"""独立到達算法の窓端・125起点・未知保持を手製テープで確認する。"""
from pathlib import Path
import importlib.util
import unittest
import numpy as np

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('independent_reach157_fixture', HERE/'確認する.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def fixture(rows: list[tuple], deadline: float = 100.) -> tuple:
    """
    機能: 入口行と指定後行だけの正常BBO人工列を作る。
    引数: rows(list[tuple[float,float]])、deadline(float)。返り値: tuple[dict,dict,dict]。
    """
    entry = {'clock': '人工0', 'time': 0., 'index': 0, 'source_line': 1,
             'last': 995., 'bid': 990., 'ask': 1000., 'quote_ok': True}
    values = [[0., 995., 990., 1000.]]
    for at, gain in rows:
        values.append([at, 1005+gain, 1000+gain, 1010+gain])
    n = len(values)
    tape = {'prices': np.array(values, dtype=np.float64),
        'physical': np.array([(i, i+1) for i in range(n)], dtype=np.int64),
        'normal': np.ones(n, bool), 'clocks': ['人工0']+[f'人工{x[0]}' for x in rows]}
    case = {'id': '人工', 'side': 1, 'entry_price': 1000., 'entry': entry}
    return case, {'force_close': deadline}, tape


class Tests(unittest.TestCase):
    """作者Goや自然ファイルなしの3主群。"""

    def test_same_row_jumpと既峰床(self) -> None:
        """
        機能: 125/250/300同時到達と、既峰300から床200への等号を分ける。
        引数: self(Tests)。返り値: None。
        """
        case, scene, tape = fixture([(1, 300), (2, 200), (3, 375), (100, 0)])
        w = m.independent_window(case, scene, tape, 'H60')
        self.assertEqual(w['status'], 'complete')
        for origin in w['origins']:
            self.assertEqual(origin['status'], 'reached')
            for c in origin['comparisons'][:6]:
                self.assertEqual(c['status'], 'upper_first')
                self.assertTrue(c['same_row_origin_and_upper'])
            c = origin['comparisons'][8]
            self.assertEqual((c['target'], c['lower_kind'], c['status']), (375, 'running_peak_minus100', 'lower_first'))
            self.assertEqual((c['first']['gain_points'], c['lower_level_at_resolution_or_end']), (200, 200))
            self.assertEqual(origin['comparisons'][6]['status'], 'upper_first')

    def test_逆先起点除外とgap既知保持と分母(self) -> None:
        """
        機能: −125先行後の125を無保護起点だけに残し、gap後500と分母除外を拒む。
        引数: self(Tests)。返り値: None。
        """
        case, scene, tape = fixture([(1, -125), (2, 125), (303, 500)], 1000.)
        w = m.independent_window(case, scene, tape, 'H60')
        self.assertEqual((w['status'], w['censor_reason']), ('censored', 'gap_censored'))
        self.assertIsNotNone(w['reaches'][4]['first_forward'])
        self.assertIsNone(w['reaches'][-1]['first_forward'])
        self.assertEqual(w['origins'][0]['status'], 'reached')
        self.assertEqual(w['origins'][1]['status'], 'opposite_first')
        self.assertEqual(w['origins'][0]['comparisons'][0]['status'], 'censored_after_origin')
        case2, scene2, tape2 = fixture([(1, 300), (100, 0)])
        complete = m.independent_window(case2, scene2, tape2, 'H60')
        counts = m.count_group([('A', w), ('B', complete)], ['A', 'B'])
        first = counts['conditionals'][0]
        self.assertEqual((first['origin_reached'], first['upper_first'], first['censored_after_origin']), (2, 1, 1))
        self.assertEqual((first['upper_on_all_origins'], first['upper_on_resolved_origins']), (.5, 1.))

    def test_deadline_strictと30秒完了EOF(self) -> None:
        """
        機能: 期限等号以降の到達を除き、+30完了/+30超過不足/空EOFを区別する。
        引数: self(Tests)。返り値: None。
        """
        for endpoint, status in ((100., 'complete'), (130., 'complete'), (130.01, 'censored')):
            case, scene, tape = fixture([(1, 125), (endpoint, 500)])
            w = m.independent_window(case, scene, tape, 'H60')
            self.assertEqual(w['status'], status)
            self.assertIsNone(w['reaches'][-1]['first_forward'])
            self.assertEqual(w['origins'][0]['comparisons'][0]['status'], 'no_hit_complete' if status == 'complete' else 'censored_after_origin')
        case, scene, tape = fixture([])
        w = m.independent_window(case, scene, tape, 'H60')
        self.assertEqual((w['status'], w['censor_reason']), ('censored', 'eof_censored'))
        self.assertEqual(w['normal_rows_in_window'], 0)
        self.assertEqual(w['origins'][0]['status'], 'censored_before_origin')


if __name__ == '__main__':
    unittest.main(verbosity=2)
