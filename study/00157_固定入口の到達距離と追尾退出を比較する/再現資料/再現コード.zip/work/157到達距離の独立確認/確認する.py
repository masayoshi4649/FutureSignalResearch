"""157の共通価格テープから到達と条件付き先着を作者Go関数なしで復元する。"""
from pathlib import Path
from collections import Counter
import argparse
import gzip
import hashlib
import json
import math
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
WIDTHS = (25, 50, 75, 100, 125, 150, 175, 200, 250, 300, 375, 500)
TARGETS = (250, 300, 375, 500)
ORIGINS = ('unprotected_first_plus125', 'plus125_before_minus125')
LOWERS = ('entry_minus125', 'gross_breakeven0', 'running_peak_minus100')
COMPARED = 0


def sha(path: Path) -> str:
    """
    機能: 物理ファイルの全SHAを逐次計算する。
    引数: path(Path)。返り値: str。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for body in iter(lambda: source.read(1 << 20), b''):
            digest.update(body)
    return digest.hexdigest()


def first(mask: np.ndarray) -> int | None:
    """
    機能: 条件配列の最初の真位置だけを得る。
    引数: mask(np.ndarray[bool])。返り値: int|None。
    """
    indices = np.flatnonzero(mask)
    return int(indices[0]) if len(indices) else None


def match(expected: object, actual: object, at: str) -> None:
    """
    機能: 対象フィールドをnull/型/原値を保って全件照合する。
    引数: expected/actual(object)、at(str)。返り値: None。
    """
    global COMPARED
    if isinstance(expected, dict):
        assert isinstance(actual, dict), (at, 'object差')
        for key, value in expected.items():
            assert key in actual, (at, key, '欠落')
            match(value, actual[key], at+'/'+key)
    elif isinstance(expected, list):
        assert isinstance(actual, list) and len(expected) == len(actual), (at, '配列長差')
        for i, (a, b) in enumerate(zip(expected, actual, strict=True)):
            match(a, b, at+'/'+str(i))
    else:
        if isinstance(expected, float):
            assert type(actual) in (float, int) and actual == expected, (at, expected, actual)
        elif isinstance(expected, bool):
            assert type(actual) is bool and actual == expected, (at, expected, actual)
        else:
            assert actual == expected, (at, expected, actual)
        COMPARED += 1


def quote(tape: dict, i: int) -> dict:
    """
    機能: 指定位置の8項目Quoteを配列から原値再構成する。
    引数: tape(dict)、i(int)。返り値: dict。
    """
    row = tape['prices'][i]
    return {'clock': tape['clocks'][i], 'time': float(row[0]), 'index': int(tape['physical'][i, 0]),
        'source_line': int(tape['physical'][i, 1]), 'last': float(row[1]), 'bid': float(row[2]),
        'ask': float(row[3]), 'quote_ok': bool(tape['normal'][i])}


def point(tape: dict, position: int | None, side: int, price: float) -> dict | None:
    """
    機能: 既知の到達位置だけを元Quoteと清算粗益へ結ぶ。
    引数: tape(dict)、position(int|None)、side(int)、price(float)。返り値: dict|None。
    """
    if position is None:
        return None
    q = quote(tape, position)
    gain = side*(q['bid' if side == 1 else 'ask']-price)
    return {'quote': q, 'gain_points': gain}


def read_tape(directory: Path, scene: dict) -> tuple:
    """
    機能: 共有テープを1回完読し、軽い列配列と全指紋証拠を得る。
    引数: directory(Path)、scene(dict)。返り値: tuple[dict,dict]。Rawは開かない。
    """
    ref = scene['tape']
    path = (directory/ref['path']).resolve()
    assert path.is_relative_to(directory.resolve()) and sha(path) == ref['sha256']
    before = (path.stat().st_size, path.stat().st_mtime_ns)
    n = ref['rows']
    prices, physical = np.empty((n, 4), np.float64), np.empty((n, 2), np.int64)
    flags, clocks = np.empty(n, bool), [None]*n
    digest, size, count = hashlib.sha256(), 0, 0
    with gzip.open(path, 'rb') as source:
        for body in source:
            assert count < n
            digest.update(body)
            size += len(body)
            q = json.loads(body)
            prices[count] = (q['time'], q['last'], q['bid'], q['ask'])
            physical[count] = (q['index'], q['source_line'])
            flags[count], clocks[count] = q['quote_ok'], q['clock']
            count += 1
    assert count == n and size == ref['decoded_bytes'] and digest.hexdigest() == ref['decoded_sha256']
    assert before == (path.stat().st_size, path.stat().st_mtime_ns) and before[0] == ref['bytes']
    assert np.isfinite(prices).all() and (prices[:, 1] > 0).all()
    assert (prices[:, 0] >= scene['start']).all() and (prices[:, 0] < scene['continuous_end']).all()
    assert np.array_equal(flags, (prices[:, 2] > 0) & (prices[:, 2] < prices[:, 3]))
    assert all(type(c) is str and c for c in clocks)
    if n:
        assert physical[0, 0] == 0 and np.all(np.diff(physical[:, 0]) == 1)
        assert np.all(np.diff(physical[:, 1]) > 0) and np.all(np.diff(prices[:, 0]) >= 0)
    tape = {'prices': prices, 'physical': physical, 'normal': flags, 'clocks': clocks}
    if n:
        assert quote(tape, 0) == scene['first_quote'] and quote(tape, n-1) == scene['last_quote']
    evidence = {'path': str(path.relative_to(ROOT)), 'sha256': ref['sha256'], 'decoded_sha256': digest.hexdigest(),
        'bytes': before[0], 'decoded_bytes': size, 'rows': n, 'CRC完読_前後stat': True}
    return tape, evidence


def independent_window(case: dict, scene: dict, tape: dict, kind: str) -> dict:
    """
    機能: 前方配列と最初交差で1窓の到達/2起点/24比較を独立復元する。
    引数: case/scene/tape(dict)、kind(str)。返り値: dict。
    """
    entry, side, price = case['entry'], case['side'], case['entry_price']
    pos = entry['index']
    assert 0 <= pos < len(tape['prices']) and quote(tape, pos) == entry
    deadline = min(scene['force_close'], entry['time']+3600) if kind == 'H60' else scene['force_close']
    times = tape['prices'][pos+1:, 0]
    normal = tape['normal'][pos+1:]
    g = side*(tape['prices'][pos+1:, 2 if side == 1 else 3]-price)
    n = len(times)
    previous = np.r_[entry['time'], times[:-1]] if n else np.empty(0)
    last_normal = np.maximum.accumulate(np.where(normal, times, entry['time']))
    previous_normal = np.r_[entry['time'], last_normal[:-1]] if n else np.empty(0)
    bad_gap = times-previous > 300
    bad_bbo = times-previous_normal > 300
    too_late = times > deadline+30
    cut = first(bad_gap | bad_bbo | too_late)
    done = first(normal & (times >= deadline))
    complete = done is not None and (cut is None or done < cut)
    end = done if complete else cut
    if end is None:
        end = n
    censor = '' if complete else 'gap_censored' if end < n and bad_gap[end] else 'bbo_gap_censored' if end < n and bad_bbo[end] else 'endpoint_missing' if end < n else 'eof_censored'
    out = {'kind': kind, 'deadline': deadline, 'status': 'complete' if complete else 'censored',
        'censor_reason': censor, 'censor_at': quote(tape, pos+1+end) if not complete and end < n else None,
        'complete_at': quote(tape, pos+1+end) if complete else None, 'extrema_cover_complete_window': complete}
    eligible = np.flatnonzero(normal & (np.arange(n) < end) & (times < deadline))
    gains = g[eligible]
    absolute = eligible+pos+1
    out['normal_rows_in_window'] = len(eligible)
    reaches = []
    plus125 = minus125 = None
    for width in WIDTHS:
        fp, ap = first(gains >= width), first(gains <= -width)
        forward = int(absolute[fp]) if fp is not None else None
        adverse = int(absolute[ap]) if ap is not None else None
        direction = 1 if forward is not None and (adverse is None or forward < adverse) else -1 if adverse is not None else 0
        initial = forward if direction == 1 else adverse if direction == -1 else None
        reaches.append({'width': width, 'first_forward': point(tape, forward, side, price),
            'first_adverse': point(tape, adverse, side, price), 'first_direction': direction,
            'first': point(tape, initial, side, price)})
        if width == 125:
            plus125, minus125 = fp, ap
    out['reaches'] = reaches
    origins = []
    for name in ORIGINS:
        opposite = name == ORIGINS[1] and minus125 is not None and (plus125 is None or minus125 < plus125)
        reached = not opposite and plus125 is not None
        origin = {'kind': name, 'status': 'opposite_first' if opposite else 'reached' if reached else 'not_reached_complete' if complete else 'censored_before_origin',
            'at': point(tape, int(absolute[plus125]), side, price) if reached else None,
            'excluded_at': point(tape, int(absolute[minus125]), side, price) if opposite else None, 'comparisons': []}
        if reached:
            tail = gains[plus125:]
            peak = np.maximum.accumulate(np.maximum(0, tail))
            prior_peak = np.r_[peak[0], peak[:-1]]
        for target in TARGETS:
            for lower_kind in LOWERS:
                c = {'target': target, 'lower_kind': lower_kind, 'status': 'not_at_risk', 'first': None,
                     'same_row_origin_and_upper': False, 'observed_peak_since_origin': 0., 'lower_level_at_resolution_or_end': None}
                if reached:
                    lower = prior_peak-100 if lower_kind == LOWERS[2] else np.full(len(tail), -125. if lower_kind == LOWERS[0] else 0.)
                    down, up = first(tail <= lower), first(tail >= target)
                    hit = min((i for i in (down, up) if i is not None), default=None)
                    if hit is None:
                        c.update(status='no_hit_complete' if complete else 'censored_after_origin',
                            observed_peak_since_origin=float(peak[-1]),
                            lower_level_at_resolution_or_end=float(peak[-1]-100 if lower_kind == LOWERS[2] else lower[-1]))
                    else:
                        assert not (down == up == hit), '上下同時は契約矛盾'
                        upper = up == hit
                        absolute_hit = int(absolute[plus125+hit])
                        c.update(status='upper_first' if upper else 'lower_first', first=point(tape, absolute_hit, side, price),
                            same_row_origin_and_upper=upper and hit == 0,
                            observed_peak_since_origin=float(peak[hit]), lower_level_at_resolution_or_end=float(lower[hit]))
                origin['comparisons'].append(c)
        origins.append(origin)
    out['origins'] = origins
    return out


def count_group(items: list[tuple], sessions: list[str]) -> dict:
    """
    機能: 独立再構成窓から固定/起点/確定分母と率を別々に集計する。
    引数: items(list[tuple[str,dict]])、sessions(list[str])。返り値: dict。
    """
    n = len(items)
    scene_counts = Counter({s: 0 for s in sessions})
    reasons = Counter()
    for session, w in items:
        scene_counts[session] += 1
        if w['status'] != 'complete':
            reasons[w['censor_reason']] += 1
    out = {'fixed_entries': n, 'window_complete': sum(w['status'] == 'complete' for _, w in items),
        'window_censored': sum(w['status'] != 'complete' for _, w in items), 'censor_reasons': dict(reasons),
        'scene_counts': dict(scene_counts), 'target_scenes': len(sessions), 'entered_scenes': sum(v > 0 for v in scene_counts.values()),
        'minimum_scene_entries': min(scene_counts.values()), 'maximum_scene_entries': max(scene_counts.values()), 'reaches': [], 'conditionals': []}
    for i, width in enumerate(WIDTHS):
        c = Counter()
        for _, w in items:
            r, complete = w['reaches'][i], w['status'] == 'complete'
            c['forward_reached_known' if r['first_forward'] is not None else 'forward_no_reach_complete' if complete else 'forward_unknown'] += 1
            c['adverse_reached_known' if r['first_adverse'] is not None else 'adverse_no_reach_complete' if complete else 'adverse_unknown'] += 1
            if r['first_direction']:
                c['first_forward_known' if r['first_direction'] == 1 else 'first_adverse_known'] += 1
            elif not complete:
                c['first_unknown'] += 1
            c['window_censored' if not complete else 'complete_first_forward' if r['first_direction'] == 1 else 'complete_first_adverse' if r['first_direction'] == -1 else 'complete_no_touch'] += 1
        keys = ('forward_reached_known', 'forward_no_reach_complete', 'forward_unknown', 'adverse_reached_known',
            'adverse_no_reach_complete', 'adverse_unknown', 'first_forward_known', 'first_adverse_known', 'first_unknown',
            'complete_first_forward', 'complete_first_adverse', 'complete_no_touch', 'window_censored')
        den = c['first_forward_known']+c['first_adverse_known']
        out['reaches'].append({'width': width, 'fixed_entries': n, **{key: c[key] for key in keys},
            'known_forward_on_fixed_denominator': c['forward_reached_known']/n if n else None,
            'first_known_resolved_rate': c['first_forward_known']/den if den else None})
    for o, origin in enumerate(ORIGINS):
        for j, target in enumerate(TARGETS):
            for k, lower in enumerate(LOWERS):
                counts = Counter()
                for _, w in items:
                    a = w['origins'][o]
                    c = a['comparisons'][j*3+k]
                    counts[{'reached': 'origin_reached', 'opposite_first': 'origin_opposite_first',
                        'not_reached_complete': 'origin_no_reach_complete'}.get(a['status'], 'origin_censored')] += 1
                    if c['status'] != 'not_at_risk':
                        counts[c['status']] += 1
                    counts['same_row_origin_and_upper'] += int(c['same_row_origin_and_upper'])
                keys = ('origin_reached', 'origin_opposite_first', 'origin_no_reach_complete', 'origin_censored',
                    'upper_first', 'lower_first', 'no_hit_complete', 'censored_after_origin', 'same_row_origin_and_upper')
                den = counts['upper_first']+counts['lower_first']
                out['conditionals'].append({'origin': origin, 'target': target, 'lower_kind': lower, 'fixed_entries': n,
                    **{key: counts[key] for key in keys}, 'upper_on_all_origins': counts['upper_first']/counts['origin_reached'] if counts['origin_reached'] else None,
                    'upper_on_resolved_origins': counts['upper_first']/den if den else None})
    return out


def main() -> None:
    """
    機能: 通知済み保存テープから837case両窓と全前後集計を一回独立照合する。
    引数: CLI --execute-saved-tapes(bool)。返り値: None。自然Raw/作者Go/金融を使わない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute-saved-tapes', action='store_true')
    args = parser.parse_args()
    assert args.execute_saved_tapes
    output = HERE/'自然確認'
    assert not output.exists()
    formal = ROOT/'study/00157_固定入口の到達距離と追尾退出を比較する'
    directory = ROOT/'inputs/00157_固定入口と価格経路/価格テープ'
    files = {'fixed': ROOT/'inputs/00157_固定入口と価格経路/固定入口入力.json',
        'manifest': directory/'価格テープの確認.json', 'detail': formal/'成果物/到達距離/到達距離と条件付き先着.json.gz',
        'summary': formal/'成果物/到達距離/到達距離の集計.json', 'completion': formal/'成果物/到達距離/完了の確認.json'}
    before = {key: (sha(p), p.stat().st_size, p.stat().st_mtime_ns) for key, p in files.items()}
    assert before['fixed'][0] == 'eabf9819351ef77fec44a7a132a8df13fd8a3aee7c3be6d87ac81dabe34ce279'
    assert before['manifest'][0] == '05b703b99f4a444d0394aa40d5efd2c5ba9e7909f1a3261271143c239affb723'
    fixed, manifest, summary, completion = (json.loads(files[key].read_bytes()) for key in ('fixed', 'manifest', 'summary', 'completion'))
    assert completion['成功'] and fixed['success'] and manifest['success'] and summary['success']
    assert completion['出力'][files['detail'].name]['sha256'] == before['detail'][0]
    assert completion['出力'][files['summary'].name]['sha256'] == before['summary'][0]
    body = gzip.decompress(files['detail'].read_bytes())
    detail_sha = hashlib.sha256(body).hexdigest()
    detail = json.loads(body)
    del body
    assert detail['success'] and detail['trial'] == 157 and detail['physical_cases'] == 837 and detail['memberships'] == 924
    assert detail['fixed_input_sha256'] == before['fixed'][0] and detail['tape_manifest_sha256'] == before['manifest'][0]
    sessions = [scene['session'] for scene in fixed['scenes']]
    assert sessions == summary['sessions'] and len(sessions) == len(set(sessions)) == 73
    by_policy = {name: [] for name in ('153U15', '152U0')}
    evidence, count, windows, memberships = [], 0, 0, 0
    for n, (scene, declared, observed) in enumerate(zip(fixed['scenes'], manifest['scenes'], detail['scenes'], strict=True)):
        assert scene['session'] == declared['session'] == observed['session']
        tape, record = read_tape(directory, declared)
        evidence.append(record)
        actual = {case['id']: case for case in observed['cases']}
        assert len(actual) == len(observed['cases']) == len(scene['cases'])
        for case in scene['cases']:
            target = actual[case['id']]
            match({key: case[key] for key in ('id', 'original_side', 'side', 'stream', 'entry', 'entry_price', 'memberships')}, target, scene['session']+'/'+case['id'])
            assert [w['kind'] for w in target['windows']] == ['H60', 'SESSION']
            expected = []
            for i, kind in enumerate(('H60', 'SESSION')):
                w = independent_window(case, scene, tape, kind)
                match(w, target['windows'][i], scene['session']+'/'+case['id']+'/'+kind)
                expected.append(w)
                windows += 1
            for member in case['memberships']:
                by_policy[member['policy']].append((scene['session'], expected))
                memberships += 1
            count += 1
        if (n+1) % 5 == 0 or n == 72:
            print(json.dumps({'確認済場': n+1, 'case': count, '窓': windows, '末端比較': COMPARED}, ensure_ascii=False), flush=True)
    assert count == 837 and windows == 1674 and memberships == 924
    for part, scope in (('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])):
        keep = set(scope)
        for policy, values in by_policy.items():
            for i, kind in enumerate(('H60', 'SESSION')):
                items = [(sid, ws[i]) for sid, ws in values if sid in keep]
                expected = count_group(items, scope)
                match(expected, summary['aggregates'][part][policy][kind], part+'/'+policy+'/'+kind)
    assert before == {key: (sha(p), p.stat().st_size, p.stat().st_mtime_ns) for key, p in files.items()}
    output.mkdir()
    proof = {'成功': True, '試行': 157, '全場': 73, '物理case': 837, '政策所属': 924, '窓': 1674,
        '幅数': 12, '起点数': 2, '目標数': 4, '下側数': 3, '全末端比較数': COMPARED,
        '対象': '全touch両側/先着/全条件付きstatus・first全Quote・peak・lower・同原行jump、全前後の全固定/全起点/確定率',
        'OHLC_MFE_MAEの数値比較': False, '作者Go関数_自然Raw_金融_追加2場読取': False,
        '方式': '前方配列と最初の閾値交差。unknown/censor後の到達を追加せず、既知touchは保持。',
        '入力': {key: {'path': p.relative_to(ROOT).as_posix(), 'sha256': before[key][0], 'bytes': before[key][1]} for key, p in files.items()},
        '詳細解凍SHA256': detail_sha, '全テープ': evidence, '全入力前後SHA_stat同体': True,
        '検算SourceSHA256': sha(Path(__file__)), 'NumPy': np.__version__}
    target = output/'独立確認.json'
    target.write_bytes((json.dumps(proof, ensure_ascii=False, indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功': True, '独立確認SHA256': sha(target), '全末端比較数': COMPARED}, ensure_ascii=False))


if __name__ == '__main__':
    main()
