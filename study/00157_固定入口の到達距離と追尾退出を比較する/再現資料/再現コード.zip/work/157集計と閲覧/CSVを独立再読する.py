"""CSV四表をPython標準CSV読取で全セル再読する。"""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math


def main() -> None:
    """
    機能: CSVの欠行・引用・小数・空値・型解釈を型付き入力と全件照合する。
    引数: CLI input/folder/output(Path)。返り値: None。
    """
    parser=argparse.ArgumentParser()
    for name in ('input','folder','output'):
        parser.add_argument(name,type=Path)
    args=parser.parse_args()
    assert not args.output.exists()
    body=args.input.read_bytes()
    data=json.loads(body)
    proof={'成功':True,'試行':157,'読取':'Python標準csv、utf-8-sig','表':{},
        '型付き入力SHA256':hashlib.sha256(body).hexdigest(),
        '検算器SHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    for name,t in data['tables'].items():
        path=args.folder/(name+'.csv')
        with path.open('r',encoding='utf-8-sig',newline='') as source:
            rows=list(csv.reader(source))
        expected=[t['headers'],*t['rows']]
        assert len(rows)==len(expected)
        count=0
        for i,(actual,wanted) in enumerate(zip(rows,expected,strict=True)):
            assert len(actual)==len(wanted)
            for j,(s,v) in enumerate(zip(actual,wanted,strict=True)):
                if v is None:
                    assert s==''
                elif type(v) is bool:
                    assert s==('true' if v else 'false')
                elif isinstance(v,(int,float)):
                    assert s!='' and math.isclose(float(s),v,rel_tol=1e-14,abs_tol=1e-9),(name,i,j,s,v)
                else:
                    assert s==v,(name,i,j,s,v)
                count+=1
        proof['表'][name]={'行':len(rows)-1,'列':len(rows[0]),'全セル一致':count,
            'SHA256':hashlib.sha256(path.read_bytes()).hexdigest()}
    assert args.input.read_bytes()==body
    args.output.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
