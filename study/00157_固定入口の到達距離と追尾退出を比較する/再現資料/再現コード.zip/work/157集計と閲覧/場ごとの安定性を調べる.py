"""157の入口先着とIFD対応差分を場単位で再標本化する。"""
from pathlib import Path
from collections import defaultdict
import argparse
import gzip
import hashlib
import json
import numpy as np


def read(path: Path) -> dict:
    """
    機能: 平文又はgzipJSONを読む。
    引数: path(Path)。返り値: dict。
    """
    with (gzip.open(path,'rt',encoding='utf-8') if path.suffix=='.gz' else path.open('r',encoding='utf-8')) as source:
        return json.load(source)


def sha(path: Path) -> str:
    """
    機能: SHA256を逐次計算する。
    引数: path(Path)。返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1<<20),b''):
            h.update(block)
    return h.hexdigest()


def interval(values: np.ndarray) -> list[float]:
    """
    機能: 有限の再標本化推定値の95%百分位区間を得る。
    引数: values(np.ndarray)。返り値: list[float]。
    """
    return np.quantile(values[np.isfinite(values)],[.025,.975]).tolist()


def main() -> None:
    """
    機能: 73場を単位とした固定seed再標本化と場集中を出力する。
    引数: CLI expected/exits/output(Path)。返り値: None。
    """
    parser=argparse.ArgumentParser()
    for name in ('expected','exits','output'):
        parser.add_argument(name,type=Path)
    args=parser.parse_args()
    assert not args.output.exists()
    old,exits=read(args.expected),read(args.exits)
    sessions=[s['session'] for s in exits['scenes']]
    rank={s:i for i,s in enumerate(sessions)}
    assert len(sessions)==73
    samples=np.random.default_rng(157).integers(0,73,size=(20000,73))
    inputs={str(args.expected.resolve()):sha(args.expected),str(args.exits.resolve()):sha(args.exits)}
    entry_results={}
    for base in ('153U15','152U0'):
        counts=np.zeros((73,5),dtype=np.int64)
        for case in old['cases']:
            if base not in case['memberships']:
                continue
            i=rank[case['session']]
            counts[i,0]+=1
            h=next(h for h in case['outcomes'] if h['seconds']==3600)
            d=next(t for t in h['touches'] if t['width']==125)['direction']
            counts[i,4 if h['status']!='complete' else 1 if d==1 else 2 if d==-1 else 3]+=1
        sums=counts[samples].sum(axis=1)
        p=sums[:,1]/(sums[:,1]+sums[:,2])
        concentration=sorted(zip(counts[:,0].tolist(),sessions),reverse=True)
        drop=counts.sum(axis=0)-counts
        leave=drop[:,1]/(drop[:,1]+drop[:,2])
        entry_results[base]={'固定N':int(counts[:,0].sum()),'順行':int(counts[:,1].sum()),
            '逆行':int(counts[:,2].sum()),'先着率':float(counts[:,1].sum()/(counts[:,1]+counts[:,2]).sum()),
            '場bootstrap95参考区間':interval(p),'一場除外先着率の最小最大':[float(leave.min()),float(leave.max())],
            '取得最多5場':[{'場':s,'取得':n} for n,s in concentration[:5]],
            '取得最多5場割合':sum(n for n,s in concentration[:5])/int(counts[:,0].sum())}
    paired=defaultdict(lambda:np.zeros(73))
    unknown=defaultdict(int)
    n=defaultdict(int)
    for s in exits['scenes']:
        i=rank[s['session']]
        for c in s['cases']:
            lookup={(r['policy'],r['horizon']):r for r in c['results'] if r['delay']=='D1' and r['cost']=='C5'}
            for (policy,h),r in lookup.items():
                baseline=lookup['F125S125',h]
                for m in c['memberships']:
                    key=(m['policy'],h,policy)
                    if r['status']==baseline['status']=='closed':
                        paired[key][i]+=r['profit_yen']-baseline['profit_yen']
                        n[key]+=1
                    else:
                        unknown[key]+=1
    exit_results=[]
    for key,delta in sorted(paired.items()):
        boot=delta[samples].sum(axis=1)
        exit_results.append({'入口':key[0],'期限':key[1],'出口':key[2],'対応既知':n[key],
            '対応未知':unknown[key],'既知IFD差分円':float(delta.sum()),
            '場bootstrap95参考区間円':interval(boot),'改善場':int((delta>0).sum()),'悪化場':int((delta<0).sum())})
    result={'成功':True,'試行':157,'seed':157,'再標本化':20000,'単位':'73場の独立復元抽出',
        '注意':'既使用・多重比較後の参考診断。未知損益の影響と場間の系列相関は解決しない。出口区間は双方既知の同取得差分だけで、未知額を0円とした総収支区間ではない。',
        '入口':entry_results,'出口':exit_results,'入力':inputs,'コードSHA256':sha(Path(__file__)),'numpy':np.__version__}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(entry_results,ensure_ascii=False))


if __name__=='__main__':
    main()
