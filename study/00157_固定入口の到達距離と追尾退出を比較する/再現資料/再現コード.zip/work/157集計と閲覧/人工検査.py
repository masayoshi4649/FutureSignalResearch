"""157集計の未知・損益分解と同時刻DDを人工検査する。"""
import importlib.util
from pathlib import Path

SPEC = importlib.util.spec_from_file_location('aggregate157',Path(__file__).with_name('集計する.py'))
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def closed(stamp: float, points: float, fee: float) -> dict:
    """
    機能: 一つの決済既知の人工行を作る。
    引数: stamp/points/fee(float)。返り値: dict。
    """
    return {'status':'closed','fill':{'time':stamp},'profit_yen':100*points-fee,
        'profit_points':points,'fee_yen':fee,'armed':True,'profit_after_positive_loss':points*100<fee,
        'profit_after125_loss':False,'held_seconds':10,'giveback_points':5}


def main() -> None:
    """
    機能: 費用差、未知の非ゼロ化、同時刻の恣意的DD回避を検査する。
    引数: なし。返り値: None。
    """
    rows = [closed(1,20,1077),closed(2,5,1077),closed(2,-5,1077),
            {'status':'unknown','profit_yen':None,'profit_points':None}]
    value = MODULE.metrics(rows)
    assert value['利益総額円'] == 923 and value['損失総額円'] == 2154
    assert value['既知差引円'] == -1231 and value['全件確定差引円'] is None
    assert value['取得数'] == 4 and value['決済既知'] == 3 and value['損益未知'] == 1
    assert MODULE.metrics([])['既知決済勝率'] is None
    assert MODULE.realized_dd([closed(1,-1,0),closed(1,1,0)]) == 0
    assert MODULE.metrics([closed(1,0,0)])['同額取引'] == 1
    lo,hi = MODULE.wilson(7,10)
    assert 0 < lo < .7 < hi < 1
    print('成功: 未知/費用/同時刻DD/同額/参考区間の5検査')


if __name__ == '__main__':
    main()
