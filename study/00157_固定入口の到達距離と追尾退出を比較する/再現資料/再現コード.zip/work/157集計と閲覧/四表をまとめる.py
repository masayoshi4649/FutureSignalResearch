"""157の出口集計と経路診断を型付きCSV四表へ接続する。"""
from pathlib import Path
import argparse
import hashlib
import json


def sha(path: Path) -> str:
    """
    機能: ファイルのSHA256を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 完了済みの二集計を検証し、CSV化用の型付き四表を新規保存する。
    引数: CLI exits/distance/output(Path)。返り値: None。
    """
    parser=argparse.ArgumentParser()
    for name in ('exits','distance','output'):
        parser.add_argument(name,type=Path)
    args=parser.parse_args()
    assert not args.output.exists()
    exits=json.loads(args.exits.read_bytes())
    distance=json.loads(args.distance.read_bytes())
    tables=exits['tables']
    reaches,conditionals=[],[]
    origins={'unprotected_first_plus125':'無保護で初めて125順行',
        'plus125_before_minus125':'125逆行より先に125順行'}
    lowers={'entry_minus125':'取得から125逆行','gross_breakeven0':'取得価格へ戻る',
        'running_peak_minus100':'逐次峰から100逆行'}
    agg=distance['aggregates']
    for part,scope in (('all','全73場'),('train','前48場'),('validation','後25場')):
        for base in ('153U15','152U0'):
            for horizon in ('H60','SESSION'):
                a=agg[part][base][horizon]
                n=a['fixed_entries']
                assert n==a['window_complete']+a['window_censored']
                for r in a['reaches']:
                    assert r['forward_reached_known']+r['forward_no_reach_complete']+r['forward_unknown']==n
                    assert r['adverse_reached_known']+r['adverse_no_reach_complete']+r['adverse_unknown']==n
                    reaches.append([base,horizon,scope,r['width'],n,a['window_complete'],a['window_censored'],
                        r['forward_reached_known'],r['forward_no_reach_complete'],r['forward_unknown'],
                        r['forward_reached_known']/n,(r['forward_reached_known']+r['forward_unknown'])/n,
                        r['adverse_reached_known'],r['adverse_no_reach_complete'],r['adverse_unknown'],
                        r['first_forward_known'],r['first_adverse_known'],r['first_unknown'],
                        r['first_known_resolved_rate'],r['complete_first_forward'],r['complete_first_adverse'],
                        r['complete_no_touch'],r['window_censored'],
                        a['mfe_complete_windows']['mean'],a['mae_complete_windows']['mean']])
                for c in a['conditionals']:
                    e=c['origin_reached']
                    assert c['upper_first']+c['lower_first']+c['no_hit_complete']+c['censored_after_origin']==e
                    assert e+c['origin_opposite_first']+c['origin_no_reach_complete']+c['origin_censored']==n
                    conditionals.append([base,horizon,scope,origins[c['origin']],c['target'],lowers[c['lower_kind']],
                        n,e,c['origin_opposite_first'],c['origin_no_reach_complete'],c['origin_censored'],
                        c['upper_first'],c['lower_first'],c['no_hit_complete'],c['censored_after_origin'],
                        c['upper_on_all_origins'],(c['upper_first']+c['censored_after_origin'])/e if e else None,
                        c['upper_on_resolved_origins'],c['same_row_origin_and_upper']])
    assert len(reaches)==144 and len(conditionals)==288
    tables['到達距離']={'headers':['入口','保有期限','区間','到達幅pt','固定取得数','全窓完了','全窓不足',
        '順到達既知','順未到達完了','順到達未知','固定N順到達率下限','固定N順到達率上限',
        '逆到達既知','逆未到達完了','逆到達未知','順先着既知','逆先着既知','先着未知',
        '先着確定のみ順率','全窓完了順先着','全窓完了逆先着','全窓完了未到達','旧式全窓不足',
        '完了窓平均MFEpt','完了窓平均MAEpt'],'rows':reaches}
    tables['125後の伸長']={'headers':['入口','保有期限','区間','125起点','順行目標pt','下側障壁',
        '固定取得数','125起点成立','125逆側先着除外','起点未到達完了','起点前観測不足',
        '目標先着','下側先着','起点後期限未到達','起点後観測不足','起点分母目標先着率下限',
        '起点分母目標先着率上限','先着確定のみ目標率','起点と目標同一原行'],'rows':conditionals}
    sources=dict(exits['sources'])
    sources.update({str(args.exits.resolve()):sha(args.exits),str(args.distance.resolve()):sha(args.distance),
        str(Path(__file__).resolve()):sha(Path(__file__))})
    result={'試行':157,'単位':exits['単位'],'DD定義':exits['DD定義'],
        '率':'0〜1の数値。観測不足を除いた確定例率と固定分母下限/上限は別指標。',
        'tables':tables,'sources':sources}
    args.output.write_text(json.dumps(result,ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'行':{k:len(v['rows']) for k,v in tables.items()},'SHA256':sha(args.output)},ensure_ascii=False))


if __name__=='__main__':
    main()
