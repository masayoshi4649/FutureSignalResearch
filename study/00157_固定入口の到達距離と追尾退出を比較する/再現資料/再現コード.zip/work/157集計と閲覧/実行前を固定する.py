"""157の最終入口入力と実行条件を自然価格走査前に固定する。"""
from pathlib import Path
import hashlib
import json
import shutil

ROOT=Path(__file__).resolve().parents[2]


def sha(path: Path) -> str:
    """
    機能: ファイルの物理SHA256を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 837入口/924所属と12政策条件を恒久保存し、実行前票を新規記録する。
    引数: なし。返り値: None。Raw本文は読まない。
    """
    source=ROOT/'work/157固定入口と価格経路/固定入口入力_最終.json'
    contract=ROOT/'study/00157_固定入口の到達距離と追尾退出を比較する/実行条件.md'
    assert sha(source)=='eabf9819351ef77fec44a7a132a8df13fd8a3aee7c3be6d87ac81dabe34ce279'
    assert sha(contract)=='96639df6c3fa6bb989d2685c792bbcf22709fb41e4e14c681a1ca05c25d05d7d'
    target=ROOT/'inputs/00157_固定入口と価格経路/固定入口入力.json'
    assert not target.exists()
    value=json.loads(source.read_bytes())
    assert value['success'] and value['expected_case_count']==837 and value['expected_membership_count']==924
    assert len(value['scenes'])==73
    assert not any(s['session'] in ('2026-11-10_Night','2026-11-11_Day') for s in value['scenes'])
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,target)
    assert sha(target)==sha(source)
    code=ROOT/'work/157固定入口と価格経路'
    refs={str(p.relative_to(ROOT)):sha(p) for p in code.rglob('*')
          if p.is_file() and p.suffix in ('.go','.mod','.py','.exe')}
    ticket=ROOT/'study/00157_固定入口の到達距離と追尾退出を比較する/検査/実行前固定.json'
    ticket.parent.mkdir(parents=True,exist_ok=True)
    assert not ticket.exists()
    result={'成功':True,'試行':157,'記録段階':'73場のRaw本文再生前',
        '実行条件':{'path':str(contract.relative_to(ROOT)),'sha256':sha(contract)},
        '固定入力':{'path':str(target.relative_to(ROOT)),'sha256':sha(target),'bytes':target.stat().st_size},
        '場数':73,'物理case':837,'所属':924,'Raw再選択':False,
        '未見2場の読取':False,'Raw走査コード':refs,'固定器SHA256':sha(Path(__file__)),
        'ユーザー追加':'全出口を単純IFD±125ptと対応比較し、153少数/152多数と場単位の安定性を分ける'}
    ticket.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':
    main()
