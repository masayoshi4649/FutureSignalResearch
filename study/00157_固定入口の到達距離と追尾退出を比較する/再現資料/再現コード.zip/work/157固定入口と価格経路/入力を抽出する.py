"""旧153U15/152U0の固定所属だけを837物理caseへ束ねる。"""
from pathlib import Path
import argparse
import copy
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
REFS = {
    '153U15': {'path': 'inputs/00153_先行高安の独立出生/選択対応.json.gz',
        'sha256': '3ffdab0cfd846e250473206b2e55c9cd45a8b18e1c9a73285537319aa1e99334',
        'decoded_sha256': 'bf5a29225a69e4e8837df9d8b34f263adb59f43ee70908e7668cc35a1a97a758'},
    '152U0': {'path': 'inputs/00152_複合回復の方向切替/選択対応.json.gz',
        'sha256': '8f7815505f3a0bc158d738a128df1b7d9a140455aa5178ba7f1b8b1eb447032b',
        'decoded_sha256': 'd77fcb20976b6207039e31912058894fdf1cc31c7aaae604739df82d2d74110c'},
    '148固定取得': {'path': 'inputs/00148_全1分入口母集団/固定取得入力.json.gz',
        'sha256': '99f10a996ca6e8b6c428061f1b48624bbc479ec84c500a9633818d47e4298e2a',
        'decoded_sha256': '12c43fe60e0ffd5ffa44bec7b5f7dd3d60bb92b291e0008db23587dcf19536d3'},
}


def sha(path: Path) -> str:
    """
    機能: 共有元入力の物理指紋を一走査で確認する。
    引数: path(Path)。返り値: str。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1 << 20), b''):
            digest.update(chunk)
    return digest.hexdigest()


def read(ref: dict) -> dict:
    """
    機能: 旧gzipをCRC/物理解凍SHA確認後だけJSON値へする。
    引数: ref(dict)。返り値: dict。元データを複写しない。
    """
    path = ROOT/ref['path']
    assert sha(path) == ref['sha256']
    body = gzip.decompress(path.read_bytes())
    assert hashlib.sha256(body).hexdigest() == ref['decoded_sha256']
    return json.loads(body)


def build(first: dict, second: dict, fixed: dict) -> dict:
    """
    機能: 2固定政策を再判定せず、元全JSON票と共通物理取得を一入力へ結ぶ。
    引数: first/second/fixed(dict)。返り値: dictはSource未実行の固定入力。
    """
    assert first['成功'] and first['試行'] == 153 and second['成功'] and second['試行'] == 152
    assert first['選択時の金融ラベル利用'] is False and second['選択時の金融ラベル利用'] is False
    sessions = first['全73場']
    assert len(sessions) == len(set(sessions)) == 73 and sessions == second['全73場']
    assert [scene['session'] for scene in fixed['scenes']] == sessions
    by_key = {}
    policies = []
    for name, key, value, count in (('153U15', 'U15', first, 93), ('152U0', 'U0', second, 831)):
        rows = value['政策'][key]
        assert len(rows) == count == len({(r['session'], r['case_id']) for r in rows})
        policies.append({'id': name, 'source_trial': value['試行'], 'source_policy': key, 'membership_count': count})
        for index, row in enumerate(rows):
            assert type(row['side']) is int and row['side'] in (-1, 1) and row['stream'] in ('original', 'reverse')
            by_key.setdefault((row['session'], row['case_id']), []).append({'policy': name,
                'source_index': index, 'side': row['side'], 'stream': row['stream'], 'source_selection_ref': copy.deepcopy(row)})
    scenes = []
    matched = set()
    for source_scene in fixed['scenes']:
        session = source_scene['session']
        metadata = copy.deepcopy(source_scene)
        metadata.pop('entries')
        cases = []
        seen = set()
        for entry in source_scene['entries']:
            assert entry['id'] not in seen
            seen.add(entry['id'])
            identity = (session, entry['id'])
            if identity not in by_key:
                continue
            members = copy.deepcopy(by_key[identity])
            side, stream = members[0]['side'], members[0]['stream']
            assert side == entry['side']*(1 if stream == 'original' else -1)
            assert all(member['side'] == side and member['stream'] == stream for member in members)
            q = entry['entry']
            assert q['quote_ok'] and 0 < q['bid'] < q['ask'] and q['clock'] and q['last'] > 0
            assert source_scene['start'] <= q['time'] < min(source_scene['force_close'], source_scene['end']-3900)
            price = q['ask' if side == 1 else 'bid']
            for member in members:
                member['entry_price'] = price
            cases.append({'id': entry['id'], 'original_side': entry['side'], 'side': side, 'stream': stream,
                'entry': copy.deepcopy(q), 'entry_price': price, 'source_fixed_entry': copy.deepcopy(entry), 'memberships': members})
            matched.add(identity)
        scenes.append({**copy.deepcopy(metadata), 'continuous_end': source_scene['end']-300,
                       'source_scene': metadata, 'cases': cases})
    assert matched == set(by_key) and len(matched) == 837
    assert sum(len(c['memberships']) for s in scenes for c in s['cases']) == 924
    return {'success': True, 'trial': 157, 'schema': 'fixed_exit_entries_v1',
        'source_refs': copy.deepcopy(REFS), 'policies': policies, 'expected_case_count': 837,
        'expected_membership_count': 924, 'scenes': scenes, 'new_entry_selection': False,
        'physical_cases_are_independent_policy_memberships': False, 'raw_read_or_new_exit_results': False}


def main() -> None:
    """
    機能: 明示抽出flagのときだけ旧3gzipからwork固定入力を排他保存する。
    引数: CLI --extract-fixed-only(bool)。返り値: None。Raw再生/正式コピーは行わない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--extract-fixed-only', action='store_true')
    args = parser.parse_args()
    assert args.extract_fixed_only
    target = HERE/'固定入口入力_最終.json'
    assert not target.exists() and not (HERE/'入力抽出の確認_最終.json').exists()
    proof_path = ROOT/'work/157固定入口の準備/schemaの確認.json'
    assert sha(proof_path) == '9ec751518049c66d0a28d43d0b45cf7352ff8fc5526d541086a4c590e0aa1cfb'
    before = {name: (sha(ROOT/ref['path']), (ROOT/ref['path']).stat().st_size, (ROOT/ref['path']).stat().st_mtime_ns) for name, ref in REFS.items()}
    output = build(read(REFS['153U15']), read(REFS['152U0']), read(REFS['148固定取得']))
    contract = ROOT/'study/00157_固定入口の到達距離と追尾退出を比較する/実行条件.md'
    assert sha(contract) == '96639df6c3fa6bb989d2685c792bbcf22709fb41e4e14c681a1ca05c25d05d7d'
    output['source_refs']['Root実行条件'] = {'path': contract.relative_to(ROOT).as_posix(), 'sha256': sha(contract)}
    output['source_refs']['保存観測までの全924所属の独立確認'] = {'path': proof_path.relative_to(ROOT).as_posix(), 'sha256': sha(proof_path)}
    body = (json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False)+'\n').encode('utf-8')
    with target.open('xb') as destination:
        destination.write(body)
    assert output == json.loads(target.read_bytes())
    assert before == {name: (sha(ROOT/ref['path']), (ROOT/ref['path']).stat().st_size, (ROOT/ref['path']).stat().st_mtime_ns) for name, ref in REFS.items()}
    proof = {'成功': True, '試行': 157, '全73場': 73, '物理case': 837, '政策所属': {'153U15': 93, '152U0': 831},
        '共通C1': 87, '入力SHA256': sha(target), '入力bytes': len(body), '元全JSON値deepcopy_数値精度保持': True,
        '全入力CRC_物理解凍SHA_前後stat一致': True, 'Raw本文_新出口損益_正式コピー': False,
        'source_refs': output['source_refs'], '抽出SourceSHA256': sha(Path(__file__))}
    (HERE/'入力抽出の確認_最終.json').write_bytes((json.dumps(proof, ensure_ascii=False, indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功': True, '入力SHA256': proof['入力SHA256'], '物理case': 837, '所属': 924}, ensure_ascii=False))


if __name__ == '__main__':
    main()
