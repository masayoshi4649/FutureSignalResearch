"""157固定入力抽出の全値保持と所属対応を人工だけで検査する。"""
from pathlib import Path
import copy
import importlib.util
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('extract157fixture', HERE/'入力を抽出する.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def fixture() -> tuple:
    """
    機能: 旧87共通+6/744別caseの73場人工を作り自然価格を使用しない。
    引数: なし。返り値: tupleは旧153/旧152/固定148風dict。
    """
    sessions = [f'場{i:02}' for i in range(73)]
    scenes = [{'session': session, 'contract': 'X', 'start': 1000000+i*20000,
        'end': 1010000+i*20000, 'force_close': 1006000+i*20000,
        'raw': {'path': '人工未読', 'sha256': '0'*64, 'mtime_ns': 9007199254740993},
        'expected_accepted': 10000, 'expected_quality': {'人工': True}, 'entries': []} for i, session in enumerate(sessions)]
    references = []
    for i in range(837):
        scene = scenes[i % 73]
        quote = {'clock': '人工時計', 'time': scene['start']+10, 'index': i+1,
                 'source_line': i+2, 'last': 100., 'bid': 99., 'ask': 101., 'quote_ok': True}
        scene['entries'].append({'id': f'case{i}', 'side': 1, 'entry': quote, '未利用': {'値': [None, 9007199254740993]}})
        side = 1 if i % 2 else -1
        references.append({'case_id': f'case{i}', 'session': scene['session'], 'side': side,
            'stream': 'original' if side == 1 else 'reverse', '未利用': {'値': [None, 9007199254740993]}})
    first = {'成功': True, '試行': 153, '選択時の金融ラベル利用': False, '全73場': sessions,
             '政策': {'U15': copy.deepcopy(references[:93])}}
    second = {'成功': True, '試行': 152, '選択時の金融ラベル利用': False, '全73場': sessions,
              '政策': {'U0': copy.deepcopy(references[:87]+references[93:]), 'U1': '未使用の人工政策'}}
    return first, second, {'scenes': scenes}


class Tests(unittest.TestCase):
    """Rawを開かず固定値だけを扱う3主群。"""

    def test_全値非改変と精度(self) -> None:
        """
        機能: 837/924の共通性と元未知キー/大整数を保持しdeepcopyする。
        引数: self(Tests)。返り値: None。
        """
        data = fixture()
        before = copy.deepcopy(data)
        out = m.build(*data)
        self.assertEqual(data, before)
        cases = [case for scene in out['scenes'] for case in scene['cases']]
        self.assertEqual(len(cases), 837)
        self.assertEqual(sum(len(case['memberships']) for case in cases), 924)
        self.assertEqual(sum(len(case['memberships']) == 2 for case in cases), 87)
        self.assertEqual(cases[0]['memberships'][0]['source_selection_ref']['未利用']['値'][1], 9007199254740993)
        cases[0]['memberships'][0]['source_selection_ref']['未利用']['値'].append(2)
        self.assertEqual(data, before)

    def test_共通向きの相違は拒否(self) -> None:
        """
        機能: 同caseを2政策の別向きへ無断でまとめない。
        引数: self(Tests)。返り値: None。
        """
        first, second, fixed = fixture()
        second['政策']['U0'][0].update(side=1, stream='original')
        with self.assertRaises(AssertionError):
            m.build(first, second, fixed)

    def test_旧U1を読まず実側を使う(self) -> None:
        """
        機能: 152U1の未知内容は無関係で、元売選択はBidへ対応する。
        引数: self(Tests)。返り値: None。
        """
        first, second, fixed = fixture()
        before = m.build(first, second, fixed)
        second['政策']['U1'] = {'将来成績': '利用しない'}
        out = m.build(first, second, fixed)
        self.assertEqual(out, before)
        case = next(case for scene in out['scenes'] for case in scene['cases'] if case['id'] == 'case0')
        self.assertEqual((case['side'], case['stream'], case['entry_price']), (-1, 'reverse', 99.))


if __name__ == '__main__':
    unittest.main(verbosity=2)
