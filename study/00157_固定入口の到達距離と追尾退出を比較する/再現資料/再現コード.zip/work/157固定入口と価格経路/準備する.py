"""157の人工/由来/固定入力metadataだけを確認し、自然Raw前に停止する。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: Source/固定入力の物理指紋を計算する。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(command: list[str]) -> dict:
    """
    機能: 自然Rawを呼ばない人工/構文/metadataコマンドを記録する。
    引数: command(list[str])。返り値: dict。
    """
    result = subprocess.run(command, cwd=HERE, capture_output=True,
        env={**os.environ, 'PYTHONUTF8': '1', 'PYTHONIOENCODING': 'utf-8', 'PYTHONDONTWRITEBYTECODE': '1'})
    stdout, stderr = result.stdout.decode('utf-8', 'strict'), result.stderr.decode('utf-8', 'strict')
    assert result.returncode == 0, (command, stdout, stderr)
    return {'command': command, '終了値': result.returncode, 'stdout': stdout, 'stderr': stderr}


def main() -> None:
    """
    機能: 由来3源/人工9主/Go test-vet-build/metadataを確認し準備と停止票を排他保存する。
    引数: なし。返り値: None。自然Rawテープを生成しない。
    """
    ready, stop = HERE/'準備の確認.json', HERE/'停止の確認.json'
    assert not ready.exists() and not stop.exists()
    provenance = json.loads((HERE/'133からの由来.json').read_bytes())
    for row in provenance['源']:
        original = (ROOT/row['元']).read_bytes()
        copied = (HERE/row['先']).read_bytes()
        assert hashlib.sha256(original).hexdigest() == row['元SHA256']
        assert hashlib.sha256(copied).hexdigest() == row['先SHA256']
        assert original.replace(b'package holdingohlc113', b'package pricetape157', 1) == copied
    for path in HERE.glob('*.py'):
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
            if isinstance(node, ast.FunctionDef):
                doc = ast.get_docstring(node)
                assert doc and '\n' in doc and all(key in doc for key in ('機能', '引数', '返り値'))
    source_paths = sorted(p for p in HERE.rglob('*') if p.is_file() and p.suffix in ('.go', '.mod', '.py', '.md', '.json') and '__pycache__' not in p.parts)
    before = {path: sha(path) for path in source_paths}
    results = [run([sys.executable, '-X', 'utf8', str(HERE/'人工検査_入力.py')]),
        run(['go', 'test', '-count=1', '-v', './...']), run(['go', 'vet', './...']),
        run(['go', 'build', '-o', '固定入口の価格テープ.exe', './cmd/run'])]
    input_path = HERE/'固定入口入力_最終.json'
    expected = 'eabf9819351ef77fec44a7a132a8df13fd8a3aee7c3be6d87ac81dabe34ce279'
    assert sha(input_path) == expected
    results.append(run([str(HERE/'固定入口の価格テープ.exe'), '--input', str(input_path), '--sha256', expected, '--metadata-only']))
    assert before == {path: sha(path) for path in source_paths}
    extract = json.loads((HERE/'入力抽出の確認_最終.json').read_bytes())
    assert extract['成功'] and extract['入力SHA256'] == expected and not extract['Raw本文_新出口損益_正式コピー']
    proof = {'成功': True, '試行': 157, '用途': '固定入口入力と共通価格テープの自然前準備',
        'Root実行条件SHA256': '96639df6c3fa6bb989d2685c792bbcf22709fb41e4e14c681a1ca05c25d05d7d',
        'Go主人工': 6, 'GoEOF小区分': 3, 'Python入力人工': 3, '人工_検査': results,
        '全73場_837物理_924所属metadata検証': True, '入力': {'path': input_path.relative_to(ROOT).as_posix(), 'sha256': expected, 'bytes': input_path.stat().st_size},
        '実行ファイル': {'path': (HERE/'固定入口の価格テープ.exe').relative_to(ROOT).as_posix(), 'sha256': sha(HERE/'固定入口の価格テープ.exe'), 'bytes': (HERE/'固定入口の価格テープ.exe').stat().st_size},
        'source': {p.relative_to(ROOT).as_posix(): h for p, h in before.items()},
        '133再用3源package以外同体': True, '元選択_元fixed_元sceneの全JSON値保持': True,
        '自然Rawテープ生成_新戦略_新損益_新CSV_追加2場読取': False, '正式コピー': False,
        '全RawEOF_指紋_CRC_stat_品質_入口検証後だけ成功': True, '正常不正常と同値行削除': False,
        '価格テープはStart以上End300未満_終了後もRaw検査完読': True, 'Source前後SHA同体': True,
        '作者自己確認と独立検査の区別': True, '未採用の旧契約入力98b149は削除_最終入力だけ使用': True}
    ready.write_bytes((json.dumps(proof, ensure_ascii=False, indent=2)+'\n').encode('utf-8'))
    stop.write_bytes((json.dumps({'成功': True, '編集停止': True, '試行': 157, '準備SHA256': sha(ready),
        '入力SHA256': expected, '実行ファイルSHA256': proof['実行ファイル']['sha256'], 'Source': proof['source'],
        '自然Raw未実行': True}, ensure_ascii=False, indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功': True, '入力SHA256': expected, '準備SHA256': sha(ready), '停止SHA256': sha(stop),
        'exe_SHA256': proof['実行ファイル']['sha256']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
