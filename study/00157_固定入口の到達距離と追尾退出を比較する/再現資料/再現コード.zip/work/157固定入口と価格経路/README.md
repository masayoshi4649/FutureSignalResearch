# 157固定入口と共通価格テープ

自然Raw生成は未実行。Root実行条件96639df6…に従い、153 U15全93と152 **U0全831**の837物理case/924所属、全73場を固定する。旧156は再開せず、133/148や既存正式資料を変更しない。

## 固定入力

[固定入口入力_最終.json](固定入口入力_最終.json)が唯一の採用入力。[入力抽出の確認_最終.json](入力抽出の確認_最終.json)に元3gzipの物理/解凍SHA・CRC・前後statと全値copyの範囲を残す。旧実行条件6c559…へ束縛した準備入力98b149…は不採用で削除し、元選択や数量入力を恒久複写しない。

`Input157`の各sceneはsession/contract/start/end/force_close/continuous_end=End−300、Raw path/SHA、元採用数/品質宣言を持つ。`source_scene`は元148sceneのentries以外を全JSON値で保持する。各caseは次を持つ。

- id、original_side（148の元方向）、side/stream/entry_price（固定選択の実側）、entry（全Quote）。
- source_fixed_entryは元固定entryの全JSON値。membershipsのsource_selection_refは元選択の全JSON値で、大整数や未知キーを削らない。
- memberships.policyは153U15/152U0。source_indexは元政策内の順序。共通C1全87は両側のside/stream一致を確認し、物理テープを共用しても所属分母を混ぜない。

`source_refs`に旧153/152選択、148固定取得、Root実行条件、保存観測までの924所属確認票を束縛した。Goは固定入力SHAと原値票の対応をRaw読取前に検査する。買い入口Ask/売りBid、originalを買いとは解釈しない。

## 133由来と生成

[133からの由来](133からの由来.json)のreader.go/types.go/stream.goは133からpackage行だけ変更して再用した。CurrentPriceTime・同時刻の採用index/物理source_line、除外/不正常BBO・全品質の規則を保つ。実受信時計や全約定イベントへの復元ではない。

各Rawは全物理bytesを**1回だけ**読み、価格テープへStart以上ContinuousEnd未満のaccepted Quoteを全行出す。不正常BBOや同値価格/同じ価格時計の行も削らない。Quoteはclock/time/index/source_line/last/bid/ask/quote_okの8項目。場外・後退等のparser除外行はテープへ補完せず元品質票で残す。

対象entryのsource_lineで全Quote一致を確認する。Entryの前でもテープは場開始から保存し、取得後状態を作るかは出口/診断側の役割。終了後もRawを完読してgzip CRC/全SHA/前後stat/限月/accepted件数/全品質/全entryを検査する。成功前は`.part`、当場の全検査後だけ完成gzip名へ替える。全73場成功後だけ`価格テープの確認.json`を作り、途中のテープを全体成功へ転用しない。

自然生成CLI（Rootの契約固定・実行通知後だけ）:

```powershell
& 'work/157固定入口と価格経路/固定入口の価格テープ.exe' `
  --input 'work/157固定入口と価格経路/固定入口入力_最終.json' `
  --sha256 'eabf9819351ef77fec44a7a132a8df13fd8a3aee7c3be6d87ac81dabe34ce279' `
  --output-dir '<未作成の価格テープ出力先>' --workers 8 --execute-after-root-freeze
```

入力だけの検証は同exeの`--metadata-only --input ... --sha256 ...`。これはRawを開かない。自然生成は試行157の準備停止後Rootが一度だけ実行する。

## 共有Go APIとテープschema

module/importは`pricetape157`。他moduleのgo.modで`replace pricetape157 => ../157固定入口と価格経路`を指定する。[tape.go](tape.go)が公開型とJSON tagの正本。

- `LoadFixed(path,sha) (Input157,error)`：全73/837/924・93/831・元全値票/選択方向/実取得価格を検証する。
- `ReadManifest(path,sha) (TapeManifest157,error)`：Rootが固定した完成manifestを認証する。
- `ReadTape(directory,scene,consume func(Quote)error) (TapeRead157,error)`：同値/不正常を含む全accepted Quoteを順番に配送し、全CRC/物理解凍SHA/前後stat/行数を完読検査する。受け側の結果正本化は成功後だけ行う。
- `Run157(input,sha,output,workers) error`：固定入力とRawから共通テープを作る。出口政策や新取得を実行しない。

完成manifestはschema=`accepted_quote_tapes_v1`、input参照/全件数/clock_basis/scenesを持つ。`SceneTape157`は場時計、Raw参照/実SHA/stat/quality、tape、first_quote/last_quote、tape_bad_bbo、entry_matchesを持つ。`tape.path`はmanifestディレクトリ相対、sha256はgzip物理、decoded_sha256はJSONL全bytes、bytes/decoded_bytes/rowsを分ける。各entry_matchesはcase_id/quote/tape_line（1起算）。

## 検査範囲

Go6主（EOF内にCRC/品質/指紋の3小区分）、Python抽出3主。正常/不正常/同値全保持、終端等号除外、plain/gzip magic、元全値精度、EOF前成功禁止、入口一値差、テープCRC/path逃げ、元売stream方向、非改変を確認した。test/vet/buildと最終固定入力のmetadata-onlyを実行し、自然Rawは実行していない。作者自己確認とRoot/他担当の独立確認を分ける。

出口FSM/到達診断は別moduleでこのテープを共用する。H60/SESSION、D0/D1、費用C0/C5、追尾・約定・gap/終端の規則は[正式実行条件](../../study/00157_固定入口の到達距離と追尾退出を比較する/実行条件.md)で定義し、この生成器は出口成績を計算しない。
