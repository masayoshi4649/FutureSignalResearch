"""157共有価格テープから旧133時計のH30/H60を独立復元する。"""
from pathlib import Path
from collections import defaultdict, Counter
import argparse
import gzip
import hashlib
import json
import numpy as np


def read(path: Path) -> dict:
    """
    機能: 平文又はgzipJSONを読む。
    引数: path(Path)。返り値: dict。
    """
    with (gzip.open(path,'rt',encoding='utf-8') if path.suffix=='.gz' else path.open('r',encoding='utf-8')) as source:
        return json.load(source)


def sha(path: Path) -> str:
    """
    機能: SHA256を逐次計算する。
    引数: path(Path)。返り値: str。
    """
    digest=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1<<20),b''):
            digest.update(block)
    return digest.hexdigest()


def first(mask: np.ndarray) -> int | None:
    """
    機能: 真値の初位置を得る。
    引数: mask(np.ndarray[bool])。返り値: int又はNone。
    """
    found=np.flatnonzero(mask)
    return int(found[0]) if len(found) else None


def main() -> None:
    """
    機能: 837固定入口の10旧時計/幅を全Quoteまで照合し、旧IFD集計を確認する。
    引数: CLI input/manifest/expected/output(Path)。返り値: None。
    """
    parser=argparse.ArgumentParser()
    for name in ('input','manifest','expected','output'):
        parser.add_argument(name,type=Path)
    args=parser.parse_args()
    assert not args.output.exists()
    fixed,manifest,expected=read(args.input),read(args.manifest),read(args.expected)
    assert expected['成功'] and expected['固定入口SHA256']==sha(args.input)
    lookup={(r['session'],r['case_id']):r for r in expected['cases']}
    groups=defaultdict(list)
    checked=0
    for scene,tape in zip(fixed['scenes'],manifest['scenes'],strict=True):
        path=args.manifest.parent/tape['tape']['path']
        assert sha(path)==tape['tape']['sha256']
        with gzip.open(path,'rt',encoding='utf-8') as source:
            quotes=[json.loads(line) for line in source]
        quote_index={q['source_line']:i for i,q in enumerate(quotes)}
        for case in scene['cases']:
            old=lookup[(scene['session'],case['id'])]
            entry=case['entry']
            at=quote_index[entry['source_line']]
            assert quotes[at]==entry
            post=quotes[at+1:]
            t=np.array([q['time'] for q in post])
            ok=np.array([q['quote_ok'] and 0<q['bid']<q['ask'] for q in post])
            points=case['side']*(np.array([q['bid' if case['side']==1 else 'ask'] for q in post])-case['entry_price'])
            previous=np.r_[entry['time'],t[:-1]]
            previous_normal=np.r_[entry['time'],np.maximum.accumulate(np.where(ok,t,entry['time']))[:-1]]
            for old_h in old['outcomes']:
                seconds=old_h['seconds']
                deadline=entry['time']+seconds
                unsafe=((t-previous>300)&(previous<deadline))|((t-previous_normal>300)&(previous_normal<deadline))|(t>deadline+30)
                stop=first(unsafe)
                if stop is None:
                    stop=len(post)
                valid=ok&(np.arange(len(post))<stop)
                endpoint=first(valid&(t>=deadline))
                complete=endpoint is not None
                assert complete==(old_h['status']=='complete'),(scene['session'],case['id'],seconds,'完了')
                if complete:
                    assert post[endpoint]==old_h['endpoint']
                for touch in old_h['touches']:
                    width=touch['width']
                    hit=first(valid&(t<=deadline)&((points>=width)|(points<=-width)))
                    direction=0 if hit is None else 1 if points[hit]>=width else -1
                    assert direction==touch['direction'],(case['id'],seconds,width,'方向')
                    assert (None if hit is None else post[hit])==touch['quote']
                    if seconds==3600 and width==125:
                        exit_q=post[hit] if hit is not None else post[endpoint] if complete else None
                        yen=None if exit_q is None else (case['side']*(exit_q['bid' if case['side']==1 else 'ask']-case['entry_price'])*100-1077)
                        for member in case['memberships']:
                            groups[member['policy']].append((complete,direction,yen))
                    checked+=1
        print(json.dumps({'場':scene['session'],'旧対照照合':checked},ensure_ascii=False),flush=True)
    assert checked==837*10
    summary={}
    for base,rows in groups.items():
        counts=Counter(d if complete else 'C' for complete,d,yen in rows)
        money=[yen for complete,d,yen in rows if yen is not None]
        summary[base]={'全件':len(rows),'順行':counts[1],'逆行':counts[-1],'未到達':counts[0],
            '観測不足':counts['C'],'先着率':counts[1]/(counts[1]+counts[-1]),
            'IFD利益円':sum(max(0,yen) for yen in money),'IFD損失円':-sum(min(0,yen) for yen in money),
            'IFD差引円':sum(money),'金額未知':len(rows)-len(money)}
    assert summary['153U15']=={'全件':93,'順行':46,'逆行':18,'未到達':22,'観測不足':7,
        '先着率':46/64,'IFD利益円':604611,'IFD損失円':337541,'IFD差引円':267070,'金額未知':3}
    assert summary['152U0']=={'全件':831,'順行':442,'逆行':280,'未到達':78,'観測不足':31,
        '先着率':442/722,'IFD利益円':5567808,'IFD損失円':4209871,'IFD差引円':1357937,'金額未知':12}
    result={'成功':True,'試行':157,'旧時計対照照合':checked,'作者観測関数の利用':False,
        '旧H60幅125':summary,'入力SHA256':sha(args.input),'テープ確認SHA256':sha(args.manifest),
        '保存対照SHA256':sha(args.expected),'検算器SHA256':sha(Path(__file__))}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':
    main()
