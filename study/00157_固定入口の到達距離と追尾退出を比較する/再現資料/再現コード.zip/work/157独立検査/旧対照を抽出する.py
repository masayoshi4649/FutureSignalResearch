"""148の保存観測から157固定837入口の旧H30/H60対照だけを抽出する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
HELPER = ROOT/'work/157固定入口の準備/schemaを確認する.py'
SPEC = importlib.util.spec_from_file_location('saved_reader157',HELPER)
READER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(READER)


def main() -> None:
    """
    機能: 既保存の正本と固定入口を結び、旧対照のみ新規gzipへ残す。
    引数: CLI input/output(Path)。返り値: None。Raw・新出口は再生しない。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('input',type=Path)
    parser.add_argument('output',type=Path)
    args=parser.parse_args()
    assert not args.output.exists()
    source=json.loads(args.input.read_bytes())
    targets={(s['session'],c['id']):c for s in source['scenes'] for c in s['cases']}
    assert len(targets)==837
    evidence,rows={},[]
    observed=ROOT/READER.INPUTS['148保存観測'][0]
    assert READER.sha(observed)==READER.INPUTS['148保存観測'][1]
    for scene in READER.scenes(observed,evidence):
        for case in scene['cases']:
            key=(scene['session'],case['id'])
            if key not in targets:
                continue
            fixed=targets[key]
            stream=case[fixed['stream']]
            assert stream['entry']==fixed['entry'] and stream['entry_price']==fixed['entry_price']
            assert stream['birth']['side']==fixed['side']
            rows.append({'session':key[0],'case_id':key[1],'side':fixed['side'],
                'memberships':[m['policy'] for m in fixed['memberships']],
                'outcomes':stream['outcomes']})
    assert len(rows)==837 and evidence['decoded_sha256']==READER.INPUTS['148保存観測'][2]
    result={'成功':True,'試行':157,'元試行':148,'固定入口SHA256':READER.sha(args.input),
        '保存観測SHA256':READER.sha(observed),'保存観測の検査':evidence,
        '抽出器SHA256':READER.sha(Path(__file__)),'読取補助SHA256':READER.sha(HELPER),'cases':rows}
    body=(json.dumps(result,ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n').encode()
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_bytes(gzip.compress(body,mtime=0))
    print(json.dumps({'成功':True,'全件':len(rows),'bytes':args.output.stat().st_size,
        'SHA256':READER.sha(args.output)},ensure_ascii=False))


if __name__=='__main__':
    main()
