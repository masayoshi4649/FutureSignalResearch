"""作者FSMを使わず、配列の先頭条件成立で157出口を独立検算する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import numpy as np


def sha(path: Path) -> str:
    """
    機能: ファイルのSHA256を逐次計算する。
    引数: path(Path)。返り値: str。
    """
    digest=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1<<20),b''):
            digest.update(block)
    return digest.hexdigest()


def read(path: Path) -> dict:
    """
    機能: 平文又はgzipJSONを全読する。
    引数: path(Path)。返り値: dict。
    """
    with (gzip.open(path,'rt',encoding='utf-8') if path.suffix=='.gz'
          else path.open('r',encoding='utf-8')) as source:
        return json.load(source)


def first(mask: np.ndarray) -> int | None:
    """
    機能: 配列条件が初成立する位置を返す。
    引数: mask(np.ndarray[bool])。返り値: int又はNone。
    """
    hits=np.flatnonzero(mask)
    return int(hits[0]) if len(hits) else None


def inspect_case(case: dict, scene: dict, quotes: list[dict], results: list[dict]) -> int:
    """
    機能: 前方累積峰と最初の障壁交差から全96出口を独立検算する。
    引数: case/scene(dict)、quotes/results(list[dict])。返り値: intは検算数。
    """
    entry=case['entry']
    pos=next(i for i,q in enumerate(quotes) if q['source_line']==entry['source_line'])
    assert quotes[pos]==entry
    post=quotes[pos+1:]
    t=np.array([q['time'] for q in post])
    normal=np.array([q['quote_ok'] and 0<q['bid']<q['ask'] for q in post],dtype=bool)
    if not post:
        for result in results:
            assert result['status']=='unknown' and result['profit_points'] is None and result['profit_yen'] is None
            assert result['fill'] is None
        return len(results)
    gain=case['side']*(np.array([q['bid' if case['side']==1 else 'ask'] for q in post])-case['entry_price'])
    previous_t=np.r_[entry['time'],t[:-1]]
    normal_times=np.maximum.accumulate(np.where(normal,t,entry['time']))
    previous_normal=np.r_[entry['time'],normal_times[:-1]]
    unsafe=(t-previous_t>300)|(t-previous_normal>300)
    cut=first(unsafe)
    if cut is None:
        cut=len(post)
    safe=np.arange(len(post))<cut
    marked=np.where(normal,gain,-np.inf)
    peaks=np.maximum.accumulate(np.maximum(0,marked))
    previous_peak=np.r_[0,peaks[:-1]]
    entry_g=case['side']*(entry['bid' if case['side']==1 else 'ask']-case['entry_price'])
    lasts=np.r_[entry['last'],np.array([q['last'] for q in post])]
    last_high=np.maximum.accumulate(lasts)
    last_low=np.minimum.accumulate(lasts)
    count=0
    for result in results:
        p=result['policy']
        deadline=min(scene['force_close'],entry['time']+3600) if result['horizon']=='H60' else scene['force_close']
        assert deadline==result['deadline']
        fee=1077 if result['cost']=='C5' else 77
        assert result['fee_yen']==fee
        sl=75 if p=='F125S75' else 100 if p=='F125S100' else 250 if p=='F250S250' else 125
        tp=125 if p.startswith('F125') else 250 if p.startswith('F250') or p.endswith('TP250') else None
        stop=np.full(len(post),-sl,dtype=float)
        if p=='T0W125':
            stop=np.maximum(stop,previous_peak-125)
        elif not p.startswith('F'):
            arm=(100*previous_peak-fee>0) if p=='E0W125' else previous_peak>=(50 if p=='T50W100' else 125)
            width=75 if p=='T125W75' else 125 if p in ('E0W125','T125W125') else 100
            stop=np.where(arm,np.maximum(0,previous_peak-width),stop)
        hit_stop=normal&(gain<=stop)&(t<deadline)&safe
        hit_tp=normal&(gain>=tp)&(t<deadline)&safe if tp is not None else np.zeros(len(post),dtype=bool)
        stop_at=first(hit_stop)
        tp_at=first(hit_tp)
        event=min((i for i in (stop_at,tp_at) if i is not None),default=None)
        reason='stop' if event is not None and event==stop_at else 'take_profit'
        trigger_time=post[event]['time'] if event is not None else deadline
        candidate=normal&safe&(t>=trigger_time+(1 if result['delay']=='D1' else 0))&(t<=trigger_time+30)
        if event is not None:
            candidate&=np.arange(len(post))>=event+(1 if result['delay']=='D1' else 0)
        else:
            reason='deadline'
        fill=first(candidate)
        status='closed' if fill is not None else 'unknown'
        assert result['status']==status,(scene['session'],case['id'],result['config_id'],'status',result['status'],status)
        if fill is not None:
            q=post[fill]
            assert result['fill']==q,(case['id'],result['config_id'],'fill')
            assert result['profit_points']==gain[fill]
            assert result['profit_yen']==100*gain[fill]-fee
            assert result['trigger']['time']==trigger_time
            assert result['trigger']['reason']==reason
            if event is not None:
                assert result['trigger']['quote']==post[event]
                if reason=='stop':
                    assert result['trigger']['stop_points']==stop[event]
            assert result['peak_points']==peaks[fill]
            low=min(0,entry_g,float(np.min(gain[:fill+1][normal[:fill+1]])))
            assert result['trough_points']==low
            positive=bool(np.any(100*gain[:fill+1][normal[:fill+1]]-fee>0))
            reached=bool(np.any(gain[:fill+1][normal[:fill+1]]>=125))
            assert result['positive_seen']==positive and result['reached125']==reached
            assert result['profit_after_positive_loss']==(positive and result['profit_yen']<0)
            assert result['profit_after125_loss']==(reached and result['profit_yen']<0)
            assert result['giveback_points']==peaks[fill]-gain[fill]
            # 退出予約後に見た上昇を追尾起動へ遡及しない。
            eligible=normal&safe&(t<trigger_time)
            if event is not None:
                eligible=np.arange(len(post))<event
                eligible&=normal&safe
            arm_level=fee/100 if p=='E0W125' else 50 if p=='T50W100' else 125
            armed=False if p.startswith('F') else bool(np.any((100*gain-fee>0 if p=='E0W125' else gain>=arm_level)&eligible))
            assert result['armed']==armed,(case['id'],result['config_id'],'armed')
            o=result['last_ohlc']
            assert o['count']==fill+2 and o['open']==entry['last'] and o['close']==q['last']
            assert o['high']==last_high[fill+1] and o['low']==last_low[fill+1]
        else:
            assert result['profit_points'] is None and result['profit_yen'] is None and result['fill'] is None
        count+=1
    return count


def main() -> None:
    """
    機能: 価格テープ全指紋・837入口・96条件を作者関数なしで照合する。
    引数: CLI input/manifest/result/output(Path)。返り値: None。
    """
    parser=argparse.ArgumentParser()
    for key in ('input','manifest','result','output'):
        parser.add_argument(key,type=Path)
    args=parser.parse_args()
    assert not args.output.exists()
    before={str(p.resolve()):sha(p) for p in (args.input,args.manifest,args.result)}
    fixed,manifest,result=read(args.input),read(args.manifest),read(args.result)
    assert fixed['success'] and manifest['success'] and result['success']
    assert len(fixed['scenes'])==len(manifest['scenes'])==len(result['scenes'])==73
    checked=0
    for s,m,r in zip(fixed['scenes'],manifest['scenes'],result['scenes'],strict=True):
        assert s['session']==m['session']==r['session']
        tape=args.manifest.parent/m['tape']['path']
        assert sha(tape)==m['tape']['sha256']
        decoded=hashlib.sha256()
        quotes=[]
        with gzip.open(tape,'rb') as source:
            for line in source:
                decoded.update(line)
                quotes.append(json.loads(line))
        assert decoded.hexdigest()==m['tape']['decoded_sha256'] and len(quotes)==m['tape']['rows']
        assert all(q['time']<s['continuous_end'] for q in quotes)
        cases={c['id']:c for c in r['cases']}
        for c in s['cases']:
            assert cases[c['id']]['entry']==c['entry']
            expected={(p,h,d,k) for p in ('F125S75','F125S100','F125S125','F250S125','F250S250',
                'T0W125','E0W125','T50W100','T125W75','T125W100','T125W125','T125W100TP250')
                for h in ('H60','SESSION') for d in ('D0','D1') for k in ('C0','C5')}
            actual=cases[c['id']]['results']
            assert len(actual)==96 and {(x['policy'],x['horizon'],x['delay'],x['cost']) for x in actual}==expected
            assert all(x['config_id']=='/'.join((x['policy'],x['horizon'],x['delay'],x['cost'])) for x in actual)
            checked+=inspect_case(c,s,quotes,cases[c['id']]['results'])
        print(json.dumps({'場':s['session'],'累計条件':checked},ensure_ascii=False),flush=True)
    assert checked==837*96
    assert before=={str(p.resolve()):sha(p) for p in (args.input,args.manifest,args.result)}
    proof={'成功':True,'試行':157,'検算条件数':checked,'全場':73,'作者FSMの利用':False,
        '方式':'前方累積峰・先頭障壁交差の配列計算','入力':before,
        '検算器SHA256':sha(Path(__file__)),'numpy':np.__version__}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':
    main()
