# 固定入口の復元と出口再生の準備調査

2026-11-12。Root指定の153 U15全93件と**152 U0全831件**を、恒久選択gzip→148固定取得→保存BBO観測で全件結合できた。152 U1全697件は使っていない。924は政策への所属数で、物理caseは837、共通は旧C1の87である。新しい入口選択・出口損益・原板再生・正式コピー・157採番は実行していない。156の探索も再開していない。

[schema確認票](schemaの確認.json)に全4入力の物理/解凍SHA、73場の原板path/指紋/品質宣言、全924所属の照合件数を残した。大入力と全入口の数値表は複写していない。保存観測は842,954,472解凍bytesを場単位に読んでCRC/全解凍SHAを確認しただけで、新たな先着/損益を計算していない。

## 最小schema

|役割|必須項目・復元元|
|---|---|
|固定された政策所属|policy、元selectionの全JSON値を保持する`source_selection_ref`。case_id/session/side/streamを再選択しない|
|物理case|148固定の`scenes[].entries`からsession+idで一意結合し、`source_fixed_entry`の全JSON値を保持する|
|実取得|`entry_quote`全8項目=clock/time/index/source_line/last/bid/ask/quote_ok。出生特徴q0でなく、固定取得q1のQuote|
|方向と価格|`original_side`は148case側、`selected_side`は元政策側。stream=originalなら同符号、reverseなら反対。買Ask/売Bidが`entry_price`|
|場と再生|session/contract/start/end/source_force_close/execution_end=End−300、Raw参照全JSON値、expected_accepted/expected_quality|

観測の`case[stream].birth.side/entry/entry_price`を固定Quoteへ全値照合済み。`original`という文字を買いと解釈しない。元側売caseではoriginalの入口はBid、reverseはAskとなる。153 U15のstream/側はoriginal売46・original買44・reverse売3、152 U0はoriginal売46・original買229・reverse売556だった。方向/取得時刻/実側価格を変更する必要はない。

原選択・固定entry・Raw参照の未知キーも失わないため、将来の小型固定入力は元JSON値のdeepcopyを併記する。int64のmtime_ns等をfloatへ通さない。同じ837物理caseを一走査で配信しても、二政策の別状態/全924所属は分ける。共通87を独立924件へ水増しした説明はしない。

最初の検査は11/09 Day等の固定Rawにあるbytes/mod_time_nsが133 Go FileRefで省略される差で停止した。検査器のみpath/sha256/actualSHAの比較へ合わせた。固定側Rawの全値は保持し、入力や価格は変更していない。

## 保存済み148観測で分かる範囲

[133固定評価器](../133固定取得の正逆評価器/README.md)はH30/H60×同幅25/50/100/125/200を保存する。各widthは最初にどちらが到達したかを示すdirectionとQuote1個、各Hはstatus/endpoint/points等で、入口後の全原行経路ではない。

したがって旧幅・Hの固定対照は保存観測を再利用できるが、**250pt以上、最初到達後の上下順序、原行ごとの追尾、H60後や場末までの退出**は再計算できない。125到達後に利幅がどれだけ伸びたか、何度戻ったかも推定しない。1分OHLCからBBO経路や高安順序を補間して代用しない。

## 適切な再生の土台

一番直接的なのは[133 entry.go](../133固定取得の正逆評価器/entry.go)の`scan133`と[reader.go](../133固定取得の正逆評価器/reader.go)の`decodeRow`を、新157の私有Sourceへ由来付きで再用する案である。現物の133/148を変更しない。

1. 148固定表から全73場のRaw path/SHA/品質を引く。保存gzipの選択を再生せず、対象837 caseの取得source_lineで保存Quote全値と採用indexを照合する。
2. 取得前は出口状態を作らず、取得後のaccepted原行だけを活動中のケースへ配信する。両政策の状態は独立。新たなSourceの出生/取得/TTL/方向判定を再実行しない。
3. 全原板のSHA/stat/限月/品質件数・gzip CRCを検証してから成功とする。`rawStream133`はgzip magic/非圧縮を扱える。全Rawは終了後も指紋のため完読するが、ザラバ外の価格を退出へ使わない。
4. 250以降の固定利確だけなら新幅を新Sourceへ加える。追尾にはaccepted Quoteを順に受ける純出口状態と約定待機状態を追加し、保存touchの差替えでは済ませない。実行契約の固定後にのみ原板再走査を行う。

旧[116 runtime](../116保有根拠の連続比較/runtime.go)は保護/予約/保有の順序を検討する参考になるが、元Source111通知・複数口座・可変数量・チャート配送等へ依存し、今回の固定入口をそのまま渡す最小APIではない。必要な純保護式/非緩和/約定待ちだけを明示選択して再用すべきで、旧36口座の条件を自動継承しない。

147の[KnownBar/Context](../147中位位置からの実体回復/types.go)は1分足の初知Quoteや当時背景の証拠で、全accepted BBO tickではない。147 Sourceから全取得後の原行順序を戻すことはできず、Raw再生の代わりにはならない。新出口が確定足技術も必要なら147/122の足・公表情報を別用途で参照できるが、その採否時計は別途固定する。

## 継承する時計と未決契約

133はCurrentPriceTimeを価格時計Timeとし、同時刻を採用index/物理source_lineで順序付ける。実受信時刻へ読み替えない。場外・価格時計後退・Last不正を除外し、BBO不正常行は品質として残す。正常BBOは正Bid<Ask。買い保有の清算側はBid、売りはAskで、Lastは価格参考である。[データ仕様](../../docs/データと閲覧形式.md)の時計/ザラバ/板寄せ制限を継承する。

[outcome133](../133固定取得の正逆評価器/outcome.go)は取得行自身をtouchへ使わず、gap>300秒/BBO gap>300秒、H期限+30秒を超えたendpoint、EOFを未知へ分ける。[phaseCut133](../133固定取得の正逆評価器/phase.go)は**Time>=End−300を価格・gap評価より先に打切り**、既知touchを保持する。Day15:40/Night05:55以降の正常BBOをザラバ退出へ流さない。

これらは旧観測の契約であり、157の追尾/場末約定をまだ決めていない。場末直前のどの正常原行で清算するか、終端未観測・欠測・気配不正の扱い、トリガー行と実行行、同原行で起動/引上げ/決済する順序、初期損切り/建値床/利益保護の条件と費用はRoot仕様で固定する必要がある。旧phase_censoredを仮の確定清算価格へ変えたり、終端後の最初正常価格へ補完したりしない。

## 調査の再現

```powershell
python -X utf8 'work/157固定入口の準備/人工検査.py'
python -X utf8 'work/157固定入口の準備/schemaを確認する.py' --check-saved-only
```

2主人工は元売のstream/BBO、全値精度、非改変、不一致/Last参考拒否を確認する。schema確認は既存4gzipだけを読み、新出力の確認票がある場合は上書きしない。Rootが正式コピーを通知するまで恒久入力や正式試行を作らない。旧156/155以前のSourceと正式資料は不変更である。
