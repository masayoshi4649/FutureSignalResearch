"""既存の固定入口・保存観測だけから157候補の取得復元schemaを確認する。"""
from pathlib import Path
from collections import Counter
import argparse
import gzip
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
INPUTS = {
    '153U15': ('inputs/00153_先行高安の独立出生/選択対応.json.gz',
        '3ffdab0cfd846e250473206b2e55c9cd45a8b18e1c9a73285537319aa1e99334',
        'bf5a29225a69e4e8837df9d8b34f263adb59f43ee70908e7668cc35a1a97a758'),
    '152U0': ('inputs/00152_複合回復の方向切替/選択対応.json.gz',
        '8f7815505f3a0bc158d738a128df1b7d9a140455aa5178ba7f1b8b1eb447032b',
        'd77fcb20976b6207039e31912058894fdf1cc31c7aaae604739df82d2d74110c'),
    '148固定取得': ('inputs/00148_全1分入口母集団/固定取得入力.json.gz',
        '99f10a996ca6e8b6c428061f1b48624bbc479ec84c500a9633818d47e4298e2a',
        '12c43fe60e0ffd5ffa44bec7b5f7dd3d60bb92b291e0008db23587dcf19536d3'),
    '148保存観測': ('study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz',
        'bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61',
        'd1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'),
}


def sha(path: Path) -> str:
    """
    機能: 共有入力を複写せず物理SHAを計算する。
    引数: path(Path)。返り値: str。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def read_small(name: str) -> dict:
    """
    機能: 既存選択/固定表だけを物理解凍指紋とCRC検査後に読む。
    引数: name(str)。返り値: dict。Raw/新特徴/戦略は読まない。
    """
    relative, physical, decoded = INPUTS[name]
    path = ROOT / relative
    assert sha(path) == physical
    body = gzip.decompress(path.read_bytes())
    assert hashlib.sha256(body).hexdigest() == decoded
    return json.loads(body)


def scenes(path: Path, evidence: dict):
    """
    機能: 保存観測を1場ずつ読むことで全原行や巨大JSONの副本を作らない。
    引数: path(Path)、evidence(dict)。返り値: Iterator[dict]。
    """
    digest, size, buffer, decoder = hashlib.sha256(), 0, '', json.JSONDecoder()
    with gzip.open(path, 'rt', encoding='utf-8', newline='') as source:
        def more() -> str:
            """
            機能: UTF8を保持した解凍chunkを全指紋へ加える。
            引数: なし。返り値: str。
            """
            nonlocal size
            body = source.read(1 << 20)
            raw = body.encode('utf-8')
            digest.update(raw)
            size += len(raw)
            return body

        while True:
            body = more()
            assert body, 'scenes配列がない'
            buffer += body
            match = re.search(r'(?m)^  "scenes": \[', buffer)
            if match:
                buffer = buffer[match.end():]
                break
        while True:
            buffer = buffer.lstrip()
            if buffer.startswith(']'):
                break
            if buffer.startswith(','):
                buffer = buffer[1:].lstrip()
            try:
                scene, end = decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                body = more()
                assert body, 'scenes途中終了'
                buffer += body
                continue
            yield scene
            buffer = buffer[end:]
        while more():
            pass
    evidence.update(decoded_sha256=digest.hexdigest(), decoded_bytes=size, gzip_full_crc_checked=True)


def restore_reference(reference: dict, scene: dict, fixed: dict, observed: dict) -> dict:
    """
    機能: 保存されたside/streamを固定Quoteと観測の実BBO入口へ一意に結ぶ。
    引数: reference/scene/fixed/observed(dict)。返り値: dictは最小復元DTO。
    """
    assert reference['session'] == scene['session'] and reference['case_id'] == fixed['id'] == observed['id']
    side, stream = reference['side'], reference['stream']
    assert type(side) is int and side in (-1, 1) and stream in ('original', 'reverse')
    assert fixed['side'] == observed['original_side']
    assert side == fixed['side'] * (1 if stream == 'original' else -1)
    candidate = observed[stream]
    assert candidate['status'] == 'filled' and candidate['axis'] == 'BBO'
    quote = fixed['entry']
    assert candidate['birth']['side'] == side and candidate['entry'] == quote == candidate['birth']['quote']
    assert candidate['birth']['time'] == quote['time'] and candidate['birth']['index'] == quote['index']
    assert candidate['birth']['source_line'] == quote['source_line']
    assert quote['quote_ok'] and 0 < quote['bid'] < quote['ask'] and quote['last'] > 0 and quote['clock']
    price = quote['ask' if side == 1 else 'bid']
    assert candidate['entry_price'] == price
    assert quote['time'] < min(scene['force_close'], scene['end']-3900)
    return {'case_id': fixed['id'], 'session': scene['session'], 'contract': scene['contract'],
        'original_side': fixed['side'], 'selected_side': side, 'selected_stream': stream,
        'entry_quote': quote, 'entry_price': price, 'source_selection_ref': reference,
        'source_fixed_entry': fixed, 'raw': scene['raw'], 'scene_start': scene['start'], 'scene_end': scene['end'],
        'source_force_close': scene['force_close'], 'execution_end': scene['end']-300,
        'expected_accepted': scene['expected_accepted'], 'expected_quality': scene['expected_quality']}


def main() -> None:
    """
    機能: 許可済み旧924所属の復元だけを全件確認し、小さいschema確認票を出す。
    引数: CLI --check-saved-only(bool)。返り値: None。正式コピー/Raw再生/新損益は行わない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--check-saved-only', action='store_true')
    args = parser.parse_args()
    assert args.check_saved_only
    output = HERE/'schemaの確認.json'
    assert not output.exists()
    before = {name: (sha(ROOT/ref[0]), (ROOT/ref[0]).stat().st_size, (ROOT/ref[0]).stat().st_mtime_ns) for name, ref in INPUTS.items()}
    assert all(before[name][0] == ref[1] for name, ref in INPUTS.items())
    selections = {}
    common_sessions = None
    for label, policy, trial, count in (('153U15', 'U15', 153, 93), ('152U0', 'U0', 152, 831)):
        value = read_small(label)
        assert value['成功'] and value['試行'] == trial and not value['選択時の金融ラベル利用']
        rows = value['政策'][policy]
        assert len(rows) == count == len({(row['session'], row['case_id']) for row in rows})
        sessions = value['全73場']
        assert len(sessions) == len(set(sessions)) == 73
        if common_sessions is None:
            common_sessions = sessions
        assert sessions == common_sessions
        selections[label] = {(row['session'], row['case_id']): row for row in rows}
    fixed = read_small('148固定取得')
    fixed_scenes = {scene['session']: scene for scene in fixed['scenes']}
    assert list(fixed_scenes) == common_sessions and len(fixed_scenes) == 73
    assert sum(len(scene['entries']) for scene in fixed_scenes.values()) == fixed['expected_entry_count'] == 31642
    targets = set().union(*(set(refs) for refs in selections.values()))
    found = {name: set() for name in selections}
    mappings = {name: Counter() for name in selections}
    fields = set()
    raw_metadata = []
    for scene in fixed_scenes.values():
        raw_metadata.append({'session': scene['session'], 'contract': scene['contract'], 'raw': scene['raw'],
            'start': scene['start'], 'end': scene['end'], 'force_close': scene['force_close'],
            'execution_end': scene['end']-300, 'expected_accepted': scene['expected_accepted'],
            'expected_quality': scene['expected_quality']})
    evidence, scene_count, case_count = {}, 0, 0
    widths, horizons = set(), set()
    for observed in scenes(ROOT/INPUTS['148保存観測'][0], evidence):
        scene_count += 1
        session = observed['session']
        assert session == common_sessions[scene_count-1] and observed['success']
        expected = fixed_scenes[session]
        assert all(observed['raw'][key] == expected['raw'][key] for key in ('path', 'sha256'))
        assert observed['actual_sha256'] == expected['raw']['sha256']
        assert observed['quality'] == expected['expected_quality'] and observed['source_entries'] == len(expected['entries'])
        assert observed['execution_end'] == expected['end']-300
        entries = {entry['id']: entry for entry in expected['entries']}
        assert len(entries) == len(expected['entries']) == len(observed['cases'])
        seen = set()
        for case in observed['cases']:
            case_count += 1
            key = (session, case['id'])
            assert case['id'] in entries and case['id'] not in seen
            seen.add(case['id'])
            if key not in targets:
                continue
            for label, refs in selections.items():
                if key not in refs:
                    continue
                dto = restore_reference(refs[key], expected, entries[case['id']], case)
                found[label].add(key)
                mappings[label][f"{dto['selected_stream']}:{dto['selected_side']:+d}"] += 1
                fields.update(dto)
                for outcome in case[dto['selected_stream']]['outcomes']:
                    horizons.add(outcome['seconds'])
                    widths.update(touch['width'] for touch in outcome['touches'])
    assert scene_count == 73 and case_count == 31642
    assert evidence['decoded_sha256'] == INPUTS['148保存観測'][2]
    assert all(found[name] == set(refs) for name, refs in selections.items())
    assert before == {name: (sha(ROOT/ref[0]), (ROOT/ref[0]).stat().st_size, (ROOT/ref[0]).stat().st_mtime_ns) for name, ref in INPUTS.items()}
    proof = {'成功': True, '用途': '157仕様固定前の既存schema調査のみ', '新試行自然_新損益_新戦略_全Raw走査': False,
        '正式コピー': False, '155以前及び156Source編集': False, '対象': {'153U15': 93, '152U0': 831},
        '152U1を使用': False, '全73場': 73, '保存観測全case読取': case_count,
        '政策所属総数': 924, '物理case一意数': len(targets), '政策間共有case': len(set.intersection(*(set(refs) for refs in selections.values()))),
        '全所属の実取得Quote_side_stream_entry_price一致': True, 'stream方向件数': {key: dict(value) for key, value in mappings.items()},
        '最小復元schema': sorted(fields), '旧全JSON値保存にはsource_selection_refとsource_fixed_entryもdeepcopyする': True,
        '148保存幅': sorted(widths), '148保存時間秒': sorted(horizons), '原行価格経路_250以上_場末追尾の保存': False,
        '初回schema差': '固定Rawのbytes/mod_time_nsをGo FileRefが省くため全dict比較で停止。path/sha256/actualを照合し、固定全Raw値は保存。元入力不変更。',
        'Raw参照は148固定表の全73だけ_本文未読': raw_metadata,
        '入力': {name: {'path': ref[0], '物理SHA256': ref[1], '解凍SHA256': ref[2], '物理bytes': before[name][1]} for name, ref in INPUTS.items()},
        '保存観測解凍とCRC': evidence, '全入力前後SHA_stat同体': True, '確認SourceSHA256': sha(Path(__file__))}
    output.write_bytes((json.dumps(proof, ensure_ascii=False, indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功': True, '政策所属': 924, '物理case': len(targets), '全73場': 73,
        '確認SHA256': sha(output)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
