"""157仕様前の固定入口schema調査を、小証跡だけで停止する。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 調査小源の物理SHAを得る。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 小人工と既存schema確認の成功を束縛し、Raw未読の範囲で停止票を作る。
    引数: なし。返り値: None。新戦略や自然損益を実行しない。
    """
    paths = sorted(p for p in HERE.iterdir() if p.is_file() and p.suffix in ('.py', '.md', '.json'))
    before = {p: sha(p) for p in paths}
    for p in HERE.glob('*.py'):
        for node in ast.walk(ast.parse(p.read_text(encoding='utf-8'))):
            if isinstance(node, ast.FunctionDef):
                doc = ast.get_docstring(node)
                assert doc and '\n' in doc and all(key in doc for key in ('機能', '引数', '返り値'))
    run = subprocess.run([sys.executable, '-X', 'utf8', str(HERE/'人工検査.py')], capture_output=True,
        env={**os.environ, 'PYTHONUTF8': '1', 'PYTHONIOENCODING': 'utf-8', 'PYTHONDONTWRITEBYTECODE': '1'})
    stdout, stderr = run.stdout.decode('utf-8', 'strict'), run.stderr.decode('utf-8', 'strict')
    assert run.returncode == 0
    result = json.loads((HERE/'schemaの確認.json').read_bytes())
    assert result['成功'] and result['政策所属総数'] == 924 and result['物理case一意数'] == 837
    assert not result['新試行自然_新損益_新戦略_全Raw走査'] and result['全入力前後SHA_stat同体']
    source_names = ['work/133固定取得の正逆評価器/entry.go', 'work/133固定取得の正逆評価器/reader.go',
        'work/133固定取得の正逆評価器/stream.go', 'work/133固定取得の正逆評価器/outcome.go',
        'work/133固定取得の正逆評価器/phase.go', 'work/147中位位置からの実体回復/types.go',
        'work/147中位位置からの実体回復/scanner.go', 'work/116保有根拠の連続比較/runtime.go',
        'work/116保有根拠の連続比較/entry_input.go', 'work/116保有根拠の連続比較/go.mod',
        'docs/データと閲覧形式.md', 'docs/議論/入口の評価時計と候補の出生を分ける.md']
    assert before == {p: sha(p) for p in paths}
    stop = {'成功': True, '編集停止': True, '目的': '固定入口の復元schemaと出口再生源の事前調査',
        '正式試行採番_恒久コピー_新戦略_新金融_Raw又は追加2場読取': False,
        '156探索の再開': False, '153U15': 93, '152U0': 831, '152U1使用': False,
        '政策所属総数': 924, '物理case数': 837, '共通旧C1': 87,
        '全所属実BBO_side_stream_Quote_価格の同体': True, '全73Rawの参照だけ保持_本文未読': True,
        '保存148の限界': 'H30/60・最大200の初touch/endpoint。250以降・全原行追尾・場末には原板再生が必要。',
        '再用候補': '133の固定取得scan/Quote/価格時計reader。純出口/約定状態は157仕様固定後に分離。',
        'schema確認SHA256': sha(HERE/'schemaの確認.json'),
        '2主人工': {'終了値': run.returncode, 'stdout': stdout, 'stderr': stderr},
        '参照コードDocs現物SHA256': {name: sha(ROOT/name) for name in source_names},
        '最小保存対象': [{'path': p.relative_to(ROOT).as_posix(), 'sha256': h, 'bytes': p.stat().st_size} for p, h in before.items()],
        '停止票自身も保存': True, '作者小源前後不変': True}
    target = HERE/'停止の確認.json'
    assert not target.exists()
    target.write_bytes((json.dumps(stop, ensure_ascii=False, indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功': True, '停止SHA256': sha(target), 'schema確認SHA256': stop['schema確認SHA256']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
