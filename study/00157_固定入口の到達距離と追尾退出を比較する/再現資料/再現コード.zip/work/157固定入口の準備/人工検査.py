"""157候補の最小復元だけを人工で確認する。"""
import copy
import importlib.util
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('schema157_fixture', HERE/'schemaを確認する.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def fixture() -> tuple:
    """
    機能: 元方向売のcaseに対して原/逆の実側価格を人工で用意する。
    引数: なし。返り値: tupleはref/scene/fixed/observed。
    """
    q = {'clock': '2026-01-01T09:00:00+09:00', 'time': 2000., 'index': 12, 'source_line': 15,
         'last': 100., 'bid': 99., 'ask': 101., 'quote_ok': True}
    fixed = {'id': '元売', 'side': -1, 'entry': q, '未知欄': {'値': 9007199254740993}}
    scene = {'session': '場', 'contract': '限月', 'start': 1000., 'end': 10000., 'force_close': 6000.,
             'raw': {'path': '人工未読', 'sha256': '0'*64}, 'expected_accepted': 1000, 'expected_quality': {}}
    ref = {'case_id': '元売', 'session': '場', 'side': -1, 'stream': 'original', '未知欄': {'値': [None, 1]}}
    observed = {'id': '元売', 'original_side': -1}
    for stream, side in (('original', -1), ('reverse', 1)):
        observed[stream] = {'status': 'filled', 'axis': 'BBO', 'entry': copy.deepcopy(q),
            'entry_price': q['ask' if side == 1 else 'bid'],
            'birth': {'side': side, 'time': q['time'], 'index': q['index'], 'source_line': q['source_line'], 'quote': copy.deepcopy(q)}}
    return ref, scene, fixed, observed


class Tests(unittest.TestCase):
    """採否や損益を作らない2主群。"""

    def test_元売のstreamと実BBO(self) -> None:
        """
        機能: 原側が売ならoriginalはBid、reverseはAskへ明示対応する。
        引数: self(Tests)。返り値: None。
        """
        ref, scene, fixed, observed = fixture()
        before = copy.deepcopy((ref, scene, fixed, observed))
        dto = m.restore_reference(ref, scene, fixed, observed)
        self.assertEqual(dto['entry_price'], 99.)
        self.assertEqual(dto['source_fixed_entry']['未知欄']['値'], 9007199254740993)
        self.assertEqual((ref, scene, fixed, observed), before)
        ref.update(side=1, stream='reverse')
        self.assertEqual(m.restore_reference(ref, scene, fixed, observed)['entry_price'], 101.)

    def test_不一致と参考Lastを拒否(self) -> None:
        """
        機能: side/stream/実価格/原行不一致とLast参考を入口へ流さない。
        引数: self(Tests)。返り値: None。
        """
        for field, value in (('side', 1), ('stream', 'chart_original')):
            ref, scene, fixed, observed = fixture()
            ref[field] = value
            with self.assertRaises(AssertionError):
                m.restore_reference(ref, scene, fixed, observed)
        for target, value in (('entry_price', 100.), ('entry', {}), ('axis', 'Last価格方向診断')):
            ref, scene, fixed, observed = fixture()
            observed['original'][target] = value
            with self.assertRaises(AssertionError):
                m.restore_reference(ref, scene, fixed, observed)


if __name__ == '__main__':
    unittest.main(verbosity=2)
