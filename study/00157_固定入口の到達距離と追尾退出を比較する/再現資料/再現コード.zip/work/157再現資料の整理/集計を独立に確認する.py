"""元出口を場単位に逐次読み、Rootの型付き二表を別集約で照合する。"""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction
from dataclasses import dataclass, field
import argparse
import gzip
import hashlib
import json
import math

POLICIES = {"F125S75", "F125S100", "F125S125", "F250S125", "F250S250", "T0W125", "E0W125", "T50W100", "T125W75", "T125W100", "T125W125", "T125W100TP250"}


def sha(path: Path) -> str:
    """物理SHAを逐次確認する。

    引数: path(Path)。返り値: str型のSHA256。
    """
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


class Reader:
    """gzip JSONのsceneだけを1件ずつ読む。全leafの副本を残さない。"""

    def __init__(self, source):
        """読取状態を作る。

        引数: source(TextIO)。返り値: None。
        """
        self.source, self.buffer, self.at = source, "", 0
        self.decoder, self.digest, self.size = json.JSONDecoder(), hashlib.sha256(), 0

    def more(self) -> bool:
        """未消費部分だけを保って次のchunkを読む。

        引数: なし。返り値: bool型の読取成否。
        """
        part = self.source.read(1 << 18)
        if not part:
            return False
        b = part.encode("utf-8")
        self.digest.update(b)
        self.size += len(b)
        self.buffer, self.at = self.buffer[self.at:] + part, 0
        return True

    def space(self) -> None:
        """空白を読み飛ばす。

        引数: なし。返り値: None。
        """
        while True:
            while self.at < len(self.buffer) and self.buffer[self.at].isspace():
                self.at += 1
            if self.at < len(self.buffer) or not self.more():
                return

    def token(self, value: str) -> None:
        """JSON構造文字を検査する。

        引数: value(str)。返り値: None。
        """
        self.space()
        assert self.buffer[self.at:self.at + 1] == value
        self.at += 1

    def value(self):
        """一つのJSON値を必要な分だけ読む。

        引数: なし。返り値: JSON値。
        """
        self.space()
        while True:
            try:
                value, end = self.decoder.raw_decode(self.buffer, self.at)
                self.at = end
                return value
            except json.JSONDecodeError:
                assert self.more(), "JSONが未完了"


def stream_scenes(path: Path, evidence: dict):
    """小さいヘッダとsceneを逐次読み全CRC/解凍SHAを確認する。

    引数: path(Path)、evidence(dict)。返り値: sceneのIterator。
    """
    with gzip.open(path, "rt", encoding="utf-8", newline="") as f:
        r = Reader(f)
        r.token("{")
        header = {}
        while True:
            key = r.value()
            r.token(":")
            if key == "scenes":
                break
            header[key] = r.value()
            r.token(",")
        assert header["success"] and header["trial"] == 157
        assert header["schema"] == "fixed_exit_results_v1"
        configs = header["configurations"]
        assert len(configs) == 96 and {x["policy"] for x in configs} == POLICIES
        evidence["header"] = {k: header[k] for k in ("scene_count", "case_count", "membership_count", "configuration_count")}
        evidence["configurations"] = configs
        r.token("[")
        while True:
            r.space()
            if r.buffer[r.at:r.at + 1] == "]":
                r.token("]")
                break
            yield r.value()
            r.space()
            if r.buffer[r.at:r.at + 1] == ",":
                r.token(",")
            else:
                r.token("]")
                break
        r.token("}")
        r.space()
        assert r.at == len(r.buffer) and not f.read(), "後続値がある"
        evidence["decoded_sha256"] = r.digest.hexdigest()
        evidence["decoded_bytes"] = r.size


def number(x) -> Fraction:
    """保存済み有限数値を十進有理数へ変換する。

    引数: x(int|float)。返り値: Fraction型。
    """
    assert type(x) in (int, float) and math.isfinite(x)
    return Fraction(str(x))


@dataclass
class Stats:
    n: int = 0
    unknown: int = 0
    wins: int = 0
    losses: int = 0
    zero: int = 0
    profit: Fraction = Fraction(0)
    loss: Fraction = Fraction(0)
    held: Fraction = Fraction(0)
    giveback: Fraction = Fraction(0)
    armed: int = 0
    after_positive: int = 0
    after125: int = 0
    events: dict = field(default_factory=lambda: defaultdict(Fraction))

    def add(self, row: dict) -> None:
        """1行の金額/診断を整数件数と有理数で加える。

        引数: row(dict)。返り値: None。
        """
        self.n += 1
        if row["status"] == "unknown":
            assert row["profit_yen"] is row["profit_points"] is row["fill"] is None
            self.unknown += 1
            return
        assert row["status"] == "closed" and row["fill"] is not None
        money, points, fee = map(number, (row["profit_yen"], row["profit_points"], row["fee_yen"]))
        assert abs(money - (100 * points - fee)) < Fraction(1, 10000000)
        self.profit += max(money, 0)
        self.loss -= min(money, 0)
        self.wins += money > 0
        self.losses += money < 0
        self.zero += money == 0
        self.held += number(row["held_seconds"])
        self.giveback += number(row["giveback_points"])
        self.armed += bool(row["armed"])
        self.after_positive += bool(row["profit_after_positive_loss"])
        self.after125 += bool(row["profit_after125_loss"])
        self.events[row["fill"]["time"]] += money

    def merge(self, other) -> None:
        """場ごとの集計値を統合する。

        引数: other(Stats)。返り値: None。
        """
        for key in self.__dataclass_fields__:
            if key != "events":
                setattr(self, key, getattr(self, key) + getattr(other, key))
        for at, value in other.events.items():
            self.events[at] += value

    def values(self) -> dict:
        """固定列の指標を別の代数式で求める。

        引数: なし。返り値: dict型。
        """
        known = self.n - self.unknown
        lower = upper = None
        if known:
            z = 1.959963984540054
            center = (self.wins + z * z / 2) / (known + z * z)
            radius = z * math.sqrt(self.wins * (known - self.wins) / known + z * z / 4) / (known + z * z)
            lower, upper = max(0, center - radius), min(1, center + radius)
        running = peak = drawdown = Fraction(0)
        for _, change in sorted(self.events.items()):
            running += change
            peak = max(peak, running)
            drawdown = max(drawdown, peak - running)
        net = self.profit - self.loss
        return {"取得数": self.n, "決済既知": known, "損益未知": self.unknown,
                "利益取引": self.wins, "損失取引": self.losses, "同額取引": self.zero,
                "利益総額円": self.profit, "損失総額円": self.loss, "既知差引円": net,
                "全件確定差引円": None if self.unknown else net,
                "PF": self.profit / self.loss if self.loss else None,
                "利益側金額比率": self.profit / (self.profit + self.loss) if self.profit + self.loss else None,
                "既知決済勝率": Fraction(self.wins, known) if known else None,
                "勝率参考95下限": lower, "勝率参考95上限": upper,
                "追尾起動既知": self.armed, "費用後正益後赤字": self.after_positive,
                "125順行後赤字": self.after125,
                "平均保有秒": self.held / known if known else None,
                "平均吐出しpt": self.giveback / known if known else None,
                "独立既知決済累計DD円": drawdown}


def equal(expected, actual, where: tuple) -> None:
    """null/整数/有限数値を型別に比較する。

    引数: expected/actual(JSON値)、where(tuple)。返り値: None。
    """
    if expected is None or isinstance(expected, str):
        assert expected == actual, (where, expected, actual)
    elif type(expected) is int:
        assert type(actual) in (int, float) and expected == actual, (where, expected, actual)
    else:
        assert type(actual) in (int, float) and math.isfinite(actual)
        assert math.isclose(float(expected), actual, rel_tol=1e-11, abs_tol=1e-7), (where, float(expected), actual)


def main() -> None:
    """生結果から二表を再構成し小票だけを保存する。

    引数: CLI result/tables/output(Path)。返り値: None。
    """
    parser = argparse.ArgumentParser()
    for key in ("result", "tables", "output"):
        parser.add_argument(key, type=Path)
    args = parser.parse_args()
    assert not args.output.exists()
    assert sha(args.result) == "58bf2b448c7ca465e3e9f20ab78f10106d6a2c7312784d939acd7ffff22d2338"
    assert sha(args.tables) == "b730b899e85d7455e2dd3b4fc711f77caedd2ba22e8a63918de0df4d0c79323e"
    before = {str(p): (sha(p), p.stat().st_size, p.stat().st_mtime_ns) for p in (args.result, args.tables)}
    tables = json.loads(args.tables.read_bytes())["tables"]
    scene_names, stats, paired, pairs_scene = [], {}, defaultdict(lambda: defaultdict(Fraction)), defaultdict(Fraction)
    evidence, physical, members, source_rows = {}, set(), defaultdict(set), 0
    for scene in stream_scenes(args.result, evidence):
        session = scene["session"]
        assert session not in scene_names
        scene_names.append(session)
        for case in scene["cases"]:
            key = (session, case["id"])
            assert key not in physical
            physical.add(key)
            rows = {(r["horizon"], r["delay"], r["cost"], r["policy"]): r for r in case["results"]}
            assert len(rows) == 96
            source_rows += len(rows)
            bases = [m["policy"] for m in case["memberships"]]
            assert len(bases) == len(set(bases))
            for base in bases:
                assert base in ("153U15", "152U0")
                members[base].add(key)
                for (horizon, delay, cost, policy), row in rows.items():
                    group = (base, horizon, delay, cost, policy, session)
                    stats.setdefault(group, Stats()).add(row)
                    control = rows[(horizon, delay, cost, "F125S125")]
                    if row["status"] == control["status"] == "closed":
                        a, b = number(row["profit_yen"]), number(control["profit_yen"])
                        p = paired[group]
                        p["IFD対応既知件数"] += 1
                        p["対応既知IFD差分円"] += a - b
                        p["対応利益総額差分円"] += max(a, 0) - max(b, 0)
                        p["対応損失総額差分円"] += max(-a, 0) - max(-b, 0)
                        p["IFDより改善件数"] += a > b
                        p["IFDより悪化件数"] += a < b
                        pairs_scene[group] += a - b
        print(json.dumps({"場": len(scene_names), "物理case": len(physical)}, ensure_ascii=False), flush=True)
    assert len(scene_names) == 73 and len(physical) == 837 and source_rows == 80352
    assert {k: len(v) for k, v in members.items()} == {"153U15": 93, "152U0": 831}
    count, numeric = 0, 0
    for table_name, table in tables.items():
        headers, rows = table["headers"], table["rows"]
        assert len(headers) == len(set(headers))
        seen = set()
        cumulative, cumulative_unknown = defaultdict(Fraction), defaultdict(int)
        for raw in rows:
            assert len(raw) == len(headers)
            actual = dict(zip(headers, raw, strict=True))
            prefix = tuple(actual[k] for k in ("入口", "保有期限", "約定代用", "費用", "出口"))
            if table_name == "出口比較":
                scope = actual["区間"]
                selected = scene_names if scope == "全73場" else scene_names[:48] if scope == "前48場" else scene_names[48:] if scope == "後25場" else None
                assert selected is not None
                total, control, pair = Stats(), Stats(), defaultdict(Fraction)
                good = bad = 0
                for session in selected:
                    g = (*prefix, session)
                    total.merge(stats.get(g, Stats()))
                    control.merge(stats.get((*prefix[:4], "F125S125", session), Stats()))
                    for k, v in paired[g].items():
                        pair[k] += v
                    good += pairs_scene[g] > 0
                    bad += pairs_scene[g] < 0
                expected = total.values()
                expected.update({"IFD利益総額円": control.profit, "IFD損失総額円": control.loss,
                                 "IFD既知差引円": control.profit - control.loss, "IFD損益未知": control.unknown,
                                 "IFD対応既知件数": pair["IFD対応既知件数"],
                                 "IFD対応損益未知": total.n - pair["IFD対応既知件数"],
                                 "対応既知改善場数": good, "対応既知悪化場数": bad})
                for k in ("対応既知IFD差分円", "対応利益総額差分円", "対応損失総額差分円", "IFDより改善件数", "IFDより悪化件数"):
                    expected[k] = pair[k]
                row_id = (*prefix, scope)
            else:
                assert table_name == "全セッション"
                session = actual["セッション"]
                group = (*prefix, session)
                item = stats.get(group, Stats())
                cumulative[prefix] += item.profit - item.loss
                cumulative_unknown[prefix] += item.unknown
                expected = {k: v for k, v in item.values().items() if k in headers}
                expected.update({"累計既知差引円": cumulative[prefix], "累計損益未知": cumulative_unknown[prefix],
                                 "全件確定累計円": cumulative[prefix] if not cumulative_unknown[prefix] else None})
                row_id = group
            assert row_id not in seen
            seen.add(row_id)
            assert set(expected) == set(headers[6:]), (table_name, set(expected) ^ set(headers[6:]))
            for k, v in expected.items():
                equal(v, actual[k], (table_name, row_id, k))
                numeric += v is not None
            count += len(headers)
        assert len(rows) == (576 if table_name == "出口比較" else 14016)
    after = {str(p): (sha(p), p.stat().st_size, p.stat().st_mtime_ns) for p in (args.result, args.tables)}
    assert before == after
    proof = {"成功": True, "試行": 157, "役割": "出口FSM作者によるRoot集計の別集約照合。FSM自体の独立検算とは別", "Root集計関数import": False,
             "全73場": 73, "物理case": 837, "所属": 924, "元出口状態": source_rows,
             "要約行": 576, "場行": 14016, "比較全セル": count, "比較数値null以外": numeric,
             "検査": ["N/既知/未知/利益損失差引", "同case F125S125全対応差分と改善悪化", "全73/前48/後25", "全73場累計と未知後null", "同時刻合算DD/保有/吐出し/起動/赤字旗", "参考Wilson区間", "全gzipCRC/解凍SHA/入力前後指紋"],
             "生結果の解凍": {k: evidence[k] for k in ("decoded_sha256", "decoded_bytes")},
             "源": before, "本コードSHA256": sha(Path(__file__)), "自然再生": False, "新条件": False}
    args.output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "path": str(args.output), "SHA256": sha(args.output)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
