"""第157の小さい再現源だけを元相対配置でZIP保存する。自然再生はしない。"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import datetime
import hashlib
import json
import subprocess
import zipfile
import zlib

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / "study/00157_固定入口の到達距離と追尾退出を比較する"
OUTPUTS = ROOT / "outputs/01a1889f-f2af-7943-a047-543275ee9ed2/00157_出口比較"
MODULES = ["157固定入口と価格経路", "157出口政策の再生", "157到達距離の診断"]


def sha(path: Path) -> str:
    """小さい源の物理SHAを求める。

    引数: path(Path)。返り値: str型。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """全停止源を格納してCRC/復元配置/構文を検査する。

    引数: なし。返り値: None。Raw・金融・CSVを再生成しない。
    """
    target = FORMAL / "再現資料/再現コード.zip"
    ticket = FORMAL / "検査/再現コードの保存確認.json"
    assert not target.exists() and not ticket.exists()
    selected = {}

    def add(path: Path, archive: str | None = None) -> None:
        """明示源を1回だけallowlistへ加える。

        引数: path(Path)、archive(str|None)。返り値: None。
        """
        assert path.is_file() and path.stat().st_size < 250000, path
        name = archive or path.relative_to(ROOT).as_posix()
        assert not any(x in ("..", "node_modules", "__pycache__", "cache") for x in Path(name).parts)
        assert Path(name).suffix not in (".exe", ".dll", ".gz", ".csv", ".png", ".pyc")
        if name in selected:
            assert selected[name].read_bytes() == path.read_bytes()
        selected[name] = path

    proof_names = {
        "157固定入口と価格経路": ["133からの由来.json", "準備の確認.json", "停止の確認.json", "入力抽出の確認_最終.json"],
        "157出口政策の再生": ["準備の確認.json"],
        "157到達距離の診断": ["準備の確認.json", "停止.json"],
    }
    for name in MODULES:
        folder = ROOT / "work" / name
        for pattern in ("*.go", "*.mod", "*.py", "README.md"):
            for p in folder.glob(pattern):
                add(p)
        for p in (folder / "cmd").rglob("*.go"):
            add(p)
        for name in proof_names[name]:
            add(folder / name)
    for name in ("157集計と閲覧", "157独立検査"):
        for pattern in ("*.py", "*.mjs"):
            for p in (ROOT / "work" / name).glob(pattern):
                add(p)
    helper = ROOT / "work/157固定入口の準備"
    for name in ("schemaを確認する.py", "人工検査.py", "調査を停止する.py", "README.md", "schemaの確認.json", "停止の確認.json"):
        add(helper / name)
    independent = ROOT / "work/157到達距離の独立確認"
    for name in ("確認する.py", "人工検査.py", "準備の確認.json", "自然確認/独立確認.json", "README.md", "停止の確認.json"):
        add(independent / name)
    assert sha(independent / "自然確認/独立確認.json") == "4a1d6cc6deb361c92bc3e39f040b044596d2b633385a493764b5eb9aea45b6d5"
    for name in ("保存する.py", "集計を独立に確認する.py", "集計の独立確認.json"):
        add(HERE / name)
    for p in (FORMAL / "検査").glob("*.json"):
        add(p)
    add(FORMAL / "実行条件.md")
    add(HERE / "固定時文書/study/00157_固定入口の到達距離と追尾退出を比較する/設定と結果.md",
        "study/00157_固定入口の到達距離と追尾退出を比較する/設定と結果.md")
    add(FORMAL / "再現資料/README.md")
    for name in ("作成確認.json", "表示修正の確認.json", "独立再読.json"):
        add(OUTPUTS / name)

    # ----------------------------------------
    # 固定票に宣言された小源と恒久共有入力を検査する。
    tape_stop = json.loads((ROOT / "work/157固定入口と価格経路/停止の確認.json").read_bytes())
    distance_stop = json.loads((ROOT / "work/157到達距離の診断/停止.json").read_bytes())
    exit_prep = json.loads((ROOT / "work/157出口政策の再生/準備の確認.json").read_bytes())
    for mapping in (tape_stop["Source"], distance_stop["源"],
                    {"work/157出口政策の再生/" + k: v for k, v in exit_prep["源SHA256"].items()}):
        for name, expected in mapping.items():
            if name in selected:
                assert sha(selected[name]) == expected, name
            else:
                assert name == "work/157固定入口と価格経路/固定入口入力_最終.json", name
                assert sha(ROOT / "inputs/00157_固定入口と価格経路/固定入口入力.json") == expected
    creation = json.loads((OUTPUTS / "作成確認.json").read_bytes())
    display = json.loads((OUTPUTS / "表示修正の確認.json").read_bytes())
    builder = ROOT / "work/157集計と閲覧/CSVへ出力する.mjs"
    assert creation["出力器SHA256"] != sha(builder) == display["出力器SHA256"]
    csv_refs = {name: sha(OUTPUTS / (name + ".csv")) for name in creation["表"]}
    assert all(csv_refs[name] == v["SHA256"] for name, v in creation["表"].items())
    assert csv_refs["125後の伸長"] == display["表"]["125後の伸長"]["SHA256"]
    package = ROOT / "work/157集計と閲覧/node_modules/@oai/artifact-tool/package.json"
    pkg = json.loads(package.read_bytes())
    refs = {}
    for name in ("inputs/00157_固定入口と価格経路/固定入口入力.json", "inputs/00157_固定入口と価格経路/価格テープ/価格テープの確認.json",
                 "study/00157_固定入口の到達距離と追尾退出を比較する/成果物/出口結果.json.gz",
                 "study/00157_固定入口の到達距離と追尾退出を比較する/成果物/到達距離/到達距離の集計.json"):
        p = ROOT / name
        refs[name] = {"bytes": p.stat().st_size, "sha256": sha(p), "ZIPへデータ格納": False}
    entries = {}
    for name, p in sorted(selected.items()):
        b = p.read_bytes()
        entries[name] = {"sha256": hashlib.sha256(b).hexdigest(), "bytes": len(b), "crc32": f"{zlib.crc32(b):08x}", "元path": p.relative_to(ROOT).as_posix()}
    manifest = {"試行": 157, "用途": "停止後の再現小源。各自然実行の事前固定票へ遡及追加しない", "格納ファイル": entries,
                "共有参照": refs, "依存": {"Go": "1.24.2 windows/amd64", "RootPython": "3.14.3", "RootNumPy": "2.5.4", "集計独立確認": "Python標準ライブラリ/Fractionのみ", "CSVNode": creation["node"], "調査shellNode": "v24.14.0", "artifact": {"name": pkg["name"], "version": pkg["version"], "private": pkg["private"], "dependencies": pkg["dependencies"], "package_json_sha256": sha(package), "提供SDKを使用": True, "node_modules同梱": False}},
                "CSV版境界": {"初回作成器SHA256": creation["出力器SHA256"], "格納現版SHA256": sha(builder), "現版の表示修正票SHA256": sha(OUTPUTS / "表示修正の確認.json"), "4CSVのSHA256": csv_refs, "CSV不変": True, "変更範囲": "125後の伸長PNG列幅/表示修正分岐。元作者票と現コードを同じbytesとは主張しない"},
                "除外": ["exe", "dll", "node_modules", "cache", "入力/観測/全テープ/出口/型付き四表JSON", "CSV/画像", "原板"],
                "設定原文SHA256": "6493d72726253c036e086ead01d604fcf6d5cc977c971f9e95f03e63fccbb4b9"}
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, p in sorted(selected.items()):
            info = zipfile.ZipInfo(name, (2026, 11, 12, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, p.read_bytes())
        z.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"))
    restored = HERE / "復元確認"
    assert not restored.exists()
    with zipfile.ZipFile(target) as z:
        assert z.testzip() is None
        assert set(z.namelist()) == set(entries) | {"manifest.json"}
        for name, info in entries.items():
            b = z.read(name)
            assert len(b) == info["bytes"] and hashlib.sha256(b).hexdigest() == info["sha256"]
            assert f"{zlib.crc32(b):08x}" == info["crc32"]
        z.extractall(restored)
    for name, p in selected.items():
        assert sha(p) == entries[name]["sha256"], name
        if name.endswith(".py"):
            compile((restored / name).read_bytes(), name, "exec")

    def go_test(name: str) -> dict:
        """復元moduleから人工だけを再実行する。

        引数: name(str)。返り値: dict型の記録。
        """
        p = subprocess.run(["go", "test", "./..."], cwd=restored / "work" / name, capture_output=True, text=True, encoding="utf-8")
        assert p.returncode == 0, (name, p.stdout, p.stderr)
        return {"module": name, "exit_code": p.returncode, "stdout": p.stdout, "stderr": p.stderr}

    with ThreadPoolExecutor(max_workers=3) as executor:
        tests = list(executor.map(go_test, MODULES))
    syntax = subprocess.run(["node", "--check", str(restored / "work/157集計と閲覧/CSVへ出力する.mjs")], capture_output=True, text=True, encoding="utf-8")
    assert syntax.returncode == 0, syntax.stderr
    proof = {"成功": True, "試行": 157, "ZIP": {"path": target.relative_to(ROOT).as_posix(), "sha256": sha(target), "bytes": target.stat().st_size}, "源ファイル": len(entries), "manifest込み": len(entries) + 1,
             "全格納bytes_SHA_CRC一致": True, "元源前後同体": True, "Python全源構文成功": True, "Node現版構文成功": True,
             "復元Go人工": tests, "共有入力と成果の複写": False, "自然再実行": False, "CSV再生成": False,
             "CSV4物理SHA初回同体": True, "集計独立票SHA256": sha(HERE / "集計の独立確認.json"),
             "作成UTC": datetime.datetime.now(datetime.timezone.utc).isoformat(), "保存器SHA256": sha(Path(__file__))}
    ticket.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "ZIP_SHA256": sha(target), "小票": str(ticket), "小票SHA256": sha(ticket), "源数": len(entries)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
