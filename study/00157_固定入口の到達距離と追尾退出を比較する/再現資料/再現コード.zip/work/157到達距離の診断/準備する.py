"""自然テープ未読でGo10人工/vet/exeと最小指紋票を固定する。"""
from pathlib import Path
import hashlib
import json
import os
import subprocess

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 小実行源/条件/exeの物理指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(args: list) -> dict:
    """
    機能: 自然引数を渡さずGo人工/vet/buildだけをUTF8で実行する。
    引数: args(list[str])。返り値: dict。
    """
    x=subprocess.run(args,cwd=HERE,capture_output=True,env={**os.environ,'PYTHONUTF8':'1'})
    out,error=x.stdout.decode('utf-8','strict'),x.stderr.decode('utf-8','strict');assert x.returncode==0,(args,out,error)
    return {'command':args,'成功':True,'stdout':out,'stderr':error}


def main() -> None:
    """
    機能: 自然実行せず最小準備/停止票とRoot用exeを作る。
    引数: なし。返り値: None。
    """
    assert not (HERE/'準備の確認.json').exists()
    shared=ROOT/'work/157固定入口と価格経路';formal=ROOT/'study/00157_固定入口の到達距離と追尾退出を比較する'
    paths=[*HERE.rglob('*.go'),HERE/'go.mod',HERE/'README.md',*HERE.glob('*.py'),*shared.glob('*.go'),shared/'go.mod',formal/'実行条件.md',formal/'設定と結果.md']
    before={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    logs=[run(['go','test','-count=1','-v','./...']),run(['go','vet','./...']),run(['go','build','-o','到達距離診断.exe','./cmd/diagnose'])]
    assert logs[0]['stdout'].count('--- PASS:')==10
    rejected=subprocess.run([str(HERE/'到達距離診断.exe')],cwd=HERE,capture_output=True);assert rejected.returncode==2
    assert before=={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    proof={'成功':True,'試行':157,'自然テープ再生_新金融_生Raw読取':False,'人工主群':10,'test_vet_build':logs,'明示旗なしI_O前拒否':True,
        '源前後同体':before,'exe':{'path':'work/157到達距離の診断/到達距離診断.exe','sha256':sha(HERE/'到達距離診断.exe')},
        '設定513セル':True,'旧H60復元はRoot別担当':True,'出力schema':'reach_distance157_v1'}
    p=HERE/'準備の確認.json';p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    stop={'成功':True,'編集停止':True,'試行':157,'準備SHA256':sha(p),'exeSHA256':sha(HERE/'到達距離診断.exe'),'源':before}
    s=HERE/'停止.json';s.write_text(json.dumps(stop,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'成功':True,'準備SHA256':sha(p),'停止SHA256':sha(s),'exeSHA256':stop['exeSHA256']},ensure_ascii=False))


if __name__=='__main__':
    main()
