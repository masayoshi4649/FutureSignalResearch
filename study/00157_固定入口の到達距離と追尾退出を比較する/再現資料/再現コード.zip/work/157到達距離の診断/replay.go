package exitdistance157

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"sort"

	"pricetape157"
)

// ReplayScene は価格テープを一回だけ読み、共通入口全値を照合して各caseの診断を進めます。
//
// 引数: directory(string)、fixed(FixedScene157)、tape(SceneTape157)。返り値: SceneResult/error。
func ReplayScene(directory string, fixed pricetape157.FixedScene157, tape pricetape157.SceneTape157) (SceneResult, error) {
	out := SceneResult{Session: fixed.Session, Contract: fixed.Contract, ForceClose: fixed.ForceClose, ContinuousEnd: fixed.ContinuousEnd, Cases: []CaseResult{}}
	if tape.Session != fixed.Session || tape.Contract != fixed.Contract || tape.Start != fixed.Start || tape.End != fixed.End || tape.ForceClose != fixed.ForceClose || tape.ContinuousEnd != fixed.ContinuousEnd || tape.Raw != fixed.Raw || tape.ActualSHA256 != fixed.Raw.SHA256 || fixed.ExpectedQuality == nil || tape.Quality != *fixed.ExpectedQuality || tape.Before != tape.After || len(tape.EntryMatches) != len(fixed.Cases) {
		return out, fmt.Errorf("固定場/品質/テープ照合差:%s", fixed.Session)
	}
	matches := map[string]pricetape157.EntryMatch157{}
	for _, m := range tape.EntryMatches {
		if _, ok := matches[m.CaseID]; ok {
			return out, fmt.Errorf("入口witness重複")
		}
		matches[m.CaseID] = m
	}
	order := make([]int, len(fixed.Cases))
	observers := make([]*Observer, len(fixed.Cases))
	for i := range order {
		order[i] = i
	}
	sort.Slice(order, func(i, j int) bool {
		a, b := fixed.Cases[order[i]], fixed.Cases[order[j]]
		if a.Entry.Index == b.Entry.Index {
			return a.ID < b.ID
		}
		return a.Entry.Index < b.Entry.Index
	})
	cursor := 0
	active := []int{}
	var line int64
	read, err := pricetape157.ReadTape(directory, tape, func(q Quote) error {
		line++
		for cursor < len(order) && fixed.Cases[order[cursor]].Entry.Index <= q.Index {
			i := order[cursor]
			c := fixed.Cases[i]
			m, ok := matches[c.ID]
			if !ok || c.Entry != q || m.Quote != q || m.TapeLine != line {
				return fmt.Errorf("固定取得8値/テープ原行差:%s", c.ID)
			}
			o, e := New(Entry{ID: c.ID, Side: c.Side, Quote: c.Entry, Price: c.EntryPrice, ForceClose: fixed.ForceClose, ContinuousEnd: fixed.ContinuousEnd})
			if e != nil {
				return e
			}
			observers[i] = o
			active = append(active, i)
			cursor++
		}
		keep := active[:0]
		for _, i := range active {
			if e := observers[i].Observe(q); e != nil {
				return e
			}
			if !observers[i].Done() {
				keep = append(keep, i)
			}
		}
		active = keep
		return nil
	})
	if err != nil {
		return out, err
	}
	if !read.Success || cursor != len(order) {
		return out, fmt.Errorf("全テープ/固定取得の完読差")
	}
	out.TapeRead = read
	for i, c := range fixed.Cases {
		if observers[i] == nil {
			return out, fmt.Errorf("未復元入口:%s", c.ID)
		}
		out.Cases = append(out.Cases, CaseResult{ID: c.ID, Session: fixed.Session, Contract: fixed.Contract, OriginalSide: c.OriginalSide, Side: c.Side, Stream: c.Stream, Entry: c.Entry, EntryPrice: c.EntryPrice, Memberships: c.Memberships, Windows: observers[i].FinishEOF()})
	}
	return out, nil
}

type fileStat struct {
	Bytes     int64  `json:"bytes"`
	ModTimeNS int64  `json:"mtime_ns"`
	SHA256    string `json:"sha256"`
}

// fingerprint は小入力の物理指紋/stat不変を確認します。
//
// 引数: path(string)。返り値: fileStat/error。
func fingerprint(path string) (fileStat, error) {
	a, e := os.Stat(path)
	if e != nil {
		return fileStat{}, e
	}
	f, e := os.Open(path)
	if e != nil {
		return fileStat{}, e
	}
	defer f.Close()
	h := sha256.New()
	if _, e = io.Copy(h, f); e != nil {
		return fileStat{}, e
	}
	b, e := os.Stat(path)
	if e != nil {
		return fileStat{}, e
	}
	if a.Size() != b.Size() || a.ModTime() != b.ModTime() {
		return fileStat{}, fmt.Errorf("読取中のstat差:%s", path)
	}
	return fileStat{Bytes: a.Size(), ModTimeNS: a.ModTime().UnixNano(), SHA256: hex.EncodeToString(h.Sum(nil))}, nil
}

type RunConfig struct {
	FixedInput       string
	FixedSHA256      string
	TapeManifest     string
	TapeSHA256       string
	Conditions       string
	ConditionsSHA256 string
	Output           string
}

// writeJSON は未作成先へJSONを保存し、任意gzipの解凍副本を作りません。
//
// 引数: path(string)、value(any)、compressed(bool)。返り値: error。
func writeJSON(path string, value any, compressed bool) error {
	f, e := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if e != nil {
		return e
	}
	defer f.Close()
	var writer io.Writer = f
	var z *gzip.Writer
	if compressed {
		z = gzip.NewWriter(f)
		writer = z
	}
	enc := json.NewEncoder(writer)
	enc.SetEscapeHTML(false)
	if e = enc.Encode(value); e != nil {
		return e
	}
	if z != nil {
		if e = z.Close(); e != nil {
			return e
		}
	}
	return f.Close()
}

// Run はRoot通知後だけ呼び、全73テープの完読成功後に837case/924所属の診断を保存します。
//
// 引数: config(RunConfig)。返り値: error。Rawや旧売買条件を呼びません。
func Run(config RunConfig) error {
	if config.Output == "" {
		return fmt.Errorf("未作成output-dirが必要")
	}
	if _, e := os.Stat(config.Output); !os.IsNotExist(e) {
		return fmt.Errorf("未作成output-dirのみ")
	}
	declared := map[string]string{config.FixedInput: config.FixedSHA256, config.TapeManifest: config.TapeSHA256, config.Conditions: config.ConditionsSHA256}
	before := map[string]fileStat{}
	for p, h := range declared {
		v, e := fingerprint(p)
		if e != nil {
			return e
		}
		if len(h) != 64 || v.SHA256 != h {
			return fmt.Errorf("入力SHA差:%s", p)
		}
		before[p] = v
	}
	fixed, e := pricetape157.LoadFixed(config.FixedInput, config.FixedSHA256)
	if e != nil {
		return e
	}
	tapes, e := pricetape157.ReadManifest(config.TapeManifest, config.TapeSHA256)
	if e != nil {
		return e
	}
	if tapes.Input.SHA256 != config.FixedSHA256 || len(fixed.Scenes) != len(tapes.Scenes) {
		return fmt.Errorf("固定/テープ参照差")
	}
	scenes := make([]SceneResult, len(fixed.Scenes))
	sessions := []string{}
	cases, members := 0, 0
	for i, s := range fixed.Scenes {
		r, err := ReplayScene(filepath.Dir(config.TapeManifest), s, tapes.Scenes[i])
		if err != nil {
			return err
		}
		scenes[i] = r
		sessions = append(sessions, s.Session)
		cases += len(r.Cases)
		for _, c := range r.Cases {
			members += len(c.Memberships)
		}
		fmt.Fprintf(os.Stderr, "診断済み %s 累計case=%d 所属=%d\n", s.Session, cases, members)
	}
	if cases != 837 || members != 924 {
		return fmt.Errorf("全物理/所属件数差")
	}
	aggregates := Summarize(scenes, sessions)
	if aggregates["all"]["153U15"]["H60"].FixedEntries != 93 || aggregates["all"]["152U0"]["H60"].FixedEntries != 831 {
		return fmt.Errorf("cohort分母差")
	}
	for p, v := range before {
		current, err := fingerprint(p)
		if err != nil || current != v {
			return fmt.Errorf("入力前後差:%s", p)
		}
	}
	if e = os.MkdirAll(config.Output, 0755); e != nil {
		return e
	}
	common := map[string]any{"success": true, "trial": 157, "schema": "reach_distance157_v1", "fixed_input_sha256": config.FixedSHA256, "tape_manifest_sha256": config.TapeSHA256, "conditions_sha256": config.ConditionsSHA256, "physical_cases": cases, "memberships": members, "widths": Widths, "conditional_targets": Targets, "origin_kinds": Origins, "lower_kinds": LowerKinds, "financial_pnl_calculated": false, "legacy_H60_baseline_recalculated": false, "deadline_price_excluded": true, "MFE_zero_is_reference_without_quote": true, "full_window_and_known_touch_are_separate": true}
	detail := map[string]any{}
	for k, v := range common {
		detail[k] = v
	}
	detail["scenes"] = scenes
	if e = writeJSON(filepath.Join(config.Output, "到達距離と条件付き先着.json.gz"), detail, true); e != nil {
		return e
	}
	summary := map[string]any{}
	for k, v := range common {
		summary[k] = v
	}
	summary["aggregates"] = aggregates
	summary["sessions"] = sessions
	summary["fixed_cohort_overlap_is_not_independent"] = 87
	if e = writeJSON(filepath.Join(config.Output, "到達距離の集計.json"), summary, false); e != nil {
		return e
	}
	outputs := map[string]fileStat{}
	for _, name := range []string{"到達距離と条件付き先着.json.gz", "到達距離の集計.json"} {
		v, err := fingerprint(filepath.Join(config.Output, name))
		if err != nil {
			return err
		}
		outputs[name] = v
	}
	for p, v := range before {
		current, err := fingerprint(p)
		if err != nil || current != v {
			return fmt.Errorf("保存後入力差:%s", p)
		}
	}
	return writeJSON(filepath.Join(config.Output, "完了の確認.json"), map[string]any{"成功": true, "試行": 157, "入力前後同体": before, "全テープCRC_物理解凍SHA_stat確認": true, "全73場": len(sessions), "物理case": cases, "所属": members, "出力": outputs, "Raw読取": false, "金融計算": false, "新採否又は閾値変更": false}, false)
}
