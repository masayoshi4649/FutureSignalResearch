package main

import (
	"flag"
	"fmt"
	"os"

	"exitdistance157"
)

// main は明示Root通知旗を検査してから共有テープの診断だけを起動します。
//
// 引数: CLIの固定入力/テープ/条件と各SHA、output-dir、execute-after-root。返り値: なし。
func main() {
	var c exitdistance157.RunConfig
	flag.StringVar(&c.FixedInput, "fixed-input", "", "固定837case入力")
	flag.StringVar(&c.FixedSHA256, "fixed-input-sha256", "", "固定入力SHA")
	flag.StringVar(&c.TapeManifest, "tape-manifest", "", "全73テープの完了票")
	flag.StringVar(&c.TapeSHA256, "tape-manifest-sha256", "", "完了票SHA")
	flag.StringVar(&c.Conditions, "conditions", "", "正式実行条件")
	flag.StringVar(&c.ConditionsSHA256, "conditions-sha256", "", "正式実行条件SHA")
	flag.StringVar(&c.Output, "output-dir", "", "未作成の出力先")
	execute := flag.Bool("execute-after-root", false, "Root自然再生通知後のみ")
	flag.Parse()
	if !*execute {
		fmt.Fprintln(os.Stderr, "Root自然再生通知後の明示旗が必要")
		os.Exit(2)
	}
	if e := exitdistance157.Run(c); e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	fmt.Println("157到達距離の全窓診断が完了")
}
