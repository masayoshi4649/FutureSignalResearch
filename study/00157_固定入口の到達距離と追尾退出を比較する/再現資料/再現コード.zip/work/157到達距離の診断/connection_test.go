package exitdistance157

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"pricetape157"
)

// bytesSHA は手製テープだけの物理/解凍指紋を求めます。
//
// 引数: value([]byte)。返り値: string。
func bytesSHA(value []byte) string { h := sha256.Sum256(value); return hex.EncodeToString(h[:]) }

// tapeFixture は3行の人工共有テープと固定1case/2所属を用意します。
//
// 引数: t(*testing.T)。返り値: directory(string)/FixedScene157/SceneTape157。
func tapeFixture(t *testing.T) (string, pricetape157.FixedScene157, pricetape157.SceneTape157) {
	t.Helper()
	directory := t.TempDir()
	entry := entryFixture(100)
	quotes := []Quote{entry.Quote, quoteFixture(1, 125, 1), quoteFixture(100, 500, 2)}
	var raw bytes.Buffer
	encoder := json.NewEncoder(&raw)
	for _, q := range quotes {
		if e := encoder.Encode(q); e != nil {
			t.Fatal(e)
		}
	}
	var compressed bytes.Buffer
	z := gzip.NewWriter(&compressed)
	if _, e := z.Write(raw.Bytes()); e != nil {
		t.Fatal(e)
	}
	if e := z.Close(); e != nil {
		t.Fatal(e)
	}
	if e := os.WriteFile(filepath.Join(directory, "人工.jsonl.gz"), compressed.Bytes(), 0600); e != nil {
		t.Fatal(e)
	}
	quality := pricetape157.Counts{Delivered: 3}
	ref := pricetape157.FileRef{Path: "原板を開かない", SHA256: strings.Repeat("a", 64)}
	fixed := pricetape157.FixedScene157{Session: "人工00", Contract: "X", Start: 0, End: 700, ForceClose: 100, ContinuousEnd: 400, Raw: ref, ExpectedAccepted: 3, ExpectedQuality: &quality,
		Cases: []pricetape157.FixedCase157{{ID: entry.ID, Side: 1, OriginalSide: 1, Stream: "original", Entry: entry.Quote, EntryPrice: entry.Price,
			Memberships: []pricetape157.Membership157{{Policy: "153U15", Side: 1, Stream: "original", EntryPrice: entry.Price}, {Policy: "152U0", Side: 1, Stream: "original", EntryPrice: entry.Price}}}}}
	tape := pricetape157.SceneTape157{Success: true, Session: fixed.Session, Contract: fixed.Contract, Start: 0, End: 700, ForceClose: 100, ContinuousEnd: 400, Raw: ref, ActualSHA256: ref.SHA256, Quality: quality,
		Tape:       pricetape157.TapeRef157{Path: "人工.jsonl.gz", SHA256: bytesSHA(compressed.Bytes()), DecodedSHA256: bytesSHA(raw.Bytes()), Bytes: int64(compressed.Len()), DecodedBytes: int64(raw.Len()), Rows: 3},
		FirstQuote: &quotes[0], LastQuote: &quotes[2], EntryMatches: []pricetape157.EntryMatch157{{CaseID: entry.ID, Quote: entry.Quote, TapeLine: 1}}}
	return directory, fixed, tape
}

// TestTapeConnectionAndCRC は837入力と同じ公開reader接続・入口8値・末尾CRCを小列で検査します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestTapeConnectionAndCRC(t *testing.T) {
	directory, fixed, tape := tapeFixture(t)
	r, e := ReplayScene(directory, fixed, tape)
	if e != nil || len(r.Cases) != 1 || len(r.Cases[0].Memberships) != 2 || !r.TapeRead.Success {
		t.Fatal("接続", e)
	}
	if *r.Cases[0].Windows[0].MFE != 125 || r.Cases[0].Windows[0].Status != "complete" {
		t.Fatal("期限行を含めた")
	}
	bad := fixed
	bad.Cases = append([]pricetape157.FixedCase157(nil), fixed.Cases...)
	bad.Cases[0].Entry.Last++
	if _, e = ReplayScene(directory, bad, tape); e == nil {
		t.Fatal("入口全値差")
	}
	path := filepath.Join(directory, tape.Tape.Path)
	body, e := os.ReadFile(path)
	if e != nil {
		t.Fatal(e)
	}
	body[len(body)-8] ^= 1
	if e = os.WriteFile(path, body, 0600); e != nil {
		t.Fatal(e)
	}
	tape.Tape.SHA256 = bytesSHA(body)
	if _, e = ReplayScene(directory, fixed, tape); e == nil {
		t.Fatal("全callback後CRC破損を成功扱い")
	}
}

// TestDenominatorsAndAllScenes は起点/不足/0取得場を保持し、二所属を物理2caseへ水増ししません。
//
// 引数: t(*testing.T)。返り値: なし。
func TestDenominatorsAndAllScenes(t *testing.T) {
	directory, fixed, tape := tapeFixture(t)
	r, e := ReplayScene(directory, fixed, tape)
	if e != nil {
		t.Fatal(e)
	}
	unknown, _ := New(entryFixture(100))
	r.Cases = append(r.Cases, CaseResult{ID: "不足", Session: r.Session, Memberships: r.Cases[0].Memberships, Windows: unknown.FinishEOF()})
	sessions := []string{}
	for i := 0; i < 73; i++ {
		sessions = append(sessions, fmt.Sprintf("人工%02d", i))
	}
	a := Summarize([]SceneResult{r}, sessions)
	all := a["all"]["153U15"]["H60"]
	if all.FixedEntries != 2 || all.WindowComplete != 1 || all.WindowCensored != 1 || all.TargetScenes != 73 || all.MinimumSceneEntries != 0 || all.MaximumSceneEntries != 2 {
		t.Fatal("固定分母/全場")
	}
	for _, x := range all.Reaches {
		if x.ForwardReached+x.ForwardNoReachComplete+x.ForwardUnknown != 2 || x.CompleteFirstForward+x.CompleteFirstAdverse+x.CompleteNoTouch+x.WindowCensored != 2 {
			t.Fatal("到達分母")
		}
	}
	for _, x := range all.Conditionals {
		if x.OriginReached+x.OriginOppositeFirst+x.OriginNoReachComplete+x.OriginCensored != 2 || x.OriginReached != 1 || x.OriginCensored != 1 || x.NoHitComplete != 1 || x.OriginDenominatorRate == nil || *x.OriginDenominatorRate != 0 || x.ResolvedRate != nil {
			t.Fatal("起点/確定分母", x)
		}
	}
	if a["validation"]["152U0"]["H60"].FixedEntries != 0 || a["validation"]["152U0"]["H60"].Conditionals[0].OriginDenominatorRate != nil {
		t.Fatal("空期null")
	}
}
