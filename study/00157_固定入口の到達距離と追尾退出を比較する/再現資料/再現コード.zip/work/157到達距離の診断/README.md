# 157 到達距離と125起点の条件付き先着

Rootの固定837case/924所属を変更せず、共通accepted Quoteテープを当場一回読むGo module `exitdistance157`。`pricetape157` の公開 `LoadFixed/ReadManifest/ReadTape` を使い、Raw・新入口・政策の損益計算を呼ばない。自然テープはRootの明示通知後だけ再生する。

`New(Entry) (*Observer,error)`、`Observe(Quote) error`、`FinishEOF() []Window` が純状態API。entry厳密後・q.Time<deadline・正常清算BBOだけで両側12幅とMFE/MAE、Last/Bid/Ask OHLCを測る。MFEはmax(0,観測g)、MAEはmin(0,観測g)で、0が参照原点だけなら極値Quoteはnil。窓内正常行が無ければ値もnil。部分観測の極値を全窓最大としない。

H60=min(entry+3600,Source.force)、SESSION=Source.force。deadline〜+30の最初正常Quoteは完了確認だけ。accepted gap/正常BBO gap>300、EOF、endpoint_missing、phaseは初回で打切り、既知touchは保持する。取得行・期限行を到達へ足さない。

125起点は無保護first+125、−125より先+125。目標250/300/375/500×下側entry−125/名目建値0/逐次峰−100を各々比較し、起点行での飛越も残す。先着済みを後から変えず、起点未達・不足・完了未到達を分母から消さない。上位到達を政策の退出後利益へ足さない。

出力は `到達距離と条件付き先着.json.gz`（scenes→cases→windows）と `到達距離の集計.json`、`完了の確認.json`。集計schemaは `aggregates[all/train/validation][153U15/152U0][H60/SESSION]`。固定N、全窓完了/不足、全対象場件数/最大集中、観測prefixと完了窓のMFE/MAE、reaches12、conditionals24を持つ。reachesは両側無条件到達known/完了未到達/unknown、先着knownと完了FANCを別にする。conditionalsは全固定N、起点4状態、upper/lower/nohit_complete/censored_after_origin、全起点率/先着確定例率を別に保存する。全起点率に未決着がある場合は確定成功の下限で、未知を失敗へ断定した確率ではない。

```powershell
go build -o 到達距離診断.exe ./cmd/diagnose
```

実行CLIは `--fixed-input/--fixed-input-sha256/--tape-manifest/--tape-manifest-sha256/--conditions/--conditions-sha256/--output-dir/--execute-after-root`。未作成output-dir限定。全73テープCRC/物理解凍SHA/stat/件数、取得8Quote値/テープ原行を確認してから成功出力する。物理case837と所属924、93/831を照合し、旧H60baselineはRoot別担当へ分離する。

人工10群は売買鏡像、期限/300秒/床等号、同時刻原行、飛越、起点2種、未知保持、同じ旧先着でも経路が違う例、小テープ末尾CRC、全73/空期/起点分母を検査する。自然のデータ値・率・容量・金融は人工へ使わない。
