"""Rootの157条件を保ち、V7全513セルと出口/到達設定だけを新規保存する。"""
from pathlib import Path
import hashlib
import os
import re

ROOT=Path(__file__).resolve().parents[2]
FORMAL=ROOT/'study/00157_固定入口の到達距離と追尾退出を比較する'
V7=ROOT/'docs/議論/手法と時間スケールの汎用表_版7.md'


def sha(path: Path) -> str:
    """
    機能: 条件/V7の物理SHA256を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def link(match: re.Match) -> str:
    """
    機能: V7教材の実体を変えず正式157相対pathへ結ぶ。
    引数: match(re.Match)。返り値: str。
    """
    target=match.group(2)
    if '://' in target or target.startswith('#'):return match.group(0)
    path,sep,anchor=target.partition('#');dest=(V7.parent/path).resolve();assert dest.exists()
    return f'[{match.group(1)}]({os.path.relpath(dest,FORMAL).replace(chr(92),"/")}{sep}{anchor})'


def main() -> None:
    """
    機能: 固定2入口を変更せず、157の使用設定と全57手法9尺度を作る。
    引数: なし。返り値: None。README/実行条件や旧試行を編集しない。
    """
    target=FORMAL/'設定と結果.md';assert not target.exists()
    condition=FORMAL/'実行条件.md';body=condition.read_text(encoding='utf-8')
    table=V7.read_text(encoding='utf-8').split('## 手法×時間スケール',1)[1].split('## 設定明細',1)[0]
    table=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',link,table).replace('全セルは未設定・未検証。','157使用セルは設定済み。作成時、到達/退出の自然結果は未読・未実行。',1)
    cells={
        ('P04',0):'157-COND：無保護+125/−125より先+125の2起点、上位250/300/375/500と三床先着；未実行',
        ('P05',0):'157-G：固定実Pから正常清算BBOの符号付きg、取得行除外；未実行',
        ('P06',0):'157-D：無保護MFE/MAE・到達原行・峰、入口前高安を混ぜない；未実行',
        ('B01',0):'157-Q：正常BBOのみ、価格/正常gap>300sで打切り、D1後1秒/TTL30；未実行',
        ('M01',0):'対象外：旧153U15/152U0固定、新学習/入口再選別なし',
        ('E01',0):'157-D：両側12幅25/50/75/100/125/150/175/200/250/300/375/500、先着/未知分母；未実行',
        ('E01',6):'157-H60：min(q1+3600,Source.force)、q.Time<deadlineだけ到達/峰；未実行',
        ('E01',7):'157-SESSION：Source.force=15:35/05:50、ザラバ終端と区別；未実行',
        ('E02',0):'157-X：固定5＋追尾7の12政策、床非緩和/要求とD1実BBOを分離、D0感度；未実行',
    }
    lines=[];count=0
    for line in table.splitlines():
        row=line.split('|')
        if re.match(r'^\|\s+[A-Z]\d{2}\s+\|',line) and len(row)==13:
            count+=1;ident=row[1].strip()
            for i in range(9):row[i+3]=' '+cells.get((ident,i),'今回の新出口では未使用・未検証')+' '
            line='|'.join(row)
        lines.append(line)
    assert count==57
    policies=body.split('|ID|初期SL|TP|追尾・利益床|',1)[1].split('最初から125pt追尾',1)[0]
    result=f'''# 157 設定と結果

2026-11-12。使用版は[汎用表V7](../../docs/議論/手法と時間スケールの汎用表_版7.md)、SHA `{sha(V7)}`。全57手法×9尺度=513セルを保持する。固定入口/価格テープの準備は行ったが、本表作成時の出口・到達自然結果は未読・未実行。Root[実行条件](実行条件.md) SHA `{sha(condition)}` を正本とし、設定の結果後交換をしない。

新入口/技術可変幅を加えず、旧153U15全93・152U0全831を全73場で保持する。837物理case/924所属、共通87は独立標本へ水増ししない。旧入口で使ったMA/RSI/量等は原試行の条件を参照し、今回の出口で再判定した設定とはしない。

{chr(10).join(lines)}

## 固定12政策・設定157-X

|ID|初期SL|TP|追尾・利益床|{policies}

全出口は同じ固定入口とF125S125（単純IFD±125）の条件を揃えて比較する。主D1は要求+1秒以降の厳密に後の最初正常BBO、D0は要求原行の理想化感度。要求+30秒超過/ザラバ終端/欠測で約定不明なら未知、反発で予約を取消さない。期限はタイマー時刻そのものを要求とし、原行を待って期限を後ろへずらさない。

T0W125は初期B=−125・M=max(0,取得後観測g)から追尾し、初期建値0ではない。E0W125は費用後W>0で必ず起動し以後B≥0。Bを不利に緩めず、起動/要求/fillを分離する。線・TPの理想価格へ遡及せず、取引所注文刻み/ネイティブ追尾を仮定しない。

## 到達距離・条件付き設定157-D/COND

H60=min(q1+3600,Source.force)、SESSION=Source.force。到達/峰/OHLCはentryより厳密後かつquote.Time<deadlineの正常清算BBOだけ。deadline以降+30秒以内の最初正常BBOは完了確認で、期限後の高安を窓に足さない。旧厳密H60/±125対照はRoot別枠で、Source時刻による短縮と混ぜない。

幅は25/50/75/100/125/150/175/200/250/300/375/500ptの両側初到達と同幅先着。MFE/MAEの観測prefixと全窓完了を分離する。125起点は無保護first+125と初期−125より先+125の2つ。各起点から目標250/300/375/500×下側entry−125/名目建値0/逐次峰−100の24比較を保存し、起点行も下側/飛越を判定する。同一行125/目標到達は明示し、補間しない。

全固定N/全起点N/先着確定例Nを別列にし、起点未到達・起点前不足・起点後未決着/不足・H完了未到達を消さない。既知touch/先着は後のgapで消さない。未完窓の部分MFEを完全な最大伸長とせず、無保護の退出後到達を政策の利益/機会損失へ加えない。

## 評価と未実行欄

両入口×H60/SESSION×D1/D0×C0/C5×12政策、全73/前48/後25を比較。mini1枚100円/pt、C0往復77円、C5往復1077円（追加滑りは現金控除、価格へ二重反映しない）。既知利益/損失/差引、PF、決済勝率、費用後正益後赤字、125後赤字、保有時間/峰からの吐出しを記録する。金額未知を0にせず、場別累計既知と全件確定nullを分離する。

全区間既使用・近接保有/共通case依存、独立mini1診断と片側10枚口座の差を維持する。今回の成績は未見再現性/運用採用の確定ではない。到達数・収支・対照との差は未算出で、正式結果は固定本文を保持して後から追記する。
'''
    target.write_text(result,encoding='utf-8',newline='\n')
    print('157 V7全513セルと12政策設定を保存')


if __name__=='__main__':
    main()
