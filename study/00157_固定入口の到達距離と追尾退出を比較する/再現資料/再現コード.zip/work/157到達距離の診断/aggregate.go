package exitdistance157

import "pricetape157"

type CaseResult struct {
	ID           string                       `json:"id"`
	Session      string                       `json:"session"`
	Contract     string                       `json:"contract"`
	OriginalSide int                          `json:"original_side"`
	Side         int                          `json:"side"`
	Stream       string                       `json:"stream"`
	Entry        Quote                        `json:"entry"`
	EntryPrice   float64                      `json:"entry_price"`
	Memberships  []pricetape157.Membership157 `json:"memberships"`
	Windows      []Window                     `json:"windows"`
}

type SceneResult struct {
	Session       string                   `json:"session"`
	Contract      string                   `json:"contract"`
	ForceClose    float64                  `json:"force_close"`
	ContinuousEnd float64                  `json:"continuous_end"`
	TapeRead      pricetape157.TapeRead157 `json:"tape_read"`
	Cases         []CaseResult             `json:"cases"`
}

type NumberStats struct {
	N       int      `json:"known_n"`
	Mean    *float64 `json:"mean"`
	Minimum *float64 `json:"minimum"`
	Maximum *float64 `json:"maximum"`
}

type ReachCounts struct {
	Width                     float64  `json:"width"`
	FixedEntries              int      `json:"fixed_entries"`
	ForwardReached            int      `json:"forward_reached_known"`
	ForwardNoReachComplete    int      `json:"forward_no_reach_complete"`
	ForwardUnknown            int      `json:"forward_unknown"`
	AdverseReached            int      `json:"adverse_reached_known"`
	AdverseNoReachComplete    int      `json:"adverse_no_reach_complete"`
	AdverseUnknown            int      `json:"adverse_unknown"`
	FirstForwardKnown         int      `json:"first_forward_known"`
	FirstAdverseKnown         int      `json:"first_adverse_known"`
	FirstUnknown              int      `json:"first_unknown"`
	CompleteFirstForward      int      `json:"complete_first_forward"`
	CompleteFirstAdverse      int      `json:"complete_first_adverse"`
	CompleteNoTouch           int      `json:"complete_no_touch"`
	WindowCensored            int      `json:"window_censored"`
	ForwardOnFixedDenominator *float64 `json:"known_forward_on_fixed_denominator"`
	FirstResolvedRate         *float64 `json:"first_known_resolved_rate"`
}

type ConditionalCounts struct {
	Origin                string   `json:"origin"`
	Target                float64  `json:"target"`
	LowerKind             string   `json:"lower_kind"`
	FixedEntries          int      `json:"fixed_entries"`
	OriginReached         int      `json:"origin_reached"`
	OriginOppositeFirst   int      `json:"origin_opposite_first"`
	OriginNoReachComplete int      `json:"origin_no_reach_complete"`
	OriginCensored        int      `json:"origin_censored"`
	UpperFirst            int      `json:"upper_first"`
	LowerFirst            int      `json:"lower_first"`
	NoHitComplete         int      `json:"no_hit_complete"`
	CensoredAfterOrigin   int      `json:"censored_after_origin"`
	SameRowOriginAndUpper int      `json:"same_row_origin_and_upper"`
	OriginDenominatorRate *float64 `json:"upper_on_all_origins"`
	ResolvedRate          *float64 `json:"upper_on_resolved_origins"`
}

type WindowCounts struct {
	FixedEntries        int                 `json:"fixed_entries"`
	WindowComplete      int                 `json:"window_complete"`
	WindowCensored      int                 `json:"window_censored"`
	CensorReasons       map[string]int      `json:"censor_reasons"`
	SceneCounts         map[string]int      `json:"scene_counts"`
	TargetScenes        int                 `json:"target_scenes"`
	EnteredScenes       int                 `json:"entered_scenes"`
	MinimumSceneEntries int                 `json:"minimum_scene_entries"`
	MaximumSceneEntries int                 `json:"maximum_scene_entries"`
	MaximumSceneShare   *float64            `json:"maximum_scene_share"`
	SceneHHI            *float64            `json:"scene_hhi"`
	MFEComplete         NumberStats         `json:"mfe_complete_windows"`
	MAEComplete         NumberStats         `json:"mae_complete_windows"`
	MFEPrefix           NumberStats         `json:"mfe_observed_prefixes"`
	MAEPrefix           NumberStats         `json:"mae_observed_prefixes"`
	Reaches             []ReachCounts       `json:"reaches"`
	Conditionals        []ConditionalCounts `json:"conditionals"`
}

type Aggregates map[string]map[string]map[string]*WindowCounts

// addNumber は未知を除く数値の件数/平均/範囲を更新し、未知を0にしません。
//
// 引数: s(*NumberStats)、v(*float64)。返り値: なし。
func addNumber(s *NumberStats, v *float64) {
	if v == nil {
		return
	}
	s.N++
	if s.Mean == nil {
		setNumber(&s.Mean, *v)
		setNumber(&s.Minimum, *v)
		setNumber(&s.Maximum, *v)
		return
	}
	*s.Mean += (*v - *s.Mean) / float64(s.N)
	if *v < *s.Minimum {
		*s.Minimum = *v
	}
	if *v > *s.Maximum {
		*s.Maximum = *v
	}
}

// fraction は0分母をnullにし、既知0率を区別します。
//
// 引数: n/d(int)。返り値: *float64。
func fraction(n, d int) *float64 {
	if d == 0 {
		return nil
	}
	v := float64(n) / float64(d)
	return &v
}

// newCounts は空群でも全対象場と24条件を保持します。
//
// 引数: sessions([]string)。返り値: *WindowCounts。
func newCounts(sessions []string) *WindowCounts {
	x := &WindowCounts{CensorReasons: map[string]int{}, SceneCounts: map[string]int{}, TargetScenes: len(sessions)}
	for _, sid := range sessions {
		x.SceneCounts[sid] = 0
	}
	for _, w := range Widths {
		x.Reaches = append(x.Reaches, ReachCounts{Width: w})
	}
	for _, o := range Origins {
		for _, target := range Targets {
			for _, lower := range LowerKinds {
				x.Conditionals = append(x.Conditionals, ConditionalCounts{Origin: o, Target: target, LowerKind: lower})
			}
		}
	}
	return x
}

// addWindow は既知touchと全窓完了、125起点の既知/未知を別々に集計します。
//
// 引数: a(*WindowCounts)、sid(string)、w(Window)。返り値: なし。
func addWindow(a *WindowCounts, sid string, w Window) {
	a.FixedEntries++
	a.SceneCounts[sid]++
	complete := w.Status == "complete"
	if complete {
		a.WindowComplete++
		addNumber(&a.MFEComplete, w.MFE)
		addNumber(&a.MAEComplete, w.MAE)
	} else {
		a.WindowCensored++
		a.CensorReasons[w.CensorReason]++
	}
	addNumber(&a.MFEPrefix, w.MFE)
	addNumber(&a.MAEPrefix, w.MAE)
	// ----------------------------------------
	// 到達は両側を独立に記録し、先着だけから無条件到達を補完しない。
	for i, r := range w.Reaches {
		x := &a.Reaches[i]
		x.FixedEntries++
		if r.Forward != nil {
			x.ForwardReached++
		} else if complete {
			x.ForwardNoReachComplete++
		} else {
			x.ForwardUnknown++
		}
		if r.Adverse != nil {
			x.AdverseReached++
		} else if complete {
			x.AdverseNoReachComplete++
		} else {
			x.AdverseUnknown++
		}
		if r.FirstDirection == 1 {
			x.FirstForwardKnown++
		} else if r.FirstDirection == -1 {
			x.FirstAdverseKnown++
		} else if !complete {
			x.FirstUnknown++
		}
		if !complete {
			x.WindowCensored++
		} else if r.FirstDirection == 1 {
			x.CompleteFirstForward++
		} else if r.FirstDirection == -1 {
			x.CompleteFirstAdverse++
		} else {
			x.CompleteNoTouch++
		}
	}
	// ----------------------------------------
	// 起点を全固定件数から消さず、到達後不足も全起点率へ残す。
	position := 0
	for _, o := range w.Origins {
		for _, c := range o.Comparisons {
			x := &a.Conditionals[position]
			position++
			x.FixedEntries++
			switch o.Status {
			case "reached":
				x.OriginReached++
			case "opposite_first":
				x.OriginOppositeFirst++
			case "not_reached_complete":
				x.OriginNoReachComplete++
			default:
				x.OriginCensored++
			}
			switch c.Status {
			case "upper_first":
				x.UpperFirst++
			case "lower_first":
				x.LowerFirst++
			case "no_hit_complete":
				x.NoHitComplete++
			case "censored_after_origin":
				x.CensoredAfterOrigin++
			}
			if c.SameRowOriginAndUpper {
				x.SameRowOriginAndUpper++
			}
		}
	}
}

// finishCounts は固定/起点/決着の分母を別名で確定し、全場の0取得を残します。
//
// 引数: a(*WindowCounts)。返り値: なし。
func finishCounts(a *WindowCounts) {
	first := true
	sumSquares := 0.0
	for _, n := range a.SceneCounts {
		if first || n < a.MinimumSceneEntries {
			a.MinimumSceneEntries = n
		}
		if first || n > a.MaximumSceneEntries {
			a.MaximumSceneEntries = n
		}
		first = false
		if n > 0 {
			a.EnteredScenes++
		}
		sumSquares += float64(n) * float64(n)
	}
	a.MaximumSceneShare = fraction(a.MaximumSceneEntries, a.FixedEntries)
	if a.FixedEntries > 0 {
		v := sumSquares / (float64(a.FixedEntries) * float64(a.FixedEntries))
		a.SceneHHI = &v
	}
	for i := range a.Reaches {
		x := &a.Reaches[i]
		x.ForwardOnFixedDenominator = fraction(x.ForwardReached, x.FixedEntries)
		x.FirstResolvedRate = fraction(x.FirstForwardKnown, x.FirstForwardKnown+x.FirstAdverseKnown)
	}
	for i := range a.Conditionals {
		x := &a.Conditionals[i]
		x.OriginDenominatorRate = fraction(x.UpperFirst, x.OriginReached)
		x.ResolvedRate = fraction(x.UpperFirst, x.UpperFirst+x.LowerFirst)
	}
}

// Summarize は837物理caseを所属へ結び、全/前48/後25で93/831の分母を保持します。
//
// 引数: scenes([]SceneResult)、sessions([]string)。返り値: Aggregates。
func Summarize(scenes []SceneResult, sessions []string) Aggregates {
	out := Aggregates{}
	scopes := map[string][]string{"all": sessions, "train": sessions[:48], "validation": sessions[48:]}
	for part, scope := range scopes {
		out[part] = map[string]map[string]*WindowCounts{}
		keep := map[string]bool{}
		for _, sid := range scope {
			keep[sid] = true
		}
		for _, policy := range []string{"153U15", "152U0"} {
			out[part][policy] = map[string]*WindowCounts{"H60": newCounts(scope), "SESSION": newCounts(scope)}
		}
		for _, scene := range scenes {
			if keep[scene.Session] {
				for _, c := range scene.Cases {
					for _, m := range c.Memberships {
						for _, w := range c.Windows {
							addWindow(out[part][m.Policy][w.Kind], c.Session, w)
						}
					}
				}
			}
		}
		for _, byWindow := range out[part] {
			for _, a := range byWindow {
				finishCounts(a)
			}
		}
	}
	return out
}
