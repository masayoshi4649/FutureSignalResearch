module exitdistance157

go 1.24.2

require pricetape157 v0.0.0

replace pricetape157 => ../157固定入口と価格経路
