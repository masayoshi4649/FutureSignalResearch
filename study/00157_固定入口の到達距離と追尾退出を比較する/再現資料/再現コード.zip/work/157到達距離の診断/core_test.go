package exitdistance157

import (
	"math"
	"testing"
)

// entryFixture は正常BBOの手製固定取得を作ります。
//
// 引数: force(float64)。返り値: Entry。
func entryFixture(force float64) Entry {
	q := Quote{Clock: "人工", Time: 0, Index: 0, SourceLine: 1, Last: 10000, Bid: 9990, Ask: 10000, QuoteOK: true}
	return Entry{ID: "人工", Side: 1, Quote: q, Price: 10000, ForceClose: force, ContinuousEnd: force + 300}
}

// quoteFixture は実清算側の符号付きgと原行順を指定してQuoteを作ります。
//
// 引数: time/gain(float64)、index(int64)。返り値: Quote。
func quoteFixture(time, gain float64, index int64) Quote {
	return Quote{Clock: "人工", Time: time, Index: index, SourceLine: index + 1, Last: 10000 + gain + 5, Bid: 10000 + gain, Ask: 10010 + gain, QuoteOK: true}
}

// replayFixture は小さい人工列だけを再生してEOF確定した窓を返します。
//
// 引数: t(*testing.T)、e(Entry)、quotes([]Quote)。返り値: []Window。
func replayFixture(t *testing.T, e Entry, quotes []Quote) []Window {
	t.Helper()
	o, err := New(e)
	if err != nil {
		t.Fatal(err)
	}
	if err = o.Observe(e.Quote); err != nil {
		t.Fatal(err)
	}
	for _, q := range quotes {
		if err = o.Observe(q); err != nil {
			t.Fatal(err)
		}
	}
	return o.FinishEOF()
}

// comparison は人工窓内の起点/目標/床を一意に選びます。
//
// 引数: t(*testing.T)、w(Window)、origin(int)、target(float64)、lower(string)。返り値: Conditional。
func comparison(t *testing.T, w Window, origin int, target float64, lower string) Conditional {
	t.Helper()
	for _, c := range w.Origins[origin].Comparisons {
		if c.Target == target && c.LowerKind == lower {
			return c
		}
	}
	t.Fatal("比較なし")
	return Conditional{}
}

// TestStrictDeadline は取得/期限行の除外と後30秒の完了確認だけを検査します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestStrictDeadline(t *testing.T) {
	e := entryFixture(100)
	w := replayFixture(t, e, []Quote{quoteFixture(1, 125, 1), quoteFixture(99, 200, 2), quoteFixture(100, 500, 3)})[0]
	if w.Status != "complete" || *w.MFE != 200 || w.NormalRows != 2 || w.Reaches[11].Forward != nil || w.CompleteAt.Time != 100 {
		t.Fatalf("期限外を加算:%+v", w)
	}
	if comparison(t, w, 0, 250, "entry_minus125").Status != "no_hit_complete" {
		t.Fatal("期限後250を成功にした")
	}
	if *w.Bid.Close != 10200 || *w.Last.Close != 10205 {
		t.Fatal("期限行OHLC混入")
	}
	for _, delta := range []float64{30, 30.01} {
		x := replayFixture(t, e, []Quote{quoteFixture(99, 20, 1), quoteFixture(100+delta, 500, 2)})[0]
		if delta == 30 && x.Status != "complete" || delta > 30 && x.CensorReason != "endpoint_missing" {
			t.Fatal("期限30境界", x.Status, x.CensorReason)
		}
	}
}

// TestPathsNeedOrder は同じ旧first-touchでも125後建値/500到達が違う人工を検査します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestPathsNeedOrder(t *testing.T) {
	var paths [][]Window
	for _, mid := range []float64{500, 0} {
		paths = append(paths, replayFixture(t, entryFixture(100), []Quote{quoteFixture(1, 130, 1), quoteFixture(2, 210, 2), quoteFixture(3, mid, 3), quoteFixture(99, 260, 4), quoteFixture(100, 260, 5)}))
	}
	for _, width := range []float64{25, 50, 100, 125, 200} {
		for i := range paths[0][0].Reaches {
			a, b := paths[0][0].Reaches[i], paths[1][0].Reaches[i]
			if a.Width == width && (a.FirstDirection != b.FirstDirection || a.First.Quote != b.First.Quote) {
				t.Fatal("旧先着差")
			}
		}
	}
	if comparison(t, paths[0][0], 0, 250, "gross_breakeven0").Status != "upper_first" || comparison(t, paths[1][0], 0, 250, "gross_breakeven0").Status != "lower_first" {
		t.Fatal("経路差を失った")
	}
	if paths[0][0].Reaches[11].Forward == nil || paths[1][0].Reaches[11].Forward != nil {
		t.Fatal("500の無条件到達差")
	}
}

// TestTwoOrigins は初期逆125の後の無保護125だけを第1起点へ含めます。
//
// 引数: t(*testing.T)。返り値: なし。
func TestTwoOrigins(t *testing.T) {
	w := replayFixture(t, entryFixture(100), []Quote{quoteFixture(1, -125, 1), quoteFixture(2, 125, 2), quoteFixture(3, 250, 3), quoteFixture(100, 0, 4)})[0]
	if w.Origins[0].Status != "reached" || w.Origins[1].Status != "opposite_first" {
		t.Fatal("起点を混合")
	}
	if comparison(t, w, 0, 250, "entry_minus125").Status != "upper_first" || comparison(t, w, 1, 250, "entry_minus125").Status != "not_at_risk" {
		t.Fatal("非起点へ成果加算")
	}
	if w.Reaches[4].Forward == nil || w.Reaches[4].Adverse == nil || w.Reaches[4].FirstDirection != -1 {
		t.Fatal("両側到達を保持していない")
	}
}

// TestJumpAndFloorEquality は飛越の同一行と三つの床の等号を検査します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestJumpAndFloorEquality(t *testing.T) {
	w := replayFixture(t, entryFixture(100), []Quote{quoteFixture(1, 500, 1), quoteFixture(100, 0, 2)})[0]
	for _, o := range w.Origins {
		for _, c := range o.Comparisons {
			if c.Status != "upper_first" || !c.SameRowOriginAndUpper || c.Peak != 500 {
				t.Fatal("同時飛越", c)
			}
		}
	}
	for _, test := range []struct {
		lower string
		gain  float64
	}{{"entry_minus125", -125}, {"gross_breakeven0", 0}, {"running_peak_minus100", 100}} {
		x := replayFixture(t, entryFixture(100), []Quote{quoteFixture(1, 125, 1), quoteFixture(2, 200, 2), quoteFixture(3, test.gain, 3), quoteFixture(100, 0, 4)})[0]
		c := comparison(t, x, 0, 250, test.lower)
		if c.Status != "lower_first" || c.First.Gain != test.gain {
			t.Fatal("床等号", test, c)
		}
	}
}

// TestGapAndKnownRetention は300等号・正常gap・確定touch保持・EOFを検査します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestGapAndKnownRetention(t *testing.T) {
	e := entryFixture(1000)
	w := replayFixture(t, e, []Quote{quoteFixture(1, 125, 1), quoteFixture(301, 130, 2), quoteFixture(602, 500, 3)})[0]
	if w.CensorReason != "gap_censored" || w.Reaches[4].Forward == nil || w.Reaches[11].Forward != nil || *w.MFE != 130 || w.ExtremaFinal {
		t.Fatal("gapと既知保持")
	}
	if comparison(t, w, 0, 250, "gross_breakeven0").Status != "censored_after_origin" {
		t.Fatal("gap後を未到達化")
	}
	q := quoteFixture(301, 0, 3)
	q.Bid = 0
	q.Ask = 0
	q.QuoteOK = false
	x := replayFixture(t, e, []Quote{quoteFixture(1, 125, 1), func() Quote { z := quoteFixture(200, 0, 2); z.Bid = 0; z.Ask = 0; z.QuoteOK = false; return z }(), q, quoteFixture(302, 250, 4)})[0]
	if x.CensorReason != "bbo_gap_censored" {
		t.Fatal("正常gap", x.CensorReason)
	}
	y := replayFixture(t, e, []Quote{quoteFixture(1, 125, 1)})[0]
	if y.CensorReason != "eof_censored" || y.Origins[0].Status != "reached" {
		t.Fatal("EOF")
	}
	if replayFixture(t, e, nil)[0].MFE != nil {
		t.Fatal("価格なし0補完")
	}
}

// TestBBOAndSameTime はLastを清算へ代用せず、同時刻原行の順を保持します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestBBOAndSameTime(t *testing.T) {
	a := quoteFixture(1, -10, 1)
	a.Last = 20000
	b := quoteFixture(1, 125, 2)
	c := quoteFixture(1, 0, 3)
	w := replayFixture(t, entryFixture(100), []Quote{a, b, c, quoteFixture(100, 0, 4)})[0]
	if *w.MFE != 125 || *w.MAE != -10 || w.Last.HighAt.Quote.Index != 1 || w.Reaches[4].Forward.Quote.Index != 2 {
		t.Fatal("BBO/Last/同時計")
	}
	if comparison(t, w, 0, 250, "gross_breakeven0").First.Quote.Index != 3 {
		t.Fatal("同時計の順")
	}
}

// TestMirror は売買とBid/Askを物理反射し、全到達/条件先着が対称なことを検査します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestMirror(t *testing.T) {
	e := entryFixture(100)
	qs := []Quote{quoteFixture(1, -50, 1), quoteFixture(2, 125, 2), quoteFixture(3, 200, 3), quoteFixture(4, 100, 4), quoteFixture(5, 500, 5), quoteFixture(100, 0, 6)}
	reflect := func(q Quote) Quote { q.Last = 30000 - q.Last; q.Bid, q.Ask = 30000-q.Ask, 30000-q.Bid; return q }
	x := replayFixture(t, e, qs)
	e.Side = -1
	e.Quote = reflect(e.Quote)
	e.Price = e.Quote.Bid
	for i := range qs {
		qs[i] = reflect(qs[i])
	}
	y := replayFixture(t, e, qs)
	for i := range x {
		if *x[i].MFE != *y[i].MFE || *x[i].MAE != *y[i].MAE {
			t.Fatal("極値鏡像")
		}
		for j := range x[i].Reaches {
			if x[i].Reaches[j].FirstDirection != y[i].Reaches[j].FirstDirection || (x[i].Reaches[j].Forward == nil) != (y[i].Reaches[j].Forward == nil) {
				t.Fatal("到達鏡像")
			}
		}
		for j := range x[i].Origins {
			for k := range x[i].Origins[j].Comparisons {
				if x[i].Origins[j].Comparisons[k].Status != y[i].Origins[j].Comparisons[k].Status {
					t.Fatal("条件鏡像")
				}
			}
		}
	}
}

// TestInvalidAndSplitHorizons は不正入力とH60/SESSIONの別期限を検査します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestInvalidAndSplitHorizons(t *testing.T) {
	e := entryFixture(7200)
	o, err := New(e)
	if err != nil {
		t.Fatal(err)
	}
	var idx int64
	for time := 100.0; time < 3600; time += 100 {
		idx++
		if err = o.Observe(quoteFixture(time, 130, idx)); err != nil {
			t.Fatal(err)
		}
	}
	idx++
	if err = o.Observe(quoteFixture(3600, 500, idx)); err != nil {
		t.Fatal(err)
	}
	w := o.FinishEOF()
	if w[0].Status != "complete" || *w[0].MFE != 130 || *w[1].MFE != 500 || w[1].Status != "censored" {
		t.Fatal("期限混合")
	}
	if o.Observe(quoteFixture(3601, 0, idx+1)) == nil {
		t.Fatal("終了後観測")
	}
	bad := entryFixture(100)
	bad.Price = math.Inf(1)
	if _, err = New(bad); err == nil {
		t.Fatal("非有限")
	}
	o, _ = New(entryFixture(100))
	if o.Observe(quoteFixture(1, 0, 0)) == nil {
		t.Fatal("原行後退")
	}
}
