// Package exitdistance157 は固定取得後の無保護経路だけを測り、出口政策の利益へ加算しません。
package exitdistance157

import (
	"fmt"
	"math"

	"pricetape157"
)

type Quote = pricetape157.Quote

var Widths = []float64{25, 50, 75, 100, 125, 150, 175, 200, 250, 300, 375, 500}
var Targets = []float64{250, 300, 375, 500}
var Origins = []string{"unprotected_first_plus125", "plus125_before_minus125"}
var LowerKinds = []string{"entry_minus125", "gross_breakeven0", "running_peak_minus100"}

type Point struct {
	Quote Quote   `json:"quote"`
	Gain  float64 `json:"gain_points"`
}

type OHLC struct {
	Known   bool     `json:"known"`
	Open    *float64 `json:"open"`
	High    *float64 `json:"high"`
	Low     *float64 `json:"low"`
	Close   *float64 `json:"close"`
	OpenAt  *Point   `json:"open_at"`
	HighAt  *Point   `json:"high_at"`
	LowAt   *Point   `json:"low_at"`
	CloseAt *Point   `json:"close_at"`
}

type Reach struct {
	Width          float64 `json:"width"`
	Forward        *Point  `json:"first_forward"`
	Adverse        *Point  `json:"first_adverse"`
	FirstDirection int     `json:"first_direction"`
	First          *Point  `json:"first"`
}

type Conditional struct {
	Target                float64  `json:"target"`
	LowerKind             string   `json:"lower_kind"`
	Status                string   `json:"status"`
	First                 *Point   `json:"first"`
	SameRowOriginAndUpper bool     `json:"same_row_origin_and_upper"`
	Peak                  float64  `json:"observed_peak_since_origin"`
	LowerLevel            *float64 `json:"lower_level_at_resolution_or_end"`
}

type Origin struct {
	Kind        string        `json:"kind"`
	Status      string        `json:"status"`
	At          *Point        `json:"at"`
	ExcludedAt  *Point        `json:"excluded_at"`
	Comparisons []Conditional `json:"comparisons"`
}

type Window struct {
	Kind         string   `json:"kind"`
	Deadline     float64  `json:"deadline"`
	Status       string   `json:"status"`
	CensorReason string   `json:"censor_reason"`
	CensorAt     *Quote   `json:"censor_at"`
	CompleteAt   *Quote   `json:"complete_at"`
	NormalRows   int64    `json:"normal_rows_in_window"`
	MFE          *float64 `json:"mfe_points"`
	MAE          *float64 `json:"mae_points"`
	MFEAt        *Point   `json:"mfe_at"`
	MAEAt        *Point   `json:"mae_at"`
	ExtremaFinal bool     `json:"extrema_cover_complete_window"`
	Last         OHLC     `json:"last_ohlc_normal_bbo"`
	Bid          OHLC     `json:"bid_ohlc_normal_bbo"`
	Ask          OHLC     `json:"ask_ohlc_normal_bbo"`
	Reaches      []Reach  `json:"reaches"`
	Origins      []Origin `json:"origins"`
}

type Entry struct {
	ID            string
	Side          int
	Quote         Quote
	Price         float64
	ForceClose    float64
	ContinuousEnd float64
}

type Observer struct {
	entry      Entry
	windows    []Window
	previous   Quote
	lastNormal float64
	final      bool
}

// finite は既知実数の有限性を確認します。
//
// 引数: values(...float64)。返り値: bool。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// normal は清算判定へ使える正常なBid/Askを確認します。
//
// 引数: q(Quote)。返り値: bool。
func normal(q Quote) bool { return q.QuoteOK && finite(q.Bid, q.Ask) && q.Bid > 0 && q.Ask > q.Bid }

// pointCopy は独立した証拠点を作り、別イベントの更新と共有しません。
//
// 引数: p(Point)。返り値: *Point。
func pointCopy(p Point) *Point { x := p; return &x }

// setPoint はOHLC等の最新証拠を値copyで更新します。
//
// 引数: dst(**Point)、p(Point)。返り値: なし。
func setPoint(dst **Point, p Point) {
	if *dst == nil {
		*dst = new(Point)
	}
	**dst = p
}

// setNumber は値の既知性をnilと分けて更新します。
//
// 引数: dst(**float64)、v(float64)。返り値: なし。
func setNumber(dst **float64, v float64) {
	if *dst == nil {
		*dst = new(float64)
	}
	**dst = v
}

// updateOHLC は正常BBOの窓内価格だけでOHLCと最初の極値原行を更新します。
//
// 引数: o(*OHLC)、price(float64)、p(Point)。返り値: なし。
func updateOHLC(o *OHLC, price float64, p Point) {
	if !o.Known {
		o.Known = true
		setNumber(&o.Open, price)
		setNumber(&o.High, price)
		setNumber(&o.Low, price)
		setPoint(&o.OpenAt, p)
		setPoint(&o.HighAt, p)
		setPoint(&o.LowAt, p)
	} else {
		if price > *o.High {
			setNumber(&o.High, price)
			setPoint(&o.HighAt, p)
		}
		if price < *o.Low {
			setNumber(&o.Low, price)
			setPoint(&o.LowAt, p)
		}
	}
	setNumber(&o.Close, price)
	setPoint(&o.CloseAt, p)
}

// New は取得原行を到達へ数えず、H60/SESSIONの独立した観測状態を作ります。
//
// 引数: e(Entry)。返り値: *Observer/error。
func New(e Entry) (*Observer, error) {
	q := e.Quote
	if e.ID == "" || (e.Side != 1 && e.Side != -1) || !normal(q) || !finite(q.Time, q.Last, e.Price, e.ForceClose, e.ContinuousEnd) || q.Last <= 0 || q.Index < 0 || q.SourceLine < 1 || q.Clock == "" || q.Time >= e.ForceClose || e.ForceClose >= e.ContinuousEnd {
		return nil, fmt.Errorf("固定取得/方向/期限/BBO差:%s", e.ID)
	}
	price := q.Ask
	if e.Side < 0 {
		price = q.Bid
	}
	if e.Price != price {
		return nil, fmt.Errorf("固定実側取得価格差:%s", e.ID)
	}
	o := &Observer{entry: e, previous: q, lastNormal: q.Time}
	for _, h := range []struct {
		name     string
		deadline float64
	}{{"H60", math.Min(q.Time+3600, e.ForceClose)}, {"SESSION", e.ForceClose}} {
		w := Window{Kind: h.name, Deadline: h.deadline, Status: "pending"}
		for _, width := range Widths {
			w.Reaches = append(w.Reaches, Reach{Width: width})
		}
		for _, kind := range Origins {
			a := Origin{Kind: kind, Status: "pending"}
			for _, target := range Targets {
				for _, lower := range LowerKinds {
					a.Comparisons = append(a.Comparisons, Conditional{Target: target, LowerKind: lower, Status: "not_at_risk"})
				}
			}
			w.Origins = append(w.Origins, a)
		}
		o.windows = append(o.windows, w)
	}
	return o, nil
}

// Done は両窓の状態が確定したかだけを返します。
//
// 引数: o(*Observer)。返り値: bool。
func (o *Observer) Done() bool {
	return o.windows[0].Status != "pending" && o.windows[1].Status != "pending"
}

// closeWindow は確定済み到達を保持し、未確定の起点/先着だけを完了又は不足へ変えます。
//
// 引数: w(*Window)、status/reason(string)、q(*Quote)。返り値: なし。
func closeWindow(w *Window, status, reason string, q *Quote) {
	w.Status = status
	w.CensorReason = reason
	w.ExtremaFinal = status == "complete"
	if q != nil {
		x := *q
		if status == "complete" {
			w.CompleteAt = &x
		} else {
			w.CensorAt = &x
		}
	}
	for i := range w.Origins {
		a := &w.Origins[i]
		if a.Status == "pending" {
			if status == "complete" {
				a.Status = "not_reached_complete"
			} else {
				a.Status = "censored_before_origin"
			}
		}
		for j := range a.Comparisons {
			c := &a.Comparisons[j]
			if c.Status == "pending" {
				if status == "complete" {
					c.Status = "no_hit_complete"
				} else {
					c.Status = "censored_after_origin"
				}
			}
		}
	}
}

// startOrigin は125初知行から下側/目標を同じ原行で比較できる状態を作ります。
//
// 引数: a(*Origin)、p(Point)。返り値: なし。
func startOrigin(a *Origin, p Point) {
	a.Status = "reached"
	a.At = pointCopy(p)
	for i := range a.Comparisons {
		c := &a.Comparisons[i]
		c.Status = "pending"
		c.Peak = math.Max(0, p.Gain)
	}
}

// stepConditional は既存峰の床→目標→峰更新の順で、先着済み結果を変えません。
//
// 引数: a(*Origin)、p(Point)。返り値: error。
func stepConditional(a *Origin, p Point) error {
	if a.Status != "reached" {
		return nil
	}
	for i := range a.Comparisons {
		c := &a.Comparisons[i]
		if c.Status != "pending" {
			continue
		}
		lower := -125.0
		switch c.LowerKind {
		case "gross_breakeven0":
			lower = 0
		case "running_peak_minus100":
			lower = c.Peak - 100
		}
		down, up := p.Gain <= lower, p.Gain >= c.Target
		if down && up {
			return fmt.Errorf("条件付き上下同時抵触:%s", c.LowerKind)
		}
		if down || up {
			c.First = pointCopy(p)
			setNumber(&c.LowerLevel, lower)
			c.Peak = math.Max(c.Peak, p.Gain)
			if down {
				c.Status = "lower_first"
			} else {
				c.Status = "upper_first"
				c.SameRowOriginAndUpper = p.Quote.Index == a.At.Quote.Index && p.Quote.SourceLine == a.At.Quote.SourceLine
			}
		} else {
			c.Peak = math.Max(c.Peak, p.Gain)
			if c.LowerKind == "running_peak_minus100" {
				lower = c.Peak - 100
			}
			setNumber(&c.LowerLevel, lower)
		}
	}
	return nil
}

// stepWindow は期限未満の正常BBOだけを到達/極値へ加え、期限以降は完了確認だけ行います。
//
// 引数: w(*Window)、q(Quote)、previous/lastNormal(float64)、e(Entry)。返り値: error。
func stepWindow(w *Window, q Quote, previous, lastNormal float64, e Entry) error {
	if w.Status != "pending" {
		return nil
	}
	if q.Time >= e.ContinuousEnd {
		closeWindow(w, "censored", "phase_censored", &q)
		return nil
	}
	if q.Time-previous > 300 {
		closeWindow(w, "censored", "gap_censored", &q)
		return nil
	}
	if q.Time-lastNormal > 300 {
		closeWindow(w, "censored", "bbo_gap_censored", &q)
		return nil
	}
	if q.Time > w.Deadline+30 {
		closeWindow(w, "censored", "endpoint_missing", &q)
		return nil
	}
	if !normal(q) {
		return nil
	}
	if q.Time >= w.Deadline {
		closeWindow(w, "complete", "", &q)
		return nil
	}
	mark := q.Bid
	if e.Side < 0 {
		mark = q.Ask
	}
	g := float64(e.Side) * (mark - e.Price)
	if !finite(g) {
		return fmt.Errorf("派生g非有限:%s", e.ID)
	}
	p := Point{Quote: q, Gain: g}
	w.NormalRows++
	if w.MFE == nil {
		setNumber(&w.MFE, 0)
		setNumber(&w.MAE, 0)
	}
	if g > *w.MFE {
		setNumber(&w.MFE, g)
		setPoint(&w.MFEAt, p)
	} else if g == *w.MFE && w.MFEAt == nil {
		setPoint(&w.MFEAt, p)
	}
	if g < *w.MAE {
		setNumber(&w.MAE, g)
		setPoint(&w.MAEAt, p)
	} else if g == *w.MAE && w.MAEAt == nil {
		setPoint(&w.MAEAt, p)
	}
	updateOHLC(&w.Last, q.Last, p)
	updateOHLC(&w.Bid, q.Bid, p)
	updateOHLC(&w.Ask, q.Ask, p)
	for i := range w.Reaches {
		r := &w.Reaches[i]
		if g >= r.Width && r.Forward == nil {
			r.Forward = pointCopy(p)
			if r.FirstDirection == 0 {
				r.FirstDirection = 1
				r.First = r.Forward
			}
		}
		if g <= -r.Width && r.Adverse == nil {
			r.Adverse = pointCopy(p)
			if r.FirstDirection == 0 {
				r.FirstDirection = -1
				r.First = r.Adverse
			}
		}
	}
	var at125 *Reach
	for i := range w.Reaches {
		if w.Reaches[i].Width == 125 {
			at125 = &w.Reaches[i]
			break
		}
	}
	for i := range w.Origins {
		a := &w.Origins[i]
		if a.Status == "pending" {
			if a.Kind == "plus125_before_minus125" && at125.FirstDirection == -1 {
				a.Status = "opposite_first"
				a.ExcludedAt = at125.Adverse
			}
			if a.Status == "pending" && at125.Forward != nil {
				startOrigin(a, *at125.Forward)
			}
		}
		if err := stepConditional(a, p); err != nil {
			return err
		}
	}
	return nil
}

// Observe は同時刻の原行順を守り、全窓が終わっても呼出元の全テープ検証を妨げません。
//
// 引数: o(*Observer)、q(Quote)。返り値: error。
func (o *Observer) Observe(q Quote) error {
	if o.final {
		return fmt.Errorf("終了後の追加観測")
	}
	if q.Index == o.entry.Quote.Index && q == o.entry.Quote {
		return nil
	}
	if !finite(q.Time, q.Last, q.Bid, q.Ask) || q.Last <= 0 || q.Clock == "" || q.Index <= o.previous.Index || q.SourceLine <= o.previous.SourceLine || q.Time < o.previous.Time {
		return fmt.Errorf("観測時計/原行/数値差:%s", o.entry.ID)
	}
	for i := range o.windows {
		if err := stepWindow(&o.windows[i], q, o.previous.Time, o.lastNormal, o.entry); err != nil {
			return err
		}
	}
	o.previous = q
	if normal(q) {
		o.lastNormal = q.Time
	}
	return nil
}

// FinishEOF は残る窓だけを不足にし、値が確定したtouch/条件付き先着を保持します。
//
// 引数: o(*Observer)。返り値: []Window。終了後Observeは拒否します。
func (o *Observer) FinishEOF() []Window {
	for i := range o.windows {
		if o.windows[i].Status == "pending" {
			closeWindow(&o.windows[i], "censored", "eof_censored", nil)
		}
	}
	o.final = true
	return o.windows
}
