# 固定入口の純出口FSMと価格テープ再生

第157試行の[固定実行条件](../../study/00157_固定入口の到達距離と追尾退出を比較する/実行条件.md)を実装する。自然Raw/テープはRoot通知まで実行しない。旧156・133・148と固定入口を変更しない。

`fsm.go`はQuoteを1行ずつ受ける純状態で、12政策×H60/SESSION×D0/D1×C0/C5の96条件。主D1は厳密な後原行かつ要求+1秒以降、D0は要求行の正常BBOによる理想化。予約は反発しても取り消さず、30秒超過・accepted/正常BBO gap>300秒・EOF/終端は未知にする。期限要求は事前のdeadlineそのもの。初めて届いた期限後Quoteの時計へ要求を遅らせない。

`F125S125`は全案と同じ入口/期限/費用/遅延の単純IFD±125対照。線への到達はトリガーであり、TP/SL価格の固定約定ではない。実fill粗益に100円/ptを掛け、C0=77円/C5=1077円を現金控除する。spreadを再控除せず、C5価格ずらしを重ねない。

`replay.go`は[共有テープAPI](../157固定入口と価格経路/README.md)のLoadFixed/ReadManifest/ReadTapeを使い、1場1回のテープ配送から837物理caseを処理する。153U15の93所属と152U0の831所属はcase.membershipsに元参照付きで保持する。物理caseを924件に増やさない。取得source_lineでQuote全値が一致してから状態を開始し、取得行自身を到達へ含めない。

## 出力

`fixed_exit_results_v1`のgzip JSON。`scenes[].cases[]`に固定id/side/stream/entry/entry_price/membershipsと`results[96]`を置く。各resultにはconfig_id/policy/horizon/delay/cost、status(closed/unknown)、deadline、profit_points/profit_yen、trigger/fill、armed/arm_quote、stop_points、peak/troughとQuote、正益/125初到達、実退出後の赤字旗、吐出し、実保有中Last OHLCを保存する。

`profit_points`は実fillの粗益、`profit_yen=100*profit_points-fee_yen`。未知は両方nullで、赤字診断旗もnull。MFEの峰は0アンカー、MAEには取得直後の清算spreadを含む（entry_mark_pointsを併記）。Last OHLCは取得行をOpenに含む。退出済みの状態には後続価格を入れず、D1の予約中は実fill行まで実保有として記録する。品質/TTLで未知となった最初の不適格行は極値へ含めない。

テープEOFで未約定ならunknown_reason=eof。入力テープはザラバ終端未満なので終端行そのものを価格として合成しない。明示的にStepへ終端行を渡した場合はphase_cut。どちらも利益0や直前価格で清算しない。

完成前は`.partial`だけへ書き、全テープCRC/物理・解凍SHA/stat/行数と固定入力/manifest/実行条件SHAの再照合後に正本名へ移す。既存結果を上書きしない。stdoutに完成gzipの物理/解凍SHA/bytesを返す。

## 準備と実行

```powershell
Set-Location 'work/157出口政策の再生'
python -X utf8 '準備を確認する.py'
```

人工10主群は固定IFD・飛越、D1予約/反発/同秒、全追尾起動/床、費用後正益、期限タイマー、TTL/300秒/終端/EOF、全96条件売買鏡像、取得除外/入力不変、共有テープの実保有区間、取得/テープ改変拒否。Go test/vet/buildとCLI無指定拒否を確認する。

自然実行はRootが固定SHAを埋めて行う。CLIはRawを開かず、完成テープだけを読む。

```powershell
.\出口政策の再生.exe `
  --input '<固定入口.json>' --input-sha256 '<物理SHA>' `
  --manifest '<価格テープmanifest.json>' --manifest-sha256 '<物理SHA>' `
  --spec '<実行条件.md>' --spec-sha256 '<固定時物理SHA>' `
  --output '<新規の出口結果.json.gz>'
```

到達距離/125起点の条件付き率は別担当の無保護経路診断であり、この出口結果の利益に足さない。出口結果は独立mini1枚の重複保有診断で、片側10枚口座ではない。
