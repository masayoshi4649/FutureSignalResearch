"""純出口と人工テープだけを検査し、固定源の準備票を作る。"""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parent
FILES = ["go.mod", "fsm.go", "fsm_test.go", "replay.go", "replay_test.go", "cmd/exits/main.go", "README.md", "準備を確認する.py"]


def digest(path: Path) -> str:
    """物理SHAを求める。

    引数: path(Path)。返り値: str型のSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(args: list[str], expected: int = 0) -> dict:
    """人工検査コマンドを実行する。

    引数: args(list[str])、expected(int)。返り値: dict型の実行記録。
    """
    p = subprocess.run(args, cwd=ROOT, capture_output=True, text=True, encoding="utf-8")
    assert p.returncode == expected, (args, p.returncode, p.stdout, p.stderr)
    return {"command": args, "exit_code": p.returncode, "stdout": p.stdout, "stderr": p.stderr}


def main() -> None:
    """自然価格を開かずに準備票を保存する。

    引数: なし。返り値: None。
    """
    target = ROOT / "準備の確認.json"
    assert not target.exists(), "既存準備票は上書きしない"
    before = {name: digest(ROOT / name) for name in FILES}
    logs = [run(["go", "test", "-v", "./..."]), run(["go", "vet", "./..."]), run(["go", "build", "-o", "出口政策の再生.exe", "./cmd/exits"])]
    logs += [run([str(ROOT / "出口政策の再生.exe"), "--help"]), run([str(ROOT / "出口政策の再生.exe")], 2)]
    after = {name: digest(ROOT / name) for name in FILES}
    assert before == after
    proof = {"成功": True, "試行": 157, "状態": "人工準備完了・自然未実行", "作成UTC": datetime.datetime.now(datetime.timezone.utc).isoformat(), "主人工群": 10, "設定数": 96, "源前後同体": True, "源SHA256": before, "実行ファイルSHA256": digest(ROOT / "出口政策の再生.exe"), "実行記録": logs, "新自然Raw読取": False, "自然テープ再生": False, "旧源変更": False}
    target.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "path": str(target), "SHA256": digest(target)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
