"""135の停止済み独立金融検算とCSV証跡、結果後の補助コードを保存する。"""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT/'study/00135_公表差で不安定な方向上書きを抑える'
OUTPUT = ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/135公表差CSV'


def sha(body: bytes) -> str:
    """
    機能: 保存内容の指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def copy(source: Path, target: Path) -> None:
    """
    機能: 停止済み証跡を正式先へ同体保存する。
    引数: source/target(Path)。
    返り値: None。既存は上書きしない。
    """
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as handle: handle.write(source.read_bytes())


# ----------------------------------------
def main() -> None:
    """
    機能: 独立検算の受領指紋と転記を照合し、F1後発資源を別ZIPにする。
    引数: CLI --independent(Path)、--proof-sha256/--completion-sha256(str)。
    返り値: None。新金融・Raw読取・CSV生成を呼ばない。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('--independent',type=Path,required=True)
    parser.add_argument('--proof-sha256',required=True)
    parser.add_argument('--completion-sha256',required=True)
    args=parser.parse_args(); independent=args.independent.resolve()
    assert independent.is_relative_to(ROOT/'work')
    assert sha((independent/'独立確認.json').read_bytes()) == args.proof_sha256
    assert sha((independent/'完了.json').read_bytes()) == args.completion_sha256
    for source,target in [
        (independent/'独立確認.json',FORMAL/'検査/独立確認.json'),
        (independent/'完了.json',FORMAL/'検査/独立検算の完了.json'),
        (ROOT/'work/135公表差CSV出力/CSV再読の確認.json',FORMAL/'検査/CSV独立再読.json'),
        (OUTPUT/'CSVの確認.json',FORMAL/'検査/CSVの確認.json'),
    ]: copy(source,target)
    (FORMAL/'検査/独立検算.md').write_text('''# 135の独立検算

[数値正本](独立確認.json)と[停止票](独立検算の完了.json)を同体保管した。全360条件、旧C0/O0の120条件、全79取得/73場、三表19,809セル、phaseを保存Quoteから独立検算した。主U0は33順23逆未17不足6、58.93%、C5利益450,612円・損失373,464円・既知差引+77,148円。IFD既知76/未知3。Root/124算術のimportや新Raw走査とは区別する。

別の[非金融準備確認](非金融の独立確認.json)は自然金融JSONparseを拒否してchooser/費用/表/phase等号を調べた。実CSVの[独立再読](CSV独立再読.json)は19,809セル/14,145数値を入力JSONと照合した。両者と金融検算は別証跡である。

検算コード・元README・人工検査がある場合のそのコードは[後発ZIP](../再現資料/検算と保管の追補コード.zip)へ同体保存した。bootstrapを独立に再実装したとはしない。結果後の変更群分解や外部教材は主条件の事前根拠ではない。
''',encoding='utf-8')
    files=[p for p in independent.iterdir() if p.suffix in ('.py','.md')]
    files+=sorted((ROOT/'work/135正式保存').glob('*.py'))
    files+=sorted((FORMAL/'再現資料').glob('*.py'))
    files+=sorted((ROOT/'work/135公表差CSV出力').glob('*.py'))+sorted((ROOT/'work/135公表差CSV出力').glob('*.mjs'))
    diag=ROOT/'work/同じ79出生における公表差の診断'
    files += [diag/x for x in ('診断する.py','公表再生_test.go','条件.md','遅延変更5件を読む.py')]
    files += [ROOT/'work/135金融前の独立確認/非金融だけ確認する.py',
              ROOT/'work/135方向差の結果を分解する/分解する.py',
              ROOT/'work/次入口の因果順序を外部資料から整理する/README.md']
    archive=FORMAL/'再現資料/検算と保管の追補コード.zip'; index=[]
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in sorted(set(files)):
            body=path.read_bytes(); name=path.relative_to(ROOT).as_posix()
            z.writestr(name,body); index.append({'path':name,'bytes':len(body),'sha256':sha(body),
                '区分':'結果後の検算/転記/保管/非金融再生又は事後診断資源。F1源とは別'})
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in index: assert sha(z.read(item['path'])) == item['sha256']
    path=FORMAL/'保管索引.json'; m=json.loads(path.read_bytes())
    m['後発コード']={'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(index),'格納源':index}
    m['独立金融検算']={'正本SHA256':args.proof_sha256,'停止票SHA256':args.completion_sha256,
                     '由来':independent.relative_to(ROOT).as_posix()}
    path.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'後発源数':len(index),'ZIP_SHA256':m['後発コード']['ZIP_SHA256'],
                      '独立金融検算SHA256':args.proof_sha256},ensure_ascii=False))


if __name__ == '__main__':
    main()
