"""135の非金融診断・結果後の変更群・未採用の外部調査を正式な根拠へ移す。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT / 'study/00135_公表差で不安定な方向上書きを抑える'


def sha(body: bytes) -> str:
    """
    機能: 根拠の指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def put(source: Path, target: Path, packed: bool = False) -> dict:
    """
    機能: 根拠原文を未作成先へ一度保存する。
    引数: source/target(Path)、packed(bool)。
    返り値: dictは原文と保存指紋。
    """
    body = source.read_bytes(); saved = gzip.compress(body,mtime=0) if packed else body
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as handle: handle.write(saved)
    return {'由来': source.relative_to(ROOT).as_posix(),'保存元': target.relative_to(ROOT).as_posix(),
            '保存SHA256':sha(saved),'原文SHA256':sha(body),'形式':'gzip' if packed else '同体'}


# ----------------------------------------
def main() -> None:
    """
    機能: 結果後の説明をF1原文から分離し、正式閲覧をwork依存にしない。
    引数: なし。
    返り値: None。金融計算やRaw/巨大派生入力読取は行わない。
    """
    diag = ROOT/'work/同じ79出生における公表差の診断'
    root_cause = ROOT/'work/135方向差の結果を分解する'
    external = ROOT/'work/次入口の因果順序を外部資料から整理する'
    assert sha((diag/'遅延変更5件の原因.json').read_bytes()) == 'cdffc1868159916806c49dbc812eb15b51aa3fdd697c6b9fc42580ad92562eb6'
    assert sha((root_cause/'変更群の分解.json').read_bytes()) == '3c76e021b0289a76d9b8217c6eea55f836857cd98249f74e8dc933e700a9cc71'
    records = []
    for source, name, packed in [
        (diag/'結果.md','同じ79出生の公表差.md',False),
        (diag/'F0.json','公表差診断のF0.json',False),
        (diag/'人工の確認.json','公表差診断の人工確認.json',False),
        (diag/'完了の確認.json','公表差診断の完了.json',False),
        (diag/'集約.json','公表差の集約.json.gz',True),
        (diag/'遅延変更5件の原因.json','遅延変更5件の原因.json',False),
        (root_cause/'変更群の分解.json','変更群の分解.json.gz',True),
        (external/'出典と確認.json','外部出典の確認.json',False),
        (external/'候補の索引.json','外部候補の索引.json',False),
        (external/'完了.json','外部調査の完了.json',False),
    ]:
        records.append(put(source,FORMAL/'根拠'/name,packed))
    review = ROOT/'work/135金融前の独立確認/非金融の独立確認.json'
    assert sha(review.read_bytes()) == '7931f796b17dde9ba2ca1b5934aeb6268d223c02125c5500fb5db605b88e566f'
    records.append(put(review,FORMAL/'検査/非金融の独立確認.json'))
    original = (external/'README.md').read_bytes(); text = original.decode('utf-8')
    replacements = {
        '../../study/00119_技術領域の出生と確認後再試験で入口を比較する/README.md':'../../00119_技術領域の出生と確認後再試験で入口を比較する/README.md',
        '../120入口の1分構造/README.md':'../../00120_1分構造と無効化距離で入口を作る/README.md',
        '../129短期回復の出生/仕様.md':'../../00129_背景方向と短期構造回復で取得を早める/README.md',
    }
    for a,b in replacements.items(): assert a in text; text=text.replace(a,b)
    text+='\n## 正式保管時の注記\n\n135完了後の関連資料として保存した。上記E1/E2/E3はまだ採用・条件固定・金融検証していない。原文は後発コードZIPへ同体保存し、ここでは119/120/129へのリンクだけを正式試行READMEへ付け替えた。原文SHAは`'+sha(original)+'`。価格形成や指標状態を揃えず、公式解説を同幅先着率の証明へ読み替えない。\n'
    (FORMAL/'根拠/次入口の因果順序.md').write_text(text,encoding='utf-8')
    (FORMAL/'根拠/変更群の読み方.md').write_text('''# 135の結果後に変更群を分解する

[変更群JSON](変更群の分解.json.gz)はRootがchoicesと旧124観測から作った事後分析。主U0が旧C0と異なる13件はすべて公表不一致でSource復帰した群で、全13件H完了・IFD既知。C0は8順4逆1未/+28,999円、U0は2順9逆2未/−87,001円、差−116,000円。N0変更21件は−195,000円、D0変更5件は−52,000円だった。群の結果を次の選別規則として固定したものではない。

[同じ出生の非金融診断](同じ79出生の公表差.md)・[遅延5件の直接分岐](遅延変更5件の原因.json)は金融と取得価格を読まず整理した。D0変更5件の当該5/15/30分OHLCとEnd/B0が同体でも長期EMA増分が未知になった。reset/carry/warmupの内訳は未証明。

135の金融前F1と、この公表差診断の非金融F0は別の記録である。外部教材と[次入口案](次入口の因果順序.md)も未採用の調査であり、135の条件や主を変更しない。各原文/コードは[後発ZIP](../再現資料/検算と保管の追補コード.zip)へ保存した。
''',encoding='utf-8')
    manifest_path=FORMAL/'保管索引.json'; manifest=json.loads(manifest_path.read_bytes())
    manifest['非金融と事後の関連根拠']=records
    manifest['外部調査の原文SHA256']=sha(original)
    manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'関連根拠':len(records),'金融前F1変更':False,'新金融実行':False},ensure_ascii=False))


if __name__ == '__main__':
    main()
