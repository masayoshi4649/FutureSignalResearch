"""135の金融前MDとF1を先行退避し、方向票・非金融公表再生と最小コードを一度保存する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FORMAL = ROOT / 'study/00135_公表差で不安定な方向上書きを抑える'
OWN = ROOT / 'work/公表差で反転が不安定な入口を保守化する'
F1_SHA = '841514160f4ea92036a06688cbce5b1404f6f3ae0040751e0a7aa44b0211a0c2'


def sha(body: bytes) -> str:
    """
    機能: 保管内容の指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def put(path: Path, body: bytes) -> None:
    """
    機能: 未作成先へUTF-8又はgzip原文を保存する。
    引数: path(Path)、body(bytes)。
    返り値: None。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as handle:
        handle.write(body)


# ----------------------------------------
def record(source: Path, saved: Path, packed: bool) -> dict:
    """
    機能: 原文を同体又は一度だけgzip化して復元票を返す。
    引数: source/saved(Path)、packed(bool)。
    返り値: dictは由来/保存/解凍指紋。
    """
    body = source.read_bytes(); saved_body = gzip.compress(body, mtime=0) if packed else body
    put(saved, saved_body)
    return {'保存元': saved.relative_to(ROOT).as_posix(), '復元先': source.relative_to(ROOT).as_posix(),
            '形式': 'gzip' if packed else '同体', '保存bytes': len(saved_body), '保存SHA256': sha(saved_body),
            '解凍bytes': len(body), '解凍SHA256': sha(body)}


# ----------------------------------------
def main() -> None:
    """
    機能: 結果編集前の全4MDと15源を照合し、共有源を複製せず正式に保管する。
    引数: なし。
    返り値: None。Raw・巨大入力・新金融・CSV生成を実行しない。
    """
    original_f1 = (OWN / 'F1.json').read_bytes(); assert sha(original_f1) == F1_SHA
    f1 = json.loads(original_f1); assert len(f1['ファイル']) == 15
    docs = []; fixed_code = []
    for name, expected in f1['ファイル'].items():
        path = Path(name); relative = path.relative_to(ROOT).as_posix()
        if path.suffix in ('.md', '.py'):
            body = path.read_bytes(); assert sha(body) == expected
            if path.suffix == '.md':
                docs.append({'path': relative, 'bytes': len(body), 'sha256': sha(body), '本文': body.decode('utf-8')})
            fixed_code.append({'path': relative, 'bytes': len(body), 'sha256': sha(body)})
    assert len(docs) == 4 and len(fixed_code) == 9
    snapshot = {'試行': 135, '段階': '金融前F1に固定されたMDの結果編集前原文',
                '金融後に事前固定を偽造': False, '元F1_SHA256': F1_SHA, 'MD数': len(docs), '文書': docs}
    put(FORMAL / '検査/F1.json', original_f1)
    put(FORMAL / '検査/実行前文書.json.gz', gzip.compress((json.dumps(snapshot, ensure_ascii=False, indent=2)+'\n').encode('utf-8'),mtime=0))
    items = [record(OWN / 'choices.json', ROOT / 'inputs/00135_公表差一致の固定方向/choices.json.gz', True),
             record(ROOT / 'work/同じ79出生における公表差の診断/公表の再生結果.json', ROOT / 'inputs/00135_公表差一致の固定方向/公表の再生結果.json.gz', True)]
    for item in items:
        assert item['解凍SHA256'] == f1['ファイル'][str(ROOT / item['復元先'])]
    aggregate = (OWN / '集計.json').read_bytes()
    assert sha(aggregate) == '90b8ea3eeff6314b36f15637fcf7608c8336fe0202a9d3b41486ab91330a5c29'
    put(FORMAL / '成果物/集計.json', aggregate)
    record(OWN / '評価完了.json', FORMAL / '検査/評価完了.json', False)
    previous = ROOT / 'study/00131_中期MACDの位相で複合入口の方向を切り替える'
    shared_index = json.loads((previous / '再現資料/コード復元索引.json').read_bytes())
    shared_names = ['work/124入口の原因分析/集計する.py', 'work/131既存入口の位相切替評価/評価する.py']
    shared_code = [x for x in shared_index['格納源'] if x['path'] in shared_names]
    assert len(shared_code) == 2
    shared_archive = previous / '再現資料' / shared_index['ZIP']
    assert sha(shared_archive.read_bytes()) == shared_index['ZIP_SHA256']
    with zipfile.ZipFile(shared_archive) as z:
        for x in shared_code:
            assert sha(z.read(x['path'])) == x['sha256'] == f1['ファイル'][str(ROOT / x['path'])]
    new_code = [x for x in fixed_code if x['path'] not in shared_names]
    archive = FORMAL / '再現資料/135追加固定コード.zip'; archive.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for item in new_code:
            z.writestr(item['path'], (ROOT / item['path']).read_bytes())
    assert len(new_code) == 7
    shared = []
    prior = json.loads((previous / '保管索引.json').read_bytes())
    for item in prior['共有参照'][:3]:
        source = ROOT / item['保存元']; body = source.read_bytes(); decoded = gzip.decompress(body)
        assert sha(decoded) == item['解凍SHA'] == f1['ファイル'][str(ROOT / item['復元先'])]
        shared.append({'保存元': item['保存元'], '復元先': item['復元先'], '形式': 'gzip',
                       '保存SHA256': sha(body), '解凍SHA256': sha(decoded)})
    source = ROOT / 'inputs/00124_同入口正逆の共用入力/入力.json.gz'; body = source.read_bytes()
    assert sha(body) == f1['ファイル'][str(source)]
    shared.append({'保存元': source.relative_to(ROOT).as_posix(), '復元先': source.relative_to(ROOT).as_posix(),
                   '形式': '同体', '保存SHA256': sha(body), '解凍SHA256': sha(body)})
    manifest = {'試行': 135, 'F1_SHA256': F1_SHA, '新共用入力': items, '共有参照': shared,
                '集計SHA256': sha(aggregate), '共有固定コード': {'保存元ZIP': shared_archive.relative_to(ROOT).as_posix(),
                  'ZIP_SHA256': shared_index['ZIP_SHA256'], '格納源数': len(shared_code), '格納源': shared_code},
                '追加固定コード': {'ZIP': archive.name, 'ZIP_SHA256': sha(archive.read_bytes()),
                  'ZIP_bytes': archive.stat().st_size, '格納源数': len(new_code), '格納源': new_code},
                '旧観測/124特徴/126集計の恒久複製': False, '原板/巨大入力読取': False, '新金融実行': False}
    put(FORMAL / '保管索引.json', (json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功': True, '金融前原文MD': len(docs), 'F1_SHA256': F1_SHA,
                      '固定コード共有/新規': [2,7], '新入力gzip': len(items),
                      'gzip計bytes': sum(x['保存bytes'] for x in items), '結果編集前に退避': True},ensure_ascii=False))


if __name__ == '__main__':
    main()
