"""独立算術の未知・touch優先・費用・実側正逆を人工例で点検する。"""
import copy
import importlib.util
import unittest
from pathlib import Path

SPEC=importlib.util.spec_from_file_location('独立135',Path(__file__).with_name('検算する.py'))
M=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)


def candidate(side: int=1, axis: str='BBO', status: str='complete', direction: int=0) -> dict:
    """
    機能: 一つの清算時点だけを持つ独立人工候補を組み立てる。
    引数: side(int)、axis/status(str)、direction(int)は向き・軸・H状態・先着。
    返り値: dictは市場データを含まない人工票。
    """
    entry={'time':0,'index':1,'source_line':1,'last':1005,'bid':1000,'ask':1010,'quote_ok':True}
    quote={'time':3600,'index':2,'source_line':2,'last':1010,'bid':1005,'ask':1015,'quote_ok':True}
    price=entry['last'] if axis=='Last' else entry['ask'] if side>0 else entry['bid']
    return {'birth':{'side':side},'entry':entry,'entry_price':price,
            'outcomes':[{'seconds':3600,'status':status,'deadline':3600,
                         'endpoint':quote if status=='complete' else None,
                         'touches':[{'width':5,'direction':direction,'quote':quote if direction else None}]}]}


class IndependentTests(unittest.TestCase):
    """保存値とは無関係の人工例で主要な分母と清算式を確認する。"""

    def test_touch_before_later_censor(self) -> None:
        """
        機能: 後のH不足でも既知touchのIFDを保持することを検査する。
        引数: self(IndependentTests)は検査インスタンス。
        返り値: None。不一致時は検査が失敗する。
        """
        c=candidate(status='phase_censored',direction=-1)
        self.assertEqual(M.ifd(c,3600,5,'BBO'),{'known':True,'reason':'逆行到達','points':-5,'net0':-577,'net5':-1577})
        r={'session':'人工場','case':{'original':c,'original_side':1},'choice':{'choices':{'U0':{'side':1}}}}
        s=M.stats([r],'U0','BBO',3600,5)
        self.assertEqual((s['entries'],s['complete'],s['censored'],s['resolved'],s['ifd_known']),(1,0,1,0,1))
        self.assertIsNone(s['resolved_rate'])

    def test_unknown_is_not_zero(self) -> None:
        """
        機能: H不足かつ未到達を未知とし、損益0や分母からの除去にしないことを検査する。
        引数: self(IndependentTests)は検査インスタンス。
        返り値: None。不一致時は検査が失敗する。
        """
        c=candidate(status='censored')
        x=M.ifd(c,3600,5,'BBO')
        self.assertEqual(x,{'known':False,'reason':'観測不足','points':None,'net0':None,'net5':None})
        r={'session':'人工場','case':{'original':c,'original_side':1},'choice':{'choices':{'U0':{'side':1}}}}
        s=M.stats([r],'U0','BBO',3600,5)
        self.assertEqual((s['entries'],s['censored'],s['ifd_unknown']),(1,1,1))
        self.assertIsNone(s['ifd_net5_sum']);self.assertIsNone(s['ifd_net5_profit'])

    def test_costs_and_last_money(self) -> None:
        """
        機能: mini1枚の往復費用77/1077円とLastの金額未知を検査する。
        引数: self(IndependentTests)は検査インスタンス。
        返り値: None。不一致時は検査が失敗する。
        """
        c=candidate();x=M.ifd(c,3600,5,'BBO')
        self.assertEqual((x['points'],x['net0'],x['net5']),(-5,-577,-1577))
        chart=candidate(axis='Last');y=M.ifd(chart,3600,5,'Last')
        self.assertEqual(y['points'],5);self.assertIsNone(y['net0']);self.assertIsNone(y['net5'])
        z=copy.deepcopy(c);z['outcomes'][0]['endpoint']['bid']=1030
        self.assertEqual(M.ifd(z,3600,5,'BBO')['net5'],923)

    def test_actual_reverse_can_also_lose(self) -> None:
        """
        機能: 同一Quoteの実BBOでは正逆双方が損失となり得ることを検査する。
        引数: self(IndependentTests)は検査インスタンス。
        返り値: None。反転を単純な1−pで補完しないことを確認する。
        """
        a=candidate(side=1);b=candidate(side=-1)
        self.assertEqual(M.ifd(a,3600,5,'BBO')['points'],-5)
        self.assertEqual(M.ifd(b,3600,5,'BBO')['points'],-15)
        self.assertLess(M.ifd(a,3600,5,'BBO')['net5'],0)
        self.assertLess(M.ifd(b,3600,5,'BBO')['net5'],0)


if __name__=='__main__':unittest.main(verbosity=2)
