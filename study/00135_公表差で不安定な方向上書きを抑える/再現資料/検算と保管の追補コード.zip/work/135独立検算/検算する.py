"""135の固定方向票と保存Quoteを独立式で照合する。Root/124金融算術は呼ばない。"""
import datetime
import gzip
import hashlib
import json
import math
from collections import Counter
from fractions import Fraction
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
POLICIES=('U0','C0','N0','D0','O0','R0')
WIDTHS=(25,50,100,125,200)
HORIZONS=(1800,3600)
AXES=('BBO','Last')

def sha(path: Path) -> str:
    """
    機能: ファイルのSHA256を求める。
    引数: path(Path)は対象。
    返り値: strは小文字16進SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()

def equal(actual: object, expected: object, location: str='') -> int:
    """
    機能: 型・未知・有限数値を区別して再帰照合する。
    引数: actual/expected(object)、location(str)は実値・期待値・位置。
    返り値: intは一致した末端値の数。不一致はAssertionError。
    """
    if isinstance(expected,dict):
        assert isinstance(actual,dict) and actual.keys()==expected.keys(),(location,'keys')
        return sum(equal(actual[k],v,location+'/'+str(k)) for k,v in expected.items())
    if isinstance(expected,list):
        assert isinstance(actual,list) and len(actual)==len(expected),(location,'length')
        return sum(equal(a,b,location+'/'+str(i)) for i,(a,b) in enumerate(zip(actual,expected)))
    if expected is None or type(expected) is bool:
        assert type(actual) is type(expected) and actual==expected,(location,actual,expected)
    elif type(expected) in (int,float):
        assert type(actual) in (int,float) and math.isfinite(actual) and math.isclose(actual,expected,rel_tol=1e-12,abs_tol=1e-8),(location,actual,expected)
    else:assert actual==expected,(location,actual,expected)
    return 1

def observation(candidate: dict, horizon: int) -> dict:
    """
    機能: 指定期限の観測を一意に取り出す。
    引数: candidate(dict)、horizon(int)は候補と秒数。
    返り値: dictは観測。
    """
    matches=[o for o in candidate['outcomes'] if o['seconds']==horizon];assert len(matches)==1
    return matches[0]

def touch(outcome: dict, width: int) -> dict:
    """
    機能: 同幅の保存先着を一意に取り出す。
    引数: outcome(dict)、width(int)は観測とpt。
    返り値: dictは先着票。
    """
    matches=[t for t in outcome['touches'] if t['width']==width];assert len(matches)==1
    return matches[0]

def points(candidate: dict, quote: dict, axis: str) -> int | float:
    """
    機能: 保存清算Quoteから実側の符号付き値幅を計算する。
    引数: candidate/quote(dict)、axis(str)は取得・清算・軸。
    返り値: int|floatはpt。
    """
    side=candidate['birth']['side'];mark=quote['last'] if axis=='Last' else quote['bid'] if side>0 else quote['ask']
    return side*(mark-candidate['entry_price'])

def ifd(candidate: dict, horizon: int, width: int, axis: str) -> dict:
    """
    機能: 既知touch優先でIFD代用を算出し、H不足の未到達は未知にする。
    引数: candidate(dict)、horizon/width(int)、axis(str)は方向と観測条件。
    返り値: dictは既知/理由/pt/C0/C5。Lastの金額はNone。
    """
    o=observation(candidate,horizon);t=touch(o,width)
    if t['direction']:
        quote=t['quote'];reason='順行到達' if t['direction']>0 else '逆行到達'
    elif o['status']=='complete':quote=o['endpoint'];reason='期限清算'
    else:return {'known':False,'reason':'観測不足','points':None,'net0':None,'net5':None}
    assert quote is not None
    p=points(candidate,quote,axis)
    return {'known':True,'reason':reason,'points':p,
            'net0':p*100-77 if axis=='BBO' else None,'net5':p*100-1077 if axis=='BBO' else None}

def stats(records: list[dict], policy: str, axis: str, horizon: int, width: int) -> dict:
    """
    機能: 保存QuoteとFractionから全率/分母/利益/損失/PFを独立集計する。
    引数: records(list[dict])、policy/axis(str)、horizon/width(int)は取得集合と条件。
    返り値: dictは主算術集計。Root集計/124算術を呼ばない。
    """
    selected=[choose(r,policy,axis) for r in records]
    complete=[observation(c,horizon) for c in selected if observation(c,horizon)['status']=='complete']
    counts=Counter(touch(o,width)['direction'] for o in complete);forward=counts[1];adverse=counts[-1];resolved=forward+adverse
    exits=[ifd(c,horizon,width,axis) for c in selected];known=[e for e in exits if e['known']]
    money=[e['net5'] for e in known] if axis=='BBO' else []
    profit=sum(x for x in money if x>0);loss=-sum(x for x in money if x<0)
    return {'entries':len(records),'sessions':len({r['session'] for r in records}),
            'complete':len(complete),'censored':len(selected)-len(complete),
            'forward':forward,'adverse':adverse,'neither':counts[0],'resolved':resolved,
            'resolved_rate':float(Fraction(forward,resolved)) if resolved else None,
            'complete_rate':float(Fraction(forward,len(complete))) if complete else None,
            'target70':Fraction(forward,resolved)>=Fraction(7,10) if resolved else None,
            'target70_all':Fraction(forward,len(complete))>=Fraction(7,10) if complete else None,
            'ifd_known':len(known),'ifd_unknown':len(exits)-len(known),
            'ifd_exits':dict(Counter(e['reason'] for e in exits)),
            'ifd_net0_sum':sum(e['net0'] for e in known) if axis=='BBO' and known else None,
            'ifd_net5_sum':sum(money) if money else None,
            'ifd_net5_mean':float(Fraction(sum(money))/len(money)) if money else None,
            'ifd_net5_profit':profit if money else None,'ifd_net5_loss':loss if money else None,
            'ifd_net5_pf':float(Fraction(profit)/Fraction(loss)) if loss else None,
            'ifd_net5_positive':sum(x>0 for x in money) if axis=='BBO' else None,
            'ifd_points_mean':float(Fraction(sum(e['points'] for e in known))/len(known)) if known else None,
            'flips':sum(c['birth']['side']!=r['case']['original_side'] for c,r in zip(selected,records))}

def jst(at: float) -> str:
    """
    機能: Unix秒を閲覧表の日本時間書式へ変換する。
    引数: at(float)は時刻。
    返り値: strは秒精度のJST。
    """
    return datetime.datetime.fromtimestamp(at,datetime.timezone(datetime.timedelta(hours=9))).isoformat(sep=' ')


def side_for(record: dict, policy: str) -> int:
    """
    機能: 金融結果を参照せず固定票の政策方向を選ぶ。
    引数: record(dict)、policy(str)は結合票と政策。
    返り値: intは買い1又は売り−1。
    """
    return record['choice']['choices'][policy]['side']


def choose(record: dict, policy: str, axis: str) -> dict:
    """
    機能: 同一取得時点の実BBO正逆又はLast参考を選ぶ。
    引数: record(dict)、policy/axis(str)は結合票・政策・価格軸。
    返り値: dictは保存候補。反転を1−pで推定しない。
    """
    name='original' if side_for(record,policy)==record['case']['original_side'] else 'reverse'
    return record['case'][('chart_' if axis=='Last' else '')+name]


def subset(records: list[dict], sessions: list[str]) -> list[dict]:
    """
    機能: 同一79例から指定セッションの票を選ぶ。
    引数: records(list[dict])、sessions(list[str])は全票と対象場。
    返り値: list[dict]は未到達・不足を除外しない部分集合。
    """
    return [r for r in records if r['session'] in sessions]


def join(choices: dict, result: dict, fixed: dict, previous: dict) -> tuple[list[dict],list[str],dict]:
    """
    機能: 固定票を正逆観測へ一対一結合し、方向式・全選択streamのphaseを点検する。
    引数: choices/result/fixed/previous(dict)は方向票・旧観測・固定入力・旧131票。
    返り値: tupleは79結合票、73場順、phase検査件数。
    """
    assert choices['成功'] and choices['試行']==135 and choices['主']=='U0'
    assert choices['policies']==list(POLICIES) and choices['金融結果読取'] is False and choices['原板読取'] is False
    sessions=choices['sessions'];assert len(sessions)==len(set(sessions))==73
    assert sessions==[s['session'] for s in result['scenes']]==[s['session'] for s in fixed['scenes']]
    assert result['success'] and result['trial']==124 and result['source_entry_count']==79
    fs={s['session']:s for s in fixed['scenes']};rs={s['session']:s for s in result['scenes']}
    priors={(c['session'],c['id']):c for c in previous['choices']}
    cases={(s['session'],c['id']):c for s in result['scenes'] for c in s['cases']}
    inputs={(s['session'],c['id']):c for s in fixed['scenes'] for c in s['entries']}
    records=[];seen=set();counts=Counter()
    for m in choices['choices']:
        key=(m['session'],m['id']);assert key in cases and key in priors and key not in seen;seen.add(key)
        sid=m['session'];c=cases[key];f=fs[sid];s=rs[sid];old=priors[key];entry=m['entry_quote']
        assert s['success'] and s['actual_sha256']==f['raw']['sha256'] and s['quality']==s['expected_quality']==f['expected_quality']
        assert c['id']==inputs[key]['id'] and c['original_side']==m['original_side']==inputs[key]['side']==old['original_side']
        assert m['strategy']==old['strategy'] and m['path']==old['path'] and m['partition_reference']==('train' if sid in sessions[:48] else 'validation')
        equal(entry,inputs[key]['entry'],'固定取得')
        for k in ('time','index','source_line'):
            equal(m['birth_quote'][k],old['birth'][k],'旧出生時計')
            equal(entry[k],old['entry'][k],'旧取得時計')
        assert entry['time']>=m['birth_quote']['time'] and entry['index']>m['birth_quote']['index'] and entry['source_line']>m['birth_quote']['source_line']
        v=m['inputs'];valid=lambda x:type(x) is int and x in (-1,1)
        available=all(valid(v[k]) for k in ('csv','instant','delay'))
        unanimous=available and len(set(v.values()))==1
        e0=m['strategy']=='E0'
        equal(m['all_available'],available);equal(m['unanimous'],unanimous);equal(m['e0_protected'],e0)
        assert valid(v['csv']) and v['csv']==old['t8_side']
        base=m['original_side'];main=base if e0 or not unanimous else v['csv']
        sides={'U0':main,'C0':v['csv'],'N0':v['instant'] if valid(v['instant']) else base,
               'D0':v['delay'] if valid(v['delay']) else base,'O0':base,'R0':-main}
        if e0:assert all(value==base for value in v.values())
        for p,side in sides.items():equal(m['choices'][p],{'side':side,'action':'keep' if side==base else 'flip'},'方向/'+p)
        r={'session':sid,'case':c,'choice':m};records.append(r);boundary=f['end']-300
        for p in POLICIES:
            for axis in AXES:
                stream=choose(r,p,axis);side=side_for(r,p)
                assert stream['status']=='filled' and stream['axis']==('BBO' if axis=='BBO' else 'Last価格方向診断') and stream['birth']['side']==side
                equal(stream['entry'],entry,'観測取得')
                assert stream['entry_price']==(entry['last'] if axis=='Last' else entry['ask'] if side>0 else entry['bid'])
                assert entry['time']<boundary and entry['quote_ok'] and 0<entry['bid']<entry['ask']
                counts['選択stream検査']+=1;counts['entry検査']+=1
                assert tuple(o['seconds'] for o in stream['outcomes'])==HORIZONS
                for o in stream['outcomes']:
                    assert o['deadline']==entry['time']+o['seconds'] and tuple(t['width'] for t in o['touches'])==WIDTHS
                    assert (o['endpoint'] is not None)==(o['status']=='complete')
                    q=o['endpoint']
                    if q is not None:
                        assert o['deadline']<=q['time']<=o['deadline']+30 and q['time']<boundary
                        assert q['index']>entry['index'] and q['source_line']>entry['source_line'] and q['quote_ok'] and 0<q['bid']<q['ask']
                        pt=points(stream,q,axis);equal(o['points'],pt);equal(o['net0'],pt*100-77 if axis=='BBO' else None);equal(o['net5'],pt*100-1077 if axis=='BBO' else None)
                        counts['endpoint検査']+=1
                    else:assert o['points'] is None and o['net0'] is None and o['net5'] is None
                    for t in o['touches']:
                        assert type(t['direction']) is int and t['direction'] in (-1,0,1)
                        q=t['quote'];assert (q is None)==(t['direction']==0)
                        if q is None:continue
                        assert entry['time']<=q['time']<=o['deadline'] and q['time']<boundary
                        assert q['index']>entry['index'] and q['source_line']>entry['source_line'] and q['quote_ok'] and 0<q['bid']<q['ask']
                        pt=points(stream,q,axis);assert pt>=t['width'] if t['direction']>0 else pt<=-t['width']
                        counts['touch検査']+=1
    assert seen==set(cases)==set(inputs)==set(priors) and len(records)==79
    assert all(any(r['session']==sid for r in records) for sid in sessions)
    return records,sessions,dict(counts)


def tables_check(tables: list[dict], records: list[dict], sessions: list[str], values: dict) -> dict:
    """
    機能: 独立算術からCSV用3表の全セルを照合する。
    引数: tables/records/sessions(list)、values(dict)は保存表と独立期待値。
    返り値: dictは照合セル数と寸法。実CSV再読や描画の代わりにはしない。
    """
    assert [(t['name'],len(t['rows']),len(t['headers'])) for t in tables]==[('正逆比較',360,28),('入口別診断',79,52),('全セッション',73,77)]
    parts={'all':sessions,'train':sessions[:48],'validation':sessions[48:]};cells=0;seen=set()
    for row in tables[0]['rows']:
        a=dict(zip(tables[0]['headers'],row));part=a['区分'];p=a['政策'];axis=a['価格軸'];h=int(a['評価分']*60);w=a['同幅pt']
        key=(part,p,axis,h,w);assert key not in seen;seen.add(key);s=values[part][p][axis][str(h)][str(w)]
        participation=s['sessions']==len(parts[part])
        e={'試行':135,'区分':part,'政策':p,'価格軸':axis,'評価分':h/60,'同幅pt':w,'対象場数':len(parts[part]),
           '取得場数':s['sessions'],'取得数':s['entries'],'最低1取得達成':participation,'元方向から反転数':s['flips'],
           '全H完了':s['complete'],'観測不足':s['censored'],'順行先着':s['forward'],'逆行先着':s['adverse'],'未到達':s['neither'],
           '到達済み順行率':s['resolved_rate'],'未到達込率':s['complete_rate'],'到達済み70%':s['target70'],
           '参加と70%両達成':bool(participation and s['target70'] is True),'IFD既知':s['ifd_known'],'IFD未知':s['ifd_unknown'],
           'C0代用差引円':s['ifd_net0_sum'],'C5代用利益円':s['ifd_net5_profit'],'C5代用損失絶対円':s['ifd_net5_loss'],
           'C5代用差引円':s['ifd_net5_sum'],'C5代用平均円':s['ifd_net5_mean'],'C5代用PF':s['ifd_net5_pf']}
        cells+=equal(a,e,'比較表/'+str(key))
    assert len(seen)==360
    t=tables[1];assert [row[t['headers'].index('出生ID')] for row in t['rows']]==[r['case']['id'] for r in records]
    for row,r in zip(t['rows'],records):
        m=r['choice'];c=r['case'];e={'試行':135,'参考区分':m['partition_reference'],'セッション':r['session'],'出生ID':c['id'],
            '入口型':m['strategy'],'元方向':m['original_side'],'出生JST':jst(m['birth_quote']['time']),'取得JST':jst(m['entry_quote']['time']),
            '元取得価格':c['original']['entry_price'],'逆取得価格':c['reverse']['entry_price'],'CSV方向':m['inputs']['csv'],
            'Raw即時方向':m['inputs']['instant'],'Raw遅延方向':m['inputs']['delay'],'三公表利用可':m['all_available'],
            '三公表一致':m['unanimous'],'主の理由':m['reason']}
        for p in POLICIES:
            q=choose(r,p,'BBO');o=observation(q,3600);x=ifd(q,3600,125,'BBO')
            e.update(zip([p+n for n in ('方向','全H','先着','IFD既知','清算理由','C5代用円')],
                         [side_for(r,p),o['status'],touch(o,125)['direction'],x['known'],x['reason'],x['net5']]))
        cells+=equal(dict(zip(t['headers'],row)),e,'入口表/'+c['id'])
    t=tables[2];assert [row[t['headers'].index('セッション')] for row in t['rows']]==sessions
    cumulative=Counter();unknown=Counter()
    for i,(row,sid) in enumerate(zip(t['rows'],sessions)):
        rs=subset(records,[sid]);e={'試行':135,'セッション':sid,'参考区分':'train' if i<48 else 'validation','取得数':len(rs),'最低1取得':bool(rs)}
        for p in POLICIES:
            s=stats(rs,p,'BBO',3600,125);cumulative[p]+=s['ifd_net5_sum'] or 0;unknown[p]+=s['ifd_unknown']
            e.update({p+'反転数':s['flips'],p+'順':s['forward'],p+'逆':s['adverse'],p+'未到達':s['neither'],p+'不足':s['censored'],
                      p+'IFD既知':s['ifd_known'],p+'IFD未知':s['ifd_unknown'],p+'C5利益円':s['ifd_net5_profit'],
                      p+'C5損失絶対円':s['ifd_net5_loss'],p+'C5差引円':s['ifd_net5_sum'],p+'C5既知累計円':cumulative[p],p+'累計未知':unknown[p]})
        cells+=equal(dict(zip(t['headers'],row)),e,'場表/'+sid)
    assert cells==19809
    return {'success':True,'table_dimensions':[[360,28],[79,52],[73,77]],'all_data_cells_equal':cells,'actual_csv_reread_or_render':False}


def main() -> None:
    """
    機能: 固定SHAから全360条件・3表・旧120条件・主目標を独立確認する。
    引数: なし。方向票と保存正逆だけを使い、原板やRoot金融算術を読込実行しない。
    返り値: None。新しい独立確認JSONを保存する。
    """
    paths={
        'choices':('work/公表差で反転が不安定な入口を保守化する/choices.json','4855a482f85a5dac40611e961e7a9d03efd9e4c79311cad1021e3bc9f80cd9d1'),
        'aggregate':('work/公表差で反転が不安定な入口を保守化する/集計.json','90b8ea3eeff6314b36f15637fcf7608c8336fe0202a9d3b41486ab91330a5c29'),
        'tables':('work/公表差で反転が不安定な入口を保守化する/CSV用の表.json','dff78180df502ee24f642defded977b187a655d3045c130384479e79a88dda7b'),
        'completion':('work/公表差で反転が不安定な入口を保守化する/評価完了.json','3a81193da6cfe70d7bc0c8051d76597a68630f42de2477fbfc49e310924d048f'),
        'F1':('work/公表差で反転が不安定な入口を保守化する/F1.json','841514160f4ea92036a06688cbce5b1404f6f3ae0040751e0a7aa44b0211a0c2'),
        'fixed':('inputs/00124_同入口正逆の共用入力/入力.json.gz','717f41674a4c99f94545a5e147495ae66498dbbc1afa48d7f34d04c40514843b'),
        'pairs':('work/124入口の正逆比較/全73場の正逆結果.json','25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1'),
        'old131':('work/131既存入口の位相切替評価/集計.json','252a8d1744fe340b57a23db5c46d7dc7abd467fdfa59d273ce42f497b04843f3'),
        'old_choices':('work/T8の15分位相による切替案/choices.json','cdf1f0c6248d76222d49c7d872094cce20edecb7f52aa9e725d1040aa51f17c3')}
    assert all(sha(ROOT/p)==h for p,h in paths.values())
    load=lambda k:json.loads((ROOT/paths[k][0]).read_text(encoding='utf-8-sig'))
    fixed_bytes=gzip.decompress((ROOT/paths['fixed'][0]).read_bytes())
    assert hashlib.sha256(fixed_bytes).hexdigest()=='b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
    choices,aggregate,tables,completion=load('choices'),load('aggregate'),load('tables'),load('completion')
    assert completion['成功'] and completion['試行']==135 and completion['全固定ファイル前後同体']
    assert completion['集計SHA256']==paths['aggregate'][1] and completion['表SHA256']==paths['tables'][1] and completion['F1_SHA256']==paths['F1'][1]
    assert aggregate['成功'] and aggregate['試行']==135 and aggregate['主政策']=='U0' and aggregate['全期間既使用'] and not aggregate['独立未知期']
    assert aggregate['F1_SHA256']==paths['F1'][1] and aggregate['Raw再読'] is False and aggregate['口座損益'] is False
    records,sessions,phase=join(choices,load('pairs'),json.loads(fixed_bytes),load('old_choices'))
    parts={'all':sessions,'train':sessions[:48],'validation':sessions[48:]};values={};conditions=0;leaves=0
    for part,ids in parts.items():
        rs=subset(records,ids);values[part]={}
        for p in POLICIES:
            values[part][p]={}
            for axis in AXES:
                values[part][p][axis]={}
                for h in HORIZONS:
                    values[part][p][axis][str(h)]={}
                    for w in WIDTHS:
                        s=stats(rs,p,axis,h,w);values[part][p][axis][str(h)][str(w)]=s
                        leaves+=equal(aggregate['集計'][part][p][axis][str(h)][str(w)],s,f'集計/{part}/{p}/{axis}/{h}/{w}');conditions+=1
    assert conditions==360
    phase_expected={'成功':True,'境界':'各SourceScene.End−300、等号違反で停止','対象':'全6政策/両軸/両H/全幅、重複選択を含む',
                    **phase,'新規2分buffer再適用':False,'未知0円化':False}
    equal(aggregate['全選択streamのphase検査'],phase_expected,'phase')
    main_s=values['all']['U0']['BBO']['3600']['125'];participation=main_s['sessions']==73
    equal(aggregate['目標判定'],{'全73場最低1取得':participation,'到達済み70%以上':main_s['target70'],
          '両条件達成':bool(participation and main_s['target70'] is True),'取得数':main_s['entries'],'順':main_s['forward'],
          '逆':main_s['adverse'],'未到達':main_s['neither'],'不足':main_s['censored']},'目標')
    for p in POLICIES:
        kinds=Counter();diffs=[]
        for r in records:
            a=ifd(choose(r,p,'BBO'),3600,125,'BBO');b=ifd(choose(r,'C0','BBO'),3600,125,'BBO')
            k='both' if a['known'] and b['known'] else 'policy' if a['known'] else 'reference' if b['known'] else 'none';kinds[k]+=1
            if k=='both':diffs.append(a['net5']-b['net5'])
        e={'比較政策':p,'対照政策':'C0','同case数':79,'両側既知':kinds['both'],'比較側だけ既知':kinds['policy'],
           '対照側だけ既知':kinds['reference'],'両側未知':kinds['none'],'C5既知ペア差引円':sum(diffs),
           'C5既知ペア平均差円':float(Fraction(sum(diffs))/len(diffs)) if diffs else None}
        equal(aggregate['同caseのC0との差'][p],e,'同case差/'+p)
    old=load('old131');old_count=0
    for part in parts:
        for p,prior in (('C0','T8'),('O0','O0')):
            for axis in AXES:
                for h in HORIZONS:
                    for w in WIDTHS:
                        equal(values[part][p][axis][str(h)][str(w)],old['集計'][part][prior][axis][str(h)][str(w)],'旧120');old_count+=1
    assert old_count==120 and aggregate['旧対照120条件同体'] is True
    table_proof=tables_check(tables['tables'],records,sessions,values)
    assert all(sha(ROOT/p)==h for p,h in paths.values())
    proof={'success':True,'trial':135,'condition_count':conditions,'aggregate_leaf_values_checked':leaves,
        'entries':len(records),'sessions':len(sessions),'all_sessions_minimum_one':participation,'phase_checks':phase,
        'table_checks':table_proof,'old_conditions_identical':old_count,'main':main_s,
        'main_policies':{p:values['all'][p]['BBO']['3600']['125'] for p in POLICIES},
        'front48':values['train']['U0']['BBO']['3600']['125'],'back25':values['validation']['U0']['BBO']['3600']['125'],
        'source_hashes_before_after_equal':True,'sources':{p:h for p,h in paths.values()},'code_sha256':sha(Path(__file__)),
        'Root_or_124_arithmetic_imported':False,'raw_reread':False,'bootstrap_reimplemented':False,
        'source_conditions_or_parameters_edited':False,'independent_unknown_period':False,
        'first_touch_within_missing_gap_reconstructed':False,'actual_order_eligibility_rebuilt':False}
    out=HERE/'独立確認.json';assert not out.exists();out.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'success':True,'proof_sha256':sha(out),'conditions':conditions,'table_cells':table_proof['all_data_cells_equal'],'main':main_s},ensure_ascii=False))


if __name__=='__main__':main()

