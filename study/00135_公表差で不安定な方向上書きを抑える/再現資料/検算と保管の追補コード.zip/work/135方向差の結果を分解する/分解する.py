"""事前固定した135の変更例を事後診断する。新しい売買規則は作らない。"""
from pathlib import Path
from collections import Counter
import importlib.util
import json
import hashlib

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
RUN = ROOT / 'work/公表差で反転が不安定な入口を保守化する'


def load(path: Path, name: str) -> object:
    """
    機能: 既存の保存観測算術をmainを呼ばず読み込む。
    引数: path(Path)、name(str)。
    返り値: objectは私有モジュール。
    """
    spec = importlib.util.spec_from_file_location(name,path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ----------------------------------------
def summarize(rows: list[dict], policy: str, arithmetic: object) -> dict:
    """
    機能: 保存された先着とIFD代用を固定算術で集計する。
    引数: rows(list[dict])、policy(str)、arithmetic(object)。
    返り値: dictはH60/±125の集計。
    """
    return arithmetic.stats(rows,policy,'BBO',3600,125)


# ----------------------------------------
def main() -> None:
    """
    機能: C0との方向変更群を理由・入口型で分け、実BBO両側の結果を残す。
    引数: なし。
    返り値: None。新Raw、閾値探索、入口の除外を行わない。
    """
    choices_path = RUN/'choices.json'
    finance_path = ROOT/'work/124入口の正逆比較/全73場の正逆結果.json'
    before = {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in (choices_path,finance_path)}
    choices = json.loads(choices_path.read_bytes())
    data = json.loads(finance_path.read_bytes())
    shared = load(ROOT/'work/131既存入口の位相切替評価/評価する.py','135事後診断の旧関数')
    shared.POLICIES = ('U0','C0','N0','D0','O0','R0')
    arithmetic = shared.module124()
    mapping = {(c['session'],c['id']):c for c in choices['choices']}
    records = [{'session':s['session'],'case':c,'choice':mapping[(s['session'],c['id'])]}
               for s in data['scenes'] for c in s['cases']]
    assert len(records) == 79 and len({r['session'] for r in records}) == 73
    changes = {}
    for policy in ('U0','N0','D0'):
        changed = [r for r in records if r['choice']['choices'][policy]['side'] != r['choice']['choices']['C0']['side']]
        same = [r for r in records if r not in changed]
        types = {}
        for strategy in sorted({r['choice']['strategy'] for r in changed}):
            rows = [r for r in changed if r['choice']['strategy'] == strategy]
            types[strategy] = {'件数':len(rows),'C0':summarize(rows,'C0',arithmetic),
                               policy:summarize(rows,policy,arithmetic),'差':shared.paired(rows,policy,'C0',arithmetic)}
        details = []
        for r in changed:
            item = {'session':r['session'],'id':r['case']['id'],'strategy':r['choice']['strategy'],
                    '理由':r['choice']['reason'],'inputs':r['choice']['inputs']}
            for p in ('C0',policy):
                c = shared.selected(r,p,'BBO')
                o = arithmetic.observation(c,3600)
                e = arithmetic.ifd(c,o,125,'BBO')
                item[p] = {'方向':r['choice']['choices'][p]['side'],'全H':o['status'],
                           '先着':arithmetic.touch(o,125)['direction'],'IFD':e}
            details.append(item)
        changes[policy] = {'変更数':len(changed),'同方向数':len(same),'理由':dict(Counter(r['choice']['reason'] for r in changed)),
                           '変更群C0':summarize(changed,'C0',arithmetic),'変更群政策':summarize(changed,policy,arithmetic),
                           '変更群の差':shared.paired(changed,policy,'C0',arithmetic),'入口型別':types,'全変更例':details}
    result = {'成功':True,'試行':135,'性質':'結果後の原因分解。選別群を新たな規則/未知検証としない',
              '入力SHA256':before,'変更比較':changes,'Raw再読':False,'新しい売買規則':False}
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == value for p,value in before.items())
    dest = OWN/'変更群の分解.json'
    with dest.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
    print(json.dumps({p:{k:v for k,v in x.items() if k not in ('全変更例','入口型別')} for p,x in changes.items()},ensure_ascii=False))


if __name__ == '__main__':
    main()
