"""旧79出生を固定し、既存Bankとdirection133で公表差だけを非金融診断する。"""
from pathlib import Path
from collections import Counter
import argparse
import hashlib
import json
import os
import subprocess

OWN = Path(__file__).resolve().parent
ROOT = OWN.parent.parent
NATIVE = ROOT / 'work/強い入口の探索期限を延ばす次仮説/Source入口の再生器'
FEATURES = ROOT / 'work/124当時特徴の診断/全79例の当時特徴.json'
SOURCE = ROOT / 'work/133探索期限の評価/Sourceの出生と取得.json'
INPUTS = [
    ('csv', ROOT / 'work/122全場入力/入力.json', '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'),
    ('instant', ROOT / 'work/P3をRaw公表時計で再生成する準備/即時のSource入力.json', '905cab946d67e368633585219fc9f4fa04efab639104dcecdc6a3d01d18eeb01'),
    ('delay', ROOT / 'work/P3をRaw公表時計で再生成する準備/遅延60秒のSource入力.json', '8cc73c58fcf90968d177913bfdf66bdcacb3a98aa6ca1a787a35ad9301349139'),
]
SOURCES = {FEATURES: 'e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774',
           SOURCE: '4c9449b620c15a63c00f9810eeaa52fc8f0eb5f92f7ea2d124cc9db12cc728f6',
           **{p: h for _, p, h in INPUTS}}


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: 指定された入力かコードだけの指紋を求める。
    引数: path(Path)。返り値: str。
    """
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


# ----------------------------------------
def save(path: Path, value: object) -> None:
    """
    機能: UTF-8の小型証跡を保存する。
    引数: path(Path)、value(object)。返り値: None。
    """
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


# ----------------------------------------
def frozen() -> dict:
    """
    機能: 凍結Sourceと依存、保存exeの前後指紋を得る。
    引数: なし。返り値: dict。
    """
    paths = [NATIVE / 'Source入口.exe']
    for folder in (NATIVE, ROOT / 'work/118複数技法の入口条件', ROOT / 'work/121入口の反転切替'):
        paths += sorted(folder.rglob('*.go')) + sorted(folder.glob('go.*'))
    result = {str(p): sha(p) for p in paths}
    assert result[str(paths[0])] == 'e6d216ffbbc9ec8d640d5d482d163de3ac289c1f46392469abb9d66eb47a905e'
    return result


# ----------------------------------------
def local() -> dict:
    """
    機能: 条件・再生code・driverの指紋を固定する。
    引数: なし。返り値: dict。
    """
    return {name: sha(OWN / name) for name in ('条件.md', '公表再生_test.go', '診断する.py')}


# ----------------------------------------
def run_go(pattern: str, label: str, plan: dict | None = None) -> list[str]:
    """
    機能: 既存packageへoverlayを渡し、指定テストだけを呼ぶ。
    引数: pattern/label(str)、plan(dict|None)。返り値: list[str]は合格群。
    """
    virtual = NATIVE / '独立同出生の公表差_test.go'
    assert not virtual.exists()
    save(OWN / 'overlay.json', {'Replace': {str(virtual): str(OWN / '公表再生_test.go')}})
    environment = dict(os.environ)
    environment.pop('FSR_SAME_BIRTH_PLAN', None)
    if plan is not None:
        environment['FSR_SAME_BIRTH_PLAN'] = json.dumps(plan, ensure_ascii=False)
    command = ['go', 'test', '-overlay=' + str(OWN / 'overlay.json'), '-run', pattern, '-count=1', '-json', '.']
    result = subprocess.run(command, cwd=NATIVE, env=environment, capture_output=True, text=True, encoding='utf-8')
    (OWN / (label + 'のログ.jsonl')).write_text(result.stdout, encoding='utf-8')
    assert result.returncode == 0, result.stderr + result.stdout[-5000:]
    events = [json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
    assert not any(e.get('Action') in ('fail', 'skip') for e in events)
    return [e['Test'] for e in events if e.get('Action') == 'pass' and e.get('Test')]


# ----------------------------------------
def points() -> list[dict]:
    """
    機能: 旧Source L0の79出生を124当時特徴と一対一結合する。
    引数: なし。返り値: list[dict]は出生Quoteと旧Directionだけ。
    """
    source = json.loads(SOURCE.read_bytes())
    data = json.loads(FEATURES.read_bytes())
    assert source['success'] and source['trial'] == 133 and source['outcomes_computed'] is False
    assert source['input_sha256'] == INPUTS[0][2] and len(source['scenes']) == 73
    assert data['source_outcomes_used'] is False and data['new_direction_results_read'] is False
    old = {(f['session'], f['id']): f for f in data['features']}
    assert len(old) == len(data['features']) == 79
    result = []
    used = set()
    for s in source['scenes']:
        for c in s['candidates']:
            if c['policy'] != 'L0' or c['entry'] is None:
                continue
            assert c['status'] == 'filled'
            birth = c['birth']
            legacy = birth['id'].replace('/補完/L0/', '/補完/P3/')
            key = (s['session'], legacy)
            assert key in old and key not in used
            used.add(key)
            f = old[key]
            assert birth['side'] == f['original_side'] and c['path'] == f['path']
            assert all(birth[k] == f['birth'][k] for k in ('time', 'index', 'source_line'))
            assert birth['quote'] == f['birth_quote'] and c['entry'] == f['entry_quote']
            d = c['direction']
            refs = [{k: r[k] for k in ('id', 'width_seconds', 'end', 'delivered')} for r in f['refs']]
            assert refs == d['refs']
            for feature_key, direction_key in (('candle5_body_signed_ratio', 'body5_signed_ratio_to_source'),
                    ('ema21_delta_30', 'ema21_delta30_raw'), ('hist_5', 'hist5_raw'), ('atr_5', 'atr5')):
                a, b = f['features'][feature_key], d['fields'][direction_key]
                assert a['known'] == b['known'] and (not a['known'] or a['value'] == b['value'])
            result.append({'session': s['session'], 'id': legacy, 'path': c['path'], 'side': birth['side'],
                           'quote': birth['quote'], 'csv_direction': d})
    assert used == set(old) and len(result) == 79
    return result


# ----------------------------------------
def field(direction: dict, key: str) -> float | None:
    """
    機能: 未知の格納0を数値にせず成分値を得る。
    引数: direction(dict)、key(str)。返り値: float|None。
    """
    item = direction['fields'][key]
    return item['value'] if item['known'] else None


# ----------------------------------------
def components(direction: dict) -> dict:
    """
    機能: 三成分の生値と、実際のB0向き閾値判定を分ける。
    引数: direction(dict)。返り値: dict。
    """
    body = field(direction, 'body5_signed_ratio_to_source')
    long = field(direction, 'ema21_delta30_raw')
    hist, atr = field(direction, 'hist5_raw'), field(direction, 'atr5')
    ratio = hist / atr if hist is not None and atr is not None and atr > 0 else None
    ema_gate = field(direction, 'ema21_delta30_to_B0')
    hist_gate = field(direction, 'hist5_atr_to_B0')
    return {'values': {'body': body, 'ema': long, 'hist_atr': ratio},
            'gates': {'B0実体境界': None if body is None else .5 <= body < .75,
                      '30分EMA増分の符号': None if ema_gate is None else ema_gate >= 0,
                      'Hist/ATR 0.1境界': None if hist_gate is None else hist_gate >= .1}}


# ----------------------------------------
def compare(left: list[dict], right: list[dict]) -> dict:
    """
    機能: 同じ79出生の既知性、三成分、方向差を機械的に分類する。
    引数: left/right(list[dict])。返り値: dict。金融結果を用いません。
    """
    lookup = {(r['session'], r['id']): r for r in right}
    assert len(left) == len(right) == len(lookup) == 79
    counts = Counter()
    changes = []
    numeric = {key: {'knownness': Counter(), 'diff': []} for key in ('body', 'ema', 'hist_atr')}
    foot = {str(w): Counter() for w in (300, 900, 1800)}
    for a in left:
        b = lookup[a['session'], a['id']]
        assert a['quote'] == b['quote']
        da, db = a['direction'], b['direction']
        for width in foot:
            x, y = a['snapshot']['frames'].get(width), b['snapshot']['frames'].get(width)
            if x is None or y is None:
                foot[width]['採用不可を含む'] += 1
            else:
                delta = y['frame']['frame']['end'] - x['frame']['frame']['end']
                foot[width]['同End' if delta == 0 else '右が新しいEnd' if delta > 0 else '右が古いEnd'] += 1
                if not y['frame']['frame']['price_known']:
                    foot[width]['右の採用価格未知'] += 1
        if da is None or db is None:
            counts['足利用不可'] += 1
            changes.append({'session': a['session'], 'id': a['id'], '分類': '足利用不可',
                            'left_valid': da is not None, 'right_valid': db is not None,
                            'left_reason': a['unavailable'], 'right_reason': b['unavailable']})
            continue
        counts['両側方向有効'] += 1
        ca, cb = components(da), components(db)
        for key, item in numeric.items():
            x, y = ca['values'][key], cb['values'][key]
            item['knownness'][('既知' if x is not None else '未知') + '→' + ('既知' if y is not None else '未知')] += 1
            if x is not None and y is not None:
                item['diff'].append(y - x)
        reasons = [key for key in ca['gates'] if ca['gates'][key] != cb['gates'][key]]
        for reason in reasons:
            counts[reason + 'の判定差'] += 1
        counts['B0方向差'] += da['b0_side'] != db['b0_side']
        counts['T8方向差'] += da['t8_side'] != db['t8_side']
        changed = da['selected_side'] != db['selected_side']
        counts['selected方向差'] += changed
        if not changed and da['t8_side'] != db['t8_side'] and da['e0_protected']:
            counts['E0保護でselected維持'] += 1
        if changed:
            assert reasons
            category = reasons[0] if len(reasons) == 1 else '複数'
            counts['方向差分類/' + category] += 1
            changes.append({'session': a['session'], 'id': a['id'], '分類': category, '判定差': reasons,
                            'left_selected': da['selected_side'], 'right_selected': db['selected_side'],
                            'left_components': ca, 'right_components': cb})
    values = {}
    for key, item in numeric.items():
        delta = item['diff']
        values[key] = {'既知性': dict(item['knownness']), '両既知比較数': len(delta),
                       '数値が異なる数': sum(d != 0 for d in delta),
                       '差の平均絶対値': sum(abs(d) for d in delta) / len(delta) if delta else None,
                       '差の最大絶対値': max(map(abs, delta)) if delta else None}
    return {'全固定出生': 79, '件数': dict(counts), '三成分': values,
            '採用足End差': {w: dict(v) for w, v in foot.items()}, '足不可または最終方向変更例': changes}


# ----------------------------------------
def main() -> None:
    """
    機能: 人工固定の後だけ出生固定の公表診断を実行する。
    引数: CLI --人工 又は --実行。返り値: None。
    """
    parser = argparse.ArgumentParser(description='原板・金融を開かない同出生診断')
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--人工', action='store_true')
    modes.add_argument('--実行', action='store_true')
    args = parser.parse_args()
    code, before = local(), frozen()
    if args.人工:
        passed = run_go('^TestSameBirth133Artificial', '人工')
        assert len(passed) == 2 and code == local() and before == frozen()
        save(OWN / '人工の確認.json', {'成功': True, 'code': code, 'frozen': before, 'passed': passed,
                                      '自然公表JSON読取': False, '原板と金融読取': False})
        print(json.dumps({'success': True, 'artificial_sha256': sha(OWN / '人工の確認.json')}, ensure_ascii=True))
        return
    artificial = json.loads((OWN / '人工の確認.json').read_bytes())
    assert artificial['成功'] and artificial['code'] == code and artificial['frozen'] == before
    assert all(sha(p) == h for p, h in SOURCES.items())
    fixed = points()
    save(OWN / '固定79出生.json', fixed)
    plan = {'points': str(OWN / '固定79出生.json'), 'points_sha256': sha(OWN / '固定79出生.json'),
            'output': str(OWN / '公表の再生結果.json'),
            'inputs': [{'model': model, 'path': str(p), 'sha256': h} for model, p, h in INPUTS]}
    save(OWN / 'F0.json', {'条件とcode': code, '人工SHA256': sha(OWN / '人工の確認.json'),
                         '入力': {str(p): h for p, h in SOURCES.items()}, '計画': plan, '凍結': before})
    passed = run_go('^TestSameBirth133Replay$', '公表再生', plan)
    assert passed == ['TestSameBirth133Replay']
    data = json.loads((OWN / '公表の再生結果.json').read_bytes())
    assert data['success'] and data['csv_direction_exact'] and data['raw_opened'] is False and data['finance_read'] is False
    groups = {m: [r for r in data['rows'] if r['model'] == m] for m, _, _ in INPUTS}
    assert len(data['rows']) == 237 and all(len(rows) == 79 for rows in groups.values())
    for rows in groups.values():
        for row in rows:
            row['foot_diagnostics'] = {}
            for width, pub in row['latest_delivered'].items():
                frame = pub['frame']['frame']
                row['foot_diagnostics'][width] = {'last_delivered_end': frame['end'],
                    'available_at': frame['available_at'], 'delivery_at': frame['delivery_at'],
                    'age_from_end': row['quote']['time'] - frame['end'],
                    'age_from_delivery': row['quote']['time'] - frame['delivery_at'],
                    'fresh_limit_exclusive': frame['end'] + int(width) + 60,
                    'in_current': width in row['snapshot']['frames'], 'price_known': frame['price_known']}
    # ----------------------------------------
    # 方向の補完・新しい条件の選択は行わず、比較表だけを作ります。
    summary = {'成功': True, '目的': '出生を変えず公表入力による方向差だけを分離',
               'CSVの旧Direction全値同体': True, '出生数': 79, '対象場': 73,
               '比較': {a + '→' + b: compare(groups[a], groups[b]) for a, b in (('csv', 'instant'), ('csv', 'delay'), ('instant', 'delay'))},
               'モデル別方向有効数': {m: sum(r['direction'] is not None for r in rows) for m, rows in groups.items()},
               '金融と原板読取': False, '入口出生の再生成': False, '新しい政策処置': False}
    assert code == local() and before == frozen() and all(sha(p) == h for p, h in SOURCES.items())
    save(OWN / '足の採用と方向差.json', {'成功': True, 'rows': data['rows']})
    save(OWN / '集約.json', summary)
    save(OWN / '完了の確認.json', {'成功': True, 'F0_SHA256': sha(OWN / 'F0.json'),
        '公表の再生結果SHA256': sha(OWN / '公表の再生結果.json'), '採用足SHA256': sha(OWN / '足の採用と方向差.json'),
        '集約SHA256': sha(OWN / '集約.json'), '前後code不変': True, '凍結Source不変': True,
        '全入力前後SHA不変': True, '原板本文と金融読取': False})
    print(json.dumps({'success': True, 'summary': summary['モデル別方向有効数'],
                     'completion_sha256': sha(OWN / '完了の確認.json')}, ensure_ascii=True))


if __name__ == '__main__':
    main()
