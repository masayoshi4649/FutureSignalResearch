package holdingohlc113

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"reflect"
	"sort"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

type sameBirthPoint133 struct {
	Session string       `json:"session"`
	ID      string       `json:"id"`
	Path    string       `json:"path"`
	Side    int          `json:"side"`
	Quote   Quote        `json:"quote"`
	CSV     Direction133 `json:"csv_direction"`
}

type sameBirthResult133 struct {
	Model       string                    `json:"model"`
	Session     string                    `json:"session"`
	ID          string                    `json:"id"`
	Quote       Quote                     `json:"quote"`
	Snapshot    rules.Snapshot            `json:"snapshot"`
	Latest      map[int]rules.Publication `json:"latest_delivered"`
	Direction   *Direction133             `json:"direction"`
	Unavailable string                    `json:"unavailable"`
}

// ----------------------------------------
// sameBirthReplay133 は、出生原行まで全公表を配送し既存の方向関数だけを呼びます。
//
// 引数: model(string)、in(Input133)、points([]sameBirthPoint133)。返り値: []sameBirthResult133/error。
// 入力JSONの原板パスを開かず、出生・注文・先着・損益の計算を行いません。
func sameBirthReplay133(model string, in Input133, points []sameBirthPoint133) ([]sameBirthResult133, error) {
	groups := map[string][]sameBirthPoint133{}
	for _, p := range points {
		groups[p.Session] = append(groups[p.Session], p)
	}
	bank := rules.NewBank()
	rows := []sameBirthResult133{}
	for _, scene := range in.Scenes {
		if err := bank.StartSession(scene.Session, scene.Contract); err != nil {
			return nil, err
		}
		queries := groups[scene.Session]
		delete(groups, scene.Session)
		sort.Slice(queries, func(i, j int) bool { return queries[i].Quote.Index < queries[j].Quote.Index })
		latest := map[int]rules.Publication{}
		cursor := 0
		add := func(pub rules.Publication) error {
			if err := bank.Add(pub); err != nil {
				return err
			}
			latest[pub.Frame.Frame.Width] = pub
			return nil
		}
		for _, point := range queries {
			q := point.Quote
			if q.Time < scene.Start || q.Time > scene.End || point.Side != 1 && point.Side != -1 {
				return nil, fmt.Errorf("固定出生のScope不正")
			}
			for cursor < len(scene.Publications) && int64(scene.Publications[cursor].Stamp.Index) <= q.Index {
				pub := scene.Publications[cursor]
				if pub.Stamp.Time > q.Time || int64(pub.Stamp.Line) > q.SourceLine {
					return nil, fmt.Errorf("出生以前のindexに未来配送がある")
				}
				if err := add(pub); err != nil {
					return nil, err
				}
				cursor++
			}
			snap, err := bank.Current(quote133(q))
			if err != nil {
				return nil, err
			}
			row := sameBirthResult133{Model: model, Session: scene.Session, ID: point.ID, Quote: q,
				Snapshot: snap, Latest: map[int]rules.Publication{}}
			for width, pub := range latest {
				row.Latest[width] = pub
			}
			d, err := direction133(point.Side, point.Path, snap)
			if err != nil {
				p, exists := snap.Frames[300]
				if exists && p.Frame.Frame.PriceKnown {
					return nil, err
				}
				row.Unavailable = err.Error()
			} else {
				row.Direction = &d
				if model == "csv" && !reflect.DeepEqual(d, point.CSV) {
					return nil, fmt.Errorf("旧CSV方向の全値差: %s", point.ID)
				}
			}
			rows = append(rows, row)
		}
		for cursor < len(scene.Publications) {
			if err := add(scene.Publications[cursor]); err != nil {
				return nil, err
			}
			cursor++
		}
	}
	if len(groups) != 0 || len(rows) != len(points) {
		return nil, fmt.Errorf("固定出生の欠落")
	}
	return rows, nil
}

// ----------------------------------------
// sameBirthArtificial133 は、同じ原行で5分と30分を公表する人工入力を作ります。
//
// 引数: なし。返り値: Input133/[]sameBirthPoint133。原板や保存済み金融を参照しません。
func sameBirthArtificial133() (Input133, []sameBirthPoint133) {
	scene := Scene133{Session: "人工場", Contract: "人工限月", Start: 10000, End: 14000}
	for _, width := range []int{300, 1800} {
		scene.Publications = append(scene.Publications, rules.Publication{
			Stamp: rules.Stamp{Time: 11860, Index: 10, Line: 11},
			Frame: rules.Frame{Frame: rules.ChartFrame{ID: fmt.Sprintf("人工足%d", width), SessionID: scene.Session,
				Contract: scene.Contract, Width: width, Start: 11800 - float64(width), End: 11800,
				AvailableAt: 11860, DeliveryAt: 11860, PriceKnown: true,
				OHLC: rules.OHLC{Open: 100, High: 104, Low: 100, Close: 102},
				Technical: rules.Technical{ATR: rules.Value{Known: true, Value: 10}, Histogram: rules.Value{Known: true, Value: -2},
					EMA21Delta: rules.Value{Known: true, Value: -1}}}},
		})
	}
	q := Quote{Time: 11860, Index: 10, SourceLine: 11, Last: 102}
	return Input133{Scenes: []Scene133{scene}}, []sameBirthPoint133{{Session: scene.Session, ID: "人工出生", Path: "deadline", Side: 1, Quote: q}}
}

// ----------------------------------------
// TestSameBirth133ArtificialSameLine は、同原行の全公表と未来非依存を検査します。
//
// 引数: t(*testing.T)。返り値: なし。境界の両足を配送してから方向を決めます。
func TestSameBirth133ArtificialSameLine(t *testing.T) {
	in, points := sameBirthArtificial133()
	rows, err := sameBirthReplay133("人工", in, points)
	if err != nil || len(rows) != 1 || rows[0].Direction == nil || rows[0].Direction.B0Side != -1 || rows[0].Direction.T8Side != 1 {
		t.Fatalf("同原行の30分を見落とした: %+v %v", rows, err)
	}
	future := in.Scenes[0].Publications[0]
	future.Stamp = rules.Stamp{Time: 12160, Index: 11, Line: 12}
	future.Frame.Frame.ID, future.Frame.Frame.Start, future.Frame.Frame.End = "未来足", 11800, 12100
	future.Frame.Frame.AvailableAt, future.Frame.Frame.DeliveryAt = 12160, 12160
	future.Frame.Frame.OHLC.Close = 104
	in.Scenes[0].Publications = append(in.Scenes[0].Publications, future)
	after, err := sameBirthReplay133("人工", in, points)
	if err != nil || !reflect.DeepEqual(rows, after) {
		t.Fatal("将来公表を出生時点へ混入")
	}
}

// ----------------------------------------
// TestSameBirth133ArtificialUnknown は、成分未知と5分不可、期限の等号を区別します。
//
// 引数: t(*testing.T)。返り値: なし。未知方向を元向きへ補いません。
func TestSameBirth133ArtificialUnknown(t *testing.T) {
	in, points := sameBirthArtificial133()
	in.Scenes[0].Publications[1].Frame.Frame.Technical.EMA21Delta = rules.Value{}
	rows, err := sameBirthReplay133("人工", in, points)
	if err != nil || rows[0].Direction == nil || rows[0].Direction.T8Side != -1 {
		t.Fatal("30分成分未知を既知0としてT8反転")
	}
	in.Scenes[0].Publications[0].Frame.Frame.PriceKnown = false
	rows, err = sameBirthReplay133("人工", in, points)
	if err != nil || rows[0].Direction != nil || rows[0].Unavailable == "" {
		t.Fatal("5分価格未知を方向へ補完")
	}
	in, points = sameBirthArtificial133()
	points[0].Quote.Time, points[0].Quote.Index, points[0].Quote.SourceLine = 12160, 12, 13
	rows, err = sameBirthReplay133("人工", in, points)
	if err != nil || rows[0].Direction != nil || len(rows[0].Snapshot.Frames) != 1 {
		t.Fatal("5分鮮度の等号を利用可能にした")
	}
}

// ----------------------------------------
// TestSameBirth133Replay は、SHA固定済みの公表3入力を既存79出生へ再生します。
//
// 引数: t(*testing.T)、環境変数 FSR_SAME_BIRTH_PLAN(JSON)。返り値: なし。原板は開きません。
func TestSameBirth133Replay(t *testing.T) {
	value := os.Getenv("FSR_SAME_BIRTH_PLAN")
	if value == "" {
		t.Skip("人工だけを実行")
	}
	var plan struct {
		Points string                                 `json:"points"`
		SHA256 string                                 `json:"points_sha256"`
		Output string                                 `json:"output"`
		Inputs []struct{ Model, Path, SHA256 string } `json:"inputs"`
	}
	if err := json.Unmarshal([]byte(value), &plan); err != nil || len(plan.Inputs) != 3 {
		t.Fatalf("再生計画不正: %v", err)
	}
	read := func(path, expected string, out any) {
		payload, err := os.ReadFile(path)
		if err != nil {
			t.Fatal(err)
		}
		sum := sha256.Sum256(payload)
		if hex.EncodeToString(sum[:]) != expected {
			t.Fatal("入力SHA差")
		}
		if err := json.Unmarshal(payload, out); err != nil {
			t.Fatal(err)
		}
	}
	var points []sameBirthPoint133
	read(plan.Points, plan.SHA256, &points)
	if len(points) != 79 {
		t.Fatal("固定出生が79件でない")
	}
	rows := []sameBirthResult133{}
	var scenes []Scene133
	for _, input := range plan.Inputs {
		var in Input133
		read(input.Path, input.SHA256, &in)
		if _, err := validateInput133(in, 1); err != nil {
			t.Fatal(err)
		}
		if scenes == nil {
			scenes = in.Scenes
		} else {
			for i, s := range in.Scenes {
				a := scenes[i]
				if a.Session != s.Session || a.Contract != s.Contract || a.Start != s.Start || a.End != s.End || a.ForceClose != s.ForceClose || a.Raw != s.Raw || a.ExpectedAccepted != s.ExpectedAccepted || !reflect.DeepEqual(a.ExpectedQuality, s.ExpectedQuality) {
					t.Fatal("モデル間の73場metadata差")
				}
			}
		}
		got, err := sameBirthReplay133(input.Model, in, points)
		if err != nil {
			t.Fatal(err)
		}
		if input.Model == "csv" {
			for _, row := range got {
				if row.Direction == nil {
					t.Fatal("CSVの旧方向が再現不能")
				}
			}
		}
		rows = append(rows, got...)
	}
	data, err := json.MarshalIndent(map[string]any{"success": true, "points": 79, "scenes": 73,
		"csv_direction_exact": true, "raw_opened": false, "finance_read": false, "rows": rows}, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	f, err := os.OpenFile(plan.Output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		t.Fatal(err)
	}
	if _, err := f.Write(append(data, '\n')); err != nil {
		t.Fatal(err)
	}
	if err := f.Close(); err != nil {
		t.Fatal(err)
	}
	t.Logf("同じ79出生×3公表モデルを再生、CSV全Direction同体、原板・金融なし")
}
