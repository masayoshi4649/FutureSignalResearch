"""既存237行だけから遅延変更5件の直接分岐を調べ、取得価格・損益を読まない。"""
from pathlib import Path
import hashlib
import json

OWN = Path(__file__).resolve().parent
DATA = OWN / '公表の再生結果.json'
EXPECTED = '1c034b7b55e9d5e10ed2ca9f25d4ffd5c17d5b187667dd46b69a845e6d4e7b81'


# ----------------------------------------
def value(direction: dict, key: str) -> float | None:
    """
    機能: 成分未知を0とせず数値を取り出す。
    引数: direction(dict)、key(str)。返り値: float|None。
    """
    v = direction['fields'][key]
    return v['value'] if v['known'] else None


# ----------------------------------------
def main() -> None:
    """
    機能: CSV→遅延で方向が変わった全件の同End/OHLCと既知性を照合する。
    引数: なし。返り値: None。元237行を変更せず新しい小型証跡を作る。
    """
    raw = DATA.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED
    data = json.loads(raw)
    groups = {}
    for r in data['rows']:
        groups.setdefault((r['session'], r['id']), {})[r['model']] = r
    assert len(groups) == 79 and len(data['rows']) == 237
    result = []
    for (sid, identity), models in groups.items():
        a, b = models['csv'], models['delay']
        da, db = a['direction'], b['direction']
        assert da is not None and db is not None
        if da['selected_side'] == db['selected_side']:
            continue
        fields = {}
        for key in ('body5_signed_ratio_to_source', 'ema21_delta30_raw', 'ema21_delta30_to_B0',
                    'hist5_raw', 'atr5', 'hist5_atr_to_B0'):
            fields[key] = {'csv': value(da, key), 'delay': value(db, key)}
        foot = {}
        for width in ('300', '900', '1800'):
            x, y = a['snapshot']['frames'][width], b['snapshot']['frames'][width]
            fx, fy = x['frame']['frame'], y['frame']['frame']
            assert fx['end'] == fy['end'] and fx['ohlc'] == fy['ohlc'] and fx['price_known'] and fy['price_known']
            foot[width] = {'same_end': True, 'same_ohlc': True, 'both_price_known': True,
                           'end': fx['end'], 'csv_delivery': fx['delivery_at'], 'delay_delivery': fy['delivery_at'],
                           'knownness': {k: {'csv': v['known'], 'delay': fy['technical'][k]['known']}
                                         for k, v in fx['technical'].items()},
                           'history_bars_saved': 'history_bars' in fy['technical']}
        assert da['b0_side'] == db['b0_side'] and da['e0_protected'] is False
        assert fields['body5_signed_ratio_to_source']['csv'] == fields['body5_signed_ratio_to_source']['delay']
        assert fields['ema21_delta30_to_B0']['csv'] is not None and fields['ema21_delta30_to_B0']['csv'] >= 0
        assert fields['ema21_delta30_to_B0']['delay'] is None
        assert fields['hist5_atr_to_B0']['csv'] >= .1
        hist_unknown = fields['hist5_atr_to_B0']['delay'] is None
        if not hist_unknown:
            assert fields['hist5_atr_to_B0']['delay'] >= .1
        result.append({'session': sid, 'id': identity, 'csv_selected': da['selected_side'], 'delay_selected': db['selected_side'],
                       'B0同体': True, '当該3尺度の同End同OHLC': True,
                       '直接分岐': '30分EMA増分の既知→未知でT8反転が不成立',
                       '5分HistATRも未知化': hist_unknown, 'fields': fields, 'foot': foot,
                       'resetとcarryの内訳': '237行だけでは未証明。history_bars/最後のreset理由/seed指紋が保存されていない'})
    assert len(result) == 5 and sum(r['5分HistATRも未知化'] for r in result) == 3
    assert hashlib.sha256(DATA.read_bytes()).hexdigest() == EXPECTED
    proof = {'成功': True, '生成元SHA256': EXPECTED, '全固定出生': 79, '遅延変更全件': 5,
             '同End同OHLCかつB0不変': 5, '30分EMA増分が既知から未知': 5, '5分HistATRも未知': 3,
             '結論': '当該足OHLC差や実体境界でなく、数値履歴の状態差。直接分岐は長期増分未知化。reset/carry内訳は未証明',
             'rows': result, '原板読取': False, '取得価格読取': False, '金融読取と再計算': False,
             '新threshold': False, '元237行変更': False}
    dest = OWN / '遅延変更5件の原因.json'
    dest.write_text(json.dumps(proof, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({'success': True, 'proof_sha256': hashlib.sha256(dest.read_bytes()).hexdigest()}, ensure_ascii=True))


if __name__ == '__main__':
    main()
