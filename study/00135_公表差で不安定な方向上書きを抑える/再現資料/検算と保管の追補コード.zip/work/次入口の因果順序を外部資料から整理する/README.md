# 次入口は状態の順序として定義する

2026-11-12（JST確認）。正式docs/試行・旧条件は変更せず、Raw・新金融・閾値探索は実行していない。資料の一般説明と心理の仮説、以下の未検証研究案を区別する。公式教材はNK225・H60・±125ptの先着70%や全73場取得の実証資料ではない。

## 外部資料で確認したこと

|役割|使う情報|解説から得る制約|
|---|---|---|
|背景方向|30分MA配置/傾き、DI差|MAは遅行する。DIとMAを独立した2票へ加算せず、1つの背景整合として使う。[Moving Momentum](https://chartschool.stockcharts.com/table-of-contents/trading-strategies-and-models/trading-strategies/moving-momentum)、[ADX](https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-indicators/average-directional-index-adx)|
|背景の強さ|ADX水準/変化|方向そのものではない。下がっただけでは逆転を意味しない。20/25は一般的目安で、分足の保証値ではない。初期値・助走に依存する。[ADX](https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-indicators/average-directional-index-adx)|
|押戻し/失速の位相|MACD-Histの符号と増減、RSIの履歴|HistはMACD−Signal。正負と拡大縮小を分ける。RSIの過熱や乖離だけで逆張りしない。両者を別々の独立票に数えない。[MACD-Hist](https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-indicators/macd-histogram)、[RSI](https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-indicators/relative-strength-index-rsi)|
|価格位置/収束|BBの位置・BandWidth、固定した過去高安|帯への接触だけは売買信号ではない。外側終値・band walkは継続の場合もある。[Bollinger公式規則](https://www.bollingerbands.com/bollinger-band-rules)|
|尺度/無効化|ATR、TR/前ATR、構造境界までの距離|ATRは方向を示さない。価格距離の正規化・異常幅・risk/capに使い、買い票/売り票へしない。[ATR](https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-indicators/average-true-range-atr)|
|参加の裏付け|確認した値動きと同じ足の量、既知性|反転は形の予兆と価格確認を分け、完成時の量を補助にする。大出来高だけでは売買方向や主体を特定しない。[CME反転](https://www.cmegroup.com/education/courses/technical-analysis/technical-patterns-reversals)|
|新規の引き金|凍結水準の奪還・失敗突破・再試験維持|支持抵抗は点でなく領域。突破後の役割交代と回復を区別する。[CME支持抵抗](https://www.cmegroup.com/education/courses/technical-analysis/support-and-resistance)、[CME継続](https://www.cmegroup.com/education/courses/technical-analysis/trend-and-continuation-patterns)|

30/15/5分と1分への役割割当は本研究の選択で、日足例の設定値をそのまま分足で有効と証明したものではない。BBも95%収容や逆転確率を保証しない。同一終値から作ったMA・MACD・RSIの多数決、TRを共有するATR/ADXの二重加点を避ける。

## 最大3つの未実行候補

買いをs=+1、売りをs=−1とする。価格・MA差・Hist・DI差はs倍で同じ条件を使う。高安は売りで上下を交換する。数字は既存EMA8/21・BB20/2σ・ADXの目安・量比1等を例示した**設計案**であり、正式条件は採用していない。

### E1：順行背景→押戻し履歴→回復

1. **背景**：30分MA配置/傾きとDIがs側、ADXは強さのラベル。未知を賛成票にしない。
2. **準備**：後の15分足がEMA21近傍へ戻り、sHist15≤0の押戻し位相になった履歴を保存。接触帯・時刻・refs・その時点までの短期高安Kを固定する。
3. **確認**：準備状態より後に公表された5分でsΔHist5>0となり、さらに後の確定1分が凍結Kをs側へ突破。現在LastもKを維持する。絶対Hist5>0は一律必須にせず、負領域からの回復と価格確認を分ける。

背景は確認時にも維持するが、準備時のHist15≤0を確認時に再要求しない。量は回復を含む足の既知量で確認し、接触前の古い5分RVOLを「回復時の量」と呼ばない。心理の仮説は「大きい流れは残り、逆側の一時的な圧力が尽きて元方向が回復」。主体や注文を実測した事実ではない。[順次過程の一般例](https://chartschool.stockcharts.com/table-of-contents/trading-strategies-and-models/trading-strategies/moving-momentum)

### E2：元方向の失速→失敗突破/回復→同じ確認足の量

1. **準備**：旧方向−sの進行を確認した後、15分でsHist15<0かつsΔHist15>0の縮小を保存。ADX低下は補助で、これだけで反転を決めない。帯端と事前レンジ境界Bを凍結する。
2. **価格確認**：その後の確定5分がBを旧方向へ一時突破し、終値が元レンジ内へ回復する。単なるBB接触や外側終値の継続を反転へ変換しない。
3. **量と維持**：この価格回復を含む**同じ5分足**のRVOL≥1が既知なら量の裏付けとし、その後の1分/RawでB維持を確認する。価格回復と当該足の量は終値確定時に同時に利用可能で、量が将来から先に分かるわけではない。

これは短期反転/レンジ回転であり、30分の大トレンド転換とは別。反対端までの現在の余地が主到達幅より小さければ「レンジ回転で目標へ届く」と仮定しない。心理は「旧方向の突破が持続せず、反対側の価格回復に参加が伴う」という仮説。[CME反転](https://www.cmegroup.com/education/courses/technical-analysis/technical-patterns-reversals)、[帯接触と継続の注意](https://www.bollingerbands.com/bollinger-band-rules)

### E3：収束→実際の突破方向→再試験維持

1. **準備**：ADXが弱い/非増勢で、15分BB幅が縮小しTR5/前ATR5<1の収束を記録。過去の確定足だけでレンジ上端/下端を凍結する。30分MAの向きで突破方向を先決めしない。
2. **突破**：後の確定5分が凍結レンジ外へ終値で進み、同じ足の既知RVOL≥1とsHist5>0を確認。上抜け/下抜けでsを決める。
3. **再試験**：別の後続1分が凍結突破水準を再試験し、終値と現在Lastが突破側を保つ場合だけ取得候補。帯外終値だけで逆張りしない。再試験が来ないケースに利益を与えない。

心理は「拮抗がほどけて一方の価格が維持される」という仮説。収束自体は方向・継続の証明ではない。[CME継続](https://www.cmegroup.com/education/courses/technical-analysis/trend-and-continuation-patterns)、[Bollinger公式](https://www.bollingerbands.com/bollinger-band-rules)

## 同時成立と順次成立の実装境界

`背景 → 準備 → 価格確認/同足量 → 後続維持 → 注文` をepisodeとして保存する。準備と回復は別時点でよく、同時に「押している」「既に回復した」をANDしない。一方、現在の背景・未失効・最新Last/BBOの維持・cap/riskは取得時点で同時に必要。

各状態にsession/contract/side、元足End・実配送time/index/物理行、凍結境界、量の対象足End、失効理由を残す。未来のpivotや将来の高安で境界を描き直さない。準備後の新公表であることをIDだけでなくEnd/配送順で検査する。gap・時計拒否・自然無効化・場替わりは取消し、未知を0や賛成へ変換しない。episode TTL・再arming・競合優先は金融前に固定し、過去成績で選ばない。

複数候補の両方向が同じ原行で競合すれば競合を記録し、黙って有利だった方を選ばない。組合せは個々の出生を保持した後に別の固定方針で扱う。これらの選別だけでは全73場最低1取得を保証しない。初日の長期助走不足や全候補0場を残し、補完が必要なら別仮説として事前固定する。時間経過だけで強い技術信号が生まれたと扱わない。

## 119/120/129との重複と差分

|既存仕様|既に順次成立している部分|今回まだ未検証の差分|
|---|---|---|
|119|領域接触の出生→5分確認→同じ確認水準の再試験、30分TTL・背景取消しがある。順次化そのものは新案ではない|E1/E2の15分Hist位相を履歴として保持し、接触後の5分公表と量の対象足を明示的に束縛する案。別時間軸への移植だけで新手法とは呼ばない|
|120|1分の過去5本突破→回復/終値確認、BB幅前後比較、出生Raw/取得Rawのholdがある。履歴を全く見ないANDではない|持続する押戻しepisodeとMACD位相を保存するE1/E2。E3の低強度背景での突破→**別の後続足の再試験**は120P3の当1分突破/holdと区別|
|129 C1/C2/C3|接触保存→拒否1分→K回復→別2Raw/1秒維持。C3は先行移動→低量反対足→次足の回復/量増。量の順序も既にある|E1は接触前の5Hist正を必須とせず、準備後の新5分公表の改善を要求する差。E2は15分の旧方向縮小→後の5分失敗突破/同足量の結合。E3は強いMA背景の追随ではなく収束レンジからの実方向選択。いずれも既存系統の差分案であり、新しい成功の発見ではない|

比較は仕様の論理時系列だけ。119の確認/再試験、129の低量戻し/回復と同じ案を別名で再検証しない。実装へ進むなら差分を1つずつ固定対照へ重ねる。[119](../../study/00119_技術領域の出生と確認後再試験で入口を比較する/README.md)、[120](../120入口の1分構造/README.md)、[129](../129短期回復の出生/仕様.md)。
