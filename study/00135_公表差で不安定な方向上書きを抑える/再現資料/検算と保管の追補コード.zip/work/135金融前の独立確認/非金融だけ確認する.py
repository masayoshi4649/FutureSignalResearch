"""135のprepareと人工算術だけを呼び、自然金融JSONのparseを拒否する独立確認。"""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json

OWN = Path(__file__).resolve().parent
ROOT = OWN.parent.parent
TARGET = ROOT / 'work/公表差で反転が不安定な入口を保守化する'


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: コードと入力の指紋を得る。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def module(path: Path, name: str) -> object:
    """
    機能: mainを呼ばず私有moduleへ読み込む。
    引数: path(Path)、name(str)。返り値: object。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


# ----------------------------------------
def main() -> None:
    """
    機能: chooserと出生結合、private算術、phase、360/79/73表を非金融で確認する。
    引数: なし。返り値: None。135のevaluateは呼ばない。
    """
    paths = [TARGET / n for n in ('条件.md', '方向を選ぶ.py', '評価する.py')]
    before = {str(p): sha(p) for p in paths}
    run = module(TARGET / '評価する.py', '135独立非金融確認')
    chooser = module(TARGET / '方向を選ぶ.py', '135独立chooser')
    checks = chooser.artificial()
    guarded = {run.SOURCES[run.FINANCE], run.SOURCES[run.OLD]}
    parsed = []
    original_loads = json.loads
    def nonfinancial_loads(value, *args, **kwargs):
        """
        機能: 自然金融の固定SHAに一致するJSONparseを拒否する。
        引数: value(str|bytes)、args/kwargs。返り値: object。
        """
        raw = value.encode('utf-8') if isinstance(value, str) else value
        actual = hashlib.sha256(raw).hexdigest()
        assert actual not in guarded, '金融のJSONparseを呼んだ'
        parsed.append(actual)
        return original_loads(value, *args, **kwargs)
    json.loads = nonfinancial_loads
    try:
        prepared = run.prepare()
    finally:
        json.loads = original_loads
    assert len(prepared['choices']) == 79 and len(prepared['sessions']) == 73
    assert prepared['金融結果読取'] is False and prepared['原板読取'] is False
    shared = module(run.SHARED, '135独立private131')
    shared.POLICIES = run.POLICIES
    arithmetic = shared.module124()
    assert arithmetic.POLICIES == run.POLICIES and arithmetic.selected is shared.selected
    fixtures = module(ROOT / 'work/134公表時計別の集計/人工検査.py', '135人工Quoteだけの再用')
    sessions = ['人工%03d' % i for i in range(73)]
    records = []
    for i in range(79):
        sid = sessions[i % 73]
        start = 10000 + (i % 73) * 20000
        side = 1 if i % 2 == 0 else -1
        q = fixtures.quote(start + 100, 2)
        birth = fixtures.quote(start + 98, 1)
        choice = chooser.choose(side, False, -side, side if i % 3 else -side, -side)
        choice.update({'strategy': '人工', 'birth_quote': birth, 'entry_quote': q,
                       'partition_reference': 'train' if i % 73 < 48 else 'validation'})
        case = {'id': '人工%d' % i, 'original_side': side}
        for name, actual_side, chart in (('original', side, False), ('reverse', -side, False),
                ('chart_original', side, True), ('chart_reverse', -side, True)):
            case[name] = fixtures.candidate(actual_side, q, chart, i % 7 == 0)
        records.append({'session': sid, 'case': case, 'choice': choice})
    values = shared.aggregate_records(records, sessions, arithmetic)
    tables = run.tables(records, sessions, values, arithmetic, shared)
    assert [len(t['rows']) for t in tables] == [360, 79, 73]
    assert values['all']['U0']['BBO']['3600']['125']['entries'] == 79
    assert values['all']['U0']['BBO']['3600']['125']['sessions'] == 73
    for part in values.values():
        for policy in run.POLICIES:
            for widths in part[policy]['Last'].values():
                assert all(v['ifd_net5_sum'] is None for v in widths.values())
    sample = fixtures.candidate(1, fixtures.quote(100, 2), False, False)
    money = arithmetic.ifd(sample, arithmetic.observation(sample, 3600), 125, 'BBO')
    assert money['net0'] == 12923 and money['net5'] == 11923
    metadata = {'scenes': [{'session': sid, 'end': 10000 + i * 20000 + 10000} for i, sid in enumerate(sessions)]}
    phase = shared.assert_execution_phase(records, sessions, metadata)
    bad = copy.deepcopy(records)
    bad[0]['case']['original']['outcomes'][0]['touches'][0]['quote'] = fixtures.quote(19700, 3)
    bad[0]['case']['original']['outcomes'][0]['touches'][0]['direction'] = 1
    try:
        shared.assert_execution_phase(bad, sessions, metadata)
    except AssertionError:
        pass
    else:
        raise AssertionError('phase等号を受理')
    assert before == {str(p): sha(p) for p in paths}
    proof = {'成功': True, '対象コードSHA256': before, 'chooser人工': checks,
             '自然出生結合': {'件数': 79, '場数': 73, '出生Quote同体': True},
             'prepareでJSONparseしたSHA256': parsed, '自然金融JSONparse拒否': True,
             'private算術の政策と選択だけ置換': True, '人工表行数': [len(t['rows']) for t in tables],
             '人工表列数': [len(t['headers']) for t in tables], '人工費用77円とC5追加1000円': True,
             'Last金額null': True, '人工phase': phase, 'phase境界等号の拒否': True,
             '旧C0とO0全120条件assert': '静的に確認。自然金融の検算は実行していない',
             'evaluate呼出': False, '新金融ファイル読取': False, '原板読取': False,
             'Rootコード前後不変': True}
    dest = OWN / '非金融の独立確認.json'
    dest.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'success': True, 'proof_sha256': sha(dest)}, ensure_ascii=True))


if __name__ == '__main__':
    main()
