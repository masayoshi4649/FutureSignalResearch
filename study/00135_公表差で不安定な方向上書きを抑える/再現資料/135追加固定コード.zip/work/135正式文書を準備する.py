"""135の主政策と汎用表を金融評価前に作成する。"""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent.parent
NAME = '00135_公表差で不安定な方向上書きを抑える'


def main() -> None:
    """
    機能: 版6の504セル、仮説、費用、全場参加条件を未作成の正式先へ保存する。
    引数: なし。
    返り値: None。自然金融・非金融診断の結果を読まない。
    """
    dest = ROOT / 'study' / NAME
    dest.mkdir(exist_ok=False)
    template = (ROOT / 'docs/議論/手法と時間スケールの汎用表_版6.md').read_text('utf-8')
    rows = [s for s in template.splitlines() if re.match(r'^\| [A-Z][0-9]{2} ', s) and len(s.split('|')[1:-1]) == 11]
    assert len(rows) == 56
    used = {
        'I01': {5: 'S02：固定T8の30分EMA21増分>=0'},
        'I03': {3: 'S02：固定T8の5分Hist/ATR>=.1'},
        'I09': {3: 'S02：Histを5分ATRで正規化'},
        'C07': {3: 'S03：同じ出生・異なる形成と公表を比較', 5: 'S02：長期背景の固定条件'},
        'P01': {3: 'S02：元向き実体比[.5,.75)で固定B0反転'},
        'B01': {0: 'S04：旧同取得の実正逆BBO、phase全検査'},
        'E01': {0: 'S05：主U0/H60±125、全73場と70%を両判定'},
        'E02': {0: '対象外：方向診断。追尾/実IFD/10枚口座未検証'},
    }
    lines = []
    for row in rows:
        parts = [v.strip() for v in row.split('|')[1:-1]]
        parts[1] = parts[1].replace('(../technical-analysis/', '(../../docs/technical-analysis/').replace(
            '(逆行200ptより先に順行400ptへ届く入口.md)', '(../../docs/議論/逆行200ptより先に順行400ptへ届く入口.md)')
        cells = ['未設定・未検証'] * 9
        for i, value in used.get(parts[0], {}).items():
            cells[i] = value
        lines.append('| ' + ' | '.join(parts[:2] + cells) + ' |')
    header = next(s for s in template.splitlines() if s.startswith('| ID |'))
    intro = '''# 00135：設定と結果（汎用表・版6）

2026-11-12、金融前。56手法×9尺度＝504セル。[主定義](README.md)、[条件](条件.md)。今回は旧79出生の方向上書き層だけを記録する。元P3/E0の多技法の入口は固定し再判定しないため、表の未設定を元入口でも未使用と解釈しない。

'''
    tail = '''

|設定ID|条件|
|---|---|
|S01|旧124の79取得・73場の日時/元向き/geometryを固定。全件を残す|
|S02|B0実体比[.5,.75)、T8はB0向きEMA21Δ30>=0かつHist5/ATR5>=.1でB0反転、成分未知は既存維持。E0元方向保護|
|S03|主U0はCSV/Raw即時/Raw遅延のselectedが全有効かつ一致なら共通方向。他はSource元方向。N0/D0は当該公表、利用不能ならSource。C0旧CSV/O0元/R0主の実逆|
|S04|同じ取得の正逆/Last保存観測を選ぶ。全entry/touch/endpointのザラバ境界を検査。逆注文の適格性再構築ではない|
|S05|主U0・実BBO/H60/±125の順/(順+逆)>=70%と全73場最低1取得。未到達/不足/未到達込率を別記。副は全H/幅/軸を保存|
|S06|mini独立1枚、100円/pt、往復77円、C5追加1000円。touch又はH完了期限BBOだけ金額既知、その他null。利益/損失/未知を別記|
|S07|6政策×20条件×全体/前48/後25＝360比較。全期間既使用。主を結果後に交換しない|

## 結果

未実行。方向が不一致の例も取得を除外せず残す。主U0の両条件達成は未確認。副の高率を主の達成としない。
'''
    (dest / '設定と結果.md').write_text(intro + header + '\n| ' + ' | '.join(['---'] * 11) + ' |\n' + '\n'.join(lines) + tail, encoding='utf-8')
    plan = ROOT / 'work/公表差で反転が不安定な入口を保守化する/条件.md'
    (dest / '条件.md').write_bytes(plan.read_bytes())
    (dest / 'README.md').write_text('''# 公表差で不安定な方向上書きを抑える

試行00135。2026-11-12、金融前。[条件](条件.md)、[設定と結果](設定と結果.md)。

134は全73場参加を維持したが、主Raw即時42.86%で未達。CSV/Rawで入口が選び直される影響と同じ出生で方向が変わる影響を分ける。旧79取得は固定し、主U0は異なる形成・公表で複合方向が一致しない時に追加反転を止めてSource元判断へ戻す。全79件を残すため、全73場最低1取得も維持する。

元判断と固定T8を複数テクニカルとして継承し、閾値を再学習しない。三公表は独立票とはみなさない。全期間は既使用であり、成功しても未知期間の安定利益とはしない。旧124の実正逆観測を利用し、mini1枚の独立IFD代用として費用後利益・損失・差引を評価する。注文適格性/実mini板/追尾/10枚口座は未検証。

現時点は未実行。条件・コード・方向票・入力を固定してから金融評価する。結果と再現資料は完了後に追記する。
''', encoding='utf-8')
    print('135の主U0と504セルを金融前に保存')


if __name__ == '__main__':
    main()
