"""135の方向票を金融前に固定し、旧79取得の実正逆だけを再集計する。"""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone
import argparse
import gzip
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00135_公表差で不安定な方向上書きを抑える'
DIAG = ROOT / 'work/同じ79出生における公表差の診断/公表の再生結果.json'
FEATURE = ROOT / 'work/124当時特徴の診断/全79例の当時特徴.json'
FINANCE = ROOT / 'work/124入口の正逆比較/全73場の正逆結果.json'
OLD = ROOT / 'work/126複合切替の探索/集計.json'
SHARED = ROOT / 'work/131既存入口の位相切替評価/評価する.py'
META = ROOT / 'inputs/00124_同入口正逆の共用入力/入力.json.gz'
POLICIES = ('U0', 'C0', 'N0', 'D0', 'O0', 'R0')
SOURCES = {
    FEATURE: 'e4f0bf25156c1fe732b186c5c5d90b6e9f95718985a440d8eb7005588f734774',
    FINANCE: '25517066b291a0434211190299b9f0195e67f9a7d2e89c801d5b9e6b4b51c3a1',
    OLD: 'e30aca19e553ded53ccdd3b1785bd6168e19dd210aa9c32c1f9625c0063fdcd8',
    ROOT / 'work/124入口の原因分析/集計する.py': '8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a',
}


def sha(path: Path) -> str:
    """
    機能: ファイルの全バイト指紋を返す。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: 既存ファイルを上書きせず日本語UTF-8でJSONを保存する。
    引数: path(Path)、value(dict)。
    返り値: None。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n')


# ----------------------------------------
def load(path: Path, name: str) -> object:
    """
    機能: 既存モジュールのmainを呼ばず私有の名前空間へ読み込む。
    引数: path(Path)、name(str)。
    返り値: objectはモジュール。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ----------------------------------------
def prepare() -> dict:
    """
    機能: 非金融237行だけを同じ旧79出生へ結合して六政策の方向票を作る。
    引数: なし。
    返り値: dictは固定方向票。金融結果は開かない。
    """
    chooser = load(OWN / '方向を選ぶ.py', '135固定方向')
    artificial = chooser.artificial()
    assert artificial['成功']
    for path, expected in SOURCES.items():
        assert sha(path) == expected, str(path)
    diagnostic = json.loads(DIAG.read_bytes())
    features = json.loads(FEATURE.read_bytes())
    assert diagnostic['success'] and diagnostic['points'] == 79 and diagnostic['scenes'] == 73
    assert diagnostic['csv_direction_exact'] and not diagnostic['raw_opened'] and not diagnostic['finance_read']
    groups = {}
    for row in diagnostic['rows']:
        key = row['session'], row['id']
        assert row['model'] in ('csv', 'instant', 'delay')
        group = groups.setdefault(key, {})
        assert row['model'] not in group
        group[row['model']] = row
    assert len(diagnostic['rows']) == 237 and len(groups) == 79
    sessions = sorted({f['session'] for f in features['features']})
    assert len(sessions) == 73
    choices = []
    for f in features['features']:
        key = f['session'], f['id']
        rows = groups.pop(key)
        assert set(rows) == {'csv', 'instant', 'delay'}
        sides = {}
        for model, row in rows.items():
            assert row['quote'] == f['birth_quote']
            d = row['direction']
            if d is None:
                assert model != 'csv' and row['unavailable']
                sides[model] = None
            else:
                assert d['source_side'] == f['original_side']
                assert d['e0_protected'] == (f['strategy'] == 'E0')
                sides[model] = d['selected_side']
        result = chooser.choose(f['original_side'], f['strategy'] == 'E0', sides['csv'], sides['instant'], sides['delay'])
        choices.append({'session': key[0], 'id': key[1], 'original_side': f['original_side'],
                        'strategy': f['strategy'], 'path': f['path'],
                        'birth_quote': f['birth_quote'], 'entry_quote': f['entry_quote'],
                        'partition_reference': 'train' if key[0] in sessions[:48] else 'validation', **result})
    assert not groups and len(choices) == 79 and tuple(chooser.POLICIES) == POLICIES
    return {'成功': True, '試行': 135, '主': 'U0', 'policies': list(POLICIES), 'sessions': sessions,
            'choices': choices, '人工': artificial, '金融結果読取': False, '原板読取': False,
            '診断SHA256': sha(DIAG), '特徴SHA256': sha(FEATURE), '条件SHA256': sha(OWN / '条件.md'),
            '方向関数SHA256': sha(OWN / '方向を選ぶ.py')}


# ----------------------------------------
def tables(records: list[dict], sessions: list[str], values: dict, arithmetic: object, shared: object) -> list[dict]:
    """
    機能: 全360条件・全79入口・全73場の閲覧三表を同じ算術から生成する。
    引数: records(list[dict])、sessions(list[str])、values(dict)、arithmetic/shared(object)。
    返り値: list[dict]は型付き三表。CSV化は別工程。
    """
    headers = ['試行','区分','政策','価格軸','評価分','同幅pt','対象場数','取得場数','取得数','最低1取得達成',
               '元方向から反転数','全H完了','観測不足','順行先着','逆行先着','未到達','到達済み順行率','未到達込率',
               '到達済み70%','参加と70%両達成','IFD既知','IFD未知','C0代用差引円','C5代用利益円','C5代用損失絶対円',
               'C5代用差引円','C5代用平均円','C5代用PF']
    comparison = []
    for part, n in (('all',73), ('train',48), ('validation',25)):
        for p in POLICIES:
            for axis in arithmetic.AXES:
                for h in arithmetic.HORIZONS:
                    for w in arithmetic.WIDTHS:
                        s = values[part][p][axis][str(h)][str(w)]
                        participation = s['sessions'] == n
                        comparison.append([135,part,p,axis,h/60,w,n,s['sessions'],s['entries'],participation,
                            s['flips'],s['complete'],s['censored'],s['forward'],s['adverse'],s['neither'],s['resolved_rate'],s['complete_rate'],
                            s['target70'],participation and s['target70'] is True,s['ifd_known'],s['ifd_unknown'],s['ifd_net0_sum'],
                            s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],s['ifd_net5_mean'],s['ifd_net5_pf']])
    detail_headers = ['試行','参考区分','セッション','出生ID','入口型','元方向','出生JST','取得JST','元取得価格','逆取得価格',
                      'CSV方向','Raw即時方向','Raw遅延方向','三公表利用可','三公表一致','主の理由']
    for p in POLICIES:
        detail_headers += [p+'方向',p+'全H',p+'先着',p+'IFD既知',p+'清算理由',p+'C5代用円']
    detail = []
    for r in records:
        c, case = r['choice'], r['case']
        row = [135,c['partition_reference'],r['session'],case['id'],c['strategy'],case['original_side'],
               arithmetic.jst(c['birth_quote']['time']),arithmetic.jst(c['entry_quote']['time']),
               case['original']['entry_price'],case['reverse']['entry_price'],c['inputs']['csv'],c['inputs']['instant'],c['inputs']['delay'],
               c['all_available'],c['unanimous'],c['reason']]
        for p in POLICIES:
            candidate = shared.selected(r,p,'BBO')
            o = arithmetic.observation(candidate,3600)
            e = arithmetic.ifd(candidate,o,125,'BBO')
            row += [c['choices'][p]['side'],o['status'],arithmetic.touch(o,125)['direction'],e['known'],e['reason'],e['net5']]
        detail.append(row)
    scene_headers = ['試行','セッション','参考区分','取得数','最低1取得']
    for p in POLICIES:
        scene_headers += [p+'反転数',p+'順',p+'逆',p+'未到達',p+'不足',p+'IFD既知',p+'IFD未知',p+'C5利益円',p+'C5損失絶対円',p+'C5差引円',p+'C5既知累計円',p+'累計未知']
    scene_rows = []
    cumulative = {p:0 for p in POLICIES}
    unknown = {p:0 for p in POLICIES}
    for i,sid in enumerate(sessions):
        group = [r for r in records if r['session'] == sid]
        row = [135,sid,'train' if i<48 else 'validation',len(group),bool(group)]
        for p in POLICIES:
            s = arithmetic.stats(group,p,'BBO',3600,125)
            if s['ifd_net5_sum'] is not None:
                cumulative[p] += s['ifd_net5_sum']
            unknown[p] += s['ifd_unknown']
            row += [s['flips'],s['forward'],s['adverse'],s['neither'],s['censored'],s['ifd_known'],s['ifd_unknown'],
                    s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],cumulative[p],unknown[p]]
        scene_rows.append(row)
    result = [{'name':'正逆比較','headers':headers,'rows':comparison}, {'name':'入口別診断','headers':detail_headers,'rows':detail},
              {'name':'全セッション','headers':scene_headers,'rows':scene_rows}]
    assert [len(t['rows']) for t in result] == [360,79,73]
    assert all(len(t['headers']) == len(set(t['headers'])) and all(len(r) == len(t['headers']) for r in t['rows']) for t in result)
    return result


# ----------------------------------------
def evaluate(f1: dict) -> None:
    """
    機能: F1不変を確認後だけ金融を読み、固定方向票で全条件を評価する。
    引数: f1(dict)は金融前の入力/コード/文書指紋。
    返り値: None。既存結果を変更せず新しい結果を保存する。
    """
    assert all(sha(Path(p)) == expected for p,expected in f1['ファイル'].items())
    fixed = json.loads((OWN / 'choices.json').read_bytes())
    data = json.loads(FINANCE.read_bytes())
    previous = json.loads(OLD.read_bytes())
    features = json.loads(FEATURE.read_bytes())
    metadata_bytes = gzip.decompress(META.read_bytes())
    assert hashlib.sha256(metadata_bytes).hexdigest() == 'b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
    metadata = json.loads(metadata_bytes)
    choices = {(c['session'],c['id']):c for c in fixed['choices']}
    fmap = {(f['session'],f['id']):f for f in features['features']}
    shared = load(SHARED,'135固定131関数')
    shared.POLICIES = POLICIES
    arithmetic = shared.module124()
    sessions = [s['session'] for s in data['scenes']]
    assert data['success'] and data['trial'] == 124 and sessions == fixed['sessions'] and len(sessions) == 73
    records = []
    seen = set()
    for scene in data['scenes']:
        assert scene['success'] and scene['cases']
        for case in scene['cases']:
            key = scene['session'],case['id']
            assert key not in seen and key in choices
            seen.add(key)
            choice,f = choices[key],fmap[key]
            side = case['original_side']
            q = case['original']['entry']
            assert side == choice['original_side'] == f['original_side']
            assert q == choice['entry_quote'] == case['reverse']['entry'] == f['entry_quote']
            assert q['quote_ok'] and 0 < q['bid'] < q['ask']
            assert case['original']['entry_price'] == (q['ask'] if side == 1 else q['bid'])
            assert case['reverse']['entry_price'] == (q['bid'] if side == 1 else q['ask'])
            for name in ('original','reverse','chart_original','chart_reverse'):
                candidate = case[name]
                assert candidate['entry'] == q and candidate['status'] == 'filled'
                assert candidate['birth']['side'] == (side if name in ('original','chart_original') else -side)
                if name.startswith('chart_'):
                    assert candidate['entry_price'] == q['last']
                    assert all(o['net0'] is None and o['net5'] is None for o in candidate['outcomes'])
            records.append({'session':key[0],'case':case,'choice':choice})
    assert len(records) == len(choices) == len(fmap) == 79 and seen == set(choices)
    phase = shared.assert_execution_phase(records,sessions,metadata)
    phase['対象'] = '全6政策/両軸/両H/全幅、重複選択を含む'
    values = shared.aggregate_records(records,sessions,arithmetic)
    for part in ('all','train','validation'):
        assert values[part]['C0'] == previous['集計'][part]['T8']
        assert values[part]['O0'] == previous['集計'][part]['O0']
    counts = Counter(r['session'] for r in records)
    assert len(counts) == 73 and min(counts.values()) >= 1
    s = values['all']['U0']['BBO']['3600']['125']
    goal = {'全73場最低1取得':True,'到達済み70%以上':s['target70'], '両条件達成':s['target70'] is True,
            '取得数':79,'順':s['forward'],'逆':s['adverse'],'未到達':s['neither'],'不足':s['censored']}
    typed_tables = tables(records,sessions,values,arithmetic,shared)
    result = {'成功':True,'試行':135,'主政策':'U0','目標判定':goal,'集計':values,
              '同caseのC0との差':{p:shared.paired(records,p,'C0',arithmetic) for p in POLICIES},
              '旧対照120条件同体':True,'全選択streamのphase検査':phase,
              'bootstrap':arithmetic.bootstrap(records,sessions),'F1_SHA256':sha(OWN/'F1.json'),
              '全期間既使用':True,'独立未知期':False,'Raw再読':False,'逆注文適格性再構築':False,'口座損益':False,
              '注意':'既使用79件の方向診断。独立1mini IFD代用、追尾/実IFD/10枚口座ではない。'}
    assert all(sha(Path(p)) == expected for p,expected in f1['ファイル'].items())
    save(OWN/'集計.json',result)
    save(OWN/'CSV用の表.json',{'成功':True,'試行':135,'主政策':'U0','tables':typed_tables})
    save(OWN/'評価完了.json',{'成功':True,'試行':135,'F1_SHA256':sha(OWN/'F1.json'),
         '全固定ファイル前後同体':True,'集計SHA256':sha(OWN/'集計.json'),'表SHA256':sha(OWN/'CSV用の表.json')})
    print(json.dumps({'成功':True,'試行':135,'主判定':goal,'主H60±125':{p:values['all'][p]['BBO']['3600']['125'] for p in POLICIES}},ensure_ascii=False))


# ----------------------------------------
def main() -> None:
    """
    機能: 固定モードで非金融票とF1を作り、評価モードだけ金融を開く。
    引数: CLI --mode(str)は固定又は評価。
    返り値: None。
    """
    parser = argparse.ArgumentParser(description='135の固定79取得・公表差の方向比較')
    parser.add_argument('--mode',choices=('固定','評価'),required=True)
    args = parser.parse_args()
    if args.mode == '固定':
        assert not (OWN/'F1.json').exists() and not (OWN/'choices.json').exists()
        choices = prepare()
        save(OWN/'choices.json',choices)
        files = set(SOURCES) | {DIAG,META,SHARED,ROOT/'work/135正式文書を準備する.py'}
        files.update(p for p in OWN.iterdir() if p.is_file() and p.suffix in ('.md','.py','.json'))
        files.update(p for p in FORMAL.iterdir() if p.is_file() and p.suffix == '.md')
        f1 = {'成功':True,'試行':135,'段階':'金融前F1','UTC':datetime.now(timezone.utc).isoformat(),
              '主':'U0/全73場/H60±125/同幅先着70%以上','ファイル':{str(p):sha(p) for p in sorted(files)}}
        save(OWN/'F1.json',f1)
        print(json.dumps({'成功':True,'F1_SHA256':sha(OWN/'F1.json'),'固定ファイル数':len(files),'金融読取':False},ensure_ascii=False))
    else:
        evaluate(json.loads((OWN/'F1.json').read_bytes()))


if __name__ == '__main__':
    main()
