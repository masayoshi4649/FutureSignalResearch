"""同じ出生の三公表による方向一致を検査する。金融結果は入力しない。"""

POLICIES = ('U0', 'C0', 'N0', 'D0', 'O0', 'R0')


def choose(original: int, e0: bool, csv: int, instant: int | None, delay: int | None) -> dict:
    """
    機能: 公表によって不安定な追加反転を止め、全ケースの取得を維持する。
    引数: original/csv(int)は±1、e0(bool)、instant/delay(int|None)は方向又は計算不能。
    返り値: dictは六政策の方向、三公表の一致・計算不能・Source復帰の理由。
    """
    assert type(original) is int and original in (-1, 1)
    assert type(e0) is bool
    assert type(csv) is int and csv in (-1, 1)
    assert all(v is None or type(v) is int and v in (-1, 1) for v in (instant, delay))
    if e0:
        assert csv == original
        assert all(v is None or v == original for v in (instant, delay))
    available = instant is not None and delay is not None
    unanimous = available and csv == instant == delay
    selected = original if e0 or not unanimous else csv
    sides = {'U0': selected, 'C0': csv,
             'N0': original if instant is None else instant,
             'D0': original if delay is None else delay,
             'O0': original, 'R0': -selected}
    reason = 'E0元方向保護' if e0 else '三公表一致' if unanimous else '公表利用不能でSource復帰' if not available else '公表方向不一致でSource復帰'
    return {'choices': {p: {'side': sides[p], 'action': 'keep' if sides[p] == original else 'flip'} for p in POLICIES},
            'all_available': available, 'unanimous': unanimous, 'reason': reason,
            'e0_protected': e0, 'inputs': {'csv': csv, 'instant': instant, 'delay': delay}}


# ----------------------------------------
def artificial() -> dict:
    """
    機能: 反対符号の鏡像、利用不能、E0保護、不正方向の拒否を金融なしで確認する。
    引数: なし。
    返り値: dictは確認数。失敗時はAssertionErrorを送出する。
    """
    cases = 0
    for original in (-1, 1):
        for csv in (-1, 1):
            for instant in (None, -1, 1):
                for delay in (None, -1, 1):
                    x = choose(original, False, csv, instant, delay)
                    mirror = choose(-original, False, -csv, None if instant is None else -instant,
                                    None if delay is None else -delay)
                    assert all(x['choices'][p]['side'] == -mirror['choices'][p]['side'] for p in POLICIES)
                    assert x['reason'] == mirror['reason']
                    assert x['choices']['R0']['side'] == -x['choices']['U0']['side']
                    if None in (instant, delay):
                        assert not x['all_available'] and x['choices']['U0']['side'] == original
                    if csv == instant == delay:
                        assert x['unanimous'] and x['choices']['U0']['side'] == csv
                    else:
                        assert not x['unanimous'] and x['choices']['U0']['side'] == original
                    cases += 1
    e0_count = 0
    for side in (-1, 1):
        for a in (None, side):
            for b in (None, side):
                x = choose(side, True, side, a, b)
                assert all(x['choices'][p]['side'] == side for p in POLICIES if p != 'R0')
                e0_count += 1
    rejected = 0
    for args in ((True, False, 1, 1, 1), (1, False, 1, 0, 1), (1, False, 1, True, 1),
                 (1, False, 1, float('nan'), 1), (1, True, -1, 1, 1), (1, True, 1, -1, 1)):
        try:
            choose(*args)
        except AssertionError:
            rejected += 1
        else:
            raise AssertionError('不正な向き又はE0矛盾を受け付けた')
    return {'成功': True, '鏡像と欠測の組合せ': cases, 'E0保護': e0_count, '不正入力拒否': rejected,
            '自然金融読取': False, '原板読取': False}


if __name__ == '__main__':
    import json
    print(json.dumps(artificial(), ensure_ascii=False))
