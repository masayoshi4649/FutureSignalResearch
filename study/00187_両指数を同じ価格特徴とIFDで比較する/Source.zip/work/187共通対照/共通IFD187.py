"""同じラージBBO約定代用・単一保有・ATR相対幅を両商品に使う。"""
from bisect import bisect_left,bisect_right
import math
import numpy as np
import 入力187 as I

PRODUCTS={'NK225':{'multiplier':100.,'tick':5.,'oneway_fee':38.5,'oneway_slip':5.},
          'TOPIX':{'multiplier':1000.,'tick':.25,'oneway_fee':41.8,'oneway_slip':.25}}
MULTIPLES=(1.5,2.5,4.)


def width(row,multiple):
    """
    機能: q0時点のATR15から対称IFD幅を決め、商品呼値へ切り上げる。
    引数: row(dict),multiple(float)。
    返り値: floatは価格pt。取得後の値幅で変更しない。
    """
    tick=PRODUCTS[row['product']]['tick']
    return max(tick,math.ceil(row['m15']['atr']*multiple/tick-1e-12)*tick)


def classify(row,side):
    """
    機能: q0で既知の場と背景を、商品共通の局面分類へ分ける。
    引数: row(dict),side(int)。
    返り値: strは帯/ADX水準/実方向の三足整合。成績を分類に使わない。
    """
    cs=[row['m'+str(n)] for n in (5,15,30)]
    aligned='実方向3足' if all(side*c['slope']>0 and side*c['di']>0 for c in cs) else '反対3足' if all(side*c['slope']<0 and side*c['di']<0 for c in cs) else '混在'
    adx=row['m15']['adx'];level='低20未満' if adx<20 else '中20以上25未満' if adx<25 else '高25以上'
    return '/'.join((('DAY','PRE','POST')[row['phase']],level,aligned))


class Route:
    """同じ価格時計・正常BBO列による取引経路。"""
    def __init__(self,data,entry):
        """
        機能: 一場の正常価格BBOだけを約定代用列として保持する。
        引数: data(dict),entry(dict)。
        返り値: None。価格と数量の市場差を混同しない。
        """
        mask=data['normal'];self.data={k:v[mask] for k,v in data.items()};self.entry=entry
        self.start,self.end,self.force,_=I.bounds(entry['session'])

    def cell(self,row,side,w):
        """
        機能: 取得後の最初のTP/SL接触又は期限を同じモデルで評価する。
        引数: row(dict)はq0、side(int),w(float)は先に固定した方向/幅。
        返り値: dict|Noneは取引又は未取得。未来の欠測は入口成立を取り消さない。
        """
        d=self.data;t=d['time'];q0=row['time'];i=bisect_left(t,q0+1)
        if i>=len(t) or t[i]>min(q0+30,self.force) or t[i]>=self.force:return None
        opened=float(t[i]);price=float(d['ask'][i] if side==1 else d['bid'][i]);mark=d['bid'] if side==1 else d['ask']
        deadline=min(opened+3600,self.force);last=bisect_right(t,deadline)
        change=side*(mark[i:last]-price);touches=np.flatnonzero((change>=w)|(change<=-w));touch=i+int(touches[0]) if len(touches) else None
        label=('F' if side*(mark[touch]-price)>=w else 'A') if touch is not None else 'N'
        target=float(t[touch]) if touch is not None else deadline
        j=touch if label=='F' else bisect_left(t,target+1);limit=min(target+30,self.end)
        fillable=j<len(t) and t[j]<=limit
        stop=j if fillable else max(i,min(bisect_right(t,limit)-1,len(t)-1))
        gaps=np.flatnonzero(np.diff(t[i:stop+1])>300);unknown=not fillable or bool(len(gaps))
        if len(gaps):confirmed=float(t[i+int(gaps[0])]);why='正常BBO300秒超空白'
        elif not fillable:confirmed=float(t[stop]);why='返済TTL内BBO不足'
        else:confirmed=float(t[j]);why=None
        original_label=label
        if unknown and (touch is None or len(gaps) and i+int(gaps[0])+1<=touch):label='C'
        exit_price=None if unknown else price+side*w if original_label=='F' else float(mark[j])
        gross=None if unknown else side*(exit_price-price);spec=PRODUCTS[row['product']]
        fee=2*spec['oneway_fee'];slip=2*spec['oneway_slip']*spec['multiplier']
        net=None if unknown else round(gross*spec['multiplier']-fee-slip,1)
        return {'session':row['session'],'product':row['product'],'phase':row['phase'],'request_time':q0,'request_line':row['line'],
            'entry_time':opened,'entry_line':int(d['line'][i]),'entry_price':price,'side':side,'width':w,'atr15':row['m15']['atr'],
            'exit_time':None if unknown else float(t[j]),'exit_line':None if unknown else int(d['line'][j]),'exit_price':exit_price,
            'gross_pt':gross,'known':not unknown,'net':net,'label':label,'reason':{'F':'IFD利確指値','A':'IFD損切','N':'通常期限又は終了前'}[original_label],
            'unknown_reason':why,'confirmed_until':confirmed,'possible_until':self.end if unknown else float(t[j]),
            'regime':classify(row,side),'gross_R':None if unknown else gross/w,
            'fee_R':fee/spec['multiplier']/w,'slip_R':slip/spec['multiplier']/w,
            'net_R':None if unknown else net/spec['multiplier']/w,'spread_R':float(d['ask'][i]-d['bid'][i])/w,
            'q0_spread_R':(row['ask']-row['bid'])/w,'width_ATR15':w/row['m15']['atr'],
            'atr15_price':row['atr_price'],'atr5_atr15':row['atr5_atr15']}


def metadata(entries):
    """
    機能: 全81場を残した参加分母を作る。
    引数: entries(list[dict])。
    返り値: list[dict]は共通安定性API用の場と実時間三帯。
    """
    result=[]
    for e in entries:
        s=e['session'];a,b,_,ny=I.bounds(s);day=s.endswith('Day')
        phases=[{'name':'DAY','start':a,'end':b}] if day else [{'name':'PRE','start':a,'end':ny},{'name':'POST','start':ny,'end':b}]
        result.append({'scene':s,'kind':'DAY' if day else 'NIGHT','start':a,'end':b,'phases':phases})
    return result


def pack(identifier,entries,cells):
    """
    機能: 実取得だけから費用後金融・確定保有・正規化値を保存する。
    引数: identifier(str),entries/cells(list[dict])。
    返り値: dictは共通安定性集計へ渡せるpack。未知を0円化しない。
    """
    fields=('known','net','phase','entry_time','exit_time','side','width','entry_price','exit_price','entry_line','exit_line','label',
            'request_time','request_line','gross_pt','reason','unknown_reason','gross_R','fee_R','slip_R','net_R','spread_R','q0_spread_R',
            'width_ATR15','atr15','atr15_price','atr5_atr15','regime')
    ledger={k:[c[k] for c in cells] for k in fields};ledger['scene']=[c['session'] for c in cells]
    positions=[{'scene':c['session'],'fill':c['entry_time'],'exit':c['exit_time'],'confirmed_until':c['confirmed_until'],'possible_until':c['possible_until']} for c in cells]
    return {'id':identifier,'sessions':metadata(entries),'ledger':ledger,'positions':positions}
