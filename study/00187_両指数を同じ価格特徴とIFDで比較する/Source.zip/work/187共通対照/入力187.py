"""両商品の恒久価格索引を、数量を読まない同じ6列へ接続する。"""
from pathlib import Path
from datetime import datetime,timedelta,timezone
from zoneinfo import ZoneInfo
import gzip,hashlib,json
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
JST=timezone(timedelta(hours=9));NY=ZoneInfo('America/New_York')
RECORD=np.dtype({'names':['time','source_line','last','bid','ask','normal'],
    'formats':['<f8','<i8','<f8','<f8','<f8','<u8'],'offsets':[0,8,16,24,32,40],'itemsize':48})


def ref(path):
    """
    機能: 参照入力の内容指紋を返す。
    引数: path(Path)。
    返り値: dictは相対パス・bytes・SHA256。
    """
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':digest}


def sessions():
    """
    機能: 正式manifestだけから両商品同名81場の価格入力参照を作る。
    引数: なし。
    返り値: dict[str,list[dict]]はNK225/TOPIX。数量台帳は読まない。
    """
    result={'NK225':[],'TOPIX':[]}
    for location in ('00163_任意幅の共用価格索引/価格索引','00167_追加七場の入口と共用価格索引/原板数値索引',
                     '00180_20261116デイの固定適用入力/原板数値索引'):
        folder=ROOT/'inputs'/location;manifest=folder/'manifest.json';data=json.loads(manifest.read_text(encoding='utf-8'))
        assert data['success']
        for r in data['scenes']:
            result['NK225'].append({'product':'NK225','session':r['session'],'contract':r['contract'],'kind':'48byte',
                'path':(folder/r['index']['path']).relative_to(ROOT).as_posix(),'sha256':r['index']['sha256'],
                'rows':r['rows'],'manifest':ref(manifest)})
    path=ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json';data=json.loads(path.read_text(encoding='utf-8'))
    for r in data['entries']:
        result['TOPIX'].append({'product':'TOPIX','session':r['session'],'contract':'TOPIX_202612','kind':'8列から価格のみ',
            'path':r['path'],'sha256':r['sha256'],'manifest':ref(path)})
    assert len(result['NK225'])==len(result['TOPIX'])==81
    assert [r['session'] for r in result['NK225']]==[r['session'] for r in result['TOPIX']]
    return result


def bounds(scene):
    """
    機能: 全商品共通の開始・終了・返済要求・NY開始を定義する。
    引数: scene(str)は開始日基準の場名。
    返り値: tuple[float,float,float,float]は開始/終了/終了1分前/NY開始。
    """
    d=datetime.fromisoformat(scene[:10]).replace(tzinfo=JST)
    start=d+timedelta(hours=8,minutes=45) if scene.endswith('Day') else d+timedelta(hours=17)
    end=d+timedelta(hours=15,minutes=30) if scene.endswith('Day') else d+timedelta(days=1,hours=5,minutes=45)
    nydate=start.astimezone(NY).date();ny=datetime.combine(nydate,datetime.min.time(),NY)+timedelta(hours=9,minutes=30)
    return start.timestamp(),end.timestamp(),end.timestamp()-60,ny.timestamp()


def band(scene,time):
    """
    機能: 新規判断時計から三帯を決める。
    引数: scene(str),time(float)。
    返り値: intはDAY=0/PRE=1/POST=2。
    """
    return 0 if scene.endswith('Day') else 1 if time<bounds(scene)[3] else 2


def load(entry):
    """
    機能: 永久入力を価格6列で読む。未来欠測を入口除外条件へ使わない。
    引数: entry(dict)はsessionsの一場参照。
    返り値: tuple[dict[str,np.ndarray],dict]は単調価格時計の場内配列と品質件数。
    """
    path=ROOT/entry['path'];assert ref(path)['sha256']==entry['sha256']
    if entry['kind']=='48byte':
        raw=gzip.decompress(path.read_bytes());assert raw[:8]==b'NQIDX163' and len(raw)==8+48*entry['rows']
        z=np.frombuffer(raw,dtype=RECORD,offset=8)
        data={k:z[v] for k,v in {'time':'time','line':'source_line','last':'last','bid':'bid','ask':'ask'}.items()}
        stored=z['normal']==1
    else:
        with np.load(path,allow_pickle=False) as z:
            data={k:z[v] for k,v in {'time':'now','line':'line','last':'last','bid':'bid','ask':'ask'}.items()}
            stored=z['valid']
    t=data['time'];finite=np.isfinite(t);prior=np.maximum.accumulate(np.where(finite,t,-np.inf))
    start,end,_,_=bounds(entry['session']);monotonic=finite&(t>=prior);inside=(t>=start)&(t<end)
    normal=np.isfinite(data['bid'])&np.isfinite(data['ask'])&(data['bid']>0)&(data['ask']>data['bid'])
    quality={'input_rows':len(t),'clock_missing':int((~finite).sum()),'backward':int((finite&~monotonic).sum()),
        'outside':int((finite&~inside).sum()),'stored_normal_difference':int((finite&(normal!=stored)).sum()),
        'quantity_used':False}
    # ----------------------------------------
    # 保存済み品質を昇格させない。TOPIXの数量1以上を含むvalidも保持する。
    keep=monotonic&inside;out={k:v[keep] for k,v in data.items()};out['normal']=(normal&stored)[keep]
    assert np.all(np.diff(out['time'])>=0) and np.all(np.diff(out['line'])>0)
    quality.update(kept_rows=len(out['time']),normal_rows=int(out['normal'].sum()))
    return out,quality
