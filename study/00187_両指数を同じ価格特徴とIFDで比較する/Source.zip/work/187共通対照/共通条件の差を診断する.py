"""187の固定金融を変更せず、可用時間・指標記憶・尺度・取得局面を分解する。"""
from collections import Counter,defaultdict,deque
from pathlib import Path
import math
import numpy as np
import 入力187 as I
import 特徴187 as F
import 実行187 as R

HERE=Path(__file__).parent


def distribution(values):
    """
    機能: 有限値の分布を共通の分位で要約する。
    引数: values(iterable[float])。
    返り値: dictは件数・平均・分位。不明値を0にしない。
    """
    a=np.asarray([v for v in values if v is not None and math.isfinite(v)],dtype=float)
    return {'count':len(a),'mean':float(a.mean()) if len(a) else None,
        **{name:float(np.quantile(a,q)) if len(a) else None for name,q in [('min',0),('p10',.1),('median',.5),('p90',.9),('max',1)]}}


def intersect(a,b):
    """
    機能: 二つの非重複時刻区間の共通部分を得る。
    引数: a/b(list[tuple[float,float]])は開始順。
    返り値: list[tuple[float,float]]は正の長さの重複だけ。
    """
    out=[];i=j=0
    while i<len(a) and j<len(b):
        x=max(a[i][0],b[j][0]);y=min(a[i][1],b[j][1])
        if x<y:out.append((x,y))
        if a[i][1]<=b[j][1]:i+=1
        else:j+=1
    return out


def contains(windows,value):
    """
    機能: 既に公開された共通判断区間に時刻が含まれるか診断する。
    引数: windows(list[tuple]),value(float)。
    返り値: bool。入口選択や金融へ反映しない。
    """
    return any(a<=value<b for a,b in windows)


def active_span(a,b,calendar):
    """
    機能: 指標の近傍有効足の最初から最後までにある対象取引秒を数える。
    引数: a/b(float),calendar(list[tuple])。
    返り値: floatは市場閉鎖を除く時間跨度。欠測時間は残す。
    """
    return sum(max(0,min(b,y)-max(a,x)) for x,y in calendar)


def availability(entries,pure):
    """
    機能: 原入力から形成率と有効足順更新の記憶跨度を再構成する。
    引数: entries(dict),pure(dict)は封印済み情報。
    返り値: dictは場別/共通窓/近傍指標跨度。固定特徴の書換えはしない。
    """
    by_scene={p:defaultdict(list) for p in entries}
    for p in entries:
        for row in pure[p]['rows']:by_scene[p][row['session']].append(row)
    common=[];windows={};span_output={};formation=[]
    calendar=[I.bounds(e['session'])[:2] for e in entries['NK225']]
    for e in entries['NK225']:
        s=e['session'];a,b,_,ny=I.bounds(s)
        ws={p:[(r['time'],r['window_end']) for r in by_scene[p][s] if r['window_end']>r['time']] for p in entries}
        joint=intersect(ws['NK225'],ws['TOPIX']);windows[s]=joint
        phases=[('DAY',a,b)] if s.endswith('Day') else [('PRE',a,ny),('POST',ny,b)]
        for phase,x,y in phases:
            common.append({'session':s,'phase':phase,'eligible_seconds':y-x,
                **{p+'_available_seconds':sum(max(0,min(v,y)-max(u,x)) for u,v in ws[p]) for p in entries},
                'common_seconds':sum(max(0,min(v,y)-max(u,x)) for u,v in joint),
                **{p+'_q0':sum(x<=r['time']<y for r in by_scene[p][s]) for p in entries}})
    for product,scenes in entries.items():
        histories={n:deque(maxlen=F.WARM[n]) for n in F.WARM};contract=None;spans=defaultdict(list)
        for e in scenes:
            if e['contract']!=contract:histories={n:deque(maxlen=F.WARM[n]) for n in F.WARM};contract=e['contract']
            data,_=I.load(e);scene=e['session'];a,b,_,_=I.bounds(scene);series={n:F.bars(data,scene,n) for n in (1,5,15,30)}
            for size,bs in series.items():
                reasons=Counter(r for bar in bs for r in bar['reasons'])
                formation.append({'product':product,'session':scene,'minutes':size,
                    'nominal_full_slots':int((b-a)//(size*60)),'published_observed':len(bs),'usable':sum(x['usable'] for x in bs),
                    'reasons':dict(reasons)})
            pointers={n:0 for n in histories}
            for row in by_scene[product][scene]:
                for size,history in histories.items():
                    while pointers[size]<len(series[size]) and series[size][pointers[size]]['pub_index']<=row['index']:
                        bar=series[size][pointers[size]];pointers[size]+=1
                        if bar['usable']:history.append(bar)
                    assert len(history)==F.WARM[size]
                    wall=history[-1]['end']-history[0]['start'];active=active_span(history[0]['start'],history[-1]['end'],calendar)
                    spans[(size,'wall_seconds')].append(wall);spans[(size,'active_seconds')].append(active)
                    spans[(size,'active_to_nominal_ratio')].append(active/(F.WARM[size]*size*60))
            for size,history in histories.items():
                for bar in series[size][pointers[size]:]:
                    if bar['usable']:history.append(bar)
        span_output[product]={str(size):{key:distribution(spans[(size,key)]) for key in ('wall_seconds','active_seconds','active_to_nominal_ratio')} for size in F.WARM}
    totals=[]
    for phase in ('ALL','DAY','PRE','POST'):
        selected=[r for r in common if phase=='ALL' or r['phase']==phase]
        totals.append({'phase':phase,**{key:sum(r[key] for r in selected) for key in ('eligible_seconds','NK225_available_seconds','TOPIX_available_seconds','common_seconds','NK225_q0','TOPIX_q0')}})
    quality={p:dict(sum((Counter(r['counts']) for r in pure[p]['quality']),Counter())) for p in entries}
    return {'definition':'純q0公開後から同じ判断分枠末までの保守的区間。連続観測可能時間全体ではない。区間終端は開区間。',
        'indicator_update':'不良足を飛ばし、有効足順でEMA等を更新する。近傍35/21有効足は指数の全記憶ではなく、最近の更新間隔診断。',
        'common_windows_usage':'事後診断だけ。共通窓で原入口を選別せず、将来の欠測による除外も行わない。',
        'quality_counts':quality,'common_totals':totals,'common_sessions':common,'common_windows':windows,
        'formation':formation,'nearby_valid_history':span_output}


def regime_background(row):
    """
    機能: 売買条件以前のq0背景を共通区分へ分類する。
    引数: row(dict)。
    返り値: strは帯/ADX/絶対的三足方向。
    """
    cs=[row['m'+str(n)] for n in (5,15,30)];direction='買3足' if all(c['slope']>0 and c['di']>0 for c in cs) else '売3足' if all(c['slope']<0 and c['di']<0 for c in cs) else '混在'
    adx=row['m15']['adx'];level='低20未満' if adx<20 else '中20以上25未満' if adx<25 else '高25以上'
    return '/'.join((('DAY','PRE','POST')[row['phase']],level,direction))


def outcome(rows):
    """
    機能: 取得済取引の正規化成績と費用・値幅分布をまとめる。
    引数: rows(list[dict])はledgerの行。
    返り値: dict。未知は0にせず既知成績の条件付き要約とする。
    """
    known=[r for r in rows if r['known']];n=len(rows);u=n-len(known);negative=sum(r['net']<0 for r in known)
    result={'acquired':n,'known':len(known),'unknown':u,'negative_rate_lower':negative/n if n else None,'negative_rate_upper':(negative+u)/n if n else None,
        'first_F':sum(r['label']=='F' for r in rows),'first_A':sum(r['label']=='A' for r in rows),'not_reached':sum(r['label']=='N' for r in rows),'censored':sum(r['label']=='C' for r in rows)}
    for key in ('width','width_ATR15','atr15','atr15_price','atr5_atr15','spread_R','fee_R','slip_R','gross_R','net_R'):
        result[key]=distribution(r[key] for r in rows)
    result['cost_R']=distribution(r['fee_R']+r['slip_R'] for r in rows)
    result['known_net_R_sum']=sum(r['net_R'] for r in known)
    return result


def composition(packs):
    """
    機能: 同家族同幅の取得済既知取引を同じ局面内差と群構成差へ算術分解する。
    引数: packs(list[dict])。
    返り値: list[dict]。共通支持局面に限定した記述であり、市場差の因果効果ではない。
    """
    pairs=defaultdict(dict);out=[]
    for pack in packs:pairs[(pack['family'],pack['multiple'])][pack['product']]=pack
    for (family,multiple),pair in pairs.items():
        grouped={p:defaultdict(list) for p in pair}
        for p,pack in pair.items():
            l=pack['ledger']
            for i in range(len(l['known'])):
                if l['known'][i]:grouped[p][l['regime'][i]].append({k:l[k][i] for k in ('net_R','gross_R','fee_R','slip_R')})
        common=sorted(set(grouped['NK225'])&set(grouped['TOPIX']))
        counts={p:sum(len(grouped[p][k]) for k in common) for p in pair};total={p:sum(map(len,grouped[p].values())) for p in pair}
        row={'family':family,'multiple':multiple,'common_regimes':common,'common_known':counts,'all_known':total,'decomposition':{}}
        for value in ('net_R','gross_R','fee_R','slip_R'):
            within=mixture=0.;details=[]
            for k in common:
                weights={p:len(grouped[p][k])/counts[p] for p in pair};means={p:sum(r[value] for r in grouped[p][k])/len(grouped[p][k]) for p in pair}
                w=.5*(weights['NK225']+weights['TOPIX'])*(means['NK225']-means['TOPIX'])
                m=.5*(means['NK225']+means['TOPIX'])*(weights['NK225']-weights['TOPIX']);within+=w;mixture+=m
                details.append({'regime':k,'count':{p:len(grouped[p][k]) for p in pair},'weight':weights,'mean':means,'within':w,'composition':m})
            means={p:sum(r[value] for k in common for r in grouped[p][k])/counts[p] if counts[p] else None for p in pair}
            difference=means['NK225']-means['TOPIX'] if all(v is not None for v in means.values()) else None
            assert difference is None or math.isclose(within+mixture,difference,abs_tol=1e-10)
            row['decomposition'][value]={'common_mean':means,'NK_minus_TOPIX':difference,'within_regime':within,'regime_composition':mixture,'details':details}
        out.append(row)
    return out


def main():
    """
    機能: 固定18口座と純特徴を読むだけの診断を保存する。
    引数: なし。
    返り値: None。
    """
    entries=I.sessions();pure={p:R.read(HERE/'純特徴'/(p+'.json.gz')) for p in entries};qa=availability(entries,pure)
    R.save(HERE/'形成可用性と有効足記憶の診断.json.gz',qa)
    backgrounds=[]
    for p in entries:
        grouped=defaultdict(list)
        for r in pure[p]['rows']:grouped[regime_background(r)].append(r)
        for key,rows in grouped.items():
            backgrounds.append({'product':p,'regime':key,'q0':len(rows),'q0_fraction':len(rows)/len(pure[p]['rows']),
                'available_seconds':sum(max(0,r['window_end']-r['time']) for r in rows),
                'in_common_window':sum(contains(qa['common_windows'][r['session']],r['time']) for r in rows),
                'signals':{f:sum(bool(r['signals'][f]) for r in rows) for f in ('T','R','M')}})
    packs=[R.read(p) for p in sorted((HERE/'金融正本').glob('*.json.gz'))];tables=[]
    for pack in packs:
        l=pack['ledger'];rows=[{k:v[i] for k,v in l.items()} for i in range(len(l['known']))];grouped=defaultdict(list)
        for r in rows:grouped[r['regime']].append(r)
        table={'id':pack['id'],'all':outcome(rows),'by_regime':{k:outcome(v) for k,v in grouped.items()}}
        for status in (True,False):
            selected=[r for r in rows if contains(qa['common_windows'][r['scene']],r['request_time'])==status]
            table['common_q0_window' if status else 'outside_common_q0_window']=outcome(selected)
        tables.append(table)
    R.save(HERE/'共通尺度と局面構成の診断.json.gz',{'notice':'取得済み既知取引に限る条件付き記述。未知損益・未取得の仮想利益を補完しない。群構成分解は観測品質・値幅・費用・条件への選択を含み、市場差の因果推定ではない。',
        'backgrounds':backgrounds,'policies':tables,'composition':composition(packs)})
    print({'可用性場帯':len(qa['common_sessions']),'口座':len(tables),'局面構成':len(backgrounds),'共通':qa['common_totals'][0]},flush=True)


if __name__=='__main__':main()
