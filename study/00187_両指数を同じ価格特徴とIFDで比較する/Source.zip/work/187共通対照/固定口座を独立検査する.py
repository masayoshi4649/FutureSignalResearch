"""187の18口座を、別の線形接触走査と既存独立集計監査で検算する。"""
from collections import defaultdict
from pathlib import Path
import importlib.util
import math
import numpy as np
import 入力187 as I
import 実行187 as R

HERE=Path(__file__).parent


def equal(a,b,where):
    """
    機能: Noneを保持し数値だけ丸め誤差許容で照合する。
    引数: a/b(object),where(tuple)。
    返り値: intは属性数1。
    """
    if isinstance(a,(int,float)) and isinstance(b,(int,float)):assert math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-8),(where,a,b)
    else:assert a==b,(where,a,b)
    return 1


def independent(data,scene,row,side,multiple):
    """
    機能: 固定仕様の取得・最初接触・返済を原BBOの線形走査で検算する。
    引数: data(dict),scene(str),row(dict),side(int),multiple(float)。
    返り値: dict|Noneは独立計算取引。Route/価格到達木は使用しない。
    """
    normal=np.where(data['normal'])[0];times=data['time'][normal];start,end,force,_=I.bounds(scene)
    tick,multiplier,fee,slip=(5.,100.,77.,10.) if row['product']=='NK225' else (.25,1000.,83.6,.5)
    width=max(tick,math.ceil(row['m15']['atr']*multiple/tick-1e-12)*tick)
    eligible=np.where((times>=row['time']+1)&(times<=row['time']+30)&(times<force))[0]
    if not len(eligible):return None
    i=int(eligible[0]);at=int(normal[i]);opened=float(times[i]);price=float(data['ask'][at] if side==1 else data['bid'][at]);deadline=min(opened+3600,force)
    touch=None;label='N'
    candidates=np.where((times>=opened)&(times<=deadline))[0]
    candidates=candidates[candidates>=i]
    for k in candidates:
        v=float(data['bid' if side==1 else 'ask'][normal[k]]);change=side*(v-price)
        if change>=width:touch=int(k);label='F';break
        if change<=-width:touch=int(k);label='A';break
    target=float(times[touch]) if touch is not None else deadline
    fill=None
    if label=='F':fill=touch
    else:
        hits=np.where((times>=target+1)&(times<=min(target+30,end)))[0]
        if len(hits):fill=int(hits[0])
    observed=np.where((times<=min(target+30,end))&(np.arange(len(times))>=i))[0]
    stop=fill if fill is not None else int(observed[-1]) if len(observed) else i
    broken=None
    for k in range(i+1,stop+1):
        if times[k]-times[k-1]>300:broken=k;break
    unknown=fill is None or broken is not None
    confirmed=float(times[broken-1] if broken is not None else times[stop])
    saved_label='C' if unknown and (touch is None or broken is not None and broken<=touch) else label
    exited=None if unknown else float(times[fill]);exitprice=None if unknown else price+side*width if label=='F' else float(data['bid' if side==1 else 'ask'][normal[fill]])
    gross=None if unknown else side*(exitprice-price);net=None if unknown else round(gross*multiplier-fee-slip*multiplier,1)
    return {'known':not unknown,'net':net,'label':saved_label,'entry_time':opened,'entry_line':int(data['line'][at]),'entry_price':price,
        'exit_time':exited,'exit_line':None if unknown else int(data['line'][normal[fill]]),'exit_price':exitprice,
        'width':width,'side':side,'request_time':row['time'],'request_line':row['line'],'gross_pt':gross,
        'gross_R':None if unknown else gross/width,'net_R':None if unknown else net/multiplier/width,
        'fee_R':fee/multiplier/width,'slip_R':slip/width,'spread_R':float(data['ask'][at]-data['bid'][at])/width,
        'q0_spread_R':(row['ask']-row['bid'])/width,'width_ATR15':width/row['m15']['atr'],
        'reason':{'F':'IFD利確指値','A':'IFD損切','N':'通常期限又は終了前'}[label],
        'unknown_reason':None if not unknown else '正常BBO300秒超空白' if broken is not None else '返済TTL内BBO不足',
        'confirmed_until':confirmed,'possible_until':end if unknown else exited}


def main():
    """
    機能: 全18口座の全取得と追加禁止/失効を再走査し、集計と封印SHAも検査する。
    引数: なし。
    返り値: None。成功時は照合票を保存する。
    """
    spec=R.read(R.TRIAL/'条件.json');assert all(I.ref(I.ROOT/x['path'])==x for x in spec['source'])
    module=importlib.util.spec_from_file_location('audit183',I.ROOT/'work/183損失安定性/新候補の集計を独立検査する.py')
    A=importlib.util.module_from_spec(module);module.loader.exec_module(A)
    stats={s['id']:s for s in R.read(HERE/'全18組安定性.json.gz')['metrics']};financial=aggregates=trades=0;records=[]
    for product,entries in I.sessions().items():
        pure=R.read(HERE/'純特徴'/(product+'.json.gz'));by_scene=defaultdict(list)
        for row in pure['rows']:by_scene[row['session']].append(row)
        packs={}
        for family in ('T','R','M'):
            for multiple in (1.5,2.5,4.):
                name=f'{product}187_{family}_ATR15x{multiple:g}_H60';packs[(family,multiple)]=R.read(HERE/'金融正本'/(name+'.json.gz'))
        indexes={k:0 for k in packs};attributes={k:0 for k in packs}
        for entry in entries:
            data,_=I.load(entry);scene=entry['session'];force=I.bounds(scene)[2]
            for key,pack in packs.items():
                family,multiple=key;busy=-math.inf;state=None;counts={'scene':scene,'signal':0,'held_blocked':0,'pending_blocked':0,'expired':0,'acquired':0}
                for row in by_scene[scene]:
                    side=row['signals'][family]
                    if not side:continue
                    counts['signal']+=1
                    if row['time']<=busy:counts['pending_blocked' if state=='pending' else 'held_blocked']+=1;continue
                    result=independent(data,scene,row,side,multiple)
                    if result is None:counts['expired']+=1;busy=min(row['time']+30,force);state='pending';continue
                    i=indexes[key];l=pack['ledger'];position=pack['positions'][i]
                    attributes[key]+=equal(l['scene'][i],scene,(pack['id'],i,'scene'))
                    for field,value in result.items():
                        actual=position[field] if field in ('confirmed_until','possible_until') else l[field][i]
                        attributes[key]+=equal(actual,value,(pack['id'],i,field))
                    indexes[key]+=1;counts['acquired']+=1;busy=result['exit_time'] if result['known'] else I.bounds(scene)[1];state='holding'
                saved=next(r for r in pack['diagnostics'] if r['scene']==scene);assert counts==saved,(pack['id'],scene,counts,saved)
        for key,pack in packs.items():
            assert indexes[key]==len(pack['ledger']['known']);trades+=indexes[key];financial+=attributes[key]
            shadow={**pack,'evidence':None,'periods':{p:None for p in stats[pack['id']]['periods']}}
            n=A.verify(shadow,stats[pack['id']]);aggregates+=n;records.append({'id':pack['id'],'trades':indexes[key],'financial_attributes':attributes[key],'aggregate_attributes':n})
        print({'独立検査':product,'全取得累計':trades},flush=True)
    proof={'成功':True,'口座':len(records),'取得':trades,'金融属性':financial,'集計属性':aggregates,'source同体':True,
        '方法':'Routeと到達木を使わず、正常BBO列を最初接触まで線形走査。全q0から単一保有/予約を再生。集計は183独立算術。価格入力接続だけ共有。',
        '参照Source':I.ref(I.ROOT/'work/183損失安定性/新候補の集計を独立検査する.py'),'records':records}
    R.save(HERE/'全18口座の独立確認.json',proof);print({k:v for k,v in proof.items() if k!='records'},flush=True)


if __name__=='__main__':main()
