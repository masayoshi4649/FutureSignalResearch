"""187の同一価格特徴・同一IFDを、純封印と金融に分けて実行する。"""
from pathlib import Path
from collections import defaultdict
import argparse,gzip,hashlib,importlib.util,json,time
import 入力187 as I
import 特徴187 as F
import 共通IFD187 as E

ROOT=I.ROOT;HERE=Path(__file__).parent
TRIAL=ROOT/'study/00187_両指数を同じ価格特徴とIFDで比較する'
SOURCES=('入力187.py','特徴187.py','共通IFD187.py','人工検査187.py','実行187.py')


def save(path,value):
    """
    機能: 決定的UTF-8 JSONとして新規保存し、再実行は同体を確認する。
    引数: path(Path),value(object)。
    返り値: None。未知はNoneを保持しNaNを保存しない。
    """
    raw=(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
    data=gzip.compress(raw,mtime=0) if path.suffix=='.gz' else raw
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():assert path.read_bytes()==data,path
    else:path.write_bytes(data)


def read(path):
    """
    機能: JSON/gzip JSONを読む。
    引数: path(Path)。
    返り値: objectは保存値。
    """
    raw=path.read_bytes();return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def freeze(entries):
    """
    機能: 共通価格条件・費用・Source・入力を新金融前に固定する。
    引数: entries(dict)は81場×2商品。
    返り値: dictは固定条件。金融成績を参照しない。
    """
    specification={'trial':187,'quantity_used':False,'quantity_followup_trial':188,
        'products':E.PRODUCTS,'width_ATR15_multiples':list(E.MULTIPLES),'families':{
            'T':'三足EMA/DI整合＋MA近傍の動力再開。固定水準の持続受容や押戻し履歴を観測したと呼ばない。',
            'R':'ADX15<25＋BB5反対側0.5σ以上＋1分方向/位置＋RSI/MACD増分回復。',
            'M':'ADX15>=25ではT、それ以外R。同じ指標閾値と売買鏡像。'},
        'feature_clock':'CurrentPriceTimeと元行順。1分q0と5/15/30分は原価格から直接形成。量を出生条件に使わない。',
        'bar_quality':'足始め初価格30秒内・足終端公表30秒内・価格観測から公表まで300秒超空白なし。未知の空足を作らない。',
        'warmup':F.WARM,'indicator_seed':'EMAは最初終値、Wilder ATRは最初TR、方向増分/ADXは0初値。係数はSourceへ固定。',
        'carry':'同商品同限月の完成指標だけ継承。1分直前3本と未完成足は場をまたがない。',
        'normal':'保存normal/valid AND 有限正Bid<Ask。TOPIX保存validの両数量>=1を無視しない。NK48には数量列なし。',
        'execution':'q0+1秒以降30秒内の最初正常BBO。買Ask/売Bid。TPは返済側接触行の事前指値価格、SL/期限は+1秒以後30秒内の最初正常BBO。取得行のspread SLも対象。',
        'horizon_seconds':3600,'capacity':1,'pending':'未取得TTL中も追加禁止。保有未知は場末まで枠を空けない。',
        'close':'Day15:29/Night05:44要求。15:30/05:45までの共通分母。入口一律待機なし。',
        'missing':'正常BBO300秒超空白又は返済TTL不足は金融未知。将来の欠測を入口除外に使わない。',
        'evaluation':'通貨収支を商品間順位に混ぜず、幅R・ATR比・費用/R・spread/R・参加・未知・局面出現/同局面内を比較。全81は既使用。',
        'source':[I.ref(HERE/n) for n in SOURCES]+[I.ref(ROOT/'work/183損失安定性/安定性183.py')],
        'inputs':entries,'artificial':read(HERE/'人工確認187.json')}
    save(TRIAL/'条件.json',specification)
    return specification


def pure(entries):
    """
    機能: 両商品の純特徴と同じ複合方向を、金融なしで封印する。
    引数: entries(dict)は固定81場ずつの入力。
    返り値: None。価格入力を複製せず純q0を保存する。
    """
    freeze(entries);generated=[];bench=[]
    for product,scenes in entries.items():
        begin=time.perf_counter();rows=[];quality=[];channels={n:F.Channel() for n in (5,15,30)};contract=None
        for number,e in enumerate(scenes,1):
            if e['contract']!=contract:channels={n:F.Channel() for n in (5,15,30)};contract=e['contract']
            data,input_quality=I.load(e);current,qa=F.features(data,e,channels)
            for r in current:r['signals']={f:F.direction(r,f) for f in ('T','R','M')}
            rows.extend(current);quality.append({**qa,'input':input_quality})
            if number%10==0:print(json.dumps({'純生成':product,'場':number,'q0累計':len(rows)},ensure_ascii=False),flush=True)
        target=HERE/'純特徴'/(product+'.json.gz')
        save(target,{'product':product,'rows':rows,'quality':quality,'quantity_used':False,'condition':I.ref(TRIAL/'条件.json')})
        generated.append(I.ref(target));bench.append({'product':product,'seconds':time.perf_counter()-begin,'q0':len(rows),'gzip_bytes':target.stat().st_size})
    save(HERE/'純入口の封印.json',{'金融前':True,'条件':I.ref(TRIAL/'条件.json'),'pure':generated})
    (HERE/'純生成実測.json').write_text(json.dumps(bench,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(bench,ensure_ascii=False),flush=True)


def finance(entries):
    """
    機能: 固定された2商品×3家族×3幅を、同じ単一保有口座で再生する。
    引数: entries(dict)は固定入力。
    返り値: None。取得・全場・未参加・未知を保存する。
    """
    freeze(entries);seal=read(HERE/'純入口の封印.json')
    assert seal['金融前'] and seal['条件']==I.ref(TRIAL/'条件.json')
    assert all(I.ref(ROOT/r['path'])==r for r in seal['pure'])
    marker=HERE/'金融開始前固定.json';assert not marker.exists()
    save(marker,{'source':read(TRIAL/'条件.json')['source'],'pure':seal['pure']})
    spec=importlib.util.spec_from_file_location('stability187',ROOT/'work/183損失安定性/安定性183.py')
    S=importlib.util.module_from_spec(spec);spec.loader.exec_module(S)
    metrics=[];summary=[]
    for product,scenes in entries.items():
        by_scene=defaultdict(list)
        for r in read(HERE/'純特徴'/(product+'.json.gz'))['rows']:by_scene[r['session']].append(r)
        cells={(f,m):[] for f in ('T','R','M') for m in E.MULTIPLES};diagnostics={k:[] for k in cells}
        for number,e in enumerate(scenes,1):
            data,_=I.load(e);route=E.Route(data,e)
            for (family,multiple),selected in cells.items():
                busy=-math.inf;state=None;counts={'scene':e['session'],'signal':0,'held_blocked':0,'pending_blocked':0,'expired':0,'acquired':0}
                for row in by_scene[e['session']]:
                    side=row['signals'][family]
                    if not side:continue
                    counts['signal']+=1
                    if row['time']<=busy:counts['pending_blocked' if state=='pending' else 'held_blocked']+=1;continue
                    cell=route.cell(row,side,E.width(row,multiple))
                    if cell is None:
                        counts['expired']+=1;busy=min(row['time']+30,route.force);state='pending';continue
                    counts['acquired']+=1;selected.append(cell);busy=cell['exit_time'] if cell['known'] else route.end;state='holding'
                diagnostics[(family,multiple)].append(counts)
            if number%20==0:print(json.dumps({'金融':product,'場':number},ensure_ascii=False),flush=True)
        names=[r['session'] for r in scenes];periods={'全80':names[:80],'前48':names[:48],'後25':names[48:73],'追加7':names[73:80],'本日1':names[80:]}
        for (family,multiple),selected in cells.items():
            identifier=f'{product}187_{family}_ATR15x{multiple:g}_H60';pack=E.pack(identifier,scenes,selected)
            pack.update(product=product,family=family,multiple=multiple,diagnostics=diagnostics[(family,multiple)])
            save(HERE/'金融正本'/(identifier+'.json.gz'),pack);stat=S.evaluate_pack(pack,periods);metrics.append(stat)
            t=stat['groups']['ALL']['trades'];summary.append({'id':identifier,'取得':t['all_count'],'未知':t['unknown_count'],'利益':t['known_profit'],'損失':t['known_loss'],'既知収支':t['known_net']})
    save(HERE/'全18組安定性.json.gz',{'metrics':metrics});save(HERE/'全18組短表.json',summary)
    assert read(marker)['source']==read(TRIAL/'条件.json')['source']
    print(json.dumps(summary,ensure_ascii=False),flush=True)


def main():
    """
    機能: 純生成と金融を明示引数で分離する。
    引数: CLI --pure又は--financeは必須で排他的。
    返り値: None。
    """
    parser=argparse.ArgumentParser();group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--pure',action='store_true');group.add_argument('--finance',action='store_true');args=parser.parse_args()
    entries=I.sessions()
    if args.pure:pure(entries)
    else:finance(entries)


import math
if __name__=='__main__':main()
