"""187の固定18口座・純入力・Sourceと診断を恒久保存する。"""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import os
import re
import shutil
import zipfile
import 入力187 as I
import 実行187 as R

HERE=Path(__file__).parent;TRIAL=R.TRIAL;INPUTS=I.ROOT/'inputs/00187_共通価格特徴'
ARTIFACTS=('純入口の封印.json','金融開始前固定.json','人工確認187.json','純生成実測.json',
    '全18組安定性.json.gz','全18組短表.json','形成可用性と有効足記憶の診断.json.gz',
    '共通尺度と局面構成の診断.json.gz','全18口座の独立確認.json')


def copy(source,target):
    """
    機能: 固定成果物を同体照合してから新規コピーする。
    引数: source/target(Path)。
    返り値: None。既存の異なる正本は上書きしない。
    """
    target.parent.mkdir(parents=True,exist_ok=True)
    if target.exists():assert source.read_bytes()==target.read_bytes(),target
    else:shutil.copyfile(source,target)


def table_copy():
    """
    機能: 汎用版8の全セルを保持して使用役割/尺度を今回の設定へ記録する。
    引数: なし。
    返り値: strは設定と結果文書。未使用と単独未検証を区別する。
    """
    source=I.ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md';text=source.read_text(encoding='utf-8')
    text=text.replace('全セルは未設定・未検証。','本試行で使わないセルは未使用、計算するが方向判断に参照しないものは算出のみ。指標単独の有効性は未検証。').replace('未設定・未検証','未使用')
    settings={
        'I01':{5:'G187/T：EMA8近傍−0.25〜1ATR5、EMA21傾き同側',15:'G187/T：EMA21傾き同側',30:'G187/T：EMA21傾き同側'},
        'I02':{5:'G187/T：Last−EMA8をATR5正規化'},
        'I03':{5:'G187/T,R：12/26/9、Hist増分同側非負、TはHist同側',15:'算出のみ',30:'算出のみ'},
        'I04':{5:'G187/T45〜75、R30〜60、14増分同側正',15:'算出のみ',30:'算出のみ'},
        'I05':{5:'G187/R：20本母σ、反対側0.5σ以上',15:'算出のみ',30:'算出のみ'},
        'I08':{5:'G187/T：DI差同側',15:'G187/T：DI差同側、R：ADX<25、M：25で切替',30:'G187/T：DI差同側'},
        'I09':{5:'G187：14、1分構造/気配/現値進行の尺度',15:'G187：14、IFD幅1.5/2.5/4倍を呼値切上げ',30:'算出・正値確認'},
        'C01':{5:'G187/T：MA近傍/動力再開',15:'G187/T：背景整合',30:'G187/T：背景整合'},
        'C02':{5:'G187/R：BB反対位置とRSI/MACD回復'},
        'C04':{5:'G187/T：方向',15:'G187/M：強弱切替、T方向',30:'G187/T：方向'},
        'C07':{5:'G187：動力/構造',15:'G187：背景/幅',30:'G187：背景'},
        'P01':{1:'G187：同側実体/進行正、R終値位置0.65以上'},
        'P05':{0:'G187：Lastと1分終値の差/ATR5、同側−0.25以上',1:'G187：直前終値比同側正'},
        'P06':{1:'G187/R：同側終値位置0.65以上'},
        'E01':{0:'G187：実BBO先着F/A/N/C、取得行含む',15:'G187：q0時ATR15固定幅'},
        'E02':{0:'G187：固定IFDのみ、追尾なし、SL+1秒/TTL30'}}
    col={0:2,1:3,3:4,5:5,15:6,30:7,60:8};lines=[]
    for line in text.splitlines():
        if line.startswith('| '):
            values=[v.strip() for v in line.strip('|').split('|')]
            if values[0] in settings:
                for scale,value in settings[values[0]].items():values[col[scale]]=value
                line='| '+' | '.join(values)+' |'
        lines.append(line)
    text='\n'.join(lines)
    def link(match):
        """
        機能: コピーされた元文書の相対リンクを正式試行からのパスへ直す。
        引数: match(re.Match)。
        返り値: strはリンク先を直したMarkdown。
        """
        target=match.group(2)
        if '://' in target or target.startswith('#'):return match.group(0)
        path=(source.parent/target).resolve();relative=os.path.relpath(path,TRIAL).replace('\\','/')
        return f'[{match.group(1)}]({relative})'
    text=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',link,text)
    return '# 187の設定と結果\n\n使用版は汎用表・版8、設定IDはG187、複合評価はT/R/M×ATR15倍率1.5/2.5/4×NK225/TOPIXの18組。数量は未使用であり、出来高0として補完しない。\n\n結果は[全18組短表](全18組短表.json)と[README](README.md)。18組とも両中央値下限黒字を満たさず、安定採用しない。EMA等は有効足順更新で、欠測後の実時間記憶の伸長を別診断する。\n\n'+text+'\n'


def main():
    """
    機能: 正式成果物・索引・小さなSourceアーカイブを作る。
    引数: なし。
    返り値: None。原板の複製は行わない。
    """
    spec=R.read(TRIAL/'条件.json');assert all(I.ref(I.ROOT/r['path'])==r for r in spec['source'])
    INPUTS.mkdir(parents=True,exist_ok=True)
    for p in ('NK225','TOPIX'):copy(HERE/'純特徴'/(p+'.json.gz'),INPUTS/(p+'.json.gz'))
    R.save(INPUTS/'入力台帳.json',{'trial':187,'condition':I.ref(TRIAL/'条件.json'),'quantity_used':False,
        'generated':[I.ref(INPUTS/(p+'.json.gz')) for p in ('NK225','TOPIX')],
        'origin':'正式恒久48byte価格索引/TOPIX8列から価格だけ使用。入力の全パス/指紋/時計と仕様は条件.json。',
        'schema':'product/rows/quality/quantity_used/condition。rowsは公開済み1分のq0、5/15/30分指標、T/R/M信号。金融なし。'})
    (INPUTS/'README.md').write_text('# 187の共通価格特徴\n\n[試行187](../../study/00187_両指数を同じ価格特徴とIFDで比較する/README.md)の純特徴を一度だけ恒久保存する。NK225 25,881 q0、TOPIX 31,818 q0。数量は未使用で、未来の金融可否による出生除外も行わない。\n\n[入力台帳](入力台帳.json)にサイズとSHA、由来を保存。各gzip JSONのrowsにはsession/time/line/minute/bar_start/bar_end/window_end、価格、m5/m15/m30、signalsを含む。CurrentPriceTimeであり受信時刻ではない。量を重ねる188は同じq0を利用する。\n',encoding='utf-8')
    for name in ARTIFACTS:copy(HERE/name,TRIAL/name)
    for path in (HERE/'金融正本').glob('*.json.gz'):copy(path,TRIAL/'金融正本'/path.name)
    (TRIAL/'設定と結果.md').write_text(table_copy(),encoding='utf-8')
    sources=[HERE/n for n in R.SOURCES]+[HERE/'共通条件の差を診断する.py',HERE/'固定口座を独立検査する.py',HERE/'正式保存する.py',
        I.ROOT/'work/183損失安定性/安定性183.py',I.ROOT/'work/183損失安定性/新候補の集計を独立検査する.py']
    archive=TRIAL/'Source.zip'
    if not archive.exists():
        with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for path in sources:z.writestr(path.relative_to(I.ROOT).as_posix(),path.read_bytes())
    with zipfile.ZipFile(archive) as z:
        assert all(z.read(p.relative_to(I.ROOT).as_posix())==p.read_bytes() for p in sources)
    R.save(TRIAL/'Sourceと依存.json',{'archive':I.ref(archive),'members':[I.ref(p) for p in sources],
        'runtime':{'python':__import__('sys').version,'numpy':importlib.metadata.version('numpy'),'tzdata':importlib.metadata.version('tzdata')},
        'new_finance_before_seal':spec['source'],'補足':'診断/監査/正式化Sourceは金融後の読み取り用。金融前Sourceと混同しない。'})
    metrics=R.read(HERE/'全18組安定性.json.gz')['metrics'];lines=[]
    for m in metrics:
        a=m['groups']['ALL'];t=a['trades'];s=a['sessions'];h=a['holding'];ident=m['id'].replace('187_',' ').replace('_H60','').replace('_ATR15x',' ×')
        lines.append(f"| {ident} | {t['all_count']} | {t['unknown_count']} | {s['participating_count']}/81 | {h['held_lower_ratio']:.2%} | {t['known_profit']:,.1f} | {t['known_loss']:,.1f} | {t['known_net']:,.1f} | {t['net_median']['lower']:,.1f} | {s['net_median']['lower']:,.1f} |")
    header='''# 両指数を同じ価格特徴と単純IFDで比較する

18口座の共通対照を検証した。**この条件群は採用しない。18組とも建玉ごと・全セッションの中央値下限黒字を同時に満たさない。** TOPIXのT×4だけ既知合計が黒字だが、安定した入口の達成ではない。旧183/184の指数間成績差は、元の足・特徴・約定代用の違いを含むため市場固有の差と断定しない。本試行も、同じ式でなお残る観測可用性・指標の実時間記憶・費用/Rを可視化する対照である。

## 仮説と固定仕様

2026-11-17。81場（Day41/Night40、全て既使用）。Tは三足EMA/DI整合とMA近傍の動力再開、Rは低ADX・BB反対側位置・RSI/MACD増分・1分構造回復、MはADX15の25を境にT/Rを切り替える。買売は符号鏡像。Tは固定水準で押戻しを持続受容する状態機械ではない。条件を増やす前に、同じ無次元複合条件のどの部分が指数間で異なるのかを検証する心理仮説であり、利益を保証する説明ではない。

原観測から1/5/15/30分OHLCを直接形成。足始め・終端公表30秒、内部観測gap300秒以内の有効足を採用する。1分足が公表された原行で判断し、量を出生条件にしない。EMA等は有効足順で更新するため、欠測を飛ばした後の記憶時間は伸びる。同限月では完成指標を継承し、未完成足/1分直前3本は場越ししない。初期履歴不足や途中不足の場も分母へ残す。受信時計は存在せず、CurrentPriceTimeと原行順のモデルである。

IFD幅はq0時ATR15×1.5/2.5/4をmini呼値へ切上げ。H60、買売合計1保有・予約中も追加禁止。q0+1秒以降30秒内の最初正常ラージBBOで買Ask/売Bid。TPは返済側接触時の事前指値価格、SL/期限は+1秒以後30秒内の反対BBO。取得行のspread損切接触も含む。正常BBO300秒超空白や返済TTL不足は金融未知として場末まで枠を空けない。将来欠測を入口選択へ戻さない。

Day15:29/Night05:44に全決済を要求し、遅くとも15:30/05:45までを分母とする。開始一律待機はない。今回は追尾や技術による途中返済を足していない。

| 商品換算 | 1ptの金額 | 片道手数料 | 片道追加滑り | 往復費用 | 幅の丸め |
| --- | ---: | ---: | ---: | ---: | ---: |
| 日経225mini 1枚 | 100円 | 38.5円 | 5pt | 1,077円 | 5pt |
| miniTOPIX 1枚 | 1,000円 | 41.8円 | 0.25pt | 583.6円 | 0.25pt |

BBO差は取得/返済価格に入り、表の追加滑りはそれと別の費用仮定。ラージBBOをminiへ代用しており、mini自身の板流動性や実注文の待ち行列は再現していない。商品間の金額の大小で優劣を付けない。

## 全81場の結果

金額は商品ごとのmini 1枚・費用後円。利益/損失は**既知決済だけの正負別合計**。未知を0円として全件確定収支とはしない。中央値は未知の損益を未限定とした下限で、0取引場も含む。保有率は確定時間下限。異なる手法を混ぜたCSVは作っていない。

| 条件 | 取得 | 未知 | 取得場 | 保有下限 | 既知利益 | 既知損失 | 既知収支 | 建玉中央値下限 | 場中央値下限 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
'''
    footer='''

幅4倍のTではNKは4F/0A/99未到達/8観測不足、TOPIXは3F/0A/120未到達/7観測不足。少数の先着だけなら高率になるが、H60の期限決済が主体であり、高確率入口の達成とはしない。NKのT×4は平均既知net_Rが+0.00761でも金額合計は−27,931円となり、可変幅での等R平均と実額の重みの違いも残る。

## 差の所在

- 共通の対象時間2,832,300秒に対して、純q0公開後の判断分内可用区間はNK1,443,912秒（50.98%）、TOPIX1,787,804秒（63.12%）、両指数共通1,287,272秒（45.45%）。共通区間の割合はDay73.15%、PRE23.20%、POST36.35%。これは連続市場の観測可能時間全体ではなく、公開済みq0から次の分枠末までの保守的な区間である。共通区間で原口座を選別して成績を作り直していない。
- 近傍15分21有効足の取引時間跨度中央値はNK21,600秒/名目18,900秒＝1.143倍、TOPIX19,800秒＝1.048倍。5分35本/30分21本も診断に保存。EMAの全記憶がこの本数で切れるという意味ではない。同じ係数でも実時間記憶と局面出現数が異なり得る。
- T×1.5のIFD幅中央値はNK270pt/TOPIX11.25pt。往復費用/R中央値はNK0.03989/TOPIX0.05188、取得spread/R中央値はNK0.03922/TOPIX0.04762。取引価格へのspreadと追加費用を別記した。
- 同じ帯・ADX階級・実方向三足整合へ取得済み既知取引を分けると、T×1.5の平均net_R差（NK−TOPIX）は−0.02449。その算術分解は同局面内−0.07110、群構成差+0.04661で相殺される。この分解は各群の既知取引に条件付けた記述であり、未取得・未知を補完した市場固有の因果差ではない。全群の支持件数と共通支持率を正本へ保存した。

数量/出来高/相対量は今回未使用。欠測を量0としたわけでもない。価格だけのT/R/Mが両指数で安定しないという結果から、同じ価格母集団へ量観測可用性と量の水準条件を別々に重ねる[188](../00188_両指数の共通入口に数量の持続を重ねる/README.md)へ進む。187の金融後に量条件を追記しない。

## 正本・再現

- [固定条件](条件.json)、[設定と結果・版8](設定と結果.md)、[全18組安定性](全18組安定性.json.gz)、[短表](全18組短表.json)。安定性には前48/後25/追加7/本日1/全80とDAY/NIGHT/PRE/POSTを保存。今回は前48の選択候補を作っていない。
- [形成・可用性・指標記憶診断](形成可用性と有効足記憶の診断.json.gz)、[共通尺度・局面構成診断](共通尺度と局面構成の診断.json.gz)。1分品質不足/初期履歴不足/途中背景不足、場別形成率、幅/ATR比/costR/spreadR、共通q0内外と群構成を含む。
- [純特徴の恒久入力](../../inputs/00187_共通価格特徴/README.md)。原板はコピーせず既存恒久索引を参照する。純生成実測はNK6.12秒/TOPIX3.45秒、18口座の金融は約4秒だった。
- [Sourceと依存版](Sourceと依存.json)、[Source.zip](Source.zip)、[独立監査](全18口座の独立確認.json)。18口座3,320取得の金融86,320属性/集計50,976属性が一致。人工検査では価格未来改変前同体、売買鏡像、取得行spread損切、返済未知を確認。価格読取だけ共有し、金融は別の線形接触走査で検査した。
- [再現する.py](再現する.py)を、NumPy/tzdataの記載版があるPythonで `--root 空の作業先` を付けて実行する。旧workを参照せず、正式Sourceを展開し恒久価格入力を参照して純生成→18金融→診断→監査を再生する。[再現確認](再現確認.json)と[保存索引](保存索引.json)を参照。

全81場が既使用であり、これは未見性能ではない。複数候補の全期成績を見て安定採用したものでもない。正常flagは保存済品質を尊重し、TOPIX validの両数量条件を無視して約定可能へ昇格させない一方、NK48byte索引に数量列はなく品質条件の元情報まで同一ではない。
'''
    (TRIAL/'README.md').write_text(header+'\n'.join(lines)+footer,encoding='utf-8')
    print({'正式金融':len(list((TRIAL/'金融正本').glob('*.gz'))),'純入力bytes':sum((INPUTS/(p+'.json.gz')).stat().st_size for p in ('NK225','TOPIX'))},flush=True)


if __name__=='__main__':main()
