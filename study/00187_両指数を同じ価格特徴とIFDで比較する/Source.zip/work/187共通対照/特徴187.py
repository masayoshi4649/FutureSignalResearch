"""価格だけの同一直接足と、無次元の複合判断を両商品へ適用する。"""
from collections import deque,Counter
import math
import numpy as np
import 入力187 as I

WARM={5:35,15:21,30:21}


class Channel:
    """両商品で同じ初値・係数・準備本数の逐次指標。"""
    def __init__(self):
        """
        機能: 同限月で持ち越す確定足状態を初期化する。
        引数: なし。
        返り値: None。
        """
        self.n=0;self.ema={};self.signal=None;self.atr=None;self.up=self.down=self.pdm=self.mdm=self.adx=0.
        self.previous=None;self.last=None;self.closes=deque(maxlen=20)

    def update(self,b):
        """
        機能: 当時公開された完成足だけでEMA/RSI/MACD/ATR/DI/ADX/BBを更新する。
        引数: b(dict)は観測OHLCと公表時計。
        返り値: dictは価格尺度と無次元指標。EMA初値は最初終値、Wilder初値は最初TR/0増分。
        """
        c=b['close'];old21=self.ema.get(21,c);previous=self.previous;prior=self.last
        for n in (8,12,21,26):self.ema[n]=c if n not in self.ema else self.ema[n]+2/(n+1)*(c-self.ema[n])
        tr=b['high']-b['low'] if previous is None else max(b['high']-b['low'],abs(b['high']-previous['close']),abs(b['low']-previous['close']))
        self.atr=tr if self.atr is None else self.atr+(tr-self.atr)/14
        change=0 if previous is None else c-previous['close']
        upmove=0 if previous is None else b['high']-previous['high'];downmove=0 if previous is None else previous['low']-b['low']
        for key,value in (('up',max(change,0)),('down',max(-change,0)),('pdm',upmove if upmove>downmove and upmove>0 else 0),('mdm',downmove if downmove>upmove and downmove>0 else 0)):
            setattr(self,key,getattr(self,key)+(value-getattr(self,key))/14)
        plus=100*self.pdm/self.atr if self.atr else 0.;minus=100*self.mdm/self.atr if self.atr else 0.
        dx=100*abs(plus-minus)/(plus+minus) if plus+minus else 0.;self.adx+=(dx-self.adx)/14
        rsi=100*self.up/(self.up+self.down) if self.up+self.down else 50.
        macd=self.ema[12]-self.ema[26];self.signal=macd if self.signal is None else self.signal+2/10*(macd-self.signal)
        hist=macd-self.signal;self.closes.append(c);self.n+=1
        mean=sum(self.closes)/len(self.closes);sigma=(sum((x-mean)**2 for x in self.closes)/len(self.closes))**.5
        out={'count':self.n,'published':b['published'],'close':c,'ema8':self.ema[8],'ema21':self.ema[21],
            'slope':(self.ema[21]-old21)/self.atr if self.atr else 0.,'atr':self.atr,'rsi':rsi,
            'rsi_delta':rsi-prior['rsi'] if prior else 0.,'di':plus-minus,'adx':self.adx,
            'adx_delta':self.adx-prior['adx'] if prior else 0.,'hist':hist,
            'hist_delta':hist-prior['hist'] if prior else 0.,'bb_mean':mean,'bb_sigma':sigma}
        self.previous=b;self.last=out
        return out


def bars(data,scene,size):
    """
    機能: 原行の価格だけから各幅の完成OHLCと公表原行を直接作る。
    引数: data(dict[str,np.ndarray]),scene(str),size(int)は分幅。
    返り値: list[dict]は可否も残した全観測足。公表後の価格をOHLCへ入れない。
    """
    start,end,force,_=I.bounds(scene);t=data['time'];length=size*60
    if not len(t):return []
    keys=((t-start)//length).astype(np.int64);starts=np.r_[0,np.flatnonzero(np.diff(keys))+1];ends=np.r_[starts[1:],len(t)]
    result=[]
    for a,b in zip(starts,ends):
        if b==len(t):continue
        last=data['last'][a:b];valid=np.isfinite(last)&(last>0);indices=np.flatnonzero(valid)+a
        begin=start+int(keys[a])*length;finish=begin+length;published=float(t[b]);reasons=[]
        if not len(indices):reasons.append('価格不足')
        else:
            if t[indices[0]]-begin>30:reasons.append('足始め30秒超')
            if max(np.diff(np.r_[t[indices],published]),default=0)>300:reasons.append('価格300秒超空白')
        if published-finish>30:reasons.append('公開30秒超')
        row={'index':int(keys[a]),'start':begin,'end':finish,'published':published,'pub_index':int(b),
            'usable':not reasons,'reasons':reasons}
        if len(indices):
            values=data['last'][indices];row.update(open=float(values[0]),high=float(values.max()),low=float(values.min()),close=float(values[-1]))
        result.append(row)
    return result


def features(data,entry,channels):
    """
    機能: 公表原行順に三足を更新し、数量と未来金融を使わず純q0を作る。
    引数: data(dict),entry(dict),channels(dict[int,Channel])は同限月履歴。
    返り値: tuple[list[dict],dict]は純q0と初期不足/途中gap/公表品質の診断。
    """
    scene=entry['session'];start,end,force,_=I.bounds(scene);series={n:bars(data,scene,n) for n in (1,5,15,30)}
    pointers={n:0 for n in channels};prior=deque(maxlen=3);out=[];counts=Counter()
    for b in series[1]:
        at=b['pub_index'];t=b['published'];counts['観測1分足']+=1
        for size,channel in channels.items():
            while pointers[size]<len(series[size]) and series[size][pointers[size]]['pub_index']<=at:
                value=series[size][pointers[size]];pointers[size]+=1
                counts[str(size)+'分採用' if value['usable'] else str(size)+'分不採用']+=1
                if value['usable']:channel.update(value)
        if not b['usable']:
            counts['1分品質不足']+=1
            for reason in b['reasons']:counts['1分:'+reason]+=1
            prior.clear();continue
        if prior and b['index']!=prior[-1]['index']+1:prior.clear()
        ready=all(c.last is not None and c.n>=WARM[n] for n,c in channels.items())
        fresh=ready and all(t-c.last['published']<=n*60+30 for n,c in channels.items())
        if not ready:counts['初期履歴不足']+=1
        elif not fresh:counts['途中背景足不足']+=1
        elif len(prior)!=3:counts['直前3分不足']+=1
        elif not data['normal'][at]:counts['q0気配不正常']+=1
        elif not math.isfinite(data['last'][at]) or data['last'][at]<=0:counts['q0現値不明']+=1
        elif t>=force:counts['新規停止後']+=1
        else:
            c5,c15,c30=(channels[n].last for n in (5,15,30));atr=c5['atr'];r=b['high']-b['low']
            if atr>0 and c15['atr']>0 and c30['atr']>0:
                last=float(data['last'][at]);bid=float(data['bid'][at]);ask=float(data['ask'][at])
                row={'product':entry['product'],'session':scene,'contract':entry['contract'],'time':t,'line':int(data['line'][at]),
                    'index':at,'minute':b['index'],'bar_start':b['start'],'bar_end':b['end'],
                    'phase':I.band(scene,t),'last':last,'bid':bid,'ask':ask,
                    'window_end':min(force,start+(b['index']+2)*60),'close':b['close'],'open':b['open'],
                    'body':(b['close']-b['open'])/atr,'progress':(b['close']-prior[-1]['close'])/atr,
                    'position':(b['close']-b['low'])/r if r else .5,'range':r/atr,'live':(last-b['close'])/atr,
                    'prior_close':prior[-1]['close'],'prior_high':max(p['high'] for p in prior),'prior_low':min(p['low'] for p in prior),
                    'atr':atr,'spread_atr':(ask-bid)/atr,'atr_price':c15['atr']/last,'atr5_atr15':atr/c15['atr'],
                    'm5':dict(c5),'m15':dict(c15),'m30':dict(c30)}
                out.append(row)
            else:counts['ATR非正']+=1
        prior.append(b)
    for size in channels:
        while pointers[size]<len(series[size]):
            b=series[size][pointers[size]];pointers[size]+=1
            if b['usable']:channels[size].update(b)
    counts['q0']=len(out)
    return out,{'session':scene,'counts':dict(counts),'first_q0':out[0]['time'] if out else None,
        'last_q0':out[-1]['time'] if out else None,'available_seconds':sum(max(0,r['window_end']-r['time']) for r in out),
        'eligible_seconds':end-start,'quantity_used':False,'end_counts':{str(n):c.n for n,c in channels.items()}}


def direction(row,family):
    """
    機能: 同じ無次元の複合条件で順行・反転・局面切替を評価する。
    引数: row(dict)は純q0、family(str)はT/R/M。
    返り値: intは買1/売-1/待機0。数量は参照しない。
    """
    if row['spread_atr']>.35 or row['range']>2.5 or abs(row['live'])>1:return 0
    accepted=[]
    for side in (1,-1):
        c5,c15,c30=(row['m'+str(n)] for n in (5,15,30));atr=row['atr']
        rsi=c5['rsi'] if side==1 else 100-c5['rsi'];dist=side*(row['last']-c5['ema8'])/atr
        motion=side*row['body']>0 and side*row['progress']>0 and side*row['live']>=-.25
        recovery=side*c5['hist_delta']>=0 and side*c5['rsi_delta']>0
        trend=all(side*c['slope']>0 and side*c['di']>0 for c in (c5,c15,c30))
        # ----------------------------------------
        # 同時点の価格位置・複数足背景・動力の複合。移動する境界の交差を固定回復と呼ばない。
        t=trend and motion and recovery and 45<=rsi<=75 and -.25<=dist<=1.0 and side*c5['hist']>=0
        z=side*(row['last']-c5['bb_mean'])/c5['bb_sigma'] if c5['bb_sigma']>0 else math.inf
        position=row['position'] if side==1 else 1-row['position']
        r=c15['adx']<25 and z<=-.5 and motion and recovery and position>=.65 and 30<=rsi<=60
        signal=t if family=='T' else r if family=='R' else t if c15['adx']>=25 else r
        if signal:accepted.append(side)
    return accepted[0] if len(accepted)==1 else 0
