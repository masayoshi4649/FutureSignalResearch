"""共通価格核の未来不変・符号反転と、IFDの時計/保有を検査する。"""
from pathlib import Path
import json,math
import numpy as np
import 入力187 as I
import 特徴187 as F
import 共通IFD187 as E


def data(times,price,spread=2.):
    """
    機能: 時計・現値・BBOだけの人工配列を作る。
    引数: times/price(np.ndarray),spread(float)。
    返り値: dict[str,np.ndarray]は6列。数量を作らない。
    """
    return {'time':np.asarray(times,float),'line':np.arange(1,len(times)+1,dtype=np.int64),
        'last':np.asarray(price,float),'bid':np.asarray(price,float)-spread/2,
        'ask':np.asarray(price,float)+spread/2,'normal':np.ones(len(times),bool)}


def q0(scene,time):
    """
    機能: 金融時計検査用の、将来価格を含まないq0を作る。
    引数: scene(str),time(float)。
    返り値: dictは最小価格特徴。
    """
    c={'slope':1.,'di':1.,'adx':30.,'atr':10.}
    return {'session':scene,'product':'NK225','time':time,'line':1,'phase':1,'m5':dict(c),'m15':dict(c),'m30':dict(c),
        'bid':999.,'ask':1001.,'atr_price':.01,'atr5_atr15':.5}


def main():
    """
    機能: 金融前に純因果・原行/同時刻・鏡像・取得行SL・TTL未知を検査する。
    引数: なし。
    返り値: None。純人工だけの検査票を専有workへ保存する。
    """
    scene='2026-09-21_Night';start,end,_,_=I.bounds(scene);entry={'product':'NK225','session':scene,'contract':'test'}
    times=np.arange(start,end,15.);price=10000+np.arange(len(times))*.1+5*np.sin(np.arange(len(times))*.05)
    original=data(times,price)
    first,qa=F.features(original,entry,{n:F.Channel() for n in (5,15,30)})
    assert first and all(r['time']>=r['bar_end'] and r['bar_start']<r['bar_end'] for r in first)
    cutoff=times[-300];changed={k:v.copy() for k,v in original.items()}
    for key in ('last','bid','ask'):changed[key][times>=cutoff]+=10000
    second,_=F.features(changed,entry,{n:F.Channel() for n in (5,15,30)})
    assert [r for r in first if r['time']<cutoff]==[r for r in second if r['time']<cutoff]
    mirrored={**original,'last':30000-original['last'],'bid':30000-original['ask'],'ask':30000-original['bid']}
    reverse,_=F.features(mirrored,entry,{n:F.Channel() for n in (5,15,30)})
    assert len(first)==len(reverse)
    directions=0
    for a,b in zip(first,reverse):
        for family in ('T','R','M'):
            assert F.direction(a,family)==-F.direction(b,family);directions+=1
        for n in (5,15,30):
            ca,cb=a['m'+str(n)],b['m'+str(n)]
            assert math.isclose(ca['atr'],cb['atr'],abs_tol=1e-8)
            assert math.isclose(ca['rsi'],100-cb['rsi'],abs_tol=1e-7)
    # ----------------------------------------
    t=start+np.arange(0,41);p=np.full(len(t),1000.);p[3:]=1020.
    row=q0(scene,start);route=E.Route(data(t,p),entry);hit=route.cell(row,1,10.)
    assert hit['entry_time']==start+1 and hit['entry_price']==1001 and hit['exit_price']==1011 and hit['exit_time']==start+3 and hit['label']=='F'
    immediate=E.Route(data(t,np.full(len(t),1000.),spread=20.),entry).cell(row,1,10.)
    assert immediate['label']=='A' and immediate['exit_time']==start+2 and immediate['gross_pt']==-20.
    missing=E.Route(data(start+np.arange(0,3601,30),np.full(121,1000.)),entry).cell(row,1,100.)
    assert missing['known'] is False and missing['exit_time'] is None and missing['confirmed_until']<=start+3630
    gap=E.Route(data(start+np.array([0.,1.,2.,400.,401.]),np.array([1000.,1000.,1000.,1020.,1020.])),entry).cell(row,1,10.)
    assert not gap['known'] and gap['label']=='C' and gap['confirmed_until']==start+2
    financial=0;rng=np.random.default_rng(187)
    for _ in range(100):
        t=start+np.arange(200)*2.;p=1000+np.cumsum(rng.integers(-3,4,size=len(t)));src=data(t,p)
        mirror={**src,'last':3000-src['last'],'bid':3000-src['ask'],'ask':3000-src['bid']}
        for w in (5.,10.,20.):
            a=E.Route(src,entry).cell(row,1,w);b=E.Route(mirror,entry).cell(row,-1,w)
            for k in ('known','label','entry_time','exit_time','gross_pt','net','confirmed_until','fee_R','slip_R','net_R'):
                assert a[k]==b[k],(k,a[k],b[k]);financial+=1
    result={'成功':True,'金融未参照':True,'純q0':len(first),'未来変更前の同体q0':int(sum(r['time']<cutoff for r in first)),
        '方向鏡像':directions,'金融鏡像属性':financial,'取得行spread_SL':True,'TP指値水準':True,'TTL未知':True,'gap未知':True,
        '数量なし出生':True}
    (Path(__file__).parent/'人工確認187.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
