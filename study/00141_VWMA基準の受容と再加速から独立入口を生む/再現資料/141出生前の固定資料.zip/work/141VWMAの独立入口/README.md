# 141・VWMA20の独立入口生成器

2026-11-12。自然CSV/原板/出生/金融は未実行。RootのF0固定後だけ生成する。仕様の正本は [採用仕様](../141_VWMA独立入口の採用仕様.md)。旧118Bank・旧生成器は変更しない。

## 入力と時計

固定122入力（SHA `6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec`）の73場・12794公表と、別SHA固定CSV73参照を使う。背景の前史は118BankのStartSession/SeedFromPriorを同順で再現し、当場5/15/30を同Raw全配送後に判断する。CSVは価格時計に対するモデルEnd+60秒以降の最初の採用Rawへ配送する。実receivedAtの復元とはしない。

CSVのtimeは分開始。ザラバの正確60秒格子を全て作り、欠分は未知placeholderとして残す。未知値の内部0はknown=falseを伴い、売買値やVWMAの既知0に使わない。閉鎖足はEnd+60以前へ渡さず、EOFで架空の配送を追加しない。品質監査の最終mask・将来最長区間は使用しない。CSV全fileの構文/順序不正は入力生成失敗とする。

Rawは旧129 decoderのpackage行だけを変更して再用する。plain/gzipをmagicで切り替え、一走査の圧縮元bytes SHA、前後stat、全11品質、採用数、単一限月、全背景配送を照合する。元122 Raw参照はbytes省略を許し、0を事前サイズ既知とせず、実stat_before/stat_afterを保存する。原板/CSVを複写しない。

## 状態

VWMAはHLC3・直近20分の量加重。全20分の価格/量/closed既知を要求し、Σ量0は未知。5分差は正確に300秒離れた窓を使う。場・限月でresetし、古い既知窓へのfallbackはしない。Root実装のtracker.goは本生成器と同packageの独立純部品である。

a1の直前窓とATRを固定→直後a2→後の帯内再接近j→直後bの確定値/同足量→現在の正常BBO2行かつ1秒維持→出生後別Raw1秒の最初正常BBO取得。売買は符号反転。帯/ATR/K/I/capは途中で緩めない。最新W/背景unknown・否定はpendingにも取消を続ける。LastはI無効化/K/cap、リスク距離は買Ask/売Bidで判定する。最初の正常気配がgeometry外なら取消し、後の価格を選ばない。

既知0量はW窓に含める。再接近待ちの中間0量は待機、a1/a2/j/bには不使用。必要足未知は取消。next足失敗をその場でa1へ再利用しない。出生後同方向600秒cooldownで、場1回capはない。

全出生要求をeventsへ、出生前取消を含む全遷移をlifecycleへ保存する。取得直前のAssessment（masks/refs/最新W/指標値）と実評価Quoteを残す。Event.Refsにも取得時参照を結合する。j前30本の高安等は診断専用で、不足を無限余地へ補わない。

## API・実行

Go 1.24.2以上。moduleは`github.com/masayoshi4649/SessionTradeExecuter/vwmaentry141`。ローカル依存は固定118Bankだけ。

```powershell
go test -count=1 -v ./...
go vet ./...
go build -o V0独立生成.exe ./cmd/run
```

CLIは`--input --sha256 --csv-manifest --csv-manifest-sha256 --output --workers --execute-after-f0`。出力は未作成先のみ。RootのF0運転部から実行し、Source成功後に別橋渡し・金融前F1・133正逆観測へ接続する。生成器自身は先着・損益を計算しない。

`Result.scenes`は入力順を保持し、0出生場も残す。各場は`success/session/contract/raw/counts/expected_quality/stat_before/stat_after/actual_sha256/events/lifecycle/stats/stage_counts/csv_stats`を出力する。取得Quoteは`entryQuote`、出生は`birth`。全格子のVWMA値を別ファイルへ重複転記しない。

## 人工確認の範囲

量加重/正確窓/5分差/未知窓と20分後回復/未来配送拒否、CSV欠分・既知0と未知0・構造拒否、plain/gzip同品質とEOF未配送、買売鏡像、維持と取得の各別行1秒、最初正常cap取消、pending不正常BBOのLast I取消、未知取消、0量中間待機とa2取消、期限等号を確認する。自然件数・全場参加・70%・頻度は未確認。
