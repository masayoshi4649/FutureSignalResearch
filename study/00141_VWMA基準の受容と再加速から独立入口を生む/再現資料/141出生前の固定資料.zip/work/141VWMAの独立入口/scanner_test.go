package vwmaentry141

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// fixtureCSV141 は人工CSVだけを一時folderへ作ります。
//
// 引数: t(*testing.T)、body(string)。返り値: FileRefです。
func fixtureCSV141(t *testing.T, body string) FileRef {
	t.Helper()
	path := filepath.Join(t.TempDir(), "candle_1min.csv")
	b := []byte(body)
	if e := os.WriteFile(path, b, 0600); e != nil {
		t.Fatal(e)
	}
	return FileRef{Path: path, SHA256: digest(b), Bytes: int64(len(b))}
}

// Test141CSV未知格子と配送 は欠分を圧縮せず、利用開始より早く配送しないことを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test141CSV未知格子と配送(t *testing.T) {
	header := "time,open,high,low,close,volume,volume_complete,closed\n"
	ref := fixtureCSV141(t, header+"1970-01-01T00:00:00Z,100,101,99,100,0,true,true\n1970-01-01T00:02:00Z,100,101,99,100,0,false,true\n")
	scene := Scene{Session: "人工_Day", Contract: "人工", Start: 0, End: 600, CSV: ref}
	minutes, stats, e := loadCSV(scene)
	if e != nil {
		t.Fatal(e)
	}
	if len(minutes) != 5 || stats.Missing != 3 || !minutes[0].VolumeKnown || minutes[0].Volume != 0 || !minutes[1].Missing || minutes[2].VolumeKnown {
		t.Fatal(minutes, stats)
	}
	cursor := 0
	q := Quote{Time: 119, Index: 1, SourceLine: 2}
	if len(deliverMinutes(minutes, &cursor, q)) != 0 {
		t.Fatal("未来配送")
	}
	q.Time = 120
	if b := deliverMinutes(minutes, &cursor, q); len(b) != 1 || b[0].Stamp.Time != 120 {
		t.Fatal(b)
	}
	q.Time = 300
	if b := deliverMinutes(minutes, &cursor, q); len(b) != 3 || !b[0].Missing || b[1].VolumeKnown || !b[2].Missing {
		t.Fatal(b)
	}
}

// Test141CSV構造と固定SHA は構造エラーを0や整列で隠さないことを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test141CSV構造と固定SHA(t *testing.T) {
	for _, body := range []string{"bad\n", "time,open,high,low,close,volume,volume_complete,closed\n1970-01-01T00:00:00Z,1,1,1,1,1,true,true\n1970-01-01T00:00:00Z,1,1,1,1,1,true,true\n"} {
		ref := fixtureCSV141(t, body)
		if _, _, e := loadCSV(Scene{Session: "s", Contract: "c", End: 600, CSV: ref}); e == nil {
			t.Fatal("構造不正を許可")
		}
	}
	if _, e := Load("存在しない", "不正", "存在しない", "不正"); e == nil {
		t.Fatal("I/O前SHA拒否なし")
	}
}

// artificialScene141 は同じ原行のplain/gzip人工参照と全品質を作ります。
//
// 引数: t(*testing.T)、compressed(bool)。返り値: Sceneです。
func artificialScene141(t *testing.T, compressed bool) Scene {
	t.Helper()
	var body bytes.Buffer
	for i, at := range []int64{120, 180, 181} {
		row := map[string]any{"Symbol": "人工", "CurrentPriceTime": time.Unix(at, 0).UTC().Format(time.RFC3339Nano), "CurrentPrice": 100.}
		for j := 1; j <= 10; j++ {
			row[fmt.Sprintf("Buy%d", j)] = map[string]float64{"Price": 99, "Qty": 1}
			row[fmt.Sprintf("Sell%d", j)] = map[string]float64{"Price": 101, "Qty": 1}
		}
		if i == 1 {
			row["Buy1"] = map[string]float64{"Price": 0, "Qty": 0}
		}
		b, e := json.Marshal(row)
		if e != nil {
			t.Fatal(e)
		}
		body.Write(b)
		body.WriteByte('\n')
	}
	raw := body.Bytes()
	if compressed {
		var zipped bytes.Buffer
		z := gzip.NewWriter(&zipped)
		_, _ = z.Write(raw)
		_ = z.Close()
		raw = zipped.Bytes()
	}
	path := filepath.Join(t.TempDir(), "raw.jsonl")
	if e := os.WriteFile(path, raw, 0600); e != nil {
		t.Fatal(e)
	}
	csv := fixtureCSV141(t, "time,open,high,low,close,volume,volume_complete,closed\n1970-01-01T00:00:00Z,100,101,99,100,1,true,true\n1970-01-01T00:01:00Z,100,101,99,100,1,true,true\n")
	return Scene{Session: "人工_Day", Contract: "人工", Start: 0, End: 10020, ForceClose: 9000, Raw: FileRef{Path: path, SHA256: digest(raw)}, CSV: csv, ExpectedAccepted: 3, ExpectedQuality: &Counts{Lines: 3, Accepted: 3, Delivered: 3, BadBBO: 1}}
}

// Test141原板一走査と全品質 は同一原行plain/gzipとEOF非生成を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test141原板一走査と全品質(t *testing.T) {
	for _, compressed := range []bool{false, true} {
		s := artificialScene141(t, compressed)
		r, e := Generate([]Scene{s}, 1, false)
		if e != nil {
			t.Fatal(e)
		}
		v := r.Scenes[0]
		if !r.Success || v.RawPasses != 1 || v.Counts != *s.ExpectedQuality || v.CSVStats.Delivered != 2 || v.CSVStats.EOFUndelivered == 0 || len(v.Events) != 0 {
			t.Fatalf("%+v", v)
		}
		s.ExpectedQuality.BadBBO = 0
		if _, e = Generate([]Scene{s}, 1, false); e == nil {
			t.Fatal("品質差を許可")
		}
	}
}
