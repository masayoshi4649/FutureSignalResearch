package main

import (
	"encoding/json"
	"flag"
	"fmt"
	v0 "github.com/masayoshi4649/SessionTradeExecuter/vwmaentry141"
	"os"
)

// main は明示F0後フラグと指紋がある時だけ自然Sourceを生成します。
//
// 引数: CLIフラグ。返り値: なし。不一致は終了コード1で中断します。
func main() {
	input := flag.String("input", "", "固定122入力")
	sha := flag.String("sha256", "", "固定122SHA")
	manifest := flag.String("csv-manifest", "", "CSV73参照")
	manifestSHA := flag.String("csv-manifest-sha256", "", "CSV参照SHA")
	output := flag.String("output", "", "未作成出力")
	workers := flag.Int("workers", 4, "並列1..16")
	execute := flag.Bool("execute-after-f0", false, "Root F0固定後だけ実行")
	flag.Parse()
	fail := func(e error) { fmt.Fprintln(os.Stderr, e); os.Exit(1) }
	if !*execute || *output == "" || *input == "" || *manifest == "" || flag.NArg() != 0 {
		fail(fmt.Errorf("F0後の明示実行/全CLI指定が必要"))
	}
	if _, e := os.Stat(*output); !os.IsNotExist(e) {
		fail(fmt.Errorf("未作成出力だけ許可"))
	}
	scenes, e := v0.Load(*input, *sha, *manifest, *manifestSHA)
	if e != nil {
		fail(e)
	}
	result, e := v0.Generate(scenes, *workers, true)
	if e != nil {
		fail(e)
	}
	result.CSVManifestSHA = *manifestSHA
	if _, e = v0.Load(*input, *sha, *manifest, *manifestSHA); e != nil {
		fail(fmt.Errorf("入力走査後:%w", e))
	}
	body, e := json.MarshalIndent(result, "", "  ")
	if e != nil {
		fail(e)
	}
	f, e := os.OpenFile(*output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		fail(e)
	}
	if _, e = f.Write(append(body, '\n')); e != nil {
		f.Close()
		fail(e)
	}
	if e = f.Close(); e != nil {
		fail(e)
	}
	fmt.Printf("141 Source成功 場=%d 出生=%d 取得=%d\n", len(result.Scenes), result.Summary["出生数"], result.Summary["取得数"])
}
