package vwmaentry141

import rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"

// FileRef は複写しない固定原本の参照です。
type FileRef struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
	Bytes  int64  `json:"bytes"`
}

// Minute は当時実配送された確定1分です。Missingは未知の格子を表します。
type Minute struct {
	ID          string      `json:"id"`
	Session     string      `json:"session"`
	Contract    string      `json:"contract"`
	Start       float64     `json:"start"`
	End         float64     `json:"end"`
	AvailableAt float64     `json:"available_at"`
	OHLC        rules.OHLC  `json:"ohlc"`
	Volume      float64     `json:"volume"`
	PriceKnown  bool        `json:"price_known"`
	VolumeKnown bool        `json:"volume_known"`
	Closed      bool        `json:"closed"`
	Missing     bool        `json:"missing"`
	Stamp       rules.Stamp `json:"stamp"`
	CSV         FileRef     `json:"csv"`
	CSVLine     int         `json:"csv_line"`
}

// WValue はEndが一致する20分窓と実配送参照を保存します。
type WValue struct {
	End   float64     `json:"end"`
	Known bool        `json:"known"`
	Value float64     `json:"value"`
	Refs  []rules.Ref `json:"refs"`
}

// Quote は固定Raw採用原行を保持します。受信時計を追加しません。
type Quote struct {
	Clock      string  `json:"clock"`
	Time       float64 `json:"time"`
	Index      int64   `json:"index"`
	SourceLine int64   `json:"source_line"`
	Last       float64 `json:"last"`
	Bid        float64 `json:"bid"`
	Ask        float64 `json:"ask"`
	QuoteOK    bool    `json:"quote_ok"`
}

// Counts は既存129/137と同じ全Rawの品質分母です。
type Counts struct {
	Lines           int64 `json:"lines"`
	ClockMissing    int64 `json:"clock_missing"`
	ClockInvalid    int64 `json:"clock_invalid"`
	Outside         int64 `json:"outside_session"`
	Backward        int64 `json:"backward_clock"`
	LastNonPositive int64 `json:"last_non_positive"`
	LastNonFinite   int64 `json:"last_non_finite"`
	BadBBO          int64 `json:"bad_bbo"`
	Accepted        int64 `json:"source_parser_accepted"`
	CutoffExcluded  int64 `json:"cutoff_excluded"`
	Delivered       int64 `json:"source_delivered"`
}

// Scene は固定122のmetadata/背景と、別固定CSV参照です。
type Scene struct {
	Session          string              `json:"session"`
	Contract         string              `json:"contract"`
	Start            float64             `json:"start"`
	End              float64             `json:"end"`
	ForceClose       float64             `json:"force_close"`
	Cutoff           float64             `json:"cutoff"`
	Raw              FileRef             `json:"raw"`
	ExpectedAccepted int64               `json:"expected_accepted"`
	ExpectedQuality  *Counts             `json:"expected_quality"`
	Publications     []rules.Publication `json:"publications"`
	CSV              FileRef             `json:"csv"`
}

// Trace は状態遷移の当時時計と足/指標参照を保存します。
type Trace struct {
	EpisodeID string         `json:"episode_id"`
	Side      int            `json:"side"`
	Stage     string         `json:"stage"`
	Reason    string         `json:"reason"`
	At        *Quote         `json:"at"`
	Fields    map[string]any `json:"fields"`
}

// Event は全出生要求を保持し、取得と取消をstatusで分けます。
type Event struct {
	ID           string         `json:"id"`
	Side         int            `json:"side"`
	Status       string         `json:"status"`
	EntryQuote   *Quote         `json:"entryQuote"`
	Birth        Quote          `json:"birth"`
	EpisodeID    string         `json:"episode_id"`
	Pattern      string         `json:"pattern"`
	Refs         []rules.Ref    `json:"refs"`
	Trace        []Trace        `json:"trace"`
	EntryPrice   *float64       `json:"entry_price"`
	Evaluation   *Quote         `json:"evaluation"`
	EntryCap     float64        `json:"entry_cap"`
	Invalidation float64        `json:"invalidation"`
	ATR5         float64        `json:"atr5"`
	HoldBoundary float64        `json:"hold_boundary"`
	Expires      float64        `json:"expires"`
	Diagnostic   map[string]any `json:"diagnostic"`
}

// Assessment は価格背景と最新VWMAのknown/passを独立保存します。
type Assessment struct {
	Pass      bool                   `json:"pass"`
	Masks     map[string]bool        `json:"masks"`
	Fields    map[string]rules.Value `json:"fields"`
	Refs      []rules.Ref            `json:"refs"`
	W         WValue                 `json:"w"`
	WPrevious WValue                 `json:"w_previous_5"`
}
