package vwmaentry141

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
	"testing"
)

// fixture141 は時刻・足・三尺度背景を自然資料なしで形成します。
//
// 引数: t(*testing.T)、side(int)。返り値: *Detector/関数は初期化済み状態と一原行配送です。
func fixture141(t *testing.T, side int) (*Detector, func(float64, *Minute, float64, bool)) {
	t.Helper()
	scene := Scene{Session: "人工_Day", Contract: "人工", Start: 0, End: 10020, ForceClose: 9000}
	d, e := NewDetector(scene)
	if e != nil {
		t.Fatal(e)
	}
	index := int64(0)
	cache := map[int]rules.Publication{}
	mirror := func(v float64) float64 {
		if side < 0 {
			return 3000 - v
		}
		return v
	}
	step := func(at float64, m *Minute, price float64, ok bool) {
		q := Quote{Clock: fmt.Sprintf("人工%.0f", at), Time: at, Index: index, SourceLine: index + 1, Last: mirror(price), Bid: mirror(price) - 1, Ask: mirror(price) + 1, QuoteOK: ok}
		if !ok {
			q.Bid, q.Ask = 0, 0
		}
		s := rules.Snapshot{SessionID: scene.Session, Contract: scene.Contract, AsOf: rq(q), Frames: map[int]rules.Publication{}}
		for _, width := range []int{300, 900, 1800} {
			end := math.Floor((at-60)/float64(width)) * float64(width)
			p, exists := cache[width]
			if !exists || p.Frame.Frame.End != end {
				v := func(x float64) rules.Value { return rules.Value{Known: true, Value: x} }
				cf := rules.ChartFrame{ID: fmt.Sprintf("背景/%d/%.0f", width, end), SessionID: scene.Session, Contract: scene.Contract, Width: width, Start: end - float64(width), End: end, AvailableAt: end + 60, DeliveryAt: at, PriceKnown: true, OHLC: rules.OHLC{Open: 1000, High: 2000, Low: 900, Close: 1500}, Technical: rules.Technical{EMA21Delta: v(float64(side)), Histogram: v(float64(side)), PreviousHistogram: v(0), ATR: v(20), PreviousATR: v(20), TR: v(10)}}
				plus, minus := 30., 10.
				if side < 0 {
					plus, minus = minus, plus
				}
				p = rules.Publication{Stamp: rules.Stamp{Time: at, Index: int(index), Line: int(index + 1)}, Frame: rules.Frame{Frame: cf, DMI: rules.DMI{PlusDI: v(plus), MinusDI: v(minus), ADX: v(25), PreviousADX: v(24)}}}
				cache[width] = p
				if err := d.AddBackground(p); err != nil {
					t.Fatal(err)
				}
			}
			s.Frames[width] = p
			s.Refs = append(s.Refs, rules.Ref{ID: p.Frame.Frame.ID, Width: width, End: end, Delivered: p.Stamp})
		}
		batch := []Minute{}
		if m != nil {
			z := *m
			z.Session, z.Contract = scene.Session, scene.Contract
			z.Stamp = rules.Stamp{Time: at, Index: int(index), Line: int(index + 1)}
			if side < 0 {
				o := z.OHLC
				z.OHLC = rules.OHLC{Open: mirror(o.Open), High: mirror(o.Low), Low: mirror(o.High), Close: mirror(o.Close)}
			}
			batch = append(batch, z)
		}
		if err := d.Observe(s, q, batch); err != nil {
			t.Fatal(err)
		}
		index++
	}
	for i := 0; i < 25; i++ {
		m := testMinute141(i, 1000+float64(i), 1001+float64(i), 999+float64(i), 1000+float64(i), 1)
		step(m.AvailableAt, &m, m.OHLC.Close, true)
	}
	return d, step
}

// testMinute141 は固定格子の人工1分を作ります。
//
// 引数: i(int)、o/h/l/c/v(float64)。返り値: Minuteです。
func testMinute141(i int, o, h, l, c, v float64) Minute {
	return Minute{ID: fmt.Sprintf("分/%d", i), Start: float64(i * 60), End: float64((i + 1) * 60), AvailableAt: float64((i + 2) * 60), OHLC: rules.OHLC{Open: o, High: h, Low: l, Close: c}, Volume: v, PriceKnown: true, VolumeKnown: true, Closed: true}
}

// pattern141 は受容2本・再接近・次足再加速を順に渡します。
//
// 引数: d(*Detector)、step(関数)。返り値: float64は買い側人工b終値です。
func pattern141(d *Detector, step func(float64, *Minute, float64, bool)) float64 {
	w := d.W.At(1500).Value
	side := 1.
	if w > 1500 {
		side = -1
		w = 3000 - w
	}
	_ = side
	bars := []Minute{testMinute141(25, w+7, w+9, w+6, w+8, 1), testMinute141(26, w+8, w+10, w+7, w+9, 1), testMinute141(27, w+5, w+6, w+2, w+4, 2), testMinute141(28, w+4, w+13, w+3, w+12, 2)}
	for _, m := range bars {
		z := m
		step(m.AvailableAt, &z, m.OHLC.Close, true)
	}
	return w + 12
}

// Test141因果維持と売買鏡像 は出生と取得を別原行/1秒へ分離します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test141因果維持と売買鏡像(t *testing.T) {
	for _, side := range []int{1, -1} {
		t.Run(fmt.Sprint(side), func(t *testing.T) {
			d, step := fixture141(t, side)
			p := pattern141(d, step)
			if len(d.Events) != 0 {
				t.Fatal("b配送時即出生")
			}
			step(1800, nil, p, true)
			if len(d.Events) != 0 {
				t.Fatal("同秒で出生")
			}
			step(1801, nil, p, true)
			if len(d.Events) != 1 || d.Events[0].Side != side || d.Events[0].Status != "pending" {
				t.Fatalf("出生なし:%+v stats=%v", d.Events, d.Stats)
			}
			step(1801, nil, p, true)
			if d.Events[0].Status != "pending" {
				t.Fatal("同秒取得")
			}
			step(1802, nil, p, true)
			e := d.Events[0]
			if e.Status != "filled" || e.EntryQuote.Time != 1802 || e.Birth.Time != 1801 || e.EntryPrice == nil {
				t.Fatalf("取得:%+v", e)
			}
			if e.Trace[len(e.Trace)-1].Fields["background"] == nil {
				t.Fatal("取得参照なし")
			}
		})
	}
}

// Test141最初正常取消と未知 は都合のよい後続価格を選ばないことを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test141最初正常取消と未知(t *testing.T) {
	t.Run("holdcap", func(t *testing.T) {
		d, step := fixture141(t, 1)
		p := pattern141(d, step)
		step(1801, nil, p+10, true)
		step(1802, nil, p, true)
		if len(d.Events) != 0 || d.Stats["取消/hold_entry_cap_rejected"] != 1 {
			t.Fatal(d.Stats)
		}
	})
	t.Run("pendingcap", func(t *testing.T) {
		d, step := fixture141(t, 1)
		p := pattern141(d, step)
		step(1801, nil, p, true)
		step(1802, nil, p+10, true)
		step(1803, nil, p, true)
		if d.Events[0].Status != "entry_cap_rejected" {
			t.Fatal(d.Events[0].Status)
		}
	})
	t.Run("badBBOI", func(t *testing.T) {
		d, step := fixture141(t, 1)
		p := pattern141(d, step)
		step(1801, nil, p, true)
		step(1802, nil, d.Events[0].Invalidation, false)
		if d.Events[0].Status != "last_invalidation" {
			t.Fatal(d.Events[0].Status)
		}
	})
	t.Run("unknown", func(t *testing.T) {
		d, step := fixture141(t, 1)
		w := d.W.At(1500).Value
		m := testMinute141(25, w+7, w+9, w+6, w+8, 1)
		step(m.AvailableAt, &m, m.OHLC.Close, true)
		m = testMinute141(26, w+8, w+10, w+7, w+9, 1)
		m.VolumeKnown = false
		step(m.AvailableAt, &m, m.OHLC.Close, true)
		if len(d.active) != 0 || d.W.Latest().Known {
			t.Fatal("未知を救済")
		}
	})
}

// Test141零量と期限境界 は中間0量の待機とnext足0量取消、等号失効を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func Test141零量と期限境界(t *testing.T) {
	d, step := fixture141(t, 1)
	w := d.W.At(1500).Value
	for _, m := range []Minute{testMinute141(25, w+7, w+9, w+6, w+8, 1), testMinute141(26, w+8, w+10, w+7, w+9, 1), testMinute141(27, w+8, w+10, w+7, w+9, 0)} {
		z := m
		step(m.AvailableAt, &z, m.OHLC.Close, true)
	}
	if d.active[1] == nil || d.active[1].Phase != "再接近待ち" || d.Stats["再接近待ちの既知量0"] != 1 {
		t.Fatal(d.Stats)
	}
	e := d.active[1]
	q := *d.last
	q.Time = e.Expires
	if d.contextPass(e, Assessment{Pass: true}, q) != "episode_expired" {
		t.Fatal("等号")
	}
	d2, step2 := fixture141(t, 1)
	m := testMinute141(25, w+7, w+9, w+6, w+8, 1)
	step2(m.AvailableAt, &m, m.OHLC.Close, true)
	m = testMinute141(26, w+8, w+10, w+7, w+9, 0)
	step2(m.AvailableAt, &m, m.OHLC.Close, true)
	if d2.active[1] != nil {
		t.Fatal("a2量0を待った")
	}
}
