package vwmaentry141

import (
	"fmt"
	"math"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// finite はRaw/geometryの有限性を検査します。
//
// 引数: values(...float64)。返り値: boolは全値が有限かです。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// normal は既存Raw採用器と同じ正常最良BBOを返します。
//
// 引数: q(Quote)。返り値: boolは正のBid<Askかです。
func normal(q Quote) bool { return finite(q.Bid, q.Ask) && q.Bid > 0 && q.Ask > q.Bid }

// rq は同じ採用Rawの原行を118の参照型へ写します。
//
// 引数: q(Quote)。返り値: rules.Quoteです。
func rq(q Quote) rules.Quote {
	return rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last}
}

// minuteRef は1分を118Bankに投入せず参照としてだけ保存します。
//
// 引数: m(Minute)。返り値: rules.Refは幅60の出典です。
func minuteRef(m Minute) rules.Ref {
	return rules.Ref{ID: m.ID, Width: 60, End: m.End, Delivered: m.Stamp}
}

// mergeRefs は同一IDを二重化せず、改変を拒否して参照をまとめます。
//
// 引数: base/more([]rules.Ref)。返り値: []rules.Refは独立copyです。
func mergeRefs(base []rules.Ref, more ...[]rules.Ref) []rules.Ref {
	out := append([]rules.Ref(nil), base...)
	seen := map[string]rules.Ref{}
	for _, r := range out {
		seen[r.ID] = r
	}
	for _, list := range more {
		for _, r := range list {
			if old, ok := seen[r.ID]; ok {
				if old != r {
					panic("同一参照IDの改変")
				}
				continue
			}
			seen[r.ID] = r
			out = append(out, r)
		}
	}
	return out
}

// validMinute は値と配送が当時利用可能だったことを確認します。
//
// 引数: m(Minute)、q(Quote)、scene(Scene)。返り値: errorは未来/scope不正です。
func validMinute(m Minute, q Quote, scene Scene) error {
	if m.ID == "" || m.Session != scene.Session || m.Contract != scene.Contract || !finite(m.Start, m.End, m.AvailableAt, m.Stamp.Time) || m.End-m.Start != 60 || m.AvailableAt != m.End+60 || m.Start < scene.Start || m.End > scene.End-300 || m.End > m.AvailableAt || m.AvailableAt > m.Stamp.Time || m.Stamp.Time > q.Time || int64(m.Stamp.Index) > q.Index || int64(m.Stamp.Line) > q.SourceLine || m.Stamp.Index < 0 || m.Stamp.Line < 1 {
		return fmt.Errorf("1分scope/因果時計が不正")
	}
	return nil
}

// referenceBefore は保存参照が現在原行以前であるか確認します。
//
// 引数: refs([]rules.Ref)、q(Quote)。返り値: boolです。
func referenceBefore(refs []rules.Ref, q Quote) bool {
	for _, r := range refs {
		if r.End > q.Time || r.Delivered.Time > q.Time || int64(r.Delivered.Index) > q.Index || int64(r.Delivered.Line) > q.SourceLine {
			return false
		}
	}
	return true
}

// background は現在配送済みの三尺度と最新W/5分差を符号対称に判定します。
//
// 引数: snapshot(rules.Snapshot)、q(Quote)、side(int)、w(*VWMA)。返り値: Assessment/errorです。
func background(snapshot rules.Snapshot, q Quote, side int, w *VWMA) (Assessment, error) {
	a := Assessment{Masks: map[string]bool{}, Fields: map[string]rules.Value{}, Refs: append([]rules.Ref(nil), snapshot.Refs...), W: w.Latest()}
	a.WPrevious = w.At(a.W.End - 300)
	s := float64(side)
	if !referenceBefore(snapshot.Refs, q) || !referenceBefore(a.W.Refs, q) || !referenceBefore(a.WPrevious.Refs, q) {
		return a, fmt.Errorf("背景又はWに未来参照")
	}
	framesKnown := true
	for _, width := range []int{300, 900, 1800} {
		p, ok := snapshot.Frames[width]
		f := p.Frame.Frame
		pass := ok && f.PriceKnown && q.Time < f.End+float64(width)+60 && f.AvailableAt <= q.Time && f.DeliveryAt <= q.Time && p.Stamp.Time <= q.Time && int64(p.Stamp.Index) <= q.Index && int64(p.Stamp.Line) <= q.SourceLine
		a.Masks[fmt.Sprintf("frame_%d_fresh_price", width)] = pass
		framesKnown = framesKnown && pass
	}
	f5, f15, f30 := snapshot.Frames[300], snapshot.Frames[900], snapshot.Frames[1800]
	t := f5.Frame.Frame.Technical
	d := f15.Frame.DMI
	l := f30.Frame.Frame.Technical
	a.Fields["ema21_delta30"], a.Fields["hist5"], a.Fields["atr5"], a.Fields["previous_atr5"], a.Fields["tr5"] = l.EMA21Delta, t.Histogram, t.ATR, t.PreviousATR, t.TR
	a.Masks["long_known"] = l.EMA21Delta.Known
	a.Masks["long_pass"] = l.EMA21Delta.Known && s*l.EMA21Delta.Value > 0
	diKnown := d.PlusDI.Known && d.MinusDI.Known
	di := s * (d.PlusDI.Value - d.MinusDI.Value)
	a.Fields["di15_signed"] = rules.Value{Known: diKnown, Value: di}
	a.Masks["di_known"], a.Masks["di_pass"] = diKnown, diKnown && di > 0
	adxDeltaKnown := d.ADX.Known && d.PreviousADX.Known
	adxDelta := d.ADX.Value - d.PreviousADX.Value
	a.Fields["adx15"], a.Fields["adx15_delta"] = d.ADX, rules.Value{Known: adxDeltaKnown, Value: adxDelta}
	a.Masks["adx_level_known"], a.Masks["adx_level_pass"] = d.ADX.Known, d.ADX.Known && d.ADX.Value >= 20
	a.Masks["adx_delta_known"], a.Masks["adx_delta_pass"] = adxDeltaKnown, adxDeltaKnown && adxDelta > 0
	a.Masks["hist_level_known"], a.Masks["hist_level_pass"] = t.Histogram.Known, t.Histogram.Known && s*t.Histogram.Value >= 0
	histDeltaKnown := t.Histogram.Known && t.PreviousHistogram.Known
	histDelta := s * (t.Histogram.Value - t.PreviousHistogram.Value)
	a.Fields["hist5_delta_signed"] = rules.Value{Known: histDeltaKnown, Value: histDelta}
	a.Masks["hist_delta_known"], a.Masks["hist_delta_pass"] = histDeltaKnown, histDeltaKnown && histDelta > 0
	a.Masks["atr_tr_known"] = t.ATR.Known && t.PreviousATR.Known && t.TR.Known
	a.Masks["atr_tr_pass"] = a.Masks["atr_tr_known"] && t.ATR.Value > 0 && t.PreviousATR.Value > 0 && t.TR.Value >= 0 && t.TR.Value <= 2*t.PreviousATR.Value
	delta := w.Delta5At(a.W.End)
	a.Fields["latest_w_delta5"] = delta
	a.Masks["latest_w_known"], a.Masks["latest_w_direction"] = a.W.Known && delta.Known, a.W.Known && delta.Known && s*delta.Value > 0
	a.Pass = framesKnown && a.Masks["long_pass"] && a.Masks["di_pass"] && (a.Masks["adx_level_pass"] || a.Masks["adx_delta_pass"]) && (a.Masks["hist_level_pass"] || a.Masks["hist_delta_pass"]) && a.Masks["atr_tr_pass"] && a.Masks["latest_w_direction"]
	a.Refs = mergeRefs(a.Refs, a.W.Refs, a.WPrevious.Refs)
	return a, nil
}
