package vwmaentry141

import (
	"fmt"
	"math"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

type episode struct {
	ID                                                  string
	Side                                                int
	Phase                                               string
	A1, A2, J, B                                        Minute
	WStar, WPrevious                                    WValue
	ATR                                                 float64
	ATRRef                                              rules.Ref
	Low, High, K, I, Cap, Expires, ReadyAt, HoldExpires float64
	FirstHold                                           *Quote
	Refs                                                []rules.Ref
	Trace                                               []Trace
	Range30                                             map[string]any
}

// Detector はVWMAとは別にV0の当時状態と全要求を管理します。
type Detector struct {
	Scene       Scene
	W           *VWMA
	Events      []*Event
	Lifecycle   []Trace
	Stats       map[string]uint64
	StageCounts map[string]uint64
	active      map[int]*episode
	lastBirth   map[int]float64
	used        map[int]map[string]bool
	minutes     map[float64]Minute
	background5 []rules.Publication
	last        *Quote
}

// NewDetector は当場の独立V0状態を開始します。
//
// 引数: scene(Scene)。返り値: *Detector/errorは初期状態又は不正metadataです。
func NewDetector(scene Scene) (*Detector, error) {
	if scene.Session == "" || scene.Contract == "" || !finite(scene.Start, scene.End, scene.ForceClose) || scene.End-3900 <= scene.Start {
		return nil, fmt.Errorf("V0場metadata不正")
	}
	d := &Detector{Scene: scene, W: NewVWMA(), Events: []*Event{}, Lifecycle: []Trace{}, Stats: map[string]uint64{}, StageCounts: map[string]uint64{}, active: map[int]*episode{}, lastBirth: map[int]float64{}, used: map[int]map[string]bool{1: {}, -1: {}}, minutes: map[float64]Minute{}}
	if err := d.W.StartSession(scene.Session, scene.Contract); err != nil {
		return nil, err
	}
	return d, nil
}

// AddBackground は実配送した当場5分を保存し、過去ATRの任意fallbackを避けます。
//
// 引数: p(rules.Publication)。返り値: errorはscope又は改変です。
func (d *Detector) AddBackground(p rules.Publication) error {
	f := p.Frame.Frame
	if f.SessionID != d.Scene.Session || f.Contract != d.Scene.Contract {
		return fmt.Errorf("V0背景scope不一致")
	}
	if f.Width != 300 {
		return nil
	}
	for _, old := range d.background5 {
		if old.Frame.Frame.ID == f.ID {
			if old != p {
				return fmt.Errorf("V0背景ID改変")
			}
			return nil
		}
	}
	if len(d.background5) > 0 && f.End <= d.background5[len(d.background5)-1].Frame.Frame.End {
		return fmt.Errorf("V0背景5分逆順")
	}
	d.background5 = append(d.background5, p)
	return nil
}

// limit はH60を残す取得限界を返します。
//
// 引数: なし。返り値: float64は元forceとEnd-3900の小さい方です。
func (d *Detector) limit() float64 { return math.Min(d.Scene.ForceClose, d.Scene.End-3900) }

// record は状態遷移だけを保存し、判定不成立の全Rawを大量転記しません。
//
// 引数: e(*episode)、stage/reason(string)、q(Quote)、fields(map[string]any)。返り値: なし。
func (d *Detector) record(e *episode, stage, reason string, q Quote, fields map[string]any) {
	z := q
	t := Trace{EpisodeID: e.ID, Side: e.Side, Stage: stage, Reason: reason, At: &z, Fields: fields}
	e.Trace = append(e.Trace, t)
	d.Lifecycle = append(d.Lifecycle, t)
	d.StageCounts[stage]++
}

// cancel は現在episodeを終え、同じ足のa1再利用を呼出し側に許しません。
//
// 引数: e(*episode)、reason(string)、q(Quote)。返り値: なし。
func (d *Detector) cancel(e *episode, reason string, q Quote) {
	d.record(e, "取消", reason, q, map[string]any{"phase": e.Phase})
	d.Stats["取消/"+reason]++
	delete(d.active, e.Side)
}

// cancelEvent は出生後要求の取消と時点を保存します。
//
// 引数: e(*Event)、reason(string)、q(Quote)。返り値: なし。
func (d *Detector) cancelEvent(e *Event, reason string, q Quote) {
	e.Status = reason
	z := q
	t := Trace{EpisodeID: e.EpisodeID, Side: e.Side, Stage: "要求取消", Reason: reason, At: &z, Fields: map[string]any{"id": e.ID}}
	e.Trace = append(e.Trace, t)
	d.Lifecycle = append(d.Lifecycle, t)
	d.StageCounts["要求取消"]++
	d.Stats["要求取消/"+reason]++
}

// RejectClock は不明時計を後から補わず当時の状態を取消します。
//
// 引数: reason(string)、line(int64)は拒否区分/物理行。返り値: なし。
func (d *Detector) RejectClock(reason string, line int64) {
	d.Stats["時計拒否/"+reason]++
	if d.last == nil {
		return
	}
	q := *d.last
	for _, side := range []int{1, -1} {
		e := d.active[side]
		if e == nil {
			continue
		}
		d.record(e, "時計拒否", "時刻不明のため直前既知asofで記録", q, map[string]any{"rejected_line": line, "reason": reason})
		d.cancel(e, "clock_rejected", q)
	}
	for _, e := range d.Events {
		if e.Status == "pending" {
			d.cancelEvent(e, "clock_rejected", q)
		}
	}
}

// atrAt はa1.End以下の最新の配送済み当場5分だけを選びます。
//
// 引数: end(float64)、q(Quote)。返り値: float64/rules.Ref/boolはATR・参照・既知性です。
func (d *Detector) atrAt(end float64, q Quote) (float64, rules.Ref, bool) {
	for i := len(d.background5) - 1; i >= 0; i-- {
		p := d.background5[i]
		f := p.Frame.Frame
		if f.End > end {
			continue
		}
		r := rules.Ref{ID: f.ID, Width: 300, End: f.End, Delivered: p.Stamp}
		known := f.PriceKnown && f.Technical.ATR.Known && f.Technical.ATR.Value > 0 && q.Time < f.End+360 && referenceBefore([]rules.Ref{r}, q)
		return f.Technical.ATR.Value, r, known
	}
	return 0, rules.Ref{}, false
}

// contextPass は背景/最新W、期限、現在LastのI到達を判定します。
//
// 引数: e(*episode)、a(Assessment)、q(Quote)。返り値: stringは空なら有効です。
func (d *Detector) contextPass(e *episode, a Assessment, q Quote) string {
	if q.Time >= d.limit() {
		return "entry_limit"
	}
	if q.Time >= e.Expires {
		return "episode_expired"
	}
	if !a.Pass {
		return "background_or_latest_w_unknown_or_denied"
	}
	if (e.Phase == "b待ち" || e.Phase == "維持") && float64(e.Side)*(q.Last-e.I) <= 0 {
		return "last_invalidation"
	}
	if e.Phase == "b待ち" && q.Time >= e.J.End+60+120 {
		return "expected_b_expired"
	}
	if e.Phase == "維持" && q.Time >= e.HoldExpires {
		return "hold_expired"
	}
	return ""
}

// arm はa1以前で終わる正確窓/5分差と凍結帯を保存します。
//
// 引数: m(Minute)、side(int)、a(Assessment)、q(Quote)。返り値: なし。
func (d *Detector) arm(m Minute, side int, a Assessment, q Quote) {
	if q.Time >= d.limit() || !a.Pass || !trackerKnown(m) || m.Volume <= 0 || d.used[side][m.ID] {
		return
	}
	if last, ok := d.lastBirth[side]; ok && q.Time < last+600 {
		d.Stats["cooldown"]++
		return
	}
	w := d.W.At(m.Start)
	previous := d.W.At(m.Start - 300)
	delta := d.W.Delta5At(m.Start)
	atr, atrRef, known := d.atrAt(m.End, q)
	if !w.Known || !previous.Known || !delta.Known || float64(side)*delta.Value <= 0 || !known || !referenceBefore(mergeRefs(w.Refs, previous.Refs), q) {
		d.Stats["a1基準未知又は方向不成立"]++
		return
	}
	boundary := w.Value + float64(side)*.25*atr
	if float64(side)*(m.OHLC.Close-boundary) <= 0 || q.Time >= m.End+900 {
		return
	}
	e := &episode{ID: fmt.Sprintf("%s/V0/%d/%.0f", d.Scene.Session, side, m.End), Side: side, Phase: "a2待ち", A1: m, WStar: w, WPrevious: previous, ATR: atr, ATRRef: atrRef, Low: w.Value - .25*atr, High: w.Value + .25*atr, Expires: m.End + 900}
	e.Refs = mergeRefs(nil, w.Refs, previous.Refs, []rules.Ref{atrRef, minuteRef(m)}, a.Refs)
	d.active[side] = e
	d.used[side][m.ID] = true
	d.record(e, "受容a1", "固定帯外の初回受容", q, map[string]any{"minute": m, "w_star": w, "w_previous5": previous, "atr5_frozen": atr, "atr_ref": atrRef, "band_low": e.Low, "band_high": e.High, "background": a})
}

// prior30 はjを除く正確30本の価格高安を診断用に求めます。
//
// 引数: j(Minute)。返り値: map[string]anyは未知を数値で埋めない診断です。
func (d *Detector) prior30(j Minute) map[string]any {
	lo, hi := math.Inf(1), math.Inf(-1)
	refs := []rules.Ref{}
	for i := 30; i >= 1; i-- {
		m, ok := d.minutes[j.Start-float64(i*60)]
		if !ok || !m.Closed || !m.PriceKnown || m.End != m.Start+60 {
			return map[string]any{"known": false, "low": nil, "high": nil, "count": 30}
		}
		lo = math.Min(lo, m.OHLC.Low)
		hi = math.Max(hi, m.OHLC.High)
		refs = append(refs, minuteRef(m))
	}
	return map[string]any{"known": true, "low": lo, "high": hi, "count": 30, "refs": refs}
}

// processMinute は別足の受容/再接近/再加速を市場順で判定します。
//
// 引数: e(*episode)、m(Minute)、a(Assessment)、q(Quote)。返り値: なし。
func (d *Detector) processMinute(e *episode, m Minute, a Assessment, q Quote) {
	if !trackerKnown(m) {
		d.cancel(e, "required_minute_unknown_or_nonpositive_volume", q)
		return
	}
	if m.Volume <= 0 {
		if e.Phase == "再接近待ち" {
			d.Stats["再接近待ちの既知量0"]++
			return
		}
		d.cancel(e, "required_minute_nonpositive_volume", q)
		return
	}
	s := float64(e.Side)
	o := m.OHLC
	switch e.Phase {
	case "a2待ち":
		d.used[e.Side][m.ID] = true
		boundary := e.High
		if e.Side < 0 {
			boundary = e.Low
		}
		if m.Start != e.A1.End || s*(o.Close-boundary) <= 0 {
			d.cancel(e, "next_a2_failed", q)
			return
		}
		e.A2 = m
		e.Phase = "再接近待ち"
		e.Refs = mergeRefs(e.Refs, []rules.Ref{minuteRef(m)}, a.Refs)
		d.record(e, "受容a2", "直後別分で同帯外を受容", q, map[string]any{"minute": m, "background": a})
	case "再接近待ち":
		if m.Start < e.A2.End {
			d.cancel(e, "retest_market_order", q)
			return
		}
		if o.High < e.Low || o.Low > e.High || o.Close < e.Low || o.Close > e.High || o.High-o.Low > e.ATR {
			return
		}
		e.J = m
		e.Phase = "b待ち"
		e.K = o.High + 5
		e.I = o.Low - 5
		if e.Side < 0 {
			e.K = o.Low - 5
			e.I = o.High + 5
		}
		e.Cap = e.K + s*math.Min(20, .25*e.ATR)
		e.Range30 = d.prior30(m)
		e.Refs = mergeRefs(e.Refs, []rules.Ref{minuteRef(m)}, a.Refs)
		d.record(e, "再接近j", "凍結帯内の別足でK/I/capを固定", q, map[string]any{"minute": m, "K": e.K, "I": e.I, "cap": e.Cap, "prior30": e.Range30, "background": a})
	case "b待ち":
		position := 0.0
		if o.High > o.Low {
			position = (o.Close - o.Low) / (o.High - o.Low)
			if e.Side < 0 {
				position = (o.High - o.Close) / (o.High - o.Low)
			}
		}
		oppositeExtreme := o.Low
		if e.Side < 0 {
			oppositeExtreme = o.High
		}
		if m.Start != e.J.End || m.End != e.J.End+60 || s*(o.Close-e.K) < 0 || s*(o.Close-o.Open) <= 0 || position < .7 || m.Volume < e.J.Volume || o.High-o.Low > e.ATR || s*(oppositeExtreme-e.I) <= 0 {
			d.cancel(e, "next_b_failed", q)
			return
		}
		e.B = m
		e.Phase = "維持"
		e.ReadyAt = q.Time
		e.HoldExpires = math.Min(math.Min(q.Time+10, m.End+120), math.Min(e.Expires, d.limit()))
		e.Refs = mergeRefs(e.Refs, []rules.Ref{minuteRef(m)}, a.Refs)
		if q.Time >= e.HoldExpires {
			d.cancel(e, "ready_expired", q)
			return
		}
		d.record(e, "再加速b", "別次足と現在背景を同時知得、ready固定", q, map[string]any{"minute": m, "close_position": position, "D_ready": e.ReadyAt, "hold_expires": e.HoldExpires, "background": a})
	}
}

// geometry は現在Lastと実取得側を固定K/cap/riskへ照合します。
//
// 引数: side(int)、k/cap/invalidation/atr(float64)、q(Quote)。返り値: stringは空なら適格です。
func geometry(side int, k, cap, invalidation, atr float64, q Quote) string {
	s := float64(side)
	price := q.Ask
	if side < 0 {
		price = q.Bid
	}
	if s*(q.Last-k) < 0 || s*(price-k) < 0 {
		return "K_not_recovered"
	}
	if s*(q.Last-cap) > 0 || s*(price-cap) > 0 {
		return "entry_cap_rejected"
	}
	risk := s * (price - invalidation)
	if risk < 10 || risk > math.Min(125, 1.5*atr) {
		return "risk_rejected"
	}
	return ""
}

// hold は正常BBOの最初不適格を取消し、2別行/1秒を満たした現在だけ出生します。
//
// 引数: e(*episode)、a(Assessment)、q(Quote)。返り値: なし。
func (d *Detector) hold(e *episode, a Assessment, q Quote) {
	if e.Phase != "維持" || !q.QuoteOK || !normal(q) {
		return
	}
	if reason := geometry(e.Side, e.K, e.Cap, e.I, e.ATR, q); reason != "" {
		d.cancel(e, "hold_"+reason, q)
		return
	}
	e.Refs = mergeRefs(e.Refs, a.Refs)
	if e.FirstHold == nil {
		z := q
		e.FirstHold = &z
		d.record(e, "維持1", "最初の正常BBO維持", q, map[string]any{"K": e.K, "cap": e.Cap})
		return
	}
	if q.Index <= e.FirstHold.Index || q.SourceLine <= e.FirstHold.SourceLine || q.Time < e.FirstHold.Time+1 {
		return
	}
	d.record(e, "出生", "別原行2行と価格時計1秒以上の維持", q, map[string]any{"first_hold": e.FirstHold, "D_ready": e.ReadyAt, "b_end": e.B.End})
	diagnostic := map[string]any{"prior30": e.Range30, "125_over_atr5": 125 / e.ATR, "b_close_to_birth_signed": float64(e.Side) * (q.Last - e.B.OHLC.Close), "opposing_edge_distance": nil, "opposing_edge_known": false}
	event := &Event{ID: fmt.Sprintf("%s/%d", e.ID, q.Index), Side: e.Side, Status: "pending", Birth: q, EpisodeID: e.ID, Pattern: "V0", Refs: append([]rules.Ref(nil), e.Refs...), Trace: append([]Trace(nil), e.Trace...), EntryCap: e.Cap, Invalidation: e.I, ATR5: e.ATR, HoldBoundary: e.K, Expires: math.Min(math.Min(q.Time+30, e.B.End+120), math.Min(e.Expires, d.limit())), Diagnostic: diagnostic}
	d.Events = append(d.Events, event)
	d.lastBirth[e.Side] = q.Time
	delete(d.active, e.Side)
}

// processPending は最初の別Raw+1秒正常BBOだけを評価します。
//
// 引数: assessments(map[int]Assessment)、q(Quote)。返り値: なし。
func (d *Detector) processPending(assessments map[int]Assessment, q Quote) {
	for _, e := range d.Events {
		if e.Status != "pending" {
			continue
		}
		if q.Time >= e.Expires {
			d.cancelEvent(e, "unfilled_expired", q)
			continue
		}
		if !assessments[e.Side].Pass {
			d.eventAssessment(e, assessments[e.Side], q, "取得前背景拒否")
			d.cancelEvent(e, "background_or_latest_w_unknown_or_denied", q)
			continue
		}
		if float64(e.Side)*(q.Last-e.Invalidation) <= 0 {
			d.cancelEvent(e, "last_invalidation", q)
			continue
		}
		if q.Index <= e.Birth.Index || q.SourceLine <= e.Birth.SourceLine || q.Time < e.Birth.Time+1 || !q.QuoteOK || !normal(q) {
			continue
		}
		z := q
		e.Evaluation = &z
		d.eventAssessment(e, assessments[e.Side], q, "取得評価")
		if reason := geometry(e.Side, e.HoldBoundary, e.EntryCap, e.Invalidation, e.ATR5, q); reason != "" {
			d.cancelEvent(e, reason, q)
			continue
		}
		price := q.Ask
		if e.Side < 0 {
			price = q.Bid
		}
		e.EntryQuote = &z
		e.EntryPrice = &price
		e.Status = "filled"
		if prior, ok := e.Diagnostic["prior30"].(map[string]any); ok && prior["known"] == true {
			distance := prior["high"].(float64) - price
			if e.Side < 0 {
				distance = price - prior["low"].(float64)
			}
			e.Diagnostic["opposing_edge_distance"], e.Diagnostic["opposing_edge_known"] = distance, true
		}
		e.Diagnostic["entry_risk"] = float64(e.Side) * (price - e.Invalidation)
		t := Trace{EpisodeID: e.EpisodeID, Side: e.Side, Stage: "取得", Reason: "出生後の最初正常実BBO", At: &z, Fields: map[string]any{"entry_price": price, "background": assessments[e.Side]}}
		e.Trace = append(e.Trace, t)
		d.Lifecycle = append(d.Lifecycle, t)
		d.StageCounts["取得"]++
	}
}

// eventAssessment は取得時計の現在背景と全参照を保存します。
//
// 引数: e(*Event)、a(Assessment)、q(Quote)、stage(string)。返り値: なし。
func (d *Detector) eventAssessment(e *Event, a Assessment, q Quote, stage string) {
	e.Refs = mergeRefs(e.Refs, a.Refs)
	z := q
	t := Trace{EpisodeID: e.EpisodeID, Side: e.Side, Stage: stage, Reason: "現在背景を再検査", At: &z, Fields: map[string]any{"background": a}}
	e.Trace = append(e.Trace, t)
	d.Lifecycle = append(d.Lifecycle, t)
	d.StageCounts[stage]++
}

// Observe は同Rawの全1分更新後に状態/既要求/出生を因果順で処理します。
//
// 引数: snapshot(rules.Snapshot)、q(Quote)、minutes([]Minute)は同Rawへ配送した全分。
// 返り値: errorは入力矛盾です。指標・出生を過去へ遡らせません。
func (d *Detector) Observe(snapshot rules.Snapshot, q Quote, minutes []Minute) error {
	if !finite(q.Time, q.Last) || q.Last <= 0 || q.Index < 0 || q.SourceLine < 1 || snapshot.SessionID != d.Scene.Session || snapshot.Contract != d.Scene.Contract {
		return fmt.Errorf("V0現在Raw/scope不正")
	}
	if d.last != nil && (q.Index <= d.last.Index || q.SourceLine <= d.last.SourceLine || q.Time < d.last.Time) {
		return fmt.Errorf("V0現在Raw逆順")
	}
	d.Stats["採用Raw"]++
	if d.last != nil && q.Time-d.last.Time > 300 {
		for _, side := range []int{1, -1} {
			e := d.active[side]
			if e == nil {
				continue
			}
			d.cancel(e, "price_clock_gap300", q)
		}
		for _, e := range d.Events {
			if e.Status == "pending" {
				d.cancelEvent(e, "price_clock_gap300", q)
			}
		}
	}
	for _, m := range minutes {
		if err := validMinute(m, q, d.Scene); err != nil {
			return err
		}
		if _, ok := d.minutes[m.Start]; ok {
			return fmt.Errorf("V0分ID又は開始が重複")
		}
		if err := d.W.Add(m); err != nil {
			return err
		}
		d.minutes[m.Start] = m
		d.Stats["1分配送"]++
	}
	assessments := map[int]Assessment{}
	for _, side := range []int{1, -1} {
		a, err := background(snapshot, q, side, d.W)
		if err != nil {
			return err
		}
		assessments[side] = a
	}
	d.processPending(assessments, q)
	for _, m := range minutes {
		for _, side := range []int{1, -1} {
			a := assessments[side]
			e, active := d.active[side]
			if active {
				if reason := d.contextPass(e, a, q); reason != "" {
					d.record(e, "現在背景検査", reason, q, map[string]any{"background": a})
					d.cancel(e, reason, q)
					continue
				}
				d.processMinute(e, m, a, q)
				continue
			}
			d.arm(m, side, a, q)
		}
	}
	for _, side := range []int{1, -1} {
		if e, ok := d.active[side]; ok {
			a := assessments[side]
			if reason := d.contextPass(e, a, q); reason != "" {
				d.record(e, "現在背景検査", reason, q, map[string]any{"background": a})
				d.cancel(e, reason, q)
			} else {
				d.hold(e, a, q)
			}
		}
	}
	z := q
	d.last = &z
	return nil
}

// Finish はEOFで架空時計を進めず未完episode/要求を別区分へ閉じます。
//
// 引数: なし。返り値: なし。取得済み要求は変更しません。
func (d *Detector) Finish() {
	if d.last == nil {
		return
	}
	q := *d.last
	for _, side := range []int{1, -1} {
		e := d.active[side]
		if e == nil {
			continue
		}
		d.cancel(e, "eof_without_later_quote", q)
	}
	for _, e := range d.Events {
		if e.Status == "pending" {
			d.cancelEvent(e, "unfilled_eof", q)
		}
	}
}
