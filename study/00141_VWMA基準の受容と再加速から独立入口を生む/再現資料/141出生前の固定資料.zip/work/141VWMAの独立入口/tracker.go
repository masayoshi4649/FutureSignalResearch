package vwmaentry141

import (
	"fmt"
	"math"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

type VWMA struct {
	session, contract string
	minutes           []Minute
	values            map[float64]WValue
	latest            float64
	hasLatest         bool
}

// NewVWMA は、固定20分窓を空の状態で作ります。
//
// 引数: なし。返り値: *VWMA は場を開始する前の純trackerです。
func NewVWMA() *VWMA { return &VWMA{values: map[float64]WValue{}} }

// StartSession は、当場と限月を設定し、過去場の窓を全て捨てます。
//
// 引数: session/contract(string)は空でない識別子。返り値: error は不正識別子です。
func (w *VWMA) StartSession(session, contract string) error {
	if session == "" || contract == "" {
		return fmt.Errorf("VWMAの場又は限月が空です")
	}
	w.session, w.contract = session, contract
	w.minutes = nil
	w.values = map[float64]WValue{}
	w.latest, w.hasLatest = 0, false
	return nil
}

// trackerFinite は、窓の時計と演算値の有限性を調べます。
//
// 引数: values(...float64)は判定対象。返り値: bool は全て有限なら真です。
func trackerFinite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// trackerKnown は、本試行の保守規約で1分が完全に既知か調べます。
//
// 引数: m(Minute)は確定候補。返り値: bool は価格・量・確定が既知なら真です。
func trackerKnown(m Minute) bool {
	o := m.OHLC
	return !m.Missing && m.Closed && m.PriceKnown && m.VolumeKnown &&
		trackerFinite(o.Open, o.High, o.Low, o.Close, m.Volume) &&
		o.Low > 0 && o.High >= o.Low && o.Open >= o.Low && o.Open <= o.High &&
		o.Close >= o.Low && o.Close <= o.High && m.Volume >= 0
}

// Add は、実配送済みの固定1分格子を一つ加え、正確な20分窓を計算します。
//
// 引数: m(Minute)は欠分placeholderを含む次の連続分。返り値: error は格子・配送の矛盾です。
func (w *VWMA) Add(m Minute) error {
	if w.session == "" || m.Session != w.session || m.Contract != w.contract || m.ID == "" ||
		!trackerFinite(m.Start, m.End, m.AvailableAt, m.Stamp.Time) || m.End-m.Start != 60 ||
		m.AvailableAt != m.End+60 || m.Stamp.Time < m.AvailableAt || m.Stamp.Index < 0 || m.Stamp.Line < 1 {
		return fmt.Errorf("VWMA分格子の識別又は配送時計が不正です")
	}
	if w.hasLatest && m.Start != w.latest {
		return fmt.Errorf("VWMA分格子が非連続又は重複です")
	}
	if len(w.minutes) > 0 {
		p := w.minutes[len(w.minutes)-1].Stamp
		if m.Stamp.Time < p.Time || m.Stamp.Index < p.Index || m.Stamp.Line < p.Line {
			return fmt.Errorf("VWMA配送が逆順です")
		}
	}
	w.minutes = append(w.minutes, m)
	if len(w.minutes) > 20 {
		w.minutes = w.minutes[len(w.minutes)-20:]
	}
	v := WValue{End: m.End}
	if len(w.minutes) == 20 {
		v.Refs = make([]rules.Ref, 0, 20)
		known, quantity, weighted := true, 0.0, 0.0
		origin := w.minutes[0].OHLC.Close
		for _, minute := range w.minutes {
			v.Refs = append(v.Refs, rules.Ref{ID: minute.ID, Width: 60, End: minute.End, Delivered: minute.Stamp})
			if !trackerKnown(minute) {
				known = false
				continue
			}
			tp := (minute.OHLC.High - origin + minute.OHLC.Low - origin + minute.OHLC.Close - origin) / 3
			quantity += minute.Volume
			weighted += tp * minute.Volume
		}
		if known && quantity > 0 && trackerFinite(origin, quantity, weighted) {
			value := origin + weighted/quantity
			if trackerFinite(value) && value > 0 {
				v.Known, v.Value = true, value
			}
		}
	}
	w.values[m.End], w.latest, w.hasLatest = v, m.End, true
	return nil
}

// At は、指定した正確な窓Endの値を返します。
//
// 引数: end(float64)は求める窓端。返り値: WValue は存在しない時も未知で、古い値へ戻りません。
func (w *VWMA) At(end float64) WValue {
	v, ok := w.values[end]
	if !ok {
		return WValue{End: end}
	}
	v.Refs = append([]rules.Ref(nil), v.Refs...)
	return v
}

// Latest は、最新配送分を端とする窓を返します。
//
// 引数: なし。返り値: WValue は最新窓の未知も保持し、直前の正常値で補いません。
func (w *VWMA) Latest() WValue {
	if !w.hasLatest {
		return WValue{}
	}
	return w.At(w.latest)
}

// Delta5At は、正確に5分離れた二つの既知窓の差を求めます。
//
// 引数: end(float64)は新しい窓端。返り値: rules.Value は片端でも未知なら未知です。
func (w *VWMA) Delta5At(end float64) rules.Value {
	a, b := w.At(end), w.At(end-300)
	if !a.Known || !b.Known {
		return rules.Value{}
	}
	d := a.Value - b.Value
	if !trackerFinite(d) {
		return rules.Value{}
	}
	return rules.Value{Known: true, Value: d}
}
