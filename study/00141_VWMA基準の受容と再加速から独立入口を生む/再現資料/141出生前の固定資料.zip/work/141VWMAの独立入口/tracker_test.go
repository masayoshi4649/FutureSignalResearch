package vwmaentry141

import (
	"math"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// trackerMinute は、既知1分の人工資料を作ります。
//
// 引数: n(int)、price/volume(float64)は分番号・価格・量。返り値: Minute は当場の確定公表です。
func trackerMinute(n int, price, volume float64) Minute {
	start := float64(n * 60)
	return Minute{ID: "人工/" + string(rune(1000+n)), Session: "人工場", Contract: "人工限月", Start: start, End: start + 60,
		AvailableAt: start + 120, OHLC: rules.OHLC{Open: price, High: price, Low: price, Close: price}, Volume: volume,
		PriceKnown: true, VolumeKnown: true, Closed: true, Stamp: rules.Stamp{Time: start + 120, Index: n, Line: n + 1}}
}

// TestVWMAExactGrid は、量加重・正確窓・5分差・参照の不変性を検査します。
//
// 引数: t(*testing.T)は検査管理。返り値: なし。自然資料は読みません。
func TestVWMAExactGrid(t *testing.T) {
	w := NewVWMA()
	if e := w.StartSession("人工場", "人工限月"); e != nil {
		t.Fatal(e)
	}
	for n := 0; n < 25; n++ {
		if e := w.Add(trackerMinute(n, 100+float64(n), float64(n+1))); e != nil {
			t.Fatal(e)
		}
	}
	x := w.At(1200)
	sum, q := 0.0, 0.0
	for n := 0; n < 20; n++ {
		sum += (100 + float64(n)) * float64(n+1)
		q += float64(n + 1)
	}
	if !x.Known || math.Abs(x.Value-sum/q) > 1e-10 || len(x.Refs) != 20 {
		t.Fatalf("量加重値: %+v", x)
	}
	if w.At(1199).Known || w.At(1261).Known {
		t.Fatal("正確でない端へfallbackした")
	}
	d := w.Delta5At(1500)
	if !d.Known || math.Abs(d.Value-(w.At(1500).Value-x.Value)) > 1e-10 {
		t.Fatal("5分差")
	}
	x.Refs[0].ID = "改変"
	if w.At(1200).Refs[0].ID == "改変" {
		t.Fatal("参照が外部から変更された")
	}
}

// TestVWMAUnknownRecovery は、未知を含む窓・量0・場resetを検査します。
//
// 引数: t(*testing.T)は検査管理。返り値: なし。自然資料は読みません。
func TestVWMAUnknownRecovery(t *testing.T) {
	for _, mode := range []string{"欠分", "不完全量", "価格未知量0", "全量0"} {
		w := NewVWMA()
		_ = w.StartSession("人工場", "人工限月")
		for n := 0; n < 45; n++ {
			m := trackerMinute(n, 100+float64(n), 1)
			if mode == "全量0" && n < 20 {
				m.Volume = 0
			}
			if n == 24 {
				switch mode {
				case "欠分":
					m.Missing = true
				case "不完全量":
					m.VolumeKnown = false
				case "価格未知量0":
					m.PriceKnown = false
					m.Volume = 0
				}
			}
			if e := w.Add(m); e != nil {
				t.Fatal(e)
			}
			if n == 19 && mode == "全量0" && w.Latest().Known {
				t.Fatal("全量0を既知平均にした")
			}
			if n == 24 && mode != "全量0" && (w.Latest().Known || w.Delta5At(m.End).Known) {
				t.Fatal("最新未知を古い既知で補った")
			}
			if n == 43 && mode != "全量0" && w.Latest().Known {
				t.Fatal("未知分が20分窓に残る")
			}
		}
		if !w.Latest().Known {
			t.Fatal("後の20連続分で回復しない")
		}
		_ = w.StartSession("人工場", "人工限月")
		if w.Latest().Known || w.At(2700).Known {
			t.Fatal("場resetが漏れた")
		}
	}
}

// TestVWMADeliveryReject は、未来配送・分の飛越・逆行を拒否することを検査します。
//
// 引数: t(*testing.T)は検査管理。返り値: なし。自然資料は読みません。
func TestVWMADeliveryReject(t *testing.T) {
	w := NewVWMA()
	_ = w.StartSession("人工場", "人工限月")
	m := trackerMinute(0, 100, 1)
	m.Stamp.Time = m.AvailableAt - 1
	if w.Add(m) == nil {
		t.Fatal("利用可能前の配送")
	}
	if e := w.Add(trackerMinute(0, 100, 1)); e != nil {
		t.Fatal(e)
	}
	if w.Add(trackerMinute(2, 100, 1)) == nil || w.Add(trackerMinute(0, 100, 1)) == nil {
		t.Fatal("非連続又は重複を許可")
	}
}
