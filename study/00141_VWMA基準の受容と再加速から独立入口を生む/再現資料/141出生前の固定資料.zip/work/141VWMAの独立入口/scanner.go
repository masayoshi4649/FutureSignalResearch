package vwmaentry141

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"io"
	"os"
	"reflect"
	"sync"
)

type SceneResult struct {
	Success          bool              `json:"success"`
	Session          string            `json:"session"`
	Contract         string            `json:"contract"`
	Start            float64           `json:"start"`
	End              float64           `json:"end"`
	ForceClose       float64           `json:"force_close"`
	EntryLimit       float64           `json:"entry_limit"`
	ExecutionEnd     float64           `json:"execution_end"`
	Raw              FileRef           `json:"raw"`
	ExpectedAccepted int64             `json:"expected_accepted"`
	ExpectedQuality  *Counts           `json:"expected_quality"`
	Counts           Counts            `json:"counts"`
	ActualSHA        string            `json:"actual_sha256"`
	StatBefore       map[string]int64  `json:"stat_before"`
	StatAfter        map[string]int64  `json:"stat_after"`
	RawPasses        int               `json:"raw_passes"`
	Events           []*Event          `json:"events"`
	Lifecycle        []Trace           `json:"lifecycle"`
	Stats            map[string]uint64 `json:"stats"`
	StageCounts      map[string]uint64 `json:"stage_counts"`
	CSVStats         CSVStats          `json:"csv_stats"`
}
type Result struct {
	Success         bool              `json:"success"`
	Trial           int               `json:"trial"`
	BackgroundSHA   string            `json:"background_sha256"`
	CSVManifestSHA  string            `json:"csv_manifest_sha256"`
	FinancialLabels bool              `json:"financial_labels_used"`
	Scenes          []SceneResult     `json:"scenes"`
	Summary         map[string]uint64 `json:"summary"`
}

// scan は一場のRawを一走査し、同原行の全背景/1分配送後に現在だけを判断します。
//
// 引数: scene(Scene)、bank(*rules.Bank)。返り値: SceneResult/errorは全状態/品質又は不一致です。
func scan(scene Scene, bank *rules.Bank) (SceneResult, error) {
	result := SceneResult{Session: scene.Session, Contract: scene.Contract, Start: scene.Start, End: scene.End, ForceClose: scene.ForceClose, Raw: scene.Raw, ExpectedAccepted: scene.ExpectedAccepted, ExpectedQuality: scene.ExpectedQuality, RawPasses: 1, ExecutionEnd: scene.End - 300}
	if e := bank.StartSession(scene.Session, scene.Contract); e != nil {
		return result, e
	}
	d, e := NewDetector(scene)
	if e != nil {
		return result, e
	}
	result.EntryLimit = d.limit()
	minutes, csvStats, e := loadCSV(scene)
	if e != nil {
		return result, e
	}
	f, e := os.Open(scene.Raw.Path)
	if e != nil {
		return result, e
	}
	defer f.Close()
	before, e := f.Stat()
	if e != nil {
		return result, e
	}
	result.StatBefore = statValue(before)
	if scene.Raw.Bytes > 0 && scene.Raw.Bytes != before.Size() {
		return result, fmt.Errorf("原板bytes差")
	}
	h := sha256.New()
	buffer := bufio.NewReader(io.TeeReader(f, h))
	header, e := buffer.Peek(2)
	if e != nil {
		return result, e
	}
	var reader io.Reader = buffer
	if header[0] == 0x1f && header[1] == 0x8b {
		z, e := gzip.NewReader(buffer)
		if e != nil {
			return result, e
		}
		defer z.Close()
		reader = z
	}
	scanner := bufio.NewScanner(reader)
	scanner.Buffer(make([]byte, 65536), 4<<20)
	previous, index, pubIndex, cursor := scene.Start, int64(0), 0, 0
	contracts := map[string]bool{}
	for scanner.Scan() {
		result.Counts.Lines++
		q, reason, next, err := decodeRow(scanner.Bytes(), result.Counts.Lines, index, scene, previous, &result.Counts, contracts)
		if err != nil {
			return result, err
		}
		previous = next
		if q == nil {
			if reason == "clock_missing" || reason == "clock_invalid" || reason == "backward_clock" {
				d.RejectClock(reason, result.Counts.Lines)
			}
			continue
		}
		if pubIndex < len(scene.Publications) && scene.Publications[pubIndex].Stamp.Index < int(q.Index) {
			return result, fmt.Errorf("背景配送原行通過")
		}
		for pubIndex < len(scene.Publications) && scene.Publications[pubIndex].Stamp.Index == int(q.Index) {
			p := scene.Publications[pubIndex]
			if p.Stamp.Time != q.Time || p.Stamp.Line != int(q.SourceLine) {
				return result, fmt.Errorf("背景stamp差")
			}
			if e = bank.Add(p); e != nil {
				return result, e
			}
			if e = d.AddBackground(p); e != nil {
				return result, e
			}
			pubIndex++
		}
		snapshot, err := bank.Current(rq(*q))
		if err != nil {
			return result, err
		}
		if e = d.Observe(snapshot, *q, deliverMinutes(minutes, &cursor, *q)); e != nil {
			return result, e
		}
		index++
	}
	if e = scanner.Err(); e != nil {
		return result, e
	}
	if _, e = io.Copy(io.Discard, buffer); e != nil {
		return result, e
	}
	result.ActualSHA = hex.EncodeToString(h.Sum(nil))
	after, e := f.Stat()
	if e != nil {
		return result, e
	}
	pathAfter, e := os.Stat(scene.Raw.Path)
	if e != nil {
		return result, e
	}
	result.StatAfter = statValue(after)
	if result.ActualSHA != scene.Raw.SHA256 || !os.SameFile(before, pathAfter) || before.Size() != after.Size() || !before.ModTime().Equal(after.ModTime()) || before.Size() != pathAfter.Size() || !before.ModTime().Equal(pathAfter.ModTime()) || !reflect.DeepEqual(result.Counts, *scene.ExpectedQuality) || result.Counts.Accepted != scene.ExpectedAccepted || pubIndex != len(scene.Publications) || len(contracts) != 1 || !contracts[scene.Contract] {
		return result, fmt.Errorf("Raw SHA/stat/11品質/限月/配送差:%s", scene.Session)
	}
	csvBody, e := os.ReadFile(scene.CSV.Path)
	if e != nil {
		return result, e
	}
	csvAfter, e := os.Stat(scene.CSV.Path)
	if e != nil {
		return result, e
	}
	if digest(csvBody) != scene.CSV.SHA256 || !reflect.DeepEqual(statValue(csvAfter), csvStats.StatBefore) {
		return result, fmt.Errorf("CSV走査後指紋差")
	}
	d.Finish()
	csvStats.Delivered = cursor
	csvStats.EOFUndelivered = len(minutes) - cursor
	csvStats.StatAfter = statValue(csvAfter)
	result.Events = d.Events
	result.Lifecycle = d.Lifecycle
	result.Stats = d.Stats
	result.StageCounts = d.StageCounts
	result.CSVStats = csvStats
	result.Success = true
	return result, nil
}

// Generate は同限月前史だけを再配送し、並列実行でも場順と出力順を固定します。
//
// 引数: scenes([]Scene)、workers(int)、all73(bool)。返り値: Result/error。falseは人工入力用です。
func Generate(scenes []Scene, workers int, all73 bool) (Result, error) {
	result := Result{Trial: 141, BackgroundSHA: BackgroundSHA, Scenes: make([]SceneResult, len(scenes)), Summary: map[string]uint64{}}
	if e := Validate(scenes, all73); e != nil {
		return result, e
	}
	if workers < 1 || workers > 16 {
		return result, fmt.Errorf("workersは1..16")
	}
	errs := make([]error, len(scenes))
	jobs := make(chan int)
	var wg sync.WaitGroup
	for n := 0; n < workers; n++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range jobs {
				bank := rules.NewBank()
				var err error
				for j := 0; j < i; j++ {
					if err = bank.StartSession(scenes[j].Session, scenes[j].Contract); err != nil {
						break
					}
					if err = bank.SeedFromPrior(scenes[j].Publications); err != nil {
						break
					}
				}
				if err == nil {
					result.Scenes[i], err = scan(scenes[i], bank)
				}
				errs[i] = err
			}
		}()
	}
	for i := range scenes {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	for i, scene := range result.Scenes {
		if errs[i] != nil {
			return result, fmt.Errorf("%s:%w", scenes[i].Session, errs[i])
		}
		result.Summary["場数"]++
		result.Summary["出生数"] += uint64(len(scene.Events))
		for _, e := range scene.Events {
			if e.Status == "filled" {
				result.Summary["取得数"]++
			} else {
				result.Summary["要求取消数"]++
			}
		}
		for k, n := range scene.StageCounts {
			result.Summary["stage/"+k] += n
		}
	}
	result.Success = true
	return result, nil
}
