"""141のCSV参照だけを、既に固定された73場の品質F0から用意する。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parent.parent
F0 = ROOT / 'work/全73場1分足の品質監査実行/F0.json'
METADATA = ROOT / 'inputs/00124_同入口正逆の共用入力/入力.json.gz'
OUTPUT = ROOT / 'work/141VWMA独立入口の評価/CSV73参照.json'


def sha(path: Path) -> str:
    """
    機能: 保存ファイルの指紋を求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 価格を解析せず、73CSVの由来と指紋を未作成先へ保存する。
    引数: なし。固定品質F0と124共用metadataを読む。
    返り値: None。追加2場は参照しない。
    """
    assert sha(F0) == '85dbb9c44bca26b3c5465b3652d6d801373f1bb75bd32c6d302dd0911f45529f'
    assert sha(METADATA) == '717f41674a4c99f94545a5e147495ae66498dbbc1afa48d7f34d04c40514843b'
    quality = json.loads(F0.read_bytes())
    common = json.loads(gzip.decompress(METADATA.read_bytes()))
    csv_files = {Path(name).parent.name: (Path(name), expected) for name, expected in quality['ファイル'].items()
                 if Path(name).name == 'candle_1min.csv'}
    assert len(csv_files) == len(common['scenes']) == 73
    scenes = []
    for scene in common['scenes']:
        path, expected = csv_files[scene['session']]
        assert sha(path) == expected
        scenes.append({'session': scene['session'], 'contract': scene['contract'],
                       'csv': {'path': str(path), 'sha256': expected, 'bytes': path.stat().st_size}})
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    with OUTPUT.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump({'success': True, 'trial': 141, 'quality_f0_sha256': sha(F0),
                   'quality_mask_used_for_online_decision': False, 'scenes': scenes},
                  stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'成功': True, 'CSV数': len(scenes), '出力': str(OUTPUT), 'SHA256': sha(OUTPUT)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
