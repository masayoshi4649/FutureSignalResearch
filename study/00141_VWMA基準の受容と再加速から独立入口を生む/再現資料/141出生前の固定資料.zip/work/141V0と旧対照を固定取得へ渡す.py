"""141の独立V0と固定C0を、金融を読まず133固定取得形式とunion参照へ渡す。"""
from pathlib import Path
import argparse
import copy
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parent.parent
COMMON = ROOT / 'inputs/00124_同入口正逆の共用入力/入力.json.gz'
OLD = ROOT / 'work/全成立poolの非金融manifest/manifest.json'
OLD_FIXED = ROOT / 'work/138全成立入口の評価/固定入力_版2/固定取得入力.json'
SHAS = {COMMON: '717f41674a4c99f94545a5e147495ae66498dbbc1afa48d7f34d04c40514843b',
        OLD: 'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35',
        OLD_FIXED: '0c83e525dec3079ce188d942069c0d137c94f39009339752ec8227ec9ecb4ce7'}
QUOTE_FIELDS = ('time', 'index', 'source_line', 'last', 'bid', 'ask', 'quote_ok', 'clock')


def sha(path: Path) -> str:
    """
    機能: 保存bytesの指紋を求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: UTF-8のJSONを未作成先だけへ保存する。
    引数: path(Path)、value(dict)は保存先と内容。
    返り値: None。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


# ----------------------------------------
def build(common: dict, controls: list[dict], source: dict) -> tuple[dict, dict]:
    """
    機能: 全取得を保持した基礎集合と、C0優先の同原行unionを組み立てる。
    引数: common(dict)、controls(list[dict])、source(dict)は場metadata、旧対照、新V0。
    返り値: tuple[dict,dict]は固定入力と入口参照。自然金融を参照しない。
    """
    assert source['success'] and source['trial'] == 141
    assert [s['session'] for s in source['scenes']] == [s['session'] for s in common['scenes']]
    output = {'scenes': [], 'expected_entry_count': 0}
    metadata = {'success': True, 'trial': 141, 'sessions': [s['session'] for s in common['scenes']],
                'entries': [], 'union': [], 'dedup_key': 'session/contract/取得time/index/source_line',
                'dedup_priority': 'C0', 'policies': ['U0', 'V0', 'C0', 'RV', 'RU'],
                'financial_labels_used': False, 'portfolio_replay': False}
    by_scene = {s['session']: [] for s in common['scenes']}
    for item in controls:
        sid = item['session']
        by_scene[sid].append({'id': 'C0/' + item['id'], 'session': sid, 'contract': item['contract'],
                            'model': 'C0', 'candidate_id': item['id'], 'native_side': item['side'],
                            'entry_quote': copy.deepcopy(item['entryQuote']), 'baseline': True,
                            'origins': copy.deepcopy(item['origins'])})
    for scene in source['scenes']:
        sid = scene['session']
        assert scene['success'] and scene['stat_before'] == scene['stat_after']
        spec = next(s for s in common['scenes'] if s['session'] == sid)
        assert scene['contract'] == spec['contract'] and scene['actual_sha256'] == spec['raw']['sha256']
        assert scene['counts'] == spec['expected_quality']
        for index, event in enumerate(scene['events']):
            if event['status'] != 'filled':
                continue
            assert event['side'] in (-1, 1)
            birth = event['birth']
            q = event['entryQuote']
            assert q['index'] > birth['index'] and q['source_line'] > birth['source_line'] and q['time'] >= birth['time'] + 1
            by_scene[sid].append({'id': 'V0/' + event['id'], 'session': sid, 'contract': scene['contract'],
                                'model': 'V0', 'candidate_id': event['id'], 'native_side': event['side'],
                                'entry_quote': copy.deepcopy(q), 'baseline': False,
                                'origins': [{'family': 'VWMA受容再加速', 'variant': 'V0',
                                             'source_locator': {'scene': sid, 'event_index': index},
                                             'birthQuote': copy.deepcopy(birth), 'episode_id': event['episode_id'],
                                             'trace': copy.deepcopy(event.get('trace'))}]})
    seen_ids = set()
    for original in common['scenes']:
        scene = copy.deepcopy(original)
        sid = scene['session']
        scene['entries'] = []
        basis = sorted(by_scene[sid], key=lambda e: (e['entry_quote']['index'], e['model'] != 'C0', e['id']))
        per_model = set()
        grouped = {}
        for item in basis:
            q = item['entry_quote']
            assert item['contract'] == scene['contract'] and item['native_side'] in (-1, 1)
            assert item['id'] not in seen_ids and set(QUOTE_FIELDS) <= set(q)
            assert q['clock'] and q['quote_ok'] and 0 < q['bid'] < q['ask'] and q['last'] > 0
            assert scene['start'] <= q['time'] < min(scene['force_close'], scene['end'] - 3900)
            stamp = (sid, item['contract'], q['time'], q['index'], q['source_line'])
            assert (item['model'], stamp) not in per_model, ('同family同原行重複', item['id'])
            per_model.add((item['model'], stamp)); seen_ids.add(item['id'])
            scene['entries'].append({'id': item['id'], 'side': item['native_side'], 'entry': copy.deepcopy(q)})
            metadata['entries'].append(item)
            grouped.setdefault(stamp, []).append(item)
        for stamp, items in grouped.items():
            chosen = next((e for e in items if e['model'] == 'C0'), items[0])
            assert all(all(e['entry_quote'][k] == chosen['entry_quote'][k] for k in QUOTE_FIELDS) for e in items)
            metadata['union'].append({'canonical_id': chosen['id'], 'alias_ids': [e['id'] for e in items],
                                      'session': sid, 'contract': scene['contract'],
                                      'entry_stamp': {'time': stamp[2], 'index': stamp[3], 'source_line': stamp[4]},
                                      'alias_sides': {e['id']: e['native_side'] for e in items}})
        output['scenes'].append(scene)
        output['expected_entry_count'] += len(basis)
    assert len(metadata['entries']) == output['expected_entry_count']
    return output, metadata


# ----------------------------------------
def main() -> None:
    """
    機能: Root固定F0と明示Source指紋を確認してから非金融転送を行う。
    引数: CLI --f0/--f0-sha256/--source/--sha256/--output-dir。
    返り値: None。旧81の取得Quoteと方向を照合し、新規結果を未作成先へ保存する。
    """
    parser = argparse.ArgumentParser(description='141の出生取得を正逆観測前に固定する')
    for key in ('f0', 'source', 'output-dir'):
        parser.add_argument('--' + key, type=Path, required=True)
    parser.add_argument('--f0-sha256', required=True)
    parser.add_argument('--sha256', required=True)
    args = parser.parse_args()
    assert sha(args.f0) == args.f0_sha256 and sha(args.source) == args.sha256
    frozen = json.loads(args.f0.read_bytes())
    assert frozen['成功'] and frozen['試行'] == 141
    for name, expected in frozen['ファイル'].items():
        assert sha(Path(name)) == expected, name
    for path, expected in SHAS.items():
        assert sha(path) == expected and frozen['ファイル'][str(path)] == expected, path
    assert frozen['ファイル'][str(Path(__file__).resolve())] == sha(Path(__file__).resolve())
    common = json.loads(gzip.decompress(COMMON.read_bytes()))
    controls = json.loads(OLD.read_bytes())['C0']
    source = json.loads(args.source.read_bytes())
    assert len(common['scenes']) == 73 and len(controls) == 81
    fixed, meta = build(common, controls, source)
    prior = json.loads(OLD_FIXED.read_bytes())
    old = {(s['session'], e['id']): e for s in prior['scenes'] for e in s['entries'] if e['id'].startswith('C0/')}
    current = {(s['session'], e['id']): e for s in fixed['scenes'] for e in s['entries'] if e['id'].startswith('C0/')}
    assert old == current and len(current) == 81
    for item in meta['entries']:
        if item['model'] == 'V0':
            item['origins'][0]['source_file_sha'] = args.sha256
    dest = args.output_dir
    dest.mkdir(parents=True, exist_ok=True)
    assert not any((dest / n).exists() for n in ('固定取得入力.json', '入口参照.json', '転送の確認.json'))
    save(dest / '固定取得入力.json', fixed)
    meta['fixed_input_sha256'] = sha(dest / '固定取得入力.json')
    meta['source_sha256'] = args.sha256
    meta['control_manifest_sha256'] = SHAS[OLD]
    save(dest / '入口参照.json', meta)
    for name, expected in frozen['ファイル'].items():
        assert sha(Path(name)) == expected, name
    counts = {model: sum(e['model'] == model for e in meta['entries']) for model in ('C0', 'V0')}
    save(dest / '転送の確認.json', {'成功': True, '試行': 141, 'F0_SHA256': args.f0_sha256,
         'Source_SHA256': args.sha256, '基礎集合': counts, 'union件数': len(meta['union']),
         '同原行alias除去数': len(meta['entries'])-len(meta['union']), '旧81同体': True,
         '金融参照': False, '固定入力SHA256': meta['fixed_input_sha256'], '入口参照SHA256': sha(dest / '入口参照.json')})
    print(json.dumps({'成功': True, '基礎集合': counts, 'union件数': len(meta['union']), '旧81同体': True}, ensure_ascii=False))


if __name__ == '__main__':
    main()
