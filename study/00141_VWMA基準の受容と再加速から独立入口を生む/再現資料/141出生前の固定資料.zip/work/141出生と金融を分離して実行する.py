"""141の自然出生・固定取得・金融を順に固定して実行するRoot運転部。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT / 'work/141VWMA独立入口の評価'
GEN = ROOT / 'work/141VWMAの独立入口'
AGG = ROOT / 'work/141独立入口とunionの集計'
FORMAL = ROOT / 'study/00141_VWMA基準の受容と再加速から独立入口を生む'
BACKGROUND = ROOT / 'work/122全場入力/入力.json'
BACKGROUND_SHA = '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
MANIFEST = OWN / 'CSV73参照.json'
MANIFEST_SHA = '07e136e2b77a0029ddacd955abad16a9240373fa849ec96b553c2875e1e85147'
ADOPTED = ROOT / 'work/141_VWMA独立入口の採用仕様.md'
BRIDGE = ROOT / 'work/141V0と旧対照を固定取得へ渡す.py'
SOURCE = OWN / 'V0の出生と取得.json'
FIXED = OWN / '固定入力/固定取得入力.json'
META = OWN / '固定入力/入口参照.json'
PAIRED = OWN / '固定取得の正逆観測.json'
KERNEL = ROOT / 'work/133固定取得の正逆評価器/固定取得の正逆評価.exe'


def sha(path: Path) -> str:
    """
    機能: 保存bytesの指紋を計算する。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def module(path: Path, name: str) -> object:
    """
    機能: mainを呼ばず依存宣言と固定用関数を私有読込する。
    引数: path(Path)、name(str)はファイルと内部名。
    返り値: objectはモジュール。
    """
    previous = list(sys.path)
    try:
        sys.path.insert(0, str(path.parent))
        spec = importlib.util.spec_from_file_location(name, path)
        result = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(result)
        return result
    finally:
        sys.path[:] = previous


# ----------------------------------------
def main() -> None:
    """
    機能: 各固定境界を検査し、自然生成と金融を分離して一段階だけ実行する。
    引数: CLI --mode(str)は固定/出生/転送/金融前/観測/集計。
    返り値: None。既存出力は上書きしない。
    """
    parser = argparse.ArgumentParser(description='141の自然生成と金融を分離する')
    parser.add_argument('--mode', required=True, choices=('固定', '出生', '転送', '金融前', '観測', '集計'))
    args = parser.parse_args()
    helper = module(ROOT / 'work/133金融前を固定して実行する.py', '141の固定補助')
    f0, f1 = OWN / 'F0出生前.json', OWN / 'F1金融前.json'
    if args.mode == '固定':
        assert sha(BACKGROUND) == BACKGROUND_SHA and sha(MANIFEST) == MANIFEST_SHA
        assert sha(KERNEL) == '033cf22a052e985bc61aa020a04fa6d499119051aaa39bb2adb715a4af1e7736'
        proof = json.loads((GEN / '準備の確認.json').read_bytes())
        assert proof['成功']
        for source in proof['源']:
            path = Path(source['path'])
            assert sha(path) == source['sha256'] and path.stat().st_size == source['bytes'], path
        review = ROOT / 'work/141窓と転送の独立準備レビュー/Source最終の確認.json'
        assert json.loads(review.read_bytes())['成功']
        bridge = module(BRIDGE, '141の転送宣言')
        files = {Path(__file__).resolve(), ADOPTED, BACKGROUND, MANIFEST, BRIDGE, KERNEL, review,
                 ROOT / 'work/141転送の人工検査.py', ROOT / 'work/141入力を準備する.py',
                 ROOT / 'work/133金融前を固定して実行する.py'}
        for path, expected in bridge.SHAS.items():
            assert sha(path) == expected, path
            files.add(path)
        for folder in (GEN, FORMAL, ROOT / 'work/118複数技法の入口条件'):
            assert folder.is_dir(), folder
            files.update(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.go', '.mod', '.py', '.md', '.json', '.exe'))
        refs = json.loads(MANIFEST.read_bytes())
        assert len(refs['scenes']) == 73 and refs['quality_mask_used_for_online_decision'] is False
        for scene in refs['scenes']:
            path = Path(scene['csv']['path'])
            assert sha(path) == scene['csv']['sha256'] and path.stat().st_size == scene['csv']['bytes']
            files.add(path)
        for name in ('README.md', '条件.md', '設定と結果.md'):
            assert (FORMAL / name).is_file()
        helper.save(f0, {'成功': True, '試行': 141, '段階': '自然出生前F0', 'UTC': datetime.now(timezone.utc).isoformat(),
            '主': '独立VWMA受容再加速V0と旧81C0のU0 union', '政策': ['U0', 'V0', 'C0', 'RV', 'RU'],
            '追加2場未読': True, '既知73場のみ': True, '全場回数均等化': False,
            'ファイル': {str(p): sha(p) for p in sorted(files)}})
        print(json.dumps({'F0_SHA256': sha(f0), '固定源数': len(files)}, ensure_ascii=False))
        return
    frozen = json.loads(f0.read_bytes())
    helper.verify(frozen)
    if args.mode == '出生':
        assert not SOURCE.exists()
        command = [str(GEN / 'V0独立生成.exe'), '--input', str(BACKGROUND), '--sha256', BACKGROUND_SHA,
            '--csv-manifest', str(MANIFEST), '--csv-manifest-sha256', MANIFEST_SHA,
            '--output', str(SOURCE), '--workers', '8', '--execute-after-f0']
    elif args.mode == '転送':
        command = [sys.executable, '-X', 'utf8', str(BRIDGE), '--f0', str(f0), '--f0-sha256', sha(f0),
            '--source', str(SOURCE), '--sha256', sha(SOURCE), '--output-dir', str(FIXED.parent)]
    elif args.mode == '金融前':
        declared = module(AGG / '集計する.py', '141の金融依存宣言')
        files = {Path(p) for p in frozen['ファイル']} | {f0, SOURCE, FIXED, META, FIXED.parent / '転送の確認.json',
                 ROOT / 'work/141金融集計を独立に確認する.py'}
        for path, expected in declared.SOURCES.items():
            assert sha(path) == expected, path
            files.add(path)
        files.update(p for p in AGG.rglob('*') if p.is_file() and p.suffix in ('.py', '.json', '.md'))
        helper.save(f1, {'成功': True, '試行': 141, '段階': '金融前F1', 'UTC': datetime.now(timezone.utc).isoformat(),
            'F0_SHA256': sha(f0), '主政策': 'U0', '主幅': 125, '主秒': 3600, '主価格': 'BBO',
            '金融結果から入口を変更': False, 'ファイル': {str(p): sha(p) for p in sorted(files)}})
        print(json.dumps({'F1_SHA256': sha(f1), '固定源数': len(files)}, ensure_ascii=False))
        return
    else:
        finance = json.loads(f1.read_bytes()); helper.verify(finance)
        if args.mode == '観測':
            assert not PAIRED.exists()
            command = [str(KERNEL), '--input', str(FIXED), '--sha256', sha(FIXED), '--output', str(PAIRED), '--workers', '8']
        else:
            command = [sys.executable, '-X', 'utf8', str(AGG / '集計する.py'), '--f1', str(f1), '--f1-sha256', sha(f1),
                '--fixed-input', str(FIXED), '--fixed-input-sha256', sha(FIXED), '--metadata', str(META), '--metadata-sha256', sha(META),
                '--result', str(PAIRED), '--result-sha256', sha(PAIRED), '--output-dir', str(OWN / '金融評価')]
    subprocess.run(command, cwd=ROOT, check=True)
    helper.verify(frozen)
    if args.mode in ('観測', '集計'):
        helper.verify(finance)
    if args.mode == '観測':
        helper.verify_result(json.loads(PAIRED.read_bytes()), json.loads(FIXED.read_bytes()))
    helper.save(OWN / (args.mode + 'の完了.json'), {'成功': True, '試行': 141, '段階': args.mode,
        'F0_SHA256': sha(f0), '全固定源前後同体': True, '実行列': command})


if __name__ == '__main__':
    main()
