"""141 F1原文と固定取得/Sourceを保存し、大観測の重複保存を避ける。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00141_*'))
RUN=ROOT/'work/141VWMA独立入口の評価'


def sha(raw: bytes) -> str:
    """
    機能: 原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def save(source: Path,target: Path,packed: bool=False) -> dict:
    """
    機能: 未作成先へ原文又はgzipを保存する。
    引数: source/target(Path)、packed(bool)。
    返り値: dictは復元先と保存/解凍指紋。
    """
    raw=source.read_bytes();body=gzip.compress(raw,mtime=0) if packed else raw
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as f:f.write(body)
    return {'保存元':target.relative_to(ROOT).as_posix(),'復元先':source.relative_to(ROOT).as_posix(),'形式':'gzip' if packed else '同体',
        '保存bytes':len(body),'保存SHA256':sha(body),'解凍bytes':len(raw),'解凍SHA256':sha(raw)}


# ----------------------------------------
def main() -> None:
    """
    機能: F1増分15源を保存/共有へ結び、Sourceと固定入力を各一度保存する。
    引数: なし。
    返り値: None。金融結果/Raw/価格CSV/177MBは読まず、固定源を変更しない。
    """
    f1raw=(RUN/'F1金融前.json').read_bytes();assert sha(f1raw)=='0602d5e3653d3981f11819d623376b64be0dea9d06e636aeba0abbac3c958f02'
    f1=json.loads(f1raw);f0=json.loads((FORMAL/'検査/F0出生前.json').read_bytes())
    assert len(f1['ファイル'])==127 and all(f1['ファイル'][n]==h for n,h in f0['ファイル'].items())
    save(RUN/'F1金融前.json',FORMAL/'検査/F1金融前.json')
    docs=[]
    for name,h in f1['ファイル'].items():
        p=Path(name)
        if p.suffix=='.md':
            body=p.read_bytes();assert sha(body)==h
            docs.append({'path':p.relative_to(ROOT).as_posix(),'sha256':h,'bytes':len(body),'本文':body.decode('utf-8')})
    snap={'試行':141,'段階':'金融前F1原文の正式編集前退避','F1_SHA256':sha(f1raw),'文書数':len(docs),'正式文書数':sum(x['path'].startswith('study/') for x in docs),'文書':docs,'事前固定の後造り':False}
    with (FORMAL/'検査/F1実行前文書.json.gz').open('xb') as f:f.write(gzip.compress((json.dumps(snap,ensure_ascii=False,indent=2)+'\n').encode('utf-8'),mtime=0))
    assert snap['正式文書数']==3
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes())
    additions=[]
    for source,name in [(RUN/'V0の出生と取得.json','V0の出生と取得.json.gz'),(RUN/'固定入力/固定取得入力.json','固定取得入力.json.gz'),(RUN/'固定入力/入口参照.json','入口参照.json.gz')]:
        assert sha(source.read_bytes())==f1['ファイル'][str(source)]
        additions.append(save(source,ROOT/'inputs/00141_VWMA独立入口'/name,True))
    fixedrefs={x['復元先']:x for x in additions}
    f0item={'保存元':(FORMAL/'検査/F0出生前.json').relative_to(ROOT).as_posix(),'復元先':'work/141VWMA独立入口の評価/F0出生前.json','形式':'同体',
        '保存bytes':(FORMAL/'検査/F0出生前.json').stat().st_size,'保存SHA256':m['F0_SHA256'],'解凍bytes':(FORMAL/'検査/F0出生前.json').stat().st_size,'解凍SHA256':m['F0_SHA256']}
    transfer=save(RUN/'固定入力/転送の確認.json',FORMAL/'検査/転送の確認.json');fixedrefs[transfer['復元先']]=transfer;fixedrefs[f0item['復元先']]=f0item
    prior138=next((ROOT/'study').glob('00138_*'));m138=json.loads((prior138/'保管索引.json').read_bytes())
    by_restore={x['復元先']:x for x in m138['共有入力']}
    groups=[];registry={}
    for folder,item in [(next((ROOT/'study').glob('00133_*')),json.loads(next((ROOT/'study').glob('00133_*/保管索引.json')).read_bytes())['固定コード']),
        (prior138,m138['追加固定資料']),(FORMAL,m['出生後段の準備資料'])]:
        path=folder/'再現資料'/item['ZIP'];assert sha(path.read_bytes())==item['ZIP_SHA256'];at=len(groups)
        groups.append({'保存元ZIP':path.relative_to(ROOT).as_posix(),'ZIP_SHA256':item['ZIP_SHA256'],'格納源':[]})
        for x in item['格納源']:registry[x['sha256']]=(at,x['path'])
    inputs=[];new=[];bodies={};shared=[]
    for name,h in f1['ファイル'].items():
        if name in f0['ファイル']:continue
        p=Path(name);rel=p.relative_to(ROOT).as_posix()
        if rel in fixedrefs:assert fixedrefs[rel]['解凍SHA256']==h;inputs.append(fixedrefs[rel]);continue
        if rel in by_restore:assert by_restore[rel]['解凍SHA256']==h;shared.append(by_restore[rel]);continue
        body=p.read_bytes();assert sha(body)==h and len(body)<1_000_000
        if h in registry:
            at,entry=registry[h];groups[at]['格納源'].append({'復元先':rel,'ZIP内path':entry,'sha256':h,'bytes':len(body)})
        else:new.append({'path':rel,'sha256':h,'bytes':len(body)});bodies[rel]=body
    assert len(inputs)+len(shared)+len(new)+sum(len(g['格納源']) for g in groups)==15
    archive=FORMAL/'再現資料/141金融前の追加固定資料.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for x in new:z.writestr(x['path'],bodies[x['path']])
    for g in groups:g['格納源数']=len(g['格納源'])
    m.update({'F1_SHA256':sha(f1raw),'F1直接源数':127,'F1増分源数':15,'F1増分固定資料':{'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(new),'格納源':new},
        'F1共有コード':groups,'F1共有入力':shared,'F1追加入力':inputs,'段階':'F0/F1原文・Source/固定取得の恒久保存。金融結果は未保存/未追記',
        'Source既報':'Root通知でV0出生0/取得0。保存だけ行い、本工程では内容を解析しない'})
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    proof={'成功':True,'試行':141,'F1原文/全MD先退避':True,'全MD':len(docs),'正式MD':3,'Source/固定入力/metadata各1gzip':True,
        '増分15源を保存/共有へ解決':True,'旧大観測を再保存':False,'金融結果/Raw/CSV価格/177MB本文読取':False,
        'F0/F1対象源の変更':False,'Source保存bytes':additions[0]['保存bytes'],'SourcegzipSHA256':additions[0]['保存SHA256'],
        'F1追加ZIP_SHA256':sha(archive.read_bytes()),'保管索引SHA256':sha(mpath.read_bytes()),'重大不足':[]}
    p=FORMAL/'検査/F1原文と増分の保管確認.json';p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'F1保管確認SHA256':sha(p.read_bytes()),'Sourcegzipbytes':additions[0]['保存bytes'],'SourcegzipSHA256':additions[0]['保存SHA256'],'F1追加ZIP_SHA256':sha(archive.read_bytes())},ensure_ascii=False))


if __name__=='__main__':main()
