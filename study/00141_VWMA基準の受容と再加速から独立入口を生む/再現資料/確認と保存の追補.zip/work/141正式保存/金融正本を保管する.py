"""141の確定済み金融/CSV/独立/Source原因を最小保存する。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00141_*'))
RUN=ROOT/'work/141VWMA独立入口の評価'


def sha(raw: bytes) -> str:
    """
    機能: 原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def save(source: Path,target: Path,packed: bool=False) -> dict:
    """
    機能: 未作成先へ同体又はgzip正本を保存する。
    引数: source/target(Path)、packed(bool)。
    返り値: dictは復元と保存の指紋。
    """
    raw=source.read_bytes();body=gzip.compress(raw,mtime=0) if packed else raw;target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as f:f.write(body)
    return {'保存元':target.relative_to(ROOT).as_posix(),'復元先':source.relative_to(ROOT).as_posix(),'形式':'gzip' if packed else '同体',
        '保存bytes':len(body),'保存SHA256':sha(body),'解凍bytes':len(raw),'解凍SHA256':sha(raw)}


# ----------------------------------------
def main() -> None:
    """
    機能: 正本と停止済み証跡を保存し再現索引へ結ぶ。
    引数: なし。
    返り値: None。Raw/CSV価格/新Source/新観測は生成せず固定源を変更しない。
    """
    assert sha((RUN/'金融評価/集計.json').read_bytes())=='0d1ff05a9893df786a9bc1d7478508fd4d263dc936865efee62ee7c812c44ec3'
    assert sha((RUN/'固定取得の正逆観測.json').read_bytes())=='63a2ccb58454fbdecd0df8be7e4e7758e6ee21230846e6c654b1fbe2544b0e41'
    aggregate=save(RUN/'金融評価/集計.json',FORMAL/'成果物/集計.json')
    observed=save(RUN/'固定取得の正逆観測.json',FORMAL/'成果物/固定取得の正逆観測.json.gz',True)
    proof_paths=[]
    for name in ('出生の完了.json','転送の完了.json','観測の完了.json','集計の完了.json','金融集計の独立確認.json','CSV全セルの独立再読.json'):
        proof_paths.append(save(RUN/name,FORMAL/'検査'/name))
    proof_paths.append(save(RUN/'金融評価/集計完了.json',FORMAL/'検査/集計器の完了.json'))
    csv=ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/141_VWMA独立入口'
    proof_paths.append(save(csv/'CSVの確認.json',FORMAL/'検査/CSV作成の確認.json'))
    source=ROOT/'work/141出生取得とunionの独立照合'
    assert sha((source/'独立照合.json').read_bytes())=='c74befa7cd849575f4ac79ee8ffaeb7e95d7bb514bc73fbc9d21e7d4d5107ad6'
    assert sha((source/'停止の確認.json').read_bytes())=='f8da4a005e96056a6dbdcbbab418fd67631b4107d33fd85fd77d372042b06f11'
    for n in ('独立照合.json','停止の確認.json'):proof_paths.append(save(source/n,FORMAL/'検査/Source独立'/n))
    cause=ROOT/'work/141出生前の取消と取得時計の診断'
    proof_paths.append(save(cause/'診断の確認.json',FORMAL/'検査/Source原因の確認.json'))
    cause_data=save(cause/'全取消と再加速7件.json',FORMAL/'根拠/全取消と再加速7件.json.gz',True)
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes());m.update({'集計正本':aggregate,'保存済み正逆観測':observed,'自然後の小型証跡':proof_paths,
        'Source原因票':cause_data,'CSV正本':csv.relative_to(ROOT).as_posix(),'表JSON再現期待SHA256':'a3ac697504155e5ba60bc674e6b68bd8ea3b0117fc74bb60dece8c45a4087ab4',
        '段階':'金融/独立/CSVの正本保存。正式結果更新と再現/最終停止を準備','Source独立照合SHA256':'c74befa7cd849575f4ac79ee8ffaeb7e95d7bb514bc73fbc9d21e7d4d5107ad6'})
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'観測gzipSHA256':observed['保存SHA256'],'集計SHA256':aggregate['解凍SHA256'],'証跡数':len(proof_paths),'原因gzipSHA256':cause_data['保存SHA256']},ensure_ascii=False))


if __name__=='__main__':main()
