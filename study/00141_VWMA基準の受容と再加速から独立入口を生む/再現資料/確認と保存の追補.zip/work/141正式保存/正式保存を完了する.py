"""141の後発証跡を保存し、原文/513セル/正本/再現/索引だけを最終確認する。"""
from pathlib import Path
import gzip
import hashlib
import json
import re
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00141_*'))


def sha(raw: bytes) -> str:
    """
    機能: 原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def cells(body: str) -> list:
    """
    機能: 57手法9尺度の設定だけを抽出する。
    引数: body(str)。
    返り値: listはIDと513セル。
    """
    rows=[]
    for line in body.splitlines():
        if re.match(r'^\| [A-Z]+\d{2} \|',line):
            row=[x.strip() for x in line.strip('|').split('|')]
            if len(row)==11:rows.append([row[0],row[2:]])
    assert len(rows)==57 and sum(len(x[1]) for x in rows)==513
    return rows


# ----------------------------------------
def main() -> None:
    """
    機能: 停止済み小成果を追加保管し、保存済み検査の範囲で正式保存を閉じる。
    引数: なし。
    返り値: None。新検証/自然再生/CSV生成/142操作/旧140変更をしない。
    """
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes())
    registry={};prior140=next((ROOT/'study').glob('00140_*'));m140=json.loads((prior140/'保管索引.json').read_bytes())
    groups=[]
    for folder,item in [(FORMAL,m['追加固定資料']),(FORMAL,m['出生後段の準備資料']),(FORMAL,m['F1増分固定資料']),(prior140,m140['後発資料'])]:
        archive=folder/'再現資料'/item['ZIP'];assert sha(archive.read_bytes())==item['ZIP_SHA256'];at=len(groups)
        groups.append({'保存元ZIP':archive.relative_to(ROOT).as_posix(),'ZIP_SHA256':item['ZIP_SHA256'],'格納源':[]})
        for entry in item['格納源']:registry.setdefault(entry['sha256'],(at,entry['path']))
    files=list((ROOT/'work/141正式保存').glob('*.py'))+list((FORMAL/'再現資料').glob('*.py'))
    files += [ROOT/'work/141出生前の取消と取得時計の診断'/n for n in ('原因と次の問い.md','診断する.py')]
    independent=ROOT/'work/141出生取得とunionの独立照合';stop=json.loads((independent/'停止の確認.json').read_bytes())
    for name,h in stop['保存対象'].items():
        p=independent/name;assert sha(p.read_bytes())==h
        if name!='独立照合.json':files.append(p)
    files += [ROOT/'work/確定三表のCSV出力_版2'/n for n in ('出力する.mjs','CSVを独立再読する.py')]
    new=[];bodies={}
    for p in sorted(set(files)):
        raw=p.read_bytes();h=sha(raw);rel=p.relative_to(ROOT).as_posix();assert len(raw)<1_000_000
        if h in registry:
            at,entry=registry[h];groups[at]['格納源'].append({'復元先':rel,'ZIP内path':entry,'sha256':h,'bytes':len(raw)})
        else:new.append({'path':rel,'sha256':h,'bytes':len(raw),'区分':'F0/F1直接源外の独立・原因・CSV作者v2・保存/復元'});bodies[rel]=raw
    archive=FORMAL/'再現資料/確認と保存の追補.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for item in new:z.writestr(item['path'],bodies[item['path']])
    for g in groups:g['格納源数']=len(g['格納源'])
    m['後発資料']={'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(new),'格納源':new}
    m['後発共有コード']=groups
    m['段階']='Source/金融/Source独立/金融独立/CSV/保存観測再現/正式保存完了。V0未評価、U0は70%/頻度未達、編集停止'
    m['保存観測再現SHA256']='6d6954a0252926e269c97320736240e19ecb82da43c0af334878d107b3673593'
    m['Source独立停止SHA256']='f8da4a005e96056a6dbdcbbab418fd67631b4107d33fd85fd77d372042b06f11'
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    # ----------------------------------------
    for phase in ('F0','F1'):
        snapshot=json.loads(gzip.decompress((FORMAL/f'検査/{phase}実行前文書.json.gz').read_bytes()))
        assert snapshot['正式文書数']==3
        for item in snapshot['文書']:assert sha(item['本文'].encode('utf-8'))==item['sha256']
        original={Path(item['path']).name:item['本文'] for item in snapshot['文書'] if item['path'].startswith('study/')}
        assert cells(original['設定と結果.md'])==cells((FORMAL/'設定と結果.md').read_text('utf-8'))
        condition=original['条件.md'].encode('utf-8');assert (FORMAL/'条件.md').read_bytes().startswith(condition)
    assert sha((FORMAL/'検査/F0出生前.json').read_bytes())==m['F0_SHA256']
    assert sha((FORMAL/'検査/F1金融前.json').read_bytes())==m['F1_SHA256']
    for item in [m['追加固定資料'],m['出生後段の準備資料'],m['F1増分固定資料'],m['後発資料']]+[m['共有固定コード'],m['kernel共有源']]+m['F1共有コード']+groups:
        p=ROOT/item['保存元ZIP'] if '保存元ZIP' in item else FORMAL/'再現資料'/item['ZIP'];assert sha(p.read_bytes())==item['ZIP_SHA256']
        with zipfile.ZipFile(p) as z:
            assert z.testzip() is None
            for entry in item['格納源']:assert sha(z.read(entry.get('ZIP内path',entry.get('path'))))==entry['sha256']
    for item in m['共有入力']+m['新共用入力']+m['F1追加入力']+m['F1共有入力']+[m['保存済み正逆観測'],m['集計正本'],m['Source原因票']]:
        raw=(ROOT/item['保存元']).read_bytes();assert sha(raw)==item['保存SHA256']
        decoded=gzip.decompress(raw) if item['形式']=='gzip' else raw;assert sha(decoded)==item['解凍SHA256']
    assert sha((FORMAL/'検査/金融集計の独立確認.json').read_bytes())=='67fc5bdc7ef98459c60a42621e4cfb1867222af6ce176c4a79128824657479c3'
    assert sha((FORMAL/'検査/Source独立/独立照合.json').read_bytes())=='c74befa7cd849575f4ac79ee8ffaeb7e95d7bb514bc73fbc9d21e7d4d5107ad6'
    assert sha((FORMAL/'検査/Source独立/停止の確認.json').read_bytes())==m['Source独立停止SHA256']
    assert sha((FORMAL/'検査/保存観測の再現確認.json').read_bytes())==m['保存観測再現SHA256']
    csv=json.loads((FORMAL/'検査/CSV全セルの独立再読.json').read_bytes());assert csv['全データセル比較数']==19709 and csv['数値比較数']==11796
    for item in csv['表別']:
        path=ROOT/m['CSV正本']/Path(item['CSV']['path']).name;assert sha(path.read_bytes())==item['CSV']['sha256']
    creator=json.loads((FORMAL/'検査/CSV作成の確認.json').read_bytes());assert creator['コードSHA256']=='0994706575ed4fc634fe5d0577d48b5b79e95ff0db2330407daf02a74ca478d3'
    for name in creator['プレビュー']:assert (ROOT/m['CSV正本']/name).exists()
    aggregate=json.loads((FORMAL/'成果物/集計.json').read_bytes());primary=aggregate['集計']['all']['U0']['BBO']['3600']['125'];newcase=aggregate['集計']['all']['V0']['BBO']['3600']['125']
    assert primary==aggregate['集計']['all']['C0']['BBO']['3600']['125']
    assert [primary[k] for k in ('entries','forward','adverse','neither','censored','ifd_net5_profit','ifd_net5_loss','ifd_net5_sum')]==[81,40,18,17,6,518227,318233,199994]
    assert newcase['entries']==0 and newcase['resolved_rate'] is None and newcase['ifd_net5_sum'] is None
    # ----------------------------------------
    indices=[ROOT/n for n in ('README.md','study/README.md','docs/README.md','docs/議論/README.md')];links=0
    for p in list(FORMAL.rglob('*.md'))+[ROOT/m['CSV正本']/'README.md']+indices:
        body=p.read_text('utf-8')
        if p in indices:assert '[141：' in body;body=body.split('\n\n',2)[1]
        for target in re.findall(r'\]\(([^)]+)\)',body):
            if target.startswith(('http:','https:','#')):continue
            assert (p.parent/target.strip('<>').split('#',1)[0]).resolve().exists(),(p,target);links+=1
    proof={'成功':True,'試行':141,'正式保存完了':True,'編集停止':True,'F0/F1原文正式3MD先退避':True,'元条件本文/57x9_513セル不変':True,
        '条件への変更は金融後の結果案内末尾だけ':True,'Sourceと固定入力各一度gzip/旧大観測共有':True,'CSV73/177MB/2exe非複製':True,
        'F0小型36/F1Source含む51源同体復元':True,'Source独立73場/689episode/旧81/union一致':True,'Source検査器schema2追補を履歴保存':True,
        '金融独立300比較7200統計セル一致':True,'CSV19709セル11796数値再読/Root三画像視認通知':True,'作者v2は説明文だけの変更':True,
        '保存観測から全300/三表JSONbytes再現':True,'V0出生取得0/率PnLはnull未評価':True,'U0はC0同体/頻度70未達':True,
        'b7全てClose時cap外/頻度上限は算術で新再生ではない':True,'新自然/金融観測/CSV再生成/142操作/140以前変更/追加2場読取':False,
        '4索引更新':True,'ローカルリンク':links,'重大不足':[],'主U0':primary,'F0_SHA256':m['F0_SHA256'],'F1_SHA256':m['F1_SHA256'],
        '保管索引SHA256':sha(mpath.read_bytes()),'追補ZIP_SHA256':m['後発資料']['ZIP_SHA256'],'Source独立SHA256':m['Source独立照合SHA256'],
        '金融独立SHA256':'67fc5bdc7ef98459c60a42621e4cfb1867222af6ce176c4a79128824657479c3','再現SHA256':m['保存観測再現SHA256'],'コードSHA256':sha(Path(__file__).read_bytes())}
    p=FORMAL/'検査/正式保存の最終確認.json';assert not p.exists();p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'最終確認SHA256':sha(p.read_bytes()),'保管索引SHA256':sha(mpath.read_bytes()),'追補ZIP_SHA256':m['後発資料']['ZIP_SHA256'],'重大不足':[]},ensure_ascii=False))


if __name__=='__main__':main()
