"""固定Sourceの遷移証跡だけを集計する非金融診断。原板や先着結果を読みません。"""

import collections
import hashlib
import json
import pathlib

SOURCE = pathlib.Path("work/141VWMA独立入口の評価/V0の出生と取得.json")
EXPECTED = "81f7c380f47b06952eaa4a8eae8f4b3821c49361fafe1afd93ef3367a23de40b"
OUT = pathlib.Path(__file__).resolve().parent


def sha(body):
    """機能: bytesの指紋を返す。引数: body(bytes)。返り値: str。"""
    return hashlib.sha256(body).hexdigest()


def geometry(side, quote, k, cap, invalidation, atr):
    """機能: 保存Quoteの符号付き距離を独立計算。引数: side(int)、quote(dict)、価格(float)。返り値: dict。"""
    price = quote["ask"] if side == 1 else quote["bid"]
    risk = side * (price - invalidation)
    maximum = min(125, 1.5 * atr)
    return {
        "quote": quote,
        "entry_side_price": price,
        "signed_last_from_K": side * (quote["last"] - k),
        "signed_price_from_K": side * (price - k),
        "signed_last_beyond_cap": side * (quote["last"] - cap),
        "signed_price_beyond_cap": side * (price - cap),
        "last_K_pass": side * (quote["last"] - k) >= 0,
        "price_K_pass": side * (price - k) >= 0,
        "last_cap_pass": side * (quote["last"] - cap) <= 0,
        "price_cap_pass": side * (price - cap) <= 0,
        "risk": risk,
        "risk_max": maximum,
        "risk_pass": 10 <= risk <= maximum,
        "normal_bbo": quote["quote_ok"] and 0 < quote["bid"] < quote["ask"],
        "spread": quote["ask"] - quote["bid"],
    }


def failure_roles(assessment):
    """機能: 背景不成立を既定論理の役割へ分ける。引数: assessment(dict)。返り値: list[str]。重複を許す。"""
    m = assessment["masks"]
    roles = []
    if not all(m[f"frame_{w}_fresh_price"] for w in (300, 900, 1800)):
        roles.append("三尺度価格又は鮮度")
    if not m["long_pass"]:
        roles.append("30分EMA増分")
    if not m["di_pass"]:
        roles.append("15分DI方向")
    if not (m["adx_level_pass"] or m["adx_delta_pass"]):
        roles.append("15分ADX水準又は増分")
    if not (m["hist_level_pass"] or m["hist_delta_pass"]):
        roles.append("5分Hist水準又は増分")
    if not m["atr_tr_pass"]:
        roles.append("5分ATRとTR")
    if not m["latest_w_direction"]:
        roles.append("最新VWMA又は5分差")
    return roles


def run():
    """機能: 全689取消とb7の保存当時値を射影。引数: なし。返り値: dict。新しい取得/金融を計算しない。"""
    before_stat = SOURCE.stat()
    body = SOURCE.read_bytes()
    assert sha(body) == EXPECTED
    source = json.loads(body)
    assert source["success"] and source["trial"] == 141 and not source["financial_labels_used"]
    assert len(source["scenes"]) == 73
    stages = collections.Counter()
    phases = collections.Counter()
    reasons = collections.Counter()
    role_counts = collections.Counter()
    cancellations = []
    cases = []
    minutes = 0
    sessions = []
    for scene in source["scenes"]:
        assert scene["success"] and not scene["events"]
        minutes += scene["csv_stats"]["grid_minutes"]
        grouped = collections.defaultdict(list)
        for trace in scene["lifecycle"]:
            stages[trace["stage"]] += 1
            grouped[trace["episode_id"]].append(trace)
        session_reasons = collections.Counter()
        for episode, traces in grouped.items():
            cancel = [x for x in traces if x["stage"] == "取消"]
            assert len(cancel) == 1
            cancel = cancel[0]
            phase, reason = cancel["fields"]["phase"], cancel["reason"]
            phases[phase] += 1
            reasons[(phase, reason)] += 1
            session_reasons[reason] += 1
            failed = None
            if reason == "background_or_latest_w_unknown_or_denied":
                a = [x for x in traces if x["stage"] == "現在背景検査"][-1]["fields"]["background"]
                assert not a["pass"]
                failed = failure_roles(a)
                role_counts.update(failed)
            cancellations.append({"session": scene["session"], "contract": scene["contract"], "episode_id": episode,
                                  "side": cancel["side"], "phase": phase, "reason": reason,
                                  "at": cancel["at"], "background_failure_roles": failed})
            accelerations = [x for x in traces if x["stage"] == "再加速b"]
            if not accelerations:
                continue
            assert len(accelerations) == 1 and phase == "維持" and reason == "hold_entry_cap_rejected"
            a1 = next(x for x in traces if x["stage"] == "受容a1")
            a2 = next(x for x in traces if x["stage"] == "受容a2")
            j = next(x for x in traces if x["stage"] == "再接近j")
            b = accelerations[0]
            holds = [x for x in traces if x["stage"] == "維持1"]
            assert len(holds) <= 1
            first = holds[0] if holds else cancel
            side = b["side"]
            k, invalidation, cap = (j["fields"][key] for key in ("K", "I", "cap"))
            atr = a1["fields"]["atr5_frozen"]
            jm, bm = j["fields"]["minute"], b["fields"]["minute"]
            assert k == (jm["ohlc"]["high"] + 5 if side == 1 else jm["ohlc"]["low"] - 5)
            assert invalidation == (jm["ohlc"]["low"] - 5 if side == 1 else jm["ohlc"]["high"] + 5)
            assert cap == k + side * min(20, .25 * atr)
            assert bm["start"] == jm["end"] and bm["end"] == jm["end"] + 60
            assert bm["volume_known"] and jm["volume_known"] and bm["volume"] >= jm["volume"] > 0
            assert side * (bm["ohlc"]["close"] - k) >= 0
            first_g = geometry(side, first["at"], k, cap, invalidation, atr)
            cancel_g = geometry(side, cancel["at"], k, cap, invalidation, atr)
            assert first_g["normal_bbo"] and cancel_g["normal_bbo"]
            assert cancel_g["signed_last_beyond_cap"] > 0 or cancel_g["signed_price_beyond_cap"] > 0
            cases.append({
                "session": scene["session"], "contract": scene["contract"], "episode_id": episode, "side": side,
                "K": k, "cap": cap, "I": invalidation, "ATR5_frozen": atr, "cap_width": abs(cap-k),
                "a1": a1["fields"]["minute"], "a2": a2["fields"]["minute"], "j": jm, "b": bm,
                "w_star": a1["fields"]["w_star"], "atr_ref": a1["fields"]["atr_ref"],
                "b_close_signed_from_K": side * (bm["ohlc"]["close"]-k),
                "b_close_signed_beyond_cap": side * (bm["ohlc"]["close"]-cap),
                "b_close_risk_reference": side * (bm["ohlc"]["close"]-invalidation),
                "D_ready": b["fields"]["D_ready"], "ready_quote": b["at"],
                "b_end_to_ready_seconds": b["at"]["time"]-bm["end"],
                "b_available_to_delivery_seconds": b["at"]["time"]-bm["available_at"],
                "first_normal_source_stage": first["stage"], "first_normal": first_g,
                "b_end_to_first_normal_seconds": first["at"]["time"]-bm["end"],
                "ready_to_first_normal_seconds": first["at"]["time"]-b["at"]["time"],
                "held_first": bool(holds), "cancellation": cancel_g,
                "ready_to_cancel_seconds": cancel["at"]["time"]-b["at"]["time"],
                "first_normal_to_cancel_raw_index": cancel["at"]["index"]-first["at"]["index"],
                "first_normal_to_cancel_source_lines": cancel["at"]["source_line"]-first["at"]["source_line"],
                "full_saved_transition_clocks": [{"stage": t["stage"], "reason": t["reason"], "at": t["at"]} for t in traces],
                "source_path": str(SOURCE), "source_sha256": EXPECTED,
            })
        sessions.append({"session": scene["session"], "episodes": len(grouped), "cancel_reasons": dict(session_reasons), "minutes": scene["csv_stats"]["grid_minutes"]})
    assert len(cancellations) == stages["受容a1"] == stages["取消"] == 689
    assert stages["受容a2"] == 550 and stages["再接近j"] == 207 and stages["再加速b"] == len(cases) == 7 and stages["維持1"] == 1
    assert all(c["b_close_signed_beyond_cap"] > 0 for c in cases)
    hours = minutes / 60
    summary = {
        "sessions": 73, "minutes": minutes, "hours": hours, "stage_counts": dict(stages),
        "cancel_phase_counts": dict(phases),
        "cancel_phase_reasons": [{"phase": phase, "reason": reason, "count": count} for (phase, reason), count in sorted(reasons.items())],
        "background_failure_roles_overlapping": dict(role_counts),
        "b_count": 7, "b_close_already_beyond_cap": 7,
        "first_normal_cap_failure": sum(not c["first_normal"]["last_cap_pass"] or not c["first_normal"]["price_cap_pass"] for c in cases),
        "first_hold_pass_then_cap_failure": sum(c["held_first"] for c in cases),
        "first_normal_risk_failure": sum(not c["first_normal"]["risk_pass"] for c in cases),
        "actual_births": 0, "actual_fills": 0,
        "b7_per_hour_upper_diagnostic": 7/hours,
        "C0_81_plus_all_b7_per_hour_upper_diagnostic": 88/hours,
        "upper_diagnostic_limit": "全bが取得可能という仮定の算術上限。遅延、risk、維持、取消、C0重複を無視し実取得を保証しない",
    }
    after = SOURCE.read_bytes()
    assert sha(after) == EXPECTED and SOURCE.stat().st_size == before_stat.st_size and SOURCE.stat().st_mtime_ns == before_stat.st_mtime_ns
    result = {"success": True, "trial": 141, "source_sha256": EXPECTED, "financial_data_read": False,
              "raw_read": False, "csv_read": False, "conditions_changed": False, "summary": summary,
              "b_cases": cases, "all_cancellations": cancellations, "sessions": sessions}
    path = OUT/"全取消と再加速7件.json"
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    return {"result": str(path), "sha256": sha(path.read_bytes()), "summary": summary}


if __name__ == "__main__":
    print(json.dumps(run(), ensure_ascii=True))
