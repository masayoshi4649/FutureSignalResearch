"""141の保存Source・固定取得・unionを金融/原板の再走査なしで独立に照合する。"""
from collections import Counter, defaultdict
import math


def close(a: float, b: float) -> bool:
    """
    機能: 出力の浮動小数演算を丸め誤差の範囲で照合する。
    引数: a/b(float)は比較値。
    返り値: boolは絶対1e-9以内か。
    """
    return math.isfinite(a) and math.isfinite(b) and math.isclose(a, b, rel_tol=0, abs_tol=1e-9)


# ----------------------------------------
def before(stamp: dict, quote: dict) -> None:
    """
    機能: 保存参照の知得が現在の時刻・原行以前か調べる。
    引数: stamp/quote(dict)は配送Stampと現在Quote。
    返り値: None。不一致なら停止する。
    """
    assert stamp['index'] >= 0 and stamp['source_line'] > 0
    assert stamp['time'] <= quote['time'] and stamp['index'] <= quote['index'] and stamp['source_line'] <= quote['source_line']


# ----------------------------------------
def references(refs: list, quote: dict) -> None:
    """
    機能: 必要足End/実配送の因果性とID改変を検査する。
    引数: refs(list)とquote(dict)は保存参照と現在。
    返り値: None。
    """
    seen = {}
    for ref in refs or []:
        assert ref['id'] and ref['width_seconds'] in (60, 300, 900, 1800)
        assert ref['end'] <= quote['time']
        before(ref['delivered'], quote)
        assert ref['delivered']['time'] >= ref['end'] + 60
        assert ref['id'] not in seen or seen[ref['id']] == ref
        seen[ref['id']] = ref


# ----------------------------------------
def window(w: dict, end: float, quote: dict) -> None:
    """
    機能: 既知VWMA窓の正確な20分端と参照を検査する。
    引数: w(dict)、end(float)、quote(dict)は値・指定端・現在。
    返り値: None。OHLCV値の再計算は行わない。
    """
    assert w['known'] is True and w['value'] > 0 and w['end'] == end
    refs = w['refs']
    assert len(refs) == 20 and [r['end'] for r in refs] == [end - i * 60 for i in range(19, -1, -1)]
    assert all(r['width_seconds'] == 60 for r in refs)
    assert all(not r['id'].startswith('csv1m-missing:') for r in refs)
    references(refs, quote)


# ----------------------------------------
def minute(m: dict, scene: dict, quote: dict, positive: bool = True) -> None:
    """
    機能: 役割足のscope・確定知得・価格形状・数量を確認する。
    引数: m/scene/quote(dict)、positive(bool)は必要な正量条件。
    返り値: None。
    """
    assert m['session'] == scene['session'] and m['contract'] == scene['contract']
    assert m['end'] - m['start'] == 60 and m['available_at'] == m['end'] + 60
    assert scene['start'] <= m['start'] < m['end'] <= scene['end'] - 300
    assert m['available_at'] <= m['stamp']['time']
    before(m['stamp'], quote)
    assert m['price_known'] and m['volume_known'] and m['closed'] and not m['missing']
    o = m['ohlc']
    assert 0 < o['low'] <= o['high'] and o['low'] <= o['open'] <= o['high'] and o['low'] <= o['close'] <= o['high']
    assert m['volume'] > 0 if positive else m['volume'] >= 0


# ----------------------------------------
def assessment(a: dict, s: int, quote: dict, require_pass: bool = True) -> None:
    """
    機能: 保存背景の支持式を数値とknownから再計算する。
    引数: a(dict)、s(int)、quote(dict)、require_pass(bool)は評価資料。
    返り値: None。指標の原系列やseed自体は再算しない。
    """
    references(a['refs'], quote)
    f = a['fields']
    k = lambda name: f[name]['known']
    v = lambda name: f[name]['value']
    w, p = a['w'], a['w_previous_5']
    wp = w['known'] and p['known'] and p['end'] == w['end'] - 300 and s * (w['value'] - p['value']) > 0
    if w['known']:
        window(w, w['end'], quote)
    if p['known']:
        window(p, w['end'] - 300, quote)
    frames = all(a['masks'].get('frame_' + str(width) + '_fresh_price', False) for width in (300, 900, 1800))
    passed = frames and k('ema21_delta30') and s * v('ema21_delta30') > 0 and k('di15_signed') and v('di15_signed') > 0
    passed = passed and ((k('adx15') and v('adx15') >= 20) or (k('adx15_delta') and v('adx15_delta') > 0))
    passed = passed and ((k('hist5') and s * v('hist5') >= 0) or (k('hist5_delta_signed') and v('hist5_delta_signed') > 0))
    passed = passed and all(k(n) for n in ('atr5', 'previous_atr5', 'tr5')) and v('atr5') > 0 and v('previous_atr5') > 0 and 0 <= v('tr5') <= 2 * v('previous_atr5') and wp
    assert a['pass'] == bool(passed)
    if require_pass:
        assert passed


# ----------------------------------------
def geometry(s: int, k: float, cap: float, invalid: float, atr: float, q: dict) -> bool:
    """
    機能: 現在Lastと実側BBOの固定geometryを対称式で評価する。
    引数: s(int)、k/cap/invalid/atr(float)、q(dict)。
    返り値: boolは正常BBOかつK/cap/riskを満たすか。
    """
    p = q['ask'] if s > 0 else q['bid']
    return q['quote_ok'] and 0 < q['bid'] < q['ask'] and 0 <= s * (q['last'] - k) <= s * (cap - k) and 0 <= s * (p - k) <= s * (cap - k) and 10 <= s * (p - invalid) <= min(125, 1.5 * atr)


# ----------------------------------------
def csv_binding(value: object, csv: dict) -> None:
    """
    機能: 全1分参照と役割足を固定CSVのSHA/区間へ束縛する。
    引数: value(object)、csv(dict)は保存traceの一部と固定参照。
    返り値: None。元CSV本文は読まない。
    """
    if isinstance(value, list):
        for item in value: csv_binding(item, csv)
    elif isinstance(value, dict):
        if {'id', 'width_seconds', 'end', 'delivered'} <= value.keys() and value['width_seconds'] == 60:
            suffix = csv['sha256'] + ':' + format(value['end'] - 60, '.0f')
            assert value['id'] in ('csv1m:' + suffix, 'csv1m-missing:' + suffix)
        if {'csv', 'csv_line', 'ohlc', 'price_known', 'start'} <= value.keys():
            assert value['csv'] == csv
            if not value['missing']: assert value['csv_line'] > 1
        for item in value.values(): csv_binding(item, csv)


# ----------------------------------------
def lifecycle(rows: list, scene: dict) -> dict:
    """
    機能: 全保存episodeの主要段階式・因果参照・期限を再構成する。
    引数: rows(list)、scene(dict)は全lifecycleと場区間。
    返り値: dictは小型の段階数と取消数。
    """
    episodes, stages, reasons = {}, Counter(), Counter()
    limit = min(scene['force_close'], scene['end'] - 3900)
    for row in rows:
        identity, s, stage, q, f = row['episode_id'], row['side'], row['stage'], row['at'], row['fields']
        assert s in (-1, 1) and q['last'] > 0 and q['index'] >= 0 and q['source_line'] > 0
        e = episodes.setdefault(identity, {'side': s, 'last': None})
        assert e['side'] == s
        if e['last'] is not None:
            before(e['last'], q)
        e['last'] = q
        stages[stage] += 1
        if 'background' in f:
            assessment(f['background'], s, q, stage not in ('取得前背景拒否', '現在背景検査'))
        if stage == '受容a1':
            assert 'a1' not in e
            m = f['minute']; minute(m, scene, q)
            w, p = f['w_star'], f['w_previous5']
            window(w, m['start'], q); window(p, m['start'] - 300, q)
            atr = f['atr5_frozen']; assert atr > 0 and s * (w['value'] - p['value']) > 0
            ar = f['atr_ref']; references([ar], q)
            assert ar['width_seconds'] == 300 and ar['end'] <= m['end'] and q['time'] < ar['end'] + 360
            lo, hi = w['value'] - .25 * atr, w['value'] + .25 * atr
            assert close(lo, f['band_low']) and close(hi, f['band_high'])
            assert s * (m['ohlc']['close'] - w['value']) > .25 * atr and q['time'] < min(limit, m['end'] + 900)
            e.update(a1=m, atr=atr, lo=lo, hi=hi, expires=m['end'] + 900)
        elif stage == '受容a2':
            m = f['minute']; minute(m, scene, q)
            assert 'a1' in e and 'a2' not in e and m['start'] == e['a1']['end']
            assert s * (m['ohlc']['close'] - (e['hi'] if s > 0 else e['lo'])) > 0
            e['a2'] = m
        elif stage == '再接近j':
            m = f['minute']; minute(m, scene, q); o = m['ohlc']
            assert 'a2' in e and 'j' not in e and m['start'] >= e['a2']['end']
            assert o['high'] >= e['lo'] and o['low'] <= e['hi'] and e['lo'] <= o['close'] <= e['hi'] and o['high'] - o['low'] <= e['atr']
            k, invalid = (o['high'] + 5, o['low'] - 5) if s > 0 else (o['low'] - 5, o['high'] + 5)
            cap = k + s * min(20, .25 * e['atr'])
            assert close(k, f['K']) and close(invalid, f['I']) and close(cap, f['cap'])
            prior = f['prior30']
            if prior['known']:
                assert prior['count'] == 30 and len(prior['refs']) == 30 and [r['end'] for r in prior['refs']] == [m['start'] - i * 60 for i in range(29, -1, -1)]
                references(prior['refs'], q)
            else:
                assert prior['low'] is None and prior['high'] is None
            e.update(j=m, k=k, invalid=invalid, cap=cap)
        elif stage == '再加速b':
            m = f['minute']; minute(m, scene, q); o = m['ohlc']; j = e['j']
            assert m['start'] == j['end'] and m['end'] == j['end'] + 60 and s * (o['close'] - e['k']) >= 0 and s * (o['close'] - o['open']) > 0
            position = (o['close'] - o['low'] if s > 0 else o['high'] - o['close']) / (o['high'] - o['low'])
            assert position >= .7 and close(position, f['close_position']) and m['volume'] >= j['volume'] > 0 and o['high'] - o['low'] <= e['atr']
            assert s * ((o['low'] if s > 0 else o['high']) - e['invalid']) > 0
            expiry = min(q['time'] + 10, m['end'] + 120, e['expires'], limit)
            assert f['D_ready'] == q['time'] and f['hold_expires'] == expiry and q['time'] < expiry
            e.update(b=m, ready=q['time'], hold_expires=expiry)
        elif stage == '維持1':
            assert 'b' in e and 'hold' not in e and e['ready'] <= q['time'] < e['hold_expires']
            assert geometry(s, e['k'], e['cap'], e['invalid'], e['atr'], q)
            assert close(f['K'], e['k']) and close(f['cap'], e['cap'])
            e['hold'] = q
        elif stage == '出生':
            h = e['hold']
            assert f['first_hold'] == h and f['D_ready'] == e['ready'] and f['b_end'] == e['b']['end']
            assert q['index'] > h['index'] and q['source_line'] > h['source_line'] and q['time'] >= h['time'] + 1 and q['time'] < e['hold_expires']
            assert geometry(s, e['k'], e['cap'], e['invalid'], e['atr'], q)
            e['birth'] = q
        elif stage == '取得':
            birth = e['birth']; p = q['ask'] if s > 0 else q['bid']
            assert q['index'] > birth['index'] and q['source_line'] > birth['source_line'] and q['time'] >= birth['time'] + 1
            assert q['time'] < min(birth['time'] + 30, e['b']['end'] + 120, e['expires'], limit)
            assert geometry(s, e['k'], e['cap'], e['invalid'], e['atr'], q) and close(p, f['entry_price'])
            e['entry'] = q
        elif stage in ('取消', '要求取消'):
            reasons[row['reason']] += 1
            reason = row['reason']
            if reason == 'entry_limit': assert q['time'] >= limit
            if reason == 'episode_expired': assert q['time'] >= e['expires']
            if reason == 'expected_b_expired': assert q['time'] >= e['j']['end'] + 180
            if reason == 'hold_expired': assert q['time'] >= e['hold_expires']
            if reason == 'last_invalidation': assert s * (q['last'] - e['invalid']) <= 0
            if reason.startswith('hold_') and reason != 'hold_expired': assert not geometry(s, e['k'], e['cap'], e['invalid'], e['atr'], q)
        if 'a1' in e and stage not in ('取消', '要求取消', '時計拒否', '現在背景検査'):
            assert q['time'] < min(e['expires'], limit)
    return {'episodes': episodes, 'stages': dict(stages), 'reasons': dict(reasons)}


# ----------------------------------------
def source_check(source: dict, common: dict, csv_manifest: dict) -> dict:
    """
    機能: 全場品質/stat/格子とlifecycle・全出生取得を独立照合する。
    引数: source/common/csv_manifest(dict)は非金融の保存出力と固定宣言。
    返り値: dictは小型件数と照合結果。
    """
    assert source['success'] and source['trial'] == 141 and source['financial_labels_used'] is False
    scenes, specs = source['scenes'], common['scenes']
    assert [s['session'] for s in scenes] == [s['session'] for s in specs] == [s['session'] for s in csv_manifest['scenes']]
    assert len({s['session'] for s in scenes}) == len(scenes)
    summary, statuses, total_stages, total_reasons, filled = Counter(), Counter(), Counter(), Counter(), {}
    totals = Counter()
    for scene, spec, cm in zip(scenes, specs, csv_manifest['scenes'], strict=True):
        assert scene['success'] and all(scene[k] == spec[k] for k in ('session', 'contract', 'start', 'end', 'force_close'))
        assert scene['raw']['path'] == spec['raw']['path'] and scene['raw']['sha256'] == spec['raw']['sha256'] == scene['actual_sha256']
        assert scene['counts'] == scene['expected_quality'] == spec['expected_quality']
        assert scene['expected_accepted'] == spec['expected_accepted'] == scene['counts']['source_parser_accepted']
        assert scene['raw_passes'] == 1 and scene['stat_before'] == scene['stat_after'] and scene['stat_before']['bytes'] > 0
        if spec['raw'].get('bytes', 0) > 0: assert scene['stat_before']['bytes'] == spec['raw']['bytes']
        assert scene['entry_limit'] == min(spec['force_close'], spec['end'] - 3900) and scene['execution_end'] == spec['end'] - 300
        csv = scene['csv_stats']; assert csv['reference'] == cm['csv'] and csv['stat_before'] == csv['stat_after'] and csv['stat_before']['bytes'] == cm['csv']['bytes']
        grid = (spec['end'] - 300 - spec['start']) / 60
        assert grid.is_integer() and csv['grid_minutes'] == grid and csv['delivered'] + csv['eof_undelivered'] == grid
        assert all(0 <= csv[k] <= grid for k in ('missing', 'price_known', 'volume_known', 'delivered', 'eof_undelivered'))
        assert scene['stats'].get('採用Raw', 0) == scene['counts']['source_delivered'] and scene['stats'].get('1分配送', 0) == csv['delivered']
        csv_binding(scene['lifecycle'], cm['csv'])
        checked = lifecycle(scene['lifecycle'], spec)
        assert checked['stages'] == scene['stage_counts']
        episodes = checked['episodes']; total_stages.update(checked['stages']); total_reasons.update(checked['reasons'])
        for event in scene['events']:
            assert event['side'] in (-1, 1) and event['pattern'] == 'V0' and event['status'] != 'pending'
            ep = episodes[event['episode_id']]; assert event['birth'] == ep['birth'] and event['side'] == ep['side']
            assert close(event['entry_cap'], ep['cap']) and close(event['invalidation'], ep['invalid']) and close(event['atr5'], ep['atr']) and close(event['hold_boundary'], ep['k'])
            assert event['expires'] == min(event['birth']['time'] + 30, ep['b']['end'] + 120, ep['expires'], scene['entry_limit'])
            references(event['refs'], event['trace'][-1]['at'])
            statuses[event['status']] += 1
            if event['status'] == 'filled':
                q = event['entryQuote']; assert q == ep['entry'] == event['evaluation'] and geometry(event['side'], ep['k'], ep['cap'], ep['invalid'], ep['atr'], q)
                assert close(event['entry_price'], q['ask'] if event['side'] > 0 else q['bid'])
                assert event['id'] not in filled; filled[event['id']] = (scene['session'], event)
            else:
                assert event['entryQuote'] is None and event['entry_price'] is None
        assert sum(r['stage'] == '出生' for r in scene['lifecycle']) == len(scene['events'])
        summary['場数'] += 1; summary['出生数'] += len(scene['events']); summary['取得数'] += sum(e['status'] == 'filled' for e in scene['events'])
        summary['要求取消数'] += sum(e['status'] != 'filled' for e in scene['events'])
        for k, v in scene['stage_counts'].items(): summary['stage/' + k] += v
        totals.update({k: csv.get(k, 0) for k in ('rows', 'grid_minutes', 'missing', 'price_known', 'volume_known', 'delivered', 'eof_undelivered')})
    assert summary == Counter(source['summary'])
    return {'場数': len(scenes), '出生数': sum(statuses.values()), '取得数': len(filled), '状態': dict(statuses), '段階': dict(total_stages), '取消': dict(total_reasons), 'CSV': dict(totals), 'filled': filled}


# ----------------------------------------
def bridge_check(fixed: dict, meta: dict, source_result: dict, old_fixed: dict, common: dict) -> dict:
    """
    機能: V0取得・旧C0同体・全場・C0優先unionを別実装で再構成する。
    引数: fixed/meta/source_result/old_fixed/common(dict)は非金融入力。
    返り値: dictは件数と同体判定。
    """
    assert meta['success'] and meta['trial'] == 141 and meta['financial_labels_used'] is False and meta['portfolio_replay'] is False
    assert meta['sessions'] == [s['session'] for s in common['scenes']] == [s['session'] for s in fixed['scenes']]
    old = {(s['session'], e['id']): e for s in old_fixed['scenes'] for e in s['entries'] if e['id'].startswith('C0/')}
    actual = {(s['session'], e['id']): e for s in fixed['scenes'] for e in s['entries']}
    controls = {key: value for key, value in actual.items() if key[1].startswith('C0/')}
    assert old == controls
    candidates = source_result['filled']
    expected_v = {(sid, 'V0/' + identity): {'id': 'V0/' + identity, 'side': event['side'], 'entry': event['entryQuote']} for identity, (sid, event) in candidates.items()}
    assert actual == {**old, **expected_v} and fixed['expected_entry_count'] == len(actual)
    rows = {(r['session'], r['id']): r for r in meta['entries']}
    assert len(rows) == len(actual)
    groups = defaultdict(list)
    for scene, original in zip(fixed['scenes'], common['scenes'], strict=True):
        assert {k: v for k, v in scene.items() if k != 'entries'} == {k: v for k, v in original.items() if k != 'entries'}
        for entry in scene['entries']:
            r = rows[(scene['session'], entry['id'])]; q = entry['entry']
            assert r['entry_quote'] == q and r['native_side'] == entry['side'] and r['contract'] == scene['contract']
            assert r['model'] == ('C0' if entry['id'].startswith('C0/') else 'V0') and r['baseline'] == (r['model'] == 'C0')
            if r['model'] == 'V0':
                event = candidates[r['candidate_id']][1]
                assert r['origins'][0]['birthQuote'] == event['birth'] and r['origins'][0]['trace'] == event['trace'] and r['origins'][0]['episode_id'] == event['episode_id']
            key = (scene['session'], scene['contract'], q['time'], q['index'], q['source_line'])
            groups[key].append(r)
    unions = {}
    for key, group in groups.items():
        controls_here = [r for r in group if r['model'] == 'C0']
        assert len(controls_here) <= 1 and len({r['model'] for r in group}) == len(group)
        chosen = controls_here[0] if controls_here else group[0]
        assert all(r['entry_quote'] == chosen['entry_quote'] for r in group)
        unions[key] = {'canonical_id': chosen['id'], 'alias_ids': {r['id'] for r in group}, 'alias_sides': {r['id']: r['native_side'] for r in group}}
    assert len(meta['union']) == len(unions)
    for row in meta['union']:
        stamp = row['entry_stamp']; key = (row['session'], row['contract'], stamp['time'], stamp['index'], stamp['source_line'])
        want = unions.pop(key)
        assert row['canonical_id'] == want['canonical_id'] and set(row['alias_ids']) == want['alias_ids'] and row['alias_sides'] == want['alias_sides']
    assert not unions
    return {'旧C0同体件数': len(old), 'V0取得件数': len(candidates), '基礎集合件数': len(actual), 'U0件数': len(meta['union']), '同原行alias除去': len(actual) - len(meta['union']), '全場保持': len(fixed['scenes'])}
