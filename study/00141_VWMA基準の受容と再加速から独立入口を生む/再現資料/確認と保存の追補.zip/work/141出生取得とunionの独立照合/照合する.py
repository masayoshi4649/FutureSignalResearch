"""Root通知後だけ141の非金融Source・固定取得・unionを独立照合する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
from 独立算術 import source_check, bridge_check

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
BASE = ROOT / 'work/141VWMA独立入口の評価'
PINS = {
    'F0': (BASE / 'F0出生前.json', '05e66573e55377e4d89b66fce2c00abaa4a247a04d1916de7b2ebff7b8cfaffb'),
    'F1': (BASE / 'F1金融前.json', '0602d5e3653d3981f11819d623376b64be0dea9d06e636aeba0abbac3c958f02'),
    'Source': (BASE / 'V0の出生と取得.json', '81f7c380f47b06952eaa4a8eae8f4b3821c49361fafe1afd93ef3367a23de40b'),
    '73場宣言': (ROOT / 'inputs/00124_同入口正逆の共用入力/入力.json.gz', '717f41674a4c99f94545a5e147495ae66498dbbc1afa48d7f34d04c40514843b'),
    'CSV73参照': (BASE / 'CSV73参照.json', '07e136e2b77a0029ddacd955abad16a9240373fa849ec96b553c2875e1e85147'),
    '旧固定取得': (ROOT / 'work/138全成立入口の評価/固定入力_版2/固定取得入力.json', '0c83e525dec3079ce188d942069c0d137c94f39009339752ec8227ec9ecb4ce7'),
}


def sha(path: Path) -> str:
    """
    機能: 許可されたコード/非金融JSONの全体指紋を求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。CSV/Raw本文へは呼ばない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def read(path: Path) -> dict:
    """
    機能: 固定JSON又はJSON.gzを読む。
    引数: path(Path)は明示許可済み非金融入力。
    返り値: dictは解読結果。
    """
    body = path.read_bytes()
    return json.loads(gzip.decompress(body) if path.suffix == '.gz' else body)


# ----------------------------------------
def main() -> None:
    """
    機能: F0/F1/Sourceの明示SHAと準備を確認して非金融出力だけを照合する。
    引数: CLI --execute-after-source-confirmation(bool)はRoot完了通知後の実行。
    返り値: None。生価格/Source全件を複製しない小型proofを保存する。
    """
    parser = argparse.ArgumentParser(description='141のSource/旧81/unionの独立非金融照合')
    parser.add_argument('--execute-after-source-confirmation', required=True, action='store_true')
    parser.parse_args()
    target = OWN / '独立照合.json'
    assert not target.exists()
    prep_path = OWN / '準備の確認.json'
    initial_sha = sha(prep_path)
    for name in ('schema追補の確認.json', 'schema期限の追補.json'):
        if (OWN / name).exists(): prep_path = OWN / name
    prep = read(prep_path)
    if prep_path.name != '準備の確認.json': assert prep['初回準備SHA256'] == initial_sha
    for name, expected in prep['源SHA256'].items(): assert sha(OWN / name) == expected
    for name, (path, expected) in PINS.items(): assert sha(path) == expected, name
    f0, f1 = read(PINS['F0'][0]), read(PINS['F1'][0])
    assert f0['成功'] and f1['成功'] and f0['試行'] == f1['試行'] == 141 and f1['F0_SHA256'] == PINS['F0'][1]
    for name in ('Source', '73場宣言', 'CSV73参照', '旧固定取得'):
        path, expected = PINS[name]
        assert f1['ファイル'][str(path)] == expected
    for name in ('73場宣言', 'CSV73参照', '旧固定取得'):
        path, expected = PINS[name]
        assert f0['ファイル'][str(path)] == expected
    fixed_path, meta_path = BASE / '固定入力/固定取得入力.json', BASE / '固定入力/入口参照.json'
    dynamic = {fixed_path: f1['ファイル'][str(fixed_path)], meta_path: f1['ファイル'][str(meta_path)]}
    for path, expected in dynamic.items(): assert sha(path) == expected
    common, manifest, source = read(PINS['73場宣言'][0]), read(PINS['CSV73参照'][0]), read(PINS['Source'][0])
    assert len(common['scenes']) == len(manifest['scenes']) == 73 and manifest['quality_mask_used_for_online_decision'] is False
    assert source['background_sha256'] == '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec' and source['csv_manifest_sha256'] == PINS['CSV73参照'][1]
    for scene in manifest['scenes']: assert f0['ファイル'][scene['csv']['path']] == scene['csv']['sha256']
    checked = source_check(source, common, manifest)
    assert checked['CSV']['grid_minutes'] == 43255 and checked['CSV']['missing'] == 2586 and checked['CSV']['price_known'] == 40669 and checked['CSV']['volume_known'] == 40622
    fixed, meta = read(fixed_path), read(meta_path)
    assert meta['fixed_input_sha256'] == dynamic[fixed_path] and meta['source_sha256'] == PINS['Source'][1]
    assert meta['control_manifest_sha256'] == 'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35'
    for row in meta['entries']:
        if row['model'] == 'V0': assert row['origins'][0]['source_file_sha'] == PINS['Source'][1]
    joined = bridge_check(fixed, meta, checked, read(PINS['旧固定取得'][0]), common)
    assert joined['旧C0同体件数'] == 81 and joined['全場保持'] == 73
    for name, (path, expected) in PINS.items(): assert sha(path) == expected, name
    for path, expected in dynamic.items(): assert sha(path) == expected
    for name, expected in prep['源SHA256'].items(): assert sha(OWN / name) == expected
    checked.pop('filled')
    proof = {'成功': True, '確認日': '2026-11-12', '試行': 141, '段階': '金融を読まないSource/bridge独立照合',
             '入力': {name: {'path': str(path), 'sha256': expected} for name, (path, expected) in PINS.items()},
             '動的固定入力': {str(path): value for path, value in dynamic.items()}, 'Source再計数': checked, 'union再構成': joined,
             'Source全73のSHA宣言_stat_品質_格子一致': True, '全保存段階の主要式_時点_期限照合': True,
             '全birth_entry当時参照': '保存された全件を照合。0件ならその事実を残し、存在しない成功例を作らない。',
             '入力と独立コード前後同体': True, 'Raw_CSV本文_金融_追加2場読取': False, 'Root_作者関数import': False,
             '未証明': ['保存されない中間Rawと最初適格候補列の再生', '不成立取消足の未保存OHLCと背景拒否時に未保存のAssessment', 'CSVからの全VWMA値/指標seedの別再計算'],
             '初回準備SHA256': initial_sha, '準備SHA256': sha(prep_path)}
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2); stream.write('\n')
    print(json.dumps({'成功': True, 'Source': checked, 'union': joined, '独立照合SHA256': sha(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
