"""保存Source照合の人工。自然出力・金融・Raw・価格CSVは読まない。"""
import copy
from 独立算術 import lifecycle, source_check, bridge_check, csv_binding, window


def quote(at: float, side: int = 1) -> dict:
    """
    機能: 時計と鏡像気配を持つ人工Quoteを作る。
    引数: at(float)、side(int)は現在と方向。
    返り値: dictは正常BBO人工。
    """
    price = 1030 if side > 0 else 970
    return {'time': at, 'index': int(at * 10), 'source_line': int(at * 10) + 1, 'last': price, 'bid': price - 5, 'ask': price + 5, 'quote_ok': True, 'clock': '人工価格時計'}


# ----------------------------------------
def ref(end: float, width: int = 60) -> dict:
    """
    機能: 人工のEnd+60配送参照を作る。
    引数: end(float)、width(int)は足端と幅。
    返り値: dictは因果参照。
    """
    return {'id': str(width) + '/' + str(end), 'width_seconds': width, 'end': end, 'delivered': {k: quote(end + 60)[k] for k in ('time', 'index', 'source_line')}}


# ----------------------------------------
def w(end: float, value: float) -> dict:
    """
    機能: 正確20格子を持つ人工の既知窓を作る。
    引数: end/value(float)は窓端と量加重値。
    返り値: dictはWValue同形。
    """
    return {'known': True, 'end': end, 'value': value, 'refs': [ref(end - i * 60) for i in range(19, -1, -1)]}


# ----------------------------------------
def background(at: float, side: int) -> dict:
    """
    機能: 必須役割が支持する人工Assessmentを作る。
    引数: at(float)、side(int)は現在と方向。
    返り値: dictは数値と既知mask。
    """
    end = (int(at) // 60 - 1) * 60
    values = {'ema21_delta30': side, 'di15_signed': 20, 'adx15': 25, 'adx15_delta': 1, 'hist5': side,
              'hist5_delta_signed': 1, 'atr5': 100, 'previous_atr5': 100, 'tr5': 40}
    return {'pass': True, 'fields': {k: {'known': True, 'value': v} for k, v in values.items()},
            'masks': {'frame_' + str(width) + '_fresh_price': True for width in (300, 900, 1800)},
            'refs': [], 'w': w(end, 1000 + side * end / 60), 'w_previous_5': w(end - 300, 1000 + side * (end - 300) / 60)}


# ----------------------------------------
def fixture(side: int = 1) -> tuple[list, dict]:
    """
    機能: 受容→再接近→b→保持→出生→取得の純人工を作る。
    引数: side(int)は符号反転方向。
    返り値: tuple[list,dict]はlifecycleと場。
    """
    base = 12000
    scene = {'session': '人工_Day', 'contract': '人工限月', 'start': 9600, 'end': 24000, 'force_close': 23000}
    rows = []
    def bar(name: str, start: int, values: tuple) -> dict:
        """
        機能: 役割に束縛する人工確定分を作る。
        引数: name(str)、start(int)、values(tuple)は識別/区間/OHLCV。
        返り値: dictはMinute。
        """
        o, h, low, c, v = values
        if side < 0: o, h, low, c = 2000-o, 2000-low, 2000-h, 2000-c
        return {'id': name, 'session': scene['session'], 'contract': scene['contract'], 'start': base+start, 'end': base+start+60,
                'available_at': base+start+120, 'stamp': {k: quote(base+start+120)[k] for k in ('time', 'index', 'source_line')},
                'ohlc': {'open': o, 'high': h, 'low': low, 'close': c}, 'volume': v, 'price_known': True, 'volume_known': True, 'closed': True, 'missing': False}
    def add(stage: str, at: float, fields: dict) -> None:
        """
        機能: 一つの人工遷移を現在Quoteに結ぶ。
        引数: stage(str)、at(float)、fields(dict)は段階・時計・資料。
        返り値: None。
        """
        rows.append({'episode_id': '人工/episode', 'side': side, 'stage': stage, 'reason': '人工', 'at': quote(base+at, side), 'fields': fields})
    a1 = bar('a1', 360, (1020, 1035, 1015, 1030, 10)); a2 = bar('a2', 420, (1025, 1035, 1020, 1030, 10))
    j = bar('j', 540, (1000, 1025, 995, 1000, 10)); b = bar('b', 600, (1000, 1035, 995, 1030, 10))
    star, previous = 1000, 990 if side > 0 else 1010
    add('受容a1', 480, {'minute': a1, 'w_star': w(base+360, star), 'w_previous5': w(base+60, previous), 'atr5_frozen': 100,
                        'atr_ref': ref(base+300, 300), 'band_low': 975, 'band_high': 1025, 'background': background(base+480, side)})
    add('受容a2', 540, {'minute': a2, 'background': background(base+540, side)})
    k, invalid, cap = (1030, 990, 1050) if side > 0 else (970, 1010, 950)
    add('再接近j', 660, {'minute': j, 'K': k, 'I': invalid, 'cap': cap, 'prior30': {'known': False, 'low': None, 'high': None}, 'background': background(base+660, side)})
    add('再加速b', 720, {'minute': b, 'close_position': .875, 'D_ready': base+720, 'hold_expires': base+730, 'background': background(base+720, side)})
    add('維持1', 720, {'K': k, 'cap': cap})
    add('出生', 721, {'first_hold': quote(base+720, side), 'D_ready': base+720, 'b_end': base+660})
    add('取得', 722, {'entry_price': quote(base+722, side)['ask' if side > 0 else 'bid'], 'background': background(base+722, side)})
    return rows, scene


# ----------------------------------------
def zero_and_alias() -> None:
    """
    機能: 全0新規の場保持と同原行異方向C0優先unionを検査する。
    引数: なし。
    返り値: None。全資料は小型人工。
    """
    q = quote(100)
    spec = {'session': '人工_Day', 'contract': '人工', 'start': 0, 'end': 8100, 'force_close': 8000,
            'raw': {'path': '人工Raw', 'sha256': '0'*64}, 'expected_quality': {'source_parser_accepted': 10, 'source_delivered': 10}, 'expected_accepted': 10, 'entries': []}
    cm = {'path': '人工CSV', 'sha256': '1'*64, 'bytes': 10}
    csv = {'reference': cm, 'stat_before': {'bytes': 10, 'mtime_ns': 1}, 'stat_after': {'bytes': 10, 'mtime_ns': 1},
           'grid_minutes': 130, 'delivered': 128, 'eof_undelivered': 2, 'missing': 2, 'price_known': 128, 'volume_known': 128}
    scene = {**spec, 'success': True, 'actual_sha256': '0'*64, 'counts': spec['expected_quality'], 'raw_passes': 1,
             'stat_before': {'bytes': 1, 'mtime_ns': 1}, 'stat_after': {'bytes': 1, 'mtime_ns': 1}, 'entry_limit': 4200, 'execution_end': 7800,
             'csv_stats': csv, 'stats': {'採用Raw': 10, '1分配送': 128}, 'lifecycle': [], 'stage_counts': {}, 'events': []}
    common = {'scenes': [spec]}
    checked = source_check({'success': True, 'trial': 141, 'financial_labels_used': False, 'scenes': [scene], 'summary': {'場数': 1, '出生数': 0}}, common,
                           {'scenes': [{'session': spec['session'], 'csv': cm}]})
    old_entry = {'id': 'C0/旧ID', 'side': 1, 'entry': q}
    fixed = {'scenes': [{**spec, 'entries': [old_entry]}], 'expected_entry_count': 1}
    old = copy.deepcopy(fixed)
    c = {'session': spec['session'], 'contract': spec['contract'], 'id': old_entry['id'], 'native_side': 1, 'model': 'C0', 'baseline': True, 'entry_quote': q}
    union = {'session': spec['session'], 'contract': spec['contract'], 'entry_stamp': {k: q[k] for k in ('time', 'index', 'source_line')}, 'canonical_id': c['id'], 'alias_ids': [c['id']], 'alias_sides': {c['id']: 1}}
    meta = {'success': True, 'trial': 141, 'financial_labels_used': False, 'portfolio_replay': False, 'sessions': [spec['session']], 'entries': [c], 'union': [union]}
    assert bridge_check(fixed, meta, checked, old, common)['U0件数'] == 1
    event = {'side': -1, 'entryQuote': q, 'birth': quote(99), 'trace': [], 'episode_id': '人工/V'}
    checked['filled'] = {'V': (spec['session'], event)}
    fixed['scenes'][0]['entries'].append({'id': 'V0/V', 'side': -1, 'entry': q}); fixed['expected_entry_count'] += 1
    meta['entries'].append({'session': spec['session'], 'contract': spec['contract'], 'id': 'V0/V', 'native_side': -1, 'model': 'V0', 'baseline': False,
                            'entry_quote': q, 'candidate_id': 'V', 'origins': [{'birthQuote': event['birth'], 'trace': [], 'episode_id': event['episode_id']}]})
    union['alias_ids'].append('V0/V'); union['alias_sides']['V0/V'] = -1
    assert bridge_check(fixed, meta, checked, old, common)['同原行alias除去'] == 1


# ----------------------------------------
def main() -> None:
    """
    機能: 5主群の純人工で主要式と拒否境界を検査する。
    引数: なし。
    返り値: None。自然出力は読まない。
    """
    for side in (1, -1):
        rows, scene = fixture(side)
        assert lifecycle(rows, scene)['stages']['取得'] == 1
    for mode in ('未来ref', 'W端', '次足', '量', '終値位置', 'cap', 'holdTTL'):
        rows, scene = fixture()
        if mode == '未来ref': rows[0]['fields']['w_star']['refs'][0]['delivered']['time'] = rows[0]['at']['time'] + 1
        elif mode == 'W端': rows[0]['fields']['w_star']['end'] += 60
        elif mode == '次足': rows[3]['fields']['minute']['start'] += 60
        elif mode == '量': rows[3]['fields']['minute']['volume'] = 9
        elif mode == '終値位置': rows[3]['fields']['minute']['ohlc']['high'] += 20
        elif mode == 'cap': rows[4]['at']['ask'] = 1051
        else: rows[5]['at']['time'] = 12730
        try: lifecycle(rows, scene)
        except AssertionError: pass
        else: raise AssertionError('拒否漏れ: ' + mode)
    zero_and_alias()
    placeholder = ref(12360)
    placeholder['id'] = 'csv1m-missing:' + 'a'*64 + ':12300'
    csv_binding(placeholder, {'sha256': 'a'*64})
    rows, scene = fixture()
    a = background(12660, 1)
    a['pass'] = False; a['w']['known'] = False
    rows = rows[:2] + [{'episode_id': '人工/episode', 'side': 1, 'stage': '現在背景検査', 'reason': 'background_or_latest_w_unknown_or_denied', 'at': quote(12660), 'fields': {'background': a}}]
    assert lifecycle(rows, scene)['stages']['現在背景検査'] == 1
    known = w(12360, 1000); known['refs'][0]['id'] = 'csv1m-missing:人工'
    try: window(known, 12360, quote(12480))
    except AssertionError: pass
    else: raise AssertionError('既知窓にmissingを許可した')
    rows, scene = fixture()
    rows = rows[:1]
    for stage, fields in [('現在背景検査', {'background': background(13320, 1)}), ('取消', {'phase': 'a2待ち'})]:
        rows.append({'episode_id': '人工/episode', 'side': 1, 'stage': stage, 'reason': 'episode_expired', 'at': quote(13320), 'fields': fields})
    assert lifecycle(rows, scene)['reasons']['episode_expired'] == 1
    print('人工7主群成功。取消診断時刻と成功TTLを分離。金融未読。')


if __name__ == '__main__':
    main()
