# 141の独立入口・旧対照・unionの集計準備

2026-11-12。可変NのV0、固定81のC0、C0優先dedupのU0、実逆RV/RUを保存133pairedから集計する部品。[条件](条件.md)と[採用仕様](../141_VWMA独立入口の採用仕様.md)に従う。自然V0・新損益は未実行で、ここでは人工だけを使用した。

```powershell
python -X utf8 "work/141独立入口とunionの集計/人工検査.py"
python -m py_compile "work/141独立入口とunionの集計/集計する.py" "work/141独立入口とunionの集計/人工検査.py"
```

人工は73場の架空時計と架空Quoteから作り、価格ファイルを持たない。V0=0・異方向の同原行alias・C0優先・基礎内重複拒否・期限phase・77/1077円・Last金額null・実正逆両方損失・H不足でも既知touch優先を調べる。旧算術をprivate importするが旧金融JSONは開かない。

Root F1と正逆結果の通知後だけ実行するCLI：

```text
python -X utf8 集計する.py
  --f1 <F1> --f1-sha256 <SHA>
  --fixed-input <固定133入力> --fixed-input-sha256 <SHA>
  --metadata <141入口参照> --metadata-sha256 <SHA>
  --result <133正逆結果> --result-sha256 <SHA>
  --output-dir <未出力先>
```

固定入力の基礎ID・方向・Quoteとmetadataの全membershipを先に照合し、全300条件・三表JSONを作る。C0の旧81/60条件同体は自然実行段階で行う。新Source生成・原板/CSV走査・実約定・資金やmini10枚口座を扱わない。独立金融検算は作者と別工程で必要である。
