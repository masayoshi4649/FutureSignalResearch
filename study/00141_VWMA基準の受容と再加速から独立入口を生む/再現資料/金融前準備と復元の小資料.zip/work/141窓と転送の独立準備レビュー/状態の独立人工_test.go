package vwmaentry141

import (
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// stateFixture は直前jと次足bの順序が完成する人工状態を符号対称に作ります。
//
// 引数: side(int)は買+1/売-1。
// 返り値: *Detector/*episode/Minute/Assessment/Quoteは自然資料を含まない純人工です。
func stateFixture(side int) (*Detector, *episode, Minute, Assessment, Quote) {
	d, err := NewDetector(Scene{Session: "独立人工", Contract: "人工限月", Start: 0, End: 10000, ForceClose: 9000})
	if err != nil { panic(err) }
	j := Minute{ID: "j", Session: "独立人工", Contract: "人工限月", Start: 540, End: 600, AvailableAt: 660,
		OHLC: rules.OHLC{Open: 1000, High: 1025, Low: 995, Close: 1000}, Volume: 10, PriceKnown: true, VolumeKnown: true, Closed: true,
		Stamp: rules.Stamp{Time: 660, Index: 1, Line: 2}}
	b := Minute{ID: "b", Session: "独立人工", Contract: "人工限月", Start: 600, End: 660, AvailableAt: 720,
		OHLC: rules.OHLC{Open: 1000, High: 1035, Low: 995, Close: 1030}, Volume: 10, PriceKnown: true, VolumeKnown: true, Closed: true,
		Stamp: rules.Stamp{Time: 720, Index: 10, Line: 11}}
	e := &episode{ID: "独立人工/episode", Side: side, Phase: "b待ち", J: j, ATR: 100, K: 1030, I: 990, Cap: 1050, Expires: 1320}
	q := Quote{Clock: "人工価格時計", Time: 720, Index: 10, SourceLine: 11, Last: 1030, Bid: 1025, Ask: 1035, QuoteOK: true}
	if side < 0 {
		mirror := func(o rules.OHLC) rules.OHLC { return rules.OHLC{Open: 2000-o.Open, High: 2000-o.Low, Low: 2000-o.High, Close: 2000-o.Close} }
		e.J.OHLC, b.OHLC = mirror(j.OHLC), mirror(b.OHLC)
		e.K, e.I, e.Cap = 970, 1010, 950
		q.Last, q.Bid, q.Ask = 970, 965, 975
	}
	d.active[side] = e
	return d, e, b, Assessment{Pass: true}, q
}

// TestReviewStateMirrorHoldEntry は同足知得後の2行1秒保持と別行1秒取得を売買対称に検査します。
//
// 引数: t(*testing.T)は人工の検査管理。
// 返り値: なし。同じ行への出生/取得の遡及を許しません。
func TestReviewStateMirrorHoldEntry(t *testing.T) {
	for _, side := range []int{1, -1} {
		d, e, b, a, q := stateFixture(side)
		d.processMinute(e, b, a, q)
		if e.Phase != "維持" || e.ReadyAt != 720 || e.HoldExpires != 730 { t.Fatal("D_ready又は保持期限が違う") }
		d.hold(e, a, q)
		d.hold(e, a, q)
		if len(d.Events) != 0 { t.Fatal("同原行の重複で出生した") }
		q.Time, q.Index, q.SourceLine = 720.5, 11, 12
		d.hold(e, a, q)
		if len(d.Events) != 0 { t.Fatal("保持1秒未満で出生した") }
		q.Time, q.Index, q.SourceLine = 721, 12, 13
		d.hold(e, a, q)
		if len(d.Events) != 1 || d.Events[0].Birth.Time != 721 { t.Fatal("2別行/1秒後に出生しない") }
		d.processPending(map[int]Assessment{side: a}, q)
		if d.Events[0].Status != "pending" { t.Fatal("出生原行で取得した") }
		q.Time, q.Index, q.SourceLine = 721.5, 13, 14
		d.processPending(map[int]Assessment{side: a}, q)
		if d.Events[0].Status != "pending" { t.Fatal("出生後1秒未満で取得した") }
		q.Time, q.Index, q.SourceLine = 722, 14, 15
		d.processPending(map[int]Assessment{side: a}, q)
		event := d.Events[0]
		if event.Status != "filled" || event.EntryQuote.Time != 722 || event.EntryPrice == nil { t.Fatal("現在の別原行で取得しない") }
		want := q.Ask
		if side < 0 { want = q.Bid }
		if *event.EntryPrice != want { t.Fatal("実側BBOが違う") }
	}
}

// TestReviewFirstNormalCancels はholdの最初の正常BBO不適格を再待機へ戻さないことを検査します。
//
// 引数: t(*testing.T)は人工の検査管理。
// 返り値: なし。不正常BBOのI無効化は別に検査します。
func TestReviewFirstNormalCancels(t *testing.T) {
	for _, side := range []int{1, -1} {
		d, e, b, a, q := stateFixture(side)
		d.processMinute(e, b, a, q)
		if side > 0 { q.Ask = e.Cap+1 } else { q.Bid = e.Cap-1 }
		d.hold(e, a, q)
		if _, active := d.active[side]; active || len(d.Events) != 0 { t.Fatal("最初正常のcap外を待機で救済した") }
	}
}

// TestReviewClockBounds は保持期限・b鮮度・期待次足の等号失効を検査します。
//
// 引数: t(*testing.T)は人工の検査管理。
// 返り値: なし。市場次足とreadyの期限を別に確認します。
func TestReviewClockBounds(t *testing.T) {
	d, e, b, a, q := stateFixture(1)
	d.processMinute(e, b, a, q)
	q.Time = 730
	if d.contextPass(e, a, q) != "hold_expired" { t.Fatal("ready+10等号を許可した") }
	d, e, b, a, q = stateFixture(1)
	q.Time = 780
	if d.contextPass(e, a, q) != "expected_b_expired" { t.Fatal("期待b.End+120等号を許可した") }
	d, e, b, a, q = stateFixture(1)
	b.Start, b.End = 660, 720
	d.processMinute(e, b, a, q)
	if _, active := d.active[1]; active { t.Fatal("j直後以外のbを許可した") }
}

// TestReviewPendingUnknownAndI は出生後の背景未知と不正常BBOでも有効LastのI到達を検査します。
//
// 引数: t(*testing.T)は人工の検査管理。
// 返り値: なし。出生後に条件を取り外さないことを確認します。
func TestReviewPendingUnknownAndI(t *testing.T) {
	for _, mode := range []string{"背景未知", "不正常BBOのLast無効化"} {
		d, e, b, a, q := stateFixture(1)
		d.processMinute(e, b, a, q)
		d.hold(e, a, q)
		q.Time, q.Index, q.SourceLine = 721, 11, 12
		d.hold(e, a, q)
		if len(d.Events) != 1 { t.Fatal("人工出生がない") }
		q.Time, q.Index, q.SourceLine = 722, 12, 13
		if mode == "背景未知" { a.Pass = false } else { q.QuoteOK = false; q.Last = e.I }
		d.processPending(map[int]Assessment{1: a}, q)
		if d.Events[0].Status == "pending" || d.Events[0].Status == "filled" { t.Fatal("pending取消が漏れた: "+mode) }
	}
}

// TestReviewKnownZeroWait は既知量0の中間分と必要次足の正量を分離します。
//
// 引数: t(*testing.T)は人工の検査管理。
// 返り値: なし。欠分unknownは中間でも取消します。
func TestReviewKnownZeroWait(t *testing.T) {
	for _, phase := range []string{"再接近待ち", "a2待ち", "b待ち"} {
		d, e, m, a, q := stateFixture(1)
		e.Phase = phase
		m.Volume = 0
		d.processMinute(e, m, a, q)
		_, active := d.active[1]
		if active != (phase == "再接近待ち") { t.Fatal("既知0の役割分離が違う: "+phase) }
	}
	d, e, m, a, q := stateFixture(1)
	e.Phase = "再接近待ち"
	m.Missing = true
	d.processMinute(e, m, a, q)
	if _, active := d.active[1]; active { t.Fatal("未知中間分を継続した") }
}
