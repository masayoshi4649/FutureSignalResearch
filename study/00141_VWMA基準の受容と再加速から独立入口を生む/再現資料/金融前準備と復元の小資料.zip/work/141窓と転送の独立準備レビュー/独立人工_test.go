package vwmaentry141

import (
	"math"
	"reflect"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// reviewMinute は価格と量を指定する人工の固定1分格子を作ります。
//
// 引数: n(int)、price/volume(float64)は格子番号・人工価格・人工量。
// 返り値: Minute は自然入力を含まない実配送済み資料です。
func reviewMinute(n int, price, volume float64) Minute {
	start := float64(n * 60)
	return Minute{ID: string(rune(1000+n)), Session: "独立人工", Contract: "人工限月", Start: start, End: start + 60,
		AvailableAt: start + 120, Stamp: rules.Stamp{Time: start + 120, Index: n, Line: n + 1},
		OHLC: rules.OHLC{Open: price, High: price, Low: price, Close: price}, PriceKnown: true, VolumeKnown: true, Closed: true, Volume: volume}
}

// TestReviewHLC3 は終値単独でなく同足HLC3と量を用いることを検査します。
//
// 引数: t(*testing.T)は人工の検査管理。
// 返り値: なし。数値不一致なら失敗します。
func TestReviewHLC3(t *testing.T) {
	w := NewVWMA()
	_ = w.StartSession("独立人工", "人工限月")
	weighted, quantity := 0.0, 0.0
	for n := 0; n < 20; n++ {
		m := reviewMinute(n, 100+float64(n), float64(n+1))
		m.OHLC.High += 7
		m.OHLC.Low -= 3
		weighted += (m.OHLC.High+m.OHLC.Low+m.OHLC.Close)/3 * m.Volume
		quantity += m.Volume
		if err := w.Add(m); err != nil { t.Fatal(err) }
	}
	got := w.At(1200)
	if !got.Known || math.Abs(got.Value-weighted/quantity) > 1e-10 || len(got.Refs) != 20 { t.Fatalf("HLC3の量加重が違う: %+v", got) }
}

// TestReviewZeroKeepsClock は既知量0を圧縮せず、未知価格の量0も救済しないことを検査します。
//
// 引数: t(*testing.T)は人工の検査管理。
// 返り値: なし。20分の時間位置と品質規約を確認します。
func TestReviewZeroKeepsClock(t *testing.T) {
	for _, unknownPrice := range []bool{false, true} {
		w := NewVWMA()
		_ = w.StartSession("独立人工", "人工限月")
		for n := 0; n < 20; n++ {
			m := reviewMinute(n, 100+float64(n), 1)
			if n == 0 { m.Volume = 0; m.PriceKnown = !unknownPrice }
			if err := w.Add(m); err != nil { t.Fatal(err) }
			if n == 18 && w.Latest().Known { t.Fatal("19分を20観測へ圧縮した") }
		}
		x := w.Latest()
		if unknownPrice {
			if x.Known { t.Fatal("本試行の保守規約に反し価格未知/量0を救済した") }
		} else if !x.Known || x.Value != 110 || len(x.Refs) != 20 || x.Refs[0].End != 60 {
			t.Fatalf("量0の時間枠又は加重値が違う: %+v", x)
		}
	}
}

// TestReviewFutureAndExactEnd は未来追加の非依存と正確な窓端・5分差を検査します。
//
// 引数: t(*testing.T)は人工の検査管理。
// 返り値: なし。過去窓が後の足で変わらないことを確認します。
func TestReviewFutureAndExactEnd(t *testing.T) {
	w := NewVWMA()
	_ = w.StartSession("独立人工", "人工限月")
	for n := 0; n < 25; n++ { if err := w.Add(reviewMinute(n, 100+float64(n), 1)); err != nil { t.Fatal(err) } }
	old, delta := w.At(1200), w.Delta5At(1500)
	if !delta.Known || delta.Value != 5 || w.At(1199).Known || w.Delta5At(1499).Known { t.Fatal("Endの正確一致又は300秒差が違う") }
	for n := 25; n < 45; n++ { if err := w.Add(reviewMinute(n, 100000+float64(n), 10000)); err != nil { t.Fatal(err) } }
	if !reflect.DeepEqual(old, w.At(1200)) || delta != w.Delta5At(1500) { t.Fatal("後の足で過去値が変わった") }
	_ = w.StartSession("次の場", "別限月")
	if w.Latest().Known || w.At(1200).Known || w.Delta5At(1500).Known { t.Fatal("場/限月resetが漏れた") }
}

// TestReviewUnknownWindowAgesOut は未知分が窓外へ出ても5分差相手の未知を維持することを検査します。
//
// 引数: t(*testing.T)は人工の検査管理。
// 返り値: なし。局所窓回復と傾き回復の時差を確認します。
func TestReviewUnknownWindowAgesOut(t *testing.T) {
	w := NewVWMA()
	_ = w.StartSession("独立人工", "人工限月")
	for n := 0; n < 50; n++ {
		m := reviewMinute(n, 100+float64(n), 1)
		if n == 24 { m.Missing = true }
		if err := w.Add(m); err != nil { t.Fatal(err) }
		if n == 43 && w.Latest().Known { t.Fatal("未知分が窓内なのに回復した") }
		if n == 44 && (!w.Latest().Known || w.Delta5At(m.End).Known) { t.Fatal("窓回復と300秒前窓の未知を混同した") }
		if n == 48 && w.Delta5At(m.End).Known { t.Fatal("5分差相手の未知を早く救済した") }
		if n == 49 && !w.Delta5At(m.End).Known { t.Fatal("両端既知後も回復しない") }
	}
}
