"""141の停止Sourceを自然実行せず、人工・因果コード・実行体同体だけで最終確認する。"""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
SOURCE = ROOT / 'work/141VWMAの独立入口'
AUTHOR = SOURCE / '準備の確認.json'
AUTHOR_SHA = 'ec0227d024ab93e5c215a4a6e9d60c14bae403a3d3e34e9f39f281f02e25a258'


def sha(path: Path) -> str:
    """
    機能: コードと人工証跡のSHAを求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 停止20源を前後照合し、人工だけで最終準備proofを新規保存する。
    引数: なし。自然CLI・Raw・価格CSV・金融を実行しない。
    返り値: None。不一致なら停止する。
    """
    assert sha(AUTHOR) == AUTHOR_SHA
    author = json.loads(AUTHOR.read_bytes())
    assert author['成功'] and author['自然未実行'] and len(author['源']) == 20
    refs = author['源'] + [author['実行ファイル']]
    for ref in refs:
        path = Path(ref['path'])
        assert sha(path) == ref['sha256'] and path.stat().st_size == ref['bytes'], path
    old = ROOT / 'work/強い入口の探索期限を延ばす次仮説/Source入口の再生器/reader.go'
    old_code = old.read_text(encoding='utf-8')
    new_code = (SOURCE / 'decoder.go').read_text(encoding='utf-8')
    assert new_code[new_code.index('func decodeRow('):].strip() == old_code[old_code.index('func decodeRow('):].strip()
    assert not (OWN / 'Source最終の確認.json').exists()
    build_output = OWN / '独立build.exe'
    assert not build_output.exists()
    commands = [
        ['go', 'test', '-count=1', '-v', './...'],
        ['go', 'test', '-overlay=' + str(OWN / '人工overlay.json'), '-count=1', '-v', 'tracker.go', 'types.go', 'tracker_test.go'],
        ['go', 'test', '-overlay=' + str(OWN / '状態人工overlay.json'), '-count=1', '-v', 'tracker.go', 'types.go', 'helpers.go', 'state.go', 'tracker_test.go'],
        ['go', 'vet', './...'],
        ['go', 'build', '-o', str(build_output), './cmd/run'],
        [sys.executable, '-X', 'utf8', str(ROOT / 'work/141転送の人工検査.py')],
        [sys.executable, '-X', 'utf8', str(OWN / '転送の独立人工.py')],
    ]
    checks = []
    for command in commands:
        result = subprocess.run(command, cwd=SOURCE, capture_output=True, text=True, encoding='utf-8', errors='strict')
        checks.append({'引数': command, '終了コード': result.returncode, '標準出力': result.stdout, '標準エラー': result.stderr})
        assert result.returncode == 0, checks[-1]
    assert sha(build_output) == author['実行ファイル']['sha256']
    for ref in refs:
        path = Path(ref['path'])
        assert sha(path) == ref['sha256'] and path.stat().st_size == ref['bytes'], path
    assert sha(AUTHOR) == AUTHOR_SHA
    proof = {
        '成功': True, '確認日': '2026-11-12', '試行': 141,
        '段階': '自然生成前Sourceの最終独立準備レビュー',
        '作者proof_SHA256': AUTHOR_SHA,
        '全20源と実行体前後同体': True,
        '源': author['源'], '実行体': author['実行ファイル'],
        '独立build実行体SHA256': sha(build_output),
        'decodeRow本文': {'旧133_SOURCE_reader_SHA256': sha(old), '関数本文完全一致': True},
        '人工': {'作者主群': 9, '独自窓群': 4, '独自状態群': 5, 'Root転送群': 5, '独自転送群': 4},
        '検査': checks,
        '解消済み': ['再接近待ちの既知0量と必要役割の正量を分離', '取得時Assessmentとrefsの保存', '元122はtrial122・success旗を要求しない', 'Raw.Bytes省略0は未知・正指定時だけ照合・実stat保存'],
        '因果確認': ['Source同Raw全背景配送→Bank.Current→同Raw全1分配送→Observe', 'a1以前W*と正確300秒差・a1.End以下最新fresh ATR', '固定格子未知と局所窓回復・古い既知窓へfallbackなし', 'a1/a2/j/bは別市場足・next失敗同足再armなし', 'D_ready一度固定・2行1秒保持・さらに別行1秒後の最初正常BBO取得', 'pendingも現在背景/W/I/期限を監視', '全RawをEOFまで一走査してSHA/stat/品質/限月と全公表配送照合', '跨場Bank seedは過去場公表だけ・VWMAと状態は当場reset', '全場の出力を保持しC0同原行優先unionとaliasを保存'],
        '重大な未解決仕様差': [],
        '自然Source_価格CSV_Raw_金融_追加2場読取又は実行': False,
        'Root源変更': False,
        '自然旧81と新出生': '自然未実行。転送の旧81完全一致assertはコード/人工を確認しただけ。',
        '独立人工コード': {p.name: sha(p) for p in OWN.iterdir() if p.is_file() and p.suffix in ('.py', '.go', '.md', '.json')},
    }
    target = OWN / 'Source最終の確認.json'
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'成功': True, '最終proof_SHA256': sha(target), '全20源一致': True, '独立build同体': True}, ensure_ascii=False))


if __name__ == '__main__':
    main()
