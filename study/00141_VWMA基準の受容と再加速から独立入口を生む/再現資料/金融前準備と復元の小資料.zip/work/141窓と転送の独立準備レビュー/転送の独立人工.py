"""141非金融転送を、全場保持・異方向alias・入力不変の人工だけで検査する。"""
from pathlib import Path
import copy
import importlib.util

ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location('独立レビュー対象の141転送', ROOT / 'work/141V0と旧対照を固定取得へ渡す.py')
BRIDGE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BRIDGE)


def fixture() -> tuple[dict, list, dict]:
    """
    機能: C0/V0同原行・V0のみ・完全0取得の3場を作る。
    引数: なし。
    返り値: tuple[dict,list,dict]は人工のmetadata・C0・V0 Source。
    """
    common, controls = {'scenes': []}, []
    source = {'success': True, 'trial': 141, 'scenes': []}
    for n in range(3):
        sid = '独立人工場' + str(n)
        start = n * 10000
        scene = {'session': sid, 'contract': '人工限月', 'start': start, 'end': start + 9000, 'force_close': start + 8000,
                 'raw': {'path': '未作成の人工Raw', 'sha256': '0' * 64}, 'expected_quality': {'人工': 1}, 'entries': []}
        common['scenes'].append(scene)
        quote = {'time': start + 102, 'index': 102, 'source_line': 103, 'clock': '人工価格時計', 'last': 1000,
                 'bid': 995, 'ask': 1005, 'quote_ok': True}
        if n == 0:
            controls.append({'id': '旧ID', 'session': sid, 'contract': '人工限月', 'side': 1, 'entryQuote': copy.deepcopy(quote), 'origins': [{'保存': True}]})
        events = []
        if n < 2:
            birth = {**quote, 'time': start + 101, 'index': 101, 'source_line': 102}
            events.append({'id': sid + '/V', 'side': -1, 'status': 'filled', 'entryQuote': quote, 'birth': birth, 'episode_id': sid + '/episode'})
        source['scenes'].append({'success': True, 'session': sid, 'contract': '人工限月', 'actual_sha256': '0' * 64,
                                 'counts': {'人工': 1}, 'stat_before': {'bytes': 1}, 'stat_after': {'bytes': 1}, 'events': events})
    return common, controls, source


# ----------------------------------------
def main() -> None:
    """
    機能: 4群の純人工で取得0場・優先alias・入力非改変・拒否境界を確認する。
    引数: なし。
    返り値: None。不一致時は停止し自然ファイルは読まない。
    """
    common, controls, source = fixture()
    original = copy.deepcopy((common, controls, source))
    fixed, meta = BRIDGE.build(common, controls, source)
    assert (common, controls, source) == original
    assert len(fixed['scenes']) == 3 and fixed['scenes'][2]['entries'] == [] and len(meta['sessions']) == 3
    assert fixed['expected_entry_count'] == len(meta['entries']) == 3 and len(meta['union']) == 2
    assert meta['union'][0]['canonical_id'] == 'C0/旧ID'
    assert set(meta['union'][0]['alias_sides'].values()) == {-1, 1}
    assert fixed['scenes'][0]['entries'][0]['side'] == 1
    fixed['scenes'][0]['entries'][0]['entry']['ask'] = 999999
    assert (common, controls, source) == original

    absent = copy.deepcopy(source)
    for scene in absent['scenes']:
        scene['events'] = []
    f, m = BRIDGE.build(common, [], absent)
    assert f['expected_entry_count'] == 0 and len(f['scenes']) == 3 and not m['union']

    for mode in ('取得1秒未満', '同物理行', '同原行価格改変', '限界等号'):
        altered = copy.deepcopy(source)
        event = altered['scenes'][0]['events'][0]
        if mode == '取得1秒未満':
            event['entryQuote']['time'] = event['birth']['time'] + 0.999
        elif mode == '同物理行':
            event['entryQuote']['source_line'] = event['birth']['source_line']
        elif mode == '同原行価格改変':
            event['entryQuote']['ask'] += 5
        else:
            event['entryQuote']['time'] = common['scenes'][0]['end'] - 3900
        try:
            BRIDGE.build(common, controls, altered)
        except AssertionError:
            pass
        else:
            raise AssertionError('拒否漏れ: ' + mode)
    print('独立転送人工4群成功。自然入力・金融は未読。')


if __name__ == '__main__':
    main()
