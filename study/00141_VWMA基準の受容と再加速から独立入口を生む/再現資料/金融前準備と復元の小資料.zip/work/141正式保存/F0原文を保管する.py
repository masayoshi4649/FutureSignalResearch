"""141の出生前F0原文と小型源だけを退避し、共有入力の復元参照を解決する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00141_*'))
RUN=ROOT/'work/141VWMA独立入口の評価'


def sha(raw: bytes) -> str:
    """
    機能: 原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def save(source: Path,target: Path,packed: bool=False) -> dict:
    """
    機能: 新規先だけへ原文又はgzipを保存する。
    引数: source/target(Path)、packed(bool)。
    返り値: dictは復元先/保存・解凍指紋。
    """
    raw=source.read_bytes();body=gzip.compress(raw,mtime=0) if packed else raw
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as f:f.write(body)
    return {'保存元':target.relative_to(ROOT).as_posix(),'復元先':source.relative_to(ROOT).as_posix(),'形式':'gzip' if packed else '同体',
        '保存bytes':len(body),'保存SHA256':sha(body),'解凍bytes':len(raw),'解凍SHA256':sha(raw)}


# ----------------------------------------
def main() -> None:
    """
    機能: F0全112源を新固定/共有/非複製へ分け、正式3MDを先行退避する。
    引数: なし。
    返り値: None。CSV/巨大入力/原板/実行体/自然結果/追加2場を読まない。
    """
    raw=(RUN/'F0出生前.json').read_bytes();expected='05e66573e55377e4d89b66fce2c00abaa4a247a04d1916de7b2ebff7b8cfaffb'
    assert sha(raw)==expected;f0=json.loads(raw);assert len(f0['ファイル'])==112
    save(RUN/'F0出生前.json',FORMAL/'検査/F0出生前.json')
    docs=[]
    for name,h in f0['ファイル'].items():
        p=Path(name)
        if p.suffix=='.md':
            body=p.read_bytes();assert sha(body)==h
            docs.append({'path':p.relative_to(ROOT).as_posix(),'sha256':h,'bytes':len(body),'本文':body.decode('utf-8')})
    snap={'試行':141,'段階':'出生前F0の原文をSource/金融結果の正式編集より先に退避','F0_SHA256':expected,
        '文書数':len(docs),'正式文書数':sum(d['path'].startswith('study/') for d in docs),'文書':docs,'F0の後造り':False}
    assert snap['正式文書数']==3
    p=FORMAL/'検査/F0実行前文書.json.gz'
    with p.open('xb') as out:out.write(gzip.compress((json.dumps(snap,ensure_ascii=False,indent=2)+'\n').encode('utf-8'),mtime=0))
    # ----------------------------------------
    prior133=next((ROOT/'study').glob('00133_*'));m133=json.loads((prior133/'保管索引.json').read_bytes());code=m133['固定コード']
    zip133=prior133/'再現資料'/code['ZIP'];assert sha(zip133.read_bytes())==code['ZIP_SHA256']
    registry={x['sha256']:x['path'] for x in code['格納源']}
    old138=json.loads(next((ROOT/'study').glob('00138_*/保管索引.json')).read_bytes())
    input_registry={x['復元先']:x for x in old138['共有入力']+old138['新共用入力']}
    csv=save(RUN/'CSV73参照.json',ROOT/'inputs/00141_VWMA独立入口/CSV73参照.json.gz',True)
    inputs=[csv];shared=[];new=[];bodies={};external=[];excluded=[]
    code_shared={'保存元ZIP':zip133.relative_to(ROOT).as_posix(),'ZIP_SHA256':code['ZIP_SHA256'],'格納源':[]}
    quality=json.loads((ROOT/'docs/根拠/全73場1分品質_20261112/F0.json').read_bytes())
    for name,h in f0['ファイル'].items():
        p=Path(name)
        if not p.is_relative_to(ROOT):
            assert p.suffix=='.csv' and quality['ファイル'][name]==h
            external.append({'path':name,'sha256':h,'用途':'共用原CSV。恒久品質F0と同体指紋、本文未複写/未読'});continue
        rel=p.relative_to(ROOT).as_posix()
        if rel==csv['復元先']:assert h==csv['解凍SHA256'];continue
        if rel=='work/122全場入力/入力.json' or p.suffix=='.exe':
            excluded.append({'path':rel,'sha256':h,'bytes':p.stat().st_size,'理由':'共有巨大入力又は実行体。既存入力差分/コードから復元・ビルドし複写しない'});continue
        if rel in input_registry:
            x=input_registry[rel];assert x['解凍SHA256']==h;shared.append(x);continue
        body=p.read_bytes();assert sha(body)==h and len(body)<1_000_000
        if h in registry:
            code_shared['格納源'].append({'復元先':rel,'ZIP内path':registry[h],'sha256':h,'bytes':len(body)})
        else:new.append({'path':rel,'sha256':h,'bytes':len(body)});bodies[rel]=body
    assert len(external)==73 and len(excluded)==3
    assert len(new)+len(shared)+len(inputs)+len(code_shared['格納源'])+len(external)+len(excluded)==112
    archive=FORMAL/'再現資料/141出生前の固定資料.zip';archive.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for x in new:z.writestr(x['path'],bodies[x['path']])
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for x in new:assert sha(z.read(x['path']))==x['sha256']
    code_shared['格納源数']=len(code_shared['格納源'])
    m={'試行':141,'段階':'F0出生前の原文と入力復元準備。自然/金融結果は未追記','F0_SHA256':expected,'F0直接源数':112,
        '追加固定資料':{'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(new),'格納源':new},
        '共有固定コード':code_shared,'共有入力':shared,'新共用入力':inputs,'共用CSV参照':external,'意図して複製しない固定源':excluded,
        '共有の原板参照':'inputs/00124_同入口正逆の共用入力/入力.json.gz。原板105恒久先とJP_OSE_Dataを元指紋で参照',
        '122巨大入力の復元':{'手順':'study/00122_E0固定条件を全セッションで検証する/再現資料/再現手順.md',
            'StageB':'study/00122_E0固定条件を全セッションで検証する/検査/StageB.json','SHA256':'6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec',
            '旧70入力':'study/00118_指値待機と複数技法の取得確認で入口を比較する/再現資料/再現手順.md',
            '新3差分':'inputs/00122_新規3場公表/新規公表.json.gz','新3差分SHA256':'39ccf4ff92bc03276839b899ec2e1a067c6570e140ecc3c66a445f0167125c42',
            '結合源':'study/00122_E0固定条件を全セッションで検証する/再現資料/122コード.zip','今回再生成/本文読取':False},
        'kernel共有源':old138['後段再現用の継承源'],'恒久品質監査':'docs/根拠/全73場1分品質_20261112/保管索引.json',
        '新Raw/巨大入力/実行体/CSV複写/自然結果参照':False,'正式README/条件/513セルの変更':False}
    (FORMAL/'保管索引.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    proof={'成功':True,'試行':141,'F0原文保存':True,'全MD':len(docs),'正式MD':3,'F0直接小型源':len(new),'共有コード源':len(code_shared['格納源']),
        '共有入力':len(shared),'新1gzip':1,'共用CSV非複製':73,'巨大入力/2exe非複製':3,'小型復元可能源数':112-73-3,
        '自然結果/金融/Raw/CSV価格/追加2場読取':False,'F0対象源の変更':False,'固定ZIP_SHA256':sha(archive.read_bytes()),'保管索引SHA256':sha((FORMAL/'保管索引.json').read_bytes()),'重大不足':[]}
    p=FORMAL/'検査/F0原文と源の保管確認.json';p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'保管確認SHA256':sha(p.read_bytes()),'新固定ZIP_SHA256':sha(archive.read_bytes()),'正式MD':3,'小型復元源':36},ensure_ascii=False))


if __name__=='__main__':main()
