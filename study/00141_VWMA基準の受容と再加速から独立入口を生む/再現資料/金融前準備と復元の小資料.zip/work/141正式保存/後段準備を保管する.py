"""141の自然結果を読まず、後段集計/独立人工と復元器を追加保管する。"""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00141_*'))


def sha(raw: bytes) -> str:
    """
    機能: 保存原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: F0直接源と別に、金融前準備/独立人工/保管源を小ZIPへ保存する。
    引数: なし。
    返り値: None。F0源変更・自然Source/金融/価格の読取はしない。
    """
    f0=json.loads((FORMAL/'検査/F0出生前.json').read_bytes());direct={Path(n).resolve() for n in f0['ファイル']}
    files=[]
    for folder in ['work/141独立入口とunionの集計','work/141窓と転送の独立準備レビュー','work/141正式保存']:
        for p in (ROOT/folder).iterdir():
            if p.is_file() and p.suffix in ('.py','.md','.json','.go') and p.resolve() not in direct:files.append(p)
    files += list((FORMAL/'再現資料').glob('*.py'))
    archive=FORMAL/'再現資料/金融前準備と復元の小資料.zip';entries=[]
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(set(files)):
            raw=p.read_bytes();assert len(raw)<1_000_000;name=p.relative_to(ROOT).as_posix();z.writestr(name,raw)
            entries.append({'path':name,'sha256':sha(raw),'bytes':len(raw),'区分':'F0直接源外。独立人工/後段金融前準備/保管/復元'})
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for e in entries:assert sha(z.read(e['path']))==e['sha256']
    p=FORMAL/'保管索引.json';m=json.loads(p.read_bytes())
    m['出生後段の準備資料']={'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(entries),'格納源':entries,
        '注記':'F0への後付けではない。集計準備proofの採用仕様SHAはRootの0量中間待機追補より前の段階で、その差はRoot固定で区別する'}
    p.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'準備ZIP源数':len(entries),'準備ZIP_SHA256':m['出生後段の準備資料']['ZIP_SHA256']},ensure_ascii=False))


if __name__=='__main__':main()
