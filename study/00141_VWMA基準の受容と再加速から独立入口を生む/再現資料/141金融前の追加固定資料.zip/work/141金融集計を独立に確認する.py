"""141の300比較を保存観測から再計算する。作者集計関数はimportしない。"""
from pathlib import Path
from collections import Counter
import argparse
import hashlib
import json
import math


def sha(path: Path) -> str:
    """
    機能: 保存ファイルの指紋を求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def calculate(cases: list[tuple], reverse: bool, axis: str, horizon: int, width: int) -> dict:
    """
    機能: H完了先着と、既知の最初到達又は期限気配によるIFD代用を再計算する。
    引数: cases(list[tuple])、reverse(bool)、axis(str)、horizon/width(int)は保存観測と設定。
    返り値: dictは独立に導いた主要計数・率・費用後金額。
    """
    counts = Counter(); money = []; points = []; reasons = Counter(); completed = 0; known = 0
    for sid, case in cases:
        stream = case[('chart_' if axis == 'Last' else '') + ('reverse' if reverse else 'original')]
        outcome = next(x for x in stream['outcomes'] if x['seconds'] == horizon)
        first = next(x for x in outcome['touches'] if x['width'] == width)
        if outcome['status'] == 'complete':
            completed += 1
            counts[first['direction']] += 1
        exit_quote = first['quote'] if first['direction'] else outcome['endpoint'] if outcome['status'] == 'complete' else None
        if exit_quote is None:
            reasons['観測不足'] += 1
            continue
        known += 1
        reasons['順行到達' if first['direction'] == 1 else '逆行到達' if first['direction'] == -1 else '期限清算'] += 1
        direction = stream['birth']['side']
        mark = exit_quote['last'] if axis == 'Last' else exit_quote['bid'] if direction == 1 else exit_quote['ask']
        point = direction * (mark-stream['entry_price'])
        points.append(point)
        if axis == 'BBO': money.append(point*100-1077)
    forward, adverse = counts[1], counts[-1]
    gains = sum(x for x in money if x > 0); losses = -sum(x for x in money if x < 0)
    return {'entries': len(cases), 'sessions': len({s for s, _ in cases}), 'complete': completed,
        'censored': len(cases)-completed, 'forward': forward, 'adverse': adverse, 'neither': counts[0],
        'resolved': forward+adverse, 'resolved_rate': forward/(forward+adverse) if forward+adverse else None,
        'complete_rate': forward/completed if completed else None,
        'target70': forward/(forward+adverse) >= .7 if forward+adverse else None,
        'target70_all': forward/completed >= .7 if completed else None,
        'ifd_known': known, 'ifd_unknown': len(cases)-known, 'ifd_exits': dict(reasons),
        'ifd_net0_sum': sum(money)+known*1000 if money else None,
        'ifd_net5_sum': sum(money) if money else None,
        'ifd_net5_profit': gains if money else None, 'ifd_net5_loss': losses if money else None,
        'ifd_net5_mean': sum(money)/len(money) if money else None,
        'ifd_net5_pf': gains/losses if losses else None,
        'ifd_net5_positive': sum(x > 0 for x in money) if axis == 'BBO' else None,
        'ifd_points_mean': sum(points)/len(points) if points else None,
        'flips': len(cases) if reverse else 0}


# ----------------------------------------
def main() -> None:
    """
    機能: 指紋付きの金融出力・参照を読み300比較の全統計値と参加・頻度を照合する。
    引数: CLI --folder(Path)は141実行先、--output(Path)は未作成の検算記録。
    返り値: None。自然価格を再走査せず、旧結果・現集計を書き換えない。
    """
    parser = argparse.ArgumentParser(description='141金融集計の独立検算')
    parser.add_argument('--folder', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(); own = args.folder
    paths = {'f1': own/'F1金融前.json', 'fixed': own/'固定入力/固定取得入力.json',
             'meta': own/'固定入力/入口参照.json', 'paired': own/'固定取得の正逆観測.json',
             'summary': own/'金融評価/集計.json'}
    hashes = {k: sha(p) for k, p in paths.items()}
    f1, fixed, meta, paired, summary = [json.loads(paths[n].read_bytes()) for n in ('f1','fixed','meta','paired','summary')]
    assert f1['試行'] == summary['試行'] == meta['trial'] == 141 and paired['trial'] == 133
    assert summary['F1_SHA256'] == hashes['f1'] and summary['自然結果SHA256'] == hashes['paired']
    assert meta['fixed_input_sha256'] == paired['input_sha256'] == hashes['fixed']
    assert all(f1['ファイル'][str(paths[n].resolve())] == hashes[n] for n in ('fixed', 'meta'))
    entries = {e['id']: e for e in meta['entries']}
    cases = {c['id']: (s['session'], c) for s in paired['scenes'] for c in s['cases']}
    assert set(entries) == set(cases) and len(cases) == fixed['expected_entry_count']
    members = {'C0': {k for k, e in entries.items() if e['model'] == 'C0'},
               'V0': {k for k, e in entries.items() if e['model'] == 'V0'},
               'U0': {u['canonical_id'] for u in meta['union']}}
    sessions = [s['session'] for s in fixed['scenes']]
    assert sessions == meta['sessions'] and len(sessions) == 73
    checked = 0; comparisons = 0
    for part, ids in (('all',sessions),('train',sessions[:48]),('validation',sessions[48:])):
        hours = sum((s['end']-300-s['start'])/3600 for s in fixed['scenes'] if s['session'] in ids)
        for policy in ('C0','V0','U0','RV','RU'):
            model = {'RV':'V0','RU':'U0'}.get(policy, policy)
            selected = [cases[k] for k in members[model] if cases[k][0] in ids]
            present = {sid for sid, _ in selected}
            participation = summary['参加'][part][model]
            assert participation['取得数'] == len(selected) and participation['全場最低1取得'] == (len(present) == len(ids))
            assert math.isclose(summary['頻度'][part][model]['全時間平均件数毎時'],len(selected)/hours,rel_tol=1e-12)
            for axis in ('BBO', 'Last'):
                for horizon in (1800, 3600):
                    for width in (25, 50, 100, 125, 200):
                        expected = calculate(selected, policy in ('RV','RU'), axis, horizon, width)
                        actual = summary['集計'][part][policy][axis][str(horizon)][str(width)]
                        assert set(expected) == set(actual), (policy, set(expected)^set(actual))
                        for key, value in expected.items():
                            if isinstance(value, float): assert math.isclose(value,actual[key],rel_tol=1e-12,abs_tol=1e-9),(part,policy,axis,horizon,width,key)
                            else: assert value == actual[key], (part,policy,axis,horizon,width,key,value,actual[key])
                            checked += 1
                        comparisons += 1
    assert comparisons == 300
    assert all(sha(p) == hashes[k] for k,p in paths.items())
    result = {'成功': True, '試行': 141, '比較数': comparisons, '統計セル数': checked,
              '全73場': True, '参加と頻度': True, '作者関数import': False, '自然原板再走査': False,
              '入力': {str(p.resolve()): hashes[k] for k,p in paths.items()}}
    with args.output.open('x',encoding='utf-8',newline='\n') as out:
        json.dump(result,out,ensure_ascii=False,indent=2);out.write('\n')
    print(json.dumps(result,ensure_ascii=False))


if __name__ == '__main__':
    main()
