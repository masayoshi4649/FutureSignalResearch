# 115：三時間軸と方向性の純公開wrapper

module `github.com/masayoshi4649/SessionTradeExecuter/threeframe115`、package `threeframe115`。停止済み旧threeframeのFrame全文を変えず、DMI/ADXと直前3本5分構造だけを別項目へ加える。CSV本文読取は依存のthreeframeinputをRootが別に行い、本部品は子足の値だけを受け取る。Source111/111保護bank/P100/原文戦略は変更しない。

## 公開API

- `BeginSession(old.Session, []old.ChildBar, *Seed) (*Bank,error)`
- `AdvanceObserved(at float64, ordinal uint64) ([]Frame,error)`
- `SnapshotAt(at float64) (Snapshot,error)`、`Snapshot.Scale(width int) (ScaleSnapshot,bool)`
- `Seal() (Seed,Snapshot,error)`、`Seed.Info() SeedInfo`
- `DeclaredDefinition() Definition`

`Frame{Frame old.Frame,DMI DMI,Structure Structure}`。DMIはPlusDI/MinusDI/DX/ADXとPreviousPlusDI/PreviousMinusDI/PreviousADXを`Value{Known,Value}`で持つ。StructureはKnown/High/Low/Refs[3]を持つ。当場のasof/HasCurrent/Fresh/SeedOnlyは旧Snapshotと同じで、seed数値が既知なだけでは当場値を公開しない。

接続は各Source受理原行で`AdvanceObserved(Stamp.Time,uint64(Stamp.Index)+1)`→`SnapshotAt(Stamp.Time)`→新規要求評価の順とする。bankのRecordOrdinalは物理行そのものではなく、Coreの受理Index+1へ明示結合する。CurrentPriceTime同値のSourceLine/IndexはCoreの配送stampが別保存する。同秒後行の公表を前の出生へ使わない。売買用Snapshotでは未来EOF/SealedをRootが伏せる。

## DMIの数値契約

各5/15/30分で別状態を持つ。最初の足は前高安終値だけ保存し、14個の価格変化からDM/TRの初期SMAを作る。以後RMA14。`up=High−前High`、`down=前Low−Low`について、up>downかつup>0なら+DM=up、down>upかつdown>0なら−DM=down、他は両0。outsideで3/1なら+3、同幅1/1とinside両負は両0。

TRは前終値を含む通常の最大3幅。平滑TR>0かつ平滑DM和>0のときだけDI/DXを既知とし、14連続の既知DXからADXを作る。TR=0又はDM和=0なら当足DMI/ADXは未知、ADX用連続DX窓をresetする。古いADXを現在値へ据え置いたり、未定義DXを飛ばして平均したりしない。最短DIは15足、ADXは28足。直前値は直前公表のKnownも含めて保持する。RにADX上昇を要求する処理や入口の採否は持たない。

価格未知Frameはその尺度のDMI数値を全resetする。量だけ未知では価格数値をresetしない。数値更新は候補を検査してから旧/追加状態を一括commitし、非有限やDI/ADX範囲外で部分公表しない。

## 構造とseed

5分足だけ、現在足を加える前の直前3連続・当場価格既知足の最大High/最小Lowを返す。refsはID/Start/End/PublishedAt。最初の利用は当場4本目の5分公表で、現在足と未来足の極値は入らない。価格欠測・非連続・場替わりでcold。旧pivotの右2足確認や旧Frame.Prior/Newは変更しない。

Seedは旧sealed種＋DMIの私有数値だけを値copyする。同限月ならcarry、別限月はcold。DMIの前高安終値も数値種なので場間差を次のDM/TRへ含み得る。公開履歴・当場mask・構造窓は継承しない。Seed.Infoは旧Info、各尺度の全DMI stateSHA、履歴本数/連続DX本数を保存する。前場種から二つの後継を作っても可変状態を共有しない。

115のRoot前史案は、宣言した過去CSV場を予定Endまで足終+60モデルで公表する別計画。当場tradeの実原行EOFとは別であり、Source111のRawEOFから同体に作った種とは主張しない。End+60>予定Endの末尾足は種に入らない。本wrapper自身は前史ファイルの選択や市場実行を行わない。

## 人工と停止

旧全Frame同体、線形3尺度の解析解、DI15/ADX28足、鏡像/直前値、TR0/DM和0/同幅、14DX再助走、現在を除く3本、欠足/量未知、同限月carry/current mask/roll、遅配/同秒/過去asof/copy/Seal、追加失敗の原子性、別言語Decimal70桁の非線形ADX、未来末尾非干渉を確認する。`TestExportArtificial`は定義と手製買売の成熟値を未作成先だけへ保存する。

```powershell
go test -count=1 -v ./...
go vet ./...
go build ./...
python -X utf8 検査して停止する.py --output <未作成検査folder>
```

この成功は市場指標の形成・入口優位・実約定の証明ではない。実Raw/CSV/Native/11月09本文と損益は読まず、固定済み旧コードを編集しない。
