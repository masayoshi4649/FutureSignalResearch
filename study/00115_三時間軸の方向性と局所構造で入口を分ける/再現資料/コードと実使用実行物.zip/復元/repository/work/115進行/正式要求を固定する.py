"""全70の成功参照を認証して115の正式保存要求を固定する。"""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def ref(relative: str, expected: str | None = None) -> dict:
    """
    機能: 明示したファイルのSHA256を算出し必要時に期待値を確認する。
    引数: relative(str)はrepo相対位置、expected(str|None)は事前確認した指紋。
    返り値: dictは絶対pathとsha256。市場の原板や価格CSVは指定しない。
    """
    path = (ROOT / relative).resolve()
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert expected is None or digest == expected, relative
    return {"path": str(path), "sha256": digest}


def main() -> None:
    """
    機能: 金融条件を変えず、正式化と再現に必要な成功資料を新要求へ結ぶ。
    引数: なし。
    返り値: None。要求を新規保存し絶対pathとSHA256を表示する。
    """
    material = ROOT / "work/115正式保存への接続/Root正式要求の素材.json"
    data = json.loads(material.read_text(encoding="utf-8-sig"))
    data.update(fixed=True, market_native_read_authorized=True)
    bindings = {
        "market": ("work/115金融F1/全70場/完了.json", "8bba68dfa7df62d2fa7f40443e4a3cd89f48caa7ed398560ca1ee914e59e714b"),
        "result": ("work/115独立保存F1/全70場/結果.json", "b4d9df3568098a73d38a670a9cca7a7dc0e6b4d79fe07a8ae8dd21d9cf6293df"),
        "saved_check": ("work/115独立保存F1/全70場/保存会計の確認.json", "9781d80ca7213e541317f317c3b95c562111ec1590b435686e1682952444e730"),
        "entry_check": ("work/115入口独立F1/全70場/結果.json", "a81d51508228a3e048d4b1241e299b9daac8afc6ea100c32c5e846980dba428e"),
        "price_request": ("work/115進行/full70_価格足DMI独立要求.json", "7d1b23240ebbaaa566de4aa6743fb90811dd668eb81662757cb1769523815d0f"),
        "price_check": ("work/115価格足DMI独立F1/全70場/結果.json", "e2f7e62cbdd1cb9c11251d9fac630e7cce2b320ba1716f9b211d021c552d39ca"),
        "csv_check": ("outputs/01a1889f-f2af-7943-a047-543275ee9ed2/115損益CSV/CSVの独立再読.json", "0dd9116ce806096c16e37ec564cc481c6623ab7a2cebb a935d5c37b159e30d2f".replace(" ", "")),
        "diagnostic_stop": ("work/115同入口と三時間軸の実現差/停止.json", "f6191f67b5297696950373f83c2f19d1ca0efed20d70c7c9bc6a9f47ff38cbb1"),
    }
    for key, value in bindings.items():
        data["refs"][key] = ref(*value)
    data.pop("Rootが成功後にbindする必須Ref", None)
    data["csv_refs"] = {
        name: ref("outputs/01a1889f-f2af-7943-a047-543275ee9ed2/115損益CSV/" + name, expected)
        for name, expected in (
            ("候補別集計.csv", "293eb7e6cc6ea7837ec07a7ba226718a5c65cd059bed2381a6da6d7060694134"),
            ("全セッション.csv", "8aef25abd16cf5c77023b1ddeab8e7b67b858acdd38682441456bc347c114826"),
        )
    }

    # ----------------------------------------
    # 診断の実行閉包とRootの後段準備コードを結ぶ。
    stopped = json.loads(Path(data["refs"]["diagnostic_stop"]["path"]).read_text(encoding="utf-8-sig"))
    for path, digest in stopped["依存コードと手製SHA256"].items():
        candidate = Path(path)
        if candidate.suffix in (".py", ".go", ".mjs", ".ps1", ".md") or candidate.name == "停止.json":
            data["code_refs"].append({"ref": {"path": path, "sha256": digest}, "role": "停止済み22対照診断の依存コード。巨大な手製JSONは参照のみ。"})
    for relative in (
        "work/115進行/同入口診断要求を固定する.py",
        "work/115進行/結果表の要求を固定する.py",
        "work/115進行/正式要求を固定する.py",
        "work/115専用Viewer8099/Viewer取得を確認する.py",
        "work/115専用Viewer8099/conf/viewer.toml",
    ):
        data["code_refs"].append({"ref": ref(relative), "role": "Root後段の実使用コード。Viewer HTTP検査は正式保存後に別確認する。"})

    # ----------------------------------------
    # 全件二重転記を避け、小検査と圧縮診断だけを正式先へ保存する。
    extras = [
        ("work/115同入口と三時間軸の実現差/全70の実現差/結果.json", "診断/同入口と費用差の結果.json"),
        ("work/115同入口と三時間軸の実現差/全70の実現差/全場と役割の詳細.json.gz", "診断/全場と役割の詳細.json.gz"),
        ("work/115同入口と三時間軸の実現差/全70の実現差/実entry対応.json.gz", "診断/実entry対応.json.gz"),
        ("outputs/01a1889f-f2af-7943-a047-543275ee9ed2/115損益CSV/CSVの確認.json", "検査/CSVの生成確認.json"),
        ("work/115設定表の結果結合準備/全70結果版/結合の確認.json", "検査/設定表の結合確認.json"),
        ("work/115金融F1/先頭2場/完了.json", "検査/先頭2金融成功.json"),
        ("work/115入口独立F1/先頭2場/結果.json", "検査/先頭2入口独立確認.json"),
        ("work/115独立保存F1/先頭2場/保存会計の確認.json", "検査/先頭2独立保存確認.json"),
        ("work/115価格足DMI独立F1/先頭2場/結果.json", "検査/先頭2価格足DMI確認.json"),
        ("work/115独立保存F1/元54場/保存会計の確認.json", "検査/元54独立保存確認.json"),
    ]
    for relative, target in extras:
        data["extra_refs"].append({"ref": ref(relative), "target": target, "role": "Rootで成功を確認した実検査または圧縮した実現差の根拠。"})
    for path in sorted((ROOT / "work/115進行").glob("*_要求*.json")):
        data["extra_refs"].append({"ref": ref(str(path.relative_to(ROOT))), "target": "検査/Root要求/" + path.name, "role": "各段階の実使用Root要求。"})
    # 命名が異なる要求も欠落させない。
    already = {item["ref"]["path"] for item in data["extra_refs"]}
    for path in sorted((ROOT / "work/115進行").glob("*_*.json")):
        if "要求" in path.name and str(path) not in already:
            data["extra_refs"].append({"ref": ref(str(path.relative_to(ROOT))), "target": "検査/Root要求/" + path.name, "role": "各段階の実使用Root要求。"})
    data["注意"] = [
        "全70金融・独立840・入口840・価格足DMI70・CSV二点全セル再読の成功後に固定した。",
        "金融条件F1と停止コードを変更しない。Viewer/報告の最終確認は後段の別証拠。",
        "11/09未読。採用false・研究目標達成false。",
    ]
    for item in data["code_refs"] + data["extra_refs"]:
        value = item["ref"]
        assert hashlib.sha256(Path(value["path"]).read_bytes()).hexdigest() == value["sha256"]
    target = Path(__file__).parent / "full70_正式保存要求.json"
    with target.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(ref(str(target.relative_to(ROOT))), ensure_ascii=False))


if __name__ == "__main__":
    main()
