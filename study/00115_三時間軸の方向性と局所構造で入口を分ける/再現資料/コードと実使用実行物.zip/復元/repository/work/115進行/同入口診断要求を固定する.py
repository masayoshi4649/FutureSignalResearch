"""115の全70金融・会計・入口の成功後にだけ22対照の実現差診断を固定する。"""

import argparse
import hashlib
import json
from pathlib import Path


def reference(path: Path, expected: str) -> dict:
    """機能: 指定した小metadata又は独立結果を指紋認証する。

    引数: path(Path)、expected(str)は対象と期待SHA256。
    返り値: dictは絶対path/SHA256。Native/Raw/CSV本文には使わない。
    """
    path = path.resolve()
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    assert actual == expected, str(path)
    return {"path": str(path), "sha256": actual}


def main() -> None:
    """機能: 全70の成功を確認し、固定した実取引比較の新要求を作る。

    引数: CLI result_sha/saved_sha(str)は成功独立結果と会計確認の指紋。
    返り値: None。市場再生・閾値探索・退出後の仮損益は行わない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--result-sha", required=True)
    parser.add_argument("--saved-sha", required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    here = Path(__file__).resolve().parent
    template = root / "work/115同入口と三時間軸の実現差/Root要求ひな形_未固定.json"
    reference(template, "d366fc379b2f3b4d2795578bccd665956224c74c081e6d4bd5587f9589e35bbd")
    request = json.loads(template.read_text(encoding="utf-8"))
    assert request["fixed"] is False and request["market_native_read_authorized"] is False and request["legacy114_read_authorized"] is False
    values = {
        "completion": reference(root / "work/115金融F1/全70場/完了.json", "8bba68dfa7df62d2fa7f40443e4a3cd89f48caa7ed398560ca1ee914e59e714b"),
        "entry_check": reference(root / "work/115入口独立F1/全70場/結果.json", "a81d51508228a3e048d4b1241e299b9daac8afc6ea100c32c5e846980dba428e"),
        "saved_result": reference(root / "work/115独立保存F1/全70場/結果.json", args.result_sha),
        "saved_check": reference(root / "work/115独立保存F1/全70場/保存会計の確認.json", args.saved_sha),
    }
    for key, item in values.items():
        obj = json.loads(Path(item["path"]).read_text(encoding="utf-8"))
        assert obj.get("success", obj.get("成功")) is True
        assert obj.get("sessions", obj.get("場数")) == 70
        assert obj.get("books", obj.get("会計数")) == 840
        request[key] = item
    request.update({"fixed": True, "market_native_read_authorized": True, "legacy114_read_authorized": True})
    destination = here / "full70_同入口診断要求.json"
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(request, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    digest = hashlib.sha256(destination.read_bytes()).hexdigest()
    print(json.dumps({"path": str(destination), "sha256": digest}, ensure_ascii=False))


if __name__ == "__main__":
    main()
