"""115の事前仮説と版6の56手法×9尺度を新規試行へ保存する。"""

import hashlib
import json
import os
import re
from pathlib import Path


def main() -> None:
    """機能: 元条件を変えず、115の事前文書と使用セルを新規に作る。

    引数: なし。固定済み114と版6の教材表だけを読む。
    返り値: None。市場/Raw/Native/価格CSVを読まず、金融条件は固定しない。
    """
    root = Path(__file__).resolve().parents[2]
    folder = root / "study/00115_三時間軸の方向性と局所構造で入口を分ける"
    assert not folder.exists(), "試行番号の再利用は禁止"
    folder.mkdir()
    template = root / "docs/議論/手法と時間スケールの汎用表_版6.md"
    original = template.read_text(encoding="utf-8")
    body = original.split("## 手法×時間スケール", 1)[1].split("## 設定明細", 1)[0]
    body = body.replace("全セルは未設定・未検証。", "使用セルは下記の設定IDへ対応。新候補の実市場結果は未検証。")
    body = body.replace("未設定・未検証", "追加未使用")
    cells = {
        ("I01", 2): "S05/S06：3分保護の形成・C診断→全R",
        ("I01", 3): "S22：EMA8/21準備のみ",
        ("I01", 4): "S22：EMA8/21準備のみ",
        ("I01", 5): "S18：s×(EMA8−21)符号→R05〜12",
        ("I03", 2): "S07：MACD-H増分M→全R狭幅",
        ("I04", 2): "S05：準備のみ",
        ("I05", 2): "S08：BB20±2幅縮小は診断のみ",
        ("I08", 3): "S19：DMI14準備・診断のみ",
        ("I08", 4): "S19：DI差>0・TのみADX>=20→R05〜12",
        ("I08", 5): "S19：DMI14準備・診断のみ",
        ("I09", 3): "S04源ATR12保護幅／S21前ATR14×2警戒→全R/R05〜12",
        ("I15", 2): "S09：前5足H−L中央値・最小5→全R狭幅",
        ("C04", 4): "S19：方向と偏りを分担→R05〜12",
        ("C06", 0): "S12〜15：H100・M AND P可変追尾→全R",
        ("C07", 3): "S20/S21/S22：局所突破と保持→R05〜12",
        ("C07", 4): "S19/S22：中期方向→R05〜12",
        ("C07", 5): "S18/S22：長い配置背景→R05〜12",
        ("P02", 2): "S10/S11：動的P・構造床→全R",
        ("P03", 2): "S10/S11：公表済みpivot→全R",
        ("P07", 3): "S20：現在足を除く前3本高安のClose突破→R05〜12",
        ("B01", 0): "S03/S15：正常BBO・厳密後原行→全R",
        ("E01", 0): "旧125/250先着は今回の合否対象外",
        ("E02", 0): "S12〜16：一定費用後益で必須追尾・場内完結→全R",
    }
    rows = []
    count = 0
    for line in body.splitlines():
        if re.match(r"^\| [ICPBVXME]\d{2} \|", line):
            parts = [x.strip() for x in line.strip().strip("|").split("|")]
            assert len(parts) == 11
            count += 1
            for scale in range(9):
                if (parts[0], scale) in cells:
                    parts[scale + 2] = cells[(parts[0], scale)]
            line = "| " + " | ".join(parts) + " |"
        rows.append(line)
    assert count == 56
    body = "\n".join(rows)
    # ----------------------------------------
    # 元表のローカル出典を、新試行から同じファイルへ到達する相対位置へ変換する。
    def relocate(match: re.Match) -> str:
        """機能: 教材のリンク先だけを保存先に合わせる。

        引数: match(re.Match)はMarkdownリンク。
        返り値: strは元と同じ参照先を持つリンク。
        """
        label, target = match.groups()
        if target.startswith(("http:", "https:", "#")):
            return match.group(0)
        destination = (template.parent / target).resolve()
        return f"[{label}]({Path(os.path.relpath(destination, folder)).as_posix()})"
    body = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", relocate, body)
    old = (root / "study/00114_順行と反転の取得確認を分ける/設定と結果.md").read_text(encoding="utf-8")
    common = []
    for line in old.splitlines():
        if re.match(r"^\| S(?:0[1-9]|1[0-7]) \|", line):
            if line.startswith("| S05 "):
                line = "| S05 | 保護専用3分/15分bank111 | 既存保護を据置 | 当場cold・EMA8/21、MACD12/26/9、RSI14、ATR14 | P100へ3分だけ配送 | 全R | 入口5/15/30分bankと別所有。追加seedを保護へ入れない |"
            elif line.startswith("| S07 "):
                line = line.replace("入口はS18/S19の水準/増分で別判定", "115入口にはHist条件を課さない")
            elif line.startswith("| S16 "):
                line = line.replace("子processも一場cold", "子processの保護はcold、入口前史はS22")
            elif line.startswith("| S17 "):
                line = line.replace("全70場・12条件・840会計の金融・独立会計/保護・入口票検算成功", "新条件は市場未実行。正益経験玉を分母にした最終赤字率も記録")
            common.append(line)
    assert len(common) == 17
    settings = """| 設定ID | 手法・尺度 | 役割 | 計算と閾値 | 時計と未知 | 対象 | 注記 |
| --- | --- | --- | --- | --- | --- | --- |
""" + "\n".join(common) + """
| S18 | I01・30分 | 長い終値背景 | G30=s×(EMA8−EMA21)。Tは>0、Rは<0 | G=0は既知偽、未知はunknown | R05〜12、A0も診断 | 同足1本傾きは追加票にしない |
| S19 | I08/C04・15分 | 高安の方向と偏り | D15=s×(+DI14−−DI14)>0。TのみADX14>=20 | 14変化でDI、14有効DXでADX。TR/DM和0は未知、DX窓reset | R05〜12、A0も診断 | RへADX閾値・ADX増分・直近DI交差は必須化しない |
| S20 | P07・5分 | 局所構造を越えた確認 | boundary=前3本High最大/Low最小、s×(確定Close−boundary)>0 | 現在足を含めず当場連続3本。欠足は未知 | R05〜12、A0も診断 | 一つの最新fresh公表を複数出生が参照可 |
| S21 | I09/P07・5分/原行 | 急変警戒と水準保持 | 前ATR14>0、TR5<=2×前ATR14、s×(要求時Last−boundary)>0 | 前ATR0は既知偽、未知は不足。Last等号は偽 | R05〜12、A0も診断 | 2倍は独自の未検証警戒値。正常BBO/fillと別 |
| S22 | 5/15/30分の時計と前史 | 入口専用の数値種・当場公表 | 固定過去CSVを予定Endまで足終+60秒モデルで公開し同限月数値継承。当場構造/公表はcold | 当場はRaw原行までだけ配送、fresh=要求時計−AvailableAt<各足幅。seedOnly不可、要求原行で一回freeze | 全R | 前史は次場開始前に取得済みとの仮定。Source/保護の実EOF同体とは異なる。末尾未公表足はseedへ不使用 |
| S23 | 複合・分母・対照 | 新入口と共通保護の分離 | A0/T/TR×C0/C5×D0/D1の12、基準A0は旧114A0四費用と金融/P100全State・Source全文を照合 | first2→base54→full70。同条件base54成功を全70で参照再用。未知は不許可、欠測を分母から消さない | 全R、市場未実行 | 実取引の純額/利益/損失/正益後赤字率/DD/回数。未参加・退出後の仮想利益を作らない |
"""
    results = ["| 評価ID | 候補 | 設定 | 結果 |", "| --- | --- | --- | --- |"]
    for number, (mode, cost, delay) in enumerate(((m, c, d) for m in ("A0", "T", "TR") for c in (0, 5) for d in (0, 1)), 1):
        results.append(f"| R{number:02d} | {mode}_C{cost}_D{delay} | S01〜23。共通P100、入口{mode} | 未固定・市場未実行 |")
    text = "# 00115：設定と結果\n\n2026-11-10。汎用表・版6（56手法×9尺度）をコピー。新条件は未固定・市場未実行、収益性・採用は未確認。\n\n## 手法×時間スケール\n" + body + "\n\n## 設定明細\n\n" + settings + "\n## 複合条件と結果\n\n" + "\n".join(results) + "\n"
    (folder / "設定と結果.md").write_text(text, encoding="utf-8", newline="\n")
    manifest = {"試行": 115, "状態": "事前案・未固定・市場未実行", "原表": {"path": str(template), "sha256": hashlib.sha256(template.read_bytes()).hexdigest()}, "手法": count, "尺度": 9, "設定": 23, "結果行": 12}
    (folder / "準備の確認.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False))


if __name__ == "__main__":
    main()
