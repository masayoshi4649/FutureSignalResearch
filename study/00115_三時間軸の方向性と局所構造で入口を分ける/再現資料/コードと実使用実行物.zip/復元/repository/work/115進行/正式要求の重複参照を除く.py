"""保存前検査で拒否されたRoot要求の参照重複だけを別要求で取り除く。"""

import hashlib
import json
from pathlib import Path


def main() -> None:
    """
    機能: refsへ既に含めたextraだけを除き、新要求と訂正理由を保存する。
    引数: なし。
    返り値: None。金融条件・コード・成果物は変更しない。
    """
    folder = Path(__file__).resolve().parent
    original = folder / "full70_正式保存要求.json"
    digest = hashlib.sha256(original.read_bytes()).hexdigest()
    assert digest == "1a160a6f37dc88bfd504f20d7db0d1c6a9488db60007b79f127d68c80e22371f"
    data = json.loads(original.read_text(encoding="utf-8"))
    existing = {item["path"] for item in data["refs"].values()}
    removed = [item for item in data["extra_refs"] if item["ref"]["path"] in existing]
    assert len(removed) == 1 and removed[0]["ref"] == data["refs"]["price_request"]
    data["extra_refs"] = [item for item in data["extra_refs"] if item["ref"]["path"] not in existing]
    proof = folder / "正式要求の参照一意化.json"
    value = {"試行": 115, "成功": True, "初回要求": {"path": str(original), "sha256": digest},
             "最初の検査": "metadata-onlyで価格足DMIのRoot要求をrefsとextraへ重複指定したため拒否。正式書込みなし。",
             "除いた重複": removed, "金融条件変更": False, "停止コード変更": False, "金融再実行": False}
    with proof.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    data["extra_refs"].append({"ref": {"path": str(proof), "sha256": hashlib.sha256(proof.read_bytes()).hexdigest()},
                               "target": "検査/正式要求の参照一意化.json", "role": "Root要求の二重転記だけを訂正した証拠。"})
    current = Path(__file__).resolve()
    data["code_refs"].append({"ref": {"path": str(current), "sha256": hashlib.sha256(current.read_bytes()).hexdigest()},
                              "role": "金融条件を変えず正式要求の参照重複だけを除いたRoot補足。"})
    target = folder / "full70_正式保存要求_参照一意.json"
    with target.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"path": str(target), "sha256": hashlib.sha256(target.read_bytes()).hexdigest()}, ensure_ascii=False))


if __name__ == "__main__":
    main()
