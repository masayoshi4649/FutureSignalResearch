"""成功した115金融段階だけを独立入口の新固定要求へ接続する。"""

import argparse
import hashlib
import json
from pathlib import Path


def reference(path: Path, expected: str | None = None) -> dict:
    """機能: 明示した小metadataを指紋認証する。

    引数: path(Path)、expected(str|None)は対象と期待指紋。
    返り値: dictは絶対pathとSHA256。Native/Raw/CSV本文には用いない。
    """
    path = path.resolve()
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert expected is None or expected == digest, str(path)
    return {"path": str(path), "sha256": digest}


def main() -> None:
    """機能: 未作成・不成功の段階を拒否し、Rootの入口読取範囲を固定する。

    引数: CLIのstage(str)、completion(Path)、sha256(str)。
    返り値: None。金融・独立本実行は別の停止CLIから行う。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("first2", "base54", "full70"), required=True)
    parser.add_argument("--completion", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    here = Path(__file__).resolve().parent
    template = root / "work/115入口判定を独立検算する/検査/Root要求ひな形_未固定.json"
    reference(template, "0c781eeba67389ffb5cabf08334f2c2662622ae99c2e11eedd1387d994ec73c1")
    request = json.loads(template.read_text(encoding="utf-8"))
    assert request["fixed"] is False and request["market_native_read_authorized"] is False
    reference(Path(request["condition"]["path"]), "94bb656a1607d59039a0c5ec0f06968a4da72463d27c0847606a09fc52fc4693")
    for key in ("entry_code", "entry_stop"):
        reference(Path(request[key]["path"]), request[key]["sha256"])
    completion = reference(args.completion, args.sha256)
    market = json.loads(args.completion.read_text(encoding="utf-8"))
    count = {"first2": 2, "base54": 54, "full70": 70}[args.stage]
    assert market["success"] and market["trial"] == 115 and market["stage"] == args.stage
    assert market["sessions"] == count and market["books"] == count * 12
    assert market["condition_sha256"] == request["condition"]["sha256"]
    assert market["all_reference114_equal"] and market["all_source111_equal"] and market["unchanged"]
    assert all(row["complete"] and row["open_quantity"] == row["pending_quantity"] == 0 for row in market["results"])
    request.update({"fixed": True, "market_native_read_authorized": True, "stage": args.stage, "completion": completion})
    destination = here / f"{args.stage}_入口独立要求.json"
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(request, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps(reference(destination), ensure_ascii=False))


if __name__ == "__main__":
    main()
