"""115の市場前成功コード・実宣言と原文を、新しい金融条件へ固定する。"""

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def ref(path: Path, expected: str | None = None) -> dict:
    """機能: 明示コード・小metadata・事前文書を認証する。

    引数: path(Path)、expected(str|None)は対象と任意の期待指紋。
    返り値: dictは絶対位置とSHA256。市場入力本文は対象外。
    """
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    assert expected is None or expected == actual, str(path)
    return {"path": str(path.resolve()), "sha256": actual}


def main() -> None:
    """機能: 新固定F1と、研究根拠の不変原文を新規保存する。

    引数: なし。Rootが成功を確認した115停止素材を使う。
    返り値: None。金融/Raw/Native/価格CSV/11月09の読取・実行はない。
    """
    root = Path(__file__).resolve().parents[2]
    here = Path(__file__).resolve().parent
    study = root / "study/00115_三時間軸の方向性と局所構造で入口を分ける"
    core = root / "work/115三時間軸の複合入口の連続比較"
    material = ref(core / "条件の素材.json", "0ce1698f80e2969776fd07ed5ffc20a94e91690db6fd390e0363c30a2559d8b6")
    data = json.loads(Path(material["path"]).read_text(encoding="utf-8"))
    assert data["trial"] == 115 and data["fixed"] is False
    assert data["entry_input_model"] == "prior_csv_publications_through_scheduled_end_current_raw_delivery115"
    assert len(data["actual_configurations"]) == 12 and len(data["original166_references"]) == 54
    ref(core / "停止.json", "1dca0288b00682c965491bcf0209a45a0bbc4eaf527b0224063db9bcda7f77d8")
    for name, digest in data["code_sha256"].items():
        ref(Path(name), digest)
    ref(Path(data["executable"]["path"]), "c9b861784367fa9b8120314f2136fbf76e071f3a8ba8b78919b494a5669e28a0")
    # ----------------------------------------
    # 成績後の文書更新を金融ゲートへ混ぜないため、先に原文bytesを別名で保存する。
    archive = study / "根拠/市場前原文"
    archive.mkdir(parents=True, exist_ok=False)
    records = {}
    for key, source, target, expected in (
        ("仮説", study / "README.md", "README.md.txt", None),
        ("汎用表と設定", study / "設定と結果.md", "設定と結果.md.txt", None),
        ("一次資料と心理", root / "work/115設計調査/技法と心理の候補.md", "技法と心理の候補.md.txt", "88c69c8a3c88db67163abc338d459701aadaf5a67d1180b8d02584d669f302bd"),
    ):
        origin = ref(source, expected)
        destination = archive / target
        with destination.open("xb") as stream:
            stream.write(source.read_bytes())
        records[key] = {"原所在": origin, "固定参照": ref(destination, origin["sha256"])}
    data["fixed"] = True
    data["fixed_at_utc"] = datetime.now(timezone.utc).isoformat()
    data["research_basis"] = {key: row["固定参照"] for key, row in records.items()}
    data["research_scope"] = "既使用70。三時間軸入口だけ変更、Source111/P100cold保護を据置。11/09は本文・損益・入力指紋未読。採用・安定性未証明。"
    destination = here / "F1_115金融条件.json"
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(data, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    proof = {"試行": 115, "成功": True, "市場前": True, "素材": material, "金融条件": ref(destination), "原文": records, "金融実行": False, "金融定義/宣言の変更": False, "固定code": len(data["code_sha256"]), "11月09読取": False}
    with (here / "F1固定の確認.json").open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "条件": ref(destination), "固定code": len(data["code_sha256"])}, ensure_ascii=False))


if __name__ == "__main__":
    main()
