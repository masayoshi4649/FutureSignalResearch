"""115の独立結果と校正済み入力表を結ぶRoot要求を作る。"""

import hashlib
import json
from pathlib import Path


def main() -> None:
    """
    機能: 既存テンプレートの参照を認証し、結果表のRoot要求を新規保存する。
    引数: なし。
    返り値: None。保存した要求の絶対パスとSHA256を標準出力へ記す。
    """
    root = Path(__file__).resolve().parents[2]
    folder = root / "work/115設定表の結果結合準備"
    data = json.loads((folder / "要求テンプレ_未固定.json").read_text(encoding="utf-8-sig"))
    for key in ("source_table", "code_stop", "condition"):
        ref = data[key]
        assert hashlib.sha256(Path(ref["path"]).read_bytes()).hexdigest() == ref["sha256"], key
    result = root / "work/115独立保存F1/全70場/結果.json"
    digest = hashlib.sha256(result.read_bytes()).hexdigest()
    assert digest == "b4d9df3568098a73d38a670a9cca7a7dc0e6b4d79fe07a8ae8dd21d9cf6293df"
    data.update(fixed=True, result_read_authorized=True)
    data["result"] = {"path": str(result), "sha256": digest}
    target = Path(__file__).parent / "full70_結果表結合要求.json"
    with target.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"path": str(target), "sha256": hashlib.sha256(target.read_bytes()).hexdigest()}, ensure_ascii=False))


if __name__ == "__main__":
    main()
