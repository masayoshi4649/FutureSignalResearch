"""115の成功金融だけを独立会計・P監査・Viewer保存要求へ固定する。"""

import argparse
import hashlib
import json
from pathlib import Path


def ref(path: Path, expected: str | None = None) -> dict:
    """機能: 明示した小metadataを認証する。

    引数: path(Path)、expected(str|None)は対象と期待指紋。
    返り値: dictは絶対位置/SHA256。Native/Raw/価格CSV本文は読まない。
    """
    path = path.resolve()
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert expected is None or expected == digest, str(path)
    return {"path": str(path), "sha256": digest}


def main() -> None:
    """機能: 明示した成功段階に限定し、独立保存CLIの新要求を作る。

    引数: CLIのstage(str)、completion(Path)、sha256(str)。
    返り値: None。market_pathは既114の小要求から文字列だけを再用する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("first2", "base54", "full70"), required=True)
    parser.add_argument("--completion", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    here = Path(__file__).resolve().parent
    template = root / "work/115三時間軸入口の独立会計と保存/要求テンプレ_未固定.json"
    ref(template, "b24413cd63c3bf2a4bf4a02a68a8b08dd424eb5eb8186c0c2583859bf602bb1c")
    request = json.loads(template.read_text(encoding="utf-8"))
    assert request["trial"] == 115 and request["fixed"] is False and request["market_native_read_authorized"] is False
    for key in ("condition", "code_stop", "P_stop", "actor_stop", "protection_code", "entry_stop", "entry_code"):
        ref(Path(request[key]["path"]), request[key]["sha256"])
    completion = ref(args.completion, args.sha256)
    market = json.loads(args.completion.read_text(encoding="utf-8"))
    n = {"first2": 2, "base54": 54, "full70": 70}[args.stage]
    assert market["trial"] == 115 and market["success"] and market["stage"] == args.stage
    assert market["condition_sha256"] == request["condition"]["sha256"]
    assert market["sessions"] == n and market["books"] == n * 12 and market["all_source111_equal"] and market["all_reference114_equal"]
    old = root / "work/114進行/full70_独立保存要求.json"
    ref(old, "96105da743a8e1be12e45cbb01fdb1841b9b10e120901dfc780fc5de56c7a7ac")
    paths = {row["session"]: row["market_path"] for row in json.loads(old.read_text(encoding="utf-8"))["scenes"]}
    request["scenes"] = []
    for i, row in enumerate(market["results"]):
        assert row["complete"] and row["open_quantity"] == row["pending_quantity"] == 0
        assert row["reference114_equal"] and row["source111_equal"] and row["books"] == 12
        request["scenes"].append({"session": row["session"], "native": row["native"], "reference114": row["reference114"], "history_class": "original54" if i < 54 else "additional16", "market_path": paths[row["session"]]})
    request.update({"fixed": True, "market_native_read_authorized": True, "stage": args.stage, "completion": completion})
    destination = here / f"{args.stage}_独立保存要求.json"
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(request, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps(ref(destination), ensure_ascii=False))


if __name__ == "__main__":
    main()
