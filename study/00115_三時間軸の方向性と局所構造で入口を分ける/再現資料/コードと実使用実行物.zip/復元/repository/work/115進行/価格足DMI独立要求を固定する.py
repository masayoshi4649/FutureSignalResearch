"""成功金融に対応するCSV prefixとNativeだけを価格足/DMI独立検査へ固定する。"""

import argparse
import hashlib
import json
from pathlib import Path


def ref(path: Path, expected: str | None = None) -> dict:
    """機能: 明示した小metadataと停止参照を認証する。

    引数: path(Path)、expected(str|None)は所在と期待指紋。
    返り値: dictは絶対path/SHA256。価格CSV・Native本文には使用しない。
    """
    path = path.resolve()
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert expected is None or expected == digest, str(path)
    return {"path": str(path), "sha256": digest}


def main() -> None:
    """機能: Rootが指定する成功段階だけをCSVとNative読取範囲へ結ぶ。

    引数: CLI stage(str)、completion(Path)、sha256(str)。
    返り値: None。Rawと11月09の本文・指紋の読取許可は付けない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("first2", "base54", "full70"), required=True)
    parser.add_argument("--completion", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    here = Path(__file__).resolve().parent
    template = root / "work/115価格足とDMIを独立検査する/Root要求のひな型_first2.json"
    ref(template, "7e01ec25dfd11d8a59d924acd8d07772fe5534f5103fc7aa25c45d8fe102b9f1")
    request = json.loads(template.read_text(encoding="utf-8"))
    assert request["fixed"] is False and request["csv_read_authorized"] is False and request["market_native_read_authorized"] is False
    assert request["raw_read_authorized"] is False and request["holdout_read_authorized"] is False
    for key in ("condition", "manifest", "bank_stop", "code_stop"):
        ref(Path(request[key]["path"]), request[key]["sha256"])
    completion = ref(args.completion, args.sha256)
    market = json.loads(args.completion.read_text(encoding="utf-8"))
    manifest = json.loads(Path(request["manifest"]["path"]).read_text(encoding="utf-8"))
    count = {"first2": 2, "base54": 54, "full70": 70}[args.stage]
    assert market["trial"] == 115 and market["success"] and market["stage"] == args.stage and market["sessions"] == count
    assert market["condition_sha256"] == request["condition"]["sha256"] and market["unchanged"]
    scenes = []
    prefix = []
    for i, row in enumerate(market["results"]):
        item = manifest["sessions"][i]
        assert row["session"] == item["id"] and item["id"] <= "2026-11-06_Night"
        assert row["complete"] and row["reference114_equal"] and row["open_quantity"] == row["pending_quantity"] == 0
        csv = item["files"]["NK225_candle_300"]
        csv_ref = {"path": str((Path(manifest["source_root"]) / csv["path"]).resolve()), "sha256": csv["sha256"], "bytes": csv["size"]}
        scenes.append({"session": item["id"], "native": row["native"], "csv": csv_ref, "prefix": list(prefix)})
        prefix.append({"session": item["id"], "csv": csv_ref})
    assert len(scenes) == count
    request.update({"fixed": True, "market_native_read_authorized": True, "csv_read_authorized": True, "stage": args.stage, "market": completion, "scenes": scenes})
    destination = here / f"{args.stage}_価格足DMI独立要求.json"
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(request, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps(ref(destination), ensure_ascii=False))


if __name__ == "__main__":
    main()
