"""115の独立保存をRoot固定・全成功・停止codeの認証後だけに制限する。"""

from datetime import date, timedelta
from pathlib import Path
import re

import 保存集計の共通部 as S


def reference(value: dict, before: dict) -> Path:
    """機能: 明示絶対FileRefをSHA認証して前後不変台帳へ結ぶ。

    引数: value(dict)、before(dict)はpath/sha256参照と認証台帳。
    返り値: Pathは認証済み絶対位置。
    """
    S.equal(set(value), {'path', 'sha256'}, '115 FileRef集合')
    path = Path(value['path'])
    S.need(path.is_absolute() and re.fullmatch('[a-f0-9]{64}', value['sha256']) is not None, '115絶対Ref/SHA')
    path = path.resolve()
    S.equal(S.digest(path), value['sha256'], '115明示参照の実物')
    S.need(str(path) not in before or before[str(path)] == value['sha256'], '同位置の指紋衝突')
    before[str(path)] = value['sha256']
    return path


def planned_sessions(stage: str) -> list[str]:
    """機能: 元54と追加16の予定集合を欠落させず列挙する。

    引数: stage(str)はfirst2/base54/full70。
    返り値: list[str]は日付順のDay/Night。11/09を含めない。
    """
    S.need(stage in ('first2', 'base54', 'full70'), '115保存stage')
    end = date(2026, 9, 21) if stage == 'first2' else date(2026, 10, 27) if stage == 'base54' else date(2026, 11, 6)
    current, result = date(2026, 9, 21), []
    while current <= end:
        if current.weekday() < 5:
            result.extend(f'{current.isoformat()}_{kind}' for kind in ('Day', 'Night'))
        current += timedelta(days=1)
    S.equal(len(result), {'first2': 2, 'base54': 54, 'full70': 70}[stage], '115予定全場数')
    return result


def prepare(fixed_path: Path, fixed_sha: str, output: Path) -> tuple:
    """機能: Rootの市場解禁・115成功・保存/P/Actor停止・全Native参照を先に認証する。

    引数: fixed_path/output(Path)、fixed_sha(str)は固定要求・新規先・期待SHA。
    返り値: tupleは場task・指紋台帳・証拠・Pコード参照。Raw本文を読まない。
    """
    S.need(not output.exists(), '115保存先は未作成')
    before = {}
    reference({'path': str(fixed_path), 'sha256': fixed_sha}, before)
    fixed = S.load(fixed_path)
    S.need(fixed['version'] == 1 and fixed['trial'] == 115 and fixed['fixed'] is True
           and fixed['market_native_read_authorized'] is True, '115 Root固定/市場Native解禁')
    expected = planned_sessions(fixed['stage'])
    values = {}
    for name in ('condition', 'completion', 'code_stop', 'P_stop', 'actor_stop', 'entry_stop'):
        values[name] = S.load(reference(fixed[name], before))
    stopped, pure = values['code_stop'], values['P_stop']
    S.need(stopped['成功'] is True and stopped['市場前'] is True and stopped['試行'] == 115, '115保存器の市場前停止')
    S.equal(stopped['Actor停止'], fixed['actor_stop'], '115 Actor停止結合')
    S.equal(stopped['P停止'], fixed['P_stop'], '115独立P停止結合')
    S.equal(stopped['入口独立停止'], fixed['entry_stop'], '115保存器と独立入口停止結合')
    own = stopped['所有ファイルSHA256']
    required = {'金融の独立検算.py', '保存集計の共通部.py', '保存の入力ゲート.py', '保存する.py', '会計の人工検査.py', '会計を検査して停止する.py', '会計_README.md'}
    S.equal({Path(p).name for p in own}, required, '115保存器の所有集合')
    S.equal({Path(p).parent for p in own}, {Path(__file__).resolve().parent}, '115現在の保存器だけ')
    for path, sha in {**own, **stopped['再用ファイルSHA256']}.items():
        reference({'path': path, 'sha256': sha}, before)
    S.need(pure['成功'] is True and pure['市場前'] is True, '115 P監査の市場前停止')
    for path, sha in pure['所有ファイルSHA256'].items():
        reference({'path': path, 'sha256': sha}, before)
    protection_path = reference(fixed['protection_code'], before)
    S.equal(pure['所有ファイルSHA256'].get(str(protection_path)), fixed['protection_code']['sha256'], '115停止Pの実監査コード')
    actor = values['actor_stop']
    S.need(actor['試行'] == 115 and actor['成功'] is True and actor['市場前'] is True, '115 Actor市場前停止')
    for path, sha in actor['所有コードSHA256'].items():
        reference({'path': path, 'sha256': sha}, before)
    entry = values['entry_stop']
    S.need(entry['成功'] is True and entry['市場前'] is True, '115入口独立監査の市場前停止')
    for path, digest in entry['所有ファイルSHA256'].items():
        reference({'path': path, 'sha256': digest}, before)
    entry_path = reference(fixed['entry_code'], before)
    S.equal(entry['所有ファイルSHA256'].get(str(entry_path)), fixed['entry_code']['sha256'], '115停止入口の実監査コード')
    condition, completion = values['condition'], values['completion']
    S.need(condition['trial'] == 115 and condition['fixed'] is True, '115市場事前条件')
    S.equal(condition['actual_configurations'], list(S.A.CONFIGS), '115条件の本名12')
    S.equal(condition['dependency_stops']['actor'], fixed['actor_stop'], '115条件と実Actor停止')
    S.equal(condition['dependency_stops']['entry_gate'], actor['純入口停止'], '115条件と純入口Go停止')
    S.equal(condition['dependency_stops']['entry_chart'], actor['入口公開停止'], '115入口公開器停止結合')
    S.equal(condition['entry_input_model'], 'prior_csv_publications_through_scheduled_end_current_raw_delivery115', '115入口前史モデル')
    S.equal(condition['dependency_stops']['pure']['sha256'], '81f54d965ef8d81c65a7b58f4d376374b79c765e1ad4ada5cc6270159e4ed312', '115共通113P100の純停止')
    for path, sha in condition['code_sha256'].items():
        code = Path(path)
        code = (code if code.is_absolute() else S.ROOT / code).resolve()
        reference({'path': str(code), 'sha256': sha}, before)
        S.equal(completion['before'].get(str(code)), sha, '115金融完了の同code')
    S.need(completion['trial'] == 115 and completion['success'] is True and completion['stage'] == fixed['stage']
           and completion['sessions'] == len(expected) and completion['books'] == 12 * len(expected), '115全12N成功')
    S.equal((completion['reused_sessions'], completion['replayed_sessions']),
            (54, 16) if fixed['stage'] == 'full70' else (0, len(expected)), '115認証再用と新規再生の区別')
    S.equal(completion['condition_sha256'], fixed['condition']['sha256'], '115同市場条件')
    S.need(completion['unchanged'] is True and completion['before'] == completion['after'], '115金融入力code不変')
    S.need(completion['all_reference114_equal'] is True and completion['all_source111_equal'] is True
           and completion['reference114_comparisons'] == 4 * len(expected), '115旧114全4N/Source対照')
    S.need(completion['all_original166_reference_events_equal'] is True and completion['historical_saved_events_equal'] is False
           and completion['all_original_signal_full_json_equal'] is False, '115元oracle/歴史同体の区別')
    S.equal([r['session'] for r in completion['results']], expected, '115金融の全予定場順')
    S.equal([r['session'] for r in fixed['scenes']], expected, '115保存要求の全予定場順')
    tasks = []
    for final, task in zip(completion['results'], fixed['scenes']):
        S.need(final['books'] == 12 and final['A0_comparisons'] == 4 and final['A0_equal'] is True and final['complete'] is True
               and final['open_quantity'] == final['pending_quantity'] == 0, '115場別残/予約0')
        S.need(final['reference114_comparisons'] == 4 and final['reference114_equal'] is True and final['source111_equal'] is True,
               '115場別旧114対照')
        S.equal(task['native'], final['native'], '115完了のNative参照')
        S.equal(task['reference114'], final['reference114'], '115完了の正式114参照')
        sid = task['session']
        native, prior = reference(task['native'], before), reference(task['reference114'], before)
        S.need(native.name == prior.name == sid + '.Native.json.gz', '115/114の同場Native本名')
        S.equal(task['history_class'], 'original54' if sid[:10] <= '2026-10-27' else 'additional16', '115元54/追加16')
        S.need(isinstance(task['market_path'], str) and task['market_path'], '115価格の参照文字列')
        tasks.append({**task, 'resolved_native': native, 'resolved_reference114': prior})
    proofs = {'stage': fixed['stage'], 'Root保存要求SHA256': fixed_sha, '金融条件SHA256': fixed['condition']['sha256'],
              '金融完了SHA256': fixed['completion']['sha256'], '保存器停止SHA256': fixed['code_stop']['sha256'],
              '独立P停止SHA256': fixed['P_stop']['sha256'], 'Actor停止SHA256': fixed['actor_stop']['sha256'], '独立入口停止SHA256': fixed['entry_stop']['sha256']}
    return tasks, before, proofs, protection_path, entry_path
