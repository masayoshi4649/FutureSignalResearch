"""115の共通P100を、本名Configのまま停止113有理数監査へ接続する。"""

import hashlib
import importlib.util
from pathlib import Path
import 金融の独立検算 as A

ROOT = Path(__file__).resolve().parents[2]
PREVIOUS_PATH = ROOT / 'work/113起動前の構造失効を執行する会計/新保護の独立監査.py'
PREVIOUS_SHA = 'fdd4182152e60a66b298e633a813c3496440f3aea684d1dc4fe950983d39115f'
if hashlib.sha256(PREVIOUS_PATH.read_bytes()).hexdigest() != PREVIOUS_SHA:
    raise ValueError('停止113独立PのSHA差')
SPEC = importlib.util.spec_from_file_location('115の共通P100を検算する固定113純P', PREVIOUS_PATH)
OLD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)


def verify_protection(book: dict, config: dict, finance: dict, context: dict) -> dict:
    """機能: 追加早期失効を許さず113P100の全玉床/保護点を独立算術で監査する。

    引数: book/config/finance/context(dict)は実口座・本名12宣言・会計・公表文脈。
    返り値: dictは113と同じexact/bounded件数と保存点の限界。原値を加工しない。
    """
    A.equal(book['key'],A.key_for(config),'115の保護監査も本名key')
    A.equal(book['config'],config,'115の保護監査も本名Config')
    A.need(config['policy']=='P100','115の共通保護だけ')
    return OLD.verify_protection(book,config,finance,context)
