"""115の全実現会計と旧114対照を独立保存し、CSV互換JSONとViewer資料を作る。"""

import argparse
from collections import Counter
import importlib.util
import json
from pathlib import Path
import sys

import 保存集計の共通部 as S
import 保存の入力ゲート as G


def run(fixed_path: Path, fixed_sha: str, output: Path) -> dict:
    """機能: Root全成功を認証後に115/114台帳を再読して全12×場数を保存する。

    引数: fixed_path/output(Path)、fixed_sha(str)は固定要求・新規先・期待指紋。
    返り値: dictは会計/Viewer件数と結果Ref。Go・Source・Rawを再実行しない。
    """
    tasks, before, proofs, protection_path, entry_path = G.prepare(fixed_path, fixed_sha, output)
    spec = importlib.util.spec_from_file_location('115停止済み純Python保護監査', protection_path)
    protection = importlib.util.module_from_spec(spec)
    sys.path.insert(0, str(protection_path.parent))
    try:
        spec.loader.exec_module(protection)
    finally:
        sys.path.pop(0)
    entry_spec = importlib.util.spec_from_file_location('115停止済み独立入口票監査', entry_path)
    entry_guard = importlib.util.module_from_spec(entry_spec)
    sys.path.insert(0, str(entry_path.parent))
    try:
        entry_spec.loader.exec_module(entry_guard)
    finally:
        sys.path.pop(0)
    output.mkdir(parents=True, exist_ok=False)
    rows, source_checks, legacy_checks, native_refs, viewer_checks, resources = [], [], [], [], [], []
    for task in tasks:
        current, prior = S.load(task['resolved_native']), S.load(task['resolved_reference114'])
        S.equal(current['reference114']['reference'], task['reference114'], '115 Nativeの正式114出典')
        S.equal(current['reference114']['before_sha256'], task['reference114']['sha256'], '115 Coreの114前指紋')
        S.equal(current['reference114']['after_sha256'], task['reference114']['sha256'], '115 Coreの114後指紋')
        inspected = S.inspect_scene(current, prior, protection, entry_guard)
        sid = task['session']
        S.equal(current['actual']['scope']['session']['id'], sid, '115 Native当場')
        for key in S.KEYS:
            row = S.summarize_book(current['actual']['books'][key], inspected['checked'][key])
            row['入口票検査'] = inspected['entry'][key]
            rows.append({'session': sid, 'key': key, 'history_class': task['history_class'], **row})
        source_checks.append({'session': sid, **inspected['source']})
        legacy_checks.append({'session': sid, 'reference': task['reference114'], **inspected['reference114']})
        native_refs.append({'session': sid, **task['native'], 'reference114': task['reference114']})
        scene_resources = S.save_viewer(current, output, task['market_path'])
        viewer_checks.append({'session': sid, **S.verify_viewer(current, output, scene_resources)})
        resources.extend(scene_resources)
    summary = {key: S.combine([r for r in rows if r['key'] == key]) for key in S.KEYS}
    entry_summary = {key: dict(sum((Counter(row['入口票検査']['counts']) for row in rows if row['key'] == key), Counter())) for key in S.KEYS}
    after = {path: S.digest(Path(path)) for path in before}
    S.equal(after, before, '115全入力/参照114/code前後不変')
    result = {'試行': 115, '成功': True, **proofs, '場数': len(tasks), '会計数': len(rows), '主key': list(S.KEYS),
              'Actor設定': {key: {'candidate': config['entry_mode'], 'entry_timing': '元Source連続時計', **config} for key, config in S.BY_KEY.items()},
              '保護定義': {'P100': S.OLD.definition('P100')},
              '集計': summary, '入口票集計': entry_summary, '場別': rows, '元Source対照': source_checks, '旧114対照': legacy_checks,
              'Native参照': native_refs, 'Viewer形式資源': len(resources), 'Viewer保存再読': viewer_checks,
              '入力codeSHA256前': before, '入力codeSHA256後': after, '前後不変': True,
              '勝率定義': '正益完結実玉数/全完結実玉数。同値も分母、平均損失は負、PFは正益総額/負益総額の絶対値、分母0はnull。',
              '頻度定義': '原行数・実新規件数・実保有時間・数量秒。固定5分/15分参加率や機会損失は作らない。',
              '限界': ['Rawの別走査なし。最初の適格正常原行はIndex後/遅延/正常BBO/物理行後までを検査し、原文oracle/元Event/Go約定人工へ接続する。',
                       '純Pは少数保存点のexact/boundedを分け、中間要求の純点未保存を明示する。全原行極値を別証明しない。',
                       'ラージ板によるmini模型。実mini板の流動性・応答・元本ROIは未実証。'],
              '未実施': {'Raw本文': 0, '価格CSV本文': 0, 'Source再実行': 0, '金融Go再実行': 0, 'HTTP': 0, 'CSV生成': 0, '11月09日本文': 0},
              '研究目標達成': False, '採用': False}
    S.BASE.write_json(output / '結果.json', result)
    S.BASE.write_json(output / '一覧.resources.json', {'schema_version': 1, 'path_base': 'catalog', 'resources': resources})
    files = {p.name: S.digest(p) for p in sorted(output.iterdir()) if p.is_file()}
    proof = {'試行': 115, '成功': True, **proofs, '場数': len(tasks), '会計数': len(rows), '資源': len(resources),
             'A0全金融比較': 4 * len(tasks), '旧114全金融比較': 4 * len(tasks), '全Source111同体': True,
             '全残玉予約0': True, '不一致数': 0, '入力codeSHA256前': before, '入力codeSHA256後': after, '前後不変': True,
             '出力SHA256': files, '研究目標達成': False, '採用': False}
    S.BASE.write_json(output / '保存会計の確認.json', proof)
    return {'成功': True, 'stage': proofs['stage'], '場数': len(tasks), '会計数': len(rows), 'Viewer資源': len(resources)}


def main() -> None:
    """機能: Rootの明示固定要求と新規先だけから保存を呼ぶ。

    引数: CLI fixed/sha256/output(str)は要求・期待SHA・新規先。
    返り値: None。件数だけを標準出力へ表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fixed', required=True, type=Path)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    print(json.dumps(run(args.fixed.resolve(), args.sha256, args.output.resolve()), ensure_ascii=False))


if __name__ == '__main__':
    main()
