"""115のCore手製72冊と別のActor旧A0八対を検査する。"""

from copy import deepcopy
from pathlib import Path
import unittest
import 保存集計の共通部 as S
import 金融の独立検算 as A
import 新保護の独立監査 as P

MANIFEST=S.ROOT/'work/115三時間軸の複合入口の連続比較/人工_入口独立用/Core人工.json'
MANIFEST_SHA='4ff53c2bed94c512c6c3c39695d9eb57748076bd6bc885da15f7e13d6e0daa9e'
ACTOR_MANIFEST=S.ROOT/'work/115三時間軸の複合入口を執行する会計/人工_独立判定用/買売人工.json'
ACTOR_SHA='24d00eaefdcaf39e1283955aff1a0968eb31d34aa9572bcd870826d3f5403a09'


def fixtures() -> list:
    """機能: 明示SHAの手製Core六ケースだけを読む。

    引数: なし。
    返り値: list[tuple[dict,None]]は買売×T/R/未知の全72冊。旧Nativeは当人工に無い。
    """
    S.equal(S.digest(MANIFEST),MANIFEST_SHA,'115手製Core manifest SHA')
    metadata=S.load(MANIFEST)
    S.need(metadata['人工'] is True and metadata['市場'] is False and metadata['FAR自然生成'] is False and metadata['試行']==115 and len(metadata['results'])==6,'手製Coreの六ケース')
    return [(value,None) for value in metadata['results'].values()]


def actor_pairs() -> list:
    """機能: 別のActor手製買売から旧A0四費用との八対だけを返す。

    引数: なし。
    返り値: list[tuple[dict,dict]]は新旧A0実口座。自然Source証明へは用いない。
    """
    S.equal(S.digest(ACTOR_MANIFEST),ACTOR_SHA,'115Actor手製SHA')
    values=S.load(ACTOR_MANIFEST)
    S.need(values['市場'] is False and values['FAR自然生成'] is False,'Actor手製の範囲')
    return [(values[side][key],values[side+'_114'][key]) for side in ('買い','売り') for key in A.KEYS[:4]]


class Protection115Tests(unittest.TestCase):
    """P113算術を同体で使い、Core72冊と別の旧A0八対を区別する。"""

    def test_core72_and_same_guard(self) -> None:
        """機能: Core全72冊の会計/P100とActor旧A0八対を検査する。

        引数: self(Protection115Tests)は検査器。
        返り値: None。自然Sourceの生成/全出生は当人工で証明しない。
        """
        count=0
        for value,_ in fixtures():
            for key,config in A.BY_KEY.items():
                book=value['actual']['books'][key];finance=A.verify_finance(book,config)
                self.assertIn('counts',P.verify_protection(book,config,finance,value['actual']));count+=1
        self.assertEqual(count,72)
        pairs=actor_pairs();self.assertEqual(len(pairs),8)
        for current,prior in pairs:self.assertTrue(S.compare_book114(current,prior)['all_financial_equal'])

    def test_policy_definition_and_state_corruption(self) -> None:
        """機能: 別政策・偽定義版・床演算の破壊を拒否する。

        引数: self(Protection115Tests)は検査器。
        返り値: None。入口115に合わせてP100版を変更しない。
        """
        value,_=fixtures()[0];config=A.BY_KEY['A0_C0_D0'];book=value['actual']['books']['A0_C0_D0'];finance=A.verify_finance(book,config)
        for kind in ('policy','definition','state'):
            broken,cfg=deepcopy(book),deepcopy(config)
            if kind=='policy':cfg['policy']='E100'
            elif kind=='definition':broken['positions'][0]['protection113']['initial']['definition']['version']=115
            else:broken['positions'][0]['protection113']['final_state']['closed_net_yen']+=1
            with self.subTest(kind=kind),self.assertRaises(ValueError):P.verify_protection(broken,cfg,finance,value['actual'])


if __name__=='__main__':unittest.main(verbosity=2)
