"""115全12の会計・P100・Source非干渉・A0旧金融対照をまとめる。"""

import ast
from copy import deepcopy
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import sys
import textwrap
from types import FunctionType

import 金融の独立検算 as A

ROOT = Path(__file__).resolve().parents[2]
PREVIOUS_PATH = ROOT / 'work/113起動前の構造失効を執行する会計/保存集計の共通部.py'
PREVIOUS_SHA = '9ccbe99c39bdae1e7c942bdf8d0eb36435f86649037281e41ffa1f62890f5869'
if hashlib.sha256(PREVIOUS_PATH.read_bytes()).hexdigest()!=PREVIOUS_SHA:
    raise ValueError('停止113集計のSHA差')
SPEC = importlib.util.spec_from_file_location('115が再用する停止113集計',PREVIOUS_PATH)
OLD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)
BASE,need,equal=A.BASE,A.need,A.equal
KEYS,BY_KEY=A.KEYS,A.BY_KEY
digest,load=OLD.digest,OLD.load
summarize_book,combine,source_projection=OLD.summarize_book,OLD.combine,OLD.source_projection


def viewer_reader():
    """機能: 固定113の保存再読器から資源分母24の一式だけを12へ派生する。

    引数: なし。
    返り値: functionは115の全12保存を独立会計で再読する関数。金融演算は同体。
    """
    tree=ast.parse(textwrap.dedent(inspect.getsource(OLD.verify_viewer)))
    found=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.Call) and ast.unparse(node)=="equal(len(resources), 24, '保存再読24資源')":
            found.append(node)
    equal(len(found),1,'保存再読の資源分母一式だけ')
    found[0].args[1]=ast.Constant(value=12)
    found[0].args[2]=ast.Constant(value='115保存再読12資源')
    space={**OLD.verify_viewer.__globals__,'A':A,'KEYS':KEYS,'BY_KEY':BY_KEY}
    exec(compile(ast.fix_missing_locations(tree),__file__+':停止113保存再読の分母だけ','exec'),space)
    return space['verify_viewer']


verify_viewer=viewer_reader()


def compare_book114(book: dict, prior: dict) -> dict:
    """機能: 新旧A0の入口説明だけを分離し全金融/P100状態を独立比較する。

    引数: book/prior(dict)は同場・同費用・同keyの115/114実口座。
    返り値: dictはGo LegacyComparison115と同じ検査済み説明差と全金融同体。
    """
    left,right=deepcopy(book),deepcopy(prior)
    equal(left['config'],right['config'],'115/114A0の本名Config同体')
    cfg=left['config'];equal(cfg['entry_mode'],'A0','旧対照はA0だけ');equal(cfg['policy'],'P100','共通P100だけ')
    equal(left['key'],right['key'],'新旧の同名key');equal(left['key'],A.key_for(cfg),'115A0本名')
    audit,old=left['entry_gate'],right['entry_gate']
    need(audit['version']==115 and old['version']==114 and audit['mode']==old['mode']=='A0','新旧入口監査版')
    rows=audit['records'];oldrows=old['records'];news=[e for e in left['source_events'] if e['kind']=='new_signal']
    need(isinstance(rows,list) and isinstance(oldrows,list),'A0監査は非null配列')
    equal(len(rows),left['metrics']['native_new_signals'],'115A0全要求票');equal(len(oldrows),right['metrics']['native_new_signals'],'114A0全要求票')
    equal(len(rows),len(oldrows),'新旧全要求数');equal(len(rows),len(news),'115A0元要求との全票数')
    for row,previous,event in zip(rows,oldrows,news):
        request=row['request']
        need(row['allowed'] is True and row['selected']==2 and previous['allowed'] is True and previous['selected']==2,'両A0全許可')
        equal((request['product'],request['method'],request['signal_id'],request['side'],request['at'],request['last']),
              ('NK225mini',event['method'],event['signal_id'],event['side'],{k:event['quote'][k] for k in ('time','index','source_line')},event['quote']['last']),'新A0当要求Last/原行固定')
        equal((row['quote'],row['accepted_quantity'],row['available'],row['order_id']),
              (event['quote'],event['actual_accepted'],event['available'],event['order_id']),'新A0実受付結合')
        need(row['decision']['version']==115 and previous['decision']['version']==114 and row['decision']['frozen'] is True and previous['decision']['frozen'] is True,'新旧純入口版と固定旗')
        equal(row['decision']['request'],request,'115純票の実要求');equal(previous['decision']['request'],previous['request'],'114純票の実要求')
        del row['decision'];del previous['decision'];del row['request']['last']
    del audit['version'];del old['version'];equal(audit,old,'新旧入口の容量/取消/受付/実取得全値')
    changed=left['stream_scope']!=right['stream_scope']
    need(left['stream_scope'].startswith('115:') and right['stream_scope'].startswith('114:'),'明示版付きScope')
    del left['entry_gate'];del right['entry_gate'];left['stream_scope']=right['stream_scope']=''
    equal(left,right,'115A0/114A0全金融/P100全State')
    return {'entry_mode':'A0','protection':'P100','stream_scope_difference':changed,'gate_definition_difference':True,
            'config_equal':True,'gate_records':len(rows),'gate_accounting_equal':True,'all_financial_equal':True}


def compare_reference114(value: dict, prior: dict) -> dict:
    """機能: 正式114A0四費用とSource全文を新Nativeへ独立照合する。

    引数: value/prior(dict)は115/114の当場Native。
    返り値: dictは4全金融/Stateの成功と説明差。IDやC/M/P/Bを変更しない。
    """
    need(value['trial']==115 and prior['actual']['trial']==114,'115/114の明示版')
    equal(value['source'],prior['source'],'Source111全JSON同体');equal(value['actual']['scope'],prior['actual']['scope'],'同場範囲')
    details={key:compare_book114(value['actual']['books'][key],prior['actual']['books'][key]) for key in KEYS[:4]}
    trace=value['reference114']
    need(trace['comparisons']==4 and trace['all_financial_equal'] is True and trace['source_equal'] is True,'Core114四対照成功')
    equal(trace['details'],details,'Go対照と独立Pythonの差件数')
    return {'comparisons':4,'all_financial_equal':True,'source_equal':True,'details':details}


def verify_source(value: dict, artificial: bool) -> dict:
    """機能: 元Source非干渉を照合し、手製Coreの自然Source未証明を分ける。

    引数: value(dict)、artificial(bool)は当場Nativeと手製区分。
    返り値: dictは同通知とD0新規出典。手製Sourceを自然再生へ偽装しない。
    """
    source,actual=value['source'],value['actual'];need(source['complete'] is True and actual['complete'] is True,'Source/実口座完結')
    minimal=source.get('books') is None
    need(artificial or not minimal,'市場Source台帳は必須')
    baseline=source_projection(actual['books']['A0_C0_D0']) if minimal else source_projection(source['books']['S0_C0_D0'])
    for key in KEYS:equal(source_projection(actual['books'][key]),baseline,'115全12の同Source通知.'+key)
    bound=allocated=0
    if not artificial:
        equal(source['explicit_timer_calls'],0,'元timerなし');need(source['mini_source_D0_fill_equal'] is True,'源D0同体flag')
        minis={k.removeprefix('NK225mini_'):b for k,b in source['sources'].items() if k.startswith('NK225mini_')}
        new={(method,r['fill']['SignalID']):r for method,ledger in minis.items() for r in ledger['fills'] if r['action']=='new'}
        for key in KEYS:
            if BY_KEY[key]['delay_seconds']!=0:continue
            for fill in actual['books'][key]['fills']:
                if fill['action']!='new':continue
                origin=new[(BASE.SOURCE_METHODS[fill['source']['method']],fill['source']['signal_id'])]
                equal(fill['quote'],origin['quote'],'115D0のSource初回取得原行');equal(fill['price'],origin['fill']['Price'],'115D0のSource初回取得価格')
                need(fill['quantity']<=origin['fill']['Quantity'],'115D0元割当上限');bound+=1;allocated+=fill['quantity']!=origin['fill']['Quantity']
    return {'全12の元通知同体':True,'Source全JSON同体は旧114対照で確認':not minimal,'D0源新規結合':bound,
            'D0源出生から割当減少':allocated,'手製Source器具':artificial,'自然Source全文の独立証明':not artificial,
            '当時保存166との同体':value['original_historical_events_equal']}


def inspect_scene(value: dict, prior: dict | None, protection, entry_guard, artificial: bool=False) -> dict:
    """機能: 全12金融/共通P100/新版入口を照合し旧A0対照の有無を区別する。

    引数: value(dict)、prior(dict|None)、protection/entry_guard(module)、artificial(bool)は新旧台帳と監査。
    返り値: dictはchecked/source/reference114/入口。手製Coreの旧Native欠落は市場では拒否する。
    """
    actual=value['actual'];need(value['version']==1 and value['trial']==115 and actual['version']==1 and actual['trial']==115 and actual['complete'] is True,'115完結Native')
    equal(actual['configurations'],list(A.CONFIGS),'115本名12宣言と順序');equal(set(actual['books']),set(KEYS),'115全12集合')
    equal(actual['entry_grid_seconds'],None,'追加新規時計なし');equal(actual['extra_opening_quiet_seconds'],0,'追加静観なし');equal(actual['explicit_timers'],0,'追加timerなし')
    equal(actual['chart_seed_mode'],'cold_each_session','旧P100保護bankだけ当場cold')
    equal(actual['scope']['session'],value['source']['session'],'Source場');equal(actual['scope']['contract'],value['source']['contract'],'Source限月')
    equal(actual['counts']['publications'],len(actual['publications'] or []),'旧保護公開数');equal(actual['counts']['resets'],len(actual['resets'] or []),'旧保護reset数')
    equal(actual['entry_input']['model'],'prior_csv_publications_through_scheduled_end_current_raw_delivery115','入口前史公表モデルを明示')
    whole_entry=entry_guard.verify_scene(value,artificial=artificial)
    entries=whole_entry['book'];equal(set(entries),set(KEYS),'入口全12検査集合')
    checked={}
    for key,config in BY_KEY.items():
        book=actual['books'][key];equal(book['session'],actual['scope']['session'],'115全12の同場')
        equal(book['metrics']['rows'],actual['counts']['rows'],'全12受理原行数');equal(book['metrics']['bad_quote_rows'],actual['counts']['bad_quotes'],'全12異常気配数')
        finance=A.verify_finance(book,config);finance['protection_counts']=protection.verify_protection(book,config,finance,actual)
        checked[key]=finance
    if prior is None:
        need(artificial,'市場は正式114当場Native必須')
        reference={'comparisons':0,'all_financial_equal':None,'source_equal':None,'未照合':'Root手製Coreは旧114Native未保存。Actor買売の別8対照で独立確認。'}
    else:reference=compare_reference114(value,prior)
    return {'checked':checked,'source':verify_source(value,artificial),'reference114':reference,'entry':entries,'entry_scene':whole_entry}


def save_viewer(value: dict,output: Path,market_path: str) -> list:
    """機能: 115本名12の実約定だけをViewer schema1へ新規保存する。

    引数: value(dict)、output(Path)、market_path(str)は当場値・未作成先・価格参照文字列。
    返り値: list[dict]は0取引も含む12資源。価格本文/HTTPを読まない。
    """
    resources=[];sid=value['actual']['scope']['session']['id']
    for key in KEYS:
        name=f'115_{key}_{sid}.trades.jsonl'
        with (output/name).open('x',encoding='utf-8',newline='\n') as stream:
            for row in BASE.viewer_trades(value['actual']['books'][key]):
                stream.write(json.dumps(row,ensure_ascii=False,default=BASE.serial,allow_nan=False)+'\n')
        resources.append({'id':f'115_{key}_{sid}','title':f'順行反転取得と共通P100 {key} {sid}',
                          'symbol':'NK225','product':'NK225mini','session':sid,'method_id':key,'point_value':100,
                          'pnl_format':'trades','pnl_basis':'net','pnl_path':name,'market_path':market_path})
    return resources
