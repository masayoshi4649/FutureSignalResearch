"""115手製Core72冊の金融/P/入口/旧対照と保存形式を独立検査する。"""

from copy import deepcopy
import importlib.util
from pathlib import Path
import tempfile
import sys
import unittest

import 金融の独立検算 as A
import 保存集計の共通部 as S
import 保存の入力ゲート as G
import 新保護の独立監査 as P
import 保護監査の人工検査 as T

ENTRY_PATH=S.ROOT/'work/115入口判定を独立検算する/検算する.py'


def entry_guard():
    """機能: 明示位置の独立入口Pythonを読み会計/Pと結合する。

    引数: なし。停止helperは入口停止・全所有SHAを先に認証する。
    返り値: moduleはGoを呼ばない三値・受付・fill監査。
    """
    spec=importlib.util.spec_from_file_location('115会計の独立入口監査',ENTRY_PATH)
    module=importlib.util.module_from_spec(spec)
    sys.path.insert(0,str(ENTRY_PATH.parent))
    try:spec.loader.exec_module(module)
    finally:sys.path.pop(0)
    return module


class Accounting115Tests(unittest.TestCase):
    """本名の全台帳を保ち、金融原値を書換えずに検算する。"""

    def test_core72_all_independent_and_reference(self) -> None:
        """機能: 全72冊の金融/P/入口と別Actor旧8冊全金融対照を検査する。

        引数: self(Accounting115Tests)は検査器。
        返り値: None。Sourceは手製API通知の範囲で照合する。
        """
        guard=entry_guard();count=0
        for value,prior in T.fixtures():
            checked=S.inspect_scene(value,prior,P,guard,artificial=True)
            self.assertEqual(len(checked['checked']),12)
            self.assertEqual(checked['reference114']['comparisons'],0)
            count+=len(checked['checked'])
        self.assertEqual(count,72)

    def test_actor_zero_trade_and_ratios(self) -> None:
        """機能: 反転だけの人工でTの0取引と未定義比率を保持する。

        引数: self(Accounting115Tests)は検査器。
        返り値: None。取引ゼロを場別から落とさない。
        """
        path=S.ROOT/'work/115三時間軸の複合入口を執行する会計/人工_独立判定用/買売人工.json'
        S.equal(S.digest(path),'24d00eaefdcaf39e1283955aff1a0968eb31d34aa9572bcd870826d3f5403a09','Actor24人工SHA')
        values=S.load(path)
        for side in ('買い','売り'):
            for key in ('T_C0_D0','T_C0_D1','T_C5_D0','T_C5_D1'):
                book=values[side][key];checked=A.verify_finance(book,A.BY_KEY[key])
                checked['protection_counts']={}
                row=S.summarize_book(book,checked)
                self.assertEqual(row['positions'],0)
                self.assertIsNone(row['PF']);self.assertIsNone(row['win_rate'])
                self.assertIsNone(row['average_profit_yen']);self.assertIsNone(row['average_loss_yen'])

    def test_viewer72_and_groups(self) -> None:
        """機能: 六ケース各12資源を保存・再読し三返済群の純額を会計へ照合する。

        引数: self(Accounting115Tests)は検査器。
        返り値: None。価格CSV本文やHTTPは読まない。
        """
        guard=entry_guard()
        for value,prior in T.fixtures():
            checked=S.inspect_scene(value,prior,P,guard,artificial=True)
            with tempfile.TemporaryDirectory(prefix='115会計人工_',dir=Path(__file__).resolve().parent) as temp:
                output=Path(temp)
                resources=S.save_viewer(value,output,'共用価格の参照だけ.csv')
                proof=S.verify_viewer(value,output,resources)
                self.assertEqual(len(resources),12)
                self.assertTrue(proof['全残0'])
                for key in S.KEYS:
                    row=S.summarize_book(value['actual']['books'][key],checked['checked'][key])
                    self.assertEqual(set(row['注文別']),{'Source','保護','起動前失効'})
                    self.assertEqual(row['注文別']['起動前失効']['要求'],0)
                    self.assertEqual(sum(group['返済片純額'] for group in row['注文別'].values()),row['net_yen'])

    def test_financial_and_original_mode_corruptions(self) -> None:
        """機能: 費用・所有・予約・純額・本名Config・選別票の金融矛盾を拒否する。

        引数: self(Accounting115Tests)は検査器。
        返り値: None。未知を偽や0へ補完して整合させない。
        """
        value,_=T.fixtures()[0];key='A0_C0_D0';book=value['actual']['books'][key];config=A.BY_KEY[key]
        for kind in ('fee','quantity','reserved','net','mode','gate'):
            broken=deepcopy(book);cfg=deepcopy(config)
            if kind=='fee':broken['fills'][0]['fee_yen']+=1
            elif kind=='quantity':broken['positions'][0]['initial_quantity']+=1
            elif kind=='reserved':broken['positions'][0]['reserved']+=1
            elif kind=='net':broken['totals']['net_yen']+=1
            elif kind=='mode':cfg['entry_mode']='P100'
            else:broken['entry_gate']['records'][0]['allowed']=False
            with self.subTest(kind=kind),self.assertRaises(ValueError):A.verify_finance(broken,cfg)

    def test_reference_114_financial_changes_rejected(self) -> None:
        """機能: Actor旧四対照の金額/State/受付破壊と最小Sourceの市場偽装を拒否する。

        引数: self(Accounting115Tests)は検査器。
        返り値: None。Coreの旧Native欠落を人工A0対照で埋めたことにしない。
        """
        pairs=T.actor_pairs();self.assertEqual(len(pairs),8)
        for current,prior in pairs:self.assertTrue(S.compare_book114(current,prior)['all_financial_equal'])
        current,prior=pairs[0]
        for kind in ('net','state','gate','capacity','actual','last'):
            bad=deepcopy(current)
            if kind=='net':bad['totals']['net_yen']+=1
            elif kind=='state':bad['positions'][0]['protection113']['final_state']['closed_net_yen']+=1
            elif kind=='gate':bad['entry_gate']['records'][0]['allowed']=False
            elif kind=='capacity':bad['entry_gate']['records'][0]['cap_quantity']+=1
            elif kind=='actual':bad['entry_gate']['records'][0]['actual_quantity']+=1
            else:bad['entry_gate']['records'][0]['request']['last']+=1
            with self.subTest(kind=kind),self.assertRaises(ValueError):S.compare_book114(bad,prior)
        value,_=T.fixtures()[0]
        with self.assertRaises(ValueError):S.verify_source(value,artificial=False)
        self.assertFalse(S.verify_source(value,artificial=True)['自然Source全文の独立証明'])

    def test_unfixed_rejected_before_native(self) -> None:
        """機能: Root未固定・未解禁要求をNative参照前かつ出力先作成前に拒否する。

        引数: self(Accounting115Tests)は検査器。
        返り値: None。
        """
        self.assertEqual([len(G.planned_sessions(stage)) for stage in ('first2','base54','full70')],[2,54,70])
        with tempfile.TemporaryDirectory(prefix='115入口拒否_',dir=Path(__file__).resolve().parent) as temp:
            fixed=Path(temp)/'未解禁.json';output=Path(temp)/'出力'
            S.BASE.write_json(fixed,{'version':1,'trial':115,'fixed':False,'market_native_read_authorized':False})
            with self.assertRaises(ValueError):G.prepare(fixed,S.digest(fixed),output)
            self.assertFalse(output.exists())


if __name__=='__main__':unittest.main(verbosity=2)
