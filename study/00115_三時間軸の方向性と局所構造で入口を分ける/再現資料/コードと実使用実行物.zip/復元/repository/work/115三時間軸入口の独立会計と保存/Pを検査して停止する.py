"""115共通P100の無変更113数式監査と本名設定の人工を固定する。"""

import json
from pathlib import Path
import subprocess
import sys
import 保存集計の共通部 as S
import 新保護の独立監査 as P
import 保護監査の人工検査 as T

OWN=Path(__file__).resolve().parent


def main() -> dict:
    """機能: 固定113P/新Actor/本名金融会計を認証して独立P115を停止する。

    引数: なし。
    返り値: dictは新P停止Ref。実市場やRawを読まない。
    """
    target,output=OWN/'P停止.json',OWN/'P検査'
    S.need(not target.exists() and not output.exists(),'115P停止の新規先')
    owned={str(OWN/name):S.digest(OWN/name) for name in ('新保護の独立監査.py','保護監査の人工検査.py','Pを検査して停止する.py','P_README.md')}
    actor=S.ROOT/'work/115三時間軸の複合入口を執行する会計/Actor停止.json'
    old=S.ROOT/'work/113起動前の構造失効を執行する会計/P停止.json'
    S.equal(S.digest(actor),'318de27a32a0941114443e5045426df3599eea74e8e5ffa8647771e92934ce35','115Actor停止')
    S.equal(S.digest(old),'25432cfb24561cd6beab9dbecffa64f20aad5afd8cf28beeeb01db725034f77b','旧113P停止')
    deps={str(actor):S.digest(actor),str(old):S.digest(old),str(P.PREVIOUS_PATH):P.PREVIOUS_SHA,
          str(OWN/'金融の独立検算.py'):S.digest(OWN/'金融の独立検算.py'),str(T.MANIFEST):T.MANIFEST_SHA}
    for data in (S.load(actor),S.load(old)):
        for field in ('所有コードSHA256','所有ファイルSHA256','再用コードSHA256','依存SHA256'):
            deps.update(data.get(field,{}))
    core=S.ROOT/'work/115三時間軸の複合入口の連続比較/停止.json'
    S.equal(S.digest(core),'1dca0288b00682c965491bcf0209a45a0bbc4eaf527b0224063db9bcda7f77d8','115Core停止')
    deps[str(core)]=S.digest(core)
    deps[str(T.ACTOR_MANIFEST)]=T.ACTOR_SHA
    for field in ('所有コードSHA256','再用コードSHA256','依存SHA256'):
        deps.update(S.load(core).get(field,{}))
    S.need(all(S.digest(Path(p))==h for p,h in deps.items()),'115P依存の全現物SHA')
    output.mkdir()
    result=subprocess.run([sys.executable,'-X','utf8',str(OWN/'保護監査の人工検査.py')],cwd=OWN,capture_output=True,text=True,encoding='utf-8',timeout=60)
    log=output/'人工検査.txt';log.write_text(result.stdout+result.stderr,encoding='utf-8',newline='\n')
    S.need(result.returncode==0,'115P全人工成功')
    S.need(all(S.digest(Path(p))==h for p,h in {**owned,**deps}.items()),'115P所有/依存前後不変')
    record={'試行':115,'成功':True,'市場前':True,'所有ファイルSHA256':owned,'依存SHA256':deps,
            '所有前後同体':True,'主人工':2,'手製Core会計':72,'別Actor旧114A0対照':8,'自然Source生成/全出生の証明':False,
            '同体再用':{'path':str(P.PREVIOUS_PATH),'sha256':P.PREVIOUS_SHA},
            'ログ':{'path':str(log),'sha256':S.digest(log)},'API':'verify_protection(book,config,finance,context)',
            '限界':'113の少数保存点exact/bounded・未保存中間純点・Raw初回適格別走なしを維持。',
            '実市場/Raw/価格CSV/11月09日本文':False,'研究目標達成':False,'採用':False}
    S.BASE.write_json(target,record)
    return {'成功':True,'停止':{'path':str(target),'sha256':S.digest(target)}}


if __name__=='__main__':print(json.dumps(main(),ensure_ascii=False))
