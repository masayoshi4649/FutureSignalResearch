# 115の共通P100独立保護監査

新入口A0/T/TR×4費用の本名Configを保持し、固定113の`protection113`と純定義113/P100を有理数・三値演算で独立検算する。新しいE/H50は許可しない。旧113P監査の全演算は同体の明示SHA importで再用し、キーやentry_modeを旧名へ書換えない。

APIは `verify_protection(book,config,finance,context)`。contextはCore.actual全体、financeは115の独立台帳会計。初期q0、実R/n、取得時ATR、費用、最低/全玉床、狭幅、取得後構造床、Source予約優先・部分返済・全予約を検査する。旧113のexact/boundedと中間純点未保存・Raw別走未実証の限界を継承する。未来最大益や退出後の価格を作らない。

人工は手製Core六ケース72冊で会計/Pを確認し、別Actor手製買売の旧114A0八対照を独立に確認する。Coreの最小Sourceを自然生成・全出生の証明にはしない。Policy/定義/State破壊を拒否する。市場/Raw/CSV/11月09日本文を読まない。入口票は別の独立Python監査へ結び、保護Pの成立と混同しない。
