"""115純入口の人工・実API・bank依存を金融市場前に停止する。"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import hashlib
import json
import os
import shutil
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OWNED=("types.go","history.go","evaluate.go","entry_test.go","cmd/declaration/main.go","go.mod","README.md",Path(__file__).name)
OLD={"work/114順行と反転取得の純判定/停止.json":"3e721f461a0b737140771335bcee67c033f3413a911910cf256f1b453f8037d6","work/三時間軸の公開器/停止.json":"b6b1a326cc98f67e13ec1962a19bac001eda743880b74a13066a2307c5944895"}


def digest(path: Path) -> str:
    """
    機能: 明示コード/小metadataの全bytes指紋を求める。
    引数: path(Path)。返り値: strはSHA256。Rawは対象外。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ref(path: Path) -> dict:
    """
    機能: 明示成果物を絶対FileRefへ写す。
    引数: path(Path)。返り値: dictはpath/sha256。
    """
    return {"path":str(path.resolve()),"sha256":digest(path)}


def run(command: list[str],env: dict) -> dict:
    """
    機能: Go依存列挙・人工・宣言・API・buildだけを実行する。
    引数: command(list[str])、env(dict)。返り値: dictは成功ログ。
    """
    p=subprocess.run(command,cwd=HERE,env=env,capture_output=True,text=True,encoding="utf-8",timeout=60);record={"command":command,"exit_code":p.returncode,"stdout":p.stdout,"stderr":p.stderr}
    if p.returncode:raise ValueError(json.dumps(record,ensure_ascii=False))
    return record


def closure(env: dict) -> dict:
    """
    機能: 実コンパイルのGo/asm/embed/module/Go実行物を認証する。
    引数: env(dict)。返り値: dictは絶対path→SHA256。
    """
    raw=run(["go","list","-deps","-json","./..."],env)["stdout"];decoder=json.JSONDecoder();pos=0;paths=set()
    while raw[pos:].strip():
        pos+=len(raw[pos:])-len(raw[pos:].lstrip());package,pos=decoder.raw_decode(raw,pos);folder=Path(package["Dir"])
        for field in ("GoFiles","CgoFiles","SFiles","HFiles","SysoFiles","EmbedFiles"):
            for name in package.get(field,[]):paths.add((folder/name).resolve())
        module=package.get("Module") or {}
        for item in (module,module.get("Replace") or {}):
            if item.get("GoMod"):paths.add(Path(item["GoMod"]).resolve())
    paths.add(Path(shutil.which("go")).resolve());return {str(p):digest(p) for p in sorted(paths,key=str)}


def authenticate_stop(path: Path,sha: str,before: dict) -> dict:
    """
    機能: 停止Refと所有codeを前後台帳へ認証する。
    引数: path(Path)、sha(str)、before(dict)。返り値: dictは停止原値。
    """
    path=path.resolve()
    if digest(path)!=sha:raise ValueError("停止SHA差:"+str(path))
    before[str(path)]=sha;v=json.loads(path.read_text(encoding="utf-8-sig"))
    if v.get("成功") is not True:raise ValueError("依存停止失敗")
    for field in ("所有コードSHA256","所有ファイルSHA256","コードSHA256前"):
        for name,expected in v.get(field,{}).items():
            p=Path(name);p=(p if p.is_absolute() else ROOT/p).resolve()
            if digest(p)!=expected:raise ValueError("依存code差:"+str(p))
            before[str(p)]=expected
    return v


def main() -> None:
    """
    機能: 所有8ファイル・bank停止・10主人工・実定義/APIを市場前固定する。
    引数: CLI bank-stop(Path)、bank-sha(str)。返り値: None。市場本文/金融は実行しない。
    """
    p=argparse.ArgumentParser();p.add_argument("--bank-stop",type=Path,required=True);p.add_argument("--bank-sha",required=True);args=p.parse_args()
    target,out=HERE/"停止.json",HERE/"検査"
    if target.exists() or out.exists():raise ValueError("新規停止だけ")
    before={};stops={};own={str((HERE/name).resolve()):digest(HERE/name) for name in OWNED};env=dict(os.environ,CGO_ENABLED="0",GOWORK="off")
    for name,sha in OLD.items():
        path=ROOT/name;authenticate_stop(path,sha,before);stops[name]=ref(path)
    bank=authenticate_stop(args.bank_stop,args.bank_sha,before)
    if bank.get("試行",bank.get("trial"))!=115 or bank.get("市場前") is not True:raise ValueError("115bank市場前停止差")
    stops["bank115"]=ref(args.bank_stop);dependencies=closure(env);out.mkdir()
    logs=[run(["go","test","-count=1","-json","-cover","./..."],env),run(["go","vet","./..."],env),run(["go","build","./..."],env),run(["go","run","./cmd/declaration"],env),run(["go","doc","-all","."],env)]
    passed=[json.loads(line)["Test"] for line in logs[0]["stdout"].splitlines() if line.startswith("{") and json.loads(line).get("Action")=="pass" and "Test" in json.loads(line)]
    if len(passed)!=10:raise ValueError("10主人工不足")
    definition=json.loads(logs[3]["stdout"])
    if definition["version"]!=115 or definition["adx_minimum"]!=20 or definition["spike_multiple"]!=2 or definition["modes"]!=["A0","T","TR"] or definition["refill_evaluation"] is not False:raise ValueError("115実宣言差")
    (out/"実定義.json").write_text(json.dumps(definition,ensure_ascii=False,indent=2)+"\n",encoding="utf-8");(out/"API.txt").write_text(logs[4]["stdout"],encoding="utf-8",newline="\n")
    exportenv=dict(env,ENTRYGATE115_EXPORT=str((out/"人工.json").resolve()));logs.append(run(["go","test","-count=1","-run","^TestExport$","."],exportenv));art=json.loads((out/"人工.json").read_text(encoding="utf-8"))
    if art["natural_source"] is not False or len(art["decisions"])!=4 or art["definition"]!=definition:raise ValueError("手製票集合差")
    allbefore={**before,**own,**dependencies}
    if any(digest(Path(path))!=sha for path,sha in allbefore.items()):raise ValueError("全所有依存前後不変差")
    value={"試行":115,"trial":115,"成功":True,"停止":True,"市場前":True,"UTC":datetime.now(timezone.utc).isoformat(),"module":"github.com/masayoshi4649/SessionTradeExecuter/entrygate115","所有コードSHA256":own,"再用コードSHA256":before,"実Go依存SHA256":dependencies,"全所有依存前後不変":True,"依存停止":stops,"主人工":10,"成功test":passed,"実定義":ref(out/"実定義.json"),"実API":ref(out/"API.txt"),"Go人工":ref(out/"人工.json"),"人工Decision数":4,"検査ログ":logs,"Raw/Native/価格CSV/11月09本文読取":0,"金融市場実行":False,"旧Source/Chart/Actor/金融変更":False}
    with target.open("x",encoding="utf-8",newline="\n") as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps({"成功":True,"停止":ref(target),"実定義":value["実定義"],"Go人工":value["Go人工"]},ensure_ascii=False))


if __name__=="__main__":main()
