// Package entrygate115 は配送済みの5/15/30分公表と要求時Lastから入口票を固定します。
package entrygate115

import bank "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"

type Truth uint8

const (
	Unknown Truth = iota
	False
	True
)

type Scope struct {
	Session  string  `json:"session"`
	Contract string  `json:"contract"`
	Start    float64 `json:"start"`
	End      float64 `json:"end"`
}

type Stamp struct {
	Time  float64 `json:"time"`
	Index int     `json:"index"`
	Line  int64   `json:"source_line"`
}

type Request struct {
	Product  string  `json:"product"`
	Method   string  `json:"method"`
	SignalID string  `json:"signal_id"`
	Side     int     `json:"side"`
	At       Stamp   `json:"at"`
	Last     float64 `json:"last"`
}

type Publication struct {
	Snapshot  bank.Snapshot `json:"snapshot"`
	Delivered Stamp         `json:"delivered"`
}

type Values struct {
	G30          *float64 `json:"g30"`
	D15          *float64 `json:"d15"`
	ADX15        *float64 `json:"adx15"`
	Boundary     *float64 `json:"boundary"`
	FiveClose    *float64 `json:"five_close"`
	CloseBreak   *float64 `json:"close_break"`
	LastBreak    *float64 `json:"last_break"`
	TR5          *float64 `json:"tr5"`
	PreviousATR5 *float64 `json:"previous_atr5"`
	SpikeMargin  *float64 `json:"spike_margin"`
	PreviousD15  *float64 `json:"previous_d15"`
	ADX15Delta   *float64 `json:"adx15_delta"`
}

type Condition struct {
	ID    string   `json:"id"`
	Value *float64 `json:"value"`
	Op    string   `json:"op"`
	Truth Truth    `json:"truth"`
}

type Decision struct {
	Version            int          `json:"version"`
	Scope              Scope        `json:"scope"`
	Request            Request      `json:"request"`
	Current            *Publication `json:"current"`
	Values             Values       `json:"values"`
	Common             Truth        `json:"common"`
	Trend              Truth        `json:"trend"`
	Reversal           Truth        `json:"reversal"`
	Combined           Truth        `json:"combined"`
	CommonConditions   []Condition  `json:"common_conditions"`
	TrendConditions    []Condition  `json:"trend_conditions"`
	ReversalConditions []Condition  `json:"reversal_conditions"`
	MissingInputs      []string     `json:"missing_inputs"`
	CommonDenials      []string     `json:"common_denials"`
	TrendDenials       []string     `json:"trend_denials"`
	ReversalDenials    []string     `json:"reversal_denials"`
	Frozen             bool         `json:"frozen"`
}

type Definition struct {
	Version               int      `json:"version"`
	SourceClock           string   `json:"source_clock"`
	Common                string   `json:"common"`
	Trend                 string   `json:"trend"`
	Reversal              string   `json:"reversal"`
	ADXMinimum            float64  `json:"adx_minimum"`
	SpikeMultiple         float64  `json:"spike_multiple"`
	PreviousStructureBars int      `json:"previous_structure_bars"`
	Freshness             string   `json:"freshness"`
	DIRecovery            string   `json:"di_recovery"`
	Modes                 []string `json:"modes"`
	RefillEvaluation      bool     `json:"refill_evaluation"`
}

type History struct {
	scope      Scope
	current    *Publication
	seen       map[string]bank.Frame
	maximum    [3]float64
	lastEvent  *Stamp
	requestRow *Stamp
	frozen     map[string]Decision
}
