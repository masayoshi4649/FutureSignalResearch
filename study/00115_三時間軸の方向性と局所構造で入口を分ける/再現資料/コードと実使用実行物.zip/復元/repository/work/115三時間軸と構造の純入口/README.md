# 115の三時間軸・構造の純入口

市場前の純Goモジュール。`threeframe115` の値型SnapshotとSource新規要求時Lastだけから判定し、金融実行・Raw/Native/CSV本文I/Oは行わない。旧Source111、P113/P100、114純入口と停止物は変更しない。

## 実API

`NewHistory(Scope)` → `(*History,error)`、`SetSnapshot(bank.Snapshot,Stamp)` → `error`、同義の `Step`、`Evaluate(Request)` → `(Decision,error)`、`DeclaredDefinition()` → `Definition`。

Scopeは場/限月/開始/終了。StampはSource原行のTime・Index・SourceLine。RequestはProduct・Method・SignalID・Side・Atと、同要求行のLastを明示する。Actorからsnapshot配送→Source新規要求の順で呼ぶ。Snapshot.AsOfとReplayObservedAtはStamp.Time、RecordOrdinalはIndex+1へ厳密結合する。Source信号のない原行に純Historyを呼ぶ必要はなく、ordinalの飛びを許す。bank自体は全原行をAdvanceする。

全3尺度のSnapshotをCurrentへ同値保存する。Snapshot/bank.Frameは入れ子もすべて値型・固定長配列。floatポインタ、条件配列、理由配列、Currentポインタは私有copyする。未知はTruth0、偽1、真2。三値ANDは既知偽を、ORは既知真を優先する。

## 固定式

買いs=+1、売りs=−1。30分Gは `s*(EMA8−EMA21)`、15分Dは `s*(DI+−DI−)`。

- 共通：5分確定Closeが現在足を含まない直前3本のHigh（買）/Low（売）をstrict突破。前ATR14>0。TR5≤2×前ATR14。要求時Lastも同じ構造境界の順側をstrict維持する。
- T：共通 AND G>0 AND D>0 AND ADX15≥20。
- R：共通 AND G<0 AND D>0。直近DI交差・ADX増分は必須にしない。
- TR：T OR R。A0はActor側で全元要求を許可し、同じ技法票だけ保存する。

TR上限は除算せず `2*前ATR−TR>=0` で同条件を評価する。前ATR既知0/負は正値条件の既知偽。ATR未知は不足。閾値は0/20/2の事前固定値で、丸め・許容誤差・市場別の後付け最適化を入れない。

Freshは当場の最新公表で、要求Time−AvailableAtが各尺度幅未満であることをbankフラグと再照合する。SeedOnlyは値が既知でも入口に使わない。現在価格不明や欠足公表はUnknown。初期warmup/値seedの規則はbankの実宣言に従い、純入口で再計算しない。同IDのFrame/DMI/構造は全値不変、同終端のID付替え・未来公表・同秒後原行の公表を拒否する。

Source出生ごとに当原行Snapshot/Lastで一度freezeする。同じ公表を同原行/後原行の別出生が参照できる。同じ複合出生（商品/手法/side/SignalID）のEvaluate再呼出しはエラー。114の同一要求copy再取得APIとの差であり、fillの再評価を許可するものではない。要求後に同原行Snapshotを追加することも拒否する。

## 保存票と診断の範囲

Decision.Common/Trend/Reversal/Combinedは最終票。CommonConditionsと各経路の条件を分け、TrendDenials/ReversalDenialsには共通否定も含める。MissingInputsは両経路に関連する全入力の不足で、選択された経路の未知と同義ではない。例えばR真でもTだけが使うADX不足を記録できる。

ValuesはG30/D15/ADX15、構造境界、5分Close、Close突破差、Last保持差、TR、前ATR、TR上限余裕、前D15/ADX増分。Snapshotには元bankのRSI現前値等も残す。DI最終交差時刻/経過足、RSI復帰時刻の専用fieldは今回実装しない。新しい5/15/30分BBもなく、旧P100の3分BBとは別。これらを後段の公表列から構成する診断や次候補と、実装済み票を混同しない。

当場fresh判定をするので、元公表を消費者が改変して使い回すことはできない。封印snapshotは新要求へ受理しない。実fill/返済/数量/予約はActorの別責務で、本モジュールへ返送しない。

## 人工と停止

`go test -count=1 -v ./...`、`go vet ./...`、`go build ./...`。10主人工では、全三値9組、閾値等号、鏡像、Rで不要なADX/交差、SeedOnly/欠足/fresh期限、未来・別場・同秒後行、同ID不変、別出生の反復、再freeze禁止、alias、未来追加非干渉、実bank人工180本の無変換受渡しを確認する。`TestExport`は明示環境変数時だけ4手製票を出し、自然Sourceや市場の証明とは扱わない。

bank停止後、`python -X utf8 検査して停止する.py --bank-stop <絶対停止path> --bank-sha <SHA>` で、旧停止・実Go依存・人工・実API/宣言・所有全ファイルを前後同体で新規停止する。市場・Raw本文を読まない。市場成績・採用・未知期間の安定性は未確認。
