package entrygate115

import (
	"encoding/json"
	"fmt"
	"math"
	"reflect"

	bank "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

// DeclaredDefinition は115の純入口式と要求時時計を返します。
//
// 引数: ありません。返り値: Definitionは独立した宣言です。
func DeclaredDefinition() Definition {
	return Definition{115, "Source新規要求の当原行SnapshotとLastを一度固定。fill再判定なし", "前3本構造の確定Close突破 AND 前ATR14>0 AND TR5<=2*前ATR14 AND 要求時Lastが同境界の順側", "Common AND G30>0 AND D15>0 AND ADX15>=20", "Common AND G30<0 AND D15>0", 20, 2, 3, "当場公表、要求時計−AvailableAt<各尺度秒、SeedOnlyは利用不可", "D15>0は状態。直近交差/ADX増分は診断のみ", []string{"A0", "T", "TR"}, false}
}

// finite は全数値が有限であることを確認します。
//
// 引数: values(...float64)。返り値: boolはNaN/Infが無い場合に真です。
func finite(values ...float64) bool {
	for _, x := range values {
		if math.IsNaN(x) || math.IsInf(x, 0) {
			return false
		}
	}
	return true
}

// NewHistory は一場・同限月だけの純入口履歴を空から作ります。
//
// 引数: scope(Scope)。返り値: *History/errorは履歴又は場境界不正です。
func NewHistory(scope Scope) (*History, error) {
	if scope.Session == "" || scope.Contract == "" || !finite(scope.Start, scope.End) || scope.Start <= 0 || scope.End <= scope.Start {
		return nil, fmt.Errorf("115入口の場境界不正")
	}
	return &History{scope: scope, seen: map[string]bank.Frame{}, frozen: map[string]Decision{}}, nil
}

// checkStamp は同秒原行を保持しながら時間・Index・物理行の後退を拒否します。
//
// 引数: at(Stamp)。返り値: errorは原行不正又は後退です。
func (h *History) checkStamp(at Stamp) error {
	if h == nil || h.seen == nil || !finite(at.Time) || at.Time < h.scope.Start || at.Time > h.scope.End || at.Index < 0 || at.Line <= 0 {
		return fmt.Errorf("115入口の原行/未初期化不正")
	}
	if h.lastEvent != nil {
		p := *h.lastEvent
		if at.Time < p.Time || at.Index < p.Index || at.Line < p.Line {
			return fmt.Errorf("115入口の原行後退")
		}
		if (at.Index == p.Index || at.Line == p.Line) && at != p {
			return fmt.Errorf("115入口の同原行stamp改変")
		}
	}
	return nil
}

// validateSnapshot は当原行公表と数値・三尺度・前3本の当時性を検査します。
//
// 引数: snapshot(bank.Snapshot)、at(Stamp)。返り値: errorは偽装/未来/別場等の不正です。
func (h *History) validateSnapshot(snapshot bank.Snapshot, at Stamp) error {
	if _, err := json.Marshal(snapshot); err != nil {
		return fmt.Errorf("115公表の非有限値: %w", err)
	}
	s := snapshot.Session
	if s.ID != h.scope.Session || s.Contract != h.scope.Contract || s.Start != h.scope.Start || s.End != h.scope.End || s.EOF < s.Start || s.EOF > s.End || at.Time > s.EOF || snapshot.AsOf != at.Time || snapshot.ReplayObservedAt != at.Time || !snapshot.HasObserved || snapshot.RecordOrdinal != uint64(at.Index)+1 || snapshot.Sealed {
		return fmt.Errorf("115の別場/未来/非当行/封印snapshot")
	}
	for i, w := range [3]int{300, 900, 1800} {
		x := snapshot.Scales[i]
		if x.WidthSeconds != w {
			return fmt.Errorf("115尺度集合/順序不正")
		}
		if !x.HasCurrent {
			if x.Fresh || h.maximum[i] > 0 {
				return fmt.Errorf("115公表を消失/種だけでfresh偽装")
			}
			continue
		}
		f := x.Current.Frame
		if x.SeedOnly || f.ID == "" || f.SessionID != s.ID || f.Contract != s.Contract || f.WidthSeconds != w || f.Start < s.Start || f.End-f.Start != float64(w) || f.End > s.End || f.NominalAvailable < f.End || f.AvailableAt < f.NominalAvailable || f.AvailableAt > at.Time || f.ObservedAt > at.Time || f.DeliveryAt > at.Time || f.ObservedAt < f.AvailableAt || f.DeliveryAt < f.ObservedAt || f.RecordOrdinal == 0 || f.RecordOrdinal > snapshot.RecordOrdinal || f.PublicationOrdinal == 0 || x.Fresh != (at.Time-f.AvailableAt < float64(w)) {
			return fmt.Errorf("115公表の時点/尺度/fresh不正")
		}
		if f.End < h.maximum[i] {
			return fmt.Errorf("115公表終端の後退")
		}
		if old, ok := h.seen[f.ID]; ok && !reflect.DeepEqual(old, x.Current) {
			return fmt.Errorf("115同ID公表の値改変")
		}
		if old, ok := h.seen[f.ID]; !ok && f.End == h.maximum[i] && h.maximum[i] > 0 {
			return fmt.Errorf("115同終端の公表ID付替え")
		} else if ok && old.Frame.WidthSeconds != w {
			return fmt.Errorf("115同IDの尺度付替え")
		}
		if f.PriceKnown && (!finite(f.OHLC.Open, f.OHLC.High, f.OHLC.Low, f.OHLC.Close) || f.OHLC.Low <= 0 || f.OHLC.High < f.OHLC.Low || f.OHLC.Open < f.OHLC.Low || f.OHLC.Open > f.OHLC.High || f.OHLC.Close < f.OHLC.Low || f.OHLC.Close > f.OHLC.High) {
			return fmt.Errorf("115既知OHLC不正")
		}
		st := x.Current.Structure
		if st.Known {
			if w != 300 || !f.PriceKnown || st.Low <= 0 || st.High < st.Low {
				return fmt.Errorf("115前3本構造の尺度/価格不正")
			}
			for j, r := range st.Refs {
				if r.ID == "" || r.End-r.Start != 300 || r.Start < s.Start || r.End != f.Start-float64(2-j)*300 || r.PublishedAt < r.End || r.PublishedAt > at.Time {
					return fmt.Errorf("115前3本の当場/連続/非未来不正")
				}
			}
		}
	}
	return nil
}

// SetSnapshot は要求原行までのbank値copyを受け、同原行要求後の改変を拒否します。
//
// 引数: snapshot(bank.Snapshot)、at(Stamp)。返り値: errorは因果/同ID/順序不正です。
func (h *History) SetSnapshot(snapshot bank.Snapshot, at Stamp) error {
	if err := h.checkStamp(at); err != nil {
		return err
	}
	if h.requestRow != nil && *h.requestRow == at {
		return fmt.Errorf("115要求後の同原行snapshot配送")
	}
	if err := h.validateSnapshot(snapshot, at); err != nil {
		return err
	}
	if h.current != nil && h.current.Delivered == at && h.current.Snapshot != snapshot {
		return fmt.Errorf("115同原行snapshot改変")
	}
	for i, x := range snapshot.Scales {
		if x.HasCurrent {
			h.seen[x.Current.Frame.ID] = x.Current
			h.maximum[i] = x.Current.Frame.End
		}
	}
	h.current = &Publication{Snapshot: snapshot, Delivered: at}
	x := at
	h.lastEvent = &x
	return nil
}

// Step はSetSnapshotと同じ当原行配送APIです。
//
// 引数: snapshot(bank.Snapshot)、at(Stamp)。返り値: errorは配送不正です。
func (h *History) Step(snapshot bank.Snapshot, at Stamp) error { return h.SetSnapshot(snapshot, at) }

// requestKey は同じ場内の複合Source出生を衝突しない形に写します。
//
// 引数: r(Request)。返り値: stringは商品/手法/売買/SignalIDのキーです。
func requestKey(r Request) string {
	b, _ := json.Marshal([]any{r.Product, r.Method, r.Side, r.SignalID})
	return string(b)
}

// Evaluate は当原行のSnapshotとLastでSource出生を一度だけ固定します。
//
// 引数: r(Request)。返り値: Decision/errorは私有固定票又は重複/因果不正です。
func (h *History) Evaluate(r Request) (Decision, error) {
	if err := h.checkStamp(r.At); err != nil {
		return Decision{}, err
	}
	if r.Product == "" || r.Method == "" || r.SignalID == "" || (r.Side != 1 && r.Side != -1) || !finite(r.Last) || r.Last <= 0 {
		return Decision{}, fmt.Errorf("115のSource要求/Last不正")
	}
	key := requestKey(r)
	if _, ok := h.frozen[key]; ok {
		return Decision{}, fmt.Errorf("115同Source出生の再freeze")
	}
	if h.current == nil || h.current.Delivered != r.At {
		return Decision{}, fmt.Errorf("115要求の当原行snapshotなし")
	}
	d := evaluate(h.scope, r, *h.current)
	for _, p := range numbers(d.Values) {
		if p != nil && !finite(*p) {
			return Decision{}, fmt.Errorf("115派生値の有限範囲外")
		}
	}
	h.frozen[key] = copyDecision(d)
	x, y := r.At, r.At
	h.lastEvent = &x
	h.requestRow = &y
	return copyDecision(d), nil
}
