package main

import (
	"encoding/json"
	"os"

	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate115"
)

// main は実コンパイルされた115入口宣言をJSONへ出力します。
//
// 引数: ありません。返り値: ありません。金融/市場入力は読みません。
func main() {
	if err := json.NewEncoder(os.Stdout).Encode(gate.DeclaredDefinition()); err != nil {
		panic(err)
	}
}
