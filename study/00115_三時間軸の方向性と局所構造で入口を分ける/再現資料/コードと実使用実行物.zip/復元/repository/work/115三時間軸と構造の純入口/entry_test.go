package entrygate115

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	old "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	bank "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

// known は人工の既知数値を作ります。
//
// 引数: value(float64)。返り値: bank.Valueは既知の値です。
func known(value float64) bank.Value { return bank.Value{Known: true, Value: value} }

// fixture は市場を使わず、T/Rと売買鏡像の当原行公表を作ります。
//
// 引数: side(int)、reversal(bool)。返り値: Scope/bank.Snapshot/Requestは手製入力です。
func fixture(side int, reversal bool) (Scope, bank.Snapshot, Request) {
	scope := Scope{"人工場", "人工限月", 1800000000, 1800030000}
	at := Stamp{scope.Start + 2460, 100, 111}
	snapshot := bank.Snapshot{Session: old.Session{ID: scope.Session, Contract: scope.Contract, Start: scope.Start, End: scope.End, EOF: scope.End}, AsOf: at.Time, ReplayObservedAt: at.Time, HasObserved: true, RecordOrdinal: 101}
	for i, w := range [3]int{300, 900, 1800} {
		end := scope.Start + 1800
		if w == 300 {
			end = scope.Start + 2400
		}
		f := old.Frame{ID: fmt.Sprintf("%s/%d/%.0f", scope.Session, w, end), SessionID: scope.Session, Contract: scope.Contract, WidthSeconds: w, Start: end - float64(w), End: end, NominalAvailable: end + 60, AvailableAt: end + 60, ObservedAt: end + 60, DeliveryAt: end + 60, RecordOrdinal: 70, PublicationOrdinal: uint64(i + 1), PriceKnown: true, OHLC: old.OHLC{Open: 1090, High: 1120, Low: 1085, Close: 1110}}
		f.Technical.EMA8 = known(1020)
		f.Technical.EMA21 = known(1000)
		f.Technical.TR = known(35)
		f.Technical.PreviousATR = known(20)
		if reversal {
			f.Technical.EMA8 = known(980)
		}
		x := bank.ScaleSnapshot{WidthSeconds: w, HasCurrent: true, Fresh: true, Current: bank.Frame{Frame: f, DMI: bank.DMI{PlusDI: known(30), MinusDI: known(10), ADX: known(20), PreviousPlusDI: known(30), PreviousMinusDI: known(10), PreviousADX: known(25)}}}
		if w == 300 {
			x.Current.Structure = bank.Structure{Known: true, High: 1100, Low: 1050}
			for j := range 3 {
				e := f.Start - float64(2-j)*300
				x.Current.Structure.Refs[j] = old.BarRef{ID: fmt.Sprintf("past%d", j), Start: e - 300, End: e, PublishedAt: e + 60}
			}
		}
		snapshot.Scales[i] = x
	}
	r := Request{Product: "NK225mini", Method: "NK225_D164_15", SignalID: "人工出生", Side: side, At: at, Last: 1112}
	if side < 0 {
		r.Last = 2000 - r.Last
		for i := range snapshot.Scales {
			x := &snapshot.Scales[i]
			f := &x.Current.Frame
			o := f.OHLC
			f.OHLC = old.OHLC{Open: 2000 - o.Open, High: 2000 - o.Low, Low: 2000 - o.High, Close: 2000 - o.Close}
			f.Technical.EMA8.Value = 2000 - f.Technical.EMA8.Value
			f.Technical.EMA21.Value = 2000 - f.Technical.EMA21.Value
			d := &x.Current.DMI
			d.PlusDI, d.MinusDI = d.MinusDI, d.PlusDI
			d.PreviousPlusDI, d.PreviousMinusDI = d.PreviousMinusDI, d.PreviousPlusDI
			if x.Current.Structure.Known {
				st := &x.Current.Structure
				st.High, st.Low = 2000-st.Low, 2000-st.High
			}
		}
	}
	return scope, snapshot, r
}

// runFixture は人工入力を実純APIへ一回配送します。
//
// 引数: t(*testing.T)、scope(Scope)、s(bank.Snapshot)、r(Request)。返り値: Decision/*Historyは判定と履歴です。
func runFixture(t *testing.T, scope Scope, s bank.Snapshot, r Request) (Decision, *History) {
	t.Helper()
	h, err := NewHistory(scope)
	if err != nil {
		t.Fatal(err)
	}
	if err = h.SetSnapshot(s, r.At); err != nil {
		t.Fatal(err)
	}
	d, err := h.Evaluate(r)
	if err != nil {
		t.Fatal(err)
	}
	return d, h
}

// TestTruth は全9組の三値AND/ORと真OR未知を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestTruth(t *testing.T) {
	for a := Unknown; a <= True; a++ {
		for b := Unknown; b <= True; b++ {
			and, or := Unknown, Unknown
			if a == False || b == False {
				and = False
			} else if a == True && b == True {
				and = True
			}
			if a == True || b == True {
				or = True
			} else if a == False && b == False {
				or = False
			}
			if And(a, b) != and || Or(a, b) != or {
				t.Fatal(a, b)
			}
		}
	}
}

// TestTrendReversalMirror は売買鏡像とRで不要なADX/直近DI交差を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestTrendReversalMirror(t *testing.T) {
	for _, reversal := range []bool{false, true} {
		var first Values
		for _, side := range []int{1, -1} {
			s, snap, r := fixture(side, reversal)
			if reversal {
				snap.Scales[1].Current.DMI.ADX = bank.Value{}
				snap.Scales[1].Current.DMI.PreviousADX = bank.Value{}
			}
			d, _ := runFixture(t, s, snap, r)
			wantT, wantR := True, False
			if reversal {
				wantT, wantR = False, True
			}
			if d.Trend != wantT || d.Reversal != wantR || d.Common != True || d.Combined != True {
				t.Fatal(d)
			}
			if side == 1 {
				first = d.Values
			} else {
				if *first.G30 != *d.Values.G30 || *first.D15 != *d.Values.D15 || *first.CloseBreak != *d.Values.CloseBreak || *first.LastBreak != *d.Values.LastBreak || *first.SpikeMargin != *d.Values.SpikeMargin {
					t.Fatal("鏡像差")
				}
			}
		}
	}
}

// TestThresholdEqualities はADX20・TR2倍等号と厳密な価格/方向零を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestThresholdEqualities(t *testing.T) {
	s, snap, r := fixture(1, false)
	snap.Scales[0].Current.Frame.Technical.TR = known(40)
	d, _ := runFixture(t, s, snap, r)
	if d.Trend != True || *d.Values.SpikeMargin != 0 {
		t.Fatal("TR等号を拒否")
	}
	for _, field := range []string{"adx", "tr", "close", "last", "g", "di", "atr0"} {
		s, snap, r := fixture(1, false)
		switch field {
		case "adx":
			snap.Scales[1].Current.DMI.ADX = known(19.999)
		case "tr":
			snap.Scales[0].Current.Frame.Technical.TR = known(40.001)
		case "close":
			snap.Scales[0].Current.Frame.OHLC.Close = snap.Scales[0].Current.Structure.High
		case "last":
			r.Last = snap.Scales[0].Current.Structure.High
		case "g":
			snap.Scales[2].Current.Frame.Technical.EMA8 = snap.Scales[2].Current.Frame.Technical.EMA21
		case "di":
			snap.Scales[1].Current.DMI.PlusDI = snap.Scales[1].Current.DMI.MinusDI
		case "atr0":
			snap.Scales[0].Current.Frame.Technical.PreviousATR = known(0)
		}
		d, _ := runFixture(t, s, snap, r)
		if d.Trend != False || len(d.TrendDenials) == 0 {
			t.Fatal(field, d)
		}
	}
}

// TestUnknownAndKnownDenial は不足・既知偽・Rで使わないADX不足を分けます。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestUnknownAndKnownDenial(t *testing.T) {
	s, snap, r := fixture(1, false)
	snap.Scales[1].Current.DMI.ADX = bank.Value{}
	d, _ := runFixture(t, s, snap, r)
	if d.Trend != Unknown || len(d.MissingInputs) == 0 || len(d.TrendDenials) != 0 {
		t.Fatal(d)
	}
	snap.Scales[2].Current.Frame.Technical.EMA8 = snap.Scales[2].Current.Frame.Technical.EMA21
	d, _ = runFixture(t, s, snap, r)
	if d.Combined != False || len(d.MissingInputs) == 0 {
		t.Fatal(d)
	}
	s, snap, r = fixture(1, true)
	snap.Scales[1].Current.DMI.ADX = bank.Value{}
	d, _ = runFixture(t, s, snap, r)
	if d.Reversal != True || !reflect.DeepEqual(d.MissingInputs, []string{"15m.adx"}) {
		t.Fatal(d)
	}
}

// TestSeedStaleAndBadPrice は数値種だけ・期限等号・欠足公表からの復活を拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestSeedStaleAndBadPrice(t *testing.T) {
	for _, field := range []string{"seed", "stale", "price", "structure"} {
		s, snap, r := fixture(1, false)
		switch field {
		case "seed":
			snap.Scales[2] = bank.ScaleSnapshot{WidthSeconds: 1800, SeedOnly: true, SeedTechnical: snap.Scales[2].Current.Frame.Technical}
		case "stale":
			r.At.Time += 300
			snap.AsOf = r.At.Time
			snap.ReplayObservedAt = r.At.Time
			snap.Scales[0].Fresh = false
			snap.Scales[1].Fresh = false
		case "price":
			snap.Scales[0].Current.Frame.PriceKnown = false
			snap.Scales[0].Current.Structure.Known = false
		case "structure":
			snap.Scales[0].Current.Structure.Known = false
		}
		d, _ := runFixture(t, s, snap, r)
		if d.Trend != Unknown || d.Combined == True {
			t.Fatal(field, d)
		}
	}
}

// TestFutureScopeAndCorruption は未来/同秒後行/別場/限月/構造の改変を拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestFutureScopeAndCorruption(t *testing.T) {
	for _, field := range []string{"asof", "contract", "scope", "ordinal", "frame_ordinal", "frame_time", "fresh", "structure", "nan", "width", "sealed"} {
		s, snap, r := fixture(1, false)
		h, _ := NewHistory(s)
		switch field {
		case "asof":
			snap.AsOf++
		case "contract":
			snap.Session.Contract = "別"
		case "scope":
			snap.Scales[0].Current.Frame.SessionID = "別"
		case "ordinal":
			snap.RecordOrdinal++
		case "frame_ordinal":
			snap.Scales[0].Current.Frame.RecordOrdinal = snap.RecordOrdinal + 1
		case "frame_time":
			snap.Scales[0].Current.Frame.DeliveryAt = r.At.Time + 1
		case "fresh":
			snap.Scales[0].Fresh = false
		case "structure":
			snap.Scales[0].Current.Structure.Refs[2].End += 300
		case "nan":
			snap.Scales[2].Current.Frame.Technical.EMA8.Value = math.NaN()
		case "width":
			snap.Scales[1].WidthSeconds = 300
		case "sealed":
			snap.Sealed = true
		}
		if err := h.SetSnapshot(snap, r.At); err == nil {
			t.Fatal(field)
		}
	}
}

// TestSameSecondSignalsFreezeAndLast は同秒別行・同公表複数出生・再freeze禁止を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestSameSecondSignalsFreezeAndLast(t *testing.T) {
	s, snap, r := fixture(1, false)
	d, h := runFixture(t, s, snap, r)
	r2 := r
	r2.SignalID = "別出生"
	r2.Last = 1099
	d2, err := h.Evaluate(r2)
	if err != nil || d2.Common != False || d.Trend != True {
		t.Fatal(d2, err)
	}
	if _, err = h.Evaluate(r); err == nil {
		t.Fatal("同出生再freeze")
	}
	if err = h.SetSnapshot(snap, r.At); err == nil {
		t.Fatal("要求後同原行配送")
	}
	next := r.At
	next.Index += 7
	next.Line += 9
	snap.RecordOrdinal = uint64(next.Index) + 1
	if err = h.Step(snap, next); err != nil {
		t.Fatal(err)
	}
	r3 := r
	r3.At = next
	r3.SignalID = "同秒後行出生"
	if _, err = h.Evaluate(r3); err != nil {
		t.Fatal(err)
	}
	r4 := r3
	r4.At.Time++
	r4.At.Index++
	r4.At.Line++
	r4.SignalID = "当行snapshot不足"
	if _, err = h.Evaluate(r4); err == nil {
		t.Fatal("過去snapshotを当行へ流用")
	}
}

// TestSameIDMutationAndRollback は同公表改変を拒否し失敗後の状態を維持します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestSameIDMutationAndRollback(t *testing.T) {
	s, snap, r := fixture(1, false)
	h, _ := NewHistory(s)
	if err := h.SetSnapshot(snap, r.At); err != nil {
		t.Fatal(err)
	}
	before := *h.current
	bad := snap
	bad.Scales[1].Current.DMI.PlusDI.Value++
	bad.RecordOrdinal++
	at := r.At
	at.Index++
	at.Line++
	if err := h.SetSnapshot(bad, at); err == nil {
		t.Fatal("同ID改変")
	}
	if *h.current != before {
		t.Fatal("失敗が履歴を変更")
	}
	bad = snap
	bad.Scales[0].Current.Frame.ID = "付替ID"
	bad.RecordOrdinal++
	if err := h.SetSnapshot(bad, at); err == nil {
		t.Fatal("同終端ID差")
	}
	if err := h.SetSnapshot(snap, r.At); err != nil {
		t.Fatal(err)
	}
}

// TestCopyAndFutureNoninterference は入力・返却票・将来snapshotから固定票を分離します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestCopyAndFutureNoninterference(t *testing.T) {
	s, snap, r := fixture(1, false)
	d, h := runFixture(t, s, snap, r)
	before, _ := json.Marshal(h.frozen[requestKey(r)])
	snap.Scales[0].Current.Structure.High = 99999
	d.Current.Snapshot.Scales[0].Current.Structure.Low = 123
	*d.Values.G30 = 999
	*d.TrendConditions[0].Value = 999
	d.TrendDenials = append(d.TrendDenials, "改変")
	unchanged, _ := json.Marshal(h.frozen[requestKey(r)])
	if string(before) != string(unchanged) {
		t.Fatal("参照共有")
	}
	_, next, _ := fixture(1, false)
	at := r.At
	at.Time++
	at.Index++
	at.Line++
	next.AsOf = at.Time
	next.ReplayObservedAt = at.Time
	next.RecordOrdinal = uint64(at.Index) + 1
	if err := h.Step(next, at); err != nil {
		t.Fatal(err)
	}
	after, _ := json.Marshal(h.frozen[requestKey(r)])
	if string(before) != string(after) {
		t.Fatal("未来追加で既存固定票差")
	}
}

// TestRealArtificialBank は実bankの人工生成snapshotを純APIへ無変換で渡します。
//
// 引数: t(*testing.T)。返り値: ありません。Raw/CSV本文は読みません。
func TestRealArtificialBank(t *testing.T) {
	start := 1800000000.0
	n := 180
	scene := old.Session{ID: "公開bank人工", Contract: "人工限月", Start: start, End: start + float64(n+1)*300, EOF: start + float64(n)*300 + 60}
	children := make([]old.ChildBar, n)
	for i := range children {
		p := 1000 + float64(i)*10
		children[i] = old.ChildBar{Start: start + float64(i)*300, End: start + float64(i+1)*300, OHLC: old.OHLC{Open: p - 1, High: p + 2, Low: p - 2, Close: p}, Closed: true, Input: old.FileRef{Path: "人工.csv", SHA256: strings.Repeat("a", 64), Bytes: 12345}, Row: uint64(i + 2)}
	}
	b, err := bank.BeginSession(scene, children, nil)
	if err != nil {
		t.Fatal(err)
	}
	h, _ := NewHistory(Scope{scene.ID, scene.Contract, scene.Start, scene.End})
	for i := range n {
		at := start + float64(i+1)*300 + 60
		if _, err = b.AdvanceObserved(at, uint64(i+1)); err != nil {
			t.Fatal(err)
		}
		snap, e := b.SnapshotAt(at)
		if e != nil {
			t.Fatal(e)
		}
		stamp := Stamp{at, i, int64(i + 1)}
		if err = h.SetSnapshot(snap, stamp); err != nil {
			t.Fatal(i, err)
		}
		if i%17 == 0 || i == n-1 {
			d, e := h.Evaluate(Request{Product: "NK225mini", Method: "NK225_D164_15", SignalID: fmt.Sprintf("人工%d", i), Side: 1, At: stamp, Last: children[i].OHLC.Close})
			if e != nil {
				t.Fatal(i, e)
			}
			if i == n-1 && d.Trend != True {
				t.Fatal("十分助走後の線形順行", d)
			}
		}
	}
}

// TestExport は停止helperが要求したときだけ小さい手製票を保存します。
//
// 引数: t(*testing.T)。返り値: ありません。自然市場の証明ではありません。
func TestExport(t *testing.T) {
	path := os.Getenv("ENTRYGATE115_EXPORT")
	if path == "" {
		t.Skip("明示出力時だけ")
	}
	decisions := []Decision{}
	for _, side := range []int{1, -1} {
		for _, reversal := range []bool{false, true} {
			s, snap, r := fixture(side, reversal)
			d, _ := runFixture(t, s, snap, r)
			decisions = append(decisions, d)
		}
	}
	value := struct {
		Version    int        `json:"version"`
		Artificial bool       `json:"artificial"`
		Natural    bool       `json:"natural_source"`
		Definition Definition `json:"definition"`
		Decisions  []Decision `json:"decisions"`
	}{115, true, false, DeclaredDefinition(), decisions}
	body, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	if err = os.MkdirAll(filepath.Dir(path), 0755); err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(path, append(body, '\n'), 0644); err != nil {
		t.Fatal(err)
	}
}
