package entrygate115

// And は偽を優先する三値論理積を返します。
//
// 引数: values(...Truth)。返り値: Truthは偽/未知/真です。
func And(values ...Truth) Truth {
	u := false
	for _, v := range values {
		if v == False {
			return False
		}
		if v != True {
			u = true
		}
	}
	if u {
		return Unknown
	}
	return True
}

// Or は真を優先する三値論理和を返します。
//
// 引数: values(...Truth)。返り値: Truthは真/未知/偽です。
func Or(values ...Truth) Truth {
	u := false
	for _, v := range values {
		if v == True {
			return True
		}
		if v != False {
			u = true
		}
	}
	if u {
		return Unknown
	}
	return False
}

// pointer は値を新しい保存先へ写します。
//
// 引数: value(float64)。返り値: *float64は私有参照です。
func pointer(value float64) *float64 { return &value }

// numbers は派生数値の全ポインタを既定順で返します。
//
// 引数: v(Values)。返り値: []*float64は全12項目です。
func numbers(v Values) []*float64 {
	return []*float64{v.G30, v.D15, v.ADX15, v.Boundary, v.FiveClose, v.CloseBreak, v.LastBreak, v.TR5, v.PreviousATR5, v.SpikeMargin, v.PreviousD15, v.ADX15Delta}
}

// copyNumber はnilを保ち値参照だけを私有化します。
//
// 引数: p(*float64又はnil)。返り値: *float64はnil又は別参照です。
func copyNumber(p *float64) *float64 {
	if p == nil {
		return nil
	}
	return pointer(*p)
}

// copyConditions はnil/空を保持して全条件ポインタを複製します。
//
// 引数: input([]Condition)。返り値: []Conditionは私有copyです。
func copyConditions(input []Condition) []Condition {
	if input == nil {
		return nil
	}
	out := make([]Condition, len(input))
	copy(out, input)
	for i := range out {
		out[i].Value = copyNumber(out[i].Value)
	}
	return out
}

// copyStrings はnil/空を区別して理由配列を私有化します。
//
// 引数: input([]string)。返り値: []stringは独立copyです。
func copyStrings(input []string) []string {
	if input == nil {
		return nil
	}
	out := make([]string, len(input))
	copy(out, input)
	return out
}

// copyDecision は全ポインタ/スライスを分離しbank値配列も値copyします。
//
// 引数: d(Decision)。返り値: Decisionは参照共有のない同体値です。
func copyDecision(d Decision) Decision {
	if d.Current != nil {
		p := *d.Current
		d.Current = &p
	}
	v := d.Values
	d.Values = Values{copyNumber(v.G30), copyNumber(v.D15), copyNumber(v.ADX15), copyNumber(v.Boundary), copyNumber(v.FiveClose), copyNumber(v.CloseBreak), copyNumber(v.LastBreak), copyNumber(v.TR5), copyNumber(v.PreviousATR5), copyNumber(v.SpikeMargin), copyNumber(v.PreviousD15), copyNumber(v.ADX15Delta)}
	d.CommonConditions = copyConditions(d.CommonConditions)
	d.TrendConditions = copyConditions(d.TrendConditions)
	d.ReversalConditions = copyConditions(d.ReversalConditions)
	d.MissingInputs = copyStrings(d.MissingInputs)
	d.CommonDenials = copyStrings(d.CommonDenials)
	d.TrendDenials = copyStrings(d.TrendDenials)
	d.ReversalDenials = copyStrings(d.ReversalDenials)
	return d
}

// condition は未知と既知の零を区別して宣言済み不等号を評価します。
//
// 引数: id/op(string)、value(*float64)。返り値: Conditionは原値と三値です。
func condition(id string, value *float64, op string) Condition {
	c := Condition{ID: id, Value: copyNumber(value), Op: op, Truth: Unknown}
	if value == nil {
		return c
	}
	yes := false
	switch op {
	case ">0":
		yes = *value > 0
	case "<0":
		yes = *value < 0
	case ">=0":
		yes = *value >= 0
	case ">=20":
		yes = *value >= 20
	default:
		panic("115未宣言演算")
	}
	c.Truth = False
	if yes {
		c.Truth = True
	}
	return c
}

// conjunction は論理積と既知偽の条件IDを返します。
//
// 引数: input([]Condition)。返り値: Truth/[]stringは票と既知否定です。
func conjunction(input []Condition) (Truth, []string) {
	values := make([]Truth, len(input))
	denials := []string{}
	for i, c := range input {
		values[i] = c.Truth
		if c.Truth == False {
			denials = append(denials, c.ID)
		}
	}
	return And(values...), denials
}

// evaluate は当原行の三尺度値から共通・順行・反転票を作ります。
//
// 引数: scope(Scope)、r(Request)、publication(Publication)。返り値: Decisionは未知/否定を分けた固定票です。
func evaluate(scope Scope, r Request, publication Publication) Decision {
	d := Decision{Version: 115, Scope: scope, Request: r, Current: &publication, MissingInputs: []string{}, Frozen: true}
	s := float64(r.Side)
	for _, scale := range publication.Snapshot.Scales {
		width := scale.WidthSeconds
		ok := scale.HasCurrent && scale.Fresh && !scale.SeedOnly && scale.Current.Frame.PriceKnown
		f := scale.Current.Frame
		t := f.Technical
		prefix := ""
		switch width {
		case 300:
			prefix = "5m"
		case 900:
			prefix = "15m"
		case 1800:
			prefix = "30m"
		}
		if !ok {
			d.MissingInputs = append(d.MissingInputs, prefix+".current_fresh_price")
		}
		switch width {
		case 300:
			st := scale.Current.Structure
			if ok && st.Known {
				boundary := st.High
				if r.Side < 0 {
					boundary = st.Low
				}
				d.Values.Boundary = pointer(boundary)
				d.Values.FiveClose = pointer(f.OHLC.Close)
				d.Values.CloseBreak = pointer(s * (f.OHLC.Close - boundary))
				d.Values.LastBreak = pointer(s * (r.Last - boundary))
			} else {
				d.MissingInputs = append(d.MissingInputs, "5m.previous3_structure")
			}
			if ok && t.TR.Known {
				d.Values.TR5 = pointer(t.TR.Value)
			} else {
				d.MissingInputs = append(d.MissingInputs, "5m.tr")
			}
			if ok && t.PreviousATR.Known {
				d.Values.PreviousATR5 = pointer(t.PreviousATR.Value)
			} else {
				d.MissingInputs = append(d.MissingInputs, "5m.previous_atr14")
			}
			if d.Values.TR5 != nil && d.Values.PreviousATR5 != nil {
				d.Values.SpikeMargin = pointer(2**d.Values.PreviousATR5 - *d.Values.TR5)
			}
		case 900:
			m := scale.Current.DMI
			if ok && m.PlusDI.Known && m.MinusDI.Known {
				d.Values.D15 = pointer(s * (m.PlusDI.Value - m.MinusDI.Value))
			} else {
				d.MissingInputs = append(d.MissingInputs, "15m.di")
			}
			if ok && m.ADX.Known {
				d.Values.ADX15 = pointer(m.ADX.Value)
			} else {
				d.MissingInputs = append(d.MissingInputs, "15m.adx")
			}
			if ok && m.PreviousPlusDI.Known && m.PreviousMinusDI.Known {
				d.Values.PreviousD15 = pointer(s * (m.PreviousPlusDI.Value - m.PreviousMinusDI.Value))
			}
			if ok && m.ADX.Known && m.PreviousADX.Known {
				d.Values.ADX15Delta = pointer(m.ADX.Value - m.PreviousADX.Value)
			}
		case 1800:
			if ok && t.EMA8.Known && t.EMA21.Known {
				d.Values.G30 = pointer(s * (t.EMA8.Value - t.EMA21.Value))
			} else {
				d.MissingInputs = append(d.MissingInputs, "30m.ema8_ema21")
			}
		}
	}
	d.CommonConditions = []Condition{condition("C.CloseBreak", d.Values.CloseBreak, ">0"), condition("C.PreviousATR", d.Values.PreviousATR5, ">0"), condition("C.SpikeMargin", d.Values.SpikeMargin, ">=0"), condition("C.LastHold", d.Values.LastBreak, ">0")}
	d.Common, d.CommonDenials = conjunction(d.CommonConditions)
	d.TrendConditions = []Condition{condition("T.G30", d.Values.G30, ">0"), condition("T.D15", d.Values.D15, ">0"), condition("T.ADX15", d.Values.ADX15, ">=20")}
	d.ReversalConditions = []Condition{condition("R.G30", d.Values.G30, "<0"), condition("R.D15", d.Values.D15, ">0")}
	t, td := conjunction(d.TrendConditions)
	rr, rd := conjunction(d.ReversalConditions)
	d.Trend = And(d.Common, t)
	d.Reversal = And(d.Common, rr)
	d.Combined = Or(d.Trend, d.Reversal)
	d.TrendDenials = append(copyStrings(d.CommonDenials), td...)
	d.ReversalDenials = append(copyStrings(d.CommonDenials), rd...)
	return d
}
