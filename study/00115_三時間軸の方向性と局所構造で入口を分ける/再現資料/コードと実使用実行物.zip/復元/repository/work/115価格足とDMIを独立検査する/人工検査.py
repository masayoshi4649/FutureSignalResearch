"""115の独立価格足/DMIを市場入力なしで検査する。"""

from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import 検査する as A


def fixture(count: int = 240, side: int = 1) -> tuple[dict, list[dict]]:
    """機能: Go公開人工と同じ定義の手製子足を別言語で生成する。

    引数: count/side(int)は本数と売買鏡像。
    返り値: tuple[dict,list[dict]]は場と子足。実ファイルは読まない。
    """
    start = 1800000000
    scene = {'id': '人工', 'contract': '人工限月', 'start': start, 'end': start + (count + 1) * 300, 'eof': start + count * 300 + 60}
    bars = []
    for i in range(count):
        close = Decimal(10000 + i)
        bar = {'open': close - Decimal('.5'), 'high': close + 2, 'low': close - 2, 'close': close}
        if side == -1:
            bar = {'open': 30000 - bar['open'], 'high': 30000 - bar['low'], 'low': 30000 - bar['high'], 'close': 30000 - bar['close']}
        bars.append({'start': start + i * 300, 'end': start + (i + 1) * 300, 'ohlc': bar, 'closed': True,
                     'volume_known': True, 'volume': Decimal(100), 'row': i + 2,
                     'input': {'path': '人工.csv', 'sha256': 'a' * 64, 'bytes': 100}})
    return scene, bars


class IndependentTests(unittest.TestCase):
    """独立初期化・価格合成・時間・読取gateの人工検査。"""

    def test_go_public_artificial(self) -> None:
        """機能: 固定Go買売人工の各幅末尾OHLC/DMIへ独立数値を照合する。

        引数: self(IndependentTests)は検査器。
        返り値: なし。実市場は読まない。
        """
        path = A.ROOT / 'work/115三時間軸と方向性の公開/検査_停止版/人工/買売人工.json'
        self.assertEqual(A.sha(path), 'f5d44c3c140aae8680f4b7b8f5e0d3b824a48b2adfd2e2d75cbd591031f77807')
        source = json.loads(path.read_text(encoding='utf-8'), parse_float=Decimal)
        checked = 0
        for case in source['cases']:
            scene, children = fixture(side=case['side'])
            frames, state = A.P.calculate(scene, children)
            latest = {frame['width_seconds']: frame for frame in frames}
            for scale in case['snapshot']['scales']:
                A.P.compare_frame(scale['current'], latest[scale['width_seconds']], scene)
                checked += 1
            A.check_seed(case['seed_info'], state)
        self.assertEqual(checked, 6)

    def test_initial_counts_and_nonlinear(self) -> None:
        """機能: DI15/ADX28と交互2/−1の非線形基準を確認する。

        引数: self(IndependentTests)は検査器。
        返り値: なし。独立Decimal解析値を使う。
        """
        state, price = A.P.Directional(), Decimal(100)
        for i in range(40):
            price += 0 if i == 0 else 2 if i % 2 else -1
            value = state.advance({'open': price, 'high': price + 2, 'low': price - 2, 'close': price})
            self.assertEqual(value['plus_di']['known'], i >= 14)
            self.assertEqual(value['adx']['known'], i >= 27)
            if i == 14:
                self.assertEqual(value['plus_di']['value'], Decimal(25))
                self.assertEqual(value['minus_di']['value'], Decimal('12.5'))
            if i == 27:
                A.P.equal_number(value['adx']['value'], Decimal('35.40291983465636992682246147288077975037086381597088052673418863999482'), 'ADX28')

    def test_outside_tie_inside(self) -> None:
        """機能: outsideの3/1優勢、同幅、insideの方向0を確認する。

        引数: self(IndependentTests)は検査器。
        返り値: なし。
        """
        state = A.P.Directional()
        for i in range(15):
            result = state.advance({'open': Decimal(100), 'close': Decimal(100), 'high': Decimal(102 + 3 * i), 'low': Decimal(98 - i)})
        A.P.equal_number(result['plus_di']['value'], Decimal(300) / 34, 'outside優勢')
        self.assertEqual(result['minus_di']['value'], 0)
        for shrinking in (False, True):
            state = A.P.Directional()
            for i in range(30):
                width = Decimal(100 - i if shrinking else 10 + i)
                result = state.advance({'open': Decimal(1000), 'close': Decimal(1000), 'high': 1000 + width, 'low': 1000 - width})
                self.assertFalse(result['plus_di']['known'])
                self.assertFalse(result['adx']['known'])

    def test_zero_range_and_dx_rewarm(self) -> None:
        """機能: TR0/DM和0を未知とし14連続DXで再助走することを確認する。

        引数: self(IndependentTests)は検査器。
        返り値: なし。
        """
        for width in (0, 2):
            state = A.P.Directional()
            for _ in range(30):
                out = state.advance({'open': Decimal(100), 'close': Decimal(100), 'high': Decimal(100 + width), 'low': Decimal(100 - width)})
                self.assertFalse(out['adx']['known'])
                self.assertEqual(out['dx_count'], 0)
            for i in range(1, 15):
                p = Decimal(100 + i)
                out = state.advance({'open': p, 'close': p, 'high': p + 2, 'low': p - 2})
                self.assertEqual(out['adx']['known'], i == 14)

    def test_missing_and_volume(self) -> None:
        """機能: 一子欠足の全影響尺度resetと数量未知の独立性を確認する。

        引数: self(IndependentTests)は検査器。
        返り値: なし。
        """
        scene, children = fixture(180)
        full, _ = A.P.calculate(scene, children)
        missing = children[:70] + children[71:]
        frames, _ = A.P.calculate(scene, missing)
        unknown = [frame for frame in frames if not frame['price_known']]
        self.assertEqual(sorted(frame['width_seconds'] for frame in unknown), [300, 900, 1800])
        self.assertTrue(all(frame['dmi'] == A.P.empty_dmi() for frame in unknown))
        changed = deepcopy(children)
        changed[70]['volume_known'] = False
        volume, _ = A.P.calculate(scene, changed)
        self.assertEqual([f['dmi'] for f in full], [f['dmi'] for f in volume])

    def test_seed_carry_and_roll(self) -> None:
        """機能: 前史数値だけの同限月継承と限月resetを確認する。

        引数: self(IndependentTests)は検査器。
        返り値: なし。
        """
        scene, children = fixture()
        _, seed = A.P.calculate(scene, children)
        next_scene, bars = fixture(12)
        delta = scene['end'] + 300 - next_scene['start']
        for key in ('start', 'end', 'eof'):
            next_scene[key] += delta
        for bar in bars:
            bar['start'] += delta
            bar['end'] += delta
        frames, _ = A.P.calculate(next_scene, bars, seed)
        self.assertTrue(frames[0]['dmi']['adx']['known'])
        next_scene['contract'] = '別限月'
        frames, _ = A.P.calculate(next_scene, bars, seed)
        self.assertFalse(frames[0]['dmi']['plus_di']['known'])

    def test_parent_ohlc_and_cutoff(self) -> None:
        """機能: 完全3/6子のOHLCとEnd+60/予定末尾除外を確認する。

        引数: self(IndependentTests)は検査器。
        返り値: なし。
        """
        scene, bars = fixture(12)
        scene['eof'] = scene['start'] + 3600
        frames = A.P.plans(scene, bars)
        self.assertEqual(sum(f['width_seconds'] == 300 for f in frames), 11)
        self.assertEqual(sum(f['width_seconds'] == 900 for f in frames), 3)
        self.assertEqual(sum(f['width_seconds'] == 1800 for f in frames), 1)
        parent = next(f for f in frames if f['width_seconds'] == 1800)
        self.assertEqual(parent['ohlc'], {'open': Decimal('9999.5'), 'high': Decimal(10007), 'low': Decimal(9998), 'close': Decimal(10005)})
        self.assertEqual(parent['nominal_available'], parent['end'] + 60)

    def test_csv_memory_and_rejections(self) -> None:
        """機能: 手製CSVの物理行/量未知と重複/列/空白拒否を確認する。

        引数: self(IndependentTests)は検査器。
        返り値: なし。CSVはメモリbytesのみ。
        """
        scene = A.scene_for({'id': '2026-09-21_Day', 'contract': '人工'})
        head = 'time,open,high,low,close,volume,volume_complete,closed\r\n'
        row = '2026-09-21T08:45:00+09:00,100,102,99,101,,false,true\r\n'
        bars = A.parse_csv((head + row).encode(), {'path': '人工', 'sha256': 'a' * 64, 'bytes': 0}, scene)
        self.assertEqual(bars[0]['row'], 2)
        self.assertFalse(bars[0]['volume_known'])
        extended = head.rstrip('\r\n') + ',追加列\r\n' + row.rstrip('\r\n') + ',"複数\r\n行"\r\n'
        extended += row.replace('08:45:00', '08:50:00').rstrip('\r\n') + ',値\r\n'
        self.assertEqual([bar['row'] for bar in A.parse_csv(extended.encode(), {}, scene)], [2, 4])
        for body in (head + row + row, head.replace('time', 'open') + row, head + row.replace(',100,', ', 100,')):
            with self.assertRaises(ValueError):
                A.parse_csv(body.encode(), {}, scene)

    def test_dmi_tamper_known_and_counter(self) -> None:
        """機能: 値・既知性・Bars/差分/連続DXの改変を拒否する。

        引数: self(IndependentTests)は検査器。
        返り値: なし。
        """
        scene, bars = fixture()
        frames, _ = A.P.calculate(scene, bars)
        expected = frames[-1]['dmi']
        for kind in ('known', 'value', 'count'):
            actual = deepcopy(expected)
            if kind == 'known':
                actual['adx']['known'] = False
            elif kind == 'value':
                actual['plus_di']['value'] += 1
            else:
                actual['dx_count'] += 1
            with self.assertRaises(ValueError):
                A.P.compare_dmi(actual, expected)

    def test_reference_and_holdout_rejection(self) -> None:
        """機能: 相対Ref/別市場/11月09や入力根外を本文前に拒否する。

        引数: self(IndependentTests)は検査器。
        返り値: なし。
        """
        with self.assertRaises(ValueError):
            A.resolve({'path': '相対.csv', 'sha256': '0' * 64})
        with self.assertRaises(ValueError):
            A.scene_for({'id': '2026-11-09_Day', 'contract': '人工'})
        with self.assertRaises(ValueError):
            A.csv_ref({'source_root': str(A.ROOT)}, {'id': '2026-09-21_Day', 'files': {'NK225_candle_300': {'path': '../book.jsonl.gz', 'sha256': '0' * 64, 'size': 1}}})

    def test_unfixed_gate_never_reads_market(self) -> None:
        """機能: Root未固定要求を拒否しCSV/Nativeを開く前に止める。

        引数: self(IndependentTests)は手製metadata検査器。
        返り値: なし。一時JSONだけ作成する。
        """
        with tempfile.TemporaryDirectory(prefix='独立gate人工_', dir=A.OWN) as directory:
            root = Path(directory)
            self.assertTrue(root.resolve().is_relative_to(A.OWN))
            path = root / '未固定.json'
            path.write_text(json.dumps({'version': 1, 'trial': 115, 'fixed': False, 'market_native_read_authorized': True, 'csv_read_authorized': True, 'raw_read_authorized': False, 'holdout_read_authorized': False}), encoding='utf-8')
            with self.assertRaises(ValueError):
                A.prepare(A.file_ref(path), root / '出力')
            self.assertFalse((root / '出力').exists())

    def test_metadata_gate_without_market_files(self) -> None:
        """機能: 正常な手製固定要求を市場ファイル未作成のまま認証する。

        引数: self(IndependentTests)は人工metadata検査器。
        返り値: なし。CSV/Nativeの本文もhashも読まない成功経路を確認する。
        """
        with tempfile.TemporaryDirectory(prefix='独立metadata人工_', dir=A.OWN) as directory:
            root = Path(directory)

            def save(name: str, body: dict) -> dict:
                """機能: 人工JSONだけを新規保存しRefを作る。

                引数: name(str)、body(dict)は人工名とmetadata。
                返り値: dictは一時JSONのRef。
                """
                path = root / (name + '.json')
                path.write_text(json.dumps(body, ensure_ascii=False), encoding='utf-8')
                return A.file_ref(path)

            sessions = []
            for i in range(70):
                date = A.datetime(2026, 9, 21) + A.timedelta(days=i // 2)
                name = date.strftime('%Y-%m-%d') + ('_Day' if i % 2 == 0 else '_Night')
                sessions.append({'id': name, 'contract': '人工', 'files': {'NK225_candle_300':
                                 {'path': f'JP_OSE_Data/future/NK225/{name}/candle_5min.csv', 'sha256': 'a' * 64, 'size': 1}}})
            manifest = {'source_root': str(root), 'sessions': sessions}
            manifest_ref = save('台帳', manifest)
            bank_ref = save('Go停止', {'成功': True, '試行': 115})
            own_stop = save('独立停止', {'成功': True, '試行': 115, '市場前': True, 'Go公開器停止': bank_ref,
                                      '所有ファイルSHA256': {str(A.OWN / name): A.sha(A.OWN / name) for name in A.OWNED}})
            condition_ref = save('条件', {'trial': 115, 'fixed': True, 'manifest': manifest_ref,
                                         'dependency_stops': {'entry_chart': bank_ref}, 'entry_input_model': A.MODEL})
            scenes, complete = [], []
            for i, item in enumerate(sessions[:2]):
                native = {'path': str(root / (item['id'] + '.Native.json.gz')), 'sha256': 'b' * 64}
                scenes.append({'session': item['id'], 'native': native, 'csv': A.csv_ref(manifest, item),
                               'prefix': [{'session': old['id'], 'csv': A.csv_ref(manifest, old)} for old in sessions[:i]]})
                complete.append({'session': item['id'], 'native': native, 'books': 12, 'complete': True, 'open_quantity': 0, 'pending_quantity': 0})
            market_ref = save('金融完了', {'trial': 115, 'success': True, 'stage': 'first2', 'sessions': 2, 'books': 24,
                                          'condition_sha256': condition_ref['sha256'], 'unchanged': True, 'before': {}, 'after': {},
                                          'reference114_comparisons': 8, 'all_reference114_equal': True, 'all_source111_equal': True,
                                          'results': complete})
            request = {'version': 1, 'trial': 115, 'fixed': True, 'market_native_read_authorized': True, 'csv_read_authorized': True,
                       'raw_read_authorized': False, 'holdout_read_authorized': False, 'stage': 'first2',
                       'condition': condition_ref, 'market': market_ref, 'manifest': manifest_ref, 'bank_stop': bank_ref,
                       'code_stop': own_stop, 'scenes': scenes}
            request_ref = save('Root要求', request)
            with patch.multiple(A, F1_SHA=condition_ref['sha256'], MANIFEST_SHA=manifest_ref['sha256'], BANK_SHA=bank_ref['sha256']):
                result = A.run(request_ref, root / '新規出力', metadata_only=True)
                self.assertTrue(result['成功'])
                self.assertFalse(result['CSV/Native本文読取'])
                changed = deepcopy(request)
                changed['scenes'][1]['prefix'] = []
                with self.assertRaises(ValueError):
                    A.prepare(save('欠落前史要求', changed), root / '新規出力')
                with self.assertRaises(ValueError):
                    A.prepare(request_ref, root)
            self.assertFalse((root / '新規出力').exists())


if __name__ == '__main__':
    unittest.main(verbosity=2)
