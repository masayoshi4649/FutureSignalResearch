# 115の価格足とDMIの独立検査

Goの不透明seedやLast DI/ADXを次の計算の初期状態として利用しない。Rootが宣言したmanifestのCSV prefixを別言語で再合成し、Decimal60桁の初期14値直接平均と差分型RMAからDI/DX/ADXを作る。数値比較は絶対1e-8以内、既知性・Bars/Differences/DXCount・公表順/子足/元行は一致を要求する。

前史は過去場の予定EndまでEnd+60秒モデルで公表された数値だけ。当場は保存された最終原行frontierまで。場間は同限月の数値だけcarryし、限月変更/価格欠足でreset。量だけ未知は価格/DMIをresetしない。高安の拡大はstrict優勢式で一方だけ、同幅/insideは両0。TR0/平滑DM和0は当値DI/ADX未知、ADX用連続DXをresetする。

## 固定要求とCLI

`version:1,trial:115,fixed:true,stage:first2|base54|full70`、`market_native_read_authorized:true,csv_read_authorized:true,raw_read_authorized:false,holdout_read_authorized:false`。FileRefはpath/sha256、CSVだけbytesも持つ。

- `condition, market, manifest, bank_stop, code_stop`：F1固定、成功completion、固定70台帳、Go bank停止、この独立検査停止。
- `scenes:[{session,native,csv,prefix:[{session,csv}]}]`：成功stageの全予定場を元順序で指定。csvは各manifestのNK225_candle_300そのもの。prefixは対象より前の全manifest場だけを列挙し、当場/将来/余剰を認めない。
- F1 SHA94bb656a…、manifest902c6b…、bank停止df5718…に限定。11/09・Raw・TOPIX CSV・任意の別ファイルは本文前に拒否する。

```powershell
python -X utf8 検査する.py --fixed <Root固定要求絶対path> --sha256 <SHA256> --output <未作成絶対先> --metadata-only
python -X utf8 検査する.py --fixed <Root固定要求絶対path> --sha256 <SHA256> --output <未作成絶対先>
```

metadata-onlyはCSV/Nativeの本文・実指紋を読まない。通常実行も全Root条件・停止自身・market全成功・scene/prefixの明示集合を先に認証する。CSVはrequest内で同じものを一度解釈して共有し、元の固定bytes・後SHAを保存する。金融額は計算しない。出力は新規のみ、途中例外は不完了を保存する。

## 検査範囲と限界

当場全EntryPublicationsの5/15/30 OHLC・価格/量既知性・子足物理行/Ref・End+60・実配送stamp/連番と、DMI全現前値・3計数を照合する。InputSeed/EndSeedのLast DMIと履歴本数も、独立prefixから再計算した状態へ照合する。

この検査はRawからCSVを再形成するものではない。Goのcanonical ID/私有seedSHAやEMA/RSI/MACD/ATR/pivotの別計算、実受信時刻、Raw上で最初の公表可能原行だったという初回性は対象外。同じ保存値をPythonへ代入した数値一致を、独立再形成とは呼ばない。

人工12主はメモリ子足・CSV bytesと固定Go買売人工f5d44…だけ。初DI15/ADX28・非線形ADX・outside/tie/inside・TR0/DM和0・欠足/量未知・carry/roll・親足合成/末尾未公表・改変拒否・Root未固定拒否・市場ファイルなしのmetadata成功を確認する。市場CSV/NativeはRootの後段固定要求まで読まない。
