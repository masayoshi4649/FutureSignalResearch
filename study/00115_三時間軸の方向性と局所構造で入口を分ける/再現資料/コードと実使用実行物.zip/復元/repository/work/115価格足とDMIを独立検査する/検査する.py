"""Root固定要求の後だけ、明示CSV prefixとNativeの価格足/DMIを独立検査する。"""

import argparse
import csv
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import gzip
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import re
import sys


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
F1_SHA = '94bb656a1607d59039a0c5ec0f06968a4da72463d27c0847606a09fc52fc4693'
BANK_SHA = 'df5718acf04495bc690c5a0d0652ba202cb9f970eb2323389f246d70cdbe7a68'
MANIFEST_SHA = '902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8'
MODEL = 'prior_csv_publications_through_scheduled_end_current_raw_delivery115'
OWNED = ('検査する.py', '価格足とDMIの純再形成.py', '人工検査.py', '検査して停止する.py', 'README.md')
SPEC = importlib.util.spec_from_file_location('115価格足DMIの独立純演算', OWN / '価格足とDMIの純再形成.py')
P = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(P)


def sha(path: Path) -> str:
    """機能: 明示した許可対象の全bytes指紋を返す。

    引数: path(Path)はmetadata/コード又は認証後のCSV/Native。
    返り値: strはSHA256。Rawを渡す経路は持たない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def file_ref(path: Path) -> dict:
    """機能: 絶対位置とSHAを作る。

    引数: path(Path)は明示保存物。
    返り値: dictはFileRef。
    """
    return {'path': str(path.resolve()), 'sha256': sha(path)}


def resolve(reference: dict) -> Path:
    """機能: FileRefの構造だけを確認し、本文は読まず解決する。

    引数: reference(dict)はpath/sha256と任意bytes。
    返り値: Pathは解決絶対位置。不正はValueError。
    """
    P.need(set(reference) in ({'path', 'sha256'}, {'path', 'sha256', 'bytes'}), 'FileRefの項目')
    P.need(isinstance(reference['path'], str) and Path(reference['path']).is_absolute(), '絶対FileRef')
    P.need(re.fullmatch('[0-9a-f]{64}', reference['sha256']) is not None, '小文字SHA256')
    if 'bytes' in reference:
        P.need(type(reference['bytes']) is int and reference['bytes'] >= 0, 'bytes型')
    return Path(reference['path']).resolve()


def bind(reference: dict, before: dict) -> Path:
    """機能: 明示FileRefのSHA/sizeを認証する。

    引数: reference/before(dict)は対象Refと入力指紋台帳。
    返り値: Pathは認証済み位置。市場Refには固定要求認証後だけ呼ぶ。
    """
    path = resolve(reference)
    P.need(sha(path) == reference['sha256'], '入力SHA差: ' + str(path))
    if 'bytes' in reference:
        P.need(path.stat().st_size == reference['bytes'], '入力size差')
    before[str(path)] = reference['sha256']
    return path


def metadata(reference: dict, before: dict) -> dict:
    """機能: 小JSONの固定Refを認証して読む。

    引数: reference/before(dict)はRefと指紋台帳。
    返り値: dictはJSON。市場Nativeにはこの関数を使わない。
    """
    path = bind(reference, before)
    P.need(path.suffix == '.json' and not path.name.endswith('.Native.json'), 'metadata JSONだけ')
    return json.loads(path.read_text(encoding='utf-8-sig'), parse_float=Decimal)


def scene_for(item: dict) -> dict:
    """機能: 固定セッションIDからJST日夜時計を独立に作る。

    引数: item(dict)はmanifestのid/contract。
    返り値: dictは予定End=EOF模型の場時計。
    """
    match = re.fullmatch(r'(2026-\d\d-\d\d)_(Day|Night)', item['id'])
    P.need(match is not None and '2026-09-21_Day' <= item['id'] <= '2026-11-06_Night', '固定70期間だけ。11/09禁止')
    date = datetime.strptime(match[1], '%Y-%m-%d').replace(tzinfo=timezone(timedelta(hours=9)))
    start = date + (timedelta(hours=8, minutes=45) if match[2] == 'Day' else timedelta(hours=17))
    seconds = 25200 if match[2] == 'Day' else 46800
    epoch = int(start.timestamp())
    return {'id': item['id'], 'contract': item['contract'], 'start': epoch, 'end': epoch + seconds, 'eof': epoch + seconds}


def csv_ref(manifest: dict, item: dict) -> dict:
    """機能: manifestのNK225固定5分CSVだけを絶対参照へ解決する。

    引数: manifest/item(dict)は固定台帳と場。
    返り値: dictはpath/sha256/bytes。Root外や別市場は拒否。
    """
    entry = item['files']['NK225_candle_300']
    expected = f"JP_OSE_Data/future/NK225/{item['id']}/candle_5min.csv"
    P.need(entry['path'].replace('\\', '/') == expected, '指定NK225の5分CSVだけ')
    base = Path(manifest['source_root']).resolve()
    path = (base / entry['path']).resolve()
    P.need(base.is_absolute() and path.is_relative_to(base), 'CSV入力根内だけ')
    return {'path': str(path), 'sha256': entry['sha256'], 'bytes': entry['size']}


def prepare(request_ref: dict, output: Path) -> dict:
    """機能: Root許可・F1/成功・停止・manifest・全scene/prefixを市場本文前に認証する。

    引数: request_ref(dict)、output(Path)はRoot固定Refと未作成先。
    返り値: dictは読み取り許可済み計画。CSV/Nativeのhashもここでは読まない。
    """
    P.need(sys.flags.optimize == 0 and output.is_absolute() and not output.exists(), '通常Pythonと未作成絶対出力が必要')
    before = {}
    request = metadata(request_ref, before)
    P.need(request['version'] == 1 and request['trial'] == 115 and request['fixed'] is True
           and request['market_native_read_authorized'] is True and request['csv_read_authorized'] is True
           and request['raw_read_authorized'] is False and request['holdout_read_authorized'] is False, 'Rootの新規固定CSV/Native解禁だけ')
    condition = metadata(request['condition'], before)
    market = metadata(request['market'], before)
    manifest = metadata(request['manifest'], before)
    bank = metadata(request['bank_stop'], before)
    stopped = metadata(request['code_stop'], before)
    P.need(request['condition']['sha256'] == F1_SHA and request['manifest']['sha256'] == MANIFEST_SHA
           and request['bank_stop']['sha256'] == BANK_SHA, '固定F1/70台帳/Go bank115だけ')
    P.need(condition['trial'] == 115 and condition['fixed'] is True and condition['manifest'] == request['manifest']
           and condition['dependency_stops']['entry_chart'] == request['bank_stop'] and condition['entry_input_model'] == MODEL, '実金融条件とbank/入力模型の結合')
    P.need(bank['成功'] is True and bank['試行'] == 115 and stopped['成功'] is True and stopped['市場前'] is True
           and stopped['試行'] == 115 and stopped['Go公開器停止'] == request['bank_stop'], '独立停止とGo停止の結合')
    actual = {str(OWN / name): sha(OWN / name) for name in OWNED}
    P.need(stopped['所有ファイルSHA256'] == actual, '停止したこの独立実装だけ')
    before.update(actual)
    count = {'first2': 2, 'base54': 54, 'full70': 70}.get(request['stage'])
    P.need(count is not None and len(manifest['sessions']) == 70, '段階と固定70場')
    P.need(market['trial'] == 115 and market['success'] is True and market['stage'] == request['stage']
           and market['sessions'] == count and market['books'] == 12 * count
           and market['condition_sha256'] == request['condition']['sha256']
           and market['unchanged'] is True and market['before'] == market['after']
           and market['reference114_comparisons'] == 4 * count and market['all_reference114_equal'] is True
           and market['all_source111_equal'] is True, '金融全成功/対照/不変')
    expected_ids = [item['id'] for item in manifest['sessions'][:count]]
    P.need([row['session'] for row in market['results']] == expected_ids
           and [row['session'] for row in request['scenes']] == expected_ids, '全許可sceneの順序/欠落/重複なし')
    for index, (task, completed) in enumerate(zip(request['scenes'], market['results'])):
        P.need(task['native'] == completed['native'] and completed['books'] == 12 and completed['complete'] is True
               and completed['open_quantity'] == completed['pending_quantity'] == 0, '許可Nativeと完結の同体')
        native = resolve(task['native'])
        P.need(native.name == task['session'] + '.Native.json.gz', '指定Native名だけ。Rawを禁止')
        P.need(task['csv'] == csv_ref(manifest, manifest['sessions'][index]), '当場CSVの明示許可')
        expected_prefix = [{'session': item['id'], 'csv': csv_ref(manifest, item)} for item in manifest['sessions'][:index]]
        P.need(task['prefix'] == expected_prefix, '対象より前のmanifest全prefixだけ。将来/余剰入力を禁止')
        scene_for(manifest['sessions'][index])
    return {'request': request, 'manifest': manifest, 'before': before, 'market': market}


def parse_csv(body: bytes, reference: dict, scene: dict) -> list[dict]:
    """機能: 認証済みCSV bytesだけを物理行付き5分子足へ解釈する。

    引数: body(bytes)、reference/scene(dict)は固定入力bytes・出典・場。
    返り値: list[dict]はstrict昇順/格子/有限OHLCの子足。足を補完しない。
    """
    parser = csv.reader(io.StringIO(body.decode('utf-8-sig'), newline=''))
    header = next(parser)
    required = {'time', 'open', 'high', 'low', 'close', 'volume', 'volume_complete', 'closed'}
    P.need(len(header) == len(set(header)) and all(header) and required <= set(header), 'CSVヘッダ')
    result, previous = [], scene['start'] - 300
    while True:
        physical = parser.line_num + 1
        row = next(parser, None)
        if row is None:
            break
        if not row:
            continue
        P.need(len(row) == len(header), 'CSV列数')
        cells = dict(zip(header, row))
        P.need(all(cells[key].strip() == cells[key] and '\n' not in cells[key] and '\r' not in cells[key] for key in required), 'セルの曖昧な空白/複数行を拒否')
        stamp = datetime.fromisoformat(cells['time'].replace('Z', '+00:00'))
        P.need(stamp.tzinfo is not None and stamp.microsecond == 0 and re.fullmatch(r'.*:[0-9]{2}(?:\.0+)?(?:Z|[+-][0-9]{2}:[0-9]{2})', cells['time']) is not None, '整数RFC3339足時計')
        start = int(stamp.timestamp())
        P.need(scene['start'] <= start < start + 300 <= scene['end'] and start > previous and (start - scene['start']) % 300 == 0, 'CSV時刻/格子/重複')
        bar = {key: P.number(Decimal(cells[key])) for key in ('open', 'high', 'low', 'close')}
        for key in ('volume_complete', 'closed'):
            P.need(cells[key] in ('true', 'false'), 'CSV真偽値')
        known, closed = cells['volume_complete'] == 'true', cells['closed'] == 'true'
        P.need(cells['volume'] != '' or not known, '既知数量の空欄')
        volume = P.number(Decimal(cells['volume'])) if cells['volume'] else P.ZERO
        P.need(volume >= 0 and P.price_known({'closed': True, 'ohlc': bar}), '正整合OHLC/非負量')
        result.append({'start': start, 'end': start + 300, 'ohlc': bar, 'closed': closed, 'volume_known': known,
                       'volume': volume, 'row': physical, 'input': reference})
        previous = start
    P.need(bool(result), '子足0を拒否')
    return result


def check_seed(info: dict | None, calculated: dict | None) -> int:
    """機能: Go私有seedを利用せず、独立prefixから得た現前DMIと履歴本数を照合する。

    引数: info/calculated(dict|None)は保存seed情報と独立数値状態。
    返り値: intは照合数。Go私有状態SHAの再符号化一致は主張しない。
    """
    if calculated is None:
        P.need(info is None, '初場に前史seedがある')
        return 0
    P.need(info is not None and info['version'] == 115 and info['old']['sealed'] is True, '入力seedの版/封印')
    total = 0
    for i, width in enumerate(P.WIDTHS):
        expected = calculated['states'][width].latest
        row = info['dmi'][i]
        P.need(row['width_seconds'] == width and all(row[key] == expected[key] for key in P.COUNT_FIELDS), '入力seedのDMI履歴本数')
        P.need(info['old']['history_bars'][i] == expected['bars'], '旧価格数値とDMIの履歴本数')
        total += P.compare_dmi(row['last'], expected, 'prefix seed')
    return total


def inspect_native(native: dict, scene: dict, children: list[dict], prior: dict | None) -> dict:
    """機能: 保存された全当場公表の価格足/DMIとprefix初期状態を別式へ照合する。

    引数: native/scene(dict)、children(list[dict])、prior(dict|None)は許可Nativeと独立入力。
    返り値: dictは全公表/子足/値の照合計数。金融額は再計算しない。
    """
    P.need(native['trial'] == 115 and native['actual']['trial'] == 115 and native['source']['trial'] == 111, '本名115とSource111')
    actual = native['actual']
    P.need(actual['scope']['session']['id'] == scene['id'] and actual['scope']['contract'] == scene['contract'], 'Nativeの場/限月')
    audit, ending = actual['entry_input'], actual['final_entry_chart']
    P.need(audit['model'] == MODEL and ending['sealed'] is True and ending['session']['eof'] == scene['end'], '入口模型と末尾封印')
    seed_count = check_seed(audit['input_seed'], prior)
    frontier = P.number(ending['as_of'])
    P.need(scene['start'] <= frontier <= scene['end'] and ending['replay_observed_at'] == frontier, '当場の実観測frontier')
    expected, end_state = P.calculate({**scene, 'eof': frontier}, children, prior)
    publications = actual['entry_publications']
    P.need(len(publications) == len(expected), '保存した全当場公表の欠落/過剰')
    totals = {'公表': 0, 'OHLC値': 0, '子足': 0, 'DMI現前値と計数': 0}
    previous_stamp = None
    for i, (row, calculated) in enumerate(zip(publications, expected), 1):
        stamp, frame = row['stamp'], row['frame']['frame']
        P.need(stamp['index'] >= 0 and stamp['source_line'] > 0 and scene['start'] <= stamp['time'] <= frontier, '公表の実原行stamp')
        if previous_stamp is not None:
            P.need(stamp['time'] >= previous_stamp['time'] and stamp['index'] >= previous_stamp['index'] and stamp['source_line'] >= previous_stamp['source_line'], '公表原行順序')
            if stamp['index'] == previous_stamp['index'] or stamp['source_line'] == previous_stamp['source_line']:
                P.need(stamp == previous_stamp, '同原行stamp改変')
        P.need(frame['publication_ordinal'] == i and frame['record_ordinal'] == stamp['index'] + 1
               and frame['observed_at'] == frame['delivery_at'] == stamp['time'] and stamp['time'] >= calculated['nominal_available'], '名目可用/実配送/連番')
        for name, count in P.compare_frame(row['frame'], calculated, scene).items():
            totals[name] += count
        previous_stamp = stamp
    end_count = check_seed(audit['end_seed'], end_state)
    return {'成功': True, '場': scene['id'], '比較': totals, '入力seed比較数': seed_count, '末尾seed比較数': end_count,
            '独立式': 'Decimal60桁/初期14値の直接平均/差分型RMA', '私有Go seedSHA/EMA等の再計算': False}


def run(request_ref: dict, output: Path, metadata_only: bool = False) -> dict:
    """機能: Root固定を認証後だけ許可CSV/Nativeを開き、新規確認を保存する。

    引数: request_ref(dict)、output(Path)、metadata_only(bool)は要求・新規先・本文未読指定。
    返り値: dictは成功確認Ref又はmetadata認証の件数。失敗を成功に補わない。
    """
    plan = prepare(request_ref, output)
    if metadata_only:
        P.need(plan['before'] == {path: sha(Path(path)) for path in plan['before']}, 'metadata/停止所有コード前後不変')
        return {'成功': True, 'metadata_only': True, '許可場数': len(plan['request']['scenes']), 'CSV/Native本文読取': False}

    # ----------------------------------------
    output.mkdir(parents=True, exist_ok=False)
    before, cache, rows = plan['before'], {}, []
    items = {item['id']: item for item in plan['manifest']['sessions']}
    try:
        for task in plan['request']['scenes']:
            prior = None
            for spec in task['prefix'] + [{'session': task['session'], 'csv': task['csv']}]:
                scene = scene_for(items[spec['session']])
                identity = (spec['session'], spec['csv']['sha256'])
                if identity not in cache:
                    path = bind(spec['csv'], before)
                    cache[identity] = parse_csv(path.read_bytes(), spec['csv'], scene)
                children = cache[identity]
                if spec['session'] != task['session']:
                    _, prior = P.calculate(scene, children, prior)
            path = bind(task['native'], before)
            with gzip.open(path, 'rt', encoding='utf-8') as stream:
                native = json.load(stream, parse_float=Decimal)
            P.need(native['actual']['entry_input']['csv'] == task['csv']
                   and native['actual']['entry_input']['prior_sessions'] == len(task['prefix']), 'Nativeの明示CSV/prefix件数')
            checked = inspect_native(native, scene, children, prior)
            rows.append({'session': task['session'], 'native': task['native'], 'csv': task['csv'], 'prefix数': len(task['prefix']), **checked})
        after = {path: sha(Path(path)) for path in before}
        P.need(before == after, 'CSV/Native/固定/コード前後不変')

        # ----------------------------------------
        result = {'試行': 115, '成功': True, 'stage': plan['request']['stage'], 'Root要求': request_ref,
                  '金融条件SHA256': plan['request']['condition']['sha256'], '金融完了SHA256': plan['request']['market']['sha256'],
                  '独立停止SHA256': plan['request']['code_stop']['sha256'], '場数': len(rows), '場別': rows,
                  'CSV個別解釈数': len(cache), '入力SHA256前': before, '入力SHA256後': after, '前後不変': True,
                  '比較絶対許容差': str(P.TOLERANCE), '金融損益再計算': False, 'Raw/11月09本文読取': False,
                  '限界': ['価格足とDMIをCSVから別式形成。RawからCSVを再形成した証明ではない。', 'GoのID/私有seedSHA/EMA/RSI/MACD/ATR/pivotの数値再形成は対象外。', '実受信時刻とRaw上で最初の公表可能行という初回性は対象外。']}
        target = output / '結果.json'
        with target.open('x', encoding='utf-8', newline='\n') as stream:
            stream.write(json.dumps(result, ensure_ascii=False, indent=2, default=str) + '\n')
        return {'成功': True, '場数': len(rows), '結果': file_ref(target)}
    except Exception as error:
        with (output / '不完了.json').open('x', encoding='utf-8', newline='\n') as stream:
            stream.write(json.dumps({'試行': 115, '成功': False, 'Root要求': request_ref, '原因': str(error)}, ensure_ascii=False, indent=2) + '\n')
        raise


def main() -> None:
    """機能: 新Root要求の期待SHAと未作成先だけから検査する。

    引数: CLI fixed/sha256/output(str)、metadata-only(bool)は要求と新規先。
    返り値: なし。小さな結果参照だけを表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fixed', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--metadata-only', action='store_true')
    args = parser.parse_args()
    print(json.dumps(run({'path': str(args.fixed.resolve()), 'sha256': args.sha256}, args.output.resolve(), args.metadata_only), ensure_ascii=False))


if __name__ == '__main__':
    main()
