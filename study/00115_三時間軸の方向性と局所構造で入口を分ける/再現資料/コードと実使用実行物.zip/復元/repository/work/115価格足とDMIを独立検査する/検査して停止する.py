"""価格足とDMIの独立Python実装を、人工だけで検査して停止する。"""

import argparse
import json
from pathlib import Path
import re
import subprocess
import sys

import 検査する as A


def write_new(path: Path, body: str) -> None:
    """機能: 未作成のUTF-8記録だけを書き込む。

    引数: path(Path)、body(str)は新規先と内容。
    返り値: なし。既存記録は上書きしない。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(body)


def stop(output: Path) -> dict:
    """機能: Go停止/公開人工と所有コードを認証し、人工成功と前後不変を記録する。

    引数: output(Path)は未作成の絶対保存先。
    返り値: dictは新停止FileRef。市場CSV/Native/Rawは開かない。
    """
    A.P.need(sys.flags.optimize == 0 and output.is_absolute() and not output.exists(), '通常Python/新規絶対停止先')
    bank_path = A.ROOT / 'work/115三時間軸と方向性の公開/検査_停止版/停止.json'
    artificial = A.ROOT / 'work/115三時間軸と方向性の公開/検査_停止版/人工/買売人工.json'
    bank_ref = {'path': str(bank_path), 'sha256': A.BANK_SHA}
    frozen = {}
    bank = A.metadata(bank_ref, frozen)
    A.P.need(bank['試行'] == 115 and bank['成功'] is True and bank['停止'] is True and bank['市場前'] is True, 'Go公開器停止')
    for path, expected in bank['所有コードSHA256'].items():
        A.P.need(A.sha(Path(path)) == expected, '固定Go所有コードのSHA差')
        frozen[path] = expected
    A.P.need(A.sha(artificial) == 'f5d44c3c140aae8680f4b7b8f5e0d3b824a48b2adfd2e2d75cbd591031f77807', '公開Go人工SHA')
    frozen[str(artificial)] = A.sha(artificial)
    owned = {str(A.OWN / name): A.sha(A.OWN / name) for name in A.OWNED}
    before = {**frozen, **owned}

    # ----------------------------------------
    output.mkdir(parents=True, exist_ok=False)
    try:
        checked = subprocess.run([sys.executable, '-X', 'utf8', str(A.OWN / '人工検査.py')], cwd=A.OWN,
                                 capture_output=True, text=True, encoding='utf-8', check=False)
        log = checked.stdout + checked.stderr
        write_new(output / '人工検査.txt', log)
        match = re.search(r'^Ran ([0-9]+) tests? in ', log, re.MULTILINE)
        A.P.need(checked.returncode == 0 and match is not None and int(match[1]) == 12 and log.rstrip().endswith('OK'), '12主人工の全成功')
        after = {path: A.sha(Path(path)) for path in before}
        A.P.need(before == after, '独立所有/固定Go公開器/公開人工の前後不変')
        result = {'試行': 115, '成功': True, '停止': True, '市場前': True, 'Go公開器停止': bank_ref,
                  '所有ファイルSHA256': owned, '人工主検査数': int(match[1]), '人工検査': A.file_ref(output / '人工検査.txt'),
                  'Go公開人工': A.file_ref(artificial), 'コードと固定資料SHA256前': before, 'コードと固定資料SHA256後': after,
                  '前後不変': True, '市場CSV本文読取': False, '市場Native本文読取': False, 'Raw/11月09本文読取': False,
                  '独立式': '明示CSV prefixの5/15/30分合成とDecimal60桁/初期14値直接平均/差分型RMA',
                  '実行環境': {'Python': sys.version, '実行物': A.file_ref(Path(sys.executable))},
                  '限界': ['市場比較はRootの新固定要求後に別実行する。', '私有Go seedSHAと他の技法・金融額・RawからCSV生成は再計算しない。']}
        target = output / '停止.json'
        write_new(target, json.dumps(result, ensure_ascii=False, indent=2) + '\n')
        return {'成功': True, '停止': A.file_ref(target)}
    except Exception as error:
        write_new(output / '不完了.json', json.dumps({'試行': 115, '成功': False, '原因': str(error)}, ensure_ascii=False, indent=2) + '\n')
        raise


def main() -> None:
    """機能: 人工のみの停止CLIを実行する。

    引数: --output(str)は新規停止先の絶対path。
    返り値: なし。停止Refだけを標準出力へ表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(stop(args.output.resolve()), ensure_ascii=False))


if __name__ == '__main__':
    main()
