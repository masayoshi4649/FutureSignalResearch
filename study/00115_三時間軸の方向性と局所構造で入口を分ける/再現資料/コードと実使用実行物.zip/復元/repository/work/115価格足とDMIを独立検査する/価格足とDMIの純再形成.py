"""明示した5分子足だけから価格足とDMIをDecimal別式で再形成する。"""

from copy import deepcopy
from decimal import Decimal, getcontext
import math


getcontext().prec = 60
WIDTHS = (300, 900, 1800)
ZERO = Decimal(0)
TOLERANCE = Decimal('1e-8')
VALUE_FIELDS = ('plus_di', 'minus_di', 'dx', 'adx', 'previous_plus_di', 'previous_minus_di', 'previous_adx')
COUNT_FIELDS = ('bars', 'differences', 'dx_count')


def need(test: bool, label: str) -> None:
    """機能: 不一致や不正入力を停止する。

    引数: test(bool)、label(str)は成立条件と説明。
    返り値: なし。不成立はValueError。
    """
    if not test:
        raise ValueError(label)


def number(value: int | float | Decimal) -> Decimal:
    """機能: 有限float64域の値を十進数へ変換する。

    引数: value(int|float|Decimal)は数値。boolは数値としない。
    返り値: Decimalは有限な値。不正はValueError。
    """
    need(type(value) in (int, float, Decimal), '数値型が必要')
    result = Decimal(str(value))
    need(result.is_finite() and math.isfinite(float(result)), '有限float64域だけ')
    return result


def value(amount: Decimal | None = None) -> dict:
    """機能: 未知と既知0を分ける公開値を作る。

    引数: amount(Decimal|None)は既知値又は未知。
    返り値: dictはknown/value。未知の格納値は0。
    """
    return {'known': amount is not None, 'value': ZERO if amount is None else amount}


def empty_dmi() -> dict:
    """機能: 全て未知の公開DMIを作る。

    引数: なし。
    返り値: dictは現前7数値と3計数。
    """
    return {**{key: value() for key in VALUE_FIELDS}, **{key: 0 for key in COUNT_FIELDS}}


class Average:
    """初期14値の直接平均後にWilder平均を更新する独立状態。"""

    def __init__(self) -> None:
        """機能: 初期窓と既知値を空にする。

        引数: self(Average)は独立平均器。
        返り値: なし。
        """
        self.initial = []
        self.current = None

    def add(self, item: Decimal) -> Decimal | None:
        """機能: 非負値を初期SMA又はRMA14へ入れる。

        引数: self(Average)、item(Decimal)は平均器と入力。
        返り値: Decimal|Noneは現在平均又は助走不足。
        """
        need(item.is_finite() and item >= 0, '平均入力は有限非負')
        if self.current is None:
            self.initial.append(item)
            if len(self.initial) == 14:
                self.current = sum(self.initial) / 14
        else:
            self.current += (item - self.current) / 14
        return self.current


class Directional:
    """高安差・前終値と別式の初期平均からDMI/ADXを形成する。"""

    def __init__(self) -> None:
        """機能: 価格/平均/連続DXをcoldにする。

        引数: self(Directional)は独立方向性器。
        返り値: なし。
        """
        self.previous = None
        self.average = {key: Average() for key in ('up', 'down', 'range', 'dx')}
        self.latest = empty_dmi()
        self.bars = self.differences = self.dx_count = 0

    def advance(self, bar: dict | None) -> dict:
        """機能: 正常親足を一度更新し、価格未知なら全数値をresetする。

        引数: self(Directional)、bar(dict|None)は器とOHLC又は価格未知。
        返り値: dictは現前の全公開値。前場数値のcarryは呼出側で値copyする。
        """
        if bar is None:
            self.__init__()
            return deepcopy(self.latest)
        prices = {key: number(bar[key]) for key in ('open', 'high', 'low', 'close')}
        output = empty_dmi()
        for target, origin in (('previous_plus_di', 'plus_di'), ('previous_minus_di', 'minus_di'), ('previous_adx', 'adx')):
            output[target] = deepcopy(self.latest[origin])
        self.bars += 1
        if self.previous is not None:
            rise = prices['high'] - self.previous['high']
            fall = self.previous['low'] - prices['low']
            upward = rise if rise > max(fall, ZERO) else ZERO
            downward = fall if fall > max(rise, ZERO) else ZERO
            ranges = (prices['high'] - prices['low'], abs(prices['high'] - self.previous['close']), abs(prices['low'] - self.previous['close']))
            up = self.average['up'].add(upward)
            down = self.average['down'].add(downward)
            true_range = self.average['range'].add(max(ranges))
            self.differences += 1
            if up is not None and down is not None and true_range is not None and true_range > 0 and up + down > 0:
                output['plus_di'] = value(100 * up / true_range)
                output['minus_di'] = value(100 * down / true_range)
                dx = 100 * abs(up - down) / (up + down)
                output['dx'] = value(dx)
                output['adx'] = value(self.average['dx'].add(dx))
                self.dx_count += 1
            else:
                self.average['dx'] = Average()
                self.dx_count = 0
        self.previous = prices
        output.update(bars=self.bars, differences=self.differences, dx_count=self.dx_count)
        self.latest = deepcopy(output)
        return output


def price_known(child: dict) -> bool:
    """機能: 子足の確定性と正の整合OHLCを判定する。

    引数: child(dict)は明示した子足。
    返り値: boolは価格を形成できる場合だけ真。
    """
    bar = child['ohlc']
    return child['closed'] is True and min(bar.values()) > 0 and bar['low'] <= min(bar['open'], bar['close']) <= max(bar['open'], bar['close']) <= bar['high']


def plans(scene: dict, children: list[dict]) -> list[dict]:
    """機能: 完全な当場子区間から5/15/30分の名目公表を独立合成する。

    引数: scene(dict)、children(list[dict])は場時計と既に認証した5分子足。
    返り値: list[dict]はEnd+60・幅の順。欠けた子を補完しない。
    """
    start, end = scene['start'], scene['end']
    need(type(start) is int and type(end) is int and start > 0 and end > start and start % 300 == 0 and (end - start) % 300 == 0, '場の300秒格子')
    indexed = {child['start']: child for child in children}
    need(len(indexed) == len(children), '子足時刻の重複')
    output = []
    for width in WIDTHS:
        for left in range(start, end - width + 1, width):
            right = left + width
            if right + 60 > scene.get('eof', end):
                continue
            selected = [indexed.get(at) for at in range(left, right, 300)]
            known = all(child is not None and price_known(child) for child in selected)
            volume_known = all(child is not None and child['closed'] and child['volume_known'] for child in selected)
            bar = dict.fromkeys(('open', 'high', 'low', 'close'), ZERO)
            if known:
                bar = {'open': selected[0]['ohlc']['open'], 'high': max(child['ohlc']['high'] for child in selected),
                       'low': min(child['ohlc']['low'] for child in selected), 'close': selected[-1]['ohlc']['close']}
            output.append({'width_seconds': width, 'start': left, 'end': right, 'nominal_available': right + 60,
                           'available_at': right + 60, 'price_known': known, 'volume_known': volume_known, 'ohlc': bar,
                           'volume': sum(child['volume'] for child in selected) if volume_known else ZERO,
                           'child_count': width // 300, 'children': selected})
    return sorted(output, key=lambda item: (item['nominal_available'], item['width_seconds']))


def calculate(scene: dict, children: list[dict], prior: dict | None = None) -> tuple[list[dict], dict]:
    """機能: 一場の名目公開順で独立価格足とDMIを再形成する。

    引数: scene(dict)、children(list[dict])、prior(dict|None)は場と子足と前場私有計算状態。
    返り値: tuple[list[dict],dict]は全名目公表と数値だけの末尾状態。
    """
    if prior is not None:
        need(scene['start'] >= prior['end'] and scene['start'] > prior['start'], '前史の重複/逆行')
    states = deepcopy(prior['states']) if prior is not None and prior['contract'] == scene['contract'] else {width: Directional() for width in WIDTHS}
    output = []
    for frame in plans(scene, children):
        frame['dmi'] = states[frame['width_seconds']].advance(frame['ohlc'] if frame['price_known'] else None)
        output.append(frame)
    return output, {'states': states, 'contract': scene['contract'], 'start': scene['start'], 'end': scene['end']}


def equal_number(actual: int | float | Decimal, expected: Decimal, label: str) -> None:
    """機能: 保存float64値を独立Decimal値へ絶対1e-8以内で比較する。

    引数: actual(int|float|Decimal)、expected(Decimal)、label(str)は保存値・期待値・説明。
    返り値: なし。不一致はValueError。
    """
    need(abs(number(actual) - expected) <= TOLERANCE, label)


def compare_dmi(actual: dict, expected: dict, label: str = 'DMI') -> int:
    """機能: 現前の全既知性・値・計数を照合する。

    引数: actual/expected(dict)、label(str)は保存値・独立値・説明。
    返り値: intは照合した数値項目数。未知値は既知0へ補完しない。
    """
    need(set(actual) == set(expected) == set(VALUE_FIELDS + COUNT_FIELDS), label + '集合')
    for key in VALUE_FIELDS:
        left, right = actual[key], expected[key]
        need(type(left['known']) is bool and left['known'] == right['known'], label + '.' + key + '.known')
        if right['known']:
            equal_number(left['value'], right['value'], label + '.' + key)
        else:
            need(number(left['value']) == 0, label + '.' + key + '未知の格納値')
    for key in COUNT_FIELDS:
        need(type(actual[key]) is int and actual[key] == expected[key], label + '.' + key)
    return len(VALUE_FIELDS) + len(COUNT_FIELDS)


def compare_frame(actual: dict, expected: dict, scene: dict) -> dict:
    """機能: 保存した旧Frameの価格/子足/公表時計と追加DMIを照合する。

    引数: actual/expected/scene(dict)は保存wrapper・独立公表・場時計。
    返り値: dictは比較計数。Frame ID/Go私有seed SHAの独立再符号化は主張しない。
    """
    frame = actual['frame']
    need(frame['session_id'] == scene['id'] and frame['contract'] == scene['contract'], '公表の場/限月')
    for key in ('width_seconds', 'start', 'end', 'nominal_available', 'available_at', 'child_count', 'price_known', 'volume_known'):
        need(frame[key] == expected[key], '価格足.' + key)
    need(type(frame['price_known']) is bool and type(frame['volume_known']) is bool, '親足既知性の真偽型')
    for key in ('open', 'high', 'low', 'close'):
        equal_number(frame['ohlc'][key], expected['ohlc'][key], 'OHLC.' + key)
    equal_number(frame['volume'], expected['volume'], '親出来高')
    need(len(frame['children']) == 6, '子出典の固定6欄')
    for i in range(frame['child_count']):
        child, recorded = expected['children'][i], frame['children'][i]
        need(all(type(recorded[key]) is bool for key in ('present', 'price_known', 'volume_known')), '子足既知性の真偽型')
        need(recorded['start'] == expected['start'] + i * 300 and recorded['end'] == recorded['start'] + 300, '子足時計')
        need(recorded['present'] == (child is not None), '子足の欠測')
        if child is None:
            need(recorded['price_known'] is False and recorded['volume_known'] is False and recorded['row'] == 0, '欠測の既知性')
        else:
            need(recorded['row'] == child['row'] and recorded['input'] == child['input'], '子足の入力Ref/物理CSV行')
            need(recorded['price_known'] == price_known(child) and recorded['volume_known'] == (child['closed'] and child['volume_known']), '子足の完全性')
    count = compare_dmi(actual['dmi'], expected['dmi'])
    return {'公表': 1, 'OHLC値': 4, '子足': frame['child_count'], 'DMI現前値と計数': count}
