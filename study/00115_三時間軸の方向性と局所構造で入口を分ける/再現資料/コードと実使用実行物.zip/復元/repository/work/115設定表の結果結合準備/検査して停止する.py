"""115設定表の結果結合器を、原固定表の不変と人工で停止する。"""

import argparse
import json
from pathlib import Path
import subprocess
import sys
import 結合する as M
import 人工検査 as T


def main() -> None:
    """機能: 4主人工と入力表/所有コードの前後不変を新規保存する。

    引数: CLI output(str)は新しい人工/停止先。
    返り値: None。実金融結果は読まず停止Refだけを表示する。
    """
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();output=args.output.resolve()
    M.need(not output.exists() and output.is_relative_to(M.OWN),'本ownedの新規検査先')
    owned={str(M.OWN/name):M.sha(M.OWN/name) for name in ('結合する.py','人工検査.py','README.md','検査して停止する.py')}
    M.need(M.sha(M.TABLE_PATH)==M.TABLE_SHA and M.sha(T.FAKE)==T.FAKE_SHA,'入力表/人工の固定SHA')
    output.mkdir()
    test=subprocess.run([sys.executable,'-X','utf8',str(M.OWN/'人工検査.py')],cwd=M.OWN,capture_output=True,text=True,encoding='utf-8',timeout=60)
    log=output/'人工検査.txt';log.write_text(test.stdout+test.stderr,encoding='utf-8',newline='\n')
    M.need(test.returncode==0,'115設定表の全人工成功')
    source,fake=T.inputs();rendered,checks=M.render(source,fake,True)
    sample=output/'人工の設定と結果.md';sample.write_text(rendered,encoding='utf-8',newline='\n')
    M.need(all(M.sha(Path(p))==h for p,h in owned.items()) and M.sha(M.TABLE_PATH)==M.TABLE_SHA and M.sha(T.FAKE)==T.FAKE_SHA,'入力/所有の前後不変')
    record={'試行':115,'成功':True,'市場前':True,'所有ファイルSHA256':owned,'入力表':{'path':str(M.TABLE_PATH),'sha256':M.TABLE_SHA},
            '人工入力':{'path':str(T.FAKE),'sha256':T.FAKE_SHA},'主人工':4,'検査':checks,'前後不変':True,
            '人工出力':{'path':str(sample),'sha256':M.sha(sample)},'ログ':{'path':str(log),'sha256':M.sha(log)},
            '実金融結果/Raw/Native/CSV本文読取':False,'正式設定表編集':False,'採用自動判定':False,'研究目標達成':False}
    target=output/'停止.json'
    with target.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'停止':{'path':str(target),'sha256':M.sha(target)}},ensure_ascii=False))


if __name__=='__main__':main()
