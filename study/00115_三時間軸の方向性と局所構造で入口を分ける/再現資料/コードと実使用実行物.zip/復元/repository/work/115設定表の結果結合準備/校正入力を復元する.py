"""市場前の原文から、少数行差分だけで115の校正済み入力を復元する。"""

import argparse
import hashlib
import json
from pathlib import Path


def digest(data: bytes) -> str:
    """機能: 再現する文書の全bytesを指紋化する。

    引数: data(bytes)は原文又は復元後UTF-8。
    返り値: strは小文字SHA256。
    """
    return hashlib.sha256(data).hexdigest()


def restore(source: Path, patch: Path, patch_sha: str, output: Path) -> dict:
    """機能: 明示SHAの原文/差分から校正入力を未作成先だけへ復元する。

    引数: source/patch/output(Path)、patch_sha(str)は原文・行差分・新規先・差分SHA。
    返り値: dictは同体証明。既存の校正コピーや正式設定表は上書きしない。
    """
    if output.exists() or digest(patch.read_bytes()) != patch_sha:
        raise ValueError('未作成先又は差分SHAの不整合')
    data = json.loads(patch.read_bytes()); raw = source.read_bytes()
    if data['version'] != 1 or data['trial'] != 115 or data['成功'] is not True or digest(raw) != data['source']['sha256']:
        raise ValueError('原文の版/指紋差')
    lines = raw.decode('utf-8').splitlines(keepends=True)
    previous = len(lines)
    for change in reversed(data['edits']):
        start, end = change['start'], change['end']
        if not 0 <= start <= end <= previous or lines[start:end] != change['before']:
            raise ValueError('行差分の範囲/原文差')
        lines[start:end] = change['after']; previous = start
    restored = ''.join(lines).encode('utf-8')
    if digest(restored) != data['target']['sha256']:
        raise ValueError('校正済み入力の同bytes差')
    with output.open('xb') as stream:
        stream.write(restored)
    if digest(source.read_bytes()) != data['source']['sha256'] or digest(patch.read_bytes()) != patch_sha:
        raise ValueError('原文/差分の前後差')
    return {'試行': 115, '成功': True, '出力': {'path': str(output.resolve()), 'sha256': digest(restored)},
            '変更範囲数': len(data['edits']), '元文書の変更': False, '市場/Raw/Native/CSV読取': False}


def main() -> None:
    """機能: Rootが明示した原文と差分から校正入力を別先へ復元する。

    引数: CLI source/patch/output(Path)、patch-sha(str)は参照と新規先。
    返り値: None。復元したFileRefを表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--patch', type=Path, required=True)
    parser.add_argument('--patch-sha', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(restore(args.source.resolve(), args.patch.resolve(), args.patch_sha, args.output.resolve()), ensure_ascii=False))


if __name__ == '__main__': main()
