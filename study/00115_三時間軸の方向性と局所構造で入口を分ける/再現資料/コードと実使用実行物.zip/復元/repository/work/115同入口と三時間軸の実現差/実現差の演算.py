"""固定113/114の厳密同入口演算を再用し、115の役割別当時票を結ぶ。"""
from collections import Counter
from copy import deepcopy
from pathlib import Path
import hashlib
import importlib.util

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PRIOR=ROOT/"work/114同入口と要求時技法の実現差/実現差の演算.py"
PRIOR_SHA="bcc2a6c103713625204e5f5af63c827e1c279a16f921b6b4007f2d479e54037c"
if hashlib.sha256(PRIOR.read_bytes()).hexdigest()!=PRIOR_SHA:raise ValueError("固定114比較演算SHA差")
_spec=importlib.util.spec_from_file_location("固定114比較を115へ再用",PRIOR);P=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(P)
OLD=P.OLD
need,amount,canon,serial,source_index,selected,mtm_dd=P.need,P.amount,P.canon,P.serial,P.source_index,P.selected,P.mtm_dd
Decimal,ZERO=P.Decimal,P.ZERO
GROUPS,OWNERS,PERIODS=P.GROUPS,P.OWNERS,P.PERIODS
MODES=("A0","T","TR")
KEYS=tuple(f"{m}_C{c}_D{d}" for m in MODES for c in (0,5) for d in (0,1))
CONFIGS=tuple({"policy":"P100","entry_mode":m,"slip_pts":c,"delay_seconds":d} for m in MODES for c in (0,5) for d in (0,1))
PAIRS=(("114A0","115A0"),("115A0","115T"),("115A0","115TR"),("115T","115TR"))
ROLES=("30m配置順","30m配置逆","15mDI順","15mADX20","5mClose突破","要求Last保持","前ATR正","TR上限余裕")
CLASSES=("T真","R真","双方偽","TR未知")


def comparison_specs() -> list[tuple]:
    """
    機能: 元16対照と同mode/delayのC0→C5感度6対照を事前列挙する。
    引数: なし。返り値: list[tuple]は名称/前key/後key/種別の22組。
    """
    rows=[(f"{a}→{b}_C{c}_D{d}",f"{a}_C{c}_D{d}",f"{b}_C{c}_D{d}","入口比較") for a,b in PAIRS for c in (0,5) for d in (0,1)]
    rows.extend((f"115{m}_C0_D{d}→115{m}_C5_D{d}",f"115{m}_C0_D{d}",f"115{m}_C5_D{d}","追加滑り感度") for m in MODES for d in (0,1))
    return rows


def exit_execution(signature: dict) -> dict:
    """
    機能: 費用/床Stateとは別に、実返済注文と実fillの執行だけを投影する。
    引数: signature(dict)は全値の退出署名。返り値: dictは時刻/quote/価格/量/理由/取消。
    """
    orders=signature["返済要求"];fills=signature["返済fill"]
    return {"要求":[{k:o[k] for k in ("kind","side","quantity","source_hold_id","native_close_signal_id","native_close_notice_id","request_time","request_quote","reason","status","cancel_time","cancel_reason")} for o in orders],"約定":[{k:f[k] for k in ("side","quantity","price","quote","source_hold_id","native_close_signal_id","native_close_notice_id","reason","order_ordinal")} for f in fills]}


def protection_witness(signature: dict) -> dict:
    """
    機能: 初起動/狭幅/床更新/hitを実時点と保存値へ小さく結び付ける。
    引数: signature(dict)。返り値: dictは未発生Noneを保つ主要witness。
    """
    result={};audit=signature["保存保護履歴"]
    for name in ("first_activation","first_narrowing","first_floor_update","last_floor_update","first_floor_hit","first_all_reserved_hit"):
        p=audit[name]
        result[name]=None if p is None else {"at":p["at"],"quote":p["quote"],"phase":p["phase"],"exit_order_id":p["exit_order_id"],"snapshot":{k:p["snapshot"][k] for k in ("minimum_floor","active","activated_at","narrowed","normal_width","width_points","peak_points","floor_points","whole_target_yen","closed_net_yen","remaining","reserved")},"decision":{k:p["decision"].get(k) for k in ("gain_points","unit_net_yen","whole_net_yen","whole_floor","peak_floor","structural_floor","protect_price","floor_hit","eligible_exit_quantity")}}
    return result


def execution_and_cost_statistics(left: list[dict],right: list[dict]) -> dict:
    """
    機能: 成立した両側の実gross/fee/slipと共通入口の執行差を加法照合する。
    引数: left/right(list[dict])。返り値: dictは仮退出を作らない実現差分解。
    """
    totals={side:{k:sum((r["realized"][k] for r in rows),ZERO) for k in ("gross","fee","slip")} for side,rows in (("前",left),("後",right))}
    difference={k:totals["後"][k]-totals["前"][k] for k in totals["前"]};difference["net"]=sum((r["net"] for r in right),ZERO)-sum((r["net"] for r in left),ZERO)
    need(difference["net"]==difference["gross"]-difference["fee"]-difference["slip"],"実現差のgross費用加法")
    a,b={r["base"]:r for r in left},{r["base"]:r for r in right};common=[k for k in a.keys()&b.keys() if canon(a[k]["entry"])==canon(b[k]["entry"])];count=Counter({k:0 for k in ("同実入口","実返済執行同体","実返済執行差","主要保護witness差")})
    for k in common:
        count["同実入口"]+=1;same=canon(a[k]["execution"])==canon(b[k]["execution"]);count["実返済執行同体"]+=same;count["実返済執行差"]+=not same;count["主要保護witness差"]+=canon(a[k]["witness"])!=canon(b[k]["witness"])
    return {"実額":totals,"後引く前":difference,"同入口の費用外執行比較":dict(count),"注意":"費用State差は当然に許す。各額は両側で成立した実値で、同退出を仮定した仮PnLはない。"}


def truth(value,op: str) -> int:
    """
    機能: 保存派生値の符号を事前固定の役割へ三値分類する。
    引数: value(数値|None)、op(str)。返り値: intは未知0/偽1/真2。
    """
    if value is None:return 0
    v=amount(value);passed=v>0 if op==">0" else v<0 if op=="<0" else v>=20 if op==">=20" else v>=0
    return 2 if passed else 1


def gate_rows(book: dict,index: dict) -> list[dict]:
    """
    機能: 115の全Source要求を当時役割/分母へ結び、未取得へ仮損益を付けない。
    引数: book/index(dict)。返り値: list[dict]は全出生の記述台帳。
    """
    rows=[];seen=set();sid=book["session"]["id"]
    for record in book["entry_gate"]["records"] or []:
        q,d=record["request"],record["decision"];key=sid,q["product"],q["method"],q["side"],q["signal_id"]
        need(d["version"]==115 and q==d["request"] and d["frozen"] and key not in seen and key in index,"115要求時固定と複合出生")
        source=index[key];signal=source["signal"];seen.add(key)
        need(q["last"]==record["quote"]["last"] and source["record"]["quote"]==record["quote"] and source["record"]["at"]==q["at"]["time"],"115Source要求原行/Last")
        owner=signal.get("owner") or "不明";need(owner in OWNERS[1:],"保存owner")
        mode=book["config"]["entry_mode"];chosen=2 if mode=="A0" else d["trend"] if mode=="T" else d["combined"]
        need(record["selected"]==chosen and record["allowed"]==(chosen==2),"115選別モード")
        v=d["values"];role={n:truth(v[k],op) for n,k,op in (("30m配置順","g30",">0"),("30m配置逆","g30","<0"),("15mDI順","d15",">0"),("15mADX20","adx15",">=20"),("5mClose突破","close_break",">0"),("要求Last保持","last_break",">0"),("前ATR正","previous_atr5",">0"),("TR上限余裕","spike_margin",">=0"))}
        need([x["truth"] for x in d["common_conditions"]]==[role[k] for k in ("5mClose突破","前ATR正","TR上限余裕","要求Last保持")],"共通役割の保存票へ一致")
        need([x["truth"] for x in d["trend_conditions"]]==[role[k] for k in ("30m配置順","15mDI順","15mADX20")] and [x["truth"] for x in d["reversal_conditions"]]==[role[k] for k in ("30m配置逆","15mDI順")],"経路役割の保存票へ一致")
        frames={str(x["width_seconds"]):x["current"]["frame"]["id"] if x["has_current"] else None for x in d["current"]["snapshot"]["scales"]}
        rows.append({"base":key,"session":sid,"owner":owner,"class":P.classification(d),"input_missing":bool(d["missing_inputs"]),"selected":chosen,"roles":role,"values":deepcopy(v),"frames":frames,"common":d["common"],"accepted_quantity":record["accepted_quantity"],"actual_quantity":record["actual_quantity"],"position_id":record["actual_position_id"]})
    need(len(rows)==book["metrics"]["native_new_signals"],"115全Source要求分母")
    return rows


def records(book: dict,index: dict,legacy: bool=False) -> list[dict]:
    """
    機能: 実玉を固定113の金融結合で抽出し、新115だけに当時役割を付ける。
    引数: book/index(dict)、legacy(bool)。返り値: list[dict]は成立玉だけ。
    """
    result=OLD.records(book,index);positions={p["id"]:p for p in book["positions"]}
    acquired={} if legacy else {r["position_id"]:r for r in gate_rows(book,index) if r["actual_quantity"]>0}
    need(legacy or set(acquired)==set(positions),"115実玉と要求票一対一")
    for row in result:
        row["technical"]=None
        if not legacy:
            request=acquired[row["id"]];need(request["base"]==row["base"] and request["actual_quantity"]==row["qty"],"115実取得量を仮定せず照合")
            row["technical"]={k:deepcopy(request[k]) for k in ("class","input_missing","roles","values","frames","common")}
        row["exit"]=P.exit_signature(positions[row["id"]],book)
        row["execution"]=exit_execution(row["exit"]);row["witness"]=protection_witness(row["exit"])
        p=positions[row["id"]];parts=[a for f in book["fills"] if f["position_id"]==p["id"] and f["action"]=="close" for a in f["allocations"]]
        row["realized"]={"gross":amount(p["gross_yen"]),"fee":sum((amount(a["entry_fee_yen"])+amount(a["exit_fee_yen"]) for a in parts),ZERO),"slip":sum((amount(a["entry_slip_yen"])+amount(a["exit_slip_yen"]) for a in parts),ZERO)}
        need(row["net"]==row["realized"]["gross"]-row["realized"]["fee"]-row["realized"]["slip"],"実玉gross手数料滑りの加法")
    return result


def pair_records(left: list[dict],right: list[dict]) -> tuple:
    """
    機能: 実入口四群を作り、共通入口の全退出/保護同体を仮定せず分類する。
    引数: left/right(list[dict])。返り値: tupleは四群・対応台帳・変更属性・共通退出検査。
    """
    groups,matched,differences=OLD.pair_records(left,right);a={r["base"]:r for r in left};b={r["base"]:r for r in right};checks=Counter({k:0 for k in ("共通入口数","初期P100同体","全返済と保存保護同体","返済差あり")});fields=Counter()
    for m in matched:
        l,r=a.get(m["base"]),b.get(m["base"]);m["前要求時技法"]=None if l is None else l["technical"];m["後要求時技法"]=None if r is None else r["technical"]
        m["前実現内訳"]=None if l is None else l["realized"];m["後実現内訳"]=None if r is None else r["realized"]
        if m["群"]!="同実入口":continue
        changed=[k for k in l["exit"] if canon(l["exit"][k])!=canon(r["exit"][k])];checks["共通入口数"]+=1;checks["初期P100同体"]+="初期P100" not in changed;checks["全返済と保存保護同体"]+=not changed;checks["返済差あり"]+=bool(changed);fields.update(changed);m["共通返済の差分属性"]=changed
        if not changed:need(l["net"]==r["net"],"全返済同体なら実現差0")
        m["費用外の実返済執行同体"]=canon(l["execution"])==canon(r["execution"])
        m["主要保護witness同体"]=canon(l["witness"])==canon(r["witness"])
        if changed:
            m["前実返済執行"]=l["execution"];m["後実返済執行"]=r["execution"];m["前主要保護witness"]=l["witness"];m["後主要保護witness"]=r["witness"]
    return groups,matched,differences,{**checks,"差分属性":dict(fields)}


def summarize(groups: dict,period: str,owner: str) -> dict:
    """
    機能: 実入口四群の実現差・cash-DDと共通退出差を固定期間/ownerへ分ける。
    引数: groups(dict)、period/owner(str)。返り値: dict。未成立の仮損益はない。
    """
    result=OLD.summarize(groups,period,owner);a={r["base"]:r for r in groups["同実入口"]["前"] if selected(r,period,owner)};b={r["base"]:r for r in groups["同実入口"]["後"] if selected(r,period,owner)};need(set(a)==set(b),"共通入口の期間owner")
    checks=Counter({k:0 for k in ("共通入口数","初期P100同体","全返済と保存保護同体","返済差あり")});fields=Counter()
    for key,l in a.items():
        r=b[key];changed=[k for k in l["exit"] if canon(l["exit"][k])!=canon(r["exit"][k])];checks["共通入口数"]+=1;checks["初期P100同体"]+="初期P100" not in changed;checks["全返済と保存保護同体"]+=not changed;checks["返済差あり"]+=bool(changed);fields.update(changed)
    result["共通入口の同保護確認"]={**checks,"差分属性":dict(fields)}
    all_rows={side:[r for g in groups.values() for r in g[side] if selected(r,period,owner)] for side in ("前","後")}
    result["実現内訳と執行差"]=execution_and_cost_statistics(all_rows["前"],all_rows["後"])
    return result


def coverage(rows: list[dict]) -> dict:
    """
    機能: 全要求の役割/未知/選別と受付実取得を件数だけで分離する。
    引数: rows(list[dict])。返り値: dict。費用反復を独立市場機会にしない。
    """
    def counts(items: list[dict]) -> dict:
        """
        機能: 指定した要求集合だけの出生・受付・実取得を数える。
        引数: items(list[dict])。返り値: dictは件数/枚数。
        """
        return {"Source出生":len(items),"受付":sum(r["accepted_quantity"]>0 for r in items),"受付枚":sum(r["accepted_quantity"] for r in items),"実取得":sum(r["actual_quantity"]>0 for r in items),"実取得枚":sum(r["actual_quantity"] for r in items),"distinct5分公表":len({(r["session"],r["frames"]["300"]) for r in items if r["frames"]["300"] is not None})}
    return {**counts(rows),"選別三値":{str(t):sum(r["selected"]==t for r in rows) for t in (0,1,2)},"入力不足あり":sum(r["input_missing"] for r in rows),"要求時分類":{c:counts([r for r in rows if r["class"]==c]) for c in CLASSES},"役割別":{name:{str(t):counts([r for r in rows if r["roles"][name]==t]) for t in (0,1,2)} for name in ROLES},"三値定義":"0未知/1既知偽/2真。役割間は重複し加算しない"}


def role_statistics(rows: list[dict]) -> dict:
    """
    機能: 実際に成立した115玉の収支を当時役割の三値ごとに記述する。
    引数: rows(list[dict])。返り値: dict。新gateの効果や機会損失とは呼ばない。
    """
    need(all(r["technical"] is not None for r in rows),"115役割の保存あり");total=OLD.statistics(rows)
    result={name:{str(t):OLD.statistics([r for r in rows if r["technical"]["roles"][name]==t]) for t in (0,1,2)} for name in ROLES}
    for name in ROLES:need(sum(result[name][str(t)]["実現円"] for t in (0,1,2))==total["実現円"],"役割三値の実現加法")
    return {"全実玉":total,"役割別":result,"T/R分類":{c:OLD.statistics([r for r in rows if r["technical"]["class"]==c]) for c in CLASSES},"入力不足あり":OLD.statistics([r for r in rows if r["technical"]["input_missing"]])}
