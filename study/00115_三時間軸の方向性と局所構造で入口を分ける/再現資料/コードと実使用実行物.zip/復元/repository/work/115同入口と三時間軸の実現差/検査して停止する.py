"""115の記述診断を人工だけで停止し、新旧自然Nativeの解禁前に固定する。"""
from pathlib import Path
from datetime import datetime,timezone
import ast
import subprocess
import sys

import 診断する as D
import 人工検査 as T


def main() -> None:
    """
    機能: 所有5・固定依存・10人工・明示手製の前後不変を市場前に保存する。
    引数: なし。返り値: None。自然Native/Raw/CSV本文/金融は実行しない。
    """
    target=D.HERE/"停止.json";D.C.need(not target.exists(),"新規停止のみ");before={};D.dependencies(before);own={str((D.HERE/n).resolve()):D.digest(D.HERE/n) for n in D.OWNED}
    for ref in (T.ACTOR_ART,T.CORE_ART):D.reference(ref,before)
    for name in D.OWNED:
        if not name.endswith(".py"):continue
        for n in ast.walk(ast.parse((D.HERE/name).read_text(encoding="utf-8"))):
            if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)):
                doc=ast.get_docstring(n) or "";D.C.need("\n" in doc and all(w in doc for w in ("機能","引数","返り値")),"関数コメント:"+n.name)
    logs=[]
    for command in ([sys.executable,"-X","utf8",str(D.HERE/"人工検査.py")],[sys.executable,"-X","utf8",str(D.HERE/"診断する.py"),"--help"]):
        p=subprocess.run(command,cwd=D.HERE,capture_output=True,text=True,encoding="utf-8",timeout=60);D.C.need(p.returncode==0,p.stdout+p.stderr);logs.append({"command":command,"exit":p.returncode,"stdout":p.stdout,"stderr":p.stderr})
    D.C.need("Ran 10 tests" in logs[0]["stderr"] and "OK" in logs[0]["stderr"],"10主人工")
    D.C.need(all(D.digest(Path(p))==s for p,s in {**before,**own}.items()),"全所有依存人工前後不変")
    print(__import__("json").dumps({"成功":True,"停止":D.write(target,{"試行":115,"成功":True,"市場前":True,"UTC":datetime.now(timezone.utc).isoformat(),"所有ファイルSHA256":own,"依存停止":D.DEPS,"依存コードと手製SHA256":before,"前後不変":True,"主人工":10,"対照数":22,"指定対照":D.C.comparison_specs(),"役割":D.C.ROLES,"期間":D.C.PERIODS,"owner":D.C.OWNERS,"検査ログ":logs,"自然Native/Raw/CSV/11月09本文読取":False,"金融実行/閾値最適化/市場条件変更":False})},ensure_ascii=False))


if __name__=="__main__":main()
