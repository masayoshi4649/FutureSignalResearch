# 115の同入口と三時間軸の実現差

市場前の記述診断器。115金融F1の全70成功・独立入口/金融/P保存成功と、新旧Nativeの明示解禁をRoot要求で認証するまで自然Nativeを読まない。Raw/価格CSV/11月09、金融再生、閾値調整、未参加/退出後の仮想利益は扱わない。旧114/113比較と全停止物は変更せずSHA固定で再用する。

対照は旧114A0→115A0、115A0→T、115A0→TR、T→TR×4費用=16に、同mode/delayのC0→C5（A0/T/TR×D0/D1）6を足した22。Sourceのsession/product/method/side/signal_idを複合出生とし、出生全文、SourceHold、実取得Quote全値/価格/数量を比較する。同実入口／取得変更／前のみ／後のみを分け、共通入口でもP100初期・全返済要求・実fill・保存保護State・終端の同体を仮定しない。実注文IDだけを所有結合後に返済順へ正規化し、金融値を除外しない。

C0/C5では費用床/起動/Stateが異なって当然で、同体を要求しない。全Stateの署名とは別に、費用欄を含まない実request/fillの時刻/Quote/価格/量/理由/取消の執行投影を比較する。初起動/初狭幅/床更新/hitの主要witnessを対応台帳へ残す。両側で成立した実gross/fee/slipをallocationへ結び、純額差=gross差−手数料差−滑り差へ加法照合する。同退出を仮定した仮PnLは作らない。

T→TRの後のみRを別記するが、容量・予約・取消によるTの後のみ/前のみ/数量差も残す。後のみをすべてRだと推測しない。旧114A0の技法は3分、115は三時間軸なので混同せず、役割別の収支は115にだけ付ける。

全A0を含む115全12の成立玉を、G30順/逆、D15順、ADX15≥20、5分Close突破、要求Last保持、前ATR>0、TR上限余裕≥0の8役割ごとに真/既知偽/未知へ分ける。各役割内は全実現純額へ加法照合、役割間は重複する。全Source要求は件数・受付/実取得数だけで分け、未取得へ収支を付けない。条件の別組合せで再取引した成績ではない。値/条件は市場前停止115の保存票だけを利用する。

全70/元54/追加16/11月06、全枝/core/addon/episode/不明を固定保持し、ownerから元意図を推測しない。部分群DDは実約定cash列（新規費用・部分返済・同原行fill順）で、全口座保存点連結時価DDとは別。115全口座時価DDは独立保存の主結果から別列へ結ぶ。費用4条件・同Frameを独立市場機会数へ合算しない。

## 出力と容量

`結果.json` は全70の22対照・R追加・主A0役割・115全口座DDと証拠Refの小要約。440の期間/owner対照、1540場別対照、240成立役割、240全要求の詳細は `全場と役割の詳細.json.gz`、小対応台帳は `実entry対応.json.gz` へ一度だけ保存する。大きいJSONの全件転記を正式レポートへ重ねない。

## 人工とRoot用要求

Actorの手製買売115各12冊＋旧114A0各4冊と、Core6手製の役割入力、四群/退出差/部分返済/境界/破壊・0件・本文前ゲートを確認する。Source.Sourcesのない手製では、明示した人工owner/holdを器具として補う。自然Sourceの実証とは扱わない。

`python -X utf8 検査して停止する.py` で市場前停止する。Rootの後段要求はversion1/trial115/fixedtrue/stagefull70、market_native_read_authorizedtrue、legacy114_read_authorizedtrueと、comparison_stop/condition/completion/saved_result/saved_check/entry_checkの絶対FileRef、owned内の未作成絶対output_dirを持つ。conditionはF1 `94bb656a1607d59039a0c5ec0f06968a4da72463d27c0847606a09fc52fc4693`。

`python -X utf8 診断する.py --fixed <絶対要求path> --sha256 <SHA> --metadata-only` は新旧Native本文を読まない。Rootが実行を固定した同じ引数からmetadata-onlyを除くと全70だけ診断する。旧114Refは各場の115金融完了と独立保存のreference114を照合して使用し、入力/停止の前後不変を確認する。この準備はfirst2/base54/full70の診断実行成功を意味しない。
