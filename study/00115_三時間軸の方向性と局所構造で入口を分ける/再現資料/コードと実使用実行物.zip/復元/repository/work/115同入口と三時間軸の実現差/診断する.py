"""Rootの115全70成功と旧114の明示解禁後だけ、同入口と役割別実現差を記述する。"""
from collections import Counter,defaultdict
from datetime import date,timedelta
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import re

import 実現差の演算 as C
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OWNED=("実現差の演算.py","診断する.py","人工検査.py","検査して停止する.py","README.md")
F1_SHA="94bb656a1607d59039a0c5ec0f06968a4da72463d27c0847606a09fc52fc4693"
DEPS={
 "旧114比較":{"path":str(ROOT/"work/114同入口と要求時技法の実現差/停止.json"),"sha256":"593245ed865763e40dfb48cb9e62980b46c17fb20669f2f9bdaa4ecf8f3ed648"},
 "会計":{"path":str(ROOT/"work/115三時間軸入口の独立会計と保存/会計停止.json"),"sha256":"80fbaf10f60d9f30d17720e13e372d5f25535e0ff47e2cefea9c38887fe1e3d7"},
 "P":{"path":str(ROOT/"work/115三時間軸入口の独立会計と保存/P停止.json"),"sha256":"fb3f87e996829d80c05a2784d041d7f8932cf8e2dfd470cfdb34a65f63eb15c5"},
 "入口":{"path":str(ROOT/"work/115入口判定を独立検算する/停止.json"),"sha256":"d7518d60e73e62b68e025e2bff50adec42dbd111ede7e075e365a8b0076df79e"},
 "Core":{"path":str(ROOT/"work/115三時間軸の複合入口の連続比較/停止.json"),"sha256":"1dca0288b00682c965491bcf0209a45a0bbc4eaf527b0224063db9bcda7f77d8"},
}


def digest(path: Path) -> str:
    """
    機能: 明示コード/小metadata/解禁Nativeの指紋を求める。
    引数: path(Path)。返り値: strはSHA256。Rawは対象外。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()

def reject(value: str) -> None:
    """
    機能: 非有限JSON数値を拒否する。
    引数: value(str)。返り値: None。必ずValueError。
    """
    raise ValueError("非有限値:"+value)

def load(path: Path) -> dict:
    """
    機能: 認証済みJSON/gzipJSONを十進数で読む。
    引数: path(Path)。返り値: dictは保存原値。
    """
    opener=gzip.open if path.suffix==".gz" else open
    with opener(path,"rt",encoding="utf-8-sig") as f:return json.load(f,parse_float=C.Decimal,parse_constant=reject)

def write(path: Path, value: dict) -> dict:
    """
    機能: 新規UTF-8 JSONだけを保存する。
    引数: path(Path)、value(dict)。返り値: dictはFileRef。
    """
    with path.open("x",encoding="utf-8",newline="\n") as f:f.write(json.dumps(value,ensure_ascii=False,indent=2,default=C.serial,allow_nan=False)+"\n")
    return {"path":str(path.resolve()),"sha256":digest(path)}

def reference(ref: dict, before: dict) -> Path:
    """
    機能: 明示絶対参照をSHA認証して前後台帳へ結ぶ。
    引数: ref/before(dict)。返り値: Pathは認証済み位置。
    """
    C.need(isinstance(ref,dict) and isinstance(ref.get("path"),str) and re.fullmatch("[a-f0-9]{64}",ref.get("sha256","")) is not None,"FileRef型")
    p=Path(ref["path"]);C.need(p.is_absolute(),"絶対Ref");p=p.resolve()
    C.need(digest(p)==ref["sha256"] and (str(p) not in before or before[str(p)]==ref["sha256"]),"Ref現物SHA")
    before[str(p)]=ref["sha256"];return p

def same_ref(a: dict, b: dict) -> bool:
    """
    機能: slash/付加bytesによらず解決絶対PathとSHAを比較する。
    引数: a/b(dict)。返り値: boolは同体性。
    """
    return isinstance(a,dict) and isinstance(b,dict) and isinstance(a.get("path"),str) and isinstance(b.get("path"),str) and Path(a["path"]).is_absolute() and Path(b["path"]).is_absolute() and Path(a["path"]).resolve()==Path(b["path"]).resolve() and a.get("sha256")==b.get("sha256")

def sessions() -> list[str]:
    """
    機能: 既使用70場の予定順を固定する。
    引数: なし。返り値: list[str]は11/09を含まない。
    """
    day,result=date(2026,9,21),[]
    while day<=date(2026,11,6):
        if day.weekday()<5:result.extend(f"{day.isoformat()}_{kind}" for kind in ("Day","Night"))
        day+=timedelta(days=1)
    C.need(len(result)==70,"予定70");return result


def dependencies(before: dict) -> None:
    """
    機能: 停止114演算と115金融/P/入口/Coreの実所有codeを認証する。
    引数: before(dict)。返り値: None。市場入力はcodeへ混入させない。
    """
    for ref in DEPS.values():
        stopped=load(reference(ref,before));C.need(stopped["成功"],"依存停止成功")
        for field in ("所有コードSHA256","所有ファイルSHA256"):
            for p,s in stopped.get(field,{}).items():
                C.need(Path(p).suffix not in (".csv",".gz",".jsonl"),"停止codeは市場入力でない");reference({"path":p,"sha256":s},before)
    reference({"path":str(C.PRIOR),"sha256":C.PRIOR_SHA},before)


def prepare(path: Path,sha: str) -> dict:
    """
    機能: Root全70と旧114Nativeの解禁・金融/入口/保存全成功を本文前に認証する。
    引数: path(Path)、sha(str)。返り値: dictは新旧明示Refだけの計画。
    """
    before={};q=load(reference({"path":str(path.resolve()),"sha256":sha},before))
    C.need(q["version"]==1 and q["trial"]==115 and q["fixed"] is True and q["market_native_read_authorized"] is True and q["legacy114_read_authorized"] is True and q["stage"]=="full70","Root115全70と旧114解禁")
    stopped=load(reference(q["comparison_stop"],before));own={str((HERE/n).resolve()):digest(HERE/n) for n in OWNED}
    C.need(stopped["試行"]==115 and stopped["成功"] and stopped["市場前"] and stopped["所有ファイルSHA256"]==own and stopped["依存停止"]==DEPS,"115比較器の同体停止")
    before.update(own);dependencies(before)
    condition=load(reference(q["condition"],before));complete=load(reference(q["completion"],before));saved=load(reference(q["saved_result"],before));checked=load(reference(q["saved_check"],before));entry=load(reference(q["entry_check"],before))
    C.need(q["condition"]["sha256"]==F1_SHA and condition["trial"]==115 and condition["fixed"] and condition["actual_configurations"]==list(C.CONFIGS),"115同F1/全12")
    C.need(complete["trial"]==115 and complete["success"] and complete["stage"]=="full70" and complete["sessions"]==70 and complete["books"]==840 and complete["reused_sessions"]==54 and complete["replayed_sessions"]==16,"115全70金融成功")
    C.need(complete["condition_sha256"]==F1_SHA and complete["unchanged"] and complete["before"] and complete["before"]==complete["after"] and complete["all_reference114_equal"] and complete["reference114_comparisons"]==280 and complete["all_source111_equal"],"115同条件/全対照/不変")
    for v in (saved,checked,entry):
        C.need(v["試行"]==115 and v["成功"] and v["stage"]=="full70" and v["場数"]==70 and v["会計数"]==840 and v["前後不変"] and v["金融条件SHA256"]==F1_SHA and v["金融完了SHA256"]==q["completion"]["sha256"] and v["入力codeSHA256前"] and v["入力codeSHA256前"]==v["入力codeSHA256後"],"115独立全成功/同金融")
    C.need(saved["保存器停止SHA256"]==checked["保存器停止SHA256"]==DEPS["会計"]["sha256"] and saved["独立P停止SHA256"]==DEPS["P"]["sha256"] and entry["入口独立停止SHA256"]==DEPS["入口"]["sha256"],"115金融/P/入口停止")
    C.need(checked["出力SHA256"]["結果.json"]==q["saved_result"]["sha256"] and checked["全残玉予約0"] and checked["全Source111同体"] and checked["旧114全金融比較"]==280 and checked["不一致数"]==0,"115保存後全検算")
    expected=sessions();C.need([r["session"] for r in complete["results"]]==[r["session"] for r in saved["Native参照"]]==[r["session"] for r in entry["場別"]]==expected,"115全70予定順")
    C.need(tuple(saved["主key"])==C.KEYS,"115全12集合")
    for final,ref in zip(complete["results"],saved["Native参照"]):
        C.need(same_ref(final["native"],ref) and same_ref(final["reference114"],ref["reference114"]) and entry["入力codeSHA256前"].get(str(Path(ref["path"]).resolve()))==ref["sha256"],"115同じ新旧金融Ref")
        C.need(final["books"]==12 and final["complete"] and final["A0_equal"] and final["A0_comparisons"]==4 and final["reference114_equal"] and final["reference114_comparisons"]==4 and final["source111_equal"] and final["open_quantity"]==final["pending_quantity"]==0,"115場別全flatと旧対照")
    financial={(r["session"],r["key"]):r for r in saved["場別"]};C.need(len(financial)==840 and set(financial)=={(s,k) for s in expected for k in C.KEYS},"115全840/0件保持")
    output=Path(q["output_dir"]);C.need(output.is_absolute() and output.resolve().is_relative_to(HERE) and not output.exists(),"115所有範囲新規先")
    return {"request":q,"complete":complete,"saved":saved,"financial":financial,"before":before,"output":output.resolve()}


def compressed(path: Path,value: dict) -> dict:
    """
    機能: 大きい期間/owner/全場詳細を一つの決定的gzipJSONへ保存する。
    引数: path(Path)、value(dict)。返り値: dictはRef。正本の全件重複を避ける。
    """
    with path.open("xb") as f:
        with gzip.GzipFile(fileobj=f,mode="wb",filename="",mtime=0) as z:z.write((json.dumps(value,ensure_ascii=False,separators=(",",":"),default=C.serial,allow_nan=False)+"\n").encode("utf-8"))
    return {"path":str(path.resolve()),"sha256":digest(path)}


def execute(plan: dict,root_ref: dict) -> dict:
    """
    機能: 解禁新旧Nativeの22対照と当時役割の実収支だけを記述集計する。
    引数: plan/root_ref(dict)。返り値: dictは小結果Ref。戦略再実行をしない。
    """
    specifications=C.comparison_specs();groups_by_name={name:{g:{s:[] for s in ("前","後")} for g in C.GROUPS} for name,_,_,_ in specifications}
    allrows={k:[] for k in C.KEYS};allrequests={k:[] for k in C.KEYS};scenes=[];matches=[];diff=defaultdict(Counter)
    for final in plan["complete"]["results"]:
        sid=final["session"];native=load(reference(final["native"],plan["before"]));legacy=load(reference(final["reference114"],plan["before"]));a=native["actual"];old=legacy["actual"]
        C.need(native["trial"]==a["trial"]==115 and legacy["trial"]==old["trial"]==114 and a["complete"] and old["complete"] and a["scope"]["session"]["id"]==old["scope"]["session"]["id"]==sid,"115/旧114当場完結")
        C.need(native["source"]==legacy["source"],"新旧Source全文同体")
        index=C.source_index(native);books={}
        for key in C.KEYS:
            book=a["books"][key];C.need(book["totals"]["net_yen"]==plan["financial"][(sid,key)]["net_yen"],"115独立保存額へ一致")
            records=C.records(book,index);books["115"+key]=records;allrows[key].extend(records);allrequests[key].extend(C.gate_rows(book,index))
        for c in (0,5):
            for d in (0,1):books[f"114A0_C{c}_D{d}"]=C.records(old["books"][f"A0_C{c}_D{d}"],index,True)
        for name,left,right,kind in specifications:
            groups,paired,changed,exits=C.pair_records(books[left],books[right])
            for g in C.GROUPS:
                for side in ("前","後"):groups_by_name[name][g][side].extend(groups[g][side])
            scenes.append({"session":sid,"対照":name,"種別":kind,**C.summarize(groups,"全70","全枝"),"入口変更属性":changed,"共通返済":exits});matches.extend({"session":sid,"対照":name,"種別":kind,**v} for v in paired);diff[name].update(changed)
    aggregate=[];role=[];requests=[];main=[];r_extra=[]
    for name,groups in groups_by_name.items():
        for period in C.PERIODS:
            for owner in C.OWNERS:
                summary={"対照":name,"期間":period,"owner":owner,**C.summarize(groups,period,owner)};aggregate.append(summary)
                if period=="全70" and owner=="全枝":main.append(summary)
        if name.startswith("115T→115TR"):
            r_extra.append({"対照":name,"説明":"成立した四群の実現差。後のみRを独立させ、Tの量差や片側も消さない。","四群":C.summarize(groups,"全70","全枝"),"後のみ要求時分類":{cl:C.OLD.statistics([r for r in groups["後のみ"]["後"] if r["technical"]["class"]==cl]) for cl in C.CLASSES}})
    for key in C.KEYS:
        for period in C.PERIODS:
            for owner in C.OWNERS:
                rows=[r for r in allrows[key] if C.selected(r,period,owner)];role.append({"key":key,"期間":period,"owner":owner,**C.role_statistics(rows)})
                requests.append({"key":key,"期間":period,"owner":owner,**C.coverage([r for r in allrequests[key] if C.selected(r,period,owner)])})
        C.need(C.OLD.statistics(allrows[key])["実現円"]==plan["saved"]["集計"][key]["net_yen"],"全実玉と115独立額")
    C.need(len(aggregate)==440 and len(scenes)==1540 and len(role)==len(requests)==240,"115全22対照/全期間owner保持")
    after={p:digest(Path(p)) for p in plan["before"]};C.need(after==plan["before"],"115全code/新旧金融前後不変")
    output=plan["output"];output.mkdir(parents=False,exist_ok=False)
    detail=compressed(output/"全場と役割の詳細.json.gz",{"集計":aggregate,"場別":scenes,"成立玉の要求時役割":role,"全Source要求時技法":requests,"入口差属性":{k:dict(v) for k,v in diff.items()}})
    pairing=compressed(output/"実entry対応.json.gz",{"対応":matches})
    new_dd={key:plan["saved"]["集計"][key]["保存点連結時価DD"] for key in C.KEYS}
    primary_roles=[r for r in role if r["key"]=="A0_C0_D0" and r["期間"]=="全70" and r["owner"]=="全枝"]
    value={"試行":115,"成功":True,"stage":"full70","場数":70,"対照数":22,"場別対照数":1540,"Root要求":root_ref,"金融条件SHA256":F1_SHA,"金融完了SHA256":plan["request"]["completion"]["sha256"],"入口独立結果SHA256":plan["request"]["entry_check"]["sha256"],"全70の22対照":main,"TからTRの実現追加":r_extra,"主A0の成立玉の役割":primary_roles,"115全口座保存点連結時価DD円":new_dd,"全詳細":detail,"対応台帳":{**pairing,"件数":len(matches)},"入力SHA256前":plan["before"],"入力SHA256後":after,"前後不変":True,"定義":["差は後−前。四群は同実入口/取得変更/前のみ/後のみ。旧114A0と115A0/T/TRを混同しない。","共通入口でも全返済/保護State同体を仮定せず別検査する。数量差と後のみの当時分類を残す。","追加滑り6感度は費用Stateの同体を要求しない。実gross差−手数料差−滑り差へ実現差を分解する。","役割ごとの真/既知偽/未知は各役割内の分割。役割同士は重複し合算しない。","Source全要求は件数、成立した実玉だけの費用後収支を記述。新しい役割gateの効果ではない。","部分群は実約定cash列DD、全口座は独立保存点連結時価DDで別尺度。","費用4/同Frameの出生を独立市場機会と数えない。ownerから元意図を推定しない。"],"未実施":{"Raw/CSV/11月09/金融再走/閾値最適化/未取得仮PnL/退出後仮利益/機会損失":0},"市場条件変更":False}
    return write(output/"結果.json",value)


def main() -> None:
    """
    機能: Rootの全70新固定要求だけから新旧の記述診断を開始する。
    引数: CLI fixed/sha256(str)、metadata-only(bool)。返り値: None。
    """
    p=argparse.ArgumentParser();p.add_argument("--fixed",type=Path,required=True);p.add_argument("--sha256",required=True);p.add_argument("--metadata-only",action="store_true");args=p.parse_args();plan=prepare(args.fixed,args.sha256)
    if args.metadata_only:print(json.dumps({"成功":True,"新旧Native本文読取":False},ensure_ascii=False));return
    print(json.dumps({"成功":True,"結果":execute(plan,{"path":str(args.fixed.resolve()),"sha256":args.sha256})},ensure_ascii=False))


if __name__=="__main__":main()
