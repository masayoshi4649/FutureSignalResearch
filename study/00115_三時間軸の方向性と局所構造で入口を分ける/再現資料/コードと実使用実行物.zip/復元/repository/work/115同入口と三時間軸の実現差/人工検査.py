"""新旧Go手製と厳密四群/役割/注文差/本文前ゲートを検査する。"""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest

import 実現差の演算 as C
import 診断する as D

ACTOR_ART={"path":str(D.ROOT/"work/115三時間軸の複合入口を執行する会計/人工_独立判定用/買売人工.json"),"sha256":"24d00eaefdcaf39e1283955aff1a0968eb31d34aa9572bcd870826d3f5403a09"}
CORE_ART={"path":str(D.ROOT/"work/115三時間軸の複合入口の連続比較/人工_入口独立用/Core人工.json"),"sha256":"4ff53c2bed94c512c6c3c39695d9eb57748076bd6bc885da15f7e13d6e0daa9e"}


def source_fixture(books: dict) -> dict:
    """
    機能: 手製bookにだけ明示owner/holdの人工Source索引を補う。
    引数: books(dict)。返り値: dictは人工Native。自然Source再現ではない。
    """
    first=books["A0_C0_D0"];sources={};sid=first["session"]["id"]
    for ordinal,r in enumerate(first["entry_gate"]["records"] or []):
        source=r["source"];m=source["method"];identity=source["signal_id"];src=sources.setdefault(m,{"session":{"id":sid},"method":m,"config":{"product":"NK225mini"},"signals":[],"holds":[]});e={k:source[k] for k in ("method","kind","parent","source_id","quantity_micro")}
        src["signals"].append({"at":source["birth_time"],"quote":source["birth_quote"],"signal":{"id":identity,"action":"new","side":r["request"]["side"],"time":source["birth_time"],"owner":("core","addon","episode")[ordinal%3],"evidence":e}})
        holds={p["source_hold_id"] for b in books.values() for p in b["positions"] if p["source"]["signal_id"]==identity and p["source"]["method"]==m}
        src["holds"].extend({"hold_id":h,"entry_id":identity,"side":r["request"]["side"],**{k:e[k] for k in ("kind","parent","source_id")}} for h in sorted(holds))
    return {"source":{"session":{"id":sid},"sources":sources}}


def fixtures() -> tuple:
    """
    機能: 解禁済みActor/Coreの手製だけを指紋認証して読む。
    引数: なし。返り値: tupleは市場でないActor/Core人工。
    """
    actor=D.load(D.reference(ACTOR_ART,{}));core=D.load(D.reference(CORE_ART,{}));C.need(not actor["市場"] and not actor["FAR自然生成"] and core["人工"] and not core["市場"],"手製限定");return actor,core


def small_row(signal: str,net: int,owner: str="core",sid: str="2026-09-21_Day") -> dict:
    """
    機能: 実現加法・四群・cash-DD用の手計算台帳を作る。
    引数: signal/owner/sid(str)、net(int)。返り値: dictは人工玉。
    """
    roles={n:{"要求":0,"約定":0,"約定枚":0,"返済片純額円":C.ZERO} for n in ("Source","利益保護","起動前失効")};roles["Source"].update({"要求":1,"約定":1,"約定枚":1,"返済片純額円":C.amount(net)})
    return {"base":(sid,"NK225mini","NK225_D164_15",1,signal),"entry":{"Source出生":{"id":signal},"SourceHold":signal,"実entry原行":{"time":1,"index":0,"source_line":1},"実entry価格":1000,"実entry枚":1},"owner":owner,"session":sid,"id":signal,"net":C.amount(net),"qty":1,"cash":[(sid,0,0,1,1,C.amount(net))],"role":roles,"whole_positive":True,"unit_positive":True,"active":False,"invalidated":False,"technical":{"class":"双方偽","input_missing":False,"roles":{k:1 for k in C.ROLES},"values":{},"frames":{"300":"同Frame"},"common":1},"exit":{"初期P100":{"H":100},"終端":{"net":net}},"execution":{"price":1000},"witness":{},"realized":{"gross":C.amount(net),"fee":C.ZERO,"slip":C.ZERO}}


def gate_fixture(base: Path,partial: bool=False) -> dict:
    """
    機能: 自然Nativeを存在させず全70の手製metadataを作る。
    引数: base(Path)、partial(bool)。返り値: dictは人工Root要求Ref。
    """
    base.mkdir();condition={"path":str((D.ROOT/"work/115進行/F1_115金融条件.json").resolve()),"sha256":D.F1_SHA};scenes=[];refs=[];financial=[];fingerprints={}
    for sid in D.sessions():
        n={"path":str((base/(sid+".Native.json.gz")).resolve()),"sha256":"a"*64};old={"path":str((base/(sid+".old114.Native.json.gz")).resolve()),"sha256":"b"*64};refs.append({"session":sid,**n,"reference114":old});fingerprints[n["path"]]=n["sha256"]
        scenes.append({"session":sid,"native":n,"reference114":old,"books":12,"complete":True,"A0_equal":True,"A0_comparisons":4,"reference114_equal":True,"reference114_comparisons":4,"source111_equal":True,"open_quantity":0,"pending_quantity":0});financial.extend({"session":sid,"key":k,"net_yen":0} for k in C.KEYS)
    complete=D.write(base/"完了.json",{"trial":115,"success":True,"stage":"full70","sessions":70,"books":840,"reused_sessions":54,"replayed_sessions":16,"condition_sha256":D.F1_SHA,"unchanged":True,"before":{"手製":"同体"},"after":{"手製":"同体"},"all_reference114_equal":True,"reference114_comparisons":280,"all_source111_equal":True,"results":scenes[:-1] if partial else scenes})
    common={"試行":115,"成功":True,"stage":"full70","場数":70,"会計数":840,"前後不変":True,"金融条件SHA256":D.F1_SHA,"金融完了SHA256":complete["sha256"],"入力codeSHA256前":fingerprints,"入力codeSHA256後":fingerprints}
    saved=D.write(base/"保存.json",{**common,"保存器停止SHA256":D.DEPS["会計"]["sha256"],"独立P停止SHA256":D.DEPS["P"]["sha256"],"主key":list(C.KEYS),"Native参照":refs,"場別":financial})
    check=D.write(base/"検算.json",{**common,"保存器停止SHA256":D.DEPS["会計"]["sha256"],"出力SHA256":{"結果.json":saved["sha256"]},"全残玉予約0":True,"全Source111同体":True,"旧114全金融比較":280,"不一致数":0})
    entry=D.write(base/"入口.json",{**common,"入口独立停止SHA256":D.DEPS["入口"]["sha256"],"場別":[{"session":s} for s in D.sessions()]})
    stop=D.write(base/"停止.json",{"試行":115,"成功":True,"市場前":True,"所有ファイルSHA256":{str((D.HERE/n).resolve()):D.digest(D.HERE/n) for n in D.OWNED},"依存停止":D.DEPS})
    return D.write(base/"要求.json",{"version":1,"trial":115,"fixed":True,"market_native_read_authorized":True,"legacy114_read_authorized":True,"stage":"full70","comparison_stop":stop,"condition":condition,"completion":complete,"saved_result":saved,"saved_check":check,"entry_check":entry,"output_dir":str((D.HERE/"人工未作成先").resolve())})


class ComparisonTests(unittest.TestCase):
    """市場未読の115記述診断人工。"""

    def test_real_artificial_old_new_twenty_two_pairs(self):
        """
        機能: Actor買売新24＋旧8冊で22対照と入口/実執行/費用Stateを分離検査する。
        引数: self(ComparisonTests)。返り値: None。
        """
        actor,_=fixtures();specifications=C.comparison_specs();self.assertEqual(len(specifications),22);self.assertEqual(sum(s[3]=="追加滑り感度" for s in specifications),6)
        for side in ("買い","売り"):
            books=actor[side];index=C.source_index(source_fixture(books));rows={"115"+k:C.records(b,index) for k,b in books.items()};rows.update({"114"+k:C.records(b,index,True) for k,b in actor[side+"_114"].items()})
            for name,left,right,kind in specifications:
                g,_,changed,exits=C.pair_records(rows[left],rows[right]);self.assertFalse(changed);s=C.summarize(g,"全70","全枝");cost=s["実現内訳と執行差"];d=cost["後引く前"]
                self.assertEqual(d["net"],d["gross"]-d["fee"]-d["slip"])
                if kind=="入口比較":self.assertEqual(exits["返済差あり"],0)
                else:
                    self.assertEqual(cost["同入口の費用外執行比較"]["実返済執行差"],0)
                    self.assertEqual(d["gross"],0);self.assertEqual(d["fee"],0)
                    self.assertEqual(d["slip"],sum(r["qty"]*1000 for r in rows[right]))
                    if rows[right]:self.assertGreater(exits["返済差あり"],0)
                if name.startswith("115T→115TR"):
                    self.assertEqual(len(g["後のみ"]["後"]),1);self.assertEqual(g["後のみ"]["後"][0]["technical"]["class"],"R真")

    def test_core_roles_and_full_request_coverage(self):
        """
        機能: Core6ケース全72冊の成立玉を8役割に分け全実現加法を確認する。
        引数: self(ComparisonTests)。返り値: None。
        """
        _,core=fixtures()
        for native in core["results"].values():
            books=native["actual"]["books"];index=C.source_index(source_fixture(books))
            for book in books.values():
                rows=C.records(book,index);stat=C.role_statistics(rows);self.assertEqual(stat["全実玉"]["実現円"],book["totals"]["net_yen"]);cov=C.coverage(C.gate_rows(book,index));self.assertEqual(cov["Source出生"],1)

    def test_four_groups_and_quantity_price_quote_changes(self):
        """
        機能: 同出生の量/価格/原行差を取得変更へ分け四群差72円へ結ぶ。
        引数: self(ComparisonTests)。返り値: None。
        """
        a=[small_row("same",10),small_row("changed",5),small_row("left",-30)];b=[small_row("same",10),small_row("changed",7),small_row("right",40)];b[1]["entry"]["実entry枚"]=2;b[1]["entry"]["実entry価格"]=1005;b[1]["entry"]["実entry原行"]["source_line"]=2
        groups,_,changed,_=C.pair_records(a,b);s=C.summarize(groups,"全70","全枝");self.assertEqual(s["全体"]["実現差円"],72);self.assertEqual(set(changed),{"実entry枚","実entry価格","実entry原行"});self.assertEqual(s["四群"]["取得変更"]["後"]["玉"],1)

    def test_exit_difference_not_assumed_equal(self):
        """
        機能: 共通入口の実退出と費用差を分離し、gross/費用の実現加法を手計算する。
        引数: self(ComparisonTests)。返り値: None。
        """
        a=small_row("same",10);b=small_row("same",7);g,_,_,x=C.pair_records([a],[b]);self.assertEqual(x["返済差あり"],1);self.assertEqual(C.summarize(g,"全70","全枝")["全体"]["実現差円"],-3)
        b["exit"]=deepcopy(a["exit"])
        with self.assertRaises(ValueError):C.pair_records([a],[b])
        a=small_row("cost",100);b=small_row("cost",-20);a["realized"]={"gross":C.Decimal(110),"fee":C.Decimal(10),"slip":C.ZERO};b["realized"]={"gross":C.Decimal(30),"fee":C.Decimal(10),"slip":C.Decimal(40)};b["execution"]["price"]=1010;b["witness"]={"first_activation":{"at":2}}
        g,matched,_,_=C.pair_records([a],[b]);s=C.summarize(g,"全70","全枝")["実現内訳と執行差"]
        self.assertEqual(s["後引く前"],{"gross":-80,"fee":0,"slip":40,"net":-120});self.assertEqual(s["同入口の費用外執行比較"]["実返済執行差"],1);self.assertEqual(s["同入口の費用外執行比較"]["主要保護witness差"],1);self.assertFalse(matched[0]["費用外の実返済執行同体"])

    def test_role_partitions_unknown_false_true_and_shared_frame(self):
        """
        機能: 各役割内三値を全額へ結び、同Frame複数出生と役割重複を区別する。
        引数: self(ComparisonTests)。返り値: None。
        """
        rows=[small_row(str(t),net) for t,net in ((0,-10),(1,3),(2,20))]
        for t,r in enumerate(rows):r["technical"]["roles"]={n:t for n in C.ROLES}
        stat=C.role_statistics(rows);self.assertEqual(stat["全実玉"]["実現円"],13)
        for name in C.ROLES:self.assertEqual([stat["役割別"][name][str(t)]["実現円"] for t in (0,1,2)],[-10,3,20])
        requests=[{"session":"場","frames":{"300":"同じ"},"roles":{n:2 for n in C.ROLES},"class":"R真","input_missing":False,"selected":2,"accepted_quantity":2,"actual_quantity":2} for _ in range(2)];c=C.coverage(requests);self.assertEqual((c["Source出生"],c["実取得"],c["distinct5分公表"]),(2,2,1))

    def test_source_quote_last_quantity_and_role_corruption(self):
        """
        機能: Source出生/Last/実数量/役割票/分母の改変を拒否する。
        引数: self(ComparisonTests)。返り値: None。
        """
        actor,_=fixtures()
        for field in ("source","last","quantity","role","denominator"):
            books=deepcopy(actor["買い"]);index=C.source_index(source_fixture(books));b=books["A0_C0_D0"];r=b["entry_gate"]["records"][0]
            if field=="source":b["positions"][0]["source"]["birth_time"]+=1
            elif field=="last":r["request"]["last"]+=1
            elif field=="quantity":r["actual_quantity"]+=1
            elif field=="role":r["decision"]["common_conditions"][0]["truth"]=0
            else:b["metrics"]["native_new_signals"]+=1
            with self.subTest(field=field),self.assertRaises(ValueError):C.records(b,index)

    def test_partial_cash_and_mtm_dd_scales(self):
        """
        機能: 新規費用と部分返済のcash-DD1038.5円、別時価DD90円を手計算する。
        引数: self(ComparisonTests)。返り値: None。
        """
        r=small_row("partial",-154);s=r["session"];r["cash"]=[(s,0,0,0,1,C.Decimal(-77)),(s,1,1,1,2,C.Decimal("961.5")),(s,2,2,2,3,C.Decimal("-1038.5"))];self.assertEqual(C.OLD.statistics([r])["実約定cash列DD円"],C.Decimal("1038.5"))
        scenes=[{"session":"a","場内時価DD":20,"保存最小時価":-10,"保存最大時価":100,"net_yen":40},{"session":"b","場内時価DD":10,"保存最小時価":-30,"保存最大時価":20,"net_yen":-20}];self.assertEqual(C.mtm_dd(scenes),90)

    def test_period_owner_and_zero_trade(self):
        """
        機能: 固定期間/ownerと0件を保持し、0件を未知の利益へ補完しない。
        引数: self(ComparisonTests)。返り値: None。
        """
        r=small_row("a",100,"core","2026-11-06_Day");self.assertTrue(C.selected(r,"追加16","core"));self.assertFalse(C.selected(r,"元54","core"));self.assertFalse(C.selected(r,"11月06","addon"));self.assertEqual(C.role_statistics([])["全実玉"]["玉"],0);self.assertEqual(C.coverage([])["Source出生"],0)

    def test_full70_gate_before_new_old_native(self):
        """
        機能: 新旧Native不存在のmetadata成功と未解禁/部分完了の拒否を検査する。
        引数: self(ComparisonTests)。返り値: None。
        """
        with tempfile.TemporaryDirectory(dir=D.HERE) as tmp:
            base=Path(tmp);ref=gate_fixture(base/"手製");plan=D.prepare(Path(ref["path"]),ref["sha256"]);self.assertEqual(len(plan["complete"]["results"]),70);self.assertTrue(all(not Path(x["native"]["path"]).exists() and not Path(x["reference114"]["path"]).exists() for x in plan["complete"]["results"]))
            for field in ("market_native_read_authorized","legacy114_read_authorized"):
                q=D.load(Path(ref["path"]));q[field]=False;bad=D.write(base/(field+".json"),q)
                with self.assertRaises(ValueError):D.prepare(Path(bad["path"]),bad["sha256"])
            bad=gate_fixture(base/"未完了",True)
            with self.assertRaises(ValueError):D.prepare(Path(bad["path"]),bad["sha256"])

    def test_composite_key_and_ref_identity(self):
        """
        機能: signal_idだけで結ばず場/商品/手法/方向とRefのSHAも区別する。
        引数: self(ComparisonTests)。返り値: None。
        """
        a=small_row("same",10)
        for i in range(4):
            b=deepcopy(a);key=list(b["base"]);key[i]=-1 if i==3 else "別";b["base"]=tuple(key);g,_,_,_=C.pair_records([a],[b]);self.assertFalse(g["同実入口"]["前"]);self.assertEqual(len(g["後のみ"]["後"]),1)
        ref={"path":str((D.HERE/"README.md").resolve()),"sha256":"a"*64};self.assertTrue(D.same_ref(ref,{**ref,"path":ref["path"].replace("\\","/"),"bytes":1}));self.assertFalse(D.same_ref(ref,{**ref,"sha256":"b"*64}))


if __name__=="__main__":unittest.main(verbosity=2)
