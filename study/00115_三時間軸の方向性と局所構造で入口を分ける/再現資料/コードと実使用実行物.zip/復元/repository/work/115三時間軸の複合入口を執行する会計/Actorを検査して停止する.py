"""115Actorの市場前人工と旧金融非干渉を停止Refへ固定する。"""

import argparse
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OLD = ROOT / 'work/114順行反転取得を執行する会計'
OLD_STOP = OLD / 'Actor停止.json'
OLD_SHA = '2178d1fbe7b980d7f507d6d9c99c6cdef1a8bde8702e4e4a69dbe97b687a9b93'


def sha(path: Path) -> str:
    """機能: 明示コード又は小証拠の全bytes指紋を返す。

    引数: path(Path)は入力ファイル。
    返り値: strは小文字SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(argv: list[str], environment: dict) -> dict:
    """機能: 市場を読まないGo人工・API検査を実行する。

    引数: argv(list[str])、environment(dict)はコマンドと明示環境。
    返り値: dictは終了値と全出力。不成功ではValueError。
    """
    value = subprocess.run(argv, cwd=HERE, env=environment, capture_output=True,
                           text=True, encoding='utf-8', timeout=120)
    result = {'argv': argv, 'exit_code': value.returncode,
              'stdout': value.stdout, 'stderr': value.stderr}
    if value.returncode:
        raise ValueError(json.dumps(result, ensure_ascii=False))
    return result


def authenticate(ref: dict) -> dict:
    """機能: 停止FileRefの成功・市場前・現物SHAを先に認証する。

    引数: ref(dict)は絶対path/sha256の二項目。
    返り値: dictは認証した停止JSON。
    """
    if set(ref) != {'path', 'sha256'} or not Path(ref['path']).is_absolute() or sha(Path(ref['path'])) != ref['sha256']:
        raise ValueError('停止Refの位置又はSHA差')
    value = json.loads(Path(ref['path']).read_bytes())
    if value.get('成功') is not True or value.get('市場前') is not True:
        raise ValueError('依存は市場前成功停止が必要')
    return value


def add_hash_maps(value: dict, dependencies: dict) -> None:
    """機能: 停止が所有する既知のコード指紋mapを衝突なく結ぶ。

    引数: value/dependencies(dict)は停止内容と絶対path→SHA台帳。
    返り値: None。金融Native等の任意Refを再帰読取しない。
    """
    names = ('所有コードSHA256', '所有ファイルSHA256', '依存SHA256', '再用コードSHA256',
             '再用ファイルSHA256', '実依存SHA256', '実Go依存SHA256', 'Go実閉包SHA256',
             '実Go依存コードSHA256', 'GoRootコードSHA256', '全固定コードSHA256')
    for name in names:
        for path, digest in value.get(name, {}).items():
            if not isinstance(digest, str) or re.fullmatch('[a-f0-9]{64}', digest) is None or not Path(path).is_absolute():
                raise ValueError('停止コードmapの形式差:' + name)
            if path in dependencies and dependencies[path] != digest:
                raise ValueError('依存の同位置指紋衝突')
            dependencies[path] = digest


def verify_finance_derivation() -> dict:
    """機能: 会計/保護codeの114からの変更を明示した接続差だけに限定する。

    引数: なし。
    返り値: dictは同体関数群と許可した型名・Scope・拒否説明の差。
    """
    transformations = {
        'actual.go': [('entryGateRuntime114', 'entryGateRuntime115'),
                      ('114取得票が真でないため出生を消費', '115取得票が真でないため出生を消費')],
        'actual_types.go': [('EntryGateAudit114', 'EntryGateAudit115')],
        'continuous.go': [('ContinuousScope114', 'ContinuousScope115'),
                          ('114:元Source通知行の順行/反転取得選別。連続時計、共通P100保護。Source内部・通知は変更しない。',
                           '115:元Source通知行の三時間軸と構造による取得選別。連続時計、共通P100保護。Source内部・通知は変更しない。'),
                          ('114の12', '115の12'), ('114口座', '115口座')],
        'actual_test.go': []}
    for name, replacements in transformations.items():
        expected = (OLD / name).read_text(encoding='utf-8')
        for before, after in replacements:
            expected = expected.replace(before, after)
        if expected != (HERE / name).read_text(encoding='utf-8'):
            raise ValueError('会計/純保護接続の限定差を超えた:' + name)
    return {'同体検査ファイル': list(transformations), '限定置換': transformations,
            'P113数式/取得時ATR/予約/費用/数量/出口の変更': False}


def stop(gate_ref: dict, bank_ref: dict) -> dict:
    """機能: 純入口・公開器停止後に11主人工/vet/buildと所有不変を固定する。

    引数: gate_ref/bank_ref(dict)は新純入口と新三時間軸公開器の停止FileRef。
    返り値: dictはActor停止Ref。実市場へ接続せず既存停止への上書きを拒否する。
    """
    target, output = HERE / 'Actor停止.json', HERE / 'Actor検査'
    if target.exists() or output.exists() or sha(OLD_STOP) != OLD_SHA:
        raise ValueError('停止先は未作成かつ旧114停止不変が必要')
    gate_stop, bank_stop = authenticate(gate_ref), authenticate(bank_ref)
    if gate_stop.get('試行') != 115 or gate_stop.get('依存停止', {}).get('bank115') != bank_ref:
        raise ValueError('純入口115と実公開bank停止の結合差')
    origin = json.loads((HERE / 'Actorの派生元.json').read_bytes())
    if origin['派生元停止'] != {'path': str(OLD_STOP), 'sha256': OLD_SHA}:
        raise ValueError('114派生元停止の結合差')
    own = sorted(HERE.glob('*.go')) + [HERE / name for name in
          ['go.mod', 'go.sum', 'Actor_README.md', 'Actorの派生元.json', Path(__file__).name]]
    before = {str(path): sha(path) for path in own}
    dependencies = {str(OLD_STOP): OLD_SHA, gate_ref['path']: gate_ref['sha256'], bank_ref['path']: bank_ref['sha256']}
    for item in [json.loads(OLD_STOP.read_bytes()), gate_stop, bank_stop]:
        add_hash_maps(item, dependencies)
    for ref in origin['入力']:
        dependencies[ref['path']] = ref['sha256']
    if any(sha(Path(path)) != digest for path, digest in dependencies.items()):
        raise ValueError('依存の停止後SHA差')
    derivation = verify_finance_derivation()
    environment = dict(os.environ, GOWORK='off', CGO_ENABLED='0')
    for key in ['MINIPROTECT_EXPORT_DIR', 'CONTINUOUS113_EXPORT_DIR', 'CONTINUOUS114_EXPORT_DIR', 'CONTINUOUS115_EXPORT_DIR']:
        environment.pop(key, None)
    checks = [run(['go', 'test', '-count=1', '-json', './...'], environment),
              run(['go', 'vet', './...'], environment), run(['go', 'build', './...'], environment)]
    events = [json.loads(line) for line in checks[0]['stdout'].splitlines() if line.startswith('{')]
    tests = [event['Test'] for event in events if event.get('Action') == 'pass' and 'Test' in event]
    if len(tests) != 11:
        raise ValueError('旧6主/新5主の人工件数差:' + str(tests))
    output.mkdir()
    exported = run(['go', 'test', '-count=1', '-run', '^TestExportEntry115$', './...'],
                   dict(environment, CONTINUOUS115_EXPORT_DIR=str(output / '人工')))
    api = run(['go', 'doc', '-all', '.'], environment)
    (output / 'API.txt').write_text(api['stdout'], encoding='utf-8')
    declared = json.loads((output / '人工/宣言設定.json').read_bytes())
    expected = [{'policy': 'P100', 'entry_mode': mode, 'slip_pts': cost, 'delay_seconds': delay}
                for mode in ['A0', 'T', 'TR'] for cost in [0, 5] for delay in [0, 1]]
    if declared != expected or 'func CompareLegacy114(' not in api['stdout'] or 'func (b *ActualBook) SetEntrySnapshot(' not in api['stdout']:
        raise ValueError('115の実12宣言又はAPI差')
    definition_ref = gate_stop['実定義']
    if sha(Path(definition_ref['path'])) != definition_ref['sha256'] or json.loads((output / '人工/入口定義.json').read_bytes()) != json.loads(Path(definition_ref['path']).read_bytes()):
        raise ValueError('Actor実入口宣言と純停止定義の全値差')
    previous = HERE / '人工_独立判定用'
    same = all(sha(previous / name) == sha(output / '人工' / name)
               for name in ['買売人工.json', '入口定義.json', '宣言設定.json'])
    if not same:
        raise ValueError('Rootへ渡した人工から値が変わった')
    if before != {path: sha(Path(path)) for path in before} or any(sha(Path(path)) != digest for path, digest in dependencies.items()):
        raise ValueError('所有/依存の前後差')
    verify_finance_derivation()
    proof = {'試行': 115, '成功': True, '市場前': True, '主人工数': 11, '成功test': tests,
             'test/vet/build': checks, '人工export': exported, '会計の限定派生': derivation,
             '旧114A0四費用対照': '各受理原行と終端の全金融/P100全State。検査済み入口Decision/versionとScope説明だけを分離。',
             'Root突合用人工と同bytes': same, '所有コードSHA256': before, '依存SHA256': dependencies,
             '前後不変': True, '市場/Raw/Native/価格CSV/11月09日本文': False}
    proof_path = output / '人工確認.json'
    proof_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    record = {'試行': 115, '成功': True, '市場前': True, '停止': True,
              'module': 'github.com/masayoshi4649/SessionTradeExecuter/continuousactor115',
              '所有コードSHA256': before, '再用コードSHA256': dependencies, '前後不変': True,
              '純入口停止': gate_ref, '入口公開停止': bank_ref,
              '元Actor停止': {'path': str(OLD_STOP), 'sha256': OLD_SHA},
              '人工確認': {'path': str(proof_path), 'sha256': sha(proof_path)},
              '実API': {'path': str(output / 'API.txt'), 'sha256': sha(output / 'API.txt')},
              '実12宣言': {'path': str(output / '人工/宣言設定.json'), 'sha256': sha(output / '人工/宣言設定.json')},
              '人工出力SHA256': {str(p): sha(p) for p in sorted((output / '人工').glob('*.json'))},
              '市場/Raw/Native/価格CSV/11月09日本文': False, '研究目標達成': False, '採用': False}
    target.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return {'成功': True, '停止': {'path': str(target), 'sha256': sha(target)}}


def main() -> None:
    """機能: 明示した二停止Refで115Actorを市場前停止する。

    引数: CLI gate-stop/gate-sha/bank-stop/bank-sha(str)は絶対位置と期待SHA。
    返り値: None。成功時にActor停止Refだけを表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--gate-stop', type=Path, required=True)
    parser.add_argument('--gate-sha', required=True)
    parser.add_argument('--bank-stop', type=Path, required=True)
    parser.add_argument('--bank-sha', required=True)
    args = parser.parse_args()
    print(json.dumps(stop({'path': str(args.gate_stop.resolve()), 'sha256': args.gate_sha},
                          {'path': str(args.bank_stop.resolve()), 'sha256': args.bank_sha}), ensure_ascii=False))


if __name__ == '__main__':
    main()
