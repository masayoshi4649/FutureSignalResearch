package miniprotect

import (
	"bytes"
	"encoding/json"
	"fmt"
	"reflect"

	legacy "github.com/masayoshi4649/SessionTradeExecuter/continuousactor114"
	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate115"
)

// LegacyComparison115 は入口技法の説明差と実金融同体を別に記録します。
type LegacyComparison115 struct {
	EntryMode             string `json:"entry_mode"`
	Protection            string `json:"protection"`
	StreamScopeChanged    bool   `json:"stream_scope_difference"`
	GateDefinitionChanged bool   `json:"gate_definition_difference"`
	ConfigEqual           bool   `json:"config_equal"`
	GateRecords           int    `json:"gate_records"`
	GateAccountingEqual   bool   `json:"gate_accounting_equal"`
	AllFinancialEqual     bool   `json:"all_financial_equal"`
}

// comparisonJSON115 は全JSONを数値字句を保つ独立値へ写します。
//
// 引数: value(any)は新旧口座の全公開値です。
// 返り値: any/errorは参照共有のない全値又は符号化拒否です。
func comparisonJSON115(value any) (any, error) {
	raw, err := json.Marshal(value)
	if err != nil {
		return nil, err
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	var result any
	err = decoder.Decode(&result)
	return result, err
}

// projectGate115 はA0の新旧技法票だけを外し、受付・実取得の全項目を残します。
//
// 引数: value(map[string]any)、current(bool)は入口監査JSONと115側であることです。
// 返り値: errorは監査の配列型不正です。技法票以外の金融値を加工しません。
func projectGate115(value map[string]any, current bool) error {
	records, ok := value["records"].([]any)
	if !ok {
		return fmt.Errorf("115/114入口監査recordsは非null配列が必要")
	}
	delete(value, "version")
	for _, item := range records {
		row := item.(map[string]any)
		delete(row, "decision")
		if current {
			delete(row["request"].(map[string]any), "last")
		}
	}
	return nil
}

// CompareLegacy114 は115A0と正式114A0を各原行又は完結後に全金融/全Stateで照合します。
//
// 引数: current(ActualResult)、prior(legacy.ActualResult)は同場・費用・遅延の新旧口座です。
// 返り値: LegacyComparison115/errorは検査した入口説明差と金融同体、又は不整合です。
func CompareLegacy114(current ActualResult, prior legacy.ActualResult) (LegacyComparison115, error) {
	proof := LegacyComparison115{EntryMode: current.Config.EntryMode, Protection: current.Config.Policy}
	if current.Config.EntryMode != "A0" || prior.Config.EntryMode != "A0" || current.Config.Policy != "P100" || prior.Config.Policy != "P100" || current.Config.SlipPts != prior.Config.SlipPts || current.Config.DelaySeconds != prior.Config.DelaySeconds || current.StreamScope != ContinuousScope115 || prior.StreamScope != legacy.ContinuousScope114 {
		return proof, fmt.Errorf("115A0と114A0の対照条件差")
	}
	audit, old := current.EntryGate, prior.EntryGate
	if audit == nil || old == nil || audit.Version != 115 || old.Version != 114 || audit.Mode != "A0" || old.Mode != "A0" || len(audit.Records) != current.Metrics.NativeNewSignals || len(old.Records) != prior.Metrics.NativeNewSignals || len(audit.Records) != len(old.Records) {
		return proof, fmt.Errorf("115/114 A0の全出生監査欠落")
	}
	events := []SourceEventTrace{}
	for _, event := range current.SourceEvents {
		if event.Kind == "new_signal" {
			events = append(events, event)
		}
	}
	if len(events) != len(audit.Records) {
		return proof, fmt.Errorf("115A0元newの分母差")
	}
	for i, row := range audit.Records {
		event, previous := events[i], old.Records[i]
		if !row.Allowed || row.Selected != gate.True || !previous.Allowed || previous.Selected != 2 || row.Request.Product != "NK225mini" || row.Request.Method != event.Method || row.Request.SignalID != event.SignalID || row.Request.Side != event.Side || row.Request.At.Time != event.At || row.Request.At.Index != int(event.Quote.Index) || row.Request.At.Line != event.Quote.SourceLine || row.Request.Last != event.Quote.Last || row.Quote != event.Quote || row.AcceptedQuantity != event.ActualAccepted || row.Available != event.Available || row.OrderID != event.OrderID || row.Decision.Version != 115 || row.Decision.Request != row.Request || !row.Decision.Frozen || previous.Decision.Version != 114 || previous.Decision.Request != previous.Request || !previous.Decision.Frozen {
			return proof, fmt.Errorf("115/114 A0全許可・要求原行・受付の結合差")
		}
	}
	leftValue, err := comparisonJSON115(current)
	if err != nil {
		return proof, err
	}
	rightValue, err := comparisonJSON115(prior)
	if err != nil {
		return proof, err
	}
	left, right := leftValue.(map[string]any), rightValue.(map[string]any)
	if !reflect.DeepEqual(left["config"], right["config"]) || left["key"] != right["key"] || current.Key != fmt.Sprintf("A0_C%.0f_D%d", current.Config.SlipPts, current.Config.DelaySeconds) {
		return proof, fmt.Errorf("115/114 A0の本名設定又はkey差")
	}
	proof.ConfigEqual = true
	leftGate, rightGate := left["entry_gate"].(map[string]any), right["entry_gate"].(map[string]any)
	if err = projectGate115(leftGate, true); err != nil {
		return proof, err
	}
	if err = projectGate115(rightGate, false); err != nil {
		return proof, err
	}
	if !reflect.DeepEqual(leftGate, rightGate) {
		return proof, fmt.Errorf("115/114 A0の入口受付・容量・取消・実取得に差")
	}
	proof.GateRecords, proof.GateAccountingEqual, proof.GateDefinitionChanged = len(audit.Records), true, true
	delete(left, "entry_gate")
	delete(right, "entry_gate")
	proof.StreamScopeChanged = left["stream_scope"] != right["stream_scope"]
	left["stream_scope"], right["stream_scope"] = "", ""
	if !reflect.DeepEqual(left, right) {
		return proof, fmt.Errorf("115A0と114A0の全金融/全Stateに差:%s", current.Key)
	}
	proof.AllFinancialEqual = true
	return proof, nil
}
