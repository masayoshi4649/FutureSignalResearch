# 115の三時間軸入口と共通P100会計

停止114 Actorから必要コードを独立コピーした。Source111、元通知の順序、片側mini10枚、38.5円/枚片道、滑り0/5pt・遅延0/1秒、予約/取消/部分返済、厳密な後原行の正常BBO約定、セッション完結を維持する。保護は純P113のP100で、policy・protection113・Definition113と全数式を変更しない。

入口だけを純entrygate115へ接続する。A0/T/TR×4費用の12本名Configを宣言し、候補はentry_mode、policyは共通P100である。研究側の5分/15分新規時計や追加開始静観はない。

## 公開API

- module `github.com/masayoshi4649/SessionTradeExecuter/continuousactor115`、package `miniprotect`。
- `DeclaredContinuousConfigurations() []ActorConfig`：A0/T/TR×C0/C5×D0/D1の12宣言。
- `NewContinuousBook(session Session,contract string,cfg ActorConfig) (*ActualBook,error)`：12宣言だけの実口座。旧人工用NewActualBookはS0/P0/P1のまま。
- `SetEntrySnapshot(snapshot threeframe115.Snapshot,stamp entrygate115.Stamp) error`：当要求原行までの入口専用公表をHistoryへ配送する。Historyへ旧3分reset/frameを渡さない。
- `SetPublication` / `ResetPublication`：旧111の当場cold保護bankからP100だけへ配送する。入口bankのseed・ATR・DMIを保護へ渡さない。
- `OnNativeStep` / `OnNativeForce` / `Snapshot` / `Finish`：旧予約fill→元通知→after_sourceの位相と実金融を維持する。
- `CompareLegacy114(current ActualResult,prior continuousactor114.ActualResult) (LegacyComparison115,error)`：A0四費用を旧114A0へ照合する。各原行の未完結Snapshotも受理する。

Root Coreは入口bankを全Source受理原行でAdvanceObservedする。SourceのDelta.Signalsがある行でSnapshotAtを取り、全12へSetEntrySnapshotを先行してからOnNativeStepを呼ぶ。Snapshot.AsOf/ReplayObservedAtは当原行Time、RecordOrdinalはIndex+1。Snapshotを渡す呼出しのIndexは飛び得る。

## 受付と証拠

全Source new要求原行で一度だけ純Decisionを凍結する。Request.Lastはその元QuoteStamp.Lastであり、fill価格や返済側BBOではない。A0は採用票True、Tは純Trend、TRは純Combinedだけで許可する。T/R/Common/Combined、生の三尺度Snapshot、必要値・不足・否定を保存し、A0の無条件許可で技法票を上書きしない。

`entry_gate`はversion115/mode/records。各recordsはrequest/source/quote/decision/selected/allowedに加え、available/cap_quantity/source_cancelled/accepted_quantity/order_id、actual_quantity/actual_fill_id/actual_position_id/actual_quoteを持つ。容量・元取消・技法拒否・受付・実取得を分ける。拒否も出生を消費し、後の公表・空き・回復で同じ出生を復活させない。同じ公表を別Source出生が参照することは許す。既予約fillのときに新しい入口Snapshotで再ゲートしない。

## 旧114A0対照

同名A0 Config/key/Actor IDを維持する。新旧A0の全許可、Source要求原行、115 Request.Last、受付/容量/取消/実取得を検査する。新旧の入口Decisionと監査versionだけを説明差として分離し、受付/実取得metadataも全値照合する。その後Scopeの版説明だけを分離して、注文・fill・所有・費用・metrics・marks・P100全State/C/M/P/B・返済理由を全値照合する。金融IDやP100値を正規化して差を隠さない。

`LegacyComparison115`はentry_mode/protection/stream_scope_difference/gate_definition_difference/config_equal/gate_records/gate_accounting_equal/all_financial_equalを保存する。新旧技法の有効性が同じという証明ではなく、A0の金融非干渉対照である。

## 市場前の人工と範囲

旧6主人工に、新5主を追加する。手製5分足の前史から数値seedを作り、当場T/R・要求時Last否定・cold未知、買売鏡像・費用間同票、取得後欠足でも既予約fillを継続、未来snapshot・参照分離、金融/PState/Last/容量/実取得の破壊拒否、同Frame複数出生・上限・元取消・拒否消費を確認する。A0四費用は旧114へ各受理原行と終端で全金融/全Stateを照合する。手製Source通知であり、自然FAR生成や実市場の検証ではない。

純入口115と公開bank115の成功停止Refを明示してからActor停止を作る。停止helperは自己所有・旧Actor・純P/入口/公開器の参照SHAを前後照合し、test/vet/buildと実API/宣言/人工出力を記録する。旧固定ファイル・Raw・Native・価格CSV・11/09を読まない。研究目標達成/採用はfalse。
