"""115正式保存器を人工だけで検査し、依存停止と所有前後不変を記録する。"""

import argparse
from pathlib import Path
import json
import re
import subprocess
import sys

import 正式保存する as F


def stop(output: Path) -> dict:
    """機能: 新正式保存器の人工と旧114/新115依存の不変を認証して停止する。

    引数: output(Path)は未作成の絶対停止先。
    返り値: dictは停止/分類停止Ref。実市場結果・Native・CSV・Rawは読まない。
    """
    F.need(sys.flags.optimize == 0 and output.is_absolute() and not output.exists(), '115正式停止の通常Python/新規絶対先')
    owned = {str(F.OWN / n): F.sha(F.OWN / n) for n in ('正式保存する.py', '人工検査.py', '検査して停止する.py', 'コードを分類する.py', 'README.md')}
    reused = {str(F.PREVIOUS_PATH): F.PREVIOUS_SHA, str(F.C.LEGACY_PATH): F.C.LEGACY_SHA,
              str(F.C.ZIP_PATH): F.C.ZIP_SHA,
              str(F.ROOT / 'work/109再現コードの準備/ZIPを正式保存する.py'): 'cb263d54b70bbb6ca94d227736fce98748a623d014924b960660039d8f98eae2',
              str(F.ROOT / 'work/111正式保存への接続/人工検査.py'): 'ff8f68906fa8cabdc97a371095025bb7c2da95bc8fcc08365ba8def87bbcd78b'}
    fixed = {'path': str(F.ROOT / 'work/115進行/F1_115金融条件.json'), 'sha256': '94bb656a1607d59039a0c5ec0f06968a4da72463d27c0847606a09fc52fc4693'}
    condition = F.read(fixed, reused)
    F.need(condition['trial'] == 115 and condition['fixed'] is True, 'Root金融F1固定')
    save_request_path = F.ROOT / 'work/115進行/first2_独立保存要求.json'
    save_request = F.read(F.ref(save_request_path), reused)
    F.need(save_request['trial'] == 115 and save_request['fixed'] is True and save_request['condition'] == fixed, 'Root first2要求の停止metadataだけ使用')
    dependencies = {**condition['dependency_stops'], 'core': condition['runtime_stop'],
                    '独立会計': save_request['code_stop'], '独立P': save_request['P_stop'], '独立入口': save_request['entry_stop'],
                    '独立価格足DMI': {'path': str(F.ROOT / 'work/115価格足とDMIを独立検査する/検査_停止版/停止.json'), 'sha256': '94c81454d80cb4a5d590b018a94b7cdb3128a202025e9fa4b6ddd25390fc7c01'},
                    'CSV正益経験分母': {'path': str(F.ROOT / 'work/115損益CSVの出力_正益経験分母/人工_停止版/停止.json'), 'sha256': '20d9db6467a3baefca459fe2dca666c006f3afee604d50edd37da9ef46b79ff8'},
                    '旧114正式保存': {'path': str(F.ROOT / 'work/114正式保存への接続_入口票の零項目/検査_停止版/停止.json'), 'sha256': '4b186c4725e3082d3bc7eeea73728504951afd38ace58125e8a1e887f5b637b6'}}
    for reference in dependencies.values():
        data = F.read(reference, reused)
        F.need(data['成功'] is True, '依存停止成功')
        for field in ('所有コードSHA256', '所有ファイルSHA256', '再用ファイルSHA256', '旧版code前後不変'):
            for path, digest in data.get(field, {}).items():
                absolute = str((Path(path) if Path(path).is_absolute() else F.ROOT / path).resolve())
                F.need(absolute not in reused or reused[absolute] == digest, '依存所有の同位置SHA衝突なし')
                reused[absolute] = digest
    F.need(all(F.sha(Path(path)) == digest for path, digest in reused.items()), '既停止/再用コード現物SHA')

    # ----------------------------------------
    output.mkdir(parents=True, exist_ok=False)
    tested = subprocess.run([sys.executable, '-X', 'utf8', str(F.OWN / '人工検査.py')], cwd=F.OWN,
                            capture_output=True, text=True, encoding='utf-8', timeout=120, check=False)
    text = tested.stdout + tested.stderr
    log = output / '人工検査.txt'
    with log.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(text)
    match = re.search(r'^Ran ([0-9]+) tests? in ', text, re.MULTILINE)
    F.need(tested.returncode == 0 and match is not None and int(match[1]) == 9 and text.rstrip().endswith('OK'), '115正式保存の9主人工成功')
    before = {**reused, **owned}
    after = {path: F.sha(Path(path)) for path in before}
    F.need(before == after, '新所有/旧114/115依存の前後不変')
    proof = output / '人工確認.json'
    F.write_json(proof, {'試行': 115, '成功': True, '市場前': True, '主人工': int(match[1]),
                        '器具': '停止111の手製70場/空約定840。仮Native/旧ZIP/CSVと価格足DMI成功metadataだけ。',
                        '全Native70/Viewer840': True, '既存文書4点不変': True, 'Goコンパイラ別環境参照': True,
                        '旧ZIP全SHAと選択entrySHA/CRC': True, '新ZIP集合SHA/CRC/安全名': True,
                        '元54認証再用と追加16区別': True, 'P113共通保護': True, '入口独立70/840と会計票結合': True,
                        'Counter零項目同値/非零差拒否': True, '価格足DMI全70必須/first2代用拒否': True, 'CSV二点/全セル再読必須': True,
                        '旧成果物/GoRoot/CSVの本文複写なし': True, '前後不変': True, 'ログ': F.ref(log),
                        '実市場結果/Native/Raw/価格CSV/実CSV/11月09日本文読取': False})
    classifier = output / 'コード分類の停止.json'
    F.write_json(classifier, {'試行': 115, '成功': True, '市場前': True, '所有コードSHA256': {str(F.CLASSIFIER_PATH): F.CLASSIFIER_SHA},
                             '人工確認': F.ref(proof), '前後不変': True, '市場/Raw/CSV本文読取': False, '採用': False, '研究目標達成': False})
    path = output / '停止.json'
    F.write_json(path, {'試行': 115, '成功': True, '停止': True, '市場前': True, 'コード分類停止': F.ref(classifier),
                       '所有ファイルSHA256': owned, '再用ファイルSHA256': reused, '依存停止': dependencies,
                       'Root金融条件': fixed, '人工確認': F.ref(proof), '前SHA256': before, '後SHA256': after, '前後不変': True,
                       '実市場結果/Native/Raw/価格CSV/実CSV/11月09日本文読取': False, '研究目標達成': False, '採用': False})
    return {'成功': True, '停止': F.ref(path), 'コード分類停止': F.ref(classifier)}


def main() -> None:
    """機能: 新規先へ115正式保存の市場前停止を生成する。

    引数: CLI output(str)は新規先。
    返り値: None。停止Refのみ標準出力へ表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(stop(args.output.resolve()), ensure_ascii=False))


if __name__ == '__main__':
    main()
