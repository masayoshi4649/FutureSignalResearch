"""手製70場と既正式参照だけで115正式保存の境界を検査する。"""

from copy import deepcopy
import importlib.util
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import zipfile

import 正式保存する as F


FIXTURE_PATH = F.ROOT / 'work/111正式保存への接続/人工検査.py'
FIXTURE_SHA = 'ff8f68906fa8cabdc97a371095025bb7c2da95bc8fcc08365ba8def87bbcd78b'


def make_fixture(base: Path) -> dict:
    """機能: 停止111の手製70場を115本名政策・旧114対照schemaへ適応する。

    引数: base(Path)はrepo内の人工一時先。
    返り値: dictはRoot仮要求・仮正式先・人工参照。実市場を使わない。
    """
    F.need(F.sha(FIXTURE_PATH) == FIXTURE_SHA, '停止111人工器具のSHA')
    spec = importlib.util.spec_from_file_location('115が使う停止111人工器具', FIXTURE_PATH)
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    old.F = SimpleNamespace(ROOT=F.ROOT, OWN=F.OWN, sha=F.sha, ref=F.ref, write_json=F.write_json,
                            CONFIGS=F.CONFIGS, KEYS=F.KEYS, sessions=F.C.sessions)
    fixture = old.make_fixture(base)
    source, request = fixture['source'], fixture['request']
    refs = request['refs']

    def put(name: str, value: dict) -> dict:
        """機能: 人工JSONを新規保存して指紋を返す。

        引数: name(str)、value(dict)は名称と人工内容。
        返り値: dictはFileRef。
        """
        path = source / name
        F.write_json(path, value)
        return F.ref(path)

    standard, custom = fixture['standard'], fixture['custom']
    standard_source = standard.parent / 'src/標準.go'
    standard_source.parent.mkdir()
    standard_source.write_bytes(standard.read_bytes())
    fixture['values']['condition']['code_sha256'][str(standard_source)] = fixture['values']['condition']['code_sha256'].pop(str(standard))
    standard = standard_source
    fixture['standard'] = standard
    refs['core_stop'] = put('core_stop115.json', {'成功': True, 'GoRootコードSHA256': {str(standard): F.sha(standard)}, '所有ファイルSHA256': {}})
    refs['save_stop'] = put('save_stop115.json', {'成功': True, 'Actor停止': refs['actor_stop'], 'P停止': refs['P_stop'], '所有ファイルSHA256': {}})
    refs['code_material_stop'] = put('code_material_stop115.json', {'試行': 115, '成功': True, '前後不変': True, '所有コードSHA256': {str(F.CLASSIFIER_PATH): F.CLASSIFIER_SHA}})
    refs['entry_gate_stop'] = put('entry_gate_stop115.json', {'成功': True})
    refs['entry_stop'] = put('entry_stop115.json', {'成功': True})
    refs['entry_chart_stop'] = put('entry_chart_stop115.json', {'成功': True})
    refs['entry_input_stop'] = put('entry_input_stop115.json', {'成功': True})
    refs['price_stop'] = put('price_stop115.json', {'試行': 115, '成功': True, '停止': True, '市場前': True, 'Go公開器停止': refs['entry_chart_stop']})
    csv_legacy_stop = put('CSV旧停止.json', {'試行': 115, '成功': True, '所有ファイルSHA256': {}})
    csv_marker = put('CSV操作marker.json', {'既発行': True, '再発行': False})
    refs['csv_stop'] = put('CSV正益経験分母版停止.json', {'試行': 115, '成功': True, '市場前': True, '前後不変': True,
                                                   '旧版code前後不変': {str(custom): F.sha(custom)},
                                                   '派生元115停止': csv_legacy_stop, '操作marker': {**csv_marker, '新規発行回数': 0}})
    refs['formal_stop'] = put('formal_stop115.json', {'成功': True, '市場前': True, '所有ファイルSHA256': {str(F.OWN / n): F.sha(F.OWN / n) for n in ('正式保存する.py', '人工検査.py', '検査して停止する.py', 'コードを分類する.py', 'README.md')}})
    refs['save_stop'] = put('save_stop入口115.json', {'成功': True, 'Actor停止': refs['actor_stop'], 'P停止': refs['P_stop'], '入口独立停止': refs['entry_stop']})
    definitions = []
    definitions.append({'version': 113, 'policy': 'P100', 'enabled': True,
                        'threshold_points': 100, 'normal_width_minimum': 200, 'atr_multiplier': 2,
                        'warning_formula': 'M AND P', 'technical_narrowing': True,
                        'entry_invalidation_enabled': False})
    condition = deepcopy(fixture['values']['condition'])
    condition.pop('oracle_executable')
    condition.update(trial=115, runtime_stop=refs['core_stop'], protection_definition=definitions[0],
                     reference114={'condition': {'人工': True}, 'market': {'人工': True}, 'native_catalog': {'人工': True}})
    condition['dependency_stops']['entry_gate'] = refs['entry_gate_stop']
    condition['dependency_stops']['entry_chart'] = refs['entry_chart_stop']
    condition['dependency_stops']['entry_input'] = refs['entry_input_stop']
    condition['entry_input_model'] = 'prior_csv_publications_through_scheduled_end_current_raw_delivery115'
    condition['entry_gate_declaration'] = put('入口定義.json', {'version':115})
    condition['entry_chart_declaration'] = put('入口公開定義.json', {'version':115})
    refs['condition'] = put('condition115.json', condition)
    market = deepcopy(fixture['values']['market'])
    market.update(trial=115, books=840, condition_sha256=refs['condition']['sha256'], reference114_comparisons=280,
                  all_reference114_equal=True, all_source111_equal=True)
    prior_native = source / '仮正式114Native'
    prior_native.mkdir()
    for row in market['results']:
        path = prior_native / (row['session'] + '.Native.json.gz')
        path.write_bytes(('複写しない旧114参照' + row['session']).encode())
        row.pop('S0_comparisons'); row.pop('S0_equal')
        row.update(books=12, A0_comparisons=4, A0_equal=True, reference114=F.ref(path), reference114_comparisons=4, reference114_equal=True, source111_equal=True)
    prior54 = {**deepcopy(market), 'stage': 'base54', 'sessions': 54, 'books': 648,
               'reused_sessions': 0, 'replayed_sessions': 54, 'results': market['results'][:54]}
    prior54.pop('prior54')
    market['prior54'] = put('元54成功115.json', prior54)
    refs['market'] = put('market115.json', market)
    result = deepcopy(fixture['values']['result'])
    result.update(試行=115, 会計数=840, Viewer形式資源=840, 独立入口停止SHA256=refs['entry_stop']['sha256'], 金融条件SHA256=refs['condition']['sha256'], 金融完了SHA256=refs['market']['sha256'],
                  Actor停止SHA256=refs['actor_stop']['sha256'], 保存器停止SHA256=refs['save_stop']['sha256'], 独立P停止SHA256=refs['P_stop']['sha256'],
                  旧114対照=[{'session': r['session'], 'comparisons': 4, 'all_financial_equal': True} for r in market['results']],
                  保護定義={r['policy']: r for r in definitions})
    counts = {'source_requests': 0, 'allowed': 0}
    result['入口票集計'] = {key: {} for key in F.KEYS}
    for row in result['場別']:
        row['入口票検査'] = {'成功': True, 'counts': counts.copy()}
    for row in [*result['場別'], *result['集計'].values()]:
        row.update({metric: 0 for metric in F.METRICS})
        row['net_yen'] = 0
        row['注文別'] = {name: {'要求': 0, '要求枚': 0, '約定': 0, '約定枚': 0, '返済片純額': 0} for name in ('Source', '保護', '起動前失効')}
    for row, completed in zip(result['Native参照'], market['results']):
        row['reference114'] = completed['reference114']
    saved_dir = Path(refs['result']['path']).parent
    catalog_path = saved_dir / '一覧.resources.json'
    catalog = F.read(F.ref(catalog_path), {})
    output_sha = {}
    for resource in catalog['resources']:
        old_name = resource['pnl_path']
        new_name = old_name.replace('111_', '115_', 1)
        (saved_dir / old_name).rename(saved_dir / new_name)
        resource['id'] = resource['id'].replace('111_', '115_', 1)
        resource['pnl_path'] = new_name
        output_sha[new_name] = F.sha(saved_dir / new_name)
    catalog_path.unlink()
    F.write_json(catalog_path, catalog)
    output_sha[catalog_path.name] = F.sha(catalog_path)
    (saved_dir / '結果.json').unlink()
    F.write_json(saved_dir / '結果.json', result)
    refs['result'] = F.ref(saved_dir / '結果.json')
    output_sha['結果.json'] = refs['result']['sha256']
    saved = deepcopy(fixture['values']['saved_check'])
    saved.update(試行=115, stage='full70', 会計数=840, 資源=840, A0全金融比較=280, Actor停止SHA256=refs['actor_stop']['sha256'], 保存器停止SHA256=refs['save_stop']['sha256'], 独立P停止SHA256=refs['P_stop']['sha256'], 独立入口停止SHA256=refs['entry_stop']['sha256'], 金融条件SHA256=refs['condition']['sha256'], 金融完了SHA256=refs['market']['sha256'],
                 旧114全金融比較=280, 全Source111同体=True, 出力SHA256=output_sha)
    check_path = saved_dir / '115保存会計の確認.json'
    F.write_json(check_path, saved)
    refs['saved_check'] = F.ref(check_path)
    entry = {'試行':115,'成功':True,'stage':'full70','場数':70,'会計数':840,'金融条件SHA256':refs['condition']['sha256'],'金融完了SHA256':refs['market']['sha256'],'入口独立停止SHA256':refs['entry_stop']['sha256'],'前後不変':True,'入力codeSHA256前':{},'入力codeSHA256後':{},'金融損益再計算':False,'Raw/価格CSV/11月09本文/市場再走':False,'場別':[{'session':r['session'],'成功':True,'会計数':12,'手製Source器具':False,'費用間とモード間のDecision同体':True,'book':{key:{'成功':True,'counts':counts.copy()} for key in F.KEYS}} for r in market['results']]}
    refs['entry_check'] = put('入口独立全70成功.json', entry)
    price_scenes = [{'session': r['session'], 'native': r['native'], 'csv': {'path': '人工参照だけ。本文を作らない', 'sha256': 'a' * 64, 'bytes': 1},
                     'prefix': []} for r in market['results']]
    price_request = {'version': 1, 'trial': 115, 'fixed': True, 'stage': 'full70', 'condition': refs['condition'],
                     'market': refs['market'], 'manifest': condition['manifest'], 'code_stop': refs['price_stop'],
                     'bank_stop': refs['entry_chart_stop'], 'market_native_read_authorized': True, 'csv_read_authorized': True,
                     'raw_read_authorized': False, 'holdout_read_authorized': False, 'scenes': price_scenes}
    refs['price_request'] = put('価格足DMI要求.json', price_request)
    price = {'試行': 115, '成功': True, 'stage': 'full70', '場数': 70, 'Root要求': refs['price_request'],
             '金融条件SHA256': refs['condition']['sha256'], '金融完了SHA256': refs['market']['sha256'],
             '独立停止SHA256': refs['price_stop']['sha256'], '前後不変': True, '入力SHA256前': {}, '入力SHA256後': {},
             'CSV個別解釈数': 70, '金融損益再計算': False, 'Raw/11月09本文読取': False,
             '場別': [{'session': r['session'], '場': r['session'], '成功': True, 'native': r['native'], 'csv': r['csv'], 'prefix数': i,
                       '比較': {'公表': 1, 'OHLC値': 4, '子足': 1, 'DMI現前値と計数': 10}} for i, r in enumerate(price_scenes)]}
    refs['price_check'] = put('価格足DMI全70成功.json', price)
    # ----------------------------------------
    # 実際の旧ZIPは開かず、同byte旧コードと別path参照を人工ZIPで検査します。
    legacy_root = source / '既正式114'
    (legacy_root / '再現資料').mkdir(parents=True)
    prior_sources = [custom, F.PREVIOUS_PATH, F.C.LEGACY_PATH, F.C.ZIP_PATH,
                     F.ROOT / 'work/109再現コードの準備/ZIPを正式保存する.py']
    legacy_rows = [{'original_path': str(path), 'sha256': F.sha(path), 'bytes': path.stat().st_size,
                    'kind': 'コードと宣言', 'restore': {'root': 'repository', 'relative': path.relative_to(F.ROOT).as_posix()},
                    'location': {'kind': 'このZIP', 'entry': '旧/' + str(i) + '/' + path.name}} for i, path in enumerate(prior_sources)]
    old_zip = legacy_root / '再現資料/コード.zip'
    F.Z.write_zip(old_zip, legacy_rows)
    old_index = legacy_root / '再現資料/索引.json'
    F.write_json(old_index, {'試行': 113, '成功': True, 'ZIP': F.ref(old_zip), 'entries': legacy_rows})
    old_index_ref = F.ref(old_index)
    code = {**condition['code_sha256'], condition['executable']['path']: condition['executable']['sha256']}
    rows = F.K.classify(code, {str(standard): F.sha(standard)}, [(F.read(old_index_ref, {}), old_index_ref)])
    for row in rows:
        if row['kind'] != 'GoRoot環境参照':
            row['restore'] = F.K.restore_target(row['original_path'], request['restore_roots'])
        if row['kind'] == '新規同梱予定':
            row['location']['entry'] = '復元/' + row['restore']['root'] + '/' + row['restore']['relative']
    material = {'試行': 115, '成功': True, '正式保存ではなく準備': True, 'Root金融条件': refs['condition'],
                '停止': refs['core_stop'], '実行物': condition['executable'], '前後不変': True, '前SHA256': code, '後SHA256': code,
                'restore_roots': request['restore_roots'], 'go_environment': request['go_environment'], '旧正式索引': [old_index_ref], 'entries': rows}
    refs['code_material'] = put('金融コード素材115.json', material)
    outputs = source / 'outputs'
    outputs.mkdir()
    csv_refs = {}
    for name in ('候補別集計.csv', '全セッション.csv'):
        path = outputs / name
        path.write_bytes(b'not-real-csv\n')
        csv_refs[name] = F.ref(path)
    hashes = {refs['result']['path']: refs['result']['sha256'], **{r['path']: r['sha256'] for r in csv_refs.values()}}
    refs['csv_check'] = put('Root仮CSV再読成功.json', {'成功': True, '試行': 115, '場別行数': 840, '候補数': 12, '数値比較数': 1,
                                                  '全場累計再計算': True, '未定義比率は空欄': True, '前後不変': True,
                                                  '入力SHA256': hashes, '後SHA256': hashes, 'Raw読取': 0, '金融再実行': False})
    alias = source / '同bytesの別path.go'
    alias.write_bytes(custom.read_bytes())
    request.update(trial=115, refs={name: refs[name] for name in F.REQUIRED | {'csv_check'}},
                   csv_refs=csv_refs, code_refs=[{'ref': F.ref(alias), 'role': '別path同bytes人工'}], extra_refs=[])
    request_ref = put('正式要求115.json', request)
    return {**fixture, 'ref': request_ref, 'request': request, 'outputs': outputs, 'legacy_root': legacy_root,
            'alias': alias, 'values': {'condition': condition, 'market': market, 'result': result, 'saved_check': saved}}


class Formal115Tests(unittest.TestCase):
    """115正式保存と旧資料参照・新旧指紋の拒否境界を確認する。"""

    def setUp(self) -> None:
        """機能: repo内に人工だけの一時領域を用意する。

        引数: self(Formal115Tests)は検査器。
        返り値: None。
        """
        self.tmp = tempfile.TemporaryDirectory(prefix='115正式人工_', dir=F.OWN)
        self.root = Path(self.tmp.name)

    def tearDown(self) -> None:
        """機能: 一時管理により人工領域だけを片付ける。

        引数: self(Formal115Tests)は検査器。
        返り値: None。
        """
        self.tmp.cleanup()

    def test_full_save_references_and_new_targets(self) -> None:
        """機能: 70Native/840Viewerを同bytes保存し旧ZIP・標準Go・CSV非複写を確認する。

        引数: self(Formal115Tests)は検査器。
        返り値: None。旧別path復元も検査する。
        """
        fixture = make_fixture(self.root / '成功')
        fixture['trial'].mkdir()
        retained = {}
        for name in ('README.md', '設定と結果.md', '設計候補.md', '根拠/市場前原文/設計.md'):
            path = fixture['trial'] / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text('既存文書は変更しない\n', encoding='utf-8')
            retained[str(path)] = F.sha(path)
        with patch.object(F, 'TRIAL', fixture['trial']), patch.object(F, 'OUTPUTS', fixture['outputs']):
            saved = F.execute(fixture['ref'])
            proof, index = F.read(saved['確認'], {}), F.read(saved['索引'], {})
            self.assertEqual(proof['Native数'], 70)
            self.assertEqual(len(list((fixture['trial'] / '成果物').glob('*.trades.jsonl'))), 840)
            self.assertEqual(len(F.read(saved['Native台帳'], {})['Native']), 70)
            alias = next(r for r in index['entries'] if r['original_path'] == str(fixture['alias']))
            self.assertEqual(alias['location']['kind'], '既正式ZIP参照')
            self.assertEqual(alias['restore']['relative'], fixture['alias'].relative_to(F.ROOT).as_posix())
            self.assertGreaterEqual(index['既正式参照数'], 6)
            self.assertTrue(proof['前後不変'])
            self.assertEqual({path: F.sha(Path(path)) for path in retained}, retained)
            self.assertFalse(list(fixture['trial'].rglob('*.csv')))
            self.assertEqual(len(list(fixture['trial'].rglob('*.zip'))), 1)
            with zipfile.ZipFile(saved['ZIP']['path']) as archive:
                self.assertIsNone(archive.testzip())
                self.assertTrue(all('仮GoRoot' not in name for name in archive.namelist()))
            with self.assertRaises(ValueError):
                F.execute(fixture['ref'])

    def test_sha_changes_rejected_before_write(self) -> None:
        """機能: Native・唯一CSV・旧ZIPの現物改変を正式書込み前に拒否する。

        引数: self(Formal115Tests)は検査器。
        返り値: None。
        """
        for kind in ('Native', 'CSV', '旧ZIP'):
            fixture = make_fixture(self.root / kind)
            if kind == 'Native':
                path = Path(fixture['values']['market']['results'][0]['native']['path'])
            elif kind == 'CSV':
                path = Path(fixture['request']['csv_refs']['全セッション.csv']['path'])
            else:
                path = fixture['legacy_root'] / '再現資料/コード.zip'
            path.write_bytes(b'changed')
            with patch.object(F, 'TRIAL', fixture['trial']), patch.object(F, 'OUTPUTS', fixture['outputs']), self.assertRaises(ValueError):
                F.prepare(fixture['ref'])
            self.assertFalse(fixture['trial'].exists())

    def test_unsafe_or_missing_success_rejected(self) -> None:
        """機能: 不成功・旧4不足・Source不一致・失効指標混同・危険相対先を拒否する。

        引数: self(Formal115Tests)は検査器。
        返り値: None。
        """
        fixture = make_fixture(self.root / '拒否')
        values = {n: F.read(r, {}) for n, r in fixture['request']['refs'].items()}
        for kind in ('failed', 'old4', 'source', 'metric', 'group', 'entry', 'entry_stop', 'counts', 'aggregate'):
            copy = deepcopy(values)
            if kind == 'failed':
                copy['market']['success'] = False
            elif kind == 'old4':
                copy['market']['reference114_comparisons'] -= 1
            elif kind == 'source':
                copy['market']['all_source111_equal'] = False
            elif kind == 'metric':
                copy['result']['場別'][0]['entry_invalidation_exit_fills'] = 1
            elif kind == 'group':
                copy['result']['場別'][0]['注文別'].pop('起動前失効')
            elif kind == 'entry':
                copy['entry_check']['成功'] = False
            elif kind == 'entry_stop':
                copy['entry_check']['入口独立停止SHA256'] = '0' * 64
            elif kind == 'counts':
                copy['entry_check']['場別'][0]['book'][F.KEYS[0]]['counts']['allowed'] = 1
            else:
                copy['result']['入口票集計'][F.KEYS[0]]['allowed'] = 1
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                F.validate(copy, fixture['request'])
        bad = deepcopy(fixture['request'])
        bad['extra_refs'] = [{'ref': bad['refs']['condition'], 'target': '診断/../../外部.json', 'role': '拒否人工'}]
        path = fixture['source'] / '危険先.json'
        F.write_json(path, bad)
        with patch.object(F, 'TRIAL', fixture['trial']), self.assertRaises(ValueError):
            F.prepare(F.ref(path))
        self.assertFalse(fixture['trial'].exists())

    def test_flattened_alias_keeps_origin_and_restore(self) -> None:
        """機能: 中継113の由来pathが直接111索引に無いflattenを正しく認証する。

        引数: self(Formal115Tests)は検査器。
        返り値: None。旧索引由来と実entryを別々に認証する。
        """
        fixture = make_fixture(self.root / '中継索引')
        req = deepcopy(fixture['request'])
        material = F.read(req['refs']['code_material'], {})
        prior_ref = material['旧正式索引'][0]
        prior = F.read(prior_ref, {})
        source_row = next(r for r in prior['entries'] if r['original_path'] == str(fixture['custom']))
        alias_row = deepcopy(source_row)
        alias_row['original_path'] = str(fixture['alias'])
        alias_row['location'] = {'kind': '既正式111のZIP', 'archive': prior['ZIP'], 'index': prior_ref,
                                 'entry': source_row['location']['entry'], 'legacy_original_path': source_row['original_path']}
        bridge_path = fixture['source'] / '中継113索引.json'
        F.write_json(bridge_path, {'試行': 113, '成功': True, 'ZIP': prior['ZIP'], 'entries': [alias_row]})
        material['旧正式索引'].append(F.ref(bridge_path))
        path = fixture['source'] / '中継素材.json'
        F.write_json(path, material)
        req['refs']['code_material'] = F.ref(path)
        path = fixture['source'] / '中継要求.json'
        F.write_json(path, req)
        with patch.object(F, 'TRIAL', fixture['trial']), patch.object(F, 'OUTPUTS', fixture['outputs']):
            plan = F.prepare(F.ref(path))
        row = next(r for r in plan['index'] if r['original_path'] == str(fixture['alias']))
        self.assertEqual(row['location']['index'], prior_ref)
        self.assertEqual(row['location']['prior_original_path'], str(fixture['alias']))
        self.assertNotIn(str(fixture['alias']), [r['original_path'] for r in prior['entries']])

    def test_required_csv_and_exact_archive_reference(self) -> None:
        """機能: CSV未接続と、旧entryを別値に置き換えた素材を拒否する。

        引数: self(Formal115Tests)は検査器。
        返り値: None。
        """
        fixture = make_fixture(self.root / '任意CSV')
        req = deepcopy(fixture['request'])
        req['refs'].pop('csv_check')
        req.pop('csv_refs')
        path = fixture['source'] / 'CSV未接続.json'
        F.write_json(path, req)
        with patch.object(F, 'TRIAL', fixture['trial']), self.assertRaises(ValueError):
            F.prepare(F.ref(path))
        req = deepcopy(fixture['request'])
        material = F.read(req['refs']['code_material'], {})
        row = next(r for r in material['entries'] if r['location']['kind'] == '既正式ZIP参照')
        row['location']['entry'] = '旧/不存在.go'
        material_path = fixture['source'] / '改変素材.json'
        F.write_json(material_path, material)
        req['refs']['code_material'] = F.ref(material_path)
        path = fixture['source'] / '改変素材要求.json'
        F.write_json(path, req)
        with patch.object(F, 'TRIAL', fixture['trial']), self.assertRaises(ValueError):
            F.prepare(F.ref(path))

    def test_prior54_and_code_collection_rejected(self) -> None:
        """機能: 元54の同条件認証不足と金融閉包の不足を拒否する。

        引数: self(Formal115Tests)は検査器。
        返り値: None。
        """
        for kind in ('prior54', 'closure'):
            fixture = make_fixture(self.root / kind)
            req = deepcopy(fixture['request'])
            if kind == 'prior54':
                market = F.read(req['refs']['market'], {})
                prior = F.read(market['prior54'], {})
                prior['condition_sha256'] = '0' * 64
                p = fixture['source'] / '改変54.json'
                F.write_json(p, prior)
                market['prior54'] = F.ref(p)
                p = fixture['source'] / '改変市場.json'
                F.write_json(p, market)
                req['refs']['market'] = F.ref(p)
                result = F.read(req['refs']['result'], {})
                saved = F.read(req['refs']['saved_check'], {})
                result['金融完了SHA256'] = saved['金融完了SHA256'] = req['refs']['market']['sha256']
                p = fixture['source'] / '改変結果.json'
                F.write_json(p, result)
                req['refs']['result'] = F.ref(p)
                saved['出力SHA256']['結果.json'] = req['refs']['result']['sha256']
                p = fixture['source'] / '改変検算.json'
                F.write_json(p, saved)
                req['refs']['saved_check'] = F.ref(p)
            else:
                material = F.read(req['refs']['code_material'], {})
                material['entries'].pop()
                p = fixture['source'] / '不足素材.json'
                F.write_json(p, material)
                req['refs']['code_material'] = F.ref(p)
            p = fixture['source'] / '不足要求.json'
            F.write_json(p, req)
            with patch.object(F, 'TRIAL', fixture['trial']), self.assertRaises(ValueError):
                F.prepare(F.ref(p))
            self.assertFalse(fixture['trial'].exists())

    def test_compiler_is_environment_reference(self) -> None:
        """機能: Goコンパイラを金融閉包へ残しZIP複写しない分類を確認する。

        引数: self(Formal115Tests)は手製検査器。
        返り値: None。実Go/市場データを使わない。
        """
        environment = self.root / '手製Go環境'
        compiler = environment / 'bin/go.exe'
        compiler.parent.mkdir(parents=True)
        compiler.write_bytes('実行しない手製Go'.encode())
        prior = {'成功': True, 'go_environment': {'version': 'go1.24.2', 'root': str(environment)}, 'entries': []}
        rows = F.K.classify({str(compiler): F.sha(compiler)}, {}, [(prior, {'人工索引': True})])
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['kind'], 'Goコンパイラ環境参照')
        self.assertEqual(rows[0]['location'], {'kind': '環境参照のみ', 'go_version': 'go1.24.2'})

    def test_all70_price_and_dmi_proof_required(self) -> None:
        """機能: 全70価格足/DMIの停止・要求・公表数・場順・不変の不足を拒否する。

        引数: self(Formal115Tests)は手製metadata検査器。
        返り値: None。first2成功を全70保証へ拡大しない。
        """
        fixture = make_fixture(self.root / '価格足DMI拒否')
        values = {name: F.read(reference, {}) for name, reference in fixture['request']['refs'].items()}
        for kind in ('first2', 'missing', 'stop', 'publication', 'order', 'changed', 'request'):
            changed = deepcopy(values)
            if kind == 'first2':
                changed['price_check']['stage'] = 'first2'
            elif kind == 'missing':
                changed['price_check']['場別'].pop()
            elif kind == 'stop':
                changed['price_stop']['Go公開器停止'] = {'path': '不一致', 'sha256': '0' * 64}
            elif kind == 'publication':
                changed['price_check']['場別'][0]['比較']['DMI現前値と計数'] -= 1
            elif kind == 'order':
                changed['price_check']['場別'].reverse()
            elif kind == 'changed':
                changed['price_check']['前後不変'] = False
            else:
                changed['price_request']['csv_read_authorized'] = False
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                F.validate(changed, fixture['request'])

    def test_fixed_dependency_goroot_union(self) -> None:
        """機能: 実cmd標準源と依存人工標準源を環境参照へ合わせ不正根を拒否する。

        引数: self(Formal115Tests)は手製Go環境検査器。
        返り値: None。金融閉包を変更せず、追加源を新ZIPへ混ぜない。
        """
        base = self.root / 'Go環境'
        paths = [base / 'src/通常.go', base / 'src/通常_test.go', base / 'bin/go.exe']
        for path in paths:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(('実行しない人工' + path.name).encode())
        code = {str(path): F.sha(path) for path in paths}
        selected = {str(paths[0]): code[str(paths[0])]}
        environment = {'version': 'go1.24.2', 'root': str(base)}
        combined = F.K.environment_goroot(code, selected, environment)
        self.assertEqual(set(combined), {str(path) for path in paths[:2]})
        prior = {'成功': True, 'go_environment': environment, 'entries': []}
        classified = F.K.classify(code, combined, [(prior, {'人工索引': True})])
        self.assertEqual([r['kind'] for r in classified].count('GoRoot環境参照'), 2)
        self.assertEqual([r['kind'] for r in classified].count('Goコンパイラ環境参照'), 1)
        with self.assertRaises(ValueError):
            F.K.environment_goroot(code, {str(paths[0]): '0' * 64}, environment)
        with self.assertRaises(ValueError):
            F.K.environment_goroot({**code, str(base / '未許可'): '0' * 64}, selected, environment)


if __name__ == '__main__':
    unittest.main(verbosity=2)
