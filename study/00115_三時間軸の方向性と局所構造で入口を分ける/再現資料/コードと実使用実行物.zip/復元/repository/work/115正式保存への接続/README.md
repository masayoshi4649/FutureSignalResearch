# 115の正式保存への接続

114の入口票Counter零項目版4b186c…から新規派生した。非零の欠落・過剰は拒否し、合計0キーの省略だけをCounter同値で扱う。既停止のコードや正式物は変更しない。

Rootの全70金融成功・独立840会計・入口独立840口座・価格足/DMI独立70場・CSV二点全セル再読成功が揃った新固定要求だけから、同bytesで正式保存する。A0/T/TR各4費用・P113のP100共通保護を本名のまま残し、A0各4条件を正式114A0へ全金融比較する。Source111全文同体と別の証拠として記録する。元54は同条件成功Nativeの認証再用、追加16だけ再生である。

## 固定要求

`version:1,trial:115,fixed:true,stage:"full70",market_native_read_authorized:true`。FileRefは絶対path/sha256、必要時bytesを加える。refsの必須項目は次の通り。

- `condition,market,result,saved_check`：金融F1、全70成功、独立会計と保存検算。
- `core_stop,actor_stop,pure_stop,entry_gate_stop,entry_chart_stop,entry_input_stop`：115Core/Actor、P113共通保護、115純入口、115入口bank、旧市場入力口の停止。
- `entry_stop,entry_check,save_stop,P_stop`：入口独立と全70成功、独立金融保存、P監査の停止。
- `price_stop,price_request,price_check`：CSVから5/15/30 OHLCとDMIを別計算する停止、同F1/同全70完了に結ぶ許可要求、全70成功。first2成功で全70を代用しない。CSV本文をこの保存器で再計算・複写しない。
- `csv_stop,csv_check`：正益経験分母版20d9…とRoot全セル再読成功。CSV二点はcsv_refsへ結ぶ。
- `formal_stop,code_material_stop,code_material`：この市場前停止、分類器停止、金融コード分類素材。

入口独立の各場countsは会計の全12票へ全値照合し、合計は零キー省略を許すCounter同値で確認する。価格足/DMIの許可要求・停止・70場Native・CSV Ref・prefix件数・全公表の比較計数・入力前後同体を結ぶ。第三の金融器は作らない。

`csv_refs={"候補別集計.csv":FileRef,"全セッション.csv":FileRef}`は必須で、唯一正本outputsの現在SHAとRoot全セル再読成功を結ぶ。CSV本文の生成・複写・第三算術再読はしない。

## コード所在と保存範囲

金融code1807と実使用exe1を現物SHA認証し、旧111/112/113/114の正式所在索引までflattenする。GoRoot1251（元runtime716と依存人工535の固定和集合）とGoコンパイラは環境参照、同体の旧Source/Chart/戦略は直接の旧ZIP entryまたは正式metadata参照とする。旧ZIPの全SHAと選択entryのSHA/size/CRCを正式保存時に確認し、旧ZIP全体は複写しない。復元先は現pathで、同bytes別path参照でも過去pathへ置き換えない。

新規Go入口/bank/Actor/Core、独立入口/P/金融/価格足DMI、CSV分母版、binder/Root後段helperなどを同pathで統合し、新規だけZIPへ保存する。各停止の所有・再用コード、5宣言、明示`code_refs:[{ref:FileRef,role:文字列}]`を加える。CSV比較人工の旧0d45所有4・旧停止・既発行marker EE57も分類し、旧人工CSV/PNGは追加しない。markerを発行し直さない。

`extra_refs:[{ref:FileRef,target:"診断/明示名.json",role:文字列}]`は小metadata・圧縮診断・文書を診断/検査/再現資料へ追加する。固定原文や校正差分/helperは元SHAのまま指定する。Raw・価格CSV・旧Native・巨大原文JSONLを重複保存せず、Viewer TOMLは実使用コードとしてcode_refsへ置く。

正式先はstudy/00115_三時間軸の方向性と局所構造で入口を分ける。成果物840trades/一覧/結果/検算、115Native70/台帳、新規コードZIP/索引と小検査を新規保存する。既存README/設定と結果/設計候補/根拠/市場前原文は上書きしない。

## CLIと証明範囲

```powershell
python -X utf8 work/115正式保存への接続/コードを分類する.py --fixed <F1絶対path> --sha256 <F1_SHA> --output <新規素材path>
python -X utf8 work/115正式保存への接続/検査して停止する.py --output <新規停止folder>
python -X utf8 work/115正式保存への接続/正式保存する.py --request <Root固定要求path> --request-sha <SHA256> --metadata-only
python -X utf8 work/115正式保存への接続/正式保存する.py --request <Root固定要求path> --request-sha <SHA256>
```

metadata-onlyは圧縮Native/約定/CSVの指紋を認証するが復号・算術再読・正式書込みをしない。人工9主は手製70場/空約定840/仮Native/人工旧ZIPと成功metadataだけを使う。全保存・再実行拒否・SHA差・旧4/Source不一致・入口票差・DMI first2代用/場順/公表数不足・CSV未接続・危険先・元54/閉包不足・標準源の選択/依存和集合を確認する。

5/15/30は入口指標の足幅で、元の連続時計を変えない。前史はCSV prefixを予定Endまで公表した模型、当場は原行観測までとする。Source/P100の3分cold保護は変えない。原文166の81比較は元54場3手法Event再実行対照の範囲で、当時全文や市場全tickState同体を証明しない。正式保存成功とViewer HTTP/描画は別の確認で、研究目標達成・採用はfalse。
