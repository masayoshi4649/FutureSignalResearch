"""115CSVを標準csv/Decimalで再読し、全行・入口分母・金銭・累計・率を独立照合する。"""

import argparse
from collections import defaultdict
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path

ZERO=Decimal(0)
TOLERANCE=Decimal('0.000001')
NUMERIC=0
BLANKS=0
GATE_COLUMNS={
    '元新規要求数':'source_new','入口許可要求数':'allowed','採用モード票が真の要求数':'selected_true',
    '採用モード票が偽の要求数':'selected_false','採用モード票が未知の要求数':'selected_unknown',
    '入力不足あり要求数':'input_missing','条件の否定あり要求数':'known_denial','新規受付要求数':'accepted_requests',
    '新規受付枚数':'accepted_quantity','実取得新規fill数':'actual_new_fills','実取得枚数':'actual_quantity'}
MAPPED={'新規件数':'positions','新規枚数':'entry_quantity','粗損益円':'gross_yen','手数料円':'fee_yen','追加滑り円':'slip_yen',
        '純損益円':'net_yen','利益総額円':'positive_yen','損失総額円':'negative_yen','勝ち件数':'positive_positions',
        '負け件数':'negative_positions','同値件数':'zero_positions','建玉全体の正益後赤字件数':'whole_positive_closed_negative',
        '追尾起動件数':'protection_activated_positions','追尾起動後赤字件数':'activated_closed_negative'}
EXTRA={'PF':'PF','平均利益円':'average_profit_yen','平均損失円':'average_loss_yen','平均利益損失比':'average_profit_loss_ratio',
       '保存点連結時価DD円':'保存点連結時価DD','建玉全体の正益後赤字額円':'whole_positive_closed_negative_yen','追尾起動後赤字額円':'activated_closed_negative_yen'}


def need(value: bool,label: str) -> None:
    """機能: 保存schemaと分母の不整合を明示失敗へする。

    引数: value(bool)、label(str)は条件と説明。
    返り値: None。不成立はValueError。
    """
    if not value:raise ValueError(label)


def digest(path: Path) -> str:
    """機能: 明示ファイルの全bytes指紋を計算する。

    引数: path(Path)は正本・CSV又はcode。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def number(value: str, expected, label: str) -> None:
    """機能: 実数と未定義空欄を正本へ照合して実行した件数を数える。

    引数: value(str)、expected(int/Decimal/None)、label(str)はCSVと正本と説明。
    返り値: None。数値は百万分の一、未定義は空欄だけを許す。
    """
    global NUMERIC,BLANKS
    if expected is None:
        need(value=='','未定義比率を0へ変換:'+label);BLANKS+=1;return
    actual=Decimal(value)
    need(actual.is_finite() and abs(actual-Decimal(expected))<=TOLERANCE,'CSV数値差:'+label)
    NUMERIC+=1


def records(path: Path) -> list:
    """機能: UTF-8 CSVを空欄のまま全行へ復元する。

    引数: path(Path)はCSV。
    返り値: list[dict]は全行。重複列や不揃い列を拒否する。
    """
    with path.open(encoding='utf-8-sig',newline='') as stream:
        reader=csv.DictReader(stream)
        need(reader.fieldnames and len(reader.fieldnames)==len(set(reader.fieldnames)),'CSVヘッダ重複/欠落')
        rows=list(reader)
    need(all(None not in row and all(v is not None for v in row.values()) for row in rows),'CSV列数不揃い')
    return rows


def inspect_metrics(row: dict,label: str) -> None:
    """機能: 率を正負金額と勝負同値から独立に再計算する。

    引数: row(dict)、label(str)は独立集計と対象。
    返り値: None。率は加算せず対応する分母から計算する。
    """
    gain,loss=Decimal(row['positive_yen']),Decimal(row['negative_yen'])
    wins,losses,count=(row[k] for k in ('positive_positions','negative_positions','positions'))
    need(gain>=0 and loss<=0 and wins+losses+row['zero_positions']==count,'利益/損失/分母:'+label)
    number(str(gain+loss),row['net_yen'],label+'/正負合算')
    values={'PF':gain/-loss if loss<0 else None,'win_rate':Decimal(wins)/count if count else None,
            'average_profit_yen':gain/wins if wins else None,'average_loss_yen':loss/losses if losses else None}
    values['average_profit_loss_ratio']=values['average_profit_yen']/-values['average_loss_yen'] if wins and losses else None
    for key,expected in values.items():
        number('' if row[key] is None else str(row[key]),expected,label+'/'+key)


def verify(result_path: Path,expected_sha: str,folder: Path,output: Path,artificial: bool) -> dict:
    """機能: 候補12と全場12Nの全セル・累計・入口分母をCSVから独立再読する。

    引数: result_path/folder/output(Path)、expected_sha(str)、artificial(bool)は正本・出力・指紋・人工区分。
    返り値: dictは件数と前後不変の確認。実Rawや金融Goを読まない。
    """
    global NUMERIC,BLANKS
    NUMERIC=BLANKS=0
    need(digest(result_path)==expected_sha,'独立正本SHA差')
    data=json.loads(result_path.read_text(encoding='utf-8-sig'),parse_float=Decimal)
    need(data['成功'] is True and data['前後不変'] is True and data['試行']==115,'115独立成功')
    if artificial:need(data.get('人工') is True and data['stage']=='artificial' and 0<data['場数']<=8,'人工ラベル/小場数')
    else:need(data.get('人工',False) is False and data['stage']=='full70' and data['場数']==70,'全70独立成功')
    sessions_count=data['場数']
    expected_keys=[f'{mode}_C{cost}_D{delay}' for mode in ('A0','T','TR') for cost in (0,5) for delay in (0,1)]
    need(data['主key']==expected_keys and data['会計数']==12*sessions_count,'115本名12順序/全会計')
    source={(row['key'],row['session']):row for row in data['場別']}
    need(len(source)==len(data['場別'])==12*sessions_count,'正本全場/重複')
    proof_path=folder/'CSVの確認.json';proof=json.loads(proof_path.read_text(encoding='utf-8'))
    need(proof['成功'] is True and proof['試行']==115 and proof['人工']==artificial and proof['入力SHA256']==expected_sha,'CSV生成の正本差')
    need(set(proof['出力'])=={'候補別集計.csv','全セッション.csv'},'CSV二点だけ')
    paths=[result_path,proof_path,folder/'候補別集計.csv',folder/'全セッション.csv',Path(__file__).resolve()]
    before={str(path):digest(path) for path in paths}
    for name,reference in proof['出力'].items():need(digest(folder/name)==reference['sha256'],'CSV生成後SHA差')
    detail,totals=records(folder/'全セッション.csv'),records(folder/'候補別集計.csv')
    need(len(detail)==12*sessions_count and len(totals)==12,'CSV予定全行数')
    seen=set();cumulative=defaultdict(lambda:ZERO);session_lists=defaultdict(list);gate_totals=defaultdict(lambda:defaultdict(int));zero_rows=0
    for row in detail:
        key=row['条件ID'];need(row['開始日JST'].endswith(' JST'),'JST文字列の欠落')
        date=row['開始日JST'][:-4]
        kind='Day' if row['セッション']=='デイ' else 'Night' if row['セッション']=='ナイト' else '不明'
        sid=date+'_'+kind;identity=key,sid
        need(identity in source and identity not in seen,'未知又は重複場別行');seen.add(identity);session_lists[key].append(sid)
        original,config=source[identity],data['Actor設定'][key]
        need(row['候補']==config['entry_mode']==config['candidate'] and row['共通保護政策']==config['policy']=='P100','入口候補又は共通保護差')
        need(row['期間区分']==('元54場' if original['history_class']=='original54' else '追加16場'),'期間区分差')
        for header,expected in [('試行',115),('片道追加滑りpt',config['slip_pts']),('仮定遅延秒',config['delay_seconds'])]:number(row[header],expected,key+'/'+header)
        for header,field in MAPPED.items():number(row[header],original[field],key+'/'+sid+'/'+header)
        inspect_metrics(original,key+'/'+sid)
        cumulative[key]+=original['net_yen']
        for header,expected in [('累計収支円',cumulative[key]),('場内時価DD円',original['場内時価DD']),('保有時間秒',original['頻度診断']['held_seconds']),('数量秒',original['頻度診断']['quantity_seconds'])]:number(row[header],expected,key+'/'+header)
        number(str(Decimal(row['粗損益円'])-Decimal(row['手数料円'])-Decimal(row['追加滑り円'])),original['net_yen'],key+'/CSV費用控除')
        counts=original['入口票検査']['counts']
        need(counts['selected_true']+counts['selected_false']+counts['selected_unknown']==counts['source_new'] and counts['allowed']==counts['selected_true'],'入口三値全分母')
        need(counts['actual_new_fills']==original['positions'] and counts['actual_quantity']==original['entry_quantity'],'実取得分母')
        for header,field in GATE_COLUMNS.items():
            number(row[header],counts[field],key+'/'+sid+'/'+header);gate_totals[key][field]+=counts[field]
        zero_rows+=original['positions']==0
    need(seen==set(source) and set(session_lists)==set(expected_keys),'全場/全候補保持')
    for key,values in session_lists.items():need(len(values)==sessions_count and values==sorted(values),'候補内の全場数/時系列')
    total_seen=set()
    for row in totals:
        key=row['条件ID'];need(key not in total_seen and key in expected_keys,'候補重複/不明');total_seen.add(key)
        aggregate,config=data['集計'][key],data['Actor設定'][key]
        need(row['候補']==config['entry_mode']==config['candidate'] and row['共通保護政策']==config['policy']=='P100','候補名又は保護差')
        for header,field in {**MAPPED,**EXTRA}.items():number(row[header],aggregate[field],key+'/'+header)
        for header,field in MAPPED.items():number(row[header],sum((r[field] for r in data['場別'] if r['key']==key),ZERO),key+'/全場再合算/'+header)
        inspect_metrics(aggregate,key)
        for header,expected in [('勝率パーセント',None if aggregate['win_rate'] is None else aggregate['win_rate']*100),('セッション数',sessions_count),('片道追加滑りpt',config['slip_pts']),('仮定遅延秒',config['delay_seconds']),('保有時間秒',sum((r['頻度診断']['held_seconds'] for r in data['場別'] if r['key']==key),ZERO)),('数量秒',sum((r['頻度診断']['quantity_seconds'] for r in data['場別'] if r['key']==key),ZERO)),('純損益円',cumulative[key])]:number(row[header],expected,key+'/'+header)
        for header,field in GATE_COLUMNS.items():
            total=gate_totals[key][field];number(row[header],total,key+'/'+header)
            number(str(data['入口票集計'][key].get(field,0)),total,key+'/正本入口票合算/'+field)
    need(total_seen==set(expected_keys),'全候補順序保持')
    after={str(path):digest(path) for path in paths};need(before==after,'正本/CSV/code前後差')
    report={'成功':True,'試行':115,'人工':artificial,'場別行数':len(detail),'候補数':len(totals),'数値比較数':NUMERIC,'空欄比率確認数':BLANKS,
            '0取引行数':zero_rows,'全場累計再計算':True,'入口全分母合算':True,'未定義比率は空欄':True,'JST文字列保持':True,
            '前後不変':True,'入力SHA256':before,'後SHA256':after,'Raw読取':0,'金融再実行':False}
    with output.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    return report


def main() -> None:
    """機能: Root成功指定又は人工の明示後にだけCSVを独立再読する。

    引数: CLI result/sha256/folder/output(str)、artificial/root-authorized(flag)は位置・指紋・解禁区分。
    返り値: None。比較数を実行値から表示する。
    """
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('result','sha256','folder','output'):parser.add_argument('--'+name,required=True)
    group=parser.add_mutually_exclusive_group(required=True);group.add_argument('--artificial',action='store_true');group.add_argument('--root-authorized',action='store_true')
    args=parser.parse_args()
    report=verify(Path(args.result).resolve(),args.sha256,Path(args.folder).resolve(),Path(args.output).resolve(),args.artificial)
    print(json.dumps({'成功':True,'数値比較数':report['数値比較数'],'空欄比率確認数':report['空欄比率確認数'],'0取引行数':report['0取引行数']},ensure_ascii=False))


if __name__=='__main__':main()
