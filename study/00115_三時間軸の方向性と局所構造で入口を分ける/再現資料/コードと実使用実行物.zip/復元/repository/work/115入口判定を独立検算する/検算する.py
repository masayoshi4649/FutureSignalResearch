"""115の独立入口算術・公表asof・Source要求と実受付を、保存値だけから検算する。"""
from collections import Counter
from copy import deepcopy
from decimal import Decimal
from pathlib import Path
from datetime import date,timedelta
import argparse
import gzip
import hashlib
import importlib.util
import json
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OWNED=("独立式.py","検算する.py","人工検査.py","検査して停止する.py","README.md")
_spec=importlib.util.spec_from_file_location("独立入口式115",HERE/"独立式.py")
I=importlib.util.module_from_spec(_spec);_spec.loader.exec_module(I)
MODES=("A0","T","TR")
CONFIGS=tuple({"policy":"P100","entry_mode":m,"slip_pts":c,"delay_seconds":d} for m in MODES for c in (0,5) for d in (0,1))
KEYS=tuple(f"{c['entry_mode']}_C{c['slip_pts']}_D{c['delay_seconds']}" for c in CONFIGS)
MODEL="prior_csv_publications_through_scheduled_end_current_raw_delivery115"
PURE_STOP={"path":str(ROOT/"work/115三時間軸と構造の純入口/停止.json"),"sha256":"50bd192518a88c4fe087ccae052ecc3d312fccabf3c8c1f230cdd8391e8c133a"}
BANK_STOP={"path":str(ROOT/"work/115三時間軸と方向性の公開/検査_停止版/停止.json"),"sha256":"df5718acf04495bc690c5a0d0652ba202cb9f970eb2323389f246d70cdbe7a68"}
ACTOR_STOP={"path":str(ROOT/"work/115三時間軸の複合入口を執行する会計/Actor停止.json"),"sha256":"318de27a32a0941114443e5045426df3599eea74e8e5ffa8647771e92934ce35"}
PRIOR_CODE={"path":str(ROOT/"work/114入口判定を独立検算する/検算する.py"),"sha256":"b4567bf7a534d825ee3461993ab3165277698c5fe36b1443280af4f3439ba5f1"}


def verify_frame(frame: dict,delivered: dict,scope: dict) -> None:
    """
    機能: 115公表の場・尺度・名目/実配送時計と元値の有限性を検査する。
    引数: frame/delivered/scope(dict)。返り値: None。CSVの形成を再走しない。
    """
    stamp(delivered,scope);f=frame["frame"];w=f["width_seconds"]
    need(w in (300,900,1800) and f["session_id"]==scope["session"] and f["contract"]==scope["contract"] and bool(f["id"]),"115公表の場/限月/尺度")
    need(I.number(f["start"])>=I.number(scope["start"]) and I.number(f["end"])-I.number(f["start"])==w and I.number(f["end"])<=I.number(scope["end"]),"115足の当場境界")
    need(I.number(f["end"])<=I.number(f["nominal_available"])<=I.number(f["available_at"])<=I.number(delivered["time"]) and f["observed_at"]==f["delivery_at"]==delivered["time"] and f["record_ordinal"]==delivered["index"]+1 and f["publication_ordinal"]>0,"115名目/実配送原行")
    need(type(f["price_known"]) is bool and type(frame["structure"]["known"]) is bool,"115価格/構造旗")
    for key in ("open","high","low","close"):I.number(f["ohlc"][key])
    if f["price_known"]:
        o=f["ohlc"];need(0<I.number(o["low"])<=min(I.number(o["open"]),I.number(o["close"]))<=max(I.number(o["open"]),I.number(o["close"]))<=I.number(o["high"]),"115OHLC形状")
    for group in (f["technical"],frame["dmi"]):
        for v in group.values():
            if isinstance(v,dict) and "known" in v:I.value(v)


def verify_snapshot(snapshot: dict,delivered: dict,scope: dict) -> None:
    """
    機能: 要求当原行Snapshotの時計・当場公表/seedだけ・鮮度を独立検査する。
    引数: snapshot/delivered/scope(dict)。返り値: None。
    """
    stamp(delivered,scope);s=snapshot["session"]
    need(s["id"]==scope["session"] and s["contract"]==scope["contract"] and s["start"]==scope["start"] and s["end"]==scope["end"],"115Snapshot場限月")
    need(snapshot["as_of"]==snapshot["replay_observed_at"]==delivered["time"] and snapshot["has_observed"] and snapshot["record_ordinal"]==delivered["index"]+1 and not snapshot["sealed"],"115当原行Snapshot")
    need([x["width_seconds"] for x in snapshot["scales"]]==[300,900,1800],"115Snapshot尺度集合")
    for scale in snapshot["scales"]:
        need(all(type(scale[k]) is bool for k in ("has_current","fresh","seed_only")),"115Snapshot旗")
        if scale["has_current"]:
            f=scale["current"]["frame"]
            need(f["record_ordinal"]<=snapshot["record_ordinal"] and f["delivery_at"]<=delivered["time"] and f["available_at"]<=delivered["time"] and not scale["seed_only"] and f["width_seconds"]==scale["width_seconds"],"115Snapshot当時公表")
            need(scale["fresh"]==(I.number(delivered["time"])-I.number(f["available_at"])<scale["width_seconds"]),"115Fresh期限")
        else:need(not scale["fresh"] and zero_value(scale["current"]),"seedだけで当場公表を偽装しない")


def zero_value(value) -> bool:
    """
    機能: 当場公表が無い値型欄がGo零値のままであることを検査する。
    引数: value(JSON値)。返り値: bool。数値seedは別欄で扱う。
    """
    if isinstance(value,dict):return all(zero_value(v) for v in value.values())
    if isinstance(value,list):return all(zero_value(v) for v in value)
    return value in (False,0,"",None)


def verify_full_decision(decision: dict) -> dict:
    """
    機能: 独立十二値/三値に要求時計とbank公表の検査を追加する。
    引数: decision(dict)。返り値: dictは確認数。
    """
    checked=I.verify_decision(decision);current=decision["current"];need(current["delivered"]==decision["request"]["at"],"115要求当原行でfreeze")
    verify_snapshot(current["snapshot"],current["delivered"],decision["scope"]);return checked


def events_for_context(context: dict,scope: dict) -> dict:
    """
    機能: 全公表から当場前3本のOHLC/Refを再構成しEntryEventsとseedを認証する。
    引数: context/scope(dict)。返り値: dictは認証済み公表列/イベント/seed metadata。
    """
    publications=context["entry_publications"] or [];events=context["entry_gate_events"] or [];previous=None;seen=set();ring=[];lastend={};ordinal=0
    for pub in publications:
        at,frame=pub["stamp"],pub["frame"];verify_frame(frame,at,scope);f=frame["frame"]
        need(previous is None or stamp_before(previous,at),"115公表原行順");previous=at
        need(f["id"] not in seen and f["publication_ordinal"]==ordinal+1 and I.number(f["end"])>lastend.get(f["width_seconds"],Decimal(0)),"115全公表一意/尺度内終端前進")
        seen.add(f["id"]);ordinal=f["publication_ordinal"];lastend[f["width_seconds"]]=I.number(f["end"])
        st=frame["structure"]
        if f["width_seconds"]!=300:need(not st["known"],"115構造は5分だけ");continue
        if not f["price_known"]:ring=[];need(not st["known"],"115不良足で構造reset");continue
        if ring and ring[-1]["frame"]["end"]!=f["start"]:ring=[]
        expected=len(ring)==3;need(st["known"]==expected,"115前3本既知の独立再形成")
        if expected:
            need(st["high"]==max(v["frame"]["ohlc"]["high"] for v in ring) and st["low"]==min(v["frame"]["ohlc"]["low"] for v in ring),"115構造HighLow独立算術")
            refs=[{"id":v["frame"]["id"],"start":v["frame"]["start"],"end":v["frame"]["end"],"published_at":v["frame"]["delivery_at"]} for v in ring]
            need(st["refs"]==refs,"115前3本Ref/現在足除外")
        ring=(ring+[frame])[-3:]
    info=context["entry_input"];need(info["model"]==MODEL and type(info["prior_sessions"]) is int and info["prior_sessions"]>=0,"115前史モデル")
    seed=info["input_seed"];carried=False
    if seed is not None:
        old=seed["old"];need(seed["version"]==115 and old["sealed"] and old["session"]["end"]<=scope["start"] and old["observed_at"]<=scope["start"] and info["prior_sessions"]>0,"115seedは厳密過去場")
        need(re.fullmatch("[a-f0-9]{64}",seed["sha256"]) is not None and [v["width_seconds"] for v in seed["dmi"]]==[300,900,1800],"115seed指紋/尺度")
        carried=old["session"]["contract"]==scope["contract"]
    previous=None;seedtechnical=None
    for event in events:
        at=event["stamp"];verify_snapshot(event["snapshot"],at,scope);need(previous is None or stamp_before(previous,at) and previous!=at,"115EntryEvent原行一意/順序");previous=at
        for i,scale in enumerate(event["snapshot"]["scales"]):
            need(scale["seed_only"]==(carried and not scale["has_current"]),"115seedだけと当場公表の分離")
            if carried:
                need(scale["seed_dmi"]==seed["dmi"][i]["last"] and scale["seed_technical"]["history_bars"]==seed["old"]["history_bars"][i],"115種DMI/本数への結合")
            else:
                need(scale["seed_technical"]["history_bars"]==scale["seed_dmi"]["bars"]==0 and not any(v["known"] for v in scale["seed_technical"].values() if isinstance(v,dict)) and not any(v["known"] for v in scale["seed_dmi"].values() if isinstance(v,dict)),"115別限月/無seedを既知化しない")
        currentseed=[(x["seed_technical"],x["seed_dmi"]) for x in event["snapshot"]["scales"]]
        if seedtechnical is None:seedtechnical=currentseed
        else:need(currentseed==seedtechnical,"115場内種公開値の不変")
    return {"publications":publications,"events":events,"seed":seed}


def history_points(context: dict,requests: list[dict],scope: dict) -> list[dict]:
    """
    機能: 要求原行へ届いた最新尺度公表だけを再構成して保存Snapshotへ照合する。
    引数: context(dict)、requests(list[dict])、scope(dict)。返り値: list[dict]は要求時Current。
    """
    publications,events=context["publications"],context["events"];by_stamp={tuple(e["stamp"][k] for k in ("time","index","source_line")):e for e in events};out=[];cursor=0;latest={};previous=None
    need(len(by_stamp)==len(events),"115EntryEvents重複なし")
    need(set(by_stamp)=={tuple(r["at"][k] for k in ("time","index","source_line")) for r in requests},"115Source全new原行とEvent1対1")
    for request in requests:
        at=request["at"];stamp(at,scope);need(previous is None or stamp_before(previous,at),"115Source要求順");previous=at
        while cursor<len(publications) and stamp_before(publications[cursor]["stamp"],at):
            frame=publications[cursor]["frame"];latest[frame["frame"]["width_seconds"]]=frame;cursor+=1
        key=tuple(at[k] for k in ("time","index","source_line"));need(key in by_stamp,"115全newに当原行Event")
        event=by_stamp[key];snapshot=event["snapshot"]
        for scale in snapshot["scales"]:
            f=latest.get(scale["width_seconds"]);need(scale["has_current"]==(f is not None),"115asof現在公表の有無")
            if f is not None:need(scale["current"]==f,"115全公表asof最新とSnapshot全値")
        out.append({"current":{"snapshot":snapshot,"delivered":at}})
    return out


def need(value: bool, label: str) -> None:
    """
    機能: 出典や会計結合の差を失敗として拒否する。
    引数: value(bool)、label(str)。返り値: None。不成立はValueError。
    """
    if not value:
        raise ValueError(label)

def digest(path: Path) -> str:
    """
    機能: 明示JSON/コード/解禁Nativeの指紋を求める。
    引数: path(Path)。返り値: strはSHA256。Rawは対象外。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()

def reject_constant(value: str) -> None:
    """
    機能: 非標準の非有限JSON数値を拒否する。
    引数: value(str)。返り値: None。必ずValueError。
    """
    raise ValueError("非有限JSON:"+value)

def load(path: Path) -> dict:
    """
    機能: 認証済みJSONを有限十進数で読む。
    引数: path(Path)。返り値: dictは元保存値。
    """
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path,"rt",encoding="utf-8-sig") as f:
        return json.load(f,parse_float=Decimal,parse_constant=reject_constant)

def serial(value):
    """
    機能: 有限DecimalだけをJSON数値へ写す。
    引数: value(object)。返り値: int/float又はTypeError。
    """
    if isinstance(value,Decimal) and value.is_finite():
        return int(value) if value == value.to_integral_value() else float(value)
    raise TypeError(type(value).__name__)

def write(path: Path, value: dict) -> dict:
    """
    機能: 未作成UTF-8 JSONだけを保存する。
    引数: path(Path)、value(dict)。返り値: dictはFileRef。
    """
    with path.open("x",encoding="utf-8",newline="\n") as f:
        f.write(json.dumps(value,ensure_ascii=False,indent=2,default=serial,allow_nan=False)+"\n")
    return {"path":str(path.resolve()),"sha256":digest(path)}

def reference(ref: dict, before: dict) -> Path:
    """
    機能: 明示絶対参照をSHA認証して前後台帳へ結ぶ。
    引数: ref/before(dict)。返り値: Pathは認証済み位置。
    """
    need(isinstance(ref,dict) and isinstance(ref.get("path"),str) and re.fullmatch("[a-f0-9]{64}",ref.get("sha256","")) is not None,"絶対FileRef型")
    path=Path(ref["path"])
    need(path.is_absolute(),"相対Ref拒否")
    path=path.resolve();need(digest(path)==ref["sha256"],"SHA差:"+str(path))
    need(str(path) not in before or before[str(path)]==ref["sha256"],"同位置SHA衝突")
    before[str(path)]=ref["sha256"]
    return path

def stamp(value: dict, scope: dict) -> tuple:
    """
    機能: 原行stampの時計/Index/物理行を独立検査する。
    引数: value/scope(dict)。返り値: tupleは時計・Index・Line。
    """
    need(set(value)=={"time","index","source_line"},"Stamp集合")
    at=I.number(value["time"])
    need(I.number(scope["start"])<=at<=I.number(scope["end"]),"場内原行")
    need(type(value["index"]) is int and value["index"]>=0 and type(value["source_line"]) is int and value["source_line"]>0,"原行整数")
    return at,value["index"],value["source_line"]

def stamp_before(a: dict, b: dict) -> bool:
    """
    機能: 同秒でも物理原行を保って前後を比較する。
    引数: a/b(dict)。返り値: boolはaがb以前のとき真。
    """
    return I.number(a["time"])<=I.number(b["time"]) and a["index"]<=b["index"] and a["source_line"]<=b["source_line"] and ((a["index"]!=b["index"] and a["source_line"]!=b["source_line"]) or a==b)

def same_ref(left: dict, right: dict) -> bool:
    """
    機能: 参照の解決絶対Path/SHAだけを同体比較する。
    引数: left/right(dict)。返り値: bool。bytes付加やslash表記を対象差にしない。
    """
    return isinstance(left,dict) and isinstance(right,dict) and isinstance(left.get("path"),str) and isinstance(right.get("path"),str) and Path(left["path"]).is_absolute() and Path(right["path"]).is_absolute() and Path(left["path"]).resolve()==Path(right["path"]).resolve() and left.get("sha256")==right.get("sha256") and isinstance(left.get("sha256"),str)

def planned_sessions(stage: str) -> list[str]:
    """
    機能: 事前固定のfirst2/元54/全70予定集合を列挙する。
    引数: stage(str)。返り値: list[str]は日付順。11/09を含めない。
    """
    need(stage in ("first2","base54","full70"),"入口監査stage")
    end=date(2026,9,21) if stage=="first2" else date(2026,10,27) if stage=="base54" else date(2026,11,6)
    day,result=date(2026,9,21),[]
    while day<=end:
        if day.weekday()<5:result.extend(f"{day.isoformat()}_{kind}" for kind in ("Day","Night"))
        day+=timedelta(days=1)
    need(len(result)=={"first2":2,"base54":54,"full70":70}[stage],"予定全場数")
    return result

def verify_entry_gate(book: dict, config: dict, context: dict) -> dict:
    """
    機能: Source全new・入口票・容量受付・実fillを元Events/注文へ独立に結ぶ。
    引数: book/config/context(dict)。返り値: dictは件数と三値分母。金融損益は別監査。
    """
    original=repr((book,config,context))
    need(config in CONFIGS and book["config"]==config,"入口本名12設定")
    audit=book["entry_gate"];need(audit["version"]==115 and audit["mode"]==config["entry_mode"],"入口保存版/モード")
    scope={"session":book["session"]["id"],"contract":context["scope"]["contract"],"start":book["session"]["start"],"end":book["session"]["end"]}
    events=events_for_context(context,scope)
    rows=audit["records"] or [];news=[e for e in (book["source_events"] or []) if e["kind"]=="new_signal"]
    need(len(rows)==len(news)==book["metrics"]["native_new_signals"],"全Source要求分母")
    need(len({(r["request"]["product"],r["request"]["method"],r["request"]["side"],r["request"]["signal_id"]) for r in rows})==len(rows),"一出生一回固定")
    requests=[r["request"] for r in rows];points=history_points(events,requests,scope)
    orders={o["id"]:o for o in (book["orders"] or [])};fills={f["id"]:f for f in (book["fills"] or [])};positions={p["id"]:p for p in (book["positions"] or [])}
    need(len(orders)==len(book["orders"] or []) and len(fills)==len(book["fills"] or []) and len(positions)==len(book["positions"] or []),"実ID重複")
    counts=Counter({k:0 for k in ("source_new","allowed","selected_true","selected_false","selected_unknown","accepted_requests","accepted_quantity","actual_new_fills","actual_quantity","input_missing","known_denial","publications_checked")})
    for row,event,point in zip(rows,news,points):
        request,decision,source=row["request"],row["decision"],row["source"]
        need(request==decision["request"] and decision["scope"]==scope,"純票の実要求と場")
        need(request["product"]=="NK225mini" and request["method"]==source["method"]==event["method"] and request["signal_id"]==source["signal_id"]==event["signal_id"] and request["side"]==event["side"],"Source複合要求")
        at={"time":row["quote"]["time"],"index":row["quote"]["index"],"source_line":row["quote"]["source_line"]}
        need(request["last"]==row["quote"]["last"] and request["at"]==at and row["quote"]==event["quote"]==source["birth_quote"] and source["birth_time"]==event["at"]==at["time"] and source["birth_quantity"]==event["quantity"],"元要求原行と出生量")
        for name in point:need(decision[name]==point[name],"配送順からの要求時履歴:"+name)
        verified=verify_full_decision(decision)
        selected=I.TRUE if config["entry_mode"]=="A0" else decision["trend"] if config["entry_mode"]=="T" else decision["combined"]
        need(row["selected"]==selected and row["allowed"]==(selected==I.TRUE),"モード選別")
        cap=min(event["quantity"],row["available"])
        cancelled=any(e["kind"]=="cancel" and e["method"]==request["method"] and e["signal_id"]==request["signal_id"] and e["quote"]["index"]<=at["index"] and e["quote"]["source_line"]<=at["source_line"] for e in (book["source_events"] or []))
        need(row["source_cancelled"]==cancelled and 0<=row["available"]<=10 and row["available"]==event["available"] and row["cap_quantity"]==cap,"容量/取消とgateの別記")
        accepted=cap if row["allowed"] and not cancelled else 0
        need(row["accepted_quantity"]==event["actual_accepted"]==accepted and row["order_id"]==event["order_id"],"実受付量/注文ID")
        counts["source_new"]+=1;counts["allowed"]+=row["allowed"];counts[{0:"selected_unknown",1:"selected_false",2:"selected_true"}[selected]]+=1
        counts["input_missing"]+=bool(decision["missing_inputs"]);counts["known_denial"]+=bool(decision["trend_denials"] or decision["reversal_denials"]);counts["publications_checked"]+=verified["公表数"]
        if accepted:
            counts["accepted_requests"]+=1;counts["accepted_quantity"]+=accepted
            need(row["order_id"] in orders,"受付注文存在")
            order=orders[row["order_id"]]
            need(order["kind"]=="entry" and order["source"]==source and order["quantity"]==accepted and order["side"]==request["side"] and order["request_quote"]==row["quote"] and order["request_time"]==at["time"],"受付注文全結合")
        else:need(not row["order_id"],"未受付注文なし")
        if row["actual_quantity"]:
            need(accepted==row["actual_quantity"] and row["actual_fill_id"] in fills and row["actual_position_id"] in positions,"実取得ID量")
            fill=fills[row["actual_fill_id"]];position=positions[row["actual_position_id"]];quote=fill["quote"]
            need(fill["action"]=="new" and fill["order_id"]==row["order_id"] and fill["position_id"]==position["id"] and fill["quantity"]==accepted and fill["source"]==source and fill["quote"]==row["actual_quote"]==position["entry_quote"],"実new取得結合")
            need(fill["side"]==position["side"]==request["side"] and position["source"]==source and position["initial_quantity"]==accepted and position["entry_order_id"]==row["order_id"] and fill["source_hold_id"]==position["source_hold_id"],"実玉の全入口所有")
            need(quote["index"]>at["index"] and quote["source_line"]>at["source_line"] and I.number(quote["time"])>=I.number(at["time"])+config["delay_seconds"],"strict後原行/D時計")
            need(quote["quote_ok"] and 0<I.number(quote["bid"])<I.number(quote["ask"]) and fill["price"]==position["entry_price"]==(quote["ask"] if request["side"]==1 else quote["bid"]),"実BBO取得価格")
            counts["actual_new_fills"]+=1;counts["actual_quantity"]+=accepted
        else:need(not row["actual_fill_id"] and not row["actual_position_id"] and row["actual_quote"] is None,"未取得を未来で補完しない")
    need(counts["accepted_requests"]==book["metrics"]["entry_requests"]==sum(o["kind"]=="entry" for o in orders.values()) and counts["accepted_quantity"]==book["metrics"]["entry_accepted_quantity"] and counts["actual_new_fills"]==book["metrics"]["entry_fills"]==sum(f["action"]=="new" for f in fills.values())==len(positions),"受付/実fill分母")
    need(counts["selected_true"]+counts["selected_false"]+counts["selected_unknown"]==counts["source_new"],"三値全分母")
    need(repr((book,config,context))==original,"入口独立監査は原値非変更")
    return {"成功":True,"counts":dict(counts),"配送と要求の独立再構成":True,"金融損益再計算":False,"限界":"保存されたEvents/Source通知/注文/実fillの照合。Rawの生成と最初の正常原行は別証明。"}

def verify_scene(native: dict, artificial: bool = False) -> dict:
    """
    機能: Core全12のSource要求・費用/モード間の固定票同体を独立照合する。
    引数: native(dict)、artificial(bool)。返り値: dictは全12結果と共通票件数。
    """
    actual=native["actual"];need(native["trial"]==actual["trial"]==115 and set(actual["books"])==set(KEYS),"115全12")
    need(actual["complete"] and actual["configurations"]==list(CONFIGS),"115全12宣言と完結")
    checked={};baseline=None;count=0
    for key,config in zip(KEYS,CONFIGS):
        book=actual["books"][key];checked[key]=verify_entry_gate(book,config,actual)
        projection=[{k:r[k] for k in ("request","source","quote","decision")} for r in (book["entry_gate"]["records"] or [])]
        if baseline is None:baseline=projection
        else:need(projection==baseline,"費用/モード間のSource要求と純固定票同体")
        count+=len(projection)
    # ----------------------------------------
    # 元Source信号が保存される自然再生では、actual側の通知だけに分母を依存しない。
    original=[]
    sources=native["source"].get("sources")
    need(artificial or isinstance(sources,dict),"自然Source全文の保存あり")
    for src in (sources or {}).values():
        if src["config"]["product"]!="NK225mini":continue
        for rec in src["signals"]:
            signal=rec["signal"]
            if signal["action"]=="new":original.append((src["method"],signal["id"],signal["side"],rec["quote"]))
    observed=[(r["request"]["method"],r["request"]["signal_id"],r["request"]["side"],r["quote"]) for r in baseline or []]
    if original or not artificial:
        need(sorted(original,key=lambda r:r[:3])==sorted(observed,key=lambda r:r[:3]),"元Source全文の全new集合と分母")
    event_stamps=[tuple(e["stamp"][k] for k in ("time","index","source_line")) for e in (actual["entry_gate_events"] or [])]
    new_stamps={tuple(r["request"]["at"][k] for k in ("time","index","source_line")) for r in (actual["books"]["A0_C0_D0"]["entry_gate"]["records"] or [])}
    need(len(event_stamps)==len(set(event_stamps)) and set(event_stamps)==new_stamps,"全new原行とEvent1対1")
    return {"成功":True,"会計数":12,"全Source延べ票":count,"共通Source要求数":len(baseline or []),"手製Source器具":artificial,"book":checked,"費用間とモード間のDecision同体":True}


def prepare(path: Path,sha: str,output: Path) -> dict:
    """
    機能: Root新解禁・市場前停止・同条件金融全成功をNative本文前に認証する。
    引数: path/output(Path)、sha(str)。返り値: dictは明示読取計画。
    """
    need(output.is_absolute() and not output.exists(),"115新規絶対出力")
    before={};request=load(reference({"path":str(path.resolve()),"sha256":sha},before))
    need(request["version"]==1 and request["trial"]==115 and request["fixed"] is True and request["market_native_read_authorized"] is True,"115Root新Native解禁")
    expected=planned_sessions(request["stage"]);stopped=load(reference(request["entry_stop"],before))
    own={str((HERE/n).resolve()):digest(HERE/n) for n in OWNED}
    need(stopped["成功"] and stopped["市場前"] and stopped["試行"]==115 and stopped["所有ファイルSHA256"]==own,"115独立入口実使用code停止")
    for p,s in {**own,**stopped["依存コードSHA256"]}.items():
        need(Path(p).suffix not in (".csv",".gz",".jsonl"),"115停止codeに市場入力を混ぜない");reference({"path":p,"sha256":s},before)
    actual_code=reference(request["entry_code"],before);need(actual_code==Path(__file__).resolve() and own[str(actual_code)]==request["entry_code"]["sha256"],"115実入口CLI")
    condition=load(reference(request["condition"],before));complete=load(reference(request["completion"],before))
    need(condition["trial"]==115 and condition["fixed"] is True and condition["actual_configurations"]==list(CONFIGS),"115固定全12")
    need(same_ref(condition["dependency_stops"]["entry_gate"],PURE_STOP) and same_ref(condition["dependency_stops"]["entry_chart"],BANK_STOP) and same_ref(condition["dependency_stops"]["actor"],ACTOR_STOP),"115純/bank/Actor固定")
    need(same_ref(stopped["純Go停止"],PURE_STOP) and same_ref(stopped["公開bank停止"],BANK_STOP) and same_ref(stopped["Core停止"],condition["runtime_stop"]),"115Python停止と同Core")
    puredecl=load(reference(stopped["純Go実定義"],before));bankdecl=load(reference(stopped["公開bank実定義"],before))
    need(condition["entry_gate_definition"]==puredecl and condition["entry_chart_definition"]==bankdecl and condition["entry_input_model"]==MODEL,"115金融の実式/公開モデル同体")
    runtime=load(reference(condition["runtime_stop"],before));need(runtime["成功"] and runtime["停止"] and runtime["trial"]==115,"115Core停止成功")
    need(complete["trial"]==115 and complete["success"] is True and complete["stage"]==request["stage"] and complete["sessions"]==len(expected) and complete["books"]==12*len(expected),"115予定全金融成功")
    need(complete["condition_sha256"]==request["condition"]["sha256"] and complete["unchanged"] and complete["before"] and complete["before"]==complete["after"],"115同固定/前後不変")
    need((complete["reused_sessions"],complete["replayed_sessions"])==((54,16) if request["stage"]=="full70" else (0,len(expected))),"115同条件再用と再生を分離")
    need(complete["all_reference114_equal"] and complete["all_source111_equal"] and complete["reference114_comparisons"]==4*len(expected),"115元A0/Source全対照")
    need([r["session"] for r in complete["results"]]==expected,"115全場順/欠落重複なし")
    for p,s in condition["code_sha256"].items():
        target=Path(p);target=(target if target.is_absolute() else ROOT/target).resolve();need(target.suffix not in (".csv",".gz",".jsonl"),"金融codeへ市場入力を混ぜない")
        reference({"path":str(target),"sha256":s},before);need(complete["before"].get(str(target))==s,"115金融が使用した同code")
    for row in complete["results"]:
        need(row["books"]==12 and row["complete"] and row["A0_equal"] and row["A0_comparisons"]==4 and row["reference114_equal"] and row["reference114_comparisons"]==4 and row["source111_equal"] and row["open_quantity"]==row["pending_quantity"]==0,"115場別全対照/flat")
    return {"request":request,"complete":complete,"before":before,"output":output.resolve()}


def execute(plan: dict,request_ref: dict) -> dict:
    """
    機能: Rootが明示解禁した全Nativeだけを入口独立検算し新規先へ保存する。
    引数: plan/request_ref(dict)。返り値: dictは成功FileRef。金融再演算はしない。
    """
    output=plan["output"];output.mkdir(parents=False,exist_ok=False);scenes=[]
    try:
        for row in plan["complete"]["results"]:
            native=load(reference(row["native"],plan["before"]));need(native["actual"]["scope"]["session"]["id"]==row["session"],"115Native場")
            scenes.append({"session":row["session"],**verify_scene(native)})
        after={p:digest(Path(p)) for p in plan["before"]};need(after==plan["before"],"115全入力code前後不変")
        return write(output/"結果.json",{"試行":115,"成功":True,"stage":plan["request"]["stage"],"場数":len(scenes),"会計数":12*len(scenes),"Root要求":request_ref,"金融条件SHA256":plan["request"]["condition"]["sha256"],"金融完了SHA256":plan["request"]["completion"]["sha256"],"入口独立停止SHA256":plan["request"]["entry_stop"]["sha256"],"場別":scenes,"入力codeSHA256前":plan["before"],"入力codeSHA256後":after,"前後不変":True,"金融損益再計算":False,"Raw/価格CSV/11月09本文/市場再走":False,"限界":["全保存公表からasofと前3本高安を独立再構成。CSV本文・原板形成は再走査しない。","DMI/EMA/ATRは保存公表値から十二値と票を独立算術。私有seedの全平滑状態はhash/本数だけで、前史の数値再算出はしない。","Availableは通知/受付との結合。保有/予約/費用/損益は別会計。実fillの後原行・遅延・BBOを照合するがRaw上の最初性は別証明。"]})
    except Exception as error:
        write(output/"不完了.json",{"成功":False,"試行":115,"Root要求":request_ref,"error":str(error)});raise


def main() -> None:
    """
    機能: Rootの市場成功後の新固定要求だけから独立入口CLIを実行する。
    引数: CLI fixed/sha256/output(str)、metadata-only(bool)。返り値: None。
    """
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--fixed",type=Path,required=True);p.add_argument("--sha256",required=True);p.add_argument("--output",type=Path,required=True);p.add_argument("--metadata-only",action="store_true");args=p.parse_args()
    plan=prepare(args.fixed,args.sha256,args.output.resolve())
    if args.metadata_only:print(json.dumps({"成功":True,"Native本文読取":False,"予定場数":len(plan["complete"]["results"])},ensure_ascii=False));return
    print(json.dumps({"成功":True,"結果":execute(plan,{"path":str(args.fixed.resolve()),"sha256":args.sha256})},ensure_ascii=False))


if __name__=="__main__":main()
