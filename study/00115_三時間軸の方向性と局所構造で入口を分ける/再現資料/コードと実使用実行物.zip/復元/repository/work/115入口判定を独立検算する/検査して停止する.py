"""115独立Python入口の式・人工・API・停止依存を市場実行前に固定する。"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import ast
import json
import subprocess
import sys

import 検算する as V
import 人工検査 as T


def authenticate(ref: dict,before: dict) -> dict:
    """
    機能: 明示停止と所有/再用codeを認証して前後台帳へ結ぶ。
    引数: ref/before(dict)。返り値: dictは停止原値。市場入力は拒否する。
    """
    stopped=V.load(V.reference(ref,before));V.need(stopped["成功"] and stopped.get("停止",True),"依存停止成功")
    for field in ("所有コードSHA256","所有ファイルSHA256","Root独立式SHA256","再用コードSHA256","実Go依存SHA256","全固定コードSHA256"):
        for p,s in stopped.get(field,{}).items():
            path=Path(p);path=(path if path.is_absolute() else V.ROOT/path).resolve();V.need(path.suffix not in (".csv",".gz",".jsonl"),"停止依存に市場本文を含めない");V.reference({"path":str(path),"sha256":s},before)
    return stopped


def financial_derivation(before: dict) -> None:
    """
    機能: 金融結合関数が旧114の版/Last結合以外は同体であることを検査する。
    引数: before(dict)。返り値: None。Goや金融期待値を呼ばない。
    """
    prior=V.reference(V.PRIOR_CODE,before);old=prior.read_text(encoding="utf-8");new=Path(V.__file__).read_text(encoding="utf-8")
    oldtree,newtree=ast.parse(old),ast.parse(new)
    a=next(ast.get_source_segment(old,n) for n in oldtree.body if isinstance(n,ast.FunctionDef) and n.name=="verify_entry_gate")
    b=next(ast.get_source_segment(new,n) for n in newtree.body if isinstance(n,ast.FunctionDef) and n.name=="verify_entry_gate")
    expected=a.replace('audit["version"]==114','audit["version"]==115').replace('need(request["at"]==at and row["quote"]==event["quote"]==source["birth_quote"]','need(request["last"]==row["quote"]["last"] and request["at"]==at and row["quote"]==event["quote"]==source["birth_quote"]')
    V.need(b==expected,"金融結合の旧114限定派生")


def main() -> None:
    """
    機能: 新所有5ファイル・9主人工・純/公開/Core停止・76手製票を停止する。
    引数: CLI core-stop(Path)、core-sha(str)。返り値: None。市場Native/Raw/CSVは読まない。
    """
    p=argparse.ArgumentParser();p.add_argument("--core-stop",type=Path,required=True);p.add_argument("--core-sha",required=True);args=p.parse_args();target,out=V.HERE/"停止.json",V.HERE/"検査"
    V.need(not target.exists() and not out.exists(),"新規停止だけ");before={};own={str((V.HERE/n).resolve()):V.digest(V.HERE/n) for n in V.OWNED}
    refs={"純":V.PURE_STOP,"bank":V.BANK_STOP,"Actor":V.ACTOR_STOP,"Core":{"path":str(args.core_stop.resolve()),"sha256":args.core_sha},"旧Python":{"path":str(V.ROOT/"work/114入口判定を独立検算する/停止.json"),"sha256":"369eda8990de9faa430ca575b3cf6f114abf73bea1cfebf32522ceef166f1eb6"}}
    stops={name:authenticate(ref,before) for name,ref in refs.items()};V.need(stops["Core"]["trial"]==115 and V.same_ref(refs["Core"],T.CORE_STOP),"115同Core停止")
    for name in V.OWNED:
        if not name.endswith(".py"):continue
        for node in ast.walk(ast.parse((V.HERE/name).read_text(encoding="utf-8"))):
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                doc=ast.get_docstring(node) or "";V.need("\n" in doc and all(w in doc for w in ("機能","引数","返り値")),"関数コメント:"+node.name)
    financial_derivation(before)
    for ref in (T.PURE_ART,T.CORE_ART):V.reference(ref,before)
    logs=[]
    for command in ([sys.executable,"-X","utf8",str(V.HERE/"人工検査.py")],[sys.executable,"-X","utf8",str(V.HERE/"検算する.py"),"--help"]):
        process=subprocess.run(command,cwd=V.HERE,capture_output=True,text=True,encoding="utf-8",timeout=60);V.need(process.returncode==0,process.stdout+process.stderr);logs.append({"command":command,"exit_code":process.returncode,"stdout":process.stdout,"stderr":process.stderr})
    V.need("Ran 9 tests" in logs[0]["stderr"] and "OK" in logs[0]["stderr"],"9主人工")
    pure,core=T.fixtures();checks={name:V.verify_scene(n,True) for name,n in core["results"].items()}
    for d in pure["decisions"]:V.verify_full_decision(d)
    out.mkdir();check=V.write(out/"人工の確認.json",{"試行":115,"成功":True,"市場前":True,"純Go手製票":4,"Core手製ケース":6,"Core会計数":72,"Core全Source延べ票":sum(v["全Source延べ票"] for v in checks.values()),"自然Source生成証明":False,"Root人工Ref":T.CORE_ART,"純人工Ref":T.PURE_ART,"case":checks,"検査ログ":logs})
    V.need(all(V.digest(Path(p))==s for p,s in {**own,**before}.items()),"全所有依存人工前後不変")
    result={"試行":115,"成功":True,"市場前":True,"UTC":datetime.now(timezone.utc).isoformat(),"所有ファイルSHA256":own,"依存コードSHA256":before,"依存停止":refs,"純Go停止":V.PURE_STOP,"公開bank停止":V.BANK_STOP,"Core停止":refs["Core"],"純Go実定義":stops["純"]["実定義"],"公開bank実定義":stops["bank"]["実定義"],"前後不変":True,"主人工":9,"人工確認":check,"金融結合の差":"停止114のversion114→115と要求Last==実Source quote.Lastの結合だけ。数式/公表asofは別新実装。","公開API":"verify_entry_gate(book,config,actual_context)->dict / verify_scene(native,artificial=False)->dict","市場Native/Raw/価格CSV/11月09本文読取":False,"金融/P再演算":False,"市場成功の仮定":False}
    print(json.dumps({"成功":True,"停止":V.write(target,result),"人工確認":check,"CLIコード":{"path":str(Path(V.__file__).resolve()),"sha256":V.digest(Path(V.__file__))}},ensure_ascii=False))


if __name__=="__main__":main()
