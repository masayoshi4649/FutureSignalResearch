# 115入口票のPython独立検算

Go期待値を呼ばないDecimal/三値の検算。115専用の新派生で、114/115の停止Go・114 Pythonは変更しない。金融/P演算・Raw/CSV形成は別監査とし、未作成の市場成功は仮定しない。

## 公開API

`verify_entry_gate(book,config,actual_context)->dict` と `verify_scene(native,artificial=False)->dict`。前者は成功/counts/配送と要求の独立再構成/金融損益再計算falseを返す。countsは114と同じsource_new・allowed・selected_true/false/unknown・accepted_requests/quantity・actual_new_fills/quantity・input_missing・known_denial・publications_checked。Currentは115のSnapshot/Delivered形。

独立式はFrame元値と要求LastからG30、D15、ADX15、構造境界、5分Close、Close突破差、Last保持差、TR5、前ATR5、2ATR−TR余裕、前D15、ADX増分の12値を再計算する。共通4条件・T3条件・R2条件、三値AND/OR、条件ID/op/value、missing/denialの全順を確認する。派生値のJSON/IEEE754差は1e-10pt以内、真偽・既知性・原値結合は完全一致。前ATR既知0は既知偽、未知は不足。RへADX/DI交差を追加しない。

## 配送・構造の独立証拠

CoreのEntryPublications（全原行公表）から当場5分足の直前3本を別のringで形成し、High/Low・Ref・連続性・欠足reset・現在足除外を照合する。公表は実配送StampとFrame.RecordOrdinal=Index+1、場/限月/尺度/名目/実時計へ結ぶ。

EntryEventsは元new要求のある原行だけ。全Source出生のunique Stamp集合と1対1、同原行複数出生は一つのSnapshotを共有する。全公表を要求Stampまでだけ進めて5/15/30のasof最新とSnapshotを全値照合する。同秒後原行の公表、未来/別場/旧公表への差替え、1公表1取得という追加制約を使わない。

EntryInputの予定End前史モデルとInputSeedを確認する。厳密な過去場・同限月の数値seedだけを継ぎ、SeedOnlyから技法票を立てない。seedDMIの公開値/助走本数と場内不変を照合する。旧seedTechnicalの私有全数値はSeedInfoに保存されず指紋/本数だけなので、前史のEMA/ATR/RMAをCSVから独立再算出したとは主張しない。DMI/EMA/ATRの公表形成そのものはbankの停止人工と固定入力の別証拠である。

受付/fill結合は停止114の金融結合関数を、版115と要求Lastのbindだけ明示派生した。全new分母、複合出生、選別/容量/取消、受付注文、実new fill/玉/量/原行、遅延・BBO、費用/モード間の固定票同体を検査する。Availableの全保有予約算術・金融損益・最初の正常原板行はこのモジュールで再演算しない。

## 人工と停止

RootのCore6手製ケース（買売×T/R/未知）72冊72票、純Go4手製票、境界の手計算、破壊反例、0取引、Native不存在のmetadataゲートを使う。Core人工のSource.Sourcesはnilなので、自然Source生成の独立集合証明は人工では対象外。市場時は保存Source全文の全new集合を必須にする。

`python -X utf8 人工検査.py`。Core停止後に `python -X utf8 検査して停止する.py --core-stop <絶対path> --core-sha <SHA>`。停止は所有5ファイル・純/bank/Actor/Core/旧Python停止・人工入力の指紋を固定する。市場/Raw/CSV/11月09は読まない。

## 市場CLI（Rootだけが後で実行）

新要求はversion1/trial115/fixedtrue/market_native_read_authorizedtrue/stage(first2/base54/full70)、entry_stop/entry_code/condition/completionの絶対FileRefを持つ。同じ実純・bank・Actor・Core停止、定義、全予定成功/flat/旧A0四対照/Source同体/前後不変を本文前に認証する。

`python -X utf8 検算する.py --fixed <絶対要求path> --sha256 <SHA> --output <未作成絶対path> --metadata-only` はNative本文を読まない。同じ引数からmetadata-onlyを除くと、Root解禁の成功Nativeだけを読み新しい結果を保存する。不完了を成功へ転用しない。この実装・人工停止は市場first2や全70の成功を意味しない。
