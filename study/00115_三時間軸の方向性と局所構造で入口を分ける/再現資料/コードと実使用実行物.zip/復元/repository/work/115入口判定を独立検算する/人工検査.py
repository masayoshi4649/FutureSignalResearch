"""115独立入口を手計算・停止Go/Core人工・破壊反例・本文前ゲートで確認する。"""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest

import 検算する as V

PURE_ART={"path":str(V.ROOT/"work/115三時間軸と構造の純入口/検査/人工.json"),"sha256":"f146c803673f53b9de8d00e49437e12114b7937991e545a7d1ebffece21b872e"}
CORE_ART={"path":str(V.ROOT/"work/115三時間軸の複合入口の連続比較/人工_入口独立用/Core人工.json"),"sha256":"4ff53c2bed94c512c6c3c39695d9eb57748076bd6bc885da15f7e13d6e0daa9e"}
CORE_STOP={"path":str(V.ROOT/"work/115三時間軸の複合入口の連続比較/停止.json"),"sha256":"1dca0288b00682c965491bcf0209a45a0bbc4eaf527b0224063db9bcda7f77d8"}


def fixtures() -> tuple:
    """
    機能: Rootが解禁した手製JSONだけをSHA認証する。
    引数: なし。返り値: tupleはGo純4票とCore6ケース。
    """
    before={};pure=V.load(V.reference(PURE_ART,before));core=V.load(V.reference(CORE_ART,before));V.need(pure["artificial"] and not pure["natural_source"] and core["人工"] and not core["市場"] and not core["FAR自然生成"] and len(core["results"])==6,"115手製限定");return pure,core


def gate_fixture(base: Path) -> tuple:
    """
    機能: Nativeを存在させず手製metadataで成功/拒否ゲートを検査する。
    引数: base(Path)。返り値: tupleは手製要求Refと値。市場成功とは扱わない。
    """
    base.mkdir();pure=V.load(Path(V.PURE_STOP["path"]));bank=V.load(Path(V.BANK_STOP["path"]));pd=pure["実定義"];bd=bank["実定義"]
    condition=V.write(base/"条件.json",{"trial":115,"fixed":True,"actual_configurations":list(V.CONFIGS),"dependency_stops":{"entry_gate":V.PURE_STOP,"entry_chart":V.BANK_STOP,"actor":V.ACTOR_STOP},"entry_gate_definition":V.load(Path(pd["path"])),"entry_chart_definition":V.load(Path(bd["path"])),"entry_input_model":V.MODEL,"runtime_stop":CORE_STOP,"code_sha256":{}})
    scenes=[{"session":sid,"native":{"path":str((base/(sid+".Native.json.gz")).resolve()),"sha256":"a"*64},"books":12,"complete":True,"A0_equal":True,"A0_comparisons":4,"reference114_equal":True,"reference114_comparisons":4,"source111_equal":True,"open_quantity":0,"pending_quantity":0} for sid in V.planned_sessions("first2")]
    complete=V.write(base/"完了.json",{"trial":115,"success":True,"stage":"first2","sessions":2,"books":24,"condition_sha256":condition["sha256"],"unchanged":True,"before":{"metadata":"same"},"after":{"metadata":"same"},"reused_sessions":0,"replayed_sessions":2,"all_reference114_equal":True,"all_source111_equal":True,"reference114_comparisons":8,"results":scenes})
    stopped=V.write(base/"入口停止.json",{"成功":True,"市場前":True,"試行":115,"所有ファイルSHA256":{str((V.HERE/n).resolve()):V.digest(V.HERE/n) for n in V.OWNED},"依存コードSHA256":{},"純Go停止":V.PURE_STOP,"公開bank停止":V.BANK_STOP,"Core停止":CORE_STOP,"純Go実定義":pd,"公開bank実定義":bd})
    request={"version":1,"trial":115,"fixed":True,"market_native_read_authorized":True,"stage":"first2","entry_stop":stopped,"entry_code":{"path":str(Path(V.__file__).resolve()),"sha256":V.digest(Path(V.__file__))},"condition":condition,"completion":complete};return V.write(base/"要求.json",request),request


class EntryTests(unittest.TestCase):
    """市場を読まない115独立監査。"""

    @classmethod
    def setUpClass(cls):
        """
        機能: Root手製を一度認証して各検査へ私有copyする元値を準備する。
        引数: cls(type)。返り値: None。
        """
        cls.pure,cls.core=fixtures()

    def test_truth_and_hand_arithmetic(self):
        """
        機能: 全三値9組とT人工の12値をGo期待値なしで手計算する。
        引数: self(EntryTests)。返り値: None。
        """
        for a in (0,1,2):
            for b in (0,1,2):self.assertEqual(V.I.conjunction([a,b]),1 if 1 in (a,b) else 0 if 0 in (a,b) else 2);self.assertEqual(V.I.disjunction([a,b]),2 if 2 in (a,b) else 0 if 0 in (a,b) else 1)
        d=self.pure["decisions"][0];x=V.I.calculate(d["current"]["snapshot"],1,1112)
        self.assertEqual(x["values"],dict(zip(("g30","d15","adx15","boundary","five_close","close_break","last_break","tr5","previous_atr5","spike_margin","previous_d15","adx15_delta"),map(V.I.number,(20,20,20,1100,1110,10,12,35,20,5,20,-5)))))
        self.assertEqual((x["common"],x["trend"],x["reversal"]),(2,2,1))

    def test_pure_go_four_and_core_seventy_two(self):
        """
        機能: 純4票とCore6ケース72冊の公表/前3/全new/受付fillを照合する。
        引数: self(EntryTests)。返り値: None。
        """
        for d in self.pure["decisions"]:V.verify_full_decision(d)
        values=[V.verify_scene(n,True) for n in self.core["results"].values()]
        self.assertEqual(sum(v["会計数"] for v in values),72);self.assertEqual(sum(v["全Source延べ票"] for v in values),72)

    def test_equalities_unknown_and_unused_adx(self):
        """
        機能: TR/ADX等号・Last/Close零・ATR0とADX未知R許可を手計算する。
        引数: self(EntryTests)。返り値: None。
        """
        s=deepcopy(self.pure["decisions"][0]["current"]["snapshot"]);s["scales"][0]["current"]["frame"]["technical"]["tr"]["value"]=40
        self.assertEqual(V.I.calculate(s,1,1112)["trend"],2);s["scales"][0]["current"]["frame"]["technical"]["tr"]["value"]=41;self.assertEqual(V.I.calculate(s,1,1112)["trend"],1)
        s=deepcopy(self.pure["decisions"][0]["current"]["snapshot"]);self.assertEqual(V.I.calculate(s,1,1100)["common"],1);s["scales"][0]["current"]["frame"]["technical"]["previous_atr"]["value"]=0;self.assertEqual(V.I.calculate(s,1,1112)["common"],1)
        d=deepcopy(self.pure["decisions"][1]);s=d["current"]["snapshot"];s["scales"][1]["current"]["dmi"]["adx"]["known"]=False;x=V.I.calculate(s,1,d["request"]["last"]);self.assertEqual(x["reversal"],2);self.assertIn("15m.adx",x["missing_inputs"])

    def test_decision_metadata_and_value_corruption(self):
        """
        機能: 真偽だけ合う派生値/条件ID/op/不足/否定の偽装も拒否する。
        引数: self(EntryTests)。返り値: None。
        """
        for name in ("value","truth","id","op","missing","denial","last"):
            d=deepcopy(self.pure["decisions"][0])
            if name=="value":d["values"]["g30"]+=1
            elif name=="truth":d["common"]=1
            elif name=="id":d["common_conditions"][0]["id"]="別"
            elif name=="op":d["trend_conditions"][0]["op"]="<0"
            elif name=="missing":d["missing_inputs"].append("偽不足")
            elif name=="denial":d["trend_denials"].append("偽否定")
            else:d["request"]["last"]-=1
            with self.subTest(name=name),self.assertRaises(ValueError):V.verify_full_decision(d)

    def test_asof_structure_and_seed_corruptions(self):
        """
        機能: 公表削除/構造現在足混入/未来公表/seed混用/全Event削除を拒否する。
        引数: self(EntryTests)。返り値: None。
        """
        for name in ("pub_delete","high","ref","future","event_delete","snapshot","seed","extra_event"):
            n=deepcopy(self.core["results"]["1_順行"]);a=n["actual"]
            if name=="pub_delete":a["entry_publications"].pop(0)
            elif name=="high":next(p["frame"]["structure"] for p in a["entry_publications"] if p["frame"]["structure"]["known"])["high"]+=1
            elif name=="ref":next(p["frame"]["structure"] for p in a["entry_publications"] if p["frame"]["structure"]["known"])["refs"][-1]["end"]+=300
            elif name=="future":a["entry_publications"][0]["stamp"]["index"]+=1000000
            elif name=="event_delete":a["entry_gate_events"]=[]
            elif name=="snapshot":a["entry_gate_events"][0]["snapshot"]["scales"][0]["current"]["frame"]["ohlc"]["close"]+=1
            elif name=="seed":a["entry_input"]["input_seed"]["old"]["session"]["end"]+=1000000
            else:a["entry_gate_events"].append(deepcopy(a["entry_gate_events"][0]))
            with self.subTest(name=name),self.assertRaises(ValueError):V.verify_scene(n,True)

    def test_source_request_last_fill_denominators(self):
        """
        機能: 要求Last・元出生・選別・受付量・実取得・全new分母の改変を拒否する。
        引数: self(EntryTests)。返り値: None。
        """
        for name in ("last","source","allowed","accepted","fill","denominator"):
            n=deepcopy(self.core["results"]["1_順行"]);b=n["actual"]["books"]["A0_C0_D0"];r=b["entry_gate"]["records"][0]
            if name=="last":r["request"]["last"]+=1
            elif name=="source":r["source"]["birth_time"]+=1
            elif name=="allowed":r["allowed"]=False
            elif name=="accepted":r["accepted_quantity"]+=1
            elif name=="fill":r["actual_quantity"]+=1
            else:b["entry_gate"]["records"]=[]
            with self.subTest(name=name),self.assertRaises(ValueError):V.verify_scene(n,True)

    def test_zero_books_and_natural_source_requirement(self):
        """
        機能: 自然Source全文不足を拒否し、0要求の人工12冊と空/nullを保持する。
        引数: self(EntryTests)。返り値: None。
        """
        n=deepcopy(self.core["results"]["1_未知"])
        with self.assertRaises(ValueError):V.verify_scene(n,False)
        n["actual"]["entry_gate_events"]=[]
        for b in n["actual"]["books"].values():
            for key in ("positions","orders","fills","source_events"):b[key]=None
            b["entry_gate"]["records"]=[]
            for k in b["metrics"]:b["metrics"][k]=0
        x=V.verify_scene(n,True);self.assertEqual(x["会計数"],12);self.assertEqual(x["全Source延べ票"],0)

    def test_fee_mode_same_and_inputs_unchanged(self):
        """
        機能: 費用間の票差を拒否し、監査が手製入力を変更しないことを確認する。
        引数: self(EntryTests)。返り値: None。
        """
        n=deepcopy(self.core["results"]["1_反転"]);before=repr(n);V.verify_scene(n,True);self.assertEqual(before,repr(n))
        n["actual"]["books"]["TR_C5_D1"]["entry_gate"]["records"][0]["decision"]["scope"]["contract"]="別"
        with self.assertRaises(ValueError):V.verify_scene(n,True)

    def test_gate_before_native(self):
        """
        機能: 手製成功metadataだけで本文前認証と未解禁/未完了/停止差の拒否を検査する。
        引数: self(EntryTests)。返り値: None。
        """
        with tempfile.TemporaryDirectory(dir=V.HERE) as tmp:
            base=Path(tmp);ref,q=gate_fixture(base/"人工");plan=V.prepare(Path(ref["path"]),ref["sha256"],base/"未作成先");self.assertEqual(len(plan["complete"]["results"]),2);self.assertTrue(all(not Path(r["native"]["path"]).exists() for r in plan["complete"]["results"]))
            for name in ("解禁","コード","未完了","欠場"):
                bad=deepcopy(q)
                if name=="解禁":bad["market_native_read_authorized"]=False
                elif name=="コード":bad["entry_code"]["sha256"]="0"*64
                else:
                    c=V.load(Path(bad["completion"]["path"]))
                    if name=="未完了":c["success"]=False
                    else:c["results"].pop()
                    bad["completion"]=V.write(base/(name+"完了.json"),c)
                denied=V.write(base/(name+"要求.json"),bad)
                with self.subTest(name=name),self.assertRaises(ValueError):V.prepare(Path(denied["path"]),denied["sha256"],base/(name+"新規先"))


if __name__=="__main__":unittest.main(verbosity=2)
