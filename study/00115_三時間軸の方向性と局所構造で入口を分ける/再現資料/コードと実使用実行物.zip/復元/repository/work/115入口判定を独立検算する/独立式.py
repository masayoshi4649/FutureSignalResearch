"""Goを呼ばず、115の公表元値と要求Lastから十二値・三値・不足理由を再計算する。"""
from decimal import Decimal

UNKNOWN,FALSE,TRUE=0,1,2


def need(value: bool,label: str) -> None:
    """
    機能: 数式/出典の不一致を拒否する。
    引数: value(bool)、label(str)。返り値: None。不成立はValueError。
    """
    if not value:raise ValueError(label)


def number(value) -> Decimal:
    """
    機能: 有限JSON数値だけを十進数へ写す。
    引数: value(int/float/Decimal)。返り値: Decimal。bool/文字列は不正。
    """
    need(type(value) in (int,float,Decimal),"数値型");v=Decimal(str(value));need(v.is_finite(),"有限数値");return v


def conjunction(values: list[int]) -> int:
    """
    機能: 既知偽が未知に優先する三値ANDを計算する。
    引数: values(list[int])。返り値: intは0不明/1偽/2真。
    """
    need(bool(values) and all(type(v) is int and v in (0,1,2) for v in values),"三値AND入力");return FALSE if FALSE in values else UNKNOWN if UNKNOWN in values else TRUE


def disjunction(values: list[int]) -> int:
    """
    機能: 既知真が未知に優先する三値ORを計算する。
    引数: values(list[int])。返り値: intは0不明/1偽/2真。
    """
    need(bool(values) and all(type(v) is int and v in (0,1,2) for v in values),"三値OR入力");return TRUE if TRUE in values else UNKNOWN if UNKNOWN in values else FALSE


def value(field: dict) -> Decimal | None:
    """
    機能: 個別Knownと数値0を区別して公開値を読む。
    引数: field(dict)。返り値: Decimal|Noneは既知値又は不足。
    """
    need(type(field["known"]) is bool,"Value既知旗");v=number(field["value"]);return v if field["known"] else None


def condition(identity: str,v: Decimal | None,op: str) -> dict:
    """
    機能: 宣言された不等号を有限十進数で独立評価する。
    引数: identity/op(str)、v(Decimal|None)。返り値: dictは原値と三値。
    """
    need(op in (">0","<0",">=0",">=20"),"115条件演算")
    passed=None if v is None else v>0 if op==">0" else v<0 if op=="<0" else v>=0 if op==">=0" else v>=20
    return {"id":identity,"value":v,"op":op,"truth":UNKNOWN if passed is None else TRUE if passed else FALSE}


def calculate(snapshot: dict,side: int,last) -> dict:
    """
    機能: Snapshotだけの公表値から共通/T/Rと十二値を再計算する。
    引数: snapshot(dict)、side(int)、last(int/float/Decimal)。返り値: dictは元値/票/不足。
    """
    need(side in (-1,1),"売買方向");last=number(last);need(last>0,"要求Last正");s=Decimal(side)
    names=("g30","d15","adx15","boundary","five_close","close_break","last_break","tr5","previous_atr5","spike_margin","previous_d15","adx15_delta");values=dict.fromkeys(names);missing=[]
    need([x["width_seconds"] for x in snapshot["scales"]]==[300,900,1800],"三尺度順")
    for x in snapshot["scales"]:
        w=x["width_seconds"];f=x["current"]["frame"];t=f["technical"];ok=x["has_current"] and x["fresh"] and not x["seed_only"] and f["price_known"];prefix={300:"5m",900:"15m",1800:"30m"}[w]
        if not ok:missing.append(prefix+".current_fresh_price")
        if w==300:
            st=x["current"]["structure"]
            if ok and st["known"]:
                boundary=number(st["high"] if side==1 else st["low"]);close=number(f["ohlc"]["close"]);values.update(boundary=boundary,five_close=close,close_break=s*(close-boundary),last_break=s*(last-boundary))
            else:missing.append("5m.previous3_structure")
            if ok and t["tr"]["known"]:values["tr5"]=value(t["tr"])
            else:missing.append("5m.tr")
            if ok and t["previous_atr"]["known"]:values["previous_atr5"]=value(t["previous_atr"])
            else:missing.append("5m.previous_atr14")
            if values["tr5"] is not None and values["previous_atr5"] is not None:values["spike_margin"]=2*values["previous_atr5"]-values["tr5"]
        elif w==900:
            d=x["current"]["dmi"]
            if ok and d["plus_di"]["known"] and d["minus_di"]["known"]:values["d15"]=s*(value(d["plus_di"])-value(d["minus_di"]))
            else:missing.append("15m.di")
            if ok and d["adx"]["known"]:values["adx15"]=value(d["adx"])
            else:missing.append("15m.adx")
            if ok and d["previous_plus_di"]["known"] and d["previous_minus_di"]["known"]:values["previous_d15"]=s*(value(d["previous_plus_di"])-value(d["previous_minus_di"]))
            if ok and d["adx"]["known"] and d["previous_adx"]["known"]:values["adx15_delta"]=value(d["adx"])-value(d["previous_adx"])
        else:
            if ok and t["ema8"]["known"] and t["ema21"]["known"]:values["g30"]=s*(value(t["ema8"])-value(t["ema21"]))
            else:missing.append("30m.ema8_ema21")
    common=[condition(i,values[n],op) for i,n,op in (("C.CloseBreak","close_break",">0"),("C.PreviousATR","previous_atr5",">0"),("C.SpikeMargin","spike_margin",">=0"),("C.LastHold","last_break",">0"))]
    trend=[condition(i,values[n],op) for i,n,op in (("T.G30","g30",">0"),("T.D15","d15",">0"),("T.ADX15","adx15",">=20"))]
    reversal=[condition(i,values[n],op) for i,n,op in (("R.G30","g30","<0"),("R.D15","d15",">0"))]
    c=conjunction([x["truth"] for x in common]);t=conjunction([c,conjunction([x["truth"] for x in trend])]);r=conjunction([c,conjunction([x["truth"] for x in reversal])]);cd=[x["id"] for x in common if x["truth"]==FALSE]
    return {"values":values,"common":c,"trend":t,"reversal":r,"combined":disjunction([t,r]),"common_conditions":common,"trend_conditions":trend,"reversal_conditions":reversal,"missing_inputs":missing,"common_denials":cd,"trend_denials":cd+[x["id"] for x in trend if x["truth"]==FALSE],"reversal_denials":cd+[x["id"] for x in reversal if x["truth"]==FALSE]}


def verify_decision(decision: dict) -> dict:
    """
    機能: 保存Go票を独立式へ照合し値許容差と真偽完全一致を分ける。
    引数: decision(dict)。返り値: dictは値/条件/複合票の確認数。
    """
    need(decision["version"]==115 and decision["frozen"] is True and decision["current"] is not None,"115凍結票")
    expected=calculate(decision["current"]["snapshot"],decision["request"]["side"],decision["request"]["last"])
    for name,n in expected["values"].items():
        actual=decision["values"][name];need(actual is None and n is None or actual is not None and n is not None and abs(number(actual)-n)<=Decimal("1e-10"),"115派生数値:"+name)
    for name in ("common","trend","reversal","combined","missing_inputs","common_denials","trend_denials","reversal_denials"):need(decision[name]==expected[name],"115独立票/理由:"+name)
    for name in ("common_conditions","trend_conditions","reversal_conditions"):
        need(len(decision[name])==len(expected[name]),"条件数")
        for a,b in zip(decision[name],expected[name]):
            need(a["id"]==b["id"] and a["op"]==b["op"] and a["truth"]==b["truth"] and a["value"]==decision["values"][{"C.CloseBreak":"close_break","C.PreviousATR":"previous_atr5","C.SpikeMargin":"spike_margin","C.LastHold":"last_break","T.G30":"g30","T.D15":"d15","T.ADX15":"adx15","R.G30":"g30","R.D15":"d15"}[a["id"]]],"115条件metadata/原値")
    return {"値":12,"条件票":9,"複合票":4,"公表数":sum(x["has_current"] for x in decision["current"]["snapshot"]["scales"])}
