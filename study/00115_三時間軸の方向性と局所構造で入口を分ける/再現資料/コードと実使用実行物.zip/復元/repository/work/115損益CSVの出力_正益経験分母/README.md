# 115の損益CSV出力

CSVは候補別集計と全セッションの二点だけ。共通保護政策はP100、候補は入口モードA0/T/TRで表示する。Root解禁後の実出力予定は12候補費用・全70場840行、0取引場も保持。金額・勝負同値・PF・平均利益損失・保存点DD・正益後赤字・実保有秒/数量秒と、元新規要求・許可・採用モード票の真/偽/未知・入力不足・否定・受付・実取得を併記する。固定5分/15分参加率は作らない。

入口の分母は成立取引数と別。source_newは元new要求、allowedは入口票の許可、acceptedは容量/取消を反映した新規要求/枚数、actualは実fill/枚数。A0のselected票は全許可であり、元のT/R票が常に真だった意味ではない。input_missingとknown_denialはT/Rの入力不足又はいずれかの既知否定を含む要求数で、互いにも許可件数にも重複し得る。各行の保存監査countsへ一致させる。実取得枚数の元field名はactual_quantity。

Node v24.22.1、@oai/artifact-tool 2.8.129の提供cacheを使用する。親cache node_modulesへのjunctionをこの作業フォルダに置き、依存そのものは改変しない。表上で費用控除と候補内累計を再計算してCSV値へ出し、標準csv/Decimalの別コードで全セル・合算・率を再読する。数値比較数はその実行で数え、旧114等の数を使い回さない。

開始日はセッションIDの日付をJSTとして、@文字列書式を先に適用し、CSV値もYYYY-MM-DD JSTとする。CSVはUTF-8 BOM/CRLF・一段ヘッダ、未定義比率は空欄。xlsxは一切生成しない。人工プレビューPNGはworkにだけ置く。

## Root指定後の実行

成功全70の独立結果JSONとSHAをRootが指定するまで、実結果や実CSVを読まない。出力先は未作成先だけ。Root解禁flag又は人工flagがないと入力本文の前に拒否する。

```powershell
& <提供Node24の絶対path> work/115損益CSVの出力/出力する.mjs <独立結果JSON> <SHA256> <未作成CSV先> --root-authorized
python -X utf8 work/115損益CSVの出力/CSVを独立再読する.py --result <独立結果JSON> --sha256 <SHA256> --folder <CSV先> --output <新規確認JSON> --root-authorized
```

人工は同じ12候補×2場の手製値でstage=artificial/人工=trueとし、利益/損失/0取引・未定義比率・入口未知/否定・集計Counterの0省略を含める。実Native/Raw/CSVを使わない。`人工を実行して停止する.py`は操作markerを最初の表作成直前に一度呼び、二CSVの生成・独立再読・改変拒否・日付文字列・xlsx非生成を検査して新規停止へ固定する。

115のTは30分EMA配置・15分DI方向/ADX・5分前3本構造のClose突破/値幅・要求時Last保持、TRはT又は逆30分配置からのRを表す。114の同名モードとは入口定義が違う。保護P100と連続判断は同体で、指標足幅を新規の固定判断時計にしない。今の停止準備は手製2場だけで、first2や未完成の実全70結果は読まない。

操作markerは115の最初の人工表作成直前に一度だけ発行し、操作markerの記録.jsonへ残す。同じ作業の再確認や後日のRoot実全70出力で再発行しない。

## 正益経験の分母

候補別44列・場別40列へ、費用後正益を経験した建玉数（whole_positive_positions）と正益経験建玉の最終赤字率パーセントを追加する。率はwhole_positive_closed_negative / whole_positive_positions ×100。0分母は空欄で、経験玉の件数そのものや全取引に対する率とは区別する。候補別は全場の分子・分母を加算してから計算し、場別率を平均/加算しない。取引数減と率改善も別に評価する。

元の0d45版はworkに保持し、この新派生だけを最終CSV二点へ使う。金融/P100条件は変えない。115の既marker記録をSHA参照し、新規markerを発行しない。
