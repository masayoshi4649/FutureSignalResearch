package entrycomparison115

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"path/filepath"

	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	entrybank "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
	input "github.com/masayoshi4649/SessionTradeExecuter/threeframeinput"
)

const EntryInputModel = "prior_csv_publications_through_scheduled_end_current_raw_delivery115"

// SeedNode は予定Endまでに公表済みとする過去場の数値種の因果連鎖です。
type SeedNode struct {
	Session        frame.Session       `json:"session"`
	CSV            frame.FileRef       `json:"csv"`
	Input          *entrybank.SeedInfo `json:"input_seed"`
	Output         entrybank.SeedInfo  `json:"output_seed"`
	ChildrenSHA256 string              `json:"children_sha256"`
}

// EntryInputAudit は前史の予定公表モデルと当場の実配送を分けます。
type EntryInputAudit struct {
	Model            string              `json:"model"`
	CSV              frame.FileRef       `json:"csv"`
	ChildrenSHA256   string              `json:"children_sha256"`
	PriorSessions    int                 `json:"prior_sessions"`
	PriorNodesSHA256 string              `json:"prior_nodes_sha256"`
	InputSeed        *entrybank.SeedInfo `json:"input_seed"`
	EndSeed          entrybank.SeedInfo  `json:"end_seed"`
}

// PublicationInput は数値seedと当場の固定子足だけを配送器へ渡します。
type PublicationInput struct {
	Session  frame.Session
	Children []frame.ChildBar
	Seed     *entrybank.Seed
	Audit    EntryInputAudit
}

// EntryPreparation は私有seedと、再現に必要な前史metadataを分けます。
type EntryPreparation struct {
	Input PublicationInput `json:"-"`
	Prior []SeedNode       `json:"prior"`
	Audit EntryInputAudit  `json:"audit"`
}

// valueSHA は有限の監査値を決定的な指紋へ結びます。
//
// 引数: value(any)は子足又は前史metadataです。
// 返り値: string/errorはSHA256又は符号化異常です。
func valueSHA(value any) (string, error) {
	raw, err := json.Marshal(value)
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:]), nil
}

// PrepareEntryInput は対象場より前だけを予定Endまで公表した独立前史を作ります。
//
// 引数: p(RunPlan)、index(int)は認証済み115条件と、その段階の対象場位置です。
// 返り値: EntryPreparation/errorは当場専用入力又はCSV/時計/種の不整合です。
// 前史は次場開始までにCSVが取得済みとのモデルで、Sourceの実EOFは再現しません。
func PrepareEntryInput(p RunPlan, index int) (EntryPreparation, error) {
	out := EntryPreparation{Prior: []SeedNode{}}
	if p.Fixed.Trial != 115 || !p.Fixed.Fixed || p.Fixed.EntryInputModel != EntryInputModel || index < 0 || index >= len(p.Source.Cases) || index >= len(p.Source.Manifest.Sessions) {
		return out, fmt.Errorf("115固定と対象場が必要")
	}
	var previous *entrybank.Seed
	for i := 0; i <= index; i++ {
		item := p.Source.Manifest.Sessions[i]
		if item.ID != p.Source.Cases[i].ID {
			return out, fmt.Errorf("入口前史のmanifest順序差")
		}
		clock, err := source.SessionFor(item.ID)
		if err != nil {
			return out, err
		}
		session := frame.Session{ID: item.ID, Contract: item.Contract, Start: clock.Start, End: clock.End, EOF: clock.End}
		f, ok := item.Files["NK225_candle_300"]
		if !ok {
			return out, fmt.Errorf("5分CSV参照がない")
		}
		csv := frame.FileRef{Path: filepath.Join(p.Source.Manifest.Root, filepath.FromSlash(f.Path)), SHA256: f.SHA256, Bytes: f.Size}
		loaded, err := input.LoadChildren(session, csv)
		if err != nil {
			return out, err
		}
		childrenSHA, err := valueSHA(loaded.Bars)
		if err != nil {
			return out, err
		}
		var prior *entrybank.SeedInfo
		if previous != nil {
			x := previous.Info()
			prior = &x
		}
		if i == index {
			prefixSHA, err := valueSHA(out.Prior)
			if err != nil {
				return out, err
			}
			out.Audit = EntryInputAudit{Model: EntryInputModel, CSV: csv, ChildrenSHA256: childrenSHA, PriorSessions: len(out.Prior), PriorNodesSHA256: prefixSHA, InputSeed: prior}
			out.Input = PublicationInput{Session: session, Children: loaded.Bars, Seed: previous, Audit: out.Audit}
			return out, nil
		}
		// ----------------------------------------
		// 過去場だけを予定Endまで進める。当場の未来公表や終端種を入口へ渡さない。
		bank, err := entrybank.BeginSession(session, loaded.Bars, previous)
		if err != nil {
			return out, err
		}
		if _, err = bank.AdvanceObserved(session.End, 1); err != nil {
			return out, err
		}
		seed, _, err := bank.Seal()
		if err != nil {
			return out, err
		}
		out.Prior = append(out.Prior, SeedNode{Session: session, CSV: csv, Input: prior, Output: seed.Info(), ChildrenSHA256: childrenSHA})
		next := seed
		previous = &next
	}
	return out, fmt.Errorf("当場入力の作成に到達しなかった")
}
