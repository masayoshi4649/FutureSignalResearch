"""115の入口三モード接続と独立場並列を人工・全閉包・exeで市場前停止する。"""

import ast
from datetime import datetime, timezone
import hashlib
import json
import os
import re
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DEPENDENCIES = {
 'source': ('111元時計の連続再現/停止.json','08b1331b372d5cd7e50d46d90c247a8fa9c6a9bf657105ff181928041f156946'),
 'chart': ('111連続保護のチャート公開/停止.json','38c01e07d276310c6c1d803dca11e27979fc9286cf64d9a495e60485ea7264bd'),
 'core114': ('114順行と反転取得の連続比較/停止.json','8e48f8c008a3bb6ab72ef9ec21f2b474dc403c79aa4a6b1a34f7b1d30d0ae729'),
 'actor': ('115三時間軸の複合入口を執行する会計/Actor停止.json','318de27a32a0941114443e5045426df3599eea74e8e5ffa8647771e92934ce35'),
 'pure': ('113起動前の支持否定と利益保護の純演算/停止.json','81f54d965ef8d81c65a7b58f4d376374b79c765e1ad4ada5cc6270159e4ed312'),
 'entry_gate': ('115三時間軸と構造の純入口/停止.json','50bd192518a88c4fe087ccae052ecc3d312fccabf3c8c1f230cdd8391e8c133a'),
 'entry_chart': ('115三時間軸と方向性の公開/検査_停止版/停止.json','df5718acf04495bc690c5a0d0652ba202cb9f970eb2323389f246d70cdbe7a68'),
 'entry_input': ('三時間軸の市場入力口/停止.json','820a819d284a58c5057150bb415ac3fd57c34473abda4b18467c42dba9e95782'),
}
NAMES = ('runtime.go','runtime_test.go','source_fixture_test.go','fixed.go','fixed_test.go','entry_input.go','entry_input_test.go',
 'runner/parallel.go','runner/parallel_test.go','runner/process_windows.go','runner/process_other.go','cmd/run/main.go',
 'go.mod','go.sum','README.md','検査して停止する.py','派生の参照.json')




def digest(path: Path) -> str:
    """機能: 明示コードと人工の全bytes指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def merge(target: dict, values: dict) -> None:
    """機能: Root相対位置を絶対化して停止mapを統合する。

    引数: target/values(dict)は統合先と固定値。
    返り値: None。現物差と衝突はValueError。
    """
    for name, sha in values.items():
        path = Path(name)
        path = (path if path.is_absolute() else ROOT / path).resolve()
        if digest(path) != sha or (str(path) in target and target[str(path)] != sha):
            raise ValueError('停止codeの現物差:' + str(path))
        target[str(path)] = sha


def execute(command: list[str], label: str, env: dict) -> dict:
    """機能: 市場を使わない人工・閉包・ビルドの終了を検査する。

    引数: command(list[str])、label(str)、env(dict)は起動と環境。
    返り値: dictは成功ログ。不成功はValueError。
    """
    result = subprocess.run(command, cwd=HERE, env=env, capture_output=True, text=True, encoding='utf-8')
    row = {'名': label, 'command': command, '終了コード': result.returncode, '標準出力': result.stdout, '標準エラー': result.stderr}
    if result.returncode:
        raise ValueError(json.dumps(row, ensure_ascii=False))
    return row


def go_closure(env: dict) -> tuple[dict, dict]:
    """機能: 実際の並列cmdの全選択ソースと標準ライブラリを固定する。

    引数: env(dict)はCGO0の環境。
    返り値: tuple[dict,dict]は非GoRootとGoRoot。
    """
    stream = execute(['go', 'list', '-deps', '-json', './cmd/run'], '実Go閉包', env)['標準出力']
    decoder, index, local, standard = json.JSONDecoder(), 0, {}, {}
    while index < len(stream):
        while index < len(stream) and stream[index].isspace():
            index += 1
        if index == len(stream):
            break
        package, index = decoder.raw_decode(stream, index)
        if not package.get('Dir'):
            continue
        target = standard if package.get('Goroot') else local
        for key in ('GoFiles', 'CgoFiles', 'SFiles', 'HFiles', 'SysoFiles', 'EmbedFiles'):
            for name in package.get(key, []):
                path = (Path(package['Dir']) / name).resolve()
                target[str(path)] = digest(path)
        module = package.get('Module', {})
        if module.get('GoMod'):
            path = Path(module['GoMod']).resolve()
            local[str(path)] = digest(path)
            if path.with_name('go.sum').exists():
                local[str(path.with_name('go.sum'))] = digest(path.with_name('go.sum'))
    return local, standard


def reference(path: Path) -> dict:
    """機能: 2キーの実FileRefを作る。

    引数: path(Path)は小metadata又は実行物。
    返り値: dictは絶対pathとSHA256。
    """
    return {'path': str(path.resolve()), 'sha256': digest(path)}


def save_new(path: Path, value: dict) -> None:
    """機能: 日本語UTF8とLFで小metadataを新規保存する。

    引数: path(Path)、value(dict)は未使用先と保存値。
    返り値: None。既存先は拒否する。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main() -> None:
    """機能: 115の接続/並列と実依存を市場前停止しRoot固定素材を返す。

    引数: なし。原板/価格CSV/市場Native/11月09は読まない。
    返り値: None。人工/閉包/自己前後差や既存停止を拒否する。
    """
    if (HERE / '停止.json').exists() or (HERE / '条件の素材.json').exists():
        raise ValueError('停止と素材は新規only')
    inherited, deps, stops = {}, {}, {}
    for key, (name, sha) in DEPENDENCIES.items():
        path = (ROOT / 'work' / name).resolve()
        if digest(path) != sha:
            raise ValueError('依存停止現物差:' + key)
        value = json.loads(path.read_text(encoding='utf-8-sig'))
        if value.get('成功') is not True or (key != 'entry_input' and value.get('停止') is not True):
            raise ValueError('部品未停止:' + key)
        deps[key], stops[key] = reference(path), value
        for field in ('所有コードSHA256', '全固定コードSHA256', 'Go閉包SHA256',
                      'GoRootコードSHA256', '再用コードSHA256', '実Go依存SHA256', '実Go依存コードSHA256'):
            merge(inherited, value.get(field, {}))
        merge(inherited, {str(path): sha})
    actual_ref = stops['actor']['実12宣言']
    pure_ref = stops['pure']['実宣言']
    entry_ref = stops['entry_gate']['実定義']
    chart_ref = stops['chart']['実API宣言']
    entry_chart_ref = stops['entry_chart']['実定義']
    for ref in (actual_ref, pure_ref, entry_ref, chart_ref, entry_chart_ref):
        merge(inherited, {ref['path']: ref['sha256']})
    owned = {str((HERE / name).resolve()): digest(HERE / name) for name in NAMES}
    for name in NAMES:
        if name.endswith('.py'):
            for node in ast.walk(ast.parse((HERE / name).read_text(encoding='utf-8-sig'))):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    doc = ast.get_docstring(node) or ''
                    if '\n' not in doc or any(s not in doc for s in ('機能', '引数', '返り値')):
                        raise ValueError('関数コメント不足:' + node.name)
    env = dict(os.environ, CGO_ENABLED='0', GOWORK='off',
               EXPORT115_CORE=str(HERE / '人工_停止版_金融'),
               PARALLEL115_ART_OUT=str(HERE / '人工_停止版_I_O'))
    local, standard = go_closure(env)
    allowed = (HERE, ROOT / 'work/115三時間軸の複合入口を執行する会計',
               ROOT / 'work/115三時間軸と構造の純入口',ROOT / 'work/115三時間軸と方向性の公開')
    for name in local:
        if name not in inherited and not any(Path(name).is_relative_to(folder) for folder in allowed):
            raise ValueError('旧閉包と新115部品以外の追加:' + name)
    full = dict(inherited)
    for codes in (local, standard, owned):
        merge(full, codes)
    directory = HERE / '検査'
    directory.mkdir(exist_ok=False)
    logs = [execute(['go', 'test', '-json', '-count=1', './...'], '全接続と並列人工', env),
            execute(['go', 'vet', './...'], 'vet', env),
            execute(['go', 'build', '-o', str(directory / '115連続比較.exe'), './cmd/run'], '115実行物', env),
            execute(['go', 'doc', '-all', '.'], '接続公開API', env),
            execute(['go', 'doc', '-all', './runner'], '並列公開API', env)]
    tests = [json.loads(line) for line in logs[0]['標準出力'].splitlines() if line.startswith('{')]
    passed = [row for row in tests if row.get('Action') == 'pass' and row.get('Test')]
    primary = [row for row in passed if '/' not in row['Test']]
    secondary = [row for row in passed if '/' in row['Test']]
    expected_tests = {name for item in NAMES if item.endswith('_test.go')
                      for name in re.findall(r'func (Test\w+)\(', (HERE / item).read_text(encoding='utf-8'))}
    if {row['Test'] for row in primary} != expected_tests:
        raise ValueError('必要な主人工の欠落/追加差')
    if owned != {name:digest(Path(name)) for name in owned} or any(digest(Path(name))!=sha for name,sha in full.items()):
        raise ValueError('自己/全閉包の前後差')
    public_dir, stopped_dir = HERE / '人工_入口独立用_新規原行', HERE / '人工_停止版_金融'
    if digest(public_dir / 'Core人工.json') != digest(stopped_dir / 'Core人工.json'):
        raise ValueError('独立へ渡したCore人工と停止時出力の差')
    artificial = {str(path.resolve()):digest(path) for folder in ('人工_停止版_金融','人工_停止版_I_O')
                  for path in sorted((HERE / folder).rglob('*')) if path.is_file()}
    api = directory / 'API.txt'
    with api.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(logs[3]['標準出力'] + '\n' + logs[4]['標準出力'])
    exe = directory / '115連続比較.exe'
    stopped = {'成功': True, '停止': True, 'trial': 115, 'UTC': datetime.now(timezone.utc).isoformat(),
               '所有コードSHA256': owned, 'Go閉包SHA256': local, 'GoRootコードSHA256': standard,
               '依存コードSHA256': inherited, '全固定コードSHA256': full, '依存停止': deps,
               '実行物': reference(exe), '実Actor宣言': actual_ref, '実純保護宣言': pure_ref,
               '実入口宣言': entry_ref, '実チャート宣言': chart_ref, '実入口公開宣言':entry_chart_ref, '実API': reference(api),
               '主test': len(primary), '副test': len(secondary), '人工SHA256': artificial,
               '検査ログ': logs, '自己コード全依存前後不変': True,
               'parallel_method': 'isolated_session_process115_v1', 'parallel_max_workers': 16,
               'Source111とChart111変更': False, 'P113共通P100保護変更': False,
               'A0旧114A0四費用のCore終端全金融対照':True, '旧114A0毎原行はActor停止へ参照':True, 'Source人工通知の前後不変':True, 'FAR自然生成':False,
               '元oracle54参照再用': True, '市場全tickState同体証明': False,
               'Raw/市場Native/実価格CSV/11月09本文読取': 0, '採用': False, '研究目標達成': False}
    save_new(HERE / '停止.json', stopped)
    stop_ref = reference(HERE / '停止.json')
    code_map = dict(full)
    code_map[stop_ref['path']] = stop_ref['sha256']
    trial113 = ROOT / 'study/00114_順行と反転の取得確認を分ける'
    condition_ref = reference(trial113 / '検査/condition.json')
    if condition_ref['sha256'] != 'b0bf17c4bcd435dcca13da12995a11a9c6f5617f86a27ca2f0994528a3823167':
        raise ValueError('旧114金融条件差')
    old = json.loads(Path(condition_ref['path']).read_text(encoding='utf-8-sig'))
    actual = json.loads(Path(actual_ref['path']).read_text(encoding='utf-8-sig'))
    pure = json.loads(Path(pure_ref['path']).read_text(encoding='utf-8-sig'))
    entry = json.loads(Path(entry_ref['path']).read_text(encoding='utf-8-sig'))
    protection = [row for row in pure['definitions'] if row['policy'] == 'P100']
    configurations = [row for row in pure['configurations'] if row['policy'] == 'P100']
    if len(protection) != 1 or len(configurations) != 4 or len(actual) != 12:
        raise ValueError('共通P100と三モード12の宣言数差')
    material = {'version': 1, 'trial': 115, 'fixed': False,
                'policy': 'original166_source111_p100_entry_confirmation115', 'source_trial': 111,
                'FAR_commit': old['FAR_commit'], 'strategy_commit': old['strategy_commit'],
                'manifest': old['manifest'], 'executable': reference(exe), 'code_sha256': code_map,
                'runtime_stop': stop_ref, 'dependency_stops': deps,
                'actual_policy': 'p100_entry_confirmation115', 'chart_seed_mode': 'cold_each_session',
                'entry_grid_seconds': None, 'extra_opening_quiet_seconds': 0,
                'actual_configurations': actual, 'protection_configurations': configurations,
                'protection_definition': protection[0], 'entry_gate_definition': entry,
                'actual_declaration': actual_ref, 'pure_declaration': pure_ref,
                'entry_gate_declaration': entry_ref, 'chart_declaration': chart_ref,
                'entry_input_model':'prior_csv_publications_through_scheduled_end_current_raw_delivery115',
                'entry_chart_definition':json.loads(Path(entry_chart_ref['path']).read_text(encoding='utf-8-sig')),
                'entry_chart_declaration':entry_chart_ref,
                'original166_references': old['original166_references'],
                'reference114': {'condition': condition_ref, 'market': reference(trial113 / '検査/market.json'),
                                 'native_catalog': reference(trial113 / '成果物_金融/Native参照台帳.json')},
                'parallel_method': 'isolated_session_process115_v1', 'parallel_max_workers': 16}
    save_new(HERE / '条件の素材.json', material)
    print(json.dumps({'成功': True, '停止': stop_ref, '素材': reference(HERE / '条件の素材.json'),
                      '実行物': reference(exe), '主test': len(primary), '副test': len(secondary),
                      '全固定': len(full)}, ensure_ascii=False))


if __name__ == '__main__':
    main()


