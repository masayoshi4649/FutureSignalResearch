package entrycomparison115

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	actor "github.com/masayoshi4649/SessionTradeExecuter/continuousactor115"
	legacy "github.com/masayoshi4649/SessionTradeExecuter/entrycomparison114"
	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate115"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	bank "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

// valueCopy は手製の源通知器具の値だけを独立複写します。
//
// 引数: value(T)は人工通知です。返り値: Tは共有のない写しです。
func valueCopy[T any](value T) T { return copyValue(value) }

// children115 は当場格子の人工5分足を売買鏡像で作ります。
//
// 引数: s(frame.Session)、side(int)、prior/reversal(bool)、future(float64)は人工条件です。
// 返り値: []frame.ChildBarは市場ファイルに由来しない確定足です。
func children115(s frame.Session, side int, prior, reversal bool, future float64) []frame.ChildBar {
	out := []frame.ChildBar{}
	count := int((s.End - s.Start) / 300)
	for i := 0; i < count; i++ {
		price := 1000 + 5*float64(i)
		if prior {
			price = 1000 - 5*float64(count-i)
			if reversal {
				price = 1000 + 5*float64(count-i)
			}
		}
		if !prior && i > 20 {
			price += future
		}
		x := frame.OHLC{Open: price, High: price + 6, Low: price - 2, Close: price + 5}
		if side < 0 {
			x = frame.OHLC{Open: 2000 - x.Open, High: 2000 - x.Low, Low: 2000 - x.High, Close: 2000 - x.Close}
		}
		out = append(out, frame.ChildBar{Start: s.Start + float64(i)*300, End: s.Start + float64(i+1)*300, OHLC: x, Closed: true, Input: frame.FileRef{Path: "人工CSV", SHA256: strings.Repeat("1", 64), Bytes: 1}, Row: uint64(i + 2)})
	}
	return out
}

// input115 は過去12時間の数値種と、別所有の当場足を構成します。
//
// 引数: t(*testing.T)、side(int)、reversal(bool)、future(float64)は人工条件です。
// 返り値: PublicationInputは私有前史と当場を分離した入力です。
func input115(t *testing.T, side int, reversal bool, future float64) PublicationInput {
	t.Helper()
	s := session94()
	before := frame.Session{ID: "人工前場", Contract: "人工限月", Start: s.Start - 46800, End: s.Start - 3600, EOF: s.Start - 3600}
	b, err := bank.BeginSession(before, children115(before, side, true, reversal, 0), nil)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = b.AdvanceObserved(before.End, 1); err != nil {
		t.Fatal(err)
	}
	seed, _, err := b.Seal()
	if err != nil {
		t.Fatal(err)
	}
	info := seed.Info()
	current := frame.Session{ID: s.ID, Contract: "人工限月", Start: s.Start, End: s.End, EOF: s.End}
	return PublicationInput{Session: current, Children: children115(current, side, false, false, future), Seed: &seed, Audit: EntryInputAudit{Model: EntryInputModel, PriorSessions: 1, InputSeed: &info}}
}

// hand115 は連続Sourceと同じAPI順で、独立入口だけを比較します。
//
// 引数: t(*testing.T)、side(int)、reversal/early(bool)、future(float64)は人工条件です。
// 返り値: ReplayResultは完結した12口座と旧114A0四対照です。
func hand115(t *testing.T, side int, reversal, early bool, future float64) ReplayResult {
	t.Helper()
	input := input115(t, side, reversal, future)
	c, old := NewWithEntry(input), legacy.New()
	scene := source.SourceCase{Session: session94(), Contract: "人工限月"}
	if err := c.Begin(scene); err != nil {
		t.Fatal(err)
	}
	if err := old.Begin(scene); err != nil {
		t.Fatal(err)
	}
	monitor, err := bank.BeginSession(input.Session, input.Children, input.Seed)
	if err != nil {
		t.Fatal(err)
	}
	fixture := newFixtureSource94()
	born := false
	for i := 0; i <= 240; i++ {
		move := 5*float64((30+i)/5) + 5
		o := observation94(scene.Session, side, int64(i), float64(i*60), move, 20)
		stamp := gate.Stamp{Time: o.Time, Index: i, Line: int64(i + 1)}
		if _, err = monitor.AdvanceObserved(o.Time, uint64(i+1)); err != nil {
			t.Fatal(err)
		}
		snapshot, err := monitor.SnapshotAt(o.Time)
		if err != nil {
			t.Fatal(err)
		}
		h, err := gate.NewHistory(gate.Scope{Session: scene.Session.ID, Contract: scene.Contract, Start: scene.Session.Start, End: scene.Session.End})
		if err != nil {
			t.Fatal(err)
		}
		if err = h.Step(snapshot, stamp); err != nil {
			t.Fatal(err)
		}
		d, err := h.Evaluate(gate.Request{Product: "NK225mini", Method: "NK225_D164_15", SignalID: fmt.Sprintf("人工探索%d", i), Side: side, At: stamp, Last: o.Last})
		if err != nil {
			t.Fatal(err)
		}
		news := []native.Signal{}
		trigger := d.Trend == gate.True
		if reversal {
			trigger = d.Reversal == gate.True
		}
		if early {
			trigger = i == 0
		}
		if trigger && !born && i < 180 {
			news = append(news, birth94("115人工出生", side, 2))
			born = true
		}
		if i == 200 && born {
			news = append(news, close94("115人工返済", "115人工出生", side, 2))
		}
		delta := fixture.step(t, o, int64(i+1), news, nil)
		original, err := json.Marshal(delta)
		if err != nil {
			t.Fatal(err)
		}
		step := source.NativeStep{Observation: o, SourceLine: int64(i + 1), Mini: []source.NativeBatch{delta}}
		if err = c.Step(step); err != nil {
			t.Fatal(i, err)
		}
		if err = old.Step(step); err != nil {
			t.Fatal(i, err)
		}
		after, err := json.Marshal(delta)
		if err != nil {
			t.Fatal(err)
		}
		if !bytes.Equal(original, after) {
			t.Fatal("源入力への干渉")
		}
	}
	if !born {
		t.Fatal("人工の必要経路を通らなかった")
	}
	end := source.SourceEnd{Session: scene.Session, Complete: true}
	if err = c.End(end); err != nil {
		t.Fatal(err)
	}
	if err = old.End(end); err != nil {
		t.Fatal(err)
	}
	origin := source.ReplayResult{Version: 1, Trial: 111, Session: scene.Session, Contract: scene.Contract, Complete: true}
	result, err := ConnectResult(origin, c)
	if err != nil {
		t.Fatal(err)
	}
	baseline, err := legacy.ConnectResult(copyValue(origin), old)
	if err != nil {
		t.Fatal(err)
	}
	if err = CompareReference114Values(&result, baseline, source.FileRef{Path: "人工旧114", SHA256: "人工"}); err != nil {
		t.Fatal(err)
	}
	if err = CheckReplay(result, Fixed{ActualConfigurations: actor.DeclaredContinuousConfigurations()}); err != nil {
		t.Fatal(err)
	}
	return result
}

// TestContinuousMultiScaleAndA0 は順行・反転・未知と売買対称を検査します。
//
// 引数: t(*testing.T)は人工器です。返り値: なし。市場の成績ではありません。
func TestContinuousMultiScaleAndA0(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, kind := range []string{"順行", "反転", "未知"} {
			t.Run(fmt.Sprintf("%d_%s", side, kind), func(t *testing.T) {
				result := hand115(t, side, kind == "反転", kind == "未知", 0)
				for _, config := range result.Actual.Configurations {
					key := fmt.Sprintf("%s_C%.0f_D%d", config.EntryMode, config.SlipPts, config.DelaySeconds)
					want := 1
					if config.EntryMode != "A0" && kind == "未知" || config.EntryMode == "T" && kind == "反転" {
						want = 0
					}
					book := result.Actual.Books[key]
					if len(book.Positions) != want {
						t.Fatal(key, len(book.Positions), want)
					}
					if len(book.EntryGate.Records) != 1 {
						t.Fatal("全出生票の分母")
					}
				}
			})
		}
	}
}

// TestEntryAuditDetectsChangedFrame は公表と出生票の対応改変を拒否します。
//
// 引数: t(*testing.T)は人工器です。返り値: なし。
func TestEntryAuditDetectsChangedFrame(t *testing.T) {
	result := hand115(t, 1, false, false, 0)
	changed := copyValue(result.Actual)
	id := changed.EntryEvents[0].Snapshot.Scales[0].Current.Frame.ID
	for i := range changed.EntryPublications {
		if changed.EntryPublications[i].Frame.Frame.ID == id {
			changed.EntryPublications[i].Frame.Frame.OHLC.Close++
			break
		}
	}
	if CheckEntryEvents(changed) == nil {
		t.Fatal("異なる公表を受理")
	}
	missing := copyValue(result.Actual)
	missing.EntryEvents = nil
	if CheckEntryEvents(missing) == nil {
		t.Fatal("出生Snapshot全欠落を受理")
	}
	missing = copyValue(result.Actual)
	book := missing.Books["T_C0_D0"]
	book.EntryGate.Records[0].Decision.Current.Snapshot.Scales[0].Current.Frame.OHLC.Close++
	missing.Books["T_C0_D0"] = book
	if CheckEntryEvents(missing) == nil {
		t.Fatal("口座の出生Snapshot差を受理")
	}
}

// TestFutureChildrenDoNotChangeBirth は後の子足を変えて過去票の数値が不変か確認します。
//
// 引数: t(*testing.T)は人工器です。返り値: なし。CSV指紋や監査IDの一致とは区別します。
func TestFutureChildrenDoNotChangeBirth(t *testing.T) {
	a, b := hand115(t, 1, false, false, 0), hand115(t, 1, false, false, 50)
	for key, left := range a.Actual.Books {
		right := b.Actual.Books[key]
		x, y := left.EntryGate.Records[0], right.EntryGate.Records[0]
		if x.Request != y.Request || x.Selected != y.Selected || !reflect.DeepEqual(x.Decision.Values, y.Decision.Values) || x.AcceptedQuantity != y.AcceptedQuantity {
			t.Fatal("将来子足が過去の入口を変更", key)
		}
	}
}

// TestExportCoreArtificial115 は独立式へ渡す手製API経路の公表と口座を保存します。
//
// 引数: t(*testing.T)は人工器、環境EXPORT115_COREは任意の新規保存先です。
// 返り値: なし。FAR自然生成・市場の成績として扱いません。
func TestExportCoreArtificial115(t *testing.T) {
	directory := os.Getenv("EXPORT115_CORE")
	if directory == "" {
		return
	}
	if err := os.MkdirAll(directory, 0755); err != nil {
		t.Fatal(err)
	}
	rows := map[string]ReplayResult{}
	for _, side := range []int{1, -1} {
		for _, kind := range []string{"順行", "反転", "未知"} {
			rows[fmt.Sprintf("%d_%s", side, kind)] = hand115(t, side, kind == "反転", kind == "未知", 0)
		}
	}
	if _, err := SaveNew(filepath.Join(directory, "Core人工.json"), map[string]any{"試行": 115, "人工": true, "市場": false, "FAR自然生成": false, "入口定義": gate.DeclaredDefinition(), "公開定義": bank.DeclaredDefinition(), "results": rows}, false); err != nil {
		t.Fatal(err)
	}
}
