# 115：入口の三時間軸を元の連続Sourceへ接続する

元Source111・保護bank111・P113/P100を変えず、入口用5/15/30分bank115だけを追加する。三時間軸は新規時計ではなく、元Sourceのnew要求原行で参照する確定足の幅。金融実行はRootが新115条件を固定した後に限定する。

`PrepareEntryInput`は固定manifest順の対象より前のCSVだけを、各予定Endまで足終+60秒モデルで公表して数値seedへする。当場CSVも全件検査して計画を作るが、当場の数値種を事前に進めない。前史は次場開始までに取得済みとの仮定で、実Raw末尾と同体の履歴とは異なる。末尾足の足終+60が予定Endを越すものは使わない。各workerは同じ固定prefixを再形成し、数値seedを外部JSONから組み立てない。

`NewWithEntry`は入口専用入力を保持し、`Begin`で元Sourceとの場・限月・開始/予定終了を照合する。保護bankは常にNew(scene,nil)でcold。入口の前史・ATR・公表を既存P100へ混ぜない。毎Native原行で入口bankを観測時刻まで進め、新公表を物理行・Indexとともに保存する。新規signalがある原行だけSnapshotAtを全12Actorへ先行配送し、その後で元通知を処理する。同原行複数newは同じSnapshotを共有できる。

入口はA0/T/TR×C0/C5×D0/D1の12口座。Tは30分EMA配置順・15分DI差順/ADX≥20、Rは30分逆配置・15分DI差順。共通は5分前3本高安を確定Closeで越え、要求時Lastも同水準を保持、前ATR14>0・TR5≤2前ATR。詳細は純入口の実定義を固定する。全出生の一回固定、未知は不許可、fill再判定なし、Sourceへの実返済返送なし。

`CheckEntryEvents`はA0全new票/metric分母とunique要求Stamp、EntryEventsの完全対応、全12のRequest/Source/Decision.CurrentのSnapshot同体、全保存公表から当new行の最新公表への結合を検査する。保存OHLCからDMIや前3本高安を別計算する検証は独立Pythonへ分ける。`End`は入口も実frontierのままSealし、仮想時計・気配・強制fillを追加しない。

同費用A0は旧114A0四冊と全金融・全P100 Stateを比較し、Source111全JSONも照合する。異なる入口診断の版/定義/説明差だけを、実受付・容量・取消・実fillの同体確認後に分ける。旧114のT/TR成績を新しい三時間軸の成績へ流用しない。

CLIは`--fixed/--fixed-sha --stage metadata-only|first2|base54|full70 --out NEW --workers 1..16`。full70は同115条件base54成功を`--prior54/--prior54-sha`で認証し、54のNativeを再用して追加16だけ再生する。元FAR166のoracle54・81手法場は同Sourceの参照を再用し、歴史の保存全Signal全文や全tick State同体とは区別する。

人工は手製API通知による買売×順行/反転/未知、旧114A0四費用の終端全金融、将来子足変更の過去票非干渉、全Snapshot欠落/個別改変の拒否、予定End前史の本数/当場未来価格からの隔離、別場拒否、metadata-onlyの旧Native未作成、全54再用・実行中exe・並列上限と予定順を検査する。手製通知はFAR自然生成でも市場損益でもない。

旧入力口の固定検査820a…は成功・前後不変・金融実行0を持つが、停止boolを持たない。当部品は7つの停止と、この旧入力検査を本名のまま認証する。停止boolを旧ファイルへ書き足さない。Go実選択コード・GoRoot・コンパイラ・宣言・依存・実exeを新Core停止へ固定し、Rootが別途金融条件を固定する。

研究の合否は費用後実現損益と安定性。未参加/退出後の仮想利益、機会損失、最高点利確の仮PnLは作らない。11/09は価格・損益・入力指紋とも読まない。
