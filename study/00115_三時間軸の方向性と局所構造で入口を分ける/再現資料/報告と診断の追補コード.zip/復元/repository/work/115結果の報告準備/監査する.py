"""Root解禁済み115診断の加法と最大差1場の保存点を独立に照合する。"""
from collections import Counter
from datetime import datetime,timezone,timedelta
from decimal import Decimal
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
RESULT={"path":str(ROOT/"work/115同入口と三時間軸の実現差/全70の実現差/結果.json"),"sha256":"c9ea16a9ee6f5fddeabdd9ddda3128346225976bac0a38ade20ee2220c167292"}
F1="94bb656a1607d59039a0c5ec0f06968a4da72463d27c0847606a09fc52fc4693"
INPUTS={}


def read(ref: dict) -> dict:
    """
    機能: Root指定正本とその明示RefだけをSHA認証して読む。
    引数: ref(dict)は絶対path/sha256。返り値: dictは十進数の保存値。
    """
    p=Path(ref["path"]);assert p.is_absolute();b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==ref["sha256"]
    INPUTS[str(p.resolve())]=ref["sha256"]
    return json.loads(gzip.decompress(b) if p.suffix==".gz" else b,parse_float=Decimal)


def serial(value):
    """
    機能: 十進数を保存用のJSON数値へ変換する。
    引数: value(object)。返り値: int|floatは有限十進数。未対応型は拒否する。
    """
    if isinstance(value,Decimal):return int(value) if value==value.to_integral_value() else float(value)
    raise TypeError(str(type(value)))


def stamp(quote: dict) -> dict:
    """
    機能: 保存原行へ日本時間の表示だけを付ける。
    引数: quote(dict)。返り値: dictは原値と日時。実受信時計とは主張しない。
    """
    return {**quote,"日本時間":datetime.fromtimestamp(float(quote["time"]),timezone(timedelta(hours=9))).isoformat()}


def net(cost: dict|None) -> Decimal:
    """
    機能: 成立した実gross/fee/slipだけから費用後純額を再加算する。
    引数: cost(dict|None)。返り値: Decimal。未成立は集合の加法単位0だけ。
    """
    return Decimal(0) if cost is None else Decimal(cost["gross"])-Decimal(cost["fee"])-Decimal(cost["slip"])


def summarize_matches(main: dict,rows: list[dict]) -> dict:
    """
    機能: 対応台帳を独自加算し22対照の四群/実額/共通執行分母へ照合する。
    引数: main(dict)とrows(list[dict])。返り値: dictは小さい照合値。
    """
    for side in ("前","後"):
        actual={k:sum((Decimal(r[side+"実現内訳"][k]) for r in rows if r[side+"実現内訳"] is not None),Decimal(0)) for k in ("gross","fee","slip")}
        assert actual==main["実現内訳と執行差"]["実額"][side]
        assert sum((net(r[side+"実現内訳"]) for r in rows),Decimal(0))==main["全体"][side]["実現円"]
    groups={}
    for group,wanted in main["四群"].items():
        subset=[r for r in rows if r["群"]==group]
        counts={s:sum(r[s+"実現内訳"] is not None for r in subset) for s in ("前","後")}
        difference=sum((net(r["後実現内訳"])-net(r["前実現内訳"]) for r in subset),Decimal(0))
        assert all(counts[s]==wanted[s]["玉"] for s in counts) and difference==wanted["実現差円"]
        groups[group]={"前玉":counts["前"],"後玉":counts["後"],"実現差円":difference}
    common=[r for r in rows if r["群"]=="同実入口"]
    execution=Counter({"同実入口":len(common),"実返済執行同体":sum(r["費用外の実返済執行同体"] for r in common),"実返済執行差":sum(not r["費用外の実返済執行同体"] for r in common),"主要保護witness差":sum(not r["主要保護witness同体"] for r in common)})
    assert dict(execution)==main["実現内訳と執行差"]["同入口の費用外執行比較"]
    return {"対照":main["対照"],"前後実現円":[main["全体"][s]["実現円"] for s in ("前","後")],"四群":groups,"費用外執行":dict(execution),"差分解":main["実現内訳と執行差"]["後引く前"]}


def execution_case(row: dict) -> dict:
    """
    機能: 実返済が異なる玉の実現差・初起動・床hit・全実fillだけを取り出す。
    引数: row(dict)は固定対応台帳。返り値: dictは退出後価格を含まない記述。
    """
    value={"出生":row["base"],"取得":row["前実entry"],"純額差円":net(row["後実現内訳"])-net(row["前実現内訳"]),"粗利益差円":row["後実現内訳"]["gross"]-row["前実現内訳"]["gross"]}
    for side in ("前","後"):
        witness=row[side+"主要保護witness"]
        value[side]={"実現内訳":row[side+"実現内訳"],"初起動":None if witness["first_activation"] is None else stamp(witness["first_activation"]["quote"]),"初床hit":None if witness["first_floor_hit"] is None else stamp(witness["first_floor_hit"]["quote"]),"全返済fill":[{"quantity":f["quantity"],"price":f["price"],"reason":f["reason"],"quote":stamp(f["quote"])} for f in row[side+"実返済執行"]["約定"]]}
    return value


def native_case(native: dict,row: dict) -> dict:
    """
    機能: 最大差の1場Nativeから両玉のentry/配賦/実注文/起動/床を再照合する。
    引数: native/row(dict)。返り値: dictは保存点証拠と実額。別engine再走ではない。
    """
    value={}
    for key,side in (("T_C0_D0","前"),("T_C5_D0","後")):
        book=native["actual"]["books"][key];p=next(p for p in book["positions"] if p["id"]==row[side+"ID"])
        assert p["source"]["signal_id"]==row["base"][-1] and p["side"]==row["base"][3]
        entry=row["前実entry"];assert p["entry_quote"]==entry["原行"] and p["entry_price"]==entry["価格"] and p["initial_quantity"]==entry["枚数"]
        fills=[f for f in book["fills"] if f["position_id"]==p["id"] and f["action"]=="close"];parts=[a for f in fills for a in f["allocations"]]
        costs={"gross":p["gross_yen"],"fee":sum(a["entry_fee_yen"]+a["exit_fee_yen"] for a in parts),"slip":sum(a["entry_slip_yen"]+a["exit_slip_yen"] for a in parts)}
        assert costs==row[side+"実現内訳"] and net(costs)==p["realized_net"] and sum(f["quantity"] for f in fills)==p["initial_quantity"]
        execution=row[side+"実返済執行"]
        assert [(f["quantity"],f["price"],f["quote"],f["reason"]) for f in fills]==[(f["quantity"],f["price"],f["quote"],f["reason"]) for f in execution["約定"]]
        orders=[next(o for o in book["orders"] if o["id"]==f["order_id"]) for f in fills]
        assert [(o["request_time"],o["request_quote"],o["reason"],o["quantity"]) for o in orders]==[(o["request_time"],o["request_quote"],o["reason"],o["quantity"]) for o in execution["要求"]]
        points={}
        for name in ("first_activation","first_narrowing","first_floor_hit"):
            point=p["protection113"][name];projection=row[side+"主要保護witness"][name]
            if point is None:assert projection is None;points[name]=None;continue
            assert point["at"]==projection["at"] and point["quote"]==projection["quote"] and point["phase"]==projection["phase"]
            assert all(point["snapshot"][k]==v for k,v in projection["snapshot"].items())
            assert all(point["decision"].get(k)==v for k,v in projection["decision"].items())
            points[name]={"quote":stamp(point["quote"]),"phase":point["phase"],"snapshot":projection["snapshot"],"decision":projection["decision"]}
        value[key]={"id":p["id"],"取得":stamp(p["entry_quote"]),"価格":p["entry_price"],"初期枚数":p["initial_quantity"],"純額":p["realized_net"],"実現内訳":costs,"保存保護点":points,"返済":[{"要求":stamp(o["request_quote"]),"約定":stamp(f["quote"]),"price":f["price"],"quantity":f["quantity"],"reason":f["reason"]} for o,f in zip(orders,fills)]}
    return value


def main() -> None:
    """
    機能: 明示解禁の診断と必要最小1場Nativeを照合し、新workへ小証拠を保存する。
    引数: なし。返り値: None。Raw/価格CSV/11月09/金融実行/固定変更は0。
    """
    result=read(RESULT);assert result["成功"] and result["対照数"]==22 and result["前後不変"]
    request=read(result["Root要求"]);assert request["fixed"] and request["market_native_read_authorized"] and request["legacy114_read_authorized"] and request["stage"]=="full70" and request["condition"]["sha256"]==F1
    read(request["comparison_stop"]);complete=read(request["completion"]);assert complete["trial"]==115 and complete["success"] and complete["sessions"]==70 and complete["books"]==840 and complete["unchanged"] and complete["condition_sha256"]==F1
    detail=read(result["全詳細"]);matching=read(result["対応台帳"])["対応"];assert len(matching)==8037
    checked=[summarize_matches(m,[r for r in matching if r["対照"]==m["対照"]]) for m in result["全70の22対照"]]
    target=[r for r in matching if r["対照"]=="115T_C0_D0→115T_C5_D0"]
    changed=sorted([r for r in target if not r["費用外の実返済執行同体"]],key=lambda r:net(r["後実現内訳"])-net(r["前実現内訳"]))
    assert len(target)==28 and len(changed)==5 and sum(r["前実entry"]["枚数"] for r in target)==79
    assert sum(r["後実現内訳"]["gross"]-r["前実現内訳"]["gross"] for r in changed)==-357000
    biggest=changed[0];assert biggest["base"][-1]=="2026-10-15_Day-NK225mini-D164_15-000008"
    ref=next(r["native"] for r in complete["results"] if r["session"]==biggest["session"]);native=read(ref);case=native_case(native,biggest)
    assert native["trial"]==115 and native["actual"]["complete"]
    main_modes={}
    for m in ("A0","T","TR"):
        for c in (0,5):
            for d in (0,1):
                row=next(x for x in result["全70の22対照"] if x["対照"]==f"115{m}_C0_D{d}→115{m}_C5_D{d}")
                stat=row["全体"]["前" if c==0 else "後"];assert stat["損失総額円"]<=stat["起動後赤字額円"]<=0
                main_modes[f"{m}_C{c}_D{d}"]={k:stat[k] for k in ("玉","枚","実現円","利益総額円","損失総額円","正益後赤字玉","起動後赤字玉","起動後赤字額円")}
                main_modes[f"{m}_C{c}_D{d}"]["未起動完結の損失総額円"]=stat["損失総額円"]-stat["起動後赤字額円"]
    periods=[{"対照":r["対照"],"期間":r["期間"],"前後純額円":[r["全体"][s]["実現円"] for s in ("前","後")]} for r in detail["集計"] if r["owner"]=="全枝" and r["対照"] in ("115A0→115T_C0_D0","115T→115TR_C0_D0","115T_C0_D0→115T_C5_D0")]
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==s for p,s in INPUTS.items())
    proof={"試行":115,"成功":True,"確認日":"2026-11-10","範囲":"固定診断22対照8037対応の独立加算と最大差1場Nativeの両玉保存点照合。金融engine/全tick再走ではない。","診断正本":RESULT,"Root要求":result["Root要求"],"金融条件SHA256":F1,"22対照の独立照合":checked,"全12の実現と損失":main_modes,"Tの実返済差5玉":[execution_case(r) for r in changed],"最大差のNativeRef":ref,"最大差の保存点再照合":case,"期間差":periods,"TからTRの実現追加":result["TからTRの実現追加"],"全口座保存点連結時価DD":result["115全口座保存点連結時価DD円"],"入力SHA256":INPUTS,"前後不変":True,"未実施":{"Raw/価格CSV/11月09本文読取":0,"金融実行/閾値調整/固定変更/未参加仮益/退出後仮益":0}}
    path=HERE/"診断の独立照合.json"
    with path.open("x",encoding="utf-8",newline="\n") as f:f.write(json.dumps(proof,ensure_ascii=False,indent=2,default=serial)+"\n")
    print(json.dumps({"成功":True,"path":str(path),"sha256":hashlib.sha256(path.read_bytes()).hexdigest(),"独立集計":22,"対応":8037,"Native再読場数":1},ensure_ascii=False))


if __name__=="__main__":main()
