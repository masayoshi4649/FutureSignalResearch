"""115独立結果の許可済みJSONだけから報告の下書きを新規生成する。"""

from collections import Counter
from decimal import Decimal, getcontext
import hashlib
import json
from pathlib import Path


getcontext().prec = 40
OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
RESULT = ROOT / 'work/115独立保存F1/全70場/結果.json'
CHECK = RESULT.parent / '保存会計の確認.json'
RESULT_SHA = 'b4d9df3568098a73d38a670a9cca7a7dc0e6b4d79fe07a8ae8dd21d9cf6293df'
CHECK_SHA = '9781d80ca7213e541317f317c3b95c562111ec1590b435686e1682952444e730'
SUM_FIELDS = ('net_yen', 'positive_yen', 'negative_yen', 'positions', 'entry_quantity', 'positive_positions',
              'negative_positions', 'zero_positions', 'whole_positive_positions', 'whole_positive_closed_negative',
              'whole_positive_closed_negative_yen', 'protection_activated_positions', 'activated_closed_negative', 'activated_closed_negative_yen')


def need(test: bool, reason: str) -> None:
    """機能: 許可範囲や集計の不一致で停止する。

    引数: test(bool)、reason(str)は成立条件と説明。
    返り値: None。不一致はValueError。
    """
    if not test:
        raise ValueError(reason)


def sha(path: Path) -> str:
    """機能: 許可済み正本JSON又は新規文書/コードの指紋を返す。

    引数: path(Path)は明示対象。
    返り値: strはSHA256。Native/CSV/Rawを渡す経路は作らない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ref(path: Path) -> dict:
    """機能: 明示成果物の絶対位置と指紋を作る。

    引数: path(Path)は対象。
    返り値: dictはFileRef。
    """
    return {'path': str(path), 'sha256': sha(path)}


def ratio(numerator: int, denominator: int) -> Decimal | None:
    """機能: 分母0を未知として件数比を作る。

    引数: numerator/denominator(int)は分子と分母。
    返り値: Decimal|Noneは比率又は未定義。
    """
    return Decimal(numerator) / denominator if denominator else None


def yen(value: int) -> str:
    """機能: 円を符号付き桁区切りで表示する。

    引数: value(int)は円額。
    返り値: strは円単位を省いた表示。
    """
    return f'{value:+,}' if value else '0'


def pct(value: Decimal | None) -> str:
    """機能: 率を2桁%又は未定義で表示する。

    引数: value(Decimal|None)は比率。
    返り値: strは表示値。
    """
    return f'{value * 100:.2f}%' if value is not None else '未定義'


def table(headers: list[str], rows: list[list[str]]) -> str:
    """機能: 並列比較をMarkdown表へ変換する。

    引数: headers(list[str])、rows(list[list[str]])は見出しと行。
    返り値: strは末尾改行付きの表。
    """
    return '\n'.join('| ' + ' | '.join(row) + ' |' for row in [headers, ['---'] * len(headers), *rows]) + '\n'


def aggregate(rows: list[dict]) -> dict:
    """機能: 保存済み各場の実現額・件数と保存点DDを期間別に結合する。

    引数: rows(list[dict])は同一口座の元順序の場別結果。
    返り値: dictは期間統計。全tickDDや金融約定を再形成しない。
    """
    out = {field: sum(row[field] for row in rows) for field in SUM_FIELDS}
    equity = peak = drawdown = 0
    for row in rows:
        drawdown = max(drawdown, row['場内時価DD'], peak - (equity + row['保存最小時価']))
        peak = max(peak, equity + row['保存最大時価'])
        equity += row['net_yen']
    out.update(場数=len(rows), 取引あり場=sum(row['positions'] > 0 for row in rows), 保存点連結時価DD=drawdown,
               PF=ratio(out['positive_yen'], -out['negative_yen']), win_rate=ratio(out['positive_positions'], out['positions']),
               正益経験後赤字率=ratio(out['whole_positive_closed_negative'], out['whole_positive_positions']),
               起動後赤字率=ratio(out['activated_closed_negative'], out['protection_activated_positions']))
    return out


def write_new(path: Path, value: dict | str) -> None:
    """機能: 下書き又は確認metadataを新規保存する。

    引数: path(Path)、value(dict|str)は新規先と内容。
    返り値: None。既存案を上書きしない。
    """
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=2, default=str) + '\n'
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(text)


def main() -> None:
    """機能: 認証した独立70場/840会計からREADMEと共通知見の案を作る。

    引数: なし。入力はRoot指定の2JSONに固定する。
    返り値: None。新規下書きRefだけを表示する。
    """
    need(sha(RESULT) == RESULT_SHA and sha(CHECK) == CHECK_SHA, 'Root解禁した正本SHA')
    data = json.loads(RESULT.read_text(encoding='utf-8-sig'), parse_float=Decimal)
    check = json.loads(CHECK.read_text(encoding='utf-8-sig'), parse_float=Decimal)
    need(data['成功'] is True and check['成功'] is True and data['試行'] == check['試行'] == 115
         and data['stage'] == check['stage'] == 'full70' and data['場数'] == check['場数'] == 70
         and data['会計数'] == check['会計数'] == 840 and data['前後不変'] is True and check['前後不変'] is True,
         '115全70/840独立成功')
    need(check['出力SHA256']['結果.json'] == RESULT_SHA and check['不一致数'] == 0 and check['旧114全金融比較'] == 280
         and check['全Source111同体'] is True and check['全残玉予約0'] is True, '独立保存/旧114全金融/Source/flat')
    need(data['採用'] is False and data['研究目標達成'] is False, '未採用を維持')
    summaries, periods, nov06 = {}, {}, []
    for key in data['主key']:
        rows = [row for row in data['場別'] if row['key'] == key]
        need(len(rows) == 70 and len({row['session'] for row in rows}) == 70, '全70保持')
        all70 = aggregate(rows)
        source = data['集計'][key]
        need(all(all70[field] == source[field] for field in SUM_FIELDS)
             and all70['保存点連結時価DD'] == source['保存点連結時価DD'], '保存実現数値/連結DDの同体')
        for name in ('PF', 'win_rate'):
            need((all70[name] is None and source[name] is None) or abs(all70[name] - source[name]) < Decimal('1e-12'), '保存比率と定義')
        summaries[key] = all70
        periods[key] = {kind: aggregate([row for row in rows if row['history_class'] == kind]) for kind in ('original54', 'additional16')}
        need(periods[key]['original54']['場数'] == 54 and periods[key]['additional16']['場数'] == 16, '54+16全期間')
        nov06.extend({field: row[field] for field in ('session', 'key', *SUM_FIELDS)} for row in rows if row['session'].startswith('2026-11-06_'))
    for suffix in ('_C0_D0', '_C0_D1', '_C5_D0', '_C5_D1'):
        need(summaries['TR' + suffix]['net_yen'] > summaries['T' + suffix]['net_yen'], 'TRとTの費用別総額比較')
        for mode in ('T', 'TR'):
            need(summaries[mode + suffix]['正益経験後赤字率'] > summaries['A0' + suffix]['正益経験後赤字率'], '全費用の全玉正益経験後赤字率比較')

    # ----------------------------------------
    full_rows, protection_rows, period_rows, day_rows = [], [], [], []
    for key in data['主key']:
        s = summaries[key]
        full_rows.append([key, yen(s['net_yen']), yen(s['positive_yen']), yen(s['negative_yen']), str(s['positions']), str(s['entry_quantity']),
                          f"{s['PF']:.3f}" if s['PF'] is not None else '未定義', pct(s['win_rate']), f"{s['保存点連結時価DD']:,}"])
        protection_rows.append([key, str(s['whole_positive_positions']), str(s['whole_positive_closed_negative']), pct(s['正益経験後赤字率']),
                                yen(s['whole_positive_closed_negative_yen']), str(s['protection_activated_positions']), str(s['activated_closed_negative']), pct(s['起動後赤字率'])])
        p, q = periods[key]['original54'], periods[key]['additional16']
        period_rows.append([key, yen(p['net_yen']), str(p['positions']), str(p['entry_quantity']), yen(q['net_yen']), str(q['positions']), str(q['entry_quantity'])])
        day, night = [next(row for row in nov06 if row['key'] == key and row['session'].endswith(kind)) for kind in ('Day', 'Night')]
        day_rows.append([key, yen(day['net_yen']), str(day['positions']), str(day['whole_positive_positions']) + '/' + str(day['whole_positive_closed_negative']),
                         yen(night['net_yen']), str(night['positions']), str(night['whole_positive_positions']) + '/' + str(night['whole_positive_closed_negative'])])
    entry_rows = []
    for mode in ('A0', 'T', 'TR'):
        key = mode + '_C0_D0'
        c, s = Counter(data['入口票集計'][key]), summaries[key]
        need(c['selected_true'] + c['selected_false'] + c['selected_unknown'] == c['source_new'] == 558, '出生票の全分母558')
        entry_rows.append([mode, str(c['selected_true']), str(c['selected_false']), str(c['selected_unknown']), str(c['input_missing']),
                           pct(ratio(c['allowed'], c['source_new'])), str(s['positions']), str(s['entry_quantity'])])
    full_table = table(['口座', '純額円', '利益総額円', '損失総額円', '実玉', '実新規枚', 'PF', '勝率', '保存点DD円'], full_rows)
    protect_table = table(['口座', '全玉正益経験', '同・最終赤字', '条件付き率', '同・最終赤字額円', '追尾起動玉', '起動後赤字', '起動後赤字率'], protection_rows)
    period_table = table(['口座', '元54純額円', '玉', '枚', '追加16純額円', '玉', '枚'], period_rows)
    entry_table = table(['モード', '選択真', '選択偽', '選択未知', '入力不足診断', '許可/558', 'C0D0実玉', 'C0D0実枚'], entry_rows)
    day_table = table(['口座', '11/06Day純額円', '玉', '正益経験/赤字玉', 'Night純額円', '玉', '正益経験/赤字玉'], day_rows)
    report = '''# 00115：三時間軸の方向性と局所構造で入口を分ける（結果案）

2026-11-10。金融F1を事前固定した全70場840会計の金融・独立入口・会計/P・CSVからの価格足/DMI再形成がRootで成功した。A0は旧114A0四費用へ全金融280対照、Source111全文同体と全残玉予約0を確認した。正式保存・CSV・Viewerの完了はこの案では未確認。同入口22対照の診断は実行中で、共通入口・R追加や幅の費用感度の原因説明は成功後に追補する。

C0D0のA0は+1,126,987円、Tは+386,917円、TRは+407,916円。T/TRの保存点DDは小さくなったが、取引も558玉から28/34玉へ減った。C5ではT/TRともD0/D1の両方で赤字であり、安定収益・採用は未確認である。正益経験後赤字率もA0より低くならなかった。条件や閾値は結果を受けて変更していない。

## 比較対象と時計

A0は「元のSource入口＋P100共通保護」の対照で、S0の原手法そのものではない。Tは順行、TRは順行Tまたは反転Rの追加選別。元三手法の全Source新規出生で一度だけ票を固定し、fill時に未来値で再判定しない。5/15/30分は指標の足幅で、新規判断の時計は元の原行連続のままである。

- T：30分の売買方向付きEMA8−EMA21差>0、15分の売買方向付きDI14差>0かつADX14≥20。
- R：30分のEMA差<0、15分のDI差>0。ADX閾値・上昇・直近DI交差は必須にしない。これは方向回復の状態であり、押戻し→復帰という履歴を証明しない。
- 共通：5分確定Closeが現在足を含めない直前3本の高安を厳密突破、前ATR14>0かつ当足TR≤2×前ATR、Source要求原行Lastも同じ水準の順側を保持。売り買いは符号対称。

30分の配置、15分の高安拡大、5分の局所構造と値幅警戒を役割分担した。これらは同じ価格履歴を共有し、独立した確率票ではない。ADX20・前3本・TR2倍は事前固定の研究値で、NK225の最適値ではない。新入口のRSI/MACD等は準備・診断、BBは新5/15/30bankに追加していない。P100の既存3分M/P/BB等と区別する。

日経mini100円/pt、片側各上限10枚、可変数量、片道手数料38.5円。C0/C5は追加片道滑り0/5pt、D0/D1は追加価格時計遅延0/1秒。D0も同原行fillを許さない。費用と遅延は別感度で、D1を安全側の改善や実通信遅延の保証と解釈しない。

## 全70場・12費用条件

''' + full_table + '''
純額は実現額で、利益総額＋損失総額に一致する。勝率は正益完結玉/全完結玉（同値も分母）、PFは利益総額/損失総額の絶対値。DDは保存点の場内・場間を連結した時価DDで、全tick別走査による最大DDではない。各玉は可変枚数なので、玉数・枚数・円額を分ける。

## 正益経験と利益保護

''' + protect_table + '''
全玉評価Wは既返済費用後実現額R＋残枚数n×残1枚費用後評価u。全玉正益経験玉は保有中W>0を経験した実玉、条件付き赤字率はそのうち最終実現純額<0となった玉数を分子にする。0取引の0/0を0%へ補完しない。赤字額は当該玉の最終実現損失総額である。

全候補でP113/P100を固定し、Wが初期枚数q0×10,000円以上で必須追尾を起動する。通常幅ceil5(max(200pt,2×取得ATR))、動的支持否定P AND MACD失速Mで狭幅、取得後適格pivot床、費用床・全玉床・非緩和を維持した。起動前の小正益を必ず利益で確定する条件ではない。実返済の原行待ち・滑りもあり、保護価格と最終実現純額は同一ではない。

C0D0ではA0の正益経験後赤字178/477=37.32%に対し、Tは11/25=44.00%、TRは14/31=45.16%。T/TRの起動後赤字0も、起動玉が10/13に減った小標本の観測である。損失件数や損失総額の減少、DDの縮小を保護演算の改善とは呼ばない。共通保護の入口選別比較であり、取得・数量・経路の分解は同入口診断待ちである。

## 期間と0取引場

''' + period_table + '''
元54は2026-09-21Day～10-27Night、追加16は10-28Day～11-06Night。元54を同F1成功Native参照で再用し、追加16だけを再生した。全70は過去研究で既使用の期間で、追加16を新しい未知データや独立テストとは呼ばない。全0取引場も分母・一覧に保持した。期間別の利益/損失・PF・勝率・保存点DD・正益経験率は[数値結合](数値結合.json)に保持する。

## 出生票と入力不足

''' + entry_table + '''
追加選別前の共通Source出生558を分母とする。選択未知7と入力不足診断79は別物で、既知偽が一つあれば入力不足を含む票でも複合選択は偽になり得る。A0は不足を理由に追加拒否しない。既知否定552も各枝の診断であり、選択偽523/517と同じ分母分類ではない。票・受付・実fillを分け、固定5分/15分枠の参加率は算出しない。

## 懸念日の11月06日

''' + day_table + '''
T/TRはDayで2玉8枚が成立し、全費用で赤字だった。C0D0の2玉はいずれも全玉正益を一度経験したが起動玉0で、最終赤字2玉。Nightは全費用0取引である。Nightの0円を保有中損失の改善とは扱わず、Dayの一部の小正益後赤字を隠さない。チャートの見やすさと取得条件・費用後実現は別に検証する。個別原行・足形や損失原因はこの集計だけで推定しない。

## 入力・因果・検査の範囲

入口bankだけに、固定manifestの対象場より前の同限月5分CSV prefixを与える。前史は予定Endまで足終+60秒で公表済みとする模型で、元Sourceの過去Raw最終frontierを逐次継承した証明ではない。当場はRaw観測原行までの配送だけを使い、最新当場公表/freshを要求する。数値seedだけで当場公表や直前3本構造を既知にせず、最初の場cold・限月変更/価格欠足resetを保つ。元Source111と保護用3分cold bankは変更しない。

金融→独立会計/P/旧A0比較→入口票独立→共有CSVからの5/15/30 OHLC/DMI別実装を別証拠として結んだ。原文166の81Event対照は元54三手法の再実行範囲であり、当時保存全文や市場全tickStateの一致を主張しない。DMI監査もEMA/ATR等全技法やRawからCSV形成を別計算したものではない。

[独立結果](../115独立保存F1/全70場/結果.json) SHA `b4d9df3568098a73d38a670a9cca7a7dc0e6b4d79fe07a8ae8dd21d9cf6293df`、[保存検算](../115独立保存F1/全70場/保存会計の確認.json) SHA `9781d80ca7213e541317f317c3b95c562111ec1590b435686e1682952444e730`。金融F1 SHA `94bb656a1607d59039a0c5ec0f06968a4da72463d27c0847606a09fc52fc4693`。[事前条件と心理の仮説](../../study/00115_三時間軸の方向性と局所構造で入口を分ける/README.md)、[設定表](../../study/00115_三時間軸の方向性と局所構造で入口を分ける/設定と結果.md)を参照する。

ラージ板でmini約定を代理した模型であり、実mini流動性/応答、未観測期間の収益安定性は未確認。11/09の価格・損益・入力指紋は未読。70%・125/250先着・固定参加率は一旦合否外とし、未参加/退出後の仮想利益、機会損失、ROIを作らない。研究目標達成・採用はfalse。
'''
    common = '''# 三時間軸の選別と正益後赤字を分けて読む（115結果案）

確認日2026-11-10。Rootが成功を解禁した115独立全70場840会計の集計に基づく。正式反映前の案で、同入口22対照は未完成。入口T/Rの各原因や費用差の内訳は診断後に追補する。閾値を結果へ合わせて変えない。

## 一般説明と心理の仮説

30分EMAの長い終値配置、15分DMIの高安拡大、5分の前3本高安突破は役割が違うが、同じ価格履歴から作るため独立票ではない。ADXは向きのある指標ではなく、DIの偏りの強さを平滑した尺度である。強い方向の中でRSI等が過熱表示を続けることも、価格幅が収縮しても方向が未定であることも、単独の反転指示にはならない。[事前の一次資料調査](../../docs/議論/外部再調査/三時間軸で配置と高安拡大と突破を分ける.md)に出典URL/確認日2026-11-10を残した。一般教材の説明をこの複合条件の優位の証明へ広げない。

心理の仮説は、長い方向配置と中期の高安更新が同じ向きで局所抵抗を越えて保持するなら複数の時間幅の判断が重なる可能性、逆配置の中で中期方向が回復するなら旧方向の手仕舞い/新方向の参加が始まる可能性である。新規/返済・主体・吸収量は価格指標から確定しない。DI順側という状態は押戻し→復帰という過程そのものではない。

## 今回確認した事実

A0は元Source入口＋P100共通保護、T/TRは同保護の入口選別である。C0D0ではA0+1,126,987円/558玉/1,169枚、T+386,917円/28玉/79枚、TR+407,916円/34玉/92枚。T/TRは保存点DDも利益総額・損失総額も減った。取得数が大きく違うため、そのまま保護技法の改善や単位リスク当たりの改善とは言えない。

Tは558出生中28票（5.02%）、TRは34票（6.09%）を通した。選択未知7と入力不足診断79は別に残した。C5ではT/TRがD0/D1とも赤字で、黒字だったC0だけを採用根拠にしない。TRの総額はTを4費用とも上回ったが、共通入口の同体やRだけの実現差は診断成功前に断定しない。

全玉W>0経験玉を分母にしたC0D0最終赤字率はA0の178/477=37.32%に対し、Tは11/25=44.00%、TRは14/31=45.16%。全4費用でもT/TRの同率はA0より高かった。起動後赤字0と、起動前も含む正益経験後赤字は別の観測である。どの玉を取得したかと、取得後の保護の違いを切り分ける必要がある。

11/06DayはT/TRともC0D0で−92,616円、2玉8枚。2玉とも全玉正益経験あり、追尾起動なしで最終赤字だった。Nightは0取引。新条件にも小正益から赤字となる実玉があり、0取引日の0円でその問題が解決したと扱わない。

## 次に判別したい問い

条件が厳しく成立数が少なかった事実で終了せず、長い配置・中期の高安方向・短い突破のどこが成立窓を制限したかを、当時公表済み値とSource枝の役割別に調べる。未知/古い公表と、既知の方向不一致、構造がまだ突破していない状態は分ける。順行待ちと反転待ちのどちらへ切り替えるかを先に状態で定義し、結果のよかった出生だけを後から拾わない。

Rの中期DI回復が一時的な買戻し/売戻しか持続的な転換か、Tの突破が通常の再開か既に拡大し切った追随かは、価格・高安方向・値幅の当時の遷移として問う。未来の回復や決済後価格を発注条件にしない。現行のADX20/前3本/TR2倍をこの70場の損益へ合わせて変更する検証は行っていない。

全70は既使用、11/09未読。未知期間の安定性、実mini板約定は未確認。採用false・研究目標達成false。[数値と費用別/期間別の案](README115結果版.md)と[独立数値結合](数値結合.json)を参照する。
'''
    out = {'試行': 115, '成功': True, '状態': '独立全70成功・同入口診断待ちの下書き', '入力正本': ref(RESULT), '入力検算': ref(CHECK),
           '全70': summaries, '期間別': periods, '11月06': nov06, '入口票集計': data['入口票集計'],
           '金融再実行': False, '市場Native/CSV/Raw/11月09本文読取': False, '正式文書編集': False}
    write_new(OWN / '数値結合.json', out)
    write_new(OWN / 'README115結果版.md', report)
    write_new(OWN / '共通知見の案.md', common)
    need(sha(RESULT) == RESULT_SHA and sha(CHECK) == CHECK_SHA, '正本前後不変')
    proof = {'試行': 115, '成功': True, '正本': ref(RESULT), '検算': ref(CHECK), '前後不変': True,
             '全12の実現額/利益損失/件数/枚数/PF/勝率/保存点DD同体': True, '期間54+16/0取引を保持': True,
             '同入口診断': 'Root実行中のため未読/未反映', '生成': {name: ref(OWN / name) for name in ('数値結合.json', 'README115結果版.md', '共通知見の案.md')},
             '所有コード': ref(Path(__file__).resolve()), '市場Native/CSV/Raw/11月09本文読取': False, '正式文書編集': False}
    write_new(OWN / '報告準備の確認.json', proof)
    print(json.dumps({'成功': True, '確認': ref(OWN / '報告準備の確認.json'), '生成': proof['生成']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
