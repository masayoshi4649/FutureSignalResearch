"""既正式の金融同体の鎖と115主条件2玉を固定112OHLCの必要行へ結ぶ。"""
from datetime import datetime,timezone,timedelta
from decimal import Decimal
from pathlib import Path
import csv
import gzip
import hashlib
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
BASE=ROOT/"work/115同入口と三時間軸の実現差/全70の実現差"
INPUTS={}
SIGNALS=("2026-11-06_Day-NK225mini-D164_15-000022","2026-11-06_Day-NK225mini-D164_15-000038")


def read(path: Path,sha: str|None=None) -> dict:
    """
    機能: 明示されたJSON/圧縮JSONを認証して必要metadataだけへ結ぶ。
    引数: path(Path)、sha(str|None)。返り値: dictは十進数の保存原値。
    """
    b=path.read_bytes();actual=hashlib.sha256(b).hexdigest();assert sha is None or actual==sha
    INPUTS[str(path.resolve())]=actual
    return json.loads(gzip.decompress(b) if path.suffix==".gz" else b,parse_float=Decimal)


def serial(value):
    """
    機能: JSONへ十進数を数値のまま保存する。
    引数: value(object)。返り値: int|float。未対応型は拒否する。
    """
    if isinstance(value,Decimal):return int(value) if value==value.to_integral_value() else float(value)
    raise TypeError(str(type(value)))


def when(seconds) -> str:
    """
    機能: 保存価格時計を日本時間表示へ変換する。
    引数: seconds(int|Decimal)。返り値: strはISO8601。受信時計とは扱わない。
    """
    return datetime.fromtimestamp(float(seconds),timezone(timedelta(hours=9))).isoformat()


def main() -> None:
    """
    機能: 主C0D0の実2玉を過去の金融同体鎖と固定OHLCの境界へ照合する。
    引数: なし。返り値: None。Raw/金融再計算/固定変更と主レビュー3ファイル変更は0。
    """
    result=read(BASE/"結果.json","c9ea16a9ee6f5fddeabdd9ddda3128346225976bac0a38ade20ee2220c167292")
    request=read(Path(result["Root要求"]["path"]),result["Root要求"]["sha256"]);assert request["market_native_read_authorized"] and request["legacy114_read_authorized"]
    complete=read(Path(request["completion"]["path"]),request["completion"]["sha256"]);ref=next(s["native"] for s in complete["results"] if s["session"]=="2026-11-06_Day")
    native=read(Path(ref["path"]),ref["sha256"]);assert native["reference114"]["all_financial_equal"] and native["reference114"]["comparisons"]==4
    ledger=read(Path(result["対応台帳"]["path"]),result["対応台帳"]["sha256"])["対応"]
    formal=[]
    for folder,field,count in (("00113_起動前の支持否定と利益保護の切替","旧112全金融比較",840),("00114_順行と反転の取得確認を分ける","旧113全金融比較",280),("00115_三時間軸の方向性と局所構造で入口を分ける","旧114全金融比較",280)):
        p=ROOT/"study"/folder/"成果物/保存会計の確認.json";v=read(p)
        assert v["成功"] and v["stage"]=="full70" and v[field]==count and v["全Source111同体"] and v["不一致数"]==0 and v["前後不変"] and v["全残玉予約0"]
        formal.append({"path":str(p.resolve()),"sha256":INPUTS[str(p.resolve())],field:count,"成功":True,"全Source111同体":True,"不一致数":0})
    csvpath=ROOT/"outputs/01a1889f-f2af-7943-a047-543275ee9ed2/112保有区間OHLC/建玉全体OHLC.csv";checkpath=csvpath.parent/"CSVの確認.json";check=read(checkpath)
    assert check["成功"] and check["対象試行"]==112 and check["出力"][csvpath.name]["データ行数"]==13332
    sha=hashlib.sha256(csvpath.read_bytes()).hexdigest();assert sha==check["出力"][csvpath.name]["sha256"]=="f073a92b82531729d38db2784d76eceba484b7fec23d477db380f2ae8198d411";INPUTS[str(csvpath.resolve())]=sha
    book=native["actual"]["books"]["T_C0_D0"];positions=[p for p in book["positions"] if p["source"]["signal_id"] in SIGNALS];assert len(positions)==len(book["positions"])==2
    indices={str(p["entry_quote"]["index"]) for p in positions}
    with csvpath.open(encoding="utf-8-sig",newline="") as f:
        selected=[r for r in csv.DictReader(f) if r["セッション"]=="2026-11-06_Day" and r["口座"]=="P100_C0_D0" and r["取得Index"] in indices]
    assert len(selected)==2
    rows=[]
    for p in positions:
        signal=p["source"]["signal_id"];r=next(r for r in selected if int(r["取得Index"])==p["entry_quote"]["index"])
        chain=[]
        for name in ("115A0→115T_C0_D0","115A0→115TR_C0_D0","115T→115TR_C0_D0"):
            match=next(m for m in ledger if m["対照"]==name and m["base"][-1]==signal)
            assert match["群"]=="同実入口" and match["共通返済の差分属性"]==[] and match["費用外の実返済執行同体"] and match["主要保護witness同体"]
            chain.append({"対照":name,"前ID":match["前ID"],"後ID":match["後ID"],"同実入口/全返済保護同体":True})
        assert r["売買"]=="売り" and p["side"]==-1 and int(r["初期枚数"])==p["initial_quantity"] and Decimal(r["取得価格"])==p["entry_price"]
        for prefix,quote in (("取得",p["entry_quote"]),("最終返済",p["closed_quote"])):
            assert r[prefix+"時刻"]==when(quote["time"]) and int(r[prefix+"Index"])==quote["index"] and int(r[prefix+"物理行"])==quote["source_line"]
        assert Decimal(r["実現純利益円"])==p["realized_net"] and not p["protection_active"] and p["activation"] is None and r["利益保護起動"]=="false" and r["H100初到達時刻"]==""
        maximum=p["marks"]["whole_max"];assert Decimal(r["全玉最大W円"])==maximum["whole_net"] and r["全玉最大W初回時刻"]==when(maximum["quote"]["time"]) and int(r["全玉最大W初回Index"])==maximum["quote"]["index"] and int(r["全玉最大W初回物理行"])==maximum["quote"]["source_line"]
        threshold=p["initial_quantity"]*100*100;assert maximum["whole_net"]<threshold
        fills=[f for f in book["fills"] if f["position_id"]==p["id"] and f["action"]=="close"];assert len(fills)==int(r["返済片数"])==1
        fields=("建玉ID","取得時刻","取得Index","取得物理行","最終返済時刻","最終返済Index","最終返済物理行","初期枚数","取得価格","実現純利益円","全玉最大W円","全玉最大W初回時刻","全玉最大W初回Index","全玉最大W初回物理行","全玉最大W最終時刻","利益保護起動","H100初到達時刻")
        excerpt={k:r[k] for k in fields}
        extrema={series:{k:r[series+k] for k in ("始値","始値時刻","高値","高値初回時刻","高値初回Index","高値初回物理行","高値最終時刻","高値最終Index","高値最終物理行","安値","安値初回時刻","安値初回Index","安値初回物理行","安値最終時刻","安値最終Index","安値最終物理行","終値","終値時刻")} for series in ("Last","Bid","Ask")}
        rows.append({"Source出生":signal,"115T建玉ID":p["id"],"115同体鎖":chain,"112CSV必要抜粋":excerpt,"必要保有区間OHLC":extrema,"W起動閾値円":threshold,"W最大の保存位相":maximum["phase"],"実返済":{"quote":fills[0]["quote"],"日本時間":when(fills[0]["quote"]["time"]),"price":fills[0]["price"],"quantity":fills[0]["quantity"],"reason":fills[0]["reason"]},"全玉H100未到達":True})
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==s for p,s in INPUTS.items())
    output={"試行":115,"成功":True,"対象":"2026-11-06_Dayの主C0D0 T/TR実2玉","既正式金融同体鎖":["112P100→113P100（S0/W100/P100旧12対照の範囲）","113P100→114A0（4費用）","114A0→115A0（4費用）","115A0→115T/TR（当該同実入口/全返済保護同体）"],"既正式記録":formal,"115NativeRef":ref,"CSVRef":{"path":str(csvpath),"sha256":sha},"2玉の抜粋":rows,"限界":["112から114の全金融再比較は今回実行せず、既正式の全金融比較成功を参照継承した。説明版/stream/gate票の差は金融値から分離された既比較の範囲。","CSVにはSource出生ID列がないため、実取得/最終返済の時刻・Index・物理行/side/枚数/価格/純額と既金融同体鎖を併用した。建玉IDだけや価格だけで結ばない。","Lastと正常Bid/Askは別系列。同じ高安の初回/最後やW最大の時計は一致を強制しない。","保有期間の両端原行を含む既計算の抜粋。Raw再走査、退出後価格、仮想利確、H変更の成績推定は行わない。"],"入力SHA256":INPUTS,"前後不変":True,"Raw/11月09/金融実行/固定変更":0}
    dest=HERE/"11月06日の2玉と既存OHLCの対応.json"
    with dest.open("x",encoding="utf-8",newline="\n") as f:f.write(json.dumps(output,ensure_ascii=False,indent=2,default=serial)+"\n")
    print(json.dumps({"成功":True,"path":str(dest),"sha256":hashlib.sha256(dest.read_bytes()).hexdigest(),"抜粋玉数":2},ensure_ascii=False))


if __name__=="__main__":main()
