"""115の正式保存metadata/コード所在/固定要求だけを読取レビューする。"""

from collections import Counter
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00115_三時間軸の方向性と局所構造で入口を分ける'
EXPECTED = 'c1e2aefa1bbd8e72289288eab8ea16182d9f99eeff8673271f0843482029015e'
READ = {}
CHECKS = []


def digest(path: Path) -> str:
    """機能: 明示metadata/文書/新規レビューコードだけのSHAを返す。

    引数: path(Path)は明示対象。
    返り値: strはSHA256。CSV/Native/原板へ呼び出す経路は持たない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def metadata(path: Path, expected: str | None = None) -> dict:
    """機能: 指定したJSON metadataだけを指紋付きで読む。

    引数: path(Path)、expected(str|None)は小metadataと期待SHA。
    返り値: dictはJSON。市場NativeやCSV本文は受け付けない。
    """
    if path.suffix != '.json' or '.Native.' in path.name:
        raise ValueError('metadataだけを受け付ける')
    current = digest(path)
    if expected is not None and current != expected:
        raise ValueError('metadata指紋差: ' + str(path))
    READ[str(path)] = current
    return json.loads(path.read_text(encoding='utf-8-sig'))


def check(name: str, passed: bool, detail: str) -> None:
    """機能: 各レビューの成立/不成立と証明範囲を記録する。

    引数: name/detail(str)、passed(bool)は項目・範囲・判定。
    返り値: None。失敗を黙って成功へ変換しない。
    """
    CHECKS.append({'項目': name, '成立': bool(passed), '範囲': detail})


def normal(path: str) -> str:
    """機能: repo相対旧所有mapと絶対pathを同じ比較キーへ正規化する。

    引数: path(str)は停止記録内の位置。
    返り値: strは解決絶対位置のcasefold。
    """
    original = Path(path)
    return str((original if original.is_absolute() else ROOT / original).resolve()).casefold()


def main() -> None:
    """機能: 正式確認と索引/要求の結合を検査し、新規の小レビューを保存する。

    引数: なし。Root指定正式metadataへ固定する。
    返り値: None。レビューRefだけを表示する。金融を再計算しない。
    """
    proof_path = TRIAL / '検査/正式保存の確認.json'
    proof = metadata(proof_path, EXPECTED)
    index_path, request_path = TRIAL / '再現資料/コード所在索引.json', TRIAL / '検査/正式保存の要求.json'
    index = metadata(index_path, proof['コード所在索引']['sha256'])
    request = metadata(request_path, proof['Root要求']['sha256'])
    copied = {normal(row['origin']['path']): row for row in proof['同bytes成果物']}
    check('正式保存成功/範囲', proof['成功'] is True and proof['試行'] == 115 and proof['Native数'] == 70
          and proof['会計数'] == proof['Viewer資源'] == 840 and proof['前後不変'] is True
          and proof['金融再実行'] is False and proof['採用'] is False and proof['研究目標達成'] is False,
          '正式保存の確認記録を認証。Native/約定/CSV本文を今回再読した証明ではない。')
    check('正式コピーの参照一意性', len(copied) == len(proof['同bytes成果物'])
          and len({row['relative'].casefold() for row in proof['同bytes成果物']}) == len(copied), 'originと正式相対先は重複なし。')
    values = {}
    for name in ('condition', 'core_stop', 'csv_stop', 'price_stop', 'price_request', 'price_check', 'entry_check', 'market', 'formal_stop'):
        reference = request['refs'][name]
        row = copied[normal(reference['path'])]
        values[name] = metadata(TRIAL / row['relative'], reference['sha256'])
    condition, market = values['condition'], values['market']
    configs = condition['actual_configurations']
    check('A0とS0の区別', len(configs) == 12 and {c['policy'] for c in configs} == {'P100'}
          and {c['entry_mode'] for c in configs} == {'A0', 'T', 'TR'} and condition['protection_definition']['version'] == 113,
          'A0は元Source入口＋P113/P100。原S0の損益や保護なし対照へ読み替えない。')
    check('元54参照再用/追加16再生', (market['sessions'], market['books'], market['reused_sessions'], market['replayed_sessions']) == (70, 840, 54, 16)
          and market['condition_sha256'] == request['refs']['condition']['sha256']
          and market['reference114_comparisons'] == 280 and market['all_reference114_equal'] is True and market['all_source111_equal'] is True,
          '旧114A0四条件への全金融比較280。Source全文同体は別の証拠。')

    # ----------------------------------------
    entries = {normal(row['original_path']): row for row in index['entries']}
    expected_code = {**condition['code_sha256'], condition['executable']['path']: condition['executable']['sha256']}
    missing_code = [path for path, sha in expected_code.items() if entries.get(normal(path), {}).get('sha256') != sha]
    missing_extra = [item['ref']['path'] for item in request['code_refs'] if entries.get(normal(item['ref']['path']), {}).get('sha256') != item['ref']['sha256']]
    check('金融閉包と実exe/Root追加コードの収録', len(expected_code) == 1808 and not missing_code and not missing_extra,
          '金融1807＋実exe1とRoot明示code_refs52の各path/SHAが所在索引へ対応。旧ZIP本文は再展開していない。')
    required_owners = {}
    for name in ('actor_stop', 'entry_gate_stop', 'entry_chart_stop', 'entry_input_stop', 'entry_stop', 'save_stop', 'P_stop', 'price_stop', 'binder_stop', 'formal_stop'):
        reference = request['refs'][name]
        row = copied[normal(reference['path'])]
        stopped = metadata(TRIAL / row['relative'], reference['sha256'])
        for field in ('所有コードSHA256', '所有ファイルSHA256'):
            required_owners.update(stopped.get(field, {}))
    missing_owners = [path for path, sha in required_owners.items() if entries.get(normal(path), {}).get('sha256') != sha]
    check('純/bank/Actor/会計/P/入口/DMI/binder/正式所有コード', not missing_owners, '各停止の所有mapを現在の復元先のpath/SHAへ結合。')
    location_counts = Counter(row['location']['kind'] for row in index['entries'])
    check('新規ZIPと既正式/環境の分離', index['同梱数'] == 120 and index['既正式参照数'] == 531
          and index['GoRoot索引数'] == 1251 and index['Goコンパイラ環境参照数'] == 1
          and location_counts['このZIP'] == 120 and location_counts['環境参照のみ'] == 1252
          and index['旧正式ZIP複写'] is False, '実cmd選択716＋依存人工535はGoRoot環境1251。compiler1。旧ZIP全複写0。')
    prohibited = [row['original_path'] for row in index['entries'] if row['location']['kind'] == 'このZIP'
                  and (Path(row['original_path']).suffix.lower() in ('.csv', '.jsonl', '.gz', '.zip') or '.Native.' in row['original_path'])]
    check('新ZIPへ市場/CSV本文の混入なし', not prohibited, '新規120entryの元ファイル種別を索引から確認。ZIP bytes/CRC再検算は正式確認に参照。')
    csv_stop = values['csv_stop']
    old_csv = csv_stop['旧版code前後不変']
    csv_refs = [csv_stop['派生元115停止'], {k: csv_stop['操作marker'][k] for k in ('path', 'sha256')}]
    check('CSV20d9/旧比較所有4/0d45停止/EE57marker', request['refs']['csv_stop']['sha256'] == '20d9db6467a3baefca459fe2dca666c006f3afee604d50edd37da9ef46b79ff8'
          and len(old_csv) == 4 and all(entries.get(normal(p), {}).get('sha256') == h for p, h in old_csv.items())
          and csv_refs[0]['sha256'] == '0d45f2fc3825b207d049e88d796885fd1fa20afd42eb65b80da58b9675c4f954'
          and csv_refs[1]['sha256'] == 'ee57f3cc87f6c7065533fb1fdd5b1c88854b73506b71bdae0a19c32d05217360'
          and all(entries.get(normal(r['path']), {}).get('sha256') == r['sha256'] for r in csv_refs), '旧比較人工のCSV/PNGを複写せず実コード4/停止/既発行markerを参照。追加marker発行を要求しない。')
    price, price_request = values['price_check'], values['price_request']
    check('DMI全70の独立成功', price['成功'] is True and price['stage'] == 'full70' and price['場数'] == 70
          and price['CSV個別解釈数'] == 70 and price['Root要求'] == request['refs']['price_request']
          and price['金融条件SHA256'] == request['refs']['condition']['sha256'] and price['金融完了SHA256'] == request['refs']['market']['sha256']
          and price['独立停止SHA256'] == request['refs']['price_stop']['sha256'] and price['前後不変'] is True
          and price_request['stage'] == 'full70' and len(price_request['scenes']) == len(price['場別']) == 70,
          '同F1/全70金融へ結合した別計算。先頭2を全70の保証へ代用していない。')
    first2 = metadata(TRIAL / '検査/先頭2価格足DMI確認.json', '83dba4d2e9b77c313dccdda36f39decc15dad44905eb7f581f85b629f0cc3e02')
    check('先頭2の段階範囲を保持', first2['成功'] is True and first2['stage'] == 'first2' and first2['場数'] == 2
          and first2['独立停止SHA256'] == price['独立停止SHA256'], '先頭2の別確認を同じ独立停止へ結ぶ。')

    # ----------------------------------------
    unique = metadata(TRIAL / '検査/正式要求の参照一意化.json')
    initial = metadata(Path(unique['初回要求']['path']), unique['初回要求']['sha256'])
    removed = unique['除いた重複']
    old_targets = {item['target'] for item in initial['extra_refs']}
    new_targets = {item['target'] for item in request['extra_refs']}
    old_codes = {(normal(item['ref']['path']), item['ref']['sha256']) for item in initial['code_refs']}
    new_codes = {(normal(item['ref']['path']), item['ref']['sha256']) for item in request['code_refs']}
    added_codes = new_codes - old_codes
    check('初回重複は書込み前拒否/金融不変', unique['成功'] is True and unique['金融条件変更'] is False
          and unique['停止コード変更'] is False and unique['金融再実行'] is False and len(removed) == 1
          and removed[0]['ref'] == request['refs']['price_request'] and initial['refs'] == request['refs']
          and initial['csv_refs'] == request['csv_refs'] and old_targets - new_targets == {removed[0]['target']}
          and new_targets - old_targets == {'検査/正式要求の参照一意化.json'} and old_codes <= new_codes
          and len(added_codes) == 1 and Path(next(iter(added_codes))[0]).name == '正式要求の重複参照を除く.py',
          '重複extra1削除＋訂正proof1追加で件数21は同じ。除重複helperコード1追加。金融/停止refsとCSVは同体。')
    procedure = TRIAL / '再現資料/再現手順.md'
    guide = TRIAL / '再現資料/CSV停止後の実行案内.md'
    text, guide_text = procedure.read_text(encoding='utf-8'), guide.read_text(encoding='utf-8')
    READ[str(procedure)], READ[str(guide)] = digest(procedure), digest(guide)
    check('実金融CLI/CSV分母版CLI', all(term in text for term in ('115連続比較.exe', '--fixed', '--fixed-sha', '--stage', '--out', '--prior54', '--prior54-sha', 'metadata-only'))
          and '115損益CSVの出力_正益経験分母/出力する.mjs' in guide_text and 'CSVを独立再読する.py' in guide_text,
          '元絶対復元先を保つCLIと凍結README旧パスの後段訂正あり。実行自体は行わない。')
    after = {path: digest(Path(path)) for path in READ}
    unchanged = READ == after
    problems = [item for item in CHECKS if not item['成立']]
    previous_path = OWN / '正式保存metadataのレビュー.json'
    out = {'試行': 115, '成功': not problems and unchanged, 'レビュー': '正式保存metadata・コード所在索引・Root要求の限定read-only',
           '訂正前レビュー': {'path': str(previous_path), 'sha256': digest(previous_path)},
           '前回失敗の原因': 'レビュー側がextraの削除1件だけを想定し、訂正proof追加1件を数えず総数差1を要求した誤判定。初回/後継とも21件、refsとCSVに不一致なし。元失敗JSONは保持。',
           '正式保存確認': {'path': str(proof_path), 'sha256': EXPECTED}, '検査': CHECKS, '問題': problems,
           '件数': {'索引行': len(index['entries']), '金融閉包とexe': len(expected_code), 'Root追加code_refs': len(request['code_refs']),
                    '新同梱': index['同梱数'], '既正式参照': index['既正式参照数'], '所在別': dict(location_counts)},
           '入力metadataSHA256前': READ, '入力metadataSHA256後': after, '前後不変': unchanged,
           '未実施': {'自然Native/約定本文': 0, 'Raw/価格CSV/損益CSV本文': 0, '金融再実行': 0, 'ZIP再展開/CRC再検査': 0,
                      '正式保存物編集': 0, '6目次編集': 0},
           '限界': ['Rootがこれから更新するREADME/設定表/共通知見の文面は今回対象外。', 'ViewerはRootの別確認。今回の正式成功をHTTP/描画成功へ拡大しない。', '新旧ZIPのbytes/SHA/CRC/集合は正式保存確認の証拠へ参照。今回は索引と要求の収録集合を照合。']}
    target = OWN / '正式保存metadataのレビュー_参照一意化の追補.json'
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'成功': out['成功'], '問題数': len(problems), 'path': str(target), 'sha256': digest(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
