"""115の成功記録と独立診断を、試行報告と共通知見へ結ぶ。"""

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00115_三時間軸の方向性と局所構造で入口を分ける"


def main() -> None:
    """
    機能: 事前固定文書を保存したまま、結果版と正本へのリンクを反映する。
    引数: なし。
    返り値: None。反映した文書のSHA256と元資料を新規確認JSONへ残す。
    """
    reports = ROOT / "work/115結果の報告準備"
    expected = {
        reports / "README115結果版.md": "8fda044b8310a67239b75c9809d51631d8fc44b6d0f3695fc4303d03b80e97dd",
        reports / "共通知見の案.md": "3310410215ea50b5ec406146ac48a14d7531cf770e51e0a8e72ba2b185170629",
        reports / "実現差のレビュー.md": "22b9331d47f71fb3e7bea2336b941e41fd8b3e71bf7a5cce6433e7bc4b0f8a9b",
        ROOT / "work/115設定表の結果結合準備/全70結果版/設定と結果_全70結果版.md": "3e27641b849464ed8a532dff35cd20a552b330585c49190f990fe6bd2460f326",
        TRIAL / "検査/正式保存の確認.json": "c1e2aefa1bbd8e72289288eab8ea16182d9f99eeff8673271f0843482029015e",
        TRIAL / "検査/Viewer確認.json": "ef5443d38e755e54d77a6272ba6f813f46a8ec75f04472d2d40bf51583ba7dbf",
    }
    for path, digest in expected.items():
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest, path
    text = (reports / "README115結果版.md").read_text(encoding="utf-8")
    text = text.replace("（結果案）", "")
    first = "正式保存・CSV・Viewerの完了はこの案では未確認。同入口22対照の診断は実行中で、共通入口・R追加や幅の費用感度の原因説明は成功後に追補する。"
    assert first in text
    text = text.replace(first, "正式保存・CSV二点の全セル再読・22対照診断も完了。専用Viewerは840一覧IDと11/06日夜24資源の全実約定・費用後純額・残玉0をHTTP照合した。全840GET・描画・目視確認ではない。")
    text = text.replace("取得・数量・経路の分解は同入口診断待ちである。", "同費用で共通する取得・数量・全返済・保存保護は同体であり、今回の差は取得集合の選別である。")
    text = text.replace("期間別の利益/損失・PF・勝率・保存点DD・正益経験率は[数値結合](数値結合.json)に保持する。", "全12条件・全70場の正本は[独立結果](成果物/結果.json)、閲覧用は[全セッションCSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/115損益CSV/全セッション.csv)。0取引場も残す。")
    text = text.replace("[独立結果](../115独立保存F1/全70場/結果.json)", "[独立結果](成果物/結果.json)")
    text = text.replace("[保存検算](../115独立保存F1/全70場/保存会計の確認.json)", "[保存検算](成果物/保存会計の確認.json)")
    text = text.replace("[事前条件と心理の仮説](../../study/00115_三時間軸の方向性と局所構造で入口を分ける/README.md)", "[市場前の条件と心理の原文](根拠/市場前原文/README.md.txt)")
    text = text.replace("[設定表](../../study/00115_三時間軸の方向性と局所構造で入口を分ける/設定と結果.md)", "[設定表](設定と結果.md)")
    text += """

## 同入口と費用による実退出差

同じ費用でA0とTの共通28玉、A0とTRの共通34玉、TとTRの共通28玉は、実取得・枚数・全返済・保存保護が同体だった。Rだけの6玉13枚はC0D0/C0D1/C5D0/C5D1で＋20,999／＋13,999／＋8,999／＋2,999円。ただし主条件は元54の5玉が−924円、追加16の1玉が＋21,923円で、少数かつ期間依存である。

TのC0D0→C5D0は28玉79枚が全て同実入口で、費用を除く実返済が変わったのは5玉。純額差−436,000円は、実粗利益差−357,000円と追加滑り79,000円へ分かれた。費用によってW・追尾の起動・費用床も変わるため、同じ出口へ費用だけを後から引く計算ではない。

最大差の10/15Day売5枚は、両側とも09:53:31に65,380ptで取得。C5は通常幅505ptのまま費用最低床20ptに当たり10:09:40に65,360ptで全返済、純額＋4,615円。C0は最低床10ptでその時点ではhitせず、後のSource部分返済2＋2枚と保護1枚で純額＋314,615円だった。MA収束による狭幅が早期返済の原因ではなかった。両側で成立した実績を比較した差であり、退出後の仮想利益ではない。

詳しい日時・値・限界は[独立した実現差のレビュー](診断/実現差のレビュー.md)、正本は[22対照の診断](診断/同入口と費用差の結果.json)。この一例に合わせて最低床を緩めたり、閾値を変えたりしていない。T/TRの全4費用の損失は保存定義上すべて未起動完結であり、入口の持続性と起動前の保有判断を次に区別する。

## 閲覧・再現

- [候補別集計CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/115損益CSV/候補別集計.csv)と[全セッションCSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/115損益CSV/全セッション.csv)：12×44列、840×40列。正益経験玉と条件付き赤字率を含む。
- [全504セルと設定・結果](設定と結果.md)、[再現手順](再現資料/再現手順.md)、[実行と検査の補足](再現資料/実行と検査の補足.md)。
- [正式保存の確認](検査/正式保存の確認.json)、[入口独立](検査/entry_check.json)、[CSVからの価格足/DMI独立](検査/price_check.json)、[Viewer確認](検査/Viewer確認.json)。
- 専用Viewer：<http://127.0.0.1:8099/>。一覧は `成果物/一覧.resources.json`。既存の他Viewerは変更していない。
- 元の保有区間調査は[112のOHLCと極値到達日時](../00113_起動前の支持否定と利益保護の切替/根拠/112保有区間OHLC/調査.md)。115全玉のOHLCを再形成したという意味ではない。

共有CSVからの独立照合は12,320公表、49,280 OHLC値、123,200 DMI比較。EMA/ATR等の全技法やRaw→CSV形成を独立再計算した証拠ではない。正式コードは新120項目を保存し、旧531項目を参照、GoRoot1251項目はruntime716＋依存人工535の環境参照として区別した。原板・価格CSV・旧ZIPの全体を複写していない。
"""
    (TRIAL / "README.md").write_text(text, encoding="utf-8", newline="\n")
    settings = ROOT / "work/115設定表の結果結合準備/全70結果版/設定と結果_全70結果版.md"
    (TRIAL / "設定と結果.md").write_bytes(settings.read_bytes())

    # ----------------------------------------
    # 一般説明・心理仮説・観測結果を区別した共通知見を反映する。
    common = (reports / "共通知見の案.md").read_text(encoding="utf-8")
    common = common.replace("（115結果案）", "（115）")
    common = common.replace("正式反映前の案で、同入口22対照は未完成。入口T/Rの各原因や費用差の内訳は診断後に追補する。", "22対照・8,037対応の診断と独立加算も完了した。")
    common = common.replace("../../docs/議論/外部再調査/", "外部再調査/")
    common = common.replace("TRの総額はTを4費用とも上回ったが、共通入口の同体やRだけの実現差は診断成功前に断定しない。", "共通28玉は全返済・保存保護も同体で、R追加6玉13枚の純額は4費用で＋20,999／＋13,999／＋8,999／＋2,999円だった。主条件は追加16場の1玉の影響が大きく、一般化はできない。")
    common = common.replace("[数値と費用別/期間別の案](README115結果版.md)と[独立数値結合](数値結合.json)", "[費用別・期間別の結果](../../study/00115_三時間軸の方向性と局所構造で入口を分ける/README.md)と[独立した実現差のレビュー](../../study/00115_三時間軸の方向性と局所構造で入口を分ける/診断/実現差のレビュー.md)")
    common += """

## 費用は実退出も変えた

TのC0D0/C5D0は全28玉79枚が同実入口で、実返済の違いは5玉。純額差43.6万円の内訳は、追加滑り7.9万円と実粗利益の減少35.7万円だった。最大差の10/15Dayは、通常幅の縮小ではなく、費用を含む最低床が10ptから20ptへ変わった実退出差である。別の10/29Dayでは起動の有無が変わった。

したがって、小さい入力差に損益差が比例すると仮定せず、起動・支配した床・要求・実約定を別に保存する。今回は起動後赤字0でも起動前の損失が残り、費用を置くと総額は赤字となった。利益保護と入口の持続性を分ける理由は[外部の一次資料再調査](外部再調査/利益保護と相場の持続性を分ける.md)にも整理した。いずれも最低床を不利に緩める根拠や、現在の70場に合う最適幅の主張ではない。
"""
    common_path = ROOT / "docs/議論/三時間軸の選別と正益後赤字を分けて読む.md"
    with common_path.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(common)
    outputs = [TRIAL / "README.md", TRIAL / "設定と結果.md", common_path]
    value = {"試行": 115, "成功": True, "入力SHA256": {str(p): s for p, s in expected.items()},
             "出力SHA256": {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in outputs},
             "金融条件変更": False, "市場前原文変更": False, "11月09読取": False, "採用": False, "研究目標達成": False}
    proof = Path(__file__).parent / "結果文書の反映確認.json"
    with proof.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(value["出力SHA256"], ensure_ascii=False))


if __name__ == "__main__":
    main()
