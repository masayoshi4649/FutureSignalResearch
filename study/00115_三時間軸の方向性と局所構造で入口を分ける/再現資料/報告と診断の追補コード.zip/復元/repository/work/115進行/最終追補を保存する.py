"""金融保存を変えず、後段の診断・文書コードと訂正記録だけを追補する。"""

import hashlib
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00115_三時間軸の方向性と局所構造で入口を分ける"


def sha(path: Path) -> str:
    """
    機能: 明示したコード・文書・検査ファイルの指紋を算出する。
    引数: path(Path)は原板や価格CSV以外のファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 新しい小資料だけを保存し、追補コードZIPの全entryを検査する。
    引数: なし。
    返り値: None。金融Native・旧ZIP・CSV本文の再複写や金融再演算は行わない。
    """
    original = TRIAL / "検査/正式保存の確認.json"
    assert sha(original) == "c1e2aefa1bbd8e72289288eab8ea16182d9f99eeff8673271f0843482029015e"
    copies = [
        ("work/115最終レビュー/正式保存metadataのレビュー.json", "検査/正式metadataレビュー_初回の条件誤認.json"),
        ("work/115最終レビュー/正式保存metadataのレビュー_参照一意化の追補.json", "検査/正式metadataレビュー.json"),
        ("work/115再現コマンドの補足/CLIレビュー.md", "再現資料/CLIレビュー.md"),
        ("work/115進行/結果文書の反映確認.json", "検査/結果文書の反映確認.json"),
        ("work/115進行/目次の最終更新確認.json", "検査/目次の最終更新確認.json"),
        ("work/115進行/実現差と再現補足の保存確認.json", "検査/実現差と再現補足の保存確認.json"),
        ("work/115進行/11月06日OHLC追補の保存確認.json", "検査/11月06日OHLC追補の保存確認.json"),
        ("work/115専用Viewer8099/プロセス.json", "検査/Viewerプロセス.json"),
    ]
    succeeded = json.loads((ROOT / copies[1][0]).read_text(encoding="utf-8"))
    assert succeeded["成功"] is True
    before = {str(ROOT / s): sha(ROOT / s) for s, _ in copies}
    saved = []
    for source, relative in copies:
        path, target = ROOT / source, TRIAL / relative
        assert target.is_relative_to(TRIAL) and not target.exists()
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as handle:
            handle.write(path.read_bytes())
        assert sha(target) == before[str(path)]
        saved.append({"original": str(path), "relative": relative, "sha256": sha(target), "同bytes": True})

    # ----------------------------------------
    # 市場の全件転記を避け、後段だけのコード・復元入力を保存する。
    codes = [
        "work/115進行/結果文書を反映する.py",
        "work/115進行/最終追補を保存する.py",
        "work/115結果の報告準備/報告案を組み立てる.py",
        "work/115結果の報告準備/監査する.py",
        "work/115結果の報告準備/11月06日のOHLCを結ぶ.py",
        "work/115最終レビュー/正式metadataを読む.py",
        "work/115結果の報告準備/README115結果版.md",
        "work/115結果の報告準備/共通知見の案.md",
    ]
    archive_path = TRIAL / "再現資料/報告と診断の追補コード.zip"
    assert not archive_path.exists()
    entries = []
    with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for relative in codes:
            path = ROOT / relative
            name = "復元/repository/" + relative
            body = path.read_bytes()
            assert ".." not in Path(name).parts and path.suffix in (".py", ".md")
            before[str(path)] = hashlib.sha256(body).hexdigest()
            archive.writestr(name, body)
            entries.append({"original_path": str(path), "entry": name, "sha256": before[str(path)], "bytes": len(body),
                            "役割": "金融正式ZIP停止後の記述診断・報告。MD二点は報告生成の固定入力で、現在の結果版ではない。"})
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None and set(archive.namelist()) == {r["entry"] for r in entries}
        for row in entries:
            body = archive.read(row["entry"])
            info = archive.getinfo(row["entry"])
            assert len(body) == row["bytes"] and hashlib.sha256(body).hexdigest() == row["sha256"]
            row["CRC"] = info.CRC
    index = TRIAL / "再現資料/追補コード所在.json"
    value = {"試行": 115, "成功": True, "ZIP": {"path": str(archive_path), "sha256": sha(archive_path)},
             "entries": entries, "全SHA_CRC_集合": True, "金融正式索引変更": False, "市場データ同梱": False}
    with index.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    assert all(sha(Path(path)) == digest for path, digest in before.items()) and sha(original) == "c1e2aefa1bbd8e72289288eab8ea16182d9f99eeff8673271f0843482029015e"
    proof = TRIAL / "検査/正式追補の確認.json"
    result = {"試行": 115, "成功": True, "保存": saved, "追補コード索引": {"path": str(index), "sha256": sha(index)},
              "入力SHA256前": before, "入力SHA256後": {p: sha(Path(p)) for p in before}, "前後不変": True,
              "元正式保存SHA256": sha(original), "元の金融ZIP変更": False, "金融再実行": False,
              "Raw_価格CSV_Native追加複写": False, "11月09読取": False, "採用": False, "研究目標達成": False}
    with proof.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"成功": True, "確認": {"path": str(proof), "sha256": sha(proof)}, "追補コード数": len(entries)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
