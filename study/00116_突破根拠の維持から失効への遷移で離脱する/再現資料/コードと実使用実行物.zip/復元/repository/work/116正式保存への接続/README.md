# 116正式保存への接続の準備

旧115正式保存器と分類器をSHA認証して再用する、新規の116保存器。市場前のコード・小metadata・人工だけで準備し、Rootの正式解禁まで保存本文を読まない。金融116F1は変更しない。

## 薄く残す範囲

- 金融1855コード＋実exe、Core/Pure/Actor、Raw Reader/consumer/要求builder、独立会計/P/life、54継承runner、CSV/表/可逆圧縮、明示したRoot helperを分類する。金融閉包と後段コードを区別する。
- 旧111〜115の正式索引は同path同SHAを優先し、同bytes別pathも直接の旧ZIP entry又は正式metadata参照へ平坦化する。復元先は現在のpathのまま。同じ新規bytesもZIP内は一度だけ同梱し、各restore先を索引へ保持する。
- GoRoot・コンパイラとNode/artifactは環境参照。Goの実コードは除外せず全SHA索引へ、生成testmainは金融閉包へ混ぜない。旧ZIP全複写、ライブラリ全複写はしない。
- Nativeは元gzip527MBを正式へ複写せず、可逆zstd索引を`成果物_金融/Native可逆圧縮索引.json`、同階層の`Native_zstd/`70点として保存する。JSON本文を再解析・金融再実行しない。Go1.24.2の再圧縮exeとsourceも保存し、必要時に未作成work先へ元gzipを同SHA/size復元する。普通のNative.json.gzが正式に存在すると見せる一覧は作らない。
- 元54からの実trades1944と追加16の576を元catalog基準で解決し、正式`成果物/`へ2520点を保存する。閲覧用の新catalogは正式内へ相対参照し、元の独立catalogも検査へ同bytes保存する。市場価格は共用入力の参照のみで、本文を開かない。
- CSV2点はoutputs唯一正本。現在SHAと全セル再読成功を結び、正式側へCSVを複写・再生成しない。CSVのRawstatusは元保存点検算の範囲を保持し、別のRaw全70成功と混同しない。
- Raw監査の各場JSONは、元bytesのまま`検査/Raw当場結果.tar.gz`へ束ね、元Ref/SHA/size/member名の索引へ結ぶ。原板・全tickの保存ではない。

既存README・設定と結果・設計候補・根拠・市場前原文は変更しない。全対象先を事前に検査し、重複extra/同じ入力の二重保存/既存先を正式書込み前に拒否する。途中失敗を全保存成功とする処理はない。

## 未許可Rootテンプレと保存gate

`Root正式要求_未許可.json`は`fixed:false`、`formal_write_authorized:false`、`market_native_read_authorized:false`、`raw_audit_read_authorized:false`。Rootが成功後の新要求へ実Refを結ぶまで最初のgateで拒否する。必要な主要Refは次の通り。

| Ref名 | 内容 |
| --- | --- |
| condition / market | 同116F1／全70金融2520・旧115比較840・Source同体・残予約0 |
| result / saved_check / base54_check | 全70独立2520・元54の1944成功。54認証継承＋16新検算を区別 |
| save_stop / P_stop / life_stop / reuse_stop | 実演算397eとP/life、型復元後の274f再用runner |
| csv_stop / csv_check / binder_stop | CSV806e／36候補2520行の全セル再読／表f488 |
| native_stop / native_request / native_index | bytes保管f9a6／実Root要求／可逆成功81ee44… |
| raw_reader_stop / raw_consumer_stop / raw_builder_stop | Reader8280／consumer1afe／builder1121 |
| raw_request / raw_check | 同金融・独立結果へ結ぶ全70consumer Root要求とRootの70場成功集約 |
| formal_stop / code_sources / code_material | この正式器のRoot承認後停止／停止コードRef一覧／認証済分類素材 |

Raw集約schemaはRoot共有のとおり、試行116・成功true・stage full70・場数70、金融条件/金融完了/独立保存結果/独立保存確認/Root要求のRef、全Rawライフ初回性true・P100H100初回性true・P100全床/全追尾幅Raw再形成false・前後不変true、結果`[{session,ref}]`を持つ。当場証拠も同金融/同Root要求とReader summary＋exit0を認証する。監視適格な実XC/XQの取得〜最終返済和集合だけが範囲で、X0・不適格・新規fill最初性・P100全床を含めない。

全70金融は元54Native参照再用＋16再生。全70独立も元54成功継承＋16新検算で、全70Nativeの新しい意味再検算とは記さない。原文166の81比較は元54の三手法Event再実行対照の範囲で、当時保存全文・全tickStateの同体ではない。X0は元入口115＋共通P100であり、S0原手法とは呼ばない。

## 実行口

```powershell
python -X utf8 work/116正式保存への接続/コードを分類する.py --fixed <116F1絶対path> --sha256 <F1_SHA> --sources <保存コードの依存参照.json絶対path> --sources-sha <そのSHA> --output <未作成の分類素材JSON>
python -X utf8 work/116正式保存への接続/検査して停止する.py --output <未作成の停止前検査folder>
# Rootレビュー後だけ正式停止する。停止前証拠は上書きしない。
python -X utf8 work/116正式保存への接続/検査して停止する.py --output <別の未作成停止folder> --reviewed --stop
python -X utf8 work/116正式保存への接続/正式保存する.py --request <Root新固定要求> --request-sha <SHA> --metadata-only
python -X utf8 work/116正式保存への接続/正式保存する.py --request <Root新固定要求> --request-sha <SHA>
```

正式器のmetadata-onlyも解禁後だけ使用する。市場JSONやtrades/zstdの指紋認証は行うが、Native復号・CSV算術再読・原板走査・正式書込みはしない。準備段階ではこの口を自然データへ実行しない。

`code_refs:[{ref,role}]`は後段Root helperを追加する公開口、`extra_refs:[{ref,target,role}]`は小metadata/文書/明示圧縮診断を追加する口。停止後に増えたhelperは別のRoot追補要求へ結ぶ。既存116のコード索引を次の分類のpriorへ追加すれば旧bytesを再複写せず、追補用の別ZIP/索引/証拠へ残せる。元ZIP・元保存確認を更新しない。

現在は準備。正式保存・Viewer確認・研究目標達成・採用は未実施／false。Raw/Native/CSV本文と11/09の読取は、この準備では0。
