"""116の全成功証拠から、新規コード・可逆Native・実約定だけを正式保存する。"""

from __future__ import annotations

import argparse
from collections import Counter
from copy import deepcopy
import gzip
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import shutil
import tarfile

import コードを分類する as K


OWN, ROOT = K.OWN, K.ROOT
TRIAL = ROOT / 'study/00116_突破根拠の維持から失効への遷移で離脱する'
OLD = ROOT / 'work/115正式保存への接続/正式保存する.py'
OLD_SHA = '491a8ea62254815543c9aa5f3726b008f2f9909ed1b0f33f74d923d268a76289'
K.need(K.sha(OLD) == OLD_SHA, '旧115正式保存器の不変')
SPEC = importlib.util.spec_from_file_location('116が再用する115保存共通部', OLD)
F = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(F)
C, Z = F.C, F.Z
need, sha, read, bind, write_json = C.need, C.sha, C.read, C.bind, C.write_json
COMPLETE_SHA = 'e9b5c2db15e2968b627b9f38ed1d8b53b9ba294800b96e35839fec4d25f38131'
NATIVE_SHA = '81ee44bb051b60c6a20b75a063c07c36ff50be2f41d265a9d48278887af75a3d'
CONFIGS = tuple({'policy': 'P100', 'life_mode': life, 'entry_mode': mode, 'slip_pts': slip, 'delay_seconds': delay}
                for life in ('X0', 'XC', 'XQ') for mode in ('A0', 'T', 'TR') for slip in (0, 5) for delay in (0, 1))
KEYS = tuple((f'{r["entry_mode"]}_C{r["slip_pts"]}_D{r["delay_seconds"]}' if r['life_mode'] == 'X0'
              else f'{r["entry_mode"]}_{r["life_mode"]}_C{r["slip_pts"]}_D{r["delay_seconds"]}') for r in CONFIGS)
OWN_NAMES = ('コードを分類する.py', '正式保存する.py', '人工検査.py', '検査して停止する.py', 'README.md', '保存コードの依存参照.json')
REQUIRED = {'condition', 'market', 'result', 'saved_check', 'base54_check', 'reuse_stop', 'csv_stop', 'csv_check',
            'binder_stop', 'native_stop', 'native_request', 'native_index', 'raw_reader_stop', 'raw_consumer_stop',
            'raw_builder_stop', 'raw_request', 'raw_check', 'formal_stop', 'code_material', 'code_sources',
            'save_stop', 'P_stop', 'life_stop'}


def same(a: dict, b: dict) -> bool:
    """機能: optional bytesとslash表記を金融値と混ぜず参照を比較する。

    引数: a/b(dict)はFileRef。
    返り値: boolは絶対位置とSHA同体。比較だけで原板を開かない。
    """
    def key(x: dict) -> tuple:
        """機能: FileRefを字句正規化する。

        引数: x(dict)はFileRef。返り値: tupleは絶対pathとSHA。
        """
        need({'path', 'sha256'} <= set(x) <= {'path', 'sha256', 'bytes'}, '明示FileRef')
        need('bytes' not in x or type(x['bytes']) is int and x['bytes'] >= 0, 'optional bytesは非負整数')
        p = Path(x['path'])
        need(p.is_absolute(), '参照は絶対位置')
        return os.path.normcase(os.path.normpath(str(p))), x['sha256']
    return key(a) == key(b)


def validate(values: dict, request: dict) -> list:
    """機能: 36×70と旧12×70、独立54継承＋16新検算の成功を結ぶ。

    引数: values/request(dict)は認証済みmetadataとRoot要求。
    返り値: listは70場順。金融損益を再計算しない。
    """
    refs = request['refs']
    condition, market, result, check = (values[n] for n in ('condition', 'market', 'result', 'saved_check'))
    expected = C.sessions()
    need(condition['trial'] == 116 and condition['fixed'] is True and condition['actual_configurations'] == list(CONFIGS), '116の本名36条件')
    need(condition['protection_definition']['version'] == 113 and condition['protection_definition']['policy'] == 'P100'
         and condition['entry_gate_definition']['version'] == 115 and condition['lifecycle_definition']['version'] == 116, 'P100/入口115/life116を分離')
    need(condition['entry_grid_seconds'] is None and condition['extra_opening_quiet_seconds'] == 0, '元の連続時計')
    need(market['trial'] == 116 and market['success'] is True and market['stage'] == 'full70'
         and (market['sessions'], market['books'], market['reused_sessions'], market['replayed_sessions']) == (70, 2520, 54, 16), '全70金融/認証再用54/再生16')
    need(market['condition_sha256'] == refs['condition']['sha256'] and market['unchanged'] is True
         and market['before'] and market['before'] == market['after'], '同F1金融前後不変')
    need(market['reference115_comparisons'] == 840 and market['all_reference115_equal'] is True
         and market['all_source111_equal'] is True and market['all_original166_reference_events_equal'] is True
         and market['historical_saved_events_equal'] is False and market['all_original_signal_full_json_equal'] is False, '旧115対照840/Source/oracleの範囲')
    need([r['session'] for r in market['results']] == expected, '金融70場の順序')
    need(all(r['books'] == 36 and r['x0_comparisons'] == 12 and r['x0_equal'] is True and r['complete'] is True
             and r['open_quantity'] == r['pending_quantity'] == 0 and r['reference115_comparisons'] == 12
             and r['reference115_equal'] is True and r['source111_equal'] is True for r in market['results']), '全場36/旧12/flat')
    for x in (result, check):
        need(x['試行'] == 116 and x['成功'] is True and x['stage'] == 'full70' and x['場数'] == 70 and x['会計数'] == 2520, '独立全70の保存成功')
        need(x['金融条件SHA256'] == refs['condition']['sha256'] and x['金融完了SHA256'] == refs['market']['sha256']
             and x['前後不変'] is True and x['入力codeSHA256前'] == x['入力codeSHA256後'], '独立保存の同F1と前後不変')
        need(x['独立再用場数'] == 54 and x['独立新規検算場数'] == 16 and x['全70の金融Native再検算'] is False
             and x['元54再用runner停止SHA256'] == refs['reuse_stop']['sha256'], '元54継承と追加16新検算を区別')
        need(x['採用'] is False and x['研究目標達成'] is False, '保存成功と研究目標を分離')
        need(x['保存器停止SHA256'] == refs['save_stop']['sha256'] and x['独立P停止SHA256'] == refs['P_stop']['sha256']
             and x['独立ライフ停止SHA256'] == refs['life_stop']['sha256']
             and x['Actor停止SHA256'] == condition['dependency_stops']['actor']['sha256']
             and x['純ライフ停止SHA256'] == condition['dependency_stops']['lifecycle']['sha256'], '実演算の保存/P/life/Actor停止')
    need(same(values['reuse_stop']['元保存器停止'], refs['save_stop'])
         and same(values['save_stop']['P停止'], refs['P_stop']) and same(values['save_stop']['ライフ停止'], refs['life_stop']), '再用runnerと演算停止の依存同体')
    need(check['資源'] == 2520 and check['X0全金融比較'] == check['旧115全金融比較'] == 840
         and check['全Source111同体'] is True and check['全残玉予約0'] is True and check['不一致数'] == 0, '独立会計の全件確認')
    need(check['出力SHA256']['結果.json'] == refs['result']['sha256'], '結果SHAと保存確認')
    need(result['主key'] == list(KEYS) and len(result['場別']) == 2520 and set(result['集計']) == set(KEYS), '36候補と全0場を保持')
    need([(r['session'], r['key']) for r in result['場別']] == [(s, k) for s in expected for k in KEYS], '2520行順序と重複/欠落なし')
    base = values['base54_check']
    need(base['試行'] == 116 and base['成功'] is True and base['stage'] == 'base54' and base['場数'] == 54
         and base['会計数'] == 1944 and base['金融条件SHA256'] == refs['condition']['sha256']
         and base['前後不変'] is True and base['不一致数'] == 0, '独立元54成功')
    need(same(result['元54再用']['check'], refs['base54_check']), '実際に継承した元54検算Ref')
    for key in KEYS:
        combined = Counter()
        for row in result['場別']:
            if row['key'] == key:
                need(row['入口票検査']['成功'] is True, '当場の入口独立成功')
                combined.update(row['入口票検査']['counts'])
        need(combined == Counter(result['入口票集計'][key]), '入口Counterの零省略は同値: ' + key)
    return expected


def validate_native(index: dict, request: dict, market: dict, expected: list) -> list:
    """機能: 可逆zstdの成功索引を元金融70参照へ結ぶ。

    引数: index/request/market(dict)、expected(list)はbytes証拠と金融metadata。
    返り値: listは保存するzstd行。元gzip/JSON本文は復号しない。
    """
    refs = request['refs']
    need(index['trial'] == 116 and index['success'] is True and index['sessions'] == 70
         and index['policy'] == 'native_payload_zstd3_window29_ldm_restore_go1242_v1'
         and same(index['condition'], refs['condition']) and same(index['financial_completion'], refs['market'])
         and same(index['Root要求'], refs['native_request']), '可逆Native索引と同F1全70成功')
    need(index['前後不変'] is True and index['入力codeSHA256前'] == index['入力codeSHA256後'], '可逆処理の入力前後不変')
    need(index['restore']['Go_version'] == 'go1.24.2'
         and index['restore']['executable']['sha256'] == 'a06c854ce4bfe6db22a3329e28a571a56454dfaaf11c90af1e33efc9a4e12c9c', '実保存する旧Go再圧縮exe')
    need([r['session'] for r in index['Native_zstd']] == expected, 'Native zstd70順序')
    for row, scene in zip(index['Native_zstd'], market['results']):
        need(same(row['source_original_gzip'], scene['native']) and row['restored_gzip_sha256'] == scene['native']['sha256']
             and row['restored_gzip_bytes'] == row['source_gzip_bytes']
             and row['restored_json_all_bytes_equal'] is True and row['restored_gzip_all_bytes_equal'] is True, '元JSON/gzip全bytes可逆証拠')
        need(row['stored_relative'] == 'Native_zstd/' + row['session'] + '.Native.json.zst'
             and row['stored_format'] == 'zstd_of_exact_json_bytes', '実在zstdだけを正式所在にする')
    return index['Native_zstd']


def validate_raw(check: dict, refs: dict, expected: list) -> list:
    """機能: Rootが全70の窓監査を再認証した集約を結ぶ。

    引数: check/refs(dict)、expected(list)はRoot集約と金融Ref。
    返り値: listは当場監査Ref。X0/不適格/P100全床への証明拡大はしない。
    """
    need(check['試行'] == 116 and check['成功'] is True and check['stage'] == 'full70' and check['場数'] == 70
         and check['全Rawライフ初回性'] is True and check['P100H100初回性'] is True
         and check['P100全床/全追尾幅Raw再形成'] is False and check['前後不変'] is True, '全70の明示範囲Raw監査成功が必須')
    for field, name in (('金融条件', 'condition'), ('金融完了', 'market'), ('独立保存結果', 'result'),
                        ('独立保存確認', 'saved_check'), ('Root要求', 'raw_request')):
        need(same(check[field], refs[name]), 'Raw集約の参照結合: ' + field)
    need([r['session'] for r in check['結果']] == expected, 'Raw監査70場順序/重複欠落なし')
    return check['結果']


def validate_csv(check: dict, refs: dict, csv_refs: dict) -> None:
    """機能: outputs唯一正本2点と36/2520全セル再読成功を結ぶ。

    引数: check/refs/csv_refs(dict)は再読証拠と明示Ref。
    返り値: None。CSV本文の第三再計算・複写はしない。
    """
    need(check['試行'] == 116 and check['成功'] is True and check['場別行数'] == 2520 and check['候補数'] == 36
         and check['全場累計再計算'] is True and check['正益経験分母合算'] is True
         and check['正益経験赤字率を原分母から再計算'] is True and check['未定義比率は空欄'] is True
         and check['前後不変'] is True and check['入力SHA256'] == check['後SHA256'], '116 CSV全セル独立再読')
    need(check['入力SHA256'].get(str(Path(refs['result']['path']).resolve())) == refs['result']['sha256'], 'CSVは同独立結果')
    need(set(csv_refs) == {'候補別集計.csv', '全セッション.csv'}, 'CSV正本2点')
    for name, value in csv_refs.items():
        p = Path(value['path']).resolve()
        need(p.is_relative_to((ROOT / 'outputs').resolve()) and p.name == name
             and check['入力SHA256'].get(str(p)) == value['sha256'], 'outputs正本の現在SHA')


def viewer_plan(catalog: dict, catalog_dir: Path, check: dict, expected: list, destination: Path) -> tuple[list, dict]:
    """機能: 旧54相対参照を解決し全2520実tradesの正式内catalogを作る。

    引数: catalog/check(dict)、catalog_dir/destination(Path)、expected(list)は実一覧と検算。
    返り値: tuple[list,dict]はコピーFileRef群と新閲覧一覧。価格は字句参照のみ。
    """
    need(catalog['schema_version'] == 1 and catalog['path_base'] == 'catalog', 'Viewer相対基準')
    need([(r['session'], r['method_id']) for r in catalog['resources']] == [(s, k) for s in expected for k in KEYS], '全2520Viewer ID順序')
    result, files = deepcopy(catalog), []
    for row in result['resources']:
        name = f"116_{row['method_id']}_{row['session']}.trades.jsonl"
        need(row['id'] == name.removesuffix('.trades.jsonl') and row['pnl_format'] == 'trades'
             and row['pnl_basis'] == 'net' and row['product'] == 'NK225mini' and row['point_value'] == 100, 'Viewer本名/費用後/点価')
        path = (catalog_dir / row['pnl_path']).resolve()
        need(path.name == name, '実trades本名')
        digest = (check['Viewer参照再用SHA256'].get(str(path)) if Path(row['pnl_path']).name != row['pnl_path']
                  else check['出力SHA256'].get(name))
        need(isinstance(digest, str) and len(digest) == 64, '旧54参照又は追加16の保存SHAが必要')
        files.append({'ref': {'path': str(path), 'sha256': digest}, 'target': '成果物/' + name})
        market = Path(row['market_path'])
        market = Path(os.path.normpath(str(market if market.is_absolute() else catalog_dir / market)))
        need(market.is_absolute() and not market.is_relative_to((ROOT / 'work').resolve()), '市場価格は共有入力参照。work中間を恒久参照しない')
        row['market_path'] = os.path.relpath(market, destination).replace('\\', '/')
        row['pnl_path'] = name
    return files, result


def reserve_copy(value: dict, relative: str, destination: Path, before: dict, plans: list,
                 target_names: set, source_names: set) -> None:
    """機能: 全コピー先を正式書込み前に予約して重複を拒否する。

    引数: value(dict)、relative(str)、destination(Path)、before(dict)、plans(list)、target_names/source_names(set)。
    返り値: None。原板・価格CSV・元金融gzipを正式転記しない。
    """
    need(Z.safe(relative), '安全な正式相対位置')
    p = Path(value['path']).resolve()
    need(p.is_relative_to(ROOT) and p.suffix.lower() != '.csv' and not p.name.endswith('.Native.json.gz'), '共有Raw/CSV/元金融gzipは複写しない')
    target = (destination / relative).resolve()
    need(target.is_relative_to(destination.resolve()) and not target.exists() and str(target).casefold() not in target_names, '既存正式物を上書きしない')
    need(str(p) not in source_names, '同じ入力の正式二重転記をしない')
    bind(value, before)
    target_names.add(str(target).casefold())
    source_names.add(str(p))
    plans.append({'source': str(p), 'relative': relative, 'target': str(target), 'sha256': value['sha256']})


def prepare(request_ref: dict) -> dict:
    """機能: Root新固定要求の解禁後だけ全保存先を認証する。

    引数: request_ref(dict)は全段階成功後のRoot要求。
    返り値: dictは新規コピー/コード/圧縮監査の計画。旧文書を上書きしない。
    """
    before = {}
    request = read(request_ref, before)
    need(request.get('version') == 1 and request.get('trial') == 116 and request.get('fixed') is True
         and request.get('stage') == 'full70' and request.get('formal_write_authorized') is True
         and request.get('market_native_read_authorized') is True and request.get('raw_audit_read_authorized') is True,
         'Rootが正式保存と成功本文を明示解禁するまで拒否')
    refs = request['refs']
    need(REQUIRED <= set(refs) and refs['condition']['sha256'] == K.F1_SHA and refs['market']['sha256'] == COMPLETE_SHA
         and refs['native_index']['sha256'] == NATIVE_SHA, '金融F1/完了/可逆索引の実固定')
    formal = read(refs['formal_stop'], before)
    need(formal['試行'] == 116 and formal['成功'] is True and formal['停止'] is True and formal['市場前'] is True, 'この正式器の停止が先')
    need(set(formal['所有ファイルSHA256']) == {str(OWN / n) for n in OWN_NAMES}, 'この正式器の全所有')
    for path, digest in formal['所有ファイルSHA256'].items():
        bind({'path': path, 'sha256': digest}, before)
    values = {name: read(value, before) for name, value in refs.items() if name != 'formal_stop'}
    values['formal_stop'] = formal
    for name, value in values.items():
        if name.endswith('_stop'):
            need(value['成功'] is True and value.get('停止') is True, '正式に停止済みの依存だけ: ' + name)
    for name, value in values['code_sources']['stops'].items():
        if name in refs:
            need(same(value, refs[name]), '分類と実保存は同じ停止: ' + name)
    raw_root = values['raw_request']
    need(raw_root['trial'] == 116 and raw_root['fixed'] is True and raw_root['stage'] == 'full70'
         and same(raw_root['consumer_stop'], refs['raw_consumer_stop']) and same(raw_root['condition'], refs['condition'])
         and same(raw_root['completion'], refs['market']) and same(raw_root['independent_result'], refs['result'])
         and same(raw_root['independent_check'], refs['saved_check']), '実Raw Root要求と同じconsumer/金融/独立保存')
    native_root = values['native_request']
    need(native_root['trial'] == 116 and native_root['fixed'] is True
         and same(native_root['code_stop'], refs['native_stop']) and same(native_root['condition'], refs['condition'])
         and same(native_root['completion'], refs['market']), '実可逆Root要求と同じ停止/金融')
    reader_ref = raw_root['reader_request']
    reader_root = read(reader_ref, before)
    need(reader_root['trial'] == 116 and reader_root['fixed'] is True and reader_root['stage'] == 'full70'
         and same(reader_root['reader_stop'], refs['raw_reader_stop']), 'consumerが実使用した同Root Reader要求')
    expected = validate(values, request)
    native = validate_native(values['native_index'], request, values['market'], expected)
    raw = validate_raw(values['raw_check'], refs, expected)
    validate_csv(values['csv_check'], refs, request['csv_refs'])
    for value in request['csv_refs'].values():
        bind(value, before)
    material = values['code_material']
    need(material['試行'] == 116 and material['成功'] is True and material['前後不変'] is True
         and same(material['Root金融条件'], refs['condition']) and same(material['依存Ref一覧'], refs['code_sources']), '停止済分類素材と同Root')
    plans, target_names, source_names = [], set(), set()

    def add(value: dict, relative: str) -> None:
        """機能: 全入力と未作成先を正式書込み前に予約する。

        引数: value(dict)、relative(str)はRefと正式内安全名。
        返り値: None。重複・既存・入力金融gzip/CSV/Rawは拒否。
        """
        reserve_copy(value, relative, TRIAL, before, plans, target_names, source_names)

    saved_dir = Path(refs['result']['path']).parent
    add(refs['result'], '成果物/結果.json')
    add(refs['saved_check'], '成果物/保存会計の確認.json')
    catalog_ref = {'path': str(saved_dir / '一覧.resources.json'), 'sha256': values['saved_check']['出力SHA256']['一覧.resources.json']}
    catalog = read(catalog_ref, before)
    files, viewer = viewer_plan(catalog, saved_dir, values['saved_check'], expected, TRIAL / '成果物')
    for row in files:
        add(row['ref'], row['target'])
    add(catalog_ref, '検査/元独立保存の一覧.resources.json')
    add(refs['native_index'], '成果物_金融/Native可逆圧縮索引.json')
    for row in native:
        add(row['stored_zstd'], '成果物_金融/' + row['stored_relative'])
    for name, value in refs.items():
        if name not in ('result', 'saved_check', 'native_index'):
            add(value, '検査/' + name + '.json')
    add(reader_ref, '検査/RawReaderの要求.json')
    add(raw_root['save_request'], '検査/Rawconsumerが結ぶ独立保存の全70要求.json')
    add(request_ref, '検査/正式保存の要求.json')
    for item in request.get('extra_refs', []):
        need(set(item) == {'ref', 'target', 'role'} and item['target'].split('/')[0] in ('診断', '検査', '再現資料'), '後段の明示extraだけ')
        p = Path(item['ref']['path'])
        need((p.suffix.lower() in ('.json', '.md', '.py', '.mjs', '.ps1', '.txt') or p.name.endswith('.json.gz'))
             and '.Native.' not in p.name, '全件tick/価格/Nativeをextraへ重複しない')
        add(item['ref'], item['target'])
    for item in raw:
        p = read(item['ref'], before)
        need(p['試行'] == 116 and p['成功'] is True and p['stage'] == 'full70' and p['場'] == item['session']
             and p['全Rawライフ初回性'] is True and p['P100H100初回性'] is True
             and p['P100全床/全追尾幅Raw再形成'] is False and p['Reader成功summaryとexit0'] is True
             and p['前後不変'] is True and p['入力SHA256前'] == p['入力SHA256後'], '当場Raw consumerの全成功')
        need(same(p['金融条件'], refs['condition']) and same(p['金融完了'], refs['market'])
             and same(p['Root要求'], refs['raw_request']), '当場Raw監査の同金融/Root要求')
    sources = deepcopy(values['code_sources'])
    source_code = {}
    expected_code = {**values['condition']['code_sha256'], values['condition']['executable']['path']: values['condition']['executable']['sha256']}
    need(material['金融と実行物SHA256'] == expected_code and len(expected_code) == 1856, '金融1855＋実exeの素材全集合')
    for row in material['entries']:
        K.add_code(source_code, row['original_path'], row['sha256'])
    need(all(source_code.get(p) == digest for p, digest in expected_code.items()), '金融コードの欠落/改竄なし')
    for item in request.get('code_refs', []):
        K.add_code(source_code, item['ref']['path'], item['ref']['sha256'])
    for p in formal['所有ファイルSHA256']:
        K.add_code(source_code, p, formal['所有ファイルSHA256'][p])
    prior = [(read(ref, before), ref) for ref in material['旧正式索引']]
    core = read(values['condition']['runtime_stop'], before)
    rows, roots, env = K.classify_rows(source_code, core, prior)
    archives, inherited = {}, {(str(Path(ref['path']).resolve()), ref['sha256']): data for data, ref in prior}
    copied = {r['source']: r['relative'] for r in plans}
    new, by_digest = [], {}
    for row in rows:
        bind({'path': row['original_path'], 'sha256': row['sha256']}, before)
        if row['kind'] in ('GoRoot環境参照', 'Goコンパイラ環境参照'):
            continue
        if row['location']['kind'] in ('既正式ZIP参照', '既正式metadata参照'):
            F.authenticate_location(row, inherited, before, archives)
            continue
        if row['original_path'] in copied:
            row['location'] = {'kind': '正式同bytes成果物', 'relative': copied[row['original_path']]}
            continue
        ident = (row['sha256'], row['bytes'])
        entry = by_digest.get(ident)
        if entry is None:
            entry = row['location']['entry']
            row['location'] = {'kind': 'このZIP', 'entry': entry}
            new.append(row)
            by_digest[ident] = entry
        else:
            row['location'] = {'kind': 'このZIP', 'entry': entry}
            row['新ZIP内同bytes参照'] = True
    generated = ('成果物/一覧.resources.json', '成果物_金融/保管方式と復元先.json', '再現資料/コードと実使用実行物.zip',
                 '再現資料/コード所在索引.json', '再現資料/再現手順.md', '再現資料/CSV所在と確認.json',
                 '検査/Raw当場結果.tar.gz', '検査/Raw当場結果の索引.json', '検査/正式保存の確認.json')
    need(all(not (TRIAL / name).exists() and str((TRIAL / name).resolve()).casefold() not in target_names for name in generated), '全生成先も未作成')
    return {'request': request, 'request_ref': request_ref, 'before': before, 'plans': plans, 'viewer': viewer,
            'raw': raw, 'index': rows, 'archived': new, 'roots': roots, 'environment': env, 'material': material}


def pack_raw(destination: Path, rows: list) -> list:
    """機能: 成功監査JSONだけを元bytesのまま一つの圧縮tarへ束ねる。

    引数: destination(Path)、rows(list)は未作成archiveと認証済当場Ref。
    返り値: listは元JSON_SHA/size/安全member名。原板や全tickを保存しない。
    """
    result = []
    with destination.open('xb') as target, gzip.GzipFile(filename='', fileobj=target, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.USTAR_FORMAT) as archive:
            for row in rows:
                body = Path(row['ref']['path']).read_bytes()
                need(hashlib.sha256(body).hexdigest() == row['ref']['sha256'], 'Raw監査JSONの直前SHA')
                name = row['session'] + '/結果.json'
                need(Z.safe(name), '監査tar安全名')
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(body), 0o644, 0
                archive.addfile(info, io.BytesIO(body))
                result.append({'session': row['session'], 'member': name, 'origin': row['ref'], 'bytes': len(body), 'sha256': row['ref']['sha256']})
    with tarfile.open(destination, 'r:gz') as archive:
        need(archive.getnames() == [r['member'] for r in result], '監査tar全集合/順序')
        for row in result:
            body = archive.extractfile(row['member']).read()
            need(len(body) == row['bytes'] and hashlib.sha256(body).hexdigest() == row['sha256'], '監査JSONの全bytes復元')
    return result


def execute(request_ref: dict) -> dict:
    """機能: 全gate通過後だけ未作成の正式先へ保存する。

    引数: request_ref(dict)はRoot新固定要求。
    返り値: dictは正式確認Ref。金融/Raw再実行やCSV生成は行わない。
    """
    plan = prepare(request_ref)
    copied = []
    for row in plan['plans']:
        source, target = Path(row['source']), Path(row['target'])
        need(sha(source) == row['sha256'] and not target.exists(), 'コピー直前の不変/新規先')
        target.parent.mkdir(parents=True, exist_ok=True)
        with source.open('rb') as src, target.open('xb') as dst:
            shutil.copyfileobj(src, dst)
        need(sha(source) == sha(target) == row['sha256'], '正式コピー同bytes')
        copied.append({'relative': row['relative'], 'origin': {'path': row['source'], 'sha256': row['sha256']}, '同bytes': True})
    write_json(TRIAL / '成果物/一覧.resources.json', plan['viewer'])
    archive = TRIAL / '再現資料/コードと実使用実行物.zip'
    archive.parent.mkdir(parents=True, exist_ok=True)
    Z.write_zip(archive, plan['archived'])
    checks = Z.verify_zip(archive, plan['archived'])
    for row in plan['index']:
        if row['location']['kind'] == 'このZIP':
            row['location'].update(checks[row['location']['entry']])
    code_index = TRIAL / '再現資料/コード所在索引.json'
    write_json(code_index, {'試行': 116, '成功': True, 'Root要求': request_ref, 'ZIP': K.reference(archive),
                           'entries': plan['index'], 'restore_roots': plan['roots'], 'go_environment': plan['environment'],
                           'Nodeとartifact環境': plan['material']['Nodeとartifact環境'], '旧正式索引': plan['material']['旧正式索引'],
                           '同梱数': len(plan['archived']), '旧ZIP全複写': False, '全entrySHA/CRC/安全名/集合': True})
    raw_tar = TRIAL / '検査/Raw当場結果.tar.gz'
    raw_rows = pack_raw(raw_tar, plan['raw'])
    write_json(TRIAL / '検査/Raw当場結果の索引.json', {'試行': 116, '成功': True, 'archive': K.reference(raw_tar), '結果': raw_rows, 'Raw本文複写': False})
    write_json(TRIAL / '成果物_金融/保管方式と復元先.json', {'試行': 116, '成功': True, 'format': 'zstd_of_exact_json_bytes',
               '索引': 'Native可逆圧縮索引.json', '同階層の保存先': 'Native_zstd', '元gzipは正式に存在するか': False,
               '復元': '保存コード索引からGo1.24.2再圧縮exeを復元し、保管する.py --restore-index 正式索引 --sha256 索引SHA --session 場 --restore-out 未作成work先 --restorer 保存exe。元gzipのSHAとsizeまで照合する。',
               '金融再生': False, '元gzip削除': False})
    write_json(TRIAL / '再現資料/CSV所在と確認.json', {'試行': 116, '成功': True, 'CSV': plan['request']['csv_refs'],
               'Root再読': plan['request']['refs']['csv_check'], '唯一正本': 'outputs', 'CSV本文複写': False,
               'CSV内Rawstatus': '元保存点検算の範囲を保持。別のRaw全70成功とは区別'})
    with (TRIAL / '再現資料/再現手順.md').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(PROCEDURE)
    after = {p: sha(Path(p)) for p in plan['before']}
    need(after == plan['before'], '全入力/既正式/code/CSV前後不変')
    proof = TRIAL / '検査/正式保存の確認.json'
    write_json(proof, {'試行': 116, '成功': True, 'Root要求': request_ref, '同bytes成果物': copied,
               'ZIP': K.reference(archive), 'コード所在索引': K.reference(code_index), '会計数': 2520, 'Viewer資源': 2520,
               'Nativeの保存形式': '可逆zstd70、gzip複写0', 'Raw当場監査': K.reference(raw_tar),
               '金融元54認証再用': 54, '金融追加16再生': 16, '独立元54継承': 54, '独立追加16新検算': 16,
               '全70金融Native再検算': False, 'Rawライフ監査': '監視適格実XC/XQの実取得〜最終返済和集合。X0/不適格/新規fill/P100全床は対象外',
               '入力SHA256前': plan['before'], '入力SHA256後': after, '前後不変': True,
               'Raw/価格CSV/損益CSV/旧Native/旧ZIP全複写': False, '金融再実行': False, '研究目標達成': False, '採用': False})
    return {'成功': True, '確認': K.reference(proof), '索引': K.reference(code_index), 'ZIP': K.reference(archive)}


PROCEDURE = """# 116の保存範囲と再現

元Source111＋入口115 A0/T/TR＋P113のP100を共通にし、life X0/XC/XQを本名で36条件比較する。X0はS0原手法ではない。金融1855閉包と実exeはコード所在索引の現在restore先へ復元する。同bytes別pathでも現在の復元先を保持し、Go1.24.2環境・Node/artifact環境・旧111〜115 ZIPは参照だけにする。

金融CLIは復元した116連続比較.exe --fixed 絶対F1 --fixed-sha F1_SHA --stage metadata-only|first2|base54|full70 --out 新規先。full70のみ --prior54 同F1元54完了 --prior54-sha SHAを付ける。先頭54は成功Native参照再用、追加16のみ再生。独立会計も元54成功を認証継承し、追加16だけ新検算した。全70の新規Native意味再検算とは呼ばない。

金融Native70は成果物_金融/Native可逆圧縮索引.jsonと同階層のNative_zstdだけを保管する。保存exeと保管する.pyの復元CLIから未作成work先へ元gzipを同SHA/sizeで復元できる。正式にNative.json.gzがあると見せる一覧は作らない。可逆処理のJSON/gzip全bytes照合はRoot実行のbytes証拠を保持し、ここで金融計算し直さない。

Viewerの2520実tradesは正式の成果物へ置き、生成した一覧は正式内を相対参照する。旧54をworkから参照し続けない。市場価格は共用入力への参照で、本文を複写しない。元独立catalogは検査へ同bytes保存し、閲覧用catalogとは区別する。

Rawライフ監査70場の当場JSONはtar.gzと元bytes索引へ束ねる。対象は監視適格実XC/XQの取得〜最終返済和集合、X0/不適格/新規fill最初性/P100全床は範囲外。価格足/DMIは別の既正式115証拠へ参照し、Rawから指標全文を再形成したとはしない。CSV2点はoutputs唯一正本で、元保存結果のRaw未結合statusを変更せず別監査成功へ結ぶ。

追加のRoot helperは、新たなRoot固定追補要求と別の追補ZIP/所在索引で保存する。今回のZIP・停止・正式保存証拠を上書きしない。分類器の旧索引リストへこの116索引を明示し、classify_rowsと旧所在認証を再用すれば、既同梱コードを再複写せず後段コードだけを追加できる。

保存成功はViewer HTTP/描画・採用・未見安定性の証明ではない。11/09は未読、研究目標達成と採用はfalse。
"""


def main() -> None:
    """機能: 全段階成功後のRoot新要求だけから正式保存する。

    引数: CLI request/request-sha(str)、metadata-only(bool)は固定要求と準備指定。
    返り値: None。未許可templateは最初のgateで拒否する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--request-sha', required=True)
    parser.add_argument('--metadata-only', action='store_true')
    args = parser.parse_args()
    value = {'path': str(args.request.resolve()), 'sha256': args.request_sha}
    if args.metadata_only:
        plan = prepare(value)
        result = {'成功': True, 'metadata_only': True, '正式書込み': False, 'コピー計画数': len(plan['plans']), '新同梱数': len(plan['archived'])}
    else:
        result = execute(value)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
