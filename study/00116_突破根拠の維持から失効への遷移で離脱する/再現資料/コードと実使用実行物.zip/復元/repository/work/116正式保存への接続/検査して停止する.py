"""116正式保存器の人工とコード前後不変だけを検査する。"""

import argparse
import json
from pathlib import Path
import re
import subprocess
import sys

import 正式保存する as F


def check(output: Path, stopped: bool = False, reviewed: bool = False) -> dict:
    """機能: 市場未読の人工を実行し、別名の停止前証拠又は正式停止を作る。

    引数: output(Path)、stopped/reviewed(bool)は未作成先とRootレビュー指定。
    返り値: dictは新規証拠Ref。自然市場/Raw/CSVは読まない。
    """
    F.need(sys.flags.optimize == 0 and output.is_absolute() and not output.exists(), '未作成の通常Python検査先')
    F.need(not stopped or reviewed, '正式停止はRootレビュー後だけ')
    before = {str(F.OWN / name): F.sha(F.OWN / name) for name in F.OWN_NAMES}
    dependencies = {str(F.OLD): F.OLD_SHA, str(F.K.OLD_PATH): F.K.OLD_SHA,
                    str(F.F.PREVIOUS_PATH): F.F.PREVIOUS_SHA, str(F.C.LEGACY_PATH): F.C.LEGACY_SHA,
                    str(F.C.ZIP_PATH): F.C.ZIP_SHA}
    F.need(all(F.sha(Path(p)) == digest for p, digest in dependencies.items()), '旧再用コードの現物SHA')
    output.mkdir(parents=True, exist_ok=False)
    sources_ref = F.K.reference(F.OWN / '保存コードの依存参照.json')
    condition_ref = {'path': str(F.ROOT / 'work/116進行/F1_116金融条件.json'), 'sha256': F.K.F1_SHA}
    material = F.K.build_plan(condition_ref, sources_ref)
    F.write_json(output / 'コード分類素材.json', material)
    dependencies.update({p: digest for p, digest in material['前SHA256'].items() if p not in before})
    command = [sys.executable, '-X', 'utf8', str(F.OWN / '人工検査.py')]
    run = subprocess.run(command, cwd=F.OWN, capture_output=True, encoding='utf-8', timeout=120, check=False)
    log = run.stdout + run.stderr
    (output / '人工検査.txt').write_text(log, encoding='utf-8')
    match = re.search(r'^Ran ([0-9]+) tests? in ', log, re.MULTILINE)
    F.need(run.returncode == 0 and match is not None and int(match[1]) >= 10 and log.rstrip().endswith('OK'), '116正式保存の主人工成功')
    after = {p: F.sha(Path(p)) for p in before}
    F.need(before == after and all(F.sha(Path(p)) == d for p, d in dependencies.items()), '新所有/旧再用の前後不変')
    data = {'試行': 116, '成功': True, '停止': stopped, '市場前': True, 'Rootレビュー後': reviewed,
            '所有ファイルSHA256': before, '再用コードSHA256': dependencies, '前SHA256': before, '後SHA256': after,
            '前後不変': True, '主人工': int(match[1]), 'ログ': F.K.reference(output / '人工検査.txt'),
            'コード分類素材': F.K.reference(output / 'コード分類素材.json'), '停止Ref一覧': sources_ref,
            '金融/Raw再実行': False, '自然Native/Raw/CSV/11月09本文読取': False,
            '正式書込み': False, '研究目標達成': False, '採用': False}
    path = output / ('停止.json' if stopped else '停止前の確認.json')
    F.write_json(path, data)
    return {'成功': True, '停止': stopped, 'ref': F.K.reference(path)}


def main() -> None:
    """機能: 人工だけの確認をCLIから実行する。

    引数: CLI output(str)、reviewed/stop(bool)は新規先とRoot確認。
    返り値: None。小Refのみ標準出力へ出す。
    """
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', required=True, type=Path)
    p.add_argument('--reviewed', action='store_true')
    p.add_argument('--stop', action='store_true')
    a = p.parse_args()
    print(json.dumps(check(a.output.resolve(), a.stop, a.reviewed), ensure_ascii=False))


if __name__ == '__main__':
    main()
