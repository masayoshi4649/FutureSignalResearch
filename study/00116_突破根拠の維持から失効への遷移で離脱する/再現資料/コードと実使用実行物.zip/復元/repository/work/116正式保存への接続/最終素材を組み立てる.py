"""116の未許可正式要求に実成功Refを結び、元JSONを純bytesで薄く保存する。"""

from __future__ import annotations

import gzip
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def digest(path: Path) -> str:
    """機能: 明示した入力の全bytes指紋を取得する。

    引数: path(Path)は許可されたコード・metadata、又はSHAだけを照合するCSV。
    返り値: strはSHA256。CSV内容の解析はしない。
    """
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def ref(path: Path, expected: str | None = None) -> dict:
    """機能: 現物SHAを照合して絶対FileRefを返す。

    引数: path(Path)、expected(str|None)は明示対象と既知SHA。
    返り値: dictはpath/sha256。
    """
    value = digest(path)
    if expected is not None and value != expected:
        raise ValueError('現物SHA差: ' + str(path))
    return {'path': str(path.resolve()), 'sha256': value}


def load(path: Path, expected: str | None = None) -> dict:
    """機能: 明示された小metadataだけを認証して読む。

    引数: path(Path)、expected(str|None)は小JSONとSHA。
    返り値: dictは参照情報。金融結果本体へは使わない。
    """
    if path.name == '結果.json' or path.suffix != '.json' or '.Native.' in path.name:
        raise ValueError('結果本文/Nativeはmetadata解析対象外')
    ref(path, expected)
    return json.loads(path.read_text(encoding='utf-8'))


def save(path: Path, value: dict) -> dict:
    """機能: 日本語UTF-8 JSONを新規先へ保存する。

    引数: path(Path)、value(dict)は未作成先とmetadata。
    返り値: dictは保存Ref。上書きはしない。
    """
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write('\n')
    return ref(path)


def compress_json(path: Path, expected: str, identifier: str, target: Path) -> dict:
    """機能: 許可された元JSONを意味解析せずgzipへ束ねる。

    引数: path/target(Path)、expected/identifier(str)は元ファイル・保存先・SHA・ID。
    返り値: dictは元Ref/SHA/bytesと保存gzipの復元情報。
    """
    body = path.read_bytes()
    if hashlib.sha256(body).hexdigest() != expected:
        raise ValueError('圧縮前の元JSON SHA差')
    with target.open('xb') as f:
        with gzip.GzipFile(filename='', fileobj=f, mode='wb', mtime=0) as g:
            g.write(body)
    stored = target.read_bytes()
    decoded = gzip.decompress(stored)
    if decoded != body or hashlib.sha256(decoded).hexdigest() != expected:
        raise ValueError('元JSONの全bytes復元差')
    return {'id': identifier, 'original': {'path': str(path.resolve()), 'sha256': expected, 'bytes': len(body)},
            'stored': {**ref(target), 'bytes': len(stored)}, 'stored_relative': target.name,
            '元JSON全bytes復元一致': True, 'JSON意味解析': False}


def main() -> None:
    """機能: 凍結6所有を変えず、Root用の未許可最終素材と欠落チェックを保存する。

    引数: なし。明示した固定成功metadataと純bytes圧縮入力だけを使う。
    返り値: None。新しい素材・確認の小Refを表示する。
    """
    original_template = HERE / 'Root正式要求_未許可.json'
    old_proof = load(HERE / '停止前検査_全依存とReader要求/停止前の確認.json', '34e6a8ee6189d62cfd0ae71be3a7e4484280f924b30ab51619b3b68e3516e786')
    owners = old_proof['所有ファイルSHA256']
    if any(digest(Path(path)) != sha for path, sha in owners.items()):
        raise ValueError('停止前6所有を改変しない')
    request = load(original_template, '62ee6cb0bc2120aa6e6b9db9e67c57fd2021f299f42a594611770ff056a16fd8')
    refs = request['refs']
    previous_material = dict(refs['code_material'])
    refs['formal_stop'] = ref(HERE / 'Root承認後の停止/停止.json', '4ec0e55f59aded77672f57d637b2846e0091436cfa942f8e9df685afc69e3395')
    formal_stop = load(Path(refs['formal_stop']['path']), refs['formal_stop']['sha256'])
    if formal_stop['停止'] is not True or formal_stop['成功'] is not True or formal_stop['所有ファイルSHA256'] != owners:
        raise ValueError('Root承認後停止は同じ6所有')
    refs['code_material'] = ref(Path(formal_stop['コード分類素材']['path']), formal_stop['コード分類素材']['sha256'])
    refs['raw_request'] = ref(ROOT / 'work/116進行/full70_原行監査のRoot要求.json', '72bfae81931c6d931f7f43edf1dad9503936eb9046a7b270e27344e259f6e6bd')
    refs['raw_check'] = ref(ROOT / 'work/116原行監査F1/全70場/全70原行監査の確認.json', '841ad3512f5589b94ab58c4930df642aa2e454fe14892c627796c35456d57276')
    raw_request = load(Path(refs['raw_request']['path']), refs['raw_request']['sha256'])
    raw_check = load(Path(refs['raw_check']['path']), refs['raw_check']['sha256'])
    pool_path = ROOT / 'work/116進行/全70原行監査を実行する.py'
    if raw_check['前SHA256'] != raw_check['後SHA256'] or raw_check['前SHA256'].get(str(pool_path)) != digest(pool_path):
        raise ValueError('Root pool helperは全70成功の前後mapと同体')
    outer = load(ROOT / 'work/116進行/full70_元54独立再用のRoot要求_金額型復元.json')
    if outer['base54']['result']['sha256'] != 'f5e3c4777dee3ef08030ef5f60f79edd5426699ffdfe02214fc3fc01735de501':
        raise ValueError('再用54結果Refの取り違え')
    if outer['base54']['check'] != refs['base54_check']:
        raise ValueError('元54 checkは自動保存と同一')
    automatic = {str(Path(v['path']).resolve()).casefold() for v in refs.values()}
    automatic.update(str(Path(raw_request[n]['path']).resolve()).casefold() for n in ('reader_request', 'save_request'))
    automatic_ref = {str(Path(v['path']).resolve()): v for v in refs.values()}
    automatic_ref.update({raw_request[n]['path']: raw_request[n] for n in ('reader_request', 'save_request')})
    extras, codes, skipped = [], [], []
    source_set, target_set, code_set = set(), set(), set()

    def extra(path: Path, target: str, role: str, expected: str | None = None) -> None:
        """機能: 自動保存分と重複しない明示extraを追加する。

        引数: path(Path)、target/role(str)、expected(str|None)。
        返り値: None。同sourceや同targetの二重追加は拒否。
        """
        key = str(path.resolve()).casefold()
        if key in automatic:
            skipped.append({'path': str(path.resolve()), '理由': '正式器の自動保存対象'})
            return
        if key in source_set or target.casefold() in target_set:
            raise ValueError('extraの二重入力又は二重先')
        extras.append({'ref': ref(path, expected), 'target': target, 'role': role})
        source_set.add(key)
        target_set.add(target.casefold())

    def code(path: Path, role: str, expected: str | None = None) -> None:
        """機能: 実使用の追加コードを同pathで一度だけ分類へ結ぶ。

        引数: path(Path)、role(str)、expected(str|None)。
        返り値: None。extra同bytes保存先があるコードはZIP二重同梱をしない設計。
        """
        key = str(path.resolve()).casefold()
        if key in code_set:
            return
        codes.append({'ref': ref(path, expected), 'role': role})
        code_set.add(key)

    # ----------------------------------------
    # Root実使用の準備/派生/固定/段階実行コード。金融ランナー1855の外として役割を明示する。
    for name in ('Coreの原文を準備する.py', 'Coreの固定人工を派生する.py', 'Coreの人工を派生する.py',
                 'Coreの接続を派生する.py', 'Core人工の参照を作る.py', 'Core停止器を準備する.py',
                 '金融条件を固定する.py', '研究資料を準備する.py', '独立保存要求を固定する.py',
                 '独立保存要求を固定する_未読件数補正.py', '診断資料を保存する.py', '全70原行監査を実行する.py'):
        code(ROOT / 'work/116進行' / name, 'Root実使用の116準備/派生/条件固定/段階要求/監査実行。金融1855閉包の外側')
    document_helper = ROOT / 'work/116進行/文書をまとめる.py'
    if document_helper.is_file():
        code(document_helper, 'Root後段のREADME/state/設定表更新専用。CSVや金融を生成しない。実行履歴は後段検査へ')
    diagnostic = ROOT / 'work/116実退出の違いを当時の技法で調べる'
    code(diagnostic / '調べる.py', '許可2Nativeからの記述診断の再現code。正式診断の同bytes成果物からも復元する',
         '42a433de552000a2a12858081470e5d97cbc63087e9d663193b82ad290001d26')
    code(diagnostic / '人工検査.py', '2例診断の照合関数の人工検査。自然再生は行わない')
    code(Path(__file__).resolve(), '未許可最終素材と純bytes metadata圧縮の組立を再現するコード')
    code(HERE / '大きいmetadataを復元する.py', '元54結果等のgzipから元JSONのSHA/sizeまで復元。金融意味解析なし')

    # ----------------------------------------
    # 同じ入力を自動保存とextraの両方へ置かない。
    progress = ROOT / 'work/116進行'
    small = [
        ('F1固定の確認.json', '検査/段階/F1固定の確認.json'),
        ('F1固定と先頭2開始の確認.json', '検査/段階/F1固定と先頭2開始の確認.json'),
        ('元54成功と全70開始の確認.json', '検査/段階/元54成功と全70開始の確認.json'),
        ('先頭2成功と独立metadata型差の記録.json', '検査/段階/独立metadataの型差と継承.json'),
        ('first2_独立保存要求_未読件数補正.json', '再現資料/段階要求/先頭2独立保存.json'),
        ('base54_独立保存要求_未読件数補正.json', '再現資料/段階要求/元54独立保存.json'),
        ('full70_独立保存要求_未読件数補正.json', '再現資料/段階要求/全70独立保存.json'),
        ('full70_元54独立再用のRoot要求_金額型復元.json', '再現資料/段階要求/元54継承と追加16の実Root要求.json'),
        ('first2_原板要求作成のRoot要求.json', '再現資料/段階要求/先頭2Reader要求の準備.json'),
        ('first2_ReaderのRoot要求.json', '再現資料/段階要求/先頭2Reader.json'),
        ('first2_原行監査のRoot要求.json', '再現資料/段階要求/先頭2原行監査.json'),
        ('full70_原板要求作成のRoot要求.json', '再現資料/段階要求/全70Reader要求の準備.json'),
        ('full70_ReaderのRoot要求.json', '再現資料/段階要求/全70Reader.json'),
        ('全70CSVのRoot要求.json', '再現資料/段階要求/CSV二点の実要求.json'),
        ('全70CSVの独立再読.json', '検査/CSVの独立再読.json'),
        ('全70設定表結合のRoot要求.json', '再現資料/段階要求/設定表結果結合.json')]
    for name, target in small:
        extra(progress / name, target, '当時の段階記録又は実使用Root要求。現在の完了状態へ書き換えない')
    extra(original_template, '再現資料/正式器の未許可原素材.json', '最終素材組立helperがSHA62eeで認証する原入力。金融正式要求とは区別')
    csv_check = load(Path(refs['csv_check']['path']), refs['csv_check']['sha256'])
    for value in request['csv_refs'].values():
        ref(Path(value['path']), value['sha256'])
    for path, digest_value in csv_check['入力SHA256'].items():
        if Path(path).name == 'CSVの確認.json':
            extra(Path(path), '検査/CSV出力の確認.json', 'Root CSV二点生成の確認。CSV本文はoutputs唯一正本', digest_value)
    extra(ROOT / 'work/116設定表の結果結合準備/全70結果版/結合の確認.json', '検査/設定表の結合確認.json', '56×9/S28/R36の結果結合確認')
    extra(ROOT / 'work/116設定表の結果結合準備/入力表.md', '再現資料/設定表の固定入力.md', 'binderがsource_tableへ要求する元path/baad89の同bytes入力',
          'baad89d6cec9164e5f76c206e00b392222e97caf5879b0b852a1eca00684a9cd')
    extra(diagnostic / '2例の実退出と当時の根拠.md', '診断/2例の実退出と当時の根拠.md', '9/30と10/26の同入口記述。新閾値や退出後仮想利益は作らない')
    extra(diagnostic / '同入口の要点.json', '診断/同入口の要点.json', '2例の当時値をまとめた小要点。ここでは内容を再解析しない')
    extra(diagnostic / '当時値の詳細.json.gz', '診断/当時値の詳細.json.gz', '2例診断の圧縮詳細を同bytes保存。再解析しない')
    extra(diagnostic / '調べる.py', '診断/調べる.py', '診断MDの相対リンク先。code_refsと一つの正式同bytes成果物を共有',
          '42a433de552000a2a12858081470e5d97cbc63087e9d663193b82ad290001d26')

    # ----------------------------------------
    # 大きめの段階metadataだけを可逆圧縮。元54checkは自動保存なので重複しない。
    packed_dir = HERE / '大きいmetadataの保管'
    packed_dir.mkdir(exist_ok=False)
    inputs = [
        (Path(outer['base54']['result']['path']), outer['base54']['result']['sha256'], '元54独立結果'),
        (ROOT / 'work/116金融F1/元54場/完了.json', 'f41b76f8cc187e7dbd59ba7324ad2b23168de96b1d81378a37861b932be57147', '元54金融完了'),
        (ROOT / 'work/116金融F1/先頭2場/完了.json', '4d221b6c3a84f403c027baf6d25cd7eceb307218c48e82c334341f7cf982d52b', '先頭2金融完了'),
        (ROOT / 'work/116独立保存F1/先頭2場/保存会計の確認.json', '8e0ec039f9d7bf940a7c17a5c6b429309acf2ec2b864548d694d8d58ea04a594', '先頭2独立保存確認'),
        (HERE / '停止前検査_全依存とReader要求/停止前の確認.json', '34e6a8ee6189d62cfd0ae71be3a7e4484280f924b30ab51619b3b68e3516e786', '正式器のRootレビュー前確認')]
    packed = []
    for source, expected, identifier in inputs:
        target = packed_dir / (identifier + '.json.gz')
        packed.append(compress_json(source, expected, identifier, target))
        extra(target, '再現資料/段階metadata/' + target.name, '元JSONの純bytes gzip。元Ref/SHA/sizeは同階層復元索引に保存')
    restore_index = save(packed_dir / '大きいmetadataの復元.json', {'試行': 116, '成功': True, '項目': packed,
                         '金融JSON意味解析': False, '原JSONの実復元先': 'original.pathを保持。元要求の絶対pathへ隔離環境で復元し、既存ファイルは上書きしない。',
                         '復元helper': ref(HERE / '大きいmetadataを復元する.py'),
                         '復元CLI': 'python -X utf8 大きいmetadataを復元する.py --index 絶対索引 --sha256 索引SHA --item 項目ID --output 未作成work先'})
    extra(Path(restore_index['path']), '再現資料/段階metadata/大きいmetadataの復元.json', '圧縮JSONの元Ref/SHA/bytesと全bytes復元証拠')
    extra(HERE / '大きいmetadataを復元する.py', '再現資料/段階metadata/大きいmetadataを復元する.py', '復元索引と同階層のCLI。code_refsからも同成果物へ結ぶ')
    request.update(code_refs=codes, extra_refs=extras)
    request['Rootが全成功後に置換するもの'] = ['formal_stop/code_materialは実承認後停止へ結合済み。', '正式許可4flagはRootだけが新要求で変更する。', '後段文書helperが変わった場合は新固定要求でcode_refsの現物SHAを更新する。']
    request['追加資料の扱い'] = '元54result等は純bytes gzipから元JSON_SHAまで復元する。元54checkは自動保存。診断コードは同bytes正式成果物をcode索引が参照する。'
    final_ref = save(HERE / '正式要求の最終素材.json', request)
    if any(request[k] is not False for k in ('fixed', 'formal_write_authorized', 'market_native_read_authorized', 'raw_audit_read_authorized')):
        raise ValueError('未許可flagを維持する')
    if any(digest(Path(path)) != sha for path, sha in owners.items()):
        raise ValueError('凍結6所有の前後差')
    report = {'試行': 116, '成功': True, '正式要求の最終素材': final_ref, '未許可flag4個': True,
              'formal_stopは実Root停止へ結合': refs['formal_stop'], '旧分類素材5d7を保持': previous_material, '6所有前後不変': True,
              '追加code数': len(codes), '追加extra数': len(extras), '自動保存と重複させず除外': skipped,
              'extraの同source/target重複': False, '診断codeの同成果物参照': True,
              '自動保存Ref': automatic_ref, '圧縮復元metadata': restore_index,
              '元54再用の再現依存': {'request': outer['base54']['request'], 'result': outer['base54']['result'],
                                  'check': refs['base54_check'], 'resultの保存': 'gzip＋元JSON_SHA/bytes', 'checkの保存': '自動検査/base54_check.json'},
              '元JSON合計bytes': sum(r['original']['bytes'] for r in packed), 'gzip合計bytes': sum(r['stored']['bytes'] for r in packed),
              '圧縮JSON数': len(packed), '全JSONの全bytes復元一致': True, '元54結果のJSON意味解析': 0, '金融値の再計算': 0,
              '新Raw/Native/価格CSV本文読取': 0, 'CSV解析': 0, 'CSVはSHA現物認証だけ': 2,
              '正式書込み': False, '欠落': [], '許可待ち': ['4flagはfalse。Rootだけが新規要求で正式許可する。'],
              'この素材を組み立てたcode': ref(Path(__file__).resolve()), '採用': False, '研究目標達成': False}
    proof = save(HERE / '最終素材と再現依存の確認.json', report)
    print(json.dumps({'成功': True, '素材': final_ref, '確認': proof, '圧縮復元metadata': restore_index}, ensure_ascii=False))


if __name__ == '__main__':
    main()
