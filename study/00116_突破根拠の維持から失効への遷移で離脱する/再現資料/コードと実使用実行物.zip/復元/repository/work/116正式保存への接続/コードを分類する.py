"""116の停止済みコードだけを既正式参照・環境参照・新規同梱へ分類する。"""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import importlib.util
import json
from pathlib import Path


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
F1_SHA = '4c76a5f7cd8a59962e885cadf6885cfc75cbc590675955cb8e72ae2d0b8bb372'
OLD_PATH = ROOT / 'work/115正式保存への接続/コードを分類する.py'
OLD_SHA = '72be0030a493d5c3e287ecb9eed80531106ff277a2574013c5df23c0590c90e8'
INDEX115 = {'path': str(ROOT / 'study/00115_三時間軸の方向性と局所構造で入口を分ける/再現資料/コード所在索引.json'),
            'sha256': '390aaa5eb01cb87b30dbc1203e9df3fe17cc5b6359a268ba19add46894bc27d5'}
CODE_FIELDS = ('所有コードSHA256', '所有ファイルSHA256', '依存コードSHA256', '再用コードSHA256', '再用ファイルSHA256',
               '全固定コードSHA256', '実Go依存SHA256')


def need(ok: bool, message: str) -> None:
    """機能: 条件不成立を通常実行でも必ず拒否する。

    引数: ok(bool)、message(str)は条件と説明。
    返り値: None。不成立ならValueError。
    """
    if not ok:
        raise ValueError(message)


def sha(path: Path) -> str:
    """機能: 明示したコード又は小metadataの全bytes指紋を返す。

    引数: path(Path)は読取を許可されたファイル。
    返り値: strはSHA256。市場本文へ自動的に進まない。
    """
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def reference(path: Path) -> dict:
    """機能: 現物コードの絶対FileRefを作る。

    引数: path(Path)はコード又は小metadata。
    返り値: dictはpath/sha256。
    """
    return {'path': str(path.resolve()), 'sha256': sha(path)}


def read(value: dict, before: dict | None = None) -> dict:
    """機能: SHA認証したJSON metadataを読む。

    引数: value(dict)は絶対FileRef、before(dict|None)は入力指紋。
    返り値: dictはJSON。圧縮NativeやCSVはこの口では受けない。
    """
    need(isinstance(value, dict) and {'path', 'sha256'} <= set(value) <= {'path', 'sha256', 'bytes'}, 'FileRefの型')
    p = Path(value['path'])
    need(p.is_absolute() and p.suffix == '.json' and '.Native.' not in p.name, '小JSON metadataだけ')
    need(isinstance(value['sha256'], str) and len(value['sha256']) == 64, 'SHA256の型')
    if 'bytes' in value:
        need(type(value['bytes']) is int and value['bytes'] >= 0 and p.stat().st_size == value['bytes'], 'FileRef bytes')
    need(sha(p) == value['sha256'], '現物metadataのSHA: ' + str(p))
    if before is not None:
        key = str(p.resolve())
        need(key not in before or before[key] == value['sha256'], '同pathの指紋衝突')
        before[key] = value['sha256']
    return json.loads(p.read_text(encoding='utf-8-sig'))


need(sha(OLD_PATH) == OLD_SHA, '旧115分類器の不変')
SPEC = importlib.util.spec_from_file_location('116が使う停止115分類器', OLD_PATH)
K = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(K)


def add_code(code: dict, path: str, digest: str) -> None:
    """機能: 明示コードを同path同SHAで統合する。

    引数: code(dict)、path/digest(str)は集合と停止した実コード。
    返り値: None。金融本文・Raw・価格CSVを分類へ混入させない。
    """
    p = Path(path)
    if not p.is_absolute():
        p = ROOT / p
    p = p.resolve()
    need(p.suffix.lower() not in ('.csv', '.gz', '.zst', '.zip', '.jsonl') and '.Native.' not in p.name, 'コードと小metadataだけ: ' + str(p))
    key = str(p)
    need(key not in code or code[key] == digest, '同pathコードSHA衝突: ' + key)
    need(sha(p) == digest, '停止コードの現物SHA: ' + key)
    code[key] = digest


def classify_rows(code: dict, core: dict, indexes: list) -> tuple[list, dict, dict]:
    """機能: 旧索引参照を平坦化し、元の復元先を保持する。

    引数: code/core(dict)、indexes(list[(dict,dict)])は現物・Core停止・旧索引。
    返り値: tuple[list,dict,dict]は全所在・復元根・Go環境。
    """
    roots = indexes[-1][0]['restore_roots']
    environment = indexes[-1][0]['go_environment']
    goroot = K.environment_goroot(code, core.get('GoRootコードSHA256', {}), environment)
    rows = K.classify(code, goroot, indexes)
    for row in rows:
        if row['kind'] in ('GoRoot環境参照', 'Goコンパイラ環境参照'):
            continue
        row['restore'] = K.restore_target(row['original_path'], roots)
        if row['location']['kind'] == '新規ZIP予定':
            row['location']['entry'] = '復元/' + row['restore']['root'] + '/' + row['restore']['relative']
    return rows, roots, environment


def build_plan(condition_ref: dict, sources_ref: dict, extra: list | None = None) -> dict:
    """機能: 116金融1855閉包と後段停止コードを正式化の素材へまとめる。

    引数: condition_ref/sources_ref(dict)は固定F1と停止Ref一覧、extra(list|None)は後段の明示コード。
    返り値: dictは分類素材。市場本文・旧ZIP本文は読まず正式書込みもしない。
    """
    before = {}
    need(condition_ref['sha256'] == F1_SHA, '金融116F1の固定指紋')
    fixed, sources = read(condition_ref, before), read(sources_ref, before)
    need(fixed['trial'] == 116 and fixed['fixed'] is True and len(fixed['actual_configurations']) == 36, '116金融F1本名36条件')
    core = read(fixed['runtime_stop'], before)
    expected = {**core['全固定コードSHA256'], fixed['runtime_stop']['path']: fixed['runtime_stop']['sha256']}
    need(expected == fixed['code_sha256'] and len(expected) == 1855, 'Core停止と金融1855閉包の全値')
    code = {}
    for path, digest in expected.items():
        add_code(code, path, digest)
    add_code(code, fixed['executable']['path'], fixed['executable']['sha256'])
    financial = dict(code)
    dependencies = {**fixed['dependency_stops'], 'core': fixed['runtime_stop'], **sources['stops']}
    for name, value in dependencies.items():
        stopped = read(value, before)
        need(stopped.get('成功') is True, '依存停止成功: ' + name)
        add_code(code, value['path'], value['sha256'])
        for field in CODE_FIELDS:
            for path, digest in stopped.get(field, {}).items():
                add_code(code, path, digest)
        for field in ('操作marker', '実Go復元物', 'Gosource', '実行物'):
            if field in stopped:
                add_code(code, stopped[field]['path'], stopped[field]['sha256'])
    for name in ('actual_declaration', 'pure_declaration', 'entry_gate_declaration', 'chart_declaration', 'entry_chart_declaration', 'lifecycle_declaration'):
        add_code(code, fixed[name]['path'], fixed[name]['sha256'])
    for row in sources.get('code_refs', []) + (extra or []):
        need(set(row) == {'ref', 'role'} and isinstance(row['role'], str) and bool(row['role']), '明示コードの役割')
        add_code(code, row['ref']['path'], row['ref']['sha256'])
    add_code(code, str(OLD_PATH), OLD_SHA)
    for p in OWN.iterdir():
        if p.is_file() and p.name in sources['own_files']:
            add_code(code, str(p), sha(p))
    refs = list(K.PRIOR_INDEXES) + [INDEX115]
    indexes = [(read(value, before), value) for value in refs]
    need(all(x['成功'] is True for x, _ in indexes), '111〜115の既正式索引成功')
    rows, roots, env = classify_rows(code, core, indexes)
    before.update(code)
    after = {p: sha(Path(p)) for p in before}
    need(before == after, '分類の全入力・コード前後不変')
    return {'試行': 116, '成功': True, '正式保存ではなく準備': True, 'Root金融条件': condition_ref,
            '停止': fixed['runtime_stop'], '実行物': fixed['executable'], '金融コード数': 1855, '金融と実行物SHA256': financial,
            '依存Ref一覧': sources_ref, '停止Ref': dependencies, '旧正式索引': refs,
            'restore_roots': roots, 'go_environment': env, 'entries': rows, '件数': dict(Counter(r['kind'] for r in rows)),
            '前SHA256': before, '後SHA256': after, '前後不変': True,
            'Nodeとartifact環境': sources['node_artifact_environment'], '生成testmainの保存': False,
            '旧ZIP本文読取': False, '金融Native/Raw/CSV本文読取': False, '正式書込み': False,
            '追加helperは後継要求の明示code_refsへ': True, '研究目標達成': False, '採用': False}


def main() -> None:
    """機能: コード分類の小入力だけから未作成先へ素材を保存する。

    引数: CLI fixed/sha256/sources/sources-sha/output(str)は固定Refと新規先。
    返り値: None。小さな出力Refを表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ('fixed', 'sha256', 'sources', 'sources-sha', 'output'):
        parser.add_argument('--' + key, required=True)
    args = parser.parse_args()
    output = Path(args.output).resolve()
    need(not output.exists(), '分類素材は未作成先だけ')
    value = build_plan({'path': str(Path(args.fixed).resolve()), 'sha256': args.sha256},
                       {'path': str(Path(args.sources).resolve()), 'sha256': args.sources_sha})
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'成功': True, 'ref': reference(output), '件数': value['件数']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
