"""手製metadataとbytesだけで116正式保存の境界を検査する。"""

from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest

import 正式保存する as F


def ref(path: Path, digest: str = 'a' * 64) -> dict:
    """機能: 存在しない対象も含む手製FileRefを作る。

    引数: path(Path)、digest(str)は人工の位置と指紋。
    返り値: dictはRef。自然ファイルを開かない。
    """
    return {'path': str(path.resolve()), 'sha256': digest}


def fixture(folder: Path) -> tuple:
    """機能: 金額を含めず36×70と54継承＋16の成功metadataを作る。

    引数: folder(Path)は手製器具の根。
    返り値: tupleはvalues/request。実Nativeは存在しない。
    """
    names = ('condition', 'market', 'result', 'saved_check', 'base54_check', 'reuse_stop', 'save_stop', 'P_stop', 'life_stop', 'raw_request')
    refs = {n: ref(folder / (n + '.json'), format(i + 1, '064x')) for i, n in enumerate(names)}
    conditions = {'trial': 116, 'fixed': True, 'actual_configurations': list(F.CONFIGS),
                  'protection_definition': {'version': 113, 'policy': 'P100'}, 'entry_gate_definition': {'version': 115},
                  'lifecycle_definition': {'version': 116}, 'entry_grid_seconds': None, 'extra_opening_quiet_seconds': 0,
                  'dependency_stops': {'actor': ref(folder / 'actor.json', 'b' * 64), 'lifecycle': ref(folder / 'life.json', 'c' * 64)}}
    expected = F.C.sessions()
    market = {'trial': 116, 'success': True, 'stage': 'full70', 'sessions': 70, 'books': 2520,
              'reused_sessions': 54, 'replayed_sessions': 16, 'condition_sha256': refs['condition']['sha256'],
              'unchanged': True, 'before': {'手製code': 'd' * 64}, 'after': {'手製code': 'd' * 64},
              'reference115_comparisons': 840, 'all_reference115_equal': True, 'all_source111_equal': True,
              'all_original166_reference_events_equal': True, 'historical_saved_events_equal': False,
              'all_original_signal_full_json_equal': False,
              'results': [{'session': s, 'books': 36, 'x0_comparisons': 12, 'x0_equal': True, 'complete': True,
                           'open_quantity': 0, 'pending_quantity': 0, 'reference115_comparisons': 12,
                           'reference115_equal': True, 'source111_equal': True, 'native': ref(folder / (s + '.Native.json.gz'))} for s in expected]}
    common = {'試行': 116, '成功': True, 'stage': 'full70', '場数': 70, '会計数': 2520,
              '金融条件SHA256': refs['condition']['sha256'], '金融完了SHA256': refs['market']['sha256'],
              '前後不変': True, '入力codeSHA256前': {'手製': 'a'}, '入力codeSHA256後': {'手製': 'a'},
              '独立再用場数': 54, '独立新規検算場数': 16, '全70の金融Native再検算': False,
              '元54再用runner停止SHA256': refs['reuse_stop']['sha256'], '採用': False, '研究目標達成': False,
              '保存器停止SHA256': refs['save_stop']['sha256'], '独立P停止SHA256': refs['P_stop']['sha256'],
              '独立ライフ停止SHA256': refs['life_stop']['sha256'], 'Actor停止SHA256': 'b' * 64, '純ライフ停止SHA256': 'c' * 64}
    result = {**common, '主key': list(F.KEYS), '集計': {k: {} for k in F.KEYS},
              '場別': [{'session': s, 'key': k, '入口票検査': {'成功': True, 'counts': {'zero': 0}}} for s in expected for k in F.KEYS],
              '入口票集計': {k: {} for k in F.KEYS}, '元54再用': {'check': refs['base54_check']}}
    check = {**common, '資源': 2520, 'X0全金融比較': 840, '旧115全金融比較': 840, '全Source111同体': True,
             '全残玉予約0': True, '不一致数': 0, '出力SHA256': {'結果.json': refs['result']['sha256']}}
    base = {'試行': 116, '成功': True, 'stage': 'base54', '場数': 54, '会計数': 1944,
            '金融条件SHA256': refs['condition']['sha256'], '前後不変': True, '不一致数': 0}
    values = {'condition': conditions, 'market': market, 'result': result, 'saved_check': check, 'base54_check': base,
              'reuse_stop': {'元保存器停止': refs['save_stop']}, 'save_stop': {'P停止': refs['P_stop'], 'ライフ停止': refs['life_stop']}}
    return values, {'refs': refs}


class Artificial(unittest.TestCase):
    def setUp(self) -> None:
        """機能: workspace内の未使用人工先だけを作る。

        引数: self(Artificial)。返り値: None。
        """
        self.temp = tempfile.TemporaryDirectory(prefix='手製_', dir=F.OWN)
        self.folder = Path(self.temp.name).resolve()
        self.assertTrue(self.folder.is_relative_to(F.OWN))

    def tearDown(self) -> None:
        """機能: 検証済み人工先だけを片付ける。

        引数: self(Artificial)。返り値: None。既存停止・正式物へ触れない。
        """
        self.assertTrue(self.folder.is_relative_to(F.OWN) and self.folder != F.OWN)
        self.temp.cleanup()

    def test_unapproved_root_before_any_reference(self) -> None:
        """機能: 未許可要求を未知の金融Refを開く前に拒否する。

        引数: self(Artificial)。返り値: None。
        """
        p = self.folder / '未許可.json'
        p.write_text(json.dumps({'version': 1, 'trial': 116, 'fixed': False, 'refs': {'result': '不存在'}}), encoding='utf-8')
        with self.assertRaisesRegex(ValueError, '明示解禁'):
            F.prepare(F.K.reference(p))
        self.assertEqual(list(self.folder.iterdir()), [p])

    def test_counter_missing_zero_equal_nonzero_rejected(self) -> None:
        """機能: 2520行の零Counter省略は同値、非零欠落は不一致とする。

        引数: self(Artificial)。返り値: None。
        """
        values, request = fixture(self.folder)
        self.assertEqual(len(F.validate(values, request)), 70)
        values['result']['場別'][0]['入口票検査']['counts']['unexpected'] = 1
        with self.assertRaisesRegex(ValueError, 'Counter'):
            F.validate(values, request)

    def test_36_12_scope_and_reuse_are_not_interchangeable(self) -> None:
        """機能: 旧12/全36と54継承/16新検算の誤表示を拒否する。

        引数: self(Artificial)。返り値: None。
        """
        values, request = fixture(self.folder)
        for field in ('books', 'x0_comparisons'):
            wrong = deepcopy(values)
            wrong['market']['results'][0][field] = 4
            with self.assertRaises(ValueError):
                F.validate(wrong, request)
        wrong = deepcopy(values)
        wrong['result']['全70の金融Native再検算'] = True
        with self.assertRaises(ValueError):
            F.validate(wrong, request)

    def test_session_duplicate_and_omission_are_rejected(self) -> None:
        """機能: 全0場でも70場の順序・件数・重複を維持する。

        引数: self(Artificial)。返り値: None。
        """
        values, request = fixture(self.folder)
        values['result']['場別'][0]['session'] = values['result']['場別'][36]['session']
        with self.assertRaisesRegex(ValueError, '2520行'):
            F.validate(values, request)

    def test_native_index_exact_bytes_and_relative_layout(self) -> None:
        """機能: 実在しない元gzipを開かず70件の可逆証拠を検査する。

        引数: self(Artificial)。返り値: None。
        """
        v, q = fixture(self.folder)
        q['refs']['native_request'] = ref(self.folder / '保管要求.json')
        rows = [{'session': r['session'], 'source_original_gzip': r['native'], 'source_gzip_bytes': 50,
                 'restored_gzip_sha256': r['native']['sha256'], 'restored_gzip_bytes': 50,
                 'restored_json_all_bytes_equal': True, 'restored_gzip_all_bytes_equal': True,
                 'stored_relative': 'Native_zstd/' + r['session'] + '.Native.json.zst',
                 'stored_format': 'zstd_of_exact_json_bytes'} for r in v['market']['results']]
        index = {'trial': 116, 'success': True, 'sessions': 70, 'policy': 'native_payload_zstd3_window29_ldm_restore_go1242_v1',
                 'condition': q['refs']['condition'], 'financial_completion': q['refs']['market'], 'Root要求': q['refs']['native_request'],
                 '前後不変': True, '入力codeSHA256前': {}, '入力codeSHA256後': {},
                 'restore': {'Go_version': 'go1.24.2', 'executable': {'sha256': 'a06c854ce4bfe6db22a3329e28a571a56454dfaaf11c90af1e33efc9a4e12c9c'}}, 'Native_zstd': rows}
        self.assertEqual(len(F.validate_native(index, q, v['market'], F.C.sessions())), 70)
        index['Native_zstd'][0]['restored_gzip_all_bytes_equal'] = False
        with self.assertRaises(ValueError):
            F.validate_native(index, q, v['market'], F.C.sessions())
        index['Native_zstd'][0]['restored_gzip_all_bytes_equal'] = True
        index['Native_zstd'][0]['stored_relative'] = '../偽.Native.json.gz'
        with self.assertRaises(ValueError):
            F.validate_native(index, q, v['market'], F.C.sessions())

    def test_raw70_cannot_be_replaced_by_first2(self) -> None:
        """機能: 適格0だった先頭2を全70初回性へ拡大しない。

        引数: self(Artificial)。返り値: None。
        """
        _, q = fixture(self.folder)
        x = {'試行': 116, '成功': True, 'stage': 'full70', '場数': 70, '全Rawライフ初回性': True,
             'P100H100初回性': True, 'P100全床/全追尾幅Raw再形成': False, '前後不変': True,
             '金融条件': q['refs']['condition'], '金融完了': q['refs']['market'], '独立保存結果': q['refs']['result'],
             '独立保存確認': q['refs']['saved_check'], 'Root要求': q['refs']['raw_request'],
             '結果': [{'session': s, 'ref': ref(self.folder / (s + '.json'))} for s in F.C.sessions()]}
        self.assertEqual(len(F.validate_raw(x, q['refs'], F.C.sessions())), 70)
        x['結果'] = x['結果'][:2]
        with self.assertRaisesRegex(ValueError, '70場'):
            F.validate_raw(x, q['refs'], F.C.sessions())
        x['P100全床/全追尾幅Raw再形成'] = True
        with self.assertRaises(ValueError):
            F.validate_raw(x, q['refs'], F.C.sessions())

    def test_viewer_54_relative_and16_direct_are_formal_local(self) -> None:
        """機能: 旧1944相対参照と新576を全2520正式内の本名へ結ぶ。

        引数: self(Artificial)。返り値: None。約定や価格本文は作らない。
        """
        saved, old = self.folder / '新16', self.folder / '元54'
        catalog = {'schema_version': 1, 'path_base': 'catalog', 'resources': []}
        check = {'出力SHA256': {}, 'Viewer参照再用SHA256': {}}
        for i, s in enumerate(F.C.sessions()):
            for key in F.KEYS:
                name = f'116_{key}_{s}.trades.jsonl'
                path = ('../元54/' + name) if i < 54 else name
                row = {'session': s, 'method_id': key, 'id': name.removesuffix('.trades.jsonl'), 'pnl_path': path,
                       'pnl_format': 'trades', 'pnl_basis': 'net', 'product': 'NK225mini', 'point_value': 100,
                       'market_path': str(F.ROOT.parent / 'JP_OSE_Data' / (s + '.csv'))}
                catalog['resources'].append(row)
                if i < 54:
                    check['Viewer参照再用SHA256'][str((old / name).resolve())] = 'a' * 64
                else:
                    check['出力SHA256'][name] = 'a' * 64
        files, generated = F.viewer_plan(catalog, saved, check, F.C.sessions(), self.folder / '正式/成果物')
        self.assertEqual(len(files), 2520)
        self.assertTrue(all('/' not in r['pnl_path'] for r in generated['resources']))
        self.assertTrue(catalog['resources'][0]['pnl_path'].startswith('../元54'))
        check['Viewer参照再用SHA256'].pop(files[0]['ref']['path'])
        with self.assertRaisesRegex(ValueError, '保存SHA'):
            F.viewer_plan(catalog, saved, check, F.C.sessions(), self.folder / '正式/成果物')

    def test_duplicate_and_existing_targets_are_rejected_before_write(self) -> None:
        """機能: 二重入力・二重先・既存先を計画中に拒否する。

        引数: self(Artificial)。返り値: None。正式pathを使わない。
        """
        source = self.folder / '小metadata.json'
        source.write_text('{}\n', encoding='utf-8')
        destination = self.folder / '正式'
        before, plans, targets, sources = {}, [], set(), set()
        value = F.K.reference(source)
        F.reserve_copy(value, '検査/一つ.json', destination, before, plans, targets, sources)
        with self.assertRaisesRegex(ValueError, '二重転記'):
            F.reserve_copy(value, '検査/二つ.json', destination, before, plans, targets, sources)
        self.assertFalse(destination.exists())
        (destination / '検査').mkdir(parents=True)
        (destination / '検査/既存.json').write_text('old', encoding='utf-8')
        with self.assertRaisesRegex(ValueError, '上書き'):
            F.reserve_copy(value, '検査/既存.json', destination, {}, [], set(), set())
        with self.assertRaises(ValueError):
            F.reserve_copy(value, '../危険.json', destination, {}, [], set(), set())

    def test_same_bytes_prior_reference_keeps_current_restore(self) -> None:
        """機能: 同bytes別pathでも現復元先を過去pathへ変えない。

        引数: self(Artificial)。返り値: None。旧ZIP本文は読まない。
        """
        source = self.folder / '新しい名前.py'
        source.write_text('# 人工\n', encoding='utf-8')
        digest = F.sha(source)
        old_path = self.folder / '旧名前.py'
        archive_ref = ref(self.folder / '旧正式.zip')
        index_ref = ref(self.folder / '旧索引.json')
        roots = {'repository': str(F.ROOT)}
        index = {'restore_roots': roots, 'go_environment': {'version': 'go1.24.2', 'root': str(self.folder / '環境')},
                 'ZIP': archive_ref, 'entries': [{'original_path': str(old_path), 'sha256': digest, 'bytes': source.stat().st_size,
                                                'kind': '新規同梱予定', 'location': {'kind': 'このZIP', 'entry': '復元/旧名前.py'}}]}
        rows, _, _ = F.K.classify_rows({str(source): digest}, {'GoRootコードSHA256': {}}, [(index, index_ref)])
        self.assertEqual(rows[0]['kind'], '旧同bytes別パス参照')
        self.assertEqual(rows[0]['location']['prior_original_path'], str(old_path))
        self.assertTrue(rows[0]['restore']['relative'].endswith('新しい名前.py'))
        self.assertFalse(Path(archive_ref['path']).exists())

    def test_raw_json_tar_preserves_full_bytes(self) -> None:
        """機能: 70当場の小JSONを圧縮し、元SHA/size/memberを復元する。

        引数: self(Artificial)。返り値: None。原板本文を模していない。
        """
        rows = []
        for s in F.C.sessions():
            path = self.folder / (s + '.json')
            path.write_text(json.dumps({'人工': True, '場': s, '重複metadata': {'code': 'a' * 2000}}, ensure_ascii=False) + '\n', encoding='utf-8')
            rows.append({'session': s, 'ref': F.K.reference(path)})
        packed = F.pack_raw(self.folder / '監査.tar.gz', rows)
        self.assertEqual(len(packed), 70)
        self.assertTrue(all(r['sha256'] == rows[i]['ref']['sha256'] for i, r in enumerate(packed)))

    def test_stop_false_or_omitted_rejected_before_results(self) -> None:
        """機能: 停止false又は未記録を結果本文へ進む前に拒否する。

        引数: self(Artificial)。返り値: None。
        """
        for state in (False, None):
            p = self.folder / ('停止' + str(state) + '.json')
            stop = {'試行': 116, '成功': True, '市場前': True}
            if state is not None:
                stop['停止'] = state
            p.write_text(json.dumps(stop), encoding='utf-8')
            refs = {n: ref(self.folder / ('不存在_' + n + '.json')) for n in F.REQUIRED}
            refs['condition']['sha256'] = F.K.F1_SHA
            refs['market']['sha256'] = F.COMPLETE_SHA
            refs['native_index']['sha256'] = F.NATIVE_SHA
            refs['formal_stop'] = F.K.reference(p)
            request = {'version': 1, 'trial': 116, 'fixed': True, 'stage': 'full70', 'formal_write_authorized': True,
                       'market_native_read_authorized': True, 'raw_audit_read_authorized': True, 'refs': refs}
            q = self.folder / ('Root' + str(state) + '.json')
            q.write_text(json.dumps(request), encoding='utf-8')
            with self.assertRaisesRegex((ValueError, KeyError), '停止'):
                F.prepare(F.K.reference(q))

    def test_csv_zero_positions_and_real_denominator_metadata(self) -> None:
        """機能: CSV未定義率と正益経験分母を全36/2520再読へ結ぶ。

        引数: self(Artificial)。返り値: None。CSV本文を生成しない。
        """
        _, q = fixture(self.folder)
        csv_refs = {name: ref(F.ROOT / 'outputs/人工' / name) for name in ('候補別集計.csv', '全セッション.csv')}
        x = {'試行': 116, '成功': True, '場別行数': 2520, '候補数': 36, '全場累計再計算': True,
             '正益経験分母合算': True, '正益経験赤字率を原分母から再計算': True, '未定義比率は空欄': True,
             '前後不変': True, '入力SHA256': {r['path']: r['sha256'] for r in [q['refs']['result'], *csv_refs.values()]}}
        x['後SHA256'] = deepcopy(x['入力SHA256'])
        F.validate_csv(x, q['refs'], csv_refs)
        x['場別行数'] = 840
        with self.assertRaises(ValueError):
            F.validate_csv(x, q['refs'], csv_refs)


if __name__ == '__main__':
    unittest.main(verbosity=2)
