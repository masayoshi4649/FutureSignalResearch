package rawdelivery116

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// saveFixture116 は手製の小metadataを新規一時先へ保存します。
//
// 引数: t(*testing.T)、dir/name(string)、value(any)は試験器・位置・手製内容です。
// 返り値: FileRefは実際の手製ファイルとSHAです。
func saveFixture116(t *testing.T, dir, name string, value any) FileRef {
	t.Helper()
	ref, err := SaveNew(filepath.Join(dir, name), value)
	if err != nil {
		t.Fatal(err)
	}
	return ref
}

// ----------------------------------------
// fixedFixture116 は実自然金融を含まないfirst2用のRoot/停止/上流成功器具を作ります。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: Fixed/FileRef/stringは手製固定内容・要求参照・一時親folderです。
func fixedFixture116(t *testing.T) (Fixed, FileRef, string) {
	t.Helper()
	dir := t.TempDir()
	day, _, _ := fixture116(t, "2026-09-21_Day")
	night, _, _ := fixture116(t, "2026-09-21_Night")
	financial := saveFixture116(t, dir, "金融条件.json", map[string]any{"trial": 116, "fixed": true})
	complete := saveFixture116(t, dir, "金融完了.json", map[string]any{"trial": 116, "success": true, "stage": "first2", "sessions": 2, "books": 72, "condition_sha256": financial.SHA256, "unchanged": true})
	life := saveFixture116(t, dir, "独立life停止.json", map[string]any{"試行": 116, "成功": true, "停止": true, "市場前": true})
	value := map[string]any{"試行": 116, "成功": true, "stage": "first2", "場数": 2, "会計数": 72, "前後不変": true, "金融条件SHA256": financial.SHA256, "金融完了SHA256": complete.SHA256, "独立ライフ停止SHA256": life.SHA256, "Root保存要求SHA256": strings.Repeat("a", 64), "全Rawライフ発生漏れ/初回性監査": false}
	result := saveFixture116(t, dir, "独立結果.json", value)
	check := saveFixture116(t, dir, "独立検算.json", value)
	executable, err := os.Executable()
	if err != nil {
		t.Fatal(err)
	}
	digest, err := Digest(executable)
	if err != nil {
		t.Fatal(err)
	}
	mod, err := filepath.Abs("go.mod")
	if err != nil {
		t.Fatal(err)
	}
	modSHA, err := Digest(mod)
	if err != nil {
		t.Fatal(err)
	}
	owned := map[string]string{mod: modSHA}
	exe := FileRef{Path: executable, SHA256: digest}
	stop := saveFixture116(t, dir, "Reader停止.json", Stop{Trial: 116, Success: true, Stopped: true, MarketBefore: true, Owned: owned, AllCode: owned, Executable: exe})
	code := map[string]string{mod: modSHA, stop.Path: stop.SHA256}
	fixed := Fixed{Version: 1, Trial: 116, Fixed: true, RawReadAuthorized: true, Policy: Policy, Stage: "first2", ReaderStop: stop, Executable: exe, CodeSHA256: code,
		Refs: map[string]FileRef{"financial_condition": financial, "financial_completion": complete, "independent_result": result, "independent_check": check, "lifecycle_audit_stop": life}, Scenes: []Scene{day, night}}
	ref := saveFixture116(t, dir, "Root要求.json", fixed)
	return fixed, ref, dir
}

// ----------------------------------------
// TestMetadataOnlyNoRawOrUpstream116 はRaw/上流refsが不存在でも形式と自己停止だけを検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。metadata-onlyが自然本文や指紋走査へ踏み込まないことを確認します。
func TestMetadataOnlyNoRawOrUpstream116(t *testing.T) {
	fixed, _, dir := fixedFixture116(t)
	for _, scene := range fixed.Scenes {
		if err := os.Remove(scene.Raw.Path); err != nil {
			t.Fatal(err)
		}
	}
	for _, ref := range fixed.Refs {
		if err := os.Remove(ref.Path); err != nil {
			t.Fatal(err)
		}
	}
	ref := saveFixture116(t, dir, "未読要求.json", fixed)
	plan, err := Prepare(ref, true)
	if err != nil || !plan.MetadataOnly || len(plan.Before) != 4 {
		t.Fatal("形式/自己stopだけのmetadata検査差", err, len(plan.Before))
	}
	if _, err = Prepare(ref, false); err == nil {
		t.Fatal("実行時の上流成功認証を省略")
	}
}

// ----------------------------------------
// TestRootPermissionAndBindings116 は許可/条件/全36N/独立成功の結合破壊を本文前に拒否します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。CLI補助許可だけではRoot固定の許可を付与できません。
func TestRootPermissionAndBindings116(t *testing.T) {
	for _, kind := range []string{"permission", "stage", "old_trial", "financial_sha", "books", "independent_sha", "save_request", "future_session", "Raw_as_code"} {
		fixed, _, dir := fixedFixture116(t)
		switch kind {
		case "permission":
			fixed.RawReadAuthorized = false
		case "stage":
			fixed.Stage = "base54"
		case "old_trial":
			fixed.Trial = 115
		case "future_session":
			fixed.Scenes[0].Session = "2026-11-09_Day"
		case "Raw_as_code":
			fixed.CodeSHA256[fixed.Scenes[0].Raw.Path] = fixed.Scenes[0].Raw.SHA256
		default:
			key := "financial_completion"
			if kind == "independent_sha" || kind == "save_request" {
				key = "independent_check"
			}
			data, err := os.ReadFile(fixed.Refs[key].Path)
			if err != nil {
				t.Fatal(err)
			}
			value := map[string]any{}
			if err = json.Unmarshal(data, &value); err != nil {
				t.Fatal(err)
			}
			switch kind {
			case "financial_sha":
				value["condition_sha256"] = strings.Repeat("f", 64)
			case "books":
				value["books"] = 24
			case "independent_sha":
				value["独立ライフ停止SHA256"] = strings.Repeat("f", 64)
			case "save_request":
				value["Root保存要求SHA256"] = strings.Repeat("f", 64)
			}
			fixed.Refs[key] = saveFixture116(t, dir, "破壊成功.json", value)
		}
		ref := saveFixture116(t, dir, "破壊要求.json", fixed)
		if _, err := Prepare(ref, false); err == nil {
			t.Fatal("Root結合破壊を受理", kind)
		}
	}
	fixed, ref, dir := fixedFixture116(t)
	if _, err := RunStream(ref, fixed.Scenes[0].Session, filepath.Join(dir, "未許可"), false, io.Discard); err == nil {
		t.Fatal("補助許可欠落を受理")
	}
}

// ----------------------------------------
// TestStreamAndNewOutput116 はquote群と最後のsummary1件・新規小出力だけを確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。生Raw全件ファイル・金融演算は作りません。
func TestStreamAndNewOutput116(t *testing.T) {
	fixed, ref, dir := fixedFixture116(t)
	out := filepath.Join(dir, "新規配送")
	var buffer bytes.Buffer
	certificate, err := RunStream(ref, fixed.Scenes[0].Session, out, true, &buffer)
	if err != nil {
		t.Fatal(err)
	}
	decoder := json.NewDecoder(&buffer)
	kinds := []string{}
	for decoder.More() {
		var value map[string]json.RawMessage
		if err = decoder.Decode(&value); err != nil {
			t.Fatal(err)
		}
		var kind string
		_ = json.Unmarshal(value["kind"], &kind)
		kinds = append(kinds, kind)
	}
	if strings.Join(kinds, ",") != "quote,quote,quote,quote,summary" {
		t.Fatal("配送順序又は終了数差", kinds)
	}
	files, err := os.ReadDir(out)
	if err != nil || len(files) != 1 || files[0].Name() != "配送の確認.json" {
		t.Fatal("小Summary以外の全件出力", err)
	}
	if actual, _ := Digest(certificate.Path); actual != certificate.SHA256 {
		t.Fatal("終了Ref差")
	}
	if _, err = RunStream(ref, fixed.Scenes[0].Session, out, true, io.Discard); err == nil {
		t.Fatal("既存出力先へ再実行")
	}
}

type brokenWriter116 struct{}

// Write は人工のpipe切断を表します。
//
// 引数: p([]byte)は配送予定bytesです。
// 返り値: int/errorは0bytesと切断です。
func (brokenWriter116) Write(p []byte) (int, error) { return 0, errors.New("人工pipe切断") }

// ----------------------------------------
// TestBrokenPipeNoSummary116 は消費者への配送失敗を成功Summaryへしないことを検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。不完了小証拠だけを許します。
func TestBrokenPipeNoSummary116(t *testing.T) {
	fixed, ref, dir := fixedFixture116(t)
	out := filepath.Join(dir, "中断配送")
	if _, err := RunStream(ref, fixed.Scenes[0].Session, out, true, brokenWriter116{}); err == nil {
		t.Fatal("切断pipeを成功化")
	}
	if _, err := os.Stat(filepath.Join(out, "配送の確認.json")); !os.IsNotExist(err) {
		t.Fatal("中断後の成功証拠")
	}
	if _, err := os.Stat(filepath.Join(out, "不完了.json")); err != nil {
		t.Fatal("中断証拠なし", err)
	}
}
