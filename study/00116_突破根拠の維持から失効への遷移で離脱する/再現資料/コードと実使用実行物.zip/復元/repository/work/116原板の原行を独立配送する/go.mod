module github.com/masayoshi4649/SessionTradeExecuter/rawdelivery116

go 1.24.2

require github.com/masayoshi4649/SessionTradeExecuter/holdingohlc113 v0.0.0

replace github.com/masayoshi4649/SessionTradeExecuter/holdingohlc113 => ../113保有中OHLCの原板照合
