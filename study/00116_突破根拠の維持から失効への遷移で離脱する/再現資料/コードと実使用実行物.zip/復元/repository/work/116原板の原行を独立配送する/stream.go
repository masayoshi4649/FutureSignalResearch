package rawdelivery116

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
)

// SaveNew は小さい終了証拠だけを未作成ファイルへ保存します。
//
// 引数: path(string)、value(any)は新規位置と小metadataです。
// 返り値: FileRef/errorは保存物のSHA又は拒否です。Raw行全件は保存しません。
func SaveNew(path string, value any) (FileRef, error) {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return FileRef{}, err
	}
	file, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return FileRef{}, err
	}
	_, writeErr := file.Write(append(data, '\n'))
	closeErr := file.Close()
	if writeErr != nil {
		return FileRef{}, writeErr
	}
	if closeErr != nil {
		return FileRef{}, closeErr
	}
	digest, err := Digest(path)
	return FileRef{Path: path, SHA256: digest}, err
}

// ----------------------------------------
// RunStream はRoot許可・上流成功・新規先を確認後、一場の実保有窓だけを逐次配送します。
//
// 引数: condition(FileRef)、session/out(string)、rootAuthorized(bool)、writer(io.Writer)は要求・場・新規先・補助許可・pipeです。
// 返り値: FileRef/errorは成功Summary又は中断です。Root固定の許可なしではRawを開きません。
func RunStream(condition FileRef, session, out string, rootAuthorized bool, writer io.Writer) (ref FileRef, err error) {
	if !rootAuthorized {
		return ref, fmt.Errorf("補助Root許可が必要。単独ではRaw読取許可にならない")
	}
	plan, err := Prepare(condition, false)
	if err != nil {
		return ref, err
	}
	var scene *Scene
	for i := range plan.Fixed.Scenes {
		if plan.Fixed.Scenes[i].Session == session {
			scene = &plan.Fixed.Scenes[i]
		}
	}
	if scene == nil || writer == nil {
		return ref, fmt.Errorf("固定対象場と配送sinkが必要")
	}
	abs, err := filepath.Abs(out)
	if err != nil {
		return ref, err
	}
	if err = os.Mkdir(abs, 0755); err != nil {
		return ref, fmt.Errorf("Summary先は既存親配下の新規folderだけ:%w", err)
	}
	defer func() {
		if err != nil {
			_, _ = SaveNew(filepath.Join(abs, "不完了.json"), map[string]any{"trial": 116, "success": false, "condition": condition, "session": session, "error": err.Error()})
		}
	}()
	buffer := bufio.NewWriterSize(writer, 65536)
	encoder := json.NewEncoder(buffer)
	result, err := ScanFile(*scene, func(quote Quote) error {
		return encoder.Encode(struct {
			Kind  string `json:"kind"`
			Quote Quote  `json:"quote"`
		}{Kind: "quote", Quote: quote})
	})
	if err != nil {
		return ref, err
	}
	if err = buffer.Flush(); err != nil {
		return ref, fmt.Errorf("quote stream終端のsink中断:%w", err)
	}
	if err = VerifyInputs(plan.Before); err != nil {
		return ref, err
	}
	certificate := struct {
		Summary
		Condition       FileRef           `json:"condition"`
		Stage           string            `json:"stage"`
		InputSHA256     map[string]string `json:"input_sha256"`
		InputsUnchanged bool              `json:"inputs_unchanged"`
	}{Summary: result, Condition: condition, Stage: plan.Fixed.Stage, InputSHA256: plan.Before, InputsUnchanged: true}
	ref, err = SaveNew(filepath.Join(abs, "配送の確認.json"), certificate)
	if err != nil {
		return ref, err
	}
	end := struct {
		Kind string `json:"kind"`
		Summary
		Condition   FileRef `json:"condition"`
		SummaryFile FileRef `json:"summary_file"`
	}{Kind: "summary", Summary: result, Condition: condition, SummaryFile: ref}
	if err = encoder.Encode(end); err != nil {
		return ref, err
	}
	if err = buffer.Flush(); err != nil {
		return ref, fmt.Errorf("成功summary配送のsink中断:%w", err)
	}
	return ref, nil
}
