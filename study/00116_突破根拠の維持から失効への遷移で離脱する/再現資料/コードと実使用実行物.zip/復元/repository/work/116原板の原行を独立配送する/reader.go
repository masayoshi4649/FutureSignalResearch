package rawdelivery116

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"reflect"
	"sort"
	"time"
)

// finite は価格・時計・金額の非有限を拒否します。
//
// 引数: values(...float64)は検査値。返り値: boolは全て有限なら真です。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// normal はSourceの実評価と同じ有限の正Bid<Askだけを認めます。
//
// 引数: q(Quote)は原行。返り値: boolは正常BBOです。数量を条件に加えません。
func normal(q Quote) bool { return finite(q.Bid, q.Ask) && q.Bid > 0 && q.Ask > q.Bid }

// ----------------------------------------
// equalQuote は元clock文字列が無くても保存Quoteの全数値と物理境界を照合します。
//
// 引数: expected/actual(Quote)は台帳と原行。返り値: boolは全利用fieldが同体です。
func equalQuote(expected, actual Quote) bool {
	clock := expected.Clock
	expected.Clock = ""
	actualClock := actual.Clock
	actual.Clock = ""
	return expected == actual && (clock == "" || clock == actualClock)
}

// ----------------------------------------
// decodeRow はSource111の原板採用規則を独立コードで照合します。
//
// 引数: raw([]byte)、line/index(int64)、scene(Scene)、previous(float64)、counts(*Counts)、contracts(map[string]bool)。
// 返り値: *Quote/reason/nextPrevious/errorは配送行・除外理由・直前採用時計・壊れたJSON等です。
func decodeRow(raw []byte, line, index int64, scene Scene, previous float64, counts *Counts, contracts map[string]bool) (*Quote, string, float64, error) {
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(raw, &fields); err != nil {
		return nil, "", previous, fmt.Errorf("物理%d JSON:%w", line, err)
	}
	var symbol string
	if err := json.Unmarshal(fields["Symbol"], &symbol); err != nil {
		return nil, "", previous, fmt.Errorf("物理%d Symbol:%w", line, err)
	}
	contracts[symbol] = true
	if len(fields["CurrentPriceTime"]) == 0 {
		counts.ClockMissing++
		return nil, "clock_missing", previous, nil
	}
	var clock string
	if err := json.Unmarshal(fields["CurrentPriceTime"], &clock); err != nil {
		return nil, "", previous, fmt.Errorf("物理%d CurrentPriceTime型:%w", line, err)
	}
	at, err := time.Parse(time.RFC3339Nano, clock)
	if err != nil {
		counts.ClockInvalid++
		return nil, "clock_invalid", previous, nil
	}
	stamp := float64(at.UnixNano()) / 1e9
	if !finite(stamp) || stamp < scene.Start || stamp > scene.End {
		counts.Outside++
		return nil, "outside_session", previous, nil
	}
	if stamp < previous {
		counts.Backward++
		return nil, "backward_clock", previous, nil
	}
	var last float64
	if len(fields["CurrentPrice"]) > 0 {
		if err = json.Unmarshal(fields["CurrentPrice"], &last); err != nil {
			return nil, "", previous, fmt.Errorf("物理%d CurrentPrice型/非有限:%w", line, err)
		}
	}
	if !finite(last) {
		counts.LastNonFinite++
		return nil, "last_non_finite", previous, nil
	}
	if last <= 0 {
		counts.LastNonPositive++
		return nil, "last_non_positive", previous, nil
	}
	// ----------------------------------------
	// 最良以外を値として保存しませんが、旧parserと同じ10深度のJSON型を検査します。
	q := Quote{Clock: clock, Time: stamp, Index: index, SourceLine: line, Last: last}
	for i := 1; i <= 10; i++ {
		var buy, sell struct{ Price, Qty float64 }
		if err = json.Unmarshal(fields[fmt.Sprintf("Buy%d", i)], &buy); err != nil {
			return nil, "", previous, fmt.Errorf("物理%d Buy%d:%w", line, i, err)
		}
		if err = json.Unmarshal(fields[fmt.Sprintf("Sell%d", i)], &sell); err != nil {
			return nil, "", previous, fmt.Errorf("物理%d Sell%d:%w", line, i, err)
		}
		if i == 1 {
			q.Bid, q.Ask = buy.Price, sell.Price
		}
	}
	q.QuoteOK = normal(q)
	counts.Accepted++
	if !q.QuoteOK {
		counts.BadBBO++
	}
	if scene.Cutoff > 0 && stamp >= scene.Cutoff {
		counts.CutoffExcluded++
		return nil, "cutoff_excluded", stamp, nil
	}
	counts.Delivered++
	return &q, "", stamp, nil
}

// ----------------------------------------
// validateScene はRaw本文を開く前にNK225と非重複保有窓の全境界を検査します。
//
// 引数: scene(Scene)はRoot固定又は手製人工の一場です。
// 返り値: errorは不正なscope・指紋・窓・期待品質です。
func validateScene(scene Scene) error {
	if scene.Reference != "NK225" || scene.Session == "" || scene.Contract == "" || !finite(scene.Start, scene.End, scene.Cutoff) || scene.End <= scene.Start || scene.Cutoff < 0 || scene.Cutoff > 0 && (scene.Cutoff <= scene.Start || scene.Cutoff > scene.End) || !validRef(scene.Raw) || scene.RawBytes <= 0 || scene.ExpectedSourceRows < 0 || scene.ExpectedSourceQuality == nil {
		return fmt.Errorf("NK225場/Raw参照/期待Source数が不正")
	}
	ids := map[string]bool{}
	var previous *Window
	for i := range scene.Windows {
		window := &scene.Windows[i]
		if window.ID == "" || ids[window.ID] || window.Start.SourceLine < 1 || window.End.SourceLine < window.Start.SourceLine || window.Start.Index < 0 || window.End.Index < window.Start.Index || window.End.Index >= scene.ExpectedSourceRows || !finite(window.Start.Time, window.End.Time, window.Start.Last, window.Start.Bid, window.Start.Ask, window.End.Last, window.End.Bid, window.End.Ask) || window.Start.Last <= 0 || window.End.Last <= 0 || window.Start.Time < scene.Start || window.End.Time > scene.End || window.End.Time < window.Start.Time || scene.Cutoff > 0 && window.End.Time >= scene.Cutoff || window.Start.QuoteOK != normal(window.Start) || window.End.QuoteOK != normal(window.End) {
			return fmt.Errorf("保有窓の境界/Index/生気配が不正:%s", window.ID)
		}
		if previous != nil && (previous.End.SourceLine >= window.Start.SourceLine || previous.End.Index >= window.Start.Index || previous.End.Time > window.Start.Time) {
			return fmt.Errorf("保有窓は物理行順の非重複和集合が必要")
		}
		ids[window.ID], previous = true, window
	}
	return nil
}

// ----------------------------------------
// ScanFile はgzipを一度だけ読み、窓外も採用Indexを形成して窓内採用行をsinkへ渡します。
//
// 引数: scene(Scene)、sink(Sink)は固定場と逐次消費者。自然RawはPrepare/RunStreamを経由します。
// 返り値: Summary/errorは圧縮SHA・品質・境界を全て照合した終了証拠又は不成功です。
func ScanFile(scene Scene, sink Sink) (result Summary, err error) {
	result = Summary{Version: 1, Trial: 116, Session: scene.Session, Raw: scene.Raw, RawPasses: 1, AllTenDepthsChecked: true, Windows: []WindowResult{}}
	if err = validateScene(scene); err != nil {
		return result, err
	}
	if sink == nil && len(scene.Windows) > 0 {
		return result, fmt.Errorf("保有窓の配送sinkが必要")
	}
	for _, window := range scene.Windows {
		result.Windows = append(result.Windows, WindowResult{Window: window})
	}
	file, err := os.Open(scene.Raw.Path)
	if err != nil {
		return result, err
	}
	defer file.Close()
	before, err := file.Stat()
	if err != nil {
		return result, err
	}
	result.Before = FileStat{Bytes: before.Size(), ModTimeNS: before.ModTime().UnixNano()}
	if before.Size() != scene.RawBytes {
		return result, fmt.Errorf("圧縮sizeの期待差")
	}
	hash := sha256.New()
	tee := io.TeeReader(file, hash)
	z, err := gzip.NewReader(tee)
	if err != nil {
		return result, err
	}
	defer z.Close()
	scan := bufio.NewScanner(z)
	scan.Buffer(make([]byte, 65536), 8*1024*1024)
	contracts := map[string]bool{}
	previous, index, cursor := scene.Start, int64(0), 0
	for scan.Scan() {
		result.Quality.Lines++
		line := result.Quality.Lines
		quote, reason, next, failure := decodeRow(scan.Bytes(), line, index, scene, previous, &result.Quality, contracts)
		if failure != nil {
			return result, failure
		}
		previous = next
		if quote != nil {
			index++
		}
		if cursor >= len(result.Windows) || line < result.Windows[cursor].Window.Start.SourceLine {
			continue
		}
		work := &result.Windows[cursor]
		if line == work.Window.Start.SourceLine {
			if quote == nil || !equalQuote(work.Window.Start, *quote) {
				return result, fmt.Errorf("保有窓開始Quote/Index差:%s 行%d 理由%s", work.Window.ID, line, reason)
			}
			work.StartMatched = true
		}
		if line == work.Window.End.SourceLine {
			if quote == nil || !equalQuote(work.Window.End, *quote) {
				return result, fmt.Errorf("保有窓終了Quote/Index差:%s 行%d 理由%s", work.Window.ID, line, reason)
			}
			work.EndMatched = true
		}
		if quote != nil {
			if err = sink(*quote); err != nil {
				return result, fmt.Errorf("配送sink中断:%w", err)
			}
			work.Rows++
			result.StreamedRows++
			if !quote.QuoteOK {
				work.BadBBORows++
			} else {
				result.NormalStreamedRows++
			}
		}
		if line == work.Window.End.SourceLine {
			if !work.StartMatched || !work.EndMatched || work.Rows != work.Window.End.Index-work.Window.Start.Index+1 {
				return result, fmt.Errorf("保有窓の採用数/Index連続性差:%s", work.Window.ID)
			}
			cursor++
		}
	}
	if err = scan.Err(); err != nil {
		return result, err
	}
	// ----------------------------------------
	// SHAは同じ読取器で圧縮末尾まで確定し、Rawを再度開いて走査しません。
	if _, err = io.Copy(io.Discard, tee); err != nil {
		return result, err
	}
	result.ActualSHA256, result.CompressedBytes = hex.EncodeToString(hash.Sum(nil)), before.Size()
	after, err := file.Stat()
	if err != nil {
		return result, err
	}
	pathAfter, err := os.Stat(scene.Raw.Path)
	if err != nil {
		return result, err
	}
	result.After = FileStat{Bytes: after.Size(), ModTimeNS: after.ModTime().UnixNano()}
	if result.ActualSHA256 != scene.Raw.SHA256 || result.Before != result.After || !os.SameFile(after, pathAfter) || pathAfter.Size() != after.Size() || pathAfter.ModTime() != after.ModTime() {
		return result, fmt.Errorf("圧縮SHA/前後stat/同pathファイル差")
	}
	for symbol := range contracts {
		result.SourceQuality.Contracts = append(result.SourceQuality.Contracts, symbol)
	}
	sort.Strings(result.SourceQuality.Contracts)
	if len(result.SourceQuality.Contracts) != 1 || result.SourceQuality.Contracts[0] != scene.Contract || cursor != len(result.Windows) {
		return result, fmt.Errorf("限月差又は保有窓EOF欠落")
	}
	quality := result.Quality
	result.SourceQuality = SourceQuality{Lines: quality.Lines, ClockMissing: quality.ClockMissing + quality.ClockInvalid, Outside: quality.Outside, Backward: quality.Backward, BadLast: quality.LastNonPositive + quality.LastNonFinite, BadQuote: quality.BadBBO, Accepted: quality.Accepted, Contracts: result.SourceQuality.Contracts}
	result.SourceQualityEqual = reflect.DeepEqual(result.SourceQuality, *scene.ExpectedSourceQuality)
	result.SourceRowsEqual = quality.Delivered == scene.ExpectedSourceRows
	if !result.SourceQualityEqual || !result.SourceRowsEqual {
		return result, fmt.Errorf("Source品質又は配送総原行数の期待差")
	}
	result.SourceIndexVerified, result.Success = true, true
	return result, nil
}
