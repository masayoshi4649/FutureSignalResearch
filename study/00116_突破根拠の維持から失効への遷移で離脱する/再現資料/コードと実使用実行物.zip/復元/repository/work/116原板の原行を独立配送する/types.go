// Package rawdelivery116 はNK225原板の採用原行だけを独立監査sinkへ配送します。
package rawdelivery116

type FileRef struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
}

type Quote struct {
	Clock      string  `json:"clock,omitempty"`
	Time       float64 `json:"time"`
	Index      int64   `json:"index"`
	SourceLine int64   `json:"source_line"`
	Last       float64 `json:"last"`
	Bid        float64 `json:"bid"`
	Ask        float64 `json:"ask"`
	QuoteOK    bool    `json:"quote_ok"`
}

type Counts struct {
	Lines           int64 `json:"lines"`
	ClockMissing    int64 `json:"clock_missing"`
	ClockInvalid    int64 `json:"clock_invalid"`
	Outside         int64 `json:"outside_session"`
	Backward        int64 `json:"backward_clock"`
	LastNonPositive int64 `json:"last_non_positive"`
	LastNonFinite   int64 `json:"last_non_finite"`
	BadBBO          int64 `json:"bad_bbo"`
	Accepted        int64 `json:"source_parser_accepted"`
	CutoffExcluded  int64 `json:"cutoff_excluded"`
	Delivered       int64 `json:"source_delivered"`
}

// SourceQuality はSource111.RawQualityの同名値を独立に照合するための型です。
type SourceQuality struct {
	Lines        int64    `json:"lines"`
	ClockMissing int64    `json:"clock_missing"`
	Outside      int64    `json:"outside"`
	Backward     int64    `json:"backward"`
	BadLast      int64    `json:"bad_last"`
	BadQuote     int64    `json:"bad_quote"`
	Accepted     int64    `json:"accepted"`
	Contracts    []string `json:"contracts"`
}

// Window は実保有窓の重複しない和集合を物理行と採用Indexで固定します。
type Window struct {
	ID    string `json:"window_id"`
	Start Quote  `json:"start_quote"`
	End   Quote  `json:"end_quote"`
}

type Scene struct {
	Session               string         `json:"session"`
	Reference             string         `json:"reference"`
	Contract              string         `json:"contract"`
	Start                 float64        `json:"start"`
	End                   float64        `json:"end"`
	Cutoff                float64        `json:"cutoff"`
	Raw                   FileRef        `json:"raw"`
	RawBytes              int64          `json:"raw_bytes"`
	ExpectedSourceRows    int64          `json:"expected_source_rows"`
	ExpectedSourceQuality *SourceQuality `json:"expected_source_quality"`
	Windows               []Window       `json:"windows"`
}

type FileStat struct {
	Bytes     int64 `json:"bytes"`
	ModTimeNS int64 `json:"mtime_ns"`
}

type WindowResult struct {
	Window       Window `json:"window"`
	StartMatched bool   `json:"start_matched"`
	EndMatched   bool   `json:"end_matched"`
	Rows         int64  `json:"rows"`
	BadBBORows   int64  `json:"bad_bbo_rows"`
}

type Summary struct {
	Version             int            `json:"version"`
	Trial               int            `json:"trial"`
	Success             bool           `json:"success"`
	Session             string         `json:"session"`
	Raw                 FileRef        `json:"raw"`
	ActualSHA256        string         `json:"actual_sha256"`
	CompressedBytes     int64          `json:"compressed_bytes"`
	Before              FileStat       `json:"stat_before"`
	After               FileStat       `json:"stat_after"`
	Quality             Counts         `json:"quality"`
	SourceQuality       SourceQuality  `json:"source_quality"`
	SourceQualityEqual  bool           `json:"source_quality_equal"`
	SourceRowsEqual     bool           `json:"source_rows_equal"`
	Windows             []WindowResult `json:"windows"`
	StreamedRows        int64          `json:"streamed_rows"`
	NormalStreamedRows  int64          `json:"normal_streamed_rows"`
	RawPasses           int            `json:"raw_passes"`
	SourceIndexVerified bool           `json:"source_index_verified"`
	AllTenDepthsChecked bool           `json:"all_ten_depths_checked"`
	FinancialReplay     bool           `json:"financial_replay"`
	AllRawRowsSaved     bool           `json:"all_raw_rows_saved"`
}

// Sink は保有窓内の採用行を一行ずつ受ける関数です。エラーは成功を中断します。
type Sink func(Quote) error
