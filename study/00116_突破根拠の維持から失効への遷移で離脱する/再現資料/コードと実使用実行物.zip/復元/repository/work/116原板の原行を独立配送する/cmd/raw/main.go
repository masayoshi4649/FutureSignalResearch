package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"

	raw "github.com/masayoshi4649/SessionTradeExecuter/rawdelivery116"
)

// main は固定Raw要求のmetadata検査又は一場のpipe配送だけを起動します。
//
// 引数: CLI request/sha/session/out(string)、metadata-only/root-authorized(bool)は固定参照と動作です。
// 返り値: なし。不成功はstderrとexit1、正常streamはquote群の後にsummary1件です。
func main() {
	request := flag.String("request", "", "Root固定要求の絶対path")
	sha := flag.String("sha", "", "要求の期待SHA256")
	session := flag.String("session", "", "配送する固定場ID")
	out := flag.String("out", "", "小Summaryの新規folder")
	metadata := flag.Bool("metadata-only", false, "Raw/上流refs未読で形式と自己owned停止だけを確認")
	authorized := flag.Bool("root-authorized", false, "Root固定許可に加える補助確認")
	flag.Parse()
	condition := raw.FileRef{Path: *request, SHA256: *sha}
	var err error
	if *metadata {
		var plan raw.Plan
		plan, err = raw.Prepare(condition, true)
		if err == nil {
			err = json.NewEncoder(os.Stdout).Encode(map[string]any{"trial": 116, "success": true, "metadata_only": true, "condition": condition, "sessions": len(plan.Fixed.Scenes), "raw_opened": false, "raw_hashed": false, "upstream_refs_opened": false, "own_inputs": len(plan.Before)})
		}
	} else {
		if *session == "" || *out == "" {
			err = fmt.Errorf("streamにはsessionと未作成outが必要")
		} else {
			_, err = raw.RunStream(condition, *session, *out, *authorized, os.Stdout)
		}
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
