"""116原板配送器の手製検査とコード不変だけをRootレビュー後に固定する。"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OLD = ROOT / 'work/113保有中OHLCの原板照合'
OLD_STOP_SHA = '6502a505ca8962393c44135c7bcd7be357c08ec1fe11e405aea9213bc068b440'
OLD_READER_SHA = '08323cc1a499d2eebdd889189612286fbf0165c8598564fc0b4f05e76402499a'
COPY_SHA = 'fd8a48a5481edd538752c2eb79b5f4686df5b0d0315b4878a216e5533e7ec9b9'


def sha(path: Path) -> str:
    """機能: 明示コード又は一時人工の全bytes指紋を返す。

    引数: path(Path)は入力位置。
    返り値: strは小文字SHA256。自然Rawには使用しない。
    """
    digest = hashlib.sha256()
    with path.open('rb') as file:
        while block := file.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def run(argv: list[str], environment: dict) -> dict:
    """機能: 市場へ接続しないGo人工又はbuild/API検査を実行する。

    引数: argv(list[str])、environment(dict)は明示コマンドと環境。
    返り値: dictは終了値/全出力。不成功はValueError。
    """
    value = subprocess.run(argv, cwd=HERE, env=environment, capture_output=True,
                           text=True, encoding='utf-8', timeout=120)
    result = {'argv': argv, 'exit_code': value.returncode,
              'stdout': value.stdout, 'stderr': value.stderr}
    if value.returncode:
        raise ValueError(json.dumps(result, ensure_ascii=False))
    return result


# ----------------------------------------
def go_function(path: Path, name: str) -> str:
    """機能: 比較対象の旧/新reader関数本文だけを取り出す。

    引数: path(Path)、name(str)は既知reader.goと対象名。
    返り値: strは宣言と本文。この限定コード以外の汎用パーサではない。
    """
    source = path.read_text(encoding='utf-8')
    match = re.search(r'^func ' + re.escape(name) + r'\(', source, re.M)
    if not match:
        raise ValueError('対象関数なし:' + name)
    line_end = source.find('\n', match.start())
    end = line_end - 1 if '}' in source[match.start():line_end] else source.find('\n}', match.start())
    return source[match.start():end + 2]


# ----------------------------------------
def dependencies() -> tuple[dict, dict]:
    """機能: 元停止と採用関数の無変更を認証し出典/旧人工依存を集める。

    引数: なし。
    返り値: tuple[dict,dict]は依存SHAと関数同体証拠。
    """
    if sha(OLD / '停止.json') != OLD_STOP_SHA or sha(OLD / 'reader.go') != OLD_READER_SHA or sha(HERE / '同bytesコピーの記録.json') != COPY_SHA:
        raise ValueError('旧停止/reader/変更前コピーの指紋差')
    origin = json.loads((HERE / '派生元と採用規則.json').read_bytes())
    refs = dict(origin['出典SHA256'])
    old = json.loads((OLD / '停止.json').read_bytes())
    refs.update(old['所有コードSHA256'])
    if any(sha(Path(path)) != expected for path, expected in refs.items()):
        raise ValueError('旧Reader/Source出典の指紋差')
    same = {}
    for name in ['finite', 'normal', 'equalQuote', 'decodeRow']:
        previous = go_function(OLD / 'reader.go', name)
        current = go_function(HERE / 'reader.go', name)
        if current != previous:
            raise ValueError('採用関数本文差:' + name)
        same[name] = hashlib.sha256(current.encode('utf-8')).hexdigest()
    return refs, {'全4関数本文同体': True, '関数SHA256': same,
                  'Source111との対応': 'readBoards→Cutoff→Features.Counts[Reference]。Source自体は実行しない。'}


# ----------------------------------------
def closure(environment: dict) -> dict:
    """機能: 実CLIの非テストGoソース閉包を指紋化する。

    引数: environment(dict)は明示Go環境。
    返り値: dict[str,str]は実在ソース/module位置とSHA。自動testmainは含めない。
    """
    output = run(['go', 'list', '-deps', '-json', './cmd/raw'], environment)['stdout']
    decoder, offset, paths = json.JSONDecoder(), 0, set()
    while output[offset:].strip():
        offset += len(output[offset:]) - len(output[offset:].lstrip())
        item, offset = decoder.raw_decode(output, offset)
        directory = Path(item['Dir'])
        for field in ['GoFiles', 'CgoFiles', 'CFiles', 'HFiles', 'SFiles', 'SysoFiles', 'EmbedFiles']:
            for name in item.get(field, []):
                path = (directory / name).resolve()
                if not path.is_file():
                    raise ValueError('実Go閉包欠落:' + str(path))
                paths.add(path)
        module = item.get('Module', {})
        if module.get('GoMod'):
            paths.add(Path(module['GoMod']).resolve())
    return {str(path): sha(path) for path in sorted(paths)}


# ----------------------------------------
def inspect_and_stop(root_reviewed: bool) -> dict:
    """機能: Rootレビュー後だけ10主人工/vet/build/APIと全コード不変を停止する。

    引数: root_reviewed(bool)はRootの明示レビュー完了。
    返り値: dictは停止Ref。既存停止・検査先への上書きを拒否する。
    """
    target, output = HERE / '停止.json', HERE / '検査'
    if not root_reviewed or target.exists() or output.exists():
        raise ValueError('Rootレビュー済みかつ停止/検査は未作成が必要')
    own = sorted(HERE.glob('*.go')) + [HERE / 'cmd/raw/main.go'] + [HERE / name for name in
        ['go.mod', 'README.md', '同bytesコピーの記録.json', '派生元と採用規則.json', Path(__file__).name]]
    before = {str(path): sha(path) for path in own}
    reused, derivation = dependencies()
    environment = dict(os.environ, GOWORK='off', CGO_ENABLED='0')
    actual = closure(environment)
    checks = [run(['go', 'test', '-count=1', '-json', './...'], environment),
              run(['go', 'vet', './...'], environment), run(['go', 'build', '-o', '原板配送.exe', './cmd/raw'], environment)]
    events = [json.loads(line) for line in checks[0]['stdout'].splitlines() if line.startswith('{')]
    tests = [x['Test'] for x in events if x.get('Action') == 'pass' and 'Test' in x]
    if len(tests) != 10:
        raise ValueError('主人工10件の差:' + str(tests))
    executable = {'path': str(HERE / '原板配送.exe'), 'sha256': sha(HERE / '原板配送.exe')}
    api = run(['go', 'doc', '-all', '.'], environment)
    if not all(name in api['stdout'] for name in ['func Prepare(', 'func RunStream(', 'func ScanFile(', 'type Scene struct', 'type Summary struct']):
        raise ValueError('公開API差')
    if before != {path: sha(Path(path)) for path in before} or actual != closure(environment) or any(sha(Path(path)) != expected for path, expected in reused.items()):
        raise ValueError('所有/実Go/旧固定出典の前後差')
    dependencies()
    output.mkdir()
    api_path = output / 'API.txt'
    api_path.write_text(api['stdout'], encoding='utf-8')
    all_code = {**reused, **actual, **before}
    proof = {'試行': 116, '成功': True, '市場前': True, '主人工数': 10, '成功test': tests,
             'test/vet/build': checks, '派生同体': derivation, '全所有依存前後不変': True,
             '自然Raw/市場Native/価格CSV/損益CSV/11月09本文': 0,
             '自然Reader実走査': False, '全Rawライフ発生漏れ/初回性監査': False,
             '範囲': '原板採用/Index/窓内配送/終了SHAの人工。ライフ独立stateと自然Raw監査は別。'}
    proof_path = output / '人工の確認.json'
    proof_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    result = {'試行': 116, 'trial': 116, '成功': True, '停止': True, '市場前': True,
              'module': 'github.com/masayoshi4649/SessionTradeExecuter/rawdelivery116',
              '所有コードSHA256': before, '再用コードSHA256': reused, '実Go依存SHA256': actual,
              '全固定コードSHA256': all_code, '全所有依存前後不変': True, '実行物': executable,
              '実API': {'path': str(api_path), 'sha256': sha(api_path)},
              '人工': {'path': str(proof_path), 'sha256': sha(proof_path)},
              '旧Reader停止': {'path': str(OLD / '停止.json'), 'sha256': OLD_STOP_SHA},
              '自然Raw/市場Native/CSV/11月09本文': 0,
              '金融再実行': False, '全Rawライフ発生漏れ/初回性監査': False}
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return {'成功': True, '停止': {'path': str(target), 'sha256': sha(target)}, '実行物': executable}


# ----------------------------------------
def main() -> None:
    """機能: 明示Rootレビュー完了後だけ停止helperを実行する。

    引数: CLI root-reviewed(bool)はRootレビュー。
    返り値: None。成功時は停止と実行物のRefを表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root-reviewed', action='store_true')
    args = parser.parse_args()
    print(json.dumps(inspect_and_stop(args.root_reviewed), ensure_ascii=False))


if __name__ == '__main__':
    main()
