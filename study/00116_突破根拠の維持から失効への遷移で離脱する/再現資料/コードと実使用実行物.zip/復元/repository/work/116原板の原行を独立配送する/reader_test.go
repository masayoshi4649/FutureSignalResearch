package rawdelivery116

import (
	"compress/gzip"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"testing"
	"time"

	old "github.com/masayoshi4649/SessionTradeExecuter/holdingohlc113"
)

// rawRow116 は旧Source型と同じ手製十深度のJSON行を作ります。
//
// 引数: clock(string)、last/bid/ask(float64)は当時時計と価格です。
// 返り値: map[string]anyは自然市場由来でない人工原板です。
func rawRow116(clock string, last, bid, ask float64) map[string]any {
	row := map[string]any{"Symbol": "人工限月116", "CurrentPriceTime": clock, "CurrentPrice": last}
	for i := 1; i <= 10; i++ {
		row[fmt.Sprintf("Buy%d", i)] = map[string]float64{"Price": bid, "Qty": 1}
		row[fmt.Sprintf("Sell%d", i)] = map[string]float64{"Price": ask, "Qty": 1}
	}
	return row
}

// ----------------------------------------
// writeRaw116 は一時人工だけのgzipと圧縮指紋を作ります。
//
// 引数: t(*testing.T)、rows([]map[string]any)は試験器と手製行です。
// 返り値: FileRef/int64は人工の絶対位置・SHA・圧縮bytesです。
func writeRaw116(t *testing.T, rows []map[string]any) (FileRef, int64) {
	t.Helper()
	path := filepath.Join(t.TempDir(), "人工.jsonl.gz")
	file, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	zipper := gzip.NewWriter(file)
	for _, row := range rows {
		body, err := json.Marshal(row)
		if err != nil {
			t.Fatal(err)
		}
		if _, err = zipper.Write(append(body, '\n')); err != nil {
			t.Fatal(err)
		}
	}
	if err = zipper.Close(); err != nil {
		t.Fatal(err)
	}
	if err = file.Close(); err != nil {
		t.Fatal(err)
	}
	digest, err := Digest(path)
	if err != nil {
		t.Fatal(err)
	}
	stat, err := os.Stat(path)
	if err != nil {
		t.Fatal(err)
	}
	return FileRef{Path: path, SHA256: digest}, stat.Size()
}

// ----------------------------------------
// fixture116 は窓前除外・同秒別行・Last0未来・異常BBOを含むSource採用人工です。
//
// 引数: t(*testing.T)、id(string)は試験器とDay/Nightです。
// 返り値: Scene/[]Quote/[]map[string]anyは期待6採用行と元人工です。
func fixture116(t *testing.T, id string) (Scene, []Quote, []map[string]any) {
	t.Helper()
	start, end, err := sessionTimes(id)
	if err != nil {
		t.Fatal(err)
	}
	base := time.Unix(int64(start), 0).In(time.FixedZone("JST", 9*3600))
	clock := func(offset time.Duration) string { return base.Add(offset).Format(time.RFC3339Nano) }
	rows := []map[string]any{
		rawRow116(clock(0), 100, 99, 101), rawRow116("不正時計", 100, 99, 101), rawRow116(clock(-time.Second), 100, 99, 101),
		rawRow116(clock(time.Second), 102, 100, 105), rawRow116(clock(time.Second), 103, 100, 100), rawRow116(clock(5*time.Second), 0, 100, 105),
		rawRow116(clock(2*time.Second+time.Nanosecond), 104, 102, 106), rawRow116(clock(1500*time.Millisecond), 104, 102, 106),
		rawRow116(clock(2*time.Second+time.Nanosecond), 105, 103, 107), rawRow116(clock(3*time.Second), 106, 104, 108),
		rawRow116(time.Unix(int64(end+1), 0).Format(time.RFC3339Nano), 107, 105, 109), rawRow116(clock(4*time.Second), 108, 106, 110),
	}
	delete(rows[0], "CurrentPriceTime")
	ref, size := writeRaw116(t, rows)
	accepted := []Quote{}
	for index, line := range []int{4, 5, 7, 9, 10, 12} {
		row := rows[line-1]
		stamp, _ := time.Parse(time.RFC3339Nano, row["CurrentPriceTime"].(string))
		quote := Quote{Clock: row["CurrentPriceTime"].(string), Time: float64(stamp.UnixNano()) / 1e9, Index: int64(index), SourceLine: int64(line), Last: row["CurrentPrice"].(float64), Bid: row["Buy1"].(map[string]float64)["Price"], Ask: row["Sell1"].(map[string]float64)["Price"]}
		quote.QuoteOK = normal(quote)
		accepted = append(accepted, quote)
	}
	scene := Scene{Session: id, Reference: "NK225", Contract: "人工限月116", Start: start, End: end, Raw: ref, RawBytes: size, ExpectedSourceRows: 6,
		ExpectedSourceQuality: &SourceQuality{Lines: 12, ClockMissing: 2, Outside: 2, Backward: 1, BadLast: 1, BadQuote: 1, Accepted: 6, Contracts: []string{"人工限月116"}},
		Windows:               []Window{{ID: "和集合1", Start: accepted[1], End: accepted[3]}, {ID: "和集合2", Start: accepted[5], End: accepted[5]}}}
	return scene, accepted, rows
}

// ----------------------------------------
// TestSourceFilterAndWindows116 は窓外も採用Indexを保ち同秒別行を全配送します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。手計算Source品質・異常BBO・境界inclusiveを確認します。
func TestSourceFilterAndWindows116(t *testing.T) {
	scene, accepted, _ := fixture116(t, "2026-09-21_Day")
	delivered := []Quote{}
	summary, err := ScanFile(scene, func(q Quote) error { delivered = append(delivered, q); return nil })
	if err != nil {
		t.Fatal(err)
	}
	want := []Quote{accepted[1], accepted[2], accepted[3], accepted[5]}
	if !reflect.DeepEqual(delivered, want) || !summary.Success || summary.RawPasses != 1 || summary.StreamedRows != 4 || summary.NormalStreamedRows != 3 || !summary.SourceIndexVerified || !summary.SourceRowsEqual || !summary.SourceQualityEqual || summary.Quality.ClockMissing != 1 || summary.Quality.ClockInvalid != 1 || summary.Quality.LastNonPositive != 1 {
		t.Fatal("採用/窓/品質/同秒の独立手計算差")
	}
	if delivered[1].Time != delivered[2].Time || delivered[1].Index == delivered[2].Index || delivered[1].SourceLine == delivered[2].SourceLine {
		t.Fatal("同秒の別原行を潰した")
	}
}

// ----------------------------------------
// TestLegacyReaderQuotes116 は改変しない旧113の同じ人工走査と全採用行を突合します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。自然Rawの二重走査は行わず一時人工だけを比較します。
func TestLegacyReaderQuotes116(t *testing.T) {
	scene, accepted, _ := fixture116(t, "2026-09-21_Day")
	prior := old.Scene{Session: scene.Session, Contract: scene.Contract, Start: scene.Start, End: scene.End, Raw: old.FileRef{Path: scene.Raw.Path, SHA256: scene.Raw.SHA256}, RawBytes: scene.RawBytes}
	for i, q := range accepted {
		prior.WitnessRequests = append(prior.WitnessRequests, old.WitnessRequest{ID: fmt.Sprint(i), Session: scene.Session, Index: q.Index, SourceLine: q.SourceLine})
	}
	proof, err := old.ScanFile(prior)
	if err != nil {
		t.Fatal(err)
	}
	for i, q := range accepted {
		left, _ := json.Marshal(q)
		right, _ := json.Marshal(proof.Witnesses[fmt.Sprint(i)].Quote)
		if string(left) != string(right) {
			t.Fatal("旧113の実採用Quote差", i)
		}
	}
	result, err := ScanFile(scene, func(Quote) error { return nil })
	if err != nil {
		t.Fatal(err)
	}
	left, _ := json.Marshal(result.Quality)
	right, _ := json.Marshal(proof.Quality)
	if string(left) != string(right) {
		t.Fatal("旧113の品質全field差")
	}
}

// ----------------------------------------
// TestCutoffAndEmptyUnion116 はCutoff後も品質を数え全窓0を金融成功へ偽装しません。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。対象0は配送0のままSource全採用検査だけを確認します。
func TestCutoffAndEmptyUnion116(t *testing.T) {
	scene, _, _ := fixture116(t, "2026-09-21_Night")
	scene.Windows = []Window{}
	scene.Cutoff = scene.Start + 3
	scene.ExpectedSourceRows = 4
	summary, err := ScanFile(scene, nil)
	if err != nil || !summary.Success || summary.StreamedRows != 0 || summary.Quality.Accepted != 6 || summary.Quality.Delivered != 4 || summary.Quality.CutoffExcluded != 2 {
		t.Fatal("Cutoff又は空和集合の計数差", err)
	}
}

// ----------------------------------------
// TestBoundarySHAAndSinkFailures116 は期待差と消費者中断を成功終了へしないことを検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。価格・Index・時計・SHA・品質の破壊を検出します。
func TestBoundarySHAAndSinkFailures116(t *testing.T) {
	for _, kind := range []string{"index", "time", "price", "SHA", "size", "quality", "rows", "overlap", "sink"} {
		scene, _, _ := fixture116(t, "2026-09-21_Day")
		switch kind {
		case "index":
			scene.Windows[0].Start.Index--
		case "time":
			scene.Windows[0].Start.Time += .1
		case "price":
			scene.Windows[0].End.Bid++
		case "SHA":
			scene.Raw.SHA256 = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
		case "size":
			scene.RawBytes++
		case "quality":
			scene.ExpectedSourceQuality.Accepted++
		case "rows":
			scene.ExpectedSourceRows++
		case "overlap":
			scene.Windows[1] = scene.Windows[0]
		}
		result, err := ScanFile(scene, func(Quote) error {
			if kind == "sink" {
				return errors.New("消費者中断")
			}
			return nil
		})
		if err == nil || result.Success {
			t.Fatal("不正又は中断を成功化", kind)
		}
	}
}

// ----------------------------------------
// TestAllAcceptedDepths116 は窓外でも採用候補の10深度型を省略しないことを確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。窓外のBuy10数量型エラーはRaw全体の不成功です。
func TestAllAcceptedDepths116(t *testing.T) {
	scene, _, rows := fixture116(t, "2026-09-21_Day")
	rows[3]["Buy10"] = map[string]any{"Price": 100, "Qty": "壊れた数量"}
	scene.Raw, scene.RawBytes = writeRaw116(t, rows)
	result, err := ScanFile(scene, func(Quote) error { return nil })
	if err == nil || result.Success {
		t.Fatal("窓外の採用候補の深度型を省略")
	}
}

// ----------------------------------------
// TestGzipAndContractFailure116 はCRC/途中EOFと除外行の別Symbol混入も不成功にします。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。流れた暫定Quoteを成功終了の代わりにはしません。
func TestGzipAndContractFailure116(t *testing.T) {
	for _, kind := range []string{"truncated", "CRC", "contract"} {
		scene, _, rows := fixture116(t, "2026-09-21_Day")
		if kind == "contract" {
			rows[0]["Symbol"] = "別限月"
			scene.Raw, scene.RawBytes = writeRaw116(t, rows)
		} else {
			body, err := os.ReadFile(scene.Raw.Path)
			if err != nil {
				t.Fatal(err)
			}
			if kind == "truncated" {
				body = body[:len(body)-6]
			} else {
				body[len(body)-5] ^= 1
			}
			if err = os.WriteFile(scene.Raw.Path, body, 0600); err != nil {
				t.Fatal(err)
			}
			scene.Raw.SHA256, err = Digest(scene.Raw.Path)
			if err != nil {
				t.Fatal(err)
			}
			scene.RawBytes = int64(len(body))
		}
		result, err := ScanFile(scene, func(Quote) error { return nil })
		if err == nil || result.Success {
			t.Fatal("gzip又は限月不正を成功化", kind)
		}
	}
}
