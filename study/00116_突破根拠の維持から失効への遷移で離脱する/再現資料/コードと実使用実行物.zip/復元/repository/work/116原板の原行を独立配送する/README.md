# 116のNK225原板配送器

保有根拠の独立Python監査へ、実保有窓の和集合に入る採用原行をpipeで渡す。金融演算・Source戦略・Goライフ状態・新規/仮想約定は実行しない。原板全件を別ファイルへ保存しない。独立Pythonが全正常Rawの最初性を検査するための入力層であり、**Reader成功だけではライフ発生漏れ・初回性の成功を主張しない**。

moduleは `github.com/masayoshi4649/SessionTradeExecuter/rawdelivery116`。元113Readerの停止・コードを認証し、変更前にreader.go/types.goを同bytesコピーした。旧113・Source111・Actor116等の固定物は変更しない。

## 公開APIと配送

- `ScanFile(scene Scene,sink Sink) (Summary,error)`：人工又はRoot認証後の一場を一走査し、保有窓内の採用Quoteを逐次渡す。`Sink=func(Quote)error`。消費者のエラーは直ちに不成功。
- `Prepare(condition FileRef,metadataOnly bool) (Plan,error)`：Root要求と自己停止を認証。実行時だけ上流金融/独立成功metadataを認証する。Rawはこの段階では開かない。
- `RunStream(condition,session,out,rootAuthorized,writer)`：Rootの固定許可と補助CLI許可の両方、新規Summary先、上流成功を満たしてから一場を配送する。

出力はstdout JSONL。保有窓内の全採用行を、正常/異常BBOとも省略せず送る。同秒の異なるIndex/物理行を保持する。

```json
{"kind":"quote","quote":{"clock":"元CurrentPriceTime文字列","time":0,"index":0,"source_line":1,"last":100,"bid":99,"ask":101,"quote_ok":true}}
```

全Raw EOF、圧縮SHA、前後stat、同pathのファイル同一性、限月、Source品質、Source配送総数、全保有窓の始終Quote/Index/連続件数を照合した場合だけ、最後に `{"kind":"summary",...Summary,"condition":FileRef,"summary_file":FileRef}` を1件送る。途中Quoteは終了前の暫定入力であり、消費側も成功summaryと正常終了の双方を受けるまで監査全体を成功化しない。切断・中断・差異では成功summaryを送らない。

Summary用の新規folderへ `配送の確認.json` だけを保存する。エラー時は `不完了.json` とする。既存folderへは書かない。保存後のsummary配送が切れた場合もCLIは失敗し、不完了を別記する。Reader証拠ファイル単独は消費側の完了証明にならない。

## Sourceの採用とIndex

旧113の `finite/normal/equalQuote/decodeRow` の関数本文を変更せず派生する。物理行は1始まり、SourceIndexは0始まり。窓外も、Symbol・価格時計・Lastと採用候補行の全10深度Price/Qty型を同じ順で検査する。窓先頭でIndexを0へ戻さない。除外行は元Sourceと同じく深度検査へ進まない。

Source111の対応は `input.go:readBoards` → `replay.go:replayInput` のCutoff → `Features.OnBoard` の `Counts[Reference]`。この範囲には `SourceAcceptedRow` という別の公開関数はなく、下記の採用とカウンタで対応する。

|段階|規則と照合|
|---|---|
|時計|CurrentPriceTimeのRFC3339Nano、`float64(UnixNano)/1e9`。場外・直前採用正Lastからの逆行を除外。同時刻は採用。|
|Last|正の有限CurrentPriceだけ採用。時計が新しいLast0行でpreviousを進めない。JSONの非有限/型崩れは元同様エラー。|
|板|全採用候補のBuy/Sell1〜10のPrice/Qty型を検査。Bid/Ask有限・Bid>0・Ask>BidだけQuoteOK真。数量を正常条件へ追加しない。異常BBOも正Lastなら採用Indexを進める。|
|Cutoff|SourceのreadBoards採用・品質はCutoff後も形成し、配送は `Time<Cutoff` だけ。Cutoff0は制限なし。|
|Index|元Featuresのカウンタは市場別なので、TOPIXの間に入る行でNK225 Indexは増えない。このReaderはNK225だけを扱う。|
|品質|旧Readerのclock_missing+clock_invalidをSourceのclock_missingへ合算。他のSource.RawQuality値とcontractsも全数照合。|

生Rawの累積High/Low、受信時計、約定価格を代用しない。元CurrentPriceTime文字列も返し、float64の時刻が同じでも別原行を失わない。圧縮SHAはgzip読取と同時に計算し、Rawを指紋用に再走査しない。

## Root固定要求

`Fixed` の実型はfixed.go、`Scene/Window/Quote/SourceQuality` はtypes.goに置く。

- `version=1, trial=116, fixed=true, raw_read_authorized=true`。
- `policy="NK225_source_rows_lifecycle116_v1"`, `stage="first2"` 又は `"full70"`。first2は09/21日夜の2場、full70は70場。場IDは既知期間09/21〜11/06のDay/Nightだけで、11/09を受け付けない。
- `reader_stop:FileRef`, `executable:FileRef`, `code_sha256:{絶対path:sha}`。code mapは自己停止の所有+全固定コード+Reader停止自身に一致させる。
- `refs` の必須5参照：`financial_condition`, `financial_completion`, `independent_result`, `independent_check`, `lifecycle_audit_stop`。Rootは成功した同stageの実参照で固定する。
- `scenes:Scene[]`。一場に `session,reference="NK225",contract,start,end,cutoff,raw:FileRef,raw_bytes,expected_source_rows,expected_source_quality,windows`。
- `expected_source_quality` はSource111.RawQualityの `lines,clock_missing,outside,backward,bad_last,bad_quote,accepted,contracts` 全field。`expected_source_rows` はCutoffを反映したNative.Actual.Counts.Rows。
- `windows:[{window_id,start_quote,end_quote}]` は監視適格XC/XQの実保有窓を先にマージした非重複和集合。物理行と採用Indexの昇順、両端inclusive。Quoteのclock文字列だけ省略可、残りは実保存値へ全照合。閉鎖原行も配送し、Python側でafter_source n0を評価しない。

上流の金融条件fixed/trial、金融完了success/trial/stage/sessions/books=36N/unchanged/condition_sha256を認証する。独立result/checkは成功/試行/stage/場数/会計数/前後不変、両金融SHA/独立ライフ停止SHA、両者のRoot保存要求SHAの一致を認証する。独立ライフ停止は成功/試行/停止を確認する。保存点監査成功と全Raw監査の範囲を合成して偽装しない。

## コマンド

ビルド：

```powershell
go test -count=1 ./...
go vet ./...
go build -o 原板配送.exe ./cmd/raw
```

Rootが実参照と新要求SHAを固定してから：

```powershell
原板配送.exe --request <Root要求の絶対path> --sha <SHA> --metadata-only
原板配送.exe --request <同要求> --sha <SHA> --session 2026-09-21_Day --out <既存親配下の新規folder> --root-authorized
```

実streamのstdoutは独立Pythonへpipeする。全Quoteを恒久ファイルへリダイレクトしない。`--root-authorized` 単独で読取許可を作れず、要求内の固定許可も必須。

metadata-onlyはRawのopen/stat/SHAと上流refsの本文を読まない。確認範囲はRoot要求の形式・Scene境界・自己owned停止/コード/exeだけで、上流成功の同条件認証は実行時に行う。人工用の自己停止器具は市場成功証拠へ使わない。

## 人工と限界

窓前の時計欠落/不正/場外、Last0がpreviousを進めないこと、同秒別行、異常BBO、Cutoff後の品質、空和集合、窓外10深度型崩れ、境界Index/時刻/価格/SHA/size/品質/総数の破壊、sink切断、Root許可/上流同条件破壊、metadata-only未読、既存出力拒否を手製gzipで検査する。旧113Readerとの全採用Quote/品質比較も一時人工だけで行う。

本作業では自然Raw・新市場Native・損益CSV・価格CSV・11/09を読まない。Readerは生原行配送と同体を検査し、技法指標の再計算・金融会計・利益率・ライフ最初性の合否はPython側の別証拠へ残す。研究目標達成・採用を判定しない。
