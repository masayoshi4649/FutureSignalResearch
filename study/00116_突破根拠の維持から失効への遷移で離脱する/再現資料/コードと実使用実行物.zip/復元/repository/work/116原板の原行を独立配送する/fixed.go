package rawdelivery116

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"regexp"
	"strings"
	"time"
)

const Policy = "NK225_source_rows_lifecycle116_v1"

type Fixed struct {
	Version           int                `json:"version"`
	Trial             int                `json:"trial"`
	Fixed             bool               `json:"fixed"`
	RawReadAuthorized bool               `json:"raw_read_authorized"`
	Policy            string             `json:"policy"`
	Stage             string             `json:"stage"`
	ReaderStop        FileRef            `json:"reader_stop"`
	Executable        FileRef            `json:"executable"`
	CodeSHA256        map[string]string  `json:"code_sha256"`
	Refs              map[string]FileRef `json:"refs"`
	Scenes            []Scene            `json:"scenes"`
}

type Stop struct {
	Success      bool              `json:"成功"`
	Stopped      bool              `json:"停止"`
	MarketBefore bool              `json:"市場前"`
	Trial        int               `json:"試行"`
	Owned        map[string]string `json:"所有コードSHA256"`
	AllCode      map[string]string `json:"全固定コードSHA256"`
	Executable   FileRef           `json:"実行物"`
}

type Plan struct {
	Condition    FileRef
	Fixed        Fixed
	Before       map[string]string
	MetadataOnly bool
}

// validRef は本文やstatを読まず絶対pathと小文字SHA形式だけを確認します。
//
// 引数: ref(FileRef)は固定入力参照です。
// 返り値: boolは形式が正しい場合に真です。
func validRef(ref FileRef) bool {
	return filepath.IsAbs(ref.Path) && regexp.MustCompile("^[a-f0-9]{64}$").MatchString(ref.SHA256)
}

// ----------------------------------------
// Digest は小metadata・コード・exeの全bytes指紋を返します。Rawには使用しません。
//
// 引数: path(string)は明示小入力です。
// 返り値: string/errorはSHA256又は読取失敗です。
func Digest(path string) (string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:]), nil
}

// ----------------------------------------
// readRef は小入力のSHAを本文利用前に認証します。
//
// 引数: ref(FileRef)、target(any)、before(map[string]string)は位置・復元先・指紋記録先です。
// 返り値: errorは不正形式・指紋差・復元差です。
func readRef(ref FileRef, target any, before map[string]string) error {
	if !validRef(ref) {
		return fmt.Errorf("絶対参照と小文字SHAが必要")
	}
	actual, err := Digest(ref.Path)
	if err != nil || actual != ref.SHA256 {
		return fmt.Errorf("小入力SHA差:%s:%v", ref.Path, err)
	}
	if target != nil {
		data, err := os.ReadFile(ref.Path)
		if err != nil {
			return err
		}
		if err = json.Unmarshal(data, target); err != nil {
			return err
		}
	}
	before[ref.Path] = ref.SHA256
	return nil
}

// ----------------------------------------
// sessionTimes は今回の既知期間だけのJST Day/Nightを再構成します。
//
// 引数: id(string)は場IDです。
// 返り値: start/end(float64)/errorは場境界又は11月09等の対象外です。
func sessionTimes(id string) (float64, float64, error) {
	parts := strings.Split(id, "_")
	if len(parts) != 2 || parts[0] < "2026-09-21" || parts[0] > "2026-11-06" {
		return 0, 0, fmt.Errorf("許可期間外の場ID")
	}
	day, err := time.ParseInLocation("2006-01-02", parts[0], time.FixedZone("JST", 9*3600))
	if err != nil {
		return 0, 0, err
	}
	start, end := day.Add(8*time.Hour+45*time.Minute), day.Add(15*time.Hour+45*time.Minute)
	if parts[1] == "Night" {
		start = day.Add(17 * time.Hour)
		end = day.AddDate(0, 0, 1).Add(6 * time.Hour)
	} else if parts[1] != "Day" {
		return 0, 0, fmt.Errorf("場種不正")
	}
	return float64(start.Unix()), float64(end.Unix()), nil
}

// ----------------------------------------
// Prepare はRoot固定要求と自己停止を認証し、実行時だけ上流の成功metadataを認証します。
//
// 引数: condition(FileRef)、metadataOnly(bool)はRoot要求と本文未走査モードです。
// 返り値: Plan/errorはRaw未開封の計画です。metadataOnlyではRawも上流refsも読みません。
func Prepare(condition FileRef, metadataOnly bool) (Plan, error) {
	p := Plan{Condition: condition, Before: map[string]string{}, MetadataOnly: metadataOnly}
	if err := readRef(condition, &p.Fixed, p.Before); err != nil {
		return p, err
	}
	f := p.Fixed
	if f.Version != 1 || f.Trial != 116 || !f.Fixed || !f.RawReadAuthorized || f.Policy != Policy || (f.Stage != "first2" && f.Stage != "full70") {
		return p, fmt.Errorf("Rootの116原板読取固定要求が必要")
	}
	if f.Stage == "first2" && len(f.Scenes) != 2 || f.Stage == "full70" && len(f.Scenes) != 70 {
		return p, fmt.Errorf("対象stage場数差")
	}
	for _, key := range []string{"financial_condition", "financial_completion", "independent_result", "independent_check", "lifecycle_audit_stop"} {
		if !validRef(f.Refs[key]) {
			return p, fmt.Errorf("必要な上流成功Ref形式なし:%s", key)
		}
	}
	seen := map[string]bool{}
	for i, scene := range f.Scenes {
		start, end, err := sessionTimes(scene.Session)
		if err != nil || scene.Start != start || scene.End != end || seen[scene.Session] {
			return p, fmt.Errorf("場のJST境界又は重複差")
		}
		if f.Stage == "first2" && scene.Session != []string{"2026-09-21_Day", "2026-09-21_Night"}[i] {
			return p, fmt.Errorf("先頭2場差")
		}
		if err = validateScene(scene); err != nil {
			return p, err
		}
		seen[scene.Session] = true
		if f.ReaderStop.Path == scene.Raw.Path || f.Executable.Path == scene.Raw.Path {
			return p, fmt.Errorf("RawとReader停止/実行物の位置が重複")
		}
		if _, exists := f.CodeSHA256[scene.Raw.Path]; exists {
			return p, fmt.Errorf("Rawをコードとして走査しない")
		}
		for _, ref := range f.Refs {
			if ref.Path == scene.Raw.Path {
				return p, fmt.Errorf("Rawを小metadataとして二重認証しない")
			}
		}
	}
	var stop Stop
	if err := readRef(f.ReaderStop, &stop, p.Before); err != nil {
		return p, err
	}
	if !stop.Success || !stop.Stopped || !stop.MarketBefore || stop.Trial != 116 || stop.Executable != f.Executable {
		return p, fmt.Errorf("自己Reader停止/実行物差")
	}
	expected := map[string]string{}
	for _, group := range []map[string]string{stop.Owned, stop.AllCode} {
		for path, digest := range group {
			if prior, exists := expected[path]; exists && prior != digest {
				return p, fmt.Errorf("停止コードmap衝突")
			}
			expected[path] = digest
		}
	}
	expected[f.ReaderStop.Path] = f.ReaderStop.SHA256
	if len(stop.Owned) == 0 || !reflect.DeepEqual(expected, f.CodeSHA256) {
		return p, fmt.Errorf("Root固定と自己停止コードmap差")
	}
	for path, digest := range expected {
		if err := readRef(FileRef{Path: path, SHA256: digest}, nil, p.Before); err != nil {
			return p, err
		}
	}
	if err := readRef(f.Executable, nil, p.Before); err != nil {
		return p, err
	}
	executable, err := os.Executable()
	if err != nil {
		return p, err
	}
	actual, err := Digest(executable)
	if err != nil || actual != f.Executable.SHA256 {
		return p, fmt.Errorf("実行中exeのSHA差")
	}
	if metadataOnly {
		return p, nil
	}
	// ----------------------------------------
	// 自然Rawの前に上流固定・金融完了・独立保存・ライフ監査停止の成功を認証します。
	values := map[string]map[string]json.RawMessage{}
	for key, ref := range f.Refs {
		var value map[string]json.RawMessage
		if err = readRef(ref, &value, p.Before); err != nil {
			return p, err
		}
		values[key] = value
	}
	var financialFixed bool
	var trial int
	if json.Unmarshal(values["financial_condition"]["fixed"], &financialFixed) != nil || !financialFixed || json.Unmarshal(values["financial_condition"]["trial"], &trial) != nil || trial != 116 {
		return p, fmt.Errorf("上流116金融固定が必要")
	}
	var success bool
	var conditionSHA string
	var sessions int
	var books int
	var stage string
	var unchanged bool
	if json.Unmarshal(values["financial_completion"]["success"], &success) != nil || !success || json.Unmarshal(values["financial_completion"]["trial"], &trial) != nil || trial != 116 || json.Unmarshal(values["financial_completion"]["sessions"], &sessions) != nil || sessions != len(f.Scenes) || json.Unmarshal(values["financial_completion"]["books"], &books) != nil || books != 36*sessions || json.Unmarshal(values["financial_completion"]["stage"], &stage) != nil || stage != f.Stage || json.Unmarshal(values["financial_completion"]["unchanged"], &unchanged) != nil || !unchanged || json.Unmarshal(values["financial_completion"]["condition_sha256"], &conditionSHA) != nil || conditionSHA != f.Refs["financial_condition"].SHA256 {
		return p, fmt.Errorf("同条件/同stage116金融完了が必要")
	}
	for _, key := range []string{"independent_result", "independent_check", "lifecycle_audit_stop"} {
		value := values[key]
		if json.Unmarshal(value["成功"], &success) != nil || !success || json.Unmarshal(value["試行"], &trial) != nil || trial != 116 {
			return p, fmt.Errorf("116独立成功metadataが必要:%s", key)
		}
	}
	var stopped bool
	if json.Unmarshal(values["lifecycle_audit_stop"]["停止"], &stopped) != nil || !stopped {
		return p, fmt.Errorf("ライフ独立監査の停止が必要")
	}
	var saveRequestSHA string
	for _, key := range []string{"independent_result", "independent_check"} {
		value := values[key]
		var count, account int
		if json.Unmarshal(value["stage"], &stage) != nil || stage != f.Stage || json.Unmarshal(value["場数"], &count) != nil || count != sessions || json.Unmarshal(value["会計数"], &account) != nil || account != books || json.Unmarshal(value["前後不変"], &unchanged) != nil || !unchanged {
			return p, fmt.Errorf("独立保存のstage/全36N/不変差:%s", key)
		}
		for field, expected := range map[string]string{"金融条件SHA256": f.Refs["financial_condition"].SHA256, "金融完了SHA256": f.Refs["financial_completion"].SHA256, "独立ライフ停止SHA256": f.Refs["lifecycle_audit_stop"].SHA256} {
			var actual string
			if json.Unmarshal(value[field], &actual) != nil || actual != expected {
				return p, fmt.Errorf("独立保存の上流結合差:%s/%s", key, field)
			}
		}
		var actualRequest string
		if json.Unmarshal(value["Root保存要求SHA256"], &actualRequest) != nil || !regexp.MustCompile("^[a-f0-9]{64}$").MatchString(actualRequest) || saveRequestSHA != "" && saveRequestSHA != actualRequest {
			return p, fmt.Errorf("結果/保存検算のRoot要求差")
		}
		saveRequestSHA = actualRequest
	}
	return p, nil
}

// ----------------------------------------
// VerifyInputs は小入力だけの前後不変を認証します。Rawは走査内SHAとstatで認証済みです。
//
// 引数: before(map[string]string)は実行前の小入力指紋です。
// 返り値: errorは終了時の差です。
func VerifyInputs(before map[string]string) error {
	for path, expected := range before {
		actual, err := Digest(path)
		if err != nil || actual != expected {
			return fmt.Errorf("小入力前後差:%s", path)
		}
	}
	return nil
}
