"""記述診断の同入口判定と公表asofを小さな人工だけで確認する。"""
from copy import deepcopy
import unittest

import 調べる as X


def publication(index: int,identifier: str,at: int=100) -> dict:
    """
    機能: 未来参照検査だけの最小5分公表を作る。
    引数: index/at(int)、identifier(str)。返り値: dict。市場や既指標の期待値ではない。
    """
    no={'known':False};f={'id':identifier,'width_seconds':300,'record_ordinal':index+1,'start':0,'end':90,'available_at':95,'price_known':True,'ohlc':{'open':10,'high':11,'low':9,'close':10},'volume_known':False,'volume':0,'technical':{},'prior_high':no,'prior_low':no,'new_high':no,'new_low':no}
    return {'stamp':{'time':at,'index':index,'source_line':index+1},'frame':{'frame':f,'dmi':{},'structure':{'known':False,'high':0,'low':0,'refs':[]}}}


class Tests(unittest.TestCase):
    """取引を同SourceIDだけで対応せず、公表を同時計だけで遡及しない。"""

    def test_entry_identity_covers_physical_quote_price_and_size(self):
        """
        機能: 同Source出生でも取得原行・価格・量が異なれば同入口でない。
        引数: self(Tests)。返り値: None。
        """
        p={'source':{'method':'M','signal_id':'S'},'side':1,'entry_price':10,'initial_quantity':2,'entry_quote':{'time':100,'index':4,'source_line':5}}
        for field in ('index','price','quantity','method'):
            b=deepcopy(p)
            if field=='index':b['entry_quote']['index']+=1
            elif field=='price':b['entry_price']+=1
            elif field=='quantity':b['initial_quantity']+=1
            else:b['source']['method']='別M'
            self.assertNotEqual(X.entry_identity(p),X.entry_identity(b))

    def test_same_second_future_index_excluded_and_batch_latest(self):
        """
        機能: 同時刻の未来Indexを除外し、同Rawの最後の公表を選ぶ。
        引数: self(Tests)。返り値: None。
        """
        n={'actual':{'entry_publications':[publication(2,'同Raw中間'),publication(2,'同Raw最後'),publication(3,'未来同秒')]}};q={'time':100,'index':2};p={'side':1,'entry_quote':{'time':80},'lifecycle116':{'initial':{'entry':{'birth':{'values':{'boundary':10}}}}}}
        out=X.published_context(n,q,p);self.assertEqual(out['300']['frame_id'],'同Raw最後');self.assertIsNone(out['300']['volume'])

    def test_future_clock_and_invalid_available_rejected(self):
        """
        機能: 過去Indexに偽装した未来時計と未来Availableを拒否する。
        引数: self(Tests)。返り値: None。
        """
        q={'time':100,'index':2};p={'side':1,'entry_quote':{'time':80},'lifecycle116':{'initial':{'entry':{'birth':{'values':{'boundary':10}}}}}}
        for mode in ('clock','available'):
            pub=publication(2,'偽装')
            if mode=='clock':pub['stamp']['time']=101
            else:pub['frame']['frame']['available_at']=101
            with self.subTest(mode=mode),self.assertRaises(ValueError):X.published_context({'actual':{'entry_publications':[pub]}},q,p)


if __name__=='__main__':unittest.main(verbosity=2)
