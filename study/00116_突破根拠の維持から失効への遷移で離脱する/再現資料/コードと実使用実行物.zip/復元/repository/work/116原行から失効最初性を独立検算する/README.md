# 実保有Rawの初回成立を別に確認する

2026-11-10。116の金融F1、純Go、Source、Actor、5/15/30公開器、P100、保存点監査は変更しない。このフォルダは新規の独立Python consumerであり、Rootの別固定要求まで自然Native・Raw・価格CSV・11月09は開かない。人工は手製の純8系列・Core失効2系列と、小さな手製gzipだけで行う。

## 何を証明するか

監視適格な実XC/XQ玉の実取得〜最終返済をinclusiveに含む窓の和集合だけを対象に、停止GoReader82806…から来る全採用行を省略せず使う。GoReaderは窓外も含めて1場1passでSource採用Index・物理行・価格時計・10深度型・圧縮SHA・品質を確認する。正常/異常BBOの両方を配送する。

Pythonは保存Activationをlifeの無効化にそのまま使わない。実fillのq0・実R/nと正常返済BBOから `W=R+n*(100*side*(P−E)−77−200*S)`、`W>=q0*10000` のH100初回到達をpre_fill/after_source別に再形成し、Activeを単調に保持する。

1. 公表列は同Rawの全5/15/30公表を揃えた最新だけをasof接合する。中間の古い5分公表を遡及評価しない。使用値/鮮度/取得後End・RecordOrdinal・生BBOを毎行検査する。
2. Native registry/取消はpre-fillより前だが、Actualの既存n/Rは変わらない。pre_fill H100を旧実所有で評価し、全当行actual fillsを保存順で適用する。Source仮想保有をActualへ使わない。
3. Source予約と当行P100自己予約の後、当行life予約の前のrを作る。lifeの期待未予約量が正なら同じRawの実要求が必要。実life予約を先に注入して要求漏れを隠さない。
4. XCの確定Close、XQの全正常Rawの返済BBOを別々に使い、初arm/警戒/鎖切り/ラッチを再形成する。全保存点のBefore/Input/After/Decision、最終保有純状態、各counterと照合する。
5. 全実返済要求後、`Index>要求Index`・正常BBO・価格時計>=要求時刻+Dを初めて満たすRawと実fillを照合する。初ラッチ、初要求、初life実fillを別項目で残す。

最終返済Rawはpre_fillでH100へ到達し得るため含める。全fill後n0ならlifeを呼ばずFinalOwnershipだけを照合する。残n>0の部分返済は実R/nで継続する。予約はWから差し引かない。

## 範囲の分離

新型保存停止は会計397ee…/P6c1e…/lifeec1f…。当該実Root保存要求と結果/確認の全SHAを必須にする。保存点の1Advance exactと、ここでの全Raw初回性を別の証拠にする。

X0と監視不適格実玉は対象外として別計数する。P100の全ATR幅/峰/床更新/床hitをRawで再形成しない。5/15/30技法数値をRawから作り直さず固定公表を使うため、価格足/DMIの独立監査とは別範囲。窓前の新規注文の最初正常fillや実mini市場の約定を証明しない。実退出後の価格、仮想利益、MFE回収、機会損失は作らない。

最終の成功summaryとReader process exit0の**両方**が必須。Readerが保存したJSONだけでは成功にしない。切断/欠落/不一致なら不完了とし、矛盾発生後の仮想取引を続行しない。全Quoteは恒久ファイルに保存しない。

## 人工とRoot手順

17主人工：H100手計算8、原行状態/全手製Core/破壊6、実上流metadata2、停止GoReader実pipe1。全48純State/Decisionを独立照合し、手製72会計の監視適格48実玉を全原行で検査する。実Readerpipeは131手製Rawだけを一時gzipへ生成し、実市場成功を人工上流の根拠へ流用しない。

停止前の確認は `検査して停止する.py --check-output <新規絶対folder>`。Rootが確認をレビュー後に `--stop --review <確認JSON> --review-sha <SHA>` で初回停止する。実Root金融・保存成功の小metadataをそのまま人工の正例に使い、boolと整数件数のschema差も停止前に確認する。

RootはまずGoReader用の別固定を作る。その `scenes` は監視適格実XC/XQ全建玉の窓の和集合、同Native.SourceのRaw指紋/SourceQuality、Actual.Counts.Rowsへ結ぶ。consumerは実Nativeを解禁後に窓を独立に作り直して全値比較する。初回はfirst2必須、全70は性能/対象を見て別Root固定へ進む。

```powershell
python .\要求ひな型を作る.py --reader-request <RootReader絶対JSON> --reader-sha <SHA> --save-request <実保存要求絶対JSON> --save-sha <SHA> --output <新規絶対JSON>
```

ひな型はfixed/Raw/Native許可=false。Rootが実参照を確認した新固定後だけ、1場ずつ次を行う。

```powershell
python .\検算する.py --request <Rootconsumer絶対JSON> --sha <SHA> --session 2026-09-21_Day --out <新規絶対folder> --metadata-only
python .\検算する.py --request <同要求> --sha <同SHA> --session 2026-09-21_Day --out <同じ未生成folder>
```

metadata-onlyは新旧Native実物SHAやRawのopen/statへ進まない。上流の同F1/同stage全36N/新型保存停止/同実保存要求、consumer自体・実Reader exe/全コード閉包までを認証する。実streamはPythonがReader子processを起動してstdoutを読み、最終成功だけを小JSONへ保存する。
