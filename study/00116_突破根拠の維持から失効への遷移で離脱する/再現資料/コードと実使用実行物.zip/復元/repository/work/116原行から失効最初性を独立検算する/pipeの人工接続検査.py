"""停止GoReader→Python消費側の実pipeを、小さな手製gzipだけで一体確認する。"""
from datetime import datetime,timezone,timedelta
from pathlib import Path
import gzip
import json
import subprocess
import tempfile
import unittest

from 独立参照 import A,S
from 原行の人工検査 import read,CORE,CORE_SHA,quotes
from 原行の最初性 import SceneAudit
from 検算する import normalized_windows
import 実行の入力ゲート as G

HERE=Path(__file__).resolve().parent


def write(path: Path,value: dict) -> dict:
    """
    機能: 人工だけのmetadataを一時先へ保存する。
    引数: path(Path)、value(dict)。返り値: dictは絶対path/sha256。
    """
    path.write_text(json.dumps(value,ensure_ascii=False,default=S.BASE.serial)+'\n',encoding='utf-8');return {'path':str(path),'sha256':S.digest(path)}


def exercise(folder: Path,native: dict,side: int) -> dict:
    """
    機能: 131行の手製Rawを実停止Readerへ渡し、全pub/所有付きCore人工へ接合する。
    引数: folder(Path)、native(dict)、side(int)。返り値: dictは人工の小証拠。自然Rawは開かない。
    """
    audit=SceneAudit(native);raw=folder/'手製だけ.json.gz';all_rows=quotes(native,side);jst=timezone(timedelta(hours=9));symbol='人工限月';encoded=[]
    for q in all_rows:
        row={'Symbol':symbol,'CurrentPriceTime':datetime.fromtimestamp(q['time'],jst).isoformat(),'CurrentPrice':q['last']}
        for depth in range(1,11):row['Buy'+str(depth)]={'Price':q['bid']-depth+1,'Qty':1};row['Sell'+str(depth)]={'Price':q['ask']+depth-1,'Qty':1}
        encoded.append(json.dumps(row,ensure_ascii=False)+'\n')
    raw.write_bytes(gzip.compress(''.join(encoded).encode('utf-8'),mtime=0));rawref={'path':str(raw),'sha256':S.digest(raw)}
    ranges=normalized_windows([{'start_quote':m.p['entry_quote'],'end_quote':m.p['closed_quote']} for m in audit.monitors]);windows=[{'window_id':str(i),'start_quote':a,'end_quote':b} for i,(a,b) in enumerate(ranges)]
    quality={'lines':131,'clock_missing':0,'outside':0,'backward':0,'bad_last':0,'bad_quote':0,'accepted':131,'contracts':[symbol]};start=native['actual']['scope']['session']['start'];end=native['actual']['scope']['session']['end']
    scene={'session':'2026-09-21_Day','reference':'NK225','contract':symbol,'start':start,'end':end,'cutoff':0,'raw':rawref,'raw_bytes':raw.stat().st_size,'expected_source_rows':131,'expected_source_quality':quality,'windows':windows}
    # ----------------------------------------
    # 上流metadataは明示人工。実市場完了を手製Rawの根拠へ流用しない。
    condition=write(folder/'金融条件の人工.json',{'trial':116,'fixed':True,'人工':True})
    completion=write(folder/'金融完了の人工.json',{'trial':116,'success':True,'人工':True,'stage':'first2','sessions':2,'books':72,'unchanged':True,'condition_sha256':condition['sha256']})
    independent={'試行':116,'成功':True,'人工':True,'stage':'first2','場数':2,'会計数':72,'前後不変':True,'金融条件SHA256':condition['sha256'],'金融完了SHA256':completion['sha256'],'独立ライフ停止SHA256':G.STOPS['ライフ停止.json'],'Root保存要求SHA256':'a'*64}
    result=write(folder/'保存結果の人工.json',independent);check=write(folder/'保存確認の人工.json',independent);stop=S.load(G.READER)
    night={**scene,'session':'2026-09-21_Night','start':start+8*3600+15*60,'end':start+21*3600+15*60,'windows':[]}
    fixed={'version':1,'trial':116,'fixed':True,'raw_read_authorized':True,'人工':True,'policy':'NK225_source_rows_lifecycle116_v1','stage':'first2','reader_stop':{'path':str(G.READER),'sha256':G.READER_SHA},'executable':stop['実行物'],'code_sha256':{**stop['全固定コードSHA256'],**stop['所有コードSHA256'],str(G.READER):G.READER_SHA},'refs':{'financial_condition':condition,'financial_completion':completion,'independent_result':result,'independent_check':check,'lifecycle_audit_stop':{'path':str(G.SAVED/'ライフ停止.json'),'sha256':G.STOPS['ライフ停止.json']}},'scenes':[scene,night]}
    ref=write(folder/'人工Reader要求.json',fixed);command=[fixed['executable']['path'],'--request',ref['path'],'--sha',ref['sha256'],'--session',scene['session'],'--out',str(folder/'Reader結果'),'--root-authorized'];summary=None
    with (folder/'stderr.log').open('w',encoding='utf-8') as err:
        child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=err,text=True,encoding='utf-8')
        try:
            for line in child.stdout:
                value=json.loads(line,parse_float=A.BASE.Decimal);A.need(summary is None,'人工でもsummaryは最後')
                if value['kind']=='quote':audit.observe(value['quote'])
                else:A.equal(value['kind'],'summary','人工pipe kind');summary=value
            child.stdout.close();code=child.wait()
        except BaseException:
            if child.poll() is None:child.terminate();child.wait()
            child.stdout.close()
            raise
    A.need(summary is not None,'実Reader人工の成功summary: '+(folder/'stderr.log').read_text(encoding='utf-8'));result=audit.finish(summary,code)
    A.equal(summary['actual_sha256'],rawref['sha256'],'手製原板の一走査SHA');A.equal(summary['quality']['source_delivered'],131,'131人工採用行');A.equal(summary['source_quality'],quality,'人工Source品質全値')
    return {'人工':True,'市場':False,'Reader停止':G.READER_SHA,'手製Raw行数':131,'手製Raw圧縮SHA':rawref['sha256'],'消費quote数':audit.rows,'監視適格実玉':result['監視適格実玉数'],'失効要求実玉':sum(p['初要求'] is not None for p in result['実玉']),'summaryとexit0':True,'Raw保存恒久複写':False}


class Tests(unittest.TestCase):
    """実pipeの人工接続一主。"""

    def test_stopped_reader_pipe_to_core_artificial(self):
        """
        機能: 停止Readerの実stdout/summary/exitをPythonへ接続する。
        引数: self(Tests)。返り値: None。自然市場の証明へ数えない。
        """
        value=read(CORE,CORE_SHA);native=value['results']['1']
        with tempfile.TemporaryDirectory(dir=HERE) as tmp:
            result=exercise(Path(tmp),native,1);self.assertEqual((result['監視適格実玉'],result['失効要求実玉']),(24,24))


if __name__=='__main__':unittest.main(verbosity=2)
