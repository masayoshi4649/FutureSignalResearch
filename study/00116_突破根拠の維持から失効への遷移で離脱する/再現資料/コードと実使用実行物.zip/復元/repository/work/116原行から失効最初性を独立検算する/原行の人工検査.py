"""自然Rawを開かず、純系列/手製Coreの全原行と破壊反例で最初性を検査する。"""
from copy import deepcopy
from decimal import Decimal
from pathlib import Path
import gzip
import hashlib
import json
import unittest

from 独立参照 import A,I
from ライフの原行状態 import Monitor
from 原行の最初性 import SceneAudit

ROOT=Path(__file__).resolve().parents[2]
PURE=ROOT/'work/116突破根拠の維持と失効/人工_接続前/ライフ系列.json'
PURE_SHA='1e3048779019cc59759b0cfdf8297faee94c3ffb621fa38e71a82aa476203284'
CORE=ROOT/'work/116保有根拠の連続比較/人工_失効と所有/Core失効人工.json.gz'
CORE_SHA='d93abd1795f3fac86fa099b0d2608207e946922ed8fcb3120b29f72826cb960b'


def read(path: Path,sha: str) -> dict:
    """
    機能: Rootが公開した手製値だけをSHA認証して読む。
    引数: path(Path)、sha(str)。返り値: dict。市場本文ではない。
    """
    b=path.read_bytes();A.equal(hashlib.sha256(b).hexdigest(),sha,'手製SHA');return json.loads(gzip.decompress(b) if path.suffix=='.gz' else b,parse_float=Decimal)


def quotes(native: dict,side: int) -> list:
    """
    機能: 手製Core失効器具の明示価格入力を、最初のSource出生を境に再構成する。
    引数: native(dict)、side(int)。返り値: list[dict]は人工131採用行。戦略や金融を再生しない。
    """
    birth=native['actual']['books']['A0_C0_D0']['positions'][0]['source']['birth_quote']['index'];start=native['actual']['scope']['session']['start'];locked=5*((30+birth)//5)+5;result=[]
    for index in range(131):
        move=locked if index>birth else 5*((30+index)//5)+5
        if index>=36:move-=50
        bid,ask=1000+move,1010+move
        if side<0:bid,ask=2000-ask,2000-bid
        result.append({'time':start+1800+index*60,'index':index,'source_line':index+1,'last':(bid+ask)/2,'bid':bid,'ask':ask,'quote_ok':True})
    return result


def deliver(native: dict,side: int,exit_code: int=0,omit: int|None=None) -> dict:
    """
    機能: 実監視窓の和集合を手製quoteから形成し、成功summary/exitを消費側へ渡す。
    引数: native(dict)、side/exit_code(int)、omit(int|None)。返り値: dictは人工の小結果。
    """
    audit=SceneAudit(native);rows=quotes(native,side);start=min(m.p['entry_quote']['index'] for m in audit.monitors);end=max(m.p['closed_quote']['index'] for m in audit.monitors);window=rows[start:end+1]
    for q in window:
        if q['index']!=omit:audit.observe(q)
    summary={'trial':116,'success':True,'session':native['actual']['scope']['session']['id'],'raw_passes':1,'source_index_verified':True,'source_quality_equal':True,'source_rows_equal':True,'all_ten_depths_checked':True,'streamed_rows':len(window),'financial_replay':False,'all_raw_rows_saved':False,'windows':[{'window':{'start_quote':window[0],'end_quote':window[-1]},'start_matched':True,'end_matched':True,'rows':len(window)}]}
    return audit.finish(summary,exit_code)


class Tests(unittest.TestCase):
    """純算術と全手製Raw列の接合を別々に確認する。"""

    @classmethod
    def setUpClass(cls):
        """
        機能: 人工8純系列/2Core系列だけを一度読む。
        引数: cls(type)。返り値: None。新市場NativeとRawは未読。
        """
        cls.pure=read(PURE,PURE_SHA);value=read(CORE,CORE_SHA);A.need(value['人工'] and not value['市場'] and not value['FAR自然生成'],'明示手製だけ');cls.core=value['results']

    def test_fast_state_matches_all48_pure_steps(self):
        """
        機能: 新原行機械を純Go8系列48評価の全Snapshot/Decisionへ照合する。
        引数: self(Tests)。返り値: None。Go関数は呼ばない。
        """
        total=0
        for case in self.pure['cases']:
            engine=Monitor(case['entry'],self.pure['definition']);I.compare(engine.snapshot(),case['initial_snapshot'],'Raw機械初期')
            for step in case['steps']:
                I.compare(engine.snapshot(),step['before_snapshot'],'Raw機械直前');inp=step['input'];after=step['after_snapshot'];d=step['decision'];names=[]
                if d['armed_now']:names.append('last_arming')
                if d['chain_broken_now']:names.append('last_chain_break')
                if d['invalidated_now']:names.append('invalidation')
                if names:w=after[names[0]];stamp=w['five_delivered'];known=w['five_delivery_line_known']
                else:stamp={'time':0,'index':0,'source_line':0};known=False
                actual=engine.advance(inp,stamp,known);I.compare(actual,d,'Raw機械48票');I.compare(engine.snapshot(),after,'Raw機械48状態');total+=1
        self.assertEqual(total,48)

    def test_all_raw72_core_lifecycle(self):
        """
        機能: 実公開器/凍結入口/実所有を持つ手製72冊の全保有原行から48新失効を照合する。
        引数: self(Tests)。返り値: None。Readerの自然Raw品質証明ではない。
        """
        total=latches=requests=0
        for side,native in self.core.items():
            result=deliver(native,int(side));total+=result['監視適格実玉数']
            for p in result['実玉']:latches+=p['初ラッチ'] is not None;requests+=p['初要求'] is not None
        self.assertEqual((total,latches,requests),(48,48,48))

    def test_dropped_raw_is_rejected(self):
        """
        機能: 正常/異常を問わず採用原行の省略を拒否する。
        引数: self(Tests)。返り値: None。
        """
        side,native=next(iter(self.core.items()))
        with self.assertRaises(ValueError):deliver(native,int(side),omit=10)

    def test_exit_nonzero_is_not_success(self):
        """
        機能: 成功summaryが見えてもReader exit非0なら成功にしない。
        引数: self(Tests)。返り値: None。
        """
        side,native=next(iter(self.core.items()))
        with self.assertRaises(ValueError):deliver(native,int(side),exit_code=1)

    def test_empty_window_missing_or_duplicate_summary(self):
        """
        機能: 監視適格0でも終了を検査し、summary欠落/二重完了を成功にしない。
        引数: self(Tests)。返り値: None。
        """
        native={'actual':{'entry_publications':[],'entry_gate_events':[],'books':{}}};a=SceneAudit(native)
        with self.assertRaises(ValueError):a.finish(None,0)
        summary={'trial':116,'success':True,'raw_passes':1,'source_index_verified':True,'source_quality_equal':True,'source_rows_equal':True,'all_ten_depths_checked':True,'streamed_rows':0,'financial_replay':False,'all_raw_rows_saved':False,'windows':[]}
        result=a.finish(summary,0);self.assertEqual(result['監視適格実玉数'],0)
        with self.assertRaises(ValueError):a.finish(summary,0)

    def test_missing_life_request_and_delayed_fill_rejected(self):
        """
        機能: 実life要求漏れと最初正常返済行の見逃しを、補完約定せず拒否する。
        引数: self(Tests)。返り値: None。
        """
        side,native=next(iter(self.core.items()))
        for mode in ('request','fill'):
            changed=deepcopy(native);book=changed['actual']['books']['T_XC_C0_D0'];p=book['positions'][0]
            if mode=='request':book['orders']=[o for o in book['orders'] if o.get('lifecycle_point') is None];p['lifecycle116']['requests']=[]
            else:
                fill=next(f for f in book['fills'] if f.get('lifecycle_exit',False));fill['quote']['index']+=1
            with self.subTest(mode=mode),self.assertRaises(ValueError):deliver(changed,int(side))


if __name__=='__main__':unittest.main(verbosity=2)
