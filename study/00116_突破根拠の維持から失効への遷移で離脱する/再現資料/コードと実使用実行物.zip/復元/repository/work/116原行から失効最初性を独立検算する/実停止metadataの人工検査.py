"""実Reader/Core/新型保存の小metadataをそのまま使い、Native/Rawを開く前にschemaを検査する。"""
from copy import deepcopy
from pathlib import Path
import json
import tempfile
import unittest

import 実行の入力ゲート as G

HERE=Path(__file__).resolve().parent


def ref(path: Path,sha: str|None=None) -> dict:
    """
    機能: 小metadataの絶対参照だけを作る。
    引数: path(Path)、sha(str|None)。返り値: dictはpath/sha256。Native/Rawには使わない。
    """
    return {'path':str(path.resolve()),'sha256':sha or G.S.digest(path)}


def write(path: Path,value: dict) -> dict:
    """
    機能: 明示人工のRoot未実行metadataを一時先へ保存する。
    引数: path(Path)、value(dict)。返り値: dictは新FileRef。
    """
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,default=G.S.BASE.serial)+'\n',encoding='utf-8');return ref(path)


def fixture(folder: Path) -> dict:
    """
    機能: 実上流小metadataへ人工の未実行Reader/consumer要求を接合する。
    引数: folder(Path)。返り値: dictは本文未読の計画材料。自然Native/Rawは参照文字列だけ。
    """
    root=G.ROOT;condition=ref(root/'work/116進行/F1_116金融条件.json',G.F1_SHA);completion=ref(root/'work/116金融F1/先頭2場/完了.json','4d221b6c3a84f403c027baf6d25cd7eceb307218c48e82c334341f7cf982d52b')
    result=ref(root/'work/116独立保存F1/先頭2場/結果.json','5b028964e5f6ea81603b97f6c699d6268017503c0ab07b332ac842a00bed9258');check=ref(root/'work/116独立保存F1/先頭2場/保存会計の確認.json','8e0ec039f9d7bf940a7c17a5c6b429309acf2ec2b864548d694d8d58ea04a594');save=ref(root/'work/116進行/first2_独立保存要求_未読件数補正.json','234d1decd9f80754cbe78b728990e5ab556a26cc32263c540752d63cc195c0c2')
    # ----------------------------------------
    # 以下は要求schemaだけの人工。実Readerを起動せず、Rawのpathも一時先の不存在位置。
    stop=G.S.load(G.READER);done=G.S.load(Path(completion['path']));scenes=[]
    for item in done['results']:scenes.append({'session':item['session'],'reference':'NK225','contract':'metadata人工限月','start':1,'end':2,'cutoff':0,'raw':{'path':str(folder/(item['session']+'.人工Raw.json.gz')),'sha256':'1'*64},'raw_bytes':1,'expected_source_rows':0,'expected_source_quality':{},'windows':[]})
    reader={'version':1,'trial':116,'fixed':True,'raw_read_authorized':True,'policy':'NK225_source_rows_lifecycle116_v1','stage':'first2','reader_stop':ref(G.READER,G.READER_SHA),'executable':stop['実行物'],'code_sha256':{**stop['全固定コードSHA256'],**stop['所有コードSHA256'],str(G.READER):G.READER_SHA},'refs':{'financial_condition':condition,'financial_completion':completion,'independent_result':result,'independent_check':check,'lifecycle_audit_stop':ref(G.SAVED/'ライフ停止.json',G.STOPS['ライフ停止.json'])},'scenes':scenes}
    consumer=write(folder/'consumer停止の人工.json',{'人工':True,'成功':True,'停止':True,'市場前':True,'試行':116,'所有ファイルSHA256':{str(Path(G.__file__).resolve()):G.S.digest(Path(G.__file__))},'依存コードSHA256':{},'保存点停止':{name:{'path':str(G.SAVED/name),'sha256':sha} for name,sha in G.STOPS.items()}})
    request={'人工':True,'version':1,'trial':116,'fixed':True,'raw_read_authorized':True,'market_native_read_authorized':True,'holdout_read_authorized':False,'stage':'first2','consumer_stop':consumer,'reader_request':write(folder/'Reader要求の人工.json',reader),'condition':condition,'completion':completion,'independent_result':result,'independent_check':check,'save_request':save,'scenes':[{'session':x['session'],'native':x['native']} for x in done['results']]}
    return {'request':request,'reader':reader,'folder':folder}


def prepare(data: dict) -> dict:
    """
    機能: 人工要求を新SHAへ結びmetadataゲートだけを呼ぶ。
    引数: data(dict)。返り値: dictはRaw未読の許可計画。
    """
    q=data['request'];q['reader_request']=write(data['folder']/'Reader要求の人工.json',data['reader']);r=write(data['folder']/'consumer要求の人工.json',q)
    return G.prepare(Path(r['path']),r['sha256'],data['folder']/'未生成結果','2026-09-21_Day')


class Tests(unittest.TestCase):
    """実schemaの正例を、停止前に必ず通す。"""

    def test_real_upstream_and_reader_schema_without_raw(self):
        """
        機能: 実F1/完了/新型保存/Reader停止でmetadataを通し、RawもNativeも開かない。
        引数: self(Tests)。返り値: None。
        """
        with tempfile.TemporaryDirectory(dir=HERE) as tmp:
            data=fixture(Path(tmp));plan=prepare(data);self.assertEqual(plan['task']['session'],'2026-09-21_Day');self.assertFalse(plan['output'].exists());self.assertFalse(Path(plan['scene']['raw']['path']).exists())

    def test_authorization_stage_and_binding_corruptions(self):
        """
        機能: 未許可/別stage/別life停止/別codeMap/別Nativeを本文前に拒否する。
        引数: self(Tests)。返り値: None。
        """
        for field in ('raw','native','holdout','stage','life','code','exe','native_ref'):
            with tempfile.TemporaryDirectory(dir=HERE) as tmp:
                data=fixture(Path(tmp));q=data['request'];r=data['reader']
                if field=='raw':q['raw_read_authorized']=False
                elif field=='native':q['market_native_read_authorized']=False
                elif field=='holdout':q['holdout_read_authorized']=True
                elif field=='stage':q['stage']='2026-11-09'
                elif field=='life':r['refs']['lifecycle_audit_stop']['sha256']='0'*64
                elif field=='code':r['code_sha256'].pop(next(iter(r['code_sha256'])))
                elif field=='exe':r['executable']['sha256']='0'*64
                else:q['scenes'][0]['native']['sha256']='0'*64
                with self.subTest(field=field),self.assertRaises(ValueError):prepare(data)


if __name__=='__main__':unittest.main(verbosity=2)
