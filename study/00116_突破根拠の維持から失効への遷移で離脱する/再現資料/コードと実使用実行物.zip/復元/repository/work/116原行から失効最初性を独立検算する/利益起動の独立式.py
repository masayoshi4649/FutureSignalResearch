"""実保有R/nと正常返済BBOからH100初回起動だけを独立再形成する。"""
from copy import deepcopy
from decimal import Decimal


def number(value: int | float | Decimal, label: str) -> Decimal:
    """
    機能: 明示された有限数だけを十進算術へ変換する。
    引数: value(int|float|Decimal)、label(str)は値と検査名。
    返り値: Decimalは有限値。不正型・非有限ならValueError。
    """
    if isinstance(value, bool) or not isinstance(value, (int, float, Decimal)):
        raise ValueError(label + "は数値だけ")
    result = value if isinstance(value, Decimal) else Decimal(str(value))
    if not result.is_finite():
        raise ValueError(label + "は有限値だけ")
    return result


def normal_mark(quote: dict, side: int) -> Decimal | None:
    """
    機能: 生QuoteOKと有限の正Bid<Askを満たす返済側だけを選ぶ。
    引数: quote(dict)、side(int)は現在原行と方向。
    返り値: Decimal|Noneは買Bid/売Ask又は異常BBO。不正旗型ならValueError。
    """
    if type(quote.get("quote_ok")) is not bool:
        raise ValueError("quote_okは生boolが必要")
    try:
        bid, ask = number(quote.get("bid"), "Bid"), number(quote.get("ask"), "Ask")
    except ValueError:
        return None
    if not quote["quote_ok"] or bid <= 0 or ask <= bid:
        return None
    return bid if side == 1 else ask


class Activation:
    """実初期枚数を固定し、初回H100起動witnessを不可逆に保持する。"""

    def __init__(self, q0: int, side: int, price: int | float | Decimal,
                 slip: int | float | Decimal):
        """
        機能: 実取得の初期枚数・方向・価格・追加片道滑りを固定する。
        引数: q0(int)、side(int)、price/slip(int|float|Decimal)。
        返り値: None。q0>0、side=±1、価格>0、滑り>=0を必要とする。
        """
        if type(q0) is not int or q0 <= 0 or type(side) is not int or side not in (1, -1):
            raise ValueError("初期枚数と売買方向が不正")
        entry, cost_slip = number(price, "取得価格"), number(slip, "追加片道滑り")
        if entry <= 0 or cost_slip < 0:
            raise ValueError("取得価格は正、追加滑りは非負が必要")
        self._q0, self._side, self._price, self._slip = q0, side, entry, cost_slip
        self._cost = Decimal(77) + Decimal(200) * cost_slip
        self._threshold = Decimal(q0) * Decimal(10000)
        self._active, self._first, self._previous = False, None, None

    @property
    def active(self) -> bool:
        """
        機能: 一度成立した必須起動を読み取る。
        引数: なし。返り値: boolは不可逆の起動旗。
        """
        return self._active

    @property
    def first(self) -> dict | None:
        """
        機能: 初回witnessを呼出側と参照共有せず返す。
        引数: なし。返り値: dict|Noneは独立した初回証拠又は未起動。
        """
        return deepcopy(self._first)

    def observe(self, quote: dict, phase: str, remaining: int,
                realized: int | float | Decimal) -> dict | None:
        """
        機能: 現在の実R/nから費用後Wを計算し、H100初回到達だけを返す。
        引数: quote(dict)、phase(str:pre_fill/after_source)、remaining(int)、realized(数値)。
        返り値: dict|Noneは新起動witness又は新起動なし。異常時は元状態を変更しない。
        """
        if not isinstance(quote, dict) or phase not in ("pre_fill", "after_source"):
            raise ValueError("原行dictと二つの実評価位相が必要")
        if type(remaining) is not int or not 0 <= remaining <= self._q0:
            raise ValueError("実残枚数は0以上かつ実初期枚数以下")
        r = number(realized, "実既返済純額R")
        at = number(quote.get("time"), "価格時計")
        index, line = quote.get("index"), quote.get("source_line")
        if type(index) is not int or index < 0 or type(line) is not int or line < 1:
            raise ValueError("採用Index/物理行が不正")
        rank = 0 if phase == "pre_fill" else 1
        if self._previous is not None:
            previous = self._previous
            if index == previous["index"]:
                if quote != previous["quote"] or rank <= previous["rank"]:
                    raise ValueError("同原行は同Quoteのpre_fill→after_sourceだけ")
            elif index < previous["index"] or line <= previous["line"] or at < previous["time"]:
                raise ValueError("採用Index/物理行/価格時計の後退")
        mark = normal_mark(quote, self._side)
        first = None
        if not self._active and remaining > 0 and mark is not None:
            unit = Decimal(100) * self._side * (mark - self._price) - self._cost
            whole = r + Decimal(remaining) * unit
            if whole >= self._threshold:
                first = {"quote": deepcopy(quote), "phase": phase, "initial_quantity": self._q0,
                         "side": self._side, "entry_price": self._price, "slip_points": self._slip,
                         "remaining": remaining, "realized_net": r, "mark_price": mark,
                         "unit_net_yen": unit, "whole_net_yen": whole,
                         "threshold_yen": self._threshold, "round_trip_cost_yen": self._cost}
        # ----------------------------------------
        # 検査後だけ現在原行と初回起動を保存する。flatでRが閾値以上でも新起動しない。
        self._previous = {"index": index, "line": line, "time": at, "rank": rank, "quote": deepcopy(quote)}
        if first is not None:
            self._active, self._first = True, deepcopy(first)
        return deepcopy(first)
