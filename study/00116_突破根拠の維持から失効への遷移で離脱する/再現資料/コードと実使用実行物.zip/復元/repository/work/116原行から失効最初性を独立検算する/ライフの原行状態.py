"""全原行の初回性を調べるため、巨大な凍結出生を毎原行複写しない独立状態機械を持つ。"""
from copy import deepcopy

from 独立参照 import A,I,L


class Monitor:
    """純Goを呼ばず、実保有原行の状態遷移と最初のwitnessだけを保持する。"""

    def __init__(self,entry: dict,definition: dict):
        """
        機能: 監視適格な実取得の凍結出生と初期純状態を私有化する。
        引数: entry/definition(dict)。返り値: None。未知/不適格な出生は上位で別計数する。
        """
        self._state=L.initial_state(entry,definition);self._previous_five=None

    def snapshot(self) -> dict:
        """
        機能: 保存点との照合に使う独立状態を参照共有なく返す。
        引数: self(Monitor)。返り値: dict。全原行での呼出しを要求しない。
        """
        return deepcopy(self._state)

    def advance(self,inp: dict,delivered: dict,line_known: bool) -> dict:
        """
        機能: 取得後の実n>0原行だけを進め、P100先行・警戒・最初ラッチ/freeを再形成する。
        引数: inp/delivered(dict)、line_known(bool)。返り値: dictは当原行の全純Decision。
        """
        s=self._state;e=s['entry'];initial=not s['initialized'];current=inp['latest']['scales'][0]
        A.need(type(inp['remaining']) is int and type(inp['reserved']) is int and 0<=inp['reserved']<=inp['remaining'] and inp['remaining']>0,'Raw lifeは実n>0だけ')
        if s['at'] is not None:A.need(inp['stamp']['index']>s['at']['index'] and inp['stamp']['source_line']>s['at']['source_line'] and inp['stamp']['time']>=s['at']['time'],'Raw life原行のstrict前進')
        x=I.values_for(e,inp);fid=current['current']['frame']['id'] if current['has_current'] else None
        new=bool(current['has_current'] and current['current']['frame']['record_ordinal']==inp['latest']['record_ordinal'] and fid!=self._previous_five)
        d={'version':116,'policy':e['policy'],'stamp':deepcopy(inp['stamp']),'initial_evaluation':initial,'monitoring_eligible':I.monitoring_eligible(e),**x,'armed_now':False,'chain_broken_now':False,'warning':False,'new_five_publication':new,'invalidated_now':False,'exit_eligible_quantity':0,'reason':''}
        s['sequence']+=1;s['at']=deepcopy(inp['stamp'])
        if e['policy']=='X0' or not s['monitoring_eligible']:d['reason']='追加監視なし'
        elif s['latched']:
            s['warning']=s['armed'] and x['required_known'] and x['required_fresh'] and x['post_entry_five'] and x['values']['signed_histogram'] is not None and I.number(x['values']['signed_histogram'])<=0;d['reason']='既完成失効を保持'
        elif s['disabled_by_P100'] or inp['P100_active']:
            s['disabled_by_P100']=True;s['armed']=False;s['warning']=False;d['reason']='P100先起動へ委譲'
        else:
            if not x['required_known'] or not x['required_fresh']:
                if s['armed']:
                    d['chain_broken_now']=True;s['chain_break_count']+=1;s['last_chain_break']=I.make_witness(inp,x['values'],delivered,line_known,'実使用Unknown/古さ')
                s['armed']=False;s['warning']=False;d['reason']='実使用値の鎖切り'
            if not s['armed'] and x['arming_condition']==I.TRUE and (initial or x['post_entry_five']):
                s['armed']=True;s['arming_count']+=1;d['armed_now']=True;w=I.make_witness(inp,x['values'],delivered,line_known,'維持根拠をarmed')
                if s['first_arming'] is None:s['first_arming']=w
                s['last_arming']=w
            if s['armed'] and x['required_known'] and x['required_fresh']:
                s['warning']=x['post_entry_five'] and x['values']['signed_histogram'] is not None and I.number(x['values']['signed_histogram'])<=0
                fired=s['warning'] and ((e['policy']=='XC' and new and I.number(x['values']['signed_close'])<0) or (e['policy']=='XQ' and x['quote_ok'] and I.number(x['values']['signed_return_BBO'])<0))
                if fired:s['latched']=True;d['invalidated_now']=True;s['invalidation']=I.make_witness(inp,x['values'],delivered,line_known,'取得後の突破根拠失効');d['reason']='新しい失効を不可逆ラッチ'
        d['warning']=s['warning']
        if s['latched'] and x['quote_ok']:d['exit_eligible_quantity']=inp['remaining']-inp['reserved']
        s['initialized']=True;self._previous_five=fid;d.update(armed=s['armed'],latched=s['latched'],disabled_by_P100=s['disabled_by_P100'],sequence=s['sequence'])
        return d
