"""全手製原行の小結果と、非イベント原行の速度だけを記録する。金融成績は作らない。"""
from copy import deepcopy
from pathlib import Path
import json
import time

from 独立参照 import A,I,S
from 原行の人工検査 import read,CORE,CORE_SHA,PURE,PURE_SHA,deliver
from ライフの原行状態 import Monitor


def main(target: Path) -> dict:
    """
    機能: 2手製系列48玉の初回性と、同じ入力構造の10,000非イベント行の処理時間を保存する。
    引数: target(Path)は新規小JSON。返り値: dictは成功Ref。自然Native/Rawは読まない。
    """
    value=read(CORE,CORE_SHA);scenes=[]
    for side,native in value['results'].items():scenes.append({'side':int(side),**deliver(native,int(side))})
    pure=read(PURE,PURE_SHA);case=pure['cases'][0];engine=Monitor(case['entry'],pure['definition']);inp=deepcopy(case['steps'][0]['input']);start=time.perf_counter()
    for offset in range(10000):
        step={**inp,'stamp':{**inp['stamp'],'index':inp['stamp']['index']+offset,'source_line':inp['stamp']['source_line']+offset},'latest':{**inp['latest'],'record_ordinal':inp['latest']['record_ordinal']+offset}}
        engine.advance(step,{'time':0,'index':0,'source_line':0},False)
    elapsed=time.perf_counter()-start
    result={'試行':116,'成功':True,'人工':True,'市場':False,'FAR自然生成':False,'Core人工Ref':{'path':str(CORE),'sha256':CORE_SHA},'純人工Ref':{'path':str(PURE),'sha256':PURE_SHA},'系列':scenes,'監視適格実玉':sum(s['監視適格実玉数'] for s in scenes),'全Raw手製の初ラッチ':sum(p['初ラッチ'] is not None for s in scenes for p in s['実玉']),'全Raw手製の初要求':sum(p['初要求'] is not None for s in scenes for p in s['実玉']),'性能人工':{'非イベント原行':10000,'秒':elapsed,'毎秒':10000/elapsed,'注意':'手製1玉・公表更新なし・保存点比較なし。市場全70やRawI/Oの所要時間推定ではない。'},'全Raw自然市場監査':False,'P100床のRaw再形成':False,'自然Raw/新自然Native/価格CSV/11月09本文':False,'金融再実行':False}
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,ensure_ascii=False,indent=2,default=S.BASE.serial)+'\n')
    return {'path':str(target.resolve()),'sha256':S.digest(target)}
