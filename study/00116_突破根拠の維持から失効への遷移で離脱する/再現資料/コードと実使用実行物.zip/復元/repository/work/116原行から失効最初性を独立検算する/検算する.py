"""Root別要求後にだけ、停止GoReaderのpipeを消費して全保有Rawの最初性を検査する。"""
from pathlib import Path
from decimal import Decimal
import argparse
import gzip
import hashlib
import json
import subprocess
import time

from 独立参照 import A,S
from 原行の最初性 import SceneAudit
import 実行の入力ゲート as G


def normalized_windows(rows: list[dict]) -> list[tuple]:
    """
    機能: 和集合の連続/重複区間を同じ始終Quoteへ正規化する。
    引数: rows(list[dict])はstart_quote/end_quote。返り値: list[tuple]。ID文字列で同体を偽装しない。
    """
    result=[]
    for row in sorted(rows,key=lambda r:r['start_quote']['index']):
        start,end=row['start_quote'],row['end_quote'];A.need(start['index']<=end['index'],'実窓の前後')
        if result and start['index']<=result[-1][1]['index']+1:
            if end['index']>result[-1][1]['index']:result[-1]=(result[-1][0],end)
        else:result.append((start,end))
    return result


def run(plan: dict,root_ref: dict) -> dict:
    """
    機能: 当場Nativeと実監視窓を認証し、Reader1passの全quote/最終summary/exitを結合する。
    引数: plan/root_ref(dict)。返り値: dictは小成功Ref。Raw全件をファイルへ複写しない。
    """
    out=plan['output'];out.mkdir(parents=True,exist_ok=False);child=None
    try:
        ref=plan['task']['native'];p=Path(ref['path']);b=p.read_bytes();A.equal(hashlib.sha256(b).hexdigest(),ref['sha256'],'解禁された当場NativeSHA');plan['before'][str(p.resolve())]=ref['sha256'];native=json.loads(gzip.decompress(b),parse_float=Decimal)
        A.equal(native['actual']['lifecycle_definition'],plan['definition'],'同F1実life定義');A.equal(native['actual']['scope']['session']['id'],plan['task']['session'],'同場Native');audit=SceneAudit(native)
        expected=[{'start_quote':m.p['entry_quote'],'end_quote':m.p['closed_quote']} for m in audit.monitors];A.equal(normalized_windows(plan['scene']['windows']),normalized_windows(expected),'全監視適格XC/XQ実窓の和集合を省略しない')
        command=[plan['reader']['executable']['path'],'--request',plan['request']['reader_request']['path'],'--sha',plan['request']['reader_request']['sha256'],'--session',plan['task']['session'],'--out',str(out/'原板配送'),'--root-authorized'];summary=None;last_progress=time.monotonic()
        with (out/'Reader.stderr.log').open('w',encoding='utf-8') as err:
            child=subprocess.Popen(command,stdout=subprocess.PIPE,stderr=err,text=True,encoding='utf-8',bufsize=1)
            for line in child.stdout:
                if not line.strip():continue
                value=json.loads(line,parse_float=Decimal);A.need(summary is None,'summaryは最後の非空行')
                if value['kind']=='quote':audit.observe(value['quote'])
                elif value['kind']=='summary':summary=value
                else:raise ValueError('Reader streamの不明kind')
                if time.monotonic()-last_progress>=30:print(json.dumps({'進行':True,'場':plan['task']['session'],'採用pipe原行':audit.rows},ensure_ascii=False),flush=True);last_progress=time.monotonic()
            child.stdout.close();code=child.wait();A.need(summary is not None,'Readerの最終成功summaryが必要');A.need(G.same(summary['condition'],plan['request']['reader_request']),'Readerは同Root要求を実行')
        A.equal(summary['session'],plan['task']['session'],'Reader当場');A.need(G.same(summary['raw'],plan['scene']['raw']),'Readerは同Root原板');A.equal(summary['actual_sha256'],plan['scene']['raw']['sha256'],'Reader1passの圧縮RawSHA');A.equal(summary['compressed_bytes'],plan['scene']['raw_bytes'],'Reader原板bytes');A.equal(summary['stat_before'],summary['stat_after'],'原板前後stat不変')
        A.equal(summary['source_quality'],plan['scene']['expected_source_quality'],'ReaderのSource品質全数');A.equal(summary['quality']['source_delivered'],plan['scene']['expected_source_rows'],'Readerの全Source配送数')
        A.equal(normalized_windows([x['window'] for x in summary['windows']]),normalized_windows(expected),'最終Reader窓と全実保有窓');G.reference(summary['summary_file'],plan['before']);proof=audit.finish(summary,code)
        after={filename:S.digest(Path(filename)) for filename in plan['before']};A.equal(after,plan['before'],'新旧停止/上流/当場Native/Reader成果物前後同体')
        proof.update({'stage':plan['request']['stage'],'場':plan['task']['session'],'Root要求':root_ref,'金融条件':plan['request']['condition'],'金融完了':plan['request']['completion'],'独立保存結果':plan['request']['independent_result'],'独立保存確認':plan['request']['independent_check'],'実保存要求':plan['request']['save_request'],'保存点停止':G.STOPS,'Reader要求':plan['request']['reader_request'],'Reader成功summary':summary,'Native':ref,'入力SHA256前':plan['before'],'入力SHA256後':after,'前後不変':True,'金融再実行':False,'限界':['監視適格な実XC/XQ建玉の実取得〜最終返済だけを対象とする。X0/不適格出生は別計数。','5/15/30の数値をRawから作り直さず、固定Nativeの全実公表列を当Rawへasof接合する。公表値自体は別の価格足/DMI監査へ参照する。','H100の初回起動は全保持Rawの実R/nと費用から再形成する。P100全追尾床/床hitの全Raw最初性は再形成しない。','監視窓前の新規注文の最初正常fillは本範囲に含めず、実返済要求後の最初正常fillを検査する。','Source通知と実取引を固定して矛盾を検出する監査であり、失敗後の仮想損益は作らない。']})
        S.BASE.write_json(out/'結果.json',proof);return {'成功':True,'場':plan['task']['session'],'監視適格実玉数':proof['監視適格実玉数'],'ref':{'path':str(out/'結果.json'),'sha256':S.digest(out/'結果.json')}}
    except BaseException as error:
        if child is not None:
            if child.poll() is None:child.terminate();child.wait()
            child.stdout.close()
        S.BASE.write_json(out/'不完了.json',{'試行':116,'成功':False,'Root要求':root_ref,'場':plan['task']['session'],'理由':str(error),'Reader成功summary単独で成功化しない':True});raise


def main() -> None:
    """
    機能: RootのRaw別固定がなければ本文に進まず、metadata-onlyと実streamを分ける。
    引数: CLI request/output(Path)、sha/session(str)、metadata-only(bool)。返り値: None。
    """
    p=argparse.ArgumentParser();p.add_argument('--request',type=Path,required=True);p.add_argument('--sha',required=True);p.add_argument('--session',required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--metadata-only',action='store_true');a=p.parse_args();plan=G.prepare(a.request,a.sha,a.out,a.session)
    if a.metadata_only:print(json.dumps({'成功':True,'Native/Raw本文読取':False,'場':a.session},ensure_ascii=False));return
    print(json.dumps(run(plan,{'path':str(a.request.resolve()),'sha256':a.sha}),ensure_ascii=False))


if __name__=='__main__':main()
