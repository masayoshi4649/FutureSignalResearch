"""保存actual fills/allocationsの実n/Rと予約だけを、原行位相ごとに再構成する。"""
from bisect import bisect_left,bisect_right
from decimal import Decimal

from 独立参照 import A
from 利益起動の独立式 import normal_mark

QUOTE_KEYS=('time','index','source_line','last','bid','ask','quote_ok')


def quote_value(q: dict) -> dict:
    """
    機能: Rawの元clock文字列を価格/Indexの実Quoteから分ける。
    引数: q(dict)。返り値: dictはActorと同じ7項目。元clockは上位の証拠へ別保存する。
    """
    return {k:q[k] for k in QUOTE_KEYS}


class Ownership:
    """Source仮想建玉を使わず、検算済み実配賦だけのprefixと全exit注文を持つ。"""

    def __init__(self,book: dict,position: dict):
        """
        機能: 実Positionの初期枚数と各close allocationを、保存約定順で索引する。
        引数: book/position(dict)。返り値: None。
        """
        self.position=position;self.q0=position['initial_quantity'];self.indices=[];self.closed=[0];self.realized=[Decimal(0)]
        self.orders=[o for o in book['orders'] if o['kind']=='exit' and o['position_id']==position['id']]
        self.fills={f['order_id']:f for f in book['fills'] if f['position_id']==position['id'] and f['action']=='close'}
        for f in book['fills']:
            if f['position_id']!=position['id'] or f['action']!='close':continue
            self.indices.append(f['quote']['index']);self.closed.append(self.closed[-1]+f['quantity']);self.realized.append(self.realized[-1]+sum((A.money(p['net_yen'],'実allocation純額') for p in f['allocations']),Decimal(0)))
        A.equal(self.closed[-1],self.q0,'Raw位相の実最終返済量');A.equal(self.realized[-1],A.money(position['realized_net'],'保存実純額'),'Raw位相の実配賦純額')

    def state(self,index: int,phase: str) -> tuple:
        """
        機能: 同原行fillをpreでは除外、afterでは全て含めてn/Rを返す。
        引数: index(int)、phase(str)。返り値: tuple[int,Decimal]。
        """
        A.need(phase in ('pre_fill','after_source'),'実所有の二位相');j=bisect_left(self.indices,index) if phase=='pre_fill' else bisect_right(self.indices,index)
        return self.q0-self.closed[j],self.realized[j]

    def reserved(self,index: int,before_life: bool) -> int:
        """
        機能: 既要求未fill予約へ当行Source/Pを足し、当行lifeは期待量照合まで除外する。
        引数: index(int)、before_life(bool)。返り値: intは実予約量。exit取消はActorにない。
        """
        total=0
        for o in self.orders:
            requested=o['request_quote']['index'];accepted=requested<index or before_life and requested==index and o.get('lifecycle_point') is None
            f=self.fills[o['id']];filled=f['quote']['index']<index or before_life and f['quote']['index']==index
            if accepted and not filled:total+=o['quantity']
        return total

    def check_first_fills(self,q: dict,delay: int) -> int:
        """
        機能: 実返済要求後の全Rawから最初正常・遅延到達原行と実fillを照合する。
        引数: q(dict)、delay(int)。返り値: intは当行に成立した実返済fill数。
        """
        found=0
        for o in self.orders:
            if o['request_quote']['index']>=q['index']:continue
            fill=self.fills[o['id']]
            if fill['quote']['index']<q['index']:continue
            eligible=normal_mark(q,self.position['side']) is not None and A.number(q['time'],'現時計')>=A.number(o['request_time'],'要求時計')+delay
            A.equal(fill['quote']['index']==q['index'],eligible,'返済の最初正常/遅延到達Rawを飛ばさない')
            if eligible:A.equal(fill['quote'],q,'最初返済fillの実Raw全値');found+=1
        return found
