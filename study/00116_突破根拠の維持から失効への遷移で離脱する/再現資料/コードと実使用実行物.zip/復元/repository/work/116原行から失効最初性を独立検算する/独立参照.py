"""停止済み116保存点監査を指紋認証して再用する。市場本文は読み込まない。"""
from pathlib import Path
import hashlib
import importlib
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
SAVED=ROOT/'work/116保有根拠の独立会計と保存_未読件数の型'
STOPS={
    '会計停止.json':'397ee90a93f491f5cf1842f70b4a974a0435fdb84eae8987416881e40af5a12d',
    'P停止.json':'6c1e1f74465527550d0ca2b62127495a7d5c3c70c5a125a0576801873a26f47d',
    'ライフ停止.json':'ec1f6fef55c1717e3592be24c74259d5f837be2eb0096dea73c2ce0a39805769'}
for name,sha in STOPS.items():
    path=SAVED/name
    if hashlib.sha256(path.read_bytes()).hexdigest()!=sha:raise ValueError('116保存点停止SHA差/'+name)
    value=json.loads(path.read_text(encoding='utf-8'))
    if not (value['成功'] and value['停止'] and value['市場前'] and value['試行']==116):raise ValueError('116保存点停止schema差')
    for filename,expected in value['所有ファイルSHA256'].items():
        if hashlib.sha256(Path(filename).read_bytes()).hexdigest()!=expected:raise ValueError('116保存点所有の変更/'+filename)
sys.path.insert(0,str(SAVED))
try:
    A=importlib.import_module('金融の独立検算');I=importlib.import_module('ライフ状態の独立式');L=importlib.import_module('保有根拠の独立監査');S=importlib.import_module('保存集計の共通部')
finally:sys.path.pop(0)

need,equal,number=A.need,A.equal,A.number
