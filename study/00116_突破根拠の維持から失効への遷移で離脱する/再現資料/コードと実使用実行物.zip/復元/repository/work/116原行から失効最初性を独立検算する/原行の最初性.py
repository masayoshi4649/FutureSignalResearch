"""実保有窓の全採用原行からP100起動とlife初回ラッチ/要求/後原行fillを独立再形成する。"""
from collections import Counter
from copy import deepcopy

from 独立参照 import A,I,L
from ライフの原行状態 import Monitor
from 公表列の当時状態 import Publications
from 実所有の原行位相 import Ownership,quote_value
from 利益起動の独立式 import Activation


class PositionAudit:
    """一つの監視適格実Positionの原行列を、保存結果へ補正せず照合する。"""

    def __init__(self,book: dict,p: dict):
        """
        機能: 当時出生/実所有/保存点/全実life注文を別索引にする。
        引数: book/p(dict)。返り値: None。監視不適格やX0は上位が対象外として別計数する。
        """
        self.book=book;self.p=p;self.audit=p['lifecycle116'];self.entry=self.audit['initial']['entry'];self.life=Monitor(self.entry,self.audit['initial']['definition']);self.own=Ownership(book,p)
        self.activation=Activation(p['initial_quantity'],p['side'],p['entry_price'],book['config']['slip_pts']);self.previous_index=None;self.rows=0;self.counts=Counter();self.saved={};self.last_warning=False
        for point in L.collect_points(self.audit):self.saved[point['snapshot']['sequence']]=point
        self.requests={o['request_quote']['index']:o for o in self.own.orders if o.get('lifecycle_point') is not None};A.equal(len(self.requests),len(self.audit.get('requests') or []),'同玉同原行life要求一件')
        self.expected_requests=[];self.first_latch=None;self.first_request=None;self.first_fill=None

    def observe(self,q: dict,snapshot: dict,publications: Publications) -> None:
        """
        機能: 同原行の公表最終状態→preH→全fill→afterH/予約→lifeの順で初回性を検査する。
        引数: q/snapshot(dict)、publications(Publications)。返り値: None。不一致後に仮想取引を続行しない。
        """
        index=q['index'];start=self.p['entry_quote']['index'];end=self.p['closed_quote']['index']
        A.need(start<=index<=end,'実保有窓内だけ');A.need(self.previous_index is None or index==self.previous_index+1,'実保有窓の採用Rawを一行も省略しない');self.previous_index=index;self.rows+=1
        if index==start:A.equal(q,self.p['entry_quote'],'実取得Rawと独立配送');A.need(self.rows==1,'監視は実取得から')
        else:
            n,r=self.own.state(index,'pre_fill');self.activation.observe(q,'pre_fill',n,r)
        fills=self.own.check_first_fills(q,self.book['config']['delay_seconds']);self.counts['返済最初正常fill']+=fills
        if fills and self.first_fill is None:
            life_fill=[f for f in self.own.fills.values() if f['quote']['index']==index and f.get('lifecycle_exit',False)]
            if life_fill:self.first_fill=deepcopy(q)
        n,r=self.own.state(index,'after_source');self.activation.observe(q,'after_source',n,r)
        if n==0:
            A.equal(index,end,'最終Rawの実所有0');A.equal(q,self.audit['final_ownership']['quote'],'n0所有完結の実Raw');A.equal(self.activation.active,self.audit['final_ownership']['P100_active'],'独立H100と所有完結のActive');A.need(index not in self.requests,'flat原行にlife新要求なし');return
        reserved=self.own.reserved(index,True);A.need(0<=reserved<=n,'life前の実残/Source/P100予約')
        inp={'stamp':{k:q[k] for k in ('time','index','source_line')},'phase':'after_source','latest':snapshot,'bid':q['bid'],'ask':q['ask'],'quote_ok':q['quote_ok'],'remaining':n,'reserved':reserved,'P100_active':self.activation.active}
        before=self.life.snapshot() if self.life._state['sequence']+1 in self.saved else None;delivered,known=publications.delivery(self.entry,snapshot);d=self.life.advance(inp,delivered,known);seq=d['sequence']
        self.counts['life原行評価']+=1;self.counts['異常BBO評価']+=not d['quote_ok'];self.counts['使用値欠測']+=bool(d['missing']);self.counts['使用値古さ']+=bool(d['stale']);self.counts['arm']+=d['armed_now'];self.counts['鎖切り']+=d['chain_broken_now']
        if d['warning'] and not self.last_warning:self.counts['警戒開始']+=1
        if self.last_warning and not d['warning']:
            self.counts['警戒解除']+=1
            if d['new_five_publication'] and d['required_known'] and d['required_fresh'] and d['values']['signed_histogram'] is not None and d['values']['signed_histogram']>0:self.counts['順Hist回復']+=1
        self.last_warning=d['warning']
        if d['latched'] and n==reserved:self.counts['完成後全予約']+=1
        if d['invalidated_now']:A.need(self.first_latch is None,'初ラッチは一度だけ');self.first_latch=deepcopy(q)
        if seq in self.saved:
            point=self.saved[seq];I.compare(point['before_snapshot'],before,'全Rawの保存前State');I.compare(point['input'],inp,'全Rawから再形成Input');I.compare(point['snapshot'],self.life.snapshot(),'全Rawから再形成State');I.compare(point['decision'],d,'全Rawから再形成Decision');A.equal(point['remaining'],n,'全Raw実n');A.equal(A.money(point['realized_net'],'保存R'),r,'全Raw実R');self.counts['保存点全値同体']+=1
        actual=self.requests.get(index)
        A.equal(actual is not None,d['exit_eligible_quantity']>0,'life要求の最初成立を飛ばさない/先取りしない')
        if actual is not None:
            A.equal(actual['quantity'],d['exit_eligible_quantity'],'初回life未予約全量');A.equal(actual['request_quote'],q,'life要求は当Raw');self.expected_requests.append(actual['id'])
            if self.first_request is None:self.first_request=deepcopy(q)

    def finish(self) -> dict:
        """
        機能: 全保有Rawと初回H/ラッチ/要求/fillを、別々の保存点へ照合する。
        引数: self(PositionAudit)。返り値: dictは当実玉の小証拠。退出後価格を使わない。
        """
        A.equal(self.rows,self.p['closed_quote']['index']-self.p['entry_quote']['index']+1,'実保有全Raw件数');I.compare(self.audit['final_state'],self.life.snapshot(),'全Raw最終保有純状態')
        A.equal(self.expected_requests,[p['exit_order_id'] for p in self.audit.get('requests') or []],'全Rawから生じたlife全要求')
        A.equal(self.first_latch,None if self.audit['first_invalidation'] is None else self.audit['first_invalidation']['quote'],'初ラッチの真のRaw')
        fields={'evaluations':'life原行評価','bad_quote_evaluations':'異常BBO評価','missing_indicator_evaluations':'使用値欠測','stale_indicator_evaluations':'使用値古さ','warning_count':'警戒開始','warning_cleared_count':'警戒解除','recovery_count':'順Hist回復','all_reserved_count':'完成後全予約'}
        for field,key in fields.items():A.equal(self.audit[field],self.counts[key],'全Raw counter/'+field)
        first=self.activation.first;saved=self.p['activation'];A.equal(saved is not None,first is not None,'H100起動漏れ/先取りなし')
        if first is not None:
            A.equal(saved['quote'],first['quote'],'H100初回Raw');A.equal(saved['phase'],first['phase'],'H100初回位相');A.equal(saved['quantity'],first['remaining'],'H100初回実n')
            for k,w in (('realized_net','realized_net'),('mark_price','mark_price'),('unit_net','unit_net_yen'),('whole_net','whole_net_yen')):A.equal(A.money(saved[k],'保存H/'+k),first[w],'H100初回の独立費用後値/'+k)
        A.equal(self.activation.active,self.p['protection_active'],'全RawでActiveは不可逆')
        return {'key':self.book['key'],'position':self.p['id'],'原行数':self.rows,'counts':dict(self.counts),'P100初起動':first,'初ラッチ':self.first_latch,'初要求':self.first_request,'初life実fill':self.first_fill,'全Rawライフ最初性':True,'P100床/追尾幅の全Raw再形成':False}


class SceneAudit:
    """一場のRaw1streamを、監視適格な全実XC/XQ玉へ多重配送する。"""

    def __init__(self,native: dict):
        """
        機能: 本名116 Nativeの実監視適格窓だけを準備し、全X0/不適格出生を別計数する。
        引数: native(dict)。返り値: None。自然Nativeのopen/許可は上位Rootゲートの責務。
        """
        self.native=native;self.publications=Publications({k:v for k,v in native['actual'].items() if k!='books'});self.monitors=[];self.rows=0;self.previous=None;self.summary=None;self.omitted=Counter()
        for key,book in native['actual']['books'].items():
            if book['config']['life_mode']=='X0':self.omitted['X0実玉']+=len(book['positions']);continue
            for p in book['positions']:
                if not I.monitoring_eligible(p['lifecycle116']['initial']['entry']):self.omitted['監視不適格実玉']+=1;continue
                self.monitors.append(PositionAudit(book,p))

    def observe(self,raw: dict) -> None:
        """
        機能: Go独立Readerの採用原行を省略せず監視窓へ渡し、時計/Indexの後退を拒否する。
        引数: raw(dict)。返り値: None。summary後の価格は拒否する。
        """
        A.need(self.summary is None,'成功summary後にQuoteを受けない');q=quote_value(raw)
        if self.previous is not None:A.need(q['index']>self.previous['index'] and q['source_line']>self.previous['source_line'] and q['time']>=self.previous['time'],'stream原行順')
        self.previous=q;self.rows+=1;snapshot=self.publications.observe(q);active=[m for m in self.monitors if m.p['entry_quote']['index']<=q['index']<=m.p['closed_quote']['index']]
        A.need(active,'実監視窓外のQuoteは配送しない')
        for m in active:m.observe(q,snapshot,self.publications)

    def finish(self,summary: dict,exit_code: int) -> dict:
        """
        機能: 最終成功summaryとprocess exit0の両方を確認してからだけ監査を成功化する。
        引数: summary(dict)、exit_code(int)。返り値: dictは小証拠。Reader保存JSON単独は成功根拠にしない。
        """
        A.need(self.summary is None,'summaryは一件だけ');A.need(isinstance(summary,dict),'最終summary未受信なら不成功');A.equal(exit_code,0,'Raw Reader CLIの正常終了必須');A.need(summary['success'] and summary['trial']==116 and summary['raw_passes']==1 and summary['source_index_verified'] and summary['source_quality_equal'] and summary['source_rows_equal'] and summary['all_ten_depths_checked'],'Readerの全走査/品質/SourceIndex成功')
        A.equal(summary['streamed_rows'],self.rows,'pipe全Quote件数');A.need(not summary['financial_replay'] and not summary['all_raw_rows_saved'],'金融再生/全Raw複写なし')
        for w in summary['windows']:A.need(w['start_matched'] and w['end_matched'] and w['rows']==w['window']['end_quote']['index']-w['window']['start_quote']['index']+1,'全Raw和集合窓の境界/連続件数')
        self.summary=summary;details=[m.finish() for m in self.monitors]
        return {'試行':116,'成功':True,'監視適格実玉数':len(details),'pipe原行数':self.rows,'対象外':dict(self.omitted),'Reader成功summaryとexit0':True,'実玉':details,'全Rawライフ初回性':True,'P100H100初回性':True,'P100全床/全追尾幅Raw再形成':False,'退出後仮想利益':False}
