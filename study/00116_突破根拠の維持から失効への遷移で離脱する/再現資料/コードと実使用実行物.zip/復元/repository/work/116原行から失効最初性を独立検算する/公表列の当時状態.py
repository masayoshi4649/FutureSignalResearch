"""Rawの原行に同時配送された全公表を揃え、過去/中間5分足へ遡及しない。"""
from copy import deepcopy

from 独立参照 import A,I,L


class Publications:
    """全公表はNativeの固定出典として使い、当Rawの最後の尺度別状態だけを形成する。"""

    def __init__(self,context: dict):
        """
        機能: 公表列の同ID不変と配送順を認証して、当時Snapshotの雛形を作る。
        引数: context(dict)はCore.actual。返り値: None。足や技法数値を再計算しない。
        """
        self.rows=context['entry_publications'] or [];self.cat=L.catalog(context);self.offset=0;self.current={300:None,900:None,1800:None};self.last_index=-1
        events=context['entry_gate_events'] or []
        self.template=deepcopy(events[0]['snapshot']) if events else None
        previous=-1
        for pub in self.rows:
            q=pub['stamp'];f=pub['frame']['frame'];A.need(q['index']>=previous and q['source_line']>0,'公表列は元Raw順');A.equal(f['record_ordinal'],q['index']+1,'公表RawのRecordOrdinal');A.equal(f['delivery_at'],q['time'],'公表の実配送時計');A.need(f['available_at']<=q['time'] and f['end']<=q['time'],'公表終端/Availableは実配送以前');previous=q['index']

    def observe(self,q: dict) -> dict|None:
        """
        機能: 現Raw以前の全公表を反映し、同原行の中間値を使わないSnapshotを返す。
        引数: q(dict)はGo独立配送Quote。返り値: dict|Noneは当Raw最新。未来公表は使わない。
        """
        A.need(q['index']>self.last_index,'公表asofのRaw前進');self.last_index=q['index']
        while self.offset<len(self.rows) and self.rows[self.offset]['stamp']['index']<=q['index']:
            pub=self.rows[self.offset];stamp=pub['stamp'];f=pub['frame']['frame']
            if stamp['index']==q['index']:A.equal(stamp,{k:q[k] for k in ('time','index','source_line')},'保持窓内の公表Stampと独立Raw')
            A.need(stamp['time']<=q['time'],'過去Indexでも未来時計の公表は拒否');self.current[f['width_seconds']]=pub['frame'];self.offset+=1
        if self.template is None:return None
        s={**self.template,'as_of':q['time'],'replay_observed_at':q['time'],'has_observed':True,'record_ordinal':q['index']+1,'sealed':False,'scales':[]}
        for base in self.template['scales']:
            width=base['width_seconds'];frame=self.current[width];A.need(frame is not None,'適格出生より後の監視では全尺度の公表が存在する')
            s['scales'].append({**base,'has_current':True,'fresh':float(q['time'])-float(frame['frame']['available_at'])<width,'seed_only':False,'current':frame})
        return s

    def delivery(self,entry: dict,snapshot: dict) -> tuple:
        """
        機能: 初期に受けた旧公表のLine未知と、取得以後の実配送行を独立に区別する。
        引数: entry/snapshot(dict)。返り値: tuple[dict,bool]は純witnessのstampと行既知旗。
        """
        return L.delivery_for(entry,{'latest':snapshot},self.cat)
