"""Rootが先に作成したGoReader固定へ、未許可のconsumerひな型を結ぶ。"""
from pathlib import Path
import argparse
import json

import 実行の入力ゲート as G

HERE=Path(__file__).resolve().parent


def make(reader_path: Path,reader_sha: str,save_path: Path,save_sha: str) -> dict:
    """
    機能: Readerと実保存の小metadataだけからRoot用の未許可consumer要求を作る。
    引数: reader_path/save_path(Path)、reader_sha/save_sha(str)。返り値: dict。Native/Rawは読まない。
    """
    before={};rr={'path':str(reader_path.resolve()),'sha256':reader_sha};sr={'path':str(save_path.resolve()),'sha256':save_sha};reader=G.metadata(rr,before);save=G.metadata(sr,before);refs=reader['refs'];complete=G.metadata(refs['financial_completion'],before)
    G.A.need(reader['trial']==116 and reader['fixed'] and reader['raw_read_authorized'] and complete['success'] and complete['trial']==116 and save['trial']==116 and save['fixed'],'実Reader/金融成功/Root保存要求のmetadata')
    G.A.need(G.same(save['condition'],refs['financial_condition']) and G.same(save['completion'],refs['financial_completion']),'Readerと保存の同金融')
    stop=HERE/'停止.json'
    return {'version':1,'trial':116,'fixed':False,'stage':reader['stage'],'raw_read_authorized':False,'market_native_read_authorized':False,'holdout_read_authorized':False,'consumer_stop':{'path':str(stop),'sha256':G.S.digest(stop)},'reader_request':rr,'condition':refs['financial_condition'],'completion':refs['financial_completion'],'independent_result':refs['independent_result'],'independent_check':refs['independent_check'],'save_request':sr,'scenes':[{'session':r['session'],'native':r['native']} for r in complete['results']],'Root固定時の確認':['同F1・全場成功と新型397e/6c1e/ec1f保存停止を確認する。','GoReaderの全監視適格XC/XQ実窓の和集合・Raw参照・Source品質/総数を固定する。','Rootがfixed/Raw/Native許可の3つだけをtrueへ固定し、新要求SHAを採用する。','metadata-only成功後、Rootだけが一場ずつ実streamを実行する。']}


def main() -> None:
    """
    機能: 新consumer停止後、未固定/未許可ひな型を新規JSONへ保存する。
    引数: CLI reader-request/save-request/output(Path)、reader-sha/save-sha(str)。返り値: None。
    """
    p=argparse.ArgumentParser();p.add_argument('--reader-request',type=Path,required=True);p.add_argument('--reader-sha',required=True);p.add_argument('--save-request',type=Path,required=True);p.add_argument('--save-sha',required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();G.A.need(a.output.is_absolute() and not a.output.exists(),'新規絶対ひな型')
    value=make(a.reader_request,a.reader_sha,a.save_request,a.save_sha)
    with a.output.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'未固定/未許可':True,'ref':{'path':str(a.output),'sha256':G.S.digest(a.output)}},ensure_ascii=False))


if __name__=='__main__':main()
