"""Rawconsumerは市場前人工と全所有/旧停止同体のレビュー後だけ新停止へ固定する。"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import json
import os
import subprocess
import sys

import 実行の入力ゲート as G
from 独立参照 import A,S,SAVED,STOPS

HERE=Path(__file__).resolve().parent


def write(path: Path,value: dict) -> dict:
    """
    機能: 小証拠を上書きせず保存し、FileRefを返す。
    引数: path(Path)、value(dict)。返り値: dictは絶対path/sha256。
    """
    with path.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2,default=S.BASE.serial)+'\n')
    return {'path':str(path.resolve()),'sha256':S.digest(path)}


def maps() -> tuple:
    """
    機能: 新所有と実再用する新型保存/Reader/全固定依存を指紋認証する。
    引数: なし。返り値: tuple[dict,dict]。市場本文をコード閉包へ入れない。
    """
    owned={str(p.resolve()):S.digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.suffix in ('.py','.md')};deps={}
    for name,sha in STOPS.items():
        path=SAVED/name;A.equal(S.digest(path),sha,'新型保存停止同体');deps[str(path)]=sha;stop=S.load(path)
        for field in ('所有ファイルSHA256','依存コードSHA256'):
            for filename,expected in stop[field].items():A.need(Path(filename).suffix not in ('.gz','.csv','.jsonl'),'保存点コードに市場本文なし');A.equal(S.digest(Path(filename)),expected,'保存点全依存同体');deps[filename]=expected
    A.equal(S.digest(G.READER),G.READER_SHA,'実Reader停止同体');deps[str(G.READER)]=G.READER_SHA;reader=S.load(G.READER)
    for field in ('所有コードSHA256','全固定コードSHA256'):
        for filename,expected in reader[field].items():A.need(Path(filename).suffix not in ('.gz','.csv','.jsonl'),'Readerコードに市場本文なし');A.equal(S.digest(Path(filename)),expected,'Reader全依存同体');deps[filename]=expected
    for p in (Path(reader['実行物']['path']),):A.equal(S.digest(p),reader['実行物']['sha256'],'停止Reader実exe');deps[str(p)]=reader['実行物']['sha256']
    return owned,dict(sorted(deps.items()))


def check(output: Path) -> dict:
    """
    機能: 17主人工/全手製原行/実pipe/実metadataと前後指紋を新規証拠へ保存する。
    引数: output(Path)。返り値: dictはRootレビュー用Ref。正式停止は作らない。
    """
    A.need(output.is_absolute() and not output.exists(),'新規絶対の停止前確認先');owned,deps=maps();output.mkdir(parents=True);env={**os.environ,'PYTHONIOENCODING':'utf-8'}
    command=[sys.executable,'-m','unittest','-v','利益起動の人工検査','原行の人工検査','実停止metadataの人工検査','pipeの人工接続検査'];r=subprocess.run(command,cwd=HERE,env=env,capture_output=True,text=True,encoding='utf-8')
    if r.returncode!=0:raise ValueError('人工不成功\n'+r.stdout+'\n'+r.stderr)
    import 人工の小結果を保存する as X
    small=X.main(output/'手製原行の結果.json');after_owned,after_deps=maps();A.equal(after_owned,owned,'新consumer所有前後同体');A.equal(after_deps,deps,'全既停止依存前後同体')
    proof={'試行':116,'成功':True,'市場前':True,'停止':False,'Rootレビュー前':True,'UTC':datetime.now(timezone.utc).isoformat(),'主人工':17,'所有ファイルSHA256':owned,'依存コードSHA256':deps,'所有SHA256前':owned,'所有SHA256後':after_owned,'依存SHA256前':deps,'依存SHA256後':after_deps,'前後不変':True,'保存点停止':{name:{'path':str(SAVED/name),'sha256':sha} for name,sha in STOPS.items()},'Reader停止':{'path':str(G.READER),'sha256':G.READER_SHA},'手製原行の結果':small,'実行ログ':{'command':command,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr},'自然Raw/市場Native/価格CSV/11月09本文':False,'金融再実行':False,'全Raw自然市場の初回性監査':False,'P100全床/全追尾幅Raw再形成':False,'研究目標達成':False,'採用':False}
    return write(output/'停止前の確認.json',proof)


def stop(review: Path,sha: str) -> dict:
    """
    機能: Rootレビュー済みproofと全所有/旧依存が同体の時だけ初回consumer停止を作る。
    引数: review(Path)、sha(str)。返り値: dictは停止Ref。人工成功を市場成功へ置換しない。
    """
    A.equal(S.digest(review),sha,'Rootレビュー対象SHA');proof=S.load(review);A.need(proof['成功'] and proof['市場前'] and proof['停止'] is False and proof['前後不変'],'同停止前確認')
    owned,deps=maps();A.equal(owned,proof['所有ファイルSHA256'],'Rootレビュー後の新所有同体');A.equal(deps,proof['依存コードSHA256'],'Rootレビュー後の既停止依存同体');small=proof['手製原行の結果'];A.equal(S.digest(Path(small['path'])),small['sha256'],'手製結果同体');target=HERE/'停止.json';A.need(not target.exists(),'新consumer停止は初回だけ')
    return write(target,{'試行':116,'成功':True,'停止':True,'市場前':True,'UTC':datetime.now(timezone.utc).isoformat(),'所有ファイルSHA256':owned,'依存コードSHA256':deps,'前後不変':True,'保存点停止':proof['保存点停止'],'Reader停止':proof['Reader停止'],'停止前確認':{'path':str(review.resolve()),'sha256':sha},'主人工':17,'人工の小結果':small,'実API':'検算する.py --request ABS --sha SHA --session ID --out NEWABS [--metadata-only]','独立初回性対象':'監視適格実XC/XQ保有窓の全採用原行、H100最初起動、life初arm/警戒/ラッチ/要求、要求後の最初正常返済fill','全Raw自然市場の初回性監査':False,'P100全床/全追尾幅Raw再形成':False,'自然Raw/市場Native/価格CSV/11月09本文':False,'金融再実行':False,'研究目標達成':False,'採用':False})


def main() -> None:
    """
    機能: 人工確認とRootレビュー後停止を別操作として扱う。
    引数: CLI check-output(Path)又はstop(bool)/review(Path)/review-sha(str)。返り値: None。
    """
    p=argparse.ArgumentParser();p.add_argument('--check-output',type=Path);p.add_argument('--stop',action='store_true');p.add_argument('--review',type=Path);p.add_argument('--review-sha');a=p.parse_args()
    if a.stop:A.need(a.check_output is None and a.review is not None and a.review_sha,'Rootレビューの指定が必要');value=stop(a.review,a.review_sha)
    else:A.need(a.check_output is not None and a.review is None and a.review_sha is None,'停止前確認先だけを指定');value=check(a.check_output)
    print(json.dumps(value,ensure_ascii=False))


if __name__=='__main__':main()
