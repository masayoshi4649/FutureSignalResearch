"""Raw消費は保存点成功と別のRoot固定要求からだけ許可する。metadata-onlyはNative/Raw未読。"""
from pathlib import Path
import hashlib
import json

from 独立参照 import A,S,ROOT,SAVED,STOPS

HERE=Path(__file__).resolve().parent
READER=ROOT/'work/116原板の原行を独立配送する/停止.json'
READER_SHA='82806b85f939d9ba67190cee10bedbff9d3a8ecade47886a9862bdb0f940cf14'
F1_SHA='4c76a5f7cd8a59962e885cadf6885cfc75cbc590675955cb8e72ae2d0b8bb372'


def same(a: dict,b: dict) -> bool:
    """
    機能: 絶対解決pathとSHAだけでFileRefの同体を比較する。
    引数: a/b(dict)。返り値: bool。bytes追加とslash表記差だけは同体を変えない。
    """
    return Path(a['path']).is_absolute() and Path(b['path']).is_absolute() and Path(a['path']).resolve()==Path(b['path']).resolve() and a['sha256']==b['sha256']


def reference(ref: dict,before: dict) -> Path:
    """
    機能: Root参照の実物SHAを認証し、前後同体の台帳へ結ぶ。
    引数: ref/before(dict)。返り値: Path。Native/Rawの呼出しは実段階まで上位が行わない。
    """
    p=Path(ref['path']);A.need(p.is_absolute() and len(ref['sha256'])==64,'Root絶対FileRef');p=p.resolve();A.equal(S.digest(p),ref['sha256'],'消費者の参照SHA');before[str(p)]=ref['sha256'];return p


def metadata(ref: dict,before: dict) -> dict:
    """
    機能: Native/Raw以外の小metadataだけを指紋認証して読む。
    引数: ref/before(dict)。返り値: dict。gzip/jsonl/csvを拒否する。
    """
    A.need(Path(ref['path']).suffix=='.json' and '.Native.' not in Path(ref['path']).name,'小metadataだけ');return S.load(reference(ref,before))


def prepare(path: Path,sha: str,output: Path,session: str) -> dict:
    """
    機能: 同F1金融・新型保存成功・GoReader固定と新consumer停止を本文前に結ぶ。
    引数: path/output(Path)、sha/session(str)。返り値: dictは一場の許可計画。Rawのopen/statなし。
    """
    A.need(output.is_absolute() and not output.exists(),'Raw監査は新規絶対出力');before={};q=metadata({'path':str(path.resolve()),'sha256':sha},before)
    A.need(q['version']==1 and q['trial']==116 and q['fixed'] is True and q['raw_read_authorized'] is True and q['market_native_read_authorized'] is True and q['holdout_read_authorized'] is False,'別Root固定のRaw/Native許可。11月09不可')
    A.need(q['stage'] in ('first2','full70'),'Raw先頭2→全70だけ');A.equal(q['condition']['sha256'],F1_SHA,'同116F1')
    stop=metadata(q['consumer_stop'],before);A.need(stop['成功'] and stop['停止'] and stop['市場前'] and stop['試行']==116,'consumer市場前停止')
    for field in ('所有ファイルSHA256','依存コードSHA256'):
        for filename,expected in stop[field].items():A.need(Path(filename).suffix not in ('.gz','.csv','.jsonl'),'コードへ市場本文を混ぜない');reference({'path':filename,'sha256':expected},before)
    own=stop['所有ファイルSHA256'];A.equal(own.get(str(Path(__file__).resolve())),S.digest(Path(__file__).resolve()),'実consumerゲート自身の停止')
    for name,expected in STOPS.items():A.equal(stop['保存点停止'][name]['sha256'],expected,'新型保存停止への連鎖/'+name)
    reader=metadata(q['reader_request'],before);A.need(reader['version']==1 and reader['trial']==116 and reader['fixed'] is True and reader['raw_read_authorized'] is True and reader['stage']==q['stage'] and reader['policy']=='NK225_source_rows_lifecycle116_v1','同Root Reader固定')
    A.equal(reader['reader_stop']['sha256'],READER_SHA,'停止済GoReader');A.need(same(reader['reader_stop'],{'path':str(READER),'sha256':READER_SHA}),'同Reader停止のpath');rstop=metadata(reader['reader_stop'],before)
    A.need(rstop['成功'] and rstop['停止'] and rstop['市場前'] and rstop['試行']==116,'Reader停止schema');A.need(same(reader['executable'],rstop['実行物']),'停止した実Reader exe');reference(reader['executable'],before)
    expected_code={**rstop['全固定コードSHA256'],**rstop['所有コードSHA256'],reader['reader_stop']['path']:reader['reader_stop']['sha256']};A.equal(reader['code_sha256'],expected_code,'実Reader停止の全コード閉包')
    for filename,expected in reader['code_sha256'].items():A.need(Path(filename).suffix not in ('.gz','.csv','.jsonl'),'Readercodeへ市場本文なし');reference({'path':filename,'sha256':expected},before)
    refs=reader['refs']
    for label,name in (('financial_condition','condition'),('financial_completion','completion'),('independent_result','independent_result'),('independent_check','independent_check')):A.need(same(refs[label],q[name]),'Readerとconsumerの上流同体/'+name)
    A.equal(refs['lifecycle_audit_stop']['sha256'],STOPS['ライフ停止.json'],'Readerは新型ライフ停止に結合')
    condition=metadata(q['condition'],before);completion=metadata(q['completion'],before);result=metadata(q['independent_result'],before);check=metadata(q['independent_check'],before);save=metadata(q['save_request'],before)
    expected=2 if q['stage']=='first2' else 70
    A.need(condition['trial']==116 and condition['fixed'] and condition['actual_configurations']==list(A.CONFIGS),'全36の同金融固定')
    core=metadata(condition['runtime_stop'],before)
    A.need(core['成功'] is True and core['停止'] is True and core['trial']==116 and core['自己コード全依存前後不変'] is True and type(core['Raw/市場Native/実価格CSV/11月09本文読取']) is int and core['Raw/市場Native/実価格CSV/11月09本文読取']==0,'実Core停止の整数未読件数schema')
    A.need(completion['success'] and completion['trial']==116 and completion['stage']==q['stage'] and completion['condition_sha256']==F1_SHA and completion['sessions']==expected and completion['books']==36*expected and completion['unchanged'],'同stage金融全成功')
    for value in (result,check):
        A.need(value['成功'] and value['試行']==116 and value['stage']==q['stage'] and value['場数']==expected and value['会計数']==36*expected and value['前後不変'],'保存点独立全成功')
        A.equal(value['金融条件SHA256'],q['condition']['sha256'],'同F1保存点成功');A.equal(value['金融完了SHA256'],q['completion']['sha256'],'同金融完了保存点成功');A.equal(value['保存器停止SHA256'],STOPS['会計停止.json'],'実保存は新型停止');A.equal(value['独立P停止SHA256'],STOPS['P停止.json'],'実保存のP停止');A.equal(value['独立ライフ停止SHA256'],STOPS['ライフ停止.json'],'実保存のlife停止');A.equal(value['Root保存要求SHA256'],q['save_request']['sha256'],'実Root保存要求に結合')
    A.need(save['trial']==116 and save['fixed'] and same(save['condition'],q['condition']) and same(save['completion'],q['completion']) and save['code_stop']['sha256']==STOPS['会計停止.json'],'Rootが実行した新型保存要求')
    sessions=[x['session'] for x in completion['results']];A.equal([x['session'] for x in reader['scenes']],sessions,'Readerと金融の全場順');A.equal([x['session'] for x in q['scenes']],sessions,'consumerと金融の全場順');A.need(session in sessions and not session.startswith('2026-11-09'),'当Rootが指定した一場だけ')
    task=next(x for x in q['scenes'] if x['session']==session);financial=next(x for x in completion['results'] if x['session']==session);scene=next(x for x in reader['scenes'] if x['session']==session)
    A.need(same(task['native'],financial['native']),'金融成功の当場Native');A.need(Path(task['native']['path']).name==session+'.Native.json.gz','当場Native本名');A.equal(scene['reference'],'NK225','Raw対象市場')
    return {'request':q,'before':before,'output':output,'task':task,'reader':reader,'scene':scene,'definition':condition['lifecycle_definition']}
