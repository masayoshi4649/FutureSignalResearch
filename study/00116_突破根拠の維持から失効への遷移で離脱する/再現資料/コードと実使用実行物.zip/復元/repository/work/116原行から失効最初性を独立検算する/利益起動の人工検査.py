"""H100独立式を手計算・位相・同秒原行の人工だけで検査する。"""
from decimal import Decimal
from pathlib import Path
import hashlib
import importlib.util
import json
import unittest

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "利益起動の独立式.py"
SPEC = importlib.util.spec_from_file_location("activation116_independent", SOURCE)
MODEL = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODEL)
Activation = MODEL.Activation


def quote(index: int, bid=1101, ask=1102, time=1000, ok: bool = True) -> dict:
    """
    機能: 市場を読まない同秒別原行の手製気配を作る。
    引数: index(int)、bid/ask/time(数値)、ok(bool)は原行と価格/正常旗。
    返り値: dictは価格時計・採用Index・物理行・生BBO。
    """
    return {"time": time, "index": index, "source_line": index + 100,
            "last": bid, "bid": bid, "ask": ask, "quote_ok": ok}


class ActivationTests(unittest.TestCase):
    def test_equality_and_first_witness(self):
        """
        機能: W=10,000の等号で初回だけ起動し、保存値の参照分離を検査する。
        引数: self(ActivationTests)。返り値: None。実市場の価格刻みは仮定しない。
        """
        state = Activation(1, 1, 1000, 0)
        q = quote(1, Decimal("1100.77"), Decimal("1101.77"))
        first = state.observe(q, "pre_fill", 1, 0)
        self.assertEqual(first["whole_net_yen"], Decimal(10000))
        self.assertEqual(first["round_trip_cost_yen"], Decimal(77))
        q["bid"] = 1
        first["whole_net_yen"] = 0
        exported = state.first
        exported["quote"]["bid"] = 2
        self.assertEqual(state.first["quote"]["bid"], Decimal("1100.77"))
        self.assertEqual(state.first["whole_net_yen"], Decimal(10000))
        self.assertIsNone(state.observe(quote(2, 900, 901), "pre_fill", 1, 0))
        self.assertTrue(state.active)

    def test_below_then_same_second_next_index(self):
        """
        機能: 閾値未満と同秒別原行での初回到達を分ける。
        引数: self(ActivationTests)。返り値: None。
        """
        state = Activation(1, 1, 1000, 0)
        self.assertIsNone(state.observe(quote(1, 1100, 1101), "pre_fill", 1, 0))
        self.assertFalse(state.active)
        first = state.observe(quote(2), "pre_fill", 1, 0)
        self.assertEqual(first["whole_net_yen"], Decimal(10023))
        self.assertEqual(first["quote"]["index"], 2)

    def test_sell_mirror(self):
        """
        機能: 買Bidと売Askを反射した同じ条件で計算する。
        引数: self(ActivationTests)。返り値: None。
        """
        buy, sell = Activation(2, 1, 1000, 0), Activation(2, -1, 2000, 0)
        b = buy.observe(quote(1, 1101, 1102), "after_source", 2, 0)
        s = sell.observe(quote(1, 1898, 1899), "after_source", 2, 0)
        self.assertEqual(b["whole_net_yen"], Decimal(20046))
        self.assertEqual(b["whole_net_yen"], s["whole_net_yen"])
        self.assertEqual(s["mark_price"], Decimal(1899))

    def test_cost_is_round_trip_once(self):
        """
        機能: 追加片道5ptを往復1,000円として手数料77へ一度だけ加える。
        引数: self(ActivationTests)。返り値: None。
        """
        state = Activation(1, 1, 1000, 5)
        self.assertIsNone(state.observe(quote(1, 1110, 1111), "pre_fill", 1, 0))
        first = state.observe(quote(2, 1111, 1112), "pre_fill", 1, 0)
        self.assertEqual(first["round_trip_cost_yen"], Decimal(1077))
        self.assertEqual(first["whole_net_yen"], Decimal(10023))

    def test_partial_realized_and_initial_quantity(self):
        """
        機能: 部分返済後のR/nを使い、H分母は実初期4枚へ固定する。
        引数: self(ActivationTests)。返り値: None。
        """
        state = Activation(4, 1, 1000, 0)
        q = quote(1, 900, 901)
        self.assertIsNone(state.observe(q, "pre_fill", 2, 50000))
        self.assertFalse(state.active)  # 50,000 + 2*(-10,077) = 29,846 < 40,000。
        first = state.observe(q, "after_source", 2, 60154)
        self.assertEqual(first["whole_net_yen"], Decimal(40000))
        self.assertEqual(first["threshold_yen"], Decimal(40000))
        self.assertEqual(first["initial_quantity"], 4)

    def test_close_row_pre_fill_and_flat_after_source(self):
        """
        機能: 閉鎖原行pre_fillの保有評価と、after_source実flatを区別する。
        引数: self(ActivationTests)。返り値: None。
        """
        q = quote(1)
        state = Activation(1, 1, 1000, 0)
        first = state.observe(q, "pre_fill", 1, 0)
        self.assertEqual(first["phase"], "pre_fill")
        self.assertIsNone(state.observe(q, "after_source", 0, 10023))
        self.assertEqual(state.first["phase"], "pre_fill")
        unactivated = Activation(1, 1, 1000, 0)
        self.assertIsNone(unactivated.observe(q, "after_source", 0, 50000))
        self.assertFalse(unactivated.active)

    def test_bad_bbo_and_raw_flag(self):
        """
        機能: 生旗偽・同値・非正・非有限BBOで新起動しない。
        引数: self(ActivationTests)。返り値: None。生価格を0に置換しない。
        """
        for q in (quote(1, ok=False), quote(1, 1101, 1101), quote(1, -1, 1102),
                  quote(1, float("nan"), 1102), quote(1, 1101, float("inf"))):
            state = Activation(1, 1, 1000, 0)
            self.assertIsNone(state.observe(q, "pre_fill", 1, 100000))
            self.assertFalse(state.active)

    def test_row_and_phase_rejection_does_not_activate(self):
        """
        機能: 同原行の二重評価・逆位相・時刻/物理行後退を拒否する。
        引数: self(ActivationTests)。返り値: None。
        """
        for kind in ("重複", "逆位相", "時刻後退", "物理行後退", "別気配", "n超過"):
            state = Activation(1, 1, 1000, 0)
            q = quote(1, 1000, 1001)
            state.observe(q, "after_source", 1, 0)
            bad, phase, n = quote(2), "pre_fill", 1
            if kind == "重複": bad, phase = q, "after_source"
            if kind == "逆位相": bad = q
            if kind == "時刻後退": bad["time"] -= 1
            if kind == "物理行後退": bad["source_line"] = q["source_line"]
            if kind == "別気配": bad = quote(1)
            if kind == "n超過": n = 2
            with self.assertRaises(ValueError): state.observe(bad, phase, n, 0)
            self.assertFalse(state.active)
            self.assertIsNone(state.first)


def run_checks() -> dict:
    """
    機能: 手計算8主人工を実行し、所有2コードの前後指紋を返す。
    引数: なし。返り値: dictは成功/件数/所有不変。市場・Go・停止は実行しない。
    """
    files = [SOURCE, Path(__file__).resolve()]
    before = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(ActivationTests))
    after = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
    if not result.wasSuccessful() or result.testsRun != 8 or before != after:
        raise ValueError("利益起動の人工又は所有前後差")
    return {"試行": 116, "成功": True, "市場前": True, "主人工": 8,
            "所有コードSHA256": before, "所有コード前後不変": True,
            "市場/Raw/Native/CSV/11月09本文読取": 0, "Go呼出": False, "正式停止": False}


if __name__ == "__main__":
    print(json.dumps(run_checks(), ensure_ascii=False, indent=2))
