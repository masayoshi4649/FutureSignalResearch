# 116の保有根拠と失効を結ぶ連続比較

2026-11-10。停止115の所有コードを独立コピーして派生した。Source111・純入口115・三時間軸bank115・P113/P100は変更しない。新しい純entrylife116とActor116だけを接続する。金融固定前・市場未実行であり、人工成功は収益改善ではない。

## 範囲と配送

A0/T/TR入口×X0/XC/XQ×追加片道滑り0/5pt×追加価格時計遅延0/1秒の36口座。X0は旧115の全12口座を同じ本名で維持する。XC/XQは `A0_XC_C0_D0` 等の本名とし、入口・共通保護・追加失効を混同しない。miniは片側各10枚、片道38.5円、100円/pt。Sourceの新規原行時計とセッション完結を維持する。

各Source受理Rawで、旧3分P100公表と5/15/30入口公表をそれぞれ既存bankへ進める。同原行の全公表を揃えた最新Snapshotを `SetLifecycleSnapshot` へ先に値配送し、new通知のある行だけ既115の `SetEntrySnapshot` で入口をfreezeしてから `OnNativeStep` を呼ぶ。最新Snapshotは値型で、毎Rawの巨大なJSON往復コピーはしない。

既予約fill→Source通知/予約→P100 after_source→追加lifeの順で、X0は追加監視を無効にする。XC/XQも実n=0となった後に新しい技術評価を作らない。最終実所有と最後の保有中Pure Stateは別に保存する。中間の古い5分公表を遡及評価せず、最終latestだけを使う。

`Actual.entry_publications` は全公表を元順に保存、`entry_gate_events` は全new出生原行のsnapshotだけ。`lifecycle_delivery_rows==counts.rows` と小さい `lifecycle_definition` を保存し、Root固定定義へ全値結合する。これだけを独立の全Raw初回性の証明とは呼ばない。

## 対照と固定ゲート

旧115全70の金融条件94bb…・成功8bba…・正式Native台帳04c8…を固定参照する。各場Source111の全文とX0全12の入口票/許可/数量/注文/fill/所有/費用/marks/P100全保存Stateを比較する。LifeMode=X0とScope説明・無効life欄だけを検査後に差分説明へ分離する。原S0との比較ではない。

金融条件はtrial116で固定し、旧試行へ偽装しない。依存停止はsource/chart/core115/entry_input/pure/entry_gate/entry_chart/actor/lifecycleの9。実CLIの閉包とexe、P100/入口/bank/life/36口座の実宣言を認証する。旧入力口は既停止SHAの成功・前後不変・金融実行0として扱う。11/09の価格・損益・入力指紋を台帳へ追加しない。

first2=2場72口座、base54=54場1,944口座、full70=70場2,520口座。同116F1で成功した54場を認証再用し、追加16場だけ再生する。115成功や別F1のNativeを116の結果として再用しない。54場の元166再実行Event参照は同じものを使い、当時保存全文や市場全tick State同体とは区別する。

## 人工と独立検査

入口/前史/未知/買売鏡像の6系列216冊に加え、実bankからHistと固定境界の失効を発生させる2系列72冊を出力する。後者は全XC/XQ48口座で追加返済・P100外部予約再同期・最終実所有の正例を通す。価格足もRaw風気配も手製で、自然FAR生成・市場実績ではない。X0は各系列で旧115全12を終端比較し、各原行の対照はActor人工で別に確認する。

metadata人工は旧成功の小metadataと手製Native印だけを使い、Raw/価格CSV/自然Nativeの本文を読まない。36本名・12対照・全Raw配送の欠落やlife定義差、前史/当場未来の分離、実行中exe/閉包差、元54成功と子I/O順序・失敗・再用を検査する。並列人工は認証済み計画後のassemble位相だけを扱う。

独立Pythonの保存点/公表asof/会計検査と、全RawのX発生漏れ・最初性は別証拠。後者は明示したRoot Raw要求から別Reader/consumerで確認し、このGo人工をその成功へ広げない。新Xが作用した人工と、作用しない対照を両方残す。

## CLI

```powershell
116連続比較.exe --fixed <Root固定JSON> --fixed-sha <SHA256> --stage metadata-only
116連続比較.exe --fixed <同F1> --fixed-sha <SHA256> --stage first2 --out <新規先> --workers 16
116連続比較.exe --fixed <同F1> --fixed-sha <SHA256> --stage base54 --out <新規先> --workers 16
116連続比較.exe --fixed <同F1> --fixed-sha <SHA256> --stage full70 --prior54 <同F1の54成功> --prior54-sha <SHA256> --out <新規先> --workers 16
```

未固定条件、別exe、未停止部品、違う宣言、未完結54、既使用出力先は拒否する。停止helperは市場前の人工/test/vet/build/API/閉包だけを実行し、金融の素材はfixed:falseで出す。Rootが別F1を事前固定してから市場再生へ進む。
