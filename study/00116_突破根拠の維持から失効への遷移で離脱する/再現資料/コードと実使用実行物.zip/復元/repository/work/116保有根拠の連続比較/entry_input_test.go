package lifecomparison116

import (
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"testing"
	"time"

	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

// csv115 は一場の人工5分CSVを作り、実入力契約と同じ列で認証します。
//
// 引数: t(*testing.T)、directory/id(string)、change(float64)は人工保存先と末尾差です。
// 返り値: source.InputCaseは人工CSVだけを参照する場です。
func csv115(t *testing.T, directory, id string, change float64) source.InputCase {
	t.Helper()
	clock, err := source.SessionFor(id)
	if err != nil {
		t.Fatal(err)
	}
	text := "time,open,high,low,close,volume,volume_complete,closed\n"
	total := int((clock.End - clock.Start) / 300)
	for i := 0; i < total; i++ {
		p := 1000 + float64(i)
		if i == total-1 {
			p += change
		}
		at := time.Unix(int64(clock.Start)+int64(i*300), 0).Format(time.RFC3339)
		text += fmt.Sprintf("%s,%.0f,%.0f,%.0f,%.0f,1,true,true\n", at, p, p+2, p-1, p+1)
	}
	name := id + ".csv"
	path := filepath.Join(directory, name)
	if err = os.WriteFile(path, []byte(text), 0644); err != nil {
		t.Fatal(err)
	}
	sha, err := source.Digest(path)
	if err != nil {
		t.Fatal(err)
	}
	return source.InputCase{ID: id, Contract: "人工限月", Files: map[string]source.InputFile{"NK225_candle_300": {Path: name, SHA256: sha, Size: int64(len([]byte(text)))}}}
}

// TestEntryPrefixAndCurrentIsolation は前史種へ当場の未来終値が混じらないことを確認します。
//
// 引数: t(*testing.T)は人工器です。返り値: なし。共有のCSVは読みません。
func TestEntryPrefixAndCurrentIsolation(t *testing.T) {
	directory := t.TempDir()
	previous := csv115(t, directory, "2026-09-21_Night", 0)
	current := csv115(t, directory, "2026-09-22_Day", 0)
	p := RunPlan{Fixed: Fixed{Trial: 116, Fixed: true, EntryInputModel: EntryInputModel}, Source: source.RunPlan{Manifest: source.InputManifest{Root: directory, Sessions: []source.InputSession{previous, current}}, Cases: []source.InputCase{previous, current}}}
	first, err := PrepareEntryInput(p, 0)
	if err != nil {
		t.Fatal(err)
	}
	if first.Input.Seed != nil || len(first.Prior) != 0 {
		t.Fatal("最初の場へ架空seed")
	}
	result, err := PrepareEntryInput(p, 1)
	if err != nil {
		t.Fatal(err)
	}
	if len(result.Prior) != 1 || result.Audit.PriorSessions != 1 || result.Input.Seed == nil || result.Audit.InputSeed.Old.Session.ID != previous.ID {
		t.Fatal("前史境界差")
	}
	// ----------------------------------------
	// 各尺度の末尾足は足終+60が予定Endを超すため、履歴本数へ加えない。
	if result.Audit.InputSeed.Old.HistoryBars != [3]uint64{155, 51, 25} {
		t.Fatal("予定Endまでの前史本数", result.Audit.InputSeed.Old.HistoryBars)
	}
	oldSeed := *result.Audit.InputSeed
	changed := csv115(t, directory, current.ID, 500)
	p.Source.Manifest.Sessions[1] = changed
	p.Source.Cases[1] = changed
	after, err := PrepareEntryInput(p, 1)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(oldSeed, *after.Audit.InputSeed) || result.Audit.PriorNodesSHA256 != after.Audit.PriorNodesSHA256 {
		t.Fatal("当場未来価格が過去seedを変更")
	}
	if result.Audit.ChildrenSHA256 == after.Audit.ChildrenSHA256 {
		t.Fatal("人工未来差の未到達")
	}
	if _, err = PrepareEntryInput(p, 2); err == nil {
		t.Fatal("対象範囲外を受理")
	}
	p.Fixed.EntryInputModel = "未宣言"
	if _, err = PrepareEntryInput(p, 0); err == nil {
		t.Fatal("モデル差を受理")
	}
}

// TestBeginRejectsUnboundScene は別場の入口を保護用Sourceへ結ばないことを確認します。
//
// 引数: t(*testing.T)は人工器です。返り値: なし。
func TestBeginRejectsUnboundScene(t *testing.T) {
	input := input115(t, 1, false, 0)
	input.Session = frame.Session{ID: "別場"}
	c := NewWithEntry(input)
	if err := c.Begin(source.SourceCase{Session: session94(), Contract: "人工限月"}); err == nil {
		t.Fatal("別場入口を受理")
	}
}
