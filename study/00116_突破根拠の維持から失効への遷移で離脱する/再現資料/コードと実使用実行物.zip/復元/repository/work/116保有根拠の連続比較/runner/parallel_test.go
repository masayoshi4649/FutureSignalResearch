package parallel116

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"sync/atomic"
	"testing"
	"time"

	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	core "github.com/masayoshi4649/SessionTradeExecuter/lifecomparison116"
)

// clone は人工の可変参照を分離します。
//
// 引数: value(T)はJSON保存可能な人工値です。
// 返り値: Tは独立した複写です。
func clone[T any](value T) T {
	raw, _ := json.Marshal(value)
	var out T
	if err := json.Unmarshal(raw, &out); err != nil {
		panic(err)
	}
	return out
}

// handPlan はRawを作らない70場metadataから段階別の手製計画を作ります。
//
// 引数: t(*testing.T)、stage(string)は試験器と段階です。
// 返り値: Planはcallback専用で市場金融の認証済み計画ではありません。
func handPlan(t *testing.T, stage string) Plan {
	t.Helper()
	base := t.TempDir()
	file, err := saveNew(filepath.Join(base, "固定metadata.json"), map[string]any{"人工": true}, false)
	if err != nil {
		t.Fatal(err)
	}
	cases := []source.InputCase{}
	day, _ := time.Parse("2006-01-02", "2026-09-21")
	for len(cases) < 70 {
		if day.Weekday() != time.Saturday && day.Weekday() != time.Sunday {
			for _, kind := range []string{"Day", "Night"} {
				cases = append(cases, source.InputCase{ID: day.Format("2006-01-02") + "_" + kind})
			}
		}
		day = day.AddDate(0, 0, 1)
	}
	n := map[string]int{"first2": 2, "base54": 54, "full70": 70}[stage]
	p := Plan{Core: core.RunPlan{Stage: stage, Source: source.RunPlan{Stage: stage, Condition: file, Cases: cases[:n], Before: map[string]string{file.Path: file.SHA256}},
		Fixed: core.Fixed{Golden: map[string]source.FileRef{}}, LegacyNatives: map[string]source.FileRef{}}}
	for _, input := range cases[:54] {
		p.Core.Fixed.Golden[input.ID] = file
	}
	for _, input := range cases {
		p.Core.LegacyNatives[input.ID] = file
	}
	return p
}

// handWorker は金融を呼ばず一子のI/O完了だけを作ります。
//
// 引数: p(Plan)、job(Job)は手製計画と当子です。
// 返り値: WorkerCompletion/errorは人工Nativeと保存完了です。
func handWorker(p Plan, job Job) (WorkerCompletion, error) {
	if _, err := newDirectory(job.Out); err != nil {
		return WorkerCompletion{}, err
	}
	ref, err := saveNew(filepath.Join(job.Out, job.Input.ID+".Native.json.gz"), map[string]any{"人工": true, "金融": false, "session": job.Input.ID}, true)
	if err != nil {
		return WorkerCompletion{}, err
	}
	var proof *source.GoldenProof
	if job.Index < 54 {
		methods := 1
		if job.Index%2 == 1 {
			methods = 2
		}
		proof = &source.GoldenProof{ReferenceKind: "rerun_original166_pinned_code", MiniEventsEqual: true, Reference: p.Core.Fixed.Golden[job.Input.ID],
			Session: job.Input.ID, Methods: methods, EventsEqual: true}
	}
	value := WorkerCompletion{Version: 1, Trial: 116, Success: true, Stage: p.Core.Stage, Session: job.Input.ID, ConditionSHA256: p.Core.Source.Condition.SHA256,
		Result: core.SceneResult{Session: job.Input.ID, Native: ref, Golden: proof, Books: 36, X0Comparisons: 12, X0Equal: true, Complete: true, Reference115: p.Core.LegacyNatives[job.Input.ID], Reference115Comparisons: 12, Reference115Equal: true, Source111Equal: true},
		Before: clone(p.Core.Source.Before), After: clone(p.Core.Source.Before), Unchanged: true}
	_, err = saveNew(filepath.Join(job.Out, "完了.json"), value, false)
	return value, err
}

// TestPoolParallelismAndPlannedOrder は同時上限と完了順に依存しない予定順を検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。人工54場を金融として評価しません。
func TestPoolParallelismAndPlannedOrder(t *testing.T) {
	p := handPlan(t, "base54")
	var active, peak atomic.Int32
	cb := func(ctx context.Context, job Job) (WorkerCompletion, error) {
		now := active.Add(1)
		defer active.Add(-1)
		for old := peak.Load(); now > old; old = peak.Load() {
			if peak.CompareAndSwap(old, now) {
				break
			}
		}
		select {
		case <-ctx.Done():
			return WorkerCompletion{}, ctx.Err()
		case <-time.After(time.Duration(5-job.Index%5) * time.Millisecond):
		}
		return handWorker(p, job)
	}
	value, err := assemble(p, 8, filepath.Join(t.TempDir(), "親"), cb)
	if err != nil || !value.Success || value.Books != 1944 || value.OriginalMethods != 81 || value.ReplayedSessions != 54 {
		t.Fatal(err)
	}
	if peak.Load() < 2 || peak.Load() > 8 || value.ParallelWorkers != 8 {
		t.Fatal("同時上限", peak.Load())
	}
	for i, row := range value.Results {
		if row.Session != p.Core.Source.Cases[i].ID {
			t.Fatal("完了順を採用")
		}
	}
	first := handPlan(t, "first2")
	small, err := assemble(first, 16, filepath.Join(t.TempDir(), "先頭2"), func(_ context.Context, j Job) (WorkerCompletion, error) { return handWorker(first, j) })
	if err != nil || small.ParallelWorkers != 2 || small.Books != 72 {
		t.Fatal("先頭2のmin同時数", err)
	}
}

// TestPoolFailuresAndExistingPaths は子失敗・保存差・場/指紋差・既存先を成功へ補いません。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。全て手製callbackです。
func TestPoolFailuresAndExistingPaths(t *testing.T) {
	for _, mode := range []string{"子失敗", "保存完了欠落", "別場", "固定前後差", "残予約", "旧対照不足", "旧源差", "子Native外部", "Native破壊", "返却保存差", "固定入力破壊"} {
		t.Run(mode, func(t *testing.T) {
			p := handPlan(t, "first2")
			out := filepath.Join(t.TempDir(), "親")
			value, err := assemble(p, 2, out, func(_ context.Context, j Job) (WorkerCompletion, error) {
				if mode == "子失敗" {
					return WorkerCompletion{}, fmt.Errorf("人工の子失敗")
				}
				v, e := handWorker(p, j)
				if e != nil {
					return v, e
				}
				switch mode {
				case "保存完了欠落":
					_ = os.Remove(filepath.Join(j.Out, "完了.json"))
				case "別場":
					v.Session = "別の場"
				case "固定前後差":
					v.After = map[string]string{}
				case "残予約":
					v.Result.PendingQuantity = 1
				case "旧対照不足":
					v.Result.Reference115Comparisons = 11
				case "旧源差":
					v.Result.Source111Equal = false
				case "子Native外部":
					v.Result.Native.Path = p.Core.Source.Condition.Path
				case "Native破壊":
					if e = os.WriteFile(v.Result.Native.Path, []byte("人工の破壊"), 0600); e != nil {
						return v, e
					}
				case "返却保存差":
					if e = os.WriteFile(filepath.Join(j.Out, "完了.json"), []byte("{}\n"), 0600); e != nil {
						return v, e
					}
				case "固定入力破壊":
					if j.Index == 0 {
						if e = os.WriteFile(p.Core.Source.Condition.Path, []byte("人工の固定差\n"), 0600); e != nil {
							return v, e
						}
					}
				}
				return v, nil
			})
			if err == nil || value.Success {
				t.Fatal("不完了を全体成功へ補完")
			}
			if _, e := os.Stat(filepath.Join(out, "不完了.json")); e != nil {
				t.Fatal(e)
			}
			if _, e := os.Stat(filepath.Join(out, "完了.json")); !os.IsNotExist(e) {
				t.Fatal("失敗後の成功ファイル")
			}
		})
	}
	p := handPlan(t, "first2")
	cb := func(_ context.Context, j Job) (WorkerCompletion, error) { return handWorker(p, j) }
	out := t.TempDir()
	if _, err := assemble(p, 2, out, cb); err == nil {
		t.Fatal("既存親先を上書き")
	}
	p.Core.Source.Cases[1].ID = p.Core.Source.Cases[0].ID
	if _, err := assemble(p, 2, filepath.Join(t.TempDir(), "重複"), cb); err == nil {
		t.Fatal("場重複を受理")
	}
}

// TestPoolValidationRejectsWrongCounts は36会計と全X0の12対照を独立して要求します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。115由来の旧12/4を誤受理しない人工だけを行います。
func TestPoolValidationRejectsWrongCounts(t *testing.T) {
	for _, mode := range []string{"旧12会計", "旧4対照", "新失効を旧対照へ混入", "別金融条件", "別旧Native", "元Event不足"} {
		t.Run(mode, func(t *testing.T) {
			p := handPlan(t, "first2")
			job := Job{Index: 0, Input: p.Core.Source.Cases[0], Out: filepath.Join(t.TempDir(), "子")}
			value, err := handWorker(p, job)
			if err != nil {
				t.Fatal(err)
			}
			switch mode {
			case "旧12会計":
				value.Result.Books = 12
			case "旧4対照":
				value.Result.X0Comparisons = 4
			case "新失効を旧対照へ混入":
				value.Result.Reference115Comparisons = 36
			case "別金融条件":
				value.ConditionSHA256 = "別条件"
			case "別旧Native":
				value.Result.Reference115.SHA256 = "別旧Native"
			case "元Event不足":
				value.Result.Golden.Methods = 2
			}
			if err = validateWorker(p, job, value); err == nil {
				t.Fatal("36会計/12対照の固定差を受理")
			}
		})
	}
}

// TestPoolPartialFailureIsIncomplete は一子成功後の途中失敗を全体成功にしません。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。既に保存された人工一子を成功全場へ数え直しません。
func TestPoolPartialFailureIsIncomplete(t *testing.T) {
	p := handPlan(t, "first2")
	out := filepath.Join(t.TempDir(), "親")
	var calls atomic.Int32
	value, err := assemble(p, 1, out, func(_ context.Context, job Job) (WorkerCompletion, error) {
		calls.Add(1)
		if job.Index == 1 {
			return WorkerCompletion{}, fmt.Errorf("一子成功後の人工失敗")
		}
		return handWorker(p, job)
	})
	if err == nil || value.Success || calls.Load() != 2 {
		t.Fatal("途中失敗を全体成功へ補完")
	}
	if _, err = os.Stat(filepath.Join(out, "worker", p.Core.Source.Cases[0].ID, "完了.json")); err != nil {
		t.Fatal("先行成功の人工子がない", err)
	}
	if _, err = os.Stat(filepath.Join(out, "完了.json")); !os.IsNotExist(err) {
		t.Fatal("途中失敗後に親成功を保存")
	}
}

// TestPoolRechecksNativeAfterChildren は認証済み子のNative後改変も最後に拒否します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。原板や金融Nativeではなく人工出力だけを破壊します。
func TestPoolRechecksNativeAfterChildren(t *testing.T) {
	p := handPlan(t, "first2")
	out := filepath.Join(t.TempDir(), "親")
	var firstNative string
	value, err := assemble(p, 1, out, func(_ context.Context, job Job) (WorkerCompletion, error) {
		v, e := handWorker(p, job)
		if e != nil {
			return v, e
		}
		if job.Index == 0 {
			firstNative = v.Result.Native.Path
		} else {
			e = os.WriteFile(firstNative, []byte("先行子認証後の人工破壊"), 0600)
		}
		return v, e
	})
	if err == nil || value.Success {
		t.Fatal("子認証後のNative変更を全体成功")
	}
}

// TestPoolRejectsInvalidPlan は同時上限・段階・集合・接続の不正を本文前に拒否します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。callbackは不正計画では一度も呼ばれません。
func TestPoolRejectsInvalidPlan(t *testing.T) {
	for _, mode := range []string{"上限0", "上限17", "場不足", "段階違い", "親階層ID", "接続なし"} {
		t.Run(mode, func(t *testing.T) {
			p := handPlan(t, "first2")
			workers := 2
			var called atomic.Int32
			cb := Callback(func(_ context.Context, job Job) (WorkerCompletion, error) {
				called.Add(1)
				return handWorker(p, job)
			})
			switch mode {
			case "上限0":
				workers = 0
			case "上限17":
				workers = 17
			case "場不足":
				p.Core.Source.Cases = p.Core.Source.Cases[:1]
			case "段階違い":
				p.Core.Stage = "metadata-only"
			case "親階層ID":
				p.Core.Source.Cases[0].ID = "../外部"
			case "接続なし":
				cb = nil
			}
			out := filepath.Join(t.TempDir(), "親")
			if _, err := assemble(p, workers, out, cb); err == nil || called.Load() != 0 {
				t.Fatal("不正計画で子を起動")
			}
			if _, err := os.Stat(out); !os.IsNotExist(err) {
				t.Fatal("不正計画で出力先を作成")
			}
		})
	}
}

// TestPoolFull70Reuses54 は同条件の54参照を保ち追加16だけcallbackへ配ります。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。手製54Nativeは再生又は複写しません。
func TestPoolFull70Reuses54(t *testing.T) {
	p := handPlan(t, "full70")
	old := core.Completion{Version: 1, Trial: 116, Success: true, Stage: "base54", ConditionSHA256: p.Core.Source.Condition.SHA256, Sessions: 54,
		Books: 1944, OriginalMethods: 81, ReplayedSessions: 54, Reference115Comparisons: 648, AllReference115Equal: true, AllSource111Equal: true, AllReferenceEventsEqual: true, Unchanged: true, Before: clone(p.Core.Source.Before), After: clone(p.Core.Source.Before)}
	root := t.TempDir()
	for i, input := range p.Core.Source.Cases[:54] {
		row, err := handWorker(p, Job{Index: i, Input: input, Out: filepath.Join(root, input.ID)})
		if err != nil {
			t.Fatal(err)
		}
		old.Results = append(old.Results, row.Result)
		p.Core.Source.Before[row.Result.Native.Path] = row.Result.Native.SHA256
	}
	// PrepareFixedが先行成功のBefore/Afterを認証してから、再用Native/先行成功Refを加える位相を模す。
	// 本人工はassembleの参照再用を対象とし、Root固定/金融Nativeの認証を代替しない。
	p.Core.Prior54 = &old
	priorRef, e := saveNew(filepath.Join(root, "人工base54完了.json"), old, false)
	if e != nil {
		t.Fatal(e)
	}
	p.Core.Source.Prior54Ref = &priorRef
	p.Core.Source.Before[priorRef.Path] = priorRef.SHA256
	var called atomic.Int32
	out := filepath.Join(t.TempDir(), "全70")
	result, err := assemble(p, 16, out, func(_ context.Context, j Job) (WorkerCompletion, error) {
		if j.Index < 54 {
			t.Error("元54の再生")
		}
		called.Add(1)
		return handWorker(p, j)
	})
	if err != nil || !result.Success || result.ReusedSessions != 54 || result.ReplayedSessions != 16 || called.Load() != 16 || result.Books != 2520 {
		t.Fatal(err)
	}
	for i := 0; i < 54; i++ {
		if result.Results[i].Native != old.Results[i].Native {
			t.Fatal("54の参照を変更")
		}
	}
	entries, err := os.ReadDir(filepath.Join(out, "worker"))
	if err != nil || len(entries) != 16 {
		t.Fatal("元54Nativeを複写", err)
	}
	if result.Reference115Comparisons != 840 || !result.AllReference115Equal || !result.AllSource111Equal || len(result.WorkerCompletions) != 16 {
		t.Fatal("70場の全X0対照/Source/追加16子の不足")
	}
	for _, mode := range []string{"別条件", "旧12会計", "再用Native指紋差"} {
		t.Run(mode, func(t *testing.T) {
			bad := clone(p)
			switch mode {
			case "別条件":
				bad.Core.Prior54.ConditionSHA256 = "別条件"
			case "旧12会計":
				bad.Core.Prior54.Books = 648
			case "再用Native指紋差":
				bad.Core.Prior54.Results[0].Native.SHA256 = "別指紋"
			}
			var calls atomic.Int32
			_, e := assemble(bad, 16, filepath.Join(t.TempDir(), "不正再用"), func(_ context.Context, j Job) (WorkerCompletion, error) {
				calls.Add(1)
				return handWorker(bad, j)
			})
			if e == nil || calls.Load() != 0 {
				t.Fatal("先行成功不正を追加16実行前に拒否できない")
			}
		})
	}
	p.Core.Prior54.Results[0].Golden = nil
	if _, err = assemble(p, 16, filepath.Join(t.TempDir(), "無対照"), func(_ context.Context, j Job) (WorkerCompletion, error) { return handWorker(p, j) }); err == nil {
		t.Fatal("元対照nilを受理")
	}
}

// TestWorkerRejectsBadFixed は子も本文より前の同じ固定認証で拒否されます。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。子の再生やspawnは起動しません。
func TestWorkerRejectsBadFixed(t *testing.T) {
	file, err := saveNew(filepath.Join(t.TempDir(), "未固定.json"), map[string]any{"fixed": false}, false)
	if err != nil {
		t.Fatal(err)
	}
	out := filepath.Join(t.TempDir(), "子")
	value, err := Worker(file, "first2", "2026-09-21_Day", out, nil)
	if err == nil || value.Success {
		t.Fatal("未固定子を受理")
	}
	if _, e := os.Stat(out); !os.IsNotExist(e) {
		t.Fatal("固定不正で子出力作成")
	}
}

// TestExportArtificial は停止器指定時だけI/O人工の成功参照を保存します。
//
// 引数: t(*testing.T)、環境変数PARALLEL116_ART_OUTは試験器と新規先です。
// 返り値: なし。実金融Nativeを作りません。
func TestExportArtificial(t *testing.T) {
	out := os.Getenv("PARALLEL116_ART_OUT")
	if out == "" {
		t.Skip("人工の保存先未指定")
	}
	p := handPlan(t, "first2")
	value, err := assemble(p, 16, out, func(_ context.Context, j Job) (WorkerCompletion, error) { return handWorker(p, j) })
	if err != nil || !value.Success || !reflect.DeepEqual(value.Before, value.After) {
		t.Fatal(err)
	}
}
