//go:build windows

package parallel116

import (
	"os/exec"
	"syscall"
)

// configureProcess はWindowsの子に表示窓を作りません。
//
// 引数: cmd(*exec.Cmd)は起動直前の独立workerです。
// 返り値: なし。金融・入力・原行の動作を変更しません。
func configureProcess(cmd *exec.Cmd) {
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: 0x08000000}
}
