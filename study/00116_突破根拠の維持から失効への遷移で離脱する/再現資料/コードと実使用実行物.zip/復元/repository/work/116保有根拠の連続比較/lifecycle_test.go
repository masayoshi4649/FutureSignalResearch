package lifecomparison116

import (
	"fmt"
	"os"
	"path/filepath"
	"testing"

	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	actor "github.com/masayoshi4649/SessionTradeExecuter/continuousactor116"
	legacy "github.com/masayoshi4649/SessionTradeExecuter/entrycomparison115"
	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate115"
	life "github.com/masayoshi4649/SessionTradeExecuter/entrylife116"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	bank "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

// handFailure116 は手製の突破後急落と、源通知を変えない追加失効を接続します。
//
// 引数: t(*testing.T)、side(int)は人工検査器と買売鏡像の方向です。
// 返り値: ReplayResultは市場由来でない36口座。CSV足もRaw気配も手製で、同じ源を旧115へ渡します。
func handFailure116(t *testing.T, side int) ReplayResult {
	t.Helper()
	input := input115(t, side, false, 0)
	for i := range input.Children {
		if i < 12 {
			continue
		}
		bar := &input.Children[i].OHLC
		shift := -100 * float64(side)
		bar.Open += shift
		bar.High += shift
		bar.Low += shift
		bar.Close += shift
	}
	c := NewWithEntry(input)
	old := legacy.NewWithEntry(legacy.PublicationInput{Session: input.Session, Children: input.Children, Seed: input.Seed, Audit: legacy.EntryInputAudit(input.Audit)})
	scene := source.SourceCase{Session: session94(), Contract: "人工限月"}
	if err := c.Begin(scene); err != nil {
		t.Fatal(err)
	}
	if err := old.Begin(scene); err != nil {
		t.Fatal(err)
	}
	monitor, err := bank.BeginSession(input.Session, input.Children, input.Seed)
	if err != nil {
		t.Fatal(err)
	}
	fixture, born, lockedMove := newFixtureSource94(), false, 0.0
	for i := 0; i <= 130; i++ {
		move := 5*float64((30+i)/5) + 5
		if born {
			move = lockedMove
		}
		if i >= 36 && born {
			move -= 50
		}
		o := observation94(scene.Session, side, int64(i), float64(i*60), move, 20)
		stamp := gate.Stamp{Time: o.Time, Index: i, Line: int64(i + 1)}
		if _, err = monitor.AdvanceObserved(o.Time, uint64(i+1)); err != nil {
			t.Fatal(err)
		}
		snapshot, e := monitor.SnapshotAt(o.Time)
		if e != nil {
			t.Fatal(e)
		}
		history, e := gate.NewHistory(gate.Scope{Session: scene.Session.ID, Contract: scene.Contract, Start: scene.Session.Start, End: scene.Session.End})
		if e != nil {
			t.Fatal(e)
		}
		if e = history.Step(snapshot, stamp); e != nil {
			t.Fatal(e)
		}
		decision, e := history.Evaluate(gate.Request{Product: "NK225mini", Method: "NK225_D164_15", SignalID: fmt.Sprintf("失効探索%d", i), Side: side, At: stamp, Last: o.Last})
		if e != nil {
			t.Fatal(e)
		}
		news := []native.Signal{}
		if !born && decision.Trend == gate.True && i < 30 {
			news = append(news, birth94("116失効出生", side, 2))
			born, lockedMove = true, move
		}
		if born && i == 120 {
			news = append(news, close94("116失効源返済", "116失効出生", side, 2))
		}
		delta := fixture.step(t, o, stamp.Line, news, nil)
		step := source.NativeStep{Observation: o, SourceLine: stamp.Line, Mini: []source.NativeBatch{delta}}
		if err = c.Step(step); err != nil {
			t.Fatal(i, err)
		}
		if err = old.Step(step); err != nil {
			t.Fatal(i, err)
		}
	}
	if !born {
		t.Fatal("急落前に必要な順行出生がない")
	}
	end := source.SourceEnd{Session: scene.Session, Complete: true}
	if err = c.End(end); err != nil {
		t.Fatal(err)
	}
	if err = old.End(end); err != nil {
		t.Fatal(err)
	}
	origin := source.ReplayResult{Version: 1, Trial: 111, Session: scene.Session, Contract: scene.Contract, Complete: true}
	result, err := ConnectResult(origin, c)
	if err != nil {
		t.Fatal(err)
	}
	baseline, err := legacy.ConnectResult(copyValue(origin), old)
	if err != nil {
		t.Fatal(err)
	}
	if err = CompareReference115Values(&result, baseline, source.FileRef{Path: "人工旧115", SHA256: "人工"}); err != nil {
		t.Fatal(err)
	}
	if err = CheckReplay(result, Fixed{ActualConfigurations: actor.DeclaredContinuousConfigurations(), LifecycleDefinition: life.DeclaredDefinition()}); err != nil {
		t.Fatal(err)
	}
	return result
}

// TestLifecycleFailureThroughPublishedBank は実公開器を通った新失効とP100予約再同期を確認します。
//
// 引数: t(*testing.T)は人工検査器です。
// 返り値: なし。手製Sourceであり、実市場の利益やFAR自然生成を主張しません。
func TestLifecycleFailureThroughPublishedBank(t *testing.T) {
	for _, side := range []int{1, -1} {
		result := handFailure116(t, side)
		for _, config := range result.Actual.Configurations {
			book := result.Actual.Books[BookKey(config)]
			if config.LifeMode == "X0" {
				continue
			}
			if book.Metrics.LifecycleExitRequests == 0 || len(book.Positions) != 1 {
				t.Fatal(side, book.Key, "公表済み根拠失効の返済経路なし")
			}
			position := book.Positions[0]
			if position.Activation != nil || position.Lifecycle116.FirstInvalidation == nil || position.Lifecycle116.FinalOwnership == nil || len(position.Protection113.LifecycleReservations) == 0 {
				t.Fatal(side, book.Key, "未起動失効/最終実所有/P100外部予約の証拠不足")
			}
		}
	}
}

// TestExportLifecycleFailureArtificial は公表asof正例を独立監査へ渡すときだけ保存します。
//
// 引数: t(*testing.T)、環境EXPORT116_CORE(str)は人工器と新規出力先です。
// 返り値: なし。閉じた後の純評価や仮想損益を作りません。
func TestExportLifecycleFailureArtificial(t *testing.T) {
	directory := os.Getenv("EXPORT116_CORE")
	if directory == "" {
		t.Skip("人工の保存先なし")
	}
	if err := os.MkdirAll(directory, 0755); err != nil {
		t.Fatal(err)
	}
	rows := map[string]ReplayResult{}
	for _, side := range []int{1, -1} {
		rows[fmt.Sprint(side)] = handFailure116(t, side)
	}
	if _, err := SaveNew(filepath.Join(directory, "Core失効人工.json"), map[string]any{"試行": 116, "人工": true, "市場": false, "FAR自然生成": false, "results": rows}, false); err != nil {
		t.Fatal(err)
	}
}
