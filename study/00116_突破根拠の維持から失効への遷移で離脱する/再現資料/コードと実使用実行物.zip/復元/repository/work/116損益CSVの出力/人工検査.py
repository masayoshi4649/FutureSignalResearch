"""116CSVを市場なしの36候補×2場で検査する。停止は別helperでRootレビュー後。"""
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import runpy
import subprocess
import sys

OWN=Path(__file__).resolve().parent
ROOT=OWN.parents[1]
NODE=Path('C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
OLD=ROOT/'work/115損益CSVの出力_正益経験分母/人工を実行して停止する.py'
OLD_SHA='ced8832ae1f61ba080310e66163e2dabc719466950211a2e5717852ae142cd1c'


def digest(path: Path) -> str:
    """
    機能: 明示コード/人工の全bytes指紋を得る。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def put(path: Path,value: dict) -> dict:
    """
    機能: 未作成先だけへUTF-8 JSONを置く。
    引数: path(Path)、value(dict)。返り値: dictは絶対Ref。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    return {'path':str(path.resolve()),'sha256':digest(path)}


def fixture() -> dict:
    """
    機能: 旧115の手製schemaだけを36候補へ拡張し、life件数と0取引を加える。
    引数: なし。返り値: dictは人工72会計。市場結果・CSVを参照しない。
    """
    if digest(OLD)!=OLD_SHA:raise ValueError('旧115手製生成codeのSHA差')
    old=runpy.run_path(str(OLD),run_name='市場を読まない旧手製関数')
    base=old['fixture']();data=deepcopy(base);data.update({'試行':116,'会計数':72,'主key':[],'Actor設定':{},'場別':[],'集計':{},'入口票集計':{},'保有根拠検査集計':{},'全Rawライフ発生漏れ/初回性監査':False})
    for li,life in enumerate(('X0','XC','XQ')):
        for oldkey in base['主key']:
            cfg=deepcopy(base['Actor設定'][oldkey]);cfg['life_mode']=life
            key=oldkey if life=='X0' else oldkey.replace('_C','_'+life+'_C',1)
            cfg['candidate']=key;data['主key'].append(key);data['Actor設定'][key]=cfg
            group=[]
            for original in (r for r in base['場別'] if r['key']==oldkey):
                row=deepcopy(original);row['key']=key
                # ----------------------------------------
                # 非ゼロの候補はlifeごとに異なる純額を持ち、位置誤結合を発見できる。
                if row['positive_positions']:
                    row['positive_yen']+=li*100;row['gross_yen']+=li*100;row['net_yen']+=li*100;row['closed_net_yen']+=li*100
                    row.update(old['metrics'](row))
                count=int(life!='X0' and row['positions']>0);life_net=count*(li*10)
                row['注文別']={'保有根拠失効':{'要求':count,'約定':count,'返済片純額':life_net}}
                row['保有根拠の独立検査']={'成功':True,'counts':{'exit_requests':count,'exit_fills':count}}
                group.append(row);data['場別'].append(row)
            agg=deepcopy(base['集計'][oldkey])
            for field in ('positive_yen','gross_yen','net_yen','closed_net_yen'):agg[field]=sum(r[field] for r in group)
            agg.update(old['metrics'](agg));data['集計'][key]=agg
            data['入口票集計'][key]=deepcopy(base['入口票集計'][oldkey])
            data['保有根拠検査集計'][key]={k:sum(r['保有根拠の独立検査']['counts'][k] for r in group) for k in ('exit_requests','exit_fills')}
    return data


def run(command: list,success: bool=True) -> dict:
    """
    機能: 明示した人工CLIだけを実行し終了と出力を記録する。
    引数: command(list)、success(bool)。返り値: dictは検査ログ。
    """
    result=subprocess.run([str(x) for x in command],cwd=OWN,capture_output=True,text=True,encoding='utf-8',timeout=90)
    value={'command':[str(x) for x in command],'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
    if (result.returncode==0)!=success:raise ValueError(json.dumps(value,ensure_ascii=False))
    return value


def inspect(output: Path) -> dict:
    """
    機能: 手製二CSVの生成・別言語再読と未解禁/不正schema拒否だけを行う。
    引数: output(Path)は未作成人工先。返り値: dictは人工の成功Ref。停止は行わない。
    """
    owned=('入力と候補.mjs','出力する.mjs','CSVを独立再読する.py','人工検査.py','README.md','検査して停止する.py')
    before={str((OWN/name).resolve()):digest(OWN/name) for name in owned}
    output.mkdir();source=put(output/'手製の独立結果.json',fixture());commands=[]
    denied=run([NODE,OWN/'出力する.mjs','開かない.json','0'*64,output/'未許可'],False)
    if 'ENOENT' in denied['stderr']:raise ValueError('未許可で本文へ進んだ')
    commands.append(denied)
    commands.append(run([NODE,OWN/'出力する.mjs',source['path'],source['sha256'],output/'CSV','--artificial']))
    commands.append(run([sys.executable,'-X','utf8',OWN/'CSVを独立再読する.py','--result',source['path'],'--sha256',source['sha256'],'--folder',output/'CSV','--output',output/'CSVの独立再読.json','--artificial']))
    reread=json.loads((output/'CSVの独立再読.json').read_text(encoding='utf-8'))
    if reread['候補数']!=36 or reread['場別行数']!=72 or reread['0取引行数']!=24:raise ValueError('手製の全36/72/0取引24差')
    for name,change in [('候補順',lambda d:d['主key'].reverse()),('life件数',lambda d:d['場別'][24]['注文別']['保有根拠失効'].update(要求=99))]:
        bad=fixture();change(bad);ref=put(output/(name+'.json'),bad)
        commands.append(run([NODE,OWN/'出力する.mjs',ref['path'],ref['sha256'],output/(name+'拒否'),'--artificial'],False))
        if (output/(name+'拒否')).exists():raise ValueError('不正schemaで出力先作成')
    unfixed=put(output/'未固定Root要求.json',{'version':1,'trial':116,'fixed':False,'result_read_authorized':False})
    commands.append(run([NODE,OWN/'出力する.mjs','--request',unfixed['path'],'--sha256',unfixed['sha256'],'--output',output/'未固定拒否','--root-authorized'],False))
    if before!={str((OWN/name).resolve()):digest(OWN/name) for name in owned}:raise ValueError('所有code前後差')
    marker=OWN/'操作markerの記録.json';m=json.loads(marker.read_text(encoding='utf-8'))
    if m['成功'] is not True or m['回数']!=1:raise ValueError('人工の操作marker一回だけ')
    proof={'再用コードSHA256':{str(OLD):OLD_SHA},'操作marker':{'path':str(marker),'sha256':digest(marker)},'所有ファイルSHA256':before,'前後不変':True,'試行':116,'成功':True,'市場前':True,'停止':False,'人工36候補':True,'人工72会計':True,'0取引行数':24,'原板/市場Native/自然CSV本文':0,'入力':source,'commands':commands,'独立再読':reread}
    return put(output/'人工の確認.json',proof)


if __name__=='__main__':
    if len(sys.argv)!=2:raise ValueError('未作成人工先だけを指定')
    print(json.dumps(inspect(Path(sys.argv[1]).resolve()),ensure_ascii=False))
