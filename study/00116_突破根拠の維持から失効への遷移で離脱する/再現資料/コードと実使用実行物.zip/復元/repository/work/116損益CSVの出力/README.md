# 116損益CSVの出力準備

2026-11-10。市場前の手製検査用。旧115の20d9版から36候補へ派生し、自然Raw・Native・価格CSV・損益CSVは準備中に読まない。既正式CSVと旧停止コードを変更しない。新xlsxは生成しない。

出力は候補別36行×50列、全70場2,520行×46列。0取引を残す。候補は入口A0/T/TR、追加保有根拠X0/XC/XQ、共通P100、費用C0/C5・D0/D1を別列で記す。Actor順はLife→Entry→費用、設定表はEntry→Life→費用なので、本名keyで一意結合する。

利益/損失は成立実玉の費用後実現額。累計は候補ごと・セッション順の純実現額のみ。勝率は同値を含む全完結玉、PFは正額/負額絶対値、平均損失は負で保持する。0分母の率は空欄。正益経験後赤字率は全玉W>0経験玉を分母とし、場別率を平均しない。保存点DDと全tick最大DDは別。保有根拠失効の要求・約定・返済片純額は成立した実績で、仮想利益ではない。

Node24.22.1、loader由来`@oai/artifact-tool`2.8.129を使用する。人工のWorkbook作成前にSpreadsheetsの操作markerを一回記録する。自然出力時の操作markerはRootがその操作の直前に別途記録する。

人工は`python -X utf8 人工検査.py <未作成先>`。手製36候補×2場と0取引24行を作り、Artifact Toolの再計算・描画と標準csv/Decimalの別言語再読を行う。これは金融市場の成功ではない。正式停止はRootレビュー後に`python -X utf8 検査して停止する.py --reviewed --artificial-proof <人工の確認.json> --sha256 <SHA>`で新規保存する。

自然出力は新しいRoot固定要求が必須：

```text
node 出力する.mjs --request <絶対JSON> --sha256 <SHA> --output <要求と同じ未作成先> --root-authorized
python -X utf8 CSVを独立再読する.py --request <同要求> --request-sha <SHA> --result <結果JSON> --sha256 <結果SHA> --folder <CSV先> --output <未作成の再読確認JSON> --root-authorized
```

要求は金融F1、同F1全70金融成功、独立保存成功・結果SHA、自己停止を束縛する。未固定/未解禁は自然結果本文と出力作成の前に拒否する。Source/Actor/Goの再実行は行わない。CSVはoutputsの一組を正本とし、試行へ複写しない。

独立保存結果が全Raw初回性を証明していない場合、各行と生成確認に「保存点の独立検算済み・全Raw発生漏れ/初回性は別監査で未結合」を残す。別のRaw監査が完成しても、それを本出力へ結合していなければ完了扱いにしない。機会損失、退出後仮想利益、MFE回収率、ROI、固定枠参加率は生成しない。

全70の独立保存は同F1の元54成功検算を認証継承し、追加16を新規照合する。Root要求のindependent_executionとbase54_checkを確認し、CSVの独立検算区分にも残す。全70を新たにRaw/Native再検算したとは記さない。
