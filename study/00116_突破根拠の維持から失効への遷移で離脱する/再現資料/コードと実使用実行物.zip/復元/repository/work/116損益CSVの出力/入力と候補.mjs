import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';

export const F1_SHA='4c76a5f7cd8a59962e885cadf6885cfc75cbc590675955cb8e72ae2d0b8bb372';
export const CONFIGS=['X0','XC','XQ'].flatMap(life=>['A0','T','TR'].flatMap(entry=>[0,5].flatMap(slip=>[0,1].map(delay=>({policy:'P100',entry_mode:entry,life_mode:life,slip_pts:slip,delay_seconds:delay})))));

/** 候補の本名keyを返す。
 * @param {Object} c - 入口/保有根拠/費用の設定。
 * @returns {string} X0の旧本名又は追加Life本名。
 */
export function keyFor(c){return `${c.entry_mode}${c.life_mode==='X0'?'':'_'+c.life_mode}_C${c.slip_pts}_D${c.delay_seconds}`;}
export const ACTOR_KEYS=CONFIGS.map(keyFor);
export const TABLE_KEYS=['A0','T','TR'].flatMap(entry=>['X0','XC','XQ'].flatMap(life=>CONFIGS.filter(c=>c.entry_mode===entry&&c.life_mode===life).map(keyFor)));

/** 全bytesをSHA256へ写す。
 * @param {Uint8Array|string} value - 明示データ。
 * @returns {string} 小文字指紋。
 */
export function sha(value){return crypto.createHash('sha256').update(value).digest('hex');}

/** 小JSONの絶対Refを認証する。NativeやCSVは受理しない。
 * @param {Object} ref - path/sha256。
 * @param {Object} before - 認証済み指紋台帳。
 * @returns {Promise<Object>} JSON値。
 */
async function readRef(ref,before){
  assert.deepEqual(Object.keys(ref).sort(),['path','sha256']);assert.ok(path.isAbsolute(ref.path)&&path.extname(ref.path)==='.json'&&/^[a-f0-9]{64}$/.test(ref.sha256),'小JSON絶対Refだけ');
  const data=await fs.readFile(ref.path);assert.equal(sha(data),ref.sha256,'RefのSHA');before[ref.path]=ref.sha256;
  return JSON.parse(data.toString('utf8').replace(/^\uFEFF/,''));
}

/** Root全70成功又は明示人工だけを本文へ通す。
 * @param {string[]} args - 人工の旧形式又は--request/--sha256/--output。
 * @returns {Promise<Object>} 結果と認証範囲。入力本文を読む前に未固定を拒否。
 */
export async function openInput(args){
  assert.equal(process.version,'v24.22.1','固定Node');
  const packagePath=import.meta.resolve('@oai/artifact-tool').replace(/dist[\\/]artifact_tool\.mjs$/,'package.json');
  assert.equal(JSON.parse(await fs.readFile(new URL(packagePath),'utf8')).version,'2.8.129');
  const beforeRefs={};let input,expectedSHA,output,data,rootRequest=null;
  const artificial=args.includes('--artificial');
  if(artificial){
    assert.equal(args.length,4,'人工入力・SHA・新規先・--artificial');
    [input,expectedSHA,output]=args;input=path.resolve(input);output=path.resolve(output);
    data=await readRef({path:input,sha256:expectedSHA},beforeRefs);
    assert.equal(data['人工'],true);assert.equal(data.stage,'artificial');assert.ok(data['場数']>0&&data['場数']<=8);
  }else{
    assert.equal(args.length,7,'Root要求/期待SHA/新規先と明示許可だけ');
    assert.equal(args[0],'--request');assert.equal(args[2],'--sha256');assert.equal(args[4],'--output');assert.equal(args[6],'--root-authorized','Root要求なしでは本文未読');
    rootRequest={path:path.resolve(args[1]),sha256:args[3]};output=path.resolve(args[5]);
    const request=await readRef(rootRequest,beforeRefs);
    assert.equal(request.version,1);assert.equal(request.trial,116);assert.equal(request.fixed,true);assert.equal(request.result_read_authorized,true,'Rootの全70成功解禁');
    assert.equal(path.resolve(request.output_dir),output,'Root指定出力先');
    const stopped=await readRef(request.code_stop,beforeRefs);
    assert.equal(stopped['試行'],116);assert.equal(stopped['成功'],true);assert.equal(stopped['市場前'],true);assert.equal(stopped['停止'],true);
    const here=path.dirname(fileURLToPath(import.meta.url));
    const owned=['入力と候補.mjs','出力する.mjs','CSVを独立再読する.py','人工検査.py','README.md','検査して停止する.py'].map(n=>path.join(here,n));
    assert.deepEqual(Object.keys(stopped['所有ファイルSHA256']).sort(),owned.sort(),'停止所有6');
    for(const [name,expected] of Object.entries(stopped['所有ファイルSHA256'])){assert.equal(sha(await fs.readFile(name)),expected,'停止codeの現物');beforeRefs[name]=expected;}
    assert.equal(request.condition.sha256,F1_SHA,'同F1');
    assert.equal(request.independent_execution,'inherit_base54_verify_additional16','独立検算の認証継承と新規照合を区別');
    const condition=await readRef(request.condition,beforeRefs),completion=await readRef(request.completion,beforeRefs),check=await readRef(request.check,beforeRefs),base54=await readRef(request.base54_check,beforeRefs);
    for(const [name,value] of Object.entries({'試行':116,'成功':true,'stage':'base54','場数':54,'会計数':1944,'前後不変':true,'全残玉予約0':true,'不一致数':0,'金融条件SHA256':F1_SHA}))assert.equal(base54[name],value,'継承元54の成功/'+name);
    assert.equal(condition.trial,116);assert.equal(condition.fixed,true);assert.deepEqual(condition.actual_configurations,CONFIGS,'F1本名36');
    assert.equal(completion.trial,116);assert.equal(completion.success,true);assert.equal(completion.stage,'full70');assert.equal(completion.sessions,70);assert.equal(completion.books,2520);assert.equal(completion.condition_sha256,F1_SHA);assert.equal(completion.unchanged,true);assert.deepEqual(completion.before,completion.after);
    assert.equal(completion.reference115_comparisons,840);assert.equal(completion.all_reference115_equal,true);assert.equal(completion.all_source111_equal,true);assert.equal(completion.results.length,70);
    for(const row of completion.results){assert.equal(row.books,36);assert.equal(row.x0_comparisons,12);assert.equal(row.x0_equal,true);assert.equal(row.complete,true);assert.equal(row.open_quantity,0);assert.equal(row.pending_quantity,0);}
    for(const [name,value] of Object.entries({'試行':116,'成功':true,'stage':'full70','場数':70,'会計数':2520,'前後不変':true,'全残玉予約0':true,'不一致数':0,'X0全金融比較':840,'全Source111同体':true}))assert.equal(check[name],value,'独立確認/'+name);
    assert.equal(check['金融条件SHA256'],F1_SHA);assert.equal(check['金融完了SHA256'],request.completion.sha256);assert.equal(check['出力SHA256']['結果.json'],request.result.sha256);
    data=await readRef(request.result,beforeRefs);input=request.result.path;expectedSHA=request.result.sha256;
    assert.equal(data['独立再用場数'],54);assert.equal(data['独立新規検算場数'],16);assert.equal(data['全70の金融Native再検算'],false,'旧54の認証継承を新規全70再計算へ拡張しない');
    assert.equal(data['金融条件SHA256'],F1_SHA);assert.equal(data['金融完了SHA256'],request.completion.sha256);assert.equal(data['Root保存要求SHA256'],check['Root保存要求SHA256']);
    assert.equal(data['人工']??false,false);assert.equal(data.stage,'full70');assert.equal(data['場数'],70);assert.equal(data['採用'],false);assert.equal(data['研究目標達成'],false);
    assert.deepEqual([...new Set(data['場別'].map(r=>r.session))].sort(),completion.results.map(r=>r.session).sort(),'金融と独立の70場集合');
  }
  assert.equal(data['試行'],116);assert.equal(data['成功'],true);assert.equal(data['前後不変'],true);assert.deepEqual(data['主key'],ACTOR_KEYS);
  const rawStatus=data['全Rawライフ発生漏れ/初回性監査']===true?'独立保存結果で全Raw監査済み':'保存点の独立検算済み・全Raw発生漏れ/初回性は別監査で未結合';
  return {input,expectedSHA,output,data,artificial,beforeRefs,rawStatus,rootRequest};
}
