"""Root許可の105生成NK225 gzip3点を一度だけ同bytes恒久保管する。"""

from pathlib import Path
import hashlib
import json


ROOT = Path(__file__).resolve().parents[2]
TARGET = ROOT / 'inputs/105生成原板'
MANIFEST = ROOT / 'study/00106_収束失速で保護の起動と幅を切り替える/入力台帳_70場.json'
MANIFEST_SHA = '902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8'
ORIGIN = ROOT / 'study/00105_固定SourceとLD10の四場追加確認/入力の由来と品質.json'
ORIGIN_SHA = '1dfc06be70541b3df63d727b24de9e931bee14ab00bd9f4cb5165568c31167ec'


def sha(path: Path) -> str:
    """機能: 解凍せずファイルbytesのSHAを返す。

    引数: path(Path)はRoot許可した3gzip又は小metadata。
    返り値: strはSHA256。価格の意味解析を行わない。
    """
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def main() -> None:
    """機能: 固定manifestのwork105生成3入力だけを新規恒久先へ保存する。

    引数: なし。Rootの2026-11-10明示許可と固定902c/105由来を使用。
    返り値: None。保存確認Refを出す。元work・金融・旧保存は変更しない。
    """
    if TARGET.exists():
        raise ValueError('恒久先が存在。上書きや再保管はせずRootへ報告する')
    if sha(MANIFEST) != MANIFEST_SHA or sha(ORIGIN) != ORIGIN_SHA:
        raise ValueError('共有台帳又は105由来metadataのSHA差')
    manifest = json.loads(MANIFEST.read_text(encoding='utf-8'))
    origin = json.loads(ORIGIN.read_text(encoding='utf-8'))
    selected = [r for r in manifest['sessions'] if r['files']['NK225_book']['path'].startswith('FutureSignalResearch/work/105入力の固定準備/')]
    if [r['id'] for r in selected] != ['2026-11-05_Night', '2026-11-06_Day', '2026-11-06_Night']:
        raise ValueError('Root許可の3場だけを対象とする')
    plans = []
    for row in selected:
        f = row['files']['NK225_book']
        source = (Path(manifest['source_root']) / f['path']).resolve()
        target = TARGET / 'NK225' / row['id'] / 'book.jsonl.gz'
        old = next(r for r in origin['InputManifest4x6'] if r['session'] == row['id'] and r['key'] == 'NK225_book')
        if not source.is_relative_to(ROOT / 'work/105入力の固定準備/生成_初回/gzip/NK225') or not target.resolve().is_relative_to(TARGET):
            raise ValueError('明示元/先の範囲外')
        if source.stat().st_size != f['size'] or sha(source) != f['sha256']:
            raise ValueError('固定生成gzipのSHA/size差')
        if old['使用SHA256'] != f['sha256'] or old['使用size'] != f['size'] or Path(old['使用位置']).resolve() != source:
            raise ValueError('105由来と106台帳の同体差')
        plans.append({'session': row['id'], 'source': {'path': str(source), 'sha256': f['sha256'], 'bytes': f['size']},
                      'canonical': {'path': str(target), 'sha256': f['sha256'], 'bytes': f['size']},
                      'original_jsonl': {'path': old['原位置'], 'sha256': old['原SHA256'], 'bytes': old['原size']},
                      '旧105で確認した解凍SHA256': old['解凍SHA256']})
    if sum(r['source']['bytes'] for r in plans) != 20791765:
        raise ValueError('Root許可の合計bytes差')
    for row in plans:
        source, target = Path(row['source']['path']), Path(row['canonical']['path'])
        target.parent.mkdir(parents=True, exist_ok=True)
        with source.open('rb') as src, target.open('xb') as dst:
            for block in iter(lambda: src.read(1024 * 1024), b''):
                dst.write(block)
        if sha(source) != row['source']['sha256'] or sha(target) != row['source']['sha256'] or target.stat().st_size != row['source']['bytes']:
            raise ValueError('恒久コピーの元前後/新先SHA/size差')
    metadata = {'version': 1, '成功': True, '由来試行': 105, 'Viewer接続対象試行': 116,
                'Root許可': '2026-11-10。workだけに残る既固定生成3gzipを一度だけ同bytes恒久保存。価格意味解析・解凍なし。',
                'manifest': {'path': str(MANIFEST), 'sha256': MANIFEST_SHA}, '105由来': {'path': str(ORIGIN), 'sha256': ORIGIN_SHA},
                'files': plans, '合計bytes': 20791765, '元work保持': True, '元前後SHAとsize同体': True,
                '新先の同SHAとsize': True, '解凍/価格意味解析': False, '金融再生': False,
                '金融F1/入力台帳/旧保存変更': False, '用途': 'Viewer市場参照の恒久所在。金融の固定絶対入力pathは不変。',
                '旧金融の再現': '固定条件のsource.pathが必要な環境ではcanonicalから元work絶対pathへ同bytes復元しSHA/size照合する。上書きしない。',
                'この保存code': {'path': str(Path(__file__).resolve()), 'sha256': sha(Path(__file__).resolve())}}
    path = TARGET / '保存の確認.json'
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(metadata, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    with (TARGET / 'README.md').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write('# 105で生成したNK225原板gzipの恒久保管\n\n2026-11-10、Root明示許可で一度だけ保存した。11/05 Night・11/06 Day/Nightの3gzip、合計20,791,765bytes。旧105は共有JSONLをgzip化し解凍SHA同体を確認したが、その生成gzipだけがworkに残っていた。ここでは既固定gzipを解凍せず同bytesコピーし、元前後と新先のSHA/sizeを確認した。\n\n由来・106共有manifestの902c固定Ref・元JSONLの既記録SHA・元work path・恒久pathは[保存確認](保存の確認.json)に保持する。元work、金融F1、共有入力台帳、旧正式保存は変更していない。Viewerだけが新所在へ結ぶ。金融再現は固定条件の元絶対work pathが必要なため、この恒久コピーから未作成の元pathへ同bytes復元しSHA/sizeを照合する。ここを他試行へ重複コピーしない。\n')
    print(json.dumps({'成功': True, '保存確認': {'path': str(path), 'sha256': sha(path)}, '場数': 3, 'bytes': 20791765}, ensure_ascii=False))


if __name__ == '__main__':
    main()
