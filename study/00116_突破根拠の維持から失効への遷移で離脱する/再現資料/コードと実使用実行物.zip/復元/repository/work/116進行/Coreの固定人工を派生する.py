"""旧115の市場本文未読ゲート人工を、116の36条件へ派生する。"""

from pathlib import Path


def main() -> None:
    """
    機能: 停止・宣言・入力台帳metadataだけの人工を新しい条件型へ接続する。
    引数: なし。
    返り値: None。部品停止前には実行しない。
    """
    root = Path(__file__).resolve().parents[2]
    old = root / "work/115三時間軸の複合入口の連続比較/fixed_test.go"
    out = root / "work/116保有根拠の連続比較/fixed_test.go"
    assert not out.exists()
    text = old.read_text(encoding="utf-8")
    for before, after in (
        ("package entrycomparison115", "package lifecomparison116"),
        ("/continuousactor115", "/continuousactor116"),
        ("References114", "References115"), ("Reference114", "Reference115"),
        ("A0Comparisons", "X0Comparisons"), ("A0Equal", "X0Equal"),
        ("Trial: 115", "Trial: 116"), ("Trial != 115", "Trial != 116"),
        ("../115三時間軸の複合入口を執行する会計", "../116突破失敗を返済へ結ぶ会計"),
        ("study/00114_順行と反転の取得確認を分ける", "study/00115_三時間軸の方向性と局所構造で入口を分ける"),
        ("b0bf17c4bcd435dcca13da12995a11a9c6f5617f86a27ca2f0994528a3823167", "94bb656a1607d59039a0c5ec0f06968a4da72463d27c0847606a09fc52fc4693"),
        ("2589160f6e86e618a64372a52cad0abd76e19e5b49d607897f758604600a0b18", "8bba68dfa7df62d2fa7f40443e4a3cd89f48caa7ed398560ca1ee914e59e714b"),
        ("93627b2b4348f2d1e86d52f2d24946f3c36aded3664c4733e219389f9b8c6f5e", "04c8eb63d5299f52b74f758b97026a9f205fa4dbeaf093996a2a7a1a8af98b9c"),
        ("Books: 648", "Books: 54*BookCount"), ("Reference115Comparisons: 216", "Reference115Comparisons: 54*BaselineCount"),
        ("Books: 12, X0Comparisons: 4", "Books: BookCount, X0Comparisons: BaselineCount"),
        ("Reference115Comparisons: 4", "Reference115Comparisons: BaselineCount"),
    ):
        text = text.replace(before, after)
    text = text.replace('gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate115"', 'gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate115"\n life "github.com/masayoshi4649/SessionTradeExecuter/entrylife116"')
    text = text.replace('deps["actor"] =', 'deps["lifecycle"] = testRef(t, filepath.Join(here, "../116突破根拠の維持と失効/停止.json"))\n deps["actor"] =', 1)
    text = text.replace('pure := testRef', 'lifeDecl := testRef(t, filepath.Join(here, "../116突破根拠の維持と失効/検査/実定義.json"))\n pure := testRef', 1)
    text = text.replace("actual, pure, entryDecl, chart, entryChart}", "actual, pure, entryDecl, chart, entryChart, lifeDecl}")
    text = text.replace("EntryInputModel: EntryInputModel,", "LifecycleDefinition: life.DeclaredDefinition(), LifecycleDeclaration: lifeDecl, EntryInputModel: EntryInputModel,", 1)
    text = text.replace('"旧113/成果物_金融/Native参照台帳.json"', '"旧115/成果物_金融/Native参照台帳.json"')
    text = text.replace('"定義変更", "実行物変更"', '"定義変更", "失効定義変更", "実行物変更"')
    text = text.replace('case "実行物変更":', 'case "失効定義変更":\n bad.LifecycleDefinition.LatestOnly = false\n case "実行物変更":', 1)
    with out.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


if __name__ == "__main__":
    main()
