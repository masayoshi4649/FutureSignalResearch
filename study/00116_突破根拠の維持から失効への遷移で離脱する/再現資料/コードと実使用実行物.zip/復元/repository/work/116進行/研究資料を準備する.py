"""116の起動前失効候補と、版6の汎用表を新規試行へ保存する。"""

import hashlib
import json
import os
from pathlib import Path
import re


def main() -> None:
    """
    機能: 既存の金融条件を変えず新候補の仮説・使用セル・未実行状態を保存する。
    引数: なし。
    返り値: None。Raw・Native・価格CSVを読まず、金融F1も作らない。
    """
    root = Path(__file__).resolve().parents[2]
    trial = root / "study/00116_突破根拠の維持から失効への遷移で離脱する"
    assert not trial.exists(), "試行番号を再利用しない"
    template = root / "docs/議論/手法と時間スケールの汎用表_版6.md"
    original = template.read_text(encoding="utf-8")
    old_settings = root / "study/00115_三時間軸の方向性と局所構造で入口を分ける/設定と結果.md"
    before = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (template, old_settings)}
    assert before[str(old_settings)] == "3e27641b849464ed8a532dff35cd20a552b330585c49190f990fe6bd2460f326"
    trial.mkdir()
    body = original.split("## 手法×時間スケール", 1)[1].split("## 設定明細", 1)[0]
    body = body.replace("全セルは未設定・未検証。", "使用セルは設定IDへ対応する。116の金融比較は未固定・未実行。")
    body = body.replace("未設定・未検証", "追加未使用")
    cells = {
        ("I01", 2): "S05/S06：従来3分保護の形成・C診断→全R",
        ("I01", 3): "S22：EMA8/21準備のみ",
        ("I01", 4): "S22：EMA8/21準備のみ",
        ("I01", 5): "S18：方向背景→入口R13〜36／S24,S27：監視文脈",
        ("I03", 2): "S07：従来MACD-H増分M→全RのP100狭幅",
        ("I03", 3): "S25/S26：Hist順側確認→水準喪失。増分だけでは退出しない",
        ("I04", 2): "S05：準備のみ",
        ("I05", 2): "S08：従来BB幅縮小は診断のみ",
        ("I08", 3): "S19：準備・診断のみ",
        ("I08", 4): "S19：入口方向・TのADX／S24,S25：DIによる監視適格・維持確認",
        ("I08", 5): "S19：準備・診断のみ",
        ("I09", 3): "S04源ATR12で従来保護幅／S21前ATR14×2は入口警戒",
        ("I15", 2): "S09：従来前5足H−L中央値・最小5→全R狭幅",
        ("C04", 4): "S19：入口方向・偏り／S25：DI方向を確認",
        ("C06", 0): "S12〜15：H100・M AND P可変追尾／S28：先行優先",
        ("C07", 3): "S20/S21/S22：入口局所突破／S24〜27：維持から失効への遷移",
        ("C07", 4): "S19/S22：入口中期方向／S24,S25：適格・armed",
        ("C07", 5): "S18/S22：長い背景／S27：取得後符号を新gateにしない",
        ("P02", 2): "S10/S11：従来動的P・構造床→全R",
        ("P03", 2): "S10/S11：従来公表済みpivot→全R",
        ("P07", 3): "S20：前3本の入口突破／S24/S26：出生時境界を固定して監視",
        ("B01", 0): "S03/S15：正常BBO・後原行fill／S25,S26：返済側価格",
        ("E01", 0): "旧125/250先着は今回の合否対象外",
        ("E02", 0): "S12〜16：必須追尾・場内完結／S28：起動前の別返済理由",
    }
    rows, methods = [], 0
    for line in body.splitlines():
        if re.match(r"^\| [ICPBVXME]\d{2} \|", line):
            values = [x.strip() for x in line.strip().strip("|").split("|")]
            assert len(values) == 11
            methods += 1
            for scale in range(9):
                if (values[0], scale) in cells:
                    values[scale + 2] = cells[(values[0], scale)]
            line = "| " + " | ".join(values) + " |"
        rows.append(line)
    assert methods == 56
    body = "\n".join(rows)

    def relocate(match: re.Match) -> str:
        """
        機能: 汎用表の同じ出典を新試行から参照する相対リンクへ変換する。
        引数: match(re.Match)はMarkdownリンク。
        返り値: strは同じ参照先へのリンク。
        """
        label, target = match.groups()
        if target.startswith(("http:", "https:", "#")):
            return match.group(0)
        destination = (template.parent / target).resolve()
        return f"[{label}]({Path(os.path.relpath(destination, trial)).as_posix()})"

    body = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", relocate, body)
    settings = []
    for line in old_settings.read_text(encoding="utf-8").splitlines():
        if not re.match(r"^\| S\d{2} \|", line):
            continue
        values = [x.strip() for x in line.strip().strip("|").split("|")]
        assert len(values) == 7
        values = [v.replace("R05〜12", "R13〜36") for v in values]
        if values[0] == "S17":
            values[5] = "全R。116市場未固定・未実行"
        if values[0] == "S23":
            values = ["S23", "複合・分母・対照", "入口と従来保護と追加失効の分離", "A0/T/TR×X0/XC/XQ×C0/C5×D0/D1の36。X0全12を旧115へ全金融・入口票・P100全保存State/Source全文照合", "first2→base54→full70。同116条件54成功の認証再用。115の成功を116の金融結果へ代用しない", "全R、市場未固定・未実行", "未知を0へ補わず、成立玉の純額・利益・損失・正益後赤字率・DD・回数で比較。未参加/退出後仮利益なし"]
        settings.append("| " + " | ".join(values) + " |")
    assert len(settings) == 23
    settings += [
        "| S24 | 出生時5/15/30・固定境界 | 追加監視の適格性 | 凍結115票のCommon真・D15>0・G30既知非0。boundaryは出生時の前3本高安値を固定 | 入口の追加拒否ではない。適格でない玉も元Source/P100で継続 | XC/XQ各入口。X0は追加失効なし | 出生票と実fill時の状態を混ぜない。監視中に境界を現在窓へ移さない |",
        "| S25 | 5Close/Hist・15DI・30背景・返済BBO | 維持確認armed | 正常返済BBOと5Closeが固定境界の順側strict>0、方向付きHist5>0・D15>0、使用3尺度当場freshで確認 | 実fill時latestで初期化。最初から逆なら未armed。後のarmedには5End>fillとfill後実配送を要求し、その公表がfreshの全正常Rawで確認可 | XC/XQ共通 | 実fillで入口を再ゲートしない。30Gの取得後符号を新gateにしない |",
        "| S26 | MACD5水準消失＋価格構造 | 警戒と退出完成 | armed後の取得後新5公表で方向付きHist<=0。XCは同公表Closeが境界逆側strict<0、XQは最新同条件Histのfresh期間の全正常Rawで返済BBOが境界逆側strict<0 | End>実fill、実配送原行もfillより後。等号の価格接触は退出偽。Hist等号0は順側水準消失 | XC/XQ | Hist増分低下・MACD本体0割れ・価格反転を同一視しない。XC/XQ差は時計と価格系列/スプレッド/気配可用性を含む |",
        "| S27 | 公表状態と履歴 | 欠足・回復・ラッチ | 使用5Close/Hist・15±DI・30EMA8/21の未知/品質欠落/古さでarmed鎖を切る。既知逆DIだけでdisarmしない。価格/Hist警戒は回復で消えるが完成失効は非取消 | 未使用ADX/RSI/BB/出来高の未知で鎖切りしない。BBO異常だけは鎖を保ちXQ/発注を待つ | XC/XQ | 同原行の全5/15/30公表を揃えたasofを使う。未来/同ID改変/同秒原行潰しを拒否 |",
        "| S28 | Source・P100・失効・予約 | 実返済の優先と所有 | 元予約とP100を先行。未ラッチでP100が先に起動した玉は以後新Xなし。既ラッチは後のP100起動でも非取消。未予約実残のみ要求し厳密後の正常BBOで約定 | XCはBBO異常でも公表で失効を先に不可逆保存し発注待ち、XQは正常返済BBO時だけ成立。全予約0量と失効成立は別 | 全R。X0は旧115と金融同体 | 初期利益100pt相当の必須追尾・最低床・非緩和、実部分返済R/nを維持。Source本体へ保護fillは返さない比較 |",
    ]
    evaluations = ["| 評価ID | 候補 | 設定 | 結果 |", "| --- | --- | --- | --- |"]
    keys = []
    for mode in ("A0", "T", "TR"):
        for life in ("X0", "XC", "XQ"):
            for cost in (0, 5):
                for delay in (0, 1):
                    key = f"{mode}{'' if life == 'X0' else '_' + life}_C{cost}_D{delay}"
                    keys.append(key)
                    evaluations.append(f"| R{len(keys):02d} | {key} | S01〜28、入口{mode}、共通P100、追加{life} | 未固定・市場未実行 |")
    assert len(keys) == 36
    text = "# 00116：設定と結果\n\n2026-11-10。汎用表・版6の56手法×9尺度をコピー。金融F1未固定・市場未実行。技法セルの使用状態と複合36候補の成績を混同しない。\n\n## 手法×時間スケール\n"
    text += body + "\n\n## 設定明細\n\n| 設定ID | 手法・尺度 | 役割 | 計算と閾値 | 時計と未知 | 対象 | 注記 |\n| --- | --- | --- | --- | --- | --- | --- |\n"
    text += "\n".join(settings) + "\n\n## 複合条件と結果\n\n" + "\n".join(evaluations) + "\n"
    (trial / "設定と結果.md").write_text(text, encoding="utf-8", newline="\n")
    readme = """# 00116：突破根拠の維持から失効への遷移で離脱する

2026-11-10。金融条件は未固定、実市場の損益は未実行。旧115を変更せず、入口・P100を維持した別試行で、取得後の根拠失効だけを分離する。採用・研究目標達成は未確認である。

## 仮説

突破水準の近くへ価格が戻っただけでは、押戻しと失敗を区別できない。取得時または取得後に、固定水準の順側・MACD Histの順側・15分DIの順側が同時に確認できた状態をarmedとして保存し、その後に価格構造とHistの順側水準が一緒に失われた場合を追加撤退の候補とする。

これは心理の仮説であり、突破後の支持への注文が残る通常の再テストと、局所水準を保てずMACDとsignalの相対関係も逆転した状態を分ける試みである。注文主体や吸収量、反転の因果を価格指標だけから断定しない。Histの符号はMACD本体の0交差や価格反転そのものではない。

旧113は取得時pivotの否定と3分Hist増分低下で早期撤退し、全体の純利益を下げた。初めから背景が逆の玉と、取得後に根拠が崩れた玉が混ざり、Histがまだ順側の例もあった。116では出生時の実突破境界、5分Hist水準、armedからの遷移、現在返済BBOと確定Last Closeの違いを明示する。同じ案の改名とは扱わない。

## 比較と条件

[115](../00115_三時間軸の方向性と局所構造で入口を分ける/README.md)のA0/T/TR入口とP113/P100を据え置き、追加退出なしX0、確定Last Closeで失効するXC、最新5分Hist警戒中に現在返済側BBOで失効するXQを比較する。各4費用、計36候補。X0は旧115全12条件との全金融・入口票・保存P100 State・Source全文の同体を確認する。

出生時Common真・D15>0・G30既知非0の実玉に監視を用意する。適格でない玉を新たに入口拒否しない。境界は出生時の5分前3本高安で固定する。初期armedは実fill時の最新公表と返済BBOで確認し、出生からfillまでに既に崩れている場合を取得後失効と誤称しない。

後のarmedは、取得後に終了・配送された5分足を参照し、5Closeと正常返済BBOが境界の順側strict>0、方向付きHist5>0・DI15>0を同時に満たす場合とする。使用5/15/30足が当場freshであることも必要。取得後30EMA配置の符号が変わることだけを新たな方向gateにはしない。

armed後、取得後の新5分公表でHist5の方向付き水準が<=0となり、XCは同じ公表Closeが固定境界の逆側strict<0、XQはその公表がfreshの間の正常Raw返済BBOが逆側strict<0で失効を完成する。買いはBid、売りはAsk。XQは公表配送行だけに限定しない。価格等号は退出偽、Hist等号は順側水準消失とする。これは独自の研究定義で、普遍的な最適閾値ではない。

警戒が回復した段階と、完成した失効ラッチを分ける。未知・欠足・古さは使用値だけでarmed鎖を切り、正常化後に再確認する。BBO異常だけは鎖を切らず、XQ判定と発注を待つ。XCは気配異常中でも確定公表で完成した失効を保存し、正常気配を待って発注する。未使用ADX/RSI/BB/出来高の未知を理由に監視を無効化しない。

元予約とP100を先行し、未ラッチでP100が起動した玉には新しい追加失効を出さない。既に完成したラッチや注文は後のP100起動で取り消さない。未予約の実残だけを要求し、既存の後原行正常BBO約定と遅延、費用、部分返済配賦、残玉0の検査を維持する。

## 入力・数量・費用・時計

対象は既使用のNK225全70場（2026-09-21Day〜11-06Night）。元54と追加16を分け、条件固定後に先頭2→元54→全70の順で確認する。追加16も未知テストとは呼ばない。11/09の価格・損益・入力指紋は未読で、今回の入力に加えない。

Source111の選定三手法と元の原行順序を維持し、5分/15分の新規時計や追加開始静観を設定しない。5/15/30は指標幅である。入口bank115の前史は同限月の過去CSVを予定Endまで足終+60秒モデルで公表済みとする既存模型、当場はRaw観測まで。元Source/3分P100保護はcoldのまま。出口用最新公表は出生時の入口freezeから分離し、全受理Raw行でasofを更新する。

日経miniは100円/pt、片道38.5円/枚、買い売り各上限10枚の可変数量。C0/C5は追加片道滑り0/5pt、D0/D1は追加価格時計遅延0/1秒。D0も同原行fillではない。P100は全玉費用後評価Wが初期枚数×10,000円に達したら必須追尾、最低床と非緩和を維持する。Sourceへ保護fillを返さない隔離比較という限界も変えない。

## 評価・再利用

実現純額、利益/損失総額、PF、勝率、保存点連結時価DD、回数/枚数、正益経験玉を分母とする最終赤字率、起動前失効/起動後赤字を分ける。失効成立、全予約で注文0、実返済要求、約定を別に残す。支持・勢いが揃う前の初期逆、未知、取得後の変化を混同しない。

XC/XQの差には、待つ時計だけでなくLast Close対返済BBO・スプレッド・正常気配可用性も含まれる。両witnessを保存し、時間だけの因果効果とは呼ばない。極値を使って最適退出を選ばず、未参加や退出後の仮利益・機会損失・ROIを作らない。

[全手法・設定と未実行結果](設定と結果.md)、[外部一次資料の調査](../../docs/議論/外部再調査/突破失敗と持続を状態遷移で分ける.md)を参照する。115の確定結果や113のH50悪化を116の利益と読み替えない。実行物・停止・F1・独立検算・CSV・Viewerの再現参照は各段階成功後に新たに結ぶ。
"""
    (trial / "README.md").write_text(readme, encoding="utf-8", newline="\n")
    external = root / "work/116突破失敗と持続の外部調査/調査.md"
    assert hashlib.sha256(external.read_bytes()).hexdigest() == "004df4d7b5ebf45a57efa1e72bf24fed4478b64429a4a11bdcaf2aa8367adbcf"
    common = root / "docs/議論/外部再調査/突破失敗と持続を状態遷移で分ける.md"
    with common.open("xb") as handle:
        handle.write(external.read_bytes())
    for p, digest in before.items():
        assert hashlib.sha256(Path(p).read_bytes()).hexdigest() == digest
    proof = {"試行": 116, "成功": True, "段階": "仮説と設定表のみ。金融未固定・未実行", "前ゴールターン分類": "進捗。115の全70比較とOHLC接合・独立検算・正式保存・CSV・Viewerを完了し、起動前損失と費用による実退出差を確認。",
             "入力SHA256": before, "文書SHA256": {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in (trial / "README.md", trial / "設定と結果.md", common)},
             "手法数": 56, "尺度数": 9, "設定数": 28, "候補数": 36, "候補key": keys,
             "金融実行": 0, "11月09読取": False, "採用": False, "研究目標達成": False}
    (trial / "準備の確認.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (Path(__file__).parent / "現在.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"試行": 116, "資料準備": True, "金融実行": False, "候補": len(keys)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
