"""116の市場前停止・実宣言・仮説原文をRoot金融条件へ固定する。"""

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


def ref(path: Path, expected: str | None = None) -> dict:
    """機能: 明示コード・小metadata・研究文書の指紋を確認する。

    引数: path(Path)は対象、expected(str|None)は任意の期待SHA256。
    返り値: dictは絶対位置とSHA256。市場入力本文は対象外。
    """
    path = path.resolve()
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    assert expected is None or actual == expected, str(path)
    return {"path": str(path), "sha256": actual}


def save_new(path: Path, value: dict) -> dict:
    """機能: 既存成果物を上書きせず小JSONを保存する。

    引数: path(Path)は新規先、value(dict)は保存値。
    返り値: dictは保存した現物の参照。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    return ref(path)


def main() -> None:
    """機能: 人工検査済み116の金融条件と市場前原文を新規固定する。

    引数: なし。Rootが確認した停止と素材の期待SHA256を使う。
    返り値: None。金融実行・Raw・Native・価格CSV・11月09の読取はない。
    """
    root = Path(__file__).resolve().parents[2]
    here = Path(__file__).resolve().parent
    study = root / "study/00116_突破根拠の維持から失効への遷移で離脱する"
    core = root / "work/116保有根拠の連続比較"
    destination = here / "F1_116金融条件.json"
    archive = study / "根拠/市場前原文"
    assert not destination.exists() and not archive.exists()
    material = ref(core / "条件の素材.json", "0845d6bf4308864ee26962709f06d9435aa509872e3f38a00de0a507044944b7")
    stopped = ref(core / "停止.json", "c080ce6fb520385acdb88c8b0efe65690c8cd0a17593859ac9b9f9691c713cbe")
    data = json.loads(Path(material["path"]).read_text(encoding="utf-8"))
    stop = json.loads(Path(stopped["path"]).read_text(encoding="utf-8"))
    assert data["version"] == 1 and data["trial"] == 116 and data["fixed"] is False
    assert stop["成功"] is True and stop["停止"] is True and stop["trial"] == 116
    assert stop["主test"] == 21 and stop["副test"] == 45
    assert data["runtime_stop"] == stopped and data["executable"] == stop["実行物"]
    assert data["dependency_stops"] == stop["依存停止"]
    assert data["entry_input_model"] == "prior_csv_publications_through_scheduled_end_current_raw_delivery115"
    assert len(data["actual_configurations"]) == 36 and len(data["original166_references"]) == 54
    assert data["entry_grid_seconds"] is None and data["extra_opening_quiet_seconds"] == 0
    assert data["lifecycle_definition"]["latest_only"] is True
    assert data["lifecycle_definition"]["holding_only"] is True
    expected_codes = dict(stop["全固定コードSHA256"])
    expected_codes.update(stop["所有コードSHA256"])
    expected_codes[stopped["path"]] = stopped["sha256"]
    assert data["code_sha256"] == expected_codes and len(expected_codes) == 1855
    for name, digest in expected_codes.items():
        ref(Path(name), digest)
    ref(Path(data["executable"]["path"]), "132a357f2dc805fd37865b75a1d60c1006d6002c22d51ff16336eacf35a0c024")
    life_ref = data["lifecycle_declaration"]
    ref(Path(life_ref["path"]), "8a57af83b6c1f50ebc0a3bff8ad25112026057d29b25a8ecd0c9c5ccd6978b5b")
    assert json.loads(Path(life_ref["path"]).read_text(encoding="utf-8")) == data["lifecycle_definition"]
    # ----------------------------------------
    # 成績を追記する文書と分け、市場前に決めた仮説と全36候補の原文を固定する。
    sources = [
        ("仮説", study / "README.md", "README.md.txt", None),
        ("汎用表と設定", study / "設定と結果.md", "設定と結果.md.txt", None),
        ("一次資料と心理", root / "docs/議論/外部再調査/突破失敗と持続を状態遷移で分ける.md", "一次資料と心理.md.txt", "004df4d7b5ebf45a57efa1e72bf24fed4478b64429a4a11bdcaf2aa8367adbcf"),
        ("診断からの仮説", root / "docs/議論/背景の整合と保有中の失効時計を分ける.md", "診断からの仮説.md.txt", None),
    ]
    originals = [(key, source, name, ref(source, expected)) for key, source, name, expected in sources]
    archive.mkdir(parents=True, exist_ok=False)
    records = {}
    for key, source, name, origin in originals:
        target = archive / name
        with target.open("xb") as stream:
            stream.write(source.read_bytes())
        records[key] = {"原所在": origin, "固定参照": ref(target, origin["sha256"])}
    data["fixed"] = True
    data["fixed_at_utc"] = datetime.now(timezone.utc).isoformat()
    data["research_basis"] = {key: value["固定参照"] for key, value in records.items()}
    data["research_scope"] = "既使用70。入口115とP100・Source111を維持し、armed後の構造/勢い失効だけ追加比較。11/09の本文・損益・入力指紋は未読。採用・安定性は未証明。"
    fixed = save_new(destination, data)
    proof = {
        "試行": 116, "成功": True, "市場前": True, "素材": material, "停止": stopped,
        "金融条件": fixed, "原文": records, "固定code": len(expected_codes), "候補数": 36,
        "金融実行": False, "金融定義/宣言の変更": False, "11月09読取": False,
        "全Raw最初性の検査": "金融実行後に独立原板監査で別途確認。人工/保存点一致だけで代用しない。",
    }
    save_new(here / "F1固定の確認.json", proof)
    print(json.dumps({"成功": True, "条件": fixed, "固定code": len(expected_codes), "金融実行": False}, ensure_ascii=False))


if __name__ == "__main__":
    main()
