"""固定済み独立consumerを場ごとに実行し、全70の小証拠を再認証する。"""

from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from threading import Event
import argparse
import hashlib
import json
import os
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[2]
CONSUMER = ROOT / "work/116原行から失効最初性を独立検算する/検算する.py"
STOP_SHA = "1afecc2a6a86c0702201fcd3c300ca4f0d8c2c914b08673fd5f038ad8a7ceb56"


def digest(path: Path) -> str:
    """機能: 明示された小証拠・コード・Nativeの指紋を得る。

    引数: path(Path)は原板以外の対象。
    返り値: strはSHA256。原板の再走査には使わない。
    """
    sha = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            sha.update(block)
    return sha.hexdigest()


def load_ref(ref: dict) -> dict:
    """機能: 小JSON参照を認証し復元する。

    引数: ref(dict)は絶対pathとSHA256。
    返り値: dictは復元値。Native・原板・CSVはJSON解析しない。
    """
    path = Path(ref["path"])
    assert path.is_absolute() and path.suffix == ".json" and ".Native." not in path.name
    assert digest(path) == ref["sha256"], str(path)
    return json.loads(path.read_text(encoding="utf-8"))


def save_new(path: Path, value: dict) -> dict:
    """機能: 小証拠を既存ファイルへ上書きせず保存する。

    引数: path(Path)は新規先、value(dict)は値。
    返り値: dictは保存された実物の参照。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    return {"path": str(path), "sha256": digest(path)}


# ----------------------------------------
def execute_one(task: dict, request: dict, output: Path, abort: Event) -> dict:
    """機能: 一場だけ停止済みconsumerを起動し、終了0と実小結果を認証する。

    引数: task/request(dict)、output(Path)、abort(Event)は場・Root固定・先・中断状態。
    返り値: dictは場IDと結果参照。不成功なら例外。
    """
    if abort.is_set():
        raise RuntimeError("先行不成功のため未開始")
    sid = task["session"]
    destination = output / sid
    command = [sys.executable, "-X", "utf8", str(CONSUMER), "--request", request["path"],
               "--sha", request["sha256"], "--session", sid, "--out", str(destination)]
    flags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    process = subprocess.run(command, capture_output=True, text=True, encoding="utf-8", creationflags=flags)
    with (output / "log" / (sid + ".txt")).open("x", encoding="utf-8") as stream:
        stream.write(process.stdout + process.stderr)
    if process.returncode:
        abort.set()
        raise RuntimeError(f"{sid}: consumer終了{process.returncode}。log参照")
    path = destination / "結果.json"
    ref = {"path": str(path), "sha256": digest(path)}
    value = load_ref(ref)
    assert value["成功"] is True and value["試行"] == 116 and value["stage"] == "full70"
    assert value["場"] == sid and value["Root要求"] == request and value["Native"] == task["native"]
    assert value["全Rawライフ初回性"] is True and value["P100H100初回性"] is True
    assert value["Reader成功summaryとexit0"] is True and value["前後不変"] is True
    assert value["入力SHA256前"] == value["入力SHA256後"]
    return {"session": sid, "ref": ref}


def main() -> None:
    """機能: 固定全70のconsumerを最大8場並行で実行し、成功全件だけを集約する。

    引数: CLI request(Path)、sha(str)、output(Path)、workers(int)。
    返り値: None。金融戦略や原板加工は行わず、固定consumerを変更しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--sha", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()
    assert 1 <= args.workers <= 8 and args.output.is_absolute() and not args.output.exists()
    request_ref = {"path": str(args.request.resolve()), "sha256": args.sha}
    request = load_ref(request_ref)
    assert request["trial"] == 116 and request["fixed"] is True and request["stage"] == "full70"
    assert request["raw_read_authorized"] is True and request["market_native_read_authorized"] is True
    assert request["holdout_read_authorized"] is False and request["consumer_stop"]["sha256"] == STOP_SHA
    stop = load_ref(request["consumer_stop"])
    assert stop["成功"] and stop["停止"] and stop["所有ファイルSHA256"][str(CONSUMER)] == digest(CONSUMER)
    completion = load_ref(request["completion"])
    assert completion["trial"] == 116 and completion["success"] and completion["stage"] == "full70"
    assert completion["sessions"] == 70 and completion["books"] == 2520
    assert [r["session"] for r in request["scenes"]] == [r["session"] for r in completion["results"]]
    assert len(set(r["session"] for r in request["scenes"])) == 70
    before = {str(Path(__file__).resolve()): digest(Path(__file__).resolve()), request_ref["path"]: request_ref["sha256"]}
    args.output.mkdir(parents=True, exist_ok=False)
    (args.output / "log").mkdir()
    abort = Event()
    try:
        results = []
        with ThreadPoolExecutor(max_workers=args.workers) as pool:
            futures = [pool.submit(execute_one, task, request_ref, args.output, abort) for task in request["scenes"]]
            for future in as_completed(futures):
                try:
                    results.append(future.result())
                except BaseException:
                    abort.set()
                    for pending in futures:
                        pending.cancel()
                    raise
                print(json.dumps({"完了場": len(results), "予定場": 70, "場": results[-1]["session"]}, ensure_ascii=False), flush=True)
        by_session = {row["session"]: row for row in results}
        results = [by_session[task["session"]] for task in request["scenes"]]
        positions = streamed = passes = latches = requests = fills = 0
        for task, row in zip(request["scenes"], results):
            value = load_ref(row["ref"])
            for field, expected in (("金融条件", request["condition"]), ("金融完了", request["completion"]),
                                    ("独立保存結果", request["independent_result"]), ("独立保存確認", request["independent_check"])):
                assert value[field] == expected
            for path, sha in value["入力SHA256前"].items():
                assert Path(path).suffix not in (".csv", ".jsonl")
                assert not path.endswith(".gz") or path.endswith(".Native.json.gz")
                assert path not in before or before[path] == sha
                before[path] = sha
            details = value["実玉"]
            assert len(details) == value["監視適格実玉数"]
            positions += len(details)
            streamed += value["pipe原行数"]
            passes += value["Reader成功summary"]["raw_passes"]
            latches += sum(p["初ラッチ"] is not None for p in details)
            requests += sum(p["初要求"] is not None for p in details)
            fills += sum(p["初life実fill"] is not None for p in details)
        assert positions > 0 and requests > 0 and passes == 70
        after = {path: digest(Path(path)) for path in before}
        assert before == after
        summary = {"試行": 116, "成功": True, "stage": "full70", "場数": 70,
                   "金融条件": request["condition"], "金融完了": request["completion"],
                   "独立保存結果": request["independent_result"], "独立保存確認": request["independent_check"],
                   "Root要求": request_ref, "consumer停止": request["consumer_stop"], "結果": results,
                   "監視適格実玉数": positions, "pipe原行数": streamed, "原板pass数": passes,
                   "初ラッチ実玉数": latches, "初要求実玉数": requests, "初life実fill実玉数": fills,
                   "全Rawライフ初回性": True, "P100H100初回性": True,
                   "P100全床/全追尾幅Raw再形成": False, "新規fill最初性": False,
                   "対象範囲": "監視適格な実XC/XQ玉の取得〜最終返済の和集合。X0/不適格は対象外。延べ玉数は独立市場機会数ではない。",
                   "前SHA256": before, "後SHA256": after, "前後不変": True,
                   "金融再実行": False, "全Raw複写": False, "11月09読取": False,
                   "研究目標達成": False, "採用": False}
        print(json.dumps({"成功": True, "集約": save_new(args.output / "全70原行監査の確認.json", summary)}, ensure_ascii=False))
    except BaseException as error:
        abort.set()
        save_new(args.output / "不完了.json", {"試行": 116, "成功": False, "Root要求": request_ref, "理由": str(error)})
        raise


if __name__ == "__main__":
    main()
