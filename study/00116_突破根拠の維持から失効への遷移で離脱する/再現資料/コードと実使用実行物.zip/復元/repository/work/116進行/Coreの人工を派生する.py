"""116Coreへ市場を読まない既115の意味ある接続人工を派生する。"""

from pathlib import Path


def main() -> None:
    """
    機能: 前史/出生/源非干渉の人工を36口座と旧115対照へ接続する。
    引数: なし。
    返り値: None。実行は部品実装後に別工程で行う。
    """
    root = Path(__file__).resolve().parents[2]
    original = root / "work/115三時間軸の複合入口の連続比較"
    folder = root / "work/116保有根拠の連続比較"
    for relative in ("source_fixture_test.go", "runtime_test.go", "entry_input_test.go"):
        path = folder / relative
        assert not path.exists()
        text = (original / relative).read_text(encoding="utf-8")
        text = text.replace("package entrycomparison115", "package lifecomparison116")
        text = text.replace("/continuousactor115", "/continuousactor116")
        text = text.replace("/entrycomparison114", "/entrycomparison115")
        text = text.replace("CompareReference114Values", "CompareReference115Values")
        text = text.replace("Trial: 115", "Trial: 116")
        text = text.replace("EXPORT115_CORE", "EXPORT116_CORE").replace("TestExportCoreArtificial115", "TestExportCoreArtificial116")
        text = text.replace('"試行": 115', '"試行": 116')
        if relative == "runtime_test.go":
            text = text.replace("c, old := NewWithEntry(input), legacy.New()", "c, old := NewWithEntry(input), legacy.NewWithEntry(legacy.PublicationInput{Session: input.Session, Children: input.Children, Seed: input.Seed, Audit: legacy.EntryInputAudit(input.Audit)})")
            text = text.replace('key := fmt.Sprintf("%s_C%.0f_D%d", config.EntryMode, config.SlipPts, config.DelaySeconds)', "key := BookKey(config)")
            text = text.replace("旧114A0四対照", "旧115全12のX0対照").replace("12口座", "36口座").replace("人工旧114", "人工旧115")
        with path.open("x", encoding="utf-8", newline="\n") as handle:
            handle.write(text)


if __name__ == "__main__":
    main()
