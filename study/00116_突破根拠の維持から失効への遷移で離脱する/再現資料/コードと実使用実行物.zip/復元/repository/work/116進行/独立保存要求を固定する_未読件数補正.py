"""116の成功した段階だけを独立保存へ渡すRoot要求を固定する。"""

import argparse
import hashlib
import json
from pathlib import Path


def ref(path: Path, expected: str | None = None) -> dict:
    """機能: 明示した小metadata・コードの指紋を確認する。

    引数: path(Path)は対象、expected(str|None)は任意の期待SHA256。
    返り値: dictは絶対位置とSHA256。Raw・Native・価格CSV本文は読まない。
    """
    path = path.resolve()
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    assert expected is None or sha == expected, str(path)
    return {"path": str(path), "sha256": sha}


def main() -> None:
    """機能: 同F1・全36・旧12対照・全残0の成功から新要求を作る。

    引数: CLI stage(str)、completion(Path)、sha256(str)。
    返り値: None。価格参照は旧要求から文字列だけを再用し、入力本文を開かない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("first2", "base54", "full70"), required=True)
    parser.add_argument("--completion", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    here = Path(__file__).resolve().parent
    template = here / f"{args.stage}_独立保存ひな型_未読件数補正.json"
    ref(template)
    request = json.loads(template.read_text(encoding="utf-8"))
    assert request["version"] == 1 and request["trial"] == 116 and request["stage"] == args.stage
    for field in ("fixed", "market_native_read_authorized", "legacy115_read_authorized", "raw_read_authorized", "holdout_read_authorized"):
        assert request[field] is False
    fixed_ref = ref(here / "F1_116金融条件.json", "4c76a5f7cd8a59962e885cadf6885cfc75cbc590675955cb8e72ae2d0b8bb372")
    assert request["condition"] == fixed_ref
    fixed = json.loads(Path(fixed_ref["path"]).read_text(encoding="utf-8"))
    assert fixed["fixed"] is True and len(fixed["actual_configurations"]) == 36
    for field, expected in (
        ("code_stop", "397ee90a93f491f5cf1842f70b4a974a0435fdb84eae8987416881e40af5a12d"),
        ("P_stop", "6c1e1f74465527550d0ca2b62127495a7d5c3c70c5a125a0576801873a26f47d"),
        ("life_stop", "ec1f6fef55c1717e3592be24c74259d5f837be2eb0096dea73c2ce0a39805769"),
    ):
        ref(Path(request[field]["path"]), expected)
        assert request[field]["sha256"] == expected
    for field in ("actor_stop", "lifecycle_go_stop", "entry115_stop", "protection_code", "lifecycle_code", "entry_code"):
        ref(Path(request[field]["path"]), request[field]["sha256"])
    completion = ref(args.completion, args.sha256)
    assert request["completion"] == completion
    market = json.loads(args.completion.read_text(encoding="utf-8"))
    count = {"first2": 2, "base54": 54, "full70": 70}[args.stage]
    assert market["trial"] == 116 and market["success"] is True and market["stage"] == args.stage
    assert market["condition_sha256"] == fixed_ref["sha256"] and market["sessions"] == count and market["books"] == count * 36
    assert market["unchanged"] is True and market["before"] == market["after"]
    assert market["all_reference115_equal"] is True and market["all_source111_equal"] is True
    assert market["reference115_comparisons"] == count * 12
    # ----------------------------------------
    # 既115の価格URL/ファイル名を参照文字列として再用する。Rawのstatや指紋計算もしない。
    old_path = root / "work/115進行/full70_独立保存要求.json"
    ref(old_path, "34fc95141b64efcede3f42984e9ebf7daadc3eec70fd1ca1f084df2a3cfe8f83")
    paths = {row["session"]: row["market_path"] for row in json.loads(old_path.read_text(encoding="utf-8"))["scenes"]}
    assert len(request["scenes"]) == count and len(paths) == 70
    for final, task in zip(market["results"], request["scenes"]):
        assert task["session"] == final["session"] and task["native"] == final["native"] and task["reference115"] == final["reference115"]
        assert final["complete"] is True and final["books"] == 36
        assert final["open_quantity"] == final["pending_quantity"] == 0
        assert final["x0_equal"] is True and final["x0_comparisons"] == 12
        assert final["reference115_equal"] is True and final["source111_equal"] is True
        task["market_path"] = paths[task["session"]]
    request.update(fixed=True, market_native_read_authorized=True, legacy115_read_authorized=True)
    destination = here / f"{args.stage}_独立保存要求_未読件数補正.json"
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(request, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps(ref(destination), ensure_ascii=False))


if __name__ == "__main__":
    main()
