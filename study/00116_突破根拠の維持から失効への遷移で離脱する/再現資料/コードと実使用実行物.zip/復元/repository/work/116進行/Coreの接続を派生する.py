"""116の独立コピーへ版・比較先・36口座の接続を施す。"""

from pathlib import Path


def main() -> None:
    """
    機能: コピー済み115原文だけを116Coreへ派生し旧コードを変更しない。
    引数: なし。
    返り値: None。純部品・Actor待ちの編集段階であり市場実行しない。
    """
    root = Path(__file__).resolve().parents[2]
    folder = root / "work/116保有根拠の連続比較"
    assert (folder / "派生の原文.json").exists()
    assert not (folder / "派生の編集開始.txt").exists()
    for relative in ("runtime.go", "fixed.go", "entry_input.go", "runner/parallel.go", "runner/process_windows.go", "runner/process_other.go", "cmd/run/main.go", "go.mod"):
        path = folder / relative
        text = path.read_text(encoding="utf-8-sig")
        text = text.replace("package entrycomparison115", "package lifecomparison116")
        text = text.replace("/entrycomparison115", "/lifecomparison116")
        text = text.replace("/entrycomparison114", "/entrycomparison115")
        text = text.replace("/continuousactor115", "/continuousactor116")
        text = text.replace("entrycomparison114", "entrycomparison115")
        text = text.replace("../114順行と反転取得の連続比較", "../115三時間軸の複合入口の連続比較")
        text = text.replace("../115三時間軸の複合入口を執行する会計", "../116突破失敗を返済へ結ぶ会計")
        for old, new in (("References114", "References115"), ("Reference114", "Reference115"), ("reference114", "reference115"), ("reference114", "reference115"), ("A0Comparisons", "X0Comparisons"), ("A0Equal", "X0Equal")):
            text = text.replace(old, new)
        text = text.replace("a0_comparisons", "x0_comparisons").replace("a0_equal", "x0_equal").replace("reference114", "reference115")
        text = text.replace("actor.LegacyComparison115", "actor.LegacyComparison116").replace("actor.CompareLegacy114", "actor.CompareLegacy115")
        # 旧版を読む比較だけを115へ進め、純入口/bank115の型名・定義は据え置く。
        for old, new in (("Trial: 115", "Trial: 116"), ("f.Trial != 115", "f.Trial != 116"), ("p.Fixed.Trial != 115", "p.Fixed.Trial != 116"), ("stop.Trial != 115", "stop.Trial != 116"), ("current.Trial != 115", "current.Trial != 116"), ("value.Trial != 115", "value.Trial != 116"), ("a.Trial != 115", "a.Trial != 116"), ("old.Trial != 115", "old.Trial != 116"), ("prior.Trial != 114", "prior.Trial != 115"), ("prior.Actual.Trial != 114", "prior.Actual.Trial != 115")):
            text = text.replace(old, new)
        if relative == "go.mod":
            text += "\nrequire github.com/masayoshi4649/SessionTradeExecuter/entrylife116 v0.0.0\nreplace github.com/masayoshi4649/SessionTradeExecuter/entrylife116 => ../116突破根拠の維持と失効\n"
        path.write_text(text, encoding="utf-8", newline="\n")
    (folder / "派生の編集開始.txt").write_text("116編集開始。金融未実行。旧115・純入口115・bank115・P113は変更しない。\n", encoding="utf-8")


if __name__ == "__main__":
    main()
