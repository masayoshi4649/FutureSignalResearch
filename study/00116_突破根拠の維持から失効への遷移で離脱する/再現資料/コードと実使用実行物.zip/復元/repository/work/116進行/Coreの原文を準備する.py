"""停止115の所有コードから116接続の独立した編集元を用意する。"""

import hashlib
import json
from pathlib import Path


def main() -> None:
    """
    機能: 必要なGo所有ファイルだけを元SHAで認証して新フォルダへコピーする。
    引数: なし。
    返り値: None。生成直後は115の原文であり、116実行物や金融成功を意味しない。
    """
    root = Path(__file__).resolve().parents[2]
    original = root / "work/115三時間軸の複合入口の連続比較"
    stop = original / "停止.json"
    assert hashlib.sha256(stop.read_bytes()).hexdigest() == "1dca0288b00682c965491bcf0209a45a0bbc4eaf527b0224063db9bcda7f77d8"
    hashes = json.loads(stop.read_text(encoding="utf-8"))["所有コードSHA256"]
    target = root / "work/116保有根拠の連続比較"
    assert not target.exists()
    files = ("runtime.go", "fixed.go", "entry_input.go", "runner/parallel.go", "runner/process_windows.go", "runner/process_other.go", "cmd/run/main.go", "go.mod", "go.sum")
    rows = []
    for relative in files:
        source = original / relative
        body = source.read_bytes()
        digest = hashlib.sha256(body).hexdigest()
        assert hashes[str(source)] == digest
        path = target / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as handle:
            handle.write(body)
        rows.append({"relative": relative, "origin": str(source), "sha256": digest, "同bytes": True})
    proof = {"試行": 116, "成功": True, "意味": "停止115の所有9ファイルを同bytesで独立コピー。116の編集・検査・停止・金融は未実行。", "元停止": str(stop), "コピー": rows}
    (target / "派生の原文.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "コピー数": len(rows)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
