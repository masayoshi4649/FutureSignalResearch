"""手製116Core人工を圧縮し、独立監査へ渡す小さい参照を作る。"""

import argparse
import gzip
import hashlib
import json
from pathlib import Path


def digest(path: Path) -> str:
    """
    機能: 大きい手製JSONも固定メモリでSHA256を求める。
    引数: path(Path)は人工だけのファイル。
    返り値: strはSHA256。
    """
    result = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            result.update(chunk)
    return result.hexdigest()


def main() -> None:
    """
    機能: Coreの6手製系列216冊を圧縮し人工であることを明示する。
    引数: folder(str)、stem(str)、series(int)は人工フォルダ名・ファイル基底名・系列数。
    返り値: None。市場実績や自然FAR生成へ読み替えない。
    """
    root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser()
    parser.add_argument("--folder", choices=("人工_入口と保有", "人工_失効と所有"), default="人工_入口と保有")
    parser.add_argument("--stem", choices=("Core人工", "Core失効人工"), default="Core人工")
    parser.add_argument("--series", type=int, choices=(2, 6), default=6)
    args = parser.parse_args()
    folder = root / "work/116保有根拠の連続比較" / args.folder
    source, packed, manifest = folder / (args.stem + ".json"), folder / (args.stem + ".json.gz"), folder / "人工の参照.json"
    assert source.is_file() and not packed.exists() and not manifest.exists()
    sha = digest(source)
    with source.open("rb") as reader, packed.open("xb") as target, gzip.GzipFile(filename="", mode="wb", fileobj=target, mtime=0, compresslevel=6) as compressor:
        while chunk := reader.read(1024 * 1024):
            compressor.write(chunk)
    assert digest(source) == sha
    proof = {"試行": 116, "成功": True, "人工": True, "市場": False, "FAR自然生成": False,
             "系列数": args.series, "各系列会計数": 36, "総会計数": args.series * 36,
             "原文": {"path": str(source), "sha256": sha, "bytes": source.stat().st_size},
             "圧縮": {"path": str(packed), "sha256": digest(packed), "bytes": packed.stat().st_size},
             "実装段階": "停止前。Source非干渉・旧X0全12・公表asofの手製接続。Core失効人工は新失効とP100外部予約の正例、Core人工は入口/前史の6系列。市場/FAR自然生成の証明ではない。",
             "金融F1固定": False, "11月09読取": False}
    with manifest.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(json.dumps(proof, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"path": str(manifest), "sha256": digest(manifest), "圧縮bytes": packed.stat().st_size}, ensure_ascii=False))


if __name__ == "__main__":
    main()
