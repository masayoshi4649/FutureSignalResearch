"""116の完了済み段階と結果を目次・試行へ反映する。"""

import hashlib
import json
import os
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / 'study/00116_突破根拠の維持から失効への遷移で離脱する'
CSV = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/116損益CSV/README.md'


def link(label: str, source: Path, target: Path) -> str:
    """機能: 日本語文書から相対Markdownリンクを作る。

    引数: label(str)は表示、source/target(Path)は元文書と参照先。
    返り値: strは相対リンク。
    """
    return '[' + label + '](' + os.path.relpath(target, source.parent).replace('\\', '/') + ')'


def write(path: Path, content: str) -> None:
    """機能: UTF-8で文書を書き込む。

    引数: path(Path)は保存先、content(str)は本文。
    返り値: None。固定市場前資料・金融結果は変更しない。
    """
    path.write_text(content, encoding='utf-8', newline='\n')


def main() -> None:
    """機能: 実在する成功証拠の範囲だけを現在の案内へ記す。

    引数: なし。
    返り値: None。未完了の保存/Viewerを成功としない。
    """
    proof = STUDY / '検査/正式保存の確認.json'
    formal = proof.exists() and json.loads(proof.read_text(encoding='utf-8'))['成功'] is True
    viewer_path = STUDY / '検査/Viewer確認.json'
    viewer = viewer_path.exists() and json.loads(viewer_path.read_text(encoding='utf-8'))['成功'] is True
    conclusion = '金融F1を固定し、全70場・36条件・2,520会計を計算した。独立保存は同F1元54の成功を認証継承し、追加16を新規照合した。旧115対照840・Source全文同体・全残玉予約0と、適格XC/XQの全70原行監査が成功した。'
    conclusion += 'CSV二点の全セル再読とNativeの可逆保管が成功。'
    conclusion += '正式保存が完了した。' if formal else '正式保存は確認中。'
    conclusion += '専用Viewerの一覧2,520IDと11/06日夜72資源をHTTP照合した（全資源GET・描画ではない）。' if viewer else 'ViewerのHTTP確認は未完了。'
    conclusion += '追加退出はA0の純額を悪化させ、片道追加滑り5ptでは対照も赤字である。採用なし、未知期間の安定性は未確認、11/09は未読。'
    readme = STUDY / 'README.md'
    text = readme.read_text(encoding='utf-8-sig')
    blocks = text.split('\n\n')
    blocks[1] = '2026-11-10。' + conclusion
    text = '\n\n'.join(blocks)
    text = text.replace('[全手法・設定と未実行結果]', '[全手法・設定と結果]')
    start = '\n## 全70場の結果と保存範囲\n'
    if start in text:
        text = text[:text.index(start)]
    text += '''
## 全70場の結果と保存範囲

費用後完結建玉の正額合計を利益、負額合計を損失とする。PFは利益÷損失絶対値、平均比は勝ち平均÷負け平均絶対値。数量可変であり、平均額は1枚換算ではない。

|全70場・D0|利益総額 円|損失総額 円|PF|平均利益損失比|純損益 円|
|---|---:|---:|---:|---:|---:|
|A0・X0・C0|6,514,793|−5,387,806|1.209|1.047|1,126,987|
|A0・XC・C0|6,495,178|−5,440,191|1.194|1.042|1,054,987|
|A0・XQ・C0|6,495,178|−5,442,191|1.193|1.041|1,052,987|
|A0・X0・C5|5,575,641|−5,938,654|0.939|0.893|−363,013|
|A0・XC・C5|5,561,026|−5,996,039|0.927|0.888|−435,013|
|A0・XQ・C5|5,561,026|−5,998,039|0.927|0.888|−437,013|

X0は元入口＋P100であり、原手法S0ではない。XC/XQはC0D0で対照より72,000円/74,000円悪化した。元54だけのPFや黒字を全70へ拡張しない。全36条件・利益/損失・DD・勝率・回数・起動/退出・全場の累計は[CSVの案内](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/116損益CSV/README.md)を参照する。

追加退出が実際に変わった相場は2例だった。[同入口の診断](診断/2例の実退出と当時の根拠.md)で、9/30夜の買い5枚はX0＋19,615円→XC/XQ−60,385円、10/26夜の売り2枚はX0−18,154円→XC−10,154円/XQ−12,154円。前者は中長期の順側根拠が残る中の短期失速、後者は取得後に確定した局所波の失速だった。これは当時値の記述であり、2例から売買分類器が完成したとはしない。退出後の仮想利益は算出しない。

原行監査の808実玉・40失効要求/約定は、入口・費用条件に重複する延べ件数。40の独立した相場例ではない。P100のH100初回起動とlife最初性が対象で、P100全床/幅の原行再形成・新規fill最初性・X0/監視不適格は対象外。CSVと独立結果のRaw未結合フラグは保存当時の範囲を残し、後の別監査成功で書き換えない。

金融Nativeは527,218,941bytesの元gzipを全件複写せず、22,063,488bytesの可逆zstd70点と索引を保管する。JSONと元gzipの全bytes/SHA/size一致を確認済み。実trades2,520点は正式内に保存し、Viewer一覧のwork依存を外す。原板全70場や価格CSVの複写は行わない。

Viewer市場参照は67場の共有原板と、[恒久保管した105生成3gzip](../../inputs/105生成原板/README.md)に分ける。3場は元work入力と同SHA/sizeで一度だけ保存し、金融F1・元入力台帳・旧保存は変更していない。旧金融再現では固定した元pathへ同bytes復元する。Viewer接続の価格意味解析・新しい金融計算は行わない。

保有管理の次の問いは[枚数・取得位置・短期保護](../../docs/議論/枚数と取得位置と短期利益保護を分けて検証する.md)。費用後W>0での起動、最低取得価格床と費用後ゼロ床、原行/暫定1分の技術的失速、5/15/30分の背景、実数量とSource仮想数量を分ける。116のP100や固定条件を後から変更しない。
'''
    if formal:
        text += '\n[正式保存の確認](検査/正式保存の確認.json)、[全70原行監査](検査/raw_check.json)、[再現手順](再現資料/再現手順.md)、[閲覧一覧](成果物/一覧.resources.json)へ結ぶ。\n'
    if viewer:
        text += '\n[Viewerの確認](検査/Viewer確認.json)は一覧IDと代表場の実約定・費用後純額・残玉0のHTTP照合であり、全2,520資源GETや画面描画は未確認。\n'
    write(readme, text)

    # ----------------------------------------
    indexes = [ROOT / 'README.md', ROOT / 'docs/README.md', ROOT / 'study/README.md',
               ROOT / 'docs/議論/README.md', ROOT / 'docs/technical-analysis/README.md',
               ROOT / 'docs/議論/外部再調査/README.md']
    focus = ROOT / 'docs/議論/枚数と取得位置と短期利益保護を分けて検証する.md'
    knowledge = ROOT / 'docs/議論/増玉と短期保護を調べて分かったこと.md'
    for path in indexes:
        text = path.read_text(encoding='utf-8-sig')
        blocks = text.split('\n\n')
        found = [i for i, block in enumerate(blocks) if block.startswith('[116：')]
        if len(found) > 1:
            raise ValueError('116の目次段落が重複: ' + str(path))
        paragraph = link('116：突破根拠の維持から失効への遷移で離脱する', path, readme) + '。' + conclusion + link('損益CSV', path, CSV) + '。'
        if found:
            blocks[found[0]] = paragraph
        else:
            blocks.insert(1, paragraph)
        links = [link('枚数・取得位置・短期保護の次の方針', path, focus)]
        if knowledge.exists():
            links.append(link('増玉と短期保護で分かったこと', path, knowledge))
        marker = '最新の診断と次の問い：'
        blocks = [b for b in blocks if not b.startswith(marker)]
        blocks.insert(2, marker + '、'.join(links) + '。')
        write(path, '\n\n'.join(blocks))
    state_path = ROOT / 'work/116進行/現在.json'
    state = json.loads(state_path.read_text(encoding='utf-8-sig'))
    state.update({'正式保存': formal, 'Viewer確認': viewer, '研究目標達成': False, '採用': False})
    write(state_path, json.dumps(state, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'成功': True, '正式保存': formal, 'Viewer確認': viewer, '目次数': len(indexes)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
