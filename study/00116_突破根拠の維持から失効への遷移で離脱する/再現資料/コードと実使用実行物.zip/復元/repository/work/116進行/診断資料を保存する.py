"""115の保有中状態診断を、116の事前根拠として保存する。"""

import hashlib
import json
from pathlib import Path
import zipfile


def main() -> None:
    """
    機能: 成功した補正版と復元に必要な小コードだけを新規正式保存する。
    引数: なし。
    返り値: None。元のNative・原板・CSVや初版の全件台帳を重複保存しない。
    """
    root = Path(__file__).resolve().parents[2]
    source = root / "work/116根拠失効の事前診断"
    target = root / "study/00116_突破根拠の維持から失効への遷移で離脱する/根拠/115保有中の公表状態"
    assert not target.exists()
    known = {
        "調査.md": "dd6438bacf6504f2fc86ca01d697f8ac50ac184e0add6ad513f5763e67cce3b0",
        "同原行一括版/記述診断の結果.json": "20df2e66891829be56c30df4b5902435a1320b2897563a6e7fa9a733f7be6b72",
        "同原行一括版/保有中の公表状態台帳.json.gz": "65495fcaada68882dadc1a48b94c2d4e22c6bc1775e3b9ed96379d3dce7e455a",
        "同原行一括版/同原行補正の独立照合.json": "dc9d99c4a066202e2e89c65f37e5f4056c5a4e49046be9a6daea3f4733ea6d9f",
    }
    for name in ("記述条件と人工の固定.json", "同原行一括版/記述条件と人工の固定.json"):
        known[name] = hashlib.sha256((source / name).read_bytes()).hexdigest()
    for name, digest in known.items():
        assert hashlib.sha256((source / name).read_bytes()).hexdigest() == digest
    target.mkdir(parents=True)
    for name, digest in known.items():
        path = target / name
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("xb") as handle:
            handle.write((source / name).read_bytes())
        assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    entries = []
    archive_path = target / "診断コード.zip"
    with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in ("状態を診断する.py", "人工検査.py", "同原行一括版/状態を診断する.py", "同原行一括版/人工検査.py"):
            path = source / name
            relative = path.relative_to(root).as_posix()
            body = path.read_bytes()
            entry = "復元/repository/" + relative
            archive.writestr(entry, body)
            entries.append({"元の復元先": str(path), "entry": entry, "sha256": hashlib.sha256(body).hexdigest(), "bytes": len(body)})
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        for item in entries:
            assert hashlib.sha256(archive.read(item["entry"])).hexdigest() == item["sha256"]
            item["CRC"] = archive.getinfo(item["entry"]).CRC
    value = {"試行": 116, "成功": True, "用途": "115既実績の事前記述。116損益ではない。", "同bytes保存": known,
             "コードZIP": {"path": str(archive_path), "sha256": hashlib.sha256(archive_path.read_bytes()).hexdigest()}, "entries": entries,
             "復元": "ZIP内コードは元のworkへ復元して実行。元115Nativeは115正式Native台帳から元pathへ同bytesで復元する。初版台帳はコードで再作成でき、正式へ全件複写しない。",
             "金融再実行": False, "原板_CSV_Native複写": False, "11月09読取": False}
    (target / "保存と復元.json").write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "正式先": str(target), "保存ファイル": len(known), "コード": len(entries)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
