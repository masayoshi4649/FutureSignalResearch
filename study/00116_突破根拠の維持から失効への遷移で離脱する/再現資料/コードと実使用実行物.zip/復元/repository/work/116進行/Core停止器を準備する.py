"""115の停止器を116の36口座・12対照・失効正例へ限定派生する。"""

from pathlib import Path


def main() -> None:
    """
    機能: 部品の成功停止Refを結び、新Coreの市場前停止helperを用意する。
    引数: なし。
    返り値: None。helperを準備するだけで停止・金融実行は行わない。
    """
    root = Path(__file__).resolve().parents[2]
    original = root / "work/115三時間軸の複合入口の連続比較/検査して停止する.py"
    folder = root / "work/116保有根拠の連続比較"
    target = folder / "検査して停止する.py"
    assert not target.exists()
    text = original.read_text(encoding="utf-8")
    changes = (
        ("'core114': ('114順行と反転取得の連続比較/停止.json','8e48f8c008a3bb6ab72ef9ec21f2b474dc403c79aa4a6b1a34f7b1d30d0ae729')", "'core115': ('115三時間軸の複合入口の連続比較/停止.json','1dca0288b00682c965491bcf0209a45a0bbc4eaf527b0224063db9bcda7f77d8')"),
        ("'actor': ('115三時間軸の複合入口を執行する会計/Actor停止.json','318de27a32a0941114443e5045426df3599eea74e8e5ffa8647771e92934ce35')", "'actor': ('116突破失敗を返済へ結ぶ会計/Actor停止.json','d5a1f5c3d30109b54173b1f8179152e671ced89830aa855a02bc42f24f2a89e1'),\n 'lifecycle': ('116突破根拠の維持と失効/停止.json','bf808c3d034d148f470230e3248443174fd9f22cedb571293b6e95020e72e296')"),
        ("'runtime_test.go','source_fixture_test.go'", "'runtime_test.go','lifecycle_test.go','source_fixture_test.go'"),
        ("'派生の参照.json'", "'派生の原文.json'"),
        ("stops['actor']['実12宣言']", "stops['actor']['実36宣言']"),
        ("entry_chart_ref = stops['entry_chart']['実定義']", "entry_chart_ref = stops['entry_chart']['実定義']\n    life_ref = stops['lifecycle']['実定義']"),
        ("actual_ref, pure_ref, entry_ref, chart_ref, entry_chart_ref)", "actual_ref, pure_ref, entry_ref, chart_ref, entry_chart_ref, life_ref)"),
        ("EXPORT115_CORE", "EXPORT116_CORE"), ("PARALLEL115_ART_OUT", "PARALLEL116_ART_OUT"),
        ("ROOT / 'work/115三時間軸の複合入口を執行する会計'", "ROOT / 'work/116突破失敗を返済へ結ぶ会計', ROOT / 'work/116突破根拠の維持と失効'"),
        ("115連続比較.exe", "116連続比較.exe"),
        ("'trial': 115", "'trial': 116"),
        ("'isolated_session_process115_v1'", "'isolated_session_process116_v1'"),
        ("'実入口公開宣言':entry_chart_ref", "'実入口公開宣言':entry_chart_ref, '実ライフ宣言':life_ref"),
        ("'A0旧114A0四費用のCore終端全金融対照':True, '旧114A0毎原行はActor停止へ参照':True", "'X0旧115全12のCore終端全金融対照':True, '旧115全12毎原行はActor停止へ参照':True"),
        ("study/00114_順行と反転の取得確認を分ける", "study/00115_三時間軸の方向性と局所構造で入口を分ける"),
        ("b0bf17c4bcd435dcca13da12995a11a9c6f5617f86a27ca2f0994528a3823167", "94bb656a1607d59039a0c5ec0f06968a4da72463d27c0847606a09fc52fc4693"),
        ("len(actual) != 12", "len(actual) != 36"),
        ("'original166_source111_p100_entry_confirmation115'", "'original166_source111_p100_entry115_lifecycle116'"),
        ("'p100_entry_confirmation115'", "'p100_entry115_lifecycle116'"),
        ("'reference114'", "'reference115'"),
        ("'entry_chart_declaration':entry_chart_ref,", "'entry_chart_declaration':entry_chart_ref,\n                'lifecycle_definition':json.loads(Path(life_ref['path']).read_text(encoding='utf-8-sig')),\n                'lifecycle_declaration':life_ref,"),
    )
    for before, after in changes:
        assert before in text, before
        text = text.replace(before, after)
    text = text.replace("'人工_入口独立用_新規原行'", "'人工_入口と保有'")
    old_check = "if digest(public_dir / 'Core人工.json') != digest(stopped_dir / 'Core人工.json'):\n        raise ValueError('独立へ渡したCore人工と停止時出力の差')"
    new_check = """if digest(public_dir / 'Core人工.json') != digest(stopped_dir / 'Core人工.json'):
        raise ValueError('独立へ渡したCore人工と停止時出力の差')
    if digest(HERE / '人工_失効と所有/Core失効人工.json') != digest(stopped_dir / 'Core失効人工.json'):
        raise ValueError('独立へ渡した失効正例と停止時出力の差')"""
    assert old_check in text
    text = text.replace(old_check, new_check)
    text = text.replace("115の", "116の").replace("新115", "新116").replace("旧114金融条件差", "旧115金融条件差").replace("三モード12", "三入口×三失効36")
    with target.open("x", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


if __name__ == "__main__":
    main()
