"""保存器の拡張子条件に合う同bytesの設定ひな型を結ぶ。"""

import hashlib
import json
from pathlib import Path


def main() -> None:
    """機能: 設定の内容を変えず、txt保存素材を新要求へ結ぶ。

    引数: なし。
    返り値: None。既要求・保存器停止・金融条件は変更しない。
    """
    root = Path(__file__).resolve().parents[2]
    old = root / 'work/116進行/全70正式保存のRoot要求_恒久市場参照.json'
    body = old.read_bytes()
    if hashlib.sha256(body).hexdigest() != 'b6741a3b70e9896d4a0a942dc552bdd2fee48a62218fc2e1bf65ce7ba4470c62':
        raise ValueError('直前のRoot要求')
    request = json.loads(body)
    selected = [row for row in request['extra_refs'] if row['target'] == '再現資料/Viewer設定ひな型.txt']
    if len(selected) != 1:
        raise ValueError('設定ひな型1点')
    row = selected[0]
    data = Path(row['ref']['path']).read_bytes()
    if hashlib.sha256(data).hexdigest() != row['ref']['sha256']:
        raise ValueError('設定の同bytes')
    new = root / 'work/116進行/Viewer設定ひな型.txt'
    with new.open('xb') as stream:
        stream.write(data)
    row['ref']['path'] = str(new)
    request['ひな型の保存分類補正'] = '元.templateを同bytesの.txtへ複写して拡張子gateに適合。TOML内容・金融・停止は不変。直前metadataは正式書込み前に停止した。'
    code = Path(__file__).resolve()
    request['code_refs'].append({'ref': {'path': str(code), 'sha256': hashlib.sha256(code.read_bytes()).hexdigest()}, 'role': '同bytes設定素材の保存分類補正のみ'})
    out = old.with_name('全70正式保存のRoot要求_恒久市場参照_設定分類補正.json')
    with out.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(request, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'成功': True, 'path': str(out), 'sha256': hashlib.sha256(out.read_bytes()).hexdigest()}, ensure_ascii=False))


if __name__ == '__main__':
    main()
