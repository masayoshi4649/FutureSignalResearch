"""元の全70正式要求へ、同bytesの恒久価格参照だけを結ぶ。"""

import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PREP = ROOT / 'work/116正式保存への接続_恒久市場参照'


def reference(path: Path, expected: str | None = None) -> dict:
    """機能: 明示metadataと後段コードのSHAを照合する。

    引数: path(Path)は指定先、expected(str|None)は既知SHA。
    返り値: dictは絶対path/SHA256。価格・金融結果の意味解析はしない。
    """
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if expected is not None and digest != expected:
        raise ValueError('SHA不一致: ' + str(path))
    return {'path': str(path), 'sha256': digest}


def main() -> None:
    """機能: Rootレビュー後の新停止と恒久移設を派生要求へ固定する。

    引数: CLI stop(Path)/stop-sha(str)はRoot確認済みの保存器停止。
    返り値: None。旧要求・市場前資料・金融・CSVは変更しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--stop', required=True, type=Path)
    parser.add_argument('--stop-sha', required=True)
    args = parser.parse_args()
    old_path = ROOT / 'work/116進行/全70正式保存のRoot要求.json'
    old_ref = reference(old_path, '44f063ddd621e41a3822f5613de0673a32d4bcf50ac06f1fd2fa4775eafcf32a')
    request = json.loads(old_path.read_text(encoding='utf-8'))
    stop_ref = reference(args.stop.resolve(), args.stop_sha)
    stop = json.loads(Path(stop_ref['path']).read_text(encoding='utf-8'))
    if not all(stop[k] is True for k in ('成功', '停止', 'Rootレビュー後', '前後不変')):
        raise ValueError('Rootレビュー後の新保存器停止')
    request['refs'].update(formal_stop=stop_ref, code_sources=stop['停止Ref一覧'], code_material=stop['コード分類素材'],
                           market_relocation=reference(ROOT / 'inputs/105生成原板/保存の確認.json',
                           '7b4564fc7639afe4c831c3caa84789126a92ddfbdc84aeb6399ed0754c0bcec3'))
    request['派生元要求'] = old_ref
    request['派生理由'] = '旧正式器metadataは3場のwork生成価格を拒否し、正式書込み前に停止した。金融と元catalogを変えず、同SHA恒久3入力へViewer市場参照だけを接続する。'
    request['Rootレビュー'] += ' 恒久市場参照版を別担当とRootで読取レビューし人工を確認。67共有参照は維持、3生成入力は一度だけ同bytes保管、旧work入力は保持する。'
    codes = [Path(__file__).resolve(), ROOT / 'work/116進行/結果文書を更新する_版2.py',
             ROOT / 'work/116進行/保存後を確認する.py', PREP / '生成入力を恒久保管する.py',
             ROOT / 'work/116Viewer確認の準備/Viewer取得を確認する.py']
    for path in codes:
        if not any(Path(row['ref']['path']) == path for row in request['code_refs']):
            request['code_refs'].append({'ref': reference(path), 'role': 'Rootの保存・閲覧接続・文書確認。金融閉包と別の後段コード'})
    extras = [(old_path, '検査/恒久市場参照追加前のRoot要求.json', '旧要求はmetadataで正式書込み前に停止した履歴'),
              (PREP / '限定差と実catalog市場接続の確認.json', '検査/Viewer市場参照の限定差.json', '共有67場不変と生成3場だけの参照移設。金融validate同体'),
              (ROOT / 'work/116Viewer確認の準備/準備の確認.json', '検査/Viewer準備の確認.json', '実HTTP前のコード/設定準備確認'),
              (ROOT / 'work/116Viewer確認の準備/viewer.toml.template', '再現資料/Viewer設定ひな型.txt', '実使用の設定ひな型。元TOMLと同bytesを保持')]
    for path, target, role in extras:
        if any(Path(row['ref']['path']) == path for row in request['extra_refs']):
            raise ValueError('追加保存の重複')
        request['extra_refs'].append({'ref': reference(path), 'target': target, 'role': role})
    out = ROOT / 'work/116進行/全70正式保存のRoot要求_恒久市場参照.json'
    with out.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(request, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'成功': True, '要求': reference(out)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
