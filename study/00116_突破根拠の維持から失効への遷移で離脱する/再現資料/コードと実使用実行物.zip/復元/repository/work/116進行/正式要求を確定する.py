"""全70場の成功資料とRootレビュー後の保存器を結ぶ。"""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PREP = ROOT / 'work/116正式保存への接続'


def reference(path: Path, expected: str | None = None) -> dict:
    """機能: 指定metadata/後段コードの全bytesを認証する。

    引数: path(Path)は明示入力、expected(str|None)は既知SHA。
    返り値: dictは絶対pathとSHA256。
    """
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if expected is not None and expected != digest:
        raise ValueError('SHA不一致: ' + str(path))
    return {'path': str(path), 'sha256': digest}


def main() -> None:
    """機能: 未許可素材を変更せず、新しい正式保存要求だけを確定する。

    引数: なし。
    返り値: None。正式保存・市場再生・11月09の読取は行わない。
    """
    source = PREP / '正式要求の最終素材.json'
    request = json.loads(source.read_text(encoding='utf-8-sig'))
    flags = ('fixed', 'formal_write_authorized', 'market_native_read_authorized', 'raw_audit_read_authorized')
    if not all(request[k] is False for k in flags):
        raise ValueError('未許可素材のみ受理')
    stop_ref = reference(PREP / 'Root承認後の停止/停止.json', '4ec0e55f59aded77672f57d637b2846e0091436cfa942f8e9df685afc69e3395')
    stop = json.loads(Path(stop_ref['path']).read_text(encoding='utf-8-sig'))
    if not (stop['成功'] and stop['停止'] and stop['Rootレビュー後'] and stop['前後不変']):
        raise ValueError('Rootレビュー後の保存器停止')
    material = stop['コード分類素材']
    reference(Path(material['path']), material['sha256'])
    request['refs']['formal_stop'] = stop_ref
    request['refs']['code_material'] = material
    if request['refs']['raw_request']['sha256'] != '72bfae81931c6d931f7f43edf1dad9503936eb9046a7b270e27344e259f6e6bd':
        raise ValueError('全70原行監査Root要求')
    if request['refs']['raw_check']['sha256'] != '841ad3512f5589b94ab58c4930df642aa2e454fe14892c627796c35456d57276':
        raise ValueError('全70原行監査成功')
    for name in flags:
        request[name] = True
    request['Rootレビュー'] = '保存器12主人工・旧依存/所有前後同体と別担当レビューを確認。全70金融/独立/Raw/CSV再読/可逆保管成功後の正式保存を許可。11月09の読取、新金融実行、CSV再生成は許可しない。'
    request['未許可素材のRef'] = reference(source)
    request['Rootが全成功後に置換するもの'] = []
    for path in (Path(__file__).resolve(), ROOT / 'work/116進行/文書をまとめる.py', ROOT / 'work/116進行/結果文書を更新する.py'):
        if not any(Path(row['ref']['path']) == path for row in request['code_refs']):
            request['code_refs'].append({'ref': reference(path), 'role': 'Rootの後段要求/文書整理。金融条件・市場計算は変更しない'})
    for path, target in ((source, '再現資料/正式要求の未許可最終素材.json'),
                         (PREP / '最終素材と再現依存の確認.json', '検査/正式要求素材の確認.json')):
        if any(Path(row['ref']['path']) == path for row in request['extra_refs']):
            raise ValueError('追加資料の重複')
        request['extra_refs'].append({'ref': reference(path), 'target': target, 'role': 'Root許可前の素材と純bytes復元依存の確認'})
    out = ROOT / 'work/116進行/全70正式保存のRoot要求.json'
    with out.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(request, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'成功': True, '要求': reference(out)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
