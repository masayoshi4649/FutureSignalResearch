"""同F1元54の独立成功を認証再用し、追加16だけ同じ停止保存器で検算する。"""
from collections import Counter
from copy import deepcopy
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PRIOR = ROOT / 'work/116保有根拠の独立会計と保存_未読件数の型'
PRIOR_STOP = PRIOR / '会計停止.json'
PRIOR_SHA = '397ee90a93f491f5cf1842f70b4a974a0435fdb84eae8987416881e40af5a12d'


def load_stopped() -> tuple:
    """機能: 固定397保存器の所有を先に認証し、無変更importする。

    引数: なし。
    返り値: tupleは停止済みS/G/P/E/L各moduleと停止内容。Nativeは読まない。
    """
    if hashlib.sha256(PRIOR_STOP.read_bytes()).hexdigest() != PRIOR_SHA:
        raise ValueError('演算元397停止SHA差')
    stop = json.loads(PRIOR_STOP.read_bytes())
    if not (stop['成功'] and stop['停止'] and stop['市場前'] and stop['試行'] == 116):
        raise ValueError('演算元保存器の成功停止が必要')
    for path, expected in stop['所有ファイルSHA256'].items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected:
            raise ValueError('演算元所有SHA差:' + path)
    names = ['保存集計の共通部', '保存の入力ゲート', '新保護の独立監査', '入口の独立検算', '保有根拠の独立監査']
    for name in names:
        if name in sys.modules and Path(sys.modules[name].__file__).resolve().parent != PRIOR:
            raise ValueError('別保存器moduleが先に存在:' + name)
    sys.path.insert(0, str(PRIOR))
    try:
        modules = tuple(importlib.import_module(name) for name in names)
    finally:
        sys.path.pop(0)
    return (*modules, stop)


S, G, P, E, L, PRIOR_RECORD = load_stopped()


# ----------------------------------------
def merge_fingerprints(target: dict, source: dict) -> None:
    """機能: 認証した指紋を衝突なく同じ台帳へ結ぶ。

    引数: target/source(dict[str,str])は結合先と入力。
    返り値: None。同位置の異なるSHAは拒否する。
    """
    for path, digest in source.items():
        resolved = str(Path(path).resolve())
        S.need(resolved not in target or target[resolved] == digest, '同path指紋衝突')
        target[resolved] = digest


# ----------------------------------------
def prepare(fixed_path: Path, fixed_sha: str, output: Path) -> dict:
    """機能: 外側Root要求と通常full70/base54要求を既G.prepareで認証する。

    引数: fixed_path/output(Path)、fixed_sha(str)は外側要求・新規先・SHA。
    返り値: dictはNative/保存結果本文未読の再用計画。
    """
    S.need(output.is_absolute() and not output.exists(), '外側保存は新規絶対出力')
    before = {}
    root_ref = {'path': str(fixed_path.resolve()), 'sha256': fixed_sha}
    request = S.load(G.reference(root_ref, before))
    S.need(request['version'] == 1 and request['trial'] == 116 and request['fixed'] is True
           and request['saved54_reuse_authorized'] is True
           and request['market_native_read_authorized'] is True
           and request['legacy115_read_authorized'] is True, 'Rootの元54再用/追加16明示許可')
    S.need(request.get('raw_read_authorized', False) is False
           and request.get('holdout_read_authorized', False) is False, 'Raw/holdout許可を付けない')
    stop = G.check_stop(request['runner_stop'], before)
    S.equal(stop['所有ファイルSHA256'].get(str(Path(__file__).resolve())), S.digest(Path(__file__)), '外側runner自体の停止同体')
    full_ref, base_refs = request['full_request'], request['base54']
    S.equal(set(base_refs), {'request', 'result', 'check'}, '元54の要求/結果/確認を明示')
    for ref in [full_ref, *base_refs.values()]:
        S.need(isinstance(ref, dict) and Path(ref.get('path', '')).is_absolute()
               and re.fullmatch('[a-f0-9]{64}', ref.get('sha256', '')) is not None, '外側要求の絶対FileRef形式')
    full = G.prepare(G.reference(full_ref, before), full_ref['sha256'], output)
    base_ref = base_refs['request']
    base = G.prepare(G.reference(base_ref, before), base_ref['sha256'], output / '_未作成の元54計画')
    S.equal(full['request']['stage'], 'full70', '通常full70要求')
    S.equal(base['request']['stage'], 'base54', '成功元54要求')
    for field in ('condition', 'code_stop', 'P_stop', 'life_stop', 'actor_stop', 'lifecycle_go_stop', 'entry115_stop', 'protection_code', 'lifecycle_code', 'entry_code'):
        S.need(G.same_ref(full['request'][field], base['request'][field]), '元54と追加16の同条件/同停止/' + field)
    S.equal(full['request']['code_stop']['sha256'], PRIOR_SHA, '同397保存器だけを再用')
    S.equal(full['condition']['actual_configurations'], base['condition']['actual_configurations'], '同36宣言')
    S.equal(full['definition'], base['definition'], '同life定義')
    S.equal(len(base['tasks']), 54, '元54数')
    S.equal(len(full['tasks']), 70, '全70数')
    for previous, current in zip(base['tasks'], full['tasks'][:54]):
        S.equal(previous['session'], current['session'], '元54場順同体')
        for field in ('native', 'reference115'):
            S.need(G.same_ref(previous[field], current[field]), '元54の同path同SHA/' + field)
    merge_fingerprints(before, full['before'])
    merge_fingerprints(before, base['before'])
    return {'request': request, 'root_ref': root_ref, 'full': full, 'base': base,
            'before': before, 'base_refs': base_refs, 'output': output}


# ----------------------------------------
def aggregate(rows: list) -> tuple:
    """機能: 全場別行を既S.combine/既Counter式だけで集計する。

    引数: rows(list[dict])は同じ列を持つ元54+新16の実統計。
    返り値: tuple[dict,dict,dict]は金融/DD、入口件数、life件数。
    """
    summary = {key: S.combine([row for row in rows if row['key'] == key]) for key in S.KEYS}
    entry = {key: dict(sum((Counter(row['入口票検査']['counts']) for row in rows if row['key'] == key), Counter())) for key in S.KEYS}
    life = {key: dict(sum((Counter(row['保有根拠の独立検査']['counts']) for row in rows if row['key'] == key), Counter())) for key in S.KEYS}
    return summary, entry, life


# ----------------------------------------
def saved_form(value: dict) -> dict:
    """機能: 再計算した値を既存BASE.serialと同じ保存JSON数値へ写す。

    引数: value(dict)はDecimal比率を含む集計です。
    返り値: dictは保存物と同じ十進字句。許容誤差や金銭補正は加えない。
    """
    return json.loads(json.dumps(value, default=S.BASE.serial, allow_nan=False), parse_float=S.BASE.Decimal)


# ----------------------------------------
def lexical_reference(path: Path) -> Path:
    """機能: 価格参照を文字列操作だけで絶対位置へ正規化する。

    引数: path(Path)はcatalog基準へ結んだ参照文字列。
    返り値: Pathはabspath/normpath結果。属性照会やsymlink解決を行わない。
    """
    return Path(os.path.abspath(os.path.normpath(os.fspath(path))))


# ----------------------------------------
def authenticate_base(plan: dict) -> dict:
    """機能: 元54独立成功の全指紋/場別/集計/Source/flatとNative同bytesを認証する。

    引数: plan(dict)はRoot認証済み外側計画。
    返り値: dictは再用する成功結果と検算。旧Nativeはgzip展開/JSON解釈しない。
    """
    before, refs, base = plan['before'], plan['base_refs'], plan['base']
    result = S.load(G.reference(refs['result'], before))
    check = S.load(G.reference(refs['check'], before))
    q = base['request']
    fields = {'金融条件SHA256': q['condition']['sha256'], '金融完了SHA256': q['completion']['sha256'],
              'Root保存要求SHA256': refs['request']['sha256'], '保存器停止SHA256': PRIOR_SHA,
              '独立P停止SHA256': q['P_stop']['sha256'], '独立ライフ停止SHA256': q['life_stop']['sha256'],
              'Actor停止SHA256': q['actor_stop']['sha256'], '純ライフ停止SHA256': q['lifecycle_go_stop']['sha256'],
              '入口115独立停止SHA256': q['entry115_stop']['sha256']}
    for value in (result, check):
        S.need(value['試行'] == 116 and value['成功'] is True and value['stage'] == 'base54'
               and value['場数'] == 54 and value['会計数'] == 1944 and value['前後不変'] is True, '元54独立全成功')
        for key, expected in fields.items():
            S.equal(value[key], expected, '元54同条件成功/' + key)
        S.equal(value['入力codeSHA256前'], value['入力codeSHA256後'], '元54保存時の前後同体')
    S.equal(result['入力codeSHA256前'], check['入力codeSHA256前'], '元54結果と保存確認の入力全体同体')
    S.need(check['全Source111同体'] is True and check['全残玉予約0'] is True and check['不一致数'] == 0
           and check['X0全金融比較'] == 648 and check['旧115全金融比較'] == 648 and check['資源'] == 1944, '元54Source/旧12/残玉予約0')
    S.equal(result['主key'], list(S.KEYS), '元54全36順序')
    S.equal(result['Actor設定'], {key: {'candidate': key, 'entry_timing': '元Source連続時計', **cfg} for key, cfg in S.BY_KEY.items()}, '元54本名36設定')
    S.equal(result['保有根拠定義'], base['definition'], '元54純定義')
    expected_rows = [(task['session'], key) for task in base['tasks'] for key in S.KEYS]
    S.equal([(row['session'], row['key']) for row in result['場別']], expected_rows, '元54全0群を残す1944場別')
    S.need(all(row['history_class'] == 'original54' for row in result['場別']), '元54区分')
    S.need(all(all(row[field] == 0 for field in ('open_buy', 'open_sell', 'pending_buy', 'pending_sell')) for row in result['場別']), '元54全場別の実残/予約0')
    summary, entry, life = aggregate(result['場別'])
    for name, actual in [('集計', summary), ('入口票集計', entry), ('保有根拠検査集計', life)]:
        S.equal(result[name], saved_form(actual), '元54保存行から同保存形式で集計再計算/' + name)
    for name in ('元Source対照', '旧115対照', 'Native参照', 'Viewer保存再読'):
        S.equal([row['session'] for row in result[name]], [task['session'] for task in base['tasks']], '元54全場証拠/' + name)
    S.need(all(row['全36の元通知同体'] is True for row in result['元Source対照']), '元54Source通知同体')
    S.need(all(row['comparisons'] == 12 and row['all_financial_equal'] is True and row['source_equal'] is True for row in result['旧115対照']), '元54旧115全12/Source全文同体')
    S.need(all(row['資源'] == 36 and row['全残0'] is True for row in result['Viewer保存再読']), '元54Viewer保存成功')
    for task, ref in zip(base['tasks'], result['Native参照']):
        S.need(G.same_ref(task['native'], ref) and G.same_ref(task['reference115'], ref['reference115']), '元54保存Native参照の同体')
        for field in ('native', 'reference115'):
            path = str(Path(task[field]['path']).resolve())
            S.equal(result['入力codeSHA256前'].get(path), task[field]['sha256'], '元54Nativeは保存時入力へ結合済み')
    # ----------------------------------------
    # 圧縮NativeはSHA認証だけ。保存された全code/参照の現物不変も認証する。
    for path, digest in result['入力codeSHA256前'].items():
        S.need(Path(path).suffix.lower() != '.csv' and not path.endswith('.jsonl'), '元54入力へRaw/価格/Viewer全件が混入しない')
        if path.endswith('.gz'):
            S.need(path.endswith('.Native.json.gz'), '元54入力のgzipは新旧金融Nativeだけ')
        G.reference({'path': path, 'sha256': digest}, before)
    S.equal(check['出力SHA256'].get(Path(refs['result']['path']).name), refs['result']['sha256'], '元54検算から結果SHAへ結合')
    return {'result': result, 'check': check}


# ----------------------------------------
def relink_viewer(plan: dict, saved: dict) -> tuple:
    """機能: 元1944資源を認証し同じ実ファイルへ相対参照して複写を避ける。

    引数: plan/saved(dict)はRoot計画と認証済み元54結果。
    返り値: tuple[list,dict]は新catalog向け資源と参照再用ファイルSHA。
    """
    base_dir = Path(plan['base_refs']['result']['path']).resolve().parent
    catalog_path = base_dir / '一覧.resources.json'
    check = saved['check']
    catalog = S.load(G.reference({'path': str(catalog_path), 'sha256': check['出力SHA256']['一覧.resources.json']}, plan['before']))
    S.need(catalog['schema_version'] == 1 and catalog['path_base'] == 'catalog', '元Viewer catalog相対基準')
    expected = [(task['session'], key) for task in plan['base']['tasks'] for key in S.KEYS]
    resources = catalog['resources']
    S.equal([(r['session'], r['method_id']) for r in resources], expected, '元1944資源全0群/順序')
    full_tasks = {task['session']: task for task in plan['full']['tasks']}
    result, reused = [], {}
    for resource in resources:
        row = deepcopy(resource)
        name = f"116_{row['method_id']}_{row['session']}.trades.jsonl"
        S.need(row['id'] == name.removesuffix('.trades.jsonl') and row['pnl_path'] == name
               and row['symbol'] == 'NK225' and row['product'] == 'NK225mini' and row['point_value'] == 100
               and row['pnl_format'] == 'trades' and row['pnl_basis'] == 'net', '元Viewer意味/本名')
        trade = (base_dir / name).resolve()
        G.reference({'path': str(trade), 'sha256': check['出力SHA256'][name]}, plan['before'])
        reused[str(trade)] = check['出力SHA256'][name]
        market = Path(row['market_path'])
        market = lexical_reference(market if market.is_absolute() else base_dir / market)
        expected_market = Path(full_tasks[row['session']]['market_path'])
        expected_market = lexical_reference(expected_market if expected_market.is_absolute() else plan['output'] / expected_market)
        S.equal(market, expected_market, '元Viewerと新Root要求の同じ価格参照。本文未読')
        row['pnl_path'] = os.path.relpath(trade, plan['output']).replace('\\', '/')
        row['market_path'] = os.path.relpath(market, plan['output']).replace('\\', '/')
        S.equal((plan['output'] / row['pnl_path']).resolve(), trade, '再用約定の相対参照復元')
        S.equal(lexical_reference(plan['output'] / row['market_path']), market, '価格相対参照の文字列だけの復元')
        result.append(row)
    return result, reused


# ----------------------------------------
def inspect_additions(plan: dict) -> tuple:
    """機能: 追加16だけを停止済みinspect/P/E/L/Viewerで新たに独立検算する。

    引数: plan(dict)はRoot同F1計画と新規出力。
    返り値: tupleは場別・Source・旧115比較・Native参照・Viewer資源・保存確認。
    """
    rows, sources, references, native_refs, resources, viewer = [], [], [], [], [], []
    for task in plan['full']['tasks'][54:]:
        native = S.load(G.reference(task['native'], plan['before']))
        prior = S.load(G.reference(task['reference115'], plan['before']))
        trace = native['reference115']
        S.need(G.same_ref(trace['reference'], task['reference115']), '新16の旧115当場Ref')
        S.equal(trace['before_sha256'], task['reference115']['sha256'], '新16旧115前SHA')
        S.equal(trace['after_sha256'], task['reference115']['sha256'], '新16旧115後SHA')
        S.equal(native['actual']['lifecycle_definition'], plan['full']['definition'], '新16同F1 life')
        inspected = S.inspect_scene(native, prior, P, E, L)
        sid = task['session']
        S.equal(native['actual']['scope']['session']['id'], sid, '新16場')
        S.equal(task['history_class'], 'additional16', '新16区分')
        for key in S.KEYS:
            stat = S.summarize_book(native['actual']['books'][key], inspected['checked'][key])
            stat['入口票検査'] = inspected['entry'][key]
            rows.append({'session': sid, 'key': key, 'history_class': 'additional16', **stat})
        sources.append({'session': sid, **inspected['source']})
        references.append({'session': sid, 'reference': task['reference115'], **inspected['reference115']})
        native_refs.append({'session': sid, **task['native'], 'reference115': task['reference115']})
        added = S.save_viewer(native, plan['output'], task['market_path'])
        viewer.append({'session': sid, **S.verify_viewer(native, plan['output'], added)})
        resources.extend(added)
    return rows, sources, references, native_refs, resources, viewer


# ----------------------------------------
def run(plan: dict) -> dict:
    """機能: 元54認証再用と新16独立検算を全70の同形結果へ統合する。

    引数: plan(dict)は外側Root認証済み計画。
    返り値: dictは結果Ref/件数。全70新規Native再計算とは記さない。
    """
    saved = authenticate_base(plan)
    resources, reused_viewer = relink_viewer(plan, saved)
    out = plan['output']
    out.mkdir(parents=True, exist_ok=False)
    additions = inspect_additions(plan)
    result = deepcopy(saved['result'])
    for field, added in zip(('場別', '元Source対照', '旧115対照', 'Native参照', 'Viewer保存再読'), additions[:4] + (additions[5],)):
        result[field].extend(added)
    resources.extend(additions[4])
    S.equal([(row['session'], row['key']) for row in result['場別']], [(task['session'], key) for task in plan['full']['tasks'] for key in S.KEYS], '全2520行と0取引の保持')
    S.equal(len(resources), 2520, '全2520Viewer資源')
    summary, entry, life = aggregate(result['場別'])
    after = {path: S.digest(Path(path)) for path in plan['before']}
    S.equal(after, plan['before'], '全再用/追加入力・停止codeの前後不変')
    q = plan['full']['request']
    result.update(stage='full70', 場数=70, 会計数=2520)
    result.update({'Root保存要求SHA256': plan['request']['full_request']['sha256'],
        '金融完了SHA256': q['completion']['sha256'], '集計': summary, '入口票集計': entry, '保有根拠検査集計': life,
        'Viewer形式資源': 2520, '入力codeSHA256前': plan['before'], '入力codeSHA256後': after,
        '独立再用場数': 54, '独立新規検算場数': 16, '全70の金融Native再検算': False,
        '再検算方式': '認証済み元54場を再用し追加16場だけ独立検算',
        '元54再用runner停止SHA256': plan['request']['runner_stop']['sha256'],
        '元54再用Root要求SHA256': plan['root_ref']['sha256'], '元54再用': deepcopy(plan['base_refs']),
        'Viewer参照再用場数': 54, 'Viewer新規保存再読場数': 16, 'Viewer参照再用SHA256': reused_viewer})
    result['限界'].append('元54金融NativeのSHAと独立成功証拠を再認証して再用。元54の金融Native展開/意味再検算0。Viewer元1944もSHAと保存成功を再用し約定意味再読0。新16だけ同停止演算で検算。全70の場別集計/DDは同S.combineで再結合。')
    S.BASE.write_json(out / '結果.json', result)
    S.BASE.write_json(out / '一覧.resources.json', {'schema_version': 1, 'path_base': 'catalog', 'resources': resources})
    files = {path.name: S.digest(path) for path in sorted(out.iterdir()) if path.is_file()}
    check = {key: result[key] for key in ('試行', '成功', 'stage', 'Root保存要求SHA256', '金融条件SHA256', '金融完了SHA256',
        '保存器停止SHA256', '独立P停止SHA256', '独立ライフ停止SHA256', 'Actor停止SHA256', '純ライフ停止SHA256', '入口115独立停止SHA256',
        '場数', '会計数', '独立再用場数', '独立新規検算場数', '全70の金融Native再検算', '再検算方式',
        '元54再用runner停止SHA256', '元54再用Root要求SHA256', '元54再用', 'Viewer参照再用場数', 'Viewer新規保存再読場数')}
    check.update({'資源': 2520, 'X0全金融比較': 840, '旧115全金融比較': 840, '全Source111同体': True,
        '全残玉予約0': True, '不一致数': 0, '全Rawライフ発生漏れ/初回性監査': False,
        '入力codeSHA256前': plan['before'], '入力codeSHA256後': after, '前後不変': True,
        '出力SHA256': files, 'Viewer参照再用SHA256': reused_viewer, '研究目標達成': False, '採用': False})
    S.BASE.write_json(out / '保存会計の確認.json', check)
    return {'成功': True, 'stage': 'full70', '独立再用場数': 54, '独立新規検算場数': 16, '会計数': 2520,
            '結果': {'path': str(out / '結果.json'), 'sha256': files['結果.json']}}


# ----------------------------------------
def main() -> None:
    """機能: 新Root外側要求からのみ認証再用・追加16独立保存を起動する。

    引数: CLI fixed/sha256/output(Path/str)、metadata-only(bool)は要求と新規先。
    返り値: None。metadata-onlyはNative/既保存結果/Viewer本文を読まない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--fixed', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--metadata-only', action='store_true')
    args = parser.parse_args()
    plan = prepare(args.fixed, args.sha256, args.output)
    value = {'成功': True, 'metadata_only': True, 'Native本文読取': False, '既保存結果/Viewer本文読取': False,
             '独立再用予定': 54, '独立新規検算予定': 16} if args.metadata_only else run(plan)
    print(json.dumps(value, ensure_ascii=False))


if __name__ == '__main__':
    main()
