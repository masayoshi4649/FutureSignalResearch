"""旧20人工のmetadata器具だけを実Coreの整数件数型へ合わせ、金融式を変更せず検査する。"""
from pathlib import Path
import unittest

import 入力ゲートの人工検査 as M

ORIGINAL_FIXTURE=M.fixture
COUNT_KEY='Raw/市場Native/実価格CSV/11月09本文読取'
CORE=M.G.S.ROOT/'work/116保有根拠の連続比較/停止.json'
CORE_SHA='c080ce6fb520385acdb88c8b0efe65690c8cd0a17593859ac9b9f9691c713cbe'


def adapted_fixture(folder: Path) -> dict:
    """
    機能: 旧テスト原文を変えず、そのCore未読件数metadataだけを整数0へ合わせる。
    引数: folder(Path)。返り値: dictは人工metadata。新旧Nativeは作らない。
    """
    data=ORIGINAL_FIXTURE(folder);runtime=M.G.S.load(Path(data['condition']['runtime_stop']['path']));runtime[COUNT_KEY]=0
    data['condition']['runtime_stop']=M.write(folder/'runtime.json',runtime);condition=M.write(folder/'condition.json',data['condition']);data['completion']['condition_sha256']=condition['sha256']
    return data


M.fixture=adapted_fixture


class Tests(unittest.TestCase):
    """実停止の型と境界のmetadata人工。"""

    def test_real_core_metadata_integer_zero(self):
        """
        機能: 実Core小停止metadataの整数0を認証し、Native不在でも計画が成功する。
        引数: self(Tests)。返り値: None。
        """
        import tempfile
        M.G.S.equal(M.G.S.digest(CORE),CORE_SHA,'実Core停止SHA')
        with tempfile.TemporaryDirectory(dir=M.HERE) as tmp:
            data=adapted_fixture(Path(tmp));data['condition']['runtime_stop']={'path':str(CORE),'sha256':CORE_SHA}
            data['completion']['condition_sha256']=M.write(Path(tmp)/'condition.json',data['condition'])['sha256']
            plan=M.prepare(data);self.assertEqual(len(plan['tasks']),2);self.assertFalse(plan['output'].exists())

    def test_count_type_and_nonzero_rejected(self):
        """
        機能: 非0整数・bool・文字列0・小数0・nullを件数型として認めない。
        引数: self(Tests)。返り値: None。
        """
        import tempfile
        for value in (1,-1,True,False,'0',0.0,None):
            with tempfile.TemporaryDirectory(dir=M.HERE) as tmp:
                data=adapted_fixture(Path(tmp));path=Path(data['condition']['runtime_stop']['path']);runtime=M.G.S.load(path);runtime[COUNT_KEY]=value;data['condition']['runtime_stop']=M.write(path,runtime)
                data['completion']['condition_sha256']=M.write(Path(tmp)/'condition.json',data['condition'])['sha256']
                with self.subTest(value=repr(value)),self.assertRaises(ValueError):M.prepare(data)


if __name__=='__main__':unittest.main(verbosity=2)
