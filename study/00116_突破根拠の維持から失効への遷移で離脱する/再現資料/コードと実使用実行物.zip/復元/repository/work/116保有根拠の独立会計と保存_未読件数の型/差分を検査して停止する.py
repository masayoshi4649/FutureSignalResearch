"""旧22所有を保ち、Gateの未読件数型1式だけを別停止へ派生する。"""
from pathlib import Path
import argparse
import json
from datetime import datetime,timezone

import 検査して停止する as B

HERE=Path(__file__).resolve().parent
OLD=B.S.ROOT/'work/116保有根拠の独立会計と保存'
OLD_STOP=OLD/'会計停止.json'
OLD_STOP_SHA='0262abed7e7d62f78998f792c8ff3fc1184f53e9153765a5f55b12817bd7cc74'
OLD_PROOF=OLD/'停止前検査_全人工/停止前の確認.json'
OLD_PROOF_SHA='90767aced6d62a44eacc31eef958149b869777bec200fcadd00e397effaaaa6b'


def old_evidence() -> tuple[dict,dict]:
    """
    機能: 旧正式停止/22所有/全人工証拠を不変参照し、1式以外は同bytesと確認する。
    引数: なし。返り値: tuple[dict,dict]は旧停止と既成功proof。Core人工本文は再読しない。
    """
    B.S.equal(B.S.digest(OLD_STOP),OLD_STOP_SHA,'旧会計停止は不変');B.S.equal(B.S.digest(OLD_PROOF),OLD_PROOF_SHA,'旧全人工証拠は不変')
    stop=B.S.load(OLD_STOP);proof=B.S.load(OLD_PROOF);B.S.need(stop['成功'] and stop['停止'] and proof['成功'] and proof['前後不変'],'旧正式/人工全成功')
    B.S.equal(len(stop['所有ファイルSHA256']),22,'旧22所有')
    old=b"runtime['Raw/"+'市場Native/実価格CSV/11月09本文読取'.encode()+b"'] is False"
    new=b"type(runtime['Raw/"+'市場Native/実価格CSV/11月09本文読取'.encode()+b"']) is int and runtime['Raw/"+'市場Native/実価格CSV/11月09本文読取'.encode()+b"']==0"
    for filename,sha in stop['所有ファイルSHA256'].items():
        original=Path(filename);B.S.equal(B.S.digest(original),sha,'旧22所有原文不変');copy=HERE/original.name
        if original.name=='保存の入力ゲート.py':
            source=original.read_bytes();B.S.equal(source.count(old),1,'旧Gateの型述語は一式だけ');B.S.equal(copy.read_bytes(),source.replace(old,new),'金融ゲートの未読件数型だけを派生')
        else:B.S.equal(copy.read_bytes(),original.read_bytes(),'Gate以外の21原文は同bytes')
    for ref in proof['人工結果'].values():B.S.equal(B.S.digest(Path(ref['path'])),ref['sha256'],'旧Core216/72等の小成功証拠を参照認証')
    return stop,proof


def maps() -> tuple[dict,dict]:
    """
    機能: 新所有/旧固定閉包へ旧22原文・正式停止・全人工の小証拠を加える。
    引数: なし。返り値: tuple[dict,dict]は所有と依存。Core人工Nativeを再生しない。
    """
    stop,proof=old_evidence();owned,reused=B.codes();reused.update(stop['所有ファイルSHA256']);reused[str(OLD_STOP)]=OLD_STOP_SHA;reused[str(OLD_PROOF)]=OLD_PROOF_SHA
    for ref in proof['人工結果'].values():reused[ref['path']]=ref['sha256']
    return owned,dict(sorted(reused.items()))


def check(output: Path) -> dict:
    """
    機能: 20既存主人工と実Core型2主を再実行し、旧Core216/72証拠は参照再用する。
    引数: output(Path)は新規絶対位置。返り値: dictは停止前確認Ref。
    """
    B.S.need(output.is_absolute() and not output.exists(),'新しい型確認先');owned,reused=maps();output.mkdir(parents=True)
    log=B.command(['-m','unittest','-v','ライフの人工検査','会計の人工検査','入力ゲートの人工検査','保存点を破壊する人工検査','型と既存人工を検査する'])
    after_owned,after_reused=maps();B.S.equal(after_owned,owned,'新所有前後同体');B.S.equal(after_reused,reused,'旧22/全固定依存/既証拠前後同体');_,oldproof=old_evidence()
    proof={'試行':116,'成功':True,'停止':False,'市場前':True,'Rootレビュー前':True,'UTC':datetime.now(timezone.utc).isoformat(),'主人工':22,'旧20主人工':20,'実Core未読件数型の追加主人工':2,'Gate以外の21原文同bytes':True,'Gate差分':'未読件数はtype(value) is int and value==0。bool False/True・文字列0・float0・null・非0整数は拒否。','所有ファイルSHA256':owned,'依存コードSHA256':reused,'所有コードSHA256前':owned,'所有コードSHA256後':after_owned,'依存コードSHA256前':reused,'依存コードSHA256後':after_reused,'前後不変':True,'旧会計停止':{'path':str(OLD_STOP),'sha256':OLD_STOP_SHA},'旧全人工証拠':{'path':str(OLD_PROOF),'sha256':OLD_PROOF_SHA},'人工結果':oldproof['人工結果'],'Core216/72の再読再生':False,'追加Raw/自然Native/価格CSV/11月09本文':False,'実行ログ':[log],'全Raw初回性':False}
    return B.write(output/'停止前の確認.json',proof)


def stop(review: Path,sha: str) -> dict:
    """
    機能: Rootレビュー後、旧停止を改変せず新folderのP/life/会計停止だけを作る。
    引数: review(Path)、sha(str)。返り値: dictは新停止3参照。
    """
    B.S.equal(B.S.digest(review),sha,'Rootレビュー対象SHA');proof=B.S.load(review);B.S.need(proof['成功'] and proof['停止'] is False and proof['市場前'] and proof['前後不変'],'新型確認の全成功')
    owned,reused=maps();B.S.equal(owned,proof['所有ファイルSHA256'],'レビュー後新所有同体');B.S.equal(reused,proof['依存コードSHA256'],'レビュー後旧固定/既証拠同体')
    paths=[HERE/'P停止.json',HERE/'ライフ停止.json',HERE/'会計停止.json'];B.S.need(not any(p.exists() for p in paths),'新停止は初回だけ')
    base={'試行':116,'成功':True,'停止':True,'市場前':True,'停止UTC':datetime.now(timezone.utc).isoformat(),'前後不変':True,'停止前確認':{'path':str(review.resolve()),'sha256':sha},'依存コードSHA256':reused,'人工結果':proof['人工結果'],'旧会計停止':{'path':str(OLD_STOP),'sha256':OLD_STOP_SHA},'金融/P/life演算変更':False,'全Rawライフ発生漏れ/初回性監査':False,'市場/Raw/新自然Native/価格CSV/11月09本文':False,'採用':False,'研究目標達成':False}
    p=B.write(paths[0],{**base,'所有ファイルSHA256':{str(HERE/'新保護の独立監査.py'):owned[str(HERE/'新保護の独立監査.py')]},'実API':'verify_protection(book,config,finance,context)->dict'})
    life=B.write(paths[1],{**base,'所有ファイルSHA256':{str(HERE/n):owned[str(HERE/n)] for n in ('ライフ状態の独立式.py','保有根拠の独立監査.py')},'実API':'verify_lifecycle(book,config,finance,context)->dict'})
    account=B.write(paths[2],{**base,'所有ファイルSHA256':owned,'P停止':p,'ライフ停止':life,'Actor停止':{'path':str(B.STOPS['Actor'][0]),'sha256':B.STOPS['Actor'][1]},'入口115停止':{'path':str(B.STOPS['入口115'][0]),'sha256':B.STOPS['入口115'][1]},'実API':'保存する.py --fixed ABS --sha256 SHA --output NEWABS [--metadata-only]','会計数':'36×N','旧115対照':'12×N','Raw権限':False})
    return {'成功':True,'P停止':p,'ライフ停止':life,'会計停止':account}


def main() -> None:
    """
    機能: 派生型の確認とRootレビュー後停止を別々に実行する。
    引数: CLI check-output(Path)又はstop(bool)/review(Path)/review-sha(str)。返り値: None。
    """
    p=argparse.ArgumentParser();p.add_argument('--check-output',type=Path);p.add_argument('--stop',action='store_true');p.add_argument('--review',type=Path);p.add_argument('--review-sha');a=p.parse_args()
    if a.stop:B.S.need(a.check_output is None and a.review is not None and a.review_sha,'Rootレビュー指定が必要');value=stop(a.review,a.review_sha)
    else:B.S.need(a.check_output is not None and a.review is None and a.review_sha is None,'新停止前確認先だけ指定');value=check(a.check_output)
    print(json.dumps(value,ensure_ascii=False))


if __name__=='__main__':main()
