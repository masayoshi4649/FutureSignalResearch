package miniprotect

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"testing"

	legacy "github.com/masayoshi4649/SessionTradeExecuter/continuousactor115"
	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate115"
	life "github.com/masayoshi4649/SessionTradeExecuter/entrylife116"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	old "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	bank "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

// lifecycleBank116 は順側の入口から取得後の逆行を持つ手製公表器を作ります。
//
// 引数: t(*testing.T)、side(int)、missing(bool)は試験器、鏡像、取得後欠足です。
// 返り値: *bank.Bankは市場由来でない5/15/30分の当時公表器です。
func lifecycleBank116(t *testing.T, side int, missing bool) *bank.Bank {
	t.Helper()
	session := session94()
	prior := old.Session{ID: "人工前史116", Contract: contract115, Start: session.Start - 50400, End: session.Start - 3600, EOF: session.Start - 3600}
	warm, err := bank.BeginSession(prior, children115(prior, side, true, false), nil)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = warm.AdvanceObserved(prior.EOF, 1); err != nil {
		t.Fatal(err)
	}
	seed, _, err := warm.Seal()
	if err != nil {
		t.Fatal(err)
	}
	scene := old.Session{ID: session.ID, Contract: contract115, Start: session.Start, End: session.End, EOF: session.End}
	children := children115(scene, side, false, false)
	// ----------------------------------------
	// 旧人工の12本目欠足を埋め、13本目以後だけ既知の下落又は明示欠足へします。
	for i := 0; i < int((scene.End-scene.Start)/300); i++ {
		if i != 11 {
			continue
		}
		close := 1110.0
		open, high, low := close-4, close+1, close-5
		if side < 0 {
			open, high, low, close = 3000-open, 3000-low, 3000-high, 3000-close
		}
		start := scene.Start + 300*float64(i)
		children = append(children, old.ChildBar{Start: start, End: start + 300, OHLC: old.OHLC{Open: open, High: high, Low: low, Close: close}, Volume: 10, Closed: true, VolumeKnown: true, Input: old.FileRef{Path: "人工/116足.csv", SHA256: "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa", Bytes: 1}, Row: uint64(i + 1)})
	}
	filtered := []old.ChildBar{}
	for _, child := range children {
		index := int((child.Start - scene.Start) / 300)
		if missing && index == 12 {
			continue
		}
		if index >= 12 {
			close := 950.0
			open, high, low := close+4, close+5, close-1
			if side < 0 {
				open, high, low, close = 3000-open, 3000-low, 3000-high, 3000-close
			}
			child.OHLC = old.OHLC{Open: open, High: high, Low: low, Close: close}
		}
		filtered = append(filtered, child)
	}
	sort.Slice(filtered, func(i, j int) bool { return filtered[i].Start < filtered[j].Start })
	out, err := bank.BeginSession(scene, filtered, &seed)
	if err != nil {
		t.Fatal(err)
	}
	return out
}

// lifecycleObservation116 は手製Rawを実5分足と同じ買売鏡像へ合わせます。
//
// 引数: side(int)、index(int64)、offset/bid(float64)、normal(bool)は方向・原行・時計・生気配です。
// 返り値: ObservationはQuoteOK偽でも生Bid/Askを消さない人工原行です。
func lifecycleObservation116(side int, index int64, offset, bid float64, normal bool) Observation {
	o := observation94(session94(), 1, index, offset-1800, bid-1000, 20)
	o.QuoteOK = normal
	if side < 0 {
		o.Last, o.Bid, o.Ask = 3000-o.Last, 3000-o.Ask, 3000-o.Bid
	}
	return o
}

// lifecycleFixture116 は手製Sourceを全36口座と旧115全12へ一方向に配送します。
//
// 引数: t(*testing.T)、side(int)、kind(string)は試験器・鏡像・部分/全予約/異常/優先等の場面です。
// 返り値: 二つのmapは完結116全36と旧115全12です。自然FARや市場取引ではありません。
func lifecycleFixture116(t *testing.T, side int, kind string) (map[string]ActualResult, map[string]legacy.ActualResult) {
	t.Helper()
	session, source := session94(), newFixtureSource94()
	publisher := lifecycleBank116(t, side, kind == "missing")
	books, oldBooks := map[string]*ActualBook{}, map[string]*legacy.ActualBook{}
	for _, cfg := range DeclaredContinuousConfigurations() {
		book, err := NewContinuousBook(session, contract115, cfg)
		if err != nil {
			t.Fatal(err)
		}
		books[book.result.Key] = book
		if cfg.LifeMode == "X0" {
			oldBook, err := legacy.NewContinuousBook(session, contract115, legacy.ActorConfig{Policy: cfg.Policy, EntryMode: cfg.EntryMode, SlipPts: cfg.SlipPts, DelaySeconds: cfg.DelaySeconds})
			if err != nil {
				t.Fatal(err)
			}
			oldBooks[book.result.Key] = oldBook
		}
	}
	times := []float64{3660, 3661, 3662, 3960, 3960, 3961, 4260, 4261}
	if kind == "latefill" {
		times = []float64{3660, 3960, 3961, 4260, 4260, 4261, 4560, 4561}
	}
	for i, offset := range times {
		bid := 1110.0
		if i >= 3 {
			bid = 1070
		}
		if kind == "priority" && i == 3 || kind == "lateactive" && i >= 4 {
			bid = 1250
		}
		if kind == "bad" && i >= 4 {
			bid = 1110
		}
		normal := !((kind == "bad" || kind == "lateactive") && i == 3)
		o := lifecycleObservation116(side, int64(i+2), offset, bid, normal)
		line := int64(i + 102)
		signals := []native.Signal{}
		if i == 0 {
			signals = append(signals, birth94("入口116", side, 3))
		}
		if kind == "flat" && i == 2 {
			signals = append(signals, close94("早Source116", "入口116", side, 3))
		}
		if kind != "flat" && i == 3 {
			quantity := 1
			if kind == "reserved" {
				quantity = 3
			}
			signals = append(signals, close94("部分Source116", "入口116", side, quantity))
		}
		if kind != "flat" && kind != "reserved" && i == 6 {
			signals = append(signals, close94("残Source116", "入口116", side, 2))
		}
		batch := source.step(t, o, line, signals, nil)
		before, err := json.Marshal(batch)
		if err != nil {
			t.Fatal(err)
		}
		if _, err := publisher.AdvanceObserved(o.Time, uint64(o.Index)+1); err != nil {
			t.Fatal(err)
		}
		snapshot, err := publisher.SnapshotAt(o.Time)
		if err != nil {
			t.Fatal(err)
		}
		stamp := gate.Stamp{Time: o.Time, Index: int(o.Index), Line: line}
		for key, book := range books {
			if err = book.SetLifecycleSnapshot(snapshot, stamp); err != nil {
				t.Fatal(kind, key, err)
			}
			if len(signals) > 0 {
				if err = book.SetEntrySnapshot(snapshot, stamp); err != nil {
					t.Fatal(err)
				}
			}
			if err = book.OnNativeStep(o, line, []NativeBatch{batch}); err != nil {
				t.Fatal(kind, key, i, err)
			}
		}
		for key, book := range oldBooks {
			if len(signals) > 0 {
				if err = book.SetEntrySnapshot(snapshot, stamp); err != nil {
					t.Fatal(err)
				}
			}
			if err = book.OnNativeStep(o, line, []legacy.NativeBatch{{Method: batch.Method, Delta: batch.Delta}}); err != nil {
				t.Fatal(err)
			}
			proof, err := CompareLegacy115(books[key].Snapshot(), book.Snapshot())
			if err != nil || !proof.AllFinancialEqual {
				t.Fatal(kind, key, i, err, proof)
			}
		}
		after, err := json.Marshal(batch)
		if err != nil || string(after) != string(before) {
			t.Fatal("116口座がSource通知を書き換えた")
		}
	}
	results, prior := map[string]ActualResult{}, map[string]legacy.ActualResult{}
	for key, book := range books {
		r, err := book.Finish()
		if err != nil {
			t.Fatal(kind, key, err)
		}
		results[key] = r
	}
	for key, book := range oldBooks {
		r, err := book.Finish()
		if err != nil {
			t.Fatal(err)
		}
		prior[key] = r
		if _, err = CompareLegacy115(results[key], r); err != nil {
			t.Fatal(err)
		}
	}
	return results, prior
}

// TestLifecycleFlowMirror116 は部分Source優先・実life返済・買売対称を全36条件で検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。P100式を変えず、life要求/実fill/最終所有を別に確認します。
func TestLifecycleFlowMirror116(t *testing.T) {
	buy, _ := lifecycleFixture116(t, 1, "partial")
	sell, _ := lifecycleFixture116(t, -1, "partial")
	if len(buy) != 36 || len(sell) != 36 {
		t.Fatal("36実名宣言の欠落")
	}
	for key, r := range buy {
		if r.Totals != sell[key].Totals {
			t.Fatal("116買売費用後鏡像差", key)
		}
		if r.Config.LifeMode == "X0" {
			if r.Positions[0].Lifecycle116 != nil || r.Metrics.LifecycleExitRequests != 0 {
				t.Fatal("X0に監視")
			}
			continue
		}
		p := r.Positions[0]
		a := p.Lifecycle116
		if !a.FinalState.Latched || a.FirstInvalidation == nil || len(a.Requests) != 1 || len(a.ExitFillIDs) != 1 || r.Metrics.LifecycleExitRequests != 1 || r.Metrics.LifecycleExitFills != 1 {
			t.Fatalf("%s lifeラッチ=%t 初失効=%t 要求=%d fill=%d metric=%d/%d armed=%d", key, a.FinalState.Latched, a.FirstInvalidation != nil, len(a.Requests), len(a.ExitFillIDs), r.Metrics.LifecycleExitRequests, r.Metrics.LifecycleExitFills, a.FinalState.ArmingCount)
		}
		if a.Requests[0].Input.Reserved != 1 || a.Requests[0].Decision.ExitEligibleQuantity != 2 || a.Requests[0].AfterReserved == nil || *a.Requests[0].AfterReserved != 3 {
			t.Fatal("Source予約を二重取得", key)
		}
		if len(p.Protection113.LifecycleReservations) != 1 || p.Protection113.LifecycleReservations[0].BeforeSnapshot == nil || a.FinalOwnership == nil || a.FinalOwnership.Remaining != 0 {
			t.Fatal("P100再同期/最終所有なし", key)
		}
		for _, fill := range r.Fills {
			if !fill.LifecycleExit {
				continue
			}
			request := a.Requests[0].Quote
			if fill.Quantity != 2 || fill.Quote.Index <= request.Index || fill.Quote.SourceLine <= request.SourceLine || fill.Quote.Time < request.Time+float64(r.Config.DelaySeconds) || (r.Config.DelaySeconds == 0 && fill.Quote.Time != request.Time) {
				t.Fatal("後原行/同秒D0/遅延D1の実fill差", key)
			}
		}
	}
}

// lifecycleHolding116 は実取得後で未退出の一口座を手製配送だけから作ります。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: *ActualBookは初回armed済みのA0/XQ、Snapshot/Stampは最後の当時値です。
func lifecycleHolding116(t *testing.T) (*ActualBook, bank.Snapshot, gate.Stamp) {
	t.Helper()
	book, err := NewContinuousBook(session94(), contract115, ActorConfig{Policy: "P100", LifeMode: "XQ", EntryMode: "A0"})
	if err != nil {
		t.Fatal(err)
	}
	publisher, source := lifecycleBank116(t, 1, false), newFixtureSource94()
	var snapshot bank.Snapshot
	var stamp gate.Stamp
	for i, offset := range []float64{3660, 3661} {
		o := lifecycleObservation116(1, int64(i+2), offset, 1110, true)
		stamp = gate.Stamp{Time: o.Time, Index: int(o.Index), Line: int64(i + 102)}
		if _, err = publisher.AdvanceObserved(o.Time, uint64(o.Index)+1); err != nil {
			t.Fatal(err)
		}
		if snapshot, err = publisher.SnapshotAt(o.Time); err != nil {
			t.Fatal(err)
		}
		if err = book.SetLifecycleSnapshot(snapshot, stamp); err != nil {
			t.Fatal(err)
		}
		signals := []native.Signal{}
		if i == 0 {
			signals = append(signals, birth94("参照分離116", 1, 3))
			if err = book.SetEntrySnapshot(snapshot, stamp); err != nil {
				t.Fatal(err)
			}
		}
		batch := source.step(t, o, stamp.Line, signals, nil)
		if err = book.OnNativeStep(o, stamp.Line, []NativeBatch{batch}); err != nil {
			t.Fatal(err)
		}
	}
	return book, snapshot, stamp
}

// TestLifecycleDeliveryAndCopy116 は未来・scope・重複・公表改変を拒否し独立複写を検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。監視snapshotは入口Historyを進めず、生値を参照共有しません。
func TestLifecycleDeliveryAndCopy116(t *testing.T) {
	for _, kind := range []string{"asof", "scope", "future", "duplicate", "mutated"} {
		book, snapshot, stamp := lifecycleHolding116(t)
		if kind != "duplicate" {
			stamp.Time++
			stamp.Index++
			stamp.Line++
			snapshot.AsOf, snapshot.ReplayObservedAt, snapshot.RecordOrdinal = stamp.Time, stamp.Time, uint64(stamp.Index)+1
		}
		switch kind {
		case "asof":
			snapshot.AsOf++
		case "scope":
			snapshot.Session.Contract = "別限月"
		case "future":
			snapshot.Scales[0].Current.Frame.AvailableAt = stamp.Time + 1
		case "mutated":
			snapshot.Scales[0].Current.Frame.Technical.Histogram.Value++
		}
		if err := book.SetLifecycleSnapshot(snapshot, stamp); err == nil {
			t.Fatal("監視配送の不正を受理", kind)
		}
	}
	book, snapshot, stamp := lifecycleHolding116(t)
	original := book.Snapshot()
	copy := book.Snapshot()
	a := copy.Positions[0].Lifecycle116
	*a.First.Snapshot.Entry.Birth.Values.Boundary += 99
	*a.Last.BeforeSnapshot.Entry.Birth.Values.G30 += 100
	*a.FinalState.Entry.Birth.Values.D15 += 100
	a.First.Input.Latest.Scales[0].Current.Frame.Technical.Histogram.Value++
	if !reflect.DeepEqual(original, book.Snapshot()) {
		t.Fatal("公開監視snapshotが内部又は別出力と参照共有")
	}
	gateBefore := valueCopy(original.EntryGate)
	stamp.Time++
	stamp.Index++
	stamp.Line++
	snapshot.AsOf, snapshot.ReplayObservedAt, snapshot.RecordOrdinal = stamp.Time, stamp.Time, uint64(stamp.Index)+1
	if err := book.SetLifecycleSnapshot(snapshot, stamp); err != nil {
		t.Fatal(err)
	}
	snapshot.Scales[0].Current.Frame.Technical.Histogram.Value++
	if snapshot == book.lifecycle.latest || !reflect.DeepEqual(gateBefore, book.Snapshot().EntryGate) {
		t.Fatal("配送値の参照共有又は入口Historyへの干渉")
	}
}

// TestLifecycleDeclarationAndControl116 は36本名とX0監視無効の厳格対照を検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。追加監視値・非零集計を説明差として削除しません。
func TestLifecycleDeclarationAndControl116(t *testing.T) {
	declared := DeclaredContinuousConfigurations()
	i := 0
	for _, mode := range []string{"X0", "XC", "XQ"} {
		for _, entry := range []string{"A0", "T", "TR"} {
			for _, cost := range []float64{0, 5} {
				for _, delay := range []int{0, 1} {
					if declared[i] != (ActorConfig{Policy: "P100", LifeMode: mode, EntryMode: entry, SlipPts: cost, DelaySeconds: delay}) {
						t.Fatal("36本名の宣言順差", i)
					}
					i++
				}
			}
		}
	}
	for _, mode := range []string{"", "P100", "X"} {
		if _, err := NewContinuousBook(session94(), contract115, ActorConfig{Policy: "P100", LifeMode: mode, EntryMode: "A0"}); err == nil {
			t.Fatal("未宣言監視を受付", mode)
		}
	}
	values, priors := lifecycleFixture116(t, 1, "partial")
	for _, kind := range []string{"audit", "metric", "fill", "order", "gate", "P100"} {
		bad := valueCopy(values["A0_C0_D0"])
		switch kind {
		case "audit":
			bad.Positions[0].Lifecycle116 = &LifecycleAudit116{}
		case "metric":
			bad.Metrics.LifecycleExitRequests = 1
		case "fill":
			bad.Fills[0].LifecycleExit = true
		case "order":
			bad.Orders[0].LifecyclePoint = &LifecyclePoint116{}
		case "gate":
			bad.EntryGate.Records[0].Decision.Trend = gate.False
		case "P100":
			bad.Positions[0].Protection113.FinalState.ClosedNetYen++
		}
		if _, err := CompareLegacy115(bad, priors["A0_C0_D0"]); err == nil {
			t.Fatal("X0の差を隠した", kind)
		}
	}
}

// TestLifecycleQuoteAndPriority116 は異常BBOのXCラッチとXQ待ち・P100先起動を区別します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。QuoteOK偽を生価格0へ置き換えず、完成ラッチを後から取り消しません。
func TestLifecycleQuoteAndPriority116(t *testing.T) {
	for _, kind := range []string{"bad", "priority", "lateactive"} {
		rows, _ := lifecycleFixture116(t, 1, kind)
		for key, r := range rows {
			if r.Config.LifeMode == "X0" {
				continue
			}
			a := r.Positions[0].Lifecycle116
			want := kind != "priority" && r.Config.LifeMode == "XC"
			if a.FinalState.Latched != want || (r.Metrics.LifecycleExitRequests > 0) != want {
				t.Fatalf("%s %s ラッチ=%t 要求=%d 期待=%t armed=%d 委譲=%t", kind, key, a.FinalState.Latched, r.Metrics.LifecycleExitRequests, want, a.FinalState.ArmingCount, a.FinalState.DisabledByP100)
			}
			if want && (a.FirstInvalidation.Input.QuoteOK || a.FirstInvalidation.Decision.QuoteOK || a.FirstInvalidation.Quote.Bid <= 0 || a.FirstInvalidation.Quote.Ask <= a.FirstInvalidation.Quote.Bid) {
				t.Fatal("異常flagと生BBOの区別差", key)
			}
			if kind == "priority" && (!a.FinalState.DisabledByP100 || a.FirstDisabledByP100 == nil) {
				t.Fatal("P100優先の証拠なし", key)
			}
			if kind == "lateactive" && r.Config.LifeMode == "XC" && !r.Positions[0].ProtectionActive {
				t.Fatal("既ラッチ後のP100起動がない")
			}
		}
	}
}

// TestLifecycleMissingFlatAndReserved116 は欠測鎖切り・既flat・全予約の別結果を確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。退出済みの仮想失効と、全予約の実失効を混同しません。
func TestLifecycleMissingFlatAndReserved116(t *testing.T) {
	for _, kind := range []string{"missing", "flat", "reserved", "latefill"} {
		rows, _ := lifecycleFixture116(t, 1, kind)
		for key, r := range rows {
			if r.Config.LifeMode == "X0" {
				continue
			}
			a := r.Positions[0].Lifecycle116
			if r.Metrics.LifecycleExitRequests != 0 {
				t.Fatal(kind, key, "不要な追加注文")
			}
			if kind == "reserved" {
				if !a.FinalState.Latched || a.FirstAllReserved == nil {
					t.Fatal(key, "全予約のラッチなし")
				}
			} else if a.FinalState.Latched {
				t.Fatal(kind, key, "不明又は退出後の仮想失効")
			}
			if kind == "missing" && len(a.ChainBreakPoints) == 0 {
				t.Fatal("欠足鎖切りなし", key)
			}
			if kind == "flat" && (a.FinalOwnership == nil || a.Last.Input.Stamp.Time >= a.FinalOwnership.Quote.Time) {
				t.Fatal("実終了後も純評価", key)
			}
			if kind == "latefill" && a.FinalState.ArmingCount != 0 {
				t.Fatal("実fill時の逆Histを初期armedへ誤認", key)
			}
		}
	}
}

// TestExportLifecycle116 はRoot指定の新規先だけへ買売36冊と旧各12冊を保存します。
//
// 引数: t(*testing.T)、環境CONTINUOUS116_LIFE_EXPORT_DIR(string)は試験器と未作成先です。
// 返り値: なし。手製API人工だけで、自然FAR/市場Nativeではありません。
func TestExportLifecycle116(t *testing.T) {
	dir := os.Getenv("CONTINUOUS116_LIFE_EXPORT_DIR")
	if dir == "" {
		t.Skip("Root指定の人工exportだけ")
	}
	if _, err := os.Stat(dir); !os.IsNotExist(err) {
		t.Fatal("新規人工先のみ")
	}
	if err := os.MkdirAll(dir, 0755); err != nil {
		t.Fatal(err)
	}
	buy, oldBuy := lifecycleFixture116(t, 1, "partial")
	sell, oldSell := lifecycleFixture116(t, -1, "partial")
	values := map[string]any{"買い": buy, "売り": sell, "買い_115": oldBuy, "売り_115": oldSell, "市場": false, "FAR自然生成": false, "scope": "手製Source通知と115実公表器。全36×買売、旧115各12。全Raw保存や自然Source生成ではない"}
	for name, value := range map[string]any{"買売人工.json": values, "宣言設定.json": DeclaredContinuousConfigurations(), "監視定義.json": life.DeclaredDefinition(), "入口定義.json": gate.DeclaredDefinition()} {
		body, err := json.MarshalIndent(value, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(filepath.Join(dir, name), append(body, '\n'), 0600); err != nil {
			t.Fatal(err)
		}
	}
	t.Log(fmt.Sprintf("人工72冊、旧115対照24冊を%sへ保存", dir))
}

// TestLifecyclePublisher116 は人工が実115公表式で順側Histから逆側へ遷移することを確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。既知性やHistをActor内で差し替えません。
func TestLifecyclePublisher116(t *testing.T) {
	for _, side := range []int{1, -1} {
		publisher := lifecycleBank116(t, side, false)
		for i, offset := range []float64{3660, 3960} {
			at := session94().Start + offset
			if _, err := publisher.AdvanceObserved(at, uint64(i+1)); err != nil {
				t.Fatal(err)
			}
			snap, err := publisher.SnapshotAt(at)
			if err != nil {
				t.Fatal(err)
			}
			five, _ := snap.Scale(300)
			f := five.Current.Frame
			h := float64(side) * f.Technical.Histogram.Value
			if !five.Fresh || !f.PriceKnown || !f.Technical.Histogram.Known || (i == 0 && h <= 0) || (i == 1 && h > 0) {
				t.Fatalf("人工Histの遷移差 side=%d i=%d H=%g fresh=%t known=%t", side, i, h, five.Fresh, f.Technical.Histogram.Known)
			}
		}
	}
}
