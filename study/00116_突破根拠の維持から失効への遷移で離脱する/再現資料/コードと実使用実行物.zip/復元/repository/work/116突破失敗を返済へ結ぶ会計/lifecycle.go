package miniprotect

import (
	"fmt"

	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate115"
	life "github.com/masayoshi4649/SessionTradeExecuter/entrylife116"
	bank "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

// LifecyclePoint116 は純判定の前後と、その時点の実R/n/予約を分けて保存します。
type LifecyclePoint116 struct {
	Quote                QuoteStamp          `json:"quote"`
	Input                life.Input          `json:"input"`
	BeforeSnapshot       *life.Snapshot      `json:"before_snapshot,omitempty"`
	Snapshot             *life.Snapshot      `json:"snapshot,omitempty"`
	Decision             life.Decision       `json:"decision"`
	Remaining            int                 `json:"remaining"`
	Reserved             int                 `json:"reserved"`
	RealizedNet          float64             `json:"realized_net"`
	ExitOrderID          string              `json:"exit_order_id,omitempty"`
	AfterRemaining       *int                `json:"after_remaining,omitempty"`
	AfterReserved        *int                `json:"after_reserved,omitempty"`
	AfterP100Reservation *ProtectionPoint113 `json:"after_P100_reservation,omitempty"`
}

// LifecycleOwnership116 は純監視の終了と、実返済による所有完結を分けます。
type LifecycleOwnership116 struct {
	Quote       QuoteStamp `json:"quote"`
	Remaining   int        `json:"remaining"`
	Reserved    int        `json:"reserved"`
	RealizedNet float64    `json:"realized_net"`
	P100Active  bool       `json:"P100_active"`
}

// LifecycleAudit116 は全Rawを複写せず状態変化・要求・最後を保存します。
type LifecycleAudit116 struct {
	Initial                     life.Snapshot          `json:"initial"`
	First                       *LifecyclePoint116     `json:"first"`
	ArmingPoints                []*LifecyclePoint116   `json:"arming_points,omitempty"`
	ChainBreakPoints            []*LifecyclePoint116   `json:"chain_break_points,omitempty"`
	FirstWarning                *LifecyclePoint116     `json:"first_warning"`
	LastWarning                 *LifecyclePoint116     `json:"last_warning"`
	FirstRecovery               *LifecyclePoint116     `json:"first_recovery"`
	LastRecovery                *LifecyclePoint116     `json:"last_recovery"`
	FirstWarningCleared         *LifecyclePoint116     `json:"first_warning_cleared"`
	LastWarningCleared          *LifecyclePoint116     `json:"last_warning_cleared"`
	FirstInvalidation           *LifecyclePoint116     `json:"first_invalidation"`
	FirstDisabledByP100         *LifecyclePoint116     `json:"first_disabled_by_P100"`
	FirstAllReserved            *LifecyclePoint116     `json:"first_all_reserved"`
	Requests                    []*LifecyclePoint116   `json:"requests,omitempty"`
	ExitFillIDs                 []string               `json:"exit_fill_ids,omitempty"`
	Last                        *LifecyclePoint116     `json:"last"`
	FinalState                  life.Snapshot          `json:"final_state"`
	FinalOwnership              *LifecycleOwnership116 `json:"final_ownership"`
	Evaluations                 uint64                 `json:"evaluations"`
	BadQuoteEvaluations         uint64                 `json:"bad_quote_evaluations"`
	MissingIndicatorEvaluations uint64                 `json:"missing_indicator_evaluations"`
	StaleIndicatorEvaluations   uint64                 `json:"stale_indicator_evaluations"`
	WarningCount                uint64                 `json:"warning_count"`
	RecoveryCount               uint64                 `json:"recovery_count"`
	WarningClearedCount         uint64                 `json:"warning_cleared_count"`
	AllReservedCount            uint64                 `json:"all_reserved_count"`
}

type lifecyclePosition116 struct {
	state    life.State
	before   life.State
	last     LifecyclePoint116
	finished bool
	warning  bool
	disabled bool
}

type lifecycleRuntime116 struct {
	latest       bank.Snapshot
	stamp        gate.Stamp
	haveSnapshot bool
	seen         map[string]bank.Frame
	positions    map[string]*lifecyclePosition116
}

// SetLifecycleSnapshot は入口freezeと独立して全受理原行の最新公表を値保存します。
//
// 引数: snapshot(bank.Snapshot)、stamp(gate.Stamp)は同じ現在原行の入口bank出力です。
// 返り値: errorはscope・未来・原行順・同ID改変です。Snapshotは参照を含まない値型です。
func (b *ActualBook) SetLifecycleSnapshot(snapshot bank.Snapshot, stamp gate.Stamp) error {
	if err := b.ready(); err != nil {
		return err
	}
	if b.lifecycle == nil || b.continuous == nil || !finiteActual(stamp.Time) || stamp.Time < b.lastEventAt || stamp.Index < 0 || stamp.Line <= 0 || !snapshot.HasObserved || snapshot.Sealed || snapshot.AsOf != stamp.Time || snapshot.ReplayObservedAt != stamp.Time || snapshot.RecordOrdinal != uint64(stamp.Index)+1 || snapshot.Session.ID != b.result.Session.ID || snapshot.Session.Contract != b.continuous.contract || snapshot.Session.Start != b.result.Session.Start || snapshot.Session.End != b.result.Session.End {
		return b.stop(fmt.Errorf("116監視snapshotのscope/asof/原行不正"))
	}
	runtime := b.lifecycle
	if runtime.haveSnapshot && (stamp.Time < runtime.stamp.Time || stamp.Index <= runtime.stamp.Index || stamp.Line <= runtime.stamp.Line) {
		return b.stop(fmt.Errorf("116監視配送の原行後退/重複"))
	}
	if runtime.seen == nil {
		runtime.seen = map[string]bank.Frame{}
	}
	for i, scale := range snapshot.Scales {
		if scale.WidthSeconds != []int{300, 900, 1800}[i] {
			return b.stop(fmt.Errorf("116監視尺度順の不正"))
		}
		if !scale.HasCurrent {
			continue
		}
		frame := scale.Current.Frame
		if frame.ID == "" || frame.SessionID != snapshot.Session.ID || frame.Contract != snapshot.Session.Contract || frame.WidthSeconds != scale.WidthSeconds || !finiteActual(frame.Start, frame.End, frame.NominalAvailable, frame.AvailableAt, frame.ObservedAt, frame.DeliveryAt) || frame.End <= frame.Start || frame.End > stamp.Time || frame.NominalAvailable > stamp.Time || frame.AvailableAt > stamp.Time || frame.ObservedAt > stamp.Time || frame.DeliveryAt > stamp.Time || frame.RecordOrdinal > snapshot.RecordOrdinal {
			return b.stop(fmt.Errorf("116監視公表のscope/未来不正"))
		}
		if prior, exists := runtime.seen[frame.ID]; exists && prior != scale.Current {
			return b.stop(fmt.Errorf("116監視同IDの改変"))
		}
		runtime.seen[frame.ID] = scale.Current
	}
	runtime.latest, runtime.stamp, runtime.haveSnapshot = snapshot, stamp, true
	return nil
}

// initLifecyclePosition は実fillで凍結出生票と取得原行を純状態へ結びます。
//
// 引数: p(*ActualPosition)は正常後原行で実取得した新玉です。
// 返り値: errorは出生票/状態初期化の不整合です。初回評価は同原行after_sourceです。
func (b *ActualBook) initLifecyclePosition(p *ActualPosition) error {
	if b.lifecycle == nil || b.result.Config.LifeMode == "X0" {
		return nil
	}
	index, exists := b.entryGate.bySource[sourceKey(p.Source.Method, p.Source.SignalID)]
	if !exists {
		return fmt.Errorf("116実取得の出生票なし")
	}
	row := b.result.EntryGate.Records[index]
	if !row.Allowed || row.OrderID != p.EntryOrderID {
		return fmt.Errorf("116実取得の許可票/注文所有差")
	}
	entry := life.Entry{Scope: gate.Scope{Session: b.result.Session.ID, Contract: b.continuous.contract, Start: b.result.Session.Start, End: b.result.Session.End}, ID: p.ID, Policy: life.Policy(b.result.Config.LifeMode), Side: p.Side, Birth: row.Decision, FillStamp: gate.Stamp{Time: p.EntryQuote.Time, Index: int(p.EntryQuote.Index), Line: p.EntryQuote.SourceLine}}
	state, err := life.NewState(entry)
	if err != nil {
		return err
	}
	initial := state.Snapshot()
	p.Lifecycle116 = &LifecycleAudit116{Initial: initial, FinalState: initial}
	b.lifecycle.positions[p.ID] = &lifecyclePosition116{state: state}
	return nil
}

// savedLifecyclePoint116 は実際に保存する点だけ純状態の前後を独立複写します。
//
// 引数: runtime(*lifecyclePosition116)は現在純状態・直前純状態・当原行の実値です。
// 返り値: *LifecyclePoint116は後続原行の上書きと共有しない保存点です。
func savedLifecyclePoint116(runtime *lifecyclePosition116) *LifecyclePoint116 {
	point := runtime.last
	before, after := runtime.before.Snapshot(), runtime.state.Snapshot()
	point.BeforeSnapshot, point.Snapshot = &before, &after
	return &point
}

// reserveLifecycleExit はlife要求をP100自身の返済群へ混ぜず実所有へ予約します。
//
// 引数: p(*ActualPosition)、point(*LifecyclePoint116)、quantity(int)は実玉・条件完成点・未予約量です。
// 返り値: errorは予約/純P100再同期の不整合です。架空の床価格約定は作りません。
func (b *ActualBook) reserveLifecycleExit(p *ActualPosition, point *LifecyclePoint116, quantity int) error {
	q := point.Quote
	if !normalActual(q) || quantity <= 0 || quantity != p.Quantity-p.Reserved {
		return fmt.Errorf("116正常気配又はlife未予約量の差")
	}
	id, err := b.requestExit(p, quantity, q.Time, q, "116突破根拠と順側Histの失効/"+b.result.Config.LifeMode, "", "", nil)
	if err != nil {
		return err
	}
	b.result.Metrics.SourceExitRequests--
	b.result.Metrics.LifecycleExitRequests++
	point.ExitOrderID = id
	n, r := p.Quantity, p.Reserved
	point.AfterRemaining, point.AfterReserved = &n, &r
	b.result.Orders[b.orders[id]].LifecyclePoint = point
	// ----------------------------------------
	// 外部life予約だけの純P100再同期を、P100自身の要求と別の配列へ残します。
	before := b.continuous.positions[p.ID].state.Snapshot()
	after, decision, err := b.continuousAdvance(p, q.Time, PhaseAfterSource, nil, false)
	if err != nil {
		return err
	}
	resync := &ProtectionPoint113{At: q.Time, Phase: PhaseAfterSource, BeforeSnapshot: &before, Snapshot: after, Decision: decision, ExitOrderID: id}
	point.AfterP100Reservation = resync
	p.Protection113.LifecycleReservations = append(p.Protection113.LifecycleReservations, resync)
	p.Protection113.FinalState = after
	p.Lifecycle116.Requests = append(p.Lifecycle116.Requests, point)
	return nil
}

// markLifecycle はSource予約とP100評価の後、未起動根拠失効だけを毎受理原行で評価します。
//
// 引数: q(QuoteStamp)は当原行の生価格・正常フラグです。
// 返り値: errorは純入力・所有・要求の不整合です。X0と退出後は仮想評価しません。
func (b *ActualBook) markLifecycle(q QuoteStamp) error {
	if b.lifecycle == nil || b.result.Config.LifeMode == "X0" {
		return nil
	}
	runtime := b.lifecycle
	stamp := gate.Stamp{Time: q.Time, Index: int(q.Index), Line: q.SourceLine}
	if !runtime.haveSnapshot || runtime.stamp != stamp {
		return fmt.Errorf("116当原行の監視snapshot配送なし")
	}
	for i := range b.result.Positions {
		p := &b.result.Positions[i]
		rt := runtime.positions[p.ID]
		if rt == nil || p.Lifecycle116 == nil {
			return fmt.Errorf("116実玉の監視初期化なし")
		}
		if rt.finished {
			continue
		}
		if p.Quantity == 0 {
			if p.Reserved != 0 || p.ClosedQuote == nil || *p.ClosedQuote != q {
				return fmt.Errorf("116所有完結の原行/予約差")
			}
			p.Lifecycle116.FinalOwnership = &LifecycleOwnership116{Quote: q, Remaining: 0, Reserved: 0, RealizedNet: p.RealizedNet, P100Active: p.ProtectionActive}
			rt.finished = true
			continue
		}
		input := life.Input{Stamp: stamp, Phase: life.AfterSource, Latest: runtime.latest, Bid: q.Bid, Ask: q.Ask, QuoteOK: q.QuoteOK, Remaining: p.Quantity, Reserved: p.Reserved, P100Active: p.ProtectionActive}
		previous := rt.state
		next, decision, err := life.Advance(previous, input)
		if err != nil {
			return err
		}
		rt.before, rt.state = previous, next
		rt.last = LifecyclePoint116{Quote: q, Input: input, Decision: decision, Remaining: p.Quantity, Reserved: p.Reserved, RealizedNet: p.RealizedNet}
		audit := p.Lifecycle116
		audit.Evaluations++
		if !decision.QuoteOK {
			audit.BadQuoteEvaluations++
		}
		if len(decision.Missing) > 0 {
			audit.MissingIndicatorEvaluations++
		}
		if len(decision.Stale) > 0 {
			audit.StaleIndicatorEvaluations++
		}
		var saved *LifecyclePoint116
		if decision.InitialEvaluation || decision.ArmedNow || decision.ChainBrokenNow || decision.InvalidatedNow || decision.Warning != rt.warning || decision.DisabledByP100 && !rt.disabled || decision.Latched && p.Quantity > 0 && p.Reserved == p.Quantity && audit.FirstAllReserved == nil || decision.ExitEligibleQuantity > 0 {
			saved = savedLifecyclePoint116(rt)
		}
		if decision.InitialEvaluation {
			audit.First = saved
		}
		if decision.ArmedNow {
			audit.ArmingPoints = append(audit.ArmingPoints, saved)
		}
		if decision.ChainBrokenNow {
			audit.ChainBreakPoints = append(audit.ChainBreakPoints, saved)
		}
		if decision.Warning && !rt.warning {
			audit.WarningCount++
			if audit.FirstWarning == nil {
				audit.FirstWarning = saved
			}
			audit.LastWarning = saved
		}
		if !decision.Warning && rt.warning {
			audit.WarningClearedCount++
			if audit.FirstWarningCleared == nil {
				audit.FirstWarningCleared = saved
			}
			audit.LastWarningCleared = saved
			// Hist順側回復と、Unknown鎖切り/P100委譲による警戒解除を分けます。
			if decision.NewFivePublication && decision.RequiredKnown && decision.RequiredFresh && decision.Values.SignedHistogram != nil && *decision.Values.SignedHistogram > 0 {
				audit.RecoveryCount++
				if audit.FirstRecovery == nil {
					audit.FirstRecovery = saved
				}
				audit.LastRecovery = saved
			}
		}
		if decision.InvalidatedNow {
			audit.FirstInvalidation = saved
		}
		if decision.DisabledByP100 && !rt.disabled {
			audit.FirstDisabledByP100 = saved
		}
		if decision.Latched && p.Quantity > 0 && p.Reserved == p.Quantity {
			audit.AllReservedCount++
			if audit.FirstAllReserved == nil {
				audit.FirstAllReserved = saved
			}
		}
		if decision.ExitEligibleQuantity > 0 {
			if err = b.reserveLifecycleExit(p, saved, decision.ExitEligibleQuantity); err != nil {
				return err
			}
		}
		rt.warning, rt.disabled, rt.finished = decision.Warning, decision.DisabledByP100, p.Quantity == 0
		audit.Last = &rt.last
	}
	return nil
}
