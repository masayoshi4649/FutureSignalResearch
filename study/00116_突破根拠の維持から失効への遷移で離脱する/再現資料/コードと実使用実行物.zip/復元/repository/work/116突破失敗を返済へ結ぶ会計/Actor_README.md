# 116の突破失効と共通P100会計

115 Actorの必要な所有12ファイルを最初に同bytesでコピーし、新しいmodule `github.com/masayoshi4649/SessionTradeExecuter/continuousactor116` へ派生した。コピー時の指紋は `同bytesコピーの記録.json`、変更範囲は `Actorの派生元.json` に残す。旧115停止物は変更しない。

Source111、入口gate115・bank115、純P113のP100、連続時計、買売各上限mini10枚、片道税込38.5円、滑り0/5pt・遅延0/1秒、Source予約優先、部分返済と配賦、厳密な後原行の正常BBO約定、場内完結を維持する。出生と実fillの間で入口を再判定しない。保有監視のためにSource内部へ実約定を戻す変更はない。

## 宣言とAPI

`LifeMode=X0/XC/XQ` × `EntryMode=A0/T/TR` × C0/C5 × D0/D1の36条件。`Policy=P100` は全て同じ保護であり、入口や保有監視の名前へ偽装しない。宣言順は保有監視、入口、滑り、遅延の順。X0は旧115の同名key（例 `T_C5_D1`）、追加監視は `T_XC_C5_D1` とする。

- `DeclaredContinuousConfigurations()`：36本名のConfig。
- `NewContinuousBook(session,contract,cfg)`：36宣言だけの実口座。旧人工用 `NewActualBook` は追加モードを受け付けない。
- `SetEntrySnapshot(snapshot,stamp)`：旧115と同じ出生原行の入口History配送。
- `SetLifecycleSnapshot(snapshot,stamp)`：全受理原行の最新bank115公表を入口Historyと独立して保存する。時刻・Index・物理行・scope・同IDの全値を検査する。Snapshotは参照のない値型としてコピーし、毎原行のJSON複写はしない。
- `SetPublication/ResetPublication`：旧cold保護bankからP100だけへ配送。入口bankのATR/DMIを保護へ流用しない。
- `OnNativeStep`：P100 pre_fill → 既予約fill → Source返済予約・出生受付 → P100 after_source → 保有監視after_source。P100先起動なら新しい保有根拠失効を作らない。
- `CompareLegacy115(current,prior)`：X0全12冊と旧115同名12冊の、各原行又は終端の全金融・入口Decision・受付/実取得・P100全Stateを照合する。

Coreは全受理原行でbank115を進め、その原行のSnapshotを全36へ `SetLifecycleSnapshot` で配送する。出生通知がある行だけ入口Snapshotも配送してから `OnNativeStep` を呼ぶ。旧3分保護bankのreset/frameは保有監視へ渡さない。`Snapshot.AsOf=ReplayObservedAt=Stamp.Time`、`RecordOrdinal=Index+1` とする。

## 実取得と保有根拠監視

XC/XQの実新規fillで凍結出生Decisionと取得原行を純entrylife116へ渡す。初回評価はその実fill原行のafter_sourceで、取得要求時ではなく実fill時latestによって初期armedを決める。出生Common真、15分DI差順側、30分EMA差既知非零、固定突破境界既知という監視適格性は追加の入口拒否ではない。

純監視は当時freshな5分Close/Hist、15分DI、30分背景と実返済BBOを受ける。初回又は取得後の順側確認からarmedとなり、順側Histを失ったことと固定境界の内戻りを組み合わせる。XCは新しい取得後確定5分Close、XQは各正常原行の返済BBOを使う。XCは異常BBOでも確定公表の完成をラッチでき、正常気配になるまで実要求を待つ。両者は単なる時計差だけでなく参照価格も異なる。

`Warning` は **Hist警戒** だけを表す。価格の順側回復だけでは解除せず、freshな新5分公表でHistが順側へ戻った場合を回復と数える。未知/鎖切り・P100委譲による警戒解除は `warning_cleared_count` として別計数する。完成ラッチは価格・Hist回復や後のP100起動で解除しない。

使用指標の未知・staleと、QuoteOK偽又は異常BBOを分ける。生Bid/Askをゼロへマスクしない。複数公表を一原行へ配送した場合はlatestのみを評価し、途中公表を順に再生したとは主張しない。

## 予約・所有と保存

保有根拠失効の要求量は `実残量−既予約量` だけ。Source又はP100の既予約を取り消さず、全予約なら失効保存と要求0を分ける。要求後は同原行で約定させず、遅延条件を満たす次の正常後原行で返済する。実fill・配賦・費用は既存会計式のまま。

- `positions.lifecycle116`：初期、初回、全arming/鎖切り、Hist警戒/回復/解除、初失効、初P100委譲、初全予約、実要求、最後の保有中純状態を保存する。
- 各保存点は `before_snapshot/input/snapshot/decision` と実 `realized_net/remaining/reserved` を別記する。要求点には要求IDと予約後量を残す。
- `orders.lifecycle_point` と `fills.lifecycle_exit`：条件完成・実要求・実fillを別の群として結ぶ。
- `protection113.lifecycle_reservations`：保有監視注文の予約後に純P100へ実予約を同期した点。P100自己要求ではなく、独立したbefore/afterと失効注文IDを持つ。P100数式・床は変更しない。
- `FinalOwnership`：after_source時に実残0なら、実closing Quote/R/n=0/予約0だけを記録して終了する。終了原行で純監視を再評価し、新armed/失効を作らない。`final_state/last` は最後の保有中純評価であり、実返済後の仮想状態ではない。

全Rawの入力は複写しない。変化点と要求点は純状態の前後を独立複写し、通常の最後の点は公開Snapshot時に複写する。独立監査は保存点の1Advanceを検算できるが、未保存Raw全点に対するXQ最初性をPython別走で証明したとは呼ばない。

## X0対照と市場前検査

X0は追加監視audit・注文・fill・非零metricsが一つでもあれば対照を拒否する。明示X0設定とScope版説明だけを分離し、残り全JSONを旧115同名冊へ照合する。入口DecisionやP100値をマスクしない。

旧会計人工、旧115入口人工を継承し、全36×買売鏡像、旧12各原行/終端対照、Source通知非干渉、部分/全予約、同秒後原行D0と遅延D1、異常BBOのXC完成とXQ待機、P100優先と既ラッチ維持、欠測鎖切り、実fill時latest、終了後非評価、未来/scope/同ID改変拒否、公開値の参照分離、X0破壊拒否を検査する。全て手製Sourceと手製5分OHLCであり、自然FAR生成・市場損益・Raw全点証明ではない。

停止helperは旧Actorと純監視の停止Ref、実コード閉包、全所有を前後認証し、test/vet/build・実API・36宣言・人工を保存する。Rootレビュー前にActor停止は生成しない。人工の非圧縮JSONはwork限定とし、正式参照には必要なら同bytesのgzipを使う。市場/Raw/Native/CSV/11月09日本文の読取・金融再実行はなく、研究目標達成・採用はfalse。
