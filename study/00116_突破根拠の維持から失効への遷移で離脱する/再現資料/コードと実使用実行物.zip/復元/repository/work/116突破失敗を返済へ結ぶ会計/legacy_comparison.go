package miniprotect

import (
	"bytes"
	"encoding/json"
	"fmt"
	"reflect"
	"strings"

	legacy "github.com/masayoshi4649/SessionTradeExecuter/continuousactor115"
)

// LegacyComparison116 は無効な追加監視と実金融同体を分けて記録します。
type LegacyComparison116 struct {
	EntryMode           string `json:"entry_mode"`
	LifeMode            string `json:"life_mode"`
	Protection          string `json:"protection"`
	StreamScopeChanged  bool   `json:"stream_scope_difference"`
	MonitoringDisabled  bool   `json:"monitoring_disabled"`
	ConfigEqual         bool   `json:"config_equal"`
	GateRecords         int    `json:"gate_records"`
	GateAccountingEqual bool   `json:"gate_accounting_equal"`
	AllFinancialEqual   bool   `json:"all_financial_equal"`
}

// comparisonJSON116 は数値字句を保持した独立JSON値を作ります。
//
// 引数: value(any)は新旧口座の全公開値です。
// 返り値: any/errorは参照共有のない値又は符号化拒否です。
func comparisonJSON116(value any) (any, error) {
	raw, err := json.Marshal(value)
	if err != nil {
		return nil, err
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	var result any
	err = decoder.Decode(&result)
	return result, err
}

// disabledLifecycle116 はX0に有効な監視記録や非零の追加集計がないことを検査します。
//
// 引数: result(map[string]any)は新116口座の全JSONです。
// 返り値: errorは無効であるべき監視の混入です。金融値の削除や零補完はしません。
func disabledLifecycle116(result map[string]any) error {
	for _, group := range []struct{ array, field string }{{"positions", "lifecycle116"}, {"orders", "lifecycle_point"}, {"fills", "lifecycle_exit"}} {
		for _, raw := range result[group.array].([]any) {
			if _, exists := raw.(map[string]any)[group.field]; exists {
				return fmt.Errorf("116X0に追加監視の有効値:%s", group.field)
			}
		}
	}
	for key := range result["metrics"].(map[string]any) {
		if strings.HasPrefix(key, "lifecycle_") {
			return fmt.Errorf("116X0に追加監視集計:%s", key)
		}
	}
	return nil
}

// CompareLegacy115 はX0の全12条件を旧115の同名条件へ全金融・全入口票・全P100で照合します。
//
// 引数: current(ActualResult)、prior(legacy.ActualResult)は同場・入口・費用・遅延の各原行又は終端です。
// 返り値: LegacyComparison116/errorは許可した説明差と同体証拠、又は差異です。
func CompareLegacy115(current ActualResult, prior legacy.ActualResult) (LegacyComparison116, error) {
	proof := LegacyComparison116{EntryMode: current.Config.EntryMode, LifeMode: current.Config.LifeMode, Protection: current.Config.Policy}
	if current.Config.LifeMode != "X0" || current.Config.Policy != "P100" || prior.Config.Policy != "P100" || current.Config.EntryMode != prior.Config.EntryMode || current.Config.SlipPts != prior.Config.SlipPts || current.Config.DelaySeconds != prior.Config.DelaySeconds || current.StreamScope != ContinuousScope116 || prior.StreamScope != legacy.ContinuousScope115 {
		return proof, fmt.Errorf("116X0と115の対照条件差")
	}
	key := fmt.Sprintf("%s_C%.0f_D%d", current.Config.EntryMode, current.Config.SlipPts, current.Config.DelaySeconds)
	if current.Key != key || prior.Key != key || current.EntryGate == nil || prior.EntryGate == nil || current.EntryGate.Version != 115 || prior.EntryGate.Version != 115 {
		return proof, fmt.Errorf("116X0の本名key又は入口115監査差")
	}
	leftValue, err := comparisonJSON116(current)
	if err != nil {
		return proof, err
	}
	rightValue, err := comparisonJSON116(prior)
	if err != nil {
		return proof, err
	}
	left, right := leftValue.(map[string]any), rightValue.(map[string]any)
	if err = disabledLifecycle116(left); err != nil {
		return proof, err
	}
	proof.MonitoringDisabled = true
	configuration := left["config"].(map[string]any)
	if configuration["life_mode"] != "X0" {
		return proof, fmt.Errorf("116X0の明示設定がない")
	}
	delete(configuration, "life_mode")
	if !reflect.DeepEqual(left["config"], right["config"]) {
		return proof, fmt.Errorf("116X0と115の同費用/入口差")
	}
	proof.ConfigEqual = true
	if !reflect.DeepEqual(left["entry_gate"], right["entry_gate"]) {
		return proof, fmt.Errorf("116X0と115の全入口票/受付/取得差")
	}
	proof.GateRecords, proof.GateAccountingEqual = len(current.EntryGate.Records), true
	proof.StreamScopeChanged = left["stream_scope"] != right["stream_scope"]
	left["stream_scope"], right["stream_scope"] = "", ""
	if !reflect.DeepEqual(left, right) {
		return proof, fmt.Errorf("116X0と115の全金融/全State差:%s", key)
	}
	proof.AllFinancialEqual = true
	return proof, nil
}
