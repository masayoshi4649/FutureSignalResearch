package miniprotect

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	legacy "github.com/masayoshi4649/SessionTradeExecuter/continuousactor115"
	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate115"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor113"
	oldframe "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	bank "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

const contract115 = "人工限月115"

// children115 は当時の指紋と時刻を持つ手製5分OHLCを生成します。
//
// 引数: scene(oldframe.Session)、side(int)、prior/reversal(bool)は場と鏡像方向・前史・回復系列です。
// 返り値: []oldframe.ChildBarは市場由来でない入力です。現在場の12本目だけ欠足にします。
func children115(scene oldframe.Session, side int, prior, reversal bool) []oldframe.ChildBar {
	out := []oldframe.ChildBar{}
	for i := 0; i < int((scene.End-scene.Start)/300); i++ {
		if !prior && i == 11 {
			continue
		}
		close := 1000 + 10*float64(i)
		if prior {
			close = 400 + 3*float64(i)
			if reversal {
				close = 1600 - 5*float64(i)
			}
		}
		open, high, low := close-4, close+1, close-5
		if prior && reversal {
			open, high, low = close+4, close+5, close-1
		}
		if side < 0 {
			open, high, low, close = 3000-open, 3000-low, 3000-high, 3000-close
		}
		start := scene.Start + 300*float64(i)
		out = append(out, oldframe.ChildBar{Start: start, End: start + 300, OHLC: oldframe.OHLC{Open: open, High: high, Low: low, Close: close}, Volume: 10, Closed: true, VolumeKnown: true,
			Input: oldframe.FileRef{Path: "人工/" + scene.ID + ".csv", SHA256: strings.Repeat("a", 64), Bytes: 1}, Row: uint64(i + 1)})
	}
	return out
}

// bank115 はSourceとP100へ接続しない人工の入口専用bankを作ります。
//
// 引数: t(*testing.T)、side(int)、kind(string)は試験器・方向・T/R/未知の局面です。
// 返り値: *bank.Bankは同限月の数値助走又は明示coldを持つ入口器です。
func bank115(t *testing.T, side int, kind string) *bank.Bank {
	t.Helper()
	session := session94()
	scene := oldframe.Session{ID: session.ID, Contract: contract115, Start: session.Start, End: session.End, EOF: session.End}
	var seed *bank.Seed
	if kind != "missing" {
		previous := oldframe.Session{ID: "人工前史115", Contract: contract115, Start: session.Start - 50400, End: session.Start - 3600, EOF: session.Start - 3600}
		warm, err := bank.BeginSession(previous, children115(previous, side, true, kind == "reversal"), nil)
		if err != nil {
			t.Fatal(err)
		}
		if _, err = warm.AdvanceObserved(previous.EOF, 1); err != nil {
			t.Fatal(err)
		}
		value, _, err := warm.Seal()
		if err != nil {
			t.Fatal(err)
		}
		seed = &value
	}
	out, err := bank.BeginSession(scene, children115(scene, side, false, false), seed)
	if err != nil {
		t.Fatal(err)
	}
	return out
}

// protection115 は新しい入口bankから独立した共通P100公表を作ります。
//
// 引数: side(int)、ordinal(uint64)は方向と保護公表の順序です。
// 返り値: guard.Publicationは113/114と同じ純APIへ渡す手製の当時公表です。
func protection115(side int, ordinal uint64) guard.Publication {
	session := session94()
	end := session.Start + 1440 + float64(ordinal)*180
	close, pivot, kind := 1210.0, 1200.0, "low"
	if side < 0 {
		close, pivot, kind = 3000-close, 3000-pivot, "high"
	}
	scope := guard.Scope{Session: session.ID, Contract: contract115, Start: session.Start}
	v := 20.0
	return guard.Publication{Scope: scope, ID: fmt.Sprintf("保護人工115/%d/%d", side, ordinal), Ordinal: ordinal, Start: end - 180, End: end, AvailableAt: end, C: guard.True, M: guard.True, Close: &close, V: &v,
		PriorPivot: &guard.Pivot{Scope: scope, ID: "共通prior115", Kind: kind, Price: pivot, CenterStart: session.Start + 180, CenterEnd: session.Start + 360, ConfirmEnd: session.Start + 540, PublishedAt: session.Start + 600}}
}

// observation115 は人工Sourceの現在Lastを入口子足と同じ鏡像価格へ合わせます。
//
// 引数: session(Session)、side(int)、index(int64)、seconds/move(float64)は場・方向・原行・時刻・値幅です。
// 返り値: Observationは市場由来でない当原行です。公開nativeATRは変えません。
func observation115(session Session, side int, index int64, seconds, move float64) Observation {
	o := observation94(session, 1, index, seconds, 100+move, 20)
	o.Time += 1800
	o.Received = o.Time
	if side < 0 {
		o.Last, o.Bid, o.Ask = 3000-o.Last, 3000-o.Ask, 3000-o.Bid
	}
	return o
}

// actorFixture115 は115由来の12口座人工をX0と旧115の各12口座へ配送します。
//
// 引数: t(*testing.T)、side(int)、kind(string)は試験器と鏡像・T/R/偽/未知の局面です。
// 返り値: 二つのmapは完結116X0全12冊と旧115全12冊。FAR自然生成ではありません。
func actorFixture115(t *testing.T, side int, kind string) (map[string]ActualResult, map[string]legacy.ActualResult) {
	t.Helper()
	session, source := session94(), newFixtureSource94()
	entry := bank115(t, side, kind)
	books, previous := map[string]*ActualBook{}, map[string]*legacy.ActualBook{}
	for _, cfg := range DeclaredContinuousConfigurations() {
		if cfg.LifeMode != "X0" {
			continue
		}
		book, err := NewContinuousBook(session, contract115, cfg)
		if err != nil {
			t.Fatal(err)
		}
		books[book.result.Key] = book
		if cfg.LifeMode == "X0" {
			old, err := legacy.NewContinuousBook(session, contract115, legacy.ActorConfig{Policy: cfg.Policy, EntryMode: cfg.EntryMode, SlipPts: cfg.SlipPts, DelaySeconds: cfg.DelaySeconds})
			if err != nil {
				t.Fatal(err)
			}
			previous[book.result.Key] = old
		}
	}
	times := []float64{0, 60, 61, 61, 62, 63, 64, 65, 66, 67, 68, 69}
	for i, move := range []float64{0, 0, 130, 450, 350, 400, 250, 50, 70, 0, 0, 0} {
		if kind == "false" && i == 0 {
			move = -20
		}
		o := observation115(session, side, int64(i+2), times[i], move)
		if i == 5 {
			o.QuoteOK = false
		}
		signals := []native.Signal{}
		if i == 0 {
			signals = append(signals, birth94("入口A115", side, 5))
		}
		if i == 4 {
			signals = append(signals, close94("部分A115", "入口A115", side, 2))
		}
		if i == 9 {
			signals = append(signals, close94("残A115", "入口A115", side, 3))
		}
		batch := source.step(t, o, int64(i+102), signals, nil)
		if _, err := entry.AdvanceObserved(o.Time, uint64(o.Index)+1); err != nil {
			t.Fatal(err)
		}
		snapshot, err := entry.SnapshotAt(o.Time)
		if err != nil {
			t.Fatal(err)
		}
		if i == 1 {
			five, _ := snapshot.Scale(300)
			if !five.HasCurrent || five.Current.Frame.PriceKnown {
				t.Fatal("取得後の欠足公表を人工で配送していない")
			}
		}
		for _, book := range books {
			if err = book.SetEntrySnapshot(snapshot, gate.Stamp{Time: o.Time, Index: int(o.Index), Line: int64(i + 102)}); err != nil {
				t.Fatal(err)
			}
		}
		for _, book := range previous {
			if err = book.SetEntrySnapshot(snapshot, gate.Stamp{Time: o.Time, Index: int(o.Index), Line: int64(i + 102)}); err != nil {
				t.Fatal(err)
			}
		}
		if i == 0 || i == 6 {
			ordinal := uint64(1 + i/6)
			for _, direction := range []int{1, -1} {
				pub := protection115(direction, ordinal)
				for _, book := range books {
					if err = book.SetPublication(o.Time, direction, pub); err != nil {
						t.Fatal(err)
					}
				}
				for _, book := range previous {
					if err = book.SetPublication(o.Time, direction, pub); err != nil {
						t.Fatal(err)
					}
				}
			}
		}
		for _, book := range books {
			if err = book.OnNativeStep(o, int64(i+102), []NativeBatch{batch}); err != nil {
				t.Fatal(book.result.Key, err)
			}
		}
		for key, old := range previous {
			if err = old.OnNativeStep(o, int64(i+102), []legacy.NativeBatch{{Method: batch.Method, Delta: batch.Delta}}); err != nil {
				t.Fatal(err)
			}
			if proof, e := CompareLegacy115(books[key].Snapshot(), old.Snapshot()); e != nil || !proof.AllFinancialEqual || !proof.GateAccountingEqual {
				t.Fatal(key, e, proof)
			}
		}
	}
	// ----------------------------------------
	// 当場の実残/予約0を確認した完結値だけを人工の成果物へ返します。
	result, prior := map[string]ActualResult{}, map[string]legacy.ActualResult{}
	for key, book := range books {
		value, err := book.Finish()
		if err != nil {
			t.Fatal(key, err)
		}
		result[key] = value
	}
	for key, book := range previous {
		value, err := book.Finish()
		if err != nil {
			t.Fatal(err)
		}
		prior[key] = value
		if _, err = CompareLegacy115(result[key], value); err != nil {
			t.Fatal(err)
		}
	}
	return result, prior
}

// TestEntryModes115 はT/R/Last否定/未知を12設定と費用間同票で確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。cold不足を許可へ変えず、後の欠足で凍結票を再ゲートしません。
func TestEntryModes115(t *testing.T) {
	for _, kind := range []string{"trend", "reversal", "false", "missing"} {
		result, _ := actorFixture115(t, 1, kind)
		for key, book := range result {
			row := book.EntryGate.Records[0]
			want := book.Config.EntryMode == "A0" || kind == "trend" || kind == "reversal" && book.Config.EntryMode == "TR"
			if row.Allowed != want || (book.Metrics.EntryFills > 0) != want || len(book.EntryGate.Records) != 1 {
				t.Fatalf("%s/%s:期待=%v T/R/C=%d/%d/%d 値=%+v 否定=%v/%v/%v", kind, key, want, row.Decision.Trend, row.Decision.Reversal, row.Decision.Common, row.Decision.Values, row.Decision.CommonDenials, row.Decision.TrendDenials, row.Decision.ReversalDenials)
			}
			if !reflect.DeepEqual(row.Decision, result["A0_C0_D0"].EntryGate.Records[0].Decision) || row.Request.Last != row.Quote.Last {
				t.Fatal("費用/モード間同票又は要求時Last差")
			}
			if kind == "missing" && (row.Decision.Trend != gate.Unknown || len(row.Decision.MissingInputs) == 0) {
				t.Fatal("未知を隠した")
			}
			if kind == "reversal" && (row.Decision.Trend != gate.False || row.Decision.Reversal != gate.True || row.Decision.Combined != gate.True) {
				t.Fatal("反転を順行と混同")
			}
		}
	}
}

// TestEntryMirror115 は買売鏡像の金額と入口純値の向きを確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。Source/P100は両側とも同じ条件を使います。
func TestEntryMirror115(t *testing.T) {
	buy, _ := actorFixture115(t, 1, "reversal")
	sell, _ := actorFixture115(t, -1, "reversal")
	for key, book := range buy {
		if book.Totals != sell[key].Totals || book.EntryGate.Records[0].Decision.Trend != sell[key].EntryGate.Records[0].Decision.Trend || book.EntryGate.Records[0].Decision.Reversal != sell[key].EntryGate.Records[0].Decision.Reversal {
			t.Fatal("買売鏡像差", key)
		}
	}
}

// TestEntrySnapshotCorruption115 は未来/原行差と返却値aliasを拒否又は分離します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。新研究snapshotからP100値へ書き戻しません。
func TestEntrySnapshotCorruption115(t *testing.T) {
	book, err := NewContinuousBook(session94(), contract115, ActorConfig{Policy: "P100", LifeMode: "X0", EntryMode: "A0"})
	if err != nil {
		t.Fatal(err)
	}
	entry := bank115(t, 1, "trend")
	at := session94().Start + 3600
	if _, err = entry.AdvanceObserved(at, 3); err != nil {
		t.Fatal(err)
	}
	snapshot, err := entry.SnapshotAt(at)
	if err != nil {
		t.Fatal(err)
	}
	if err = book.SetEntrySnapshot(snapshot, gate.Stamp{Time: at - 1, Index: 2, Line: 102}); err == nil {
		t.Fatal("未来又はsnapshot asof差を受理")
	}
	values, _ := actorFixture115(t, 1, "trend")
	original := values["A0_C0_D0"]
	copy := valueCopy(original)
	*copy.EntryGate.Records[0].Decision.Values.G30 = -123
	if *original.EntryGate.Records[0].Decision.Values.G30 < 0 {
		t.Fatal("純値pointerの参照共有")
	}
	if _, err = NewContinuousBook(session94(), contract115, ActorConfig{Policy: "E100", LifeMode: "X0", EntryMode: "A0"}); err == nil {
		t.Fatal("P100以外を受付")
	}
	// ----------------------------------------
	// 同秒の別原行は新しい出生を受けるが、同じ足の値を別公表へ偽装しません。
	same, err := NewContinuousBook(session94(), contract115, ActorConfig{Policy: "P100", LifeMode: "X0", EntryMode: "T"})
	if err != nil {
		t.Fatal(err)
	}
	clock, source := bank115(t, 1, "trend"), newFixtureSource94()
	for index := int64(2); index <= 3; index++ {
		o := observation115(session94(), 1, index, 0, 0)
		batch := source.step(t, o, index+100, []native.Signal{birth94(fmt.Sprintf("同秒115-%d", index), 1, 1)}, nil)
		if _, err = clock.AdvanceObserved(o.Time, uint64(index)+1); err != nil {
			t.Fatal(err)
		}
		snapshot, err = clock.SnapshotAt(o.Time)
		if err != nil {
			t.Fatal(err)
		}
		if err = same.SetEntrySnapshot(snapshot, gate.Stamp{Time: o.Time, Index: int(index), Line: index + 100}); err != nil {
			t.Fatal(err)
		}
		if err = same.OnNativeStep(o, index+100, []NativeBatch{batch}); err != nil {
			t.Fatal(err)
		}
	}
	rows := same.Snapshot().EntryGate.Records
	if len(rows) != 2 || !rows[0].Allowed || !rows[1].Allowed || rows[0].Request.At.Time != rows[1].Request.At.Time || rows[0].Request.At.Index == rows[1].Request.At.Index || rows[0].Decision.Current.Snapshot.Scales[0].Current.Frame.ID != rows[1].Decision.Current.Snapshot.Scales[0].Current.Frame.ID {
		t.Fatal("同秒後原行の別出生/同Frameの使い方に差")
	}
}

// TestEntryComparisonCorruption115 は金融・純State・受付・固定Lastの差を対照から隠さないことを確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。旧115の本物の人工完結値へ各破壊を照合します。
func TestEntryComparisonCorruption115(t *testing.T) {
	values, previous := actorFixture115(t, 1, "trend")
	current, prior := values["A0_C0_D0"], previous["A0_C0_D0"]
	for _, kind := range []string{"net", "state", "gate", "last", "capacity", "actual"} {
		bad := valueCopy(current)
		switch kind {
		case "net":
			bad.Totals.NetYen++
		case "state":
			bad.Positions[0].Protection113.FinalState.ClosedNetYen++
		case "gate":
			bad.EntryGate.Records[0].Allowed = false
		case "last":
			bad.EntryGate.Records[0].Request.Last++
		case "capacity":
			bad.EntryGate.Records[0].CapQuantity++
		case "actual":
			bad.EntryGate.Records[0].ActualQuantity++
		}
		if _, err := CompareLegacy115(bad, prior); err == nil {
			t.Fatal("破壊を隠した", kind)
		}
	}
}

// TestEntrySameFrameAndCapacity115 は同じ公表の別出生・容量0・元取消を分離します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。拒否出生を次原行へ持ち越さず、Source通知を変更しません。
func TestEntrySameFrameAndCapacity115(t *testing.T) {
	scene, source, entry := session94(), newFixtureSource94(), bank115(t, 1, "trend")
	books := map[string]*ActualBook{}
	for _, cfg := range DeclaredContinuousConfigurations() {
		if cfg.LifeMode != "X0" {
			continue
		}
		book, err := NewContinuousBook(scene, contract115, cfg)
		if err != nil {
			t.Fatal(err)
		}
		books[book.result.Key] = book
	}
	for i := 0; i < 6; i++ {
		o := observation115(scene, 1, int64(i+2), float64(i), 0)
		signals, cancels := []native.Signal{}, []string{}
		switch i {
		case 0:
			signals = []native.Signal{birth94("買A115", 1, 10), birth94("容量C115", 1, 1), birth94("売B115", -1, 10)}
		case 1:
			signals = []native.Signal{birth94("容量F115", 1, 2)}
		case 2:
			signals = []native.Signal{close94("A全", "買A115", 1, 10), close94("C全", "容量C115", 1, 1), close94("B全", "売B115", -1, 10), close94("F全", "容量F115", 1, 2)}
		case 4:
			signals, cancels = []native.Signal{birth94("取消Z115", 1, 5)}, []string{"取消Z115"}
		}
		batch := source.step(t, o, int64(i+102), signals, cancels)
		if _, err := entry.AdvanceObserved(o.Time, uint64(o.Index)+1); err != nil {
			t.Fatal(err)
		}
		snapshot, err := entry.SnapshotAt(o.Time)
		if err != nil {
			t.Fatal(err)
		}
		for key, book := range books {
			if err = book.SetEntrySnapshot(snapshot, gate.Stamp{Time: o.Time, Index: int(o.Index), Line: int64(i + 102)}); err != nil {
				t.Fatal(key, err)
			}
			if err = book.OnNativeStep(o, int64(i+102), []NativeBatch{batch}); err != nil {
				t.Fatal(key, err)
			}
		}
	}
	for key, book := range books {
		result, err := book.Finish()
		if err != nil || result.Metrics.CapRejectedEntries != 2 || len(result.EntryGate.Records) != 5 {
			t.Fatal(key, err, result.Metrics)
		}
		for _, row := range result.EntryGate.Records {
			if row.Request.SignalID == "容量C115" || row.Request.SignalID == "容量F115" {
				if !row.Allowed || row.CapQuantity != 0 || row.AcceptedQuantity != 0 || row.ActualQuantity != 0 {
					t.Fatal("容量拒否を技法拒否と混同")
				}
				if id, exists := book.entryBySource[sourceKey(row.Request.Method, row.Request.SignalID)]; !exists || id != "" {
					t.Fatal("拒否出生を消費していない")
				}
			}
			if row.Request.SignalID == "取消Z115" && (!row.SourceCancelled || row.AcceptedQuantity != 0 || row.ActualQuantity != 0) {
				t.Fatal("元取消を復活")
			}
		}
	}
}

// TestExportEntry115 は明示環境時だけ買売12冊と旧各4冊・宣言を人工保存します。
//
// 引数: t(*testing.T)、環境CONTINUOUS116_EXPORT_DIR(string)は試験器と未作成先です。
// 返り値: なし。価格CSVやNativeを読まず、Sourceは手製通知です。
func TestExportEntry115(t *testing.T) {
	directory := os.Getenv("CONTINUOUS116_EXPORT_DIR")
	if directory == "" {
		t.Skip("人工export指定時だけ")
	}
	if _, err := os.Stat(directory); !os.IsNotExist(err) {
		t.Fatal("人工は新規先だけ")
	}
	if err := os.MkdirAll(directory, 0755); err != nil {
		t.Fatal(err)
	}
	buy, priorBuy := actorFixture115(t, 1, "reversal")
	sell, priorSell := actorFixture115(t, -1, "reversal")
	values := map[string]any{"買い": buy, "売り": sell, "買い_115": priorBuy, "売り_115": priorSell, "市場": false, "FAR自然生成": false}
	for name, value := range map[string]any{"宣言設定.json": DeclaredContinuousConfigurations(), "買売人工.json": values, "入口定義.json": gate.DeclaredDefinition()} {
		body, err := json.MarshalIndent(value, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(filepath.Join(directory, name), append(body, '\n'), 0600); err != nil {
			t.Fatal(err)
		}
	}
}
