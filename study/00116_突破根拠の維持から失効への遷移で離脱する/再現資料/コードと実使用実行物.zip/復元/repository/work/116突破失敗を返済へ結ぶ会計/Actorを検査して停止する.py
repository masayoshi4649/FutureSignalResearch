"""116Actorの市場前人工・旧12金融対照・停止依存を固定する。"""

import argparse
import difflib
import gzip
import hashlib
import json
import os
import re
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OLD = ROOT / 'work/115三時間軸の複合入口を執行する会計'
OLD_STOP = OLD / 'Actor停止.json'
OLD_SHA = '318de27a32a0941114443e5045426df3599eea74e8e5ffa8647771e92934ce35'
COPY_SHA = '1a0ae14da21d7d8544b4c8113a0ae134847bab3bd236a511410017f96a866c10'


def sha(path: Path) -> str:
    """機能: コード又は人工証拠の全bytes指紋を逐次算出する。

    引数: path(Path)は明示入力。
    返り値: strは小文字SHA256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        while block := source.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def run(argv: list[str], environment: dict) -> dict:
    """機能: 原板を開かないGo人工・API検査を実行する。

    引数: argv(list[str])とenvironment(dict)はコマンドと明示環境。
    返り値: dictは終了値と出力。不成功はValueError。
    """
    value = subprocess.run(argv, cwd=HERE, env=environment, capture_output=True,
                           text=True, encoding='utf-8', timeout=180)
    result = {'argv': argv, 'exit_code': value.returncode,
              'stdout': value.stdout, 'stderr': value.stderr}
    if value.returncode:
        raise ValueError(json.dumps(result, ensure_ascii=False))
    return result


# ----------------------------------------
def authenticate(ref: dict) -> dict:
    """機能: 停止FileRefを本文利用より前に認証する。

    引数: ref(dict)は絶対path/sha256。
    返り値: dictは成功かつ市場前の停止JSON。不整合はValueError。
    """
    if set(ref) != {'path', 'sha256'} or not Path(ref['path']).is_absolute() or sha(Path(ref['path'])) != ref['sha256']:
        raise ValueError('停止Refの位置又はSHA差')
    value = json.loads(Path(ref['path']).read_bytes())
    if value.get('成功') is not True or value.get('市場前') is not True or value.get('停止') is not True:
        raise ValueError('依存は市場前成功停止が必要')
    return value


# ----------------------------------------
def add_hash_maps(value: dict, dependencies: dict) -> None:
    """機能: 停止内の明示コードmapだけを衝突なく結合する。

    引数: value/dependencies(dict)は停止内容と絶対path→SHA台帳。
    返り値: None。金融Native等のRefを再帰読取しない。
    """
    names = ('所有コードSHA256', '所有ファイルSHA256', '依存SHA256', '再用コードSHA256',
             '再用ファイルSHA256', '実依存SHA256', '実Go依存SHA256', 'Go実閉包SHA256',
             '実Go依存コードSHA256', 'GoRootコードSHA256', '全固定コードSHA256')
    for name in names:
        for path, digest in value.get(name, {}).items():
            if not isinstance(digest, str) or re.fullmatch('[a-f0-9]{64}', digest) is None or not Path(path).is_absolute():
                raise ValueError('停止コードmapの形式差:' + name)
            if path in dependencies and dependencies[path] != digest:
                raise ValueError('依存の同位置指紋衝突')
            dependencies[path] = digest


# ----------------------------------------
def functions(path: Path) -> dict:
    """機能: 本Goコードのトップレベル関数本文を比較用に抽出する。

    引数: path(Path)は既知のactual.go又はcontinuous.go。
    返り値: dict[str,str]は関数名と宣言/本文。汎用Goパーサを主張しない。
    """
    source, out = path.read_text(encoding='utf-8'), {}
    for match in re.finditer(r'^func (?:\([^\n]+?\) )?(\w+)(?:\[[^\n]*?\])?\(', source, re.M):
        line_end = source.find('\n', match.start())
        end = line_end - 1 if '}' in source[match.start():line_end] else source.find('\n}', match.start())
        if end < match.start() or match.group(1) in out:
            raise ValueError('関数抽出の不整合')
        out[match.group(1)] = source[match.start():end + 2]
    return out


# ----------------------------------------
def verify_derivation() -> dict:
    """機能: 旧115の入口同bytesと既存会計/P接続関数の限定差を明示する。

    引数: なし。
    返り値: dictは同体関数・接続変更関数・全文差分。追加出口自体を同体と偽装しない。
    """
    if sha(HERE / '同bytesコピーの記録.json') != COPY_SHA:
        raise ValueError('派生前コピー履歴差')
    copy_record = json.loads((HERE / '同bytesコピーの記録.json').read_bytes())
    if copy_record['全同bytes'] is not True or copy_record['コピー数'] != 12:
        raise ValueError('派生前コピー不成立')
    for item in copy_record['files']:
        if sha(Path(item['元path'])) != item['元SHA256'] or item['元SHA256'] != item['初期コピーSHA256']:
            raise ValueError('元115のコピー時指紋差')
    same_files = ['entry_gate.go', 'actual_test.go', 'go.sum']
    if any(sha(HERE / name) != sha(OLD / name) for name in same_files):
        raise ValueError('旧入口/基礎人工/依存和の同体差')
    allowed = {'actual.go': {'NewActualBook', 'fillOrders', 'OnNativeStep', 'Snapshot'},
               'continuous.go': {'DeclaredContinuousConfigurations', 'NewContinuousBook'}}
    checks, differences = {}, {}
    for name, changed in allowed.items():
        previous, current = functions(OLD / name), functions(HERE / name)
        actual = {key for key in previous if previous[key] != current.get(key)}
        if set(previous) != set(current) or actual != changed:
            raise ValueError('旧会計/P接続の関数差が予定外:' + name)
        checks[name] = {'同体関数': sorted(set(previous) - changed), '接続変更関数': sorted(changed)}
    for name in ['actual.go', 'actual_types.go', 'continuous.go', 'go.mod']:
        differences[name] = ''.join(difflib.unified_diff((OLD / name).read_text(encoding='utf-8').splitlines(True),
            (HERE / name).read_text(encoding='utf-8').splitlines(True), fromfile='115/' + name, tofile='116/' + name))
    return {'同bytesファイル': same_files, '関数比較': checks, '全文差分': differences,
            '追加出口': 'lifecycle.go。X0各原行対照と新36人工を別途確認。',
            '入口115/P113数式/費用/数量/既存約定条件の変更': False}


# ----------------------------------------
def go_closure(environment: dict) -> dict:
    """機能: 実選択された非テストGo閉包とmodule入力を指紋化する。

    引数: environment(dict)は固定Go環境。
    返り値: dict[str,str]は実在コードpath→SHA。テスト本体は所有mapで別認証する。
    """
    output = run(['go', 'list', '-deps', '-json', '.'], environment)['stdout']
    decoder, offset, paths = json.JSONDecoder(), 0, set()
    while output[offset:].strip():
        offset += len(output[offset:]) - len(output[offset:].lstrip())
        item, offset = decoder.raw_decode(output, offset)
        directory = Path(item['Dir'])
        for name in ['GoFiles', 'CgoFiles', 'CFiles', 'CXXFiles', 'HFiles', 'SFiles', 'SysoFiles', 'EmbedFiles']:
            for relative in item.get(name, []):
                path = directory / relative
                if not path.is_file():
                    raise ValueError('実選択Goファイル欠落:' + str(path))
                paths.add(path.resolve())
        module = item.get('Module', {})
        if module.get('GoMod'):
            path = Path(module['GoMod'])
            paths.add(path.resolve())
            if path.with_name('go.sum').is_file():
                paths.add(path.with_name('go.sum').resolve())
    return {str(path): sha(path) for path in sorted(paths)}


# ----------------------------------------
def stop(life_ref: dict, root_reviewed: bool) -> dict:
    """機能: Rootレビュー済みの新Actorを人工/vet/build後に市場前停止する。

    引数: life_ref(dict)は純監視停止、root_reviewed(bool)はRoot明示レビュー完了。
    返り値: dictは停止Ref。未承認・既存先・入力差は本文利用又は書込前に拒否する。
    """
    target, output = HERE / 'Actor停止.json', HERE / 'Actor検査'
    if not root_reviewed or target.exists() or output.exists() or sha(OLD_STOP) != OLD_SHA:
        raise ValueError('Rootレビュー済み・新規先・旧115停止不変が必要')
    old_stop = authenticate({'path': str(OLD_STOP), 'sha256': OLD_SHA})
    life_stop = authenticate(life_ref)
    if life_stop.get('試行') != 116:
        raise ValueError('純監視116の停止が必要')
    origin = json.loads((HERE / 'Actorの派生元.json').read_bytes())
    if origin['派生元停止'] != {'path': str(OLD_STOP), 'sha256': OLD_SHA}:
        raise ValueError('派生元停止の結合差')
    own = sorted(HERE.glob('*.go')) + [HERE / name for name in
        ['go.mod', 'go.sum', 'Actor_README.md', 'Actorの派生元.json', '同bytesコピーの記録.json', Path(__file__).name]]
    before = {str(path): sha(path) for path in own}
    dependencies = {str(OLD_STOP): OLD_SHA, life_ref['path']: life_ref['sha256']}
    for item in [old_stop, life_stop]:
        add_hash_maps(item, dependencies)
    if any(sha(Path(path)) != digest for path, digest in dependencies.items()):
        raise ValueError('依存停止後のSHA差')
    derivation = verify_derivation()
    environment = dict(os.environ, GOWORK='off', CGO_ENABLED='0')
    for key in list(environment):
        if key.endswith('EXPORT_DIR') and key.startswith(('MINIPROTECT', 'CONTINUOUS')):
            environment.pop(key)
    closure = go_closure(environment)
    checks = [run(['go', 'test', '-count=1', '-json', './...'], environment),
              run(['go', 'vet', './...'], environment), run(['go', 'build', './...'], environment)]
    events = [json.loads(line) for line in checks[0]['stdout'].splitlines() if line.startswith('{')]
    tests = [event['Test'] for event in events if event.get('Action') == 'pass' and 'Test' in event]
    if len(tests) != 17:
        raise ValueError('旧11主/新6主の人工件数差:' + str(tests))
    output.mkdir()
    exported = run(['go', 'test', '-count=1', '-run', '^TestExportLifecycle116$', './...'],
                   dict(environment, CONTINUOUS116_LIFE_EXPORT_DIR=str(output / '人工')))
    api = run(['go', 'doc', '-all', '.'], environment)
    (output / 'API.txt').write_text(api['stdout'], encoding='utf-8')
    declared = json.loads((output / '人工/宣言設定.json').read_bytes())
    expected = [{'policy': 'P100', 'life_mode': life, 'entry_mode': mode, 'slip_pts': cost, 'delay_seconds': delay}
                for life in ['X0', 'XC', 'XQ'] for mode in ['A0', 'T', 'TR'] for cost in [0, 5] for delay in [0, 1]]
    if declared != expected or not all(name in api['stdout'] for name in
        ['func CompareLegacy115(', 'func (b *ActualBook) SetLifecycleSnapshot(', 'func (b *ActualBook) SetEntrySnapshot(']):
        raise ValueError('実36宣言又はAPI差')
    definition_ref = life_stop['実定義']
    if sha(Path(definition_ref['path'])) != definition_ref['sha256'] or json.loads((output / '人工/監視定義.json').read_bytes()) != json.loads(Path(definition_ref['path']).read_bytes()):
        raise ValueError('Actor監視定義と純停止の差')
    names = ['買売人工.json', '宣言設定.json', '監視定義.json', '入口定義.json']
    same = all(sha(HERE / '人工_独立判定用' / name) == sha(output / '人工' / name) for name in names)
    if not same:
        raise ValueError('Root/独立へ渡した人工から値が変わった')
    source, compressed = output / '人工/買売人工.json', output / '人工/買売人工.json.gz'
    with source.open('rb') as reader, compressed.open('xb') as file, gzip.GzipFile(filename='', mode='wb', fileobj=file, mtime=0) as zipper:
        while block := reader.read(1024 * 1024):
            zipper.write(block)
    if before != {path: sha(Path(path)) for path in before} or closure != go_closure(environment) or any(sha(Path(path)) != digest for path, digest in dependencies.items()):
        raise ValueError('所有/実Go/依存の前後差')
    verify_derivation()
    proof = {'試行': 116, '成功': True, '市場前': True, '主人工数': 17, '成功test': tests,
             'test/vet/build': checks, '人工export': exported, '派生と同体': derivation,
             '旧115全12対照': '各受理原行と終端の全金融・入口Decision/P100全State。X0無効検査後の明示LifeModeとScope説明だけの差。',
             'Root突合用人工と同bytes': same, '所有コードSHA256': before, '依存SHA256': dependencies,
             '実Go依存SHA256': closure, '前後不変': True,
             '限界': ['手製Source通知。自然FAR生成/市場ではない。', '保存点は全Rawの複写でなくXQ未保存中間点の最初性を独立証明しない。'],
             '市場/Raw/Native/価格CSV/11月09日本文': False}
    proof_path = output / '人工確認.json'
    proof_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    record = {'試行': 116, '成功': True, '市場前': True, '停止': True,
              'module': 'github.com/masayoshi4649/SessionTradeExecuter/continuousactor116',
              '所有コードSHA256': before, '再用コードSHA256': dependencies, '実Go依存SHA256': closure, '前後不変': True,
              '純監視停止': life_ref, '元Actor停止': {'path': str(OLD_STOP), 'sha256': OLD_SHA},
              '人工確認': {'path': str(proof_path), 'sha256': sha(proof_path)},
              '実API': {'path': str(output / 'API.txt'), 'sha256': sha(output / 'API.txt')},
              '実36宣言': {'path': str(output / '人工/宣言設定.json'), 'sha256': sha(output / '人工/宣言設定.json')},
              '人工出力SHA256': {str(p): sha(p) for p in sorted((output / '人工').glob('*.json*'))},
              '市場/Raw/Native/価格CSV/11月09日本文': False, '研究目標達成': False, '採用': False}
    target.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return {'成功': True, '停止': {'path': str(target), 'sha256': sha(target)}}


# ----------------------------------------
def main() -> None:
    """機能: 純監視停止とRootレビュー完了を明示して116Actorを市場前停止する。

    引数: CLI life-stop/life-sha(str)、root-reviewed(bool)は位置・期待SHA・Root確認。
    返り値: None。成功時はActor停止Refだけを表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--life-stop', type=Path, required=True)
    parser.add_argument('--life-sha', required=True)
    parser.add_argument('--root-reviewed', action='store_true')
    args = parser.parse_args()
    print(json.dumps(stop({'path': str(args.life_stop.resolve()), 'sha256': args.life_sha}, args.root_reviewed), ensure_ascii=False))


if __name__ == '__main__':
    main()
