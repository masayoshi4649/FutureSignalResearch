"""Rootの別固定後だけ実Nativeを読み、原板未読のままGoReader用の未許可要求を組み立てる。"""
from copy import deepcopy
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import os
import re

from 固定参照 import A,S,I,D,G,ROOT,CONSUMER_STOP,CONSUMER_SHA,normalized_windows

HERE=Path(__file__).resolve().parent
F1_SHA='4c76a5f7cd8a59962e885cadf6885cfc75cbc590675955cb8e72ae2d0b8bb372'


def reference(ref: dict,before: dict) -> Path:
    """
    機能: 小metadata/解禁Nativeの指紋を利用前に認証する。
    引数: ref/before(dict)。返り値: Path。Rawには決して使わない。
    """
    p=Path(ref['path']);A.need(p.is_absolute() and re.fullmatch('[a-f0-9]{64}',ref['sha256']) is not None,'絶対FileRef');p=p.resolve();A.equal(S.digest(p),ref['sha256'],'builder参照SHA');before[str(p)]=ref['sha256'];return p


def metadata(ref: dict,before: dict) -> dict:
    """
    機能: Native/Raw/CSVを除いた小JSONだけを認証する。
    引数: ref/before(dict)。返り値: dict。原板pathへopen/statを行わない。
    """
    A.need(Path(ref['path']).suffix=='.json' and '.Native.' not in Path(ref['path']).name,'小metadata専用');return S.load(reference(ref,before))


def prepare(path: Path,sha: str,output: Path) -> dict:
    """
    機能: 同F1金融と実新型保存の成功を、builderの明示Native読取許可へ結ぶ。
    引数: path/output(Path)、sha(str)。返り値: dictは本文未読の計画。
    """
    A.need(output.is_absolute() and not output.exists() and not output.with_name(output.stem+'_作成の確認.json').exists(),'新規絶対出力/確認');before={};q=metadata({'path':str(path.resolve()),'sha256':sha},before)
    A.need(q['version']==1 and q['trial']==116 and q['fixed'] is True and q['market_native_read_authorized'] is True and q['raw_read_authorized'] is False and q['holdout_read_authorized'] is False,'Root別固定のNativeだけ許可。Raw/11月09は不可');A.need(q['stage'] in ('first2','full70'),'first2又はfull70')
    stop=metadata(q['builder_stop'],before);A.need(stop['成功'] and stop['停止'] and stop['市場前'] and stop['試行']==116,'新builder停止')
    for field in ('所有ファイルSHA256','依存コードSHA256'):
        for filename,expected in stop[field].items():A.need(Path(filename).suffix not in ('.gz','.csv','.jsonl'),'市場本文をコードへ入れない');reference({'path':filename,'sha256':expected},before)
    A.equal(stop['所有ファイルSHA256'].get(str(Path(__file__).resolve())),S.digest(Path(__file__)),'実builder自身の停止')
    A.need(G.same(q['consumer_stop'],{'path':str(CONSUMER_STOP),'sha256':CONSUMER_SHA}),'停止consumer参照');metadata(q['consumer_stop'],before)
    condition=metadata(q['condition'],before);complete=metadata(q['completion'],before);result=metadata(q['independent_result'],before);check=metadata(q['independent_check'],before);save=metadata(q['save_request'],before)
    A.equal(q['condition']['sha256'],F1_SHA,'同116F1');A.need(condition['trial']==116 and condition['fixed'] and condition['actual_configurations']==list(A.CONFIGS),'同全36金融固定')
    n=2 if q['stage']=='first2' else 70;A.need(complete['trial']==116 and complete['success'] and complete['stage']==q['stage'] and complete['sessions']==n and complete['books']==36*n and complete['condition_sha256']==F1_SHA and complete['unchanged'],'同stage全金融成功')
    A.need(complete['all_reference115_equal'] and complete['all_source111_equal'] and complete['reference115_comparisons']==12*n,'金融全旧対照/Source成功')
    for value in (result,check):
        A.need(value['成功'] and value['試行']==116 and value['stage']==q['stage'] and value['場数']==n and value['会計数']==36*n and value['前後不変'],'独立保存全成功')
        for field,name in (('金融条件SHA256','condition'),('金融完了SHA256','completion'),('Root保存要求SHA256','save_request')):A.equal(value[field],q[name]['sha256'],'同実上流/'+name)
        A.equal(value['保存器停止SHA256'],G.STOPS['会計停止.json'],'実保存は新型会計');A.equal(value['独立P停止SHA256'],G.STOPS['P停止.json'],'実P停止');A.equal(value['独立ライフ停止SHA256'],G.STOPS['ライフ停止.json'],'実life停止')
    A.need(save['trial']==116 and save['fixed'] and G.same(save['condition'],q['condition']) and G.same(save['completion'],q['completion']) and save['code_stop']['sha256']==G.STOPS['会計停止.json'],'Root実保存要求同体')
    A.need(G.same(q['manifest'],condition['manifest']),'同金融の実入力台帳');manifest=metadata(q['manifest'],before);A.need(isinstance(manifest['source_root'],str) and Path(manifest['source_root']).is_absolute(),'manifest.source_root絶対path');cases={x['id']:x for x in manifest['sessions']};A.equal(len(cases),len(manifest['sessions']),'台帳場ID一意')
    tasks=complete['results'];A.equal(len(tasks),n,'全予定場');A.equal([r['session'] for r in tasks],[c['id'] for c in manifest['sessions'][:n]],'台帳の先頭2又は全70予定場順');A.equal([r['session'] for r in save['scenes']],[r['session'] for r in tasks],'実保存と金融全場順')
    for task,stored in zip(tasks,save['scenes']):
        A.need(task['session'] in cases and not task['session'].startswith('2026-11-09'),'同台帳の許可場');A.need(G.same(task['native'],stored['native']),'実保存と金融の同Native');A.need(task['complete'] and task['books']==36 and task['x0_equal'] and task['x0_comparisons']==12 and task['reference115_equal'] and task['reference115_comparisons']==12 and task['source111_equal'] and task['open_quantity']==task['pending_quantity']==0,'場別全金融/旧対照/flat')
    A.equal(q['reader_stop']['sha256'],G.READER_SHA,'同Reader停止');reader_stop=metadata(q['reader_stop'],before);A.need(G.same(q['reader_stop'],{'path':str(G.READER),'sha256':G.READER_SHA}),'実Reader停止path');A.need(reader_stop['成功'] and reader_stop['停止'] and reader_stop['市場前'] and reader_stop['試行']==116,'実Reader停止schema')
    return {'request':q,'condition':condition,'complete':complete,'manifest':manifest,'cases':cases,'reader_stop':reader_stop,'before':before,'output':output,'tasks':tasks}


def raw_reference(manifest: dict,case: dict) -> tuple:
    """
    機能: 台帳のsource_root+NK225_book.pathを文字列で結び、指紋とsizeをそのまま保持する。
    引数: manifest/case(dict)。返り値: tuple[dict,int]はRaw参照/bytes。open/stat/hash/resolveは行わない。
    """
    file=case['files']['NK225_book'];base=manifest['source_root'];relative=file['path'];A.need(Path(base).is_absolute() and not Path(relative).is_absolute(),'台帳root絶対/ファイル相対path');path=os.path.normpath(os.path.join(base,relative));A.equal(os.path.normcase(os.path.commonpath([base,path])),os.path.normcase(os.path.normpath(base)),'Raw pathは台帳root内')
    A.need(re.fullmatch('[a-f0-9]{64}',file['sha256']) is not None and type(file['size']) is int and file['size']>0,'Raw台帳指紋/size型');return {'path':path,'sha256':file['sha256']},file['size']


def scene_from_native(native: dict,manifest: dict,case: dict) -> tuple:
    """
    機能: 生115出生票を再評価し、監視適格な実XC/XQ全玉のinclusive窓を和集合にする。
    引数: native/manifest/case(dict)。返り値: tuple[dict,dict]はGoReader Scene/小集計。Source虚玉は窓へ使わない。
    """
    actual,source=native['actual'],native['source'];A.need(native['trial']==actual['trial']==116 and actual['complete'] and source['complete'],'116完結Native');A.equal(actual['configurations'],list(A.CONFIGS),'全36構成');A.equal(set(actual['books']),set(A.KEYS),'全36口座集合')
    A.equal(source['session']['id'],case['id'],'台帳とSource場');A.equal(actual['scope']['session'],source['session'],'ActualとSource場全文');A.equal(source['contract'],case['contract'],'台帳とSource限月');A.equal(actual['scope']['contract'],source['contract'],'ActualとSource限月')
    windows=[];endpoints={};counts={'XC実玉':0,'XQ実玉':0,'適格実玉':0,'不適格実玉':0}
    for key,book in actual['books'].items():
        config=book['config'];A.equal(config,A.BY_KEY[key],'実口座本名設定')
        if config['life_mode']=='X0':continue
        records={r['actual_position_id']:r for r in book['entry_gate']['records'] or [] if r['actual_position_id']}
        for p in book['positions']:
            counts[config['life_mode']+'実玉']+=1;audit=p['lifecycle116'];entry=audit['initial']['entry'];record=records[p['id']]
            A.equal(entry['id'],p['id'],'実所有ID');A.equal(entry['policy'],config['life_mode'],'実life政策');A.equal(entry['side'],p['side'],'実方向');A.equal(entry['birth'],record['decision'],'実取得に結ぶ生115凍結出生');A.equal(record['actual_quote'],p['entry_quote'],'実取得Quote');A.equal(record['actual_quantity'],p['initial_quantity'],'実取得量')
            A.equal(entry['fill_stamp'],{k:p['entry_quote'][k] for k in ('time','index','source_line')},'実取得原行');D.L.E.OLD.verify_full_decision(entry['birth']);eligible=I.monitoring_eligible(entry)
            A.equal(audit['initial']['monitoring_eligible'],eligible,'生票から独立に監視適格を再計算');A.equal(audit['final_state']['monitoring_eligible'],eligible,'監視適格不変')
            if not eligible:counts['不適格実玉']+=1;continue
            counts['適格実玉']+=1;start,end=p['entry_quote'],p['closed_quote'];A.need(end is not None and start['index']<=end['index'] and start['source_line']<=end['source_line'] and source['session']['start']<=start['time']<=end['time']<=source['session']['end'],'実保有のinclusive両端')
            for quote in (start,end):
                if quote['index'] in endpoints:A.equal(quote,endpoints[quote['index']],'同Indexの窓端Quoteは全実口座で同体')
                else:endpoints[quote['index']]=quote
            windows.append({'start_quote':deepcopy(start),'end_quote':deepcopy(end)})
    merged=normalized_windows(windows);raw,size=raw_reference(manifest,case);quality=deepcopy(source['quality']['NK225']);A.need(isinstance(quality,dict),'Source NK225品質')
    required={'lines','clock_missing','outside','backward','bad_last','bad_quote','accepted','contracts'};A.equal(set(quality),required,'Source品質の実8field')
    for key in required-{'contracts'}:A.need(type(quality[key]) is int and quality[key]>=0,'Source品質件数型')
    rows=actual['counts']['rows'];A.need(type(rows) is int and rows>=0,'Actual全受理行数');cutoff=case.get('cutoff',0);A.need(A.number(cutoff,'台帳cutoff')>=0,'省略cutoffは0')
    scene={'session':case['id'],'reference':'NK225','contract':source['contract'],'start':source['session']['start'],'end':source['session']['end'],'cutoff':cutoff,'raw':raw,'raw_bytes':size,'expected_source_rows':rows,'expected_source_quality':quality,'windows':[{'window_id':f'W{i+1:05d}','start_quote':a,'end_quote':b} for i,(a,b) in enumerate(merged)]}
    counts['結合窓数']=len(merged);counts['窓内採用行数']=sum(b['index']-a['index']+1 for a,b in merged);return scene,counts


def run(plan: dict,root_ref: dict) -> dict:
    """
    機能: 明示解禁Nativeだけを読んでReader未許可要求を作り、Raw未読の証拠を保存する。
    引数: plan/root_ref(dict)。返り値: dictはReader要求/作成確認Ref。金融実行/原板走査なし。
    """
    scenes=[];counts=[]
    for task in plan['tasks']:
        ref=task['native'];path=Path(ref['path']);data=path.read_bytes();A.equal(hashlib.sha256(data).hexdigest(),ref['sha256'],'Root解禁NativeSHA');plan['before'][str(path.resolve())]=ref['sha256'];native=json.loads(gzip.decompress(data),parse_float=A.BASE.Decimal)
        A.equal(native['actual']['lifecycle_definition'],plan['condition']['lifecycle_definition'],'同F1の実life定義');scene,count=scene_from_native(native,plan['manifest'],plan['cases'][task['session']]);scenes.append(scene);counts.append({'session':task['session'],**count})
    q=plan['request'];stop=plan['reader_stop'];code={**stop['全固定コードSHA256'],**stop['所有コードSHA256'],q['reader_stop']['path']:q['reader_stop']['sha256']}
    result={'version':1,'trial':116,'fixed':False,'raw_read_authorized':False,'policy':'NK225_source_rows_lifecycle116_v1','stage':q['stage'],'reader_stop':q['reader_stop'],'executable':stop['実行物'],'code_sha256':code,'refs':{'financial_condition':q['condition'],'financial_completion':q['completion'],'independent_result':q['independent_result'],'independent_check':q['independent_check'],'lifecycle_audit_stop':{'path':str(G.SAVED/'ライフ停止.json'),'sha256':G.STOPS['ライフ停止.json']}},'scenes':scenes}
    after={p:S.digest(Path(p)) for p in plan['before']};A.equal(after,plan['before'],'builder全上流/Native/停止前後同体')
    with plan['output'].open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(result,ensure_ascii=False,indent=2,default=S.BASE.serial)+'\n')
    proof={'試行':116,'成功':True,'Root作成要求':root_ref,'Reader要求':{'path':str(plan['output']),'sha256':S.digest(plan['output'])},'Reader未固定/Raw未許可':True,'stage':q['stage'],'場数':len(scenes),'場別窓':counts,'生115出生から適格を再計算':True,'全監視適格実XC/XQ窓':True,'入力SHA256前':plan['before'],'入力SHA256後':after,'前後不変':True,'Rawのopen/stat/hash':False,'金融再実行/価格CSV/11月09本文':False}
    check=plan['output'].with_name(plan['output'].stem+'_作成の確認.json')
    with check.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(proof,ensure_ascii=False,indent=2,default=S.BASE.serial)+'\n')
    return {'成功':True,'Reader要求':proof['Reader要求'],'作成の確認':{'path':str(check),'sha256':S.digest(check)}}


def main() -> None:
    """
    機能: Root別固定builder要求以外ではNative本文を読まない。
    引数: CLI request/output(Path)、sha(str)、metadata-only(bool)。返り値: None。
    """
    p=argparse.ArgumentParser();p.add_argument('--request',type=Path,required=True);p.add_argument('--sha',required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--metadata-only',action='store_true');a=p.parse_args();plan=prepare(a.request,a.sha,a.output)
    if a.metadata_only:print(json.dumps({'成功':True,'Native/Raw本文読取':False,'場数':len(plan['tasks'])},ensure_ascii=False));return
    print(json.dumps(run(plan,{'path':str(a.request.resolve()),'sha256':a.sha}),ensure_ascii=False))


if __name__=='__main__':main()
