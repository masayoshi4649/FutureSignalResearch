"""Reader要求builderの人工と未読範囲をRootレビュー後の新停止へ結ぶ。"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import json
import os
import subprocess
import sys

import 要求を作る as B
from 固定参照 import STOP,CONSUMER_STOP,CONSUMER_SHA

HERE=Path(__file__).resolve().parent


def write(path: Path,value: dict) -> dict:
    """
    機能: 小証拠を新規保存しFileRefを返す。
    引数: path(Path)、value(dict)。返り値: dictは絶対path/sha256。
    """
    with path.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2,default=B.S.BASE.serial)+'\n')
    return {'path':str(path.resolve()),'sha256':B.S.digest(path)}


def maps() -> tuple:
    """
    機能: 新builderと停止consumer/全旧固定依存/Readerを指紋認証する。
    引数: なし。返り値: tuple[dict,dict]は所有と依存。Native/Rawをコードとして読まない。
    """
    owned={str(p.resolve()):B.S.digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.suffix in ('.py','.md')};deps={str(CONSUMER_STOP):CONSUMER_SHA};B.A.equal(B.S.digest(CONSUMER_STOP),CONSUMER_SHA,'停止consumer同体')
    for field in ('所有ファイルSHA256','依存コードSHA256'):
        for filename,sha in STOP[field].items():B.A.need(Path(filename).suffix not in ('.gz','.csv','.jsonl'),'市場本文を固定コードへ入れない');B.A.equal(B.S.digest(Path(filename)),sha,'全再用停止同体');deps[filename]=sha
    return owned,dict(sorted(deps.items()))


def check(output: Path) -> dict:
    """
    機能: 6主人工と実小metadataを確認し、Native未許可templateと前後指紋を保存する。
    引数: output(Path)。返り値: dictは停止前確認Ref。正式停止は作らない。
    """
    B.A.need(output.is_absolute() and not output.exists(),'新規絶対確認先');owned,deps=maps();output.mkdir(parents=True);env={**os.environ,'PYTHONIOENCODING':'utf-8'};command=[sys.executable,'-m','unittest','-v','人工検査'];r=subprocess.run(command,cwd=HERE,env=env,capture_output=True,text=True,encoding='utf-8')
    if r.returncode!=0:raise ValueError('builder人工失敗\n'+r.stdout+'\n'+r.stderr)
    import 人工検査 as T
    q=T.fixture(output);q.pop('人工');q['fixed']=False;q['market_native_read_authorized']=False;q['builder_stop']={'path':str(HERE/'停止.json'),'sha256':'Rootが停止後に設定する'};template=write(output/'first2_作成要求ひな型.json',q)
    after_owned,after_deps=maps();B.A.equal(after_owned,owned,'builder所有前後同体');B.A.equal(after_deps,deps,'全旧停止依存前後同体')
    return write(output/'停止前の確認.json',{'試行':116,'成功':True,'停止':False,'市場前':True,'Rootレビュー前':True,'UTC':datetime.now(timezone.utc).isoformat(),'主人工':6,'所有ファイルSHA256':owned,'依存コードSHA256':deps,'所有SHA256前':owned,'所有SHA256後':after_owned,'依存SHA256前':deps,'依存SHA256後':after_deps,'前後不変':True,'未許可template':template,'実行ログ':{'command':command,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr},'生115Decisionから適格を独立再評価':True,'手製以外のNative本文読取':False,'Rawのopen/stat/hash':False,'金融再実行/価格CSV/11月09本文':False})


def stop(review: Path,sha: str) -> dict:
    """
    機能: Rootレビュー済み証拠と同体のbuilderを初回停止する。
    引数: review(Path)、sha(str)。返り値: dictは新停止Ref。
    """
    B.A.equal(B.S.digest(review),sha,'Rootレビュー対象SHA');proof=B.S.load(review);B.A.need(proof['成功'] and proof['市場前'] and proof['停止'] is False and proof['前後不変'],'同停止前証拠');owned,deps=maps();B.A.equal(owned,proof['所有ファイルSHA256'],'レビュー後所有不変');B.A.equal(deps,proof['依存コードSHA256'],'レビュー後全旧停止不変');target=HERE/'停止.json';B.A.need(not target.exists(),'builder停止は初回だけ')
    return write(target,{'試行':116,'成功':True,'停止':True,'市場前':True,'UTC':datetime.now(timezone.utc).isoformat(),'所有ファイルSHA256':owned,'依存コードSHA256':deps,'前後不変':True,'停止前確認':{'path':str(review.resolve()),'sha256':sha},'主人工':6,'consumer停止':{'path':str(CONSUMER_STOP),'sha256':CONSUMER_SHA},'実API':'要求を作る.py --request ABS --sha SHA --output NEWABS [--metadata-only]','Native実読取':'Root別固定の明示許可後のみ','Rawのopen/stat/hash':False,'金融再実行/価格CSV/11月09本文':False,'Reader出力は未固定/Raw未許可':True})


def main() -> None:
    """
    機能: 人工確認とRootレビュー後停止を分離する。
    引数: CLI check-output(Path)又はstop(bool)/review(Path)/review-sha(str)。返り値: None。
    """
    p=argparse.ArgumentParser();p.add_argument('--check-output',type=Path);p.add_argument('--stop',action='store_true');p.add_argument('--review',type=Path);p.add_argument('--review-sha');a=p.parse_args()
    if a.stop:B.A.need(a.check_output is None and a.review is not None and a.review_sha,'Rootレビュー指定が必要');value=stop(a.review,a.review_sha)
    else:B.A.need(a.check_output is not None and a.review is None and a.review_sha is None,'新規停止前確認先だけ指定');value=check(a.check_output)
    print(json.dumps(value,ensure_ascii=False))


if __name__=='__main__':main()
