"""生115票/実窓/実小metadataを確認し、Rawへのopen/stat/hashを行わない人工。"""
from copy import deepcopy
from pathlib import Path
from unittest.mock import patch
import gzip
import hashlib
import json
import tempfile
import unittest

import 要求を作る as B

HERE=Path(__file__).resolve().parent
CORE=B.ROOT/'work/116保有根拠の連続比較/人工_失効と所有/Core失効人工.json.gz'
CORE_SHA='d93abd1795f3fac86fa099b0d2608207e946922ed8fcb3120b29f72826cb960b'


def quality(rows: int) -> dict:
    """
    機能: 手製Source品質だけを作る。
    引数: rows(int)。返り値: dictは明示人工値。
    """
    return {'lines':rows,'clock_missing':0,'outside':0,'backward':0,'bad_last':0,'bad_quote':0,'accepted':rows,'contracts':['人工限月']}


def write(path: Path,value: dict) -> dict:
    """
    機能: 小人工metadataを一時先へ保存する。
    引数: path(Path)、value(dict)。返り値: dictは絶対path/sha256。
    """
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,default=B.S.BASE.serial)+'\n',encoding='utf-8');return {'path':str(path.resolve()),'sha256':B.S.digest(path)}


def fixture(folder: Path) -> dict:
    """
    機能: Rootの実first2小metadataをそのまま使い、builder要求だけを人工化する。
    引数: folder(Path)。返り値: dictはNative未読の要求。
    """
    root=B.ROOT
    ref=lambda p,s:{'path':str(root/p),'sha256':s}
    q={'人工':True,'version':1,'trial':116,'fixed':True,'market_native_read_authorized':True,'raw_read_authorized':False,'holdout_read_authorized':False,'stage':'first2',
       'condition':ref('work/116進行/F1_116金融条件.json',B.F1_SHA),'completion':ref('work/116金融F1/先頭2場/完了.json','4d221b6c3a84f403c027baf6d25cd7eceb307218c48e82c334341f7cf982d52b'),
       'independent_result':ref('work/116独立保存F1/先頭2場/結果.json','5b028964e5f6ea81603b97f6c699d6268017503c0ab07b332ac842a00bed9258'),'independent_check':ref('work/116独立保存F1/先頭2場/保存会計の確認.json','8e0ec039f9d7bf940a7c17a5c6b429309acf2ec2b864548d694d8d58ea04a594'),
       'save_request':ref('work/116進行/first2_独立保存要求_未読件数補正.json','234d1decd9f80754cbe78b728990e5ab556a26cc32263c540752d63cc195c0c2'),
       'manifest':ref('study/00106_収束失速で保護の起動と幅を切り替える/入力台帳_70場.json','902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8'),
       'consumer_stop':{'path':str(B.CONSUMER_STOP),'sha256':B.CONSUMER_SHA},'reader_stop':{'path':str(B.G.READER),'sha256':B.G.READER_SHA}}
    q['builder_stop']=write(folder/'builder停止の人工.json',{'人工':True,'成功':True,'停止':True,'市場前':True,'試行':116,'所有ファイルSHA256':{str(Path(B.__file__).resolve()):B.S.digest(Path(B.__file__))},'依存コードSHA256':{}})
    return q


class Tests(unittest.TestCase):
    """人工のみの窓・schema・Root許可を確認する。"""

    @classmethod
    def setUpClass(cls):
        """
        機能: 明示Core人工だけを一回読む。
        引数: cls(type)。返り値: None。自然NativeとRawは未読。
        """
        data=CORE.read_bytes();B.A.equal(hashlib.sha256(data).hexdigest(),CORE_SHA,'Core人工SHA');value=json.loads(gzip.decompress(data),parse_float=B.A.BASE.Decimal);B.A.need(value['人工'] and not value['市場'],'手製だけ');cls.native=next(iter(value['results'].values()))

    def material(self,folder: Path) -> tuple:
        """
        機能: 実Core手製のSource品質と不存在のRaw台帳を用意する。
        引数: self(Tests)、folder(Path)。返り値: tuple[dict,dict,dict]はNative/manifest/case。
        """
        native=deepcopy(self.native);native['source']['quality']={'NK225':quality(native['actual']['counts']['rows'])};case={'id':native['source']['session']['id'],'contract':'人工限月','files':{'NK225_book':{'path':'存在しない/原板.jsonl.gz','sha256':'1'*64,'size':123}}};manifest={'source_root':str(folder/'Rawを開かない'),'sessions':[case]};return native,manifest,case

    def test_raw_never_open_stat_or_hash_and_eligible_union(self):
        """
        機能: Raw不存在でも24適格実玉を一窓へ結び、open/statを使用しない。
        引数: self(Tests)。返り値: None。
        """
        with tempfile.TemporaryDirectory(dir=HERE) as tmp:
            n,m,c=self.material(Path(tmp));original=deepcopy(n)
            with patch.object(Path,'open',side_effect=AssertionError('Raw open不可')),patch.object(Path,'stat',side_effect=AssertionError('Raw stat不可')):scene,counts=B.scene_from_native(n,m,c)
            self.assertEqual(counts['適格実玉'],24);self.assertEqual(len(scene['windows']),1);self.assertEqual(scene['windows'][0]['window_id'],'W00001');self.assertEqual(scene['cutoff'],0);self.assertEqual(scene['expected_source_rows'],n['actual']['counts']['rows']);self.assertEqual(scene['raw_bytes'],123);self.assertEqual(n,original)

    def test_empty_actual_windows_ignore_virtual_source(self):
        """
        機能: Source仮想玉の情報があっても実監視玉0なら空窓とする。
        引数: self(Tests)。返り値: None。
        """
        with tempfile.TemporaryDirectory(dir=HERE) as tmp:
            n,m,c=self.material(Path(tmp));n['source']['books']={'虚玉':{'entry':0,'exit':9999999}}
            for b in n['actual']['books'].values():b['positions']=[]
            scene,count=B.scene_from_native(n,m,c);self.assertEqual(scene['windows'],[]);self.assertEqual(count['適格実玉'],0);self.assertIn('expected_source_quality',scene)

    def test_overlapping_adjacent_window_merge(self):
        """
        機能: 同Index・重複・隣接は結合し、離れた窓は分ける。
        引数: self(Tests)。返り値: None。
        """
        q=lambda i:{'index':i,'source_line':i+10}
        rows=[{'start_quote':q(a),'end_quote':q(b)} for a,b in ((2,5),(4,7),(2,5),(8,9),(12,13))]
        self.assertEqual([(a['index'],b['index']) for a,b in B.normalized_windows(rows)],[(2,9),(12,13)])

    def test_frozen_vote_and_ownership_corruptions(self):
        """
        機能: 申告適格だけを信頼せず、生票/実量/取得原行/契約/終了の改変を拒否する。
        引数: self(Tests)。返り値: None。
        """
        for field in ('eligibility','vote','quantity','fill_stamp','contract','end','same_index'):
            with tempfile.TemporaryDirectory(dir=HERE) as tmp:
                n,m,c=self.material(Path(tmp));b=n['actual']['books']['T_XC_C0_D0'];p=b['positions'][0];entry=p['lifecycle116']['initial']['entry']
                if field=='eligibility':p['lifecycle116']['initial']['monitoring_eligible']=False
                elif field=='vote':entry['birth']['values']['d15']+=1
                elif field=='quantity':next(r for r in b['entry_gate']['records'] if r['actual_position_id']==p['id'])['actual_quantity']+=1
                elif field=='fill_stamp':entry['fill_stamp']['source_line']+=1
                elif field=='contract':c['contract']='別限月'
                elif field=='end':p['closed_quote']['index']=p['entry_quote']['index']-1
                else:p['closed_quote']['last']+=1
                with self.subTest(field=field),self.assertRaises(ValueError):B.scene_from_native(n,m,c)

    def test_real_metadata_positive_native_unread(self):
        """
        機能: 実Root小metadataと実source_root台帳でGateを通し、Native/Rawを開かない。
        引数: self(Tests)。返り値: None。
        """
        with tempfile.TemporaryDirectory(dir=HERE) as tmp:
            folder=Path(tmp);q=fixture(folder);ref=write(folder/'builder要求の人工.json',q);plan=B.prepare(Path(ref['path']),ref['sha256'],folder/'未生成Reader要求.json');self.assertEqual(len(plan['tasks']),2);self.assertIn('source_root',plan['manifest']);self.assertIn('NK225_book',plan['cases']['2026-09-21_Day']['files']);self.assertFalse(plan['output'].exists())

    def test_root_authorization_and_upstream_binding(self):
        """
        機能: 未固定/未許可/Raw許可/holdout/別stage/別上流SHAを本文前に拒否する。
        引数: self(Tests)。返り値: None。
        """
        for field in ('fixed','native','raw','holdout','stage','condition','manifest','completion'):
            with tempfile.TemporaryDirectory(dir=HERE) as tmp:
                folder=Path(tmp);q=fixture(folder)
                if field=='fixed':q['fixed']=False
                elif field=='native':q['market_native_read_authorized']=False
                elif field=='raw':q['raw_read_authorized']=True
                elif field=='holdout':q['holdout_read_authorized']=True
                elif field=='stage':q['stage']='2026-11-09'
                else:q[field]['sha256']='0'*64
                ref=write(folder/'builder要求の人工.json',q)
                with self.subTest(field=field),self.assertRaises(ValueError):B.prepare(Path(ref['path']),ref['sha256'],folder/'未生成Reader要求.json')


if __name__=='__main__':unittest.main(verbosity=2)
