# 原板を開かずReader要求を作る

116の同F1（4c76a5f7…）金融完了、397ee…新型独立保存の結果/確認/実Root保存要求、固定入力台帳、Reader停止82806…、consumer停止1afecc…を結ぶ。既停止の金融/入口/P100/life/Reader/consumerは変更しない。**このbuilderが読む市場本文は、Rootの新しい固定要求で明示解禁されたNativeだけ**。Raw・価格CSV・11月09・金融再実行は対象外。

`manifest.source_root` と `manifest.sessions[]` を使う。各caseの `files.NK225_book.path/sha256/size` を保持し、Raw pathは `source_root + path` の文字列正規化だけで作る。Rawのopen/stat/hash/resolveは行わない。cutoff省略は0。

各実XC/XQ Positionを、実取得に結び付くentry_gate recordの生115Decisionへ結合する。停止済み独立式で全票を再評価し、Common真・D15>0・既知G30非0・境界既知から適格を再計算する。申告monitoring_eligibleだけを信頼せず、Source仮想玉は窓に使わない。適格な実entry_quote〜closed_quoteの両端inclusiveを取得し、同Index・重複・隣接をmerge、昇順にW00001から固定IDを付ける。Source.session start/end、Source.contract、Source.quality['NK225']、Actual.counts.rowsをそのままSceneへ使う。適格0は空窓とし、Raw全fileのIndex/品質を省略する意味にしない。

## Root作成要求のschema

未許可ひな型は停止前確認先の `first2_作成要求ひな型.json` に保存する。`version=1,trial=116,stage=first2/full70`。必要Refは次の通り。

- `builder_stop`：この新builderの市場前停止。
- `condition/completion`：同116F1金融条件・同stage全成功。
- `independent_result/independent_check/save_request`：同金融成功の新型保存3参照。
- `manifest`：金融条件の実入力台帳。
- `reader_stop/consumer_stop`：停止済みReaderとRawconsumer。

Rootが小metadataと対象を確認し、`fixed=true,market_native_read_authorized=true` の新要求へ固定する。`raw_read_authorized=false,holdout_read_authorized=false` は保持する。

```powershell
python .\要求を作る.py --request <Root新作成要求の絶対JSON> --sha <SHA> --output <新規Reader要求の絶対JSON> --metadata-only
python .\要求を作る.py --request <同要求> --sha <同SHA> --output <同じ未生成JSON>
```

metadata-onlyはNativeとRawの実物SHA/本文へ触れない。実行後にReader要求と `_作成の確認.json` を保存し、全Native/小metadata/停止の前後SHAを確認する。

出力のGoReader要求も **fixed=false,raw_read_authorized=false**。Rootが全Scene・空窓・原板参照・上流Refをレビューし、最終のReader固定へ別保存する。その後、停止consumerの `要求ひな型を作る.py` へ渡す。要求の作成と原板の実走査を同じ許可にしない。

## 人工と停止

手製Core正例から24適格玉の一窓化、実玉0とSource虚玉の分離、重複/隣接merge、申告適格/生票/実量/取得原行/契約/終端破壊、Raw不存在でopen/stat禁止、実Root小metadata/source_root正例、未許可・上流差拒否を確認する。

`検査して停止する.py --check-output <新規絶対folder>` は人工と未許可templateを保存する。Rootレビュー後だけ `--stop --review <確認JSON> --review-sha <SHA>` を実行する。既存停止は上書きしない。
