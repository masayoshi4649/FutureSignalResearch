"""停止済みRawconsumerの純粋な参照と窓正規化だけを指紋認証して再用する。"""
from pathlib import Path
import hashlib
import importlib
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
CONSUMER=ROOT/'work/116原行から失効最初性を独立検算する'
CONSUMER_STOP=CONSUMER/'停止.json'
CONSUMER_SHA='1afecc2a6a86c0702201fcd3c300ca4f0d8c2c914b08673fd5f038ad8a7ceb56'
if hashlib.sha256(CONSUMER_STOP.read_bytes()).hexdigest()!=CONSUMER_SHA:raise ValueError('Rawconsumer停止SHA差')
STOP=json.loads(CONSUMER_STOP.read_text(encoding='utf-8'))
for filename,sha in STOP['所有ファイルSHA256'].items():
    if hashlib.sha256(Path(filename).read_bytes()).hexdigest()!=sha:raise ValueError('停止consumer所有差')
sys.path.insert(0,str(CONSUMER))
try:
    D=importlib.import_module('独立参照');C=importlib.import_module('検算する');G=importlib.import_module('実行の入力ゲート')
finally:sys.path.pop(0)
A,S,I=D.A,D.S,D.I
normalized_windows=C.normalized_windows
