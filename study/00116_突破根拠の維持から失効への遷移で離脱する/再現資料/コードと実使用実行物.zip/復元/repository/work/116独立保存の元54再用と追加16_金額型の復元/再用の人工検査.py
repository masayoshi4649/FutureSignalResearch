"""元54再用の認証・DD再結合・追加16限定呼出を手製資料だけで検査する。"""
from copy import deepcopy
from decimal import Decimal
import gzip
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import 再用して保存する as M


def toy_row(sid: str, key: str, number: int) -> dict:
    """機能: S.combineの入力型を満たす手計算の場別行を作る。

    引数: sid/key(str)、number(int)は場・口座・実現額の人工値。
    返り値: dictは自然金融と無関係の統計入力。
    """
    active = int(number != 0)
    return {'session': sid, 'key': key, 'history_class': 'original54' if sid[:10] <= '2026-10-27' else 'additional16',
        'net_yen': Decimal(number), 'positive_yen': Decimal(max(0, number)), 'negative_yen': Decimal(min(0, number)),
        'positions': active, 'positive_positions': int(number > 0), 'negative_positions': int(number < 0), 'zero_positions': 0,
        'open_buy': 0, 'open_sell': 0, 'pending_buy': 0, 'pending_sell': 0,
        '場内時価DD': Decimal(20 if number > 0 else -number + 10 if number < 0 else 0),
        '保存最大時価': Decimal(number + 20 if number > 0 else 0), '保存最小時価': Decimal(-10 if number > 0 else number - 10 if number < 0 else 0),
        '売買別': {'1': {'玉': active, '枚': active, '純額': Decimal(number)}},
        '注文別': {'Source': {'要求': active, '要求枚': active, '約定': active, '約定枚': active, '返済片純額': Decimal(number)}},
        '頻度診断': {'source_rows': 10, 'held_seconds': Decimal(active)},
        '入口票検査': {'counts': {'source_new': active, 'allowed': active, 'selected_unknown': 0}},
        '保有根拠の独立検査': {'counts': {'life_points': active, 'requests': 0}}}


# ----------------------------------------
class Fixture:
    """Native54は意図的な非gzip bytesとし、再用で展開していないことも検出する器具。"""

    def __init__(self, root: Path):
        """機能: 54場×36行と1944の小Viewer、追加16用の最小JSONを作る。

        引数: root(Path)は一時folder。
        返り値: None。全て手製で市場・FAR自然生成を主張しない。
        """
        self.root = root
        self.base_dir = root / '元54'
        self.native_dir = root / 'Native'
        self.legacy_dir = root / '旧115'
        for folder in (self.base_dir, self.native_dir, self.legacy_dir):
            folder.mkdir()
        self.before = {}
        self.sessions = M.G.planned_sessions('full70')
        self.definition = {'version': 116, 'policies': ['X0', 'XC', 'XQ'], 'toy': True}
        self.condition_ref = self.write(root / '金融条件.json', {'toy': 'condition'})
        self.base_complete = self.write(root / '元54金融完了.json', {'toy': 'base54'})
        self.full_complete = self.write(root / '全70金融完了.json', {'toy': 'full70'})
        self.common = {name: self.write(root / (name + '.json'), {'toy': name}) for name in ('P_stop', 'life_stop', 'actor_stop', 'lifecycle_go_stop', 'entry115_stop', 'protection_code', 'lifecycle_code', 'entry_code')}
        self.common.update(condition=self.condition_ref, code_stop={'path': str(M.PRIOR_STOP), 'sha256': M.PRIOR_SHA})
        self.tasks = []
        for i, sid in enumerate(self.sessions):
            legacy_body = b'handcrafted legacy identity; no JSON parse for reused54' if i < 54 else gzip.compress(b'{"toy":"legacy"}', mtime=0)
            legacy = self.bytes(self.legacy_dir / (sid + '.Native.json.gz'), legacy_body)
            body = {'actual': {'scope': {'session': {'id': sid}}, 'lifecycle_definition': self.definition,
                              'books': {key: {'toy_key': key} for key in M.S.KEYS}},
                    'reference115': {'reference': legacy, 'before_sha256': legacy['sha256'], 'after_sha256': legacy['sha256']}}
            raw = b'handcrafted identity; must not gzip-decode reused54' if i < 54 else gzip.compress(json.dumps(body).encode(), mtime=0)
            native = self.bytes(self.native_dir / (sid + '.Native.json.gz'), raw)
            self.tasks.append({'session': sid, 'native': native, 'reference115': legacy,
                              'history_class': 'original54' if i < 54 else 'additional16', 'market_path': str(root / '未読の価格.csv')})
        self.base_q = {**self.common, 'stage': 'base54', 'completion': self.base_complete}
        self.full_q = {**self.common, 'stage': 'full70', 'completion': self.full_complete}
        self.base_request = self.write(root / '元54要求.json', self.base_q)
        self.full_request = self.write(root / '全70要求.json', self.full_q)
        rows = [toy_row(sid, key, 100 if i == 0 and key == M.S.KEYS[0] else -50 if i == 1 and key == M.S.KEYS[0] else 0)
                for i, sid in enumerate(self.sessions[:54]) for key in M.S.KEYS]
        summary, entry, life = M.aggregate(rows)
        source = [{'session': sid, '全36の元通知同体': True} for sid in self.sessions[:54]]
        references = [{'session': sid, 'comparisons': 12, 'all_financial_equal': True, 'source_equal': True} for sid in self.sessions[:54]]
        native_refs = [{'session': t['session'], **t['native'], 'reference115': t['reference115']} for t in self.tasks[:54]]
        viewer = [{'session': sid, '資源': 36, '全残0': True, '約定行': 0} for sid in self.sessions[:54]]
        resources, self.output_sha = [], {}
        for sid in self.sessions[:54]:
            for key in M.S.KEYS:
                name = f'116_{key}_{sid}.trades.jsonl'
                ref = self.bytes(self.base_dir / name, b'')
                self.output_sha[name] = ref['sha256']
                resources.append({'id': name.removesuffix('.trades.jsonl'), 'title': '人工', 'symbol': 'NK225', 'product': 'NK225mini',
                    'session': sid, 'method_id': key, 'point_value': 100, 'pnl_format': 'trades', 'pnl_basis': 'net', 'pnl_path': name, 'market_path': str(root / '未読の価格.csv')})
        catalog = self.write(self.base_dir / '一覧.resources.json', {'schema_version': 1, 'path_base': 'catalog', 'resources': resources})
        self.output_sha['一覧.resources.json'] = catalog['sha256']
        prior_inputs = {str(Path(t[field]['path'])): t[field]['sha256'] for t in self.tasks[:54] for field in ('native', 'reference115')}
        proofs = {'試行': 116, '成功': True, 'stage': 'base54', '場数': 54, '会計数': 1944, '前後不変': True,
            '金融条件SHA256': self.condition_ref['sha256'], '金融完了SHA256': self.base_complete['sha256'], 'Root保存要求SHA256': self.base_request['sha256'],
            '保存器停止SHA256': M.PRIOR_SHA, '独立P停止SHA256': self.common['P_stop']['sha256'], '独立ライフ停止SHA256': self.common['life_stop']['sha256'],
            'Actor停止SHA256': self.common['actor_stop']['sha256'], '純ライフ停止SHA256': self.common['lifecycle_go_stop']['sha256'],
            '入口115独立停止SHA256': self.common['entry115_stop']['sha256'], '入力codeSHA256前': prior_inputs, '入力codeSHA256後': prior_inputs}
        self.result = {**proofs, '主key': list(M.S.KEYS), 'Actor設定': {k: {'candidate': k, 'entry_timing': '元Source連続時計', **c} for k, c in M.S.BY_KEY.items()},
            '保有根拠定義': self.definition, '場別': rows, '集計': summary, '入口票集計': entry, '保有根拠検査集計': life,
            '元Source対照': source, '旧115対照': references, 'Native参照': native_refs, 'Viewer保存再読': viewer, '限界': ['手製人工'],
            '全Rawライフ発生漏れ/初回性監査': False, '保護定義': {'toy': True}}
        self.check = {**proofs, '全Source111同体': True, '全残玉予約0': True, '不一致数': 0, 'X0全金融比較': 648, '旧115全金融比較': 648, '資源': 1944}
        self.refresh()

    def bytes(self, path: Path, body: bytes) -> dict:
        """機能: 手製bytesを一時位置へ保存する。

        引数: path(Path)、body(bytes)。
        返り値: dictは絶対FileRef。
        """
        path.write_bytes(body)
        return {'path': str(path), 'sha256': hashlib.sha256(body).hexdigest()}

    def write(self, path: Path, value: dict) -> dict:
        """機能: 手製のDecimalを含むJSONを保存する。

        引数: path(Path)、value(dict)。
        返り値: dictは絶対FileRef。
        """
        return self.bytes(path, (json.dumps(value, ensure_ascii=False, default=M.S.BASE.serial) + '\n').encode('utf-8'))

    def refresh(self) -> None:
        """機能: 意図的破壊を含む結果/検算を新期待SHAへ結び直す。

        引数: なし。
        返り値: None。単なるSHA不一致だけでない意味ゲートを試験する。
        """
        result_ref = self.write(self.base_dir / '結果.json', self.result)
        self.output_sha['結果.json'] = result_ref['sha256']
        self.check['出力SHA256'] = deepcopy(self.output_sha)
        check_ref = self.write(self.base_dir / '保存会計の確認.json', self.check)
        self.base_refs = {'request': self.base_request, 'result': result_ref, 'check': check_ref}

    def plan(self) -> dict:
        """機能: 既G認証済みの形を表す手製外側計画を返す。

        引数: なし。
        返り値: dictはNativeではない人工の計画。
        """
        full = {'tasks': self.tasks, 'request': self.full_q, 'definition': self.definition, 'condition': {'actual_configurations': list(M.S.A.CONFIGS)}}
        base = {'tasks': self.tasks[:54], 'request': self.base_q, 'definition': self.definition, 'condition': {'actual_configurations': list(M.S.A.CONFIGS)}}
        return {'before': {}, 'base_refs': self.base_refs, 'base': base, 'full': full, 'output': self.root / '新しい全70',
            'request': {'runner_stop': {'sha256': 'f' * 64}, 'full_request': self.full_request}, 'root_ref': {'sha256': 'e' * 64}}


# ----------------------------------------
class ReuseTests(unittest.TestCase):
    """新しい再用境界だけを検査し、旧P/金融人工の再実行とは称さない。"""

    def setUp(self) -> None:
        """機能: 各主人工へ独立した一時資料を与える。

        引数: なし。返り値: None。
        """
        self.temp = tempfile.TemporaryDirectory()
        self.fixture = Fixture(Path(self.temp.name))

    def tearDown(self) -> None:
        """機能: 自己一時資料だけを片付ける。

        引数: なし。返り値: None。
        """
        self.temp.cleanup()

    def test_01_authenticate54_without_decode(self):
        """機能: 非gzipの手製Native54を展開せず指紋だけで認証する。

        引数: なし。返り値: None。
        """
        plan = self.fixture.plan()
        saved = M.authenticate_base(plan)
        self.assertEqual(len(saved['result']['場別']), 1944)
        self.assertTrue(all(t[field]['path'] in plan['before'] for t in plan['base']['tasks'] for field in ('native', 'reference115')))

    def test_02_metadata_meaning_corruptions(self):
        """機能: SHAを合わせても停止/条件/全残0/宣言/行/集計/Sourceの破壊を拒否する。

        引数: なし。返り値: None。
        """
        original_result, original_check = deepcopy(self.fixture.result), deepcopy(self.fixture.check)
        for kind in ('condition', 'stop', 'flat', 'config', 'row', 'summary', 'source', 'reference', 'native_ref'):
            self.fixture.result, self.fixture.check = deepcopy(original_result), deepcopy(original_check)
            r, c = self.fixture.result, self.fixture.check
            if kind == 'condition': r['金融条件SHA256'] = '0' * 64
            elif kind == 'stop': r['保存器停止SHA256'] = '0' * 64
            elif kind == 'flat': c['全残玉予約0'] = False
            elif kind == 'config': r['Actor設定'][M.S.KEYS[0]]['life_mode'] = 'XC'
            elif kind == 'row': r['場別'][1] = deepcopy(r['場別'][0])
            elif kind == 'summary': r['集計'][M.S.KEYS[0]]['net_yen'] += 1
            elif kind == 'source': r['元Source対照'][0]['全36の元通知同体'] = False
            elif kind == 'reference': r['旧115対照'][0]['comparisons'] = 4
            elif kind == 'native_ref': r['Native参照'][0]['path'] = r['Native参照'][1]['path']
            self.fixture.refresh()
            with self.subTest(kind=kind), self.assertRaises((ValueError, AssertionError)):
                M.authenticate_base(self.fixture.plan())

    def test_03_reused_native_mutation(self):
        """機能: 元54Nativeの保存成功後bytes変化を拒否する。

        引数: なし。返り値: None。
        """
        path = Path(self.fixture.tasks[10]['native']['path'])
        path.write_bytes(path.read_bytes() + b'changed')
        with self.assertRaises((ValueError, AssertionError)):
            M.authenticate_base(self.fixture.plan())

    def test_04_relink_without_copy(self):
        """機能: 1944Viewerを同じファイルへ相対参照し価格を開かない。

        引数: なし。返り値: None。
        """
        plan = self.fixture.plan()
        saved = M.authenticate_base(plan)
        original_resolve = Path.resolve
        def guarded_resolve(path, *args, **kwargs):
            """機能: 人工価格参照へのresolve呼出を禁止して文字列処理を確認する。

            引数: path(Path)、args/kwargs(tuple/dict)は対象と元API引数。
            返り値: Pathは価格以外の元resolve結果。価格ならAssertionError。
            """
            if path.name.endswith('.csv'):
                raise AssertionError('価格参照へresolve/属性照会を行った')
            return original_resolve(path, *args, **kwargs)
        with patch.object(Path, 'resolve', guarded_resolve):
            resources, fingerprints = M.relink_viewer(plan, saved)
        self.assertEqual(len(resources), len(fingerprints))
        self.assertEqual(len(resources), 1944)
        self.assertFalse(plan['output'].exists())
        for row in resources:
            self.assertIn(str((plan['output'] / row['pnl_path']).resolve()), fingerprints)
        self.assertFalse((self.fixture.root / '未読の価格.csv').exists())

    def test_05_viewer_and_market_corruptions(self):
        """機能: Viewer実bytesと価格参照の解釈違いを継承しない。

        引数: なし。返り値: None。
        """
        plan = self.fixture.plan()
        saved = M.authenticate_base(plan)
        plan['full']['tasks'][0]['market_path'] = str(self.fixture.root / '別価格.csv')
        with self.assertRaises((ValueError, AssertionError)):
            M.relink_viewer(plan, saved)
        self.fixture.tasks[0]['market_path'] = str(self.fixture.root / '未読の価格.csv')
        trade = self.fixture.base_dir / ('116_' + M.S.KEYS[0] + '_' + self.fixture.sessions[0] + '.trades.jsonl')
        trade.write_bytes(b'changed')
        with self.assertRaises((ValueError, AssertionError)):
            M.relink_viewer(self.fixture.plan(), saved)

    def test_06_dd_counter_and_zero_groups(self):
        """機能: 元54と新16をつなぐDD105/純額25と全0群を手計算照合する。

        引数: なし。返り値: None。
        """
        rows = deepcopy(self.fixture.result['場別'])
        rows += [toy_row(sid, key, -25 if i == 0 and key == M.S.KEYS[0] else 0) for i, sid in enumerate(self.fixture.sessions[54:]) for key in M.S.KEYS]
        summary, entry, life = M.aggregate(rows)
        one = summary[M.S.KEYS[0]]
        self.assertEqual(one['net_yen'], 25)
        self.assertEqual(one['保存点連結時価DD'], 105)
        self.assertEqual(one['場数'], 70)
        self.assertEqual(one['positions'], 3)
        self.assertEqual(entry[M.S.KEYS[0]]['source_new'], 3)
        self.assertEqual(life[M.S.KEYS[0]]['life_points'], 3)
        self.assertEqual(summary[M.S.KEYS[1]]['positions'], 0)
        self.assertIsNone(summary[M.S.KEYS[1]]['PF'])

    def test_07_only_new16_api_calls(self):
        """機能: 追加16だけに同inspect/保存/再読APIを呼び全70互換結果を作る。

        引数: なし。返り値: None。金融/P演算の代替試験ではなく外側委譲の人工。
        """
        plan = self.fixture.plan()
        calls = []
        def inspect(native, prior, protection, entry, lifecycle):
            """機能: 追加16の呼出場と同一P/E/Lを記録する。

            引数: native/prior(dict)、protection/entry/lifecycle(module)。
            返り値: dictは外側委譲検査専用の手製戻し。
            """
            sid = native['actual']['scope']['session']['id']
            calls.append(sid)
            self.assertIs(protection, M.P)
            self.assertIs(entry, M.E)
            self.assertIs(lifecycle, M.L)
            return {'checked': {k: {'key': k, 'sid': sid} for k in M.S.KEYS}, 'entry': {k: {'counts': {'source_new': 0}} for k in M.S.KEYS},
                    'source': {'全36の元通知同体': True}, 'reference115': {'comparisons': 12, 'all_financial_equal': True, 'source_equal': True}}
        def summarize(book, checked):
            """機能: 金融演算の代わりに外側統合用の手製行を返す。

            引数: book/checked(dict)。返り値: dictは全0取引行。
            """
            row = toy_row(checked['sid'], checked['key'], 0)
            row['保有根拠の独立検査'] = {'counts': {'life_points': 0}}
            return row
        def save(native, out, market):
            """機能: 外側のファイル本数検査用に新16の空約定を保存する。

            引数: native(dict)、out(Path)、market(str)。
            返り値: list[dict]は手製資源。
            """
            sid = native['actual']['scope']['session']['id']
            resources = []
            for key in M.S.KEYS:
                name = f'116_{key}_{sid}.trades.jsonl'
                (out / name).write_bytes(b'')
                resources.append({'id': name.removesuffix('.trades.jsonl'), 'session': sid, 'method_id': key, 'pnl_path': name, 'market_path': market})
            return resources
        with patch.object(M.S, 'inspect_scene', side_effect=inspect), patch.object(M.S, 'summarize_book', side_effect=summarize), patch.object(M.S, 'save_viewer', side_effect=save), patch.object(M.S, 'verify_viewer', return_value={'資源': 36, '全残0': True, '約定行': 0}):
            result = M.run(plan)
        self.assertEqual(calls, self.fixture.sessions[54:])
        self.assertEqual(result['独立再用場数'], 54)
        self.assertEqual(result['独立新規検算場数'], 16)
        saved = M.S.load(plan['output'] / '結果.json')
        self.assertEqual(len(saved['場別']), 2520)
        self.assertFalse(saved['全70の金融Native再検算'])
        self.assertEqual(len(list(plan['output'].glob('*.trades.jsonl'))), 576)

    def test_08_false_root_permission_before_read(self):
        """機能: 未許可外側要求は上流/Nativeを読む前に拒否する。

        引数: なし。返り値: None。
        """
        ref = self.fixture.write(self.fixture.root / '未許可外側.json', {'version': 1, 'trial': 116, 'fixed': False})
        with patch.object(M.G, 'prepare', side_effect=AssertionError('上流へ進んだ')) as prepare:
            with self.assertRaises(ValueError):
                M.prepare(Path(ref['path']), ref['sha256'], self.fixture.root / '未許可出力')
            prepare.assert_not_called()

    def test_09_metadata_prepare_delegation(self):
        """機能: 通常2要求を既Gへ渡し保存結果/Nativeの本文へ進まないことを確認する。

        引数: なし。返り値: None。既G内部の再試験ではなく外側の結合だけを試験する。
        """
        trusted = self.fixture.plan()
        trusted['full']['before'] = {}
        trusted['base']['before'] = {}
        root = {'version': 1, 'trial': 116, 'fixed': True, 'saved54_reuse_authorized': True,
            'market_native_read_authorized': True, 'legacy115_read_authorized': True,
            'runner_stop': {'path': str(self.fixture.root / '仮停止.json'), 'sha256': 'f' * 64},
            'full_request': self.fixture.full_request, 'base54': self.fixture.base_refs}
        ref = self.fixture.write(self.fixture.root / '外側要求.json', root)
        self_stop = {'所有ファイルSHA256': {str(Path(M.__file__).resolve()): M.S.digest(Path(M.__file__))}}
        with patch.object(M.G, 'check_stop', return_value=self_stop), patch.object(M.G, 'prepare', side_effect=[trusted['full'], trusted['base']]) as delegated, patch.object(M.S, 'load', wraps=M.S.load) as loaded:
            plan = M.prepare(Path(ref['path']), ref['sha256'], self.fixture.root / '計画だけ')
        self.assertEqual(delegated.call_count, 2)
        self.assertEqual(loaded.call_count, 1)
        self.assertEqual(len(plan['full']['tasks']), 70)

    def test_10_prepared_reuse_must_match(self):
        """機能: G認証後でも元54の条件/停止/Native同path同SHAが違えば再用を拒否する。

        引数: なし。返り値: None。
        """
        for kind in ('condition', 'stop', 'native'):
            trusted = deepcopy(self.fixture.plan())
            trusted['base'] = deepcopy(trusted['base'])
            trusted['full']['before'] = {}
            trusted['base']['before'] = {}
            if kind == 'condition': trusted['full']['request']['condition']['sha256'] = '0' * 64
            elif kind == 'stop': trusted['full']['request']['P_stop']['sha256'] = '0' * 64
            else: trusted['full']['tasks'][0]['native']['sha256'] = '0' * 64
            root = {'version': 1, 'trial': 116, 'fixed': True, 'saved54_reuse_authorized': True,
                'market_native_read_authorized': True, 'legacy115_read_authorized': True,
                'runner_stop': {'path': str(self.fixture.root / '仮停止.json'), 'sha256': 'f' * 64},
                'full_request': self.fixture.full_request, 'base54': self.fixture.base_refs}
            ref = self.fixture.write(self.fixture.root / ('結合破壊' + kind + '.json'), root)
            self_stop = {'所有ファイルSHA256': {str(Path(M.__file__).resolve()): M.S.digest(Path(M.__file__))}}
            with patch.object(M.G, 'check_stop', return_value=self_stop), patch.object(M.G, 'prepare', side_effect=[trusted['full'], trusted['base']]), self.subTest(kind=kind), self.assertRaises(ValueError):
                M.prepare(Path(ref['path']), ref['sha256'], self.fixture.root / ('不一致計画' + kind))

    def test_11_saved_decimal_ratios(self):
        """機能: 循環小数の比率は既serial保存形へ戻して厳密照合する。

        引数: なし。返り値: None。許容誤差を導入せず1単位破壊は拒否する。
        """
        row = self.fixture.result['場別'][36]
        row['positions'], row['negative_positions'] = 3, 3
        summary, entry, life = M.aggregate(self.fixture.result['場別'])
        self.fixture.result.update(集計=summary, 入口票集計=entry, 保有根拠検査集計=life)
        self.fixture.refresh()
        saved = M.authenticate_base(self.fixture.plan())
        self.assertEqual(saved['result']['集計'][M.S.KEYS[0]]['average_loss_yen'], Decimal('-16.666666666666668'))
        self.fixture.result['集計'][M.S.KEYS[0]]['average_loss_yen'] += 1
        self.fixture.refresh()
        with self.assertRaises(ValueError):
            M.authenticate_base(self.fixture.plan())
        import 金額型を検証する as V
        self.assertTrue(V.representative()['1円破壊拒否'])


if __name__ == '__main__':
    unittest.main()
