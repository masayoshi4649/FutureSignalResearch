"""Root許可済みf5元54結果だけから、金額型復元による全36保存集計一致を確認する。"""
from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path

import 再用して保存する as M

SOURCE = M.ROOT / 'work/116独立保存F1/元54場/結果.json'
SOURCE_SHA = 'f5e3c4777dee3ef08030ef5f60f79edd5426699ffdfe02214fc3fc01735de501'
OLD_RUNNER = M.ROOT / 'work/116独立保存の元54再用と追加16'
OLD_STOP_SHA = 'b198faff20a19ba090c52609448b13f457ae920c93675c471be4ecdf3ed15459'
COPY_SHA = 'f01a2f916140acb078dbb892a4c9b068973364445cd3fec9032d88bf1cf417e1'


def check_derivation() -> dict:
    """機能: b198所有5の変更前同bytesコピーと旧停止の不変を認証する。

    引数: なし。
    返り値: dictは停止/原文の指紋。旧所有を変更しない。
    """
    stop_path = OLD_RUNNER / '停止.json'
    M.S.equal(M.S.digest(stop_path), OLD_STOP_SHA, '旧b198停止不変')
    record = M.S.load(stop_path)
    copy_path = Path(__file__).resolve().parent / '同bytesコピーの記録.json'
    M.S.equal(M.S.digest(copy_path), COPY_SHA, '変更前同bytesコピーの履歴')
    copied = M.S.load(copy_path)
    M.S.need(copied['全同bytes'] is True and copied['コピー数'] == 5, '旧所有5の同bytesコピー')
    for row in copied['files']:
        M.S.equal(M.S.digest(Path(row['元path'])), row['元SHA256'], '旧所有5の原文同体')
        M.S.equal(row['コピー時SHA256'], row['元SHA256'], 'コピー時同bytes')
    return {'元停止': {'path': str(stop_path), 'sha256': OLD_STOP_SHA}, '元所有': record['所有ファイルSHA256'],
            'コピー記録': {'path': str(copy_path), 'sha256': COPY_SHA}}


# ----------------------------------------
def representative() -> dict:
    """機能: 金額int化による中間double丸めを指定A0金額で再現し厳密型復元を確認する。

    引数: なし。
    返り値: dictは旧差・復元一致・1円破壊拒否の小証拠。値は手製指定反例。
    """
    row = {'session': '手製反例', 'positive_yen': 4485577, 'negative_yen': -2503712,
        'positive_positions': 212, 'negative_positions': 147, 'positions': 359, 'net_yen': 1981865,
        '場内時価DD': 0, '保存最大時価': 0, '保存最小時価': 0, '売買別': {}, '注文別': {}, '頻度診断': {}}
    before = repr(row)
    old = M.S.combine([row])
    fixed = M.S.combine(M.decimal_money_copy([row]))
    expected = Decimal('1.2422683459975987')
    M.S.equal(M.saved_form(fixed)['average_profit_loss_ratio'], expected, '指定A0の元Decimal経路へ復元')
    M.S.equal(M.saved_form(old)['average_profit_loss_ratio'], Decimal('1.2422683459975985'), '旧int除算の中間double差を再現')
    M.S.equal(repr(row), before, '元金額値/型を変更しない')
    wrong = deepcopy(row)
    wrong['positive_yen'] += 1
    rejected = False
    try:
        M.S.equal(M.saved_form(M.S.combine(M.decimal_money_copy([wrong]))), M.saved_form(fixed), '1円破壊')
    except ValueError:
        rejected = True
    M.S.need(rejected, '金額1円差を許容しない')
    return {'正益総額': 4485577, '損失総額': -2503712, '勝ち': 212, '負け': 147,
        '旧int経路の平均利益損失比': M.saved_form(old)['average_profit_loss_ratio'],
        'Decimal復元の平均利益損失比': M.saved_form(fixed)['average_profit_loss_ratio'],
        '保存代表値と一致': True, '元値/型不変': True, '1円破壊拒否': rejected}


# ----------------------------------------
def verify_metadata() -> dict:
    """機能: 許可された元54結果f5だけを読み全36集計/Counterを厳密照合する。

    引数: なし。
    返り値: dictは全36一致・元行不変の小証拠。Native/Viewer/価格を開かない。
    """
    derivation = check_derivation()
    M.S.equal(M.S.digest(SOURCE), SOURCE_SHA, 'Root許可f5結果だけを読む')
    result = M.S.load(SOURCE)
    M.S.need(result['試行'] == 116 and result['成功'] is True and result['stage'] == 'base54'
             and result['会計数'] == 1944 and result['場数'] == 54, '元54成功metadataの範囲')
    rows = result['場別']
    before = repr(rows)
    summary, entry, life = M.aggregate(rows)
    M.S.equal(set(summary), set(result['集計']), '元54全36 key')
    for key in M.S.KEYS:
        M.S.equal(M.saved_form(summary[key]), result['集計'][key], '全36保存集計同体/' + key)
        M.S.equal(M.saved_form(entry[key]), result['入口票集計'][key], '全36入口Counter同体/' + key)
        M.S.equal(M.saved_form(life[key]), result['保有根拠検査集計'][key], '全36lifeCounter同体/' + key)
    M.S.equal(repr(rows), before, '元54保存rowsの値/型を維持')
    M.S.equal(M.S.digest(SOURCE), SOURCE_SHA, '許可f5結果の実物前後同体')
    return {'試行': 116, '成功': True, 'Root許可結果': {'path': str(SOURCE), 'sha256': SOURCE_SHA},
        '場数': 54, '場別行数': 1944, '全36金融集計一致': True, '全36入口Counter一致': True,
        '全36lifeCounter一致': True, '保存元rows値/型不変': True, '代表反例': representative(),
        '派生の原文確認': derivation, 'Native/Raw/Viewer/CSV/11月09本文読取': 0,
        '金融条件/閾値/許容誤差/丸めの変更': False}


if __name__ == '__main__':
    print(json.dumps(verify_metadata(), ensure_ascii=False, default=M.S.BASE.serial))
