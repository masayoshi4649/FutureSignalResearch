# 116独立保存：元54成功の再用と追加16の検算

このフォルダは停止済みb198 runnerの所有5原文を変更前に同bytesコピーした新派生である。旧runnerとproofは不変。`同bytesコピーの記録.json` に元5ファイルと元停止を残す。変更は、集計用の独立コピーへ `positive_yen/negative_yen` の金額型を既会計のDecimalへ復元する処理と、その検査・案内である。

停止済み保存器 `work/116保有根拠の独立会計と保存_未読件数の型/会計停止.json`（397ee90a…）を変更しない。通常full70要求とbase54要求は既存 `G.prepare` へそのまま渡す。新しい外側Root要求は、元54の要求・独立結果・保存確認と、このrunner停止だけを追加する。

目的は**同条件の認証済み元54を再用し、追加16だけを同じ独立演算で検算**すること。全70のNativeを新たに意味再計算したとは記さない。54Nativeの圧縮bytesは現在SHAを認証するが、gzip展開・JSON解釈は行わない。Source/P100/入口/lifeの算術や閾値は一切変更しない。Raw・価格CSV・損益CSV・11/09を読まない。

## 再用条件

元54と全70の金融F1・保存397停止・独立P/life・Actor/pure/入口停止・実Python、全36宣言と定義が一致すること。金融full70は同F1のbase54 Nativeを同path同SHAで保持していること。条件が違えば再用を拒否し、通常全70再検算へ黙って切り替えない。

元54独立結果/保存確認はRootの絶対FileRefで先にSHA認証する。54場1944会計・648旧対照・Source全文同体・残玉予約0・不一致0・入力前後同体を認証する。1944場別行と全0取引群、実設定、元集計、入口/life Counter、全場証拠、全NativeRefを照合し、旧入力の現物SHAも認証する。Rootが指定した保存成功の継承であり、新しいSource/金融の再走ではない。

追加16だけは停止済みの同じ `S.inspect_scene(native,prior,P,E,L)`、`S.summarize_book`、`S.save_viewer/verify_viewer` を使う。全2520場別行から金融集計・保存点連結時価DDは既存 `S.combine`、入口/life件数は既存Counter式で再結合する。負の返済純額・ゼロ群・未定義比率を変更しない。

元集計の照合は既存 `BASE.serial` を通した同じJSON保存形式へ戻して厳密比較する。循環小数のPF・平均損失等を、保存前の高精度Decimalへ無条件に完全一致させて誤拒否しない。新しい許容誤差や金額の補正は加えない。

整数Decimalは既存serialでJSON整数へ保存される。その場別行を読み直すと正負金額がintとなり、同じS.combineでも平均利益/平均損失の `/` がfloatを経由し得る。このため **S.combine直前の作業用deepcopyだけ** の正負金額を `BASE.money` でDecimalへ厳密復元する。保存元の1944行の数値・型や出力場別行を上書きしない。P100/金融式・S.combine/profit_statistics・丸め・閾値・許容誤差を変更しない。

代表A0（正益4,485,577円、損失−2,503,712円、勝212/負147）は、int中間演算の平均損益比1.2422683459975985から、元Decimal経路の保存値1.2422683459975987へ戻る。Root許可済み元54結果f5e3c477…だけを使うmetadata確認で、全36金融集計/入口Counter/lifeCounterの一致、保存元行とファイルの不変、1円破壊拒否を別に記録する。Native/Viewer/価格をこの確認のために開かない。

## Viewer

元54の1944約定ファイルは保存成功と現在SHAを認証し、新catalogから同じファイルへの相対参照へ変換する。複写・約定意味再計算をしない。価格参照も旧catalog基準から新catalog基準へ正規化し、通常full70 Root要求が指す同じ価格位置へ復元できることを確認する。価格の存在確認・本文読取はしない。

価格参照は `abspath/normpath` の文字列操作だけで正規化・復元し、`Path.resolve()` による属性照会や最終path/symlink解決を行わない。約定ファイルの実物指紋認証に使うresolveは維持する。人工では価格CSV参照へのresolveを明示的に拒否する。

追加16の576約定ファイルだけを新規保存・再読する。全70catalogは2520資源を持つ。後段の正式保存器はcatalog相対参照を解決し、元54の参照再用SHAも保存証拠へ結ぶ必要がある。新出力folderに全2520ファイルがローカル複写されているとは仮定しない。

## 外側Root要求と実行

要求ひな型は `要求ひな型.json`。Rootが停止後に実Refで新要求を作り、以下を固定する。

```json
{
  "version": 1,
  "trial": 116,
  "fixed": true,
  "saved54_reuse_authorized": true,
  "market_native_read_authorized": true,
  "legacy115_read_authorized": true,
  "raw_read_authorized": false,
  "holdout_read_authorized": false,
  "runner_stop": {"path": "新runner停止の絶対位置", "sha256": "SHA"},
  "full_request": {"path": "通常full70 Root保存要求", "sha256": "SHA"},
  "base54": {
    "request": {"path": "成功元54のRoot保存要求", "sha256": "SHA"},
    "result": {"path": "成功元54の結果.json", "sha256": "SHA"},
    "check": {"path": "成功元54の保存会計の確認.json", "sha256": "SHA"}
  }
}
```

```powershell
python 再用して保存する.py --fixed <外側Root要求絶対path> --sha256 <SHA> --output <新規絶対folder> --metadata-only
python 再用して保存する.py --fixed <同要求> --sha256 <同SHA> --output <同じ未作成folder>
```

metadata-onlyは通常2要求と停止/小metadataの認証まで。Native・元54結果・Viewer本文へ進まない。元54の成功結果を読む処理と圧縮Nativeの指紋読取も実行段階だけで行う。既存出力先を使わない。失敗後に部分出力を完成成果物とみなさない。

## 出力schema

通常の `結果.json` / `保存会計の確認.json` / `一覧.resources.json` を維持し、36×70、全場別、集計、Source/旧115対照、Native参照、Viewer保存証拠を持つ。

- `Root保存要求SHA256` は**通常full70要求**を保持する（現通常要求a51ce001…）。`保存器停止SHA256` も同じ演算元397ee90a…を保持する。
- 外側実行は `元54再用Root要求SHA256` と `元54再用runner停止SHA256` へ別記する。外側の実使用を隠さない。
- `独立再用場数=54`、`独立新規検算場数=16`、`全70の金融Native再検算=false`、`再検算方式` を明記する。
- `元54再用` に元要求/結果/保存確認の全FileRefを残す。
- `Viewer参照再用場数=54`、`Viewer新規保存再読場数=16`、`Viewer参照再用SHA256` を残す。
- `入力codeSHA256前/後` は旧入力・元保存物・外側停止・追加16入力を含み、全現物前後同体を検査する。
- `全Rawライフ発生漏れ/初回性監査=false` は維持する。別Raw監査が後で成功しても、この保存物単体の検査範囲を書き換えない。

## 人工・停止

手製54×36行と1944空約定、追加16の最小JSONを作る。元54Nativeを意図的な非gzip bytesにし、再用で展開しないことを検査する。条件/停止/Source/flat/宣言/全場/集計/参照の破壊、NativeとViewerの実bytes変化、価格参照のずれを拒否する。DDは元54から追加16へ跨ぐ手計算例105円、純額25円を同S.combineで確認する。

追加16限定のAPI呼出人工は、旧演算の代替試験ではない。呼出対象と同じP/E/Lを渡すこと、新規576のみ、全2520行/資源、54再用の明示を検査する。既存P/金融演算の証拠は397停止へ参照し、旧全市場を再演算したとは呼ばない。

`検査と停止を準備する.py` の停止前proofをRootがレビューした後だけ新runner停止を作る。旧停止・通常保存器・金融F1は変更しない。本準備で自然Native/Raw/CSVは未読、Rootが許可した元54成功結果の小schemaだけを確認した。
