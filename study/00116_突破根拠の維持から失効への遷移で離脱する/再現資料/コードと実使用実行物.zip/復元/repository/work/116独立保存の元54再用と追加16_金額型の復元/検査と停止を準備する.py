"""元54再用runnerの人工と不変を記録し、Rootレビュー後だけ新停止を作る。"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import 再用して保存する as M
import 金額型を検証する as V

HERE = Path(__file__).resolve().parent
OWN_NAMES = ['再用して保存する.py', '再用の人工検査.py', 'README.md', '要求ひな型.json',
             '同bytesコピーの記録.json', '金額型を検証する.py', Path(__file__).name]


def sha(path: Path) -> str:
    """機能: 明示コード又は小証拠のSHAを返す。

    引数: path(Path)は入力。
    返り値: strは小文字SHA256。市場Native/Raw/CSVへ使わない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def maps() -> tuple:
    """機能: 新所有と固定397のコード依存だけを指紋認証する。

    引数: なし。
    返り値: tuple[dict,dict]は所有/依存SHA。市場本文を依存へ混ぜない。
    """
    M.S.equal(sha(M.PRIOR_STOP), M.PRIOR_SHA, '元397停止不変')
    prior = json.loads(M.PRIOR_STOP.read_bytes())
    own = {str(HERE / name): sha(HERE / name) for name in OWN_NAMES}
    reused = {**prior['所有ファイルSHA256'], **prior['依存コードSHA256'], str(M.PRIOR_STOP): M.PRIOR_SHA}
    old = V.check_derivation()
    reused.update(old['元所有'])
    reused[old['元停止']['path']] = old['元停止']['sha256']
    for path, expected in reused.items():
        M.S.need(Path(path).suffix.lower() not in ('.gz', '.csv', '.jsonl'), '依存コードへ市場本文なし')
        M.S.equal(sha(Path(path)), expected, '停止済み依存code同体')
    return own, reused


# ----------------------------------------
def check(output: Path) -> dict:
    """機能: 11主人工と構文検査で外側の再用境界・委譲・DD・不変を確認する。

    引数: output(Path)は未作成の絶対証拠folder。
    返り値: dictは停止前確認Ref。自然Nativeを検算しない。
    """
    M.S.need(output.is_absolute() and not output.exists(), '停止前証拠は新規絶対先')
    own, reused = maps()
    for name in OWN_NAMES:
        if name.endswith('.py'):
            compile((HERE / name).read_text(encoding='utf-8'), str(HERE / name), 'exec')
    run = subprocess.run([sys.executable, '-m', 'unittest', '-v', '再用の人工検査'], cwd=HERE,
                         capture_output=True, text=True, encoding='utf-8', timeout=120)
    M.S.need(run.returncode == 0 and 'Ran 11 tests' in run.stderr and run.stderr.rstrip().endswith('OK'), '再用の人工11主成功')
    metadata = V.verify_metadata()
    after_own, after_reused = maps()
    M.S.equal(after_own, own, '新所有前後同体')
    M.S.equal(after_reused, reused, '旧保存器/依存前後同体')
    output.mkdir()
    proof = {'試行': 116, '成功': True, '市場前': True, '停止': False, 'Rootレビュー前': True,
        'UTC': datetime.now(timezone.utc).isoformat(), 'Python': sys.version, '主人工': 11,
        '所有ファイルSHA256': own, '依存コードSHA256': reused, '前後不変': True,
        '元保存器停止': {'path': str(M.PRIOR_STOP), 'sha256': M.PRIOR_SHA},
        '元runner停止': metadata['派生の原文確認']['元停止'],
        '金額型復元metadata確認': metadata,
        '人工範囲': ['非gzip手製Native54の指紋再用/条件等破壊拒否。',
            '1944手製Viewer参照/複写0/価格未読/実bytes破壊拒否。',
            'DD105/純額25/Counter/全0群。',
            '追加16のみ同inspect/P/E/L/Viewer APIへ委譲する呼出試験。金融算術の代替試験ではない。',
            '既Gへ通常full70/base54要求をそのまま渡す外側結合/未許可拒否。'],
        '市場Native/Raw/価格CSV/損益CSV/11月09本文読取': 0,
        '許可済み元54成功小metadata': 'f5結果だけで全36集計/Counter一致。保存元rowsの値/型不変。自然Native指紋読取/展開0。',
        '自然full70保存実行': False, '全70の金融Native再検算': False,
        '全Rawライフ発生漏れ/初回性監査': False,
        '実行ログ': {'argv': run.args, 'exit_code': run.returncode, 'stdout': run.stdout, 'stderr': run.stderr}}
    path = output / '停止前の確認.json'
    path.write_text(json.dumps(proof, ensure_ascii=False, indent=2, default=M.S.BASE.serial) + '\n', encoding='utf-8')
    return {'成功': True, '確認': {'path': str(path), 'sha256': sha(path)}}


# ----------------------------------------
def stop(review: Path, expected: str) -> dict:
    """機能: Rootレビュー後に同じコードと証拠を確認して新停止だけを保存する。

    引数: review(Path)、expected(str)はRoot確認対象とSHA。
    返り値: dictは停止Ref。旧停止と新既存先を上書きしない。
    """
    M.S.equal(sha(review), expected, 'RootレビューproofのSHA')
    value = json.loads(review.read_bytes())
    M.S.need(value['成功'] and value['市場前'] and value['停止'] is False and value['前後不変'], 'Rootレビュー前proof成功')
    owned, reused = maps()
    M.S.equal(owned, value['所有ファイルSHA256'], 'Rootレビュー後の所有同体')
    M.S.equal(reused, value['依存コードSHA256'], 'Rootレビュー後の依存同体')
    path = HERE / '停止.json'
    M.S.need(not path.exists(), '新runner停止は初回だけ')
    record = {'試行': 116, '成功': True, '停止': True, '市場前': True,
        'UTC': datetime.now(timezone.utc).isoformat(), '所有ファイルSHA256': owned, '依存コードSHA256': reused,
        '前後不変': True, '元保存器停止': {'path': str(M.PRIOR_STOP), 'sha256': M.PRIOR_SHA},
        '元runner停止': value['元runner停止'],
        '金額型復元': {'作業用copyだけ': True, '復元field': ['positive_yen', 'negative_yen'],
                     '保存元rows値/型不変': True, 'f5全36集計一致': True, '代表反例1円破壊拒否': True},
        '停止前確認': {'path': str(review.resolve()), 'sha256': expected},
        '実API': '再用して保存する.py --fixed ABS --sha256 SHA --output NEWABS [--metadata-only]',
        '再用方式': '同397/F1の独立成功54をSHA認証再用し、新16だけ同じ検算APIを呼ぶ。',
        '自然市場実行': False, 'Native/Raw/CSV/11月09本文読取': 0, '全Rawライフ初回性': False,
        '研究目標達成': False, '採用': False}
    path.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return {'成功': True, '停止': {'path': str(path), 'sha256': sha(path)}}


# ----------------------------------------
def main() -> None:
    """機能: 人工proof作成とRootレビュー後停止を別のCLIとして処理する。

    引数: CLI check-output/review(Path)、review-sha(str)、stop(bool)。
    返り値: None。成功Refだけを出力する。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--check-output', type=Path)
    parser.add_argument('--stop', action='store_true')
    parser.add_argument('--review', type=Path)
    parser.add_argument('--review-sha')
    args = parser.parse_args()
    if args.stop:
        M.S.need(args.check_output is None and args.review is not None and args.review_sha, 'Rootレビュー参照指定')
        result = stop(args.review, args.review_sha)
    else:
        M.S.need(args.check_output is not None and args.review is None and args.review_sha is None, '新しい人工proof先だけ指定')
        result = check(args.check_output)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
