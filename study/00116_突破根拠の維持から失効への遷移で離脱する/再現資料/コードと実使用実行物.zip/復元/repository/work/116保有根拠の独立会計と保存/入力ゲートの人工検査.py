"""自然Nativeを用意せず、Root固定と全成功以外では本文へ進まないことを検査する。"""
from copy import deepcopy
from pathlib import Path
import json
import tempfile
import unittest

import 保存の入力ゲート as G

HERE=Path(__file__).resolve().parent


def write(path: Path,value: dict) -> dict:
    """
    機能: 人工metadataを保存してその絶対FileRefを返す。
    引数: path(Path)、value(dict)。返り値: dictはpath/sha256/bytes。
    """
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2,default=G.S.BASE.serial)+'\n',encoding='utf-8')
    return {'path':str(path.resolve()),'sha256':G.S.digest(path),'bytes':path.stat().st_size}


def fixture(folder: Path) -> dict:
    """
    機能: 実市場成功とは明確に別の、Native不在のfirst2 metadata人工を構成する。
    引数: folder(Path)。返り値: dictは要求原値と依存人工。
    """
    refs={};gate=Path(G.__file__).resolve();entry=HERE/'入口の独立検算.py';pcode=HERE/'新保護の独立監査.py';lcode=HERE/'保有根拠の独立監査.py'
    for name,owned,trial in [('code_stop',[gate,entry],116),('P_stop',[pcode],116),('life_stop',[lcode],116),('actor_stop',[],116),('lifecycle_go_stop',[],116),('entry115_stop',[],115),('runtime',[],116)]:
        refs[name]=write(folder/(name+'.json'),{'人工':True,'成功':True,'停止':True,'市場前':True,'試行':trial,'所有ファイルSHA256':{str(p):G.S.digest(p) for p in owned}})
    oldpath=G.S.ROOT/'work/115進行/F1_115金融条件.json';old=G.S.load(oldpath);oldref={'path':str(oldpath.resolve()),'sha256':'94bb656a1607d59039a0c5ec0f06968a4da72463d27c0847606a09fc52fc4693'}
    definition=G.S.load(G.S.ROOT/'work/116突破根拠の維持と失効/検査/実定義.json')
    declaration=write(folder/'definition.json',definition);code={str(gate):G.S.digest(gate)}
    actor=G.S.load(Path(refs['actor_stop']['path']));actor['純監視停止']=refs['lifecycle_go_stop'];refs['actor_stop']=write(folder/'actor_stop.json',actor)
    pure=G.S.load(Path(refs['lifecycle_go_stop']['path']));pure['実定義']=declaration;refs['lifecycle_go_stop']=write(folder/'lifecycle_go_stop.json',pure)
    actor['純監視停止']=refs['lifecycle_go_stop'];refs['actor_stop']=write(folder/'actor_stop.json',actor)
    refs['runtime']=write(folder/'runtime.json',{'成功':True,'停止':True,'trial':116,'自己コード全依存前後不変':True,'Raw/市場Native/実価格CSV/11月09本文読取':False})
    condition={'人工':True,'trial':116,'fixed':True,'actual_configurations':list(G.S.A.CONFIGS),'runtime_stop':refs['runtime'],'dependency_stops':{n:refs['actor_stop'] for n in ('source','chart','core115','entry_input','pure','entry_gate','entry_chart','actor','lifecycle')},'reference115':{'condition':oldref},'lifecycle_declaration':declaration,'lifecycle_definition':definition,'code_sha256':code}
    condition['dependency_stops']['lifecycle']=refs['lifecycle_go_stop']
    for field in ('protection_definition','protection_configurations','entry_gate_definition','entry_chart_definition','entry_input_model'):condition[field]=old[field]
    cref=write(folder/'condition.json',condition);scenes=[];results=[]
    for sid in G.planned_sessions('first2'):
        native={'path':str(folder/'new'/f'{sid}.Native.json.gz'),'sha256':'1'*64};prior={'path':str(folder/'old'/f'{sid}.Native.json.gz'),'sha256':'2'*64}
        scenes.append({'session':sid,'native':native,'reference115':prior,'history_class':'original54','market_path':'人工文字列だけ'})
        results.append({'session':sid,'books':36,'complete':True,'x0_equal':True,'x0_comparisons':12,'reference115_equal':True,'reference115_comparisons':12,'source111_equal':True,'open_quantity':0,'pending_quantity':0,'native':native,'reference115':prior})
    completion={'人工':True,'trial':116,'success':True,'stage':'first2','sessions':2,'books':72,'condition_sha256':cref['sha256'],'unchanged':True,'before':code,'after':code,'reused_sessions':0,'replayed_sessions':2,'all_reference115_equal':True,'all_source111_equal':True,'reference115_comparisons':24,'results':results}
    complete=write(folder/'completion.json',completion)
    q={'人工':True,'version':1,'trial':116,'fixed':True,'stage':'first2','market_native_read_authorized':True,'legacy115_read_authorized':True,'raw_read_authorized':False,'holdout_read_authorized':False,**{k:v for k,v in refs.items() if k!='runtime'},'protection_code':{'path':str(pcode),'sha256':G.S.digest(pcode)},'lifecycle_code':{'path':str(lcode),'sha256':G.S.digest(lcode)},'entry_code':{'path':str(entry),'sha256':G.S.digest(entry)},'condition':cref,'completion':complete,'scenes':scenes}
    return {'request':q,'condition':condition,'completion':completion,'folder':folder}


def prepare(data: dict) -> dict:
    """
    機能: 改変後の人工metadataを再指紋化し入力ゲートだけを実行する。
    引数: data(dict)。返り値: dictは本文未読の計画。Nativeは存在しない。
    """
    q=data['request'];folder=data['folder'];q['condition']=write(folder/'condition.json',data['condition']);q['completion']=write(folder/'completion.json',data['completion']);ref=write(folder/'request.json',q)
    return G.prepare(Path(ref['path']),ref['sha256'],folder/'未生成の出力')


class Tests(unittest.TestCase):
    """市場原文なしのmetadata許可/拒否。"""

    def test_metadata_success_without_native(self):
        """
        機能: 全成功人工の計画だけを作り、存在しない新旧Nativeへ触れない。
        引数: self(Tests)。返り値: None。
        """
        with tempfile.TemporaryDirectory(dir=HERE) as tmp:
            data=fixture(Path(tmp));plan=prepare(data);self.assertEqual(len(plan['tasks']),2);self.assertFalse(plan['output'].exists());self.assertFalse(Path(plan['tasks'][0]['native']['path']).exists())

    def test_reference_identity_ignores_bytes_and_slash_only(self):
        """
        機能: bytes付加/slash差だけは同体とし、SHA/絶対位置の差は拒否する。
        引数: self(Tests)。返り値: None。
        """
        a={'path':str(HERE/'A.json'),'sha256':'1'*64};b={**a,'path':a['path'].replace('\\','/'),'bytes':1};self.assertTrue(G.same_ref(a,b));self.assertFalse(G.same_ref(a,{**b,'sha256':'2'*64}));self.assertFalse(G.same_ref(a,{**b,'path':str(HERE/'B.json')}))

    def test_unauthorized_or_incomplete_rejected(self):
        """
        機能: 明示許可/全36/旧12/flat/同条件の欠落を本文前に拒否する。
        引数: self(Tests)。返り値: None。
        """
        for field in ('permission','legacy','raw','holdout','books','old','flat','condition','stage','config'):
            with tempfile.TemporaryDirectory(dir=HERE) as tmp:
                data=fixture(Path(tmp));q=data['request'];c=data['completion']
                if field=='permission':q['market_native_read_authorized']=False
                elif field=='legacy':q['legacy115_read_authorized']=False
                elif field=='raw':q['raw_read_authorized']=True
                elif field=='holdout':q['holdout_read_authorized']=True
                elif field=='books':c['books']=71
                elif field=='old':c['reference115_comparisons']=23
                elif field=='flat':c['results'][0]['pending_quantity']=1
                elif field=='condition':c['condition_sha256']='0'*64
                elif field=='stage':q['stage']='11月09'
                else:data['condition']['actual_configurations']=data['condition']['actual_configurations'][:-1]
                with self.subTest(field=field),self.assertRaises(ValueError):prepare(data)


if __name__=='__main__':unittest.main(verbosity=2)
