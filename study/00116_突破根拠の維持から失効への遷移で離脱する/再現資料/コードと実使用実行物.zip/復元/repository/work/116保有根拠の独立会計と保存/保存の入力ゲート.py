"""116の金融全成功・停止・明示Root許可を本文前に認証する。Raw実行権限は持たない。"""
from datetime import date,timedelta
from pathlib import Path
import re

import 保存集計の共通部 as S


def reference(ref: dict,before: dict) -> Path:
    """
    機能: 絶対FileRefをSHA認証し前後不変の台帳へ結ぶ。
    引数: ref/before(dict)。返り値: Path。追加bytesやslash表記は同体性を変えない。
    """
    S.need(isinstance(ref,dict) and isinstance(ref.get('path'),str) and re.fullmatch('[a-f0-9]{64}',ref.get('sha256','')) is not None,'116 FileRef型')
    p=Path(ref['path']);S.need(p.is_absolute(),'116絶対Ref');p=p.resolve();S.equal(S.digest(p),ref['sha256'],'116参照実物SHA');S.need(str(p) not in before or before[str(p)]==ref['sha256'],'同path指紋衝突');before[str(p)]=ref['sha256']
    return p


def same_ref(a: dict,b: dict) -> bool:
    """
    機能: 絶対解決位置とSHAだけを厳密に比較する。
    引数: a/b(dict)。返り値: bool。本文を読む操作ではない。
    """
    return isinstance(a,dict) and isinstance(b,dict) and Path(a['path']).is_absolute() and Path(b['path']).is_absolute() and Path(a['path']).resolve()==Path(b['path']).resolve() and a['sha256']==b['sha256']


def planned_sessions(stage: str) -> list[str]:
    """
    機能: first2/base54/full70の全予定場を日夜順に保持する。
    引数: stage(str)。返り値: list[str]。11月09を対象に含めない。
    """
    S.need(stage in ('first2','base54','full70'),'116独立stage');end=date(2026,9,21) if stage=='first2' else date(2026,10,27) if stage=='base54' else date(2026,11,6);day=date(2026,9,21);out=[]
    while day<=end:
        if day.weekday()<5:out.extend(f'{day.isoformat()}_{kind}' for kind in ('Day','Night'))
        day+=timedelta(days=1)
    S.equal(len(out),{'first2':2,'base54':54,'full70':70}[stage],'116予定場数')
    return out


def check_stop(ref: dict,before: dict,trial: int=116) -> dict:
    """
    機能: 独立/Go停止とその実使用コードだけを指紋認証する。
    引数: ref/before(dict)、trial(int)。返り値: dictは認証済停止metadata。
    """
    value=S.load(reference(ref,before));S.need(value['成功'] and value['市場前'] and value['試行']==trial,'市場前の同trial停止')
    for field in ('所有ファイルSHA256','所有コードSHA256','再用ファイルSHA256','依存コードSHA256'):
        for path,sha in value.get(field,{}).items():
            S.need(Path(path).suffix not in ('.csv','.gz','.jsonl'),'停止コードへ市場本文を混ぜない');reference({'path':path,'sha256':sha},before)
    return value


def prepare(fixed_path: Path,fixed_sha: str,output: Path) -> dict:
    """
    機能: Rootの116金融成功/全36/旧12対照と独立停止をNative本文前に認証する。
    引数: fixed_path/output(Path)、fixed_sha(str)。返り値: dictは明示新旧Native計画。
    """
    S.need(output.is_absolute() and not output.exists(),'116新規絶対出力');before={};q=S.load(reference({'path':str(fixed_path.resolve()),'sha256':fixed_sha},before))
    S.need(q['version']==1 and q['trial']==116 and q['fixed'] is True and q['market_native_read_authorized'] is True and q['legacy115_read_authorized'] is True,'Root116新旧Nativeの明示解禁')
    S.need(q.get('raw_read_authorized',False) is False and q.get('holdout_read_authorized',False) is False,'この保存CLIはRaw/holdoutを読まない')
    stops={name:check_stop(q[name],before,115 if name=='entry115_stop' else 116) for name in ('code_stop','P_stop','life_stop','actor_stop','lifecycle_go_stop','entry115_stop')}
    own=stops['code_stop']['所有ファイルSHA256'];S.need(all(str(Path(p).parent.resolve())==str(Path(__file__).resolve().parent) for p in own),'現在の独立保存所有フォルダ')
    S.equal(own.get(str(Path(__file__).resolve())),S.digest(Path(__file__).resolve()),'実保存ゲート自体の停止同体')
    for name,stop in (('protection_code','P_stop'),('lifecycle_code','life_stop'),('entry_code','code_stop')):
        p=reference(q[name],before);S.equal(stops[stop]['所有ファイルSHA256'].get(str(p)),q[name]['sha256'],'同体停止の実Python/'+name)
    condition=S.load(reference(q['condition'],before));complete=S.load(reference(q['completion'],before));expected=planned_sessions(q['stage'])
    S.need(condition['trial']==116 and condition['fixed'],'116本名金融固定');S.equal(condition['actual_configurations'],list(S.A.CONFIGS),'116全36実宣言順')
    runtime=S.load(reference(condition['runtime_stop'],before))
    S.need(runtime['成功'] is True and runtime['停止'] is True and runtime['trial']==116 and runtime['自己コード全依存前後不変'] is True and runtime['Raw/市場Native/実価格CSV/11月09本文読取'] is False,'116Core固有schemaの市場前停止')
    deps=condition['dependency_stops'];S.equal(set(deps),{'source','chart','core115','entry_input','pure','entry_gate','entry_chart','actor','lifecycle'},'116依存9群')
    S.need(same_ref(deps['actor'],q['actor_stop']) and same_ref(deps['lifecycle'],q['lifecycle_go_stop']),'同Actor/純ライフ停止')
    S.need(same_ref(stops['actor_stop']['純監視停止'],q['lifecycle_go_stop']),'Actorが実際に用いた純ライフ停止')
    oldref=condition['reference115']['condition'];S.equal(oldref['sha256'],'94bb656a1607d59039a0c5ec0f06968a4da72463d27c0847606a09fc52fc4693','旧115同F1参照');old=S.load(reference(oldref,before))
    for field in ('protection_definition','protection_configurations','entry_gate_definition','entry_chart_definition','entry_input_model'):S.equal(condition[field],old[field],'116で既入口/保護を変えない/'+field)
    definition=S.load(reference(condition['lifecycle_declaration'],before));S.equal(condition['lifecycle_definition'],definition,'純ライフ実定義と金融F1')
    S.equal(S.load(reference(stops['lifecycle_go_stop']['実定義'],before)),definition,'純Go停止の実定義そのもの')
    S.equal(definition['version'],116,'116ライフ定義版');S.equal(definition['policies'],['X0','XC','XQ'],'116ライフ3政策')
    S.need(complete['trial']==116 and complete['success'] and complete['stage']==q['stage'] and complete['sessions']==len(expected) and complete['books']==36*len(expected),'116全36N金融成功')
    S.equal(complete['condition_sha256'],q['condition']['sha256'],'独立と金融は同F1');S.need(complete['unchanged'] and complete['before'] and complete['before']==complete['after'],'金融前後不変')
    S.equal((complete['reused_sessions'],complete['replayed_sessions']),(54,16) if q['stage']=='full70' else (0,len(expected)),'同F1元54再用/追加16再生')
    S.need(complete['all_reference115_equal'] and complete['all_source111_equal'] and complete['reference115_comparisons']==12*len(expected),'旧115全12N/Source全文対照')
    S.equal([r['session'] for r in complete['results']],expected,'116全予定場順');S.equal([r['session'] for r in q['scenes']],expected,'独立要求全予定場順')
    financial_before={str(Path(p).resolve()):sha for p,sha in complete['before'].items()}
    for path,sha in condition['code_sha256'].items():
        p=Path(path);p=(p if p.is_absolute() else S.ROOT/p).resolve();S.need(p.suffix not in ('.csv','.gz','.jsonl'),'金融コードに市場本文なし');reference({'path':str(p),'sha256':sha},before);S.equal(financial_before.get(str(p)),sha,'同金融実使用コード')
    tasks=[]
    for final,task in zip(complete['results'],q['scenes']):
        S.need(final['books']==36 and final['complete'] and final['x0_equal'] and final['x0_comparisons']==12 and final['reference115_equal'] and final['reference115_comparisons']==12 and final['source111_equal'] and final['open_quantity']==final['pending_quantity']==0,'116場別36/旧12/flat')
        S.need(same_ref(task['native'],final['native']) and same_ref(task['reference115'],final['reference115']),'当場新旧NativeのRoot参照同体')
        S.need(Path(task['native']['path']).name==Path(task['reference115']['path']).name==task['session']+'.Native.json.gz','同場Native本名')
        S.equal(task['history_class'],'original54' if task['session'][:10]<='2026-10-27' else 'additional16','元54/追加16')
        S.need(isinstance(task['market_path'],str) and task['market_path'],'価格は参照文字列だけ');tasks.append(task)
    return {'request':q,'condition':condition,'completion':complete,'tasks':tasks,'before':before,'output':output.resolve(),'definition':definition}
