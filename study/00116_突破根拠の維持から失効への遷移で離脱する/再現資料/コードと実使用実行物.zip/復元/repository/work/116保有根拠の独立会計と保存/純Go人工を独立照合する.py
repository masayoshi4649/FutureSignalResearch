"""Go116の手製全系列を、期待値を呼ばずPython状態式へ逐次突合する。"""
from pathlib import Path
from decimal import Decimal
import hashlib
import json

import ライフ状態の独立式 as I
import 保有根拠の独立監査 as L

HERE=Path(__file__).resolve().parent
ART=HERE.parents[1]/'work/116突破根拠の維持と失効/人工_接続前/人工の参照.json'
ART_SHA='47bcaa3f06b016473de29b86f8163759c11fd0004b526f603d1c2eb1717c8e33'


def read(path: Path,sha: str) -> dict:
    """
    機能: 明示されたGo手製だけをSHA認証して読む。
    引数: path(Path)、sha(str)。返り値: dict。自然Nativeは対象外。
    """
    body=path.read_bytes();I.A.equal(hashlib.sha256(body).hexdigest(),sha,'純Go人工SHA')
    return json.loads(body,parse_float=Decimal)


def main(target: Path|None=None) -> None:
    """
    機能: 8系列48Advanceの初期/前後/DecisionをPython単独式で一致確認する。
    引数: target(Path|None)は新規保存先。返り値: None。Go実行や金融/Raw読取なし。
    """
    manifest=read(ART,ART_SHA);I.A.need(manifest['人工'] and not manifest['市場読取'] and manifest['試行']==116,'明示手製のみ')
    ref=manifest['系列'];series=read(Path(ref['path']),ref['sha256']);definition=read(Path(manifest['実定義']['path']),manifest['実定義']['sha256']);I.A.equal(series['definition'],definition,'Go人工の同実定義')
    count=0;result=[]
    for case in series['cases']:
        state=L.initial_state(case['entry'],definition);I.compare(case['initial_snapshot'],state,'独立初期/'+case['id']);previous=None;deliveries={}
        birth=case['entry']['birth']
        for scale in birth['current']['snapshot']['scales']:
            if not scale['has_current']:continue
            f=scale['current']['frame'];idx=f['record_ordinal']-1
            deliveries[f['id']]={'time':f['delivery_at'],'index':idx,'source_line':birth['request']['at']['source_line'] if idx==birth['request']['at']['index'] else 0}
        for ordinal,step in enumerate(case['steps']):
            I.compare(step['before_snapshot'],state,'逐次独立Before/'+case['id']);inp=step['input'];five=inp['latest']['scales'][0]
            if five['has_current']:
                f=five['current']['frame'];ident=f['id']
                if ident not in deliveries:deliveries[ident]={'time':f['delivery_at'],'index':f['record_ordinal']-1,'source_line':inp['stamp']['source_line'] if f['record_ordinal']==inp['latest']['record_ordinal'] else 0}
                delivered=deliveries[ident]
            else:delivered={'time':0,'index':0,'source_line':0}
            state,decision=I.expected_step(state,inp,previous,delivered,delivered['source_line']>0)
            I.compare(step['after_snapshot'],state,'逐次独立After/'+case['id']+'/'+str(ordinal));I.compare(step['decision'],decision,'逐次独立Decision/'+case['id']+'/'+str(ordinal));previous=inp['latest'];count+=1
        result.append({'id':case['id'],'Advance':len(case['steps']),'一致':True})
    I.A.equal(len(result),8,'純Go人工8系列');I.A.equal(count,48,'純Go人工48Advance')
    proof={'試行':116,'成功':True,'市場前':True,'Go人工参照':{'path':str(ART),'sha256':ART_SHA},'系列Ref':ref,'実定義Ref':manifest['実定義'],'系列数':8,'Advance数':count,'初期/Before/After/Decision全値一致':True,'系列':result,'Go期待関数の呼出/Raw/金融実行':0}
    target=target or HERE/'純Go8系列の独立照合.json'
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'path':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__=='__main__':main()
