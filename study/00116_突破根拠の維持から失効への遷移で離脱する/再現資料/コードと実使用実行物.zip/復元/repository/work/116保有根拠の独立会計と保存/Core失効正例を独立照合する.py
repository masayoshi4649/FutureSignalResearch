"""実公開器からlife実返済へ至る手製72冊を、独立会計/公表/状態式へ結ぶ。"""
from collections import Counter
from pathlib import Path
import hashlib
import json
import tempfile

import Core人工を独立照合する as C

HERE=Path(__file__).resolve().parent
ART=C.S.ROOT/'work/116保有根拠の連続比較/人工_失効と所有/人工の参照.json'
ART_SHA='c5cde3741e193ac3dac6e0e40980405783f77aaed3dcce1558396551f6d3d46c'


def main(target: Path|None=None) -> None:
    """
    機能: 公表asof/失効要求/実fill/外部P予約/flatを72人工で一体照合する。
    引数: target(Path|None)は新規証拠保存先。返り値: None。市場/Rawの初回性は扱わない。
    """
    manifest=C.read({'path':str(ART),'sha256':ART_SHA})
    C.S.need(manifest['人工'] and not manifest['市場'] and not manifest['FAR自然生成'],'失効正例は手製だけ')
    value=C.read(manifest['圧縮']);total=resources=0;pc=Counter();lc=Counter();scenes=[]
    C.S.need(value['人工'] and not value['市場'] and not value['FAR自然生成'],'正例の範囲を維持')
    for name,native in value['results'].items():
        checked=C.S.inspect_scene(native,None,C.P,C.E,C.L,True)
        C.S.equal(len(checked['checked']),36,'失効Core人工各36')
        for key,result in checked['checked'].items():
            row=C.S.summarize_book(native['actual']['books'][key],result)
            C.S.equal(sum(v['返済片純額'] for v in row['注文別'].values()),row['net_yen'],'失効人工の全返済役割加法')
            pc.update(result['protection_counts']['counts']);lc.update(result['lifecycle_counts']['counts']);total+=1
            if native['actual']['books'][key]['config']['life_mode']!='X0':
                C.S.need(result['lifecycle_counts']['counts']['exit_requests']>0,'新XC/XQ全口座で失効要求正例')
                C.S.need(result['lifecycle_counts']['counts']['exit_fills']>0,'新XC/XQ全口座で失効実fill正例')
        with tempfile.TemporaryDirectory(dir=HERE) as tmp:
            out=Path(tmp);catalog=C.S.save_viewer(native,out,'人工の価格参照だけ');viewer=C.S.verify_viewer(native,out,catalog);resources+=len(catalog)
        scenes.append({'id':name,'会計':36,'全公表asof/入口/会計/P/ライフ/実所有成功':True,'旧115独立Native対照':checked['reference115']['comparisons'],'自然Source生成証明':False,'Viewer':viewer})
    C.S.equal((len(scenes),total,resources),(2,72,72),'失効正例2系列72会計/Viewer')
    C.S.need(lc['exit_requests']>=48 and lc['exit_fills']>=48 and pc['lifecycle_P100_reservations_exact']>=48,'48口座の失効返済とP100外部予約の正例')
    proof={'試行':116,'成功':True,'市場前':True,'Core人工参照':{'path':str(ART),'sha256':ART_SHA},'圧縮Ref':manifest['圧縮'],'系列数':2,'会計数':total,'Viewer資源':resources,'P保存検査':dict(pc),'ライフ保存検査':dict(lc),'系列':scenes,'全Raw発生漏れ/初回性監査':False,'自然Source生成証明':False,'旧115対照':'Coreは旧Native本文を同梱しないため0。別Actor手製72で旧115全24を独立照合済み。','Raw/新自然Native/金融Go再走':0}
    target=target or HERE/'Core手製72失効正例の結合確認.json'
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(proof,ensure_ascii=False,indent=2,default=C.S.BASE.serial)+'\n')
    print(json.dumps({'成功':True,'path':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__=='__main__':main()
