"""Rootが同F1金融成功後に固定する独立保存要求の、未許可ひな型だけを作る。"""
from pathlib import Path
import argparse
import json

import 保存の入力ゲート as G

HERE=Path(__file__).resolve().parent
F1=G.S.ROOT/'work/116進行/F1_116金融条件.json'
F1_SHA='4c76a5f7cd8a59962e885cadf6885cfc75cbc590675955cb8e72ae2d0b8bb372'


def ref(path: Path) -> dict:
    """
    機能: 存在するmetadata/コードの絶対FileRefを作る。
    引数: path(Path)。返り値: dictはpath/sha256。市場本文は読まない。
    """
    return {'path':str(path.resolve()),'sha256':G.S.digest(path)}


def make_template(stage: str,completion: Path|None=None) -> dict:
    """
    機能: 停止後の実Refと同F1を含む未固定・未許可の要求ひな型を作る。
    引数: stage(str)、completion(Path|None)。返り値: dict。Rootが許可を固定するまで実行不可。
    """
    G.planned_sessions(stage);G.S.equal(G.S.digest(F1),F1_SHA,'Root同F1')
    root=G.S.ROOT
    q={'version':1,'trial':116,'fixed':False,'stage':stage,'market_native_read_authorized':False,'legacy115_read_authorized':False,'raw_read_authorized':False,'holdout_read_authorized':False,
       'condition':ref(F1),'completion':None,'code_stop':ref(HERE/'会計停止.json'),'P_stop':ref(HERE/'P停止.json'),'life_stop':ref(HERE/'ライフ停止.json'),
       'actor_stop':ref(root/'work/116突破失敗を返済へ結ぶ会計/Actor停止.json'),'lifecycle_go_stop':ref(root/'work/116突破根拠の維持と失効/停止.json'),'entry115_stop':ref(root/'work/115入口判定を独立検算する/停止.json'),
       'protection_code':ref(HERE/'新保護の独立監査.py'),'lifecycle_code':ref(HERE/'保有根拠の独立監査.py'),'entry_code':ref(HERE/'入口の独立検算.py'),'scenes':[],
       'Root固定時の手順':['completion成功metadataのstage/同F1を確認し全scenesを元順で埋める。','market_pathは価格参照文字列だけを設定する。','Rootがfixed/新旧Native許可をtrueへ固定し、新しい要求SHAを採用する。','metadata-only認証後にRootだけが保存CLIを実行する。Raw許可はこの要求へ付けない。']}
    if completion is not None:
        value=G.S.load(completion);G.S.need(value['success'] and value['trial']==116 and value['stage']==stage and value['condition_sha256']==F1_SHA,'同F1/同stage金融成功metadata')
        G.S.equal([x['session'] for x in value['results']],G.planned_sessions(stage),'成功metadataの全場順');q['completion']=ref(completion)
        q['scenes']=[{'session':x['session'],'native':x['native'],'reference115':x['reference115'],'history_class':'original54' if x['session'][:10]<='2026-10-27' else 'additional16','market_path':'Rootが既存の価格参照文字列を設定する'} for x in value['results']]
    return q


def main() -> None:
    """
    機能: 停止済み独立コードの未許可要求を新規JSONへ保存する。
    引数: CLI stage(str)、completion(Path|None)、output(Path)。返り値: None。
    """
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=('first2','base54','full70'),required=True);p.add_argument('--completion',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    G.S.need(a.output.is_absolute() and not a.output.exists(),'ひな型は新規絶対位置');value=make_template(a.stage,a.completion)
    with a.output.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2,default=G.S.BASE.serial)+'\n')
    print(json.dumps({'成功':True,'未固定':True,'市場本文読取許可':False,'ref':ref(a.output)},ensure_ascii=False))


if __name__=='__main__':main()
