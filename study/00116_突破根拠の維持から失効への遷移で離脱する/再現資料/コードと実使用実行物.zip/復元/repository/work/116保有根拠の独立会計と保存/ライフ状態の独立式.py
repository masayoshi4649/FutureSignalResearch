"""116の境界維持・失効をDecimal/三値で独立再計算する。Go関数は呼ばない。"""
from copy import deepcopy
from decimal import Decimal

import 金融の独立検算 as A

UNKNOWN,FALSE,TRUE=0,1,2


def number(value,label: str='ライフ実数') -> Decimal:
    """
    機能: 保存された有限実数を十進数へ変換する。
    引数: value(数値)、label(str)。返り値: Decimal。不正型/非有限を拒否する。
    """
    return A.number(value,label)


def known(value: dict) -> Decimal|None:
    """
    機能: Knownが真の公開数値だけを使う。
    引数: value(dict)。返り値: Decimal|None。未知を0にしない。
    """
    A.need(type(value['known']) is bool,'Known型')
    return number(value['value']) if value['known'] else None


def monitoring_eligible(entry: dict) -> bool:
    """
    機能: 凍結出生Common/D15/G30/境界だけから監視適格を独立に判定する。
    引数: entry(dict)。返り値: bool。入口の受理・新規追加拒否を意味しない。
    """
    birth=entry['birth'];v=birth['values']
    return birth['common']==TRUE and v['d15'] is not None and number(v['d15'])>0 and v['g30'] is not None and number(v['g30'])!=0 and v['boundary'] is not None


def values_for(entry: dict,inp: dict) -> dict:
    """
    機能: 最新公表の実使用値/鮮度/BBOとarmed四票を独立計算する。
    引数: entry/ inp(dict)。返り値: dictは数値・三値・欠測の理由。
    """
    side=entry['side'];boundary=entry['birth']['values']['boundary'];A.need(type(inp['quote_ok']) is bool,'Input.quote_ok型');qok=inp['quote_ok'] and number(inp['bid'])>0 and number(inp['ask'])>number(inp['bid'])
    v={'boundary':boundary,'five_close':None,'signed_close':None,'signed_histogram':None,'signed_di15':None,'g30':None,'return_BBO':None,'signed_return_BBO':None};missing=[];stale=[];fresh=True;allknown=True
    for i,scale in enumerate(inp['latest']['scales']):
        label=('5','15','30')[i]
        if not scale['has_current'] or scale['seed_only']:allknown=False;missing.append(label+'.当場公表');continue
        if not scale['fresh']:fresh=False;stale.append(label+'.fresh')
        f=scale['current']['frame']
        if not f['price_known']:allknown=False;missing.append(label+'.PriceKnown');continue
        t=f['technical']
        if i==0:
            v['five_close']=f['ohlc']['close']
            if boundary is not None:v['signed_close']=side*(number(v['five_close'])-number(boundary))
            hist=known(t['histogram'])
            if hist is None:allknown=False;missing.append('5.Hist')
            else:v['signed_histogram']=side*hist
        elif i==1:
            dmi=scale['current']['dmi'];plus=known(dmi['plus_di']);minus=known(dmi['minus_di'])
            if plus is None or minus is None:allknown=False;missing.append('15.DI')
            else:v['signed_di15']=side*(plus-minus)
        else:
            fast=known(t['ema8']);slow=known(t['ema21'])
            if fast is None or slow is None:allknown=False;missing.append('30.EMA')
            else:v['g30']=side*(fast-slow)
    if qok and boundary is not None:
        v['return_BBO']=inp['bid'] if side==1 else inp['ask'];v['signed_return_BBO']=side*(number(v['return_BBO'])-number(boundary))
    arm=UNKNOWN
    if not monitoring_eligible(entry):arm=FALSE
    elif allknown and fresh and qok:
        A.need(all(v[k] is not None for k in ('signed_close','signed_histogram','signed_di15','signed_return_BBO')),'監視適格の既知四票')
        arm=TRUE if all(number(v[k])>0 for k in ('signed_close','signed_histogram','signed_di15','signed_return_BBO')) else FALSE
    five=inp['latest']['scales'][0]
    post=five['has_current'] and number(five['current']['frame']['end'])>number(entry['fill_stamp']['time']) and five['current']['frame']['record_ordinal']-1>entry['fill_stamp']['index']
    return {'values':v,'required_known':allknown,'required_fresh':fresh,'quote_ok':qok,'arming_condition':arm,'post_entry_five':post,'missing':missing,'stale':stale}


def make_witness(inp: dict,values: dict,delivered: dict,line_known: bool,reason: str) -> dict:
    """
    機能: 最初の実arm/失効の入力と利用値を参照共有なしで固定する。
    引数: inp/values/delivered(dict)、line_known(bool)、reason(str)。返り値: dictはwitness。
    """
    return deepcopy({'input':inp,'values':values,'five_delivered':delivered,'five_delivery_line_known':line_known,'reason':reason})


def expected_step(before: dict,inp: dict,previous_latest: dict|None,delivered: dict,line_known: bool) -> tuple[dict,dict]:
    """
    機能: 直前公開状態から1Advanceを独立算術し、不可逆ラッチとP100優先を検査する。
    引数: before/ inp(dict)、previous_latest(dict|None)、delivered(dict)、line_known(bool)。
    返り値: tuple[dict,dict]は期待Snapshot/Decision。Go期待値・市場再生を使わない。
    """
    out=deepcopy(before);entry=before['entry'];initial=not before['initialized'];current=inp['latest']['scales'][0]
    A.need(type(inp['remaining']) is int and type(inp['reserved']) is int and 0<=inp['reserved']<=inp['remaining'] and inp['remaining']>0,'実保有n>0だけを純ライフ評価')
    x=values_for(entry,inp);old=None if previous_latest is None else previous_latest['scales'][0]
    newfive=current['has_current'] and current['current']['frame']['record_ordinal']==inp['latest']['record_ordinal'] and (old is None or not old['has_current'] or current['current']['frame']['id']!=old['current']['frame']['id'])
    d={'version':116,'policy':entry['policy'],'stamp':deepcopy(inp['stamp']),'initial_evaluation':initial,'monitoring_eligible':monitoring_eligible(entry),**x,'armed_now':False,'chain_broken_now':False,'warning':False,'new_five_publication':newfive,'invalidated_now':False,'exit_eligible_quantity':0,'reason':''}
    out['sequence']+=1;out['at']=deepcopy(inp['stamp'])
    if entry['policy']=='X0' or not out['monitoring_eligible']:d['reason']='追加監視なし'
    elif out['latched']:
        out['warning']=out['armed'] and x['required_known'] and x['required_fresh'] and x['post_entry_five'] and x['values']['signed_histogram'] is not None and number(x['values']['signed_histogram'])<=0
        d['reason']='既完成失効を保持'
    elif out['disabled_by_P100'] or inp['P100_active']:
        out['disabled_by_P100']=True;out['armed']=False;out['warning']=False;d['reason']='P100先起動へ委譲'
    else:
        if not x['required_known'] or not x['required_fresh']:
            if out['armed']:
                d['chain_broken_now']=True;out['chain_break_count']+=1;out['last_chain_break']=make_witness(inp,x['values'],delivered,line_known,'実使用Unknown/古さ')
            out['armed']=False;out['warning']=False;d['reason']='実使用値の鎖切り'
        if not out['armed'] and x['arming_condition']==TRUE and (initial or x['post_entry_five']):
            out['armed']=True;out['arming_count']+=1;d['armed_now']=True;w=make_witness(inp,x['values'],delivered,line_known,'維持根拠をarmed')
            if out['first_arming'] is None:out['first_arming']=deepcopy(w)
            out['last_arming']=deepcopy(w)
        if out['armed'] and x['required_known'] and x['required_fresh']:
            out['warning']=x['post_entry_five'] and x['values']['signed_histogram'] is not None and number(x['values']['signed_histogram'])<=0
            trigger=out['warning'] and ((entry['policy']=='XC' and newfive and number(x['values']['signed_close'])<0) or (entry['policy']=='XQ' and x['quote_ok'] and number(x['values']['signed_return_BBO'])<0))
            if trigger:
                out['latched']=True;d['invalidated_now']=True;out['invalidation']=make_witness(inp,x['values'],delivered,line_known,'取得後の突破根拠失効');d['reason']='新しい失効を不可逆ラッチ'
    d['warning']=out['warning']
    if out['latched'] and x['quote_ok']:d['exit_eligible_quantity']=inp['remaining']-inp['reserved']
    out['initialized']=True
    d.update(armed=out['armed'],latched=out['latched'],disabled_by_P100=out['disabled_by_P100'],sequence=out['sequence'])
    return out,d


def compare(actual,expected,path: str='独立ライフ') -> None:
    """
    機能: 全fieldと三値/旗を厳密、派生実数だけを1e-9絶対差で比較する。
    引数: actual/expected(JSON値)、path(str)。返り値: None。不一致はValueError。
    """
    if isinstance(expected,dict):
        A.equal(set(actual),set(expected),path+'/keys')
        for k,v in expected.items():compare(actual[k],v,path+'/'+k)
    elif isinstance(expected,list):
        A.need(isinstance(actual,list) and len(actual)==len(expected),path+'/list')
        for i,v in enumerate(expected):compare(actual[i],v,path+'/'+str(i))
    elif isinstance(expected,Decimal):A.need(actual is not None and abs(number(actual)-expected)<=Decimal('1e-9'),path+'/数値')
    else:A.equal(actual,expected,path)
