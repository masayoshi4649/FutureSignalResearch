"""Actor手製のlife正例と外部P予約を、出典asof全体とは分けて算術照合する。"""
from pathlib import Path
from decimal import Decimal
import gzip
import hashlib
import json

import 金融の独立検算 as A
import 新保護の独立監査 as P
import 保有根拠の独立監査 as L
import ライフ状態の独立式 as I

HERE=Path(__file__).resolve().parent
ART=A.ROOT/'work/116突破失敗を返済へ結ぶ会計/人工_独立判定用/買売人工.json.gz'
SHA='8efcdab653b0938ec6dbfe3d144dad8dbf39989642e10ad6af034246cd73ecb5'


def delivered_for_point(entry: dict,point: dict) -> tuple:
    """
    機能: 算術点の5配送を当行/出生から解決し、未解決物理行は別に数える。
    引数: entry/point(dict)。返り値: tuple[dict,bool,bool]は配送値/既知旗/独立解決旗。
    """
    inp=point['input'];five=inp['latest']['scales'][0]
    if not five['has_current']:return {'time':0,'index':0,'source_line':0},False,True
    f=five['current']['frame'];index=f['record_ordinal']-1;birth=entry['birth'];birth_ids={s['current']['frame']['id'] for s in birth['current']['snapshot']['scales'] if s['has_current']}
    if f['id'] in birth_ids:
        line=birth['request']['at']['source_line'] if index==birth['request']['at']['index'] else 0
        return {'time':f['delivery_at'],'index':index,'source_line':line},line>0,True
    if index==inp['stamp']['index']:return {'time':f['delivery_at'],'index':index,'source_line':inp['stamp']['source_line']},True,True
    after=point['snapshot'];decision=point['decision'];names=[]
    if decision['armed_now']:names.append('last_arming')
    if decision['chain_broken_now']:names.append('last_chain_break')
    if decision['invalidated_now']:names.append('invalidation')
    if names:
        w=after[names[0]];d=w['five_delivered'];A.equal((d['time'],d['index']),(f['delivery_at'],index),'手製witness公表時計/Index');A.equal(w['five_delivery_line_known'],d['source_line']>0,'手製witness行既知旗')
        A.need(d['source_line']<=point['quote']['source_line'],'手製witness行は未来でない')
        return d,w['five_delivery_line_known'],False
    return {'time':f['delivery_at'],'index':index,'source_line':0},False,True


def main(target: Path|None=None) -> None:
    """
    機能: Actor72のlife各保存点とP外部予約正例を独立式へ結ぶ。
    引数: target(Path|None)は新規先。返り値: None。完全公表asof/全Raw初回性は別証明。
    """
    b=ART.read_bytes();A.equal(hashlib.sha256(b).hexdigest(),SHA,'Actor手製gzipSHA');data=json.loads(gzip.decompress(b),parse_float=Decimal);A.need(not data['市場'] and not data['FAR自然生成'],'Actor手製のみ')
    life_points=p_resync=unresolved=life_orders=life_fills=0;per=[]
    for side in ('買い','売り'):
        for name,cfg in A.BY_KEY.items():
            book=data[side][name];finance=A.verify_finance(book,cfg)
            for p in book['positions']:
                guards=p['protection113'];orders={o['id']:o for o in book['orders'] if o['position_id']==p['id'] and o.get('lifecycle_point') is not None};traces=guards.get('lifecycle_reservations') or []
                A.equal(len(traces),len(orders),'手製life予約とP再同期一対一')
                own=sum(o['position_id']==p['id'] and (o['protection_point'] is not None or o.get('entry_invalidation_point') is not None) for o in book['orders'])
                A.equal(guards['final_state']['sequence'],guards['evaluations']+guards['resets']+own+len(traces),'手製Pの外部予約sequence保存則')
                for pt in traces:
                    pre=pt['before_snapshot'];post=pt['snapshot'];order=orders[pt['exit_order_id']];A.equal(pt['quote'],None,'P予約再同期は価格を再評価しない');A.equal(post['sequence'],pre['sequence']+1,'P外部予約Advance一回');A.equal(post['reserved'],pre['reserved']+order['quantity'],'P外部予約の数量')
                    P.OLD.verify_exact_point(pre,pt);A.equal(order['lifecycle_point']['after_P100_reservation'],pt,'life実要求とP専用点全値');p_resync+=1
                audit=p.get('lifecycle116')
                if audit is None:continue
                entry=audit['initial']['entry'];seen=set()
                for point in L.collect_points(audit):
                    seq=point['snapshot']['sequence']
                    if seq in seen:continue
                    seen.add(seq);before=point['before_snapshot'];inp=point['input'];delivered,known,independent=delivered_for_point(entry,point);unresolved+=not independent
                    # ----------------------------------------
                    # 当Rawに新Frameが配送されたなら、直前Rawに同IDはあり得ない。
                    # それ以外はRecordOrdinal条件だけでNewFive=falseとなり、前のIDに依存しない。
                    previous=None if not before['initialized'] else {'scales':[{'has_current':False}]}
                    wanted,decision=I.expected_step(before,inp,previous,delivered,known);I.compare(point['snapshot'],wanted,'Actorlife数式After');I.compare(point['decision'],decision,'Actorlife数式Decision');life_points+=1
                ownership=audit['final_ownership'];A.equal(ownership['quote'],p['closed_quote'],'Actor所有完結の実原行');A.equal(ownership['remaining'],0,'Actor所有完結残0');A.equal(ownership['reserved'],0,'Actor所有完結予約0');A.equal(ownership['realized_net'],p['realized_net'],'Actor所有完結R')
                life_orders+=len(orders);life_fills+=len(audit.get('exit_fill_ids') or [])
                per.append({'side':side,'key':name,'position':p['id'],'保存life点':len(seen),'P専用再同期':len(traces),'life要求':len(orders)})
    A.need(p_resync>0 and life_orders>0 and life_fills>0,'新life実要求とP再同期の正例を検査')
    proof={'試行':116,'成功':True,'市場前':True,'Actor圧縮人工Ref':{'path':str(ART),'sha256':SHA},'life保存点の独立1Advance':life_points,'P外部予約exact':p_resync,'life要求':life_orders,'life実fill':life_fills,'公表物理行を点自身の申告へ限定した点':unresolved,'完全公表asofの別証拠':'Core手製216の結合確認.json','全Raw初回性':False,'限界':'Actor手製は完全公表列を持たない。各点の当行RecordOrdinalによるNewFive条件と算術/入力複写を検査し、全asof/物理行出典/連続Raw最初性と区別する。','点別':per,'Raw/自然Native/金融Go再実行':0}
    target=target or HERE/'Actor手製のlife正例とP再同期.json'
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(proof,ensure_ascii=False,indent=2,default=A.BASE.serial)+'\n')
    print(json.dumps({'成功':True,'path':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__=='__main__':main()
