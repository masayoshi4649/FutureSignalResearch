"""新ライフの純数式を、Go期待値なしの手計算で先に固定する。"""
from copy import deepcopy
from decimal import Decimal as D
import unittest

import ライフ状態の独立式 as L


def fixture(policy: str='XC',side: int=1) -> tuple:
    """
    機能: 境界100の維持を確認する、手製の公開状態と実取得Inputを作る。
    引数: policy(str)、side(int)。返り値: tuple[dict,dict]。市場やGoの期待値ではない。
    """
    v=lambda x:{'known':True,'value':x}
    scales=[]
    for width in (300,900,1800):
        scales.append({'width_seconds':width,'has_current':True,'fresh':True,'seed_only':False,'current':{'frame':{'id':str(width)+'初期','end':900,'record_ordinal':5,'price_known':True,'ohlc':{'close':100+side*2},'technical':{'histogram':v(side*2),'ema8':v(100+side*4),'ema21':v(100)}},'dmi':{'plus_di':v(5+side),'minus_di':v(5-side)}}})
    e={'policy':policy,'side':side,'birth':{'common':2,'values':{'boundary':100,'d15':2,'g30':4}},'fill_stamp':{'time':1000,'index':10,'source_line':11}}
    before={'version':116,'entry':e,'definition':{'version':116},'initialized':False,'at':None,'sequence':0,'monitoring_eligible':True,'armed':False,'warning':False,'disabled_by_P100':False,'latched':False,'first_arming':None,'last_arming':None,'last_chain_break':None,'invalidation':None,'arming_count':0,'chain_break_count':0}
    inp={'stamp':deepcopy(e['fill_stamp']),'phase':'after_source','latest':{'scales':scales,'record_ordinal':11},'bid':102 if side==1 else 97,'ask':103 if side==1 else 98,'quote_ok':True,'remaining':3,'reserved':0,'P100_active':False}
    return before,inp


def next_input(inp: dict,newfive: bool=True,close: int=99,hist: int=0,side: int=1) -> dict:
    """
    機能: 同5公表または取得後の新5公表を含む次原行を作る。
    引数: inp(dict)、newfive(bool)、close/hist/side(int)。返り値: dictは独立Input。
    """
    result=deepcopy(inp);s=result['stamp'];s['time']+=100;s['index']+=1;s['source_line']+=1;result['latest']['record_ordinal']=s['index']+1
    if newfive:
        f=result['latest']['scales'][0]['current']['frame'];f['id']='取得後'+str(s['index']);f['end']=1001;f['record_ordinal']=s['index']+1;f['ohlc']['close']=close;f['technical']['histogram']['value']=hist
    return result


def step(before: dict,inp: dict,previous: dict|None=None) -> tuple:
    """
    機能: 人工の5公表配送stampを用いて独立1Advanceだけを計算する。
    引数: before/ inp(dict)、previous(dict|None)。返り値: tuple[Snapshot,Decision]。
    """
    return L.expected_step(before,inp,previous,{'time':900,'index':4,'source_line':0},False)


class Tests(unittest.TestCase):
    """手計算のライフ10主人工。"""

    def test_birth_and_initial_arming(self):
        """
        機能: 監視適格と初期四票を確認し、X0を追加返済へ偽装しない。
        引数: self(Tests)。返り値: None。
        """
        before,inp=fixture();out,d=step(before,inp);self.assertTrue(out['armed']);self.assertTrue(d['armed_now']);self.assertEqual(out['arming_count'],1)
        for policy in ('X0','XC','XQ'):
            a,i=fixture(policy);a['entry']['birth']['values']['g30']=0;a['monitoring_eligible']=False;o,d=step(a,i);self.assertFalse(o['armed']);self.assertEqual(d['arming_condition'],1);self.assertEqual(d['exit_eligible_quantity'],0)

    def test_zero_hist_never_arms_and_old_frame_no_later_arm(self):
        """
        機能: Hist0と後armに取得後5公表が要る条件を手計算する。
        引数: self(Tests)。返り値: None。
        """
        before,inp=fixture();inp['latest']['scales'][0]['current']['frame']['technical']['histogram']['value']=0;out,d=step(before,inp);self.assertFalse(out['armed']);self.assertEqual(d['arming_condition'],1)
        later=next_input(inp,False);later['latest']['scales'][0]['current']['frame']['technical']['histogram']['value']=2;out2,d=step(out,later,inp['latest']);self.assertFalse(out2['armed']);self.assertFalse(d['post_entry_five'])

    def test_xc_bad_bbo_latch_and_recovery_irreversible(self):
        """
        機能: XCは新5Close/Histで異常BBOでもラッチし、回復やP100でも撤回しない。
        引数: self(Tests)。返り値: None。
        """
        before,inp=fixture();out,_=step(before,inp);bad=next_input(inp);bad['bid']=bad['ask']=0;out2,d=step(out,bad,inp['latest']);self.assertTrue(out2['latched']);self.assertTrue(d['invalidated_now']);self.assertEqual(d['exit_eligible_quantity'],0)
        good=next_input(bad,True,close=103,hist=2);good['bid']=102;good['ask']=103;good['reserved']=1;good['P100_active']=True;out3,d=step(out2,good,bad['latest']);self.assertTrue(out3['latched']);self.assertEqual(d['exit_eligible_quantity'],2);self.assertFalse(out3['disabled_by_P100'])

    def test_xq_normal_raw_during_warning(self):
        """
        機能: XQは最新5警戒中のBBO内戻りで発火し、異常BBOだけでは鎖を切らない。
        引数: self(Tests)。返り値: None。
        """
        before,inp=fixture('XQ');out,_=step(before,inp);warn=next_input(inp,close=102,hist=0);warn['bid']=warn['ask']=0;out2,d=step(out,warn,inp['latest']);self.assertTrue(out2['armed']);self.assertTrue(out2['warning']);self.assertFalse(out2['latched'])
        normal=next_input(warn,False);normal['bid']=99;normal['ask']=100;out3,d=step(out2,normal,warn['latest']);self.assertTrue(out3['latched']);self.assertEqual(d['exit_eligible_quantity'],3)

    def test_strict_boundary_equality(self):
        """
        機能: Close/BBOの境界等号は内側へ含めず、Hist0だけ警戒へ含める。
        引数: self(Tests)。返り値: None。
        """
        for policy in ('XC','XQ'):
            before,inp=fixture(policy);out,_=step(before,inp);warn=next_input(inp,close=100,hist=0);warn['bid']=100;warn['ask']=101;out2,d=step(out,warn,inp['latest']);self.assertTrue(out2['warning']);self.assertFalse(out2['latched'])

    def test_unknown_and_fresh_reset(self):
        """
        機能: 実使用Unknown/古さだけで未完成armedを切り、完成済みは保持する。
        引数: self(Tests)。返り値: None。
        """
        for mode in ('unknown','stale'):
            before,inp=fixture();out,_=step(before,inp);bad=next_input(inp)
            if mode=='unknown':bad['latest']['scales'][1]['current']['dmi']['plus_di']['known']=False
            else:bad['latest']['scales'][2]['fresh']=False
            out2,d=step(out,bad,inp['latest']);self.assertFalse(out2['armed']);self.assertTrue(d['chain_broken_now']);self.assertEqual(out2['chain_break_count'],1)

    def test_known_direction_reversal_does_not_break(self):
        """
        機能: DI/30Gの既知逆転だけでarmedを解除しない。
        引数: self(Tests)。返り値: None。
        """
        before,inp=fixture();out,_=step(before,inp);bad=next_input(inp,close=102,hist=2);bad['latest']['scales'][1]['current']['dmi']['plus_di']['value']=1;bad['latest']['scales'][2]['current']['frame']['technical']['ema8']['value']=95;out2,d=step(out,bad,inp['latest']);self.assertTrue(out2['armed']);self.assertFalse(d['chain_broken_now']);self.assertFalse(out2['latched'])

    def test_p100_priority_and_all_reserved(self):
        """
        機能: 未ラッチのP100先起動を優先し、既ラッチ全予約は完成と数量0を分ける。
        引数: self(Tests)。返り値: None。
        """
        before,inp=fixture();out,_=step(before,inp);bad=next_input(inp);bad['P100_active']=True;out2,d=step(out,bad,inp['latest']);self.assertTrue(out2['disabled_by_P100']);self.assertFalse(out2['latched'])
        out['latched']=True;bad['reserved']=bad['remaining'];out3,d=step(out,bad,inp['latest']);self.assertTrue(out3['latched']);self.assertEqual(d['exit_eligible_quantity'],0)

    def test_mirror_and_reference_separation(self):
        """
        機能: 売買対称の発火とwitnessの参照分離を確認する。
        引数: self(Tests)。返り値: None。
        """
        for side in (1,-1):
            before,inp=fixture(side=side);original=deepcopy((before,inp));out,_=step(before,inp);bad=next_input(inp,close=100-side,hist=0);o,d=step(out,bad,inp['latest']);self.assertTrue(o['latched']);self.assertEqual((before,inp),original);o['invalidation']['input']['latest']['scales'][0]['current']['frame']['ohlc']['close']=0;self.assertNotEqual(bad['latest']['scales'][0]['current']['frame']['ohlc']['close'],0)

    def test_latest_only_gap_not_synthetic_break(self):
        """
        機能: 公表Endの跳びだけで中間足を遡及評価せず、最終latestの既知性を使う。
        引数: self(Tests)。返り値: None。
        """
        before,inp=fixture();out,_=step(before,inp);later=next_input(inp,close=102,hist=2);later['latest']['scales'][0]['current']['frame']['end']=1500;o,d=step(out,later,inp['latest']);self.assertFalse(d['chain_broken_now']);self.assertFalse(d['armed_now']);self.assertTrue(o['armed']);self.assertEqual(o['arming_count'],1)


if __name__=='__main__':unittest.main(verbosity=2)
