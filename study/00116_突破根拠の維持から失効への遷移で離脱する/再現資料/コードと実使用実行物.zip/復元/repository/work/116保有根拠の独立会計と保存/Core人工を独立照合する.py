"""Core116の全公表付き手製216冊を独立監査し、Viewerも再読する。"""
from collections import Counter
from pathlib import Path
from decimal import Decimal
import gzip
import hashlib
import json
import tempfile

import 保存集計の共通部 as S
import 入口の独立検算 as E
import 新保護の独立監査 as P
import 保有根拠の独立監査 as L

HERE=Path(__file__).resolve().parent
ART=S.ROOT/'work/116保有根拠の連続比較/人工_入口と保有/人工の参照.json'
ART_SHA='f646495b0d315199b768a4905d1fdfb5b7208e5417d1f8d33006f7ec5d273663'


def read(ref: dict) -> dict:
    """
    機能: Rootが公開したCore手製だけをSHA認証して読む。
    引数: ref(dict)。返り値: dictは十進数の手製値。自然Nativeは読まない。
    """
    p=Path(ref['path']);b=p.read_bytes();S.equal(hashlib.sha256(b).hexdigest(),ref['sha256'],'Core手製SHA')
    return json.loads(gzip.decompress(b) if p.suffix=='.gz' else b,parse_float=Decimal)


def main(target: Path|None=None) -> None:
    """
    機能: 全216の会計/P/入口/life/asof/所有と216Viewer資源を結合する。
    引数: target(Path|None)は新規保存先。返り値: None。全Raw最初性と自然Sourceは別証明。
    """
    manifest=read({'path':str(ART),'sha256':ART_SHA});S.need(manifest['人工'] and not manifest['市場'] and not manifest['FAR自然生成'],'Root手製だけ')
    value=read(manifest['圧縮']);S.need(value['人工'] and not value['市場'] and not value['FAR自然生成'],'手製の範囲を維持')
    total=resources=0;pc=Counter();lc=Counter();scenes=[];entry=0
    for name,native in value['results'].items():
        checked=S.inspect_scene(native,None,P,E,L,True);S.equal(len(checked['checked']),36,'Core人工各36')
        for key,result in checked['checked'].items():
            row=S.summarize_book(native['actual']['books'][key],result);S.equal(sum(v['返済片純額'] for v in row['注文別'].values()),row['net_yen'],'Core人工の新旧返済役割加法');pc.update(result['protection_counts']['counts']);lc.update(result['lifecycle_counts']['counts']);total+=1
        entry+=checked['entry_scene']['全Source延べ票']
        with tempfile.TemporaryDirectory(dir=HERE) as tmp:
            out=Path(tmp);catalog=S.save_viewer(native,out,'人工の価格参照だけ');viewer=S.verify_viewer(native,out,catalog);S.equal(len(catalog),36,'人工Viewer36');resources+=len(catalog)
        scenes.append({'id':name,'会計':36,'入口/共通P/ライフ/公表asof成功':True,'旧115独立Native対照':checked['reference115']['comparisons'],'自然Source生成証明':False,'Viewer':viewer})
    S.equal(len(scenes),6,'Core手製6系列');S.equal(total,216,'Core手製216会計');S.equal(resources,216,'Core手製216Viewer')
    proof={'試行':116,'成功':True,'市場前':True,'Core人工参照':{'path':str(ART),'sha256':ART_SHA},'圧縮Ref':manifest['圧縮'],'系列数':6,'会計数':total,'Viewer資源':resources,'入口票':entry,'P保存検査':dict(pc),'ライフ保存検査':dict(lc),'系列':scenes,'全Raw発生漏れ/初回性監査':False,'自然Source生成証明':False,'旧115対照':'Coreは旧Native本文を同梱しないため0。別Actor手製72で旧115全24を独立照合済み。','Raw/新自然Native/金融Go再走':0}
    target=target or HERE/'Core手製216の結合確認.json'
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(proof,ensure_ascii=False,indent=2,default=S.BASE.serial)+'\n')
    print(json.dumps({'成功':True,'path':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__=='__main__':main()
