"""人工/全所有依存同体の停止前確認と、Rootレビュー後だけの正式停止を分離する。"""
from pathlib import Path
from types import ModuleType
import argparse
import hashlib
import importlib
import json
import os
import subprocess
import sys
from datetime import datetime,timezone

import 保存集計の共通部 as S
import 入口の独立検算 as E
import 新保護の独立監査 as P
import 保有根拠の独立監査 as L

HERE=Path(__file__).resolve().parent
STOPS={
    '純ライフ':(S.ROOT/'work/116突破根拠の維持と失効/停止.json','bf808c3d034d148f470230e3248443174fd9f22cedb571293b6e95020e72e296'),
    'Actor':(S.ROOT/'work/116突破失敗を返済へ結ぶ会計/Actor停止.json','d5a1f5c3d30109b54173b1f8179152e671ced89830aa855a02bc42f24f2a89e1'),
    'Core':(S.ROOT/'work/116保有根拠の連続比較/停止.json','c080ce6fb520385acdb88c8b0efe65690c8cd0a17593859ac9b9f9691c713cbe'),
    '入口115':(S.ROOT/'work/115入口判定を独立検算する/停止.json','d7518d60e73e62b68e025e2bff50adec42dbd111ede7e075e365a8b0076df79e')}
INPUTS={
    S.ROOT/'work/116突破根拠の維持と失効/人工_接続前/人工の参照.json':'47bcaa3f06b016473de29b86f8163759c11fd0004b526f603d1c2eb1717c8e33',
    S.ROOT/'work/116突破根拠の維持と失効/人工_接続前/ライフ系列.json':'1e3048779019cc59759b0cfdf8297faee94c3ffb621fa38e71a82aa476203284',
    S.ROOT/'work/116突破失敗を返済へ結ぶ会計/人工_独立判定用/買売人工.json.gz':'8efcdab653b0938ec6dbfe3d144dad8dbf39989642e10ad6af034246cd73ecb5',
    S.ROOT/'work/116保有根拠の連続比較/人工_入口と保有/人工の参照.json':'f646495b0d315199b768a4905d1fdfb5b7208e5417d1f8d33006f7ec5d273663',
    S.ROOT/'work/116保有根拠の連続比較/人工_入口と保有/Core人工.json.gz':'ed12f151258f68d24dde66c9dee109d45ece19bc84c3dbaec817ed464ff9a8d6',
    S.ROOT/'work/116保有根拠の連続比較/人工_失効と所有/人工の参照.json':'c5cde3741e193ac3dac6e0e40980405783f77aaed3dcce1558396551f6d3d46c',
    S.ROOT/'work/116保有根拠の連続比較/人工_失効と所有/Core失効人工.json.gz':'d93abd1795f3fac86fa099b0d2608207e946922ed8fcb3120b29f72826cb960b',
    S.ROOT/'work/115三時間軸の複合入口の連続比較/人工_入口独立用/Core人工.json':'4ff53c2bed94c512c6c3c39695d9eb57748076bd6bc885da15f7e13d6e0daa9e'}


def write(path: Path,value: dict) -> dict:
    """
    機能: 証拠を上書きせず保存してFileRefを返す。
    引数: path(Path)、value(dict)。返り値: dictは絶対path/sha256。
    """
    with path.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2,default=S.BASE.serial)+'\n')
    return {'path':str(path.resolve()),'sha256':S.digest(path)}


def codes() -> tuple[dict,dict]:
    """
    機能: 新所有全コードと実importした旧Python/停止済みGoの閉包を指紋化する。
    引数: なし。返り値: tuple[dict,dict]は所有/再用コード。市場本文は対象外。
    """
    owned={str(p.resolve()):S.digest(p) for p in sorted(HERE.iterdir()) if p.is_file() and p.suffix in ('.py','.md')};reused={};seen=set();queue=[S,E,P,L]
    while queue:
        module=queue.pop()
        if id(module) in seen:continue
        seen.add(id(module));path=getattr(module,'__file__',None)
        if path:
            p=Path(path).resolve()
            if p.suffix=='.py' and S.ROOT in p.parents and p.parent!=HERE:reused[str(p)]=S.digest(p)
        queue.extend(v for v in vars(module).values() if isinstance(v,ModuleType) and getattr(v,'__file__',None) and S.ROOT in Path(v.__file__).resolve().parents)
    for name,(path,sha) in STOPS.items():
        S.equal(S.digest(path),sha,'既停止metadataの同体/'+name);reused[str(path.resolve())]=sha;stop=S.load(path)
        for key in ('全固定コードSHA256','Go閉包SHA256','実Go依存SHA256','所有コードSHA256','依存コードSHA256','所有ファイルSHA256','再用ファイルSHA256'):
            for filename,expected in stop.get(key,{}).items():
                p=Path(filename);p=(p if p.is_absolute() else S.ROOT/p).resolve();S.need(p.suffix not in ('.csv','.gz','.jsonl'),'市場本文をコード閉包に混ぜない');actual=S.digest(p);S.equal(actual,expected,'既停止コード不変/'+str(p))
                if str(p) not in owned:reused[str(p)]=actual
    return dict(sorted(owned.items())),dict(sorted(reused.items()))


def inputs() -> dict:
    """
    機能: 明示人工だけの入力指紋を確認する。
    引数: なし。返り値: dict。自然Native/Raw/価格CSVを読まない。
    """
    result={}
    for p,sha in INPUTS.items():S.equal(S.digest(p),sha,'手製入力SHA');result[str(p.resolve())]=sha
    return result


def command(args: list[str]) -> dict:
    """
    機能: 人工Pythonだけを別processで実行し失敗を伝播する。
    引数: args(list[str])。返り値: dictはstdout/stderr/exit。市場Goは呼ばない。
    """
    env={**os.environ,'PYTHONIOENCODING':'utf-8'};r=subprocess.run([sys.executable,*args],cwd=HERE,env=env,capture_output=True,text=True,encoding='utf-8')
    if r.returncode!=0:raise ValueError('人工CLI不成功: '+str(args)+'\n'+r.stdout+'\n'+r.stderr)
    return {'command':[sys.executable,*args],'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr}


def check(output: Path) -> dict:
    """
    機能: 全人工を新しい証拠先へ再実行し、所有/旧停止依存/人工入力の前後同体を保存する。
    引数: output(Path)は新規絶対位置。返り値: dictはRootレビュー用Ref。正式停止は作らない。
    """
    S.need(output.is_absolute() and not output.exists(),'停止前確認の新規絶対位置');owned,reused=codes();art=inputs();output.mkdir(parents=True);logs=[]
    logs.append(command(['-m','unittest','-v','ライフの人工検査','会計の人工検査','入力ゲートの人工検査','保存点を破壊する人工検査']))
    results={}
    for module,label in [('純Go人工を独立照合する','純48'),('Actor人工の会計を検査する','Actor72会計'),('Actor保存点の算術を検査する','Actor120life48予約'),('Core人工を独立照合する','Core216'),('Core失効正例を独立照合する','Core72正例')]:
        path=output/(label+'.json');logs.append(command(['-c','from pathlib import Path; import sys; import '+module+' as M; M.main(Path(sys.argv[1]))',str(path)]));results[label]={'path':str(path),'sha256':S.digest(path)}
    after_owned,after_reused=codes();S.equal(after_owned,owned,'新Python全所有前後同体');S.equal(after_reused,reused,'旧固定全依存前後同体');S.equal(inputs(),art,'人工全入力前後同体')
    proof={'試行':116,'成功':True,'市場前':True,'停止':False,'Rootレビュー前':True,'UTC':datetime.now(timezone.utc).isoformat(),'主人工':20,'手計算10/旧接続4/保存点破壊3/入力ゲート3':True,'所有ファイルSHA256':owned,'依存コードSHA256':reused,'人工入力SHA256':art,'所有コードSHA256前':owned,'所有コードSHA256後':after_owned,'依存コードSHA256前':reused,'依存コードSHA256後':after_reused,'前後不変':True,'人工結果':results,'実行ログ':logs,'全Raw初回性':False,'Raw/新自然Native/価格CSV/11月09本文':False,'金融再実行':False,'採用':False}
    return write(output/'停止前の確認.json',proof)


def stop(review: Path,sha: str) -> dict:
    """
    機能: Rootレビュー済み確認のコード/人工/全依存同体を再確認し、初回停止だけを保存する。
    引数: review(Path)、sha(str)。返り値: dictはP/life/会計停止Ref。人工結果や旧停止は変更しない。
    """
    S.equal(S.digest(review),sha,'Rootレビュー対象確認SHA');proof=S.load(review);S.need(proof['成功'] and proof['市場前'] and proof['試行']==116 and proof['停止'] is False and proof['前後不変'],'同一の停止前確認')
    owned,reused=codes();S.equal(owned,proof['所有ファイルSHA256'],'レビュー後新所有不変');S.equal(reused,proof['依存コードSHA256'],'レビュー後旧固定依存不変');S.equal(inputs(),proof['人工入力SHA256'],'レビュー後人工入力不変')
    for r in proof['人工結果'].values():S.equal(S.digest(Path(r['path'])),r['sha256'],'レビュー後人工証拠不変')
    targets=[HERE/'P停止.json',HERE/'ライフ停止.json',HERE/'会計停止.json'];S.need(not any(p.exists() for p in targets),'停止は初回だけ。既存停止は変更しない')
    base={'試行':116,'成功':True,'停止':True,'市場前':True,'停止UTC':datetime.now(timezone.utc).isoformat(),'前後不変':True,'停止前確認':{'path':str(review.resolve()),'sha256':sha},'依存コードSHA256':reused,'人工結果':proof['人工結果'],'全Rawライフ発生漏れ/初回性監査':False,'自然FAR生成証明':False,'市場/Raw/新自然Native/価格CSV/11月09本文':False,'研究目標達成':False,'採用':False}
    pstop=write(targets[0],{**base,'所有ファイルSHA256':{str(HERE/'新保護の独立監査.py'):owned[str(HERE/'新保護の独立監査.py')]},'実API':'verify_protection(book,config,finance,context)->dict','元有理数P113監査':True,'life外部予約は別exact':True})
    lstop=write(targets[1],{**base,'所有ファイルSHA256':{str(HERE/name):owned[str(HERE/name)] for name in ('ライフ状態の独立式.py','保有根拠の独立監査.py')},'実API':'verify_lifecycle(book,config,finance,context)->dict','純Go停止':{'path':str(STOPS['純ライフ'][0]),'sha256':STOPS['純ライフ'][1]},'保存点1Advanceと全公表asofの検査':True,'全Raw最初性は別Root要求':True})
    cstop=write(targets[2],{**base,'所有ファイルSHA256':owned,'P停止':pstop,'ライフ停止':lstop,'Actor停止':{'path':str(STOPS['Actor'][0]),'sha256':STOPS['Actor'][1]},'入口115停止':{'path':str(STOPS['入口115'][0]),'sha256':STOPS['入口115'][1]},'実API':'保存する.py --fixed ABS --sha256 SHA --output NEWABS [--metadata-only]','会計数':'36×N','旧115対照':'12×N、X0全金融/入口/P100State','Raw権限':False})
    return {'成功':True,'P停止':pstop,'ライフ停止':lstop,'会計停止':cstop}


def main() -> None:
    """
    機能: 人工チェックとRootレビュー後停止を別CLIとして扱う。
    引数: CLI check-output(Path)またはstop(bool)/review(Path)/review-sha(str)。返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--check-output',type=Path);parser.add_argument('--stop',action='store_true');parser.add_argument('--review',type=Path);parser.add_argument('--review-sha');a=parser.parse_args()
    if a.stop:S.need(a.check_output is None and a.review is not None and a.review_sha,'Rootレビュー済み確認の指定が必要');value=stop(a.review,a.review_sha)
    else:S.need(a.check_output is not None and a.review is None and a.review_sha is None,'停止前確認先だけを指定');value=check(a.check_output)
    print(json.dumps(value,ensure_ascii=False))


if __name__=='__main__':main()
