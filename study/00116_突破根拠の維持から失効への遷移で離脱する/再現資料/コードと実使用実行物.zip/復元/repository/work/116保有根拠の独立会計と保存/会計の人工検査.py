"""116の新Go器具待ちにも金融/入口/P100の既同体接続を人工だけで確認する。"""
from copy import deepcopy
from pathlib import Path
import gzip
import hashlib
import json
import unittest

import 金融の独立検算 as A
import 入口の独立検算 as E
import 新保護の独立監査 as P
import 保存集計の共通部 as S

ART=S.ROOT/'work/115三時間軸の複合入口の連続比較/人工_入口独立用/Core人工.json'
ART_SHA='4ff53c2bed94c512c6c3c39695d9eb57748076bd6bc885da15f7e13d6e0daa9e'


def fixtures() -> list[dict]:
    """
    機能: 既存Go115の市場ではない6器具だけを指紋認証して読む。
    引数: なし。返り値: list[dict]。新116Goや自然Sourceの実証ではない。
    """
    b=ART.read_bytes();A.equal(hashlib.sha256(b).hexdigest(),ART_SHA,'人工115指紋');m=json.loads(b,parse_float=A.BASE.Decimal);A.need(m['人工'] and not m['市場'],'明示人工だけ')
    return list(m['results'].values())


def x0_fixture(book: dict) -> dict:
    """
    機能: 同体対照の許可説明差life_modeとScopeだけを人工的に付ける。
    引数: book(dict)は旧115手製book。返り値: dict。116Actor実出力と偽装しない。
    """
    result=deepcopy(book);result['config']['life_mode']='X0';result['stream_scope']=S.SCOPE116
    return result


class Tests(unittest.TestCase):
    """116市場前の接続人工。新Actor/Core器具は後で別主へ追加する。"""

    def test_declared36_and_real_names(self):
        """
        機能: Life→Entry→C→Dの36順序とX0/新2群の実名を確認する。
        引数: self(Tests)。返り値: None。
        """
        self.assertEqual(len(A.CONFIGS),36);self.assertEqual(len(set(A.KEYS)),36);self.assertEqual(A.KEYS[0],'A0_C0_D0');self.assertEqual(A.KEYS[12],'A0_XC_C0_D0');self.assertEqual(A.KEYS[24],'A0_XQ_C0_D0')
        c=deepcopy(A.CONFIGS[0]);c['life_mode']='X9'
        with self.assertRaises(ValueError):A.key_for(c)

    def test_old_go72_finance_entry_p100_same(self):
        """
        機能: 旧Go手製72冊へ許可説明差だけを加え金融/P100/入口と旧全値を確認する。
        引数: self(Tests)。返り値: None。新116Go出力という主張ではない。
        """
        count=0
        for native in fixtures():
            for old in native['actual']['books'].values():
                b=x0_fixture(old);cfg=b['config'];finance=A.verify_finance(b,cfg);pr=P.verify_protection(b,cfg,finance,native['actual']);en=E.verify_entry_gate(b,cfg,native['actual']);proof=S.compare_book115(b,old)
                self.assertTrue(pr['complete']);self.assertTrue(en['成功']);self.assertTrue(proof['all_financial_equal']);self.assertEqual(finance['totals']['net_yen'],old['totals']['net_yen']);count+=1
        self.assertEqual(count,72)

    def test_financial_corruptions(self):
        """
        機能: 価格/費用/物理行/配賦/Source件数の破壊を同体接続が拒否する。
        引数: self(Tests)。返り値: None。
        """
        native=fixtures()[0];old=next(b for b in native['actual']['books'].values() if b['positions'])
        for field in ('fee','price','allocation','line','source_count'):
            b=x0_fixture(old)
            if field=='fee':b['fills'][0]['fee_yen']+=1
            elif field=='price':b['fills'][0]['price']+=5
            elif field=='allocation':b['fills'][-1]['allocations'][0]['net_yen']+=1
            elif field=='line':b['fills'][0]['quote']['source_line']=b['orders'][0]['request_quote']['source_line']
            else:b['metrics']['source_exit_requests']+=1
            with self.subTest(field=field),self.assertRaises(ValueError):A.verify_finance(b,b['config'])

    def test_x0_cannot_hide_new_life_or_finance(self):
        """
        機能: X0の新life有効値や旧金融差を説明差として除外しない。
        引数: self(Tests)。返り値: None。
        """
        native=fixtures()[0];old=next(b for b in native['actual']['books'].values() if b['positions'])
        for field in ('life','metric','finance','decision'):
            b=x0_fixture(old)
            if field=='life':b['positions'][0]['lifecycle116']={'latched':False}
            elif field=='metric':b['metrics']['lifecycle_exit_requests']=0
            elif field=='finance':b['positions'][0]['realized_net']+=1
            else:b['entry_gate']['records'][0]['decision']['values']['g30']=None
            with self.subTest(field=field),self.assertRaises(ValueError):S.compare_book115(b,old)


if __name__=='__main__':unittest.main(verbosity=2)
