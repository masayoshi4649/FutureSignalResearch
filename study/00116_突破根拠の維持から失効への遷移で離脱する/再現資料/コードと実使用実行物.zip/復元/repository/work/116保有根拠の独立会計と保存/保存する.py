"""Root成功要求の116だけを独立会計/P/入口/life監査して保存する。Rawは読まない。"""
from collections import Counter
from pathlib import Path
import argparse
import json

import 保存集計の共通部 as S
import 保存の入力ゲート as G
import 入口の独立検算 as E
import 新保護の独立監査 as P
import 保有根拠の独立監査 as L


def run(plan: dict,root_ref: dict) -> dict:
    """
    機能: 認証済み同stageの36N全会計と旧115全12Nを保存・Viewer再読する。
    引数: plan/root_ref(dict)。返り値: dictは件数と結果Ref。金融Go/Raw再走は0。
    """
    out=plan['output'];out.mkdir(parents=True,exist_ok=False);rows=[];sources=[];references=[];native_refs=[];resources=[];viewer=[]
    for task in plan['tasks']:
        native=S.load(G.reference(task['native'],plan['before']));prior=S.load(G.reference(task['reference115'],plan['before']));trace=native['reference115']
        S.need(G.same_ref(trace['reference'],task['reference115']),'旧115の当場Native出典');S.equal(trace['before_sha256'],task['reference115']['sha256'],'旧115前指紋');S.equal(trace['after_sha256'],task['reference115']['sha256'],'旧115後指紋')
        S.equal(native['actual']['lifecycle_definition'],plan['definition'],'実Nativeの同F1ライフ定義');checked=S.inspect_scene(native,prior,P,E,L)
        sid=task['session'];S.equal(native['actual']['scope']['session']['id'],sid,'当場Native')
        for key in S.KEYS:
            stat=S.summarize_book(native['actual']['books'][key],checked['checked'][key]);stat['入口票検査']=checked['entry'][key]
            rows.append({'session':sid,'key':key,'history_class':task['history_class'],**stat})
        sources.append({'session':sid,**checked['source']});references.append({'session':sid,'reference':task['reference115'],**checked['reference115']});native_refs.append({'session':sid,**task['native'],'reference115':task['reference115']})
        scene_resources=S.save_viewer(native,out,task['market_path']);viewer.append({'session':sid,**S.verify_viewer(native,out,scene_resources)});resources.extend(scene_resources)
    summary={k:S.combine([r for r in rows if r['key']==k]) for k in S.KEYS}
    entry_summary={k:dict(sum((Counter(r['入口票検査']['counts']) for r in rows if r['key']==k),Counter())) for k in S.KEYS}
    life_summary={k:dict(sum((Counter(r['保有根拠の独立検査']['counts']) for r in rows if r['key']==k),Counter())) for k in S.KEYS}
    after={p:S.digest(Path(p)) for p in plan['before']};S.equal(after,plan['before'],'全入力/旧115/コード前後不変')
    q=plan['request'];proofs={'stage':q['stage'],'Root保存要求SHA256':root_ref['sha256'],'金融条件SHA256':q['condition']['sha256'],'金融完了SHA256':q['completion']['sha256'],'保存器停止SHA256':q['code_stop']['sha256'],'独立P停止SHA256':q['P_stop']['sha256'],'独立ライフ停止SHA256':q['life_stop']['sha256'],'Actor停止SHA256':q['actor_stop']['sha256'],'純ライフ停止SHA256':q['lifecycle_go_stop']['sha256'],'入口115独立停止SHA256':q['entry115_stop']['sha256']}
    result={'試行':116,'成功':True,**proofs,'場数':len(plan['tasks']),'会計数':len(rows),'主key':list(S.KEYS),'Actor設定':{k:{'candidate':k,'entry_timing':'元Source連続時計',**c} for k,c in S.BY_KEY.items()},'保護定義':{'P100':S.OLD.OLD.definition('P100')},'保有根拠定義':plan['definition'],'集計':summary,'入口票集計':entry_summary,'保有根拠検査集計':life_summary,'場別':rows,'元Source対照':sources,'旧115対照':references,'Native参照':native_refs,'Viewer形式資源':len(resources),'Viewer保存再読':viewer,'入力codeSHA256前':plan['before'],'入力codeSHA256後':after,'前後不変':True,'勝率定義':'正益完結実玉/全完結実玉。同値も分母、平均損失は負、分母0比率はnull。','頻度定義':'原行数・実新規・実保有時間・数量秒。固定時計の参加率や機会損失は作らない。','全Rawライフ発生漏れ/初回性監査':False,'限界':['全実会計/所有/費用/後原行/保存DD、全入口票、公表asof、少数P/life保存点を照合する。','life保存点の1Advance exactを、全Rawの発生漏れや最初の正常BBOの独立証明と呼ばない。別Root Raw要求の監査が必要。','n0原行ではpureを評価せず、最後の保有中純状態とFinalOwnershipを別証明する。','ラージ板を使ったmini模型であり、実mini約定や未知期間の安定性は未証明。'],'未実施':{'Raw/価格CSV/11月09本文':0,'Go/Source/金融再実行':0,'HTTP/CSV生成/退出後仮想利益/機会損失':0},'研究目標達成':False,'採用':False}
    S.BASE.write_json(out/'結果.json',result);S.BASE.write_json(out/'一覧.resources.json',{'schema_version':1,'path_base':'catalog','resources':resources})
    files={p.name:S.digest(p) for p in sorted(out.iterdir()) if p.is_file()}
    checked={'試行':116,'成功':True,**proofs,'場数':len(plan['tasks']),'会計数':len(rows),'資源':len(resources),'X0全金融比較':12*len(plan['tasks']),'旧115全金融比較':12*len(plan['tasks']),'全Source111同体':True,'全残玉予約0':True,'不一致数':0,'全Rawライフ発生漏れ/初回性監査':False,'入力codeSHA256前':plan['before'],'入力codeSHA256後':after,'前後不変':True,'出力SHA256':files,'研究目標達成':False,'採用':False}
    S.BASE.write_json(out/'保存会計の確認.json',checked)
    return {'成功':True,'stage':q['stage'],'場数':len(plan['tasks']),'会計数':len(rows),'Viewer資源':len(resources),'結果':{'path':str((out/'結果.json').resolve()),'sha256':files['結果.json']}}


def main() -> None:
    """
    機能: Rootの新金融成功要求からだけ独立保存し、metadata-onlyは本文を読まない。
    引数: CLI fixed/sha256/output(str)、metadata-only(bool)。返り値: None。
    """
    p=argparse.ArgumentParser();p.add_argument('--fixed',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--metadata-only',action='store_true');a=p.parse_args();plan=G.prepare(a.fixed,a.sha256,a.output)
    if a.metadata_only:print(json.dumps({'成功':True,'Native本文読取':False,'場数':len(plan['tasks'])},ensure_ascii=False));return
    print(json.dumps(run(plan,{'path':str(a.fixed.resolve()),'sha256':a.sha256}),ensure_ascii=False))


if __name__=='__main__':main()
