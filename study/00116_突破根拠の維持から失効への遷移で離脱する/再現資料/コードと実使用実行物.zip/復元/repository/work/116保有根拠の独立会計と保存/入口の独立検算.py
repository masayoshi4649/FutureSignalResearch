"""入口115の独立数式を保持し、116の36本名口座と全Source分母へ接続する。"""
from pathlib import Path
from types import FunctionType
import hashlib
import importlib.util
import sys

import 金融の独立検算 as A

ROOT=Path(__file__).resolve().parents[2]
PRIOR=ROOT/'work/115入口判定を独立検算する/検算する.py'
PRIOR_SHA='7195ce4420b835117630f0e5e03a657bd768f26308707e9ec35dd771c2c8fa24'
if hashlib.sha256(PRIOR.read_bytes()).hexdigest()!=PRIOR_SHA:raise ValueError('停止115入口独立算術SHA差')
spec=importlib.util.spec_from_file_location('116が再用する停止115入口検算',PRIOR);OLD=importlib.util.module_from_spec(spec)
sys.path.insert(0,str(PRIOR.parent))
try:spec.loader.exec_module(OLD)
finally:sys.path.pop(0)
_VERIFY=FunctionType(OLD.verify_entry_gate.__code__,{**OLD.verify_entry_gate.__globals__,'CONFIGS':A.CONFIGS},'116本名36へ入口115数式接続',OLD.verify_entry_gate.__defaults__,OLD.verify_entry_gate.__closure__)


def verify_entry_gate(book: dict,config: dict,context: dict) -> dict:
    """
    機能: 本名116を保ち、115の票/三値/公表asof/Source/実受付/取得を無変更算術で検算する。
    引数: book/config/context(dict)。返り値: dictは停止115と同じ件数・限界。
    """
    A.equal(book['key'],A.key_for(config),'116入口の本名key')
    return _VERIFY(book,config,context)


def verify_scene(native: dict,artificial: bool=False) -> dict:
    """
    機能: 全36でSource出生と要求固定票を同体照合し、取得/返済life作用と分ける。
    引数: native(dict)、artificial(bool)。返り値: dictは36票監査とSource全分母。
    """
    actual=native['actual'];A.need(native['trial']==actual['trial']==116 and actual['complete'],'116の本名完結Native')
    A.equal(actual['configurations'],list(A.CONFIGS),'116入口の実36設定順');A.equal(set(actual['books']),set(A.KEYS),'116入口の全36集合')
    result={};baseline=None;count=0;context={k:v for k,v in actual.items() if k!='books'}
    for key,config in A.BY_KEY.items():
        book=actual['books'][key];result[key]=verify_entry_gate(book,config,context)
        projection=[{k:r[k] for k in ('request','source','quote','decision')} for r in (book['entry_gate']['records'] or [])]
        if baseline is None:baseline=projection
        else:A.equal(projection,baseline,'116全Life/費用/入口でSource要求と純入口115票が同体')
        count+=len(projection)
    sources=native['source'].get('sources');A.need(artificial or isinstance(sources,dict),'自然Source全文の保存必須')
    original=[]
    for src in (sources or {}).values():
        if src['config']['product']!='NK225mini':continue
        for rec in src['signals']:
            signal=rec['signal']
            if signal['action']=='new':original.append((src['method'],signal['id'],signal['side'],rec['quote']))
    observed=[(r['request']['method'],r['request']['signal_id'],r['request']['side'],r['quote']) for r in baseline or []]
    if original or not artificial:A.equal(sorted(original,key=lambda r:r[:3]),sorted(observed,key=lambda r:r[:3]),'元Source全文の全new集合と分母')
    event_stamps=[tuple(e['stamp'][k] for k in ('time','index','source_line')) for e in actual['entry_gate_events'] or []]
    source_stamps={tuple(r['request']['at'][k] for k in ('time','index','source_line')) for r in actual['books']['A0_C0_D0']['entry_gate']['records'] or []}
    A.need(len(event_stamps)==len(set(event_stamps)) and set(event_stamps)==source_stamps,'116の全new原行と入口Event1対1')
    return {'成功':True,'会計数':36,'全Source延べ票':count,'共通Source要求数':len(baseline or []),'手製Source器具':artificial,'book':result,'Life/費用/モード間のDecision115同体':True}
