"""Coreの失効正例へ保存点/所有/出典の破壊を加え、独立器が拒否することを確認する。"""
from copy import deepcopy
import unittest

import Core失効正例を独立照合する as C


class Tests(unittest.TestCase):
    """同じ金融を再走せず、公開された人工保存物の反例だけを検査する。"""

    @classmethod
    def setUpClass(cls):
        """
        機能: SHA認証済みの手製Core正例から一口座と全公表を取り出す。
        引数: cls(type)。返り値: None。自然Nativeは読まない。
        """
        manifest=C.C.read({'path':str(C.ART),'sha256':C.ART_SHA});value=C.C.read(manifest['圧縮'])
        native=next(iter(value['results'].values()));cls.context={k:v for k,v in native['actual'].items() if k!='books'}
        cls.book=next(b for b in native['actual']['books'].values() if b['config']['life_mode']=='XC' and b['positions'])
        cls.finance=C.C.S.A.verify_finance(cls.book,cls.book['config'])
        cls.position=cls.book['positions'][0]['id']

    def test_life_point_corruptions(self):
        """
        機能: 初期状態/凍結出生/純票/所有/予約/時点の別々の改変を拒否する。
        引数: self(Tests)。返り値: None。
        """
        for field in ('initial','birth','decision','ownership','future','P100','zero_quantity','metric','request_free'):
            b=deepcopy(self.book);p=b['positions'][0];a=p['lifecycle116'];point=a['first']
            if field=='initial':a['initial']['armed']=True
            elif field=='birth':a['initial']['entry']['birth']['values']['d15']+=1
            elif field=='decision':point['decision']['values']['signed_close']+=1
            elif field=='ownership':a['final_ownership']['remaining']=1
            elif field=='future':point['input']['latest']['scales'][0]['current']['frame']['available_at']=point['input']['stamp']['time']+1
            elif field=='P100':point['input']['P100_active']=not point['input']['P100_active']
            elif field=='zero_quantity':point['input']['remaining']=0
            elif field=='metric':b['metrics']['lifecycle_exit_requests']+=1
            else:a['requests'][0]['decision']['exit_eligible_quantity']+=1
            with self.subTest(field=field),self.assertRaises(ValueError):C.C.L.verify_lifecycle(b,b['config'],self.finance,self.context)

    def test_external_P100_copy_corruptions(self):
        """
        機能: P再同期の片側コピーと外部予約数量の改変を独立P監査が拒否する。
        引数: self(Tests)。返り値: None。
        """
        for field in ('copy','reserved','sequence','quote'):
            b=deepcopy(self.book);p=b['positions'][0];pt=p['protection113']['lifecycle_reservations'][0]
            if field=='copy':next(o for o in b['orders'] if o.get('lifecycle_point'))['lifecycle_point']['after_P100_reservation']['snapshot']['reserved']-=1
            elif field=='reserved':pt['snapshot']['reserved']-=1
            elif field=='sequence':pt['snapshot']['sequence']+=1
            else:pt['quote']=b['positions'][0]['entry_quote']
            with self.subTest(field=field),self.assertRaises(ValueError):C.C.P.verify_protection(b,b['config'],self.finance,self.context)

    def test_asof_cannot_use_future_or_missing_publication(self):
        """
        機能: Inputに合う保存足でも公表列の未来/不存在を認めない。
        引数: self(Tests)。返り値: None。
        """
        p=self.book['positions'][0];point=p['lifecycle116']['first'];cat=C.C.L.catalog(self.context)
        for field in ('future','missing'):
            context=deepcopy(self.context);fid=point['input']['latest']['scales'][0]['current']['frame']['id']
            pub=next(x for x in context['entry_publications'] if x['frame']['frame']['id']==fid)
            if field=='future':pub['stamp']['index']=point['input']['stamp']['index']+1
            else:context['entry_publications'].remove(pub)
            with self.subTest(field=field),self.assertRaises(ValueError):C.C.L.check_latest(point['input'],p['lifecycle116']['initial']['entry']['scope'],C.C.L.catalog(context))


if __name__=='__main__':unittest.main(verbosity=2)
