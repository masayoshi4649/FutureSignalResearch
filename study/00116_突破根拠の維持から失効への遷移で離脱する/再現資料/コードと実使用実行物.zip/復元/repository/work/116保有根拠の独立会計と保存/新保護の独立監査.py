"""共通P113/P100を保持し、新life予約の外部再同期だけを別算術で監査する。"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import inspect
import textwrap

import 金融の独立検算 as A

ROOT=Path(__file__).resolve().parents[2]
PRIOR=ROOT/'work/113起動前の構造失効を執行する会計/新保護の独立監査.py'
PRIOR_SHA='fdd4182152e60a66b298e633a813c3496440f3aea684d1dc4fe950983d39115f'
if hashlib.sha256(PRIOR.read_bytes()).hexdigest()!=PRIOR_SHA:raise ValueError('停止P113有理数監査SHA差')
spec=importlib.util.spec_from_file_location('116で再用する固定P113独立算術',PRIOR);OLD=importlib.util.module_from_spec(spec);spec.loader.exec_module(OLD)


def protection_function():
    """
    機能: P100数式は変えず最終sequence保存則へlife外部予約の再同期回数だけを加える。
    引数: なし。返り値: functionは旧P監査の限定派生。
    """
    tree=ast.parse(textwrap.dedent(inspect.getsource(OLD.verify_protection)));found=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.Call) and ast.unparse(node)=="equal(final['sequence'], audit['evaluations'] + audit['resets'] + len(own_orders), '評価/reset/実予約再同期のsequence保存則')":found.append(node)
    A.equal(len(found),1,'固定Pのsequence一式のみ')
    found[0].args[1]=ast.parse("audit['evaluations']+audit['resets']+len(own_orders)+len(audit.get('lifecycle_reservations') or [])",mode='eval').body
    space=dict(vars(OLD));exec(compile(ast.fix_missing_locations(tree),__file__+':life外部予約のsequenceだけ','exec'),space)
    return space['verify_protection']


VERIFY=protection_function()


def verify_protection(book: dict,config: dict,finance: dict,context: dict) -> dict:
    """
    機能: 既P100保存点とlife予約後の専用P再同期を区別して有理数検査する。
    引数: book/config/finance/context(dict)。返り値: dictはexact/boundedと専用件数。
    """
    A.equal(book['key'],A.key_for(config),'116P監査の本名key');A.equal(book['config'],config,'116Pの本名Config');A.need(config['policy']=='P100','116共通P100')
    before=repr((book,config,context));result=VERIFY(book,config,finance,context);checked=0
    for p in book['positions']:
        orders={o['id']:o for o in book['orders'] if o['position_id']==p['id'] and o.get('lifecycle_point') is not None}
        traces=p['protection113'].get('lifecycle_reservations') or []
        A.equal(len(traces),len(orders),'life予約とP専用再同期が一対一')
        A.need(config['life_mode']!='X0' or not traces,'X0はP再同期新欄が無効')
        seen=set()
        for trace in traces:
            order_id=trace['exit_order_id'];A.need(order_id in orders and order_id not in seen,'専用P再同期のlife実注文所有');seen.add(order_id);o=orders[order_id]
            A.equal(o['lifecycle_point']['after_P100_reservation'],trace,'life要求とP専用再同期は全値同体')
            pre=trace['before_snapshot'];post=trace['snapshot'];A.need(pre is not None,'life外部予約の直前P状態は必須')
            A.equal(trace['quote'],None,'life予約P再同期は新価格評価なし');A.equal(trace.get('after_request'),None,'P自身の要求へ偽装しない');A.equal(trace['phase'],'after_source','lifeの実要求位相');A.equal(trace['at'],o['request_time'],'lifeとP再同期時計')
            A.equal(post['sequence'],pre['sequence']+1,'外部予約でP Advance一回');A.equal(post['remaining'],pre['remaining'],'外部予約時に実残不変');OLD.same_amount(post['closed_net_yen'],pre['closed_net_yen'],'外部予約時にR不変')
            A.equal(post['reserved'],pre['reserved']+o['quantity'],'外部予約だけをPへ反映')
            state=finance['timeline'].state_at(p['id'],{'quote':o['request_quote'],'phase':'after_source'})
            A.need(state is not None,'実取得前のlife予約なし');A.equal(post['remaining'],state['quantity'],'P再同期の実残');OLD.same_amount(post['closed_net_yen'],state['realized'],'P再同期の実R')
            OLD.verify_exact_point(pre,trace);checked+=1
    result['counts']['lifecycle_P100_reservations_exact']=checked
    result['limits'].append('life自己要求はP100自己要求に数えず、専用before_snapshot付き再同期を別exact検査する。')
    A.equal(repr((book,config,context)),before,'116P監査の原値不変')
    return result
