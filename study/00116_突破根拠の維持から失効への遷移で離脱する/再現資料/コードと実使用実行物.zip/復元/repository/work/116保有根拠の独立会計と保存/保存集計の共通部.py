"""116の全36会計/入口/P100/新lifeを別監査し、旧115X0全12を厳密比較する。"""
from copy import deepcopy
from pathlib import Path
from types import FunctionType
import ast
import hashlib
import importlib.util
import inspect
import json
import textwrap

import 金融の独立検算 as A

ROOT=Path(__file__).resolve().parents[2]
PRIOR=ROOT/'work/115三時間軸入口の独立会計と保存/保存集計の共通部.py'
PRIOR_SHA='7e9866cf6556092bc892bbaf398e849fce23072f50bedcfd71af521f24d9e605'
if hashlib.sha256(PRIOR.read_bytes()).hexdigest()!=PRIOR_SHA:raise ValueError('停止115保存共通SHA差')
spec=importlib.util.spec_from_file_location('116が再用する停止115保存共通',PRIOR);OLD=importlib.util.module_from_spec(spec);spec.loader.exec_module(OLD)
BASE,need,equal=A.BASE,A.need,A.equal
KEYS,BY_KEY=A.KEYS,A.BY_KEY
digest,load,combine,source_projection=OLD.digest,OLD.load,OLD.combine,OLD.source_projection
SOURCE_VERIFY=FunctionType(OLD.verify_source.__code__,{**OLD.verify_source.__globals__,'KEYS':KEYS,'BY_KEY':BY_KEY},'116全36のSource通知同体',OLD.verify_source.__defaults__,OLD.verify_source.__closure__)
SCOPE116='116:入口115と共通P100を固定し、取得後の突破根拠と順側Hist喪失を別監視する。元Source通知・連続時計は変更しない。'
SCOPE115='115:元Source通知行の三時間軸と構造による取得選別。連続時計、共通P100保護。Source内部・通知は変更しない。'


def summarize_book(book: dict,checked: dict) -> dict:
    """
    機能: 固定統計を維持し、Source/旧P100/新life/対象外旧Eの返済純額を分ける。
    引数: book/checked(dict)。返り値: dictは0取引を残す場別統計。
    """
    row=OLD.summarize_book(book,checked);groups={}
    for label in ('Source','保護','保有根拠失効','起動前失効'):
        selected={}
        for oid,o in checked['orders'].items():
            if o['kind']!='exit':continue
            role='保有根拠失効' if o.get('lifecycle_point') is not None else '起動前失効' if o.get('entry_invalidation_point') is not None else '保護' if o['protection_point'] is not None else 'Source'
            if role==label:selected[oid]=o
        fills=[f for f in book['fills'] if f['order_id'] in selected]
        groups[label]={'要求':len(selected),'要求枚':sum(o['quantity'] for o in selected.values()),'約定':len(fills),'約定枚':sum(f['quantity'] for f in fills),'返済片純額':sum((a['net_yen'] for f in fills for a in f['allocations']),BASE.ZERO)}
    equal(sum((g['返済片純額'] for g in groups.values()),BASE.ZERO),row['net_yen'],'116全返済役割の実純額加法');row['注文別']=groups
    row['保有根拠の独立検査']=checked['lifecycle_counts']
    return row


def compare_book115(book: dict,prior: dict) -> dict:
    """
    機能: X0の説明追加だけを検査分離し、旧115の金融/入口/P100全値を照合する。
    引数: book/prior(dict)。返り値: dictはGo LegacyComparison116と同じ対照証拠。
    """
    left,right=deepcopy(book),deepcopy(prior);cfg=left['config'];equal(cfg['life_mode'],'X0','旧対照はX0だけ');equal(left['key'],A.key_for(cfg),'新X0本名key');equal(left['key'],right['key'],'新旧同名key')
    for array,field in (('positions','lifecycle116'),('orders','lifecycle_point'),('fills','lifecycle_exit')):
        need(all(field not in r for r in left[array]),'X0に追加life欄なし/'+field)
    need(not any(k.startswith('lifecycle_') for k in left['metrics']),'X0に追加life集計なし')
    del cfg['life_mode'];equal(cfg,right['config'],'X0追加設定以外の旧115Config同体')
    need(left['stream_scope']==SCOPE116 and right['stream_scope']==SCOPE115,'旧115/X0の明示説明Scope')
    equal(left['entry_gate'],right['entry_gate'],'旧115/X0の全入口票/受付/取得同体')
    equal(left['entry_gate']['version'],115,'入口は115の実版を保持')
    records=len(left['entry_gate']['records'] or []);left['stream_scope']=right['stream_scope']='';equal(left,right,'旧115/X0全金融/P100全State同体')
    return {'entry_mode':cfg['entry_mode'],'life_mode':'X0','protection':'P100','stream_scope_difference':True,'monitoring_disabled':True,'config_equal':True,'gate_records':records,'gate_accounting_equal':True,'all_financial_equal':True}


def compare_reference115(value: dict,prior: dict) -> dict:
    """
    機能: Source全文とX0全12を旧115正式当場へ独立に照合する。
    引数: value/prior(dict)。返り値: dictは全12の説明差と全金融同体。
    """
    need(value['trial']==value['actual']['trial']==116 and prior['trial']==prior['actual']['trial']==115,'新旧の明示trial')
    equal(value['source'],prior['source'],'Source111全文の独立非干渉');equal(value['actual']['scope'],prior['actual']['scope'],'同当場/限月')
    details={k:compare_book115(value['actual']['books'][k],prior['actual']['books'][k]) for k in KEYS[:12]};trace=value['reference115']
    need(trace['comparisons']==12 and trace['all_financial_equal'] and trace['source_equal'],'Core旧115全12対照');equal(trace['details'],details,'CoreとPythonの旧115対照全値')
    return {'comparisons':12,'all_financial_equal':True,'source_equal':True,'details':details}


def viewer_reader():
    """
    機能: 固定111の保存再読式は保持し、資源分母だけ36へ派生する。
    引数: なし。返り値: functionは独立Viewer約定再読器。
    """
    original=OLD.OLD.OLD.verify_viewer;tree=ast.parse(textwrap.dedent(inspect.getsource(original)));matches=[n for n in ast.walk(tree) if isinstance(n,ast.Call) and ast.unparse(n)=="equal(len(resources), 24, '保存再読24資源')"]
    equal(len(matches),1,'固定Viewer分母一式');matches[0].args[1]=ast.Constant(36);matches[0].args[2]=ast.Constant('116保存再読36資源')
    returns=[n for n in ast.walk(tree) if isinstance(n,ast.Return) and isinstance(n.value,ast.Dict) and any(isinstance(k,ast.Constant) and k.value=='資源' for k in n.value.keys)]
    equal(len(returns),1,'固定Viewerの資源返却一式')
    for index,key in enumerate(returns[0].value.keys):
        if isinstance(key,ast.Constant) and key.value=='資源':
            equal(ast.literal_eval(returns[0].value.values[index]),24,'旧Viewerの資源返却24');returns[0].value.values[index]=ast.Constant(36)
    space={**original.__globals__,'A':A,'KEYS':KEYS,'BY_KEY':BY_KEY};exec(compile(ast.fix_missing_locations(tree),__file__+':分母36のみ','exec'),space)
    return space['verify_viewer']


verify_viewer=viewer_reader()


def inspect_scene(value: dict,prior: dict|None,protection,entry_guard,lifecycle,artificial: bool=False) -> dict:
    """
    機能: 116実Nativeの36会計/入口/共通P/新lifeを別検算しSourceと旧12を結ぶ。
    引数: value/prior(dict|None)、protection/entry_guard/lifecycle(module)、artificial(bool)。
    返り値: dictはchecked/source/reference115/入口/life。市場で旧参照欠落は拒否する。
    """
    actual=value['actual'];need(value['version']==1 and value['trial']==actual['trial']==116 and actual['version']==1 and actual['complete'],'116完結Native')
    equal(actual['configurations'],list(A.CONFIGS),'116実宣言36順序');equal(set(actual['books']),set(KEYS),'全36集合')
    equal(actual['scope']['session'],value['source']['session'],'Source場');equal(actual['scope']['contract'],value['source']['contract'],'Source限月')
    equal(actual['entry_grid_seconds'],None,'新規時計据置');equal(actual['extra_opening_quiet_seconds'],0,'追加静観なし');equal(actual['explicit_timers'],0,'架空timerなし');equal(actual['chart_seed_mode'],'cold_each_session','P100旧cold bank')
    equal(actual['lifecycle_delivery_rows'],actual['counts']['rows'],'life文脈は全受理原行配送')
    equal(actual['counts']['publications'],len(actual['publications'] or []),'P100公表数');equal(actual['counts']['resets'],len(actual['resets'] or []),'P100 reset数')
    entries=entry_guard.verify_scene(value,artificial=artificial);equal(set(entries['book']),set(KEYS),'全36入口監査')
    checked={};context={k:v for k,v in actual.items() if k!='books'}
    for k,c in BY_KEY.items():
        book=actual['books'][k];equal(book['session'],actual['scope']['session'],'全36同場');equal(book['metrics']['rows'],actual['counts']['rows'],'全36全受理原行');equal(book['metrics']['bad_quote_rows'],actual['counts']['bad_quotes'],'全36異常気配行')
        finance=A.verify_finance(book,c);finance['protection_counts']=protection.verify_protection(book,c,finance,context);finance['lifecycle_counts']=lifecycle.verify_lifecycle(book,c,finance,context);checked[k]=finance
    source=SOURCE_VERIFY(value,artificial);source['全36の元通知同体']=source.pop('全12の元通知同体');source['Source全JSON同体は旧115対照で確認']=source.pop('Source全JSON同体は旧114対照で確認')
    if prior is None:
        need(artificial,'市場は旧115正式当場参照が必須');reference={'comparisons':0,'all_financial_equal':None,'source_equal':None,'未照合':'最小手製Sourceは自然生成未証明。旧115比較は別人工が必要。'}
    else:reference=compare_reference115(value,prior)
    return {'checked':checked,'source':source,'reference115':reference,'entry':entries['book'],'entry_scene':entries}


def save_viewer(value: dict,output: Path,market_path: str) -> list:
    """
    機能: 実約定だけのViewer36資源を新規先へ保存する。
    引数: value(dict)、output(Path)、market_path(str)。返り値: list[dict]。価格本文は読まない。
    """
    resources=[];sid=value['actual']['scope']['session']['id']
    for k in KEYS:
        name=f'116_{k}_{sid}.trades.jsonl'
        with (output/name).open('x',encoding='utf-8',newline='\n') as f:
            for row in BASE.viewer_trades(value['actual']['books'][k]):f.write(json.dumps(row,ensure_ascii=False,default=BASE.serial,allow_nan=False)+'\n')
        resources.append({'id':f'116_{k}_{sid}','title':f'突破根拠の維持と失効 {k} {sid}','symbol':'NK225','product':'NK225mini','session':sid,'method_id':k,'point_value':100,'pnl_format':'trades','pnl_basis':'net','pnl_path':name,'market_path':market_path})
    return resources
