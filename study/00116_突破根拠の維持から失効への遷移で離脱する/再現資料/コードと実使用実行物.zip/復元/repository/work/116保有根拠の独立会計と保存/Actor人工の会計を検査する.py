"""Actor116の手製72冊を新会計と旧115全24対照へ結び、自然再生と分ける。"""
from pathlib import Path
from decimal import Decimal
import gzip
import hashlib
import json

import 金融の独立検算 as A
import 保存集計の共通部 as S

HERE=Path(__file__).resolve().parent
ART=S.ROOT/'work/116突破失敗を返済へ結ぶ会計/人工_独立判定用/人工の参照.json'
ART_SHA='0502927af91c3a0ee795cd2f7baa060b6043e03615a4c42fb268f518af363135'


def read(ref: dict) -> dict:
    """
    機能: 明示された手製JSON/gzipだけをSHA認証して読む。
    引数: ref(dict)。返り値: dict。Rawや自然Nativeは対象外。
    """
    p=Path(ref['path']);raw=p.read_bytes();A.equal(hashlib.sha256(raw).hexdigest(),ref['sha256'],'Actor手製SHA')
    return json.loads(gzip.decompress(raw) if p.suffix=='.gz' else raw,parse_float=Decimal)


def main(target: Path|None=None) -> None:
    """
    機能: 72会計とX0旧24の全金融/入口/P状態を独立照合する。
    引数: target(Path|None)は新規保存先。返り値: None。完全な公表文脈つき結合はCore人工で別証明。
    """
    manifest=read({'path':str(ART),'sha256':ART_SHA});A.need(not manifest['市場'] and not manifest['FAR自然生成'],'手製Actorだけ')
    refs=manifest['refs'];value=read(refs['買売人工.json.gz']);A.need(not value['市場'] and not value['FAR自然生成'],'手製の範囲を維持')
    total=legacy=0;life_requests=life_fills=0;details=[]
    for side in ('買い','売り'):
        A.equal(set(value[side]),set(A.KEYS),'人工36本名集合')
        for key in A.KEYS:
            book=value[side][key];checked=A.verify_finance(book,A.BY_KEY[key]);total+=1;life_requests+=checked['counts']['lifecycle_exit_requests'];life_fills+=checked['counts']['lifecycle_exit_fills']
            if A.BY_KEY[key]['life_mode']=='X0':S.compare_book115(book,value[side+'_115'][key]);legacy+=1
            details.append({'side':side,'key':key,'金融成功':True,'net_yen':checked['totals']['net_yen'],'life_requests':checked['counts']['lifecycle_exit_requests'],'life_fills':checked['counts']['lifecycle_exit_fills']})
    A.equal(total,72,'新手製72会計');A.equal(legacy,24,'旧115全24比較')
    proof={'試行':116,'成功':True,'市場前':True,'Actor人工参照':{'path':str(ART),'sha256':ART_SHA},'圧縮人工Ref':refs['買売人工.json.gz'],'会計数':total,'旧115全金融比較':legacy,'life要求':life_requests,'life実fill':life_fills,'場別':details,'限界':'Actor手製の金融と旧24対照。全公表Contextを必要とする入口/P/life保存点の結合はCore人工で別に確認する。自然FAR再生ではない。','Raw/自然Native/金融Go再実行':0}
    target=target or HERE/'Actor手製72会計の確認.json'
    with target.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(proof,ensure_ascii=False,indent=2,default=A.BASE.serial)+'\n')
    print(json.dumps({'成功':True,'path':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__=='__main__':main()
