"""116本名36口座の会計を、固定115/113/94数式と新自己返済の分類差だけで検算する。"""
from pathlib import Path
from types import FunctionType
import ast
import hashlib
import importlib.util
import inspect
import textwrap

ROOT=Path(__file__).resolve().parents[2]
PRIOR=ROOT/'work/115三時間軸入口の独立会計と保存/金融の独立検算.py'
PRIOR_SHA='bed354c17962b689a2546449703c006ace0a4a056e44775d1d61f4acf1bd8419'
if hashlib.sha256(PRIOR.read_bytes()).hexdigest()!=PRIOR_SHA:raise ValueError('停止115金融会計SHA差')
spec=importlib.util.spec_from_file_location('116が参照する停止115会計',PRIOR)
OLD=importlib.util.module_from_spec(spec);spec.loader.exec_module(OLD)
BASE,need,equal,number,money=OLD.BASE,OLD.need,OLD.equal,OLD.number,OLD.money
CONFIGS=tuple({'policy':'P100','entry_mode':entry,'life_mode':life,'slip_pts':cost,'delay_seconds':delay} for life in ('X0','XC','XQ') for entry in ('A0','T','TR') for cost in (0,5) for delay in (0,1))


def key_for(config: dict) -> str:
    """
    機能: 116の実宣言36だけを受理しX0旧名とXC/XQ本名を保持する。
    引数: config(dict)。返り値: strは実口座key。政策/費用/版を偽装しない。
    """
    need(config in CONFIGS and set(config)=={'policy','entry_mode','life_mode','slip_pts','delay_seconds'},'116本名36設定')
    middle='' if config['life_mode']=='X0' else '_'+config['life_mode']
    return f"{config['entry_mode']}{middle}_C{config['slip_pts']}_D{config['delay_seconds']}"


BY_KEY={key_for(c):c for c in CONFIGS}
KEYS=tuple(BY_KEY)


def make_timeline():
    """
    機能: 同原行Source後の自己予約として旧保護/旧失効/新lifeを区別する。
    引数: なし。返り値: typeは固定94時点会計の限定分類派生。
    """
    tree=ast.parse(OLD.OLD.OLD.BASE_PATH.read_text(encoding='utf-8'))
    classes=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='Timeline'];equal(len(classes),1,'固定Timeline唯一')
    tree=ast.Module(body=classes,type_ignores=[]);found=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.Compare) and ast.unparse(node)=="order['protection_point'] is None":found.append(node)
    equal(len(found),1,'旧Source予約分類一式')
    target=found[0];replacement=ast.parse("order['protection_point'] is None and order.get('entry_invalidation_point') is None and order.get('lifecycle_point') is None",mode='eval').body
    class Replace(ast.NodeTransformer):
        """唯一の旧Source述語を新自己予約の分類へ置き換える。"""
        def visit_Compare(self,node):
            """
            機能: 指定済みの一つの比較式だけを変える。
            引数: node(ast.Compare)。返り値: ast.exprは旧式または限定差分。
            """
            return replacement if node is target else self.generic_visit(node)
    tree=Replace().visit(tree);space=dict(vars(BASE));exec(compile(ast.fix_missing_locations(tree),__file__+':新自己予約分類','exec'),space)
    return space['Timeline']


TIMELINE=make_timeline()


def accounting_function():
    """
    機能: 固定金融の入口宣言部を外へ分離し、Source件数の新life除外だけを追加する。
    引数: なし。返り値: functionは価格/費用/配賦/所有/flat数式を保持する。
    """
    tree=ast.parse(textwrap.dedent(inspect.getsource(BASE.verify_book)));fn=tree.body[0]
    expected=["require(key in KEYS and book['key'] == key, 'Actor key')","policy, cost, delay = key.split('_')","config = {'policy': policy, 'slip_pts': int(cost[1:]), 'delay_seconds': int(delay[1:])}","equal(book['config'], config, 'Actor config')"]
    equal([ast.unparse(n) for n in fn.body[1:5]],expected,'固定94設定部の厳密同体')
    fn.name='pure_accounting116';fn.body=[fn.body[0]]+fn.body[5:];fn.args.args=[ast.arg(arg=n) for n in ('book','config','policy')];changed={'atr':0,'source':0}
    for node in ast.walk(fn):
        if not isinstance(node,ast.Dict):continue
        for i,k in enumerate(node.keys):
            if isinstance(k,ast.Constant) and k.value=='atr_deferred_positions':
                node.values[i]=ast.parse("sum(p['atr'] is None or p['atr']['after_entry'] for p in saved.values()) if policy == 'S0' else 0",mode='eval').body;changed['atr']+=1
            if isinstance(k,ast.Constant) and k.value=='source_exit_requests':
                equal(ast.unparse(node.values[i]),"sum((o['kind'] == 'exit' and o['protection_point'] is None for o in orders.values()))",'元Source要求件数式')
                node.values[i]=ast.parse("sum(o['kind']=='exit' and o['protection_point'] is None and o.get('entry_invalidation_point') is None and o.get('lifecycle_point') is None for o in orders.values())",mode='eval').body;changed['source']+=1
    equal(changed,{'atr':1,'source':1},'既113ATR式と新自己予約分類以外を変えない')
    space={**vars(BASE),'Timeline':TIMELINE,'verify_marks':OLD.OLD.OLD.verify_marks,'verify_source_events':OLD.SOURCE_EVENTS}
    exec(compile(ast.fix_missing_locations(tree),__file__+':固定金融数式と116分類','exec'),space)
    return space[fn.name]


PURE_ACCOUNTING=accounting_function()


def verify_finance(book: dict,config: dict) -> dict:
    """
    機能: 本名116の全実約定/価格/費用/配賦/実残/予約をGoなしで独立検算する。
    引数: book/config(dict)。返り値: dictは旧会計API同形と新life分類件数。
    """
    equal(book['key'],key_for(config),'116本名key');equal(book['config'],config,'116本名設定');before=repr(book)
    result=PURE_ACCOUNTING(book,config,'P100');OLD.OLD.OLD.verify_source_reservations(book,result)
    life_orders=[o for o in book['orders'] if o.get('lifecycle_point') is not None]
    need(config['life_mode']!='X0' or not life_orders,'X0に新life返済なし')
    for order in book['orders']:
        need(order.get('entry_invalidation_point') is None,'共通P100へ旧E失効を混ぜない')
        if order.get('lifecycle_point') is not None:
            need(order['kind']=='exit' and order['protection_point'] is None and not order['native_close_signal_id'] and not order['native_close_notice_id'],'life/旧P100/Source要求を別にする')
    for fill in book['fills']:
        order=result['orders'][fill['order_id']]
        need(fill['quote']['source_line']>order['request_quote']['source_line'],'lifeを含む全fillが後続物理行')
        equal(fill.get('lifecycle_exit',False),order.get('lifecycle_point') is not None,'life実fill識別')
        need(not fill.get('entry_invalidation',False),'P100へ旧E実fillなし')
    life_counts={'lifecycle_exit_requests':len(life_orders),'lifecycle_exit_fills':sum(f.get('lifecycle_exit',False) for f in book['fills'])}
    for k,v in life_counts.items():equal(book['metrics'].get(k,0),v,'新life別件数/'+k)
    for k in ('entry_invalidated_positions','entry_invalidation_exit_requests','entry_invalidation_exit_fills'):equal(book['metrics'].get(k,0),0,'旧Eは今回対象外/'+k)
    equal(book['metrics']['timer_calls'],0,'追加timerなし');fallback=sum(p['atr'] is None for p in book['positions']);equal(book['metrics'].get('atr_unknown_fallback_positions',0),fallback,'P100取得時ATR不明固定幅')
    result['counts'].update(life_counts);result['counts']['atr_unknown_fallback_positions']=fallback
    equal(repr(book),before,'116会計の原値非変更')
    return {**result,'book':book}
