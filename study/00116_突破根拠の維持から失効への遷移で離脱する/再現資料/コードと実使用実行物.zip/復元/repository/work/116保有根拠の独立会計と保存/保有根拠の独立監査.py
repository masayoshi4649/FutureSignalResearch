"""116の保存life点を、全公表asof・独立会計・Decimal状態遷移へ結ぶ。"""
from bisect import bisect_right
from copy import deepcopy

import 金融の独立検算 as A
import 入口の独立検算 as E
import ライフ状態の独立式 as I


def catalog(context: dict) -> dict:
    """
    機能: 全実公表を幅別/ID別へ索引し同原行の最後までをasofに使う。
    引数: context(dict)はCore.actual原値。返り値: dictは複写しない読み取り索引。
    """
    widths={w:[] for w in (300,900,1800)};by_id={}
    for pub in context['entry_publications'] or []:
        f=pub['frame']['frame'];A.need(f['id'] not in by_id,'公表IDの一意性');by_id[f['id']]=pub;widths[f['width_seconds']].append(pub)
    for w,rows in widths.items():A.need([r['stamp']['index'] for r in rows]==sorted(r['stamp']['index'] for r in rows),'尺度別公表の原行順')
    return {'widths':widths,'by_id':by_id,'indices':{w:[p['stamp']['index'] for p in ps] for w,ps in widths.items()}}


def latest_at(cat: dict,index: int) -> dict:
    """
    機能: 同原行の全公表を含む各幅の最終latestを独立に再構成する。
    引数: cat(dict)、index(int)。返り値: dictは尺度配列の必要形。未来原行は含めない。
    """
    scales=[]
    for width in (300,900,1800):
        j=bisect_right(cat['indices'][width],index)-1;pub=None if j<0 else cat['widths'][width][j]
        scales.append({'width_seconds':width,'has_current':pub is not None,'current':None if pub is None else pub['frame']})
    return {'scales':scales}


def check_latest(inp: dict,scope: dict,cat: dict) -> None:
    """
    機能: 保存Input.Latestの時計/既知性と全公表asofの最新全値を照合する。
    引数: inp/scope/cat(dict)。返り値: None。seed数値を当場公表へ偽装しない。
    """
    E.OLD.verify_snapshot(inp['latest'],inp['stamp'],scope)
    latest=latest_at(cat,inp['stamp']['index'])
    for scale,expected in zip(inp['latest']['scales'],latest['scales']):
        A.equal(scale['has_current'],expected['has_current'],'life最新公表の有無')
        if expected['has_current']:
            A.equal(scale['current'],expected['current'],'life同原行最終latest全値。中間足/未来を使わない')
            f=scale['current']['frame'];A.need(f['available_at']<=inp['stamp']['time'] and f['record_ordinal']<=inp['latest']['record_ordinal'],'life公表の現在以前')


def initial_state(entry: dict,definition: dict) -> dict:
    """
    機能: 未評価のNewStateを出生票の適格性から独立に構成する。
    引数: entry/definition(dict)。返り値: dictは初期Snapshot。
    """
    return {'version':116,'entry':deepcopy(entry),'definition':deepcopy(definition),'initialized':False,'at':None,'sequence':0,'monitoring_eligible':I.monitoring_eligible(entry),'armed':False,'warning':False,'disabled_by_P100':False,'latched':False,'first_arming':None,'last_arming':None,'last_chain_break':None,'invalidation':None,'arming_count':0,'chain_break_count':0}


def delivery_for(entry: dict,inp: dict,cat: dict) -> tuple:
    """
    機能: 初期に受けた旧公表のLine不明と、取得後の当行配送を区別する。
    引数: entry/ inp/cat(dict)。返り値: tuple[dict,bool]は純witness配送stamp。
    """
    scale=inp['latest']['scales'][0]
    if not scale['has_current']:return {'time':0,'index':0,'source_line':0},False
    f=scale['current']['frame'];pub=cat['by_id'][f['id']];index=f['record_ordinal']-1
    birth=entry['birth'];birth_ids={s['current']['frame']['id'] for s in birth['current']['snapshot']['scales'] if s['has_current']}
    if f['id'] in birth_ids:line=birth['request']['at']['source_line'] if index==birth['request']['at']['index'] else 0
    else:line=pub['stamp']['source_line'] if index>=entry['fill_stamp']['index'] else 0
    return {'time':f['delivery_at'],'index':index,'source_line':line},line>0


def collect_points(audit: dict) -> list[dict]:
    """
    機能: 少数イベント/実要求/最後の点を列挙し、同sequenceの重複保存も残す。
    引数: audit(dict)。返り値: list[dict]は非nullの保存点。
    """
    names=('first','first_warning','last_warning','first_recovery','last_recovery','first_warning_cleared','last_warning_cleared','first_invalidation','first_disabled_by_P100','first_all_reserved','last')
    return [audit[k] for k in names if audit.get(k) is not None]+[p for k in ('arming_points','chain_break_points','requests') for p in audit.get(k) or []]


def verify_point(point: dict,p: dict,entry: dict,finance: dict,context: dict,cat: dict) -> None:
    """
    機能: 一つのbefore/input/afterを独立式へ結び、実所有/原行/P100先行も照合する。
    引数: point/p/entry/finance/context/cat(dict)。返り値: None。全Rawの初回性は証明しない。
    """
    before,after,inp=point['before_snapshot'],point['snapshot'],point['input'];A.need(before is not None and after is not None,'life保存点の直前/直後状態')
    A.equal(before['entry'],entry,'各点の凍結出生/取得不変');A.equal(after['entry'],entry,'直後の凍結出生/取得不変');A.equal(before['definition'],after['definition'],'life実定義不変')
    scope=entry['scope'];q=point['quote'];A.equal(inp['stamp'],{k:q[k] for k in ('time','index','source_line')},'life入力と実原行');A.equal(inp['phase'],'after_source','lifeのSource/P100後位相')
    A.equal((inp['bid'],inp['ask'],inp['quote_ok']),(q['bid'],q['ask'],q['quote_ok']),'life実BBO/正常旗')
    if before['initialized']:
        previous=before['at'];A.need(inp['stamp']['index']>previous['index'] and inp['stamp']['source_line']>previous['source_line'] and inp['stamp']['time']>=previous['time'],'life原行前進/同秒物理行')
        previous_latest=latest_at(cat,previous['index'])
    else:
        A.equal(inp['stamp'],entry['fill_stamp'],'初回は実取得同原行');A.equal(before,initial_state(entry,before['definition']),'初回Beforeは独立NewState');previous_latest=None
    check_latest(inp,scope,cat);delivered,line_known=delivery_for(entry,inp,cat)
    wanted,decision=I.expected_step(before,inp,previous_latest,delivered,line_known);I.compare(after,wanted,'life1Advance/Snapshot');I.compare(point['decision'],decision,'life1Advance/Decision')
    A.equal(before['monitoring_eligible'],I.monitoring_eligible(entry),'出生適格を後付けしない');A.equal(after['monitoring_eligible'],before['monitoring_eligible'],'監視適格の不変')
    state=finance['timeline'].state_at(p['id'],{'quote':q,'phase':'after_source'});A.need(state is not None,'実取得前のlife評価なし')
    A.equal(inp['remaining'],state['quantity'],'lifeの実残');A.equal(point['remaining'],inp['remaining'],'life保存残');A.equal(A.money(point['realized_net'],'life保存R'),A.money(state['realized'],'独立実R'),'lifeの実R')
    reserved=0
    for order in finance['orders'].values():
        if order['kind']!='exit' or order['position_id']!=p['id']:continue
        ri=order['request_quote']['index'];accepted=ri<q['index'] or ri==q['index'] and order.get('lifecycle_point') is None
        fill=finance['timeline'].fill_by_order.get(order['id']);finished=fill is not None and fill['quote']['index']<=q['index']
        if accepted and not finished:reserved+=order['quantity']
    A.equal(inp['reserved'],reserved,'life前のSource/P100実予約');A.equal(point['reserved'],inp['reserved'],'life保存予約')
    activation=p['activation'];active=activation is not None and activation['quote']['index']<=q['index'];A.equal(inp['P100_active'],active,'P100起動はlifeより先')
    A.need(inp['remaining']>0 and q['index']<p['closed_quote']['index'],'最終返済済みの原行でpureを再評価しない')


def verify_lifecycle(book: dict,config: dict,finance: dict,context: dict) -> dict:
    """
    機能: 全life保存点・要求/free/実fill・所有完結を独立会計と状態式へ結ぶ。
    引数: book/config/finance/context(dict)。返り値: dictはexact/bounded/未証明範囲。
    """
    A.equal(book['config'],config,'life本名Config');A.equal(book['key'],A.key_for(config),'life本名key');original=repr((book,context));cat=catalog(context)
    counts={'positions':len(book['positions']),'saved_points_exact':0,'nonadjacent_saved_intervals':0,'source_requests':0,'exit_requests':0,'exit_fills':0,'eligible_positions':0,'armed_positions':0,'latched_positions':0,'ownership_completions':0,'zero_evaluation_positions':0}
    for p in book['positions']:
        audit=p.get('lifecycle116')
        if config['life_mode']=='X0':
            A.equal(audit,None,'X0追加life状態なし');A.need(not any(o['position_id']==p['id'] and o.get('lifecycle_point') is not None for o in book['orders']),'X0life要求なし');continue
        A.need(audit is not None,'XC/XQ実玉はlife監査必須');initial=audit['initial'];entry=initial['entry'];record=next(r for r in book['entry_gate']['records'] if r['actual_position_id']==p['id'])
        A.equal(entry['id'],p['id'],'life所有ID');A.equal(entry['policy'],config['life_mode'],'life政策実名');A.equal(entry['side'],p['side'],'life方向');A.equal(entry['birth'],record['decision'],'要求時に凍結した入口票そのもの');A.equal(entry['fill_stamp'],{k:p['entry_quote'][k] for k in ('time','index','source_line')},'life実取得原行')
        I.compare(initial,initial_state(entry,initial['definition']),'独立life初期状態');A.equal(initial['definition'],context['lifecycle_definition'],'Root実定義とlife定義')
        E.OLD.verify_full_decision(entry['birth'])
        points=collect_points(audit);unique={}
        for point in points:
            seq=point['snapshot']['sequence']
            projection={k:point[k] for k in ('input','before_snapshot','snapshot','decision','quote','remaining','reserved','realized_net')}
            if seq in unique:A.equal(unique[seq],projection,'同sequence保存点の純/所有全値不変')
            else:verify_point(point,p,entry,finance,context,cat);unique[seq]=projection;counts['saved_points_exact']+=1
        final=audit['final_state'];A.equal(final['sequence'],audit['evaluations'],'life評価回数とsequence');A.equal(final['entry'],entry,'最終life出生不変')
        if audit['evaluations']==0:
            A.equal(final,initial,'未初回評価ならNewStateのまま');A.equal(points,[],'未評価点を捏造しない');counts['zero_evaluation_positions']+=1
        else:
            A.equal(audit['first']['before_snapshot'],initial,'最初のlife評価は初期から');A.equal(audit['last']['snapshot'],final,'最後の保有中pure状態');A.equal(audit['first']['snapshot']['sequence'],1,'初回sequence1')
            sequence=sorted(unique);counts['nonadjacent_saved_intervals']+=sum(b>a+1 for a,b in zip(sequence,sequence[1:]))
            for previous,current in zip(sequence,sequence[1:]):
                if current==previous+1:A.equal(unique[current]['before_snapshot'],unique[previous]['snapshot'],'隣接保存点は同じ純状態を継承する')
        A.equal(len(audit.get('arming_points') or []),final['arming_count'],'全arm回数と保存点');A.equal(len(audit.get('chain_break_points') or []),final['chain_break_count'],'全鎖切り回数と保存点')
        for pt in audit.get('arming_points') or []:A.need(pt['decision']['armed_now'],'arm保存点の純票')
        for pt in audit.get('chain_break_points') or []:A.need(pt['decision']['chain_broken_now'],'鎖切り保存点の純票')
        for name in ('first_warning','last_warning'):
            pt=audit.get(name)
            if pt is not None:A.need(not pt['before_snapshot']['warning'] and pt['snapshot']['warning'],'Hist警戒の立上り保存')
        for name in ('first_warning_cleared','last_warning_cleared','first_recovery','last_recovery'):
            pt=audit.get(name)
            if pt is None:continue
            A.need(pt['before_snapshot']['warning'] and not pt['snapshot']['warning'],'Hist警戒の解除保存')
            if 'recovery' in name:
                d=pt['decision'];A.need(d['new_five_publication'] and d['required_known'] and d['required_fresh'] and d['values']['signed_histogram'] is not None and I.number(d['values']['signed_histogram'])>0,'順Hist回復とUnknown/P100解除を分ける')
        A.equal(audit['first_invalidation'] is not None,final['latched'],'初失効と不可逆ラッチ')
        if audit['first_invalidation'] is not None:A.need(audit['first_invalidation']['decision']['invalidated_now'],'初失効は当時の新失効')
        ownership=audit['final_ownership'];A.equal(ownership['quote'],p['closed_quote'],'所有完結は実最終fill原行');A.equal(ownership['remaining'],0,'所有完結残0');A.equal(ownership['reserved'],0,'所有完結予約0');A.equal(A.money(ownership['realized_net'],'所有完結R'),A.money(p['realized_net'],'実現R'),'所有完結R');A.equal(ownership['P100_active'],p['protection_active'],'所有完結P100状態')
        counts['ownership_completions']+=1;counts['eligible_positions']+=final['monitoring_eligible'];counts['armed_positions']+=final['arming_count']>0;counts['latched_positions']+=final['latched']
        orders={o['id']:o for o in book['orders'] if o['position_id']==p['id'] and o.get('lifecycle_point') is not None};requests=audit.get('requests') or []
        A.equal({pt['exit_order_id'] for pt in requests},set(orders),'全life実要求と専用保存一対一');A.equal(len(requests),len(orders),'life要求の重複なし')
        for pt in requests:
            o=orders[pt['exit_order_id']];d=pt['decision'];A.equal(o['lifecycle_point'],pt,'life実注文の全条件点');A.equal(o['request_quote'],pt['quote'],'life要求は現在の正常原行');A.equal(o['request_time'],pt['input']['stamp']['time'],'life要求時計');A.need(d['latched'] and d['quote_ok'] and d['exit_eligible_quantity']>0,'完成/正常/freeがある時だけ注文')
            A.equal(o['quantity'],d['exit_eligible_quantity'],'life純適格量と実要求');A.equal(o['quantity'],pt['remaining']-pt['reserved'],'life未予約全量');A.equal(o['reason'],'116突破根拠と順側Histの失効/'+config['life_mode'],'life実名理由')
            A.equal(pt['after_remaining'],pt['remaining'],'life要求だけでは実残不変');A.equal(pt['after_reserved'],pt['remaining'],'life要求後は全残予約');A.need(pt.get('after_P100_reservation') is not None,'外部予約をP100へ別同期');counts['exit_requests']+=1
        fills=[f for f in book['fills'] if f['position_id']==p['id'] and f.get('lifecycle_exit',False)];A.equal(audit.get('exit_fill_ids') or [],[f['id'] for f in fills],'life全実fillID')
        counts['exit_fills']+=len(fills)
    for field,key in (('lifecycle_eligible_positions','eligible_positions'),('lifecycle_armed_positions','armed_positions'),('lifecycle_latched_positions','latched_positions'),('lifecycle_exit_requests','exit_requests'),('lifecycle_exit_fills','exit_fills')):A.equal(book['metrics'].get(field,0),counts[key],'life独立metric/'+field)
    A.equal(repr((book,context)),original,'life監査は原値非変更')
    return {'成功':True,'counts':counts,'limits':['BeforeSnapshot/Inputがある保存点の1Advanceは独立算術exact。全Rawを別エンジンで再走したものではない。','非隣接sequence間の最初のXQ成立、全Rawの真の初回性、未保存の全warning遷移は保存点だけでは証明しない。','Raw上の次正常原行の最初性は別Go配送/約定人工証拠。金融は後原行/価格/配賦/数量/予約を全件照合する。']}
