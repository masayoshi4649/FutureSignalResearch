# 116の独立会計・保有根拠・保存の準備

2026-11-10。Rootの116金融F1は `work/116進行/F1_116金融条件.json`（SHA `4c76a5f7cd8a59962e885cadf6885cfc75cbc590675955cb8e72ae2d0b8bb372`）。このフォルダは人工と保存点の独立検算を担当し、新116市場の独立検算成功はまだ主張しない。115の正式成果物・金融条件・停止コードは変更しない。新116の自然Native・Raw・価格CSV・11月09を自主的に読まない。各段階の明示Root成功要求を受けてから、Rootだけが実CLIを実行する。

36設定はActor実宣言と同じ **LifeMode→EntryMode→C→D** 順。LifeはX0/XC/XQ、入口はA0/T/TR、費用はC0/C5×D0/D1。P113/P100、Source111、入口純115、5/15/30公開bank115、入口前史115模型を保持する。X0は旧115のkeyを継承し、XC/XQは `A0_XC_C0_D0` 等の実名で扱う。正式設定表のR行はEntry→Life順であるため、将来の結果結合は行番号と金融配列位置を同一視せず、候補keyからBY_KEYへ一意に結ぶ。

## API

- `金融の独立検算.verify_finance(book, config)`：実BBO約定、手数料38.5円/片道、滑り、各allocation、実残/予約、Source作用、flat、保存時価DDを固定94/111/113/115の数式から検査する。新life注文だけをSource自己要求と誤分類しない限定派生を加える。
- `入口の独立検算.verify_entry_gate(book, config, context)` / `verify_scene(native, artificial=False)`：115の独立十二値・三値・asof・前3本・全Source出生・受付/実取得を再用し、本名116の36へ結ぶ。Nativeを115へ偽装しない。
- `新保護の独立監査.verify_protection(book, config, finance, context)`：P113有理数式を保持する。lifeの外部予約はP100自己要求へ混ぜず、専用 `lifecycle_reservations` のBeforeSnapshot付きnil価格Advanceを別exact検査し、sequence保存則へ専用回数を加える。
- `ライフ状態の独立式.expected_step(before, input, previous_latest, delivered, line_known)`：Decimalによる新ライフ1Advanceの算術。Go関数やGo期待値を呼ばない。
- `保有根拠の独立監査.verify_lifecycle(book, config, finance, context)`：保存Before/Input/Afterを全公表asof・実所有へ接合する。隣接sequenceは状態継承も全値比較し、life要求と専用P再同期コピーを同じ注文IDで結ぶ。

Source/旧保護/新lifeの実返済役割を分ける。X0は `life_mode=X0` の説明差・stream版差・無効life欄を検査した上で、旧115全12の金融・全入口票・P100Stateを全値比較する。XC/XQは新返済後の容量や後続取得が変わり得るため、Source通知の同体と実取得同体を混同しない。未参加や退出後の仮想利益は計算しない。

## ライフの独立算術

監視適格は凍結出生Common真・D15>0・G30既知非0・固定境界既知であり、入口を追加拒否する条件ではない。実取得原行では、freshな当場5/15/30、公表5Close順側、Hist5順符号、DI15順側、正常返済BBO順側で初期armed。後armはEnd>fillかつ5Frame.RecordOrdinal−1>fill.Indexの取得後公表がfreshな間、同4票を満たす正常Rawで行う。

新lifeは各Raw原行で全5/15/30公表を揃えた最終latest Snapshotだけを使う。同原行バッチ内の中間古い5足を仮想時計へ遡及して評価しない。出典の全公表列は独立に認証する。

armed後、取得後のfresh5Hist<=0が「Hist警戒」。価格が順側へ戻ってもHist警戒は続き、Hist>0で解除される。XCは新5公表のClose strict内側、XQはHist警戒の期間中の全正常Rawで返済BBO strict内側なら完成ラッチ。Hist=0は警戒、価格の境界等号は内側でない。XCは異常BBOでも完成できるが、返済適格量は正常BBO時だけの未予約n−r。全予約なら0で、ラッチの不存在を意味しない。

実使用Unknown/古さは未完成armedを切る。欠足は当該latestのPriceKnown等の未知として扱い、Endの跳びだけでバッチ中間足を遡及評価しない。異常BBOだけでは切らず、DI/G30の既知逆転だけでも切らない。再armは別回数として保持する。未ラッチでP100が先にActiveなら追加lifeを無効化する。既に完成したラッチは回復・Source予約取消・後のP100起動でも撤回しない。

## 証拠範囲

保存するlife点にBeforeSnapshotと当時Inputがあれば、その1Advanceをexactで再計算できる。非隣接sequenceの全途中Raw、最初の正常約定原行、XQのRaw全列における真の初回性は、少数保存点だけでは証明しない。出典公表のasof・配送行、実R/n/予約は別々に結び、exact/bounded/unknownを分ける。

実残0の原行ではpureを再評価しない。最後の保有中 `FinalState` と、閉じた原行の `FinalOwnership`（実n=0・予約0・実R）を別に照合する。P100先起動の保存点照合は保存Activationの出典との結合であり、全RawのH100初回到達を独立再走した証明ではない。

人工は手計算10主、旧115接続4主、保存点破壊3主、入力ゲート3主。純Go8系列48Advance、Actor新72会計と旧115全24対照、Actor life120点/P専用予約48点、全公表付きCore6系列216会計/216Viewer、新失効正例Core2系列72会計/72Viewerを別々に検査する。Core人工は自然FAR生成ではなく、旧115Native本文を同梱しないためその独立比較は0とする。Actor別人工が旧115全24を担う。新金融成績や未参加仮利益は作らない。

`原板最初性の独立検査方式.md` と `原板最初性のP100起動を独立確認する.md` は別Raw監査の計画であり、この保存器がRawを読んだ証明ではない。後者は正常BBO・実R/n・q0×10000円からpre_fill/after_sourceのH100最初到達を再形成する。Native保存ActivationだけでXを無効化しない。ATR/全追尾床の全Raw最初性とは範囲を分ける。Raw consumerは別フォルダ・別Root固定へ派生する。

## Rootによる停止と実行

人工と前後同体だけを確認する。既存証拠・停止を上書きしない。

```powershell
python .\検査して停止する.py --check-output <新しい絶対フォルダ>
```

この出力の `停止前の確認.json` をRootがレビューした後だけ、同じコード・依存・人工結果のSHAを再確認して停止する。

```powershell
python .\検査して停止する.py --stop --review <停止前の確認.jsonの絶対パス> --review-sha <SHA256>
```

`P停止.json`、`ライフ停止.json`、`会計停止.json` は成功/停止/市場前/試行116/所有ファイルSHA256を持つ。全Raw発生漏れ・初回性はfalseを維持する。Rootレビュー前に正式停止を作らない。

停止後に `要求ひな型を作る.py --stage first2 --completion <Root金融完了.json> --output <新規絶対JSON>` をRootが実行する。ひな型はfixed=false、新旧Native許可=false。Rootが同F1成功metadataと全場順を確認し、価格は文字列参照を設定し、3つの固定/許可をtrueにした新要求を別保存する。FileRefは解決絶対pathとSHAで同体を比較し、bytes付加とslash表記だけの差を条件変更としない。

```powershell
python .\保存する.py --fixed <Rootの新要求絶対JSON> --sha256 <要求SHA> --output <新規絶対フォルダ> --metadata-only
python .\保存する.py --fixed <同要求> --sha256 <同SHA> --output <同じ未生成フォルダ>
```

metadata-onlyは条件・完了・停止・コードだけを認証し、新旧Native本文とNative実物SHAへは触れない。実保存では新旧Nativeを指紋認証して36N会計/入口/P/life/12N旧対照を実施、結果・保存会計の確認・Viewer資源を再読して保存する。このCLIへRaw/11月09の許可を与えることはできない。
