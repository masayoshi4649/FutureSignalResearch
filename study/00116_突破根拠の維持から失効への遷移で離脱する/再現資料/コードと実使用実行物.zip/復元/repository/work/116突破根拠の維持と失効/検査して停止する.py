"""116純ライフサイクルの人工と依存をRootレビュー後に停止する。"""
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OWNED = (
    "types.go", "state.go", "fastcopy.go", "state_test.go", "export_test.go",
    "cmd/definition/main.go", "go.mod", "README.md", "API案.md", Path(__file__).name,
)
DEPENDENCIES = {
    "bank115": ("work/115三時間軸と方向性の公開/検査_停止版/停止.json", "df5718acf04495bc690c5a0d0652ba202cb9f970eb2323389f246d70cdbe7a68"),
    "entry_gate115": ("work/115三時間軸と構造の純入口/停止.json", "50bd192518a88c4fe087ccae052ecc3d312fccabf3c8c1f230cdd8391e8c133a"),
}
CODE_FIELDS = (
    "所有コードSHA256", "所有ファイルSHA256", "再用コードSHA256", "実Go依存SHA256",
    "実Go依存コードSHA256", "コードSHA256前", "全固定コードSHA256",
)


def digest(path: Path) -> str:
    """
    機能: 明示コード・停止metadata・人工成果物の全bytes指紋を求める。
    引数: path(Path)は対象ファイル。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ref(path: Path) -> dict:
    """
    機能: 明示ファイルを絶対参照へ変換する。
    引数: path(Path)は実在ファイル。返り値: dictはpath/sha256。
    """
    return {"path": str(path.resolve()), "sha256": digest(path)}


def run(command: list[str], env: dict) -> dict:
    """
    機能: Go依存列挙・人工・定義・API・buildだけを実行する。
    引数: command(list[str])、env(dict)は実行列と環境。返り値: dictは成功ログ。
    """
    result = subprocess.run(command, cwd=HERE, env=env, capture_output=True,
                            text=True, encoding="utf-8", timeout=60)
    value = {"command": command, "exit_code": result.returncode,
             "stdout": result.stdout, "stderr": result.stderr}
    if result.returncode:
        raise ValueError(json.dumps(value, ensure_ascii=False))
    return value


def generated_testmain(package: dict, cache: Path) -> list[dict]:
    """
    機能: Goが主test実行用に生成したmainだけを生成環境参照へ分類する。
    引数: package(dict)、cache(Path)はgo listのpackageとGo自身のGOCACHE。
    返り値: list[dict]は生成mainの指紋/由来/再生成方法。実ソースは空配列。
    """
    if package.get("Name") != "main" or not package.get("ImportPath", "").endswith(".test"):
        return []
    module = package.get("Module") or {}
    generated = package.get("GoFiles", [])
    if (module.get("Main") is not True or package["ImportPath"] != module.get("Path", "") + ".test"
            or Path(package["Dir"]).resolve() != HERE or len(generated) != 1
            or any(package.get(key) for key in ("CgoFiles", "SFiles", "HFiles", "SysoFiles", "EmbedFiles"))):
        raise ValueError("生成testmainのpackage識別/主module/構成差")
    path = Path(generated[0])
    if not path.is_absolute():
        raise ValueError("生成testmainの実ファイルが絶対pathではない")
    path = path.resolve()
    if not path.is_relative_to(cache) or not re.fullmatch(r"[0-9a-f]{64}-d", path.name):
        raise ValueError("識別済み生成testmainのGo生成位置が不正")
    return [{**ref(path), "kind": "Go自動testmain", "package": package["ImportPath"],
             "由来": "go list -deps -testによるName=mainかつImportPath末尾.testの主module生成GoFiles一件",
             "再生成": ["go", "test", "-count=1", module["Path"]],
             "金融固定コード": False, "正式復元対象": False}]


def closure(env: dict) -> tuple[dict, list[dict]]:
    """
    機能: 純moduleの実Go依存と人工依存、Go実行物を列挙認証する。
    引数: env(dict)は固定Go環境。
    返り値: tuple[dict,list[dict]]は実ソース閉包とSHA検査を維持する生成環境参照。
    """
    raw = run(["go", "list", "-deps", "-test", "-json", "./..."], env)["stdout"]
    cache = Path(run(["go", "env", "GOCACHE"], env)["stdout"].strip()).resolve()
    decoder, position, paths, generated = json.JSONDecoder(), 0, set(), []
    while raw[position:].strip():
        position += len(raw[position:]) - len(raw[position:].lstrip())
        package, position = decoder.raw_decode(raw, position)
        folder = Path(package["Dir"])
        main = generated_testmain(package, cache)
        if main:
            generated.extend(main)
            continue
        for field in ("GoFiles", "CgoFiles", "SFiles", "HFiles", "SysoFiles", "EmbedFiles"):
            for name in package.get(field, []):
                source = (folder / name).resolve()
                if source.is_relative_to(cache):
                    raise ValueError("生成testmainと識別されないcache入力を固定コードへ混入:" + str(source))
                paths.add(source)
        module = package.get("Module") or {}
        for item in (module, module.get("Replace") or {}):
            if item.get("GoMod"):
                paths.add(Path(item["GoMod"]).resolve())
    paths.add(Path(shutil.which("go")).resolve())
    return {str(path): digest(path) for path in sorted(paths, key=str)}, generated


def authenticate_stop(name: str, path: Path, sha: str, before: dict) -> dict:
    """
    機能: 旧停止Refと明示コード指紋を本文市場読取なしで認証する。
    引数: name(str)、path(Path)、sha(str)、before(dict)は依存名/停止/期待/台帳。
    返り値: dictは原停止値。旧停止とコードは変更しない。
    """
    if digest(path) != sha:
        raise ValueError("依存停止SHA差:" + name)
    value = json.loads(path.read_text(encoding="utf-8-sig"))
    if value.get("成功") is not True or value.get("停止") is not True or value.get("市場前") is not True:
        raise ValueError("依存の市場前停止が不正:" + name)
    before[str(path.resolve())] = sha
    for field in CODE_FIELDS:
        for source, expected in value.get(field, {}).items():
            item = Path(source)
            item = (item if item.is_absolute() else ROOT / item).resolve()
            if digest(item) != expected:
                raise ValueError("旧依存コードSHA差:" + str(item))
            before[str(item)] = expected
    return value


def write_new(path: Path, value: dict) -> None:
    """
    機能: 新規先だけへUTF-8/LF JSONを保存する。
    引数: path(Path)、value(dict)は未作成先と保存値。返り値: None。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def main() -> None:
    """
    機能: Rootレビュー後の明示実行で純116だけを新規停止する。
    引数: CLI --reviewedはRootレビュー済みの明示。返り値: None。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--reviewed", action="store_true", required=True)
    parser.parse_args()
    target, output = HERE / "停止.json", HERE / "検査"
    if target.exists() or output.exists():
        raise ValueError("停止と検査先は未作成だけを許可")
    env = dict(os.environ, CGO_ENABLED="0", GOWORK="off")
    if run(["go", "version"], env)["stdout"].strip() != "go version go1.24.2 windows/amd64":
        raise ValueError("Go1.24.2 windows/amd64だけを固定")
    before, stops = {}, {}
    for name, (relative, sha) in DEPENDENCIES.items():
        path = ROOT / relative
        authenticate_stop(name, path, sha, before)
        stops[name] = ref(path)
    owned = {str((HERE / name).resolve()): digest(HERE / name) for name in OWNED}
    compiled, generated = closure(env)
    output.mkdir()
    artificial_env = dict(env, ENTRYLIFE116_ARTIFACT_DIR=str((output / "人工").resolve()))
    logs = [run(["go", "test", "-count=1", "-json", "./..."], artificial_env),
            run(["go", "vet", "./..."], env), run(["go", "build", "./..."], env),
            run(["go", "run", "./cmd/definition"], env), run(["go", "doc", "-all", "."], env)]
    events = [json.loads(line) for line in logs[0]["stdout"].splitlines() if line.startswith("{")]
    passed = [event["Test"] for event in events if event.get("Action") == "pass" and "Test" in event and "/" not in event["Test"]]
    if len(passed) != 17 or "TestExportArtificial" not in passed:
        raise ValueError("16主人工と1人工exportが不足")
    definition = json.loads(logs[3]["stdout"])
    if definition["version"] != 116 or definition["policies"] != ["X0", "XC", "XQ"] or not all(definition[key] is True for key in ("latest_only", "holding_only", "completed_latch_irreversible")):
        raise ValueError("116実定義差")
    artificial = json.loads((output / "人工/人工の参照.json").read_text(encoding="utf-8"))
    series = json.loads(Path(artificial["系列"]["path"]).read_text(encoding="utf-8"))
    if artificial["系列数"] != 8 or artificial["評価数"] != 48 or series["definition"] != definition:
        raise ValueError("8系列48評価又は実定義差")
    write_new(output / "実定義.json", definition)
    with (output / "API.txt").open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(logs[4]["stdout"])
    fixed = {**before, **owned, **compiled}
    if any(digest(Path(path)) != sha for path, sha in fixed.items()):
        raise ValueError("全固定コードの前後差")
    if any(digest(Path(item["path"])) != item["sha256"] for item in generated):
        raise ValueError("生成testmainの前後SHA差")
    value = {"試行": 116, "trial": 116, "成功": True, "停止": True, "市場前": True,
             "停止UTC": datetime.now(timezone.utc).isoformat(),
             "module": "github.com/masayoshi4649/SessionTradeExecuter/entrylife116",
             "所有コードSHA256": owned, "再用コードSHA256": before,
             "実Go依存SHA256": compiled, "全固定コードSHA256": fixed,
             "生成環境参照": generated, "生成環境参照前後不変": True,
             "全所有依存前後不変": True, "依存停止": stops,
             "主人工": 16, "export人工": 1, "成功test": passed,
             "実定義": ref(output / "実定義.json"), "実API": ref(output / "API.txt"),
             "Go人工": ref(output / "人工/ライフ系列.json"), "人工参照": ref(output / "人工/人工の参照.json"),
             "人工系列数": 8, "人工評価数": 48, "検査ログ": logs,
             "Rootレビュー後": True, "Raw/Native/価格CSV/11月09本文読取": 0,
             "金融市場実行": False, "旧Source/Chart/Actor/金融変更": False}
    write_new(target, value)
    print(json.dumps({"成功": True, "停止": ref(target), "実定義": value["実定義"], "Go人工": value["Go人工"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
