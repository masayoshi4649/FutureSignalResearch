package main

import (
	"encoding/json"
	life "github.com/masayoshi4649/SessionTradeExecuter/entrylife116"
	"os"
)

// main は純実定義をJSONとして標準出力へ渡します。
//
// 引数: なし。
// 返り値: なし。市場や外部ファイルを読まず、符号/時刻の定義だけを出力します。
func main() {
	encoder := json.NewEncoder(os.Stdout)
	encoder.SetIndent("", "  ")
	if err := encoder.Encode(life.DeclaredDefinition()); err != nil {
		panic(err)
	}
}
