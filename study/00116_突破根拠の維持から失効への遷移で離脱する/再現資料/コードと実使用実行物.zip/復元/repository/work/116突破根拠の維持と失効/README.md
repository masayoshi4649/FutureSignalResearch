# 突破根拠の維持と起動前失効の純演算

2026-11-10。市場前の人工検査用。収益改善は未確認。旧115のSource・入口・bank、113由来P100保護は変更しない。注文・約定・損益を計算しないmoduleである。

moduleは`github.com/masayoshi4649/SessionTradeExecuter/entrylife116`。公開型と[接続API](API案.md)、[実装](types.go)、[状態遷移](state.go)を参照する。

## 判定の役割

X0は追加失効なし。XCは取得後の新しい5分確定公表のClose、XQは最新5分Hist警戒中の全正常原行の返済側BBOで、出生時に固定した5分prior3境界のstrict内戻りを確認する。両者の差は時計だけでなくCloseと返済気配の系列・スプレッドを含む。入口3モードと費用4条件をActorが組み合わせる。純moduleは入口モードや枚数を変更しない。

出生Common真・方向調整DI15>0・G30既知非0を監視適格とする。出生票は旧115の式で再計算照合し、境界を固定する。実fill時の最新freshな5Close・Hist5・15DIと正常返済BBOが全て方向側strict>0ならarmed。実取得時から逆/不足なら未armedのままP100へ任せる。後のarmedはEnd>実fillの最新5公表がfreshな正常原行で同じ四条件を確認する。

armed後のHist5<=0を`Warning`と呼ぶ。これはHist警戒だけであり、価格が回復しただけでは解除しない。Hist>0で解除し、価格の距離はDecision.Valuesへ分けて保存する。XCはEnd>fillかつ配送原行Index>fillの新公表で同Closeが境界内側なら、異常気配でも失効を不可逆ラッチする。正常気配まで返済適格量は0。XQは同じ取得後Hist警戒がfreshな期間の全正常原行で返済BBOが境界内側ならラッチする。価格等号は失効しない。

実使用値は5Close/Hist、15+DI/-DI、30EMA8/21と各当場PriceKnown/freshのみ。未知・未公表・期限切れで未完成armedの鎖を切る。未使用ADX/RSI/BB/volume、既知DI反転や30G符号変化だけでは鎖を切らない。BBO異常はarmedを維持して判定/発注を待つ。既完成ラッチは回復やP100後起動でも取り消さない。未完成でP100が先に起動した場合は以後の新Xを無効化する。

## 原行と所有

`NewState(Entry)`は未評価Stateを作る。最初の`Advance`は実fillと同じ原行の`after_source`であり、P100更新・Source予約が先行する。以後は同秒でもIndexとSourceLineがstrictに進む原行だけを受け付ける。Snapshot.AsOf/ReplayObservedAtは現在Time、RecordOrdinalはIndex+1。公表IDの同値性・場/限月・確定/足終+60秒・未来・原行後退を検査する。

Coreは同原行の公表を全て保存してから最終Snapshotを渡す。純moduleは最新5公表だけを評価し、同原行内の中間公表を遡及評価しない。未観測の公表間隔だけで鎖切りを推定しない。取得時の古い公表や、取得後に配送されたEnd<=fillの公表をXC失効へ読み替えない。

純AdvanceはRemaining>0だけを受け付ける。ActorがSource/保護返済後にflatとなったら新しいX評価を行わず、最後の保有中Snapshotと別のFinalOwnershipへ最終返済quote/R/n0/reserved0を残す。部分返済n>0は継続する。`ExitEligibleQuantity`は正常気配時のRemaining−Reservedのみで、全予約0と完成事実を混同しない。QuoteOKの生フラグと有限Bid>0/Ask>BidのANDを使い、価格はマスクしない。

Stateはprivate、公開Snapshotは参照を分離する。全Rawで巨大JSONをcloneせず、同一公表はimmutable値を再用し、新ID時だけmapを複写する。私有履歴は原行stampと各尺度ID/Endだけ。イベントwitnessへ当時Inputを保存する。手製1000回の同公表benchmarkは約2µs/回・216B/回・3allocationであり、市場速度を保証する値ではない。

## 人工検査と停止

`go test ./...`、`go vet ./...`、`go build ./...`を実行する。`ENTRYLIFE116_ARTIFACT_DIR`へ未作成の絶対pathを指定して`go test -run '^TestExportArtificial$' -v`を実行すると、買売×X0/XC/XQと未知回復の8系列48評価を新規保存する。市場・Native・Raw・CSVは読まない。

`検査して停止する.py`は所有・旧依存停止・実Go閉包を認証し、人工・実定義・実APIを新規`検査/`へ出す。Rootレビュー前に停止を実行しない。正式停止は`停止.json`、実定義は`検査/実定義.json`。旧停止の変更や金融市場実行は含まない。
