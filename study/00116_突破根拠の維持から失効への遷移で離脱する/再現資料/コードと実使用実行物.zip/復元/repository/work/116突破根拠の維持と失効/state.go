package entrylife116

import (
	"encoding/json"
	"fmt"
	"math"
	"reflect"

	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate115"
	bank "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

// finite は公開する値が有限であるか検査します。
//
// 引数: values(...float64)は時計又は価格です。
// 返り値: boolは全て有限なら真です。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// validStamp は場内の採用原行stampを確認します。
//
// 引数: scope(Scope)、s(Stamp)は場時計と原行です。
// 返り値: boolは正しい範囲/Index/物理行なら真です。
func validStamp(scope Scope, s Stamp) bool {
	return finite(s.Time) && s.Time >= scope.Start && s.Time <= scope.End && s.Index >= 0 && s.Line > 0
}

// NewState は115出生票を同じ純判定へ照合し、未評価の116状態を作ります。
//
// 引数: e(Entry)は場/本名policy/方向/固定出生票/実fillstampです。
// 返り値: State/errorは独立状態又は不正です。初期armedは最初の同fill原行Advanceで決めます。
func NewState(e Entry) (State, error) {
	if _, err := json.Marshal(e); err != nil {
		return State{}, fmt.Errorf("116取得の非有限値:%w", err)
	}
	if e.ID == "" || (e.Policy != X0 && e.Policy != XC && e.Policy != XQ) || (e.Side != 1 && e.Side != -1) || e.Scope.Session == "" || e.Scope.Contract == "" || !finite(e.Scope.Start, e.Scope.End) || e.Scope.Start <= 0 || e.Scope.End <= e.Scope.Start || !validStamp(e.Scope, e.FillStamp) {
		return State{}, fmt.Errorf("116取得のID/政策/方向/場/原行が不正")
	}
	b := e.Birth
	if b.Version != 115 || !b.Frozen || b.Scope != e.Scope || b.Request.Side != e.Side || b.Request.Product != "NK225mini" || b.Current == nil || b.Current.Delivered != b.Request.At || e.FillStamp.Index <= b.Request.At.Index || e.FillStamp.Line <= b.Request.At.Line || e.FillStamp.Time < b.Request.At.Time {
		return State{}, fmt.Errorf("116出生票と実fillの結合が不正")
	}
	history, err := gate.NewHistory(e.Scope)
	if err != nil {
		return State{}, err
	}
	if err = history.SetSnapshot(b.Current.Snapshot, b.Current.Delivered); err != nil {
		return State{}, fmt.Errorf("116出生snapshot:%w", err)
	}
	recomputed, err := history.Evaluate(b.Request)
	if err != nil || !reflect.DeepEqual(b, recomputed) {
		return State{}, fmt.Errorf("116出生票が115固定式と不一致:%v", err)
	}
	eligible := b.Common == True && b.Values.D15 != nil && *b.Values.D15 > 0 && b.Values.G30 != nil && *b.Values.G30 != 0 && b.Values.Boundary != nil
	view := Snapshot{Version: 116, Entry: copyEntry(e), Definition: DeclaredDefinition(), MonitoringEligible: eligible}
	state := State{view: view, seen: map[string]bank.Frame{}, deliveries: map[string]Stamp{}}
	for _, scale := range b.Current.Snapshot.Scales {
		if !scale.HasCurrent {
			continue
		}
		f := scale.Current.Frame
		state.seen[f.ID] = scale.Current
		delivered := Stamp{Time: f.DeliveryAt, Index: int(f.RecordOrdinal) - 1}
		if int(f.RecordOrdinal)-1 == b.Request.At.Index {
			delivered.Line = b.Request.At.Line
		}
		state.deliveries[f.ID] = delivered
	}
	return state, nil
}

// Snapshot は現在の公開状態を参照共有なしで返します。
//
// 引数: s(State)は純状態です。
// 返り値: Snapshotは呼出側の変更が元状態へ波及しない値です。
func (s State) Snapshot() Snapshot { return copySnapshot(s.view) }

// cloneState は次評価だけに使う私有状態を複写します。
//
// 引数: s(State)は変更前の純状態です。
// 返り値: Stateはimmutableな過去値を共有する次状態です。mapは新公表時だけ別所有へ複写します。
func cloneState(s State) State {
	return State{view: s.view, seen: s.seen, deliveries: s.deliveries, lastInput: s.lastInput}
}

// validateInput は時刻・場・最新公表ID/全値と配送を次状態で検査します。
//
// 引数: s(*State)、in(Input)は次私有状態と現在原行の最新snapshotです。
// 返り値: errorは不正です。未知の実使用値自体はerrorでなく後段の鎖切りとします。
func validateInput(s *State, in Input) error {
	v := s.view
	scope := v.Entry.Scope
	if v.Version != 116 || in.Phase != AfterSource || !validStamp(scope, in.Stamp) || !finite(in.Bid, in.Ask) || in.Remaining <= 0 || in.Reserved < 0 || in.Reserved > in.Remaining {
		return fmt.Errorf("116状態/位相/原行/未予約量が不正")
	}
	if !v.Initialized {
		if in.Stamp != v.Entry.FillStamp {
			return fmt.Errorf("116初回評価は実fill同原行だけ")
		}
	} else {
		prev := s.lastInput.Stamp
		if in.Stamp.Time < prev.Time || in.Stamp.Index <= prev.Index || in.Stamp.Line <= prev.Line {
			return fmt.Errorf("116原行の後退又は二重評価")
		}
	}
	snap := in.Latest
	if snap.Session != v.Entry.Birth.Current.Snapshot.Session || snap.AsOf != in.Stamp.Time || snap.ReplayObservedAt != in.Stamp.Time || !snap.HasObserved || snap.Sealed || snap.RecordOrdinal != uint64(in.Stamp.Index)+1 {
		return fmt.Errorf("116最新snapshotの場/観測時計/原行差")
	}
	widths := [3]int{300, 900, 1800}
	copiedMaps := false
	for i, scale := range snap.Scales {
		if scale.WidthSeconds != widths[i] {
			return fmt.Errorf("116尺度の順序/重複")
		}
		if !scale.HasCurrent {
			if scale.Fresh {
				return fmt.Errorf("116未公表をfreshへ補完")
			}
			continue
		}
		f := scale.Current.Frame
		if scale.SeedOnly || f.ID == "" || f.SessionID != scope.Session || f.Contract != scope.Contract || f.WidthSeconds != widths[i] || f.Start < scope.Start || math.Mod(f.Start-scope.Start, float64(widths[i])) != 0 || f.End > scope.End || f.End != f.Start+float64(widths[i]) || f.NominalAvailable != f.End+60 || f.AvailableAt != f.NominalAvailable || f.DeliveryAt != f.ObservedAt || f.DeliveryAt < f.AvailableAt || f.DeliveryAt > in.Stamp.Time || f.RecordOrdinal < 1 || f.RecordOrdinal > snap.RecordOrdinal || f.PublicationOrdinal < 1 {
			return fmt.Errorf("116公表のscope/確定/可用/実配送が不正")
		}
		if scale.Fresh != (in.Stamp.Time-f.AvailableAt < float64(widths[i])) {
			return fmt.Errorf("116freshの偽装")
		}
		if prior, ok := s.seen[f.ID]; ok {
			if prior != scale.Current {
				return fmt.Errorf("116同公表IDの内容が改竄")
			}
		} else {
			if _, err := json.Marshal(scale.Current); err != nil {
				return fmt.Errorf("116新公表の非有限値:%w", err)
			}
			if f.PriceKnown && (f.OHLC.Low <= 0 || f.OHLC.High < math.Max(f.OHLC.Open, f.OHLC.Close) || f.OHLC.Low > math.Min(f.OHLC.Open, f.OHLC.Close)) {
				return fmt.Errorf("116既知価格足のOHLC不整合")
			}
			if v.Initialized && f.RecordOrdinal != snap.RecordOrdinal {
				return fmt.Errorf("116新公表を配送行以外で初めて受けた")
			}
			delivered := Stamp{Time: f.DeliveryAt, Index: int(f.RecordOrdinal) - 1}
			if f.RecordOrdinal == snap.RecordOrdinal {
				delivered.Line = in.Stamp.Line
			}
			if !copiedMaps {
				oldSeen, oldDeliveries := s.seen, s.deliveries
				s.seen, s.deliveries = map[string]bank.Frame{}, map[string]Stamp{}
				for k, v := range oldSeen {
					s.seen[k] = v
				}
				for k, v := range oldDeliveries {
					s.deliveries[k] = v
				}
				copiedMaps = true
			}
			s.deliveries[f.ID] = delivered
			s.seen[f.ID] = scale.Current
		}
		if s.lastInput != nil {
			previous := s.lastInput.Scales[i]
			if previous.HasCurrent {
				if f.End < previous.End || f.End == previous.End && f.ID != previous.ID {
					return fmt.Errorf("116最新公表の後退/同期間別ID")
				}
			}
		}
	}
	return nil
}

// inspect は実使用値だけを抽出し、準備ADX/RSI/BB/volumeを票へ入れません。
//
// 引数: v(Snapshot)、in(Input)は固定境界と現在の最新値です。
// 返り値: Decisionは既知性/鮮度/BBO/条件票です。注文や損益を計算しません。
func inspect(v Snapshot, in Input) Decision {
	d := Decision{Version: 116, Policy: v.Entry.Policy, Stamp: in.Stamp, InitialEvaluation: !v.Initialized, MonitoringEligible: v.MonitoringEligible, RequiredKnown: true, RequiredFresh: true, Missing: []string{}, Stale: []string{}}
	values := new([8]float64)
	d.QuoteOK = in.QuoteOK && in.Bid > 0 && in.Ask > in.Bid
	if v.Entry.Birth.Values.Boundary != nil {
		d.Values.Boundary = valueAt(values, 0, *v.Entry.Birth.Values.Boundary)
	}
	side := float64(v.Entry.Side)
	for i, scale := range in.Latest.Scales {
		name := []string{"5", "15", "30"}[i]
		if !scale.HasCurrent || scale.SeedOnly {
			d.RequiredKnown = false
			d.Missing = append(d.Missing, name+".当場公表")
			continue
		}
		if !scale.Fresh {
			d.RequiredFresh = false
			d.Stale = append(d.Stale, name+".fresh")
		}
		if !scale.Current.Frame.PriceKnown {
			d.RequiredKnown = false
			d.Missing = append(d.Missing, name+".PriceKnown")
			continue
		}
		t := scale.Current.Frame.Technical
		switch i {
		case 0:
			c := scale.Current.Frame.OHLC.Close
			d.Values.FiveClose = valueAt(values, 1, c)
			if d.Values.Boundary != nil {
				d.Values.SignedClose = valueAt(values, 2, side*(c-*d.Values.Boundary))
			}
			if t.Histogram.Known {
				d.Values.SignedHistogram = valueAt(values, 3, side*t.Histogram.Value)
			} else {
				d.RequiredKnown = false
				d.Missing = append(d.Missing, "5.Hist")
			}
		case 1:
			m := scale.Current.DMI
			if m.PlusDI.Known && m.MinusDI.Known {
				d.Values.SignedDI15 = valueAt(values, 4, side*(m.PlusDI.Value-m.MinusDI.Value))
			} else {
				d.RequiredKnown = false
				d.Missing = append(d.Missing, "15.DI")
			}
		case 2:
			if t.EMA8.Known && t.EMA21.Known {
				d.Values.G30 = valueAt(values, 5, side*(t.EMA8.Value-t.EMA21.Value))
			} else {
				d.RequiredKnown = false
				d.Missing = append(d.Missing, "30.EMA")
			}
		}
	}
	if d.QuoteOK && d.Values.Boundary != nil {
		mark := in.Bid
		if v.Entry.Side < 0 {
			mark = in.Ask
		}
		d.Values.ReturnBBO = valueAt(values, 6, mark)
		d.Values.SignedReturnBBO = valueAt(values, 7, side*(mark-*d.Values.Boundary))
	}
	d.ArmingCondition = Unknown
	if !v.MonitoringEligible {
		d.ArmingCondition = False
	} else if d.RequiredKnown && d.RequiredFresh && d.QuoteOK {
		d.ArmingCondition = False
		if *d.Values.SignedClose > 0 && *d.Values.SignedHistogram > 0 && *d.Values.SignedDI15 > 0 && *d.Values.SignedReturnBBO > 0 {
			d.ArmingCondition = True
		}
	}
	if in.Latest.Scales[0].HasCurrent {
		f := in.Latest.Scales[0].Current.Frame
		d.PostEntryFive = f.End > v.Entry.FillStamp.Time && int(f.RecordOrdinal)-1 > v.Entry.FillStamp.Index
	}
	return d
}

// witness は判断の入力/原行/最新5公表の配送出典を独立保存します。
//
// 引数: s(State)、in(Input)、d(Decision)、reason(string)は判断と理由です。
// 返り値: *Witnessは呼出側と参照共有しない証拠です。
func witness(s State, in Input, d Decision, reason string) *Witness {
	w := Witness{Input: in, Values: d.Values, Reason: reason}
	if in.Latest.Scales[0].HasCurrent {
		f := in.Latest.Scales[0].Current.Frame
		w.FiveDelivered = s.deliveries[f.ID]
		w.FiveDeliveryLineKnown = w.FiveDelivered.Line > 0
	}
	return copyWitness(&w)
}

// Advance は最新snapshot一つでarmed/失効を更新し、実未予約量だけを返します。
//
// 引数: state(State)、in(Input)は変更前状態とafter_sourceの現在値です。
// 返り値: State/Decision/errorは新状態と純返済適格量又は不正です。error時に元状態を変更しません。
func Advance(state State, in Input) (State, Decision, error) {
	if state.view.Version != 116 {
		return state, Decision{}, fmt.Errorf("116未初期化State")
	}
	next := cloneState(state)
	if err := validateInput(&next, in); err != nil {
		return state, Decision{}, err
	}
	v := &next.view
	d := inspect(*v, in)
	five := in.Latest.Scales[0]
	d.NewFivePublication = five.HasCurrent && five.Current.Frame.RecordOrdinal == in.Latest.RecordOrdinal && (state.lastInput == nil || !state.lastInput.Scales[0].HasCurrent || five.Current.Frame.ID != state.lastInput.Scales[0].ID)
	v.Sequence++
	at := in.Stamp
	v.At = &at
	if v.Entry.Policy == X0 || !v.MonitoringEligible {
		d.Reason = "追加監視なし"
	} else if v.Latched {
		v.Warning = v.Armed && d.RequiredKnown && d.RequiredFresh && d.PostEntryFive && d.Values.SignedHistogram != nil && *d.Values.SignedHistogram <= 0
		d.Reason = "既完成失効を保持"
	} else if v.DisabledByP100 || in.P100Active {
		v.DisabledByP100 = true
		v.Armed = false
		v.Warning = false
		d.Reason = "P100先起動へ委譲"
	} else {
		if !d.RequiredKnown || !d.RequiredFresh {
			if v.Armed {
				d.ChainBrokenNow = true
				v.ChainBreakCount++
				v.LastChainBreak = witness(next, in, d, "実使用Unknown/古さ")
			}
			v.Armed = false
			v.Warning = false
			d.Reason = "実使用値の鎖切り"
		}
		if !v.Armed && d.ArmingCondition == True && (d.InitialEvaluation || d.PostEntryFive) {
			v.Armed = true
			v.ArmingCount++
			d.ArmedNow = true
			w := witness(next, in, d, "維持根拠をarmed")
			if v.FirstArming == nil {
				v.FirstArming = w
			}
			v.LastArming = w
		}
		if v.Armed && d.RequiredKnown && d.RequiredFresh {
			v.Warning = d.PostEntryFive && d.Values.SignedHistogram != nil && *d.Values.SignedHistogram <= 0
			trigger := false
			if v.Warning && v.Entry.Policy == XC {
				trigger = d.NewFivePublication && *d.Values.SignedClose < 0
			}
			if v.Warning && v.Entry.Policy == XQ {
				trigger = d.QuoteOK && *d.Values.SignedReturnBBO < 0
			}
			if trigger {
				v.Latched = true
				d.InvalidatedNow = true
				v.Invalidation = witness(next, in, d, "取得後の突破根拠失効")
				d.Reason = "新しい失効を不可逆ラッチ"
			}
		}
	}
	d.Warning = v.Warning
	d.Armed, d.Latched, d.DisabledByP100, d.Sequence = v.Armed, v.Latched, v.DisabledByP100, v.Sequence
	if v.Latched && d.QuoteOK {
		d.ExitEligibleQuantity = in.Remaining - in.Reserved
	}
	v.Initialized = true
	history := inputHistory{Stamp: in.Stamp}
	for i, scale := range in.Latest.Scales {
		history.Scales[i] = frameHistory{HasCurrent: scale.HasCurrent, ID: scale.Current.Frame.ID, End: scale.Current.Frame.End}
	}
	next.lastInput = &history
	return next, d, nil
}
