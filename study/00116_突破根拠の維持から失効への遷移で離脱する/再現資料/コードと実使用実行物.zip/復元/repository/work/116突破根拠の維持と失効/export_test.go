package entrylife116

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
)

type artificialStep struct {
	BeforeSnapshot Snapshot `json:"before_snapshot"`
	Input          Input    `json:"input"`
	AfterSnapshot  Snapshot `json:"after_snapshot"`
	Decision       Decision `json:"decision"`
}
type artificialCase struct {
	ID              string           `json:"id"`
	Entry           Entry            `json:"entry"`
	InitialSnapshot Snapshot         `json:"initial_snapshot"`
	Steps           []artificialStep `json:"steps"`
}
type artifactRef struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
}

// exportSeries は買売と三政策の同じ人工原行列を、独立再計算用に残します。
//
// 引数: t(*testing.T)、policy(Policy)、side(int)は検査器/本名政策/方向です。
// 返り値: artificialCaseは各段階の変更前状態・入力・変更後状態・判断です。
func exportSeries(t *testing.T, policy Policy, side int) artificialCase {
	t.Helper()
	e, initial := handEntry(t, policy, side, artificialStart+7260)
	s, err := NewState(e)
	if err != nil {
		t.Fatal(err)
	}
	c := artificialCase{ID: fmt.Sprintf("基本_%s_%d", policy, side), Entry: e, InitialSnapshot: s.Snapshot(), Steps: []artificialStep{}}
	// appendStep は現在系列へ一回の純遷移を追加します。
	// 引数: in(Input)は現在原行です。返り値: なし。
	appendStep := func(in Input) {
		before := s.Snapshot()
		next, d := advanceOK(t, s, in)
		c.Steps = append(c.Steps, artificialStep{before, in, next.Snapshot(), d})
		s = next
	}
	appendStep(initial)
	bad := later(e, initial, artificialStart+7560, 995, -1)
	setQuote(&bad, side, 994, 996)
	bad.QuoteOK = false
	appendStep(bad)
	normal := later(e, bad, bad.Stamp.Time, 995, -1)
	normal.QuoteOK = true
	normal.Reserved = normal.Remaining
	appendStep(normal)
	free := later(e, normal, normal.Stamp.Time, 995, -1)
	free.Reserved = 1
	appendStep(free)
	recovered := later(e, free, artificialStart+7860, 1010, 2)
	setQuote(&recovered, side, 1008, 1010)
	recovered.Reserved = 0
	appendStep(recovered)
	p100 := later(e, recovered, recovered.Stamp.Time, 1010, 2)
	p100.P100Active = true
	appendStep(p100)
	return c
}

// exportRecovery は初期逆からの回復と、実使用Unknownによる鎖切りを残します。
//
// 引数: t(*testing.T)、side(int)は検査器/方向です。
// 返り値: artificialCaseは再armed・Hist警戒・P100委譲を含む手製系列です。
func exportRecovery(t *testing.T, side int) artificialCase {
	t.Helper()
	e, initial := handEntry(t, XQ, side, artificialStart+7260)
	setQuote(&initial, side, 998, 1000)
	s, err := NewState(e)
	if err != nil {
		t.Fatal(err)
	}
	c := artificialCase{ID: fmt.Sprintf("回復と未知_%d", side), Entry: e, InitialSnapshot: s.Snapshot(), Steps: []artificialStep{}}
	// appendStep は現在系列へ一回の純遷移を追加します。
	// 引数: in(Input)は現在原行です。返り値: なし。
	appendStep := func(in Input) {
		before := s.Snapshot()
		next, d := advanceOK(t, s, in)
		c.Steps = append(c.Steps, artificialStep{before, in, next.Snapshot(), d})
		s = next
	}
	appendStep(initial)
	good := later(e, initial, artificialStart+7560, 1010, 2)
	setQuote(&good, side, 1008, 1010)
	appendStep(good)
	unknown := later(e, good, artificialStart+7860, 1010, 2)
	unknown.Latest.Scales[0].Current.Frame.Technical.Histogram.Known = false
	appendStep(unknown)
	rearm := later(e, unknown, artificialStart+8160, 1010, 2)
	appendStep(rearm)
	warning := later(e, rearm, artificialStart+8460, 1010, -1)
	appendStep(warning)
	p100 := later(e, warning, warning.Stamp.Time, 1010, -1)
	p100.P100Active = true
	appendStep(p100)
	return c
}

// writeArtifact は新規出力だけを許可してUTF-8 JSONとSHAを返します。
//
// 引数: t(*testing.T)、path(string)、value(any)は検査器/未作成先/公開値です。
// 返り値: artifactRefは絶対pathと全bytesのSHA256です。
func writeArtifact(t *testing.T, path string, value any) artifactRef {
	t.Helper()
	b, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	b = append(b, '\n')
	f, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = f.Write(b); err != nil {
		f.Close()
		t.Fatal(err)
	}
	if err = f.Close(); err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(b)
	return artifactRef{Path: path, SHA256: hex.EncodeToString(sum[:])}
}

// TestExportArtificial は明示した新規先だけへ人工系列と実定義を書きます。
//
// 引数: t(*testing.T)は検査器です。環境変数ENTRYLIFE116_ARTIFACT_DIRが出力先です。
// 返り値: なし。未指定時はskipし、市場・Native・CSVを読みません。
func TestExportArtificial(t *testing.T) {
	dir := os.Getenv("ENTRYLIFE116_ARTIFACT_DIR")
	if dir == "" {
		t.Skip("人工出力先の明示なし")
	}
	abs, err := filepath.Abs(dir)
	if err != nil {
		t.Fatal(err)
	}
	if err = os.Mkdir(abs, 0700); err != nil {
		t.Fatal(err)
	}
	cases := []artificialCase{}
	for _, policy := range []Policy{X0, XC, XQ} {
		for _, side := range []int{1, -1} {
			cases = append(cases, exportSeries(t, policy, side))
		}
	}
	for _, side := range []int{1, -1} {
		cases = append(cases, exportRecovery(t, side))
	}
	series := writeArtifact(t, filepath.Join(abs, "ライフ系列.json"), map[string]any{"trial": 116, "artificial": true, "market_read": false, "definition": DeclaredDefinition(), "cases": cases})
	definition := writeArtifact(t, filepath.Join(abs, "実定義.json"), DeclaredDefinition())
	manifest := map[string]any{"試行": 116, "人工": true, "市場読取": false, "系列数": len(cases), "評価数": len(cases) * 6, "系列": series, "実定義": definition}
	ref := writeArtifact(t, filepath.Join(abs, "人工の参照.json"), manifest)
	t.Logf("人工参照=%s SHA256=%s", ref.Path, ref.SHA256)
}
