package entrylife116

import (
	"fmt"
	"math"
	"reflect"
	"testing"

	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate115"
	old "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	bank "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

const artificialStart = 1800000000.0

// mirror は買基準の人工価格を売買鏡像へ写します。
//
// 引数: side(int)、price(float64)は方向と買基準価格です。
// 返り値: float64は実人工価格です。
func mirror(side int, price float64) float64 {
	if side < 0 {
		return 3000 - price
	}
	return price
}

// handLatest は価格計算を実行せず、有限で当時公表済みの手製三尺度を作ります。
//
// 引数: scope(Scope)、previous(bank.Snapshot)、at(Stamp)、side(int)、close/hist(float64)は場/前値/原行/鏡像/新5値です。
// 返り値: bank.Snapshotは最新だけの手製公表です。市場入力を読みません。
func handLatest(scope Scope, previous bank.Snapshot, at Stamp, side int, close, hist float64) bank.Snapshot {
	snap := previous
	snap.Session = old.Session{ID: scope.Session, Contract: scope.Contract, Start: scope.Start, End: scope.End, EOF: scope.End}
	snap.AsOf, snap.ReplayObservedAt, snap.HasObserved, snap.RecordOrdinal = at.Time, at.Time, true, uint64(at.Index)+1
	for i, width := range [3]int{300, 900, 1800} {
		end := scope.Start + math.Floor((at.Time-scope.Start-60)/float64(width))*float64(width)
		scale := snap.Scales[i]
		scale.WidthSeconds = width
		if !scale.HasCurrent || end > scale.Current.Frame.End {
			price := 1010.0
			if i == 0 {
				price = close
			}
			price = mirror(side, price)
			frame := old.Frame{ID: fmt.Sprintf("人工-%d-%.0f-%d", width, end, side), SessionID: scope.Session, Contract: scope.Contract, WidthSeconds: width, Start: end - float64(width), End: end, NominalAvailable: end + 60, AvailableAt: end + 60, ObservedAt: at.Time, DeliveryAt: at.Time, RecordOrdinal: uint64(at.Index) + 1, PublicationOrdinal: uint64(at.Index) + 1, PriceKnown: true, OHLC: old.OHLC{Open: price, High: price + 2, Low: price - 2, Close: price}}
			frame.Technical.EMA8 = old.Value{Known: true, Value: mirror(side, 1015)}
			frame.Technical.EMA21 = old.Value{Known: true, Value: mirror(side, 1005)}
			frame.Technical.Histogram = old.Value{Known: true, Value: float64(side) * 2}
			if i == 0 {
				frame.Technical.Histogram.Value = float64(side) * hist
			}
			frame.Technical.PreviousATR = old.Value{Known: true, Value: 10}
			frame.Technical.TR = old.Value{Known: true, Value: 10}
			scale.Current = bank.Frame{Frame: frame, DMI: bank.DMI{PlusDI: old.Value{Known: true, Value: 30}, MinusDI: old.Value{Known: true, Value: 10}, ADX: old.Value{Known: true, Value: 25}}}
			if side < 0 {
				scale.Current.DMI.PlusDI.Value, scale.Current.DMI.MinusDI.Value = 10, 30
			}
			if i == 0 {
				st := bank.Structure{Known: true, High: 1000, Low: 980}
				if side < 0 {
					st.High, st.Low = 2020, 2000
				}
				for j := range st.Refs {
					end := frame.Start - float64(2-j)*300
					st.Refs[j] = old.BarRef{ID: fmt.Sprintf("前足%d", j), Start: end - 300, End: end, PublishedAt: end + 60}
				}
				scale.Current.Structure = st
			}
			scale.HasCurrent = true
		}
		scale.Fresh = at.Time-scale.Current.Frame.AvailableAt < float64(width)
		snap.Scales[i] = scale
	}
	return snap
}

// handEntry は実115純判定で凍結した人工出生と、その後の実fill原行を作ります。
//
// 引数: t(testing.TB)、policy(Policy)、side(int)、birthTime(float64)は検査器/政策/鏡像/出生時計です。
// 返り値: Entry/Inputは未評価取得と同fill原行の初回入力です。
func handEntry(t testing.TB, policy Policy, side int, birthTime float64) (Entry, Input) {
	t.Helper()
	scope := Scope{Session: "人工116", Contract: "人工限月", Start: artificialStart, End: artificialStart + 25200}
	birthAt := Stamp{Time: birthTime, Index: 100, Line: 200}
	snap := handLatest(scope, bank.Snapshot{}, birthAt, side, 1010, 2)
	h, err := gate.NewHistory(scope)
	if err != nil {
		t.Fatal(err)
	}
	if err = h.SetSnapshot(snap, birthAt); err != nil {
		t.Fatal(err)
	}
	birth, err := h.Evaluate(gate.Request{Product: "NK225mini", Method: "NK225_D164_15", SignalID: fmt.Sprintf("人工出生%d", side), Side: side, At: birthAt, Last: mirror(side, 1010)})
	if err != nil || birth.Common != True {
		t.Fatalf("人工出生:%v %#v", err, birth)
	}
	fill := Stamp{Time: birthTime + 1, Index: 101, Line: 201}
	e := Entry{Scope: scope, ID: fmt.Sprintf("人工実玉%d", side), Policy: policy, Side: side, Birth: birth, FillStamp: fill}
	initial := Input{Stamp: fill, Phase: AfterSource, Latest: handLatest(scope, snap, fill, side, 1010, 2), Remaining: 3, QuoteOK: true}
	setQuote(&initial, side, 1008, 1010)
	return e, initial
}

// setQuote は生の人工BBOを鏡像で入力へ設定します。
//
// 引数: in(*Input)、side(int)、bid/ask(float64)は入力/方向/買基準気配です。
// 返り値: なし。QuoteOKを勝手に補正しません。
func setQuote(in *Input, side int, bid, ask float64) {
	in.Bid, in.Ask = bid, ask
	if side < 0 {
		in.Bid, in.Ask = 3000-ask, 3000-bid
	}
}

// later は前入力から後の原行と最新公表を作ります。
//
// 引数: e(Entry)、previous(Input)、at/close/hist(float64)は取得/前入力/時計/買基準値です。
// 返り値: Inputは次の人工原行です。
func later(e Entry, previous Input, at, close, hist float64) Input {
	in := previous
	in.Stamp = Stamp{Time: at, Index: previous.Stamp.Index + 1, Line: previous.Stamp.Line + 1}
	in.Latest = handLatest(e.Scope, previous.Latest, in.Stamp, e.Side, close, hist)
	return in
}

// advanceOK は成功した純遷移だけを検査へ返します。
//
// 引数: t(testing.TB)、s(State)、in(Input)は検査器/前状態/現在入力です。
// 返り値: State/Decisionは新状態と判断です。
func advanceOK(t testing.TB, s State, in Input) (State, Decision) {
	t.Helper()
	n, d, err := Advance(s, in)
	if err != nil {
		t.Fatal(err)
	}
	return n, d
}

// initialState は同fill原行の初回Advanceまで進めます。
//
// 引数: t(testing.TB)、e(Entry)、in(Input)は検査器/取得/初期入力です。
// 返り値: Stateは評価済み人工状態です。
func initialState(t testing.TB, e Entry, in Input) State {
	t.Helper()
	s, err := NewState(e)
	if err != nil {
		t.Fatal(err)
	}
	s, _ = advanceOK(t, s, in)
	return s
}

// TestInitialArmingMirror は実fill時四票と鏡像を確認します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestInitialArmingMirror(t *testing.T) {
	for _, side := range []int{1, -1} {
		e, in := handEntry(t, XC, side, artificialStart+7260)
		s := initialState(t, e, in)
		v := s.Snapshot()
		if !v.Armed || v.Latched || v.Warning || v.ArmingCount != 1 || v.FirstArming.Input.Stamp != e.FillStamp {
			t.Fatal("初期四票")
		}
	}
}

// TestInitialReverseDoesNotInvalidate は取得時から内側の玉を失効へ読み替えません。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestInitialReverseDoesNotInvalidate(t *testing.T) {
	e, in := handEntry(t, XQ, 1, artificialStart+7260)
	setQuote(&in, 1, 998, 1000)
	s := initialState(t, e, in)
	if s.Snapshot().Armed {
		t.Fatal("既逆なのにarm")
	}
	bad := later(e, in, artificialStart+7560, 995, -1)
	setQuote(&bad, 1, 994, 996)
	s, d := advanceOK(t, s, bad)
	if d.InvalidatedNow || s.Snapshot().Latched {
		t.Fatal("未armの逆を失効")
	}
	good := later(e, bad, artificialStart+7860, 1010, 2)
	setQuote(&good, 1, 1008, 1010)
	s, d = advanceOK(t, s, good)
	if !d.ArmedNow || !s.Snapshot().Armed {
		t.Fatal("後の回復arm")
	}
}

// TestCloseAndQuoteDifferentClock はXCの公表判定とXQの全正常Rawを分けます。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestCloseAndQuoteDifferentClock(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, policy := range []Policy{XC, XQ} {
			e, in := handEntry(t, policy, side, artificialStart+7260)
			s := initialState(t, e, in)
			pub := later(e, in, artificialStart+7560, 995, -1)
			setQuote(&pub, side, 1003, 1005)
			s, d := advanceOK(t, s, pub)
			if d.InvalidatedNow != (policy == XC) {
				t.Fatal("CloseとBBO")
			}
			raw := later(e, pub, pub.Stamp.Time, 995, -1)
			setQuote(&raw, side, 994, 996)
			s, d = advanceOK(t, s, raw)
			if !s.Snapshot().Latched || d.NewFivePublication || d.InvalidatedNow != (policy == XQ) || d.ExitEligibleQuantity != 3 {
				t.Fatal("同秒後RawのXQ")
			}
		}
	}
}

// TestBadQuoteFlagWaitsButXCCompletes は生QuoteOK偽を価格0で隠しません。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestBadQuoteFlagWaitsButXCCompletes(t *testing.T) {
	for _, policy := range []Policy{XC, XQ} {
		e, in := handEntry(t, policy, 1, artificialStart+7260)
		s := initialState(t, e, in)
		pub := later(e, in, artificialStart+7560, 995, -1)
		setQuote(&pub, 1, 994, 996)
		pub.QuoteOK = false
		s, d := advanceOK(t, s, pub)
		if d.QuoteOK || d.ChainBrokenNow || !s.Snapshot().Armed || d.ExitEligibleQuantity != 0 || s.Snapshot().Latched != (policy == XC) {
			t.Fatal("異常気配の処理")
		}
		raw := later(e, pub, pub.Stamp.Time+1, 995, -1)
		raw.QuoteOK = true
		s, d = advanceOK(t, s, raw)
		if !s.Snapshot().Latched || d.ExitEligibleQuantity != 3 {
			t.Fatal("正常待ち完了")
		}
	}
}

// TestUnknownResetAndRearm は必須Hist未知と回復後の再armを確認します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestUnknownResetAndRearm(t *testing.T) {
	e, in := handEntry(t, XC, 1, artificialStart+7260)
	s := initialState(t, e, in)
	unknown := later(e, in, artificialStart+7560, 995, -1)
	unknown.Latest.Scales[0].Current.Frame.Technical.Histogram = old.Value{}
	s, d := advanceOK(t, s, unknown)
	if !d.ChainBrokenNow || s.Snapshot().Armed || s.Snapshot().Latched {
		t.Fatal("未知鎖切り")
	}
	neg := later(e, unknown, artificialStart+7860, 995, -1)
	s, _ = advanceOK(t, s, neg)
	if s.Snapshot().Latched {
		t.Fatal("未armedで失効")
	}
	good := later(e, neg, artificialStart+8160, 1010, 2)
	setQuote(&good, 1, 1008, 1010)
	s, d = advanceOK(t, s, good)
	if !d.ArmedNow || s.Snapshot().ArmingCount != 2 {
		t.Fatal("再arm")
	}
}

// TestUnusedUnknownAndKnownReversal は準備指標と既知方向変化を鎖切りにしません。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestUnusedUnknownAndKnownReversal(t *testing.T) {
	e, in := handEntry(t, XQ, 1, artificialStart+7260)
	s := initialState(t, e, in)
	next := later(e, in, artificialStart+9060, 1010, 2)
	for i := range next.Latest.Scales {
		next.Latest.Scales[i].Current.Frame.Technical.RSI = old.Value{}
		next.Latest.Scales[i].Current.DMI.ADX = old.Value{}
	}
	next.Latest.Scales[1].Current.DMI.PlusDI.Value = 5
	next.Latest.Scales[1].Current.DMI.MinusDI.Value = 30
	next.Latest.Scales[2].Current.Frame.Technical.EMA8.Value = 990
	next.Latest.Scales[2].Current.Frame.Technical.EMA21.Value = 1005
	s, d := advanceOK(t, s, next)
	if d.ChainBrokenNow || !s.Snapshot().Armed || d.ArmingCondition != False {
		t.Fatal("既知DI/30G逆でdisarm")
	}
}

// TestDelayedPublicationExcluded は配送後でもEndが取得以前の足を新失効にしません。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestDelayedPublicationExcluded(t *testing.T) {
	e, in := handEntry(t, XC, 1, artificialStart+7200)
	e.FillStamp.Time = artificialStart + 7206
	in.Stamp = e.FillStamp
	in.Latest = handLatest(e.Scope, e.Birth.Current.Snapshot, in.Stamp, 1, 1010, 2)
	s := initialState(t, e, in)
	pub := later(e, in, artificialStart+7260, 995, -1)
	setQuote(&pub, 1, 994, 996)
	s, d := advanceOK(t, s, pub)
	if !d.NewFivePublication || d.PostEntryFive || d.Warning || s.Snapshot().Latched {
		t.Fatal("遅延公表を新失効へ使用")
	}
}

// TestP100PriorityAndCompletedLatch は先行委譲と既X後のP100を分けます。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestP100PriorityAndCompletedLatch(t *testing.T) {
	e, in := handEntry(t, XC, 1, artificialStart+7260)
	base := initialState(t, e, in)
	pub := later(e, in, artificialStart+7560, 995, -1)
	setQuote(&pub, 1, 994, 996)
	active := pub
	active.P100Active = true
	s, d := advanceOK(t, base, active)
	if d.InvalidatedNow || !s.Snapshot().DisabledByP100 {
		t.Fatal("P100先起動")
	}
	latched, _ := advanceOK(t, base, pub)
	after := later(e, pub, pub.Stamp.Time+1, 995, -1)
	after.P100Active = true
	latched, d = advanceOK(t, latched, after)
	if !latched.Snapshot().Latched || d.ExitEligibleQuantity != 3 {
		t.Fatal("既X後のP100で取消")
	}
}

// TestReservationAndRecovery は全予約0と回復後の既ラッチ非取消を確認します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestReservationAndRecovery(t *testing.T) {
	e, in := handEntry(t, XC, 1, artificialStart+7260)
	s := initialState(t, e, in)
	pub := later(e, in, artificialStart+7560, 995, -1)
	pub.Reserved = 3
	s, d := advanceOK(t, s, pub)
	if !d.InvalidatedNow || d.ExitEligibleQuantity != 0 {
		t.Fatal("全予約と成立混同")
	}
	recovered := later(e, pub, artificialStart+7860, 1010, 2)
	recovered.Reserved = 1
	s, d = advanceOK(t, s, recovered)
	if !s.Snapshot().Latched || d.Warning || d.ExitEligibleQuantity != 2 {
		t.Fatal("回復取消又はfree量")
	}
}

// TestHistWarningSeparateFromPrice は価格回復だけではHist警戒を解除しません。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestHistWarningSeparateFromPrice(t *testing.T) {
	e, in := handEntry(t, XQ, 1, artificialStart+7260)
	s := initialState(t, e, in)
	pub := later(e, in, artificialStart+7560, 1010, 0)
	s, d := advanceOK(t, s, pub)
	if !d.Warning || s.Snapshot().Latched {
		t.Fatal("Hist0警戒")
	}
	raw := later(e, pub, pub.Stamp.Time+1, 1010, 0)
	setQuote(&raw, 1, 1015, 1017)
	s, d = advanceOK(t, s, raw)
	if !d.Warning || s.Snapshot().Latched {
		t.Fatal("価格だけの回復")
	}
}

// TestEqualityAndX0 は境界等号と追加なし政策を確認します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestEqualityAndX0(t *testing.T) {
	for _, policy := range []Policy{X0, XC, XQ} {
		e, in := handEntry(t, policy, 1, artificialStart+7260)
		s := initialState(t, e, in)
		pub := later(e, in, artificialStart+7560, 1000, 0)
		setQuote(&pub, 1, 1000, 1002)
		s, d := advanceOK(t, s, pub)
		if d.InvalidatedNow || s.Snapshot().Latched {
			t.Fatal("価格等号又はX0")
		}
	}
}

// TestStaleReset は現在公表の期限切れと必須値未知を区別します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestStaleReset(t *testing.T) {
	e, in := handEntry(t, XC, 1, artificialStart+7260)
	s := initialState(t, e, in)
	stale := in
	stale.Stamp = Stamp{Time: artificialStart + 7560, Index: 102, Line: 202}
	stale.Latest.AsOf, stale.Latest.ReplayObservedAt, stale.Latest.RecordOrdinal = stale.Stamp.Time, stale.Stamp.Time, 103
	for i := range stale.Latest.Scales {
		scale := &stale.Latest.Scales[i]
		scale.Fresh = stale.Stamp.Time-scale.Current.Frame.AvailableAt < float64(scale.WidthSeconds)
	}
	s, d := advanceOK(t, s, stale)
	if !d.ChainBrokenNow || len(d.Stale) != 1 || !d.RequiredKnown || s.Snapshot().Armed {
		t.Fatal("fresh等号で鎖切り")
	}
}

// TestTamperFutureAndRowOrder は不正入力を拒否し元状態を保存します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestTamperFutureAndRowOrder(t *testing.T) {
	e, in := handEntry(t, XC, 1, artificialStart+7260)
	s := initialState(t, e, in)
	before := s.Snapshot()
	cases := []Input{in, later(e, in, in.Stamp.Time, 1010, 2), later(e, in, in.Stamp.Time+1, 1010, 2), later(e, in, in.Stamp.Time+1, 1010, 2), later(e, in, in.Stamp.Time+1, 1010, 2)}
	cases[1].Latest.Scales[0].Current.Frame.Technical.Histogram.Value += 1
	cases[2].Latest.Scales[0].Current.Frame.DeliveryAt = cases[2].Stamp.Time + 1
	cases[3].Latest.Session.Contract = "別限月"
	cases[4].Stamp.Line = in.Stamp.Line
	for i, bad := range cases {
		if _, _, err := Advance(s, bad); err == nil {
			t.Fatalf("不正%dを受理", i)
		}
		if !reflect.DeepEqual(before, s.Snapshot()) {
			t.Fatal("errorで元State変更")
		}
	}
}

// TestCopySeparationAndFork は入力/公開状態/判断の可変欄を独立させます。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestCopySeparationAndFork(t *testing.T) {
	e, in := handEntry(t, XC, 1, artificialStart+7260)
	s, err := NewState(e)
	if err != nil {
		t.Fatal(err)
	}
	*e.Birth.Values.Boundary = 1
	s, d := advanceOK(t, s, in)
	before := s.Snapshot()
	*d.Values.Boundary = 2
	out := s.Snapshot()
	*out.Entry.Birth.Values.Boundary = 3
	out.Definition.Policies[0] = XQ
	out.FirstArming.Input.Latest.Scales[0].Current.Frame.OHLC.Close = 4
	*out.FirstArming.Values.Boundary = 5
	if !reflect.DeepEqual(before, s.Snapshot()) {
		t.Fatal("公開値参照がStateへ波及")
	}
	pub := later(before.Entry, in, artificialStart+7560, 995, -1)
	left, _ := advanceOK(t, s, pub)
	good := pub
	good.Latest.Scales[0].Current.Frame.OHLC = old.OHLC{Open: 1010, High: 1012, Low: 1008, Close: 1010}
	good.Latest.Scales[0].Current.Frame.Technical.Histogram.Value = 2
	right, _ := advanceOK(t, s, good)
	if !left.Snapshot().Latched || right.Snapshot().Latched || !reflect.DeepEqual(before, s.Snapshot()) {
		t.Fatal("COW分岐の共有変更")
	}
}

// TestZeroOwnershipRejected は実flat後の新arm/失効評価を拒否します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。終了所有はActorの別証拠へ保存します。
func TestZeroOwnershipRejected(t *testing.T) {
	e, in := handEntry(t, XC, 1, artificialStart+7260)
	s := initialState(t, e, in)
	before := s.Snapshot()
	next := later(e, in, artificialStart+7560, 995, -1)
	next.Remaining = 0
	if _, _, err := Advance(s, next); err == nil || !reflect.DeepEqual(before, s.Snapshot()) {
		t.Fatal("flat評価を受理又は元State変更")
	}
}

// TestIneligibleBirthKeepsP100 は追加適格でないA0出生を再拒否も監視もしません。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestIneligibleBirthKeepsP100(t *testing.T) {
	e, in := handEntry(t, XC, 1, artificialStart+7260)
	r := e.Birth.Request
	r.Last = 1000
	h, _ := gate.NewHistory(e.Scope)
	if err := h.SetSnapshot(e.Birth.Current.Snapshot, e.Birth.Current.Delivered); err != nil {
		t.Fatal(err)
	}
	b, err := h.Evaluate(r)
	if err != nil {
		t.Fatal(err)
	}
	e.Birth = b
	s := initialState(t, e, in)
	bad := later(e, in, artificialStart+7560, 995, -1)
	s, d := advanceOK(t, s, bad)
	if s.Snapshot().MonitoringEligible || s.Snapshot().Armed || d.InvalidatedNow {
		t.Fatal("非適格出生へXを追加")
	}
}

// BenchmarkUnchangedRaw は同公表を使う全Raw経路のallocationを手製で測ります。
//
// 引数: b(*testing.B)は計測器。返り値: なし。市場入力や損益は計算しません。
func BenchmarkUnchangedRaw(b *testing.B) {
	e, in := handEntry(b, XC, 1, artificialStart+7260)
	s := initialState(b, e, in)
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		in.Stamp.Index++
		in.Stamp.Line++
		in.Latest.RecordOrdinal = uint64(in.Stamp.Index) + 1
		var err error
		s, _, err = Advance(s, in)
		if err != nil {
			b.Fatal(err)
		}
	}
}
