# entrylife116の接続API

2026-11-10。Root選択の純状態遷移を実装中。市場・Native・CSV読取なし、旧停止Go変更なし。正式停止はRootレビュー後。

module `github.com/masayoshi4649/SessionTradeExecuter/entrylife116`、package `entrylife116`。

```go
func NewState(e Entry) (State, error)
func Advance(state State, in Input) (State, Decision, error)
func (s State) Snapshot() Snapshot
func DeclaredDefinition() Definition
```

Entryは`Scope,ID,Policy(X0/XC/XQ),Side,Birth(gate115.Decision),FillStamp(gate115.Stamp)`。NewStateでは未評価。初回AdvanceのStampはFillStampと同原行のafter_sourceを必須にする。実fill→P100 after_source→X初回Advanceの順で、初期の最新公表を使う。

Inputは`Stamp,Phase(AfterSource),Latest(bank115.Snapshot),Bid,Ask,QuoteOK,Remaining,Reserved,P100Active`。生QuoteOKと有限Bid>0/Ask>BidのANDで正常気配を判定し、価格を0へマスクしない。R/損益を純Xで計算しない。Actorの実Rは会計証拠へ別保存する。返り値Decisionの`ExitEligibleQuantity`は注文ではなく正常BBO時の未予約数量のみで、全予約0と`Snapshot.Latched`を分ける。DecisionのArmed/Latched/DisabledByP100/Sequenceで毎原行の要点を読み、監査Snapshotの取得を必要点に絞れる。

最新Snapshotだけを評価し、同一Rawにまとめて配送された中間の古い5公表を遡及評価しない。Coreは全公表を別に保存する。Snapshot.RecordOrdinal=Stamp.Index+1、AsOf/ReplayObservedAt=Stamp.Time。当場scope・公表IDと内容・未来・原行後退を検査する。

新しい5FrameのRecordOrdinal−1が現在Stamp.Indexなら、その配送SourceLineをStamp.Lineで保存する。初期旧公表はXC失効対象外。初回後は同原行再Advanceを二重更新として拒否、同秒別Index/物理行は許す。純Stateはcopyし、errorでも元Stateを変更しない。

Snapshot/Decision/Witnessの実fieldはtypes.go。Witnessは入力Snapshotと原行をコピーして初arm/再arm/鎖切り/初失効を保存する。Actorはこの型をそのまま保存し、元値のマスク・費用値の偽装をしない。

Advanceは実保有中のRemaining>0だけを受け付ける。after_sourceでn=0ならActorは最後の保有中Pure Stateと別FinalOwnership（最終実返済quote/R/n0/reserved0）を保存して終了し、純Xへflat原行を渡して新arm/失効を作らない。部分返済n>0は継続する。Warningは価格警戒ではなくHist警戒だけで、Hist>0で解除し価格回復だけでは消さない。
