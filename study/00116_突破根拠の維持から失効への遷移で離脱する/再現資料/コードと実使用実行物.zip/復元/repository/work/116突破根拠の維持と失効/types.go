// Package entrylife116 は固定出生境界の維持と起動前失効だけを純演算します。
package entrylife116

import (
	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate115"
	bank "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

type Scope = gate.Scope
type Stamp = gate.Stamp
type Truth = gate.Truth

const (
	Unknown = gate.Unknown
	False   = gate.False
	True    = gate.True
)

type Policy string

const (
	X0 Policy = "X0"
	XC Policy = "XC"
	XQ Policy = "XQ"
)

type Phase string

const AfterSource Phase = "after_source"

type Entry struct {
	Scope     Scope         `json:"scope"`
	ID        string        `json:"id"`
	Policy    Policy        `json:"policy"`
	Side      int           `json:"side"`
	Birth     gate.Decision `json:"birth"`
	FillStamp Stamp         `json:"fill_stamp"`
}

type Input struct {
	Stamp      Stamp         `json:"stamp"`
	Phase      Phase         `json:"phase"`
	Latest     bank.Snapshot `json:"latest"`
	Bid        float64       `json:"bid"`
	Ask        float64       `json:"ask"`
	QuoteOK    bool          `json:"quote_ok"`
	Remaining  int           `json:"remaining"`
	Reserved   int           `json:"reserved"`
	P100Active bool          `json:"P100_active"`
}

type Values struct {
	Boundary        *float64 `json:"boundary"`
	FiveClose       *float64 `json:"five_close"`
	SignedClose     *float64 `json:"signed_close"`
	SignedHistogram *float64 `json:"signed_histogram"`
	SignedDI15      *float64 `json:"signed_di15"`
	G30             *float64 `json:"g30"`
	ReturnBBO       *float64 `json:"return_BBO"`
	SignedReturnBBO *float64 `json:"signed_return_BBO"`
}

type Witness struct {
	Input                 Input  `json:"input"`
	Values                Values `json:"values"`
	FiveDelivered         Stamp  `json:"five_delivered"`
	FiveDeliveryLineKnown bool   `json:"five_delivery_line_known"`
	Reason                string `json:"reason"`
}

type Definition struct {
	Version                    int      `json:"version"`
	Policies                   []Policy `json:"policies"`
	BirthEligibility           string   `json:"birth_eligibility"`
	InitialArming              string   `json:"initial_arming"`
	LaterArming                string   `json:"later_arming"`
	XCFailure                  string   `json:"XC_failure"`
	XQFailure                  string   `json:"XQ_failure"`
	WarningDefinition          string   `json:"warning_definition"`
	UnknownReset               string   `json:"unknown_reset"`
	P100Priority               string   `json:"P100_priority"`
	LatestOnly                 bool     `json:"latest_only"`
	CompletedLatchIrreversible bool     `json:"completed_latch_irreversible"`
	HoldingOnly                bool     `json:"holding_only"`
	RequiredInputs             []string `json:"required_inputs"`
}

type Snapshot struct {
	Version            int        `json:"version"`
	Entry              Entry      `json:"entry"`
	Definition         Definition `json:"definition"`
	Initialized        bool       `json:"initialized"`
	At                 *Stamp     `json:"at"`
	Sequence           uint64     `json:"sequence"`
	MonitoringEligible bool       `json:"monitoring_eligible"`
	Armed              bool       `json:"armed"`
	Warning            bool       `json:"warning"`
	DisabledByP100     bool       `json:"disabled_by_P100"`
	Latched            bool       `json:"latched"`
	FirstArming        *Witness   `json:"first_arming"`
	LastArming         *Witness   `json:"last_arming"`
	LastChainBreak     *Witness   `json:"last_chain_break"`
	Invalidation       *Witness   `json:"invalidation"`
	ArmingCount        uint64     `json:"arming_count"`
	ChainBreakCount    uint64     `json:"chain_break_count"`
}

type Decision struct {
	Version              int      `json:"version"`
	Policy               Policy   `json:"policy"`
	Stamp                Stamp    `json:"stamp"`
	InitialEvaluation    bool     `json:"initial_evaluation"`
	MonitoringEligible   bool     `json:"monitoring_eligible"`
	RequiredKnown        bool     `json:"required_known"`
	RequiredFresh        bool     `json:"required_fresh"`
	QuoteOK              bool     `json:"quote_ok"`
	Values               Values   `json:"values"`
	ArmingCondition      Truth    `json:"arming_condition"`
	ArmedNow             bool     `json:"armed_now"`
	ChainBrokenNow       bool     `json:"chain_broken_now"`
	Warning              bool     `json:"warning"`
	NewFivePublication   bool     `json:"new_five_publication"`
	PostEntryFive        bool     `json:"post_entry_five"`
	InvalidatedNow       bool     `json:"invalidated_now"`
	ExitEligibleQuantity int      `json:"exit_eligible_quantity"`
	Missing              []string `json:"missing"`
	Stale                []string `json:"stale"`
	Reason               string   `json:"reason"`
	Armed                bool     `json:"armed"`
	Latched              bool     `json:"latched"`
	DisabledByP100       bool     `json:"disabled_by_P100"`
	Sequence             uint64   `json:"sequence"`
}

type State struct {
	view       Snapshot
	seen       map[string]bank.Frame
	deliveries map[string]Stamp
	lastInput  *inputHistory
}

type frameHistory struct {
	HasCurrent bool
	ID         string
	End        float64
}
type inputHistory struct {
	Stamp  Stamp
	Scales [3]frameHistory
}

// DeclaredDefinition はRoot選択済みの純ライフサイクル定義を独立値で返します。
//
// 引数: なし。
// 返り値: Definitionは収益未検証の116条件です。返したsliceは他の呼出と共有しません。
func DeclaredDefinition() Definition {
	return Definition{Version: 116, Policies: []Policy{X0, XC, XQ},
		BirthEligibility:  "出生Common真・D15>0・G30既知非0。prior3境界を固定。入口追加拒否なし",
		InitialArming:     "実fill時fresh5/15/30、signed5Close>0、signedHist5>0、D15>0、正常返済BBO順側",
		LaterArming:       "End>fillの最新5公表がfreshな全正常Rawで初期と同4条件",
		XCFailure:         "新しい取得後5公表のHist<=0かつ同Close内側。BBO異常でも完成ラッチ",
		XQFailure:         "取得後5公表のHist<=0がfreshな間、全正常Rawで返済BBO内側",
		WarningDefinition: "Warningはarmed後のHist警戒だけ。価格回復だけでは消さずHist>0で解除。価格Signed距離と完成Latchは別",
		UnknownReset:      "実使用値Unknown/欠足/古さで未完成armedを切る。BBO異常は待ち。DI/30G既知反転だけでは切らない",
		P100Priority:      "P100先Activeなら新Xなし。既Xラッチ後のP100起動でもラッチ/注文を取消さない",
		LatestOnly:        true, CompletedLatchIrreversible: true, HoldingOnly: true, RequiredInputs: []string{"5Close/Hist", "15+DI/-DI", "30EMA8/EMA21", "当場PriceKnown/fresh"}}
}
