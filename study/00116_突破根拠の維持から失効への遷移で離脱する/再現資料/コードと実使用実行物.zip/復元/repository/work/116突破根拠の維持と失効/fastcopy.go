package entrylife116

import gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate115"

// valueAt は判断一回の数値領域へ値を置き、pointerの個別allocationを減らします。
//
// 引数: values(*[8]float64)、at(int)、value(float64)は今回領域/位置/値です。
// 返り値: *float64は今回判断だけが所有する領域内の値です。
func valueAt(values *[8]float64, at int, value float64) *float64 {
	values[at] = value
	return &values[at]
}

// copyFloat は任意数値pointerを独立所有へ複写します。
//
// 引数: p(*float64)は既知値又はnilです。
// 返り値: *float64は独立値又はnilです。
func copyFloat(p *float64) *float64 {
	if p == nil {
		return nil
	}
	v := *p
	return &v
}

// copyBirth は固定115出生票の可変slice/pointerだけを複写します。
//
// 引数: b(gate.Decision)は出生票です。
// 返り値: gate.Decisionはbank Snapshotの値コピーと独立した可変欄です。
func copyBirth(b gate.Decision) gate.Decision {
	if b.Current != nil {
		v := *b.Current
		b.Current = &v
	}
	v := b.Values
	v.G30 = copyFloat(v.G30)
	v.D15 = copyFloat(v.D15)
	v.ADX15 = copyFloat(v.ADX15)
	v.Boundary = copyFloat(v.Boundary)
	v.FiveClose = copyFloat(v.FiveClose)
	v.CloseBreak = copyFloat(v.CloseBreak)
	v.LastBreak = copyFloat(v.LastBreak)
	v.TR5 = copyFloat(v.TR5)
	v.PreviousATR5 = copyFloat(v.PreviousATR5)
	v.SpikeMargin = copyFloat(v.SpikeMargin)
	v.PreviousD15 = copyFloat(v.PreviousD15)
	v.ADX15Delta = copyFloat(v.ADX15Delta)
	b.Values = v
	b.CommonConditions = copyConditions(b.CommonConditions)
	b.TrendConditions = copyConditions(b.TrendConditions)
	b.ReversalConditions = copyConditions(b.ReversalConditions)
	b.MissingInputs = copyStrings(b.MissingInputs)
	b.CommonDenials = copyStrings(b.CommonDenials)
	b.TrendDenials = copyStrings(b.TrendDenials)
	b.ReversalDenials = copyStrings(b.ReversalDenials)
	return b
}

// copyConditions は条件票の配列と数値pointerを複写します。
//
// 引数: in([]gate.Condition)は票です。
// 返り値: []gate.Conditionはnil/空の別も保つ独立値です。
func copyConditions(in []gate.Condition) []gate.Condition {
	if in == nil {
		return nil
	}
	out := make([]gate.Condition, len(in))
	copy(out, in)
	for i := range out {
		out[i].Value = copyFloat(out[i].Value)
	}
	return out
}

// copyStrings はnil/空の別を保って文字列sliceを複写します。
//
// 引数: in([]string)は文字列列です。
// 返り値: []stringは独立sliceです。
func copyStrings(in []string) []string {
	if in == nil {
		return nil
	}
	out := make([]string, len(in))
	copy(out, in)
	return out
}

// copyEntry は実取得と固定出生の可変欄を複写します。
//
// 引数: e(Entry)は取得情報です。
// 返り値: Entryは出生票と参照共有しない値です。
func copyEntry(e Entry) Entry { e.Birth = copyBirth(e.Birth); return e }

// copyValues は抽出値の任意数値を複写します。
//
// 引数: v(Values)は抽出値です。
// 返り値: Valuesは独立pointerを持つ値です。
func copyValues(v Values) Values {
	v.Boundary = copyFloat(v.Boundary)
	v.FiveClose = copyFloat(v.FiveClose)
	v.SignedClose = copyFloat(v.SignedClose)
	v.SignedHistogram = copyFloat(v.SignedHistogram)
	v.SignedDI15 = copyFloat(v.SignedDI15)
	v.G30 = copyFloat(v.G30)
	v.ReturnBBO = copyFloat(v.ReturnBBO)
	v.SignedReturnBBO = copyFloat(v.SignedReturnBBO)
	return v
}

// copyWitness は値型bank Snapshotと可変数値だけを複写します。
//
// 引数: w(*Witness)は保存点又はnilです。
// 返り値: *Witnessは独立値又はnilです。
func copyWitness(w *Witness) *Witness {
	if w == nil {
		return nil
	}
	out := *w
	out.Values = copyValues(w.Values)
	return &out
}

// copySnapshot は公開状態の可変欄を全て独立複写します。
//
// 引数: s(Snapshot)は公開直前の私有状態です。
// 返り値: Snapshotは呼出側で変更しても元状態へ波及しない値です。
func copySnapshot(s Snapshot) Snapshot {
	s.Entry = copyEntry(s.Entry)
	if s.At != nil {
		v := *s.At
		s.At = &v
	}
	policies := make([]Policy, len(s.Definition.Policies))
	copy(policies, s.Definition.Policies)
	s.Definition.Policies = policies
	s.Definition.RequiredInputs = copyStrings(s.Definition.RequiredInputs)
	s.FirstArming = copyWitness(s.FirstArming)
	s.LastArming = copyWitness(s.LastArming)
	s.LastChainBreak = copyWitness(s.LastChainBreak)
	s.Invalidation = copyWitness(s.Invalidation)
	return s
}
