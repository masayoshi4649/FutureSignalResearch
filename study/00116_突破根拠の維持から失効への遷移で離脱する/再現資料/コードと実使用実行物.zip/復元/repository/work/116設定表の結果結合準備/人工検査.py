"""116の56×9/S28/R36と候補key結合を手製だけで検査する。"""
from copy import deepcopy
from pathlib import Path
import importlib.util
import json
import tempfile
import unittest
import 結合する as M


def inputs() -> tuple[str,dict]:
    """
    機能: 明示した作業用入力表と、市場を読まない手製36候補を得る。
    引数: なし。返り値: tuple[str,dict]は表と人工値。
    """
    before={};source=M.load_ref({'path':str(M.TABLE_PATH),'sha256':M.TABLE_SHA},before,True)
    path=M.ROOT/'work/116損益CSVの出力/人工検査.py';spec=importlib.util.spec_from_file_location('csv116_fixture_for_table',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return source,module.fixture()


class Table116Tests(unittest.TestCase):
    def test_all_rows_and_conditions_unchanged(self):
        """
        機能: 56×9/S28/R36と定義全セル・R01-36本名を保持する。
        引数: self(Table116Tests)。返り値: None。
        """
        source,fake=inputs();rendered,proof=M.render(source,fake,True)
        before,after=M.parse_table(source),M.parse_table(rendered)
        self.assertEqual(before['features'],after['features']);self.assertEqual(proof['設定数'],28);self.assertEqual(proof['結果行数'],36)
        for identity in set(before['settings'])-{'S17','S22','S23'}:self.assertEqual(before['settings'][identity],after['settings'][identity])
        self.assertIn('全Raw発生漏れ/初回性は別監査で未結合',rendered)

    def test_actor_order_is_not_table_order(self):
        """
        機能: Actor位置と異なるR05/R13/R29をkeyで正しく結合する。
        引数: self(Table116Tests)。返り値: None。
        """
        source,fake=inputs();self.assertNotEqual(list(M.KEYS),list(M.TABLE_KEYS))
        fake['場別'].reverse();text,_=M.render(source,fake,True);rows=M.parse_table(text)['results']
        for identity,key in [('R05','A0_XC_C0_D0'),('R13','T_C0_D0'),('R29','TR_XC_C0_D0')]:
            self.assertEqual(rows[identity]['cells'][1],key)
            self.assertIn('純額'+M.amount(fake['集計'][key]['net_yen'],signed=True)+'円',rows[identity]['cells'][3])
        self.assertIn('PF 未定義、勝率未定義',rows['R13']['cells'][3])

    def test_bad_schema_or_key_rejected(self):
        """
        機能: 全36欠落・Life偽装・入口分母・R重複を拒否する。
        引数: self(Table116Tests)。返り値: None。
        """
        source,fake=inputs()
        for kind in ('欠落','Life','分母'):
            bad=deepcopy(fake)
            if kind=='欠落':bad['主key'].pop()
            elif kind=='Life':bad['Actor設定']['A0_XC_C0_D0']['life_mode']='X0'
            else:bad['場別'][0]['入口票検査']['counts']['selected_true']+=1
            with self.assertRaises(ValueError):M.render(source,bad,True)
        with self.assertRaises(ValueError):M.parse_table(source.replace('| R36 |','| R35 |'))

    def test_unfixed_before_reading_results(self):
        """
        機能: 未解禁Root要求を結果・表の参照と出力作成前に拒否する。
        引数: self(Table116Tests)。返り値: None。
        """
        with tempfile.TemporaryDirectory(dir=M.OWN) as folder:
            path=Path(folder)/'未解禁.json';out=Path(folder)/'出力'
            path.write_text(json.dumps({'version':1,'trial':116,'fixed':False,'result_read_authorized':False}),encoding='utf-8')
            with self.assertRaises(ValueError):M.execute({'path':str(path),'sha256':M.sha(path)},out)
            self.assertFalse(out.exists())


if __name__=='__main__':unittest.main(verbosity=2)
