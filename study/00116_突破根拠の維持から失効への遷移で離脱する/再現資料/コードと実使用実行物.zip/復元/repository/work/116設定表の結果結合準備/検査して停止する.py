"""Rootレビュー後に116表結合コードを新規停止する。市場結果は読まない。"""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess
import sys

OWN=Path(__file__).resolve().parent
FILES=('結合する.py','人工検査.py','README.md',Path(__file__).name)


def digest(path: Path) -> str:
    """
    機能: コード/入力表の全bytes指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: Rootレビュー後だけ手製4主を再確認し所有を固定する。
    引数: CLI --reviewed(bool)。返り値: None。自然結果・CSV・金融は実行しない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--reviewed',action='store_true',required=True);parser.parse_args()
    target=OWN/'停止.json'
    if target.exists():raise ValueError('未作成停止だけ')
    before={str((OWN/name).resolve()):digest(OWN/name) for name in FILES}
    root=OWN.parents[1]
    dependencies={str(path.resolve()):digest(path) for path in [root/'work/116損益CSVの出力/人工検査.py',root/'work/115損益CSVの出力_正益経験分母/人工を実行して停止する.py']}
    source={'path':str(OWN/'入力表.md'),'sha256':digest(OWN/'入力表.md')}
    result=subprocess.run([sys.executable,'-X','utf8','人工検査.py'],cwd=OWN,capture_output=True,text=True,encoding='utf-8',timeout=60)
    if result.returncode or before!={p:digest(Path(p)) for p in before}:raise ValueError(result.stdout+result.stderr)
    data={'試行':116,'成功':True,'停止':True,'市場前':True,'所有ファイルSHA256':before,'再用コードSHA256':dependencies,'入力表':source,'前後不変':True,'人工4主':True,'人工ログ':result.stdout+result.stderr,'自然Raw/Native/CSV本文読取':False}
    with target.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'path':str(target),'sha256':digest(target)},ensure_ascii=False))


if __name__=='__main__':main()
