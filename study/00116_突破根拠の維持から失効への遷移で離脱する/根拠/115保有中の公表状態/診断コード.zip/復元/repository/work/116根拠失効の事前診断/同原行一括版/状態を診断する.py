"""115の実保有中の公表状態を記述し、新しい売買や仮損益は作らない。"""
from collections import Counter,defaultdict
from decimal import Decimal
from datetime import datetime,timezone,timedelta
from pathlib import Path
import gzip
import hashlib
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
FINISH=ROOT/"study/00115_三時間軸の方向性と局所構造で入口を分ける/検査/完了記録.json"
FINISH_SHA="c4dd66725a4c4c48c593aa7aed287ab5a21f0ad3f9f3c196c4a839ffbf65cd8a"
RESULT=ROOT/"work/115同入口と三時間軸の実現差/全70の実現差/結果.json"
RESULT_SHA="c9ea16a9ee6f5fddeabdd9ddda3128346225976bac0a38ade20ee2220c167292"
F1="94bb656a1607d59039a0c5ec0f06968a4da72463d27c0847606a09fc52fc4693"
KEYS=("TR_C0_D0","TR_C0_D1","TR_C5_D0","TR_C5_D1")
CONDITIONS={"境界のstrict内戻り":(300,"boundary",False),"境界の突破維持喪失":(300,"boundary",True),"15DIの逆側または0":(900,"di",True),"5Histの方向調整増分負":(300,"hist_delta",False),"5Histの方向調整水準負":(300,"hist",False),"30Gの逆側または0":(1800,"gap",True),"30Gのstrict逆側":(1800,"gap",False),"30Gの取得時符号からの反転":(1800,"gap_flip",False)}
DEFINITION={"主集合":"115TR_C0_D0の成立34Source出生。T28は内数。","追加費用":"他3費用は実取得Quote/価格/初期量または費用外実返済執行が主条件と異なるものだけ別記。","保有区間":"実取得Index<公表配送Index<=最終返済Index。取得原行の公表はfill前なので初期へ、返済原行の公表はfill前なので区間内へ。","基準":"取得判断で凍結した5m prior3境界。取得時の最新配送asofを別に初期状態として持つ。","遅延公表":"Frame.End<=実取得時刻の取得後配送と、End>実取得時刻を分離。","未知":"非価格足/数値Known不足/古い公表/欠足を未知とし、未知をまたぐ新遷移は証明しない。","W":"marks/保護audit等の実保存点の前後だけ。任意公表時のCloseからWを補完しない。","用途":"最終win/lossは記述分類。新しい出口の効果/仮想収支/機会損失の計算ではない。"}
INPUTS={}


def serial(value):
    """
    機能: 十進数をJSONの数値として保存する。
    引数: value(object)。返り値: int|float。未対応型は拒否する。
    """
    if isinstance(value,Decimal):return int(value) if value==value.to_integral_value() else float(value)
    raise TypeError(str(type(value)))


def read(path: Path,sha: str) -> dict:
    """
    機能: 解禁済み115の明示RefだけをSHA認証して読む。
    引数: path(Path)、sha(str)。返り値: dictは十進数で解釈した保存値。
    """
    b=path.read_bytes();assert path.is_absolute() and hashlib.sha256(b).hexdigest()==sha
    INPUTS[str(path.resolve())]=sha
    return json.loads(gzip.decompress(b) if path.suffix==".gz" else b,parse_float=Decimal)


def stamp(quote: dict) -> dict:
    """
    機能: 公表または実約定の価格時計と物理順を小さく保持する。
    引数: quote(dict)。返り値: dictはtime/index/source_lineと日本時間。
    """
    return {k:quote[k] for k in ("time","index","source_line")}|{"日本時間":datetime.fromtimestamp(float(quote["time"]),timezone(timedelta(hours=9))).isoformat()}


def value(item: dict) -> Decimal|None:
    """
    機能: Knownが立つ保存数値だけを読む。
    引数: item(dict)。返り値: Decimal|None。未知を0にしない。
    """
    return Decimal(item["value"]) if item["known"] else None


def key(position: dict,book: dict) -> tuple:
    """
    機能: Sourceを場/商品/手法/方向/出生で識別する。
    引数: position/book(dict)。返り値: tuple。単なるsignal_id結合を避ける。
    """
    s=position["source"];r=next(r["request"] for r in book["entry_gate"]["records"] if r["actual_position_id"]==position["id"])
    assert r["method"]==s["method"] and r["signal_id"]==s["signal_id"] and r["side"]==position["side"]
    return book["session"]["id"],r["product"],r["method"],position["side"],s["signal_id"]


def holding_signature(book: dict,p: dict) -> dict:
    """
    機能: 費用値を混ぜず実取得と全返済要求/約定を比較する。
    引数: book/p(dict)。返り値: dictは実行済みの寿命署名。
    """
    fills=[f for f in book["fills"] if f["position_id"]==p["id"] and f["action"]=="close"]
    orders={o["id"]:o for o in book["orders"]}
    return {"source":p["source"],"entry":p["entry_quote"],"price":p["entry_price"],"q0":p["initial_quantity"],"exits":[{"fill":{k:f[k] for k in ("quote","price","quantity","reason")},"order":{k:orders[f["order_id"]][k] for k in ("request_time","request_quote","quantity","reason","status","cancel_time","cancel_reason")}} for f in fills]}


def prepare_publications(actual: dict) -> list[dict]:
    """
    機能: 保存公表列の場/限月/実原行/未来不在/同ID不変を検査する。
    引数: actual(dict)。返り値: list[dict]はdistinct公表と直前同幅参照。
    """
    seen={};last={};events=[];previous_index=-1;scope=actual["scope"]
    for ordinal,pub in enumerate(actual["entry_publications"]):
        s=pub["stamp"];f=pub["frame"]["frame"];width=f["width_seconds"]
        assert s["index"]>=previous_index and s["source_line"]>0 and f["record_ordinal"]==s["index"]+1
        assert f["session_id"]==scope["session"]["id"] and f["contract"]==scope["contract"] and f["available_at"]<=s["time"] and f["end"]<=f["available_at"] and width in (300,900,1800)
        previous_index=s["index"]
        if f["id"] in seen:assert seen[f["id"]]==pub;continue
        seen[f["id"]]=pub;prior=last.get(width);events.append({"pub":pub,"ordinal":ordinal,"previous":None if prior is None else prior["pub"],"gap":prior is not None and f["end"]-prior["pub"]["frame"]["frame"]["end"]!=width});last[width]=events[-1]
    return events


def values(pub: dict|None,side: int,boundary: Decimal,at,previous: dict|None=None,initial_gap: Decimal|None=None) -> dict:
    """
    機能: 公表された同一幅の価格構造/方向/勢いを符号調整し、欠測を保持する。
    引数: pub/previous(dict|None)、side(int)、boundary/initial_gap(Decimal|None)、at(数値)。
    返り値: dict。Hist増分は既知で連続する5m公表だけを用いる。
    """
    out={k:None for k in ("boundary","di","adx","hist","hist_delta","gap","gap_flip","tr","previous_atr","spike_margin")}
    if pub is None:return out
    outer=pub["frame"];f=outer["frame"];width=f["width_seconds"];fresh=0<=at-f["available_at"]<width
    if not fresh or not f["price_known"]:return out
    t=f["technical"]
    if width==300:
        out["boundary"]=side*(Decimal(f["ohlc"]["close"])-boundary);hist=value(t["histogram"]);out["hist"]=None if hist is None else side*hist
        out["tr"]=value(t["tr"]);out["previous_atr"]=value(t["previous_atr"])
        if out["tr"] is not None and out["previous_atr"] is not None:out["spike_margin"]=2*out["previous_atr"]-out["tr"]
        if previous is not None:
            pf=previous["frame"]["frame"];ph=value(pf["technical"]["histogram"])
            if pf["price_known"] and f["end"]-pf["end"]==300 and hist is not None and ph is not None:
                stored=value(t["previous_histogram"]);assert stored is not None and abs(stored-ph)<=Decimal("1e-10")
                out["hist_delta"]=side*(hist-ph)
    elif width==900:
        plus=value(outer["dmi"]["plus_di"]);minus=value(outer["dmi"]["minus_di"])
        out["di"]=None if plus is None or minus is None else side*(plus-minus);out["adx"]=value(outer["dmi"]["adx"])
    else:
        gap=value(t["gap"]);out["gap"]=None if gap is None else side*gap
        if initial_gap is not None and initial_gap!=0 and out["gap"] is not None:out["gap_flip"]=out["gap"]*(1 if initial_gap>0 else -1)
    return out


def test_state(number: Decimal|None,nonpositive: bool) -> bool|None:
    """
    機能: strict逆側と0を含む否定を区別する。
    引数: number(Decimal|None)、nonpositive(bool)。返り値: bool|Noneは未知三値。
    """
    return None if number is None else number<=0 if nonpositive else number<0


def w_points(position: dict) -> list[dict]:
    """
    機能: 既保存marks/保護点からのみ全玉Wと位相/数量/Rを集める。
    引数: position(dict)。返り値: list[dict]。任意時点の価格やWは再形成しない。
    """
    points=[]
    for name,p in position["marks"].items():
        if p is not None:points.append({"出典":"marks."+name,"stamp":stamp(p["quote"]),"phase":p["phase"],"n":p["quantity"],"reserved":p["reserved"],"R":p["realized_net"],"W":p["whole_net"]})
    for name,p in position["protection113"].items():
        if isinstance(p,dict) and "snapshot" in p and p["decision"]["whole_net_yen"] is not None:
            s=p["snapshot"];points.append({"出典":"protection113."+name,"stamp":stamp(p["quote"]),"phase":p["phase"],"n":s["remaining"],"reserved":s["reserved"],"R":s["closed_net_yen"],"W":p["decision"]["whole_net_yen"]})
    return sorted(points,key=lambda p:(p["stamp"]["index"],0 if p["phase"]=="pre_fill" else 1,p["出典"]))


def w_context(index: int,points: list[dict]) -> dict:
    """
    機能: 公表前後の実保存Wだけを返し、間の値を補完しない。
    引数: index(int)、points(list[dict])。返り値: dictは直前/同原行以後の最初の保存点。
    """
    before=[p for p in points if p["stamp"]["index"]<index];after=[p for p in points if p["stamp"]["index"]>=index]
    return {"前の最後の保存点":None if not before else before[-1],"同原行または後の最初の保存点":None if not after else after[0],"公表当時のWを補完":False}


def relation(index: int,point: dict|None) -> str:
    """
    機能: 公表と既保存W milestoneの原行順を区別する。
    引数: index(int)、point(dict|None)。返り値: str。時刻同秒だけでは同一扱いしない。
    """
    if point is None:return "未保存/未発生"
    pi=point["quote"]["index"]
    return "同原行で公表が先" if index==pi else "公表が前" if index<pi else "公表が後"


def held_events(events: list[dict],entry: dict,exit: dict) -> list[dict]:
    """
    機能: 同秒でも実取得前の公表を除き、最終返済原行の先行公表を含める。
    引数: events(list[dict])、entry/exit(dict)。返り値: list[dict]は実保有原行区間。
    """
    return [e for e in events if entry["index"]<e["pub"]["stamp"]["index"]<=exit["index"]]


def asof_events(events: list[dict],index: int) -> dict:
    """
    機能: Actor実評価前に揃う同原行全公表を含め、各幅の最新既公表を求める。
    引数: events(list[dict])、index(int)。返り値: dictは幅別最新公表。後原行は含めない。
    """
    result={}
    for event in events:
        if event["pub"]["stamp"]["index"]>index:break
        result[event["pub"]["frame"]["frame"]["width_seconds"]]=event
    return result


def track(initial: Decimal|None,items: list[dict],field: str,nonpositive: bool) -> dict:
    """
    機能: 初期から成立/未知、新しい連続状態遷移、未発生を混同せず記述する。
    引数: initial(Decimal|None)、items(list[dict])、field(str)、nonpositive(bool)。
    返り値: dictは最初の実公表・未知/0計数・因果限定を持つ。
    """
    start=test_state(initial,nonpositive);prior=start;first=None;transition=None;eligible=None;unknown=zero=0
    for item in items:
        number=item["values"][field];state=test_state(number,nonpositive)
        if item["gap"]:prior=None
        if number is None:unknown+=1
        elif number==0:zero+=1
        if state is True:
            if first is None:first=item
            if item["足Endが実取得後"] and eligible is None:eligible=item
            if prior is False and transition is None:transition=item
        prior=state
    status="初期から該当" if start is True else "初期不明" if start is None else "取得後に初回該当" if first is not None else "該当公表なし"
    if not items:status+="/保有中に当該幅の新公表なし"
    return {"初期値":initial,"初期票":start,"分類":status,"新公表数":len(items),"未知公表数":unknown,"0公表数":zero,"初回該当公表":first,"既知非該当から該当への初遷移":transition,"Endも取得後である初回該当公表":eligible}


def diagnose(native: dict,book: dict,p: dict,events: list[dict]) -> dict:
    """
    機能: 一つの成立実玉だけに、取得票と実保有中の三時間軸公表を因果結合する。
    引数: native/book/p(dict)、events(list[dict])。返り値: dictは記述台帳。
    """
    record=next(r for r in book["entry_gate"]["records"] if r["actual_position_id"]==p["id"])
    d=record["decision"];request=record["request"];side=p["side"];boundary=Decimal(d["values"]["boundary"]);entry=p["entry_quote"];exit=p["closed_quote"]
    assert record["actual_quantity"]==p["initial_quantity"] and d["frozen"] and d["combined"]==2
    initial={};initial_pub={};history={};last={};inflight=[];points=w_points(p);series={w:[] for w in (300,900,1800)};g0=None
    for event in events:
        pub=event["pub"];s=pub["stamp"];f=pub["frame"]["frame"];width=f["width_seconds"]
        if s["index"]<=entry["index"]:
            last[width]=event
            if request["at"]["index"]<s["index"]<=entry["index"]:inflight.append({"stamp":stamp(s),"width":width,"frame_id":f["id"]})
    for width in (300,900,1800):
        current=last.get(width);initial_pub[width]=None if current is None else {"stamp":stamp(current["pub"]["stamp"]),"frame_id":current["pub"]["frame"]["frame"]["id"],"end":current["pub"]["frame"]["frame"]["end"]}
        initial[width]=values(None if current is None else current["pub"],side,boundary,entry["time"],None if current is None else current["previous"])
    g0=initial[1800]["gap"];initial[1800]["gap_flip"]=None if g0 is None or g0==0 else abs(g0)
    for event in held_events(events,entry,exit):
        pub=event["pub"];s=pub["stamp"];f=pub["frame"]["frame"];width=f["width_seconds"]
        last[width]=event
        state=values(pub,side,boundary,s["time"],event["previous"],g0)
        batch=asof_events(events,s["index"])
        context={str(w):values(None if batch.get(w) is None else batch[w]["pub"],side,boundary,s["time"],None if batch.get(w) is None else batch[w]["previous"],g0) for w in (300,900,1800)}
        item={"stamp":stamp(s),"frame_id":f["id"],"width":width,"end":f["end"],"available_at":f["available_at"],"配送遅れ秒":s["time"]-f["available_at"],"取得後秒":s["time"]-entry["time"],"足Endが実取得後":f["end"]>entry["time"],"gap":event["gap"],"values":state,"当時公表状態":context,"W保存点の前後":w_context(s["index"],points),"W最大との順序":relation(s["index"],p["marks"]["whole_max"]),"初正益との順序":relation(s["index"],p["marks"]["first_whole_positive"]),"正益後初負との順序":relation(s["index"],p["marks"]["first_whole_negative_after"]),"利益保護起動との順序":relation(s["index"],p["activation"])}
        series[width].append(item)
    tracks={name:track(initial[width][field],series[width],field,nonpositive) for name,(width,field,nonpositive) in CONDITIONS.items()}
    request_frames=[]
    for scale in d["current"]["snapshot"]["scales"]:
        assert scale["has_current"]
        f=scale["current"]["frame"];request_frames.append({"width":scale["width_seconds"],"frame_id":f["id"],"end":f["end"],"available_at":f["available_at"],"配送時刻":f["delivery_at"],"要求時点での公表後秒":request["at"]["time"]-f["available_at"],"要求時点での配送後秒":request["at"]["time"]-f["delivery_at"]})
    fills=[f for f in book["fills"] if f["position_id"]==p["id"] and f["action"]=="close"]
    win="利益" if p["realized_net"]>0 else "損失" if p["realized_net"]<0 else "同額"
    return {"出生":key(p,book),"key":book["key"],"建玉ID":p["id"],"Tにも成立":any(x["source"]["signal_id"]==p["source"]["signal_id"] for x in native["actual"]["books"][book["key"].replace("TR_","T_")]["positions"]),"要求時刻":stamp(request["at"]),"要求時値":d["values"],"要求時公表":request_frames,"取得":stamp(entry),"取得価格":p["entry_price"],"初期枚数":p["initial_quantity"],"最終返済":stamp(exit),"実返済":[{"stamp":stamp(f["quote"]),"価格":f["price"],"枚":f["quantity"],"理由":f["reason"]} for f in fills],"実純額":p["realized_net"],"勝敗記述":win,"固定境界":boundary,"要求から実取得までの新公表":inflight,"実取得時asof":{str(w):{"公表":initial_pub[w],"values":initial[w]} for w in (300,900,1800)},"状態の記述":tracks,"保有中新公表":{str(w):series[w] for w in series},"Wmilestone":{name:point for name,point in p["marks"].items() if name in ("first_whole_positive","whole_max","first_whole_negative_after","whole_min")},"起動":p["activation"],"W保存点":points}


def aggregate(rows: list[dict]) -> dict:
    """
    機能: 主34実玉を最終win/lossと初期/発生状態で記述集計する。
    引数: rows(list[dict])。返り値: dict。新出口の成績には変換しない。
    """
    result={}
    for win in ("全体","利益","損失","同額"):
        selected=rows if win=="全体" else [r for r in rows if r["勝敗記述"]==win]
        out={"玉":len(selected),"実純額":sum((r["実純額"] for r in selected),Decimal(0)),"T玉":sum(r["Tにも成立"] for r in selected),"R玉":sum(not r["Tにも成立"] for r in selected),"状態":{}}
        for name in CONDITIONS:
            t=[r["状態の記述"][name] for r in selected]
            out["状態"][name]={"初期該当":sum(x["初期票"] is True for x in t),"初期不明":sum(x["初期票"] is None for x in t),"初期非該当":sum(x["初期票"] is False for x in t),"初期非該当から保有中に該当":sum(x["初期票"] is False and x["初回該当公表"] is not None for x in t),"既知の非該当→該当を確認":sum(x["既知非該当から該当への初遷移"] is not None for x in t),"保有中新公表なし":sum(x["新公表数"]==0 for x in t),"保有中の未知公表あり":sum(x["未知公表数"]>0 for x in t),"取得後公表で該当あり":sum(x["初回該当公表"] is not None for x in t),"Endも取得後の該当あり":sum(x["Endも取得後である初回該当公表"] is not None for x in t)}
        result[win]=out
    return result


def save(path: Path,value: dict,compressed: bool=False) -> dict:
    """
    機能: 新ownedへ小JSONまたは決定的gzip台帳を新規保存する。
    引数: path(Path)、value(dict)、compressed(bool)。返り値: dictはFileRef。
    """
    body=(json.dumps(value,ensure_ascii=False,indent=None if compressed else 2,default=serial,allow_nan=False)+"\n").encode("utf-8")
    with path.open("xb") as f:
        if compressed:
            with gzip.GzipFile(fileobj=f,mode="wb",filename="",mtime=0) as z:z.write(body)
        else:f.write(body)
    return {"path":str(path.resolve()),"sha256":hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 115完了・同F1成功要求を認証し、許可されたNativeだけで記述診断する。
    引数: なし。返り値: None。金融ロジック変更、Raw/新価格CSV/11月09読取は0。
    """
    for name in ("状態を診断する.py","人工検査.py"):
        path=HERE/name;INPUTS[str(path.resolve())]=hashlib.sha256(path.read_bytes()).hexdigest()
    runtime=ROOT/"work/115三時間軸の複合入口の連続比較/runtime.go";INPUTS[str(runtime.resolve())]=hashlib.sha256(runtime.read_bytes()).hexdigest()
    finish=read(FINISH,FINISH_SHA);assert finish["成功"] and finish["試行作業完了"] and finish["試行"]==115
    result=read(RESULT,RESULT_SHA);q=read(Path(result["Root要求"]["path"]),result["Root要求"]["sha256"])
    assert q["fixed"] and q["market_native_read_authorized"] and q["stage"]=="full70" and q["condition"]["sha256"]==F1
    done=read(Path(q["completion"]["path"]),q["completion"]["sha256"]);assert done["success"] and done["trial"]==115 and done["condition_sha256"]==F1 and done["books"]==840 and done["sessions"]==70 and done["unchanged"]
    ledger=read(Path(result["対応台帳"]["path"]),result["対応台帳"]["sha256"])["対応"]
    expected={k:{tuple(r["base"]) for r in ledger if r["対照"]=="115A0→115TR_"+k.removeprefix("TR_") and r["後ID"] is not None} for k in KEYS}
    assert all(len(s)==34 for s in expected.values());sessions={x[0] for s in expected.values() for x in s};cohorts={k:{} for k in KEYS};natives=0
    for final in done["results"]:
        if final["session"] not in sessions:continue
        native=read(Path(final["native"]["path"]),final["native"]["sha256"]);assert native["trial"]==115 and native["actual"]["complete"]
        natives+=1;events=prepare_publications(native["actual"])
        for k in KEYS:
            book=native["actual"]["books"][k]
            for p in book["positions"]:
                identity=key(p,book);assert identity in expected[k] and identity not in cohorts[k]
                # ----------------------------------------
                # 実取得/返済が同じ追加費用の台帳を重複生成しない。
                signature=holding_signature(book,p);main_entry=cohorts["TR_C0_D0"].get(identity)
                if k!="TR_C0_D0" and main_entry is not None and signature==main_entry["signature"]:
                    cohorts[k][identity]={"signature":signature,"同寿命で主条件参照":True,"主建玉ID":main_entry["診断"]["建玉ID"],"実純額":p["realized_net"]};continue
                cohorts[k][identity]={"signature":signature,"診断":diagnose(native,book,p,events)}
    assert all(set(cohorts[k])==expected[k] for k in KEYS)
    main_rows=[v["診断"] for v in cohorts["TR_C0_D0"].values()];assert len(main_rows)==34 and sum(r["Tにも成立"] for r in main_rows)==28
    extra={k:[v["診断"] for v in cohorts[k].values() if "診断" in v] for k in KEYS[1:]}
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==s for p,s in INPUTS.items())
    full=save(HERE/"保有中の公表状態台帳.json.gz",{"主34玉":main_rows,"他費用の実寿命差だけ":extra,"同実寿命で主条件参照数":{k:sum("同寿命で主条件参照" in v for v in cohorts[k].values()) for k in KEYS[1:]}},True)
    examples=[r for r in main_rows if r["出生"][0] in ("2026-11-06_Day","2026-10-15_Day")]
    output={"成功":True,"研究元試行":115,"記述診断のみ":True,"新金融試行採番":False,"確認日":"2026-11-10","定義":DEFINITION,"完了記録":{"path":str(FINISH),"sha256":FINISH_SHA},"同F1":F1,"主34玉集計":aggregate(main_rows),"費用別の寿命差分母":{k:{"全実出生":len(cohorts[k]),"実寿命差を追加記述":len(extra[k]),"主条件同寿命参照":len(cohorts[k])-len(extra[k])} for k in KEYS[1:]},"11月06と10月15の主条件例":[{"出生":r["出生"],"建玉ID":r["建玉ID"],"取得":r["取得"],"最終返済":r["最終返済"],"実純額":r["実純額"],"状態の記述":r["状態の記述"]} for r in examples],"台帳":full,"Native読取場数":natives,"入力SHA256":INPUTS,"前後不変":True,"Raw/新価格CSV/11月09/金融実行/閾値最適化/仮想利益/固定編集":0}
    print(json.dumps(save(HERE/"記述診断の結果.json",output),ensure_ascii=False))


if __name__=="__main__":main()
