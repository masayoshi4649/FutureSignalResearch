"""記述診断の符号/既知性/時間境界を市場値なしの器具で固定する。"""
from copy import deepcopy
from decimal import Decimal as D
import unittest
import 状態を診断する as S


def frame(width: int=300,end: int=600,index: int=20,close: int=101,hist: int=2) -> dict:
    """
    機能: 各幅の確定足を既知/未知変更できる人工公表として作る。
    引数: width/end/index/close/hist(int)。返り値: dictは市場ではないpub。
    """
    known=lambda x:{"known":True,"value":x}
    return {"stamp":{"time":end+60,"index":index,"source_line":index+1},"frame":{"frame":{"id":f"人工{width}/{end}","session_id":"人工","contract":"人工限月","width_seconds":width,"end":end,"available_at":end+60,"record_ordinal":index+1,"price_known":True,"ohlc":{"close":close},"technical":{"histogram":known(hist),"previous_histogram":known(1),"gap":known(4),"tr":known(8),"previous_atr":known(5)}},"dmi":{"plus_di":known(7),"minus_di":known(3),"adx":known(21)}}}


def item(value,idx: int=1,gap: bool=False,end_after: bool=True) -> dict:
    """
    機能: 初期/未知/連続性を区別する人工状態を作る。
    引数: value(数値|None)、idx(int)、gap/end_after(bool)。返り値: dictは小器具。
    """
    return {"values":{"x":value},"gap":gap,"足Endが実取得後":end_after,"index":idx}


class Tests(unittest.TestCase):
    """純記述の8主人工。"""

    def test_zero_and_unknown(self):
        """
        機能: 0/strict内戻り/未知を同一にしない。
        引数: self(Tests)。返り値: None。
        """
        self.assertIsNone(S.test_state(None,True));self.assertFalse(S.test_state(D(0),False));self.assertTrue(S.test_state(D(0),True));self.assertTrue(S.test_state(D(-1),False))

    def test_mirror_and_hist_continuity(self):
        """
        機能: 売買鏡像の境界/Hist符号と連続足の実増分を照合する。
        引数: self(Tests)。返り値: None。
        """
        previous=frame(end=300,hist=1);current=frame(close=99,hist=2);a=S.values(current,1,D(100),660,previous)
        sell=frame(close=101,hist=-2);sell['frame']['frame']['technical']['previous_histogram']['value']=-1;sp=frame(end=300,hist=-1);b=S.values(sell,-1,D(100),660,sp)
        self.assertEqual((a['boundary'],a['hist'],a['hist_delta']),(b['boundary'],b['hist'],b['hist_delta']));self.assertEqual(a['spike_margin'],2)
        previous['frame']['frame']['end']=0;self.assertIsNone(S.values(current,1,D(100),660,previous)['hist_delta'])

    def test_stale_or_missing_not_zero(self):
        """
        機能: 古い公表/非価格足/数値不足を値0へ補わない。
        引数: self(Tests)。返り値: None。
        """
        p=frame();self.assertIsNone(S.values(p,1,D(100),960)['boundary']);p['frame']['frame']['price_known']=False;self.assertIsNone(S.values(p,1,D(100),660)['hist']);p['frame']['frame']['price_known']=True;p['frame']['frame']['technical']['histogram']['known']=False;self.assertIsNone(S.values(p,1,D(100),660)['hist'])

    def test_initial_already_adverse_and_unknown(self):
        """
        機能: 取得時から逆の状態を取得後の初失効にしない。
        引数: self(Tests)。返り値: None。
        """
        t=S.track(D(-1),[item(D(-2))],'x',False);self.assertEqual(t['分類'],'初期から該当');self.assertIsNone(t['既知非該当から該当への初遷移']);self.assertIsNotNone(t['初回該当公表'])
        t=S.track(None,[item(D(-2))],'x',False);self.assertEqual(t['分類'],'初期不明');self.assertIsNone(t['既知非該当から該当への初遷移'])

    def test_unknown_gap_and_nominal_end(self):
        """
        機能: 欠測跨ぎの新遷移を捏造せず、遅延公表と取得後Endを区別する。
        引数: self(Tests)。返り値: None。
        """
        t=S.track(D(1),[item(None),item(D(-1),2)],'x',False);self.assertIsNone(t['既知非該当から該当への初遷移']);t=S.track(D(1),[item(D(-1),gap=True)],'x',False);self.assertIsNone(t['既知非該当から該当への初遷移'])
        t=S.track(D(1),[item(D(-1),end_after=False),item(D(-2),2)],'x',False);self.assertEqual(t['初回該当公表']['index'],1);self.assertEqual(t['Endも取得後である初回該当公表']['index'],2)

    def test_same_second_physical_boundaries(self):
        """
        機能: 同秒の実取得前/後・最終返済前公表をIndexで判別する。
        引数: self(Tests)。返り値: None。
        """
        events=[{'pub':frame(index=i)} for i in (9,10,11,12,13)];self.assertEqual([e['pub']['stamp']['index'] for e in S.held_events(events,{'index':10},{'index':12})],[11,12]);self.assertFalse(S.held_events(events,{'index':10},{'index':10}))

    def test_publication_causality_and_duplicate(self):
        """
        機能: 同IDの再公表不変、未来値と場違いを拒否する。
        引数: self(Tests)。返り値: None。
        """
        p=frame();actual={'scope':{'session':{'id':'人工'},'contract':'人工限月'},'entry_publications':[p,deepcopy(p)]};self.assertEqual(len(S.prepare_publications(actual)),1)
        for kind in ('future','scope','mutate'):
            a=deepcopy(actual)
            if kind=='future':a['entry_publications'][0]['frame']['frame']['available_at']+=1
            elif kind=='scope':a['entry_publications'][0]['frame']['frame']['session_id']='別場'
            else:a['entry_publications'][1]['frame']['frame']['ohlc']['close']+=1
            with self.subTest(kind=kind),self.assertRaises(AssertionError):S.prepare_publications(a)

    def test_w_saved_brackets_and_r_background(self):
        """
        機能: Wの保存点前後だけを返し、Rの初期逆背景の符号反転を別に扱う。
        引数: self(Tests)。返り値: None。
        """
        points=[{'stamp':{'index':1},'W':D(10)},{'stamp':{'index':5},'W':D(-2)}];c=S.w_context(3,points);self.assertEqual(c['前の最後の保存点']['W'],10);self.assertEqual(c['同原行または後の最初の保存点']['W'],-2);self.assertFalse(c['公表当時のWを補完'])
        p=frame(width=1800);r=S.values(p,-1,D(100),660,initial_gap=D(-4));self.assertEqual(r['gap'],-4);self.assertEqual(r['gap_flip'],4);p['frame']['frame']['technical']['gap']['value']=-2;r=S.values(p,-1,D(100),660,initial_gap=D(-4));self.assertEqual(r['gap_flip'],-2)


if __name__=='__main__':unittest.main(verbosity=2)
