"""196の履歴中央値・方向対称・費用可否分離を金融前に検査する。"""
from copy import deepcopy
import sys,json
import 入口196 as E
import 人工検査 as T
from 人工確認186 import mirror_m
from 人工確認192 import mirror_extra


def main():
    """
    機能: 実特徴の鏡像と足ID/当該足除外/前情報だけの中央値を確認する。
    引数: なし。
    返り値: None。
    """
    checks=0
    rows=E.P.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116/純特徴184直接.json.gz')
    template=deepcopy(rows[1000]);scene=template['session'];start=E.M.bounds(scene)[0]
    synthetic=[]
    for i in range(15):
        row=deepcopy(template);row.update(time=start+(i+1)*300,line=i+1)
        row['m5'].update(count=i,end=row['time'],published=row['time'],atr=float(i+1))
        synthetic.append(row)
    context=E.context_rows(synthetic)
    key=(scene,synthetic[12]['time'],synthetic[12]['line'])
    assert context[key]['past_atr_median']==6.5 and context[key]['past_atr_count']==12 and context[key]['past_atr_span']==3600;checks+=3
    changed=deepcopy(synthetic);changed[12]['m5']['atr']=10000
    assert E.context_rows(changed)[key]['past_atr_median']==6.5;checks+=1
    prefix=E.context_rows(synthetic[:13]);assert prefix[key]==context[key];checks+=1
    duplicated=[]
    for row in synthetic:
        duplicated.append(row);again=deepcopy(row);again['time']+=30;again['line']+=100;duplicated.append(again)
    assert E.context_rows(duplicated)[key]['past_atr_median']==6.5;checks+=1
    gap=deepcopy(synthetic);gap[5]['m5']['end']-=60
    assert E.context_rows(gap)[key]['past_atr_median'] is None;checks+=1
    baseline=E.P.read(E.ROOT/'inputs/00192_TOPIXの構造と数量の純入口/純入口.json.gz')
    extra={(r['session'],r['time'],r['line']):r['extra'] for r in baseline}
    for name in ('純特徴183.json.gz','純特徴184直接.json.gz'):
        source=E.P.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116'/name);contexts=E.context_rows(source)
        for i,row in enumerate(source):
            if i%17:continue
            key=(row['session'],row['time'],row['line']);ctx=contexts[key];ex=extra[key]
            mirrored=dict(ctx,history=[mirror_m(m) for m in ctx['history']],previous=T.mirror(ctx['previous']) if ctx['previous'] else None)
            for policy in range(6):
                original=E.night_direction(row,ctx,ex,policy)[0]
                mirror=E.night_direction(T.mirror(row),mirrored,mirror_extra(ex),policy)[0]
                assert original==-mirror;checks+=1
            for strict,small in ((False,False),(True,False),(True,True)):
                assert E.native(row,ctx,ex,strict,small)==-E.native(T.mirror(row),mirrored,mirror_extra(ex),strict,small);checks+=1
    proof={'成功':True,'項目数':checks,'同一足重複防止':True,'当該足を中央値から除外':True,'prefix同体':True,'鏡像':True,
        '履歴不足は別状態':True,'SourceSHA':E.M.sha(E.HERE/'入口196.py')}
    E.M.save(E.HERE/'人工確認.json',proof);print(json.dumps(proof,ensure_ascii=False),flush=True)


if __name__=='__main__':main()
