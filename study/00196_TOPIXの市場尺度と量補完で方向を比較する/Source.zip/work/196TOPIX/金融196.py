"""196の固定52入口を、同じ単純IFDと単一保有枠で再生する。"""
from pathlib import Path
from copy import deepcopy
import json
import 入口196 as E
M=E.M
import 金融を比較する as F
A=F.A


def main():
    """
    機能: 固定81場を全52候補で再生し、期間と三帯を分けて集計する。
    引数: なし。
    返り値: None。金融前の条件/純出生/Sourceを上書きしない。
    """
    cfg=E.read(E.HERE/'条件.json')
    assert all(M.sha(E.ROOT/p)==sha for p,sha in cfg['Source'].items())
    assert cfg['純入口SHA']==M.sha(E.HERE/'純入口.json.gz')
    proof=E.read(E.HERE/'人工確認.json');assert proof['成功'] and proof['SourceSHA']==M.sha(E.HERE/'入口196.py')
    marker=E.HERE/'金融開始前固定.json';assert not marker.exists()
    M.save(marker,{'条件SHA':M.sha(E.HERE/'条件.json'),'金融Source':M.sha(Path(__file__)),'人工':proof,
        '安定性Source':M.sha(E.ROOT/'work/183損失安定性/安定性183.py'),'金融部Source':M.sha(Path(F.__file__))})
    entries=deepcopy(E.read(M.HERE/'入力台帳.json')['entries'])
    mapping={r['session']:r for r in E.read(E.ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json')['entries']}
    for entry in entries:entry['cache_absolute']=str(E.ROOT/mapping[entry['session']]['path'])
    assert len(entries)==81;meta=F.sessions(entries);by={e['session']:[] for e in entries}
    for row in E.read(E.HERE/'純入口.json.gz'):by[row['session']].append(row)
    packs=[]
    for name in E.NAMES:
        pack=F.empty('TOPIX196_'+name+'_DayA25_NightW15_H60',meta);pack['ledger']['origin']=[];packs.append(pack)
    for entry in entries:
        route=M.Route(entry);cache={}
        for ci,pack in enumerate(packs):
            busy=-float('inf');pending=False;count={'純成立':0,'保有棄却':0,'予約棄却':0,'取得':0,'失効':0}
            for row in by[entry['session']]:
                side=row['signals'][ci]
                if not side:continue
                count['純成立']+=1
                if row['time']<=busy:count['予約棄却' if pending else '保有棄却']+=1;continue
                width=row['widths'][ci];assert width is not None
                key=(row['time'],row['line'],side,width)
                if key not in cache:cache[key]=route.cell(*key)
                cell=cache[key]
                if cell is None:
                    count['失効']+=1;busy=min(row['time']+30,route.force);pending=True;continue
                count['取得']+=1;F.append(pack,dict(cell,origin=row['origins'][ci]))
                busy=route.end if cell['unknown'] else cell['exit_time'];pending=False
            pack['diagnostics'].append({'scene':entry['session'],**count})
        print(entry['session'],len(cache),flush=True)
    periods={'全80':[r['scene'] for r in meta[:80]],'前48':[r['scene'] for r in meta[:48]],'後25':[r['scene'] for r in meta[48:73]],
        '追加7':[r['scene'] for r in meta[73:80]],'本日1':[meta[-1]['scene']]}
    assert {name:len(scenes) for name,scenes in periods.items()}=={'全80':80,'前48':48,'後25':25,'追加7':7,'本日1':1}
    stats=[];short=[]
    for ci,pack in enumerate(packs):
        stat=A.evaluate_pack(pack,periods);stats.append(stat)
        M.save(E.HERE/'金融正本'/(pack['id']+'.json.gz'),pack)
        short.append({'id':pack['id'],'candidate':E.NAMES[ci],'全81':{b:F.terse(g) for b,g in stat['groups'].items()},
            '期間':{p:{b:F.terse(g) for b,g in bands.items()} for p,bands in stat['periods'].items()}})
    rankings={}
    for period in ('全80','前48'):
        for band in ('DAY','NIGHT','ALL'):
            baseline=stats[0]['periods'][period][band]
            order=sorted(range(len(packs)),key=lambda i:(A.rank_key(stats[i]['periods'][period][band],baseline),packs[i]['id']))
            rankings[f'{period}_{band}']=[{'id':packs[i]['id'],'gate':A.gate(stats[i]['periods'][period][band],baseline)} for i in order]
    old=E.read(E.ROOT/'work/190TOPIX/金融正本/TOPIX190_D4_量不明でも動力改善_N01_共通q0の旧_DayA25_NightW15_H60.json.gz')
    ledger={k:v for k,v in packs[0]['ledger'].items() if k!='origin'};oldledger={k:v for k,v in old['ledger'].items() if k!='origin'}
    assert packs[0]['sessions']==old['sessions'] and packs[0]['positions']==old['positions'] and ledger==oldledger
    M.save(E.HERE/'旧対照同体.json',{'成功':True,'台帳属性':len(ledger),'取得':len(ledger['net']),'予約待機追加の影響':False})
    M.save(E.HERE/'全52組安定性.json.gz',{'metrics':stats,'順位':rankings});M.save(E.HERE/'全52組短表.json.gz',{'rows':short,'順位':rankings})
    assert all(M.sha(E.ROOT/p)==sha for p,sha in cfg['Source'].items())
    print('52口座と旧対照同体を確認',flush=True)


if __name__=='__main__':main()
