"""固定165出生と当時特徴だけから166の可用指標階層を固定する。"""
from pathlib import Path
import sys
import numpy as np
import local166

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00166_未公表の長期指標を捏造せず局所技術で参加を補う'
BOOK_SHA='5c3ad73b0003da91749c50e0242b973951c74993db6a9156dfa951d8020f5a49'
sys.path.insert(0,str(ROOT/'work/163入口と任意幅'))
from 共通163 import read,save,sha,data_module


def main() -> None:
    """
    機能: 4主profile・4階層・2旧T幅の全q0方向を金融未入力で保存する。
    引数: なし。166条件、165の方向/枝/旧T、当時100Xとq0識別だけを読む。
    返り値: None。全出生/階層化の出生.npzと指紋・未知/公表履歴の確認票を保存する。
            Context165の取得/pending制御と金融評価は呼び出し側が行う。
    """
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    setting=read(TRIAL/'条件.json');out=HERE/'全出生';assert not out.exists()
    artificial=read(HERE/'局所人工検査結果.json')
    assert artificial['成功'] and artificial['自然特徴と取得と金融未入力']
    assert artificial['SourceSHA256']==sha(HERE/'local166.py')
    assert artificial['検査SourceSHA256']==sha(HERE/'局所人工検査.py')
    parent=ROOT/'work/165順行と回復失敗の複合/全出生';parent_proof=read(parent/'全出生の確認.json')
    assert parent_proof['成功'] and parent_proof['金融未入力']
    path=parent/'複合と技術補完.npz'
    assert sha(path)==parent_proof['files'][path.name]['sha256']
    source_paths=[Path(__file__),HERE/'local166.py',HERE/'局所人工検査.py',HERE/'局所人工検査結果.json',
        HERE/'仕様を固定する.py',TRIAL/'条件.json',parent/'全出生の確認.json',path,
        ROOT/'work/161三時間帯入口のデータ/data161.py',ROOT/'work/163入口と任意幅/共通163.py',
        ROOT/'work/162入口探索/共通.py']
    before={p.relative_to(ROOT).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in source_paths}
    save(TRIAL/'検査/F0_階層出生前.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと入力':before,
        '金融未入力':True,'Context165生成なし':True,'旧165の比較結果未読':True})
    # ----------------------------------------
    # 既存の主4本と旧Tは再推定せず、byte同体の方向/枝をそのまま選ぶ。
    lookup={profile['id']:row for row,profile in enumerate(parent_proof['profiles'])}
    profiles=[parent_proof['profiles'][lookup[name]].copy() for name in setting['core_profiles']]
    assert len(profiles)==4 and len({p['id'] for p in profiles})==4
    selected_indices=[lookup[p['id']] for p in profiles]
    with np.load(path,allow_pickle=False) as original:
        assert set(original.files)=={'directions','branches','technical'}
        directions=original['directions'][selected_indices].copy();branches=original['branches'][selected_indices].copy()
        oldtechnical=original['technical'].copy()
    data=data_module();features=data.load_feature_dataset()
    n=len(features.q0_meta);assert n==35339
    assert directions.shape==branches.shape==(4,n) and oldtechnical.shape==(2,n)
    assert directions.dtype==branches.dtype==oldtechnical.dtype==np.int8
    assert np.isin(directions,(-1,0,1)).all() and np.isin(oldtechnical,(-1,0,1)).all()
    assert np.array_equal(branches==-1,directions==0)
    assert np.isin(branches,(-1,0,1)).all()
    widths=setting['technical_first']['widths'];assert widths==parent_proof['technical_widths']==[150,200]
    hierarchies=setting['hierarchy_variants'];assert len(hierarchies)==4
    starts=np.array([scene['start'] for scene in features.scenes],dtype=np.float64)
    # ----------------------------------------
    # 局所可用性は当時までだけで判定し、旧Tの非0は幅ごとに絶対優先する。
    technical=[];tiers=[];local_directions=[];local_eligible=[];diagnostics=[];local_scores=None
    for hierarchy in hierarchies:
        result=local166.evaluate_local(features.buy_X,features.sell_X,list(features.columns),features.q0_meta,
            starts,hierarchy['after_minutes'],hierarchy['minimum_score'])
        current,tier=local166.merge_hierarchy(oldtechnical,result['directions'])
        assert np.array_equal(current[oldtechnical!=0],oldtechnical[oldtechnical!=0])
        assert not np.any((tier==2)&~result['eligible'][None,:])
        technical.append(current);tiers.append(tier);local_directions.append(result['directions']);local_eligible.append(result['eligible'])
        if local_scores is None:local_scores=result['scores']
        else:assert np.array_equal(local_scores,result['scores'],equal_nan=True)
        diagnostics.append({'id':hierarchy['id'],'eligible_q0':int(result['eligible'].sum()),
            'local_born':int(np.count_nonzero(result['directions'])),
            'seen_m15_hist_q0':int(result['seen_m15_hist'].sum()),
            'score_unknown_by_side':(~result['score_known']).sum(axis=1).tolist(),
            'gate_unknown_by_side':(~result['gate_known']).sum(axis=1).tolist(),
            'old_T_born_by_width':np.count_nonzero(oldtechnical,axis=1).tolist(),
            'local_tier_born_by_width':(tier==2).sum(axis=1).tolist(),
            'technical_born_by_width':np.count_nonzero(current,axis=1).tolist()})
    out.mkdir();destination=out/'階層化の出生.npz'
    np.savez_compressed(destination,directions=directions,branches=branches,technical=np.stack(technical),
        technical_tier=np.stack(tiers),oldtechnical=oldtechnical,local_directions=np.stack(local_directions),
        local_eligible=np.stack(local_eligible),local_scores=local_scores)
    assert all(sha(ROOT/name)==record['sha256'] for name,record in before.items())
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    save(out/'全出生の確認.json',{'成功':True,'条件SHA256':BOOK_SHA,'金融未入力':True,'Context165生成なし':True,
        'Sourceと入力':before,'profiles':profiles,'hierarchies':hierarchies,'technical_widths':widths,
        'shape':{'directions':[4,n],'branches':[4,n],'technical':[4,2,n],'technical_tier':[4,2,n],
            'oldtechnical':[2,n],'local_directions':[4,n],'local_eligible':[4,n],'local_scores':[2,n]},
        'tier':'0待機/1旧T/2局所。実取得の補完採否は165の因果controllerが別途判断する。',
        '診断':diagnostics,'features':features.sources,
        'files':{destination.name:{'bytes':destination.stat().st_size,'sha256':sha(destination)}}})
    print({'成功':True,'出生SHA256':sha(destination),'出生bytes':destination.stat().st_size,'診断':diagnostics})


if __name__=='__main__':main()
