"""長期指標の利用履歴がない場の局所補完を新試行として固定する。"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00166_未公表の長期指標を捏造せず局所技術で参加を補う'


def main() -> None:
    """
    機能: 165の未参加原因を踏まえ、可用指標の補完階層を結果前に固定する。
    引数: なし。
    返り値: None。固定条件と未実行READMEを保存する。
    """
    assert not TRIAL.exists()
    assert max(int(p.name[:5]) for p in (ROOT/'study').iterdir() if p.is_dir() and p.name[:5].isdigit())==165
    parent=ROOT/'study/00165_順行と回復失敗を組み合わせ技術条件で初参加を補う/条件.json'
    setting=json.loads(parent.read_text(encoding='utf-8'))
    setting.update(trial=166,name='未公表の長期指標を捏造せず局所技術で参加を補う')
    setting['parent_conditions']={'path':parent.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(parent.read_bytes()).hexdigest()}
    setting['hypothesis']='旧Tの17列全既知条件が9場で止まった。長期MACD増分をまだ一度も利用できない場合だけ、既知のM5方向・動力・価格構造・量へ限定する補完に切り替える。未知を0や順行へ捏造しない。'
    setting['core_profiles']=[f'{mp}_{ex}_B0_IMMEDIATE' for mp in ('MP0057','MP0058') for ex in ('EX0075','EX0076')]
    setting['hierarchy_variants']=[{'id':f'L{wait}_S{score}','after_minutes':wait,'minimum_score':score}
        for wait in (120,180) for score in (4,5)]
    setting['hierarchy_eligibility']='その場でm15_hist_deltaを両実側のいずれにも一度も有限観測しておらず、開始120/180分以上経過したq0だけ。後の指標が既知になる時刻は見ない。'
    setting['local_score']='M5 EMA21傾き正、DI差正、Hist増分正、RSI増分正、実体正かつ終値位置>0.5、1分相対量>=0.5の6票。6票の必要列は全known。最低4/5票。'
    setting['local_role_gate']='最低1方向票(EMA/DI)と最低1動力票(MACD/RSI/実体)を要求。RSI中心side−5..25、absRSIΔ<=12、absEMA8距離<=1ATR、量>=.5、M5TR/ATR<=2、正常spread0< <=20、absq0gap<=1。'
    setting['local_side_choice']='買売を同じ式で採点し、score差>=1の高い側だけ資格確認する。低い側へ代用しない。'
    setting['hierarchy_priority']='旧T150/200の方向が出れば常に旧T。そうでなく利用履歴不足かつ時間条件を満たす時にlocalを使う。主新規の取得/pending制御、取消後再試行、最初要求優先は165と同体。'
    setting['integration']=['H150','H200']
    setting['main_profile']={'core':'MP0057_EX0076_B0_IMMEDIATE','hierarchy':'L180_S4',
        'momentum_width':200,'fade_width':400,'horizon':'H60','integration':'H200'}
    setting['design_evidence']='165主案728取得72.13%/平均1.01h/利益7,878,969損失4,608,406円だが64/73場。未参加9場はm15Hist増分が全q0未知、他のM5/価格/量は利用可だった。既使用診断を見た新仮説。'
    setting['holdout']='11/10Night～11/13Nightの新7場は本試行へ使わない。候補固定後の別試行で同一N/H条件を適用する。旧156未実行。'
    setting['outputs']='旧165主案/旧補完を固定対照として保持し、166主案・近傍・前半固定選択・全期発見を分離。局所補完を独立枝として計数。'
    TRIAL.mkdir();(TRIAL/'検査').mkdir()
    p=TRIAL/'条件.json';p.write_text(json.dumps(setting,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (TRIAL/'README.md').write_text('# 00166 未公表の長期指標を捏造せず局所技術で参加を補う\n\n2026-11-14。[条件](条件.json)を自然実行前に固定。長期MACDが利用できない場で、既知のM5・価格・量を使う補完へ階層化する。現在未実行。165の未参加場や未知を分母から除かず、全73場参加を実取得で検査する。\n',encoding='utf-8')
    print(json.dumps({'条件SHA256':hashlib.sha256(p.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__=='__main__':
    main()
