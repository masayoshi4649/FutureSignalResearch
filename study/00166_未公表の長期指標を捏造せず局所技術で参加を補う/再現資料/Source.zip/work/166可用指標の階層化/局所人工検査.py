"""局所技術補完の方向対称・因果・未知・公表履歴・優先階層を人工確認する。"""
from pathlib import Path
import hashlib
import json
import numpy as np
import local166 as M

HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 検査Sourceの全物理指紋を計算する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def base(n: int) -> tuple:
    """
    機能: 買6票・売1票、長期増分未公表の人工特徴を作る。
    引数: n(int)は行数。
    返り値: tupleは買売特徴、列、q0識別、場開始。
    """
    columns=list(dict.fromkeys((*M.GATE_COLUMNS,M.AVAILABILITY_COLUMN)));index={name:i for i,name in enumerate(columns)}
    buy=np.zeros((n,len(columns)));sell=np.zeros_like(buy)
    positive={'m5_ema21_delta_to_side':1,'m5_di_difference_to_side':1,'m5_hist_delta_to_side':1,
        'm5_rsi_delta_to_side':1,'m5_body_ratio_to_side':.5,'m5_close_position_to_side':.8,
        'm1_volume_relative_prior3':1,'m5_rsi_center_to_side':0,'q0_entry_minus_ema8_atr5_to_side':0,
        'm5_tr_atr_ratio':1,'q0_spread_points':5,'q0_last_minus_m1_close_atr5_to_side':0,
        M.AVAILABILITY_COLUMN:np.nan}
    for name,value in positive.items():buy[:,index[name]]=value;sell[:,index[name]]=value
    for name in ('m5_ema21_delta_to_side','m5_di_difference_to_side','m5_hist_delta_to_side',
        'm5_rsi_delta_to_side','m5_body_ratio_to_side'):sell[:,index[name]]*=-1
    sell[:,index['m5_close_position_to_side']]=.2
    meta=[{'session_index':0,'q0_time':10800+i} for i in range(n)]
    return buy,sell,columns,meta,np.array([0.])


def run(arguments: tuple,wait: int=120,score: int=4) -> dict:
    """
    機能: 人工特徴を純APIへ渡す。
    引数: arguments(tuple)、wait(int分)、score(int票)。
    返り値: dictは局所判断と診断。
    """
    return M.evaluate_local(*arguments,wait,score)


# ----------------------------------------
def main() -> None:
    """
    機能: 自然特徴・取得・金融を読まず境界・乱数・未来毒の人工検査を行う。
    引数: なし。
    返り値: None。Source固定指紋付きの人工結果を保存する。
    """
    checks=[];a,b,columns,meta,starts=base(8);index={name:i for i,name in enumerate(columns)}
    for row,t in enumerate((7199,7200,10799,10800,10801,10802,10803,10804)):meta[row]['q0_time']=t
    b[4,index[M.AVAILABILITY_COLUMN]]=0
    arguments=(a,b,columns,meta,starts)
    result=run(arguments);assert result['directions'].tolist()==[0,1,1,1,0,0,0,0]
    assert run(arguments,180)['directions'].tolist()==[0,0,0,1,0,0,0,0]
    assert result['seen_m15_hist'].tolist()==[False]*4+[True]*4
    checks.append('120/180分等号、売側だけ有限0の当行から永久無効')
    # ----------------------------------------
    a,b,columns,meta,starts=base(5);index={name:i for i,name in enumerate(columns)}
    meta[3:] = [{'session_index':1,'q0_time':21600+i} for i in range(2)]
    starts=np.array([0.,10800.]);a[1,index[M.AVAILABILITY_COLUMN]]=1
    assert run((a,b,columns,meta,starts))['directions'].tolist()==[1,0,0,1,1]
    checks.append('公表後のNaNや長い間隔では再有効化せず、次の場だけreset')
    # ----------------------------------------
    a,b,columns,meta,starts=base(5);index={name:i for i,name in enumerate(columns)}
    a[0,index['m5_hist_delta_to_side']]=np.nan
    a[1,index['q0_last_minus_m1_close_atr5_to_side']]=np.nan
    a[2,index['m5_hist_delta_to_side']]=np.inf
    zero=np.zeros(len(columns));zero[index[M.AVAILABILITY_COLUMN]]=np.nan
    a[3]=zero;b[3]=zero
    result=run((a,b,columns,meta,starts))
    assert result['directions'].tolist()==[0,0,0,0,1]
    assert np.isnan(result['scores'][0,0]) and np.isnan(result['scores'][0,2])
    assert result['scores'][0,1]==6 and not result['gate_known'][0,1]
    assert result['scores'][0,3]==0 and result['score_known'][0,3]
    checks.append('未知/非有限は0票へ代用せず、既知0票とgateだけ未知を区別')
    # ----------------------------------------
    a,b,columns,meta,starts=base(4);index={name:i for i,name in enumerate(columns)}
    a[0,index['m5_di_difference_to_side']]=0;a[0,index['m5_body_ratio_to_side']]=0
    # 高い側6票は過熱で資格なし、低い側5票は資格ありでも代用しない。
    b[1]=a[1];b[1,index['m5_di_difference_to_side']]=0;a[1,index['m5_rsi_center_to_side']]=26
    # 同点は待機、方向票が無い4票は不許可。
    b[2]=a[2];a[3,index['m5_ema21_delta_to_side']]=0;a[3,index['m5_di_difference_to_side']]=0
    result=run((a,b,columns,meta,starts))
    assert result['directions'].tolist()==[1,0,0,0]
    assert run((a,b,columns,meta,starts),score=5)['directions'][0]==0
    assert result['preferred_side'][1]==1 and result['side_pass'][1,1]
    checks.append('4/5票差、高得点側だけ資格検査、同点待機、最低方向票')
    # ----------------------------------------
    a,b,columns,meta,starts=base(12);index={name:i for i,name in enumerate(columns)}
    boundary=[('m5_rsi_center_to_side',-5,True),('m5_rsi_center_to_side',25,True),
        ('m5_rsi_center_to_side',-5.001,False),('m5_rsi_delta_to_side',12,True),
        ('m5_rsi_delta_to_side',12.001,False),('q0_entry_minus_ema8_atr5_to_side',-1,True),
        ('q0_entry_minus_ema8_atr5_to_side',-1.001,False),('m5_tr_atr_ratio',2,True),
        ('m5_tr_atr_ratio',2.001,False),('q0_spread_points',20,True),
        ('q0_spread_points',0,False),('m1_volume_relative_prior3',.499,False)]
    for row,(name,value,expected) in enumerate(boundary):a[row,index[name]]=value
    assert run((a,b,columns,meta,starts))['directions'].tolist()==[int(v) for _,_,v in boundary]
    checks.append('過熱/追値/急変/値幅/量/気配の境界12件')
    # ----------------------------------------
    rng=np.random.default_rng(166);mirror_rows=0;future_rows=0
    for case in range(40):
        a,b,columns,meta,starts=base(79);index={name:i for i,name in enumerate(columns)}
        for x in (a,b):
            for name in M.GATE_COLUMNS:
                x[:,index[name]]=rng.uniform(-2,2,len(x))
            x[:,index['q0_spread_points']]=rng.uniform(1,25,len(x))
            x[:,index['m5_close_position_to_side']]=rng.uniform(0,1,len(x))
            x[:,index['m5_rsi_center_to_side']]=rng.uniform(-10,30,len(x))
            x[:,index['m5_rsi_delta_to_side']]=rng.uniform(-15,15,len(x))
        # 各場の公表有無と既知0を混ぜる。未来へ毒を入れても過去接頭部は変わらない。
        if case%3==0:a[60,index[M.AVAILABILITY_COLUMN]]=0
        wait=(120,180)[case%2];score=(4,5)[case%2]
        original=run((a,b,columns,meta,starts),wait,score)
        mirrored=run((b,a,columns,meta,starts),wait,score)
        assert np.array_equal(original['directions'],-mirrored['directions'])
        assert np.array_equal(original['scores'],mirrored['scores'][::-1],equal_nan=True)
        mirror_rows+=len(a)
        for cut in (0,1,19,59,78,79):
            changed_a=a.copy();changed_b=b.copy()
            changed_a[cut:]=rng.normal(size=changed_a[cut:].shape);changed_b[cut:]=np.nan
            changed=run((changed_a,changed_b,columns,meta,starts),wait,score)
            for key in original:
                left=original[key];right=changed[key]
                assert np.array_equal(left[...,:cut] if left.ndim==2 else left[:cut],
                    right[...,:cut] if right.ndim==2 else right[:cut],equal_nan=True),(case,cut,key)
            future_rows+=cut
    checks.append('買売鏡像、未来接尾の特徴/長期公表毒で全診断接頭が不変')
    # ----------------------------------------
    old=np.array([[1,-1,0,0,0,1],[-1,1,0,0,-1,0]],dtype=np.int8)
    local=np.array([-1,1,1,-1,0,0],dtype=np.int8);directions,tier=M.merge_hierarchy(old,local)
    assert directions.tolist()==[[1,-1,1,-1,0,1],[-1,1,1,-1,-1,0]]
    assert tier.tolist()==[[1,1,2,2,0,1],[1,1,2,2,1,0]]
    reverse,reverse_tier=M.merge_hierarchy(-old,-local)
    assert np.array_equal(reverse,-directions) and np.array_equal(reverse_tier,tier)
    checks.append('旧Tの相反方向も絶対優先、待機だけLocal、tier/買売対称')
    a,b,columns,meta,starts=base(2);meta[1]['q0_time']=meta[0]['q0_time']-1
    try:run((a,b,columns,meta,starts))
    except AssertionError:pass
    else:raise AssertionError('後退時計を拒否しない')
    checks.append('同場時計後退拒否')
    proof={'成功':True,'自然特徴と取得と金融未入力':True,'検査群':checks,'鏡像行数':mirror_rows,
        '未来毒の接頭照合行数':future_rows,'SourceSHA256':sha(HERE/'local166.py'),'検査SourceSHA256':sha(Path(__file__))}
    (HERE/'局所人工検査結果.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
