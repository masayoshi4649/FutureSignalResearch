# 166 局所可用指標と旧Tの階層化

2026-11-15。正式研究文書ではなく、Rootの取得・金融runnerへ渡す固定部品の説明。自然の金融・165比較結果・未見7場はこの担当では読んでいない。

`local166.evaluate_local(buy_X,sell_X,columns,q0_meta,scene_starts,after_minutes,minimum_score)`は特徴だけを受ける純関数。場開始は`np.array([s['start'] for s in features.scenes])`、待機は120/180分、最低票は4/5。返り値の`directions`は[N]int8、`scores`は[2,N]float、他にknown・当時適格・長期公表履歴・票の診断を持つ。

M5 EMA21傾き、DI差、Hist増分、RSI増分、実体と終値位置、1分相対量の六票。六票に必要な七列を全knownとする。品質gateも含めると必要12列で、スコア未知とgateだけ未知を別に記録する。高得点側だけの資格を検査し、低い側への代用はしない。score差が1未満又は比較相手のscoreが未知なら待機。

`m15_hist_delta_to_side`が両実側のどちらかで一度でも有限となれば、現在行から場末まで局所補完は禁止。有限0も公表として扱い、後のNaNや長いgapで再有効化しない。次の場だけ履歴をresetする。後の初公表時計を先に検索しない。

`merge_hierarchy(oldtechnical[2,N],local_directions[N])`は`(technical,tier)`を返す。旧T非0は絶対優先。tierは0待機/1旧T/2局所。Local自体は幅によらず、選んだ150/200ptは取得後のIFD幅である。

`出生を作る.py`は固定165出生の4主profileと旧T2幅をコピーし、当時100Xだけから4階層を作る。Context165を生成せず、取得・pending・金融は入力にしない。

`全出生/階層化の出生.npz`：

|配列|形|意味|
|---|---|---|
|directions|4×35,339|MP0057/58×EX0075/76のB0 IMMEDIATE、165同体|
|branches|4×35,339|−1待機/0順行/1回復失速、165同体|
|technical|4×2×35,339|階層別・旧T幅別の補完方向|
|technical_tier|4×2×35,339|0待機/1旧T/2局所|
|oldtechnical|2×35,339|165のT150/T200同体|
|local_directions|4×35,339|旧Tと合成する前の局所方向|
|local_eligible|4×35,339|当時まで未公表かつ120/180分経過|
|local_scores|2×35,339|買売の六票。未知はNaN|

profile/階層/幅の順序は`全出生/全出生の確認.json`で固定。実取得採否はRoot側のContext165.technical_integrateを再用し、旧Tと局所の取得をtierで別集計する。局所出生585/402/500/349は注文・取得・利益の件数ではない。

人工検査は鏡像3,160行、未来接尾毒9,440接頭行の全診断、未知/有限0、待機等号、公表後無効、資格不合格の高得点側から低側へ代用しないこと、旧T優先を確認した。`局所人工検査結果.json`と`局所部品の停止.json`にSource/入力/出力指紋を残す。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/166可用指標の階層化/局所人工検査.py'
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/166可用指標の階層化/出生を作る.py'
```

出生生成は全出生が未作成の隔離checkoutでだけ実行する。保存済みの自然出力・固定Sourceを改変しない。Python3.14.3/NumPy2.5.4を使用した。
