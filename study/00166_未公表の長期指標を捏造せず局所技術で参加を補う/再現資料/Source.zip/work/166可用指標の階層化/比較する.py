"""可用指標の補完階層を固定主案・近傍・過去選択に分けて評価する。"""
from pathlib import Path
from itertools import product
import sys
import time
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00166_未公表の長期指標を捏造せず局所技術で参加を補う'
BOOK_SHA='5c3ad73b0003da91749c50e0242b973951c74993db6a9156dfa951d8020f5a49'
sys.path.insert(0,str(ROOT/'work/163入口と任意幅'))
from 共通163 import read,save,sha,module
sys.path.insert(0,str(ROOT/'work/165順行と回復失敗の複合'))
from 評価基盤165 import Context165,widths_for_selection,extended_cube,FIELDS165

old_runner=module(ROOT/'work/165順行と回復失敗の複合/比較する.py','runner165_for166')
FIELDS166=FIELDS165+('old_technical_count','local_technical_count')
INTEGRATIONS=('H150','H200')
PERIODS=('全期','前48場','後25場')


def period_rows(array: np.ndarray) -> dict:
    """
    機能: 三期間の数値を未定義null付きの辞書へ変換する。
    引数: array(np.ndarray[float,3,29])は一政策の統計。
    返り値: dictは期間別の全指標。
    """
    return {period:{name:float(v) if np.isfinite(v) else None for name,v in zip(FIELDS166,row,strict=True)}
        for period,row in zip(PERIODS,array,strict=True)}


def cube(context: Context165, selected: object, origins: np.ndarray,
         widths: np.ndarray, tiers: np.ndarray) -> np.ndarray:
    """
    機能: 旧技術補完と局所補完の取得を独立に計数する。
    引数: context(Context165)、selected(Selection)、origins/widths/tiers(np.ndarray[int])。
    返り値: np.ndarray[float,H,3,29]は既存27指標と二補完枝の件数。
    """
    before=extended_cube(context,selected,origins,widths)
    result=np.full((*before.shape[:-1],len(FIELDS166)),np.nan)
    result[:,:,:len(FIELDS165)]=before
    selected_tier=np.zeros(len(selected.cases),dtype=np.int8)
    mask=origins==2
    selected_tier[mask]=tiers[selected.events[mask]]
    assert np.isin(selected_tier[mask],(1,2)).all()
    scenes=context.case_scene[selected.cases]
    for pi,period in enumerate(PERIODS):
        rows=np.ones(len(scenes),dtype=bool)
        if period=='前48場':rows &= scenes<48
        if period=='後25場':rows &= scenes>=48
        result[:,pi,-2]=np.sum(rows&(selected_tier==1))
        result[:,pi,-1]=np.sum(rows&(selected_tier==2))
    assert np.array_equal(result[:,:,-2]+result[:,:,-1],before[:,:,FIELDS165.index('technical_first_count')])
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: 四主枝・四階層・二補完幅と30幅対・四期限を比較する。
    引数: なし。166条件と金融未入力の出生正本を利用する。
    返り値: None。全統計・取得参照・主案・前半固定選択・支持候補を保存する。
    """
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    setting=read(TRIAL/'条件.json');out=HERE/'比較';assert not out.exists()
    proof_path=HERE/'全出生/全出生の確認.json'
    proof=read(proof_path);assert proof['成功'] and proof['金融未入力']
    path=HERE/'全出生/階層化の出生.npz'
    assert sha(path)==proof['files'][path.name]['sha256']
    source_paths=[Path(__file__),HERE/'local166.py',HERE/'出生を作る.py',proof_path,
        ROOT/'work/165順行と回復失敗の複合/評価基盤165.py',
        ROOT/'work/165順行と回復失敗の複合/比較する.py',
        ROOT/'work/164先着確定と反転比較/比較する.py',ROOT/'work/163入口と任意幅/評価163.py']
    before={p.relative_to(ROOT).as_posix():sha(p) for p in source_paths}
    save(TRIAL/'検査/F1_階層比較前.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと出生':before})
    with np.load(path,allow_pickle=False) as source:
        directions=source['directions'].copy();branches=source['branches'].copy()
        technical=source['technical'].copy();tiers=source['technical_tier'].copy()
        oldtechnical=source['oldtechnical'].copy()
    context=Context165();profiles=proof['profiles'];hierarchies=setting['hierarchy_variants']
    assert [p['id'] for p in profiles]==setting['core_profiles']
    assert technical.shape==tiers.shape==(4,2,len(context.event_keys))
    assert directions.shape==branches.shape==(4,len(context.event_keys))
    mw=setting['momentum_widths'];fw=setting['fade_widths'];nh=len(context.table.horizons)
    metrics=np.full((4,4,len(mw),len(fw),nh,2,3,len(FIELDS166)),np.nan)
    controls=np.full((4,len(mw),len(fw),nh,2,3,len(FIELDS165)),np.nan)
    audits=[];references=[];begin=time.monotonic();out.mkdir()
    for pi,profile in enumerate(profiles):
        core=context.link(directions[pi])
        for ti,tw in enumerate((150,200)):
            old_selected,old_origins,old_audit=context.technical_integrate(directions[pi],core,oldtechnical[ti])
            for mi,fi in product(range(len(mw)),range(len(fw))):
                widths=widths_for_selection(context,old_selected,old_origins,branches[pi],mw[mi],fw[fi],tw)
                controls[pi,mi,fi,:,ti]=extended_cube(context,old_selected,old_origins,widths)
            for li,hierarchy in enumerate(hierarchies):
                selected,origins,clock_audits=context.technical_integrate(directions[pi],core,technical[li,ti])
                audits.append({'profile':profile['id'],'hierarchy':hierarchy['id'],
                    'integration':INTEGRATIONS[ti],'rows':clock_audits})
                selected_tiers=np.zeros(len(selected.cases),dtype=np.int8)
                selected_tiers[origins==2]=tiers[li,ti,selected.events[origins==2]]
                references.append({'profile':profile['id'],'hierarchy':hierarchy['id'],
                    'integration':INTEGRATIONS[ti],'cases':selected.cases.tolist(),'sides':selected.sides.tolist(),
                    'events':selected.events.tolist(),'origins':origins.tolist(),'tiers':selected_tiers.tolist()})
                for mi,fi in product(range(len(mw)),range(len(fw))):
                    widths=widths_for_selection(context,selected,origins,branches[pi],mw[mi],fw[fi],tw)
                    metrics[pi,li,mi,fi,:,ti]=cube(context,selected,origins,widths,tiers[li,ti])
        print(__import__('json').dumps({'profile':pi+1,'全profile':4,'経過秒':round(time.monotonic()-begin)},ensure_ascii=False),flush=True)
    # 旧165の対応行を全件比較し、階層化以外の差が入っていないことを検査する。
    old_proof=read(ROOT/'work/165順行と回復失敗の複合/全出生/全出生の確認.json')
    with np.load(ROOT/'work/165順行と回復失敗の複合/比較/複合入口の統計配列.npz',allow_pickle=False) as old:
        for pi,profile in enumerate(profiles):
            oi=next(i for i,p in enumerate(old_proof['profiles']) if p['id']==profile['id'])
            np.testing.assert_allclose(controls[pi],old['metrics'][oi,:,:,:,3:5],rtol=0,atol=0,equal_nan=True)
    np.savez_compressed(out/'階層化入口の統計配列.npz',metrics=metrics,controls=controls)
    save(out/'初参加補完の因果監査.json.gz',{'成功':True,'rows':audits})
    save(out/'全取得参照.json.gz',{'成功':True,'rows':references})
    save(out/'統計軸.json',{'成功':True,'trial':166,'profiles':profiles,'hierarchies':hierarchies,
        'momentum_widths':mw,'fade_widths':fw,'horizons':context.table.horizons,
        'integrations':INTEGRATIONS,'periods':PERIODS,'fields':FIELDS166,'shape':list(metrics.shape),
        'source_kind':'origin0=主複合、2=技術補完。tier1=旧T、2=長期未公表時の局所補完',
        '旧165対照全要素同体':True})
    f={name:i for i,name in enumerate(FIELDS166)}
    def describe(position: object) -> dict:
        """
        機能: 六政策軸の添字を条件と三期間統計へ変換する。
        引数: position(np.ndarray[int]又はlist[int])はprofile/階層/二幅/期限/補完の添字。
        返り値: dictは候補の再利用可能な記述。
        """
        pi,li,mi,fi,hi,ii=map(int,position)
        return {'position':list(map(int,position)),'profile':profiles[pi],'hierarchy':hierarchies[li],
            'momentum_width':mw[mi],'fade_width':fw[fi],'horizon':context.table.horizons[hi],
            'integration':INTEGRATIONS[ii],'periods':period_rows(metrics[pi,li,mi,fi,hi,ii])}
    positions=sorted(np.argwhere(old_runner.ready_mask(metrics,setting['discovery_support'])),
        key=lambda p:(-metrics[tuple(p)][0,f['count']],-metrics[tuple(p)][0,f['rate']],tuple(p)))
    primary=setting['main_profile']
    pp=[next(i for i,p in enumerate(profiles) if p['id']==primary['core']),
        next(i for i,p in enumerate(hierarchies) if p['id']==primary['hierarchy']),
        mw.index(primary['momentum_width']),fw.index(primary['fade_width']),
        context.table.horizons.index(primary['horizon']),INTEGRATIONS.index(primary['integration'])]
    training=sorted(np.argwhere(old_runner.prospective_mask(metrics)),
        key=lambda p:(-metrics[tuple(p)][1,f['count']],-metrics[tuple(p)][1,f['rate']],tuple(p)))
    save(out/'主案と探索結果.json',{'成功':True,'全期探索は発見用':True,
        '総政策数':4*4*len(mw)*len(fw)*nh*2,'事前固定主案':describe(pp),
        '前48場だけで選択':describe(training[0]) if training else None,'前48場で適格数':len(training),
        '発見支持合格':len(positions),'頻度順上位':[describe(p) for p in positions[:100]]})
    assert all(sha(ROOT/p)==value for p,value in before.items())
    save(out/'完了.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと出生':before,
        '旧165対照全要素同体':True,'経過秒':time.monotonic()-begin,
        'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()}})
    print(__import__('json').dumps({'成功':True,'主案':describe(pp),'発見支持合格':len(positions)},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
