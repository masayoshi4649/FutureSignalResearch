package main

import (
	"fmt"
	"math"
	"sort"
	"strings"
)

const pointValue102 = 100.0
const feeSide102 = 38.5

type position102 struct {
	trade Trade
	floor float64
	best  float64
}

type engine102 struct {
	r        Result
	position *position102
	entry    int
	exit     int
	last     Quote
	hasLast  bool
	forced   bool
	atr      float64
	buy      ProtectionState
	sell     ProtectionState
	serial   int
	peak     float64
	minimum  float64
}

type event102 struct {
	at    float64
	kind  int // Force=0、原行=1、公開済み定時判断=2。
	index int
}

// Replay は、定時信号を単一建玉・全量最良気配仮定で再生します。
//
// 引数: session(Session)、quotes([]Quote)、decisions([]Decision)、cfg(Config)。
// 返り値: Result。入力不正又は未返済・未約定残はSuccess=falseです。
// 原行を再時刻化せず、要求時に観測済みのIndexより後だけを約定へ使います。
func Replay(session Session, quotes []Quote, decisions []Decision, cfg Config) Result {
	e := engine102{r: Result{Session: session, Config: cfg, Orders: []Order{}, Fills: []Fill{},
		Trades: []Trade{}, Grids: []GridRecord{}, EquityPoints: []EquityPoint{}}, entry: -1, exit: -1}
	if err := validate102(session, quotes, decisions, cfg); err != nil {
		e.r.Error = err.Error()
		return e.r
	}
	byAt := make(map[float64]Decision, len(decisions))
	for _, d := range decisions {
		byAt[d.At] = d
	}
	events := []event102{{at: session.Force, kind: 0}}
	for i, q := range quotes {
		events = append(events, event102{at: q.Time, kind: 1, index: i})
	}
	grids := []Decision{}
	for at := session.Start + 1800; at < session.End-1800; at += 300 {
		d, found := byAt[at]
		if !found {
			d = Decision{At: at, AvailableAt: at, Reason: "定時判断が欠測"}
		}
		grids = append(grids, d)
		events = append(events, event102{at: math.Max(at, d.AvailableAt), kind: 2, index: len(grids) - 1})
	}
	for _, d := range decisions {
		if d.At < session.Start+1800 || d.At >= session.End-1800 {
			grids = append(grids, d)
			events = append(events, event102{at: math.Max(d.At, d.AvailableAt), kind: 2, index: len(grids) - 1})
		}
	}
	sort.SliceStable(events, func(i, j int) bool {
		if events[i].at != events[j].at {
			return events[i].at < events[j].at
		}
		return events[i].kind < events[j].kind
	})
	for _, event := range events {
		e.expire(event.at)
		switch event.kind {
		case 0:
			e.force(event.at)
		case 1:
			e.onQuote(quotes[event.index])
		case 2:
			e.onGrid(grids[event.index], event.at)
		}
	}
	e.expire(session.End)
	e.finishClassification()
	e.r.OpenQuantity = 0
	if e.position != nil {
		e.r.OpenQuantity = e.position.trade.Qty
	}
	if e.entry >= 0 {
		e.r.PendingEntry = e.r.Orders[e.entry].Qty
	}
	if e.exit >= 0 {
		e.r.PendingExit = e.r.Orders[e.exit].Qty
	}
	e.r.Net = e.r.Gross - e.r.Fee - e.r.Slip
	finalAt, finalIndex := session.End, -1
	if e.hasLast {
		finalAt, finalIndex = e.last.Time, e.last.Index
	}
	e.r.EquityPoints = append(e.r.EquityPoints, EquityPoint{At: finalAt, Index: finalIndex,
		Phase: "finish", Kind: "場末", Equity: e.equity()})
	if e.r.OpenQuantity != 0 || e.r.PendingEntry != 0 || e.r.PendingExit != 0 {
		e.r.Error = "場末に実建玉又は未約定予約が残存"
		return e.r
	}
	e.r.Success = true
	return e.r
}

// validate102 は、時計・数量・公開値の破損を再生前に拒否します。
//
// 引数: Session、[]Quote、[]Decision、Config。
// 返り値: error。通常の判断未知は許容し、未来公表をAtへ戻しません。
func validate102(s Session, quotes []Quote, decisions []Decision, c Config) error {
	if s.ID == "" || (s.Kind != "Day" && s.Kind != "Night") || !finite102(s.Start, s.End, s.Force) ||
		s.Start < 0 || s.End <= s.Start+3600 || s.Force <= s.Start || s.Force > s.End {
		return fmt.Errorf("場の時計又は識別が不正")
	}
	if c.Name == "" || (c.EntryPolicy != "S3" && c.EntryPolicy != "S4") ||
		(c.TrailPolicy != "P0" && c.TrailPolicy != "A0" && c.TrailPolicy != "A1") ||
		!finite102(c.Slip, c.Delay) || (c.Slip != 0 && c.Slip != 5) || (c.Delay != 0 && c.Delay != 1) {
		return fmt.Errorf("政策・費用又は遅延が不正")
	}
	for i, q := range quotes {
		if !finite102(q.Time, q.Bid, q.Ask) || q.Time < s.Start || q.Time > s.End || q.Index < 0 ||
			(i > 0 && (q.Index <= quotes[i-1].Index || q.Time < quotes[i-1].Time)) ||
			(q.Valid && (q.Bid <= 0 || q.Ask <= q.Bid)) {
			return fmt.Errorf("気配の時計・Index又は価格が不正: %d", i)
		}
	}
	seen := map[float64]bool{}
	for _, d := range decisions {
		grid := (d.At - s.Start) / 300
		if !finite102(d.At, d.AvailableAt, d.ATR) || d.At < s.Start || d.At >= s.End ||
			grid != math.Trunc(grid) || d.AvailableAt < 0 || d.ATR < 0 || seen[d.At] ||
			(d.Side != -1 && d.Side != 0 && d.Side != 1) ||
			(d.Qty != 0 && d.Qty != 2 && d.Qty != 4 && d.Qty != 6) ||
			(d.Known && d.Side != 0 && d.Qty == 0) {
			return fmt.Errorf("定時判断の時計・数量又は値が不正")
		}
		seen[d.At] = true
	}
	return nil
}

// finite102 は、必要数値に非有限値がないことを確認します。
//
// 引数: values(...float64)。返り値: boolは全値有限のときtrueです。
func finite102(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// expire は、論理枠60秒と末尾新規締切の早い期限で等号失効させます。
//
// 引数: at(float64)。返り値: なし。取消は約定より先です。
func (e *engine102) expire(at float64) {
	if e.entry >= 0 && at >= e.r.Orders[e.entry].ExpiresAt {
		o := &e.r.Orders[e.entry]
		o.Status, o.CancelAt = "cancelled", o.ExpiresAt
		e.entry = -1
	}
}

// force は、新規取消後に全残返済を予約します。
//
// 引数: at(float64)。返り値: なし。同秒原行より先に処理します。
func (e *engine102) force(at float64) {
	e.forced = true
	if e.entry >= 0 {
		o := &e.r.Orders[e.entry]
		o.Status, o.CancelAt = "cancelled", at
		e.entry = -1
	}
	if e.position != nil && e.exit < 0 {
		e.requestExit(at, 0, "場末強制返済")
	}
}

// onGrid は、公表時刻に保有情報・反対返済・新規要求を順に処理します。
//
// 引数: d(Decision)、at(float64)は実要求可能時計です。返り値: なし。
func (e *engine102) onGrid(d Decision, at float64) {
	if d.ATR > 0 {
		e.atr = d.ATR
	}
	if d.BuyProtection.Known {
		e.buy = d.BuyProtection
	}
	if d.SellProtection.Known {
		e.sell = d.SellProtection
	}
	if e.position != nil {
		state := d.BuyProtection
		if e.position.trade.Side < 0 {
			state = d.SellProtection
		}
		if !e.forced && d.Known && d.Side == -e.position.trade.Side && state.Known &&
			(state.Converged || state.Stalled) && e.exit < 0 {
			e.requestExit(at, d.At, "反対方向と保有複合否定")
		}
	}
	if d.At < e.r.Session.Start+1800 || d.At >= e.r.Session.End-1800 {
		return
	}
	row := GridRecord{At: d.At, Action: "wait", Reason: d.Reason, Decision: d}
	if e.position != nil {
		row.Quantity = e.position.trade.Qty
		row.Action, row.Reason = "hold", "実保有。追加取得なし"
	} else if e.entry >= 0 {
		row.Pending = e.r.Orders[e.entry].Qty
		row.Reason = "実新規の約定待ち"
	} else if e.forced || at >= e.r.Session.Force {
		row.Reason = "場末新規停止"
	} else if d.Known && d.Side == 0 {
		row.Reason = "既知の新規不成立"
	} else if !d.Known || !e.hasLast || !e.last.Valid || d.ATR <= 0 {
		row.Action, row.Reason = "unknown", "必要判断・気配又はATRが未知"
	} else if at >= math.Min(d.At+60, e.r.Session.End-1800) {
		row.Action, row.Reason = "unknown", "公表遅延で論理枠60秒又は末尾新規締切に到達"
	} else if age := at - e.last.Time; age < 0 || age > 15 {
		row.Action, row.Reason = "unknown", "実要求時の気配価格時計が0..15秒外"
	} else {
		e.serial++
		positionID := fmt.Sprintf("%s-P%04d", e.r.Config.Name, e.serial)
		o := Order{ID: fmt.Sprintf("%s-O%04d", e.r.Config.Name, len(e.r.Orders)+1),
			PositionID: positionID, Kind: "entry", Side: d.Side, Qty: d.Qty, At: at, GridAt: d.At,
			RequestIndex: e.last.Index, ExpiresAt: math.Min(d.At+60, e.r.Session.End-1800), Reason: d.Reason, Status: "pending"}
		e.r.Orders = append(e.r.Orders, o)
		e.entry = len(e.r.Orders) - 1
		row.Pending, row.Reason = d.Qty, "新規受理。参加分類は実約定後に確定"
	}
	e.r.Grids = append(e.r.Grids, row)
}

// onQuote は、次適格約定後に現在評価と連続追尾を処理します。
//
// 引数: q(Quote)。返り値: なし。新要求を同じ原行で約定しません。
func (e *engine102) onQuote(q Quote) {
	e.last, e.hasLast = q, true
	if !q.Valid {
		return
	}
	e.recordEquity(q, "pre_fill")
	if e.position != nil {
		e.protect(q)
	}
	if e.exit >= 0 && e.eligible(e.r.Orders[e.exit], q) {
		e.fillExit(q)
	}
	if e.entry >= 0 && e.eligible(e.r.Orders[e.entry], q) {
		e.fillEntry(q)
	}
	e.recordEquity(q, "after_fill")
	if e.position != nil {
		e.protect(q)
	}
}

// eligible は、要求直前原行よりstrict後の正常行だけを許可します。
//
// 引数: o(Order)、q(Quote)。返り値: boolは約定可否です。
func (e *engine102) eligible(o Order, q Quote) bool {
	return q.Valid && q.Index > o.RequestIndex && q.Time >= o.At+e.r.Config.Delay
}

// fillEntry は、取得時の最新公表ATRで初期損切り幅を凍結します。
//
// 引数: q(Quote)。返り値: なし。全量最良BBO仮定で板厚は使いません。
func (e *engine102) fillEntry(q Quote) {
	o := &e.r.Orders[e.entry]
	f := e.makeFill(*o, q)
	o.Status = "filled"
	e.entry = -1
	stop := f.Price - float64(f.Side)*math.Max(20, 2*e.atr)
	t := Trade{ID: f.PositionID, Side: f.Side, Qty: f.Qty, Entry: f, EntryATR: e.atr,
		InitialStop: stop, FinalFloor: stop}
	e.position = &position102{trade: t, floor: stop, best: e.mark(q, f.Side)}
	e.r.PosCount++
}

// makeFill は、約定BBOと指定費用・仮定滑りを別々に記録します。
//
// 引数: o(Order)、q(Quote)。返り値: Fill。
func (e *engine102) makeFill(o Order, q Quote) Fill {
	price := q.Ask
	if o.Side < 0 {
		price = q.Bid
	}
	f := Fill{OrderID: o.ID, PositionID: o.PositionID, Kind: o.Kind, Side: o.Side,
		Qty: o.Qty, Quote: q, Price: price, Fee: feeSide102 * float64(o.Qty),
		Slip: e.r.Config.Slip * pointValue102 * float64(o.Qty)}
	e.r.Fee += f.Fee
	e.r.Slip += f.Slip
	e.r.Fills = append(e.r.Fills, f)
	return f
}

// fillExit は、一建玉の全返済と実現純額を確定します。
//
// 引数: q(Quote)。返り値: なし。要求予約による保有余力解放は行いません。
func (e *engine102) fillExit(q Quote) {
	o := &e.r.Orders[e.exit]
	f := e.makeFill(*o, q)
	o.Status = "filled"
	t := e.position.trade
	t.Exit, t.ExitReason, t.FinalFloor = f, o.Reason, e.position.floor
	t.Gross = float64(t.Side) * (f.Price - t.Entry.Price) * pointValue102 * float64(t.Qty)
	t.Fee = t.Entry.Fee + f.Fee
	t.Slip = t.Entry.Slip + f.Slip
	t.Net = t.Gross - t.Fee - t.Slip
	e.r.Gross += t.Gross
	e.r.Trades = append(e.r.Trades, t)
	e.position, e.exit = nil, -1
}

// mark は、実保有を全量返済する側の最良BBOを返します。
//
// 引数: q(Quote)、side(int)。返り値: float64は価格です。
func (e *engine102) mark(q Quote, side int) float64 {
	if side > 0 {
		return q.Bid
	}
	return q.Ask
}

// protect は、現在残玉単価益と固定・可変幅で非緩和床を更新します。
//
// 引数: q(Quote)。返り値: なし。価格線の発動は要求で、約定は後続行です。
func (e *engine102) protect(q Quote) {
	p := e.position
	s := float64(p.trade.Side)
	mark := e.mark(q, p.trade.Side)
	cost := 2*feeSide102/pointValue102 + 2*e.r.Config.Slip
	unit := s*(mark-p.trade.Entry.Price) - cost
	positive := s*(mark-(p.trade.Entry.Price+s*cost)) > 0
	if positive && !p.trade.HadPositiveUnit {
		p.trade.HadPositiveUnit, p.trade.FirstPositiveAt = true, q.Time
	}
	if s*(mark-p.best) > 0 {
		p.best = mark
	}
	activate := positive
	if e.r.Config.TrailPolicy != "P0" {
		// 費用と起動幅を価格線へ移す同値式で、境界へ任意epsilonを足しません。
		level := p.trade.Entry.Price + s*(cost+math.Max(10, .5*p.trade.EntryATR))
		activate = s*(mark-level) >= 0
	}
	if !p.trade.Activated && activate {
		p.trade.Activated = true
		p.trade.ActivationAt, p.trade.ActivationIndex, p.trade.ActivationUnit = q.Time, q.Index, unit
		e.r.ActivatedPositions++
	}
	if p.trade.Activated {
		minimum, width := p.trade.Entry.Price, 2*p.trade.EntryATR
		if e.r.Config.TrailPolicy != "P0" {
			minimum += s * math.Ceil((2*feeSide102/pointValue102+2*e.r.Config.Slip)/5) * 5
			width = math.Max(10, 1.5*e.atr)
			state := e.buy
			if p.trade.Side < 0 {
				state = e.sell
			}
			if e.r.Config.TrailPolicy == "A1" && state.Known && (state.Converged || state.Stalled) {
				width = math.Max(10, .75*e.atr)
			}
		}
		for _, candidate := range []float64{minimum, p.best - s*width} {
			if s*(candidate-p.floor) > 0 {
				p.floor = candidate
			}
		}
	}
	p.trade.FinalFloor = p.floor
	if e.exit < 0 && s*(mark-p.floor) <= 0 {
		reason := "取得時ATR初期損切り"
		if p.trade.Activated {
			reason = "利益起動後の非緩和床"
		}
		e.requestExit(q.Time, 0, reason)
	}
}

// requestExit は、未予約の全保有を一度だけ予約します。
//
// 引数: at/gridAt(float64)、reason(string)。返り値: なし。
func (e *engine102) requestExit(at, gridAt float64, reason string) {
	if e.position == nil || e.exit >= 0 {
		return
	}
	index := -1
	if e.hasLast {
		index = e.last.Index
	}
	t := e.position.trade
	e.r.Orders = append(e.r.Orders, Order{ID: fmt.Sprintf("%s-O%04d", e.r.Config.Name, len(e.r.Orders)+1),
		PositionID: t.ID, Kind: "exit", Side: -t.Side, Qty: t.Qty, At: at, GridAt: gridAt,
		RequestIndex: index, Reason: reason, Status: "pending"})
	e.exit = len(e.r.Orders) - 1
}

// equity は、実現純額と現在返済BBOの保有評価を合計します。
//
// 引数: なし。返り値: float64は円。未払返済費用も控除します。
func (e *engine102) equity() float64 {
	value := e.r.Gross - e.r.Fee - e.r.Slip
	if e.position != nil && e.hasLast && e.last.Valid {
		t := e.position.trade
		value += float64(t.Side) * (e.mark(e.last, t.Side) - t.Entry.Price) * pointValue102 * float64(t.Qty)
		value -= (feeSide102 + e.r.Config.Slip*pointValue102) * float64(t.Qty)
	}
	return value
}

// recordEquity は、全正常行の評価から更新極値だけを保存します。
//
// 引数: q(Quote)、phase(string)。返り値: なし。全原行の複写はしません。
func (e *engine102) recordEquity(q Quote, phase string) {
	v := e.equity()
	kinds := []string{}
	if v > e.peak {
		e.peak = v
		kinds = append(kinds, "峰")
	}
	if v < e.minimum {
		e.minimum = v
		kinds = append(kinds, "谷")
	}
	if e.peak-v > e.r.DD {
		e.r.DD = e.peak - v
		kinds = append(kinds, "最大DD")
	}
	if len(kinds) > 0 {
		e.r.EquityPoints = append(e.r.EquityPoints, EquityPoint{At: q.Time, Index: q.Index,
			Phase: phase, Kind: strings.Join(kinds, "/"), Equity: v})
	}
	e.r.PeakEquity, e.r.MinEquity = e.peak, e.minimum
}

// finishClassification は、実保有区間・実新規fillによって分母を確定します。
//
// 引数: なし。返り値: なし。受理だけの未約定をnewへ数えません。
func (e *engine102) finishClassification() {
	sort.Slice(e.r.Grids, func(i, j int) bool { return e.r.Grids[i].At < e.r.Grids[j].At })
	for i := range e.r.Grids {
		row := &e.r.Grids[i]
		entryFilled := false
		for _, o := range e.r.Orders {
			if o.Kind == "entry" && o.GridAt == row.At && o.Status == "filled" {
				entryFilled = true
			}
		}
		if entryFilled {
			row.Action, row.Reason = "new", "当枠の新規要求が実約定"
		} else {
			held := false
			for _, t := range e.r.Trades {
				if t.Entry.Quote.Time <= row.At && row.At < t.Exit.Quote.Time {
					held = true
				}
			}
			if e.position != nil && e.position.trade.Entry.Quote.Time <= row.At {
				held = true
			}
			if held {
				row.Action, row.Reason = "hold", "論理判断時刻に実保有"
			} else if row.Action == "hold" {
				row.Action, row.Reason = "wait", "公表待ち中の取得で論理枠時点は未保有"
			}
		}
		switch row.Action {
		case "new":
			e.r.New++
		case "hold":
			e.r.Hold++
		case "unknown":
			e.r.Unknown++
		default:
			e.r.Wait++
		}
	}
	e.r.Denom = len(e.r.Grids)
	e.r.Active = e.r.New + e.r.Hold
	if e.r.Denom > 0 {
		e.r.Participation = float64(e.r.Active) / float64(e.r.Denom)
	}
}
