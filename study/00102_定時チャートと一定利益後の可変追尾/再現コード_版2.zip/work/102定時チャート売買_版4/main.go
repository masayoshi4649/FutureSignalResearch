package main

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strings"
	"sync"
	"time"

	chart "github.com/masayoshi4649/SessionTradeExecuter/minichart"
)

type FileRef102 struct {
	Path string `json:"path"`
	SHA  string `json:"sha256"`
}
type SceneInput102 struct {
	Session Session    `json:"session"`
	Header  FileRef102 `json:"header"`
	Records FileRef102 `json:"records"`
}
type Condition102 struct {
	Version      int               `json:"version"`
	Trial        int               `json:"trial"`
	Fixed        bool              `json:"fixed"`
	Scenes       []SceneInput102   `json:"scenes"`
	Configs      []Config          `json:"configs"`
	Code         map[string]string `json:"code_sha256"`
	Binary       FileRef102        `json:"binary"`
	InputReceipt FileRef102        `json:"input_receipt"`
}
type InputReceipt102 struct {
	Success           bool     `json:"成功"`
	Stage             string   `json:"stage"`
	Sessions          []string `json:"sessions"`
	Unchanged         bool     `json:"前後不変"`
	Proof100SHA       string   `json:"固定100完了SHA256"`
	SourceReexecuted  bool     `json:"source_reexecuted"`
	FinancialExecuted bool     `json:"financial_executed"`
	Details           []struct {
		Session    string `json:"session"`
		Header     string `json:"header"`
		HeaderSHA  string `json:"header_SHA256"`
		Records    string `json:"path"`
		RecordsSHA string `json:"SHA256"`
	} `json:"details"`
}
type Args102 struct {
	Condition, ConditionSHA, Stage, Out, First2, First2SHA string
	Workers                                                int
}

// Header102 は固定共有入力から必要な公開型だけを射影します。
//
// Source/金融・特徴値の再生成は行わず、既存辞書や終了値も複製しません。
type Header102 struct {
	Version int `json:"version"`
	Session struct {
		ID    string  `json:"id"`
		Kind  string  `json:"kind"`
		Start float64 `json:"start"`
		End   float64 `json:"end"`
		Force float64 `json:"force_close"`
	} `json:"session"`
	Streamed          bool                       `json:"streamed"`
	SourceReexecuted  bool                       `json:"source_reexecuted"`
	FinancialExecuted bool                       `json:"financial_executed"`
	RowCount          int                        `json:"row_count"`
	Grids             []chart.TechnicalGateInput `json:"grids"`
}
type GridSignal102 struct {
	Decision Decision       `json:"decision"`
	Evidence SignalEvidence `json:"evidence"`
}
type SceneResult102 struct {
	Version          int                        `json:"version"`
	Trial            int                        `json:"trial"`
	Session          Session                    `json:"session"`
	Books            map[string]Result          `json:"books"`
	Signals          map[string][]GridSignal102 `json:"signals"`
	QuoteRows        int                        `json:"quote_rows"`
	BadQuoteRows     int                        `json:"bad_quote_rows"`
	ControlRecords   int                        `json:"control_records"`
	SourceReexecuted bool                       `json:"source_reexecuted"`
	ChartsRecomputed bool                       `json:"charts_recomputed"`
}
type SceneReceipt102 struct {
	Session string               `json:"session"`
	Path    string               `json:"path,omitempty"`
	SHA     string               `json:"sha256,omitempty"`
	Books   int                  `json:"books"`
	Error   string               `json:"error,omitempty"`
	Totals  map[string]Totals102 `json:"totals,omitempty"`
}
type Totals102 struct {
	Gross         float64 `json:"gross"`
	Fee           float64 `json:"fee"`
	Slip          float64 `json:"slip"`
	Net           float64 `json:"net"`
	Positions     int     `json:"positions"`
	EntryQuantity int     `json:"entry_quantity"`
	Denom         int     `json:"denom"`
	Active        int     `json:"active"`
}
type Completion102 struct {
	Version          int               `json:"version"`
	Trial            int               `json:"trial"`
	Success          bool              `json:"success"`
	Stage            string            `json:"stage"`
	ConditionSHA     string            `json:"condition_sha256"`
	Scenes           int               `json:"scenes"`
	BooksPerScene    int               `json:"books_per_scene"`
	Books            int               `json:"books"`
	Configs          []Config          `json:"configs"`
	Results          []SceneReceipt102 `json:"results"`
	Before           map[string]string `json:"input_code_sha256_before"`
	After            map[string]string `json:"input_code_sha256_after"`
	Unchanged        bool              `json:"input_code_unchanged"`
	First2           *FileRef102       `json:"first2,omitempty"`
	SourceReexecuted bool              `json:"source_reexecuted"`
	ChartsRecomputed bool              `json:"charts_recomputed"`
	RawCSVRead       int               `json:"raw_csv_read"`
	Error            string            `json:"error,omitempty"`
}

// fileSHA102 は通常ファイルを逐次読み指紋を返します。
//
// 引数: path(string)は明示された入力。返り値: string/errorはSHA256又は不正です。
func fileSHA102(path string) (string, error) {
	f, e := os.Open(path)
	if e != nil {
		return "", e
	}
	defer f.Close()
	st, e := f.Stat()
	if e != nil {
		return "", e
	}
	if !st.Mode().IsRegular() {
		return "", fmt.Errorf("通常ファイルではありません: %s", path)
	}
	h := sha256.New()
	if _, e = io.Copy(h, f); e != nil {
		return "", e
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

// validSHA102 は空値や大文字等の未固定指紋を拒否します。
//
// 引数: value(string)は指紋。返り値: boolは小文字64桁なら真です。
func validSHA102(value string) bool {
	b, e := hex.DecodeString(value)
	return e == nil && len(b) == 32 && strings.ToLower(value) == value
}

// absolute102 は条件に含む相対pathの基準を一意にします。
//
// 引数: base/path(string)は基準と明示path。返り値: string/errorは絶対pathです。
func absolute102(base, path string) (string, error) {
	if path == "" {
		return "", fmt.Errorf("空path")
	}
	if !filepath.IsAbs(path) {
		path = filepath.Join(base, path)
	}
	return filepath.Abs(path)
}

// strictJSON102 は重複キー・末尾値・未知設定欄を拒否します。
//
// 引数: data([]byte)、out(any)、strict(bool)はJSON/格納先/未知欄拒否です。
// 返り値: errorは重複又は型等の破損です。
func strictJSON102(data []byte, out any, strict bool) error {
	d := json.NewDecoder(bytes.NewReader(data))
	if e := uniqueValue102(d); e != nil {
		return e
	}
	if _, e := d.Token(); e != io.EOF {
		return fmt.Errorf("JSON末尾値又は破損")
	}
	d = json.NewDecoder(bytes.NewReader(data))
	if strict {
		d.DisallowUnknownFields()
	}
	return d.Decode(out)
}

// uniqueValue102 は一JSON値の全階層に重複キーがないことを検査します。
//
// 引数: d(*json.Decoder)は当値の先頭。返り値: errorは字句/重複破損です。
func uniqueValue102(d *json.Decoder) error {
	t, e := d.Token()
	if e != nil {
		return e
	}
	delim, ok := t.(json.Delim)
	if !ok {
		return nil
	}
	switch delim {
	case '{':
		seen := map[string]bool{}
		for d.More() {
			k, e := d.Token()
			if e != nil {
				return e
			}
			s, ok := k.(string)
			if !ok || seen[s] {
				return fmt.Errorf("JSONキーの重複")
			}
			seen[s] = true
			if e = uniqueValue102(d); e != nil {
				return e
			}
		}
	case '[':
		for d.More() {
			if e := uniqueValue102(d); e != nil {
				return e
			}
		}
	default:
		return fmt.Errorf("JSON区切り不正")
	}
	_, e = d.Token()
	return e
}

// allowedSessions102 は既使用27開始日・昼夜54だけを返します。
//
// 引数: なし。返り値: []Sessionは新日を含まない固定時計集合です。
func allowedSessions102() []Session {
	zone := time.FixedZone("JST", 9*3600)
	out := []Session{}
	for d := time.Date(2026, 9, 21, 0, 0, 0, 0, zone); !d.After(time.Date(2026, 10, 27, 0, 0, 0, 0, zone)); d = d.AddDate(0, 0, 1) {
		if d.Weekday() == time.Saturday || d.Weekday() == time.Sunday {
			continue
		}
		day := d.Add(8*time.Hour + 45*time.Minute)
		night := d.Add(17 * time.Hour)
		out = append(out, Session{d.Format("2006-01-02") + "_Day", "Day", float64(day.Unix()), float64(d.Add(15*time.Hour + 45*time.Minute).Unix()), float64(d.Add(15*time.Hour + 35*time.Minute).Unix())}, Session{d.Format("2006-01-02") + "_Night", "Night", float64(night.Unix()), float64(d.Add(30 * time.Hour).Unix()), float64(d.Add(29*time.Hour + 50*time.Minute).Unix())})
	}
	return out
}

// canonicalConfigs102 は採否・追尾・費用・遅延の全24条件を列挙します。
//
// 引数: なし。返り値: []Configは順序も固定した設定集合です。
func canonicalConfigs102() []Config {
	out := []Config{}
	for _, entry := range []string{"S3", "S4"} {
		for _, trail := range []string{"P0", "A0", "A1"} {
			for _, slip := range []float64{0, 5} {
				for _, delay := range []float64{0, 1} {
					out = append(out, Config{fmt.Sprintf("%s_%s_C%.0f_D%.0f", entry, trail, slip, delay), entry, trail, slip, delay})
				}
			}
		}
	}
	return out
}

// repoRoot102 は相対コードpath専用のリポジトリ基準を見つけます。
//
// 引数: なし。返り値: string/errorはstudy/scriptsを持つ作業場所の祖先です。
func repoRoot102() (string, error) {
	p, e := os.Getwd()
	if e != nil {
		return "", e
	}
	for {
		a, ae := os.Stat(filepath.Join(p, "study"))
		b, be := os.Stat(filepath.Join(p, "scripts"))
		if ae == nil && be == nil && a.IsDir() && b.IsDir() {
			return p, nil
		}
		next := filepath.Dir(p)
		if next == p {
			return "", fmt.Errorf("repo基準を特定できません")
		}
		p = next
	}
}

// bindInputReceipt102 は固定101生成metadataと54場の入力対を一意に結びます。
//
// 引数: path/root(string)、scenes([]SceneInput102)はreceipt/repo/絶対path化済み条件です。
// 返り値: errorは生成未完了・集合/出典/入力対の不一致です。Native等は読みません。
func bindInputReceipt102(path, root string, scenes []SceneInput102) error {
	b, e := os.ReadFile(path)
	if e != nil {
		return e
	}
	var r InputReceipt102
	if e = strictJSON102(b, &r, false); e != nil {
		return e
	}
	if !r.Success || r.Stage != "full54" || !r.Unchanged || r.SourceReexecuted || r.FinancialExecuted || r.Proof100SHA != "4a8bc486e329f65f17e2395f781b2efd7cf76c5630d91924b611e90254725af3" || len(r.Sessions) != 54 || len(r.Details) != 54 {
		return fmt.Errorf("101生成完了/全54/固定100出典不一致")
	}
	for i, d := range r.Details {
		s := scenes[i]
		h, e := absolute102(root, d.Header)
		if e != nil {
			return e
		}
		p, e := absolute102(root, d.Records)
		if e != nil {
			return e
		}
		if r.Sessions[i] != s.Session.ID || d.Session != s.Session.ID || !strings.EqualFold(h, s.Header.Path) || !strings.EqualFold(p, s.Records.Path) || d.HeaderSHA != s.Header.SHA || d.RecordsSHA != s.Records.SHA {
			return fmt.Errorf("101生成metadataと条件の入力対不一致: %s", s.Session.ID)
		}
	}
	return nil
}

// prepare102 は本文処理と出力作成より前に全固定metadataを検査します。
//
// 引数: a(Args102)、root/executable(string)は引数とrepo/実行物です。
// 返り値: Condition102/[]SceneInput102/map[string]string/errorは固定設定/対象場/前指紋です。
func prepare102(a Args102, root, executable string) (Condition102, []SceneInput102, map[string]string, error) {
	var c Condition102
	fail := func(e error) (Condition102, []SceneInput102, map[string]string, error) { return c, nil, nil, e }
	if a.Stage != "first2" && a.Stage != "full54" || a.Workers < 1 || a.Workers > 4 || !validSHA102(a.ConditionSHA) {
		return fail(fmt.Errorf("stage/workers/条件SHA不正"))
	}
	cp, e := filepath.Abs(a.Condition)
	if e != nil {
		return fail(e)
	}
	sum, e := fileSHA102(cp)
	if e != nil || sum != a.ConditionSHA {
		return fail(fmt.Errorf("条件SHA不一致: %v", e))
	}
	raw, e := os.ReadFile(cp)
	if e != nil {
		return fail(e)
	}
	if e = strictJSON102(raw, &c, true); e != nil {
		return fail(e)
	}
	if c.Version != 1 || c.Trial != 102 || !c.Fixed || !reflect.DeepEqual(c.Configs, canonicalConfigs102()) || len(c.Scenes) != 54 || len(c.Code) == 0 {
		return fail(fmt.Errorf("固定条件/全54/全24設定不一致"))
	}
	base := filepath.Dir(cp)
	seen := map[string]bool{}
	allowed := allowedSessions102()
	for i := range c.Scenes {
		if c.Scenes[i].Session != allowed[i] {
			return fail(fmt.Errorf("許可54集合/場時計不一致: %d", i))
		}
		for _, r := range []*FileRef102{&c.Scenes[i].Header, &c.Scenes[i].Records} {
			if !validSHA102(r.SHA) {
				return fail(fmt.Errorf("場入力SHA未固定"))
			}
			r.Path, e = absolute102(base, r.Path)
			if e != nil {
				return fail(e)
			}
			k := strings.ToLower(r.Path)
			if seen[k] {
				return fail(fmt.Errorf("場入力pathの重複"))
			}
			seen[k] = true
		}
	}
	before := map[string]string{cp: a.ConditionSHA}
	check := func(r FileRef102, base string) error {
		if !validSHA102(r.SHA) {
			return fmt.Errorf("未固定SHA")
		}
		p, e := absolute102(base, r.Path)
		if e != nil {
			return e
		}
		h, e := fileSHA102(p)
		if e != nil {
			return e
		}
		if h != r.SHA {
			return fmt.Errorf("指紋不一致: %s", p)
		}
		if old, ok := before[p]; ok && old != h {
			return fmt.Errorf("同path別SHA")
		}
		before[p] = h
		return nil
	}
	for p, h := range c.Code {
		if e = check(FileRef102{p, h}, root); e != nil {
			return fail(e)
		}
	}
	for _, name := range []string{"main.go", "api.go", "会計.go", "信号.go", "go.mod", "go.sum"} {
		found := false
		for p := range c.Code {
			if filepath.Base(p) == name {
				found = true
			}
		}
		if !found {
			return fail(fmt.Errorf("所有code指紋欠落: %s", name))
		}
	}
	bin, e := absolute102(base, c.Binary.Path)
	if e != nil {
		return fail(e)
	}
	actual, e := filepath.Abs(executable)
	if e != nil || !strings.EqualFold(bin, actual) {
		return fail(fmt.Errorf("実行binary path不一致"))
	}
	if e = check(c.Binary, base); e != nil {
		return fail(e)
	}
	if e = check(c.InputReceipt, base); e != nil {
		return fail(e)
	}
	receiptPath, e := absolute102(base, c.InputReceipt.Path)
	if e != nil {
		return fail(e)
	}
	if e = bindInputReceipt102(receiptPath, root, c.Scenes); e != nil {
		return fail(e)
	}
	scenes := c.Scenes
	if a.Stage == "first2" {
		scenes = scenes[:2]
	}
	for _, s := range scenes {
		for _, r := range []FileRef102{s.Header, s.Records} {
			if e = check(r, base); e != nil {
				return fail(e)
			}
		}
	}
	if a.Stage == "full54" {
		if e = check(FileRef102{a.First2, a.First2SHA}, base); e != nil {
			return fail(fmt.Errorf("先頭2場: %w", e))
		}
		p, _ := absolute102(base, a.First2)
		b, e := os.ReadFile(p)
		if e != nil {
			return fail(e)
		}
		var first Completion102
		if e = strictJSON102(b, &first, true); e != nil {
			return fail(e)
		}
		if !first.Success || first.Version != 1 || first.Trial != 102 || first.Stage != "first2" || first.ConditionSHA != a.ConditionSHA || first.Scenes != 2 || first.Books != 48 || first.BooksPerScene != 24 || !first.Unchanged || !reflect.DeepEqual(first.Before, first.After) || !reflect.DeepEqual(first.Configs, c.Configs) || len(first.Results) != 2 || first.SourceReexecuted || first.ChartsRecomputed || first.RawCSVRead != 0 || first.Error != "" {
			return fail(fmt.Errorf("先頭2場の完了/条件/前後不変不一致"))
		}
		for i, r := range first.Results {
			if r.Session != c.Scenes[i].Session.ID || r.Books != 24 || r.Error != "" || len(r.Totals) != 24 {
				return fail(fmt.Errorf("先頭2場の結果集合不一致"))
			}
			for _, cfg := range c.Configs {
				v, ok := r.Totals[cfg.Name]
				if !ok || !finite102(v.Gross, v.Fee, v.Slip, v.Net) || v.Net != v.Gross-v.Fee-v.Slip || v.Positions < 0 || v.EntryQuantity < 0 || v.Active < 0 || v.Active > v.Denom || v.Denom != int((c.Scenes[i].Session.End-c.Scenes[i].Session.Start-3600)/300) {
					return fail(fmt.Errorf("先頭2場の全24集計型不正"))
				}
			}
			for _, ref := range []FileRef102{c.Scenes[i].Header, c.Scenes[i].Records} {
				if first.Before[ref.Path] != ref.SHA {
					return fail(fmt.Errorf("先頭2場の入力SHA不一致"))
				}
			}
			if e = check(FileRef102{r.Path, r.SHA}, filepath.Dir(p)); e != nil {
				return fail(e)
			}
		}
		for p, h := range before {
			if p == cp || p == bin {
				if first.Before[p] != h {
					return fail(fmt.Errorf("先頭2場との条件/実行物不一致"))
				}
			}
		}
		for p, h := range c.Code {
			abs, _ := absolute102(root, p)
			if first.Before[abs] != h {
				return fail(fmt.Errorf("先頭2場とのcode不一致"))
			}
		}
		if first.Before[receiptPath] != c.InputReceipt.SHA {
			return fail(fmt.Errorf("先頭2場との入力生成receipt不一致"))
		}
	} else if a.First2 != "" || a.First2SHA != "" {
		return fail(fmt.Errorf("first2へ先頭完了を指定できません"))
	}
	return c, scenes, before, nil
}

// readHeader102 は固定共有headerを限定型へ読み場時計を照合します。
//
// 引数: s(SceneInput102)は固定場。返り値: Header102/errorは公開入力又は破損です。
func readHeader102(s SceneInput102) (Header102, error) {
	var h Header102
	data, e := os.ReadFile(s.Header.Path)
	if e != nil {
		return h, e
	}
	if e = strictJSON102(data, &h, false); e != nil {
		return h, e
	}
	actual := Session{h.Session.ID, h.Session.Kind, h.Session.Start, h.Session.End, h.Session.Force}
	if h.Version != 1 || !h.Streamed || h.SourceReexecuted || h.FinancialExecuted || h.RowCount <= 0 || actual != s.Session {
		return h, fmt.Errorf("header版/共有型/場時計不一致")
	}
	prior := s.Session.Start - 1
	ids := map[string]bool{}
	for _, g := range h.Grids {
		if !finite102(g.At) || g.At < s.Session.Start || g.At >= s.Session.End || g.At <= prior || math.Mod(g.At-s.Session.Start, 300) != 0 || g.Kind != s.Session.Kind || g.Chart.Scene.ID != s.Session.ID || g.Chart.Scene.Start != s.Session.Start || g.SnapshotID == "" || ids[g.SnapshotID] {
			return h, fmt.Errorf("header枠の時計/識別不正")
		}
		prior = g.At
		ids[g.SnapshotID] = true
	}
	return h, nil
}

// readQuotes102 はrow.scalarだけを順序を変えずQuoteへ結びます。
//
// 引数: path(string)、s(Session)、expected(int)はrecords/場/正NK行数です。
// 返り値: []Quote/int/int/errorは全気配/不良数/control数又は破損です。
// Last0等のcontrolは新Quoteにせず、badBBOのrowは落としません。
func readQuotes102(path string, s Session, expected int) ([]Quote, int, int, error) {
	f, e := os.Open(path)
	if e != nil {
		return nil, 0, 0, e
	}
	defer f.Close()
	z, e := gzip.NewReader(f)
	if e != nil {
		return nil, 0, 0, e
	}
	defer z.Close()
	d := json.NewDecoder(z)
	quotes := make([]Quote, 0, expected)
	bad, controls := 0, 0
	for n := 0; ; n++ {
		var rec struct {
			Kind string `json:"kind"`
			Row  *struct {
				Scalar json.RawMessage `json:"scalar"`
			} `json:"row"`
			Control json.RawMessage `json:"control"`
		}
		e = d.Decode(&rec)
		if e == io.EOF {
			break
		}
		if e != nil {
			return nil, 0, 0, e
		}
		if n >= 12000000 {
			return nil, 0, 0, fmt.Errorf("records数の上限超過")
		}
		if rec.Kind == "control" {
			if rec.Row != nil || len(rec.Control) == 0 || bytes.Equal(rec.Control, []byte("null")) {
				return nil, 0, 0, fmt.Errorf("control型不正")
			}
			controls++
			continue
		}
		if rec.Kind != "row" || rec.Row == nil || len(rec.Control) > 0 {
			return nil, 0, 0, fmt.Errorf("records型不正")
		}
		var raw map[string]json.RawMessage
		if e = strictJSON102(rec.Row.Scalar, &raw, false); e != nil {
			return nil, 0, 0, e
		}
		if len(raw) != 11 {
			return nil, 0, 0, fmt.Errorf("Scalar11集合不正")
		}
		var values [8]float64
		for i, k := range []string{"time", "received", "last", "bid", "ask", "atr", "atr_available", "atr_nominal"} {
			b, ok := raw[k]
			if !ok || bytes.Equal(b, []byte("null")) {
				return nil, 0, 0, fmt.Errorf("Scalar値欠落: %s", k)
			}
			if e = json.Unmarshal(b, &values[i]); e != nil || !finite102(values[i]) {
				return nil, 0, 0, fmt.Errorf("Scalar数値不正: %s", k)
			}
		}
		var index, line int64
		var valid *bool
		if bytes.Equal(bytes.TrimSpace(raw["index"]), []byte("null")) {
			return nil, 0, 0, fmt.Errorf("Scalar indexはnullにできません")
		}
		if e = json.Unmarshal(raw["index"], &index); e != nil {
			return nil, 0, 0, e
		}
		if e = json.Unmarshal(raw["source_line"], &line); e != nil {
			return nil, 0, 0, e
		}
		if e = json.Unmarshal(raw["quote_ok"], &valid); e != nil || valid == nil {
			return nil, 0, 0, fmt.Errorf("Scalar quote_ok欠落/不正")
		}
		q := Quote{values[0], int(index), values[3], values[4], *valid}
		if int64(q.Index) != index || index < 0 || line <= 0 || values[1] != q.Time || values[2] <= 0 || q.Time < s.Start || q.Time >= s.End || len(quotes) > 0 && (q.Index <= quotes[len(quotes)-1].Index || q.Time < quotes[len(quotes)-1].Time) {
			return nil, 0, 0, fmt.Errorf("Scalar時計/Index/正NK受理列不正")
		}
		if q.Valid && (q.Bid <= 0 || q.Ask <= q.Bid) {
			return nil, 0, 0, fmt.Errorf("Scalar正常気配不整合")
		}
		if !q.Valid {
			bad++
		}
		quotes = append(quotes, q)
		if len(quotes) > expected {
			return nil, 0, 0, fmt.Errorf("header行数を超過")
		}
	}
	if len(quotes) != expected {
		return nil, 0, 0, fmt.Errorf("header行数不一致: %d != %d", len(quotes), expected)
	}
	return quotes, bad, controls, nil
}

// replayScene102 は共有入力の信号を一度ずつ作り全24条件へ渡します。
//
// 引数: s(SceneInput102)、configs([]Config)は固定場/全条件です。
// 返り値: SceneResult102/errorは全完結結果又はいずれかの失敗です。
func replayScene102(s SceneInput102, configs []Config) (SceneResult102, error) {
	out := SceneResult102{Version: 1, Trial: 102, Session: s.Session, Books: map[string]Result{}, Signals: map[string][]GridSignal102{}}
	h, e := readHeader102(s)
	if e != nil {
		return out, e
	}
	quotes, bad, controls, e := readQuotes102(s.Records.Path, s.Session, h.RowCount)
	if e != nil {
		return out, e
	}
	out.QuoteRows, out.BadQuoteRows, out.ControlRecords = len(quotes), bad, controls
	decisions := map[string][]Decision{}
	for _, policy := range []string{"S3", "S4"} {
		out.Signals[policy] = []GridSignal102{}
		for _, g := range h.Grids {
			decision, evidence, e := AssessGrid(g, policy)
			if e != nil {
				return out, fmt.Errorf("%s %.0f: %w", policy, g.At, e)
			}
			decisions[policy] = append(decisions[policy], decision)
			out.Signals[policy] = append(out.Signals[policy], GridSignal102{decision, evidence})
		}
	}
	for _, cfg := range configs {
		r := Replay(s.Session, quotes, decisions[cfg.EntryPolicy], cfg)
		if !r.Success {
			return out, fmt.Errorf("%s: %s", cfg.Name, r.Error)
		}
		out.Books[cfg.Name] = r
	}
	return out, nil
}

// writeJSON102 は既存ファイルを上書きせずJSONを保存します。
//
// 引数: path(string)、value(any)、compressed(bool)は保存先/値/gzip有無です。
// 返り値: errorは新規作成又は保存の失敗です。
func writeJSON102(path string, value any, compressed bool) error {
	f, e := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		return e
	}
	encWriter := io.Writer(f)
	var z *gzip.Writer
	if compressed {
		z = gzip.NewWriter(f)
		encWriter = z
	}
	enc := json.NewEncoder(encWriter)
	enc.SetEscapeHTML(false)
	e = enc.Encode(value)
	if z != nil {
		if ze := z.Close(); e == nil {
			e = ze
		}
	}
	if fe := f.Close(); e == nil {
		e = fe
	}
	return e
}

// run102 は固定入力の全事前検査後に最大4場を並列実行します。
//
// 引数: a(Args102)、root/executable(string)はCLI設定と明示実行環境です。
// 返り値: Completion102/errorは新規完了記録又は失敗です。失敗記録を成功へ変換しません。
func run102(a Args102, root, executable string) (Completion102, error) {
	proof := Completion102{Version: 1, Trial: 102, Stage: a.Stage, ConditionSHA: a.ConditionSHA, BooksPerScene: 24}
	c, scenes, before, e := prepare102(a, root, executable)
	if e != nil {
		return proof, e
	}
	proof.Before = before
	proof.Configs = c.Configs
	proof.Scenes = len(scenes)
	if a.Stage == "full54" {
		p, _ := absolute102(filepath.Dir(a.Condition), a.First2)
		proof.First2 = &FileRef102{p, a.First2SHA}
	}
	out, e := filepath.Abs(a.Out)
	if e != nil || a.Out == "" {
		return proof, fmt.Errorf("新規出力先が必要")
	}
	if _, e = os.Stat(out); !os.IsNotExist(e) {
		return proof, fmt.Errorf("既存又は不正な出力先")
	}
	if e = os.MkdirAll(filepath.Dir(out), 0700); e != nil {
		return proof, e
	}
	if e = os.Mkdir(out, 0700); e != nil {
		return proof, e
	}
	jobs := make(chan SceneInput102)
	results := make(chan SceneReceipt102)
	var wg sync.WaitGroup
	for worker := 0; worker < a.Workers; worker++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for s := range jobs {
				entry := SceneReceipt102{Session: s.Session.ID}
				r, e := replayScene102(s, c.Configs)
				if e == nil {
					entry.Path = filepath.Join(out, s.Session.ID+".json.gz")
					e = writeJSON102(entry.Path, r, true)
				}
				if e == nil {
					entry.SHA, e = fileSHA102(entry.Path)
				}
				if e != nil {
					entry.Error = e.Error()
				} else {
					entry.Books = len(r.Books)
					entry.Totals = map[string]Totals102{}
					for key, b := range r.Books {
						qty := 0
						for _, t := range b.Trades {
							qty += t.Qty
						}
						entry.Totals[key] = Totals102{b.Gross, b.Fee, b.Slip, b.Net, b.PosCount, qty, b.Denom, b.Active}
					}
				}
				results <- entry
			}
		}()
	}
	go func() {
		for _, s := range scenes {
			jobs <- s
		}
		close(jobs)
		wg.Wait()
		close(results)
	}()
	proof.Results = []SceneReceipt102{}
	for r := range results {
		proof.Results = append(proof.Results, r)
		proof.Books += r.Books
		if r.Error != "" && proof.Error == "" {
			proof.Error = r.Session + ": " + r.Error
		}
		fmt.Fprintf(os.Stderr, "%d/%d %s 口座%d %s\n", len(proof.Results), len(scenes), r.Session, r.Books, r.Error)
	}
	sort.Slice(proof.Results, func(i, j int) bool { return proof.Results[i].Session < proof.Results[j].Session })
	proof.After = map[string]string{}
	for path := range before {
		h, he := fileSHA102(path)
		if he != nil && proof.Error == "" {
			proof.Error = he.Error()
		}
		proof.After[path] = h
	}
	proof.Unchanged = reflect.DeepEqual(proof.Before, proof.After)
	if !proof.Unchanged && proof.Error == "" {
		proof.Error = "実行前後の入力/code指紋不一致"
	}
	proof.Success = proof.Error == "" && proof.Books == len(scenes)*24
	if e = writeJSON102(filepath.Join(out, "完了.json"), proof, false); e != nil {
		return proof, e
	}
	if !proof.Success {
		return proof, fmt.Errorf("%s", proof.Error)
	}
	return proof, nil
}

// main は明示固定条件と新規出力先だけを受け付けます。
//
// 引数: CLI引数。返り値: なし。未固定・未完結・指紋差は終了1です。
func main() {
	a := Args102{}
	flag.StringVar(&a.Condition, "condition", "", "固定条件JSON")
	flag.StringVar(&a.ConditionSHA, "condition-sha", "", "固定条件SHA256")
	flag.StringVar(&a.Stage, "stage", "first2", "first2/full54")
	flag.StringVar(&a.Out, "out", "", "新規出力directory")
	flag.StringVar(&a.First2, "first2", "", "同条件first2完了JSON")
	flag.StringVar(&a.First2SHA, "first2-sha", "", "first2完了SHA256")
	flag.IntVar(&a.Workers, "workers", 1, "並列場数1..4")
	flag.Parse()
	if flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "未定義の位置引数")
		os.Exit(1)
	}
	root, e := repoRoot102()
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	exe, e := os.Executable()
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	proof, e := run102(a, root, exe)
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	fmt.Printf("成功 %s %d場 %d口座\n", proof.Stage, proof.Scenes, proof.Books)
}
