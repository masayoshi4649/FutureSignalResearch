package main

import (
	"fmt"
	"math"
	"reflect"

	warm "github.com/masayoshi4649/SessionTradeExecuter/chartwarmup96"
	chart "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	far80 "github.com/masayoshi4649/SessionTradeExecuter/research80"
	far81 "github.com/masayoshi4649/SessionTradeExecuter/research81"
)

// SignalVote は、支持なしと未観測を区別した一票です。
//
// Known/Passed はbool、IDは役割を示すstringです。
type SignalVote struct {
	ID     string `json:"id"`
	Known  bool   `json:"known"`
	Passed bool   `json:"passed"`
}

// SideSignal は、方向別の確定支持数と可能上限を保持します。
//
// Lower/Upper はint、役割と採用のKnown/Possibleはboolです。
type SideSignal struct {
	Side          int          `json:"side"`
	Lower         int          `json:"lower"`
	Upper         int          `json:"upper"`
	Votes         []SignalVote `json:"votes"`
	TrendKnown    bool         `json:"trend_known"`
	Trend         bool         `json:"trend"`
	ReversalKnown bool         `json:"reversal_known"`
	Reversal      bool         `json:"reversal"`
	Eligible      bool         `json:"eligible"`
	Possible      bool         `json:"possible"`
}

// SignalEvidence は、全8票と両方向の判断出典を保持します。
//
// 得点は相関した指標の段階支持数で、校正確率ではありません。
type SignalEvidence struct {
	Policy       string     `json:"policy"`
	Threshold    int        `json:"threshold"`
	InputID      string     `json:"input_id"`
	QualityKnown bool       `json:"quality_known"`
	Buy          SideSignal `json:"buy"`
	Sell         SideSignal `json:"sell"`
}

type signalTruth struct{ known, passed bool }

// signalAnd は、既知否定を優先する三値ANDです。
//
// 引数: values(...signalTruth)は条件列。返り値: signalTruthは論理値です。
func signalAnd(values ...signalTruth) signalTruth {
	known := true
	for _, v := range values {
		if v.known && !v.passed {
			return signalTruth{true, false}
		}
		known = known && v.known
	}
	return signalTruth{known, known}
}

// signalOr は、既知成立を優先する三値ORです。
//
// 引数: values(...signalTruth)は条件列。返り値: signalTruthは論理値です。
func signalOr(values ...signalTruth) signalTruth {
	known := true
	for _, v := range values {
		if v.known && v.passed {
			return signalTruth{true, true}
		}
		known = known && v.known
	}
	return signalTruth{known, false}
}

// signalFinite は、公開型内の全floatとmap/sliceの非有限を拒否します。
//
// 引数: v(reflect.Value)は公開入力。返り値: boolは全値が有限なら真です。
func signalFinite(v reflect.Value) bool {
	switch v.Kind() {
	case reflect.Float32, reflect.Float64:
		return !math.IsNaN(v.Float()) && !math.IsInf(v.Float(), 0)
	case reflect.Struct:
		for i := 0; i < v.NumField(); i++ {
			if !signalFinite(v.Field(i)) {
				return false
			}
		}
	case reflect.Slice, reflect.Array:
		for i := 0; i < v.Len(); i++ {
			if !signalFinite(v.Index(i)) {
				return false
			}
		}
	case reflect.Map:
		it := v.MapRange()
		for it.Next() {
			if !signalFinite(it.Value()) {
				return false
			}
		}
	case reflect.Pointer, reflect.Interface:
		if !v.IsNil() {
			return signalFinite(v.Elem())
		}
	}
	return true
}

// signalTechnical は、既知性を推測せず指標の範囲破損を拒否します。
//
// 引数: t(far80.TechnicalView)は公開値。返り値: errorは価格/RSI/ATRの破損です。
func signalTechnical(t far80.TechnicalView) error {
	if t.Bar3End < 0 || t.Bar15End < 0 || t.Close3 < 0 || t.EMA8_3 < 0 || t.EMA21_3 < 0 || t.EMA8_15 < 0 || t.EMA21_15 < 0 || t.TR3 < 0 || t.ATR3 < 0 || t.PreviousATR3 < 0 || t.RSI3 < 0 || t.RSI3 > 100 || t.PreviousRSI3 < 0 || t.PreviousRSI3 > 100 {
		return fmt.Errorf("価格/ATR/RSI範囲が不正です")
	}
	if t.TrendKnown && (t.EMA8_3 <= 0 || t.EMA21_3 <= 0 || t.EMA8_15 <= 0 || t.EMA21_15 <= 0) || (t.ExitKnown || t.ReversalKnown) && (t.EMA8_3 <= 0 || t.Close3 <= 0) || t.SpikeKnown && t.Close3 <= 0 || t.ATRKnown && t.ATR3 <= 0 {
		return fmt.Errorf("既知指標の価格/ATRが不正です")
	}
	return nil
}

// signalSnapshot は、論理公表と価格出典を検査し観測上限を区別します。
//
// 引数: s(warm.Snapshot)、at(float64)は公開値と査定時計。返り値: errorは未来/出典破損です。
func signalSnapshot(s warm.Snapshot, at float64) error {
	if s.At < 0 || s.At > at || s.Scene.ID == "" || s.Scene.Contract == "" || s.Scene.Start <= 0 || s.Scene.Start > s.At || s.InvalidatedAt < 0 || s.InvalidatedAt > s.At || s.Chart.Technical.Bar3End > s.At || s.Chart.Technical.Bar15End > s.At || s.ObservedClock < 0 || s.HasObservedClock && s.ObservedClock < s.At {
		return fmt.Errorf("場/公開時計/観測上限が不正です")
	}
	if err := signalTechnical(s.Chart.Technical); err != nil {
		return err
	}
	if s.HasLastInput && (s.LastInput.Time <= 0 || s.LastInput.Time > s.At || s.LastInput.Index < 0 || s.LastInput.Line <= 0 || s.LastInput.Last < 0 || s.LastInput.Valid && s.LastInput.Last <= 0) {
		return fmt.Errorf("最終価格出典が未来又は不正です")
	}
	for i, e := range []warm.BarEvidence{s.Three, s.Fifteen} {
		width := 180.0
		if i == 1 {
			width = 900
		}
		if e.BarEnd < 0 || e.AvailableAt < 0 || e.BarEnd > s.At || e.AvailableAt > s.At || e.BarEnd > e.AvailableAt || e.ObservedClock < 0 || e.Rows < 0 || (e.Rows > 0) != e.HasLastSource || e.DataKnown && (e.BarEnd <= 0 || e.Rows == 0 || !e.HasLastSource) || e.BarEnd > 0 && (!s.HasObservedClock || e.ObservedClock < e.AvailableAt) {
			return fmt.Errorf("確定足の公開/行数が不正です")
		}
		if e.HasLastSource && (e.LastSource.Time < math.Max(s.Scene.Start, e.BarEnd-width) || e.LastSource.Time >= e.BarEnd || e.LastSource.Index < 0 || e.LastSource.Line <= 0 || e.LastSource.Last < 0 || e.DataKnown && (!e.LastSource.Valid || e.LastSource.Last <= 0)) {
			return fmt.Errorf("確定足の半開区間と原行が不一致です")
		}
	}
	if s.Three.BarEnd != s.Chart.Technical.Bar3End || s.Fifteen.BarEnd != s.Chart.Technical.Bar15End {
		return fmt.Errorf("足の終端と指標が不一致です")
	}
	v := s.Chart
	if v.PreviousBar3End < 0 || v.PreviousBar3End > s.At || v.PreviousClose3 < 0 || v.PreviousEMA8_3 < 0 || v.Previous3Known && (v.PreviousClose3 <= 0 || v.PreviousEMA8_3 <= 0 || v.Technical.Bar3End-v.PreviousBar3End != 180) {
		return fmt.Errorf("前3分の出典が不正です")
	}
	return nil
}

// validateSignalInput は、Source候補を作らず公開チャートと現在値を検査します。
//
// 引数: in(chart.TechnicalGateInput)は全5分入力。返り値: errorは型で表現された破損です。
func validateSignalInput(in chart.TechnicalGateInput) error {
	if !signalFinite(reflect.ValueOf(in)) || in.SnapshotID == "" || in.At <= 0 || math.Mod(in.At, 300) != 0 || in.Chart.At != in.At || (in.Kind != "Day" && in.Kind != "Night") {
		return fmt.Errorf("定時入力の有限値/識別/5分時計が不正です")
	}
	if err := signalSnapshot(in.Chart, in.At); err != nil {
		return err
	}
	c := in.Current
	if c.Reference != "" && c.Reference != "NK225" || c.Time < 0 || c.Time > in.At || c.Received < 0 || c.SourceLine < 0 || c.Time > 0 && (c.SourceIndex < 0 || c.SourceLine <= 0) || c.Last < 0 || c.Bid < 0 || c.Ask < 0 {
		return fmt.Errorf("現在価格の時計/出典が不正です")
	}
	for _, v := range []struct{ own, peer float64 }{{c.Buy.OwnAt, c.Buy.PeerAt}, {c.Sell.OwnAt, c.Sell.PeerAt}} {
		if v.own < 0 || v.peer < 0 || v.own > c.Time || v.peer > c.Time {
			return fmt.Errorf("数量の価格出典が未来です")
		}
	}
	for _, windows := range []map[string]far81.CurrentSupportWindow{c.Buy.Windows, c.Sell.Windows} {
		for _, w := range windows {
			if w.CurrentAt < 0 || w.EndpointAt < 0 || w.CurrentAt > c.Time || w.EndpointAt > c.Time {
				return fmt.Errorf("数量窓が未来です")
			}
		}
	}
	n := c.Night
	if n.Time < 0 || n.Time > c.Time || n.Band.Time < 0 || n.Band.Time > c.Time || n.Band.StartTime < 0 || n.Band.StartTime > c.Time || n.Index > c.SourceIndex || n.Band.Index > c.SourceIndex || n.Band.StartIndex > c.SourceIndex {
		return fmt.Errorf("夜間数量の出典が未来です")
	}
	for _, h := range []far81.CurrentPriceBand{n.Buy, n.Sell} {
		if h.Time < 0 || h.Time > c.Time || h.Barrier.Time < 0 || h.Barrier.Time > c.Time || h.Support.Time < 0 || h.Support.Time > c.Time || h.Index > c.SourceIndex || h.Barrier.Index > c.SourceIndex || h.Support.Index > c.SourceIndex || h.PressureIndex > c.SourceIndex {
			return fmt.Errorf("夜間帯の出典が未来です")
		}
	}
	for _, q := range []float64{n.Band.BidRefill, n.Band.AskRefill, n.Band.BidDeplete, n.Band.AskDeplete, n.Band.CommonBidUp, n.Band.CommonAskUp, n.Band.CommonBidDown, n.Band.CommonAskDown} {
		if q < 0 {
			return fmt.Errorf("数量成分が負です")
		}
	}
	if c.Short.Time < 0 || c.Short.Time > c.Time || c.Short.Five.Endpoint < 0 || c.Short.Five.Endpoint > c.Time || c.Short.Fifteen.Endpoint < 0 || c.Short.Fifteen.Endpoint > c.Time {
		return fmt.Errorf("短秒の価格出典が未来です")
	}
	if len(in.Recent3) > 3 {
		return fmt.Errorf("Recent3の数が不正です")
	}
	for i, s := range in.Recent3 {
		if err := signalSnapshot(s, in.At); err != nil {
			return err
		}
		if s.Scene != in.Chart.Scene || s.At != s.Three.BarEnd || i > 0 && s.At <= in.Recent3[i-1].At || s.HasObservedClock && (!in.Chart.HasObservedClock || s.ObservedClock > in.Chart.ObservedClock) {
			return fmt.Errorf("Recent3の場/公表順/観測上限が不正です")
		}
	}
	if len(in.Recent3) > 0 {
		c := in.Recent3[len(in.Recent3)-1]
		t, u := in.Chart.Chart.Technical, c.Chart.Technical
		if c.Three.BarEnd == in.Chart.Three.BarEnd && t.ExitKnown && t.TrendKnown && t.SpikeKnown && t.ATRKnown && (t.Close3 != u.Close3 || t.EMA8_3 != u.EMA8_3 || t.EMA21_3 != u.EMA21_3 || t.Histogram3 != u.Histogram3 || t.PreviousHistogram3 != u.PreviousHistogram3 || t.RSI3 != u.RSI3 || t.ATR3 != u.ATR3) {
			return fmt.Errorf("最新公開足と現在指標が不一致です")
		}
	}
	if len(in.Recent3) >= 2 {
		r := in.Recent3
		p, c := r[len(r)-2], r[len(r)-1]
		t, u := in.Chart.Chart.Technical, p.Chart.Technical
		if c.At == t.Bar3End && c.At-p.At == 180 && p.Three.DataKnown && c.Three.DataKnown {
			if t.ExitKnown && u.ExitKnown && t.PreviousHistogram3 != u.Histogram3 || t.SpikeKnown && u.SpikeKnown && t.PreviousRSI3 != u.RSI3 || t.ATRKnown && u.ATRKnown && t.PreviousATR3 != u.ATR3 {
				return fmt.Errorf("指標前値と連続前足が不一致です")
			}
			if in.Chart.Chart.Previous3Known && (in.Chart.Chart.PreviousClose3 != u.Close3 || in.Chart.Chart.PreviousEMA8_3 != u.EMA8_3) {
				return fmt.Errorf("前3分追跡と連続公開足が不一致です")
			}
		}
	}
	return nil
}

// signalQuality は、ウォームアップ不足と正常な既知性を分けます。
//
// 引数: in(chart.TechnicalGateInput)は検査済み入力。返り値: boolは必要品質の充足です。
func signalQuality(in chart.TechnicalGateInput) bool {
	c, s := in.Current, in.Chart
	t := s.Chart.Technical
	return c.Reference == "NK225" && c.Time > 0 && c.Last > 0 && c.Bid > 0 && c.Ask > c.Bid && in.At-c.Time <= 15 && s.Three.DataKnown && s.Fifteen.DataKnown && t.Bar3End > 0 && in.At-t.Bar3End < 180 && t.Bar15End > 0 && in.At-t.Bar15End < 900 && t.TrendKnown && t.ExitKnown && t.SpikeKnown && t.ATRKnown && t.ATR3 > 0
}

// signalVolume は、Day/Night別の公開数量を方向へ符号付けします。
//
// 引数: in(chart.TechnicalGateInput)、side(int)。返り値: signalTruthは既知支持です。
func signalVolume(in chart.TechnicalGateInput, side int) signalTruth {
	c := in.Current
	s := float64(side)
	if in.Kind == "Day" {
		v := c.Buy
		if side < 0 {
			v = c.Sell
		}
		known := v.OFIKnown && v.OwnAt == c.Time
		return signalTruth{known, known && s*v.OFI30 > 0}
	}
	n, v := c.Night, c.Night.Band
	known := n.Available && n.Window == "E08" && v.QuantityKnown && v.Time == c.Time && v.Index == c.SourceIndex
	return signalTruth{known, known && s*(v.BidRefill+v.AskDeplete-v.AskRefill-v.BidDeplete) > 0}
}

// signalReversal は、成功足へ付替えず最新連続3足の固定線奪還を判定します。
//
// 引数: in(chart.TechnicalGateInput)、side(int)。返り値: signalTruthは構造だけの三値です。
func signalReversal(in chart.TechnicalGateInput, side int) signalTruth {
	if len(in.Recent3) != 3 {
		return signalTruth{}
	}
	for i, p := range in.Recent3 {
		if !p.Three.DataKnown || i > 0 && p.At-in.Recent3[i-1].At != 180 {
			return signalTruth{}
		}
	}
	a, b, c := in.Recent3[0].Chart.Technical, in.Recent3[1].Chart.Technical, in.Recent3[2].Chart.Technical
	if in.Recent3[2].At != in.Chart.Chart.Technical.Bar3End || !(a.TrendKnown || a.ExitKnown || a.ReversalKnown) || a.Close3 <= 0 || b.Close3 <= 0 || c.Close3 <= 0 {
		return signalTruth{}
	}
	s, L := float64(side), a.EMA8_3
	return signalTruth{true, s*(a.Close3-L) <= 0 && s*(b.Close3-L) > 0 && s*(c.Close3-L) > 0 && s*(c.Close3-b.Close3) > 0}
}

// scoreSignal は、8票と役割の下限/上限から一方向の採用可能性を作ります。
//
// 引数: in(chart.TechnicalGateInput)、side/threshold(int)。返り値: SideSignalは全根拠です。
func scoreSignal(in chart.TechnicalGateInput, side, threshold int) SideSignal {
	s, v := float64(side), in.Chart.Chart
	t := v.Technical
	entry := in.Current.Ask
	if side < 0 {
		entry = in.Current.Bid
	}
	previous := v.Previous3Known && t.Bar3End-v.PreviousBar3End == 180
	values := []signalTruth{{true, s*(t.EMA8_3-t.EMA21_3) > 0}, {true, s*(t.EMA8_15-t.EMA21_15) > 0}, {previous, previous && s*(t.EMA8_3-v.PreviousEMA8_3) > 0}, {true, s*(t.Histogram3-t.PreviousHistogram3) > 0}, {true, s*(t.RSI3-50) > 0 && s*(t.RSI3-t.PreviousRSI3) >= 0}, {previous, previous && s*(t.Close3-v.PreviousClose3) > 0 && s*(t.Close3-t.EMA8_3) > 0}, {true, s*(entry-t.EMA8_3) >= 0 && s*(entry-t.EMA8_3) <= t.ATR3}, signalVolume(in, side)}
	ids := []string{"3分EMA方向", "15分EMA方向", "3分EMA傾き", "MACD増分", "RSI持続", "価格構造", "取得位置ATR", "現在数量"}
	out := SideSignal{Side: side, Votes: []SignalVote{}}
	for i, x := range values {
		out.Votes = append(out.Votes, SignalVote{ids[i], x.known, x.known && x.passed})
		if x.known && x.passed {
			out.Lower++
		}
		if !x.known || x.passed {
			out.Upper++
		}
	}
	tRole := signalAnd(signalOr(values[0], values[1]), signalOr(values[2], values[3], values[4]))
	rRole := signalAnd(signalReversal(in, side), signalOr(values[3], values[4]))
	out.TrendKnown, out.Trend = tRole.known, tRole.known && tRole.passed
	out.ReversalKnown, out.Reversal = rRole.known, rRole.known && rRole.passed
	role := signalOr(tRole, rRole)
	out.Eligible = role.known && role.passed && out.Lower >= threshold
	out.Possible = (!role.known || role.passed) && out.Upper >= threshold
	return out
}

// selectSignal は、未知上限による逆転を排除できる勝者だけを返します。
//
// 引数: buy/sell(SideSignal)は両側評価。返り値: side/score(int)、known(bool)、reason(string)。
func selectSignal(buy, sell SideSignal) (int, int, bool, string) {
	if buy.Eligible && (!sell.Possible || buy.Lower > sell.Upper) {
		return 1, buy.Lower, true, "買いの支持下限が反対側可能上限を上回る"
	}
	if sell.Eligible && (!buy.Possible || sell.Lower > buy.Upper) {
		return -1, sell.Lower, true, "売りの支持下限が反対側可能上限を上回る"
	}
	if !buy.Possible && !sell.Possible {
		return 0, 0, true, "両方向が既知不成立"
	}
	if buy.Eligible && sell.Eligible && buy.Lower == buy.Upper && sell.Lower == sell.Upper && buy.Lower == sell.Lower {
		return 0, 0, true, "両方向同点のため待機"
	}
	return 0, 0, false, "未知票又は役割で勝者が変わり得る"
}

// AssessHeldGrid は、実保有方向ごとの収束と複合失速を公開値から判定します。
//
// 引数: in(chart.TechnicalGateInput)、side(int)は公開入力と保有方向。返り値: ProtectionState/error。
func AssessHeldGrid(in chart.TechnicalGateInput, side int) (ProtectionState, error) {
	if side != 1 && side != -1 {
		return ProtectionState{}, fmt.Errorf("保有方向は±1です")
	}
	if err := validateSignalInput(in); err != nil {
		return ProtectionState{}, err
	}
	if !signalQuality(in) || len(in.Recent3) < 2 {
		return ProtectionState{}, nil
	}
	r := in.Recent3
	p, c := r[len(r)-2], r[len(r)-1]
	t := in.Chart.Chart.Technical
	if c.At != t.Bar3End || c.At-p.At != 180 || !p.Three.DataKnown || !c.Three.DataKnown || !p.Chart.Technical.TrendKnown || !p.Chart.Technical.ATRKnown || !p.Chart.Technical.ExitKnown || p.Chart.Technical.ATR3 <= 0 {
		return ProtectionState{}, nil
	}
	prior := p.Chart.Technical
	s := float64(side)
	nowWidth := math.Abs(t.EMA8_3-t.EMA21_3) / t.ATR3
	oldWidth := math.Abs(prior.EMA8_3-prior.EMA21_3) / prior.ATR3
	converged := nowWidth < oldWidth && t.ATR3 <= prior.ATR3 && s*t.Histogram3 >= 0 && s*t.Histogram3 < s*t.PreviousHistogram3
	stalled := s*(t.Close3-t.EMA8_3) < 0 && s*(t.Histogram3-t.PreviousHistogram3) < 0
	return ProtectionState{Known: true, Converged: converged, Stalled: stalled}, nil
}

// AssessGrid は、Sourceなしの両方向を評価し全票と純Decisionを返します。
//
// 引数: in(chart.TechnicalGateInput)、policy(string)はS3/S4。返り値: Decision/SignalEvidence/error。
func AssessGrid(in chart.TechnicalGateInput, policy string) (Decision, SignalEvidence, error) {
	threshold := 3
	if policy == "S4" {
		threshold = 4
	} else if policy != "S3" {
		return Decision{}, SignalEvidence{}, fmt.Errorf("入口政策はS3/S4です")
	}
	if err := validateSignalInput(in); err != nil {
		return Decision{}, SignalEvidence{}, err
	}
	d := Decision{At: in.At, AvailableAt: math.Max(in.At, math.Max(in.Chart.ObservedClock, in.Current.Received))}
	e := SignalEvidence{Policy: policy, Threshold: threshold, InputID: in.SnapshotID, QualityKnown: signalQuality(in)}
	var err error
	d.BuyProtection, err = AssessHeldGrid(in, 1)
	if err != nil {
		return d, e, err
	}
	d.SellProtection, err = AssessHeldGrid(in, -1)
	if err != nil {
		return d, e, err
	}
	if in.Chart.Chart.Technical.ATRKnown {
		d.ATR = in.Chart.Chart.Technical.ATR3
	}
	if !e.QualityKnown {
		d.Reason = "現在価格/公開3・15分/指標の品質又は助走が未知"
		return d, e, nil
	}
	e.Buy = scoreSignal(in, 1, threshold)
	e.Sell = scoreSignal(in, -1, threshold)
	var score int
	d.Side, score, d.Known, d.Reason = selectSignal(e.Buy, e.Sell)
	if d.Side != 0 {
		d.Qty = 2
		if score >= 4 {
			d.Qty = 4
		}
		if score >= 5 {
			d.Qty = 6
		}
	}
	return d, e, nil
}

// DecideGrid は、詳細証拠を別保存する呼出側へ最小Decisionを返します。
//
// 引数: in(chart.TechnicalGateInput)、policy(string)。返り値: Decision/errorは純査定結果です。
func DecideGrid(in chart.TechnicalGateInput, policy string) (Decision, error) {
	d, _, err := AssessGrid(in, policy)
	return d, err
}
