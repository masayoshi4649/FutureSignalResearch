package main

// Quote は、実在する原行の気配と時計を保持します。
//
// Time は秒、Index は単調増加する原行番号、Valid は気配品質です。
// Bid/Ask の価格へ仮定滑りを重ねず、費用は別会計へ記録します。
type Quote struct {
	Time  float64 `json:"time"`
	Index int     `json:"index"`
	Bid   float64 `json:"bid"`
	Ask   float64 `json:"ask"`
	Valid bool    `json:"valid"`
}

// Decision は、定時に公開済みのチャート判断を保持します。
//
// At/AvailableAt は判断秒と公表秒、Side は売買符号、Qty は希望枚数です。
// ATR は価格単位、保護状態は実保有方向ごとに独立して評価します。
type Decision struct {
	At             float64         `json:"at"`
	AvailableAt    float64         `json:"available_at"`
	Side           int             `json:"side"`
	Qty            int             `json:"qty"`
	ATR            float64         `json:"atr"`
	Known          bool            `json:"known"`
	Reason         string          `json:"reason"`
	BuyProtection  ProtectionState `json:"buy_protection"`
	SellProtection ProtectionState `json:"sell_protection"`
}

// ProtectionState は、実保有方向の収束・失速の既知性を保持します。
//
// Known=false を反対化とせず、その枠では既存床を維持します。
type ProtectionState struct {
	Known     bool `json:"known"`
	Converged bool `json:"converged"`
	Stalled   bool `json:"stalled"`
}

// Session は、建玉を持ち越さない一場の時計を保持します。
//
// Start/End/Force は秒、Kind は Day 又は Night です。
type Session struct {
	ID    string  `json:"id"`
	Kind  string  `json:"kind"`
	Start float64 `json:"start"`
	End   float64 `json:"end"`
	Force float64 `json:"force"`
}

// Config は、事前固定する入口・追尾・費用・遅延を保持します。
//
// Slip は片道価格単位、Delay は最低約定遅延秒です。
type Config struct {
	Name        string  `json:"name"`
	EntryPolicy string  `json:"entry_policy"`
	TrailPolicy string  `json:"trail_policy"`
	Slip        float64 `json:"slip"`
	Delay       float64 `json:"delay"`
}

// Order は、原行へ結合した全量成行の要求と取消を保持します。
//
// RequestIndex は要求時に最後に受理した原行で、同じ原行で約定しません。
type Order struct {
	ID           string  `json:"id"`
	PositionID   string  `json:"position_id"`
	Kind         string  `json:"kind"`
	Side         int     `json:"side"`
	Qty          int     `json:"qty"`
	At           float64 `json:"at"`
	GridAt       float64 `json:"grid_at"`
	RequestIndex int     `json:"request_index"`
	ExpiresAt    float64 `json:"expires_at,omitempty"`
	Reason       string  `json:"reason"`
	Status       string  `json:"status"`
	CancelAt     float64 `json:"cancel_at,omitempty"`
}

// Fill は、実気配価格と別会計費用による一約定を保持します。
//
// Fee/Slip は円、Price は買Ask又は売Bidそのものです。
type Fill struct {
	OrderID    string  `json:"order_id"`
	PositionID string  `json:"position_id"`
	Kind       string  `json:"kind"`
	Side       int     `json:"side"`
	Qty        int     `json:"qty"`
	Quote      Quote   `json:"quote"`
	Price      float64 `json:"price"`
	Fee        float64 `json:"fee"`
	Slip       float64 `json:"slip"`
}

// Trade は、一実建玉の取得から全返済までの実会計を保持します。
//
// 床と起動の履歴は当時値だけを記録し、退出後価格を参照しません。
type Trade struct {
	ID              string  `json:"id"`
	Side            int     `json:"side"`
	Qty             int     `json:"qty"`
	Entry           Fill    `json:"entry"`
	Exit            Fill    `json:"exit"`
	EntryATR        float64 `json:"entry_atr"`
	InitialStop     float64 `json:"initial_stop"`
	ActivationAt    float64 `json:"activation_at,omitempty"`
	ActivationIndex int     `json:"activation_index,omitempty"`
	ActivationUnit  float64 `json:"activation_unit_points,omitempty"`
	Activated       bool    `json:"activated"`
	HadPositiveUnit bool    `json:"had_positive_unit"`
	FirstPositiveAt float64 `json:"first_positive_at,omitempty"`
	FinalFloor      float64 `json:"final_floor"`
	Gross           float64 `json:"gross"`
	Fee             float64 `json:"fee"`
	Slip            float64 `json:"slip"`
	Net             float64 `json:"net"`
	ExitReason      string  `json:"exit_reason"`
}

// GridRecord は、欠測も除外しない一判断枠の分類を保持します。
//
// Action は new/hold/wait/unknown、Pending は未取得注文の予約枚数です。
type GridRecord struct {
	At       float64  `json:"at"`
	Action   string   `json:"action"`
	Reason   string   `json:"reason"`
	Decision Decision `json:"decision"`
	Quantity int      `json:"quantity"`
	Pending  int      `json:"pending"`
}

// Result は、一場の実会計と定時分類を分離して返します。
//
// Success=false の出力は不完結又は入力不正で、成績として採用しません。
type Result struct {
	Success            bool          `json:"success"`
	Error              string        `json:"error,omitempty"`
	Session            Session       `json:"session"`
	Config             Config        `json:"config"`
	Orders             []Order       `json:"orders"`
	Fills              []Fill        `json:"fills"`
	Trades             []Trade       `json:"trades"`
	Grids              []GridRecord  `json:"grids"`
	Gross              float64       `json:"gross"`
	Fee                float64       `json:"fee"`
	Slip               float64       `json:"slip"`
	Net                float64       `json:"net"`
	DD                 float64       `json:"dd"`
	PosCount           int           `json:"poscount"`
	Active             int           `json:"active"`
	Hold               int           `json:"hold"`
	New                int           `json:"new"`
	Wait               int           `json:"wait"`
	Unknown            int           `json:"unknown"`
	Denom              int           `json:"denom"`
	Participation      float64       `json:"participation"`
	OpenQuantity       int           `json:"open_quantity"`
	PendingEntry       int           `json:"pending_entry"`
	PendingExit        int           `json:"pending_exit"`
	ActivatedPositions int           `json:"activated_positions"`
	EquityPoints       []EquityPoint `json:"equity_points"`
	PeakEquity         float64       `json:"peak_equity"`
	MinEquity          float64       `json:"min_equity"`
}

// EquityPoint は、逐次口座評価の峰・谷・最大DD更新・場末を保持します。
//
// Equity は実現純額と保有返済評価の合計円で、Phase は同原行内順序です。
type EquityPoint struct {
	At     float64 `json:"at"`
	Index  int     `json:"index"`
	Phase  string  `json:"phase"`
	Kind   string  `json:"kind"`
	Equity float64 `json:"equity"`
}
