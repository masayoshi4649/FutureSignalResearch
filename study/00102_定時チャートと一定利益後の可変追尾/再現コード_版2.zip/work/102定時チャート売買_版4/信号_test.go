package main

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"

	warm "github.com/masayoshi4649/SessionTradeExecuter/chartwarmup96"
	chart "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	far80 "github.com/masayoshi4649/SessionTradeExecuter/research80"
)

// signalFixture は、Sourceを含まない公開型の買い人工を作ります。
//
// 引数: なし。返り値: chart.TechnicalGateInputは価格/数量/指標手製の器具です。
func signalFixture() chart.TechnicalGateInput {
	scene := warm.Scene{ID: "人工102", Contract: "人工限月", Start: 300}
	t := far80.TechnicalView{TrendKnown: true, ExitKnown: true, SpikeKnown: true, ATRKnown: true, EMA8_3: 1000, EMA21_3: 990, EMA8_15: 1000, EMA21_15: 980, Close3: 1010, Histogram3: 2, PreviousHistogram3: 1, RSI3: 60, PreviousRSI3: 59, ATR3: 20, PreviousATR3: 22, TR3: 10, Bar3End: 2880, Bar15End: 2700}
	snapshot := func(at float64, v far80.TechnicalView) warm.Snapshot {
		p := warm.Snapshot{Scene: scene, At: at, HasObservedClock: true, ObservedClock: 3001, HasLastInput: true, LastInput: warm.SourceStamp{Time: at - 1, Index: 80, Line: 80, Last: v.Close3, Valid: true}}
		p.Chart.Technical = v
		p.Three = warm.BarEvidence{BarEnd: v.Bar3End, AvailableAt: v.Bar3End, ObservedClock: 3001, Rows: 1, DataKnown: true, HasLastSource: true, LastSource: warm.SourceStamp{Time: v.Bar3End - 1, Index: 70, Line: 70, Last: v.Close3, Valid: true}}
		p.Fifteen = warm.BarEvidence{BarEnd: v.Bar15End, AvailableAt: v.Bar15End, ObservedClock: 3001, Rows: 1, DataKnown: true, HasLastSource: true, LastSource: warm.SourceStamp{Time: v.Bar15End - 1, Index: 60, Line: 60, Last: v.Close3, Valid: true}}
		return p
	}
	in := chart.TechnicalGateInput{SnapshotID: "人工102-G1", At: 3000, Kind: "Day", Chart: snapshot(3000, t)}
	in.Chart.Chart.Previous3Known = true
	in.Chart.Chart.PreviousBar3End = 2700
	in.Chart.Chart.PreviousClose3 = 1005
	in.Chart.Chart.PreviousEMA8_3 = 995
	in.Current.Reference = "NK225"
	in.Current.Time = 2999
	in.Current.Received = 3002
	in.Current.SourceIndex = 50
	in.Current.SourceLine = 100
	in.Current.Last = 1010
	in.Current.Bid = 1009
	in.Current.Ask = 1011
	in.Current.Buy.OwnAt = 2999
	in.Current.Sell.OwnAt = 2999
	in.Current.Buy.OFIKnown = true
	in.Current.Sell.OFIKnown = true
	in.Current.Buy.OFI30 = .2
	in.Current.Sell.OFI30 = .2
	for i, end := range []float64{2520, 2700, 2880} {
		v := t
		v.Bar3End = end
		v.Bar15End = math.Floor(end/900) * 900
		v.Close3 = 1000 + 5*float64(i)
		v.EMA8_3 = 990 + 5*float64(i)
		v.EMA21_3 = 980 + 5*float64(i)
		if i == 0 {
			v.EMA8_3 = 1000
		}
		if i == 1 {
			v.Histogram3, v.RSI3, v.ATR3 = t.PreviousHistogram3, t.PreviousRSI3, t.PreviousATR3
		}
		if i == 2 {
			v = t
		}
		in.Recent3 = append(in.Recent3, snapshot(end, v))
	}
	return in
}

// mirrorSignal は、手製価格を同じ中心で反射し方向指標を反転します。
//
// 引数: in(chart.TechnicalGateInput)は人工。返り値: chart.TechnicalGateInputは独立鏡像です。
func mirrorSignal(in chart.TechnicalGateInput) chart.TechnicalGateInput {
	body, _ := json.Marshal(in)
	var out chart.TechnicalGateInput
	_ = json.Unmarshal(body, &out)
	flip := func(s *warm.Snapshot) {
		v := &s.Chart.Technical
		v.Close3 = 2000 - v.Close3
		v.EMA8_3 = 2000 - v.EMA8_3
		v.EMA21_3 = 2000 - v.EMA21_3
		v.EMA8_15 = 2000 - v.EMA8_15
		v.EMA21_15 = 2000 - v.EMA21_15
		v.RSI3 = 100 - v.RSI3
		v.PreviousRSI3 = 100 - v.PreviousRSI3
		v.Histogram3 = -v.Histogram3
		v.PreviousHistogram3 = -v.PreviousHistogram3
		s.LastInput.Last = 2000 - s.LastInput.Last
		s.Three.LastSource.Last = 2000 - s.Three.LastSource.Last
		s.Fifteen.LastSource.Last = 2000 - s.Fifteen.LastSource.Last
		if s.Chart.Previous3Known {
			s.Chart.PreviousClose3 = 2000 - s.Chart.PreviousClose3
			s.Chart.PreviousEMA8_3 = 2000 - s.Chart.PreviousEMA8_3
		}
	}
	flip(&out.Chart)
	for i := range out.Recent3 {
		flip(&out.Recent3[i])
	}
	out.Current.Last = 2000 - out.Current.Last
	out.Current.Bid, out.Current.Ask = 2000-out.Current.Ask, 2000-out.Current.Bid
	out.Current.Buy.OFI30 = -out.Current.Buy.OFI30
	out.Current.Sell.OFI30 = -out.Current.Sell.OFI30
	return out
}

// syncSignalLatest は、人工現在指標を最新公表足へ同体反映します。
//
// 引数: in(*chart.TechnicalGateInput)は変更した器具。返り値: なし。
func syncSignalLatest(in *chart.TechnicalGateInput) {
	in.Recent3[len(in.Recent3)-1].Chart.Technical = in.Chart.Chart.Technical
	if len(in.Recent3) >= 2 {
		p := &in.Recent3[len(in.Recent3)-2].Chart.Technical
		t := in.Chart.Chart.Technical
		p.Histogram3 = t.PreviousHistogram3
		p.RSI3 = t.PreviousRSI3
		p.ATR3 = t.PreviousATR3
		p.Close3 = in.Chart.Chart.PreviousClose3
		p.EMA8_3 = in.Chart.Chart.PreviousEMA8_3
	}
}

// TestSignal102Mirror は、8票/数量/保護の売買対称と入力不変を検査します。
//
// 引数: t(*testing.T)は人工検査。返り値: なし。
func TestSignal102Mirror(t *testing.T) {
	buy := signalFixture()
	before, _ := json.Marshal(buy)
	sell := mirrorSignal(buy)
	for _, policy := range []string{"S3", "S4"} {
		a, ae, err := AssessGrid(buy, policy)
		if err != nil {
			t.Fatal(err)
		}
		b, be, err := AssessGrid(sell, policy)
		if err != nil {
			t.Fatal(err)
		}
		if !a.Known || a.Side != 1 || a.Qty != 6 || b.Side != -1 || b.Qty != a.Qty || ae.Buy.Lower != 8 || be.Sell.Lower != 8 || a.AvailableAt != 3002 {
			t.Fatalf("鏡像/8票/公開下限: %+v %+v", a, b)
		}
		if !reflect.DeepEqual(ae.Buy.Votes, be.Sell.Votes) || a.BuyProtection != b.SellProtection {
			t.Fatal("票又は保護非対称")
		}
	}
	after, _ := json.Marshal(buy)
	if string(before) != string(after) {
		t.Fatal("入力共有変更")
	}
}

// TestSignal102ThreeFour は、8票中3/4境界と2/4/6枚を検査します。
//
// 引数: t(*testing.T)は人工検査。返り値: なし。
func TestSignal102ThreeFour(t *testing.T) {
	in := signalFixture()
	v := &in.Chart.Chart.Technical
	v.EMA8_15, v.EMA21_15 = 1000, 1000
	v.Histogram3, v.PreviousHistogram3 = 1, 1
	v.RSI3, v.PreviousRSI3 = 50, 50
	v.Close3 = 1000
	in.Chart.Chart.PreviousClose3 = 1000
	in.Current.Bid, in.Current.Ask = 1000, 1002
	in.Current.Buy.OFI30, in.Current.Sell.OFI30 = 0, 0
	syncSignalLatest(&in)
	a, e, err := AssessGrid(in, "S3")
	if err != nil {
		t.Fatal(err)
	}
	b, _, err := AssessGrid(in, "S4")
	if err != nil {
		t.Fatal(err)
	}
	if a.Side != 1 || a.Qty != 2 || e.Buy.Lower != 3 || !b.Known || b.Side != 0 {
		t.Fatalf("3票境界 %+v %+v %+v", a, b, e)
	}
	in.Current.Buy.OFI30 = .2
	in.Current.Sell.OFI30 = .2
	a, _, err = AssessGrid(in, "S4")
	if err != nil || a.Side != 1 || a.Qty != 4 {
		t.Fatalf("4票 %+v %v", a, err)
	}
	v.Histogram3 = 2
	syncSignalLatest(&in)
	a, _, err = AssessGrid(in, "S4")
	if err != nil || a.Qty != 6 {
		t.Fatalf("5票 %+v %v", a, err)
	}
}

// TestSignal102UnknownBounds は、未知量/前足と反対側の未知逆転を検査します。
//
// 引数: t(*testing.T)は人工検査。返り値: なし。
func TestSignal102UnknownBounds(t *testing.T) {
	in := signalFixture()
	in.Current.Buy.OFIKnown = false
	in.Current.Sell.OFIKnown = false
	in.Chart.Chart.Previous3Known = false
	d, e, err := AssessGrid(in, "S3")
	if err != nil {
		t.Fatal(err)
	}
	if !d.Known || d.Side != 1 || e.Buy.Lower != 5 || e.Buy.Upper != 8 || e.Buy.Votes[7].Known || e.Buy.Votes[7].Passed {
		t.Fatalf("未知票区間 %+v %+v", d, e)
	}
	b := SideSignal{Side: 1, Lower: 4, Upper: 5, Eligible: true, Possible: true}
	s := SideSignal{Side: -1, Lower: 3, Upper: 4, Possible: true}
	side, _, known, _ := selectSignal(b, s)
	if side != 0 || known {
		t.Fatal("未知同点を採用")
	}
	s.Upper = 3
	side, _, known, _ = selectSignal(b, s)
	if side != 1 || !known {
		t.Fatal("確定勝者を不明化")
	}
	b.Upper = 4
	s = SideSignal{Side: -1, Lower: 4, Upper: 4, Eligible: true, Possible: true}
	side, _, known, _ = selectSignal(b, s)
	if side != 0 || !known {
		t.Fatal("同点競合は待機")
	}
}

// TestSignal102Protection は、複合収束/失速と鏡像・未知を検査します。
//
// 引数: t(*testing.T)は人工検査。返り値: なし。
func TestSignal102Protection(t *testing.T) {
	in := signalFixture()
	v := &in.Chart.Chart.Technical
	v.EMA21_3 = 999
	v.Close3 = 990
	v.Histogram3 = 2
	v.PreviousHistogram3 = 3
	in.Recent3[1].Chart.Technical.Histogram3 = 3
	syncSignalLatest(&in)
	a, err := AssessHeldGrid(in, 1)
	if err != nil || !a.Known || !a.Converged || !a.Stalled {
		t.Fatalf("複合状態 %+v %v", a, err)
	}
	b, err := AssessHeldGrid(mirrorSignal(in), -1)
	if err != nil || a != b {
		t.Fatalf("保護鏡像 %+v %v", b, err)
	}
	v.Histogram3 = v.PreviousHistogram3
	syncSignalLatest(&in)
	a, err = AssessHeldGrid(in, 1)
	if err != nil || a.Converged || a.Stalled {
		t.Fatal("単MA変化で保護")
	}
	in.Recent3 = nil
	a, err = AssessHeldGrid(in, 1)
	if err != nil || a.Known {
		t.Fatal("前足未知の0補完")
	}
}

// TestSignal102Quality は、正常助走/Last0と未来破損を区別します。
//
// 引数: t(*testing.T)は人工検査。返り値: なし。
func TestSignal102Quality(t *testing.T) {
	for _, change := range []func(*chart.TechnicalGateInput){func(in *chart.TechnicalGateInput) { in.Chart.Chart.Technical.TrendKnown = false }, func(in *chart.TechnicalGateInput) { in.Chart.Three.DataKnown = false }, func(in *chart.TechnicalGateInput) {
		in.Current.Time = in.At - 16
		in.Current.Buy.OwnAt = in.Current.Time
		in.Current.Sell.OwnAt = in.Current.Time
	}, func(in *chart.TechnicalGateInput) { in.Current.Ask = in.Current.Bid }, func(in *chart.TechnicalGateInput) {
		in.Chart.Chart.Technical.ExitKnown = false
		in.Chart.Chart.Technical.SpikeKnown = false
		in.Chart.Chart.Technical.ATRKnown = false
		in.Chart.Chart.Technical.TrendKnown = false
	}} {
		in := signalFixture()
		change(&in)
		d, _, err := AssessGrid(in, "S3")
		if err != nil || d.Known || d.Side != 0 {
			t.Fatalf("通常未知 %+v %v", d, err)
		}
	}
	for _, change := range []func(*chart.TechnicalGateInput){func(in *chart.TechnicalGateInput) { in.Current.Time = in.At + 1 }, func(in *chart.TechnicalGateInput) { in.Chart.Three.AvailableAt = in.At + 1 }, func(in *chart.TechnicalGateInput) { in.Recent3[0].Scene.ID = "他場" }, func(in *chart.TechnicalGateInput) { in.Current.Buy.OwnAt = in.Current.Time + 1 }, func(in *chart.TechnicalGateInput) { in.Chart.Chart.Technical.ATR3 = -1 }, func(in *chart.TechnicalGateInput) { in.Chart.Chart.Technical.RSI3 = 101 }, func(in *chart.TechnicalGateInput) { in.Current.Ask = math.NaN() }, func(in *chart.TechnicalGateInput) { in.Chart.Chart.PreviousBar3End-- }, func(in *chart.TechnicalGateInput) { in.Recent3[2].Chart.Technical.Close3++ }} {
		in := signalFixture()
		change(&in)
		if _, _, err := AssessGrid(in, "S3"); err == nil {
			t.Fatal("未来/破損受理")
		}
	}
	in := signalFixture()
	in.Current.Time = in.At - 15
	in.Current.Buy.OwnAt, in.Current.Sell.OwnAt = in.Current.Time, in.Current.Time
	if _, _, err := AssessGrid(in, "S3"); err != nil {
		t.Fatal("15秒等号拒否")
	}
}

// TestSignal102NightAndReversal は、E08符号と固定3足の別役割を検査します。
//
// 引数: t(*testing.T)は人工検査。返り値: なし。
func TestSignal102NightAndReversal(t *testing.T) {
	in := signalFixture()
	in.Kind = "Night"
	n := &in.Current.Night
	n.Available = true
	n.Window = "E08"
	n.Time = in.Current.Time
	n.Index = in.Current.SourceIndex
	n.Band.Time = in.Current.Time
	n.Band.Index = in.Current.SourceIndex
	n.Band.QuantityKnown = true
	n.Band.BidRefill = 2
	if !signalVolume(in, 1).passed || signalVolume(in, -1).passed {
		t.Fatal("E08方向")
	}
	n.Band.Index--
	if signalVolume(in, 1).known {
		t.Fatal("E08別原行")
	}
	in = signalFixture()
	if r := signalReversal(in, 1); !r.known || !r.passed {
		t.Fatal("固定線奪還")
	}
	if r := signalReversal(mirrorSignal(in), -1); !r.known || !r.passed {
		t.Fatal("固定線鏡像")
	}
	in.Recent3[0].Chart.Technical.Close3 = 1001
	if r := signalReversal(in, 1); !r.known || r.passed {
		t.Fatal("a同値境界")
	}
	in.Recent3 = in.Recent3[1:]
	if signalReversal(in, 1).known {
		t.Fatal("足不足を成立")
	}
}

// TestSignal102HeaderCounts は、明示環境指定時だけ許可54Headerの候補数を数えます。
//
// 引数: t(*testing.T)、環境SIGNAL102_HEADERS_ROOT/OUT(string)はrepoと新規証拠先です。
// 返り値: なし。金融/records/原板/損益を開かず、固定SHA不一致/純式errorで停止します。
func TestSignal102HeaderCounts(t *testing.T) {
	root, out := os.Getenv("SIGNAL102_HEADERS_ROOT"), os.Getenv("SIGNAL102_HEADERS_OUT")
	if root == "" && out == "" {
		t.Skip("Header候補率はRoot許可の明示環境指定だけ")
	}
	if root == "" || out == "" {
		t.Fatal("repoと新規出力の両方が必要")
	}
	if _, err := os.Stat(out); !os.IsNotExist(err) {
		t.Fatal("新規出力だけ", err)
	}
	hash := func(body []byte) string { return fmt.Sprintf("%x", sha256.Sum256(body)) }
	read := func(path, expected string) []byte {
		b, err := os.ReadFile(path)
		if err != nil {
			t.Fatal(err)
		}
		if expected != "" && hash(b) != expected {
			t.Fatal("SHA差", path)
		}
		return b
	}
	rp := filepath.Join(root, "work/101連続入力の全54場_版3/生成/完了.json")
	rsha := "9ed1a959d9178f6ff6d4f4402c886cc81fc90aced7846d5d8c706f44ef0b0cd3"
	rb := read(rp, rsha)
	var receipt struct {
		Success   bool     `json:"成功"`
		Unchanged bool     `json:"前後不変"`
		Stage     string   `json:"stage"`
		Sessions  []string `json:"sessions"`
		Details   []struct {
			Session, Header string
			SHA             string `json:"header_SHA256"`
		} `json:"details"`
	}
	if err := json.Unmarshal(rb, &receipt); err != nil {
		t.Fatal(err)
	}
	bp := filepath.Join(root, "work/101連続入力の全54場_版3/全54読戻し.json")
	bsha := "1b5e837c441dcafab9d68a5df4ddd491ba9e55bcdf733fba8b8b959321d68e8b"
	bb := read(bp, bsha)
	var back struct {
		Success   bool     `json:"成功"`
		Unchanged bool     `json:"前後不変"`
		Stage     string   `json:"stage"`
		Receipt   string   `json:"入力構築receiptSHA256"`
		Sessions  []string `json:"sessions"`
	}
	if err := json.Unmarshal(bb, &back); err != nil {
		t.Fatal(err)
	}
	expected := []string{}
	for date := time.Date(2026, 9, 21, 0, 0, 0, 0, time.UTC); !date.After(time.Date(2026, 10, 27, 0, 0, 0, 0, time.UTC)); date = date.AddDate(0, 0, 1) {
		if date.Weekday() != time.Saturday && date.Weekday() != time.Sunday {
			for _, kind := range []string{"Day", "Night"} {
				expected = append(expected, date.Format("2006-01-02")+"_"+kind)
			}
		}
	}
	if !receipt.Success || !receipt.Unchanged || receipt.Stage != "full54" || !back.Success || !back.Unchanged || back.Stage != "full54" || back.Receipt != rsha || len(receipt.Details) != 54 || !reflect.DeepEqual(receipt.Sessions, expected) || !reflect.DeepEqual(back.Sessions, expected) {
		t.Fatal("完全54と成功読戻し")
	}
	before := map[string]string{rp: rsha, bp: bsha}
	for _, name := range []string{"信号.go", "信号_test.go", "api.go"} {
		p := filepath.Join(root, "work/102定時チャート売買", name)
		before[p] = hash(read(p, ""))
	}
	count := map[string]map[string]int{}
	details := []any{}
	for _, policy := range []string{"S3", "S4"} {
		count[policy] = map[string]int{}
	}
	for i, row := range receipt.Details {
		if row.Session != expected[i] {
			t.Fatal("場順/重複", row.Session)
		}
		path := filepath.Clean(filepath.Join(root, row.Header))
		if !strings.HasPrefix(path, filepath.Clean(root)+string(filepath.Separator)) {
			t.Fatal("Headerはrepo内だけ")
		}
		body := read(path, row.SHA)
		before[path] = row.SHA
		var h struct {
			Session struct {
				ID, Kind   string
				Start, End float64
			}
			Grids []chart.TechnicalGateInput
		}
		if err := json.Unmarshal(body, &h); err != nil {
			t.Fatal(err)
		}
		if h.Session.ID != row.Session || h.Session.Start <= 0 || h.Session.End <= h.Session.Start || len(h.Grids) == 0 {
			t.Fatal("Header場/時計", row.Session)
		}
		local := map[string]map[string]int{"S3": {}, "S4": {}}
		for gi, in := range h.Grids {
			if in.Chart.Scene.ID != row.Session || in.Kind != h.Session.Kind {
				t.Fatal("枠の場違い")
			}
			for _, policy := range []string{"S3", "S4"} {
				d, _, err := AssessGrid(in, policy)
				if err != nil {
					t.Fatalf("%s %s 枠%d At%.0f: %v", row.Session, policy, gi, in.At, err)
				}
				kind := "待機"
				if !d.Known {
					kind = "判定不能"
				} else if d.Side != 0 {
					kind = "候補"
				}
				local[policy]["全保存枠"]++
				local[policy]["全保存_"+kind]++
				if in.At >= h.Session.Start+1800 && in.At < h.Session.End-1800 {
					local[policy]["前後30分除外枠"]++
					local[policy]["前後30分除外_"+kind]++
					if d.Side > 0 {
						local[policy]["買い候補"]++
					}
					if d.Side < 0 {
						local[policy]["売り候補"]++
					}
				}
			}
		}
		for policy, v := range local {
			for name, n := range v {
				count[policy][name] += n
			}
		}
		details = append(details, map[string]any{"session": row.Session, "header_SHA256": row.SHA, "counts": local})
	}
	after := map[string]string{}
	for p, expectedSHA := range before {
		after[p] = hash(read(p, expectedSHA))
	}
	value := map[string]any{"成功": true, "scope": "固定S3/S4純式の全54Header候補枠数だけ。実参加率/損益/金融は未測定", "事前固定仕様SHA256": "d51523a128348432d51203dd42ca2b3736a5cec70cc36379cb25a70da110ec56", "counts": count, "details": details, "入力codeSHA256前": before, "入力codeSHA256後": after, "前後不変": true, "records_Raw_CSV_Native追加読取": 0, "金融_Source再生": 0, "機会損失_MFE": false, "時計範囲": "保存全5分列とscene前後30分除外列。US独自見送りは別途未追加"}
	body, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	f, err := os.OpenFile(out, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
	if err != nil {
		t.Fatal(err)
	}
	_, err = f.Write(append(body, '\n'))
	closeErr := f.Close()
	if err != nil || closeErr != nil {
		t.Fatal(err, closeErr)
	}
	t.Logf("候補枠数だけ: %+v", count)
}
