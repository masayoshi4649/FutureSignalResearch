package main

import (
	"encoding/json"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"testing"
)

// financeSession102 は、欠測枠も残す二枠の人工時計を作ります。
//
// 引数: なし。返り値: Session。市場データは使いません。
func financeSession102() Session {
	return Session{ID: "人工Day", Kind: "Day", Start: 0, End: 4200, Force: 4190}
}

// financeConfig102 は、人工用の固定設定を返します。
//
// 引数: policy(string)、slip/delay(float64)。返り値: Config。
func financeConfig102(policy string, slip, delay float64) Config {
	return Config{Name: "人工", EntryPolicy: "S3", TrailPolicy: policy, Slip: slip, Delay: delay}
}

// financeDecision102 は、買い側の既知公開判断を作ります。
//
// 引数: at/atr(float64)、qty(int)。返り値: Decision。
func financeDecision102(at, atr float64, qty int) Decision {
	return Decision{At: at, AvailableAt: at, Side: 1, Qty: qty, ATR: atr, Known: true,
		Reason: "手製複合信号", BuyProtection: ProtectionState{Known: true}, SellProtection: ProtectionState{Known: true}}
}

// financeQuotes102 は、秒と価格を対応させた人工原行列を作ります。
//
// 引数: rows([][3]float64)は秒/Bid/Ask。返り値: []Quote。
func financeQuotes102(rows ...[3]float64) []Quote {
	quotes := make([]Quote, len(rows))
	for i, row := range rows {
		quotes[i] = Quote{Time: row[0], Index: i, Bid: row[1], Ask: row[2], Valid: true}
	}
	return quotes
}

// financeClose102 は、浮動小数の計算差だけを許容します。
//
// 引数: t(*testing.T)、a/b(float64)。返り値: なし。
func financeClose102(t *testing.T, a, b float64) {
	t.Helper()
	if math.Abs(a-b) > 1e-8 {
		t.Fatalf("値差: %v / %v", a, b)
	}
}

// TestFinance102Mirror は、三追尾と費用遅延の鏡像会計を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestFinance102Mirror(t *testing.T) {
	quotes := financeQuotes102([3]float64{1799, 1000, 1005}, [3]float64{1800, 1000, 1005},
		[3]float64{1801, 1000, 1005}, [3]float64{1802, 1040, 1045},
		[3]float64{1803, 1020, 1025}, [3]float64{1804, 990, 995}, [3]float64{1805, 985, 990},
		[3]float64{4190, 985, 990}, [3]float64{4191, 985, 990})
	decision := financeDecision102(1800, 10, 6)
	decision.BuyProtection.Converged = true
	for _, policy := range []string{"P0", "A0", "A1"} {
		for _, slip := range []float64{0, 5} {
			for _, delay := range []float64{0, 1} {
				t.Run(policy+string(rune('0'+int(slip)))+string(rune('0'+int(delay))), func(t *testing.T) {
					long := Replay(financeSession102(), quotes, []Decision{decision}, financeConfig102(policy, slip, delay))
					mirror := append([]Quote(nil), quotes...)
					for i, q := range mirror {
						mirror[i].Bid, mirror[i].Ask = 2000-q.Ask, 2000-q.Bid
					}
					d := decision
					d.Side = -1
					d.BuyProtection, d.SellProtection = d.SellProtection, d.BuyProtection
					short := Replay(financeSession102(), mirror, []Decision{d}, financeConfig102(policy, slip, delay))
					if !long.Success || !short.Success || len(long.Trades) != 1 || len(short.Trades) != 1 {
						t.Fatalf("未完結: %+v / %+v", long, short)
					}
					financeClose102(t, long.Gross, short.Gross)
					financeClose102(t, long.Net, short.Net)
					financeClose102(t, long.DD, short.DD)
					financeClose102(t, long.Trades[0].FinalFloor+short.Trades[0].FinalFloor, 2000)
					if long.OpenQuantity != 0 || long.PendingExit != 0 || long.New != 1 || long.Denom != 2 {
						t.Fatalf("所有又は分類: %+v", long)
					}
				})
			}
		}
	}
}

// TestFinance102PublicationAndStrictRow は、drain時刻と同秒後続原行を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestFinance102PublicationAndStrictRow(t *testing.T) {
	q := financeQuotes102([3]float64{1799, 1000, 1005}, [3]float64{1805, 1010, 1015},
		[3]float64{1805, 1020, 1025}, [3]float64{1805.1, 1030, 1035}, [3]float64{1806, 1040, 1045},
		[3]float64{4190, 1040, 1045}, [3]float64{4191, 1040, 1045})
	d := financeDecision102(1800, 10, 2)
	d.AvailableAt = 1805
	for _, delay := range []float64{0, 1} {
		r := Replay(financeSession102(), q, []Decision{d}, financeConfig102("P0", 0, delay))
		if !r.Success || len(r.Trades) != 1 || r.Orders[0].At != 1805 || r.Orders[0].RequestIndex != 2 || r.Orders[0].ExpiresAt != 1860 {
			t.Fatalf("公表時計: %+v", r)
		}
		want := 1805.1
		if delay == 1 {
			want = 1806
		}
		financeClose102(t, r.Trades[0].Entry.Quote.Time, want)
		if r.Trades[0].Entry.Quote.Index <= 2 {
			t.Fatal("要求前原行fill")
		}
	}
}

// TestFinance102TTLAndForce は、等号失効・Force優先・不完結失敗を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestFinance102TTLAndForce(t *testing.T) {
	d := financeDecision102(1800, 10, 2)
	q := financeQuotes102([3]float64{1800, 1000, 1005}, [3]float64{1860, 1000, 1005})
	r := Replay(financeSession102(), q, []Decision{d}, financeConfig102("P0", 0, 0))
	if !r.Success || r.PosCount != 0 || r.Orders[0].Status != "cancelled" || r.Orders[0].CancelAt != 1860 || r.New != 0 {
		t.Fatalf("TTL等号: %+v", r)
	}
	s := financeSession102()
	s.Force = 1801
	q = financeQuotes102([3]float64{1800, 1000, 1005}, [3]float64{1801, 1000, 1005})
	r = Replay(s, q, []Decision{d}, financeConfig102("P0", 0, 0))
	if !r.Success || len(r.Fills) != 0 || r.Orders[0].CancelAt != 1801 {
		t.Fatalf("Force優先: %+v", r)
	}
	s = financeSession102()
	q = financeQuotes102([3]float64{1800, 1000, 1005}, [3]float64{1801, 1000, 1005})
	r = Replay(s, q, []Decision{d}, financeConfig102("P0", 0, 0))
	if r.Success || r.OpenQuantity != 2 || r.PendingExit != 2 {
		t.Fatalf("終端残存を成功化: %+v", r)
	}
}

// TestFinance102ActivationAndFeeFloor は、起動前後と費用回収床を区別します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestFinance102ActivationAndFeeFloor(t *testing.T) {
	for _, slip := range []float64{0, 5} {
		d := financeDecision102(1800, 40, 2)
		mark := 1005 + 2*slip + .77 + 15 // 正益だが20pt起動へ未到達。
		q := financeQuotes102([3]float64{1800, 1000, 1005}, [3]float64{1801, 1000, 1005},
			[3]float64{1802, mark, mark + 5}, [3]float64{4190, mark, mark + 5}, [3]float64{4191, mark, mark + 5})
		p0 := Replay(financeSession102(), q, []Decision{d}, financeConfig102("P0", slip, 0))
		a0 := Replay(financeSession102(), q, []Decision{d}, financeConfig102("A0", slip, 0))
		if !p0.Success || !a0.Success || !p0.Trades[0].Activated || a0.Trades[0].Activated || !a0.Trades[0].HadPositiveUnit {
			t.Fatalf("利益観測と起動の分離: %+v / %+v", p0, a0)
		}
		mark = 1005 + 2*slip + .77 + 20
		q[2].Bid, q[2].Ask = mark, mark+5
		q[3].Bid, q[3].Ask = mark, mark+5
		q[4].Bid, q[4].Ask = mark, mark+5
		a0 = Replay(financeSession102(), q, []Decision{d}, financeConfig102("A0", slip, 0))
		want := 1010.0
		if slip == 5 {
			want = 1020
		}
		if !a0.Success || !a0.Trades[0].Activated {
			t.Fatalf("起動等号: %+v", a0)
		}
		financeClose102(t, a0.Trades[0].FinalFloor, want)
	}
	// 偶数枚の公開取引と、半円の費用単価を別々に検査する。
	e := engine102{r: Result{Config: financeConfig102("P0", 0, 0)}}
	f := e.makeFill(Order{Side: 1, Qty: 1}, Quote{Ask: 1005})
	financeClose102(t, f.Fee, 38.5)
	financeClose102(t, 2*feeSide102/pointValue102, .77)
}

// TestFinance102NonRelaxationAndHeldSide は、A1幅と保有方向状態を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestFinance102NonRelaxationAndHeldSide(t *testing.T) {
	s := financeSession102()
	d := financeDecision102(1800, 20, 4)
	d.BuyProtection.Stalled = true
	second := financeDecision102(2100, 100, 4)
	second.Side = 0
	second.BuyProtection = ProtectionState{} // 未知で反対化せず前状態を保持。
	q := financeQuotes102([3]float64{1800, 1000, 1005}, [3]float64{1801, 1000, 1005},
		[3]float64{1802, 1050, 1055}, [3]float64{2100, 1050, 1055}, [3]float64{2101, 1050, 1055},
		[3]float64{4190, 1050, 1055}, [3]float64{4191, 1050, 1055})
	a0 := Replay(s, q, []Decision{d, second}, financeConfig102("A0", 0, 0))
	a1 := Replay(s, q, []Decision{d, second}, financeConfig102("A1", 0, 0))
	if !a0.Success || !a1.Success {
		t.Fatalf("未完結: %+v / %+v", a0, a1)
	}
	financeClose102(t, a0.Trades[0].FinalFloor, 1020)
	financeClose102(t, a1.Trades[0].FinalFloor, 1035)
	if a1.Hold != 1 || a1.New != 1 || a1.Active != 2 {
		t.Fatalf("保有分類: %+v", a1)
	}
}

// TestFinance102GapAndDelayedLoss は、床要求後の悪化を実損失へ残します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestFinance102GapAndDelayedLoss(t *testing.T) {
	d := financeDecision102(1800, 10, 2)
	q := financeQuotes102([3]float64{1800, 1000, 1005}, [3]float64{1801, 1000, 1005},
		[3]float64{1802, 1020, 1025}, [3]float64{1803, 1005, 1010}, [3]float64{1803, 990, 995},
		[3]float64{1804, 980, 985}, [3]float64{4191, 980, 985})
	for _, delay := range []float64{0, 1} {
		r := Replay(financeSession102(), q, []Decision{d}, financeConfig102("P0", 0, delay))
		if !r.Success || len(r.Trades) != 1 || !r.Trades[0].Activated || r.Trades[0].Net >= 0 {
			t.Fatalf("遅延損失: %+v", r)
		}
		if r.Trades[0].Exit.Quote.Index <= r.Orders[1].RequestIndex {
			t.Fatal("要求原行fill")
		}
		want := 990.0
		if delay == 1 {
			want = 980
		}
		financeClose102(t, r.Trades[0].Exit.Price, want)
		financeClose102(t, r.Net, r.Gross-r.Fee-r.Slip)
		if r.DD <= 0 || r.MinEquity >= 0 || len(r.EquityPoints) == 0 {
			t.Fatal("口座DD未記録")
		}
	}
}

// TestFinance102OppositeAndNoImmediateReentry は、保有側否定による枠返済を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestFinance102OppositeAndNoImmediateReentry(t *testing.T) {
	d := financeDecision102(1800, 100, 2)
	opposite := financeDecision102(2100, 100, 6)
	opposite.Side = -1
	q := financeQuotes102([3]float64{1800, 1000, 1005}, [3]float64{1801, 1000, 1005},
		[3]float64{2100, 1000, 1005}, [3]float64{2101, 1000, 1005}, [3]float64{4191, 1000, 1005})
	for _, denied := range []bool{false, true} {
		x := opposite
		x.BuyProtection.Stalled = denied
		r := Replay(financeSession102(), q, []Decision{d, x}, financeConfig102("A1", 0, 0))
		if !r.Success || r.PosCount != 1 || len(r.Orders) != 2 {
			t.Fatalf("反対新規又は不完結: %+v", r)
		}
		want := "場末強制返済"
		if denied {
			want = "反対方向と保有複合否定"
		}
		if r.Trades[0].ExitReason != want {
			t.Fatalf("方向だけで退出: %+v", r.Trades[0])
		}
	}
}

// TestFinance102GridDenominatorAndUnknown は、欠測を分母へ残し未約定を参加にしません。
//
// 引数: t(*testing.T)。返り値: なし。
func TestFinance102GridDenominatorAndUnknown(t *testing.T) {
	for _, row := range []struct {
		kind     string
		duration float64
		want     int
	}{{"Day", 7 * 3600, 72}, {"Night", 13 * 3600, 144}} {
		s := Session{ID: "無観測人工", Kind: row.kind, Start: 0, End: row.duration, Force: row.duration - 1}
		r := Replay(s, nil, nil, financeConfig102("P0", 0, 0))
		if !r.Success || r.Denom != row.want || r.Unknown != row.want || r.Active != 0 {
			t.Fatalf("分母: %+v", r)
		}
	}
	d := financeDecision102(1800, 0, 2)
	d2 := financeDecision102(2100, 0, 0)
	d2.Side = 0
	r := Replay(financeSession102(), nil, []Decision{d, d2}, financeConfig102("P0", 0, 0))
	if !r.Success || r.Unknown != 1 || r.Wait != 1 || r.Active != 0 {
		t.Fatalf("既知否定/ATR未知: %+v", r)
	}
	q := financeQuotes102([3]float64{1800, 1000, 1005}, [3]float64{1801, 1000, 1005})
	q[1].Valid = false
	r = Replay(financeSession102(), q, []Decision{financeDecision102(1800, 10, 2)}, financeConfig102("P0", 0, 0))
	if !r.Success || r.PosCount != 0 || r.New != 0 || r.Wait != 1 {
		t.Fatalf("未約定の水増し: %+v", r)
	}
}

// TestFinance102MalformedAndInputImmutable は、数値破損と入力副作用を拒否します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestFinance102MalformedAndInputImmutable(t *testing.T) {
	q := financeQuotes102([3]float64{1800, 1000, 1005}, [3]float64{1801, 1000, 1005}, [3]float64{4191, 1000, 1005})
	d := []Decision{financeDecision102(1800, 10, 2)}
	qCopy := append([]Quote(nil), q...)
	dCopy := append([]Decision(nil), d...)
	_ = Replay(financeSession102(), q, d, financeConfig102("P0", 0, 0))
	if !reflect.DeepEqual(q, qCopy) || !reflect.DeepEqual(d, dCopy) {
		t.Fatal("入力変更")
	}
	badQ := append([]Quote(nil), q...)
	badQ[1].Index = badQ[0].Index
	if Replay(financeSession102(), badQ, d, financeConfig102("P0", 0, 0)).Success {
		t.Fatal("Index重複受理")
	}
	for _, bad := range []float64{-1, math.NaN(), math.Inf(1)} {
		x := d[0]
		x.ATR = bad
		if Replay(financeSession102(), q, []Decision{x}, financeConfig102("P0", 0, 0)).Success {
			t.Fatal("ATR破損受理")
		}
	}
	x := d[0]
	x.Qty = 10
	if Replay(financeSession102(), q, []Decision{x}, financeConfig102("P0", 0, 0)).Success {
		t.Fatal("指定外数量受理")
	}
}

// TestFinance102StrictProfitBoundary は、費用後0を起動へ補完しません。
//
// 引数: t(*testing.T)。返り値: なし。価格線の直後一値も区別します。
func TestFinance102StrictProfitBoundary(t *testing.T) {
	for _, policy := range []string{"P0", "A0"} {
		for _, above := range []bool{false, true} {
			level := 1000 + .77
			if policy == "A0" {
				level += 10
			}
			if above {
				level = math.Nextafter(level, math.Inf(1))
			}
			q := financeQuotes102([3]float64{1800, 995, 1000}, [3]float64{1801, 995, 1000},
				[3]float64{1802, level, level + 5}, [3]float64{4190, level, level + 5}, [3]float64{4191, level, level + 5})
			r := Replay(financeSession102(), q, []Decision{financeDecision102(1800, 10, 2)}, financeConfig102(policy, 0, 0))
			if !r.Success || len(r.Trades) != 1 {
				t.Fatal("人工未完結")
			}
			want := above || policy == "A0"
			if r.Trades[0].Activated != want {
				t.Fatalf("起動境界 %s above=%v: %+v", policy, above, r.Trades[0])
			}
			if policy == "P0" && r.Trades[0].HadPositiveUnit != above {
				t.Fatal("費用後0の正益化")
			}
		}
	}
}

// TestFinance102CapacityAndExitRowObservation は、追加取得禁止と返済直前評価を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestFinance102CapacityAndExitRowObservation(t *testing.T) {
	d := financeDecision102(1800, 100, 6)
	other := financeDecision102(2100, 100, 6)
	q := financeQuotes102([3]float64{1800, 1000, 1005}, [3]float64{1801, 1000, 1005},
		[3]float64{2100, 1000, 1005}, [3]float64{2101, 1000, 1005}, [3]float64{4191, 1000, 1005})
	r := Replay(financeSession102(), q, []Decision{d, other}, financeConfig102("P0", 0, 0))
	if !r.Success || r.PosCount != 1 || r.Trades[0].Qty != 6 || len(r.Fills) != 2 {
		t.Fatalf("保有中の追加取得: %+v", r)
	}
	q = financeQuotes102([3]float64{1800, 1000, 1005}, [3]float64{1801, 1000, 1005},
		[3]float64{1802, 980, 985}, [3]float64{1803, 1020, 1025}, [3]float64{4191, 1020, 1025})
	r = Replay(financeSession102(), q, []Decision{financeDecision102(1800, 10, 2)}, financeConfig102("P0", 0, 0))
	if !r.Success || !r.Trades[0].HadPositiveUnit || r.Trades[0].FirstPositiveAt != 1803 || !r.Trades[0].Activated || r.Trades[0].ExitReason != "取得時ATR初期損切り" {
		t.Fatalf("返済fill原行の正益/起動・元予約理由: %+v", r)
	}
}

// TestFinance102V2CutoffAndLatePublication は、実要求の論理期限を確認します。
//
// 引数: t(*testing.T)。返り値: なし。公表待ちで信号を若返らせません。
func TestFinance102V2CutoffAndLatePublication(t *testing.T) {
	for _, available := range []float64{1859.5, 1860} {
		for _, delay := range []float64{0, 1} {
			d := financeDecision102(1800, 10, 2)
			d.AvailableAt = available
			q := financeQuotes102([3]float64{1800, 1000, 1005}, [3]float64{available, 1000, 1005},
				[3]float64{1859.9, 1000, 1005}, [3]float64{1860, 1000, 1005}, [3]float64{4191, 1000, 1005})
			if available == 1860 {
				q = financeQuotes102([3]float64{1800, 1000, 1005}, [3]float64{1860, 1000, 1005}, [3]float64{1861, 1000, 1005}, [3]float64{4191, 1000, 1005})
			}
			r := Replay(financeSession102(), q, []Decision{d}, financeConfig102("P0", 0, delay))
			want := 0
			if available < 1860 && delay == 0 {
				want = 1
			}
			if !r.Success || r.PosCount != want || r.Denom != 2 {
				t.Fatalf("論理期限 available=%v delay=%v: %+v", available, delay, r)
			}
			if available == 1860 && (len(r.Orders) != 0 || r.Unknown != 2) {
				t.Fatalf("期限等号の復活: %+v", r)
			}
			if available < 1860 && r.Orders[0].ExpiresAt != 1860 {
				t.Fatal("要求時刻でTTL若返り")
			}
		}
	}
	// 末尾境界が5分と一致しない人工でminの末尾側も検査する。
	s := financeSession102()
	s.End = 4250
	s.Force = 4240
	for _, available := range []float64{2449, 2450} {
		d := financeDecision102(2400, 10, 2)
		d.AvailableAt = available
		q := financeQuotes102([3]float64{2400, 1000, 1005}, [3]float64{available, 1000, 1005}, [3]float64{2451, 1000, 1005}, [3]float64{4241, 1000, 1005})
		r := Replay(s, q, []Decision{d}, financeConfig102("P0", 0, 1))
		if !r.Success || r.PosCount != 0 || r.Denom != 3 {
			t.Fatalf("末尾締切: %+v", r)
		}
		if available == 2449 && (len(r.Orders) != 1 || r.Orders[0].ExpiresAt != 2450 || r.Orders[0].Status != "cancelled") {
			t.Fatalf("D1と末尾期限: %+v", r)
		}
		if available == 2450 && (len(r.Orders) != 0 || r.Unknown != 3) {
			t.Fatalf("末尾等号: %+v", r)
		}
	}
}

// TestFinance102V2QuoteAge は、実要求時の気配15秒境界を確認します。
//
// 引数: t(*testing.T)。返り値: なし。欠測枠は同じ分母へ残します。
func TestFinance102V2QuoteAge(t *testing.T) {
	for _, age := range []float64{15, 15.001} {
		q := financeQuotes102([3]float64{1800 - age, 1000, 1005}, [3]float64{1800.1, 1000, 1005}, [3]float64{4191, 1000, 1005})
		r := Replay(financeSession102(), q, []Decision{financeDecision102(1800, 10, 2)}, financeConfig102("P0", 0, 0))
		want := 1
		if age > 15 {
			want = 0
		}
		if !r.Success || r.PosCount != want || r.Denom != 2 {
			t.Fatalf("価格齢: %v %+v", age, r)
		}
		if age > 15 && (r.Unknown != 2 || len(r.Orders) != 0) {
			t.Fatal("古い気配で受理")
		}
	}
}

// TestFinance102V3ProtectionOnlyGrid は、新規除外域でも技法保護を更新します。
//
// 引数: t(*testing.T)。返り値: なし。参加分母に域外枠を足しません。
func TestFinance102V3ProtectionOnlyGrid(t *testing.T) {
	first := financeDecision102(0, 20, 6)
	entry := financeDecision102(1800, 20, 2)
	protection := financeDecision102(2400, 20, 6)
	protection.Side = 0
	protection.BuyProtection.Converged = true
	q := financeQuotes102([3]float64{0, 1000, 1005}, [3]float64{1, 1000, 1005},
		[3]float64{1800, 1000, 1005}, [3]float64{1801, 1000, 1005}, [3]float64{1802, 1050, 1055},
		[3]float64{2400, 1050, 1055}, [3]float64{2401, 1050, 1055}, [3]float64{2402, 1035, 1040},
		[3]float64{2403, 1030, 1035}, [3]float64{4191, 1030, 1035})
	r := Replay(financeSession102(), q, []Decision{first, entry, protection}, financeConfig102("A1", 0, 0))
	if !r.Success || r.PosCount != 1 || r.Denom != 2 || len(r.Grids) != 2 || r.Trades[0].Exit.Quote.Time != 2403 || r.Trades[0].FinalFloor != 1035 {
		t.Fatalf("域外保護幅/新規/分母: %+v", r)
	}
	opposite := protection
	opposite.Side = -1
	r = Replay(financeSession102(), q, []Decision{first, entry, opposite}, financeConfig102("A1", 0, 0))
	if !r.Success || r.PosCount != 1 || r.Denom != 2 || len(r.Orders) != 2 || r.Orders[1].At != 2400 || r.Trades[0].ExitReason != "反対方向と保有複合否定" {
		t.Fatalf("域外反対返済: %+v", r)
	}
	if r.Trades[0].Exit.Quote.Time != 2401 {
		t.Fatal("域外要求原行fill")
	}
}

// TestFinance102Export は、明示された新規先だけへ実Go型の人工を保存します。
//
// 引数: t(*testing.T)、環境変数FINANCE102_EXPORT(string)。返り値: なし。
func TestFinance102Export(t *testing.T) {
	out := os.Getenv("FINANCE102_EXPORT")
	if out == "" {
		t.Skip("明示人工exportなし")
	}
	if err := os.Mkdir(out, 0755); err != nil {
		t.Fatal(err)
	}
	quotes := financeQuotes102([3]float64{1800, 1000, 1005}, [3]float64{1801, 1000, 1005},
		[3]float64{1802, 1040, 1045}, [3]float64{1803, 1005, 1010}, [3]float64{1804, 990, 995}, [3]float64{4191, 990, 995})
	d := financeDecision102(1800, 20, 4)
	results := []Result{}
	for _, policy := range []string{"P0", "A0", "A1"} {
		for _, slip := range []float64{0, 5} {
			for _, delay := range []float64{0, 1} {
				r := Replay(financeSession102(), quotes, []Decision{d}, financeConfig102(policy, slip, delay))
				if !r.Success {
					t.Fatal(r.Error)
				}
				results = append(results, r)
			}
		}
	}
	value := struct {
		Session   Session    `json:"session"`
		Quotes    []Quote    `json:"quotes"`
		Decisions []Decision `json:"decisions"`
		Results   []Result   `json:"results"`
	}{financeSession102(), quotes, []Decision{d}, results}
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(filepath.Join(out, "人工.json"), append(data, '\n'), 0644); err != nil {
		t.Fatal(err)
	}
}
