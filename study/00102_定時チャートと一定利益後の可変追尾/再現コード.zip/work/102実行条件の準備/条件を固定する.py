"""人工確認後の102コード・共有入力・実行物を市場実行前に固定する。"""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile


ROOT = Path(__file__).resolve().parents[2]
MODULE = ROOT / "work/102定時チャート売買_版3"
FORMAL = ROOT / "study/00102_定時チャートと一定利益後の可変追尾"


def digest(path: Path) -> str:
    """
    機能: 明示したコード・資料・実行物の指紋を求める。
    引数: path(Path)は対象ファイル。
    返り値: strは小文字SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dependencies() -> set[Path]:
    """
    機能: Goが実際に参照する標準外コードとモジュール定義を列挙する。
    引数: なし。MODULE(Path)から読み取り専用で依存を解決する。
    返り値: set[Path]は標準ライブラリ以外の既存ファイル。
    """
    run = subprocess.run(["go", "list", "-mod=readonly", "-deps", "-json", "./..."],
                         cwd=MODULE, check=True, capture_output=True, text=True, encoding="utf-8")
    decoder, offset, paths = json.JSONDecoder(), 0, set()
    while offset < len(run.stdout):
        while offset < len(run.stdout) and run.stdout[offset].isspace():
            offset += 1
        if offset == len(run.stdout):
            break
        package, offset = decoder.raw_decode(run.stdout, offset)
        if package.get("Standard"):
            continue
        directory = Path(package["Dir"])
        for field in ("GoFiles", "CgoFiles", "CFiles", "HFiles", "SFiles", "SysoFiles", "EmbedFiles"):
            for name in package.get(field, []):
                paths.add((directory / name).resolve())
        module = package.get("Module", {})
        actual = module.get("Replace", module)
        if actual.get("GoMod"):
            paths.add(Path(actual["GoMod"]).resolve())
        if actual.get("Dir"):
            for name in ("go.mod", "go.sum"):
                p = Path(actual["Dir"]) / name
                if p.is_file():
                    paths.add(p.resolve())
    return paths


def main() -> int:
    """
    機能: 完成コードと実行物から新規の条件JSON・再現コードを保存する。
    引数: なし。既存の54入力・24設定下書きを使う。
    返り値: intは成功0。既に固定した条件の上書きは拒否する。
    """
    condition_path = FORMAL / "条件.json"
    assert not condition_path.exists(), "固定済み条件は上書きしない"
    draft = json.loads((Path(__file__).parent / "入力と設定の下書き.json").read_text(encoding="utf-8"))
    assert draft["fixed"] is False and len(draft["scenes"]) == 54 and len(draft["configs"]) == 24
    exe = MODULE / "検査/定時売買.exe"
    assert exe.is_file(), "人工確認後の実行物が必要"
    paths = dependencies() | set(MODULE.glob("*.go")) | {MODULE / "go.mod", MODULE / "go.sum", Path(__file__).resolve()}
    snapshot = FORMAL / "実行前仕様"
    snapshot.mkdir(exist_ok=False)
    for name in ("README.md", "設定と結果.md"):
        shutil.copy2(FORMAL / name, snapshot / name)
        paths.add(snapshot / name)
    paths.add(FORMAL / "入力の確認.json")
    code = {p.as_posix(): digest(p) for p in sorted(paths)}
    draft["code_sha256"] = code
    draft["binary"] = {"path": exe.as_posix(), "sha256": digest(exe)}
    draft["fixed"] = True
    condition_path.write_text(json.dumps(draft, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    archive = FORMAL / "再現コード.zip"
    with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(paths):
            try:
                name = p.relative_to(ROOT).as_posix()
            except ValueError:
                name = "外部/" + p.drive.replace(":", "") + p.as_posix()[2:]
            z.write(p, name)
        z.writestr("対応.json", json.dumps(code, ensure_ascii=False, indent=2))
    go_version = subprocess.run(["go", "version"], check=True, capture_output=True,
                                text=True, encoding="utf-8").stdout.strip()
    proof = {"成功": True, "固定日": "2026-11-09", "条件SHA256": digest(condition_path),
             "実行物SHA256": digest(exe), "コードと資料数": len(code), "Go": go_version,
             "再現コードSHA256": digest(archive), "市場金融はまだ未実行": True,
             "限界": "Goツールチェーンと参照共有cacheは別。code_zipへ原板やrecordsを複製しない。"}
    (FORMAL / "実行前固定.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    assert all(digest(Path(p)) == sha for p, sha in code.items())
    print(json.dumps(proof, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
