package main

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	chart "github.com/masayoshi4649/SessionTradeExecuter/minichart"
)

// scalarFixture102 は実ScalarQuoteの11JSON欄を手製値で生成します。
//
// 引数: q(Quote)は人工気配。返り値: map[string]anyは公開schemaの人工です。
func scalarFixture102(q Quote) map[string]any {
	return map[string]any{"time": q.Time, "received": q.Time, "index": q.Index, "source_line": q.Index + 10, "last": 1010, "bid": q.Bid, "ask": q.Ask, "quote_ok": q.Valid, "atr": 20, "atr_available": q.Time - 1, "atr_nominal": q.Time - 2}
}

// gzipRecordsFixture102 は人工だけを新規gzipへ保存します。
//
// 引数: t(*testing.T)、path(string)、rows([]any)は検査と器具です。返り値: なし。
func gzipRecordsFixture102(t *testing.T, path string, rows []any) {
	t.Helper()
	f, e := os.Create(path)
	if e != nil {
		t.Fatal(e)
	}
	z := gzip.NewWriter(f)
	enc := json.NewEncoder(z)
	for _, v := range rows {
		if e = enc.Encode(v); e != nil {
			t.Fatal(e)
		}
	}
	if e = z.Close(); e != nil {
		t.Fatal(e)
	}
	if e = f.Close(); e != nil {
		t.Fatal(e)
	}
}

// headerFixture102 はSourceを含まない人工headerを作成します。
//
// 引数: s(Session)、rows(int)、grids([]TechnicalGateInput)は人工公開値です。
// 返り値: Header102はSource/特徴値形成を主張しない器具です。
func headerFixture102(s Session, rows int, grids []chart.TechnicalGateInput) Header102 {
	h := Header102{Version: 1, Streamed: true, RowCount: rows, Grids: grids}
	h.Session.ID = s.ID
	h.Session.Kind = s.Kind
	h.Session.Start = s.Start
	h.Session.End = s.End
	h.Session.Force = s.Force
	return h
}

// writeHeaderFixture102 は人工headerを新規保存して指紋を返します。
//
// 引数: t(*testing.T)、path(string)、h(Header102)。返り値: FileRef102は人工path/SHAです。
func writeHeaderFixture102(t *testing.T, path string, h Header102) FileRef102 {
	t.Helper()
	if e := writeJSON102(path, h, false); e != nil {
		t.Fatal(e)
	}
	sha, e := fileSHA102(path)
	if e != nil {
		t.Fatal(e)
	}
	return FileRef102{path, sha}
}

// TestMain102ScalarProjection は正常/不良・同秒別Index・controlの境界を検査します。
//
// 引数: t(*testing.T)は検査。返り値: なし。市場recordsは読みません。
func TestMain102ScalarProjection(t *testing.T) {
	s := Session{"人工102", "Day", 1000, 9000, 8500}
	path := filepath.Join(t.TempDir(), "人工.records.jsonl.gz")
	quotes := []Quote{{1100, 1, 100, 105, true}, {1100, 2, 0, 0, false}, {1100, 3, 100, 105, true}}
	rows := []any{map[string]any{"kind": "control", "control": map[string]any{"kind": "invalidate", "at": 1099}}}
	for _, q := range quotes {
		rows = append(rows, map[string]any{"kind": "row", "row": map[string]any{"scalar": scalarFixture102(q)}})
	}
	gzipRecordsFixture102(t, path, rows)
	got, bad, control, e := readQuotes102(path, s, 3)
	if e != nil || !reflect.DeepEqual(got, quotes) || bad != 1 || control != 1 {
		t.Fatalf("row/control/不良/同秒維持: %+v %d %d %v", got, bad, control, e)
	}
	for _, name := range []string{"quote_ok欠落", "Index据置", "時計逆行", "Scalar大文字", "空Last", "未知record", "行数不一致", "controlへrow混入"} {
		t.Run(name, func(t *testing.T) {
			qs := []any{}
			for _, q := range quotes {
				qs = append(qs, map[string]any{"kind": "row", "row": map[string]any{"scalar": scalarFixture102(q)}})
			}
			expected := 3
			scalar := qs[1].(map[string]any)["row"].(map[string]any)["scalar"].(map[string]any)
			switch name {
			case "quote_ok欠落":
				delete(scalar, "quote_ok")
			case "Index据置":
				scalar["index"] = 1
			case "時計逆行":
				scalar["time"] = 1099
				scalar["received"] = 1099
			case "Scalar大文字":
				scalar["QuoteOK"] = scalar["quote_ok"]
				delete(scalar, "quote_ok")
			case "空Last":
				scalar["last"] = 0
			case "未知record":
				qs[1].(map[string]any)["kind"] = "invented"
			case "行数不一致":
				expected = 4
			case "controlへrow混入":
				qs[1].(map[string]any)["kind"] = "control"
				qs[1].(map[string]any)["control"] = map[string]any{"kind": "grid"}
			}
			p := filepath.Join(t.TempDir(), "破損.gz")
			gzipRecordsFixture102(t, p, qs)
			if _, _, _, e := readQuotes102(p, s, expected); e == nil {
				t.Fatal("破損を受理")
			}
		})
	}
}

// TestMain102SignalReplay は手製公開Inputから全24条件を非0で結合します。
//
// 引数: t(*testing.T)は検査。返り値: なし。自然Source/特徴値生成の証明ではありません。
func TestMain102SignalReplay(t *testing.T) {
	dir := t.TempDir()
	s := Session{"人工102", "Day", 1200, 6000, 5900}
	g := signalFixture()
	g.Chart.Scene.ID = s.ID
	g.Chart.Scene.Start = s.Start
	for i := range g.Recent3 {
		g.Recent3[i].Scene = g.Chart.Scene
	}
	late := g
	late.At = 4200
	late.SnapshotID = "人工102-末尾保護枠"
	late.Chart.At = 4200
	late.Chart.ObservedClock = 4200
	quotes := []Quote{{2999, 1, 1009, 1011, true}, {3002, 2, 1009, 1011, true}, {3002, 3, 0, 0, false}, {3002, 4, 1009, 1011, true}, {3003, 5, 1009, 1011, true}, {3100, 6, 1050, 1052, true}, {3101, 7, 1000, 1002, true}, {3102, 8, 1000, 1002, true}, {5901, 9, 1000, 1002, true}}
	rows := []any{}
	for _, q := range quotes {
		rows = append(rows, map[string]any{"kind": "row", "row": map[string]any{"scalar": scalarFixture102(q)}})
	}
	records := filepath.Join(dir, "records.gz")
	gzipRecordsFixture102(t, records, rows)
	h := writeHeaderFixture102(t, filepath.Join(dir, "header.json"), headerFixture102(s, len(quotes), []chart.TechnicalGateInput{g, late}))
	rsha, _ := fileSHA102(records)
	input := SceneInput102{s, h, FileRef102{records, rsha}}
	result, e := replayScene102(input, canonicalConfigs102())
	if e != nil {
		t.Fatal(e)
	}
	if len(result.Books) != 24 || result.BadQuoteRows != 1 || len(result.Signals["S3"]) != 2 || len(result.Signals["S4"]) != 2 {
		t.Fatal("全24/信号/不良数")
	}
	for _, b := range result.Books {
		if !b.Success || b.PosCount != 1 || b.OpenQuantity != 0 || b.PendingEntry != 0 || b.PendingExit != 0 || b.Denom != 4 || b.Trades[0].Entry.Quote.Index <= 4 || b.Fee != 462 {
			t.Fatalf("実取得/同秒/半円/完結: %+v", b)
		}
		if b.Config.Slip == 5 && b.Slip != 6000 {
			t.Fatal("滑り費用を別計上していない")
		}
	}
	// ----------------------------------------
	// 最後の正常気配を取り去るとForce予約が未返済となり、成功へ補完しない。
	g.Current.Bid, g.Current.Ask = 1009, 1011
	g.Chart.Chart.Technical.ATR3 = 500
	syncSignalLatest(&g)
	h2 := headerFixture102(s, 5, []chart.TechnicalGateInput{g})
	input.Header = writeHeaderFixture102(t, filepath.Join(dir, "未完header.json"), h2)
	short := filepath.Join(dir, "未完.gz")
	gzipRecordsFixture102(t, short, rows[:5])
	input.Records.Path = short
	if _, e = replayScene102(input, canonicalConfigs102()); e == nil {
		t.Fatal("未完結を成功化")
	}
}

// conditionFixture102 は実市場本文を持たない完全54metadata器具を作ります。
//
// 引数: t(*testing.T)は検査。返り値: Args102/string/stringは引数/repo/模擬実行物です。
func conditionFixture102(t *testing.T) (Args102, string, string) {
	t.Helper()
	root := t.TempDir()
	inputDir := filepath.Join(root, "固定入力")
	if e := os.Mkdir(inputDir, 0700); e != nil {
		t.Fatal(e)
	}
	code := map[string]string{}
	for _, n := range []string{"main.go", "api.go", "会計.go", "信号.go", "go.mod", "go.sum"} {
		p := filepath.Join(root, n)
		if e := os.WriteFile(p, []byte("人工metadata\n"), 0600); e != nil {
			t.Fatal(e)
		}
		h, _ := fileSHA102(p)
		code[n] = h
	}
	bin := filepath.Join(root, "人工.exe")
	if e := os.WriteFile(bin, []byte("実行しない模擬binary"), 0600); e != nil {
		t.Fatal(e)
	}
	bs, _ := fileSHA102(bin)
	receipt := filepath.Join(root, "入力由来.json")
	c := Condition102{Version: 1, Trial: 102, Fixed: true, Configs: canonicalConfigs102(), Code: code, Binary: FileRef102{"人工.exe", bs}}
	for _, s := range allowedSessions102() {
		header := filepath.Join(inputDir, s.ID+".header.json")
		h := writeHeaderFixture102(t, header, headerFixture102(s, 1, nil))
		records := filepath.Join(inputDir, s.ID+".gz")
		q := Quote{s.Start + 1, 1, 1000, 1005, true}
		gzipRecordsFixture102(t, records, []any{map[string]any{"kind": "row", "row": map[string]any{"scalar": scalarFixture102(q)}}})
		sha, _ := fileSHA102(records)
		h.Path, _ = filepath.Rel(root, header)
		rp, _ := filepath.Rel(root, records)
		c.Scenes = append(c.Scenes, SceneInput102{s, h, FileRef102{rp, sha}})
	}
	r := InputReceipt102{Success: true, Stage: "full54", Unchanged: true, Proof100SHA: "4a8bc486e329f65f17e2395f781b2efd7cf76c5630d91924b611e90254725af3"}
	for _, s := range c.Scenes {
		r.Sessions = append(r.Sessions, s.Session.ID)
		d := struct {
			Session    string `json:"session"`
			Header     string `json:"header"`
			HeaderSHA  string `json:"header_SHA256"`
			Records    string `json:"path"`
			RecordsSHA string `json:"SHA256"`
		}{s.Session.ID, s.Header.Path, s.Header.SHA, s.Records.Path, s.Records.SHA}
		r.Details = append(r.Details, d)
	}
	if e := writeJSON102(receipt, r, false); e != nil {
		t.Fatal(e)
	}
	rs, _ := fileSHA102(receipt)
	c.InputReceipt = FileRef102{"入力由来.json", rs}
	cp := filepath.Join(root, "条件.json")
	if e := writeJSON102(cp, c, false); e != nil {
		t.Fatal(e)
	}
	sha, _ := fileSHA102(cp)
	return Args102{Condition: cp, ConditionSHA: sha, Stage: "first2", Out: filepath.Join(root, "先頭2"), Workers: 2}, root, bin
}

// mutateCondition102 は人工条件だけを別ファイルへ変更します。
//
// 引数: t(*testing.T)、a(Args102)、change(func)は検査/元条件/変更です。返り値: Args102は新条件です。
func mutateCondition102(t *testing.T, a Args102, change func(*Condition102)) Args102 {
	t.Helper()
	b, e := os.ReadFile(a.Condition)
	if e != nil {
		t.Fatal(e)
	}
	var c Condition102
	if e = json.Unmarshal(b, &c); e != nil {
		t.Fatal(e)
	}
	change(&c)
	a.Condition = filepath.Join(filepath.Dir(a.Condition), "破損条件.json")
	if e = writeJSON102(a.Condition, c, false); e != nil {
		t.Fatal(e)
	}
	a.ConditionSHA, _ = fileSHA102(a.Condition)
	return a
}

// TestMain102MetadataGuards は本文処理前の集合/指紋/未固定拒否を検査します。
//
// 引数: t(*testing.T)は検査。返り値: なし。市場の54ファイルは生成/読取しません。
func TestMain102MetadataGuards(t *testing.T) {
	for _, name := range []string{"正常", "53場", "55場", "新日", "重複場", "入力偽SHA", "23設定", "政策入替", "未固定", "code欠落", "binary別path", "空receiptSHA", "条件偽SHA", "workers超過", "full先頭なし"} {
		t.Run(name, func(t *testing.T) {
			a, root, bin := conditionFixture102(t)
			if name != "正常" && name != "条件偽SHA" && name != "workers超過" && name != "full先頭なし" {
				a = mutateCondition102(t, a, func(c *Condition102) {
					switch name {
					case "53場":
						c.Scenes = c.Scenes[:53]
					case "55場":
						c.Scenes = append(c.Scenes, c.Scenes[0])
					case "新日":
						c.Scenes[3].Session.ID = "2026-11-01_Night"
					case "重複場":
						c.Scenes[1] = c.Scenes[0]
					case "入力偽SHA":
						c.Scenes[0].Header.SHA = strings.Repeat("0", 64)
					case "23設定":
						c.Configs = c.Configs[:23]
					case "政策入替":
						c.Configs[0].EntryPolicy = "E3S"
					case "未固定":
						c.Fixed = false
					case "code欠落":
						delete(c.Code, "main.go")
					case "binary別path":
						c.Binary.Path = "別.exe"
					case "空receiptSHA":
						c.InputReceipt.SHA = ""
					}
				})
			}
			if name == "条件偽SHA" {
				a.ConditionSHA = strings.Repeat("0", 64)
			}
			if name == "workers超過" {
				a.Workers = 5
			}
			if name == "full先頭なし" {
				a.Stage = "full54"
			}
			_, scenes, _, e := prepare102(a, root, bin)
			if name == "正常" {
				if e != nil || len(scenes) != 2 {
					t.Fatal(e)
				}
			} else if e == nil {
				t.Fatal("metadata破損を受理")
			}
			if _, e = os.Stat(a.Out); !os.IsNotExist(e) {
				t.Fatal("guard中に出力を作成")
			}
		})
	}
}

// TestMain102DuplicateJSON は条件JSONの重複・未知欄を拒否します。
//
// 引数: t(*testing.T)は検査。返り値: なし。
func TestMain102DuplicateJSON(t *testing.T) {
	for _, data := range []string{`{"version":1,"version":1}`, `{"version":1,"future_policy":true}`, `{"version":1} {}`, `{"configs":[{"name":"a","name":"b"}]}`} {
		var c Condition102
		if e := strictJSON102([]byte(data), &c, true); e == nil {
			t.Fatal("JSON破損を受理", data)
		}
	}
}

// TestMain102InputReceiptBinding はSHA自体が正しくても別由来や入替を拒否します。
//
// 引数: t(*testing.T)は検査。返り値: なし。生成済み市場入力は開きません。
func TestMain102InputReceiptBinding(t *testing.T) {
	for _, name := range []string{"生成失敗", "Source再運転", "別100", "sessions重複", "details欠落", "header入替", "stream偽SHA"} {
		t.Run(name, func(t *testing.T) {
			a, root, bin := conditionFixture102(t)
			rp := filepath.Join(root, "入力由来.json")
			b, _ := os.ReadFile(rp)
			var r InputReceipt102
			_ = json.Unmarshal(b, &r)
			switch name {
			case "生成失敗":
				r.Success = false
			case "Source再運転":
				r.SourceReexecuted = true
			case "別100":
				r.Proof100SHA = strings.Repeat("0", 64)
			case "sessions重複":
				r.Sessions[1] = r.Sessions[0]
			case "details欠落":
				r.Details = r.Details[:53]
			case "header入替":
				r.Details[0].Header = r.Details[1].Header
			case "stream偽SHA":
				r.Details[0].RecordsSHA = strings.Repeat("0", 64)
			}
			b, _ = json.Marshal(r)
			if e := os.WriteFile(rp, b, 0600); e != nil {
				t.Fatal(e)
			}
			h, _ := fileSHA102(rp)
			a = mutateCondition102(t, a, func(c *Condition102) { c.InputReceipt.SHA = h })
			if _, _, _, e := prepare102(a, root, bin); e == nil {
				t.Fatal("別生成metadataを受理")
			}
		})
	}
}

// TestMain102First2Full54 は同固定条件の2→54と全出力SHAを人工で結びます。
//
// 引数: t(*testing.T)は検査。返り値: なし。全帳簿は空の人工で、非0結合とは別scopeです。
func TestMain102First2Full54(t *testing.T) {
	a, root, bin := conditionFixture102(t)
	first, e := run102(a, root, bin)
	if e != nil || !first.Success || first.Books != 48 {
		t.Fatal(e)
	}
	firstPath := filepath.Join(a.Out, "完了.json")
	firstSHA, _ := fileSHA102(firstPath)
	a.Stage = "full54"
	a.Out = filepath.Join(root, "全54")
	a.First2 = firstPath
	a.First2SHA = firstSHA
	a.Workers = 4
	full, e := run102(a, root, bin)
	if e != nil || !full.Success || full.Books != 1296 || !full.Unchanged || len(full.Results) != 54 {
		t.Fatalf("2→54: %+v %v", full, e)
	}
	for _, r := range full.Results {
		sha, e := fileSHA102(r.Path)
		if e != nil || sha != r.SHA || r.Books != 24 {
			t.Fatal("出力SHA/24条件")
		}
		for _, tot := range r.Totals {
			if tot.Gross != 0 || tot.Net != 0 || tot.Positions != 0 || tot.Active != 0 || (tot.Denom != 72 && tot.Denom != 144) {
				t.Fatal("空帳簿の母数を落とした")
			}
		}
	}
	if _, e = run102(a, root, bin); e == nil {
		t.Fatal("既存出力を上書き")
	}
	// ----------------------------------------
	// first2成功だけを捏造/別条件へ転用しても、本文出力の前に拒否する。
	first.Success = false
	b, _ := json.Marshal(first)
	badPath := filepath.Join(root, "先頭失敗.json")
	if e = os.WriteFile(badPath, b, 0600); e != nil {
		t.Fatal(e)
	}
	a.Out = filepath.Join(root, "拒否")
	a.First2 = badPath
	a.First2SHA, _ = fileSHA102(badPath)
	if _, _, _, e = prepare102(a, root, bin); e == nil {
		t.Fatal("失敗first2を成功へ転用")
	}
}

// TestMain102ForceSchema は旧force_closeの明示変換と場clock照合を確認します。
//
// 引数: t(*testing.T)は検査。返り値: なし。
func TestMain102ForceSchema(t *testing.T) {
	a, _, _ := conditionFixture102(t)
	var c Condition102
	b, _ := os.ReadFile(a.Condition)
	_ = json.Unmarshal(b, &c)
	s := c.Scenes[0]
	s.Header.Path = filepath.Join(filepath.Dir(a.Condition), s.Header.Path)
	h, e := readHeader102(s)
	if e != nil || h.Session.Force != s.Session.Force {
		t.Fatal("force_close変換", e)
	}
	data, _ := os.ReadFile(s.Header.Path)
	data = bytes.ReplaceAll(data, []byte("force_close"), []byte("force"))
	p := filepath.Join(filepath.Dir(a.Condition), "誤clock.json")
	if e = os.WriteFile(p, data, 0600); e != nil {
		t.Fatal(e)
	}
	s.Header.Path = p
	if _, e = readHeader102(s); e == nil {
		t.Fatal("旧force欄を推測補完")
	}
	if len(allowedSessions102()) != 54 || len(canonicalConfigs102()) != 24 {
		t.Fatal(fmt.Errorf("固定集合件数"))
	}
}
