"""既存Viewerへ102一覧を読み込み、代表4資源の保存純額を確認する。"""

from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
import hashlib
import json
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parents[2]
BASE = "http://127.0.0.1:8092"
CATALOG = ROOT / "study/00102_定時チャートと一定利益後の可変追尾/成果物_版2/一覧.resources.json"
RECEIPT = ROOT / "work/102市場再生_版2/全54場/完了.json"


def request(route: str, payload: dict | None = None) -> tuple[dict, str]:
    """
    機能: 既存Viewerの情報・一覧読込・表示データだけを取得する。
    引数: route(str)、payload(dict|None)は相対APIと一覧パス。
    返り値: tuple[dict,str]は応答JSONと本文SHA256。
    """
    body = None if payload is None else json.dumps(payload).encode("utf-8")
    req = Request(BASE + route, data=body, headers={"Content-Type": "application/json"})
    with urlopen(req, timeout=60) as response:
        raw = response.read()
        sha = hashlib.sha256(raw).hexdigest()
        claimed = response.headers.get("x-chart-data-sha256")
        if claimed is not None:
            assert claimed == sha
        return json.loads(raw, parse_float=Decimal), sha


def main() -> None:
    """
    機能: 4表示の約定数・費用後純額・残0を保存金融へ結ぶ。
    引数: なし。固定した102完了と生成済み一覧を使う。
    返り値: None。全1296表示の実GET検証とは呼ばない。
    """
    code = Path(__file__).resolve()
    paths = [CATALOG, RECEIPT, code]
    before = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    native = json.loads(RECEIPT.read_text(encoding="utf-8"))
    assert native["success"] and native["books"] == 1296
    resources = json.loads(CATALOG.read_text(encoding="utf-8"))["resources"]
    info, _ = request("/api/info")
    assert Path(info["resource_root"]).resolve() == ROOT
    loaded, _ = request("/api/catalogs/load", {"path": CATALOG.relative_to(ROOT).as_posix()})
    assert len(loaded["resources"]) == len(resources) == 1296
    selected = [("S4_A0_C0_D0", "2026-09-21_Night"), ("S4_A1_C0_D0", "2026-09-21_Night"),
                ("S3_A1_C5_D1", "2026-10-06_Day"), ("S4_P0_C5_D0", "2026-10-27_Night")]
    expected = {(scene["session"], key): value["net"] for scene in native["results"] for key, value in scene["totals"].items()}

    def check(item: tuple[str, str]) -> dict:
        """
        機能: 一資源の表示会計を保存実約定と照合する。
        引数: item(tuple[str,str])は設定KeyとセッションID。
        返り値: dictは限定した照合証拠。
        """
        key, session = item
        identity = f"102_{key}_{session}"
        resource = next(r for r in resources if r["id"] == identity)
        trades = CATALOG.parent / resource["pnl_path"]
        original = trades.read_bytes()
        query = urlencode({"catalog": loaded["catalog_id"], "resource": identity, "width": 1, "interval": "raw", "price": "last"})
        value, sha = request("/api/data?" + query)
        summary = value["summary"]
        assert value["resource"]["id"] == identity
        assert summary["realized_pnl_yen"] == expected[(session, key)]
        assert summary["long_qty"] == summary["short_qty"] == summary["unrealized_pnl_yen"] == 0
        assert len(value["events"]) == len(original.splitlines())
        assert original == trades.read_bytes()
        return {"id": identity, "実約定行": len(value["events"]), "純額": expected[(session, key)], "本文SHA256": sha}

    with ThreadPoolExecutor(max_workers=4) as pool:
        details = list(pool.map(check, selected))
    assert before == {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    proof = {"成功": True, "scope": "一覧1296読込と代表4資源の実表示・保存純額一致。全表示の検証ではない",
             "一覧資源数": 1296, "実GET資源": 4, "details": details, "入力コードSHA256": before,
             "前後不変": True, "server停止再起動設定変更": 0, "金融再実行": 0, "Source再形成": 0}
    out = ROOT / "study/00102_定時チャートと一定利益後の可変追尾/検査/全54場/Viewer代表4資源.json"
    assert not out.exists()
    out.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "一覧": 1296, "実表示": 4, "照合差": 0}, ensure_ascii=False))


if __name__ == "__main__":
    main()
