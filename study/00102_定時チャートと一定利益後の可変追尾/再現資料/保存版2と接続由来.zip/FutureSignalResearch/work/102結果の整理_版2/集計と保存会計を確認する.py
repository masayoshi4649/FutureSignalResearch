"""102の保存約定算術と限定因果を検算し、実績とViewer資料を生成する。"""

import argparse
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
POINT, FEE = Decimal(100), Decimal("38.5")
ZERO = Decimal(0)
KEYS = [f"{entry}_{trail}_C{cost}_D{delay}" for entry in ("S3", "S4") for trail in ("P0", "A0", "A1") for cost in (0, 5) for delay in (0, 1)]


def need(value, reason):
    """
    機能: 保存矛盾を成功へ変換せず停止する。
    引数: value(bool)、reason(str)は条件と理由。
    返り値: None。
    """
    if not value:
        raise ValueError(reason)


def dec(value):
    """
    機能: 保存数値を有限Decimalへ統一する。
    引数: value(int/float/Decimal)はJSON数値。
    返り値: Decimalは小数会計値。
    """
    need(not isinstance(value, bool) and isinstance(value, (int, float, Decimal)), "数値型")
    result = Decimal(str(value))
    need(result.is_finite(), "非有限値")
    return result


def equal(actual, expected, reason, tolerance=ZERO):
    """
    機能: 算術の期待値を保存値と照合する。
    引数: actual/expected(数値)、reason(str)、tolerance(Decimal)。
    返り値: None。許容差はGo表示の比率/単価だけに明示する。
    """
    need(abs(dec(actual)-dec(expected)) <= tolerance, reason)


def equal_float(actual, expected, reason):
    """
    機能: 非金融の価格線/比率を元IEEE64演算結果と厳密比較する。
    引数: actual(保存数値)、expected(float)、reason(str)は価格線又は比率だけ。
    返り値: None。BBO/実額/数量/時計/Indexには使わない。
    """
    need(float(dec(actual)) == expected, reason)


def digest(path):
    """
    機能: 明示した通常ファイルの指紋を得る。
    引数: path(Path)はコード/metadata又はRoot許可Native。
    返り値: strはSHA256。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load_json(path):
    """
    機能: 小数をDecimalとしてJSON又はgzipを読む。
    引数: path(Path)は許可した保存ファイル。
    返り値: dict/listは保存値。
    """
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as stream:
        return json.load(stream, parse_float=Decimal)


def plain(value):
    """
    機能: 半円を維持してJSON出力可能な値へ変換する。
    引数: value(any)は集計値。
    返り値: anyはJSON互換。
    """
    if isinstance(value, Decimal):
        return int(value) if value == value.to_integral_value() else float(value)
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    return value


def write_json(path, value):
    """
    機能: 既存証拠を上書きせずJSONを保存する。
    引数: path(Path)、value(any)は新規先と値。
    返り値: None。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(plain(value), stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def configurations():
    """
    機能: mainと同じ24設定を順序固定で得る。
    引数: なし。
    返り値: dictはkeyから公開Configへの対応。
    """
    return {f"{e}_{t}_C{c}_D{d}": {"name": f"{e}_{t}_C{c}_D{d}", "entry_policy": e, "trail_policy": t, "slip": c, "delay": d}
            for e in ("S3", "S4") for t in ("P0", "A0", "A1") for c in (0, 5) for d in (0, 1)}


def fill_stamp(fill):
    """
    機能: 保存約定の時計/Indexを一意な順序へする。
    引数: fill(dict)は実Fill。
    返り値: tupleは価格時計とFeaturesIndex。
    """
    return dec(fill["quote"]["time"]), fill["quote"]["index"]


def fingerprint(trade, orders):
    """
    機能: 同実入口だけへ出口差を帰属する指紋を作る。
    引数: trade(dict)、orders(dict)は実玉と注文ID索引。
    返り値: tupleは要求/取得の全公開属性とATR。
    """
    f = trade["entry"]
    order = orders[f["order_id"]]
    quote = tuple(sorted(f["quote"].items()))
    return (order["at"], order["grid_at"], order["request_index"], quote,
            trade["side"], f["price"], trade["qty"], trade["entry_atr"])


def verify_book(book, session, key):
    """
    機能: 全実約定の算術・保存因果・単一所有・分類・保存DDを検算する。
    引数: book/session(dict)、key(str)は公開Result/場/24key。
    返り値: dictは統計材料。原板の最初eligible行や全MTMの再生証明ではない。
    """
    need(book["success"] is True and not book.get("error") and book["session"] == session, "成功場とBook")
    need(book["config"] == configurations()[key], "24設定本名")
    need(all(book[n] == 0 for n in ("open_quantity", "pending_entry", "pending_exit")), "終了残0")
    orders, fills, trades = book["orders"] or [], book["fills"] or [], book["trades"] or []
    oo = {o["id"]: o for o in orders}
    ff = {f["order_id"]: f for f in fills}
    tt = {t["id"]: t for t in trades}
    need(len(oo) == len(orders) and len(ff) == len(fills) and len(tt) == len(trades), "注文/約定/玉ID一意")
    config = book["config"]
    start, end, force = (dec(session[n]) for n in ("start", "end", "force"))
    fee, slip, gross, previous = ZERO, ZERO, ZERO, None
    quantities, closed, entries = {}, set(), {}
    for f in fills:
        o = oo.get(f["order_id"])
        need(o is not None and o["status"] == "filled" and f["kind"] == o["kind"] and f["position_id"] == o["position_id"], "注文と実Fill")
        need(f["side"] == o["side"] and f["qty"] == o["qty"] and type(f["qty"]) is int and 0 < f["qty"] <= 10, "売買と数量")
        q, stamp = f["quote"], fill_stamp(f)
        need(q["valid"] is True and dec(q["bid"]) > 0 and dec(q["ask"]) > dec(q["bid"]), "正常BBO fill")
        need(type(q["index"]) is int and q["index"] > o["request_index"] and stamp[0] >= dec(o["at"])+dec(config["delay"]), "strict後行/D1")
        need(start <= stamp[0] <= end and (previous is None or stamp >= previous), "場内/実fill順")
        previous = stamp
        equal(f["price"], q["ask"] if f["side"] > 0 else q["bid"], "実約定気配")
        equal(f["fee"], FEE*f["qty"], "38.5円単価")
        equal(f["slip"], dec(config["slip"])*POINT*f["qty"], "追加滑り別費用")
        fee += dec(f["fee"])
        slip += dec(f["slip"])
        pid = f["position_id"]
        if f["kind"] == "entry":
            need(not any(quantities.values()) and pid not in entries, "単一保有/取得一回")
            need(dec(o["grid_at"]) >= start+1800 and dec(o["grid_at"]) < end-1800 and dec(o["at"]) < force, "新規窓/Force")
            equal(o["expires_at"], min(dec(o["grid_at"])+60, end-1800), "論理TTL/cutoff")
            need(stamp[0] < dec(o["expires_at"]), "TTL等号はfill不可")
            quantities[pid], entries[pid] = f["qty"], f
        else:
            need(f["kind"] == "exit" and pid in entries and quantities.get(pid) == f["qty"] and f["side"] == -entries[pid]["side"], "返済の実所有/予約量")
            quantities[pid] = 0
            closed.add(pid)
    need(not any(quantities.values()) and len(closed) == len(trades) == len(entries), "全玉完結")
    for o in orders:
        need(o["kind"] in ("entry", "exit") and o["status"] in ("filled", "cancelled"), "終了注文状態")
        if o["status"] == "filled":
            need(o["id"] in ff, "filledの実Fill欠落")
        else:
            need(o["kind"] == "entry" and o["id"] not in ff and dec(o["cancel_at"]) >= dec(o["at"]), "取消は未取得entryだけ")
        if o["kind"] == "entry":
            deadline = min(dec(o["grid_at"])+60, end-1800)
            equal(o["expires_at"], deadline, "全entry TTL")
            need(start+1800 <= dec(o["grid_at"]) < end-1800 and dec(o["at"]) < min(deadline, force), "全entry要求時計")
    realized, prior_cash = [], ZERO
    for t in trades:
        entry, exit_ = t["entry"], t["exit"]
        need(entry == entries[t["id"]] and exit_ == ff[exit_["order_id"]] and t["side"] == entry["side"] and t["qty"] == entry["qty"], "Trade実fill全文")
        need(fill_stamp(exit_) > fill_stamp(entry), "取得後の返済")
        g = dec(t["side"])*(dec(exit_["price"])-dec(entry["price"]))*POINT*t["qty"]
        f = dec(entry["fee"])+dec(exit_["fee"])
        s = dec(entry["slip"])+dec(exit_["slip"])
        for name, value in (("gross", g), ("fee", f), ("slip", s), ("net", g-f-s)):
            equal(t[name], value, "実玉算術:"+name)
        gross += g
        need(dec(t["entry_atr"]) > 0, "取得までに公開されたATR")
        # 元Go: f.Price-float64(f.Side)*math.Max(20,2*e.atr)。
        # 公開JSONのATRをIEEE64へ復元し、同じ演算順だけを用いる。
        stop = float(entry["price"])-float(t["side"])*max(20.0, 2.0*float(t["entry_atr"]))
        equal_float(t["initial_stop"], stop, "固定初期stopのIEEE64同値")
        need(t["side"]*(dec(t["final_floor"])-dec(t["initial_stop"])) >= 0, "最終床の非緩和必要条件")
        if t["had_positive_unit"]:
            need(dec(entry["quote"]["time"]) <= dec(t["first_positive_at"]) <= dec(exit_["quote"]["time"]), "初回u正益の保有内時計")
        else:
            need(not t.get("first_positive_at") and g-f-s <= 0, "正益未観測と実現正益の矛盾")
        if t["activated"]:
            need(t["had_positive_unit"] and dec(t["first_positive_at"]) <= dec(t["activation_at"]) <= dec(exit_["quote"]["time"]), "起動/先行正益")
            unit = dec(t["activation_unit_points"])
            minimum = ZERO if config["trail_policy"] == "P0" else max(Decimal(10), dec(t["entry_atr"])/2)
            need(unit > 0 and unit+Decimal("0.000000001") >= minimum and entry["quote"]["index"] <= t["activation_index"] <= exit_["quote"]["index"], "起動余裕/Index")
            need(t["side"]*(dec(t["final_floor"])-dec(entry["price"])) >= 0, "起動後最低建値")
            if config["trail_policy"] != "P0":
                cost = 2*FEE/POINT+2*dec(config["slip"])
                cost_floor = (cost/5).to_integral_value(rounding="ROUND_CEILING")*5
                need(t["side"]*(dec(t["final_floor"])-dec(entry["price"])) >= cost_floor, "A0/A1費用回収床")
            # 保存口座峰から得た単価上限と保存unitの必要整合だけをptで確認。
            # 金額自体は保存点と厳密比較済み。許容は1e-9ptへ局所化する。
            peak_unit = (dec(book["peak_equity"])-prior_cash)/POINT/t["qty"]
            need(peak_unit+Decimal("0.000000001") >= unit, "起動単価と保存口座峰の整合")
        else:
            need(not t.get("activation_at") and not t.get("activation_index") and not t.get("activation_unit_points"), "非起動に起動点")
        realized.append(dec(t["net"]))
        prior_cash += dec(t["net"])
    for name, value in (("gross", gross), ("fee", fee), ("slip", slip), ("net", gross-fee-slip)):
        equal(book[name], value, "Book会計:"+name)
    equal(sum(realized), book["net"], "全玉net合計")
    equal(book["poscount"], len(trades), "完結回数")
    equal(book["activated_positions"], sum(t["activated"] for t in trades), "Activated分母")
    grids = book["grids"] or []
    expected = list(range(int(start)+1800, int(end)-1800, 300))
    need([g["at"] for g in grids] == expected, "欠測込み全新規分母")
    actions = Counter()
    for row in grids:
        at = dec(row["at"])
        new = any(o["kind"] == "entry" and o["grid_at"] == row["at"] and o["status"] == "filled" for o in orders)
        held = any(dec(t["entry"]["quote"]["time"]) <= at < dec(t["exit"]["quote"]["time"]) for t in trades)
        need(row["action"] in ("new", "hold", "wait", "unknown"), "4分類")
        if new:
            need(row["action"] == "new", "要求枠の実取得成功分類")
        elif held:
            need(row["action"] == "hold", "logical Atの実保有分類")
        else:
            d = row["decision"]
            pub = max(at, dec(d["available_at"]))
            held_pub = any(dec(t["entry"]["quote"]["time"]) <= pub < dec(t["exit"]["quote"]["time"]) for t in trades)
            pending = any(o["kind"] == "entry" and dec(o["at"]) <= pub
                          and (dec(ff[o["id"]]["quote"]["time"]) if o["status"] == "filled" else dec(o["cancel_at"])) > pub for o in orders)
            accepted = any(o["kind"] == "entry" and o["grid_at"] == row["at"] for o in orders)
            wait = held_pub or pending or pub >= force or d["known"] and d["side"] == 0 or accepted
            need(row["action"] == ("wait" if wait else "unknown"), "保存判断と実所有/受理からの待機・未知分類")
        actions[row["action"]] += 1
    for field, action in (("new", "new"), ("hold", "hold"), ("wait", "wait"), ("unknown", "unknown")):
        equal(book[field], actions[action], "分類合計")
    equal(book["denom"], len(expected), "全予定枠")
    equal(book["active"], actions["new"]+actions["hold"], "活動の和集合")
    equal_float(book["participation"], float(book["active"])/float(len(expected)), "活動率のIEEE64同値")
    points = book["equity_points"] or []
    need(points and points[-1]["phase"] == "finish", "保存終端点")
    peak, trough, dd = ZERO, ZERO, ZERO
    prior = None
    for p in points:
        stamp = (dec(p["at"]), p["index"], {"pre_fill": 0, "after_fill": 1, "finish": 2}[p["phase"]])
        need(prior is None or stamp >= prior, "保存極値点の因果順")
        prior = stamp
        value = dec(p["equity"])
        peak, trough = max(peak, value), min(trough, value)
        dd = max(dd, peak-value)
    equal(points[-1]["equity"], book["net"], "flat場末時価=実現")
    equal(book["peak_equity"], peak, "保存峰")
    equal(book["min_equity"], trough, "保存谷")
    equal(book["dd"], dd, "保存点からの場内DD")
    return {"book": book, "orders": oo, "trades": tt, "realized": realized, "points": points,
            "entry_quantity": sum(t["qty"] for t in trades), "accepted": sum(o["kind"] == "entry" for o in orders)}


def statistics(checked):
    """
    機能: 実現額・実損失分母と保存点連結DDを集約する。
    引数: checked(list[dict])は場順の検算済み材料。
    返り値: dictは実績指標。未参加や退出後の価格は使わない。
    """
    nets = [n for row in checked for n in row["realized"]]
    trades = [t for row in checked for t in row["trades"].values()]
    books = [row["book"] for row in checked]
    positive, negative = sum((x for x in nets if x > 0), ZERO), sum((x for x in nets if x < 0), ZERO)
    carry, peak, dd = ZERO, ZERO, ZERO
    for row in checked:
        for p in row["points"]:
            value = carry+dec(p["equity"])
            peak = max(peak, value)
            dd = max(dd, peak-value)
        carry += dec(row["book"]["net"])
    result = {n: sum((dec(b[n]) for b in books), ZERO) for n in ("gross", "fee", "slip", "net")}
    result.update(完結玉=len(nets), 取得枚数=sum(t["qty"] for t in trades), 勝ち=sum(n > 0 for n in nets), 負け=sum(n < 0 for n in nets), 同値=sum(n == 0 for n in nets),
                  正額=positive, 負額=negative, PF=positive/abs(negative) if negative else None, 保存点連結時価DD=dd,
                  新規要求受理=sum(row["accepted"] for row in checked), 新規実約定玉=len(nets))
    for flag, label in (("had_positive_unit", "u正益"), ("activated", "Activated")):
        group = [t for t in trades if t[flag]]
        bad = [t for t in group if dec(t["net"]) < 0]
        result[label] = {"観測玉": len(group), "最終赤字玉": len(bad), "最終赤字額": sum((dec(t["net"]) for t in bad), ZERO)}
    counts = {n: sum(int(b[n]) for b in books) for n in ("new", "hold", "wait", "unknown", "active", "denom")}
    rate = dec(counts["active"])/counts["denom"] if counts["denom"] else ZERO
    result["活動"] = {**counts, "率": rate, "最低25%": counts["active"]*4 >= counts["denom"] if counts["denom"] else False,
                      "目標50%": counts["active"]*2 >= counts["denom"] if counts["denom"] else False,
                      "定義": "後続実fillした要求枠newとlogical Atの実保有hold。要求受理/asof取得済み率とは別"}
    return result


def compare_entries(before, after):
    """
    機能: 同じ定時方向候補と実入口からA1対A0の実額差を分解する。
    引数: before/after(dict)は同場同costの検算済みBook材料。
    返り値: dictは同実入口/取得変更/片側実参加額。
    """
    groups = []
    for row in (before, after):
        indexed = {}
        for t in row["trades"].values():
            order = row["orders"][t["entry"]["order_id"]]
            k = (order["grid_at"], t["side"])
            need(k not in indexed, "同枠同方向の実玉重複")
            indexed[k] = t
        groups.append(indexed)
    a, b = groups
    result = {name: {"玉": 0, "前実額": ZERO, "後実額": ZERO, "差": ZERO} for name in ("同実入口の出口差", "取得変更", "前だけ実参加", "後だけ実参加")}
    for k in a.keys() | b.keys():
        x, y = a.get(k), b.get(k)
        name = "取得変更" if x and y else ("前だけ実参加" if x else "後だけ実参加")
        if x and y and fingerprint(x, before["orders"]) == fingerprint(y, after["orders"]):
            name = "同実入口の出口差"
        p, q = dec(x["net"]) if x else ZERO, dec(y["net"]) if y else ZERO
        result[name]["玉"] += 1
        result[name]["前実額"] += p
        result[name]["後実額"] += q
        result[name]["差"] += q-p
    total = dec(after["book"]["net"])-dec(before["book"]["net"])
    equal(sum(r["差"] for r in result.values()), total, "取得変更を含む全差分解")
    return {"差": total, "分解": result}


def viewer_trades(checked, session, key):
    """
    機能: 実Fillだけを既存schema1のViewer約定へ写す。
    引数: checked(dict)、session/key(str)は検算材料と識別。
    返り値: list[dict]は半円費用維持の約定列。物理Lineは未保存なので創作しない。
    """
    out = []
    for i, f in enumerate(checked["book"]["fills"] or []):
        side = f["side"] if f["kind"] == "entry" else -f["side"]
        stamp = datetime.fromtimestamp(float(f["quote"]["time"]), timezone(timedelta(hours=9))).isoformat()
        out.append({"id": f"102_{session}_{key}_F{i+1:06d}", "timestamp": stamp,
                    "type": ("Long" if side > 0 else "Short")+("N" if f["kind"] == "entry" else "R"),
                    "position_id": f["position_id"], "price": f["price"], "qty": f["qty"],
                    "fee_yen": dec(f["fee"])+dec(f["slip"]), "method_id": key})
    return out


def inspect_scene(value):
    """
    機能: 新Native24会計を保存検算し全件転記しない材料を返す。
    引数: value(dict)はRoot成功後に許可した新SceneResult102又は人工。
    返り値: dictはkeyごとの検算材料。
    """
    need(value["version"] == 1 and value["trial"] == 102 and set(value["books"]) == set(KEYS), "新102全24集合")
    need(value["source_reexecuted"] is False and value["charts_recomputed"] is False, "再生成なし")
    return {key: verify_book(value["books"][key], value["session"], key) for key in KEYS}


def prepare(fixed_path, fixed_sha, output):
    """
    機能: Root固定の条件/full54完了/保存codeの3参照だけを本文前照合する。
    引数: fixed_path/output(Path)、fixed_sha(str)は固定宣言/新規先/そのSHA。
    返り値: tupleは新Nativeタスク、前指紋、固定証拠。
    """
    need(digest(fixed_path) == fixed_sha, "Root固定SHA")
    f = load_json(fixed_path)
    need(set(f) == {"version", "trial", "fixed", "stage", "condition", "completion", "code"}
         and f["version"] == 1 and f["trial"] == 102 and f["fixed"] is True and f["stage"] == "full54", "未固定市場拒否")
    need(not output.exists(), "新規保存先だけ")
    before, paths = {str(fixed_path.resolve()): fixed_sha}, {}
    for name in ("condition", "completion", "code"):
        row = f[name]
        path = Path(row["path"])
        path = (path if path.is_absolute() else fixed_path.parent/path).resolve()
        need(path.is_file() and digest(path) == row["sha256"], "固定参照差:"+name)
        before[str(path)] = row["sha256"]
        paths[name] = path
    need(paths["code"] == Path(__file__).resolve(), "実保存code")
    c, done = load_json(paths["condition"]), load_json(paths["completion"])
    need(c["version"] == 1 and c["trial"] == 102 and c["fixed"] is True and c["configs"] == list(configurations().values()), "条件24設定")
    need(done["success"] is True and not done.get("error") and done["stage"] == "full54" and done["trial"] == 102 and done["version"] == 1
         and done["scenes"] == 54 and done["books_per_scene"] == 24 and done["books"] == 1296 and done["configs"] == c["configs"]
         and done["condition_sha256"] == f["condition"]["sha256"] and done["input_code_unchanged"] is True
         and done["input_code_sha256_before"] == done["input_code_sha256_after"] and done["source_reexecuted"] is False
         and done["charts_recomputed"] is False and done["raw_csv_read"] == 0, "同条件full54の成功が必要")
    sessions = []
    cursor = date(2026, 9, 21)
    while cursor <= date(2026, 10, 27):
        if cursor.weekday() < 5:
            sessions.extend(f"{cursor.isoformat()}_{kind}" for kind in ("Day", "Night"))
        cursor += timedelta(days=1)
    tasks = done["results"]
    need(len(tasks) == 54 and [r["session"] for r in tasks] == sessions and [r["session"]["id"] for r in c["scenes"]] == sessions, "完全54場")
    for name, expected in c["code_sha256"].items():
        path = (ROOT/name).resolve()
        need(digest(path) == expected and done["input_code_sha256_before"].get(str(path)) == expected, "実行code指紋差")
        before[str(path)] = expected
    for task in tasks:
        need(task["books"] == 24 and not task.get("error") and set(task["totals"]) == set(KEYS), "各場全24完了")
        path = Path(task["path"])
        path = (path if path.is_absolute() else paths["completion"].parent/path).resolve()
        need(path.name == task["session"]+".json.gz" and digest(path) == task["sha256"], "新Native SHA")
        task["resolved_path"] = path
        before[str(path)] = task["sha256"]
    return tasks, before, {"Root固定SHA256": fixed_sha, **{name+"SHA256": f[name]["sha256"] for name in ("condition", "completion", "code")}}


def main():
    """
    機能: 成功後の新Nativeだけから保存検算/集計/Viewer変換を実行する。
    引数: CLI --fixed/--fixed-sha/--outはRoot宣言と新規先。
    返り値: None。失敗は例外で停止し、HTTP/原板/金融再生は行わない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixed", type=Path, required=True)
    parser.add_argument("--fixed-sha", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    tasks, before, proofs = prepare(args.fixed.resolve(), args.fixed_sha, args.out)
    by_key, scene_rows, resources, native_refs = {k: [] for k in KEYS}, [], [], []
    comparisons = defaultdict(list)
    daily, candidates = {k: defaultdict(list) for k in KEYS}, {p: Counter() for p in ("S3", "S4")}
    args.out.mkdir(parents=True)
    for task in tasks:
        value = load_json(task["resolved_path"])
        need(value["session"]["id"] == task["session"], "新Native場")
        checked = inspect_scene(value)
        native_refs.append({"session": task["session"], "path": str(task["resolved_path"]), "sha256": task["sha256"]})
        for policy in ("S3", "S4"):
            for row in value["signals"][policy]:
                d = row["decision"]
                if dec(value["session"]["start"])+1800 <= dec(d["at"]) < dec(value["session"]["end"])-1800:
                    candidates[policy]["分母"] += 1
                    candidates[policy]["候補" if d["known"] and d["side"] else "待機" if d["known"] else "未知"] += 1
        for key, row in checked.items():
            by_key[key].append(row)
            daily[key][task["session"][:10]].append(row)
            stat = statistics([row])
            scene_rows.append({"session": task["session"], "key": key, **stat})
            for name, field in (("gross", "gross"), ("fee", "fee"), ("slip", "slip"), ("net", "net"), ("positions", "完結玉"), ("entry_quantity", "取得枚数")):
                equal(task["totals"][key][name], stat[field], "完了receiptと保存会計")
            name = f"102_{key}_{task['session']}.trades.jsonl"
            with (args.out/name).open("x", encoding="utf-8", newline="\n") as stream:
                for f in viewer_trades(row, task["session"], key):
                    stream.write(json.dumps(plain(f), ensure_ascii=False, allow_nan=False)+"\n")
            resources.append({"id": f"102_{key}_{task['session']}", "title": f"一定利益後の可変追尾 {key} {task['session']}", "symbol": "NK225", "product": "NK225mini", "session": task["session"], "method_id": key, "point_value": 100, "pnl_format": "trades", "pnl_basis": "net", "pnl_path": name, "market_path": f"NK225/{task['session']}/book.jsonl.gz"})
        for entry in ("S3", "S4"):
            for cost in (0, 5):
                for delay in (0, 1):
                    a, b = f"{entry}_A0_C{cost}_D{delay}", f"{entry}_A1_C{cost}_D{delay}"
                    comparisons[b+"対"+a].append({"session": task["session"], **compare_entries(checked[a], checked[b])})
    aggregate, diagnostics, day_rows = {}, {}, {}
    for key, rows in by_key.items():
        aggregate[key] = statistics(rows)
        equal(aggregate[key]["活動"]["denom"], 5832, "全54の予定分母")
        day_rows[key] = [{"開始日": day, **statistics(items)} for day, items in sorted(daily[key].items())]
        best = max(day_rows[key], key=lambda row: row["net"])
        diagnostics[key] = {"日夜": {kind: statistics([r for r in rows if r["book"]["session"]["kind"] == kind]) for kind in ("Day", "Night")},
                            "売買": {str(s): {"玉": sum(t["side"] == s for r in rows for t in r["trades"].values()), "純額": sum((dec(t["net"]) for r in rows for t in r["trades"].values() if t["side"] == s), ZERO)} for s in (1, -1)},
                            "最大損益開始日": best["開始日"], "同日純額": best["net"], "同日除外純額": aggregate[key]["net"]-best["net"], "日数": len(day_rows[key]), "黒字日": sum(r["net"] > 0 for r in day_rows[key])}
    after = {path: digest(Path(path)) for path in before}
    need(before == after, "入力/code前後差")
    result = {"試行": 102, "成功": True, "scope": "実fill保存会計/限定因果/保存点連結DD。全原板別engineの独立再生ではない", "場数": 54, "会計数": 1296,
              **proofs, "集計": aggregate, "実現診断": diagnostics, "日別": day_rows, "場別": scene_rows,
              "A1対A0の同実入口と実参加差": dict(comparisons), "signals候補枠": candidates, "Native参照": native_refs,
              "未評価": ["機会損失", "退出後価格", "未参加仮想利益", "MFE/理想峰回収", "資本金不明ROI"], "入力codeSHA256前": before, "入力codeSHA256後": after, "前後不変": True}
    write_json(args.out/"結果.json", result)
    write_json(args.out/"一覧.resources.json", {"schema_version": 1, "path_base": "catalog", "resources": resources})
    lines = ["# 102の実現額と参加", "", "保存約定算術と限定因果の検算。原板全経路の別engine再生ではない。", "", "|設定|純額|PF|活動/予定枠|25%/50%|保存点DD|", "|---|---:|---:|---:|---|---:|"]
    for key, r in aggregate.items():
        a = r["活動"]
        lines.append(f"|{key}|{r['net']}|{r['PF'] if r['PF'] is not None else '未定義'}|{a['active']}/{a['denom']}|{a['最低25%']}/{a['目標50%']}|{r['保存点連結時価DD']}|")
    (args.out/"結果.md").write_text("\n".join(lines)+"\n", encoding="utf-8")
    outputs = {p.name: digest(p) for p in args.out.iterdir() if p.is_file()}
    write_json(args.out/"保存会計の確認.json", {"成功": True, "scope": result["scope"], **proofs, "会計": 1296, "資源": len(resources), "不一致数": 0, "前後不変": True,
               "入力codeSHA256前": before, "入力codeSHA256後": after, "出力SHA256": outputs, "Raw_Source_金融_特徴再生成_HTTP": 0})


if __name__ == "__main__":
    main()
