# 102の結果整理と保存会計検算・版2

準備日：2026-11-09。旧停止 `c5ad4bda…` と旧保存code `d1360d96…` を変更せず、非金融floatの検算だけを別版にした。手製72会計（非0 48・合法空24）、実Fill形式96行、非整数ATRの買売48会計、狭い破損12件の拒否を確認した。Root許可の実最初1場だけを読み、24会計が保存検算を通過した。全54保存の成功はまだ主張しない。Source/金融/指標の実行、Raw・records本文、HTTP/Viewer登録は0。

## 初回失敗と限定修正

旧器の最初の実場で、取得価格65130、ATR20.011611855074232から作った停止価格が不一致になった。保存値65089.97677628985に対しDecimal再算術は65089.976776289851536で、差は−1.536e−12ptだった。最初1場の非整数ATRによる差104件は最大3.88e−12ptで、すべて元GoのIEEE64演算順序では保存値と完全一致した。金融の停止価格や実Fillは変更していない。

- 初期stopは、公開ATRを倍精度へ復元し、元Goの `entry−side*max(20,2*ATR)` の演算順序と完全一致で比較する。
- 活動率も元Goと同じ倍精度の `active/denom` に完全一致させる。
- 起動単価の閾値境界だけ1e−9ptを許す。以前の1e−8ptから狭めた。保存口座峰と起動単価の必要整合は、円額を倍率100と数量で割ったpt単価に直して同じ1e−9pt内で比較する。旧検算の円とptの次元不一致を修正した。
- BBO保存価格、gross/fee/slip/net、保存極値/DD、枚数、Index、時刻の検算へ許容差を広げない。金額はDecimalの厳密比較を維持する。保存点から起動全経路を再形成した証明でもない。

`初回失敗の小診断.json` と `最初1場の版2接続.json` を残した。旧器は同じ非整数ATR人工で失敗を再現した。旧停止、旧人工、金融条件・実行物、および途中の正式出力先は変更・削除しない。

新しい小型postprocessorで、旧100の複雑なSource金融validatorを偽装して通さない。新Goの `SceneResult102.books`、公開Result/Order/Fill/Trade/GridRecord/EquityPointへ直接結ぶ。Viewerは既存schema1の約定行を使用する。Rootの5点静的レビュー・Go人工と実入力指紋・本保存会計を別の層として扱い、旧101の全原行を別engineで再構成した監査と同じ証明とは呼ばない。

## 最小固定とCLI

Rootが次のJSONの実path/SHAを埋め、JSON自身のSHAを渡す。相対pathはこのJSONのディレクトリ基準。未固定の雛形は入力本文前に拒否する。

```json
{
  "version": 1,
  "trial": 102,
  "fixed": true,
  "stage": "full54",
  "condition": {"path": "条件.json", "sha256": "実SHA"},
  "completion": {"path": "金融の全54完了.json", "sha256": "実SHA"},
  "code": {"path": "集計と保存会計を確認する.py", "sha256": "保存code実SHA"}
}
```

```powershell
python -B -X utf8 work/102結果の整理_版2/集計と保存会計を確認する.py `
  --fixed <Rootが成功後に保存する固定JSON> --fixed-sha <そのSHA> `
  --out <存在しない新規保存dir>
```

固定24設定、完全54場、success/full54/1296会計、同条件、Goの入力/code前後一致、条件にある実行codeの現在SHA、完了が指す各Native SHAを検査してからNative本文を開く。架空の別engine独立receiptや未定schemaは要求しない。保存器自身もRoot固定のcode SHAへ結び、実行前後のNative/code SHAを結果と保存receiptへ残す。

## 保存会計が独立に再計算する範囲

- 実額 `gross=side*(exit−entry)*100*qty`、各約定の指定fee=`38.5*qty`、別仮定slip=`cfg.slip*100*qty`。Decimalで半円と0.77ptの費用単価を維持する。BBO価格自体を追加滑りでずらさない。
- 注文/Fill/TradeのID・side/qty/full quote・実所有、正常BBO・要求Indexよりstrict後・D1・logical枠60秒/末尾30分締切・Force前新規・終端残0・単一全量玉/数量上限10。
- 新規の成功枠とlogical Atの実保有を別に再照合し、欠測込みDay72/Night144・全54各設定5832枠へ結ぶ。newは当枠要求が後続で実約定した事後分類であり、要求受理数/asof取得済み数と同義ではない。wait/unknownの完全な価格鮮度再判定は全quotesが無いため主張しない。
- 初期stopと最終床の必要条件、起動/初回u正益の保有内時計と分母。起動単価と保存口座峰の必要整合も検査するが、起動した全原行の別再形成ではない。
- 保存された極値点を時刻/Index/phase順に連結して場内DD・flatな場間の累積DDを計算し、Bookの保存極値/DDへ一致させる。全正常RawのMTM極値を取り直した証明ではない。

最初eligible行だったこと、要求時の最後quoteの15秒鮮度、全床更新の非緩和、全u/起動flag、Source/指標値/全原行MTMの独立再構成はこの保存器だけでは証明しない。Rootの事前静的レビュー/Go境界人工/固定入力指紋と区別する。既存スカラー/各場末0の金融成功を偽って追加しない。

## 出力

`結果.json/md`、`保存会計の確認.json`、`一覧.resources.json`、24×54の `.trades.jsonl` を新規保存する。内部全Bookの転記はせずNative参照と指紋を残す。

実現正負/PF、u正益後とActivated後の最終赤字（各別分母）、保存点連結DD、要求数/実玉/枚数、4分類・最低25%/目標50%、日夜・売買・日別/27開始日・最大損益開始日除外を出す。0取引はPF未定義、0純額を黒字扱いしない。signals候補率は金融の実活動率と別欄。

A1対A0は同入口S3/S4・各C/Dの8系列。`(grid_at,side)` の候補対応を作り、要求At/GridAt/Index、実fill quote全値/side/price/qty/entryATRがすべて一致する玉だけ同実入口の出口差とする。他は取得変更、前だけ/後だけの実参加額へ分ける。Sourceを持たない候補を架空の元Sourceへ結ばない。

Viewerは実Fillのみ、mini倍率100、費用は指定fee+仮定slip、ID `102_<key>_<session>`。新Quoteに物理Lineが保存されないため、FeaturesIndexを `source_line` として創作しない。timestamp/price/positionと全実額の形式変換であり、Viewerの原板同時刻行の一意解決を追加証明しない。実HTTPは行わない。

機会損失、未参加/退出後価格、理想峰/MFE回収、資本金不明ROIは算出しない。最大利益日を除外して成績を作り直す戦略でもない。集中診断として実額を記す。

## 人工

```powershell
python -B -X utf8 work/102結果の整理_版2/人工を確認する.py
```

停止前の手製検算。正常72会計・全24集合・空24資源・Viewer96行・買売/正負・欠測分母・同入口/取得変更・単価38.5/0.77に加え、非整数ATRを買売の全C/D・全24設定で48件確認した。初期stopの1e−8pt破損、net/feeの1e−9円破損、起動unitの1e−9pt内外も含め計12破損を拒否した。手製保存極値は起動単価に倍率100と数量を掛けた円額へ正したもので、金融再生ではない。巨大な人工Native本文は別保存しない。途中receiptは履歴として保持し、現在codeへ結ぶものは `人工確認_版2停止.json`。既存証拠を上書きしないため、再実行時は新規receipt先を用意する。

Rootが新版codeのpath/SHAだけを新しい固定JSONへ結び、存在しない出力先で全54保存CLIを実行する。最小固定schemaは旧版と同じ。版2準備中に本番の全54集計は実行していない。
