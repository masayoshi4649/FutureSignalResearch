"""Root許可の手製単一玉/空会計で保存検算と表示型を確認する。"""

from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("102の保存人工", HERE/"集計と保存会計を確認する.py")
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)


def fixture(side, bad=False, empty=False):
    """
    機能: 全24設定に対する手製の単一全量玉又は合法空を作る。
    引数: side(int)は±1、bad/empty(bool)は最終赤字/空。
    返り値: dictは型人工。Source/金融/価格の再生をした例ではない。
    """
    s = {"id": "人工Day", "kind": "Day", "start": 0, "end": 25200, "force": 24600}
    value = {"version": 1, "trial": 102, "session": s, "source_reexecuted": False, "charts_recomputed": False, "books": {}}
    for key, cfg in M.configurations().items():
        b = {"success": True, "session": s, "config": cfg, "orders": [], "fills": [], "trades": [], "grids": [],
             "gross": 0, "fee": 0, "slip": 0, "net": 0, "dd": 0, "poscount": 0, "active": 0, "hold": 0, "new": 0, "wait": 0, "unknown": 72,
             "denom": 72, "participation": 0, "open_quantity": 0, "pending_entry": 0, "pending_exit": 0, "activated_positions": 0,
             "equity_points": [{"at": 25199, "index": 30, "phase": "finish", "kind": "場末", "equity": 0}], "peak_equity": 0, "min_equity": 0}
        for at in range(1800, 23400, 300):
            b["grids"].append({"at": at, "action": "unknown", "reason": "人工の欠測", "decision": {"at": at, "available_at": at, "known": False, "side": 0, "qty": 0, "atr": 0}, "quantity": 0, "pending": 0})
        if not empty:
            pid = key+"_玉"
            def fill(kind, at, index, price):
                """
                機能: 手製の実Fill型を作る。
                引数: kind(str)、at/index/price(int)は公開値。
                返り値: dictは型fixture。
                """
                direction = side if kind == "entry" else -side
                bid, ask = (price-5, price) if direction > 0 else (price, price+5)
                return {"order_id": pid+kind, "position_id": pid, "kind": kind, "side": direction, "qty": 2, "quote": {"time": at, "index": index, "bid": bid, "ask": ask, "valid": True}, "price": price, "fee": 77, "slip": cfg["slip"]*200}
            en = fill("entry", 1801+cfg["delay"], 2, 1000)
            ex = fill("exit", 1811+cfg["delay"], 12, 1000+side*(-30 if bad else 30))
            gross, fee, slip = (-6000 if bad else 6000), 154, cfg["slip"]*400
            net = gross-fee-slip
            order = {"id": en["order_id"], "position_id": pid, "kind": "entry", "side": side, "qty": 2, "at": 1800, "grid_at": 1800, "request_index": 1, "expires_at": 1860, "reason": "人工新規", "status": "filled"}
            exit_order = {"id": ex["order_id"], "position_id": pid, "kind": "exit", "side": -side, "qty": 2, "at": 1810, "grid_at": 0, "request_index": 11, "reason": "人工保護", "status": "filled"}
            cost = M.Decimal("0.77")+2*cfg["slip"]
            unit = 30-cost
            floor = 1000+side*(0 if cfg["trail_policy"] == "P0" else (5 if cfg["slip"] == 0 else 15))
            trade = {"id": pid, "side": side, "qty": 2, "entry": en, "exit": ex, "entry_atr": 20, "initial_stop": 1000-side*40,
                     "activation_at": 1805, "activation_index": 5, "activation_unit_points": unit, "activated": True, "had_positive_unit": True, "first_positive_at": 1804,
                     "final_floor": floor, "gross": gross, "fee": fee, "slip": slip, "net": net, "exit_reason": "人工保護"}
            peak = max(0, unit*2*M.POINT, net)
            b.update(orders=[order, exit_order], fills=[en, ex], trades=[trade], gross=gross, fee=fee, slip=slip, net=net, poscount=1,
                     active=1, new=1, unknown=71, participation=M.dec(1)/72, activated_positions=1, dd=max(0, peak-net), peak_equity=peak, min_equity=min(0, net))
            b["equity_points"] = [{"at": 1805, "index": 5, "phase": "after_fill", "kind": "人工起動点", "equity": unit*2*M.POINT}, {"at": ex["quote"]["time"], "index": ex["quote"]["index"], "phase": "after_fill", "kind": "人工保存点", "equity": net}, {"at": 25199, "index": 30, "phase": "finish", "kind": "場末", "equity": net}]
            b["grids"][0]["action"] = "new"
            b["grids"][0]["decision"].update(known=True, side=side, qty=2, atr=20)
        value["books"][key] = b
    return value


def main():
    """
    機能: 正常72会計/表示と狭い破損、未固定本文前拒否を確認する。
    引数: なし。
    返り値: None。市場入力は一切使わない。
    """
    cases = [fixture(1), fixture(-1, bad=True), fixture(1, empty=True)]
    checked = [M.inspect_scene(v) for v in cases]
    rows, viewers = 0, 0
    for c in checked:
        for key, row in c.items():
            rows += 1
            t = M.viewer_trades(row, "人工Day", key)
            viewers += len(t)
            assert len(t) == 2*len(row["trades"])
            if t:
                assert t[0]["type"] in ("LongN", "ShortN") and t[1]["type"] in ("LongR", "ShortR")
                assert t[0]["fee_yen"] == M.dec(row["book"]["fills"][0]["fee"])+M.dec(row["book"]["fills"][0]["slip"])
    for key in M.KEYS:
        stat = M.statistics([checked[0][key], checked[1][key]])
        assert stat["u正益"]["観測玉"] == stat["Activated"]["観測玉"] == 2
        assert stat["u正益"]["最終赤字玉"] == stat["Activated"]["最終赤字玉"] == 1
        empty = M.statistics([checked[2][key]])
        assert empty["PF"] is None and empty["完結玉"] == 0 and empty["活動"]["最低25%"] is False
        assert stat["活動"]["denom"] == 144 and stat["活動"]["active"] == 2
    assert M.FEE == M.Decimal("38.5") and 2*M.FEE/M.POINT == M.Decimal("0.77")
    # 非整数ATRの公開値から、元倍精度の初期stopを買売/全C/Dで確認する。
    fractional = []
    for side in (1, -1):
        v = fixture(side)
        for b in v["books"].values():
            t = b["trades"][0]
            for f in b["fills"]:
                f["price"] += 64130
                f["quote"]["bid"] += 64130
                f["quote"]["ask"] += 64130
            t["entry_atr"] = M.Decimal("20.011611855074232")
            t["initial_stop"] = M.Decimal(str(float(t["entry"]["price"])-float(side)*max(20.0, 2.0*float(t["entry_atr"]))))
            t["final_floor"] += 64130
        M.inspect_scene(v)
        fractional.append(v)
    # 旧停止器が同じ型人工で失敗することも残し、入力や旧codeは変えない。
    old_path = HERE.parent/"102結果の整理/集計と保存会計を確認する.py"
    assert hashlib.sha256(old_path.read_bytes()).hexdigest() == "d1360d962be0d902f707e17a4183543ba887ccbdfb163b5687d151c8a9eda867"
    old_spec = importlib.util.spec_from_file_location("102旧停止の再現", old_path)
    old = importlib.util.module_from_spec(old_spec); old_spec.loader.exec_module(old)
    try:
        old.inspect_scene(fractional[0])
    except ValueError as error:
        assert str(error) == "固定初期stop"
    else:
        raise AssertionError("旧失敗を再現できない")
    key_a, key_b = "S3_A0_C0_D0", "S3_A1_C0_D0"
    a, b = checked[0][key_a], checked[0][key_b]
    match = M.compare_entries(a, b)
    assert match["分解"]["同実入口の出口差"]["玉"] == 1
    changed = deepcopy(b)
    trade = next(iter(changed["trades"].values()))
    trade["entry"]["quote"]["index"] += 1
    assert M.compare_entries(a, changed)["分解"]["取得変更"]["玉"] == 1
    rejected = 0
    def broken_fee(v):
        """
        機能: 費用破損を一箇所だけ注入する。
        引数: v(dict)は人工コピー。返り値: None。
        """
        v["books"][M.KEYS[0]]["fills"][0]["fee"] += 1
    mutations = [broken_fee,
                 lambda v: v["books"][M.KEYS[0]]["fills"][0]["quote"].update(index=1),
                 lambda v: v["books"][M.KEYS[0]]["fills"][0]["quote"].update(time=1860),
                 lambda v: v["books"][M.KEYS[0]]["orders"][0].update(expires_at=1861),
                 lambda v: v["books"][M.KEYS[0]]["grids"].pop(),
                 lambda v: v["books"][M.KEYS[0]].update(open_quantity=2),
                 lambda v: v["books"][M.KEYS[0]].update(dd=1),
                 lambda v: v["books"].pop(M.KEYS[-1])]
    for mutate in mutations:
        v = deepcopy(cases[0]); mutate(v)
        try:
            M.inspect_scene(v)
        except (ValueError, KeyError):
            rejected += 1
        else:
            raise AssertionError("破損を成功扱い")
    for field, delta in (("initial_stop", M.Decimal("0.00000001")), ("net", M.Decimal("0.000000001")), ("fee", M.Decimal("0.000000001"))):
        v = deepcopy(fractional[0])
        v["books"][M.KEYS[0]]["trades"][0][field] += delta
        try:
            M.inspect_scene(v)
        except ValueError:
            rejected += 1
        else:
            raise AssertionError("float対応で実額/価格線を緩和")
    # 起動単価だけの局所許容境界。実額や価格/時計は変更しない。
    unit_case = deepcopy(cases[0]["books"]["S3_A0_C0_D0"])
    trade = unit_case["trades"][0]
    threshold = M.Decimal("29.23")
    trade["entry_atr"] = 2*threshold
    trade["initial_stop"] = M.Decimal(str(float(trade["entry"]["price"])-max(20.0, 2.0*float(trade["entry_atr"]))))
    trade["activation_unit_points"] = threshold-M.Decimal("0.0000000005")
    M.verify_book(unit_case, unit_case["session"], "S3_A0_C0_D0")
    trade["activation_unit_points"] = threshold-M.Decimal("0.000000002")
    try:
        M.verify_book(unit_case, unit_case["session"], "S3_A0_C0_D0")
    except ValueError as error:
        assert str(error) == "起動余裕/Index"
        rejected += 1
    else:
        raise AssertionError("1e-9pt外を起動単価へ許容")
    with tempfile.TemporaryDirectory() as temp:
        p = Path(temp)/"固定.json"
        p.write_text(json.dumps({"version": 1, "trial": 102, "fixed": False, "stage": "full54", "condition": {}, "completion": {}, "code": {}}))
        try:
            M.prepare(p, M.digest(p), Path(temp)/"出力")
        except ValueError:
            pass
        else:
            raise AssertionError("未固定の市場読取")
        catalog = {"schema_version": 1, "path_base": "catalog", "resources": [{"id": "102_人工", "point_value": 100, "pnl_format": "trades", "pnl_basis": "net", "pnl_path": "実約定.trades.jsonl", "market_path": "NK225/人工/book.jsonl.gz"}]}
        M.write_json(Path(temp)/"一覧.resources.json", catalog)
        trades = M.viewer_trades(checked[0][M.KEYS[0]], "人工Day", M.KEYS[0])
        target = Path(temp)/"実約定.trades.jsonl"
        target.write_text("".join(json.dumps(M.plain(row), ensure_ascii=False)+"\n" for row in trades), encoding="utf-8")
        assert M.load_json(Path(temp)/"一覧.resources.json") == catalog
        assert [json.loads(line) for line in target.read_text(encoding="utf-8").splitlines()] == M.plain(trades)
    receipt = {"成功": True, "scope": "手製単一全量玉/空Resultの保存算術とViewer型。金融/Source/原板再生なし", "会計": rows, "全実FillのViewer行": viewers,
               "空資源": 24, "非整数ATRの買売全C_D": 48, "旧固定初期stop失敗再現": True, "起動unitの1e_9pt内外境界": True,
               "半円単価_費用回収単価": True, "同実入口_取得変更分離": True, "欠測分母と0玉PF": True, "狭い破損拒否": rejected,
               "未固定本文前拒否": True, "市場_Raw_records_Native読取": 0, "金融_Source_HTTP": 0,
               "codeSHA256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (HERE/"集計と保存会計を確認する.py", Path(__file__))}}
    M.write_json(HERE/"人工確認_版2停止.json", receipt)
    print(json.dumps(M.plain(receipt), ensure_ascii=False))


if __name__ == "__main__":
    main()
