"""170固定主案の二期間適用を、封印幅と元NPZから独立確認する。"""
from pathlib import Path
import importlib.util
import sys
import math

import numpy as np

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
AUTHOR=ROOT/'work/170ATRと三時間帯'


def module(path: Path,name: str) -> object:
    """
    機能: mainを実行せず独立式を読む。
    引数: path(Path)、name(str)はSourceと識別名。
    返り値: objectはmodule。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


qa=module(HERE/'旧七十三場を層別検算する.py','independent170_fixed')
previous=qa.previous;pure=qa.pure;read=qa.read;save=qa.save;sha=qa.sha


def main() -> None:
    """
    機能: 固定主案の幅出生・全要求取得・両期間全分解を検算する。
    引数: なし。固定主案以外の追加7探索は行わない。
    返り値: None。幅分布・封印同体・自然全場/帯/数量の確認票を保存する。
    """
    sys.stdout.reconfigure(encoding='utf-8');book=qa.BOOK;assert sha(book)==qa.BOOK_SHA
    trial=book.parent
    paths=[Path(__file__),HERE/'旧七十三場を層別検算する.py',AUTHOR/'固定主案を二期間に適用する.py',
           AUTHOR/'固定候補を再生する.py',AUTHOR/'固定候補二期間の完了.json',AUTHOR/'追加7固定候補の幅と出生.npz',
           AUTHOR/'旧73探索/主案と前半A-Bの封印.json',trial/'検査/F1_追加固定候補幅の金融前封印.json']
    for folder in ('旧73固定候補','追加7固定候補'):
        paths.extend(AUTHOR/folder/name for name in ('完了.json','固定候補の数量比較.json','全取得参照.json','数量と要求の監査.json.gz'))
    before={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    setting=read(book);seal=read(paths[6]);fixed=read(paths[7]);candidate=seal['事前固定主案']['candidate']
    assert seal['選択']=={'A':None,'B':None} and fixed['候補']==[candidate]
    assert fixed['今回幅出生の金融数値表未入力'] and fixed['新規独立未見ではない']
    assert fixed['幅出生SHA256']==sha(paths[5])
    library=module(ROOT/'work/162複合入口候補/rules162.py','catalog_fixed170');catalog={r['id']:r for r in library.candidate_catalog()}
    summaries=[];stat_cells=0;requests=0;records=0;seal_cells=0
    for label,old,folder in (('旧73',True,'旧73固定候補'),('追加7',False,'追加7固定候補')):
        data=previous.load_dataset(old);born=previous.births(data,candidate,catalog)
        phase=np.asarray([previous.io.band(row['session'],row['q0_time']) for row in data.q0],dtype=np.int8)
        atr=data.buy[:,data.columns.index('m5_atr')]
        assert np.array_equal(atr,data.sell[:,data.columns.index('m5_atr')],equal_nan=True)
        scale=next(s for s in setting['timeband_scales'] if s['id']==candidate['timeband_scale'])
        widths=pure.width_oracle(atr,phase,candidate['momentum_atr_multiplier'],candidate['fade_atr_multiplier'],scale,setting['width_grid'])
        born['core']=np.where(widths['valid'],born['core'],0).astype(np.int8)
        born['branches']=np.where(born['core']!=0,born['branches'],-1).astype(np.int8)
        if not old:
            with np.load(paths[5],allow_pickle=False) as frozen:
                for name,value in widths.items():
                    assert np.array_equal(frozen[candidate['id']+'__'+name],value);seal_cells+=value.size
                for name,value in born.items():
                    assert np.array_equal(frozen[candidate['id']+'__birth__'+name],value);seal_cells+=value.size
        oracle_choice={**candidate,'momentum_width':200,'fade_width':400}
        inputs=previous.oracle_data(data,born,oracle_choice)
        inputs['momentum_width']=widths['momentum_widths'];inputs['fade_width']=widths['fade_widths']
        result=qa.oracle(inputs,10);requests+=len(result['requests']);records+=len(result['records'])
        parent=AUTHOR/folder;report=read(parent/'固定候補の数量比較.json')['rows'];assert len(report)==1
        ref=read(parent/'全取得参照.json')['rows'];audit=read(parent/'数量と要求の監査.json.gz')['rows'];assert len(ref)==len(audit)==1
        entry=report[0];assert entry['candidate']==candidate and audit[0]['requests']==result['requests']
        for expected,actual in zip(result['audits'],audit[0]['audits'],strict=True):
            for name,value in expected.items():assert actual[name]==value
        rows=[(row['case'],row['side'],row['event'],row['origin']) for row in result['records']]
        wi=np.asarray([data.meta['widths'].index(row['width']) for row in result['records']],dtype=np.int8)
        tiers=[row['tier'] for row in result['records']];previous.reference_match(data,rows,wi,tiers,ref[0])
        # 選ばれた全eventの幅が金融前封印/q0からの幅と一致する。
        for row in result['records']:
            expected=int(candidate['integration'][1:]) if row['origin']==2 else int(widths['momentum_widths' if born['branches'][row['event']]==0 else 'fade_widths'][row['event']])
            assert row['width']==expected
        actual=entry['cap10']
        stat_cells+=previous.audit_financial_parts(data,rows,wi,tiers,born,candidate,actual['periods']['全期'],
            actual['scenes'],actual['timebands'],actual['branches'],actual['sides'],'168')
        scene=np.asarray([data.arrays['session_index'][row[0]] for row in rows],dtype=np.int16)
        branch=np.asarray([int(born['branches'][row['event']]) if row['origin']==0 else 2 if row['tier']==1 else 3 for row in result['records']],dtype=np.int8)
        grid_index=np.asarray([setting['width_grid'].index(row['width']) for row in result['records']],dtype=np.int16)
        for name,value in actual['periods'].items():
            eligible=np.arange(73)<48 if name=='前48場' else np.arange(73)>=48 if name=='後25場' else np.ones(len(data.scenes),dtype=bool)
            stat_cells+=previous.compare_statistics(value,previous.statistics(data,rows,wi,1,eligible[scene],eligible),(label,name))
            for bi in range(4):
                expected=np.bincount(grid_index[eligible[scene]&(branch==bi)],minlength=len(setting['width_grid']))
                assert expected.tolist()==entry['width_counts'][name][bi]
        if old:
            for name,value in seal['事前固定主案']['periods'].items():
                for field in ('count','F','A','N','C','profit','loss','net','known','unknown','rate'):
                    assert actual['periods'][name][field]==value[field],(name,field)
        summaries.append({'period':label,'metrics':actual['periods']['全期'],'requests':len(result['requests']),
                          'width_counts':entry['width_counts'],'peak_reserved_total':actual['peak_reserved_total']})
    assert all(sha(ROOT/path)==digest for path,digest in before.items())
    save(HERE/'固定主案二期間の独立確認.json',{'成功':True,'trial':170,'Sourceと入力':before,'封印幅出生照合セル':seal_cells,
         '独立全要求照合':requests,'独立全取得照合':records,'元NPZから全分解統計照合':stat_cells,
         '選択eventの幅が金融前封印と一致':True,'全場_三帯_幅分布_数量上限':True,'旧73主案が探索正本と同体':True,
         '追加7は既使用の基準期':True,'追加7で全候補探索しない':True,'rows':summaries,
         '注意':'追加7の到達済み11件による72.73%は優位性の確立証拠としない。Cは損益0とせず全件収支null。'})
    save(HERE/'固定主案二期間確認の停止.json',{'成功':True,'SourceSHA256':sha(Path(__file__)),
         '検査票SHA256':sha(HERE/'固定主案二期間の独立確認.json'),'元Sourceと結果不変':True})
    print(__import__('json').dumps({'成功':True,'要求':requests,'取得':records,'検査票SHA256':sha(HERE/'固定主案二期間の独立確認.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
