"""封印済みATR主案と存在する前半選択だけを旧73・追加7へ適用する。"""
from pathlib import Path
import numpy as np
import json
import 固定候補を再生する as apply

ROOT=apply.ROOT
HERE=Path(__file__).resolve().parent
BASE=apply.R168.BASE
read,save,sha=apply.R168.read,apply.R168.save,apply.R168.sha
TRIAL=ROOT/'study/00170_ATRと三時間帯の幅で複合入口を数量枠に適合させる'


def main() -> None:
    """
    機能: 元条件から主案を交換せず、追加金融入力前に幅を封印して両期間へ再生する。
    引数: なし。旧73の固定主案と前半A/Bの封印を使い、全期発見案を追加へ持ち込まない。
    返り値: None。両期間の固定候補参照・統計とSource/幅の検査票を保存する。
    """
    setting=read(TRIAL/'条件.json')
    assert sha(TRIAL/'条件.json')=='c7c0ebeaebc51a24b256c74ad0dfe1aeaa1d7ff8d4ee019d25d5d92f064a0f1b'
    seal_path=HERE/'旧73探索/主案と前半A-Bの封印.json'
    assert sha(seal_path)=='c29a8f61e662e3e7ca1d5159d5e35a033af6a171ff343c9e5ebdca9b70c47b62'
    seal=read(seal_path);assert seal['成功']
    candidates=[seal['事前固定主案']['candidate']]
    for value in seal['選択'].values():
        if value is not None:candidates.append(value['candidate'])
    assert len(candidates)<=3
    directory=ROOT/'work/167追加七場の入力'
    paths=[Path(__file__),HERE/'固定候補を再生する.py',HERE/'engine170.py',HERE/'width170.py',seal_path,
        directory/'生成の完了.json',directory/'入口母集団/完了.json']
    before={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    features,captures,_=BASE.load_features(directory/'入口母集団')
    born={};prepared={}
    for candidate in candidates:
        result=apply.birth_widths(features,candidate,setting);prepared[candidate['id']]=result
        for key in ('momentum_widths','fade_widths','valid'):born[candidate['id']+'__'+key]=result[key]
        for key,value in result['birth'].items():born[candidate['id']+'__birth__'+key]=value
    # ----------------------------------------
    # この新規幅は追加七場金融数値表を開く前に保存する。基準期の過去参照歴は条件に明記済み。
    birth_path=HERE/'追加7固定候補の幅と出生.npz';assert not birth_path.exists()
    np.savez_compressed(birth_path,**born)
    save(TRIAL/'検査/F1_追加固定候補幅の金融前封印.json',{'成功':True,'Sourceと入力':before,
        '今回幅出生の金融数値表未入力':True,'新規独立未見ではない':True,
        '幅出生SHA256':sha(birth_path),'候補':candidates})
    numeric=read(directory/'生成の完了.json');assert numeric['成功']
    adapter=BASE.module(ROOT/'work/166可変場の数値化/arrays166.py','arrays166_for170')
    table=adapter.load_table(directory/'自然数値表',numeric['cache'])
    new=BASE.GenericContext(features,table,captures)
    old0=BASE.Context165();old=BASE.GenericContext(old0.features,old0.table,old0.capture_rows)
    reports=[]
    for label,context,folder in [('旧73',old,'旧73固定候補'),('追加7',new,'追加7固定候補')]:
        result=apply.run_context(context,candidates,setting,HERE/folder)
        if label=='追加7':
            refs=read(HERE/folder/'全取得参照.json')['rows']
            for candidate,reference in zip(candidates,refs,strict=True):
                actual=apply.birth_widths(features,candidate,setting);expected=prepared[candidate['id']]
                for key in ('momentum_widths','fade_widths','valid'):
                    assert np.array_equal(actual[key],expected[key])
                for event,origin,wi in zip(reference['events'],reference['origins'],reference['widths'],strict=True):
                    if origin==0:
                        branch=expected['birth']['branches'][event]
                        width=expected['momentum_widths' if branch==0 else 'fade_widths'][event]
                    else:width=int(candidate['integration'][1:])
                    assert table.widths[wi]==width
        reports.extend({'period':label,'id':r['id'],'metrics':r['cap10']['periods']['全期']} for r in result['rows'])
        save(HERE/folder/'完了.json',{'成功':True,'条件SHA256':sha(TRIAL/'条件.json'),'Sourceと入力':before,
            'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in (HERE/folder).iterdir() if p.is_file()}})
    assert all(sha(ROOT/p)==v for p,v in before.items())
    save(HERE/'固定候補二期間の完了.json',{'成功':True,'Sourceと入力':before,'幅出生SHA256':sha(birth_path),'rows':reports})
    print(json.dumps({'成功':True,'rows':reports},ensure_ascii=False))


if __name__=='__main__':
    main()
