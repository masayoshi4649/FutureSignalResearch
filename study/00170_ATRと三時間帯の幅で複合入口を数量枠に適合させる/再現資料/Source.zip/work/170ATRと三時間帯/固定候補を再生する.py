"""170の事前主案と前半固定A/Bだけを可変S場へ同式で適用する。"""
from pathlib import Path
import sys
import numpy as np
import width170
import engine170

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/168数量枠の因果再生'))
import 再生する as R168
from 共通163 import save


def birth_widths(features: object,candidate: dict,setting: dict) -> dict:
    """
    機能: 金融を引数に取らず、当時特徴から固定候補の方向とATR幅を作る。
    引数: features(FeatureDataset)、candidate/setting(dict)は固定170候補と条件。
    返り値: dictはbirth、momentum_widths/fade_widths/valid等。幅未知ならcore0/branch−1。
    """
    birth=R168.BASE.births(features,candidate);column=features.columns.index('m5_atr')
    atr=features.buy_X[:,column];assert np.array_equal(atr,features.sell_X[:,column],equal_nan=True)
    scale=next(s for s in setting['timeband_scales'] if s['id']==candidate['timeband_scale'])
    widths=width170.choose_widths(atr,features.q0_timeband,candidate['momentum_atr_multiplier'],
        candidate['fade_atr_multiplier'],scale,setting['width_grid'])
    birth['core']=np.where(widths['valid'],birth['core'],0).astype(np.int8)
    birth['branches']=np.where(birth['core']!=0,birth['branches'],-1).astype(np.int8)
    return {'birth':birth,**widths}


def replay_candidate(context: object,candidate: dict,setting: dict,prepared: dict|None=None) -> tuple:
    """
    機能: 一つの固定ATR幅候補をcap10と当時注文制御で再生する。
    引数: context(GenericContext)、candidate/setting(dict)、prepared(dict|None)は金融前の幅出生。
    返り値: tupleはSelection/origins/widths/tiers/engine結果/birth。出口へは時計だけを渡す。
    """
    prepared=birth_widths(context.features,candidate,setting) if prepared is None else prepared
    birth=prepared['birth'];hi=context.table.horizons.index(candidate['horizon'])
    width_map={int(w):i for i,w in enumerate(context.table.widths)}
    def exit_lookup(case: int,side: int,width: int) -> float|None:
        """
        機能: 既に取得した幅に対応する決済の時計だけを返す。
        引数: case/side/width(int)。
        返り値: floatは既知exit秒、Noneは未知。損益/labelは読まない。
        """
        wi=width_map[width]
        return float(context.arrays['exit_time'][case,side,wi,hi]) if context.arrays['known'][case,side,wi,hi] else None
    result=engine170.replay(context.event_keys,context.event_scenes,
        np.array([s['start'] for s in context.scenes]),np.array([s['end'] for s in context.scenes]),
        R168.capture_descriptors(context),birth['core'],birth['branches'],birth['technical'],birth['tier'],
        prepared['momentum_widths'],prepared['fade_widths'],int(candidate['integration'][1:]),exit_lookup,capacity=10)
    rows=result['records'];events=np.array([r['event'] for r in rows],dtype=np.int32)
    selected=R168.Selection(np.array([r['case'] for r in rows],dtype=np.int32),np.array([r['side'] for r in rows],dtype=np.int8),
        events,context.event_phases[events],np.zeros(len(rows),dtype=bool))
    origins=np.array([r['origin'] for r in rows],dtype=np.int8);tiers=np.array([r['tier'] for r in rows],dtype=np.int8)
    widths=np.array([width_map[r['width']] for r in rows],dtype=np.int8)
    return selected,origins,widths,tiers,result,birth


def run_context(context: object,candidates: list,setting: dict,output: Path) -> dict:
    """
    機能: 封印済み主案/A/Bの最大3案だけを可変S場で再生し参照・全場結果を保存する。
    引数: context(GenericContext)、candidates(list[dict])、setting(dict)、output(Path)は未作成先。
    返り値: dictは固定候補の報告。追加7は既使用基準期であり新規未見と称さない。
    """
    assert setting['trial']==170 and 1<=len(candidates)<=3 and not output.exists()
    output.mkdir(parents=True);reports=[];refs=[];audits=[]
    for choice in candidates:
        value=replay_candidate(context,choice,setting);selected,origins,widths,tiers,result,birth=value
        rows=R168.describe(context,birth,choice,value[:5]);scene=context.case_scene[selected.cases]
        branch=np.where(origins==0,birth['branches'][selected.events],np.where(tiers==1,2,3))
        points=np.array([context.table.widths[int(i)] for i in widths]);indices=np.searchsorted(setting['width_grid'],points)
        distributions={};scopes=[('全期',np.ones(len(context.scenes),dtype=bool))]
        if len(context.scenes)==73:scopes+=[('前48場',np.arange(73)<48),('後25場',np.arange(73)>=48)]
        for name,eligible in scopes:
            distributions[name]=[np.bincount(indices[eligible[scene]&(branch==b)],minlength=len(setting['width_grid'])).tolist() for b in range(4)]
        reports.append({'id':choice['id'],'candidate':choice,'cap10':rows,'width_grid':setting['width_grid'],
            'width_count_branches':['主順行','主失速','旧T','局所'],'width_counts':distributions})
        refs.append({'id':choice['id'],'cases':selected.cases.tolist(),'sides':selected.sides.tolist(),
            'events':selected.events.tolist(),'phases':selected.phases.tolist(),'widths':widths.tolist(),
            'origins':origins.tolist(),'tiers':tiers.tolist()})
        audits.append({'id':choice['id'],'audits':result['audits'],'requests':result['requests']})
    report={'成功':True,'場数':len(context.scenes),'場順':context.sessions,'rows':reports,
        '範囲':'170主案と前半固定A/Bのみ。追加7の全4096探索はしない。'}
    save(output/'全取得参照.json',{'成功':True,'rows':refs})
    save(output/'数量と要求の監査.json.gz',{'成功':True,'rows':audits})
    save(output/'固定候補の数量比較.json',report)
    return report
