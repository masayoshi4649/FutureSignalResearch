"""旧73場の当時特徴だけから全ATR幅配列を金融前に封印する。"""
from pathlib import Path
import sys
import numpy as np
import width170

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00170_ATRと三時間帯の幅で複合入口を数量枠に適合させる'
BOOK_SHA='c7c0ebeaebc51a24b256c74ad0dfe1aeaa1d7ff8d4ee019d25d5d92f064a0f1b'
sys.path.insert(0,str(ROOT/'work/163入口と任意幅'))
from 共通163 import read,save,sha,data_module


def main() -> None:
    """
    機能: 二帯設定×各四倍率の主枝幅を当時ATRとq0三帯だけで固定する。
    引数: なし。170条件・人工票・正式同体の当時100特徴のみを読む。
    返り値: None。全幅/当時ATRの幅.npzとSource/特徴指紋を保存する。
    """
    assert sha(TRIAL/'条件.json')==BOOK_SHA;setting=read(TRIAL/'条件.json');out=HERE/'全幅';assert not out.exists()
    artificial=read(HERE/'幅の人工確認.json');assert artificial['成功']
    assert artificial['Source']['width170.py']==sha(HERE/'width170.py')
    sources=[Path(__file__),HERE/'width170.py',HERE/'幅の人工確認.json',ROOT/'work/161三時間帯入口のデータ/data161.py',TRIAL/'条件.json']
    before={p.relative_to(ROOT).as_posix():sha(p) for p in sources}
    save(TRIAL/'検査/F0_ATR幅固定前.json',{'成功':True,'金融未入力':True,'Sourceと条件':before})
    features=data_module().load_feature_dataset();column=features.columns.index('m5_atr')
    atr=features.buy_X[:,column];assert np.array_equal(atr,features.sell_X[:,column],equal_nan=True)
    phases=features.q0_timeband;momentum=[];fade=[];valid=None
    for scale in setting['timeband_scales']:
        a=[];b=[]
        for multiplier in setting['momentum_atr_multipliers']:
            result=width170.choose_widths(atr,phases,multiplier,setting['fade_atr_multipliers'][0],scale,setting['width_grid'])
            a.append(result['momentum_widths']);valid=result['valid']
        for multiplier in setting['fade_atr_multipliers']:
            result=width170.choose_widths(atr,phases,setting['momentum_atr_multipliers'][0],multiplier,scale,setting['width_grid'])
            b.append(result['fade_widths']);assert np.array_equal(valid,result['valid'])
        momentum.append(a);fade.append(b)
    out.mkdir();path=out/'当時ATRの幅.npz'
    np.savez_compressed(path,momentum=np.array(momentum),fade=np.array(fade),valid=valid,phases=phases)
    assert all(sha(ROOT/p)==digest for p,digest in before.items())
    save(out/'幅の確認.json',{'成功':True,'金融未入力':True,'条件SHA256':BOOK_SHA,'Source':before,
        'features':features.sources,'momentum_shape':list(np.shape(momentum)),'fade_shape':list(np.shape(fade)),
        'valid':int(valid.sum()),'unknown_or_nonpositive':int((~valid).sum()),
        'scales':setting['timeband_scales'],'momentum_multipliers':setting['momentum_atr_multipliers'],
        'fade_multipliers':setting['fade_atr_multipliers'],'grid':setting['width_grid'],
        'files':{path.name:{'bytes':path.stat().st_size,'sha256':sha(path)}}})
    print({'成功':True,'valid':int(valid.sum()),'幅SHA256':sha(path)})


if __name__=='__main__':main()
