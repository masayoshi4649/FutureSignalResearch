"""170の保存配列不変式と主案の別経路再生同体を自己確認する。"""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np
import 固定候補を再生する as FIXED

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'work/169数量枠と技術近傍'))
import selector169


def sha(path: Path) -> str:
    """
    機能: 原本ファイルを物理指紋化する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def main() -> None:
    """
    機能: 全4096政策の加法・枠・分布と、封印候補の可変S経路を旧73で確認する。
    引数: なし。追加7場を開かず、A/B又は主案を交換しない。
    返り値: None。全取得参照・不変式と経路同体の自己確認票を保存する。
    """
    folder=HERE/'旧73探索';axes=json.loads((folder/'統計軸.json').read_bytes());fields=axes['fields'];f={n:i for i,n in enumerate(fields)}
    source=folder/'ATR数量探索の統計配列.npz'
    with np.load(source,allow_pickle=False) as archive:
        values=archive['metrics'].reshape(4096,3,len(fields));bands=archive['bands'].reshape(4096,3,2,3,len(fields))
        counts=archive['width_counts'].reshape(4096,3,4,len(axes['width_grid']))
    additive=('count','F','A','N','C','profit','loss','net','known','unknown','wins','loss_trades','core_count','old_technical_count','local_technical_count')
    for name in additive:
        i=f[name];assert np.array_equal(values[:,0,i],values[:,1,i]+values[:,2,i])
        for clock in (0,1):assert np.array_equal(values[:,:,i],bands[:,:,clock,:,i].sum(axis=2))
    assert np.array_equal(values[:,:,f['count']],sum(values[:,:,f[n]] for n in ('F','A','N','C')))
    assert np.array_equal(values[:,:,f['known']]+values[:,:,f['unknown']],values[:,:,f['count']])
    assert np.array_equal(values[:,:,f['unknown']],values[:,:,f['C']])
    assert np.array_equal(values[:,:,f['profit']]-values[:,:,f['loss']],values[:,:,f['net']])
    assert np.all(values[:,:,[f['peak_reserved_buy'],f['peak_reserved_sell']]]<=10)
    assert np.array_equal(counts.sum(axis=(2,3)),values[:,:,f['count']])
    assert np.array_equal(counts[:,0],counts[:,1]+counts[:,2])
    assert np.array_equal(counts[:,:,:2,:].sum(axis=(2,3)),values[:,:,f['core_count']])
    assert np.array_equal(counts[:,:,2,:].sum(axis=2),values[:,:,f['old_technical_count']])
    assert np.array_equal(counts[:,:,3,:].sum(axis=2),values[:,:,f['local_technical_count']])
    book=json.loads((ROOT/'study/00170_ATRと三時間帯の幅で複合入口を数量枠に適合させる/条件.json').read_bytes())
    selection=selector169.select_front48(values[:,1],bands[:,1,0],fields,{**book,'trial':169})
    seal=json.loads((folder/'主案と前半A-Bの封印.json').read_bytes())
    assert seal['選択']=={'A':None,'B':None} and selection['A']['position'] is selection['B']['position'] is None
    old=FIXED.R168.BASE.Context165();context=FIXED.R168.BASE.GenericContext(old.features,old.table,old.capture_rows)
    candidates=[seal['事前固定主案']['candidate']]+[r['candidate'] for r in seal['選択'].values() if r is not None]
    report=FIXED.run_context(context,candidates,book,HERE/'固定候補の旧73再生')
    compared=0
    for record,description in zip(report['rows'],[seal['事前固定主案']]+[r for r in seal['選択'].values() if r is not None],strict=True):
        index=np.ravel_multi_index(tuple(description['position']),(4,4,4,4,2,4,2))
        for pi,period in enumerate(axes['periods']):
            for name,actual in record['cap10']['periods'][period].items():
                if name not in f:continue
                wanted=values[index,pi,f[name]]
                if actual is None:assert np.isnan(wanted),(period,name)
                else:assert actual==wanted,(period,name,actual,wanted)
                compared+=1
            assert np.array_equal(np.array(record['width_counts'][period]),counts[index,pi])
    proof={'成功':True,'範囲':'全保存配列の不変式と主案の可変S経路同体。全4096の別engine再生ではない。',
        '追加七場成績未読':True,'全政策':4096,'同体統計欄':compared,'全幅分布と件数同体':True,
        'AとBの封印不変':True,'統計正本SHA256':sha(source),'SourceSHA256':sha(Path(__file__))}
    (folder/'自然統計の自己確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
