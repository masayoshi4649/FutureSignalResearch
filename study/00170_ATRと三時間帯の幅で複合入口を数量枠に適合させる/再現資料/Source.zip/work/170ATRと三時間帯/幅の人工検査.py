"""ATR幅選択と数量engineの定数同体・枠連動を人工確認する。"""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np
import width170
import engine170

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'work/168数量枠の因果再生'))
import 人工検査 as T168
import engine168


def sha(path: Path) -> str:
    """
    機能: 固定Sourceを物理指紋化する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def main() -> None:
    """
    機能: 自然特徴/金融を読まずgrid/未知/反射/未来/定数同体/枠連動を検査する。
    引数: なし。
    返り値: None。人工票とSource固定指紋を保存する。
    """
    grid=[150,175,200,225,250,300,350,400,500,750,1000]
    common={'DAY':1,'PRE':1,'POST':1};phase={'DAY':1,'PRE':.75,'POST':1.25}
    atr=np.array([0.,-1,np.nan,np.inf,-np.inf,50.,50.00001,100.,1000.,1e308])
    result=width170.choose_widths(atr,np.zeros(len(atr),dtype=int),3,6,common,grid)
    assert result['valid'].tolist()==[False]*5+[True]*5
    assert result['momentum_widths'].tolist()==[0]*5+[150,175,300,1000,1000]
    result=width170.choose_widths(np.array([100.,100.,100.]),np.array([0,1,2]),2,4,phase,grid)
    assert result['momentum_widths'].tolist()==[200,150,250]
    assert result['fade_widths'].tolist()==[400,300,500]
    checks=['NaN/Inf/0/負のATRを未知幅0、grid等号/上側/下限/上限/有限overflowclamp','q0三帯倍率と枝倍率']
    rng=np.random.default_rng(170);prefix_rows=0
    values=rng.uniform(1,500,1000);phases=rng.integers(0,3,len(values))
    original=width170.choose_widths(values,phases,3,6,phase,grid)
    mirrored=width170.choose_widths(values.copy(),phases.copy(),3,6,phase,grid)
    assert all(np.array_equal(original[k],mirrored[k]) for k in original)
    for cut in (0,1,333,999,1000):
        changed=values.copy();changed[cut:]=np.nan;shifted=phases.copy();shifted[cut:]=2
        other=width170.choose_widths(changed,shifted,3,6,phase,grid)
        for key in original:assert np.array_equal(original[key][:cut],other[key][:cut])
        prefix_rows+=cut
    checks.append('売買反射で不変のATR幅、未来ATR/帯毒で接頭不変')
    # ----------------------------------------
    # 168と同じ人工場を両engineへ渡し、定数配列以外の差がないことを確認する。
    compared=0
    for repeat in range(60):
        n=40;times=(np.arange(n)*3+2700).tolist();core=rng.choice((-1,0,1),n).tolist();technical=rng.choice((-1,0,1),n).tolist()
        values=T168.inputs(times,core,technical)
        values['exit_lookup']=lambda case,side,width:float(times[case]+width/10)
        for row in range(n):
            if rng.random()<.2:values['captures'][row]={'status':'cancelled','finish_key':(times[row]+2,2*row+2,2*row+2)}
        capacity=(None,1,2,10)[repeat%4]
        expected=engine168.replay(**values,capacity=capacity)
        changed={**values,'momentum_width':np.full(n,200,dtype=np.int64),'fade_width':np.full(n,400,dtype=np.int64)}
        actual=engine170.replay(**changed,capacity=capacity);assert actual==expected
        reflected={**changed,'core':-changed['core'],'technical':-changed['technical']}
        other=engine170.replay(**reflected,capacity=capacity)
        for a,b in zip(actual['records'],other['records'],strict=True):
            assert all(a[k]==b[k] for k in a if k!='side') and a['side']==1-b['side']
        compared+=n
    checks.append('60乱数場の168定数配列全結果同体・買売鏡像、無制限/cap1/2/10')
    values=T168.inputs([0,2,4],[1,1,1]);values['exit_lookup']=lambda case,side,width:float((0,2,4)[case]+1+width/100)
    long=engine170.replay(**{**values,'momentum_width':np.full(3,1000),'fade_width':np.full(3,1000)},capacity=1)
    short=engine170.replay(**{**values,'momentum_width':np.full(3,150),'fade_width':np.full(3,150)},capacity=1)
    assert [r['event'] for r in long['records']]==[0] and [r['event'] for r in short['records']]==[0,2]
    values=T168.inputs([2700],[1],[1])
    no_atr=engine170.replay(**{**values,'momentum_width':np.array([0]),'fade_width':np.array([0])},capacity=1)
    assert no_atr['records'][0]['origin']==2 and no_atr['records'][0]['width']==150
    checks.append('幅→exit時計→枠再利用の連動、ATR未知core0で固定補完だけ可能')
    proof={'成功':True,'金融と自然特徴未入力':True,'検査群':checks,'定数配列鏡像行数':compared,'未来接頭行数':prefix_rows,
        'Source':{p.name:sha(p) for p in [HERE/'width170.py',HERE/'engine170.py',Path(__file__),ROOT/'work/168数量枠の因果再生/engine168.py']}}
    (HERE/'幅の人工確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
