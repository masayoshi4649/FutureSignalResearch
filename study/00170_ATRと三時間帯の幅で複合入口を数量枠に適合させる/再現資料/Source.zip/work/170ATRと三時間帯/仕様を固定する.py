"""当時ATRと三時間帯による幅選択を数量枠込みで比較する条件を固定する。"""
from pathlib import Path
import json
import hashlib

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00170_ATRと三時間帯の幅で複合入口を数量枠に適合させる'


def main() -> None:
    """
    機能: 固定幅の近傍探索の不適格原因を受け、価格変動に比例する幅を事前固定する。
    引数: なし。169条件と停止票を入力し、追加期の候補別値で閾値を選ばない。
    返り値: None。170条件と未実行READMEを保存する。
    """
    assert not TRIAL.exists()
    assert max(int(p.name[:5]) for p in (ROOT/'study').iterdir() if p.is_dir() and p.name[:5].isdigit())==169
    parent=ROOT/'study/00169_数量枠の下で技術近傍と任意幅を再探索する/条件.json'
    previous=json.loads(parent.read_text(encoding='utf-8'))
    setting={k:previous[k] for k in ('core_profiles','hierarchy_variants','integration','technical_first',
        'cost','discovery_support','base_support','score','selectors')}
    setting.update(trial=170,date='2026-11-15',name='ATRと三時間帯の幅で複合入口を数量枠に適合させる')
    setting['parent']={'path':parent.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(parent.read_bytes()).hexdigest()}
    setting['hypothesis']='同じ固定幅では場の値動きに対する距離と保有時間が変わる。q0時点のM5 ATRで主枝幅を選び、方向・勢い・量・価格位置の技術入口と片側10枚の枠利用を両立できるかを調べる。'
    setting['capacity']='168のcap10・pending予約・同秒exit保守・未知枠保守と同体。新engineは幅をq0配列から読む部分だけ一般化し、定数配列で168へ全件同体を確認する。'
    setting['momentum_atr_multipliers']=[2,3,4,6]
    setting['fade_atr_multipliers']=[4,6,8,10]
    setting['width_grid']=[150,175,200,225,250,300,350,400,500,750,1000]
    setting['width_choice']='target=当時m5_atr×枝倍率×q0三帯倍率。target以上の最小grid、1000超は1000。ATR未知/非正なら主新規不成立。実取得後は選んだ幅を固定する。'
    setting['timeband_scales']=[{'id':'COMMON','DAY':1,'PRE':1,'POST':1},
        {'id':'PHASE','DAY':1,'PRE':.75,'POST':1.25}]
    setting['timeband_interpretation']='夜間米国前を狭め、米国後を広めにする仮説と共通倍率を比較する。ATRで既に差を吸収できる可能性もあり、三帯倍率が有利とは事前断定しない。各帯強制取得や境界返済は追加しない。'
    setting['entry']='166の4主profileと4局所階層は同じ技術式。主枝だけの幅を当時ATRで選ぶ。旧T/局所補完の幅はH150/H200の固定150/200を維持し、未知を埋めない。'
    setting['horizons']=['H30','H60','H120','SESSION']
    setting['screen']='4主profile×4階層×4順行倍率×4回復失敗倍率×2三帯倍率×4期限×2補完幅=4096政策。旧73場発見用。'
    setting['main_profile']={'profile':'MP0057_EX0076_B0_IMMEDIATE','hierarchy':'L180_S4',
        'momentum_atr_multiplier':3,'fade_atr_multiplier':6,'timeband_scale':'COMMON',
        'horizon':'H60','integration':'H200'}
    setting['training']='169と同じ前48場支持・Wilson順位のA/Bを適用。適格なしはnull。探索条件を追加7結果で交換しない。'
    setting['additional_period_status']='追加7場の167/168基準成績はRoot既使用。170の新4096候補成績は未計算。追加7全候補の再探索は禁止し、固定主案/A/Bだけの確認を別に残す。新規独立未見とは呼ばない。'
    setting['report']='全対象場・FANC・到達済み率/決済勝率・頻度・既知利益損失・前後/q0q1三帯・各枝・枠棄却・幅の選択分布。ATR幅と技術入口の効果を混同しない。'
    TRIAL.mkdir();(TRIAL/'検査').mkdir()
    path=TRIAL/'条件.json';path.write_text(json.dumps(setting,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (TRIAL/'README.md').write_text('# 00170 ATRと三時間帯の幅で複合入口を数量枠に適合させる\n\n2026-11-15。[条件](条件.json)を自然実行前に固定。固定pt幅から、当時ATR×枝倍率×三帯倍率で選ぶ幅へ拡張する。新しい技術入口の優位と幅・保有・枠利用の効果を分ける。現在未実行。\n',encoding='utf-8')
    print(json.dumps({'成功':True,'条件SHA256':hashlib.sha256(path.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__=='__main__':
    main()
