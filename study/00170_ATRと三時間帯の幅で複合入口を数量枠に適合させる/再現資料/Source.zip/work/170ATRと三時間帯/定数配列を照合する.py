"""170の定数幅配列が旧73二案について168全要求/取得/枠と同体か確認する。"""
from pathlib import Path
import sys
import numpy as np
import engine170

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'work/168数量枠の因果再生'))
import 再生する as R168
from 共通163 import read,save,sha


def main() -> None:
    """
    機能: 定数配列を旧168の両固定案・無制限/cap10全73場へ比較する。
    引数: なし。旧73だけを使い、170の可変幅候補の金融は計算しない。
    返り値: None。全要求/取得/数量audit同体とSource指紋を保存する。
    """
    assert sha(ROOT/'work/168数量枠の因果再生/engine168.py')==R168.read(R168.HERE/'人工検査結果.json')['engineSHA256']
    old=R168.BASE.Context165();context=R168.BASE.GenericContext(old.features,old.table,old.capture_rows)
    candidates=read(R168.TRIAL/'条件.json')['candidates'];captures=R168.capture_descriptors(context)
    tests=[]
    for candidate in candidates:
        birth=R168.BASE.births(context.features,candidate);n=len(birth['core']);hi=context.table.horizons.index(candidate['horizon'])
        width_map={int(w):i for i,w in enumerate(context.table.widths)}
        def exit_lookup(case: int,side: int,width: int) -> float|None:
            """
            機能: 両engineへ同じ元候補の決済時計だけを返す。
            引数: case/side/width(int)。
            返り値: floatは既知exit秒、Noneは未知。
            """
            wi=width_map[width]
            return float(context.arrays['exit_time'][case,side,wi,hi]) if context.arrays['known'][case,side,wi,hi] else None
        for capacity in (None,10):
            expected=R168.replay_candidate(context,birth,candidate,capacity)[4]
            actual=engine170.replay(context.event_keys,context.event_scenes,
                np.array([s['start'] for s in context.scenes]),np.array([s['end'] for s in context.scenes]),
                captures,birth['core'],birth['branches'],birth['technical'],birth['tier'],
                np.full(n,candidate['momentum_width'],dtype=np.int64),
                np.full(n,candidate['fade_width'],dtype=np.int64),int(candidate['integration'][1:]),exit_lookup,capacity=capacity)
            assert actual==expected,(candidate['id'],capacity)
            tests.append({'id':candidate['id'],'capacity':capacity,'q0':n,'取得':len(actual['records']),
                '全要求':len(actual['requests']),'全場audit':len(actual['audits']),'全同体':True})
    save(HERE/'定数配列の旧七十三場同体.json',{'成功':True,'170可変幅候補の金融未計算':True,
        '確認':tests,'Source':{p.relative_to(ROOT).as_posix():sha(p) for p in [Path(__file__),HERE/'engine170.py',
            ROOT/'work/168数量枠の因果再生/engine168.py',ROOT/'work/168数量枠の因果再生/再生する.py']}})
    print({'成功':True,'確認':tests})


if __name__=='__main__':main()
