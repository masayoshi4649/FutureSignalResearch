"""正式148特徴と共有金融から170を単一workerで隔離再現する。"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import importlib.util
import json
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent


def load(path: Path,name: str) -> object:
    """
    機能: Sourceをmain未実行で取り込む。
    引数: path(Path)、name(str)はSourceと登録名。
    返り値: objectはmodule。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


def main() -> None:
    """
    機能: Source非改変・特徴cache非複製で4096政策と固定二期間を再現する。
    引数: なし。
    返り値: None。全NPZ配列と固定候補統計JSONを正式正本へ照合する。
    """
    helper=load(ROOT/'work/163_164正式保存/正式入力から再現する.py','restore170')
    trial=ROOT/'study/00170_ATRと三時間帯の幅で複合入口を数量枠に適合させる';engine=ROOT/'work/170ATRと三時間帯'
    assert not(engine/'旧73探索').exists() and not(engine/'旧73固定候補').exists() and not(engine/'追加7固定候補').exists()
    helper.restore(helper.T162/'再現資料/出生と探索.zip',('work/162可変幅評価/自然射影/',))
    helper.restore(trial/'再現資料/ATR探索と固定適用の統計正本.zip',('work/170ATRと三時間帯/全幅/',))
    helper.restore(next((ROOT/'study').glob('00166_*'))/'再現資料/出生と統計正本.zip',('work/166可用指標の階層化/全出生/',))
    sys.path.insert(0,str(ROOT/'work/162入口探索'));common=helper.module(ROOT/'work/162入口探索/共通.py','共通');factory=common.data_module
    features=factory().load_feature_from_formal()
    def formal_data() -> object:
        """
        機能: 正式148の特徴をSourceの既存APIへ実行時接続する。
        引数: なし。
        返り値: objectは特徴loadだけを差し替えたdata module。
        """
        value=factory();value.load_feature_dataset=lambda:features;return value
    common.data_module=formal_data;sys.path.insert(0,str(engine))
    runner=load(engine/'探索する.py','正式170探索');qa=HERE/'隔離再現の検査';assert not qa.exists();qa.mkdir()
    (qa/'条件.json').write_bytes((trial/'条件.json').read_bytes());runner.TRIAL=qa
    paths=[engine/name for name in ('探索する.py','width170.py','engine170.py','固定候補を再生する.py')]
    before={p.relative_to(ROOT).as_posix():helper.sha(p) for p in paths}
    # workerを同一process内の1本へ接続し、正式特徴を子processごとにcache複製しない。
    runner.ProcessPoolExecutor=ThreadPoolExecutor;original_argv=sys.argv;sys.argv=[str(engine/'探索する.py'),'--workers','1']
    try:runner.main()
    finally:sys.argv=original_argv
    applied=load(engine/'固定候補を再生する.py','正式170固定適用')
    with zipfile.ZipFile(trial/'再現資料/ATR探索と固定適用の統計正本.zip') as source:
        seal=json.loads(source.read('work/170ATRと三時間帯/旧73探索/主案と前半A-Bの封印.json'))
    choices=[seal['事前固定主案']['candidate']]+[v['candidate'] for v in seal['選択'].values() if v is not None]
    setting=json.loads((trial/'条件.json').read_bytes());old=runner.WORKER_CONTEXT
    applied.run_context(old,choices,setting,engine/'旧73固定候補')
    base=ROOT/'work/167追加七場の入力';new_features,captures,_=applied.R168.BASE.load_features(base/'入口母集団')
    adapter=applied.R168.BASE.module(ROOT/'work/166可変場の数値化/arrays166.py','numeric170_formal')
    proof=json.loads((base/'生成の完了.json').read_bytes());table=adapter.load_table(base/'自然数値表',proof['cache'])
    new=applied.R168.BASE.GenericContext(new_features,table,captures)
    applied.run_context(new,choices,setting,engine/'追加7固定候補')
    arrays=helper.compare_arrays(trial/'再現資料/ATR探索と固定適用の統計正本.zip','work/170ATRと三時間帯/旧73探索/')
    checked=0
    with zipfile.ZipFile(trial/'再現資料/ATR探索と固定適用の統計正本.zip') as source:
        for member in source.namelist():
            if member.endswith(('固定候補の数量比較.json','全取得参照.json')):
                assert json.loads(source.read(member))==json.loads((ROOT/member).read_bytes());checked+=1
    assert all(helper.sha(ROOT/p)==h for p,h in before.items())
    (qa/'再現確認.json').write_text(json.dumps({'成功':True,'NPZ配列照合':arrays,'固定候補JSON照合':checked,
        'Source不変':before,'単一worker':True,'未見性能ではない':True},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':
    main()
