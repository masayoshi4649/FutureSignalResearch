"""170のATR幅探索・固定適用・独立検査を正式保存する。"""
from pathlib import Path
import importlib.util
import importlib.metadata
import json
import re
import sys

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00170_ATRと三時間帯の幅で複合入口を数量枠に適合させる';WORK=ROOT/'work/170ATRと三時間帯'
BOOK_SHA='c7c0ebeaebc51a24b256c74ad0dfe1aeaa1d7ff8d4ee019d25d5d92f064a0f1b'
spec=importlib.util.spec_from_file_location('formal168_for170',ROOT/'work/168正式保存/正式保存する.py')
template=importlib.util.module_from_spec(spec);spec.loader.exec_module(template);B=template.B


def settings() -> None:
    """
    機能: 168の同体V8配置を再用し、170の全567セルと設定差へ更新する。
    引数: なし。
    返り値: None。設定と結果.mdを保存する。
    """
    template.TRIAL=TRIAL;template.settings();path=TRIAL/'設定と結果.md';text=path.read_text(encoding='utf-8').replace('168','170')
    text=text.replace('ATR幅最適化は本試行対象外','当時ATR×枝倍率×三帯倍率の上側gridで主枝幅を選択')
    text=text.replace('EX0076の','EX0075/76の').replace('EX0076：','EX0075/76：').replace('量>=0.5・spread20','量>=0.5・spread10/20')
    text=text.replace('PRIMARY順行200/失速400/補完200 H60、FRONT48順行250/失速400/補完150 H120。IFD_FIRST',
                      '当時ATRによる主枝150～1000・固定補完150/200、H30/H60/H120/SESSION。IFD_FIRST')
    text=text.replace('6票中4以上。PRIMARY180分、FRONT48 120分','6票中4/5以上。開始120/180分の4階層')
    text=text.replace('固定二案の枝幅/期限を維持。対称IFD、Nは期限BBO清算。追加追尾なし','q0のATR幅を取得後固定。対称IFD、Nは期限BBO清算。追加追尾なし')
    text=text.replace('新規モデル学習、ATR幅の最適化、トレーリング、各帯強制取得は未実施','新規モデル学習、トレーリング、各帯強制取得は未実施。主枝のATR倍率/帯倍率/期限を比較')
    text+='''

| 設定ID | 条件・役割 | 結果参照 |
| --- | --- | --- |
| S170-ATR | 順行ATR×2/3/4/6、失速×4/6/8/10。target以上の最小grid150/175/200/225/250/300/350/400/500/750/1000、超過は1000。ATR未知/非正は主不成立 | 4096政策 |
| S170-PHASE | COMMON=全帯1、PHASE=DAY1/PRE0.75/POST1.25。q0時刻をNY09:30 DSTで区分。q1帯へ置換しない | 幅 |
| S170-PAST | 169固定selectorの前48のみ。取得250/到達100/率70%/頻度0.75/全48/未知10%以下/PF1.2/差引正。Bは前48q0三帯支持追加 | A/Bともnull |

R170：主4×階層4×順行倍率4×失速倍率4×帯倍率2×期限4×補完2＝4096。主案はMP0057_EX0076_B0_IMMEDIATE/L180_S4、ATR3/6、COMMON、H60、H200。全期発見82と事前主案・前半選択は別物。単独ATRの効果又は新規未見性能を示さない。
'''
    path.write_text(text,encoding='utf-8')


def docs() -> None:
    """
    機能: 4096探索、事前主案、前半null、追加固定適用を区別して4MDへ記す。
    引数: なし。
    返り値: None。170正式MDを保存する。
    """
    seal=B.read(WORK/'旧73探索/主案と前半A-Bの封印.json');found=B.read(WORK/'旧73探索/全期発見の上位.json')
    new=B.read(WORK/'追加7固定候補/固定候補の数量比較.json')['rows'][0];primary=seal['事前固定主案'];top=found['上位'][0]
    text=f'''# 170 ATRと三時間帯による主枝幅

2026-11-15。**事前主案の旧73場は620取得、68順35逆、先着66.02%。前48場56.25%・後25場74.55%で不均一**。ATR幅を導入しただけで入口の70%超が安定したとは言えない。前48場の固定選択A/Bはともにnull。全期報告支持82件は発見用として保持し、主案へ交換しない。

## 仮説・条件

同じ固定幅でも相場の値動きに対する距離と保有時間は変わる。主枝の対称IFD幅をq0のM5 ATRへ比例させ、複合技術入口と片側10枚枠を両立できるか検証した。[条件](条件.json)SHA `{BOOK_SHA}`。

入口は166の主4profile・局所4階層。順行/失速はMACD・RSI・DMI/ADX・BB・形状・量を組み合わせる。順行倍率2/3/4/6、失速4/6/8/10、帯倍率COMMON又はDAY1/PRE0.75/POST1.25、4期限、補完150/200。全4096政策。主案はATR3/6・COMMON・H60・H200。q0で幅を選び取得後固定し、後のATRで拡張しない。

target以上の最小grid150～1000ptを用い、1000超は1000へ。ATR未知/非正は主不成立とし、未知0pt注文を出さない。旧T/局所補完の固定150/200は維持する。買売同条件、各要求mini1枚・片側10枚、保有と未決を合計して予約する。168の数量制御は幅配列以外同体。

## 入力・費用・分母

旧73場35,339q0・31,642caseは既使用。追加7場は167/168で既使用の基準期であり、新規独立未見ではない。特徴/価格索引/生金融を共用し、Rawを試行ごとに複製しない。

mini100円/pt、片道税込38.5円、往復77円＋追加滑り1,000円のC5。実BBOのスプレッドを含む。F/Aは欠測前の最初の確定到達、Nは両未到達で期限完了、Cは観測不足。Nは期限BBOの費用後損益へ算入する。Cは0円決済せず全件収支null、既知利益/損失と差引だけを計数。F/(F+A)と費用後決済勝率は別物。

## 旧73の事前主案

{B.metric_table(primary)}

前半の既知差引は+65,664円、後半+4,021,215円。全期額だけで安定性を説明しない。全73場参加と0.860回/時を維持したが、先着率70%は未達。

## 前48選択と全期発見

固定selector A/Bの前48適格は0件。後25や追加7を使って補完採用しない。全期支持82件は全期発見であり、追加7へは持ち込まない。頻度順先頭は順行ATR2/失速ATR10・COMMON・H60/H200で次の通り。

{B.metric_table(top)}

## 固定主案の追加7基準期確認

{B.metric_table(new['cap10'])}

114取得のうち到達済みは8順3逆の11件だけ、未到達101・観測不足2。72.73%だけを高い優位の証拠にしない。費用後決済勝率は45.54%、利益1,274,073円・損失920,697円、既知差引+353,376円。q0のデイは7順0逆、NY前1順3逆、NY後0順0逆で率未定義。帯別の支持差を残し、利益が得られた理由を到達率だけへ帰さない。

## 検査と保存

純幅独立確認はceil387,744セル、定数168同体14,400行、可変幅一覧oracle14,400行、旧73封印幅565,424セル。旧73自然は全4096不変式、支持82全て・主案・層別を合わせ210政策、158,553要求/126,391取得・132,930統計セルが一致。全4096の全取得再生ではない。

固定二期間は939要求/734取得、追加幅出生36,080セルと全場/三帯/幅分布/数量が独立一致。原板第二parser全再走査やmini実約定保証ではない。Source/自然検査/保存QAを別記録する。

[設定と結果](設定と結果.md)、[心理と限界](条件心理と限界.md)、[再現手順](再現手順.md)、[保存索引](再現資料/保存索引.json)を参照。全場・三帯・幅分布・上位40/支持全配列は正本へ保存し、xlsxを生成しない。
'''
    (TRIAL/'README.md').write_text(text,encoding='utf-8')
    (TRIAL/'条件心理と限界.md').write_text('''# 170 ATR幅の仮説と限界

2026-11-15。心理・市場構造の説明は仮説、件数/損益/支持は固定データでの確認事実として区別する。

## 仮説

同じ200ptでも静かな場では遠く、値動きの大きい場では近い。ATRで主枝幅を変えると、先着の難度だけでなく保有時間と片側枠の占有も変わる。技術方向・動力・量で入口を作ることと、値幅を相場へ適合させることは別の効果である。夜間NY前を狭めNY後を広める倍率は仮説に過ぎず、ATR自体が帯差を吸収できる可能性もある。

幅は現在q0のATRと帯から選び取得後は固定する。後から幅を広げて損切りを避けるトレーリング緩和とは異なる。数量制約・未知/同秒の保守的処理を168から維持する。

## 確認事実と次の問い

事前主案は旧全期66.02%、前半56.25%、後半74.55%。前48固定支持のA/Bはともにnull。全期支持82候補はあっても前半採用できず、支持・方向・保有時間・量の組合せが期間をまたいで安定していない。固定主案を全期上位へ後付けで変更しない。

追加7主案は114取得だが同幅到達は11件しかなく、NY後は35取得すべてNで、到達済み率は未定義。全取得の費用後結果と到達済みだけの率を区別する。既知差引が黒字でも、各帯が同じ機構で高い到達率を持つとは言えない。次の入口/局面切替は別試行で条件を固定し、170の幅や入口を書き換えない。

旧73・追加7とも既使用。多数比較・全期上位・少数到達による率を独立未見の証拠としない。未知Cを決済済み0円として埋めず、保有枠も場末まで保持する。実mini板、待ち行列、通信遅延、約定マッチングは未検証。未参加の仮想利益を機会損失として最適化していない。
''',encoding='utf-8')
    settings()
    (TRIAL/'再現手順.md').write_text('''# 170 再現手順

2026-11-15。Python3.14.3/NumPy2.5.4/tzdata2026.6。Source/環境/サイズ/SHA/全memberは[保存索引](再現資料/保存索引.json)。

## 保存構成

[Source.zip](再現資料/Source.zip)は純幅/配列engine/生成・探索・固定適用・人工/独立QA・保存/再現Sourceを元byteで保持する。[ATR探索と固定適用の統計正本.zip](再現資料/ATR探索と固定適用の統計正本.zip)は全幅、4096探索NPZ/軸/主案・A/B封印/全期上位と原因診断、固定二期間の全場/取得/要求/幅分布、追加幅出生と封印完了を保持する。圧縮済みNPZ/gzipは外ZIP無圧縮。

旧Raw/金融は[inputs/00163](../../inputs/00163_任意幅の共用価格索引/README.md)、追加7は[inputs/00167](../../inputs/00167_追加七場の入口と共用価格索引/README.md)を一組だけ参照。166の出生、168数量部品、169純selectorを再用する。

## 隔離再現

元work成果物のない別checkoutを使い、162〜168の必要Source.zipと170Source.zipをROOTへ展開する。正式inputs/00148/00163/00167、166出生正本、162数値射影を保持する。169純selectorと人工票は170Sourceへ小型依存として収録している。親Sourceを変更しない。

```powershell
New-Item -ItemType Junction -Path 'work/163任意幅の数値化/自然数値表' -Target (Resolve-Path -LiteralPath 'inputs/00163_任意幅の共用価格索引/数値表')
New-Item -ItemType Junction -Path 'work/167追加七場の入力' -Target (Resolve-Path -LiteralPath 'inputs/00167_追加七場の入口と共用価格索引')
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/170正式保存/正式入力から再現する.py'
```

再現wrapperは正式148特徴をAPIへ実行時接続し、process poolを単一thread workerへ接続する。Source非改変で全4096と固定主案二期間を再生し、全NPZ配列と固定候補統計/取得JSONを正本へ照合する。共有特徴cacheを新たに複製しない。保存時にwrapperはcompileのみ確認し、このwrapperで全4096を再実行したとは称さない。

## 実施済み独立確認

純幅・旧73自然・固定二期間の各独立票をSource.zipへ保持した。旧73の全4096は不変式、全支持82＋主案＋各軸層別の210政策は全要求・取得6属性・元金融統計を再計算。固定主案の二期間は全場/帯/幅分布と数量上限、追加金融前の封印幅出生と全選択eventの幅を一致確認した。

追加7は既使用の基準期であり、幅/入口の探索をそこでやり直していない。A/B nullのまま事前主案だけを適用した。原板第二parser全面再走査や実mini約定を保証しない。未知を含む既知差引と全件収支nullは区別する。
''',encoding='utf-8')


def main() -> None:
    """
    機能: 170正式MD/ZIP/索引を作り、保存だけの検査と停止を残す。
    引数: なし。169/171とCSV/globalを変更しない。
    返り値: None。170の正式資料を保存する。
    """
    assert B.sha(TRIAL/'条件.json')==BOOK_SHA
    source=B.source_files('work/170ATRと三時間帯')+B.source_files('work/170純幅独立確認')+B.source_files('work/170自然独立確認')
    source+=[ROOT/'work/169数量枠と技術近傍/selector169.py',ROOT/'work/169数量枠と技術近傍/選択の人工確認.json']
    source+=[p for p in HERE.iterdir() if p.is_file() and p.suffix=='.py']+[TRIAL/'条件.json',*(TRIAL/'検査').glob('F*.json')]
    data=[p for folder in ('全幅','旧73探索','旧73固定候補','追加7固定候補') for p in (WORK/folder).iterdir() if p.is_file()]
    data+=[WORK/'追加7固定候補の幅と出生.npz']
    frozen={p:B.sha(p) for p in set(source+data)};docs();folder=TRIAL/'再現資料';folder.mkdir(exist_ok=True)
    a=B.archive(folder/'Source.zip',source);b=B.archive(folder/'ATR探索と固定適用の統計正本.zip',data)
    refs=[ROOT/'inputs/00163_任意幅の共用価格索引/保存索引.json',ROOT/'inputs/00167_追加七場の入口と共用価格索引/保存索引.json']
    for trial in (162,163,164,165,166,167,168):refs.append(next((ROOT/'study').glob(f'{trial:05d}_*'))/'再現資料/Source.zip')
    refs+=[next((ROOT/'study').glob('00162_*'))/'再現資料/出生と探索.zip',next((ROOT/'study').glob('00166_*'))/'再現資料/出生と統計正本.zip']
    B.save(folder/'保存索引.json',{'成功':True,'試行':170,'条件':B.reference(TRIAL/'条件.json'),
        '環境':{'Python':sys.version,'NumPy':importlib.metadata.version('numpy'),'tzdata':importlib.metadata.version('tzdata')},
        '正本':[{'archive':B.reference(folder/'Source.zip'),'members':a},{'archive':B.reference(folder/'ATR探索と固定適用の統計正本.zip'),'members':b}],
        '共用入力と親参照':[B.reference(p) for p in refs],
        '非重複':'Raw/価格索引/生金融/当時特徴は親の一組を参照。169純selectorだけ小型依存として同体収録。',
        '区別':'旧73全期発見・事前主案・前48A/Bnull・既使用追加7固定適用を別に保持。',
        '再現wrapper':'compileだけ確認。独立自然QAと保存QAは別。'})
    assert all(B.sha(p)==h for p,h in frozen.items())
    documents=[TRIAL/name for name in ('README.md','条件心理と限界.md','設定と結果.md','再現手順.md')];links=0;rows=0
    for path in documents:
        text=path.read_text(encoding='utf-8');assert '\ufffd' not in text
        for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)',text):
            if '://' in target or target.startswith('#'):continue
            assert (path.parent/target.split('#')[0]).exists(),(path.name,target);links+=1
    for line in (TRIAL/'設定と結果.md').read_text(encoding='utf-8').splitlines():
        cells=[c.strip() for c in line.split('|')[1:-1]] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch('[A-Z][0-9]{2}',cells[0]):rows+=1
    assert rows==63
    compile((HERE/'正式入力から再現する.py').read_text(encoding='utf-8'),str(HERE/'正式入力から再現する.py'),'exec')
    B.save(TRIAL/'検査/正式保存の確認.json',{'成功':True,'保存だけの検査':True,'文書数':4,'有効リンク数':links,'V8セル':rows*9,
        'ZIP数':2,'全member数':len(a)+len(b),'全CRC_SHA_サイズ_元byte同体':True,'凍結元不変':len(frozen),
        '文書指紋':[B.reference(p) for p in documents],'自然QAを保存QAと区別':True,'169_171_CSV_global変更':False})
    B.save(TRIAL/'検査/正式保存の停止.json',{'成功':True,'試行':170,'条件SHA256':BOOK_SHA,
        '保存確認SHA256':B.sha(TRIAL/'検査/正式保存の確認.json'),'保存索引SHA256':B.sha(folder/'保存索引.json'),
        'SourceZIP_SHA256':B.sha(folder/'Source.zip'),'統計ZIP_SHA256':B.sha(folder/'ATR探索と固定適用の統計正本.zip'),'凍結元不変':True})
    print(json.dumps({'成功':True,'停止':B.reference(TRIAL/'検査/正式保存の停止.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
