"""206の全85純条件を、固定199/200の親出生と別の配列式で照合する。"""
from collections import defaultdict
from pathlib import Path
import gzip
import hashlib
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
TARGET=ROOT/'work/206指数間の入口比較'
TRIAL=ROOT/'study/00206_指数間の相対変化を複合入口へ加える'
INPUT=ROOT/'inputs/00206_両指数の固定端点相対変化'
DELAYS=(1,5,30,60);MODES=('AVAIL','PEER','VETO','RELATIVE')
VARIANTS=[('BASE',None,'BASE')]+[(f'D{d:03d}_{m}',i,m) for i,d in enumerate(DELAYS) for m in MODES]
NK_IDS=('E199_00','E199_02','E199_05');TP_IDS=(0,10)
sys.path.insert(0,str(ROOT/'work/201板数量比較'))
import 実行201 as J


# ----------------------------------------
def read(path: Path) -> object:
    """
    機能: 純JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    body=path.read_bytes();return json.loads(gzip.decompress(body) if path.suffix=='.gz' else body)


# ----------------------------------------
def ref(path: Path) -> dict:
    """
    機能: 対象Source・純出生の内容指紋を得る。
    引数: path(Path)。
    返り値: dictは相対path・byte・SHA。
    """
    with path.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':sha}


# ----------------------------------------
def oracle(r: np.ndarray,q: np.ndarray,side: np.ndarray,di: int | None,mode: str) -> tuple:
    """
    機能: 生産decide/filterを使わず、各要求の許可・未知を配列式で計算する。
    引数: r/q(np.ndarray[n,4,4,2])、side(np.ndarray[n])、di(int|None)、mode(str)。
    返り値: tuple[np.ndarray[bool],np.ndarray[bool]]。
    """
    n=len(side)
    if mode=='BASE':return np.ones(n,bool),np.zeros(n,bool)
    present=np.sum(q[:,di],axis=(1,2))==8
    assert np.isfinite(r[present,di]).all()
    if mode=='AVAIL':allow=present
    elif mode=='PEER':allow=present&(r[:,di,2,1]*side>0)&(r[:,di,3,1]*side>0)
    elif mode=='VETO':
        opposite=np.sum(r[:,di,:,1]*side[:,None]<0,axis=1)==4
        allow=~(present&opposite)
    elif mode=='RELATIVE':allow=present&(r[:,di,2,1]*side>0)&((r[:,di,2,0]-r[:,di,2,1])*side<0)&(r[:,di,0,0]*side>0)
    else:raise AssertionError(mode)
    return allow,~present


# ----------------------------------------
def load_index() -> dict:
    """
    機能: 原行キーで純returnと品質を索引化する。
    引数: なし。
    返り値: dictはsymbol→(場,原行)→(時計,return,quality)。
    """
    result={'NK225':{},'TOPIX':{}}
    done=read(INPUT/'完了.json');assert not done['financial_labels_used']
    for row in done['files']:
        p=ROOT/row['file']['path'];assert ref(p)['sha256']==row['file']['sha256']
        with np.load(p,allow_pickle=False) as z:
            for i,line in enumerate(z['q0_line']):
                key=(row['session'],int(line));assert key not in result[row['symbol']]
                result[row['symbol']][key]=(float(z['q0_time'][i]),z['log_return'][i].copy(),z['quality_known'][i].copy())
    assert [len(result[s]) for s in ('NK225','TOPIX')]==[40314,35361]
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: 全85の純出生・幅期限・同q0迂回禁止・未知診断を金融前に照合する。
    引数: なし。
    返り値: None。金融、先着、損益は参照せず、生産側の条件式を呼ばない。
    """
    assert not(TARGET/'金融開始前固定.json').exists(),'この確認は金融前に実行する'
    condition=read(TRIAL/'条件.json');sealed=read(TARGET/'純封印.json');assert sealed['条件']==ref(TRIAL/'条件.json')
    before=ref(TRIAL/'条件.json')
    for r in condition['Sourceと参照']+condition['純出生']:assert ref(ROOT/r['path'])==r
    assert condition['カタログ']['規模']==85 and condition['カタログ']['主遅延秒']==1
    index=load_index();checks=0;requested=0;diagnostics={};parents=[];baseline_checks=0
    for leg in (*J.C.LEGS,'追加2'):
        pure=J.N.load_pure_leg() if leg=='追加2' else J.C.load_pure_leg(leg)
        rows=[]
        for meta in pure['features'].q0_meta:
            t,r,q=index['NK225'][(meta['session'],int(meta['q0_line']))];assert t==meta['q0_time'];rows.append((r,q))
        returns=np.asarray([r[0] for r in rows]);quality=np.asarray([r[1] for r in rows])
        parent_path=ROOT/'work/199追加二場の固定診断/追加二場純出生.npz' if leg=='追加2' else ROOT/'work/199保留中の旧幹確認_未知保持'/(leg+'_新入口.npz')
        parents.append(ref(parent_path));diag={}
        with np.load(parent_path,allow_pickle=False) as parent,np.load(TARGET/'純入口'/(leg+'.npz'),allow_pickle=False) as child,np.load(ROOT/'work/201板数量比較/純入口'/(leg+'.npz'),allow_pickle=False) as baseline:
            for mother in NK_IDS:
                original={a:parent[mother+'__birth__'+a].copy() for a in ('core','branches','technical','tier')}
                side=np.where(original['core']!=0,original['core'],original['technical'])
                active=side!=0
                for a in ('core','branches','technical','tier'):
                    np.testing.assert_array_equal(original[a],baseline[mother+'_BASE__birth__'+a]);baseline_checks+=len(side)
                for key,di,mode in VARIANTS:
                    name=mother+'_'+key;allow,unknown=oracle(returns,quality,side,di,mode);reject=active&~allow
                    diag[name]={'proposed':int(active.sum()),'unknown':int(np.sum(active&unknown)),'rejected':int(reject.sum())};requested+=int(active.sum())
                    for attr,blank in (('core',0),('branches',-1),('technical',0),('tier',0)):
                        expected=original[attr].copy();expected[reject]=blank
                        np.testing.assert_array_equal(child[name+'__birth__'+attr],expected,err_msg=leg+'/'+name+'/'+attr);checks+=len(side)
                    for attr in ('mw','fw','hi','added'):
                        np.testing.assert_array_equal(child[name+'__'+attr],parent[mother+'__'+attr]);checks+=len(side)
                        if mode=='BASE':
                            np.testing.assert_array_equal(child[name+'__'+attr],baseline[mother+'_BASE__'+attr]);baseline_checks+=len(side)
            assert len(child.files)==3*17*8
        diagnostics[leg]=diag
        print('NK純独立一致',leg,flush=True)
    sources=[ROOT/'inputs/00200_TOPIXの観測被覆と時間順入口'/n for n in ('純入口.json.gz','追加二場純入口.json.gz')]
    parents.extend(ref(p) for p in sources);old=read(sources[0])+read(sources[1]);new=read(TARGET/'純入口/TOPIX.json.gz')
    assert len(old)==len(new)==35361
    rows=[index['TOPIX'][(r['session'],r['line'])] for r in old]
    assert [r[0] for r in rows]==[r['time'] for r in old]
    returns=np.asarray([r[1] for r in rows]);quality=np.asarray([r[2] for r in rows]);diag={}
    for pos,mother in enumerate(TP_IDS):
        side=np.asarray([r['signals'][mother] for r in old]);active=side!=0
        for vi,(key,di,mode) in enumerate(VARIANTS):
            allow,unknown=oracle(returns,quality,side,di,mode);name=f'I{mother:02d}_'+key
            diag[name]={'proposed':int(active.sum()),'unknown':int(np.sum(active&unknown)),'rejected':int(np.sum(active&~allow))};requested+=int(active.sum())
            offset=pos*17+vi
            expected=np.where(allow,side,0)
            np.testing.assert_array_equal(np.asarray([r['signals'][offset] for r in new]),expected);checks+=len(side)
            for attr in ('widths','origins'):
                assert [r[attr][offset] for r in new]==[r[attr][mother] for r in old];checks+=len(side)
    for a,b in zip(old,new,strict=True):
        assert set(b)=={'session','line','time','band','signals','widths','origins'}
        for key in ('session','line','time','band'):assert a[key]==b[key];checks+=1
        assert len(b['signals'])==len(b['widths'])==len(b['origins'])==34
    diagnostics['TOPIX']=diag
    assert diagnostics==read(TARGET/'純成立診断.json')
    assert ref(TRIAL/'条件.json')==before
    assert not(TARGET/'金融開始前固定.json').exists()
    proof={'試行':206,'成功':True,'金融未参照':True,'全85純出生の別式照合':checks,'全85判断要求':requested,
        'NK親199と201BASE属性一致':baseline_checks,'decide_filter呼出なし':True,
        '未知規則':'VETOのみ親保持。他3modeはQ不足で不成立。BASE同体。',
        '同q0迂回':'coreが存在する要求はcore側で判定し、棄却時はtechnicalもゼロ。',
        '条件':before,'Source':ref(Path(__file__)),'親純出生':parents,'診断':diagnostics,
        '範囲':'価格時計の純値は別実装で全件監査済み。この検査は純値から追加条件への接続と親の幅期限保持。'}
    HERE.mkdir(parents=True,exist_ok=True)
    path=HERE/'純判定独立確認206.json';body=json.dumps(proof,ensure_ascii=False,indent=2)+'\n'
    if path.exists():assert path.read_text(encoding='utf-8')==body
    else:path.write_text(body,encoding='utf-8')
    print(json.dumps({'成功':True,'全85属性照合':checks,'要求':requested,'親BASE属性照合':baseline_checks},ensure_ascii=False),flush=True)


# ----------------------------------------
if __name__=='__main__':main()
