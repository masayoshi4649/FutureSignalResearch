"""金融未実行のまま、206純判断の独立確認をSource補足版2へ束縛する。"""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
TARGET=ROOT/'work/206指数間の入口比較'
TRIAL=ROOT/'study/00206_指数間の相対変化を複合入口へ加える'


# ----------------------------------------
def read(path: Path) -> object:
    """
    機能: JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    return json.loads(path.read_text(encoding='utf-8'))


# ----------------------------------------
def ref(path: Path) -> dict:
    """
    機能: 内容の指紋を得る。
    引数: path(Path)。
    返り値: dictはpath/byte/SHA。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


# ----------------------------------------
def main() -> None:
    """
    機能: 版2の差分がSource封印だけであり、全85純出生と条件が旧独立確認と同体か検査する。
    引数: なし。
    返り値: None。金融前条件を後から遡及改変しない。
    """
    assert not(TARGET/'金融開始前固定.json').exists()
    old=read(TRIAL/'条件.json');new=read(TRIAL/'条件_v2.json');prior=read(HERE/'純判定独立確認206.json')
    assert prior['成功'] and prior['金融未参照'] and prior['条件']==ref(TRIAL/'条件.json')
    assert read(TARGET/'純封印_v2.json')['条件']==ref(TRIAL/'条件_v2.json')
    for key in ('カタログ','人工','純出生','全85金融前'):assert old[key]==new[key],key
    before={r['path']:r for r in old['Sourceと参照']};after={r['path']:r for r in new['Sourceと参照']}
    added=set(after)-set(before);removed=set(before)-set(after)
    assert added=={'work/206指数間の入口比較/実行206_v2.py','study/00206_指数間の相対変化を複合入口へ加える/条件.json','work/206指数間の入口比較/純封印.json','scripts/入口分析/分析.py'}
    assert removed=={'work/206指数間の入口比較/実行206.py'}
    for path in set(before)&set(after):assert before[path]==after[path]
    for r in new['Sourceと参照']+new['純出生']:assert ref(ROOT/r['path'])==r
    text=(TARGET/'実行206_v2.py').read_text(encoding='utf-8')
    text=text.replace('全85の指数間確認。版2は金融前に動的到達木を明示封印する。','全85の指数間確認を、金融前純封印と固定IFDに分離して評価する。')
    text=text.replace("INPUT/'抽出前固定.json.gz',\n        ROOT/'scripts/入口分析/分析.py',TRIAL/'条件.json',HERE/'純封印.json'))","INPUT/'抽出前固定.json.gz'))")
    text=text.replace('条件_v2.json','条件.json').replace('純封印_v2.json','純封印.json')
    assert text==(TARGET/'実行206.py').read_text(encoding='utf-8'),'封印以外の実装差分'
    source=ROOT/'scripts/入口分析/分析.py'
    with zipfile.ZipFile(ROOT/'study/00200_TOPIXの観測被覆と構造確認の順序を分ける/Source.zip') as z:
        assert z.read('scripts/入口分析/分析.py')==source.read_bytes()
    proof={'試行':206,'成功':True,'金融未参照':True,'版2条件':ref(TRIAL/'条件_v2.json'),'版2封印':ref(TARGET/'純封印_v2.json'),
        '元の全85別式照合':ref(HERE/'純判定独立確認206.json'),'全85純出生物理指紋同体':True,'カタログと人工条件同体':True,
        '生産Source差分は封印参照のみ':True,'追加直接Source':sorted(added),'除かれた直接Source':sorted(removed),
        '旧条件と旧封印は版2で明示参照':True,'動的分析は200正式ZIPと同体':ref(source),
        'Source':ref(Path(__file__)),'判断':'価格時計と未知の限界を維持した金融前の純条件確認を通過。金融結果の採用判断ではない。'}
    assert not(TARGET/'金融開始前固定.json').exists()
    path=HERE/'純判定独立確認206_v2.json';body=json.dumps(proof,ensure_ascii=False,indent=2)+'\n'
    if path.exists():assert path.read_text(encoding='utf-8')==body
    else:path.write_text(body,encoding='utf-8')
    print(json.dumps({'成功':True,'版2へ束縛':True,'全85純判断同体':True},ensure_ascii=False),flush=True)


# ----------------------------------------
if __name__=='__main__':main()
