"""206の固定85口座を、一件状態の枠・費用式・別集計で独立確認する。"""
from collections import defaultdict
from pathlib import Path
import copy
import gzip
import hashlib
import importlib.util
import json
import math
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
TARGET=ROOT/'work/206指数間の入口比較'
TRIAL=ROOT/'study/00206_指数間の相対変化を複合入口へ加える'
VARIANTS=('BASE',)+tuple(f'D{d:03d}_{m}' for d in (1,5,30,60) for m in ('AVAIL','PEER','VETO','RELATIVE'))
NK_IDS=('E199_00','E199_02','E199_05');TP_IDS=(0,10)
spec=importlib.util.spec_from_file_location('independent201_for206',ROOT/'work/201独立検査/独立確認201.py')
P=importlib.util.module_from_spec(spec);sys.modules[spec.name]=P;spec.loader.exec_module(P)
J=P.J;V=P.V


# ----------------------------------------
def read(path: Path) -> object:
    """
    機能: 固定正本のJSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    body=path.read_bytes();return json.loads(gzip.decompress(body) if path.suffix=='.gz' else body)


# ----------------------------------------
def ref(path: Path) -> dict:
    """
    機能: 正本の内容指紋を得る。
    引数: path(Path)。
    返り値: dictはpath/bytes/SHA。
    """
    with path.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':sha}


# ----------------------------------------
def save(path: Path,value: object) -> None:
    """
    機能: 独立票を保存し、再実行では同体を要求する。
    引数: path(Path)、value(object)。
    返り値: None。
    """
    body=(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
    if path.suffix=='.gz':body=gzip.compress(body,mtime=0)
    if path.exists():assert path.read_bytes()==body,path
    else:path.write_bytes(body)


# ----------------------------------------
def baseline(packs: dict) -> list:
    """
    機能: 206の5BASEを199旧81/追加2および200固定正本へ全件照合する。
    引数: packs(dict)は85台帳。
    返り値: list[dict]は同体票。生産側BASE照合関数を呼ばない。
    """
    sources={};old=ROOT/'study/00199_保留中の旧幹を確認済みの根拠で切り替える'
    for mother in NK_IDS:sources[f'NK225206_{mother}_BASE']=[old/'保存金融'/(mother+'__C0_IFD.json.gz'),old/'追加二場/保存金融'/('NK225199_'+mother+'__C0_IFD.json.gz')]
    for mother in TP_IDS:
        paths=list((ROOT/'work/200TOPIX/全83金融正本').glob(f'TOPIX200_N{mother:02d}_*.json.gz'));assert len(paths)==1
        sources[f'TOPIX206_I{mother:02d}_BASE']=paths
    proof=[]
    for identity,paths in sources.items():
        parents=[read(p) for p in paths]
        for field in ('ledger','sessions','positions'):
            expected={k:sum((p[field][k] for p in parents),[]) for k in parents[0][field]} if field=='ledger' else sum((p[field] for p in parents),[])
            assert packs[identity][field]==expected,(identity,field)
        proof.append({'候補':identity,'成功':True,'元金融':[ref(p) for p in paths]})
    return proof


# ----------------------------------------
def nk_slots(packs: dict) -> dict:
    """
    機能: heap生産エンジンではなく既存の独立一件状態でNK51口座の全後続枠を再生する。
    引数: packs(dict)は保存金融。
    返り値: dictは属性照合数・全q0/予約/保有の診断。
    """
    checks=0;fee_checks=0;diagnostics={}
    for leg in (*J.C.LEGS,'追加2'):
        pure=J.N.load_pure_leg() if leg=='追加2' else J.C.load_pure_leg(leg)
        if leg!='追加2':
            assert(J.C.HERE/'cache'/(leg+'_純基準181.npz')).exists();J.C.seal_pure_leg(pure)
        context=J.NF.attach_financial(J.NF.load_unvalued_context(pure)['context'])['context'] if leg=='追加2' else J.C.attach_financial(pure)['context']
        captures=J.A.M.B.captures(context)
        with np.load(TARGET/'純入口'/(leg+'.npz'),allow_pickle=False) as z:
            for mother in NK_IDS:
                for variant in VARIANTS:
                    key=mother+'_'+variant;identity='NK225206_'+key
                    bundle={k:z[key+'__'+k] for k in ('mw','fw','hi','added')}
                    bundle['birth']={k:z[key+'__birth__'+k] for k in ('core','branches','technical','tier')}
                    records,diag=P.nk_slots(context,bundle,captures);diagnostics[identity+'/'+leg]=diag
                    ledger=packs[identity]['ledger'];ids=[i for i,v in enumerate(ledger['leg']) if v==leg]
                    assert len(records)==len(ids),(identity,leg,'取得数')
                    for row,i in zip(records,ids,strict=True):
                        for attr in ('event','case','side','width','origin'):assert ledger[attr][i]==row[attr];checks+=1
                        assert ledger['horizon'][i]==context.table.horizons[row['hi']];checks+=1
                        case=row['case'];side=row['side'];wi=list(context.table.widths).index(row['width']);cell=(case,side,wi,row['hi'])
                        known=bool(context.arrays['known'][cell])
                        expected={'known':known,'case_id':context.table.case_ids[case],'scene':context.sessions[int(context.case_scene[case])],
                            'phase':int(context.event_phases[row['event']]),'added':int(bundle['added'][row['event']]),'leg':leg}
                        for attr in ('label','exit_index','exit_line','forced','status'):expected[attr]=context.arrays[attr][cell].item()
                        for attr in ('exit_time','exit_price'):expected[attr]=float(context.arrays[attr][cell]) if known else None
                        for attr in ('entry_time','entry_index','entry_line'):expected[attr]=context.arrays[attr][case].item()
                        expected['entry_price']=float(context.arrays['entry_price'][case,side])
                        if known:
                            sign=1 if side==0 else -1
                            expected['net']=sign*(expected['exit_price']-expected['entry_price'])*100-77-1000
                            assert math.isclose(expected['net'],float(context.arrays['net'][cell]),abs_tol=1e-7);fee_checks+=1
                        else:expected['net']=None
                        for attr,value in expected.items():checks+=V.V.check_equal(ledger[attr][i],value,(identity,leg,i,attr))
        print('NK枠独立一致',leg,flush=True)
    return {'属性照合':checks,'既知費用式照合':fee_checks,'診断':diagnostics}


# ----------------------------------------
def topix_slots(packs: dict) -> dict:
    """
    機能: 元Routeセルだけを共用し、TOPIX34口座の枠選択・費用・台帳を別再生する。
    引数: packs(dict)。
    返り値: dictは全件照合と予約保有診断。原BBOの独立再走査とはしない。
    """
    entries=copy.deepcopy(read(J.T.M.HERE/'入力台帳.json')['entries'])
    mapping={r['session']:r for r in read(ROOT/'inputs/TOPIX原順8列_20260921_20261116/台帳.json')['entries']}
    for entry in entries:entry['cache_absolute']=str(ROOT/mapping[entry['session']]['path'])
    entries.extend(r for r in read(ROOT/'inputs/00194_20261116夜と1117昼の固定適用入力/原順8列/入力台帳.json')['entries'] if r['symbol']=='TOPIX')
    by=defaultdict(list)
    for row in read(TARGET/'純入口/TOPIX.json.gz'):by[row['session']].append(row)
    checks=0;fees=0;diagnostics={}
    for entry in entries:
        scene=entry['session'];route=J.T.M.Route(entry);cells={}
        for mp,mother in enumerate(TP_IDS):
            for vp,variant in enumerate(VARIANTS):
                ci=mp*17+vp;identity=f'TOPIX206_I{mother:02d}_'+variant;ledger=packs[identity]['ledger']
                ids=[i for i,s in enumerate(ledger['scene']) if s==scene];cursor=0;unavailable=-math.inf;diag=defaultdict(int)
                for row in by[scene]:
                    diag['全q0']+=1;side=row['signals'][ci]
                    if not side:continue
                    diag['純要求']+=1
                    if row['time']<=unavailable:diag['枠棄却']+=1;continue
                    key=(row['time'],row['line'],side,row['widths'][ci])
                    if key not in cells:cells[key]=route.cell(*key)
                    cell=cells[key]
                    if cell is None:unavailable=min(row['time']+30,route.force);diag['予約失効']+=1;continue
                    assert cursor<len(ids),(identity,scene,'不足取得');i=ids[cursor];cursor+=1;diag['取得']+=1
                    expected={'known':not cell['unknown'],'net':None if cell['unknown'] else round(side*(cell['exit_price']-cell['entry_price'])*1000-83.6-500,1),
                        'scene':scene,'phase':{'DAY':0,'PRE':1,'POST':2}[cell['band']],'origin':row['origins'][ci]}
                    if not cell['unknown']:fees+=1
                    for attr,values in ledger.items():checks+=V.V.check_equal(values[i],expected[attr] if attr in expected else cell[attr],(identity,scene,i,attr))
                    unavailable=route.end if cell['unknown'] else cell['exit_time']
                assert cursor==len(ids),(identity,scene,'余分取得');diagnostics[identity+'/'+scene]=dict(diag)
    return {'属性照合':checks,'既知費用式照合':fees,'診断':diagnostics}


# ----------------------------------------
def decomposition(packs: dict) -> list:
    """
    機能: 母体と各固定感度の共通/旧のみ/新のみ実取得を帯・期間別に分解する。
    引数: packs(dict)。
    返り値: list[dict]。未取得時刻の仮想利益を計算しない。
    """
    result=[]
    mothers=[f'NK225206_{m}' for m in NK_IDS]+[f'TOPIX206_I{m:02d}' for m in TP_IDS]
    for mother in mothers:
        old=P.trade_rows(packs[mother+'_BASE'])
        for variant in VARIANTS:
            identity=mother+'_'+variant;pack=packs[identity];new=P.trade_rows(pack)
            common=set(old)&set(new);removed=set(old)-common;added=set(new)-common
            for key in common:
                for attr in ('net','known','entry_price','exit_price','exit_time','label'):assert old[key][attr]==new[key][attr]
            scenes=[s['scene'] for s in pack['sessions']];summaries=[]
            for period,names in {'全83':scenes,'前48':scenes[:48],'後25':scenes[48:73],'追加7':scenes[73:80],'本日1':scenes[80:81],'追加2':scenes[81:]}.items():
                eligible=set(names)
                for band in ('ALL','DAY','NIGHT','PRE','POST'):
                    def includes(row: dict) -> bool:
                        """
                        機能: 元の取得帯・場で実取引を選ぶ。
                        引数: row(dict)。
                        返り値: bool。
                        """
                        return row['scene'] in eligible and (band=='ALL' or band=='NIGHT' and row['phase']!=0 or row['phase']=={'DAY':0,'PRE':1,'POST':2}.get(band))
                    a=P.financial_summary([old[k] for k in sorted(common) if includes(old[k])])
                    b=P.financial_summary([old[k] for k in sorted(removed) if includes(old[k])])
                    c=P.financial_summary([new[k] for k in sorted(added) if includes(new[k])])
                    before=P.financial_summary([r for r in old.values() if includes(r)]);after=P.financial_summary([r for r in new.values() if includes(r)])
                    assert before['取得']==a['取得']+b['取得'] and after['取得']==a['取得']+c['取得']
                    assert math.isclose(after['既知収支']-before['既知収支'],c['既知収支']-b['既知収支'],abs_tol=1e-7)
                    summaries.append({'期間':period,'帯':band,'共通':a,'旧のみ':b,'新のみ':c,'旧合計':before,'新合計':after})
            result.append({'候補':identity,'母体':mother+'_BASE','主条件か':variant=='BASE' or variant.startswith('D001_'),
                '集計':summaries,'旧のみ実取得':[old[k] for k in sorted(removed)],'新のみ実取得':[new[k] for k in sorted(added)]})
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: rootの金融完了連絡後に全85の母体・枠・費用・別算術を検査する。
    引数: なし。
    返り値: None。新候補や主遅延の選び直しは行わない。
    """
    pure=read(HERE/'純判定独立確認206_v2.json');assert pure['版2条件']==ref(TRIAL/'条件_v2.json')
    assert read(TARGET/'金融開始前固定.json')['条件']==pure['版2条件']
    states_path=TARGET/'全85口座安定性.json.gz';states=read(states_path)['metrics'];assert len(states)==85
    refs=[ref(states_path)];packs={}
    for state in states:
        p=TARGET/'金融正本'/(state['id']+'.json.gz');refs.append(ref(p));packs[state['id']]=read(p)
    bases=baseline(packs)
    count=sum(V.inspect_groups(packs[s['id']],s) for s in states)
    nk=nk_slots(packs);tx=topix_slots(packs)
    save(HERE/'元新の実取得差分206.json.gz',{'全83既使用':True,'実現取引だけ':True,'主d1と感度d5_30_60は交換しない':True,'比較':decomposition(packs)})
    assert all(ref(ROOT/r['path'])==r for r in refs)
    proof={'試行':206,'成功':True,'候補':85,'主遅延秒':1,'別遅延は時計感度':True,'五BASE同体':bases,'別算術照合属性':count,
        'NK枠':nk,'TOPIX枠':tx,'金融正本':refs,'純確認':ref(HERE/'純判定独立確認206_v2.json'),
        '実取引差分':ref(HERE/'元新の実取得差分206.json.gz'),
        'Source':[ref(Path(__file__)),ref(Path(P.__file__)),ref(Path(V.__file__)),ref(Path(V.V.__file__))],
        '限界':'IFD価格セルは固定のNK共用表とTOPIX Routeを共用。今回原BBOの別走査はしていない。別実装は枠選択/後続要求/費用/集計。',
        '新条件探索なし':True}
    save(HERE/'金融独立確認206.json.gz',proof)
    print(json.dumps({'成功':True,'候補':85,'別算術照合':count,'NK枠属性':nk['属性照合'],'TOPIX枠属性':tx['属性照合']},ensure_ascii=False),flush=True)


# ----------------------------------------
if __name__=='__main__':main()
