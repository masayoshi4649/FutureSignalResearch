"""206主d1の実取得差を、元q0の純棄却と成立保持後の口座経路差へ分ける。"""
from collections import Counter,defaultdict
from pathlib import Path
import gzip
import hashlib
import json
import math
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
TARGET=ROOT/'work/206指数間の入口比較'
MAIN=('BASE','D001_AVAIL','D001_PEER','D001_VETO','D001_RELATIVE')


# ----------------------------------------
def read(path: Path) -> object:
    """
    機能: 固定JSONを読む。
    引数: path(Path)。
    返り値: object。
    """
    body=path.read_bytes();return json.loads(gzip.decompress(body) if path.suffix=='.gz' else body)


# ----------------------------------------
def ref(path: Path) -> dict:
    """
    機能: 読取対象の内容指紋を得る。
    引数: path(Path)。
    返り値: dict。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


# ----------------------------------------
def trades(pack: dict) -> dict:
    """
    機能: 実取得を指定された4キーで索引化する。
    引数: pack(dict)。
    返り値: dict[(場,取得原行,実側,幅),dict]。同一キーの重複は拒否する。
    """
    ledger=pack['ledger'];result={};nk=pack['id'].startswith('NK')
    for i in range(len(ledger['known'])):
        row={k:v[i] for k,v in ledger.items()};side=(1 if row['side']==0 else -1) if nk else row['side']
        key=(row['scene'],row['entry_line'],side,row['width']);assert key not in result
        result[key]=row
    return result


# ----------------------------------------
def summary(rows: list[dict]) -> dict:
    """
    機能: 実現した旧取引の利益・損失と未知を集計する。
    引数: rows(list[dict])。
    返り値: dict。未取得の仮想損益や機会損失を作らない。
    """
    values=[r['net'] for r in rows if r['known']];unknown=sum(not r['known'] for r in rows)
    return {'取得':len(rows),'未知':unknown,'利益':sum(max(0,v) for v in values),'損失':sum(max(0,-v) for v in values),
        '既知収支':sum(values),'確定収支':sum(values) if unknown==0 else None,'赤字取得':sum(v<0 for v in values)}


# ----------------------------------------
def main() -> None:
    """
    機能: 主d1全25を母体へ比較し、旧のみの純棄却/口座経路差を分類する。
    引数: なし。
    返り値: None。成績から新候補や閾値を選ばない。
    """
    audit=read(HERE/'金融独立確認206.json.gz');assert audit['成功'] and audit['候補']==85
    plan=read(ROOT/'inputs/00201_両指数の板数量純特徴/抽出前固定.json.gz')
    member={'旧73':'181旧73','追加7':'181追加7','本日1':'181本日1','追加2':'194追加2'}
    metadata={leg:[dict(q,session=scene['session']) for scene in plan['scenes'] if scene['symbol']=='NK225' for q in scene['q0'] if name in q['members']] for leg,name in member.items()}
    nk={}
    for leg in member:
        with np.load(TARGET/'純入口'/(leg+'.npz'),allow_pickle=False) as z:nk[leg]={k:z[k].copy() for k in z.files}
        assert len(metadata[leg])==len(nk[leg]['E199_00_BASE__birth__core'])
    tx={(r['session'],r['line']):r for r in read(TARGET/'純入口/TOPIX.json.gz')}
    mothers=[('NK225',m,f'NK225206_{m}') for m in ('E199_00','E199_02','E199_05')]+[('TOPIX',m,f'TOPIX206_I{m:02d}') for m in (0,10)]
    results=[];refs=[];raw_core_conflicts=[]
    for symbol,mother,prefix in mothers:
        source=TARGET/'金融正本'/(prefix+'_BASE.json.gz');base_pack=read(source);refs.append(ref(source));old=trades(base_pack)
        scenes=[s['scene'] for s in base_pack['sessions']]
        for vi,variant in enumerate(MAIN):
            path=TARGET/'金融正本'/(prefix+'_'+variant+'.json.gz');pack=read(path);refs.append(ref(path));new=trades(pack)
            common=set(old)&set(new);removed=set(old)-common;added=set(new)-common
            for key in common:
                # 4キー一致が期限・取得時刻の違いを隠さないことも検査する。
                assert old[key]['entry_time']==new[key]['entry_time']
                assert old[key].get('horizon','H60')==new[key].get('horizon','H60')
                for attr in ('known','net','entry_price','exit_price','exit_time','label'):assert old[key][attr]==new[key][attr]
            classified=[]
            for key in sorted(removed):
                row=old[key];side=key[2]
                if symbol=='NK225':
                    leg=row['leg'];event=row['event'];q=metadata[leg][event];arrays=nk[leg];identity=mother+'_'+variant
                    assert q['session']==row['scene'] and q['line']<=row['entry_line'] and q['time']<=row['entry_time']
                    attr='core' if row['origin']==0 else 'technical';assert row['origin'] in (0,2)
                    baseline=int(arrays[mother+'_BASE__birth__'+attr][event]);assert baseline==side
                    signal=int(arrays[identity+'__birth__'+attr][event]);assert signal in (0,side)
                    if row['origin']==2 and int(arrays[mother+'_BASE__birth__core'][event])!=0:
                        raw_core_conflicts.append({'候補':pack['id'],'場':row['scene'],'event':event,'core':int(arrays[mother+'_BASE__birth__core'][event]),'実T側':side})
                    cause='純条件で棄却' if signal==0 else '純成立保持後の口座経路差（予約/保有・初参加T・同case別名）'
                    qline=q['line'];qtime=q['time']
                else:
                    qline=row['request_line'];qtime=row['request_time'];q=tx[(row['scene'],qline)];assert q['time']==qtime
                    index=(0 if mother==0 else 1)*17+vi
                    signal=q['signals'][index];assert signal in (0,side)
                    cause='純条件で棄却' if signal==0 else '純成立保持後の予約/保有枠差'
                classified.append(dict(row,原因区分=cause,元q0原行=qline,元q0時計=qtime,新純条件で実側保持=signal==side))
            summaries=[]
            periods={'全83':scenes,'前48':scenes[:48],'後25':scenes[48:73],'追加7':scenes[73:80],'本日1':scenes[80:81],'追加2':scenes[81:]}
            for period,names in periods.items():
                eligible=set(names)
                for band in ('ALL','DAY','NIGHT','PRE','POST'):
                    def includes(row: dict) -> bool:
                        """
                        機能: 実取得の場・帯を保って対象を選ぶ。
                        引数: row(dict)。
                        返り値: bool。
                        """
                        return row['scene'] in eligible and (band=='ALL' or band=='NIGHT' and row['phase']!=0 or row['phase']=={'DAY':0,'PRE':1,'POST':2}.get(band))
                    causes=defaultdict(list)
                    for row in classified:
                        if includes(row):causes[row['原因区分']].append(row)
                    a=summary([old[k] for k in sorted(common) if includes(old[k])]);b=summary([old[k] for k in sorted(removed) if includes(old[k])]);c=summary([new[k] for k in sorted(added) if includes(new[k])])
                    before=summary([r for r in old.values() if includes(r)]);after=summary([r for r in new.values() if includes(r)])
                    assert before['取得']==a['取得']+b['取得'] and after['取得']==a['取得']+c['取得']
                    assert math.isclose(after['既知収支']-before['既知収支'],c['既知収支']-b['既知収支'],abs_tol=1e-7)
                    assert sum(len(v) for v in causes.values())==b['取得']
                    summaries.append({'期間':period,'帯':band,'共通':a,'旧のみ':b,'新のみ':c,'旧のみ原因別':{k:summary(v) for k,v in causes.items()},'旧合計':before,'新合計':after})
            results.append({'候補':pack['id'],'母体':base_pack['id'],'集計':summaries,'旧のみ原因':classified,'新のみ実取得':[new[k] for k in sorted(added)]})
    assert len(results)==25 and all(ref(ROOT/r['path'])==r for r in refs)
    proof={'試行':206,'成功':True,'主d1全25だけ':True,'キー':['scene','entry_line','actual_side','width'],
        '共通4キーの取得時計と期限も一致':True,'金融監査':ref(HERE/'金融独立確認206.json.gz'),'Source':ref(Path(__file__)),
        '解釈':'旧のみは旧口座で実現した取引。機会損失や未取得時刻の仮想利益ではない。NKの純成立保持は予約/保有だけと断定せず初参加T・同case別名を含む口座経路差。',
        '生coreと実T側の診断':raw_core_conflicts,'比較':results}
    target=HERE/'主d1の実取得差と純棄却206.json.gz';body=gzip.compress((json.dumps(proof,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode(),mtime=0)
    if target.exists():assert target.read_bytes()==body
    else:target.write_bytes(body)
    print(json.dumps({'成功':True,'候補':25,'生coreと実T側の診断件数':len(raw_core_conflicts),'旧のみ件数':sum(len(r['旧のみ原因']) for r in results)},ensure_ascii=False),flush=True)


# ----------------------------------------
if __name__=='__main__':main()
