"""206金融独立確認と実取引差分のSource・正本を恒久保存する。"""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
TRIAL=ROOT/'study/00206_指数間の相対変化を複合入口へ加える'


# ----------------------------------------
def ref(path: Path) -> dict:
    """
    機能: 資源の内容指紋を得る。
    引数: path(Path)。
    返り値: dictは相対path/bytes/SHA。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


# ----------------------------------------
def main() -> None:
    """
    機能: 6 Sourceと金融独立票・実現差分3本を保存し、別展開の同体を確認する。
    引数: なし。
    返り値: None。主金融と純条件は変更しない。
    """
    proof=json.loads(gzip.decompress((HERE/'金融独立確認206.json.gz').read_bytes()));assert proof['成功']
    paths=[]
    for r in proof['Source']:
        p=ROOT/r['path'];assert ref(p)==r;paths.append(p)
    paths.extend((HERE/'主条件の実取得差を分類する.py',Path(__file__)))
    target=TRIAL/'金融独立Source.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(paths):
            info=zipfile.ZipInfo(p.relative_to(ROOT).as_posix(),(2026,11,18,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,p.read_bytes())
    index={'試行':206,'archive':ref(target),'members':[ref(p) for p in sorted(paths)],
        '既存IFDセルと生産Sourceの依存':'201/206の主金融Sourceと恒久入力を復元して利用。原板や金融行列を重複収録しない。',
        '独立範囲':'一件枠・取得選択・費用式・集計・実現差分。原BBO再走査ではない。',
        'dependencies':{'Python':'3.14.3','numpy':'2.5.4','orjson':'3.13.0','tzdata':'2026.6'}}
    (TRIAL/'金融独立Source索引.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    audit=TRIAL/'監査';audit.mkdir(exist_ok=True)
    outputs=[]
    for name in ('金融独立確認206.json.gz','元新の実取得差分206.json.gz','主d1の実取得差と純棄却206.json.gz'):
        dest=audit/name
        if dest.exists():assert dest.read_bytes()==(HERE/name).read_bytes()
        else:shutil.copy2(HERE/name,dest)
        outputs.append(ref(dest))
    folder=ROOT/'work/206金融独立Source展開';assert not folder.exists();folder.mkdir(parents=True)
    with zipfile.ZipFile(target) as z:
        for r in index['members']:
            body=z.read(r['path']);dest=folder/r['path'];dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(body)
            assert hashlib.sha256(body).hexdigest()==r['sha256'];compile(body,str(dest),'exec')
    check={'試行':206,'成功':True,'ZIP':ref(target),'全memberSHAとPython構文一致':len(paths),'正式保存票':outputs,
        '主金融と条件に変更なし':True}
    (TRIAL/'金融独立Source展開確認.json').write_text(json.dumps(check,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(check,ensure_ascii=False),flush=True)


# ----------------------------------------
if __name__=='__main__':main()
