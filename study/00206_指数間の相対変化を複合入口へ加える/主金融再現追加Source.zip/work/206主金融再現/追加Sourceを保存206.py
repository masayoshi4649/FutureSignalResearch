"""206主金融の別root再現を、既存金融Sourceと分離した追加ZIPへ保存する。"""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
TRIAL=ROOT/'study/00206_指数間の相対変化を複合入口へ加える'


# ----------------------------------------
def ref(path: Path) -> dict:
    """
    機能: 正式資源の内容指紋を得る。
    引数: path(Path)。
    返り値: dictはpath/bytes/SHA。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


# ----------------------------------------
def main() -> None:
    """
    機能: 固定版2の主金融再現Source・依存参照・確認票を正式保存する。
    引数: なし。
    返り値: None。元の金融Source・条件を変更しない。
    """
    helper=HERE/'repo_0/work/206主金融再現';proof=json.loads((helper/'主金融復元確認206.json').read_text(encoding='utf-8'))
    assert proof['成功'] and len(proof['全85金融byte同体'])==85 and len(proof['全統計byte同体'])==3 and not proof['元workへの参照']
    prepared=json.loads((helper/'復元準備206.json').read_text(encoding='utf-8'))
    assert ref(TRIAL/'金融Source.zip')==prepared['206金融Source']
    paths=[HERE/name for name in ('復元206.py','実行を確認206.py','追加Sourceを保存206.py')]
    target=TRIAL/'主金融再現追加Source.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(paths):
            info=zipfile.ZipInfo(p.relative_to(ROOT).as_posix(),(2026,11,18,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,p.read_bytes())
    index={'試行':206,'archive':ref(target),'members':[ref(p) for p in paths],
        '恒久依存':[prepared['201追加Source'],prepared['206金融Source']],
        '201復元の依存':'201追加ZIP内の復元参照表が既存ZIP11本と正式資源154件を固定。',
        '条件':prepared['条件'],'純封印':prepared['純封印'],'入力前後確認数':len(prepared['入力前後SHA対象']),
        '原板と生成入力とライブラリの重複収録なし':True,'金融Sourceは変更なし':True}
    (TRIAL/'主金融再現追加Source索引.json').write_text(json.dumps(index,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    audit=TRIAL/'監査';audit.mkdir(exist_ok=True)
    for source,name in ((helper/'主金融復元確認206.json','主金融復元確認206.json'),(helper/'復元準備206.json','主金融復元準備206.json')):
        dest=audit/name
        if dest.exists():assert dest.read_bytes()==source.read_bytes()
        else:shutil.copy2(source,dest)
    dest=HERE/'追加Source展開';assert not dest.exists();dest.mkdir()
    with zipfile.ZipFile(target) as z:
        for row in index['members']:
            body=z.read(row['path']);p=dest/row['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(body)
            assert hashlib.sha256(body).hexdigest()==row['sha256'];compile(body,str(p),'exec')
    check={'成功':True,'ZIP':ref(target),'全memberSHAと構文一致':3,'主金融全85byte同体':True,'全集計3byte同体':True,
        '元work参照':0,'原入力書込':0,'原入力前後SHA同体':len(prepared['入力前後SHA対象']),
        '確認票':ref(audit/'主金融復元確認206.json')}
    (TRIAL/'主金融再現Source展開確認.json').write_text(json.dumps(check,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(check,ensure_ascii=False),flush=True)


# ----------------------------------------
if __name__=='__main__':main()
