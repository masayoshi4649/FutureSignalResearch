"""201の恒久復元へ206版2の固定資源を足し、別rootの再実行先を作る。"""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
TRIAL=ROOT/'study/00206_指数間の相対変化を複合入口へ加える'
PREVIOUS=ROOT/'study/00201_板数量の更新尺度を複合入口へ加える/主金融再現追加Source.zip'


# ----------------------------------------
def ref(path: Path) -> dict:
    """
    機能: 正式保存の内容指紋を得る。
    引数: path(Path)。
    返り値: dictはpath/bytes/SHA。
    """
    with path.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':sha}


# ----------------------------------------
def extract(archive: Path,target: Path) -> list:
    """
    機能: 元相対構造でZIPを展開し、既存ファイルは内容同体だけを許す。
    引数: archive/target(Path)。
    返り値: list[dict]は各memberの指紋。元入力を上書きしない。
    """
    result=[]
    with zipfile.ZipFile(archive) as z:
        for item in z.infolist():
            assert not item.is_dir();p=(target/item.filename).resolve();assert p.is_relative_to(target.resolve())
            body=z.read(item.filename);p.parent.mkdir(parents=True,exist_ok=True)
            if p.exists():assert p.read_bytes()==body,p
            else:p.write_bytes(body)
            result.append({'path':item.filename,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()})
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: 恒久201追加ZIP・206金融ZIPから復元し、入力の前後照合表を作る。
    引数: 第1引数は新しい展開先(str)。省略時はrepo_0。
    返り値: None。原板を複製せず、入力は201復元器のfile hardlinkを使う。
    """
    target=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else HERE/'repo_0'
    assert not target.exists()
    assert ref(PREVIOUS)['sha256']=='92de3e39ec7920b4c0fcf6d0319a715b3f51a4c4f8d99092c88e51c80fa3e11b'
    bootstrap=extract(PREVIOUS,ROOT)
    helper=ROOT/'work/201主金融再現/復元する.py'
    subprocess.run([sys.executable,'-X','utf8',str(helper),str(target)],check=True)
    financial=TRIAL/'金融Source.zip';members=extract(financial,target)
    copies=[]
    for name in ('条件.json','条件_v2.json','純封印.json','純封印_v2.json','金融前カタログ.json'):
        source=TRIAL/name;dest=target/source.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(source.read_bytes());copies.append(ref(source))
    for name in ('純封印.json','純封印_v2.json'):
        source=TRIAL/name;dest=target/'work/206指数間の入口比較'/name
        if dest.exists():assert dest.read_bytes()==source.read_bytes()
        else:dest.write_bytes(source.read_bytes())
    assert not(target/'work/206指数間の入口比較/金融開始前固定.json').exists()
    prior=json.loads((ROOT/'work/201主金融再現/復元参照表.json').read_text(encoding='utf-8'))
    refs={r['path']:r for r in prior['input_refs']}
    condition=json.loads((TRIAL/'条件_v2.json').read_text(encoding='utf-8'))
    for r in condition['Sourceと参照']:
        if r['path'].startswith('inputs/'):
            if r['path'] in refs:assert refs[r['path']]==r
            refs[r['path']]=r
    current=target/'work/206主金融再現';current.mkdir(parents=True,exist_ok=True)
    shutil.copy2(HERE/'実行を確認206.py',current/'実行を確認206.py')
    proof={'試行':206,'成功':True,'展開先':str(target),'201追加Source':ref(PREVIOUS),'201正式からのbootstrap':bootstrap,
        '206金融Source':ref(financial),'206member':members,'正式コピー':copies,'入力前後SHA対象':list(refs.values()),
        '条件':ref(TRIAL/'条件_v2.json'),'純封印':ref(TRIAL/'純封印_v2.json'),'原板複製なし':True,
        '入力はhardlinkかつ実行時書込拒否':True,'バイナリ版':'Python3.14.3/NumPy2.5.4/orjson3.13.0/tzdata2026.6'}
    (current/'復元準備206.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'展開先':str(target),'206資源':len(members),'入力SHA':len(refs)},ensure_ascii=False),flush=True)


# ----------------------------------------
if __name__=='__main__':main()
