"""正式保存からの別rootで206版2の主金融を再実行し、全85正本へ同体照合する。"""
from pathlib import Path
import importlib.util
import json
import sys
import traceback

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
ORIGINAL=Path(sys.argv[1]).resolve()
TRIAL=Path('study/00206_指数間の相対変化を複合入口へ加える')
spec=importlib.util.spec_from_file_location('audit201_restored_for206',ROOT/'work/201主金融再現/復元先を実行する.py')
W=importlib.util.module_from_spec(spec);sys.modules[spec.name]=W;spec.loader.exec_module(W)


# ----------------------------------------
def main() -> None:
    """
    機能: 固定版2の全85金融を再生し、原入力保護・元work不使用・byte同体を確認する。
    引数: 第1引数は元リポジトリの絶対path(str)。
    返り値: None。独立金融算術の検査は別Sourceの範囲。
    """
    prepared=json.loads((HERE/'復元準備206.json').read_text(encoding='utf-8'))
    for r in prepared['入力前後SHA対象']:assert W.ref(ORIGINAL/r['path'])['sha256']==r['sha256']
    sys.addaudithook(W.watch)
    sys.path.insert(0,str(ROOT/'work/206指数間の入口比較'))
    success=False;error=None;matches=[];statistics=[]
    try:
        import 実行206_v2 as M
        M.finance()
        output=ROOT/'work/206指数間の入口比較'
        for p in sorted((output/'金融正本').glob('*.json.gz')):
            assert p.read_bytes()==(ORIGINAL/TRIAL/'金融正本'/p.name).read_bytes(),p.name
            matches.append(W.ref(p))
        assert len(matches)==85
        for name in ('全85口座安定性.json.gz','全85口座短表.json.gz','旧五母体同体.json'):
            assert (output/name).read_bytes()==(ORIGINAL/TRIAL/name).read_bytes(),name
            statistics.append(W.ref(output/name))
        success=True
    except Exception:error=traceback.format_exc()
    imports=[]
    for name,module in list(sys.modules.items()):
        filename=getattr(module,'__file__',None)
        if filename:
            p=Path(filename).resolve()
            if p.suffix in ('.py','.pyd') and (p.is_relative_to(ROOT) or p.is_relative_to(ORIGINAL)) and 'site-packages' not in p.parts:
                imports.append({'module':name,'path':str(p),'展開先':p.is_relative_to(ROOT)})
    assert all(r['展開先'] for r in imports),[r for r in imports if not r['展開先']]
    for r in prepared['入力前後SHA対象']:assert W.ref(ORIGINAL/r['path'])['sha256']==r['sha256']
    original_work=[{'path':p,'stack':trace} for p,trace in sorted(W.EXTERNAL.items())]
    assert not original_work,original_work
    proof={'試行':206,'成功':success,'固定Sourceと純封印変更なし':True,'主実装の再現であり独立算術とは別':True,
        '全85金融byte同体':matches,'全統計byte同体':statistics,'展開先':str(ROOT),'元workへの参照':original_work,
        '読込module':imports,'恒久入力の前後SHA不変件数':len(prepared['入力前後SHA対象']),'恒久入力への書込みなし':True,
        '書込先':[str(p) for p in sorted(W.WRITTEN)],'実参照':[str(p) for p in sorted(W.OPENED)],'error':error,
        'Source':[W.ref(Path(__file__)),W.ref(ROOT/'work/201主金融再現/復元先を実行する.py')],
        '条件':prepared['条件'],'純封印':prepared['純封印']}
    (HERE/'主金融復元確認206.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':success,'金融byte同体':len(matches),'統計byte同体':len(statistics),'module':len(imports),'元work参照':len(original_work),'error':error},ensure_ascii=False),flush=True)
    assert success,error


# ----------------------------------------
if __name__=='__main__':main()
