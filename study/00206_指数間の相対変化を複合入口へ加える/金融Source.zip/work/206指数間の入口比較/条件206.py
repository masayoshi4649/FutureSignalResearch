"""既存複合入口へ、同じ過去端点で測る相手指数の背景を追加する。"""
import itertools
import numpy as np

DELAYS=(1,5,30,60)
MODES=('AVAIL','PEER','VETO','RELATIVE')


def variants() -> list:
    """
    機能: 主1秒と三つの時計感度を金融前に定義する。
    引数: なし。
    返り値: list[dict]はBASEと16感度。高成績の遅延へ主条件を交換しない。
    """
    return [{'key':'BASE','delay':None,'mode':'BASE'}]+[
        {'key':f'D{d:03d}_{mode}','delay':d,'mode':mode} for d in DELAYS for mode in MODES]


# ----------------------------------------
def catalog() -> dict:
    """
    機能: 五母体×17条件の85口座と相対変化の解釈を固定する。
    引数: なし。
    返り値: dictは金融前カタログ。
    """
    return {'試行':206,'規模':85,'母体':{'NK225':['E199_00','E199_02','E199_05'],'TOPIX':['I00','I10']},
        '感度':variants(),'主遅延秒':1,'追加停滞上限秒':60,
        'Q':'同一dの自己/相手1/5/15/30分の全8returnが端点既知・内部300秒超gapなし。分母の場・q0を削除しない。',
        'AVAIL':'Qのみ。参照可用性による取得の変化を分ける対照。',
        'PEER':'Qかつ相手指数の15/30分returnがどちらも元入口の実側へ正。',
        'VETO':'Qかつ相手指数の1/5/15/30分returnが全て実側へ負なら現在要求を棄却。Q未知なら親要求保持。',
        'RELATIVE':'Qかつ相手15分は実側へ正、自己15分は相手15分より実側へ弱い、自己1分は実側へ正。相対的な遅れから回復する仮説。',
        '未知':'BASEは元同体。AVAIL/PEER/RELATIVEのQ未知は不成立、VETOは元判断保持＋未知旗。未知をゼロreturnとしない。',
        '限界':'価格時計の公表遅延モデルであり、実際の受信先行性を測らない。logreturn差の係数1は裁定/適正価格/安定した市場betaの証明ではない。',
        '技術':'元の方向・価格構造・勢い・量の複合入口へ追加する。相手指数だけで新規・反転を作らず、同q0の別名Tへ迂回させない。',
        '金融':'元幅/期限/費用・単純IFD・保有予約1・終了15分前を維持。全83既使用、前48/全80/後25/追加7/最終1/追加2を保持。',
        '評価':'損失頻度・深さ・連続性・期間差と参加/両中央値を評価し、純利益上位や最良遅延だけで採用しない。'}


# ----------------------------------------
def decide(returns: np.ndarray, quality: np.ndarray, side: int, variant: dict) -> tuple:
    """
    機能: 同じ過去端点の自己/相手returnで元要求の許否を判断する。
    引数: returns/quality(np.ndarray)は(遅延4,窓4,商品2)、side(int)は±1、variant(dict)。
    返り値: tuple[bool,bool]は許可・必要値未知。
    """
    assert side in (-1,1)
    mode=variant['mode']
    if mode=='BASE':return True,False
    di=DELAYS.index(variant['delay']);r=returns[di]
    q=bool(np.all(quality[di]))
    if not q:return mode=='VETO',True
    assert np.isfinite(r).all()
    if mode=='AVAIL':return True,False
    if mode=='PEER':return bool(side*r[2,1]>0 and side*r[3,1]>0),False
    if mode=='VETO':return not bool(np.all(side*r[:,1]<0)),False
    assert mode=='RELATIVE'
    return bool(side*r[2,1]>0 and side*(r[2,0]-r[2,1])<0 and side*r[0,0]>0),False


# ----------------------------------------
def filter_bundle(bundle: dict, rows: list, variant: dict) -> tuple:
    """
    機能: NK固定出生をコピーし、core優先・同q0迂回禁止で相手指数条件を重ねる。
    引数: bundle(dict)、rows(list[tuple[np.ndarray,np.ndarray]])、variant(dict)。
    返り値: tuple[dict,dict]は新出生と純件数診断。元配列・幅期限は変更しない。
    """
    out={k:v.copy() for k,v in bundle.items() if k!='birth'};out['birth']={k:v.copy() for k,v in bundle['birth'].items()}
    assert len(rows)==len(out['birth']['core']);counts={'proposed':0,'unknown':0,'rejected':0}
    for i,(r,q) in enumerate(rows):
        side=int(out['birth']['core'][i]) or int(out['birth']['technical'][i])
        if not side:continue
        allow,unknown=decide(r,q,side,variant);counts['proposed']+=1;counts['unknown']+=int(unknown)
        if not allow:
            counts['rejected']+=1
            for key,value in (('core',0),('branches',-1),('technical',0),('tier',0)):out['birth'][key][i]=value
    return out,counts


# ----------------------------------------
def artificial() -> dict:
    """
    機能: 符号鏡像・未知保持・閾値0・遅延軸の独立を人工確認する。
    引数: なし。
    返り値: dictは金融未参照の確認票。
    """
    checks=0
    for values in itertools.product((-.01,0,.01),repeat=4):
        r=np.ones((4,4,2))*.001;r[:,:,1]=np.array(values);q=np.ones(r.shape,bool)
        for v in variants():
            assert decide(r,q,1,v)==decide(-r,q,-1,v);checks+=1
            if v['mode']!='BASE':
                bad=q.copy();bad[DELAYS.index(v['delay']),0,0]=False
                assert decide(r,bad,1,v)==(v['mode']=='VETO',True);checks+=1
    z=np.zeros((4,4,2));q=np.ones(z.shape,bool)
    for v in variants():
        expect=v['mode'] in ('BASE','AVAIL','VETO');assert decide(z,q,1,v)==(expect,False);checks+=1
    return {'成功':True,'確認項目':checks,'金融未参照':True}
