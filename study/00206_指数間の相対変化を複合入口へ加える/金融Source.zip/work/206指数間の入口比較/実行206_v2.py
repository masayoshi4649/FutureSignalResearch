"""全85の指数間確認。版2は金融前に動的到達木を明示封印する。"""
from pathlib import Path
from collections import defaultdict
import argparse
import json
import sys
import numpy as np
import 条件206 as B

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00206_指数間の相対変化を複合入口へ加える'
INPUT=ROOT/'inputs/00206_両指数の固定端点相対変化'
sys.path.insert(0,str(ROOT/'work/201板数量比較'))
import 実行201 as E
sys.path.insert(0,str(ROOT/'scripts/TOPIX入口研究'))
import 共通金融 as G


def index() -> tuple:
    """
    機能: 166純資源を原行キーへ結び、全q0のreturnと品質を保持する。
    引数: なし。
    返り値: tuple[dict,list[Path]]は市場別索引・資源。金融列を読まない。
    """
    manifest=E.read(INPUT/'完了.json');result={s:{} for s in ('NK225','TOPIX')};paths=[]
    for item in manifest['files']:
        path=Path(item['file']['path']);path=path if path.is_absolute() else ROOT/path
        assert E.ref(path)['sha256']==item['file']['sha256'];paths.append(path)
        with np.load(path,allow_pickle=False) as a:
            r=a['log_return'].copy();q=a['quality_known'].copy();times=a['q0_time'];lines=a['q0_line']
            assert r.shape==q.shape==(len(lines),4,4,2)
            for i,line in enumerate(lines):
                key=(item['session'],int(line));assert key not in result[item['symbol']]
                result[item['symbol']][key]=(float(times[i]),r[i],q[i])
    assert len(paths)==166 and [len(result[s]) for s in ('NK225','TOPIX')]==[40314,35361]
    return result,paths


# ----------------------------------------
def pure() -> None:
    """
    機能: 全85の出生を全83場で先に生成し、Sourceと入力を金融前固定する。
    引数: なし。
    返り値: None。
    """
    boards,paths=index();refs=[];diagnosis={};variants=B.variants()
    for leg in (*E.C.LEGS,'追加2'):
        p=E.N.load_pure_leg() if leg=='追加2' else E.C.load_pure_leg(leg)
        if leg!='追加2':E.C.seal_pure_leg(p)
        p['features'].q0_prices=E.N.load_q0(p) if leg=='追加2' else E.Q.load_q0(p)
        built=E.R.build(p['features'],p['baselines']['全期_J035'],candidate_ids=list(E.NK_IDS));rows=[]
        for meta in p['features'].q0_meta:
            time,r,q=boards['NK225'][(meta['session'],meta['q0_line'])];assert time==meta['q0_time'];rows.append((r,q))
        payload={};diag={}
        for identity,bundle in built['bundles'].items():
            for v in variants:
                key=identity+'_'+v['key'];out,info=B.filter_bundle(bundle,rows,v);diag[key]=info
                for k in E.C.PARAM_KEYS:payload[key+'__'+k]=out[k]
                for k in E.C.BIRTH_KEYS:payload[key+'__birth__'+k]=out['birth'][k]
        target=HERE/'純入口'/(leg+'.npz');target.parent.mkdir(parents=True,exist_ok=True)
        if target.exists():
            with np.load(target,allow_pickle=False) as old:
                assert set(old.files)==set(payload)
                for k in payload:np.testing.assert_array_equal(old[k],payload[k])
        else:np.savez_compressed(target,**payload)
        refs.append(E.ref(target));diagnosis[leg]=diag
        print(json.dumps({'純出生':leg,'候補':51},ensure_ascii=False),flush=True)
    rows=[];diag=defaultdict(lambda:defaultdict(int))
    for parent in E.parent_topix():
        time,r,q=boards['TOPIX'][(parent['session'],parent['line'])];assert time==parent['time']
        new={k:parent[k] for k in ('session','line','time','band')};signals=[];widths=[];origins=[]
        for mother in E.TP_IDS:
            for v in variants:
                side=parent['signals'][mother];key=f'I{mother:02d}_'+v['key']
                allow,unknown=B.decide(r,q,side,v) if side else (True,False)
                diag[key]['proposed']+=int(side!=0);diag[key]['unknown']+=int(unknown);diag[key]['rejected']+=int(not allow)
                signals.append(side if allow else 0);widths.append(parent['widths'][mother]);origins.append(parent['origins'][mother])
        new.update(signals=signals,widths=widths,origins=origins);rows.append(new)
    target=HERE/'純入口/TOPIX.json.gz';E.save(target,rows);refs.append(E.ref(target));diagnosis['TOPIX']=dict(diag)
    E.save(HERE/'純成立診断.json',diagnosis)
    sources={ROOT/r['path'] for r in E.read(E.TRIAL/'条件.json')['Sourceと参照']}
    sources.update(paths);sources.update((Path(__file__),Path(B.__file__),Path(G.__file__),INPUT/'完了.json',INPUT/'抽出前固定.json.gz',
        ROOT/'scripts/入口分析/分析.py',TRIAL/'条件.json',HERE/'純封印.json'))
    condition={'カタログ':B.catalog(),'人工':B.artificial(),'Sourceと参照':[E.ref(p) for p in sorted(sources)],'純出生':refs,'全85金融前':True}
    E.save(TRIAL/'条件_v2.json',condition);E.save(HERE/'純封印_v2.json',{'成功':True,'条件':E.ref(TRIAL/'条件_v2.json'),'金融前':True})


# ----------------------------------------
def finance() -> None:
    """
    機能: 事前固定された全85口座を元IFD・一枠で全83場再生する。
    引数: なし。
    返り値: None。Sourceと純出生は変更しない。
    """
    condition=E.read(TRIAL/'条件_v2.json');assert E.read(HERE/'純封印_v2.json')['条件']==E.ref(TRIAL/'条件_v2.json')
    assert all(E.ref(ROOT/r['path'])==r for r in condition['Sourceと参照']+condition['純出生'])
    marker=HERE/'金融開始前固定.json';assert not marker.exists();E.save(marker,{'条件':E.ref(TRIAL/'条件_v2.json')})
    variants=B.variants();parts=defaultdict(list)
    for leg in (*E.C.LEGS,'追加2'):
        p=E.N.load_pure_leg() if leg=='追加2' else E.C.load_pure_leg(leg)
        if leg!='追加2':E.C.seal_pure_leg(p)
        context=E.NF.attach_financial(E.NF.load_unvalued_context(p)['context'])['context'] if leg=='追加2' else E.C.attach_financial(p)['context']
        with np.load(HERE/'純入口'/(leg+'.npz'),allow_pickle=False) as a:
            for mother in E.NK_IDS:
                for v in variants:
                    key=mother+'_'+v['key'];identity='NK225206_'+key
                    bundle={k:a[key+'__'+k].copy() for k in E.C.PARAM_KEYS}
                    bundle['birth']={k:a[key+'__birth__'+k].copy() for k in E.C.BIRTH_KEYS}
                    parts[identity].append(E.A.pack(context,bundle,{'id':identity,'entry':mother,'relative':v},leg))
        print(json.dumps({'金融':leg,'候補':51},ensure_ascii=False),flush=True)
    packs=[E.A.combine(p) for p in parts.values()]
    ids=[f'TOPIX206_I{mother:02d}_'+v['key'] for mother in E.TP_IDS for v in variants]
    packs+=G.replay(E.read(HERE/'純入口/TOPIX.json.gz'),ids,G.entries(True));stats=[];short=[];checks=[]
    for pack in packs:
        E.check_scenes(pack['sessions'])
        if pack['id'].endswith('_BASE'):
            expected=E.read(ROOT/'study/00201_板数量の更新尺度を複合入口へ加える/金融正本'/(pack['id'].replace('206','201',1)+'.json.gz'))
            for key in ('ledger','sessions','positions'):assert pack[key]==expected[key],(pack['id'],key)
            checks.append(pack['id'])
        state=E.S.evaluate_pack(pack,G.periods(pack));stats.append(state)
        E.save(HERE/'金融正本'/(pack['id']+'.json.gz'),pack)
        short.append({'id':pack['id'],'全83':{b:E.F.terse(g) for b,g in state['groups'].items()},
            '期間':{p:{b:E.F.terse(g) for b,g in bands.items()} for p,bands in state['periods'].items()}})
    assert len(packs)==85 and len(checks)==5
    E.save(HERE/'全85口座安定性.json.gz',{'metrics':stats});E.save(HERE/'全85口座短表.json.gz',short)
    E.save(HERE/'旧五母体同体.json',{'成功':True,'候補':checks})
    assert all(E.ref(ROOT/r['path'])==r for r in condition['Sourceと参照']+condition['純出生'])
    print(json.dumps({'完了':85,'主d1固定':True,'全83既使用':True},ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':
    parser=argparse.ArgumentParser();p=parser.add_mutually_exclusive_group(required=True)
    p.add_argument('--pure',action='store_true');p.add_argument('--finance',action='store_true');args=parser.parse_args()
    E.save(HERE/'人工確認.json',B.artificial())
    if args.pure:pure()
    else:finance()
