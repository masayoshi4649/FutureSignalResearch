"""指数間85口座の固定結果と、主1秒25口座の閲覧資料を保存する。"""
from pathlib import Path
import csv
import hashlib
import io
import json
import math
import re
import shutil
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).parent
TRIAL=ROOT/'study/00206_指数間の相対変化を複合入口へ加える'
OUT=ROOT/'outputs/00206_指数間の相対変化の比較'
sys.path.insert(0,str(ROOT/'work/201板数量比較'))
import 実行201 as E


def write(path: Path,text: str) -> None:
    """
    機能: 日本語UTF-8の閲覧資料を保存する。
    引数: path(Path)、text(str)。
    返り値: None。固定Sourceと金融正本を変更しない。
    """
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text,encoding='utf-8')


# ----------------------------------------
def csv_check() -> dict:
    """
    機能: 主時計全125CSVを元セルと照合し、未知と累計を確認する。
    引数: なし。
    返り値: dictは再読票。
    """
    proof=E.read(ROOT/'work/206CSV検査/作成確認.json');data=E.read(HERE/'閲覧入力.json');cells=unknown=0
    for item in proof['files']:
        path=OUT/item['相対path'];raw=path.read_bytes();assert hashlib.sha256(raw).hexdigest()==item['sha256']
        actual=list(csv.reader(io.StringIO(raw.decode('utf-8-sig'))));table=data['tables'][item['元表']]
        expected=[table['headers']]+[r for r in table['rows'] if r[0]==item['候補']]
        assert len(actual)==len(expected)
        for a,b in zip(actual,expected,strict=True):
            assert len(a)==len(b)
            for left,right in zip(a,b,strict=True):
                cells+=1
                if right is None:assert left=='';unknown+=1
                elif isinstance(right,(int,float)):assert math.isclose(float(left),right,abs_tol=1e-7)
                else:assert left==right
        if item['元表']=='候補比較':continue
        assert len(actual)==(43 if item['元表']=='デイ' else 42)
        cumulative=0.;complete=True
        for row in actual[1:]:
            assert math.isclose(float(row[3])-float(row[4]),float(row[10]),abs_tol=1e-7)
            cumulative+=float(row[10]);complete=complete and int(row[8])==0
            assert math.isclose(cumulative,float(row[11]),abs_tol=1e-7)
            if complete:assert math.isclose(cumulative,float(row[6]),abs_tol=1e-7)
            else:assert row[6]==''
    assert len(proof['files'])==125 and cells==52500 and unknown>0
    return {**proof,'全セル再読':cells,'未知空欄':unknown,'全場と累計一致':True}


# ----------------------------------------
def settings() -> None:
    """
    機能: 親199/200と新しい指数間設定を全567セルへ対応付ける。
    引数: なし。
    返り値: None。板201の条件は継承しない。
    """
    parents=[ROOT/'study/00199_保留中の旧幹を確認済みの根拠で切り替える/設定と結果.md',
             ROOT/'study/00200_TOPIXの観測被覆と構造確認の順序を分ける/設定と結果.md']
    grids=[]
    for path in parents:
        grid={}
        for line in path.read_text(encoding='utf-8').splitlines():
            p=[x.strip() for x in line.split('|')[1:-1]] if line.startswith('|') else []
            if len(p)==11 and re.fullmatch('[ICPVBEMX][0-9]{2}',p[0]):grid[p[0]]=p
        assert len(grid)==63;grids.append(grid)
    template=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md'
    body=template.read_text(encoding='utf-8').split('## 設定明細（コピー後に記入）')[0]
    body=body.replace('# 手法と時間スケールの汎用表・版8','# 206 設定と結果・版8')
    body=body.replace('全セルは未設定・未検証。','Nは199、Tは200の親設定。S206は指数間追加、R206は全85口座の複合評価。')
    body=body.replace('](../technical-analysis/','](../../docs/technical-analysis/')
    lines=[];count=0
    for line in body.splitlines():
        p=[x.strip() for x in line.split('|')[1:-1]] if line.startswith('|') else []
        if len(p)==11 and p[0] in grids[0]:
            code=p[0];p[1]=grids[0][code][1];count+=1
            for j in range(2,11):
                parts=[prefix+g[code][j] for prefix,g in zip(('N:','T:'),grids) if g[code][j]!='未使用']
                if code=='X01' and j in (2,3,5,6,7):parts.append('S206 同じ過去端点・実側return・品質Q')
                p[j]=' / '.join(parts)+'/R206' if parts else '未使用'
            line='| '+' | '.join(p)+' |'
        elif line.startswith('[版7]'):line='[版7](../../docs/議論/手法と時間スケールの汎用表_版7.md)。旧表は保持。'
        lines.append(line)
    assert count==63
    tail='''
## 設定明細と結果

Nは[199](../00199_保留中の旧幹を確認済みの根拠で切り替える/設定と結果.md)の00/02/05、Tは[200](../00200_TOPIXの観測被覆と構造確認の順序を分ける/設定と結果.md)のI00/I10。表は有効枝の和集合で、全セルを全候補で同時使用する意味ではない。板201のQI/OFI条件は今回の売買に使わない。

S206は確定分足ではなく原板Lastの同じ過去端点間のlogreturn。窓1/5/15/30分、自己/相手、主遅延1秒、感度5/30/60秒。端点停滞60秒以内、内部300秒超価格時計gapなしをQとし、全8列既知を要求する。原行以前だけ参照し、場を跨がない。未知を0へ変えない。

BASE、Q可用性だけのAVAIL、相手15/30分の実側支持PEER、相手4窓全て反対時だけ棄却VETO、相手15分支持・自己の相対的遅れ・自己1分回復RELATIVE。[金融前カタログ](金融前カタログ.json)に閾値と未知時動作。同q0の別名Tへ迂回しない。係数1の差は裁定・均衡・受信先行性を証明しない。

R206は5母体×17=85口座、全83既使用。元幅・期限・単純IFD・保有予約1・終了15分前を保持。NK mini1pt100円/往復費用1,077円、miniTOPIX1pt1,000円/583.6円。ラージBBO代用。主条件を成績の良い遅延へ交換しない。新たな全面採用はしないが、日経の損失軽減の部分効果と夜間の少数入替えは次仮説へ残す。

[全85設定別結果](全85条件の比較.md)・[安定性正本](全85口座安定性.json.gz)・[主25候補別CSV](../../outputs/00206_指数間の相対変化の比較/README.md)。567セル、元表SHA256: '''+E.ref(template)['sha256']+'。\n'
    write(TRIAL/'設定と結果.md','\n'.join(lines)+'\n'+tail)


# ----------------------------------------
def main() -> None:
    """
    機能: 全85固定台帳・Source・全条件表と主25の閲覧入口を保存する。
    引数: なし。独立金融監査成功を先に要求する。
    返り値: None。
    """
    audit=ROOT/'work/206独立確認/金融独立確認206.json.gz'
    assert E.read(audit)['成功']
    proof=csv_check();E.save(TRIAL/'CSV確認.json',proof)
    for name in ('純封印.json','純封印_v2.json','金融開始前固定.json','純成立診断.json','旧五母体同体.json',
                 '全85口座安定性.json.gz','全85口座短表.json.gz','閲覧入力.json','人工確認.json'):
        shutil.copy2(HERE/name,TRIAL/name)
    (TRIAL/'金融正本').mkdir(exist_ok=True)
    for p in (HERE/'金融正本').glob('*.json.gz'):shutil.copy2(p,TRIAL/'金融正本'/p.name)
    condition=E.read(TRIAL/'条件_v2.json');E.save(TRIAL/'金融前カタログ.json',condition['カタログ'])
    sources=[ROOT/r['path'] for r in condition['Sourceと参照']+condition['純出生'] if r['path'].startswith(('work/','scripts/'))]
    sources+=list(HERE.glob('*.py'))+[ROOT/'scripts/損益CSV/候補別に出力する.mjs',ROOT/'work/199候補別CSV/入力を作る.py']
    sources=sorted(set(p for p in sources if p.is_file() and 'pythonlibs' not in p.parts))
    with zipfile.ZipFile(TRIAL/'金融Source.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sources:z.write(p,p.relative_to(ROOT).as_posix())
    E.save(TRIAL/'金融Source索引.json',[E.ref(p) for p in sources]);settings()
    stats=E.read(HERE/'全85口座安定性.json.gz')['metrics'];by_id={s['id']:s for s in stats}
    rows=['# 全85条件の比較','',
          '全83既使用・各商品mini1枚・費用後の円。d001が主時計、d005/d030/d060は感度。利益/損失/収支は既知寄与で、未知を含む口座の確定額ではない。両中央値は未知を含めた下限で判定する。全条件の閾値は[カタログ](金融前カタログ.json)。', '',
          '|ID|帯|取得/参加場|未知|保有下限|利益|損失|既知収支|赤字取引/場|両中央値正|場末DD既知寄与|',
          '|---|---|---:|---:|---:|---:|---:|---:|---:|---|---:|']
    for stat in stats:
        for band in ('DAY','NIGHT'):
            g=stat['groups'][band];t=g['trades'];s=g['sessions']
            rows.append(f"|{stat['id']}|{band}|{t['all_count']}/{s['participating_count']}|{t['unknown_count']}|{g['holding']['held_lower_ratio']:.2%}|{t['known_profit']:,.1f}|{t['known_loss']:,.1f}|{t['known_net']:,.1f}|{t['negative_rate']['negative_count']}/{s['negative_rate']['negative_count']}|{'正' if g['both_medians_positive'] else '未達'}|{g['path']['known_contribution']['max_drawdown']['amount']:,.1f}|")
    rows+=['','前48/後25/追加7/本日1/追加2と全80は[統計正本](全85口座安定性.json.gz)。0取得場を落とさず、予約を保有としない。相手指数の情報が取れる場合だけに絞る効果はAVAILで分ける。比較の母体自体が両指数で異なるため、損益差から固有の市場心理を断定しない。']
    write(TRIAL/'全85条件の比較.md','\n'.join(rows)+'\n')
    rows=['# 指数間確認の主1秒・全25候補','',
          'N00/N02/N05は日経199の00/02/05、T00/T10はTOPIX200のI00/I10。BはBASE、QはAVAIL、PはPEER、VはVETO、RはRELATIVE。各候補のCSVへ分離し、異なる手法を一つに混ぜない。', '',
          '|候補|母体/条件|デイ利益/損失|デイ収支|ナイト利益/損失|夜間既知収支|','|---|---|---:|---:|---:|---:|']
    for m in E.read(HERE/'閲覧入力.json')['候補対応']:
        code=m['候補'].split(':')[1];folder='206_'+code;g=by_id[m['id']]['groups'];d,n=g['DAY']['trades'],g['NIGHT']['trades']
        rows.append(f"|[{code}]({folder}/README.md)|{m['母体']}/{m['相手条件']}|{d['known_profit']:,.1f}/{d['known_loss']:,.1f}|{d['known_net']:,.1f}|{n['known_profit']:,.1f}/{n['known_loss']:,.1f}|{n['known_net']:,.1f}|")
        write(OUT/folder/'README.md',f'''# {m['候補']}

正本ID `{m['id']}`。商品{m['商品']}、主1秒・{m['相手条件']}。[カタログ](../../../study/00206_指数間の相対変化を複合入口へ加える/金融前カタログ.json)。

[集計](集計.csv) / [デイ](デイ.csv) / [ナイト全体](ナイト全体.csv) / [ナイト米国前](ナイト_米前.csv) / [ナイト米国後](ナイト_米後.csv)。全83場、Day42/Night41、各商品mini1枚、費用後の円。NK往復1,077円、TOPIX583.6円。ラージBBO代用。

未知を含む場の確定収支と以後の確定累計は空欄。既知寄与は別列で、未解決を0円としない。実保有時間率下限は対象時間比0〜1、終了15分前を除き、予約は保有としない。損益は新規の帯、保有は実区間重複へ帰属。ナイト全体と米前/後は重複合算しない。

[比較一覧](../README.md)・[結果と限界](../../../study/00206_指数間の相対変化を複合入口へ加える/README.md)。探索に全83場既使用。
''')
    rows+=['','[全85設定別比較](../../study/00206_指数間の相対変化を複合入口へ加える/全85条件の比較.md)・[仮説と限界](../../study/00206_指数間の相対変化を複合入口へ加える/README.md)。遅延5/30/60秒の60口座も統計正本と金融台帳へ保持し、主の上位互換とはしない。125CSV・52,500セル再読一致。']
    write(OUT/'README.md','\n'.join(rows)+'\n')
    print(json.dumps({'正式保存':85,'主CSV':125,'Source資源':len(sources),'汎用表':567},ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':main()
