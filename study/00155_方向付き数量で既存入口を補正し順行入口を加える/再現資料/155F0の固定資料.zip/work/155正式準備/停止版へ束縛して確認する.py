"""数量恒久化と155Source最終停止後、正式3文書を同じbookへ束縛する。"""
from pathlib import Path
import argparse
import hashlib
import json
import re
from urllib.parse import unquote

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
FORMAL=ROOT/'study/00155_方向付き数量で既存入口を補正し順行入口を加える'
SOURCE=ROOT/'work/155量方向による入口'
INPUT=ROOT/'inputs/00155_方向付き数量の測定'
NOTICE=ROOT/'work/155採用条件のRoot通知.md'
NOTICE_SHA='5b6eedc71c27fae3ab02d51eb779762eda515e32115d403785cab7ae555a9171'
PHYSICAL='947dd612858e5560debe0c350c73eda2a12d821f515bd6f9627c2040676901d3'
DECODED='9b8ace0d3ec2649ab484762d3bf8dc35b0a229ebe3c384a6e875cc74252be4f0'
POLICIES=['C0','C1','RC1','B152','UB152','U154','Q0','RQ0','UQ0','FT','UFT','N0','U0','RU0','NZ','UZ']


def sha(path: Path) -> str:
    """
    機能: 小源・文書の物理SHA256を求める。
    引数: path(Path)。返り値: str。
    """
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()


def catalog(text: str) -> list:
    """
    機能: 設定明細と区別して57手法9尺度の本表だけを取り出す。
    引数: text(str)。返り値: list[list[str]]。
    """
    return [[cell.strip() for cell in line.split('|')[1:-1]] for line in text.splitlines() if re.match(r'^\|\s+[A-Z]\d{2}\s+\|',line) and len(line.split('|'))==13]


def main() -> None:
    """
    機能: 停止book/数量指紋と513セルを検査し正式文書を未実行で停止する。
    引数: CLI book-sha256/preparation-sha256/stop-sha256(str)。返り値: None。
    """
    parser=argparse.ArgumentParser()
    for name in ('book-sha256','preparation-sha256','stop-sha256'):parser.add_argument('--'+name,required=True)
    args=parser.parse_args();assert not (HERE/'準備の確認.json').exists()
    paths=[SOURCE/name for name in ('条件.json','準備の確認.json','停止.json')]
    expected=[args.book_sha256,args.preparation_sha256,args.stop_sha256]
    assert [sha(p) for p in paths]==expected
    book,prepared,stopped=[json.loads(p.read_bytes()) for p in paths]
    assert prepared['成功'] and stopped['成功'] and stopped['編集停止']
    assert book['trial']==155 and book['primary']=='U0' and book['buffers']=={'main':.05,'zero':0}
    assert book['financial_policies']==POLICIES and book['feature_rows']==35339 and book['session_count']==73 and book['legacy_count']==87
    assert book['quantity_input']['path']=='inputs/00155_方向付き数量の測定/方向付き数量の入力.json.gz'
    assert book['quantity_input']['sha256']==PHYSICAL and book['quantity_input']['decoded_sha256']==DECODED
    assert book['quantity']['obv_field']=='change' and not book['quantity']['obv_ratio_used']
    assert book['quantity']['known_zero_obv_is_known_zero'] and not book['quantity']['OBV5_OBV30_previousCMF_delta_decision_used']
    assert book['quantity']['CMF_OBV_independent_roles'] is False
    assert book['FT']['rsi_delta_AND'] is False and book['FT']['ema8_distance_range']=='[0,1]'
    assert book['common']['spread_range']=='(0,20]' and book['common']['abs_last_close_atr5_max']==1
    assert book['base']['unknown_or_nonopposition']=='keep' and not book['base']['unknown_keep_is_quantity_support']
    assert book['linking']['same_q1_priority']==['C1','Q0','FT'] and book['linking']['all_q0_saved_before_controls']
    assert book['fixed154_control']['expected_counts']=={'B152':614,'UB152':697,'U154':213,'C1':87}
    assert book['no_model_or_teacher'] and not book['current100X_or_old_model_changed']
    assert sha(NOTICE)==NOTICE_SHA and book['sources']['work/155採用条件のRoot通知.md']==NOTICE_SHA
    assert (FORMAL/'再現資料/採用条件のRoot通知.md').read_bytes()==NOTICE.read_bytes()
    source_map={name:sha(ROOT/name) for name in book['sources']};assert source_map==book['sources']
    saveproof=json.loads((INPUT/'入力の保存確認.json').read_bytes());assert saveproof['成功'] and saveproof['正本']['sha256']==PHYSICAL
    assert saveproof['正本']['decoded_sha256']==DECODED and saveproof['恒久gzipコピー回数']==1
    assert sha(INPUT/'方向付き数量の入力.json.gz')==PHYSICAL
    before={p.relative_to(ROOT).as_posix():sha(p) for p in SOURCE.iterdir() if p.is_file()}
    permanent=INPUT/'条件.json'
    if permanent.exists():assert permanent.read_bytes()==paths[0].read_bytes()
    else:
        with permanent.open('xb') as sink:sink.write(paths[0].read_bytes())
    # ----------------------------------------
    # 数値条件を変えず、最終book/源/数量の指紋だけを文書へ束縛する。
    condition=FORMAL/'条件.md';text=condition.read_text(encoding='utf-8');assert '## F0前の最終停止版' not in text
    text=text.replace('最終Source/book/数量入力の指紋はF0前に束縛する。','最終Source/book/数量入力の指紋は末尾へ束縛済み。')
    text+=f'''\n\n## F0前の最終停止版

[恒久book](../../inputs/00155_方向付き数量の測定/条件.json) SHA256 `{args.book_sha256}`。Source[準備票](../../work/155量方向による入口/準備の確認.json) `{args.preparation_sha256}`、[停止票](../../work/155量方向による入口/停止.json) `{args.stop_sha256}`。Root採用通知 `{NOTICE_SHA}`へ束縛した。主U0/a=.05と全式は不変。

[数量恒久入力](../../inputs/00155_方向付き数量の測定/README.md)は物理 `{PHYSICAL}`、解凍 `{DECODED}`。Source147/153からの非金融測定1回・全件独立照合・同体一度保存を経た入力であり、155売買/容量/金融を先に評価した記録ではない。

本票は正式文書作者の自己確認であり、Source純判断/運転の独立レビューとは別。自然155売買・容量・金融は引き続き未実行、Root F0後だけ実行する。
'''
    condition.write_text(text,encoding='utf-8',newline='\n')
    readme=FORMAL/'README.md';text=readme.read_text(encoding='utf-8').replace('最終book/入力/源指紋はF0前に束縛する。','最終book/入力/源指紋は[条件末尾](条件.md)へ束縛済み。')
    readme.write_text(text,encoding='utf-8',newline='\n')
    original=catalog((ROOT/'docs/議論/手法と時間スケールの汎用表_版7.md').read_text(encoding='utf-8'))
    configured=catalog((FORMAL/'設定と結果.md').read_text(encoding='utf-8'))
    assert len(original)==len(configured)==57
    assert [re.sub(r'\]\([^)]*\)',']',r[1]) for r in original]==[re.sub(r'\]\([^)]*\)',']',r[1]) for r in configured]
    # 教材リンクは相対起点だけ変わるため、IDと9列を別に検査する。
    assert [r[0] for r in original]==[r[0] for r in configured] and all(len(r[2:])==9 for r in configured)
    heading='| ID | 手法 | 原板・逐次 | 1分 | 3分 | 5分 | 15分 | 30分 | 60分 | セッション足 | 日足 |'
    assert heading in (FORMAL/'設定と結果.md').read_text(encoding='utf-8')
    rows={r[0]:r[2:] for r in configured};assert '1m×15' in rows['V02'][1] and '1m×20CMF' in rows['V06'][1]
    assert 'a0比較' in rows['V06'][1] and 'H=Lは0' in rows['V06'][1]
    assert 'RSIΔ>0 OR' in rows['I04'][3] and '30EMA21生増分>0' in rows['I01'][5]
    docs=[FORMAL/name for name in ('README.md','条件.md','設定と結果.md')];links=0
    for path in docs:
        body=path.read_text(encoding='utf-8');assert '未実行' in body and '全セルは未設定・未検証。' not in body
        for target in re.findall(r'\]\(([^)]+)\)',body):
            if '://' in target or target.startswith('#'):continue
            local=unquote(target.strip('<>').split('#',1)[0]);assert (path.parent/local).exists(),(path.name,target);links+=1
    assert before=={p.relative_to(ROOT).as_posix():sha(p) for p in SOURCE.iterdir() if p.is_file()}
    assert source_map=={name:sha(ROOT/name) for name in source_map} and [sha(p) for p in paths]==expected
    proof={'成功':True,'試行':155,'編集停止':True,'自然155売買_容量_金融未実行':True,
        'Sourcebook数量指紋束縛':True,'文書作者自己確認_Source独立レビューとは別':True,
        'Root通知SHA256':NOTICE_SHA,'book恒久1回同体':{'path':permanent.relative_to(ROOT).as_posix(),'sha256':sha(permanent)},
        'Source準備SHA256':args.preparation_sha256,'Source停止SHA256':args.stop_sha256,'Source全ファイル前後同体':before,
        '数量保存確認SHA256':sha(INPUT/'入力の保存確認.json'),'V7':{'手法':57,'尺度':9,'セル':513,'ID順時間列保持':True,'使用セル閾値記入':True},
        '主':'U0','比較':'UZ/a=0','政策':POLICIES,'比較数':960,'ローカルリンク実在':links,
        '正式3MD':{p.name:sha(p) for p in docs},'生成器SHA256':sha(HERE/'正式文書を作る.py'),'確認器SHA256':sha(Path(__file__)),
        '旧154以前_共通知見_目次変更':False}
    (HERE/'準備の確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'成功':True,'準備SHA256':sha(HERE/'準備の確認.json'),'正式3MD':proof['正式3MD'],'513':True,'リンク':links},ensure_ascii=False))


if __name__=='__main__':
    main()
