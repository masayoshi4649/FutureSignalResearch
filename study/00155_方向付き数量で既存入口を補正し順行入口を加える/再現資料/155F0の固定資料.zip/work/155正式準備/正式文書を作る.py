"""155採用原文を保存し、未実行の正式3文書とV7全513セルを用意する。"""
from pathlib import Path
import hashlib
import os
import re

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
FORMAL=ROOT/'study/00155_方向付き数量で既存入口を補正し順行入口を加える'
NOTICE=ROOT/'work/155採用条件のRoot通知.md'
NOTICE_SHA='5b6eedc71c27fae3ab02d51eb779762eda515e32115d403785cab7ae555a9171'
V7=ROOT/'docs/議論/手法と時間スケールの汎用表_版7.md'


def sha(path: Path) -> str:
    """
    機能: 文書・採用原文の物理指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relocate(match: re.Match) -> str:
    """
    機能: 原V7の教材リンクを同じ参照先の正式相対パスへ変換する。
    引数: match(re.Match)。返り値: str。
    """
    target=match.group(2)
    if '://' in target or target.startswith('#'):return match.group(0)
    path,separator,anchor=target.partition('#');destination=(V7.parent/path).resolve();assert destination.exists()
    relative=os.path.relpath(destination,FORMAL).replace('\\','/')
    return f'[{match.group(1)}]({relative}{separator}{anchor})'


def configured_table() -> str:
    """
    機能: V7の57手法・9尺度を保ち、155の使用セルへ短い閾値を記入する。
    引数: なし。返り値: str。1分数量窓を15/30分足へ混同しない。
    """
    text=V7.read_text(encoding='utf-8').split('## 手法×時間スケール',1)[1].split('## 設定明細',1)[0]
    text=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',relocate,text)
    text=text.replace('全セルは未設定・未検証。','該当セルは設定済み。自然155売買・容量・金融は未実行。',1)
    cells={
        ('I01',3):'155-FT：最終実側EMA8距離[0,1]ATR5；Q反転は≤1；未実行',
        ('I01',5):'155-FT：t×30EMA21生増分>0；未実行',
        ('I03',3):'155-FT：tHist水準>0/実Δ>0；Q反転はHistΔ>0 OR RSIΔ>0；未実行',
        ('I04',3):'155-Q：反転確認のRSIΔ>0 OR HistΔ>0、FTへAND無し；未実行',
        ('I09',3):'155-Q/FT：ATR5>0、absLastClose≤1ATR・EMA8位置尺度；未実行',
        ('P01',1):'155-FT：t実体比>0、Lastはr.Close順側又は同値；未実行',
        ('P04',0):'155-FT：t(Last−p.Open)>0；Q反転：t(Last−r.Open)>0；未実行',
        ('V01',1):'155-FT：同r量/当場先行3平均≥1、未知量を0にしない；未実行',
        ('V02',1):'155-Q/FT：r含む1m×15のOBV変化、符号用前Close必須；5/30は記録のみ；未実行',
        ('V06',1):'155-Q/FT：r含む1m×20CMF；tCMF>.05/反対<−.05；a0比較；H=Lは0；未実行',
        ('C01',0):'155-Q：量反対時の実体現在回復＋5Hist/RSI三値OR＋実側位置；未実行',
        ('C07',0):'155-FT：30方向＋5Hist＋1分回復/量＋現在実側位置；未実行',
        ('B01',0):'155-Q/FT：正常BBO、0<spread≤20、absLastClose≤1ATR；未実行',
        ('M01',0):'継承対照B152は過去モデル由来、155新学習/再予測なし',
        ('E01',0):'155-E：主U0/BBO/H60±125、16政策960；未実行',
        ('E01',5):'155-E：H30副診断、OBV/CMFの分足窓と別；未実行',
        ('E01',6):'155-E：H60主、近接窓重複依存を保持；未実行',
        ('E02',0):'対象外：独立mini1 IFD、必須追尾/保有制約なし',
    }
    out=[]
    for line in text.splitlines():
        row=line.split('|')
        if re.match(r'^\|\s+[A-Z]\d{2}\s+\|',line) and len(row)==13:
            ident=row[1].strip()
            for i in range(9):
                value=cells.get((ident,i),'未使用・未検証')
                if ident.startswith('X') or ident=='V05':value='対象外・新検証なし'
                row[i+3]=' '+value+' '
            line='|'.join(row)
        out.append(line)
    return '\n'.join(out)+'\n'


def main() -> None:
    """
    機能: Root採用155の正式3文書を自然売買未実行として新規作成する。
    引数: なし。返り値: None。最終book束縛は別確認器で行う。
    """
    assert sha(NOTICE)==NOTICE_SHA and not FORMAL.exists()
    numbers=[int(p.name[:5]) for p in (ROOT/'study').iterdir() if p.is_dir() and re.match(r'^\d{5}_',p.name)]
    assert max(numbers)==154
    FORMAL.mkdir();(FORMAL/'再現資料').mkdir();(FORMAL/'再現資料/採用条件のRoot通知.md').write_bytes(NOTICE.read_bytes())
    readme='''# 155 方向付き数量で既存入口を補正し順行入口を加える

**準備中・F0未固定。自然155売買・容量・金融は未実行。** 主U0=C1∪N0、N0=Q0∪FT、CMFバッファa=.05を数量自然測定より前に採用した。a=0のUZは事前比較であり、結果後に主へ交換しない。

価格・勢いだけの切替や回帰環境分類で期間差を解消できなかったことを動機に、終値の方向に配分した観測量を追加する。固定B152へ量反対時だけ複合回復を要求するQ0と、全35,339適格q0から量・30分方向・5分勢い・1分現在回復を合わせる独立FTを分ける。既存100特徴・モデルを変更せず、新学習/再予測をしない。

| 役割 | Q0の補正 | FTの独立出生 |
| --- | --- | --- |
| 方向 | 固定B152の元側sを後段で参照、強い量反対だけ新側t=−s | 30分EMA21実増分がt側へ正 |
| 勢い | 新側Hist5実増分>0 OR RSI5実増分>0 | Hist5水準・実増分がt側へ正。RSI増分は追加ANDしない |
| 構造・現在回復 | 新側Lastがr.Openを回復 | r実体とLastのp.Open回復、Lastはr.Close順側又は同値 |
| 値幅・取得位置 | ATR5正、Last−Close差≤1ATR、最終側EMA8距離≤1ATR | 同品質＋最終側EMA8距離[0,1]ATR |
| 量 | s×CMF<−aかつs×OBV15変化<0なら反対。未知/非反対は旧側維持 | t×CMF>a、t×OBV15変化>0、同r相対量≥1 |

CMFとOBVは同じ量役割の異なる記述で、独立な二票ではない。ヒストとRSIも同じ勢い役割で、一般的な多数決をしない。ADXの新hardgateは加えない。心理は「価格回復と数量配分が同じ側へ揃うときの継続」「量が強く反対なら現在の価格・勢いによる反転確認を要する」という仮説であり、攻撃側注文フロー/吸収/真の資金流入を観測した証明ではない。

## 入力と数量測定

148の100列・全q0/取得対応/保存正逆を共有する。147の1分Volumeを153のcanonical価格へ全ID/品質/Stamp照合し、別の非方向数量入力を作る。新Raw/CSV/追加2場の走査は行わない。数量測定は全40,544q0・適格35,339・73場を保持し、量未知を0へ補わない。測定生成の成否と155の売買採否・率・損益は別である。

OBVはr含む1分×15の変化で、符号用の前Closeを含む16連続価格と当15本量が必要。CMF20はr含む1分20本の数量加重終値位置。H=LはMFM0、総量0は値未定義、既知OBV変化0は既知0とする。5/30分のOBV、前CMF/Δは保存するが主採否へ使わない。期間15/20は15/20分足ではない。

全q0へ両側FTと仮定元側sのkeep/flip/waitを先に保存し、その後だけ固定B152/旧C1/q1を結ぶ。q1やラベルを新資格へ渡さない。同q0の両側trueは待機、片true・反対unknownはtrue側。別q0同q1は最早canonicalで後発aliasが取消/方向取直しをしない。同q1はQ0優先、さらにC1全87を優先する。

## 評価・費用と限界

主は実BBO/H60/同幅±125pt。16政策×全/前48/後25×2軸×2H×5幅で960比較。全73場min1、全時間平均概ね1/h、到達済70%を別及び共同判定する。未到達・観測不足・IFD未知と0取得場を除かない。新候補数/取得数/容量/率/利益は未計数。

独立mini1枚100円/pt、往復77円+C5追加1,000円。利益・損失・既知差引と未知を分け、未知累積後の全件確定差引はnull。重複H60・同場依存を保持し、同時IFD合算を可変枚数・保有制約・必須追尾の口座収支と呼ばない。実逆は同q1の反対BBOで計算し、1−pへ置き換えない。

旧29 OBV、42/43 CMF、47/48 Forceも未達だった。今回は初検証・数量単独効果・a=.05の有効性を主張せず、広い全1分母集団への因果測定と複合の新仮説である。全73場既使用・152事後再診断後の着想で、前48/後25も未知期ではない。旧高率群の単純外挿、日付除外、有利群だけの後採用はしない。

[採用条件](条件.md) / [V7設定513セル](設定と結果.md) / [採用通知原文](再現資料/採用条件のRoot通知.md)。最終book/入力/源指紋はF0前に束縛する。Root F0→全q0判断/後段接続→F1→金融前F2→960集計の順で実行予定。CSVは結果後にRootが作成し、xlsxは作らない。
'''
    notice=NOTICE.read_text(encoding='utf-8')
    condition=f'''# 155 実行前の採用条件

2026-11-12。準備中・F0未固定、自然155売買・容量・金融未実行。主U0、a=.05、比較a=0、全16政策960比較を固定する。採用源は[Root通知原文](再現資料/採用条件のRoot通知.md)、物理SHA256 `{NOTICE_SHA}`。最終Source/book/数量入力の指紋はF0前に束縛する。

## 採用通知本文

{notice.split(chr(10),1)[1]}

## 時計・式の補足

tは最終物理方向、sは後段で結ぶ固定B152の最終元側。買はAsk0、売はBid0で100列を独立に計算したものを読む。単純negateや1−xで反対側の実側取得位置を復元しない。ATR5はq0背景の正既知値、Lastはq0価格で、将来q1から採否を作らない。

FTの現在回復は `t*(Last0−p.Open)/ATR5 = body_reclaim_t + last_minus_rClose_t`。r.Closeの確認だけと区別し、q1で維持した保証とはしない。Base反転確認は `t*(Last0−r.Open)>0` で、p.Open回復とは別条件である。HistはMACDヒストの現水準と実前との差、RSI増分は生RSI ptでありATR正規化ではない。

FTは採否に必要な各条件が既知で成立することを要求する。観測保存だけのRSI増分の未知はFTを失格にしない。Baseの勢いORだけは三値で既知trueが勝ち、true無し・unknownありはunknown。量の強い反対は両knownかつ strict、C_s=−aやO_s=0では反対不成立。CMF=a、OBV=0はFT不成立。相対量=1、spread=20、LastClose差=1ATR、EMA8距離端[0,1]は包含、spread=0は不成立。量未知/非反対をQ0でkeepするのは明示の旧政策復帰分岐で、量支持を確認したという意味ではない。

CMF20の市場窓は `[r.End−1200,r.End)`、OBV15は `[r.End−900,r.End)` と符号用前Close。欠分・価格量未知・未closedを詰めず、同場・同限月・配送済み足だけを使用。足End/AvailableAt/Stampとq0時刻/index/lineを照合する。rの初配送Stamp=q0。未知を0へ補わず、H=Lだけは採用仕様に基づくMFM既知0で、総量0は値undefined。V7の一般説明に対する155設定差として記録し、旧試行を変更しない。前CMFは同q0知得prefixで1分ずらした市場窓、Δは両値defined時だけ。窓入替えの影響を含むため新規の資金流入そのものではなく、155採否には使わない。

## 保存・対照・未実行

全q0判断保存後だけcapture/meta/固定154選択からB152614・UB152697・U154213・C187を結合する。新判断が旧選択・モデル・ラベルを引数に持たないことを人工/独立運転レビューで確認する予定。未知は出典maskとnullを保存し、未取得q0判断も残す。B152/UB152/U154の旧対照は再選別しない。金融の旧152全120条件と旧154全60条件の統計dict同体を要求する。

準備時点では自然155採否・容量・金融のいずれも未実行。率目標達成・頻度充足・損益の推定は行っていない。数量測定は入力検査として売買評価と分離する。
'''
    setting=f'''# 155 設定と結果

使用版は[汎用表・版7](../../docs/議論/手法と時間スケールの汎用表_版7.md)、SHA256 `{sha(V7)}`。57手法×9尺度=513セルを全コピーしID/時間列/教材リンクを維持する。準備中・F0未固定、自然155売買・容量・金融は未実行。複合評価ID155-Q/FT/E、主U0/a=.05、比較UZ/a0を結果前に定めた。

{configured_table()}

## 設定明細

| ID | 設定と役割 | 結果 |
| --- | --- | --- |
| 155-Q | 量が元sへ強く反対なら新tの現在r.Open回復・勢いOR・実側位置を要求。反対無し/未知は旧側keep | 未実行 |
| 155-FT | CMF/OBV量支持＋30EMA方向＋5Hist水準/実Δ＋1分実体/現在p.Open回復＋量/位置 | 未実行 |
| 155-QTY | 1分×15 OBV変化、1分×20 CMF。全q0/品質/参照を保存、旧100列へ混入しない | 入力測定と売買評価は別 |
| 155-LINK | 全新q0先保存、後段Q0優先N0・C1優先U0。同q1最早canonical | 未実行 |
| 155-E | 実BBO/H60±125主、16政策960比較。利益/損失/未知/頻度/参加を分離 | 未実行 |

1分から作る15本OBV/20本CMFを15分足・20分足とは呼ばない。OBV5/30・前CMF/Δは入力記録のみ、未使用セルの有効性を推定しない。I08 ADXやI14回帰を今回の新出生ANDへ加えない。M01は旧B152の由来だけで、新モデルを学習/推論しない。

CMF/OBV/相対量は量の同じ役割、Hist/RSIは勢いの同じ役割である。複合結果が出ても指標単独の効果・独立した票数としない。全73場既使用、後付け設計、未知期なし、近接H60依存を保持する。
'''
    for name,text in [('README.md',readme),('条件.md',condition),('設定と結果.md',setting)]:
        (FORMAL/name).write_text(text,encoding='utf-8',newline='\n')
    print('155正式3文書を準備。最終book指紋束縛は未実施。')


if __name__=='__main__':
    main()
