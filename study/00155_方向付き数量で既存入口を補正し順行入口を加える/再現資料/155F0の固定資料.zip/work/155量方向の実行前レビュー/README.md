# 155の純判定と運転の実行前独立レビュー

2026-11-12。Root採用原文と最終book `23c059a2900136f9643d61ade0a5bb7a4295ba0c87de571a1ab84b18985142e6` を基準とする。作者Sourceを変更せず、155の自然判断・取得数・金融は読まない。方向付き数量の自然全件監査は[別の停止票](../方向付き数量の自然独立確認/停止の確認.json)であり、本レビューの人工とは分ける。

## 確認した主な境界

- pure APIは `choose(buy, sell, columns, measurement, quantity)`。q1、旧B152の選択、旧予測、教師やラベルの引数を持たず、買Ask/売Bid由来の各100列を明示して渡す。
- Baseは元s側へCMFと生OBV15差が両方既知で強い反対になったときだけ、新t側の確認でflip/waitする。反対不成立や量unknownは明示KEEP。共通品質unknown/falseをKEEPへの追加除外にしていない。
- Native FTは全required knownを要求する。CMFの主a=.05は厳密超過、a=0は別対照、生OBVの0は既知0。量比1、Last対r.Closeの0、EMA8実側距離0/1は包含し、上限超過を除く。FTにRSI増分ANDを追加しない。
- Base反転は新実側の現在Lastがr.Openを厳密に越え、EMA8距離<=1、Hist改善OR RSI改善の既知trueを要求する。ORでは既知trueを優先し、ANDは全required knownを要求する。
- 売買の物理反射（価格反射とBid/Ask交換、CMF/OBV符号反転、買売vector交換）でaction/方向が反転する。FT片側true＋反対unknownは採用、両true競合は待機する。

[独立人工.py](独立人工.py)はRoot式から私有の期待式と価格/数量DTOを作り、13ケース・130主要項目を照合した。初回の私有期待式でANDをfalse優先にした点は、Root仕様の全required knownへ修正した。作者Sourceや自然結果を変更したものではない。

## 運転と優先

運転DTOだけは作者の `人工検査_運転.py::link_fixture()` を借用した。作者テストの期待値や純判定算術は使わず、最早q0のFT、同物理caseのQ優先、C1の旧売側優先、Base元参照全値保持、q1 status/価格差替え後のq0判断非改変を確認した。借用2源の物理SHAと依存は[準備の確認.json](準備の確認.json)へ記録する。

運転を静的に読み、ASTで `project(175行) → q0保存(177行) → captures/metadata読取(181行) → connect(186行)` の順序を確認した。旧154選択/F1の読取もq0保存より後の同ブロックで、旧対照は取得結合後に全値copyする。book/outputはresolveし、数量の恒久gzip・153入力・100列・Sourceの物理SHAへbindする。

これは主要反例だけの限定独立レビューで、作者14人工の全再実行や155自然全件監査ではない。金融の960比較や新政策の有効性も未評価。純13ケースの期待式は作者logic/runnerを使わずに算出し、全実行源/DTO依存を前後同体確認した。重大未解決なしとして停止する。
