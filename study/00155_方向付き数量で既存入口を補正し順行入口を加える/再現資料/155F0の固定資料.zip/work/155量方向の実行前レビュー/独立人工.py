"""155の主要反例だけを独立式と小型DTOで確認する。自然入力は開かない。"""
import ast
import copy
import hashlib
import importlib.util
import inspect
import json
import math
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[2]
AUTHOR=ROOT/'work/155量方向による入口'
HERE=Path(__file__).resolve().parent
KEYS=('m5_atr','q0_last_minus_m1_close_atr5_to_side','q0_entry_minus_ema8_atr5_to_side',
      'm1_volume_relative_prior3','m30_ema21_delta_to_side','m5_hist_to_side','m5_hist_delta_to_side',
      'm5_rsi_delta_to_side','m1_body_ratio_to_side','m1_body_reclaim_atr5_to_side')
NAMES=sorted([*KEYS,*[f'未使用{i}' for i in range(90)]]);INDEX={key:i for i,key in enumerate(NAMES)}


def load(path: Path,name: str):
    """
    機能: 自然本文に触れない作者コードと人工DTOだけを読取importする。
    引数: path(Path)、name(str)。返り値: module。
    """
    spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec)
    sys.path.insert(0,str(AUTHOR))
    try:spec.loader.exec_module(mod)
    finally:sys.path.pop(0)
    return mod


# ----------------------------------------
def fixture() -> tuple:
    """
    機能: Root定義だけから100列と同q0価格/数量を私有構成する。
    引数: なし。返り値: tupleはbuy/sell/measurement/quantity。
    """
    q={'time':3721,'index':10,'source_line':11,'last':205.,'bid':204.,'ask':206.,
       'last_known':True,'bid_known':True,'ask_known':True,'quote_ok':True,'normal_bbo':True}
    r={'id':'r','start':3600,'end':3660,'available_at':3720,'stamp':{'time':3721,'index':10,'line':11},
       'price_known':True,'volume_known':True,'closed':True,'missing':False,
       'ohlc':{'open':200.,'high':208.,'low':198.,'close':204.}}
    windows={str(w):{'from':3600-w*60,'to':3600,'duration_seconds':w*60,'expected_count':w,'known':False,
             'high':None,'low':None,'high_first_ref':None,'low_first_ref':None,'range_points':None,'range_zero':None} for w in (15,30,60)}
    m={'event_id':'独立q0','session':'人工','contract':'X','eligible':True,'q0':q,'r':r,'p':None,'prior_ranges':windows}
    qty={'event_id':'独立q0','eligible':True,'r_ref':'r','q0_stamp':dict(r['stamp']),
         'obv':{'15':{'from':2760,'to':3660,'window_known':True,'change':200.,'ratio':None,'ratio_defined':False}},
         'cmf20':{'current':{'from':2460,'to':3660,'window_known':True,'value_defined':True,'value':.2}}}
    vectors=[]
    for s in (1,-1):
        values={'m5_atr':8.,'q0_last_minus_m1_close_atr5_to_side':s/8,
                'q0_entry_minus_ema8_atr5_to_side':.5 if s==1 else -.25,
                'm1_volume_relative_prior3':1.,'m30_ema21_delta_to_side':s*2.,'m5_hist_to_side':s*.5,
                'm5_hist_delta_to_side':s*.25,'m5_rsi_delta_to_side':None,
                'm1_body_ratio_to_side':s*.4,'m1_body_reclaim_atr5_to_side':s*.25}
        vectors.append([values.get(key,0.) for key in NAMES])
    return *vectors,m,qty


# ----------------------------------------
def and3(items: list) -> bool | None:
    """
    機能: 全required knownを要求するANDを独立定義する。
    引数: items(list[bool|None])。返り値: bool|None。
    """
    return None if None in items else all(items)


# ----------------------------------------
def compare(value: object,op: str,boundary: float) -> bool | None:
    """
    機能: 数値knownと厳密/包含境界を独立に判定する。
    引数: value(object)、op(str)、boundary(float)。返り値: bool|None。
    """
    if type(value) not in (int,float) or not math.isfinite(value):return None
    return {'>':value>boundary,'<':value<boundary,'>=':value>=boundary,'<=':value<=boundary}[op]


# ----------------------------------------
def oracle(f: tuple) -> dict:
    """
    機能: Root数式からFTと仮定両側actionの期待値だけを独立構成する。
    引数: f(tuple)はfixture形。返り値: dict。
    """
    buy,sell,m,qty=f;q=m['q0'];c=qty['cmf20']['current'];o=qty['obv']['15']
    cmf=c['value'] if c['value_defined'] else None;obv=o['change'] if o['window_known'] else None
    sides={}
    for s,vector in ((1,buy),(-1,sell)):
        v=dict(zip(NAMES,vector));gap=v[KEYS[1]];distance=v[KEYS[2]]
        spread=q['ask']-q['bid'] if q['normal_bbo'] else None
        common=and3([m['eligible'],q['normal_bbo'],compare(spread,'>',0),compare(spread,'<=',20),
                     compare(v['m5_atr'],'>',0),compare(abs(gap) if gap is not None else None,'<=',1)])
        momentum=[compare(v[key],'>',0) for key in ('m5_hist_delta_to_side','m5_rsi_delta_to_side')]
        improved=True if True in momentum else None if None in momentum else False
        last_open=s*(q['last']-m['r']['ohlc']['open']) if q['last'] is not None else None
        flip=and3([common,compare(last_open,'>',0),compare(distance,'<=',1),improved])
        reclaim=v['m1_body_reclaim_atr5_to_side']+gap if v['m1_body_reclaim_atr5_to_side'] is not None and gap is not None else None
        signed_c=s*cmf if cmf is not None else None;signed_o=s*obv if obv is not None else None
        ft={}
        for name,a in [('main',.05),('zero',0.)]:
            ft[name]=and3([common,compare(signed_c,'>',a),compare(signed_o,'>',0),compare(v['m1_volume_relative_prior3'],'>=',1),
                compare(v['m30_ema21_delta_to_side'],'>',0),compare(v['m5_hist_to_side'],'>',0),compare(v['m5_hist_delta_to_side'],'>',0),
                compare(v['m1_body_ratio_to_side'],'>',0),compare(reclaim,'>',0),compare(gap,'>=',0),compare(distance,'>=',0),compare(distance,'<=',1)])
        sides[s]={'flip':flip,'ft':ft,'cmf':signed_c,'obv':signed_o}
    actions={}
    for name,a in [('main',.05),('zero',0.)]:
        actions[name]={}
        for s in (1,-1):
            opposite=and3([compare(sides[s]['cmf'],'<',-a),compare(sides[s]['obv'],'<',0)])
            actions[name][s]=(-s,'flip') if opposite is True and sides[-s]['flip'] is True else (0,'wait') if opposite is True else (s,'keep')
    return {'sides':sides,'actions':actions}


# ----------------------------------------
def check(core,f: tuple) -> int:
    """
    機能: 期待式と作者APIの主要pass/actionを照合し入力非改変を確認する。
    引数: core(module)、f(tuple)。返り値: int比較数。
    """
    before=copy.deepcopy(f);expected=oracle(f);actual=core.choose(f[0],f[1],NAMES,f[2],f[3]);assert f==before
    for s in (1,-1):
        assert actual['technical'][str(s)]['flip_confirmation']['pass'] is expected['sides'][s]['flip']
        for name in ('main','zero'):
            assert actual['technical'][str(s)]['FT'][name]['pass'] is expected['sides'][s]['ft'][name]
            a=actual['base_actions'][name][str(s)];assert (a['side'],a['action'])==expected['actions'][name][s]
    return 10


# ----------------------------------------
def main() -> None:
    """
    機能: 主要反例・鏡像・優先・運転順序を小型人工だけで独立確認する。
    引数: なし。返り値: None。自然量/採否/金融は読まない。
    """
    paths=[AUTHOR/name for name in ('logic155.py','選択する.py','人工検査.py','人工検査_運転.py')]
    paths.extend([ROOT/'work/153独立出生の入口/logic153.py',ROOT/'scripts/入口研究/固定特徴から可読条件を選択する.py'])
    before={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    core=load(paths[0],'author155_core_independent');runner=load(paths[1],'author155_runner_independent')
    cases=[fixture()]
    for kind in ('cmf_equal','raw_zero','quantity_unknown','common_false','distance_zero','distance_one','distance_over','gap_one','gap_over','momentum_unknown','flip_or','last_open_equal'):
        f=fixture();buy,sell,m,q=f
        if kind=='cmf_equal':q['cmf20']['current']['value']=.05
        elif kind=='raw_zero':q['obv']['15']['change']=0.
        elif kind=='quantity_unknown':q['cmf20']['current'].update(value=None,value_defined=False);m['q0'].update(quote_ok=False,normal_bbo=False)
        elif kind=='common_false':m['q0'].update(quote_ok=False,normal_bbo=False)
        elif kind.startswith('distance_'):buy[INDEX[KEYS[2]]]={'distance_zero':0.,'distance_one':1.,'distance_over':1.0001}[kind]
        elif kind.startswith('gap_'):buy[INDEX[KEYS[1]]]=1. if kind=='gap_one' else 1.0001
        elif kind=='momentum_unknown':buy[INDEX['m5_hist_delta_to_side']]=None
        else:
            q['cmf20']['current']['value']=-.2;q['obv']['15']['change']=-200.;m['q0']['last']=199. if kind=='flip_or' else 200.
            buy[INDEX[KEYS[1]]]=(m['q0']['last']-204)/8;sell[INDEX[KEYS[1]]]=-buy[INDEX[KEYS[1]]]
            sell[INDEX['m5_hist_delta_to_side']]=None;sell[INDEX['m5_rsi_delta_to_side']]=1.
        cases.append(f)
    count=sum(check(core,f) for f in cases)
    f=fixture();original=core.choose(f[0],f[1],NAMES,f[2],f[3]);mirror=copy.deepcopy(f);q=f[2]['q0'];p=f[2]['r']['ohlc']
    mirror[2]['q0'].update(last=500-q['last'],bid=500-q['ask'],ask=500-q['bid'])
    mirror[2]['r']['ohlc']={'open':500-p['open'],'high':500-p['low'],'low':500-p['high'],'close':500-p['close']}
    mirror[3]['cmf20']['current']['value']*=-1;mirror[3]['obv']['15']['change']*=-1
    reflected=core.choose(mirror[1],mirror[0],NAMES,mirror[2],mirror[3])
    for name in ('main','zero'):
        for s in (1,-1):assert reflected['base_actions'][name][str(-s)]['side']==-original['base_actions'][name][str(s)]['side']
    assert reflected['decision']['directions']['FT']==-original['decision']['directions']['FT']
    assert tuple(inspect.signature(core.choose).parameters)==('buy','sell','columns','measurement','quantity')
    sides={str(t):{'FT':{name:{'pass':True if t==1 else None} for name in ('main','zero')}} for t in (1,-1)}
    assert core.native_decision(sides)['directions']=={'FT':1,'FTZ':1}
    sides['-1']['FT']['main']['pass']=True
    assert core.native_decision(sides)['directions']['FT']==0 and core.native_decision(sides)['conflicts']['FT']

    # ----------------------------------------
    fixtures=load(paths[3],'author155_artificial_dto_only');d,c,meta,sessions,old,expected=fixtures.link_fixture()
    before_objects=copy.deepcopy((d,c,meta,old))
    helper=load(paths[-1],'fixed_linker155_independent')
    result=runner.connect(d,c,meta,sessions,old,helper,expected)
    selected={key:{r['case_id']:r for r in rows} for key,rows in result['政策'].items()}
    assert selected['FT']['新']['event_id']=='先'
    assert selected['N0']['新']['side']==-1 and selected['N0']['新']['origin']=='Q0'
    assert selected['NZ']['新']['side']==1
    for name in ('U0','UQ0','UFT','UZ'):assert (selected[name]['旧00']['side'],selected[name]['旧00']['stream'])==(-1,'original')
    assert selected['Q0']['新']['source_B152_ref']==old['政策']['B152'][0]
    assert (d,c,meta,old)==before_objects
    changed=copy.deepcopy(c);changed['rows'][-1].update(status='expired',q1={'ask':99999,'bid':1})
    runner.connect(d,changed,meta,sessions,old,helper,expected);assert (d,c,meta,old)==before_objects

    # ----------------------------------------
    tree=ast.parse(paths[1].read_text(encoding='utf-8'));main_node=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='main')
    calls=[x for x in ast.walk(main_node) if isinstance(x,ast.Call)]
    save_q0=next(x.lineno for x in calls if isinstance(x.func,ast.Name) and x.func.id=='save' and any(isinstance(y,ast.Constant) and y.value=='q0の判断.json' for y in ast.walk(x)))
    project=next(x.lineno for x in calls if isinstance(x.func,ast.Name) and x.func.id=='project')
    later_reads=[x.lineno for x in calls if isinstance(x.func,ast.Attribute) and x.func.attr=='read_ref' and any(isinstance(y,ast.Constant) and y.value in ('captures','metadata') for y in ast.walk(x))]
    old_read=next(x.lineno for x in calls if isinstance(x.func,ast.Name) and x.func.id=='connect')
    assert project<save_q0<min(later_reads)<old_read
    assert 'args.book=args.book.resolve();args.output_dir=args.output_dir.resolve()' in paths[1].read_text(encoding='utf-8')
    assert before=={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}
    result={'成功':True,'自然入力_新採否_金融読取':False,'独立条件人工':len(cases),'主要項目比較':count,
            '売買物理鏡像':True,'pure_APIにq1又は旧選択がない':True,'主要優先と非改変':True,
            'FT片側true反対unknown採用_両true待機':True,
            '運転AST順序':{'project':project,'q0保存':save_q0,'取得metadata読取':later_reads,'connect':old_read},
            '実行源とDTO依存SHA256':before,'全依存前後同体':True,
            '初回私有検査器補修':'人工のANDをfalse優先からRoot仕様の全required knownへ修正。作者Source変更なし、自然読取なし。',
            '範囲':'作者14人工の全再実行ではなく、主要未知/境界/鏡像/優先反例と順序だけを独立確認。fixtureはDTOのみ借用。'}
    (HERE/'準備の確認.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':main()
