"""155の符号/未知/量0/境界と仮定側の純actionを自然入力なしで確認する。"""
import copy
import inspect
import unittest
import logic155 as m

NAMES=sorted([*m.REQUIRED,*[f'人工追加{i:03}' for i in range(100-len(m.REQUIRED))]])
INDEX={name:i for i,name in enumerate(NAMES)}


def fixture() -> tuple:
    """
    機能: 買FT成立/売baseは量反対の同時仮定を持つ小型100Xを作る。
    引数: なし。返り値: tupleはbuy/sell/measurement/quantity。
    """
    q={'time':3721,'index':10,'source_line':11,'last':101.5,'bid':101,'ask':102,
        'last_known':True,'bid_known':True,'ask_known':True,'quote_ok':True,'normal_bbo':True}
    r={'id':'r','start':3600,'end':3660,'available_at':3720,'stamp':{'time':3721,'index':10,'line':11},
        'price_known':True,'volume_known':True,'closed':True,'missing':False,'ohlc':{'open':100,'high':103,'low':99,'close':101}}
    ranges={str(w):{'from':3600-w*60,'to':3600,'duration_seconds':w*60,'expected_count':w,'known':False,
        'high':None,'low':None,'high_first_ref':None,'low_first_ref':None,'range_points':None,'range_zero':None} for w in m.WINDOWS}
    measurement={'event_id':'人工','session':'人工','contract':'X','eligible':True,'q0':q,'r':r,'p':None,'prior_ranges':ranges}
    quantity={'event_id':'人工','eligible':True,'r_ref':'r','q0_stamp':{'time':3721,'index':10,'source_line':11},
        'obv':{'15':{'from':2760,'to':3660,'window_known':True,'change':100.,'ratio_defined':True,'ratio':.1}},
        'cmf20':{'current':{'from':2460,'to':3660,'window_known':True,'value_defined':True,'value':.1}}}
    vectors=[]
    for t in (1,-1):
        vector=[0.]*100
        for key in ('m30_ema21_delta_to_side','m5_hist_to_side','m5_hist_delta_to_side','m5_rsi_delta_to_side'):vector[INDEX[key]]=float(t)
        vector[INDEX['m5_atr']]=4.;vector[INDEX['m1_volume_relative_prior3']]=1.
        vector[INDEX['m1_body_ratio_to_side']]=t/4.;vector[INDEX['m1_body_reclaim_atr5_to_side']]=t*.5
        vector[INDEX['q0_last_minus_m1_close_atr5_to_side']]=t*.125
        vector[INDEX['q0_entry_minus_ema8_atr5_to_side']]=t*(q['ask' if t==1 else 'bid']-101)/4
        vectors.append(vector)
    return *vectors,measurement,quantity


def choose(f: tuple) -> dict:
    """
    機能: 人工4引数と固定100列を純chooseへ渡す。
    引数: f(tuple)。返り値: dict。
    """
    return m.choose(f[0],f[1],NAMES,f[2],f[3])


class Tests(unittest.TestCase):
    """自然の価格/量/取得/金融を開かない8主群。"""

    def test_FTとbase仮定とbuffer等号(self) -> None:
        """
        機能: 主.05厳密境界とa0を区別し両仮定base側を保存する。
        引数: self(Tests)。返り値: None。
        """
        f=fixture();out=choose(f);self.assertEqual(out['decision']['directions']['FT'],1)
        self.assertEqual(out['base_actions']['main']['-1']['action'],'flip')
        f[3]['cmf20']['current']['value']=.05;out=choose(f)
        self.assertEqual(out['decision']['directions'],{'FT':0,'FTZ':1})
        self.assertEqual(out['base_actions']['main']['-1']['action'],'keep')
        self.assertEqual(out['base_actions']['zero']['-1']['action'],'flip')

    def test_OBV0比未定義と量unknownKEEP(self) -> None:
        """
        機能: rawOBV既知0を未知にせず、CMF未知はbaseKEEP/native待機にする。
        引数: self(Tests)。返り値: None。
        """
        f=fixture();f[3]['obv']['15'].update(change=0,ratio=None,ratio_defined=False)
        out=choose(f);self.assertFalse(out['technical']['1']['FT']['main']['checks']['obv_support'])
        self.assertEqual(out['base_actions']['main']['-1']['action'],'keep')
        f[3]['cmf20']['current'].update(value=None,value_defined=False)
        out=choose(f);self.assertEqual(out['decision']['directions']['FT'],0)
        self.assertEqual(out['base_actions']['main']['1']['reason'],'quantity_unknown_keep')

    def test_反転確認ORとrOpen等号(self) -> None:
        """
        機能: r.Openの現在越えと勢い既知true優先OR、境界0を確認する。
        引数: self(Tests)。返り値: None。
        """
        f=fixture();f[3]['cmf20']['current']['value']=-.1;f[3]['obv']['15']['change']=-100
        self.assertEqual(choose(f)['base_actions']['main']['1']['action'],'wait')
        f[2]['q0']['last']=99;f[0][INDEX['q0_last_minus_m1_close_atr5_to_side']]=-.5;f[1][INDEX['q0_last_minus_m1_close_atr5_to_side']]=.5
        f[1][INDEX['m5_hist_delta_to_side']]=None;f[1][INDEX['m5_rsi_delta_to_side']]=1
        self.assertEqual(choose(f)['base_actions']['main']['1']['action'],'flip')
        f[2]['q0']['last']=100
        self.assertEqual(choose(f)['base_actions']['main']['1']['action'],'wait')

    def test_FTはRSI不要と価格等号(self) -> None:
        """
        機能: FTにRSI増分を足さず量1/LastClose0/EMA8距離0,1を含む。
        引数: self(Tests)。返り値: None。
        """
        f=fixture();f[0][INDEX['m5_rsi_delta_to_side']]=None;f[2]['q0']['last']=101;f[0][INDEX['q0_last_minus_m1_close_atr5_to_side']]=0
        for value in (0.,1.):
            f[0][INDEX['q0_entry_minus_ema8_atr5_to_side']]=value;self.assertEqual(choose(f)['decision']['directions']['FT'],1)
        for value in (-.001,1.001):
            f[0][INDEX['q0_entry_minus_ema8_atr5_to_side']]=value;self.assertEqual(choose(f)['decision']['directions']['FT'],0)

    def test_異常BBOでも非反対base維持(self) -> None:
        """
        機能: 共通品質不成立を旧政策へのKEEP分岐へ勝手に追加しない。
        引数: self(Tests)。返り値: None。
        """
        f=fixture();f[2]['q0'].update(quote_ok=False,normal_bbo=False)
        out=choose(f);self.assertEqual(out['decision']['directions']['FT'],0)
        self.assertEqual(out['base_actions']['main']['1']['action'],'keep')
        self.assertEqual(out['base_actions']['main']['-1']['action'],'wait')

    def test_片側unknownと同時反対待機(self) -> None:
        """
        機能: native方向統合の既知true優先と両true防御を確認する。
        引数: self(Tests)。返り値: None。
        """
        sides={str(t):{'FT':{b:{'pass':True if t==1 else None} for b in m.BUFFERS}} for t in (1,-1)}
        self.assertEqual(m.native_decision(sides)['directions']['FT'],1)
        sides['-1']['FT']['main']['pass']=True
        self.assertEqual(m.native_decision(sides)['directions']['FT'],0);self.assertTrue(m.native_decision(sides)['conflicts']['FT'])

    def test_鏡像非改変と未使用値非依存(self) -> None:
        """
        機能: 売買物理反射でaction方向を反転し、比や未使用量を採否へ混ぜない。
        引数: self(Tests)。返り値: None。
        """
        f=fixture();old=copy.deepcopy(f);expected=choose(f);self.assertEqual(f,old)
        mirrored=copy.deepcopy(f);q=f[2]['q0'];o=f[2]['r']['ohlc']
        mirrored[2]['q0'].update(last=220-q['last'],bid=220-q['ask'],ask=220-q['bid'])
        mirrored[2]['r']['ohlc']={'open':220-o['open'],'close':220-o['close'],'high':220-o['low'],'low':220-o['high']}
        mirrored[3]['cmf20']['current']['value']*=-1;mirrored[3]['obv']['15']['change']*=-1
        actual=m.choose(mirrored[1],mirrored[0],NAMES,mirrored[2],mirrored[3])
        self.assertEqual(actual['decision']['directions']['FT'],-expected['decision']['directions']['FT'])
        for s in (1,-1):self.assertEqual(actual['base_actions']['main'][str(-s)]['side'],-expected['base_actions']['main'][str(s)]['side'])
        f[3]['obv']['15'].update(ratio=None,ratio_defined=False)
        self.assertEqual(choose(f),expected)

    def test_未来時計と不正値とAPI(self) -> None:
        """
        機能: 異event/未来数量/boolを拒否しpureへ旧選択/q1を渡さない。
        引数: self(Tests)。返り値: None。
        """
        self.assertEqual(list(inspect.signature(m.choose).parameters),['buy','sell','columns','measurement','quantity'])
        for field,value in [('event_id','未来'),('q0_stamp',{'time':3722,'index':10,'line':11})]:
            f=fixture();f[3][field]=value
            with self.assertRaises(AssertionError):choose(f)
        f=fixture();f[3]['obv']['15']['change']=True
        with self.assertRaises(ValueError):choose(f)


if __name__=='__main__':
    unittest.main(verbosity=2)
