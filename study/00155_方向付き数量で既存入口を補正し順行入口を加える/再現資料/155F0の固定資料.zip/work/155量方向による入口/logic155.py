"""155は全q0の両側FTと仮定base側の維持/反転/待機を先に計算する。"""
from pathlib import Path
import importlib.util
import math

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('fixed153_logic_for155',ROOT/'work/153独立出生の入口/logic153.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
WINDOWS=prior.WINDOWS
stamp=prior.stamp
validate_measurement=prior.validate_measurement
BUFFERS={'main':.05,'zero':0.0}
REQUIRED=('m5_atr','q0_last_minus_m1_close_atr5_to_side','q0_entry_minus_ema8_atr5_to_side',
    'm1_volume_relative_prior3','m30_ema21_delta_to_side','m5_hist_to_side','m5_hist_delta_to_side',
    'm5_rsi_delta_to_side','m1_body_ratio_to_side','m1_body_reclaim_atr5_to_side')


def validate_quantity(measurement: dict,quantity: dict) -> tuple:
    """
    機能: 同q0/rの数量の既知性を確認し、採否用CMF値とrawOBV差だけを取り出す。
    引数: measurement/quantity(dict)。返り値: tuple[float|None,float|None]。
    """
    assert quantity['event_id']==measurement['event_id'] and quantity['r_ref']==measurement['r']['id']
    assert type(quantity['eligible']) is bool and quantity['eligible']==measurement['eligible']
    assert stamp(quantity['q0_stamp'])==stamp(measurement['q0'])
    end=measurement['r']['end'];obv=quantity['obv']['15'];cmf=quantity['cmf20']['current']
    assert obv['from']==end-15*60 and obv['to']==end
    assert cmf['from']==end-20*60 and cmf['to']==end
    assert type(obv['window_known']) is bool and type(cmf['window_known']) is bool and type(cmf['value_defined']) is bool
    raw=prior.number(obv['change']);value=prior.number(cmf['value'])
    if obv['window_known']:assert raw is not None
    else:assert raw is None
    if cmf['value_defined']:assert cmf['window_known'] and value is not None
    else:assert value is None
    # ratioが未定義でも、raw変化の既知0はそのまま採否の0として使う。
    return value if cmf['value_defined'] else None,raw if obv['window_known'] else None


def native_decision(sides: dict) -> dict:
    """
    機能: 各bufferの片側trueを採用し、反対unknownは維持・両trueは待機する。
    引数: sides(dict[str,dict])。返り値: dictはdirection/conflict/evidence。
    """
    directions={};conflicts={};evidence=[]
    for name,policy in [('main','FT'),('zero','FTZ')]:
        hits=[t for t in (1,-1) if sides[str(t)]['FT'][name]['pass'] is True]
        directions[policy]=hits[0] if len(hits)==1 else 0;conflicts[policy]=len(hits)>1
        for t in hits:evidence.append({'rule':policy,'signal_side':t,'order_side':t,
            'roles':['方向','勢い','量','構造','値幅'],'quantity_descriptions_are_one_role':True,'cmf_buffer':BUFFERS[name]})
    return {'directions':directions,'conflicts':conflicts,'evidence':evidence}


def choose(buy: list,sell: list,columns: list,measurement: dict,quantity: dict) -> dict:
    """
    機能: q0の100X/短期価格/数量だけからFTと各仮定base側actionを計算する。
    引数: buy/sell(list)、columns(list[str|dict])、measurement/quantity(dict)。
    返り値: dictはtechnical/base_actions/decision。旧選択/q1/ラベル引数を持たない。
    """
    validate_measurement(measurement);cmf,obv=validate_quantity(measurement,quantity)
    names=[c['name'] if isinstance(c,dict) else c for c in columns]
    assert len(names)==len(set(names))==len(buy)==len(sell)==100 and set(REQUIRED)<=set(names)
    index={name:i for i,name in enumerate(names)};q=measurement['q0'];r=measurement['r'];o=r['ohlc'] or {}
    last=prior.number(q['last']);spread=q['ask']-q['bid'] if q['normal_bbo'] else None;sides={}
    for t,vector in ((1,buy),(-1,sell)):
        v=prior.values(vector,index,REQUIRED);atr=v['m5_atr'];gap=v['q0_last_minus_m1_close_atr5_to_side']
        distance=v['q0_entry_minus_ema8_atr5_to_side'];c=t*cmf if cmf is not None else None;ob=t*obv if obv is not None else None
        reclaim=v['m1_body_reclaim_atr5_to_side']+gap if v['m1_body_reclaim_atr5_to_side'] is not None and gap is not None else None
        if reclaim is not None and not math.isfinite(reclaim):raise ValueError('現在実体回復overflow')
        last_r_open=t*(last-o['open']) if last is not None and o else None
        common=prior.gate({'eligible':measurement['eligible'],'normal_bbo':q['normal_bbo'],
            'spread_positive':prior.compare(spread,'>',0),'spread_max20':prior.compare(spread,'<=',20),
            'atr5_positive':prior.compare(atr,'>',0),'gap_abs_max1':prior.compare(abs(gap) if gap is not None else None,'<=',1)},
            {'atr5':atr,'spread':spread,'last_close_gap_atr5':gap})
        momentum=prior.logical_or([prior.compare(v['m5_hist_delta_to_side'],'>',0),prior.compare(v['m5_rsi_delta_to_side'],'>',0)])
        flip=prior.gate({'common':common['pass'],'last_beyond_r_open':prior.compare(last_r_open,'>',0),
            'entry_ema8_upper1':prior.compare(distance,'<=',1),'hist_or_rsi_improvement':momentum},
            {'last_minus_r_open_to_side':last_r_open,'entry_ema8_distance':distance,
             'hist_delta':v['m5_hist_delta_to_side'],'rsi_delta':v['m5_rsi_delta_to_side']})
        ft={}
        for name,a in BUFFERS.items():
            ft[name]=prior.gate({'common':common['pass'],'cmf_support':prior.compare(c,'>',a),'obv_support':prior.compare(ob,'>',0),
                'same_r_volume_at_least1':prior.compare(v['m1_volume_relative_prior3'],'>=',1),
                'ema21_delta30_positive':prior.compare(v['m30_ema21_delta_to_side'],'>',0),
                'hist_level_positive':prior.compare(v['m5_hist_to_side'],'>',0),'hist_delta_positive':prior.compare(v['m5_hist_delta_to_side'],'>',0),
                'r_body_positive':prior.compare(v['m1_body_ratio_to_side'],'>',0),'current_p_open_reclaim':prior.compare(reclaim,'>',0),
                'last_at_or_beyond_r_close':prior.compare(gap,'>=',0),
                'entry_ema8_lower0':prior.compare(distance,'>=',0),'entry_ema8_upper1':prior.compare(distance,'<=',1)},
                {'a':a,'CMF20_to_side':c,'OBV15_raw_change_to_side':ob,'current_p_open_reclaim':reclaim,
                 **v})
        sides[str(t)]={'common':common,'quantity':{'CMF20_to_side':c,'OBV15_raw_change_to_side':ob},
            'flip_confirmation':flip,'FT':ft}
    actions={name:{} for name in BUFFERS}
    for name,a in BUFFERS.items():
        for s in (1,-1):
            v=sides[str(s)]['quantity'];opposition=prior.gate({'cmf_strong_opposition':prior.compare(v['CMF20_to_side'],'<',-a),
                'obv_opposition':prior.compare(v['OBV15_raw_change_to_side'],'<',0)},dict(v,a=a))
            confirmed=sides[str(-s)]['flip_confirmation']['pass']
            if opposition['pass'] is True:
                target=-s if confirmed is True else 0
                action='flip' if target else 'wait';reason='strong_opposition_confirmed' if target else 'strong_opposition_confirmation_missing'
            else:target=s;action='keep';reason='quantity_unknown_keep' if not opposition['known'] else 'no_strong_opposition_keep'
            actions[name][str(s)]={'source_side':s,'side':target,'action':action,'reason':reason,
                'strong_opposition':opposition,'opposite_confirmation':confirmed,
                'unknown_keep_is_not_quantity_support':not opposition['known']}
    return {'technical':sides,'base_actions':actions,'decision':native_decision(sides)}
