"""Rootが通知した恒久数量入力の指紋だけを155bookへ束縛する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 入力/源をbufferで指紋化する。
    引数: path(Path)。返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def main() -> None:
    """
    機能: Root通知後に量をJSONparseせず全CRC/指紋確認しbook源を最終更新する。
    引数: CLI sha256/decoded-sha256(str)/execute-after-root-notice(bool)。返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--sha256',required=True);parser.add_argument('--decoded-sha256',required=True)
    parser.add_argument('--execute-after-root-notice',action='store_true');args=parser.parse_args();assert args.execute_after_root_notice
    path=HERE/'条件.json';book=json.loads(path.read_bytes());assert book['trial']==155 and book['quantity_input']['sha256'] is None
    quantity=ROOT/book['quantity_input']['path'];before=quantity.stat();assert sha(quantity)==args.sha256
    digest=hashlib.sha256();size=0
    with gzip.open(quantity,'rb') as stream:
        for block in iter(lambda:stream.read(1<<20),b''):digest.update(block);size+=len(block)
    assert digest.hexdigest()==args.decoded_sha256
    assert (before.st_size,before.st_mtime_ns)==(quantity.stat().st_size,quantity.stat().st_mtime_ns) and sha(quantity)==args.sha256
    book['quantity_input'].update(sha256=args.sha256,decoded_sha256=args.decoded_sha256,bytes=before.st_size,decoded_bytes=size)
    book['status']='実装準備完了・F0未固定・戦略自然未実行'
    for source in HERE.iterdir():
        if source.is_file() and source.suffix in ('.py','.md'):book['sources'][source.relative_to(ROOT).as_posix()]=sha(source)
    path.write_bytes((json.dumps(book,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'book_SHA256':sha(path),'数量JSONparse_戦略採否':False},ensure_ascii=False))


if __name__=='__main__':
    main()
