# 155：量方向補正と独立順行FTの実装

戦略の自然採否・容量・金融は未実行。Rootの[採用通知](../155採用条件のRoot通知.md)と[book](条件.json)が正本。新数量測定は別作業で生成/独立監査/恒久保存し、最終SHA束縛後、Root F0で初めてこの戦略を自然実行する。

## 純APIと時計の分離

`logic155.choose(buy,sell,columns,measurement,quantity)`。旧100列は変更せず買売別配列の各t側を読む。measurementは153の当時q0/r/p/先行域DTO、quantityは同eventの方向非依存量測定で、event/r/q0Stampを照合する。旧選択・q1・ラベル・教師・モデルは引数にしない。

- `technical[str(t)]`：共通品質、CMF/OBVのt側値、反転確認、`FT.main/zero`のknown/pass/false/unknown/原値。
- `base_actions.main/zero[str(s)]`：s=±1を仮定したkeep/flip/waitと量反対/新側確認を全q0で先保存。
- `decision`：FT/FTZの方向・同q0反対競合・根拠。片側trueと反対unknownはtrue側、両trueは待機。

Oは`obv['15'].window_known/change`による**raw OBV変化**。ratio/ratio_definedを資格へ使わず、比が未定義でもraw既知0は0としてstrict符号を満たさない。Cは`cmf20.current.value_defined/value`、分母0/欠測は未知。OBV5/30、前CMF/Δは正本へ記録するだけで主判定に使わない。CMF/OBV/相対量は同じ量の役割で独立票としない。

共通品質はeligible、正常q0 BBO、spread(0,20]、ATR5>0、absLastClose≤1ATR。FTはC_t>a/O_t>0/同r相対量≥1、EMA21増分30_t>0、Hist5水準/実増分_t>0、r実体/現在p.Open回復>0、Lastはr.Closeのt側又は同値、実側EMA8距離[0,1]。RSI増分をAND追加しない。

BaseはC_s<−aとO_s<0が両known trueのときだけ新t=−sの確認を求める。確認は共通品質、t(Last−r.Open)>0、実側EMA8距離≤1、Hist5Δ_t>0 OR RSI5Δ_t>0の三値OR。強い反対かつ確認true→flip、確認false/unknown→wait。量反対がfalse又はunknownなら旧base KEEP。共通品質をKEEP分岐へ追加しない。未知KEEPは量支持への0補完ではない。

## 後段接続と固定対照

`選択する.project`は全35339q0のFTと両仮定actionを完成し、`q0の判断.json`を排他保存する。その後だけcaptures/metaと旧154選択を読む。C1/B152/UB152/U154は全値copy保持。Q0はB152の最終sに一致する仮定actionを取り出し、元case/q0/旧側旧stream/元参照を保持、反転時は同caseのbuy/sell streamへ明示対応する。q1再資格判定はしない。

FT内の別q0同q1は既存helperの最初q0index→line→eventID。N0はQ0を先にしてFTを統合し、同q1後発aliasがcanonicalを取消/方向取直ししない。U0はC1を最優先。同様にUQ0/UFT、a=0のNZ/UZを比較する。`旧C1重複`はUQ0/UFT/U0/UZ別dict、`Q_FT重複`はN0/NZ別dict。FTZ/QZはa=0の再現用補助で金融外。

金融directはC1/B152/UB152/U154/Q0/UQ0/FT/UFT/N0/U0/NZ/UZ。C0/RC1/RQ0/RU0は後段金融が同case実逆から派生し、全16政策960比較。新予測/学習なし。C1全87、B152614、UB152697、U154213を保持する。

## 人工と実行

純8主＋運転6主。主/0境界、rawOBV0、CMF未知KEEP/native待機、反転三値OR、r.Open0、FTのRSI非要求、価格等号、鏡像、非改変、全数量先検査、同q1 Q優先/C1優先、元参照全値copy、未来q1非依存を確認する。main spyは判断保存前のcapture/meta/旧対照読取を拒否し、q1価格/status変更で後段件数が変わってもq0保存bytesは同体だった。自然容量をこの人工件数から推定しない。

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 `
  'work/155量方向による入口/選択する.py' `
  --book 'inputs/00155_方向付き数量の測定/条件.json' --book-sha256 '<最終SHA>' `
  --output-dir 'work/155量方向による入口の評価/入口選択' --execute-after-f0
```

Root F0前には実行しない。出力先は未作成、相対引数は絶対へ正規化する。gzip CRC/物理解凍SHA・前後stat/SHA、全場/全q0/量known/足refsを保持し、未知を分母から除かない。独立役はarchive130/Rootで、作者の本準備は自己確認として区別する。全73既使用・事後着想、旧量29/42-43/Force47-48は未達、新a=.05の有効性未確認。独立mini IFDと口座・必須追尾を区別する。
