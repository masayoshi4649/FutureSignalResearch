"""155戦略自然実行なしで純8/運転6人工と最終源指紋を確認して停止する。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys
import 選択する as runner

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 最終小源を物理指紋化する。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 数量束縛済みbookと全小源を検査し人工結果を新規票へ保存する。
    引数: なし。返り値: None。自然数量JSON/価格/旧選択/金融本文を読まない。
    """
    book_path=HERE/'条件.json';book=json.loads(book_path.read_bytes());runner.validate_book(book)
    paths=[ROOT/path for path in book['sources']]+[book_path]
    before={path:sha(path) for path in paths};assert all(before[ROOT/path]==h for path,h in book['sources'].items())
    for path in HERE.glob('*.py'):
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
            if isinstance(node,ast.FunctionDef):
                doc=ast.get_docstring(node);assert doc and '\n' in doc and all(key in doc for key in ('機能','引数','返り値'))
    results={}
    for name in ('人工検査.py','人工検査_運転.py'):
        result=subprocess.run([sys.executable,'-X','utf8',str(HERE/name)],capture_output=True,cwd=ROOT,
            env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'})
        stdout,stderr=result.stdout.decode('utf-8','strict'),result.stderr.decode('utf-8','strict')
        assert result.returncode==0 and '\ufffd' not in stdout+stderr
        results[name]={'終了値':result.returncode,'stdout':stdout,'stderr':stderr}
    assert before=={path:sha(path) for path in paths}
    ready=HERE/'準備の確認.json';stop=HERE/'停止.json';assert not ready.exists() and not stop.exists()
    proof={'成功':True,'試行':155,'戦略自然採否_容量_金融未実行':True,'自然数量_価格_旧選択の本文読取':False,
        '新モデル_教師_再予測_Raw_新CSV_追加2場':False,'純人工数':8,'運転人工数':6,'人工':results,
        'UTF8_strict_構文_複数行関数コメント':True,'源':{path.relative_to(ROOT).as_posix():h for path,h in before.items()},
        '数量入力は生成独立監査後の恒久SHAへ束縛_ここで再解析なし':book['quantity_input'],
        '主':'U0','主buffer':.05,'比較buffer':0,'政策数':16,'比較数':960,
        '全q0保存後だけ旧B152取得結合':True,'q1差替え後q0bytes同体_mainSpy成功':True,
        '未知KEEPとnative未知待機を区別':True,'rawOBV0をratio未知と区別':True,
        '既存152153154停止源変更':False,'独立者と作者自己確認を区別':True,'全源前後同体':True}
    ready.write_bytes((json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    stop.write_bytes((json.dumps({'成功':True,'試行':155,'編集停止':True,'自然売買未実行':True,'準備SHA256':sha(ready),
        'book_SHA256':sha(book_path),'源':proof['源']},ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'book_SHA256':sha(book_path),'準備SHA256':sha(ready),'停止SHA256':sha(stop)},ensure_ascii=False))


if __name__=='__main__':
    main()
