"""155数量の全q0先検査と、旧base参照を後段だけで結合する契約を人工確認する。"""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import copy
import importlib.util
import json
import sys
import tempfile
import unittest
import numpy as np
import 人工検査 as fixtures
import logic155 as core

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('runner155test',HERE/'選択する.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
helper=m.module(m.ROOT/'scripts/入口研究/固定特徴から可読条件を選択する.py','helper155test')


def joined_fixture() -> tuple:
    """
    機能: 同q0の価格/r/数量/short_refsと1場特徴を人工で作る。
    引数: なし。返り値: tupleは特徴/証拠/高安/数量。
    """
    buy,sell,d,quantity=fixtures.fixture();q=d['q0'];r=d['r']
    meta={'event_id':'人工','session':'人工','contract':'X','session_index':0,'q0_time':q['time'],'q0_index':q['index'],'q0_line':q['source_line']}
    features=SimpleNamespace(columns=fixtures.NAMES,buy_X=np.array([buy]),sell_X=np.array([sell]),q0_meta=[meta],
        scenes=[{'session':'人工','contract':'X','start':0,'end':10800,'force_close':10500}])
    quote={key:q[key] for key in ('time','index','source_line','last','bid','ask','quote_ok','normal_bbo')}
    short={key:copy.deepcopy(r[key]) for key in ('id','start','end','available_at','stamp','price_known','volume_known','closed')}
    short.update(session='人工',contract='X');witness={'人工':{'q0':quote,'short_refs':[short]}}
    high={'success':True,'schema':'prior_time_range_v1','windows_minutes':[15,30,60],
        'financial_labels_used':False,'strategy_selected':False,'selected_trade_count':None,'selected_trade_frequency':None,
        'sessions':['人工'],'scenes':[{'session':'人工','contract':'X','start':0,'continuous_end':10500,'bars':[r],
        'rows':[{'event_id':'人工','eligible':True,'q0':q,'r_ref':'r','slot_refs':['r'],'delivered_refs':['r'],'prior_ranges':d['prior_ranges']}]}]}
    quantities={'success':True,'schema':'directional_volume_v1','strategy_selected':False,'financial_labels_used':False,'current100X_changed':False,
        'sessions':['人工'],'obv_minutes':[5,15,30],'cmf_minutes':20,
        'scenes':[{'session':'人工','contract':'X','start':0,'continuous_end':10500,'rows':[quantity],
            'volume_refs':[{'id':'r','source147_bar_index':0,'volume_known':True,'volume':1}]}]}
    return features,witness,high,quantities


def link_fixture() -> tuple:
    """
    機能: 同q1先後native・後base優先・旧売C1優先を含む73場人工を作る。
    引数: なし。返り値: tupleはdecisions/captures/meta/sessions/old/期待件数。
    """
    sessions=[f'場{i:02}' for i in range(73)]
    descriptors=[{'case_id':f'旧{i:02}','session':sessions[min(i,72)],'contract':'X','original_side':-1 if i==0 else 1,
        'c1_reused':True,'buy_stream':'reverse' if i==0 else 'original','sell_stream':'original' if i==0 else 'reverse'} for i in range(87)]
    descriptors += [{'case_id':key,'session':sessions[0],'contract':'X','original_side':1,'c1_reused':False,'buy_stream':'original','sell_stream':'reverse'} for key in ('新','新2')]
    legacy=[{'case_id':d['case_id'],'session':d['session'],'side':d['original_side'],'stream':'original','event_id':None,'feature_ref':None,'origin':'C1'} for d in descriptors if d['c1_reused']]
    decisions=[];captures=[]
    for event,index,ft,case in [('先',1,1,'新'),('後',2,-1,'新'),('base',3,0,'新'),('旧反対',4,1,'旧00'),('別',5,1,'新2')]:
        actions={name:{str(s):{'source_side':s,'side':s,'action':'keep','reason':'人工保持'} for s in (1,-1)} for name in core.BUFFERS}
        if event=='base':
            actions['main']['1'].update(side=-1,action='flip');actions['zero']['1'].update(side=0,action='wait')
        row={'event_id':event,'session':sessions[0],'contract':'X','q0_time':100+index,'q0_index':index,'q0_line':index+1,'base_actions':actions,
            'decision':{'directions':{'FT':ft,'FTZ':ft,'NFT':ft},'conflicts':{'FT':False,'FTZ':False,'NFT':False},
                'evidence':[{'rule':name,'order_side':ft} for name in ('FT','FTZ') if ft]}}
        decisions.append(row);descriptor=next(d for d in descriptors if d['case_id']==case)
        captures.append({'event_id':event,'session':sessions[0],'contract':'X','q0':{'time':100+index,'index':index,'source_line':index+1},
            'status':'filled','case_id':case,'buy_stream':descriptor['buy_stream'],'sell_stream':descriptor['sell_stream']})
    b=[]
    for event,key,stream in [('base','新','original'),('旧反対','旧00','reverse')]:
        d=next(d for d in decisions if d['event_id']==event)
        b.append({**{k:d[k] for k in ('event_id','session','q0_time','q0_index','q0_line')},'case_id':key,'feature_ref':event,
            'side':1,'stream':stream,'origin':'B0','未知元欄':{'値':[None,1]}})
    old={'成功':True,'試行':154,'選択時の金融ラベル利用':False,'政策':{'C1':legacy,'B152':b,'UB152':copy.deepcopy(legacy),'U30':copy.deepcopy(legacy)}}
    return decisions,{'rows':captures},{'population148':{'cases':descriptors}},sessions,old,{'B152':2,'UB152':87,'U154':87,'C1':87}


class Tests(unittest.TestCase):
    """自然入力や155容量を使わない5主運転人工。"""

    def test_数量全先検査からprojectへ(self) -> None:
        """
        機能: 異q0/r/数量IDをchoose前に拒否し、同体時だけ全仮定を判定する。
        引数: self(Tests)。返り値: None。
        """
        f,w,h,q=joined_fixture();before=copy.deepcopy((w,h,q))
        with patch.object(core,'choose',wraps=core.choose) as choose:
            joined,quant=m.measurements(f,w,h,q,core,1);self.assertEqual(choose.call_count,0)
            rows=m.project(f,joined,quant,core);self.assertEqual(choose.call_count,1)
        self.assertEqual(rows[0]['decision']['directions']['FT'],1);self.assertEqual((w,h,q),before)
        for field in ('event_id','r_ref','q0_stamp'):
            bad=copy.deepcopy(q);value=bad['scenes'][0]['rows'][0]
            value[field]={'time':3722,'index':10,'source_line':11} if field=='q0_stamp' else '未来'
            with self.assertRaises(AssertionError):m.measurements(f,w,h,bad,core,1)

    def test_Q優先とC1優先とa0差(self) -> None:
        """
        機能: 後baseもQ優先、同Source後aliasは不採用、C1売保護、a0分離を確認する。
        引数: self(Tests)。返り値: None。
        """
        d,c,meta,s,old,expected=link_fixture();before=copy.deepcopy((d,c,meta,old))
        out=m.connect(d,c,meta,s,old,helper,expected)
        policies={name:{row['case_id']:row for row in rows} for name,rows in out['政策'].items()}
        self.assertEqual(policies['FT']['新']['event_id'],'先')
        self.assertEqual((policies['N0']['新']['side'],policies['N0']['新']['origin']),(-1,'Q0'))
        self.assertEqual(policies['NZ']['新']['side'],1)
        for name in ('U0','UQ0','UFT','UZ'):
            self.assertEqual((policies[name]['旧00']['side'],policies[name]['旧00']['stream']),(-1,'original'))
        self.assertTrue(out['Q_FT重複']['N0'][0]['opposite']);self.assertEqual(len(policies['U0']),89)
        self.assertEqual((d,c,meta,old),before)

    def test_全値旧参照と実逆stream(self) -> None:
        """
        機能: 旧B152/UB152/U154をcopyしflip元欄とq0時計を保持する。
        引数: self(Tests)。返り値: None。
        """
        d,c,meta,s,old,expected=link_fixture();out=m.connect(d,c,meta,s,old,helper,expected)
        for dest,src in [('B152','B152'),('UB152','UB152'),('U154','U30')]:self.assertEqual(out['政策'][dest],old['政策'][src])
        flipped=next(row for row in out['政策']['Q0'] if row['case_id']=='新')
        self.assertEqual((flipped['side'],flipped['stream'],flipped['source_selected_side'],flipped['source_selected_stream']),(-1,'reverse',1,'original'))
        self.assertEqual(flipped['source_B152_ref'],old['政策']['B152'][0]);self.assertEqual(flipped['q0_index'],3)
        out['政策']['B152'][0]['未知元欄']['値'].append(2);self.assertEqual(old['政策']['B152'][0]['未知元欄']['値'],[None,1])

    def test_q1変更で全q0純判断不変(self) -> None:
        """
        機能: pending後の価格/取得statusがpureやproject引数へ入らない境界を確認する。
        引数: self(Tests)。返り値: None。
        """
        f,w,h,q=joined_fixture();joined,quant=m.measurements(f,w,h,q,core,1)
        first=m.project(f,joined,quant,core)
        d,c,meta,s,old,expected=link_fixture();before=copy.deepcopy(d)
        original=m.connect(d,c,meta,s,old,helper,expected)
        changed=copy.deepcopy(c);changed['rows'][-1].update(status='expired',q1={'ask':99999,'bid':99998})
        after=m.connect(d,changed,meta,s,old,helper,expected)
        self.assertNotEqual(len(original['政策']['FT']),len(after['政策']['FT']))
        self.assertEqual(d,before);self.assertEqual(m.project(f,joined,quant,core),first)
        old['政策']['B152'][0]['q0_time']+=1
        with self.assertRaises(AssertionError):m.connect(d,c,meta,s,old,helper,expected)

    def test_mainは全判断保存より前に取得対照を読まない(self) -> None:
        """
        機能: 私有mock入出力で順序を検査し、q1差替え後もq0保存bytesを同体にする。
        引数: self(Tests)。返り値: None。実入力は読まず人工小ファイルだけを使う。
        """
        d,c,meta,s,old,expected=link_fixture();saved=[];reads=[];original_save=m.save
        with tempfile.TemporaryDirectory(dir=HERE) as temporary:
            root=Path(temporary).resolve();catalog=root/'inputs/00148_全1分入口母集団/100特徴の列定義.json'
            catalog.parent.mkdir(parents=True);catalog.write_text(json.dumps([{'name':n} for n in fixtures.NAMES]),encoding='utf-8')
            paths={name:root/(name+'.json') for name in ('features','fixed','captures','metadata','range','quantity','old','f1')}
            for path in paths.values():path.write_text('{}',encoding='utf-8')
            refs={name:{'path':str(paths[name]),'sha256':'0'*64,'decoded_sha256':'0'*64} for name in paths if name!='f1'}
            book={'sources':{},'features_source':{name:refs[name] for name in ('features','fixed','captures','metadata')},
                'range_input':refs['range'],'quantity_input':refs['quantity'],'buffers':{'main':.05,'zero':0},'catalog_definition_sha256':'0'*64,
                'fixed154_control':{'selection':refs['old'],'f1':{'path':str(paths['f1']),'sha256':'0'*64},'expected_counts':expected}}
            paths['f1'].write_text(json.dumps({'ファイル':{'work/154回帰環境の評価/入口選択/選択対応.json':'0'*64}}),encoding='utf-8')
            book_path=root/'book.json';book_path.write_text(json.dumps(book),encoding='utf-8')
            fake_features=SimpleNamespace(columns=fixtures.NAMES,scenes=[{'session':sid} for sid in s])
            current_capture=copy.deepcopy(c)

            def read(ref):
                """
                機能: 人工refへだけ値を返し、取得/旧対照読取前の判断保存をassertする。
                引数: ref(SimpleNamespace)。返り値: tuple[dict,dict]。
                """
                name=Path(ref.path).stem;reads.append(name)
                if name in ('captures','metadata','old'):self.assertIn('q0の判断.json',saved)
                value={'quantity':{'source_refs':{'source153':refs['range']}},'captures':current_capture,
                    'metadata':{**meta,'sessions':s},'old':old}.get(name,{})
                if name=='captures':value={**value,'sessions':s}
                return copy.deepcopy(value),{}

            def write(path,value):
                """
                機能: 実際の私有q0小JSON保存を行い、以後読取可の印を付ける。
                引数: path(Path)、value(dict)。返り値: None。
                """
                original_save(path,value);saved.append(path.name)

            fake_data=SimpleNamespace(FileRef=lambda path,*_:SimpleNamespace(path=path),read_ref=read,
                feature_dataset_from_objects=lambda *_:fake_features)

            def modules(path,name):
                """
                機能: 自然Sourceを再importせず人工データAPI/固定pure/helperだけ返す。
                引数: path(Path)、name(str)。返り値: object。
                """
                return fake_data if Path(path).name=='data151.py' else core if Path(path).name=='logic155.py' else helper

            bodies=[]
            for n in range(2):
                saved.clear();reads.clear();out=root/f'出力{n}'
                if n:current_capture['rows'][-1].update(status='expired',q1={'ask':99999,'bid':99998})
                argv=['選択する.py','--book',str(book_path),'--book-sha256','0'*64,'--output-dir',str(out),'--execute-after-f0']
                with patch.object(m,'ROOT',root),patch.object(m,'sha',return_value='0'*64),patch.object(m,'validate_book'),\
                    patch.object(m,'module',side_effect=modules),patch.object(m.shared,'witnesses',return_value={}),\
                    patch.object(m,'measurements',return_value=([],[])),patch.object(m,'project',return_value=copy.deepcopy(d)),\
                    patch.object(m,'save',side_effect=write),patch.object(sys,'argv',argv):m.main()
                self.assertEqual(reads[:4],['features','fixed','range','quantity'])
                self.assertEqual(reads[4:],['captures','metadata','old']);bodies.append((out/'q0の判断.json').read_bytes())
            self.assertEqual(bodies[0],bodies[1])

    def test_明示実行前は本文IOなし(self) -> None:
        """
        機能: F0旗なしでbook本文・価格入力へ到達しないことを確認する。
        引数: self(Tests)。返り値: None。
        """
        with patch.object(sys,'argv',['選択する.py','--book','不存在.json','--book-sha256','0'*64,'--output-dir','不存在出力']),patch.object(m,'sha',side_effect=RuntimeError('本文IO禁止')) as digest:
            with self.assertRaises(AssertionError):m.main()
            self.assertEqual(digest.call_count,0)


if __name__=='__main__':
    unittest.main(verbosity=2)
