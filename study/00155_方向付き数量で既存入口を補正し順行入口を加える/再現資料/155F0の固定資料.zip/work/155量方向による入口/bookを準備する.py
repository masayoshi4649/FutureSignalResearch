"""155採用通知の数値を固定し、数量inputの最終SHAだけを後で束縛するbookを作る。"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 小源の物理指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 旧bookの共有参照だけを再用し、155数式/未知分岐/優先を記録する。
    引数: なし。返り値: None。自然数量/採否/容量/金融は読まない。
    """
    previous=json.loads((ROOT/'work/154回帰環境の入口/条件.json').read_bytes())
    index=json.loads((ROOT/'study/00154_回帰で進行と往復を分けて短期回復から入る/保管索引.json').read_bytes())
    selection=next(row for row in index['154新生成3JSONを各1gzip保存'] if row['保存元'].endswith('/選択対応.json.gz'))
    book={'trial':155,'name':'方向付き数量で既存入口を補正し順行入口を加える','status':'数量入力SHA未束縛・F0実行不可',
        'parent_trial':148,'primary':'U0','buffers':{'main':.05,'zero':0},'buffer_after_results_swap':False,
        'financial_policies':['C0','C1','RC1','B152','UB152','U154','Q0','RQ0','UQ0','FT','UFT','N0','U0','RU0','NZ','UZ'],
        'feature_rows':35339,'session_count':73,'legacy_count':87,'catalog_count':100,
        'catalog_definition_sha256':previous['catalog_definition_sha256'],'features_source':previous['features_source'],
        'range_input':previous['range_input'],
        'quantity_input':{'path':'inputs/00155_方向付き数量の測定/方向付き数量の入力.json.gz','sha256':None,'decoded_sha256':None,'schema':'directional_volume_v1'},
        'quantity':{'obv_window_minutes':15,'obv_r_included':True,'obv_sign_previous_close_required':True,'obv_field':'change','obv_ratio_used':False,
            'known_zero_obv_is_known_zero':True,'cmf_window_minutes':20,'cmf_r_included':True,'cmf_field':'current.value',
            'cmf_defined_flag':'current.value_defined','cmf_denominator_zero_unknown':True,'OBV5_OBV30_previousCMF_delta_decision_used':False,
            'CMF_OBV_independent_roles':False},
        'common':{'eligible':True,'normal_q0_bbo':True,'spread_range':'(0,20]','atr5_strict_positive':True,'abs_last_close_atr5_max':1},
        'FT':{'all_required_known':True,'cmf_to_side_strict_above_buffer':True,'obv_raw_change_to_side_strict_positive':True,
            'same_r_volume_relative_prior3_at_least':1,'ema21_delta30_to_side_strict_positive':True,
            'hist5_level_and_real_delta_to_side_strict_positive':True,'rsi_delta_AND':False,'r_body_to_side_strict_positive':True,
            'live_p_open_reclaim_strict_positive':True,'last_at_or_beyond_r_close_inclusive':True,'ema8_distance_range':'[0,1]',
            'one_true_other_unknown_choose_true':True,'both_true_wait':True,'no_true_wait':True},
        'base':{'source_side_is_later_B152_final_side':True,'all_q0_two_assumed_source_sides_saved':True,
            'strong_opposition':'CMF20_to_s < -a AND rawOBV15change_to_s < 0、両known',
            'flip_confirmation_new_t':'common AND t*(Last0-r.Open)>0 AND entryEMA8_t<=1 AND (Hist5delta_t>0 OR RSI5delta_t>0)',
            'momentum_OR_three_valued_true_wins':True,'opposition_with_confirmation':'flip',
            'opposition_without_confirmation':'wait','unknown_or_nonopposition':'keep','unknown_keep_is_quantity_support':False},
        'linking':{'same_q1_priority':['C1','Q0','FT'],'earliest_q0_within_one_source':True,
            'same_q0_opposite_native_wait':True,'later_alias_cannot_cancel_canonical':True,'all_q0_saved_before_controls':True,
            'Q0_no_q1_requalification':True,'new_q0_qualification_uses_old_selection_or_label':False,
            'unions':{'UQ0':['C1','Q0'],'UFT':['C1','FT'],'N0':['Q0','FT'],'U0':['C1','N0'],'NZ':['QZ','FTZ'],'UZ':['C1','NZ']},
            'nonfinancial_aliases':['FTZ','QZ']},
        'fixed154_control':{'read_only_after_all_new_q0_saved':True,
            'selection':{'path':selection['保存元'],'sha256':selection['保存SHA256'],'decoded_sha256':selection['解凍SHA256']},
            'f1':{'path':'study/00154_回帰で進行と往復を分けて短期回復から入る/検査/F1入口選択後.json','sha256':'d3eb4ed12b2a62b46da3e0bc581e558f8a5a85514a0f56ac5bc4c6be12de942a'},
            'expected_counts':{'B152':614,'UB152':697,'U154':213,'C1':87},'copy_all_values_without_reselection':True},
        'no_model_or_teacher':True,'current100X_or_old_model_changed':False,
        'limits':['全73既使用・152三再診断後の着想','前48/後25は未知期でない','旧量29/42-43/Force47-48は未達',
            'a=.05は研究用バッファ、結果最適化でない','近接H60/同場依存・独立1mini IFD代用、実口座追尾でない'],
        'sources':{}}
    notice=ROOT/'work/155採用条件のRoot通知.md';assert sha(notice)=='5b6eedc71c27fae3ab02d51eb779762eda515e32115d403785cab7ae555a9171'
    files=[notice,ROOT/'work/153独立出生の入口/logic153.py',ROOT/'work/153独立出生の入口/選択する.py',
        ROOT/'work/151過去場判別/data151.py',ROOT/'scripts/入口研究/固定特徴から可読条件を選択する.py',
        HERE/'logic155.py',HERE/'選択する.py']
    book['sources']={path.relative_to(ROOT).as_posix():sha(path) for path in files}
    path=HERE/'条件.json';assert not path.exists()
    path.write_bytes((json.dumps(book,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'book_SHA256':sha(path),'quantity_SHA未束縛で自然実行不可':True},ensure_ascii=False))


if __name__=='__main__':
    main()
