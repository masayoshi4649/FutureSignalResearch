"""155全q0仮定action/FTを先保存し、その後だけB152と取得対応へ結合する。"""
from pathlib import Path
import argparse
import copy
import gc
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fixed153_driver_for155',ROOT/'work/153独立出生の入口/選択する.py')
shared=importlib.util.module_from_spec(spec);spec.loader.exec_module(shared)
sha=shared.sha
save=shared.save
module=shared.module
POLICIES=['C0','C1','RC1','B152','UB152','U154','Q0','RQ0','UQ0','FT','UFT','N0','U0','RU0','NZ','UZ']


def validate_book(book: dict) -> None:
    """
    機能: Root採用の符号/未知分岐/優先/全政策を入力本文の前に照合する。
    引数: book(dict)。返り値: None。数量入力の最終SHA未束縛なら拒否する。
    """
    assert book['trial']==155 and book['parent_trial']==148 and book['primary']=='U0'
    assert (book['feature_rows'],book['session_count'],book['legacy_count'],book['catalog_count'])==(35339,73,87,100)
    assert book['buffers']=={'main':.05,'zero':0} and book['financial_policies']==POLICIES
    assert book['quantity']['obv_window_minutes']==15 and book['quantity']['obv_field']=='change' and not book['quantity']['obv_ratio_used']
    assert book['quantity']['cmf_window_minutes']==20 and book['quantity']['cmf_field']=='current.value'
    assert book['base']['unknown_or_nonopposition']=='keep' and book['base']['opposition_without_confirmation']=='wait'
    assert book['FT']['ema8_distance_range']=='[0,1]' and book['FT']['rsi_delta_AND'] is False
    assert book['linking']['same_q1_priority']==['C1','Q0','FT'] and book['linking']['all_q0_saved_before_controls']
    assert book['fixed154_control']['expected_counts']=={'B152':614,'UB152':697,'U154':213,'C1':87}
    assert book['no_model_or_teacher']
    for ref in [book['quantity_input'],book['range_input'],*book['features_source'].values()]:
        assert len(ref['sha256'])==len(ref['decoded_sha256'])==64


def measurements(features: object,witness: dict,high: dict,quantity: dict,core: object,expected_rows: int=40544) -> tuple:
    """
    機能: 全40544の数量窓を153同q0/r/量knownへ結び、適格特徴順へ射影する。
    引数: features(object)、witness/high/quantity(dict)、core(object)、expected_rows(int)。返り値: tuple[list,list]。
    """
    joined=shared.measurements(features,witness,high,core,expected_rows)
    assert quantity['success'] and quantity['schema']=='directional_volume_v1'
    assert not quantity['strategy_selected'] and not quantity['financial_labels_used'] and not quantity['current100X_changed']
    assert quantity['sessions']==high['sessions'] and len(quantity['scenes'])==len(high['scenes'])
    assert quantity['obv_minutes']==[5,15,30] and quantity['cmf_minutes']==20
    eligible={};seen=set();total=0
    for original,measured in zip(high['scenes'],quantity['scenes']):
        assert all(original[k]==measured[k] for k in ('session','contract','start','continuous_end'))
        assert len(original['rows'])==len(measured['rows']) and len(original['bars'])==len(measured['volume_refs'])
        bars={b['id']:b for b in original['bars']}
        for i,(bar,volume) in enumerate(zip(original['bars'],measured['volume_refs'])):
            assert volume['id']==bar['id'] and volume['source147_bar_index']==i and volume['volume_known']==bar['volume_known']
            if volume['volume_known']:assert type(volume['volume']) in (int,float) and core.prior.number(volume['volume'])>=0
            else:assert volume['volume'] is None
        for row,value in zip(original['rows'],measured['rows']):
            assert row['event_id'] not in seen;seen.add(row['event_id']);total+=1
            assert all(row[k]==value[k] for k in ('event_id','eligible','r_ref'))
            assert core.stamp(row['q0'])==core.stamp(value['q0_stamp'])
            dto={'event_id':row['event_id'],'eligible':row['eligible'],'q0':row['q0'],'r':bars[row['r_ref']]}
            core.validate_quantity(dto,value)
            if row['eligible']:eligible[row['event_id']]=value
    assert total==expected_rows and len(eligible)==len(features.q0_meta)
    result=[]
    for meta,dto in zip(features.q0_meta,joined):
        dto['event_id']=meta['event_id'];value=eligible[meta['event_id']];core.validate_quantity(dto,value);result.append(value)
    return joined,result


def project(features: object,joined: list,quantities: list,core: object) -> list:
    """
    機能: q1/旧選択なしで全q0両側action/FTを完成させる。
    引数: features(object)、joined/quantities(list)、core(object)。返り値: list[dict]。
    """
    assert len(joined)==len(quantities)==len(features.q0_meta);rows=[]
    for i,(meta,dto,quantity) in enumerate(zip(features.q0_meta,joined,quantities)):
        chosen=core.choose(features.buy_X[i].tolist(),features.sell_X[i].tolist(),list(features.columns),dto,quantity)
        decision=chosen['decision'];decision['directions']['NFT']=decision['directions']['FT'];decision['conflicts']['NFT']=decision['conflicts']['FT']
        rows.append({**meta,'r_ref':dto['r']['id'],**chosen})
        if (i+1)%5000==0:print(json.dumps({'判定済q0':i+1,'全q0':len(joined)},ensure_ascii=False),flush=True)
    return rows


def merge_priority(first: list,second: list,origin: str) -> tuple:
    """
    機能: 同物理caseはfirstを完全保持し、後発別方向でも取消/取直ししない。
    引数: first/second(list[dict])、origin(str)。返り値: tuple[list, list]は統合と重複記録。
    """
    merged={row['case_id']:copy.deepcopy(row) for row in first};assert len(merged)==len(first);seen=set();collisions=[]
    for row in second:
        key=row['case_id'];assert key not in seen;seen.add(key)
        if key in merged:
            collisions.append({'case_id':key,'priority_side':merged[key]['side'],'new_side':row['side'],
                'opposite':merged[key]['side']!=row['side'],'priority_origin':merged[key]['origin'],'later_origin':row['origin']})
        else:merged[key]=copy.deepcopy(row)
    return list(merged.values()),collisions


def connect(decisions: list,captures: dict,metadata: dict,sessions: list,old154: dict,helper: object,expected: dict=None) -> dict:
    """
    機能: 全q0保存後だけ固定B152へ仮定actionを当てQ優先/C1優先で統合する。
    引数: decisions(list)、captures/metadata/old154(dict)、sessions(list)、helper(object)、expected(dict|None)。返り値: dict。
    """
    expected=expected or {'B152':614,'UB152':697,'U154':213,'C1':87}
    setting={'rules':[{'id':'FT'},{'id':'FTZ'}],'union_rules':['FT'],'union_id':'NFT','legacy_id':'C1','main_id':'UFT',
        'session_count':len(sessions),'legacy_count':expected['C1']}
    out=helper.connect(decisions,captures['rows'],metadata['population148']['cases'],sessions,setting)
    out['政策'].pop('NFT');out['候補と取得'].pop('NFT',None);overlap={'UFT':out.pop('旧C1重複')}
    assert old154['成功'] and old154['試行']==154 and old154['選択時の金融ラベル利用'] is False
    legacy={row['case_id']:row for row in out['政策']['C1']};oldlegacy={row['case_id']:row for row in old154['政策']['C1']}
    assert legacy==oldlegacy and len(legacy)==expected['C1']
    for dest,source in [('B152','B152'),('UB152','UB152'),('U154','U30')]:
        assert len(old154['政策'][source])==expected[dest];out['政策'][dest]=copy.deepcopy(old154['政策'][source])
    events={row['event_id']:row for row in decisions};descriptors={row['case_id']:row for row in metadata['population148']['cases']}
    assert len(events)==len(decisions)
    qrows={};qaudit={}
    for variant,name in [('main','Q0'),('zero','QZ')]:
        selected=[];audit=[]
        for base in out['政策']['B152']:
            row=events[base['event_id']];descriptor=descriptors[base['case_id']];s=base['side']
            assert type(s) is int and s in (-1,1) and base['feature_ref']==row['event_id']
            assert all(base[k]==row[k] for k in ('session','q0_time','q0_index','q0_line'))
            assert descriptor['session']==row['session'] and descriptor['contract']==row['contract']
            assert base['stream']==descriptor['buy_stream' if s==1 else 'sell_stream']
            action=copy.deepcopy(row['base_actions'][variant][str(s)]);t=action['side']
            assert action['source_side']==s and t in (-s,0,s)
            audit.append({'case_id':base['case_id'],'event_id':row['event_id'],'source_side':s,'source_stream':base['stream'],**action})
            if not t:continue
            reference=copy.deepcopy(base);reference.update(side=t,stream=descriptor['buy_stream' if t==1 else 'sell_stream'],origin=name,
                source_policy='B152',source_selected_side=s,source_selected_stream=base['stream'],source_B152_ref=copy.deepcopy(base),
                q0_action=action,cmf_buffer=.05 if variant=='main' else 0.,
                evidence=[{'rule':name,'signal_side':s,'order_side':t,'roles':['量','構造','勢い','値幅'],
                    'action':action['action'],'quantity_descriptions_are_one_role':True}],成立ID=[name])
            selected.append(reference)
        assert len({row['case_id'] for row in selected})==len(selected)
        qrows[name]=selected;qaudit[name]=audit
    out['政策'].update(qrows);collisions={}
    out['政策']['N0'],collisions['N0']=merge_priority(qrows['Q0'],out['政策']['FT'],'N0')
    out['政策']['NZ'],collisions['NZ']=merge_priority(qrows['QZ'],out['政策']['FTZ'],'NZ')
    for dest,new in [('UQ0','Q0'),('U0','N0'),('UZ','NZ')]:
        out['政策'][dest],overlap[dest]=merge_priority(out['政策']['C1'],out['政策'][new],dest)
    out['旧C1重複']=overlap;out['Q_FT重複']=collisions;out['B152へのq0action']=qaudit
    out['候補と取得'].update({name:{'fixed_B152':len(qaudit[name]),'keep':sum(a['action']=='keep' for a in qaudit[name]),
        'flip':sum(a['action']=='flip' for a in qaudit[name]),'wait':sum(a['action']=='wait' for a in qaudit[name]),'filled':len(qrows[name])} for name in ('Q0','QZ')})
    out['非金融補助alias']=['FTZ','QZ'];out['固定154対照全値保持']={'成功':True,**expected,'旧選択をpureへ未使用':True}
    return out


def main() -> None:
    """
    機能: Root F0後だけ特徴/数量先判定→排他保存→固定B152/取得結合を実行する。
    引数: CLI book(Path)/book-sha256(str)/output-dir(Path)/execute-after-f0(bool)。返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--book',type=Path,required=True);parser.add_argument('--book-sha256',required=True)
    parser.add_argument('--output-dir',type=Path,required=True);parser.add_argument('--execute-after-f0',action='store_true');args=parser.parse_args()
    args.book=args.book.resolve();args.output_dir=args.output_dir.resolve()
    assert args.execute_after_f0 and not args.output_dir.exists() and sha(args.book)==args.book_sha256
    book=json.loads(args.book.read_bytes());validate_book(book)
    declared={ROOT/path:h for path,h in book['sources'].items()};declared[args.book]=args.book_sha256
    inputs=[*book['features_source'].values(),book['range_input'],book['quantity_input'],book['fixed154_control']['selection'],book['fixed154_control']['f1']]
    declared.update({ROOT/ref['path']:ref['sha256'] for ref in inputs})
    catalog=ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json';declared[catalog]=book['catalog_definition_sha256']
    assert all(sha(path)==h for path,h in declared.items());before={str(path):[path.stat().st_size,path.stat().st_mtime_ns] for path in declared}
    data=module(ROOT/'work/151過去場判別/data151.py','features_only155');core=module(HERE/'logic155.py','logic155run')
    helper=module(ROOT/'scripts/入口研究/固定特徴から可読条件を選択する.py','helper155')
    refs={key:data.FileRef(ROOT/ref['path'],ref['sha256'],ref['decoded_sha256']) for key,ref in book['features_source'].items()}
    raw,features_evidence=data.read_ref(refs['features']);fixed,fixed_evidence=data.read_ref(refs['fixed'])
    features=data.feature_dataset_from_objects(raw,fixed,73,35339);witness=shared.witnesses(raw)
    assert list(features.columns)==[c['name'] for c in json.loads(catalog.read_bytes())];del raw,fixed;gc.collect()
    ref=book['range_input'];high,high_evidence=data.read_ref(data.FileRef(ROOT/ref['path'],ref['sha256'],ref['decoded_sha256']))
    ref=book['quantity_input'];quantity,quantity_evidence=data.read_ref(data.FileRef(ROOT/ref['path'],ref['sha256'],ref['decoded_sha256']))
    assert quantity['source_refs']['source153']=={k:book['range_input'][k] for k in ('path','sha256','decoded_sha256')}
    joined,quantities=measurements(features,witness,high,quantity,core);del high,quantity,witness;gc.collect()
    decisions=project(features,joined,quantities,core);del joined,quantities;gc.collect()
    assert all(sha(path)==h for path,h in declared.items());args.output_dir.mkdir(parents=True)
    save(args.output_dir/'q0の判断.json',{'成功':True,'試行':155,'主政策':'U0','全q0判断数':len(decisions),'buffers':book['buffers'],
        '全q0仮定base両側actionとnativeFTを先保存':True,'旧選択_q1_ラベル_モデルを新判断へ使用':False,'rows':decisions})
    # ----------------------------------------
    # 全q0の保存が成功した後だけ、取得対応と固定B152/旧対照を読む。
    captures,_=data.read_ref(refs['captures']);metadata,_=data.read_ref(refs['metadata']);sessions=[s['session'] for s in features.scenes]
    assert captures['sessions']==metadata['sessions']==sessions
    control=book['fixed154_control'];freeze=json.loads((ROOT/control['f1']['path']).read_bytes());ref=control['selection']
    assert freeze['ファイル']['work/154回帰環境の評価/入口選択/選択対応.json']==ref['decoded_sha256']
    old154,_=data.read_ref(data.FileRef(ROOT/ref['path'],ref['sha256'],ref['decoded_sha256']))
    result=connect(decisions,captures,metadata,sessions,old154,helper,control['expected_counts'])
    save(args.output_dir/'選択対応.json',{'成功':True,'試行':155,'主政策':'U0','book_sha256':args.book_sha256,
        'quantity_input_decoded_sha256':book['quantity_input']['decoded_sha256'],**result})
    assert all(sha(path)==h for path,h in declared.items()) and before=={str(path):[path.stat().st_size,path.stat().st_mtime_ns] for path in declared}
    save(args.output_dir/'選択の確認.json',{'成功':True,'試行':155,'新学習又は金融又はRaw':False,
        '全新q0両側action保存後だけ取得_旧対照読取':True,'入力':{path.relative_to(ROOT).as_posix():h for path,h in declared.items()},
        '全入力前後SHA_stat同体':True,'特徴読取証跡':features_evidence,'固定入力読取証跡':fixed_evidence,
        '高安読取証跡':high_evidence,'数量読取証跡':quantity_evidence,
        '政策別取得数':{name:len(rows) for name,rows in result['政策'].items()},
        '出力':{path.name:sha(path) for path in args.output_dir.iterdir() if path.is_file()}})
    print(json.dumps({'成功':True,'政策別取得数':{name:len(rows) for name,rows in result['政策'].items()}},ensure_ascii=False))


if __name__=='__main__':
    main()
