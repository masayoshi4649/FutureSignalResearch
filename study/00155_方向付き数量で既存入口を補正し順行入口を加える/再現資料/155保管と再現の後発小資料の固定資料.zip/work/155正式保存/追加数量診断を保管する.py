"""155のF2後に作られた数量水準/変化診断2点だけを後発保存する。"""
from pathlib import Path
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: Root停止通知の追加2点を明示manifestで保存し、F2へ遡及しない。
    引数: なし。返り値: None。Source採否・正式3MD・主/閾値を変更しない。
    """
    spec=importlib.util.spec_from_file_location('archive155_volume_late',HERE/'保存する.py')
    base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);lib=base.library();formal=ROOT/base.FORMAL_REL
    source=ROOT/'work/155の数量水準と変化を分ける.py';result=ROOT/'work/155量方向による入口の評価/数量の水準と変化の診断.json'
    expected_source='74f440fa6e0a21e16f13aaf475f650e3a692ae40ce6782abc6baf743c1eb013a'
    expected_result='6e58191b8a9eb6977c1b558364777a1d16815131de04be48302101d55b4dd99f'
    assert lib.sha(source)==expected_source and lib.sha(result)==expected_result
    index_path=formal/'保管索引.json';index=json.loads(index_path.read_bytes());key='F2後の数量水準と変化の診断';assert key not in index
    record=lib.save_file(result,formal/'根拠/数量の水準と変化の診断.json.gz',expected_result,True);lib.check_reference(record,expected_result)
    existing=base.references(index);existing[record['復元先']]=record
    files={source.relative_to(ROOT).as_posix():expected_source,result.relative_to(ROOT).as_posix():expected_result}
    index[key]={'Root停止通知の2点':files,'正本':[record],'全源復元参照':lib.resolve(files,key,existing),
        'F2前固定だったとの遡及主張':False,'Source_主_閾値又は政策の変更':False,
        '固定B152614を32群_全前後元実逆_66加法照合はRoot正本へ記録':True}
    index_path.write_bytes(lib.json_bytes(index))
    for name in ('閲覧資料.md','再現手順.md'):
        path=formal/name;body=path.read_bytes()
        path.write_bytes(body+('\n\n## F2後の追加事後診断\n\n[数量の水準と変化の診断](根拠/数量の水準と変化の診断.json.gz)は、'
            '固定B152614をCMF水準×同q0で知得済みCMFΔ、OBV15×OBV5の32群へ分けたRootの全前後元/実逆診断。'
            'Rootの66加法照合が成功した。F2後の新Source/結果として保存し、F2へ遡及して固定済みと主張しない。'
            '水準/変化は資金流入そのものの観測や新政策採用を意味せず、主a=.05/閾値は不変。\n').encode('utf-8'))
    print(json.dumps({'成功':True,'追加小点':2,'索引SHA256':lib.sha(index_path)},ensure_ascii=False))


if __name__=='__main__':
    main()
