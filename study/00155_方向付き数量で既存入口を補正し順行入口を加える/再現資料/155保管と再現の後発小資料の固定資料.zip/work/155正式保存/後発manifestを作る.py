"""Root完了通知に基づき155自然監査とRoot小診断の最小manifestを作る。"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 停止小資料を物理指紋化する。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 完了通知/自然監査停止/診断Source/JSONの明示集合だけをmanifestへ記録する。
    引数: なし。返り値: None。結果の再選別や正式3MD編集を行わない。
    """
    runtime=ROOT/'work/155量方向による入口の評価';notice_path=runtime/'Rootの完了通知.json'
    assert sha(notice_path)=='7e84c22f86d3a63eec6013b84787156a9ea3c1795c5c82c5cc56f6032f332baa'
    notice=json.loads(notice_path.read_bytes());assert notice['成功'] and notice['Root金融_独立_CSV終了通知']
    stop_path=ROOT/'work/155自然選択の独立監査/停止の確認.json'
    assert sha(stop_path)=='982dca6b9df4c1d492223ee6f4dc2496dd789738f32d6a3b679a37e819f89fc2'
    stop=json.loads(stop_path.read_bytes());files={ROOT/info['path']:info['SHA256'] for info in stop['最小保存対象']}
    files[stop_path]=sha(stop_path)
    destinations={'work/155自然選択の独立監査/自然確認/監査の確認.json':'検査/自然選択の独立監査.json',
        stop_path.relative_to(ROOT).as_posix():'検査/自然監査の停止.json'}
    for key,name in [('診断','維持反転待機の診断'),('出生診断','FTの出生診断')]:
        ref=notice['refs'][key];path=ROOT/ref['path'];assert sha(path)==ref['sha256'];files[path]=ref['sha256']
        destinations[path.relative_to(ROOT).as_posix()]='根拠/'+name+'.json'
    f2=json.loads((runtime/'F2金融前.json').read_bytes())
    for name in ('155の維持反転待機を診断する.py','155の順行入口の絞り込みを集計する.py'):
        path=ROOT/'work'/name;rel=path.relative_to(ROOT).as_posix();assert sha(path)==f2['ファイル'][rel];files[path]=sha(path)
    files[notice_path]=sha(notice_path)
    destinations[notice_path.relative_to(ROOT).as_posix()]='検査/Rootの完了通知.json'
    entries=[]
    for path,expected in files.items():
        assert sha(path)==expected
        row={'source':path.relative_to(ROOT).as_posix(),'sha256':expected}
        if row['source'] in destinations:row['正式相対path']=destinations[row['source']]
        entries.append(row)
    payload={'試行':155,'Root停止通知後':True,'区分':'自然独立監査とRootの事後診断','小源':entries,
        'Root2診断SourceはF2で既固定_JSONは各生成時点どおり':True,
        '全35339q0_9268149末端':True,'自然監査の初回NFT由来差は同F1期待表記だけ補修':True,
        'Source又は選択再生成なし':True,'新政策又は閾値の採用なし':True,
        'Root視認支援画像は完了通知と索引から参照_画像再コピーなし':notice['視認支援画像']}
    out=HERE/'後発保存manifest.json';assert not out.exists();out.write_bytes((json.dumps(payload,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'小源数':len(entries),'manifest_SHA256':sha(out)},ensure_ascii=False))


if __name__=='__main__':
    main()
