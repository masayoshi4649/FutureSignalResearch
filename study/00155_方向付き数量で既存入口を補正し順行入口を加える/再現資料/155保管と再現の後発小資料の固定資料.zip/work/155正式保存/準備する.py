"""155保存器の準備だけを人工確認し、自然出力/金融/正式3MDを開かない。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 保存Sourceの物理指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 3人工・全構文/関数コメント/源前後同体を確認して準備票を保存する。
    引数: なし。返り値: None。自然採否/金融の保存は実行しない。
    """
    paths=[p for p in HERE.iterdir() if p.is_file() and p.suffix in ('.py','.md')]
    paths += [ROOT/'work/151正式保存/保存部品.py',ROOT/'work/154正式保存/保存する.py',ROOT/'work/154正式保存/人工検査.py',
        ROOT/'work/154正式保存/保存選択から再集計する.py']
    before={path:sha(path) for path in paths}
    for path in HERE.glob('*.py'):
        for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
            if isinstance(node,ast.FunctionDef):
                doc=ast.get_docstring(node);assert doc and '\n' in doc and all(key in doc for key in ('機能','引数','返り値'))
    result=subprocess.run([sys.executable,'-X','utf8',str(HERE/'人工検査.py')],capture_output=True,cwd=ROOT,
        env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'})
    stdout,stderr=result.stdout.decode('utf-8','strict'),result.stderr.decode('utf-8','strict');assert result.returncode==0 and '\ufffd' not in stdout+stderr
    assert before=={path:sha(path) for path in paths}
    proof={'成功':True,'試行':155,'用途':'正式保存器の人工準備','自然155採否_容量_金融_新量本文読取':False,
        'F0_F1_F2又は正式3MDの自然読取_保存実行':False,'人工数':3,'UTF8_strict_構文_関数コメント':True,
        '新3JSON各1gzip_共有147148152153154量入力非複写':True,'正式3MD編集担当':False,
        '自然実行にはRoot完了通知と明示flagが必要':True,'源':[{'path':p.relative_to(ROOT).as_posix(),'sha256':h,'bytes':p.stat().st_size} for p,h in before.items()],
        '全源前後同体':True,'人工':{'終了値':result.returncode,'stdout':stdout,'stderr':stderr}}
    out=HERE/'準備の確認.json';assert not out.exists()
    out.write_bytes((json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'準備SHA256':sha(out),'Source':{p.name:h for p,h in before.items() if p.parent==HERE}},ensure_ascii=False))


if __name__=='__main__':
    main()
