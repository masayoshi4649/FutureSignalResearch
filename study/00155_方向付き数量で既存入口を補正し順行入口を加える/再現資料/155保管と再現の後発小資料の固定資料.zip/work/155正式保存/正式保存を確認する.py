"""155全恒久参照と文書不変・保存再現を確認し、保存担当の最終票を作る。"""
from pathlib import Path
import argparse
import gzip
import importlib.util
import json
import re
from urllib.parse import unquote

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def catalog(text: str) -> list[str]:
    """
    機能: 設定本表の57手法9尺度行だけを抽出する。
    引数: text(str)。返り値: list[str]。
    """
    return [line for line in text.splitlines() if re.match(r'^\|\s+[A-Z]\d{2}\s+\|',line) and len(line.split('|'))==13]


def main() -> None:
    """
    機能: 全資料停止後にF0prefix/513/源復元/3gzip/960再現/リンクを確認して保存停止する。
    引数: CLI documents-stopped/root-additional-stopped(bool)。返り値: None。正式3MDは編集しない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--documents-stopped',action='store_true');parser.add_argument('--root-additional-stopped',action='store_true');args=parser.parse_args()
    assert args.documents_stopped and args.root_additional_stopped
    spec=importlib.util.spec_from_file_location('archive155_final',HERE/'保存する.py')
    base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);lib=base.library();formal=ROOT/base.FORMAL_REL
    stop_path=ROOT/'work/155結果文書/停止.json';assert lib.sha(stop_path)=='d5fed9027eb6596861a764ebedc5a540901963c95546758f21dd9ee75a1a64f7'
    stopped=json.loads(stop_path.read_bytes());assert stopped['成功'] and stopped['編集停止']
    docs=[formal/name for name in ('README.md','条件.md','設定と結果.md')];doc_hashes={p.name:lib.sha(p) for p in docs}
    assert doc_hashes==stopped['正式3MD']
    index_path=formal/'保管索引.json';index=json.loads(index_path.read_bytes());existing=base.references(index)
    assert all(key in index for key in ('自然独立監査とRootの事後診断','F2後の数量水準と変化の診断','追加FTと未知量の事後診断','別担当の結果文書停止源'))
    source=HERE/'保存選択から再集計する.py';stored=formal/'再現資料/保存選択から再集計する.py'
    assert source.read_bytes()==stored.read_bytes()
    record={'保存元':stored.relative_to(ROOT).as_posix(),'復元先':source.relative_to(ROOT).as_posix(),'形式':'同体',
        '保存SHA256':lib.sha(stored),'解凍SHA256':lib.sha(source),'保存bytes':stored.stat().st_size,'解凍bytes':source.stat().st_size}
    existing[record['復元先']]=record;index['保存再集計Source']=record
    files={p.relative_to(ROOT).as_posix():lib.sha(p) for p in HERE.iterdir() if p.is_file() and p.suffix in ('.py','.md','.json') and p.name!='停止の確認.json'}
    key='保管と再現の後発小資料';assert key not in index
    index[key]=lib.resolve(files,key,existing)
    index['段階']='F0/F1/F2、新3gzip、金融/CSV/自然監査、Root前後発診断、別担当結果文書源、保存960再現を保管して最終停止。'
    index_path.write_bytes(lib.json_bytes(index))
    # ----------------------------------------
    # 現在文書を事前SHAへ当てず、実行前原本を恒久snapshotから確認する。
    snapshot=json.loads(gzip.decompress((formal/'検査/F0実行前文書.json.gz').read_bytes()))
    originals={Path(row['path']).name:row['本文'].encode('utf-8') for row in snapshot['文書']}
    for name in ('条件.md','設定と結果.md'):assert (formal/name).read_bytes().startswith(originals[name])
    rows=catalog(docs[2].read_text(encoding='utf-8'));assert rows==catalog(originals['設定と結果.md'].decode('utf-8')) and len(rows)==57
    assert len({line.split('|')[1].strip() for line in rows})==57 and all(len(line.split('|')[3:-1])==9 for line in rows)
    intro=docs[0].read_text(encoding='utf-8').split('\n\n')[1];assert '実行済み' in intro and '主U0' in intro and '未達' in intro
    summary=formal/'成果物/集計.json';assert lib.sha(summary)=='6ce08c28ba7dda7fc4bb587ca30c908f24a6e4fdd3819584f5dac5d408de35ed'
    data=json.loads(summary.read_bytes());assert data['主政策']=='U0' and data['主CMFバッファ']==.05 and data['比較CMFバッファ']==0
    assert data['主評価']=={'全場最低1':True,'到達済70%':False,'全時間毎時1以上':False,'三目標共同':False}
    restored={};unique={};stable={};checked=set()
    for stage,description in index['固定段階'].items():
        frozen=json.loads((ROOT/description['原文']['保存元']).read_bytes());refs=base.references(description['全源復元参照'])
        restored[stage]=len(frozen['ファイル'])
        for relative,expected in frozen['ファイル'].items():
            if (relative,expected) not in checked:lib.check_reference(refs[relative],expected);checked.add((relative,expected))
            unique[relative]=expected
            if not relative.startswith(formal.relative_to(ROOT).as_posix()+'/'):
                assert lib.sha(ROOT/relative)==expected,relative;stable[relative]=expected
    assert restored=={'F0':37,'F1':41,'F2':74}
    for item in index['155新生成3JSONを各1gzip保存']+index['金融とCSV証跡']:lib.check_reference(item,item['解凍SHA256'])
    late_keys=('自然独立監査とRootの事後診断','F2後の数量水準と変化の診断','追加FTと未知量の事後診断','別担当の結果文書停止源','保管と再現の後発小資料')
    for label in late_keys:
        value=index[label];refs=base.references(value.get('全源復元参照',value))
        for relative,item in refs.items():lib.check_reference(item,item.get('解凍SHA256',item.get('sha256')))
    replay_path=formal/'検査/保存観測からの再現確認.json';replay=json.loads(replay_path.read_bytes())
    assert replay['成功'] and replay['比較数']==960 and replay['正本と三表bytes再現']
    with gzip.open(formal/'成果物/CSV用の表.json.gz','rt',encoding='utf-8') as stream:tables=json.load(stream)['tables']
    assert [(len(t['rows']),len(t['headers'])) for t in tables]==[(960,34),(526,47),(73,68)]
    for item in index['CSV正本']:assert lib.sha(ROOT/item['path'])==item['sha256']
    notice=json.loads((formal/'検査/Rootの完了通知.json').read_bytes());assert notice['RootCSV支援画像視認済み']
    for relative,expected in notice['視認支援画像'].items():assert lib.sha(ROOT/relative)==expected
    input_dir=ROOT/'inputs/00155_方向付き数量の測定';input_readme=input_dir/'README.md'
    assert {p.name for p in input_dir.glob('*.json.gz')}=={'方向付き数量の入力.json.gz','q0の判断.json.gz','選択対応.json.gz','選択の確認.json.gz'}
    mutation=json.loads((HERE/'入力README追記の確認.json').read_bytes());import hashlib
    prefix=input_readme.read_bytes().split('\n\n## 155新生成3JSON'.encode('utf-8'),1)[0]
    assert hashlib.sha256(prefix).hexdigest()==mutation['追記前SHA256']
    links=0
    for path in [*docs,formal/'閲覧資料.md',formal/'再現手順.md',input_readme,*sorted((formal/'根拠').glob('*.md'))]:
        for target in re.findall(r'\]\(([^)]+)\)',path.read_text(encoding='utf-8')):
            if '://' in target or target.startswith('#'):continue
            local=unquote(target.strip('<>').split('#',1)[0]);assert (path.parent/local).exists(),(path,target)
            links+=1
    for name in ('README.md','study/README.md','docs/README.md','docs/議論/README.md'):
        assert '00155_方向付き数量で既存入口を補正し順行入口を加える/README.md' in (ROOT/name).read_text(encoding='utf-8')
    assert doc_hashes=={p.name:lib.sha(p) for p in docs} and all(lib.sha(ROOT/rel)==expected for rel,expected in stable.items())
    final={'成功':True,'編集停止':True,'試行':155,'保存担当の正式3MD編集':False,'別担当文書停止SHA256':lib.sha(stop_path),
        '正式3MD':doc_hashes,'条件設定F0全prefix':True,'V7':{'手法':57,'尺度':9,'セル':513,'F0設定行全字同体':True},
        '主a_閾値_政策交換':False,'主U0は全73参加_率と頻度未達':True,'全ローカルリンク実在':links,
        '全固定源復元件数':restored,'全固定源unique':len(unique),'現在停止源前後同体':True,
        '新3JSON各1gzip_CRC_解凍SHA同体':True,'共有147148152153154量入力の再コピー':False,
        '保存選択から960正本typed三表bytes再現':True,'workなしでも恒久ZIP_gzip_索引_入力と環境から再現到達':True,
        'Root完了通知_画像3視認_960独立_CSV62326と算術は分離':True,'F2後追加数量診断は遡及固定しない':True,
        '保管索引SHA256':lib.sha(index_path),'保存確認SourceSHA256':lib.sha(Path(__file__))}
    target=formal/'検査/正式保存の最終確認.json';lib.write_new(target,lib.json_bytes(final))
    stop={**final,'正式保存最終票SHA256':lib.sha(target),'保存Source':files}
    lib.write_new(HERE/'停止の確認.json',lib.json_bytes(stop))
    print(json.dumps({'成功':True,'最終票SHA256':lib.sha(target),'索引SHA256':lib.sha(index_path),
        '停止SHA256':lib.sha(HERE/'停止の確認.json'),'リンク':links},ensure_ascii=False))


if __name__=='__main__':
    main()
