"""Root結果通知後だけ155金融/CSVの明示保存jobを作る。"""
from pathlib import Path
import argparse
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 通知済み成果物の物理指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 正本/typed表の通知SHAと成功を確認し、明示jobだけをworkへ作る。
    引数: CLI summary-sha256/table-sha256(str)、execute-after-root-notice(bool)。返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--summary-sha256',required=True);parser.add_argument('--table-sha256',required=True)
    parser.add_argument('--execute-after-root-notice',action='store_true');args=parser.parse_args()
    if not args.execute_after_root_notice:parser.error('Root完了通知後だけ金融成果物を読む')
    runtime=ROOT/'work/155量方向による入口の評価';notice_path=runtime/'Rootの完了通知.json'
    assert sha(notice_path)=='7e84c22f86d3a63eec6013b84787156a9ea3c1795c5c82c5cc56f6032f332baa'
    notice=json.loads(notice_path.read_bytes());assert notice['成功'] and notice['Root金融_独立_CSV終了通知']
    finance=(ROOT/notice['refs']['金融正本']['path']).parent
    output=ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/155_方向付き数量の補正'
    assert sha(finance/'集計.json')==args.summary_sha256 and sha(finance/'CSV用の表.json')==args.table_sha256
    summary=json.loads((finance/'集計.json').read_bytes());assert summary['成功'] and summary['試行']==155 and summary['主政策']=='U0'
    entries=[]
    for source,destination,mode in [(finance/'集計.json','成果物/集計.json','同体'),
        (finance/'CSV用の表.json','成果物/CSV用の表.json.gz','gzip'),(finance/'集計完了.json','成果物/集計完了.json','同体'),
        (runtime/'金融独立検算.json','検査/金融独立検算.json','同体'),(runtime/'CSV独立再読.json','検査/CSV独立再読.json','同体'),
        (output/'CSVの確認.json','検査/CSV作成の確認.json','同体'),
        (notice_path,'検査/Rootの完了通知.json','同体')]:
        entries.append({'source':source.relative_to(ROOT).as_posix(),'sha256':sha(source),'正式相対path':destination,'形式':mode})
    job={'試行':155,'Root結果通知後':True,'区分':'金融とCSV証跡','保存':entries}
    target=HERE/'金融保存job.json';assert not target.exists()
    target.write_bytes((json.dumps(job,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'job_SHA256':sha(target)},ensure_ascii=False))


if __name__=='__main__':
    main()
