"""155保存再集計の証拠とRoot検査/診断への恒久リンクを案内へ追補する。"""
from pathlib import Path
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 正本bytes再現票/環境/検査/Root診断を保存し3MDを変更せず案内する。
    引数: なし。返り値: None。新金融/選択/Sourceの再計算を行わない。
    """
    spec=importlib.util.spec_from_file_location('archive155_replay_done',HERE/'保存する.py')
    base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);lib=base.library();formal=ROOT/base.FORMAL_REL
    source=HERE/'保存選択の再集計/保存観測からの再現確認.json';proof=json.loads(source.read_bytes())
    assert proof['成功'] and proof['比較数']==960 and proof['正本と三表bytes再現']
    record=lib.save_file(source,formal/'検査/保存観測からの再現確認.json',lib.sha(source));lib.check_reference(record,lib.sha(source))
    index_path=formal/'保管索引.json';index=json.loads(index_path.read_bytes())
    index['保存選択からの再集計確認']={'正本とtyped三表bytes再現':True,'新選択_新Raw走査':False,'票':record}
    index['Root完了時の画像視認情報']={'完了通知':'検査/Rootの完了通知.json','Root視認済み':True,'新画像複写':False,
        'CSV独立全セル':62326,'支援画像':3}
    index['再現環境']={'Python':'3.14.3','NumPy':'2.5.4','新CatBoostモデル又は再学習':False,
        'venvは保存対象でなく作業環境に再作成':True}
    index_path.write_bytes(lib.json_bytes(index))
    source_text='''

## 恒久の検査・Root小診断

[F0原本](検査/F0入口選択前.json)、[F1原本](検査/F1入口選択後.json)、[F2原本](検査/F2金融前.json)、[Root完了通知と画像視認情報](検査/Rootの完了通知.json)。CSV全62,326セルの独立再読と3画像Root視認を、金融算術から分けて記録する。

[自然選択の独立全件監査](検査/自然選択の独立監査.json)は35,339q0/9,268,149末端を確認した。初回はUFTの内部NFT由来を期待側でFTとした表記差で停止し、期待由来だけ補正して同じF1を再監査した。Source・選択・F1を再生成していない。監査Source/初回小票/停止票は保管索引の「自然独立監査とRootの事後診断」から復元できる。

[維持/反転/待機の診断](根拠/維持反転待機の診断.json)は固定B152の4分岐を分け、[FTの出生診断](根拠/FTの出生診断.json)は単条件と固定順の通過会計を分けた。通過減少は順序依存で指標単独の因果ではなく、結果から新規則や主交換を採用していない。両診断SourceはF2で既固定、各JSONは保存時点を索引で区別する。

[保存観測からの再現確認](検査/保存観測からの再現確認.json)は960比較とtyped三表の全bytes一致。共有147/148/152/153/154/数量入力を再コピーせず再現した。
'''
    for name in ('閲覧資料.md','再現手順.md'):
        path=formal/name;body=path.read_bytes();assert '## 恒久の検査・Root小診断' not in body.decode('utf-8')
        path.write_bytes(body+source_text.encode('utf-8'))
    path=formal/'再現手順.md';body=path.read_bytes()
    environment='''

## workを失った別作業コピーでの環境

記録環境はPython 3.14.3/NumPy 2.5.4。venvやモデルを新たな再現資源として複写していない。一般のPythonから `python -m venv work/複合テクニカル学習環境` を作り、必要なら同環境へ `python -m pip install numpy==2.5.4` で特徴射影依存だけを用意する。155はCatBoostの学習/予測を呼ばない。

Source/停止人工/固定票は保管索引が指す恒久ZIP/gzipから、不足する元相対work pathだけへ復元する。金融再現CLIはそのうち必要な53源を自動復元する。残る戦略再選択・独立監査のSourceも同じ索引から到達可能で、入力はinputs/studyの保存実体を使う。記録されたWindows絶対pathが必要な箇所は同じ研究ルートを用意し、既存不一致源を上書き又は暗黙に書換えない。実行前3MDはsnapshotから復元し、現在の結果文書を事前SHAへ当てない。
'''
    path.write_bytes(body+environment.encode('utf-8'))
    out=HERE/'保存再現案内の確認.json';assert not out.exists()
    out.write_bytes(lib.json_bytes({'成功':True,'正本typed全bytes再現':True,'Root画像視認情報の保存':True,
        'work以外の恒久参照到達を案内':True,'正式3MD変更':False,'再現票SHA256':lib.sha(source)}))
    print(json.dumps({'成功':True,'再現票SHA256':lib.sha(source),'索引SHA256':lib.sha(index_path)},ensure_ascii=False))


if __name__=='__main__':
    main()
