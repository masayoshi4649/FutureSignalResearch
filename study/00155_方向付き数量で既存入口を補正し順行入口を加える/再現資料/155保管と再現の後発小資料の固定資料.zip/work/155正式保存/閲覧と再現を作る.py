"""Root完了通知後だけ155の閲覧/再現と保存再集計源を実在化する。"""
from pathlib import Path
import argparse
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 通知正本の主値だけを引用し、3MDを編集せずCSV/再現/索引を案内する。
    引数: CLI summary-sha256(str)/execute-after-root-notice(bool)。返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--summary-sha256',required=True)
    parser.add_argument('--execute-after-root-notice',action='store_true');args=parser.parse_args()
    if not args.execute_after_root_notice:parser.error('Root全完了通知後だけ閲覧資料を作成する')
    spec=importlib.util.spec_from_file_location('archive155_guides',HERE/'保存する.py')
    base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);lib=base.library()
    formal=ROOT/base.FORMAL_REL;summary=formal/'成果物/集計.json';assert lib.sha(summary)==args.summary_sha256
    data=json.loads(summary.read_bytes());assert data['成功'] and data['試行']==155 and data['主政策']=='U0'
    index_path=formal/'保管索引.json';index=json.loads(index_path.read_bytes());assert 'F2' in index['固定段階']
    output=ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/155_方向付き数量の補正'
    csv=sorted(output.glob('*.csv'));images=sorted((output/'支援画像').glob('*.png'))
    assert len(csv)==len(images)==3
    value=data['集計']['all']['U0']['BBO']['3600']['125'];rate=value['resolved_rate'];frequency=data['頻度']['all']['U0']['全時間取得毎時']
    rate_text='未定義' if rate is None else f'{rate*100:.4f}%'
    output_rel='../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/155_方向付き数量の補正'
    viewer=f'''# 155のCSVを見る

まず[全セッションCSV]({output_rel}/全セッション.csv)。全73場と主U0/N0/C1の利益・損失・差引・IFD未知・累計を残す。未知が一度累積したら全件確定累計差引はnullのままで、既知小計と区別する。

[入口別CSV]({output_rel}/入口別診断.csv)は主の同q1元/実逆、[比較CSV]({output_rel}/正逆比較.csv)は16政策960比較。主はall/U0/BBO/H60±125、CMFバッファa=.05。a=0のUZや単独枝へ結果後交換しない。旧C1保護、Q0の維持/反転/待機、全q0からのFT独立出生を分ける。

主は{value['entries']}取得、{value['forward']}順/{value['adverse']}逆/{value['neither']}未/{value['censored']}不足、到達済率{rate_text}、全時間平均{frequency:.6f}回/時。利益/損失/差引は[金融正本](成果物/集計.json)と正式[README](README.md)でIFD未知込みの分母と一緒に読む。独立mini1枚100円/pt・往復77円+C5追加1000円、入口IFD代用で口座利益保護ではない。

[CSV作成票](検査/CSV作成の確認.json)・[独立再読](検査/CSV独立再読.json)・[別金融算術](検査/金融独立検算.json)・[再現手順](再現手順.md)は別の検査。支援画像3点はRoot確認の資料として索引に参照し、新xlsxは作らない。正式3MDは別担当がF0原文を保持して結果追記する。
'''
    replay='''# 155の保存資料から再現する

[保管索引](保管索引.json)に元path/物理/解凍SHAを残す。F0/F1/F2は[実行前原文](検査/F0実行前文書.json.gz)と分離する。結果追記済みの3MDを実行前指紋へ当てず、F0の採用条件/設定済み57行513セルを使用する。

[155恒久入力](../../inputs/00155_方向付き数量の測定/README.md)の数量測定/最終bookは既保存を共有し、今回新3JSONだけ各1gzipで追加した。147/148/152/153/154の大入力/観測/旧モデルは再コピーしない。小Source/独立人工はF0/F1/F2の新ZIP又は既存共有ZIPから元の相対構造で復元する。現在の同pathが存在しSHA不一致なら上書きしない。

全35339q0のFTと仮定base両側actionを先に保存してからだけ、旧B152/capture/metaを読む。量不明/非反対KEEPと、強い反対時の反転確認不成立WAITを分ける。FTは必要条件unknownで成立させない。同q1の優先はC1→Q0→FT、同Source内は最初q0。CMF/OBVは同じ量の役割で独立票にしない。

## 保存選択と共有観測から960比較

```powershell
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 `
  'study/00155_方向付き数量で既存入口を補正し順行入口を加える/再現資料/保存選択から再集計する.py' `
  --output-dir 'work/155再現用の新規出力'
```

不足する小型work源・固定F1/F2・選択対応を保存実体から復元し、共有148の4stream観測と凍結算術で再集計する。再選択・新モデル・Raw走査を行わず、集計/typed三表の全bytesを正本へ照合する。Root別141算術の960比較、CSV全セルの独立再読、自然選択全件監査は別票として保存する。

量29/42-43/Force47-48の旧失敗、全73既使用・事後着想、近接H60/同場依存、実受信時計/真の出来高を認定していない点を残す。未来の利益保護や実mini/口座保有制約は未検証。事後原因は次の問いであり、固定155の条件へ採用しない。
'''
    lib.write_new(formal/'閲覧資料.md',viewer.encode('utf-8'));lib.write_new(formal/'再現手順.md',replay.encode('utf-8'))
    source=HERE/'保存選択から再集計する.py';lib.save_file(source,formal/'再現資料/保存選択から再集計する.py',lib.sha(source))
    index['CSV正本']=[{'path':p.relative_to(ROOT).as_posix(),'sha256':lib.sha(p),'bytes':p.stat().st_size} for p in csv]
    index['Root視認用の支援画像']=[{'path':p.relative_to(ROOT).as_posix(),'sha256':lib.sha(p)} for p in images]
    index['閲覧と再現案内']={'正式3MD編集':False,'主':'U0','主buffer':.05,'比較buffer':0,'新xlsx生成':False}
    index_path.write_bytes(lib.json_bytes(index))
    print(json.dumps({'成功':True,'正式3MD不変更':True,'閲覧_再現案内':True},ensure_ascii=False))


if __name__=='__main__':
    main()
