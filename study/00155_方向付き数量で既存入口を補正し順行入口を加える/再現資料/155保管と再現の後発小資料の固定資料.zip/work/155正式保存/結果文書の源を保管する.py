"""別担当が停止した155結果文書9小点を保存し、正式3MDへ書き込まない。"""
from pathlib import Path
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 文書作者停止票の指紋を確認し、更新器/人工/票を恒久ZIPと検査へ保存する。
    引数: なし。返り値: None。別担当の正式3MD/目次を変更しない。
    """
    spec=importlib.util.spec_from_file_location('archive155_documents',HERE/'保存する.py')
    base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);lib=base.library();formal=ROOT/base.FORMAL_REL
    folder=ROOT/'work/155結果文書';stop_path=folder/'停止.json'
    expected='d5fed9027eb6596861a764ebedc5a540901963c95546758f21dd9ee75a1a64f7'
    assert lib.sha(stop_path)==expected;stop=json.loads(stop_path.read_bytes());assert stop['成功'] and stop['編集停止']
    assert all(lib.sha(formal/name)==h for name,h in stop['正式3MD'].items())
    files={folder/name:h for name,h in stop['源'].items()}
    files.update({folder/'最終確認.json':stop['最終確認SHA256'],folder/'結果反映の確認.json':stop['結果反映SHA256'],
        folder/'準備の確認.json':lib.sha(folder/'準備の確認.json'),stop_path:expected})
    assert len(files)==9 and all(lib.sha(path)==h for path,h in files.items())
    index_path=formal/'保管索引.json';index=json.loads(index_path.read_bytes());key='別担当の結果文書停止源';assert key not in index
    existing=base.references(index);saved=[]
    for source,dest in [(folder/'最終確認.json','検査/結果文書の最終確認.json'),
        (folder/'結果反映の確認.json','検査/結果文書の反映確認.json'),(stop_path,'検査/結果文書の停止.json')]:
        record=lib.save_file(source,formal/dest,files[source]);lib.check_reference(record,files[source])
        existing[record['復元先']]=record;saved.append(record)
    index[key]={'作者停止SHA256':expected,'正本':saved,'全源復元参照':lib.resolve(
        {p.relative_to(ROOT).as_posix():h for p,h in files.items()},key,existing),'保存担当による正式3MD編集':False}
    index_path.write_bytes(lib.json_bytes(index))
    print(json.dumps({'成功':True,'作者小点':9,'正式3MD不変更':True,'索引SHA256':lib.sha(index_path)},ensure_ascii=False))


if __name__=='__main__':
    main()
