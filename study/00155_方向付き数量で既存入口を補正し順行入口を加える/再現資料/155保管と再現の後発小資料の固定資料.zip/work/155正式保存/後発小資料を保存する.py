"""155監査/事後根拠の明示manifestだけを後発Sourceとして保存する。"""
from pathlib import Path
import argparse
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: manifestのSourceをZIP/同体/gzipへ保存し、元F0へ遡及しない索引を足す。
    引数: CLI manifest(Path)/sha256(str)/execute-after-root-notice(bool)。返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--manifest',required=True,type=Path);parser.add_argument('--sha256',required=True)
    parser.add_argument('--execute-after-root-notice',action='store_true');args=parser.parse_args()
    if not args.execute_after_root_notice:parser.error('Rootの停止/完了通知後だけ後発資料を読む')
    spec=importlib.util.spec_from_file_location('archive155_late',HERE/'保存する.py')
    base=importlib.util.module_from_spec(spec);spec.loader.exec_module(base);lib=base.library()
    assert lib.sha(args.manifest)==args.sha256;manifest=json.loads(args.manifest.read_bytes())
    assert manifest['試行']==155 and manifest['Root停止通知後'] is True
    formal=ROOT/base.FORMAL_REL;index_path=formal/'保管索引.json';index=json.loads(index_path.read_bytes())
    key=manifest['区分'];assert key not in index
    existing=base.references(index);saved=[];files={}
    for row in manifest['小源']:
        source=lib.path_of(row['source']);expected=row['sha256'];assert lib.sha(source)==expected and source.stat().st_size<3_000_000
        files[source.relative_to(ROOT).as_posix()]=expected
        if row.get('正式相対path'):
            target=(formal/row['正式相対path']).resolve();assert target.is_relative_to(formal.resolve())
            if target.exists():
                compressed=row.get('gzip',False)
                if compressed:
                    import gzip
                    import hashlib
                    assert hashlib.sha256(gzip.decompress(target.read_bytes())).hexdigest()==expected
                else:assert lib.sha(target)==expected
                record={'復元先':source.relative_to(ROOT).as_posix(),'保存元':target.relative_to(ROOT).as_posix(),
                    '形式':'gzip' if compressed else '同体','保存SHA256':lib.sha(target),'解凍SHA256':expected,
                    '保存bytes':target.stat().st_size,'解凍bytes':source.stat().st_size}
            else:record=lib.save_file(source,target,expected,row.get('gzip',False))
            lib.check_reference(record,expected)
            saved.append(record);existing[record['復元先']]=record
    index[key]={'正本':saved,'全源復元参照':lib.resolve(files,key,existing),'元F0_F1への遡及主張':False,
        'Source_主_閾値又は正式3MD変更':False,'manifest_SHA256':args.sha256}
    index_path.write_bytes(lib.json_bytes(index))
    print(json.dumps({'成功':True,'区分':key,'小源数':len(files),'索引SHA256':lib.sha(index_path)},ensure_ascii=False))


if __name__=='__main__':
    main()
