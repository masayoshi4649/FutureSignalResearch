"""154停止保存器の段階保存/人工だけを155へ派生する。"""
from pathlib import Path
import hashlib

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 保存先/主名を155へ変え、共有154索引を再用して大入力再複写を防ぐ。
    引数: なし。返り値: None。旧源や新自然出力を開かない。
    """
    for name in ('保存する.py','人工検査.py'):
        source=ROOT/'work/154正式保存'/name
        text=source.read_text(encoding='utf-8').replace('154','155').replace('U30','U0')
        text=text.replace('00155_回帰で進行と往復を分けて短期回復から入る','00155_方向付き数量で既存入口を補正し順行入口を加える')
        text=text.replace('00155_先行終値の回帰測定','00155_方向付き数量の測定')
        if name=='保存する.py':text=text.replace('for number in (153,152):','for number in (154,153,152):')
        target=HERE/name;assert not target.exists();target.write_bytes(text.encode('utf-8'))
        print(name,hashlib.sha256(target.read_bytes()).hexdigest())


if __name__=='__main__':
    main()
