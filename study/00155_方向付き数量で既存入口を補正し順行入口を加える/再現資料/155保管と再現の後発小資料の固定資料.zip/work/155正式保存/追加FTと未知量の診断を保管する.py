"""155のF2後に停止したFT実逆と数量未知維持の診断5点を保管する。"""
from pathlib import Path
import importlib.util
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 停止済み5点を全指紋照合し、原文ZIP・正式根拠・参照案内を保存する。
    引数: なし。返り値: None。F2/採用条件/正式3MDを変更せず遡及固定もしない。
    """
    spec = importlib.util.spec_from_file_location('archive155_ft_late', HERE / '保存する.py')
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    lib = base.library()
    formal = ROOT / base.FORMAL_REL
    folder = ROOT / 'work/155FTと数量未知維持の原因診断'
    stop_path = folder / '停止の確認.json'
    stop_sha = 'b3ac9443a11a93ca0a276c316352b8a7a7821ebf26f80a49e354663a80aaf34a'
    assert lib.sha(stop_path) == stop_sha
    stop = json.loads(stop_path.read_bytes())
    assert stop['成功'] and stop['編集停止'] and stop['本停止票自身も保存']
    files = {row['path']: row['SHA256'] for row in stop['最小保存対象']}
    files[stop_path.relative_to(ROOT).as_posix()] = stop_sha
    assert len(files) == 5
    before = {rel: (lib.sha(ROOT / rel), (ROOT / rel).stat().st_size, (ROOT / rel).stat().st_mtime_ns) for rel in files}
    assert all(value[0] == files[rel] for rel, value in before.items())
    docs = {name: lib.sha(formal / name) for name in ('README.md', '条件.md', '設定と結果.md')}
    index_path = formal / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    key = '追加FTと未知量の事後診断'
    assert key not in index
    existing = base.references(index)
    saved = []
    for source, destination, compressed in (
        (folder / '診断.json', '根拠/FTと数量未知維持の診断.json.gz', True),
        (folder / '範囲.md', '根拠/FTと数量未知維持の診断範囲.md', False),
        (stop_path, '検査/FTと数量未知維持の診断の停止.json', False),
    ):
        record = lib.save_file(source, formal / destination, files[source.relative_to(ROOT).as_posix()], compressed)
        lib.check_reference(record, record['解凍SHA256'])
        saved.append(record)
        existing[record['復元先']] = record
    # ----------------------------------------
    # 正式閲覧用MDは相対リンクだけ変え、作者原文は小源ZIPに保持する。
    original = (folder / '短報.md').read_text(encoding='utf-8')
    body = original.replace('[診断.json](診断.json)', '[診断JSON](FTと数量未知維持の診断.json.gz)')
    body = body.replace('[範囲.md](範囲.md)', '[診断範囲](FTと数量未知維持の診断範囲.md)')
    body = body.replace('[診断する.py](診断する.py)', '[診断Sourceの復元参照](../保管索引.json)')
    short = formal / '根拠/FTと数量未知維持の事後診断.md'
    lib.write_new(short, body.encode('utf-8'))
    index[key] = {
        '作者停止SHA256': stop_sha,
        '正本': saved,
        '閲覧用短報': {'path': short.relative_to(ROOT).as_posix(), 'SHA256': lib.sha(short),
                     '作者原文SHA256': files[(folder / '短報.md').relative_to(ROOT).as_posix()], '本文変更は相対リンクだけ': True},
        '全源復元参照': lib.resolve(files, key, existing),
        'F2前固定だったとの遡及主張': False,
        '固定155の条件_取得_主交換': False,
        '事後少数群_近接依存_量未知だから反転は未採用': True,
    }
    index_path.write_bytes(lib.json_bytes(index))
    addition = (
        '\n\n## FTと数量未知維持の追加事後診断\n\n'
        '[短報](根拠/FTと数量未知維持の事後診断.md)と[全数値・品質原因足](根拠/FTと数量未知維持の診断.json.gz)を保存した。'
        '固定FT45の同q1実逆も全期52.94%・費用後赤字で、一律反転を採用しない。'
        '数量未知KEEP17は2場に集中し、14件が同じ欠分1足を共有した。'
        '品質回復待ちと方向判断を分け、17件を独立成功や量未知による反転根拠にしない。'
        'F2後の事後診断5点であり、F2へ遡及固定せず、主・閾値・取得は不変。'
        '原文MDとSourceは保管索引の「追加FTと未知量の事後診断」から復元できる。\n'
    ).encode('utf-8')
    for name in ('閲覧資料.md', '再現手順.md'):
        target = formal / name
        target.write_bytes(target.read_bytes() + addition)
    assert docs == {name: lib.sha(formal / name) for name in docs}
    assert before == {rel: (lib.sha(ROOT / rel), (ROOT / rel).stat().st_size, (ROOT / rel).stat().st_mtime_ns) for rel in files}
    print(json.dumps({'成功': True, '追加最小小点': 5, '正式3MD不変更': True, '索引SHA256': lib.sha(index_path)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
