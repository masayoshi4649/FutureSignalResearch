"""155の保存選択再現源を154から派生し、未知の結果SHAは実行時正本へ結ぶ。"""
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 固定共有観測を使う再現源だけを作成し、新自然結果は読まない。
    引数: なし。返り値: None。155正式文書へはまだ書き込まない。
    """
    source=ROOT/'work/154正式保存/保存選択から再集計する.py'
    text=source.read_text(encoding='utf-8').replace('154','155')
    text=text.replace('00155_回帰で進行と往復を分けて短期回復から入る','00155_方向付き数量で既存入口を補正し順行入口を加える')
    text=text.replace('155回帰環境の評価','155量方向による入口の評価').replace('155回帰環境の金融集計','155方向付き数量の金融集計')
    text=text.replace('1020比較','960比較').replace("'比較数': 1020","'比較数': 960")
    text=text.replace('F2実金融集計前.json','F2金融前.json')
    marker="    freeze = json.loads((FORMAL / '検査/F2実金融集計前.json').read_bytes())\n"
    assert marker in text
    text=text.replace(marker,marker+"    summary = json.loads((FORMAL / '成果物/集計.json').read_bytes())\n",1)
    text=text.replace("wanted[selection_rel] = 'f1a6d038c1f25ae703b7aef45c41fe4470899a531481abfd735e17c6128df5ea'",
        "wanted[selection_rel] = summary['選択対応SHA256']")
    path=HERE/'保存選択から再集計する.py';assert not path.exists();path.write_bytes(text.encode('utf-8'))


if __name__=='__main__':
    main()
