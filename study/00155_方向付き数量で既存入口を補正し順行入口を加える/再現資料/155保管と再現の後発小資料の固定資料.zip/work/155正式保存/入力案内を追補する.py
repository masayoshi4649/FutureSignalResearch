"""155既存数量READMEを全prefix保持して新3gzip案内だけ追記する。"""
from pathlib import Path
import argparse
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: F1保存済み新3JSONの物理/解凍SHAを既存入力README末尾へ足す。
    引数: CLI execute-after-root-notice(bool)。返り値: None。既存入力と3MDを変更しない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--execute-after-root-notice',action='store_true');args=parser.parse_args()
    if not args.execute_after_root_notice:parser.error('Root完了通知後のF1保存後だけ実行する')
    formal=ROOT/'study/00155_方向付き数量で既存入口を補正し順行入口を加える'
    index=json.loads((formal/'保管索引.json').read_bytes());rows=index['155新生成3JSONを各1gzip保存'];assert len(rows)==3
    path=ROOT/'inputs/00155_方向付き数量の測定/README.md';before=path.read_bytes();assert '## 155新生成3JSON' not in before.decode('utf-8')
    lines=['\n\n## 155新生成3JSON（F1後の追加）\n','元の数量測定案内は全bytes保持し、この節だけ追記した。新モデルはない。\n',
        '| 保存 | 物理bytes | 物理SHA256 | 解凍bytes | 解凍SHA256 |','| --- | ---: | --- | ---: | --- |']
    for row in rows:
        name=Path(row['保存元']).name
        lines.append(f"| [{name}]({name}) | {row['保存bytes']:,} | `{row['保存SHA256']}` | {row['解凍bytes']:,} | `{row['解凍SHA256']}` |")
    lines.append('\n147/148/152/153/154・数量測定・100X/大観測は共有し、新3JSON以外は再コピーしていない。'
        '[正式結果](../../study/00155_方向付き数量で既存入口を補正し順行入口を加える/README.md)・'
        '[保管索引](../../study/00155_方向付き数量で既存入口を補正し順行入口を加える/保管索引.json)。\n')
    path.write_bytes(before+'\n'.join(lines).encode('utf-8'));assert path.read_bytes().startswith(before)
    out=HERE/'入力README追記の確認.json';assert not out.exists()
    proof={'成功':True,'元入力README全prefix保持':True,'追記前SHA256':hashlib.sha256(before).hexdigest(),
        '追記後SHA256':hashlib.sha256(path.read_bytes()).hexdigest(),'数量_book_共有入力_正式3MD変更':False}
    out.write_bytes((json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
