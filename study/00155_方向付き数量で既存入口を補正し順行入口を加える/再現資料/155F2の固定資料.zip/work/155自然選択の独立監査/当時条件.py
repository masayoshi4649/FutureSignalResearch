"""停止済み私有oracleを使い155の主要gateと全仮定actionを独立再構成する。"""
from pathlib import Path
import importlib.util
import math

ROOT=Path(__file__).resolve().parents[2]
ORACLE=ROOT/'work/155量方向の実行前レビュー/独立人工.py'
spec=importlib.util.spec_from_file_location('private155oracle_natural',ORACLE)
private=importlib.util.module_from_spec(spec);spec.loader.exec_module(private)


def gate(checks: dict,values: dict) -> dict:
    """
    機能: 全required knownのANDを独立に構成する。
    引数: checks(dict[str,bool|None])、values(dict)。返り値: dict。
    """
    known=all(v is not None for v in checks.values())
    return {'known':known,'pass':all(checks.values()) if known else None,
            'false':[k for k,v in checks.items() if v is False],'unknown':[k for k,v in checks.items() if v is None],
            'checks':checks,'values':values}


# ----------------------------------------
def reconstruct(buy: list,sell: list,columns: list,measurement: dict,quantity: dict) -> dict:
    """
    機能: 当時100列を名前で射影し、主要条件・action・方向・役割を独立計算する。
    引数: buy/sell(list)、columns(list[str])、measurement/quantity(dict)。返り値: dict。
    """
    ix={name:i for i,name in enumerate(columns)};vectors=[]
    for vector in (buy,sell):
        vectors.append([vector[ix[name]] if name in ix else 0. for name in private.NAMES])
    basic=private.oracle((*vectors,measurement,quantity));cmp=private.compare
    q=measurement['q0'];r=measurement['r'];sidegates={};actions={name:{} for name in ('main','zero')};decision={'directions':{},'conflicts':{},'evidence':[]}
    cmf=quantity['cmf20']['current']['value'] if quantity['cmf20']['current']['value_defined'] else None
    obv=quantity['obv']['15']['change'] if quantity['obv']['15']['window_known'] else None
    for t,vector in ((1,buy),(-1,sell)):
        v={key:vector[ix[key]] if type(vector[ix[key]]) in (int,float) and math.isfinite(vector[ix[key]]) else None for key in private.KEYS}
        gap=v['q0_last_minus_m1_close_atr5_to_side'];distance=v['q0_entry_minus_ema8_atr5_to_side'];atr=v['m5_atr']
        spread=q['ask']-q['bid'] if q['normal_bbo'] else None
        common=gate({'eligible':measurement['eligible'],'normal_bbo':q['normal_bbo'],'spread_positive':cmp(spread,'>',0),
                     'spread_max20':cmp(spread,'<=',20),'atr5_positive':cmp(atr,'>',0),'gap_abs_max1':cmp(abs(gap) if gap is not None else None,'<=',1)},
                    {'atr5':atr,'spread':spread,'last_close_gap_atr5':gap})
        m=[cmp(v[key],'>',0) for key in ('m5_hist_delta_to_side','m5_rsi_delta_to_side')]
        momentum=True if True in m else None if None in m else False
        last_open=t*(q['last']-r['ohlc']['open']) if type(q['last']) in (int,float) else None
        flip=gate({'common':common['pass'],'last_beyond_r_open':cmp(last_open,'>',0),'entry_ema8_upper1':cmp(distance,'<=',1),'hist_or_rsi_improvement':momentum},
                  {'last_minus_r_open_to_side':last_open,'entry_ema8_distance':distance,'hist_delta':v['m5_hist_delta_to_side'],'rsi_delta':v['m5_rsi_delta_to_side']})
        signed_c=t*cmf if cmf is not None else None;signed_o=t*obv if obv is not None else None
        reclaim=v['m1_body_reclaim_atr5_to_side']+gap if v['m1_body_reclaim_atr5_to_side'] is not None and gap is not None else None
        ft={}
        for name,a in (('main',.05),('zero',0.)):
            checks={'common':common['pass'],'cmf_support':cmp(signed_c,'>',a),'obv_support':cmp(signed_o,'>',0),
                    'same_r_volume_at_least1':cmp(v['m1_volume_relative_prior3'],'>=',1),'ema21_delta30_positive':cmp(v['m30_ema21_delta_to_side'],'>',0),
                    'hist_level_positive':cmp(v['m5_hist_to_side'],'>',0),'hist_delta_positive':cmp(v['m5_hist_delta_to_side'],'>',0),
                    'r_body_positive':cmp(v['m1_body_ratio_to_side'],'>',0),'current_p_open_reclaim':cmp(reclaim,'>',0),
                    'last_at_or_beyond_r_close':cmp(gap,'>=',0),'entry_ema8_lower0':cmp(distance,'>=',0),'entry_ema8_upper1':cmp(distance,'<=',1)}
            ft[name]=gate(checks,{'a':a,'CMF20_to_side':signed_c,'OBV15_raw_change_to_side':signed_o,'current_p_open_reclaim':reclaim,**v})
            assert ft[name]['pass'] is basic['sides'][t]['ft'][name]
        assert flip['pass'] is basic['sides'][t]['flip']
        sidegates[str(t)]={'common':common,'quantity':{'CMF20_to_side':signed_c,'OBV15_raw_change_to_side':signed_o},'flip_confirmation':flip,'FT':ft}
    for name,a in (('main',.05),('zero',0.)):
        for s in (1,-1):
            values=sidegates[str(s)]['quantity'];opposition=gate({'cmf_strong_opposition':cmp(values['CMF20_to_side'],'<',-a),'obv_opposition':cmp(values['OBV15_raw_change_to_side'],'<',0)},dict(values,a=a))
            side,action=basic['actions'][name][s];confirmed=sidegates[str(-s)]['flip_confirmation']['pass']
            reason='strong_opposition_confirmed' if action=='flip' else 'strong_opposition_confirmation_missing' if action=='wait' else 'quantity_unknown_keep' if not opposition['known'] else 'no_strong_opposition_keep'
            actions[name][str(s)]={'source_side':s,'side':side,'action':action,'reason':reason,'strong_opposition':opposition,
                                  'opposite_confirmation':confirmed,'unknown_keep_is_not_quantity_support':not opposition['known']}
        policy='FT' if name=='main' else 'FTZ';hits=[t for t in (1,-1) if sidegates[str(t)]['FT'][name]['pass'] is True]
        decision['directions'][policy]=hits[0] if len(hits)==1 else 0;decision['conflicts'][policy]=len(hits)>1
        for t in hits:decision['evidence'].append({'rule':policy,'signal_side':t,'order_side':t,'roles':['方向','勢い','量','構造','値幅'],'quantity_descriptions_are_one_role':True,'cmf_buffer':a})
    decision['directions']['NFT']=decision['directions']['FT'];decision['conflicts']['NFT']=decision['conflicts']['FT']
    return {'technical':sidegates,'base_actions':actions,'decision':decision}
