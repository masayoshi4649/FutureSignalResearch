"""155全q0を独立再構成後にだけ取得と固定対照を結合する。"""
from pathlib import Path
from collections import Counter
import argparse
import copy
import gzip
import hashlib
import json
import math
import re
import 当時条件 as condition

ROOT = Path(__file__).resolve().parents[2]



def sha(path: Path) -> str:
    """
    機能: 明示された固定入力の全物理指紋を求める。
    引数: path(Path)。返り値: str。
    """
    value = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''): value.update(block)
    return value.hexdigest()


# ----------------------------------------
def read(path: Path, physical: str, decoded: str | None = None) -> dict:
    """
    機能: SHAとgzip全CRCを確認しplain副本を作らずJSONを読む。
    引数: path(Path)、physical(str)、decoded(str|None)。返り値: dict。
    """
    assert sha(path) == physical
    with (gzip.open(path, 'rb') if path.suffix == '.gz' else path.open('rb')) as source: body = source.read()
    assert decoded is None or hashlib.sha256(body).hexdigest() == decoded
    return json.loads(body)


# ----------------------------------------
def rows(path: Path, evidence: dict):
    """
    機能: 巨大なq0 JSONを1行ずつ解析して全bytesを指紋へ加える。
    引数: path(Path)、evidence(dict)。返り値: Iterator[dict]。
    """
    digest = hashlib.sha256(); size = 0; decoder = json.JSONDecoder(); buffer = ''
    with path.open('rt', encoding='utf-8', newline='') as source:
        def more() -> str:
            """
            機能: 文字境界を保ったblockを読み指紋を更新する。
            引数: なし。返り値: str。
            """
            nonlocal size
            text = source.read(1 << 20); raw = text.encode('utf-8'); digest.update(raw); size += len(raw)
            return text
        while True:
            text = more(); assert text, 'rowsがない'
            buffer += text; match = re.search(r'(?m)^  "rows": \[', buffer)
            if match: buffer = buffer[match.end():]; break
        while True:
            buffer = buffer.lstrip()
            if buffer.startswith(']'): break
            if buffer.startswith(','): buffer = buffer[1:].lstrip()
            try: item, end = decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                text = more(); assert text, 'rows途中終了'; buffer += text; continue
            yield item; buffer = buffer[end:]
        while more(): pass
    evidence.update(sha256=digest.hexdigest(), bytes=size)


# ----------------------------------------
def stamp(value: dict) -> tuple:
    """
    機能: 保存Stampとq0のline/source_lineを同じ物理行として取り出す。
    引数: value(dict)。返り値: tuple[float,int,int]。
    """
    return value['time'], value['index'], value['line'] if 'line' in value else value['source_line']


# ----------------------------------------
def equal(expected, actual, path: str = '') -> int:
    """
    機能: 全キー・配列順・型付き末端を漏れなく照合する。
    引数: expected/actual(object)、path(str)。返り値: intは末端比較数。
    """
    if isinstance(expected, dict):
        assert isinstance(actual, dict) and set(expected) == set(actual), path
        return sum(equal(value, actual[key], path + '/' + str(key)) for key, value in expected.items())
    if isinstance(expected, list):
        assert isinstance(actual, list) and len(expected) == len(actual), path
        return sum(equal(value, actual[i], path + '/' + str(i)) for i, value in enumerate(expected))
    if expected is None: assert actual is None, path
    elif isinstance(expected, bool): assert type(actual) is bool and expected == actual, (path, expected, actual)
    elif type(expected) in (int, float): assert type(actual) in (int, float) and math.isfinite(actual) and expected == actual, (path, expected, actual)
    else: assert type(expected) is type(actual) and expected == actual, (path, expected, actual)
    return 1


# ----------------------------------------
def merge(first: list,second: list) -> tuple:
    """
    機能: 同物理caseをfirst優先で独立統合し、反対方向aliasも記録する。
    引数: first/second(list[dict])。返り値: tuple[list,list]。
    """
    out={x['case_id']:copy.deepcopy(x) for x in first};assert len(out)==len(first);seen=set();collisions=[]
    for row in second:
        key=row['case_id'];assert key not in seen;seen.add(key)
        if key in out:
            collisions.append({'case_id':key,'priority_side':out[key]['side'],'new_side':row['side'],
                'opposite':out[key]['side']!=row['side'],'priority_origin':out[key]['origin'],'later_origin':row['origin']})
        else:out[key]=copy.deepcopy(row)
    return list(out.values()),collisions


# ----------------------------------------
def join(decisions: list,captures: dict,metadata: dict,sessions: list,old: dict) -> dict:
    """
    機能: 全独立判断後に取得/固定対照を読み最早q0・Q/C1優先を再現する。
    引数: decisions(list)、captures/metadata/old(dict)、sessions(list)。返り値: dict。
    """
    events={r['event_id']:r for r in captures['rows']};descriptors=metadata['population148']['cases'];cases={r['case_id']:r for r in descriptors}
    assert len(events)==len(decisions)==len({r['event_id'] for r in decisions}) and set(events)=={r['event_id'] for r in decisions}
    assert len(cases)==len(descriptors) and captures['sessions']==metadata['sessions']==sessions
    order={s:i for i,s in enumerate(sessions)};picked={n:{} for n in ('FT','FTZ')};counts={n:Counter() for n in picked}
    for row in sorted(decisions,key=lambda r:(order[r['session']],r['q0_index'],r['q0_line'],r['event_id'])):
        cap=events[row['event_id']]
        assert (cap['session'],cap['contract'])==(row['session'],row['contract'])
        assert stamp(cap['q0'])==(row['q0_time'],row['q0_index'],row['q0_line'])
        for policy in ('FT','FTZ'):
            if row['decision']['conflicts'][policy]:counts[policy]['conflict_wait']+=1
            side=row['decision']['directions'][policy]
            if not side:continue
            counts[policy]['born']+=1;counts[policy][cap['status']]+=1
            if cap['status']!='filled':continue
            key=cap['case_id'];desc=cases[key];assert (desc['session'],desc['contract'])==(row['session'],row['contract'])
            if key in picked[policy]:counts[policy]['duplicate_q1']+=1;continue
            streamkey='buy_stream' if side==1 else 'sell_stream';assert cap[streamkey]==desc[streamkey]
            hits=[x for x in row['decision']['evidence'] if x['rule']==policy and x['order_side']==side]
            picked[policy][key]={'case_id':key,'session':row['session'],'side':side,'stream':cap[streamkey],
                'event_id':row['event_id'],'feature_ref':row['event_id'],'q0_time':row['q0_time'],
                'q0_index':row['q0_index'],'q0_line':row['q0_line'],'成立ID':sorted({x['rule'] for x in hits}),'evidence':hits,'origin':policy}
    legacy=[{'case_id':r['case_id'],'session':r['session'],'side':r['original_side'],'stream':'original',
             'event_id':None,'feature_ref':None,'origin':'C1'} for r in descriptors if r['c1_reused']]
    assert len(legacy)==87 and old['成功'] and old['試行']==154 and old['選択時の金融ラベル利用'] is False
    assert {r['case_id']:r for r in legacy}=={r['case_id']:r for r in old['政策']['C1']}
    policies={n:list(v.values()) for n,v in picked.items()};policies['C1']=legacy
    bycase={r['case_id']:r for r in legacy};uft=list(legacy);uftalias=[]
    for r in policies['FT']:
        if r['case_id'] in bycase:
            uftalias.append({'case_id':r['case_id'],'legacy_side':bycase[r['case_id']]['side'],'new_side':r['side'],'opposite':bycase[r['case_id']]['side']!=r['side']})
        else:
            reference=copy.deepcopy(r);reference['origin']='NFT';uft.append(reference)
    policies['UFT']=uft;overlap={'UFT':uftalias};expected={'B152':614,'UB152':697,'U154':213,'C1':87}
    for dest,src in [('B152','B152'),('UB152','UB152'),('U154','U30')]:
        assert len(old['政策'][src])==expected[dest];policies[dest]=copy.deepcopy(old['政策'][src])
    decided={r['event_id']:r for r in decisions};audit={}
    for variant,name in [('main','Q0'),('zero','QZ')]:
        selected=[];audit[name]=[]
        for base in policies['B152']:
            row=decided[base['event_id']];desc=cases[base['case_id']];s=base['side']
            assert type(s) is int and s in (1,-1) and base['feature_ref']==row['event_id']
            assert all(base[k]==row[k] for k in ('session','q0_time','q0_index','q0_line'))
            assert (desc['session'],desc['contract'])==(row['session'],row['contract'])
            assert base['stream']==desc['buy_stream' if s==1 else 'sell_stream']
            action=copy.deepcopy(row['base_actions'][variant][str(s)]);side=action['side']
            assert action['source_side']==s and side in (-s,0,s)
            audit[name].append({'case_id':base['case_id'],'event_id':row['event_id'],'source_side':s,'source_stream':base['stream'],**action})
            if not side:continue
            ref=copy.deepcopy(base);ref.update(side=side,stream=desc['buy_stream' if side==1 else 'sell_stream'],origin=name,
                source_policy='B152',source_selected_side=s,source_selected_stream=base['stream'],source_B152_ref=copy.deepcopy(base),
                q0_action=action,cmf_buffer=.05 if variant=='main' else 0.,
                evidence=[{'rule':name,'signal_side':s,'order_side':side,'roles':['量','構造','勢い','値幅'],
                           'action':action['action'],'quantity_descriptions_are_one_role':True}],成立ID=[name])
            selected.append(ref)
        assert len({r['case_id'] for r in selected})==len(selected);policies[name]=selected
        counts[name]={'fixed_B152':614,'keep':sum(x['action']=='keep' for x in audit[name]),
                      'flip':sum(x['action']=='flip' for x in audit[name]),'wait':sum(x['action']=='wait' for x in audit[name]),'filled':len(selected)}
    policies['N0'],n0alias=merge(policies['Q0'],policies['FT']);policies['NZ'],nzalias=merge(policies['QZ'],policies['FTZ'])
    for dest,new in [('UQ0','Q0'),('U0','N0'),('UZ','NZ')]:policies[dest],overlap[dest]=merge(legacy,policies[new])
    return {'政策':policies,'候補と取得':{k:dict(v) for k,v in counts.items()},'旧C1重複':overlap,'全73場':sessions,
            '選択時の金融ラベル利用':False,'Q_FT重複':{'N0':n0alias,'NZ':nzalias},'B152へのq0action':audit,
            '非金融補助alias':['FTZ','QZ'],'固定154対照全値保持':{'成功':True,**expected,'旧選択をpureへ未使用':True}}


# ----------------------------------------
def main() -> None:
    """
    機能: F1許可後に全q0を独立照合し、その後にだけ取得と固定対照を読む。
    引数: CLI --f0/--f1/--book/--run-dir/--output-dir(Path)と各sha256(str)。返り値: None。
    """
    parser=argparse.ArgumentParser()
    for name in ('f0','f1','book','run-dir','output-dir'):parser.add_argument('--'+name,type=Path,required=True)
    for name in ('f0-sha256','f1-sha256','book-sha256'):parser.add_argument('--'+name,required=True)
    args=parser.parse_args();f0=read(args.f0,args.f0_sha256);f1=read(args.f1,args.f1_sha256);book=read(args.book,args.book_sha256)
    assert f0['試行']==f1['試行']==book['trial']==155 and f1['前段階SHA256']==args.f0_sha256
    files={**f0['ファイル'],**f1['ファイル']};assert all(f1['ファイル'].get(p)==h for p,h in f0['ファイル'].items())
    before={p:(sha(ROOT/p),(ROOT/p).stat().st_size,(ROOT/p).stat().st_mtime_ns) for p in files}
    assert all(before[p][0]==h for p,h in files.items())
    oracle_sha='d543cc04c53e76891a4f48ef0ae812d25a73c7b3746a603f8a260e73726ff525'
    assert sha(condition.ORACLE)==oracle_sha,'停止済み私有oracleが変わっていない'
    refs=book['features_source'];value=refs['features'];features=read(ROOT/value['path'],value['sha256'],value['decoded_sha256'])
    value=book['range_input'];high=read(ROOT/value['path'],value['sha256'],value['decoded_sha256'])
    value=book['quantity_input'];quantity=read(ROOT/value['path'],value['sha256'],value['decoded_sha256'])
    assert features['success'] and features['trial']==148 and features['financial_labels_used'] is False and features['selected_trade_count'] is None
    assert high['success'] and high['schema']=='prior_time_range_v1' and high['financial_labels_used'] is False
    assert quantity['success'] and quantity['schema']=='directional_volume_v1' and quantity['financial_labels_used'] is False
    assert quantity['source_refs']['source153']=={k:book['range_input'][k] for k in ('path','sha256','decoded_sha256')}
    columns=[c['name'] for c in features['catalog']];sessions=features['sessions']
    assert len(columns)==100 and columns==sorted(set(columns)) and len(sessions)==73 and high['sessions']==quantity['sessions']==sessions
    measurements={};seen=set();source_counts=Counter()
    for scene,qtyscene in zip(high['scenes'],quantity['scenes'],strict=True):
        assert all(scene[k]==qtyscene[k] for k in ('session','contract','start','continuous_end'))
        bars={r['id']:r for r in scene['bars']};assert len(bars)==len(scene['bars'])==len(qtyscene['volume_refs'])
        for i,(b,v) in enumerate(zip(scene['bars'],qtyscene['volume_refs'],strict=True)):
            assert v['id']==b['id'] and v['source147_bar_index']==i and v['volume_known']==b['volume_known']
            assert v['volume'] is None if not v['volume_known'] else type(v['volume']) in (int,float) and math.isfinite(v['volume']) and v['volume']>=0
        for row,qty in zip(scene['rows'],qtyscene['rows'],strict=True):
            assert row['event_id'] not in seen;seen.add(row['event_id']);source_counts['all_q0']+=1
            assert all(row[k]==qty[k] for k in ('event_id','eligible','r_ref')) and stamp(row['q0'])==stamp(qty['q0_stamp'])
            r=bars[row['r_ref']];assert stamp(r['stamp'])==stamp(row['q0'])
            assert qty['obv']['15']['from']==r['end']-900 and qty['obv']['15']['to']==r['end']
            assert qty['cmf20']['current']['from']==r['end']-1200 and qty['cmf20']['current']['to']==r['end']
            if row['eligible']:
                measurements[row['event_id']]=(scene,bars,row,qty);source_counts['eligible']+=1
    assert source_counts=={'all_q0':40544,'eligible':35339} and len(features['rows'])==35339
    path=args.run_dir/'q0の判断.json';expected_sha=files[path.resolve().relative_to(ROOT).as_posix()]
    streamproof={};iterator=iter(rows(path,streamproof));minimal=[];cells=0;flags=Counter()
    for i,feature in enumerate(features['rows']):
        scene,bars,measured,qty=measurements.pop(feature['event_id']);q=measured['q0'];r=bars[measured['r_ref']]
        meta={'event_id':feature['event_id'],'session':feature['session'],'contract':feature['contract'],
              'session_index':sessions.index(feature['session']),'q0_time':q['time'],'q0_index':q['index'],'q0_line':q['source_line']}
        assert (scene['session'],scene['contract'])==(meta['session'],meta['contract'])
        original=feature['metadata']['q0'];assert all(q[k]==original[k] for k in ('time','index','source_line','last','quote_ok','normal_bbo'))
        for k in ('bid','ask'):
            known=type(original[k]) in (int,float) and math.isfinite(original[k]) and original[k]>0
            assert q[k+'_known'] is known and q[k]==(original[k] if known else None)
        assert r['end']<=r['available_at']<=q['time'] and r['price_known'] and r['closed'] and not r['missing']
        assert measured['r_ref']==measured['slot_refs'][-1]==measured['delivered_refs'][-1]
        assert [x['id'] for x in feature['metadata']['short_refs']]==measured['slot_refs']
        for ref in feature['metadata']['short_refs']:
            b=bars[ref['id']];assert (ref['session'],ref['contract'])==(meta['session'],meta['contract'])
            assert all(ref[k]==b[k] for k in ('id','start','end','available_at','stamp','price_known','volume_known','closed'))
            assert all(x<=y for x,y in zip(stamp(b['stamp']),stamp(q)))
        assert feature['buy']['side']==1 and feature['sell']['side']==-1
        dto={'eligible':True,'event_id':feature['event_id'],'q0':q,'r':r,'prior_ranges':measured['prior_ranges']}
        expected={**meta,'r_ref':r['id'],**condition.reconstruct(feature['buy']['x'],feature['sell']['x'],columns,dto,qty)}
        actual=next(iterator);cells+=equal(expected,actual,'q0/'+str(i))
        minimal.append({**meta,'decision':expected['decision'],'base_actions':expected['base_actions']})
        for policy,direction in expected['decision']['directions'].items():flags[policy+'/'+str(direction)]+=1
        if (i+1)%5000==0:print(json.dumps({'独立q0':i+1},ensure_ascii=False),flush=True)
    assert not measurements
    try:next(iterator)
    except StopIteration:pass
    else:raise AssertionError('余分なq0')
    assert streamproof['sha256']==expected_sha
    # ----------------------------------------
    # 全q0照合後にだけ取得/旧対照を構造として読み、独立結合する。
    value=refs['captures'];captures=read(ROOT/value['path'],value['sha256'],value['decoded_sha256'])
    value=refs['metadata'];metadata=read(ROOT/value['path'],value['sha256'],value['decoded_sha256'])
    control=book['fixed154_control'];value=control['selection'];old=read(ROOT/value['path'],value['sha256'],value['decoded_sha256'])
    value=control['f1'];oldf1=read(ROOT/value['path'],value['sha256'])
    assert oldf1['ファイル']['work/154回帰環境の評価/入口選択/選択対応.json']==control['selection']['decoded_sha256']
    linked=join(minimal,captures,metadata,sessions,old)
    expected={'成功':True,'試行':155,'主政策':'U0','book_sha256':args.book_sha256,
              'quantity_input_decoded_sha256':book['quantity_input']['decoded_sha256'],**linked}
    path=args.run_dir/'選択対応.json';actual=read(path,files[path.resolve().relative_to(ROOT).as_posix()])
    cells+=equal(expected,actual,'選択対応')
    assert before=={p:(sha(ROOT/p),(ROOT/p).stat().st_size,(ROOT/p).stat().st_mtime_ns) for p in files}
    proof={'成功':True,'編集停止':True,'試行':155,'F0_SHA256':args.f0_sha256,'F1_SHA256':args.f1_sha256,'bookSHA256':args.book_sha256,
           '全q0':len(minimal),'末端比較':cells,'全common_flip_FT_main_zero_action_方向役割一致':True,
           '全取得_最早q0_別q0同q1_Q優先_C1優先_旧154全値同体':True,
           '政策別取得数':{k:len(v) for k,v in linked['政策'].items()},'判断方向分布':dict(flags),'巨大q0の全bytes':streamproof,
           '全固定41源前後同体':{p:v[0] for p,v in before.items()},'独立oracle':{'path':condition.ORACLE.relative_to(ROOT).as_posix(),'SHA256':oracle_sha},
           '純判断全件一致後にだけ取得_旧対照を構造読取':True,'作者155choose_runner_接続算術import':False,
           '金融_観測_教師_Raw_CSV_追加2場読取_新しい選び直し':False,'全technical葉又は巨大入力の副本':False,
           '初回停止と補修':'全q0一致後、UFT新参照の内部NFT由来表記で停止。期待側originのみ補修して同じF1を再監査。Source/自然選択は不変更。',
           '限界':'保存100X/価格数量測定を固定入力とする。各測定の元算術は別票、真受信/first-normal/実約定/金融は今回再検査しない。'}
    args.output_dir.mkdir(parents=True,exist_ok=True);target=args.output_dir/'監査の確認.json'
    with target.open('x',encoding='utf-8') as out:json.dump(proof,out,ensure_ascii=False,indent=2);out.write('\n')
    print(json.dumps({'成功':True,'全q0':len(minimal),'末端比較':cells,'政策別取得数':proof['政策別取得数'],'SHA256':sha(target)},ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':main()
