"""155の入口選択後F1と金融Sourceを別の金融前F2へ束縛する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json

ROOT = Path(__file__).resolve().parent.parent


def sha(path: Path) -> str:
    """
    機能: ファイルの物理指紋を計算する。
    引数: path(Path)。返り値: strはSHA256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: F1同体と金融準備源を確認し、F2だけを新規保存する。
    引数: CLI f1/output(Path)、f1-sha256(str)。返り値: None。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--f1', type=Path, required=True)
    parser.add_argument('--f1-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.f1, args.output = args.f1.resolve(), args.output.resolve()
    assert not args.output.exists() and sha(args.f1) == args.f1_sha256
    f1 = json.loads(args.f1.read_bytes())
    assert f1['成功'] and f1['試行'] == 155 and f1['段階'] == 'F1'
    files = {}
    for name, expected in f1['ファイル'].items():
        assert sha(ROOT / name) == expected, name
        files[name] = expected
    finance = ROOT / 'work/155方向付き数量の金融集計'
    prep = json.loads((finance / '準備の確認.json').read_bytes())
    assert prep['成功']
    for item in prep['源']:
        assert sha(ROOT / item['path']) == item['sha256']
    spec = importlib.util.spec_from_file_location('金融155の定義だけ', finance / '集計する.py')
    code = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(code)
    for path, expected in code.SOURCES.items():
        assert sha(path) == expected, str(path)
        files[path.relative_to(ROOT).as_posix()] = expected
    refs = [args.f1, Path(__file__).resolve(),
        ROOT / 'work/155量方向による金融集計を独立に照合する.py',
        ROOT / 'work/155の維持反転待機を診断する.py',
        ROOT / 'work/155の順行入口の絞り込みを集計する.py',
        ROOT / 'work/155量方向による入口の評価/FTの出生診断.json',
        ROOT / 'work/141金融集計を独立に確認する.py',
        ROOT / 'inputs/00148_全1分入口母集団/出生台帳.json.gz',
        ROOT / 'work/確定三表のCSV出力_版2/出力する.mjs',
        ROOT / 'work/確定三表のCSV出力_版2/CSVを独立再読する.py']
    refs.extend(path for path in finance.iterdir() if path.is_file())
    audit = ROOT / 'work/155自然選択の独立監査'
    audit_proof = audit / '自然確認/監査の確認.json'
    assert json.loads(audit_proof.read_bytes())['成功']
    assert json.loads((audit / '停止の確認.json').read_bytes())['成功']
    refs.extend(path for path in audit.iterdir() if path.is_file())
    refs.append(audit_proof)
    for path in refs:
        files[path.relative_to(ROOT).as_posix()] = sha(path)
    result = {'成功': True, '試行': 155, '段階': '実金融集計前F2',
        'UTC': datetime.now(timezone.utc).isoformat(), 'F1_SHA256': args.f1_sha256,
        '金融のために入口を選び直す': False, '主政策': 'U0',
        'ファイル': dict(sorted(files.items()))}
    with args.output.open('x', encoding='utf-8', newline='\n') as sink:
        json.dump(result, sink, ensure_ascii=False, indent=2, allow_nan=False)
        sink.write('\n')
    print(json.dumps({'成功': True, '段階': 'F2', '指紋数': len(files),
        'sha256': sha(args.output)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
