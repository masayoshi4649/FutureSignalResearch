"""155方向付き数量の固定選択を共有正逆へ結合し960比較と累計既知/未知を保存する。"""
from pathlib import Path
import argparse
import copy
import gzip
import hashlib
import importlib.util
import json
import math

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PARENT=ROOT/'work/149可読局面の金融集計/集計する.py'
PREPARE=ROOT/'work/148母集団の診断集計/集計する.py'
ANCESTOR=ROOT/'work/150構造状態の金融集計/集計する.py'
ARITHMETIC=ROOT/'work/124入口の原因分析/集計する.py'
OLD_PAIRS=ROOT/'study/00145_押戻し完了と失敗突破を別の構造イベントで評価する/成果物/固定取得の正逆観測.json.gz'
OLD_SUMMARY=ROOT/'study/00145_押戻し完了と失敗突破を別の構造イベントで評価する/成果物/集計.json'
SOURCES={PARENT:'920b6a6c666318eaf5a6ea4a0047246a8d183f850fad67af52bdf6cfdcc9264f',PREPARE:'0ae8287b67b53df0d07c22963e2bf9ecd0775af9b0545a89f6a61af6ec2ec309',ARITHMETIC:'8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a',OLD_PAIRS:'e970b53d95ac4ff56335288ba402d59bef41558d0785d448b1cefe12bd360cbf',OLD_SUMMARY:'fb374d53982ce7727c5ae936d72a20a973029de35480ed442a6cb2305fc9c861'}
SOURCES[ANCESTOR]='017b335b3b5c1fa20ccf1bcb32c1495b84e25c7461b46c70cb9318f688f8c15a'
ANCESTOR152=ROOT/'work/152複合回復の金融集計/集計する.py'
PRIOR152=ROOT/'study/00152_強い反対背景を複合回復で切り替える/成果物/集計.json'
SOURCES[ANCESTOR152]='fc46fe84b3d22a44b2fd930ecad7baa7d16257bd57138222b94eebd7f05d62fc'
SOURCES[PRIOR152]='baa76c4a4827204ec3a4673eed4881f66ab2a0ad4d996de8cf8a5bc7e818add5'
ANCESTOR154=ROOT/'work/154回帰環境の金融集計/集計する.py'
PRIOR154=ROOT/'study/00154_回帰で進行と往復を分けて短期回復から入る/成果物/集計.json'
SOURCES[ANCESTOR154]='b826a0b79230c3033e35bc05d10c7600e1beaa947af67f6c60853a2662c7b52b'
SOURCES[PRIOR154]='41b160e6918b7bdd58e8fcacf857ca036cb5f93720bde617d0c062169fe0deef'
INPUTS={'出生台帳':('9d589488bca8e83be3fd23ed230b6f7cae176acbbe96dd2d04a62d3bbfb6e753','4f4d3ce3a652170d5d5f15941b591493592d5816bb0985c2e70c86b14323b219'),'取得対応':('7c27420abe6af0867f6cf3d8fd838205da3ed099df8db8e5b5d62892cbadf6bc','e433b79f87411c34232acac57a8aed191da71bcd1888376b19196099cbf9909a'),'固定取得入力':('99f10a996ca6e8b6c428061f1b48624bbc479ec84c500a9633818d47e4298e2a','12c43fe60e0ffd5ffa44bec7b5f7dd3d60bb92b291e0008db23587dcf19536d3'),'入口参照':('ad53cccf8e4da093ebd32c1ddc80132ddcd4c73d8f20897c4033f0895fc966b6','66511104a6efd7bc936b0e624469a2de43e9fa5b5fa7645304499f793c25329c')}
OBS_DECODED='d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'
POLICIES=('C0','C1','RC1','B152','UB152','U154','Q0','RQ0','UQ0','FT','UFT','N0','U0','RU0','NZ','UZ')
AXES=('BBO','Last');HORIZONS=(1800,3600);WIDTHS=(25,50,100,125,200)
DETAIL_HEADERS=['試行','参考区分','セッション','限月','固定caseID','旧新','origin','旧C0subset','選択方向','格納方向','選択stream','買stream','売stream','q0eventID','feature_ref','q0JST','q0index','q0物理行','成立IDs','同caseN0成立IDs','旧C1とのN0方向競合','取得JST','取得index','取得物理行','取得Last','取得Bid','取得Ask','選択実P','旧C1同原行保護']
for policy in ('U0','RU0'):DETAIL_HEADERS += [policy+s for s in ('方向','125H状態','125記録方向','125完了方向','125最初到達JST','IFD既知','IFD清算','IFD清算JST','125C5円')]
SCENE_HEADERS=['試行','セッション','参考区分','ザラバ時間h','名目新規可時間h',*[p+'取得数'for p in POLICIES],'U0全時間毎時','N0全時間毎時','U0最低1','U0名目H60連結群数','U0最大連結群件数']
for policy in ('U0','N0','C1'):SCENE_HEADERS += [policy+s for s in ('125順','125逆','125未','125不足','IFD既知','IFD未知','C5利益','C5損失絶対','C5差引')]
CUMULATIVE_FIELDS=('累計既知利益','累計既知損失絶対','累計既知差引','累計IFD未知','累計全件確定差引')
for policy in ('U0','N0','C1'):SCENE_HEADERS += [policy+s for s in CUMULATIVE_FIELDS]


def sha(path: Path) -> str:
    """
    機能: 大型の圧縮又はplain入力を固定bufferで指紋化する。
    引数: path(Path)。返り値: str。
    """
    digest=hashlib.sha256()
    with path.open('rb')as source:
        for block in iter(lambda:source.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()


def load(path: Path,physical: str,decoded: str=None):
    """
    機能: 全解凍CRC/物理・解凍SHA/statを検査し解凍副本なしでJSONを返す。
    引数: path(Path)、physical(str)、decoded(str又はNone)。返り値: object。
    """
    before=path.stat();assert sha(path)==physical
    with (gzip.open(path,'rb')if path.suffix=='.gz'else path.open('rb'))as source:body=source.read()
    assert decoded is None or hashlib.sha256(body).hexdigest()==decoded
    after=path.stat();assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)and sha(path)==physical
    return json.loads(body)


def module(path: Path,name: str):
    """
    機能: mainを呼ばず停止済みコードを私有importする。
    引数: path(Path)、name(str)。返り値: ModuleType。
    """
    spec=importlib.util.spec_from_file_location(name,path);result=importlib.util.module_from_spec(spec);spec.loader.exec_module(result);return result


def selected(record: dict,policy: str,axis: str) -> dict:
    """
    機能: 固定選択の同q1 streamだけを向き正規化して返す。
    引数: record(dict)、policy/axis(str)。返り値: dict。
    """
    return record['case'][('chart_'if axis=='Last'else '')+record['choices'][policy]['stream']]


def bind_choices(records: dict,members: dict,selection: dict,strict: bool=True) -> dict:
    """
    機能: 155固定政策をQ0優先/C1優先で検査し同q1実逆を派生する。
    引数: records/members/selection(dict)、strict(bool)。返り値: dict。
    """
    assert selection['成功'] and selection['試行']==155 and selection['選択時の金融ラベル利用'] is False
    output={key:{**record,'choices':{}} for key,record in records.items()}
    direct=('C1','B152','UB152','U154','Q0','UQ0','FT','UFT','N0','U0','NZ','UZ')
    policies={policy:copy.deepcopy(selection['政策'][policy]) for policy in direct}
    legacy={row['case_id']:row for row in policies['C1']}
    assert set(legacy)==members['C1'] and len(legacy)==len(policies['C1'])
    fields=('case_id','session','side','stream','event_id','feature_ref','q0_time','q0_index','q0_line')
    for union,new in [('UB152','B152'),('UQ0','Q0'),('UFT','FT'),('U0','N0'),('UZ','NZ')]:
        fresh={row['case_id']:row for row in policies[new]};combined={row['case_id']:row for row in policies[union]}
        assert len(fresh)==len(policies[new]) and len(combined)==len(policies[union])
        assert set(combined)==set(legacy)|set(fresh)
        for key,row in combined.items():
            expected=legacy[key] if key in legacy else fresh[key]
            assert all(row.get(field)==expected.get(field) for field in fields)
    q={row['case_id']:row for row in policies['Q0']};ft={row['case_id']:row for row in policies['FT']}
    native={row['case_id']:row for row in policies['N0']};assert set(native)==set(q)|set(ft)
    for key,row in native.items():
        expected=q[key] if key in q else ft[key]
        assert all(row.get(field)==expected.get(field) for field in fields)
    fixed={row['case_id']:row for row in policies['U154']}
    assert len(fixed)==len(policies['U154']) and set(legacy)<=set(fixed)
    for key,row in legacy.items():assert all(fixed[key].get(field)==row.get(field) for field in fields)
    policies['C0']=[row for row in policies['C1'] if row['case_id'] in members['C0']]
    for dest,source in [('RC1','C1'),('RQ0','Q0'),('RU0','U0')]:
        policies[dest]=[{**row,'side':-row['side'],'stream':'reverse' if row['stream']=='original' else 'original',
            'origin':dest,'counterfactual_reverse':True,'reverse_of_policy':source,
            'source_selected_side':row['side'],'source_selected_stream':row['stream']} for row in policies[source]]
    for policy,rows in policies.items():
        seen=set()
        for row in rows:
            key=row['case_id'];assert key not in seen;seen.add(key);record=output[key]
            assert record['session']==row['session'] and row['stream'] in ('original','reverse')
            assert row['side']==record['case'][row['stream']]['birth']['side']
            record['choices'][policy]=row
    if strict:assert len(policies['C0'])==81 and len(legacy)==87 and len(selection['全73場'])==73
    return output

def prior152_check(values: dict,prior: dict) -> dict:
    """
    機能: 旧152B0/U1を155固定別名B152/UB152へ全統計で照合する。
    引数: values/prior(dict)。返り値: dictは120条件/統計セル数。
    """
    count=cells=0
    for part in ('all','train','validation'):
        for policy,old in [('B152','B0'),('UB152','U1')]:
            for axis in AXES:
                for horizon in HORIZONS:
                    for width in WIDTHS:
                        actual=values[part][policy][axis][str(horizon)][str(width)]
                        expected=prior['集計'][part][old][axis][str(horizon)][str(width)]
                        assert actual==expected,(part,policy,old,axis,horizon,width)
                        count+=1;cells+=len(actual)
    assert count==120
    return {'成功':True,'旧試行':152,'政策対応':{'B152':'B0','UB152':'U1'},'全統計同体':True,'条件数':count,'統計セル数':cells}

def prior154_check(values: dict,prior: dict) -> dict:
    """
    機能: 旧154U30を155の固定U154へ全60条件・統計辞書同体で照合する。
    引数: values/prior(dict)。返り値: dictは条件数と統計セル数。
    """
    count=cells=0
    for part in ('all','train','validation'):
        for axis in AXES:
            for horizon in HORIZONS:
                for width in WIDTHS:
                    actual=values[part]['U154'][axis][str(horizon)][str(width)]
                    expected=prior['集計'][part]['U30'][axis][str(horizon)][str(width)]
                    assert actual==expected,(part,axis,horizon,width)
                    count+=1;cells+=len(actual)
    assert count==60
    return {'成功':True,'旧試行':154,'政策対応':{'U154':'U30'},'条件数':count,'統計セル数':cells,'全統計同体':True}



def cumulative_step(previous: dict,stats: dict) -> dict:
    """
    機能: 既知小計を累積し、一度未知があれば全件確定差引をnullに保つ。
    引数: previous(dict)、stats(dict)。返り値: dict。
    """
    profit=previous.get('累計既知利益',0)+(stats['ifd_net5_profit']or 0);loss=previous.get('累計既知損失絶対',0)+(stats['ifd_net5_loss']or 0);unknown=previous.get('累計IFD未知',0)+stats['ifd_unknown'];net=profit-loss
    return {'累計既知利益':profit,'累計既知損失絶対':loss,'累計既知差引':net,'累計IFD未知':unknown,'累計全件確定差引':net if unknown==0 else None}


def tables(records: dict,sessions: list,values: dict,p: dict,f: dict,overlaps: dict,selection: dict,meta: dict,parent,arith) -> tuple:
    """
    機能: 960比較・時刻順U0取得・累計を含む全73場をtyped3表にする。
    引数: records/values/p/f/overlaps/selection/meta(dict)、sessions(list)、parent/arith(ModuleType)。返り値: tuple[list,dict]。
    """
    comparisons=[]
    for part in ('all','train','validation'):
        for policy in POLICIES:
            for axis in AXES:
                for h in HORIZONS:
                    for w in WIDTHS:
                        s=values[part][policy][axis][str(h)][str(w)];rate=s['target70'];frequency=f[part][policy]['全時間取得毎時'];present=p[part][policy]['全場最低1取得'];kind='旧152固定対照'if policy in ('B152','UB152')else '旧固定対照'if policy in ('C0','C1','RC1')else '旧154固定対照'if policy=='U154'else '量方向による補正と独立順行'
                        comparisons.append([155,part,policy,kind,axis,h/60,w,p[part][policy]['対象場数'],s['sessions'],s['entries'],s['flips'],present,s['complete'],s['censored'],s['forward'],s['adverse'],s['neither'],s['resolved_rate'],s['complete_rate'],s['forward']/s['entries']if s['entries']else None,rate,present and rate if rate is not None else None,frequency,f[part][policy]['名目新規可時間毎時'],frequency>=1 if frequency is not None else None,present and rate and frequency>=1 if rate is not None and frequency is not None else None,s['ifd_known'],s['ifd_unknown'],s['ifd_net0_sum'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],s['ifd_net5_mean'],s['ifd_net5_pf']])
    descriptor={d['case_id']:d for d in meta['population148']['cases']};old_c0={e['id']for e in meta['entries']if e.get('baseline')is True};n0={x['case_id']:x for x in selection['政策']['N0']};conflicts={x['case_id']:x['opposite']for x in selection['旧C1重複']['U0']};details=[]
    ordered=sorted(selection['政策']['U0'],key=lambda r:(records[r['case_id']]['case']['original']['entry']['time'],records[r['case_id']]['case']['original']['entry']['index'],records[r['case_id']]['case']['original']['entry']['source_line'],r['case_id']))
    for choice in ordered:
        record=records[choice['case_id']];case=record['case'];q=case['original']['entry'];d=descriptor[choice['case_id']];hit=n0.get(choice['case_id']);stream=selected(record,'U0','BBO')
        row=[155,'train'if record['session']in sessions[:48]else 'validation',record['session'],record['scene']['contract'],choice['case_id'],'旧C1'if choice['origin']=='C1'else '新N0',choice['origin'],choice['case_id']in old_c0,choice['side'],case['original_side'],choice['stream'],d['buy_stream'],d['sell_stream'],choice['event_id'],choice['feature_ref'],arith.jst(choice['q0_time'])if choice.get('q0_time')is not None else None,choice.get('q0_index'),choice.get('q0_line'),'|'.join(choice.get('成立ID',[])),'|'.join(hit.get('成立ID',[]))if hit else None,conflicts.get(choice['case_id']),arith.jst(q['time']),q['index'],q['source_line'],q['last'],q['bid'],q['ask'],stream['entry_price'],choice['origin']=='C1']
        for policy in ('U0','RU0'):
            c=selected(record,policy,'BBO');o=arith.observation(c,3600);t=arith.touch(o,125);e=arith.ifd(c,o,125,'BBO');row.extend([c['birth']['side'],o['status'],t['direction'],t['direction']if o['status']=='complete'else None,arith.jst(t['quote']['time'])if t['quote']else None,e['known'],e['reason'],arith.jst(e['exit']['time'])if e['exit']else None,e['net5']])
        details.append(row)
    scene_rows=[];curves={policy:{}for policy in ('U0','N0','C1')};previous={policy:{}for policy in curves}
    for index,sid in enumerate(sessions):
        scene=next(r['scene']for r in records.values()if r['session']==sid);hours=(scene['end']-300-scene['start'])/3600;available=(min(scene['force_close'],scene['end']-3900)-scene['start'])/3600;counts={policy:len(parent.subset(records,policy,[sid]))for policy in POLICIES};ov=overlaps['all']['U0']['場別'][sid]
        row=[155,sid,'train'if index<48 else 'validation',hours,available,*[counts[policy]for policy in POLICIES],counts['U0']/hours,counts['N0']/hours,counts['U0']>0,ov['連結群数'],ov['最大群件数']]
        for policy in curves:
            s=arith.stats(parent.subset(records,policy,[sid]),policy,'BBO',3600,125);row.extend([s['forward'],s['adverse'],s['neither'],s['censored'],s['ifd_known'],s['ifd_unknown'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum']]);previous[policy]=cumulative_step(previous[policy],s);curves[policy][sid]=previous[policy]
        for policy in curves:row.extend(curves[policy][sid][key]for key in CUMULATIVE_FIELDS)
        scene_rows.append(row)
    result=[{'name':'正逆比較','headers':parent.COMPARISON_HEADERS,'rows':comparisons},{'name':'入口別診断','headers':DETAIL_HEADERS,'rows':details},{'name':'全セッション','headers':SCENE_HEADERS,'rows':scene_rows}]
    assert len(comparisons)==960 and len(scene_rows)==73
    for table in result:
        assert len(set(table['headers']))==len(table['headers'])and all(len(row)==len(table['headers'])for row in table['rows'])
        assert all(v is None or type(v)in (str,bool,int,float)and(not isinstance(v,float)or math.isfinite(v))for row in table['rows']for v in row)
    return result,curves


def _declared(freeze: dict) -> dict:
    """
    機能: 固定票の相対/絶対pathを研究ルート基準で統一する。
    引数: freeze(dict)。返り値: dict[str,str]。
    """
    return {str((Path(path)if Path(path).is_absolute()else ROOT/Path(path)).resolve()):value for path,value in freeze['ファイル'].items()}


def verify_freezes(f1_path: Path,f1_sha: str,f2_path: Path,f2_sha: str,selection_path: Path,selection_sha: str) -> tuple:
    """
    機能: 選択後F1と金融前F2を別票として選択参照まで結合検査する。
    引数: f1_path/f2_path/selection_path(Path)、f1_sha/f2_sha/selection_sha(str)。返り値: tuple[dict,dict]。
    """
    f1=load(f1_path,f1_sha);f2=load(f2_path,f2_sha)
    assert f1.get('成功') is True and f2.get('成功') is True and f1.get('試行')==f2.get('試行')==155
    assert f1_path.resolve()!=f2_path.resolve()and f1_sha!=f2_sha
    declared1,declared2=_declared(f1),_declared(f2);selection_key=str(selection_path.resolve())
    assert declared1[selection_key]==declared2[selection_key]==selection_sha and declared2[str(f1_path.resolve())]==f1_sha
    return f1,f2


def main() -> None:
    """
    機能: 別F1/F2と運転停止後のRoot通知でのみ固定選択の金融集計を行う。
    引数: CLI preparation-sha256/f1/f1-sha256/f2/f2-sha256/selection/selection-sha256/generation-dir/result/result-sha256/result-decoded-sha256/output-dir。返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--preparation-sha256',required=True)
    for name in ('f1','f2','selection','generation-dir','result','output-dir'):parser.add_argument('--'+name,required=True,type=Path)
    for name in ('f1-sha256','f2-sha256','selection-sha256','result-sha256'):parser.add_argument('--'+name,required=True)
    parser.add_argument('--result-decoded-sha256',default=OBS_DECODED);args=parser.parse_args();args.output_dir=args.output_dir.resolve();prep_path=HERE/'準備の確認.json';assert sha(prep_path)==args.preparation_sha256;prep=json.loads(prep_path.read_bytes());assert prep['成功']and all(sha(ROOT/x['path'])==x['sha256']for x in prep['源'])
    assert all(sha(path)==value for path,value in SOURCES.items());verify_freezes(args.f1,args.f1_sha256,args.f2,args.f2_sha256,args.selection,args.selection_sha256)
    paths={name:next(p for p in (args.generation_dir/(name+'.json.gz'),args.generation_dir/(name+'.json'))if p.exists())for name in INPUTS};expected={p:INPUTS[name][0 if p.suffix=='.gz'else 1]for name,p in paths.items()};expected.update({**SOURCES,args.result:args.result_sha256,args.selection:args.selection_sha256,args.f1:args.f1_sha256,args.f2:args.f2_sha256,prep_path:args.preparation_sha256});assert all(sha(path)==value for path,value in expected.items());stat={str(path):[path.stat().st_size,path.stat().st_mtime_ns]for path in expected}
    # ----------------------------------------
    # 自然本文はRootの実行許可後にのみ読み、モデル学習/予測は呼びません。
    loaded={name:load(path,expected[path],INPUTS[name][1])for name,path in paths.items()};observed=load(args.result,args.result_sha256,args.result_decoded_sha256);selection=load(args.selection,args.selection_sha256);base=module(PREPARE,'fixed148for155finance');parent=module(PARENT,'fixed149for155finance');parent.POLICIES=POLICIES
    records,members,sessions,phase=base.prepare(observed,loaded['固定取得入力'],loaded['入口参照'],loaded['出生台帳'],loaded['取得対応']);assert sessions==selection['全73場'];records=bind_choices(records,members,selection);arith=module(ARITHMETIC,'fixed124for155finance');arith.selected=selected;arith.POLICIES=POLICIES
    values,p,f,goals,overlaps=parent.calculate(records,sessions,loaded['固定取得入力']['scenes'],arith);baseline=base.baseline_check(records,values,load(OLD_PAIRS,SOURCES[OLD_PAIRS],'3b92da8b447d7be9ead6a2a112759ca7272a1e65d6cb5516989e3faf50c54d62'),load(OLD_SUMMARY,SOURCES[OLD_SUMMARY]),members);result_tables,curves=tables(records,sessions,values,p,f,overlaps,selection,loaded['入口参照'],parent,arith);prior_check=prior152_check(values,load(PRIOR152,SOURCES[PRIOR152]));prior154=prior154_check(values,load(PRIOR154,SOURCES[PRIOR154]))
    out={'成功':True,'試行':155,'主政策':'U0','主幅pt':125,'主H秒':3600,'主評価':goals['all']['U0'],'新資格へ予測又は旧152_154選択を渡す':False,'補助aliasは金融政策外':True,'集計':values,'参加':p,'頻度':f,'重複連結群と場集中':overlaps,'場別累計':curves,'候補と取得':selection['候補と取得'],'旧C1重複':selection['旧C1重複'],'旧C1同体':baseline,'旧152_B0_U1同体':prior_check,'旧154_U30同体':prior154,'全4stream_phase':phase,'運用収支':False,'実IFD':False,'全期既使用':True,
        'F1_SHA256':args.f1_sha256,'F2_SHA256':args.f2_sha256,'F1の意味':'155全q0方向判断と取得結合後の固定','F2の意味':'実金融集計の直前固定','選択対応SHA256':args.selection_sha256,'観測物理SHA256':args.result_sha256,'観測解凍SHA256':args.result_decoded_sha256,'集計準備SHA256':args.preparation_sha256,'旧152対照は継承151モデル由来':True,'155で新学習又は再予測':False,'主CMFバッファ':.05,'比較CMFバッファ':0,'CMFとOBVは同じ量役割':True,'現場未来教師で取得を選択':False,'金融で再学習又は再予測':False,
        '実逆metadata':{'RC1':'C1の同q1反対BBO側','RU0':'U0の同q1反対BBO側','RQ0':'Q0の同q1反対BBO側','反対予測の再生成':False,'元選択evidenceの向きは出典として保持':True},'限界':['主a=.05のU0をa=0のUZや単独枝へ結果後交換しない','152固定対照は過去学習由来だが155全新q0を先判断し旧選択は後結合','累計IFD未知>0なら全件確定差引null','同時IFD合計は運用口座収支ではない','名目H60連結群は独立標本数ではない']}
    assert all(sha(path)==value for path,value in expected.items())and stat=={str(path):[path.stat().st_size,path.stat().st_mtime_ns]for path in expected};args.output_dir.mkdir(parents=True,exist_ok=True)
    for name,value in [('集計.json',out),('CSV用の表.json',{'成功':True,'試行':155,'主政策':'U0','tables':result_tables})]:
        with (args.output_dir/name).open('x',encoding='utf-8')as target:json.dump(value,target,ensure_ascii=False,indent=2,allow_nan=False);target.write('\n')
    with (args.output_dir/'集計完了.json').open('x',encoding='utf-8')as target:json.dump({'成功':True,'前後不変':True,'解凍ファイル書出':False,'F1_SHA256':args.f1_sha256,'F2_SHA256':args.f2_sha256,'前後SHA256':{str(path):value for path,value in expected.items()},'三表形状':[[len(t['rows']),len(t['headers'])]for t in result_tables],'集計SHA256':sha(args.output_dir/'集計.json'),'表SHA256':sha(args.output_dir/'CSV用の表.json'),'CSV又はmarker実行':False},target,ensure_ascii=False,indent=2);target.write('\n')
    print(json.dumps({'成功':True,'主評価':goals['all']['U0'],'三表形状':[[len(t['rows']),len(t['headers'])]for t in result_tables]},ensure_ascii=False))


if __name__=='__main__':
    main()
