"""自然155本文なしで16政策・同q1実逆・旧対照・累計と三表を確認する。"""
from pathlib import Path
import copy
import gzip
import hashlib
import importlib.util
import json
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def module(path: Path,name: str):
    """
    機能: 自然mainを実行せず人工fixtureと停止した算術を読む。
    引数: path(Path)、name(str)。返り値: ModuleType。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


m=module(HERE/'集計する.py','finance155test')
previous=module(ROOT/'work/154回帰環境の金融集計/人工検査.py','fixture154for155')


def merge(first: list,second: list) -> list:
    """
    機能: 人工参照をcaseごとに先頭政策優先で結合する。
    引数: first/second(list[dict])。返り値: list[dict]。
    """
    combined={row['case_id']:copy.deepcopy(row) for row in second}
    combined.update({row['case_id']:copy.deepcopy(row) for row in first})
    return list(combined.values())


def fixture(empty: bool=False) -> tuple:
    """
    機能: 旧87保護とQ0/FT重複のある16政策を純人工で用意する。
    引数: empty(bool)。返り値: tupleはrecords/場/固定/選択/meta/算術/members。
    """
    records,sessions,fixed,old,meta,parent,arith,members=previous.fixture(empty)
    policies={p:copy.deepcopy(old['政策'][p]) for p in ('C1','B152','UB152')}
    policies['U154']=copy.deepcopy(old['政策']['U30'])
    policies['Q0']=copy.deepcopy(old['政策']['N30']);policies['FT']=copy.deepcopy(old['政策']['V30'])
    for row in policies['Q0']:row['origin']='Q0'
    for row in policies['FT']:row['origin']='FT'
    policies['N0']=merge(policies['Q0'],policies['FT']);policies['NZ']=copy.deepcopy(policies['N0'])
    legacy={row['case_id']:row for row in policies['C1']};overlaps={}
    for union,new in [('UQ0','Q0'),('UFT','FT'),('U0','N0'),('UZ','NZ')]:
        policies[union]=merge(policies['C1'],policies[new])
        overlaps[union]=[{'case_id':r['case_id'],'opposite':r['side']!=legacy[r['case_id']]['side']} for r in policies[new] if r['case_id'] in legacy]
    selection={'成功':True,'試行':155,'選択時の金融ラベル利用':False,'政策':policies,
        '旧C1重複':overlaps,'候補と取得':{},'全73場':sessions}
    parent.POLICIES=m.POLICIES;arith.POLICIES=m.POLICIES;arith.selected=m.selected
    return m.bind_choices(records,members,selection),sessions,fixed,selection,meta,parent,arith,members


class Tests(unittest.TestCase):
    """自然選択も金融本文も開かない最小の8主群。"""

    def test_960三表と同q1三実逆(self) -> None:
        """
        機能: 960比較と主時刻順・73場累計、3実逆の物理側を確認する。
        引数: self(Tests)。返り値: None。
        """
        records,sessions,fixed,selection,meta,parent,arith,_=fixture()
        values,p,f,_,overlaps=parent.calculate(records,sessions,fixed['scenes'],arith)
        tables,curves=m.tables(records,sessions,values,p,f,overlaps,selection,meta,parent,arith)
        self.assertEqual([(len(t['rows']),len(t['headers'])) for t in tables],[(960,34),(88,47),(73,68)])
        self.assertEqual(records['人工00/0']['choices']['U0']['side'],-1)
        for source,inverse in [('C1','RC1'),('Q0','RQ0'),('U0','RU0')]:
            for record in records.values():
                if source not in record['choices']:continue
                a,b=record['choices'][source],record['choices'][inverse]
                self.assertEqual(a['side'],-b['side']);self.assertNotEqual(a['stream'],b['stream'])
        self.assertEqual(curves['U0'][sessions[-1]]['累計既知差引'],values['all']['U0']['BBO']['3600']['125']['ifd_net5_sum'])
        times=[r[tables[1]['headers'].index('取得JST')] for r in tables[1]['rows']];self.assertEqual(times,sorted(times))

    def test_固定152と154を全180条件照合(self) -> None:
        """
        機能: 旧B152/UB152とU154全条件を比較し、一統計差も拒否する。
        引数: self(Tests)。返り値: None。
        """
        records,sessions,fixed,_,_,parent,arith,_=fixture();values,*_=parent.calculate(records,sessions,fixed['scenes'],arith)
        a={'集計':{part:{old:copy.deepcopy(v[new]) for old,new in [('B0','B152'),('U1','UB152')]} for part,v in values.items()}}
        b={'集計':{part:{'U30':copy.deepcopy(v['U154'])} for part,v in values.items()}}
        self.assertEqual(m.prior152_check(values,a)['条件数'],120);self.assertEqual(m.prior154_check(values,b)['条件数'],60)
        a['集計']['validation']['B0']['Last']['1800']['25']['entries']+=1
        b['集計']['all']['U30']['BBO']['3600']['125']['ifd_net5_sum']+=1
        with self.assertRaises(AssertionError):m.prior152_check(values,a)
        with self.assertRaises(AssertionError):m.prior154_check(values,b)

    def test_空新群でも旧87と全73維持(self) -> None:
        """
        機能: 空政策の率をnullとし、Last金額と全73場を保持する。
        引数: self(Tests)。返り値: None。
        """
        records,sessions,fixed,selection,meta,parent,arith,_=fixture(True)
        values,p,f,_,overlaps=parent.calculate(records,sessions,fixed['scenes'],arith)
        tables,_=m.tables(records,sessions,values,p,f,overlaps,selection,meta,parent,arith)
        self.assertEqual(values['all']['N0']['BBO']['3600']['125']['entries'],0)
        self.assertIsNone(values['all']['N0']['BBO']['3600']['125']['resolved_rate'])
        self.assertEqual(p['all']['N0']['取得場数'],0);self.assertEqual(len(tables[2]['rows']),73)
        self.assertIsNone(values['all']['U0']['Last']['3600']['125']['ifd_net5_sum'])

    def test_C1優先破壊と同政策重複を拒否(self) -> None:
        """
        機能: 全unionの旧保護・固定U154保護とcase一意性を検査する。
        引数: self(Tests)。返り値: None。
        """
        records,_,_,selection,_,_,_,members=fixture()
        for policy in ('UB152','U154','UQ0','UFT','U0','UZ'):
            bad=copy.deepcopy(selection);bad['政策'][policy][0]['side']*=-1
            with self.assertRaises(AssertionError):m.bind_choices(records,members,bad)
        bad=copy.deepcopy(selection);bad['政策']['Q0'].append(copy.deepcopy(bad['政策']['Q0'][0]))
        with self.assertRaises(AssertionError):m.bind_choices(records,members,bad)

    def test_Q0優先でFTは旧側へ取直さない(self) -> None:
        """
        機能: Q0/FT同case逆方向でもQ0を優先し、誤ったN0は拒否する。
        引数: self(Tests)。返り値: None。
        """
        records,_,_,selection,_,_,_,members=fixture()
        q=selection['政策']['Q0'][0];ft={**copy.deepcopy(q),'side':-q['side'],'stream':'reverse' if q['stream']=='original' else 'original','origin':'FT'}
        selection['政策']['FT']=[ft];selection['政策']['UFT']=merge(selection['政策']['C1'],[ft])
        accepted=m.bind_choices(records,members,selection)
        self.assertEqual(accepted[q['case_id']]['choices']['N0']['side'],q['side'])
        bad=copy.deepcopy(selection);row=next(r for r in bad['政策']['N0'] if r['case_id']==q['case_id']);row.update(ft)
        with self.assertRaises(AssertionError):m.bind_choices(records,members,bad)

    def test_H不足touchと費用1077と未知累計(self) -> None:
        """
        機能: 不足でも既知touchを残し、未知累積後の確定差引をnullへ保つ。
        引数: self(Tests)。返り値: None。
        """
        records,_,_,_,_,_,arith,_=fixture();record=records['人工00/0'];observed=m.selected(record,'U0','BBO')
        observed['outcomes'][1]['status']='censored';observed['outcomes'][1]['endpoint']=None
        stats=arith.stats([record],'U0','BBO',3600,125)
        self.assertEqual((stats['complete'],stats['ifd_known'],stats['ifd_net5_sum']),(0,1,12500-1077))
        first=m.cumulative_step({},{'ifd_net5_profit':10,'ifd_net5_loss':0,'ifd_unknown':1})
        second=m.cumulative_step(first,{'ifd_net5_profit':20,'ifd_net5_loss':5,'ifd_unknown':0})
        self.assertEqual(second['累計既知差引'],25);self.assertIsNone(second['累計全件確定差引'])

    def test_F1F2別票とgzip末尾(self) -> None:
        """
        機能: 固定票入替・同票・CRC破損・解凍指紋不一致を拒否する。
        引数: self(Tests)。返り値: None。
        """
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);selection=root/'選択.json';selection.write_bytes(b'{}');h=m.sha(selection)
            f1,f2=root/'F1.json',root/'F2.json'
            f1.write_text(json.dumps({'成功':True,'試行':155,'ファイル':{str(selection):h}}),encoding='utf-8');a=m.sha(f1)
            f2.write_text(json.dumps({'成功':True,'試行':155,'ファイル':{str(selection):h,str(f1):a}}),encoding='utf-8')
            m.verify_freezes(f1,a,f2,m.sha(f2),selection,h)
            with self.assertRaises(AssertionError):m.verify_freezes(f1,a,f1,a,selection,h)
            with self.assertRaises((AssertionError,KeyError)):m.verify_freezes(f2,m.sha(f2),f1,a,selection,h)
            path=root/'人工.json.gz';raw='{"日本語":true}'.encode('utf-8');path.write_bytes(gzip.compress(raw,mtime=0))
            self.assertEqual(m.load(path,m.sha(path),hashlib.sha256(raw).hexdigest()),{'日本語':True})
            with self.assertRaises(AssertionError):m.load(path,m.sha(path),'0'*64)
            body=bytearray(path.read_bytes());body[-8]^=1;path.write_bytes(body)
            with self.assertRaises((OSError,EOFError)):m.load(path,m.sha(path))

    def test_変換副作用なしと主16政策固定(self) -> None:
        """
        機能: 元選択を変更せず、a0比較を主へ足さない16政策契約を確認する。
        引数: self(Tests)。返り値: None。
        """
        records,_,_,selection,_,_,_,members=fixture();before=copy.deepcopy(selection)
        m.bind_choices(records,members,selection);self.assertEqual(selection,before)
        self.assertEqual(len(m.POLICIES),16);self.assertNotIn('NB0',m.POLICIES)
        self.assertEqual(set(m.POLICIES),{'C0','C1','RC1','B152','UB152','U154','Q0','RQ0','UQ0','FT','UFT','N0','U0','RU0','NZ','UZ'})


if __name__=='__main__':
    unittest.main(verbosity=2)
