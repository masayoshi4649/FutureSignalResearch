"""自然155本文を開かず、8人工と154由来の同体を準備停止する。"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import tempfile

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: 実行源の小ファイルを物理SHA256へ写す。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def module(path: Path,name: str):
    """
    機能: 自然mainを呼ばず、実行源の関数定義だけを読む。
    引数: path(Path)、name(str)。返り値: ModuleType。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


def function_ast(path: Path,name: str) -> str:
    """
    機能: 指定関数を位置情報なしASTへ写し継承算術を確認する。
    引数: path(Path)、name(str)。返り値: str。
    """
    tree=ast.parse(path.read_text(encoding='utf-8'));node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
    return ast.dump(node,include_attributes=False)


def main() -> None:
    """
    機能: 自然入力を開かず人工/構文/由来を固定し準備票と停止票を作る。
    引数: なし。返り値: None。
    """
    assert not (HERE/'準備の確認.json').exists() and not (HERE/'停止.json').exists()
    source=module(HERE/'集計する.py','finance155prepare')
    parent=module(source.ANCESTOR154,'finance154inputs')
    assert source.INPUTS==parent.INPUTS and source.OBS_DECODED==parent.OBS_DECODED and len(source.POLICIES)==16
    deferred=(source.PRIOR152,source.PRIOR154,source.OLD_PAIRS,source.OLD_SUMMARY)
    paths=list(HERE.glob('*.py'))+[HERE/'条件.md',ROOT/'work/155採用条件のRoot通知.md']
    paths += [p for p in source.SOURCES if p not in deferred]
    paths += [ROOT/'work'/folder/'人工検査.py' for folder in ('154回帰環境の金融集計','153独立出生の金融集計','152複合回復の金融集計','151過去場判別の金融集計','150構造状態の金融集計','148母集団の診断集計')]
    paths=list(dict.fromkeys(paths));before={p:sha(p) for p in paths}
    assert all(before[p]==h for p,h in source.SOURCES.items() if p not in deferred)
    for path in HERE.glob('*.py'):
        tree=ast.parse(path.read_text(encoding='utf-8'));compile(tree,str(path),'exec')
        for node in ast.walk(tree):
            if isinstance(node,ast.FunctionDef):
                doc=ast.get_docstring(node);assert doc and '\n' in doc and all(s in doc for s in ('機能','引数','返り値')),(path.name,node.name)
    same={name:function_ast(HERE/'集計する.py',name)==function_ast(source.ANCESTOR154,name) for name in ('sha','load','module','selected','cumulative_step','_declared')}
    assert all(same.values())
    maker=module(HERE/'由来を作る.py','finance155derive')
    with tempfile.TemporaryDirectory() as directory:
        maker.HERE=Path(directory);maker.main();assert (maker.HERE/'集計する.py').read_bytes()==(HERE/'集計する.py').read_bytes()
    result=subprocess.run([sys.executable,'-X','utf8',str(HERE/'人工検査.py')],cwd=ROOT,capture_output=True,
        env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'})
    out,error=result.stdout.decode('utf-8','strict'),result.stderr.decode('utf-8','strict')
    assert result.returncode==0 and '\ufffd' not in out+error and 'Ran 8 tests' in error
    assert before=={p:sha(p) for p in paths}
    proof={'成功':True,'試行':155,'自然155採否_容量_金融':False,'自然特徴_新数量_選択_観測_旧金融の本文読取':False,
        '新Raw_CSV_追加2場_新学習_再予測':False,'人工主数':8,'UTF8_strict_構文_関数コメント':True,
        '154基本6関数AST同体':same,'154からの最小派生bytes再現':True,'全源前後同体':True,
        '源':[{'path':p.relative_to(ROOT).as_posix(),'sha256':h,'bytes':p.stat().st_size} for p,h in before.items()],
        '後段のみ読む金融正本':[{'path':p.relative_to(ROOT).as_posix(),'sha256':source.SOURCES[p],'準備時の物理bytes読取':False} for p in deferred],
        '三表契約':{'正逆比較':[960,34],'入口別診断':['U0可変・旧87保護',47],'全セッション':[73,68]},
        '固定対照':{'152B0_U1':[120,2880],'154U30':[60,1440]},'主':'U0','全場累計':['U0','N0','C1'],
        '独立性':'作者154/153/152/149/124継承、Root141別算術とは別。',
        '人工結果':{'終了値':result.returncode,'標準出力':out,'標準エラー':error}}
    ready=HERE/'準備の確認.json';ready.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    stop={'成功':True,'編集停止':True,'試行':155,'自然未実行':True,'準備SHA256':sha(ready),'自源':{p.name:h for p,h in before.items() if p.parent==HERE}}
    (HERE/'停止.json').write_text(json.dumps(stop,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'成功':True,'準備SHA256':sha(ready),'停止SHA256':sha(HERE/'停止.json'),'集計SourceSHA256':sha(HERE/'集計する.py')},ensure_ascii=False))


if __name__=='__main__':
    main()
