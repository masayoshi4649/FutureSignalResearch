"""停止154の金融算術・型付き三表を155の固定政策へ最小派生する。"""
from pathlib import Path
import hashlib
import re

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def replace_function(text: str,name: str,replacement: str) -> str:
    """
    機能: 指定関数だけを明示した本文へ置き換える。
    引数: text/name/replacement(str)。返り値: str。
    """
    pattern=re.compile(r'(?ms)^def '+re.escape(name)+r'\(.*?(?=^def |^if __name__)')
    result,count=pattern.subn(lambda _:replacement+'\n\n',text);assert count==1
    return result


def main() -> None:
    """
    機能: 154停止源を155の政策・主U0と固定対照だけへ適合する。
    引数: なし。返り値: None。自然入力・選択・観測本文を開かない。
    """
    original=ROOT/'work/154回帰環境の金融集計/集計する.py'
    raw=original.read_bytes();assert hashlib.sha256(raw).hexdigest()=='b826a0b79230c3033e35bc05d10c7600e1beaa947af67f6c60853a2662c7b52b'
    text=raw.decode('utf-8').replace('\r\n','\n')
    start=text.index('ANCESTOR153=');end=text.index('INPUTS=',start)
    text=text[:start]+"""ANCESTOR154=ROOT/'work/154回帰環境の金融集計/集計する.py'
PRIOR154=ROOT/'study/00154_回帰で進行と往復を分けて短期回復から入る/成果物/集計.json'
SOURCES[ANCESTOR154]='b826a0b79230c3033e35bc05d10c7600e1beaa947af67f6c60853a2662c7b52b'
SOURCES[PRIOR154]='41b160e6918b7bdd58e8fcacf857ca036cb5f93720bde617d0c062169fe0deef'
"""+text[end:]
    text=text.replace('154回帰環境の固定選択を共有正逆へ結合し1020比較','155方向付き数量の固定選択を共有正逆へ結合し960比較')
    text=re.sub(r'(?<![\w])154(?![\w])','155',text)
    # ----------------------------------------
    # 由来の154パスと固定対照名は置換せず、新主U0/N0だけを切り替える。
    text=text.replace('for154finance','for155finance').replace('U30','U0').replace('RU30','RU0').replace('N30','N0')
    text=text.replace('1020','960').replace('回帰環境と短期回復','量方向による補正と独立順行')
    begin=text.index('POLICIES=');finish=text.index('\n',begin)
    text=text[:begin]+"POLICIES=('C0','C1','RC1','B152','UB152','U154','Q0','RQ0','UQ0','FT','UFT','N0','U0','RU0','NZ','UZ')"+text[finish:]
    text=text.replace("else '旧153固定対照'if policy in ('U153','R0','RR0')","else '旧154固定対照'if policy=='U154'")
    text=replace_function(text,'bind_choices','''def bind_choices(records: dict,members: dict,selection: dict,strict: bool=True) -> dict:
    """
    機能: 155固定政策をQ0優先/C1優先で検査し同q1実逆を派生する。
    引数: records/members/selection(dict)、strict(bool)。返り値: dict。
    """
    assert selection['成功'] and selection['試行']==155 and selection['選択時の金融ラベル利用'] is False
    output={key:{**record,'choices':{}} for key,record in records.items()}
    direct=('C1','B152','UB152','U154','Q0','UQ0','FT','UFT','N0','U0','NZ','UZ')
    policies={policy:copy.deepcopy(selection['政策'][policy]) for policy in direct}
    legacy={row['case_id']:row for row in policies['C1']}
    assert set(legacy)==members['C1'] and len(legacy)==len(policies['C1'])
    fields=('case_id','session','side','stream','event_id','feature_ref','q0_time','q0_index','q0_line')
    for union,new in [('UB152','B152'),('UQ0','Q0'),('UFT','FT'),('U0','N0'),('UZ','NZ')]:
        fresh={row['case_id']:row for row in policies[new]};combined={row['case_id']:row for row in policies[union]}
        assert len(fresh)==len(policies[new]) and len(combined)==len(policies[union])
        assert set(combined)==set(legacy)|set(fresh)
        for key,row in combined.items():
            expected=legacy[key] if key in legacy else fresh[key]
            assert all(row.get(field)==expected.get(field) for field in fields)
    q={row['case_id']:row for row in policies['Q0']};ft={row['case_id']:row for row in policies['FT']}
    native={row['case_id']:row for row in policies['N0']};assert set(native)==set(q)|set(ft)
    for key,row in native.items():
        expected=q[key] if key in q else ft[key]
        assert all(row.get(field)==expected.get(field) for field in fields)
    fixed={row['case_id']:row for row in policies['U154']}
    assert len(fixed)==len(policies['U154']) and set(legacy)<=set(fixed)
    for key,row in legacy.items():assert all(fixed[key].get(field)==row.get(field) for field in fields)
    policies['C0']=[row for row in policies['C1'] if row['case_id'] in members['C0']]
    for dest,source in [('RC1','C1'),('RQ0','Q0'),('RU0','U0')]:
        policies[dest]=[{**row,'side':-row['side'],'stream':'reverse' if row['stream']=='original' else 'original',
            'origin':dest,'counterfactual_reverse':True,'reverse_of_policy':source,
            'source_selected_side':row['side'],'source_selected_stream':row['stream']} for row in policies[source]]
    for policy,rows in policies.items():
        seen=set()
        for row in rows:
            key=row['case_id'];assert key not in seen;seen.add(key);record=output[key]
            assert record['session']==row['session'] and row['stream'] in ('original','reverse')
            assert row['side']==record['case'][row['stream']]['birth']['side']
            record['choices'][policy]=row
    if strict:assert len(policies['C0'])==81 and len(legacy)==87 and len(selection['全73場'])==73
    return output''')
    text=replace_function(text,'prior153_check','''def prior154_check(values: dict,prior: dict) -> dict:
    """
    機能: 旧154U30を155の固定U154へ全60条件・統計辞書同体で照合する。
    引数: values/prior(dict)。返り値: dictは条件数と統計セル数。
    """
    count=cells=0
    for part in ('all','train','validation'):
        for axis in AXES:
            for horizon in HORIZONS:
                for width in WIDTHS:
                    actual=values[part]['U154'][axis][str(horizon)][str(width)]
                    expected=prior['集計'][part]['U30'][axis][str(horizon)][str(width)]
                    assert actual==expected,(part,axis,horizon,width)
                    count+=1;cells+=len(actual)
    assert count==60
    return {'成功':True,'旧試行':154,'政策対応':{'U154':'U30'},'条件数':count,'統計セル数':cells,'全統計同体':True}''')
    text=replace_function(text,'prior_rr0_check','')
    text=text.replace("prior153=prior153_check(values,load(PRIOR153,SOURCES[PRIOR153]));priorrr=prior_rr0_check(values,load(RR153,SOURCES[RR153],RR153_DECODED))","prior154=prior154_check(values,load(PRIOR154,SOURCES[PRIOR154]))")
    text=text.replace("'旧153_U15_R0同体':prior153,'旧153_R0実逆同体':priorrr,","'旧154_U30同体':prior154,")
    text=text.replace("'新資格へ予測又は旧152_153選択を渡す':False","'新資格へ予測又は旧152_154選択を渡す':False")
    text=text.replace("'RR0':'R0の同q1反対BBO側'","'RQ0':'Q0の同q1反対BBO側'")
    text=text.replace("'主U0をU15/U60や単独枝へ結果後交換しない'","'主a=.05のU0をa=0のUZや単独枝へ結果後交換しない'")
    text=text.replace("'152固定対照は過去学習由来だが154新資格へ予測を渡さない'","'152固定対照は過去学習由来だが155全新q0を先判断し旧選択は後結合'")
    text=text.replace('154固定別名','155固定別名').replace('154全q0方向判断','155全q0方向判断')
    text=text.replace("'154で新学習又は再予測':False","'155で新学習又は再予測':False,'主CMFバッファ':.05,'比較CMFバッファ':0,'CMFとOBVは同じ量役割':True")
    assert 'PRIOR153' not in text and 'RR153' not in text and 'priorrr' not in text
    target=HERE/'集計する.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')


if __name__=='__main__':
    main()
