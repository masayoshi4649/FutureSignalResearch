"""155の事前固定した数量分岐を、元方向と同q1実逆で分解する。"""
from collections import Counter
from pathlib import Path
import argparse
import importlib.util
import json
import math

ROOT = Path(__file__).resolve().parent.parent
GROUPS = ('量未知で維持', '強い反対なしで維持', '反転確認で反転', '強い反対だが待機')
ADDITIVE = ('entries', 'complete', 'censored', 'forward', 'adverse', 'neither',
            'resolved', 'ifd_known', 'ifd_unknown', 'ifd_net0_sum',
            'ifd_net5_sum', 'ifd_net5_profit', 'ifd_net5_loss', 'ifd_net5_positive', 'flips')


def load_helper() -> object:
    """
    機能: Rootの独立読取・向き対応と、固定141算術だけを読み込む。
    引数: なし。返り値: objectはRootの155独立照合モジュール。
    """
    path = ROOT / 'work/155量方向による金融集計を独立に照合する.py'
    spec = importlib.util.spec_from_file_location('診断155の独立参照', path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    return helper


# ----------------------------------------
def group_of(action: dict) -> str:
    """
    機能: 結果を参照せず保存済みactionを相互排他的な4群へ分類する。
    引数: action(dict)。返り値: strは事前固定した群名。
    """
    names = {
        ('keep', 'quantity_unknown_keep'): GROUPS[0],
        ('keep', 'no_strong_opposition_keep'): GROUPS[1],
        ('flip', 'strong_opposition_confirmed'): GROUPS[2],
        ('wait', 'strong_opposition_confirmation_missing'): GROUPS[3],
    }
    return names[(action['action'], action['reason'])]


# ----------------------------------------
def main() -> None:
    """
    機能: 主a=.05の4分岐を全/前48/後25で元・実逆・採用側に分解する。
    引数: CLI summary/output(Path)。返り値: None。新条件・新政策を選ばない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--summary', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    helper = load_helper()
    own = ROOT / 'work/155量方向による入口の評価'
    paths = {
        'selection': own / '入口選択/選択対応.json',
        'f1': own / 'F1入口選択後.json',
        'summary': args.summary,
        'observation': ROOT / 'study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz',
    }
    before = {key: helper.sha(path) for key, path in paths.items()}
    assert before['observation'] == 'bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61'
    selection, f1, summary, observations = [helper.load_json(paths[key])
        for key in ('selection', 'f1', 'summary', 'observation')]
    assert selection['試行'] == f1['試行'] == summary['試行'] == 155
    assert f1['ファイル'][paths['selection'].relative_to(ROOT).as_posix()] == before['selection']
    sessions = selection['全73場']
    assert len(sessions) == len(set(sessions)) == 73
    cases = {case['id']: (scene['session'], case)
             for scene in observations['scenes'] for case in scene['cases']}
    policies = selection['政策']
    base = {row['case_id']: row for row in policies['B152']}
    chosen = {row['case_id']: row for row in policies['Q0']}
    actions = {row['case_id']: row for row in selection['B152へのq0action']['Q0']}
    assert len(base) == len(actions) == 614 and set(base) == set(actions)
    assert set(chosen) == {key for key, action in actions.items() if action['action'] != 'wait'}
    for key, action in actions.items():
        assert action['source_side'] == base[key]['side']
        assert action['source_stream'] == base[key]['stream']
        assert action['event_id'] == base[key]['event_id']
        if key in chosen:
            assert chosen[key]['side'] == action['side']
            assert chosen[key]['source_B152_ref'] == base[key]
    mathematics = helper.load_math()

    def calculate(refs: list, reverse: bool = False) -> dict:
        """
        機能: 取得側streamを原側へ写して141の同q1実BBO算術で集計する。
        引数: refs(list[dict])、reverse(bool)。返り値: dictは主H60±125統計。
        """
        rows = []
        for ref in refs:
            sid, case = cases[ref['case_id']]
            assert sid == ref['session'] and case[ref['stream']]['birth']['side'] == ref['side']
            rows.append((sid, helper.orient(case, ref['stream'])))
        stats = mathematics.calculate(rows, reverse, 'BBO', 3600, 125)
        stats['flips'] = sum((ref['stream'] == 'reverse') != reverse for ref in refs)
        return stats

    result = {}
    checks = 0
    for part, targets in (('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])):
        selected_ids = {key for key, ref in base.items() if ref['session'] in set(targets)}
        result[part] = {}
        for name in GROUPS:
            ids = sorted(key for key in selected_ids if group_of(actions[key]) == name)
            original = [base[key] for key in ids]
            adopted = [chosen[key] for key in ids if key in chosen]
            per_scene = Counter(ref['session'] for ref in original)
            result[part][name] = {
                '件数': len(ids), '取得場数': len(per_scene),
                '最多場件数': max(per_scene.values(), default=0), '場別': dict(per_scene),
                'B152元方向': calculate(original), 'B152同q1実逆': calculate(original, True),
                'Q0採用方向': calculate(adopted), 'Q0同q1実逆': calculate(adopted, True),
            }
        assert sum(row['件数'] for row in result[part].values()) == len(selected_ids)
        for column, policy in (('B152元方向', 'B152'), ('Q0採用方向', 'Q0')):
            expected = summary['集計'][part][policy]['BBO']['3600']['125']
            for key in ADDITIVE:
                total = sum(row[column][key] or 0 for row in result[part].values())
                target = expected[key]
                assert math.isclose(total, target or 0, rel_tol=1e-12, abs_tol=1e-8), (part, column, key)
                checks += 1
    attribution = {}
    for policy in ('N0', 'U0'):
        attribution[policy] = dict(Counter(row['origin'] for row in policies[policy]))
    assert all(helper.sha(path) == before[key] for key, path in paths.items())
    output = {
        '成功': True, '試行': 155, '主CMFバッファ': .05,
        '群の定義': list(GROUPS), '全前後の分岐診断': result,
        '主と新規の採用origin': attribution, '元と採用の加法照合数': checks,
        '新政策又は新閾値の採用': False, '作者124算術import': False,
        '入力': {str(paths[key].resolve()): value for key, value in before.items()},
    }
    with args.output.open('x', encoding='utf-8', newline='\n') as sink:
        json.dump(output, sink, ensure_ascii=False, indent=2, allow_nan=False)
        sink.write('\n')
    print(json.dumps({'成功': True, '分岐': list(GROUPS), '加法照合数': checks}, ensure_ascii=False))


if __name__ == '__main__':
    main()
