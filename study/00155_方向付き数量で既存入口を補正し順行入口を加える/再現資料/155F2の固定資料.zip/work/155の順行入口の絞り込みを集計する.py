"""155の固定判断からFTの条件ごとの既知性と事前順序の通過数を集計する。"""
from collections import Counter
from pathlib import Path
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parent.parent
CHECKS = ('common', 'cmf_support', 'obv_support', 'same_r_volume_at_least1',
          'ema21_delta30_positive', 'hist_level_positive', 'hist_delta_positive',
          'r_body_positive', 'current_p_open_reclaim', 'last_at_or_beyond_r_close',
          'entry_ema8_lower0', 'entry_ema8_upper1')


def sha(path: Path) -> str:
    """
    機能: 入力を分割読取して物理指紋を計算する。
    引数: path(Path)。返り値: strはSHA256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def rows(path: Path):
    """
    機能: indent2で保存したq0配列を1件ずつ復号し大型副本を作らない。
    引数: path(Path)。返り値: Iterator[dict]はrows配列の各要素。
    """
    inside = False
    buffer = None
    with path.open('r', encoding='utf-8') as source:
        for line in source:
            if not inside:
                if line.rstrip() == '  "rows": [':
                    inside = True
                continue
            if buffer is None:
                if line.rstrip() == '  ]':
                    break
                assert line.rstrip() == '    {'
                buffer = [line]
            else:
                buffer.append(line)
                if line.rstrip() in ('    },', '    }'):
                    yield json.loads(''.join(buffer).rstrip().removesuffix(','))
                    buffer = None
    assert inside and buffer is None


# ----------------------------------------
def main() -> None:
    """
    機能: FTの単条件真偽/未知と固定順累積通過を全/前48/後25で集計する。
    引数: CLI output(Path)。返り値: None。閾値変更や新入口選別は行わない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    own = ROOT / 'work/155量方向による入口の評価'
    q0 = own / '入口選択/q0の判断.json'
    selection_path = own / '入口選択/選択対応.json'
    f1_path = own / 'F1入口選択後.json'
    before = {path: sha(path) for path in (q0, selection_path, f1_path)}
    f1 = json.loads(f1_path.read_bytes())
    for path in (q0, selection_path):
        assert f1['ファイル'][path.relative_to(ROOT).as_posix()] == before[path]
    selection = json.loads(selection_path.read_bytes())
    sessions = selection['全73場']
    assert len(sessions) == len(set(sessions)) == 73
    front = set(sessions[:48])
    counters = {}
    births = Counter()
    seen = set()
    for row in rows(q0):
        assert row['event_id'] not in seen
        seen.add(row['event_id'])
        part = 'train' if row['session'] in front else 'validation'
        for area in ('all', part):
            for side in ('1', '-1'):
                key = area + '/' + side
                current = counters.setdefault(key, {'件数': 0, '単条件': {c: Counter() for c in CHECKS},
                                                    '固定順の全条件通過数': Counter()})
                current['件数'] += 1
                passed = True
                values = row['technical'][side]['FT']['main']['checks']
                assert set(values) == set(CHECKS)
                for check in CHECKS:
                    value = values[check]
                    assert value is None or type(value) is bool
                    current['単条件'][check]['未知' if value is None else '真' if value else '偽'] += 1
                    passed = passed and value is True
                    current['固定順の全条件通過数'][check] += int(passed)
                assert passed == (row['technical'][side]['FT']['main']['pass'] is True)
        for rule in ('FT', 'FTZ'):
            births[rule] += int(row['decision']['directions'][rule] != 0)
    assert len(seen) == 35339
    for rule in ('FT', 'FTZ'):
        assert births[rule] == selection['候補と取得'][rule]['born']
    assert all(sha(path) == value for path, value in before.items())
    result = {'成功': True, '試行': 155, 'q0数': len(seen), '条件の集計順': list(CHECKS),
              '単条件と固定順通過': counters, 'q0成立数': dict(births),
              '固定順の限界': '通過数の減少は順序依存の会計で、指標単独の効果や因果ではない。',
              '新条件採用又は金融読取': False,
              '入力': {path.relative_to(ROOT).as_posix(): value for path, value in before.items()}}
    with args.output.open('x', encoding='utf-8', newline='\n') as sink:
        json.dump(result, sink, ensure_ascii=False, indent=2, allow_nan=False)
        sink.write('\n')
    print(json.dumps({'成功': True, 'q0': len(seen), '成立数': dict(births)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
