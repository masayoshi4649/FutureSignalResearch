"""固定B152を量の水準・窓変化・短長OBVで事後分解し、採用規則は変更しない。"""
from collections import Counter
from pathlib import Path
import argparse
import importlib.util
import itertools
import json
import math

ROOT = Path(__file__).resolve().parent.parent
LEVELS = ('支持', '中立帯', '反対', '未知')
CHANGES = ('正', '零', '負', '未知')
TOTAL_KEYS = ('entries', 'complete', 'censored', 'forward', 'adverse', 'neither',
              'ifd_known', 'ifd_unknown', 'ifd_net5_sum', 'ifd_net5_profit', 'ifd_net5_loss')


def sign(value: float | None) -> str:
    """
    機能: 生値の正/零/負と未知を丸めず区別する。
    引数: value(float|None)。返り値: strは4分類。
    """
    if value is None:
        return '未知'
    assert math.isfinite(value)
    return '正' if value > 0 else '負' if value < 0 else '零'


# ----------------------------------------
def main() -> None:
    """
    機能: 元614取得を固定した2つの16群で原/実逆と期間集中を事後診断する。
    引数: CLI output(Path)。返り値: None。新売買条件や主政策は採用しない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    path = ROOT / 'work/155量方向による金融集計を独立に照合する.py'
    spec = importlib.util.spec_from_file_location('量変化診断155の独立参照', path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    own = ROOT / 'work/155量方向による入口の評価'
    paths = {
        '選択': own / '入口選択/選択対応.json',
        '正本': own / '金融評価/集計.json',
        '数量': ROOT / 'inputs/00155_方向付き数量の測定/方向付き数量の入力.json.gz',
        '観測': ROOT / 'study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz',
    }
    before = {key: helper.sha(path) for key, path in paths.items()}
    assert before['数量'] == '947dd612858e5560debe0c350c73eda2a12d821f515bd6f9627c2040676901d3'
    assert before['観測'] == 'bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61'
    selection, summary, quantity, observed = [helper.load_json(paths[key])
        for key in ('選択', '正本', '数量', '観測')]
    assert selection['試行'] == summary['試行'] == 155
    measurements = {row['event_id']: row for scene in quantity['scenes'] for row in scene['rows']}
    cases = {case['id']: (scene['session'], case)
             for scene in observed['scenes'] for case in scene['cases']}
    sessions = selection['全73場']
    refs = selection['政策']['B152']
    assert len(refs) == len({row['case_id'] for row in refs}) == 614
    labelled = []
    for ref in refs:
        row = measurements[ref['event_id']]
        side = ref['side']
        current = row['cmf20']['current']
        cmf = side * current['value'] if current['value_defined'] else None
        level = '未知' if cmf is None else '支持' if cmf > .05 else '反対' if cmf < -.05 else '中立帯'
        delta = side * row['cmf20']['delta'] if row['cmf20']['delta_known'] else None
        obv = {str(w): sign(side * row['obv'][str(w)]['change'])
               if row['obv'][str(w)]['window_known'] else '未知' for w in (5, 15)}
        labelled.append((ref, {'CMF水準と同q0窓変化': (level, sign(delta)),
                               'OBV15とOBV5': (obv['15'], obv['5'])}))
    definitions = {'CMF水準と同q0窓変化': list(itertools.product(LEVELS, CHANGES)),
                   'OBV15とOBV5': list(itertools.product(CHANGES, CHANGES))}
    mathematics = helper.load_math()
    result = {}
    checked = 0
    for part, targets in (('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])):
        area = [(ref, group) for ref, group in labelled if ref['session'] in set(targets)]
        result[part] = {}
        for axis, groups in definitions.items():
            output = {}
            for group in groups:
                selected = [ref for ref, labels in area if labels[axis] == group]
                streams = []
                counts = Counter()
                for ref in selected:
                    sid, case = cases[ref['case_id']]
                    assert sid == ref['session'] and case[ref['stream']]['birth']['side'] == ref['side']
                    counts[sid] += 1
                    streams.append((sid, helper.orient(case, ref['stream'])))
                output['/'.join(group)] = {
                    '件数': len(selected), '場数': len(counts), '最大場件数': max(counts.values(), default=0),
                    '場別': dict(counts),
                    '元': mathematics.calculate(streams, False, 'BBO', 3600, 125),
                    '同q1実逆': mathematics.calculate(streams, True, 'BBO', 3600, 125),
                }
            assert sum(row['件数'] for row in output.values()) == len(area)
            expected = summary['集計'][part]['B152']['BBO']['3600']['125']
            for key in TOTAL_KEYS:
                total = sum(row['元'][key] or 0 for row in output.values())
                assert math.isclose(total, expected[key] or 0, rel_tol=1e-12, abs_tol=1e-8), (part, axis, key)
                checked += 1
            result[part][axis] = output
    assert all(helper.sha(path) == before[key] for key, path in paths.items())
    output = {'成功': True, '試行': 155, '事後診断': True, '新政策採用': False,
              '分類': {'CMF水準': list(LEVELS), '符号': list(CHANGES), '中立帯': '[-.05,.05]包含',
                       'CMF変化': '同じq0知得prefixで20本窓を1分ずらした差。過去q0公表値との差や真の資金流入ではない。'},
              '全前後の数量群': result, '加法照合数': checked,
              '独立141算術': True, 'Raw_追加2場_新条件検証': False,
              '限界': '同場依存・全期既使用・32群の事後比較。良い群をそのまま採用せず、次試行と区別する。',
              '入力': {paths[key].relative_to(ROOT).as_posix(): value for key, value in before.items()}}
    with args.output.open('x', encoding='utf-8', newline='\n') as sink:
        json.dump(output, sink, ensure_ascii=False, indent=2, allow_nan=False)
        sink.write('\n')
    print(json.dumps({'成功': True, '加法照合数': checked, '1区分あたり群数': 32}, ensure_ascii=False))


if __name__ == '__main__':
    main()
