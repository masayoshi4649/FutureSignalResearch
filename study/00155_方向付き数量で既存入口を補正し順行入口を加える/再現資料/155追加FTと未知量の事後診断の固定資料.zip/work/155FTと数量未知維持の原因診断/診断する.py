"""固定FT実逆と数量未知維持17件を別算術・当時入力だけで診断する。"""
from collections import Counter
import copy
import datetime
import hashlib
import importlib.util
import json
import math
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
RUNTIME=ROOT/'work/155量方向による入口の評価'
MATH=ROOT/'work/141金融集計を独立に確認する.py'
MATH_SHA='30bd4aef8c2809699cb013f930cfbce152f3986fe8d3d3cc6b49452104c2269e'
OBS=ROOT/'study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz'
OBS_SHA='bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61'
OBS_DECODED='d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'


def sha(path: Path) -> str:
    """
    機能: 入力を複写せず全物理SHAを得る。
    引数: path(Path)。返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1048576),b''):h.update(block)
    return h.hexdigest()


# ----------------------------------------
def load(path: Path,name: str):
    """
    機能: 独立141算術又は過去の自作読取helperだけを読取importする。
    引数: path(Path)、name(str)。返り値: module。
    """
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


# ----------------------------------------
def state(value: object) -> str:
    """
    機能: 診断用に数値の符号と未知を分ける。
    引数: value(object)。返り値: str。
    """
    return '未知' if value is None else '正' if value>0 else '負' if value<0 else '0'


# ----------------------------------------
def quality(bars: dict,row: dict,width: int,obv: bool) -> dict:
    """
    機能: 元q0までの厳密窓で価格/量の原因足を別に取り出す。
    引数: bars(dict)、row(dict)、width(int)、obv(bool)。返り値: dict。
    """
    r=bars[row['r_ref']];by_start={b['start']:b for b in bars.values()};end=r['end'];start=end-width*60
    price_positions=[start+i*60 for i in range(-1 if obv else 0,width)]
    volume_positions=[start+i*60 for i in range(width)]
    result={}
    for name,positions,flag in [('価格',price_positions,'price_known'),('量',volume_positions,'volume_known')]:
        bad=[]
        for at in positions:
            b=by_start.get(at)
            if b is None:bad.append({'start':at,'理由':['場先頭不足又はslot不在']});continue
            assert b['end']<=r['end'] and all(x<=y for x,y in zip(stamp(b['stamp']),stamp(row['q0'])))
            reasons=[k for k,failed in [('missing',b['missing']),('未closed',not b['closed']),('unknown',not b[flag])] if failed]
            if reasons:bad.append({'id':b['id'],'start':b['start'],'end':b['end'],'理由':reasons})
        result[name]={'既知':not bad,'原因足':bad}
    return result


# ----------------------------------------
def stamp(x: dict) -> tuple:
    """
    機能: q0とbarの物理行表記を揃える。
    引数: x(dict)。返り値: tuple。
    """
    return x['time'],x['index'],x.get('line',x.get('source_line'))


# ----------------------------------------
def compare(expected: dict,actual: dict) -> int:
    """
    機能: 統計全キーを数値許容差とnull保持で照合する。
    引数: expected/actual(dict)。返り値: int比較数。
    """
    assert set(expected)==set(actual)
    for k,v in expected.items():
        if isinstance(v,float):assert math.isclose(v,actual[k],rel_tol=1e-12,abs_tol=1e-8),(k,v,actual[k])
        else:assert v==actual[k],(k,v,actual[k])
    return len(expected)


# ----------------------------------------
def main() -> None:
    """
    機能: 固定17件の当時状態を先に整理し、FT45と共に保存正逆を診断する。
    引数: なし。返り値: None。新選択/Raw/追加2場を読まない。
    """
    assert not (HERE/'診断.json').exists() and sha(MATH)==MATH_SHA
    readers_path=ROOT/'work/方向付き数量の自然独立確認/監査する.py'
    oldreader_path=ROOT/'work/154現在価格と回復足の独立診断/診断する.py'
    readers=load(readers_path,'own_quantity_reader155cause');oldreader=load(oldreader_path,'own_obs_reader155cause')
    math141=load(MATH,'independent141_155cause')
    book_path=ROOT/'work/155量方向による入口/条件.json';book=json.loads(book_path.read_text(encoding='utf-8'))
    paths={'book':book_path,'selection':RUNTIME/'入口選択/選択対応.json','f1':RUNTIME/'F1入口選択後.json',
           'f2':RUNTIME/'F2金融前.json','summary':RUNTIME/'金融評価/集計.json','Root分岐診断':RUNTIME/'維持反転待機の診断.json',
           '範囲':HERE/'範囲.md','math141':MATH,'観測':OBS,'reader数量':readers_path,'reader観測':oldreader_path}
    for name,key in [('特徴','features'),('価格','range_input'),('数量','quantity_input')]:
        ref=book['features_source'][key] if name=='特徴' else book[key];paths[name]=ROOT/ref['path']
    before={name:(sha(p),p.stat().st_size,p.stat().st_mtime_ns) for name,p in paths.items()}
    assert before['観測'][0]==OBS_SHA
    selection=json.loads(paths['selection'].read_text(encoding='utf-8'));f1=json.loads(paths['f1'].read_text(encoding='utf-8'))
    assert f1['ファイル'][paths['selection'].relative_to(ROOT).as_posix()]==before['selection'][0]
    ft=selection['政策']['FT'];unknown=[r for r in selection['政策']['Q0'] if r['q0_action']['reason']=='quantity_unknown_keep']
    assert len(ft)==45 and len(unknown)==17 and len({r['event_id'] for r in unknown})==17
    refs={r['event_id']:r for r in unknown};sessions=selection['全73場'];details={};evidence={'価格':{},'数量':{},'特徴':{},'観測':{}}
    for price,qty in zip(readers.scenes(paths['価格'],evidence['価格']),readers.scenes(paths['数量'],evidence['数量']),strict=True):
        assert price['session']==qty['session'];bars={b['id']:b for b in price['bars']}
        for row,qrow in zip(price['rows'],qty['rows'],strict=True):
            assert row['event_id']==qrow['event_id']
            if row['event_id'] not in refs:continue
            ref=refs[row['event_id']];r=bars[row['r_ref']];q=row['q0'];side=ref['side']
            assert stamp(q)==(ref['q0_time'],ref['q0_index'],ref['q0_line']) and stamp(r['stamp'])==stamp(q)
            assert ref['q0_action']['action']=='keep' and side==ref['source_selected_side']
            obv=qrow['obv']['15'];cmf=qrow['cmf20']['current'];obvq=quality(bars,row,15,True);cmfq=quality(bars,row,20,False)
            assert obv['window_known']==(obvq['価格']['既知'] and obvq['量']['既知'])
            assert cmf['window_known']==(cmfq['価格']['既知'] and cmfq['量']['既知'])
            elapsed=q['time']-price['start'];o=r['ohlc'];p=bars.get(row['slot_refs'][-2]) if len(row['slot_refs'])>=2 else None
            details[row['event_id']]={'case_id':ref['case_id'],'event_id':row['event_id'],'session':price['session'],'side':side,'stream':ref['stream'],
                'q0':q,'r_ref':r['id'],'r':{k:r[k] for k in ('start','end','available_at','ohlc','price_known','closed')},
                'p_ref':p['id'] if p else None,'場開始':price['start'],'開始後秒':elapsed,'開始後分':elapsed/60,
                'q0日本時刻':datetime.datetime.fromtimestamp(q['time'],datetime.timezone(datetime.timedelta(hours=9))).isoformat(),
                'CMF20':cmf,'OBV15':obv,'数量原因':{'CMF20':cmfq,'OBV15':obvq},
                'CMF未定義':not cmf['value_defined'],'OBV差未知':not obv['window_known'],
                '構造':{'r実体符号':state(side*(o['close']-o['open'])),'Last対r始値':side*(q['last']-o['open']),
                         'Last対r逆端':side*(q['last']-o['low' if side==1 else 'high']),
                         'Last対r終値':side*(q['last']-o['close'])},'元Base参照':{'event_id':ref['source_B152_ref']['event_id'],'side':ref['source_selected_side'],'stream':ref['source_selected_stream']}}
    assert set(details)==set(refs)
    feature_names=[]
    catalog=json.loads((ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json').read_text(encoding='utf-8'));names=[c['name'] for c in catalog]
    for w in (5,15,30):feature_names.extend(f'm{w}_{tail}' for tail in ('ema21_delta_to_side','di_difference_to_side','adx','adx_delta','hist_to_side','hist_delta_to_side','rsi_center_to_side','rsi_delta_to_side'))
    feature_names.extend(['m1_body_ratio_to_side','m1_body_reclaim_atr5_to_side','q0_last_minus_m1_close_atr5_to_side',
        'q0_entry_minus_ema8_atr5_to_side','q0_entry_minus_ema21_atr5_to_side','bb15_forward_room_125_ratio_to_side',
        'q0_entry_prior3_percent_to_side','q0_last_minus_prior3_forward_edge_atr5_to_side','m1_volume_relative_prior3','m5_atr'])
    ix={k:i for i,k in enumerate(names)};found=set()
    for feature in oldreader.array(paths['特徴'],'rows',evidence['特徴']):
        eid=feature['event_id']
        if eid not in details:continue
        d=details[eid];vector=feature['buy' if d['side']==1 else 'sell']['x'];d['当時特徴']={k:vector[ix[k]] for k in feature_names}
        assert stamp(feature['metadata']['q0'])==stamp(d['q0']);found.add(eid)
    assert found==set(details)
    wanted={r['case_id'] for r in ft+unknown};cases={}
    for scene in oldreader.array(OBS,'scenes',evidence['観測']):
        for case in scene['cases']:
            if case['id'] in wanted:cases[case['id']]=(scene['session'],case)
    assert set(cases)==wanted and evidence['観測']['decoded_sha256']==OBS_DECODED
    def calculate(group: list,part: list,reverse: bool) -> dict:
        """
        機能: 保存された選択streamを元向きに射影し、同q1実逆を141算術で得る。
        引数: group(list[dict])、part(list[str])、reverse(bool)。返り値: dict。
        """
        values=[];flips=0
        for ref in group:
            if ref['session'] not in part:continue
            sid,case=cases[ref['case_id']];assert sid==ref['session'];swapped=ref['stream']=='reverse'
            oriented={**case,'original':case['reverse' if swapped else 'original'],'reverse':case['original' if swapped else 'reverse']}
            assert oriented['original']['birth']['side']==ref['side'];values.append((sid,oriented));flips+=int(not swapped if reverse else swapped)
        result=math141.calculate(values,reverse,'BBO',3600,125);result['flips']=flips;return result
    finance={};parts={'all':sessions,'train':sessions[:48],'validation':sessions[48:]}
    for part,sids in parts.items():
        finance[part]={key:{'元':calculate(group,sids,False),'実逆':calculate(group,sids,True)} for key,group in [('FT45',ft),('数量未知維持17',unknown)]}
    summary=json.loads(paths['summary'].read_text(encoding='utf-8'));rootcause=json.loads(paths['Root分岐診断'].read_text(encoding='utf-8'));checks=0
    for part in parts:
        checks+=compare(finance[part]['FT45']['元'],summary['集計'][part]['FT']['BBO']['3600']['125'])
        checks+=compare(finance[part]['数量未知維持17']['元'],rootcause['全前後の分岐診断'][part]['量未知で維持']['Q0採用方向'])
        checks+=compare(finance[part]['数量未知維持17']['実逆'],rootcause['全前後の分岐診断'][part]['量未知で維持']['Q0同q1実逆'])
    reason_counts=Counter();signs={};time_ranges={}
    for d in details.values():
        reason_counts['CMFのみ' if d['CMF未定義'] and not d['OBV差未知'] else 'OBVのみ' if d['OBV差未知'] and not d['CMF未定義'] else '両方']+=1
        for key,value in d['当時特徴'].items():signs.setdefault(key,Counter())[state(value)]+=1
        time_ranges.setdefault(d['session'],[]).append(d['開始後分'])
    assert before=={name:(sha(p),p.stat().st_size,p.stat().st_mtime_ns) for name,p in paths.items()}
    result={'成功':True,'試行':'固定155の事後診断','入力':{k:{'path':paths[k].relative_to(ROOT).as_posix(),'SHA256':v[0],'bytes':v[1]} for k,v in before.items()},
        '141独立算術SHA256':MATH_SHA,'金融':finance,'正本とRoot診断の同体キー':checks,'数量未知維持全17対応':True,
        '17個別':list(details.values()),'未知の組合せ':dict(reason_counts),'当時特徴の符号':{k:dict(v) for k,v in signs.items()},
        '場別開始後分':{k:{'件数':len(v),'最小':min(v),'最大':max(v)} for k,v in time_ranges.items()},'入力全指紋前後同体':True,
        '全gzip_CRC_解凍':evidence,'作者124_155金融_原因金融算術import':False,'新規則_閾値_取得_原板_追加2場':False,
        'コードSHA256':sha(Path(__file__))}
    (HERE/'診断.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'FT全期':finance['all']['FT45'],'未知組合せ':dict(reason_counts),'時刻':result['場別開始後分'],'照合キー':checks},ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':main()
