"""Rootの金融・独立・CSV終了後だけ、固定155本文を保って結果を追記する。"""
from pathlib import Path
import argparse
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
FORMAL=ROOT/'study/00155_方向付き数量で既存入口を補正し順行入口を加える'
EVALUATION=ROOT/'work/155量方向による入口の評価'
CSV=ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/155_方向付き数量の補正'
POLICIES=('C0','C1','RC1','B152','UB152','U154','Q0','RQ0','UQ0','FT','UFT','N0','U0','RU0','NZ','UZ')
GROUPS=('量未知で維持','強い反対なしで維持','反転確認で反転','強い反対だが待機')
STATUS='**準備中・F0未固定。自然155売買・容量・金融は未実行。**'
MARKER='## 155 実行結果（F0固定本文は当時記録として保持）'


def sha(path: Path) -> str:
    """
    機能: 小型文書・金融正本・CSVの物理指紋を求める。
    引数: path(Path)。返り値: str。
    """
    digest=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()


def number(value,decimals: int=0) -> str:
    """
    機能: 未知を0へ補わず、表示桁だけ整える。
    引数: value(int|float|None)、decimals(int)。返り値: str。
    """
    if value is None:return '未定義'
    assert type(value) in (int,float) and math.isfinite(value)
    return f'{value:,.{decimals}f}'


def rate(value) -> str:
    """
    機能: 率の未知と百分率表示を分ける。
    引数: value(float|None)。返り値: str。
    """
    return '未定義' if value is None else number(value*100,4)+'%'


def verdict(value) -> str:
    """
    機能: 未知判定を不合格や0%に置き換えない。
    引数: value(bool|None)。返り値: str。
    """
    assert value is None or type(value) is bool
    return '未定義' if value is None else '達成' if value else '未達'


def stats(data: dict,part: str,policy: str) -> dict:
    """
    機能: 主軸H60±125実BBOの固定統計だけを参照する。
    引数: data(dict)、part/policy(str)。返り値: dict。
    """
    return data['集計'][part][policy]['BBO']['3600']['125']


def policy_table(data: dict,part: str) -> str:
    """
    機能: 全16政策の件数・率・利益損失と未知を同じ分母で表示する。
    引数: data(dict)、part(str)。返り値: str。
    """
    out=['| 政策 | 取得 | 順/逆/未/不足 | 到達済率 | C5利益円 | C5損失絶対円 | C5既知差引円 | IFD未知 |',
         '| --- | ---: | --- | ---: | ---: | ---: | ---: | ---: |']
    for policy in POLICIES:
        s=stats(data,part,policy);counts='/'.join(str(s[k]) for k in ('forward','adverse','neither','censored'))
        out.append(f"| {policy} | {s['entries']} | {counts} | {rate(s['resolved_rate'])} | {number(s['ifd_net5_profit'])} | {number(s['ifd_net5_loss'])} | {number(s['ifd_net5_sum'])} | {s['ifd_unknown']} |")
    return '\n'.join(out)


def goals(data: dict,part: str='all') -> dict:
    """
    機能: 率・全場・頻度の判定を表示用に独立計算し、主正本と照合する。
    引数: data(dict)、part(str)。返り値: dict。
    """
    s=stats(data,part,'U0');p=data['参加'][part]['U0'];f=data['頻度'][part]['U0']
    resolved=s['forward']+s['adverse'];target=10*s['forward']>=7*resolved if resolved else None
    frequent=f['全時間取得毎時']>=1 if f['全時間取得毎時'] is not None else None
    result={'全場最低1':p['全場最低1取得'],'到達済70%':target,'全時間毎時1以上':frequent,
        '三目標共同':p['全場最低1取得'] and target and frequent if target is not None and frequent is not None else None}
    if part=='all':assert result==data['主評価']
    return result


def diagnosis_table(diagnosis: dict) -> str:
    """
    機能: 保存された4分岐を前後別に示し、待機の仮想利益を機会損失へしない。
    引数: diagnosis(dict)。返り値: str。
    """
    out=['| 区分 | 分岐 | B152対象 | 対象場 | Q0採用 | Q0順/逆/未/不足 | Q0 C5既知差引円 | IFD未知 |',
         '| --- | --- | ---: | ---: | ---: | --- | ---: | ---: |']
    for part in ('all','train','validation'):
        for group in GROUPS:
            row=diagnosis['全前後の分岐診断'][part][group];s=row['Q0採用方向']
            counts='/'.join(str(s[k]) for k in ('forward','adverse','neither','censored'))
            out.append(f"| {part} | {group} | {row['件数']} | {row['取得場数']} | {s['entries']} | {counts} | {number(s['ifd_net5_sum'])} | {s['ifd_unknown']} |")
    return '\n'.join(out)


def render(data: dict,diagnosis: dict,birth: dict=None) -> tuple:
    """
    機能: 保存正本から3文書用の結果本文を作り、新しい条件を採点しない。
    引数: data/diagnosis(dict)、birth(dict|None)。返り値: tuple[str,str,str]はREADME状態・全結果・短い追記。
    """
    assert data['成功'] and data['試行']==155 and data['主政策']=='U0'
    assert diagnosis['成功'] and diagnosis['試行']==155 and diagnosis['主CMFバッファ']==.05
    for part in ('all','train','validation'):assert set(data['集計'][part])==set(POLICIES)
    main=stats(data,'all','U0');new=stats(data,'all','N0');p=data['参加']['all']['U0'];f=data['頻度']['all']['U0'];g=goals(data)
    status=f"**実行済み。主U0の三条件共同は{verdict(g['三目標共同'])}。**"
    goal_lines=['| 目標 | 実測・分母 | 判定 |','| --- | --- | --- |',
        f"| 到達済70%以上 | {main['forward']}/({main['forward']}+{main['adverse']})={rate(main['resolved_rate'])} | {verdict(g['到達済70%'])} |",
        f"| 全対象場min1 | {p['取得場数']}/{p['対象場数']}場、最小{p['最小場件数']}・最大{p['最大場件数']}取得 | {verdict(g['全場最低1'])} |",
        f"| 全時間平均1回/時以上 | {main['entries']}/{number(f['全時間h'],6)}h={number(f['全時間取得毎時'],6)}回/時 | {verdict(g['全時間毎時1以上'])} |",
        f"| 三条件共同 | 上記を同時に判定 | **{verdict(g['三目標共同'])}** |"]
    front=stats(data,'train','U0');back=stats(data,'validation','U0');ov=data['重複連結群と場集中']['all']['U0']
    flip=diagnosis['全前後の分岐診断']['all']['反転確認で反転'];oldflip=flip['B152元方向'] if 'B152元方向' in flip else None
    waiting=diagnosis['全前後の分岐診断']['all']['強い反対だが待機'];oldwait=waiting.get('B152元方向')
    flip_text=''
    if oldflip is not None:
        adopted=flip['Q0採用方向']
        flip_text=f"同caseで実方向を変えた{flip['件数']}件は、旧元{oldflip['forward']}順{oldflip['adverse']}逆{oldflip['neither']}未{oldflip['censored']}不足・{rate(oldflip['resolved_rate'])}/C5既知差引{number(oldflip['ifd_net5_sum'])}円から、新側{adopted['forward']}順{adopted['adverse']}逆{adopted['neither']}未{adopted['censored']}不足・{rate(adopted['resolved_rate'])}/{number(adopted['ifd_net5_sum'])}円となった。量反対が元入口失敗の根拠になったとは確認できず、主の全体差を方向切替の改善と呼ばない。"
    if oldwait is not None:
        flip_text+=f" 待機{waiting['件数']}件の旧元方向は既存固定対照で{rate(oldwait['resolved_rate'])}だった。これは既に成立した旧取引との比較であり、未参加利益や待機の機会損失ではない。"
    ft=stats(data,'all','FT');birth_text=''
    if birth is not None:
        assert birth['成功'] and birth['試行']==155 and birth['q0数']==35339
        counts=[birth['単条件と固定順通過']['all/'+str(side)]['固定順の全条件通過数'] for side in (1,-1)]
        before_upper=sum(c['entry_ema8_lower0'] for c in counts);after_upper=sum(c['entry_ema8_upper1'] for c in counts)
        assert after_upper==birth['q0成立数']['FT']
        birth_text=f"独立FTの両側を合算した固定順通過は、実側EMA8距離上限の直前{before_upper}、≤1ATR5通過{after_upper}、取得{ft['entries']}件だった。FTは{ft['forward']}順{ft['adverse']}逆{ft['neither']}未{ft['censored']}不足・{rate(ft['resolved_rate'])}、C5既知差引{number(ft['ifd_net5_sum'])}円/未知{ft['ifd_unknown']}。この通過数の減少は順序依存の会計で、距離条件単独の因果や上限を外せば改善するという結果ではない。[FTの出生診断](根拠/FTの出生診断.json)に全q0/単条件/未知を保存し、条件を緩めて採用し直していない。"
    whole=policy_table(data,'all');train=policy_table(data,'train');validation=policy_table(data,'validation')
    text=f'''\n\n{MARKER}

Rootの選択/金融/独立960条件/CSV終了通知後に追記した。主U0/a=.05、比較a=0、固定閾値・旧対照・設定513セルは変更していない。先の「未実行」はF0当時の原文で、現在の状態はこの結果とREADME冒頭による。

### 全体・実BBO/H60±125

{whole}

主U0は{main['entries']}取得、{main['forward']}順{main['adverse']}逆{main['neither']}未到達{main['censored']}不足、到達済み{rate(main['resolved_rate'])}。H完了分母率{rate(main['complete_rate'])}、全取得分母率{rate(main['forward']/main['entries'] if main['entries'] else None)}を別に記録する。IFDは{main['ifd_known']}既知/{main['ifd_unknown']}未知、C5既知利益{number(main['ifd_net5_profit'])}円・損失絶対{number(main['ifd_net5_loss'])}円・差引{number(main['ifd_net5_sum'])}円。未知を0円としていない。

{chr(10).join(goal_lines)}

新N0は{new['entries']}取得・到達済{rate(new['resolved_rate'])}・C5既知差引{number(new['ifd_net5_sum'])}円/未知{new['ifd_unknown']}。旧C1を含む主U0と新枝単独の効果を同一視しない。C0/C1/RC1、B152/UB152、U154を固定対照として残す。a0のNZ/UZや成績の良い単独枝へ主を交換しない。

### 前48場（全期既使用の参考区分）

{train}

### 後25場（全期既使用の参考区分）

{validation}

主の前48は{rate(front['resolved_rate'])}・C5既知差引{number(front['ifd_net5_sum'])}円/未知{front['ifd_unknown']}、後25は{rate(back['resolved_rate'])}・{number(back['ifd_net5_sum'])}円/未知{back['ifd_unknown']}。全73場は既使用、152の事後診断を受けた着想で、前後期は独立未知期ではない。特定場の後付け除外や新閾値の採用をしていない。

### 量分岐の維持・実反転・待機を分ける

{diagnosis_table(diagnosis)}

Q0は量の未知/非反対で旧B152を維持し、強い反対時だけ反転確認又は待機へ分ける。未知keepを量支持へ置き換えていない。反転群は同じq1の実反対BBOで計算したもので、1−pではない。待機群の未採用IFDを機会損失として最適化せず、成立集合の違いを方向変更だけの効果とも呼ばない。独立FTとQ0の重複、C1優先は選択正本に保持する。CMF/OBVは同じ量役割の異なる記述で、複合結果を単独有効性や二つの独立票へ分解しない。

{flip_text}

元/同q1実逆/採用側の全統計は[維持反転待機の診断](根拠/維持反転待機の診断.json)、新採否へ転用しない共通知見は[量の逆向きと入口の失効を同一視しない](../../docs/議論/量の逆向きと入口の失効を同一視しない.md)に分けて残した。

{birth_text}

一般説明では、[StockChartsのADL解説](https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-indicators/accumulation-distribution-line)は足内終値位置×量と前終値比OBVの違いによりギャップ時に逆方向となり得ること、数量の乖離は警戒で価格の確認が別に必要なことを説明する（確認2026-11-12）。[FidelityのATR解説](https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/atr)のATRは非方向の値幅尺度であり、今回の「EMA8から1ATR以内」が普遍的な買い場・売り場であるという根拠ではなく、155で固定した研究仮定と区別する（確認2026-11-12）。

### 閲覧・依存・限界

[全セッションCSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/155_方向付き数量の補正/全セッション.csv)、[主入口別CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/155_方向付き数量の補正/入口別診断.csv)、[960比較CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/155_方向付き数量の補正/正逆比較.csv)を参照する。CSVは正本の転記で金融再計算ではなく、xlsxを作っていない。F0/F1/F2、保管・復元・閲覧の資料は別担当が保存する。

主の名目H60重複連結は{ov['連結群数']}群・最大{ov['最大群件数']}件、最多場{ov['最大場件数']}件、上位5場件数比{rate(ov['上位5場件数比'])}。これは独立標本数・実ポジション数ではない。独立mini1枚100円/pt・往復77円+C5追加1000円のIFD代用で、未知を伴う既知小計の累計と全件確定差引を分ける。可変枚数・保有制約・必須追尾の運用収支ではない。数量は観測足量の終値方向/位置への配分であり、真の攻撃側約定量・資金流入を測ったと断定しない。

旧29/42-43/47-48の未達、100特徴/旧モデル不変更、CSV知得モデルと実受信時計の限界、全期既使用を維持する。新しい仮説や採否はこの155の条件へ遡及しない。
'''
    short=f'''\n\n{MARKER}

F0当時の条件・設定513セルの全文prefixを保って結果だけ追記した。主U0/a=.05、a0比較・旧対照・閾値は不変更。{main['entries']}取得/{p['取得場数']}/{p['対象場数']}場、{main['forward']}順{main['adverse']}逆{main['neither']}未{main['censored']}不足、到達済{rate(main['resolved_rate'])}、平均{number(f['全時間取得毎時'],6)}回/時。三条件共同は{verdict(g['三目標共同'])}。

C5既知利益{number(main['ifd_net5_profit'])}円/損失絶対{number(main['ifd_net5_loss'])}円/差引{number(main['ifd_net5_sum'])}円、IFD未知{main['ifd_unknown']}。前48は{rate(front['resolved_rate'])}/{number(front['ifd_net5_sum'])}円、後25は{rate(back['resolved_rate'])}/{number(back['ifd_net5_sum'])}円。全/前48/後25・全16政策表、維持/反転/待機と旧対照は[README結果](README.md)を参照する。

全期既使用・事後着想、未知を0にしない独立mini1 IFD代用であり口座利益保護ではない。良い比較へ主交換せず、実逆を1−pで推定せず、待機の仮想利益を機会損失へしない。
'''
    return status,text,short


def ref_path(value: str) -> Path:
    """
    機能: jobの相対pathを研究ルートへ結び、絶対pathも保持する。
    引数: value(str)。返り値: Path。
    """
    path=Path(value);return (path if path.is_absolute() else ROOT/path).resolve()


def read_ref(ref: dict) -> tuple:
    """
    機能: 指定小JSONを期待SHA検査後に読み、stat不変を確認する。
    引数: ref(dict)はpath/sha256。返り値: tuple[Path,dict]。
    """
    path=ref_path(ref['path']);before=path.stat();assert sha(path)==ref['sha256'];body=path.read_bytes();after=path.stat()
    assert (before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns) and hashlib.sha256(body).hexdigest()==ref['sha256']
    return path,json.loads(body)


def declarations(freeze: dict) -> dict:
    """
    機能: 固定票の宣言pathを同じ絶対pathへ正規化する。
    引数: freeze(dict)。返り値: dict[Path,str]。
    """
    return {ref_path(path):value for path,value in freeze['ファイル'].items()}


def apply(job: dict) -> dict:
    """
    機能: 完了証跡とF0本文の同体を確認して3MDと必要4目次だけを更新する。
    引数: job(dict)はRoot終了通知後に作る小入力。返り値: dictは反映票。
    """
    assert job['Root金融_独立_CSV終了通知'] is True and job['RootCSV支援画像視認済み'] is True
    assert job['F0全文の恒久保管完了'] is True
    keys=('F0','F1','F2','金融正本','typed三表','金融独立','CSV作成','CSV再読','診断')
    keys=keys+tuple(key for key in ('出生診断','自然監査') if key in job['refs'])
    loaded={key:read_ref(job['refs'][key]) for key in keys}
    f0,f1,f2=[loaded[key][1] for key in ('F0','F1','F2')];data=loaded['金融正本'][1];typed=loaded['typed三表'][1]
    independent=loaded['金融独立'][1];created=loaded['CSV作成'][1];reread=loaded['CSV再読'][1];diagnosis=loaded['診断'][1]
    assert all(item['成功'] and item['試行']==155 for item in (f0,f1,f2,data,typed,independent,created,diagnosis))
    assert reread['成功'] and independent['比較数']==960
    assert f1['前段階SHA256']==job['refs']['F0']['sha256'] and f2['F1_SHA256']==job['refs']['F1']['sha256']
    assert data['F1_SHA256']==job['refs']['F1']['sha256'] and data['F2_SHA256']==job['refs']['F2']['sha256']
    assert declarations(f1)[loaded['F0'][0]]==job['refs']['F0']['sha256']
    assert declarations(f2)[loaded['F1'][0]]==job['refs']['F1']['sha256']
    assert independent['入力'][str(loaded['金融正本'][0])]==job['refs']['金融正本']['sha256']
    assert independent['目標の独立判定']==data['主評価']
    assert diagnosis['入力'][str(loaded['金融正本'][0])]==job['refs']['金融正本']['sha256']
    assert created['入力SHA256']==reread['入力']['sha256']==job['refs']['typed三表']['sha256']
    assert reread['入力SHA256']==reread['後SHA256']
    csv_declared={ref_path(path):value for path,value in reread['入力SHA256'].items()}
    assert csv_declared[loaded['typed三表'][0]]==job['refs']['typed三表']['sha256']
    assert typed['主政策']=='U0' and [t['name'] for t in typed['tables']]==['正逆比較','入口別診断','全セッション']
    assert [len(t['rows']) for t in typed['tables']]==[960,stats(data,'all','U0')['entries'],73]
    assert reread['全データセル比較数']==sum(len(t['rows'])*len(t['headers']) for t in typed['tables'])
    originals={};watched={path:job['refs'][key]['sha256'] for key,(path,_) in loaded.items()}
    for name in ('README.md','条件.md','設定と結果.md'):
        frozen=EVALUATION/'F0実行前文書'/name;current=FORMAL/name;body=frozen.read_bytes()
        assert current.read_bytes()==body and MARKER.encode('utf-8') not in body
        assert all(declarations(stage)[current.resolve()]==hashlib.sha256(body).hexdigest() for stage in (f0,f1,f2))
        originals[name]=body;watched[current]=sha(current);watched[frozen]=sha(frozen)
    for name,value in created['出力'].items():
        path=CSV/name;assert sha(path)==value['sha256']==csv_declared[path.resolve()];watched[path]=value['sha256']
    assert set(created['出力'])=={'正逆比較.csv','入口別診断.csv','全セッション.csv'}
    birth=loaded['出生診断'][1] if '出生診断' in loaded else None
    if '自然監査' in loaded:assert loaded['自然監査'][1]['成功'] is True
    status,appendix,short=render(data,diagnosis,birth)
    old=originals['README.md'].decode('utf-8');assert old.count(STATUS)==1
    primary=stats(data,'all','U0');frequency=data['頻度']['all']['U0']['全時間取得毎時']
    banner=status+f"\n\n{primary['entries']}取得/全73場、{primary['forward']}順{primary['adverse']}逆{primary['neither']}未到達{primary['censored']}不足・到達済{rate(primary['resolved_rate'])}、平均{number(frequency,6)}回/時。C5既知利益{number(primary['ifd_net5_profit'])}円/損失絶対{number(primary['ifd_net5_loss'])}円/差引{number(primary['ifd_net5_sum'])}円、未知{primary['ifd_unknown']}。主a=.05を維持し、結果の良い比較へ交換していない。\n\n以下の準備・未実行表記はF0当時の記録であり、現在の結果は末尾に追記した。"
    updated=old.replace(STATUS,banner,1)+appendix
    assert updated.split(appendix)[0].replace(banner,STATUS,1)==old
    changes={FORMAL/'README.md':updated.encode('utf-8')}
    for name in ('条件.md','設定と結果.md'):
        changes[FORMAL/name]=originals[name]+short.encode('utf-8');assert changes[FORMAL/name].startswith(originals[name])
    primary=stats(data,'all','U0');f=data['頻度']['all']['U0'];goal=goals(data)
    for name,prefix in [('README.md','study/'),('study/README.md',''),('docs/README.md','../study/'),('docs/議論/README.md','../../study/')]:
        path=ROOT/name;before=path.read_bytes();assert b'00155_' not in before;watched[path]=sha(path)
        newline=b'\r\n' if b'\r\n' in before[:300] else b'\n'
        line=f"[155：方向付き数量で補正と独立順行を比較]({prefix}{FORMAL.name}/README.md)。主U0は{primary['entries']}取得・到達済{rate(primary['resolved_rate'])}・平均{number(f['全時間取得毎時'],6)}回/時、全場/70%/頻度の共同は{verdict(goal['三目標共同'])}。C5既知利益{number(primary['ifd_net5_profit'])}円/損失絶対{number(primary['ifd_net5_loss'])}円/差引{number(primary['ifd_net5_sum'])}円、未知{primary['ifd_unknown']}。主a=.05と旧対照を保持し、量の維持/実反転/待機と新FTを分けた。"
        if name=='docs/README.md':line+=' [量の逆向きと入口失効の違い](議論/量の逆向きと入口の失効を同一視しない.md)。'
        if name=='docs/議論/README.md':line+=' [量の逆向きと入口失効の違い](量の逆向きと入口の失効を同一視しない.md)。'
        addition=line.encode('utf-8')+newline+newline;position=before.find(b'[154');assert position>=0
        changes[path]=before[:position]+addition+before[position:];assert changes[path].replace(addition,b'',1)==before
    assert all(sha(path)==value for path,value in watched.items())
    assert not (HERE/'結果反映の確認.json').exists()
    for path,body in changes.items():path.write_bytes(body)
    for path,value in watched.items():
        if path not in changes:assert sha(path)==value
    assert all((FORMAL/name).read_bytes().startswith(originals[name]) for name in ('条件.md','設定と結果.md'))
    proof={'成功':True,'試行':155,'編集停止':True,'Root終了通知後のみ反映':True,
        '条件設定F0全文prefix保持':True,'READMEは先頭状態だけ更新_本文を復元可能':True,'主_数値条件_513セル変更':False,
        '独立金融比較数':960,'独立金融統計キー':independent['統計キー数'],'CSV全データセル':reread['全データセル比較数'],
        '金融再計算_Source価格_原板読取':False,'正本_固定票_CSVの前後同体':True,
        '入力refs':job['refs'],'反映前SHA256':{p.relative_to(ROOT).as_posix():value for p,value in watched.items() if p in changes},
        '変更SHA256':{p.relative_to(ROOT).as_posix():sha(p) for p in changes},
        '閲覧資料_再現手順_保管索引_保存ZIPへ書込':False,'追記器SHA256':sha(Path(__file__))}
    (HERE/'結果反映の確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    return proof


def main() -> None:
    """
    機能: Root終了通知と明示実行旗が揃うときだけ小jobを読んで正式反映する。
    引数: CLI job(Path)/job-sha256(str)/execute-after-root(bool)。返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--job',required=True,type=Path);parser.add_argument('--job-sha256',required=True)
    parser.add_argument('--execute-after-root',action='store_true');args=parser.parse_args();assert args.execute_after_root
    assert sha(args.job)==args.job_sha256;job=json.loads(args.job.read_bytes());proof=apply(job)
    print(json.dumps({'成功':proof['成功'],'正式結果追記':True,'確認SHA256':sha(HERE/'結果反映の確認.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
