"""結果追記後のF0本文・正式リンク・全指紋を確認して停止票を作る。"""
from pathlib import Path
import ast
import gzip
import hashlib
import json
import os
import re
import subprocess
import sys
from urllib.parse import unquote

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
FORMAL=ROOT/'study/00155_方向付き数量で既存入口を補正し順行入口を加える'


def sha(path: Path) -> str:
    """
    機能: 検査する小票・文書・CSVの物理指紋を求める。
    引数: path(Path)。返り値: str。
    """
    digest=hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda:source.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()


def main() -> None:
    """
    機能: 既反映文書を再編集せず、本文prefix/57行/リンクとSource不変を検査する。
    引数: なし。返り値: None。新選択・金融再計算・原板読取をしない。
    """
    assert not (HERE/'停止.json').exists()
    source_paths=sorted([*HERE.glob('*.py'),HERE/'README.md']);source_before={p.name:sha(p) for p in source_paths}
    job_path=ROOT/'work/155量方向による入口の評価/Rootの完了通知.json'
    assert sha(job_path)=='7e84c22f86d3a63eec6013b84787156a9ea3c1795c5c82c5cc56f6032f332baa'
    job=json.loads(job_path.read_bytes());reflected=json.loads((HERE/'結果反映の確認.json').read_bytes())
    assert reflected['成功'] and reflected['追記器SHA256']==sha(HERE/'結果を追記する.py')
    for ref in job['refs'].values():
        path=Path(ref['path']);path=path if path.is_absolute() else ROOT/path
        assert sha(path)==ref['sha256']
    snapshot=FORMAL/'検査/F0実行前文書.json.gz'
    original=json.loads(gzip.decompress(snapshot.read_bytes()))
    initial={Path(row['path']).name:row['本文'].encode('utf-8') for row in original['文書']}
    assert len(initial)==3
    for name,body in initial.items():
        assert hashlib.sha256(body).hexdigest()==next(row['sha256'] for row in original['文書'] if Path(row['path']).name==name)
        assert (ROOT/'work/155量方向による入口の評価/F0実行前文書'/name).read_bytes()==body
        if name!='README.md':assert (FORMAL/name).read_bytes().startswith(body)
    setting=(FORMAL/'設定と結果.md').read_text(encoding='utf-8')
    original_table=[line for line in initial['設定と結果.md'].decode('utf-8').splitlines() if re.match(r'^\|\s+[A-Z]\d{2}\s+\|',line) and len(line.split('|'))==13]
    current_table=[line for line in setting.splitlines() if re.match(r'^\|\s+[A-Z]\d{2}\s+\|',line) and len(line.split('|'))==13]
    assert original_table==current_table and len(current_table)==57
    links=0;documents={}
    for name in ('README.md','条件.md','設定と結果.md'):
        path=FORMAL/name;text=path.read_text(encoding='utf-8');documents[name]=sha(path)
        for target in re.findall(r'\]\(([^)]+)\)',text):
            if '://' in target or target.startswith('#'):continue
            local=unquote(target.strip('<>').split('#',1)[0]);assert (path.parent/local).exists(),(name,target);links+=1
    assert '526取得/全73場' in (FORMAL/'README.md').read_text(encoding='utf-8')
    for name in ('docs/README.md','docs/議論/README.md'):
        text=(ROOT/name).read_text(encoding='utf-8');assert '00155_' in text and '量の逆向きと入口の失効を同一視しない.md' in text
    for relative,expected in reflected['変更SHA256'].items():assert sha(ROOT/relative)==expected
    for name,ref in [('FTの出生診断.json',job['refs']['出生診断']),('維持反転待機の診断.json',job['refs']['診断'])]:
        assert sha(FORMAL/'根拠'/name)==ref['sha256']
    for path in HERE.glob('*.py'):
        tree=ast.parse(path.read_text(encoding='utf-8'));compile(tree,str(path),'exec')
        for node in ast.walk(tree):
            if isinstance(node,ast.FunctionDef):
                doc=ast.get_docstring(node);assert doc and '\n' in doc and all(k in doc for k in ('機能','引数','返り値'))
    test=subprocess.run([sys.executable,'-X','utf8',str(HERE/'人工検査.py')],cwd=ROOT,capture_output=True,
        env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'})
    out,error=test.stdout.decode('utf-8','strict'),test.stderr.decode('utf-8','strict')
    assert test.returncode==0 and 'Ran 3 tests' in error and '\ufffd' not in out+error
    assert source_before=={p.name:sha(p) for p in source_paths}
    assert documents=={name:sha(FORMAL/name) for name in documents}
    proof={'成功':True,'試行':155,'編集停止':True,'Root完了通知SHA256':sha(job_path),
        '結果反映SHA256':sha(HERE/'結果反映の確認.json'),'恒久F0原文SHA256':sha(snapshot),
        '条件設定F0全文prefix保持':True,'設定57行513セル全字同体':True,'README先頭結果化_原文復元可能':True,
        '正式ローカルリンク実在数':links,'Rootの共通知見をdocs2目次へ追加':True,
        '独立960比較23040キー_CSV62326セルはRoot正本参照':True,
        '金融_Source_条件_主_閾値_再計算変更':False,'Raw_追加2場読取':False,
        '別担当の閲覧_再現_索引_ZIP編集':False,'正式3MD':documents,
        '源前後同体':source_before,'補足一次資料':{'確認日':'2026-11-12','ADL':'https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-indicators/accumulation-distribution-line','ATR':'https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/atr'},
        '最終人工':{'主群':3,'終了値':test.returncode,'標準出力':out,'標準エラー':error}}
    (HERE/'最終確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    stop={'成功':True,'編集停止':True,'試行':155,'最終確認SHA256':sha(HERE/'最終確認.json'),'結果反映SHA256':sha(HERE/'結果反映の確認.json'),
        '正式3MD':documents,'源':{p.name:sha(p) for p in source_paths}}
    (HERE/'停止.json').write_text(json.dumps(stop,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'成功':True,'停止SHA256':sha(HERE/'停止.json'),'最終確認SHA256':sha(HERE/'最終確認.json'),'正式3MD':documents,'リンク':links},ensure_ascii=False))


if __name__=='__main__':
    main()
