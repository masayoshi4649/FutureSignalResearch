"""自然155結果を開かず、追記器の人工と正式不変更を記録する。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
FORMAL=ROOT/'study/00155_方向付き数量で既存入口を補正し順行入口を加える'


def sha(path: Path) -> str:
    """
    機能: 源と正式文書の物理SHA256を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: UTF8人工3群と構文・正式3MD不変更を確認して準備停止する。
    引数: なし。返り値: None。自然155JSONを読まない。
    """
    assert not (HERE/'準備の確認.json').exists()
    paths=sorted([*HERE.glob('*.py'),HERE/'README.md'])
    before={p.name:sha(p) for p in paths};documents={name:sha(FORMAL/name) for name in ('README.md','条件.md','設定と結果.md')}
    for path in HERE.glob('*.py'):
        tree=ast.parse(path.read_text(encoding='utf-8'));compile(tree,str(path),'exec')
        for node in ast.walk(tree):
            if isinstance(node,ast.FunctionDef):
                doc=ast.get_docstring(node);assert doc and '\n' in doc and all(k in doc for k in ('機能','引数','返り値'))
    result=subprocess.run([sys.executable,'-X','utf8',str(HERE/'人工検査.py')],cwd=ROOT,capture_output=True,
        env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'})
    out,error=result.stdout.decode('utf-8','strict'),result.stderr.decode('utf-8','strict')
    assert result.returncode==0 and 'Ran 3 tests' in error and '\ufffd' not in out+error
    assert before=={p.name:sha(p) for p in paths} and documents=={name:sha(FORMAL/name) for name in documents}
    proof={'成功':True,'試行':155,'編集停止':True,'人工主群':3,'自然155採否_金融_JSON読取':False,
        '正式3MD又は目次変更':False,'正式3MD前後同体':documents,'源前後同体':before,
        '条件設定F0全文prefix_README先頭状態のみ更新_一時人工成功':True,
        '別担当の閲覧_再現_索引_ZIPへ書込':False,'Root金融_独立_CSVとF0恒久保管完了を待つ':True,
        '人工結果':{'終了値':result.returncode,'標準出力':out,'標準エラー':error}}
    (HERE/'準備の確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps({'成功':True,'準備SHA256':sha(HERE/'準備の確認.json'),'追記器SHA256':sha(HERE/'結果を追記する.py')},ensure_ascii=False))


if __name__=='__main__':
    main()
