"""自然155結果を読まず、表示の未知とF0本文保持・明示旗を人工で確認する。"""
from pathlib import Path
from unittest.mock import patch
import copy
import importlib.util
import json
import sys
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('result155',HERE/'結果を追記する.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def item(f: int=7,a: int=3,n: int=2,c: int=1) -> dict:
    """
    機能: 主表示に必要なF/A/N/C・金額・未知の小統計を作る。
    引数: f/a/n/c(int)。返り値: dict。
    """
    entries=f+a+n+c;known=entries-c
    return {'entries':entries,'forward':f,'adverse':a,'neither':n,'censored':c,'complete':f+a+n,
        'resolved_rate':f/(f+a) if f+a else None,'complete_rate':f/(f+a+n) if f+a+n else None,
        'ifd_known':known,'ifd_unknown':c,'ifd_net5_profit':f*1000 if known else None,
        'ifd_net5_loss':a*1000 if known else None,'ifd_net5_sum':(f-a)*1000 if known else None}


def data() -> tuple:
    """
    機能: 全/前48/後25と4分岐を人工統計だけで作る。
    引数: なし。返り値: tuple[dict,dict]。
    """
    result={'成功':True,'試行':155,'主政策':'U0','集計':{},'参加':{},'頻度':{},'重複連結群と場集中':{}}
    diagnosis={'成功':True,'試行':155,'主CMFバッファ':.05,'全前後の分岐診断':{}}
    for part,s,scope in [('all',item(),73),('train',item(4,1,1,0),48),('validation',item(3,2,1,1),25)]:
        result['集計'][part]={p:{'BBO':{'3600':{'125':copy.deepcopy(s)}}} for p in m.POLICIES}
        result['参加'][part]={'U0':{'対象場数':scope,'取得場数':5,'全場最低1取得':False,'最小場件数':0,'最大場件数':5}}
        result['頻度'][part]={'U0':{'全時間h':720.9166666666666,'全時間取得毎時':s['entries']/720.9166666666666}}
        result['重複連結群と場集中'][part]={'U0':{'連結群数':3,'最大群件数':6,'最大場件数':5,'上位5場件数比':1.0}}
        diagnosis['全前後の分岐診断'][part]={g:{'件数':s['entries'] if i==0 else 0,'取得場数':5 if i==0 else 0,
            'Q0採用方向':copy.deepcopy(s if i==0 else item(0,0,0,0))} for i,g in enumerate(m.GROUPS)}
    result['主評価']={'全場最低1':False,'到達済70%':True,'全時間毎時1以上':False,'三目標共同':False}
    return result,diagnosis


def write(path: Path,value: dict) -> dict:
    """
    機能: 人工小JSONを保存し期待参照を返す。
    引数: path(Path)、value(dict)。返り値: dict。
    """
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,ensure_ascii=False)+'\n',encoding='utf-8')
    return {'path':str(path),'sha256':m.sha(path)}


def fixture(root: Path) -> tuple:
    """
    機能: 実データを使わず固定票・3CSV・完了票が揃った一時研究ルートを作る。
    引数: root(Path)。返り値: tuple[dict,dict]はjobとF0本文。
    """
    formal=root/'study/00155_人工';evaluation=root/'work/155評価';csv=root/'outputs/CSV';here=root/'work/追記器'
    for path in (formal,evaluation,csv,here):path.mkdir(parents=True)
    originals={name:(f'# 人工155\n\n{m.STATUS}\n\nF0の原文と513セルを保持。\n').encode('utf-8') for name in ('README.md','条件.md','設定と結果.md')}
    files={}
    for name,body in originals.items():
        (formal/name).write_bytes(body);frozen=evaluation/'F0実行前文書'/name;frozen.parent.mkdir(exist_ok=True);frozen.write_bytes(body)
        files[(formal/name).relative_to(root).as_posix()]=m.sha(formal/name)
    f0=write(evaluation/'F0.json',{'成功':True,'試行':155,'ファイル':files})
    f1=write(evaluation/'F1.json',{'成功':True,'試行':155,'前段階SHA256':f0['sha256'],'ファイル':{**files,Path(f0['path']).relative_to(root).as_posix():f0['sha256']}})
    f2=write(evaluation/'F2.json',{'成功':True,'試行':155,'F1_SHA256':f1['sha256'],'ファイル':{**files,Path(f1['path']).relative_to(root).as_posix():f1['sha256']}})
    summary,diagnosis=data();summary.update(F1_SHA256=f1['sha256'],F2_SHA256=f2['sha256'])
    s=write(evaluation/'集計.json',summary)
    table_data={'成功':True,'試行':155,'主政策':'U0','tables':[{'name':name,'headers':['原値'],'rows':[[0] for _ in range(count)]} for name,count in [('正逆比較',960),('入口別診断',13),('全セッション',73)]]}
    typed=write(evaluation/'表.json',table_data)
    independent=write(evaluation/'独立.json',{'成功':True,'試行':155,'比較数':960,'統計キー数':23040,'入力':{s['path']:s['sha256']},'目標の独立判定':summary['主評価']})
    outputs={}
    for name in ('正逆比較.csv','入口別診断.csv','全セッション.csv'):
        (csv/name).write_bytes(b'fixture\n');outputs[name]={'sha256':m.sha(csv/name)}
    creation=write(evaluation/'CSV作成.json',{'成功':True,'試行':155,'入力SHA256':typed['sha256'],'出力':outputs})
    csv_checks={typed['path']:typed['sha256'],**{str(csv/name):value['sha256'] for name,value in outputs.items()}}
    reread=write(evaluation/'CSV再読.json',{'成功':True,'入力':{'sha256':typed['sha256']},'入力SHA256':csv_checks,'後SHA256':csv_checks,'全データセル比較数':1046})
    diagnosis['入力']={s['path']:s['sha256']};diag=write(evaluation/'診断.json',diagnosis)
    for name in ('README.md','study/README.md','docs/README.md','docs/議論/README.md'):
        path=root/name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes('共通知見を維持\n\n[154：旧案内](旧README.md)\n'.encode('utf-8'))
    for name in ('閲覧資料.md','再現手順.md','保管索引.json'):(formal/name).write_bytes(b'peer')
    job={'Root金融_独立_CSV終了通知':True,'RootCSV支援画像視認済み':True,'F0全文の恒久保管完了':True,
        'refs':dict(zip(('F0','F1','F2','金融正本','typed三表','金融独立','CSV作成','CSV再読','診断'),(f0,f1,f2,s,typed,independent,creation,reread,diag)))}
    return job,{'root':root,'formal':formal,'evaluation':evaluation,'csv':csv,'here':here,'originals':originals}


class Tests(unittest.TestCase):
    """自然155の正本・選択を開かない3主群。"""

    def test_未知率は0と合格に置き換えない(self) -> None:
        """
        機能: 空政策の率/金額と判定のnullを維持し主を交換しない。
        引数: self(Tests)。返り値: None。
        """
        summary,diagnosis=data();summary['集計']['all']['U0']['BBO']['3600']['125']=item(0,0,0,0)
        summary['主評価']={'全場最低1':False,'到達済70%':None,'全時間毎時1以上':False,'三目標共同':None}
        status,body,short=m.render(summary,diagnosis)
        self.assertIn('三条件共同は未定義',status);self.assertIn('0/(0+0)=未定義',body)
        self.assertNotIn('未定義%',body);self.assertIn('主U0/a=.05',short)

    def test_全完了票とF0prefixと編集分担(self) -> None:
        """
        機能: 完了後の一時ルートだけを更新し条件/設定prefixと別担当ファイルを保つ。
        引数: self(Tests)。返り値: None。
        """
        with tempfile.TemporaryDirectory() as directory:
            job,f=fixture(Path(directory))
            with patch.multiple(m,ROOT=f['root'],FORMAL=f['formal'],EVALUATION=f['evaluation'],CSV=f['csv'],HERE=f['here']):
                proof=m.apply(job)
                for name in ('条件.md','設定と結果.md'):self.assertTrue((f['formal']/name).read_bytes().startswith(f['originals'][name]))
                self.assertIn('実行済み',(f['formal']/'README.md').read_text(encoding='utf-8'))
                self.assertEqual(len(proof['変更SHA256']),7)
                for name in ('閲覧資料.md','再現手順.md','保管索引.json'):self.assertEqual((f['formal']/name).read_bytes(),b'peer')
                with self.assertRaises(AssertionError):m.apply(job)

    def test_通知不足と明示旗なしは入出力前に拒否(self) -> None:
        """
        機能: Root終了/視認/F0恒久通知と明示実行旗を省けないことを確認する。
        引数: self(Tests)。返り値: None。
        """
        for missing in ('Root金融_独立_CSV終了通知','RootCSV支援画像視認済み','F0全文の恒久保管完了'):
            job={key:key!=missing for key in ('Root金融_独立_CSV終了通知','RootCSV支援画像視認済み','F0全文の恒久保管完了')}
            with patch.object(m,'read_ref') as called:
                with self.assertRaises(AssertionError):m.apply(job)
                called.assert_not_called()
        with patch.object(sys,'argv',['結果を追記する.py','--job','なし','--job-sha256','0'*64]),patch.object(m,'sha') as called:
            with self.assertRaises(AssertionError):m.main()
            called.assert_not_called()


if __name__=='__main__':
    unittest.main(verbosity=2)
