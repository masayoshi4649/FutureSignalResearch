"""151の閾値準備稿だけを作り、Source/book未確定のまま自然実行しない。"""
from pathlib import Path
import hashlib
import json
import os
import re

ROOT = Path(__file__).resolve().parent.parent
FORMAL = ROOT / 'study/00151_広い複合テクニカルを過去場だけで判別する'
TABLE = ROOT / 'docs/議論/手法と時間スケールの汎用表_版7.md'
CATALOG = ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json'


def sha(path: Path) -> str:
    """
    機能: 小型の元表・列辞書・文書を識別する。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path, body: str) -> None:
    """
    機能: UTF-8の新規文書を排他的に保存する。
    引数: path(Path)は保存先、body(str)は本文。
    返り値: None。既存試行を上書きしない。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as output:
        output.write(body.rstrip() + '\n')


# ----------------------------------------
def move_links(text: str) -> str:
    """
    機能: 元汎用表の教材リンクを151から同じ実体へ向ける。
    引数: text(str)は元表本文。
    返り値: strは相対リンクを移設した本文。
    """
    def replace(match):
        """
        機能: ローカルリンク1件を移設する。
        引数: match(re.Match)はMarkdownリンク。
        返り値: strは移設後のリンク。
        """
        label, link = match.groups()
        if '://' in link or link.startswith('#'):
            return match.group(0)
        relative = os.path.relpath((TABLE.parent / link).resolve(), FORMAL).replace('\\', '/')
        return '[' + label + '](' + relative + ')'
    return re.sub(r'\[([^\]]+)\]\(([^)]+)\)', replace, text)


# ----------------------------------------
def rows(text: str) -> list:
    """
    機能: 元表の57手法行だけを抽出する。
    引数: text(str)はMarkdown本文。
    返り値: listはID・手法・9尺度を保持した行。
    """
    values = []
    for line in text.splitlines():
        cells = [cell.strip() for cell in line.split('|')[1:-1]]
        if len(cells) == 11 and re.fullmatch(r'[A-Z]\d{2}', cells[0]):
            values.append(cells)
    return values


# ----------------------------------------
def main() -> None:
    """
    機能: Root採用閾値を準備3MDへ記録し、元表と全リンクを検査する。
    引数: なし。自然ラベル・モデル・予測・価格・金融を開かない。
    返り値: None。Source/bookのSHAは未取得としF0固定を装わない。
    """
    assert not FORMAL.exists()
    assert max(int(path.name[:5]) for path in (ROOT/'study').iterdir()
               if path.is_dir() and re.match(r'\d{5}_', path.name)) == 150
    assert sha(TABLE) == '585d0d9ba69ff3601325e9e6564ede53aeb81b0d33a2da6cb67e20e175187c3d'
    assert sha(CATALOG) == 'c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4'
    catalog = json.loads(CATALOG.read_bytes())
    assert len(catalog) == 100 and [item['name'] for item in catalog] == sorted(item['name'] for item in catalog)
    assert set(item['role'] for item in catalog) == {'方向','強度','勢い','構造','値幅','量'}
    protected_paths = [TABLE, CATALOG,
        ROOT/'study/00150_突破の現在状態と背景で順逆を切り替える/検査/正式保存の最終確認.json',
        ROOT/'study/00150_突破の現在状態と背景で順逆を切り替える/保管索引.json',
        ROOT/'README.md', ROOT/'docs/README.md', ROOT/'docs/議論/README.md', ROOT/'study/README.md', ROOT/'AGENTS.md']
    protected = {path.relative_to(ROOT).as_posix():sha(path) for path in protected_paths}
    readme = '''# 00151 広い複合テクニカルを過去場だけで判別する

**実行前の準備稿。自然ラベル射影・学習・予測・選択・金融は未実行。Rootの条件bookと専用Sourceは準備中で、完全SHA未取得・F0未固定。** この時点の文書指紋を事前F0の成立と読み替えない。

[条件](条件.md) / [版7・全513セルの設定](設定と結果.md) / [親148](../00148_全1分知得から入口品質の母集団を固定する/README.md) / [直前150](../00150_突破の現在状態と背景で順逆を切り替える/README.md) / [小群から広げたときの知見](../../docs/議論/高率の小群を広げるときに残す情報.md)

## 何を変えて検証するか

148の広い全適格q0・35,339件に保存された、BUY/SELLそれぞれ100列の複合テクニカルを使う。買Ask/売Bidの実側位置、1分の構造・量・値幅と、5/15/30分の方向・強度・勢い等を同じ分類器へ渡す。場開始前に過去だけで一度学習し、その場のモデルを固定する。

[143](../00143_複合テクニカルを過去の場だけで学び方向を判別する/README.md)の752固定取得・74列・向き判別は到達済み51.12%で失敗した。149の可読8局面と150の手動状態拡張も全体70%を満たしていない。旧失敗を保持し、今回は広い母集団・実側位置を含む100列・直近20過去場・活動時間区画重みで、順行/逆行/未到達の組み合わせを判別する別仮説として検証する。学習器なら自動的に改善するとは仮定しない。

価格構造の良さを、方向整合だけでなく勢い・量・値幅・取得位置との関係で識別できるかが問いである。心理仮説は「同じ整合でも、推進の持続・参加・過熱・構造余地により結果が違う」。分類器の分岐や確率は参加者の心理・因果・独立した二要因の効果を証明しない。

## 教師と学習の固定方針

各場開始前、固定73場順の直近20過去セッションだけを選ぶ。20日ではなく20場で、教師寄与ゼロの場を飛ばして古い場を補充しない。物理caseをcanonical最早q0へ一度だけ対応付け、両BUY/SELLの実BBO・H60が完了し、両endpoint時刻の最大が当場startよりstrictに前のpairだけを教師にする。先着の早いtouchだけで成熟を前倒ししない。

クラスは0=逆行先着A、1=両方未到達N、2=順行先着F。未取得・観測不足をNやAへ補わない。成熟1,000物理pair以上、教師寄与8場以上、3クラス全てが必要。条件不足時の新しい学習側は待機し、元方向へのnative fallbackはしない。旧C1全87の保護は予測後の別統合であり学習fallbackではない。

重みは教師がある非空60分区画を等しくする。N=窓内の成熟canonical物理pair数、B=非空活動区画総数、n=その区画のpair数として、各sideにN/(B×n)。左右同値で全2N行の平均は1、場ごとの総重みは均等化しない。区画番号は各場start基準のfloor((canonical q0−start)/3600)で、空区画を分母へ入れず飛び番を維持する。重み付けても近接H60が独立標本になるわけではない。

## 予測から注文方向を選ぶ

同じモデルでBUY/SELLの100値を別々に評価する。各側E=P(F)−P(A)。反対側よりEが0.05以上良い側だけを候補とし、主P70はP(F)/(P(F)+P(A))≥0.70かつP(F)≥0.40を要求する。P65/P60は条件付き比率だけを0.65/0.60へ緩めた事前対照であり、全期の良い結果へ主を交換しない。**予測確率0.70を実測先着率70%と呼ばない。**

保存モデルの実split使用列のうち、当該q0側でfinite既知の列が2技術役割以上必要。未知をNaNとして予測できても役割根拠に数えない。q0_spread_points、q0_spread_125_ratio、q0_entry_minus_last_atr5_to_sideの3列は役割数から除外するが、100列のXから除外するものではない。残る列の役割は100辞書の方向・強度・勢い・構造・値幅・量に従う。

共通は0<q0スプレッド≤20pt、q0Lastと既知1分終値の符号付き差/ATR5が−1〜+1。全q0の予測・判断を完了してから取得対応/metadataを読み、q1価格・取得成否・将来ラベルで選び直さない。主U70=P70＋旧C1全87、同q1重複は旧C1の方向を優先する。P65/U65/P60/U60は別政策。各場の頻度を均等化せず、条件成立と取得を分ける。

## 評価・費用・限界

主U70は実BBO/H60/±125ptの到達済み先着率70%以上、全73場min1、全720時間55分平均概ね1回/時を別及び共同で判定する。順/逆/未到達/観測不足、全件比、IFD既知/未知、利益/損失/差引、近接連結群・場集中を残す。前48/後25は全て既使用であり、過去だけの逐次学習でも独立未知期の検証にはならない。

mini独立1枚で1pt=100円、往復手数料77円。費用C0は手数料だけ、C5はさらに片道5pt×2=1,000円を控除する。未到達の期限清算を0円とせず、金額未知はnullに保つ。実逆は同取得時点の保存反対BBOで評価し1−pで推定しない。Lastはチャート診断で実約定金額へ置換しない。重複IFD合算は10枚口座の運用収支や実注文・追尾管理の実績ではない。

長い支持抵抗・VWAP等の追加は別の未採用案で、151の100列へ後から加えない。日付/ID・side旗・C1所属・数量・q1・将来品質をXへ入れず、必要metadataは別管理。入力の未知分岐が当時品質や期間の代理になり得る点、確率校正と小群/過学習の限界も記録する。

## 未実行と源指紋

数値条件の説明は[条件](条件.md)に記す。Rootのbook・専用data/model/logic・教師純部品・実行器の完全SHAは**未取得**。100列辞書と元V7だけを既存恒久正本の指紋へ照合した。Root実装/人工/独立確認とbook固定後にSource/依存/正式原文をF0へ束縛し、それまで自然実行しない。

CatBoost1.2.10をCPU/1threadの固定設定で使う計画で、GPU・追加インストール・パラメータ探索は行わない。モデル・予測・教師成熟/重み監査を一度保存し、同じ保存モデルの再推論を主な再現証拠とする予定。実行済みのモデル、取得数、率、金額は現時点で全てnull。148の一度保存したgzipと観測を共有し、Raw・追加2場・venv/DLL/wheelは複写しない。
'''
    conditions = '''# 151 条件・実行前準備稿

2026-11-12。**Rootのbook/Sourceは実装中で完全SHA未取得、F0は未固定。自然ラベル・モデル・学習・予測・金融は未実行。** 以下の閾値は採用指示に基づく準備で、Root book固定後に完全SHAと源pathを追補する。存在しないSHAや検証結果を記入しない。

## 入力・時間・禁止入力

親は[148全1分母集団](../00148_全1分知得から入口品質の母集団を固定する/README.md)。全35,339適格q0のBUY/SELL各100値を[辞書順100列](../../inputs/00148_全1分入口母集団/100特徴の列定義.json)に固定する。辞書物理SHA256は `c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4`。価格全反射の対称性と、同q0買Ask/売Bidの非対称を分け、片側の符号反転で反対100行を作らない。

既存[特徴](../../inputs/00148_全1分入口母集団/当時特徴.json.gz)・[取得対応](../../inputs/00148_全1分入口母集団/取得対応.json.gz)・[入口参照](../../inputs/00148_全1分入口母集団/入口参照.json.gz)・[実正逆観測](../00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz)を共有する。Xに日付/時刻/ID/side旗/C1旗/数量/q1価格や成否/将来品質/ラベルを加えない。現在/未来場のラベルpathを学習部品へ渡さない。q0は研究公表モデルの知得時点であり実受信時計の復元ではない。

## 教師射影と成熟

1. 固定場順のiに対しwindow=max(0,i−20)..i−1。20は過去セッション数で暦日数ではない。寄与ゼロ場を詰めず保持し、21場以上前から補充しない。
2. 同じ物理caseをcanonical最早q0へ一度だけ結ぶ。別通知・旧C1複製・両sideでpair数を水増ししない。対応q0のないcaseから特徴を捏造しない。
3. 同q1のBUY/SELL実BBOの両方がH60 completeで、label_known_at=max(BUY.endpoint.time,SELL.endpoint.time) < current_scene.startのときだけ採用。等号不可。早いtouchだけで両H60の成熟を代用しない。phase・限月・正常BBOは保存検査を維持する。
4. 各sideのH60±125について逆行先着=0、両方未到達=1、順行先着=2。未取得/観測不足は教師クラスにせず、IFD金額の正負をラベルへ代入しない。
5. N≥1,000成熟物理pair、教師寄与場数≥8、学習行に3クラス全てが揃うときだけ学習。2N側行やorigin数をNと呼ばない。条件不足時は新規学習側の全q0を待機させ、native方向へfallbackしない。

各場開始前に一度fitし、その場の予測中に再学習/更新しない。学習行順・同値時の安定順・保存モデルschema等の実装詳細はRoot book/専用Source固定時の源へ束縛する。古い143の全prefix/場均重み/74列/native維持を暗黙に移植しない。

## 非空活動60分区画の重み

区画番号は各場開始を基点とするfloor((canonical q0.time−scene.start)/3600)。Bは20場window内で教師pairがある非空区画の総数、nは当該区画のpair数、Nは全成熟pair数。**各pairのBUY/SELLのsideWeight=N/(B×n)** とし左右同値。全2N行の重み平均は1、各非空区画の両側合計は2N/Bとなる。

空区画をBへ含めず、区画番号の飛び番を保ち、空時間の教師を捏造しない。20場windowの寄与ゼロ場も詰めない。各場総重みは非空区画数に応じて変わり、場均重みにはしない。区画番号/場時刻は重みと監査metadata専用でXへ入れない。重みで近接H60の依存がなくなるとはしない。

## 固定CatBoost設定

| 項目 | 採用値 |
| --- | --- |
| ライブラリ | CatBoost 1.2.10 |
| task_type / thread_count | CPU / 1 |
| iterations / depth | 128 / 3 |
| learning_rate / l2_leaf_reg | 0.05 / 10 |
| loss_function / classes_count | MultiClass / 3（0=A、1=N、2=F） |
| boosting_type / bootstrap_type | Plain / No |
| random_strength / random_seed | 0 / 151 |
| has_time / nan_mode | true / Min |
| use_best_model | false |
| 早期停止・全期param探索 | 行わない |

未知特徴はNaNとして渡せるが、既知0と区別し非有限の無効値を混ぜない。保存class順と100列名を検査する。1つのClassifier/同じ予測関数/閾値を買売へ用いる。保存モデルの同一再推論と、再学習bytesの一致は区別する。

## q0の共通条件と役割

正常q0の0<spread≤20pt、q0_last_minus_m1_close_atr5_to_side∈[−1,1]。必要な共通値未知は待機。全q0のBUY/SELL予測・判断を完了してからcapture/metaを読み、q1で選び直さない。

実split列とは、保存モデルの全treeの実際の分岐に使った列を指す。対称木の各level分岐は全q0が通るが、役割票には**当該q0側でfinite既知の実split列**だけを使う。未知split列がモデル全体で使われたというだけで2役割にしない。

100辞書の6役割=方向/強度/勢い/構造/値幅/量。q0_spread_points、q0_spread_125_ratio、q0_entry_minus_last_atr5_to_sideは執行要因として役割数からだけ除外し、Xから削除しない。他の列を新しい独自roleへ付け替えない。選ぶ側に既知実split由来2技術役割以上を要求する。列が2本あることと2役割を混同せず、2役割でも心理の因果や独立効果を立証しない。

## 予測ゲートと主・対照

P(A),P(N),P(F)はclass0/1/2。E_side=P(F)−P(A)。反対側よりEが0.05以上大きい側だけを候補とする。分母P(F)+P(A)>0、確率が有効、当該側の既知split役割≥2を前提に次を用いる。

| 新政策 | 条件付きP(F)/(P(F)+P(A)) | P(F) | 他条件 |
| --- | --- | --- | --- |
| P70（主の新規側） | ≥0.70 | ≥0.40 | E差≥0.05・共通/役割条件 |
| P65（事前緩和対照） | ≥0.65 | ≥0.40 | 同一 |
| P60（事前緩和対照） | ≥0.60 | ≥0.40 | 同一 |

同点/不足/無効/閾値不足なら待機。P(N)が大きいのに条件付き比だけが高い状態を避けるためP(F)の床を別に持つ。モデル確率は実測先着率/校正/費用後利益の保証ではない。全期結果を見てP65等へ主交換したり閾値を調整したりしない。

## 取得・金融の政策

全q0判断後に固定148取得対応を結び、未取得・取消も記録。同q1は最早q0の代表1つにし、旧C1全87との重複は旧方向を優先する。負けた旧6件を含む旧87を全保持し、C1所属を予測へ渡さない。

Source政策はP70/P65/P60、各C1統合のU70/U65/U60、旧C1。主U70=P70+C1である。金融後段に旧C0全81、P70実逆RP70、U70実逆RU70、旧C1実逆RC1を別対照として用意する予定。実逆は同q1の保存反対BBOであり、反転側注文の再構築や1−pではない。後段政策660比較は準備予定で自然結果ではない。

## 評価・数量・未評価

主U70・全73場・実BBO・H60・±125pt。HcompleteのF/(F+A)≥70%、全73場min1、全720時間55分平均概ね1回/時を別及び共同で判定する。F/A/N/Cと全件数、全件比・完了比・到達済み率・金額既知/未知を区別し、0場を除外しない。高頻度場/1回だけの場を均等化せず、一律時刻・上限回数を課さない。

H30/H60・幅25/50/100/125/200・BBO/Last・全期/前48/後25は固定診断として残す。全期既使用・前後も既使用で独立未知期ではない。近接[q1,q1+H60)連結群・最大群・場集中を記録し、case数を独立標本数としない。未選択利益を機会損失として最適化しない。

mini独立1枚、1pt=100円。費用C0は往復77円、C5はさらに片道5pt×2=1,000円。未到達の期限清算損益、利益/損失/差引、IFD未知を残し、未知を0円にしない。Lastの金額はnull、独立IFD合算は枚数上限のある口座や実IFD/追尾運用の実績ではない。

自然の教師数・学習場数・モデル・選択/取得数・確率校正・先着率・金額は全て未実行/null。長い支持抵抗/VWAP等を151へ後追加しない。Raw/追加2場は未読、旧試行・旧目次・環境は変更しない。

## Source/book指紋の準備欄

| 部品 | 状態・正本 |
| --- | --- |
| Root条件book | 作成中。path/完全SHA未取得・F0未固定 |
| 専用data/model/logic/driver | Root準備中。完全SHA未取得 |
| 教師純部品 | 再用予定。完全SHA未取得・本稿で仮造しない |
| 100列定義 | 既存恒久JSON・c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4 |
| 版7汎用表 | 既存57×9。設定と結果.mdから教材へ同実体リンク |

Root Source/book完成・人工/独立確認後、実行前3MD原文と源をF0へ固定する。それまで自然学習・選択・金融を開始しない。条件の追加変更は採用指示と実行前の版へ記録し、後からF0を仮造しない。
'''
    save(FORMAL/'README.md', readme)
    save(FORMAL/'条件.md', conditions)
    original = TABLE.read_text(encoding='utf-8-sig')
    copied = move_links(original[original.index('## 手法×時間スケール'):])
    copied = copied.replace('全セルは未設定・未検証。', '151実行前の入力・監査設定。使用セルも全て未検証。')
    used = {}
    for scale in (3,4,5):
        used[('I01',scale)] = '151-X：EMA8/21・増分/差/距離；入力予定・未検証'
        used[('I03',scale)] = '151-X：Hist水準/増分；入力予定・未検証'
        used[('I04',scale)] = '151-X：RSI中心差/増分；入力予定・未検証'
        used[('I08',scale)] = '151-X：DI向き/ADX水準Δ；入力予定・未検証'
        used[('I09',scale)] = '151-X：ATR/TR/正規化尺度；入力予定・未検証'
    used.update({
        ('I05',4): '151-X：BB15位置/σ/幅/実側余地；入力予定・未検証',
        ('C01',0): '151-CB：MA/Hist/RSI等の木の相互作用；準備・未検証',
        ('C02',0): '151-CB：BB位置/RSI等の複合入力；準備・未検証',
        ('C03',0): '151-CB：BB/短期高安端/量を別役割；準備・未検証',
        ('C04',0): '151-CB：方向と強度の別role；準備・未検証',
        ('C07',0): '151-CB：5/15/30背景と1分構造；準備・未検証',
        ('P01',1): '151-X：r/p実体・ヒゲ・終値位置；入力予定・未検証',
        ('P01',3): '151-X：5分実体/ヒゲ/終値位置；入力予定・未検証',
        ('P02',1): '151-X：r除外prior3端；入力予定・未検証',
        ('P05',0): '151-X：q0Last/既知足/EMAとの距離；入力予定・未検証',
        ('P06',0): '151-X：実Ask/Bidのprior3/BB余地位置；入力予定・未検証',
        ('P07',1): '151-X：端距離の入力。突破成功ラベルは無し；未検証',
        ('V01',1): '151-X：r/p量比・r/先行3平均量比；入力予定・未検証',
        ('V01',3): '151-X：rvol5；入力予定・未検証',
        ('B01',0): '151-Q：0<spread≤20。執行3列はrole除外；未検証',
        ('M01',0): '151-CB：CatBoost128×深3/2既知role/P70；準備・未検証',
        ('E01',0): '151主U70：実BBO/H60±125・70%/全場/1h；未実行',
        ('E01',6): '151診断：H60/全5幅・未到達/不足；未実行',
    })
    lines = []
    for line in copied.splitlines():
        cells = [item.strip() for item in line.split('|')[1:-1]]
        if len(cells) == 11 and re.fullmatch(r'[A-Z]\d{2}',cells[0]):
            for scale in range(9):
                cells[scale+2] = used.get((cells[0],scale),'未使用・未検証')
            line = '| '+' | '.join(cells)+' |'
        lines.append(line)
    setting = '''# 151 設定と結果・実行前準備稿

**自然未実行。Root book/Sourceの完全SHA未取得、F0未固定。** [条件](条件.md)の閾値準備稿と[README](README.md)を参照する。実装の指紋未取得を架空値で埋めない。

[汎用表版7](../../docs/議論/手法と時間スケールの汎用表_版7.md) SHA256 `585d0d9ba69ff3601325e9e6564ede53aeb81b0d33a2da6cb67e20e175187c3d`。57手法×9尺度=513セル、ID・手法順を保持して同じ教材へ相対リンクを移設した。新しい手法IDは追加しない。

151-X=既存100列、151-Q=共通q0品質、151-T=過去20場/両H60成熟/区画重み、151-CB=固定CatBoost/既知実split2役割、151-P70=主新規、151-U70=旧C1優先主統合。入力列を提供したことと、その指標が実モデルで選ばれたことを分ける。実split採用列は自然モデル完成後に記録する。複合成績を単独指標の効果としない。

M01欄はCatBoostの木の複合分岐と監査を記す。単一決定木の条件総当たりやM02のHGBT実装を採用したという意味ではない。長い支持抵抗・VWAP/VWMA・学習後の新列追加は行わない。1分TRは5分ATRで正規化し、1分ATRを新生成したとはしない。

''' + '\n'.join(lines) + '''

## 準備閾値と実行状態

| 設定 | 採用準備値 | 実行結果 |
| --- | --- | --- |
| 教師 | 過去20場内・両H60 complete・両endpoint_max<当場start | 未実行/null |
| 学習最低条件 | 1,000物理pair/8教師寄与場/3class | 未実行/null |
| 重み | 非空60分区画、各side=N/(B×n)、左右同値/平均1 | 未実行/null |
| モデル | CatBoost1.2.10 CPU1、128/depth3/lr.05/l2=10、seed151 | 未実行/null |
| 実split役割 | 当該側finite既知・執行3列除外・異なる2role以上 | 未実行/null |
| P70 | E差≥.05、条件付きP順≥.70、P順≥.40 | 未実行/null |
| P65/P60 | 条件付き比だけ≥.65/≥.60、他は共通 | 未実行/null |
| 主U70 | 新P70+C1全87、同q1は旧C1優先 | 未実行/null |
| 共同目標 | 実BBO H60±125先着70%/全73場min1/720h55m平均1h | 未判定/null |

Source政策P70/P65/P60/U70/U65/U60/C1、金融対照C0/RP70/RU70/RC1は別に残す。未学習・閾値不足・役割不足は学習側待機であり、native fallbackで参加数を増やさない。C1保護は予測後だけ。

実モデル数・学習場数・取得数・待機率・先着率・利益/損失/未知は未評価。0%/0円とは記録しない。未使用・未検証・実装未確定を分け、Source/book指紋の取得後だけF0へ束縛する。Rootが自然を許可するまで未実行状態を保つ。
'''
    save(FORMAL/'設定と結果.md',setting)
    old_rows, new_rows = rows(original),rows(setting)
    assert len(old_rows) == len(new_rows) == 57 and len(new_rows)*9 == 513
    assert [line[0] for line in old_rows] == [line[0] for line in new_rows]
    assert [move_links(line[1]) for line in old_rows] == [line[1] for line in new_rows]
    links = []
    for name in ('README.md','条件.md','設定と結果.md'):
        text = (FORMAL/name).read_text(encoding='utf-8')
        for match in re.finditer(r'\[[^\]]+\]\(([^)]+)\)',text):
            target = match.group(1).split('#')[0]
            if target and '://' not in target:
                assert (FORMAL/target).exists(),(name,target)
                links.append((name,target))
    assert protected == {path.relative_to(ROOT).as_posix():sha(path) for path in protected_paths}
    proof = {'成功':True,'編集停止':True,'区分':'151閾値準備稿。Root book/Source未取得のためF0固定ではない',
        '自然ラベル/モデル/学習/選択/金融/Raw/追加2場':False,
        'Sourceとbook完全SHA256':None,'F0固定':False,'57手法9尺度513セル':True,'ID順と教材同体':True,
        '全ローカルリンク':len(links),'過去20場は20日でなく寄与0場を詰めない':True,
        '教師成熟は両endpoint最大strict':True,'各side重みN_Bnと平均1':True,'役割は各q0finite実splitと3列除外':True,
        '主P70と緩和対照を結果後交換しない':True,'未学習native_fallback':False,
        '既存源/旧試行/目次/AGENTS前後同体':protected,
        '準備3MDの作成時指紋_事前F0ではない':{name:sha(FORMAL/name)for name in ('README.md','条件.md','設定と結果.md')},
        '未取得事項':['Root条件bookのpath/完全SHA','専用data/model/logic/driverと教師純部品の完全SHA','実装/人工/独立確認の正式bind'],
        '準備器SHA256':sha(Path(__file__))}
    save(ROOT/'work/151正式閾値準備の確認.json',json.dumps(proof,ensure_ascii=False,indent=2))
    print(json.dumps({'成功':True,'準備票SHA256':sha(ROOT/'work/151正式閾値準備の確認.json'),'リンク':len(links),'F0固定':False},ensure_ascii=False))


if __name__ == '__main__':
    main()
