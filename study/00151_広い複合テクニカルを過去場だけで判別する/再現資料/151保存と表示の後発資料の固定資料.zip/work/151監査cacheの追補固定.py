"""151の再生成可能cacheを、F1後の監査参照として別票へ束縛する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path(__file__).resolve().parent.parent


def sha(path: Path) -> str:
    """
    機能: 物理ファイルの指紋を計算する。
    引数: path(Path)。返り値: strはSHA256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 過去F1を書き換えず、4cacheの現在SHAと共有入力の由来を保存する。
    引数: なし。返り値: None。自然価格・教師本文・モデルの変更は行わない。
    """
    own = ROOT / 'work/151過去場判別の評価'
    f1 = own / 'F1入口選択後.json'
    assert sha(f1) == '81018200993e85ecc22e54ff518cebd225693162140658124434ed2eabc36917'
    f0 = own / 'F0入口選択前.json'
    cache = own / '入口選択/cache'
    paths = [path for path in cache.rglob('*') if path.is_file()]
    assert len(paths) == 4
    files = {path.relative_to(ROOT).as_posix(): sha(path) for path in sorted(paths)}
    result = {'成功': True, '試行': 151, '段階': 'F1後の監査cache参照追補',
        'UTC': datetime.now(timezone.utc).isoformat(), 'F1_SHA256': sha(f1), 'F0_SHA256': sha(f0),
        'F1事前固定の対象だったと主張する': False,
        '意味': '共有入力から再生成した作業cacheの現在指紋。保存学習配列署名と全予測への独立照合に用いる',
        '全cacheは変更せず指紋のみ取得': True, 'ファイル': files,
        '共有入力の由来': json.loads((ROOT / 'inputs/00151_過去場だけの複合判別/条件.json').read_bytes())['inputs']}
    with (own / '監査cacheの後発参照.json').open('x', encoding='utf-8', newline='\n') as sink:
        json.dump(result, sink, ensure_ascii=False, indent=2, allow_nan=False)
        sink.write('\n')
    print(json.dumps({'成功': True, 'cache数': len(files), 'sha256': sha(own / '監査cacheの後発参照.json')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
