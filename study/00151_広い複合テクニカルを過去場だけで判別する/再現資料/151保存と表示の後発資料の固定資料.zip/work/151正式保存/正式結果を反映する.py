"""151の実行前条件・513セルを保ったまま、確定結果と失敗履歴を明示する。"""
from pathlib import Path
import gzip
import json
import re
from 保存部品 import ROOT,FORMAL_REL,CORE,sha,json_bytes,write_new

FORMAL=ROOT/FORMAL_REL
CSV='../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/151_過去場だけの複合判別/'


def number(value: object) -> str:
    """
    機能: 金額を未知のまま又は桁区切りで表示する。
    引数: value(object)は整数又はNone。
    返り値: strは閲覧文字列。
    """
    return 'null'if value is None else f'{value:,}'


# ----------------------------------------
def method_rows(text: str) -> list:
    """
    機能: 元表の57行513セルだけを抽出する。
    引数: text(str)はMarkdown。
    返り値: listはID・手法・9尺度の全セル。
    """
    result=[]
    for line in text.splitlines():
        cells=[part.strip()for part in line.split('|')[1:-1]]
        if len(cells)==11 and re.fullmatch(r'[A-Z]\d{2}',cells[0]):result.append(cells)
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: 保存金融から11政策表を作り、主不採用・確率校正・背景の限界を記録する。
    引数: なし。選択/Source/モデル/閾値を変更しない。
    返り値: None。条件と設定はF0全文prefixと元513セルを保持する。
    """
    source=FORMAL/'成果物/集計.json'
    assert sha(source)=='ab002c2088784bb45ea86800550013ae44637f39d4bafb7a70e42814789ccd04'
    summary=json.loads(source.read_bytes())
    with gzip.open(FORMAL/'検査/F0実行前文書.json.gz','rb')as stream:
        originals={Path(item['path']).name:item['本文']for item in json.load(stream)['文書']}
    assert all((FORMAL/name).read_text(encoding='utf-8')==originals[name]for name in CORE)

    def stat(policy: str,part: str='all') -> dict:
        """
        機能: 主時計/幅の保存値だけを読む。
        引数: policy/part(str)は政策と期間。
        返り値: dictは実BBO H60±125の既存集計。
        """
        return summary['集計'][part][policy]['BBO']['3600']['125']

    table=['| 政策 | 取得/参加場 | 順/逆/未/不足 | 到達済み先着率 | C5既知利益 | C5既知損失 | C5既知差引 | IFD未知 |',
           '| --- | --- | --- | --- | --- | --- | --- | --- |']
    for policy in ('C0','C1','RC1','P70','RP70','U70','RU70','P65','U65','P60','U60'):
        value=stat(policy)
        table.append(f"| {policy} | {value['entries']}/{value['sessions']} | {value['forward']}/{value['adverse']}/{value['neither']}/{value['censored']} | {value['resolved_rate']:.2%} | {number(value['ifd_net5_profit'])}円 | {number(value['ifd_net5_loss'])}円 | {number(value['ifd_net5_sum'])}円 | {value['ifd_unknown']} |")
    policy_table='\n'.join(table)
    split=['| 政策・参考期間 | 取得 | 順/逆/未/不足 | 到達済み率 | 平均取得/時 | C5既知利益 | C5既知損失 | C5既知差引 | IFD未知 |',
           '| --- | --- | --- | --- | --- | --- | --- | --- | --- |']
    for policy in ('U70','U65','U60'):
        for part,title in [('train','前48場'),('validation','後25場')]:
            value=stat(policy,part)
            split.append(f"| {policy}・{title} | {value['entries']} | {value['forward']}/{value['adverse']}/{value['neither']}/{value['censored']} | {value['resolved_rate']:.2%} | {summary['頻度'][part][policy]['全時間取得毎時']:.4f} | {number(value['ifd_net5_profit'])}円 | {number(value['ifd_net5_loss'])}円 | {number(value['ifd_net5_sum'])}円 | {value['ifd_unknown']} |")
    value=stat('U70')
    results=f'''## 結果：主U70は先着率と頻度が未達

主U70は595取得/全73場、272順283逆29未到達11観測不足。到達済み先着率は**272/(272+283)=49.01%**、平均0.8253回/時で、70%・平均概ね1回/時とも未達だった。全場min1は旧C1保護で維持した。主を緩和対照U65へ交換せず、151は不採用とする。

C5既知590件の小計は**利益3,338,747円／損失4,109,177円／差引−770,430円**、未知5件を別に残す。手数料のみの費用C0でも差引−180,430円。追加滑りの差590,000円は既知590件×1,000円である。未知を0円にせず、全件確定差引はnull。

到達済み49.01%は全取引勝率や参加率ではない。全595取得中の順行先着は{value['forward']/value['entries']:.2%}、Hcomplete584件中は{value['complete_rate']:.2%}で、未到達29・不足11も取得済みである。IFD未知5と観測不足11は別の分類で、観測不足でも早いtouchが既知の場合がある。

{policy_table}

SourceのN70はP70と同じ接続用aliasで、金融政策や取得回数へ二重計上しない。政策C0は旧81、C1は旧87。費用C0という名前とは区別する。RP70/RU70/RC1は同q1の保存実BBO反対側で、1−pではない。P70は511件/13場、旧87との重複3件を旧優先にしてU70=595件とした。C1の70%/+210,532円は同体だが頻度0.1207回/時である。

## 緩和対照と前後期間

U65は全1,200取得・平均1.6645回/時、599順482逆81未38不足・55.41%、C5既知差引+473,678円、未知14。**全期の既知小計が正でも70%に届かず、後25場は112順112逆=50%・−256,633円**だった。P70の不採用を取り消す成績ではない。U60も回数は増えたが48.49%・−3,701,890円で、単に閾値を下げる規則が有利とはいえない。

{chr(10).join(split)}

全73場・前48/後25とも既使用。過去場だけの逐次学習が実装できたことと、独立未知期で高精度だったことは別である。場ごとの頻度差は許容するが、分母を取得できた場や学習開始後だけへ縮めない。

## 高いモデル確率と実測率が分かれた理由

[確率・集中の停止短報](根拠/確率と集中の原因.md)と[背景追補](根拠/強い反対背景と未回復の追補.md)に事後診断を分離した。P70の到達済み497件の平均条件付き予測は73.97%だったが、同じ497件の実測は46.28%。予測0.70を実先着率70%とする校正は成立していなかった。高い確率帯を結果後に採用/除外した新政策は作っていない。

P70は新取得13場に集中し、10/15Dayの253件は全て買い・同じmodel36、72順181逆・既知差引−1,680,481円。名目H60の1連結群で、253件が全て同じ1時間内にあった意味ではない。U70全体も91連結群・最大253件/群で、case数を独立標本数として解釈しない。

当日の全253件では30分EMA21増分・DI30差・DI15差が買いに反対、ADX15は最小52.57と強く、未知不足による見落としではなかった。モデルは61列の実分岐を使っていても、背景方向の支持や選択方向の構造回復を必須条件にしていなかった。**複数の技術役割を入力・分岐で参照したことと、その方向の支持/反転確認が成立したことは同じではない。**

ただし上位反対の他3場66件は48順14逆・+389,918円で、一律に背景反対を禁止できる結果でもない。上位賛成群も後25場は25順39逆・−250,928円。強い背景に対する短期反転を、回復の段階・勢い・量・取得位置とどう分けるかが次の問いであり、151へ新しいhardgateを後追加していない。長い高安やVWAPがないことだけを未達原因とする比較もしていない。
'''
    old=originals['README.md']
    body=old[old.index('## 何を変えて検証するか'):old.index('## 未実行と源指紋')]
    readme=f'''# 00151 広い複合テクニカルを過去場だけで判別する

**実行済み。主U70は到達済み先着率49.01%・平均0.8253回/時で未達・不採用。** 過去20場・100複合特徴・固定CatBoostで学び、主P70/U70を変更せず評価した。参考U65の全期既知差引は正でも、70%未達・後25場赤字のため主へ交換しない。

[全セッションCSV]({CSV}全セッション.csv) / [入口別CSV]({CSV}入口別診断.csv) / [正逆比較CSV]({CSV}正逆比較.csv) / [金融正本](成果物/集計.json) / [固定条件](条件.md) / [設定と結果](設定と結果.md) / [保管索引](保管索引.json)

{results}

{body}

## 実行履歴と再現の範囲

初回F0 `eb694b32897b1a533cb25ac30b36b3befa7b7357bd07a737ee29ebd2e9099c61` の自然接続は、教師射影後・最初fit前に時計型不整合で停止した。共有fixedの整数秒floatと純教師APIのint限定が合わなかったためで、**自然教師射影済み・モデル0/判断0**。初回源・元Root人工票・初回F0・停止票を修正版成功履歴と分けて保存した。

finiteかつ整数秒と等値のstartだけをintへ無損失射影する修正後、新F0 `d14d98f984adf9894703a40f4c68a97347109666c0a05743459ca3822e566cf4` で再実行した。市場値・売買閾値・bookの変更ではない。成功版run151のSHAは `17ba1de23a58220f7297553313f99429138413300de74f4b4c21682fe89060d6`。

F1 `81018200993e85ecc22e54ff518cebd225693162140658124434ed2eabc36917` で全q0判断・65保存モデル・場別教師監査・取得結合を固定し、金融前F2 `0f0b6223f627043185f44ddf16d473736d8173fb64746d34ba8add418d2e467e` で後段を固定した。65モデル＋4JSONは[一つの恒久ZIP](../../inputs/00151_過去場だけの複合判別/学習と選択の正本.zip)へ保存。148特徴・100列・大観測は共有し、venv/DLLや原板を重ねない。

4cacheはF1に含まれていない再生成可能な作業資料で、F1後の[監査cache参照票](根拠/監査cacheの後発参照.json)として別に束縛した。これを事前F1の固定対象だったとは主張しない。自然独立監査は65JSON再推論・全35,339q0・73場の過去教師/配列署名/区画重み/全政策所属を再構成し、1,446,946末端値を一致確認した。モデルの再学習bytes同体ではなく、同じ保存モデルの再推論を検証した。

Root別算術は660比較・15,840統計キー一致。CSVは55,004セル・数値29,646セルの独立再読とRoot3支援画像の目視を確認した。教師射影器が全保存観測/capture/metaを準備時に読むこと、学習selectorが当場/将来を先に除外して過去成熟X/y/wだけをtrainerへ渡すこと、全q0予測後に選択結果を取得へ結ぶことを分けて検査している。

[予測確率と実先着率の共通知見](../../docs/議論/予測確率と実先着率を分けて判断する.md)も参照する。ラージ板によるmini独立1枚換算のIFD代用であり、mini実板/実発注・片側10枚口座・利益追尾の運用実績ではない。追加2場の価格は未読のまま残す。
'''
    (FORMAL/'README.md').write_text(readme,encoding='utf-8',newline='\n')
    appendix=f'''\n\n---

## 151 金融実行後の追記

上段はF0前の準備時点の原文であり、条件・閾値・全57行513セルを変更していない。現在は修正版F0・F1・F2による自然学習/予測/金融が実行済み。主U70は595/73場、272順283逆29未11不足・到達済49.01%、平均0.8253回/時。C5既知利益3,338,747円・損失4,109,177円・差引−770,430円、未知5。全場min1は維持したが先着70%/平均1回毎時が未達で不採用。

{policy_table}

U65は事前緩和対照で全期55.41%/+473,678円でも後25場112順112逆・−256,633円。主P70/U70を交換しない。旧C1は全87/70%/+210,532円を維持する。金額は各IFD既知集合の小計で全件確定差引ではなく、未知を0円にしない。

初回は自然教師射影後fit0/判断0で時計型停止、整数秒float→等値intの無損失API修正後に新F0で再開。初回F0は成功した実行の事前固定とは区別する。run151の停止SHAは17ba1de23a58220f7297553313f99429138413300de74f4b4c21682fe89060d6、bookは09bad678c01cc7db614137647161ec695f20cb148770987a515ee4cfa71f8f2dのまま。

65保存モデル再推論/全q0/過去教師監査の独立一致、金融660比較15,840キー、CSV55,004セル再読が成功。4cacheはF1未掲載の後発参照であり事前固定としない。[結果と原因](README.md)、[金融正本](成果物/集計.json)、[cache後発票](根拠/監査cacheの後発参照.json)へ分離保存した。
'''
    for name in ('条件.md','設定と結果.md'):
        (FORMAL/name).write_text(originals[name]+appendix,encoding='utf-8',newline='\n')
        assert (FORMAL/name).read_bytes().startswith(originals[name].encode('utf-8'))
    assert len(method_rows(originals['設定と結果.md']))==57 and method_rows(originals['設定と結果.md'])==method_rows((FORMAL/'設定と結果.md').read_text(encoding='utf-8'))
    proof={'成功':True,'試行':151,'条件設定F0全prefix保持':True,'57行513セル同体':True,
        '全11政策表は保存JSONから生成':True,'主U70未達と緩和対照の区別':True,
        '初回時計型停止fit0判断0を修正版成功と分離':True,'cache後発を事前F1へ遡及しない':True,
        '金融SHA256':sha(source),'正式3MD_SHA256':{name:sha(FORMAL/name)for name in CORE},
        '未実在予定リンク':'原因短報2件は停止版の保存後に最終検査する。'}
    write_new(FORMAL/'検査/正式結果の反映確認.json',json_bytes(proof))
    print(json.dumps(proof['正式3MD_SHA256'],ensure_ascii=False))


if __name__=='__main__':main()
