"""Rootの各段階通知SHAを必須にして151保存器を呼ぶCLI。"""
from pathlib import Path
import argparse
from 保存部品 import stage_f0,stage_f1,stage_initial,stage_extra_freeze,stage_artifacts


def main() -> None:
    """
    機能: 明示された段階・通知済みSHAだけを保存APIへ渡す。
    引数: CLI stage(str)、sha256(str)、freeze/generated-dir/history-dir/job(Path|None)、label(str|None)。
    返り値: None。不足引数や不明段階は自然ファイルを読む前に拒否する。
    """
    parser=argparse.ArgumentParser(description='151の段階別恒久保存。自然生成や学習は行わない。')
    parser.add_argument('--stage',required=True,choices=('F0','F1','初回停止','追加固定','成果物'))
    parser.add_argument('--sha256',required=True)
    for name in ('freeze','generated-dir','history-dir','job'):parser.add_argument('--'+name,type=Path)
    parser.add_argument('--label')
    args=parser.parse_args()
    if len(args.sha256)!=64 or not set(args.sha256)<=set('0123456789abcdef'):parser.error('Root通知SHA256が必要')
    if args.stage=='F0':
        if args.freeze is None:parser.error('F0は--freezeが必要')
        stage_f0(args.freeze,args.sha256)
    elif args.stage=='F1':
        if args.freeze is None or args.generated_dir is None:parser.error('F1は--freeze/--generated-dirが必要')
        stage_f1(args.freeze,args.sha256,args.generated_dir)
    elif args.stage=='初回停止':
        if args.history_dir is None:parser.error('初回停止は--history-dirが必要')
        stage_initial(args.history_dir,args.sha256)
    elif args.stage=='追加固定':
        if args.freeze is None or args.label is None:parser.error('追加固定は--freeze/--labelが必要')
        stage_extra_freeze(args.freeze,args.sha256,args.label)
    else:
        if args.job is None:parser.error('成果物は--jobが必要')
        stage_artifacts(args.job,args.sha256)


if __name__=='__main__':main()
