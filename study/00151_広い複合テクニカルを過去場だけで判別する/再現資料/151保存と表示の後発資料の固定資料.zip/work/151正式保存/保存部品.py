"""151の相対固定票・初回停止履歴・モデル群を、段階通知後だけ保存する。"""
from pathlib import Path
import gzip
import hashlib
import json
import uuid
import zipfile

ROOT = Path(__file__).resolve().parents[2]
FORMAL_REL = 'study/00151_広い複合テクニカルを過去場だけで判別する'
INPUT_REL = 'inputs/00151_過去場だけの複合判別'
CORE = ('README.md','条件.md','設定と結果.md')
GENERATED = ('q0の判断.json','場別モデルと教師.json','選択対応.json','選択の確認.json')


def path_of(name: str | Path) -> Path:
    """
    機能: リポジトリ相対/絶対パスを同じ絶対パスへ正規化する。
    引数: name(str|Path)は対象。
    返り値: PathはROOT内の絶対パス。外部原板への暗黙アクセスは拒否する。
    """
    value=Path(name)
    result=(value if value.is_absolute()else ROOT/value).resolve()
    assert result.is_relative_to(ROOT.resolve()),str(result)
    return result


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: 大きい生成物も固定bufferで物理指紋化する。
    引数: path(Path)は対象。
    返り値: strはSHA256。JSON/npz/modelの内容は構造解析しない。
    """
    digest=hashlib.sha256()
    with path.open('rb')as source:
        for block in iter(lambda:source.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def json_bytes(value: object) -> bytes:
    """
    機能: 日本語UTF-8 JSONを有限値だけで作る。
    引数: value(object)は保存値。
    返り値: bytesは末尾改行付きのJSON。
    """
    return (json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')


# ----------------------------------------
def write_new(path: Path,body: bytes) -> None:
    """
    機能: 新規保存先だけへbytesを書き込む。
    引数: path(Path)とbody(bytes)。
    返り値: None。旧資料の上書きを禁止する。
    """
    path=path_of(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb')as output:output.write(body)


# ----------------------------------------
def normalized_files(value: dict) -> dict:
    """
    機能: 固定票の相対/絶対keyをリポジトリ相対へ統一する。
    引数: value(dict)はファイルpath→SHA辞書。
    返り値: dictは正規化path→SHA。正規化後重複は拒否する。
    """
    result={}
    for name,digest in value.items():
        rel=path_of(name).relative_to(ROOT).as_posix()
        assert rel not in result and len(digest)==64 and set(digest)<=set('0123456789abcdef')
        result[rel]=digest
    return result


# ----------------------------------------
def save_file(source: Path,target: Path,expected: str,packed: bool=False) -> dict:
    """
    機能: 通知された生成物を一度同体/gzip保存して復元情報を返す。
    引数: source/target(Path)、expected(str)、packed(bool)。
    返り値: dictは保存/復元先・物理/解凍指紋。Source本文の意味は読まない。
    """
    source=path_of(source);target=path_of(target);assert not target.exists()
    assert sha(source)==expected
    target.parent.mkdir(parents=True,exist_ok=True);digest=hashlib.sha256();size=0
    with source.open('rb')as original,target.open('xb')as output:
        writer=gzip.GzipFile(filename='',fileobj=output,mode='wb',compresslevel=9,mtime=0)if packed else output
        try:
            for block in iter(lambda:original.read(1<<20),b''):
                digest.update(block);size+=len(block);writer.write(block)
        finally:
            if packed:writer.close()
    assert digest.hexdigest()==expected and sha(source)==expected
    return {'保存元':target.relative_to(ROOT).as_posix(),'復元先':source.relative_to(ROOT).as_posix(),
        '形式':'gzip'if packed else '同体','保存SHA256':sha(target),'保存bytes':target.stat().st_size,
        '解凍SHA256':expected,'解凍bytes':size}


# ----------------------------------------
def registry() -> tuple[dict,dict]:
    """
    機能: 旧恒久索引だけから共有源の復元参照を集める。
    引数: なし。
    返り値: tuple(dict,dict)は元path/SHA索引。モデルや観測本文を読まない。
    """
    by_path,by_sha={},{}
    for number in (151,150,149,148,147,146,145,144,143,141,138,133):
        folder=next((ROOT/'study').glob(f'{number:05d}_*'),None)
        if folder is None or not(folder/'保管索引.json').exists():continue
        pending=[json.loads((folder/'保管索引.json').read_bytes())]
        while pending:
            item=pending.pop()
            if isinstance(item,list):pending.extend(item);continue
            if not isinstance(item,dict):continue
            if all(key in item for key in ('保存元','復元先','保存SHA256','解凍SHA256')):
                by_path.setdefault(item['復元先'],item);by_sha.setdefault(item['解凍SHA256'],item)
            if item.get('形式')=='文書snapshot'and all(key in item for key in ('保存元','抽出キー','sha256')):
                by_sha.setdefault(item['sha256'],item)
            if all(key in item for key in ('保存元ZIP','ZIP_SHA256','ZIP内path','sha256')):
                by_sha.setdefault(item['sha256'],item)
            if '格納源'in item and('保存元ZIP'in item or 'ZIP'in item):
                source=ROOT/item['保存元ZIP']if '保存元ZIP'in item else folder/'再現資料'/item['ZIP']
                for record in item['格納源']:
                    digest=record.get('sha256');name=record.get('ZIP内path',record.get('path'))
                    if digest and name:by_sha.setdefault(digest,{'保存元ZIP':source.relative_to(ROOT).as_posix(),
                        'ZIP_SHA256':item['ZIP_SHA256'],'ZIP内path':name,'sha256':digest,'bytes':record.get('bytes')})
            pending.extend(item.values())
    return by_path,by_sha


# ----------------------------------------
def pack_zip(entries: dict,target: Path,aliases: dict|None=None) -> dict:
    """
    機能: 通知済みpath/SHA集合を一つのZIPへstream保存する。
    引数: entries(dict)は相対path→SHA、target(Path)、aliases(dict|None)は初回旧源の実所在。
    返り値: dictは全ZIP内源と復元情報。モデル/判断JSONを解析せず同体保存する。
    """
    target=path_of(target);assert not target.exists();aliases=aliases or {};records=[]
    assert all(sha(path_of(aliases.get(rel,rel)))==expected for rel,expected in entries.items())
    temporary=path_of(ROOT/'work/151保存器の途中ZIP'/f'{uuid.uuid4().hex}.zip.part')
    temporary.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(temporary,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as bundle:
        for rel,expected in sorted(entries.items()):
            source=path_of(aliases.get(rel,rel));before=source.stat();digest=hashlib.sha256();size=0
            assert sha(source)==expected
            info=zipfile.ZipInfo(rel,date_time=(2026,11,12,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            with source.open('rb')as original,bundle.open(info,'w',force_zip64=True)as output:
                for block in iter(lambda:original.read(1<<20),b''):
                    digest.update(block);size+=len(block);output.write(block)
            after=source.stat();assert digest.hexdigest()==expected and(before.st_size,before.st_mtime_ns)==(after.st_size,after.st_mtime_ns)
            records.append({'path':rel,'ZIP内path':rel,'sha256':expected,'bytes':size,
                            '読取元':source.relative_to(ROOT).as_posix()})
    with zipfile.ZipFile(temporary)as bundle:
        assert bundle.testzip()is None
        for record in records:
            digest=hashlib.sha256()
            with bundle.open(record['ZIP内path'])as original:
                for block in iter(lambda:original.read(1<<20),b''):digest.update(block)
            assert digest.hexdigest()==record['sha256']
    target.parent.mkdir(parents=True,exist_ok=True)
    assert temporary.is_relative_to(ROOT.resolve())and target.is_relative_to(ROOT.resolve())and not target.exists()
    temporary.rename(target)
    return {'保存元ZIP':target.relative_to(ROOT).as_posix(),'ZIP_SHA256':sha(target),
        'ZIP_bytes':target.stat().st_size,'格納源':records}


# ----------------------------------------
def check_reference(reference: dict,expected: str) -> None:
    """
    機能: 共有参照の保存実体と復元bytesの指紋を検査する。
    引数: reference(dict)は既存恒久台帳、expected(str)は必要な元SHA。
    返り値: None。共有圧縮入力が同体なら新解凍せず物理SHAだけを照合する。
    """
    if '保存元ZIP'in reference:
        source=path_of(reference['保存元ZIP']);assert sha(source)==reference['ZIP_SHA256']
        digest=hashlib.sha256()
        with zipfile.ZipFile(source)as bundle,bundle.open(reference['ZIP内path'])as original:
            for block in iter(lambda:original.read(1<<20),b''):digest.update(block)
        assert digest.hexdigest()==expected;return
    source=path_of(reference['保存元']);assert sha(source)==reference['保存SHA256']
    if reference['形式']=='同体':assert sha(source)==expected;return
    if reference['形式']=='文書snapshot':
        with gzip.open(source,'rb')as stream:docs=json.load(stream)['文書']
        body=next(item['本文']for item in docs if item['path']==reference['抽出キー']).encode('utf-8')
        assert hashlib.sha256(body).hexdigest()==expected;return
    assert reference['形式']=='gzip'
    digest=hashlib.sha256()
    with gzip.open(source,'rb')as original:
        for block in iter(lambda:original.read(1<<20),b''):digest.update(block)
    assert digest.hexdigest()==expected


# ----------------------------------------
def snapshot(frozen: dict,stage: str,fingerprint: str,freeze_dir: Path) -> tuple[dict,list]:
    """
    機能: Rootの実行前退避3MDを指紋確認して小gzipへ保存する。
    引数: frozen(dict)、stage/fingerprint(str)、freeze_dir(Path)。
    返り値: tuple(dict,list)は保存情報と各原文参照。現在結果MDからF0を偽造しない。
    """
    files=normalized_files(frozen['ファイル']);docs=[]
    for name in CORE:
        logical=f'{FORMAL_REL}/{name}';expected=files[logical]
        candidates=[freeze_dir/'F0実行前文書'/name,ROOT/logical]
        source=next((p for p in candidates if p.is_file()and sha(p)==expected),None)
        assert source is not None,logical
        body=source.read_bytes();docs.append({'path':logical,'sha256':expected,'bytes':len(body),'本文':body.decode('utf-8')})
    payload={'試行':151,'段階':stage,'固定SHA256':fingerprint,'文書':docs,
             '実行前Root退避又は同指紋原文':True,'事前固定を後造り':False}
    target=ROOT/FORMAL_REL/'検査'/f'{stage}実行前文書.json.gz'
    write_new(target,gzip.compress(json_bytes(payload),mtime=0))
    record={'保存元':target.relative_to(ROOT).as_posix(),'保存SHA256':sha(target),'文書数':3}
    refs=[{'復元先':item['path'],'sha256':item['sha256'],'bytes':item['bytes'],'形式':'文書snapshot',
           '保存元':record['保存元'],'保存SHA256':record['保存SHA256'],'抽出キー':item['path']}for item in docs]
    return record,refs


# ----------------------------------------
def resolve(files: dict,stage: str,existing: dict|None=None,aliases: dict|None=None) -> dict:
    """
    機能: 新小型源・既存正本・共有ZIPへ固定源を分類し重複を避ける。
    引数: files(dict)、stage(str)、existing/aliases(dict|None)。
    返り値: dictは分類と新小ZIP。巨大生成物はF1専用ZIPへの明示保存が必要。
    """
    existing=existing or {};aliases=aliases or {};by_path,by_sha=registry()
    groups={'保存済み参照':[],'既存恒久正本':[],'共有源':[],'新小型源':[]};fresh={}
    for rel,expected in normalized_files(files).items():
        if rel in existing:
            ref=existing[rel];assert ref.get('解凍SHA256',ref.get('sha256'))==expected
            groups['保存済み参照'].append(ref);continue
        source=path_of(aliases.get(rel,rel))
        if rel.startswith(('inputs/','study/','scripts/'))and source.is_file()and sha(source)==expected:
            groups['既存恒久正本'].append({'保存元':rel,'復元先':rel,'形式':'同体','保存SHA256':expected,
                '解凍SHA256':expected,'保存bytes':source.stat().st_size,'解凍bytes':source.stat().st_size});continue
        reference=by_path.get(rel)
        if not reference or reference.get('解凍SHA256')!=expected:reference=by_sha.get(expected)
        if reference:
            check_reference(reference,expected)
            groups['共有源'].append({**reference,'復元先':rel});continue
        assert not any(part in ('cache','__pycache__','venv','.venv')for part in Path(rel).parts),rel
        assert source.stat().st_size<3_000_000,(rel,'大生成物を小型源へ紛れ込ませない')
        assert sha(source)==expected;fresh[rel]=expected
        groups['新小型源'].append({'path':rel,'sha256':expected,'bytes':source.stat().st_size})
    if fresh:groups['新小型ZIP']=pack_zip(fresh,ROOT/FORMAL_REL/'再現資料'/f'151{stage}の固定資料.zip',aliases)
    assert sum(len(value)for value in groups.values()if isinstance(value,list))==len(files)
    return groups


# ----------------------------------------
def load_freeze(path: Path,expected: str) -> dict:
    """
    機能: Root通知SHAで固定票metadataだけを読む。
    引数: path(Path)、expected(str)。
    返り値: dictは151の固定票。生成JSON/モデル/自然ラベルはここで開かない。
    """
    path=path_of(path);assert sha(path)==expected
    frozen=json.loads(path.read_bytes());assert frozen['試行']==151 and frozen['主政策']=='U70'
    normalized_files(frozen['ファイル']);return frozen


# ----------------------------------------
def stage_f0(freeze_path: Path,expected: str) -> None:
    """
    機能: 成功予定の修正版Root F0と実行前原文・全源参照を保存する。
    引数: freeze_path(Path)、expected(str)はRoot通知値。
    返り値: None。初回失敗F0をこの段階へ混同しない。
    """
    frozen=load_freeze(freeze_path,expected);formal=ROOT/FORMAL_REL
    assert not(formal/'保管索引.json').exists()
    original=save_file(path_of(freeze_path),formal/'検査/F0入口選択前.json',expected)
    snap,refs=snapshot(frozen,'F0',expected,path_of(freeze_path).parent)
    resolved=resolve(frozen['ファイル'],'入口選択前',{item['復元先']:item for item in refs})
    index={'試行':151,'段階':'修正版F0原文と38源等を保存。F1/金融は通知待ち。',
        'F0_SHA256':expected,'F0原文':original,'F0直接源数':len(frozen['ファイル']),
        'F0文書原文':snap,'F0復元参照':resolved,'主政策':'U70','最終選択取引数':None,
        '共用148特徴/100列/観測の新複製':False,'初回停止履歴':'別段階へ明示保存する。',
        '自然結果のここでの構造解析':False}
    write_new(formal/'保管索引.json',json_bytes(index))


# ----------------------------------------
def stage_f1(freeze_path: Path,expected: str,generated_dir: Path) -> None:
    """
    機能: Root F1通知後、全モデル・判断・教師監査・取得結合を一ZIP保存する。
    引数: freeze_path/generated_dir(Path)、expected(str)。
    返り値: None。cacheを暗黙読取せず、各モデル/判断を別gzipへ重ねない。
    """
    frozen=load_freeze(freeze_path,expected);formal=ROOT/FORMAL_REL;generated=path_of(generated_dir)
    index_path=formal/'保管索引.json';index=json.loads(index_path.read_bytes())
    prior=json.loads((ROOT/index['F0原文']['保存元']).read_bytes())
    current=normalized_files(frozen['ファイル']);previous=normalized_files(prior['ファイル'])
    assert all(current.get(rel)==digest for rel,digest in previous.items())
    origin=save_file(path_of(freeze_path),formal/'検査/F1入口選択後.json',expected)
    selected={rel:digest for rel,digest in current.items()if path_of(rel).is_relative_to(generated)}
    assert selected and all('cache'not in Path(rel).parts for rel in selected)
    assert all((generated/name).relative_to(ROOT).as_posix()in selected for name in GENERATED)
    assert all(Path(rel).suffix=='.json'and(path_of(rel).parent==generated or 'models'in path_of(rel).relative_to(generated).parts)for rel in selected)
    packed=pack_zip(selected,ROOT/INPUT_REL/'学習と選択の正本.zip')
    saved={item['path']:{'保存元ZIP':packed['保存元ZIP'],'ZIP_SHA256':packed['ZIP_SHA256'],
        'ZIP内path':item['ZIP内path'],'sha256':item['sha256'],'復元先':item['path'],'bytes':item['bytes']}for item in packed['格納源']}
    saved[index['F0原文']['復元先']]=index['F0原文']
    additions={rel:digest for rel,digest in current.items()if rel not in previous}
    resolved=resolve(additions,'入口選択後追加',saved)
    index.update({'段階':'F1と全判断/場別教師監査/モデル/選択を一ZIP保存。金融は別段階。',
        'F1_SHA256':expected,'F1原文':origin,'F1直接源数':len(current),'F1増分復元参照':resolved,
        '学習と選択の正本':packed,'feature_cacheの複製':False,'teacher_cache':'F1直接源ではなく共有入力とSourceから再生成。保存監査の配列指紋を参照。',
        '生成JSON又はモデルのここでの構造解析':False})
    index_path.write_bytes(json_bytes(index))


# ----------------------------------------
def stage_initial(history_dir: Path,expected_f0: str) -> None:
    """
    機能: 自然教師射影後fit0/判断0で停止した初回を、修正版成功履歴と分離する。
    引数: history_dir(Path)、expected_f0(str)はRoot通知した旧F0。
    返り値: None。重い初回cacheは所在/指紋と再生成法だけを保存する。
    """
    history=path_of(history_dir);freeze=history/'F0入口選択前.json';frozen=load_freeze(freeze,expected_f0)
    stop=json.loads((history/'初回停止の確認.json').read_bytes())
    assert stop['F0_SHA256']==expected_f0 and stop['成功']is False and stop['モデル数']==stop['判断数']==0
    formal=ROOT/FORMAL_REL;index_path=formal/'保管索引.json';index=json.loads(index_path.read_bytes())
    assert index['F0_SHA256']!=expected_f0
    origin=save_file(freeze,formal/'検査/初回F0入口選択前.json',expected_f0)
    snap,refs=snapshot(frozen,'初回停止F0',expected_f0,history)
    aliases={'work/151過去場判別/run151.py':history/'初回run151.py',
             'work/151過去場判別/運転側Root人工の確認.json':history/'初回Root人工の確認.json'}
    resolved=resolve(frozen['ファイル'],'初回時計型停止',{item['復元先']:item for item in refs},aliases)
    extra={path.relative_to(ROOT).as_posix():sha(path)for path in history.iterdir()if path.is_file()and path.name not in ('F0入口選択前.json','初回run151.py','初回Root人工の確認.json')}
    stopped=resolve(extra,'初回停止の補足')
    cache=[{'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':sha(path)}
           for path in (history/'入口選択/cache').rglob('*')if path.is_file()]
    index.update({'初回の停止履歴':{'区分':'自然教師射影済み・fit0/判断0。成功実行のF0とは別。',
        '初回F0_SHA256':expected_f0,'原文':origin,'文書原文':snap,'全源復元参照':resolved,'停止補足':stopped,
        '初回cache非複製台帳':cache,'cache本文の意味読取':False,
        'cache再生成':'同指紋data151と旧F0共用入力を用いた射影で再生成可能。初回NPZの保存bytes同体は主張しない。',
        '修正区分':'有限で整数秒と等値のstartだけintへ無損失変換。市場値/売買閾値/bookの変更ではない。'}})
    index_path.write_bytes(json_bytes(index))


# ----------------------------------------
def stage_extra_freeze(freeze_path: Path,expected: str,label: str) -> None:
    """
    機能: 金融前F2等を元段階へ遡及追加せず別保存する。
    引数: freeze_path(Path)、expected/label(str)。
    返り値: None。共有入力・F1生成物は既存台帳から参照する。
    """
    assert re_label(label)
    frozen=load_freeze(freeze_path,expected);formal=ROOT/FORMAL_REL
    index_path=formal/'保管索引.json';index=json.loads(index_path.read_bytes())
    saved=save_file(path_of(freeze_path),formal/'検査'/f'{label}.json',expected)
    refs=resolve(frozen['ファイル'],label)
    index[label]={'SHA256':expected,'原文':saved,'全源数':len(frozen['ファイル']),'復元参照':refs}
    index_path.write_bytes(json_bytes(index))


# ----------------------------------------
def re_label(value: str) -> bool:
    """
    機能: 保存名へpath区切り等を混入させない。
    引数: value(str)は段階名。
    返り値: boolは短い安全な名前かどうか。
    """
    return bool(value)and len(value)<60 and not any(c in value for c in '/\\:..')


# ----------------------------------------
def stage_artifacts(job_path: Path,expected: str) -> None:
    """
    機能: Root通知後の金融正本/typed表/CSVproof/独立票を明示jobで保存する。
    引数: job_path(Path)、expected(str)は通知済み保存jobのSHA。
    返り値: None。金融schemaを仮定せず新たな計算や選び直しを行わない。
    """
    job_path=path_of(job_path);assert sha(job_path)==expected;job=json.loads(job_path.read_bytes())
    assert job['試行']==151 and job['Root結果通知後']is True
    formal=ROOT/FORMAL_REL;index_path=formal/'保管索引.json';index=json.loads(index_path.read_bytes());saved=[]
    for item in job['保存']:
        assert item['形式']in ('同体','gzip','参照')
        if item['形式']=='参照':
            source=path_of(item['source']);assert sha(source)==item['sha256']
            assert source.relative_to(ROOT).parts[0]in ('inputs','study','scripts','outputs')
            saved.append({'保存元':source.relative_to(ROOT).as_posix(),'形式':'同体','保存SHA256':item['sha256'],
                          '解凍SHA256':item['sha256'],'保存bytes':source.stat().st_size,'区分':'既存恒久正本の参照・新複写なし'})
            continue
        target=path_of(formal/item['正式相対path']);assert target.is_relative_to(formal.resolve())
        saved.append(save_file(path_of(item['source']),target,item['sha256'],item['形式']=='gzip'))
    index[job['区分']]=saved
    index_path.write_bytes(json_bytes(index))
