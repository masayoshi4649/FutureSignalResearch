"""151の停止根拠・監査・閲覧・目次を、巨大共有入力を重ねず仕上げる。"""
from pathlib import Path
import json
import os
from 保存部品 import ROOT,FORMAL_REL,sha,save_file,resolve,json_bytes,write_new

FORMAL=ROOT/FORMAL_REL
OUT=ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/151_過去場だけの複合判別'


def main() -> None:
    """
    機能: 停止診断・自然監査・cache後発参照・保存器を恒久化する。
    引数: なし。Root自然監査成功と金融完成通知の後にだけ実行する。
    返り値: None。再学習・条件交換・原板走査・旧150変更は行わない。
    """
    index_path=FORMAL/'保管索引.json';index=json.loads(index_path.read_bytes())
    diagnosis=ROOT/'work/151確率と集中の原因診断'
    assert sha(diagnosis/'最終の確認.json')=='0498467713e686d14469b0d7dfda59ac7f22661eda40241e5f7782a86bf224e6'
    assert sha(diagnosis/'停止.json')=='3bfb6b4424ba201fa04277f64527f86c34888b8162ae539e780f40adeff0af4a'
    saved=[]
    for name,dest,packed in [('短報.md','根拠/確率と集中の原因.md',False),
        ('背景追補の短報.md','根拠/強い反対背景と未回復の追補.md',False),
        ('診断.json','根拠/確率と集中の診断.json.gz',True),('背景追補.json','根拠/背景の追補.json.gz',True)]:
        saved.append(save_file(diagnosis/name,FORMAL/dest,sha(diagnosis/name),packed))
    source_files={p.relative_to(ROOT).as_posix():sha(p)for p in diagnosis.iterdir()if p.is_file()}
    index['停止した確率と背景の診断']={'最終確認SHA256':sha(diagnosis/'最終の確認.json'),
        '正本':saved,'復元参照':resolve(source_files,'確率と背景の事後診断',{item['復元先']:item for item in saved}),
        '新条件採用':False,'全期事後':True}
    index_path.write_bytes(json_bytes(index))
    audit=ROOT/'work/151自然選択の独立監査';stop=audit/'停止の確認.json'
    assert sha(stop)=='07e7b57d6c17533b7b2534b87020b7829dd64187cc08e1530057f68360d90d36'
    proof=audit/'自然確認/監査の確認.json'
    assert sha(proof)=='899471f1ba22e6a7ac690dcf6c334eb812f98d8a60d91492eb093d2cc69c2d37'
    audit_record=save_file(proof,FORMAL/'検査/自然選択の独立監査.json',sha(proof))
    files={p.relative_to(ROOT).as_posix():sha(p)for p in audit.rglob('*')if p.is_file()and p.suffix in ('.py','.json','.md','.txt')and'__pycache__'not in p.parts}
    index['自然選択の独立監査']={'保存票':audit_record,'復元参照':resolve(files,'自然選択の独立監査',{audit_record['復元先']:audit_record}),
        '65保存JSON再推論':True,'全35339q0と73場の教師署名重み':True,'末端比較数':1446946,
        '再学習':False,'金融算術とは別':True}
    index_path.write_bytes(json_bytes(index))
    for record in index['金融とCSV及び後発cache参照の保存']:
        if record['保存元'].endswith('監査cacheの後発参照.json'):
            late=json.loads((ROOT/record['保存元']).read_bytes())
            assert late['F1事前固定の対象だったと主張する']is False
            index['監査cacheは後発']={'参照票':record,'原cache4件の所在とSHA':late['ファイル'],
                '原cache新複製':False,'再現':'共有148の固定入力/特徴/取得/metadata/観測とdata151から隔離workへ再生成可能。保存モデル/配列署名/全q0の独立照合を証拠とする。NPZ物理bytes再現は主張しない。'}
    index_path.write_bytes(json_bytes(index))
    extras=list(Path(__file__).parent.glob('*.py'))+list(Path(__file__).parent.glob('*.json'))+[Path(__file__).parent/'保存方針.md',
        ROOT/'work/151監査cacheの追補固定.py',ROOT/'work/151正式準備3MDを作成する.py',
        ROOT/'work/151正式準備をbookとSourceへ束縛する.py',ROOT/'work/151正式閾値準備の確認.json',
        ROOT/'work/151bookとSource束縛の準備確認.json',ROOT/'work/確定三表のCSV出力/出力する.mjs',
        ROOT/'work/確定三表のCSV出力/CSVを独立再読する.py',ROOT/'work/確定三表のCSV出力/由来.json']
    items={path.relative_to(ROOT).as_posix():sha(path)for path in extras if path.is_file()}
    index['保存と表示の後発資料']=resolve(items,'保存と表示の後発資料')
    index['CSV正本']=[{'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted(OUT.glob('*.csv'))]
    assert len(index['CSV正本'])==3
    images=list((OUT/'支援画像').glob('*.png'));assert len(images)==3
    index['CSV支援画像']=[{'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p)}for p in images]
    index['Root画像確認']='RootがCSV3支援画像を目視確認。金融算術・CSV再読と別の表示検査。'
    index['段階']='主正本・初回停止・全モデル・金融・CSV・停止根拠の保管済み。文書最終確認待ち。'
    index_path.write_bytes(json_bytes(index))
    viewer='''# 151のCSVを見る

最初は[全セッションCSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/151_過去場だけの複合判別/全セッション.csv)を見る。全73場を残し、U70/P70/C1の取得・先着・既知利益/損失/差引と未知・累計を分けた。未知が含まれた全件確定差引はnullのままである。

[入口別CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/151_過去場だけの複合判別/入口別診断.csv)は主U70の595取得、[正逆比較CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/151_過去場だけの複合判別/正逆比較.csv)は11政策660比較。主は全期/BBO/H60/125pt/U70で固定し、U65等の良い行へ交換しない。N70は接続aliasで金融政策外である。

主U70は272順283逆29未11不足・到達済49.01%、全73場・平均0.8253回/時。既知利益3,338,747円/損失4,109,177円/差引−770,430円、未知5。U65は既知差引+473,678円でも55.41%・後25場−256,633円であり主ではない。予測の0.70と実測70%は別である。

初回の自然接続は教師射影後fit0/判断0で停止し、修正版F0で成功した。4cacheはF1未掲載の後発参照で、事前固定へ遡及していない。[README](README.md)、[金融正本](成果物/集計.json)、[再現手順](再現手順.md)、[保管索引](保管索引.json)に範囲を残す。

Rootが55,004セル/数値29,646セルの独立再読と3支援画像を確認した。金額はラージ板を用いたmini独立1枚IFD代用の既知小計で、10枚口座の実運用収支ではない。
'''
    replay='''# 151の保存資料からの再現

[保管索引](保管索引.json)に全Source・入力・モデル・結果の保存元/元path/SHAを残した。修正版[F0](検査/F0入口選択前.json)、[F1](検査/F1入口選択後.json)、[F2](検査/F2金融集計前.json)を区別し、現在の結果追記済みMDを実行前SHAへ使わない。Rootの実行前3MDは[原文gzip](検査/F0実行前文書.json.gz)から復元する。

## 保存実体

65モデル・q0判断・場別モデルと教師・選択対応・選択確認の69源は[単一ZIP](../../inputs/00151_過去場だけの複合判別/学習と選択の正本.zip)へ一度だけ保存した。元86,777,483bytes/ZIP9,500,078bytes。各モデルのJSON原文と署名を保持し、同じモデルの再推論を再現の主証拠とする。再学習JSONはGUID/時計等を含み得るためbytes同体を主張しない。

Sourceと人工・監査は再現資料の各ZIP、既存コードは共有ZIP/正本へ索引で結ぶ。復元は元相対pathを隔離workの根に再現し、現RootのSourceや旧正式資料を上書きしない。相対/絶対パスを許す保存器は[後発保存資料](再現資料/151保存と表示の後発資料の固定資料.zip)へ保管した。

148の100列・特徴/固定入力/取得対応/metadata・大観測gzipは共有する。原板・177MB派生入力・venv/DLL/wheelは新保存しない。CatBoost1.2.10、Python3.14.3、NumPy2.5.4、CPU1threadを条件bookどおり用いる。環境を新しく作る場合も版を合わせ、独立再推論/有限値/列名/class順を確認する。

## モデルと教師の確認

[自然独立監査票](検査/自然選択の独立監査.json)は65保存JSON再推論、全35,339q0、73場の過去教師・区画重み・配列署名・全政策所属を別実装で1,446,946末端値照合した。監査コード/CLI/復元注意は再現資料の独立監査ZIP内READMEに保存し、再学習せず保存JSONを読み推論する。全体教師射影と、当場/将来を先に除外したtrainer入力を区別して確認する。

4cacheはF1に載っていない。[後発参照票](根拠/監査cacheの後発参照.json)は当時のcache物理指紋であり、事前F1固定を意味しない。cacheはdata151のload_feature_dataset/project_teacherとsave_feature_cache/save_teacher_cacheに、条件bookの共有FileRefを渡して隔離workへ再生成できる。特徴cacheへ教師を混ぜず、教師cacheは当場未成熟排除前の候補射影である。再生成NPZ/metadataの物理bytes同体ではなく、配列・教師署名・保存モデル推論の値同体を確認する。

## 金融と初回停止

[金融正本](成果物/集計.json)、[typed三表gzip](成果物/CSV用の表.json.gz)、[別算術票](検査/金融独立検算.json)、[CSV再読票](検査/CSV独立再読.json)は同じF1選択と148保存正逆観測に基づく。金融集計の停止Source/CLIはF2全源に保存した。入口の再選択や再予測をせず、復元した選択対応と共有gzipをRoot CLIのSHA引数へ渡して別の未作成出力先へ再集計する。金融660比較15,840キーはRootの別算術検査で一致済みで、CSV三表55,004セルも独立転記一致した。

初回の[旧F0](検査/初回F0入口選択前.json)は自然教師射影後fit0/判断0で時計型停止した。旧run/元人工票・停止票・[初回文書](検査/初回停止F0実行前文書.json.gz)は別保存し、成功した修正版F0へ混同しない。初回cacheはworkに残る派生物の所在/サイズ/指紋を記録し、重い副本は正式へ作っていない。有限かつ整数秒同値のstartをintへ無損失化したSource差を履歴へ残す。

[確率・集中診断](根拠/確率と集中の原因.md)と[強い反対背景の追補](根拠/強い反対背景と未回復の追補.md)は主結果後の事後資料である。良い日・確率帯・整合群を後から主へ交換しない。全期既使用、未知IFD、近接依存、実mini/10枚口座未検証の限界を維持する。
'''
    write_new(FORMAL/'閲覧資料.md',viewer.encode('utf-8'))
    write_new(FORMAL/'再現手順.md',replay.encode('utf-8'))
    for rel in ('README.md','docs/README.md','docs/議論/README.md','study/README.md'):
        path=ROOT/rel;text=path.read_text(encoding='utf-8-sig');assert '[151：'not in text
        target=os.path.relpath(FORMAL/'README.md',path.parent).replace('\\','/')
        viewer_link=os.path.relpath(FORMAL/'閲覧資料.md',path.parent).replace('\\','/')
        paragraph=f'[151：100複合テクニカルの過去場判別を検証]({target})。主U70は595取得/全73場・平均0.8253件/時、272順283逆29未11不足・到達済49.01%で不採用。C5既知利益3,338,747円/損失4,109,177円/差引−770,430円、未知5。U65全期+473,678円でも55.41%・後25場赤字で主交換なし。65保存モデル再推論と660金融比較を確認。[CSVと分母]({viewer_link})。\n\n'
        at=text.index('[150：');path.write_text(text[:at]+paragraph+text[at:],encoding='utf-8',newline='\n')
    for rel,prefix in [('docs/README.md','議論/'),('docs/議論/README.md','')]:
        path=ROOT/rel;text=path.read_text(encoding='utf-8-sig');items=[]
        for name,label in [('予測確率と実先着率を分けて判断する.md','モデル確率と実先着率・場集中を分ける'),
                           ('長い高安とVWAPの欠測を分けて扱う.md','長い高安とVWAPの欠測を分ける')]:
            assert (ROOT/'docs/議論'/name).exists()
            if prefix+name not in text:items.append(f'[{label}]({prefix+name})。既使用診断・入力可用性と新手法採用を区別する。')
        at=text.index('[151：');path.write_text(text[:at]+'\n\n'.join(items)+'\n\n'+text[at:],encoding='utf-8',newline='\n')
    output_readme='''# 151のCSV

最初は[全セッション](全セッション.csv)を見る。主U70/P70/旧C1の全73場と既知利益・損失・差引累計、IFD未知累計を分け、未知を含む全件確定差引は空欄(null)に保つ。[入口別診断](入口別診断.csv)は595取得、[正逆比較](正逆比較.csv)は11政策660行である。

主U70は到達済49.01%・平均0.8253回/時・C5既知差引−770,430円（利益3,338,747円/損失4,109,177円）、未知5。U65は全期既知差引が正でも70%未達/後25場赤字で主ではない。モデル予測の0.70と実先着率は別で、同時IFD合算は10枚口座収支ではない。

[正式結果](../../../study/00151_広い複合テクニカルを過去場だけで判別する/README.md)、[閲覧資料](../../../study/00151_広い複合テクニカルを過去場だけで判別する/閲覧資料.md)、[再現手順](../../../study/00151_広い複合テクニカルを過去場だけで判別する/再現手順.md)を参照する。
'''
    write_new(OUT/'README.md',output_readme.encode('utf-8'))
    print('停止根拠/自然監査/後発源/閲覧再現/4目次と共通知見2件を保管')


if __name__=='__main__':main()
