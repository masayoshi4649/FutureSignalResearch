"""151保存器を人工の小型ファイルだけで検査する。自然入力は開かない。"""
from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import sys
import uuid
import zipfile
import 保存部品 as module


def main() -> None:
    """
    機能: 人工Rootで相対票/F0/F1/初回停止/F2/成果物保存と拒否境界を通す。
    引数: なし。
    返り値: None。実リポジトリの正式・自然判断・モデル・教師・金融は不使用。
    """
    original_root=module.ROOT
    sandbox=original_root/'work/151正式保存の人工'/uuid.uuid4().hex
    sandbox.mkdir(parents=True,exist_ok=False);assert sandbox.resolve().is_relative_to((original_root/'work').resolve())
    module.ROOT=sandbox;checks=[]

    def put(rel: str,body: bytes) -> Path:
        """
        機能: 人工Root内の新規fixtureを作る。
        引数: rel(str)、body(bytes)。
        返り値: Pathはfixture。
        """
        path=sandbox/rel;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(body);return path

    def dump(rel: str,value: dict) -> Path:
        """
        機能: 人工JSONをUTF-8で作る。
        引数: rel(str)、value(dict)。
        返り値: Pathはfixture。
        """
        return put(rel,module.json_bytes(value))

    def rejected(function) -> None:
        """
        機能: 禁止境界が例外で止まることを確認する。
        引数: function(callable)は人工処理。
        返り値: None。
        """
        try:function()
        except (AssertionError,FileNotFoundError):return
        raise AssertionError('禁止境界が通過した')

    source=put('work/小型源.py','人工だけ\n'.encode())
    digest=module.sha(source)
    assert module.normalized_files({'work/小型源.py':digest})==module.normalized_files({str(source):digest})
    rejected(lambda:module.path_of(sandbox.parent/'範囲外'))
    rejected(lambda:module.normalized_files({'work/小型源.py':digest,str(source):digest}))
    target=sandbox/'study/小型.zip'
    rejected(lambda:module.pack_zip({'work/小型源.py':'0'*64},target))
    assert not target.exists();checks.append('相対絶対同体/範囲外重複拒否/誤SHAで公開ZIPを作らない')
    current_run=put('work/151過去場判別/run151.py',b'current')
    current_check=dump('work/151過去場判別/運転側Root人工の確認.json',{'人工':'現在'})
    shared=put('inputs/共有.json.gz',gzip.compress(b'{"opaque":true}',mtime=0))
    runtime='work/人工runtime';files={}
    for name in module.CORE:
        body=('人工の実行前 '+name+'\n').encode('utf-8')
        logical=module.FORMAL_REL+'/'+name
        put(logical,body);put(runtime+'/F0実行前文書/'+name,body);files[logical]=hashlib.sha256(body).hexdigest()
    files.update({current_run.relative_to(sandbox).as_posix():module.sha(current_run),
                  current_check.relative_to(sandbox).as_posix():module.sha(current_check),
                  shared.relative_to(sandbox).as_posix():module.sha(shared)})
    f0=dump(runtime+'/F0入口選択前.json',{'試行':151,'主政策':'U70','人工':True,'ファイル':files})
    # 結果編集後でもRootの同指紋退避原文だけからsnapshotを復元できます。
    put(module.FORMAL_REL+'/README.md','人工の現在結果\n'.encode())
    module.stage_f0(f0,module.sha(f0))
    formal=sandbox/module.FORMAL_REL
    with gzip.open(formal/'検査/F0実行前文書.json.gz','rb')as original:
        assert json.load(original)['文書'][0]['本文'].startswith('人工の実行前')
    checks.append('相対F0/共有gzip非複写/結果後はRoot実行前退避を使用')
    history='work/人工の初回停止';old_files=dict(files)
    old_run=put(history+'/初回run151.py',b'old')
    old_check=dump(history+'/初回Root人工の確認.json',{'人工':'初回'})
    old_files['work/151過去場判別/run151.py']=module.sha(old_run)
    old_files['work/151過去場判別/運転側Root人工の確認.json']=module.sha(old_check)
    old_f0=dump(history+'/F0入口選択前.json',{'試行':151,'主政策':'U70','人工':True,'ファイル':old_files})
    for name in module.CORE:put(history+'/F0実行前文書/'+name,(sandbox/runtime/'F0実行前文書'/name).read_bytes())
    dump(history+'/初回停止の確認.json',{'成功':False,'F0_SHA256':module.sha(old_f0),'モデル数':0,'判断数':0})
    put(history+'/入口選択/cache/teacher_only/teachers.npz','人工opaque-cache'.encode())
    module.stage_initial(sandbox/history,module.sha(old_f0))
    index=json.loads((formal/'保管索引.json').read_bytes())
    assert index['初回の停止履歴']['初回F0_SHA256']!=index['F0_SHA256']
    assert len(index['初回の停止履歴']['初回cache非複製台帳'])==1
    checks.append('初回false停止/旧run人工票alias/fit0判断0と成功F0を分離/cacheは指紋だけ')
    generated=sandbox/runtime/'入口選択';new_files={}
    for name in module.GENERATED:
        path=dump(runtime+'/入口選択/'+name,{'人工':True,'large_integer':9007199254740993,'未知':None})
        new_files[path.relative_to(sandbox).as_posix()]=module.sha(path)
    model=dump(runtime+'/入口選択/models/008.json',{'人工モデル':True})
    new_files[model.relative_to(sandbox).as_posix()]=module.sha(model)
    put(runtime+'/入口選択/cache/feature_only/features.npz','非複写'.encode())
    f1=dump(runtime+'/F1入口選択後.json',{'試行':151,'主政策':'U70','人工':True,
        'ファイル':{**files,**new_files,f0.relative_to(sandbox).as_posix():module.sha(f0)}})
    module.stage_f1(f1,module.sha(f1),generated)
    index=json.loads((formal/'保管索引.json').read_bytes())
    with zipfile.ZipFile(sandbox/index['学習と選択の正本']['保存元ZIP'])as bundle:
        assert len(bundle.namelist())==5 and not any('/cache/'in name for name in bundle.namelist())
        for name,expected in new_files.items():assert hashlib.sha256(bundle.read(name)).hexdigest()==expected
    checks.append('F1全4JSONとモデルを一ZIP/整数原文null保持/cache非複写')
    f2=dump(runtime+'/F2.json',{'試行':151,'主政策':'U70','人工':True,'ファイル':new_files})
    module.stage_extra_freeze(f2,module.sha(f2),'F2金融前')
    index=json.loads((formal/'保管索引.json').read_bytes())
    assert len(index['F2金融前']['復元参照']['共有源'])==5
    checks.append('F2はF1一ZIPを全共有し新モデル判断を再複製しない')
    summary=dump(runtime+'/人工集計.json',{'人工':True,'未知':None,'利益':123,'損失':456})
    job=dump('work/人工保存job.json',{'試行':151,'Root結果通知後':True,'区分':'金融人工',
        '保存':[{'source':str(summary),'sha256':module.sha(summary),'正式相対path':'成果物/人工集計.json.gz','形式':'gzip'},
                {'source':str(shared),'sha256':module.sha(shared),'形式':'参照'}]})
    module.stage_artifacts(job,module.sha(job))
    with gzip.open(formal/'成果物/人工集計.json.gz','rb')as stream:assert stream.read()==summary.read_bytes()
    invalid=dump('work/不正job.json',{'試行':151,'Root結果通知後':False,'保存':[]})
    rejected(lambda:module.stage_artifacts(invalid,module.sha(invalid)))
    checks.append('金融typed等の明示job保存と恒久参照/結果未通知job拒否')
    module.ROOT=original_root
    cli=Path(__file__).parent/'保管する.py'
    help_result=subprocess.run([sys.executable,'-X','utf8',str(cli),'--help'],capture_output=True)
    missing=subprocess.run([sys.executable,'-X','utf8',str(cli)],capture_output=True)
    assert help_result.returncode==0 and missing.returncode!=0
    checks.append('CLI help成功/無指定拒否。自然操作は呼ばない')
    proof={'成功':True,'区分':'人工fixtureだけ','検査群':checks,'群数':len(checks),
        '人工Root':sandbox.relative_to(original_root).as_posix(),'自然判断/モデル/教師cache/金融/Raw読取':False}
    target=Path(__file__).parent/'人工の確認.json'
    with target.open('x',encoding='utf-8',newline='\n')as output:json.dump(proof,output,ensure_ascii=False,indent=2);output.write('\n')
    print(json.dumps({'成功':True,'群数':len(checks),'人工票SHA256':hashlib.sha256(target.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__=='__main__':main()
