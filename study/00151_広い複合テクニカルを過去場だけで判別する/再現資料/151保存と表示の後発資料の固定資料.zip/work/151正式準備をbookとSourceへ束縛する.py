"""151の準備3MDを現在book/停止済み部品へ結び、教師準備と取得結合を分ける。"""
from pathlib import Path
import gzip
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent.parent
FORMAL = ROOT / 'study/00151_広い複合テクニカルを過去場だけで判別する'
BOOK = ROOT / 'work/151過去場判別/条件.json'
CANONICAL = ROOT / 'inputs/00151_過去場だけの複合判別/条件.json'
BOOK_SHA = '09bad678c01cc7db614137647161ec695f20cb148770987a515ee4cfa71f8f2d'
SOURCES = {
    'work/151過去場判別/data151.py': '3b92ff77a28bf82e6cf8e5dc504cc5586f4101c1e28d0bc12b29bc7cd0efdd8c',
    'work/151過去場判別/model151.py': 'bd5639b76d8ce12354ef1e04fef1534ca3af23bc416c2ada7ca783122526c7ae',
    'work/過去場だけの教師選択と時間区画重み/教師選択.py': '075ac230ea4ec2b7c5aa3a59fd7348941a903f9612611ef7c26ad1d5705017df',
    'scripts/入口研究/固定特徴から可読条件を選択する.py': '2f46be32a23ce2c1e5e99f2714ed4fd1eb14c545e4e150a2efd8d112e5c5344a'}


def sha(path: Path) -> str:
    """
    機能: 小型の条件・コード・文書を物理bytesで識別する。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def replace_once(text: str, old: str, new: str) -> str:
    """
    機能: 明示した準備文1箇所だけを訂正する。
    引数: text/old/new(str)は対象・元・新本文。
    返り値: strは訂正後本文。予定外の差分は停止する。
    """
    assert text.count(old) == 1, old
    return text.replace(old,new,1)


# ----------------------------------------
def rows(text: str) -> list:
    """
    機能: 57手法×9尺度の表だけを抜き出す。
    引数: text(str)はMarkdown。
    返り値: listはID・手法・9尺度のセル列。
    """
    result=[]
    for line in text.splitlines():
        cells=[part.strip()for part in line.split('|')[1:-1]]
        if len(cells)==11 and re.fullmatch(r'[A-Z]\d{2}',cells[0]):result.append(cells)
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: 条件を一度恒久保存し、F0前の準備文書だけをSourceへ束縛する。
    引数: なし。実装・book・自然データ・旧試行・目次は変更しない。
    返り値: None。run151はレビュー中としてSHAを固定しない。
    """
    assert sha(BOOK)==BOOK_SHA and all(sha(ROOT/path)==expected for path,expected in SOURCES.items())
    initial=ROOT/'work/151正式閾値準備の確認.json'
    assert sha(initial)=='1441ae7fd09051bc079d0ba567fd4d3f11645dfcfe49222ebf7743a772fb6255'
    prepared=json.loads(initial.read_bytes())
    originals={name:(FORMAL/name).read_bytes()for name in ('README.md','条件.md','設定と結果.md')}
    assert {name:hashlib.sha256(body).hexdigest()for name,body in originals.items()}==prepared['準備3MDの作成時指紋_事前F0ではない']
    protected_paths=[ROOT/path for path in SOURCES]+[BOOK,ROOT/'README.md',ROOT/'docs/README.md',ROOT/'docs/議論/README.md',ROOT/'study/README.md',ROOT/'AGENTS.md',
        ROOT/'study/00150_突破の現在状態と背景で順逆を切り替える/保管索引.json',
        ROOT/'study/00150_突破の現在状態と背景で順逆を切り替える/検査/正式保存の最終確認.json']
    protected={path.relative_to(ROOT).as_posix():sha(path)for path in protected_paths}
    snapshot={'区分':'151 F0未固定の準備稿原文。自然実行前固定票を後造りするものではない。',
        '元準備票SHA256':sha(initial),'文書':[{'path':(FORMAL/name).relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(body).hexdigest(),'本文':body.decode('utf-8')}for name,body in originals.items()]}
    archive=ROOT/'work/151準備束縛/閾値準備3MD原文.json.gz'
    archive.parent.mkdir(parents=True,exist_ok=True)
    with archive.open('xb')as output:output.write(gzip.compress((json.dumps(snapshot,ensure_ascii=False,indent=2)+'\n').encode('utf-8'),mtime=0))
    created=not CANONICAL.exists()
    if created:
        CANONICAL.parent.mkdir(parents=True,exist_ok=True)
        with CANONICAL.open('xb')as output:output.write(BOOK.read_bytes())
    assert sha(CANONICAL)==BOOK_SHA
    book=json.loads(CANONICAL.read_bytes())
    assert book['training']['window_sessions']==20 and book['training']['minimum_physical_pairs']==1000 and book['training']['minimum_contributing_sessions']==8
    assert book['selection']['thresholds']=={'P70':.7,'P65':.65,'P60':.6}
    assert book['selection']['minimum_score_margin']==.05 and book['selection']['minimum_forward_probability']==.4 and book['selection']['minimum_known_roles']==2
    assert book['classifier_parameters']['random_seed']==151 and book['classifier_parameters']['iterations']==128
    readme=originals['README.md'].decode('utf-8')
    readme=replace_once(readme,
        '**実行前の準備稿。自然ラベル射影・学習・予測・選択・金融は未実行。Rootの条件bookと専用Sourceは準備中で、完全SHA未取得・F0未固定。** この時点の文書指紋を事前F0の成立と読み替えない。',
        '**実行前。自然の教師射影・学習・予測・選択・金融は未実行。条件bookとdata/model・教師純部品・共通linkを現在のSourceに照合済み。run151はレビュー中、F0は未固定。** 準備文書の指紋を事前F0の成立と読み替えない。')
    readme=replace_once(readme,
        '全q0の予測・判断を完了してから取得対応/metadataを読み、q1価格・取得成否・将来ラベルで選び直さない。',
        '新しい選択結果の取得結合は、全q0の予測・判断を保存した後だけ行い、q1価格・取得成否・将来ラベルで選び直さない。教師射影器はそれより前の学習準備時に、全保存観測・capture/metaを読んで教師候補を作る。学習selectorが当場/将来を先に除外し、trainerへ渡すのは過去かつ成熟したX/y/wだけである。')
    readme=replace_once(readme,
        'Rootのbook・専用data/model/logic・教師純部品・実行器の完全SHAは**未取得**。100列辞書と元V7だけを既存恒久正本の指紋へ照合した。Root実装/人工/独立確認とbook固定後にSource/依存/正式原文をF0へ束縛し、それまで自然実行しない。',
        '条件の数値正本は[恒久book](../../inputs/00151_過去場だけの複合判別/条件.json)、SHA256 `09bad678c01cc7db614137647161ec695f20cb148770987a515ee4cfa71f8f2d`。data/model・教師純部品・共通linkの完全SHAは[条件末尾](条件.md)へ束縛した。run151の完全SHAはレビュー中のため**未固定**。Root実装/人工/独立確認の完了後に全Source/依存/実行前原文をF0へ固定し、それまで自然実行しない。')
    conditions=originals['条件.md'].decode('utf-8')
    conditions=replace_once(conditions,
        '**Rootのbook/Sourceは実装中で完全SHA未取得、F0は未固定。自然ラベル・モデル・学習・予測・金融は未実行。** 以下の閾値は採用指示に基づく準備で、Root book固定後に完全SHAと源pathを追補する。存在しないSHAや検証結果を記入しない。',
        '**条件bookとdata/model・教師純部品・共通linkの現Sourceを照合済み。run151はレビュー中・SHA未固定、F0も未固定。自然の教師射影・モデル・学習・予測・金融は未実行。** 数値条件の正本は[恒久book](../../inputs/00151_過去場だけの複合判別/条件.json)。存在しないSHAや検証結果を記入しない。')
    conditions=replace_once(conditions,
        '現在/未来場のラベルpathを学習部品へ渡さない。',
        'trainerの引数へ当場/将来のラベル又はそのpathを渡さない。教師候補の事前射影が全保存観測を読む工程とは分ける。')
    conditions=replace_once(conditions,
        '全q0のBUY/SELL予測・判断を完了してからcapture/metaを読み、q1で選び直さない。',
        '全q0のBUY/SELL予測・判断の保存後だけ、選択結果をcapture/metaへ取得結合し、q1で選び直さない。これと別に、教師射影器は学習準備時に全保存観測/capture/metaを読み候補を作る。学習selectorは当場/将来を先に除外し、その後に過去窓と成熟条件で絞ったX/y/wだけをtrainerへ渡す。')
    conditions=replace_once(conditions,
        '| Root条件book | 作成中。path/完全SHA未取得・F0未固定 |',
        '| Root条件book | inputs/00151_過去場だけの複合判別/条件.json・09bad678c01cc7db614137647161ec695f20cb148770987a515ee4cfa71f8f2d |')
    conditions=replace_once(conditions,
        '| 専用data/model/logic/driver | Root準備中。完全SHA未取得 |',
        '| data151.py | work/151過去場判別/data151.py・3b92ff77a28bf82e6cf8e5dc504cc5586f4101c1e28d0bc12b29bc7cd0efdd8c |\n| model151.py | work/151過去場判別/model151.py・bd5639b76d8ce12354ef1e04fef1534ca3af23bc416c2ada7ca783122526c7ae |\n| run151.py | work/151過去場判別/run151.py・レビュー中、完全SHA未固定 |\n| 共通link | scripts/入口研究/固定特徴から可読条件を選択する.py・2f46be32a23ce2c1e5e99f2714ed4fd1eb14c545e4e150a2efd8d112e5c5344a |')
    conditions=replace_once(conditions,
        '| 教師純部品 | 再用予定。完全SHA未取得・本稿で仮造しない |',
        '| 教師純部品 | work/過去場だけの教師選択と時間区画重み/教師選択.py・075ac230ea4ec2b7c5aa3a59fd7348941a903f9612611ef7c26ad1d5705017df |')
    conditions+='''

## F0前のSource束縛追補

恒久bookは元work/151過去場判別/条件.jsonと同bytesを一度保存した。完全SHAは上表へ記録し、run151のレビュー中版を固定済みと呼ばない。work実装は停止時までの参照で、停止後は正式な小型源保存と共有依存から再現できるようにする。

教師のクラス前段は保存touch方向−1/0/+1、モデルへ渡すとき0=A/1=N/2=Fへ明示写像する。bookのminimum_classes=[−1,0,1]とモデルclass=[0,1,2]はこの変換の前後であり、未知ラベルを0へ補完するものではない。canonicalは同物理q1の(q0_index,q0_line,event_id)最初、各pairのside順はBUY/SELL。具体的な学習行順と配列指紋は停止したSourceと保存監査で確認する。

bookの固定モデル設定にはallow_writing_files=false、verbose=falseも含む。特徴読み込みはcapture/観測を引数に取らず、教師射影へは識別/時計metadataだけを渡してXと型を分離する。教師射影器の全期間読取を「予測が未来ラベルを使った」と同一視せず、過去場・成熟selectorの先行除外とtrainer引数の境界を人工/独立確認で検査する。逆に「全q0判断までcapture/metaを一切読まない」とも記さない。
'''
    settings=originals['設定と結果.md'].decode('utf-8')
    settings=replace_once(settings,
        '**自然未実行。Root book/Sourceの完全SHA未取得、F0未固定。**',
        '**自然未実行。Root bookとdata/model・教師純部品・共通linkは現Sourceへ束縛済み、run151はレビュー中、F0未固定。**')
    settings=replace_once(settings,
        'Source/book指紋の取得後だけF0へ束縛する。',
        'Source停止・run151レビューと全必要指紋の取得後だけF0へ束縛する。')
    settings+='''

## book/Sourceへの束縛追補（F0未固定）

[条件JSON](../../inputs/00151_過去場だけの複合判別/条件.json)の物理SHA256は `09bad678c01cc7db614137647161ec695f20cb148770987a515ee4cfa71f8f2d`。data/model・教師純部品・共通linkの完全指紋は条件表へ記録、run151はレビュー中なのでSHA未固定である。上の全57行513セル・閾値は変更していない。

教師準備では全保存観測/capture/metaを先に読み候補を射影する。一方、学習selectorは当場/将来を先に除き、trainerへ過去成熟X/y/wだけを渡す。予測の全q0判断を保存後にだけ、選択結果のcapture/meta結合を行う。教師準備・過去学習・現在予測・取得結合を別工程として監査する。
'''
    for name,text in [('README.md',readme),('条件.md',conditions),('設定と結果.md',settings)]:
        (FORMAL/name).write_text(text,encoding='utf-8',newline='\n')
    assert rows(originals['設定と結果.md'].decode('utf-8'))==rows(settings)and len(rows(settings))==57
    links=[]
    for name in originals:
        for match in re.finditer(r'\[[^\]]+\]\(([^)]+)\)',(FORMAL/name).read_text(encoding='utf-8')):
            target=match.group(1).split('#')[0]
            if target and '://'not in target:
                assert (FORMAL/target).exists(),(name,target)
                links.append((name,target))
    assert protected=={path.relative_to(ROOT).as_posix():sha(path)for path in protected_paths}
    proof={'成功':True,'編集停止':True,'区分':'151 F0前のbook/Source束縛準備。run151レビュー中。',
        'F0固定':False,'自然ラベル射影/学習/予測/選択/金融/Raw/追加2場':False,
        '条件book':{'path':CANONICAL.relative_to(ROOT).as_posix(),'sha256':sha(CANONICAL),'bytes':CANONICAL.stat().st_size,'新規一度保存':created},
        '照合済みSource':SOURCES,'run151完全SHA固定':False,
        '準備稿原文退避':{'path':archive.relative_to(ROOT).as_posix(),'sha256':sha(archive),'事前F0ではない':True},
        '教師の全保存観測capture読取と予測後取得結合を分離':True,'元閾値と全57行513セル同体':True,
        'ローカルリンク全実在':len(links),'旧試行/目次/AGENTS/Source前後同体':protected,
        '準備3MD指紋_F0ではない':{name:sha(FORMAL/name)for name in originals},
        '未完':'run151レビュー停止とRoot F0固定通知を待つ。自然は未許可。'}
    target=ROOT/'work/151bookとSource束縛の準備確認.json'
    with target.open('x',encoding='utf-8',newline='\n')as output:json.dump(proof,output,ensure_ascii=False,indent=2);output.write('\n')
    print(json.dumps({'成功':True,'bookSHA256':sha(CANONICAL),'準備票SHA256':sha(target),'リンク':len(links),'F0固定':False},ensure_ascii=False))


if __name__=='__main__':main()
