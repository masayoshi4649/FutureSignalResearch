"""151正式文書だけを非金融で限定照合する。archive最終通知後に実行する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import re
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def fingerprint(path: Path) -> dict:
    """
    機能: 文書と小型Sourceの物理指紋を保存する。
    引数: path(Path)。返り値: dict。
    """
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def catalog(text: str) -> list[str]:
    """
    機能: 後追記の状態表と分けて57行9尺度を抽出する。
    引数: text(str)。返り値: list[str]。
    """
    return [line for line in text.splitlines() if re.match(r'^\|\s+[A-Z]\d{2}\s+\|', line)
            and len(line.split('|')) == 13]


def main() -> None:
    """
    機能: 最終author票とF0原文を指定しprefix/513/冒頭/リンク/Sourceを確認する。
    引数: CLI --formal/--snapshot/--f0/--author(Path)、--author-sha256(str)。
    返り値: None。金融/ラベルJSONとリンク先本文は開かず正式を編集しない。
    """
    parser = argparse.ArgumentParser()
    for name in ('formal', 'snapshot', 'f0', 'author'): parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--author-sha256', required=True)
    args = parser.parse_args(); formal = args.formal
    sources = [ROOT / 'work/151過去場判別' / name for name in ('run151.py', 'data151.py', 'model151.py')]
    sources += [ROOT / 'work/過去場だけの教師選択と時間区画重み/教師選択.py',
                ROOT / 'scripts/入口研究/固定特徴から可読条件を選択する.py']
    docs = [formal / name for name in ('README.md', '条件.md', '設定と結果.md')]
    paths = docs + [args.snapshot, args.f0, args.author] + sources
    before = {path: fingerprint(path) for path in paths}
    assert before[args.author]['sha256'] == args.author_sha256
    snapshot = json.loads(gzip.decompress(args.snapshot.read_bytes()))
    by_path = {row['path'].replace('\\', '/'): row for row in snapshot['文書']}
    original = {}
    for path in docs:
        row = by_path[path.relative_to(ROOT).as_posix()]
        raw = row['本文'].encode('utf-8'); assert hashlib.sha256(raw).hexdigest() == row['sha256']
        original[path.name] = raw
    for name in ('条件.md', '設定と結果.md'):
        assert (formal / name).read_bytes().startswith(original[name])
    rows = catalog((formal / '設定と結果.md').read_text(encoding='utf-8'))
    assert rows == catalog(original['設定と結果.md'].decode('utf-8')) and len(rows) == 57
    assert len({row.split('|')[1].strip() for row in rows}) == 57
    assert all(len(row.split('|')[3:-1]) == 9 for row in rows)
    readme = (formal / 'README.md').read_text(encoding='utf-8')
    intro = readme.split('\n\n')[1]
    assert '実行' in intro and '主U70' in intro and '未達' in intro
    fixed = json.loads(args.f0.read_bytes())
    declared = {(Path(k) if Path(k).is_absolute() else ROOT / k).resolve(): v for k, v in fixed['ファイル'].items()}
    assert fixed['成功'] and fixed['試行'] == 151
    assert all(declared[p.resolve()] == before[p]['sha256'] for p in sources)
    count = 0
    for path in docs:
        for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if '://' in target or target.startswith('#'): continue
            local = unquote(target.strip('<>').split('#', 1)[0])
            assert (path.parent / local).exists(), (path.name, target)
            count += 1
    assert before == {path: fingerprint(path) for path in paths}
    proof = {'成功': True, '試行': 151, '編集停止': True, '条件/設定のF0元全bytesがprefix保持': True,
             'V7': {'手法': 57, '尺度': 9, 'セル': 513, '全行文字同体': True},
             'README冒頭': '実行済み/主U70未達', '全ローカルリンク実在': count,
             'Source5源はF0同体/全対象前後同体': True, '対象指紋': list(before.values()),
             '金融/ラベルJSON/Raw/追加2場読取': False, '金融数値妥当性検査': False,
             '金融数値はRoot別算術票へ分離': True, '正式/Source/次準備変更': False,
             '確認コード': fingerprint(Path(__file__))}
    output = HERE / '確認の記録.json'
    output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'セル': 513, 'リンク': count,
                      '停止票SHA256': fingerprint(output)['sha256']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
