"""151正式文書の数値とCSVを、停止金融正本へRootが別照合する。"""
from pathlib import Path
import hashlib
import json
import re
from urllib.parse import unquote
import zipfile

ROOT = Path(__file__).resolve().parent.parent
STUDY = ROOT / 'study/00151_広い複合テクニカルを過去場だけで判別する'
POLICIES = ('C0', 'C1', 'RC1', 'P70', 'RP70', 'U70', 'RU70', 'P65', 'U65', 'P60', 'U60')


def sha(path: Path) -> str:
    """
    機能: 物理ファイルの指紋を計算する。
    引数: path(Path)。返り値: strはSHA256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def integer(text: str) -> int:
    """
    機能: 円表記の区切りと単位だけを除いて整数へ写す。
    引数: text(str)。返り値: int。未知NULLは数値へ補完しない。
    """
    return int(text.replace(',', '').replace('円', '').replace('−', '-').strip())


# ----------------------------------------
def main() -> None:
    """
    機能: 全政策表・前後表・CSV指紋・新文書リンク・模型ZIPの保存を検査する。
    引数: なし。返り値: None。自然価格の再走査や政策の再選択はしない。
    """
    summary_path = STUDY / '成果物/集計.json'
    assert sha(summary_path) == 'ab002c2088784bb45ea86800550013ae44637f39d4bafb7a70e42814789ccd04'
    summary = json.loads(summary_path.read_bytes())
    content = (STUDY / 'README.md').read_text(encoding='utf-8')
    table = {}
    for line in content.splitlines():
        if line.startswith('| '):
            values = [value.strip() for value in line.strip('|').split('|')]
            table[values[0]] = values
    checked = 0
    for policy in POLICIES:
        row = table[policy]
        values = summary['集計']['all'][policy]['BBO']['3600']['125']
        assert list(map(integer, row[1].split('/'))) == [values['entries'], values['sessions']]
        assert list(map(integer, row[2].split('/'))) == [values[key] for key in ('forward', 'adverse', 'neither', 'censored')]
        assert row[3] == f"{100 * values['resolved_rate']:.2f}%"
        assert list(map(integer, row[4:8])) == [values[key] for key in ('ifd_net5_profit', 'ifd_net5_loss', 'ifd_net5_sum', 'ifd_unknown')]
        checked += 11
    for policy in ('U70', 'U65', 'U60'):
        for part, label in (('train', '前48場'), ('validation', '後25場')):
            row = table[policy + '・' + label]
            values = summary['集計'][part][policy]['BBO']['3600']['125']
            assert integer(row[1]) == values['entries']
            assert list(map(integer, row[2].split('/'))) == [values[key] for key in ('forward', 'adverse', 'neither', 'censored')]
            assert row[3] == f"{100 * values['resolved_rate']:.2f}%"
            assert row[4] == f"{summary['頻度'][part][policy]['全時間取得毎時']:.4f}"
            assert list(map(integer, row[5:9])) == [values[key] for key in ('ifd_net5_profit', 'ifd_net5_loss', 'ifd_net5_sum', 'ifd_unknown')]
            checked += 11
    output = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/151_過去場だけの複合判別'
    for name, expected in {'正逆比較.csv': 'f665b1bd543d02f1f913adc4a49b6b35a64e5a4dde96b5332ad29df1414df888',
                           '入口別診断.csv': '813fd83067816aaea46fa409fe7df8b0f8d4a1daf5cb8d16103f132978898872',
                           '全セッション.csv': 'd9ae6fc81a30e4243a3e12b8be3414a8123c3e316f4fb76ab399aec9ace9525d'}.items():
        assert sha(output / name) == expected
    documents = list(STUDY.glob('*.md')) + [ROOT / ('docs/議論/' + name) for name in
        ('予測確率と実先着率を分けて判断する.md', '長い高安とVWAPの欠測を分けて扱う.md')]
    links = 0
    for path in documents:
        for target in re.findall(r'\[[^\]]*\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if '://' in target or target.startswith('#'):
                continue
            local = unquote(target.strip('<>').split('#')[0])
            assert (path.parent / local).exists(), (str(path), target)
            links += 1
    archive = ROOT / 'inputs/00151_過去場だけの複合判別/学習と選択の正本.zip'
    assert sha(archive) == '61e4826a61e06440b7914b3e9eff0539ab5f8632d389a83515108f9a46f423cb'
    with zipfile.ZipFile(archive) as bundle:
        assert bundle.testzip() is None and len(bundle.namelist()) == 69
    assert '場別の頻度差は許容し、各時刻の強制発注や均等化はしない' in (ROOT / 'AGENTS.md').read_text(encoding='utf-8')
    result = {'成功': True, '試行': 151, '正式表の金融照合値': checked,
        '局所リンク数': links, '金融正本SHA256': sha(summary_path),
        'CSV3物理SHA一致': True, 'モデルと選択ZIP69源CRC': True,
        '新しい金融計算又は採否': False,
        '確認文書': {p.relative_to(ROOT).as_posix(): sha(p) for p in documents}}
    target = ROOT / 'work/151正式数値とリンクのRoot確認.json'
    with target.open('x', encoding='utf-8', newline='\n') as sink:
        json.dump(result, sink, ensure_ascii=False, indent=2, allow_nan=False)
        sink.write('\n')
    print(json.dumps({'成功': True, '金融値': checked, '局所リンク': links, 'sha256': sha(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
