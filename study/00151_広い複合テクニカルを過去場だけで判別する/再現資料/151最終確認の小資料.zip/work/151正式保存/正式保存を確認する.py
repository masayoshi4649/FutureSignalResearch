"""151の保存源復元・条件不変・金融/自然監査・リンクを最終確認する。"""
from pathlib import Path
import argparse
import gzip
import json
import re
from 保存部品 import ROOT,FORMAL_REL,CORE,sha,registry,check_reference,save_file,pack_zip,json_bytes,write_new

FORMAL=ROOT/FORMAL_REL


def rows(text: str) -> list:
    """
    機能: 57手法の9尺度だけを抽出する。
    引数: text(str)はMarkdown。
    返り値: listはID・手法・9尺度のセル。
    """
    result=[]
    for line in text.splitlines():
        cells=[value.strip()for value in line.split('|')[1:-1]]
        if len(cells)==11 and re.fullmatch(r'[A-Z]\d{2}',cells[0]):result.append(cells)
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: Author票を作り、文書独立票受領後だけ最終停止票を保存する。
    引数: --review(Path|None)は編集停止済み限定文書確認票。
    返り値: None。再学習/金融再計算/Source/旧150変更は行わない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--review',type=Path);args=parser.parse_args()
    index_path=FORMAL/'保管索引.json';index=json.loads(index_path.read_bytes());_,by_sha=registry()
    stages=[('修正版F0',index['F0原文'],index['F0_SHA256']),('F1',index['F1原文'],index['F1_SHA256']),
        ('F2',index['F2金融集計前']['原文'],index['F2金融集計前']['SHA256']),
        ('初回停止F0',index['初回の停止履歴']['原文'],index['初回の停止履歴']['初回F0_SHA256'])]
    source_pairs=set();counts={}
    for stage,record,expected in stages:
        original=ROOT/record['保存元'];assert sha(original)==expected
        files=json.loads(original.read_bytes())['ファイル'];counts[stage]=len(files)
        for name,digest in files.items():
            source_pairs.add((name,digest))
    for name,digest in source_pairs:
        assert digest in by_sha,(name,digest)
        check_reference(by_sha[digest],digest)
    with gzip.open(FORMAL/'検査/F0実行前文書.json.gz','rb')as original:
        docs={Path(item['path']).name:item['本文'].encode('utf-8')for item in json.load(original)['文書']}
    for name in ('条件.md','設定と結果.md'):assert(FORMAL/name).read_bytes().startswith(docs[name])
    table=rows((FORMAL/'設定と結果.md').read_text(encoding='utf-8'))
    assert len(table)==57 and table==rows(docs['設定と結果.md'].decode('utf-8'))
    assert sha(ROOT/'inputs/00151_過去場だけの複合判別/条件.json')=='09bad678c01cc7db614137647161ec695f20cb148770987a515ee4cfa71f8f2d'
    assert sha(FORMAL/'成果物/集計.json')=='ab002c2088784bb45ea86800550013ae44637f39d4bafb7a70e42814789ccd04'
    summary=json.loads((FORMAL/'成果物/集計.json').read_bytes());value=summary['集計']['all']['U70']['BBO']['3600']['125']
    assert [value[key]for key in ('entries','forward','adverse','neither','censored','ifd_unknown','ifd_net5_profit','ifd_net5_loss','ifd_net5_sum')]==[595,272,283,29,11,5,3338747,4109177,-770430]
    assert summary['主評価']=={'全場最低1':True,'到達済70%':False,'全時間毎時1以上':False,'三目標共同':False}
    csv=json.loads((FORMAL/'検査/CSV独立再読.json').read_bytes());assert csv['成功']and csv['全データセル比較数']==55004 and csv['数値比較数']==29646
    financial=json.loads((FORMAL/'検査/金融独立検算.json').read_bytes());assert financial['成功']
    natural=json.loads((FORMAL/'検査/自然選択の独立監査.json').read_bytes());assert natural['成功']
    for record in index['CSV正本']:assert sha(ROOT/record['path'])==record['sha256']
    links=[]
    paths=list(FORMAL.glob('*.md'))+[ROOT/rel for rel in ('README.md','docs/README.md','docs/議論/README.md','study/README.md')]
    for path in paths:
        for match in re.finditer(r'\[[^\]]+\]\(([^)]+)\)',path.read_text(encoding='utf-8-sig')):
            name=match.group(1).strip('<>').split('#')[0]
            if name and '://'not in name:
                assert(path.parent/name).exists(),(path,name);links.append((path.relative_to(ROOT).as_posix(),name))
    text=(FORMAL/'README.md').read_text(encoding='utf-8');assert '**実行済み。主U70'in text and '未達・不採用'in text
    assert '自然教師射影済み・モデル0/判断0'in text and 'F1に含まれていない'in text
    old=ROOT/'study/00150_突破の現在状態と背景で順逆を切り替える'
    assert sha(old/'検査/正式保存の最終確認.json')=='8792e1506ad256f8be9924aa53acb59ec074c55630e23e02ceca9fda139d8625'
    assert sha(old/'保管索引.json')=='eb5b029f5d91c052324e6983da925284e06c254699e64be23e2f3500bceb7b00'
    proof={'成功':True,'試行':151,'正式3MD_SHA256':{name:sha(FORMAL/name)for name in CORE},
        '固定源数':counts,'元path_SHAの組数':len(source_pairs),'全固定源を恒久実体から復元SHA一致':True,
        '条件設定F0全prefixと57行513セル同体':True,'主U70未達/対照U65主交換なし':True,
        '初回自然教師射影済みfit0判断0を成功F0と区分':True,'cache後発をF1へ遡及しない':True,
        '65モデルと4JSON69源一ZIP':True,'660金融比較15840キーはRoot別算術':True,
        '自然独立1446946末端比較':True,'CSV55004セル29646数値':True,'全ローカルリンク':len(links),
        '共有148大入力/観測/venv等の新複製':False,'旧150最終票と索引不変更':True,'新研究/再学習/次試行採番':False,'重大不足':[]}
    if args.review is None:
        target=FORMAL/'検査/正式資料の最終反映確認.json'
        write_new(target,json_bytes(proof));print(json.dumps({'成功':True,'Author票SHA256':sha(target),'リンク':len(links)},ensure_ascii=False));return
    review=args.review.resolve();review_value=json.loads(review.read_bytes());assert review_value['成功']
    root_proof=ROOT/'work/151正式数値とリンクのRoot確認.json'
    assert sha(root_proof)=='7fe370349398b05e5612cfcca97b9443b485ca86007cf899f8102ab485d31713'
    saved=[save_file(review,FORMAL/'検査/正式文書の独立確認.json',sha(review)),
        save_file(root_proof,FORMAL/'検査/正式数値とリンクのRoot確認.json',sha(root_proof))]
    sources=[Path(__file__),Path(__file__).parent/'保存部品.py',ROOT/'work/151正式数値とリンクを確認する.py',review.parent/'確認する.py']
    packed=pack_zip({path.relative_to(ROOT).as_posix():sha(path)for path in sources},FORMAL/'再現資料/151最終確認の小資料.zip')
    index.update({'段階':'正式保存完了・編集停止','最終文書検査':saved,'最終確認コード':packed,
        '正式3MD最終SHA256':proof['正式3MD_SHA256'],'未解決事項':[]})
    index_path.write_bytes(json_bytes(index))
    proof.update({'状態':'正式保存完了・編集停止','保管索引SHA256':sha(index_path),
        'Root187数値/123リンク/CSV物理/69源CRC票SHA256':sha(root_proof),'文書独立票SHA256':sha(review),
        'F0_SHA256':index['F0_SHA256'],'F1_SHA256':index['F1_SHA256'],'F2_SHA256':index['F2金融集計前']['SHA256']})
    target=FORMAL/'検査/正式保存の最終確認.json';write_new(target,json_bytes(proof))
    print(json.dumps({'成功':True,'最終票SHA256':sha(target),'保管索引SHA256':sha(index_path)},ensure_ascii=False))


if __name__=='__main__':main()
