"""作者コードと別の人工oracleで、過去窓・canonical・区画重みを確認する。"""
from pathlib import Path
from collections import Counter
from fractions import Fraction
import copy
import hashlib
import importlib.util
import unittest

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'work/過去場だけの教師選択と時間区画重み/教師選択.py'
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == '075ac230ea4ec2b7c5aa3a59fd7348941a903f9612611ef7c26ad1d5705017df'
SPEC = importlib.util.spec_from_file_location('被検査教師選択', SOURCE)
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)


def fixture(counts: list[int]) -> tuple:
    """
    機能: 二つの時間区画を持つ寄与場の人工メタデータを作る。
    引数: counts(list[int])は各場のpair数。
    返り値: tupleはrows/scene_starts。
    """
    starts = [100000 + i * 20000 for i in range(len(counts) + 2)]
    rows = []
    for session, count in enumerate(counts):
        for number in range(count):
            clock = starts[session] + (30 + number if number < count // 3 else 3700 + number)
            rows.append({'case_id': f'C/{session}/{number}', 'event_id': f'E/{session}/{number}',
                'session_index': session, 'q0_index': number, 'q0_line': number + 1,
                'q0_time': clock, 'known_at': clock + 3601, 'pair_complete': True,
                'label_buy': number % 3 - 1, 'label_sell': -(number % 3 - 1)})
    return rows, starts


class Tests(unittest.TestCase):
    """日時・索引・重みを分離して照合する。"""

    def test_独立分数重みと未来不変(self) -> None:
        """
        機能: 区画質量と左右平均1をFractionで独立計算し未来ラベル差替え不変を確認する。
        引数: self(Tests)。
        返り値: None。
        """
        rows, starts = fixture([120, 135, 150, 165, 180, 195, 210, 225, 240])
        before = copy.deepcopy(rows)
        actual = M.select_past_teachers(rows, starts, 9)
        self.assertTrue(actual['ready'])
        blocks = Counter((row['session_index'], (row['q0_time'] - starts[row['session_index']]) // 3600) for row in rows)
        self.assertEqual(actual['indices'], list(range(len(rows))))
        exact = []
        for pair in actual['pairs']:
            block = (pair['session_index'], pair['block_index'])
            expected = Fraction(len(rows), len(blocks) * blocks[block])
            exact.extend([expected, expected])
            self.assertAlmostEqual(pair['side_weight'], float(expected), places=14)
        self.assertEqual(sum(exact), len(exact))
        future = {'session_index': 9, 'label_buy': object(), 'known_at': object(), 'q0_time': object()}
        other = {'session_index': 10, 'pair_complete': object(), 'label_sell': object()}
        changed = M.select_past_teachers(rows + [future, other], starts, 9)
        self.assertEqual(actual['pairs'], changed['pairs'])
        self.assertEqual(actual['ready'], changed['ready'])
        self.assertEqual(before, rows)

    def test_20場窓と成熟等号(self) -> None:
        """
        機能: 窓外を詰めず、成熟時計が当場開始と等しい行を除く。
        引数: self(Tests)。
        返り値: None。
        """
        rows, starts = fixture([51] * 31)
        rows[30 * 51 - 1]['known_at'] = starts[30]
        expected = [i for i, row in enumerate(rows) if 10 <= row['session_index'] < 30 and row['known_at'] < starts[30]]
        actual = M.select_past_teachers(rows, starts, 30)
        self.assertEqual(actual['indices'], expected)
        self.assertEqual(actual['window']['first_session_index'], 10)
        self.assertEqual(actual['physical_pair_count'], 1019)

    def test_別区画canonicalと重複(self) -> None:
        """
        機能: 後発q0を区画重みに二重計数せず、同順位矛盾を拒否する。
        引数: self(Tests)。
        返り値: None。
        """
        rows, starts = fixture([125] * 8)
        original = M.select_past_teachers(rows, starts, 8)
        later = {**rows[0], 'q0_index': 500, 'q0_line': 501, 'event_id': 'later',
                 'q0_time': rows[0]['q0_time'] + 3600, 'known_at': rows[0]['known_at'] + 3600}
        changed = M.select_past_teachers(rows + [later, dict(rows[0])], starts, 8)
        self.assertEqual(original['pairs'], changed['pairs'])
        self.assertEqual(changed['physical_pair_count'], 1000)
        with self.assertRaises(ValueError):
            M.select_past_teachers(rows + [{**rows[0], 'label_buy': 1}], starts, 8)

    def test_下限と偽past時刻(self) -> None:
        """
        機能: 1000pair/8寄与場/三class不足は待機し、未来q0を偽pastへ混ぜない。
        引数: self(Tests)。
        返り値: None。
        """
        rows, starts = fixture([125] * 8)
        self.assertTrue(M.select_past_teachers(rows, starts, 8)['ready'])
        self.assertFalse(M.select_past_teachers(rows[:-1], starts, 8)['ready'])
        no_neutral = [{**row, 'label_buy': 1, 'label_sell': -1} for row in rows]
        self.assertFalse(M.select_past_teachers(no_neutral, starts, 8)['ready'])
        bad = {**rows[0], 'q0_time': starts[8] + 1, 'known_at': starts[8] - 1}
        with self.assertRaises(ValueError):
            M.select_past_teachers([bad] + rows[1:], starts, 8)


if __name__ == '__main__':
    unittest.main(verbosity=2)
