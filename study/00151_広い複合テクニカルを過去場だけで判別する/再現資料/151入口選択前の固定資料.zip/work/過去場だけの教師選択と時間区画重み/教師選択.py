"""未採用の純部品。過去場の成熟した物理pairだけを選び活動時間区画で重み付けする。"""
from collections import Counter
from collections.abc import Mapping, Sequence
import math
from typing import Any, TypedDict

WINDOW_SESSIONS = 20
MIN_PAIRS = 1000
MIN_CONTRIBUTING_SESSIONS = 8
LABELS = frozenset((-1, 0, 1))


class TeacherRow(TypedDict):
    """特徴やモデルを含まない、物理pair候補の宣言済みメタデータ型。"""
    case_id: str
    event_id: str
    session_index: int
    q0_index: int
    q0_line: int
    q0_time: float
    known_at: float | None
    pair_complete: bool
    label_buy: int | None
    label_sell: int | None


def _integer(value: Any) -> bool:
    """
    機能: boolを整数として扱わず整数メタデータを検査する。
    引数: value(Any)。返り値: bool。
    """
    return type(value) is int


def _finite(value: Any) -> bool:
    """
    機能: 時計とラベルの有限数値を検査する。
    引数: value(Any)。返り値: bool。
    """
    return type(value) in (int, float) and math.isfinite(value)


def _class_known(value: Any) -> bool:
    """
    機能: boolや未知を除外し、三クラスのラベル値だけを許容する。
    引数: value(Any)。返り値: bool。
    """
    return type(value) is int and value in LABELS


def select_past_teachers(rows: Sequence[Mapping[str, Any]], scene_starts: Sequence[int],
                         current_scene_index: int) -> dict[str, Any]:
    """
    機能: 現場より前の直近20暦セッションから成熟教師をcanonical化し重み付けする。
    引数: rows(Sequence[Mapping[str,Any]])はTeacherRow形式のメタデータのみ。
          scene_starts(Sequence[int])は厳密昇順の場開始、current_scene_index(int)は現在場番号。
    返り値: dict[str,Any]。indicesは元配列index、pairsは時系列順の教師メタデータと両側共通side_weight。
            readyは1000物理pair・8寄与場・買売全体の三classを全て満たす場合のみTrue。
            未達でも条件の変更やnative代用を行わず、ready_reasonsへ全未達理由を返す。
    例外: ValueErrorは時計/メタデータ不正、同caseの場不一致、同順位の原値矛盾。
    """
    if not scene_starts or any(not _integer(x) for x in scene_starts):
        raise ValueError('scene_startsは整数の非空配列が必要')
    if any(a >= b for a, b in zip(scene_starts, scene_starts[1:])):
        raise ValueError('場開始は厳密昇順が必要')
    if not _integer(current_scene_index) or not 0 <= current_scene_index < len(scene_starts):
        raise ValueError('current_scene_indexが範囲外')
    cutoff = scene_starts[current_scene_index]
    first = max(0, current_scene_index - WINDOW_SESSIONS)
    filtered = Counter()
    candidates = []
    # ----------------------------------------
    # 現在/未来・窓外を最初に除き、その行のラベルや成熟時計へ触れない。
    for original_index, row in enumerate(rows):
        if not isinstance(row, Mapping):
            raise ValueError('rowはメタデータdictが必要')
        session = row.get('session_index')
        if not _integer(session) or not 0 <= session < len(scene_starts):
            raise ValueError('session_indexが範囲外')
        if not first <= session < current_scene_index:
            filtered['outside_window'] += 1
            continue
        if row.get('pair_complete') is not True:
            filtered['pair_incomplete'] += 1
            continue
        known = row.get('known_at')
        if not _finite(known):
            filtered['known_at_unknown'] += 1
            continue
        if known >= cutoff:
            filtered['not_mature_strict'] += 1
            continue
        if not _class_known(row.get('label_buy')) or not _class_known(row.get('label_sell')):
            filtered['label_unknown_or_outside_classes'] += 1
            continue
        if not _finite(row.get('q0_time')) or row['q0_time'] > known:
            raise ValueError('成熟適格past行は有限q0_time<=known_atが必要')
        for name in ('case_id', 'event_id'):
            if not isinstance(row.get(name), str) or not row[name]:
                raise ValueError(name + 'は非空文字列が必要')
        for name in ('q0_index', 'q0_line'):
            if not _integer(row.get(name)) or row[name] < 0:
                raise ValueError(name + 'は非負整数が必要')
        candidates.append((original_index, row))
    # ----------------------------------------
    # 適格候補内だけで同caseの場と同順位原値を検査してから、最初の出生を選ぶ。
    case_sessions = {}
    same_rank = {}
    by_case = {}
    exact_duplicates = 0
    for original_index, row in candidates:
        cid = row['case_id']; session = row['session_index']
        if cid in case_sessions and case_sessions[cid] != session:
            raise ValueError('同case_idに異なるsession_index')
        case_sessions[cid] = session
        rank = (row['q0_index'], row['q0_line'], row['event_id'])
        key = (cid, rank)
        if key in same_rank:
            if dict(same_rank[key]) != dict(row):
                raise ValueError('同case_id・同順位で原値が不一致')
            exact_duplicates += 1
        else:
            same_rank[key] = row
        if cid not in by_case or rank < by_case[cid][0]:
            by_case[cid] = (rank, original_index, row)
    canonical = sorted(by_case.values(), key=lambda item: (item[2]['session_index'], *item[0]))
    pairs = []
    blocks = Counter()
    classes = set()
    sessions = set()
    for _, original_index, row in canonical:
        session = row['session_index']; clock = row.get('q0_time')
        if not _finite(clock) or clock < scene_starts[session]:
            raise ValueError('canonical q0は所属場開始以上の有限時計が必要')
        block = math.floor((clock - scene_starts[session]) / 3600)
        blocks[(session, block)] += 1
        sessions.add(session)
        classes.update((int(row['label_buy']), int(row['label_sell'])))
        pairs.append({'source_index': original_index, 'case_id': row['case_id'], 'event_id': row['event_id'],
                      'session_index': session, 'q0_index': row['q0_index'], 'q0_line': row['q0_line'],
                      'q0_time': clock, 'known_at': row['known_at'], 'pair_complete': True,
                      'label_buy': int(row['label_buy']), 'label_sell': int(row['label_sell']),
                      'block_index': block})
    count = len(pairs); active_blocks = len(blocks)
    for pair in pairs:
        block_count = blocks[(pair['session_index'], pair['block_index'])]
        pair['side_weight'] = count / (active_blocks * block_count)
    reasons = []
    if count < MIN_PAIRS: reasons.append('physical_pairs_under_1000')
    if len(sessions) < MIN_CONTRIBUTING_SESSIONS: reasons.append('contributing_sessions_under_8')
    if classes != LABELS: reasons.append('three_classes_not_present')
    return {'ready': not reasons, 'ready_reasons': reasons, 'indices': [p['source_index'] for p in pairs],
            'pairs': pairs, 'current_scene_index': current_scene_index, 'current_scene_start': cutoff,
            'window': {'first_session_index': first, 'last_session_index': current_scene_index - 1,
                       'calendar_session_count': current_scene_index - first, 'limit': WINDOW_SESSIONS},
            'maturity': {'known_at_strict_before': cutoff, 'pair_complete_required': True},
            'physical_pair_count': count, 'contributing_sessions': sorted(sessions),
            'contributing_session_count': len(sessions), 'classes': sorted(classes),
            'active_block_count': active_blocks,
            'blocks': [{'session_index': session, 'block_index': block, 'physical_pairs': n,
                        'side_weight': count / (active_blocks * n)} for (session, block), n in sorted(blocks.items())],
            'filters': dict(filtered), 'eligible_rows_before_canonical': len(candidates),
            'exact_duplicate_rows_deduplicated': exact_duplicates,
            'noncanonical_rows_removed': len(candidates) - count,
            'side_weight_mean': sum(2 * p['side_weight'] for p in pairs) / (2 * count) if count else None,
            'weight_formula': 'Npairs/(B_active*n_pairs_in_block)', 'native_fallback': False}
