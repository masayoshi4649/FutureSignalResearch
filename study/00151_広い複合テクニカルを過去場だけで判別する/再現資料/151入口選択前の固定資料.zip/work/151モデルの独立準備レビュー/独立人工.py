"""Root model151を自然学習せず、別fixtureでAPI・選択境界・再現性を確認する。"""
from pathlib import Path
from types import SimpleNamespace
from unittest import mock
import copy
import hashlib
import importlib.util
import inspect
import io
import json
import math
import tempfile
import unittest

import numpy as np
from catboost import CatBoostClassifier, Pool
import catboost

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CODE = ROOT / 'work/151過去場判別/model151.py'
SOURCE_SHA = hashlib.sha256(CODE.read_bytes()).hexdigest()
SPEC = importlib.util.spec_from_file_location('Root151の独立確認対象', CODE)
target = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(target)
CATALOG_PATH = ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json'
CATALOG_SHA = 'c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4'
COLUMNS = json.loads(CATALOG_PATH.read_bytes())
INDEX = {c['name']: i for i, c in enumerate(COLUMNS)}
EXCLUDED = {'q0_spread_points', 'q0_spread_125_ratio', 'q0_entry_minus_last_atr5_to_side'}
THRESHOLDS = {'P70': .70, 'P65': .65, 'P60': .60}
ROLE_INDICES = [INDEX['m30_ema21_delta_to_side'], INDEX['m1_volume_relative_prior3']]


def digest(path: Path) -> str:
    """
    機能: 固定コードと小型人工モデルの指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def vector(spread: float | None = 10, gap: float | None = 0) -> list:
    """
    機能: 共通条件と方向/量だけ既知の100列人工q0を作る。
    引数: spread/gap(float|None)。返り値: list[float|None]。
    """
    result = [None] * 100
    result[INDEX['q0_spread_points']] = spread
    result[INDEX['q0_last_minus_m1_close_atr5_to_side']] = gap
    for index in ROLE_INDICES: result[index] = 1.
    return result


def artificial_training() -> tuple:
    """
    機能: 自然価格を使わない正規格子で三classと非一様平均1重みを作る。
    引数: なし。返り値: tuple[np.ndarray,np.ndarray,np.ndarray]。
    """
    rows, labels = [], []
    for i in range(180):
        a = (i % 5) - 2; b = (i // 5) % 3; c = (i // 15) % 3 - 1
        x = np.full(100, np.nan)
        x[INDEX['m30_ema21_delta_to_side']] = a
        x[INDEX['m1_volume_relative_prior3']] = b
        x[INDEX['m5_rsi_delta_to_side']] = c
        x[INDEX['q0_spread_points']] = 5 + i % 3 * 5
        score = a + .6 * c + .3 * b
        rows.append(x); labels.append(0 if score < -.5 else 2 if score > .5 else 1)
    return np.array(rows), np.array(labels, dtype=np.int64), np.tile([.5, 1.5], 90)


def independent_used(exported: dict) -> list[int]:
    """
    機能: 公開JSONの内部番号を別実装の対応表で100列へ変換する。
    引数: exported(dict)。返り値: list[int]。
    """
    by_internal = {f['feature_index']: (f['flat_feature_index'], f['feature_id'])
                   for f in exported['features_info']['float_features']}
    result = set()
    for tree in exported['oblivious_trees']:
        for split in tree.get('splits') or []:
            assert split['split_type'] == 'FloatFeature'
            index, name = by_internal[split['float_feature_index']]
            assert COLUMNS[index]['name'] == name
            result.add(index)
    return sorted(result)


class Model151Tests(unittest.TestCase):
    """自然151教師・金融を開かない独立準備人工。"""

    def test_01_api_rejects_future_arguments(self) -> None:
        """
        機能: 学習/推論の引数に全期間ラベルや未来データを追加できないことを確認する。
        引数: self(Model151Tests)。返り値: None。
        """
        self.assertEqual(list(inspect.signature(target.fit_past).parameters), ['X', 'y', 'weights', 'columns', 'model_path'])
        self.assertEqual(list(inspect.signature(target.predict_both).parameters), ['model', 'buy_X', 'sell_X', 'columns'])
        x, y, w = artificial_training()
        with self.assertRaises(TypeError): target.fit_past(x, y, w, COLUMNS, Path('未作成'), future_labels=[0])
        with self.assertRaises(TypeError): target.predict_both(None, x, x, COLUMNS, labels=y)

    def test_02_bad_shapes_labels_inf_weights_before_fit(self) -> None:
        """
        機能: 100列/inf/float又はboolラベル/重み不正を実fit前に拒否する。
        引数: self(Model151Tests)。返り値: None。
        """
        x, y, w = artificial_training()
        bad_x = x.copy(); bad_x[0, 0] = np.inf
        failures = [(bad_x, y, w), (x[:, :99], y, w), (x, y.astype(float), w),
                    (x, y.astype(bool), w), (x, y, w * 2), (x, y, np.zeros(len(w))),
                    (x, y, -w), (x, y, np.full(len(w), np.nan)), (x, y[:-1], w)]
        with mock.patch.object(catboost.CatBoostClassifier, 'fit', side_effect=AssertionError('fitまで到達した')) as spy:
            for bx, by, bw in failures:
                with self.assertRaises(AssertionError): target.fit_past(bx, by, bw, COLUMNS, Path('人工未作成'))
            self.assertEqual(spy.call_count, 0)

    def test_03_real_fit_json_reload_and_array_signature(self) -> None:
        """
        機能: 人工2fitの構造/予測再現と配列署名を別算術で確認する。
        引数: self(Model151Tests)。返り値: None。
        """
        x, y, w = artificial_training(); before = (x.copy(), y.copy(), w.copy())
        names = [c['name'] for c in COLUMNS]
        # ----------------------------------------
        # 未来の人工ラベルは変更してもfitの引数へ渡さない。
        future = [0, 1, 2]
        path_a, path_b = HERE / '人工RootモデルA.json', HERE / '人工RootモデルB.json'
        first, audit_a = target.fit_past(x, y, w, COLUMNS, path_a)
        future[:] = [object(), None, '未来差替え']
        second, audit_b = target.fit_past(x, y, w, COLUMNS, path_b)
        self.assertEqual(audit_a['training_array_sha256'], audit_b['training_array_sha256'])
        self.assertEqual(audit_a['structure_sha256'], audit_b['structure_sha256'])
        buffer = bytearray(json.dumps(names, ensure_ascii=False, separators=(',', ':')).encode('utf-8'))
        for data, dtype in [(x, '<f8'), (y, '<i8'), (w, '<f8')]:
            canonical = np.array(data, dtype=dtype, order='C')
            buffer.extend(str(canonical.shape).encode('ascii')); buffer.extend(canonical.tobytes(order='C'))
        self.assertEqual(audit_a['training_array_sha256'], hashlib.sha256(buffer).hexdigest())
        self.assertEqual(first.get_params(), target.PARAMS)
        exported = json.loads(path_a.read_bytes())
        self.assertEqual(independent_used(exported), audit_a['used_indices'])
        data = Pool(x[:12], feature_names=names)
        prediction = first.predict_proba(data, thread_count=1)
        self.assertTrue(np.array_equal(prediction, second.predict_proba(data, thread_count=1)))
        restored = CatBoostClassifier(); restored.load_model(str(path_a), format='json')
        self.assertTrue(np.allclose(prediction, restored.predict_proba(data, thread_count=1), atol=1e-12, rtol=1e-12))
        buy, sell = target.predict_both(restored, x[:6], x[6:12], COLUMNS)
        self.assertTrue(np.allclose(np.array(buy + sell), prediction, atol=1e-12, rtol=1e-12))
        self.assertTrue(np.array_equal(x, before[0], equal_nan=True))
        self.assertTrue(np.array_equal(y, before[1]) and np.array_equal(w, before[2]))
        record = {'training_array_sha256': audit_a['training_array_sha256'],
                  'structure_sha256': audit_a['structure_sha256'], 'used_indices': audit_a['used_indices'],
                  'used_columns': audit_a['used_columns'], 'classes': audit_a['classes'],
                  'json_reload_max_error': float(np.max(np.abs(prediction - restored.predict_proba(data, thread_count=1))))}
        (HERE / '人工モデルの照合.json').write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    def test_04_public_json_mapping_not_direct_index(self) -> None:
        """
        機能: 内部番号とflat列番号を混同せず非数値splitを拒否する。
        引数: self(Model151Tests)。返り値: None。
        """
        index = ROLE_INDICES[0]
        exported = {'features_info': {'float_features': [{'feature_index': 7, 'flat_feature_index': index, 'feature_id': COLUMNS[index]['name']}]},
                    'oblivious_trees': [{'splits': [{'split_type': 'FloatFeature', 'float_feature_index': 7}]}]}
        self.assertEqual(target.split_indices(exported, COLUMNS), [index])
        exported['oblivious_trees'][0]['splits'][0]['split_type'] = 'OneHotFeature'
        with self.assertRaises(AssertionError): target.split_indices(exported, COLUMNS)

    def test_05_roles_known_per_q0_and_execution_excluded(self) -> None:
        """
        機能: 実splitの既知役割0/1/2と執行3列除外を確認する。
        引数: self(Model151Tests)。返り値: None。
        """
        v = [None] * 100; used = ROLE_INDICES + [INDEX[name] for name in EXCLUDED]
        for name in EXCLUDED: v[INDEX[name]] = 1.
        self.assertEqual(target.known_roles(v, COLUMNS, used), [])
        v[ROLE_INDICES[0]] = 1.
        self.assertEqual(len(target.known_roles(v, COLUMNS, used)), 1)
        v[ROLE_INDICES[1]] = math.nan
        self.assertEqual(len(target.known_roles(v, COLUMNS, used)), 1)
        v[ROLE_INDICES[1]] = 0.
        self.assertEqual(len(target.known_roles(v, COLUMNS, used)), 2)
        self.assertEqual(len(target.known_roles(v, COLUMNS, [])), 0)

    def test_06_classes_map_concatenation_cpu1(self) -> None:
        """
        機能: classes_並び替えと同一CPU1呼出し・買売順をspyで確認する。
        引数: self(Model151Tests)。返り値: None。
        """
        buy = np.zeros((1, 100)); sell = np.ones((1, 100)); calls = []
        def predict(pool, thread_count):
            """
            機能: ラベルを受け取らない人工predictの入力順を記録する。
            引数: pool(Pool)、thread_count(int)。返り値: np.ndarray。
            """
            calls.append((pool.get_features(), thread_count))
            return np.array([[.6, .3, .1], [.2, .1, .7]])
        model = SimpleNamespace(classes_=np.array([2, 0, 1]), predict_proba=predict)
        a, b = target.predict_both(model, buy, sell, COLUMNS)
        self.assertEqual(a, [[.3, .1, .6]]); self.assertEqual(b, [[.1, .7, .2]])
        self.assertEqual(len(calls), 1); self.assertEqual(calls[0][1], 1)
        self.assertTrue(np.array_equal(calls[0][0], np.concatenate((buy, sell))))
        self.assertEqual(target.predict_both(model, np.empty((0, 100)), np.empty((0, 100)), COLUMNS), ([], []))
        self.assertEqual(len(calls), 1)

    def test_07_untrained_margin_and_no_fallback(self) -> None:
        """
        機能: 未学習待機・E差.05境界と選択側不適格時の代用なしを検査する。
        引数: self(Model151Tests)。返り値: None。
        """
        v = vector()
        untrained = target.decide(v, v, None, None, COLUMNS, ROLE_INDICES, THRESHOLDS)
        self.assertEqual(untrained['reason'], 'untrained'); self.assertEqual(set(untrained['directions'].values()), {0})
        exact = target.decide(v, v, [0, .95, .05], [0, 1, 0], COLUMNS, ROLE_INDICES, THRESHOLDS)
        self.assertEqual(exact['selected_side'], 1)
        self.assertEqual(exact['reason'], 'forward_probability_under_0.40')
        low = target.decide(v, v, [0, .951, .049], [0, 1, 0], COLUMNS, ROLE_INDICES, THRESHOLDS)
        self.assertEqual(low['reason'], 'score_margin_under_0.05')
        invalid = vector(spread=0)
        result = target.decide(invalid, v, [.1, .2, .7], [.2, .2, .6], COLUMNS, ROLE_INDICES, THRESHOLDS)
        self.assertEqual(result['reason'], 'q0_common_not_met')
        self.assertEqual(set(result['directions'].values()), {0})

    def test_08_probability_thresholds_and_symmetry(self) -> None:
        """
        機能: conditional .70/.65/.60等号、pF.40等号と売買対称を確認する。
        引数: self(Model151Tests)。返り値: None。
        """
        v = vector(); other = [.4, .2, .4]
        for p, expected in [([.3, 0, .7], {'P70': 1, 'P65': 1, 'P60': 1}),
                            ([.35, 0, .65], {'P70': 0, 'P65': 1, 'P60': 1}),
                            ([.4, 0, .6], {'P70': 0, 'P65': 0, 'P60': 1})]:
            result = target.decide(v, v, p, other, COLUMNS, ROLE_INDICES, THRESHOLDS)
            self.assertEqual(result['directions'], expected)
            mirror = target.decide(v, v, other, p, COLUMNS, ROLE_INDICES, THRESHOLDS)
            self.assertEqual(mirror['directions'], {k: -s for k, s in expected.items()})
        exact = target.decide(v, v, [.1, .5, .4], [.4, .3, .3], COLUMNS, ROLE_INDICES, THRESHOLDS)
        self.assertEqual(set(exact['directions'].values()), {1})
        under = target.decide(v, v, [.1, .500001, .399999], [.4, .3, .3], COLUMNS, ROLE_INDICES, THRESHOLDS)
        self.assertEqual(under['reason'], 'forward_probability_under_0.40')

    def test_09_common_and_role_thresholds(self) -> None:
        """
        機能: spread20/±1包含と当該q0既知役割2の境界を確認する。
        引数: self(Model151Tests)。返り値: None。
        """
        p = [.1, .2, .7]; other = [.4, .2, .4]
        for spread, gap, expected in [(20, -1, True), (20, 1, True), (0, 0, False),
                                       (20.0001, 0, False), (10, -1.0001, False), (10, 1.0001, False),
                                       (None, 0, False), (10, math.nan, False)]:
            result = target.decide(vector(spread, gap), vector(), p, other, COLUMNS, ROLE_INDICES, THRESHOLDS)
            self.assertEqual(result['reason'] == 'selected', expected)
        v = vector(); v[ROLE_INDICES[1]] = None
        result = target.decide(v, vector(), p, other, COLUMNS, ROLE_INDICES, THRESHOLDS)
        self.assertEqual(result['reason'], 'known_technical_roles_under_2')
        with self.assertRaises(AssertionError): target.decide(vector(), vector(), [math.nan, 0, 1], other, COLUMNS, ROLE_INDICES, THRESHOLDS)


def main() -> None:
    """
    機能: 独立9人工と人工モデルを保存しSource前後同体を停止票へ記す。
    引数: なし。返り値: None。自然151教師/モデル/価格/150金融/Rawを読まない。
    """
    assert catboost.__version__ == '1.2.10'
    assert digest(CODE) == SOURCE_SHA and digest(CATALOG_PATH) == CATALOG_SHA
    log = io.StringIO()
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Model151Tests))
    log_path = HERE / '人工のログ.txt'; log_path.write_text(log.getvalue(), encoding='utf-8')
    assert result.wasSuccessful(), log.getvalue()
    assert digest(CODE) == SOURCE_SHA and digest(CATALOG_PATH) == CATALOG_SHA
    proof = {'成功': True, '編集停止': True, '状態': '151 Rootモデルの独立人工準備',
             '対象SourceSHA256': SOURCE_SHA, 'Source前後同体': True, '独立人工主群': result.testsRun,
             'fitAPIは過去X/y/weights/columns/pathのみ': True,
             '100列/NaN保持/inf拒否/int3class/mean1正重み/固定params': True,
             '保存JSON再load/構造予測再現/配列署名別再構成': True,
             '全split対応/当該q0finite役割2/除外3列': True,
             'classes_並替えmap/CPU1/両側同一call': True,
             'E差.05/pF.4/条件付P70_65_60/common20±1/未学習待機': True,
             '未来教師をfitへ渡す追加引数は拒否': True,
             '自然data151のprefix教師接続': '未確認。orchestrator/data151は後続の別レビュー。',
             '自然151教師/fit/モデル/価格/150金融/Raw/CSV/追加2場読取': False,
             'Source/他準備変更': False, '重大未解決': [],
             '人工ログSHA256': digest(log_path), '私有SourceSHA256': digest(Path(__file__)),
             '人工モデル照合SHA256': digest(HERE / '人工モデルの照合.json')}
    output = HERE / '確認の記録.json'
    output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '人工': result.testsRun, '対象SHA256': SOURCE_SHA,
                      '停止票SHA256': digest(output)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
