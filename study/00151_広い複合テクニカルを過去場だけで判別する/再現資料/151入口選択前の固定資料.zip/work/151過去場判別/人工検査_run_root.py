"""151の運転側における教師行対応とクラス変換を人工値で確かめる。"""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import importlib.util
import json
import unittest
import numpy as np

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('run151_root', HERE / 'run151.py')
run = importlib.util.module_from_spec(spec)
spec.loader.exec_module(run)


class 運転側の検査(unittest.TestCase):
    """自然値を使わず数値配列の境界を検査する。"""

    def test_教師行と特徴行を混同しない(self) -> None:
        """
        機能: source_indexとfeature_indexを別にし、両側のrawクラスへ1を足す。
        引数: self(運転側の検査)。返り値: None。
        """
        features = SimpleNamespace(buy_X=np.arange(600).reshape(6, 100),
            sell_X=-np.arange(600).reshape(6, 100),
            q0_meta=[{'event_id': f'e{i}', 'session_index': 0} for i in range(6)],
            scenes=[{'start': 0}, {'start': 1000}])
        teachers = SimpleNamespace(rows=[{'feature_index': 5, 'event_id': 'e5',
            'session_index': 0, 'pair_complete': True, 'known_at': 999,
            'label_buy': -1, 'label_sell': 1}, {'feature_index': 2, 'event_id': 'e2',
            'session_index': 0, 'pair_complete': True, 'known_at': 900,
            'label_buy': 0, 'label_sell': -1}])
        selected = {'ready': True, 'pairs': [{**teachers.rows[1], 'source_index': 1, 'side_weight': .5},
                                            {**teachers.rows[0], 'source_index': 0, 'side_weight': 1.5}]}
        X, y, weights, indices = run.training_arrays(features, teachers, selected, 1)
        np.testing.assert_array_equal(X, [features.buy_X[2], features.sell_X[2], features.buy_X[5], features.sell_X[5]])
        np.testing.assert_array_equal(y, [1, 0, 0, 2])
        np.testing.assert_array_equal(weights, [.5, .5, 1.5, 1.5])
        self.assertEqual(indices, [2, 5])
        teachers.rows[0]['known_at'] = 1000
        with self.assertRaises(AssertionError):
            run.training_arrays(features, teachers, selected, 1)


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(運転側の検査)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    body = {'成功': result.wasSuccessful(), '人工検査数': result.testsRun, '自然入力': False,
        '源': {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
               for name in ('run151.py', Path(__file__).name)}}
    if result.wasSuccessful():
        (HERE / '運転側Root人工の確認.json').write_text(json.dumps(body, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    raise SystemExit(0 if result.wasSuccessful() else 1)
