"""151データ投影を小sceneだけで検査し自然ラベルを開かない。"""
from pathlib import Path
import copy
import gzip
import hashlib
import json
import tempfile
import unittest

import numpy as np
import data151 as d

HERE=Path(__file__).resolve().parent


def quote(time: float,index: int) -> dict:
    """
    機能: 有限で正常BBOの人工Quoteを作る。
    引数: time(float)、index(int)。返り値: dict。
    """
    return {'clock':'人工','time':time,'index':index,'source_line':index+1,'last':1000,'bid':995,'ask':1005,'quote_ok':True}


def case(case_id: str,side: int,entry: dict,directions: tuple,statuses: tuple=('complete','complete')) -> dict:
    """
    機能: 実正逆のH60三classとendpointを持つ人工caseを作る。
    引数: case_id(str)、side(int)、entry(dict)、directions/statuses(tuple)。返り値: dict。
    """
    result={'id':case_id,'original_side':side}
    for j,name in enumerate(('original','reverse')):
        actual=side if j==0 else -side;endpoint=quote(entry['time']+3602+j*3,entry['index']+1000+j)if statuses[j]=='complete'else None;touch=quote(entry['time']+100,entry['index']+1)if directions[j]else None
        result[name]={'status':'filled','axis':'BBO','birth':{'side':actual},'entry':copy.deepcopy(entry),'entry_price':entry['ask'if actual==1 else 'bid'],'outcomes':[{'seconds':3600,'deadline':entry['time']+3600,'status':statuses[j],'touches':[{'width':125,'direction':directions[j],'quote':touch}],'endpoint':endpoint,'net5':-999999999}]}
    return result


def fixture() -> tuple:
    """
    機能: F/A/N/C・売格納再用・alias・未取得を含む2場7q0を作る。
    引数: なし。返り値: tuple。
    """
    scenes=[{'session':'場0','contract':'X','start':0,'end':10000,'force_close':9000,'entries':[]},{'session':'場1','contract':'X','start':20000,'end':30000,'force_close':29000,'entries':[]}]
    values=[case('売C1',-1,quote(1000,100),(1,-1)),case('未到達',1,quote(1100,200),(0,0)),case('片側不足',1,quote(1200,300),(1,-1),('complete','censored')),case('両側不足',1,quote(1300,400),(1,-1),('censored','censored')),case('Xなし旧case',1,quote(1500,500),(1,-1)),case('後場',1,quote(21000,100),(1,-1))]
    observed_scenes=[];descriptors=[]
    for i,scene in enumerate(scenes):
        selected=values[:5]if i==0 else values[5:]
        for c in selected:
            scene['entries'].append({'id':c['id'],'side':c['original_side'],'entry':copy.deepcopy(c['original']['entry'])});descriptors.append({'case_id':c['id'],'session':scene['session'],'contract':'X','original_side':c['original_side'],'buy_stream':'original'if c['original_side']==1 else 'reverse','sell_stream':'reverse'if c['original_side']==1 else 'original'})
        observed_scenes.append({'session':scene['session'],'success':True,'execution_end':scene['end']-300,'cases':selected})
    fixed={'expected_entry_count':6,'scenes':scenes};observed={'success':True,'trial':133,'source_entry_count':6,'scenes':observed_scenes}
    events=[('z_先',0,998,10,'売C1'),('a_後',0,999,20,'売C1'),('未',0,1098,30,'未到達'),('片',0,1198,40,'片側不足'),('両',0,1298,50,'両側不足'),('未取得',0,1400,60,None),('将来場',1,20998,10,'後場')]
    rows=[];captures=[];links=[];by_case={c['id']:c for c in values};desc={x['case_id']:x for x in descriptors}
    for i,(event,scene_index,time,index,key)in enumerate(events):
        q0=quote(time,index);buy=[float(i+1)]*100;sell=[float(-i)-.125]*100;buy[3]=None
        if key is None:buy=[None]*100;sell=[None]*100
        rows.append({'event_id':event,'session':scenes[scene_index]['session'],'contract':'X','buy':{'side':1,'x':buy},'sell':{'side':-1,'x':sell},'metadata':{'q0':q0,'future_label_must_not_be_X':999}})
        c=by_case[key]if key else None;entry=copy.deepcopy(c['original']['entry'])if c else None;descriptor=desc[key]if key else None
        cap={'event_id':event,'session':scenes[scene_index]['session'],'contract':'X','q0':q0,'status':'filled'if key else 'expired','expires':time+30,'q1':entry,'case_id':key,'buy_stream':descriptor['buy_stream']if key else None,'sell_stream':descriptor['sell_stream']if key else None};captures.append(cap)
        if key:links.append({k:cap[k]for k in ('event_id','case_id','buy_stream','sell_stream')})
    sessions=[s['session']for s in scenes];features={'success':True,'trial':148,'financial_labels_used':False,'strategy_selected':False,'selected_trade_count':None,'catalog_definition_sha256':d.CATALOG_DEFINITION_SHA256,'catalog':[{'name':f'f{i:03d}'}for i in range(100)],'sessions':sessions,'rows':rows}
    capture={'success':True,'trial':148,'financial_labels_used':False,'sessions':sessions,'rows':captures};metadata={'success':True,'trial':148,'financial_labels_used':False,'sessions':sessions,'population148':{'cases':descriptors,'event_case_links':links}}
    return features,fixed,capture,metadata,observed


def reference(path: Path,value: object) -> d.FileRef:
    """
    機能: 人工JSONをgzipにし物理/解凍指紋を分けて返す。
    引数: path(Path)、value(object)。返り値: FileRef。
    """
    body=json.dumps(value,ensure_ascii=False,allow_nan=False).encode('utf-8');path.write_bytes(gzip.compress(body,mtime=0));return d.FileRef(path,d.sha(path),hashlib.sha256(body).hexdigest())


class DataTests(unittest.TestCase):
    """自然入力なし6主群。"""

    def test_全X保持と教師canonical(self) -> None:
        """
        機能: 100列/NaN・未取得X・売格納BUY/SELL・aliasesを確認する。
        引数: self(DataTests)。返り値: None。
        """
        f,fixed,cap,meta,obs=fixture();before=copy.deepcopy((f,fixed,cap,meta,obs));features=d.feature_dataset_from_objects(f,fixed,2,7);teachers=d.teacher_dataset_from_objects(features.feature_meta(),cap,meta,fixed,obs)
        self.assertEqual(features.buy_X.shape,(7,100));self.assertEqual(features.buy_X.dtype,np.float64);self.assertTrue(np.isnan(features.buy_X[0,3]));self.assertTrue(np.isnan(features.buy_X[5]).all());self.assertNotIn('entries',features.scenes[0]);self.assertNotIn('future_label_must_not_be_X',features.q0_meta[0])
        self.assertEqual(len(teachers.rows),5);self.assertEqual(teachers.rows[0]['event_id'],'z_先');self.assertEqual(teachers.rows[0]['aliases'],['z_先','a_後']);self.assertEqual(teachers.rows[0]['feature_index'],0);self.assertEqual(teachers.event_to_teacher_index[:2].tolist(),[0,0]);self.assertEqual(teachers.event_to_teacher_index[5],-1)
        self.assertEqual(teachers.labels[0].tolist(),[-1,1]);self.assertEqual(teachers.labels[1].tolist(),[0,0]);self.assertEqual(teachers.rows[0]['known_at'],4605);self.assertEqual(teachers.counts['extra_alias_events'],1);self.assertEqual(teachers.counts['observation_cases_without_feature_capture'],1)
        self.assertEqual((f,fixed,cap,meta,obs),before)

    def test_早期touchでもH不完了は教師不可(self) -> None:
        """
        機能: 片側/両側H不足のlabelとknown_atを両方未知にする。
        引数: self(DataTests)。返り値: None。
        """
        f,fixed,cap,meta,obs=fixture();features=d.feature_dataset_from_objects(f,fixed);t=d.teacher_dataset_from_objects(features.feature_meta(),cap,meta,fixed,obs)
        for row in t.rows:
            if row['case_id']in ('片側不足','両側不足'):
                self.assertFalse(row['pair_complete']);self.assertIsNone(row['label_buy']);self.assertIsNone(row['label_sell']);self.assertIsNone(row['known_at'])
        self.assertTrue(np.isnan(t.labels[2:4]).all());self.assertTrue(np.isnan(t.known_at[2:4]).all());self.assertEqual(t.counts['one_side_complete'],1)

    def test_同物理case矛盾を拒否(self) -> None:
        """
        機能: 別IDでも同q1のclass/endpoint時刻が異なるaliasを拒否する。
        引数: self(DataTests)。返り値: None。
        """
        for kind in ('class','time'):
            with self.subTest(kind=kind):
                f,fixed,cap,meta,obs=fixture();duplicate=copy.deepcopy(obs['scenes'][0]['cases'][0]);duplicate['id']='矛盾'
                if kind=='class':duplicate['reverse']['outcomes'][0]['touches'][0]['direction']=1
                else:duplicate['reverse']['outcomes'][0]['endpoint']['time']+=1
                obs['scenes'][0]['cases'].append(duplicate);obs['source_entry_count']+=1;fixed['expected_entry_count']+=1;fixed['scenes'][0]['entries'].append({'id':'矛盾','side':-1,'entry':copy.deepcopy(duplicate['original']['entry'])});descriptor=copy.deepcopy(meta['population148']['cases'][0]);descriptor['case_id']='矛盾';meta['population148']['cases'].append(descriptor);cap['rows'][1]['case_id']='矛盾';meta['population148']['event_case_links'][1]['case_id']='矛盾';features=d.feature_dataset_from_objects(f,fixed)
                with self.assertRaises(AssertionError):d.teacher_dataset_from_objects(features.feature_meta(),cap,meta,fixed,obs)

    def test_誤った買売streamとscopeを拒否(self) -> None:
        """
        機能: C1売格納のBUY=original誤束縛又は別場aliasを拒否する。
        引数: self(DataTests)。返り値: None。
        """
        for key,value in [('buy_stream','original'),('session','場1')]:
            f,fixed,cap,meta,obs=fixture();features=d.feature_dataset_from_objects(f,fixed);cap['rows'][1][key]=value
            with self.assertRaises(AssertionError):d.teacher_dataset_from_objects(features.feature_meta(),cap,meta,fixed,obs)

    def test_gzip指紋とwork限定cache(self) -> None:
        """
        機能: 小gzipだけで物理解凍SHA/CRCと分離npzを検査する。
        引数: self(DataTests)。返り値: None。
        """
        with tempfile.TemporaryDirectory(prefix='人工_',dir=HERE)as folder:
            root=Path(folder);f,fixed,cap,meta,obs=fixture();fr=reference(root/'features.gz',f);fixed_ref=reference(root/'fixed.gz',fixed);meta['fixed_input_sha256']=fixed_ref.decoded_sha256;obs['input_sha256']=fixed_ref.decoded_sha256
            features=d.load_feature_dataset(fr,fixed_ref,2,7);teachers=d.project_teacher(features.feature_meta(),reference(root/'capture.gz',cap),reference(root/'meta.gz',meta),fixed_ref,reference(root/'obs.gz',obs));assert fr.sha256!=fr.decoded_sha256
            feature_cache=d.save_feature_cache(features,root/'特徴');teacher_cache=d.save_teacher_cache(teachers,root/'教師')
            with np.load(feature_cache['npz'],allow_pickle=False)as source:self.assertEqual(set(source.files),{'buy_X','sell_X','columns'});self.assertTrue(np.isnan(source['buy_X'][0,3]))
            with np.load(teacher_cache['npz'],allow_pickle=False)as source:self.assertEqual(source['side_order'].tolist(),[1,-1]);self.assertTrue(np.isnan(source['labels'][2]).all())
            with self.assertRaises(AssertionError):d.read_ref(d.FileRef(fr.path,fr.sha256,'0'*64))
            path=Path(fr.path);damaged=bytearray(path.read_bytes());damaged[-8]^=1;path.write_bytes(damaged)
            with self.assertRaises((OSError,EOFError)):d.read_ref(d.FileRef(path,d.sha(path),fr.decoded_sha256))
        with tempfile.TemporaryDirectory()as outside:
            with self.assertRaises(AssertionError):d.save_feature_cache(features,Path(outside)/'不可')

    def test_教師入力を特徴APIへ渡さない(self) -> None:
        """
        機能: monetary/label変更は全q0の特徴配列や場時計へ影響しない。
        引数: self(DataTests)。返り値: None。
        """
        f,fixed,cap,meta,obs=fixture();a=d.feature_dataset_from_objects(f,fixed);obs['scenes'][0]['cases'][0]['reverse']['outcomes'][0]['touches'][0]['direction']=1;cap['rows'][0]['status']='expired';fixed['scenes'][0]['entries'][0]['side']=1;fixed['scenes'][0]['entries'][0]['entry']['ask']=999999;b=d.feature_dataset_from_objects(f,fixed)
        np.testing.assert_equal(a.buy_X,b.buy_X);np.testing.assert_equal(a.sell_X,b.sell_X);self.assertEqual(a.q0_meta,b.q0_meta);self.assertEqual(a.scenes,b.scenes)


if __name__=='__main__':
    unittest.main(verbosity=2)
