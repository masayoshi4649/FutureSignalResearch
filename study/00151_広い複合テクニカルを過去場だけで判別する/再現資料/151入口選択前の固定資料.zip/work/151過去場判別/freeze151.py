"""151の自然実行前後を、相対パスの指紋と事前文書で記録する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
STUDY = ROOT / 'study/00151_広い複合テクニカルを過去場だけで判別する'
BOOK = ROOT / 'inputs/00151_過去場だけの複合判別/条件.json'


def sha(path: Path) -> str:
    """
    機能: ファイルの物理指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: 既存を上書きせずUTF8の確認票を保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as source:
        json.dump(value, source, ensure_ascii=False, indent=2, allow_nan=False)
        source.write('\n')


# ----------------------------------------
def main() -> None:
    """
    機能: F0で源と3文書を固定し、F1で同体と全選択資料を確認する。
    引数: CLI stage(str)、output-dir(Path)。返り値: None。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--stage', choices=('F0', 'F1'), required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    refs = set()
    previous = None
    if args.stage == 'F0':
        book = json.loads(BOOK.read_bytes())
        refs.update(ROOT / item['path'] for item in book['inputs'].values())
        refs.update((BOOK, ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json',
            ROOT / 'scripts/入口研究/固定特徴から可読条件を選択する.py',
            ROOT / 'work/過去場だけの教師選択と時間区画重み/教師選択.py'))
        for folder in (HERE, ROOT / 'work/151教師選択のRoot独立検査',
                       ROOT / 'work/151モデルの独立準備レビュー',
                       ROOT / 'work/151運転の独立準備レビュー'):
            assert folder.exists(), str(folder)
            refs.update(p for p in folder.iterdir() if p.is_file())
        for name in ('README.md', '条件.md', '設定と結果.md'):
            path = STUDY / name
            target = args.output_dir / 'F0実行前文書' / name
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open('xb') as sink:
                sink.write(path.read_bytes())
            refs.add(path)
    else:
        f0 = args.output_dir / 'F0入口選択前.json'
        previous = sha(f0)
        before = json.loads(f0.read_bytes())
        for path, expected in before['ファイル'].items():
            assert sha(ROOT / path) == expected, path
        refs.update(ROOT / path for path in before['ファイル'])
        refs.add(f0)
        selection = args.output_dir / '入口選択'
        for path in selection.rglob('*'):
            if path.is_file() and 'cache' not in path.relative_to(selection).parts:
                refs.add(path)
        check = json.loads((selection / '選択の確認.json').read_bytes())
        assert check['成功'] and check['book_sha256'] == sha(BOOK)
    files = {path.relative_to(ROOT).as_posix(): sha(path) for path in sorted(refs)}
    result = {'成功': True, '試行': 151, '段階': args.stage,
        'UTC': datetime.now(timezone.utc).isoformat(), '前段階SHA256': previous,
        '主政策': 'U70', '全73場は既使用': True, '追加2場価格未読': True,
        '教師射影器は全保存観測を読む': True, '学習へ当場又は将来教師を渡す': False,
        'ファイル': files}
    name = 'F0入口選択前.json' if args.stage == 'F0' else 'F1入口選択後.json'
    target = args.output_dir / name
    save(target, result)
    print(json.dumps({'成功': True, '段階': args.stage, '指紋数': len(files),
        'path': str(target), 'sha256': sha(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
