"""151データ部品だけを人工検査し自然未読の準備票を保存する。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

import numpy as np

HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: データ部品の物理bytesを指紋化する。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: UTF-8 strictの小fixture検査と源前後一致でデータ部品を停止する。
    引数: なし。返り値: None。
    """
    paths=[HERE/name for name in ('data151.py','test_data151.py','README_データ部品.md','prepare_data151.py')];before={p.name:sha(p)for p in paths}
    for path in paths:
        if path.suffix=='.py':
            tree=ast.parse(path.read_text(encoding='utf-8'))
            for node in ast.walk(tree):
                if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                    text=ast.get_docstring(node);assert text and '\n'in text and all(word in text for word in ('機能','引数','返り値')),(path.name,node.name)
    command=[sys.executable,'-X','utf8',str(HERE/'test_data151.py')];process=subprocess.run(command,capture_output=True,cwd=HERE,env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'});stdout=process.stdout.decode('utf-8','strict');stderr=process.stderr.decode('utf-8','strict');assert process.returncode==0 and '\ufffd'not in stdout+stderr
    assert before=={p.name:sha(p)for p in paths}
    proof={'成功':True,'試行':151,'範囲':'data151のみ。モデル/selector作者源は対象外。','自然共有148特徴又は133観測の読取':False,'自然学習':False,'旧Source変更':False,'追加2場':False,'人工主検査数':6,'構文と関数コメント':True,'UTF8_strict':True,'python':sys.version,'numpy':np.__version__,'実行':{'引数':command,'終了値':process.returncode,'標準出力':stdout,'標準エラー':stderr},'源':[{'name':p.name,'bytes':p.stat().st_size,'sha256':before[p.name]}for p in paths],'全源前後一致':True,'teacher_labels':'raw BUY/SELL -1/0/1。pair不完了は両None/NaN。model用+1は運転側。','自然実行':'RootのF0後通知待ち'}
    target=HERE/'データ準備の確認.json'
    with target.open('x',encoding='utf-8')as output:json.dump(proof,output,ensure_ascii=False,indent=2,allow_nan=False);output.write('\n')
    stop={'成功':True,'編集停止':True,'自然入力未読':True,'準備票SHA256':sha(target),'源':before}
    with (HERE/'データ部品の停止.json').open('x',encoding='utf-8')as output:json.dump(stop,output,ensure_ascii=False,indent=2);output.write('\n')
    print(json.dumps({'成功':True,'準備SHA256':sha(target),'停止SHA256':sha(HERE/'データ部品の停止.json'),'data151_SHA256':before['data151.py']},ensure_ascii=False))


if __name__=='__main__':
    main()
