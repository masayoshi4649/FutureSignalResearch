"""151の過去数値配列だけの学習と、現在特徴だけの売買対称な予測。"""
from pathlib import Path
import hashlib
import json
import math

PARAMS = {'iterations': 128, 'depth': 3, 'learning_rate': .05, 'l2_leaf_reg': 10,
    'loss_function': 'MultiClass', 'classes_count': 3, 'random_seed': 151,
    'boosting_type': 'Plain', 'bootstrap_type': 'No', 'random_strength': 0,
    'has_time': True, 'nan_mode': 'Min', 'use_best_model': False,
    'allow_writing_files': False, 'verbose': False, 'task_type': 'CPU', 'thread_count': 1}
EXCLUDED_ROLE_COLUMNS = frozenset(('q0_spread_points', 'q0_spread_125_ratio',
                                  'q0_entry_minus_last_atr5_to_side'))


def split_indices(exported: dict, columns: list[dict]) -> list[int]:
    """
    機能: 保存対称木の実分岐を元の100列へ写す。
    引数: exported(dict)は公開モデルJSON、columns(list[dict])は列名/役割。
    返り値: list[int]は実際に使った元列番号。重要度による代用ではない。
    """
    names = [column['name'] for column in columns]
    floats = {field['feature_index']: field for field in exported['features_info']['float_features']}
    used = set()
    assert len(names) == len(set(names)) == 100
    for tree in exported['oblivious_trees']:
        for split in tree.get('splits') or []:
            assert split['split_type'] == 'FloatFeature'
            field = floats[split['float_feature_index']]
            index = field['flat_feature_index']
            assert 0 <= index < len(names) and field['feature_id'] == names[index]
            used.add(index)
    return sorted(used)


# ----------------------------------------
def known_roles(vector: list, columns: list[dict], indices: list[int]) -> list[str]:
    """
    機能: 当該q0で既知の実分岐列から、執行3列を除いた技術役割を数える。
    引数: vector(list)は一方向100特徴、columns(list[dict])、indices(list[int])。
    返り値: list[str]は6分類内の既知役割集合。NaNを根拠に数えない。
    """
    assert len(vector) == len(columns) == 100
    result = set()
    for index in indices:
        value = vector[index]
        if columns[index]['name'] not in EXCLUDED_ROLE_COLUMNS and value is not None and math.isfinite(float(value)):
            result.add(columns[index]['role'])
    return sorted(result)


# ----------------------------------------
def fit_past(X: object, y: object, weights: object, columns: list[dict], model_path: Path) -> tuple:
    """
    機能: 呼出側が過去だけへ限定した数値配列で固定CPUモデルを学ぶ。
    引数: X(object)は[N,100]、y(object)は0=A/1=N/2=F、weights(object)は平均1正重み。
          columns(list[dict])、model_path(Path)は未作成JSON先。
    返り値: tuple[object,dict]はモデルと配列/構造/分岐の指紋。全期間ラベル引数は持たない。
    """
    import numpy as np
    import catboost
    from catboost import CatBoostClassifier, Pool
    assert catboost.__version__ == '1.2.10'
    matrix = np.ascontiguousarray(X, dtype='<f8')
    raw_labels = np.asarray(y)
    raw_mass = np.asarray(weights)
    assert raw_labels.ndim == raw_mass.ndim == 1 and raw_labels.dtype.kind in ('i', 'u')
    assert raw_mass.dtype.kind in ('i', 'u', 'f')
    labels = np.ascontiguousarray(raw_labels, dtype='<i8')
    mass = np.ascontiguousarray(raw_mass, dtype='<f8')
    assert matrix.ndim == 2 and matrix.shape[1] == len(columns) == 100
    assert len(matrix) == len(labels) == len(mass) and len(matrix) > 0
    assert not np.isinf(matrix).any() and set(labels.tolist()) == {0, 1, 2}
    assert np.isfinite(mass).all() and (mass > 0).all() and math.isclose(float(mass.mean()), 1, rel_tol=1e-12)
    names = [column['name'] for column in columns]
    signature = hashlib.sha256()
    signature.update(json.dumps(names, ensure_ascii=False, separators=(',', ':')).encode('utf-8'))
    for array in (matrix, labels, mass):
        signature.update(str(array.shape).encode('ascii'))
        signature.update(array.tobytes())
    pool = Pool(matrix, label=labels, weight=mass, feature_names=names)
    model = CatBoostClassifier(**PARAMS)
    model.fit(pool)
    assert list(model.classes_) == [0, 1, 2]
    assert not model_path.exists()
    model_path.parent.mkdir(parents=True, exist_ok=True)
    model.save_model(str(model_path), format='json')
    body = model_path.read_bytes()
    exported = json.loads(body)
    indices = split_indices(exported, columns)
    stable = {name: exported[name] for name in ('features_info', 'oblivious_trees', 'scale_and_bias')}
    return model, {'status': 'trained', 'model_file': model_path.name,
        'physical_sha256': hashlib.sha256(body).hexdigest(),
        'structure_sha256': hashlib.sha256(json.dumps(stable, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
        'training_array_sha256': signature.hexdigest(), 'used_indices': indices,
        'used_columns': [names[index] for index in indices], 'classes': list(map(int, model.classes_)),
        'parameters': dict(PARAMS), 'catboost': catboost.__version__}


# ----------------------------------------
def predict_both(model: object, buy_X: object, sell_X: object, columns: list[dict]) -> tuple[list, list]:
    """
    機能: 同じモデル/関数で両方向を予測し、classes_を通じてA/N/Fへ写す。
    引数: model(object)、buy_X/sell_X(object)は同数の100列、columns(list[dict])。
    返り値: tuple[list,list]は買売各行の[P(A),P(N),P(F)]。ラベルは受け取らない。
    """
    import numpy as np
    from catboost import Pool
    buy = np.asarray(buy_X, dtype=np.float64)
    sell = np.asarray(sell_X, dtype=np.float64)
    assert buy.shape == sell.shape and buy.ndim == 2 and buy.shape[1] == 100
    if not len(buy):
        return [], []
    assert not np.isinf(buy).any() and not np.isinf(sell).any()
    classes = list(map(int, model.classes_))
    assert sorted(classes) == [0, 1, 2]
    positions = [classes.index(value) for value in (0, 1, 2)]
    pool = Pool(np.concatenate((buy, sell)), feature_names=[column['name'] for column in columns])
    values = np.asarray(model.predict_proba(pool, thread_count=1))[:, positions].tolist()
    return values[:len(buy)], values[len(buy):]


# ----------------------------------------
def decide(buy: list, sell: list, buy_p: list | None, sell_p: list | None,
           columns: list[dict], used_indices: list[int], thresholds: dict[str, float]) -> dict:
    """
    機能: 当時確率の差・共通品質・複数役割から、固定閾値別に待機又は方向を選ぶ。
    引数: buy/sell(list)、buy_p/sell_p(list|None)、columns(list[dict])、used_indices(list[int])、thresholds(dict)。
    返り値: dictは確率/役割/理由と方向。取得成否・q1・当場ラベルは受け取らない。
    """
    result = {'directions': {name: 0 for name in thresholds}, 'probabilities': None,
              'scores': None, 'selected_side': 0, 'known_roles': [], 'reason': 'untrained'}
    if buy_p is None or sell_p is None:
        assert buy_p is None and sell_p is None
        return result
    for probability in (buy_p, sell_p):
        assert len(probability) == 3 and all(math.isfinite(float(value)) and 0 <= value <= 1 for value in probability)
        assert math.isclose(sum(probability), 1, abs_tol=1e-9)
    a, b = buy_p[2] - buy_p[0], sell_p[2] - sell_p[0]
    result.update(probabilities={'buy': list(buy_p), 'sell': list(sell_p)}, scores={'buy': a, 'sell': b})
    if a - b >= .05:
        side, vector, probability = 1, buy, buy_p
    elif b - a >= .05:
        side, vector, probability = -1, sell, sell_p
    else:
        result['reason'] = 'score_margin_under_0.05'
        return result
    result['selected_side'] = side
    index = {column['name']: i for i, column in enumerate(columns)}
    spread = vector[index['q0_spread_points']]
    gap = vector[index['q0_last_minus_m1_close_atr5_to_side']]
    if spread is None or gap is None or not math.isfinite(float(spread)) or not math.isfinite(float(gap)) or not (0 < spread <= 20 and -1 <= gap <= 1):
        result['reason'] = 'q0_common_not_met'
        return result
    roles = known_roles(vector, columns, used_indices)
    result['known_roles'] = roles
    if len(roles) < 2:
        result['reason'] = 'known_technical_roles_under_2'
        return result
    denominator = probability[2] + probability[0]
    conditional = probability[2] / denominator if denominator > 0 else None
    result['conditional_forward'] = conditional
    if probability[2] < .4:
        result['reason'] = 'forward_probability_under_0.40'
        return result
    result['reason'] = 'threshold_wait'
    for name, threshold in thresholds.items():
        if conditional is not None and conditional >= threshold:
            result['directions'][name] = side
            result['reason'] = 'selected'
    return result
