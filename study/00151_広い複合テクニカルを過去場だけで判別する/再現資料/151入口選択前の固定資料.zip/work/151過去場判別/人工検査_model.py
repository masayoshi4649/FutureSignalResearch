"""モデルと無関係な確率人工で、151の方向/未知/役割/閾値を確認する。"""
from pathlib import Path
import importlib.util
import unittest
import math

SPEC = importlib.util.spec_from_file_location('model151', Path(__file__).with_name('model151.py'))
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)


def fixture() -> tuple:
    """
    機能: 執行列と2技術役割を区別した100列人工を作る。
    引数: なし。
    返り値: tupleはcolumns/vector。
    """
    columns = [{'name': 'f' + str(i), 'role': '構造'} for i in range(100)]
    columns[0] = {'name': 'q0_spread_points', 'role': '値幅'}
    columns[1] = {'name': 'q0_last_minus_m1_close_atr5_to_side', 'role': '構造'}
    columns[2] = {'name': 'q0_entry_minus_last_atr5_to_side', 'role': '構造'}
    columns[4] = {'name': 'quantity', 'role': '量'}
    vector = [1.] * 100
    vector[0], vector[1] = 10., .2
    return columns, vector


class Tests(unittest.TestCase):
    """q0情報だけの対称な確率選択を確認する。"""

    def test_鏡像と固定閾値(self) -> None:
        """
        機能: 同じ条件で方向を選び、下位閾値の通過が主を交換しないことを確認する。
        引数: self(Tests)。
        返り値: None。
        """
        c, x = fixture()
        thresholds = {'P70': .7, 'P65': .65, 'P60': .6}
        a, b = [.15, .2, .65], [.5, .25, .25]
        self.assertEqual(M.decide(x, x, a, b, c, [3, 4], thresholds)['directions'], dict.fromkeys(thresholds, 1))
        self.assertEqual(M.decide(x, x, b, a, c, [3, 4], thresholds)['directions'], dict.fromkeys(thresholds, -1))
        lower = M.decide(x, x, [.22, .34, .44], b, c, [3, 4], thresholds)
        self.assertEqual(lower['directions'], {'P70': 0, 'P65': 1, 'P60': 1})

    def test_未知と執行列は役割に数えない(self) -> None:
        """
        機能: 不足role、NaN、共通品質不成立で発注しないことを確認する。
        引数: self(Tests)。
        返り値: None。
        """
        c, x = fixture()
        a, b = [.15, .2, .65], [.5, .25, .25]
        x[4] = math.nan
        result = M.decide(x, x, a, b, c, [0, 2, 3, 4], {'P70': .7})
        self.assertEqual(result['reason'], 'known_technical_roles_under_2')
        self.assertEqual(result['directions']['P70'], 0)
        x[4], x[0] = 1., 30.
        self.assertEqual(M.decide(x, x, a, b, c, [3, 4], {'P70': .7})['reason'], 'q0_common_not_met')

    def test_未学習と同点と低い順行確率(self) -> None:
        """
        機能: 未学習をnative代用せず、方向差と到達可能性の条件を守る。
        引数: self(Tests)。
        返り値: None。
        """
        c, x = fixture()
        self.assertEqual(M.decide(x, x, None, None, c, [], {'P70': .7})['reason'], 'untrained')
        p = [.1, .4, .5]
        self.assertEqual(M.decide(x, x, p, p, c, [3, 4], {'P70': .7})['directions']['P70'], 0)
        result = M.decide(x, x, [.05, .60, .35], [.5, .4, .1], c, [3, 4], {'P70': .7})
        self.assertEqual(result['reason'], 'forward_probability_under_0.40')

    def test_内部列番号と元列番号(self) -> None:
        """
        機能: 内部float indexを元100列へ正しく解決する。
        引数: self(Tests)。
        返り値: None。
        """
        c, _ = fixture()
        model = {'features_info': {'float_features': [
            {'feature_index': 0, 'flat_feature_index': 3, 'feature_id': 'f3'},
            {'feature_index': 1, 'flat_feature_index': 4, 'feature_id': 'quantity'}]},
            'oblivious_trees': [{'splits': [{'split_type': 'FloatFeature', 'float_feature_index': 1}]}]}
        self.assertEqual(M.split_indices(model, c), [4])


if __name__ == '__main__':
    unittest.main(verbosity=2)
