# 151 データ部品の契約

2026-11-12。担当は`data151.py`と`test_data151.py`。Root/別担当の学習器・予測器・純teacher selectorとは分離する。自然共有入力の読取・自然cache作成・学習はRootのF0後通知まで実行しない。旧148–150源、Raw、追加2場は変更/読取しない。

## 特徴専用

`FileRef(path, sha256, decoded_sha256)`は物理SHAと全解凍SHAを別に持つ。gzipを全読してCRC・物理/解凍SHA・前後statを検査し、巨大解凍副本は書かない。

`load_feature_dataset(features_ref, fixed_ref, expected_sessions=73, expected_rows=35339) -> FeatureDataset`

- `columns`: 辞書順の100名tuple。
- `buy_X`, `sell_X`: float64のN×100。元nullはNaN、既知0は0を保持。買売は保存配列をそれぞれ読み、符号flipで代用しない。
- `q0_meta`: 全Nのflat辞書。event_id/session/contract/session_index/q0_time/q0_index/q0_line。q1・ラベル・C1flag・成績を入れない。未取得や全NaN行も落とさない。
- `scenes`: 固定入力原文のsession/contract/start/end/force_closeだけをcopy。fixedに含まれるentries未来取得表を返さず、Xへも入れない。
- `sources`: 指紋/由来のmetadata。

capture/観測/教師はこの関数の引数にない。`features.feature_meta() -> FeatureMetadata`はXを除く識別/時計だけのcopyを返す。

## 教師専用

`project_teacher(feature_meta, captures_ref, metadata_ref, fixed_ref, observations_ref) -> TeacherDataset`

純投影は`teacher_dataset_from_objects(FeatureMetadata, captures, metadata, fixed, observations)`。自然I/Oを人工から切り離す。特徴行列そのものは受け取らない。買/売はcapture.buy_stream/sell_streamを正本にし、metadata/実birth.sideとの一致を確認。旧C1売格納の場合はBUY=reverse、SELL=originalとなる。

`TeacherDataset.rows`（`canonical_rows`は同じ配列）は純teacher selectorへそのまま渡すlist。最低keysは次のとおり。

```json
{
  "case_id":"人工case",
  "event_id":"最初q0",
  "session_index":0,
  "q0_index":10,
  "q0_line":11,
  "q0_time":998,
  "known_at":4605,
  "pair_complete":true,
  "label_buy":-1,
  "label_sell":1,
  "feature_index":0,
  "aliases":["最初q0","別q0"],
  "alias_feature_indices":[0,1]
}
```

labelは**raw −1/0/+1=A/N/F**。CatBoost等の0/1/2変換はmodel/運転側で行い、この部品では+1しない。

両BBOのH60がcompleteでなければ、pair_complete=false、両label/known_atはNone。教師配列ではNaN。早期touchが既知でもH60 endpointまで成熟を前倒ししない。両endpoint>=各deadline・ザラバ内を検査し、`known_at=max(BUYendpoint.time,SELLendpoint.time)`。IFD/金額/MFE等は教師へ射影しない。

物理単位は(session,contract,q1 time/index/line)。同q1 aliasesの全q0Xを残し、最初のq0 index→line→event IDを教師canonicalにする。同物理のentry/買売label/完了/endpoint知得時計が矛盾すれば拒否する。観測にあるがfeature captureにない旧caseは教師へ加えず件数を記録する。

教師配列は次のとおり。

- `labels[M,2]`: 列順BUY/SELL、float64。両完了以外は両NaN。
- `pair_complete[M]`, `known_at[M]`: boolとfloat64 NaN。
- `canonical_feature_index[M]`: rows.source_indexから特徴へ写すindex。
- `event_to_teacher_index[N]`: filled aliasは同じM index、未取得は−1。
- `counts`: 片側だけ完了、alias追加、未取得X、featureにない観測case等。

この部品は過去20場・strict成熟・最低1000pair・8寄与場・時間区画の選択/重みを行わない。純selectorがrowsの配列indexをsource_indexとして返し、`rows[source_index].feature_index`でXへ写す。モデルの現在場判断へ全教師を渡すAPIではなく、特徴と教師を物理ファイルでも分離する。

## work cache

`save_feature_cache(features, output_dir)`はfeatures.npz（buy_X/sell_X/columns）とfeatures_meta.jsonだけ。`save_teacher_cache(teachers, output_dir)`は別dirへteachers.npz/teachers_meta.json。教師cacheにXを入れず、特徴cacheに教師を入れない。npzはobject配列/ピクルを使わず、`np.load(...,allow_pickle=False)`で読める。保存先はwork配下・未作成dirのみ、恒久inputsへ100列を複写しない。

cacheは再生成可能な作業物。npz ZIP時刻等のbytes同体と数値同体は別であり、実行時のartifact SHAをRootが固定する。

## 人工と責任境界

指定venvのPythonで`test_data151.py`を実行する。2scene/7q0/6観測caseの人工のみで、F/A/N/C、旧C1売格納、同q1 alias、未取得全NaN行、片側H不足、endpoint最大、矛盾拒否、入力非改変、gzipCRC/decodedSHA、work限定の別cacheを確認する。

この部品の作者は学習器/純selectorの独立検算役ではない。Root/別担当がlabel raw値→model class変換、過去場限定、strict成熟、重みを独立確認する。自然データはF0後のRoot通知まで開かない。
