"""151運転を人工Feature/Teacherとspyモデルで確認する。自然入力は開かない。"""
from pathlib import Path
from types import SimpleNamespace
from unittest import mock
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import sys
import tempfile
import unittest

import numpy as np
import catboost

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CODE = ROOT / 'work/151過去場判別/run151.py'
SOURCE_SHA = hashlib.sha256(CODE.read_bytes()).hexdigest()


def load_module(path: Path, name: str):
    """
    機能: dataclassを登録してmain未実行の確認対象だけを読み込む。
    引数: path(Path)、name(str)。返り値: object。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec); sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


run = load_module(CODE, '独立対象運転151')
data = load_module(CODE.parent / 'data151.py', '人工用型151')
model = load_module(CODE.parent / 'model151.py', '独立対象推論151')
teacher_path = ROOT / 'work/過去場だけの教師選択と時間区画重み/教師選択.py'
teacher = load_module(teacher_path, '既準備teacher151')
helper = load_module(ROOT / 'scripts/入口研究/固定特徴から可読条件を選択する.py', '既確認link151')
CATALOG = ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json'
COLUMNS = json.loads(CATALOG.read_bytes()); INDEX = {c['name']: i for i, c in enumerate(COLUMNS)}
USED = [INDEX['m30_ema21_delta_to_side'], INDEX['m1_volume_relative_prior3']]


def digest(path: Path) -> str:
    """
    機能: 固定小型Source/人工出力のSHAを計算する。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def book() -> dict:
    """
    機能: validate_book用に価格を含まない固定契約を人工生成する。
    引数: なし。返り値: dict。
    """
    return {'trial': 151, 'session_count': 73, 'feature_rows': 35339, 'legacy_count': 87, 'catalog_count': 100,
            'catalog_definition_sha256': digest(CATALOG),
            'runtime': {'python': '.'.join(map(str, sys.version_info[:3])), 'numpy': np.__version__, 'catboost': catboost.__version__},
            'classifier_parameters': dict(model.PARAMS),
            'training': {'window_sessions': 20, 'minimum_physical_pairs': 1000, 'minimum_contributing_sessions': 8,
                         'minimum_classes': [-1, 0, 1], 'label_to_class': {'-1': 0, '0': 1, '1': 2}},
            'selection': {'thresholds': {'P70': .7, 'P65': .65, 'P60': .6}, 'minimum_score_margin': .05,
                          'minimum_forward_probability': .4, 'minimum_known_roles': 2,
                          'role_excluded_columns': sorted(model.EXCLUDED_ROLE_COLUMNS), 'q1_for_prediction': False},
            'linking': {'primary_new': 'P70', 'primary_union': 'U70', 'sensitivity_unions': {'U65': 'P65', 'U60': 'P60'},
                        'legacy': 'C1', 'same_q1': '旧C1優先、C1外は最初q0、後発aliasは重複計数しない'}}


def artificial_datasets() -> tuple:
    """
    機能: 10場125pair/場の人工FeatureDataset/TeacherDatasetを作る。
    引数: なし。返り値: tuple。自然価格やラベルを参照しない。
    """
    scenes, metadata, rows = [], [], []
    x = np.full((1250, 100), np.nan)
    for sid in range(10):
        start = 100000 + sid * 30000
        scenes.append({'session': f'人工{sid:02d}_Day', 'contract': '人工限月', 'start': start, 'end': start + 20000, 'force_close': start + 19900})
        for local in range(125):
            idx = sid * 125 + local
            event = f'人工/{sid}/{local}'
            q0 = {'event_id': event, 'session': scenes[-1]['session'], 'contract': '人工限月', 'session_index': sid,
                  'q0_index': local + 1, 'q0_line': local + 101, 'q0_time': start + local * 60}
            metadata.append(q0)
            rows.append({'case_id': f'case{idx}', **q0, 'feature_index': idx, 'known_at': start + 9000,
                         'pair_complete': True, 'label_buy': (-1, 0, 1)[local % 3], 'label_sell': (1, 0, -1)[local % 3]})
            x[idx, INDEX['m15_adx']] = sid
            x[idx, INDEX['q0_spread_points']] = 10
            x[idx, INDEX['q0_last_minus_m1_close_atr5_to_side']] = 0
            x[idx, USED] = 1
    features = data.FeatureDataset(tuple(c['name'] for c in COLUMNS), x.copy(), x.copy(), metadata, scenes)
    teachers = SimpleNamespace(rows=rows, counts={'人工pair': len(rows)})
    return features, teachers


class SpyModel:
    """学習に渡る配列だけを記録する人工モデル。自然fitは行わない。"""
    PARAMS = model.PARAMS

    def __init__(self):
        """
        機能: 記録配列を初期化する。
        引数: self(SpyModel)。返り値: None。
        """
        self.calls = []

    def fit_past(self, x, y, weights, columns, path):
        """
        機能: 過去場だけが数値配列へ入ったかを記録・確認する。
        引数: x/y/weights(np.ndarray)、columns(list)、path(Path)。返り値: tuple。
        """
        current = int(path.stem)
        assert np.max(x[:, INDEX['m15_adx']]) < current
        assert x.shape == (len(y), 100) and set(y.tolist()) == {0, 1, 2}
        assert np.all(weights > 0) and np.isclose(weights.mean(), 1)
        signature = hashlib.sha256(x.tobytes() + y.tobytes() + weights.tobytes()).hexdigest()
        self.calls.append({'current': current, 'signature': signature, 'X': x.copy(), 'y': y.copy(), 'weights': weights.copy()})
        return float(y.mean()), {'used_indices': USED, 'training_array_sha256': signature, 'artificial': True}

    def predict_both(self, trained, buy, sell, columns):
        """
        機能: 人工学習ラベル平均にだけ依存する両側確率を返す。
        引数: trained(float)、buy/sell(np.ndarray)、columns(list)。返り値: tuple[list,list]。
        """
        p = .60 + trained * .05
        return [[.1, .9 - p, p] for _ in buy], [[.4, .2, .4] for _ in sell]

    decide = staticmethod(model.decide)


class Run151Tests(unittest.TestCase):
    """運転の因果境界・連結契約を独立人工で確認する。"""

    def test_01_training_labels_weights_and_interleaving(self) -> None:
        """
        機能: raw−1/0/1→0/1/2変換と買売交互行・同重みを検査する。
        引数: self(Run151Tests)。返り値: None。
        """
        features, teachers = artificial_datasets()
        selected = teacher.select_past_teachers(teachers.rows, [s['start'] for s in features.scenes], 8)
        x, y, weights, indices = run.training_arrays(features, teachers, selected, 8)
        self.assertEqual(x.shape, (2000, 100)); self.assertEqual(len(indices), 1000)
        self.assertTrue(np.array_equal(x[0::2], features.buy_X[indices], equal_nan=True))
        self.assertTrue(np.array_equal(x[1::2], features.sell_X[indices], equal_nan=True))
        expected = [label + 1 for pair in selected['pairs'] for label in (pair['label_buy'], pair['label_sell'])]
        self.assertEqual(y.tolist(), expected)
        self.assertTrue(np.array_equal(weights[0::2], weights[1::2]))
        invalid = copy.deepcopy(teachers); invalid.rows[0]['known_at'] = features.scenes[8]['start']
        with self.assertRaises(AssertionError): run.training_arrays(features, invalid, selected, 8)

    def test_02_current_future_labels_leave_earlier_fit_and_prediction_same(self) -> None:
        """
        機能: 現場/未来教師変更が対象場までのfit/予測へ混ざらず次場だけ変わり得ることを検査する。
        引数: self(Run151Tests)。返り値: None。
        """
        features, teachers = artificial_datasets(); changed = copy.deepcopy(teachers)
        for row in changed.rows:
            if row['session_index'] >= 8: row['label_buy'] = row['label_sell'] = 1
        models = [SpyModel(), SpyModel()]
        results = []
        with contextlib.redirect_stdout(io.StringIO()):
            for source, spy in zip((teachers, changed), models):
                results.append(run.simulate(features, source, COLUMNS, book(), HERE / '人工のみ', spy, teacher.select_past_teachers))
        before, after = results
        self.assertEqual([call['current'] for call in models[0].calls], [8, 9])
        self.assertEqual(models[0].calls[0]['signature'], models[1].calls[0]['signature'])
        self.assertNotEqual(models[0].calls[1]['signature'], models[1].calls[1]['signature'])
        self.assertEqual(before[0][:1125], after[0][:1125])
        self.assertNotEqual(before[0][1125]['prediction']['probabilities'], after[0][1125]['prediction']['probabilities'])
        self.assertTrue(all(d['prediction']['reason'] == 'untrained' for d in before[0][:1000]))
        for audit in before[1]:
            self.assertTrue(audit['max_label_known_at'] is None or audit['max_label_known_at'] < audit['current_start'])
        for d in before[0]: self.assertEqual(d['decision']['directions']['N70'], d['decision']['directions']['P70'])

    def test_03_p70_primary_canonical_and_c1_priority(self) -> None:
        """
        機能: P65先行は主P70を予約せず、U70/65/60でC1を同じく優先する。
        引数: self(Run151Tests)。返り値: None。
        """
        sessions = ['人工A', '人工B']
        descriptors = [{'case_id': f'旧{i}', 'session': sessions[i % 2], 'contract': '人工限月', 'original_side': -1,
                        'buy_stream': 'reverse', 'sell_stream': 'original', 'c1_reused': True} for i in range(87)]
        descriptors.append({'case_id': '新', 'session': sessions[0], 'contract': '人工限月', 'original_side': 1,
                            'buy_stream': 'original', 'sell_stream': 'reverse', 'c1_reused': False})
        decisions, captures = [], []
        for event, idx, cid, dirs in [('感度先行', 10, '新', (0, 1, 1)), ('主後続', 20, '新', (-1, -1, -1)), ('旧重複', 30, '旧0', (1, 1, 1))]:
            directions = dict(zip(('P70', 'P65', 'P60'), dirs)); directions['N70'] = dirs[0]
            evidence = [{'rule': name, 'signal_side': side, 'order_side': side, 'roles': ['方向', '量'], 'model_id': 0}
                        for name, side in zip(('P70', 'P65', 'P60'), dirs) if side]
            decisions.append({'event_id': event, 'session': sessions[0], 'contract': '人工限月', 'q0_time': 1000 + idx,
                              'q0_index': idx, 'q0_line': 100 + idx, 'decision': {'directions': directions,
                              'conflicts': {k: False for k in directions}, 'evidence': evidence}})
            captures.append({'event_id': event, 'session': sessions[0], 'contract': '人工限月', 'q0': {'time': 1000 + idx, 'index': idx, 'source_line': 100 + idx},
                             'status': 'filled', 'case_id': cid, 'buy_stream': 'reverse' if cid == '旧0' else 'original',
                             'sell_stream': 'original' if cid == '旧0' else 'reverse'})
        result = run.link_decisions(decisions, {'rows': captures}, {'population148': {'cases': descriptors}}, sessions, helper)
        main = next(r for r in result['政策']['N70'] if r['case_id'] == '新')
        self.assertEqual((main['event_id'], main['side'], main['成立ID']), ('主後続', -1, ['P70']))
        self.assertEqual(next(r for r in result['政策']['P65'] if r['case_id'] == '新')['event_id'], '感度先行')
        for union in ('U70', 'U65', 'U60'):
            old = next(r for r in result['政策'][union] if r['case_id'] == '旧0')
            self.assertEqual((old['side'], old['stream'], old['event_id']), (-1, 'original', None))
            self.assertEqual(len(result['政策'][union]), 88)

    def test_04_book_guard_before_natural_load(self) -> None:
        """
        機能: runtime/閾値/教師窓/role/連結の契約不一致を先に拒否する。
        引数: self(Run151Tests)。返り値: None。
        """
        run.validate_book(book(), model, teacher)
        paths = [('runtime', 'python'), ('training', 'window_sessions'), ('training', 'minimum_physical_pairs'),
                 ('selection', 'minimum_score_margin'), ('selection', 'minimum_known_roles'), ('linking', 'primary_new')]
        for group, key in paths:
            invalid = book(); invalid[group][key] = '不一致'
            with self.assertRaises(AssertionError): run.validate_book(invalid, model, teacher)

    def test_05_main_saves_all_predictions_before_link(self) -> None:
        """
        機能: mainの全q0保存・場別監査保存より前に取得結合を呼べないことをspyで確認する。
        引数: self(Run151Tests)。返り値: None。
        """
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder); conditions = book(); conditions['inputs'] = {}
            for name in ('features', 'fixed', 'captures', 'metadata', 'observations'):
                path = base / (name + '.json'); path.write_text('{}', encoding='utf-8')
                conditions['inputs'][name] = {'path': str(path), 'sha256': digest(path), 'decoded_sha256': digest(path)}
            book_path = base / 'book.json'; book_path.write_text(json.dumps(conditions), encoding='utf-8')
            output = base / 'output'; events = []
            feature_meta = object()
            feature = SimpleNamespace(scenes=[{'session': '人工A'}], feature_meta=lambda: feature_meta)
            teachers = SimpleNamespace(counts={'人工': 2})
            def project(meta, *args):
                """
                機能: 教師射影へ特徴行列を渡さないことを確認する。
                引数: meta(object)、args(tuple)。返り値: object。
                """
                self.assertIs(meta, feature_meta); events.append('teacher_projection')
                return teachers
            def read_reference(ref):
                """
                機能: 後段の直接capture読取で予測資料の実在を確認する。
                引数: ref(FileRef)。返り値: tuple[dict,dict]。
                """
                self.assertTrue((output / 'q0の判断.json').exists())
                self.assertTrue((output / '場別モデルと教師.json').exists())
                events.append('late_' + Path(ref.path).stem)
                return {}, {}
            fake_data = SimpleNamespace(FileRef=data.FileRef, load_feature_dataset=lambda *args: feature,
                project_teacher=project, save_feature_cache=lambda *args: None, save_teacher_cache=lambda *args: None,
                read_ref=read_reference)
            modules = {'data151': fake_data, 'model151': model, 'teacher151': teacher, 'link151': helper}
            decisions = [{'event_id': '人工A'}, {'event_id': '人工B'}]
            audits = [{'ready': False}, {'ready': False}]
            def simulate(*args):
                """
                機能: 全q0判断が完成するまでsimulateが返らない状況を人工化する。
                引数: args(tuple)。返り値: tuple[list,list]。
                """
                self.assertFalse((output / 'q0の判断.json').exists()); events.append('all_predictions_finished')
                return decisions, audits
            def link(*args):
                """
                機能: 全q0保存済みかつ全判断が揃った後だけ結合する。
                引数: args(tuple)。返り値: dict。
                """
                saved = json.loads((output / 'q0の判断.json').read_bytes())
                self.assertEqual(saved['rows'], decisions); events.append('link')
                return {'政策': {'C1': [], 'U70': []}}
            argv = ['run151', '--book', str(book_path), '--sha256', digest(book_path), '--output-dir', str(output)]
            with mock.patch.object(run, 'module', side_effect=lambda path, name: modules[name]), mock.patch.object(run, 'simulate', side_effect=simulate), mock.patch.object(run, 'link_decisions', side_effect=link), mock.patch.object(sys, 'argv', argv), contextlib.redirect_stdout(io.StringIO()):
                run.main()
            self.assertLess(events.index('all_predictions_finished'), events.index('late_captures'))
            self.assertLess(events.index('late_metadata'), events.index('link'))


def main() -> None:
    """
    機能: 自然なしの独立5主人工を実行し運転Sourceの前後不変を保存する。
    引数: なし。返り値: None。独立teacher数理検算はRoot別票とする。
    """
    sources = [CODE, CODE.parent / 'data151.py', CODE.parent / 'model151.py', teacher_path,
               ROOT / 'scripts/入口研究/固定特徴から可読条件を選択する.py']
    before = {str(p.relative_to(ROOT)): digest(p) for p in sources}
    assert digest(CODE) == SOURCE_SHA
    log = io.StringIO()
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Run151Tests))
    log_path = HERE / '人工のログ.txt'; log_path.write_text(log.getvalue(), encoding='utf-8')
    assert result.wasSuccessful(), log.getvalue()
    assert before == {str(p.relative_to(ROOT)): digest(p) for p in sources}
    proof = {'成功': True, '編集停止': True, '状態': '151運転の独立因果準備', '独立人工主群': result.testsRun,
             'raw教師+1/左右交互/同重み': True,
             '10人工場のうち最初8待機/8場目過去1000pairのみ学習': True,
             '現場8/未来9教師変更で場8までのfit署名/予測不変、次場のみ変更可': True,
             '全q0保存と全場監査保存後のみ取得結合': True,
             'P70主winner/感度先行で予約しない/C1優先': True,
             'runtime/book/教師窓/閾値/役割除外/linking整合': True,
             'teacher作者境界': '本監査者は純teacher module作者。運転の配列抽出/時点spyを検査し、teacher数理独立検算はRoot別票。',
             '教師射影と取得結合': 'main前段は教師作成のため全観測を射影。予測への現在教師漏洩と、保存後の取得結合を区別する。',
             '自然入力/自然151教師/fit/金融/Raw/CSV/追加2場読取': False,
             'Source/正式変更': False, '重大未解決': [], '対象源前後同体': before,
             '私有人工SHA256': digest(Path(__file__)), '人工ログSHA256': digest(log_path)}
    output = HERE / '確認の記録.json'
    output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '人工': result.testsRun, '対象SHA256': SOURCE_SHA,
                      '停止票SHA256': digest(output)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
