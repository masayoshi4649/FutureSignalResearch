"""整数値floatの場開始を無損失正規化する差分だけを、旧票を保って確認する。"""
from pathlib import Path
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CODE = ROOT / 'work/151過去場判別/run151.py'
OLD_PROOF = HERE / '確認の記録.json'
SOURCE_SHA = '17ba1de23a58220f7297553313f99429138413300de74f4b4c21682fe89060d6'
spec = importlib.util.spec_from_file_location('旧運転人工再用', HERE / '独立人工.py')
previous = importlib.util.module_from_spec(spec); spec.loader.exec_module(previous)


def sha(path: Path) -> str:
    """
    機能: 新旧固定源と追補人工を指紋化する。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


class ClockSupplement(unittest.TestCase):
    """自然入力を開かない場開始型の限定追加人工。"""

    def test_06_integer_float_starts_preserve_all_training_and_prediction(self) -> None:
        """
        機能: 整数値floatとint場開始で全fit署名・全予測が同体か確認する。
        引数: self(ClockSupplement)。返り値: None。
        """
        features, teachers = previous.artificial_datasets()
        float_features = copy.deepcopy(features)
        for scene in float_features.scenes: scene['start'] = float(scene['start'])
        spies = [previous.SpyModel(), previous.SpyModel()]
        result = []
        with contextlib.redirect_stdout(io.StringIO()):
            for data, spy in zip((features, float_features), spies):
                result.append(previous.run.simulate(data, teachers, previous.COLUMNS, previous.book(),
                              HERE / '人工のみ', spy, previous.teacher.select_past_teachers))
        self.assertEqual(result[0], result[1])
        self.assertEqual([x['signature'] for x in spies[0].calls], [x['signature'] for x in spies[1].calls])

    def test_07_fractional_and_bad_starts_rejected_before_teacher_and_fit(self) -> None:
        """
        機能: 小数・非有限・bool時計をteacher/fitへ到達する前に拒否する。
        引数: self(ClockSupplement)。返り値: None。
        """
        for bad in (100000.25, float('nan'), float('inf'), True):
            features, teachers = previous.artificial_datasets()
            features.scenes[0]['start'] = bad
            calls = []
            def teacher_spy(*args):
                """
                機能: 不正時計が教師選択まで到達したら検査失敗にする。
                引数: args(tuple)。返り値: なし、AssertionError。
                """
                calls.append(args); raise AssertionError('教師まで到達')
            model = previous.SpyModel()
            with self.assertRaises(AssertionError):
                previous.run.simulate(features, teachers, previous.COLUMNS, previous.book(),
                                      HERE / '人工のみ', model, teacher_spy)
            self.assertEqual(calls, []); self.assertEqual(model.calls, [])


def main() -> None:
    """
    機能: 旧5群と追加2群を確認し、初回票不変の追補停止票を保存する。
    引数: なし。返り値: None。自然cache/出力/教師/金融は開かない。
    """
    assert sha(CODE) == previous.SOURCE_SHA == SOURCE_SHA
    old_sha = sha(OLD_PROOF)
    assert old_sha == '11a5dbb374b2a22bf0385a6a488f4b2d26b4bd527c48e830b3bb7b6bb6a874bd'
    old_source = ROOT / 'work/151過去場判別の初回射影と時計型停止/初回run151.py'
    assert sha(old_source) == 'e5fae2a2a1af777ff732b27ea8c1388fdd32589fbe813a3f0a8a52b72702ccc2'
    log = io.StringIO()
    suite = unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromTestCase(previous.Run151Tests),
                               unittest.defaultTestLoader.loadTestsFromTestCase(ClockSupplement)])
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    log_path = HERE / '場開始追補の人工ログ.txt'; log_path.write_text(log.getvalue(), encoding='utf-8')
    assert result.wasSuccessful(), log.getvalue()
    assert sha(CODE) == SOURCE_SHA and sha(OLD_PROOF) == old_sha
    proof = {'成功': True, '編集停止': True, '状態': '151場開始の無損失型正規化の限定追補',
             '対象SourceSHA256': SOURCE_SHA, '旧5群再実行': 5, '追加人工': 2,
             'int/整数値floatで全fit署名/全判断/全監査同体': True,
             '小数/非有限/boolはteacherとfit以前で拒否': True,
             '初回運転票SHA256/不変更': old_sha, '初回源の保管SHA一致': True,
             '旧pureteacher変更': False,
             '自然cache/教師/出力/モデル/金融/Raw/CSV/追加2場読取': False,
             'Source/正式変更': False, '重大未解決': [],
             '人工SourceSHA256': sha(Path(__file__)), '人工ログSHA256': sha(log_path)}
    output = HERE / '場開始の正規化追補確認.json'
    output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '人工': result.testsRun, '対象SHA256': SOURCE_SHA,
                      '追補SHA256': sha(output)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
