"""151の過去場モデルを場開始時に固定し、全q0判断後に取得だけを結ぶ。"""
from pathlib import Path
from collections import Counter
import argparse
import hashlib
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def module(path: Path, name: str) -> object:
    """
    機能: dataclassの所属を登録して固定モジュールを読み込む。
    引数: path(Path)、name(str)。
    返り値: objectはmain未実行のモジュール。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: 物理bytesの指紋を固定bufferで計算する。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def validate_book(book: dict, model: object, teacher: object) -> None:
    """
    機能: 閾値・教師窓・実行環境が事前条件と同一であることを検査する。
    引数: book(dict)、model(object)、teacher(object)は固定部品。
    返り値: None。不一致時は自然入力を読む前に停止する。
    """
    import numpy as np
    import catboost
    assert book['trial'] == 151 and book['session_count'] == 73
    assert book['feature_rows'] == 35339 and book['legacy_count'] == 87
    assert book['catalog_count'] == 100
    assert book['runtime'] == {'python': '.'.join(map(str, sys.version_info[:3])),
                               'numpy': np.__version__, 'catboost': catboost.__version__}
    assert book['classifier_parameters'] == model.PARAMS
    setting = book['training']
    assert setting['window_sessions'] == teacher.WINDOW_SESSIONS == 20
    assert setting['minimum_physical_pairs'] == teacher.MIN_PAIRS == 1000
    assert setting['minimum_contributing_sessions'] == teacher.MIN_CONTRIBUTING_SESSIONS == 8
    assert set(setting['minimum_classes']) == teacher.LABELS == {-1, 0, 1}
    assert setting['label_to_class'] == {'-1': 0, '0': 1, '1': 2}
    selection = book['selection']
    assert selection['thresholds'] == {'P70': .7, 'P65': .65, 'P60': .6}
    assert selection['minimum_score_margin'] == .05
    assert selection['minimum_forward_probability'] == .4
    assert selection['minimum_known_roles'] == 2
    assert set(selection['role_excluded_columns']) == model.EXCLUDED_ROLE_COLUMNS
    assert selection['q1_for_prediction'] is False
    assert book['linking'] == {'primary_new': 'P70', 'primary_union': 'U70',
        'sensitivity_unions': {'U65': 'P65', 'U60': 'P60'}, 'legacy': 'C1',
        'same_q1': '旧C1優先、C1外は最初q0、後発aliasは重複計数しない'}


# ----------------------------------------
def training_arrays(features: object, teachers: object, selected: dict, current_index: int) -> tuple:
    """
    機能: 成熟選択済みpairだけからBUY/SELLの数値配列を作る。
    引数: features/teachers(object)、selected(dict)、current_index(int)。
    返り値: tupleはX/y/weights/feature_indices。現場教師は通さない。
    """
    import numpy as np
    pairs = selected['pairs']
    assert selected['ready']
    indices, labels, weights = [], [], []
    for pair in pairs:
        row = teachers.rows[pair['source_index']]
        index = row['feature_index']
        q0 = features.q0_meta[index]
        assert row['pair_complete'] and row['session_index'] < current_index
        assert row['known_at'] < features.scenes[current_index]['start']
        assert row['event_id'] == q0['event_id'] == pair['event_id']
        assert row['session_index'] == q0['session_index']
        assert (row['label_buy'], row['label_sell']) == (pair['label_buy'], pair['label_sell'])
        assert all(type(label) is int and label in (-1, 0, 1) for label in (row['label_buy'], row['label_sell']))
        indices.append(index)
        labels.extend((row['label_buy'] + 1, row['label_sell'] + 1))
        weights.extend((pair['side_weight'], pair['side_weight']))
    matrix = np.empty((2 * len(indices), 100), dtype=np.float64)
    matrix[0::2] = features.buy_X[indices]
    matrix[1::2] = features.sell_X[indices]
    return matrix, np.asarray(labels, dtype=np.int64), np.asarray(weights, dtype=np.float64), indices


# ----------------------------------------
def simulate(features: object, teachers: object, columns: list[dict], book: dict, output: Path,
             model_module: object, teacher_selector: object) -> tuple[list, list]:
    """
    機能: 場ごとに過去モデルを作り、その場の全特徴だけを予測する。
    引数: features/teachers(object)、columns(list[dict])、book(dict)、output(Path)、
          model_module(object)とteacher_selector(callable)は分離済み部品。
    返り値: tuple[list,list]は全q0判断と場別学習監査。取得結合は行わない。
    """
    assert list(features.columns) == [column['name'] for column in columns]
    assert book['classifier_parameters'] == model_module.PARAMS
    thresholds = book['selection']['thresholds']
    assert thresholds == {'P70': .7, 'P65': .65, 'P60': .6}
    starts = [scene['start'] for scene in features.scenes]
    decisions, audits = [], []
    for current, scene in enumerate(features.scenes):
        selected = teacher_selector(teachers.rows, starts, current)
        assert selected['current_scene_start'] == scene['start']
        assert selected['window']['first_session_index'] == max(0, current - 20)
        active = [i for i, row in enumerate(features.q0_meta) if row['session_index'] == current]
        model, ref = None, None
        if selected['ready']:
            X, y, weights, used_features = training_arrays(features, teachers, selected, current)
            model, ref = model_module.fit_past(X, y, weights, columns, output / 'models' / f'{current:03d}.json')
            buy_p, sell_p = model_module.predict_both(model, features.buy_X[active], features.sell_X[active], columns)
            used = ref['used_indices']
        else:
            used_features = []
            buy_p = sell_p = [None] * len(active)
            used = []
        assert len(buy_p) == len(sell_p) == len(active)
        reason_counts = Counter()
        for offset, index in enumerate(active):
            q0 = features.q0_meta[index]
            vote = model_module.decide(features.buy_X[index], features.sell_X[index],
                buy_p[offset], sell_p[offset], columns, used, thresholds)
            reason_counts[vote['reason']] += 1
            directions = dict(vote['directions'])
            directions['N70'] = directions['P70']
            evidence = [{'rule': name, 'signal_side': side, 'order_side': side,
                'roles': list(vote['known_roles']), 'model_id': current}
                for name, side in vote['directions'].items() if side]
            decisions.append({**q0, 'model_id': current if model is not None else None,
                'prediction': vote, 'decision': {'directions': directions,
                    'conflicts': {name: False for name in directions}, 'evidence': evidence}})
        audits.append({'session_index': current, 'session': scene['session'], 'current_start': scene['start'],
            'ready': selected['ready'], 'ready_reasons': selected['ready_reasons'],
            'window': selected['window'], 'physical_pair_count': selected['physical_pair_count'],
            'contributing_sessions': selected['contributing_sessions'], 'classes': selected['classes'],
            'active_block_count': selected['active_block_count'], 'blocks': selected['blocks'],
            'max_label_known_at': max((row['known_at'] for row in selected['pairs']), default=None),
            'training_source_indices': selected['indices'], 'training_feature_indices': used_features,
            'side_weight_mean': selected['side_weight_mean'], 'model': ref,
            'all_current_feature_rows': len(active), 'prediction_reasons': dict(reason_counts)})
        print(json.dumps({'場': current + 1, '全場': len(features.scenes), 'session': scene['session'],
            '学習': model is not None, '過去pair': selected['physical_pair_count'],
            '判断数': len(active), 'P70候補': sum(row['decision']['directions']['P70'] != 0
                for row in decisions[-len(active):]) if active else 0}, ensure_ascii=False), flush=True)
    assert len(decisions) == len(features.q0_meta)
    assert [row['event_id'] for row in decisions] == [row['event_id'] for row in features.q0_meta]
    return decisions, audits


# ----------------------------------------
def link_decisions(decisions: list, captures: dict, metadata: dict, sessions: list,
                   helper: object) -> dict:
    """
    機能: 全予測後に各閾値の取得と旧C1を統合する。
    引数: decisions(list)、captures/metadata(dict)、sessions(list)、helper(object)。
    返り値: dictは固定政策の取得参照。q1で予測を取り直さない。
    """
    link_book = {'rules': [{'id': name} for name in ('P70', 'P65', 'P60')],
        'union_rules': ['P70'], 'union_id': 'N70', 'legacy_id': 'C1', 'main_id': 'U70',
        'session_count': len(sessions), 'legacy_count': 87}
    result = helper.connect(decisions, captures['rows'], metadata['population148']['cases'], sessions, link_book)
    base = {row['case_id']: row for row in result['政策']['C1']}
    overlaps = {'U70': result.pop('旧C1重複')}
    for name, source in (('U65', 'P65'), ('U60', 'P60')):
        merged = dict(base)
        overlapping = []
        for row in result['政策'][source]:
            case_id = row['case_id']
            if case_id in merged:
                overlapping.append({'case_id': case_id, 'legacy_side': merged[case_id]['side'],
                    'new_side': row['side'], 'opposite': merged[case_id]['side'] != row['side']})
            else:
                merged[case_id] = row
        result['政策'][name] = list(merged.values())
        overlaps[name] = overlapping
    result['旧C1重複'] = overlaps
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: 固定入力を射影し、全q0学習予測の後にだけ実取得へ結ぶ。
    引数: CLI book(Path)/sha256(str)/output-dir(Path)は固定仕様と未作成先。
    返り値: None。モデル・監査・判断・選択を新規保存し、既存試行を変更しない。
    """
    parser = argparse.ArgumentParser(description='151の過去場限定複合テクニカル判別')
    parser.add_argument('--book', type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output_dir.exists() and sha(args.book) == args.sha256
    book = json.loads(args.book.read_bytes())
    assert book['trial'] == 151
    data = module(HERE / 'data151.py', 'data151')
    model = module(HERE / 'model151.py', 'model151')
    teacher = module(ROOT / 'work/過去場だけの教師選択と時間区画重み/教師選択.py', 'teacher151')
    helper = module(ROOT / 'scripts/入口研究/固定特徴から可読条件を選択する.py', 'link151')
    validate_book(book, model, teacher)
    refs = {name: data.FileRef(ROOT / row['path'], row['sha256'], row['decoded_sha256'])
            for name, row in book['inputs'].items()}
    columns_path = ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json'
    assert sha(columns_path) == book['catalog_definition_sha256']
    columns = json.loads(columns_path.read_bytes())
    features = data.load_feature_dataset(refs['features'], refs['fixed'])
    teachers = data.project_teacher(features.feature_meta(), refs['captures'], refs['metadata'], refs['fixed'], refs['observations'])
    args.output_dir.mkdir(parents=True)
    data.save_feature_cache(features, args.output_dir / 'cache/feature_only')
    data.save_teacher_cache(teachers, args.output_dir / 'cache/teacher_only')
    decisions, audits = simulate(features, teachers, columns, book, args.output_dir, model, teacher.select_past_teachers)
    helper.save(args.output_dir / 'q0の判断.json', {'成功': True, '試行': 151,
        '全q0判断数': len(decisions), '当場ラベルをモデルへ渡す': False, 'rows': decisions})
    helper.save(args.output_dir / '場別モデルと教師.json', {'成功': True, '試行': 151,
        '教師射影の範囲': '射影器は全観測を読むが、学習は当場以前の成熟pairだけへ限定する',
        'teacher_counts': teachers.counts, 'scenes': audits})
    # ----------------------------------------
    # 取得結合は全q0予測を排他保存した後。現在場のcaptureを予測引数へ渡しません。
    captures, _ = data.read_ref(refs['captures'])
    metadata, _ = data.read_ref(refs['metadata'])
    result = link_decisions(decisions, captures, metadata, [scene['session'] for scene in features.scenes], helper)
    helper.save(args.output_dir / '選択対応.json', {'成功': True, '試行': 151, **result})
    assert sha(args.book) == args.sha256
    for ref in refs.values():
        assert sha(Path(ref.path)) == ref.sha256
    helper.save(args.output_dir / '選択の確認.json', {'成功': True, '試行': 151,
        'book_sha256': args.sha256, '全q0判断後に取得結合': True,
        'モデル数': sum(row['ready'] for row in audits), '政策別取得数': {name: len(rows) for name, rows in result['政策'].items()},
        '予測資料': {path.name: sha(path) for path in args.output_dir.iterdir() if path.is_file()},
        '共有入力': {name: {'path': str(ref.path), 'sha256': ref.sha256, 'decoded_sha256': ref.decoded_sha256} for name, ref in refs.items()}})
    print(json.dumps({'成功': True, '政策別取得数': {name: len(rows) for name, rows in result['政策'].items()}}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
