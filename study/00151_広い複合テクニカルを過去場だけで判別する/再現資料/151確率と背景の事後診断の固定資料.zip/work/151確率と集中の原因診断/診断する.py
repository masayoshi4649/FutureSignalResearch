"""151の固定選択だけの確率校正・場集中・実反転を事後診断する。"""
from pathlib import Path
from collections import Counter
import hashlib
import importlib.util
import json
import math
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
EVAL = ROOT / 'work/151過去場判別の評価'
SELECTION = EVAL / '入口選択/選択対応.json'
DECISIONS = EVAL / '入口選択/q0の判断.json'
AUDITS = EVAL / '入口選択/場別モデルと教師.json'
SUMMARY = EVAL / '金融診断/集計.json'
OBS = ROOT / 'work/148全1分母集団の評価/固定取得の正逆観測.json'
PARENT = ROOT / 'work/149局面の位置と急変と実反転の診断/診断する.py'
POLICIES = ('P70', 'P65', 'P60', 'U70')
LEVELS = ('[.60,.65)', '[.65,.70)', '[.70,.80)', '[.80,.90)', '[.90,1]', '閾値未満', '未知')
EXPECTED = {
    SELECTION: '2c8a9c9e932b2469c50534e93b8ea4770613ef951da68f2f74d7a022bcb18266',
    DECISIONS: '14b4bfaf2d6cc8832c3fb075a029389b7c0da4591489854547308919b93ba118',
    AUDITS: '91df571f7bd144e7e06b992d32165fc82e78355add4a96951c42090f81302a5b',
    SUMMARY: 'ab002c2088784bb45ea86800550013ae44637f39d4bafb7a70e42814789ccd04',
    OBS: 'd1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc',
    PARENT: '963044ab01273131755f4f6df963af986e49a44d0100fa6258c4b340f1e9140a',
}


def sha(path: Path) -> str:
    """
    機能: 入力を複写せず固定bufferで指紋化する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    value = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''):
            value.update(block)
    return value.hexdigest()


def module(path: Path) -> object:
    """
    機能: 保存quote算術と配列stream readerだけを固定旧診断から読む。
    引数: path(Path)。
    返り値: objectはmainを呼ばない私有module。
    """
    spec = importlib.util.spec_from_file_location('frozen149diagnostic151', path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = value
    spec.loader.exec_module(value)
    return value


def bucket(value: float | None) -> str:
    """
    機能: 事後説明用に先固定した重複しない確率区画へ分ける。
    引数: value(float|None)は保存conditional。
    返り値: strは区画名。
    """
    if value is None:
        return '未知'
    assert math.isfinite(value) and 0 <= value <= 1
    if value < .6:
        return '閾値未満'
    if value < .65:
        return '[.60,.65)'
    if value < .7:
        return '[.65,.70)'
    if value < .8:
        return '[.70,.80)'
    if value < .9:
        return '[.80,.90)'
    return '[.90,1]'


def average(values: list) -> float | None:
    """
    機能: 欠測を0へ変えず有限観測だけの平均を求める。
    引数: values(list[float|None])。
    返り値: float|None。
    """
    known = [v for v in values if v is not None]
    return sum(known) / len(known) if known else None


def describe(rows: list, old: object) -> dict:
    """
    機能: 同じ元確率群のままnativeと実逆・校正をまとめる。
    引数: rows(list[dict])、old(object)は保存quote算術。
    返り値: dictは未到達/不足/IFD未知を残した数値。
    """
    out = old.paired(rows)
    scored = [r for r in rows if r['conditional'] is not None]
    resolved = [r for r in scored if r['native']['state'] in ('F', 'A')]
    complete = [r for r in scored if r['native']['state'] != 'C']
    out['校正'] = {
        '予測付き件数': len(scored),
        '予測付きF_A既知件数': len(resolved),
        '平均conditional_全件': average([r['conditional'] for r in scored]),
        '平均conditional_F_A既知分': average([r['conditional'] for r in resolved]),
        '実測F_A率': sum(r['native']['state'] == 'F' for r in resolved) / len(resolved) if resolved else None,
        '平均pF_全件': average([r['pF'] for r in rows]),
        '平均pA_全件': average([r['pA'] for r in rows]),
        '平均pN_全件': average([r['pN'] for r in rows]),
        'F_A既知Brier': average([(r['conditional'] - int(r['native']['state'] == 'F')) ** 2 for r in resolved]),
        '完了分母F率': sum(r['native']['state'] == 'F' for r in complete) / len(complete) if complete else None,
        '完了分母N率': sum(r['native']['state'] == 'N' for r in complete) / len(complete) if complete else None,
        '平均q0_q1秒': average([r['q1_time'] - r['q0_time'] for r in rows if r['q0_time'] is not None]),
    }
    return out


def group_rows(rows: list, mode: str) -> list:
    """
    機能: 当場時刻順から名目H60連結又は同向/同モデルrunを作る。
    引数: rows(list[dict])、mode(str)はH60/side/model/side_model。
    返り値: list[list[dict]]。runは時間gapを制限しない。
    """
    result = []
    ordered = sorted(rows, key=lambda r: (r['session_index'], r['q1_time'], r['q1_index'], r['q1_line'], r['case_id']))
    edge = None
    for row in ordered:
        previous = result[-1][-1] if result else None
        same = previous is not None and previous['session'] == row['session']
        if same:
            if mode == 'H60':
                same = row['q1_time'] < edge
            elif mode == 'side':
                same = row['side'] == previous['side']
            elif mode == 'model':
                same = row['model_id'] == previous['model_id']
            elif mode == 'side_model':
                same = (row['side'], row['model_id']) == (previous['side'], previous['model_id'])
            else:
                raise ValueError('未定義群')
        if not same:
            result.append([])
            edge = row['q1_time'] + 3600
        result[-1].append(row)
        edge = max(edge, row['q1_time'] + 3600)
    return result


def group_summary(rows: list, old: object) -> dict:
    """
    機能: 群件数と最大5群の小さい記述だけを返す。
    引数: rows(list[dict])、old(object)。
    返り値: dictは全件転載を避けた集中指標。
    """
    out = {}
    for mode in ('H60', 'side', 'model', 'side_model'):
        groups = group_rows(rows, mode)
        top = []
        for g in sorted(groups, key=lambda x: (-len(x), x[0]['session_index'], x[0]['q1_time']))[:5]:
            t = [r['q1_time'] for r in g]
            top.append({'session': g[0]['session'], '件数': len(g), 'side集合': sorted({r['side'] for r in g}),
                'model_id集合': sorted({r['model_id'] for r in g}, key=lambda x: -1 if x is None else x),
                '初取得': t[0], '最終取得': t[-1], 'span秒': t[-1] - t[0],
                '最大隣接gap秒': max((b-a for a, b in zip(t, t[1:])), default=0),
                '初case': g[0]['case_id'], '最終case': g[-1]['case_id'], '数値': describe(g, old)})
        out[mode] = {'群数': len(groups), '最大群件数': max(map(len, groups), default=0),
                     '最大群件数比': max(map(len, groups), default=0) / len(rows) if rows else None, '上位5群': top}
    return out


def scene_summary(rows: list, sessions: list, old: object) -> dict:
    """
    機能: 全73場を残し件数/方向/損益集中と分母を求める。
    引数: rows(list[dict])、sessions(list[str])、old(object)。
    返り値: dict。
    """
    scene = {s: describe([r for r in rows if r['session'] == s], old) for s in sessions}
    counts = [scene[s]['元方向']['件数'] for s in sessions]
    profit = sum(r['native']['net5'] for r in rows if r['native']['net5'] is not None and r['native']['net5'] > 0)
    loss = -sum(r['native']['net5'] for r in rows if r['native']['net5'] is not None and r['native']['net5'] < 0)
    return {'全73場': scene, '取得場数': sum(n > 0 for n in counts), '取得ゼロ場': [s for s in sessions if not scene[s]['元方向']['件数']],
        '最大場件数': max(counts, default=0), '上位1場件数比': max(counts, default=0) / len(rows) if rows else None,
        '上位5場件数比': sum(sorted(counts, reverse=True)[:5]) / len(rows) if rows else None,
        '場件数HHI': sum((n / len(rows)) ** 2 for n in counts) if rows else None,
        '最大場利益寄与比': max((v['元方向']['C5利益'] or 0 for v in scene.values()), default=0) / profit if profit else None,
        '最大場損失寄与比': max((v['元方向']['C5損失絶対'] or 0 for v in scene.values()), default=0) / loss if loss else None}


def main() -> None:
    """
    機能: 固定確率区画から保存151の選択/予測/実正逆を事後結合する。
    引数: なし。
    返り値: None。新folderに小型数値と前後SHA証跡を排他保存する。
    """
    assert not (HERE / '診断.json').exists()
    sources = {**EXPECTED, HERE / '診断範囲.md': sha(HERE / '診断範囲.md'), Path(__file__): sha(Path(__file__))}
    assert all(sha(p) == h for p, h in sources.items())
    before = {str(p): [p.stat().st_size, p.stat().st_mtime_ns] for p in sources}
    selection = json.loads(SELECTION.read_bytes())
    summary = json.loads(SUMMARY.read_bytes())
    decisions = {r['event_id']: r for r in json.loads(DECISIONS.read_bytes())['rows']}
    audits = json.loads(AUDITS.read_bytes())['scenes']
    sessions = selection['全73場']
    assert len(sessions) == len(audits) == 73 and len(decisions) == 35339
    old = module(PARENT)
    needed = {r['case_id'] for p in POLICIES for r in selection['政策'][p]}
    cases = {}
    scene_count = 0
    for scene in old.array_items(OBS, 'scenes'):
        assert scene['success'] and scene['session'] == sessions[scene_count]
        scene_count += 1
        for case in scene['cases']:
            if case['id'] in needed:
                assert case['id'] not in cases
                cases[case['id']] = (scene['session'], case)
    assert scene_count == 73 and set(cases) == needed
    policy_rows = {}
    for policy in POLICIES:
        rows = []
        physical = set()
        for choice in selection['政策'][policy]:
            sid, case = cases[choice['case_id']]
            stream = choice['stream']
            reverse = 'reverse' if stream == 'original' else 'original'
            q1 = case[stream]['entry']
            assert choice['session'] == sid and case[stream]['birth']['side'] == choice['side']
            assert q1 == case[reverse]['entry'] and case[reverse]['birth']['side'] == -choice['side']
            key = (sid, q1['time'], q1['index'], q1['source_line'])
            assert key not in physical
            physical.add(key)
            decision = decisions.get(choice['event_id'])
            if policy != 'U70':
                assert decision and decision['session'] == sid and decision['decision']['directions'][policy] == choice['side']
                assert (decision['q0_time'], decision['q0_index'], decision['q0_line']) == (choice['q0_time'], choice['q0_index'], choice['q0_line'])
            vote = decision['prediction'] if decision else {}
            side_prob = (vote.get('probabilities') or {}).get('buy' if choice['side'] == 1 else 'sell')
            # U70の旧C1は保護方向なので、別方向の新予測を校正対象へ混ぜません。
            if policy == 'U70' and choice['origin'] == 'C1':
                side_prob = None
            cond = side_prob[2] / (side_prob[2] + side_prob[0]) if side_prob and side_prob[2] + side_prob[0] > 0 else None
            if policy != 'U70':
                assert cond is not None and math.isclose(cond, vote['conditional_forward'], abs_tol=1e-15)
                assert cond >= {'P70': .7, 'P65': .65, 'P60': .6}[policy]
            rows.append({'session': sid, 'session_index': sessions.index(sid), 'case_id': choice['case_id'],
                'event_id': choice['event_id'], 'side': choice['side'], 'model_id': decision['model_id'] if decision and side_prob else None,
                'q0_time': choice.get('q0_time'), 'q1_time': q1['time'], 'q1_index': q1['index'], 'q1_line': q1['source_line'],
                'conditional': cond, 'pF': side_prob[2] if side_prob else None, 'pA': side_prob[0] if side_prob else None,
                'pN': side_prob[1] if side_prob else None, 'native': old.one(case[stream]), 'inverse': old.one(case[reverse])})
        policy_rows[policy] = rows
    psets = [{r['case_id'] for r in policy_rows[p]} for p in ('P70', 'P65', 'P60')]
    assert psets[0] <= psets[1] <= psets[2]
    results = {}
    checked = 0
    for part, scope in [('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])]:
        results[part] = {}
        for policy in POLICIES:
            rows = [r for r in policy_rows[policy] if r['session'] in scope]
            total = describe(rows, old)
            actual = total['元方向']
            fixed = summary['集計'][part][policy]['BBO']['3600']['125']
            for a, b in [('件数','entries'), ('F','forward'), ('A','adverse'), ('N','neither'), ('C','censored'),
                ('IFD既知','ifd_known'), ('IFD未知','ifd_unknown'), ('C5利益','ifd_net5_profit'), ('C5損失絶対','ifd_net5_loss'), ('C5差引','ifd_net5_sum')]:
                assert actual[a] == fixed[b], (part, policy, a, actual[a], fixed[b])
                checked += 1
            if policy == 'P70':
                inverse = total['実逆']
                fixed_reverse = summary['集計'][part]['RP70']['BBO']['3600']['125']
                for a, b in [('件数','entries'), ('F','forward'), ('A','adverse'), ('N','neither'), ('C','censored'),
                    ('IFD既知','ifd_known'), ('IFD未知','ifd_unknown'), ('C5差引','ifd_net5_sum')]:
                    assert inverse[a] == fixed_reverse[b], (part, 'RP70', a)
                    checked += 1
            bins = {level: describe([r for r in rows if bucket(r['conditional']) == level], old) for level in LEVELS}
            assert sum(v['元方向']['件数'] for v in bins.values()) == len(rows)
            results[part][policy] = {'全件': total, 'conditional区画': bins, '集中群': group_summary(rows, old)}
    scenes = {p: scene_summary(policy_rows[p], sessions, old) for p in POLICIES}
    model_audit = {'学習場数': sum(a['ready'] for a in audits), '未学習場': [a['session'] for a in audits if not a['ready']],
        '予測理由総数': dict(sum((Counter(a['prediction_reasons']) for a in audits), Counter())),
        '場別': [{k: a[k] for k in ('session_index','session','ready','ready_reasons','physical_pair_count','active_block_count','side_weight_mean','all_current_feature_rows','prediction_reasons')} for a in audits]}
    output = {'成功': True, '試行': 151, '用途': '固定選択後の事後診断。新条件採用なし。',
        '全73場': sessions, '実逆は同q1反対BBO': True, '全期既使用': True,
        '部別政策': results, '場別集中': scenes, '学習監査要約': model_audit,
        '旧正本一致セル': checked, '選択3閾値case包含': True, '個別取引全件転載': False,
        '10月15日Day': {p: scenes[p]['全73場']['2026-10-15_Day'] for p in POLICIES}}
    assert all(sha(p) == h for p, h in sources.items())
    assert before == {str(p): [p.stat().st_size, p.stat().st_mtime_ns] for p in sources}
    target = HERE / '診断.json'
    target.write_text(json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    proof = {'成功': True, '旧固定正本一致セル': checked, '全源前後SHA_stat同体': True,
        '新条件又は学習': False, 'Raw又はCSV又は追加2場': False,
        '源': [{'path': str(p.relative_to(ROOT)).replace('\\','/'), 'sha256': h, 'bytes': before[str(p)][0]} for p, h in sources.items()],
        '診断SHA256': sha(target)}
    (HERE / '診断の確認.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '旧一致セル': checked, '政策': {p: results['all'][p]['全件'] for p in POLICIES},
        'P60確率区画': results['all']['P60']['conditional区画'], '10月15日Day': output['10月15日Day']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
