"""151事後診断と技術追補を照合し編集停止票を作る。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: 診断入力/出力を複写せず指紋化する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    """
    機能: 人工/構文/144正本一致と追補分母の同体を最後に確認する。
    引数: なし。
    返り値: None。自然再集計や新学習を呼ばず排他保存する。
    """
    sources = {}
    for name in ('診断の確認.json', '背景追補の確認.json'):
        p = json.loads((HERE / name).read_bytes())
        assert p['成功'] and p['全源前後SHA_stat同体']
        for row in p['源']:
            path = ROOT / row['path']
            assert path not in sources or sources[path] == row['sha256']
            sources[path] = row['sha256']
    assert all(sha(p) == h for p, h in sources.items())
    own = sorted([*HERE.glob('*.py'), *HERE.glob('*.md')])
    fingerprints = {str(p.relative_to(ROOT)).replace('\\','/'): sha(p) for p in own}
    for path in HERE.glob('*.py'):
        tree = ast.parse(path.read_text(encoding='utf-8'))
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                doc = ast.get_docstring(node)
                assert doc and '\n' in doc and all(k in doc for k in ('機能:', '引数:', '返り値:')), node.name
    env = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1')
    test = subprocess.run([sys.executable, '-X', 'utf8', str(HERE / '人工検査.py')], capture_output=True,
        text=True, encoding='utf-8', errors='strict', env=env)
    assert test.returncode == 0 and '\ufffd' not in test.stdout + test.stderr
    base = json.loads((HERE / '診断.json').read_bytes())
    added = json.loads((HERE / '背景追補.json').read_bytes())
    checked = 0
    for part in ('all', 'train', 'validation'):
        a = base['部別政策'][part]['P70']['全件']
        b = added['部別'][part]['P70全体']['全件']
        for side in ('元方向', '実逆'):
            assert a[side] == b[side]
            checked += len(a[side])
    assert base['旧正本一致セル'] == 144
    p70 = base['部別政策']['all']['P70']['全件']
    assert p70['校正']['予測付き件数'] == 511 and p70['校正']['予測付きF_A既知件数'] == 497
    audit = json.loads((ROOT / 'work/151過去場判別の評価/入口選択/場別モデルと教師.json').read_bytes())['scenes'][36]
    assert audit['session'] == '2026-10-15_Day' and len(audit['model']['used_columns']) == 61
    assert all(sha(ROOT / p) == h for p, h in fingerprints.items())
    proof = {'成功': True, '編集停止': True, '新条件又はモデル又は閾値変更': False,
        'Raw又はCSV又は追加2場読取': False, '全源前後SHA_stat同体': True,
        '人工主数': 4, '構文と複数行型付き関数コメント': True, 'UTF8_strict': True,
        '人工': {'終了値': test.returncode, '標準出力': test.stdout, '標準エラー': test.stderr},
        '旧金融正本一致セル': 144, '主診断と技術追補P70同体セル': checked,
        'model36実分岐1分列': [n for n in audit['model']['used_columns'] if n.startswith('m1_')],
        '源': fingerprints,
        '成果物': {p.name: sha(p) for p in HERE.glob('*.json') if p.name not in ('最終の確認.json', '停止.json')},
        '再現': ['人工検査.py', '診断する.py', '背景を追補する.py', '確認して停止する.py']}
    target = HERE / '最終の確認.json'
    with target.open('x', encoding='utf-8') as f:
        json.dump(proof, f, ensure_ascii=False, indent=2)
        f.write('\n')
    stop = {'成功': True, '編集停止': True, '最終確認SHA256': sha(target), '源': fingerprints,
        '成果物': proof['成果物'], '新学習又は採用なし': True}
    with (HERE / '停止.json').open('x', encoding='utf-8') as f:
        json.dump(stop, f, ensure_ascii=False, indent=2)
        f.write('\n')
    print(json.dumps({'成功': True, '確認SHA256': sha(target), '停止SHA256': sha(HERE / '停止.json')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
