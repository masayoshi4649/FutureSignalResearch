"""151事後診断の区画・重複境界・既知touchを人工で確認する。"""
import importlib.util
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('posthoc151', HERE / '診断する.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class Tests(unittest.TestCase):
    def test_背景4群と既知ゼロ(self):
        """
        機能: 背景の賛成/反対/混在ゼロ/未知を区別する。
        引数: self(Tests)。
        返り値: None。
        """
        s = importlib.util.spec_from_file_location('background151test', HERE / '背景を追補する.py')
        b = importlib.util.module_from_spec(s)
        s.loader.exec_module(b)
        self.assertEqual([b.background(1, 1), b.background(-1, -1), b.background(0, -1),
                          b.background(1, -1), b.background(None, 1)], ['賛成', '反対', '混在ゼロ', '混在ゼロ', '未知'])
        self.assertEqual(b.numbers([None, 0, -1, 2]), {'既知': 3, '未知': 1, '最小': -1,
                         '中央値': 0.0, '最大': 2, '正': 1, '負': 1, 'ゼロ': 1})

    def test_確率区画(self):
        """
        機能: 等号を上側区画へ一意に入れる。
        引数: self(Tests)。
        返り値: None。
        """
        cases = [(None, '未知'), (.59, '閾値未満'), (.6, '[.60,.65)'), (.65, '[.65,.70)'),
                 (.7, '[.70,.80)'), (.8, '[.80,.90)'), (.9, '[.90,1]'), (1., '[.90,1]')]
        for value, want in cases:
            self.assertEqual(m.bucket(value), want)

    def test_名目H60境界とrun(self):
        """
        機能: 半開窓の等号非接続と同方向/モデルの別定義を確認する。
        引数: self(Tests)。
        返り値: None。
        """
        rows = [{'session_index': 0, 'session': '人工', 'q1_time': t, 'q1_index': i, 'q1_line': i,
                 'case_id': str(i), 'side': side, 'model_id': 8}
                for i, (t, side) in enumerate([(0, 1), (60, 1), (3660, -1), (8000, -1)])]
        self.assertEqual([len(x) for x in m.group_rows(rows, 'H60')], [2, 1, 1])
        self.assertEqual([len(x) for x in m.group_rows(rows, 'side')], [2, 2])
        self.assertEqual([len(x) for x in m.group_rows(rows, 'model')], [4])

    def test_不足既知touchと費用(self):
        """
        機能: H不足でもtouch既知のIFDを残しC5を1077円とする。
        引数: self(Tests)。
        返り値: None。
        """
        old = m.module(m.PARENT)
        stream = {'birth': {'side': 1}, 'entry': {'bid': 90, 'ask': 100, 'quote_ok': True}, 'entry_price': 100,
            'outcomes': [{'seconds': 3600, 'status': 'phase_censored',
                'touches': [{'width': 125, 'direction': 1, 'quote': {'bid': 225, 'ask': 235, 'time': 9}}], 'endpoint': None}]}
        got = old.one(stream)
        self.assertEqual(got['state'], 'C')
        self.assertTrue(got['ifd_known'])
        self.assertEqual(got['net5'], 12500 - 1077)


if __name__ == '__main__':
    unittest.main(verbosity=2)
