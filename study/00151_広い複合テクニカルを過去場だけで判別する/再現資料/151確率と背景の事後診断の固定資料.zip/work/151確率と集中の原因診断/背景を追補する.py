"""151固定P70の上位背景と回復列を保存100Xから事後記述する。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import math
import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
spec = importlib.util.spec_from_file_location('diagnose151background', HERE / '診断する.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
CACHE = ROOT / 'work/151過去場判別の評価/入口選択/cache/feature_only'
MATRIX = CACHE / 'features.npz'
META = CACHE / 'features_meta.json'
NAMES = {
    '30EMA21増分pt': 'm30_ema21_delta_to_side',
    '30DI差': 'm30_di_difference_to_side',
    '15ADX水準': 'm15_adx',
    '15DI差': 'm15_di_difference_to_side',
    '5Hist増分pt': 'm5_hist_delta_to_side',
    '5RSI増分指標pt': 'm5_rsi_delta_to_side',
    'q0実側BB15σ位置': 'q0_entry_minus_bbmean_sigma_to_side',
    'q0実側先行3足域percent': 'q0_entry_prior3_percent_to_side',
    'q0Last先行3足順端差ATR5': 'q0_last_minus_prior3_forward_edge_atr5_to_side',
    'r順実体比': 'm1_body_ratio_to_side',
    'rClose対pOpen回復ATR5': 'm1_body_reclaim_atr5_to_side',
    'q0Last対rClose差ATR5': 'q0_last_minus_m1_close_atr5_to_side',
}
LEVELS = ('賛成', '反対', '混在ゼロ', '未知')


def background(ema: float | None, di: float | None) -> str:
    """
    機能: 選択側の30分実増分とDI差を固定4群へ分類する。
    引数: ema/di(float|None)。
    返り値: strは賛成/反対/混在ゼロ/未知。
    """
    if ema is None or di is None:
        return '未知'
    if ema > 0 and di > 0:
        return '賛成'
    if ema < 0 and di < 0:
        return '反対'
    return '混在ゼロ'


def numbers(values: list) -> dict:
    """
    機能: 新閾値を探さず有限実数の範囲と符号だけを示す。
    引数: values(list[float|None])。
    返り値: dictは既知/未知/最小/中央値/最大/正負ゼロ件数。
    """
    known = [v for v in values if v is not None]
    return {'既知': len(known), '未知': len(values) - len(known), '最小': min(known) if known else None,
        '中央値': float(np.median(known)) if known else None, '最大': max(known) if known else None,
        '正': sum(v > 0 for v in known), '負': sum(v < 0 for v in known), 'ゼロ': sum(v == 0 for v in known)}


def summarize(rows: list, old: object) -> dict:
    """
    機能: 群の実BBO正逆と当時値の分布を同じ選択側でまとめる。
    引数: rows(list[dict])、old(object)は固定保存quote算術。
    返り値: dictは全件転載しない小型票。
    """
    out = old.paired(rows)
    keys = [*NAMES, 'q0Last対pOpen生存回復ATR5']
    out['選択side件数'] = {str(side): sum(r['side'] == side for r in rows) for side in (-1, 1)}
    out['当時値分布'] = {key: numbers([r['values'][key] for r in rows]) for key in keys}
    out['両動力改善'] = sum(r['values']['5Hist増分pt'] is not None and r['values']['5RSI増分指標pt'] is not None
        and r['values']['5Hist増分pt'] > 0 and r['values']['5RSI増分指標pt'] > 0 for r in rows)
    out['r実体かつq0生存回復が正'] = sum(r['values']['r順実体比'] is not None
        and r['values']['q0Last対pOpen生存回復ATR5'] is not None and r['values']['r順実体比'] > 0
        and r['values']['q0Last対pOpen生存回復ATR5'] > 0 for r in rows)
    return out


def main() -> None:
    """
    機能: 固定P70だけの100X/保存実逆から技術背景追補を排他保存する。
    引数: なし。
    返り値: None。自然Raw/新選択/新学習を呼ばない。
    """
    expected = {m.SELECTION: m.EXPECTED[m.SELECTION], m.OBS: m.EXPECTED[m.OBS], m.PARENT: m.EXPECTED[m.PARENT],
        MATRIX: '5b309e0821403fcf1b122956fc6c9fe20ec5dfbe4327d7d674193b8e58f99b44',
        META: '71df54db57a3093eb4de2f5ce26c654c758f9181e07f61660cb1a192f6fa4602'}
    for path in (Path(__file__), HERE / '10月15日背景の追補範囲.md', HERE / '診断する.py'):
        expected[path] = m.sha(path)
    assert all(m.sha(p) == h for p, h in expected.items())
    before = {str(p): [p.stat().st_size, p.stat().st_mtime_ns] for p in expected}
    selection = json.loads(m.SELECTION.read_bytes())
    meta = json.loads(META.read_bytes())
    assert meta['success'] and meta['trial'] == 151 and meta['label_fields_present'] is False
    event_index = {r['event_id']: (i, r) for i, r in enumerate(meta['q0_meta'])}
    assert len(event_index) == 35339
    old = m.module(m.PARENT)
    choices = {r['case_id']: r for r in selection['政策']['P70']}
    rows = []
    with np.load(MATRIX, allow_pickle=False) as archive:
        columns = archive['columns'].tolist()
        assert len(columns) == len(set(columns)) == 100 and columns == sorted(columns)
        indices = {key: columns.index(name) for key, name in NAMES.items()}
        buy, sell = archive['buy_X'], archive['sell_X']
        assert buy.shape == sell.shape == (35339, 100)
        for scene in old.array_items(m.OBS, 'scenes'):
            for case in scene['cases']:
                if case['id'] not in choices:
                    continue
                choice = choices[case['id']]
                i, q0 = event_index[choice['event_id']]
                assert q0['session'] == choice['session'] == scene['session']
                assert (q0['q0_time'], q0['q0_index'], q0['q0_line']) == (choice['q0_time'], choice['q0_index'], choice['q0_line'])
                x = buy[i] if choice['side'] == 1 else sell[i]
                values = {key: float(x[n]) if math.isfinite(x[n]) else None for key, n in indices.items()}
                a, b = values['rClose対pOpen回復ATR5'], values['q0Last対rClose差ATR5']
                values['q0Last対pOpen生存回復ATR5'] = a + b if a is not None and b is not None else None
                stream = choice['stream']
                reverse = 'reverse' if stream == 'original' else 'original'
                assert case[stream]['birth']['side'] == choice['side'] and case[reverse]['entry'] == case[stream]['entry']
                rows.append({'session': choice['session'], 'side': choice['side'], 'values': values,
                    '30背景': background(values['30EMA21増分pt'], values['30DI差']),
                    'native': old.one(case[stream]), 'inverse': old.one(case[reverse])})
    assert len(rows) == len(choices) == 511
    results = {}
    sessions = selection['全73場']
    for part, scope in [('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])]:
        results[part] = {}
        for name, selected in [('P70全体', [r for r in rows if r['session'] in scope]),
            ('10月15日Day', [r for r in rows if r['session'] == '2026-10-15_Day' and r['session'] in scope]),
            ('その他の場', [r for r in rows if r['session'] != '2026-10-15_Day' and r['session'] in scope])]:
            bins = {level: summarize([r for r in selected if r['30背景'] == level], old) for level in LEVELS}
            assert sum(v['元方向']['件数'] for v in bins.values()) == len(selected)
            results[part][name] = {'全件': summarize(selected, old), '30背景': bins}
    assert all(m.sha(p) == h for p, h in expected.items())
    assert before == {str(p): [p.stat().st_size, p.stat().st_mtime_ns] for p in expected}
    output = {'成功': True, '試行': 151, '用途': '固定P70の事後技術背景。新条件採用なし。',
        '前足端の意味': '100列にあるr除外先行3本域/順端。前1本の高安列を新復元していない。',
        '選択側分類を実逆へ付替えない': True, '100列又は選択の変更': False, '部別': results,
        '限界': ['場分類とmodel_idは交絡する', 'r実体/生存回復列の符号は時系列episodeを証明しない',
            '既知複数役割は上位方向/構造回復hardgateではない', '長い高安/VWAPの追加効果は未比較']}
    target = HERE / '背景追補.json'
    with target.open('x', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write('\n')
    proof = {'成功': True, '全源前後SHA_stat同体': True, '新学習又は新選択': False, 'Raw又はCSV又は追加2場': False,
        '源': [{'path': str(p.relative_to(ROOT)).replace('\\','/'), 'sha256': h} for p, h in expected.items()], '出力SHA256': m.sha(target)}
    (HERE / '背景追補の確認.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(results['all'], ensure_ascii=False))


if __name__ == '__main__':
    main()
