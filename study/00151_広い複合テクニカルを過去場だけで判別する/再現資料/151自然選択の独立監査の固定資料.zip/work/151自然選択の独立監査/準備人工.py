"""151自然監査器の小人工だけを確認する。自然出力はF1通知まで開かない。"""
from pathlib import Path
import hashlib
import importlib.util
import io
import json
import math
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('自然監査の準備対象', HERE / '監査する.py')
audit = importlib.util.module_from_spec(spec); spec.loader.exec_module(audit)


def row(case: str, index: int, session: int, clock: int) -> dict:
    """
    機能: 独立oracle用の教師メタデータを作る。
    引数: case(str)、index/session/clock(int)。返り値: dict。
    """
    return {'case_id': case, 'event_id': case + str(index), 'q0_index': index, 'q0_line': index + 10,
            'session_index': session, 'q0_time': clock, 'known_at': clock + 100,
            'pair_complete': True, 'label_buy': -1, 'label_sell': 1}


class PreparationTests(unittest.TestCase):
    """本番監査を誤って起動しない小型純oracle人工。"""

    def test_01_past_window_canonical_and_weights(self) -> None:
        """
        機能: 20窓・厳密成熟・canonical・区画質量の独立計算を手計算へ照合する。
        引数: self(PreparationTests)。返り値: None。
        """
        starts = [100000 * i for i in range(23)]
        rows = [row('a', 1, 1, 100060), row('b', 2, 1, 100120), row('c', 3, 1, 100180),
                row('d', 4, 1, 103600), row('e', 5, 2, 200060), row('a', 50, 1, 103660),
                row('old', 6, 0, 60), row('equal', 7, 20, 2000060), row('future', 8, 21, 2100060)]
        rows[1]['label_buy'] = 0; rows[-2]['known_at'] = starts[21]
        rows[-1]['label_buy'] = object()
        result = audit.past_oracle(rows, starts, 21)
        self.assertEqual(result['indices'], [0, 1, 2, 3, 4])
        self.assertEqual(result['physical_pair_count'], 5); self.assertEqual(result['active_block_count'], 3)
        self.assertEqual(result['classes'], [-1, 0, 1]); self.assertFalse(result['ready'])
        self.assertEqual(result['window']['first_session_index'], 1)
        self.assertTrue(math.isclose(sum(result['weights']), 5))

    def test_02_json_mapping_and_decision_roles(self) -> None:
        """
        機能: split内部番号・finite役割・固定閾値と未学習を人工で照合する。
        引数: self(PreparationTests)。返り値: None。
        """
        columns = [{'name': f'x{i}', 'role': '構造'} for i in range(100)]
        columns[0] = {'name': 'direction', 'role': '方向'}; columns[1] = {'name': 'volume', 'role': '量'}
        columns[2] = {'name': 'q0_spread_points', 'role': '値幅'}
        columns[3] = {'name': 'q0_last_minus_m1_close_atr5_to_side', 'role': '構造'}
        vector = [math.nan] * 100; vector[:4] = [1, 1, 10, 0]
        exported = {'features_info': {'float_features': [{'feature_index': 7, 'flat_feature_index': 1, 'feature_id': 'volume'}]},
                    'oblivious_trees': [{'splits': [{'split_type': 'FloatFeature', 'float_feature_index': 7}]}]}
        self.assertEqual(audit.split_oracle(exported, columns), [1])
        selected = audit.decide_oracle(vector, vector, [.3, 0, .7], [.4, .2, .4], columns, [0, 1, 2])
        self.assertEqual(selected['directions'], {'P70': 1, 'P65': 1, 'P60': 1})
        self.assertEqual(selected['known_roles'], ['方向', '量'])
        unknown = audit.decide_oracle(vector, vector, None, None, columns, [])
        self.assertEqual(unknown['reason'], 'untrained')

    def test_03_policy_primary_and_legacy(self) -> None:
        """
        機能: P70だけの主OR・最初q0・C1優先・感度統合の全行を確認する。
        引数: self(PreparationTests)。返り値: None。
        """
        sessions = ['A', 'B']; decisions, captures = [], []
        cases = [{'case_id': f'old{i}', 'session': sessions[i % 2], 'contract': 'K', 'original_side': -1, 'c1_reused': True} for i in range(87)]
        cases.append({'case_id': 'new', 'session': 'A', 'contract': 'K', 'original_side': 1, 'c1_reused': False})
        for event, index, cid, values in [('early', 10, 'new', (0, 1, 1)), ('later', 20, 'new', (-1, -1, -1)), ('old', 30, 'old0', (1, 1, 1))]:
            directions = dict(zip(('P70', 'P65', 'P60'), values)); directions['N70'] = values[0]
            evidence = [{'rule': name, 'order_side': side, 'signal_side': side, 'roles': ['方向', '量'], 'model_id': 8}
                        for name, side in zip(('P70', 'P65', 'P60'), values) if side]
            decisions.append({'event_id': event, 'session': 'A', 'contract': 'K', 'q0_time': index + 1000, 'q0_index': index, 'q0_line': index + 100,
                              'decision': {'directions': directions, 'conflicts': {name: False for name in directions}, 'evidence': evidence}})
            captures.append({'event_id': event, 'session': 'A', 'contract': 'K', 'q0': {'time': index + 1000, 'index': index, 'source_line': index + 100},
                             'case_id': cid, 'status': 'filled', 'buy_stream': 'reverse' if cid.startswith('old') else 'original',
                             'sell_stream': 'original' if cid.startswith('old') else 'reverse'})
        result = audit.policy_oracle(decisions, {'rows': captures}, {'population148': {'cases': cases}}, sessions)
        main = next(r for r in result['政策']['N70'] if r['case_id'] == 'new')
        self.assertEqual((main['event_id'], main['成立ID']), ('later', ['P70']))
        for name in ('U70', 'U65', 'U60'):
            self.assertEqual(len(result['政策'][name]), 88)
            self.assertEqual(next(r for r in result['政策'][name] if r['case_id'] == 'old0')['side'], -1)


def main() -> None:
    """
    機能: 小人工と構文を確認し自然未実行の準備票を保存する。
    引数: なし。返り値: None。自然main/モデルfit/金融は起動しない。
    """
    compile((HERE / '監査する.py').read_text(encoding='utf-8'), '監査する.py', 'exec')
    log = io.StringIO()
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(PreparationTests))
    path = HERE / '準備人工のログ.txt'; path.write_text(log.getvalue(), encoding='utf-8')
    assert result.wasSuccessful(), log.getvalue()
    proof = {'成功': True, '状態': '自然F1後監査コードの人工準備', '人工主群': result.testsRun,
             '自然出力/教師/価格/モデル/金融/Raw/追加2場読取': False,
             '自然監査main実行': False, 'Root/source/teacher/model/selector関数import': False,
             '監査SourceSHA256': hashlib.sha256((HERE / '監査する.py').read_bytes()).hexdigest(),
             '人工SourceSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
             'ログSHA256': hashlib.sha256(path.read_bytes()).hexdigest()}
    output = HERE / '準備の確認.json'; output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '人工': result.testsRun,
                      '準備SHA256': hashlib.sha256(output.read_bytes()).hexdigest()}, ensure_ascii=False))


if __name__ == '__main__':
    main()
