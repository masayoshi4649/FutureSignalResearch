"""F1後だけ151の教師選択・保存モデル再推論・政策所属を独立に照合する。再学習しない。"""
from pathlib import Path
from collections import Counter
import argparse
import gzip
import hashlib
import json
import math

import numpy as np
from catboost import CatBoostClassifier, Pool

ROOT = Path(__file__).resolve().parents[2]
EXCLUDED = {'q0_spread_points', 'q0_spread_125_ratio', 'q0_entry_minus_last_atr5_to_side'}
THRESHOLDS = {'P70': .7, 'P65': .65, 'P60': .6}
NAMES = ('P70', 'P65', 'P60', 'N70')


def digest(path: Path) -> str:
    """
    機能: 大型cacheも複写せず物理SHAを取得する。
    引数: path(Path)。返り値: str。
    """
    h = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(4 << 20), b''): h.update(chunk)
    return h.hexdigest()


def read_json(path: Path, decoded: str | None = None) -> dict:
    """
    機能: JSON/gzipをCRC終端まで読み必要時は解凍SHAを検査する。
    引数: path(Path)、decoded(str|None)。返り値: dict。
    """
    with (gzip.open(path, 'rb') if path.suffix == '.gz' else path.open('rb')) as source: raw = source.read()
    if decoded is not None: assert hashlib.sha256(raw).hexdigest() == decoded
    return json.loads(raw)


def resolve(path: str | Path) -> Path:
    """
    機能: repo相対と絶対の参照を同じ絶対Pathへ写す。
    引数: path(str|Path)。返り値: Path。
    """
    value = Path(path)
    return (value if value.is_absolute() else ROOT / value).resolve()


def compare(expected, actual, label: str = '') -> int:
    """
    機能: 全キー・順序・分類を比較し、再推論floatだけ微小丸めを許容する。
    引数: expected/actual(JSON値)、label(str)。返り値: intは末端比較数。
    """
    if isinstance(expected, dict):
        assert expected.keys() == actual.keys(), (label, expected.keys(), actual.keys())
        return sum(compare(v, actual[k], label + '/' + str(k)) for k, v in expected.items())
    if isinstance(expected, list):
        assert len(expected) == len(actual), label
        return sum(compare(a, b, label + '/' + str(i)) for i, (a, b) in enumerate(zip(expected, actual)))
    if isinstance(expected, float):
        assert actual is not None and math.isclose(expected, actual, rel_tol=1e-12, abs_tol=1e-12), (label, expected, actual)
    else: assert expected == actual, (label, expected, actual)
    return 1


def past_oracle(rows: list[dict], starts: list[int], current: int) -> dict:
    """
    機能: 作者teacherを使わず成熟窓・canonical・区画密度を再構成する。
    引数: rows(list[dict])、starts(list[int])、current(int)。返り値: dict。
    """
    lower = max(0, current - 20); candidates = []
    for source_index, row in enumerate(rows):
        if not lower <= row['session_index'] < current: continue
        if row['pair_complete'] is not True: continue
        known = row['known_at']
        if type(known) not in (int, float) or not math.isfinite(known) or known >= starts[current]: continue
        if any(type(row[k]) is not int or row[k] not in (-1, 0, 1) for k in ('label_buy', 'label_sell')): continue
        assert math.isfinite(row['q0_time']) and row['q0_time'] <= known
        candidates.append((source_index, row))
    grouped = {}
    for source_index, row in candidates:
        key = row['case_id']; rank = (row['q0_index'], row['q0_line'], row['event_id'])
        if key in grouped:
            prior = grouped[key]
            assert prior[2]['session_index'] == row['session_index']
            if prior[0] == rank: assert prior[2] == row
        if key not in grouped or rank < grouped[key][0]: grouped[key] = (rank, source_index, row)
    chosen = sorted(grouped.values(), key=lambda r: (r[2]['session_index'], *r[0]))
    indices = [r[1] for r in chosen]; rows = [r[2] for r in chosen]
    blocks = Counter((r['session_index'], math.floor((r['q0_time'] - starts[r['session_index']]) / 3600)) for r in rows)
    assert all(r['q0_time'] >= starts[r['session_index']] for r in rows)
    n = len(rows); b = len(blocks); sessions = sorted({r['session_index'] for r in rows})
    classes = sorted({r[k] for r in rows for k in ('label_buy', 'label_sell')})
    weight = [n / (b * blocks[(r['session_index'], math.floor((r['q0_time'] - starts[r['session_index']]) / 3600))]) for r in rows]
    reasons = ([] if n >= 1000 else ['physical_pairs_under_1000']) + ([] if len(sessions) >= 8 else ['contributing_sessions_under_8']) + ([] if classes == [-1, 0, 1] else ['three_classes_not_present'])
    block_rows = [{'session_index': s, 'block_index': block, 'physical_pairs': count,
                   'side_weight': n / (b * count)} for (s, block), count in sorted(blocks.items())]
    mass_parts = {key: [] for key in blocks}
    for r, w in zip(rows, weight):
        key = (r['session_index'], math.floor((r['q0_time'] - starts[r['session_index']]) / 3600))
        mass_parts[key].append(2 * w)
    assert all(math.isclose(math.fsum(parts), 2 * n / b, rel_tol=1e-12) for parts in mass_parts.values())
    return {'ready': not reasons, 'ready_reasons': reasons, 'indices': indices, 'rows': rows, 'weights': weight,
            'window': {'first_session_index': lower, 'last_session_index': current - 1, 'calendar_session_count': current - lower, 'limit': 20},
            'physical_pair_count': n, 'contributing_sessions': sessions, 'classes': classes,
            'active_block_count': b, 'blocks': block_rows,
            'side_weight_mean': math.fsum(weight) / n if n else None}


def split_oracle(exported: dict, columns: list[dict]) -> list[int]:
    """
    機能: public JSONの実splitを内部番号から100入力列へ別対応させる。
    引数: exported(dict)、columns(list[dict])。返り値: list[int]。
    """
    mapping = {f['feature_index']: (f['flat_feature_index'], f['feature_id']) for f in exported['features_info']['float_features']}
    used = set()
    for tree in exported['oblivious_trees']:
        for split in tree.get('splits') or []:
            assert split['split_type'] == 'FloatFeature'
            flat, name = mapping[split['float_feature_index']]
            assert columns[flat]['name'] == name; used.add(flat)
    return sorted(used)


def decide_oracle(buy: list, sell: list, bp, sp, columns: list[dict], used: list[int]) -> dict:
    """
    機能: 保存確率と当時有限列から固定選択を別計算する。
    引数: buy/sell(list)、bp/sp(list|None)、columns(list[dict])、used(list[int])。返り値: dict。
    """
    result = {'directions': {k: 0 for k in THRESHOLDS}, 'probabilities': None, 'scores': None,
              'selected_side': 0, 'known_roles': [], 'reason': 'untrained'}
    if bp is None or sp is None:
        assert bp is None and sp is None
        return result
    a, b = bp[2] - bp[0], sp[2] - sp[0]
    result.update(probabilities={'buy': bp, 'sell': sp}, scores={'buy': a, 'sell': b})
    if a - b >= .05: side, vector, p = 1, buy, bp
    elif b - a >= .05: side, vector, p = -1, sell, sp
    else: result['reason'] = 'score_margin_under_0.05'; return result
    result['selected_side'] = side
    names = {c['name']: i for i, c in enumerate(columns)}
    spread, gap = vector[names['q0_spread_points']], vector[names['q0_last_minus_m1_close_atr5_to_side']]
    if not math.isfinite(float(spread)) or not math.isfinite(float(gap)) or not (0 < spread <= 20 and -1 <= gap <= 1):
        result['reason'] = 'q0_common_not_met'; return result
    roles = sorted({columns[i]['role'] for i in used if columns[i]['name'] not in EXCLUDED and math.isfinite(float(vector[i]))})
    result['known_roles'] = roles
    if len(roles) < 2: result['reason'] = 'known_technical_roles_under_2'; return result
    conditional = p[2] / (p[0] + p[2]) if p[0] + p[2] > 0 else None
    result['conditional_forward'] = conditional
    if p[2] < .4: result['reason'] = 'forward_probability_under_0.40'; return result
    result['reason'] = 'threshold_wait'
    for name, cutoff in THRESHOLDS.items():
        if conditional is not None and conditional >= cutoff: result['directions'][name] = side; result['reason'] = 'selected'
    return result


def policy_oracle(decisions: list, captures: dict, metadata: dict, sessions: list[str]) -> dict:
    """
    機能: 全判断完成後にq1 canonicalとP70主/C1優先/感度統合を別構成する。
    引数: decisions(list)、captures/metadata(dict)、sessions(list[str])。返り値: dict。
    """
    caps = {r['event_id']: r for r in captures['rows']}; cases = {r['case_id']: r for r in metadata['population148']['cases']}
    assert len(caps) == len(captures['rows']) == len(decisions)
    assert set(caps) == {r['event_id'] for r in decisions}
    order = {s: i for i, s in enumerate(sessions)}
    selected = {p: {} for p in NAMES}; counts = {p: Counter() for p in NAMES}
    for decision in sorted(decisions, key=lambda r: (order[r['session']], r['q0_index'], r['q0_line'], r['event_id'])):
        acq = caps[decision['event_id']]
        assert (acq['session'], acq['contract']) == (decision['session'], decision['contract'])
        assert tuple(acq['q0'][k] for k in ('time', 'index', 'source_line')) == tuple(decision[k] for k in ('q0_time', 'q0_index', 'q0_line'))
        for name in NAMES:
            if decision['decision']['conflicts'][name]: counts[name]['conflict_wait'] += 1
            side = decision['decision']['directions'][name]
            if not side: continue
            counts[name]['born'] += 1; counts[name][acq['status']] += 1
            if acq['status'] != 'filled': continue
            cid = acq['case_id']; descriptor = cases[cid]
            if cid in selected[name]: counts[name]['duplicate_q1'] += 1; continue
            assert (descriptor['session'], descriptor['contract']) == (decision['session'], decision['contract'])
            stream = 'original' if side == descriptor['original_side'] else 'reverse'
            assert stream == acq['buy_stream' if side == 1 else 'sell_stream']
            wanted = 'P70' if name == 'N70' else name
            evidence = [e for e in decision['decision']['evidence'] if e['order_side'] == side and e['rule'] == wanted]
            assert evidence
            selected[name][cid] = {'case_id': cid, 'session': decision['session'], 'side': side, 'stream': stream,
                'event_id': decision['event_id'], 'feature_ref': decision['event_id'],
                **{k: decision[k] for k in ('q0_time', 'q0_index', 'q0_line')},
                '成立ID': sorted({e['rule'] for e in evidence}), 'evidence': evidence, 'origin': name}
    legacy = {cid: {'case_id': cid, 'session': d['session'], 'side': d['original_side'], 'stream': 'original',
                   'event_id': None, 'feature_ref': None, 'origin': 'C1'} for cid, d in cases.items() if d['c1_reused']}
    assert len(legacy) == 87
    policies = {p: list(rows.values()) for p, rows in selected.items()}; policies['C1'] = list(legacy.values())
    overlaps = {}
    for union, new in (('U70', 'N70'), ('U65', 'P65'), ('U60', 'P60')):
        merged = legacy.copy(); overlaps[union] = []
        for cid, row in selected[new].items():
            if cid in merged:
                overlaps[union].append({'case_id': cid, 'legacy_side': merged[cid]['side'], 'new_side': row['side'], 'opposite': merged[cid]['side'] != row['side']})
            else: merged[cid] = row
        policies[union] = list(merged.values())
    return {'政策': policies, '候補と取得': {p: dict(c) for p, c in counts.items()}, '全73場': sessions,
            '選択時の金融ラベル利用': False, '旧C1重複': overlaps}


def main() -> None:
    """
    機能: Root F1通知後の明示SHAを要求し自然監査のみ行う。
    引数: CLI run-dir/book/f0/f0-sha256/f1/f1-sha256/cache-reference/cache-reference-sha256/output-dir。
    返り値: None。保存モデル再推論を行うが再学習・金融計算・Raw走査はしない。
    """
    parser = argparse.ArgumentParser()
    for name in ('run-dir', 'book', 'f0', 'f1', 'cache-reference', 'output-dir'): parser.add_argument('--' + name, type=Path, required=True)
    for name in ('f0-sha256', 'f1-sha256', 'cache-reference-sha256'): parser.add_argument('--' + name, required=True)
    args = parser.parse_args(); assert not args.output_dir.exists()
    assert digest(args.f0) == args.f0_sha256 and digest(args.f1) == args.f1_sha256
    f0, f1 = read_json(args.f0), read_json(args.f1)
    assert f0['成功'] and f1['成功'] and f0['試行'] == f1['試行'] == 151
    assert f1['段階'] == 'F1' and f1['前段階SHA256'] == args.f0_sha256
    manifests = [{resolve(k): v for k, v in f['ファイル'].items()} for f in (f0, f1)]
    assert digest(args.cache_reference) == args.cache_reference_sha256
    reference = read_json(args.cache_reference)
    assert reference['成功'] and reference['試行'] == 151
    assert reference['F0_SHA256'] == args.f0_sha256 and reference['F1_SHA256'] == args.f1_sha256
    assert reference['F1事前固定の対象だったと主張する'] is False
    cache_manifest = {resolve(k): v for k, v in reference['ファイル'].items()}
    tracked = {args.cache_reference.resolve(): (args.cache_reference_sha256, args.cache_reference.stat().st_size, args.cache_reference.stat().st_mtime_ns)}
    def track(path: Path, both: bool = False) -> None:
        """
        機能: F1又はF0/F1の指定入力を検査し前後追跡へ登録する。
        引数: path(Path)、both(bool)。返り値: None。
        """
        path = path.resolve(); h = digest(path)
        if path in cache_manifest:
            assert not both and cache_manifest[path] == h
        else:
            assert manifests[1][path] == h
            if both: assert manifests[0][path] == h
        tracked[path] = (h, path.stat().st_size, path.stat().st_mtime_ns)
    track(args.book, True); book = read_json(args.book)
    root = args.run_dir
    feature_files = [root / 'cache/feature_only/features.npz', root / 'cache/feature_only/features_meta.json']
    teacher_files = [root / 'cache/teacher_only/teachers.npz', root / 'cache/teacher_only/teachers_meta.json']
    assert set(cache_manifest) == {p.resolve() for p in feature_files + teacher_files}
    assert reference['共有入力の由来'] == book['inputs']
    for p in feature_files + teacher_files + [root / 'q0の判断.json', root / '場別モデルと教師.json', root / '選択対応.json', root / '選択の確認.json']: track(p)
    fm, tm = read_json(feature_files[1]), read_json(teacher_files[1])
    with np.load(feature_files[0], allow_pickle=False) as cache:
        assert set(cache.files) == {'buy_X', 'sell_X', 'columns'}
        buy, sell, names = cache['buy_X'], cache['sell_X'], cache['columns'].tolist()
    with np.load(teacher_files[0], allow_pickle=False) as cache:
        assert set(cache.files) == {'labels', 'pair_complete', 'known_at', 'event_to_teacher_index', 'canonical_feature_index', 'side_order'}
        labels, complete, known, links, canonical = [cache[k] for k in ('labels', 'pair_complete', 'known_at', 'event_to_teacher_index', 'canonical_feature_index')]
        assert cache['side_order'].tolist() == [1, -1]
    columns_path = ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json'
    assert digest(columns_path) == book['catalog_definition_sha256']; columns = read_json(columns_path)
    assert names == [c['name'] for c in columns] and len(names) == 100
    q0s, scenes, teachers = fm['q0_meta'], fm['scenes'], tm['rows']
    assert len({r['case_id'] for r in teachers}) == len(teachers)
    assert all(set(q) == {'event_id', 'session', 'contract', 'session_index', 'q0_time', 'q0_index', 'q0_line'} for q in q0s)
    assert buy.shape == sell.shape == (35339, 100) and not np.isinf(buy).any() and not np.isinf(sell).any()
    assert fm['label_fields_present'] is False and len(scenes) == 73 and len(q0s) == len(links) == 35339
    starts = [int(s['start']) for s in scenes]
    assert all(v == s['start'] for v, s in zip(starts, scenes))
    assert labels.shape == (len(teachers), 2) and len(known) == len(complete) == len(canonical) == len(teachers)
    seen_aliases = set()
    for i, row in enumerate(teachers):
        assert row['pair_complete'] == bool(complete[i])
        assert row['feature_index'] == int(canonical[i])
        assert row['event_id'] == q0s[row['feature_index']]['event_id']
        aliases = row['alias_feature_indices']
        assert row['aliases'] == [q0s[x]['event_id'] for x in aliases]
        assert aliases == sorted(aliases, key=lambda x: (q0s[x]['q0_index'], q0s[x]['q0_line'], q0s[x]['event_id']))
        assert row['feature_index'] == aliases[0]
        for a in aliases:
            assert a not in seen_aliases and int(links[a]) == i; seen_aliases.add(a)
        if row['pair_complete']:
            assert labels[i].tolist() == [row['label_buy'], row['label_sell']] and known[i] == row['known_at']
        else: assert np.isnan(labels[i]).all() and np.isnan(known[i]) and row['known_at'] is None
    assert seen_aliases == {i for i, value in enumerate(links) if value >= 0}
    actual_decisions = read_json(root / 'q0の判断.json'); actual_audits = read_json(root / '場別モデルと教師.json')
    assert len(actual_decisions['rows']) == 35339 and len(actual_audits['scenes']) == 73
    decisions = []; comparison_cells = 0; trained = 0; scene_reports = []
    for current, scene in enumerate(scenes):
        expected = past_oracle(teachers, starts, current); actual = actual_audits['scenes'][current]
        for key in ('ready', 'ready_reasons', 'window', 'physical_pair_count', 'contributing_sessions', 'classes', 'active_block_count', 'blocks', 'side_weight_mean'):
            comparison_cells += compare(expected[key], actual[key], f'場{current}/{key}')
        assert actual['training_source_indices'] == expected['indices']
        assert actual['max_label_known_at'] == max((r['known_at'] for r in expected['rows']), default=None)
        active = [i for i, q in enumerate(q0s) if q['session_index'] == current]
        assert actual['all_current_feature_rows'] == len(active)
        probabilities = None; used = []; ref = actual['model']
        if expected['ready']:
            trained += 1; assert ref is not None
            fi = [r['feature_index'] for r in expected['rows']]
            assert actual['training_feature_indices'] == fi
            matrix = np.empty((2 * len(fi), 100), dtype='<f8'); matrix[0::2] = buy[fi]; matrix[1::2] = sell[fi]
            y = np.array([r[k] + 1 for r in expected['rows'] for k in ('label_buy', 'label_sell')], dtype='<i8')
            mass = np.repeat(np.array(expected['weights'], dtype='<f8'), 2)
            signature = hashlib.sha256(json.dumps(names, ensure_ascii=False, separators=(',', ':')).encode('utf-8'))
            for array in (matrix, y, mass): signature.update(str(array.shape).encode('ascii')); signature.update(array.tobytes())
            assert signature.hexdigest() == ref['training_array_sha256']
            assert ref['parameters'] == book['classifier_parameters'] and ref['classes'] == [0, 1, 2]
            path = root / 'models' / ref['model_file']; track(path)
            assert digest(path) == ref['physical_sha256']
            exported = read_json(path); used = split_oracle(exported, columns)
            assert used == ref['used_indices'] and [names[i] for i in used] == ref['used_columns']
            stable = {k: exported[k] for k in ('features_info', 'oblivious_trees', 'scale_and_bias')}
            assert hashlib.sha256(json.dumps(stable, sort_keys=True, separators=(',', ':')).encode()).hexdigest() == ref['structure_sha256']
            saved_model = CatBoostClassifier(); saved_model.load_model(str(path), format='json')
            classes = saved_model.classes_.tolist(); assert sorted(classes) == [0, 1, 2]
            if active:
                data = np.concatenate((buy[active], sell[active]))
                probabilities = np.asarray(saved_model.predict_proba(Pool(data, feature_names=names), thread_count=1))[:, [classes.index(k) for k in (0, 1, 2)]]
        else:
            assert ref is None and actual['training_feature_indices'] == []
        reasons = Counter()
        for offset, i in enumerate(active):
            bp = probabilities[offset].tolist() if probabilities is not None else None
            sp = probabilities[len(active) + offset].tolist() if probabilities is not None else None
            vote = decide_oracle(buy[i].tolist(), sell[i].tolist(), bp, sp, columns, used)
            directions = dict(vote['directions']); directions['N70'] = directions['P70']
            evidence = [{'rule': name, 'signal_side': side, 'order_side': side, 'roles': vote['known_roles'].copy(), 'model_id': current}
                        for name, side in vote['directions'].items() if side]
            row = {**q0s[i], 'model_id': current if expected['ready'] else None, 'prediction': vote,
                   'decision': {'directions': directions, 'conflicts': {k: False for k in directions}, 'evidence': evidence}}
            comparison_cells += compare(row, actual_decisions['rows'][i], f'q0/{i}')
            decisions.append(row); reasons[vote['reason']] += 1
        assert dict(reasons) == actual['prediction_reasons']
        scene_reports.append({'session_index': current, 'ready': expected['ready'], 'physical_pairs': expected['physical_pair_count'],
                              'blocks': expected['active_block_count'], 'q0': len(active), 'prediction_reasons': dict(reasons)})
    assert [r['event_id'] for r in decisions] == [r['event_id'] for r in q0s]
    # ----------------------------------------
    # 全判断の再構成が完了後にだけ、取得と旧C1未来表を結ぶ。
    refs = {}
    for key in ('captures', 'metadata'):
        ref = book['inputs'][key]; path = resolve(ref['path']); track(path, True)
        assert digest(path) == ref['sha256']; refs[key] = read_json(path, ref['decoded_sha256'])
    sessions = [s['session'] for s in scenes]
    expected_selection = policy_oracle(decisions, refs['captures'], refs['metadata'], sessions)
    actual_selection = read_json(root / '選択対応.json')
    for key, value in expected_selection.items(): comparison_cells += compare(value, actual_selection[key], key)
    confirmation = read_json(root / '選択の確認.json')
    counts = {p: len(rows) for p, rows in expected_selection['政策'].items()}
    assert counts == confirmation['政策別取得数'] and confirmation['モデル数'] == trained
    assert all((digest(path), path.stat().st_size, path.stat().st_mtime_ns) == before for path, before in tracked.items())
    assert digest(args.f0) == args.f0_sha256 and digest(args.f1) == args.f1_sha256
    args.output_dir.mkdir(parents=True)
    proof = {'成功': True, '編集停止': True, '試行': 151, 'F0_SHA256': args.f0_sha256, 'F1_SHA256': args.f1_sha256,
             'cache後発参照SHA256': args.cache_reference_sha256, 'cacheがF1事前固定対象だった主張': False,
             '全q0': len(decisions), '保存JSON再推論モデル数': trained, '全比較末端値': comparison_cells,
             '教師窓/成熟/1000/8/三class/区画質量/学習署名を別再構成': True,
             '全q0保存再推論/実split/finite役割/固定選択/同原行政策所属一致': True,
             '政策別取得': counts, '場別要約': scene_reports,
             'Source/teacher/model/selectorの関数import': False, 'モデル再学習/金融計算/Raw/CSV/追加2場': False,
             '教師射影の境界': 'workcacheの全canonical/aliases/label/known_at対応を検査。原観測の金融再集計はRoot別票。',
             '入力前後同体': [{'path': str(p.relative_to(ROOT)), 'sha256': v[0], 'bytes': v[1], 'mtime_ns': v[2]} for p, v in tracked.items()],
             '監査コードSHA256': digest(Path(__file__))}
    output = args.output_dir / '監査の確認.json'; output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'モデル': trained, '全q0': len(decisions), '政策': counts, '停止SHA256': digest(output)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
