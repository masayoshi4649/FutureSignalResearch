# 151自然選択の全件因果・所属監査

2026-11-12。監査成功・編集停止。全65保存JSONを再loadし、全35,339q0の確率・固定決定・実split/有限role・evidenceを別計算した。全73場の直近20/strict成熟/1000物理pair/8寄与場/三class、活動時間区画の質量と両側同重み、LE数値配列署名も一致した。**金融結果の検算とは別である。**

P70 511、P65 1,118、P60 2,545、N70 511、C1 87、U70 595、U65 1,200、U60 2,627。q1 canonical・C1優先・未取得/競合計数・全参照順序が一致した。全末端比較は1,446,946値。[自然確認票](自然確認/監査の確認.json)が数値/源指紋の正本。

## 範囲と作者境界

Root run151/data151/model151/selector、純teacherの関数はimportしていない。CatBoost1.2.10で保存JSONの再推論だけを行い、再学習・原観測の金融計算・Raw/CSV/追加2場読取はしていない。教師workcacheのcanonical/aliases・label/known_at・配列対応を検査し、原BBO観測からの教師再射影や金融算術はRoot別票へ分離する。

純teacher部品の作者は本監査者である。本票ではその関数を呼ばず別式で自然の重み/配列と運転出力を再構成したが、純teacher数理の作者分離された検査はRootの別人工票へ分ける。100特徴の定義自体の再実装でもない。

## 固定票と後発cache参照

- F0：`d14d98f984adf9894703a40f4c68a97347109666c0a05743459ca3822e566cf4`
- F1：`81018200993e85ecc22e54ff518cebd225693162140658124434ed2eabc36917`
- cache後発参照：`d7bc76ec0b8ebe001e3d0df3359325d5066c63a9f4a88f686c955dcfa88d2c49`

最初の監査試行では、F1のF0結合キーが従前の`F0_SHA256`ではなく`前段階SHA256`で停止した。次に、4cacheはF1のファイル一覧へ含まれないことを検出し停止した。Rootがcacheの現在SHAを別票へ固定し、**F1事前固定対象だったとの主張をfalse**として追補した。この後発票・元book入力由来・元F0/F1を照合してから再開した。元F1/Source/条件/選択は変更していない。

4cacheは後発参照として、モデル65のF1固定学習配列署名と全q0保存予測へ照合した。F1に含まれるモデル/判断と、F1後に指紋化したcacheを同じ固定時点の成果だと誤記しない。全77追跡源は監査前後SHA/stat同体だった。

## 実行

指定venvのPythonを用い、F1通知後にだけ実行する。出力先は未作成にする。

```powershell
& work/複合テクニカル学習環境/Scripts/python.exe work/151自然選択の独立監査/監査する.py `
  --run-dir work/151過去場判別の評価/入口選択 `
  --book inputs/00151_過去場だけの複合判別/条件.json `
  --f0 work/151過去場判別の評価/F0入口選択前.json `
  --f0-sha256 d14d98f984adf9894703a40f4c68a97347109666c0a05743459ca3822e566cf4 `
  --f1 work/151過去場判別の評価/F1入口選択後.json `
  --f1-sha256 81018200993e85ecc22e54ff518cebd225693162140658124434ed2eabc36917 `
  --cache-reference work/151過去場判別の評価/監査cacheの後発参照.json `
  --cache-reference-sha256 d7bc76ec0b8ebe001e3d0df3359325d5066c63a9f4a88f686c955dcfa88d2c49 `
  --output-dir S:/GitHub/masayoshi4649/FutureSignalResearch/work/151自然選択の独立監査/別の未作成出力
```

Rootの固定運転器`freeze151`でもoutput-dirを絶対pathで渡した。相対pathでは固定票path整形が保存前に停止した履歴があり、Root報告ではSourceの売買条件を変更せず絶対pathで成功した。監査器やrun151そのもののAPIが相対pathを一律禁止すると主張する意味ではない。

cacheは再生成可能なwork参照で、巨大な原板や解凍副本をこの監査folderへ複製しない。保存モデル・共有入力・正規再現手順はRootの正式保管へ接続する。本監査成功を先着率70%やモデル採用の達成とはしない。
