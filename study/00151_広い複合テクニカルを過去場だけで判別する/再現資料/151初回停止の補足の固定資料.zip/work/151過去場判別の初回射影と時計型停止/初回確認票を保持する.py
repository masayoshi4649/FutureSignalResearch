"""初回停止F0に束縛された確認票を、値の明白な差分だけから保持する。"""
from pathlib import Path
import hashlib
import json


def main() -> None:
    """
    機能: 初回runの指紋へ戻したRoot人工票が旧F0と一致することを確認する。
    引数: なし。返り値: None。現在の票やSourceは上書きしない。
    """
    here = Path(__file__).resolve().parent
    root = here.parents[1]
    key = 'work/151過去場判別/運転側Root人工の確認.json'
    f0 = json.loads((here / 'F0入口選択前.json').read_bytes())
    previous = json.loads((root / key).read_bytes())
    previous['源']['run151.py'] = 'e5fae2a2a1af777ff732b27ea8c1388fdd32589fbe813a3f0a8a52b72702ccc2'
    body = (json.dumps(previous, ensure_ascii=False, indent=2) + '\n').replace('\n', '\r\n').encode('utf-8')
    assert hashlib.sha256(body).hexdigest() == f0['ファイル'][key]
    with (here / '初回Root人工の確認.json').open('xb') as sink:
        sink.write(body)
    print('初回F0のRoot人工票と同体')


if __name__ == '__main__':
    main()
