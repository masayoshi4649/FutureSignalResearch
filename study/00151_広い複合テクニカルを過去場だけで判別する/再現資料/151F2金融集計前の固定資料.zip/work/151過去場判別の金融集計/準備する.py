"""151金融集計の人工だけを実行し自然未読の準備票を固定する。"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: 対象源の物理指紋を固定bufferで求める。
    引数: path(Path)。返り値: str。
    """
    digest=hashlib.sha256()
    with path.open('rb')as source:
        for block in iter(lambda:source.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()


def function_ast(path: Path,name: str) -> str:
    """
    機能: 祖先の基本算術/I/OのASTが変わっていないか比較する。
    引数: path(Path)、name(str)。返り値: str。
    """
    node=next(n for n in ast.parse(path.read_text(encoding='utf-8')).body if isinstance(n,ast.FunctionDef)and n.name==name)
    return ast.dump(node,include_attributes=False)


def main() -> None:
    """
    機能: UTF-8小fixture検査・構文・源/祖先同体だけで準備停止する。
    引数: なし。返り値: None。
    """
    spec=importlib.util.spec_from_file_location('prepare151finance',HERE/'集計する.py');aggregate=importlib.util.module_from_spec(spec);spec.loader.exec_module(aggregate)
    paths=list(dict.fromkeys([HERE/name for name in ('集計する.py','人工検査.py','条件.md','準備する.py')]+[ROOT/'work/150構造状態の金融集計/人工検査.py',ROOT/'work/148母集団の診断集計/人工検査.py',*aggregate.SOURCES]));before={p:sha(p)for p in paths};assert all(before[p]==h for p,h in aggregate.SOURCES.items())
    for path in HERE.glob('*.py'):
        tree=ast.parse(path.read_text(encoding='utf-8'))
        for node in ast.walk(tree):
            if isinstance(node,ast.FunctionDef):
                text=ast.get_docstring(node);assert text and '\n'in text and all(word in text for word in ('機能','引数','返り値'))
    copied={name:function_ast(HERE/'集計する.py',name)==function_ast(aggregate.ANCESTOR,name)for name in ('sha','load','module','selected','cumulative_step')};assert all(copied.values())
    command=[sys.executable,'-X','utf8',str(HERE/'人工検査.py')];process=subprocess.run(command,capture_output=True,cwd=ROOT,env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'});stdout=process.stdout.decode('utf-8','strict');stderr=process.stderr.decode('utf-8','strict');assert process.returncode==0 and '\ufffd'not in stdout+stderr
    assert all(sha(path)==value for path,value in before.items());proof={'成功':True,'試行':151,'自然共用入力又はラベル本文の読取':False,'自然選択又は学習':False,'自然金融集計':False,'人工主検査数':5,'構文と関数コメント':True,'UTF8_strict':True,'実行':{'引数':command,'終了値':process.returncode,'標準出力':stdout,'標準エラー':stderr},'祖先150基本関数AST同体':copied,'源':[{'path':str(path.relative_to(ROOT)).replace('\\','/'),'sha256':value,'bytes':path.stat().st_size}for path,value in before.items()],'全源前後一致':True,'三表契約':{'正逆比較':[660,34],'入口別診断':['U70可変件数・最低旧C1の87',47],'全セッション':[73,63]},'固定票':'F1=予測選択後、F2=実金融前。別key/別引数。','Source学習':'過去成熟教師を使用した学習の固定予測だけを評価し、金融内で再学習しない。','独立役':'作者は150/149/148/124算術を継承。Root141独立算術は別。','自然実行':'運転停止proof後のRoot別通知待ち'}
    target=HERE/'準備の確認.json'
    with target.open('x',encoding='utf-8')as source:json.dump(proof,source,ensure_ascii=False,indent=2,allow_nan=False);source.write('\n')
    stop={'成功':True,'編集停止':True,'自然金融未実行':True,'準備票SHA256':sha(target),'自源':{p.name:before[p]for p in paths if p.parent==HERE}}
    with (HERE/'停止.json').open('x',encoding='utf-8')as source:json.dump(stop,source,ensure_ascii=False,indent=2);source.write('\n')
    print(json.dumps({'成功':True,'準備SHA256':sha(target),'停止SHA256':sha(HERE/'停止.json'),'集計sourceSHA256':before[HERE/'集計する.py']},ensure_ascii=False))


if __name__=='__main__':
    main()
