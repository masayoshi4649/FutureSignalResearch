"""151の予測選択後F1と金融Sourceを、別の金融前F2へ束縛する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json

ROOT = Path(__file__).resolve().parent.parent


def sha(path: Path) -> str:
    """
    機能: ファイルの物理指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: F1同体と金融準備の源を確認してF2だけを新規保存する。
    引数: CLI f1/output(Path)、f1-sha256(str)。返り値: None。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--f1', type=Path, required=True)
    parser.add_argument('--f1-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists() and sha(args.f1) == args.f1_sha256
    f1 = json.loads(args.f1.read_bytes())
    assert f1['試行'] == 151 and f1['段階'] == 'F1'
    files = {}
    for name, expected in f1['ファイル'].items():
        assert sha(ROOT / name) == expected, name
        files[name] = expected
    refs = [args.f1.resolve(), Path(__file__).resolve(),
        ROOT / 'work/151複合テクニカルの金融集計を独立に照合する.py',
        ROOT / 'work/141金融集計を独立に確認する.py',
        ROOT / 'work/124入口の原因分析/集計する.py',
        ROOT / 'work/148母集団の診断集計/集計する.py',
        ROOT / 'work/149可読局面の金融集計/集計する.py',
        ROOT / 'work/150構造状態の金融集計/集計する.py',
        ROOT / 'work/確定三表のCSV出力_版2/出力する.mjs',
        ROOT / 'work/確定三表のCSV出力_版2/CSVを独立再読する.py']
    finance = ROOT / 'work/151過去場判別の金融集計'
    refs.extend(p for p in finance.iterdir() if p.is_file())
    prep = json.loads((finance / '準備の確認.json').read_bytes())
    assert prep['成功']
    for item in prep['源']:
        assert sha(ROOT / item['path']) == item['sha256']
    for path in refs:
        files[path.relative_to(ROOT).as_posix()] = sha(path)
    result = {'成功': True, '試行': 151, '段階': '実金融集計前F2',
        'UTC': datetime.now(timezone.utc).isoformat(), 'F1_SHA256': args.f1_sha256,
        '金融のために入口を選び直す': False, '主政策': 'U70',
        'ファイル': dict(sorted(files.items()))}
    with args.output.open('x', encoding='utf-8', newline='\n') as source:
        json.dump(result, source, ensure_ascii=False, indent=2, allow_nan=False)
        source.write('\n')
    print(json.dumps({'成功': True, '段階': 'F2', '指紋数': len(files),
        'sha256': sha(args.output)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
