package miniprotect

import (
	"bytes"
	"encoding/json"
	"fmt"
	"reflect"
	"strings"

	legacy "github.com/masayoshi4649/SessionTradeExecuter/continuousactor113"
	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate114"
)

// LegacyComparison114 はA0の追加証拠とID表記差だけを分離した全金融対照です。
type LegacyComparison114 struct {
	EntryMode           string `json:"entry_mode"`
	Protection          string `json:"protection"`
	StreamScopeChanged  bool   `json:"stream_scope_difference"`
	ConfigModeSeparated bool   `json:"config_mode_separated"`
	GateRecords         int    `json:"gate_records"`
	NormalizedIDs       int    `json:"normalized_ids"`
	AllFinancialEqual   bool   `json:"all_financial_equal"`
}

// comparisonJSON114 は数値字句を保って全公開JSONを独立値へ写します。
//
// 引数: value(any)は現在又は旧口座です。
// 返り値: any/errorは全値又は符号化エラーです。金融値は削りません。
func comparisonJSON114(value any) (any, error) {
	raw, err := json.Marshal(value)
	if err != nil {
		return nil, err
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	var result any
	err = decoder.Decode(&result)
	return result, err
}

// normalizeIDs114 はActor生成IDの接頭辞だけを明示field内で旧表記へ写します。
//
// 引数: value(any)、before/after(string)、proof(*LegacyComparison114)は全値と新旧接頭辞・件数です。
// 返り値: なし。Source ID・Frame・C/M/P/Bの値を加工しません。
func normalizeIDs114(value any, before, after string, proof *LegacyComparison114) {
	switch node := value.(type) {
	case []any:
		for _, child := range node {
			normalizeIDs114(child, before, after, proof)
		}
	case map[string]any:
		for key, child := range node {
			switch key {
			case "id", "entry_order_id", "order_id", "position_id", "fill_id", "exit_order_id":
				if text, ok := child.(string); ok && strings.HasPrefix(text, before) {
					node[key] = after + strings.TrimPrefix(text, before)
					proof.NormalizedIDs++
				}
			}
			// 元通知・技法証拠のIDはActor生成IDの対象ではありません。
			if key != "source" && key != "request" && key != "decision" && key != "entry" && key != "latest" {
				normalizeIDs114(node[key], before, after, proof)
			}
		}
	}
}

// CompareLegacy113 はA0と旧113P100を原行ごと又は完結後に全金融/全Stateで照合します。
//
// 引数: current(ActualResult)、prior(legacy.ActualResult)は同場・費用・遅延の新旧口座です。
// 返り値: LegacyComparison114/errorは許可説明差と成功又は金融差です。
func CompareLegacy113(current ActualResult, prior legacy.ActualResult) (LegacyComparison114, error) {
	proof := LegacyComparison114{EntryMode: current.Config.EntryMode, Protection: current.Config.Policy}
	if current.Config.EntryMode != "A0" || current.Config.Policy != "P100" || prior.Config.Policy != "P100" || current.Config.SlipPts != prior.Config.SlipPts || current.Config.DelaySeconds != prior.Config.DelaySeconds || current.StreamScope != ContinuousScope114 || prior.StreamScope != legacy.ContinuousScope113 {
		return proof, fmt.Errorf("114A0と113P100の対照条件差")
	}
	audit := current.EntryGate
	if audit == nil || audit.Version != 114 || audit.Mode != "A0" || len(audit.Records) != current.Metrics.NativeNewSignals {
		return proof, fmt.Errorf("114A0全new票の欠落")
	}
	events := []SourceEventTrace{}
	for _, event := range current.SourceEvents {
		if event.Kind == "new_signal" {
			events = append(events, event)
		}
	}
	if len(events) != len(audit.Records) {
		return proof, fmt.Errorf("114A0元newイベントとの分母差")
	}
	for i, row := range audit.Records {
		event := events[i]
		if !row.Allowed || row.Selected != gate.True || row.Request.Product != "NK225mini" || row.Request.Method != event.Method || row.Request.SignalID != event.SignalID || row.Request.Side != event.Side || row.Request.At.Time != event.At || row.Request.At.Index != int(event.Quote.Index) || row.Request.At.Line != event.Quote.SourceLine || row.Quote != event.Quote || row.AcceptedQuantity != event.ActualAccepted || row.Available != event.Available || row.OrderID != event.OrderID {
			return proof, fmt.Errorf("114A0の全許可/要求行固定/実受付結合の差")
		}
	}
	proof.GateRecords = len(audit.Records)
	leftValue, err := comparisonJSON114(current)
	if err != nil {
		return proof, err
	}
	rightValue, err := comparisonJSON114(prior)
	if err != nil {
		return proof, err
	}
	left, right := leftValue.(map[string]any), rightValue.(map[string]any)
	config := left["config"].(map[string]any)
	if config["entry_mode"] != "A0" {
		return proof, fmt.Errorf("114A0の設定説明差")
	}
	delete(config, "entry_mode")
	proof.ConfigModeSeparated = true
	delete(left, "entry_gate")
	proof.StreamScopeChanged = left["stream_scope"] != right["stream_scope"]
	left["stream_scope"], right["stream_scope"] = "", ""
	expectedKey := fmt.Sprintf("A0_C%.0f_D%d", current.Config.SlipPts, current.Config.DelaySeconds)
	if current.Key != expectedKey || prior.Key != fmt.Sprintf("P100_C%.0f_D%d", current.Config.SlipPts, current.Config.DelaySeconds) {
		return proof, fmt.Errorf("114A0の口座key差")
	}
	left["key"] = right["key"]
	normalizeIDs114(left, current.Session.ID+"-"+current.Key+"-", prior.Session.ID+"-"+prior.Key+"-", &proof)
	if !reflect.DeepEqual(left, right) {
		return proof, fmt.Errorf("114A0と113P100の全金融/全Stateに差:%s", current.Key)
	}
	proof.AllFinancialEqual = true
	return proof, nil
}
