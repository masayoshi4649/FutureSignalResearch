"""114Actorの純停止・人工・旧金融同体と所有不変を固定する。"""

import argparse
import hashlib
import json
import os
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OLD_STOP = ROOT / 'work/113起動前の構造失効を執行する会計/Actor停止.json'
OLD_SHA = '9f261c911946082c20b0bfc259a991cb045a533456187ec611732ec72a34133b'


def sha(path: Path) -> str:
    """機能: 明示ファイルの全bytes指紋を返す。

    引数: path(Path)は停止・コード又は人工証拠。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(argv: list[str], environment: dict) -> dict:
    """機能: 市場を読まないGo検査を行う。

    引数: argv(list[str])はコマンド、environment(dict)は明示環境。
    返り値: dictは出力と終了値。不成功はValueError。
    """
    value = subprocess.run(argv, cwd=HERE, env=environment, capture_output=True, text=True, encoding='utf-8', timeout=90)
    result = {'argv': argv, 'exit_code': value.returncode, 'stdout': value.stdout, 'stderr': value.stderr}
    if value.returncode:
        raise ValueError(json.dumps(result, ensure_ascii=False))
    return result


def stop(gate_ref: dict) -> dict:
    """機能: 純gate停止と旧113不変を認証しActor114の市場前停止を作る。

    引数: gate_ref(dict)はRootへ共有された純gate停止のFileRef。
    返り値: dictは停止Ref。既存停止への上書きは拒否する。
    """
    target, output = HERE / 'Actor停止.json', HERE / 'Actor検査'
    if target.exists() or output.exists() or sha(OLD_STOP) != OLD_SHA or sha(Path(gate_ref['path'])) != gate_ref['sha256']:
        raise ValueError('停止先新規性又は旧/純停止SHA差')
    pure = json.loads(Path(gate_ref['path']).read_bytes())
    if pure.get('成功') is not True:
        raise ValueError('純gate停止が成功でない')
    own = sorted(HERE.glob('*.go')) + [HERE / n for n in ['go.mod', 'go.sum', 'Actor_README.md', 'Actorの派生元.json', Path(__file__).name]]
    before = {str(path): sha(path) for path in own}
    origin = json.loads((HERE / 'Actorの派生元.json').read_bytes())
    old = json.loads(OLD_STOP.read_bytes())
    deps = {str(OLD_STOP): OLD_SHA, gate_ref['path']: gate_ref['sha256']}
    for data in [pure, old]:
        for field in ['所有コードSHA256', '所有ファイルSHA256', '依存SHA256', '再用コードSHA256']:
            deps.update(data.get(field, {}))
    deps.update({row['path']: row['sha256'] for row in origin['入力']})
    if any(sha(Path(path)) != digest for path, digest in deps.items()):
        raise ValueError('依存コードの事前SHA差')
    env = dict(os.environ, GOWORK='off', CGO_ENABLED='0')
    for key in ['MINIPROTECT_EXPORT_DIR', 'CONTINUOUS113_EXPORT_DIR', 'CONTINUOUS114_EXPORT_DIR']:
        env.pop(key, None)
    commands = [run(['go', 'test', '-count=1', '-json', './...'], env), run(['go', 'vet', './...'], env), run(['go', 'build', './...'], env)]
    events = [json.loads(line) for line in commands[0]['stdout'].splitlines() if line.startswith('{')]
    tests = [event['Test'] for event in events if event.get('Action') == 'pass' and 'Test' in event]
    if len(tests) != 11:
        raise ValueError('旧6主/新5主の人工件数差:' + str(tests))
    output.mkdir()
    exported = run(['go', 'test', '-count=1', '-run', '^TestExportEntry114$', './...'], dict(env, CONTINUOUS114_EXPORT_DIR=str(output/'人工')))
    api = run(['go', 'doc', '-all', '.'], env)
    (output/'API.txt').write_text(api['stdout'], encoding='utf-8')
    declared = json.loads((output/'人工/宣言設定.json').read_bytes())
    expected = [{'policy': 'P100', 'entry_mode': mode, 'slip_pts': cost, 'delay_seconds': delay} for mode in ['A0','T','TR'] for cost in [0,5] for delay in [0,1]]
    if declared != expected or 'func CompareLegacy113(' not in api['stdout'] or 'func (b *ActualBook) SetEntryFrame(' not in api['stdout']:
        raise ValueError('実12宣言又は公開API差')
    previous = HERE / '人工_独立判定用'
    same = all(sha(previous/name) == sha(output/'人工'/name) for name in ['買売人工.json','入口定義.json','宣言設定.json'])
    if not same:
        raise ValueError('Root独立突合用の人工から値が変わった')
    if before != {p: sha(Path(p)) for p in before} or any(sha(Path(p)) != h for p,h in deps.items()):
        raise ValueError('新所有/旧依存の前後差')
    proof = {'試行': 114, '成功': True, '市場前': True, '主人工数': 11, '成功test': tests, 'test/vet/build': commands,
             '人工export': exported, '旧113P100対A0': '全4費用/全受理原行と終了の全金融/全State。gate metadata/ID/key/mode/Scope説明だけ検査後に分離。',
             'Root独立突合用人工と同bytes': same, '所有コードSHA256': before, '依存SHA256': deps, '前後不変': True,
             '市場/Raw/価格CSV/11月09日本文': False}
    proof_path = output/'人工確認.json'
    proof_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    record = {'試行': 114, '成功': True, '市場前': True, '停止': True, 'module': 'github.com/masayoshi4649/SessionTradeExecuter/continuousactor114',
              '所有コードSHA256': before, '再用コードSHA256': deps, '前後不変': True, '純入口停止': gate_ref,
              '元Actor停止': {'path': str(OLD_STOP), 'sha256': OLD_SHA}, '人工確認': {'path': str(proof_path), 'sha256': sha(proof_path)},
              '実API': {'path': str(output/'API.txt'), 'sha256': sha(output/'API.txt')},
              '実12宣言': {'path': str(output/'人工/宣言設定.json'), 'sha256': sha(output/'人工/宣言設定.json')},
              '人工出力SHA256': {str(p): sha(p) for p in sorted((output/'人工').glob('*.json'))},
              '市場/Raw/価格CSV/11月09日本文': False, '研究目標達成': False, '採用': False}
    target.write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    return {'成功': True, '停止': {'path': str(target), 'sha256': sha(target)}}


def main() -> None:
    """機能: 明示純停止Refで114Actorを市場前停止する。

    引数: CLI gate-stop/gate-sha(str)は絶対停止位置と期待SHA。
    返り値: None。停止Refだけを表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--gate-stop', type=Path, required=True)
    parser.add_argument('--gate-sha', required=True)
    args = parser.parse_args()
    print(json.dumps(stop({'path': str(args.gate_stop.resolve()), 'sha256': args.gate_sha}), ensure_ascii=False))


if __name__ == '__main__':
    main()
