package miniprotect

import (
	"fmt"
	"reflect"

	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate114"
)

// EntryGateRecord114 は元要求行で固定した技法票と、その後の実受付/取得を分けます。
type EntryGateRecord114 struct {
	Request          gate.Request   `json:"request"`
	Source           SourceIdentity `json:"source"`
	Quote            QuoteStamp     `json:"quote"`
	Decision         gate.Decision  `json:"decision"`
	Selected         gate.Truth     `json:"selected"`
	Allowed          bool           `json:"allowed"`
	Available        int            `json:"available"`
	CapQuantity      int            `json:"cap_quantity"`
	SourceCancelled  bool           `json:"source_cancelled"`
	AcceptedQuantity int            `json:"accepted_quantity"`
	OrderID          string         `json:"order_id"`
	ActualQuantity   int            `json:"actual_quantity"`
	ActualFillID     string         `json:"actual_fill_id"`
	ActualPositionID string         `json:"actual_position_id"`
	ActualQuote      *QuoteStamp    `json:"actual_quote"`
}

// EntryGateAudit114 は全new通知を残し、技法拒否と容量・実fillを混同しません。
type EntryGateAudit114 struct {
	Version int                  `json:"version"`
	Mode    string               `json:"mode"`
	Records []EntryGateRecord114 `json:"records"`
}

type entryGateRuntime114 struct {
	history  *gate.History
	bySource map[string]int
}

// initEntryGate は口座ごとに同じ範囲の私有履歴を一度作ります。
//
// 引数: contract(string)は明示限月です。
// 返り値: errorは新規履歴範囲の不正です。元Sourceへ更新を返しません。
func (b *ActualBook) initEntryGate(contract string) error {
	history, err := gate.NewHistory(gate.Scope{Session: b.result.Session.ID, Contract: contract, Start: b.result.Session.Start, End: b.result.Session.End})
	if err != nil {
		return err
	}
	b.entryGate = &entryGateRuntime114{history: history, bySource: map[string]int{}}
	b.result.EntryGate = &EntryGateAudit114{Version: 114, Mode: b.result.Config.EntryMode, Records: []EntryGateRecord114{}}
	return nil
}

// SetEntryFrame はCoreの実公表順で旧Frameと原行配送stampを受け取ります。
//
// 引数: frame(gate.Frame)、stamp(gate.Stamp)は当時公表と配送原行です。
// 返り値: errorは範囲・未来・後退・同ID改変です。注文や再ゲートは発生しません。
func (b *ActualBook) SetEntryFrame(frame gate.Frame, stamp gate.Stamp) error {
	if err := b.ready(); err != nil {
		return err
	}
	if b.entryGate == nil || stamp.Time < b.lastEventAt {
		return b.stop(fmt.Errorf("114入口公表の初期化又は配送時計差"))
	}
	if err := b.entryGate.history.Step(frame, stamp); err != nil {
		return b.stop(err)
	}
	return nil
}

// ResetEntryFrame は実欠足等の配送順で入口履歴を失効させます。
//
// 引数: stamp(gate.Stamp)、reason(string)は原行と明示理由です。
// 返り値: errorは範囲・後退・空理由です。既に凍結した出生票は変更しません。
func (b *ActualBook) ResetEntryFrame(stamp gate.Stamp, reason string) error {
	if err := b.ready(); err != nil {
		return err
	}
	if b.entryGate == nil || stamp.Time < b.lastEventAt {
		return b.stop(fmt.Errorf("114入口resetの初期化又は配送時計差"))
	}
	if err := b.entryGate.history.Reset(stamp, reason); err != nil {
		return b.stop(err)
	}
	return nil
}

// freezeEntryGate は元new要求行だけで三値T/R/ORを一度固定します。
//
// 引数: at(float64)、quote(QuoteStamp)、source(SourceIdentity)は実元通知の時計・原行・出典です。
// 返り値: int/bool/errorは証拠行番号・選別許可・不整合です。旧人工の非連続口座は許可します。
func (b *ActualBook) freezeEntryGate(at float64, quote QuoteStamp, source SourceIdentity) (int, bool, error) {
	if b.entryGate == nil {
		return -1, true, nil
	}
	if at != quote.Time {
		return -1, false, fmt.Errorf("114入口要求と原行時計差")
	}
	key := sourceKey(source.Method, source.SignalID)
	if _, exists := b.entryGate.bySource[key]; exists {
		return -1, false, fmt.Errorf("114出生を再評価しない")
	}
	request := gate.Request{Product: "NK225mini", Method: source.Method, SignalID: source.SignalID, Side: sourceSide114(b, source), At: gate.Stamp{Time: at, Index: int(quote.Index), Line: quote.SourceLine}}
	decision, err := b.entryGate.history.Evaluate(request)
	if err != nil {
		return -1, false, err
	}
	selected := gate.True
	switch b.result.Config.EntryMode {
	case "A0":
	case "T":
		selected = decision.Trend
	case "TR":
		selected = decision.Combined
	default:
		return -1, false, fmt.Errorf("114未知の入口モード")
	}
	allowed := selected == gate.True
	index := len(b.result.EntryGate.Records)
	b.entryGate.bySource[key] = index
	b.result.EntryGate.Records = append(b.result.EntryGate.Records, EntryGateRecord114{Request: request, Source: source, Quote: quote, Decision: decision, Selected: selected, Allowed: allowed})
	return index, allowed, nil
}

// sourceSide114 はregistryに存在する元new要求の方向を参照します。
//
// 引数: book(*ActualBook)、source(SourceIdentity)は実口座と登録済み元通知です。
// 返り値: intは買1/売-1です。呼出しはprepareBatches成功後に限ります。
func sourceSide114(book *ActualBook, source SourceIdentity) int {
	return book.sourceOrders[sourceKey(source.Method, source.SignalID)].signal.Side
}

// entryGateOutcome は凍結した技法証拠を変えず容量・受付の事実だけを追記します。
//
// 引数: index/free/cap/accepted(int)、cancelled(bool)、orderID(string)は証拠位置と実受付です。
// 返り値: なし。旧人工のindex-1は非対象です。
func (b *ActualBook) entryGateOutcome(index, free, cap int, cancelled bool, accepted int, orderID string) {
	if index < 0 {
		return
	}
	row := &b.result.EntryGate.Records[index]
	row.Available, row.CapQuantity, row.SourceCancelled = free, cap, cancelled
	row.AcceptedQuantity, row.OrderID = accepted, orderID
}

// entryGateFill は元要求で許可済みの実新規fillを一意な出生票へ結びます。
//
// 引数: order(ActualOrder)、fill(ActualFill)は既予約の実取得です。
// 返り値: errorは未許可・再取得・数量超過です。現在Frameを再評価しません。
func (b *ActualBook) entryGateFill(order ActualOrder, fill ActualFill) error {
	if b.entryGate == nil {
		return nil
	}
	index, exists := b.entryGate.bySource[sourceKey(order.Source.Method, order.Source.SignalID)]
	if !exists {
		return fmt.Errorf("114実取得に凍結出生票なし")
	}
	row := &b.result.EntryGate.Records[index]
	if !row.Allowed || row.SourceCancelled || row.OrderID != order.ID || row.ActualQuantity != 0 || fill.Quantity != row.AcceptedQuantity {
		return fmt.Errorf("114実取得と元受付票の不整合")
	}
	row.ActualQuantity, row.ActualFillID, row.ActualPositionID = fill.Quantity, fill.ID, fill.PositionID
	stamp := fill.Quote
	row.ActualQuote = &stamp
	return nil
}

// checkEntryGate は全出生と実受付・取得の分母を照合します。
//
// 引数: receiver(*ActualBook)は元原行の処理後です。
// 返り値: errorは欠落・重複・未許可取得・金融分母の差です。
func (b *ActualBook) checkEntryGate() error {
	if b.entryGate == nil {
		return nil
	}
	audit := b.result.EntryGate
	if audit == nil || audit.Mode != b.result.Config.EntryMode || len(audit.Records) != b.result.Metrics.NativeNewSignals || len(b.entryGate.bySource) != len(audit.Records) {
		return fmt.Errorf("114全new票の分母差")
	}
	requests, accepted, fills := 0, 0, 0
	for _, row := range audit.Records {
		if row.AcceptedQuantity > 0 {
			requests++
			accepted += row.AcceptedQuantity
			if !row.Allowed || row.SourceCancelled || row.AcceptedQuantity > row.CapQuantity || row.OrderID == "" {
				return fmt.Errorf("114未許可受付")
			}
		} else if row.OrderID != "" {
			return fmt.Errorf("114受付0に注文")
		}
		if row.ActualQuantity > 0 {
			fills++
			if row.ActualQuantity != row.AcceptedQuantity || row.ActualFillID == "" || row.ActualQuote == nil {
				return fmt.Errorf("114実取得の結合差")
			}
		}
		if row.Decision.Request != row.Request || !row.Decision.Frozen {
			return fmt.Errorf("114純固定票と要求原行の差")
		}
		if !reflect.DeepEqual(row.Source, b.sourceOrders[sourceKey(row.Request.Method, row.Request.SignalID)].identity) {
			return fmt.Errorf("114出典の変更")
		}
	}
	if requests != b.result.Metrics.EntryRequests || accepted != b.result.Metrics.EntryAcceptedQuantity || fills != b.result.Metrics.EntryFills {
		return fmt.Errorf("114受付/実fillの金融分母差")
	}
	return nil
}
