# 114の順行・反転取得を執行するActor

元Source111の新規要求原行を一度だけ判定し、A0（元全出生）/T（順行）/TR（順行または反転）×追加滑り0/5pt×追加価格時計遅延0/1秒の12口座を独立保持する。`ActorConfig`の`policy`は全てP100、`entry_mode`を別fieldとし、口座keyはA0_C0_D0等。本名Policyを別保護へ偽装しない。

113 Actorのactual/continuous型を独立コピーした。共通保護は113純演算のP100（H100・MACDと動的支持否定による狭幅・取得後の適格構造床）であり、E早期失効/H50や数量変更は追加しない。既存の注文取消・Source予約優先・実部分返済・片側10mini・片道38.5円・同原行禁止・正常な後原行fill・場内flatを継承する。保護の`protection113`型/定義113を維持する。元の一方向Sourceへ実保護/選別を返送しない。

## 公開APIと順序

- `DeclaredContinuousConfigurations()`：本名12条件。
- `NewContinuousBook(session,contract,cfg)`：市場入口は上記12だけ。
- `SetEntryFrame(frame gate.Frame,stamp gate.Stamp)` / `ResetEntryFrame(stamp,reason)`：Coreのbank.Events順に全12へ同じ公表/欠足を配送。
- `SetPublication` / `ResetPublication`：共通P100保護の既存配送。
- `OnNativeStep` / `OnNativeForce` / `Snapshot` / `Finish`：原順序と旧型を維持。
- `CompareLegacy113(current,prior)`：A0と旧113P100の同費用4条件を、未Finishの原行ごとにも全金融/全Stateで比較する。

純entrygate114のHistoryを各口座が私有化する。元new通知に対してProduct NK225mini・正規Method・SignalID・Side・Time/Index/物理行を渡し、当時までに配送済みのCurrent/PreviousとT/R/OR三値をfreeze。A0は元三値も残して全許可、TはTrend真のみ、TRはCombined真のみ。未知を偽へ補完しない。取得時に新しいFrameで再ゲートしない。拒否・上限0・元取消も消費済みとし後の空きへ再参加しない。

`ActualResult.entry_gate.records`は`request/source/quote/decision/selected/allowed`を凍結証拠、`available/cap_quantity/source_cancelled/accepted_quantity/order_id/actual_quantity/actual_fill_id/actual_position_id/actual_quote`を実受付・取得の事実として分ける。cap_quantityは選別前のmin(元枚数,片側余力)。Decisionの全条件票・不足・否定・生Frame/値・配送Stampを保持し、全モード/費用/遅延の元Decisionが同体であることを人工で確認する。

A0対照では、新gate証拠の全出生/全許可/受付結合を確認してからその追加metadataを分離する。許可する他の差はentry_mode=A0、口座key、Actor生成IDの接頭辞、StreamScope説明だけ。Source ID/Frame/C/M/P/Bや保護数式、全注文/約定/所有/時価・費用は比較から落とさない。

旧`NewActualBook`は固定旧人工のS0/P0/P1にのみ残し、新EntryModeを受付しない。114市場はNewContinuousBookだけを用いる。市場/Raw/11月09日本文は実行・読取していない。CSVは生成しない。

## 人工と停止

停止helperは純gate停止を明示Refで認証し、旧113の所有・依存を前後SHAで認証してtest/vet/build/API/実12宣言/買売24冊を保存する。旧6主人工に加え新5主人工が対象。初期の`人工_独立判定用`はRoot独立Python突合用で、停止時の人工と同bytesも照合する。Frameは手製の旧型、Sourceは手製API通知であり、自然FAR生成の成功とは呼ばない。
