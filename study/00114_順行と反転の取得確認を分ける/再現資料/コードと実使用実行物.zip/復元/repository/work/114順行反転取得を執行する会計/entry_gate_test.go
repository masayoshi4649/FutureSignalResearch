package miniprotect

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	warm "github.com/masayoshi4649/SessionTradeExecuter/chartwarmup96"
	legacy "github.com/masayoshi4649/SessionTradeExecuter/continuousactor113"
	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate114"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	finance "github.com/masayoshi4649/SessionTradeExecuter/minivariableguard"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor113"
	delivery "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery"
)

// frame114 は市場を使わずT/Rの役割別値を持つ既存Frame型を作ります。
//
// 引数: side(int)、ordinal(int)、kind(string)は方向・順序・手製局面です。
// 返り値: gate.Frameは旧Validateも通る手製公表です。
func frame114(side, ordinal int, kind string) gate.Frame {
	session := session94()
	end := session.Start + 1440 + float64(ordinal)*180
	ema8, ema21, close, hist := 1000.0, 990.0, 1005.0, 4.0
	if kind == "reversal" {
		ema21, close, hist = 1020, 995, -4
	}
	if ordinal > 1 {
		ema8 += 5
		ema21 += 5
		close = 1010
		hist += 2
	}
	if kind == "false" {
		hist = -5
	}
	if side < 0 {
		ema8, ema21, close, hist = 2000-ema8, 2000-ema21, 2000-close, -hist
	}
	id := finance.WidthPublicationID(session.ID, "人工限月114", end)
	return gate.Frame{ID: id, Ordinal: ordinal, Session: session.ID, Contract: "人工限月114", Start: session.Start, End: end, At: end, AvailableAt: end, ObservedClock: end, TechnicalEnd: end, DataKnown: true,
		LastSource: &warm.SourceStamp{Time: end - 1, Index: int64(ordinal - 1), Line: int64(ordinal), Last: close, Valid: true},
		EMA8:       ema8, EMA21: ema21, Close: close, Hist: hist, Known: delivery.Known{EMA8: true, EMA21: true, Hist: true, Close: true}}
}

// protection114 は共通P100の生C/M/P/Bと元pivotを同じ旧型で配送します。
//
// 引数: side(int)、ordinal(uint64)は方向と順序です。
// 返り値: guard.Publicationは人工の当時確定公表です。
func protection114(side int, ordinal uint64) guard.Publication {
	session := session94()
	end := session.Start + 1440 + float64(ordinal)*180
	close, pivot, kind := 1110.0, 1100.0, "low"
	if side < 0 {
		close, pivot, kind = 2000-close, 2000-pivot, "high"
	}
	scope := guard.Scope{Session: session.ID, Contract: "人工限月114", Start: session.Start}
	v := 20.0
	return guard.Publication{Scope: scope, ID: fmt.Sprintf("保護人工/%d/%d", side, ordinal), Ordinal: ordinal, Start: end - 180, End: end, AvailableAt: end, C: guard.True, M: guard.True, Close: &close, V: &v,
		PriorPivot: &guard.Pivot{Scope: scope, ID: "共通prior", Kind: kind, Price: pivot, CenterStart: session.Start + 180, CenterEnd: session.Start + 360, ConfirmEnd: session.Start + 540, PublishedAt: session.Start + 600}}
}

// actorFixture114 は12口座へ同じ通知を配送しA0の4旧対照を全原行で照合します。
//
// 引数: t(*testing.T)、side(int)、kind(string)は試験器・方向・人工判定局面です。
// 返り値: map[string]ActualResultは完結12冊です。FAR自然生成ではありません。
func actorFixture114(t *testing.T, side int, kind string) map[string]ActualResult {
	t.Helper()
	session := session94()
	source := newFixtureSource94()
	books := map[string]*ActualBook{}
	old := map[string]*legacy.ActualBook{}
	for _, cfg := range DeclaredContinuousConfigurations() {
		book, err := NewContinuousBook(session, "人工限月114", cfg)
		if err != nil {
			t.Fatal(err)
		}
		books[book.Snapshot().Key] = book
		if cfg.EntryMode == "A0" {
			prior, err := legacy.NewContinuousBook(session, "人工限月114", legacy.ActorConfig{Policy: "P100", SlipPts: cfg.SlipPts, DelaySeconds: cfg.DelaySeconds})
			if err != nil {
				t.Fatal(err)
			}
			old[book.Snapshot().Key] = prior
		}
		if kind != "missing" {
			for ordinal := 1; ordinal <= 2; ordinal++ {
				frame := frame114(side, ordinal, kind)
				stamp := gate.Stamp{Time: frame.End, Index: ordinal - 1, Line: int64(99 + ordinal)}
				if err := book.SetEntryFrame(frame, stamp); err != nil {
					t.Fatal(err)
				}
			}
		}
	}
	for i, move := range []float64{0, 0, 130, 450, 350, 400, 250, 50, 70, 0, 0, 0} {
		seconds := []float64{0, .5, 1, 1, 2, 3, 4, 5, 6, 7, 8, 9}
		observation := observation94(session, side, int64(i+2), seconds[i], move, 20)
		if i == 5 {
			observation.QuoteOK = false
		}
		signals := []native.Signal{}
		if i == 0 {
			signals = append(signals, birth94("入口A", side, 5))
		}
		if i == 4 {
			signals = append(signals, close94("部分A", "入口A", side, 2))
		}
		if i == 9 {
			signals = append(signals, close94("残A", "入口A", side, 3))
		}
		batch := source.step(t, observation, int64(i+102), signals, nil)
		if i == 0 || i == 6 {
			ordinal := uint64(1)
			if i == 6 {
				ordinal = 2
			}
			for _, direction := range []int{1, -1} {
				pub := protection114(direction, ordinal)
				for _, book := range books {
					if err := book.SetPublication(observation.Time, direction, pub); err != nil {
						t.Fatal(err)
					}
				}
				for _, book := range old {
					if err := book.SetPublication(observation.Time, direction, pub); err != nil {
						t.Fatal(err)
					}
				}
			}
		}
		if i == 1 && kind != "missing" {
			// 要求行の固定票は、後の履歴resetでも変更されません。
			stamp := gate.Stamp{Time: observation.Time, Index: int(observation.Index), Line: int64(i + 102)}
			for _, book := range books {
				if err := book.ResetEntryFrame(stamp, "取得後の手製reset"); err != nil {
					t.Fatal(err)
				}
			}
		}
		for _, book := range books {
			if err := book.OnNativeStep(observation, int64(i+102), []NativeBatch{batch}); err != nil {
				t.Fatal(book.result.Key, err)
			}
		}
		for key, book := range old {
			if err := book.OnNativeStep(observation, int64(i+102), []legacy.NativeBatch{{Method: batch.Method, Delta: batch.Delta}}); err != nil {
				t.Fatal(err)
			}
			proof, err := CompareLegacy113(books[key].Snapshot(), book.Snapshot())
			if err != nil || !proof.AllFinancialEqual {
				t.Fatal(key, err, proof)
			}
		}

	}
	result := map[string]ActualResult{}
	for key, book := range books {
		value, err := book.Finish()
		if err != nil {
			t.Fatal(err)
		}
		result[key] = value
	}
	for key, book := range old {
		value, err := book.Finish()
		if err != nil {
			t.Fatal(err)
		}
		if _, err = CompareLegacy113(result[key], value); err != nil {
			t.Fatal(err)
		}
	}
	return result
}

// TestEntryModes114 はT/R/偽/未知を12条件で区別し全A0同体を検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。未知を偽へ補完せず入力不足を保持します。
func TestEntryModes114(t *testing.T) {
	for _, kind := range []string{"trend", "reversal", "false", "missing"} {
		result := actorFixture114(t, 1, kind)
		for key, book := range result {
			want := book.Config.EntryMode == "A0" || kind == "trend" || kind == "reversal" && book.Config.EntryMode == "TR"
			row := book.EntryGate.Records[0]
			if !reflect.DeepEqual(row.Decision, result["A0_C0_D0"].EntryGate.Records[0].Decision) {
				t.Fatal("入口モード/費用/遅延で元固定票が異なる")
			}
			if row.Allowed != want || (book.Metrics.EntryFills > 0) != want || len(book.EntryGate.Records) != 1 {
				t.Fatalf("%s/%s:票と実取得差 %+v", kind, key, row)
			}
			if kind == "missing" && (row.Decision.Trend != gate.Unknown || len(row.Decision.MissingInputs) == 0) {
				t.Fatal("未知を隠した")
			}
			if kind == "reversal" && (row.Decision.Trend != gate.False || row.Decision.Reversal != gate.True || row.Decision.Combined != gate.True) {
				t.Fatal("T/R/ORの三値差")
			}
		}
	}
}

// TestEntryMirrorAndFeeEvidence114 は買売鏡像の金額と費用非依存の技法証拠を確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。取得/容量の事実と凍結Decisionを別に比較します。
func TestEntryMirrorAndFeeEvidence114(t *testing.T) {
	buy, sell := actorFixture114(t, 1, "reversal"), actorFixture114(t, -1, "reversal")
	for key, book := range buy {
		if book.Totals != sell[key].Totals {
			t.Fatal("売買鏡像の金額差", key)
		}
		other := buy[fmt.Sprintf("%s_C5_D%d", book.Config.EntryMode, book.Config.DelaySeconds)]
		if !reflect.DeepEqual(book.EntryGate.Records[0].Decision, other.EntryGate.Records[0].Decision) {
			t.Fatal("費用で技法票差", key)
		}
	}
}

// TestEntryFrameCorruptionAndSnapshot114 は未来公表と返却値の参照改変を拒否/分離します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。元公表値を0やマスクへ置換しません。
func TestEntryFrameCorruptionAndSnapshot114(t *testing.T) {
	cfg := ActorConfig{Policy: "P100", EntryMode: "A0"}
	book, err := NewContinuousBook(session94(), "人工限月114", cfg)
	if err != nil {
		t.Fatal(err)
	}
	frame := frame114(1, 1, "trend")
	if err = book.SetEntryFrame(frame, gate.Stamp{Time: frame.End - 1, Index: 3, Line: 100}); err == nil {
		t.Fatal("未来Frameを受理")
	}
	result := actorFixture114(t, 1, "trend")
	original := result["A0_C0_D0"]
	corrupt := valueCopy(original)
	corrupt.EntryGate.Records[0].Decision.Current.Frame.EMA8 = -1
	if original.EntryGate.Records[0].Decision.Current.Frame.EMA8 < 0 {
		t.Fatal("証拠copyの参照共有")
	}
	if _, err = NewContinuousBook(session94(), "人工限月114", ActorConfig{Policy: "E100", EntryMode: "A0"}); err == nil {
		t.Fatal("追加E政策を受理")
	}
}

// TestEntryComparisonCorruptions114 は金融・保護State・新ゲート偽装を対照から隠さないことを検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。比較用旧値は同型JSONから人工的に復元します。
func TestEntryComparisonCorruptions114(t *testing.T) {
	current := actorFixture114(t, 1, "trend")["A0_C0_D0"]
	raw, _ := json.Marshal(current)
	var prior legacy.ActualResult
	_ = json.Unmarshal(raw, &prior)
	prior.Config = legacy.ActorConfig{Policy: "P100"}
	prior.Key = "P100_C0_D0"
	prior.StreamScope = legacy.ContinuousScope113
	// 本人工は各受理原行の本当の旧対照も別途成功済みです。破壊拒否は同じ新旧IDで検査します。
	value, _ := comparisonJSON114(current)
	obj := value.(map[string]any)
	proof := LegacyComparison114{}
	normalizeIDs114(obj, current.Session.ID+"-"+current.Key+"-", current.Session.ID+"-"+prior.Key+"-", &proof)
	raw, _ = json.Marshal(obj)
	_ = json.Unmarshal(raw, &prior)
	prior.Config = legacy.ActorConfig{Policy: "P100"}
	prior.Key = "P100_C0_D0"
	prior.StreamScope = legacy.ContinuousScope113
	if _, err := CompareLegacy113(current, prior); err != nil {
		t.Fatal(err)
	}
	for _, kind := range []string{"net", "state", "gate"} {
		bad := valueCopy(current)
		switch kind {
		case "net":
			bad.Totals.NetYen++
		case "state":
			bad.Positions[0].Protection113.FinalState.ClosedNetYen++
		case "gate":
			bad.EntryGate.Records[0].Allowed = false
		}
		if _, err := CompareLegacy113(bad, prior); err == nil {
			t.Fatal("破壊を隠した", kind)
		}
	}
}

// TestEntryCapAndConsumedRejections114 は容量拒否と技法拒否を分け、後の空きで出生を復活させません。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。Source全通知は各モードへ同じまま配送します。
func TestEntryCapAndConsumedRejections114(t *testing.T) {
	scene := session94()
	source := newFixtureSource94()
	books := map[string]*ActualBook{}
	for _, cfg := range DeclaredContinuousConfigurations() {
		book, err := NewContinuousBook(scene, "人工限月114", cfg)
		if err != nil {
			t.Fatal(err)
		}
		for ordinal := 1; ordinal <= 2; ordinal++ {
			frame := frame114(1, ordinal, "trend")
			if err = book.SetEntryFrame(frame, gate.Stamp{Time: frame.End, Index: ordinal - 1, Line: int64(99 + ordinal)}); err != nil {
				t.Fatal(err)
			}
		}
		books[book.result.Key] = book
	}
	for i := 0; i < 6; i++ {
		observation := observation94(scene, 1, int64(i+2), float64(i), 0, 20)
		signals := []native.Signal{}
		cancels := []string{}
		switch i {
		case 0:
			signals = []native.Signal{birth94("買A", 1, 10), birth94("容量C", 1, 1), birth94("売B", -1, 10)}
		case 1:
			signals = []native.Signal{birth94("容量F", 1, 2)}
		case 2:
			signals = []native.Signal{close94("A全残", "買A", 1, 10), close94("C全残", "容量C", 1, 1), close94("B全残", "売B", -1, 10), close94("F全残", "容量F", 1, 2)}
		case 4:
			signals = []native.Signal{birth94("即取消Z", 1, 5)}
			cancels = []string{"即取消Z"}
		}
		batch := source.step(t, observation, int64(i+102), signals, cancels)
		for key, book := range books {
			if err := book.OnNativeStep(observation, int64(i+102), []NativeBatch{batch}); err != nil {
				t.Fatal(key, err)
			}
		}
	}
	for key, book := range books {
		result, err := book.Finish()
		if err != nil {
			t.Fatal(err)
		}
		if result.Metrics.CapRejectedEntries != 2 || len(result.EntryGate.Records) != 5 {
			t.Fatal(key, "容量又は出生数差", result.Metrics)
		}
		for _, row := range result.EntryGate.Records {
			if row.Request.SignalID == "容量C" || row.Request.SignalID == "容量F" {
				if !row.Allowed || row.CapQuantity != 0 || row.AcceptedQuantity != 0 || row.ActualQuantity != 0 {
					t.Fatal("容量拒否を技法拒否と混同")
				}
				if id, exists := book.entryBySource[sourceKey(row.Request.Method, row.Request.SignalID)]; !exists || id != "" {
					t.Fatal("拒否出生の消費を保存しない")
				}
			}
			if row.Request.SignalID == "売B" && result.Config.EntryMode != "A0" && (row.Allowed || row.Selected != gate.False || row.ActualQuantity != 0) {
				t.Fatal("技法拒否を容量拒否と混同")
			}
			if row.Request.SignalID == "即取消Z" && (!row.SourceCancelled || row.ActualQuantity != 0 || row.AcceptedQuantity != 0) {
				t.Fatal("元取消を復活")
			}
		}
	}
}

// TestExportEntry114 は明示環境時だけ買売12冊と実宣言を人工保存します。
//
// 引数: t(*testing.T)、環境CONTINUOUS114_EXPORT_DIR(string)は試験器と新規先です。
// 返り値: なし。市場/Raw/FAR自然生成を実行しません。
func TestExportEntry114(t *testing.T) {
	directory := os.Getenv("CONTINUOUS114_EXPORT_DIR")
	if directory == "" {
		t.Skip("人工export指定時だけ")
	}
	if _, err := os.Stat(directory); !os.IsNotExist(err) {
		t.Fatal("人工は新規先だけ")
	}
	if err := os.MkdirAll(directory, 0755); err != nil {
		t.Fatal(err)
	}
	values := map[string]any{"買い": actorFixture114(t, 1, "reversal"), "売り": actorFixture114(t, -1, "reversal"), "市場": false, "FAR自然生成": false}
	for name, value := range map[string]any{"宣言設定.json": DeclaredContinuousConfigurations(), "買売人工.json": values, "入口定義.json": gate.DeclaredDefinition()} {
		body, err := json.MarshalIndent(value, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(filepath.Join(directory, name), append(body, '\n'), 0600); err != nil {
			t.Fatal(err)
		}
	}
}
