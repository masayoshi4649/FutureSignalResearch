"""114の市場前設計・版6設定表を、固定済み113とカタログから準備する。"""

import hashlib
import json
from pathlib import Path
import re


def sha(path: Path) -> str:
    """機能: 明示された文書・metadataのSHA256を求める。

    引数: path(Path)は固定参照または新資料。
    返り値: strは全バイトSHA。原板やNative本文は渡さない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """機能: 未固定・未市場実行の114資料だけを新規作成する。

    引数: なし。リポジトリの位置は当ファイルから解決する。
    返り値: None。既存試行・旧条件・市場価格を変更または参照しない。
    """
    root = Path(__file__).resolve().parents[2]
    target = root / 'study/00114_順行と反転の取得確認を分ける'
    assert not target.exists()
    assert max(int(p.name[:5]) for p in (root/'study').iterdir() if p.is_dir() and re.match(r'\d{5}_', p.name)) == 113
    old = root / 'study/00113_起動前の支持否定と利益保護の切替'
    prior = json.loads((old/'検査/完了記録.json').read_text(encoding='utf-8'))
    old_table = old / '設定と結果.md'
    assert sha(old_table) == prior['最終参照SHA256'][str(old_table)]
    catalogue = root / 'scripts/レポート/手法カタログ_版6.json'
    assert sha(catalogue) == '5c383fc2e6f39e96d0163fe1c84d97d57eaf4e41424f521631e59c5d431a4a42'
    source = old_table.read_text(encoding='utf-8')
    matrix = source.split('## 手法×時間スケール', 1)[1].split('## 設定明細', 1)[0]
    matrix = '## 手法×時間スケール' + matrix
    overrides = {
        ('I01', 2): '入口S18/S19：EMA8/21の配置・現前傾き・Close位置→R05〜12。収束Cは診断のみ',
        ('I03', 2): '入口S18/S19：Tのside×Hist>0、Rのside×ΔHist>0→R05〜12。起動後MはS07',
        ('C06', 0): '共通S12〜15：P100・H100必須起動/最低費用床/全玉床/非緩和→全R',
        ('C06', 2): '共通S07/S09〜11/S13：M AND 動的Pの狭幅と取得後構造床→全R',
        ('P01', 2): '入口S18/S19：CloseとEMA8の現前位置・奪還。共通S05/S09〜11：確定OHLC・尺度・構造',
        ('P02', 2): '共通S10/S11：動的pivot否定と取得後構造床→全R。取得時固定支持Eは追加未使用',
        ('P03', 2): '共通S10/S11：動的支持否定と取得後構造床→全R。固定支持失効の追加なし',
        ('P05', 2): '入口S18/S19：EMA現前差/Hist増分。共通S07：保護のMACD失速',
        ('E02', 0): '共通S12〜16：一定利益H100の連続保護・費用床/全玉床・厳密後原行fill→全R',
    }
    rows = []
    method_count = 0
    for line in matrix.splitlines():
        m = re.match(r'^\| ([A-Z]\d{2}) \|', line)
        if m:
            fields = [x.strip() for x in line.strip().strip('|').split('|')]
            assert len(fields) == 11
            method_count += 1
            for col in range(9):
                cell = overrides.get((m[1], col), fields[col+2])
                cell = re.sub(r'R\d{2}〜24', '全R', cell)
                cell = cell.replace('R09〜12/R17〜20', '全R').replace('P/E', 'P100')
                fields[col+2] = cell
            line = '| ' + ' | '.join(fields) + ' |'
        rows.append(line)
    assert method_count == 56
    baseline = []
    for line in source.splitlines():
        m = re.match(r'^\| S(\d{2}) \|', line)
        if not m or int(m[1]) > 17:
            continue
        line = re.sub(r'R\d{2}〜24', '全R', line)
        line = line.replace('H100は100、H50は50。S0は追加Stateなし', '全RはH100=100。H50/E/S0の追加比較はしない')
        line = line.replace('H100:全R、H50:R13〜16/R21〜24', '全RはH100')
        line = line.replace('H100:R05〜12/R17〜20、H50:R13〜16/R21〜24', '全RはH100')
        line = line.replace('P/Eだけ', '全R共通P100で').replace('W100は狭幅なし。', '')
        line = line.replace('Eの別要求はS22', '追加E失効の要求はない')
        line = line.replace('S19のanchor', '113Eの固定anchor').replace('S19の取得前既知固定支持', '113Eの取得前既知固定支持')
        line = line.replace('起動水準の変更はS18', '起動水準は全RでH100固定')
        line = line.replace('元源保護全起動0ではない', '元源保護全起動0ではない（旧対照の定義）')
        line = line.replace('全R、独立全1,680会計', '全R、12条件×全予定場。未実行')
        baseline.append(line)
    assert len(baseline) == 17
    settings = '\n'.join(baseline) + '''
| S18 | I01/I03/P01・確定3分のT | 配置G=s(EMA8−EMA21)、a8=sΔEMA8、a21=sΔEMA21、x8=s(Close−EMA8)、z=sHist | G>0 AND a8>0 AND a21>0 AND x8>0 AND z>0。現在水準と傾きを分ける | 履歴はS20、要求原行でS21へfreeze。Hist不足は未知票 | T/TRのR05〜12。A0も診断保存 | EMA/Histは価格履歴が重なり独立の二票ではない |
| S19 | I01/I03/P01・確定3分のR | G<0、a8>0、x8p=s(Close_p−EMA8_p)、x8=s(Close_t−EMA8_t)、h=s(Hist_t−Hist_p) | G<0 AND a8>0 AND x8p<=0 AND x8>0 AND h>0。a21/z条件は付けない | 逆配置からのfast線奪還イベント。h=0は改善成立でない。Rは元Sourceの同方向新規を許可するだけ | TRのR09〜12。全Rで診断保存 | 静的な価格位置と新しい奪還を混同しない |
| S20 | 公表履歴・原行順 | 現在/前Frameの既知値、ID、Ordinal、場/限月、End/AvailableAt、実配送quote | 前足End差180秒、同場/限月・reset/欠足なし。同ID再配送で履歴を進めない | batch.Events実順、要求原行まで配送済みのみ。同秒後行や未来値は不使用 | 全R、両費用でも同じ当時技法証拠 | 名目足終端へ遡及せず、15分場末snapshotも使わない |
| S21 | A0/T/TRの入口選別 | A0は元全出生、TはT真、TRは三値T OR Rが真 | 買+1/売−1の対称。偽/未知は見送りで一度消費、後足で復活しない | 要求時にfreeze、fillでは再ゲートしない。Source内部/数量/取消/予約は共通 | R01〜04=A0、R05〜08=T、R09〜12=TR | 源への実保護返送/反対注文生成/新しい独自再参加なし |
| S22 | 証拠と分母 | 全Source new要求のT/R/OR、値/増分/Known、通過/偽/未知、容量/取消/実取得 | 三値AND/OR。判定未知と入力欄欠測件数は別。0は未知へ置換しない | 上限拒否でgate拒否を代用しない。Source要求を分母から落とさない | 全R、独立検算は後段 | 出生を費用4条件で反復した件数を独立機会数にしない |
| S23 | 対照と評価 | 113P100四費用とA0の全金融/保護を説明差だけ分けて比較、Source全文同体 | first2→元54→全70。全70は同F1成功54参照再用+16再生 | 全12の純額/利益損失/利益後赤字/DD/回数/数量、全予定場を記録 | 全R。未実行・未知安定性未確認 | 未参加/退出後仮想利益/機会損失/最高点利確の仮額は作らない |
'''
    result_rows = []
    configs = []
    for mode in ('A0', 'T', 'TR'):
        for slip in (0, 5):
            for delay in (0, 1):
                rid = f'R{len(configs)+1:02d}'
                key = f'{mode}_C{slip}_D{delay}'
                configs.append({'policy':'P100', 'entry_mode':mode, 'slip_pts':slip, 'delay_seconds':delay})
                result_rows.append(f'| {rid} | {key} | S01〜23。保護P100共通、入口{mode} | 未固定・市場未実行 |')
    text = '# 00114：設定と結果\n\n2026-11-10。版6・56手法×9尺度。実装準備中、金融条件は未固定・市場未実行。採用なし。\n\n[仮説と条件](README.md) / [使用した汎用表](../../docs/議論/手法と時間スケールの汎用表_版6.md) / [元手法の技法対応](../00112_支持否定の確認と通常追尾幅の比較/診断/元三手法の技法/調査.md)\n\n'
    text += '113の共通保護・源特徴の使用セルを引き継ぎ、入口S18〜23だけを追加した。源内部の全504セルの完全対応は未監査。「追加未使用」は源でも未使用という意味ではない。C/BBは診断、15分は準備のみ。3分指標と逐次新規判断の時計は別。\n\n'
    text += '\n'.join(rows) + '\n\n## 設定明細（市場前の案）\n\n| 設定ID | 手法・尺度 | 役割 | 計算と閾値 | 時計と未知 | 対象 | 注記 |\n| --- | --- | --- | --- | --- | --- | --- |\n' + settings
    text += '\n## 複合条件と結果\n\n| 評価ID | 候補 | 設定 | 結果 |\n| --- | --- | --- | --- |\n' + '\n'.join(result_rows) + '\n'
    target.mkdir()
    (target/'設定と結果.md').write_text(text,encoding='utf-8')
    proposal = {'version':1,'trial':114,'fixed':False,'market_executed':False,'purpose':'P100共通保護の下で元入口/順行T/T又は回復Rを分離する','configurations':configs,'T':'G>0 AND a8>0 AND a21>0 AND x8>0 AND side*Hist>0','R':'G<0 AND a8>0 AND x8p<=0 AND x8>0 AND side*deltaHist>0','source':'111の元原行連続・Source非返送・研究新規時計なし','input_scope':'既使用70場、11/09は価格/損益/入力指紋未読','catalogue_sha256':sha(catalogue),'basis_completion_sha256':sha(old/'検査/完了記録の追補.json'),'baseline_settings_sha256':sha(old_table),'adopted':False,'stable_profit_proven':False}
    (target/'設計候補.json').write_text(json.dumps(proposal,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'試行':114,'状態':'未固定・市場未実行','手法':method_count,'尺度':9,'設定':23,'候補費用':12,'設定表SHA256':sha(target/'設定と結果.md')},ensure_ascii=False))


if __name__ == '__main__':
    main()
