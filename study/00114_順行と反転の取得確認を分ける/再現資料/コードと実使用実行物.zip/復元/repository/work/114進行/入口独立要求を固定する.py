"""114金融の全成功を先に認証し、指定段階だけの入口独立監査を解禁する。"""

import argparse
import hashlib
import json
from pathlib import Path


def ref(path: Path, expected: str | None = None) -> dict:
    """機能: 小metadataの実SHAを求め、指定時は期待指紋を認証する。

    引数: path(Path)、expected(str|None)は対象と期待値。
    返り値: dictは絶対path/sha256。Native本文やRawには使わない。
    """
    path = path.resolve()
    actual = hashlib.sha256(path.read_bytes()).hexdigest()
    assert expected is None or actual == expected, str(path)
    return {'path':str(path),'sha256':actual}


def main() -> None:
    """機能: Root金融成功を、停止済み入口監査の新規固定要求へ結ぶ。

    引数: CLI --stage/--completion/--sha256(str)は段階・成功JSON・期待SHA。
    返り値: None。Nativeを読まず要求metadataだけを新規保存する。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('--stage',choices=('first2','base54','full70'),required=True)
    parser.add_argument('--completion',required=True,type=Path)
    parser.add_argument('--sha256',required=True)
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[2]
    fixed=ref(root/'work/114進行/F2_114金融条件_設計原文参照.json','b0bf17c4bcd435dcca13da12995a11a9c6f5617f86a27ca2f0994528a3823167')
    completion=ref(args.completion,args.sha256)
    value=json.loads(Path(completion['path']).read_text(encoding='utf-8'))
    n={'first2':2,'base54':54,'full70':70}[args.stage]
    assert value['trial']==114 and value['stage']==args.stage and value['success']
    assert value['sessions']==n and value['books']==12*n and value['condition_sha256']==fixed['sha256']
    assert value['all_reference113_equal'] and value['all_source111_equal'] and value['reference113_comparisons']==4*n
    assert value['unchanged'] and value['before']==value['after']
    request={'version':1,'trial':114,'fixed':True,'market_native_read_authorized':True,'stage':args.stage,
             'condition':fixed,'completion':completion,
             'entry_stop':ref(root/'work/114入口判定を独立検算する/停止.json','369eda8990de9faa430ca575b3cf6f114abf73bea1cfebf32522ceef166f1eb6'),
             'entry_code':ref(root/'work/114入口判定を独立検算する/検算する.py','b4567bf7a534d825ee3461993ab3165277698c5fe36b1443280af4f3439ba5f1')}
    output=root/f'work/114進行/{args.stage}_入口独立要求.json'
    with output.open('x',encoding='utf-8') as stream:
        stream.write(json.dumps(request,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'要求':ref(output),'予定場':n,'Native本文読取':0},ensure_ascii=False))


if __name__=='__main__':
    main()
