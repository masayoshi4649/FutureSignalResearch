"""全成功の114金融だけを、独立会計・P・入口・Viewer保存へ渡す。"""

import argparse
import hashlib
import json
from pathlib import Path


def reference(path: Path, expected: str) -> dict:
    """機能: 明示した小metadata・コードをSHA認証する。

    引数: path(Path)、expected(str)は対象と期待指紋。
    返り値: dictは絶対path/sha256。Raw/Native本文には使わない。
    """
    path=path.resolve()
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected,str(path)
    return {'path':str(path),'sha256':expected}


def main() -> None:
    """機能: 全12Nの金融成功・全旧対照・入力不変を認証し新要求を作る。

    引数: CLI stage/completion/sha256(str)は段階と成功JSON。
    返り値: None。正式CSVや金融損益の変更、Raw/Native読取を行わない。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('--stage',choices=('first2','base54','full70'),required=True)
    parser.add_argument('--completion',type=Path,required=True)
    parser.add_argument('--sha256',required=True)
    args=parser.parse_args()
    root=Path(__file__).resolve().parents[2]
    condition=reference(root/'work/114進行/F2_114金融条件_設計原文参照.json','b0bf17c4bcd435dcca13da12995a11a9c6f5617f86a27ca2f0994528a3823167')
    completion=reference(args.completion,args.sha256)
    data=json.loads(Path(completion['path']).read_text(encoding='utf-8'))
    n={'first2':2,'base54':54,'full70':70}[args.stage]
    assert data['success'] and data['trial']==114 and data['stage']==args.stage
    assert data['condition_sha256']==condition['sha256'] and data['sessions']==n and data['books']==12*n
    assert data['unchanged'] and data['before']==data['after']
    assert data['all_reference113_equal'] and data['all_source111_equal'] and data['reference113_comparisons']==4*n
    old_path=root/'study/00113_起動前の支持否定と利益保護の切替/再現資料/独立保存要求_full70.json'
    reference(old_path,'c5f9f48fbf5f03f3ce8c46a2c46ba2837af81b6ad3041acfaa4f1326d7c1c11f')
    old=json.loads(old_path.read_text(encoding='utf-8'))
    market_paths={row['session']:row['market_path'] for row in old['scenes']}
    request={'version':1,'trial':114,'fixed':True,'market_native_read_authorized':True,'stage':args.stage,
             'condition':condition,'completion':completion,
             'code_stop':reference(root/'work/114利益保護を固定した入口比較の会計/会計停止.json','1c746b02409398afcbd70f4aea6362ddb3da0a30e80fa0c7ca4aba0139a8373c'),
             'P_stop':reference(root/'work/114利益保護を固定した入口比較の会計/P停止.json','f2c19983d428fd0bf6dbc49266751fb08498ed10bd754505bc6bed577ccd72dd'),
             'actor_stop':reference(root/'work/114順行反転取得を執行する会計/Actor停止.json','2178d1fbe7b980d7f507d6d9c99c6cdef1a8bde8702e4e4a69dbe97b687a9b93'),
             'protection_code':reference(root/'work/114利益保護を固定した入口比較の会計/新保護の独立監査.py','b6a31c84f0ac7378ad96423221035fdd03bb8ba7ea1aaef2c41e13166eb9b7d9'),
             'entry_stop':reference(root/'work/114入口判定を独立検算する/停止.json','369eda8990de9faa430ca575b3cf6f114abf73bea1cfebf32522ceef166f1eb6'),
             'entry_code':reference(root/'work/114入口判定を独立検算する/検算する.py','b4567bf7a534d825ee3461993ab3165277698c5fe36b1443280af4f3439ba5f1'),
             'scenes':[]}
    for row in data['results']:
        sid=row['session']
        assert row['complete'] and row['books']==12 and row['reference113_equal'] and row['source111_equal']
        assert row['A0_equal'] and row['A0_comparisons']==4 and row['open_quantity']==row['pending_quantity']==0
        request['scenes'].append({'session':sid,'native':row['native'],'reference113':row['reference113'],
                                  'history_class':'original54' if sid[:10]<='2026-10-27' else 'additional16',
                                  'market_path':market_paths[sid]})
    assert len(request['scenes'])==n
    output=root/f'work/114進行/{args.stage}_独立保存要求.json'
    with output.open('x',encoding='utf-8') as stream:
        stream.write(json.dumps(request,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'要求':{'path':str(output),'sha256':hashlib.sha256(output.read_bytes()).hexdigest()},'場数':n,'Raw_Native本文読取':0},ensure_ascii=False))


if __name__=='__main__':
    main()
