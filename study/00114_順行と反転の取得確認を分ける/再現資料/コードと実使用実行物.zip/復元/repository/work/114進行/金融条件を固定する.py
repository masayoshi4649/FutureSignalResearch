"""114の実宣言と停止済み実装を認証し、市場を見る前のRoot金融F1を作る。"""

import argparse
import hashlib
import json
from pathlib import Path


def digest(path: Path) -> str:
    """機能: 明示されたコードまたは小metadataを認証する。

    引数: path(Path)は固定宣言・停止・コード・実行物。
    返り値: strはSHA256。市場Raw・Native本文をこの関数へ渡さない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_verified(path: Path, expected: str) -> dict:
    """機能: 期待SHAで認証したJSONだけを読む。

    引数: path(Path)、expected(str)は対象と期待指紋。
    返り値: dictはUTF-8 JSON。固定金融の改変・実行はしない。
    """
    assert digest(path) == expected, str(path)
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main() -> None:
    """機能: 市場前の12実宣言・共通保護・全閉包を検査し、新規F1を固定する。

    引数: CLIの--material/--sha256/--stop-sha256(str)はCore素材と期待SHA。
    返り値: None。条件を新規保存する。Raw・価格CSV・Native本文・11/09は読まない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--material', required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--stop-sha256', required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[2]
    target = root/'work/114進行/F1_114金融条件.json'
    assert not target.exists()
    value = read_verified(Path(args.material).resolve(), args.sha256)
    assert value['version'] == 1 and value['trial'] == 114 and value['fixed'] is False
    assert value['policy'] == 'original166_source111_p100_entry_confirmation114'
    assert value['actual_policy'] == 'p100_entry_confirmation114' and value['source_trial'] == 111
    expected = [{'policy':'P100', 'slip_pts':slip, 'delay_seconds':delay, 'entry_mode':mode}
                for mode in ('A0','T','TR') for slip in (0,5) for delay in (0,1)]
    assert value['actual_configurations'] == expected
    assert len(value['protection_configurations']) == 4 and value['protection_definition']['policy'] == 'P100'
    protection = value['protection_definition']
    assert protection['enabled'] and protection['threshold_points'] == 100
    assert protection['normal_width_minimum'] == 200 and protection['atr_multiplier'] == 2
    assert protection['warning_formula'] == 'M AND P' and protection['technical_narrowing'] is True
    assert protection['entry_invalidation_enabled'] is False
    assert value['entry_gate_definition']['version'] == 114
    assert value['entry_gate_definition']['modes'] == ['A0','T','TR']
    assert value['entry_gate_definition']['refill_evaluation'] is False
    assert value['entry_grid_seconds'] is None and value['extra_opening_quiet_seconds'] == 0
    assert value['chart_seed_mode'] == 'cold_each_session' and value['parallel_max_workers'] == 16
    stop_ref = value['runtime_stop']
    assert stop_ref['sha256'] == args.stop_sha256
    stop = read_verified(Path(stop_ref['path']), args.stop_sha256)
    assert stop['成功'] and stop['停止'] and stop['trial'] == 114
    declared_code = dict(stop['全固定コードSHA256'])
    declared_code[stop_ref['path']] = args.stop_sha256
    assert declared_code == value['code_sha256']
    for name, expected_sha in value['code_sha256'].items():
        assert digest(Path(name)) == expected_sha, name
    refs = [value[name] for name in ('executable','manifest','actual_declaration','pure_declaration','chart_declaration','entry_gate_declaration')]
    refs += list(value['dependency_stops'].values()) + list(value['reference113'].values())
    for ref in refs:
        assert digest(Path(ref['path'])) == ref['sha256'], ref['path']
    assert value['dependency_stops'] == stop['依存停止']
    basis = root/'study/00113_起動前の支持否定と利益保護の切替/検査/完了記録の追補.json'
    read_verified(basis,'cd6187bbf4ac665e1da94b0f62f86db3524b2edc64fc1d6062395ca179e1fdc1')
    trial = root/'study/00114_順行と反転の取得確認を分ける'
    proposal = json.loads((trial/'設計候補.json').read_text(encoding='utf-8'))
    assert proposal['fixed'] is False and proposal['market_executed'] is False
    value['fixed'] = True
    value['research_basis'] = {
        '113の完了':{'path':str(basis),'sha256':digest(basis)},
        '市場前の設計':{name:{'path':str(trial/name),'sha256':digest(trial/name)} for name in ('設計候補.json','README.md','設定と結果.md')},
        '選択':'元入口A0・MA配置/二傾き/Close位置/Hist水準のT・T又は逆配置からの価格奪還/fast傾き/Hist増分のTR。保護P100と源数量を共通に固定。',
        '分母':'全Source新規要求。入力不足と既知否定、容量/取消/実受付/実取得を別記。',
        '費用と限界':'mini100円/pt・片道38.5円・片側10枚、追加滑り0/5pt・追加価格時計遅延0/1秒。ラージBBO代理・Source非返送・既使用70場。',
        '11月09':'価格・損益・入力指紋は未読を維持。',
        '合格条件':'従来125/250先着・70%・固定時計参加率は一旦合否対象外。費用後安定性と利益保護を比較、先読み/費用/品質の検査は維持。',
        '機会損失評価':False,
    }
    raw = (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    with target.open('xb') as stream:
        stream.write(raw)
    print(json.dumps({'成功':True,'固定条件':{'path':str(target),'sha256':hashlib.sha256(raw).hexdigest()},'全コード':len(value['code_sha256']),'候補費用':12,'市場読取':0},ensure_ascii=False))


if __name__ == '__main__':
    main()
