"""114の全成功・CSV・実現差・記述診断を、重複を避けた正式保存要求へ束ねる。"""

import gzip
import hashlib
import json
from pathlib import Path


def ref(path: Path, expected: str | None = None) -> dict:
    """機能: 明示した文書・小metadata・コード・圧縮診断を認証する。

    引数: path(Path)、expected(str|None)は対象と任意の期待指紋。
    返り値: dictは絶対path/sha256。Raw/Native本文には使用しない。
    """
    path=path.resolve()
    actual=hashlib.sha256(path.read_bytes()).hexdigest()
    assert expected is None or expected==actual,str(path)
    return {'path':str(path),'sha256':actual}


def write_new(path: Path, data: bytes) -> dict:
    """機能: 明示した新規先だけへ根拠を保存する。

    引数: path(Path)、data(bytes)は出力先と内容。
    返り値: dictは保存後の指紋。既存ファイルは上書きしない。
    """
    with path.open('xb') as stream:
        stream.write(data)
    return ref(path)


def main() -> None:
    """機能: 840会計・全入口票・同入口実現差とCSVの成功Refを新規固定する。

    引数: なし。Rootが実行済みのF2と成功正本だけを使用する。
    返り値: None。金融再実行、Raw/価格CSV本文/Native本文の読取は行わない。
    """
    root=Path(__file__).resolve().parents[2]
    here=Path(__file__).resolve().parent
    source=root/'work/114正式保存への接続_入口票の零項目/Root正式要求の素材.json'
    ref(source,'5937b84a5b202b2ac9a536fb4934778874e30a29194ed2b1f5dcb9b9925614d6')
    request=json.loads(source.read_text(encoding='utf-8'))
    assert request['trial']==114 and request['fixed'] is False
    for key,path,expected in (
        ('market','work/114金融F2/全70場/完了.json','2589160f6e86e618a64372a52cad0abd76e19e5b49d607897f758604600a0b18'),
        ('result','work/114独立保存F2/全70場/結果.json','28006bfa74cee9ac93e85496590c4b93479bc0c7d31080c3b2f1eeb938d9fb1c'),
        ('saved_check','work/114独立保存F2/全70場/保存会計の確認.json','301c2b4359484ba2e4a4748dae4c069201ed03c959ff10be452531ad200a34b7'),
        ('entry_check','work/114入口独立F2/全70場/結果.json','5e5bc4e9ceeba8a1522becc5842a7dc259f94d18b8d527447d1f912496f15b1f'),
        ('csv_check','outputs/01a1889f-f2af-7943-a047-543275ee9ed2/114損益CSV/CSVの独立再読.json','1ea6ab25e9e6fee6a400369bdc130c598d790d992e7b464bffd1801121f5c7f5'),
    ):
        request['refs'][key]=ref(root/path,expected)
    csv_root=root/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/114損益CSV'
    request['csv_refs']={name:ref(csv_root/name,expected) for name,expected in (
        ('候補別集計.csv','de1cab06ee857c23736aec14da20695346c70bdefcf14e2fef5dda7dcf35a57d'),
        ('全セッション.csv','9f48e7cfef1bfe403e7b7a1fafc243a1fa5f628259548ae1cfbf00d6326ad70a'))}
    for item in request['refs'].values():
        ref(Path(item['path']),item['sha256'])

    # ----------------------------------------
    comparison=root/'work/114同入口と要求時技法の実現差/全70の実現差'
    original=ref(comparison/'結果.json','775b5f29349fa8e8d43caee63b094fe7edd247ae2fdb32342c9d730fdabd5843')
    body=Path(original['path']).read_bytes()
    compressed=write_new(here/'同入口と要求時技法の実現差.json.gz',gzip.compress(body,mtime=0))
    assert gzip.decompress(Path(compressed['path']).read_bytes())==body
    ledger=ref(comparison/'実entry対応.jsonl.gz','5be1e1e14c97f3911270cab2d3d09c360c2f28193c3360a1ae56db0af282b1f8')
    records=[json.loads(line) for line in gzip.decompress(Path(ledger['path']).read_bytes()).decode('utf-8').splitlines()]
    assert len(records)==5060
    envelope={'version':1,'元JSONL圧縮参照':ledger,'件数':len(records),'records':records}
    wrapped=write_new(here/'実entry対応.json.gz',gzip.compress(json.dumps(envelope,ensure_ascii=False,separators=(',',':')).encode('utf-8'),mtime=0))
    assert json.loads(gzip.decompress(Path(wrapped['path']).read_bytes()))['records']==records
    request['extra_refs'] += [
        {'ref':compressed,'target':'診断/同入口と要求時技法の実現差.json.gz','role':'原結果JSONを全bytes同体でgzip保存。解凍後SHA775b5f…'},
        {'ref':wrapped,'target':'診断/実entry対応.json.gz','role':'原JSONL5060行をrecords配列へ同値で格納、原圧縮Refを保存。金銭改変なし'},
    ]
    additions=[
        ('検査/同入口診断の停止.json',root/'work/114同入口と要求時技法の実現差/停止.json'),
        ('検査/同入口診断の要求.json',here/'full70_同入口診断要求.json'),
        ('検査/先頭2金融成功.json',root/'work/114金融F2/先頭2場/完了.json'),
        ('検査/先頭2独立保存確認.json',root/'work/114独立保存F2/先頭2場/保存会計の確認.json'),
        ('検査/先頭2入口独立確認.json',root/'work/114入口独立F2/先頭2場/結果.json'),
        ('検査/元54独立保存確認.json',root/'work/114独立保存F2/元54場/保存会計の確認.json'),
        ('再現資料/独立保存要求_first2.json',here/'first2_独立保存要求.json'),
        ('再現資料/独立保存要求_base54.json',here/'base54_独立保存要求.json'),
        ('再現資料/独立保存要求_full70.json',here/'full70_独立保存要求.json'),
        ('再現資料/入口独立要求_full70.json',here/'full70_入口独立要求.json'),
        ('検査/初期固定F1_市場未実行.json',here/'F1_114金融条件.json'),
        ('検査/設計原文参照の確認.json',here/'設計原文参照の確認.json'),
        ('検査/F2固定の監査.json',root/'work/114F2固定の監査/監査.json'),
        ('診断/F2固定の監査.md',root/'work/114F2固定の監査/監査.md'),
        ('検査/CSVの生成確認.json',csv_root/'CSVの確認.json'),
        ('検査/CSV出力の停止.json',root/'work/114損益CSVの出力/人工_停止版/停止.json'),
        ('検査/設定表の結合停止.json',root/'work/114設定表の結果結合準備/人工_停止版/停止.json'),
        ('再現資料/設定表の結合要求.json',here/'全70設定表の結合要求.json'),
        ('検査/設定表の結合確認.json',root/'work/114設定表の結果結合準備/全70の結果版/結合の確認.json'),
    ]
    review=root/'work/114全70実現差のレビュー'
    for name in ('レビュー.md','正本の独立確認.json','Rの当時値の記述診断.md','R25玉の要求時文脈.json','EMA同足の数式確認.json','確認する.py','EMAの同足関係を確認する.py'):
        additions.append(('診断/要求時技法の文脈/'+name,review/name))
    for relative,path in additions:
        request['extra_refs'].append({'ref':ref(path),'target':relative,'role':'実行済み検査・固定原文・市場後の記述診断の根拠'})

    # ----------------------------------------
    codes=[here/name for name in ('研究資料を準備する.py','金融条件を固定する.py','設計根拠を不変参照へ移す.py','入口独立要求を固定する.py','独立保存要求を固定する.py','正式保存要求を作る.py','Viewer取得を確認する.py')]
    codes += [root/'work/114入口判定を独立検算する'/name for name in ('独立式.py','人工検査.py')]
    for stop in (root/'work/114同入口と要求時技法の実現差/停止.json',root/'work/114損益CSVの出力/人工_停止版/停止.json',root/'work/114設定表の結果結合準備/人工_停止版/停止.json'):
        values=json.loads(stop.read_text(encoding='utf-8'))
        for key in ('所有コードSHA256','所有ファイルSHA256'):
            codes.extend(Path(p) for p in values.get(key,{}) if Path(p).suffix in ('.py','.mjs','.md'))
    codes += [review/'確認する.py',review/'EMAの同足関係を確認する.py']
    request['code_refs']=[{'ref':ref(path),'role':'Rootの実使用検査/CSV/表結合/記述診断コード'} for path in dict.fromkeys(codes)]
    request['fixed']=True
    request['market_native_read_authorized']=True
    request.pop('Rootが成功後にbindする必須Ref',None)
    request.pop('Rootが成功後にbindする任意Ref',None)
    output=here/'114正式保存の固定要求.json'
    result=write_new(output,(json.dumps(request,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'要求':result,'コード追加':len(request['code_refs']),'根拠追加':len(request['extra_refs']),'Raw_Native本文読取':0},ensure_ascii=False))


if __name__=='__main__':
    main()
