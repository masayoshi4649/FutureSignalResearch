"""市場未実行の114条件の設計参照だけを原文保存先へ移し、金融部分を不変に保つ。"""

import hashlib
import json
from pathlib import Path
import shutil


def sha(path: Path) -> str:
    """機能: 明示された固定条件・文書のSHA256を求める。

    引数: path(Path)は価格を含まない根拠metadata。
    返り値: strは全バイトSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """機能: 未実行F1を保持し、設計文書の更新に影響されないF2を新規保存する。

    引数: なし。市場前に固定したF1とその期待指紋を使う。
    返り値: None。金融条件・コード・閾値は同一、市場読取や金融実行は行わない。
    """
    root = Path(__file__).resolve().parents[2]
    base = root/'work/114進行'
    old = base/'F1_114金融条件.json'
    assert sha(old) == '45193a0cac5ce98045a4e9a952ebba898b57618a6a940665b38e1f8fa6971989'
    value = json.loads(old.read_text(encoding='utf-8'))
    before = json.loads(old.read_text(encoding='utf-8'))
    destination = root/'study/00114_順行と反転の取得確認を分ける/根拠/市場前原文'
    destination.mkdir(parents=True,exist_ok=False)
    relocation = []
    for name, ref in value['research_basis']['市場前の設計'].items():
        source = Path(ref['path'])
        assert sha(source) == ref['sha256']
        saved = destination/(name+'.txt' if name.endswith('.md') else name)
        shutil.copyfile(source,saved)
        assert sha(saved) == ref['sha256']
        relocation.append({'元参照':dict(ref),'原文保存':{'path':str(saved),'sha256':sha(saved)}})
        ref['path'] = str(saved)
    value['research_basis']['原文保存の理由'] = 'READMEと設定表を結果更新する前の原文を保存。md.txtは元の試行ルートにおける相対リンクを保った原文テキストで、現行報告と区別する。'
    a,b = dict(before),dict(value)
    del a['research_basis'];del b['research_basis']
    assert a == b
    output = base/'F2_114金融条件_設計原文参照.json'
    with output.open('x',encoding='utf-8') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    proof = {'成功':True,'試行':114,'市場前':True,'F1市場実行':False,
             '元固定':{'path':str(old),'sha256':sha(old)},'実行予定固定':{'path':str(output),'sha256':sha(output)},
             '金融条件コード宣言の全値同一':True,'変更':'research_basisの設計参照だけを同bytesの不変原文へ移した',
             '移動ではなく複写':relocation,'Raw読取':0,'Native読取':0,'金融実行':False}
    (base/'設計原文参照の確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'条件':proof['実行予定固定'],'金融全値同一':True,'市場実行':False},ensure_ascii=False))


if __name__ == '__main__':
    main()
