"""114純入口の実Go依存・人工・APIを市場前に固定する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OWNED = ["types.go", "history.go", "evaluate.go", "gate_test.go", "cmd/declaration/main.go", "go.mod", "go.sum", "README.md", Path(__file__).name]
STOPS = {
    "work/収束可変幅の公開配送案/停止.json": "8c426b5791df0c3d327d0224ecfe48baac7c319a6d1fb776672cecdf79733015",
    "work/可変追尾向けの公開チャート/停止.json": "f534631e19d8c04fa6f7beefe295178cd432ae1f099d1b9ef69781b5e4fccad6",
    "work/111連続保護のチャート公開/停止.json": "38c01e07d276310c6c1d803dca11e27979fc9286cf64d9a495e60485ea7264bd",
}


def digest(path: Path) -> str:
    """
    機能: 明示コード/小metadataの全bytes指紋を求める。
    引数: path(Path)。返り値: strはSHA256。市場入力を対象にしない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reference(path: Path) -> dict:
    """
    機能: 明示成果物の絶対FileRefを作る。
    引数: path(Path)。返り値: dictはpath/sha256。
    """
    return {"path": str(path.resolve()), "sha256": digest(path)}


def run(command: list[str], env: dict) -> dict:
    """
    機能: 純Goのコード列挙/人工/宣言/ビルドだけを実行する。
    引数: command(list[str])、env(dict)。返り値: dictは成功ログ。
    """
    value = subprocess.run(command, cwd=HERE, env=env, capture_output=True, text=True, encoding="utf-8", timeout=60)
    record = {"command": command, "exit_code": value.returncode, "stdout": value.stdout, "stderr": value.stderr}
    if value.returncode:
        raise ValueError(json.dumps(record, ensure_ascii=False))
    return record


def go_dependencies(env: dict) -> dict:
    """
    機能: 実コンパイル依存のGo/asm/embed/moduleを列挙して認証する。
    引数: env(dict)。返り値: dictは解決絶対PathからSHA256への写像。
    """
    raw = run(["go", "list", "-deps", "-json", "./..."], env)["stdout"]
    decoder, pos, paths = json.JSONDecoder(), 0, set()
    while pos < len(raw):
        if raw[pos:].strip() == "":
            break
        pos += len(raw[pos:]) - len(raw[pos:].lstrip())
        package, end = decoder.raw_decode(raw, pos)
        pos = end
        folder = Path(package["Dir"])
        for field in ("GoFiles", "CgoFiles", "SFiles", "HFiles", "SysoFiles", "EmbedFiles"):
            for name in package.get(field, []):
                paths.add((folder / name).resolve())
        module = package.get("Module") or {}
        for item in (module, module.get("Replace") or {}):
            if item.get("GoMod"):
                paths.add(Path(item["GoMod"]).resolve())
    paths.add(Path(shutil.which("go")).resolve())
    return {str(path): digest(path) for path in sorted(paths, key=str)}


def main() -> None:
    """
    機能: 10主人工・実定義・実API・Go人工exportと旧不変を停止する。
    引数: なし。返り値: None。Raw/Native/Source/金融市場を実行しない。
    """
    target, out = HERE / "停止.json", HERE / "検査"
    if target.exists() or out.exists():
        raise ValueError("新規停止だけ")
    env = dict(os.environ, CGO_ENABLED="0", GOWORK="off")
    owned = {str((HERE/name).resolve()): digest(HERE/name) for name in OWNED}
    reused, stoprefs = {}, {}
    for name, sha in STOPS.items():
        path = (ROOT/name).resolve()
        if digest(path) != sha:
            raise ValueError("旧停止SHA差:"+name)
        stoprefs[name] = {"path": str(path), "sha256": sha}
        reused[str(path)] = sha
        value = json.loads(path.read_text(encoding="utf-8"))
        for key in ("所有コードSHA256", "参照コードSHA256"):
            for code, expected in value.get(key, {}).items():
                source = Path(code)
                source = (source if source.is_absolute() else ROOT/source).resolve()
                if digest(source) != expected:
                    raise ValueError("旧code差:"+code)
                reused[str(source)] = expected
    closure = go_dependencies(env)
    out.mkdir()
    logs = [run(["go", "test", "-count=1", "-json", "-cover", "./..."], env), run(["go", "vet", "./..."], env), run(["go", "build", "./..."], env), run(["go", "run", "./cmd/declaration"], env), run(["go", "doc", "-all", "."], env)]
    passed = [json.loads(line)["Test"] for line in logs[0]["stdout"].splitlines() if line.startswith("{") and json.loads(line).get("Action") == "pass" and "Test" in json.loads(line)]
    if len(passed) != 10:
        raise ValueError("10主人工不足")
    declaration = json.loads(logs[3]["stdout"])
    if declaration["version"] != 114 or declaration["modes"] != ["A0", "T", "TR"] or "side*Hist_t>0" not in declaration["trend"]:
        raise ValueError("実T/R宣言差")
    (out/"実定義.json").write_text(json.dumps(declaration, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    (out/"API.txt").write_text(logs[4]["stdout"], encoding="utf-8", newline="\n")
    exportenv = dict(env, ENTRYGATE114_ARTIFICIAL_OUTPUT=str((out/"人工.json").resolve()))
    logs.append(run(["go", "test", "-run", "^TestExportArtificial$", "-count=1", "."], exportenv))
    artificial = json.loads((out/"人工.json").read_text(encoding="utf-8"))
    if len(artificial["cases"]) != 16 or len(artificial["truth_tables"]) != 9 or artificial["市場Raw"] is not False:
        raise ValueError("人工export集合差")
    if any(digest(Path(p)) != sha for p, sha in {**owned, **reused, **closure}.items()):
        raise ValueError("全code前後不変不足")
    value = {"成功": True, "停止": True, "市場前": True, "trial": 114, "module": "github.com/masayoshi4649/SessionTradeExecuter/entrygate114", "UTC": datetime.now(timezone.utc).isoformat(),
             "所有コードSHA256": owned, "再用コードSHA256": reused, "実Go依存SHA256": closure, "全所有依存前後不変": True, "依存停止": stoprefs,
             "主人工": 10, "成功test": passed, "実定義": reference(out/"実定義.json"), "実API": reference(out/"API.txt"), "Go人工": reference(out/"人工.json"), "人工Decision数": 16, "三値表": 9,
             "検査ログ": logs, "Raw/Native/価格CSV/11月09本文読取": 0, "金融市場実行": False, "旧Source/Chart/Actor/金融変更": False}
    with target.open("x", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(value, ensure_ascii=False, indent=2)+"\n")
    print(json.dumps({"成功": True, "停止": reference(target), "Go人工": value["Go人工"], "実定義": value["実定義"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
