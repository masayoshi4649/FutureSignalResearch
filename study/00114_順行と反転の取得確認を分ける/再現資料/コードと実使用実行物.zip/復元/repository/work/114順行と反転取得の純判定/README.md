# 114の純入口判定

Source新規要求原行で配送済みの111Chart実FrameからT/Rを一回固定する。注文・価格形成・金融・Source生成は扱わない。市場成績を主張しない。

## 実API

moduleは `github.com/masayoshi4649/SessionTradeExecuter/entrygate114`。`Frame` は停止済み `publicdelivery.Frame` の型alias。

- `NewHistory(Scope) (*History,error)`。ScopeはSession/Contract/Start/End。
- `History.Step(Frame,Stamp) error`。Stampは現在配送原行のTime(float64)/Index(int)/Line(int64)。JSON Line名はsource_line。
- `History.Reset(Stamp,reason) error`。公表の欠足等の実Events順で配送する。
- `History.Evaluate(Request) (Decision,error)`。RequestはProduct/Method/SignalID/Side/At(Stamp)。Sourceの場内複合出生で一度freezeし、同じRequestは私有copyを返す。固定要求を別の取得/fill原行へ付け替えると拒否する。
- `DeclaredDefinition() Definition`。A0/T/TRの使用法と実式を宣言し、`go run ./cmd/declaration`でJSON化できる。

CoreはChartのbatch.Events順で各ActorへStep/Resetしてから、その原行のSource要求を処理する。要求処理後に同じ原行へStep/Resetを追加することを拒否する。同秒でも別原行のIndex/Lineを保持する。Frame.At/End/AvailableAtは名目終端、Stampは実配送原行であり、書き換えて揃えない。要求後の未来Frameは固定Decisionへ影響しない。fillで再判定するAPIはない。

## 確定式

sは買+1/売−1。pは配送済みの連続した前3分公表。

```text
G=s(EMA8_t−EMA21_t)
a8=s(EMA8_t−EMA8_p), a21=s(EMA21_t−EMA21_p)
x8=s(Close_t−EMA8_t), x8p=s(Close_p−EMA8_p)
HistLevel=s Hist_t, HistDelta=s(Hist_t−Hist_p)
T = G>0 AND a8>0 AND a21>0 AND x8>0 AND HistLevel>0
R = G<0 AND a8>0 AND x8p<=0 AND x8>0 AND HistDelta>0
TR = T OR R
```

TのHist現在水準は必須。Rにはslow傾き/Hist水準を要求しない。価格の現在順側状態と奪還イベント、Hist水準と増分、M偽と増分strict正を分ける。A0はActor側で全許可する固定対照、TはTrend==True、TRはCombined==Trueだけ許可する。偽/未知で新予約しない。Source判断・数量・P100保護は本部品で変更しない。

## JSONと未知の契約

TruthはUnknown=0/False=1/True=2。AndはFalse優先、否定がなくUnknownが残ればUnknown、全TrueならTrue。OrはTrue優先、成立がなくUnknownが残ればUnknown、全FalseならFalse。G=0は両並び票が既知False。Hist=0も既知値であり、HistLevel>0/HistDelta>0の否定と不足を区別する。

Current.DataKnownが偽/Current無しなら現在7値に必要な現在入力はすべて未知。Previousは同Scope・前後DataKnown・End差180の直前別IDだけを保持する。Frame.Startは場開始であり前Endと比較しない。各Frame.Known.EMA8/EMA21/Hist/Closeを別々に適用し、CurrentとPreviousがあっても必要Known不足なら対応値はnilとなる。過去の未知を後から補完しない。

ValuesはG/A8/A21/X8/X8Prev/HistLevel/HistDeltaの7個のnullable float64。CurrentだけでG/X8/HistLevelを計算し、連続Previousの必要値がある場合だけA8/A21/X8Prev/HistDeltaを計算する。Current.DataKnownが偽ならPreviousによる計算もしない。ゼロ境界は厳密比較。差はGo float64の算術であり、独立十進算術との差の丸めを方向票と混同しない。非有限入力と差分overflowは拒否する。

ConditionsはID/Value/Op/Truth。T条件順はT.G,T.a8,T.a21,T.x8,T.HistLevel。R条件順はR.G,R.a8,R.x8p,R.x8,R.HistDelta。各Denialsには既知FalseのIDだけを保存し、未知条件はConditions.Truth=0に残す。

MissingInputsは次の10入力のうち不足した名前をこの順で保存する：current.data_known,current.ema8,current.ema21,current.close,current.hist,previous.contiguous_3m,previous.ema8,previous.ema21,previous.close,previous.hist。これは全条件に用いる入力不足の診断で、最終判定Unknownの件数とは違う。確定した否定票により結果Falseでも他入力がMissingに残り得る。

## 出典と状態の制約

旧 `publicdelivery.Validate` を実Frameへ適用し、足ID・名目終端・Known/LastSource/OHLCをそのまま検査する。Scope不一致、未来End/AvailableAt/ObservedClock、配送原行以後のLastSource物理行、時計/Index/Line後退・同原行改変を拒否する。

同IDは全Frame値不変だけ許可し、窓や初回Deliveredを進めない。reset後の旧ID再配送ではCurrentを復活させない。新IDはEnd/Ordinalが前進することを要求し、End差180だけを連続とする。間の足やEOF足を作らない。reset/欠足はPreviousを切り、必要値を未知へ戻すが、過去の固定Decisionは変えない。

Frame.LastSource/OHLC、DecisionのCurrent/Previous/数値/条件/理由配列は参照分離する。元Chart/Source/Actorと旧停止は変更しない。T/Rは元Sourceの候補を選別する値で、追加の売買方向を生成しない。

## 人工と停止

`go test -count=1 -json -cover ./...`、`go vet ./...`、`go build ./...`を行う。売買鏡像、TのHist不足/0/逆、RのHist水準と増分/slow傾き、奪還/既存位置、三値全9組、同秒原行、同ID、reset/欠足、未来/別場、要求固定/未来不干渉、別名共有とoverflowを人工確認する。

`ENTRYGATE114_ARTIFICIAL_OUTPUT=<未作成絶対JSON>` を設定し `go test -run ^TestExportArtificial$ -count=1 .` で、実Go Decisionと三値表を小数表記を保ってexportする。停止helperが `検査/人工.json` へ固定する。元Frame自体も人工であり、自然市場の成績ではない。市場Raw/Native/価格CSV/11/09の読取と金融再実行は0。
