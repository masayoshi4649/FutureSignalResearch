package entrygate114

import (
	"encoding/json"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	warm "github.com/masayoshi4649/SessionTradeExecuter/chartwarmup96"
	finance "github.com/masayoshi4649/SessionTradeExecuter/minivariableguard"
	delivery "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery"
)

// testScope は市場と無関係の手製境界を返します。
//
// 引数: ありません。返り値: Scopeは一つの人工場です。
func testScope() Scope { return Scope{"手製114", "NK225_手製", 1000, 10000} }

// testFrame は旧公開型/Validateを通る既知値の人工足を作ります。
//
// 引数: n(int)、e8/e21/close/hist(float64)。返り値: FrameとStampは名目公表と実配送行です。
func testFrame(n int, e8, e21, close, hist float64) (Frame, Stamp) {
	scope := testScope()
	end := scope.Start + float64(n)*180
	at := Stamp{end + 1, n * 10, int64(n*10 + 1)}
	f := Frame{ID: finance.WidthPublicationID(scope.Session, scope.Contract, end), Ordinal: n, Session: scope.Session, Contract: scope.Contract, Start: scope.Start, End: end, AvailableAt: end, ObservedClock: at.Time, At: end, TechnicalEnd: end, DataKnown: true, EMA8: e8, EMA21: e21, Hist: hist, Close: close, ExtensionSupplied: true}
	f.Known.EMA8, f.Known.EMA21, f.Known.Hist, f.Known.Close = true, true, true, true
	f.LastSource = &warm.SourceStamp{Time: end - 1, Index: int64(n*10 - 1), Line: int64(n * 10), Last: close, Valid: true}
	f.OHLC = &delivery.OHLC{Open: close, High: close + 1, Low: close - 1, Close: close, PublicationID: f.ID}
	return f, at
}

// testRequest は当原行の元Source新規要求の手製識別を返します。
//
// 引数: id(string)、side(int)、at(Stamp)。返り値: Requestは取得価格を含みません。
func testRequest(id string, side int, at Stamp) Request {
	return Request{"NK225mini", "NK225_D164_15", id, side, at}
}

// testHistory は任意の手製公表を順番に配送します。
//
// 引数: t(*testing.T)、frames(...Frame)。返り値: *Historyは独立した手製履歴です。
func testHistory(t *testing.T, frames ...Frame) *History {
	t.Helper()
	h, e := NewHistory(testScope())
	if e != nil {
		t.Fatal(e)
	}
	for _, f := range frames {
		if e = h.Step(f, Stamp{f.End + 1, f.Ordinal * 10, int64(f.Ordinal*10 + 1)}); e != nil {
			t.Fatal(e)
		}
	}
	return h
}

// testDecision は現在公表原行で一回だけ判定します。
//
// 引数: t(*testing.T)、h(*History)、id(string)、side(int)、at(Stamp)。返り値: Decisionは固定票です。
func testDecision(t *testing.T, h *History, id string, side int, at Stamp) Decision {
	t.Helper()
	d, e := h.Evaluate(testRequest(id, side, at))
	if e != nil {
		t.Fatal(e)
	}
	return d
}

// mirrorFrame は価格を基準2000で反転しMACD符号も反転します。
//
// 引数: f(Frame)。返り値: Frameは売買鏡像の人工です。
func mirrorFrame(f Frame) Frame {
	f = copyFrame(f)
	f.EMA8, f.EMA21, f.Close, f.Hist = 2000-f.EMA8, 2000-f.EMA21, 2000-f.Close, -f.Hist
	f.LastSource.Last = 2000 - f.LastSource.Last
	if f.OHLC != nil {
		f.OHLC.Open, f.OHLC.High, f.OHLC.Low, f.OHLC.Close = 2000-f.OHLC.Open, 2000-f.OHLC.Low, 2000-f.OHLC.High, 2000-f.OHLC.Close
	}
	return f
}

// TestTrendAndMirror はTのMA/現在Hist水準と買売対称を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestTrendAndMirror(t *testing.T) {
	p, _ := testFrame(1, 101, 100, 101, 1)
	c, at := testFrame(2, 103, 101, 104, 2)
	a := testDecision(t, testHistory(t, p, c), "買い", 1, at)
	b := testDecision(t, testHistory(t, mirrorFrame(p), mirrorFrame(c)), "売り", -1, at)
	if a.Trend != True || a.Reversal != False || a.Combined != True || !reflect.DeepEqual(a.Values, b.Values) || a.Trend != b.Trend || a.Reversal != b.Reversal {
		t.Fatal(a, b)
	}
	if *a.Values.G != 2 || *a.Values.A8 != 2 || *a.Values.A21 != 1 || *a.Values.X8 != 1 || *a.Values.HistLevel != 2 || *a.Values.HistDelta != 1 {
		t.Fatal(a.Values)
	}
}

// TestTrendHistKnownAndZero はMAが順方向でもHist未知/0/逆ならTを通しません。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestTrendHistKnownAndZero(t *testing.T) {
	p, _ := testFrame(1, 101, 100, 101, 1)
	for _, name := range []string{"未知", "0", "逆"} {
		c, at := testFrame(2, 103, 101, 104, 2)
		if name == "未知" {
			c.Known.Hist = false
		} else if name == "0" {
			c.Hist = 0
		} else {
			c.Hist = -1
		}
		d := testDecision(t, testHistory(t, p, c), name, 1, at)
		want := False
		if name == "未知" {
			want = Unknown
		}
		if d.Trend != want {
			t.Fatal(name, d)
		}
		if name == "未知" && d.Values.HistLevel != nil {
			t.Fatal("未知を0へ補完")
		}
	}
}

// TestReversalLevelDeltaAndMirror はHist水準が逆でも改善増分と奪還でRを通します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestReversalLevelDeltaAndMirror(t *testing.T) {
	p, _ := testFrame(1, 100, 110, 100, -3)
	c, at := testFrame(2, 101, 109, 102, -2)
	a := testDecision(t, testHistory(t, p, c), "買い", 1, at)
	b := testDecision(t, testHistory(t, mirrorFrame(p), mirrorFrame(c)), "売り", -1, at)
	if a.Reversal != True || a.Trend != False || a.Combined != True || *a.Values.HistLevel != -2 || *a.Values.HistDelta != 1 || *a.Values.A21 != -1 || !reflect.DeepEqual(a.Values, b.Values) || a.Combined != b.Combined {
		t.Fatal(a, b)
	}
}

// TestReversalBoundaries は既存位置/Hist増分0/fast傾き0/並び0/終値等号を区別します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestReversalBoundaries(t *testing.T) {
	for _, name := range []string{"既に順側", "h0", "a8zero", "Gzero", "x8zero", "前Hist未知"} {
		p, _ := testFrame(1, 100, 110, 100, -3)
		c, at := testFrame(2, 101, 109, 102, -2)
		switch name {
		case "既に順側":
			p.Close = 101
			p.LastSource.Last = 101
			p.OHLC = nil
		case "h0":
			c.Hist = -3
		case "a8zero":
			c.EMA8 = 100
		case "Gzero":
			c.EMA21 = c.EMA8
		case "x8zero":
			c.Close = c.EMA8
			c.LastSource.Last = c.Close
			c.OHLC = nil
		case "前Hist未知":
			p.Known.Hist = false
		}
		d := testDecision(t, testHistory(t, p, c), name, 1, at)
		want := False
		if name == "前Hist未知" {
			want = Unknown
		}
		if d.Reversal != want {
			t.Fatal(name, d)
		}
	}
}

// TestTruthTables は未知と既知否定を分け真OR未知も検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestTruthTables(t *testing.T) {
	and := [][]Truth{{Unknown, False, Unknown}, {False, False, False}, {Unknown, False, True}}
	or := [][]Truth{{Unknown, Unknown, True}, {Unknown, False, True}, {True, True, True}}
	for a := Unknown; a <= True; a++ {
		for b := Unknown; b <= True; b++ {
			if And(a, b) != and[a][b] || Or(a, b) != or[a][b] {
				t.Fatal(a, b)
			}
		}
	}
}

// TestColdGapResetAndDuplicate は不足・欠足・resetと同IDで窓を進めないことを検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestColdGapResetAndDuplicate(t *testing.T) {
	h, _ := NewHistory(testScope())
	d := testDecision(t, h, "空", 1, Stamp{1001, 0, 1})
	if d.Combined != Unknown || len(d.MissingInputs) == 0 {
		t.Fatal(d)
	}
	p, _ := testFrame(1, 101, 100, 101, 1)
	c, at := testFrame(3, 103, 101, 104, 2)
	h = testHistory(t, p, c)
	d = testDecision(t, h, "欠足", 1, at)
	if d.Continuous || d.Values.A8 != nil || d.Trend != Unknown {
		t.Fatal(d)
	}
	h = testHistory(t, p)
	stamp := Stamp{1181, 11, 12}
	if e := h.Reset(stamp, "人工欠足"); e != nil {
		t.Fatal(e)
	}
	if e := h.Step(p, Stamp{1181, 12, 13}); e != nil {
		t.Fatal(e)
	}
	d = testDecision(t, h, "reset後同ID", 1, Stamp{1181, 13, 14})
	if d.Current != nil || d.Previous != nil || d.Combined != Unknown || d.LastReset == nil {
		t.Fatal(d)
	}
	h = testHistory(t, p)
	if e := h.Step(p, Stamp{1181, 11, 12}); e != nil {
		t.Fatal(e)
	}
	d = testDecision(t, h, "重複", 1, Stamp{1181, 12, 13})
	if d.Previous != nil || d.Current.Delivered.Index != 10 {
		t.Fatal(d)
	}
}

// TestFutureScopeAndRowRejection は未来・別場・同秒後退・同原行改変を拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestFutureScopeAndRowRejection(t *testing.T) {
	p, at := testFrame(1, 101, 100, 101, 1)
	for _, name := range []string{"未来", "観測未来", "別場", "別限月", "出典未来", "原行後退", "同原行時計改変"} {
		h, _ := NewHistory(testScope())
		f := copyFrame(p)
		s := at
		switch name {
		case "未来":
			s.Time = f.End - 1
		case "観測未来":
			f.ObservedClock = s.Time + 1
		case "別場":
			f.Session = "別"
		case "別限月":
			f.Contract = "別"
		case "出典未来":
			f.LastSource.Line = s.Line
		case "原行後退":
			if e := h.Step(p, at); e != nil {
				t.Fatal(e)
			}
			s.Index--
		case "同原行時計改変":
			if e := h.Step(p, at); e != nil {
				t.Fatal(e)
			}
			s.Time++
		}
		if e := h.Step(f, s); e == nil {
			t.Fatal("拒否不足", name)
		}
	}
	h := testHistory(t, p)
	f := copyFrame(p)
	f.Hist++
	if e := h.Step(f, Stamp{at.Time, at.Index + 1, at.Line + 1}); e == nil {
		t.Fatal("同ID改変")
	}
}

// TestFreezeRowPhaseAndFutureIndependence は要求固定・同秒配送順・未来不干渉を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestFreezeRowPhaseAndFutureIndependence(t *testing.T) {
	p, _ := testFrame(1, 101, 100, 101, 1)
	c, at := testFrame(2, 103, 101, 104, 2)
	h := testHistory(t, p, c)
	r := testRequest("固定", 1, at)
	d, e := h.Evaluate(r)
	if e != nil {
		t.Fatal(e)
	}
	want, _ := json.Marshal(d)
	if e = h.Step(c, at); e == nil {
		t.Fatal("要求後同原行公表")
	}
	if e = h.Reset(at, "遅いreset"); e == nil {
		t.Fatal("要求後同原行reset")
	}
	f3, s3 := testFrame(3, 105, 102, 106, 3)
	if e = h.Step(f3, s3); e != nil {
		t.Fatal(e)
	}
	got, e := h.Evaluate(r)
	raw, _ := json.Marshal(got)
	if e != nil || string(raw) != string(want) {
		t.Fatal("未来で固定票が変化")
	}
	r.At = s3
	if _, e = h.Evaluate(r); e == nil {
		t.Fatal("fill原行へ要求付替え")
	}
}

// TestAliasesPrivate は入力/出力Frame・条件値・理由配列から内部状態を破壊できないことを検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestAliasesPrivate(t *testing.T) {
	p, _ := testFrame(1, 101, 100, 101, 1)
	c, at := testFrame(2, 103, 101, 104, 2)
	h := testHistory(t, p, c)
	c.LastSource.Last = 999
	c.OHLC.Close = 999
	r := testRequest("私有", 1, at)
	d, e := h.Evaluate(r)
	if e != nil {
		t.Fatal(e)
	}
	want, _ := json.Marshal(d)
	d.Current.Frame.LastSource.Last = 999
	d.Previous.Frame.OHLC.Close = 999
	*d.Values.G = 999
	*d.TrendConditions[0].Value = 999
	d.ReversalDenials[0] = "改変"
	got, e := h.Evaluate(r)
	raw, _ := json.Marshal(got)
	if e != nil || string(raw) != string(want) {
		t.Fatal("参照共有")
	}
	def := DeclaredDefinition()
	def.Modes[0] = "変更"
	if DeclaredDefinition().Modes[0] != "A0" {
		t.Fatal("宣言参照共有")
	}
}

// TestDataUnknownAndNumericOverflow は暖機の未知を正常に扱い非有限の差を拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestDataUnknownAndNumericOverflow(t *testing.T) {
	p, _ := testFrame(1, 101, 100, 101, 1)
	c, at := testFrame(2, 103, 101, 104, 2)
	c.DataKnown = false
	c.LastSource = nil
	c.OHLC = nil
	d := testDecision(t, testHistory(t, p, c), "不良足", 1, at)
	if d.Current == nil || d.Values.G != nil || d.Values.HistLevel != nil || d.Combined != Unknown {
		t.Fatal(d)
	}
	p.Hist = -math.MaxFloat64
	c, at = testFrame(2, 103, 101, 104, math.MaxFloat64)
	h := testHistory(t, p, c)
	if _, e := h.Evaluate(testRequest("overflow", 1, at)); e == nil {
		t.Fatal("差分overflow")
	}
	if _, e := NewHistory(Scope{"", "", 0, 1}); e == nil {
		t.Fatal("不正Scope")
	}
}

// TestExportArtificial は停止helper明示先だけへ実Go Decisionを小数を保ち保存します。
//
// 引数: t(*testing.T)、環境ENTRYGATE114_ARTIFICIAL_OUTPUT(string)。返り値: ありません。通常検査ではskipです。
func TestExportArtificial(t *testing.T) {
	target := os.Getenv("ENTRYGATE114_ARTIFICIAL_OUTPUT")
	if target == "" {
		t.Skip("人工export専用")
	}
	if !filepath.IsAbs(target) {
		t.Fatal("人工絶対先だけ")
	}
	cases := []struct {
		Name     string   `json:"name"`
		Decision Decision `json:"decision"`
	}{}
	p, _ := testFrame(1, 101, 100, 101, 1)
	c, at := testFrame(2, 103, 101, 104, 2)
	for _, side := range []int{1, -1} {
		a, b := p, c
		if side < 0 {
			a, b = mirrorFrame(p), mirrorFrame(c)
		}
		cases = append(cases, struct {
			Name     string   `json:"name"`
			Decision Decision `json:"decision"`
		}{"順行", testDecision(t, testHistory(t, a, b), "順行", side, at)})
	}
	for _, name := range []string{"T現在Hist未知", "T現在Hist0", "二進小数"} {
		a, b := copyFrame(p), copyFrame(c)
		if name == "T現在Hist未知" {
			b.Known.Hist = false
		} else if name == "T現在Hist0" {
			b.Hist = 0
		} else {
			a, _ = testFrame(1, 101.25, 100.5, 101.75, 1.25)
			b, _ = testFrame(2, 103.5, 101.25, 104.25, 2.25)
		}
		cases = append(cases, struct {
			Name     string   `json:"name"`
			Decision Decision `json:"decision"`
		}{name, testDecision(t, testHistory(t, a, b), name, 1, at)})
	}
	p, _ = testFrame(1, 100, 110, 100, -3)
	c, at = testFrame(2, 101, 109, 102, -2)
	for _, side := range []int{1, -1} {
		a, b := p, c
		if side < 0 {
			a, b = mirrorFrame(p), mirrorFrame(c)
		}
		cases = append(cases, struct {
			Name     string   `json:"name"`
			Decision Decision `json:"decision"`
		}{"反転", testDecision(t, testHistory(t, a, b), "反転", side, at)})
	}
	for _, name := range []string{"h0", "前Hist未知", "現在Hist未知", "現在Hist0", "G0", "現在足未知", "欠足", "reset", "空"} {
		a, b := copyFrame(p), copyFrame(c)
		h := testHistory(t)
		switch name {
		case "h0":
			b.Hist = a.Hist
		case "前Hist未知":
			a.Known.Hist = false
		case "現在Hist未知":
			b.Known.Hist = false
		case "現在Hist0":
			b.Hist = 0
		case "G0":
			b.EMA21 = b.EMA8
		case "現在足未知":
			b.DataKnown = false
			b.LastSource = nil
			b.OHLC = nil
		case "欠足":
			b, at = testFrame(3, 101, 109, 102, -2)
		}
		if name != "空" {
			if e := h.Step(a, Stamp{a.End + 1, a.Ordinal * 10, int64(a.Ordinal*10 + 1)}); e != nil {
				t.Fatal(e)
			}
			if e := h.Step(b, Stamp{b.End + 1, b.Ordinal * 10, int64(b.Ordinal*10 + 1)}); e != nil {
				t.Fatal(e)
			}
		}
		s := Stamp{b.End + 1, b.Ordinal * 10, int64(b.Ordinal*10 + 1)}
		if name == "reset" {
			s.Index++
			s.Line++
			if e := h.Reset(s, "手製reset"); e != nil {
				t.Fatal(e)
			}
		}
		cases = append(cases, struct {
			Name     string   `json:"name"`
			Decision Decision `json:"decision"`
		}{name, testDecision(t, h, name, 1, s)})
	}
	table := []map[string]Truth{}
	for a := Unknown; a <= True; a++ {
		for b := Unknown; b <= True; b++ {
			table = append(table, map[string]Truth{"a": a, "b": b, "and": And(a, b), "or": Or(a, b)})
		}
	}
	raw, e := json.MarshalIndent(map[string]any{"version": 114, "成功": true, "人工": true, "市場Raw": false, "definition": DeclaredDefinition(), "cases": cases, "truth_tables": table}, "", "  ")
	if e != nil {
		t.Fatal(e)
	}
	f, e := os.OpenFile(target, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		t.Fatal(e)
	}
	defer f.Close()
	if _, e = f.Write(append(raw, '\n')); e != nil {
		t.Fatal(e)
	}
}
