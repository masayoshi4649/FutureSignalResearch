package entrygate114

// And は未知を含む論理積を計算します。
//
// 引数: values(...Truth)。返り値: Truthは偽を優先し、否定のない不足は未知です。
func And(values ...Truth) Truth {
	unknown := false
	for _, v := range values {
		if v == False {
			return False
		}
		if v != True {
			unknown = true
		}
	}
	if unknown {
		return Unknown
	}
	return True
}

// Or は未知を含む論理和を計算します。
//
// 引数: values(...Truth)。返り値: Truthは真を優先し、成立のない不足は未知です。
func Or(values ...Truth) Truth {
	unknown := false
	for _, v := range values {
		if v == True {
			return True
		}
		if v != False {
			unknown = true
		}
	}
	if unknown {
		return Unknown
	}
	return False
}

// pointer は数値の私有ポインタを作ります。
//
// 引数: value(float64)。返り値: *float64は新しい保存先です。
func pointer(value float64) *float64 { return &value }

// copyNumber は未知nilを保った独立copyを返します。
//
// 引数: value(*float64又はnil)。返り値: *float64はnil又は新保存先です。
func copyNumber(value *float64) *float64 {
	if value == nil {
		return nil
	}
	return pointer(*value)
}

// copyValues は値の全ポインタを私有化します。
//
// 引数: value(Values)。返り値: Valuesはnilを保つ独立copyです。
func copyValues(value Values) Values {
	return Values{copyNumber(value.G), copyNumber(value.A8), copyNumber(value.A21), copyNumber(value.X8), copyNumber(value.X8Prev), copyNumber(value.HistLevel), copyNumber(value.HistDelta)}
}

// copyConditions は空/nilを保ち条件値の参照を分離します。
//
// 引数: values([]Condition)。返り値: []Conditionは独立copyです。
func copyConditions(values []Condition) []Condition {
	if values == nil {
		return nil
	}
	out := make([]Condition, len(values))
	copy(out, values)
	for i := range out {
		out[i].Value = copyNumber(out[i].Value)
	}
	return out
}

// copyStrings は空/nilを保ち理由配列を分離します。
//
// 引数: values([]string)。返り値: []stringは独立copyです。
func copyStrings(values []string) []string {
	if values == nil {
		return nil
	}
	out := make([]string, len(values))
	copy(out, values)
	return out
}

// copyDecision は要求固定票の入れ子と全ポインタを消費者から分離します。
//
// 引数: d(Decision)。返り値: Decisionは値同体の私有copyです。
func copyDecision(d Decision) Decision {
	d.Current, d.Previous = copyPublication(d.Current), copyPublication(d.Previous)
	d.Values = copyValues(d.Values)
	d.TrendConditions, d.ReversalConditions = copyConditions(d.TrendConditions), copyConditions(d.ReversalConditions)
	d.MissingInputs, d.TrendDenials, d.ReversalDenials = copyStrings(d.MissingInputs), copyStrings(d.TrendDenials), copyStrings(d.ReversalDenials)
	if d.LastReset != nil {
		x := *d.LastReset
		d.LastReset = &x
	}
	return d
}

// condition は既知値を0境界と比較し、未知を偽へ置換しません。
//
// 引数: id/op(string)、value(*float64)。返り値: Conditionは元値と三値です。
func condition(id string, value *float64, op string) Condition {
	out := Condition{ID: id, Value: copyNumber(value), Op: op, Truth: Unknown}
	if value == nil {
		return out
	}
	passed := false
	switch op {
	case ">0":
		passed = *value > 0
	case "<0":
		passed = *value < 0
	case "<=0":
		passed = *value <= 0
	default:
		panic("未宣言の114条件演算")
	}
	out.Truth = False
	if passed {
		out.Truth = True
	}
	return out
}

// conjunction は個別条件票から論理積と既知の否定理由を作ります。
//
// 引数: conditions([]Condition)。返り値: Truthと[]stringは全体票と否定条件IDです。
func conjunction(conditions []Condition) (Truth, []string) {
	values := make([]Truth, len(conditions))
	denials := []string{}
	for i, c := range conditions {
		values[i] = c.Truth
		if c.Truth == False {
			denials = append(denials, c.ID)
		}
	}
	return And(values...), denials
}

// evaluate は要求までに配送済みの連続公表だけからT/Rの不変票を作ります。
//
// 引数: scope(Scope)、request(Request)、current/previous(*Publication)、reset(*Stamp)、reason(string)。
// 返り値: Decisionは現在水準と増分・未知と否定を分けた私有保存値です。
func evaluate(scope Scope, request Request, current, previous *Publication, reset *Stamp, reason string) Decision {
	d := Decision{Version: 114, Scope: scope, Request: request, Current: copyPublication(current), Previous: copyPublication(previous), Continuous: previous != nil, MissingInputs: []string{}, ResetReason: reason, Frozen: true}
	if reset != nil {
		x := *reset
		d.LastReset = &x
	}
	s := float64(request.Side)
	currentKnown := current != nil && current.Frame.DataKnown
	previousKnown := previous != nil && previous.Frame.DataKnown && currentKnown
	var c, p Frame
	if current != nil {
		c = current.Frame
	}
	if previous != nil {
		p = previous.Frame
	}
	inputs := []struct {
		name  string
		known bool
	}{
		{"current.data_known", currentKnown},
		{"current.ema8", currentKnown && c.Known.EMA8},
		{"current.ema21", currentKnown && c.Known.EMA21},
		{"current.close", currentKnown && c.Known.Close},
		{"current.hist", currentKnown && c.Known.Hist},
		{"previous.contiguous_3m", previousKnown},
		{"previous.ema8", previousKnown && p.Known.EMA8},
		{"previous.ema21", previousKnown && p.Known.EMA21},
		{"previous.close", previousKnown && p.Known.Close},
		{"previous.hist", previousKnown && p.Known.Hist},
	}
	for _, v := range inputs {
		if !v.known {
			d.MissingInputs = append(d.MissingInputs, v.name)
		}
	}
	if currentKnown {
		if c.Known.EMA8 && c.Known.EMA21 {
			d.Values.G = pointer(s * (c.EMA8 - c.EMA21))
		}
		if c.Known.Close && c.Known.EMA8 {
			d.Values.X8 = pointer(s * (c.Close - c.EMA8))
		}
		if c.Known.Hist {
			d.Values.HistLevel = pointer(s * c.Hist)
		}
	}
	if previousKnown {
		if c.Known.EMA8 && p.Known.EMA8 {
			d.Values.A8 = pointer(s * (c.EMA8 - p.EMA8))
		}
		if c.Known.EMA21 && p.Known.EMA21 {
			d.Values.A21 = pointer(s * (c.EMA21 - p.EMA21))
		}
		if p.Known.Close && p.Known.EMA8 {
			d.Values.X8Prev = pointer(s * (p.Close - p.EMA8))
		}
		if c.Known.Hist && p.Known.Hist {
			d.Values.HistDelta = pointer(s * (c.Hist - p.Hist))
		}
	}
	d.TrendConditions = []Condition{condition("T.G", d.Values.G, ">0"), condition("T.a8", d.Values.A8, ">0"), condition("T.a21", d.Values.A21, ">0"), condition("T.x8", d.Values.X8, ">0"), condition("T.HistLevel", d.Values.HistLevel, ">0")}
	d.ReversalConditions = []Condition{condition("R.G", d.Values.G, "<0"), condition("R.a8", d.Values.A8, ">0"), condition("R.x8p", d.Values.X8Prev, "<=0"), condition("R.x8", d.Values.X8, ">0"), condition("R.HistDelta", d.Values.HistDelta, ">0")}
	d.Trend, d.TrendDenials = conjunction(d.TrendConditions)
	d.Reversal, d.ReversalDenials = conjunction(d.ReversalConditions)
	d.Combined = Or(d.Trend, d.Reversal)
	return d
}
