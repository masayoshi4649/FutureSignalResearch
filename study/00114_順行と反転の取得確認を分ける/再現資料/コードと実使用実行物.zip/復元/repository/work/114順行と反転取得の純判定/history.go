package entrygate114

import (
	"encoding/json"
	"fmt"
	"math"
	"reflect"

	delivery "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery"
)

// DeclaredDefinition は114の確定したT/R式と判定時計を返します。
//
// 引数: ありません。返り値: Definitionは参照共有のない宣言です。
func DeclaredDefinition() Definition {
	return Definition{114, "Source新規要求原行で配送済み公表を一回固定", "G>0 AND a8>0 AND a21>0 AND x8>0 AND side*Hist_t>0", "G<0 AND a8>0 AND x8p<=0 AND x8>0 AND side*(Hist_t-Hist_p)>0", 0, 180, []string{"A0", "T", "TR"}, false}
}

// finite は時計と公表数値の有限性を確認します。
//
// 引数: values(...float64)。返り値: boolは全値が有限のとき真です。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// NewHistory は一つの場・限月の配送済み履歴を空から作ります。
//
// 引数: scope(Scope)。返り値: *History/errorは純履歴又は場境界の不正です。
func NewHistory(scope Scope) (*History, error) {
	if scope.Session == "" || scope.Contract == "" || !finite(scope.Start, scope.End) || scope.Start < 0 || scope.End <= scope.Start {
		return nil, fmt.Errorf("114入口の場境界不正")
	}
	return &History{scope: scope, seen: map[string]Frame{}, frozen: map[string]Decision{}}, nil
}

// checkStamp は原行の時計/Index/物理行を比較し、同秒の別原行を保持します。
//
// 引数: at(Stamp)は配送又は要求行。返り値: errorは未来/後退又は同原行の不整合です。
func (h *History) checkStamp(at Stamp) error {
	if h == nil || h.seen == nil || !finite(at.Time) || at.Time < h.scope.Start || at.Time > h.scope.End || at.Index < 0 || at.Line <= 0 {
		return fmt.Errorf("114入口の原行/未初期化不正")
	}
	if h.lastEvent != nil {
		p := *h.lastEvent
		if at.Time < p.Time || at.Index < p.Index || at.Line < p.Line {
			return fmt.Errorf("114入口の原行後退")
		}
		if (at.Index == p.Index || at.Line == p.Line) && at != p {
			return fmt.Errorf("114入口の同原行stamp改変")
		}
	}
	return nil
}

// copyFrame は実Frameの二つの入れ子ポインタを私有化します。
//
// 引数: f(Frame)。返り値: Frameは値同体かつ参照共有なしです。
func copyFrame(f Frame) Frame {
	if f.LastSource != nil {
		x := *f.LastSource
		f.LastSource = &x
	}
	if f.OHLC != nil {
		x := *f.OHLC
		f.OHLC = &x
	}
	return f
}

// copyPublication は公表と配送stampの私有copyを返します。
//
// 引数: p(*Publication又はnil)。返り値: *Publicationはnil又は独立copyです。
func copyPublication(p *Publication) *Publication {
	if p == nil {
		return nil
	}
	q := *p
	q.Frame = copyFrame(q.Frame)
	return &q
}

// Step は実Frameを現在配送原行へ結び、未来公表と同ID改変を拒否します。
//
// 引数: frame(Frame)、at(Stamp)。返り値: errorは公表出典又は配送順の不正です。
func (h *History) Step(frame Frame, at Stamp) error {
	if err := h.checkStamp(at); err != nil {
		return err
	}
	if h.requestRow != nil && *h.requestRow == at {
		return fmt.Errorf("114入口の要求処理後へ同原行公表を追加")
	}
	if err := delivery.Validate(frame); err != nil {
		return fmt.Errorf("114入口Frame: %w", err)
	}
	if frame.Session != h.scope.Session || frame.Contract != h.scope.Contract || frame.Start != h.scope.Start || frame.End > h.scope.End || frame.End > at.Time || frame.AvailableAt > at.Time || frame.ObservedClock > at.Time {
		return fmt.Errorf("114入口の別場/未来Frame")
	}
	if frame.LastSource != nil && (frame.LastSource.Index > int64(at.Index) || frame.LastSource.Line >= at.Line) {
		return fmt.Errorf("114入口の公表出典が配送原行以後")
	}
	if old, ok := h.seen[frame.ID]; ok {
		if !reflect.DeepEqual(old, frame) {
			return fmt.Errorf("114入口の同ID公表改変")
		}
		if frame.End < h.maxEnd {
			return fmt.Errorf("114入口の古いID再配送")
		}
		x := at
		h.lastEvent = &x
		return nil
	}
	if frame.End <= h.maxEnd || frame.Ordinal <= h.maxOrdinal {
		return fmt.Errorf("114入口の公表順後退")
	}
	pub := &Publication{copyFrame(frame), at}
	h.previous = nil
	if h.current != nil && h.current.Frame.DataKnown && frame.DataKnown && frame.End-h.current.Frame.End == 180 {
		h.previous = copyPublication(h.current)
	}
	h.current = pub
	h.seen[frame.ID] = copyFrame(frame)
	h.maxEnd, h.maxOrdinal = frame.End, frame.Ordinal
	x := at
	h.lastEvent = &x
	return nil
}

// Reset は当原行までに観測した欠足等を受け、技法窓だけを未知へ戻します。
//
// 引数: at(Stamp)、reason(string)。返り値: errorは原行又は空理由の不正です。固定済み判定は消しません。
func (h *History) Reset(at Stamp, reason string) error {
	if err := h.checkStamp(at); err != nil {
		return err
	}
	if h.requestRow != nil && *h.requestRow == at {
		return fmt.Errorf("114入口の要求処理後へ同原行resetを追加")
	}
	if reason == "" {
		return fmt.Errorf("114入口のreset理由なし")
	}
	h.current, h.previous = nil, nil
	x, y := at, at
	h.lastEvent = &x
	h.lastReset = &y
	h.resetReason = reason
	return nil
}

// requestKey は場内のSource複合出生を衝突しない形に写します。
//
// 引数: r(Request)。返り値: stringは商品/手法/売買/SignalIDのキーです。
func requestKey(r Request) string {
	b, _ := json.Marshal([]any{r.Product, r.Method, r.Side, r.SignalID})
	return string(b)
}

// Evaluate は要求原行のT/Rを一度だけ評価し、同じ出生の再利用で再判定しません。
//
// 引数: request(Request)。返り値: Decision/errorは私有固定票又は不整合です。実fillを受けるAPIはありません。
func (h *History) Evaluate(request Request) (Decision, error) {
	if h == nil || h.frozen == nil {
		return Decision{}, fmt.Errorf("114入口の未初期化")
	}
	if request.Product == "" || request.Method == "" || request.SignalID == "" || (request.Side != 1 && request.Side != -1) {
		return Decision{}, fmt.Errorf("114入口のSource複合要求不正")
	}
	key := requestKey(request)
	if saved, ok := h.frozen[key]; ok {
		if saved.Request != request {
			return Decision{}, fmt.Errorf("114入口の固定要求を別原行へ付替え")
		}
		return copyDecision(saved), nil
	}
	if err := h.checkStamp(request.At); err != nil {
		return Decision{}, err
	}
	d := evaluate(h.scope, request, h.current, h.previous, h.lastReset, h.resetReason)
	for _, value := range []*float64{d.Values.G, d.Values.A8, d.Values.A21, d.Values.X8, d.Values.X8Prev, d.Values.HistLevel, d.Values.HistDelta} {
		if value != nil && !finite(*value) {
			return Decision{}, fmt.Errorf("114入口の差分数値が有限範囲外")
		}
	}
	h.frozen[key] = copyDecision(d)
	x := request.At
	h.lastEvent = &x
	y := request.At
	h.requestRow = &y
	return copyDecision(d), nil
}
