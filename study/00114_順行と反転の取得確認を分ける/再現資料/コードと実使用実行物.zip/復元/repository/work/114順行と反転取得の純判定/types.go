// Package entrygate114 は実公表の確定3分値だけから、Source要求時の入口票を固定します。
package entrygate114

import delivery "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery"

type Frame = delivery.Frame

type Truth uint8

const (
	Unknown Truth = iota
	False
	True
)

type Scope struct {
	Session  string  `json:"session"`
	Contract string  `json:"contract"`
	Start    float64 `json:"start"`
	End      float64 `json:"end"`
}

type Stamp struct {
	Time  float64 `json:"time"`
	Index int     `json:"index"`
	Line  int64   `json:"source_line"`
}

type Publication struct {
	Frame     Frame `json:"frame"`
	Delivered Stamp `json:"delivered"`
}

type Request struct {
	Product  string `json:"product"`
	Method   string `json:"method"`
	SignalID string `json:"signal_id"`
	Side     int    `json:"side"`
	At       Stamp  `json:"at"`
}

type Values struct {
	G         *float64 `json:"g"`
	A8        *float64 `json:"a8"`
	A21       *float64 `json:"a21"`
	X8        *float64 `json:"x8"`
	X8Prev    *float64 `json:"x8_prev"`
	HistLevel *float64 `json:"hist_level"`
	HistDelta *float64 `json:"hist_delta"`
}

type Condition struct {
	ID    string   `json:"id"`
	Value *float64 `json:"value"`
	Op    string   `json:"op"`
	Truth Truth    `json:"truth"`
}

type Decision struct {
	Version            int          `json:"version"`
	Scope              Scope        `json:"scope"`
	Request            Request      `json:"request"`
	Current            *Publication `json:"current"`
	Previous           *Publication `json:"previous"`
	Continuous         bool         `json:"continuous"`
	Values             Values       `json:"values"`
	Trend              Truth        `json:"trend"`
	Reversal           Truth        `json:"reversal"`
	Combined           Truth        `json:"combined"`
	TrendConditions    []Condition  `json:"trend_conditions"`
	ReversalConditions []Condition  `json:"reversal_conditions"`
	MissingInputs      []string     `json:"missing_inputs"`
	TrendDenials       []string     `json:"trend_denials"`
	ReversalDenials    []string     `json:"reversal_denials"`
	LastReset          *Stamp       `json:"last_reset"`
	ResetReason        string       `json:"reset_reason"`
	Frozen             bool         `json:"frozen"`
}

type Definition struct {
	Version          int      `json:"version"`
	SourceClock      string   `json:"source_clock"`
	Trend            string   `json:"trend"`
	Reversal         string   `json:"reversal"`
	Boundary         float64  `json:"boundary"`
	PreviousSeconds  float64  `json:"previous_seconds"`
	Modes            []string `json:"modes"`
	RefillEvaluation bool     `json:"refill_evaluation"`
}

type History struct {
	scope       Scope
	current     *Publication
	previous    *Publication
	seen        map[string]Frame
	maxEnd      float64
	maxOrdinal  int
	lastEvent   *Stamp
	requestRow  *Stamp
	lastReset   *Stamp
	resetReason string
	frozen      map[string]Decision
}
