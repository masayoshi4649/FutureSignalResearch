package main

import (
	"encoding/json"
	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate114"
	"os"
)

// main はコンパイル済みの114実定義を標準出力へ保存します。
//
// 引数: ありません。返り値: ありません。市場入力やSourceを実行しません。
func main() {
	encoder := json.NewEncoder(os.Stdout)
	encoder.SetIndent("", "  ")
	if err := encoder.Encode(gate.DeclaredDefinition()); err != nil {
		panic(err)
	}
}
