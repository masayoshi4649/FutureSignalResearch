"""114本名入口設定を保ち、固定113の金融会計を入口拒否だけ明示して再用する。"""

import ast
import inspect
import textwrap
import hashlib
import importlib.util
from pathlib import Path
from types import FunctionType

ROOT = Path(__file__).resolve().parents[2]
PREVIOUS_PATH = ROOT / 'work/113起動前の構造失効を執行する会計/金融の独立検算.py'
PREVIOUS_SHA = '52e0e640e27209faa65894289309bdfe525b09ea050cbd9544d47eda1a89ef2f'
if hashlib.sha256(PREVIOUS_PATH.read_bytes()).hexdigest() != PREVIOUS_SHA:
    raise ValueError('停止113金融会計のSHA差')
SPEC = importlib.util.spec_from_file_location('114が再用する停止113会計', PREVIOUS_PATH)
OLD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)
BASE, need, equal, number, money = OLD.BASE, OLD.need, OLD.equal, OLD.number, OLD.money
CONFIGS = tuple({'policy':'P100','entry_mode':mode,'slip_pts':cost,'delay_seconds':delay}
                for mode in ('A0','T','TR') for cost in (0,5) for delay in (0,1))


def key_for(config: dict) -> str:
    """機能: 114本名の入口モード・共通P100・費用の12宣言だけを受理する。

    引数: config(dict)は4fieldの実設定。
    返り値: strはA0/T/TRの口座key。設定やPolicyを旧名へ書換えない。
    """
    need(config in CONFIGS and set(config)=={'policy','entry_mode','slip_pts','delay_seconds'}, '114本名12設定')
    return f"{config['entry_mode']}_C{config['slip_pts']}_D{config['delay_seconds']}"


BY_KEY = {key_for(c):c for c in CONFIGS}
KEYS = tuple(BY_KEY)
def gate_allowed(book: dict, key: tuple) -> bool:
    """機能: 本名の元new要求へ一意に結合した凍結許可票を参照する。

    引数: book(dict)、key(tuple[str,str])は実口座とmethod/signal_id。
    返り値: boolは記録された許可。技法票の独立三値検算は別監査で行う。
    """
    audit=book['entry_gate']
    equal(audit['mode'],book['config']['entry_mode'],'入口監査の本名モード')
    records=[row for row in audit['records'] if (row['request']['method'],row['request']['signal_id'])==key]
    equal(len(records),1,'元new要求と入口票の一意結合')
    need(type(records[0]['allowed']) is bool,'入口許可のbool')
    return records[0]['allowed']


def source_events_function():
    """機能: 元出生量のmin式だけへ選別拒否0を加え、所有/予約/Source検査を維持する。

    引数: なし。
    返り値: functionは新規ゲート以外の固定94Source作用監査を同体で持つ関数。
    """
    tree=ast.parse(textwrap.dedent(inspect.getsource(BASE.verify_source_events)))
    matches=[node for node in ast.walk(tree) if isinstance(node,ast.Call)
             and ast.unparse(node)=="equal(event['actual_accepted'], 0 if key in cancelled else min(event['quantity'], event['available']), 'Source出生量/空きのmin')"]
    equal(len(matches),1,'停止Source受付minの限定一式')
    matches[0].args[1]=ast.parse("0 if key in cancelled or not gate_allowed(book,key) else min(event['quantity'],event['available'])",mode='eval').body
    namespace={**vars(BASE),'gate_allowed':gate_allowed}
    exec(compile(ast.fix_missing_locations(tree),__file__+':Source受付minへ拒否0だけ追加','exec'),namespace)
    return namespace['verify_source_events']


SOURCE_EVENTS=source_events_function()
PURE_ACCOUNTING=FunctionType(OLD.PURE_ACCOUNTING.__code__,{**OLD.PURE_ACCOUNTING.__globals__,'verify_source_events':SOURCE_EVENTS},'停止113金融会計の入口拒否接続',OLD.PURE_ACCOUNTING.__defaults__,OLD.PURE_ACCOUNTING.__closure__)
SPACE = {**vars(OLD), 'key_for':key_for,'PURE_ACCOUNTING':PURE_ACCOUNTING}
FINANCE = FunctionType(OLD.verify_finance.__code__, SPACE, '停止113金融会計の114key接続', OLD.verify_finance.__defaults__, OLD.verify_finance.__closure__)


def verify_finance(book: dict, config: dict) -> dict:
    """機能: 本名のkey/Configを保ったまま全実約定・所有・予約・u/W/費用を検算する。

    引数: book/config(dict)は114実台帳と固定12設定。
    返り値: dictは独立会計結果。113の金融数式を変更せず、GoやRawを実行しない。
    """
    equal(book['key'],key_for(config),'114本名key')
    equal(book['config'],config,'114本名Config')
    return FINANCE(book,config)
