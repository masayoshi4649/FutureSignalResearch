# 114の独立金融・共通保護・入口票・保存

対象はA0/T/TR×追加滑り0/5pt×追加遅延0/1秒の12本名Configで、policyは全てP100。Config.entry_modeやkeyをP100へ書換えず、実注文・約定・所有・上限10・片道38.5円・費用・u/W・R/n・部分返済・予約・後原行fill・全場flatを独立算術で検算する。元Source111全文は旧113へ、A0は旧113P100四費用へ全金融/全State照合する。追加早期退出・H50・数量変更はない。

金融算術は停止113を同bytecodeで再用する。Sourceのnew受理だけは、旧min(出生量,余力)の一式へ『取消又は凍結入口拒否なら0』を明示AST派生した。金融値やConfigを都合よく補正しない。固定許可票は別所有の独立入口Pythonが実Events順・要求・三値・不足・否定・容量・取得まで再構成する。

保護は別P停止が固定113の有理数/三値演算を直接再用し、protection113/定義113/P100を保持する。少数保存点exact/bounded、未保存中間純点、Raw別走による最初の適格正常原行の初回性は未証明という限界を維持する。Source/利益保護/起動前失効の返済群は既存schemaに残すが、114の起動前失効群は必ず0。

## Root固定要求

`version:1,trial:114,fixed:true,market_native_read_authorized:true,stage:first2|base54|full70`。

FileRefは絶対path/sha256。必須は`condition/completion/code_stop/P_stop/actor_stop/protection_code/entry_stop/entry_code`。entry_stopは別所有入口Pythonの停止、entry_codeはその検算する.py。code_stopはこの独立保存器の会計停止、protection_codeはこのフォルダの新保護の独立監査.py。

scenesは予定全場の順序で`[{session,native,reference113,history_class,market_path}]`。history_classはoriginal54/additional16、nativeとreference113は当場SID.Native.json.gzのFileRef、market_pathは共用価格の参照文字列だけ。市場成功・停止code・指紋・全12N・旧4N・Source同体・全残0を先に認証し、成功後だけNativeを復号する。未固定/未解禁の要求はNative参照前・出力先作成前に拒否する。full70の元54は同条件成果物の認証再用、追加16のみ新規再生。

```powershell
python -X utf8 work/114利益保護を固定した入口比較の会計/保存する.py --fixed <Root要求の絶対path> --sha256 <SHA256> --output <未作成先>
```

結果JSON、保存検算、Viewerの一覧.resources.jsonと12×場数のtrades.jsonlを新規保存する。主key/Actor設定/集計/場別/旧113対照/Native参照/入口票検査・保護保存点件数を保持し、全0場を落とさない。利益/損失総額、勝負同値、PF、平均利益損失、実保有時間・数量秒、保存点連結時価DDを既存schemaで残す。CSVはRootが別途作り、この器は生成しない。機会損失・退出後の仮想利益・MFE回収・ROIを作らない。

人工は手製Core買売24冊＋旧113対で、6主が金融/P/入口/全値対照/0取引/Viewer再読/破壊拒否/未解禁拒否を検査する。自然FAR生成・実市場の成功とは呼ばない。Actor/P/入口/既固定113は編集しない。
