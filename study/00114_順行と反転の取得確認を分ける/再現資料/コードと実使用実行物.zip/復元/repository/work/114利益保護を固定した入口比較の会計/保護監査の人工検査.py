"""114本名12と共通P100をCore手製公表文脈で独立検算する。"""

from copy import deepcopy
from pathlib import Path
import unittest
import 保存集計の共通部 as S
import 金融の独立検算 as A
import 新保護の独立監査 as P

MANIFEST=S.ROOT/'work/114順行と反転取得の連続比較/人工_独立保存用/人工.json'
MANIFEST_SHA='ad8d3498c8a08afe0fabdee3d1a24f9dd4b16e43f4bf72e07a45493c03f82419'


def fixtures() -> list:
    """機能: 明示SHAの手製Core24冊と旧113対だけを読む。

    引数: なし。
    返り値: list[tuple]は新旧Native。FAR自然生成や実市場ではない。
    """
    S.equal(S.digest(MANIFEST),MANIFEST_SHA,'114手製manifestSHA')
    metadata=S.load(MANIFEST)
    S.need(metadata['artificial'] is True and metadata['books']==24,'114人工24の範囲')
    values=[]
    for case in metadata['cases']:
        for role in ('current','prior113'):
            S.equal(S.digest(Path(case[role]['path'])),case[role]['sha256'],'手製Native全SHA')
        values.append((S.load(Path(case['current']['path'])),S.load(Path(case['prior113']['path']))))
    return values


class Protection114Tests(unittest.TestCase):
    """P100固定の全数式再用と新モードの無偽装を確認する。"""

    def test_core24_and_same_guard(self) -> None:
        """機能: 新12×買売の全会計・少数P点と旧A0四対照を確認する。

        引数: self(Protection114Tests)は検査器。
        返り値: None。exact/boundedと未保存中間点を区別する。
        """
        count=0
        for value,prior in fixtures():
            for key,config in A.BY_KEY.items():
                book=value['actual']['books'][key]
                finance=A.verify_finance(book,config)
                checked=P.verify_protection(book,config,finance,value['actual'])
                self.assertIn('counts',checked)
                count+=1
            self.assertEqual(S.compare_reference113(value,prior)['comparisons'],4)
        self.assertEqual(count,24)

    def test_policy_definition_and_state_corruption(self) -> None:
        """機能: 別政策・新しい偽定義・床演算値の破壊を拒否する。

        引数: self(Protection114Tests)は検査器。
        返り値: None。共通保護の意味を変えない。
        """
        value,_=fixtures()[0]
        config=A.BY_KEY['A0_C0_D0'];book=value['actual']['books']['A0_C0_D0']
        finance=A.verify_finance(book,config)
        for kind in ('policy','definition','state'):
            broken=deepcopy(book);cfg=deepcopy(config)
            if kind=='policy':cfg['policy']='E100'
            elif kind=='definition':broken['positions'][0]['protection113']['initial']['definition']['version']=114
            else:broken['positions'][0]['protection113']['final_state']['closed_net_yen']+=1
            with self.subTest(kind=kind),self.assertRaises(ValueError):
                P.verify_protection(broken,cfg,finance,value['actual'])


if __name__=='__main__':unittest.main(verbosity=2)
