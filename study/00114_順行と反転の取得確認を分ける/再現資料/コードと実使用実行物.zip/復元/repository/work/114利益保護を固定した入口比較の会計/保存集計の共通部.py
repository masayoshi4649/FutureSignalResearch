"""114全12の会計・P100・Source非干渉・A0旧金融対照をまとめる。"""

import ast
from copy import deepcopy
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import sys
import textwrap
from types import FunctionType

import 金融の独立検算 as A

ROOT = Path(__file__).resolve().parents[2]
PREVIOUS_PATH = ROOT / 'work/113起動前の構造失効を執行する会計/保存集計の共通部.py'
PREVIOUS_SHA = '9ccbe99c39bdae1e7c942bdf8d0eb36435f86649037281e41ffa1f62890f5869'
if hashlib.sha256(PREVIOUS_PATH.read_bytes()).hexdigest()!=PREVIOUS_SHA:
    raise ValueError('停止113集計のSHA差')
SPEC = importlib.util.spec_from_file_location('114が再用する停止113集計',PREVIOUS_PATH)
OLD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)
BASE,need,equal=A.BASE,A.need,A.equal
KEYS,BY_KEY=A.KEYS,A.BY_KEY
digest,load=OLD.digest,OLD.load
summarize_book,combine,source_projection=OLD.summarize_book,OLD.combine,OLD.source_projection


def viewer_reader():
    """機能: 固定113の保存再読器から資源分母24の一式だけを12へ派生する。

    引数: なし。
    返り値: functionは114の全12保存を独立会計で再読する関数。金融演算は同体。
    """
    tree=ast.parse(textwrap.dedent(inspect.getsource(OLD.verify_viewer)))
    found=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.Call) and ast.unparse(node)=="equal(len(resources), 24, '保存再読24資源')":
            found.append(node)
    equal(len(found),1,'保存再読の資源分母一式だけ')
    found[0].args[1]=ast.Constant(value=12)
    found[0].args[2]=ast.Constant(value='114保存再読12資源')
    space={**OLD.verify_viewer.__globals__,'A':A,'KEYS':KEYS,'BY_KEY':BY_KEY}
    exec(compile(ast.fix_missing_locations(tree),__file__+':停止113保存再読の分母だけ','exec'),space)
    return space['verify_viewer']


verify_viewer=viewer_reader()


def normalize_ids(value, before: str, after: str) -> int:
    """機能: Actor生成IDの明示fieldだけを旧口座接頭辞へ写す。

    引数: value(any)、before/after(str)は全JSON部分木と新旧接頭辞。
    返り値: intは変更件数。Source・純値・要求DecisionのIDを加工しない。
    """
    count=0
    if isinstance(value,list):
        for child in value:count+=normalize_ids(child,before,after)
    elif isinstance(value,dict):
        for key,child in value.items():
            if key in ('id','entry_order_id','order_id','position_id','fill_id','exit_order_id') and isinstance(child,str) and child.startswith(before):
                value[key]=after+child[len(before):];count+=1
            if key not in ('source','request','decision','entry','latest'):
                count+=normalize_ids(value[key],before,after)
    return count


def compare_reference113(value: dict, prior: dict) -> dict:
    """機能: A0対旧P100の4冊とSource全文を独立に全値比較する。

    引数: value/prior(dict)は114と113の当場Native。
    返り値: dictは4全金融/全Stateと明示ID/型/ゲート説明差の件数。
    """
    need(value['trial']==114 and prior['actual']['trial']==113,'114/113の明示版')
    equal(value['source'],prior['source'],'Source111全JSON同体')
    equal(value['actual']['scope'],prior['actual']['scope'],'114/113の同場範囲')
    details={}
    for key in KEYS[:4]:
        left=deepcopy(value['actual']['books'][key]);config=BY_KEY[key]
        oldkey=f"P100_C{config['slip_pts']}_D{config['delay_seconds']}"
        right=deepcopy(prior['actual']['books'][oldkey])
        equal(left['config'],config,'114A0本名設定')
        equal(right['config'],{'policy':'P100','slip_pts':config['slip_pts'],'delay_seconds':config['delay_seconds']},'113共通保護設定')
        audit=left['entry_gate'];events=[e for e in left['source_events'] if e['kind']=='new_signal']
        need(audit['version']==114 and audit['mode']=='A0' and len(audit['records'])==len(events)==left['metrics']['native_new_signals'],'114A0全new票')
        for row,event in zip(audit['records'],events):
            request=row['request']
            need(row['allowed'] is True and row['selected']==2 and request['product']=='NK225mini','114A0全許可')
            equal((request['method'],request['signal_id'],request['side'],request['at']),
                  (event['method'],event['signal_id'],event['side'],{k:event['quote'][k] for k in ('time','index','source_line')}),'114A0元要求行固定')
            equal((row['quote'],row['accepted_quantity'],row['available'],row['order_id']),
                  (event['quote'],event['actual_accepted'],event['available'],event['order_id']),'114A0実受付結合')
        changed=left['stream_scope']!=right['stream_scope']
        need(left['stream_scope'].startswith('114:') and right['stream_scope'].startswith('113:'),'版付きScope説明')
        left['stream_scope']=right['stream_scope']=''
        del left['entry_gate'];del left['config']['entry_mode'];left['key']=oldkey
        normalized=normalize_ids(left,left['session']['id']+'-'+key+'-',right['session']['id']+'-'+oldkey+'-')
        equal(left,right,'114A0/113P100の全金融と全State.'+key)
        details[key]={'entry_mode':'A0','protection':'P100','stream_scope_difference':changed,'config_mode_separated':True,
                      'gate_records':len(events),'normalized_ids':normalized,'all_financial_equal':True}
    trace=value['reference113']
    need(trace['comparisons']==4 and trace['all_financial_equal'] is True and trace['source_equal'] is True,'Core113四対照成功')
    equal(trace['details'],details,'Go対照と独立Pythonの差件数')
    return {'comparisons':4,'all_financial_equal':True,'source_equal':True,'details':details}


def verify_source(value: dict, artificial: bool) -> dict:
    """機能: 全12へ同じSource通知を配送したこととD0新規の出典を照合する。

    引数: value(dict)、artificial(bool)は当場Nativeと手製区分。
    返り値: dictはSource非干渉・D0新規結合数。S0口座の成績へ偽装しない。
    """
    source,actual=value['source'],value['actual']
    need(source['complete'] is True and actual['complete'] is True,'Sourceと実口座完結')
    baseline=source_projection(source['books']['S0_C0_D0'])
    for key in KEYS:equal(source_projection(actual['books'][key]),baseline,'114全12の同Source通知.'+key)
    bound=allocated=0
    if not artificial:
        equal(source['explicit_timer_calls'],0,'元timerなし')
        need(source['mini_source_D0_fill_equal'] is True,'源D0同体flag')
        minis={k.removeprefix('NK225mini_'):b for k,b in source['sources'].items() if k.startswith('NK225mini_')}
        new={(method,r['fill']['SignalID']):r for method,ledger in minis.items() for r in ledger['fills'] if r['action']=='new'}
        for key in KEYS:
            if BY_KEY[key]['delay_seconds']!=0:continue
            for fill in actual['books'][key]['fills']:
                if fill['action']!='new':continue
                origin=new[(BASE.SOURCE_METHODS[fill['source']['method']],fill['source']['signal_id'])]
                equal(fill['quote'],origin['quote'],'114D0のSource初回取得原行')
                equal(fill['price'],origin['fill']['Price'],'114D0のSource初回取得価格')
                need(fill['quantity']<=origin['fill']['Quantity'],'114D0元割当上限')
                bound+=1;allocated+=fill['quantity']!=origin['fill']['Quantity']
    return {'全12の元通知同体':True,'Source全JSON同体は旧113対照で確認':True,'D0源新規結合':bound,
            'D0源出生から割当減少':allocated,'手製Source器具':artificial,'当時保存166との同体':value['original_historical_events_equal']}


def inspect_scene(value: dict, prior: dict, protection, entry_guard, artificial: bool=False) -> dict:
    """機能: 114全12金融・共通P100・独立入口票・旧四対照を結合する。

    引数: value/prior(dict)、protection/entry_guard(module)、artificial(bool)は新旧台帳・独立監査と手製区分。
    返り値: dictはchecked/source/reference113/入口検査。Rawや金融Goを再実行しない。
    """
    actual=value['actual']
    need(value['version']==1 and value['trial']==114 and actual['version']==1 and actual['trial']==114 and actual['complete'] is True,'114完結Native')
    equal(actual['configurations'],list(A.CONFIGS),'114本名12宣言と順序')
    equal(set(actual['books']),set(KEYS),'114全12集合')
    equal(actual['entry_grid_seconds'],None,'114追加新規時計なし')
    equal(actual['extra_opening_quiet_seconds'],0,'114追加静観なし')
    equal(actual['explicit_timers'],0,'114追加timerなし')
    equal(actual['chart_seed_mode'],'cold_each_session','114当場cold')
    equal(actual['scope']['session'],value['source']['session'],'114Source場')
    equal(actual['scope']['contract'],value['source']['contract'],'114Source限月')
    equal(actual['counts']['publications'],len(actual['publications'] or []),'114公開数')
    equal(actual['counts']['resets'],len(actual['resets'] or []),'114reset数')
    checked={};entries={}
    for key,config in BY_KEY.items():
        book=actual['books'][key]
        equal(book['session'],actual['scope']['session'],'114全12の同場')
        equal(book['metrics']['rows'],actual['counts']['rows'],'114全12受理原行数')
        equal(book['metrics']['bad_quote_rows'],actual['counts']['bad_quotes'],'114全12異常気配数')
        finance=A.verify_finance(book,config)
        finance['protection_counts']=protection.verify_protection(book,config,finance,actual)
        entries[key]=entry_guard.verify_entry_gate(book,config,actual)
        checked[key]=finance
    return {'checked':checked,'source':verify_source(value,artificial),'reference113':compare_reference113(value,prior),'entry':entries}


def save_viewer(value: dict,output: Path,market_path: str) -> list:
    """機能: 114本名12の実約定だけをViewer schema1へ新規保存する。

    引数: value(dict)、output(Path)、market_path(str)は当場値・未作成先・価格参照文字列。
    返り値: list[dict]は0取引も含む12資源。価格本文/HTTPを読まない。
    """
    resources=[];sid=value['actual']['scope']['session']['id']
    for key in KEYS:
        name=f'114_{key}_{sid}.trades.jsonl'
        with (output/name).open('x',encoding='utf-8',newline='\n') as stream:
            for row in BASE.viewer_trades(value['actual']['books'][key]):
                stream.write(json.dumps(row,ensure_ascii=False,default=BASE.serial,allow_nan=False)+'\n')
        resources.append({'id':f'114_{key}_{sid}','title':f'順行反転取得と共通P100 {key} {sid}',
                          'symbol':'NK225','product':'NK225mini','session':sid,'method_id':key,'point_value':100,
                          'pnl_format':'trades','pnl_basis':'net','pnl_path':name,'market_path':market_path})
    return resources
