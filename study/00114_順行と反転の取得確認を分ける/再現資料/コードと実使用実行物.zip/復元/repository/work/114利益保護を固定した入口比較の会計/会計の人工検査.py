"""114手製Core24冊の金融/P/入口/旧対照と保存形式を独立検査する。"""

from copy import deepcopy
import importlib.util
from pathlib import Path
import tempfile
import sys
import unittest

import 金融の独立検算 as A
import 保存集計の共通部 as S
import 保存の入力ゲート as G
import 新保護の独立監査 as P
import 保護監査の人工検査 as T

ENTRY_PATH=S.ROOT/'work/114入口判定を独立検算する/検算する.py'


def entry_guard():
    """機能: 明示位置の独立入口Pythonを読み会計/Pと結合する。

    引数: なし。停止helperは入口停止・全所有SHAを先に認証する。
    返り値: moduleはGoを呼ばない三値・受付・fill監査。
    """
    spec=importlib.util.spec_from_file_location('114会計の独立入口監査',ENTRY_PATH)
    module=importlib.util.module_from_spec(spec)
    sys.path.insert(0,str(ENTRY_PATH.parent))
    try:spec.loader.exec_module(module)
    finally:sys.path.pop(0)
    return module


class Accounting114Tests(unittest.TestCase):
    """本名の全台帳を保ち、金融原値を書換えずに検算する。"""

    def test_core24_all_independent_and_reference(self) -> None:
        """機能: 全24冊の金融/P/入口と旧8冊全金融対照を検査する。

        引数: self(Accounting114Tests)は検査器。
        返り値: None。Sourceは手製API通知の範囲で照合する。
        """
        guard=entry_guard();count=0
        for value,prior in T.fixtures():
            checked=S.inspect_scene(value,prior,P,guard,artificial=True)
            self.assertEqual(len(checked['checked']),12)
            self.assertEqual(checked['reference113']['comparisons'],4)
            count+=len(checked['checked'])
        self.assertEqual(count,24)

    def test_actor_zero_trade_and_ratios(self) -> None:
        """機能: 反転だけの人工でTの0取引と未定義比率を保持する。

        引数: self(Accounting114Tests)は検査器。
        返り値: None。取引ゼロを場別から落とさない。
        """
        path=S.ROOT/'work/114順行反転取得を執行する会計/人工_独立判定用/買売人工.json'
        S.equal(S.digest(path),'002ce20aa432f2b3f36ec97e8d4a7dc771bc8bb4d484ab89c34d3a6642fde998','Actor24人工SHA')
        values=S.load(path)
        for side in ('買い','売り'):
            for key in ('T_C0_D0','T_C0_D1','T_C5_D0','T_C5_D1'):
                book=values[side][key];checked=A.verify_finance(book,A.BY_KEY[key])
                checked['protection_counts']={}
                row=S.summarize_book(book,checked)
                self.assertEqual(row['positions'],0)
                self.assertIsNone(row['PF']);self.assertIsNone(row['win_rate'])
                self.assertIsNone(row['average_profit_yen']);self.assertIsNone(row['average_loss_yen'])

    def test_viewer24_and_groups(self) -> None:
        """機能: 買売各12資源を保存・再読し三返済群の純額を会計へ照合する。

        引数: self(Accounting114Tests)は検査器。
        返り値: None。価格CSV本文やHTTPは読まない。
        """
        guard=entry_guard()
        for value,prior in T.fixtures():
            checked=S.inspect_scene(value,prior,P,guard,artificial=True)
            with tempfile.TemporaryDirectory(prefix='114会計人工_',dir=Path(__file__).resolve().parent) as temp:
                output=Path(temp)
                resources=S.save_viewer(value,output,'共用価格の参照だけ.csv')
                proof=S.verify_viewer(value,output,resources)
                self.assertEqual(len(resources),12)
                self.assertTrue(proof['全残0'])
                for key in S.KEYS:
                    row=S.summarize_book(value['actual']['books'][key],checked['checked'][key])
                    self.assertEqual(set(row['注文別']),{'Source','保護','起動前失効'})
                    self.assertEqual(row['注文別']['起動前失効']['要求'],0)
                    self.assertEqual(sum(group['返済片純額'] for group in row['注文別'].values()),row['net_yen'])

    def test_financial_and_original_mode_corruptions(self) -> None:
        """機能: 費用・所有・予約・純額・本名Config・選別票の金融矛盾を拒否する。

        引数: self(Accounting114Tests)は検査器。
        返り値: None。未知を偽や0へ補完して整合させない。
        """
        value,_=T.fixtures()[0];key='A0_C0_D0';book=value['actual']['books'][key];config=A.BY_KEY[key]
        for kind in ('fee','quantity','reserved','net','mode','gate'):
            broken=deepcopy(book);cfg=deepcopy(config)
            if kind=='fee':broken['fills'][0]['fee_yen']+=1
            elif kind=='quantity':broken['positions'][0]['initial_quantity']+=1
            elif kind=='reserved':broken['positions'][0]['reserved']+=1
            elif kind=='net':broken['totals']['net_yen']+=1
            elif kind=='mode':cfg['entry_mode']='P100'
            else:broken['entry_gate']['records'][0]['allowed']=False
            with self.subTest(kind=kind),self.assertRaises(ValueError):A.verify_finance(broken,cfg)

    def test_reference_113_financial_changes_rejected(self) -> None:
        """機能: A0旧四対照のSource・金額・State・受付偽装を拒否する。

        引数: self(Accounting114Tests)は検査器。
        返り値: None。保護の旧定義やC/M/P/Bを比較から除かない。
        """
        value,prior=T.fixtures()[0]
        for kind in ('source','net','state','gate'):
            bad=deepcopy(value)
            if kind=='source':bad['source']['complete']=False
            elif kind=='net':bad['actual']['books']['A0_C0_D0']['totals']['net_yen']+=1
            elif kind=='state':bad['actual']['books']['A0_C0_D0']['positions'][0]['protection113']['final_state']['closed_net_yen']+=1
            else:bad['actual']['books']['A0_C0_D0']['entry_gate']['records'][0]['allowed']=False
            with self.subTest(kind=kind),self.assertRaises(ValueError):S.compare_reference113(bad,prior)

    def test_unfixed_rejected_before_native(self) -> None:
        """機能: Root未固定・未解禁要求をNative参照前かつ出力先作成前に拒否する。

        引数: self(Accounting114Tests)は検査器。
        返り値: None。
        """
        self.assertEqual([len(G.planned_sessions(stage)) for stage in ('first2','base54','full70')],[2,54,70])
        with tempfile.TemporaryDirectory(prefix='114入口拒否_',dir=Path(__file__).resolve().parent) as temp:
            fixed=Path(temp)/'未解禁.json';output=Path(temp)/'出力'
            S.BASE.write_json(fixed,{'version':1,'trial':114,'fixed':False,'market_native_read_authorized':False})
            with self.assertRaises(ValueError):G.prepare(fixed,S.digest(fixed),output)
            self.assertFalse(output.exists())


if __name__=='__main__':unittest.main(verbosity=2)
