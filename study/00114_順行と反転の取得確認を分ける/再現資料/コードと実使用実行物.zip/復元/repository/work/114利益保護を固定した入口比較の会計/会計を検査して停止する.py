"""114の本名12金融・P100・入口独立監査を結合し保存器を停止する。"""

import argparse
from collections import Counter
import json
from pathlib import Path
import subprocess
import sys

import 保存集計の共通部 as S
import 保護監査の人工検査 as PTEST
import 会計の人工検査 as T
import 新保護の独立監査 as P

OWN=Path(__file__).resolve().parent
OWNED=('金融の独立検算.py','保存集計の共通部.py','保存の入力ゲート.py','保存する.py','会計の人工検査.py','会計を検査して停止する.py','会計_README.md')
ACTOR_SHA='2178d1fbe7b980d7f507d6d9c99c6cdef1a8bde8702e4e4a69dbe97b687a9b93'
P_SHA='f2c19983d428fd0bf6dbc49266751fb08498ed10bd754505bc6bed577ccd72dd'


def stop(entry_ref: dict) -> dict:
    """機能: Actor/P/独立入口停止を認証して全24人工と所有不変を固定する。

    引数: entry_ref(dict)は入口Pythonの停止FileRef。
    返り値: dictは会計停止Ref。市場Native/Raw/CSVを読まない。
    """
    target,output=OWN/'会計停止.json',OWN/'会計検査'
    S.need(not target.exists() and not output.exists(),'114会計停止の新規先')
    actor_path=S.ROOT/'work/114順行反転取得を執行する会計/Actor停止.json';p_path=OWN/'P停止.json'
    S.equal(S.digest(actor_path),ACTOR_SHA,'114Actor停止不変')
    S.equal(S.digest(p_path),P_SHA,'114P停止不変')
    S.equal(S.digest(Path(entry_ref['path'])),entry_ref['sha256'],'114入口独立停止')
    actor,pure,entry=S.load(actor_path),S.load(p_path),S.load(Path(entry_ref['path']))
    S.need(entry['成功'] is True and entry['市場前'] is True,'114入口独立の市場前成功')
    before={str(OWN/name):S.digest(OWN/name) for name in OWNED}
    reused={str(actor_path):ACTOR_SHA,str(p_path):P_SHA,entry_ref['path']:entry_ref['sha256'],
            str(S.A.PREVIOUS_PATH):S.A.PREVIOUS_SHA,str(S.PREVIOUS_PATH):S.PREVIOUS_SHA,
            str(P.PREVIOUS_PATH):P.PREVIOUS_SHA,str(PTEST.MANIFEST):PTEST.MANIFEST_SHA}
    for data in (actor,pure,entry):
        for field in ('所有コードSHA256','所有ファイルSHA256','再用コードSHA256','再用ファイルSHA256','依存SHA256','依存コードSHA256','Root独立式SHA256'):
            reused.update(data.get(field,{}))
    for case in S.load(PTEST.MANIFEST)['cases']:
        for role in ('current','prior113'):reused[case[role]['path']]=case[role]['sha256']
    S.need(all(S.digest(Path(p))==h for p,h in reused.items()),'114会計の依存現物SHA')
    output.mkdir()
    test=subprocess.run([sys.executable,'-X','utf8',str(OWN/'会計の人工検査.py')],cwd=OWN,capture_output=True,text=True,encoding='utf-8',timeout=90)
    log=output/'人工検査.txt';log.write_text(test.stdout+test.stderr,encoding='utf-8',newline='\n')
    S.need(test.returncode==0,'114会計の全人工成功')
    p_counts=Counter();entry_counts=Counter();guard=T.entry_guard()
    for current,prior in PTEST.fixtures():
        inspected=S.inspect_scene(current,prior,P,guard,artificial=True)
        for checked in inspected['checked'].values():p_counts.update(checked['protection_counts']['counts'])
        for checked in inspected['entry'].values():entry_counts.update(checked['counts'])
    after={p:S.digest(Path(p)) for p in before}
    S.equal(after,before,'114会計所有前後不変')
    S.need(all(S.digest(Path(p))==h for p,h in reused.items()),'114会計依存/既停止前後不変')
    proof={'試行':114,'成功':True,'市場前':True,'主人工':6,'Core手製会計':24,'旧113P100全金融対照':8,
           'Source全文と全12への同通知':True,'P保存点':dict(p_counts),'入口票独立':dict(entry_counts),
           '0取引と未定義比率保持':True,'Viewer24保存再読':True,'Source受付minの派生一式だけ':True,
           'ログ':{'path':str(log),'sha256':S.digest(log)},'所有ファイルSHA256前':before,'所有ファイルSHA256後':after,
           '前後不変':True,'実市場/Raw/価格CSV/11月09日本文':False}
    proof_path=output/'人工確認.json';S.BASE.write_json(proof_path,proof)
    record={'試行':114,'成功':True,'市場前':True,'所有ファイルSHA256':before,'再用ファイルSHA256':reused,
            'Actor停止':{'path':str(actor_path),'sha256':ACTOR_SHA},'P停止':{'path':str(p_path),'sha256':P_SHA},
            '入口独立停止':entry_ref,'人工確認':{'path':str(proof_path),'sha256':S.digest(proof_path)},
            '前後不変':True,'実市場/Raw/価格CSV/11月09日本文':False,'研究目標達成':False,'採用':False}
    S.BASE.write_json(target,record)
    return {'成功':True,'停止':{'path':str(target),'sha256':S.digest(target)}}


def main() -> None:
    """機能: 明示入口Python停止Refで114会計を市場前停止する。

    引数: CLI entry-stop/entry-sha(str)は絶対停止先と期待SHA。
    返り値: None。会計停止Refだけを表示する。
    """
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--entry-stop',type=Path,required=True)
    parser.add_argument('--entry-sha',required=True)
    args=parser.parse_args()
    print(json.dumps(stop({'path':str(args.entry_stop.resolve()),'sha256':args.entry_sha}),ensure_ascii=False))


if __name__=='__main__':main()
