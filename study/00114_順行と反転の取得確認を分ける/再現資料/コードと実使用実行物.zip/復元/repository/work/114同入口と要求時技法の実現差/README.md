# 114の同入口と要求時技法の実現差

市場前の比較器。114の金融条件F2・全70成功・入口独立成功・会計保存成功を新しいRoot要求で認証した後だけNativeを読む。金融再実行、Raw、価格CSV、11月09日、未参加の仮損益、退出後の仮利益は扱わない。

対照はA0→T、A0→TR、T→TRの各C0/C5×D0/D1、合計12。113の停止済み演算をSHA固定で無変更再用する。Sourceの場・商品・手法・方向・signal_idで出生を結び、実取得原行の全値・価格・数量・SourceHold・出生タグを照合して、同実入口／取得変更／前のみ／後のみを区別する。入口選別が容量と後続取得に影響する可能性も残す。

要求時のT真／R真／双方偽／TR未知を排他的に記録し、input_missingとselected_false／unknownは別軸とする。T/RはG符号によって排他。ownerは保存されたcore/addon/episodeだけであり、元の売買意図を推定しない。実取得がない要求は件数だけを出す。

T/RのSource出生数、実取得数、distinct公表ID数を別記する。同じ最新公表を複数Source要求が参照することを許す。公表IDは場との複合で重複除去し、費用4条件や同じFrameを独立した市場機会として合算しない。共通入口では実注文IDを返済順序へ厳密結合した上で、初期P100・全返済要求・実fill・保護保存履歴・終端を比較する。実ID以外の金融値は除外しない。

収支・利益/損失総額・枚数・正益後赤字・起動後赤字・返済役割・四群差を全70／元54／追加16／11月06と全枝／各ownerで残す。部分群のDDは実約定cash列DD（新規費用と部分返済を原行内fill順で反映）。全口座の保存点連結時価DDは独立保存結果から別列へ結合し、尺度を混ぜない。

## 実行

まず `python -X utf8 検査して停止する.py`。人工はCore買売24冊（自然Source生成ではない）と手計算・破壊反例・本文前ゲートを使う。人工Sourceのowner/holdsは人工器具内で明示的に補う。実市場の証明とは扱わない。

Rootの新要求は次のフィールドを持つ。

```json
{
  "version": 1,
  "trial": 114,
  "fixed": true,
  "market_native_read_authorized": true,
  "stage": "full70",
  "comparison_stop": {"path": "停止.jsonの絶対位置", "sha256": "SHA256"},
  "condition": {"path": "F2条件の絶対位置", "sha256": "b0bf17c4bcd435dcca13da12995a11a9c6f5617f86a27ca2f0994528a3823167"},
  "completion": {"path": "全70金融完了の絶対位置", "sha256": "SHA256"},
  "saved_result": {"path": "全70独立保存結果の絶対位置", "sha256": "SHA256"},
  "saved_check": {"path": "全70保存会計の確認の絶対位置", "sha256": "SHA256"},
  "entry_check": {"path": "全70入口独立結果の絶対位置", "sha256": "SHA256"},
  "output_dir": "本フォルダ内の未作成の絶対位置"
}
```

`python -X utf8 診断する.py --fixed 絶対要求path --sha256 要求SHA --metadata-only` はNative本文を読まない。同じ引数から `--metadata-only` を除くと認証済みNativeだけを読み、新しい結果JSONと小対応台帳gzipを保存する。停止物・金融条件・閾値は変更しない。金融/入口検算そのものは別の独立保存器に依存し、ここで重複した全tickエンジンを作らない。
