"""Root全成功と入口/会計独立成功の後だけ、114同入口と要求時技法を診断する。"""
from collections import Counter, defaultdict
from datetime import date, timedelta
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import re

import 実現差の演算 as C

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
OWNED=("実現差の演算.py","診断する.py","人工検査.py","検査して停止する.py","README.md")
F2_SHA="b0bf17c4bcd435dcca13da12995a11a9c6f5617f86a27ca2f0994528a3823167"
DEPS={
    "旧同入口":{"path":str(ROOT/"work/113同入口の実現収支差の独立診断/停止.json"),"sha256":"4cb4485383e66b17bb3775cd967c1b2623cfda2484b2be90d30d8727fa39c61f"},
    "会計":{"path":str(ROOT/"work/114利益保護を固定した入口比較の会計/会計停止.json"),"sha256":"1c746b02409398afcbd70f4aea6362ddb3da0a30e80fa0c7ca4aba0139a8373c"},
    "P":{"path":str(ROOT/"work/114利益保護を固定した入口比較の会計/P停止.json"),"sha256":"f2c19983d428fd0bf6dbc49266751fb08498ed10bd754505bc6bed577ccd72dd"},
    "入口":{"path":str(ROOT/"work/114入口判定を独立検算する/停止.json"),"sha256":"369eda8990de9faa430ca575b3cf6f114abf73bea1cfebf32522ceef166f1eb6"},
    "Actor":{"path":str(ROOT/"work/114順行反転取得を執行する会計/Actor停止.json"),"sha256":"2178d1fbe7b980d7f507d6d9c99c6cdef1a8bde8702e4e4a69dbe97b687a9b93"},
    "純入口":{"path":str(ROOT/"work/114順行と反転取得の純判定/停止.json"),"sha256":"3e721f461a0b737140771335bcee67c033f3413a911910cf256f1b453f8037d6"},
    "Core":{"path":str(ROOT/"work/114順行と反転取得の連続比較/停止.json"),"sha256":"8e48f8c008a3bb6ab72ef9ec21f2b474dc403c79aa4a6b1a34f7b1d30d0ae729"},
}


def digest(path: Path) -> str:
    """
    機能: 明示コード/小metadata/解禁Nativeの指紋を求める。
    引数: path(Path)。返り値: strはSHA256。Rawは対象外。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reject(value: str) -> None:
    """
    機能: 非有限JSON数値を拒否する。
    引数: value(str)。返り値: None。必ずValueError。
    """
    raise ValueError("非有限値:"+value)


def load(path: Path) -> dict:
    """
    機能: 認証済みJSON/gzipJSONを十進数で読む。
    引数: path(Path)。返り値: dictは保存原値。
    """
    opener=gzip.open if path.suffix==".gz" else open
    with opener(path,"rt",encoding="utf-8-sig") as f:return json.load(f,parse_float=C.Decimal,parse_constant=reject)


def write(path: Path, value: dict) -> dict:
    """
    機能: 新規UTF-8 JSONだけを保存する。
    引数: path(Path)、value(dict)。返り値: dictはFileRef。
    """
    with path.open("x",encoding="utf-8",newline="\n") as f:f.write(json.dumps(value,ensure_ascii=False,indent=2,default=C.serial,allow_nan=False)+"\n")
    return {"path":str(path.resolve()),"sha256":digest(path)}


def reference(ref: dict, before: dict) -> Path:
    """
    機能: 明示絶対参照をSHA認証して前後台帳へ結ぶ。
    引数: ref/before(dict)。返り値: Pathは認証済み位置。
    """
    C.need(isinstance(ref,dict) and isinstance(ref.get("path"),str) and re.fullmatch("[a-f0-9]{64}",ref.get("sha256","")) is not None,"FileRef型")
    p=Path(ref["path"]);C.need(p.is_absolute(),"絶対Ref");p=p.resolve()
    C.need(digest(p)==ref["sha256"] and (str(p) not in before or before[str(p)]==ref["sha256"]),"Ref現物SHA")
    before[str(p)]=ref["sha256"];return p


def same_ref(a: dict, b: dict) -> bool:
    """
    機能: slash/付加bytesによらず解決絶対PathとSHAを比較する。
    引数: a/b(dict)。返り値: boolは同体性。
    """
    return isinstance(a,dict) and isinstance(b,dict) and isinstance(a.get("path"),str) and isinstance(b.get("path"),str) and Path(a["path"]).is_absolute() and Path(b["path"]).is_absolute() and Path(a["path"]).resolve()==Path(b["path"]).resolve() and a.get("sha256")==b.get("sha256")


def sessions() -> list[str]:
    """
    機能: 既使用70場の予定順を固定する。
    引数: なし。返り値: list[str]は11/09を含まない。
    """
    day,result=date(2026,9,21),[]
    while day<=date(2026,11,6):
        if day.weekday()<5:result.extend(f"{day.isoformat()}_{kind}" for kind in ("Day","Night"))
        day+=timedelta(days=1)
    C.need(len(result)==70,"予定70");return result


def dependencies(before: dict) -> None:
    """
    機能: 旧同入口/金融/入口停止と所有コードの現物を認証する。
    引数: before(dict)。返り値: None。金融/市場を実行しない。
    """
    for ref in DEPS.values():
        stop=load(reference(ref,before));C.need(stop["成功"] and stop.get("市場前",stop.get("停止")),"依存停止")
        for field in ("所有コードSHA256","所有ファイルSHA256","Root独立式SHA256"):
            for p,sha in stop.get(field,{}).items():reference({"path":p,"sha256":sha},before)
    reference({"path":str(C.PRIOR),"sha256":C.PRIOR_SHA},before)


def prepare(path: Path, sha: str) -> dict:
    """
    機能: Root全70解禁/全成功/会計・入口独立成功をNative本文前に認証する。
    引数: path(Path)、sha(str)。返り値: dictは読取計画。市場価格を開かない。
    """
    before={};request=load(reference({"path":str(path.resolve()),"sha256":sha},before))
    C.need(request["version"]==1 and request["trial"]==114 and request["fixed"] is True and request["market_native_read_authorized"] is True and request["stage"]=="full70","Root新全70解禁")
    stopped=load(reference(request["comparison_stop"],before))
    own={str((HERE/n).resolve()):digest(HERE/n) for n in OWNED}
    C.need(stopped["試行"]==114 and stopped["成功"] and stopped["市場前"] and stopped["所有ファイルSHA256"]==own and stopped["依存停止"]==DEPS,"実比較器停止")
    before.update(own);dependencies(before)
    condition=load(reference(request["condition"],before));complete=load(reference(request["completion"],before))
    saved=load(reference(request["saved_result"],before));checked=load(reference(request["saved_check"],before));entry=load(reference(request["entry_check"],before))
    C.need(request["condition"]["sha256"]==F2_SHA and condition["trial"]==114 and condition["fixed"] and condition["actual_configurations"]==list(C.CONFIGS),"同F2/全12")
    C.need(complete["trial"]==114 and complete["success"] and complete["stage"]=="full70" and complete["sessions"]==70 and complete["books"]==840 and complete["reused_sessions"]==54 and complete["replayed_sessions"]==16,"金融全70成功")
    C.need(complete["condition_sha256"]==F2_SHA and complete["unchanged"] and complete["before"] and complete["before"]==complete["after"] and complete["all_reference113_equal"] and complete["reference113_comparisons"]==280 and complete["all_source111_equal"],"同条件/元対照/不変")
    for value in (saved,checked,entry):
        C.need(value["試行"]==114 and value["成功"] and value["stage"]=="full70" and value["場数"]==70 and value["会計数"]==840 and value["前後不変"] and value["金融条件SHA256"]==F2_SHA and value["金融完了SHA256"]==request["completion"]["sha256"],"独立全70/同金融")
        C.need(value["入力codeSHA256前"] and value["入力codeSHA256前"]==value["入力codeSHA256後"],"各独立前後不変")
    C.need(saved["保存器停止SHA256"]==checked["保存器停止SHA256"]==DEPS["会計"]["sha256"] and saved["独立P停止SHA256"]==DEPS["P"]["sha256"] and entry["入口独立停止SHA256"]==DEPS["入口"]["sha256"],"独立停止結合")
    C.need(checked["出力SHA256"]["結果.json"]==request["saved_result"]["sha256"] and checked["全残玉予約0"] and checked["全Source111同体"] and checked["旧113全金融比較"]==280 and checked["不一致数"]==0,"全保存後検算")
    expected=sessions();C.need([r["session"] for r in complete["results"]]==[r["session"] for r in saved["Native参照"]]==[r["session"] for r in entry["場別"]]==expected,"全70予定順")
    C.need(tuple(saved["主key"])==C.KEYS,"独立全12集合")
    for final,ref in zip(complete["results"],saved["Native参照"]):
        C.need(same_ref(final["native"],ref) and entry["入力codeSHA256前"].get(str(Path(ref["path"]).resolve()))==ref["sha256"],"同じ金融/保存/入口Native")
        C.need(final["books"]==12 and final["complete"] and final["A0_equal"] and final["A0_comparisons"]==4 and final["reference113_equal"] and final["reference113_comparisons"]==4 and final["source111_equal"] and final["open_quantity"]==final["pending_quantity"]==0,"場別flatと全対照")
    financial={(r["session"],r["key"]):r for r in saved["場別"]}
    C.need(len(financial)==840 and set(financial)=={(sid,key) for sid in expected for key in C.KEYS},"0取引を含む全840")
    output=Path(request["output_dir"]);C.need(output.is_absolute() and output.resolve().is_relative_to(HERE) and not output.exists(),"所有範囲新規先")
    return {"request":request,"saved":saved,"entry":entry,"financial":financial,"before":before,"output":output.resolve()}


def run(plan: dict, request_ref: dict) -> dict:
    """
    機能: 全70成功後に12実対照・要求分母・公表ID・同保護退出を保存する。
    引数: plan/request_ref(dict)。返り値: dictは結果Ref。未参加仮益を作らない。
    """
    total_groups={f"{a}→{b}_C{c}_D{d}":{name:{side:[] for side in ("前","後")} for name in C.GROUPS} for a,b in C.PAIRS for c in (0,5) for d in (0,1)}
    all_requests={key:[] for key in C.KEYS};scene_rows=[];matches=[];differences=defaultdict(Counter)
    for ref in plan["saved"]["Native参照"]:
        native=load(reference(ref,plan["before"]));sid=ref["session"];actual=native["actual"]
        C.need(native["trial"]==actual["trial"]==114 and actual["complete"] and actual["scope"]["session"]["id"]==sid and set(actual["books"])==set(C.KEYS),"当場全12")
        index=C.source_index(native);books={}
        for key in C.KEYS:
            book=actual["books"][key];C.need(book["key"]==key and book["totals"]["net_yen"]==plan["financial"][(sid,key)]["net_yen"],"実純額と独立保存")
            books[key]=C.records(book,index);all_requests[key].extend(C.gate_rows(book,index))
        for a,b in C.PAIRS:
            for c in (0,5):
                for d in (0,1):
                    name=f"{a}→{b}_C{c}_D{d}";groups,paired,changed,exits=C.pair_records(books[f"{a}_C{c}_D{d}"],books[f"{b}_C{c}_D{d}"])
                    for group in C.GROUPS:
                        for side in ("前","後"):total_groups[name][group][side].extend(groups[group][side])
                    scene_rows.append({"session":sid,"対照":name,**C.summarize(groups,"全70","全枝"),"入口変更属性":changed,"共通返済":exits})
                    matches.extend({"session":sid,"対照":name,**row} for row in paired);differences[name].update(changed)
    aggregate=[];coverage=[]
    for a,b in C.PAIRS:
        for c in (0,5):
            for d in (0,1):
                ak,bk=f"{a}_C{c}_D{d}",f"{b}_C{c}_D{d}";name=f"{a}→{b}_C{c}_D{d}"
                for period in C.PERIODS:
                    mtm={side:C.mtm_dd([r for r in plan["saved"]["場別"] if r["key"]==key and C.selected(r,period,"全枝")]) for side,key in (("前",ak),("後",bk))}
                    for owner in C.OWNERS:
                        summary=C.summarize(total_groups[name],period,owner)
                        if period=="全70" and owner=="全枝":
                            for side,key in (("前",ak),("後",bk)):
                                C.need(summary["全体"][side]["実現円"]==plan["saved"]["集計"][key]["net_yen"] and mtm[side]==plan["saved"]["集計"][key]["保存点連結時価DD"],"全独立額/DDへ一致")
                        aggregate.append({"対照":name,"期間":period,"owner":owner,**summary,"全口座保存点連結時価DD円":mtm if owner=="全枝" else None})
    for key in C.KEYS:
        for period in C.PERIODS:
            for owner in C.OWNERS:coverage.append({"key":key,"期間":period,"owner":owner,**C.coverage([r for r in all_requests[key] if C.selected(r,period,owner)])})
    C.need(len(aggregate)==240 and len(scene_rows)==840 and len(coverage)==240,"固定12対照/全期間owner保持")
    after={p:digest(Path(p)) for p in plan["before"]};C.need(after==plan["before"],"全金融code前後不変")
    output=plan["output"];output.mkdir(parents=False,exist_ok=False);matchpath=output/"実entry対応.jsonl.gz"
    with matchpath.open("xb") as f:
        with gzip.GzipFile(fileobj=f,mode="wb",filename="",mtime=0) as z:
            for row in matches:z.write((json.dumps(row,ensure_ascii=False,separators=(",",":"),default=C.serial,allow_nan=False)+"\n").encode("utf-8"))
    result={"試行":114,"成功":True,"stage":"full70","場数":70,"対照数":12,"場別対照数":840,"Root要求":request_ref,"金融条件SHA256":F2_SHA,"金融完了SHA256":plan["request"]["completion"]["sha256"],"入口独立結果SHA256":plan["request"]["entry_check"]["sha256"],"集計":aggregate,"場別":scene_rows,"全Source要求時技法":coverage,"入口差属性":{k:dict(v) for k,v in differences.items()},"対応台帳":{"path":str(matchpath),"sha256":digest(matchpath),"件数":len(matches)},"入力SHA256前":plan["before"],"入力SHA256後":after,"前後不変":True,"定義":["差は後−前。四群は同入口/取得変更/前のみ/後のみ。","要求分類とinput_missing/selected_false/unknownは別軸。未取得は件数だけ、仮PnLなし。","T/Rの出生/取得数とdistinct公表ID数は別。同じ公表で複数出生を許す。費用反復を独立機会数にしない。","枝別cash列DDと全口座保存点連結時価DDは別列。","共通入口で初期P100/全返済/保護履歴を実IDの結合検査後に比較。入口変更による後続容量変化を残す。"],"未実施":{"Raw/価格CSV/11月09":0,"金融再走":0,"退出後仮利益/未参加仮PnL/機会損失/MFE":0},"閾値変更":False}
    return write(output/"結果.json",result)


def main() -> None:
    """
    機能: Rootの新固定要求だけから全成功診断を呼ぶ。
    引数: CLI fixed/sha256(str)、metadata-only(bool)。返り値: None。
    """
    p=argparse.ArgumentParser();p.add_argument("--fixed",type=Path,required=True);p.add_argument("--sha256",required=True);p.add_argument("--metadata-only",action="store_true");args=p.parse_args()
    plan=prepare(args.fixed,args.sha256)
    if args.metadata_only:print(json.dumps({"成功":True,"Native本文読取":False},ensure_ascii=False));return
    ref=run(plan,{"path":str(args.fixed.resolve()),"sha256":args.sha256});print(json.dumps({"成功":True,"結果":ref},ensure_ascii=False))


if __name__=="__main__":main()
