"""114同入口・要求時技法の独立診断を人工だけで固定する。"""
from pathlib import Path
from datetime import datetime,timezone
import ast
import subprocess
import sys

import 診断する as D


def main() -> None:
    """
    機能: 所有5ファイル・依存停止・10人工を市場前に認証して新停止を作る。
    引数: なし。返り値: None。市場/Raw本文や金融エンジンを実行しない。
    """
    target=D.HERE/"停止.json";D.C.need(not target.exists(),"新規停止のみ")
    before={};D.dependencies(before);owned={str((D.HERE/n).resolve()):D.digest(D.HERE/n) for n in D.OWNED}
    for name in D.OWNED:
        if not name.endswith(".py"):continue
        for node in ast.walk(ast.parse((D.HERE/name).read_text(encoding="utf-8"))):
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                doc=ast.get_docstring(node) or "";D.C.need("\n" in doc and all(w in doc for w in ("機能","引数","返り値")),"関数コメント:"+node.name)
    logs=[]
    for command in ([sys.executable,"-X","utf8",str(D.HERE/"人工検査.py")],[sys.executable,"-X","utf8",str(D.HERE/"診断する.py"),"--help"]):
        p=subprocess.run(command,cwd=D.HERE,capture_output=True,text=True,encoding="utf-8",timeout=60);D.C.need(p.returncode==0,p.stdout+p.stderr);logs.append({"command":command,"exit":p.returncode,"stdout":p.stdout,"stderr":p.stderr})
    D.C.need("Ran 10 tests" in logs[0]["stderr"] and "OK" in logs[0]["stderr"],"10人工")
    D.C.need(before=={p:D.digest(Path(p)) for p in before} and owned=={p:D.digest(Path(p)) for p in owned},"全所有依存前後不変")
    proof={"試行":114,"成功":True,"市場前":True,"UTC":datetime.now(timezone.utc).isoformat(),"所有ファイルSHA256":owned,"依存停止":D.DEPS,"元停止codeSHA256":before,"前後不変":True,"主人工":10,"指定対照":list(D.C.PAIRS),"費用":4,"全対照":12,"期間":D.C.PERIODS,"owner":D.C.OWNERS,"検査ログ":logs,"市場Native本文/Raw/金融再実行/11月09":False,"閾値変更":False}
    print(__import__("json").dumps({"成功":True,"停止":D.write(target,proof)},ensure_ascii=False))


if __name__=="__main__":main()
