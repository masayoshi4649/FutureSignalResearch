"""人工の成立玉・全Source要求・同保護・本文前ゲートを検査する。"""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest

import 実現差の演算 as C
import 診断する as D

ART=D.ROOT/"work/114順行と反転取得の連続比較/人工_独立保存用/人工.json"
ART_SHA="ad8d3498c8a08afe0fabdee3d1a24f9dd4b16e43f4bf72e07a45493c03f82419"


def artificial_cases() -> list[dict]:
    """
    機能: 解禁されたCore人工だけに手製Source出生/hold/ownerを補い比較器へ渡す。
    引数: なし。返り値: list[dict]は買売Nativeコピー。自然Source事実とは扱わない。
    """
    manifest=D.load(D.reference({"path":str(ART.resolve()),"sha256":ART_SHA},{}));result=[]
    for case in manifest["cases"]:
        n=D.load(D.reference(case["current"],{}));a=n["actual"];sources={}
        for ordinal,r in enumerate(a["books"]["A0_C0_D0"]["entry_gate"]["records"]):
            source=r["source"];method=source["method"];sid=source["signal_id"]
            src=sources.setdefault(method,{"session":n["source"]["session"],"config":{"product":"NK225mini"},"method":method,"signals":[],"holds":[]})
            e={k:source[k] for k in ("method","kind","parent","source_id","quantity_micro")}
            signal={"id":sid,"action":"new","side":r["request"]["side"],"time":source["birth_time"],"owner":("core","episode")[ordinal%2],"campaign":0,"evidence":e}
            src["signals"].append({"at":source["birth_time"],"quote":source["birth_quote"],"signal":signal})
            holds={p["source_hold_id"] for b in a["books"].values() for p in b["positions"] if p["source"]["signal_id"]==sid and p["source"]["method"]==method}
            src["holds"].extend({"hold_id":h,"entry_id":sid,"side":signal["side"],**{k:e[k] for k in ("kind","parent","source_id")}} for h in sorted(holds))
        n["source"]["sources"]=sources;result.append(n)
    return result


def small_row(signal: str, net: int, owner: str="core", sid: str="2026-09-21_Day") -> dict:
    """
    機能: 四群・cash-DD・技法加法の手計算用に実現額を持つ人工玉を作る。
    引数: signal/owner/sid(str)、net(int)。返り値: dictは人工比較玉。
    """
    roles={n:{"要求":0,"約定":0,"約定枚":0,"返済片純額円":C.ZERO} for n in ("Source","利益保護","起動前失効")}
    roles["Source"].update({"要求":1,"約定":1,"約定枚":1,"返済片純額円":C.amount(net)})
    return {"base":(sid,"NK225mini","NK225_D164_15",1,signal),"entry":{"Source出生":{"id":signal},"SourceHold":signal,"実entry原行":{"time":1,"index":0,"source_line":1},"実entry価格":1000,"実entry枚":1},"owner":owner,"session":sid,"id":signal,"net":C.amount(net),"qty":1,"cash":[(sid,0,0,1,1,C.amount(net))],"role":roles,"whole_positive":True,"unit_positive":True,"active":False,"invalidated":False,"technical":{"class":"T真","input_missing":False,"selected":2,"frame_id":"同じ公表"},"exit":{"初期P100":{"H":100},"返済fill":{"net":net}}}


def gate_fixture(base: Path, partial: bool=False) -> dict:
    """
    機能: Native不存在の全70成功metadataを手製で作る。
    引数: base(Path)、partial(bool)。返り値: dictは人工Root要求Ref。
    """
    base.mkdir();condition={"path":str((D.ROOT/"work/114進行/F2_114金融条件_設計原文参照.json").resolve()),"sha256":D.F2_SHA}
    scenes=[];refs=[];financial=[];nativehash={}
    for sid in D.sessions():
        ref={"path":str((base/(sid+".Native.json.gz")).resolve()),"sha256":"a"*64};refs.append({"session":sid,**ref});nativehash[ref["path"]]=ref["sha256"]
        scenes.append({"session":sid,"native":ref,"books":12,"complete":True,"A0_equal":True,"A0_comparisons":4,"open_quantity":0,"pending_quantity":0,"reference113_equal":True,"source111_equal":True,"reference113_comparisons":4})
        financial.extend({"session":sid,"key":k,"net_yen":0} for k in C.KEYS)
    completion=D.write(base/"完了.json",{"trial":114,"stage":"full70","success":True,"sessions":70,"books":840,"reused_sessions":54,"replayed_sessions":16,"condition_sha256":D.F2_SHA,"unchanged":True,"before":{"code":"a"},"after":{"code":"a"},"all_reference113_equal":True,"all_source111_equal":True,"reference113_comparisons":280,"results":scenes[:-1] if partial else scenes})
    common={"試行":114,"成功":True,"stage":"full70","場数":70,"会計数":840,"前後不変":True,"金融条件SHA256":D.F2_SHA,"金融完了SHA256":completion["sha256"],"入力codeSHA256前":nativehash,"入力codeSHA256後":nativehash}
    saved=D.write(base/"保存.json",{**common,"保存器停止SHA256":D.DEPS["会計"]["sha256"],"独立P停止SHA256":D.DEPS["P"]["sha256"],"主key":list(C.KEYS),"Native参照":refs,"場別":financial})
    check=D.write(base/"検算.json",{**common,"保存器停止SHA256":D.DEPS["会計"]["sha256"],"出力SHA256":{"結果.json":saved["sha256"]},"全残玉予約0":True,"全Source111同体":True,"旧113全金融比較":280,"不一致数":0})
    entry=D.write(base/"入口.json",{**common,"入口独立停止SHA256":D.DEPS["入口"]["sha256"],"場別":[{"session":sid} for sid in D.sessions()]})
    stop=D.write(base/"停止.json",{"試行":114,"成功":True,"市場前":True,"依存停止":D.DEPS,"所有ファイルSHA256":{str((D.HERE/n).resolve()):D.digest(D.HERE/n) for n in D.OWNED}})
    return D.write(base/"要求.json",{"version":1,"trial":114,"fixed":True,"market_native_read_authorized":True,"stage":"full70","comparison_stop":stop,"condition":condition,"completion":completion,"saved_result":saved,"saved_check":check,"entry_check":entry,"output_dir":str((D.HERE/"人工未作成先").resolve())})


class ComparisonTests(unittest.TestCase):
    """市場を読まない比較の人工。"""

    def test_core_all_twelve_pairs_and_mirror(self):
        """
        機能: 買売各12冊の成立玉・全要求と12対照の共通退出を検査する。
        引数: self(ComparisonTests)。返り値: None。
        """
        counts=[]
        for native in artificial_cases():
            index=C.source_index(native);books=native["actual"]["books"];rows={k:C.records(books[k],index) for k in C.KEYS};stats=[]
            for a,b in C.PAIRS:
                for c in (0,5):
                    for d in (0,1):
                        groups,matched,diff,exits=C.pair_records(rows[f"{a}_C{c}_D{d}"],rows[f"{b}_C{c}_D{d}"])
                        total=C.summarize(groups,"全70","全枝")
                        self.assertEqual(total["全体"]["実現差円"],books[f"{b}_C{c}_D{d}"]["totals"]["net_yen"]-books[f"{a}_C{c}_D{d}"]["totals"]["net_yen"])
                        self.assertFalse(diff);self.assertEqual(exits["返済差あり"],0);self.assertEqual(exits["共通入口数"],exits["全返済と保存保護同体"]);stats.append((len(matched),exits["共通入口数"]))
            counts.append(stats)
        self.assertEqual(*counts)
        empty=deepcopy(books["A0_C0_D0"]);empty["positions"]=[];empty["orders"]=[];empty["fills"]=[];empty["entry_gate"]["records"]=[];empty["metrics"]["native_new_signals"]=0;empty["totals"]["net_yen"]=0
        self.assertEqual(C.records(empty,index),[]);self.assertEqual(C.coverage(C.gate_rows(empty,index))["Source出生数"],0)

    def test_four_groups_price_quote_qty_and_base(self):
        """
        機能: 同一出生でも実価格/量/原行を区別し、複合出生差を片側へ分ける。
        引数: self(ComparisonTests)。返り値: None。
        """
        a=[small_row("same",10),small_row("change",5),small_row("left",-30)];b=[small_row("same",10),small_row("change",7),small_row("right",40)]
        b[1]["entry"]["実entry枚"]=2;b[1]["entry"]["実entry価格"]=1005;b[1]["entry"]["実entry原行"]["source_line"]=2
        groups,match,diff,checks=C.pair_records(a,b);s=C.summarize(groups,"全70","全枝")
        self.assertEqual(s["全体"]["実現差円"],72);self.assertEqual(len(match),4);self.assertEqual(set(diff),{"実entry枚","実entry価格","実entry原行"});self.assertEqual(checks["共通入口数"],1)
        for i in range(4):
            x=small_row("same",10);key=list(x["base"]);key[i]=-1 if i==3 else "別";x["base"]=tuple(key)
            g,_,_,_=C.pair_records([a[0]],[x]);self.assertEqual(len(g["前のみ"]["前"]),1);self.assertFalse(g["同実入口"]["前"])
        with self.assertRaises(ValueError):C.pair_records([a[0],a[0]],[])

    def test_common_exit_change_and_id_binding(self):
        """
        機能: 共通入口の初期/実退出の差を隠さず、未結合audit IDを拒否する。
        引数: self(ComparisonTests)。返り値: None。
        """
        a=small_row("same",10);b=deepcopy(a);b["exit"]["初期P100"]["H"]=50
        _,_,_,checks=C.pair_records([a],[b]);self.assertEqual(checks["初期P100同体"],0);self.assertEqual(checks["返済差あり"],1)
        n=artificial_cases()[0];book=n["actual"]["books"]["A0_C0_D0"];position=deepcopy(book["positions"][0]);position["protection113"]["last"]["exit_order_id"]="存在しない注文"
        with self.assertRaises(ValueError):C.exit_signature(position,book)

    def test_four_technical_classes_and_denials(self):
        """
        機能: T/R排他と真OR未知、既知否定/不足/選別未知の別軸を確認する。
        引数: self(ComparisonTests)。返り値: None。
        """
        for t,r,e,name in ((2,0,2,"T真"),(0,2,2,"R真"),(1,1,1,"双方偽"),(1,0,0,"TR未知"),(0,0,0,"TR未知")):
            self.assertEqual(C.classification({"trend":t,"reversal":r,"combined":e}),name)
        for t,r,e in ((2,2,2),(1,1,0),(0,1,1)):
            with self.assertRaises(ValueError):C.classification({"trend":t,"reversal":r,"combined":e})
        rows=[]
        for name,chosen,missing in (("T真",2,True),("R真",1,False),("双方偽",1,False),("TR未知",0,True)):
            rows.append({"base":("a",),"session":"場","class":name,"selected":chosen,"input_missing":missing,"frame_id":"公表","accepted":False,"accepted_quantity":0,"acquired":False,"actual_quantity":0})
        cov=C.coverage(rows);self.assertEqual(cov["selected_false"],2);self.assertEqual(cov["selected_unknown"],1);self.assertEqual(cov["input_missing"],2);self.assertEqual(cov["実取得数"],0)

    def test_repeated_frame_birth_and_acquisition_counts(self):
        """
        機能: 最新R/T公表を複数出生が参照しても出生/取得とdistinct IDを混ぜない。
        引数: self(ComparisonTests)。返り値: None。
        """
        for name in ("T真","R真"):
            row={"session":"場","class":name,"selected":2,"input_missing":False,"frame_id":"同一公表","accepted":True,"accepted_quantity":2,"acquired":True,"actual_quantity":2}
            cov=C.coverage([row,deepcopy(row)]);s=cov["要求時技法"][name]
            self.assertEqual((s["Source出生数"],s["実取得数"],s["実取得枚"],s["distinct公表ID数"]),(2,2,4,1))
            row2={**row,"session":"別場"};self.assertEqual(C.coverage([row,row2])["要求時技法"][name]["distinct公表ID数"],2)

    def test_source_request_and_acquisition_corruption(self):
        """
        機能: 出生時計・選別票・実取得量・要求分母の改変を拒否する。
        引数: self(ComparisonTests)。返り値: None。
        """
        for field in ("time","selected","quantity","denominator"):
            n=artificial_cases()[0];b=n["actual"]["books"]["A0_C0_D0"];index=C.source_index(n)
            if field=="time":b["entry_gate"]["records"][0]["request"]["at"]["time"]+=1
            elif field=="selected":b["entry_gate"]["records"][0]["selected"]=1
            elif field=="quantity":b["entry_gate"]["records"][0]["actual_quantity"]+=1
            else:b["metrics"]["native_new_signals"]+=1
            with self.subTest(field=field),self.assertRaises(ValueError):C.records(b,index)

    def test_cash_fee_partial_and_dd_scale(self):
        """
        機能: 部分返済cash-DDと全口座時価DDの別尺度、同原行fill順を手計算する。
        引数: self(ComparisonTests)。返り値: None。
        """
        a=small_row("a",-154);a["cash"]=[(a["session"],0,0,0,1,C.Decimal("-77")),(a["session"],1,1,1,2,C.Decimal("961.5")),(a["session"],2,2,2,3,C.Decimal("-1038.5"))]
        self.assertEqual(C.OLD.statistics([a])["実約定cash列DD円"],C.Decimal("1038.5"))
        rows=[{"session":"b","場内時価DD":10,"保存最小時価":-30,"保存最大時価":20,"net_yen":-20},{"session":"a","場内時価DD":20,"保存最小時価":-10,"保存最大時価":100,"net_yen":40}]
        self.assertEqual(C.mtm_dd(rows),90);self.assertEqual(C.mtm_dd([]),0)
        b=small_row("b",-50);a=small_row("a",100);sid=a["session"];a["cash"]=[(sid,0,0,1,1,C.amount(-10)),(sid,1,2,2,2,C.amount(110))];b["cash"]=[(sid,0,1,1,1,C.amount(-10)),(sid,1,3,2,2,C.amount(-40))]
        self.assertEqual(C.OLD.statistics([b,a])["実約定cash列DD円"],40)

    def test_period_owner_technical_additivity(self):
        """
        機能: 事前の期間/owner/技法分類で全差加法を維持し空群を残す。
        引数: self(ComparisonTests)。返り値: None。
        """
        a=small_row("a",100,"core","2026-11-06_Day");b=small_row("b",-50,"episode","2026-09-21_Day");b["technical"]["class"]="R真"
        g,_,_,_=C.pair_records([a,b],[a]);s=C.summarize(g,"全70","全枝")
        self.assertEqual(s["全体"]["実現差円"],50);self.assertEqual(sum(x["実現差円"] for x in s["成立玉の要求時技法別"].values()),50)
        self.assertTrue(C.selected(a,"追加16","core"));self.assertFalse(C.selected(a,"元54","core"));self.assertEqual(C.summarize(g,"11月06","addon")["全体"]["前"]["玉"],0)

    def test_full70_gate_without_native_and_failures(self):
        """
        機能: 全70新解禁のみ許可し、Native不存在で拒否/metadata成功を確認する。
        引数: self(ComparisonTests)。返り値: None。
        """
        with tempfile.TemporaryDirectory(dir=D.HERE) as tmp:
            base=Path(tmp);ref=gate_fixture(base/"成功");plan=D.prepare(Path(ref["path"]),ref["sha256"])
            self.assertEqual(len(plan["saved"]["Native参照"]),70);self.assertTrue(all(not Path(r["path"]).exists() for r in plan["saved"]["Native参照"]));self.assertFalse(plan["output"].exists())
            for field,value in (("market_native_read_authorized",False),("stage","base54"),("trial",113)):
                request=D.load(Path(ref["path"]));request[field]=value;bad=D.write(base/(field+".json"),request)
                with self.subTest(field=field),self.assertRaises(ValueError):D.prepare(Path(bad["path"]),bad["sha256"])
            bad=gate_fixture(base/"未完了",True)
            with self.assertRaises(ValueError):D.prepare(Path(bad["path"]),bad["sha256"])

    def test_ref_slashes_bytes_and_sha(self):
        """
        機能: 参照付加bytes/slash差を許容し、別SHAは拒否する。
        引数: self(ComparisonTests)。返り値: None。
        """
        a={"path":str((D.HERE/"README.md").resolve()),"sha256":"a"*64};self.assertTrue(D.same_ref(a,{**a,"path":a["path"].replace("\\","/"),"bytes":123}));self.assertFalse(D.same_ref(a,{**a,"sha256":"b"*64}))


if __name__=="__main__":unittest.main(verbosity=2)
