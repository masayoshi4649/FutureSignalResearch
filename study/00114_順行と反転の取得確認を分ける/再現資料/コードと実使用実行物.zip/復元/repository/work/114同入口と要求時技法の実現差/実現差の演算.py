"""113固定の同入口演算を再用し、114の要求時分類と共通返済同体を追加する。"""
from collections import Counter
from copy import deepcopy
from pathlib import Path
import hashlib
import importlib.util

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PRIOR=ROOT/"work/113同入口の実現収支差の独立診断/実現差の演算.py"
PRIOR_SHA="db0af730042a7638a667ab9121e672278196ab876da49aaebddb3dc5a050c458"
if hashlib.sha256(PRIOR.read_bytes()).hexdigest()!=PRIOR_SHA:raise ValueError("固定113演算SHA差")
spec=importlib.util.spec_from_file_location("固定113同入口演算を114で再用",PRIOR)
OLD=importlib.util.module_from_spec(spec);spec.loader.exec_module(OLD)
need,amount,canon,serial=OLD.need,OLD.amount,OLD.canon,OLD.serial
source_index,selected,mtm_dd=OLD.source_index,OLD.selected,OLD.mtm_dd
Decimal,ZERO=OLD.Decimal,OLD.ZERO
GROUPS,OWNERS,PERIODS=OLD.GROUPS,OLD.OWNERS,OLD.PERIODS
MODES=("A0","T","TR")
KEYS=tuple(f"{m}_C{c}_D{d}" for m in MODES for c in (0,5) for d in (0,1))
CONFIGS=tuple({"policy":"P100","entry_mode":m,"slip_pts":c,"delay_seconds":d} for m in MODES for c in (0,5) for d in (0,1))
PAIRS=(("A0","T"),("A0","TR"),("T","TR"))
CLASSES=("T真","R真","双方偽","TR未知")


def classification(decision: dict) -> str:
    """
    機能: 当時の三値T/Rを排他的な4技法群へ分ける。
    引数: decision(dict)。返り値: strはT真/R真/双方偽/TR未知。元意図は推定しない。
    """
    t,r,either=decision["trend"],decision["reversal"],decision["combined"]
    need(t in (0,1,2) and r in (0,1,2) and either in (0,1,2),"三値範囲")
    need(not(t==r==2),"G符号によるT/R排他")
    expected=2 if 2 in (t,r) else 0 if 0 in (t,r) else 1
    need(either==expected,"TR論理和")
    return "T真" if t==2 else "R真" if r==2 else "双方偽" if t==r==1 else "TR未知"


def gate_rows(book: dict, index: dict) -> list[dict]:
    """
    機能: 実取得の有無にかかわらず全Source要求の技法・分母・公表IDだけを結ぶ。
    引数: book/index(dict)。返り値: list[dict]は価格仮益を持たない要求台帳。
    """
    rows=[];seen=set();sid=book["session"]["id"]
    for record in book["entry_gate"]["records"] or []:
        q,d=record["request"],record["decision"]
        need(q==d["request"] and d["frozen"],"要求時固定票")
        key=sid,q["product"],q["method"],q["side"],q["signal_id"]
        need(key not in seen and key in index,"要求Source複合結合")
        seen.add(key);source=index[key];signal=source["signal"]
        need(q["product"]=="NK225mini" and signal["side"]==q["side"] and signal["id"]==record["source"]["signal_id"],"元Signal方向/出生")
        need(source["record"]["quote"]==record["quote"] and source["record"]["at"]==q["at"]["time"],"Source要求原行")
        owner=signal.get("owner") or "不明";need(owner in OWNERS[1:],"未宣言owner")
        mode=book["config"]["entry_mode"]
        chosen=2 if mode=="A0" else d["trend"] if mode=="T" else d["combined"]
        need(record["selected"]==chosen and record["allowed"]==(chosen==2),"選別モード")
        current=d["current"];frame=None if current is None else current["frame"]["id"]
        rows.append({"base":key,"session":sid,"owner":owner,"class":classification(d),"input_missing":bool(d["missing_inputs"]),"selected":chosen,"frame_id":frame,
                     "accepted":record["accepted_quantity"]>0,"accepted_quantity":record["accepted_quantity"],"acquired":record["actual_quantity"]>0,"actual_quantity":record["actual_quantity"],"position_id":record["actual_position_id"],"decision":d})
    need(len(rows)==book["metrics"]["native_new_signals"],"全Source要求分母")
    return rows


def normalize_audit(value, exits: dict):
    """
    機能: 正当に結合された返済注文IDだけを位置番号へ写し、保護値を隠さない。
    引数: value(JSON値)、exits(dict[str,int])。返り値: JSON値は私有化した比較値。
    """
    if isinstance(value,list):return [normalize_audit(x,exits) for x in value]
    if isinstance(value,dict):
        out={}
        for key,item in value.items():
            if key=="exit_order_id" and item:
                need(item in exits,"保護auditの実返済ID")
                out[key]=exits[item]
            else:out[key]=normalize_audit(item,exits)
        return out
    return deepcopy(value)


def exit_signature(position: dict, book: dict) -> dict:
    """
    機能: 共通入口の初期P100・実返済要求/fill・保存保護履歴を比較可能にする。
    引数: position/book(dict)。返り値: dict。政策別実ID以外の金融値は保持する。
    """
    orders=[o for o in book["orders"] if o["kind"]=="exit" and o["position_id"]==position["id"]]
    numbers={o["id"]:i for i,o in enumerate(orders)}
    normalized_orders=[{k:deepcopy(v) for k,v in o.items() if k not in ("id","position_id","fill_id")} for o in orders]
    fills=[]
    for fill in book["fills"]:
        if fill["position_id"]!=position["id"] or fill["action"]!="close":continue
        need(fill["order_id"] in numbers,"共通返済fill所有")
        f={k:deepcopy(v) for k,v in fill.items() if k not in ("id","order_id","position_id")}
        f["order_ordinal"]=numbers[fill["order_id"]]
        f["allocations"]=[{k:deepcopy(v) for k,v in a.items() if k!="position_id"} for a in fill["allocations"]]
        fills.append(f)
    audit=position.get("protection113")
    need(audit is not None and audit["initial"]["entry"]["policy"]=="P100","共通P100実保護")
    return {"初期P100":deepcopy(audit["initial"]),"返済要求":normalized_orders,"返済fill":fills,
            "保存保護履歴":normalize_audit(audit,numbers),"終端":{k:deepcopy(position[k]) for k in ("closed_quantity","closed_quote","gross_yen","realized_net","marks","protection_active","activation","floor_gain","floor_updated","first_floor_hit","atr")}}


def records(book: dict, index: dict) -> list[dict]:
    """
    機能: 113固定演算の実玉へ要求時技法と共通退出照合値だけを追加する。
    引数: book/index(dict)。返り値: list[dict]は成立玉だけ。未取得の仮損益を作らない。
    """
    result=OLD.records(book,index)
    gates=gate_rows(book,index);acquired={r["position_id"]:r for r in gates if r["acquired"]}
    positions={p["id"]:p for p in book["positions"]}
    need(len(acquired)==sum(r["acquired"] for r in gates) and set(acquired)==set(positions),"全実玉の要求時票一対一")
    for row in result:
        request=acquired[row["id"]]
        need(request["base"]==row["base"] and request["actual_quantity"]==row["qty"],"実入口と要求出生量")
        row["technical"]={k:request[k] for k in ("class","input_missing","selected","frame_id")}
        row["exit"]=exit_signature(positions[row["id"]],book)
    return result


def coverage(rows: list[dict]) -> dict:
    """
    機能: 全要求のT/R等と選別票/不足/実取得を別集計し公表IDも重複除去する。
    引数: rows(list[dict])。返り値: dict。未取得側の損益は扱わない。
    """
    total=Counter({k:0 for k in ("Source出生数","selected_true","selected_false","selected_unknown","input_missing","受付数","受付枚","実取得数","実取得枚")})
    categories={name:Counter({k:0 for k in ("Source出生数","実取得数","実取得枚")}) for name in CLASSES}
    frames={name:set() for name in CLASSES}
    for r in rows:
        total["Source出生数"]+=1;total[{2:"selected_true",1:"selected_false",0:"selected_unknown"}[r["selected"]]]+=1
        total["input_missing"]+=r["input_missing"];total["受付数"]+=r["accepted"];total["受付枚"]+=r["accepted_quantity"];total["実取得数"]+=r["acquired"];total["実取得枚"]+=r["actual_quantity"]
        c=categories[r["class"]];c["Source出生数"]+=1;c["実取得数"]+=r["acquired"];c["実取得枚"]+=r["actual_quantity"]
        if r["frame_id"] is not None:frames[r["class"]].add((r["session"],r["frame_id"]))
    need(sum(c["Source出生数"] for c in categories.values())==total["Source出生数"],"4技法分類の全要求分母")
    return {**total,"要求時技法":{k:{**v,"distinct公表ID数":len(frames[k])} for k,v in categories.items()},"公表IDは独立市場機会数ではない":True}


def pair_records(left: list[dict], right: list[dict]) -> tuple:
    """
    機能: 113と同じ厳密入口四群を作り、共通入口の同保護/返済を別に確認する。
    引数: left/right(list[dict])。返り値: tupleは四群・小対応台帳・入口差・共通退出差。
    """
    groups,matched,differences=OLD.pair_records(left,right)
    a,b={r["base"]:r for r in left},{r["base"]:r for r in right}
    checks=Counter({"共通入口数":0,"初期P100同体":0,"全返済と保存保護同体":0,"返済差あり":0})
    fields=Counter()
    for row in matched:
        row["前要求時技法"]=deepcopy(a[row["base"]]["technical"]) if row["base"] in a else None
        row["後要求時技法"]=deepcopy(b[row["base"]]["technical"]) if row["base"] in b else None
        if row["群"]!="同実入口":continue
        l,r=a[row["base"]],b[row["base"]]
        need(l["technical"]==r["technical"],"共通Source要求時技法同体")
        changed=[k for k in l["exit"] if canon(l["exit"][k])!=canon(r["exit"][k])]
        same_initial="初期P100" not in changed
        checks["共通入口数"]+=1;checks["初期P100同体"]+=same_initial;checks["全返済と保存保護同体"]+=not changed;checks["返済差あり"]+=bool(changed);fields.update(changed)
        row["要求時技法"]=l["technical"];row["共通返済の差分属性"]=changed
        if not changed:need(l["net"]==r["net"],"同返済で実現額差")
    return groups,matched,differences,{**checks,"差分属性":dict(fields)}


def summarize(groups: dict, period: str, owner: str) -> dict:
    """
    機能: 実入口四群の実現差へ、成立玉の要求時分類と返済同体を追加する。
    引数: groups(dict)、period/owner(str)。返り値: dictは実現額だけの比較。
    """
    result=OLD.summarize(groups,period,owner)
    total={side:[r for group in groups.values() for r in group[side] if selected(r,period,owner)] for side in ("前","後")}
    technical={}
    for name in CLASSES:
        a=OLD.statistics([r for r in total["前"] if r["technical"]["class"]==name]);b=OLD.statistics([r for r in total["後"] if r["technical"]["class"]==name])
        technical[name]={"前":a,"後":b,"実現差円":b["実現円"]-a["実現円"]}
    need(sum(r["実現差円"] for r in technical.values())==result["全体"]["実現差円"],"要求時技法別の実現差加法")
    result["成立玉の要求時技法別"]=technical
    for side in ("前","後"):
        result["全体"][side]["要求時input_missing玉"]=sum(r["technical"]["input_missing"] for r in total[side])
    a={r["base"]:r for r in groups["同実入口"]["前"] if selected(r,period,owner)}
    b={r["base"]:r for r in groups["同実入口"]["後"] if selected(r,period,owner)}
    need(set(a)==set(b),"共通入口owner/期間一致")
    changed=Counter();same_initial=same_exit=0
    for key in a:
        fields=[f for f in a[key]["exit"] if canon(a[key]["exit"][f])!=canon(b[key]["exit"][f])]
        same_initial+="初期P100" not in fields;same_exit+=not fields;changed.update(fields)
    result["共通入口の同保護確認"]={"共通玉":len(a),"初期P100同体":same_initial,"全返済と保存保護同体":same_exit,"返済差あり":len(a)-same_exit,"差分属性":dict(changed)}
    return result
