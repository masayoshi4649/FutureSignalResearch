# 114の正式保存への接続

全70金融成功・独立840会計成功・独立入口840口座検査成功を、Rootの新しい固定要求から同bytes保存する。P113のP100保護を固定し、入口A0/T/TR各4費用の12条件を本名で保つ。A0各4条件を正式113のP100へ全金融比較し、Source111全文同体と別に記録する。全70中、元54は同条件成功Nativeの認証再用、追加16だけ再生である。

市場や金融を再実行しない。114 Nativeは復号せず圧縮bytesを認証・保存する。Raw・価格CSV・11月09日本文を読まない。研究目標達成・採用はfalse。正式実行はRootが全成功Refを結んだ要求を固定して所有する。

## 固定要求

JSONは `version:1, trial:114, fixed:true, stage:"full70", market_native_read_authorized:true`。`refs`の必須FileRefは次の通り。FileRefは絶対`path`と`sha256`の2項目。

- `condition, market, result, saved_check`：金融固定、全70成功、独立会計結果と保存検算。
- `core_stop, actor_stop, pure_stop`：金融Core114、Actor114、共通利益保護P113の停止。
- `entry_gate_stop, entry_stop, entry_check`：純Go入口114、独立Python入口114の停止、同金融条件/成功へ結ぶ全70のstandalone入口検算成功。
- `save_stop, P_stop`：独立金融保存とP監査の停止。
- `formal_stop, code_material_stop, code_material`：この保存器の市場前停止、同停止helperが出す分類器停止、金融コード分類素材。

`entry_check`は全70順序/840口座/全12票成功・原Source器具false・費用間とモード間のDecision同体・停止/条件/金融完了への結合を確認する。各場各口座のcountsを独立会計の入口票検査へ全値照合し、候補別70場の入口票合算も確認する。保存済み会計を再計算する第三の金融器ではない。

`code_material`は金融コード1204＋実使用exeの1205行を、GoRoot環境参照・既正式コード参照・新規同梱へ分ける。`コードを分類する.py`はRoot固定F2と停止Coreの全集合・現物SHAを認証し、市場本文を開かず素材を作る。旧111/112/113の索引を認証し、直接のarchive/index/entryまたはmetadataRefへflattenする。由来pathが中継索引に残る場合も、認証した旧索引群の証拠行と直接entryを別々に確認する。復元先は現在のpathを維持する。

追加コードは各停止の所有・再用コード、4宣言、共通ZIP器、明示`code_refs:[{ref:FileRef,role:文字列}]`から同pathで統合する。RootのCSV/同入口/Viewer/helper等を明示できる。GoRoot716とGoコンパイラ実行物1行は別計数のGo1.24.2環境参照・SHA索引のみ。既正式ZIPの全SHAと選択entryのSHA/size/CRCを正式保存時に認証し、旧ZIPを複写しない。新コードZIPは全entry集合・安全名・SHA・size・CRCを再読する。同bytesで正式保存するmetadataはZIPにも重ねず、同じ正式成果物へ結ぶ。

任意の`csv_refs`は`{"候補別集計.csv":FileRef,"全セッション.csv":FileRef}`。同時に`refs.csv_check`へRoot全セル再読成功を渡す。唯一正本はoutputsで、現在SHAを確認するだけとしCSV本文を生成・複写・第三算術再読しない。未接続は空として記録する。

`extra_refs:[{ref:FileRef,target:"診断/明示名.json",role:文字列}]`は小metadata・圧縮診断・文書を診断/検査/再現資料へ追加する。Native/CSV/原板や旧ZIPの重複保存は許さない。根拠や既存文書を上書きしない。

## 保存先と操作

正式先は`study/00114_順行と反転の取得確認を分ける`。成果物840 `.trades.jsonl`と一覧・結果・検算、金融Native70と台帳、新規コードZIP/所在索引、小検査を新規保存する。既存README/設定と結果/設計候補/根拠/市場前原文は保持する。全対象先の未作成をprepareで認証し、上書き・二重複写を拒否する。

```powershell
python -X utf8 work/114正式保存への接続_入口票の零項目/コードを分類する.py --fixed <F2絶対path> --sha256 <F2_SHA> --output <新規素材path>
python -X utf8 work/114正式保存への接続_入口票の零項目/検査して停止する.py --output <新規停止folder>
python -X utf8 work/114正式保存への接続_入口票の零項目/正式保存する.py --request <Root固定要求path> --request-sha <SHA256> --metadata-only
python -X utf8 work/114正式保存への接続_入口票の零項目/正式保存する.py --request <Root固定要求path> --request-sha <SHA256>
```

metadata-onlyは同じ全入力/新規先を認証し、正式先へ書かない。人工7主は手製70場・空約定840・仮Native・人工旧ZIP・仮CSV確認metadataだけを使い、全保存、再実行拒否、SHA差/旧4不足/Source不一致/入口不成功・停止差・票差/危険先/元54同条件不足/閉包不足を確認する。市場の全原行証明を代用しない。原文166の81比較は元54場3手法Event再実行対照の範囲で、当時保存全文の同体を主張しない。

## 停止後の限定派生

元保存器b8e7e3…は保持する。入口票の全70集計は独立会計のCounter加算が合計0キーを省略するため、比較1式だけをCounter等価へ変更した。各場countsは全値同体のまま、非0の欠落/過剰は拒否する。人工も合計0キー欠落を実schemaに合わせ、非0差の拒否を追加した。金融・CSV・コード分類の意味は不変。
