package entrycomparison114

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	bank "github.com/masayoshi4649/SessionTradeExecuter/chartprotection111"
	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	legacyActor "github.com/masayoshi4649/SessionTradeExecuter/continuousactor113"
	actor "github.com/masayoshi4649/SessionTradeExecuter/continuousactor114"
	legacyCore "github.com/masayoshi4649/SessionTradeExecuter/entrycomparison113"
	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate114"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	protect "github.com/masayoshi4649/SessionTradeExecuter/miniprotect"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
)

// valueCopy は手製Source器具だけの複写名を現接続へ結びます。
//
// 引数: value(T)は保存可能な値。返り値: Tは独立した写しです。
func valueCopy[T any](value T) T { return copyValue(value) }

// handReplay は原板を使わず、順行と逆配置反転の二出生を同じ源から全12へ渡します。
//
// 引数: t(*testing.T)、side(int)、late(float64)、early(bool)は人工器・鏡像・終了後追記・未知入口です。
// 返り値: ReplayResult/legacyCore.ReplayResultは114と旧113の完結したAPI人工です。
func handReplay(t *testing.T, side int, late float64, early bool) (ReplayResult, legacyCore.ReplayResult) {
	t.Helper()
	session := session94()
	scene := source.SourceCase{Session: session, Contract: "人工限月"}
	current, prior := New(), legacyCore.New()
	if err := current.Begin(scene); err != nil {
		t.Fatal(err)
	}
	if err := prior.Begin(scene); err != nil {
		t.Fatal(err)
	}
	original := map[string]*protect.ActualBook{}
	for _, config := range source.ActorConfigs() {
		b, e := protect.NewActualBook(session, config)
		if e != nil {
			t.Fatal(e)
		}
		original[b.Snapshot().Key] = b
	}
	controls := map[string]*legacyActor.ActualBook{}
	for _, config := range legacyActor.DeclaredContinuousConfigurations() {
		if config.Policy != "P100" {
			continue
		}
		b, e := legacyActor.NewContinuousBook(session, scene.Contract, config)
		if e != nil {
			t.Fatal(e)
		}
		controls[b.Snapshot().Key] = b
	}
	monitor, e := bank.New(chart.Scene{ID: session.ID, Contract: scene.Contract, Start: session.Start}, nil)
	if e != nil {
		t.Fatal(e)
	}
	history, e := gate.NewHistory(gate.Scope{Session: session.ID, Contract: scene.Contract, Start: session.Start, End: session.End})
	if e != nil {
		t.Fatal(e)
	}
	fixture := newFixtureSource94()
	reversalAt := -1
	for i := 0; i <= 330; i++ {
		move := 5 * float64(i)
		if i >= 90 && i <= 120 {
			move += float64(((i-90)*(i-90))/25) * 5
		}
		if i >= 125 && i <= 149 {
			moves := map[int]float64{125: 700, 126: 800, 127: 900}
			if v, ok := moves[i]; ok {
				move = v
			} else {
				move = 700
			}
		}
		if i >= 150 {
			move = 700 - 5*float64(i-150)
		}
		if i > 260 {
			move = 150 + 20*float64(i-260)
		}
		if i >= 300 {
			move = 850 + late
		}
		o := observation94(session, side, int64(i), float64(i*60), move, 20)
		if reversalAt >= 0 && i > reversalAt && i <= reversalAt+3 {
			o.Ask = o.Bid
			o.QuoteOK = false
		}
		line := int64(i + 1)
		stamp := gate.Stamp{Time: o.Time, Index: int(o.Index), Line: line}
		batch, e := monitor.Step(chart.Quote{Time: o.Time, Index: o.Index, Line: line, Last: o.Last, Bid: o.Bid, Ask: o.Ask, Valid: true})
		if e != nil {
			t.Fatal(e)
		}
		for _, event := range batch.Events {
			switch event.Kind {
			case "reset":
				r := batch.Resets[event.Index]
				if e = history.Reset(stamp, r.Reason); e != nil {
					t.Fatal(e)
				}
				for _, b := range controls {
					if e = b.ResetPublication(r.At, r.Reason); e != nil {
						t.Fatal(e)
					}
				}
			case "observation":
				p := batch.Observations[event.Index]
				if e = history.Step(p.Frame, stamp); e != nil {
					t.Fatal(e)
				}
				for _, b := range controls {
					if e = b.SetPublication(p.At, 1, p.Buy); e != nil {
						t.Fatal(e)
					}
					if e = b.SetPublication(p.At, -1, p.Sell); e != nil {
						t.Fatal(e)
					}
				}
			default:
				t.Fatal("未定義公開イベント")
			}
		}
		news := []native.Signal{}
		if early {
			if i == 1 {
				news = append(news, birth94("人工未知入口", side, 2))
			}
			if i == 20 {
				news = append(news, close94("人工未知源返済", "人工未知入口", side, 2))
			}
		} else {
			if i == 110 {
				news = append(news, birth94("人工順行入口", side, 2))
			}
			if i == 145 {
				news = append(news, close94("人工順行源返済", "人工順行入口", side, 2))
			}
			if i > 260 && i < 285 && reversalAt < 0 {
				d, e := history.Evaluate(gate.Request{Product: "NK225mini", Method: "NK225_D164_15", SignalID: fmt.Sprintf("人工探索%d", i), Side: side, At: stamp})
				if e != nil {
					t.Fatal(e)
				}
				if d.Reversal == gate.True {
					if d.Trend == gate.True {
						t.Fatal("順行と逆配置反転が同時真")
					}
					reversalAt = i
					news = append(news, birth94("人工反転入口", side, 2))
				}
			}
			if i == 295 {
				if reversalAt < 0 {
					t.Fatal("反転人工の成立なし")
				}
				news = append(news, close94("人工反転源返済", "人工反転入口", side, 2))
			}
		}
		delta := fixture.step(t, o, line, news, nil)
		before, _ := json.Marshal(delta)
		for _, b := range original {
			if e = b.OnNativeStep(o, line, []protect.NativeBatch{delta}); e != nil {
				t.Fatal(e)
			}
		}
		step := source.NativeStep{Observation: o, SourceLine: line, Mini: []source.NativeBatch{delta}}
		if e = current.Step(step); e != nil {
			t.Fatal(i, e)
		}
		if e = prior.Step(step); e != nil {
			t.Fatal(i, e)
		}
		for _, b := range controls {
			if e = b.OnNativeStep(o, line, []legacyActor.NativeBatch{{Method: delta.Method, Delta: delta.Delta}}); e != nil {
				t.Fatal(e)
			}
		}
		for _, b := range current.books {
			value := b.Snapshot()
			if value.Config.EntryMode != "A0" {
				continue
			}
			key := fmt.Sprintf("P100_C%.0f_D%d", value.Config.SlipPts, value.Config.DelaySeconds)
			checked, e := actor.CompareLegacy113(value, controls[key].Snapshot())
			if e != nil || !checked.AllFinancialEqual {
				t.Fatal("A0毎原行対照", i, key, e)
			}
		}
		after, _ := json.Marshal(delta)
		if !reflect.DeepEqual(before, after) {
			t.Fatal("Source入力の破壊")
		}
	}
	end := source.SourceEnd{Session: session, Complete: true}
	if e = current.End(end); e != nil {
		t.Fatal(e)
	}
	if e = prior.End(end); e != nil {
		t.Fatal(e)
	}
	origin := source.ReplayResult{Version: 1, Trial: 111, Session: session, Contract: scene.Contract, Complete: true, Books: map[string]source.ActualResult{}}
	for key, b := range original {
		v, e := b.Finish()
		if e != nil {
			t.Fatal(e)
		}
		origin.Books[key] = v
	}
	result, e := ConnectResult(origin, current)
	if e != nil {
		t.Fatal(e)
	}
	previous, e := legacyCore.ConnectResult(copyValue(origin), prior)
	if e != nil {
		t.Fatal(e)
	}
	if e = CompareReference113Values(&result, previous, source.FileRef{Path: "人工旧113", SHA256: "人工"}); e != nil {
		t.Fatal(e)
	}
	if e = CheckReplay(result, Fixed{ActualConfigurations: actor.DeclaredContinuousConfigurations()}); e != nil {
		t.Fatal(e)
	}
	return result, previous
}

// TestHandTrendReversalAndA0 は三モードの違いと旧P100四費用の毎行同体を確認します。
//
// 引数: t(*testing.T)は人工器。返り値: ありません。市場の優位性を測りません。
func TestHandTrendReversalAndA0(t *testing.T) {
	for _, side := range []int{1, -1} {
		result, _ := handReplay(t, side, 0, false)
		if result.A0Comparisons != 4 || !result.A0Equal || result.Reference113.Comparisons != 4 || len(result.Actual.Books) != 12 {
			t.Fatal("全12/四対照")
		}
		for _, cost := range []int{0, 5} {
			for _, delay := range []int{0, 1} {
				for mode, want := range map[string]int{"A0": 2, "T": 1, "TR": 2} {
					key := fmt.Sprintf("%s_C%d_D%d", mode, cost, delay)
					b := result.Actual.Books[key]
					if len(b.Positions) != want || !b.Complete || b.Totals.EntryQuantity != b.Totals.CloseQuantity {
						raw, _ := json.Marshal(b.EntryGate)
						t.Fatal(key, len(b.Positions), want, string(raw))
					}
				}
			}
		}
	}
}

// TestUnknownConsumesBirth は未知公表の入口が後から復活しないことを全費用で確認します。
//
// 引数: t(*testing.T)は人工器。返り値: ありません。
func TestUnknownConsumesBirth(t *testing.T) {
	result, _ := handReplay(t, 1, 0, true)
	for key, b := range result.Actual.Books {
		want := 0
		if strings.HasPrefix(key, "A0_") {
			want = 1
		}
		if len(b.Positions) != want {
			raw, _ := json.Marshal(b.EntryGate)
			t.Fatal(key, len(b.Positions), want, string(raw))
		}
	}
}

// TestLaterFramesDoNotRewriteEntry は全決済後の価格を変えて過去の入口とfillが変わらないことを確認します。
//
// 引数: t(*testing.T)は人工器。返り値: ありません。
func TestLaterFramesDoNotRewriteEntry(t *testing.T) {
	a, _ := handReplay(t, 1, 0, false)
	b, _ := handReplay(t, 1, 200, false)
	for key, x := range a.Actual.Books {
		if !reflect.DeepEqual(x.Orders, b.Actual.Books[key].Orders) || !reflect.DeepEqual(x.Fills, b.Actual.Books[key].Fills) || !reflect.DeepEqual(x.Positions, b.Actual.Books[key].Positions) {
			t.Fatal(key, "過去の注文/fill/玉が変化")
		}
	}
}

// TestReferenceAndEventTampering は版差以外の金融差と公表順/原行差を拒否します。
//
// 引数: t(*testing.T)は人工器。返り値: ありません。
func TestReferenceAndEventTampering(t *testing.T) {
	result, prior := handReplay(t, 1, 0, false)
	bad := copyValue(prior)
	p := bad.Actual.Books["P100_C0_D0"]
	p.Totals.NetYen++
	bad.Actual.Books[p.Key] = p
	if CompareReference113Values(&result, bad, source.FileRef{}) == nil {
		t.Fatal("金融改変を受理")
	}
	modified := copyValue(result)
	modified.Actual.EntryEvents[0].Stamp.Line = 0
	if CheckEntryEvents(modified.Actual) == nil {
		t.Fatal("原行不正を受理")
	}
	modified = copyValue(result)
	modified.Actual.EntryEvents = modified.Actual.EntryEvents[1:]
	if CheckEntryEvents(modified.Actual) == nil {
		t.Fatal("公開reset欠落を受理")
	}
}

// TestLifecycleOwnership は開始/終端と呼出元の共有参照を隔離します。
//
// 引数: t(*testing.T)は人工器。返り値: ありません。
func TestLifecycleOwnership(t *testing.T) {
	c := New()
	if _, e := c.Result(); e == nil {
		t.Fatal("未完了を成功化")
	}
	if e := c.Step(source.NativeStep{}); e == nil {
		t.Fatal("開始前")
	}
	result, prior := handReplay(t, 1, 0, false)
	old, _ := json.Marshal(result.Source)
	prior.Source.Books = map[string]source.ActualResult{}
	after, _ := json.Marshal(result.Source)
	if !reflect.DeepEqual(old, after) {
		t.Fatal("Source共有参照")
	}
}

// TestExportArtificial は独立判定へ買売24冊と旧113対を渡します。
//
// 引数: t(*testing.T)は人工器。返り値: ありません。環境変数指定時だけ新規出力します。
func TestExportArtificial(t *testing.T) {
	folder := os.Getenv("EXPORT114")
	if folder == "" {
		t.Skip("指定時だけ出力")
	}
	if e := os.Mkdir(folder, 0755); e != nil {
		t.Fatal(e)
	}
	cases := []map[string]any{}
	for _, side := range []int{1, -1} {
		current, prior := handReplay(t, side, 0, false)
		ref, e := SaveNew(filepath.Join(folder, fmt.Sprintf("人工114_%d.json", side)), current, false)
		if e != nil {
			t.Fatal(e)
		}
		old, e := SaveNew(filepath.Join(folder, fmt.Sprintf("人工113_%d.json", side)), prior, false)
		if e != nil {
			t.Fatal(e)
		}
		cases = append(cases, map[string]any{"side": side, "current": ref, "prior113": old})
	}
	if _, e := SaveNew(filepath.Join(folder, "人工.json"), map[string]any{"trial": 114, "artificial": true, "books": 24, "cases": cases}, false); e != nil {
		t.Fatal(e)
	}
}
