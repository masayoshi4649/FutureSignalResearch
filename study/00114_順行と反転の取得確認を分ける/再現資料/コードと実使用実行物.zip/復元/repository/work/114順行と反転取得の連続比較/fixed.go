package entrycomparison114

import (
	"compress/gzip"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"runtime"
	"sort"
	"strings"

	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	actor "github.com/masayoshi4649/SessionTradeExecuter/continuousactor114"
	legacyCore "github.com/masayoshi4649/SessionTradeExecuter/entrycomparison113"
	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate114"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor113"
)

const Policy = "original166_source111_p100_entry_confirmation114"
const ActualPolicy = "p100_entry_confirmation114"
const ParallelMethod = "isolated_session_process114_v1"

// References113 は固定済み113の金融条件・成功・正式Native索引の由来です。
type References113 struct {
	Condition     source.FileRef `json:"condition"`
	Market        source.FileRef `json:"market"`
	NativeCatalog source.FileRef `json:"native_catalog"`
}

// Fixed は111へ偽装せず114としてRootが事前固定する条件です。
type Fixed struct {
	Version                  int                       `json:"version"`
	Trial                    int                       `json:"trial"`
	Fixed                    bool                      `json:"fixed"`
	Policy                   string                    `json:"policy"`
	SourceTrial              int                       `json:"source_trial"`
	FARCommit                string                    `json:"FAR_commit"`
	StrategyCommit           string                    `json:"strategy_commit"`
	Manifest                 source.FileRef            `json:"manifest"`
	Executable               source.FileRef            `json:"executable"`
	CodeSHA256               map[string]string         `json:"code_sha256"`
	Golden                   map[string]source.FileRef `json:"original166_references"`
	RuntimeStop              source.FileRef            `json:"runtime_stop"`
	DependencyStops          map[string]source.FileRef `json:"dependency_stops"`
	ActualPolicy             string                    `json:"actual_policy"`
	ChartSeedMode            string                    `json:"chart_seed_mode"`
	EntryGridSeconds         *int                      `json:"entry_grid_seconds"`
	ExtraOpeningQuietSeconds int                       `json:"extra_opening_quiet_seconds"`
	ActualConfigurations     []actor.ActorConfig       `json:"actual_configurations"`
	ProtectionConfigurations []guard.Configuration     `json:"protection_configurations"`
	ProtectionDefinition     guard.Definition          `json:"protection_definition"`
	EntryDefinition          gate.Definition           `json:"entry_gate_definition"`
	EntryDeclaration         source.FileRef            `json:"entry_gate_declaration"`
	ActualDeclaration        source.FileRef            `json:"actual_declaration"`
	PureDeclaration          source.FileRef            `json:"pure_declaration"`
	ChartDeclaration         source.FileRef            `json:"chart_declaration"`
	Reference113             References113             `json:"reference113"`
	ParallelMethod           string                    `json:"parallel_method"`
	ParallelMaxWorkers       int                       `json:"parallel_max_workers"`
}

// SceneResult は当場の12金融・原文Event・旧113の4対照を別に記録します。
type SceneResult struct {
	Session                 string              `json:"session"`
	Native                  source.FileRef      `json:"native"`
	Golden                  *source.GoldenProof `json:"original166_reference,omitempty"`
	Books                   int                 `json:"books"`
	A0Comparisons           int                 `json:"A0_comparisons"`
	A0Equal                 bool                `json:"A0_equal"`
	Complete                bool                `json:"complete"`
	OpenQuantity            int                 `json:"open_quantity"`
	PendingQuantity         int                 `json:"pending_quantity"`
	Reference113            source.FileRef      `json:"reference113"`
	Reference113Comparisons int                 `json:"reference113_comparisons"`
	Reference113Equal       bool                `json:"reference113_equal"`
	Source111Equal          bool                `json:"source111_equal"`
}

// Completion は114の全段階の成功と同条件54参照再用を結びます。
type Completion struct {
	Version                    int               `json:"version"`
	Trial                      int               `json:"trial"`
	Stage                      string            `json:"stage"`
	Success                    bool              `json:"success"`
	ConditionSHA256            string            `json:"condition_sha256"`
	Sessions                   int               `json:"sessions"`
	ReusedSessions             int               `json:"reused_sessions"`
	ReplayedSessions           int               `json:"replayed_sessions"`
	Books                      int               `json:"books"`
	OriginalMethods            int               `json:"original_methods"`
	AllReferenceEventsEqual    bool              `json:"all_original166_reference_events_equal"`
	HistoricalSavedEventsEqual bool              `json:"historical_saved_events_equal"`
	AllSignalFullJSONEqual     bool              `json:"all_original_signal_full_json_equal"`
	Reference113Comparisons    int               `json:"reference113_comparisons"`
	AllReference113Equal       bool              `json:"all_reference113_equal"`
	AllSource111Equal          bool              `json:"all_source111_equal"`
	Results                    []SceneResult     `json:"results"`
	Before                     map[string]string `json:"before"`
	After                      map[string]string `json:"after"`
	Unchanged                  bool              `json:"unchanged"`
	Prior54                    *source.FileRef   `json:"prior54,omitempty"`
}

// RunPlan は114外ゲートが認証した入力計画です。Sourceの111ゲートは呼びません。
type RunPlan struct {
	Source        source.RunPlan
	Fixed         Fixed
	Stage         string
	Prior54       *Completion
	LegacyNatives map[string]source.FileRef
}

// RuntimeStop は金融部品と接続CLIの市場前停止をRoot条件へ渡します。
type RuntimeStop struct {
	Success      bool                      `json:"成功"`
	Stopped      bool                      `json:"停止"`
	Trial        int                       `json:"trial"`
	Owned        map[string]string         `json:"所有コードSHA256"`
	AllCode      map[string]string         `json:"全固定コードSHA256"`
	Executable   source.FileRef            `json:"実行物"`
	Dependencies map[string]source.FileRef `json:"依存停止"`
}

// Directory は114接続のビルド元を返します。
//
// 引数: なし。
// 返り値: string/errorは絶対module位置又は不明です。
func Directory() (string, error) {
	_, file, _, ok := runtime.Caller(0)
	if !ok {
		return "", fmt.Errorf("114ビルド元不明")
	}
	return filepath.Dir(file), nil
}

// readRef は絶対参照をSHA認証して小JSONだけを復元します。
//
// 引数: ref(source.FileRef)、value(any)は期待参照と復元先です。
// 返り値: errorは指紋又はJSONの差です。
func readRef(ref source.FileRef, value any) error {
	if err := source.VerifyRef(ref); err != nil {
		return err
	}
	raw, err := os.ReadFile(ref.Path)
	if err != nil {
		return err
	}
	return json.Unmarshal(raw, value)
}

// BasisStops は変更しないSource/Chart/旧113Core/P113保護の絶対停止参照を返します。
//
// 引数: なし。
// 返り値: map[string]source.FileRef/errorは4基礎停止又は位置差です。
func BasisStops() (map[string]source.FileRef, error) {
	base, err := Directory()
	if err != nil {
		return nil, err
	}
	out := map[string]source.FileRef{}
	for key, pair := range map[string][2]string{
		"source":  {"111元時計の連続再現", "08b1331b372d5cd7e50d46d90c247a8fa9c6a9bf657105ff181928041f156946"},
		"chart":   {"111連続保護のチャート公開", "38c01e07d276310c6c1d803dca11e27979fc9286cf64d9a495e60485ea7264bd"},
		"core113": {"113利益起動水準と構造失効の連続比較", "dfd84dc9153abc5f80659a4604f677227ab58e27f64ef3df5ee3407c95e609f0"},
		"pure":    {"113起動前の支持否定と利益保護の純演算", "81f54d965ef8d81c65a7b58f4d376374b79c765e1ad4ada5cc6270159e4ed312"},
	} {
		out[key] = source.FileRef{Path: filepath.Clean(filepath.Join(base, "..", pair[0], "停止.json")), SHA256: pair[1]}
	}
	return out, nil
}

// ProtectionConfigurations は共通P100の四費用を元P113宣言から抽出します。
//
// 引数: なし。返り値: []guard.Configurationは変更しない四設定です。
func ProtectionConfigurations() []guard.Configuration {
	out := []guard.Configuration{}
	for _, c := range guard.DeclaredConfigurations() {
		if c.Policy == "P100" {
			out = append(out, c)
		}
	}
	return out
}

// ProtectionDefinition は共通P100の保護定義を元P113宣言から返します。
//
// 引数: なし。返り値: guard.DefinitionはH100/通常200・2ATR/動的Pの既定値です。
func ProtectionDefinition() guard.Definition {
	for _, d := range guard.DeclaredDefinitions() {
		if d.Policy == "P100" {
			return d
		}
	}
	panic("P113にP100定義がない")
}

// RequiredCodePaths は114実cmdの選択コード閉包を入力本文なしで取得します。
//
// 引数: なし。
// 返り値: []string/errorはGo/asm/embed/module/GoRootの絶対位置です。
func RequiredCodePaths() ([]string, error) {
	base, err := Directory()
	if err != nil {
		return nil, err
	}
	cmd := exec.Command("go", "list", "-deps", "-json", "./cmd/run")
	cmd.Dir = base
	cmd.Env = append(os.Environ(), "GOWORK=off", "CGO_ENABLED=0")
	raw, err := cmd.Output()
	if err != nil {
		return nil, err
	}
	decoder := json.NewDecoder(strings.NewReader(string(raw)))
	paths := map[string]bool{}
	for {
		var p struct {
			Dir                                                      string
			GoFiles, CgoFiles, SFiles, HFiles, SysoFiles, EmbedFiles []string
			Module                                                   *struct{ GoMod string }
		}
		err = decoder.Decode(&p)
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
		if p.Dir == "" {
			continue
		}
		for _, names := range [][]string{p.GoFiles, p.CgoFiles, p.SFiles, p.HFiles, p.SysoFiles, p.EmbedFiles} {
			for _, name := range names {
				paths[filepath.Clean(filepath.Join(p.Dir, name))] = true
			}
		}
		if p.Module != nil && p.Module.GoMod != "" {
			paths[filepath.Clean(p.Module.GoMod)] = true
			sum := filepath.Join(filepath.Dir(p.Module.GoMod), "go.sum")
			if _, e := os.Stat(sum); e == nil {
				paths[sum] = true
			}
		}
	}
	out := []string{}
	for path := range paths {
		out = append(out, path)
	}
	sort.Strings(out)
	return out, nil
}

// verifyRuntime は114の実宣言・実閉包・親子exeを本文前に認証します。
//
// 引数: f(Fixed)、before(map[string]string)はRoot固定と前指紋です。
// 返り値: errorは停止/閉包/実宣言/実行物の不一致です。
func verifyRuntime(f Fixed, before map[string]string) error {
	var stop RuntimeStop
	if err := readRef(f.RuntimeStop, &stop); err != nil {
		return err
	}
	if !stop.Success || !stop.Stopped || stop.Trial != 114 || stop.Executable != f.Executable || !reflect.DeepEqual(stop.Dependencies, f.DependencyStops) {
		return fmt.Errorf("114市場前停止/依存/実行物差")
	}
	basis, err := BasisStops()
	if err != nil {
		return err
	}
	if len(f.DependencyStops) != 6 {
		return fmt.Errorf("114のSource/Chart/Core113/Actor/P113/EntryGateの6停止が必要")
	}
	for key, ref := range basis {
		if f.DependencyStops[key] != ref {
			return fmt.Errorf("114基礎停止差:%s", key)
		}
	}
	for _, key := range []string{"actor", "entry_gate"} {
		if _, ok := f.DependencyStops[key]; !ok {
			return fmt.Errorf("114の停止不足:%s", key)
		}
	}
	for key, ref := range f.DependencyStops {
		var status map[string]json.RawMessage
		if err = readRef(ref, &status); err != nil {
			return err
		}
		var success, stopped bool
		if json.Unmarshal(status["成功"], &success) != nil || json.Unmarshal(status["停止"], &stopped) != nil || !success || !stopped {
			return fmt.Errorf("部品停止不足:%s", key)
		}
		before[ref.Path] = ref.SHA256
	}
	expected := map[string]string{}
	for _, codes := range []map[string]string{stop.AllCode, stop.Owned} {
		for path, sha := range codes {
			if old, ok := expected[path]; ok && old != sha {
				return fmt.Errorf("114停止code衝突")
			}
			expected[path] = sha
		}
	}
	expected[f.RuntimeStop.Path] = f.RuntimeStop.SHA256
	if !reflect.DeepEqual(expected, f.CodeSHA256) {
		return fmt.Errorf("114停止の実閉包と固定map差")
	}
	for path, sha := range expected {
		if err = source.VerifyRef(source.FileRef{Path: path, SHA256: sha}); err != nil {
			return err
		}
		before[path] = sha
	}
	paths, err := RequiredCodePaths()
	if err != nil {
		return err
	}
	for _, path := range paths {
		if _, ok := expected[path]; !ok {
			return fmt.Errorf("114実Go閉包漏れ:%s", path)
		}
	}
	exe, err := os.Executable()
	if err != nil {
		return err
	}
	actual, err := source.Digest(exe)
	if err != nil || actual != f.Executable.SHA256 {
		return fmt.Errorf("114実行中exeのSHA差")
	}
	if err = source.VerifyRef(f.Executable); err != nil {
		return err
	}
	before[f.Executable.Path] = f.Executable.SHA256
	for _, ref := range []source.FileRef{f.ActualDeclaration, f.PureDeclaration, f.EntryDeclaration, f.ChartDeclaration} {
		if err = source.VerifyRef(ref); err != nil {
			return err
		}
		if expected[ref.Path] != ref.SHA256 {
			return fmt.Errorf("114実宣言の固定漏れ")
		}
	}
	var actualConfigs []actor.ActorConfig
	if err = readRef(f.ActualDeclaration, &actualConfigs); err != nil || !reflect.DeepEqual(actualConfigs, f.ActualConfigurations) {
		return fmt.Errorf("Actor114の実12宣言差:%v", err)
	}
	var pure struct {
		Configurations []guard.Configuration `json:"configurations"`
		Definitions    []guard.Definition    `json:"definitions"`
		Version        int                   `json:"version"`
	}
	if err = readRef(f.PureDeclaration, &pure); err != nil || pure.Version != 113 || !reflect.DeepEqual(pure.Configurations, guard.DeclaredConfigurations()) || !reflect.DeepEqual(pure.Definitions, guard.DeclaredDefinitions()) {
		return fmt.Errorf("共通P113の元実宣言差:%v", err)
	}
	var declaration gate.Definition
	if err = readRef(f.EntryDeclaration, &declaration); err != nil || !reflect.DeepEqual(declaration, f.EntryDefinition) {
		return fmt.Errorf("entrygate114実宣言差:%v", err)
	}
	return nil
}

// reference113 は旧正式索引のmetadataだけを結び、旧Native本文は読みません。
//
// 引数: f(Fixed)、manifest(source.InputManifest)、before(map[string]string)は新固定・入力・前指紋です。
// 返り値: map[string]source.FileRef/errorは旧70Nativeの期待参照又は由来差です。
func reference113(f Fixed, manifest source.InputManifest, before map[string]string) (map[string]source.FileRef, error) {
	if f.Reference113.Condition.SHA256 != "065cb5ebc894627cb70cf6f3d8f0add7698532af269cb92c2dd3decf4051a138" ||
		f.Reference113.Market.SHA256 != "3d8160b4374091d0d31b14b68d177aa116081e44acc5f3fc055b66f8a8fb6d5f" {
		return nil, fmt.Errorf("113の指定済み正式条件/全70成功の指紋差")
	}
	var old source.Fixed
	var market legacyCore.Completion
	if err := readRef(f.Reference113.Condition, &old); err != nil {
		return nil, err
	}
	if err := readRef(f.Reference113.Market, &market); err != nil {
		return nil, err
	}
	if old.Version != 1 || old.Trial != 113 || !old.Fixed || old.Policy != legacyCore.Policy ||
		old.StrategyCommit != f.StrategyCommit || old.FARCommit != f.FARCommit || old.Manifest.SHA256 != f.Manifest.SHA256 ||
		!market.Success || market.Trial != 113 || market.Stage != "full70" || market.ConditionSHA256 != f.Reference113.Condition.SHA256 ||
		market.Sessions != 70 || market.Books != 1680 || !market.Unchanged || !reflect.DeepEqual(market.Before, market.After) || len(market.Results) != 70 ||
		!market.AllReferenceEventsEqual || market.HistoricalSavedEventsEqual || market.AllSignalFullJSONEqual {
		return nil, fmt.Errorf("旧113の同Source/入力/全70成功参照が必要")
	}
	for _, ref := range []source.FileRef{f.Reference113.Condition, f.Reference113.Market, f.Reference113.NativeCatalog} {
		before[ref.Path] = ref.SHA256
	}
	var catalog struct {
		Trial    int  `json:"試行"`
		Success  bool `json:"成功"`
		Sessions int  `json:"場数"`
		Books    int  `json:"会計数"`
		Native   []struct {
			Session  string         `json:"session"`
			Relative string         `json:"relative"`
			SHA256   string         `json:"sha256"`
			Origin   source.FileRef `json:"origin"`
		} `json:"Native"`
	}
	if err := readRef(f.Reference113.NativeCatalog, &catalog); err != nil {
		return nil, err
	}
	if catalog.Trial != 113 || !catalog.Success || catalog.Sessions != 70 || catalog.Books != 1680 || len(catalog.Native) != 70 {
		return nil, fmt.Errorf("113正式Native索引70が必要")
	}
	trialRoot := filepath.Dir(filepath.Dir(f.Reference113.NativeCatalog.Path))
	natives := map[string]source.FileRef{}
	for i, row := range catalog.Native {
		sid := manifest.Sessions[i].ID
		expected := filepath.ToSlash(filepath.Join("成果物_金融", "Native", sid+".Native.json.gz"))
		if row.Session != sid || row.Relative != expected || market.Results[i].Session != sid || row.Origin != market.Results[i].Native || row.SHA256 != row.Origin.SHA256 {
			return nil, fmt.Errorf("113正式Nativeの同bytes/場順参照差")
		}
		natives[sid] = source.FileRef{Path: filepath.Join(trialRoot, filepath.FromSlash(row.Relative)), SHA256: row.SHA256}
	}
	if len(f.Golden) != 54 || len(old.Golden) != 54 {
		return nil, fmt.Errorf("同Sourceの原文oracle54参照が必要")
	}
	for _, input := range manifest.Sessions[:54] {
		ref, ok := f.Golden[input.ID]
		if !ok || ref.SHA256 != old.Golden[input.ID].SHA256 {
			return nil, fmt.Errorf("元54oracleのsamebytes参照差")
		}
		session, err := source.SessionFor(input.ID)
		if err != nil {
			return nil, err
		}
		if err = source.ValidateGoldenRef(ref, session); err != nil {
			return nil, err
		}
		before[ref.Path] = ref.SHA256
	}
	return natives, nil
}

// PrepareFixed はtrial114の独立外ゲートで70台帳・43戦略・旧4対照を認証します。
//
// 引数: condition(source.FileRef)、stage(string)、prior(*source.FileRef|nil)は114固定・段階・同114元54成功です。
// 返り値: RunPlan/errorは本文未読計画。111へのtrial偽装を行いません。
func PrepareFixed(condition source.FileRef, stage string, prior *source.FileRef) (RunPlan, error) {
	p := RunPlan{Stage: stage, Source: source.RunPlan{Condition: condition, Stage: stage, Before: map[string]string{}}}
	if err := readRef(condition, &p.Fixed); err != nil {
		return p, err
	}
	f := p.Fixed
	if f.Version != 1 || f.Trial != 114 || !f.Fixed || f.Policy != Policy || f.SourceTrial != 111 ||
		f.FARCommit != "cf0717daa1eed78759f78a428bce50129e7f705b" || f.StrategyCommit != "67ba01588a60961ce2fb505ee5654999473dedab" ||
		f.ActualPolicy != ActualPolicy || f.ParallelMethod != ParallelMethod || f.ParallelMaxWorkers != 16 ||
		f.ChartSeedMode != "cold_each_session" || f.EntryGridSeconds != nil || f.ExtraOpeningQuietSeconds != 0 ||
		!reflect.DeepEqual(f.ActualConfigurations, actor.DeclaredContinuousConfigurations()) ||
		!reflect.DeepEqual(f.ProtectionConfigurations, ProtectionConfigurations()) || !reflect.DeepEqual(f.ProtectionDefinition, ProtectionDefinition()) || !reflect.DeepEqual(f.EntryDefinition, gate.DeclaredDefinition()) {
		return p, fmt.Errorf("114のRoot固定/実宣言/定義/原時計が必要")
	}
	var fields map[string]json.RawMessage
	if err := readRef(condition, &fields); err != nil {
		return p, err
	}
	if string(fields["entry_grid_seconds"]) != "null" || fields["extra_opening_quiet_seconds"] == nil {
		return p, fmt.Errorf("新規時計なし/静観0の明示が必要")
	}
	before := p.Source.Before
	before[condition.Path] = condition.SHA256
	if err := verifyRuntime(f, before); err != nil {
		return p, err
	}
	if err := readRef(f.Manifest, &p.Source.Manifest); err != nil {
		return p, err
	}
	before[f.Manifest.Path] = f.Manifest.SHA256
	m := p.Source.Manifest
	if len(m.Sessions) != 70 || len(m.StrategySHA256) != 43 || !filepath.IsAbs(m.Root) || !filepath.IsAbs(m.StrategyRoot) {
		return p, fmt.Errorf("既使用70と純43の絶対台帳が必要")
	}
	if err := source.ValidateManifest(m); err != nil {
		return p, err
	}
	for name, sha := range m.StrategySHA256 {
		before[filepath.Join(m.StrategyRoot, filepath.FromSlash(name))] = sha
	}
	for _, input := range m.Sessions {
		if input.ID < "2026-09-21_Day" || input.ID > "2026-11-06_Night" {
			return p, fmt.Errorf("未使用期間を拒否")
		}
		for _, file := range input.Files {
			clean := filepath.Clean(filepath.FromSlash(file.Path))
			if filepath.IsAbs(clean) || clean == ".." || strings.HasPrefix(clean, ".."+string(filepath.Separator)) {
				return p, fmt.Errorf("入力根外の相対参照を拒否")
			}
		}
	}
	if m.Sessions[0].ID != "2026-09-21_Day" || m.Sessions[53].ID != "2026-10-27_Night" || m.Sessions[69].ID != "2026-11-06_Night" {
		return p, fmt.Errorf("元54/追加16の境界差")
	}
	natives, err := reference113(f, m, before)
	if err != nil {
		return p, err
	}
	p.LegacyNatives = natives
	n := map[string]int{"metadata-only": 70, "first2": 2, "base54": 54, "full70": 70}[stage]
	if n == 0 {
		return p, fmt.Errorf("stageはmetadata-only/first2/base54/full70")
	}
	p.Source.Cases = append([]source.InputCase(nil), m.Sessions[:n]...)
	// ----------------------------------------
	// source.RunPlanは公開入力型の容器だけに使用し、111のPrepareMetadataを呼びません。
	p.Source.Fixed = source.Fixed{Version: f.Version, Trial: f.Trial, Fixed: f.Fixed, Policy: f.Policy, FARCommit: f.FARCommit, StrategyCommit: f.StrategyCommit, Manifest: f.Manifest, Executable: f.Executable, CodeSHA256: f.CodeSHA256, Golden: f.Golden}
	if stage == "full70" {
		if prior == nil {
			return p, fmt.Errorf("同114固定のbase54成功を先に要求")
		}
		var old Completion
		if err = readRef(*prior, &old); err != nil {
			return p, err
		}
		if err = validatePrior54(old, condition, p); err != nil {
			return p, err
		}
		p.Prior54 = &old
		p.Source.Prior54Ref = prior
		before[prior.Path] = prior.SHA256
		for _, row := range old.Results {
			before[row.Native.Path] = row.Native.SHA256
		}
	} else if prior != nil {
		return p, fmt.Errorf("prior54はfull70だけ")
	}
	return p, nil
}

// validatePrior54 は114の同条件・全12・旧4対照・81Event対照・全残0を確認します。
//
// 引数: old(Completion)、condition(source.FileRef)、p(RunPlan)は先行成功と今回計画です。
// 返り値: errorは54成功不足又はNativeSHAの差です。
func validatePrior54(old Completion, condition source.FileRef, p RunPlan) error {
	if old.Version != 1 || old.Trial != 114 || !old.Success || old.Stage != "base54" || old.ConditionSHA256 != condition.SHA256 ||
		old.Sessions != 54 || old.Books != 648 || old.OriginalMethods != 81 || old.ReusedSessions != 0 || old.ReplayedSessions != 54 ||
		old.Reference113Comparisons != 216 || !old.AllReference113Equal || !old.AllSource111Equal || !old.AllReferenceEventsEqual ||
		old.HistoricalSavedEventsEqual || old.AllSignalFullJSONEqual || !old.Unchanged || len(old.Results) != 54 ||
		!reflect.DeepEqual(old.Before, old.After) || !reflect.DeepEqual(old.Before, p.Source.Before) {
		return fmt.Errorf("同条件の114全base54成功ではない")
	}
	for i, row := range old.Results {
		methods := 1
		if i%2 == 1 {
			methods = 2
		}
		if row.Session != p.Source.Manifest.Sessions[i].ID || row.Books != 12 || row.A0Comparisons != 4 || !row.A0Equal || !row.Complete || row.OpenQuantity != 0 || row.PendingQuantity != 0 ||
			row.Reference113Comparisons != 4 || !row.Reference113Equal || !row.Source111Equal || row.Reference113 != p.LegacyNatives[row.Session] ||
			row.Golden == nil || !row.Golden.EventsEqual || !row.Golden.MiniEventsEqual || row.Golden.Methods != methods ||
			row.Golden.Reference != p.Fixed.Golden[row.Session] || row.Golden.ReferenceKind != "rerun_original166_pinned_code" || row.Golden.HistoricalSavedEventsEqual || row.Golden.AllSignalEqual {
			return fmt.Errorf("114元54の場別成功/対照不足")
		}
		if err := source.VerifyRef(row.Native); err != nil {
			return err
		}
	}
	return nil
}

// CheckEntryEvents は保存した入口公表列を同じ純Historyへ戻し、時計と原配送順を検証します。
//
// 引数: value(Result)は114当場の保存値です。
// 返り値: errorはFrame/Stamp/reset/observationの因果又は欠落です。新規判断は再評価しません。
func CheckEntryEvents(value Result) error {
	history, err := gate.NewHistory(gate.Scope{Session: value.Scope.Session.ID, Contract: value.Scope.Contract, Start: value.Scope.Session.Start, End: value.Scope.Session.End})
	if err != nil {
		return err
	}
	publications, resets := 0, 0
	for _, event := range value.EntryEvents {
		switch event.Kind {
		case "reset":
			if event.Frame != nil || resets >= len(value.Resets) || event.Stamp.Time != value.Resets[resets].At || event.Reason != value.Resets[resets].Reason {
				return fmt.Errorf("114入口resetの出典/順序差")
			}
			if err = history.Reset(event.Stamp, event.Reason); err != nil {
				return err
			}
			resets++
		case "observation":
			if event.Frame == nil || event.Reason != "" || publications >= len(value.Publications) || event.Stamp.Time != value.Publications[publications].At || !reflect.DeepEqual(*event.Frame, value.Publications[publications].Frame) {
				return fmt.Errorf("114入口公表の出典/順序差")
			}
			if err = history.Step(*event.Frame, event.Stamp); err != nil {
				return err
			}
			publications++
		default:
			return fmt.Errorf("114未定義の入口公表種別")
		}
	}
	if publications != len(value.Publications) || resets != len(value.Resets) {
		return fmt.Errorf("114入口公表列の欠落")
	}
	return nil
}

// CheckReplay は114当場の12条件が原時計で完結したことを確認します。
//
// 引数: value(ReplayResult)、fixed(Fixed)は当場値とRoot固定です。
// 返り値: errorは宣言・数量・時計・源S0対照の差です。金融額で候補を選びません。
func CheckReplay(value ReplayResult, fixed Fixed) error {
	a := value.Actual
	if value.Version != 1 || value.Trial != 114 || value.Source.Trial != 111 || !value.Source.Complete || !a.Complete || a.Trial != 114 ||
		!value.A0Equal || value.A0Comparisons != 4 || value.OriginalHistoricalEventsEqual || len(a.Books) != 12 ||
		!reflect.DeepEqual(a.Configurations, fixed.ActualConfigurations) || a.EntryGridSeconds != nil || a.ExtraOpeningQuietSeconds != 0 ||
		a.ExplicitTimers != 0 || a.ChartSeedMode != "cold_each_session" || a.FinalChart.CarriedNumericSeed ||
		a.Scope.Session.ID != value.Source.Session.ID || a.Scope.Contract != value.Source.Contract {
		return fmt.Errorf("114の全12/原時計/源対照差")
	}
	if err := CheckEntryEvents(a); err != nil {
		return err
	}
	for _, config := range fixed.ActualConfigurations {
		key := fmt.Sprintf("%s_C%.0f_D%d", config.EntryMode, config.SlipPts, config.DelaySeconds)
		b, ok := a.Books[key]
		if !ok || b.Key != key || b.Config != config || !b.Complete || !b.Finished || b.Failure != "" ||
			b.Totals.OpenBuy != 0 || b.Totals.OpenSell != 0 || b.Totals.PendingBuy != 0 || b.Totals.PendingSell != 0 ||
			b.Totals.OpenEntryCostsYen != 0 || b.Totals.EntryQuantity != b.Totals.CloseQuantity || b.Totals.NetYen != b.Totals.ClosedNetYen {
			return fmt.Errorf("114口座の完結差:%s", key)
		}
		for _, position := range b.Positions {
			if position.Quantity != 0 || position.Reserved != 0 {
				return fmt.Errorf("114実玉の終了残")
			}
		}
	}
	return nil
}

// SaveNew は111と同じJSON整形/LF/gzipで114結果を新規保存します。
//
// 引数: path(string)、value(any)、compressed(bool)は新規先と保存値です。
// 返り値: source.FileRef/errorは保存指紋又は既存/書込異常です。
func SaveNew(path string, value any, compressed bool) (source.FileRef, error) {
	raw, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return source.FileRef{}, err
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if err != nil {
		return source.FileRef{}, err
	}
	if compressed {
		z := gzip.NewWriter(f)
		_, err = z.Write(append(raw, '\n'))
		if e := z.Close(); err == nil {
			err = e
		}
	} else {
		_, err = f.Write(append(raw, '\n'))
	}
	if e := f.Close(); err == nil {
		err = e
	}
	if err != nil {
		return source.FileRef{}, err
	}
	sha, err := source.Digest(path)
	return source.FileRef{Path: path, SHA256: sha}, err
}
