# 114：P100保護を共通にした順行/反転入口の連続比較

Source111・Chart111とP113のP100利益保護を変更せず、入口をA0/T/TR×C0/C5×D0/D1の12冊へ分ける。元FAR166の連続原行と取引時間を維持し、5分/15分の新規時計や追加開始静観を加えない。市場はRootが114の金融条件を固定した後だけ実行する。

## 新規要求時の確定

各NativeStepで、既存bank batch.Eventsのreset/observationを実順に全Actorへ渡す。入口Historyへ渡すFrameは元公表の全文で、実配送のStamp{time,index,source_line}を別に保存する。CurrentPriceTimeだけで同秒物理行の順序を潰さない。元FrameのAt/AvailableAt/Start等を現在原行へ書き換えない。Frame.Startは場開始であり、足の連続性はEnd差180秒等で判定する。

Source新規要求の当行でActorがRequestのProduct/Method/SignalID/Side/Stampを一度だけEvaluateし、票とcurrent/previousの全値・Stampをfreezeする。拒否出生は消費済みで、後のfillや新公表で復活させない。実fill時にゲートを再評価しない。A0は入口確認を加えない基準、Tは順行だけ、TRは順行OR反転の既知真だけを受ける。原Sourceへ実受付/拒否/返済を返さない。

売買方向d、G=d(EMA8−EMA21)、a8/a21=d×現前EMA差、x8=d(Close−EMA8)、H=d×Histとして、実 `entrygate114.DeclaredDefinition()` を固定する。

- T：G>0 AND a8>0 AND a21>0 AND x8>0 AND H>0。
- R：G<0 AND a8>0 AND 前x8<=0 AND 現x8>0 AND d×現前Hist差>0。
- 0の境界と未知は純定義に従う。Rは遅いMAの反転を要求せず、TのHist水準とRのHist増分を混同しない。

## 保存・対照

Actualはtrial114/12冊。Source.trial111は固定部品の由来として維持する。Actual.publicationsはbank.ObservationのFrame/FrameSHA/ResultSHA全文、entry_gate_eventsは実順の{kind,stamp,frame?,reason?}を保持する。保護のprotection113とdefinition113/P100は同体の本名で保存する。

同費用A0四冊を正式113のP100四冊へ `CompareLegacy113` で全金融/全State比較し、Sourceの全JSONも照合する。許可した新入口監査・key/config/説明scope差だけをActor公開比較が検査して分離する。旧112Native24冊の追加参照は行わない。元54は同Source/同43/同入力の原文oracle参照を再用し、81手法場を比較する。当時保存Eventや全Signal全文・市場全tick Stateの同体を主張しない。

## Root固定schema

```text
version1/trial114/fixedtrue,
policy=original166_source111_p100_entry_confirmation114,
source_trial111/FAR_commit/strategy_commit/manifest,
runtime_stop/executable/code_sha256,
dependency_stops{source,chart,core113,actor,pure,entry_gate},
actual_policy=p100_entry_confirmation114,
actual_configurations[12],protection_configurations[4],protection_definition,
entry_gate_definition,actual_declaration,pure_declaration,entry_gate_declaration,chart_declaration,
chart_seed_mode=cold_each_session,entry_grid_seconds=null,extra_opening_quiet_seconds=0,
original166_references[54],reference113{condition,market,native_catalog},
parallel_method=isolated_session_process114_v1,parallel_max_workers=16
```

pureはP113共通保護の停止、entry_gateは入口純114の停止。metadata-onlyは新旧Native本文・実Native SHA・Raw・価格CSVを読まず、固定閉包/43戦略/70場台帳/原文oracle54のmetadataと旧113の小さい索引を認証する。旧Source111の試行ゲートへ114を偽装しない。

```powershell
& '検査/114連続比較.exe' --fixed '<Root新固定abs>' --fixed-sha '<SHA>' --stage metadata-only
& '検査/114連続比較.exe' --fixed '<同条件>' --fixed-sha '<同SHA>' --stage first2 --out '<新規abs>' --workers 2
& '検査/114連続比較.exe' --fixed '<同条件>' --fixed-sha '<同SHA>' --stage base54 --out '<新規abs>' --workers 16
& '検査/114連続比較.exe' --fixed '<同条件>' --fixed-sha '<同SHA>' --stage full70 --out '<新規abs>' --workers 16 --prior54 '<同114条件のbase54完了abs>' --prior54-sha '<SHA>'
```

全70は同条件で成功した先頭54Nativeを指紋/全12/全flat/旧4/元81の証拠ごと参照再用し、追加16だけを再生する。別process最大16、Windows非表示、子GOMAXPROCS1、原行内直列、場ごとcold。完了順ではなく入力台帳順に集約する。失敗・欠落・重複を全体成功へ補わない。

Completionはbooks12N、A0比較4/場、reference113_comparisons4N、all_reference113_equal/all_source111_equal、全残玉/予約0、Before=After。first2は24冊・旧8対照・原文3手法場、base54は648冊・旧216・原文81、full70は840冊・旧280・原文81。

## 人工と停止

手製の買売24冊には加速順行と逆配置反転の二出生を同じ源から渡す。T/TRの違い、未知拒否後の消費、後の公表を見たfill再判定の禁止、予約/悪BBO、A0旧P100四費用の毎受理原行/終了同体、Source非干渉、EOF完結と将来追記非干渉を検査する。metadataは旧113Nativeを作らない人工で、並列はcallbackだけの手製I/Oで確認する。これらは市場の利益やFAR自然生成の証拠ではない。

停止器は自己15ファイル、旧113停止を含む全実閉包、依存6の前後不変、人工/vet/build/APIを記録しfixed:falseの条件素材を作る。新市場条件をRootが別に固定する。Raw・価格CSV・11/09を追加取得せず、未参加/返済後仮想利益・機会損失・MFE回収率・ROIは作らない。
