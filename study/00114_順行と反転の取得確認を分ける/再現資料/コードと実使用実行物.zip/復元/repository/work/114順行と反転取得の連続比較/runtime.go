// Package entrycomparison114 は元時計のSourceを変更せず、12口座と確定足の必須保護へ結びます。
package entrycomparison114

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"reflect"

	bank "github.com/masayoshi4649/SessionTradeExecuter/chartprotection111"
	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	actor "github.com/masayoshi4649/SessionTradeExecuter/continuousactor114"
	legacyCore "github.com/masayoshi4649/SessionTradeExecuter/entrycomparison113"
	gate "github.com/masayoshi4649/SessionTradeExecuter/entrygate114"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
)

type EntryEvent struct {
	Kind   string      `json:"kind"`
	Stamp  gate.Stamp  `json:"stamp"`
	Frame  *gate.Frame `json:"frame,omitempty"`
	Reason string      `json:"reason,omitempty"`
}

type Counts struct {
	Rows         int `json:"rows"`
	BadQuotes    int `json:"bad_quotes"`
	Publications int `json:"publications"`
	Resets       int `json:"resets"`
}

type Result struct {
	Version                  int                           `json:"version"`
	Trial                    int                           `json:"trial"`
	Scope                    source.SourceCase             `json:"scope"`
	Configurations           []actor.ActorConfig           `json:"configurations"`
	Books                    map[string]actor.ActualResult `json:"books"`
	Publications             []bank.Observation            `json:"publications"`
	Resets                   []bank.Reset                  `json:"resets"`
	Counts                   Counts                        `json:"counts"`
	EntryEvents              []EntryEvent                  `json:"entry_gate_events"`
	FinalChart               bank.Snapshot                 `json:"final_chart"`
	EntryGridSeconds         *int                          `json:"entry_grid_seconds"`
	ExtraOpeningQuietSeconds int                           `json:"extra_opening_quiet_seconds"`
	ChartSeedMode            string                        `json:"chart_seed_mode"`
	ExplicitTimers           int                           `json:"explicit_timers"`
	Complete                 bool                          `json:"complete"`
}

type ReplayResult struct {
	Version                       int                 `json:"version"`
	Trial                         int                 `json:"trial"`
	Source                        source.ReplayResult `json:"source"`
	Actual                        Result              `json:"actual"`
	A0Comparisons                 int                 `json:"A0_comparisons"`
	A0Equal                       bool                `json:"A0_equal"`
	OriginalHistoricalEventsEqual bool                `json:"original_historical_events_equal"`
	Reference113                  *ReferenceProof     `json:"reference113,omitempty"`
}

// ReferenceProof は旧113の保存済み12冊と源全値の照合範囲です。
type ReferenceProof struct {
	Reference         source.FileRef                       `json:"reference"`
	Comparisons       int                                  `json:"comparisons"`
	AllFinancialEqual bool                                 `json:"all_financial_equal"`
	SourceEqual       bool                                 `json:"source_equal"`
	BeforeSHA256      string                               `json:"before_sha256"`
	AfterSHA256       string                               `json:"after_sha256"`
	Details           map[string]actor.LegacyComparison114 `json:"details"`
}

// Consumer はSourceへ値を返さず、当時の原行を独立した12口座へ配送します。
type Consumer struct {
	result       Result
	chart        *bank.Bank
	books        []*actor.ActualBook
	begun, ended bool
	failure      error
}

// New は入力をまだ読まない当場用の配送器を作ります。
//
// 引数: なし。返り値: *Consumerは当場coldの追加保護と12口座の接続です。
func New() *Consumer {
	return &Consumer{result: Result{Version: 1, Trial: 114, Configurations: actor.DeclaredContinuousConfigurations(), Books: map[string]actor.ActualResult{}, Publications: []bank.Observation{}, Resets: []bank.Reset{}, EntryEvents: []EntryEvent{}, ChartSeedMode: "cold_each_session"}}
}

// copyValue は出典と結果の可変参照を分離します。
//
// 引数: value(T)はJSON保存可能な値。返り値: Tは独立した全値です。
func copyValue[T any](value T) T {
	raw, err := json.Marshal(value)
	if err != nil {
		panic(err)
	}
	var out T
	if err = json.Unmarshal(raw, &out); err != nil {
		panic(err)
	}
	return out
}

// stop は最初の失敗を保持し、その後の部分結果を成功へ転用しません。
//
// 引数: err(error)は処理失敗。返り値: errorは保持された最初の失敗です。
func (c *Consumer) stop(err error) error {
	if c.failure == nil {
		c.failure = err
	}
	return c.failure
}

// Begin は元Sourceの場・限月をそのまま12口座へ適用します。
//
// 引数: scene(source.SourceCase)は実構築した元設定と場。返り値: errorは二重開始又は不正です。
func (c *Consumer) Begin(scene source.SourceCase) error {
	if c == nil || c.begun || c.ended {
		return fmt.Errorf("114配送の二重開始又は未初期化")
	}
	c.begun = true
	c.result.Scope = copyValue(scene)
	if len(c.result.Configurations) != 12 {
		return c.stop(fmt.Errorf("114実宣言が12条件でない"))
	}
	var err error
	c.chart, err = bank.New(chart.Scene{ID: scene.Session.ID, Contract: scene.Contract, Start: scene.Session.Start}, nil)
	if err != nil {
		return c.stop(err)
	}
	for _, config := range c.result.Configurations {
		book, e := actor.NewContinuousBook(scene.Session, scene.Contract, config)
		if e != nil {
			return c.stop(e)
		}
		c.books = append(c.books, book)
	}
	return nil
}

// Step は同じ原行で公表された足を先に配送し、元通知を12口座へ一度ずつ渡します。
//
// 引数: step(source.NativeStep)は源から独立複写された当原行。返り値: errorは因果・所有又は会計の不正です。
func (c *Consumer) Step(step source.NativeStep) error {
	if c == nil || !c.begun || c.ended {
		return fmt.Errorf("114配送の原行順序が不正")
	}
	if c.failure != nil {
		return c.failure
	}
	o := step.Observation
	validLast := o.Last > 0 && !math.IsNaN(o.Last) && !math.IsInf(o.Last, 0)
	if !validLast || o.Reference != "NK225" {
		return c.stop(fmt.Errorf("元166で未受理の原行を追加保護へ配送"))
	}
	batch, err := c.chart.Step(chart.Quote{Time: o.Time, Index: o.Index, Line: step.SourceLine, Last: o.Last, Bid: o.Bid, Ask: o.Ask, Valid: validLast})
	if err != nil {
		return c.stop(err)
	}
	if len(batch.EntryGrids) != 0 || batch.After.CarriedNumericSeed {
		return c.stop(fmt.Errorf("114へ研究側の新規時計又は未宣言seedを追加"))
	}
	if o.Index < 0 || int64(int(o.Index)) != o.Index || step.SourceLine <= 0 {
		return c.stop(fmt.Errorf("114原行index/lineの型範囲不正"))
	}
	stamp := gate.Stamp{Time: o.Time, Index: int(o.Index), Line: step.SourceLine}
	for _, event := range batch.Events {
		switch event.Kind {
		case "reset":
			if event.Index < 0 || event.Index >= len(batch.Resets) {
				return c.stop(fmt.Errorf("114 reset出典範囲"))
			}
			r := batch.Resets[event.Index]
			if r.At != o.Time {
				return c.stop(fmt.Errorf("114 resetを未観測時刻へ遡及"))
			}
			c.result.EntryEvents = append(c.result.EntryEvents, EntryEvent{Kind: "reset", Stamp: stamp, Reason: r.Reason})
			for _, book := range c.books {
				if e := book.ResetEntryFrame(stamp, r.Reason); e != nil {
					return c.stop(e)
				}
				if e := book.ResetPublication(r.At, r.Reason); e != nil {
					return c.stop(e)
				}
			}
		case "observation":
			if event.Index < 0 || event.Index >= len(batch.Observations) {
				return c.stop(fmt.Errorf("114公表出典範囲"))
			}
			p := batch.Observations[event.Index]
			if p.At != o.Time {
				return c.stop(fmt.Errorf("114公表を未観測時刻へ遡及"))
			}
			frame := copyValue(p.Frame)
			c.result.EntryEvents = append(c.result.EntryEvents, EntryEvent{Kind: "observation", Stamp: stamp, Frame: &frame})
			for _, book := range c.books {
				if e := book.SetEntryFrame(copyValue(p.Frame), stamp); e != nil {
					return c.stop(e)
				}
				if e := book.SetPublication(p.At, 1, p.Buy); e != nil {
					return c.stop(e)
				}
				if e := book.SetPublication(p.At, -1, p.Sell); e != nil {
					return c.stop(e)
				}
			}
		default:
			return c.stop(fmt.Errorf("114未宣言公開イベント:%s", event.Kind))
		}
	}
	batches := make([]actor.NativeBatch, 0, len(step.Mini))
	for _, item := range step.Mini {
		batches = append(batches, actor.NativeBatch{Method: item.Method, Delta: item.Delta})
	}
	for _, book := range c.books {
		if e := book.OnNativeStep(o, step.SourceLine, batches); e != nil {
			return c.stop(e)
		}
	}
	c.result.Publications = append(c.result.Publications, copyValue(batch.Observations)...)
	c.result.Resets = append(c.result.Resets, copyValue(batch.Resets)...)
	c.result.Counts.Rows++
	if !o.QuoteOK || math.IsNaN(o.Bid) || math.IsInf(o.Bid, 0) || math.IsNaN(o.Ask) || math.IsInf(o.Ask, 0) || o.Bid <= 0 || o.Ask <= o.Bid {
		c.result.Counts.BadQuotes++
	}
	c.result.Counts.Publications += len(batch.Observations)
	c.result.Counts.Resets += len(batch.Resets)
	return nil
}

// End はEOFへ気配やForceを加えず全12口座の完結を確認します。
//
// 引数: end(source.SourceEnd)は源が完結確認した通知。返り値: errorは残量・予約・場又は架空timerです。
func (c *Consumer) End(end source.SourceEnd) error {
	if c == nil || !c.begun || c.ended {
		return fmt.Errorf("114配送の終了順序が不正")
	}
	if c.failure != nil {
		return c.failure
	}
	if !end.Complete || end.ExplicitTimerCalls != 0 || !reflect.DeepEqual(end.Session, c.result.Scope.Session) {
		return c.stop(fmt.Errorf("114源の終了・原時計が不正"))
	}
	_, last, err := c.chart.Seal()
	if err != nil {
		return c.stop(err)
	}
	c.result.FinalChart = last
	for _, book := range c.books {
		value, e := book.Finish()
		if e != nil {
			return c.stop(e)
		}
		if _, exists := c.result.Books[value.Key]; exists {
			return c.stop(fmt.Errorf("114口座IDが重複"))
		}
		c.result.Books[value.Key] = value
	}
	if len(c.result.Books) != 12 {
		return c.stop(fmt.Errorf("114口座の欠落"))
	}
	c.result.Complete, c.ended = true, true
	return nil
}

// Result は完了した当場の実口座と公開出典だけを独立複写します。
//
// 引数: receiver(*Consumer)は当場。返り値: Result/errorは完了結果又は未成功です。
func (c *Consumer) Result() (Result, error) {
	if c == nil || c.failure != nil || !c.ended || !c.result.Complete {
		return Result{}, fmt.Errorf("114接続結果は未完了")
	}
	return copyValue(c.result), nil
}

// ConnectResult は元Sourceと12口座を非干渉のまま結合します。
//
// 引数: origin(source.ReplayResult)、consumer(*Consumer)は源と当場配送です。
// 返り値: ReplayResult/errorは完結した結合値。A0対照は旧113正式Nativeへ別途照合します。
func ConnectResult(origin source.ReplayResult, consumer *Consumer) (ReplayResult, error) {
	actual, err := consumer.Result()
	if err != nil {
		return ReplayResult{}, err
	}
	if !origin.Complete || origin.Trial != 111 || origin.Session.ID != actual.Scope.Session.ID || origin.Contract != actual.Scope.Contract {
		return ReplayResult{}, fmt.Errorf("114の元Source完結/場差")
	}
	return ReplayResult{Version: 1, Trial: 114, Source: copyValue(origin), Actual: actual, OriginalHistoricalEventsEqual: false}, nil
}

// CompareReference113Values は同場・同費用の旧P100四費用とSource全値を照合します。
//
// 引数: current(*ReplayResult)、prior(legacyCore.ReplayResult)、ref(source.FileRef)は新結果・旧保存値・出典です。
// 返り値: errorは許可した版説明以外の全金融値又は源の差です。
func CompareReference113Values(current *ReplayResult, prior legacyCore.ReplayResult, ref source.FileRef) error {
	if current == nil || current.Version != 1 || current.Trial != 114 || current.Source.Trial != 111 ||
		!current.Actual.Complete || prior.Version != 1 || prior.Trial != 113 || !prior.Actual.Complete || prior.Actual.Trial != 113 ||
		current.Actual.Scope.Session.ID != prior.Actual.Scope.Session.ID || current.Actual.Scope.Contract != prior.Actual.Scope.Contract {
		return fmt.Errorf("114と旧113対照の場・版・完結差")
	}
	a, err := json.Marshal(current.Source)
	if err != nil {
		return err
	}
	b, err := json.Marshal(prior.Source)
	if err != nil {
		return err
	}
	if !bytes.Equal(a, b) {
		return fmt.Errorf("Source111の全JSON値に非干渉差")
	}
	proof := ReferenceProof{Reference: ref, SourceEqual: true, Details: map[string]actor.LegacyComparison114{}}
	for _, cost := range []int{0, 5} {
		for _, delay := range []int{0, 1} {
			key := fmt.Sprintf("A0_C%d_D%d", cost, delay)
			priorKey := fmt.Sprintf("P100_C%d_D%d", cost, delay)
			newBook, ok := current.Actual.Books[key]
			oldBook, found := prior.Actual.Books[priorKey]
			if !ok || !found {
				return fmt.Errorf("114のA0旧P100四対照欠落:%s", key)
			}
			checked, e := actor.CompareLegacy113(newBook, oldBook)
			if e != nil || !checked.AllFinancialEqual {
				return fmt.Errorf("旧113P100金融全値差:%s:%v", key, e)
			}
			proof.Details[key] = checked
			proof.Comparisons++
		}
	}
	current.A0Comparisons, current.A0Equal = proof.Comparisons, proof.Comparisons == 4
	proof.AllFinancialEqual = true
	current.Reference113 = &proof
	return nil
}

// CompareReference113 はRoot固定後の当場旧113Nativeだけを認証・復号して4冊を照合します。
//
// 引数: current(*ReplayResult)、ref(source.FileRef)は114結果と旧113正式Nativeの期待参照です。
// 返り値: errorはSHA・源・全金融値・前後不変の差です。metadata-onlyから呼びません。
func CompareReference113(current *ReplayResult, ref source.FileRef) error {
	if err := source.VerifyRef(ref); err != nil {
		return err
	}
	f, err := os.Open(ref.Path)
	if err != nil {
		return err
	}
	defer f.Close()
	z, err := gzip.NewReader(f)
	if err != nil {
		return err
	}
	defer z.Close()
	var prior legacyCore.ReplayResult
	if err = json.NewDecoder(z).Decode(&prior); err != nil {
		return err
	}
	if err = CompareReference113Values(current, prior, ref); err != nil {
		return err
	}
	after, err := source.Digest(ref.Path)
	if err != nil {
		return err
	}
	if after != ref.SHA256 {
		return fmt.Errorf("旧113参照の読取前後差")
	}
	current.Reference113.BeforeSHA256 = ref.SHA256
	current.Reference113.AfterSHA256 = after
	return nil
}
