"""校正済み56×9/S23/R12の保持と、手製12候補の結果結合を検査する。"""

from copy import deepcopy
from pathlib import Path
import json
import tempfile
import unittest
import 結合する as M

FAKE=M.ROOT/'work/114損益CSVの出力/人工_停止版/手製の独立結果.json'
FAKE_SHA='63ac50b66abf7a3725eeac0c7e8eb7f1b174dea8dd0ab463921af2a91c903a2e'


def inputs() -> tuple:
    """機能: 校正済み表とCSVで既検査した手製schemaを指紋認証して読む。

    引数: なし。
    返り値: tuple[str,dict]は市場を含まない設定文と人工JSON。
    """
    before={}
    source=M.load_ref({'path':str(M.TABLE_PATH),'sha256':M.TABLE_SHA},before,True)
    fake=M.load_ref({'path':str(FAKE),'sha256':FAKE_SHA},before)
    return source,fake


class Table114Tests(unittest.TestCase):
    """数値と役割を混同せず、元の条件セルを維持することを確認する。"""

    def test_counts_and_unchanged_definitions(self) -> None:
        """機能: 56×9/S23/R12と共通S01-17の定義を保持する。

        引数: self(Table114Tests)は検査器。
        返り値: None。正式表や旧113を編集しない。
        """
        source,fake=inputs();rendered,proof=M.render(source,fake,True)
        before,after=M.parse_table(source),M.parse_table(rendered)
        self.assertEqual(before['features'],after['features'])
        for identity in (f'S{n:02}' for n in range(1,17)):
            self.assertEqual(before['settings'][identity]['line'],after['settings'][identity]['line'])
        self.assertEqual(before['settings']['S17']['cells'][:5],after['settings']['S17']['cells'][:5])
        self.assertEqual(before['settings']['S17']['cells'][6],after['settings']['S17']['cells'][6])
        self.assertEqual(proof['結果行数'],12)
        self.assertIn('C/BBは診断、15分は準備のみ',rendered)
        self.assertIn('人工2場・24会計の結合検査（市場の成功ではない）',rendered)

    def test_literal_amounts_and_gate_denominators(self) -> None:
        """機能: 手計算できる正益/赤字/0取引と入口分母の表示先を確認する。

        引数: self(Table114Tests)は検査器。
        返り値: None。勝率とPFは別の値として表示する。
        """
        source,fake=inputs();rendered,_=M.render(source,fake,True)
        result=M.parse_table(rendered)['results']
        self.assertIn('純額＋1,692円、PF 1.786、勝率50.00%',result['R01']['cells'][3])
        self.assertIn('PF 未定義、勝率未定義',result['R05']['cells'][3])
        self.assertIn('元要求8、許可0、採用票の真/偽/未知=0/4/4',result['R05']['cells'][3])
        self.assertIn('元要求8、許可4、採用票の真/偽/未知=4/2/2',result['R09']['cells'][3])
        self.assertIn('純額−654円',result['R11']['cells'][3])
        self.assertIn('採否はC0の純額だけから自動決定しない',rendered)

    def test_schema_or_mode_change_rejected(self) -> None:
        """機能: 12候補の欠落・Policy混同・三値分母改変を拒否する。

        引数: self(Table114Tests)は検査器。
        返り値: None。
        """
        _,fake=inputs()
        for kind in ('keys','policy','truth'):
            bad=deepcopy(fake)
            if kind=='keys':bad['主key'].pop()
            elif kind=='policy':bad['Actor設定']['A0_C0_D0']['policy']='A0'
            else:bad['場別'][0]['入口票検査']['counts']['selected_true']+=1
            with self.subTest(kind=kind),self.assertRaises(ValueError):M.validate_result(bad,True)
        source,_=inputs()
        with self.assertRaises(ValueError):M.parse_table(source.replace('| R12 |','| R11 |'))

    def test_unfixed_request_before_result(self) -> None:
        """機能: Root未解禁は表・金融結果の参照前かつ出力作成前に拒否する。

        引数: self(Table114Tests)は検査器。
        返り値: None。実市場を読み込まない。
        """
        with tempfile.TemporaryDirectory(prefix='設定表人工_',dir=M.OWN) as temp:
            path=Path(temp)/'未解禁.json';out=Path(temp)/'出力'
            path.write_text(json.dumps({'version':1,'trial':114,'fixed':False,'result_read_authorized':False}),encoding='utf-8')
            with self.assertRaises(ValueError):M.execute({'path':str(path),'sha256':M.sha(path)},out)
            self.assertFalse(out.exists())


if __name__=='__main__':unittest.main(verbosity=2)
