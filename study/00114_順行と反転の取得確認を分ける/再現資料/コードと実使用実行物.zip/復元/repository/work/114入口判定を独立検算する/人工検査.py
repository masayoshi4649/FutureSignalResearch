"""114の独立式を、順行/回復/中立/不足/売買鏡像の手製例で確認する。"""

from copy import deepcopy
from decimal import Decimal
import unittest

from 独立式 import calculate, conjunction, disjunction


def frame(end: int, fast: float, slow: float, close: float, hist: float) -> dict:
    """機能: 数学的に管理できる手製の確定足を作る。

    引数: end(int)、fast/slow/close/hist(float)は名目終端と技法値。
    返り値: dictは独立式用Frame。市場値やGo判定を読み込まない。
    """
    return {'id':str(end), 'session':'人工場', 'contract':'人工限月', 'end':end, 'ordinal':end//180,
            'data_known':True, 'ema8':Decimal(str(fast)), 'ema21':Decimal(str(slow)), 'close':Decimal(str(close)), 'hist':Decimal(str(hist)),
            'known':{'ema8':True, 'ema21':True, 'close':True, 'hist':True}}


def mirror(value: dict) -> dict:
    """機能: 買いの手製価格を売りの同じ符号条件へ鏡像化する。

    引数: value(dict)は手製Frame。
    返り値: dictは価格1000−元値、Histは反転した独立Frame。
    """
    result = deepcopy(value)
    for name in ('ema8', 'ema21', 'close'):
        result[name] = Decimal(1000) - result[name]
    result['hist'] = -result['hist']
    return result


class IndependentTest(unittest.TestCase):
    def test_three_valued_tables(self) -> None:
        """機能: 全9組のAND/ORを手で指定した真理表へ照合する。

        引数: self(IndependentTest)。返り値: None。不一致は失敗。
        """
        and_table = ((0,1,0), (1,1,1), (0,1,2))
        or_table = ((0,0,2), (0,1,2), (2,2,2))
        for a in range(3):
            for b in range(3):
                self.assertEqual(conjunction([a,b]), and_table[a][b])
                self.assertEqual(disjunction([a,b]), or_table[a][b])

    def test_trend_and_mirror(self) -> None:
        """機能: 平均・価格・MACD水準が整う入口の鏡像性を確認する。

        引数: self(IndependentTest)。返り値: None。
        """
        previous = frame(180,104,99,103,1)
        current = frame(360,105,100,106,2)
        buy = calculate(current,previous,1)
        sell = calculate(mirror(current),mirror(previous),-1)
        self.assertEqual(buy,sell)
        self.assertEqual((buy['trend'],buy['reversal'],buy['combined']),(2,1,2))

    def test_reclaim_does_not_require_hist_level_or_slow_slope(self) -> None:
        """機能: 逆配置からの回復を、遅い線反転待ちの順行と区別する。

        引数: self(IndependentTest)。返り値: None。
        """
        previous = frame(180,100,105,99,-2)
        current = frame(360,101,105,102,-1)
        buy = calculate(current,previous,1)
        self.assertEqual((buy['trend'],buy['reversal'],buy['combined']),(1,2,2))
        self.assertEqual(buy,calculate(mirror(current),mirror(previous),-1))
        no_event = deepcopy(previous)
        no_event['close'] = Decimal(101)
        self.assertEqual(calculate(current,no_event,1)['reversal'],1)
        no_improvement = deepcopy(current)
        no_improvement['hist'] = Decimal(-2)
        self.assertEqual(calculate(no_improvement,previous,1)['reversal'],1)

    def test_unknown_input_and_known_denial_are_distinct(self) -> None:
        """機能: Hist不足と既知中立を、真偽の勝手な補完なしで扱う。

        引数: self(IndependentTest)。返り値: None。
        """
        previous = frame(180,104,99,103,1)
        current = frame(360,105,100,106,2)
        current['known']['hist'] = False
        result = calculate(current,previous,1)
        self.assertEqual((result['trend'],result['reversal'],result['combined']),(0,1,0))
        current['ema21'] = Decimal(105)
        result = calculate(current,previous,1)
        self.assertEqual((result['trend'],result['reversal'],result['combined']),(1,1,1))
        self.assertIsNone(result['values']['hist_level'])

    def test_irrelevant_missing_does_not_override_true(self) -> None:
        """機能: 反転用の前Hist不足が、既に真のTを未知へ変えないことを確認する。

        引数: self(IndependentTest)。返り値: None。
        """
        previous = frame(180,104,99,103,1)
        previous['known']['hist'] = False
        result = calculate(frame(360,105,100,106,2),previous,1)
        self.assertEqual(result['combined'],2)
        self.assertIsNone(result['values']['hist_delta'])


if __name__ == '__main__':
    unittest.main()
