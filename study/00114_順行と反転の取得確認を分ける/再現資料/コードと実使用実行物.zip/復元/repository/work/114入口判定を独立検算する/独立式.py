"""Go実装と別の十進数・三値演算で、114の要求時入口票を検算する。"""

from decimal import Decimal
from typing import Any

UNKNOWN, FALSE, TRUE = 0, 1, 2
ZERO = Decimal(0)


def number(value: Any) -> Decimal:
    """機能: 有限値を十進数へ変換する。

    引数: value(Any)はJSONの数値。
    返り値: Decimalは有限の元数値。bool・文字列・非有限値は受理しない。
    """
    assert not isinstance(value, (bool, str)) and value is not None
    result = value if isinstance(value, Decimal) else Decimal(str(value))
    assert result.is_finite()
    return result


def conjunction(values: list[int]) -> int:
    """機能: 偽が未知に優先する三値ANDを求める。

    引数: values(list[int])は未知0・偽1・真2の票。
    返り値: intは三値AND。空の票や宣言外値は不正とする。
    """
    assert values and all(x in (UNKNOWN, FALSE, TRUE) for x in values)
    return FALSE if FALSE in values else UNKNOWN if UNKNOWN in values else TRUE


def disjunction(values: list[int]) -> int:
    """機能: 真が未知に優先する三値ORを求める。

    引数: values(list[int])は未知0・偽1・真2の票。
    返り値: intは三値OR。
    """
    assert values and all(x in (UNKNOWN, FALSE, TRUE) for x in values)
    return TRUE if TRUE in values else UNKNOWN if UNKNOWN in values else FALSE


def compare(value: Decimal | None, op: str) -> int:
    """機能: 既知値のゼロ境界を評価し、不足値は未知として残す。

    引数: value(Decimal|None)、op(str)は値と >0/<0/<=0 の演算。
    返り値: intは三値。0を不足値に変換しない。
    """
    assert op in ('>0', '<0', '<=0')
    if value is None:
        return UNKNOWN
    passed = value > ZERO if op == '>0' else value < ZERO if op == '<0' else value <= ZERO
    return TRUE if passed else FALSE


def field(frame: dict | None, name: str) -> Decimal | None:
    """機能: 当時のFrameのDataKnownと個別Knownを区別して読む。

    引数: frame(dict|None)、name(str)は元公表とEMA8/EMA21/Hist/Closeの名前。
    返り値: Decimal|Noneは既知値又は入力不足。後から補完しない。
    """
    assert name in ('ema8', 'ema21', 'hist', 'close')
    if frame is None or not frame['data_known'] or not frame['known'][name]:
        return None
    return number(frame[name])


def difference(left: Decimal | None, right: Decimal | None, side: int) -> Decimal | None:
    """機能: 両値が既知の場合だけ売買方向へ符号を揃えた差を求める。

    引数: left/right(Decimal|None)、side(int)は現値・比較値・買1/売−1。
    返り値: Decimal|Noneは方向差又は不足。
    """
    assert side in (-1, 1)
    return None if left is None or right is None else Decimal(side) * (left - right)


def calculate(current: dict | None, previous: dict | None, side: int) -> dict:
    """機能: 原Frameから7値とT/R/ORを独立に求める。

    引数: current/previous(dict|None)は実配送済み公表のframe、side(int)は方向。
    返り値: dictは元値由来の値・条件票・複合票。注文や約定を作らない。
    """
    assert side in (-1, 1)
    if previous is not None:
        assert current is not None
        assert current['session'] == previous['session'] and current['contract'] == previous['contract']
        assert current['id'] != previous['id'] and number(current['end']) - number(previous['end']) == 180
        assert current['ordinal'] > previous['ordinal']
    fast = field(current, 'ema8')
    slow = field(current, 'ema21')
    close = field(current, 'close')
    hist = field(current, 'hist')
    values = {
        'g': difference(fast, slow, side),
        'a8': difference(fast, field(previous, 'ema8'), side),
        'a21': difference(slow, field(previous, 'ema21'), side),
        'x8': difference(close, fast, side),
        'x8_prev': difference(field(previous, 'close'), field(previous, 'ema8'), side),
        'hist_level': None if hist is None else Decimal(side) * hist,
        'hist_delta': difference(hist, field(previous, 'hist'), side),
    }
    trend = [compare(values[k], '>0') for k in ('g', 'a8', 'a21', 'x8', 'hist_level')]
    reversal = [compare(values['g'], '<0'), compare(values['a8'], '>0'), compare(values['x8_prev'], '<=0'), compare(values['x8'], '>0'), compare(values['hist_delta'], '>0')]
    t, r = conjunction(trend), conjunction(reversal)
    return {'values': values, 'trend': t, 'reversal': r, 'combined': disjunction([t, r]), 'trend_truths': trend, 'reversal_truths': reversal}


def verify_decision(decision: dict) -> dict:
    """機能: 保存済みのGo入口票を原Frame・要求原行から独立検算する。

    引数: decision(dict)は凍結済みentrygate114.DecisionのJSON。
    返り値: dictは検査数。実原板の最初の到達や未保存全tickを証明しない。
    """
    assert decision['version'] == 114 and decision['frozen'] is True
    request, scope = decision['request'], decision['scope']
    at = request['at']
    publications = [decision['current'], decision['previous']]
    for publication in publications:
        if publication is None:
            continue
        frame, delivered = publication['frame'], publication['delivered']
        assert frame['session'] == scope['session'] and frame['contract'] == scope['contract']
        assert number(frame['end']) <= number(frame['available_at']) <= number(delivered['time']) <= number(at['time'])
        assert delivered['index'] <= at['index'] and delivered['source_line'] <= at['source_line']
        if delivered['index'] == at['index']:
            assert delivered == at
    current = None if publications[0] is None else publications[0]['frame']
    previous = None if publications[1] is None else publications[1]['frame']
    expected = calculate(current, previous, request['side'])
    for name, value in expected['values'].items():
        actual = decision['values'][name]
        assert (actual is None and value is None) or (actual is not None and value is not None and abs(number(actual)-value) <= Decimal('0.0000000001')), (name, actual, value)
    for name in ('trend', 'reversal', 'combined'):
        assert decision[name] == expected[name], (name, decision[name], expected[name])
    assert decision['continuous'] == (previous is not None)
    assert [c['truth'] for c in decision['trend_conditions']] == expected['trend_truths']
    assert [c['truth'] for c in decision['reversal_conditions']] == expected['reversal_truths']
    return {'値': 7, '条件票': 10, '複合票': 3, '公表数': sum(x is not None for x in publications)}
