"""Root独立式を変更せず入口の新CLI/接続監査を人工停止する。"""
from pathlib import Path
from datetime import datetime, timezone
import ast
import os
import subprocess
import sys

import 検算する as V
import 人工CLI検査 as T


def run(command: list[str]) -> dict:
    """
    機能: 独立Pythonの人工又はCLI説明だけを実行する。
    引数: command(list[str])。返り値: dictは成功ログ。不成功はValueError。
    """
    p=subprocess.run(command,cwd=V.HERE,env=dict(os.environ,PYTHONIOENCODING="utf-8"),capture_output=True,text=True,encoding="utf-8",timeout=60)
    V.need(p.returncode==0,p.stdout+p.stderr)
    return {"command":command,"exit_code":p.returncode,"stdout":p.stdout,"stderr":p.stderr}


def main() -> None:
    """
    機能: 7新主/5Root主とGo16/接続24冊48票を固定して市場前停止する。
    引数: なし。返り値: None。実市場Native/Raw/金融再実行なし。
    """
    target,out=V.HERE/"停止.json",V.HERE/"検査"
    V.need(not target.exists() and not out.exists(),"新規入口Python停止だけ")
    own={str((V.HERE/n).resolve()):V.digest(V.HERE/n) for n in V.OWNED}
    rootcodes={str((V.HERE/n).resolve()):sha for n,sha in V.ROOT_CODES.items()}
    before={}
    for p,sha in rootcodes.items():V.reference({"path":p,"sha256":sha},before)
    for ref in (T.PURE_STOP,T.PURE_DECL,T.PURE_ART,T.CORE_ART,T.CORE_STOP):V.reference(ref,before)
    core=V.load(Path(T.CORE_STOP["path"]))
    V.need(core["成功"] and core["停止"] and core["trial"]==114,"Core市場前停止")
    for p,sha in core["所有コードSHA256"].items():V.reference({"path":p,"sha256":sha},before)
    actor_ref={"path":str(V.ROOT/"work/114順行反転取得を執行する会計/Actor停止.json"),"sha256":"2178d1fbe7b980d7f507d6d9c99c6cdef1a8bde8702e4e4a69dbe97b687a9b93"}
    actor=V.load(V.reference(actor_ref,before))
    V.need(actor["成功"] and actor["市場前"],"Actor市場前停止")
    for p,sha in actor["所有コードSHA256"].items():V.reference({"path":p,"sha256":sha},before)
    pure_stop=V.load(Path(T.PURE_STOP["path"]))
    for p,sha in pure_stop["所有コードSHA256"].items():V.reference({"path":p,"sha256":sha},before)
    manifest=V.load(Path(T.CORE_ART["path"]))
    for case in manifest["cases"]:V.reference(case["current"],before)
    for name in V.OWNED:
        if not name.endswith(".py"):continue
        for node in ast.walk(ast.parse((V.HERE/name).read_text(encoding="utf-8"))):
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                doc=ast.get_docstring(node) or ""
                V.need("\n" in doc and all(k in doc for k in ("機能","引数","返り値")),"関数コメント:"+node.name)
    out.mkdir()
    logs=[run([sys.executable,"-X","utf8","人工検査.py"]),run([sys.executable,"-X","utf8","人工CLI検査.py"]),run([sys.executable,"-X","utf8","検算する.py","--help"])]
    V.need("Ran 5 tests" in logs[0]["stderr"] and "Ran 7 tests" in logs[1]["stderr"],"独立主人工集合")
    pure,values=T.fixtures()
    pure_checks=[V.verify_full_decision(case["decision"]) for case in pure["cases"]]
    core_checks=[V.verify_scene(native,True) for native in values]
    proof=V.write(out/"人工確認.json",{"試行":114,"成功":True,"市場前":True,"Root独立主":5,"新主":7,"純Go16票":pure_checks,"Core買売":core_checks,"三値表":9,"市場Native/Raw/金融再実行":False})
    V.need(all(V.digest(Path(p))==sha for p,sha in {**before,**own}.items()),"全所有/Root2/依存前後不変")
    stopped={"試行":114,"成功":True,"市場前":True,"停止":True,"UTC":datetime.now(timezone.utc).isoformat(),"所有ファイルSHA256":own,"Root独立式SHA256":rootcodes,"依存コードSHA256":before,"純Go停止":T.PURE_STOP,"純Go実定義":T.PURE_DECL,"Actor停止":actor_ref,"Core停止":T.CORE_STOP,"人工確認":proof,"主人工":7,"Root主人工":5,"Go票":16,"Core会計":24,"Core票":48,"API":"verify_entry_gate(book:dict,config:dict,actual_context:dict)->dict; 差はValueError","前後不変":True,"検査ログ":logs,"実市場Native/Raw/価格CSV/11月09本文":False,"金融再実行":False}
    ref=V.write(target,stopped)
    print(__import__("json").dumps({"成功":True,"停止":ref,"人工確認":proof},ensure_ascii=False))


if __name__=="__main__":
    main()
