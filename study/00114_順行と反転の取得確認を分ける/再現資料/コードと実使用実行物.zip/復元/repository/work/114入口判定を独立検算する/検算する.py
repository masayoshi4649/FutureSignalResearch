"""114の配送・Source要求・純票・実受付を保存値だけから独立検算する。"""
from copy import deepcopy
from collections import Counter
from decimal import Decimal
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import re
import sys
from datetime import date, timedelta

if not __debug__:
    raise ValueError("独立式のassertを無効化する起動は禁止")

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ROOT_CODES = {"独立式.py":"75279ee570a1dbea59588eebf8b3c39acb0d9f30bbc1bb145314f8e468ea39f3", "人工検査.py":"0c01cfb907a4c6e8f88f67309ec71bb8e81af67bd058c83c6775defbd8497588"}
for filename, expected_sha in ROOT_CODES.items():
    if hashlib.sha256((HERE/filename).read_bytes()).hexdigest() != expected_sha:
        raise ValueError("Root独立式code差:"+filename)
import 独立式 as I

MODES = ("A0", "T", "TR")
CONFIGS = tuple({"policy":"P100","entry_mode":m,"slip_pts":c,"delay_seconds":d} for m in MODES for c in (0,5) for d in (0,1))
KEYS = tuple(f"{c['entry_mode']}_C{c['slip_pts']}_D{c['delay_seconds']}" for c in CONFIGS)
OWNED = ("検算する.py", "人工CLI検査.py", "README.md", "検査して停止する.py")


def need(value: bool, label: str) -> None:
    """
    機能: 出典や会計結合の差を失敗として拒否する。
    引数: value(bool)、label(str)。返り値: None。不成立はValueError。
    """
    if not value:
        raise ValueError(label)


def digest(path: Path) -> str:
    """
    機能: 明示JSON/コード/解禁Nativeの指紋を求める。
    引数: path(Path)。返り値: strはSHA256。Rawは対象外。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reject_constant(value: str) -> None:
    """
    機能: 非標準の非有限JSON数値を拒否する。
    引数: value(str)。返り値: None。必ずValueError。
    """
    raise ValueError("非有限JSON:"+value)


def load(path: Path) -> dict:
    """
    機能: 認証済みJSONを有限十進数で読む。
    引数: path(Path)。返り値: dictは元保存値。
    """
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path,"rt",encoding="utf-8-sig") as f:
        return json.load(f,parse_float=Decimal,parse_constant=reject_constant)


def serial(value):
    """
    機能: 有限DecimalだけをJSON数値へ写す。
    引数: value(object)。返り値: int/float又はTypeError。
    """
    if isinstance(value,Decimal) and value.is_finite():
        return int(value) if value == value.to_integral_value() else float(value)
    raise TypeError(type(value).__name__)


def write(path: Path, value: dict) -> dict:
    """
    機能: 未作成UTF-8 JSONだけを保存する。
    引数: path(Path)、value(dict)。返り値: dictはFileRef。
    """
    with path.open("x",encoding="utf-8",newline="\n") as f:
        f.write(json.dumps(value,ensure_ascii=False,indent=2,default=serial,allow_nan=False)+"\n")
    return {"path":str(path.resolve()),"sha256":digest(path)}


def reference(ref: dict, before: dict) -> Path:
    """
    機能: 明示絶対参照をSHA認証して前後台帳へ結ぶ。
    引数: ref/before(dict)。返り値: Pathは認証済み位置。
    """
    need(isinstance(ref,dict) and isinstance(ref.get("path"),str) and re.fullmatch("[a-f0-9]{64}",ref.get("sha256","")) is not None,"絶対FileRef型")
    path=Path(ref["path"])
    need(path.is_absolute(),"相対Ref拒否")
    path=path.resolve();need(digest(path)==ref["sha256"],"SHA差:"+str(path))
    need(str(path) not in before or before[str(path)]==ref["sha256"],"同位置SHA衝突")
    before[str(path)]=ref["sha256"]
    return path


def normalize(value):
    """
    機能: Go JSONの読取型を公開canonical用Python型へ正規化する。
    引数: value(JSON値)。返り値: JSON値。Decimalの小数表記はfloatの最短表記へ写す。
    """
    if isinstance(value,Decimal):
        return float(value)
    if isinstance(value,list):
        return [normalize(x) for x in value]
    if isinstance(value,dict):
        return {k:normalize(v) for k,v in value.items()}
    return value


def canonical_sha(value: dict) -> str:
    """
    機能: 停止公開器のPython互換正準JSONを別処理でハッシュ化する。
    引数: value(dict)。返り値: strはSHA256。元Frame/Resultを変えない。
    """
    text=json.dumps(normalize(value),ensure_ascii=False,sort_keys=True,separators=(",",":"),allow_nan=False)
    text=text.replace("\u2028","\\u2028").replace("\u2029","\\u2029")
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def stamp(value: dict, scope: dict) -> tuple:
    """
    機能: 原行stampの時計/Index/物理行を独立検査する。
    引数: value/scope(dict)。返り値: tupleは時計・Index・Line。
    """
    need(set(value)=={"time","index","source_line"},"Stamp集合")
    at=I.number(value["time"])
    need(I.number(scope["start"])<=at<=I.number(scope["end"]),"場内原行")
    need(type(value["index"]) is int and value["index"]>=0 and type(value["source_line"]) is int and value["source_line"]>0,"原行整数")
    return at,value["index"],value["source_line"]


def stamp_before(a: dict, b: dict) -> bool:
    """
    機能: 同秒でも物理原行を保って前後を比較する。
    引数: a/b(dict)。返り値: boolはaがb以前のとき真。
    """
    return I.number(a["time"])<=I.number(b["time"]) and a["index"]<=b["index"] and a["source_line"]<=b["source_line"] and ((a["index"]!=b["index"] and a["source_line"]!=b["source_line"]) or a==b)


def verify_frame(frame: dict, delivered: dict, scope: dict) -> None:
    """
    機能: 旧Frameの場/名目時計/足出典/個別KnownをGoなしで確認する。
    引数: frame/delivered/scope(dict)。返り値: None。Raw形成の再証明はしない。
    """
    stamp(delivered,scope)
    need(frame["session"]==scope["session"] and frame["contract"]==scope["contract"] and frame["start"]==scope["start"],"Frame場限月")
    end=I.number(frame["end"])
    need(end>I.number(scope["start"]) and end<=I.number(scope["end"]) and (end-I.number(scope["start"]))%180==0,"Frame3分終端")
    need(frame["at"]==frame["available_at"]==frame["technical_end"]==frame["end"] and end<=I.number(frame["observed_clock"])<=I.number(delivered["time"]),"Frame名目/配送時計")
    need(isinstance(frame["id"],str) and frame["id"] and type(frame["ordinal"]) is int and frame["ordinal"]>0,"Frame識別")
    need(type(frame["data_known"]) is bool and all(type(frame["known"][k]) is bool for k in ("ema8","ema21","hist","close")),"Frame既知旗")
    for key in ("ema8","ema21","hist","close"):
        number=I.number(frame[key])
        if frame["data_known"] and frame["known"][key] and key!="hist":need(number>0,"既知価格正")
    source=frame["last_source"]
    if source is not None:
        need(source["line"]<delivered["source_line"] and source["index"]<=delivered["index"],"足出典は配送原行前")
    if frame["data_known"]:
        need(source is not None and source["valid"] and end-180<=I.number(source["time"])<end and source["line"]>0 and source["index"]>=0 and I.number(source["last"])>0,"足の半開出典")
    o=frame["ohlc"]
    if o is not None:
        need(frame["data_known"] and frame["known"]["close"] and o["publication_id"]==frame["id"] and o["close"]==frame["close"],"OHLC出典")
        need(0<I.number(o["low"])<=min(I.number(o["open"]),I.number(o["close"]))<=max(I.number(o["open"]),I.number(o["close"]))<=I.number(o["high"]),"OHLC形状")


def verify_full_decision(decision: dict) -> dict:
    """
    機能: Root独立7値/三値式へ、条件ID/op/値・missing/denial・場内因果を追加照合する。
    引数: decision(dict)。返り値: dictは検査件数。不一致はValueError。
    """
    try:
        checked=I.verify_decision(decision)
    except (AssertionError,KeyError,TypeError) as error:
        raise ValueError("Root独立票不一致:"+str(error)) from error
    scope=decision["scope"];stamp(decision["request"]["at"],scope)
    current,previous=decision["current"],decision["previous"]
    for publication in (current,previous):
        if publication is not None:verify_frame(publication["frame"],publication["delivered"],scope)
    ck=current is not None and current["frame"]["data_known"]
    pk=previous is not None and previous["frame"]["data_known"] and ck
    need(previous is None or pk,"不良足の前Frameを利用しない")
    c={} if current is None else current["frame"]["known"]
    p={} if previous is None else previous["frame"]["known"]
    inputs=[("current.data_known",ck),("current.ema8",ck and c["ema8"]),("current.ema21",ck and c["ema21"]),("current.close",ck and c["close"]),("current.hist",ck and c["hist"]),("previous.contiguous_3m",pk),("previous.ema8",pk and p["ema8"]),("previous.ema21",pk and p["ema21"]),("previous.close",pk and p["close"]),("previous.hist",pk and p["hist"])]
    need(decision["missing_inputs"]==[name for name,known in inputs if not known],"missing全入力と順序")
    specifications={"trend":(("T.G","g",">0"),("T.a8","a8",">0"),("T.a21","a21",">0"),("T.x8","x8",">0"),("T.HistLevel","hist_level",">0")),"reversal":(("R.G","g","<0"),("R.a8","a8",">0"),("R.x8p","x8_prev","<=0"),("R.x8","x8",">0"),("R.HistDelta","hist_delta",">0"))}
    for branch,specification in specifications.items():
        conditions=decision[branch+"_conditions"]
        need(len(conditions)==5,"個別条件5")
        for condition,(identity,value,op) in zip(conditions,specification):
            need(condition["id"]==identity and condition["op"]==op and condition["value"]==decision["values"][value],"条件ID/op/元値")
        need(decision[branch+"_denials"]==[x["id"] for x in conditions if x["truth"]==I.FALSE],"既知否定のみ保存")
    if decision["last_reset"] is not None:
        stamp(decision["last_reset"],scope)
        need(stamp_before(decision["last_reset"],decision["request"]["at"]) and bool(decision["reset_reason"]),"reset出典")
    return {**checked,"missing_denial":3,"条件metadata":10}


def events_for_context(context: dict, scope: dict) -> list[dict]:
    """
    機能: Core実Events順・公表Frame/Result指紋・reset列を照合する。
    引数: context/scope(dict)。返り値: list[dict]は原Events。不変値として扱う。
    """
    events=context["entry_gate_events"]
    publications=context["publications"] or []
    resets=context["resets"] or []
    observations=[e for e in events if e["kind"]=="observation"]
    reset_events=[e for e in events if e["kind"]=="reset"]
    need(len(observations)==len(publications) and len(reset_events)==len(resets),"Events全公表/reset数")
    previous=None
    for event in events:
        stamp(event["stamp"],scope)
        need(previous is None or stamp_before(previous,event["stamp"]),"Events原行順")
        previous=event["stamp"]
        need(event["kind"] in ("observation","reset"),"Events宣言種別")
        if event["kind"]=="observation":verify_frame(event["frame"],event["stamp"],scope)
        else:need(bool(event["reason"]),"reset理由")
    for event,publication in zip(observations,publications):
        need(event["frame"]==publication["frame"] and event["stamp"]["time"]==publication["at"],"実公表Frameと配送")
        need(canonical_sha(publication["frame"])==publication["frame_sha256"] and canonical_sha(publication["result"])==publication["result_sha256"],"公表Frame/Resultの独立canonicalSHA")
    for event,reset in zip(reset_events,resets):
        need(event["stamp"]["time"]==reset["at"] and event["reason"]==reset["reason"],"reset実順")
    return events


def history_points(events: list[dict], requests: list[dict], scope: dict) -> list[dict]:
    """
    機能: 配送済みEventだけをSource要求まで進め、現在/前Frameを独立再構成する。
    引数: events/requests(list[dict])、scope(dict)。返り値: list[dict]は要求時の小履歴。
    """
    cursor,current,previous,last_reset,reason=0,None,None,None,""
    seen={};max_end=Decimal(0);max_ordinal=0;last_request=None;out=[]
    for request in requests:
        at=request["at"];stamp(at,scope)
        need(last_request is None or stamp_before(last_request,at),"Source要求原行順")
        while cursor<len(events) and stamp_before(events[cursor]["stamp"],at):
            event=events[cursor];cursor+=1
            if event["kind"]=="reset":
                current,previous,last_reset,reason=None,None,event["stamp"],event["reason"]
                continue
            f=event["frame"]
            if f["id"] in seen:
                need(f==seen[f["id"]] and I.number(f["end"])==max_end,"同ID改変/古いID")
                continue
            need(I.number(f["end"])>max_end and f["ordinal"]>max_ordinal,"公表End/Ordinal前進")
            previous=current if current is not None and current["frame"]["data_known"] and f["data_known"] and I.number(f["end"])-I.number(current["frame"]["end"])==180 else None
            current={"frame":f,"delivered":event["stamp"]}
            seen[f["id"]]=f;max_end=I.number(f["end"]);max_ordinal=f["ordinal"]
        out.append({"current":current,"previous":previous,"last_reset":last_reset,"reset_reason":reason})
        last_request=at
    return out


def verify_entry_gate(book: dict, config: dict, context: dict) -> dict:
    """
    機能: Source全new・入口票・容量受付・実fillを元Events/注文へ独立に結ぶ。
    引数: book/config/context(dict)。返り値: dictは件数と三値分母。金融損益は別監査。
    """
    original=repr((book,config,context))
    need(config in CONFIGS and book["config"]==config,"入口本名12設定")
    audit=book["entry_gate"];need(audit["version"]==114 and audit["mode"]==config["entry_mode"],"入口保存版/モード")
    scope={"session":book["session"]["id"],"contract":context["scope"]["contract"],"start":book["session"]["start"],"end":book["session"]["end"]}
    events=events_for_context(context,scope)
    rows=audit["records"] or [];news=[e for e in (book["source_events"] or []) if e["kind"]=="new_signal"]
    need(len(rows)==len(news)==book["metrics"]["native_new_signals"],"全Source要求分母")
    need(len({(r["request"]["product"],r["request"]["method"],r["request"]["side"],r["request"]["signal_id"]) for r in rows})==len(rows),"一出生一回固定")
    requests=[r["request"] for r in rows];points=history_points(events,requests,scope)
    orders={o["id"]:o for o in (book["orders"] or [])};fills={f["id"]:f for f in (book["fills"] or [])};positions={p["id"]:p for p in (book["positions"] or [])}
    need(len(orders)==len(book["orders"] or []) and len(fills)==len(book["fills"] or []) and len(positions)==len(book["positions"] or []),"実ID重複")
    counts=Counter({k:0 for k in ("source_new","allowed","selected_true","selected_false","selected_unknown","accepted_requests","accepted_quantity","actual_new_fills","actual_quantity","input_missing","known_denial","publications_checked")})
    for row,event,point in zip(rows,news,points):
        request,decision,source=row["request"],row["decision"],row["source"]
        need(request==decision["request"] and decision["scope"]==scope,"純票の実要求と場")
        need(request["product"]=="NK225mini" and request["method"]==source["method"]==event["method"] and request["signal_id"]==source["signal_id"]==event["signal_id"] and request["side"]==event["side"],"Source複合要求")
        at={"time":row["quote"]["time"],"index":row["quote"]["index"],"source_line":row["quote"]["source_line"]}
        need(request["at"]==at and row["quote"]==event["quote"]==source["birth_quote"] and source["birth_time"]==event["at"]==at["time"] and source["birth_quantity"]==event["quantity"],"元要求原行と出生量")
        for name in point:need(decision[name]==point[name],"配送順からの要求時履歴:"+name)
        verified=verify_full_decision(decision)
        selected=I.TRUE if config["entry_mode"]=="A0" else decision["trend"] if config["entry_mode"]=="T" else decision["combined"]
        need(row["selected"]==selected and row["allowed"]==(selected==I.TRUE),"モード選別")
        cap=min(event["quantity"],row["available"])
        cancelled=any(e["kind"]=="cancel" and e["method"]==request["method"] and e["signal_id"]==request["signal_id"] and e["quote"]["index"]<=at["index"] and e["quote"]["source_line"]<=at["source_line"] for e in (book["source_events"] or []))
        need(row["source_cancelled"]==cancelled and 0<=row["available"]<=10 and row["available"]==event["available"] and row["cap_quantity"]==cap,"容量/取消とgateの別記")
        accepted=cap if row["allowed"] and not cancelled else 0
        need(row["accepted_quantity"]==event["actual_accepted"]==accepted and row["order_id"]==event["order_id"],"実受付量/注文ID")
        counts["source_new"]+=1;counts["allowed"]+=row["allowed"];counts[{0:"selected_unknown",1:"selected_false",2:"selected_true"}[selected]]+=1
        counts["input_missing"]+=bool(decision["missing_inputs"]);counts["known_denial"]+=bool(decision["trend_denials"] or decision["reversal_denials"]);counts["publications_checked"]+=verified["公表数"]
        if accepted:
            counts["accepted_requests"]+=1;counts["accepted_quantity"]+=accepted
            need(row["order_id"] in orders,"受付注文存在")
            order=orders[row["order_id"]]
            need(order["kind"]=="entry" and order["source"]==source and order["quantity"]==accepted and order["side"]==request["side"] and order["request_quote"]==row["quote"] and order["request_time"]==at["time"],"受付注文全結合")
        else:need(not row["order_id"],"未受付注文なし")
        if row["actual_quantity"]:
            need(accepted==row["actual_quantity"] and row["actual_fill_id"] in fills and row["actual_position_id"] in positions,"実取得ID量")
            fill=fills[row["actual_fill_id"]];position=positions[row["actual_position_id"]];quote=fill["quote"]
            need(fill["action"]=="new" and fill["order_id"]==row["order_id"] and fill["position_id"]==position["id"] and fill["quantity"]==accepted and fill["source"]==source and fill["quote"]==row["actual_quote"]==position["entry_quote"],"実new取得結合")
            need(fill["side"]==position["side"]==request["side"] and position["source"]==source and position["initial_quantity"]==accepted and position["entry_order_id"]==row["order_id"] and fill["source_hold_id"]==position["source_hold_id"],"実玉の全入口所有")
            need(quote["index"]>at["index"] and quote["source_line"]>at["source_line"] and I.number(quote["time"])>=I.number(at["time"])+config["delay_seconds"],"strict後原行/D時計")
            need(quote["quote_ok"] and 0<I.number(quote["bid"])<I.number(quote["ask"]) and fill["price"]==position["entry_price"]==(quote["ask"] if request["side"]==1 else quote["bid"]),"実BBO取得価格")
            counts["actual_new_fills"]+=1;counts["actual_quantity"]+=accepted
        else:need(not row["actual_fill_id"] and not row["actual_position_id"] and row["actual_quote"] is None,"未取得を未来で補完しない")
    need(counts["accepted_requests"]==book["metrics"]["entry_requests"]==sum(o["kind"]=="entry" for o in orders.values()) and counts["accepted_quantity"]==book["metrics"]["entry_accepted_quantity"] and counts["actual_new_fills"]==book["metrics"]["entry_fills"]==sum(f["action"]=="new" for f in fills.values())==len(positions),"受付/実fill分母")
    need(counts["selected_true"]+counts["selected_false"]+counts["selected_unknown"]==counts["source_new"],"三値全分母")
    need(repr((book,config,context))==original,"入口独立監査は原値非変更")
    return {"成功":True,"counts":dict(counts),"配送と要求の独立再構成":True,"金融損益再計算":False,"限界":"保存されたEvents/Source通知/注文/実fillの照合。Rawの生成と最初の正常原行は別証明。"}


def verify_scene(native: dict, artificial: bool = False) -> dict:
    """
    機能: Core全12のSource要求・費用/モード間の固定票同体を独立照合する。
    引数: native(dict)、artificial(bool)。返り値: dictは全12結果と共通票件数。
    """
    actual=native["actual"];need(native["trial"]==actual["trial"]==114 and set(actual["books"])==set(KEYS),"114全12")
    need(actual["complete"] and actual["configurations"]==list(CONFIGS),"114全12宣言と完結")
    checked={};baseline=None;count=0
    for key,config in zip(KEYS,CONFIGS):
        book=actual["books"][key];checked[key]=verify_entry_gate(book,config,actual)
        projection=[{k:r[k] for k in ("request","source","quote","decision")} for r in (book["entry_gate"]["records"] or [])]
        if baseline is None:baseline=projection
        else:need(projection==baseline,"費用/モード間のSource要求と純固定票同体")
        count+=len(projection)
    # ----------------------------------------
    # 元Source信号が保存される自然再生では、actual側の通知だけに分母を依存しない。
    original=[]
    sources=native["source"].get("sources")
    need(artificial or isinstance(sources,dict),"自然Source全文の保存あり")
    for src in (sources or {}).values():
        if src["config"]["product"]!="NK225mini":continue
        for rec in src["signals"]:
            signal=rec["signal"]
            if signal["action"]=="new":original.append((src["method"],signal["id"],signal["side"],rec["quote"]))
    observed=[(r["request"]["method"],r["request"]["signal_id"],r["request"]["side"],r["quote"]) for r in baseline or []]
    if original or not artificial:
        need(sorted(original,key=lambda r:r[:3])==sorted(observed,key=lambda r:r[:3]),"元Source全文の全new集合と分母")
    return {"成功":True,"会計数":12,"全Source延べ票":count,"共通Source要求数":len(baseline or []),"手製Source器具":artificial,"book":checked,"費用間とモード間のDecision同体":True}


def planned_sessions(stage: str) -> list[str]:
    """
    機能: 事前固定のfirst2/元54/全70予定集合を列挙する。
    引数: stage(str)。返り値: list[str]は日付順。11/09を含めない。
    """
    need(stage in ("first2","base54","full70"),"入口監査stage")
    end=date(2026,9,21) if stage=="first2" else date(2026,10,27) if stage=="base54" else date(2026,11,6)
    day,result=date(2026,9,21),[]
    while day<=end:
        if day.weekday()<5:result.extend(f"{day.isoformat()}_{kind}" for kind in ("Day","Night"))
        day+=timedelta(days=1)
    need(len(result)=={"first2":2,"base54":54,"full70":70}[stage],"予定全場数")
    return result


def same_ref(left: dict, right: dict) -> bool:
    """
    機能: 参照の解決絶対Path/SHAだけを同体比較する。
    引数: left/right(dict)。返り値: bool。bytes付加やslash表記を対象差にしない。
    """
    return isinstance(left,dict) and isinstance(right,dict) and isinstance(left.get("path"),str) and isinstance(right.get("path"),str) and Path(left["path"]).is_absolute() and Path(right["path"]).is_absolute() and Path(left["path"]).resolve()==Path(right["path"]).resolve() and left.get("sha256")==right.get("sha256") and isinstance(left.get("sha256"),str)


def prepare(path: Path, sha: str, output: Path) -> dict:
    """
    機能: 新Root解禁・独立停止・金融全成功・元対照をNative本文前に認証する。
    引数: path/output(Path)、sha(str)。返り値: dictは明示Native読取計画。
    """
    need(output.is_absolute() and not output.exists(),"入口監査新規絶対出力")
    before={};request=load(reference({"path":str(path.resolve()),"sha256":sha},before))
    need(request["version"]==1 and request["trial"]==114 and request["fixed"] is True and request["market_native_read_authorized"] is True,"新Root市場Native解禁")
    expected=planned_sessions(request["stage"])
    stop=load(reference(request["entry_stop"],before))
    need(stop["成功"] and stop["市場前"] and stop["試行"]==114,"入口Python市場前停止")
    own={str((HERE/name).resolve()):digest(HERE/name) for name in OWNED}
    rootcodes={str((HERE/name).resolve()):sha for name,sha in ROOT_CODES.items()}
    need(stop["所有ファイルSHA256"]==own and stop["Root独立式SHA256"]==rootcodes,"入口Python実使用code固定")
    for name,expected_sha in {**own,**rootcodes,**stop["依存コードSHA256"]}.items():reference({"path":name,"sha256":expected_sha},before)
    actual_code=reference(request["entry_code"],before)
    need(actual_code==Path(__file__).resolve() and own[str(actual_code)]==request["entry_code"]["sha256"],"実入口監査code")
    condition=load(reference(request["condition"],before));complete=load(reference(request["completion"],before))
    need(condition["trial"]==114 and condition["fixed"] is True and condition["actual_configurations"]==list(CONFIGS),"114凍結全12条件")
    need(same_ref(condition["dependency_stops"]["entry_gate"],stop["純Go停止"]),"金融条件と入口純停止")
    definition=load(reference(stop["純Go実定義"],before))
    need(condition["entry_gate_definition"]==definition,"金融の入口実式全値")
    need(same_ref(condition["runtime_stop"],stop["Core停止"]),"金融条件と停止Core")
    runtime=load(reference(condition["runtime_stop"],before))
    need(runtime["成功"] and runtime["停止"] and runtime["trial"]==114,"Core停止")
    need(complete["trial"]==114 and complete["success"] is True and complete["stage"]==request["stage"] and complete["sessions"]==len(expected) and complete["books"]==12*len(expected),"全予定金融成功")
    need(complete["condition_sha256"]==request["condition"]["sha256"] and complete["unchanged"] and complete["before"] and complete["before"]==complete["after"],"同条件と全前後不変")
    need((complete["reused_sessions"],complete["replayed_sessions"])==((54,16) if request["stage"]=="full70" else (0,len(expected))),"認証再用と新規再生の区別")
    need(complete["all_reference113_equal"] and complete["all_source111_equal"] and complete["reference113_comparisons"]==4*len(expected),"元P100/Source全値対照")
    need([r["session"] for r in complete["results"]]==expected,"欠落重複なしの場順")
    for code,expected_sha in condition["code_sha256"].items():
        target=Path(code);target=(target if target.is_absolute() else ROOT/target).resolve()
        need(not target.name.endswith(".Native.json.gz") and target.suffix not in (".csv",".jsonl",".gz"),"code固定へ市場入力を混ぜない")
        reference({"path":str(target),"sha256":expected_sha},before)
        need(complete["before"].get(str(target))==expected_sha,"金融が使用した同code")
    for row in complete["results"]:
        need(row["books"]==12 and row["complete"] and row["A0_equal"] and row["A0_comparisons"]==4 and row["reference113_equal"] and row["reference113_comparisons"]==4 and row["source111_equal"] and row["open_quantity"]==row["pending_quantity"]==0,"場別全12とflat/元対照")
    return {"request":request,"complete":complete,"before":before,"output":output.resolve()}


def execute(plan: dict, request_ref: dict) -> dict:
    """
    機能: 解禁済み全Nativeを新規先へ独立検算し、不完了を成功扱いしない。
    引数: plan/request_ref(dict)。返り値: dictは成功結果FileRef。
    """
    output=plan["output"];output.mkdir(parents=False,exist_ok=False)
    scenes=[]
    try:
        for row in plan["complete"]["results"]:
            native=load(reference(row["native"],plan["before"]))
            need(native["actual"]["scope"]["session"]["id"]==row["session"],"Native場境界")
            scenes.append({"session":row["session"],**verify_scene(native)})
        after={p:digest(Path(p)) for p in plan["before"]}
        need(after==plan["before"],"入口全入力code前後不変")
        result={"試行":114,"成功":True,"stage":plan["request"]["stage"],"場数":len(scenes),"会計数":12*len(scenes),"Root要求":request_ref,"金融条件SHA256":plan["request"]["condition"]["sha256"],"金融完了SHA256":plan["request"]["completion"]["sha256"],"入口独立停止SHA256":plan["request"]["entry_stop"]["sha256"],"場別":scenes,"入力codeSHA256前":plan["before"],"入力codeSHA256後":after,"前後不変":True,"金融損益再計算":False,"Raw/価格CSV/11月09本文/市場再走":False,"限界":["公表生成は保存Frame/Resultの指紋と出典照合まで。Raw形成を別走していない。","容量Availableは全Source通知と受付票の整合。保有/予約/費用・損益の完全計算は別の金融監査。","実約定は要求後Index/物理行・遅延・BBOを照合し、Raw上の最初の正常原行という初回性を追加証明しない。"]}
        return write(output/"結果.json",result)
    except Exception as error:
        write(output/"不完了.json",{"成功":False,"試行":114,"error":str(error),"Root要求":request_ref})
        raise


def main() -> None:
    """
    機能: 明示Root成功要求だけから入口独立監査を開始する。
    引数: CLI fixed/sha256/output(str)、metadata-only(bool)。返り値: None。
    """
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixed",required=True,type=Path);parser.add_argument("--sha256",required=True);parser.add_argument("--output",required=True,type=Path);parser.add_argument("--metadata-only",action="store_true")
    args=parser.parse_args();plan=prepare(args.fixed,args.sha256,args.output.resolve())
    if args.metadata_only:
        print(json.dumps({"成功":True,"Native本文読取":False,"予定場数":len(plan["complete"]["results"])},ensure_ascii=False));return
    ref=execute(plan,{"path":str(args.fixed.resolve()),"sha256":args.sha256})
    print(json.dumps({"成功":True,"結果":ref},ensure_ascii=False))


if __name__=="__main__":
    main()
