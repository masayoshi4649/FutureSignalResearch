# 114入口の独立Python監査

Root所有の `独立式.py`（75279e…39f3）と`人工検査.py`（0c01cf…7588）は変更せずSHA固定。新所有は検算する.py/人工CLI検査.py/README.md/検査して停止する.pyだけ。金融損益/P監査は別担当で、本部品は公表・入口票・Source要求・実受付/取得を照合する。

APIは `verify_entry_gate(book,config,actual_context)->dict` と `verify_scene(native,artificial=False)->dict`。Root式が元Frameから7値・T/R/ORを十進数で計算し、値は1e-10以内、符号票は完全一致を要求する。さらに条件ID/op/保存値、missing10入力の順序、既知否定IDを照合する。Truthは未知0/偽1/真2。最終判定未知と、一部入力に不足がある件数は別。

Coreのentry_gate_eventsをIndex/物理行込みの原順で要求まで進め、current/previous/last_resetを再構成する。同IDでは窓/初回配送を進めず、resetで旧公表を復活させない。Frameは名目At/End/AvailableAt、実配送は別stamp。Source要求より同秒後行の公表は使わない。publications/resetsへ全値結合し、Frame/Resultの公開canonical SHAも別Pythonで照合する。市場Rawから公表形成を別再現したという主張ではない。

全Source new通知とrecordsを一対一にし、Source出生/quote/side/数量、freeze時点、モード選択、容量受付、予約注文、実new fill/Positionを照合する。未知・否定・全許可A0・cap・Source取消を分ける。Available自体の保有/予約会計は別金融監査が計算し、本部品はSource通知/保存票/受付量を結合する。実fillのIndex/物理行後・遅延・正常BBOは検査するが、Raw上の最初の適格原行という初回性までは証明しない。要求後のFrameで再ゲートせず、費用/モード全12の元要求とDecisionを同体照合する。

市場CLIは `python -X utf8 検算する.py --fixed ABS --sha256 SHA --output NEW_ABS`。`--metadata-only`は市場Native本文/実Native指紋を開かない。新Root要求はversion1/trial114/fixedtrue/market_native_read_authorizedtrue/stage(first2/base54/full70)、entry_stop/entry_code/condition/completionの絶対FileRef。自己停止/Root2コード/純Go停止・実式、Core停止・全金融成功/旧A0四×場数/Source同体/flat/予定場順を先に認証する。全70は同条件54認証再用＋16新規再生を区別する。Source全文の全mini新規集合は自然再生で必須、Source無しの手製器具は人工フラグを明示する。

assertを無効にする `python -O` は拒否する。出力は新規先だけで、失敗時に不完了を保存し成功へ補わない。市場/Raw/価格CSV/11月09日をRoot新要求前に読まない。利益や機会損失・退出後価格・MFE回収は集計しない。
