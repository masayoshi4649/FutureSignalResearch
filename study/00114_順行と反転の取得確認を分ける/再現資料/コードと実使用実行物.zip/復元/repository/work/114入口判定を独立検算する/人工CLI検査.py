"""純Go/接続Goの手製票、破壊反例と本文前ゲートだけを検査する。"""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest

import 検算する as V

PURE_STOP={"path":str(V.ROOT/"work/114順行と反転取得の純判定/停止.json"),"sha256":"3e721f461a0b737140771335bcee67c033f3413a911910cf256f1b453f8037d6"}
PURE_DECL={"path":str(V.ROOT/"work/114順行と反転取得の純判定/検査/実定義.json"),"sha256":"9e681e66ee18f221363ea7c3180c5a574c352cc6029cf3083b3a2bcab73a50ff"}
PURE_ART={"path":str(V.ROOT/"work/114順行と反転取得の純判定/検査/人工.json"),"sha256":"35d68df4742294721b56897288d9bb65e1d0a82572e2702fc676a735936e6e02"}
CORE_ART={"path":str(V.ROOT/"work/114順行と反転取得の連続比較/人工_独立保存用/人工.json"),"sha256":"ad8d3498c8a08afe0fabdee3d1a24f9dd4b16e43f4bf72e07a45493c03f82419"}
CORE_STOP={"path":str(V.ROOT/"work/114順行と反転取得の連続比較/停止.json"),"sha256":"8e48f8c008a3bb6ab72ef9ec21f2b474dc403c79aa4a6b1a34f7b1d30d0ae729"}


def fixtures() -> tuple:
    """
    機能: Root明示済みの純/接続人工だけを指紋認証して読む。
    引数: なし。返り値: tupleは純人工と買売Core人工。
    """
    before={}
    pure=V.load(V.reference(PURE_ART,before));manifest=V.load(V.reference(CORE_ART,before))
    V.need(pure["人工"] and not pure["市場Raw"] and manifest["artificial"] and manifest["books"]==24,"人工範囲")
    values=[V.load(V.reference(case["current"],before)) for case in manifest["cases"]]
    return pure,values


def gate_fixture(base: Path) -> tuple:
    """
    機能: Nativeを作成しない成功小metadataだけでRoot解禁ゲートを試す。
    引数: base(Path)。返り値: tupleは手製要求Refと値。市場成功ではない。
    """
    base.mkdir()
    definition=V.load(Path(PURE_DECL["path"]))
    runtime=CORE_STOP
    condition=V.write(base/"条件.json",{"trial":114,"fixed":True,"actual_configurations":list(V.CONFIGS),"dependency_stops":{"entry_gate":PURE_STOP},"entry_gate_definition":definition,"runtime_stop":runtime,"code_sha256":{}})
    scenes=[]
    for sid in V.planned_sessions("first2"):
        scenes.append({"session":sid,"native":{"path":str((base/(sid+".Native.json.gz")).resolve()),"sha256":"a"*64},"books":12,"complete":True,"A0_equal":True,"A0_comparisons":4,"reference113_equal":True,"reference113_comparisons":4,"source111_equal":True,"open_quantity":0,"pending_quantity":0})
    complete=V.write(base/"完了.json",{"trial":114,"success":True,"stage":"first2","sessions":2,"books":24,"condition_sha256":condition["sha256"],"unchanged":True,"before":{"metadata":"same"},"after":{"metadata":"same"},"reused_sessions":0,"replayed_sessions":2,"all_reference113_equal":True,"all_source111_equal":True,"reference113_comparisons":8,"results":scenes})
    stop=V.write(base/"入口停止.json",{"成功":True,"市場前":True,"試行":114,"所有ファイルSHA256":{str((V.HERE/n).resolve()):V.digest(V.HERE/n) for n in V.OWNED},"Root独立式SHA256":{str((V.HERE/n).resolve()):sha for n,sha in V.ROOT_CODES.items()},"依存コードSHA256":{},"純Go停止":PURE_STOP,"純Go実定義":PURE_DECL,"Core停止":CORE_STOP})
    req={"version":1,"trial":114,"fixed":True,"market_native_read_authorized":True,"stage":"first2","entry_stop":stop,"entry_code":{"path":str(Path(V.__file__).resolve()),"sha256":V.digest(Path(V.__file__))},"condition":condition,"completion":complete}
    return V.write(base/"要求.json",req),req


class EntryCLI114Tests(unittest.TestCase):
    """原板・金融再走なしの独立入口監査。"""

    @classmethod
    def setUpClass(cls):
        """
        機能: 解禁済み手製を一度だけ準備する。
        引数: cls(type)。返り値: None。
        """
        cls.pure,cls.values=fixtures()

    def test_pure16_and_truth9(self):
        """
        機能: 停止純Go16票/三値9組をRoot十進独立式と追加契約へ照合する。
        引数: self(EntryCLI114Tests)。返り値: None。
        """
        self.assertEqual(len(self.pure["cases"]),16)
        for case in self.pure["cases"]:V.verify_full_decision(case["decision"])
        for row in self.pure["truth_tables"]:
            self.assertEqual(row["and"],V.I.conjunction([row["a"],row["b"]]));self.assertEqual(row["or"],V.I.disjunction([row["a"],row["b"]]))

    def test_core24_and_48_source_votes(self):
        """
        機能: Core24冊/48票のFrame配送・受付・fillと全費用票同体を照合する。
        引数: self(EntryCLI114Tests)。返り値: None。
        """
        checks=[V.verify_scene(n,True) for n in self.values]
        self.assertEqual(sum(c["会計数"] for c in checks),24)
        self.assertEqual(sum(c["全Source延べ票"] for c in checks),48)
        self.assertTrue(all(c["共通Source要求数"]==2 for c in checks))

    def test_missing_denial_metadata_corruptions(self):
        """
        機能: 条件真偽だけ合うmissing/denial/ID/op/値の偽装も拒否する。
        引数: self(EntryCLI114Tests)。返り値: None。
        """
        template=self.pure["cases"][0]["decision"]
        for name in ("missing","denial","id","op","value"):
            d=deepcopy(template)
            if name=="missing":d["missing_inputs"].append("偽不足")
            elif name=="denial":d["trend_denials"].append("偽否定")
            elif name=="id":d["trend_conditions"][0]["id"]="別"
            elif name=="op":d["trend_conditions"][0]["op"]="<0"
            else:d["trend_conditions"][0]["value"]+=1
            with self.subTest(name=name),self.assertRaises(ValueError):V.verify_full_decision(d)

    def test_context_quote_and_denominator_corruptions(self):
        """
        機能: 後行公表/原Frame/全new分母/受付量/実fill/要求付替えを拒否する。
        引数: self(EntryCLI114Tests)。返り値: None。
        """
        for name in ("event","frame","denominator","accepted","fill","rejudge","selected","source"):
            n=deepcopy(self.values[0]);a=n["actual"];book=a["books"]["A0_C0_D0"];row=book["entry_gate"]["records"][0]
            if name=="event":a["entry_gate_events"][0]["stamp"]["index"]+=100000
            elif name=="frame":a["publications"][0]["frame"]["hist"]+=1
            elif name=="denominator":book["entry_gate"]["records"].pop()
            elif name=="accepted":row["accepted_quantity"]+=1
            elif name=="fill":row["actual_quantity"]+=1
            elif name=="rejudge":row["decision"]["request"]["at"]=row["actual_quote"]
            elif name=="selected":row["allowed"]=False
            else:row["source"]["birth_time"]+=1
            with self.subTest(name=name),self.assertRaises((ValueError,AssertionError)):
                V.verify_entry_gate(book,book["config"],a)

    def test_fee_mode_decisions_and_natural_source_required(self):
        """
        機能: 費用間だけの純票差と、自然Source全文不足を拒否する。
        引数: self(EntryCLI114Tests)。返り値: None。
        """
        n=deepcopy(self.values[0]);n["actual"]["books"]["TR_C5_D1"]["entry_gate"]["records"][0]["decision"]["scope"]["contract"]="別"
        with self.assertRaises(ValueError):V.verify_scene(n,True)
        with self.assertRaises(ValueError):V.verify_scene(self.values[0],False)

    def test_zero_trade_books_and_nil_arrays(self):
        """
        機能: 全0Source/受付/取引を空/nullのまま全12残す。
        引数: self(EntryCLI114Tests)。返り値: None。
        """
        n=deepcopy(self.values[0])
        for book in n["actual"]["books"].values():
            for name in ("orders","fills","positions","source_events"):book[name]=None
            book["entry_gate"]["records"]=[]
            for name in book["metrics"]:book["metrics"][name]=0
        checked=V.verify_scene(n,True)
        self.assertEqual(checked["会計数"],12);self.assertEqual(checked["全Source延べ票"],0)

    def test_market_gate_before_native(self):
        """
        機能: Root新解禁/自己停止/全予定成功をNative本文前に検査する。
        引数: self(EntryCLI114Tests)。返り値: None。
        """
        with tempfile.TemporaryDirectory(dir=V.HERE) as directory:
            base=Path(directory);ref,req=gate_fixture(base/"手製")
            plan=V.prepare(Path(ref["path"]),ref["sha256"],base/"未作成先")
            self.assertEqual(len(plan["complete"]["results"]),2)
            self.assertTrue(all(not Path(r["native"]["path"]).exists() for r in plan["complete"]["results"]))
            for name in ("解禁なし","自己停止差","未完了","欠場"):
                bad=deepcopy(req)
                if name=="解禁なし":bad["market_native_read_authorized"]=False
                elif name=="自己停止差":bad["entry_code"]["sha256"]="0"*64
                else:
                    comp=V.load(Path(bad["completion"]["path"]))
                    if name=="未完了":comp["success"]=False
                    else:comp["results"].pop()
                    bad["completion"]=V.write(base/(name+"完了.json"),comp)
                rejected=V.write(base/(name+"要求.json"),bad)
                with self.subTest(name=name),self.assertRaises(ValueError):V.prepare(Path(rejected["path"]),rejected["sha256"],base/(name+"出力"))


if __name__=="__main__":
    unittest.main(verbosity=2)
