"""114二CSVを手製12候補×2場で生成・独立再読し市場前停止する。"""

import argparse
from copy import deepcopy
import csv
import hashlib
import json
from pathlib import Path
import subprocess
import sys

OWN=Path(__file__).resolve().parent
ROOT=OWN.parents[1]
NODE=Path('C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
MARKER=Path('C:/Users/masay/.codex/plugins/cache/openai-primary-runtime/spreadsheets/26.1104.22356/skills/spreadsheets/container_tools/mark_artifact_operation_started.mjs')
OWNED=('出力する.mjs','CSVを独立再読する.py','README.md','人工を実行して停止する.py')
GATE=('source_new','allowed','selected_true','selected_false','selected_unknown','accepted_requests','accepted_quantity','actual_new_fills','actual_quantity','input_missing','known_denial')


def digest(path: Path) -> str:
    """機能: 明示したcode・人工・CSV証拠の全指紋を返す。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def put(path: Path,value: dict) -> dict:
    """機能: 新規JSONをUTF-8で保存しFileRefを得る。

    引数: path(Path)、value(dict)は未作成先と本文。
    返り値: dictは絶対pathとSHA256。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    return {'path':str(path),'sha256':digest(path)}


def metrics(value: dict) -> dict:
    """機能: 人工の正負金額と勝負から比率を定義する。

    引数: value(dict)は手製集計。
    返り値: dictは分母0をNoneとする率。
    """
    positive,negative,wins,losses,count=(value[k] for k in ('positive_yen','negative_yen','positive_positions','negative_positions','positions'))
    gain=positive/wins if wins else None;loss=negative/losses if losses else None
    return {'PF':positive/-negative if negative<0 else None,'win_rate':wins/count if count else None,
            'average_profit_yen':gain,'average_loss_yen':loss,'average_profit_loss_ratio':gain/-loss if gain is not None and loss is not None else None}


def fixture() -> dict:
    """機能: 市場と無関係な全12候補×2場の小さい金融/入口schemaを作る。

    引数: なし。
    返り値: dictは人工=true/stage=artificialで、利益・損失・0取引・未知・否定を含む。
    """
    keys=[];configs={};rows=[];summaries={};gate_summaries={}
    for mode in ('A0','T','TR'):
        for cost in (0,5):
            for delay in (0,1):
                key=f'{mode}_C{cost}_D{delay}';keys.append(key)
                configs[key]={'candidate':mode,'entry_mode':mode,'policy':'P100','entry_timing':'元Source連続時計','slip_pts':cost,'delay_seconds':delay}
                group=[]
                for n,kind in enumerate(('Day','Night')):
                    k=77+200*cost
                    if mode=='A0':positive,negative,wins,losses=2000-k,-1000-k,1,1
                    elif mode=='TR':positive,negative,wins,losses=(2000-k,0,1,0) if n==0 else (0,-500-k,0,1)
                    else:positive=negative=wins=losses=0
                    count=wins+losses;net=positive+negative;fee=77*count;slip=200*cost*count;gross=net+fee+slip
                    counts={'source_new':4,'allowed':4 if mode=='A0' else 2 if mode=='TR' else 0,
                            'selected_true':4 if mode=='A0' else 2 if mode=='TR' else 0,
                            'selected_false':0 if mode=='A0' else 1 if mode=='TR' else 2,
                            'selected_unknown':0 if mode=='A0' else 1 if mode=='TR' else 2,
                            'accepted_requests':count,'accepted_quantity':count,'actual_new_fills':count,'actual_quantity':count,
                            'input_missing':1 if mode=='A0' else 2,'known_denial':3 if mode=='A0' else 2}
                    row={'session':'2026-09-21_'+kind,'key':key,'history_class':'original54','positions':count,'entry_quantity':count,'close_quantity':count,
                         'gross_yen':gross,'fee_yen':fee,'slip_yen':slip,'net_yen':net,'closed_net_yen':net,'positive_yen':positive,'negative_yen':negative,
                         'positive_positions':wins,'negative_positions':losses,'zero_positions':0,'open_buy':0,'open_sell':0,'pending_buy':0,'pending_sell':0,
                         'whole_positive_closed_negative':0,'whole_positive_closed_negative_yen':0,'protection_activated_positions':count,
                         'activated_closed_negative':losses,'activated_closed_negative_yen':negative,'場内時価DD':-negative,
                         '頻度診断':{'held_seconds':count*60,'quantity_seconds':count*75},'入口票検査':{'成功':True,'counts':counts}}
                    row.update(metrics(row));rows.append(row);group.append(row)
                fields=('positions','entry_quantity','close_quantity','gross_yen','fee_yen','slip_yen','net_yen','closed_net_yen','positive_yen','negative_yen','positive_positions','negative_positions','zero_positions','whole_positive_closed_negative','whole_positive_closed_negative_yen','protection_activated_positions','activated_closed_negative','activated_closed_negative_yen')
                aggregate={field:sum(r[field] for r in group) for field in fields}
                aggregate['保存点連結時価DD']=max(r['場内時価DD'] for r in group)
                aggregate['頻度診断']={field:sum(r['頻度診断'][field] for r in group) for field in ('held_seconds','quantity_seconds') if sum(r['頻度診断'][field] for r in group)!=0}
                aggregate.update(metrics(aggregate));summaries[key]=aggregate
                gate_summaries[key]={field:sum(r['入口票検査']['counts'][field] for r in group) for field in GATE if sum(r['入口票検査']['counts'][field] for r in group)!=0}
    return {'試行':114,'成功':True,'人工':True,'stage':'artificial','前後不変':True,'場数':2,'会計数':24,'主key':keys,'Actor設定':configs,'場別':rows,'集計':summaries,'入口票集計':gate_summaries,
            '注意':'手製schema検査だけ。市場/Raw/自然FAR/実損益ではない。'}


def run(argv: list, success: bool=True) -> dict:
    """機能: 明示コマンドの実行記録を取り期待終了状態へ照合する。

    引数: argv(list)はコマンド、success(bool)は成功を期待するか。
    返り値: dictはstdout/stderr/終了値。市場を参照しない人工だけに使う。
    """
    result=subprocess.run([str(item) for item in argv],cwd=OWN,capture_output=True,text=True,encoding='utf-8',timeout=90)
    record={'argv':[str(item) for item in argv],'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
    if (result.returncode==0)!=success:raise ValueError(json.dumps(record,ensure_ascii=False))
    return record


def main() -> None:
    """機能: marker一回から二CSV生成・独立再読・拒否例までを実行して停止する。

    引数: CLI output(str)は未作成の人工/停止先。
    返り値: None。市場結果は読まず新停止Refだけ表示する。
    """
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',required=True,type=Path);args=parser.parse_args()
    output=args.output.resolve()
    if output.exists():raise ValueError('人工/停止先は新規だけ')
    output.mkdir()
    before={str(OWN/name):digest(OWN/name) for name in OWNED}
    source=put(output/'手製の独立結果.json',fixture());csv_dir=output/'CSV'
    commands=[]
    denied=run([NODE,OWN/'出力する.mjs',output/'決して開かない.json','0'*64,output/'未許可出力'],False)
    if '人工又はRootの成功結果指定が必要' not in denied['stderr'] or 'ENOENT' in denied['stderr']:raise ValueError('本文前解禁拒否の差')
    commands.append(denied)
    # ----------------------------------------
    # 最初のWorkbook作成の直前に、操作markerを一度だけ記録します。
    commands.append(run([NODE,MARKER,'--operation-kind','create','--expected-output-count','2','--output-format','csv']))
    commands.append(run([NODE,OWN/'出力する.mjs',source['path'],source['sha256'],csv_dir,'--artificial']))
    checked=output/'CSVの独立再読.json'
    commands.append(run([sys.executable,'-X','utf8',OWN/'CSVを独立再読する.py','--result',source['path'],'--sha256',source['sha256'],'--folder',csv_dir,'--output',checked,'--artificial']))
    proof=json.loads(checked.read_text(encoding='utf-8'))
    if not (proof['成功'] is True and proof['場別行数']==24 and proof['候補数']==12 and proof['0取引行数']==8 and proof['空欄比率確認数']>0 and proof['数値比較数']>0):raise ValueError('人工の比較件数差')
    with (csv_dir/'全セッション.csv').open(encoding='utf-8-sig',newline='') as stream:detail=list(csv.DictReader(stream))
    if not all(row['開始日JST'].endswith(' JST') for row in detail):raise ValueError('日付を文字列で保存していない')
    # ----------------------------------------
    # CSVを別ツールで書換えず、期待JSON側を破壊して独立数値照合の拒否を確認します。
    damaged=fixture();damaged['場別'][0]['net_yen']+=1
    bad=put(output/'正本の数値破壊.json',damaged)
    builder_proof=csv_dir/'CSVの確認.json';saved=builder_proof.read_bytes()
    value=json.loads(saved);value['入力SHA256']=bad['sha256']
    builder_proof.write_text(json.dumps(value,ensure_ascii=False),encoding='utf-8')
    commands.append(run([sys.executable,'-X','utf8',OWN/'CSVを独立再読する.py','--result',bad['path'],'--sha256',bad['sha256'],'--folder',csv_dir,'--output',output/'破壊が通ったら誤り.json','--artificial'],False))
    builder_proof.write_bytes(saved)
    if (output/'破壊が通ったら誤り.json').exists() or list(output.rglob('*.xlsx')):raise ValueError('破壊成功又はxlsx生成')
    after={path:digest(Path(path)) for path in before}
    if before!=after or digest(Path(source['path']))!=source['sha256']:raise ValueError('code又は人工正本の前後差')
    files={str(path):digest(path) for path in output.rglob('*') if path.is_file()}
    record={'試行':114,'成功':True,'市場前':True,'所有ファイルSHA256':before,'前後SHA256':after,'前後不変':True,
            '人工':{'場数':2,'候補数':12,'場別行数':24,'0取引行数':proof['0取引行数'],'数値比較数':proof['数値比較数'],'空欄比率確認数':proof['空欄比率確認数']},
            'Root未指定の本文前拒否':True,'独立数値破壊拒否':True,'JST文字列/書式@':True,'xlsx生成':False,
            '入力':source,'人工出力SHA256':files,'commands':commands,'実市場結果/実CSV/Raw/11月09日本文読取':False,
            '実行環境':{'Node':'v24.22.1','artifact_tool':'2.8.129'},'研究目標達成':False,'採用':False}
    stopped=put(output/'停止.json',record)
    print(json.dumps({'成功':True,'停止':stopped,'人工CSV':str(csv_dir),'数値比較数':proof['数値比較数']},ensure_ascii=False))


if __name__=='__main__':main()
