"""114正式保存器を非市場人工と所有不変の証拠で停止する。"""

import argparse
from pathlib import Path
import subprocess
import sys
import json

import 正式保存する as F


def stop(output: Path) -> dict:
    """機能: 新正式保存器の人工と旧停止の前後不変を固定する。

    引数: output(Path)は新規証拠先。
    返り値: dictは停止Ref。実市場・Raw・CSVを読まない。
    """
    F.need(not output.exists(), '114正式停止の新規先')
    owned = {str(F.OWN / n): F.sha(F.OWN / n) for n in ('正式保存する.py', '人工検査.py', '検査して停止する.py', 'コードを分類する.py', 'README.md')}
    reused = {str(F.PREVIOUS_PATH): F.PREVIOUS_SHA, str(F.CLASSIFIER_PATH): F.CLASSIFIER_SHA,
              str(F.C.LEGACY_PATH): F.C.LEGACY_SHA, str(F.C.ZIP_PATH): F.C.ZIP_SHA,
              str(F.ROOT / 'work/109再現コードの準備/ZIPを正式保存する.py'): 'cb263d54b70bbb6ca94d227736fce98748a623d014924b960660039d8f98eae2',
              str(F.ROOT / 'work/111正式保存への接続/人工検査.py'): 'ff8f68906fa8cabdc97a371095025bb7c2da95bc8fcc08365ba8def87bbcd78b',
              str(F.ROOT / 'work/113正式保存への接続/正式保存する.py'): '4ca4886e35c4f88c55f736e2f013af175df03ae3b548b58f2a361dff68d1f3b4'}
    protected = {'work/113正式保存への接続/検査_停止版/停止.json': '4154fbdf70d19b77881fa11a3e95d81156266820ef23f7840f1c35e67b8b9d9c', 'work/114順行と反転取得の連続比較/停止.json': '8e48f8c008a3bb6ab72ef9ec21f2b474dc403c79aa4a6b1a34f7b1d30d0ae729', 'work/114順行反転取得を執行する会計/Actor停止.json': '2178d1fbe7b980d7f507d6d9c99c6cdef1a8bde8702e4e4a69dbe97b687a9b93', 'work/113起動前の支持否定と利益保護の純演算/停止.json': '81f54d965ef8d81c65a7b58f4d376374b79c765e1ad4ada5cc6270159e4ed312', 'work/114順行と反転取得の純判定/停止.json': '3e721f461a0b737140771335bcee67c033f3413a911910cf256f1b453f8037d6', 'work/114入口判定を独立検算する/停止.json': '369eda8990de9faa430ca575b3cf6f114abf73bea1cfebf32522ceef166f1eb6', 'work/114利益保護を固定した入口比較の会計/P停止.json': 'f2c19983d428fd0bf6dbc49266751fb08498ed10bd754505bc6bed577ccd72dd', 'work/114利益保護を固定した入口比較の会計/会計停止.json': '1c746b02409398afcbd70f4aea6362ddb3da0a30e80fa0c7ca4aba0139a8373c'}
    for relative, digest in protected.items():
        path = F.ROOT / relative
        F.need(F.sha(path) == digest, '既停止の現物不変')
        reused[str(path)] = digest
        data = F.read({'path': str(path), 'sha256': digest}, {})
        for field in ('所有コードSHA256', '所有ファイルSHA256'):
            reused.update(data.get(field, {}))
    F.need(all(F.sha(Path(p)) == h for p, h in reused.items()), '再用/旧所有の停止SHA')
    output.mkdir()
    test = subprocess.run([sys.executable, '-X', 'utf8', str(F.OWN / '人工検査.py')], cwd=F.OWN,
                          capture_output=True, text=True, encoding='utf-8', timeout=120)
    log = output / '人工検査.txt'
    log.write_text(test.stdout + test.stderr, encoding='utf-8', newline='\n')
    F.need(test.returncode == 0, '114正式保存人工の全成功')
    F.need(all(F.sha(Path(p)) == h for p, h in {**owned, **reused}.items()), '新所有/旧停止コード前後不変')
    proof = output / '人工確認.json'
    F.write_json(proof, {'試行': 114, '成功': True, '市場前': True, '主人工': 7,
                        '器具': '停止111の手製70場/空約定840を114へ適応。仮Native/旧ZIP/CSV成功metadataだけ。',
                        '全Native70/Viewer840': True, '既存文書4点不変': True, 'Goコンパイラ別環境参照': True, '旧ZIP全SHAと選択entrySHA/CRC': True, '新ZIP集合SHA/CRC/安全名': True,
                        '元54認証再用と追加16区別': True, '共通P113と三注文群': True, '入口独立70/840と会計票結合': True,
                        '旧成果物/GoRoot/CSVの本文複写なし': True, '前後不変': True, 'ログ': F.ref(log),
                        '実市場/Raw/価格CSV/実CSV/11月09日本文': False})
    classifier = output / 'コード分類の停止.json'
    F.write_json(classifier, {'試行': 114, '成功': True, '市場前': True, '所有コードSHA256': {str(F.CLASSIFIER_PATH): F.CLASSIFIER_SHA}, '人工確認': F.ref(proof), '前後不変': True, '市場/Raw/CSV本文読取': False, '採用': False, '研究目標達成': False})
    record = {'コード分類停止': F.ref(classifier), '試行': 114, '成功': True, '市場前': True, '所有ファイルSHA256': owned, '再用ファイルSHA256': reused,
              '人工確認': F.ref(proof), '前後不変': True, '実市場/Raw/価格CSV/実CSV/11月09日本文': False,
              '研究目標達成': False, '採用': False}
    path = output / '停止.json'
    F.write_json(path, record)
    return {'成功': True, '停止': F.ref(path), 'コード分類停止': F.ref(classifier)}


def main() -> None:
    """機能: 未作成先へ114正式保存の市場前停止を生成する。

    引数: CLI output(str)は新規先。
    返り値: None。停止Refのみ表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(stop(args.output.resolve()), ensure_ascii=False))


if __name__ == '__main__':
    main()
