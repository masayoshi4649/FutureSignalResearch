# 175 経路と支持の純評価

2026-11-16。自然金融・候補結果を読まずにSourceと人工検査を作成した。173の金融・両中央値・F/A/N/Cを置換せず、既存の一群へ経路と支持を追加する。硬いDD金額の足切りは設けない。

## API

```python
from path175 import path_summary, candidate_key

risk = path_summary(group)
key = candidate_key(group, risk, 'DAY')  # 昇順
```

`group`は`metrics173`の一群（`trades`、`sessions.rows`、`decision`）。`sessions.rows`は0取得場を含み、scene/known_net/all_count/unknown_countを持つ。取得・未知数の一致、未知場のall_net=None、無取得場の0円を確認する。元groupを変更しない。

sceneが`YYYY-MM-DD_...`なら日付で整列する。別識別子の場合は`path_summary(group, scene_dates={scene_id: 'YYYY-MM-DD'})`を渡す。日付を判断できない場合は入力順を保持し、暦ブロックの広がりを未評価とする。金融・ファイル・時計サービスはこのSourceへ入力しない。

## 返り値

- `exact_path`：全対象場が金融既知の場合だけ全件の場末実現収支経路。未知があればNone。
- `known_contribution`：既知分だけの経路。未知を0円決済にした曲線ではなく、全件のDDや回復とは呼ばない。
- `complete_prefix`：最初の未知場より前の確定経路と場数。最初から未知なら0場。
- `complete_runs`：連続した確定区間。各区間を0円から始める局所経路で、未知をまたいで繋がない。
- `windows['5']`/`['10']`：全窓数・未知窓数・完全窓数を残し、完全窓だけの収支と場中央値、赤字数、取得0窓を評価する。重なる窓を独立試行とは数えない。
- `support`：対象場・実取得場・0取得場、取得/場、上位1/3場の取得集中、固定14日暦ブロックの支持分布。ブロックは1970-01-05（月）起算で、将来を追加しても既存の区切りが動かない。

`_path`のDDは場末実現収支であり、建玉保有中の時価DDではない。`sustained_nonnegative_scene=None`は「累計赤字が一度もない」又は「最後まで未回復」なので、`initial_minimum`/`below_initial_zero_scenes`と組み合わせる。`max_drawdown=None`は当該経路にDDがなく、`max_drawdown_amount=0`を併記する。0取引の経路が安定の最良にならないよう取得支持を先に判定する。

## 順位

`candidate_key(group, risk, field)`は昇順で、次の辞書順。

1. 取得あり。
2. 共同目標：既知決済が存在・既知差引>0・先着>=70%・参加目標。DAY/NIGHTだけは両中央値適合も共同条件。PRE/POSTの両中央値は必須ではない。
3. DAY/NIGHTの両中央値・先着目標・参加目標を個別にも残す。
4. 2以上の非重複暦ブロックへの広がり、ブロック参加率の最小値。
5. 金融未知比率。
6. 完全5/10場窓の赤字率・負の場中央値率・最悪窓の損失/既知利益。
7. DD/既知利益、未回復・水面下期間・初期損失/既知利益。
8. PRE/POSTを含む両中央値は診断的tie要素、率・頻度・既知差引。

DAY/NIGHTの参加目標は全対象場で取得。PRE/POSTは各全場の50%以上に取得し、平均0.5取得/場以上を比較軸とする。これを小帯ごとの硬い採用条件へ変更していない（`goal_is_hard_adoption_rule=False`）。同点IDの固定順は呼出側で処理する。金融未知群の経路比較は既知寄与の参考で、未知比率より後ろへ置く。

順位キーは比較専用で、収益0や完全窓なし等に`math.inf`を含み得る。JSON正本へはキー自体ではなく`risk`の有限/None指標を保存する。自然結果を見て順位の重み・閾値は調整していない。

## 人工検査

`人工検査.py`はDDの全ピーク底一覧3,280列、未来追加/前半prefix200列、独立窓計算11,400窓を照合。未知prefix/完全窓/完全区間、0取得場、全静観降格、固定暦ブロック、入力順の逆転、未知0円の拒否、PRE中央値を必須にしない境界、全件未知でもFラベルだけ確定した群の共同順位非適合も確認した。

```powershell
python -X utf8 work/175経路と支持の評価/人工検査.py
```

人工検査は既存173の純metrics Sourceを人工groupの構成に使う。自然入力は一切開いていない。Source変更はRootのF0aへ渡した最終SHAで停止し、`人工結果.json`へ記録した。
