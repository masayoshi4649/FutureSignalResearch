"""LOCAL参照の付加属性に対する指紋接続だけを訂正し、別F1bを保存する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00173_追加建てを禁止し両中央値で入口を再探索する'


def ref(path: Path) -> dict:
    """
    機能: ファイルの元byteを物理指紋へ変換する。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,
        'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 指紋の余分2属性で停止した接続を、条件を変えず人工確認後に再固定する。
    引数: なし。
    返り値: None。元F1とpartial DAYを保持し、新F1bだけを作る。
    """
    source=TRIAL/'検査/新screen前F1.json';result=json.loads(source.read_bytes())
    allowed={'work/173予備入口screen/pool173.py','work/173予備入口screen/人工検査.py',
        'work/173予備入口screen/人工確認.json'}
    changed=[];refs=[]
    for old in result['固定対象']:
        current=ref(ROOT/old['path'])
        if current!=old:
            assert old['path'] in allowed,old['path'];changed.append({'before':old,'after':current})
            backup=ROOT/'work/173予備入口screen/修正前Source'/Path(old['path']).name
            assert ref(backup)['sha256']==old['sha256']
        refs.append(current)
    assert len(changed)==3
    refs.append(ref(Path(__file__)))
    result['固定対象']=refs;result['元F1']=ref(source)
    result['接続訂正']={'UTC':datetime.now(timezone.utc).isoformat(),'変更':changed,
        '根因':'LOCAL出生参照へlayout/array_nameが付くため、3field物理指紋とのdict完全一致が停止。',
        '訂正':'物理3fieldを照合し、付加属性はdeclared/directions対だけ許可。未知属性・誤値・誤指紋を拒否する人工追加。',
        '不変':'売買条件、出生、金額、screen集計式、旧172統計は変更なし。旧partial DAYは残し、自然結果bへ新規再実行。',
        '先の実行':'OLD/NEW DAY全計算と代表別集計・旧164差分確認は完了、LOCAL入口で停止。新候補の選択/global1は未実行。'}
    target=TRIAL/'検査/新screen前F1b.json';assert not target.exists()
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'F1b':ref(target)},ensure_ascii=False))


if __name__=='__main__':main()
