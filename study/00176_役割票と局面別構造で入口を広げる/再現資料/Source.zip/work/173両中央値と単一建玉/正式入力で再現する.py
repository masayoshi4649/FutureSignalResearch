"""正式共有入力から173の固定四政策を再現し、出生・取得・監査・両中央値を照合する。"""
from pathlib import Path
from io import BytesIO
import argparse
import gzip
import json
import zipfile
import numpy as np
import 基盤173 as B
from 構成173 import compose

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / 'study/00173_追加建てを禁止し両中央値で入口を再探索する'


def old_context() -> object:
    """
    機能: feature cacheを読まず正式148を固定式で射影し、共有163へ接続する。
    引数: なし。
    返り値: GenericContextは旧73の当時特徴・取得時計・共有金融。
    """
    from 共通163 import data_module
    features = data_module().load_feature_from_formal()
    captures = B.P.read(ROOT / 'inputs/00148_全1分入口母集団/取得対応.json.gz')['rows']
    proof = B.P.read(ROOT / 'study/00172_デイを固定しナイト米国前後の複合入口を探索する/検査/共用入力の指紋.json')['旧73数値表']
    adapter = B.P.module(ROOT / 'work/163任意幅の数値化/arrays163.py', 'formal173_arrays')
    table = adapter.load_table(ROOT / 'inputs/00163_任意幅の共用価格索引/数値表', proof)
    return B.P.R168.BASE.GenericContext(features, table, captures)


def packed(context: object, value: tuple) -> dict:
    """
    機能: 数量再生の全取得属性とengine辞書を金融と独立に比較できる形にする。
    引数: context(GenericContext)、value(tuple)は固定政策再生。
    返り値: dictはcasesからengineまでの十属性。
    """
    selected, origin, wi, hi, tier, engine = value
    return {'cases': selected.cases.tolist(), 'sides': selected.sides.tolist(),
        'events': selected.events.tolist(), 'phases': selected.phases.tolist(),
        'origins': origin.tolist(), 'widths': wi.tolist(), 'horizons': hi.tolist(),
        'tiers': tier.tolist(), 'engine': engine}


def main() -> None:
    """
    機能: 正式ZIPと共有148/163/167だけから固定四政策を照合する。
    引数: --output(Path)は未作成のwork内確認先。
    返り値: None。固定再現の確認票を保存する。全探索や未見検証は行わない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(); output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'work') and not output.exists()
    source = TRIAL / '再現資料/出生と比較正本.zip'
    builder = B.P.module(ROOT / 'work/172ナイト入口探索/選定政策の出生.py', 'formal173_birth')
    checks = []
    with zipfile.ZipFile(source) as archive:
        def read(name: str) -> dict:
            """
            機能: 正式ZIP内の小正本を読む。
            引数: name(str)はmember相対パス。
            返り値: dictはJSON又はgzip JSON。
            """
            body = archive.read(name)
            return json.loads(gzip.decompress(body) if name.endswith('.gz') else body)
        fixed = read('work/173両中央値と単一建玉/旧73jointの固定選択.json')['選択']
        policies = [p for route in ('全期', '前48') for p in fixed[route]['candidates']]
        options = {r['birth_key']: r for p in policies for rules in p['options'].values() for r in rules}
        assert all(r['source'] != 'LOCAL173' for r in options.values())
        normalized = [{**r, 'key': r['birth_key'], 'entry_mode': r['mode']} for r in options.values()]
        for period, context in [('旧73', old_context()), ('追加7', B.load_context(True))]:
            base, _, _ = B.P.baseline(context)
            directions = builder.build(context.features, normalized)
            expected = read(f'work/173追加七場適用/{period}の全取得173.json.gz')['rows']
            expected = {r['id']: r for r in expected}
            member = f'work/173追加七場適用/{period}の純出生173.npz'
            with np.load(BytesIO(archive.read(member)), allow_pickle=False) as birth_source:
                for policy in policies:
                    birth, mw, fw, hi, component, conflict = compose(context.event_phases,
                        policy['options'], directions, base['technical'], base['tier'],
                        list(context.table.horizons), policy['fallback_by_band'])
                    arrays = {**{k: birth[k] for k in ('core', 'branches', 'technical', 'tier')},
                        'mw': mw, 'fw': fw, 'hi': hi, 'component': component, 'conflict': conflict}
                    for key, array in arrays.items():
                        assert np.array_equal(array, birth_source[policy['id'] + '__' + key]), (period, policy['id'], key)
                    value = B.replay(context, birth, mw, fw, hi, policy['fallback'])
                    record = expected[policy['id']]
                    assert packed(context, value) == {k: record[k] for k in packed(context, value)}, (period, policy['id'])
                    assert B.financial(context, value) == record['financial'], (period, policy['id'], 'financial')
                    checks.append({'期間': period, 'id': policy['id'], '取得': len(value[0].cases),
                        '純出生全属性全engine全金融同体': True})
    output.mkdir(parents=True)
    result = {'成功': True, '確認': checks, '正式正本SHA256': B.P.sha(source),
        '旧特徴': '正式148から固定151/161式で射影。作業cacheを読まない。',
        '注意': '全80は既使用。固定四政策の再現であり、全探索・未見性能・実mini注文成立の検査ではない。'}
    B.P.save(output / '再現確認.json', result)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
