"""旧固定入口の数量規則だけをglobal1に変更し、新条件下の出発点を測る。"""
from pathlib import Path
from datetime import datetime, timezone
import json
import numpy as np
import 基盤173 as B

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT/'study/00173_追加建てを禁止し両中央値で入口を再探索する'


def main() -> None:
    """
    機能: 171と172二案を純主/初参加補完の二モードで旧73だけglobal1再生する。
    引数: なし。新候補の探索前にSource・人工・対照を封印する。
    返り値: None。旧73の三対照×二モード報告・取得・監査を保存する。
    """
    paths = [Path(__file__), HERE/'基盤173.py', TRIAL/'条件.json',
        ROOT/'work/173追加なしの因果再生/engine173.py', ROOT/'work/173追加なしの因果再生/人工確認.json',
        ROOT/'work/173追加なしの評価/metrics173.py', ROOT/'work/173追加なしの評価/検証結果.json']
    refs = {p.relative_to(ROOT).as_posix(): B.P.sha(p) for p in paths}
    B.P.save(TRIAL/'検査/対照前F0b.json', {'成功':True,'UTC':datetime.now(timezone.utc).isoformat(),
        'Sourceと条件':refs,'対照':'171/B05_01/B05_11、それぞれ純主N0・旧初参加Tあり。旧73だけ。',
        '接続訂正':'初回F0後はセッションIDのintを純metricsが拒否し報告未生成。実session名のstrへ接続を訂正し、この別F0bを固定。入口や金融は変更しない。'})
    context = B.load_context()
    candidates = B.P.read(ROOT/'work/172ナイト入口探索/適用五組の固定.json')['candidates']
    choices = [{'id':'BASE171','PRE':None,'POST':None}]+[c for c in candidates if c['id'] in ('B05_01','B05_11')]
    rows, references = [], []
    for choice in choices:
        for fallback in (False,True):
            name = choice['id']+('_T' if fallback else '_N0')
            value = B.legacy(context,choice,fallback)
            selected,origins,wi,hi,tiers,result = value
            metric = B.financial(context,value)
            rows.append({'id':name,'candidate':choice,'fallback':fallback,'metrics':metric,
                'legacy_fields':B.P.describe(context,value,True)})
            references.append({'id':name,'cases':selected.cases.tolist(),'sides':selected.sides.tolist(),
                'events':selected.events.tolist(),'phases':selected.phases.tolist(),'origins':origins.tolist(),
                'widths':wi.tolist(),'horizons':hi.tolist(),'tiers':tiers.tolist(),'engine':result})
    B.P.save(HERE/'旧73対照.json.gz',{'成功':True,'rows':rows,'Sourceと条件':refs})
    B.P.save(HERE/'旧73対照取得.json.gz',{'成功':True,'rows':references})
    assert all(B.P.sha(ROOT/name)==digest for name,digest in refs.items())
    print(json.dumps({'成功':True,'対照数':len(rows),'各対照':[{'id':r['id'],
        '必須判定':r['metrics']['required_decision'],
        '各セッション区分':r['metrics']['session_groups_required']} for r in rows]},ensure_ascii=False))


if __name__=='__main__':
    main()
