"""全買売合計一建玉で、旧対照と新三帯入口を同じ金融時計へ接続する。"""
from pathlib import Path
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT/'work/172ナイト入口探索'))
import 再生172 as P
sys.path.insert(0, str(ROOT/'work/173追加なしの因果再生'))
import engine173
sys.path.insert(0, str(ROOT/'work/173追加なしの評価'))
import metrics173


def load_context(new: bool = False) -> object:
    """
    機能: 既存の当時特徴・取得対応と恒久金融を可変場Contextへ接続する。
    引数: new(bool)は追加7か旧73か。
    返り値: GenericContext。Rawの副本や新金融は生成しない。
    """
    if new:
        directory = ROOT/'inputs/00167_追加七場の入口と共用価格索引'
        features, captures, _ = P.R168.BASE.load_features(directory/'入口母集団')
        proof = P.read(directory/'生成の完了.json')['cache']
        adapter = P.module(ROOT/'work/166可変場の数値化/arrays166.py', 'arrays166_173')
        table = adapter.load_table(directory/'自然数値表', proof)
    else:
        from 共通163 import data_module
        data = data_module()
        features = data.load_feature_dataset()
        captures = P.read(ROOT/'inputs/00148_全1分入口母集団/取得対応.json.gz')['rows']
        directory = ROOT/'inputs/00163_任意幅の共用価格索引/数値表'
        proof = P.read(ROOT/'study/00172_デイを固定しナイト米国前後の複合入口を探索する/検査/共用入力の指紋.json')['旧73数値表']
        adapter = P.module(ROOT/'work/163任意幅の数値化/arrays163.py', 'arrays163_173')
        table = adapter.load_table(directory, proof)
    return P.R168.BASE.GenericContext(features, table, captures)


def captures(context: object) -> list:
    """
    機能: 取得/失効時計と、存在する時だけその理由をengineへ渡す。
    引数: context(GenericContext)。
    返り値: list[dict]は価格・金融を含まない取得descriptor。
    """
    rows = P.R168.capture_descriptors(context)
    for event, row in enumerate(rows):
        original = context.capture_rows[event]
        for key in ('reason', 'termination_reason'):
            if isinstance(original.get(key), str):
                row[key] = original[key]
    return rows


def replay(context: object, birth: dict, mw: np.ndarray, fw: np.ndarray, event_hi: np.ndarray,
           fallback: bool = True, descriptors: list | None = None) -> tuple:
    """
    機能: q0で固定した主方向・幅・期限をglobal1で再生する。
    引数: context(GenericContext)、birth(dict)、mw/fw/event_hi(np.ndarray[N])、
          fallback(bool)、descriptors(list|None)は共用取得時計。
    返り値: tupleはSelection/origin/幅/期限/tier/engine結果。
    """
    width_map = {int(w): i for i, w in enumerate(context.table.widths)}
    default_hi = context.table.horizons.index('H60')
    assert (mw > 0).all() and (fw > 0).all()
    assert np.isin(mw, context.table.widths).all() and np.isin(fw, context.table.widths).all()

    def exit_lookup(event: int, case: int, side: int, width: int) -> float | None:
        """
        機能: 主のevent期限又は初参加補完H60の既知決済時計を返す。
        引数: event/case/side/width(int)。
        返り値: floatは既知exit秒、Noneは未知。方向labelや金額は参照しない。
        """
        hi = int(event_hi[event]) if birth['core'][event] != 0 else default_hi
        wi = width_map[width]
        return float(context.arrays['exit_time'][case, side, wi, hi]) if context.arrays['known'][case, side, wi, hi] else None

    technical = birth['technical'] if fallback else np.zeros_like(birth['core'])
    tier = birth['tier'] if fallback else np.zeros_like(birth['core'])
    result = engine173.replay(context.event_keys, context.event_scenes,
        np.array([s['start'] for s in context.scenes]), np.array([s['end'] for s in context.scenes]),
        captures(context) if descriptors is None else descriptors,
        birth['core'], birth['branches'], technical, tier, mw, fw, 200, exit_lookup, capacity=1)
    rows = result['records']
    events = np.array([r['event'] for r in rows], np.int32)
    selected = P.Selection(np.array([r['case'] for r in rows], np.int32),
        np.array([r['side'] for r in rows], np.int8), events, context.event_phases[events], np.zeros(len(rows), bool))
    origin = np.array([r['origin'] for r in rows], np.int8)
    wi = np.array([width_map[r['width']] for r in rows], np.int8)
    hi = np.where(origin == 2, default_hi, event_hi[events]).astype(np.int8)
    tiers = np.array([r['tier'] for r in rows], np.int8)
    assert max((a['peak_global_reserved'] for a in result['audits']), default=0) <= 1
    return selected, origin, wi, hi, tiers, result


def financial(context: object, value: tuple, mask: np.ndarray | None = None,
              eligible: np.ndarray | None = None) -> dict:
    """
    機能: 建玉・全セッションの両中央値を未知の符号上下限とともに評価する。
    引数: context(GenericContext)、value(tuple)、mask/eligible(np.ndarray|None)。
    返り値: dictは純metrics部品の統計。0取引場もeligibleから落とさない。
    """
    selected, origins, wi, hi, _, _ = value
    if mask is None:
        mask = np.ones(len(selected.cases), bool)
    if eligible is None:
        eligible = np.ones(len(context.scenes), bool)
    cases, sides = selected.cases[mask], selected.sides[mask]
    key = (cases, sides, wi[mask], hi[mask])
    known = context.arrays['known'][key]
    raw_net = context.arrays['net'][key]
    net = [float(v) if bool(k) else None for v, k in zip(raw_net, known, strict=True)]
    scenes = [context.sessions[int(i)] for i in context.case_scene[cases]]
    eligible_map = {'DAY': [context.sessions[i] for i in np.flatnonzero(eligible & (context.hours[:,0] > 0))],
        'PRE': [context.sessions[i] for i in np.flatnonzero(eligible & (context.hours[:,1] > 0))],
        'POST': [context.sessions[i] for i in np.flatnonzero(eligible & (context.hours[:,2] > 0))]}
    hours = {name: float(context.hours[eligible, i].sum()) for i, name in enumerate(('DAY','PRE','POST'))}
    return metrics173.evaluate_metrics(net, known.tolist(), context.arrays['label'][key].tolist(),
        scenes, selected.phases[mask].tolist(), origins[mask].tolist(), eligible_map, hours)


def legacy(context: object, choice: dict, fallback: bool = True) -> tuple:
    """
    機能: 171又は172固定案の純出生を保ち、数量規則だけglobal1へ変更する。
    引数: context(GenericContext)、choice(dict)は172形式固定候補、fallback(bool)。
    返り値: tupleは新global1の実取得と監査。
    """
    base, _, _ = P.baseline(context)
    options = [choice[b] for b in ('PRE','POST') if choice.get(b) is not None]
    builder = P.module(ROOT/'work/172ナイト入口探索/選定政策の出生.py', 'birth173_legacy')
    directions = builder.build(context.features, options)
    birth, mw, fw, hi = P.route(context, base, choice, directions)
    return replay(context, birth, mw, fw, hi, fallback)
