"""追加建てを禁止し、建玉・セッション両中央値で入口を再探索する条件を固定する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / 'study/00173_追加建てを禁止し両中央値で入口を再探索する'


def ref(path: Path) -> dict:
    """
    機能: 固定対照・入力・Sourceの由来を指紋付きで記録する。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 最新ユーザーの両中央値・単一建玉・参加条件を新173へ採番する。
    引数: なし。
    返り値: None。条件と未実行READMEを保存し、171/172を変更しない。
    """
    assert not TRIAL.exists()
    assert max(int(p.name[:5]) for p in (ROOT/'study').iterdir() if p.is_dir() and p.name[:5].isdigit()) == 172
    setting = {'trial': 173, 'date': '2026-11-15', 'locked_utc': datetime.now(timezone.utc).isoformat(),
        'user_final': '費用後の建玉ごとの収支中央値とセッション別収支中央値の両方を黒字。保有中に追加建玉不可。可能な限り取引0セッションをなくし、合理的理由だけ例外。',
        'scope': 'NK225。Day/PRE/POSTを再探索。以前のDay固定は171/172対照に保持し、新173ではDayも改良可能。',
        'position': '全買売合計で保有mini1枚まで。反対売買・両建ても含め、保有中は新規禁止。未決予約中も別要求禁止。取消又は既知決済後の次q0から新規可。',
        'median_trade': '取得した建玉の費用後決済損益中央値。未到達の期限決済Nも含む。未知Cを0円取引として含めず既知値と全件不確定を分離する。',
        'median_session': '各Day及び各Nightの費用後合計収支中央値。0取引場は0円として全対象場へ含める。Day40とNight40を別々に判定、全80も参考表示する。',
        'phase_median': 'PRE/POSTはNight内の小帯。各40小帯の中央値と参加は診断表示し、小帯ごと黒字を硬い必須条件にしてNight接合を排除しない。',
        'unknown': 'C件数と未知セッションを保持。未知値を自由な値とした中央値上下限から符号確定/不確定を区別。既知中央値だけ正で全件の符号が不確定なら保留。',
        'participation': '各対象Day/Night最低1取得を目指す。全80の未参加を分母から落とさず、指標未公表/価格品質/複合条件不成立/未決取消等を記録。小帯ごとの強制発注はしない。',
        'frequency': '概ね1回/時は比較軸として維持。条件が成立する場の頻度差を許し、同一物理取得・枚数分割を水増ししない。保有中の禁止は機会損失として最適化しない。',
        'entry_quality': '同一幅F/(F+A)70%以上を目標、F/A/N/C・費用後利益損失・両中央値・場集中を別記する。多数の独立取引があると仮定しない。',
        'data': {'old': 'inputs/00148_全1分入口母集団 + inputs/00163_任意幅の共用価格索引',
                 'reference': 'inputs/00167_追加七場の入口と共用価格索引',
                 'clock': '既存全1分q0→別原行q1。NY09:30を夏冬変換しq0で帯分類。NY境界で強制決済しない。'},
        'widths': [125,150,175,200,225,250,300,350,400,500,750,1000],
        'horizons': ['H30','H60','H120','SESSION'],
        'entry_modes': ['ALL','EDGE'], 'orientation': ['NORMAL','REVERSE'],
        'library': '旧1460複合規則の幅別固定出生＋172新768の幅非依存純出生。移動平均/RSIだけに限定せず、方向・動力・構造・量・値幅を組み合わせる。',
        'research': '独立一枚screenは入口の予備候補化だけ。採否はglobal1の因果再生で行う。三帯単独とPRE/POST接合を分け、幅と期限ごとに枠解放・後続要求を再計算する。',
        'controls': ['171固定三帯をglobal1で再生', '172のB05_01をglobal1で再生', '172のB05_11をglobal1で再生'],
        'fallback': '純主N0と171既存L180S4/H200・H60の初参加補完を別対照。新補完は別出生/技術理由を記録し、無条件の定刻発注で参加率を作らない。',
        'selection': '旧73で探索。全期発見と前半のみ選択を分離し、追加7は旧73で固定した少数候補のみ参考適用する。全80は既使用、未見と呼ばない。',
        'cost': {'point_yen':100,'one_way_fee_yen':38.5,'one_way_additional_slippage_points':5},
        'exit': '共用IFD_FIRST、対称IFD又は未到達の期限BBO返済。未知で枠解除せず場末まで保持。同秒決済の原行不明は秒末まで保有。',
        'limits': '実mini板の約定・遅延・資金制約を検証していない。未知・指標可用性・特定日集中・既使用多数比較を保持する。',
        'outputs': 'README/設定と結果V8/再現Source/小正本/CSV。既存171/172と既存CSVは改変しない。',
        'sources': [ref(ROOT/'study/00171_三時間帯で順行と回復失敗の確認を切り替える/条件.json'),
                    ref(ROOT/'study/00172_デイを固定しナイト米国前後の複合入口を探索する/条件.json'),
                    ref(Path(__file__))]}
    TRIAL.mkdir(); (TRIAL/'検査').mkdir()
    (TRIAL/'条件.json').write_text(json.dumps(setting,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (TRIAL/'README.md').write_text('# 00173 追加建てを禁止し両中央値で入口を再探索する\n\n2026-11-15。最新ユーザー条件に従い、global1・建玉とセッションの両費用後中央値黒字・未参加を極力なくす入口を探索する。[条件](条件.json)を固定。現在は純部品の準備中で、新自然再生は未実行。旧171/172は対照として保持する。\n',encoding='utf-8')
    print(json.dumps({'成功':True,'条件':ref(TRIAL/'条件.json')},ensure_ascii=False))


if __name__ == '__main__':
    main()
