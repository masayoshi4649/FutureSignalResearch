"""RootF1後に当時の純特徴だけからLOCAL152出生を封印する。"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]


def module(path: Path, name: str) -> object:
    """
    機能: mainを呼ばずSourceを明示名で読込む。
    引数: path(Path)、name(str)。
    返り値: objectはmodule。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


def main() -> None:
    """
    機能: F1の指紋・GOを検査後、feature-only cacheから局所主出生を生成する。
    引数: --f1(Path)、--sha(str)は事前固定票。
    返り値: None。金融入力は読まずLOCAL出生と完了票を保存する。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--f1',type=Path,required=True);parser.add_argument('--sha',required=True)
    args=parser.parse_args();f1=args.f1.resolve();assert hashlib.sha256(f1.read_bytes()).hexdigest()==args.sha
    fixed=json.loads(f1.read_bytes());assert fixed['試行']==173 and fixed['GO'] is True
    lookup={r['path']:{'bytes':r['bytes'],'sha256':r['sha256']} for r in fixed['固定対象']}
    names=['work/161三時間帯入口のデータ/data161.py',
        'work/151過去場判別の評価/入口選択/cache/feature_only/features.npz',
        'work/151過去場判別の評価/入口選択/cache/feature_only/features_meta.json']
    inputs={}
    for name in names:
        path=ROOT/name
        current={'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
        assert lookup[name]==current;inputs[name]=current
    assert lookup[Path(__file__).relative_to(ROOT).as_posix()]['sha256']==hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    data=module(ROOT/names[0],'feature173_only');features=data.load_feature_dataset()
    pure={'buy_X':features.buy_X,'sell_X':features.sell_X,'columns':list(features.columns),
        'q0_meta':features.q0_meta,'scene_starts':np.array([s['start'] for s in features.scenes]),
        'phases':features.q0_timeband}
    folder=ROOT/'work/173局所技術の主入口';out=folder/'全出生';assert not out.exists()
    saver=module(folder/'出生を保存する.py','local173_save')
    manifest=saver.save_birth(pure,out,lookup,inputs)
    print(json.dumps({'成功':True,'候補数':len(manifest['ids']),'出生':manifest['birth'],
        '金融未入力':True,'F1SHA256':args.sha},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
