"""金融を受け取らず、三帯の単体・異技術ORと旧初参加補完を合成する。"""
import numpy as np


def compose(phases: np.ndarray, options: dict, directions: dict, technical: np.ndarray,
            tiers: np.ndarray, horizons: list, fallback: bool | dict = False) -> tuple:
    """
    機能: q0帯ごとの単独/2規則ORを全履歴方向から合成し、取得時の幅・期限を固定する。
    引数: phases(np.ndarray[N])、options(dict[str,list[dict]])は帯ごと最大2規則、
          directions(dict[str,np.ndarray])は純出生、technical/tiers(np.ndarray[N])、
          horizons(list[str])は公開期限順、fallback(bool|dict)は全体又は帯別の旧補完有無。
    返り値: tupleはbirth/mw/fw/event_hi/component/conflict。金融・取得は参照しない。
    """
    phases = np.asarray(phases)
    n = len(phases)
    assert np.isin(phases, (0,1,2)).all() and technical.shape == tiers.shape == (n,)
    core = np.zeros(n, np.int8)
    width = np.full(n, 200, np.int16)
    hi = np.full(n, horizons.index('H60'), np.int8)
    component = np.full(n, -1, np.int8)
    conflict = np.zeros(n, bool)
    for phase, name in enumerate(('DAY','PRE','POST')):
        rules = sorted(options.get(name, []), key=lambda r:r['id'])
        assert len(rules) <= 2
        if not rules:
            continue
        phase_rows = phases == phase
        for rule in rules:
            assert directions[rule['birth_key']].shape == (n,)
            assert rule['width'] > 0 and rule['horizon'] in horizons
            assert np.isin(directions[rule['birth_key']], (-1,0,1)).all()
        a = directions[rules[0]['birth_key']]
        b = directions[rules[1]['birth_key']] if len(rules)==2 else np.zeros(n,np.int8)
        oppose = (a!=0)&(b!=0)&(a!=b)
        proposed = np.where(oppose,0,np.where(a!=0,a,b)).astype(np.int8)
        chosen = np.where(proposed==0,-1,np.where(a!=0,0,1)).astype(np.int8)
        core[phase_rows] = proposed[phase_rows]
        component[phase_rows] = chosen[phase_rows]
        conflict[phase_rows] = oppose[phase_rows]
        for index, rule in enumerate(rules):
            mask = phase_rows & (chosen==index)
            width[mask] = rule['width']
            hi[mask] = horizons.index(rule['horizon'])
    fallback_rows=np.full(n,fallback,bool) if isinstance(fallback,bool) else \
        np.array([bool(fallback.get(('DAY','PRE','POST')[int(p)],False)) for p in phases])
    birth = {'core':core,'branches':np.where(core!=0,0,-1).astype(np.int8),
        'technical':np.where(fallback_rows & ~conflict,technical,0).astype(np.int8),
        'tier':np.where(fallback_rows & ~conflict,tiers,0).astype(np.int8)}
    assert np.array_equal(birth['branches']==-1,core==0)
    return birth,width,width.copy(),hi,component,conflict


def artificial() -> dict:
    """
    機能: 単独/ORの同方向優先・逆向き待機・帯/期限・旧補完抑制を人工で確認する。
    引数: なし。
    返り値: dictは自然金融不使用の検査結果。
    """
    n=9;phases=np.array([0]*3+[1]*3+[2]*3,np.int8)
    a=np.array([1,1,0,-1,-1,0,1,1,0],np.int8)
    b=np.array([1,-1,-1,-1,1,1,1,-1,-1],np.int8)
    common={'A':a,'B':b}
    first={'id':'A','birth_key':'A','width':150,'horizon':'H30'}
    second={'id':'B','birth_key':'B','width':300,'horizon':'H120'}
    options={p:[second,first] for p in ('DAY','PRE','POST')}
    t=np.ones(n,np.int8);tier=np.ones(n,np.int8);hs=['H30','H60','H120','SESSION']
    result=compose(phases,options,common,t,tier,hs,True)
    birth,mw,fw,hi,c,conflict=result
    assert birth['core'].tolist()==[1,0,-1,-1,0,1,1,0,-1]
    assert c.tolist()==[0,-1,1,0,-1,1,0,-1,1]
    assert birth['technical'].tolist()==[1,0,1,1,0,1,1,0,1]
    assert np.array_equal(mw,fw) and mw[c==0].tolist()==[150]*3 and mw[c==1].tolist()==[300]*3
    assert (hi[c==0]==0).all() and (hi[c==1]==2).all()
    mirror=compose(phases,options,{'A':-a,'B':-b},-t,tier,hs,True)
    for name in ('core','technical'):assert np.array_equal(mirror[0][name],-birth[name])
    assert np.array_equal(mirror[-1],conflict)
    for end in range(1,n+1):
        cut=compose(phases[:end],options,{k:v[:end] for k,v in common.items()},t[:end],tier[:end],hs,True)
        assert np.array_equal(cut[0]['core'],birth['core'][:end])
    only_day=compose(phases,options,common,t,tier,hs,{'DAY':True})
    assert not only_day[0]['technical'][phases!=0].any()
    return {'成功':True,'自然金融未入力':True,'OR同方向優先':True,'逆向き同時は補完も待機':True,
        '鏡像とprefix':True,'候補ID順固定':True}


if __name__=='__main__':
    import json
    print(json.dumps(artificial(),ensure_ascii=False))
