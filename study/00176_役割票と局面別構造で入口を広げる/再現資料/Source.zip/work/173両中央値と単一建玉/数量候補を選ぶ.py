"""global1の結果から支持・中央値・参加を別順位で選ぶ純部品。"""
from collections import Counter
import math

VERSION='173global1短表1'


def wilson(f: int, a: int) -> float:
    """
    機能: 先着率の参考Wilson95下限を順位だけへ使う。
    引数: f/a(int)は同幅先着数。
    返り値: floatは下限。到達なしは0。
    """
    n=f+a
    if not n:return 0.0
    p=f/n;z=1.959963984540054
    return (p+z*z/(2*n)-z*math.sqrt(p*(1-p)/n+z*z/(4*n*n)))/(1+z*z/n)


def support(group: dict) -> int:
    """
    機能: 少数の無損失群を過大に選ばないため数量再生後の支持層を返す。
    引数: group(dict)は純metricsの一帯又は実セッション群。
    返り値: intは通常2/疎1/支持なし0。中央値を支持へ混ぜない。
    """
    t=group['trades'];s=group['sessions'];fa=t['IFD_FIRSTFANC']
    if not t['all_count'] or t['unknown_count']>.2*t['all_count']:return 0
    resolved=group.get('resolved_scene_count',sum(r.get('F',0)+r.get('A',0)>0 for r in s.get('rows',[])))
    maximum=group.get('max_resolved_scene_count',0)
    share=maximum/fa['reached_count'] if fa['reached_count'] else 1
    if t['all_count']>=12 and fa['reached_count']>=8 and s['participating_count']>=6 and resolved>=6 and share<=.5:return 2
    if t['all_count']>=6 and fa['reached_count']>=4 and s['participating_count']>=3 and resolved>=3 and share<=.6:return 1
    return 0


def keys(group: dict) -> dict:
    """
    機能: 同じ入力群から率・両中央値・参加・疎補完の固定順位を作る。
    引数: group(dict)は一つの評価期間だけの指標。
    返り値: dict[str,tuple]は降順キー。
    """
    t=group['trades'];s=group['sessions'];fa=t['IFD_FIRSTFANC'];tm=t['net_median'];sm=s['net_median']
    low_t=-math.inf if tm['lower_unbounded'] or tm['lower'] is None else tm['lower']
    low_s=-math.inf if sm['lower_unbounded'] or sm['lower'] is None else sm['lower']
    positive=int(tm['strictly_positive_guaranteed'] and sm['strictly_positive_guaranteed'])
    unknown=-t['unknown_count'];count=t['all_count'];scene=s['participating_count'];w=wilson(fa['F'],fa['A'])
    return {'先着支持':(support(group),w,scene,positive,unknown,count),
        '両中央値':(positive,low_s,low_t,support(group),scene,unknown),
        '参加':(scene,positive,support(group),w,unknown,count),
        '疎補完':(support(group)>0,w,positive,scene,unknown,count)}


def choose(rows: list, period: str, field: str, maximum: int=8) -> list:
    """
    機能: 一期間だけを読み、4観点各最大2候補を重複除去して最大8へ絞る。
    引数: rows(list[dict])、period/field(str)は期間と帯/実セッション群、maximum(int)。
    返り値: list[dict]はid/policy/groupと選択理由。逆方向同時の優先を結果で変えない。
    """
    candidates=[]
    for row in rows:
        group=row['periods'][period][field]
        if not group['trades']['all_count']:continue
        candidates.append((row,group))
    chosen=[];seen=set();families=Counter()
    for perspective in ('先着支持','両中央値','参加','疎補完'):
        options=sorted(candidates,key=lambda pair:pair[0]['id'])
        options.sort(key=lambda pair:keys(pair[1])[perspective],reverse=True)
        taken=0
        for row,group in options:
            if row['id'] in seen:continue
            family=tuple(sorted(row['policy'].get('families',[row['policy'].get('family','固定対照')])))
            if families[family]>=3:continue
            if perspective=='先着支持' and not support(group):continue
            if perspective=='疎補完' and support(group)!=1:continue
            chosen.append({'id':row['id'],'policy':row['policy'],'selected_by':perspective,
                'period':period,'field':field,'support_tier':support(group)})
            seen.add(row['id']);families[family]+=1;taken+=1
            if taken==2 or len(chosen)==maximum:break
        if len(chosen)==maximum:break
    return chosen


def artificial() -> dict:
    """
    機能: 前48選択で別期間を読まず、上限・空取得・固定ID同点を人工確認する。
    引数: なし。
    返り値: dictはSourceが金融未入力である確認票。
    """
    def group(v: float) -> dict:
        """
        機能: 人工の中央値を持つ十分な支持の群を作る。
        引数: v(float)は人工利益水準。
        返り値: dictは純順位に必要な最小metrics。
        """
        m={'lower':v,'lower_unbounded':False,'strictly_positive_guaranteed':v>0}
        return {'resolved_scene_count':10,'max_resolved_scene_count':3,
            'trades':{'all_count':20,'unknown_count':0,'net_median':m,
            'IFD_FIRSTFANC':{'F':15,'A':5,'reached_count':20}},
            'sessions':{'participating_count':12,'net_median':m,'rows':[]}}
    rows=[{'id':f'X{i:02}','policy':{'family':str(i)},'periods':{'前48':{'DAY':group(i+1)},'全期':{'DAY':group(100-i)}}} for i in range(20)]
    first=choose(rows,'前48','DAY')
    for row in rows:row['periods']['全期']['DAY']=group(-999999)
    second=choose(list(reversed(rows)),'前48','DAY')
    assert first==second and len(first)<=8 and len({r['id'] for r in first})==len(first)
    assert choose([],'全期','DAY')==[]
    return {'成功':True,'自然金融未入力':True,'前48は別期間非参照':True,'入力順と上限':True}


if __name__=='__main__':
    import json
    print(json.dumps(artificial(),ensure_ascii=False))
