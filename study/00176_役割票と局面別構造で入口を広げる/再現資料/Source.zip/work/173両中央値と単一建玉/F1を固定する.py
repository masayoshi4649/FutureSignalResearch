"""自然screen前に、三帯候補・局所出生・数量再生・順位のSourceを束縛する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00173_追加建てを禁止し両中央値で入口を再探索する'


def ref(path: Path) -> dict:
    """
    機能: 元byteを変更せず物理指紋を記録する。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':digest}


def main() -> None:
    """
    機能: 既使用対照を区別して新自然候補の全screenとglobal1構成を事前固定する。
    引数: なし。
    返り値: None。173F1と研究手順追補を新規保存する。
    """
    target=TRIAL/'検査/新screen前F1.json';assert not target.exists()
    path=ROOT/'work/173予備入口screen/screen173.py'
    sys.path.insert(0,str(path.parent))
    spec=importlib.util.spec_from_file_location('screen173_source_only',path);screen=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=screen;spec.loader.exec_module(screen)
    paths=screen.required_paths()
    for folder in (HERE,ROOT/'work/173追加なしの因果再生',ROOT/'work/173追加なしの評価',
        ROOT/'work/173局所技術の主入口',ROOT/'work/173追加なしの候補計画'):
        paths.extend(p for p in folder.rglob('*') if p.is_file() and p.suffix in ('.py','.json','.md') and '__pycache__' not in p.parts)
    paths += [TRIAL/'条件.json',ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only/features.npz',
        ROOT/'work/161三時間帯入口のデータ/data161.py',ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json']
    procedure={'候補':{'固定1460と新768':427776,'LOCAL173_mode込み152':14592,'合計設定':442368,'3帯統計行':1327104},
        '局所新規':'旧166同式8＋2開始(120/180分)*2score(4/5)*3持続(0/2/5実分)*2逆RSI増分下限(-8/-12)*3量(.5/.75/1)*ALL/EDGE=144。M15一度公表後は局所禁止、gapは持続/EDGEだけreset。',
        '段階':'独立screen→全期/前48を別に最大36/帯→global1単独→4観点各2で最大8→異技術OR最大28/帯とDayの旧初参加T比較→PRE×POST最大64とN0/T→最大8Day×8Night。',
        '採用':'各Day/Nightで両中央値の下界>0、先着率>=70%、取得>=24・到達>=12・到達場>=6・既知net>0を主案支持とし、0参加場を最優先で減らす。旧73と前48をそれぞれの選択範囲だけで判定。',
        '未知':'中央値の符号上下限を残す。正確な金額を未知から推定せず、Cを0決済と扱わない。',
        '補完':'無条件発注なし。異技術ORは主同士で1要求、逆同時は旧Tも待機。旧Tは始めて取得するまで・45分以後、局所階層は171固定を保持。',
        '参考適用':'旧73で固定した全期/前半の各最大2、対照を含め最大6設定だけ追加7参考へ。追加7は既使用。'}
    p=TRIAL/'研究手順追補.json';p.write_text(json.dumps(procedure,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');paths.append(p)
    refs=[ref(p) for p in sorted(set(paths))]
    fixed={'試行':173,'GO':True,'固定UTC':datetime.now(timezone.utc).isoformat(),'固定対象':refs,
        '既閲覧':'171/172全使用結果、デイ集中診断、173の旧固定三案global1・旧73対照6本は閲覧済。新DAY全候補/LOCAL152自然出生/新候補global1は未実行。',
        '手順':procedure,'自然出生':'LOCALはこのF1のSource/当時入力から先に出生を封印してから金融screenへ渡す。'}
    target.write_text(json.dumps(fixed,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'F1':ref(target),'固定数':len(refs)},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
