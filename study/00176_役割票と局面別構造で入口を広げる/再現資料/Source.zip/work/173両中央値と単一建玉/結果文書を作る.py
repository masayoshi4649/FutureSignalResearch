"""173の固定比較を読み、未知境界と追加期悪化を残す正式文書を作る。"""
from pathlib import Path
import sys
import json
import 基盤173 as B

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / 'study/00173_追加建てを禁止し両中央値で入口を再探索する'


def money(value: float | None) -> str:
    """
    機能: 確定又は境界金額を日本語表で表示する。
    引数: value(float|None)。
    返り値: str。Noneは未確定と表示する。
    """
    return '未確定' if value is None else f'{value:+,.1f}'.removesuffix('.0')


def median(record: dict) -> str:
    """
    機能: 全件中央値の確定値又は上下界を表示する。
    引数: record(dict)はmetrics173の中央値辞書。
    返り値: str。既知分だけの中央値へ置換しない。
    """
    if record['all_median_exact']:
        return money(record['all_median'])
    low = '−∞' if record['lower_unbounded'] else money(record['lower'])
    high = '＋∞' if record['upper_unbounded'] else money(record['upper'])
    return f'{low}〜{high}'


def table(rows: list, period: str) -> str:
    """
    機能: Day/Nightを分離し両中央値・利益損失・参加を同じ表へ残す。
    引数: rows(list[dict])は固定四案、period(str)はfinancial/旧73/追加7。
    返り値: strはMarkdown表。
    """
    lines = ['|候補|区分|取得 F/A/N/C|先着率|既知利益円|既知損失円|既知差引円|建玉中央値円|場中央値円|取得場|',
             '|---|---|---|---:|---:|---:|---:|---|---|---:|']
    for row in rows:
        for band, group in row[period]['session_groups_required'].items():
            t, s = group['trades'], group['sessions']; fa = t['IFD_FIRSTFANC']
            rate = '未定義' if fa['first_f_rate_reached'] is None else f"{fa['first_f_rate_reached']:.2%}"
            fanc = '/'.join(str(fa[k]) for k in ('F', 'A', 'N', 'C'))
            lines.append(f"|{row['id']}|{band}|{t['all_count']}＝{fanc}|{rate}|{t['known_profit']:,.0f}|"
                f"{t['known_loss']:,.0f}|{money(t['known_net'])}|{median(t['net_median'])}|"
                f"{median(s['net_median'])}|{s['participating_count']}/{s['eligible_count']}|")
    return '\n'.join(lines)


def main() -> None:
    """
    機能: 固定正本からREADMEとV8複写・可読条件を正式173へ保存する。
    引数: なし。
    返り値: None。固定条件や他試行を変更しない。
    """
    data = B.P.read(ROOT / 'work/173追加七場適用/全80の両中央値173.json.gz')
    rows = data['rows']
    body = '''# 00173 追加建てを禁止し両中央値で入口を再探索する

2026-11-15開始、2026-11-16集計。**買売合計一建玉・予約中も新規禁止で、全80セッション取得、建玉とセッションの両費用後中央値が正になる参考候補を得た。** ただしDay/Night双方の先着70%は未達、追加7の夜間も悪化した。173の主案は全期・前48ともnullのまま、参考4案を保存する。

最新条件の全セッション参加と両中央値は満たすが、将来の安定収益や全ての日の黒字を示さない。全80は既使用。未知Cを0円に置換していない。全件中央値が未確定なら未知を任意の値にした上下界を示す。

## 全80既使用の固定参考比較

'''+table(rows, 'financial')+'''

F/A/N/Cは順側先着/逆側先着/未到達/観測不足。先着率はF/(F+A)、決済勝率とは異なる。期限決済Nも利益損失と中央値に含む。Cがある候補の利益・損失・差引は既知分で、全件確定収支ではない。0取引場は全Day/Nightの場中央値に0円で残す。今回の固定4案はいずれも0取引場なし。PRE/POSTの小帯ごとの取引は強制しない。

全期J016/J017は技術設定のspread差があるが、この全80では金融経路が同一。前48J026/J027はPOSTのH30/H60が異なる。同体結果を別の独立成功として数えない。

## 追加7だけの参考適用

'''+table(rows, '追加7')+'''

全期2案の追加4Nightは両中央値が赤字。前48J026の追加Nightは未知2件で両中央値の符号が保留、J027は建玉中央値上界も負。全80で中央値が正でも追加夜間の悪化を打ち消さない。追加期を見て4案を選び直していない。

## 何を変え、何が分かったか

旧171デイの好成績には同側保有中の追加302/341件が含まれていた。171入口をglobal1で初めから再生すると、旧37DayのT付きは75取得、先着71.43%、建玉中央値＋6,923円でも場中央値−1,231円で新条件に不適合。旧数量の独立1枚損益を単に足して今回の口座収支にはしない。

旧1460・172新768・新LOCAL152の計442,368設定、三帯1,327,104行を予備評価。新LOCALは長期指標が一度も公表されていない場で、5分のEMA/DI/MACD/RSI・実体・量を使う。独立一枚の予備表から全期と前48を別選択し、単独182・異技術OR等193・Night接合224・三帯接合96政策をglobal1で再生した。

参考の前48J026は全80Dayの主34件が24F/5A/5N・先着82.76%・既知＋455,382円に対し、初参加補完33件は12F/12A/9N・50%・−54,541円。主だけは17/40Day、補完が全場参加に寄与する。高率主と低率補完を混ぜた率低下を、主入口の無効性と同一視しない。Nightは85件すべて主で40/40場。

段階選択の診断では、全期Night接合に両中央値正＋70%以上の8案があるのに次段短表へ残らなかった。4観点の順位を個別に上げても共同条件が保持されるとは限らない。Dayの再生済み単独/ORには共同適合がなかった。[174](../00174_共同条件を残して単一建玉の入口を広げる/README.md)で候補の広さと共同条件の留保を別に改善する。

## 入力・費用・時計

[固定条件](条件.json)、[研究手順](研究手順追補.json)。旧73は正式148の当時特徴とq0/q1、恒久共有163の任意幅IFD_FIRST。追加7は正式167。全1分q0→別原行q1の取得代用で、実mini注文を検証したものではない。Day37＋Night36、追加Day3＋Night4。NY09:30を夏冬変換しq0で三帯を区分、帯境界で強制返済しない。

1要求mini1枚、全買売合計で保有＋未決予約一件まで。保有中は追加も反対側新規も禁止。未知決済は場末まで枠を占有し、既知同秒exitは秒末解放。旧Tは初取得まで・45分以後の複合技術成立時だけ。定刻の無条件発注で参加を作らない。

1pt100円、税込片道38.5円、追加片道5pt滑り、実BBO spreadも含む。往復手数料77円＋追加滑り1,000円を金融へ反映。幅125/150/175/200/225/250/300/350/400/500/750/1000pt、H30/H60/H120/SESSION。未知を解消できておらず、実板・遅延・資金制約も残る。

## 再現と閲覧

[設定表V8](設定と結果.md)、[条件と市場心理](条件と市場心理.md)、[再現手順](再現手順.md)、[保存索引](再現資料/保存索引.json)。旧173の固定条件・前48選択・全期発見を交換せず、旧171/172も改変しない。CSVは後続174の比較へ本試行の固定参考を併記する。xlsxは作成しない。
'''
    (TRIAL / 'README.md').write_text(body, encoding='utf-8')
    # ----------------------------------------
    template = (ROOT / 'docs/議論/手法と時間スケールの汎用表_版8.md').read_text(encoding='utf-8')
    template = template.replace('(../technical-analysis/', '(../../docs/technical-analysis/').replace('(../../scripts/', '(../../scripts/')
    template = template.replace('(手法と時間スケールの汎用表_版7.md)', '(../../docs/議論/手法と時間スケールの汎用表_版7.md)')
    template = template.replace('(逆行200ptより先に順行400ptへ届く入口.md)', '(../../docs/議論/逆行200ptより先に順行400ptへ届く入口.md)')
    template += '''\n\n## 173の設定IDと結果

原表V8を複写。使用セルは次表のIDを正本とし、それ以外はこの試行では未使用。複合成績を各指標単独の効果とはしない。

|設定ID|技法・尺度|閾値・役割|結果|
|---|---|---|---|
|173-OLD|旧1460、原行品質と1/5/15/30分、3分価格端や実分履歴|正逆・ALL/EDGE・12幅・4期限。候補ごとの全閾値は下記可読条件と小正本|予備427,776設定の旧/新共有枠のうち旧280,320|
|173-NEW|新768、原行/1/5/15/30分と5/10/20分履歴、NC15/30/60実分|NP/NR/NB/NF/NS/NC/NA/NX。固定geometry200、出口幅独立|予備147,456設定|
|173-LOCAL|I01/I03/I04/I08・P01・量、5分・1分、120/180経過分と0/2/5実分持続|旧8同式＋新144。score4/5、RSI逆増分8/12、量0.5/0.75/1。M15HistΔ一度公表後は局所禁止|152候補×12幅×4期限×2正逆。短表Dayに各1|
|173-G1|原行数量・C対称条件・EのIFD|買売合計保有＋pending<=1、未知場末保持、同秒秒末解放|単独182/OR等193/Night224/joint96|
|173-T|171固定複合初参加補完、原行/1/5/15/30分とL180S4|45分以後・初取得まで、200/H60。主競合時は補完も待機|全80前48J026 Day33件、12F12A9N、−54,541円|

結果は[README](README.md)のDay/Night両中央値と未知境界を参照。未使用・未検証・支持不足・指標未公表を区別する。
'''
    (TRIAL / '設定と結果.md').write_text(template, encoding='utf-8')
    # ----------------------------------------
    sys.path.insert(0, str(ROOT / 'work/162複合入口候補'))
    sys.path.insert(0, str(ROOT / 'work/172ナイト複合候補'))
    from rules162 import candidate_catalog as static
    from rules162_stateful import candidate_catalog as history
    from rules172_night import candidate_catalog as fresh
    catalog = {r['id']: r for r in static()+history()+fresh()}
    conditions = '''# 173の固定条件と市場心理

2026-11-16。一般的説明は既存教科書、以下は固定173の実装条件と研究仮説。心理の説明だけで収益性を証明しない。買売は符号反転した同一式。REVERSEは同じq0の実反対BBOで再評価し、1−pで推定しない。

同一帯に2技術が同方向ならID昇順の技術の幅・期限で一要求。反対方向なら待機し、そのq0の旧Tも抑止する。ALL/EDGE、幅、期限を一緒に条件へ含める。以下の閾値は元技術の向きで記載し、反転候補は元条件成立後に注文側を反転する。

'''
    seen = set()
    for row in rows:
        conditions += f"## {row['id']}\n\n"
        for band, rules in row['policy']['options'].items():
            conditions += f"- {band}："+'、'.join(f"{r['rule']} {r['mode']}/{r['orientation']} ±{r['width']}pt/{r['horizon']}" for r in rules)+'\n'
            seen.update(r['rule'] for r in rules)
        conditions += '\n'
    conditions += '''## 考え方と限界

MPは強いADXと上位MACDの方向を背景に短期動力が弱まらない状態を選ぶ。RG/EX/NRは帯端への偏りだけで逆張りせず、MACD/RSI増分・実体・量の回復を求める。TP/RM/NPは背景方向と取得位置又は過去の押戻し回復を組み合わせる。BO逆は突破をそのまま追うと不利だった群の再評価であり、突破失敗を直接観測した条件と称さない。前者は追随需要、後者は行き過ぎの解消という心理仮説だが、直接の注文主体や心理を観測した証拠ではない。

Tの早い取得が主の遅い好機より先に一枠を占有し得る。主と補完の支持・収支を分離し、過去の高率だけを参加補完全体へ当てはめない。再探索は174の別条件で行う。

## 固定規則の全閾値

派生factorの算出も正式Source.zipに保存。主要尺度はM5=5分、M15=15分、M30=30分。volumeはラージ原板の観測量で、mini実出来高とは同一視しない。
'''
    for identity in sorted(seen):
        rule = catalog[identity]
        conditions += f"\n### {identity}：{rule['description']}\n\n```json\n"+json.dumps(rule, ensure_ascii=False, indent=2)+'\n```\n'
    (TRIAL / '条件と市場心理.md').write_text(conditions, encoding='utf-8')
    print(json.dumps({'成功': True, '文書': 3, '参考': len(rows), '全閾値規則': len(seen)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
