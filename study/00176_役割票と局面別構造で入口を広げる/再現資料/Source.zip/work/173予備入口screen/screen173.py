"""RootのF1固定後にDAYだけを追加計算し、既存172夜間統計へ接続する。"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
import time

import numpy as np

from pool173 import ROOT, WIDTHS, HORIZONS, BANDS, PERIODS, FIELDS, physical, read, axis, checked, register_full

HERE = Path(__file__).resolve().parent
BASE_SOURCE = ROOT / 'work/172ナイト基礎診断/基礎診断.py'
SPECS = {
    'OLD1460': {'count': 1460, 'proof': 'work/163入口と任意幅/全出生/全出生の確認.json',
        'birth': 'work/163入口と任意幅/全出生/出生{width}.npz', 'layout': 'width_dependent',
        'night_proof': 'work/172ナイト基礎診断/1460再集計の完了.json', 'proof_files': '結果',
        'night_axis': 'work/172ナイト基礎診断/1460純新規のナイト診断軸.json',
        'night_metrics': 'work/172ナイト基礎診断/1460純新規のナイト診断配列.npz'},
    'NEW768': {'count': 768, 'proof': 'work/172ナイト複合候補/全出生/全出生の確認.json',
        'birth': 'work/172ナイト複合候補/全出生/新768の出生.npz', 'layout': 'shared',
        'night_proof': 'work/172ナイト複合候補/金融比較/完了.json', 'proof_files': 'files',
        'night_axis': 'work/172ナイト複合候補/金融比較/新768のナイト診断軸.json',
        'night_metrics': 'work/172ナイト複合候補/金融比較/新768のナイト診断配列.npz'}}
REUSE_SHA = {
    'work/172ナイト基礎診断/1460純新規のナイト診断軸.json': 'edcdc2fff650e50978d145df25ec9c8ac2e473fab4708d3542f7f620a71c971e',
    'work/172ナイト基礎診断/1460純新規のナイト診断配列.npz': '63b1a8ad27fe5eccc49a3bd804a083a96660292b8c630458dcced0ba16c49820',
    'work/172ナイト複合候補/金融比較/新768のナイト診断軸.json': 'd2b0db580e68b1990ca17c65c06d8db662003fe3cf18cab7c5f997b10474035b',
    'work/172ナイト複合候補/金融比較/新768のナイト診断配列.npz': 'bc7201cd075fc82366c640524a734e6eef0ae262d7b8f38d1f8d71cb322d1245'}


def module(path: Path, name: str) -> object:
    """
    機能: 固定Sourceを自動実行なしで読み込む。
    引数: path(Path)はSource、name(str)はmodule識別名。
    返り値: objectは読み込んだモジュール。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


def save(path: Path, value: dict) -> None:
    """
    機能: 標準JSONを日本語UTF-8で保存する。
    引数: path(Path)は出力先、value(dict)は保存値。
    返り値: None。
    """
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def required_paths() -> list[Path]:
    """
    機能: RootがF1で固定するSource・出生・金融・再利用統計の全パスを返す。
    引数: なし。ファイル内容や自然数値を読まない。
    返り値: list[Path]は重複のない固定対象。
    """
    paths = [HERE / n for n in ('screen173.py', 'pool173.py', '独立検算.py', '人工検査.py', '人工確認.json', 'README.md')]
    paths += [BASE_SOURCE,
        ROOT / 'inputs/00148_全1分入口母集団/固定取得入力.json.gz',
        ROOT / 'inputs/00148_全1分入口母集団/取得対応.json.gz',
        ROOT / 'inputs/00163_任意幅の共用価格索引/数値表/任意幅識別.json.gz',
        ROOT / 'inputs/00163_任意幅の共用価格索引/数値表/任意幅配列.npz',
        ROOT / 'work/151過去場判別の評価/入口選択/cache/feature_only/features_meta.json',
        ROOT / 'work/164先着確定と反転比較/比較/統計軸.json',
        ROOT / 'work/164先着確定と反転比較/比較/最初到達の統計配列.npz']
    for spec in SPECS.values():
        paths += [ROOT / spec[k] for k in ('proof', 'night_proof', 'night_axis', 'night_metrics')]
        paths += [ROOT / spec['birth'].format(width=w) for w in WIDTHS] if spec['layout'] == 'width_dependent' else [ROOT / spec['birth']]
    return list(dict.fromkeys(paths))


def verify_f1(path: Path, digest: str) -> tuple[dict, dict]:
    """
    機能: 明示されたRoot F1と全必要Source/入力の物理指紋を確認する。
    引数: path(Path)はRoot固定票、digest(str)は事前提示されたF1 SHA256。
    返り値: tuple[dict,dict]はF1参照と固定対象参照。未固定なら自然読込へ進まない。
    """
    ref = physical(path)
    assert ref['sha256'] == digest and len(digest) == 64
    fixed = read(path)
    rows = fixed['固定対象']
    assert isinstance(rows, list)
    lookup = {str(r['path']).replace('\\', '/'): {'path': str(r['path']).replace('\\', '/'),
        'bytes': r['bytes'], 'sha256': r['sha256']} for r in rows}
    references = {}
    for required in required_paths():
        current = physical(required)
        assert current['path'] in lookup and current == lookup[current['path']], current['path']
        references[current['path']] = current
    return ref, references


def select_physical(directions: np.ndarray, event_cases: np.ndarray, phases: np.ndarray) -> tuple:
    """
    機能: 全場で同一caseの最初の成立q0を一度だけ選び、その後に帯を保持する。
    引数: directions(np.ndarray[N])は固定方向、event_cases/phases(np.ndarray[N])は物理caseとq0帯。
    返り値: tuple[np.ndarray]はcase/実側/最初q0帯/event。DAY分解前に重複排除する。
    """
    assert directions.shape == event_cases.shape == phases.shape
    assert np.isin(directions, (-1, 0, 1)).all()
    events = np.flatnonzero((directions != 0) & (event_cases >= 0))
    if len(events):
        indices = np.unique(event_cases[events], return_index=True)[1]
        events = events[np.sort(indices)]
    return event_cases[events], np.where(directions[events] == 1, 0, 1).astype(np.int8), phases[events], events


def day_cube(context: dict, cases: np.ndarray, sides: np.ndarray, phases: np.ndarray, wi: int, phase: int = 0) -> np.ndarray:
    """
    機能: 全場で正準化した取得の一帯を4期限・3期間・既存16指標へ集計する。
    引数: context(dict)は固定金融/場時計、cases/sides/phases(np.ndarray)は正準取得、wi(int)は幅位置、phase(int)は既定DAY0又はPRE1/POST2。
    返り値: np.ndarray[4,3,16]はIFD_FIRST・既知net5の指定帯統計。
    """
    arrays = context['arrays']
    his = np.array([context['meta']['horizons'].index(h) for h in HORIZONS])
    key = (cases[:, None], sides[:, None], wi, his[None, :])
    strict, direction, known = [arrays[name][key] for name in ('label', 'direction', 'known')]
    labels = np.where(known & (direction != 0), direction, np.where(strict == 0, 0, 2)).astype(np.int8)
    assert np.array_equal(labels == 2, ~known)
    money = arrays['net5'][key]
    scene = arrays['session_index'][cases]
    assert phase in (0, 1, 2)
    hours = context['hours'][:, phase]
    output = np.full((4, 3, 16), np.nan)
    for pi, period in enumerate(PERIODS):
        eligible = hours > 0
        if pi == 1:
            eligible &= np.arange(len(hours)) < 48
        elif pi == 2:
            eligible &= np.arange(len(hours)) >= 48
        rows = (phases == phase) & eligible[scene]
        count = int(rows.sum())
        l, k, m = labels[rows], known[rows], money[rows]
        f, a, n, c = [(l == code).sum(axis=0) for code in (1, -1, 0, 2)]
        profit = np.where(k, np.maximum(m, 0), 0).sum(axis=0)
        loss = np.where(k, np.maximum(-m, 0), 0).sum(axis=0)
        by_scene = np.bincount(scene[rows], minlength=len(hours))
        values = {'count': count, 'F': f, 'A': a, 'N': n, 'C': c,
            'rate': np.divide(f, f+a, out=np.full(4, np.nan), where=f+a != 0),
            'profit': profit, 'loss': loss, 'net': profit-loss,
            'pf': np.divide(profit, loss, out=np.full(4, np.nan), where=loss != 0),
            'known': k.sum(axis=0), 'unknown': count-k.sum(axis=0),
            'scenes': np.count_nonzero(by_scene), 'eligible_scenes': int(eligible.sum()),
            'per_hour': count / float(hours[eligible].sum()) if eligible.any() else np.nan,
            'max_scene_share': int(by_scene.max())/count if count else np.nan}
        for fi, field in enumerate(FIELDS):
            output[:, pi, fi] = values[field]
    return output


def birth_metadata(spec: dict, proof: dict) -> dict:
    """
    機能: direction解決器が幅別又は共通出生へ到達できる物理参照を構成する。
    引数: spec/proof(dict)は固定Source仕様と出生確認票。
    返り値: dictはlayout/files/proof/array_modes/q0_countを持つ出生参照。
    """
    paths = {str(w): ROOT / spec['birth'].format(width=w) for w in WIDTHS} if spec['layout'] == 'width_dependent' else {'shared': ROOT / spec['birth']}
    references = {name: physical(path) for name, path in paths.items()}
    for ref in references.values():
        assert {k: ref[k] for k in ('bytes', 'sha256')} == proof['files'][Path(ref['path']).name]
    return {'layout': spec['layout'], 'files': references, 'proof': physical(ROOT / spec['proof']),
        'array_modes': ['ALL', 'EDGE'], 'q0_count': 35339,
        'geometry': '元の各幅ごとの出生を維持' if spec['layout'] == 'width_dependent' else 'target_points200共通出生を全出口幅に共用'}


def screen_source(context: dict, source: str, spec: dict, output: Path) -> dict:
    """
    機能: 固定OLD/NEW出生のDAYだけを計算し、PRE/POSTの再用参照を登録する。
    引数: context(dict)は共有入力、source(str)はSource名、spec(dict)は仕様、output(Path)は出力先。
    返り値: dictはpool登録entry。新しい方向や閾値を生成しない。
    """
    proof = read(ROOT / spec['proof'])
    assert proof['成功'] and proof['金融未入力']
    ids = proof['規則順']
    assert len(ids) == spec['count'] == len(set(ids))
    birth = birth_metadata(spec, proof)
    feature_meta = ROOT / 'work/151過去場判別の評価/入口選択/cache/feature_only/features_meta.json'
    if source == 'NEW768':
        assert proof['入口は出口幅非依存']
        assert proof['features']['cache161']['meta']['sha256'] == physical(feature_meta)['sha256']
        ordered = read(feature_meta)['q0_meta']
        keys = ('event_id', 'session', 'contract', 'session_index', 'q0_time', 'q0_index', 'q0_line')
        canonical = json.dumps([[r[k] for k in keys] for r in ordered], ensure_ascii=False,
            separators=(',', ':'), allow_nan=False).encode('utf-8')
        assert hashlib.sha256(canonical).hexdigest() == proof['q0']['ordered_keys_sha256']
        del ordered
    else:
        assert proof['特徴入力']['cache161']['meta']['sha256'] == physical(feature_meta)['sha256']
    night_proof = read(ROOT / spec['night_proof'])
    assert night_proof['成功']
    for name in ('night_axis', 'night_metrics'):
        ref = physical(ROOT / spec[name])
        assert ref['sha256'] == REUSE_SHA[ref['path']]
        assert {k: ref[k] for k in ('bytes', 'sha256')} == night_proof[spec['proof_files']][Path(ref['path']).name]
    night_axis = read(ROOT / spec['night_axis'])
    assert night_axis['規則順'] == ids and night_axis['指標'] == list(FIELDS)
    metrics = np.full((len(ids), 2, 2, 12, 4, 3, 16), np.nan)
    begin = time.monotonic()
    for wj, width in enumerate(WIDTHS):
        reference = birth['files'][str(width) if spec['layout'] == 'width_dependent' else 'shared']
        with np.load(ROOT / reference['path'], allow_pickle=False) as sealed:
            matrices = {mode: sealed[mode].copy() for mode in ('ALL', 'EDGE')}
            if 'phases' in sealed.files:
                assert np.array_equal(sealed['phases'], context['event_phases'])
        for mi, mode in enumerate(('ALL', 'EDGE')):
            assert matrices[mode].shape == (len(ids), len(context['event_cases']))
            for ri, directions in enumerate(matrices[mode]):
                cases, sides, phases, _ = select_physical(directions, context['event_cases'], context['event_phases'])
                for oi in (0, 1):
                    metrics[ri, mi, oi, wj] = day_cube(context, cases, sides if oi == 0 else 1-sides,
                        phases, context['meta']['widths'].index(width))
        print(json.dumps({'Source': source, 'DAY追加済み幅': width, '経過秒': round(time.monotonic()-begin, 1)}, ensure_ascii=False), flush=True)
    array_path, axis_path = output / (source + '_DAY.npz'), output / (source + '_DAY軸.json')
    np.savez_compressed(array_path, metrics=metrics)
    metadata = axis(ids)
    metadata.update({'成功': True, '帯': ['DAY'], 'shape': list(metrics.shape), 'source': source,
        '出生': birth, '物理取得': '全場で同case最初q0を正準化してからDAY分解。正逆は同じq0/caseを共用。',
        '数量': '独立一枚の予備screen。global1口座再生・中央値達成とは呼ばない。'})
    save(axis_path, metadata)
    return {'source': source, 'ids': ids, 'families': [name[:2] for name in ids], 'layout': 'day_plus_reused_night',
        'day_metrics': physical(array_path), 'day_axis': physical(axis_path),
        'night_metrics': physical(ROOT / spec['night_metrics']), 'night_axis': physical(ROOT / spec['night_axis']),
        'night_proof': physical(ROOT / spec['night_proof']), 'birth': birth}


def screen_local(context: dict, manifest_path: Path, f1_path: Path, hours: list, output: Path) -> tuple:
    """
    機能: 辞書でmode適用済みのLOCAL出生をDECLARED一軸で三帯集計する。
    引数: context(dict)は共有金融、manifest_path(Path)は金融未入力出生の生成票、f1_path(Path)はRoot固定票、hours(list[3,3])は帯別期間時間、output(Path)は未作成先。
    返り値: tuple[dict,dict]はfull型pool entryと代表8規則の別集計確認。ALL/EDGEを再適用しない。
    """
    manifest = read(manifest_path)
    assert manifest['source'] == 'LOCAL173'
    proof = read(checked(manifest['proof']))
    assert proof['source'] == 'LOCAL173' and proof['layout'] == 'declared' and proof['candidate_count'] == 152
    assert proof['birth'] == manifest['birth']
    fixed = {r['path'].replace('\\', '/'): {**r, 'path': r['path'].replace('\\', '/')} for r in read(f1_path)['固定対象']}
    for name, expected in proof['source_fingerprints'].items():
        assert name in fixed
        assert all(expected[key] == fixed[name][key] for key in ('bytes', 'sha256')), name
        assert physical(ROOT / name) == {k: fixed[name][k] for k in ('path', 'bytes', 'sha256')}
    for name, expected in proof['input_fingerprints'].items():
        assert name in fixed and all(expected[key] == fixed[name][key] for key in ('bytes', 'sha256')), name
        assert physical(ROOT / name) == {k: fixed[name][k] for k in ('path', 'bytes', 'sha256')}
    catalog_names = [name for name in proof['source_fingerprints'] if name.endswith('/SourceCatalog.json')]
    assert len(catalog_names) == 1
    catalog_path = ROOT / catalog_names[0]
    assert physical(catalog_path)['sha256'] == proof['catalog_sha256']
    rules = read(catalog_path)['rules']
    assert manifest['ids'] == [r['id'] for r in rules]
    assert manifest['families'] == [r['family'] for r in rules]
    assert manifest['declared_modes'] == [r['mode'] for r in rules]
    with np.load(checked(manifest['birth']), allow_pickle=False) as sealed:
        assert set(sealed.files) == {'directions', 'phases'}
        directions, phases = sealed['directions'], sealed['phases']
    assert directions.shape == (152, len(context['event_cases'])) and directions.dtype == np.int8
    assert np.array_equal(phases, context['event_phases']) and np.isin(directions, (-1, 0, 1)).all()
    metrics = np.full((152, 1, 2, 12, 4, 3, 3, 16), np.nan)
    independent = module(HERE / '独立検算.py', 'screen173_local_independent')
    representatives = np.linspace(0, 151, 8, dtype=int).tolist()
    verified = 0
    for ri, direction in enumerate(directions):
        cases, sides, first_phases, _ = select_physical(direction, context['event_cases'], phases)
        independent_selected = independent.physical_list(context, direction) if ri in representatives else None
        for oi in (0, 1):
            oriented = sides if oi == 0 else 1-sides
            direct = [(case, side if oi == 0 else 1-side, phase) for case, side, phase in independent_selected] if independent_selected is not None else None
            for wj, width in enumerate(WIDTHS):
                for bi in range(3):
                    cube = day_cube(context, cases, oriented, first_phases, context['meta']['widths'].index(width), bi)
                    metrics[ri, 0, oi, wj, :, bi] = cube
                    if direct is not None:
                        for hi, horizon in enumerate(HORIZONS):
                            for pi in range(3):
                                expected = independent.direct_row(context, direct, width, horizon, pi, bi)
                                assert np.allclose(cube[hi, pi], expected, equal_nan=True, rtol=1e-12, atol=1e-12)
                                verified += 16
        if (ri+1) % 16 == 0:
            print(json.dumps({'Source': 'LOCAL173', '三帯比較済み': ri+1, '全規則': 152}, ensure_ascii=False), flush=True)
    birth = {'layout': 'declared', 'array_name': 'directions', 'files': {'shared': manifest['birth']},
        'proof': manifest['proof'], 'q0_count': directions.shape[1], 'array_modes': ['DECLARED'],
        'catalog': physical(catalog_path)}
    result = register_full(output, 'LOCAL173', manifest['ids'], manifest['families'], metrics, birth, hours,
        {'出生manifest': physical(manifest_path), 'SourceはRootF1一致': True},
        modes=['DECLARED'], declared_modes=manifest['declared_modes'])
    check = {'成功': True, 'source': 'LOCAL173', '代表規則': [manifest['ids'][i] for i in representatives],
        '三帯別一覧16指標照合セル': verified, 'mode再評価なし': True}
    return result['blocks'][0], check


def run(f1_path: Path, f1_sha: str, output: Path, local_manifest: Path | None = None) -> None:
    """
    機能: Root F1を確認後、DAY追加・代表独立検算・三帯参照poolを新規保存する。
    引数: f1_path(Path)/f1_sha(str)はRoot固定票、output(Path)は未作成work先、local_manifest(Path|None)は後生成の金融未入力LOCAL出生票。
    返り値: None。GO後にだけ明示呼出し、旧Sourceと旧統計を変更しない。
    """
    assert output.resolve().is_relative_to(ROOT / 'work') and not output.exists()
    f1_ref, references = verify_f1(f1_path, f1_sha)
    base = module(BASE_SOURCE, 'baseline172_inputs_for173')
    context = base.load(False)
    assert len(context['scenes']) == 73 and len(context['event_cases']) == 35339
    assert all(base.INPUTS[name] == {k: references[name][k] for k in ('bytes', 'sha256')} for name in base.INPUTS)
    output.mkdir(parents=True)
    entries = [screen_source(context, source, spec, output) for source, spec in SPECS.items()]
    hours, eligible_scenes = [], []
    for bi in range(3):
        hours.append([]); eligible_scenes.append([])
        for pi in range(3):
            eligible = context['hours'][:, bi] > 0
            if pi == 1:
                eligible &= np.arange(73) < 48
            elif pi == 2:
                eligible &= np.arange(73) >= 48
            hours[-1].append(float(context['hours'][eligible, bi].sum()))
            eligible_scenes[-1].append(int(eligible.sum()))
    independent = module(HERE / '独立検算.py', 'screen173_independent')
    check = independent.verify(context, entries)
    if local_manifest is not None:
        local_entry, local_check = screen_local(context, local_manifest, f1_path, hours, output / 'LOCAL173')
        entries.append(local_entry)
        check['LOCAL173'] = local_check
    pool = {'成功': True, '版': '173予備三帯1', '帯': list(BANDS), '期間': list(PERIODS),
        'eligible_hours': hours, 'eligible_scenes': eligible_scenes, 'blocks': entries, 'F1': f1_ref,
        '注意': 'OLD/NEWのPRE/POSTは172統計の指紋付き参照。DAYと任意指定LOCAL三帯だけ新集計。追加7は含まない。'}
    save(output / 'pool.json', pool)
    save(output / '独立検算.json', check)
    for name, expected in references.items():
        assert physical(ROOT / name) == expected, name
    assert physical(f1_path) == f1_ref
    save(output / '完了.json', {'成功': True, 'F1': f1_ref, 'Sourceと入力': references,
        '新自然計算範囲': 'OLD1460/NEW768のDAYのみ。PRE/POST再計算なし。', '独立検査': check,
        'files': {path.name: physical(path) for path in output.iterdir() if path.is_file()}})
    print(json.dumps({'成功': True, '出力': output.relative_to(ROOT).as_posix(), '三帯pool': True}, ensure_ascii=False), flush=True)


def main() -> None:
    """
    機能: F1付き明示実行だけを受け付け、引数なしで自然計算を開始しない。
    引数: --f1(Path)、--f1-sha256(str)、--output(Path)、--execute(bool)はRoot GO後の指定。
    返り値: None。
    """
    parser = argparse.ArgumentParser(description='Root F1とGO後のDAY予備screen')
    parser.add_argument('--f1', type=Path, required=True)
    parser.add_argument('--f1-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--execute', action='store_true', required=True)
    parser.add_argument('--local-manifest', type=Path)
    args = parser.parse_args()
    run(args.f1.resolve(), args.f1_sha256, args.output.resolve(), args.local_manifest.resolve() if args.local_manifest else None)


if __name__ == '__main__':
    main()
