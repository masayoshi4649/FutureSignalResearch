"""DAY追加表と指紋固定の172夜間表を三帯の共通軸へ接続する。"""
from pathlib import Path
import hashlib
import json

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
WIDTHS = (125, 150, 175, 200, 225, 250, 300, 350, 400, 500, 750, 1000)
HORIZONS = ('H30', 'H60', 'H120', 'SESSION')
BANDS = ('DAY', 'PRE', 'POST')
PERIODS = ('全期', '前48場', '後25場')
FIELDS = ('count', 'F', 'A', 'N', 'C', 'rate', 'profit', 'loss', 'net', 'pf',
          'known', 'unknown', 'scenes', 'eligible_scenes', 'per_hour', 'max_scene_share')


def physical(path: Path) -> dict:
    """
    機能: 参照するファイルの物理指紋を返す。
    引数: path(Path)はリポジトリ内ファイル。
    返り値: dictはpath/bytes/sha256。
    """
    path = path.resolve()
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest}


def checked(ref: dict) -> Path:
    """
    機能: 期待する物理指紋と一致する参照だけを許す。
    引数: ref(dict)はpath/bytes/sha256を持つ保存参照。
    返り値: Pathは一致済みの絶対パス。
    """
    path = ROOT / ref['path']
    assert physical(path) == ref, ref['path']
    return path


def read(path: Path) -> dict:
    """
    機能: UTF-8の小型JSONを読む。
    引数: path(Path)はJSONパス。
    返り値: dictは解析値。
    """
    return json.loads(path.read_text(encoding='utf-8-sig'))


def axis(ids: list[str], modes: list[str] | None = None) -> dict:
    """
    機能: Source別の規則順と共通三帯統計軸を構成する。
    引数: ids(list[str])は重複のない固定規則順、modes(list[str]|None)は既定ALL/EDGE又はDECLARED等。
    返り値: dictは規則/発火/方向/幅/期限/帯/期間/指標の軸。
    """
    assert len(ids) == len(set(ids))
    modes = ['ALL', 'EDGE'] if modes is None else modes
    assert modes and len(modes) == len(set(modes))
    return {'規則順': ids, '発火方式': modes, '方向': ['NORMAL', 'REVERSE'],
        '幅': list(WIDTHS), '時計': list(HORIZONS), '帯': list(BANDS),
        '期間': list(PERIODS), '指標': list(FIELDS), '主label': 'IFD_FIRST',
        'shape': [len(ids), len(modes), 2, 12, 4, 3, 3, 16]}


def validate_axis(value: dict, ids: list[str], full: bool) -> None:
    """
    機能: DAY単独又は三帯の16指標軸を検査する。
    引数: value(dict)は保存軸、ids(list[str])は規則順、full(bool)は三帯指定。
    返り値: None。
    """
    expected = axis(ids, value['発火方式'])
    if not full:
        expected['帯'] = ['DAY']
        expected['shape'] = [len(ids), len(value['発火方式']), 2, 12, 4, 3, 16]
    for name in ('規則順', '発火方式', '方向', '幅', '時計', '帯', '期間', '指標', '主label', 'shape'):
        assert value[name] == expected[name], name


def iter_blocks(day_output: Path, additions: list[Path] | None = None):
    """
    機能: DAY/PRE/POSTをSource別に統一し、追加LOCAL等も同じ型で逐次返す。
    引数: day_output(Path)は173出力フォルダ又はpool.json、additions(list[Path]|None)はfull型追加pool。
    返り値: generator[dict]はsource/ids/families/metrics/axis/birth/eligible_hours/references。
            metrics軸は規則×発火×正逆×幅×期限×DAY/PRE/POST×期間×16指標。
    """
    manifests = [day_output, *(additions or [])]
    seen = set()
    for manifest_path in manifests:
        manifest_path = manifest_path / 'pool.json' if manifest_path.is_dir() else manifest_path
        manifest = read(manifest_path)
        assert manifest['成功'] and manifest['版'] == '173予備三帯1'
        assert manifest['帯'] == list(BANDS) and manifest['期間'] == list(PERIODS)
        for entry in manifest['blocks']:
            source, ids = entry['source'], entry['ids']
            assert source not in seen and len(entry['families']) == len(ids)
            seen.add(source)
            if entry['layout'] == 'day_plus_reused_night':
                checked(entry['night_proof'])
                day_axis = read(checked(entry['day_axis']))
                validate_axis(day_axis, ids, False)
                night_axis = read(checked(entry['night_axis']))
                assert night_axis['規則順'] == ids and night_axis['帯'] == ['NIGHT', 'PRE', 'POST']
                for key in ('発火方式', '方向', '幅', '時計', '期間', '指標', '主label'):
                    assert night_axis[key] == day_axis[key], key
                with np.load(checked(entry['day_metrics']), allow_pickle=False) as source_file:
                    day = source_file['metrics']
                with np.load(checked(entry['night_metrics']), allow_pickle=False) as source_file:
                    night = source_file['metrics']
                assert list(day.shape) == day_axis['shape'] and list(night.shape) == night_axis['shape']
                metrics = np.concatenate((day[..., None, :, :], night[..., 1:3, :, :]), axis=5)
                del day, night
            else:
                assert entry['layout'] == 'full'
                full_axis = read(checked(entry['axis']))
                validate_axis(full_axis, ids, True)
                with np.load(checked(entry['metrics']), allow_pickle=False) as source_file:
                    metrics = source_file['metrics']
            common_axis = axis(ids, day_axis['発火方式'] if entry['layout'] == 'day_plus_reused_night' else full_axis['発火方式'])
            assert list(metrics.shape) == common_axis['shape']
            for ref in entry['birth']['files'].values():
                checked(ref)
            checked(entry['birth']['proof'])
            if 'catalog' in entry['birth']:
                checked(entry['birth']['catalog'])
            yield {'source': source, 'ids': ids, 'families': entry['families'], 'metrics': metrics,
                'axis': common_axis, 'birth': entry['birth'], 'eligible_hours': manifest['eligible_hours'],
                'declared_modes': entry.get('declared_modes'),
                'references': entry, 'manifest': physical(manifest_path)}


def register_full(output: Path, source: str, ids: list[str], families: list[str],
                  metrics: np.ndarray, birth: dict, eligible_hours: list, provenance: dict,
                  modes: list[str] | None = None, declared_modes: list[str] | None = None) -> dict:
    """
    機能: 後から計算するLOCAL等を同じ三帯16指標型の別poolとして登録する。
    引数: output(Path)は未作成先、source(str)は固有Source名、ids/families(list[str])は順序、
          metrics(np.ndarray)は完成済み三帯統計、birth(dict)は出生参照、eligible_hours(list[3,3])は帯別期間時間、provenance(dict)は固定由来、
          modes(list[str]|None)は発火軸、declared_modes(list[str]|None)は辞書で適用済みの発火方式。
    返り値: dictは保存pool。計算・選択を行わず入力統計をそのまま保存する。
    """
    assert not output.exists() and source and len(families) == len(ids)
    common = axis(ids, modes)
    assert declared_modes is None or len(declared_modes) == len(ids)
    assert list(metrics.shape) == common['shape'] and np.asarray(eligible_hours).shape == (3, 3)
    output.mkdir(parents=True)
    np.savez_compressed(output / '統計配列.npz', metrics=metrics)
    (output / '統計軸.json').write_text(json.dumps(common, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    entry = {'source': source, 'ids': ids, 'families': families, 'layout': 'full',
        'metrics': physical(output / '統計配列.npz'), 'axis': physical(output / '統計軸.json'), 'birth': birth,
        'declared_modes': declared_modes}
    result = {'成功': True, '版': '173予備三帯1', '帯': list(BANDS), '期間': list(PERIODS),
        'eligible_hours': eligible_hours, 'blocks': [entry], '由来': provenance}
    (output / 'pool.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return result
