"""DAY代表を別ループ集計し、旧164全帯から旧172夜間を引いた加法項とも照合する。"""
from pathlib import Path
from collections import Counter

import numpy as np

from pool173 import ROOT, WIDTHS, HORIZONS, PERIODS, FIELDS, checked, read


def direct_row(context: dict, selected: list, width: int, horizon: str, period: int, phase: int) -> np.ndarray:
    """
    機能: 物理取得一覧から一帯一期間の16指標を別実装で数える。
    引数: context(dict)は共有入力、selected(list[tuple])はcase/側/q0帯、width(int)/horizon(str)/period(int)/phase(int)は評価範囲。
    返り値: np.ndarray[16]はIFD_FIRST・既知net5の独立集計。
    """
    eligible = []
    hours = 0.
    for si, scene in enumerate(context['scenes']):
        if (period == 1 and si >= 48) or (period == 2 and si < 48):
            continue
        if context['hours'][si, phase] <= 0:
            continue
        eligible.append(si)
        hours += float(context['hours'][si, phase])
    wi = context['meta']['widths'].index(width)
    hi = context['meta']['horizons'].index(horizon)
    arrays = context['arrays']
    labels, money, scenes = [], [], []
    for case, side, first_phase in selected:
        si = int(arrays['session_index'][case])
        if si not in eligible or first_phase != phase:
            continue
        key = (case, side, wi, hi)
        known, reached, strict = bool(arrays['known'][key]), int(arrays['direction'][key]), int(arrays['label'][key])
        label = reached if known and reached else 0 if strict == 0 else 2
        assert (label == 2) == (not known)
        labels.append(label); scenes.append(si)
        if known:
            money.append(int(arrays['net5'][key]))
    counts = Counter(labels)
    f, a, n, c = [counts[k] for k in (1, -1, 0, 2)]
    profit, loss = sum(max(m, 0) for m in money), sum(max(-m, 0) for m in money)
    scene_counts = Counter(scenes)
    count = len(labels)
    values = {'count': count, 'F': f, 'A': a, 'N': n, 'C': c, 'rate': f/(f+a) if f+a else np.nan,
        'profit': profit, 'loss': loss, 'net': profit-loss, 'pf': profit/loss if loss else np.nan,
        'known': len(money), 'unknown': c, 'scenes': len(scene_counts), 'eligible_scenes': len(eligible),
        'per_hour': count/hours if hours else np.nan, 'max_scene_share': max(scene_counts.values())/count if count else np.nan}
    return np.array([values[f] for f in FIELDS], dtype=float)


def physical_list(context: dict, directions: np.ndarray) -> list:
    """
    機能: 全q0を順に走査し、帯で分解する前に同物理caseの最初の成立だけを残す。
    引数: context(dict)は取得対応、directions(np.ndarray[N])は固定出生。
    返り値: list[tuple]はcase/側/q0帯。vector選択関数を再用しない。
    """
    mapping = {name: i for i, name in enumerate(context['meta']['case_ids'])}
    seen, selected = set(), []
    for event, sign in enumerate(directions):
        capture = context['captures'][event]
        if not sign or capture['status'] != 'filled' or capture['case_id'] in seen:
            continue
        seen.add(capture['case_id'])
        selected.append((mapping[capture['case_id']], 0 if sign > 0 else 1, int(context['event_phases'][event])))
    return selected


def verify(context: dict, entries: list[dict]) -> dict:
    """
    機能: OLD/NEW各代表8規則の全DAY軸を別集計し、OLDは旧164全帯−旧172NIGHT加法項を照合する。
    引数: context(dict)は同じ固定入力、entries(list[dict])は完成DAYのpool登録。
    返り値: dictは検査規模と成功。screen173の選択・ラベル・集計関数は呼ばない。
    """
    direct_cells = additive_cells = 0
    representatives = {}
    old_axis_path = ROOT / 'work/164先着確定と反転比較/比較/統計軸.json'
    old_axis = read(old_axis_path)
    old_fields = {name: i for i, name in enumerate(old_axis['指標'])}
    additive = ('count', 'F', 'A', 'N', 'C', 'profit', 'loss', 'net', 'known', 'unknown', 'scenes')
    for entry in entries:
        ids = entry['ids']
        reps = list(range(0, len(ids), 96)) if entry['source'] == 'NEW768' else np.linspace(0, len(ids)-1, 8, dtype=int).tolist()
        representatives[entry['source']] = [ids[i] for i in reps]
        with np.load(checked(entry['day_metrics']), allow_pickle=False) as saved:
            actual = saved['metrics'][reps].copy()
        for wj, width in enumerate(WIDTHS):
            birth = entry['birth']
            reference = birth['files'][str(width) if birth['layout'] == 'width_dependent' else 'shared']
            with np.load(checked(reference), allow_pickle=False) as saved:
                matrices = {mode: saved[mode][reps].copy() for mode in ('ALL', 'EDGE')}
            for local, ri in enumerate(reps):
                for mi, mode in enumerate(('ALL', 'EDGE')):
                    selected = physical_list(context, matrices[mode][local])
                    for oi in (0, 1):
                        oriented = [(case, side if oi == 0 else 1-side, phase) for case, side, phase in selected]
                        for hi, horizon in enumerate(HORIZONS):
                            for pi, period in enumerate(PERIODS):
                                expected = direct_row(context, oriented, width, horizon, pi, 0)
                                observed = actual[local, mi, oi, wj, hi, pi]
                                assert np.allclose(observed, expected, equal_nan=True, rtol=1e-12, atol=1e-12), \
                                    (entry['source'], ids[ri], mode, oi, width, horizon, period)
                                direct_cells += len(FIELDS)
        if entry['source'] == 'OLD1460':
            assert old_axis['規則順'] == ids and old_axis['統合'][0] == 'N'
            with np.load(ROOT / 'work/164先着確定と反転比較/比較/最初到達の統計配列.npz', allow_pickle=False) as saved:
                all_bands = saved['metrics'][reps, :, :, :, :, 0].copy()
            with np.load(checked(entry['night_metrics']), allow_pickle=False) as saved:
                night = saved['metrics'][reps, :, :, :, :, 0].copy()
            for field in additive:
                difference = all_bands[..., old_fields[field]] - night[..., FIELDS.index(field)]
                assert np.array_equal(difference, actual[..., FIELDS.index(field)]), field
                additive_cells += difference.size
    return {'成功': True, '代表規則': representatives, '別一覧集計16指標照合セル': direct_cells,
        '旧164全帯Nから旧172NIGHTを引いた11加法項照合セル': additive_cells,
        '非加法項': 'rate/pf/per_hour/max_scene_shareは差し引かず、別一覧集計だけで照合。eligible_scenesも帯別分母で検算。',
        '再用範囲': '同じ固定入力contextと定数のみ。select_physical/day_cube/labelsは再用しない。'}
