"""自然金融を読まず、正準化・IFD_FIRST・三帯軸・DECLARED接続を確認する。"""
from pathlib import Path
import json
import tempfile

import numpy as np

import screen173 as screen
import pool173 as pool
from 独立検算 import direct_row, physical_list

HERE = Path(__file__).resolve().parent


def fixture() -> dict:
    """
    機能: 73場の位置と有限の小型金融配列だけを持つ人工contextを作る。
    引数: なし。自然ファイルは読まない。
    返り値: dictはDAY/PRE/POSTと前48/後25を持つ人工入力。
    """
    scenes = [{'session': '人工' + str(i), 'start': float(i*1000), 'end': float(i*1000+900)} for i in range(73)]
    hours = np.zeros((73, 3))
    hours[0, 0] = hours[48, 0] = 7
    hours[1, 1:] = hours[49, 1:] = [6, 7]
    cases = np.array([0, 0, 1, -1, 2, 3, 3, 4, 5])
    phases = np.array([1, 0, 0, 0, 0, 2, 0, 0, 2], dtype=np.int8)
    case_scene = np.array([1, 0, 48, 49, 48, 49])
    shape = (6, 2, 12, 4)
    arrays = {'known': np.ones(shape, bool), 'label': np.zeros(shape, np.int8),
        'direction': np.zeros(shape, np.int8), 'net5': np.full(shape, -1077, dtype=np.int64),
        'session_index': case_scene}
    arrays['known'][1] = False
    arrays['label'][1] = 2
    arrays['net5'][1] = 999999999
    arrays['label'][2, 0] = 2
    arrays['direction'][2, 0] = 1
    arrays['net5'][2, 0] = 18923
    captures = [{'event_id': '人工q0_' + str(i), 'status': 'filled' if c >= 0 else 'unavailable',
        'case_id': '人工case_' + str(c), 'session': scenes[case_scene[c]]['session'] if c >= 0 else '人工0',
        'q0': {'time': float(i), 'index': i, 'source_line': i+1}} for i, c in enumerate(cases)]
    return {'scenes': scenes, 'hours': hours, 'arrays': arrays, 'captures': captures,
        'event_cases': cases, 'event_phases': phases,
        'meta': {'case_ids': ['人工case_' + str(i) for i in range(6)],
                 'widths': list(pool.WIDTHS), 'horizons': list(pool.HORIZONS)}}


def main() -> None:
    """
    機能: 人工配列だけで全16指標を独立集計と比較し、自然実行前の結果を保存する。
    引数: なし。173のSourceと人工一時ファイルだけを読む。
    返り値: None。人工確認.jsonを保存する。自然screenは呼ばない。
    """
    context = fixture()
    directions = np.ones(len(context['event_cases']), dtype=np.int8)
    cases, sides, phases, events = screen.select_physical(directions, context['event_cases'], context['event_phases'])
    assert cases.tolist() == [0, 1, 2, 3, 4, 5] and events.tolist() == [0, 2, 4, 5, 7, 8]
    assert phases.tolist() == [1, 0, 0, 2, 0, 2]
    assert (cases == context['event_cases'][events]).all()
    empty = screen.select_physical(directions*0, context['event_cases'], context['event_phases'])
    assert all(len(a) == 0 for a in empty)
    cube = screen.day_cube(context, cases, sides, phases, 0)
    assert cube[0, 0, pool.FIELDS.index('F')] == 1
    assert cube[0, 0, pool.FIELDS.index('C')] == 1
    assert cube[0, 0, pool.FIELDS.index('profit')] == 18923
    assert cube[0, 0, pool.FIELDS.index('known')] == 2
    assert cube[0, 0, pool.FIELDS.index('count')] == 3
    assert cube[0, 0, pool.FIELDS.index('scenes')] == 2
    assert cube[0, 0, pool.FIELDS.index('eligible_scenes')] == 2
    rng = np.random.default_rng(202611151731)
    checked = 0
    for sample in range(64):
        shape = context['arrays']['known'].shape
        known = rng.random(shape) > .2
        direction = rng.choice((-1, 0, 1), shape).astype(np.int8)
        strict = np.where(known, direction, 2).astype(np.int8)
        strict[known & (direction != 0) & (rng.random(shape) < .3)] = 2
        context['arrays']['known'] = known
        context['arrays']['direction'] = direction
        context['arrays']['label'] = strict
        context['arrays']['net5'] = rng.integers(-50000, 50001, shape)
        directions = rng.choice((-1, 0, 1), len(context['event_cases'])).astype(np.int8)
        cases, sides, phases, _ = screen.select_physical(directions, context['event_cases'], context['event_phases'])
        selected = physical_list(context, directions)
        for oi in (0, 1):
            oriented = sides if oi == 0 else 1-sides
            direct = [(case, side if oi == 0 else 1-side, phase) for case, side, phase in selected]
            for wi, width in enumerate(pool.WIDTHS):
                for bi in range(3):
                    observed = screen.day_cube(context, cases, oriented, phases, wi, bi)
                    for hi, horizon in enumerate(pool.HORIZONS):
                        for pi in range(3):
                            expected = direct_row(context, direct, width, horizon, pi, bi)
                            assert np.allclose(observed[hi, pi], expected, equal_nan=True, rtol=1e-12, atol=1e-12)
                            checked += 16
    # ----------------------------------------
    # 小さい人工full blockだけを保存し、DECLARED一軸を保つpool読込を確認する。
    with tempfile.TemporaryDirectory(prefix='人工pool_', dir=HERE) as temporary:
        temporary = Path(temporary).resolve()
        assert temporary.is_relative_to(HERE)
        proof = temporary / '人工出生票.json'
        proof.write_text('{}\n', encoding='utf-8')
        extended_ref = {**pool.physical(proof), 'layout': 'declared', 'array_name': 'directions'}
        assert pool.checked(extended_ref) == proof
        for invalid_ref in ({**extended_ref, 'array_name': '価格'},
                            {**extended_ref, 'layout': 'shared'},
                            {**extended_ref, '未知項目': 1},
                            {**extended_ref, 'sha256': '0'*64}):
            try:
                pool.checked(invalid_ref)
            except AssertionError:
                continue
            raise AssertionError('不正な追加metadata又は指紋を受理した')
        birth = {'layout': 'declared', 'array_name': 'directions',
            'files': {'shared': extended_ref}, 'proof': pool.physical(proof), 'q0_count': 9}
        metrics = np.zeros((2, 1, 2, 12, 4, 3, 3, 16))
        output = temporary / '追加'
        pool.register_full(output, '人工LOCAL', ['人工A', '人工B'], ['人工群', '人工群'],
            metrics, birth, [[14., 7., 7.], [12., 6., 6.], [14., 7., 7.]], {},
            modes=['DECLARED'], declared_modes=['ALL', 'EDGE'])
        block = list(pool.iter_blocks(output))[0]
        assert block['axis']['発火方式'] == ['DECLARED'] and block['metrics'].shape == metrics.shape
        assert block['declared_modes'] == ['ALL', 'EDGE']
        invalid = temporary / '未固定票.json'
        invalid.write_text('{"固定対象": []}\n', encoding='utf-8')
        try:
            screen.verify_f1(invalid, '0'*64)
        except AssertionError:
            pass
        else:
            raise AssertionError('誤ったF1指紋を受理した')
    result = {'成功': True, 'この人工検査から自然価格特徴金融未読': True, 'この人工検査から新自然screen未実行': True,
        '物理case最初q0を全場固定後にDAY分解': True, '正逆は同case実側を交換': True,
        'STRICT未完でも欠測前の到達をIFD_FIRSTへ保持': True, '未知net5を利益へ混ぜない': True,
        '独立集計比較セル': checked, '乱数種': 202611151731,
        'LOCAL_DECLARED一軸と実mode保持': True, '誤F1指紋の自然読込前拒否': True,
        '出生参照の追加metadataはdeclared_directionsだけ許可し指紋3fieldを照合': True,
        '未知項目と誤metadataと誤指紋を拒否': True,
        'Source': {p.name: pool.physical(p) for p in (HERE/'screen173.py', HERE/'pool173.py', HERE/'独立検算.py', Path(__file__))}}
    (HERE / '人工確認.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in result.items() if k != 'Source'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
