"""未公表の長期増分がまだ一度も無い場だけを局所技術で補完する純部品。"""
import numpy as np

VERSION='166局所補完1'
SCORE_COLUMNS=('m5_ema21_delta_to_side','m5_di_difference_to_side','m5_hist_delta_to_side',
    'm5_rsi_delta_to_side','m5_body_ratio_to_side','m5_close_position_to_side','m1_volume_relative_prior3')
GATE_COLUMNS=SCORE_COLUMNS+('m5_rsi_center_to_side','q0_entry_minus_ema8_atr5_to_side',
    'm5_tr_atr_ratio','q0_spread_points','q0_last_minus_m1_close_atr5_to_side')
AVAILABILITY_COLUMN='m15_hist_delta_to_side'


def evaluate_local(buy_X: np.ndarray,sell_X: np.ndarray,columns: list,q0_meta: list,
                   scene_starts: np.ndarray,after_minutes: int,minimum_score: int) -> dict:
    """
    機能: 当時までの長期増分利用履歴とM5方向・動力・構造・量から局所方向を求める。
    引数: buy_X/sell_X(np.ndarray[N,C])は買売実側特徴、columns(list[str又はdict])は列定義、
          q0_meta(list[dict])はsession_index/q0_time、scene_starts(np.ndarray[S])は各場開始秒、
          after_minutes(int)は120又は180、minimum_score(int)は4又は5。
    返り値: dict。directions[N]int8、scores[2,N]float、known/eligibility等の診断配列。
            教師・取得・金融を受け取らず、必要列の非有限値を0票へ置換しない。
    """
    assert after_minutes in (120,180) and minimum_score in (4,5)
    names=[item['name'] if isinstance(item,dict) else item for item in columns]
    assert len(names)==len(set(names))
    index={name:i for i,name in enumerate(names)}
    assert all(name in index for name in (*GATE_COLUMNS,AVAILABILITY_COLUMN))
    arrays=np.stack([np.asarray(buy_X,dtype=np.float64),np.asarray(sell_X,dtype=np.float64)])
    assert arrays.ndim==3 and arrays.shape[0]==2 and arrays.shape[2]==len(names)
    n=arrays.shape[1];assert len(q0_meta)==n
    starts=np.asarray(scene_starts,dtype=np.float64)
    assert starts.ndim==1 and np.isfinite(starts).all()
    scenes=np.array([q['session_index'] for q in q0_meta],dtype=np.int64)
    times=np.array([q['q0_time'] for q in q0_meta],dtype=np.float64)
    assert np.isfinite(times).all() and ((scenes>=0)&(scenes<len(starts))).all()
    assert n==0 or np.all(times>=starts[scenes])
    assert n<=1 or np.all((scenes[1:]>scenes[:-1])|((scenes[1:]==scenes[:-1])&(times[1:]>=times[:-1])))
    # ----------------------------------------
    # 有限0も公表済み。現在行を含め、場末の未来の公表時刻は一切参照しない。
    current_available=np.isfinite(arrays[:,:,index[AVAILABILITY_COLUMN]]).any(axis=0)
    seen=np.zeros(n,dtype=bool);published=False;previous_scene=None
    for row,scene in enumerate(scenes):
        if previous_scene is None or scene!=previous_scene:published=False
        published=published or bool(current_available[row]);seen[row]=published;previous_scene=scene
    elapsed=times-starts[scenes]
    eligible=(~seen)&(elapsed>=after_minutes*60)
    # ----------------------------------------
    # 六票に必要な七列を全knownとする。高得点側を決めてから、その側だけ資格を検査する。
    values={name:arrays[:,:,index[name]] for name in GATE_COLUMNS}
    score_known=np.isfinite(arrays[:,:,[index[name] for name in SCORE_COLUMNS]]).all(axis=2)
    gate_known=np.isfinite(arrays[:,:,[index[name] for name in GATE_COLUMNS]]).all(axis=2)
    trend_votes=np.stack([values['m5_ema21_delta_to_side']>0,values['m5_di_difference_to_side']>0])
    body=(values['m5_body_ratio_to_side']>0)&(values['m5_close_position_to_side']>.5)
    momentum_votes=np.stack([values['m5_hist_delta_to_side']>0,values['m5_rsi_delta_to_side']>0,body])
    volume=values['m1_volume_relative_prior3']>=.5
    score=trend_votes.sum(axis=0)+momentum_votes.sum(axis=0)+volume
    scores=np.where(score_known,score,np.nan)
    rsi=values['m5_rsi_center_to_side'];spread=values['q0_spread_points']
    passed=gate_known&(scores>=minimum_score)&trend_votes.any(axis=0)&momentum_votes.any(axis=0)&\
        (rsi>=-5)&(rsi<=25)&(np.abs(values['m5_rsi_delta_to_side'])<=12)&\
        (np.abs(values['q0_entry_minus_ema8_atr5_to_side'])<=1)&volume&\
        (values['m5_tr_atr_ratio']<=2)&(spread>0)&(spread<=20)&\
        (np.abs(values['q0_last_minus_m1_close_atr5_to_side'])<=1)
    margin=scores[0]-scores[1]
    preferred=np.where(margin>=1,1,np.where(margin<=-1,-1,0)).astype(np.int8)
    directions=np.where(eligible&(preferred==1)&passed[0],1,
        np.where(eligible&(preferred==-1)&passed[1],-1,0)).astype(np.int8)
    return {'directions':directions,'scores':scores,'score_known':score_known,'gate_known':gate_known,
        'side_pass':passed,'preferred_side':preferred,'eligible':eligible,'seen_m15_hist':seen,
        'current_m15_hist_available':current_available,'elapsed_seconds':elapsed,
        'direction_votes':trend_votes.sum(axis=0).astype(np.int8),
        'momentum_votes':momentum_votes.sum(axis=0).astype(np.int8)}


def merge_hierarchy(oldtechnical: np.ndarray,local_directions: np.ndarray) -> tuple:
    """
    機能: 旧Tの非0方向を常に優先し、待機行だけを局所方向へ置き換える。
    引数: oldtechnical(np.ndarray[2,N])は旧T150/T200、local_directions(np.ndarray[N])。
    返り値: tuple[np.ndarray,np.ndarray]は技術方向[2,N]int8とtier[2,N]int8。
            tierは0待機/1旧T/2局所。主新規/pending/取得制御は呼び出し側の165方式を使う。
    """
    old=np.asarray(oldtechnical);local=np.asarray(local_directions)
    assert old.ndim==2 and old.shape[0]==2 and local.shape==(old.shape[1],)
    assert np.isin(old,(-1,0,1)).all() and np.isin(local,(-1,0,1)).all()
    direction=np.where(old!=0,old,local[None,:]).astype(np.int8)
    tier=np.where(old!=0,1,np.where(local[None,:]!=0,2,0)).astype(np.int8)
    assert np.array_equal(direction[old!=0],old[old!=0])
    return direction,tier
