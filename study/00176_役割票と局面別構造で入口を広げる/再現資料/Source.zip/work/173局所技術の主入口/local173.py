"""173の局所主入口候補を当時特徴だけから出生する純部品。金融・教師を読まない。"""

from __future__ import annotations

from collections.abc import Mapping
from itertools import product

import numpy as np

VERSION = "173局所主入口1"
SCORE_COLUMNS = (
    "m5_ema21_delta_to_side", "m5_di_difference_to_side", "m5_hist_delta_to_side",
    "m5_rsi_delta_to_side", "m5_body_ratio_to_side", "m5_close_position_to_side", "m1_volume_relative_prior3",
)
GATE_COLUMNS = SCORE_COLUMNS + (
    "m5_rsi_center_to_side", "q0_entry_minus_ema8_atr5_to_side", "m5_tr_atr_ratio",
    "q0_spread_points", "q0_last_minus_m1_close_atr5_to_side",
)
AVAILABILITY_COLUMN = "m15_hist_delta_to_side"
MAXIMUM_GAP_SECONDS = 180


def catalog() -> dict:
    """
    機能: 自然特徴を見る前に定義した152候補の全閾値・発火・状態規則を返す。
    引数: なし。
    返り値: dict。旧4規則×2発火の8対照と、新72規則×2発火の144候補。
    """
    rules = []
    for after, score, firing in product((120, 180), (4, 5), ("ALL", "EDGE")):
        rules.append({"id": f"L166_L{after}_S{score}_{firing}", "family": "旧166完全同式",
                      "after_minutes": after, "minimum_score": score, "confirmation_minutes": 0,
                      "adverse_rsi_delta_max": 12, "volume_min": 0.5, "mode": firing,
                      "availability_memory": "場単位ever", "confirmation_reset": "なし",
                      "edge_reset": "場変更またはgap180秒超", "legacy_formula": True})
    for after, score, confirmation, adverse, volume, firing in product(
            (120, 180), (4, 5), (0, 2, 5), (8, 12), (0.5, 0.75, 1.0), ("ALL", "EDGE")):
        volume_id = {0.5: "050", 0.75: "075", 1.0: "100"}[volume]
        rules.append({"id": f"L173_L{after}_S{score}_P{confirmation}_R{adverse}_V{volume_id}_{firing}",
                      "family": "173局所主入口", "after_minutes": after, "minimum_score": score,
                      "confirmation_minutes": confirmation, "adverse_rsi_delta_max": adverse,
                      "volume_min": volume, "mode": firing,
                      "availability_memory": "場と限月の組単位ever・gapでは消さない",
                      "confirmation_reset": "場変更・限月変更・gap180秒超・方向不成立または変更",
                      "edge_reset": "場変更・限月変更・gap180秒超", "legacy_formula": False})
    return {
        "version": VERSION, "candidate_count": len(rules), "legacy_rule_count": 4, "legacy_candidate_count": 8,
        "new_rule_count": 72, "new_candidate_count": 144,
        "required_columns": list(GATE_COLUMNS) + [AVAILABILITY_COLUMN],
        "common": {
            "maximum_gap_seconds": MAXIMUM_GAP_SECONDS,
            "score_known": "六票に必要な七列がすべて有限。未知を0票へ置換しない。",
            "votes": [
                {"role": "方向", "conditions": [{"column": "m5_ema21_delta_to_side", "operator": ">", "threshold": 0}]},
                {"role": "方向", "conditions": [{"column": "m5_di_difference_to_side", "operator": ">", "threshold": 0}]},
                {"role": "動力", "conditions": [{"column": "m5_hist_delta_to_side", "operator": ">", "threshold": 0}]},
                {"role": "動力", "conditions": [{"column": "m5_rsi_delta_to_side", "operator": ">", "threshold": 0}]},
                {"role": "実体と位置", "conditions": [{"column": "m5_body_ratio_to_side", "operator": ">", "threshold": 0},
                                                       {"column": "m5_close_position_to_side", "operator": ">", "threshold": 0.5}]},
                {"role": "量", "conditions": [{"column": "m1_volume_relative_prior3", "operator": ">=", "threshold": "各規則volume_min"}]},
            ],
            "preferred_score_margin_min": 1, "require_at_least_one_trend_vote": True,
            "require_at_least_one_momentum_vote": True,
            "rsi_center_min": -5, "rsi_center_max": 25, "absolute_rsi_delta_max": 12,
            "absolute_entry_minus_ema8_atr5_max": 1, "m5_tr_atr_ratio_max": 2,
            "spread_points_min_exclusive": 0, "spread_points_max_inclusive": 20,
            "absolute_last_minus_m1_close_atr5_max": 1,
            "adverse_spike_rule": "選択側RSIΔ>=-adverse_rsi_delta_max。正方向の+8〜+12を追加で落とさない。",
            "direction_selection": "先に六票の高得点側を1票以上の差で選び、その側だけ資格を検査する。",
            "m15_availability": "買売のどちらかが有限なら公表済み。有限0も既知。現在行までのever。",
            "new_volume_vote": "新規則では量票もvolume_minを使用。量が閾値未満なら品質guardで不成立。",
            "elapsed_clock": "L120/L180は元の実セッション開始からの経過。限月変更で開始時計を移さない。",
            "confirmation_coverage": "資格・方向が連続する観測列の最初から現在までの実時間。隣接gap<=180秒、同時刻重複は時間を増やさない。",
            "confirmation_start": "開始待機・M15未公表・品質・方向がすべて成立した最初の当時行。",
            "unchanged_m5_value": "同じ5分入力値の継続も実時間を覆う。新しい5分足の本数や異なる値の数ではない。",
            "new_edge": "確認後の方向が直前と変化した非0行、または履歴reset後最初の非0行。",
            "all": "確認後に資格を持つ全q0行。同じ方向の連続行も出生する。",
        },
        "rules": rules,
    }


def _get(features: object, name: str):
    """
    機能: 辞書または属性付き当時特徴から必要入力を取得する。
    引数: features（object）入力束、name（str）必要な項目名。
    返り値: object。指定項目。欠落時はValueErrorを送出する。
    """
    if isinstance(features, Mapping):
        if name not in features:
            raise ValueError(f"当時特徴の必須項目がない: {name}")
        return features[name]
    if not hasattr(features, name):
        raise ValueError(f"当時特徴の必須属性がない: {name}")
    return getattr(features, name)


def _prepare(features: object) -> dict:
    """
    機能: 当時入力の形・時間順・場・限月を検査し、六票と品質に必要な配列を作る。
    引数: features（object）buy_X/sell_X/columns/q0_meta/scene_starts/phasesを持つ辞書または属性束。
    返り値: dict。入力を変更せず、方向選択・状態評価用の配列を返す。
    """
    columns = _get(features, "columns")
    names = [item["name"] if isinstance(item, dict) else item for item in columns]
    if len(names) != len(set(names)):
        raise ValueError("特徴列名が重複している。")
    index = {name: position for position, name in enumerate(names)}
    if any(name not in index for name in (*GATE_COLUMNS, AVAILABILITY_COLUMN)):
        raise ValueError("局所技術に必要な当時特徴列が足りない。")
    arrays = np.stack([np.asarray(_get(features, "buy_X"), dtype=np.float64),
                       np.asarray(_get(features, "sell_X"), dtype=np.float64)])
    if arrays.ndim != 3 or arrays.shape[0] != 2 or arrays.shape[2] != len(names):
        raise ValueError("買売特徴は同形の[N,特徴列数]にする。")
    meta = _get(features, "q0_meta")
    n = arrays.shape[1]
    if len(meta) != n:
        raise ValueError("q0メタデータと特徴行数が一致しない。")
    starts = np.asarray(_get(features, "scene_starts"), dtype=np.float64)
    scenes = np.asarray([row["session_index"] for row in meta], dtype=np.int64)
    times = np.asarray([row["q0_time"] for row in meta], dtype=np.float64)
    contracts = np.asarray([row["contract"] for row in meta], dtype=str)
    phases = np.asarray(_get(features, "phases"))
    if phases.shape != (n,) or not np.isin(phases, (0, 1, 2)).all():
        raise ValueError("時間帯phasesは0デイ・1米国前・2米国後の[N]で指定する。")
    if starts.ndim != 1 or not np.isfinite(starts).all() or not np.isfinite(times).all():
        raise ValueError("場開始・当時時刻は有限秒で指定する。")
    if not ((scenes >= 0) & (scenes < len(starts))).all() or (n and not np.all(times >= starts[scenes])):
        raise ValueError("場番号または開始からの時刻が不正。")
    if any(not isinstance(row["contract"], str) or not row["contract"] for row in meta):
        raise ValueError("限月は空ではない文字列で明示する。")
    if n > 1 and not np.all((scenes[1:] > scenes[:-1]) | ((scenes[1:] == scenes[:-1]) & (times[1:] >= times[:-1]))):
        raise ValueError("入力は場番号・当時時刻の順に並べる。")
    values = {name: arrays[:, :, index[name]] for name in GATE_COLUMNS}
    score_known = np.isfinite(arrays[:, :, [index[name] for name in SCORE_COLUMNS]]).all(axis=2)
    gate_known = np.isfinite(arrays[:, :, [index[name] for name in GATE_COLUMNS]]).all(axis=2)
    trend_votes = np.stack([values["m5_ema21_delta_to_side"] > 0, values["m5_di_difference_to_side"] > 0])
    body = (values["m5_body_ratio_to_side"] > 0) & (values["m5_close_position_to_side"] > 0.5)
    momentum_votes = np.stack([values["m5_hist_delta_to_side"] > 0, values["m5_rsi_delta_to_side"] > 0, body])
    current_available = np.isfinite(arrays[:, :, index[AVAILABILITY_COLUMN]]).any(axis=0)
    scene_reset = np.r_[True, scenes[1:] != scenes[:-1]] if n else np.zeros(0, dtype=bool)
    old_history_reset = scene_reset.copy()
    new_history_reset = scene_reset.copy()
    if n > 1:
        gaps = times[1:] - times[:-1] > MAXIMUM_GAP_SECONDS
        old_history_reset[1:] |= gaps
        new_history_reset[1:] |= gaps | (contracts[1:] != contracts[:-1])
    old_seen = np.zeros(n, dtype=bool)
    new_seen = np.zeros(n, dtype=bool)
    published = False
    published_keys = set()
    for row in range(n):
        if scene_reset[row]:
            published = False
        published = published or bool(current_available[row])
        old_seen[row] = published
        key = (int(scenes[row]), contracts[row])
        if current_available[row]:
            published_keys.add(key)
        new_seen[row] = key in published_keys
    return {"values": values, "score_known": score_known, "gate_known": gate_known,
            "trend_votes": trend_votes, "momentum_votes": momentum_votes,
            "times": times, "scenes": scenes, "contracts": contracts, "phases": phases.astype(np.int8),
            "elapsed": times - starts[scenes], "current_available": current_available,
            "old_seen": old_seen, "new_seen": new_seen,
            "old_history_reset": old_history_reset, "new_history_reset": new_history_reset}


def _raw_directions(prepared: dict, rule: dict) -> tuple:
    """
    機能: 六票の優先側と当時品質から、確認持続前の局所方向を求める。
    引数: prepared（dict）検査済み入力、rule（dict）固定Catalogの1規則。
    返り値: tuple[np.ndarray, np.ndarray]。方向[N]int8、買売六票得点[2,N]float。
    """
    values = prepared["values"]
    volume = values["m1_volume_relative_prior3"] >= rule["volume_min"]
    score = prepared["trend_votes"].sum(axis=0) + prepared["momentum_votes"].sum(axis=0) + volume
    scores = np.where(prepared["score_known"], score, np.nan)
    rsi, delta = values["m5_rsi_center_to_side"], values["m5_rsi_delta_to_side"]
    spread = values["q0_spread_points"]
    passed = (prepared["gate_known"] & (scores >= rule["minimum_score"])
              & prepared["trend_votes"].any(axis=0) & prepared["momentum_votes"].any(axis=0)
              & (rsi >= -5) & (rsi <= 25) & (np.abs(delta) <= 12)
              & (np.abs(values["q0_entry_minus_ema8_atr5_to_side"]) <= 1) & volume
              & (values["m5_tr_atr_ratio"] <= 2) & (spread > 0) & (spread <= 20)
              & (np.abs(values["q0_last_minus_m1_close_atr5_to_side"]) <= 1))
    if not rule["legacy_formula"]:
        passed &= delta >= -rule["adverse_rsi_delta_max"]
    margin = scores[0] - scores[1]
    preferred = np.where(margin >= 1, 1, np.where(margin <= -1, -1, 0)).astype(np.int8)
    seen = prepared["old_seen"] if rule["legacy_formula"] else prepared["new_seen"]
    eligible = (~seen) & (prepared["elapsed"] >= rule["after_minutes"] * 60)
    directions = np.where(eligible & (preferred == 1) & passed[0], 1,
                          np.where(eligible & (preferred == -1) & passed[1], -1, 0)).astype(np.int8)
    return directions, scores


def confirmation_directions(raw: np.ndarray, times: np.ndarray, reset: np.ndarray,
                            confirmation_seconds: int) -> np.ndarray:
    """
    機能: 同じ非0方向が途切れず覆った実時間で確認持続を判定する。
    引数: raw（np.ndarray[N]）方向、times（np.ndarray[N]）当時秒、reset（np.ndarray[N]）履歴境界、
          confirmation_seconds（int）0/120/300秒の確認持続。
    返り値: np.ndarray[N]int8。必要時間を満たした全行の方向。異なる値の数は数えない。
    """
    if not len(raw):
        return raw.copy()
    boundaries = reset | np.r_[True, raw[1:] != raw[:-1]]
    starts = np.maximum.accumulate(np.where(boundaries, np.arange(len(raw)), 0))
    covered = times - times[starts] >= confirmation_seconds
    return np.where((raw != 0) & covered, raw, 0).astype(np.int8)


def edge_directions(directions: np.ndarray, reset: np.ndarray) -> np.ndarray:
    """
    機能: 確認済み方向への再遷移、または履歴reset後の最初の非0行だけを残す。
    引数: directions（np.ndarray[N]）確認後方向、reset（np.ndarray[N]）場・限月・gap等の境界。
    返り値: np.ndarray[N]int8。Source163EDGEと同じ行遷移型の出生方向。
    """
    if not len(directions):
        return directions.copy()
    previous = np.r_[np.int8(0), directions[:-1]]
    return np.where((directions != previous) | reset, directions, 0).astype(np.int8)


def build(features: object) -> dict:
    """
    機能: 当時特徴だけから固定152候補の主入口出生を作る。旧方向の待機時補完へ限定しない。
    引数: features（object）buy_X/sell_X/columns/q0_meta/scene_starts/phasesを持つ辞書または属性束。
          q0_metaの各行はsession_index/q0_time/contractを持つ。金融・決済・教師は受け取らない。
    返り値: dict。mode適用済みdirections[152,N]int8、candidate_ids、phases[N]、状態診断。
    """
    prepared = _prepare(features)
    source_catalog = catalog()
    rules = source_catalog["rules"]
    matrix = np.zeros((len(rules), len(prepared["times"])), dtype=np.int8)
    raw_cache, confirmed_cache = {}, {}
    for index, rule in enumerate(rules):
        raw_key = (rule["legacy_formula"], rule["after_minutes"], rule["minimum_score"],
                   rule["adverse_rsi_delta_max"], rule["volume_min"])
        if raw_key not in raw_cache:
            raw_cache[raw_key] = _raw_directions(prepared, rule)[0]
        confirmation_key = raw_key + (rule["confirmation_minutes"],)
        reset = prepared["old_history_reset"] if rule["legacy_formula"] else prepared["new_history_reset"]
        if confirmation_key not in confirmed_cache:
            confirmed_cache[confirmation_key] = confirmation_directions(
                raw_cache[raw_key], prepared["times"], reset, rule["confirmation_minutes"] * 60)
        confirmed = confirmed_cache[confirmation_key]
        matrix[index] = confirmed if rule["mode"] == "ALL" else edge_directions(confirmed, reset)
    return {"version": VERSION, "candidate_ids": [rule["id"] for rule in rules], "directions": matrix,
            "phases": prepared["phases"].copy(),
            "diagnostics": {"score_known": prepared["score_known"], "gate_known": prepared["gate_known"],
                            "current_m15_hist_available": prepared["current_available"],
                            "legacy_seen_m15_hist": prepared["old_seen"], "new_seen_m15_hist": prepared["new_seen"],
                            "legacy_history_reset": prepared["old_history_reset"],
                            "new_history_reset": prepared["new_history_reset"], "elapsed_seconds": prepared["elapsed"]}}
