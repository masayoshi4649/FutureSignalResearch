"""Rootの固定Source指紋を照合してからLOCAL173出生を保存する。自然データloaderは持たない。"""

from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def fingerprint(path: Path) -> dict:
    """
    機能: ファイルのサイズとSHA256を計算する。
    引数: path（Path）対象ファイル。
    返り値: dict。リポジトリ相対path、bytes、sha256。
    """
    raw = path.read_bytes()
    return {"path": path.resolve().relative_to(ROOT.resolve()).as_posix(), "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest()}


def save_birth(features: object, output_directory: str | Path, fixed_source_sha256: dict,
               input_fingerprints: dict) -> dict:
    """
    機能: RootF1の指紋と出生Sourceを照合し、既にmode適用済みの出生・proof・manifestを保存する。
    引数: features（object）buildの当時入力、output_directory（str | Path）repo内出力先、
          fixed_source_sha256（dict[str,str | dict]）RootF1のrepo相対Source→sha256または指紋辞書、
          input_fingerprints（dict[str,dict]）repo相対path→bytes/sha256の固定当時入力指紋。
          fixed_source_sha256には当時入力も含むRootF1指紋辞書を渡す。金融・ラベルの入力は不要。
    返り値: dict。LOCAL173のmanifest。金融や自然入力のファイルは本関数から読まない。
    """
    destination = Path(output_directory).resolve()
    if not destination.is_relative_to(ROOT.resolve()):
        raise ValueError("出生保存先はリポジトリ内で明示する。")
    if not input_fingerprints:
        raise ValueError("当時入力の固定指紋を空にしない。")
    for name, item in input_fingerprints.items():
        if not isinstance(name, str) or Path(name).is_absolute() or not (ROOT / name).resolve().is_relative_to(ROOT.resolve()):
            raise ValueError("入力指紋のkeyはrepo相対pathにする。")
        if (not isinstance(item, dict) or not isinstance(item.get("bytes"), int) or item["bytes"] < 0
                or not isinstance(item.get("sha256"), str) or len(item["sha256"]) != 64
                or any(character not in "0123456789abcdef" for character in item["sha256"])):
            raise ValueError("入力指紋にはbytesと小文字SHA256を指定する。")
        fixed_item = fixed_source_sha256.get(name)
        expected = fixed_item.get("sha256") if isinstance(fixed_item, dict) else fixed_item
        if expected != item["sha256"] or (isinstance(fixed_item, dict) and "bytes" in fixed_item and fixed_item["bytes"] != item["bytes"]):
            raise ValueError("当時入力の指紋がRootF1と一致しない。")
    source_names = ("local173.py", "SourceCatalog.json", "人工検査.py", "人工結果.json", "出生を保存する.py")
    sources = {}
    for name in source_names:
        item = fingerprint(HERE / name)
        expected = fixed_source_sha256.get(item["path"])
        if isinstance(expected, dict):
            expected = expected.get("sha256")
        if expected != item["sha256"]:
            raise ValueError(f"RootF1とLOCAL出生Sourceの指紋が一致しない: {item['path']}")
        sources[item["path"]] = {"bytes": item["bytes"], "sha256": item["sha256"]}
    source_catalog = json.loads((HERE / "SourceCatalog.json").read_text(encoding="utf-8"))
    artificial = json.loads((HERE / "人工結果.json").read_text(encoding="utf-8"))
    if artificial.get("結果") != "全検査成功" or artificial.get("自然金融入力読込") is not False:
        raise ValueError("人工検証の完了記録を確認できない。")
    for name, expected in artificial.get("SourceSHA256", {}).items():
        item = sources.get((HERE / name).relative_to(ROOT).as_posix())
        if item is None or item["sha256"] != expected:
            raise ValueError("人工結果と現在Sourceの指紋が一致しない。")
    specification = importlib.util.spec_from_file_location("local173_fixed_birth", HERE / "local173.py")
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    if module.catalog() != source_catalog:
        raise ValueError("SourceのCatalogと固定JSONが一致しない。")
    result = module.build(features)
    ids = [row["id"] for row in source_catalog["rules"]]
    if result["candidate_ids"] != ids or result["directions"].shape != (152, len(result["phases"])):
        raise ValueError("出生の候補順序または形が固定Catalogと一致しない。")
    destination.mkdir(parents=True, exist_ok=True)
    birth_path = destination / "出生173LOCAL.npz"
    np.savez_compressed(birth_path, directions=result["directions"], phases=result["phases"])
    birth = fingerprint(birth_path)
    birth.update({"layout": "declared", "array_name": "directions"})
    proof = {"source": "LOCAL173", "version": result["version"], "layout": "declared",
             "candidate_count": 152, "shape": list(result["directions"].shape),
             "phase_counts": {str(band): int(np.count_nonzero(result["phases"] == band)) for band in (0, 1, 2)},
             "source_fingerprints": sources, "input_fingerprints": input_fingerprints,
             "catalog_sha256": sources[(HERE / "SourceCatalog.json").relative_to(ROOT).as_posix()]["sha256"],
             "birth": birth, "declared_modes_already_applied": True,
             "financial_inputs_read_by_generator": False}
    proof_path = destination / "出生完了173LOCAL.json"
    proof_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    manifest = {"source": "LOCAL173", "ids": ids, "families": [row["family"] for row in source_catalog["rules"]],
                "declared_modes": [row["mode"] for row in source_catalog["rules"]],
                "birth": birth, "proof": fingerprint(proof_path)}
    (destination / "出生manifest173LOCAL.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    return manifest
