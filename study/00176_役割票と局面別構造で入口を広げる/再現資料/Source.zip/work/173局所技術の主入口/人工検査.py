"""局所主入口152候補を、自然特徴・金融なしで旧式・独立参照・未来なしに照合する。"""

from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np

import local173 as M

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def load_module(name: str, path: Path):
    """
    機能: 自然入力を読まない指定Sourceだけを独立名で読み込む。
    引数: name（str）module名、path（Path）Sourceの場所。
    返り値: module。読み込んだPython部品。
    """
    specification = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def synthetic(times: list[float], scenes: list[int] | None = None, contracts: list[str] | None = None) -> dict:
    """
    機能: 買い6票・売り1票の人工当時特徴を作る。
    引数: times（list[float]）当時秒、scenes（list[int] | None）場番号、contracts（list[str] | None）限月。
    返り値: dict。buildへ渡せる人工特徴束。M15増分は初期状態ですべて未知。
    """
    n = len(times)
    columns = list(M.GATE_COLUMNS) + [M.AVAILABILITY_COLUMN]
    values = {
        "m5_ema21_delta_to_side": (1, -1), "m5_di_difference_to_side": (1, -1),
        "m5_hist_delta_to_side": (1, -1), "m5_rsi_delta_to_side": (1, -1),
        "m5_body_ratio_to_side": (0.4, -0.4), "m5_close_position_to_side": (0.8, 0.2),
        "m1_volume_relative_prior3": (1, 1), "m5_rsi_center_to_side": (10, -10),
        "q0_entry_minus_ema8_atr5_to_side": (0.2, -0.2), "m5_tr_atr_ratio": (1, 1),
        "q0_spread_points": (5, 5), "q0_last_minus_m1_close_atr5_to_side": (0.1, -0.1),
        M.AVAILABILITY_COLUMN: (np.nan, np.nan),
    }
    buy = np.empty((n, len(columns)))
    sell = np.empty_like(buy)
    for index, column in enumerate(columns):
        buy[:, index], sell[:, index] = values[column]
    scenes = [0] * n if scenes is None else scenes
    contracts = ["人工A"] * n if contracts is None else contracts
    meta = [{"session_index": scenes[row], "q0_time": times[row], "contract": contracts[row]}
            for row in range(n)]
    return {"buy_X": buy, "sell_X": sell, "columns": columns, "q0_meta": meta,
            "scene_starts": np.zeros(max(scenes, default=0) + 1), "phases": np.zeros(n, dtype=np.int8)}


def direction(result: dict, candidate_id: str) -> np.ndarray:
    """
    機能: 候補IDから検査対象の方向行を取得する。
    引数: result（dict）buildの返り値、candidate_id（str）固定ID。
    返り値: np.ndarray[N]。該当方向。
    """
    return result["directions"][result["candidate_ids"].index(candidate_id)]


def reference_confirm(raw: np.ndarray, times: np.ndarray, reset: np.ndarray, seconds: int) -> np.ndarray:
    """
    機能: 各行を順に処理する独立参照で、実時間の方向持続を判定する。
    引数: raw（np.ndarray）確認前方向、times（np.ndarray）当時秒、reset（np.ndarray）境界、seconds（int）必要秒。
    返り値: np.ndarray。確認後方向。
    """
    output = np.zeros_like(raw)
    start, previous = None, 0
    for row, side in enumerate(raw):
        if reset[row] or side != previous:
            start = times[row]
        if side and times[row] - start >= seconds:
            output[row] = side
        previous = side
    return output


def reference_edge(raw: np.ndarray, scenes: np.ndarray, times: np.ndarray, contracts: list[str] | None = None) -> np.ndarray:
    """
    機能: 行ごとの独立参照でSource163型EDGEを計算する。
    引数: raw（np.ndarray）確認後方向、scenes（np.ndarray）場、times（np.ndarray）秒、contracts（list[str] | None）新規限月境界。
    返り値: np.ndarray。同方向連続行を落とした出生。
    """
    output = np.zeros_like(raw)
    for row, side in enumerate(raw):
        reset = row == 0 or scenes[row] != scenes[row - 1] or times[row] - times[row - 1] > 180
        if contracts is not None and row and contracts[row] != contracts[row - 1]:
            reset = True
        if reset or side != raw[row - 1]:
            output[row] = side
    return output


def main() -> None:
    """
    機能: 旧4同式・対称性・接頭・未知・実時間・resetを人工検査し、Catalogと結果を固定する。
    引数: なし。
    返り値: None。自然金融データを読まず、SourceCatalogと人工検査結果を保存する。
    """
    source_catalog = M.catalog()
    rules = source_catalog["rules"]
    assert len(rules) == 152 and len({rule["id"] for rule in rules}) == 152
    assert sum(rule["legacy_formula"] for rule in rules) == 8
    assert {rule["mode"] for rule in rules} == {"ALL", "EDGE"}
    legacy_path = ROOT / "work/166可用指標の階層化/local166.py"
    legacy = load_module("legacy166_artificial_only", legacy_path)
    random_source = np.random.default_rng(173)
    legacy_comparisons, mirror_comparisons, reference_comparisons = 0, 0, 0
    for case in range(300):
        n = int(random_source.integers(0, 41))
        times = (10800 + np.arange(n) * 60).tolist()
        features = synthetic(times)
        if n:
            perturb = random_source.normal(0, 0.35, features["buy_X"].shape)
            perturb[:, -1] = 0
            features["buy_X"] += perturb
            features["sell_X"] -= perturb
            for side in ("buy_X", "sell_X"):
                missing = random_source.random(features[side].shape) < 0.015
                features[side][missing] = np.nan
            if case % 3 == 0:
                features["buy_X"][n // 2, -1] = 0
            if case % 4 == 0:
                for row in range(n // 2, n):
                    features["q0_meta"][row]["contract"] = "人工B"
            if case % 5 == 0:
                for row in range(n // 2, n):
                    features["q0_meta"][row]["q0_time"] += 400
        actual = M.build(features)
        scenes = np.array([row["session_index"] for row in features["q0_meta"]])
        actual_times = np.array([row["q0_time"] for row in features["q0_meta"]])
        contracts = [row["contract"] for row in features["q0_meta"]]
        for after in (120, 180):
            for score in (4, 5):
                expected = legacy.evaluate_local(features["buy_X"], features["sell_X"], features["columns"],
                                                 features["q0_meta"], features["scene_starts"], after, score)
                assert np.array_equal(direction(actual, f"L166_L{after}_S{score}_ALL"), expected["directions"])
                assert np.array_equal(direction(actual, f"L166_L{after}_S{score}_EDGE"), reference_edge(expected["directions"], scenes, actual_times))
                assert np.array_equal(actual["diagnostics"]["legacy_seen_m15_hist"], expected["seen_m15_hist"])
                legacy_comparisons += 1
        mirrored = dict(features, buy_X=features["sell_X"], sell_X=features["buy_X"])
        assert np.array_equal(M.build(mirrored)["directions"], -actual["directions"])
        mirror_comparisons += 152
        raw = random_source.choice(np.array([-1, 0, 1], dtype=np.int8), size=n)
        reset = actual["diagnostics"]["new_history_reset"]
        for seconds in (0, 120, 300):
            assert np.array_equal(M.confirmation_directions(raw, actual_times, reset, seconds), reference_confirm(raw, actual_times, reset, seconds))
            reference_comparisons += 1
        assert np.array_equal(M.edge_directions(raw, reset), reference_edge(raw, scenes, actual_times, contracts))
        reference_comparisons += 1

    # ----------------------------------------
    # M15有限0からのeverはgapでも消さず、別限月へ移っても旧限月へ戻れば既知を覚えている。
    state = synthetic([10800, 10860, 10920, 11000, 11600, 11660, 11720], contracts=["人工A"] * 5 + ["人工B", "人工A"])
    state["buy_X"][1, -1] = 0
    state_result = M.build(state)
    assert state_result["diagnostics"]["new_seen_m15_hist"].tolist() == [False, True, True, True, True, False, True]
    assert direction(state_result, "L173_L180_S4_P0_R12_V050_ALL").tolist() == [1, 0, 0, 0, 0, 1, 0]
    assert direction(state_result, "L166_L180_S4_ALL").tolist() == [1, 0, 0, 0, 0, 0, 0]
    scene = synthetic([10800, 10860, 10800, 10860], scenes=[0, 0, 1, 1])
    scene["buy_X"][0, -1] = 0
    assert M.build(scene)["diagnostics"]["new_seen_m15_hist"].tolist() == [True, True, False, False]
    known_future = synthetic([10800 + row * 60 for row in range(16)])
    known_future["buy_X"][10, -1] = 0
    full = M.build(known_future)
    prefix_count = 0
    for end in range(17):
        prefix = dict(known_future, buy_X=known_future["buy_X"][:end], sell_X=known_future["sell_X"][:end],
                      q0_meta=known_future["q0_meta"][:end], phases=known_future["phases"][:end])
        assert np.array_equal(M.build(prefix)["directions"], full["directions"][:, :end])
        prefix_count += 152
    poison = copy.deepcopy(known_future)
    poison["buy_X"][8:] = np.inf
    poison["sell_X"][8:] = np.nan
    assert np.array_equal(M.build(poison)["directions"][:, :8], full["directions"][:, :8])

    # ----------------------------------------
    # 値が同じ5分入力でも実時間で2/5分を確認する。行数・新しい足数では判定しない。
    steady = M.build(synthetic([10800 + row * 60 for row in range(6)]))
    assert direction(steady, "L173_L180_S4_P2_R12_V050_ALL").tolist() == [0, 0, 1, 1, 1, 1]
    assert direction(steady, "L173_L180_S4_P5_R12_V050_ALL").tolist() == [0, 0, 0, 0, 0, 1]
    assert direction(steady, "L173_L180_S4_P2_R12_V050_EDGE").tolist() == [0, 0, 1, 0, 0, 0]
    duplicate = M.build(synthetic([10800] * 10))
    assert not direction(duplicate, "L173_L180_S4_P2_R12_V050_ALL").any()
    exact_gap = M.build(synthetic([10800, 10920, 11100]))
    assert direction(exact_gap, "L173_L180_S4_P5_R12_V050_ALL").tolist() == [0, 0, 1]
    excess_gap = M.build(synthetic([10800, 10920, 11101]))
    assert direction(excess_gap, "L173_L180_S4_P5_R12_V050_ALL").tolist() == [0, 0, 0]
    unknown = synthetic([10800 + row * 60 for row in range(5)])
    unknown["buy_X"][1, 0] = np.nan
    unknown_result = M.build(unknown)
    assert direction(unknown_result, "L173_L180_S4_P2_R12_V050_ALL").tolist() == [0, 0, 0, 0, 1]
    opposite_unknown = synthetic([10800])
    opposite_unknown["sell_X"][0, 0] = np.nan
    assert not M.build(opposite_unknown)["directions"].any()
    spike = synthetic([10800])
    delta_index = spike["columns"].index("m5_rsi_delta_to_side")
    spike["buy_X"][0, delta_index] = -10
    spike_result = M.build(spike)
    assert direction(spike_result, "L173_L180_S4_P0_R8_V050_ALL")[0] == 0
    assert direction(spike_result, "L173_L180_S4_P0_R12_V050_ALL")[0] == 1
    spike["buy_X"][0, delta_index] = 10
    assert direction(M.build(spike), "L173_L180_S4_P0_R8_V050_ALL")[0] == 1
    volume = synthetic([10800])
    volume_index = volume["columns"].index("m1_volume_relative_prior3")
    volume["buy_X"][:, volume_index] = volume["sell_X"][:, volume_index] = 0.6
    volume_result = M.build(volume)
    assert direction(volume_result, "L173_L180_S4_P0_R12_V050_ALL")[0] == 1
    assert direction(volume_result, "L173_L180_S4_P0_R12_V075_ALL")[0] == 0
    assert np.array_equal(full["phases"], known_future["phases"])

    # ----------------------------------------
    # 固定辞書・Source指紋・人工完了のみを保存する。自然出生は実行しない。
    (HERE / "SourceCatalog.json").write_text(json.dumps(source_catalog, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    sources = {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
               for name in ("local173.py", "人工検査.py", "出生を保存する.py", "SourceCatalog.json")}
    result = {"確認日": "2026-11-15", "自然金融入力読込": False, "候補数": 152, "mode適用済み": True,
              "旧166同式照合ケース": legacy_comparisons, "売買鏡像照合候補数": mirror_comparisons,
              "持続とEDGE独立照合ケース": reference_comparisons, "接頭照合候補数": prefix_count,
              "検査": ["旧4規則の方向とM15ever完全同式", "旧EDGEはSource163と同じ場/gap reset",
                       "M15有限0は既知", "M15everをgapで消さない", "場と限月の組で既知を記憶",
                       "未知を0票にしない", "5分値の不変と実時間coverageを区別", "同時刻行数で持続を水増ししない",
                       "gap180秒と181秒", "現在行を含む公表停止", "売買同式", "全接頭一致と未来毒",
                       "逆方向RSIΔ上限と正方向RSIΔを区別", "量の有限閾値", "phasesを無加工で継承"],
              "SourceSHA256": sources, "旧166SourceSHA256": hashlib.sha256(legacy_path.read_bytes()).hexdigest(),
              "結果": "全検査成功"}
    (HERE / "人工結果.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    hashes = {name: hashlib.sha256((HERE / name).read_bytes()).hexdigest()
              for name in (*sources.keys(), "人工結果.json", "README.md")}
    (HERE / "SHA256.json").write_text(json.dumps(hashes, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    # ----------------------------------------
    # 自然loaderを使わず、人工特徴だけで固定指紋・NPZ・proof・manifestの接続も照合する。
    writer = load_module("local173_writer_artificial_only", HERE / "出生を保存する.py")
    fixed = {(HERE / name).relative_to(ROOT).as_posix(): sha for name, sha in hashes.items()}
    artificial_destination = HERE / "人工保存のみ"
    artificial_input = writer.fingerprint(Path(__file__))
    manifest = writer.save_birth(synthetic([10800 + row * 60 for row in range(6)]), artificial_destination,
                                 fixed, {artificial_input["path"]: {"bytes": artificial_input["bytes"], "sha256": artificial_input["sha256"]}})
    assert manifest["source"] == "LOCAL173"
    assert manifest["ids"] == [rule["id"] for rule in rules]
    assert manifest["declared_modes"] == [rule["mode"] for rule in rules]
    for key in ("birth", "proof"):
        record = manifest[key]
        raw = (ROOT / record["path"]).read_bytes()
        assert len(raw) == record["bytes"] and hashlib.sha256(raw).hexdigest() == record["sha256"]
    with np.load(ROOT / manifest["birth"]["path"], allow_pickle=False) as saved:
        assert set(saved.files) == {"directions", "phases"}
        assert np.array_equal(saved["directions"], steady["directions"])
        assert saved["directions"].shape == (152, 6)
    rejected = False
    try:
        writer.save_birth(synthetic([]), artificial_destination, {},
                          {artificial_input["path"]: {"bytes": artificial_input["bytes"], "sha256": artificial_input["sha256"]}})
    except ValueError:
        rejected = True
    assert rejected
    save_result = {"自然金融入力読込": False, "入力": "人工6行のみ", "候補数": 152,
                   "検査": ["RootF1指紋必須", "空指紋拒否", "Sourceと人工結果とCatalogの一致",
                            "declared出生NPZのshapeとmode", "manifest順序とbirth/proof物理指紋"],
                   "結果": "全検査成功"}
    (HERE / "保存人工結果.json").write_text(json.dumps(save_result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    hashes["保存人工結果.json"] = hashlib.sha256((HERE / "保存人工結果.json").read_bytes()).hexdigest()
    (HERE / "SHA256.json").write_text(json.dumps(hashes, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"候補": 152, "旧照合": legacy_comparisons, "結果": "成功"}, ensure_ascii=True))


if __name__ == "__main__":
    main()
