"""176固定少数案の純出生を封印し、追加七場と全80場を参考評価する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import copy
import gzip
import hashlib
import json
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'work/175局面別入口の再探索'))
import 基盤175 as BASE
sys.path.insert(0,str(ROOT/'work/175経路と支持の評価'))
import path175 as RISK
B=BASE.B
FIXED=ROOT/'work/176役割票入口の再探索/旧73の固定選択.json'
OLD_REPORT=ROOT/'work/176役割票入口の再探索/三帯接合.json.gz'
OLD_BIRTH=ROOT/'work/176役割票入口の再探索/純出生176.npz'
CATALOG=ROOT/'work/176局面別の役割票/候補辞書176.json'
BUILDER=ROOT/'work/176局面別の役割票/rules176.py'
STAGE_SOURCE=ROOT/'work/175局面別入口の再探索/数量段階を進める.py'
HORIZONS=['H30','H60','H120','SESSION']


def physical(path: Path) -> dict:
    """
    機能: Sourceと純入力の物理指紋を返す。
    引数: path(Path)はリポジトリ内ファイル。
    返り値: dictはpath/bytes/sha256。
    """
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':path.resolve().relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':digest}


def save(path: Path, value: dict) -> None:
    """
    機能: 非有限値を拒否し、JSON又はgzipをUTF-8で新規保存する。
    引数: path(Path)、value(dict)。
    返り値: None。既存成果物を上書きしない。
    """
    assert not path.exists(),path
    raw=(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode('utf-8')
    path.write_bytes(gzip.compress(raw,mtime=0) if path.suffix=='.gz' else raw)


def fixed_policies(expected_sha: str) -> list:
    """
    機能: Rootが指定した固定SHAの全期/前48各最大二案だけを返す。
    引数: expected_sha(str)はGO時に指定される固定票のSHA256。
    返り値: list[dict]は保存順の固定政策。再選択を行わない。
    """
    assert len(expected_sha)==64 and physical(FIXED)['sha256']==expected_sha.lower()
    body=B.P.read(FIXED);assert body['成功'] and body['追加7当該候補金融未読']
    policies=[]
    for route in ('全期','前48'):
        values=body['選択'][route]['candidates']
        assert len(values)<=2 and all(p['route']==route and p['band']=='JOINT' for p in values)
        for policy in values:
            assert set(policy['options'])=={'DAY','PRE','POST'}
            for rules in policy['options'].values():
                assert len(rules)<=6 and len({r['family'] for r in rules})==len(rules)
        policies.extend(values)
    assert policies and len({p['id'] for p in policies})==len(policies)
    return policies


def sources() -> list:
    """
    機能: 再現Sourceと固定純入力の一覧を作る。
    引数: なし。
    返り値: list[Path]。旧金融reportは出生封印後に別途指紋を取る。
    """
    declared=[Path(__file__),HERE/'README.md',FIXED,OLD_BIRTH,OLD_BIRTH.with_suffix('.json'),CATALOG,BUILDER,STAGE_SOURCE,
        ROOT/'work/176役割票入口の再探索/準備と予備評価.py',
        ROOT/'study/00176_役割票と局面別構造で入口を広げる/条件.json',
        ROOT/'work/173追加なしの因果再生/engine173.py',ROOT/'work/173追加なしの評価/metrics173.py',
        ROOT/'work/163任意幅の数値化/arrays163.py',ROOT/'work/166可変場の数値化/arrays166.py']
    loaded=[]
    for module in list(sys.modules.values()):
        name=getattr(module,'__file__',None)
        if not name:continue
        path=Path(name).resolve()
        if path.suffix=='.py' and path.is_relative_to(ROOT):loaded.append(path)
    return sorted(set(declared+loaded))


def selected_rules(policies: list) -> dict:
    """
    機能: 幅期限だけが異なる重複を除き、birth_keyごとの純条件を返す。
    引数: policies(list[dict])は固定政策。
    返り値: dict[str,dict]は正逆・modeが一意の入口。
    """
    result={}
    for policy in policies:
        for rules in policy['options'].values():
            for rule in rules:
                assert rule['orientation'] in ('NORMAL','REVERSE')
                assert rule['birth_key']==rule['rule_id']+'/'+rule['orientation']
                key=rule['birth_key']
                if key in result:
                    assert all(result[key][name]==rule[name] for name in ('rule_id','orientation','mode'))
                result[key]=rule
    return result


def build_directions(features: object, policies: list, builder: object) -> tuple:
    """
    機能: mode既適用の176純方向にbirth_keyの正逆を一回だけ適用する。
    引数: features(object)、policies(list[dict])、builder(object)は176の純生成部品。
    返り値: tuple[dict,dict]はbirth_key方向と、正逆適用前のrule_id方向。金融を入力しない。
    """
    rules=selected_rules(policies);ids=sorted({r['rule_id'] for r in rules.values()})
    catalog={r['id']:r for r in B.P.read(CATALOG)['rules']}
    assert all(catalog[r['rule_id']]['mode']==r['mode'] for r in rules.values())
    born=builder.build(features,np.asarray([s['start'] for s in features.scenes]),features.q0_timeband,candidate_ids=ids)
    assert born['candidate_ids']==ids and born['directions'].shape==(len(ids),len(features.q0_meta))
    assert np.isin(born['directions'],(-1,0,1)).all()
    assert np.array_equal(born['phases'],features.q0_timeband)
    raw={name:born['directions'][i].copy() for i,name in enumerate(ids)}
    directions={key:(raw[r['rule_id']].copy() if r['orientation']=='NORMAL' else -raw[r['rule_id']]) for key,r in rules.items()}
    return directions,raw


def freeze_births(policies: list, before: dict, builder: object) -> dict:
    """
    機能: 旧73出生の一致を確認し、両期間の純出生を金融読込前に封印する。
    引数: policies(list[dict])、before(dict)はSource指紋、builder(object)は純生成部品。
    返り値: dictは純入力指紋・出生参照・一致確認。
    """
    data=B.P.R168.BASE.data_module();old=data.load_feature_dataset()
    added_dir=ROOT/'inputs/00167_追加七場の入口と共用価格索引/入口母集団'
    added,_,_=B.P.R168.BASE.load_features(added_dir)
    inputs=[ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only/features.npz',
        ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only/features_meta.json',
        *[added_dir/name for name in ('完了.json','当時特徴.json.gz','固定取得入力.json.gz','取得対応.json.gz')]]
    proof={'成功':True,'金融内容未入力':True,'追加7金融未読':True,'Sourceと固定選択':before,
        '非金融入力':{p.relative_to(ROOT).as_posix():physical(p) for p in inputs},'期間':{}}
    old_proof=B.P.read(OLD_BIRTH.with_suffix('.json'))
    assert old_proof['金融未入力'] and physical(OLD_BIRTH)['sha256']==old_proof['出生SHA256']
    catalog=B.P.read(CATALOG)['rules'];lookup={r['id']:i for i,r in enumerate(catalog)}
    for period,features in (('旧73',old),('追加7',added)):
        directions,raw=build_directions(features,policies,builder)
        if period=='旧73':
            with np.load(OLD_BIRTH,allow_pickle=False) as sealed:
                assert np.array_equal(sealed['phases'],features.q0_timeband)
                matrix=sealed['directions']
                assert matrix.shape==(len(catalog),len(features.q0_meta))
                assert all(np.array_equal(value,matrix[lookup[name]]) for name,value in raw.items())
                assert all(np.array_equal(value,matrix[lookup[r['rule_id']]]*(1 if r['orientation']=='NORMAL' else -1))
                    for key,value in directions.items() for r in [selected_rules(policies)[key]])
        arrays={'phases':features.q0_timeband};counts=[]
        for policy in policies:
            birth,mw,fw,hi,component,conflict=BASE.compose(features.q0_timeband,policy['options'],directions,HORIZONS)
            assert not birth['technical'].any() and not birth['tier'].any()
            prefix=policy['id']+'__'
            arrays.update({prefix+key:value for key,value in birth.items()})
            arrays.update({prefix+key:value for key,value in [('mw',mw),('fw',fw),('hi',hi),('component',component),('conflict',conflict)]})
            counts.append({'id':policy['id'],'主成立q0':int(np.count_nonzero(birth['core'])),
                '旧T成立q0':int(np.count_nonzero(birth['technical'])),'競合q0':int(conflict.sum())})
        target=HERE/(period+'の純出生176.npz');assert not target.exists();np.savez_compressed(target,**arrays)
        proof['期間'][period]={'場順':[s['session'] for s in features.scenes],'q0数':len(features.q0_meta),
            '出生':physical(target),'birth_key数':len(directions),'必要rule_id数':len(raw),'診断':counts,
            '旧選定純出生一致':period=='旧73','mode既適用・正逆一回':True}
    assert all(physical(ROOT/name)==value for name,value in before.items())
    assert all(physical(ROOT/name)==value for name,value in proof['非金融入力'].items())
    save(HERE/'金融前の出生固定.json',proof);return proof


def ledger(context: object, value: tuple) -> dict:
    """
    機能: 実取得を金融未知None・実セッションIDの台帳へ写す。
    引数: context(object)、value(tuple)は追加禁止再生の実取得。
    返り値: dictはnet/known/label/scene。
    """
    selected,_,wi,hi,_,_=value;key=(selected.cases,selected.sides,wi,hi);known=context.arrays['known'][key]
    return {'net':[float(n) if k else None for n,k in zip(context.arrays['net'][key],known,strict=True)],
        'known':known.tolist(),'label':context.arrays['label'][key].tolist(),
        'scene':[context.sessions[int(i)] for i in context.case_scene[selected.cases]]}


def paths(financial: dict) -> dict:
    """
    機能: 三帯・Night・全体の完全な経路/支持診断を作る。
    引数: financial(dict)はmetrics173の全場評価。
    返り値: dictは小型化しないpath175診断。
    """
    groups={**financial['phases_diagnostic'],'NIGHT':financial['session_groups_required']['NIGHT'],'ALL':financial['all_reference']}
    return {name:RISK.path_summary(group) for name,group in groups.items()}


def period_evidence(context: object, value: tuple, stage: object) -> tuple:
    """
    機能: 旧数量段階と同じ三期間/四帯の金融群と経路を再構成する。
    引数: context(object)、value(tuple)、stage(object)は小型化のみを借りる固定Source。
    返り値: tuple[dict,dict,dict]は群・比較用小型経路・完全経路。
    """
    selected=value[0];scene=context.case_scene[selected.cases]
    labels=context.arrays['label'][selected.cases,selected.sides,value[2],value[3]]
    periods={};compact={};full={}
    for name,eligible in [('全期',np.ones(len(context.scenes),bool)),('前48',np.arange(len(context.scenes))<48),('後25',np.arange(len(context.scenes))>=48)]:
        metric=B.financial(context,value,eligible[scene],eligible)
        groups={**metric['phases_diagnostic'],'NIGHT':metric['session_groups_required']['NIGHT']}
        periods[name]={};compact[name]={};full[name]={}
        for field in ('DAY','PRE','POST','NIGHT'):
            group=groups[field]
            phase=selected.phases>0 if field=='NIGHT' else selected.phases==('DAY','PRE','POST').index(field)
            resolved=eligible[scene]&phase&np.isin(labels,(-1,1))
            counts=np.bincount(scene[resolved],minlength=len(context.scenes))
            group['resolved_scene_count']=int((counts>0).sum());group['max_resolved_scene_count']=int(counts.max())
            risk=RISK.path_summary(group);full[name][field]=risk;compact[name][field]=stage.compact_risk(risk)
            group.pop('origins',None);group.pop('concentration',None);periods[name][field]=group
    return periods,compact,full


def pack(context: object, value: tuple, policy: dict) -> dict:
    """
    機能: 173/174共通の取得packと金融/台帳/完全経路を生成する。
    引数: context(object)、value(tuple)、policy(dict)。
    返り値: dict。widths/horizonsは共用軸の添字であり値幅そのものではない。
    """
    selected,origin,wi,hi,tier,engine=value;financial=B.financial(context,value)
    return {'id':policy['id'],'policy':policy,'cases':selected.cases.tolist(),'sides':selected.sides.tolist(),
        'events':selected.events.tolist(),'phases':selected.phases.tolist(),'origins':origin.tolist(),
        'widths':wi.tolist(),'horizons':hi.tolist(),'tiers':tier.tolist(),'engine':engine,
        'financial':financial,'ledger':ledger(context,value),'paths':paths(financial)}


def eligibility(context: object) -> tuple:
    """
    機能: 0取引場を除外せず三帯の全対象IDと時間を返す。
    引数: context(object)。
    返り値: tuple[dict,dict]は対象場と全対象時間。
    """
    names=('DAY','PRE','POST')
    return ({name:[context.sessions[i] for i in np.flatnonzero(context.hours[:,bi]>0)] for bi,name in enumerate(names)},
        {name:float(context.hours[:,bi].sum()) for bi,name in enumerate(names)})


def run(expected_sha: str) -> None:
    """
    機能: 固定少数案を出生封印後だけ金融へ接続し、全80を台帳から再計算する。
    引数: expected_sha(str)はRootのGOとともに指定された固定票SHA256。
    返り値: None。このwork内に新規成果物を保存し、固定候補を交換しない。
    """
    assert not (HERE/'金融前の出生固定.json').exists()
    policies=fixed_policies(expected_sha);ids=[p['id'] for p in policies]
    builder=B.P.module(BUILDER,'birth176_fixed_added');stage=B.P.module(STAGE_SOURCE,'stage176_added_same')
    before={p.relative_to(ROOT).as_posix():physical(p) for p in sources()}
    save(HERE/'出生前の固定.json',{'成功':True,'UTC':datetime.now(timezone.utc).isoformat(),'Sourceと固定選択':before,
        '固定選択SHA256':expected_sha.lower(),'対象ID':ids,'追加7金融未読':True,'NumPy版':np.__version__})
    proof=freeze_births(policies,before,builder);proof_ref=physical(HERE/'金融前の出生固定.json')
    # ----------------------------------------
    # この位置より前では旧金融reportや追加7金融表を読み込まない。
    report_ref=physical(OLD_REPORT);expected={r['id']:r for r in B.P.read(OLD_REPORT)['rows'] if r['id'] in ids}
    assert set(expected)==set(ids);reports={};checks=[]
    for new,period in ((False,'旧73'),(True,'追加7')):
        context=B.load_context(new);assert context.sessions==proof['期間'][period]['場順']
        birth_path=HERE/(period+'の純出生176.npz');assert physical(birth_path)==proof['期間'][period]['出生']
        rows=[]
        with np.load(birth_path,allow_pickle=False) as sealed:
            assert np.array_equal(sealed['phases'],context.event_phases)
            for policy in policies:
                prefix=policy['id']+'__';birth={key:sealed[prefix+key] for key in ('core','branches','technical','tier')}
                assert not birth['technical'].any() and not birth['tier'].any()
                mw,fw,hi=[sealed[prefix+key] for key in ('mw','fw','hi')]
                value=B.replay(context,birth,mw,fw,hi,False)
                evidence,compact,full=period_evidence(context,value,stage)
                reserved=max((a['peak_global_reserved'] for a in value[-1]['audits']),default=0)
                assert reserved<=1 and not (value[1]==2).any()
                if not new:
                    original=expected[policy['id']]
                    assert original['policy']==policy and evidence==original['periods'] and compact==original['paths'],policy['id']
                    assert len(value[0].cases)==original['count'] and reserved==original['max_reserved']
                    assert int(sealed[prefix+'conflict'].sum())==original['conflict_q0']
                    assert sum(a['skipped_held_core'] for a in value[-1]['audits'])==original['held_rejected']
                    checks.append({'id':policy['id'],'旧73三期間四帯金融と小型経路一致':True,'旧73取得数・占有監査一致':True})
                row=pack(context,value,policy);row.update({'periods':evidence,'period_paths':full});rows.append(row)
        eligible,hours=eligibility(context)
        reports[period]={'成功':True,'場数':len(context.scenes),'場順':context.sessions,'幅順':list(context.table.widths),
            '期限順':list(context.table.horizons),'対象場':eligible,'対象時間':hours,'出生固定':proof_ref,'rows':rows,
            '位置づけ':'旧73既使用の固定再現' if not new else '追加7既使用の参考適用。新規独立未見ではない。'}
        save(HERE/(period+'の全取得176.json.gz'),reports[period])
    # ----------------------------------------
    # 中央値や率を足さず、実セッションIDを保持した取得台帳を連結する。
    all_eligible={name:reports['旧73']['対象場'][name]+reports['追加7']['対象場'][name] for name in ('DAY','PRE','POST')}
    all_hours={name:reports['旧73']['対象時間'][name]+reports['追加7']['対象時間'][name] for name in ('DAY','PRE','POST')}
    assert not set(reports['旧73']['場順'])&set(reports['追加7']['場順'])
    all_rows=[]
    for old,added,policy in zip(reports['旧73']['rows'],reports['追加7']['rows'],policies,strict=True):
        assert old['id']==added['id']==policy['id']
        joined={name:old['ledger'][name]+added['ledger'][name] for name in ('net','known','label','scene')}
        phases=old['phases']+added['phases'];origins=old['origins']+added['origins']
        financial=B.metrics173.evaluate_metrics(joined['net'],joined['known'],joined['label'],joined['scene'],phases,origins,all_eligible,all_hours)
        all_rows.append({'id':policy['id'],'policy':policy,'financial':financial,'paths':paths(financial),
            '旧73':old['financial'],'追加7':added['financial'],'ledger':joined,'phases':phases,'origins':origins})
    total=len(reports['旧73']['場順'])+len(reports['追加7']['場順']);assert total==80
    save(HERE/'全80の両中央値176.json.gz',{'成功':True,'場数':total,'対象場':all_eligible,'対象時間':all_hours,'rows':all_rows,
        '注意':'全80既使用。未知None。完全経路と既知寄与を分離。固定候補を選び直さない。'})
    assert physical(HERE/'金融前の出生固定.json')==proof_ref and physical(OLD_REPORT)==report_ref
    assert all(physical(ROOT/name)==value for name,value in before.items())
    assert all(physical(ROOT/name)==value for name,value in proof['非金融入力'].items())
    save(HERE/'完了.json',{'成功':True,'出生固定':proof_ref,'旧金融report':report_ref,'Sourceと固定選択':before,
        '旧73同体確認':checks,'追加7':'既使用参考、未見ではない','固定候補再選択なし':True,
        'files':{p.name:physical(p) for p in HERE.iterdir() if p.is_file() and p.name!='完了.json'}})
    print(json.dumps({'成功':True,'対象ID':ids,'旧73同体':len(checks),'全80場':True,
        '取得数':{name:{r['id']:len(r['cases']) for r in report['rows']} for name,report in reports.items()}},ensure_ascii=False))


def main() -> None:
    """
    機能: RootのGOと固定SHAが与えられたときだけ自然参考適用を始める。
    引数: --expected-sha(str)は固定票SHA256、--execute(bool)はGO後の明示指定。
    返り値: None。引数なしでは自然処理を開始しない。
    """
    parser=argparse.ArgumentParser(description='176固定少数案の追加七場参考適用')
    parser.add_argument('--expected-sha',required=True);parser.add_argument('--execute',action='store_true',required=True)
    args=parser.parse_args();run(args.expected_sha)


if __name__=='__main__':main()
