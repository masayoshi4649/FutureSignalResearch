"""隔離した175/176正式runnerの読書きを監査する。"""
from pathlib import Path
import hashlib
import json
import os
import runpy
import sys
import traceback

ROOT=Path(__file__).resolve().parents[2]
ISOLATION=ROOT/'work/176隔離再現'
REPO=ISOLATION/'repo'
READS=set();WRITES=set();BLOCKED=[]


def audit(event: str, arguments: tuple) -> None:
    """
    機能: 元work・原板・feature cacheの参照と共有入力への書込を拒否する。
    引数: event(str)、arguments(tuple)はPython監査引数。
    返り値: None。禁止操作ならRuntimeError。
    """
    if event not in ('open','os.listdir','os.scandir') or not arguments:return
    raw=arguments[0]
    if not isinstance(raw,(str,bytes,os.PathLike)):return
    path=Path(os.fsdecode(raw)).resolve();reason=None
    if path.is_relative_to(ROOT/'work') and not path.is_relative_to(ISOLATION):reason='元work'
    elif path.is_relative_to(ROOT.parent/'JP_OSE_Data'):reason='原板'
    elif path.is_relative_to(ROOT) and any(p.lower() in ('cache','feature_only') for p in path.parts):reason='feature cache'
    writing=False
    if event=='open':
        mode=arguments[1] if len(arguments)>1 else None;flags=arguments[2] if len(arguments)>2 else 0
        writing=(isinstance(mode,str) and any(c in mode for c in 'wax+')) or (isinstance(flags,int) and bool(flags&(os.O_WRONLY|os.O_RDWR|os.O_APPEND|os.O_CREAT|os.O_TRUNC)))
    if writing and (path.is_relative_to(ROOT/'inputs') or path.is_relative_to(ROOT/'study')):reason='共有入力への書込'
    if reason:
        BLOCKED.append({'event':event,'path':str(path),'理由':reason});raise RuntimeError(reason+': '+str(path))
    if path.is_relative_to(ROOT):(WRITES if writing else READS).add(str(path))


def main() -> None:
    """
    機能: 元workをsys.pathから外して隔離runnerを実行し監査票を保存する。
    引数: なし。
    返り値: None。失敗時も監査票に例外を残す。
    """
    assert Path.cwd().resolve()==REPO
    sys.dont_write_bytecode=True
    sys.path[:]=[p for p in sys.path if not p or not Path(p).resolve().is_relative_to(ROOT/'work') or Path(p).resolve().is_relative_to(ISOLATION)]
    runner=REPO/'work/176正式保存/正式入力で再現する.py';sys.path.insert(0,str(runner.parent))
    sys.argv=[str(runner),'--archive',str(REPO/'artifacts/出生と比較正本.zip'),'--output',str(REPO/'work/正式runner確認')]
    own_sha=hashlib.sha256(Path(__file__).read_bytes()).hexdigest();sys.addaudithook(audit);failure=None
    try:runpy.run_path(str(runner),run_name='__main__')
    except BaseException:failure=traceback.format_exc()
    result={'成功':failure is None and not BLOCKED,'元work読込禁止':True,'原板読込禁止':True,'feature_cache読込禁止':True,
        '共有inputs_study書込禁止':True,'禁止参照':BLOCKED,'読込repoファイル':sorted(READS),'書込repoファイル':sorted(WRITES),
        '監査SourceSHA256':own_sha,'Python':sys.version,'実行環境':sys.executable,'失敗':failure}
    (REPO/'work/監査結果.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if failure:print(failure);raise SystemExit(1)
    print(json.dumps({'成功':True,'禁止参照':len(BLOCKED),'読込ファイル数':len(READS)},ensure_ascii=False))


if __name__=='__main__':main()
