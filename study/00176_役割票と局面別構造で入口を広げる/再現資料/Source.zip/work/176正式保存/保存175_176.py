"""175/176の未採用研究を、174元byte継承と小正本で一組へ正式保存する。"""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIALS={175:ROOT/'study/00175_局面別入口を累計経路と支持で探索する',176:ROOT/'study/00176_役割票と局面別構造で入口を広げる'}
PARENT=ROOT/'study/00174_共同条件を残して単一建玉の入口を広げる/再現資料'
DESTINATION=TRIALS[176]/'再現資料'
EXCLUDED_DIRS={'node_modules','__pycache__','.git','.venv','venv','.pnpm','repo','環境','仮保存','検査対象Source'}


def fingerprint(path: Path) -> dict:
    """
    機能: リポジトリ内ファイルの物理指紋を算出する。
    引数: path(Path)。
    返り値: dictは相対path/bytes/sha256。
    """
    path=path.resolve();assert path.is_relative_to(ROOT)
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':digest}


def member_reference(name: str, body: bytes) -> dict:
    """
    機能: ZIP元byteの安全名と指紋を返す。
    引数: name(str)、body(bytes)。
    返り値: dictはpath/bytes/sha256。
    """
    path=PurePosixPath(name)
    assert name and '\\' not in name and ':' not in name and not path.is_absolute() and '..' not in path.parts
    assert name==path.as_posix()
    return {'path':name,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()}


def read(path: Path) -> dict:
    """
    機能: 小型JSONを読む。
    引数: path(Path)。
    返り値: dictは解析値。
    """
    return json.loads(path.read_text(encoding='utf-8-sig'))


def inherited() -> tuple:
    """
    機能: 174正式Source全195memberと必要小入力だけを正式索引へ照合し継承する。
    引数: なし。
    返り値: tuple[dict,dict,dict]は継承参照・Source元byte・小入力元byte。
    """
    index=read(PARENT/'保存索引.json');records={};contents={}
    for key,filename in (('Source','Source.zip'),('正本','出生と比較正本.zip')):
        source=PARENT/filename;assert fingerprint(source)==index[key]['archive']
        expected={r['path']:r for r in index[key]['members']}
        names=sorted(expected) if key=='Source' else ['work/171三帯の入口切替/旧73探索/主案と前半A-Bの封印.json','work/173局所技術の主入口/SourceCatalog.json']
        members={}
        with zipfile.ZipFile(source) as archive:
            assert archive.testzip() is None and len(archive.namelist())==len(set(archive.namelist()))
            assert set(archive.namelist())==set(expected)
            for name in names:
                body=archive.read(name);assert member_reference(name,body)==expected[name],name;members[name]=body
        contents[key]=members
        records[key]={'archive':fingerprint(source),'index':fingerprint(PARENT/'保存索引.json'),
            'members':[expected[name] for name in names],'元byte継承':True}
    assert len(contents['Source'])==195
    return records,contents['Source'],contents['正本']


def work_files() -> list:
    """
    機能: 175/176自身の作業成果だけを環境/cache/隔離を除き列挙する。
    引数: なし。
    返り値: list[Path]。共有入力や原板を走査しない。
    """
    result=[]
    folders=sorted(p for p in (ROOT/'work').iterdir() if p.is_dir() and p.name.startswith(('175','176')) and '隔離再現' not in p.name)
    for folder in folders:
        for current,dirs,files in os.walk(folder,followlinks=False):
            dirs[:]=[n for n in dirs if n not in EXCLUDED_DIRS and 'cache' not in n.lower()]
            result.extend(Path(current)/name for name in files)
    return sorted(set(result))


def collect() -> tuple:
    """
    機能: 新Sourceと小正本を集め、予備統計/画像等の省略理由とSHAを残す。
    引数: なし。
    返り値: tuple[list,list,list]はSource・結果・省略指紋。
    """
    source=[];results=[];omitted=[]
    for path in work_files():
        if path.suffix in ('.py','.mjs'):
            source.append(path);continue
        if path.is_relative_to(HERE) and path.name!='README.md':continue
        if path.suffix not in ('.md','.json','.gz','.npz','.png','.jpg','.webp','.svg','.csv'):continue
        reason=None
        if path.suffix=='.npz' and '予備統計' in path.name:reason='全幅期限の予備統計は再生成中間。辞書・純出生・軸・短表・Source・指紋を保存する。'
        elif path.suffix in ('.png','.jpg','.webp','.svg'):reason='表示画像は再生成可能な中間であり、小正本への重複保存を省く。'
        elif path.suffix=='.csv':reason='閲覧CSVはoutputsの候補別正本を参照し、このZIPへ重複保存しない。'
        if reason:omitted.append({'file':fingerprint(path),'理由':reason})
        else:
            assert path.stat().st_size<16*1024*1024,('小正本上限',str(path));results.append(path)
    for trial in TRIALS.values():
        results.extend(p for p in trial.rglob('*') if p.is_file() and '再現資料' not in p.relative_to(trial).parts and p.suffix in ('.json','.md'))
    assert Path(__file__) in source and HERE/'正式入力で再現する.py' in source
    return sorted(set(source)),sorted(set(results)),sorted(omitted,key=lambda r:r['file']['path'])


def gates(extra: list, final: bool) -> dict:
    """
    機能: 固定案・自然段階・独立検査・175追加7未実行を保存前に確認する。
    引数: extra(list[Path])はRoot追加必須、final(bool)は正式保存か。
    返り値: dictは必須指紋と未採用判断。
    """
    required=[TRIALS[n]/'条件.json' for n in (175,176)]
    for n,folder in ((175,'175局面別入口の再探索'),(176,'176役割票入口の再探索')):
        required.extend(ROOT/f'work/{folder}'/name for name in ('純出生'+str(n)+'.npz','旧73の固定選択.json',
            '単独.json.gz','六局面.json.gz','Night接合.json.gz','三帯接合.json.gz','単独短表.json','帯短表.json','Night短表.json'))
        fixed=read(ROOT/f'work/{folder}/旧73の固定選択.json')
        assert fixed['成功'] and all(v['主案'] is None for v in fixed['選択'].values())
    required.extend(ROOT/'work/175固定少数の再現'/name for name in ('旧73の全取得175.json.gz','旧73の純出生175.npz','完了.json'))
    required.extend(ROOT/'work/176追加七場適用'/name for name in ('旧73の全取得176.json.gz','追加7の全取得176.json.gz','全80の両中央値176.json.gz','金融前の出生固定.json','完了.json'))
    required.extend([ROOT/'work/175数量結果の独立検査/独立検査結果.json',ROOT/'work/176固定結果の独立検査/数量四段階の独立結果.json',ROOT/'work/176固定結果の独立検査/固定四案の独立結果.json',*extra])
    assert all(p.is_file() for p in required),[str(p) for p in required if not p.is_file()]
    assert read(ROOT/'work/175固定少数の再現/完了.json')['175追加7未実行'] is True
    assert not (ROOT/'work/175追加七場適用').exists()
    assert all(read(p)['成功'] is True for p in (ROOT/'work/175数量結果の独立検査/独立検査結果.json',ROOT/'work/176固定結果の独立検査/数量四段階の独立結果.json',ROOT/'work/176固定結果の独立検査/固定四案の独立結果.json',ROOT/'work/176追加七場適用/完了.json'))
    if final:
        assert all((t/'README.md').is_file() and (t/'設定と結果.md').is_file() for t in TRIALS.values())
        audit=ROOT/'work/176隔離再現/repo/work/監査結果.json';verification=ROOT/'work/176隔離再現/repo/work/正式runner確認/再現確認.json'
        assert read(audit)['成功'] and read(verification)['成功'];required.extend([audit,verification])
        assert fingerprint(ROOT/'work/176隔離再現/repo/work/176正式保存/正式入力で再現する.py')['sha256']==fingerprint(HERE/'正式入力で再現する.py')['sha256']
        assert read(audit)['監査SourceSHA256']==fingerprint(HERE/'監査実行.py')['sha256']
    return {'成功':True,'175と176は未採用':True,'175追加7未実行':True,'必須':[fingerprint(p) for p in sorted(set(required))]}


def write_archive(path: Path, contents: dict) -> dict:
    """
    機能: 元byteだけを新ZIPへ保存し全CRCとmember指紋を照合する。
    引数: path(Path)、contents(dict[str,bytes])。
    返り値: dictはarchiveとmemberの指紋。
    """
    assert not path.exists()
    with zipfile.ZipFile(path,'x') as archive:
        for name,body in sorted(contents.items()):
            member_reference(name,body)
            archive.writestr(name,body,compress_type=zipfile.ZIP_STORED if PurePosixPath(name).suffix in ('.npz','.gz','.zip') else zipfile.ZIP_DEFLATED)
    expected=[member_reference(name,body) for name,body in sorted(contents.items())]
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None and set(archive.namelist())==set(contents)
        assert all(member_reference(r['path'],archive.read(r['path']))==r for r in expected)
    return {'archive':fingerprint(path),'members':expected}


def execute(destination: Path, extra: list, final: bool) -> dict:
    """
    機能: 隔離用仮ZIP又はGO後の正式ZIPを一組として作る。
    引数: destination(Path)、extra(list[Path])、final(bool)。
    返り値: dictは保存索引。175側へ重複ZIPを作らない。
    """
    assert not any((destination/name).exists() for name in ('Source.zip','出生と比較正本.zip','保存索引.json'))
    gate=gates(extra,final);inherit,source_bytes,old_small=inherited()
    source_paths,result_paths,omitted=collect();before={p.relative_to(ROOT).as_posix():fingerprint(p) for p in source_paths+result_paths}
    for path in source_paths:
        name=path.relative_to(ROOT).as_posix();assert name not in source_bytes;source_bytes[name]=path.read_bytes()
    results={p.relative_to(ROOT).as_posix():p.read_bytes() for p in result_paths};assert not set(results)&set(old_small);results.update(old_small)
    if final:
        for path in (ROOT/'work/176隔離再現/repo/work/監査結果.json',ROOT/'work/176隔離再現/repo/work/正式runner確認/再現確認.json'):
            results['検査/175_176隔離/'+path.name]=path.read_bytes()
    destination.mkdir(parents=True,exist_ok=True)
    source=write_archive(destination/'Source.zip',source_bytes);canonical=write_archive(destination/'出生と比較正本.zip',results)
    assert all(fingerprint(ROOT/name)==value for name,value in before.items())
    assert fingerprint(PARENT/'Source.zip')==inherit['Source']['archive']
    index={'成功':True,'正式保存':final,'保存UTC':datetime.now(timezone.utc).isoformat(),'Source':source,'正本':canonical,
        'Source継承元':inherit['Source'],'旧小入力の選択継承':inherit['正本'],'新Source':[fingerprint(p) for p in source_paths],
        '完了gate':gate,'省略中間指紋':omitted,'保存器':fingerprint(Path(__file__)),
        '共用入力':'正式148当時特徴・固定取得の固定151/161射影、共有163金融、追加167純特徴/金融を読取参照。原板/cache/金融の副本をZIPへ入れない。',
        '注意':'175/176未採用。175追加7未実行。176追加7と全80は既使用参考。主案nullと未知None、広幅の未到達Nを保持。'}
    (destination/'保存索引.json').write_text(json.dumps(index,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    if final:
        shared=TRIALS[175]/'再現資料';shared.mkdir(exist_ok=True)
        reference={'成功':True,'Sourceと小正本の共有先':destination.relative_to(ROOT).as_posix(),
            'Source':source['archive'],'正本':canonical['archive'],'索引':fingerprint(destination/'保存索引.json'),
            '175追加7未実行':True,'175と176は未採用':True}
        target=shared/'共有再現資料の参照.json';assert not target.exists();target.write_text(json.dumps(reference,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return index


def main() -> None:
    """
    機能: 計画表示・隔離用仮保存・Root最終GO後の正式保存を区別する。
    引数: --prepare(bool)、--execute/--go(bool)、--require(Path,反復可)。
    返り値: None。指定なしでは正式ZIPを作らない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--prepare',action='store_true');parser.add_argument('--execute',action='store_true');parser.add_argument('--go',action='store_true')
    parser.add_argument('--require',type=Path,action='append',default=[]);args=parser.parse_args()
    extra=[(p if p.is_absolute() else ROOT/p).resolve() for p in args.require]
    if args.prepare:
        assert not args.execute and not args.go;result=execute(HERE/'仮保存',extra,False)
    elif args.execute or args.go:
        assert args.execute and args.go;result=execute(DESTINATION,extra,True)
    else:
        print(json.dumps({'準備済み':True,'正式保存未実行':True,'隔離用仮ZIP':'--prepare','正式GO後':'--execute --go'},ensure_ascii=False));return
    print(json.dumps({'成功':True,'正式保存':result['正式保存'],'Source':result['Source']['archive'],'正本':result['正本']['archive']},ensure_ascii=False))


if __name__=='__main__':main()
