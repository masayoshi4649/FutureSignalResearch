"""正式148射影と共有163/167から175旧固定二案・176固定四案を再現する。"""
from pathlib import Path
from io import BytesIO
import argparse
import gzip
import hashlib
import json
import sys
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/175局面別入口の再探索'))
import 基盤175 as BASE
B=BASE.B
TRIAL176=ROOT/'study/00176_役割票と局面別構造で入口を広げる'
PACK_KEYS=('cases','sides','events','phases','origins','widths','horizons','tiers','engine','financial','ledger','paths','periods','period_paths')


def local_read(name: str) -> dict:
    """
    機能: 初回175固定pack作成時だけ現在の小正本を読む。
    引数: name(str)はrepo相対パス。
    返り値: dictはJSON又はgzip JSON。
    """
    return B.P.read(ROOT/name)


def policies(read: object, trial: int) -> list:
    """
    機能: 固定票の保存順だけを取り出し主案nullを維持する。
    引数: read(callable)、trial(int)は175又は176。
    返り値: list[dict]は固定二案又は四案。
    """
    folder={175:'175局面別入口の再探索',176:'176役割票入口の再探索'}[trial]
    fixed=read(f'work/{folder}/旧73の固定選択.json');assert fixed['成功']
    assert all(value['主案'] is None for value in fixed['選択'].values())
    result=[p for route in ('全期','前48') for p in fixed['選択'][route]['candidates']]
    assert len(result)==(2 if trial==175 else 4)
    return result


def old_context() -> object:
    """
    機能: 作業cacheを使わず正式148の固定射影から旧73contextを作る。
    引数: なし。
    返り値: objectは正式当時特徴と共有金融/取得時計。
    """
    helper=B.P.module(ROOT/'work/173両中央値と単一建玉/正式入力で再現する.py','formal173_for175_176')
    context=helper.old_context()
    assert context.features.sources['formal161']['cache_used'] is False
    return context


def born(features: object, trial: int, fixed: list, read: object, raw_reader: object) -> tuple:
    """
    機能: 必要候補だけを正式純Sourceで再生成し、旧73元出生へ照合する。
    引数: features(object)、trial(int)、fixed(list)、read/raw_reader(callable)は正本の読込。
    返り値: tuple[dict,list]は正逆一回適用のbirth_key方向と必要rule_id。
    """
    rule_folder={175:'175局面別の純入口',176:'176局面別の役割票'}[trial]
    result_folder={175:'175局面別入口の再探索',176:'176役割票入口の再探索'}[trial]
    builder=B.P.module(ROOT/f'work/{rule_folder}/rules{trial}.py',f'formal{trial}_pure')
    rules={r['birth_key']:r for p in fixed for rows in p['options'].values() for r in rows}
    ids=sorted({r['rule_id'] for r in rules.values()})
    output=builder.build(features,np.asarray([s['start'] for s in features.scenes]),features.q0_timeband,candidate_ids=ids)
    assert output['candidate_ids']==ids and np.array_equal(output['phases'],features.q0_timeband)
    raw={name:output['directions'][i] for i,name in enumerate(ids)}
    if len(features.scenes)==73:
        catalog=read(f'work/{rule_folder}/候補辞書{trial}.json')['rules'];lookup={r['id']:i for i,r in enumerate(catalog)}
        with np.load(BytesIO(raw_reader(f'work/{result_folder}/純出生{trial}.npz')),allow_pickle=False) as sealed:
            assert np.array_equal(sealed['phases'],features.q0_timeband)
            matrix=sealed['directions'];assert all(np.array_equal(raw[name],matrix[lookup[name]]) for name in ids)
    directions={}
    for key,rule in rules.items():
        assert key==rule['rule_id']+'/'+rule['orientation'] and rule['orientation'] in ('NORMAL','REVERSE')
        directions[key]=raw[rule['rule_id']].copy() if rule['orientation']=='NORMAL' else -raw[rule['rule_id']]
    return directions,ids


def replay(context: object, fixed: list, directions: dict, adapter: object, stage: object) -> tuple:
    """
    機能: 固定案を一建玉で再生し、全packと純出生配列を作る。
    引数: context(object)、fixed(list)、directions(dict)、adapter/stage(object)。
    返り値: tuple[list,dict]は全取得packと政策別出生配列。
    """
    rows=[];arrays={'phases':context.event_phases}
    for policy in fixed:
        birth,mw,fw,hi,component,conflict=BASE.compose(context.event_phases,policy['options'],directions,list(context.table.horizons))
        assert not birth['technical'].any() and not birth['tier'].any()
        values={**birth,'mw':mw,'fw':fw,'hi':hi,'component':component,'conflict':conflict}
        arrays.update({policy['id']+'__'+k:v for k,v in values.items()})
        value=B.replay(context,birth,mw,fw,hi,False);row=adapter.pack(context,value,policy)
        evidence,_,full=adapter.period_evidence(context,value,stage);row.update({'periods':evidence,'period_paths':full})
        assert max((r['peak_global_reserved'] for r in row['engine']['audits']),default=0)<=1
        rows.append(row)
    return rows,arrays


def baseline175() -> None:
    """
    機能: 175旧固定二案だけを正式148から再生し、元三帯正本一致の全packを作る。
    引数: なし。
    返り値: None。追加7を読まず、175固定再現の小正本を新規保存する。
    """
    destination=ROOT/'work/175固定少数の再現';assert not destination.exists()
    fixed=policies(local_read,175);context=old_context()
    adapter=B.P.module(ROOT/'work/176追加七場適用/固定政策を適用する.py','adapter176_for175_baseline')
    stage=B.P.module(ROOT/'work/175局面別入口の再探索/数量段階を進める.py','stage175_baseline')
    directions,_=born(context.features,175,fixed,local_read,lambda name:(ROOT/name).read_bytes())
    rows,arrays=replay(context,fixed,directions,adapter,stage)
    expected={r['id']:r for r in local_read('work/175局面別入口の再探索/三帯接合.json.gz')['rows']}
    for row in rows:
        original=expected[row['id']]
        assert row['policy']==original['policy'] and row['periods']==original['periods']
        assert {p:{b:stage.compact_risk(v) for b,v in bands.items()} for p,bands in row['period_paths'].items()}==original['paths']
        assert len(row['cases'])==original['count']
        assert max((a['peak_global_reserved'] for a in row['engine']['audits']),default=0)==original['max_reserved']
        assert sum(a['skipped_held_core'] for a in row['engine']['audits'])==original['held_rejected']
        assert int(arrays[row['id']+'__conflict'].sum())==original['conflict_q0']
    destination.mkdir();np.savez_compressed(destination/'旧73の純出生175.npz',**arrays)
    eligible,hours=adapter.eligibility(context)
    adapter.save(destination/'旧73の全取得175.json.gz',{'成功':True,'場数':73,'場順':context.sessions,
        '対象場':eligible,'対象時間':hours,'幅順':list(context.table.widths),'期限順':list(context.table.horizons),'rows':rows,
        '位置づけ':'175未採用の旧固定二案。元三帯正本の三期間金融・経路・占有・回数一致。175追加7は未実行。'})
    adapter.save(destination/'完了.json',{'成功':True,'175追加7未実行':True,'正式148射影キャッシュなし':True,
        '対象':[r['id'] for r in rows],'元三帯金融経路監査一致':True,'runner':adapter.physical(Path(__file__)),
        'files':[adapter.physical(p) for p in destination.iterdir() if p.is_file()]})
    print(json.dumps({'成功':True,'175旧固定pack':{r['id']:len(r['cases']) for r in rows},'175追加7未実行':True},ensure_ascii=False))


def verify(archive_path: Path, output: Path) -> None:
    """
    機能: 正式ZIPと共有148/163/167だけで175旧2・176旧追加4の同体を検査する。
    引数: archive_path(Path)は小正本ZIP、output(Path)は未作成のwork内確認先。
    返り値: None。出生・全取得・engine・金融・全経路の一致票を保存する。
    """
    assert output.is_relative_to(ROOT/'work') and not output.exists()
    adapter=B.P.module(ROOT/'work/176追加七場適用/固定政策を適用する.py','formal176_adapter')
    stage=B.P.module(ROOT/'work/175局面別入口の再探索/数量段階を進める.py','formal175_stage')
    checks=[];regenerated={}
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        def read(name: str) -> dict:
            """
            機能: ZIP元byteから小正本を読む。
            引数: name(str)はmember名。
            返り値: dictはJSON又はgzip JSON。
            """
            body=archive.read(name);return json.loads(gzip.decompress(body) if name.endswith('.gz') else body)
        for period,context in (('旧73',old_context()),('追加7',B.load_context(True))):
            for trial in ((175,176) if period=='旧73' else (176,)):
                fixed=policies(read,trial);directions,ids=born(context.features,trial,fixed,read,archive.read)
                rows,arrays=replay(context,fixed,directions,adapter,stage)
                folder='175固定少数の再現' if trial==175 else '176追加七場適用'
                expected={r['id']:r for r in read(f'work/{folder}/{period}の全取得{trial}.json.gz')['rows']}
                with np.load(BytesIO(archive.read(f'work/{folder}/{period}の純出生{trial}.npz')),allow_pickle=False) as sealed:
                    assert set(arrays)==set(sealed.files)
                    for name,value in arrays.items():assert np.array_equal(value,sealed[name]),(trial,period,name)
                for row in rows:
                    assert row['policy']==expected[row['id']]['policy']
                    assert all(row[key]==expected[row['id']][key] for key in PACK_KEYS),(trial,period,row['id'])
                    checks.append({'試行':trial,'期間':period,'id':row['id'],'取得':len(row['cases']),
                        '純出生・全取得・engine・金融・完全経路一致':True})
                regenerated[(trial,period)]=rows
        expected80=read('work/176追加七場適用/全80の両中央値176.json.gz')
        for old,added in zip(regenerated[(176,'旧73')],regenerated[(176,'追加7')],strict=True):
            assert old['id']==added['id']
            joined={name:old['ledger'][name]+added['ledger'][name] for name in ('net','known','label','scene')}
            phases=old['phases']+added['phases'];origins=old['origins']+added['origins']
            actual=B.metrics173.evaluate_metrics(joined['net'],joined['known'],joined['label'],joined['scene'],phases,origins,expected80['対象場'],expected80['対象時間'])
            target=next(r for r in expected80['rows'] if r['id']==old['id'])
            assert actual==target['financial'] and adapter.paths(actual)==target['paths']
    output.mkdir(parents=True)
    B.P.save(output/'再現確認.json',{'成功':True,'確認':checks,'176全80台帳から金融と完全経路一致':True,
        '175追加7未実行':True,'キャッシュ不使用':True,'正式正本SHA256':B.P.sha(archive_path),
        '注意':'175/176は未採用。既使用入力の固定再現であり、全探索・独立未見性能・実注文成立を検証したものではない。'})
    print(json.dumps({'成功':True,'同体候補期間':len(checks),'175追加7未実行':True},ensure_ascii=False))


def main() -> None:
    """
    機能: 175固定pack作成又は正式入力の固定再現を明示指定で実行する。
    引数: --baseline175(bool)、--archive/--output(Path)。
    返り値: None。追加7の新選択や175追加7再生は行わない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--baseline175',action='store_true')
    parser.add_argument('--archive',type=Path,default=TRIAL176/'再現資料/出生と比較正本.zip');parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    if args.baseline175:assert args.output is None;baseline175()
    else:assert args.output is not None;verify(args.archive.resolve(),args.output.resolve())


if __name__=='__main__':main()
