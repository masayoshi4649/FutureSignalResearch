"""正式/仮ZIPからだけSourceを復元し、元work/cache無しの固定再現を実行する。"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import venv
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
ISOLATION=ROOT/'work/176隔離再現'


def digest(path: Path) -> str:
    """
    機能: ファイルのSHA256を返す。
    引数: path(Path)。
    返り値: strは十六進指紋。
    """
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def restore(archive_path: Path, expected: list, repository: Path, source: bool) -> None:
    """
    機能: 正式索引へ全byteを照合し、Source又は必要work小入力だけを復元する。
    引数: archive_path/repository(Path)、expected(list[dict])、source(bool)。
    返り値: None。共有study/inputsは複製せず、ZIPの親移動を拒否する。
    """
    refs={r['path']:r for r in expected}
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None and set(archive.namelist())==set(refs)
        assert len(archive.namelist())==len(refs)
        for name in archive.namelist():
            path=PurePosixPath(name);assert '\\' not in name and ':' not in name and not path.is_absolute() and '..' not in path.parts
            body=archive.read(name);assert len(body)==refs[name]['bytes'] and hashlib.sha256(body).hexdigest()==refs[name]['sha256']
            if not source and not name.startswith('work/'):continue
            target=repository/name;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();target.write_bytes(body)


def junction(path: Path, target: Path) -> None:
    """
    機能: 共有inputs/studyへ読取運用するWindows junctionを新規作成する。
    引数: path/target(Path)。
    返り値: None。既存先を変更しない。
    """
    assert not path.exists()
    quote=lambda p:"'"+str(p).replace("'","''")+"'"
    command='New-Item -ItemType Junction -Path '+quote(path)+' -Target '+quote(target)+' | Out-Null'
    subprocess.run(['powershell','-NoProfile','-Command',command],check=True)
    assert path.resolve()==target.resolve()


def main() -> None:
    """
    機能: 新しい隔離環境を作り、監査付きの固定再現を開始する。
    引数: --bundle(Path)は保存索引と二ZIPを含む正式又は仮保存先。
    返り値: None。元workの特徴cacheや金融生成物へrunnerが触れない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--bundle',type=Path,default=HERE/'仮保存');args=parser.parse_args()
    bundle=args.bundle.resolve();index=json.loads((bundle/'保存索引.json').read_text(encoding='utf-8'))
    assert index['成功'] and not ISOLATION.exists()
    for field,name in (('Source','Source.zip'),('正本','出生と比較正本.zip')):
        assert digest(bundle/name)==index[field]['archive']['sha256']
    repository=ISOLATION/'repo';repository.mkdir(parents=True)
    restore(bundle/'Source.zip',index['Source']['members'],repository,True)
    restore(bundle/'出生と比較正本.zip',index['正本']['members'],repository,False)
    artifacts=repository/'artifacts';artifacts.mkdir();shutil.copy2(bundle/'出生と比較正本.zip',artifacts/'出生と比較正本.zip')
    junction(repository/'inputs',ROOT/'inputs');junction(repository/'study',ROOT/'study')
    environment=ISOLATION/'環境';venv.EnvBuilder(with_pip=False,symlinks=False).create(environment)
    original_site=Path(np.__file__).resolve().parent.parent;isolated_site=environment/'Lib/site-packages'
    packages=[p for p in original_site.iterdir() if p.name in ('numpy','numpy.libs','tzdata') or
        p.name.startswith(('numpy-','tzdata-')) and p.name.endswith('.dist-info')]
    assert any(p.name=='numpy' for p in packages) and any(p.name=='tzdata' for p in packages)
    for package in packages:shutil.copytree(package,isolated_site/package.name)
    audit=ISOLATION/'監査実行.py';shutil.copy2(HERE/'監査実行.py',audit)
    record={'成功':True,'SourceSHA256':digest(bundle/'Source.zip'),'小正本SHA256':digest(bundle/'出生と比較正本.zip'),
        '元work_source不使用':'ZIP内元byteだけ復元。共有inputs/studyは読取監査。',
        '環境':'新規venvとNumPy'+np.__version__+'・tzdata','共有入力':['inputs','study'],'実行Source':digest(audit)}
    (ISOLATION/'準備.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    env=os.environ.copy();env.pop('PYTHONPATH',None);env.update({'PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1','PYTHONNOUSERSITE':'1'})
    subprocess.run([str(environment/'Scripts/python.exe'),str(audit)],cwd=repository,env=env,check=True)


if __name__=='__main__':main()
