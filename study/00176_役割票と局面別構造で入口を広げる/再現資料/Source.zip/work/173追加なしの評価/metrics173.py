"""173向けの純粋な評価部品。ファイル・金融データ・外部メタデータを読まない。"""

from __future__ import annotations

import math
import statistics
from collections.abc import Mapping, Sequence
from numbers import Real


def median_bounds(known_values: Sequence[Real], unknown_count: int) -> dict:
    """
    機能: 未知値が任意の実数を取る場合の全件中央値の厳密な上下限を返す。
    引数: known_values（Sequence[Real]）有限の既知値、unknown_count（int）未知件数。
    返り値: dict。既知のみの中央値、全件中央値、上下限、無限方向、可能な符号。
    """
    if isinstance(unknown_count, bool) or not isinstance(unknown_count, int) or unknown_count < 0:
        raise ValueError("未知件数は0以上の整数で指定する。")
    values = []
    for value in known_values:
        if isinstance(value, bool) or not isinstance(value, Real) or not math.isfinite(value):
            raise ValueError("既知値には有限の実数を指定する。")
        values.append(float(value))
    values.sort()
    count = len(values) + unknown_count
    known_median = statistics.median(values) if values else None
    result = {
        "known_count": len(values), "unknown_count": unknown_count, "all_count": count,
        "known_median": known_median,
        "all_median": known_median if count and not unknown_count else None,
        "all_median_exact": bool(count and not unknown_count),
        "lower": None, "upper": None,
        "lower_unbounded": False, "upper_unbounded": False,
        "possible_signs": [], "strictly_positive_guaranteed": False,
        "strictly_positive_possible": False,
    }
    if not count:
        return result
    left, right = (count - 1) // 2, count // 2
    lower_unbounded = left < unknown_count
    upper_unbounded = right >= len(values)
    lower = None if lower_unbounded else (values[left - unknown_count] + values[right - unknown_count]) / 2
    upper = None if upper_unbounded else (values[left] + values[right]) / 2
    low = -math.inf if lower_unbounded else lower
    high = math.inf if upper_unbounded else upper
    result.update({
        "lower": lower, "upper": upper,
        "lower_unbounded": lower_unbounded, "upper_unbounded": upper_unbounded,
        "possible_signs": [sign for sign, possible in (
            ("負", low < 0), ("ゼロ", low <= 0 <= high), ("正", high > 0)
        ) if possible],
        "strictly_positive_guaranteed": low > 0,
        "strictly_positive_possible": high > 0,
    })
    return result


def _phase(value: object) -> str:
    """
    機能: 数値・文字列の時間帯をDAY・PRE・POSTへ正規化する。
    引数: value（object）0/1/2、または時間帯の文字列表記。
    返り値: str。正規化した時間帯。未知の文字列表記はそのまま保持する。
    """
    aliases = {0: "DAY", 1: "PRE", 2: "POST", "0": "DAY", "1": "PRE", "2": "POST",
               "DAY": "DAY", "デイ": "DAY", "日中": "DAY", "PRE": "PRE", "米国前": "PRE",
               "POST": "POST", "米国後": "POST"}
    key = value.strip().upper() if isinstance(value, str) else value
    return aliases.get(key, str(value))


def _label(value: object) -> str:
    """
    機能: 先着判定をF/A/N/Cへ正規化する。
    引数: value（object）1/-1/0/2、またはF/A/N/Cの文字列表記。
    返り値: str。F/A/N/C。不明な値ではValueErrorを送出する。
    """
    aliases = {1: "F", -1: "A", 0: "N", 2: "C", "1": "F", "-1": "A", "0": "N", "2": "C"}
    key = value.strip().upper() if isinstance(value, str) else value
    if isinstance(key, str) and key.startswith("IFD_FIRSTFANC_"):
        key = key.removeprefix("IFD_FIRSTFANC_")
    normalized = aliases.get(key, key)
    if normalized not in ("F", "A", "N", "C"):
        raise ValueError("先着判定はF/A/N/Cまたは1/-1/0/2で指定する。")
    return normalized


def _origin(value: object) -> str:
    """
    機能: 主入口と補完入口の表記を統一する。
    引数: value（object）0/2、または主・補完に相当する文字列表記。
    返り値: str。主・補完、または未登録の文字列表記。
    """
    key = value.strip().upper() if isinstance(value, str) else value
    aliases = {0: "主", 2: "補完", "0": "主", "2": "補完", "MAIN": "主", "主": "主",
               "主入口": "主", "FALLBACK": "補完", "SUPPLEMENT": "補完", "補完": "補完", "補完入口": "補完"}
    return aliases.get(key, str(value))


def _trade_metrics(records: Sequence[dict]) -> dict:
    """
    機能: 建玉ごとの費用後損益、正決済率、先着判定を集計する。
    引数: records（Sequence[dict]）正規化した取得記録。
    返り値: dict。既知金額・未知件数・中央値境界・先着F/A/N/C件数。
    """
    known_values = [record["net"] for record in records if record["known"]]
    unknown_count = len(records) - len(known_values)
    positive = sum(value > 0 for value in known_values)
    negative = sum(value < 0 for value in known_values)
    flat = sum(value == 0 for value in known_values)
    labels = {key: sum(record["label"] == key for record in records) for key in ("F", "A", "N", "C")}
    reached = labels["F"] + labels["A"]
    return {
        "all_count": len(records), "known_count": len(known_values), "unknown_count": unknown_count,
        "known_profit": sum(value for value in known_values if value > 0),
        "known_loss": -sum(value for value in known_values if value < 0),
        "known_net": sum(known_values),
        "known_positive_count": positive, "known_negative_count": negative, "known_zero_count": flat,
        "positive_settlement_rate_known": positive / len(known_values) if known_values else None,
        "positive_settlement_rate_all_lower": positive / len(records) if records else None,
        "positive_settlement_rate_all_upper": (positive + unknown_count) / len(records) if records else None,
        "net_median": median_bounds(known_values, unknown_count),
        "IFD_FIRSTFANC": {**labels, "reached_count": reached,
                          "first_f_rate_reached": labels["F"] / reached if reached else None},
    }


def _concentration(rows: Sequence[dict]) -> dict:
    """
    機能: 全対象場を残し、利益・損失・既知収支・取得の集中を順位別に計算する。
    引数: rows（Sequence[dict]）未参加場を含むセッション別集計。
    返り値: dict。各指標の独立順位で選ぶ上位1/3/5/10場のシェア。
    """
    result = {}
    for key in ("known_profit", "known_loss", "known_net", "all_count"):
        total = sum(row[key] for row in rows)
        ordered = sorted(rows, key=lambda row: (-row[key], row["scene"]))
        result[key] = []
        for requested in (1, 3, 5, 10):
            selected = ordered[:requested]
            subtotal = sum(row[key] for row in selected)
            result[key].append({"requested_top_count": requested, "actual_top_count": len(selected),
                                "scenes": [row["scene"] for row in selected], "value": subtotal,
                                "share": subtotal / total if total else None})
    return result


def _group_metrics(records: Sequence[dict], eligible: Sequence[str], hours: float | None) -> dict:
    """
    機能: 対象場の全件を分母にして、建玉・場・参加・頻度・集中を集計する。
    引数: records（Sequence[dict]）取得記録、eligible（Sequence[str]）全対象場、hours（float | None）全対象時間。
    返り値: dict。0取引場を含む場集計と、両中央値の必須条件判定。
    """
    by_scene = {scene_id: [] for scene_id in eligible}
    for record in records:
        by_scene[record["scene"]].append(record)
    rows = []
    for scene_id in eligible:
        selected = by_scene[scene_id]
        trade = _trade_metrics(selected)
        rows.append({"scene": scene_id, "all_count": trade["all_count"], "known_count": trade["known_count"],
                     "unknown_count": trade["unknown_count"], "known_profit": trade["known_profit"],
                     "known_loss": trade["known_loss"], "known_net": trade["known_net"],
                     "complete": trade["unknown_count"] == 0,
                     "all_net": trade["known_net"] if trade["unknown_count"] == 0 else None,
                     "main_count": sum(record["origin"] == "主" for record in selected),
                     "supplement_count": sum(record["origin"] == "補完" for record in selected)})
    trade = _trade_metrics(records)
    complete_values = [row["known_net"] for row in rows if row["complete"]]
    unknown_scenes = sum(not row["complete"] for row in rows)
    session_median = median_bounds(complete_values, unknown_scenes)
    active = sum(row["all_count"] > 0 for row in rows)
    origin_metrics = {}
    for name in sorted({"主", "補完"} | {record["origin"] for record in records}):
        selected = [record for record in records if record["origin"] == name]
        participants = {record["scene"] for record in selected}
        origin_metrics[name] = {"acquisition_count": len(selected), "participating_scene_count": len(participants),
                                "participation_rate": len(participants) / len(rows) if rows else None,
                                "metrics": _trade_metrics(selected)}
    return {
        "trades": trade,
        "sessions": {
            "eligible_count": len(rows), "complete_count": len(complete_values), "unknown_count": unknown_scenes,
            "participating_count": active, "zero_acquisition_count": len(rows) - active,
            "participation_rate": active / len(rows) if rows else None,
            "zero_acquisition_scenes": [row["scene"] for row in rows if not row["all_count"]],
            "known_contribution_median_all_scenes": statistics.median([row["known_net"] for row in rows]) if rows else None,
            "net_median": session_median,
            "complete_positive_count": sum(row["complete"] and row["known_net"] > 0 for row in rows),
            "complete_negative_count": sum(row["complete"] and row["known_net"] < 0 for row in rows),
            "complete_zero_count": sum(row["complete"] and row["known_net"] == 0 for row in rows),
            "rows": rows,
        },
        "origins": origin_metrics, "eligible_hours": hours,
        "acquisitions_per_hour": len(records) / hours if hours else None,
        "concentration": _concentration(rows),
        "decision": dual_median_decision(trade["net_median"], session_median),
    }


def dual_median_decision(trade_median: Mapping, session_median: Mapping) -> dict:
    """
    機能: 建玉ごと・セッション別の費用後中央値が両方とも厳密に正か判定する。
    引数: trade_median（Mapping）建玉中央値の境界、session_median（Mapping）場中央値の境界。
    返り値: dict。適合・不適合・保留・評価不能。未知の金額を0円に置き換えない。
    """
    bounds = {"建玉": trade_median, "セッション": session_median}
    if any(not bound["all_count"] for bound in bounds.values()):
        status, reason = "評価不能", "建玉または対象セッションが0件。"
    elif all(bound["strictly_positive_guaranteed"] for bound in bounds.values()):
        status, reason = "適合", "両中央値の下限が0円を厳密に上回る。"
    elif any(not bound["strictly_positive_possible"] for bound in bounds.values()):
        status, reason = "不適合", "少なくとも一方の中央値の上限が0円以下。"
    else:
        status, reason = "保留", "未知値によって必須中央値の符号が変わり得る。"
    return {"status": status, "reason": reason, "strictly_positive_required": True,
            "unknown_values_present": any(bound["unknown_count"] for bound in bounds.values()),
            "both_exact": all(bound["all_median_exact"] for bound in bounds.values())}


def candidate_rank_key(metrics: Mapping) -> tuple | None:
    """
    機能: 必須条件に適合した候補だけに、参加・両中央値を優先する固定順位を与える。
    引数: metrics（Mapping）evaluate_metricsの返り値。過去選択では成熟済み選択範囲だけを渡す。
    返り値: tuple | None。降順用の順位キー。不適合・保留・評価不能ではNone。
          優先順は未参加場数の少なさ、Day/Nightの低い建玉中央値下限、低い場中央値下限、未知件数の少なさ。
    """
    if metrics["required_decision"]["status"] != "適合":
        return None
    groups = [metrics["session_groups_required"][name] for name in ("DAY", "NIGHT")]
    missing = sum(group["sessions"]["zero_acquisition_count"] for group in groups)
    lowest_trade_median = min(group["trades"]["net_median"]["lower"] for group in groups)
    lowest_session_median = min(group["sessions"]["net_median"]["lower"] for group in groups)
    unknown_count = sum(group["trades"]["unknown_count"] for group in groups)
    return (-missing, lowest_trade_median, lowest_session_median, -unknown_count)


def evaluate_metrics(net: Sequence[Real | None], known: Sequence[bool], label: Sequence[object],
                     scene: Sequence[str], phase: Sequence[object], origin: Sequence[object],
                     eligible_scenes: Sequence[str] | Mapping[object, Sequence[str]],
                     hours: Real | Mapping[object, Real]) -> dict:
    """
    機能: 並列の取得配列から173の固定評価を返す純関数。入出力ファイル操作は行わない。
    引数: net（Sequence[Real | None]）1取得ごとの費用後収支、known（Sequence[bool]）決済既知、
          label（Sequence[object]）F/A/N/Cまたは1/-1/0/2、scene（Sequence[str]）実セッションID、
          phase（Sequence[object]）DAY/PRE/POSTまたは0/1/2、origin（Sequence[object]）主/補完または0/2、
          eligible_scenes（Sequence[str] | Mapping[object, Sequence[str]]）0取引を含む全場。
          帯別辞書ならPREとPOSTに同じNight場IDを渡し、DAYとNightでは異なる場IDを用いる。
          hours（Real | Mapping[object, Real]）全対象時間。帯別辞書ならDAY/PRE/POSTの時間。
    返り値: dict。全体参考、帯別診断、DAY/NIGHTの必須両中央値と参加・集中・IFD評価。
    """
    count = len(net)
    if any(len(values) != count for values in (known, label, scene, phase, origin)):
        raise ValueError("取得の並列配列は同じ長さで指定する。")
    phase_eligible = {}
    explicit_phase_eligibility = isinstance(eligible_scenes, Mapping)
    if explicit_phase_eligibility:
        for key, values in eligible_scenes.items():
            normalized_phase = _phase(key)
            if normalized_phase in phase_eligible:
                raise ValueError("正規化後に同じ時間帯が重複している。")
            phase_eligible[normalized_phase] = list(dict.fromkeys(values))
        eligible = list(dict.fromkeys(value for values in phase_eligible.values() for value in values))
    else:
        eligible = list(dict.fromkeys(eligible_scenes))
    if any(not isinstance(value, str) or not value for value in eligible):
        raise ValueError("セッションIDは空ではない文字列で指定する。")
    if explicit_phase_eligibility and set(phase_eligible.get("DAY", [])) & (
            set(phase_eligible.get("PRE", [])) | set(phase_eligible.get("POST", []))):
        raise ValueError("DAYとNightには異なる実セッションIDを付ける。")
    phase_hours = {}
    if isinstance(hours, Mapping):
        for key, value in hours.items():
            normalized_phase = _phase(key)
            if normalized_phase in phase_hours:
                raise ValueError("時間の正規化後に同じ帯が重複している。")
            if isinstance(value, bool) or not isinstance(value, Real) or not math.isfinite(value) or value < 0:
                raise ValueError("対象時間は有限の0以上の数値で指定する。")
            phase_hours[normalized_phase] = float(value)
        total_hours = sum(phase_hours.values())
    else:
        if isinstance(hours, bool) or not isinstance(hours, Real) or not math.isfinite(hours) or hours < 0:
            raise ValueError("対象時間は有限の0以上の数値で指定する。")
        total_hours = float(hours)
    records = []
    for index in range(count):
        if not isinstance(known[index], bool):
            raise ValueError("既知フラグにはboolを指定する。")
        normalized_label, normalized_phase = _label(label[index]), _phase(phase[index])
        value = net[index]
        if known[index]:
            if normalized_label == "C":
                raise ValueError("Cの未知決済を既知扱いにしない。")
            if isinstance(value, bool) or not isinstance(value, Real) or not math.isfinite(value):
                raise ValueError("既知決済には有限の費用後収支を指定する。")
            value = float(value)
        elif value is not None:
            raise ValueError("未知決済の収支はNoneで指定し、0円で埋めない。")
        if scene[index] not in eligible:
            raise ValueError("取得の場が全対象セッションに含まれていない。")
        if explicit_phase_eligibility and scene[index] not in phase_eligible.get(normalized_phase, []):
            raise ValueError("取得の帯と場が帯別対象セッションに含まれていない。")
        records.append({"net": value, "known": known[index], "label": normalized_label,
                        "scene": scene[index], "phase": normalized_phase, "origin": _origin(origin[index])})

    # ----------------------------------------
    # 全体の参考値と小帯診断を計算する。小帯中央値を必須条件に追加しない。
    all_metrics = _group_metrics(records, eligible, total_hours)
    phases = {}
    for name in sorted(set(phase_eligible) | {record["phase"] for record in records}):
        selected = [record for record in records if record["phase"] == name]
        selected_eligible = phase_eligible.get(name, eligible)
        phases[name] = _group_metrics(selected, selected_eligible, phase_hours.get(name))
    session_groups = {}
    for name, members in (("DAY", ("DAY",)), ("NIGHT", ("PRE", "POST"))):
        selected = [record for record in records if record["phase"] in members]
        selected_eligible = list(dict.fromkeys(value for member in members for value in phase_eligible.get(member, [])))
        group_hours = sum(phase_hours[member] for member in members) if all(member in phase_hours for member in members) else None
        if explicit_phase_eligibility:
            session_groups[name] = _group_metrics(selected, selected_eligible, group_hours)
    statuses = [session_groups.get(name, {}).get("decision", {}).get("status", "評価不能") for name in ("DAY", "NIGHT")]
    if all(status == "適合" for status in statuses):
        required_status = "適合"
    elif "不適合" in statuses:
        required_status = "不適合"
    elif "評価不能" in statuses:
        required_status = "評価不能"
    else:
        required_status = "保留"
    return {
        "all_reference": all_metrics, "phases_diagnostic": phases, "session_groups_required": session_groups,
        "required_decision": {"status": required_status,
                              "rule": "DAYとNIGHTそれぞれで、建玉ごと・実セッション別の費用後収支中央値が両方とも0円より大きい。",
                              "by_group": dict(zip(("DAY", "NIGHT"), statuses)),
                              "phase_medians_are_diagnostic_only": True,
                              "participation_exceptions": "未参加場は除外せず0円で残す。合理的理由は別記録とする。"},
        "eligibility_by_phase_explicit": explicit_phase_eligibility,
        "notes": ["known_contribution_median_all_scenesは未知場の既知部分だけを足した診断値であり採否には使わない。",
                  "セッションnet_medianのknown_medianは全件既知の場だけ。0取引場は既知0円として含む。",
                  "未知を含む場の最終収支は未知とし、自由な未知値による全場中央値上下限で採否する。",
                  "F/A/Nの先着判定と費用後の正決済率は別集計。Nでも利益・損失・ゼロがあり得る。",
                  "参加・頻度の分母は全対象場・全対象時間。PRE/POSTはNightを合算した必須判定とは別の診断。",
                  "帯別eligible_scenesを省略した場合、DAY/NIGHTの必須採否は評価不能。"],
    }
