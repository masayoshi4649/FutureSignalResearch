"""金融データを読まずに173評価部品を人工ケースだけで独立照合する。"""

from __future__ import annotations

import hashlib
import itertools
import json
import random
from pathlib import Path

from metrics173 import candidate_rank_key, evaluate_metrics, median_bounds


def reference_median(values: list[float]) -> float | None:
    """
    機能: 独立照合用に並び替えと中央位置の直接参照で中央値を求める。
    引数: values（list[float]）比較対象の有限値。
    返り値: float | None。値がなければNone。
    """
    ordered = sorted(values)
    if not ordered:
        return None
    middle = len(ordered) // 2
    if len(ordered) % 2:
        return ordered[middle]
    return (ordered[middle - 1] + ordered[middle]) / 2


def verify_bounds(values: list[float], unknown_count: int) -> None:
    """
    機能: 未知へ大小2段階の極端値を代入し、有限端点と非有界方向を独立照合する。
    引数: values（list[float]）既知値、unknown_count（int）未知件数。
    返り値: None。不一致時はAssertionErrorを送出する。
    """
    actual = median_bounds(values, unknown_count)
    assert actual["known_median"] == reference_median(values)
    assert actual["all_count"] == len(values) + unknown_count
    if not actual["all_count"]:
        assert actual["possible_signs"] == []
        return
    low_small = reference_median(values + [-1_000_000.0] * unknown_count)
    low_large = reference_median(values + [-1_000_000_000.0] * unknown_count)
    high_small = reference_median(values + [1_000_000.0] * unknown_count)
    high_large = reference_median(values + [1_000_000_000.0] * unknown_count)
    if actual["lower_unbounded"]:
        assert low_large < low_small
        assert actual["lower"] is None
    else:
        assert low_small == low_large == actual["lower"]
    if actual["upper_unbounded"]:
        assert high_large > high_small
        assert actual["upper"] is None
    else:
        assert high_small == high_large == actual["upper"]
    assert actual["strictly_positive_guaranteed"] == (low_large > 0)
    assert actual["strictly_positive_possible"] == (high_large > 0)
    if not unknown_count:
        assert actual["all_median"] == reference_median(values)


def expect_error(callback) -> None:
    """
    機能: 不正入力が誤集計されずValueErrorになることを確認する。
    引数: callback（Callable）引数なしの検証対象呼び出し。
    返り値: None。例外がなければAssertionErrorを送出する。
    """
    try:
        callback()
    except ValueError:
        return
    raise AssertionError("不正入力が拒否されなかった。")


def main() -> None:
    """
    機能: 網羅ケース・乱数ケース・必須条件の反例を検証して小JSONとSHAを保存する。
    引数: なし。
    返り値: None。人工検証に不一致があればAssertionErrorを送出する。
    """
    exhaustive_count = 0
    for length in range(8):
        for states in itertools.product((-7.0, 0.0, 5.0, None), repeat=length):
            values = [value for value in states if value is not None]
            verify_bounds(values, states.count(None))
            exhaustive_count += 1

    # ----------------------------------------
    # Nの正負、C、0取引、偶数中央値、Night合算を同時に含む固定人工例。
    eligibility = {0: ["D0", "D1", "D2", "D3"], 1: ["N0", "N1", "N2", "N3"], 2: ["N0", "N1", "N2", "N3"]}
    sample = evaluate_metrics(
        [10, -3, 2, None, 4, 6, -2, 3, None, 5],
        [True, True, True, False, True, True, True, True, False, True],
        [1, 0, 0, 2, 1, 0, -1, 0, 2, 1],
        ["D0", "D0", "D1", "D2", "N0", "N0", "N1", "N1", "N2", "N2"],
        [0, 0, 0, 0, 1, 2, 1, 2, 1, 2], [0, 2, 0, 0, 0, 0, 2, 0, 2, 0],
        eligibility, {0: 16, 1: 8, 2: 8},
    )
    trade = sample["all_reference"]["trades"]
    assert (trade["all_count"], trade["known_count"], trade["unknown_count"]) == (10, 8, 2)
    assert (trade["known_profit"], trade["known_loss"], trade["known_net"]) == (30, 5, 25)
    assert trade["net_median"]["known_median"] == 3.5
    assert trade["net_median"]["all_median"] is None
    assert trade["positive_settlement_rate_known"] == 6 / 8
    assert trade["IFD_FIRSTFANC"] == {"F": 3, "A": 1, "N": 4, "C": 2, "reached_count": 4, "first_f_rate_reached": 3 / 4}
    assert sample["all_reference"]["sessions"]["eligible_count"] == 8
    assert sample["all_reference"]["sessions"]["zero_acquisition_scenes"] == ["D3", "N3"]
    assert sample["all_reference"]["acquisitions_per_hour"] == 10 / 32
    assert sample["all_reference"]["origins"]["主"]["participation_rate"] == 6 / 8
    assert sample["all_reference"]["origins"]["補完"]["participation_rate"] == 3 / 8
    assert sample["all_reference"]["concentration"]["known_profit"][0]["share"] == 10 / 30
    assert sample["all_reference"]["concentration"]["known_loss"][0]["share"] == 3 / 5
    assert sample["all_reference"]["concentration"]["known_net"][0]["share"] == 10 / 25
    assert sample["all_reference"]["concentration"]["all_count"][0]["share"] == 2 / 10
    assert sample["session_groups_required"]["DAY"]["decision"]["status"] == "保留"
    assert sample["session_groups_required"]["NIGHT"]["decision"]["status"] == "適合"
    assert sample["session_groups_required"]["NIGHT"]["sessions"]["net_median"]["lower"] == 0.5
    assert sample["session_groups_required"]["NIGHT"]["sessions"]["net_median"]["upper"] == 5.5
    assert sample["required_decision"]["status"] == "保留"

    # ----------------------------------------
    # PRE単独の中央値が赤字でも、Night合算の両中央値が黒字なら必須条件を通す。
    joint = evaluate_metrics([2, 4, -1, -1, 5, 5], [True] * 6, [1, 1, -1, -1, 1, 1],
                             ["D0", "D1", "N0", "N1", "N0", "N1"], [0, 0, 1, 1, 2, 2], [0] * 6,
                             {"DAY": ["D0", "D1"], "PRE": ["N0", "N1"], "POST": ["N0", "N1"]},
                             {"DAY": 4, "PRE": 2, "POST": 2})
    assert joint["phases_diagnostic"]["PRE"]["decision"]["status"] == "不適合"
    assert joint["session_groups_required"]["NIGHT"]["trades"]["net_median"]["all_median"] == 2
    assert joint["required_decision"]["status"] == "適合"
    assert candidate_rank_key(joint) == (0, 2, 3, 0)
    assert candidate_rank_key(sample) is None
    zero_sessions = evaluate_metrics([2], [True], [0], ["D0"], [0], [0], {0: ["D0", "D1", "D2"]}, {0: 6})
    assert zero_sessions["session_groups_required"]["DAY"]["trades"]["net_median"]["all_median"] == 2
    assert zero_sessions["session_groups_required"]["DAY"]["sessions"]["net_median"]["all_median"] == 0
    assert zero_sessions["session_groups_required"]["DAY"]["decision"]["status"] == "不適合"
    empty = evaluate_metrics([], [], [], [], [], [], {0: ["D0"], 1: ["N0"], 2: ["N0"]}, {0: 2, 1: 1, 2: 1})
    assert empty["all_reference"]["sessions"]["net_median"]["all_median"] == 0
    assert empty["all_reference"]["trades"]["net_median"]["all_median"] is None
    assert empty["required_decision"]["status"] == "評価不能"
    all_unknown = evaluate_metrics([None], [False], [2], ["D0"], [0], [2], {0: ["D0"]}, {0: 1})
    assert all_unknown["all_reference"]["sessions"]["net_median"]["known_median"] is None
    assert all_unknown["all_reference"]["sessions"]["rows"][0]["all_net"] is None
    assert all_unknown["all_reference"]["decision"]["status"] == "保留"

    # ----------------------------------------
    # 乱数例の損益・場ごとの既知部分・完了場中央値を独立した直接集計と照合する。
    random_source = random.Random(173)
    random_count = 500
    for _ in range(random_count):
        size = random_source.randrange(25)
        phases = [random_source.randrange(3) for _ in range(size)]
        scenes = [random_source.choice(eligibility[band]) for band in phases]
        known = [random_source.random() > 0.2 for _ in range(size)]
        values = [random_source.randrange(-50, 51) if flag else None for flag in known]
        labels = [random_source.choice((-1, 0, 1)) if flag else 2 for flag in known]
        origins = [random_source.choice((0, 2)) for _ in range(size)]
        actual = evaluate_metrics(values, known, labels, scenes, phases, origins, eligibility, {0: 16, 1: 8, 2: 8})
        known_values = [value for value in values if value is not None]
        totals = actual["all_reference"]["trades"]
        assert totals["known_profit"] == sum(value for value in known_values if value > 0)
        assert totals["known_loss"] == -sum(value for value in known_values if value < 0)
        assert totals["known_net"] == sum(known_values)
        assert totals["net_median"]["known_median"] == reference_median(known_values)
        complete_scene_values = []
        for row in actual["all_reference"]["sessions"]["rows"]:
            indices = [index for index, scene_id in enumerate(scenes) if scene_id == row["scene"]]
            expected_known = sum(values[index] for index in indices if known[index])
            expected_unknown = sum(not known[index] for index in indices)
            assert row["known_net"] == expected_known
            assert row["unknown_count"] == expected_unknown
            assert row["complete"] == (expected_unknown == 0)
            if expected_unknown == 0:
                complete_scene_values.append(expected_known)
        actual_session_median = actual["all_reference"]["sessions"]["net_median"]
        assert actual_session_median["known_median"] == reference_median(complete_scene_values)
        verify_bounds(complete_scene_values, 8 - len(complete_scene_values))
        assert actual["all_reference"]["sessions"]["eligible_count"] == 8
        assert sum(row["all_count"] for row in actual["all_reference"]["sessions"]["rows"]) == size

    # ----------------------------------------
    # 未知0埋め・C既知扱い・長さ不一致・対象外取得を拒否する。
    expect_error(lambda: evaluate_metrics([0], [False], [2], ["D0"], [0], [0], {0: ["D0"]}, {0: 1}))
    expect_error(lambda: evaluate_metrics([0], [True], [2], ["D0"], [0], [0], {0: ["D0"]}, {0: 1}))
    expect_error(lambda: evaluate_metrics([1], [], [1], ["D0"], [0], [0], {0: ["D0"]}, {0: 1}))
    expect_error(lambda: evaluate_metrics([1], [True], [1], ["D9"], [0], [0], {0: ["D0"]}, {0: 1}))
    expect_error(lambda: evaluate_metrics([], [], [], [], [], [], {0: ["同日"], 1: ["同日"]}, {0: 1, 1: 1}))
    expect_error(lambda: median_bounds([float("nan")], 0))
    expect_error(lambda: median_bounds([1], -1))
    json.dumps(sample, ensure_ascii=False, allow_nan=False)
    json.dumps(all_unknown, ensure_ascii=False, allow_nan=False)

    destination = Path(__file__).resolve().parent
    result = {"確認日": "2026-11-15", "自然金融データ読込": False,
              "中央値境界網羅ケース数": exhaustive_count, "乱数集計照合ケース数": random_count,
              "固定人工例": {"既知利益": trade["known_profit"], "既知損失": trade["known_loss"],
                             "既知収支": trade["known_net"], "建玉既知中央値": trade["net_median"]["known_median"],
                             "主必須判定": sample["required_decision"]},
              "検証": ["Nの利益損失を先着と独立集計", "未知Cを0円埋めしない", "未知場は最終収支未確定",
                       "0取引場を0円として中央値に含める", "偶数中央値の平均", "中央値の有限端点・非有界方向",
                       "DAY/NIGHTごと両中央値が厳密正", "PRE赤字でもNight合算黒字なら適合",
                       "全対象場と全時間の分母", "対象外取得・不正入力を拒否", "JSONの非標準Infinity/NaNなし"],
              "結果": "全検証成功"}
    (destination / "検証結果.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    hashes = {name: hashlib.sha256((destination / name).read_bytes()).hexdigest()
              for name in ("metrics173.py", "検証.py", "README.md", "検証結果.json")}
    (destination / "SHA256.json").write_text(json.dumps(hashes, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"網羅": exhaustive_count, "乱数": random_count, "結果": "成功"}, ensure_ascii=True))


if __name__ == "__main__":
    main()
