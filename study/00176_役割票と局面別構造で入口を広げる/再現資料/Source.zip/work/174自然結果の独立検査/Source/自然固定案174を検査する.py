"""174固定4政策を別状態機械で旧73・追加7へ再生し、各段正本と全80財務を独立照合する。"""

from __future__ import annotations

import copy
import csv
import gzip
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from 接続174 import delayed_composition

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DESTINATION = HERE.parent
TARGET = ROOT / "work/174参加と両中央値の再探索"
APPLICATION = ROOT / "work/174追加七場適用"
IDS = ("全期_J002", "全期_J003", "前48_J000", "前48_J001")
FIXED_SHA = "1d31d7c8e69168a6eb1c025add255ae1a57e6f91d909c0ab4d1eb0c606e65f6e"
sys.path.insert(0, str(ROOT / "work/173自然結果の独立検査/Source"))
import 旧73を検査する as Q
import 追加7と全80を検査する as V


def selected_rows(path: Path, wanted: set[str]) -> tuple:
    """
    機能: gzip正本を順に読み、指定政策行だけを保持して巨大な全件複製を避ける。
    引数: path（Path）段階正本、wanted（set[str]）固定されたID。
    返り値: tuple。指定行辞書とrows以前の正本ヘッダ。
    """
    decoder = json.JSONDecoder()
    found = {}
    with gzip.open(path, "rt", encoding="utf-8") as handle:
        buffer = ""
        marker = '"rows"'
        while marker not in buffer:
            piece = handle.read(65536)
            assert piece, "段階正本にrowsがない。"
            buffer += piece
        position = buffer.index(marker)
        header = json.loads(buffer[:position].rstrip().rstrip(",") + "}")
        start = buffer.index("[", position)
        buffer = buffer[start + 1:]
        while found.keys() != wanted:
            buffer = buffer.lstrip(" \r\n\t,")
            if buffer.startswith("]"):
                break
            try:
                row, end = decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                piece = handle.read(65536)
                assert piece, "段階正本の行が完了しない。"
                buffer += piece
                continue
            buffer = buffer[end:]
            if row["id"] in wanted:
                found[row["id"]] = row
    assert set(found) == wanted, (path.name, wanted - set(found))
    return found, header


def direct_births(policies: list) -> tuple:
    """
    機能: 元出生refから固定方向を直接抽出し、174短表と全方向を照合する。
    引数: policies（list）固定4政策。
    返り値: tuple。方向辞書、参照出生の物理指紋。
    """
    groups, output, refs = {}, {}, []
    for policy in policies:
        for rules in policy["options"].values():
            for rule in rules:
                groups.setdefault(ROOT / rule["birth_ref"]["path"], {})[rule["birth_key"]] = rule
    for path, rules in groups.items():
        physical = Q.fingerprint(path)
        refs.append(physical)
        for rule in rules.values():
            assert physical["sha256"] == rule["birth_ref"]["sha256"] and physical["bytes"] == rule["birth_ref"]["bytes"]
        with np.load(path, allow_pickle=False) as archive:
            for name in {rule.get("birth_array", rule["mode"]) for rule in rules.values()}:
                matrix = archive[name]
                for key, rule in rules.items():
                    if rule.get("birth_array", rule["mode"]) == name:
                        output[key] = matrix[int(rule["rule_index"])].copy() * (-1 if rule["orientation"] == "REVERSE" else 1)
    with np.load(TARGET / "短表の純出生173.npz", allow_pickle=False) as archive:
        assert all(np.array_equal(archive[key], value) for key, value in output.items())
    return output, refs


def compose(context: object, policy: dict, directions: dict, base: dict) -> tuple:
    """
    機能: 独立ORのあとに当該policyのDayT待機だけを別の逐次maskで適用する。
    引数: context（object）、policy（dict）、directions（dict）、base（dict）。
    返り値: tuple。別状態機械へ渡す出生。
    """
    return delayed_composition(Q.independent_compose(context, policy, directions, base), context.event_phases,
                               context.event_scenes, context.event_keys,
                               np.array([scene["start"] for scene in context.scenes]),
                               int(policy.get("day_fallback_after_minutes", 45)))


def compare_stage(context: object, policy: dict, replay: dict, conflicts: np.ndarray, official: dict) -> dict:
    """
    機能: 各段の3期間×4群の全財務dictと枠監査を独立結果へ照合する。
    引数: context（object）、policy（dict）、replay（dict）別状態機械、conflicts（np.ndarray）、official（dict）段階正本。
    返り値: dict。照合数と短い群別指標。
    """
    assert policy == official["policy"]
    assert max(row["peak_global_reserved"] for row in replay["audits"]) == official["global_reserved_max"] <= 1
    assert max(row["peak_global_held"] for row in replay["audits"]) == official["global_held_max"] <= 1
    assert sum(row["skipped_held_core"] + row["skipped_held_technical"] for row in replay["audits"]) == official["rejected_held"]
    assert sum(row["skipped_pending_core"] + row["skipped_pending_technical"] for row in replay["audits"]) == official["rejected_pending"]
    assert int(conflicts.sum()) == official["conflict_q0"]
    periods, comparisons = {}, 0
    for period, indices in (("全期", range(73)), ("前48", range(48)), ("後25", range(48, 73))):
        periods[period] = {}
        for band in ("DAY", "PRE", "POST", "NIGHT"):
            phases = {"DAY": [0], "PRE": [1], "POST": [2], "NIGHT": [1, 2]}[band]
            eligible = [scene for scene in indices if context.hours[scene, phases].sum() > 0]
            group = Q.aggregate(context, replay["trades"], eligible, band)
            comparisons += Q.compare_group(group, official["periods"][period][band])
            periods[period][band] = V.concise(group)
    return {"id": policy["id"], "Day補完待機分": policy.get("day_fallback_after_minutes", 45),
            "取得数": len(replay["records"]), "要求数": len(replay["requests"]), "財務照合大項目数": comparisons,
            "占有違反": 0, "要求SHA256": Q.digest_json(replay["requests"]), "取得SHA256": Q.digest_json(replay["records"]), "periods": periods}


def write_csv(path: Path, rows: list) -> None:
    """
    機能: 小さい独立閲覧集計だけをCSVへ保存する。
    引数: path（Path）出力、rows（list[dict]）同じ列の行。
    返り値: None。
    """
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    """
    機能: 固定4政策と選択構成政策の旧73・追加7・全80を自然独立照合して成功gateを保存する。
    引数: なし。
    返り値: None。Root174/173のSource・正本を変更しない。
    """
    fixed_path = TARGET / "旧73jointの固定選択.json"
    assert Q.fingerprint(fixed_path)["sha256"] == FIXED_SHA
    fixed = Q.read(fixed_path)
    policies = [policy for route in fixed["選択"].values() for policy in route["candidates"]]
    assert {policy["id"] for policy in policies} == set(IDS)
    source_paths = [TARGET / name for name in ("段階再生174.py", "数量候補を選ぶ.py", "数量候補を選ぶ173原版.py")]
    source_paths += [ROOT / "work/173両中央値と単一建玉/基盤173.py", ROOT / "work/173両中央値と単一建玉/構成173.py",
                     ROOT / "work/173追加なしの因果再生/engine173.py", ROOT / "work/173追加なしの評価/metrics173.py",
                     HERE / "接続174.py", ROOT / "work/173自然結果の独立検査/Source/旧73を検査する.py"]
    before = [Q.fingerprint(path) for path in source_paths]
    joint_path = TARGET / "三帯接合global1.json.gz"
    official, _ = selected_rows(joint_path, set(IDS))
    assert all(official[policy["id"]]["policy"] == policy for policy in policies)
    packs_paths = {"旧73": APPLICATION / "旧73の全取得174.json.gz", "追加7": APPLICATION / "追加7の全取得174.json.gz",
                   "全80": APPLICATION / "全80の両中央値174.json.gz"}
    packs = {part: Q.read(path) for part, path in packs_paths.items()}
    by_id = {part: {row["id"]: row for row in pack["rows"]} for part, pack in packs.items()}
    assert all(set(rows) == set(IDS) for rows in by_id.values())
    assert all(by_id[part][policy["id"]]["policy"] == policy for part in by_id for policy in policies)
    directions_old, refs = direct_births(policies)
    contexts, replays, reports, old_checks = {}, {}, {}, []
    trade_rows, scene_rows = [], []
    for part, is_new in (("旧73", False), ("追加7", True)):
        context = Q.B.load_context(is_new)
        assert context.sessions == packs[part]["場順"]
        contexts[part] = context
        base, _, _ = Q.B.P.baseline(context)
        captures = Q.B.captures(context)
        directions = V.rebuild_directions(context, policies) if is_new else directions_old
        replays[part], reports[part] = {}, {}
        for policy in policies:
            name = policy["id"]
            composed = compose(context, policy, directions, base)
            V.compare_pure_birth(context, policy, composed, APPLICATION / (part + "の純出生174.npz"))
            replay = Q.independent_replay(context, composed, captures)
            V.compare_pack(context, replay, by_id[part][name])
            groups, count = V.compare_financial(context, replay["trades"], by_id[part][name]["financial"])
            replays[part][name] = replay
            reports[part][name] = {"財務照合数": count, "要求数": len(replay["requests"]),
                                    "要求SHA256": Q.digest_json(replay["requests"]), "取得SHA256": Q.digest_json(replay["records"]),
                                    "groups": {band: V.concise(group) for band, group in groups.items()}}
            trade_rows.extend({"政策": name, "入力区分": part, "セッション": context.sessions[trade["scene"]], **trade} for trade in replay["trades"])
            if not is_new:
                old_checks.append(compare_stage(context, policy, replay, composed[-1], official[name]))
            print(json.dumps({"区分": part, "政策": name, "独立取得": len(replay["records"]), "一致": True}, ensure_ascii=True), flush=True)
        if not is_new:
            # ----------------------------------------
            # jointで実際に選ばれたDay/Night構成政策も、その段階正本と金融全dictを照合する。
            component_ids = {policy[key] for policy in policies for key in ("day_policy", "night_policy")}
            component_official, stage_refs = {}, []
            for filename in ("単独global1.json.gz", "異技術ORglobal1.json.gz", "Night接合global1.json.gz"):
                wanted = {name for name in component_ids if ("_N" in name) == filename.startswith("Night")}
                if not wanted:
                    continue
                try:
                    rows, _ = selected_rows(TARGET / filename, wanted)
                except AssertionError:
                    if filename.startswith("単独"):
                        continue
                    raise
                component_official.update(rows)
                stage_refs.append(Q.fingerprint(TARGET / filename))
            assert set(component_official) == component_ids
            component_checks = []
            for row in component_official.values():
                policy = row["policy"]
                composed = compose(context, policy, directions, base)
                replay = Q.independent_replay(context, composed, captures)
                component_checks.append(compare_stage(context, policy, replay, composed[-1], row))
            old_result = {"確認日": "2026-11-16", "結果": "全検査成功", "対象": list(IDS), "全場数": 73,
                          "検査前後Source一致": True, "固定選択SHA256": FIXED_SHA, "Source": before,
                          "方法": "元出生方向・独立OR・逐次DayT待機・別pending/held状態機械・中央値直接再集計。Root replay/financial不使用。",
                          "policies": old_checks, "選択構成政策": component_checks, "構成段正本": stage_refs}
            assert before == [Q.fingerprint(path) for path in source_paths]
            (DESTINATION / "旧73独立結果174.json").write_text(json.dumps(old_result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    merged = SimpleNamespace(sessions=contexts["旧73"].sessions + contexts["追加7"].sessions,
                             hours=np.vstack([contexts["旧73"].hours, contexts["追加7"].hours]))
    assert len(merged.sessions) == len(set(merged.sessions)) == 80
    checks = []
    for policy in policies:
        name = policy["id"]
        trades = copy.deepcopy(replays["旧73"][name]["trades"])
        trades += [dict(trade, scene=trade["scene"] + 73) for trade in replays["追加7"][name]["trades"]]
        expected = {"net": [trade["net"] for trade in trades], "known": [trade["known"] for trade in trades],
                    "label": [trade["label"] for trade in trades], "scene": [merged.sessions[trade["scene"]] for trade in trades]}
        assert expected == by_id["全80"][name]["ledger"]
        assert [trade["phase"] for trade in trades] == by_id["全80"][name]["phases"]
        assert [trade["origin"] for trade in trades] == by_id["全80"][name]["origins"]
        groups, count = V.compare_financial(merged, trades, by_id["全80"][name]["financial"])
        assert groups["ALL"]["sessions"]["eligible_count"] == 80
        assert groups["DAY"]["sessions"]["eligible_count"] == groups["NIGHT"]["sessions"]["eligible_count"] == 40
        checks.append({"id": name, "Day補完待機分": policy.get("day_fallback_after_minutes", 45),
                       "追加7独立再生一致": True, "全80財務一致": True, "枠占有違反": 0, "全80財務照合数": count,
                       "旧73": reports["旧73"][name], "追加7": reports["追加7"][name],
                       "全80": {band: V.concise(group) for band, group in groups.items()}})
        for band in ("DAY", "NIGHT"):
            scene_rows.extend({"政策": name, "帯": band, **row} for row in groups[band]["sessions"]["rows"])
    assert before == [Q.fingerprint(path) for path in source_paths]
    result_path = DESTINATION / "追加7と全80の独立結果174.json"
    result = {"確認日": "2026-11-16", "結果": "全検査成功", "対象": list(IDS), "全場数": 80,
              "検査前後Source一致": True, "固定選択SHA256": FIXED_SHA, "Source": before,
              "入力": [Q.fingerprint(path) for path in (fixed_path, joint_path, *packs_paths.values(), APPLICATION / "旧73の純出生174.npz", APPLICATION / "追加7の純出生174.npz")],
              "元出生": refs, "policies": checks}
    result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    write_csv(DESTINATION / "全80独立取引174.csv", trade_rows)
    write_csv(DESTINATION / "全80独立場別174.csv", scene_rows)
    paths = (Path(__file__), HERE / "接続174.py", DESTINATION / "旧73独立結果174.json", result_path,
             DESTINATION / "全80独立取引174.csv", DESTINATION / "全80独立場別174.csv")
    (DESTINATION / "自然検査SHA256174.json").write_text(json.dumps({path.name: Q.fingerprint(path) for path in paths}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
