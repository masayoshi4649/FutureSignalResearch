"""174固定案を、173の独立状態機械へ接続する準備部品。自然入力は自動で読まない。"""

from __future__ import annotations

import importlib.util
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[3]


def delayed_composition(composed: tuple, phases: np.ndarray, event_scenes: np.ndarray,
                        event_keys: list, scene_starts: np.ndarray, minutes: int) -> tuple:
    """
    機能: 独立合成後のDay旧Tだけを当該場開始から指定分まで抑制する。
    引数: composed（tuple）core/technical/tier/width/hi/conflict、phases/event_scenes（np.ndarray）、
          event_keys（list[tuple]）、scene_starts（np.ndarray）、minutes（int）45/90/120/180。
    返り値: tuple。全配列を複写した独立出生。境界時刻ちょうどは許可し、主・Nightを変えない。
    """
    if minutes not in (45, 90, 120, 180):
        raise ValueError("Day旧T待機は固定した45/90/120/180分で指定する。")
    output = tuple(value.copy() for value in composed)
    for row, phase in enumerate(phases):
        if phase == 0 and event_keys[row][0] < scene_starts[int(event_scenes[row])] + minutes * 60:
            output[1][row] = 0
            output[2][row] = 0
    return output


def independent173():
    """
    機能: 将来の自然固定案検査時だけ、173の別状態機械Sourceを読み込む。
    引数: なし。
    返り値: module。金融・自然特徴のloader関数は呼ばない。
    """
    path = ROOT / "work/173自然結果の独立検査/Source/旧73を検査する.py"
    specification = importlib.util.spec_from_file_location("independent173_for174", path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def compose(context: object, policy: dict, directions: dict, base: dict) -> tuple:
    """
    機能: 固定政策の独立ORへDay待機を加え、Root174の構成関数に依存しない出生を作る。
    引数: context（object）当時時計、policy（dict）固定174政策、directions（dict）封印出生、base（dict）旧T。
    返り値: tuple。173の独立数量再生へ渡せる出生。
    """
    source = independent173()
    original = source.independent_compose(context, policy, directions, base)
    return delayed_composition(original, context.event_phases, context.event_scenes, context.event_keys,
                               np.asarray([scene["start"] for scene in context.scenes]),
                               int(policy.get("day_fallback_after_minutes", 45)))


def replay(context: object, policy: dict, directions: dict, base: dict, descriptors: list) -> dict:
    """
    機能: Root174のreplayを使わず、Day待機を含む固定出生を別pending/held状態機械で再生する。
    引数: context（object）、policy（dict）、directions（dict）、base（dict）、descriptors（list）。
    返り値: dict。全要求・取得・財務・予約占有区間・独立監査。
    """
    source = independent173()
    return source.independent_replay(context, compose(context, policy, directions, base), descriptors)
