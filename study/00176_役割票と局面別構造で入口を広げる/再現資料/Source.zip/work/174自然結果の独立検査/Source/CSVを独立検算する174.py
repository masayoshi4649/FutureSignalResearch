"""型付き入力と金融dictを使わず、全80 ledgerから4CSVの全セルを独立再計算する。"""

from __future__ import annotations

import csv
import json
import math
import sys
from decimal import Decimal
from pathlib import Path
from types import SimpleNamespace

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DESTINATION = HERE.parent
OUTPUT = ROOT / "outputs/00174_追加禁止と両中央値の比較"
sys.path.insert(0, str(ROOT / "work/173自然結果の独立検査/Source"))
import 旧73を検査する as Q

COMPARISON_HEADERS = ["候補", "選択範囲", "区分", "対象場数", "取得場数", "取得回数", "主取得", "補完取得",
    "F", "A", "N", "C", "金融未知件数", "先着率", "既知利益円", "既知損失円", "既知収支円", "利益損失比",
    "建玉中央値下限円", "建玉中央値上限円", "場中央値下限円", "場中央値上限円", "完全場数", "両中央値判定", "取得毎時", "全件確定収支円"]
SESSION_HEADERS = ["候補", "選択範囲", "セッション日", "セッションID", "利益円_既知", "損失円_既知", "収支円_全件確定",
    "収支円_既知分", "累計収支円_全件確定", "累計収支円_既知分", "取得回数", "主取得", "補完取得", "F", "A", "N", "C", "金融未知件数", "累計金融未知件数", "取引なし理由"]


def ledger_trades(context: object, row: dict) -> list:
    """
    機能: ledgerとphases/originsだけを独立取得行へ変換する。金融dictは参照しない。
    引数: context（object）全場順、row（dict）固定1政策の保存pack。
    返り値: list[dict]。未知netをNoneのまま持つ取得。
    """
    ledger = row["ledger"]
    mapping = {scene: index for index, scene in enumerate(context.sessions)}
    result = []
    for value, known, label, scene, phase, origin in zip(ledger["net"], ledger["known"], ledger["label"], ledger["scene"], row["phases"], row["origins"], strict=True):
        assert isinstance(known, bool) and label in (1, -1, 0, 2) and phase in (0, 1, 2) and origin in (0, 2)
        assert value is None if not known else value is not None and math.isfinite(value)
        result.append({"net": value, "known": known, "label": label, "scene": mapping[scene], "phase": phase, "origin": origin})
    return result


def expected_tables(context: object, packs: dict) -> dict:
    """
    機能: ledgerと独立Contextの対象場/時間から、利益損失・中央値・参加・累計等の全CSV値を再計算する。
    引数: context（object）全80場と時間、packs（dict[int,dict]）173/174固定全80正本。
    返り値: dict。表名→headers/rows。
    """
    result = {"候補比較": {"headers": COMPARISON_HEADERS, "rows": []}}
    for name in ("デイ", "ナイト_米前", "ナイト_米後"):
        result[name] = {"headers": SESSION_HEADERS, "rows": []}
    for trial, pack in packs.items():
        for row in pack["rows"]:
            identity, route = f"{trial}:{row['id']}", row["policy"]["route"]
            trades = ledger_trades(context, row)
            groups = {}
            for band, phases in (("DAY", {0}), ("NIGHT", {1, 2}), ("PRE", {1}), ("POST", {2})):
                eligible = [scene for scene in range(80) if context.hours[scene, list(phases)].sum() > 0]
                group = Q.aggregate(context, trades, eligible, band)
                groups[band] = group
                chosen = [trade for trade in trades if trade["phase"] in phases]
                t, s = group["trades"], group["sessions"]
                labels, tm, sm = t["IFD_FIRSTFANC"], t["net_median"], s["net_median"]
                result["候補比較"]["rows"].append([identity, route, band, len(eligible), s["participating_count"], len(chosen),
                    sum(trade["origin"] == 0 for trade in chosen), sum(trade["origin"] == 2 for trade in chosen),
                    *[labels[key] for key in ("F", "A", "N", "C")], t["unknown_count"], labels["first_f_rate_reached"],
                    t["known_profit"], t["known_loss"], t["known_net"], t["known_profit"] / t["known_loss"] if t["known_loss"] else None,
                    tm["lower"], tm["upper"], sm["lower"], sm["upper"], s["complete_count"], group["decision_status"],
                    group["acquisitions_per_hour"], t["known_net"] if not t["unknown_count"] else None])
            for phase, band, filename in ((0, "DAY", "デイ"), (1, "PRE", "ナイト_米前"), (2, "POST", "ナイト_米後")):
                cumulative_net, cumulative_unknown = 0, 0
                scenes = sorted(groups[band]["sessions"]["rows"], key=lambda item: item["scene"])
                assert len(scenes) == 40
                for scene in scenes:
                    count = scene["all_count"]
                    cumulative_net += scene["known_net"]
                    cumulative_unknown += scene["unknown_count"]
                    reason = "" if count else ("技術不成立又は取得代用不成立。監査正本を参照。" if phase == 0
                        else "当該小帯で取得なし。Night全体の参加は候補比較のNIGHTを参照。")
                    result[filename]["rows"].append([identity, route, scene["scene"].split("_")[0], scene["scene"],
                        scene["known_profit"], scene["known_loss"], scene["all_net"], scene["known_net"],
                        cumulative_net if not cumulative_unknown else None, cumulative_net, count, scene["main_count"], scene["supplement_count"],
                        *[scene[key] for key in ("F", "A", "N", "C")], scene["unknown_count"], cumulative_unknown, reason])
    return result


def equal_cell(expected: object, actual: str, column: str) -> bool:
    """
    機能: 空欄・文字列・数値を区別し、意味のある全セルを比較する。
    引数: expected（object）独立期待値、actual（str）CSVセル、column（str）列名。
    返り値: bool。率/PF/頻度だけ1e-12相対・1e-9絶対の丸めを許容し、金額と件数は完全比較。
    """
    if expected is None:
        return actual == ""
    if isinstance(expected, str):
        return actual == expected
    if actual == "":
        return False
    try:
        if column in ("先着率", "利益損失比", "取得毎時"):
            return math.isclose(float(expected), float(actual), rel_tol=1e-12, abs_tol=1e-9)
        return Decimal(str(expected)) == Decimal(actual)
    except (ValueError, ArithmeticError):
        return False


def main() -> None:
    """
    機能: 4CSVのヘッダを含む全セルを直接ledgerから検算し、正式保存gateを出す。
    引数: なし。
    返り値: None。型付き入力・金融dictは不使用。CSVは編集しない。
    """
    input_paths = {173: ROOT / "work/173追加七場適用/全80の両中央値173.json.gz",
                   174: ROOT / "work/174追加七場適用/全80の両中央値174.json.gz"}
    packs = {trial: Q.read(path) for trial, path in input_paths.items()}
    old, new = Q.B.load_context(False), Q.B.load_context(True)
    context = SimpleNamespace(sessions=old.sessions + new.sessions, hours=np.vstack([old.hours, new.hours]))
    assert len(context.sessions) == len(set(context.sessions)) == 80
    for pack in packs.values():
        for phase, band in enumerate(("DAY", "PRE", "POST")):
            expected = [scene for scene, hours in zip(context.sessions, context.hours, strict=True) if hours[phase] > 0]
            assert sorted(expected) == sorted(pack["対象場"][band])
    # ----------------------------------------
    # Cと金融未知が異なる人工例でも別計数する。Nの利益損失も直接収支に含める。
    artificial_context = SimpleNamespace(sessions=["人工_Day"], hours=np.array([[1.0, 0, 0]]))
    artificial = Q.aggregate(artificial_context, [
        {"scene": 0, "phase": 0, "origin": 0, "net": 10.0, "known": True, "label": 2},
        {"scene": 0, "phase": 0, "origin": 0, "net": 20.0, "known": True, "label": 2},
        {"scene": 0, "phase": 0, "origin": 2, "net": None, "known": False, "label": 1},
        {"scene": 0, "phase": 0, "origin": 0, "net": -5.0, "known": True, "label": 0},
    ], [0], "DAY")
    assert artificial["trades"]["IFD_FIRSTFANC"]["C"] == 2 and artificial["trades"]["unknown_count"] == 1
    assert artificial["trades"]["known_profit"] == 30 and artificial["trades"]["known_loss"] == 5
    tables = expected_tables(context, packs)
    csv_paths = [OUTPUT / (name + ".csv") for name in tables]
    before = [Q.fingerprint(path) for path in csv_paths]
    errors, cells, files = [], 0, []
    for name, table in tables.items():
        path = OUTPUT / (name + ".csv")
        with path.open("r", encoding="utf-8-sig", newline="") as handle:
            actual = list(csv.reader(handle))
        expected = [table["headers"], *table["rows"]]
        assert len(actual) == len(expected), (name, len(actual), len(expected))
        for row_number, (left, right) in enumerate(zip(expected, actual, strict=True), start=1):
            assert len(left) == len(right) == len(table["headers"]), (name, row_number)
            for column, (value, text) in enumerate(zip(left, right, strict=True)):
                cells += 1
                if not equal_cell(value, text, table["headers"][column]):
                    errors.append({"ファイル": name, "行": row_number, "列": table["headers"][column], "期待": value, "CSV": text})
        files.append({"表": name, "データ行数": len(table["rows"]), "列数": len(table["headers"]),
                      "検査セル数": len(expected) * len(table["headers"]), "全セル一致": not any(error["ファイル"] == name for error in errors)})
    assert before == [Q.fingerprint(path) for path in csv_paths]
    result = {"確認日": "2026-11-16", "結果": "全検査成功" if not errors else "不一致", "全セル一致": not errors,
              "検査セル数": cells, "候補数": 8, "ファイル数": 4, "型付き入力未使用": True, "金融dict未使用": True,
              "検査前後CSV一致": True, "金融未知とCを独立計数": True,
              "方法": "173/174全80ledgerから収支・場集計・両中央値・参加・主補完・FANC・累計を再計算。場と時間は共用Contextから独立構成。",
              "ファイル指紋": before, "入力指紋": [Q.fingerprint(path) for path in input_paths.values()],
              "表": files, "不一致数": len(errors), "不一致先頭": errors[:20]}
    path = DESTINATION / "CSV独立検算.json"
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    (DESTINATION / "CSV独立SHA256.json").write_text(json.dumps({"Source/CSVを独立検算する174.py": Q.fingerprint(Path(__file__)),
        "CSV独立検算.json": Q.fingerprint(path)}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"全セル一致": not errors, "検査セル数": cells, "不一致数": len(errors)}, ensure_ascii=True))
    assert not errors


if __name__ == "__main__":
    main()
