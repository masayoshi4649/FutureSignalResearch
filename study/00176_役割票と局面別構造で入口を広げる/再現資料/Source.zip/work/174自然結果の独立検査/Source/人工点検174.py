"""174の共同条件4枠とDay旧T待機を、自然結果なしでAST・人工により独立点検する。"""

from __future__ import annotations

import copy
import hashlib
import heapq
import importlib.util
import json
import math
import sys
from collections import Counter
from itertools import combinations, product
from pathlib import Path
from types import SimpleNamespace

import numpy as np

from 接続174 import delayed_composition

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
TARGET = ROOT / "work/174参加と両中央値の再探索"
DESTINATION = HERE.parent


def sha(path: Path) -> str:
    """
    機能: 対象Sourceの指紋を計算する。
    引数: path（Path）Source。
    返り値: str。SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def old_artificial():
    """
    機能: 173のAST専用人工補助だけを読み込み、自然loaderを呼ばない。
    引数: なし。
    返り値: module。関数抽出・人工群・期間guardを再用する。
    """
    path = ROOT / "work/173数量接続の独立確認/Source/人工点検.py"
    specification = importlib.util.spec_from_file_location("artificial173_for174", path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


def group(helper: object, median: float, f: int = 24, a: int = 6, active: int = 8) -> dict:
    """
    機能: 174共同条件に必要な人工指標を生成する。
    引数: helper（object）人工補助、median（float）両中央値下限、f/a/active（int）先着数・参加場数。
    返り値: dict。自然値を使わない選択群。
    """
    result = helper.artificial_group(median)
    result["trades"]["all_count"] = f + a
    result["trades"]["IFD_FIRSTFANC"] = {"F": f, "A": a, "reached_count": f + a, "first_f_rate_reached": f / (f + a) if f + a else None}
    result["sessions"]["participating_count"] = active
    return result


def check_selection(helper: object, selector: object) -> dict:
    """
    機能: 同じ技術群の共同適合4候補留保・70%境界・支持・一期間限定を独立確認する。
    引数: helper（object）人工補助、selector（object）174固定選択Source。
    返り値: dict。検査件数と結果。
    """
    rows = [{"id": f"A{i:02}", "policy": {"families": [f"非共同{i}"]},
             "periods": helper.OnePeriod({"前48": {"NIGHT": group(helper, -100, 29, 1, 12)}})} for i in range(30)]
    rows += [{"id": f"Z{i:02}", "policy": {"families": ["同じ技術群"]},
              "periods": helper.OnePeriod({"前48": {"NIGHT": group(helper, i + 1, 21, 9, 7 + i)}})} for i in range(6)]
    selected = selector.choose(rows, "前48", "NIGHT")
    joint = [row for row in selected if row["selected_by"] == "共同条件"]
    assert len(joint) == 4 and [row["id"] for row in joint] == ["Z05", "Z04", "Z03", "Z02"]
    assert all(row["policy"]["families"] == ["同じ技術群"] for row in joint)
    assert len(selected) <= 16 and len({row["id"] for row in selected}) == len(selected)
    assert selected == selector.choose(list(reversed(rows)), "前48", "NIGHT")
    assert len(selector.choose(rows, "前48", "NIGHT", maximum=1)) == 1
    assert len(selector.choose(rows, "前48", "NIGHT", maximum=4)) == 4
    assert selector.choose([], "前48", "NIGHT") == []
    assert selector.joint_eligible(group(helper, 1, 21, 9))
    assert not selector.joint_eligible(group(helper, 1, 20, 10))
    assert not selector.joint_eligible(group(helper, 0, 29, 1))
    insufficient = group(helper, 1, 21, 9)
    insufficient["resolved_scene_count"] = 2
    assert not selector.joint_eligible(insufficient)
    unknown = group(helper, 1, 21, 9)
    unknown["trades"]["unknown_count"] = 7
    assert not selector.joint_eligible(unknown)
    assert selector.artificial()["成功"]
    return {"共同4枠同群でも保持": True, "一期間guard": True, "70%以上と支持": True,
            "最大16とID同点固定": True, "共同留保ID": [row["id"] for row in joint]}


def check_delay(stage: object, engine: object) -> dict:
    """
    機能: 4待機の境界・主/Night不変・場別時計・prefix・実engine初取得を人工照合する。
    引数: stage（object）174固定段階Source、engine（object）173純engine。
    返り値: dict。待機ごとの独立照合と取得境界。
    """
    result = {}
    for minutes in (45, 90, 120, 180):
        seconds = minutes * 60
        phases = np.array([0, 0, 0, 1, 2, 0, 0, 0], np.int8)
        scenes = np.array([0, 0, 0, 1, 1, 2, 2, 2], np.int8)
        starts = np.array([10000, 30000, 50000], dtype=float)
        times = [10000 + seconds - 1, 10000 + seconds, 10000 + seconds + 1, 30100, 30200,
                 50000 + seconds - 1, 50000 + seconds, 50000 + seconds + 1]
        keys = [(value, row, row) for row, value in enumerate(times)]
        core = np.array([1, -1, 1, -1, 1, -1, 1, -1], np.int8)
        technical = -core
        tiers = np.array([1, 2] * 4, np.int8)
        birth = {"core": core, "branches": np.zeros(8, np.int8), "technical": technical, "tier": tiers}
        before = {name: value.copy() for name, value in birth.items()}
        actual = stage.delay_day_fallback(birth, phases, scenes, keys, starts, minutes)
        composed = (core, technical, tiers, np.full(8, 200, np.int16), np.zeros(8, np.int8), np.zeros(8, bool))
        reference = delayed_composition(composed, phases, scenes, keys, starts, minutes)
        assert actual["technical"].tolist() == [0, 1, -1, 1, -1, 0, -1, 1]
        assert np.array_equal(actual["technical"], reference[1]) and np.array_equal(actual["tier"], reference[2])
        assert np.array_equal(actual["core"], core) and np.array_equal(actual["branches"], birth["branches"])
        assert all(np.array_equal(value, before[name]) for name, value in birth.items())
        assert not np.shares_memory(actual["technical"], technical) and not np.shares_memory(actual["tier"], tiers)
        for end in range(9):
            cut = {name: value[:end] for name, value in birth.items()}
            prefix = stage.delay_day_fallback(cut, phases[:end], scenes[:end], keys[:end], starts, minutes)
            assert np.array_equal(prefix["technical"], actual["technical"][:end])
        q0 = [2699, 2700, 5399, 5400, 7199, 7200, 10799, 10800]
        keys = [(float(value), row * 2, row * 2) for row, value in enumerate(q0)]
        source = {"core": np.zeros(8, np.int8), "branches": np.full(8, -1, np.int8),
                  "technical": np.ones(8, np.int8), "tier": np.ones(8, np.int8)}
        delayed = stage.delay_day_fallback(source, np.zeros(8, np.int8), np.zeros(8, np.int8), keys, np.array([0]), minutes)
        captures = [{"status": "filled", "case": row, "fill_key": (value + 0.5, row * 2 + 1, row * 2 + 1)}
                    for row, value in enumerate(q0)]

        def exit_lookup(event: int, case: int, side: int, width: int) -> float:
            """
            機能: 実engine人工例へ既知の短い決済時計だけを渡す。
            引数: event/case/side/width（int）人工取得。
            返り値: float。q0から60秒後。
            """
            return float(q0[event] + 60)

        output = engine.replay(keys, np.zeros(8, np.int8), np.array([0]), np.array([20000]), captures,
                               delayed["core"], delayed["branches"], delayed["technical"], delayed["tier"],
                               np.full(8, 200, np.int16), np.full(8, 200, np.int16), 200, exit_lookup)
        assert len(output["records"]) == 1
        event = output["records"][0]["event"]
        assert q0[event] == seconds
        result[str(minutes)] = {"境界前停止_境界許可": True, "主とNight不変": True,
                                "入力非破壊と全prefix": True, "実engine初取得経過秒": q0[event]}
    return result


def check_routes(helper: object, stage: object, selector: object) -> dict:
    """
    機能: 自然結果なしでORの4待機政策とjointの待機引継ぎを全ルート確認する。
    引数: helper（object）、stage（object）174Source、selector（object）174選択器。
    返り値: dict。人工段階の政策数。
    """
    memory, observed = {}, {}
    selected = {}
    for route in ("全期", "前48"):
        selected[route] = {}
        for band in ("DAY", "PRE", "POST"):
            selected[route][band] = []
            for number in range(2):
                rule = {"id": f"{band}_R{number}", "birth_key": f"{band}_R{number}", "width": 150,
                        "horizon": "H60"}
                policy = {"id": f"{route}_{band}_S{number}", "route": route, "band": band,
                          "families": [f"技術{number}"], "options": {band: [rule]}, "fallback": False}
                selected[route][band].append({"id": policy["id"], "policy": policy})
    memory[TARGET / "単独global1の短表.json"] = {"選択": selected}
    memory[TARGET / "単独global1.json.gz"] = {"rows": []}

    def read(path: Path):
        """
        機能: 人工の資料名だけを許可し、自然結果ファイルを開かない。
        引数: path（Path）要求名。
        返り値: object。人工資料。
        """
        return memory[path]

    def save(path: Path, value: dict) -> None:
        """
        機能: 段階出力を人工メモリ内だけに保存する。
        引数: path（Path）、value（dict）。
        返り値: None。
        """
        memory[path] = value

    def run_stage(name: str, policies: list, workers: int) -> list:
        """
        機能: 金融再生せず、各政策の一つの選択期間だけを持つ結果を返す。
        引数: name（str）、policies（list）、workers（int）。
        返り値: list。別期間アクセスが失敗する人工結果。
        """
        observed[name] = copy.deepcopy(policies)
        return [{"id": policy["id"], "policy": policy,
                 "periods": helper.OnePeriod({policy["route"]: {band: helper.artificial_group() for band in ("DAY", "PRE", "POST", "NIGHT")}})}
                for policy in policies]

    stage.B = SimpleNamespace(P=SimpleNamespace(read=read, save=save))
    stage.run_stage, stage.choose = run_stage, selector.choose
    stage.or_stage(1)
    day_t = [policy for policy in observed["異技術ORglobal1"] if policy.get("fallback", False)]
    assert len(day_t) == 24
    groups = {}
    for policy in day_t:
        assert policy["fallback_by_band"] == {"DAY": True, "PRE": False, "POST": False}
        assert set(policy["options"]) == {"DAY"}
        groups.setdefault((policy["route"], policy["id"].rsplit("_T", 1)[0]), set()).add(policy["day_fallback_after_minutes"])
    assert all(delays == {45, 90, 120, 180} for delays in groups.values())
    joint_selected = {}
    for route in ("全期", "前48"):
        days = [{"id": policy["id"], "policy": policy} for policy in day_t if policy["route"] == route]
        nights = [{"id": f"{route}_N{int(fallback)}", "policy": {
            "id": f"{route}_N{int(fallback)}", "route": route, "families": ["夜間技術"],
            "options": {"PRE": [], "POST": []}, "fallback": fallback}} for fallback in (False, True)]
        joint_selected[route] = {"DAY": days, "NIGHT": nights}
    memory[TARGET / "Night接合の短表.json"] = {"選択": joint_selected}
    previous_module = sys.modules.get("数量候補を選ぶ")
    sys.modules["数量候補を選ぶ"] = selector
    try:
        fixed = stage.joint_stage(1)
    finally:
        if previous_module is None:
            sys.modules.pop("数量候補を選ぶ", None)
        else:
            sys.modules["数量候補を選ぶ"] = previous_module
    by_id = {policy["id"]: policy for policy in day_t}
    for policy in observed["三帯接合global1"]:
        day = by_id[policy["day_policy"]]
        assert policy["day_fallback_after_minutes"] == day["day_fallback_after_minutes"]
        assert policy["fallback_by_band"]["DAY"] and policy["fallback_by_band"]["PRE"] == policy["fallback_by_band"]["POST"]
    assert all(fixed[route]["主案"] is not None for route in ("全期", "前48"))
    return {name: len(policies) for name, policies in observed.items()}


def main() -> None:
    """
    機能: 174変更点の人工点検と将来の独立接続準備を完了し、指紋付き小JSONを残す。
    引数: なし。
    返り値: None。174自然値・候補結果は読み込まない。
    """
    paths = [TARGET / name for name in ("段階再生174.py", "数量候補を選ぶ.py", "数量候補を選ぶ173原版.py")]
    paths += [ROOT / "work/173追加なしの因果再生/engine173.py"]
    before = {path.relative_to(ROOT).as_posix(): sha(path) for path in paths}
    helper = old_artificial()
    shared = {"np": np, "math": math, "Counter": Counter, "Path": Path, "heapq": heapq,
              "combinations": combinations, "product": product}
    original = helper.functions_only(paths[2], "selector173_base_for174", shared)
    selector = helper.functions_only(paths[1], "selector174_independent", {**shared,
                                      "keys": original.keys, "support": original.support, "wilson": original.wilson})
    stage = helper.functions_only(paths[0], "stage174_independent", {**shared, "ROOT": ROOT, "HERE": TARGET})
    engine = helper.functions_only(paths[3], "engine173_for174_artificial", shared)
    selection_result = check_selection(helper, selector)
    delay_result = check_delay(stage, engine)
    routes = check_routes(helper, stage, selector)
    assert before == {path.relative_to(ROOT).as_posix(): sha(path) for path in paths}
    result = {"確認日": "2026-11-16", "結果": "全検査成功", "174自然結果読込": False,
              "固定Source編集": False, "検査前後Source一致": True, "共同条件留保": selection_result,
              "DayT待機": delay_result, "人工ルート政策数": routes,
              "独立接続準備": {"Source": "Source/接続174.py", "API": "compose(context,policy,directions,base) / replay(context,policy,directions,base,descriptors)",
                               "方式": "独立ORと逐次Day待機を、173の別pending/held状態機械へ接続。自然loaderは自動実行しない。"},
              "不具合": [], "SourceSHA256": before}
    (DESTINATION / "人工結果174.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    hashes = {"Source/人工点検174.py": sha(Path(__file__)), "Source/接続174.py": sha(HERE / "接続174.py"),
              "人工結果174.json": sha(DESTINATION / "人工結果174.json")}
    (DESTINATION / "SHA256.json").write_text(json.dumps(hashes, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"結果": "成功", "174自然結果読込": False, "人工ルート": routes}, ensure_ascii=True))


if __name__ == "__main__":
    main()
