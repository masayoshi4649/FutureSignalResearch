"""175の局面別複合入口。入力は当時の実側100特徴とq0識別だけ。"""
from collections.abc import Mapping
from itertools import product
from pathlib import Path
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/172ナイト複合候補'))
from rules172_night import NightEvaluator
from rules162 import term

VERSION='175局面別純入口1'
GROUPS={
    'HT':('ADX中間以上の押戻し再開',['DMI/ADX','移動平均','MACD','RSI','価格構造','観測量']),
    'HB':('ADX中間以上の価格端突破と動力持続',['DMI/ADX','移動平均','MACD','RSI','価格構造','実体','観測量']),
    'HR':('ADX低下と反対動力失速後の構造回復',['DMI/ADX','MACD','RSI','BB','実体回復','観測量']),
    'HM':('背景混在から短期DIが整理される回復',['DMI/ADX','移動平均','MACD','RSI','実体回復','観測量']),
    'LC':('長期未公表の場だけの局所複合確認',['移動平均','DMI/ADX','MACD','RSI','実体','観測量']),
    'RL':('低ADXの帯端から動力と実体が回復',['DMI/ADX','BB','MACD','RSI','実体回復','観測量']),
}


def _get(features: object,name: str) -> object:
    """
    機能: 辞書又は属性束から純特徴を取得する。
    引数: features(object)、name(str)は必須属性名。
    返り値: objectは対応する入力。金融値を補って作らない。
    """
    return features[name] if isinstance(features,Mapping) else getattr(features,name)


def candidate_catalog() -> list[dict]:
    """
    機能: 六群各48論理規則へALL/EDGEを適用した固定576候補を作る。
    引数: なし。
    返り値: list[dict]は全比較式・状態・発火方式・技術役割を持つ辞書。
    """
    rules=[]
    for group in GROUPS:
        if group=='LC':
            settings=product((120,180),(.5,.75,1.0),(0,60),(0,1),(.5,1.0))
        else:
            depths={'HT':(0,.25),'HB':(0,.1),'HR':(8,12),'HM':(0,5),'RL':(1,1.5)}[group]
            settings=product((5,10),depths,(0,60),(.5,.75,1.0),(0,1))
        for number,values in enumerate(settings,1):
            if group=='LC':
                after,volume,hold,profile,chase=values
                window=None;depth=None
            else:
                window,depth,hold,volume,profile=values
                after=None;chase=1.0
            spike=8 if profile==0 else 4
            conditions=[term('q0_spread_points','>',0),term('q0_spread_points','<=',20),
                term('abs_q0_close_gap','<=',1),term('q0_entry_minus_ema8_atr5_to_side','>=',-.25),
                term('q0_entry_minus_ema8_atr5_to_side','<=',chase),
                term('m1_tr_atr5_ratio','<=',1.5),term('m5_tr_previous_atr_ratio','<=',2.5),
                term('n_abs_rsi_delta5','<=',spike),term('m1_volume_relative_prior3','>=',volume)]
            if group=='HT':
                conditions += [term('m15_adx','>=',20+5*profile),
                    term('ema_up_count','>=',2+profile),term('di_up_count','>=',2+profile),
                    term('long_up_votes','>=',2+profile),term('short_up_votes','>=',2),
                    term('m15_hist_delta_to_side','>=',0),term('m5_hist_delta_to_side','>',0),
                    term('m5_rsi_delta_to_side','>',0),term('m5_rsi_center_to_side','<=',20),
                    term('m1_body_ratio_to_side','>',0),term('live_reclaim','>',0),
                    term(f'n_event|NP|{window}|{depth}|{hold}','>',.5)]
            elif group=='HB':
                conditions += [term('m15_adx','>=',20+5*profile),
                    term('m15_adx_delta','>=',-.25 if profile==0 else 0),
                    term('ema_up_count','>=',2),term('di_up_count','>=',2),
                    term('long_up_votes','>=',2+profile),
                    term('m5_hist_delta_to_side','>',0),term(f'p175_hist_min|{window}','>=',0),
                    term('m5_rsi_delta_to_side','>',0),term('m5_rsi_center_to_side','<=',20),
                    term('m5_body_ratio_to_side','>=',.2+.2*profile),
                    term(f'p175_break|{window}|{depth}|{hold}','>',.5)]
            elif group=='HR':
                conditions += [term('m15_adx','>=',20+5*profile),
                    term('m15_adx_delta','<=',0 if profile==0 else -.25),
                    term('long_up_votes','<=',2-profile),term('short_up_votes','>=',2),
                    term('m5_di_difference_to_side','>',0),
                    term('m5_hist_delta_atr_to_side','>',0),term('m5_hist_delta_atr_to_side','<=',.15),
                    term('m5_rsi_delta_to_side','>',0),term('m5_rsi_delta_to_side','<=',4),
                    term('bb15_position_sigma_to_side','<=',.5),
                    term('m1_body_ratio_to_side','>',0),term('live_reclaim','>',0),
                    term(f'n_event|NS|{window}|{depth}|{hold}','>',.5)]
            elif group=='HM':
                conditions += [term('m15_adx','>=',15+5*profile),term('m15_adx','<=',30+10*profile),
                    term('m15_adx_delta','>=',-.5 if profile==0 else 0),
                    term('long_up_votes','>=',1),term('long_up_votes','<=',3),
                    term('short_up_votes','>=',2),term('m5_hist_delta_to_side','>',0),
                    term('m15_hist_delta_to_side','>=',0),term('m5_rsi_delta_to_side','>',0),
                    term('m5_rsi_center_to_side','<=',20),term('live_reclaim','>',0),
                    term('m1_body_ratio_to_side','>',0),
                    term('m15_ema21_delta_to_side' if profile==0 else 'm30_ema21_delta_to_side','>=',0),
                    term(f'n_event|NX|{window}|{depth}|{hold}','>',.5)]
            elif group=='RL':
                conditions += [term('m15_adx','<=',15+5*profile),term('long_up_votes','<=',2),
                    term('bb15_position_sigma_to_side','<=',-.25),
                    term('bb15_mean_room_125_ratio_to_side','>',0),
                    term('m5_hist_delta_to_side','>',0),term('m5_rsi_delta_to_side','>',0),
                    term('m5_rsi_center_to_side','<=',5+5*profile),
                    term('m5_body_ratio_to_side','>',0),term('live_reclaim','>',0),
                    term(f'n_event|NR|{window}|{depth}|{hold}','>',.5)]
            else:
                conditions += [term('p175_local_allowed','>',.5),term('p175_elapsed_minutes','>=',after),
                    term('m5_ema21_delta_to_side','>',0),term('m5_di_difference_to_side','>',0),
                    term('m5_hist_delta_to_side','>',0),term('m5_rsi_delta_to_side','>',0),
                    term('m5_rsi_center_to_side','>=',-5),term('m5_rsi_center_to_side','<=',20),
                    term('m5_body_ratio_to_side','>',0 if profile==0 else .3),
                    term('m5_close_position_to_side','>',.5),term('m5_tr_atr_ratio','<=',2)]
            logical_id=f'{group}{number:04d}'
            for mode in ('ALL','EDGE'):
                rules.append({'id':logical_id+'_'+mode,'logical_id':logical_id,'group':group,'family':group,
                    'description':GROUPS[group][0],'technical_families':GROUPS[group][1],
                    'timeframes':[1,5] if group=='LC' else [1,5,15,30],
                    'settings':{'window_minutes':window,'depth':depth,'hold_seconds':hold,
                        'volume_min':volume,'profile':profile,'after_minutes':after,'chase_atr':chase,
                        'rsi_delta_abs_max':spike,'geometry_points':200},
                    'mode':mode,'confirmation_seconds':hold if group=='LC' else 0,'conditions':conditions})
    assert len(rules)==576 and len({r['id'] for r in rules})==576
    assert all(sum(r['group']==g for r in rules)==96 for g in GROUPS)
    return rules


def catalog() -> dict:
    """
    機能: 純入力・候補数・時計・限界と全規則を公開する。
    引数: なし。
    返り値: dictは実行前固定用の完全な辞書。
    """
    return {'version':VERSION,'logical_count':288,'candidate_count':576,'rules':candidate_catalog(),
        'groups':{g:{'description':v[0],'technical_families':v[1],'logical_count':48,'candidate_count':96} for g,v in GROUPS.items()},
        'input':'当時実側BUY/SELL100特徴、q0_meta、場開始秒だけ。金融・教師・取得を受けない。',
        'clock':'全場履歴で評価。場/scene/限月変更又はgap>180秒で動力履歴とEDGEをreset。NY境界ではresetしない。',
        'local':'m15_hist_delta_to_sideが当該場/限月で一度も公表されていない時だけ許可。未来の公表を先読みせず、一度公表後はgapでも再許可しない。',
        'geometry':'入口geometry200固定、対称IFD幅と独立。出口幅・期限で候補を増やす責務は呼出側。',
        'adx':'20以上は中間帯を含む研究閾値で、強い上昇を意味しない。方向はEMA/DI等の実側特徴で別確認する。',
        'limitations':['全閾値と5/15/30分の組合せは研究仮説であり公開資料の推奨値そのものではない。',
            '窓は現在を除く実分履歴。イベントの持続はq0観測の実秒であり、別々の確定5分足本数ではない。',
            'LCのM1/M5の局所票は長期票の代用値ではない。長期が未公表という別の情報状態を明示する。',
            'HBは更新されるprior3端の交差を使い、過去絶対価格を固定した完全な突破リテストではない。',
            '観測量は既存ラージ累積差分の当時特徴で、miniの全攻撃側約定量ではない。',
            '方向列は要求・取得・損益ではない。同じエピソードの近接q0を独立相場と数えない。']}


class Evaluator175(NightEvaluator):
    def __init__(self,features: object,scene_starts: object) -> None:
        """
        機能: 純特徴を親の因果履歴へ接続し、場/限月別の公表済み状態を作る。
        引数: features(object)はbuy_X/sell_X/columns/q0_meta、scene_starts(object)は場開始秒[S]。
        返り値: None。金融又は自然ファイルを読み込まない。
        """
        super().__init__(_get(features,'buy_X'),_get(features,'sell_X'),_get(features,'columns'),
            target_points=200,q0_meta=_get(features,'q0_meta'))
        starts=np.asarray(scene_starts,dtype=np.float64)
        scenes=np.asarray([q['session_index'] for q in self.q0_meta],dtype=np.int64)
        assert starts.ndim==1 and np.isfinite(starts).all()
        assert ((scenes>=0)&(scenes<len(starts))).all()
        self._elapsed=(self._times-starts[scenes])/60
        assert (self._elapsed>=0).all()
        reset=np.zeros(len(scenes),bool)
        for start,_ in self._segments:reset[start]=True
        self._reset175=reset;self._break175={}
        availability=np.isfinite(self.arrays[0][:,self.index['m15_hist_delta_to_side']])|np.isfinite(self.arrays[1][:,self.index['m15_hist_delta_to_side']])
        seen=set();allowed=np.ones(len(scenes),dtype=np.float64)
        for i,q in enumerate(self.q0_meta):
            key=(q['session'],int(scenes[i]),q['contract'])
            if availability[i]:seen.add(key)
            allowed[i]=float(key not in seen)
        self._local_allowed175=allowed

    def breakout_state(self,side: int,minutes: int,depth: float,hold: int) -> np.ndarray:
        """
        機能: 過去窓内から直近3分端を新しく越え、その外側を維持する状態を作る。
        引数: side(int)、minutes(int)、depth(float)、hold(int)は固定設定。
        返り値: np.ndarray[N]は成立1/非成立0/必要未知NaN。
        """
        key=(side,minutes,depth,hold)
        if key in self._break175:return self._break175[key]
        current=super().factor(side,'q0_last_minus_prior3_forward_edge_atr5_to_side')[0]
        before=self.previous(current);low=self.rolling(side,'q0_last_minus_prior3_forward_edge_atr5_to_side',minutes,'min')
        known=np.isfinite(current)&np.isfinite(before)&np.isfinite(low)
        event=(before<=depth)&(current>depth)&(low<=0)
        result=np.full(len(current),np.nan)
        for begin,end in self._segments:
            armed=None
            for i in range(begin,end):
                if not known[i]:armed=None;continue
                if current[i]<=0:armed=None
                if event[i]:armed=self._times[i]
                age=np.nan if armed is None else self._times[i]-armed
                result[i]=float(armed is not None and hold<=age<=minutes*60)
                if armed is not None and age>minutes*60:armed=None
        self._break175[key]=result
        return result

    def factor(self,side_index: int,name: str) -> tuple:
        """
        機能: 既存の当時派生に175固有の純履歴・公表状態だけを追加する。
        引数: side_index(int)は買0/売1、name(str)は特徴又は固定派生名。
        返り値: tuple[np.ndarray,np.ndarray]は値と既知mask。
        """
        if not name.startswith('p175_'):return super().factor(side_index,name)
        key=(side_index,name)
        if key not in self._factor_cache:
            if name=='p175_local_allowed':value=self._local_allowed175
            elif name=='p175_elapsed_minutes':value=self._elapsed
            elif name.startswith('p175_hist_min|'):
                value=self.rolling(side_index,'m5_hist_delta_to_side',int(name.split('|')[1]),'min')
            elif name.startswith('p175_break|'):
                _,minutes,depth,hold=name.split('|')
                value=self.breakout_state(side_index,int(minutes),float(depth),int(hold))
            else:raise KeyError('未定義の175派生: '+name)
            self._factor_cache[key]=(value,np.isfinite(value))
        return self._factor_cache[key]

    def evaluate_one(self,candidate: dict) -> dict:
        """
        機能: 対称比較の方向へ局所持続とALL/EDGEを同じ全場時計で適用する。
        引数: candidate(dict)はcatalogの固定一候補。
        返り値: dictは親互換の判定とmode適用済み方向。
        """
        result=super().evaluate_one(candidate)
        raw=result['directions'];hold=int(candidate['confirmation_seconds'])
        if hold and len(raw):
            boundaries=self._reset175|np.r_[True,raw[1:]!=raw[:-1]]
            starts=np.maximum.accumulate(np.where(boundaries,np.arange(len(raw)),0))
            raw=np.where((raw!=0)&(self._times-self._times[starts]>=hold),raw,0).astype(np.int8)
        if candidate['mode']=='EDGE' and len(raw):
            previous=np.r_[np.int8(0),raw[:-1]]
            raw=np.where(self._reset175|(raw!=previous),raw,0).astype(np.int8)
        result['directions']=raw
        return result


def build(features: object,scene_starts: object=None,phases: object=None,candidate_ids: list|None=None) -> dict:
    """
    機能: 純入力から固定候補のmode適用済み方向をまとめて返す。
    引数: features(object)、scene_starts(object|None)は省略時features.scene_starts、
          phases(object|None)は診断だけ、candidate_ids(list[str]|None)は固定部分集合。
    返り値: dictはcandidate_ids/directions[候補,N]int8と純状態診断。金融・取得は返さない。
    """
    if scene_starts is None:scene_starts=_get(features,'scene_starts')
    evaluator=Evaluator175(features,scene_starts)
    rules=candidate_catalog()
    if candidate_ids is not None:
        requested=set(candidate_ids);assert len(requested)==len(candidate_ids)
        known={r['id'] for r in rules};assert requested<=known
        mapping={r['id']:r for r in rules};rules=[mapping[name] for name in candidate_ids]
    matrix=np.asarray([evaluator.evaluate_one(r)['directions'] for r in rules],dtype=np.int8)
    if not rules:matrix=np.zeros((0,len(evaluator.q0_meta)),dtype=np.int8)
    result={'version':VERSION,'candidate_ids':[r['id'] for r in rules],'directions':matrix,
        'diagnostics':{'history_reset':evaluator._reset175.copy(),'local_allowed':evaluator._local_allowed175.copy(),
            'elapsed_minutes':evaluator._elapsed.copy()}}
    if phases is not None:
        values=np.asarray(phases);assert values.shape==(matrix.shape[1],) and np.isin(values,(0,1,2)).all()
        result['phases']=values.copy()
    return result
