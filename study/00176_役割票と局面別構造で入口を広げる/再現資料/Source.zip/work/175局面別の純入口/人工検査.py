"""自然特徴・金融を読まず175純入口の因果性と局面分離を検査する。"""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json

import numpy as np
import rules175 as R


def synthetic(group: str,n: int=70) -> tuple:
    """
    機能: 実在する特徴名だけを持つ人工100特徴とq0履歴を作る。
    引数: group(str)はHT/HB/HR/HM/RL/LC、n(int)は行数。
    返り値: tupleはfeatures(SimpleNamespace)と場開始秒np.ndarray。
    """
    names=set()
    for rule in R.candidate_catalog():
        names.update(t['factor'] for t in rule['conditions'] if not t['factor'].startswith(('p175_','n_')))
    names.update(['q0_last_minus_m1_close_atr5_to_side','m1_body_reclaim_atr5_to_side',
        'm5_price_ema8_atr_to_side','m5_hist_atr_to_side','q0_last_minus_prior3_forward_edge_atr5_to_side',
        'm5_gap_to_side','m15_hist_delta_to_side','m1_close_delta_atr5_to_side'])
    names.difference_update(['abs_q0_close_gap','ema_up_count','di_up_count','long_up_votes','short_up_votes','live_reclaim'])
    for m in (5,15,30):names.update([f'm{m}_ema21_delta_to_side',f'm{m}_di_difference_to_side'])
    names=sorted(names)
    names += [f'人工未使用{i}' for i in range(100-len(names))]
    assert len(names)==100
    index={name:i for i,name in enumerate(names)}
    buy=np.zeros((n,100),dtype=np.float64)

    def set_value(name: str,value: object) -> None:
        """
        機能: 人工買側列を設定する。
        引数: name(str)、value(object)は有限数・配列又は明示NaN。
        返り値: None。
        """
        buy[:,index[name]]=value

    set_value('q0_spread_points',10);set_value('m1_volume_relative_prior3',1.5)
    set_value('m1_tr_atr5_ratio',.5);set_value('m5_tr_previous_atr_ratio',1)
    set_value('m5_tr_atr_ratio',1);set_value('q0_entry_minus_ema8_atr5_to_side',.1)
    set_value('m1_body_ratio_to_side',.5);set_value('m5_body_ratio_to_side',.5)
    set_value('m5_close_position_to_side',.8);set_value('m5_rsi_delta_to_side',2)
    set_value('m5_hist_delta_to_side',.1);set_value('m5_hist_delta_atr_to_side',.1)
    set_value('m1_body_reclaim_atr5_to_side',.1);set_value('m15_hist_delta_to_side',.1)
    set_value('m15_adx',30);set_value('m15_adx_delta',.1)
    set_value('m5_gap_to_side',.1)
    for m in (5,15,30):
        set_value(f'm{m}_ema21_delta_to_side',.1);set_value(f'm{m}_di_difference_to_side',5)
    turn=n//2
    if group=='HT':
        set_value('m5_price_ema8_atr_to_side',np.r_[np.full(turn,-.5),np.full(n-turn,.3)])
    elif group=='HB':
        set_value('q0_last_minus_prior3_forward_edge_atr5_to_side',np.r_[np.full(turn,-.1),np.full(n-turn,.3)])
    elif group=='HR':
        set_value('m15_adx_delta',-.5)
        for m in (15,30):
            set_value(f'm{m}_ema21_delta_to_side',-.1);set_value(f'm{m}_di_difference_to_side',-5)
        set_value('m5_rsi_delta_to_side',np.r_[np.full(turn,-15),np.full(n-turn,2)])
        set_value('m5_hist_delta_atr_to_side',np.r_[np.full(turn,-.1),np.full(n-turn,.1)])
    elif group=='HM':
        set_value('m15_adx',25)
        set_value('m30_ema21_delta_to_side',-.1);set_value('m30_di_difference_to_side',-5)
        set_value('m5_di_difference_to_side',np.r_[np.full(turn,-8),np.full(n-turn,5)])
    elif group=='RL':
        set_value('m15_adx',12)
        for m in (15,30):
            set_value(f'm{m}_ema21_delta_to_side',-.1);set_value(f'm{m}_di_difference_to_side',-5)
        set_value('bb15_position_sigma_to_side',-1.6);set_value('bb15_mean_room_125_ratio_to_side',1)
        set_value('m1_close_delta_atr5_to_side',np.r_[np.full(turn,-.1),np.full(n-turn,.1)])
    elif group=='LC':
        set_value('m15_hist_delta_to_side',np.nan)
    else:raise ValueError('人工群が未定義')
    sell=buy.copy()
    for name in ('m5_ema21_delta_to_side','m5_di_difference_to_side','m5_hist_delta_to_side','m5_rsi_delta_to_side',
                 'm1_body_ratio_to_side','m5_body_ratio_to_side','m1_body_reclaim_atr5_to_side'):
        sell[:,index[name]]=-np.abs(np.nan_to_num(sell[:,index[name]],nan=0))
    if group=='LC':sell[:,index['m15_hist_delta_to_side']]=np.nan
    meta=[{'session':'人工場','session_index':0,'contract':'人工限月','q0_time':i*60.0,'q0_index':i,'q0_line':i+1} for i in range(n)]
    features=SimpleNamespace(buy_X=buy,sell_X=sell,columns=names,q0_meta=meta)
    return features,np.array([-10800.0])


def take(features: object,end: int) -> object:
    """
    機能: 人工特徴を同じprefixへ切り出す。
    引数: features(object)、end(int)は切出し終端。
    返り値: SimpleNamespaceは入力を変更しないprefix。
    """
    return SimpleNamespace(buy_X=features.buy_X[:end].copy(),sell_X=features.sell_X[:end].copy(),
        columns=list(features.columns),q0_meta=[dict(r) for r in features.q0_meta[:end]])


def main() -> None:
    """
    機能: 六群の成立、売買鏡像、prefix、未来変更、NaN、gap・公表状態を人工確認する。
    引数: なし。
    返り値: None。自然金融なしの確認票と全候補辞書を保存する。
    """
    here=Path(__file__).resolve().parent
    catalog=R.catalog();assert catalog['candidate_count']==576
    checks={};cells=0
    for group in R.GROUPS:
        features,starts=synthetic(group)
        ids=[r['id'] for r in catalog['rules'] if r['group']==group]
        before=features.buy_X.copy()
        result=R.build(features,starts,candidate_ids=ids)
        assert np.array_equal(features.buy_X,before,equal_nan=True)
        assert (result['directions']!=0).any(),group
        swapped=SimpleNamespace(buy_X=features.sell_X.copy(),sell_X=features.buy_X.copy(),columns=features.columns,q0_meta=features.q0_meta)
        mirror=R.build(swapped,starts,candidate_ids=ids)['directions']
        assert np.array_equal(mirror,-result['directions']),group
        for end in (20,36,50):
            prefix=R.build(take(features,end),starts,candidate_ids=ids)['directions']
            assert np.array_equal(prefix,result['directions'][:,:end]),(group,end)
            future=take(features,len(features.q0_meta));future.buy_X[end:]=np.nan;future.sell_X[end:]=np.nan
            altered=R.build(future,starts,candidate_ids=ids)['directions']
            assert np.array_equal(altered[:,:end],result['directions'][:,:end]),(group,'未来変更')
            cells+=prefix.size+altered[:,:end].size
        unknown=take(features,len(features.q0_meta));unknown.buy_X[:]=np.nan;unknown.sell_X[:]=np.nan
        assert not R.build(unknown,starts,candidate_ids=ids)['directions'].any(),group
        if group!='LC':
            gap=take(features,len(features.q0_meta))
            boundary=len(features.q0_meta)//2+1
            for q in gap.q0_meta[boundary:]:q['q0_time']+=300
            reset_result=R.build(gap,starts,candidate_ids=ids)
            assert reset_result['diagnostics']['history_reset'][boundary]
            assert not reset_result['directions'][:,boundary:boundary+4].any(),group
        for logical in {i.removesuffix('_ALL').removesuffix('_EDGE') for i in ids}:
            ai=ids.index(logical+'_ALL');ei=ids.index(logical+'_EDGE')
            assert np.all((result['directions'][ei]==0)|(result['directions'][ei]==result['directions'][ai]))
        checks[group]={'候補数':len(ids),'人工成立方向セル':int(np.count_nonzero(result['directions'])),'鏡像':True,'prefixと未来変更':True,'全未知待機':True,'長gapで旧arm破棄':True}
    # ----------------------------------------
    features,starts=synthetic('LC',80);name=features.columns.index('m15_hist_delta_to_side')
    features.buy_X[20,name]=.1
    for q in features.q0_meta[40:]:q['q0_time']+=300
    result=R.build(features,starts,candidate_ids=['LC0001_ALL'])
    assert result['diagnostics']['local_allowed'][:20].all()
    assert not result['diagnostics']['local_allowed'][20:].any()
    assert result['diagnostics']['history_reset'][40]
    assert not result['directions'][:,20:].any()
    changed=take(features,80)
    for q in changed.q0_meta[50:]:q['contract']='次の人工限月'
    other=R.build(changed,starts,candidate_ids=['LC0001_ALL'])
    assert other['diagnostics']['local_allowed'][50:].all()
    assert other['diagnostics']['history_reset'][50]
    fresh,starts=synthetic('LC',80)
    for q in fresh.q0_meta[40:]:q['q0_time']+=300
    local_ids=[r['id'] for r in catalog['rules'] if r['group']=='LC' and r['confirmation_seconds']==60]
    local_reset=R.build(fresh,starts,candidate_ids=local_ids)
    assert not local_reset['directions'][:,40].any()
    source=here/'rules175.py'
    catalog_path=here/'候補辞書175.json'
    catalog_path.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    proof={'成功':True,'自然特徴と金融未読':True,'群':checks,'照合セル':cells,'局所一度公表後gap再許可なし':True,
        '限月変更reset':True,'SourceSHA256':hashlib.sha256(source.read_bytes()).hexdigest(),
        '候補辞書SHA256':hashlib.sha256(catalog_path.read_bytes()).hexdigest()}
    (here/'人工確認175.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
