"""175の純出生と当時特徴だけから、希少成立の原因を分解する。金融は読まない。"""
from pathlib import Path
import hashlib
import json
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'work/175局面別の純入口'))
sys.path.insert(0,str(ROOT/'work/161三時間帯入口のデータ'))
import rules175 as R
import data161


def sha(path: Path) -> str:
    """
    機能: 読取入力のSHA256を返す。
    引数: path(Path)。
    返り値: strは十六進指紋。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def count(mask: np.ndarray,phases: np.ndarray,scenes: np.ndarray) -> dict:
    """
    機能: 同じq0を重複加算せず三帯の行数と場数を数える。
    引数: mask/phases/scenes(np.ndarray[N])。
    返り値: dictは各帯のq0/場数。
    """
    return {name:{'q0':int(np.count_nonzero(mask&(phases==band))),
        '場数':int(len(np.unique(scenes[mask&(phases==band)])))} for band,name in enumerate(('DAY','PRE','POST'))}


def main() -> None:
    """
    機能: 封印方向を再照合し、未知と有効条件不成立・単条件/二条件の遮断を診断する。
    引数: なし。
    返り値: None。workへJSONを保存するだけでSource・候補・金融を変更しない。
    """
    source=ROOT/'work/175局面別の純入口/rules175.py'
    birth=ROOT/'work/175局面別入口の再探索/純出生175.npz'
    before={'Source':sha(source),'純出生':sha(birth)}
    assert before['Source']=='9588c3233812791d37afb0de9d029bbb3ea379891e81d1e4abf2fde49f3c6dab'
    features=data161.load_feature_dataset()
    phases=features.q0_timeband;scenes=np.asarray([q['session_index'] for q in features.q0_meta])
    starts=np.asarray([s['start'] for s in features.scenes])
    evaluator=R.Evaluator175(features,starts);rules=R.candidate_catalog();n=len(phases)
    matrix=np.load(birth,allow_pickle=False)['directions']
    assert matrix.shape==(576,n)
    group_rows={};all_rules=[]
    for group in R.GROUPS:
        indices=[i for i,r in enumerate(rules) if r['group']==group and r['mode']=='ALL']
        any_pass=np.zeros(n,bool);any_known=np.zeros(n,bool)
        relax={};missing={};availability={};pair_recovery=np.zeros(n,bool)
        counts=[]
        for ri in indices:
            rule=rules[ri];record=evaluator.evaluate_one(rule)
            assert np.array_equal(record['directions'],matrix[ri]),rule['id']
            known_any=(~record['unknown_buy'])|(~record['unknown_sell'])
            any_known|=known_any;any_pass|=record['directions']!=0
            counts.append(count(record['directions']!=0,phases,scenes))
            for side in (0,1):
                conditions=rule['conditions'];pairs=[evaluator.comparison(side,item) for item in conditions]
                truths=[p[0] for p in pairs];knowns=[p[1] for p in pairs]
                prefix=[np.ones(n,bool)]
                for truth in truths:prefix.append(prefix[-1]&truth)
                suffix=[None]*(len(truths)+1);suffix[-1]=np.ones(n,bool)
                for i in range(len(truths)-1,-1,-1):suffix[i]=suffix[i+1]&truths[i]
                for i,item in enumerate(conditions):
                    key=f"{item['factor']} {item['operator']} {item['threshold']}"
                    available=availability.setdefault(item['factor'],np.zeros(n,bool));available|=knowns[i]
                    others=prefix[i]&suffix[i+1]
                    relax.setdefault(key,np.zeros(n,bool))[:] |= others&knowns[i]&~truths[i]
                    missing.setdefault(key,np.zeros(n,bool))[:] |= others&~knowns[i]
                selected=[i for i,item in enumerate(conditions) if
                    (item['factor']=='q0_entry_minus_ema8_atr5_to_side' and item['operator']=='>=') or item['factor']=='live_reclaim']
                if len(selected)==2:
                    others=np.ones(n,bool);removed_known=np.ones(n,bool);removed_pass=np.ones(n,bool)
                    for i in range(len(truths)):
                        if i in selected:removed_known &= knowns[i];removed_pass &= truths[i]
                        else:others &= truths[i]
                    pair_recovery |= others&removed_known&~removed_pass
            all_rules.append({'id':rule['id'],'成立':count(record['directions']!=0,phases,scenes),
                '全条件既知側あり':count(known_any,phases,scenes)})
        # ----------------------------------------
        summary={'成立する候補が一つでもあるq0':count(any_pass,phases,scenes),
            '全条件既知の候補側が一つでもあるq0':count(any_known,phases,scenes),
            '必要未知で候補側が全て無効':count(~any_known,phases,scenes),
            '有効候補側があるが複合条件不成立':count(any_known&~any_pass,phases,scenes),
            '各ALL候補の成立q0範囲':{name:[min(c[name]['q0'] for c in counts),max(c[name]['q0'] for c in counts)] for name in ('DAY','PRE','POST')},
            'entry下限とlive回復だけを共に外す仮想成立':count(pair_recovery&~any_pass,phases,scenes),
            '必要factorの片側以上既知':{key:count(mask,phases,scenes) for key,mask in availability.items()},
            '既知だが単条件だけが遮断':{key:count(mask&~any_pass,phases,scenes) for key,mask in relax.items()},
            '単条件未知だけが遮断':{key:count(mask&~any_pass,phases,scenes) for key,mask in missing.items()}}
        group_rows[group]=summary
        print(json.dumps({'群':group,'成立':summary['成立する候補が一つでもあるq0'],
            '有効だが不成立':summary['有効候補側があるが複合条件不成立']},ensure_ascii=False),flush=True)
    result={'成功':True,'金融結果未読':True,'対象':'旧73場の純特徴と純出生だけ',
        '対象q0':count(np.ones(n,bool),phases,scenes),'群':group_rows,'ALL候補':all_rules,
        '入力':before,'注意':'条件を外す仮想数は非金融funnel。売買条件変更/要求/実取得/損益/閾値採用の根拠ではない。群のq0は候補間重複を除いた和集合。'}
    assert before=={'Source':sha(source),'純出生':sha(birth)}
    target=Path(__file__).resolve().parent/'自然成立の診断.json'
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__':
    main()
