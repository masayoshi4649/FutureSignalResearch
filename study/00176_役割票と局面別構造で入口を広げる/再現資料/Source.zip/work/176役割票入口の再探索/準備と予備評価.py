"""175の計算部品を保ち、176の役割票純入口だけを別条件で検証する。"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import hashlib
import json
import sys
import time
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/175局面別入口の再探索'))
import 基盤175 as BASE
import 予備評価175 as SCREEN
B=BASE.B
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00176_役割票と局面別構造で入口を広げる'


def ref(path: Path) -> dict:
    """
    機能: Source又は固定入力の物理指紋を返す。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def freeze() -> None:
    """
    機能: 175の非金融成立不足から変えた176のSourceと仮説を金融前に固定する。
    引数: なし。
    返り値: None。175の条件・出生・金融は変更しない。
    """
    parent=ROOT/'study/00175_局面別入口を累計経路と支持で探索する/検査/F0a_順位の人工境界補強.json'
    body=B.P.read(parent)
    for key in ('親F0','追補UTC','追補','Source'):body.pop(key,None)
    body.update({'試行':176,'GO':True,'UTC':datetime.now(timezone.utc).isoformat(),'親研究条件':ref(parent),
        '仮説':'175は有効な指標値がある場でも全ANDと同時トリガーで希少。複数技術の役割を維持し、方向/動力の必要票＋代替の価格構造へ変える。',
        '候補':'HT/HB/HR/HM/LC/RLの役割票辞書。ALL/EDGE既適用、入口geometry200は出口幅非依存。全閾値は新辞書へ固定。'})
    paths=[p for folder in ('176局面別の役割票','176役割票入口の再探索') for p in (ROOT/'work'/folder).glob('*.py')]
    paths+=[ROOT/'work/176局面別の役割票/候補辞書176.json',ROOT/'work/175局面別入口の再探索/基盤175.py',
        ROOT/'work/175局面別入口の再探索/予備評価175.py',ROOT/'work/175局面別入口の再探索/数量段階を進める.py',
        ROOT/'work/175経路と支持の評価/path175.py']
    body['Source']=[ref(p) for p in sorted(set(paths))]
    TRIAL.mkdir(parents=True,exist_ok=True);(TRIAL/'検査').mkdir(exist_ok=True)
    target=TRIAL/'条件.json';assert not target.exists();B.P.save(target,body)
    print(json.dumps(ref(target),ensure_ascii=False))


def birth() -> None:
    """
    機能: 176の自然特徴から純出生を作り、金融前に固定する。
    引数: なし。
    返り値: None。旧73だけの純出生NPZを保存する。
    """
    fixed=B.P.read(TRIAL/'条件.json')
    for record in fixed['Source']:assert B.P.sha(ROOT/record['path'])==record['sha256']
    builder=B.P.module(ROOT/'work/176局面別の役割票/rules176.py','birth176_pure')
    data=B.P.R168.BASE.data_module();features=data.load_feature_dataset()
    output=builder.build(features,np.asarray([s['start'] for s in features.scenes]),features.q0_timeband)
    rules=B.P.read(ROOT/'work/176局面別の役割票/候補辞書176.json')['rules']
    assert output['candidate_ids']==[r['id'] for r in rules]
    target=HERE/'純出生176.npz';assert not target.exists()
    np.savez_compressed(target,directions=output['directions'],phases=features.q0_timeband)
    B.P.save(target.with_suffix('.json'),{'成功':True,'金融未入力':True,'F0SHA256':B.P.sha(TRIAL/'条件.json'),
        '出生SHA256':B.P.sha(target),'候補数':len(rules),'q0数':len(features.q0_meta),'特徴':features.sources})
    print(json.dumps({'成功':True,'候補数':len(rules),'出生SHA256':B.P.sha(target)},ensure_ascii=False))


def screen() -> None:
    """
    機能: 175固定の共用計算法で176出生を同じ全幅期限へ予備評価する。
    引数: なし。
    返り値: None。独立一枚の短表でありglobal1採否とは区別する。
    """
    fixed=B.P.read(TRIAL/'条件.json')
    for record in fixed['Source']:assert B.P.sha(ROOT/record['path'])==record['sha256']
    birth_path=HERE/'純出生176.npz';proof=B.P.read(birth_path.with_suffix('.json'))
    assert proof['金融未入力'] and B.P.sha(birth_path)==proof['出生SHA256']
    rules=B.P.read(ROOT/'work/176局面別の役割票/候補辞書176.json')['rules'];context=B.load_context(False)
    with np.load(birth_path,allow_pickle=False) as source:
        matrix=source['directions'];assert np.array_equal(source['phases'],context.event_phases)
    metrics=np.empty((len(rules),2,3,2,len(context.table.widths),len(context.table.horizons),len(SCREEN.FIELDS)))
    begin=time.monotonic()
    for ri,direction in enumerate(matrix):
        cases,sides,phases=SCREEN.physical(direction,context.event_cases,context.event_phases)
        for oi in range(2):metrics[ri,oi]=SCREEN.summarize(context,cases,sides if oi==0 else 1-sides,phases)
        if (ri+1)%96==0:print(json.dumps({'候補':ri+1,'全数':len(rules),'経過秒':round(time.monotonic()-begin,1)},ensure_ascii=False),flush=True)
    target=HERE/'予備統計176.npz';assert not target.exists();np.savez_compressed(target,metrics=metrics)
    selected=SCREEN.select(metrics,rules,list(context.table.widths),list(context.table.horizons))
    B.P.save(HERE/'予備短表176.json',{'成功':True,'選択':selected,'出生SHA256':B.P.sha(birth_path),'予備統計SHA256':B.P.sha(target),'F0SHA256':B.P.sha(TRIAL/'条件.json')})
    B.P.save(HERE/'予備軸176.json',{'指標':SCREEN.FIELDS,'帯':SCREEN.BANDS,'期間':SCREEN.PERIODS,
        '幅':list(context.table.widths),'期限':list(context.table.horizons),'方向':['NORMAL','REVERSE'],'候補順':[r['id'] for r in rules]})
    print(json.dumps({'成功':True,'短表':{p:{b:len(v) for b,v in bs.items()} for p,bs in selected.items()}},ensure_ascii=False))


def main() -> None:
    """
    機能: 176の固定・出生・予備評価を別々の段階として実行する。
    引数: --stage(str)はfreeze/birth/screen。
    返り値: None。段階の重複出力は上書きしない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=('freeze','birth','screen'),required=True)
    args=parser.parse_args();{'freeze':freeze,'birth':birth,'screen':screen}[args.stage]()


if __name__=='__main__':
    main()
