"""探索の正本から比較に必要な短い結果を表示する。"""
from pathlib import Path
import gzip
import json


def main() -> None:
    """
    機能: 固定候補と段階ごとの最大値・適合数を短く表示する。
    引数: なし。
    返り値: None。
    """
    root=Path(__file__).parent
    fixed=json.loads((root/'旧73の固定選択.json').read_text(encoding='utf-8'))['選択']
    for stage in ('単独','六局面','Night接合','三帯接合'):
        rows=json.loads(gzip.decompress((root/(stage+'.json.gz')).read_bytes()))['rows']
        print(stage,len(rows))
        if stage!='三帯接合':continue
        for route,selection in fixed.items():
            print(route,'主案',selection['主案'],'候補',selection['参考候補'])
            for row in rows:
                if row['id'] not in selection['参考候補']:continue
                print(row['id'])
                for period in ('全期','前48','後25'):
                    for band,g in row['periods'][period].items():
                        t=g['trades'];s=g['sessions'];p=row['paths'][period][band]
                        fa=t['IFD_FIRSTFANC'];su=p['support'];pa=p['known_contribution']
                        print(period,band,g['decision']['status'],'件数/未知',t['all_count'],t['unknown_count'],
                              '率',fa['first_f_rate_reached'],'FA',fa['reached_count'],
                              '中央値下限',t['net_median']['lower'],s['net_median']['lower'],
                              '利益/損失/収支',t['known_profit'],t['known_loss'],t['known_net'],
                              '0場',su['zero_scene_count'],'既知DD/最低',pa['max_drawdown_amount'],pa['initial_minimum'])


if __name__=='__main__':
    main()
