"""追加7の数量履歴を独立再構成し、固定4政策の全80財務を独立再集計する。"""

from __future__ import annotations

import copy
import csv
import json
import math
from pathlib import Path
from types import SimpleNamespace

import numpy as np

import 旧73を検査する as Q

HERE = Path(__file__).resolve().parent
ROOT, DESTINATION, TARGET = Q.ROOT, Q.DESTINATION, Q.TARGET
APPLICATION = ROOT / "work/173追加七場適用"


def rebuild_directions(context: object, policies: list) -> dict:
    """
    機能: 封印済み政策だけを純特徴へ適用し、金融なしで出生方向を再構成する。
    引数: context（object）追加7当時特徴、policies（list）固定4政策。
    返り値: dict。birth_key→方向配列。horizon違いの同方向も同体確認する。
    """
    options = {}
    for policy in policies:
        for rules in policy["options"].values():
            for rule in rules:
                options[rule["id"]] = {"key": rule["id"], "source": rule["source"], "rule": rule["rule"],
                                       "width": int(rule["width"]), "horizon": rule["horizon"],
                                       "entry_mode": rule["mode"], "orientation": rule["orientation"]}
    builder = Q.B.P.module(ROOT / "work/172ナイト入口探索/選定政策の出生.py", "birth172_for173_independent80")
    raw = builder.build(context.features, list(options.values()))
    directions = {}
    for policy in policies:
        for rules in policy["options"].values():
            for rule in rules:
                direction = raw[rule["id"]]
                if rule["birth_key"] in directions:
                    assert np.array_equal(directions[rule["birth_key"]], direction)
                directions[rule["birth_key"]] = direction
    return directions


def compare_pure_birth(context: object, policy: dict, composed: tuple, path: Path) -> None:
    """
    機能: 独立OR合成した出生と、金融前封印NPZの各配列を照合する。
    引数: context（object）、policy（dict）、composed（tuple）独立出生、path（Path）封印NPZ。
    返り値: None。不一致ならAssertionError。
    """
    core, technical, tiers, widths, horizons, conflicts = composed
    expected = {"core": core, "branches": np.where(core != 0, 0, -1).astype(np.int8),
                "technical": technical, "tier": tiers, "mw": widths, "fw": widths, "hi": horizons, "conflict": conflicts}
    with np.load(path, allow_pickle=False) as archive:
        assert np.array_equal(context.event_phases, archive["phases"])
        for name, value in expected.items():
            assert np.array_equal(value, archive[policy["id"] + "__" + name]), (policy["id"], name)


def compare_pack(context: object, independent: dict, row: dict) -> None:
    """
    機能: 独立履歴と保存packの全要求・取得・財務ledger・index配列を一致照合する。
    引数: context（object）、independent（dict）独立再生、row（dict）保存packの固定1政策。
    返り値: None。不一致ならAssertionError。
    """
    assert independent["records"] == row["engine"]["records"]
    assert independent["requests"] == row["engine"]["requests"]
    for audit, official in zip(independent["audits"], row["engine"]["audits"], strict=True):
        for name, value in audit.items():
            assert value == (sum(official[name]) if name == "pending_at_scene_end" else official[name]), name
    trades = independent["trades"]
    expected = {"cases": [trade["case"] for trade in trades], "sides": [trade["side"] for trade in trades],
                "events": [trade["event"] for trade in trades], "phases": [trade["phase"] for trade in trades],
                "origins": [trade["origin"] for trade in trades],
                "widths": [list(context.table.widths).index(trade["width"]) for trade in trades],
                "horizons": [trade["horizon"] for trade in trades], "tiers": [trade["tier"] for trade in trades]}
    for name, values in expected.items():
        assert values == row[name], name
    ledger = {"net": [trade["net"] for trade in trades], "known": [trade["known"] for trade in trades],
              "label": [trade["label"] for trade in trades], "scene": [context.sessions[trade["scene"]] for trade in trades]}
    assert ledger == row["ledger"]


def compare_financial(context: object, trades: list, financial: dict) -> tuple:
    """
    機能: 正本metricsを呼ばず、全体・小帯・DAY/NIGHTを独立集計してpack財務へ照合する。
    引数: context（object）全対象場と時間、trades（list）独立財務付取引、financial（dict）保存metrics。
    返り値: tuple。独立集計の群辞書と照合数。
    """
    groups, comparisons = {}, 0
    for band, phase_columns in (("ALL", (0, 1, 2)), ("DAY", (0,)), ("PRE", (1,)), ("POST", (2,)), ("NIGHT", (1, 2))):
        eligible = [scene for scene in range(len(context.sessions)) if context.hours[scene, list(phase_columns)].sum() > 0]
        group = Q.aggregate(context, trades, eligible, band)
        official = financial["all_reference"] if band == "ALL" else financial["session_groups_required"]["NIGHT"] if band == "NIGHT" else financial["phases_diagnostic"][band]
        assert group["trades"] == official["trades"], (band, "trades")
        independent_sessions = copy.deepcopy(group["sessions"])
        for row in independent_sessions["rows"]:
            for key in ("F", "A", "N", "C"):
                row.pop(key)
        official_sessions = copy.deepcopy(official["sessions"])
        for sessions in (independent_sessions, official_sessions):
            sessions["rows"].sort(key=lambda row: row["scene"])
            sessions["zero_acquisition_scenes"].sort()
        assert independent_sessions == official_sessions, (band, "sessions")
        assert group["decision_status"] == official["decision"]["status"], (band, "decision")
        for key in ("eligible_hours", "acquisitions_per_hour"):
            assert (group[key] is official[key]) if group[key] is None or official[key] is None else math.isclose(group[key], official[key], rel_tol=1e-12, abs_tol=1e-9)
        groups[band] = group
        comparisons += 5
    assert financial["session_groups_required"]["DAY"]["trades"] == groups["DAY"]["trades"]
    day_status, night_status = groups["DAY"]["decision_status"], groups["NIGHT"]["decision_status"]
    if day_status == night_status == "適合":
        required = "適合"
    elif "不適合" in (day_status, night_status):
        required = "不適合"
    elif "評価不能" in (day_status, night_status):
        required = "評価不能"
    else:
        required = "保留"
    assert required == financial["required_decision"]["status"]
    return groups, comparisons + 2


def concise(group: dict) -> dict:
    """
    機能: 成果JSONへ必要な利益損失・未知・参加・両中央値だけを残す。
    引数: group（dict）独立集計の1群。
    返り値: dict。短い指標。
    """
    t, s = group["trades"], group["sessions"]
    return {"取得": t["all_count"], "既知": t["known_count"], "未知": t["unknown_count"],
            "利益": t["known_profit"], "損失": t["known_loss"], "既知収支": t["known_net"],
            "対象場": s["eligible_count"], "取得場": s["participating_count"], "未取得場": s["zero_acquisition_scenes"],
            "未知場": s["unknown_count"], "建玉中央値": t["net_median"], "場中央値": s["net_median"],
            "両中央値判定": group["decision_status"], "IFD_FIRSTFANC": t["IFD_FIRSTFANC"],
            "時間当たり取得": group["acquisitions_per_hour"]}


def main() -> None:
    """
    機能: 固定4政策の追加7独立再生と、連結80場の全財務を照合して成功gateを保存する。
    引数: なし。
    返り値: None。既存Source・出生・pack・正本を改変しない。
    """
    old_pack_path = APPLICATION / "旧73の全取得173.json.gz"
    new_pack_path = APPLICATION / "追加7の全取得173.json.gz"
    merged_pack_path = APPLICATION / "全80の両中央値173.json.gz"
    packs = {"旧73": Q.read(old_pack_path), "追加7": Q.read(new_pack_path), "全80": Q.read(merged_pack_path)}
    by_id = {part: {row["id"]: row for row in pack["rows"]} for part, pack in packs.items()}
    assert all(set(rows) == set(Q.IDS) for rows in by_id.values())
    policies = [by_id["旧73"][name]["policy"] for name in Q.IDS]
    assert all(by_id[part][policy["id"]]["policy"] == policy for part in by_id for policy in policies)
    prior = Q.read(DESTINATION / "旧73独立結果.json")
    assert prior["結果"] == "全検査成功" and prior["検査前後Source一致"]
    source_paths = [TARGET / name for name in ("基盤173.py", "構成173.py", "数量候補を選ぶ.py", "段階再生173.py")]
    source_paths += [ROOT / "work/173追加なしの因果再生/engine173.py", ROOT / "work/173追加なしの評価/metrics173.py",
                     ROOT / "work/172ナイト入口探索/選定政策の出生.py"]
    before = [Q.fingerprint(path) for path in source_paths]
    birth_paths = {part: APPLICATION / (part + "の純出生173.npz") for part in ("旧73", "追加7")}
    direct_old, _ = Q.direct_births(policies)
    contexts, results, part_checks = {}, {}, {}
    trade_csv, scene_csv = [], []
    for part, is_new in (("旧73", False), ("追加7", True)):
        context = Q.B.load_context(is_new)
        contexts[part] = context
        assert context.sessions == packs[part]["場順"]
        assert len(context.scenes) == (7 if is_new else 73)
        base, _, _ = Q.B.P.baseline(context)
        descriptors = Q.B.captures(context)
        directions = rebuild_directions(context, policies) if is_new else direct_old
        results[part], part_checks[part] = {}, {}
        for policy in policies:
            composed = Q.independent_compose(context, policy, directions, base)
            compare_pure_birth(context, policy, composed, birth_paths[part])
            independent = Q.independent_replay(context, composed, descriptors)
            compare_pack(context, independent, by_id[part][policy["id"]])
            groups, comparisons = compare_financial(context, independent["trades"], by_id[part][policy["id"]]["financial"])
            results[part][policy["id"]] = independent
            part_checks[part][policy["id"]] = {"財務照合数": comparisons, "要求数": len(independent["requests"]),
                                               "要求SHA256": Q.digest_json(independent["requests"]), "取得SHA256": Q.digest_json(independent["records"]),
                                               "groups": {band: concise(group) for band, group in groups.items()}}
            if is_new:
                trade_csv.extend({"政策": policy["id"], "セッション": context.sessions[trade["scene"]], **trade} for trade in independent["trades"])
            print(json.dumps({"区分": part, "政策": policy["id"], "取得": len(independent["trades"]), "一致": True}, ensure_ascii=True), flush=True)
    merged_context = SimpleNamespace(sessions=contexts["旧73"].sessions + contexts["追加7"].sessions,
                                     hours=np.vstack([contexts["旧73"].hours, contexts["追加7"].hours]))
    assert len(merged_context.sessions) == len(set(merged_context.sessions)) == 80
    checks = []
    for policy in policies:
        name = policy["id"]
        merged_trades = copy.deepcopy(results["旧73"][name]["trades"])
        for trade in results["追加7"][name]["trades"]:
            copied = dict(trade, scene=trade["scene"] + 73)
            merged_trades.append(copied)
        expected_ledger = {"net": [trade["net"] for trade in merged_trades], "known": [trade["known"] for trade in merged_trades],
                           "label": [trade["label"] for trade in merged_trades], "scene": [merged_context.sessions[trade["scene"]] for trade in merged_trades]}
        assert expected_ledger == by_id["全80"][name]["ledger"]
        assert [trade["phase"] for trade in merged_trades] == by_id["全80"][name]["phases"]
        assert [trade["origin"] for trade in merged_trades] == by_id["全80"][name]["origins"]
        groups, comparisons = compare_financial(merged_context, merged_trades, by_id["全80"][name]["financial"])
        assert groups["ALL"]["sessions"]["eligible_count"] == 80
        assert groups["DAY"]["sessions"]["eligible_count"] == groups["NIGHT"]["sessions"]["eligible_count"] == 40
        checks.append({"id": name, "追加7独立再生一致": True, "全80財務一致": True, "枠占有違反": 0,
                       "全80財務照合数": comparisons,
                       "旧73": part_checks["旧73"][name], "追加7": part_checks["追加7"][name],
                       "全80": {band: concise(group) for band, group in groups.items()}})
        for band in ("DAY", "NIGHT"):
            scene_csv.extend({"政策": name, "帯": band, **row} for row in groups[band]["sessions"]["rows"])
    assert before == [Q.fingerprint(path) for path in source_paths]
    result = {"確認日": "2026-11-16", "結果": "全検査成功", "対象": list(Q.IDS), "全場数": 80,
              "検査前後Source一致": True, "自然結果の独立再集計": True,
              "方法": "Rootのreplay/financialを使わず、直接出生・独立OR・単一pending/held状態機械・中央値直接再集計。旧73+追加7を最後に結合。",
              "Source": before, "入力": [Q.fingerprint(path) for path in (old_pack_path, new_pack_path, merged_pack_path, *birth_paths.values(), DESTINATION / "旧73独立結果.json")],
              "policies": checks}
    result_path = DESTINATION / "追加7と全80の独立結果.json"
    result_path.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    for filename, rows in (("追加7独立取引.csv", trade_csv), ("全80独立場別.csv", scene_csv)):
        with (DESTINATION / filename).open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    hash_paths = (Path(__file__), HERE / "旧73を検査する.py", result_path, DESTINATION / "追加7独立取引.csv", DESTINATION / "全80独立場別.csv")
    (DESTINATION / "全80SHA256.json").write_text(json.dumps({path.name: Q.fingerprint(path) for path in hash_paths}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
