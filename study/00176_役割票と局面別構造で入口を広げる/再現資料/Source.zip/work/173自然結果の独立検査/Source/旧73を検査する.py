"""指定4政策だけを独立の一枠状態機械・財務再集計で照合する。固定Sourceを編集しない。"""

from __future__ import annotations

import csv
import gzip
import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
DESTINATION = HERE.parent
TARGET = ROOT / "work/173両中央値と単一建玉"
IDS = ("全期_J016", "全期_J017", "前48_J026", "前48_J027")
sys.path.insert(0, str(TARGET))
import 基盤173 as B


def read(path: Path) -> dict:
    """
    機能: 指定された正本だけをUTF-8で読む。
    引数: path（Path）JSONまたはgzip JSON。
    返り値: dict。読み込んだ資料。
    """
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as handle:
        return json.load(handle)


def fingerprint(path: Path) -> dict:
    """
    機能: 小さいSource・正本・出生の物理指紋を得る。
    引数: path（Path）対象。
    返り値: dict。repo相対path、bytes、sha256。
    """
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": path.stat().st_size, "sha256": digest.hexdigest()}


def digest_json(value: object) -> str:
    """
    機能: 再生の履歴を同じ並びで指紋化する。
    引数: value（object）JSONへ変換可能な履歴。
    返り値: str。UTF-8正規化JSONのSHA256。
    """
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode("utf-8")).hexdigest()


def direct_births(policies: list[dict]) -> tuple:
    """
    機能: 各政策の元出生refから方向を直接抽出し、Root短表NPZと一致を照合する。
    引数: policies（list[dict]）固定4政策。
    返り値: tuple。birth_key→方向配列と参照出生の指紋一覧。
    """
    groups = {}
    for policy in policies:
        for rules in policy["options"].values():
            for rule in rules:
                reference = rule["birth_ref"]
                path = ROOT / reference["path"]
                groups.setdefault(path, {})[rule["birth_key"]] = rule
    directions, refs = {}, []
    for path, rules in groups.items():
        physical = fingerprint(path)
        for rule in rules.values():
            assert physical["bytes"] == rule["birth_ref"]["bytes"] and physical["sha256"] == rule["birth_ref"]["sha256"]
        refs.append(physical)
        with np.load(path, allow_pickle=False) as archive:
            for array_name in {rule.get("birth_array", rule["mode"]) for rule in rules.values()}:
                matrix = archive[array_name]
                for key, rule in rules.items():
                    if rule.get("birth_array", rule["mode"]) != array_name:
                        continue
                    row = matrix[int(rule["rule_index"])].copy()
                    if rule["orientation"] == "REVERSE":
                        row *= -1
                    directions[key] = row
    with np.load(TARGET / "短表の純出生173.npz", allow_pickle=False) as archive:
        for key, value in directions.items():
            assert np.array_equal(value, archive[key]), key
    return directions, refs


def independent_compose(context: object, policy: dict, directions: dict, base: dict) -> tuple:
    """
    機能: 構成173を呼ばず、帯別OR・ID優先・反対待機・旧Tの出生を独立合成する。
    引数: context（object）当時時計、policy（dict）固定政策、directions（dict）元出生、base（dict）固定旧T。
    返り値: tuple。主方向、旧T方向、階層、幅、期限、反対同時mask。
    """
    n = len(context.event_keys)
    core = np.zeros(n, np.int8)
    widths = np.full(n, 200, np.int16)
    horizons = np.full(n, context.table.horizons.index("H60"), np.int8)
    conflicts = np.zeros(n, bool)
    technical = np.zeros(n, np.int8)
    tiers = np.zeros(n, np.int8)
    fallback = policy.get("fallback_by_band", {name: policy.get("fallback", False) for name in ("DAY", "PRE", "POST")})
    for band, name in enumerate(("DAY", "PRE", "POST")):
        rules = sorted(policy["options"].get(name, []), key=lambda rule: rule["id"])
        assert len(rules) <= 2
        rows = np.flatnonzero(context.event_phases == band)
        for row in rows:
            selected = [(rule, int(directions[rule["birth_key"]][row])) for rule in rules
                        if directions[rule["birth_key"]][row] != 0]
            distinct = {side for _, side in selected}
            if len(distinct) > 1:
                conflicts[row] = True
                continue
            if selected:
                rule, side = selected[0]
                core[row] = side
                widths[row] = rule["width"]
                horizons[row] = context.table.horizons.index(rule["horizon"])
            if fallback.get(name, False):
                technical[row] = base["technical"][row]
                tiers[row] = base["tier"][row]
    return core, technical, tiers, widths, horizons, conflicts


def outcome(context: object, event: int, case: int, side: int, width: int, horizon: int, origin: int) -> dict:
    """
    機能: 選択済み取得の費用後財務と、枠解放に使う既知決済時計を直接参照する。
    引数: context（object）、event/case/side/width/horizon/origin（int）固定された取得条件。
    返り値: dict。known、net、label、exit_time。未知net/exitはNoneのまま。
    """
    wi = list(context.table.widths).index(width)
    key = (case, side, wi, horizon)
    known = bool(context.arrays["known"][key])
    label = int(context.arrays["label"][key])
    assert (label == 2) == (not known)
    return {"event": event, "case": case, "side": side, "width": width, "horizon": horizon, "origin": origin,
            "known": known, "net": float(context.arrays["net"][key]) if known else None, "label": label,
            "exit_time": float(context.arrays["exit_time"][key]) if known else None}


def independent_replay(context: object, composed: tuple, descriptors: list) -> dict:
    """
    機能: heapや既存replayを使わず、一つのpending/held状態と当時時計で数量履歴を独立再構成する。
    引数: context（object）、composed（tuple）独立出生、descriptors（list）共有取得/失効時計。
    返り値: dict。records、requests、財務付きtrades、占有intervals、独立audits。
    """
    core, technical, tiers, widths, horizons, _ = composed
    records, requests, trades, intervals, audits = [], [], [], [], []
    for scene, definition in enumerate(context.scenes):
        pending, held, acquired = None, None, False
        seen_cases = set()
        audit = {key: 0 for key in ("accepted_core", "accepted_technical", "filled_core", "filled_technical",
                 "cancelled_core", "cancelled_technical", "skipped_held_core", "skipped_held_technical",
                 "skipped_pending_core", "skipped_pending_technical", "alias_fills_skipped_core",
                 "alias_fills_skipped_technical", "unknown_held_to_end", "peak_global_reserved", "peak_global_held", "peak_global_pending")}

        def advance(now: tuple) -> None:
            """
            機能: 単一予約の成立/失効と単一建玉の解放を、now以前の時計だけで順に処理する。
            引数: now（tuple）現在原行。場末と既知exitは秒末のindex/line無限大。
            返り値: None。未知は場末まで保持する。
            """
            nonlocal pending, held, acquired
            while True:
                if pending is not None and pending["due"] <= now:
                    request = pending
                    pending = None
                    role = "core" if request["origin"] == 0 else "technical"
                    if request["status"] != "filled":
                        audit["cancelled_" + role] += 1
                        intervals.append({"scene": scene, "begin": request["at"], "end": request["due"], "kind": "失効"})
                        continue
                    if request["case"] in seen_cases:
                        audit["alias_fills_skipped_" + role] += 1
                        intervals.append({"scene": scene, "begin": request["at"], "end": request["due"], "kind": "重複取得棄却"})
                        continue
                    seen_cases.add(request["case"])
                    acquired = True
                    record = {key: request[key] for key in ("event", "case", "side", "width", "origin", "tier")}
                    detail = outcome(context, record["event"], record["case"], record["side"], record["width"], request["horizon"], record["origin"])
                    release = detail["exit_time"] if detail["known"] else float(definition["end"])
                    assert math.isfinite(release) and request["due"][0] <= release <= definition["end"]
                    held = {"release": (release, math.inf, math.inf), "record": record}
                    detail.update({"scene": scene, "phase": int(context.event_phases[record["event"]]),
                                   "tier": record["tier"], "request_key": request["at"], "fill_key": request["due"],
                                   "release_time": release})
                    records.append(record)
                    trades.append(detail)
                    intervals.append({"scene": scene, "begin": request["at"], "end": held["release"],
                                      "fill": request["due"], "kind": "既知決済" if detail["known"] else "未知を場末保持"})
                    audit["filled_" + role] += 1
                    audit["unknown_held_to_end"] += int(not detail["known"])
                    audit["peak_global_held"] = 1
                    continue
                if held is not None and held["release"] <= now:
                    held = None
                    continue
                break

        for event in np.flatnonzero(context.event_scenes == scene):
            event = int(event)
            now = tuple(context.event_keys[event])
            advance(now)
            if core[event]:
                side, width, origin, tier, horizon = (0 if core[event] == 1 else 1), int(widths[event]), 0, 0, int(horizons[event])
            elif technical[event] and now[0] >= definition["start"] + 2700 and not acquired:
                side, width, origin, tier, horizon = (0 if technical[event] == 1 else 1), 200, 2, int(tiers[event]), context.table.horizons.index("H60")
            else:
                continue
            reason = "held" if held is not None else "pending" if pending is not None else None
            row = {"event": event, "scene_index": scene, "side": side, "width": width, "origin": origin, "tier": tier,
                   "at": list(now), "held_before": int(held is not None and held["record"]["side"] == side),
                   "pending_before": int(pending is not None and pending["side"] == side),
                   "held_total_before": int(held is not None), "pending_total_before": int(pending is not None),
                   "accepted": reason is None, "skip_reason": reason}
            requests.append(row)
            role = "core" if origin == 0 else "technical"
            if reason is not None:
                audit["skipped_" + reason + "_" + role] += 1
                continue
            capture = descriptors[event]
            due = tuple(capture["fill_key"] if capture["status"] == "filled" else capture["finish_key"])
            assert now <= due
            pending = {**row, "at": now, "case": int(capture["case"]) if capture["status"] == "filled" else -1,
                       "due": due, "status": capture["status"], "horizon": horizon}
            audit["accepted_" + role] += 1
            audit["peak_global_reserved"] = 1
            audit["peak_global_pending"] = 1
        advance((float(definition["end"]), math.inf, math.inf))
        assert held is None
        audit["pending_at_scene_end"] = int(pending is not None)
        audits.append(audit)
    records.sort(key=lambda row: (row["event"], row["origin"]))
    trades.sort(key=lambda row: (row["event"], row["origin"]))
    assert len({row["case"] for row in records}) == len(records)
    previous = {}
    for interval in sorted(intervals, key=lambda row: (row["scene"], row["begin"])):
        assert interval["begin"] >= previous.get(interval["scene"], (-math.inf, -math.inf, -math.inf))
        assert interval["end"] >= interval["begin"]
        previous[interval["scene"]] = interval["end"]
    return {"records": records, "requests": requests, "trades": trades, "intervals": intervals, "audits": audits}


def median(values: list[float]) -> float | None:
    """
    機能: 中央要素の直接参照で偶数件を含む中央値を計算する。
    引数: values（list[float]）値。
    返り値: float | None。空ならNone。
    """
    ordered = sorted(values)
    n = len(ordered)
    return (ordered[(n - 1) // 2] + ordered[n // 2]) / 2 if n else None


def median_statistics(values: list[float], unknown: int) -> dict:
    """
    機能: 未知へ負/正無限大を直接置いて並べ直し、中央値上下限を独立計算する。
    引数: values（list[float]）既知値、unknown（int）未知件数。
    返り値: dict。metricsの中央値契約と同じ項目。
    """
    n = len(values) + unknown
    lower = median(values + [-math.inf] * unknown)
    upper = median(values + [math.inf] * unknown)
    low_unbounded = lower is not None and math.isinf(lower)
    high_unbounded = upper is not None and math.isinf(upper)
    return {"known_count": len(values), "unknown_count": unknown, "all_count": n,
            "known_median": median(values), "all_median": median(values) if n and not unknown else None,
            "all_median_exact": bool(n and not unknown),
            "lower": None if low_unbounded else lower, "upper": None if high_unbounded else upper,
            "lower_unbounded": low_unbounded, "upper_unbounded": high_unbounded,
            "possible_signs": [name for name, possible in (("負", n and lower < 0), ("ゼロ", n and lower <= 0 <= upper), ("正", n and upper > 0)) if possible],
            "strictly_positive_guaranteed": bool(n and lower > 0), "strictly_positive_possible": bool(n and upper > 0)}


def aggregate(context: object, trades: list, eligible: list[int], band: str) -> dict:
    """
    機能: 全対象場を残し、取引と場の財務・先着・中央値を独立再集計する。
    引数: context（object）、trades（list）財務付履歴、eligible（list[int]）対象場、band（str）DAY/PRE/POST/NIGHT。
    返り値: dict。正本へ照合する独立の帯別指標。
    """
    bands = {"ALL": {0, 1, 2}, "DAY": {0}, "PRE": {1}, "POST": {2}, "NIGHT": {1, 2}}[band]
    selected = [trade for trade in trades if trade["scene"] in eligible and trade["phase"] in bands]
    valid = [trade["net"] for trade in selected if trade["known"]]
    unknown = len(selected) - len(valid)
    labels = {letter: sum(trade["label"] == code for trade in selected) for letter, code in (("F", 1), ("A", -1), ("N", 0), ("C", 2))}
    reached = labels["F"] + labels["A"]
    t = {"all_count": len(selected), "known_count": len(valid), "unknown_count": unknown,
         "known_profit": sum(value for value in valid if value > 0), "known_loss": -sum(value for value in valid if value < 0),
         "known_net": sum(valid), "known_positive_count": sum(value > 0 for value in valid),
         "known_negative_count": sum(value < 0 for value in valid), "known_zero_count": sum(value == 0 for value in valid),
         "positive_settlement_rate_known": sum(value > 0 for value in valid) / len(valid) if valid else None,
         "positive_settlement_rate_all_lower": sum(value > 0 for value in valid) / len(selected) if selected else None,
         "positive_settlement_rate_all_upper": (sum(value > 0 for value in valid) + unknown) / len(selected) if selected else None,
         "net_median": median_statistics(valid, unknown),
         "IFD_FIRSTFANC": {**labels, "reached_count": reached, "first_f_rate_reached": labels["F"] / reached if reached else None}}
    rows = []
    for scene in eligible:
        values = [trade for trade in selected if trade["scene"] == scene]
        net = [trade["net"] for trade in values if trade["known"]]
        missing = len(values) - len(net)
        row = {"scene": context.sessions[scene], "all_count": len(values), "known_count": len(net), "unknown_count": missing,
               "known_profit": sum(value for value in net if value > 0), "known_loss": -sum(value for value in net if value < 0),
               "known_net": sum(net), "complete": missing == 0, "all_net": sum(net) if not missing else None,
               "main_count": sum(trade["origin"] == 0 for trade in values), "supplement_count": sum(trade["origin"] == 2 for trade in values)}
        row.update({letter: sum(trade["label"] == code for trade in values) for letter, code in (("F", 1), ("A", -1), ("N", 0), ("C", 2))})
        rows.append(row)
    complete = [row["known_net"] for row in rows if row["complete"]]
    active = sum(row["all_count"] > 0 for row in rows)
    s = {"eligible_count": len(rows), "complete_count": len(complete), "unknown_count": len(rows) - len(complete),
         "participating_count": active, "zero_acquisition_count": len(rows) - active,
         "participation_rate": active / len(rows) if rows else None,
         "zero_acquisition_scenes": [row["scene"] for row in rows if not row["all_count"]],
         "known_contribution_median_all_scenes": median([row["known_net"] for row in rows]),
         "net_median": median_statistics(complete, len(rows) - len(complete)),
         "complete_positive_count": sum(row["complete"] and row["known_net"] > 0 for row in rows),
         "complete_negative_count": sum(row["complete"] and row["known_net"] < 0 for row in rows),
         "complete_zero_count": sum(row["complete"] and row["known_net"] == 0 for row in rows), "rows": rows}
    tm, sm = t["net_median"], s["net_median"]
    if not tm["all_count"] or not sm["all_count"]:
        decision = "評価不能"
    elif tm["strictly_positive_guaranteed"] and sm["strictly_positive_guaranteed"]:
        decision = "適合"
    elif not tm["strictly_positive_possible"] or not sm["strictly_positive_possible"]:
        decision = "不適合"
    else:
        decision = "保留"
    hours = sum(context.hours[scene, phase] for scene in eligible for phase in bands)
    return {"trades": t, "sessions": s, "eligible_hours": float(hours), "acquisitions_per_hour": len(selected) / hours if hours else None,
            "resolved_scene_count": sum(row["F"] + row["A"] > 0 for row in rows),
            "max_resolved_scene_count": max((row["F"] + row["A"] for row in rows), default=0),
            "decision_status": decision}


def compare_group(independent: dict, official: dict) -> int:
    """
    機能: 正本と独立集計の財務・中央値・0場・支持を完全照合する。
    引数: independent（dict）独立指標、official（dict）正本の帯指標。
    返り値: int。照合した大項目数。不一致ならAssertionError。
    """
    count = 0
    for name in ("trades", "sessions", "eligible_hours", "acquisitions_per_hour", "resolved_scene_count", "max_resolved_scene_count"):
        if name in ("eligible_hours", "acquisitions_per_hour") and independent[name] is not None and official[name] is not None:
            assert math.isclose(independent[name], official[name], rel_tol=1e-12, abs_tol=1e-9), (name, independent[name], official[name])
        else:
            assert independent[name] == official[name], (name, independent[name], official[name])
        count += 1
    assert independent["decision_status"] == official["decision"]["status"]
    return count + 1


def run_old73() -> None:
    """
    機能: 旧73指定4政策を独立再生し、既存engine・正本・占有時計・財務へ照合して保存する。
    引数: なし。
    返り値: None。固定Sourceや旧正本は変更しない。
    """
    fixed_path = TARGET / "旧73jointの固定選択.json"
    report_path = TARGET / "三帯接合global1.json.gz"
    fixed = read(fixed_path)
    reports = read(report_path)
    official = {row["id"]: row for row in reports["rows"] if row["id"] in IDS}
    assert set(official) == set(IDS)
    policies = [official[name]["policy"] for name in IDS]
    fixed_policies = {policy["id"]: policy for route in fixed["選択"].values() for policy in route["candidates"]}
    assert set(fixed_policies) == set(IDS)
    assert all(policy == fixed_policies[policy["id"]] for policy in policies)
    source_paths = [TARGET / name for name in ("基盤173.py", "構成173.py", "数量候補を選ぶ.py", "段階再生173.py")]
    source_paths += [ROOT / "work/173追加なしの因果再生/engine173.py", ROOT / "work/173追加なしの評価/metrics173.py"]
    before = [fingerprint(path) for path in source_paths]
    directions, birth_refs = direct_births(policies)
    print(json.dumps({"段階": "context読込", "政策数": 4}, ensure_ascii=True), flush=True)
    context = B.load_context(False)
    assert len(context.scenes) == 73
    base, _, _ = B.P.baseline(context)
    descriptors = B.captures(context)
    checks, trade_csv, scene_csv = [], [], []
    for policy in policies:
        name = policy["id"]
        composed = independent_compose(context, policy, directions, base)
        independent = independent_replay(context, composed, descriptors)
        core, technical, tiers, widths, horizons, conflicts = composed

        def exit_lookup(event: int, case: int, side: int, width: int) -> float | None:
            """
            機能: 既存engineとの照合用に取得後だけ主event期限または旧T60分のexitを返す。
            引数: event/case/side/width（int）取得条件。
            返り値: float | None。既知時計または未知None。
            """
            horizon = int(horizons[event]) if core[event] else context.table.horizons.index("H60")
            return outcome(context, event, case, side, width, horizon, 0 if core[event] else 2)["exit_time"]

        engine = B.engine173.replay(context.event_keys, context.event_scenes,
            np.array([scene["start"] for scene in context.scenes]), np.array([scene["end"] for scene in context.scenes]),
            descriptors, core, np.where(core != 0, 0, -1).astype(np.int8), technical, tiers,
            widths, widths.copy(), 200, exit_lookup, capacity=1)
        assert independent["records"] == engine["records"]
        assert independent["requests"] == engine["requests"]
        for audit, root_audit in zip(independent["audits"], engine["audits"], strict=True):
            for key, value in audit.items():
                expected = sum(root_audit[key]) if key == "pending_at_scene_end" else root_audit[key]
                assert value == expected, (name, key, value, expected)
        assert max((row["peak_global_reserved"] for row in engine["audits"]), default=0) == official[name]["global_reserved_max"]
        assert max((row["peak_global_held"] for row in engine["audits"]), default=0) == official[name]["global_held_max"]
        assert sum(row["skipped_held_core"] + row["skipped_held_technical"] for row in engine["audits"]) == official[name]["rejected_held"]
        assert sum(row["skipped_pending_core"] + row["skipped_pending_technical"] for row in engine["audits"]) == official[name]["rejected_pending"]
        assert int(conflicts.sum()) == official[name]["conflict_q0"]
        periods, comparisons = {}, 0
        for period, indices in (("全期", list(range(73))), ("前48", list(range(48))), ("後25", list(range(48, 73)))):
            periods[period] = {}
            for band in ("DAY", "PRE", "POST", "NIGHT"):
                phase_columns = {"DAY": (0,), "PRE": (1,), "POST": (2,), "NIGHT": (1, 2)}[band]
                eligible = [scene for scene in indices if context.hours[scene, list(phase_columns)].sum() > 0]
                group = aggregate(context, independent["trades"], eligible, band)
                comparisons += compare_group(group, official[name]["periods"][period][band])
                periods[period][band] = {key: value for key, value in group.items() if key != "sessions"}
                periods[period][band]["sessions"] = {key: value for key, value in group["sessions"].items() if key != "rows"}
                if period == "全期" and band in ("DAY", "NIGHT"):
                    scene_csv.extend({"政策": name, "帯": band, **row} for row in group["sessions"]["rows"])
        for row in independent["trades"]:
            trade_csv.append({"政策": name, "セッション": context.sessions[row["scene"]], **row})
        checks.append({"id": name, "独立再生一致": True, "占有重複違反": 0, "予約と保有の最大合計": max(row["peak_global_reserved"] for row in independent["audits"]),
                       "取引数": len(independent["records"]), "要求数": len(independent["requests"]), "財務大項目照合数": comparisons,
                       "要求履歴SHA256": digest_json(independent["requests"]), "取得履歴SHA256": digest_json(independent["records"]), "periods": periods})
        print(json.dumps({"政策": name, "取得": len(independent["records"]), "要求": len(independent["requests"]), "正本一致": True}, ensure_ascii=True), flush=True)
    assert before == [fingerprint(path) for path in source_paths]
    result = {"確認日": "2026-11-16", "結果": "全検査成功", "対象": list(IDS), "全場数": 73,
              "方法": "元出生ref直接照合・独立OR・単一pending/held状態機械・予約区間の非重複・中央値を直接再集計。基盤replay/financialは不使用。",
              "検査前後Source一致": True, "Source": before,
              "入力正本": [fingerprint(fixed_path), fingerprint(report_path), fingerprint(TARGET / "短表の純出生173.npz")],
              "元出生": birth_refs, "policies": checks}
    (DESTINATION / "旧73独立結果.json").write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    for filename, rows in (("旧73独立取引.csv", trade_csv), ("旧73独立場別.csv", scene_csv)):
        with (DESTINATION / filename).open("w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    hashes = {path.name: fingerprint(path) for path in (Path(__file__), DESTINATION / "旧73独立結果.json", DESTINATION / "旧73独立取引.csv", DESTINATION / "旧73独立場別.csv")}
    (DESTINATION / "SHA256.json").write_text(json.dumps(hashes, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    run_old73()
