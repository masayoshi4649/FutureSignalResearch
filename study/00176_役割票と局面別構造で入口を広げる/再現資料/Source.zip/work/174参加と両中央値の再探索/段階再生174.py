"""独立screenの短表をglobal1単独・異技術OR・Night接合へ段階再生する。"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from datetime import datetime, timezone
from itertools import combinations, product
import argparse
import json
import time
import sys
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parents[2]/'work/173両中央値と単一建玉'))
import 基盤173 as B
from 構成173 import compose
sys.path.insert(0, str(Path(__file__).resolve().parent))
from 数量候補を選ぶ import choose

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00174_共同条件を残して単一建玉の入口を広げる'
CTX=BASE=DIRS=CAPTURES=None


def delay_day_fallback(birth: dict, phases: np.ndarray, event_scenes: np.ndarray,
                       event_keys: list, scene_starts: np.ndarray, minutes: int) -> dict:
    """
    機能: Day初参加補完だけを指定経過分まで待ち、主出生とNightを変えない。
    引数: birth(dict)、phases/event_scenes(np.ndarray[N])、event_keys(list[tuple])、
          scene_starts(np.ndarray[S])、minutes(int)は45/90/120/180。
    返り値: dictは補完方向とtierを複写してマスクした出生。元入力を変更しない。
    """
    assert minutes in (45,90,120,180)
    elapsed=np.asarray([key[0] for key in event_keys])-scene_starts[event_scenes]
    blocked=(phases==0)&(elapsed<60*minutes)
    return {**birth,'technical':np.where(blocked,0,birth['technical']).astype(np.int8),
        'tier':np.where(blocked,0,birth['tier']).astype(np.int8)}


def prepare(rows: list) -> None:
    """
    機能: 短表にある純出生だけを元の固定配列から抽出する。
    引数: rows(list[dict])はrule_indexとbirth_keyを持つ純候補。
    返り値: None。重複キーの同体を確認し小型NPZへ保存する。
    """
    groups={}
    for r in rows:
        source=r['source']
        path=ROOT/('work/163入口と任意幅/全出生/出生'+str(r['width'])+'.npz') if source=='OLD1460' else \
            ROOT/'work/172ナイト複合候補/全出生/新768の出生.npz' if source=='NEW768' else \
            ROOT/'work/173局所技術の主入口/全出生/出生173LOCAL.npz'
        assert source in ('OLD1460','NEW768','LOCAL173')
        groups.setdefault(path,[]).append(r)
    output={}
    for path, rules in groups.items():
        with np.load(path,allow_pickle=False) as source:
            modes={'directions'} if rules[0]['source']=='LOCAL173' else {r['mode'] for r in rules}
            matrices={mode:source[mode].copy() for mode in modes}
            for r in rules:
                index=int(r['rule_index'])
                mode='directions' if r['source']=='LOCAL173' else r['mode']
                direction=matrices[mode][index].copy()
                if r['orientation']=='REVERSE':direction*=-1
                key=r['birth_key']
                if key in output:assert np.array_equal(output[key],direction),key
                else:output[key]=direction
    np.savez_compressed(HERE/'短表の純出生173.npz',**output)


def initialize() -> None:
    """
    機能: workerで旧73の共用入力と固定出生を一度だけ読み込む。
    引数: なし。
    返り値: None。追加7場は開かない。
    """
    global CTX,BASE,DIRS,CAPTURES
    CTX=B.load_context();BASE,_,_=B.P.baseline(CTX);CAPTURES=B.captures(CTX)
    with np.load(HERE/'短表の純出生173.npz',allow_pickle=False) as source:
        DIRS={key:source[key].copy() for key in source.files}


def decorate(context: object, value: tuple, metric: dict, rows: np.ndarray) -> dict:
    """
    機能: 全場中央値の各群へ実到達場数と場別F/A/N/Cを追加する。
    引数: context(GenericContext)、value(tuple)、metric(dict)、rows(np.ndarray[bool])。
    返り値: dict[str,dict]はDAY/PRE/POST/NIGHT。既知収支の値は変更しない。
    """
    selected,_,wi,hi,_,_=value
    cases=selected.cases[rows];sides=selected.sides[rows]
    labels=context.arrays['label'][cases,sides,wi[rows],hi[rows]]
    scenes=context.case_scene[cases];phases=selected.phases[rows]
    groups={name:metric['phases_diagnostic'][name] for name in ('DAY','PRE','POST')}
    groups['NIGHT']=metric['session_groups_required']['NIGHT']
    for name,g in groups.items():
        phase_mask=phases>0 if name=='NIGHT' else phases==('DAY','PRE','POST').index(name)
        counts={code:np.bincount(scenes[phase_mask&(labels==code)],minlength=len(context.scenes)) for code in (1,-1,0,2)}
        resolved=counts[1]+counts[-1]
        g['resolved_scene_count']=int((resolved>0).sum())
        g['max_resolved_scene_count']=int(resolved.max())
        for record in g['sessions']['rows']:
            si=context.sessions.index(record['scene'])
            for label,code in (('F',1),('A',-1),('N',0),('C',2)):record[label]=int(counts[code][si])
        g.pop('concentration',None)
        g.pop('origins',None)
    return groups


def evaluate(policy: dict) -> dict:
    """
    機能: 一つの三帯構成をglobal1で再生し、全期・前48・後25の両中央値を残す。
    引数: policy(dict)は純技術optionsと旧補完有無。
    返り値: dictはid/policy/periodsと予約上限の検査。
    """
    birth,mw,fw,hi,component,conflict=compose(CTX.event_phases,policy['options'],DIRS,
        BASE['technical'],BASE['tier'],list(CTX.table.horizons),policy.get('fallback_by_band',policy.get('fallback',False)))
    birth=delay_day_fallback(birth,CTX.event_phases,CTX.event_scenes,CTX.event_keys,
        np.asarray([s['start'] for s in CTX.scenes]),policy.get('day_fallback_after_minutes',45))
    value=B.replay(CTX,birth,mw,fw,hi,policy.get('fallback',False),CAPTURES)
    s=CTX.case_scene[value[0].cases];periods={}
    for name,eligible in [('全期',np.ones(len(CTX.scenes),bool)),('前48',np.arange(len(CTX.scenes))<48),('後25',np.arange(len(CTX.scenes))>=48)]:
        selected=eligible[s]
        metric=B.financial(CTX,value,selected,eligible)
        periods[name]=decorate(CTX,value,metric,selected)
    return {'id':policy['id'],'policy':policy,'periods':periods,
        'global_reserved_max':max(a['peak_global_reserved'] for a in value[-1]['audits']),
        'global_held_max':max(a['peak_global_held'] for a in value[-1]['audits']),
        'rejected_held':sum(a['skipped_held_core']+a['skipped_held_technical'] for a in value[-1]['audits']),
        'rejected_pending':sum(a['skipped_pending_core']+a['skipped_pending_technical'] for a in value[-1]['audits']),
        'conflict_q0':int(conflict.sum())}


def run_stage(name: str, policies: list, workers: int) -> list:
    """
    機能: 固定政策群を旧73だけで並列因果再生し新しい段階正本へ保存する。
    引数: name(str)、policies(list[dict])、workers(int)。
    返り値: list[dict]は評価結果。選択後にSourceが変わっていないことも確認する。
    """
    target=HERE/(name+'.json.gz');assert not target.exists()
    source_paths=[Path(__file__),ROOT/'work/173両中央値と単一建玉/基盤173.py',ROOT/'work/173両中央値と単一建玉/構成173.py',HERE/'数量候補を選ぶ.py',HERE/'数量候補を選ぶ173原版.py',
        ROOT/'work/173追加なしの因果再生/engine173.py',ROOT/'work/173追加なしの評価/metrics173.py',HERE/'短表の純出生173.npz']
    before={p.relative_to(ROOT).as_posix():B.P.sha(p) for p in source_paths}
    B.P.save(TRIAL/'検査'/('F2_'+name+'.json'),{'成功':True,'UTC':datetime.now(timezone.utc).isoformat(),
        'Sourceと入力':before,'政策数':len(policies),'policy':policies,'追加7候補結果未読':True})
    start=time.monotonic();out=[]
    with ProcessPoolExecutor(max_workers=workers,initializer=initialize) as executor:
        for row in executor.map(evaluate,policies,chunksize=4):
            out.append(row)
            if len(out)%40==0:print(json.dumps({'段階':name,'再生数':len(out),'全数':len(policies),'経過秒':round(time.monotonic()-start,1)},ensure_ascii=False),flush=True)
    assert all(B.P.sha(ROOT/p)==d for p,d in before.items())
    B.P.save(target,{'成功':True,'stage':name,'Sourceと入力':before,'rows':out,'経過秒':time.monotonic()-start})
    return out


def singles(short_path: Path, workers: int) -> dict:
    """
    機能: 2選択ルートの各帯短表を単独再生し、期間を混ぜず最大8を次段へ渡す。
    引数: short_path(Path)は173独立screenの固定短表、workers(int)。
    返り値: dictは全期/前48の各帯上位。
    """
    reports=B.P.read(short_path)['選択']
    policies=[];all_rules=[]
    for route in ('全期','前48'):
        for band in ('DAY','PRE','POST'):
            for i,rule in enumerate(reports[route]['短表'][band]):
                all_rules.append(rule)
                policies.append({'id':f'{route}_{band}_S{i:03}','route':route,'band':band,
                    'family':rule['family'],'families':[rule['source']+'_'+rule['family']],
                    'options':{band:[rule]},'fallback':False})
    prepare(all_rules)
    rows=run_stage('単独global1',policies,workers)
    selected={route:{band:choose([r for r in rows if r['policy']['route']==route and r['policy']['band']==band],route,band)
        for band in ('DAY','PRE','POST')} for route in ('全期','前48')}
    B.P.save(HERE/'単独global1の短表.json',{'成功':True,'選択':selected})
    return selected


def or_stage(workers: int) -> dict:
    """
    機能: 単独上位の異技術2規則をID昇順ORで再生し、単独と合わせて帯ごとに選ぶ。
    引数: workers(int)。
    返り値: dictは各帯の単独/OR上位。
    """
    selected=B.P.read(HERE/'単独global1の短表.json')['選択'];policies=[]
    for route,bands in selected.items():
        for band,rows in bands.items():
            for i,(a,b) in enumerate(combinations(rows,2)):
                pa,pb=a['policy'],b['policy']
                if pa['families']==pb['families']:continue
                rules=pa['options'][band]+pb['options'][band]
                policies.append({'id':f'{route}_{band}_OR{i:03}','route':route,'band':band,
                    'families':sorted(set(pa['families']+pb['families'])),'options':{band:rules},'fallback':False})
    day_base=[r['policy'] for route,bands in selected.items() for r in bands['DAY']]
    day_base += [p for p in policies if p['band']=='DAY']
    for base in day_base:
        for delay in (45,90,120,180):
            policy=dict(base);policy['id']=base['id']+f'_T{delay}';policy['fallback']=True
            policy['day_fallback_after_minutes']=delay
            policy['fallback_by_band']={'DAY':True,'PRE':False,'POST':False}
            policies.append(policy)
    added=run_stage('異技術ORglobal1',policies,workers) if policies else []
    rows=B.P.read(HERE/'単独global1.json.gz')['rows']+added
    final={route:{band:choose([r for r in rows if r['policy']['route']==route and r['policy']['band']==band],route,band)
        for band in ('DAY','PRE','POST')} for route in ('全期','前48')}
    B.P.save(HERE/'帯ごとの数量短表.json',{'成功':True,'選択':final})
    return final


def night_stage(workers: int) -> dict:
    """
    機能: PREとPOSTの上位を同じNight一枠で接合し、純主と旧初参加補完を分ける。
    引数: workers(int)。
    返り値: dictはNight上位とDayの候補。
    """
    selected=B.P.read(HERE/'帯ごとの数量短表.json')['選択'];policies=[]
    for route,bands in selected.items():
        pre=bands['PRE'];post=bands['POST']
        for i,(a,b) in enumerate(product(pre,post)):
            options={'PRE':a['policy']['options']['PRE'],'POST':b['policy']['options']['POST']}
            for fallback in (False,True):
                policies.append({'id':f'{route}_N{i:03}'+('_T' if fallback else '_N0'),'route':route,'band':'NIGHT',
                    'families':sorted(set(a['policy']['families']+b['policy']['families'])),'options':options,'fallback':fallback,
                    'fallback_by_band':{'DAY':False,'PRE':fallback,'POST':fallback}})
    rows=run_stage('Night接合global1',policies,workers)
    final={route:{'NIGHT':choose([r for r in rows if r['policy']['route']==route],route,'NIGHT'),
        'DAY':selected[route]['DAY']} for route in ('全期','前48')}
    B.P.save(HERE/'Night接合の短表.json',{'成功':True,'選択':final})
    return final


def joint_stage(workers: int) -> dict:
    """
    機能: DayとNightの上位を接合し、双方の両中央値・先着・参加を判定する。
    引数: workers(int)。
    返り値: dictは全期発見と前48選択の固定少数候補。追加7は開かない。
    """
    selected=B.P.read(HERE/'Night接合の短表.json')['選択'];policies=[]
    for route,bands in selected.items():
        for i,(day,night) in enumerate(product(bands['DAY'],bands['NIGHT'])):
            dp,np_=day['policy'],night['policy']
            options={**dp['options'],**np_['options']}
            dt=bool(dp.get('fallback',False));nt=bool(np_.get('fallback',False))
            policies.append({'id':f'{route}_J{i:03}','route':route,'band':'JOINT',
                'families':sorted(set(dp['families']+np_['families'])),'options':options,'fallback':dt or nt,
                'fallback_by_band':{'DAY':dt,'PRE':nt,'POST':nt},'day_policy':dp['id'],'night_policy':np_['id'],
                'day_fallback_after_minutes':dp.get('day_fallback_after_minutes',45)})
    rows=run_stage('三帯接合global1',policies,workers)
    fixed={}
    for route in ('全期','前48'):
        matching=[r for r in rows if r['policy']['route']==route]
        eligible=[];median_only=[]
        for row in matching:
            groups=row['periods'][route]
            med=all(groups[g]['decision']['status']=='適合' for g in ('DAY','NIGHT'))
            if med:median_only.append(row)
            quality=all((groups[g]['trades']['IFD_FIRSTFANC']['first_f_rate_reached'] or 0)>=.7
                and groups[g]['trades']['all_count']>=24 and groups[g]['trades']['IFD_FIRSTFANC']['reached_count']>=12
                and groups[g]['resolved_scene_count']>=6 and groups[g]['trades']['known_net']>0 for g in ('DAY','NIGHT'))
            if med and quality:eligible.append(row)

        def rank(row: dict) -> tuple:
            """
            機能: 参加優先、最も低い両中央値下限、未知、参考Wilsonで固定順位にする。
            引数: row(dict)は一つの選択期間のjoint統計。
            返り値: tupleは昇順比較キー。
            """
            from 数量候補を選ぶ import wilson
            gs=[row['periods'][route][g] for g in ('DAY','NIGHT')]
            zero=sum(g['sessions']['zero_acquisition_count'] for g in gs)
            sm=min(g['sessions']['net_median']['lower'] if g['sessions']['net_median']['lower'] is not None else -float('inf') for g in gs)
            tm=min(g['trades']['net_median']['lower'] if g['trades']['net_median']['lower'] is not None else -float('inf') for g in gs)
            unknown=sum(g['trades']['unknown_count'] for g in gs)
            w=min(wilson(g['trades']['IFD_FIRSTFANC']['F'],g['trades']['IFD_FIRSTFANC']['A']) for g in gs)
            return (zero,-sm,-tm,unknown,-w,row['id'])

        eligible.sort(key=rank);median_only.sort(key=rank)
        fixed[route]={'主案':eligible[0]['id'] if eligible else None,'両中央値適合数':len(median_only),
            '両中央値と先着支持適合数':len(eligible),'参考候補':[r['id'] for r in (eligible[:2] if eligible else median_only[:2])],
            'candidates':[r['policy'] for r in (eligible[:2] if eligible else median_only[:2])],
            '注意':'中央値を満たしても取引0場/先着支持は別。前48ルートは段階ごと前48だけで選ぶ。'}
    B.P.save(HERE/'旧73jointの固定選択.json',{'成功':True,'選択':fixed,'追加7当該候補結果未読':True})
    return fixed


def main() -> None:
    """
    機能: 指定された数量段階だけを新規出力先へ実行する。
    引数: --stage(str)、--shortlist(Path)、--workers(int)。
    返り値: None。追加7の探索はしない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=('single','or','night','joint'),required=True)
    parser.add_argument('--shortlist',type=Path);parser.add_argument('--workers',type=int,default=4)
    args=parser.parse_args()
    if args.stage=='single':
        assert args.shortlist is not None
        result=singles(args.shortlist.resolve(),args.workers)
    elif args.stage=='or':result=or_stage(args.workers)
    elif args.stage=='night':result=night_stage(args.workers)
    else:result=joint_stage(args.workers)
    if args.stage=='joint':
        small={route:{k:v for k,v in value.items() if k!='candidates'} for route,value in result.items()}
    else:small={route:{band:len(rows) for band,rows in bands.items()} for route,bands in result.items()}
    print(json.dumps({'成功':True,'段階':args.stage,'短表':small},ensure_ascii=False))


if __name__=='__main__':
    main()
