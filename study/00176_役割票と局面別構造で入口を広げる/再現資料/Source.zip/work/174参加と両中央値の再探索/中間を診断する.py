"""固定済み174の各段を、選択期間だけで共同条件と参加へ分解する。"""
from pathlib import Path
import gzip
import json


def main() -> None:
    """
    機能: 実行済み単独/ORのDayについて両中央値・70%・全場参加の件数を示す。
    引数: なし。
    返り値: None。固定結果を読み、条件は変更しない。
    """
    here=Path(__file__).resolve().parent
    rows=[]
    for name in ('単独global1.json.gz','異技術ORglobal1.json.gz'):
        rows.extend(json.loads(gzip.decompress((here/name).read_bytes()))['rows'])
    output={}
    for route in ('全期','前48'):
        selected=[r for r in rows if r['policy']['route']==route and r['policy']['band']=='DAY']
        good=[r for r in selected if r['periods'][route]['DAY']['decision']['status']=='適合'
              and (r['periods'][route]['DAY']['trades']['IFD_FIRSTFANC']['first_f_rate_reached'] or 0)>=.7]
        output[route]={'共同適合':len(good),'全場参加共同適合':sum(r['periods'][route]['DAY']['sessions']['zero_acquisition_count']==0 for r in good),
            '例':[{'id':r['id'],'取得':r['periods'][route]['DAY']['trades']['all_count'],
                'FANC':r['periods'][route]['DAY']['trades']['IFD_FIRSTFANC'],
                '未取得場':r['periods'][route]['DAY']['sessions']['zero_acquisition_count']} for r in good[:3]]}
    print(json.dumps(output,ensure_ascii=False))


if __name__=='__main__':
    main()
