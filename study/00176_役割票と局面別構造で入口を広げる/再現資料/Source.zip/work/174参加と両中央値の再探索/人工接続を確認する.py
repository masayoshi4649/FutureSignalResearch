"""174の選択器接続と補完待機の境界を自然金融なしで確認する。"""
from pathlib import Path
import json
import numpy as np
import 段階再生174 as S


def main() -> None:
    """
    機能: 174専用選択器、待機境界、Night非変更、元入力不変を確認する。
    引数: なし。
    返り値: None。人工票を同じ作業領域へ保存する。
    """
    assert S.choose.__module__ == '数量候補を選ぶ'
    import 数量候補を選ぶ as Q
    assert Q.VERSION == '174共同条件優先1'
    result=Q.artificial()
    for delay in (45,90,120,180):
        start=1000.0;cut=start+60*delay
        keys=[(cut-1,0,1),(cut,1,2),(cut+1,2,3),(start,3,4)]
        phases=np.array([0,0,0,1]);scene=np.array([0,0,0,1])
        born={'core':np.array([1,-1,1,-1],np.int8),'technical':np.ones(4,np.int8),'tier':np.ones(4,np.int8)}
        out=S.delay_day_fallback(born,phases,scene,keys,np.array([start,start]),delay)
        assert out['technical'].tolist()==[0,1,1,1]
        assert out['tier'].tolist()==[0,1,1,1]
        assert np.array_equal(out['core'],born['core'])
        assert born['technical'].tolist()==[1,1,1,1]
    result.update({'174選択器を実接続':True,'待機境界4通り':True,'Nightと主出生非変更':True,'元入力不変':True})
    output=Path(__file__).resolve().parent/'人工接続確認.json'
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':
    main()
