"""173の選択診断を受け、共同条件に適合する候補を次段へ必ず留保する。"""
from collections import Counter
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
from 数量候補を選ぶ173原版 import keys, support, wilson

VERSION = '174共同条件優先1'


def joint_eligible(group: dict) -> bool:
    """
    機能: 一つの群で両中央値と先着70%の共同条件が成立するか判定する。
    引数: group(dict)は一つの選択期間だけのglobal1指標。
    返り値: bool。最低支持は173の通常又は疎支持を用いる。
    """
    fa = group['trades']['IFD_FIRSTFANC']
    return (group['decision']['status'] == '適合' and support(group) > 0
            and fa['reached_count'] > 0 and fa['F'] / fa['reached_count'] >= .7)


def choose(rows: list, period: str, field: str, maximum: int = 16) -> list:
    """
    機能: 共同条件4枠を先に取り、支持・両中央値・参加・疎補完を各3枠残す。
    引数: rows(list[dict])、period/field(str)、maximum(int)は既定16。
    返り値: list[dict]。共同条件枠だけは技術群上限を理由に全滅させない。
    """
    candidates = [(r, r['periods'][period][field]) for r in rows
                  if r['periods'][period][field]['trades']['all_count']]
    result = []; seen = set(); families = Counter()
    perspectives = [('共同条件', 4), ('先着支持', 3), ('両中央値', 3), ('参加', 3), ('疎補完', 3)]
    for perspective, quota in perspectives:
        options = sorted(candidates, key=lambda pair: pair[0]['id'])
        if perspective == '共同条件':
            options = [(r, g) for r, g in options if joint_eligible(g)]
            options.sort(key=lambda pair: (pair[1]['sessions']['participating_count'],
                keys(pair[1])['両中央値'], keys(pair[1])['先着支持']), reverse=True)
        else:
            options.sort(key=lambda pair: keys(pair[1])[perspective], reverse=True)
        taken = 0
        for row, group in options:
            if row['id'] in seen:
                continue
            family = tuple(sorted(row['policy'].get('families', [row['policy'].get('family', '固定対照')])))
            if perspective != '共同条件' and families[family] >= 4:
                continue
            if perspective == '先着支持' and not support(group):
                continue
            if perspective == '疎補完' and support(group) != 1:
                continue
            result.append({'id': row['id'], 'policy': row['policy'], 'selected_by': perspective,
                'period': period, 'field': field, 'support_tier': support(group)})
            seen.add(row['id']); families[family] += 1; taken += 1
            if taken >= quota or len(result) >= maximum:
                break
        if len(result) >= maximum:
            break
    return result


def artificial() -> dict:
    """
    機能: 他観点で低順位の共同適合候補が保持され、他期間値を参照しないことを確認する。
    引数: なし。
    返り値: dictは人工確認票。自然結果を読まない。
    """
    def group(f: int, a: int, median: int) -> dict:
        """
        機能: 支持を持つ人工群を生成する。
        引数: f/a/median(int)は先着数と中央値。
        返り値: dictは純選択入力。
        """
        m = {'lower': median, 'lower_unbounded': False, 'strictly_positive_guaranteed': median > 0}
        return {'trades': {'all_count': f+a, 'unknown_count': 0, 'net_median': m,
            'IFD_FIRSTFANC': {'F': f, 'A': a, 'reached_count': f+a}},
            'sessions': {'participating_count': 12, 'net_median': m},
            'decision': {'status': '適合' if median > 0 else '不適合'},
            'resolved_scene_count': 10, 'max_resolved_scene_count': 3}
    rows = [{'id': f'X{i:02}', 'policy': {'families': [str(i)]},
        'periods': {'前48': {'NIGHT': group(19, 1, -100)}, '全期': {'NIGHT': group(19, 1, 10000)}}}
        for i in range(30)]
    rows.append({'id': 'Z', 'policy': {'families': ['Z']},
        'periods': {'前48': {'NIGHT': group(14, 6, 1)}, '全期': {'NIGHT': group(0, 20, -999)}}})
    first = choose(rows, '前48', 'NIGHT')
    assert first[0]['id'] == 'Z' and first[0]['selected_by'] == '共同条件'
    for row in rows:
        row['periods']['全期'] = {'NIGHT': group(20, 0, 999999)}
    assert first == choose(list(reversed(rows)), '前48', 'NIGHT')
    assert choose([], '前48', 'NIGHT') == [] and len(first) <= 16
    return {'成功': True, '共同適合の保持': True, '他期間非参照': True, '入力順不変': True}


if __name__ == '__main__':
    import json
    print(json.dumps(artificial(), ensure_ascii=False))
