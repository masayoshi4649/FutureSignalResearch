import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {Workbook} from '@oai/artifact-tool';

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'../..');
const input=path.join(here,'CSVの型付き入力.json');
const output=path.join(root,'outputs','00174_追加禁止と両中央値の比較');
const previewOnly=process.argv.includes('--表示だけ');

/**
 * 機能: 内容のSHA256を返す。
 * @param {Buffer|string} value - 指紋化する内容。
 * @returns {string} 十六進SHA256。
 */
function sha(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

/**
 * 機能: 型付き一セルをCSVの引用規則へ変換する。
 * @param {number|string|boolean|null} value - 一セルの値。
 * @returns {string} CSVセル。未知nullは空欄。
 */
function field(value) {
  const s=value===null?'':String(value);
  return /[",\r\n]/.test(s)?'"'+s.replaceAll('"','""')+'"':s;
}

// ----------------------------------------
const bytes=await fs.readFile(input);
const data=JSON.parse(bytes);
assert.equal(data.trial,174);
assert.deepEqual(Object.keys(data.tables),['候補比較','デイ','ナイト_米前','ナイト_米後']);
for (const ref of data.inputs) {
  assert.equal(sha(await fs.readFile(path.resolve(root,ref.path))),ref.sha256);
}
const workbook=Workbook.create();
const owners=[];
for (const [name,t] of Object.entries(data.tables)) {
  const original=[t.headers,...t.rows];
  assert.ok(original.every(r=>r.length===t.headers.length));
  const sheet=workbook.worksheets.add(name);
  const range=sheet.getRangeByIndexes(0,0,original.length,t.headers.length);
  range.values=original;
  sheet.showGridLines=false;
  range.format.font={name:'Arial',size:10};
  range.format.rowHeight=32;
  range.format.verticalAlignment='center';
  sheet.getRangeByIndexes(0,0,1,t.headers.length).format={fill:'#334155',
    font:{name:'Arial',size:10,color:'#FFFFFF',bold:true},wrapText:true,rowHeight:56,horizontalAlignment:'center'};
  for (let j=0;j<t.headers.length;j++) {
    const column=sheet.getRangeByIndexes(0,j,original.length,1);
    column.format.columnWidthPx=j===0?180:j<3?145:name==='候補比較'?110:j===3?200:160;
    if (t.rows.length) {
      const numeric=sheet.getRangeByIndexes(1,j,t.rows.length,1);
      const count=/回数|場数|件数|^主取得$|^補完取得$|^[FANC]$/.test(t.headers[j]);
      numeric.setNumberFormat(t.headers[j].includes('率')?'0.00%':count?'#,##0':'#,##0.0');
    }
  }
  sheet.freezePanes.freezeRows(1);
  owners.push({name,t,original,range});
}
workbook.recalculate();
await fs.mkdir(output,{recursive:true});
const proof={成功:true,試行:174,入力SHA256:sha(bytes),元正本:data.inputs,node:process.version,
  出力器SHA256:sha(await fs.readFile(fileURLToPath(import.meta.url))),表:{}};
for (const {name,t,original,range} of owners) {
  const actual=range.values;
  assert.deepEqual(actual,original);
  assert.ok(range.formulas.flat().every(v=>v===''||v===null||v===undefined));
  const body='\uFEFF'+actual.map(r=>r.map(field).join(',')).join('\r\n')+'\r\n';
  if (previewOnly) assert.equal(await fs.readFile(path.join(output,name+'.csv'),'utf8'),body);
  else await fs.writeFile(path.join(output,name+'.csv'),body,{encoding:'utf8',flag:'wx'});
  const inspected=await workbook.inspect({kind:'table',range:name+'!A1:L6',
    include:'values,formulas',tableMaxRows:6,tableMaxCols:12,maxChars:1200});
  const preview=await workbook.render({sheetName:name,range:'A1:L6',scale:1,format:'png'});
  await fs.writeFile(path.join(here,name+(previewOnly?'_再表示確認.png':'_表示確認.png')),new Uint8Array(await preview.arrayBuffer()),{flag:'wx'});
  proof.表[name]={データ行:t.rows.length,列:t.headers.length,全セル照合:actual.length*t.headers.length,
    SHA256:sha(body),inspect:inspected.ndjson};
}
for (const ref of data.inputs) {
  assert.equal(sha(await fs.readFile(path.resolve(root,ref.path))),ref.sha256);
}
assert.equal(sha(await fs.readFile(input)),sha(bytes));
await fs.writeFile(path.join(here,previewOnly?'CSV表示確認.json':'CSV作成確認.json'),JSON.stringify(proof,null,2)+'\n',{encoding:'utf8',flag:'wx'});
console.log(JSON.stringify({成功:true,表:proof.表}));
