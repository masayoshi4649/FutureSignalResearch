"""174の固定四政策を正式共有入力だけで再現する。"""
from pathlib import Path
from io import BytesIO
import argparse
import gzip
import json
import zipfile
import numpy as np
import 段階再生174 as S

B=S.B
ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00174_共同条件を残して単一建玉の入口を広げる'


def main() -> None:
    """
    機能: 正式Source/小正本/共有入力から全出生・取得・engine・両中央値を照合する。
    引数: --output(Path)は未作成のwork内確認先。
    返り値: None。新探索や未見検証を行わず固定再現の確認票を保存する。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();output=args.output.resolve()
    assert output.is_relative_to(ROOT/'work') and not output.exists()
    helper=B.P.module(ROOT/'work/173両中央値と単一建玉/正式入力で再現する.py','formal173_helper_for174')
    builder=B.P.module(ROOT/'work/172ナイト入口探索/選定政策の出生.py','formal174_builder')
    reference=TRIAL/'再現資料/出生と比較正本.zip';checks=[]
    with zipfile.ZipFile(reference) as archive:
        def read(name: str) -> dict:
            """
            機能: 正式ZIP内のJSONを元byteから復元する。
            引数: name(str)はmember名。
            返り値: dictは小正本。
            """
            body=archive.read(name)
            return json.loads(gzip.decompress(body) if name.endswith('.gz') else body)
        fixed=read('work/174参加と両中央値の再探索/旧73jointの固定選択.json')['選択']
        policies=[p for route in ('全期','前48') for p in fixed[route]['candidates']]
        rules={r['birth_key']:r for p in policies for band in p['options'].values() for r in band}
        assert all(r['source']!='LOCAL173' for r in rules.values())
        options=[{**r,'key':r['birth_key'],'entry_mode':r['mode']} for r in rules.values()]
        for period,context in [('旧73',helper.old_context()),('追加7',B.load_context(True))]:
            base,_,_=B.P.baseline(context);directions=builder.build(context.features,options)
            expected={r['id']:r for r in read(f'work/174追加七場適用/{period}の全取得174.json.gz')['rows']}
            with np.load(BytesIO(archive.read(f'work/174追加七場適用/{period}の純出生174.npz')),allow_pickle=False) as sealed:
                for policy in policies:
                    birth,mw,fw,hi,component,conflict=S.compose(context.event_phases,policy['options'],directions,
                        base['technical'],base['tier'],list(context.table.horizons),policy['fallback_by_band'])
                    birth=S.delay_day_fallback(birth,context.event_phases,context.event_scenes,context.event_keys,
                        np.asarray([s['start'] for s in context.scenes]),policy['day_fallback_after_minutes'])
                    arrays={**{k:birth[k] for k in ('core','branches','technical','tier')},
                        'mw':mw,'fw':fw,'hi':hi,'component':component,'conflict':conflict}
                    for key,value in arrays.items():
                        assert np.array_equal(value,sealed[policy['id']+'__'+key]),(period,policy['id'],key)
                    value=B.replay(context,birth,mw,fw,hi,policy['fallback'])
                    record=expected[policy['id']];packed=helper.packed(context,value)
                    assert packed=={k:record[k] for k in packed},(period,policy['id'],'pack')
                    assert B.financial(context,value)==record['financial'],(period,policy['id'],'financial')
                    checks.append({'期間':period,'id':policy['id'],'取得':len(value[0].cases),'全出生全取得全engine全金融一致':True})
    output.mkdir(parents=True)
    result={'成功':True,'確認':checks,'正式正本SHA256':B.P.sha(reference),
        '注意':'正式148射影と共有163/167で固定四政策を再現。全80既使用、未見性能や実注文成立ではない。'}
    B.P.save(output/'再現確認.json',result);print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':
    main()
