"""173診断に基づく174の次実験を新しい自然選択の前に固定する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00174_共同条件を残して単一建玉の入口を広げる'


def ref(path: Path) -> dict:
    """
    機能: 固定Source又は入力のサイズとSHA256を返す。
    引数: path(Path)。
    返り値: dictはrepo相対path/bytes/sha256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,
        'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 174の操作条件と新SourceをF0 GOとして一度だけ保存する。
    引数: なし。
    返り値: None。173固定結果を変更せず、新自然選択前の指紋を出力する。
    """
    target=TRIAL/'条件.json';assert not target.exists()
    sources=[p for d in ('174参加と両中央値の再探索','174参加と両中央値の選択')
             for p in (ROOT/'work'/d).glob('*.py')]
    inputs=[ROOT/'study/00173_追加建てを禁止し両中央値で入口を再探索する/条件.json',
        ROOT/'work/173選択診断/選択診断.json',ROOT/'work/173予備入口screen/自然結果b/pool.json',
        ROOT/'work/173追加なしの候補計画/短表/短表173.json']
    body={'試行':174,'GO':True,'確認日':'2026-11-16','UTC':datetime.now(timezone.utc).isoformat(),
        '由来':'173の旧73結果を見た後の改善。173は固定、追加7は新選択へ使わない。',
        '継承':'173の費用・全買売一枚+pending一枠・IFD_FIRST・未知None・Day/Night両中央値と参加を継承。',
        'DAY短表':'各route173DAY31包含、支持付きSource/family/向き/実mode層を公平巡回。Wilson/参加/既知net各観点、同論理入口の幅/H派生4まで、最大240。',
        'Night短表':'173のPRE/POST候補と技術を維持。数量段階の短表だけ共同条件を先に留保。',
        '数量選択':'共同条件(両中央値+70%+173支持)4枠、先着支持/両中央値/参加/疎補完各3枠、計最大16。共同条件は技術群上限で全滅させない。',
        'Day補完待機':'旧複合初参加Tの技術条件と200/H60は維持し、開始45/90/120/180経過分を比較。定刻強制発注はしない。NightTは45分固定。',
        '段階':'単独→異技術2規則OR+DayT4通り→PRE×POSTのN0/T→Day×Night。追加の新指標や出生を金融後に変更しない。',
        '最終支持':'DayとNight双方の両中央値下界>0、先着>=70%、取得>=24/到達>=12/到達場>=6/既知net>0。適合群で未取得場最少を先に順位付け。',
        '参考適用':'旧73で全期/前48を独立に選び各最大2案を固定、追加7へ参考適用。旧73も追加7も既使用であり未見とは呼ばない。',
        '新自然選択未実行':True,'Source':[ref(p) for p in sorted(sources)],'入力':[ref(p) for p in inputs]}
    target.write_text(json.dumps(body,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(ref(target),ensure_ascii=False))


if __name__=='__main__':
    main()
