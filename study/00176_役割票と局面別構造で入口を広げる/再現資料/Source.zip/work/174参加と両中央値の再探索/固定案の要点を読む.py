"""174の固定参考案だけの主要指標を表示する。"""
from pathlib import Path
import gzip
import json


def main() -> None:
    """
    機能: 固定4の選択期間/全旧73の率・中央値・参加・待機を抽出する。
    引数: なし。
    返り値: None。条件又は順位は変更しない。
    """
    here=Path(__file__).resolve().parent
    fixed=json.loads((here/'旧73jointの固定選択.json').read_text(encoding='utf-8'))['選択']
    ids={p['id'] for value in fixed.values() for p in value['candidates']}
    rows=json.loads(gzip.decompress((here/'三帯接合global1.json.gz').read_bytes()))['rows']
    out=[]
    for row in rows:
        if row['id'] not in ids:continue
        groups={}
        for band in ('DAY','NIGHT'):
            g=row['periods']['全期'][band];t=g['trades'];s=g['sessions']
            groups[band]={'取得':t['all_count'],'FANC':t['IFD_FIRSTFANC'],'利益':t['known_profit'],'損失':t['known_loss'],
                '既知差引':t['known_net'],'建玉中央値下限':t['net_median']['lower'],'場中央値下限':s['net_median']['lower'],
                '未参加':s['zero_acquisition_count']}
        out.append({'id':row['id'],'待機':row['policy'].get('day_fallback_after_minutes'),'groups':groups})
    print(json.dumps(out,ensure_ascii=False))


if __name__=='__main__':
    main()
