"""173固定対照と174固定案の全80場を、未知を空欄にするCSV用型付き表へまとめる。"""
from pathlib import Path
import hashlib
import gzip
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def read(path: Path) -> dict:
    """
    機能: 圧縮又は通常のUTF-8 JSON正本を読む。
    引数: path(Path)。
    返り値: dictは復元した正本。
    """
    body=path.read_bytes()
    return json.loads(gzip.decompress(body) if path.suffix=='.gz' else body)


def ref(path: Path) -> dict:
    """
    機能: CSV入力となる固定正本の指紋を返す。
    引数: path(Path)。
    返り値: dictは相対path/bytes/sha256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,
        'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 各候補の全対象場を落とさず4表へ整理し、元集計と照合する。
    引数: なし。固定済みの173/174全80正本だけ読む。
    返り値: None。xlsxは作らず、CSV author用JSONを作る。
    """
    paths={173:ROOT/'work/173追加七場適用/全80の両中央値173.json.gz',
           174:ROOT/'work/174追加七場適用/全80の両中央値174.json.gz'}
    tables={'候補比較':{'headers':['候補','選択範囲','区分','対象場数','取得場数','取得回数','主取得','補完取得',
        'F','A','N','C','金融未知件数','先着率','既知利益円','既知損失円','既知収支円','利益損失比',
        '建玉中央値下限円','建玉中央値上限円','場中央値下限円','場中央値上限円','完全場数','両中央値判定','取得毎時','全件確定収支円'], 'rows':[]}}
    session_headers=['候補','選択範囲','セッション日','セッションID','利益円_既知','損失円_既知','収支円_全件確定',
        '収支円_既知分','累計収支円_全件確定','累計収支円_既知分','取得回数','主取得','補完取得','F','A','N','C','金融未知件数','累計金融未知件数','取引なし理由']
    for name in ('デイ','ナイト_米前','ナイト_米後'):
        tables[name]={'headers':session_headers,'rows':[]}
    for trial,path in paths.items():
        data=read(path)
        for row in data['rows']:
            identity=f"{trial}:{row['id']}";route=row['policy']['route'];metric=row['financial']
            groups={**metric['phases_diagnostic'],'NIGHT':metric['session_groups_required']['NIGHT']}
            for band in ('DAY','NIGHT','PRE','POST'):
                g=groups[band];t=g['trades'];s=g['sessions'];fa=t['IFD_FIRSTFANC']
                p,l=t['known_profit'],t['known_loss'];tm=t['net_median'];sm=s['net_median']
                origins=g['origins']
                tables['候補比較']['rows'].append([identity,route,band,s['eligible_count'],s['participating_count'],t['all_count'],
                    origins['主']['acquisition_count'],origins['補完']['acquisition_count'],*[fa[k] for k in ('F','A','N','C')],
                    t['unknown_count'],fa['first_f_rate_reached'],p,l,t['known_net'],p/l if l else None,
                    tm['lower'],tm['upper'],sm['lower'],sm['upper'],s['complete_count'],g['decision']['status'],
                    g['acquisitions_per_hour'],t['known_net'] if not t['unknown_count'] else None])
            for phase,(band,name) in enumerate((('DAY','デイ'),('PRE','ナイト_米前'),('POST','ナイト_米後'))):
                cumulative=0.0;unknown=0
                records=sorted(groups[band]['sessions']['rows'],key=lambda r:r['scene'])
                assert len(records)==40
                for scene in records:
                    key=scene['scene'];cumulative+=scene['known_net'];unknown+=scene['unknown_count']
                    labels=[label for label,s,p in zip(row['ledger']['label'],row['ledger']['scene'],row['phases'],strict=True)
                            if s==key and p==phase]
                    counts=[labels.count(k) for k in (1,-1,0,2)]
                    assert sum(counts)==scene['all_count']
                    reason='' if scene['all_count'] else '当該小帯で取得なし。Night全体の参加は候補比較のNIGHTを参照。' if phase else '技術不成立又は取得代用不成立。監査正本を参照。'
                    tables[name]['rows'].append([identity,route,key.split('_')[0],key,scene['known_profit'],scene['known_loss'],scene['all_net'],
                        scene['known_net'],cumulative if not unknown else None,cumulative,scene['all_count'],scene['main_count'],scene['supplement_count'],
                        *counts,scene['unknown_count'],unknown,reason])
                assert abs(cumulative-groups[band]['trades']['known_net'])<1e-7
    output=HERE/'CSVの型付き入力.json';assert not output.exists()
    output.write_text(json.dumps({'trial':174,'確認日':'2026-11-16','inputs':[ref(p) for p in paths.values()],
        'tables':tables,'定義':'各候補は要求mini1枚、保有/予約を買売合計一件。両中央値必須はDAY/NIGHT、PRE/POSTは診断。C未知は0円に置換せず空欄、利益損失は既知分。'},ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'表':{k:len(v['rows']) for k,v in tables.items()}},ensure_ascii=False))


if __name__=='__main__':
    main()
