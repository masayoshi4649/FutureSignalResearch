"""174のDAYだけを旧73poolから圧縮する。Root F0 GOまでは自然入力へ触れない。"""

from __future__ import annotations

import argparse
import importlib.util
import json
import math
import sys
from pathlib import Path

import numpy as np

from DAY候補を広く選ぶ import DAYを選ぶ


根 = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(根 / "work/173追加なしの候補計画/Source"))
定義 = importlib.util.spec_from_file_location("adapter173_for174", 根 / "work/173追加なしの候補計画/Source/Stage1から短表を作る.py")
adapter = importlib.util.module_from_spec(定義)
sys.modules[定義.name] = adapter
定義.loader.exec_module(adapter)


def F0を確認する(path: Path, sha: str) -> dict:
    """機能: 新しい自然選択に先立ちRootの174 F0 GOと指紋を確認する。

    引数: path (Path) はF0 JSON、sha (str) はRootが固定したSHA256。
    返り値: dictは一致したF0参照。GOなし・別試行・指紋違いは例外。
    """
    ref = adapter.物理指紋(path)
    if ref["sha256"] != sha:
        raise ValueError("174のRoot F0指紋と不一致")
    body = json.loads(path.read_text(encoding="utf-8-sig"))
    if body.get("GO") is not True or body.get("試行", body.get("trial")) != 174:
        raise ValueError("Rootによる174 F0 GOが必要")
    return ref


def DAYrecordを流す(blocks: object, context: dict, lookup: object, resolver: object,
                period: str, audit: dict, progress: object = None):
    """機能: DAY軸だけを最緩filterし、実caseで不足列を補完して流す。

    引数: blocks (Iterable[dict])、context (dict)、lookup (callable)、resolver (出生解決)、
          period (str)、audit (dict)、progress (callable | None)。
    返り値: Iterator[dict]はDAYだけの173互換record。PRE/POSTの新選択はしない。
    """
    for block in blocks:
        axis = block["axis"]
        pi = axis["期間"].index(adapter.期間対応[period])
        bi = axis["帯"].index("DAY")
        fields = list(axis["指標"])
        field = {name: i for i, name in enumerate(fields)}
        values = block["metrics"][..., bi, pi, :]
        mask = adapter.保守的事前フィルター(values, fields, period)
        positions = np.argwhere(mask)
        if len(positions):
            positions = positions[np.lexsort((positions[:, 4], positions[:, 2], positions[:, 0], positions[:, 1], positions[:, 3]))]
        audit[block["source"]] = {"事前filter前": int(mask.size), "事前filter通過": len(positions)}
        if progress:
            progress({"期間": period, "源": block["source"], "DAY": audit[block["source"]]})
        previous = None
        for done, position in enumerate(positions, 1):
            ri, mi, oi, wi, hi = map(int, position)
            width, horizon = int(axis["幅"][wi]), axis["時計"][hi]
            direction, birth_ref, array_name = resolver.方向を読む(block, ri, mi, width)
            physical_key = (birth_ref["path"], ri, mi)
            if previous != physical_key:
                cases, base_sides, phases = adapter.最初の物理取得(direction, context["event_cases"], context["event_phases"])
                previous = physical_key
            sides = base_sides if axis["方向"][oi] == "NORMAL" else 1 - base_sides
            stats = adapter.不足列を集計する(context, lookup, cases, sides, phases, "DAY", period, width, horizon)
            original = values[tuple(position)]
            checks = {"count": "count", "F": "F", "A": "A", "N": "N", "C": "C", "known": "known_financial", "unknown": "unknown_financial",
                "scenes": "filled_scenes", "eligible_scenes": "eligible_scenes", "profit": "profit", "loss": "loss", "net": "net"}
            for before, after in checks.items():
                if not math.isclose(float(original[field[before]]), float(stats[after]), rel_tol=0, abs_tol=1e-7):
                    raise ValueError(f"174 DAY実caseとStage1が不一致: {block['source']}/{ri}/{period}/{before}")
            mode = block["declared_modes"][ri] if block.get("declared_modes") is not None else axis["発火方式"][mi]
            rule = block["ids"][ri]
            key = f"{block['source']}_{rule}_{mode}_{axis['方向'][oi]}_W{width}_{horizon}"
            geometry = width if block["birth"]["layout"] == "width_dependent" else "共通"
            yield {"id": key + "_DAY", "key": key, "source": block["source"], "family": block["families"][ri],
                "birth_key": f"{block['source']}/{rule}/{mode}/{axis['方向'][oi]}/geometry{geometry}",
                "band": "DAY", "rule": rule, "rule_index": ri, "mode": mode, "mode_index": mi,
                "axis_mode": axis["発火方式"][mi], "orientation": axis["方向"][oi], "width": width, "horizon": horizon,
                "position": [ri, mi, oi, wi, hi], "birth_ref": birth_ref, "birth_layout": block["birth"]["layout"],
                "birth_array": array_name, "periods": {period: stats}}
            if progress and done % 10000 == 0:
                progress({"期間": period, "源": block["source"], "DAY実case補完": done, "全数": len(positions)})


def 主処理() -> None:
    """機能: F0 GO後に2ルート各最大240DAYの新短表を保存する。

    引数: CLIの--pool/--controls/--out/--f0-go(Path)、--f0-sha256(str)。
    返り値: None。workの未作成出力先だけへDAY短表174.jsonと監査を保存する。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--pool", type=Path, required=True)
    parser.add_argument("--controls", type=Path, default=根 / "work/173追加なしの候補計画/短表/短表173.json")
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent / "自然選択")
    parser.add_argument("--f0-go", type=Path, required=True)
    parser.add_argument("--f0-sha256", required=True)
    args = parser.parse_args()
    f0 = F0を確認する(args.f0_go.resolve(), args.f0_sha256)
    out = args.out.resolve()
    if 根 / "work" not in out.parents or out.exists():
        raise ValueError("work配下の未作成出力先を指定する")
    controls = json.loads(args.controls.read_text(encoding="utf-8-sig"))["選択"]
    pool = adapter.モジュールを読む(根 / "work/173予備入口screen/pool173.py", "pool173_for174")
    base = adapter.モジュールを読む(根 / "work/172ナイト基礎診断/基礎診断.py", "base172_for174")
    context = base.load(False)
    resolver = adapter.出生解決(根, len(context["event_cases"]))
    selected, audit = {}, {}
    for period in ["全期", "前48"]:
        audit[period] = {}
        stream = DAYrecordを流す(pool.iter_blocks(args.pool.resolve()), context, base.labels, resolver,
            period, audit[period], lambda body: print(json.dumps(body, ensure_ascii=False), flush=True))
        selected[period] = DAYを選ぶ(stream, period, controls[period]["短表"]["DAY"])
    out.mkdir()
    body = {"成功": True, "試行": 174, "選択": selected, "F0": f0,
        "夜間": "173のPRE/POST単独・OR・Night接合保存結果をRoot段階Sourceで再利用。ここでは新選択しない"}
    (out / "DAY短表174.json").write_text(json.dumps(adapter.JSON可能にする(body), ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    proof = {"成功": True, "F0": f0, "事前filter": audit, "173対照": adapter.物理指紋(args.controls),
        "DAY短表件数": {period: len(value["短表"]["DAY"]) for period, value in selected.items()},
        "金融入力": base.INPUTS, "出生参照": resolver.検査済み,
        "性質": "旧73の事後新試行選択。追加7を選択に使わず、global1結果をまだ生成しない"}
    (out / "接続確認174.json").write_text(json.dumps(adapter.JSON可能にする(proof), ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    主処理()
