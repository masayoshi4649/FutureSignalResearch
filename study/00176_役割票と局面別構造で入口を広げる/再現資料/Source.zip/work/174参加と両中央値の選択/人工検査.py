"""174のDAY圧縮を人工値だけで検査する。自然poolの新選択は行わない。"""

from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import sys
import unittest
from pathlib import Path

from DAY候補を広く選ぶ import DAYを選ぶ, 派生単位
from DAY短表へ接続する import DAYrecordを流す, adapter


ここ = Path(__file__).resolve().parent


def 候補(i: int, source: str = "OLD1460", family: str = "人工群", variant: int = 0) -> dict:
    """機能: 幅/期限・向き・modeを持つ人工候補を生成する。

    引数: i (int) は論理規則番号、source/family (str) は層、variant (int) は出口派生。
    返り値: dictは自然値を含まない173互換record。
    """
    stats = {"count": 40, "F": 24 + i % 8, "A": 4, "N": 12 - i % 8, "C": 0,
        "unknown_financial": 0, "eligible_scenes": 37, "filled_scenes": 12 + i % 8,
        "resolved_scenes": 10, "max_resolved_scene_count": 4,
        "filled_scene_ids": [f"人工場{k}" for k in range(12 + i % 8)],
        "trade_median_lower": 100, "trade_median_upper": 100,
        "session_median_lower": 0, "session_median_upper": 0, "net": i * 100 + variant}
    mode = "ALL" if i % 2 == 0 else "EDGE"
    side = "NORMAL" if i % 4 < 2 else "REVERSE"
    return {"id": f"{source}_{family}_{i:04}_{variant:02}", "key": f"人工{i}_{variant}",
        "source": source, "family": family, "rule": f"人工規則{i:04}", "mode": mode,
        "orientation": side, "birth_key": f"人工出生{i}", "band": "DAY", "width": 125 + variant * 25,
        "horizon": "H60", "rule_index": i, "position": [i, 0, 0, variant, 1],
        "periods": {period: copy.deepcopy(stats) for period in ["全期", "前48", "後25"]}}


def 対照化する(row: dict, period: str = "全期") -> dict:
    """機能: 173保存短表と同じstats型の人工対照へ変換する。

    引数: row (dict) は人工record、period (str) は対照の選択期間。
    返り値: dictは入力を変更しない対照行。
    """
    out = {k: copy.deepcopy(v) for k, v in row.items() if k != "periods"}
    out["stats"] = copy.deepcopy(row["periods"][period])
    return out


class 人工確認(unittest.TestCase):
    """期間漏洩・240上限・対照包含・派生4・DAY接続を確認する。"""

    def test_対照包含と240上限と入力順(self) -> None:
        """機能: 旧31を含めて最大240と順序非依存を確認する。

        引数: self (人工確認) は検査インスタンス。
        返り値: None。
        """
        rows = [候補(i, source, f"群{i % 8}", v) for source in ["OLD1460", "NEW768", "LOCAL173"] for i in range(80) for v in range(6)]
        controls = [対照化する(row) for row in rows[:31]]
        first = DAYを選ぶ(rows, "全期", controls)
        second = DAYを選ぶ(reversed(rows), "全期", controls)
        self.assertEqual(first, second)
        self.assertEqual(len(first["短表"]["DAY"]), 240)
        self.assertTrue({r["id"] for r in controls} <= {r["id"] for r in first["短表"]["DAY"]})
        baseline = {r["id"] for r in controls}
        for key in {派生単位(r) for r in first["短表"]["DAY"]}:
            selected = [r for r in first["短表"]["DAY"] if 派生単位(r) == key]
            if len(selected) > 4:
                self.assertTrue(all(r["id"] in baseline for r in selected))

    def test_前48は別期間を読まない(self) -> None:
        """機能: 全期・後25を壊しても前48選択が変わらないことを確認する。

        引数: self (人工確認) は検査インスタンス。
        返り値: None。
        """
        rows = [候補(i) for i in range(300)]
        before = DAYを選ぶ(rows, "前48", [])
        for row in rows:
            row["periods"]["全期"] = {"参照禁止": True}
            row["periods"]["後25"] = {"参照禁止": True}
        self.assertEqual(before, DAYを選ぶ(rows, "前48", []))

    def test_3Sourceと層と疎補完を残す(self) -> None:
        """機能: Sourceと技術群を広く残し、疎補完を通常へ偽装しない。

        引数: self (人工確認) は検査インスタンス。
        返り値: None。
        """
        rows = [候補(i, source, f"群{i % 4}") for source in ["OLD1460", "NEW768", "LOCAL173"] for i in range(40)]
        sparse = 候補(501, "LOCAL173", "疎群")
        for s in sparse["periods"].values():
            s.update({"count": 8, "F": 5, "A": 1, "N": 2, "filled_scenes": 4, "resolved_scenes": 3,
                "filled_scene_ids": [f"疎{i}" for i in range(4)], "max_resolved_scene_count": 2})
        chosen = DAYを選ぶ(rows + [sparse], "全期", [])["短表"]["DAY"]
        self.assertEqual({r["source"] for r in chosen}, {"OLD1460", "NEW768", "LOCAL173"})
        self.assertEqual(next(r for r in chosen if r["id"] == sparse["id"])["support_tier"], "疎補完")

    def test_DAYだけを実caseへ接続する(self) -> None:
        """機能: 人工poolからDAYだけを取り出し12項目とLOCAL添字を検査する。

        引数: self (人工確認) は検査インスタンス。
        返り値: None。
        """
        path = ここ.parents[0] / "173追加なしの候補計画/Source/接続の人工を確認する.py"
        spec = importlib.util.spec_from_file_location("fixture173_for174", path)
        fixture = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = fixture
        spec.loader.exec_module(fixture)
        fixture.人工先 = ここ / "人工入力"
        fixture.人工先.mkdir(exist_ok=True)
        context = fixture.人工contextを作る()
        blocks = [fixture.人工blockを作る(context, s) for s in ["OLD1460", "NEW768", "LOCAL173"]]
        resolver = adapter.出生解決(fixture.人工先, len(context["event_cases"]))
        audit = {}
        records = list(DAYrecordを流す(blocks, context, fixture.金融を参照する, resolver, "全期", audit))
        self.assertTrue(records)
        self.assertEqual({r["band"] for r in records}, {"DAY"})
        self.assertTrue(all(r["periods"]["全期"]["eligible_scenes"] == 8 for r in records))
        self.assertTrue(any(r["source"] == "LOCAL173" and r["axis_mode"] == "DECLARED" for r in records))


if __name__ == "__main__":
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(人工確認)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    proof = {"成功": result.wasSuccessful(), "確認日": "2026-11-16", "人工検査数": result.testsRun,
        "自然poolの新選択": "未実行。人工recordと生成した人工NPZだけ",
        "Source": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in ここ.glob("*.py")}}
    (ここ / "人工確認.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    raise SystemExit(0 if result.wasSuccessful() else 1)
