"""173の事後診断を踏まえた174の純DAY圧縮部品。自然金融やファイルを読まない。"""

from __future__ import annotations

import copy
import hashlib
import json
import sys
from collections import Counter, defaultdict
from pathlib import Path


根 = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(根 / "work/173追加なしの候補計画/Source"))
from 支持と多様性で短表を選ぶ import 支持を判定する, ウィルソン下限


仕様 = {
    "版": "174DAY多様圧縮1",
    "最大候補数": 240,
    "173対照": "各選択ルートの既存DAY31を無条件に包含。新候補の支持不足を救済する規則ではない",
    "支持": "173の通常/疎補完支持を期間ごとにそのまま使用",
    "層": ["source", "family", "orientation", "mode"],
    "観点": ["先着Wilson", "参加", "既知差引"],
    "巡回": "Source別の層を交互に並べ、層番号と周回数で観点をずらす。240又は候補枯渇まで1層1候補ずつ追加",
    "幅期限派生の上限": 4,
    "派生の単位": "source/rule/mode/orientation。同じ論理規則の幅/期限だけで枠を占有させない",
    "上限の例外": "173対照必包含が優先。対照だけで4を超えた単位へ新派生は追加しない",
    "中央値": "独立一枚の両中央値は補助順位だけ。global1の両中央値や先着70%の代用としない",
    "期間": ["全期", "前48"],
    "性質": "旧73の173結果を見た後の新試行案。追加7は選択に使わない",
}


def 派生単位(行: dict) -> tuple:
    """機能: 幅・期限を除いた同じ論理入口の単位を返す。

    引数: 行 (dict) は元添字を持つ純候補。
    返り値: tupleはsource/rule/mode/orientation。
    """
    return tuple(行[項目] for 項目 in ["source", "rule", "mode", "orientation"])


def 層の単位(行: dict) -> tuple:
    """機能: Source・技術群・向き・発火方式の層を返す。

    引数: 行 (dict) は純候補。
    返り値: tupleはsource/family/orientation/mode。
    """
    return tuple(行[項目] for 項目 in 仕様["層"])


def 順位(行: dict, 観点: str) -> tuple:
    """機能: 同じ選択期間だけの代理統計から観点別の降順キーを返す。

    引数: 行 (dict) はstats・支持層を持つ候補、観点 (str) は固定3観点。
    返り値: tuple。既知差引を追加なし口座収支とは扱わない。
    """
    s = 行["stats"]
    tier = 2 if 行["support_tier"] == "通常" else 1
    w = ウィルソン下限(s["F"], s["A"])
    positive = int(s["trade_median_lower"] > 0 and s["session_median_lower"] > 0)
    unknown = -s["unknown_financial"]
    if 観点 == "先着Wilson":
        return (tier, w, s["resolved_scenes"], s["filled_scenes"], positive, unknown, s["net"])
    if 観点 == "参加":
        return (s["filled_scenes"], s["resolved_scenes"], positive, tier, w, unknown, s["net"])
    if 観点 == "既知差引":
        return (s["net"], positive, s["filled_scenes"], tier, w, unknown)
    raise ValueError("未定義の選択観点")


def 層を交互にする(層集合: list[tuple]) -> list[tuple]:
    """機能: Sourceの層数の違いで一つのSourceが先に予算を使い切らない順序を作る。

    引数: 層集合 (list[tuple]) は支持を満たした層。
    返り値: list[tuple]はSourceごとの層を交互に並べた固定順序。
    """
    by_source = defaultdict(list)
    for key in sorted(層集合):
        by_source[key[0]].append(key)
    sources = [s for s in ["OLD1460", "NEW768", "LOCAL173"] if s in by_source]
    sources += sorted(set(by_source) - set(sources))
    out = []
    for i in range(max((len(x) for x in by_source.values()), default=0)):
        for source in sources:
            if i < len(by_source[source]):
                out.append(by_source[source][i])
    return out


def DAYを選ぶ(records: object, 期間: str, 対照: list[dict], 最大数: int = 240) -> dict:
    """機能: 173対照を包含し、支持付きの各層からDAYを最大240候補へ広げる。

    引数: records (Iterable[dict]) は173 adapter互換、期間 (str) は全期/前48、
          対照 (list[dict]) は同ルートの173DAY短表、最大数 (int) は上限。
    返り値: dictは短表.DAYと支持不足・派生上限・層別選択の監査。
    """
    if 期間 not in 仕様["期間"] or not 0 < 最大数 <= 仕様["最大候補数"]:
        raise ValueError("期間又は最大数が仕様の範囲外")
    if len(対照) > 最大数:
        raise ValueError("173対照を包含できない候補上限")
    選択 = []
    seen = set()
    派生数 = Counter()
    for 元 in 対照:
        if 元["band"] != "DAY" or 元["id"] in seen:
            raise ValueError("DAY対照の帯又はIDが不整合")
        行 = copy.deepcopy(元)
        行["selected_by_174"] = "173DAY対照"
        行["selection_period_174"] = 期間
        選択.append(行)
        seen.add(行["id"])
        派生数[派生単位(行)] += 1
    層 = defaultdict(list)
    入力ID = set()
    支持不足 = Counter()
    支持数 = Counter()
    for 元 in records:
        if 元["band"] != "DAY":
            raise ValueError("174の新Stage1選択はDAYだけ")
        if 元["id"] in 入力ID:
            raise ValueError("Stage1候補IDの重複")
        入力ID.add(元["id"])
        s = 元["periods"][期間]
        tier = 支持を判定する(s, 期間)
        if tier is None:
            支持不足[元["source"]] += 1
            continue
        支持数[(元["source"], tier)] += 1
        if 元["id"] in seen:
            continue
        行 = {k: v for k, v in 元.items() if k != "periods"}
        行["stats"] = s
        行["support_tier"] = tier
        層[層の単位(行)].append(行)

    # ----------------------------------------
    順序 = 層を交互にする(list(層))
    並び = {}
    位置 = Counter()
    for key in 順序:
        for view in 仕様["観点"]:
            pool = sorted(層[key], key=lambda r: r["id"])
            pool.sort(key=lambda r: 順位(r, view), reverse=True)
            並び[(key, view)] = pool
    周 = 0
    while len(選択) < 最大数:
        増加 = 0
        for 層番号, key in enumerate(順序):
            view = 仕様["観点"][(層番号 + 周) % len(仕様["観点"])]
            pool = 並び[(key, view)]
            i = 位置[(key, view)]
            while i < len(pool) and (pool[i]["id"] in seen or 派生数[派生単位(pool[i])] >= 仕様["幅期限派生の上限"]):
                i += 1
            位置[(key, view)] = i
            if i == len(pool):
                continue
            行 = dict(pool[i])
            行["selected_by_174"] = view
            行["selection_period_174"] = 期間
            選択.append(行)
            seen.add(行["id"])
            派生数[派生単位(行)] += 1
            位置[(key, view)] += 1
            増加 += 1
            if len(選択) == 最大数:
                break
        周 += 1
        if not 増加:
            break
    仕様本文 = json.dumps(仕様, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return {"選択期間": 期間, "仕様SHA256": hashlib.sha256(仕様本文).hexdigest(),
        "短表": {"DAY": 選択}, "対照数": len(対照), "事前filter後入力数": len(入力ID),
        "支持不足数": dict(支持不足), "支持層件数": {f"{source}/{tier}": n for (source, tier), n in 支持数.items()},
        "支持のある層数": len(順序), "選択Source": dict(Counter(r["source"] for r in 選択)),
        "選択観点": dict(Counter(r["selected_by_174"] for r in 選択)),
        "選択層": {"/".join(key): sum(層の単位(r) == key for r in 選択) for key in 順序},
        "対照由来の派生上限超過": [{"単位": list(k), "対照を含む数": v} for k, v in 派生数.items() if v > 仕様["幅期限派生の上限"]],
        "注意": "173を見た後の174用選択。独立screenの代理値だけ。global1で再生するまで両中央値・70%・参加の達成は未判定"}
