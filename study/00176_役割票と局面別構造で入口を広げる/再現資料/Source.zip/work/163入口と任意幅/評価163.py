"""任意幅・複数期限の大量探索を小さい統計配列で実行する。"""
from pathlib import Path
import sys
import numpy as np
from 共通163 import ROOT,HERE,book,read,sha,module

sys.path.insert(0,str(ROOT/'work/162入口探索'))
from 評価基盤 import Context as PreviousContext

PERIODS=('全期','前48場','後25場')
INTEGRATIONS=('N','U','F')
ENTRY_MODES=('ALL','EDGE')
FIELDS=('count','F','A','N','C','rate','complete_rate','all_rate','profit','loss','net','pf',
    'known','unknown','scenes','all_scenes','per_hour','max_scene_share','new_count','old_count',
    'hold_mean_seconds','wins','loss_trades','realized_win_rate','new_scenes')


class Context163(PreviousContext):
    """旧取得時計と新しい任意幅金融配列を同一caseで結ぶ。"""
    def __init__(self) -> None:
        """
        機能: 旧取得/初参加補完を継承し、数値表だけを指紋確認後に交換する。
        引数: self(Context163)。
        返り値: None。旧表とのcase・実取得時計・場順同体を検査する。
        """
        super().__init__();old_ids=self.table.case_ids;old_arrays=self.arrays
        adapter_path=ROOT/'work/163任意幅の数値化/arrays163.py'
        assert sha(adapter_path)=='0231ea14ce03979a733d1a307c175266ff6aed2492dbc283162de63e153b23e6'
        adapter=module(adapter_path,'arrays163_engine')
        directory=ROOT/'work/163任意幅の数値化/自然数値表'
        proof=read(directory/'完了.json');assert proof['成功']
        self.table=adapter.load_table(directory,proof['cache']);self.arrays=self.table.root_arrays()
        assert self.table.case_ids==old_ids and list(self.table.session_order)==self.sessions
        for name in ('entry_time','entry_index','entry_line','session_index'):
            assert np.array_equal(self.arrays[name],old_arrays[name])
        self.setting163=book()
        assert list(self.table.widths)==self.setting163['widths']
        assert list(self.table.horizons)==[h['id'] for h in self.setting163['horizons']]
        self.array_sources={'adapter_sha256':sha(adapter_path),'cache':proof['cache']}


def divide(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """
    機能: 分母0の率を未定義NaNで保持する。
    引数: a/b(np.ndarray)は分子/分母。
    返り値: np.ndarray[float64]は比率。
    """
    return np.divide(a,b,out=np.full(np.broadcast_shapes(np.shape(a),np.shape(b)),np.nan),where=np.asarray(b)!=0)


def summary_cube(context: Context163, selected: object, widths: int|np.ndarray) -> np.ndarray:
    """
    機能: 同一取得集合の四期限×三期間×全指標を一度に計算する。
    引数: context(Context163)、selected(Selection)、widths(int又はnp.ndarray[int])は固定幅又は取得ごとの幅添字。
    返り値: np.ndarray[float64,H,3,len(FIELDS)]。未定義の率/時間はNaN。
    """
    arrays=context.arrays;nh=len(context.table.horizons)
    cases,sides=selected.cases,selected.sides
    assert np.isscalar(widths) or np.shape(widths)==np.shape(cases)
    labels=arrays['label'][cases,sides,widths,:]
    known=arrays['known'][cases,sides,widths,:]
    money=arrays['net'][cases,sides,widths,:]
    exits=arrays['exit_time'][cases,sides,widths,:]
    scenes=context.case_scene[cases];result=np.full((nh,3,len(FIELDS)),np.nan)
    for pi,period in enumerate(PERIODS):
        eligible=np.ones(73,dtype=bool)
        if period=='前48場':eligible[48:]=False
        if period=='後25場':eligible[:48]=False
        rows=eligible[scenes];n=int(rows.sum());selected_scenes=scenes[rows]
        counts=np.bincount(selected_scenes,minlength=73)
        old=selected.old[rows]
        l=labels[rows];k=known[rows];m=money[rows]
        f=(l==1).sum(axis=0);a=(l==-1).sum(axis=0);und=(l==0).sum(axis=0);c=(l==2).sum(axis=0)
        profit=np.where(k,np.maximum(m,0),0).sum(axis=0)
        loss=np.where(k,np.maximum(-m,0),0).sum(axis=0)
        known_count=k.sum(axis=0);wins=(k&(m>0)).sum(axis=0);loss_trades=(k&(m<0)).sum(axis=0)
        duration=exits[rows]-arrays['entry_time'][cases[rows],None]
        hold_mean=divide(np.where(k,duration,0).sum(axis=0),known_count)
        hours=float(context.hours[eligible].sum())
        values={'count':n,'F':f,'A':a,'N':und,'C':c,'rate':divide(f,f+a),
            'complete_rate':divide(f,f+a+und),'all_rate':divide(f,np.full(nh,n)),
            'profit':profit,'loss':loss,'net':profit-loss,'pf':divide(profit,loss),
            'known':known_count,'unknown':n-known_count,'scenes':np.count_nonzero(counts),
            'all_scenes':float(np.all(counts[eligible]>0)),
            'per_hour':n/hours,'max_scene_share':counts.max()/n if n else np.nan,
            'new_count':int((~old).sum()),'old_count':int(old.sum()),'hold_mean_seconds':hold_mean,
            'wins':wins,'loss_trades':loss_trades,'realized_win_rate':divide(wins,known_count),
            'new_scenes':len(np.unique(selected_scenes[~old]))}
        for j,name in enumerate(FIELDS):result[:,pi,j]=values[name]
    return result


def materialize(values: np.ndarray) -> dict:
    """
    機能: 統計配列のNaNをJSONのnullへ写し、既知値を通常数値へする。
    引数: values(np.ndarray)は一政策の三期間×指標。
    返り値: dictは各期間の統計辞書。
    """
    return {period:{name:float(v) if np.isfinite(v) else None for name,v in zip(FIELDS,row,strict=True)}
        for period,row in zip(PERIODS,values,strict=True)}


def link_variable(context: Context163, directions: np.ndarray, event_widths: np.ndarray) -> tuple:
    """
    機能: 適応幅の出生を通常取得へ結び、最初q0の幅を取得後まで固定する。
    引数: context(Context163)、directions(np.ndarray[int8])、event_widths(np.ndarray[int])は全q0幅添字。
    返り値: tupleはN/U/FのSelectionと各実取得の幅添字写像。
    """
    new=context.link(directions);result={};fallback=context.table.widths.index(200)
    for name in INTEGRATIONS:
        selected=context.integrate(new,name)
        widths=np.full(len(selected.cases),fallback,dtype=np.int8)
        rows=selected.events>=0
        widths[rows]=event_widths[selected.events[rows]]
        assert np.all(widths>=0)
        result[name]=(selected,widths)
    return result
