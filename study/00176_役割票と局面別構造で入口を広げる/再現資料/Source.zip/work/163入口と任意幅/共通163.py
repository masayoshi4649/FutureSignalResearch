"""163の固定条件・共有Source・保存を束縛する。"""
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/162入口探索'))
from 共通 import sha,read,save,module,data_module

HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00163_履歴を含む複合入口を任意幅と場末まで検証する'
BOOK_SHA='a4e5a3ad0417b5790a7f17e768327648e27790d25867092e5e60944ed2863b10'


def book() -> dict:
    """
    機能: 新規163条件と観測・候補Sourceの固定指紋を確認する。
    引数: なし。
    返り値: dictは163条件。
    """
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    setting=read(TRIAL/'条件.json')
    for ref in setting['candidate_sources'].values():
        assert sha(ROOT/ref['path'])==ref['sha256']
    assert sha(ROOT/setting['raw_source_stop']['path'])==setting['raw_source_stop']['sha256']
    return setting


def libraries() -> tuple:
    """
    機能: 初版と履歴版を非改変で読み込み規則順を固定する。
    引数: なし。
    返り値: tupleは静的module、履歴module、全1460辞書。
    """
    setting=book();folder=ROOT/'work/162複合入口候補'
    sys.path.insert(0,str(folder))
    static=module(folder/'rules162.py','rules162')
    history=module(folder/'rules162_stateful.py','rules163_history')
    registry=static.candidate_catalog()+history.candidate_catalog()
    assert len(registry)==setting['candidate_count']==len({r['id'] for r in registry})
    return static,history,registry
