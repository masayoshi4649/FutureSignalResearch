"""固定174の旧73だけを同体再生し、役割・前後・集中を加法分解する。選択は変えない。"""

from __future__ import annotations

import copy
import gzip
import hashlib
import importlib.util
import json
import re
import sys
from pathlib import Path

import numpy as np


根 = Path(__file__).resolve().parents[2]
入力先 = 根 / "work/174参加と両中央値の再探索"
出力先 = Path(__file__).resolve().parent


def 読む(path: Path) -> dict:
    """機能: 固定JSON/gzip JSONを読み込む。

    引数: path (Path) は旧73の保存資料。
    返り値: dictは解析内容。追加7資料は指定しない。
    """
    body = path.read_bytes()
    return json.loads(gzip.decompress(body) if path.suffix == ".gz" else body)


def 要約する(g: dict) -> dict:
    """機能: 両中央値・先着率・決済正率・未知を別項目で写す。

    引数: g (dict) は保存済みmetricsの一群。
    返り値: dictは小型の群別成績。
    """
    t, s = g["trades"], g["sessions"]
    return {"取得": t["all_count"], "FANC": t["IFD_FIRSTFANC"], "既知利益": t["known_profit"],
        "既知損失": t["known_loss"], "既知差引": t["known_net"], "未知": t["unknown_count"],
        "建玉中央値": t["net_median"], "場中央値": s["net_median"], "両中央値判定": g["decision"],
        "決済正率_既知": t["positive_settlement_rate_known"],
        "決済正率_全件下界": t["positive_settlement_rate_all_lower"], "決済正率_全件上界": t["positive_settlement_rate_all_upper"],
        "対象場": s["eligible_count"], "取引0場": s["zero_acquisition_count"], "取引0場名": s["zero_acquisition_scenes"],
        "到達場": g["resolved_scene_count"], "最大一場到達": g["max_resolved_scene_count"],
        "全時間": g["eligible_hours"], "取得毎時": g["acquisitions_per_hour"]}


def 役割を集計する(mask: np.ndarray, labels: np.ndarray, known: np.ndarray, net: np.ndarray, scenes: np.ndarray) -> dict:
    """機能: 保存された口座内の主/T/枝を加法分解する。

    引数: mask/labels/known/net/scenes (np.ndarray) は同じ取得台帳の選択と金融。
    返り値: dict。役割を除いた新政策の再生収支ではない。
    """
    ls, k, money = labels[mask], known[mask], net[mask]
    F, A, N, C = [int((ls == code).sum()) for code in [1, -1, 0, 2]]
    n = int(mask.sum())
    wins = int((money[k] > 0).sum())
    return {"取得": n, "F": F, "A": A, "N": N, "C": C, "到達率": F / (F + A) if F + A else None,
        "取得場": len(set(scenes[mask].tolist())), "既知": int(k.sum()), "未知": int((~k).sum()),
        "既知利益": float(np.maximum(money[k], 0).sum()), "既知損失": float(np.maximum(-money[k], 0).sum()),
        "既知差引": float(money[k].sum()), "全件差引": float(money[k].sum()) if k.all() else None,
        "既知正決済数": wins, "決済正率_既知": wins / int(k.sum()) if k.any() else None,
        "決済正率_全件下界": wins / n if n else None, "決済正率_全件上界": (wins + int((~k).sum())) / n if n else None}


def 集中を集計する(rows: list[dict]) -> dict:
    """機能: 全場を保持して利益・到達・取得の集中を事後診断する。

    引数: rows (list[dict]) は0取得場と未知を含む保存場別統計。
    返り値: dictは上位場寄与と除外後の記述感応度。
    """
    total_profit = sum(r["known_profit"] for r in rows)
    total_net = sum(r["known_net"] for r in rows)
    total_fa = sum(r["F"] + r["A"] for r in rows)
    reached = [r for r in rows if r["F"] + r["A"]]
    out = {"到達場": len(reached), "無到達場": len(rows) - len(reached),
        "到達場等重み先着率": float(np.mean([r["F"] / (r["F"] + r["A"]) for r in reached])) if reached else None,
        "完全既知黒字場": sum(r["complete"] and r["known_net"] > 0 for r in rows),
        "未知を含む場": sum(not r["complete"] for r in rows), "上位利益": [], "上位到達": []}
    for 名前, key in [("上位利益", lambda r: r["known_profit"]), ("上位到達", lambda r: r["F"] + r["A"])]:
        ordered = sorted(rows, key=lambda r: (-key(r), r["scene"]))
        for top in [1, 3, 5, 10]:
            first, rest = ordered[:top], ordered[top:]
            F, A = sum(r["F"] for r in rest), sum(r["A"] for r in rest)
            out[名前].append({"上位数": top, "場": [r["scene"] for r in first],
                "利益寄与": sum(r["known_profit"] for r in first) / total_profit if total_profit else None,
                "既知差引寄与": sum(r["known_net"] for r in first) / total_net if total_net else None,
                "到達寄与": sum(r["F"] + r["A"] for r in first) / total_fa if total_fa else None,
                "除外後既知差引": sum(r["known_net"] for r in rest), "除外後F": F, "除外後A": A,
                "除外後率": F / (F + A) if F + A else None,
                "除外後金融未知": sum(r["unknown_count"] for r in rest)})
    return out


def 主処理() -> None:
    """機能: 固定4を同体確認し、旧73診断と選択された全技術条件を保存する。

    引数: なし。
    返り値: None。work/174結果診断だけを更新し、追加7を読まない。
    """
    stage = 読む(入力先 / "三帯接合global1.json.gz")
    fixed = 読む(入力先 / "旧73jointの固定選択.json")["選択"]
    chosen_ids = {p["id"] for v in fixed.values() for p in v["candidates"]}
    chosen = [r for r in stage["rows"] if r["id"] in chosen_ids]
    old_short = 読む(根 / "work/173追加なしの候補計画/短表/短表173.json")["選択"]
    before = {p: hashlib.sha256((根 / p).read_bytes()).hexdigest() for p in stage["Sourceと入力"]}
    assert before == stage["Sourceと入力"]
    sys.path.insert(0, str(入力先))
    spec = importlib.util.spec_from_file_location("runner174_for_diagnosis", 入力先 / "段階再生174.py")
    runner = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = runner
    spec.loader.exec_module(runner)
    runner.initialize()
    ctx = runner.CTX
    assert len(ctx.scenes) == 73
    output, signatures = {}, {}
    for row in chosen:
        p = row["policy"]
        birth, mw, fw, hi, component, conflict = runner.compose(ctx.event_phases, p["options"], runner.DIRS,
            runner.BASE["technical"], runner.BASE["tier"], list(ctx.table.horizons), p.get("fallback_by_band", p.get("fallback", False)))
        birth = runner.delay_day_fallback(birth, ctx.event_phases, ctx.event_scenes, ctx.event_keys,
            np.asarray([s["start"] for s in ctx.scenes]), p.get("day_fallback_after_minutes", 45))
        value = runner.B.replay(ctx, birth, mw, fw, hi, p.get("fallback", False), runner.CAPTURES)
        selected, origin, ws, hs, tiers, engine = value
        cases, sides, phases = selected.cases, selected.sides, selected.phases
        scene = ctx.case_scene[cases]
        labels, known, net = [ctx.arrays[k][cases, sides, ws, hs] for k in ["label", "known", "net"]]
        parts = {}
        for period in ["全期", "前48", "後25"]:
            eligible = np.ones(len(ctx.scenes), bool) if period == "全期" else np.arange(len(ctx.scenes)) < 48 if period == "前48" else np.arange(len(ctx.scenes)) >= 48
            actual_metric = runner.B.financial(ctx, value, eligible[scene], eligible)
            saved = row["periods"][period]
            parts[period] = {}
            for band, phase_mask in [("DAY", phases == 0), ("NIGHT", phases > 0), ("PRE", phases == 1), ("POST", phases == 2)]:
                g = saved[band]
                actual = actual_metric["session_groups_required"][band] if band in ["DAY", "NIGHT"] else actual_metric["phases_diagnostic"][band]
                assert actual["trades"] == g["trades"], (row["id"], period, band)
                assert actual["sessions"] == {k: v for k, v in g["sessions"].items() if k != "rows"} | {"rows": [{k: v for k, v in r.items() if k not in ["F", "A", "N", "C"]} for r in g["sessions"]["rows"]]}, (row["id"], period, band, "場")
                mask = eligible[scene] & phase_mask
                roles = {"主": 役割を集計する(mask & (origin == 0), labels, known, net, scene),
                         "T": 役割を集計する(mask & (origin == 2), labels, known, net, scene)}
                assert sum(v["取得"] for v in roles.values()) == g["trades"]["all_count"]
                assert sum(v["既知差引"] for v in roles.values()) == g["trades"]["known_net"]
                parts[period][band] = {"全体": 要約する(g), "役割": roles,
                    "集中": 集中を集計する(g["sessions"]["rows"])}
        raw_signature = [[int(e), int(c), int(s), int(w), int(l), bool(k), float(m) if k else None]
            for e, c, s, w, l, k, m in zip(selected.events, cases, sides, ws, labels, known, net)]
        signatures[row["id"]] = hashlib.sha256(json.dumps(raw_signature, separators=(",", ":")).encode()).hexdigest()
        output[row["id"]] = {"policy": {k: v for k, v in p.items() if k != "options"}, "技術": p["options"],
            "旧173DAY31からの追加": [r["id"] for r in p["options"]["DAY"] if r["id"] not in {o["id"] for o in old_short[p["route"]]["短表"]["DAY"]}],
            "期間": parts, "最大予約": row["global_reserved_max"], "最大保有": row["global_held_max"],
            "保有中棄却": row["rejected_held"], "未決中棄却": row["rejected_pending"], "逆同時q0": row["conflict_q0"],
            "旧73の取得金融同体署名": signatures[row["id"]]}
    catalog_files = [根 / "work/162複合入口候補/候補辞書.json", 根 / "work/172ナイト複合候補/候補辞書.json"]
    wanted = {(r["source"], r["rule"]) for v in output.values() for rules in v["技術"].values() for r in rules}
    catalog = []
    for path in catalog_files:
        source = "NEW768" if "172" in str(path) else "OLD1460"
        d = 読む(path)
        for rule in d["rules"]:
            if (source, rule["id"]) in wanted:
                catalog.append({"source": source, "catalog_path": path.relative_to(根).as_posix(),
                    "catalog_SHA256": hashlib.sha256(path.read_bytes()).hexdigest(), "rule": rule})
    assert len(catalog) == len(wanted)
    or_rows = 読む(入力先 / "異技術ORglobal1.json.gz")["rows"]
    waits = {}
    for row in chosen:
        base_id = re.sub(r"_T\d+$", "", row["policy"]["day_policy"])
        waits[row["id"]] = [{"id": r["id"], "待機分": r["policy"].get("day_fallback_after_minutes"),
            "期間": {period: 要約する(r["periods"][period]["DAY"]) for period in ["全期", "前48", "後25"]}}
            for r in or_rows if r["id"] == base_id or re.sub(r"_T\d+$", "", r["id"]) == base_id]
    after = {p: hashlib.sha256((根 / p).read_bytes()).hexdigest() for p in before}
    assert before == after
    result = {"確認日": "2026-11-16", "対象": "固定174四案の旧73のみ。追加7未参照。選択変更なし",
        "固定": output, "待機の既存比較": waits, "署名": signatures, "凍結Source入力の前後同体": True,
        "Source入力SHA256": before, "選択時の共同支持数": {route: v["両中央値と先着支持適合数"] for route, v in fixed.items()},
        "限界": "主/Tは既存口座台帳の加法分解。役割を外す新政策の再生収支ではない。両中央値の正は未知を任意値とした下界で判定"}
    (出力先 / "固定四案の診断.json").write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    (出力先 / "採用技術の全条件.json").write_text(json.dumps({"確認日": "2026-11-16", "catalog": catalog}, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "固定数": len(output), "技術規則数": len(catalog), "署名": signatures}, ensure_ascii=True))


if __name__ == "__main__":
    主処理()
