"""175純合成と予備集計を、金融自然入力なしで別の逐次実装へ照合する。"""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import importlib.util
import json
import math
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'work/175局面別入口の再探索'


def sha(path: Path) -> str:
    """
    機能: SourceのSHA256を算出する。
    引数: path(Path)。
    返り値: strは十六進指紋。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def no_natural(event: str, arguments: tuple) -> None:
    """
    機能: 入力配列・原板・金融自然正本の読込を監査で禁止する。
    引数: event(str)、arguments(tuple)はPython監査イベント。
    返り値: None。禁止対象はRuntimeErrorを送出する。
    """
    if event!='open' or not isinstance(arguments[0],(str,bytes)):
        return
    path=Path(arguments[0]).resolve()
    if path.is_relative_to(ROOT/'inputs') or path.is_relative_to(ROOT.parent/'JP_OSE_Data'):
        raise RuntimeError('自然入力を開こうとした: '+str(path))
    if path.suffix in ('.npz','.gz') and not path.is_relative_to(HERE):
        raise RuntimeError('自然配列を開こうとした: '+str(path))
    if 'feature_only' in path.parts:
        raise RuntimeError('自然特徴を開こうとした: '+str(path))


def scalar_compose(phases: np.ndarray, options: dict, directions: dict, horizons: list) -> tuple:
    """
    機能: 各eventを一つずつ処理する独立OR合成を行う。
    引数: phases(np.ndarray)、options/directions(dict)、horizons(list[str])。
    返り値: tupleはRoot合成と同じbirth/二幅/期限/成分/競合。
    """
    n=len(phases);core=[];width=[];hi=[];component=[];conflicts=[]
    for event,phase in enumerate(phases):
        rules=sorted(options.get(('DAY','PRE','POST')[int(phase)],[]),key=lambda r:r['id'])
        active=[(index,rule,int(directions[rule['birth_key']][event])) for index,rule in enumerate(rules)
                if directions[rule['birth_key']][event]!=0]
        signs={r[2] for r in active}
        opposed=len(signs)>1
        if active and not opposed:
            index,rule,direction=active[0]
            core.append(direction);width.append(rule['width']);hi.append(horizons.index(rule['horizon']));component.append(index)
        else:
            core.append(0);width.append(200);hi.append(horizons.index('H60'));component.append(-1)
        conflicts.append(opposed)
    c=np.asarray(core,np.int8);w=np.asarray(width,np.int16)
    return {'core':c,'branches':np.asarray([0 if d else -1 for d in core],np.int8),
        'technical':np.zeros(n,np.int8),'tier':np.zeros(n,np.int8)},w,w.copy(),np.asarray(hi,np.int8),np.asarray(component,np.int16),np.asarray(conflicts,bool)


def scalar_physical(direction: np.ndarray, event_cases: np.ndarray, phases: np.ndarray) -> tuple:
    """
    機能: 全履歴で最初に成立した物理caseだけを別の集合方式で残す。
    引数: direction/event_cases/phases(np.ndarray)。
    返り値: tupleはcase/実側/帯。帯の分割前に重複を除く。
    """
    seen=set();cases=[];sides=[];bands=[]
    for d,c,p in zip(direction,event_cases,phases,strict=True):
        if not d or c<0 or int(c) in seen:
            continue
        seen.add(int(c));cases.append(c);sides.append(0 if d==1 else 1);bands.append(p)
    return np.asarray(cases,event_cases.dtype),np.asarray(sides,np.int8),np.asarray(bands,phases.dtype)


def scalar_summary(context: object, cases: np.ndarray, sides: np.ndarray, phases: np.ndarray, fields: tuple) -> np.ndarray:
    """
    機能: 幅・期限・帯・期間を個別ループする独立集計を行う。
    引数: context(object)は人工配列、cases/sides/phases(np.ndarray)、fields(tuple[str])。
    返り値: np.ndarray[3,2,W,H,F]は独立金融16指標。
    """
    out=np.empty((3,2,len(context.table.widths),len(context.table.horizons),len(fields)))
    for band in range(3):
        for period in range(2):
            eligible=[i for i in range(len(context.scenes)) if context.hours[i,band]>0 and (period==0 or i<48)]
            eligible_set=set(eligible);hours=sum(float(context.hours[i,band]) for i in eligible)
            entries=[(int(c),int(s),int(context.case_scene[c])) for c,s,p in zip(cases,sides,phases,strict=True)
                     if p==band and int(context.case_scene[c]) in eligible_set]
            for wi in range(len(context.table.widths)):
                for hi in range(len(context.table.horizons)):
                    labels=[int(context.arrays['label'][c,s,wi,hi]) for c,s,_ in entries]
                    valid=[(float(context.arrays['net'][c,s,wi,hi]),scene) for c,s,scene in entries
                           if context.arrays['known'][c,s,wi,hi]]
                    profit=sum(n for n,_ in valid if n>0);loss=-sum(n for n,_ in valid if n<0)
                    f=labels.count(1);a=labels.count(-1);per_scene={}
                    for (c,s,scene),label in zip(entries,labels,strict=True):
                        if label in (-1,1):per_scene[scene]=per_scene.get(scene,0)+1
                    values={'count':len(entries),'F':f,'A':a,'N':labels.count(0),'C':labels.count(2),'known':len(valid),
                        'profit':profit,'loss':loss,'net':profit-loss,'pf':profit/loss if loss else math.nan,
                        'scenes':len({scene for _,_,scene in entries}),'resolved_scenes':len(per_scene),
                        'max_fa_share':max(per_scene.values(),default=0)/(f+a) if f+a else 1,
                        'rate':f/(f+a) if f+a else math.nan,'per_hour':len(entries)/hours if hours else math.nan,
                        'positive_rate':sum(n>0 for n,_ in valid)/len(valid) if valid else math.nan}
                    out[band,period,wi,hi]=[values[name] for name in fields]
    return out


def same_compose(a: tuple,b: tuple) -> None:
    """
    機能: 合成の全配列を厳密に比較する。
    引数: a/b(tuple)は同形式の合成結果。
    返り値: None。不一致ならAssertionError。
    """
    for key in a[0]:np.testing.assert_array_equal(a[0][key],b[0][key])
    for x,y in zip(a[1:],b[1:],strict=True):np.testing.assert_array_equal(x,y)


def selection_checks(screen: object, rng: np.random.Generator) -> int:
    """
    機能: 予備短表の期間分離・支持境界・選択上限を人工指標で確認する。
    引数: screen(object)は予備評価モジュール、rng(np.random.Generator)。
    返り値: intは独立確認項目数。自然予備短表を開かない。
    """
    rules=[{'id':f'{group}{index:02d}','group':group,'mode':'ALL'}
           for group in ('HT','HB','HR','HM','LC','RL') for index in range(2)]
    widths=[150,200,300];horizons=['H30','H60','SESSION']
    shape=(len(rules),2,3,2,len(widths),len(horizons),len(screen.FIELDS))
    metrics=np.empty(shape);fields={name:i for i,name in enumerate(screen.FIELDS)}
    for index in np.ndindex(shape[:-1]):
        n=int(rng.integers(20,100));f=int(rng.integers(5,n-5));a=n-f
        values={'count':n,'F':f,'A':a,'N':0,'C':0,'known':n,'profit':f*100.,'loss':a*100.,
            'net':(f-a)*100.,'pf':f/a,'scenes':int(rng.integers(6,20)),
            'resolved_scenes':int(rng.integers(4,6)),'max_fa_share':.2,'rate':f/n,
            'per_hour':n/100.,'positive_rate':f/n}
        metrics[index]=[values[name] for name in screen.FIELDS]
    chosen=screen.select(metrics,rules,widths,horizons)
    assert chosen==screen.select(metrics,rules,widths,horizons)
    for period,bands in chosen.items():
        for band,rows in bands.items():
            assert len({row['id'] for row in rows})==len(rows)
            for group in ('HT','HB','HR','HM','LC','RL'):
                part=[row for row in rows if row['family']==group]
                assert len(part)<=4
                assert all(sum(row['birth_key']==key for row in part)<=2 for key in {row['birth_key'] for row in part})
    # ----------------------------------------
    mutated=metrics.copy();mutated[:,:,:,0]=0
    assert chosen['前48']==screen.select(mutated,rules,widths,horizons)['前48']
    mutated=metrics.copy();mutated[:,:,:,1]=0
    assert chosen['全期']==screen.select(mutated,rules,widths,horizons)['全期']
    assert not any(screen.select(np.zeros(shape),rules,widths,horizons)[p][b] for p in screen.PERIODS for b in screen.BANDS)
    # ----------------------------------------
    boundary=np.zeros((1,2,3,2,1,1,len(screen.FIELDS)))
    accepted={'count':12,'F':4,'A':2,'C':2,'known':12,'scenes':6,'resolved_scenes':4,
        'max_fa_share':.5,'net':100,'positive_rate':.6}
    for key,value in accepted.items():boundary[...,fields[key]]=value
    one=[rules[0]]
    assert all(screen.select(boundary,one,[150],['H60'])[p][b] for p in screen.PERIODS for b in screen.BANDS)
    for key,value in [('count',11),('F',3),('scenes',5),('resolved_scenes',3),('C',3),('max_fa_share',.5001)]:
        rejected=boundary.copy();rejected[...,fields[key]]=value
        assert not any(screen.select(rejected,one,[150],['H60'])[p][b] for p in screen.PERIODS for b in screen.BANDS),key
    return 13


def ledger_checks(base: object) -> int:
    """
    機能: 実側・軸添字と未知Noneを保つ最小台帳を人工配列で検査する。
    引数: base(object)は基盤モジュール。
    返り値: intは人工確認項目数。金融未知をゼロへ置換しない。
    """
    shape=(3,2,2,2);money=np.arange(np.prod(shape),dtype=float).reshape(shape)
    known=np.ones(shape,bool);label=np.ones(shape,np.int8)
    cases=np.array([0,1,2]);sides=np.array([0,1,0]);wi=np.array([1,0,1]);hi=np.array([0,1,1])
    known[1,1,0,1]=False;money[1,1,0,1]=np.nan;label[2,0,1,1]=-1
    context=SimpleNamespace(arrays={'net':money,'known':known,'label':label},
        sessions=['日1','夜1'],case_scene=np.array([0,1,1]))
    selected=SimpleNamespace(cases=cases,sides=sides,phases=np.array([0,1,2]),events=np.array([3,8,13]))
    value=(selected,np.array([0,0,2]),wi,hi,np.zeros(3),None)
    ledger=base.scene_ledger(context,value)
    assert ledger=={'net':[float(money[0,0,1,0]),None,float(money[2,0,1,1])],
        'known':[True,False,True],'label':[1,1,-1],'scene':['日1','夜1','夜1'],
        'phase':[0,1,2],'origin':[0,0,2],'event':[3,8,13]}
    return 7


def main() -> None:
    """
    機能: 独立OR・物理正準・全幅期限金融を人工系だけで検査する。
    引数: なし。
    返り値: None。自然金融未読の結果JSONを保存し、RootSourceを変更しない。
    """
    paths=[SOURCE/'基盤175.py',SOURCE/'予備評価175.py'];before={p.name:sha(p) for p in paths}
    sys.addaudithook(no_natural)
    sys.path.insert(0,str(SOURCE))
    import 基盤175 as base
    import 予備評価175 as screen
    rng=np.random.default_rng(1750203);horizons=['H30','H60','H120','SESSION']
    compose_checks=prefix_checks=physical_checks=cells=0
    # ----------------------------------------
    for size in (0,1,8,53,120):
        for repetition in range(20):
            phase=rng.integers(0,3,size,dtype=np.int8);directions={};options={}
            for band in ('DAY','PRE','POST'):
                rules=[]
                for index in range(int(rng.integers(0,7))):
                    key=f'{band}_{index}';directions[key]=rng.integers(-1,2,size,dtype=np.int8)
                    rules.append({'id':key,'birth_key':key,'width':int(rng.choice([125,150,250,400])),
                        'horizon':str(rng.choice(horizons))})
                options[band]=list(reversed(rules))
            actual=base.compose(phase,options,directions,horizons)
            same_compose(actual,scalar_compose(phase,options,directions,horizons));compose_checks+=1
            mirror=base.compose(phase,options,{key:-value for key,value in directions.items()},horizons)
            np.testing.assert_array_equal(mirror[0]['core'],-actual[0]['core'])
            for key in ('technical','tier'):assert not actual[0][key].any()
            for key in ('technical','tier','branches'):np.testing.assert_array_equal(mirror[0][key],actual[0][key])
            for index in (1,2,3,4,5):np.testing.assert_array_equal(mirror[index],actual[index])
            if size:
                end=int(rng.integers(0,size+1))
                short=base.compose(phase[:end],options,{k:v[:end] for k,v in directions.items()},horizons)
                expected=( {k:v[:end] for k,v in actual[0].items()},*[a[:end] for a in actual[1:]])
                same_compose(short,expected);prefix_checks+=1
    # ----------------------------------------
    too_many=[{'id':str(i),'birth_key':str(i),'width':125,'horizon':'H60'} for i in range(7)]
    try:base.compose(np.array([0],np.int8),{'DAY':too_many},{str(i):np.ones(1,np.int8) for i in range(7)},horizons)
    except AssertionError:pass
    else:raise AssertionError('7局面を受理した')
    for repetition in range(70):
        n=210;scene=np.repeat(np.arange(54),4)[:n]
        phase=np.asarray([0 if s%2==0 else (1 if index%4<2 else 2) for index,s in enumerate(scene)],np.int8)
        event_cases=np.arange(n,dtype=np.int32)
        for i in range(1,n):
            if scene[i]==scene[i-1] and rng.random()<.35:event_cases[i]=event_cases[i-1]
        event_cases[rng.random(n)<.1]=-1
        direction=rng.integers(-1,2,n,dtype=np.int8)
        actual=screen.physical(direction,event_cases,phase)
        expected=scalar_physical(direction,event_cases,phase)
        for a,b in zip(actual,expected,strict=True):np.testing.assert_array_equal(a,b)
        physical_checks+=1
        c=n;w=4;h=4
        shape=(c,2,w,h)
        label=rng.choice(np.array([-1,0,1,2],np.int8),size=shape)
        known=rng.random(shape)>.25
        net=rng.integers(-50000,50001,size=shape).astype(float)
        net[rng.random(shape)<.08]=0
        net[~known]=np.nan
        case_scene=scene.copy()
        hours=np.asarray([[7.,0,0] if s%2==0 else [0,5.,8.] for s in range(54)])
        if repetition%7==0:hours[:]=0
        context=SimpleNamespace(table=SimpleNamespace(widths=[125,150,250,400],horizons=horizons),
            arrays={'known':known,'net':net,'label':label},case_scene=case_scene,scenes=[{} for _ in range(54)],hours=hours)
        for sides in (actual[1],1-actual[1]):
            observed=screen.summarize(context,actual[0],sides,actual[2])
            independent=scalar_summary(context,actual[0],sides,actual[2],screen.FIELDS)
            np.testing.assert_allclose(observed,independent,rtol=0,atol=1e-8,equal_nan=True)
            cells+=observed.size
        empty=np.array([],np.int32)
        observed=screen.summarize(context,empty,np.array([],np.int8),np.array([],np.int8))
        independent=scalar_summary(context,empty,np.array([],np.int8),np.array([],np.int8),screen.FIELDS)
        np.testing.assert_allclose(observed,independent,rtol=0,atol=1e-8,equal_nan=True);cells+=observed.size
    selection=selection_checks(screen,rng);ledger=ledger_checks(base)
    # ----------------------------------------
    actual=screen.physical(np.array([0,1,-1,1,-1],np.int8),np.array([4,4,4,5,6]),np.array([1,1,2,2,2]))
    for a,b in zip(actual,(np.array([4,5,6]),np.array([0,0,1]),np.array([1,2,2])),strict=True):
        np.testing.assert_array_equal(a,b)
    assert all(sha(p)==before[p.name] for p in paths)
    result={'成功':True,'確認日':'2026-11-16','自然金融未読':True,'自然配列/inputs/Raw読込禁止監査':True,
        'SourceSHA256':before,'Source前後不変':True,'独立OR合成':compose_checks,'鏡像':compose_checks,
        'prefix':prefix_checks,'最大6/7拒否':True,'旧T自動追加なし':True,'物理case正準':physical_checks,
        '全幅期限三帯二期間16指標照合セル':cells,'空取得/ゼロ時間/未知net/逆実側':True,
        '予備選択の期間分離・支持境界・上限':selection,'台帳の軸添字・未知None':ledger,
        '注意':'合法な時刻順contextに限定。自然成績・手法採否の検査ではない。'}
    (HERE/'人工接続の独立結果.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':
    main()
