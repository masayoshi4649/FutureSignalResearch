"""175数量段階を人工配列と差替え再生だけで検査する。"""
from pathlib import Path
from types import SimpleNamespace
from contextlib import contextmanager
import copy
import hashlib
import importlib.util
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'work/175局面別入口の再探索/数量段階を進める.py'


def no_natural(event: str, arguments: tuple) -> None:
    """
    機能: 自然金融と原板の読込を監査で禁止する。
    引数: event(str)、arguments(tuple)は監査イベント。
    返り値: None。禁止対象ならRuntimeError。
    """
    if event!='open' or not isinstance(arguments[0],(str,bytes)):return
    path=Path(arguments[0]).resolve()
    if path.is_relative_to(ROOT/'inputs') or path.is_relative_to(ROOT.parent/'JP_OSE_Data'):
        raise RuntimeError(str(path))
    if path.suffix in ('.npz','.gz') and not path.is_relative_to(HERE):raise RuntimeError(str(path))


def row(policy: dict) -> dict:
    """
    機能: 各期間・帯の選択を検査する人工評価行を作る。
    引数: policy(dict)は固定構成。
    返り値: dictは各期間で支持・経路を満たす人工行。
    """
    periods={};paths={}
    for period in ('全期','前48','後25'):
        periods[period]={};paths[period]={}
        for band in ('DAY','PRE','POST','NIGHT'):
            periods[period][band]={'rank':0,'decision':{'status':'適合'},
                'resolved_scene_count':10,'trades':{'all_count':30,
                'IFD_FIRSTFANC':{'reached_count':20,'first_f_rate_reached':.8}}}
            paths[period][band]={'support':{'participating_scene_count':10,
                'active_calendar_blocks':3,'phase_diagnostic_goal_met':True,'zero_scene_count':0},
                'windows':{'5':{'complete_window_count':5,'negative_net_share_complete':0}}}
    return {'id':policy['id'],'policy':policy,'periods':periods,'paths':paths}


def rule(group: str, band: str, index: int=0) -> dict:
    """
    機能: 群・帯・向きを識別できる人工入口を作る。
    引数: group/band(str)、index(int)。
    返り値: dictはcomposeへ渡せる一入口。
    """
    return {'id':f'{group}{index}_{band}','family':group,'birth_key':f'{group}{index}/NORMAL',
        'width':150+50*index,'horizon':'H60'}


def initialization(module: object) -> None:
    """
    機能: 辞書順と配列行、NORMAL/REVERSEの符号を人工NPZ代用で検査する。
    引数: module(object)は数量段階モジュール。
    返り値: None。自然contextとNPZは開かない。
    """
    matrix=np.array([[1,0,-1,1],[-1,1,0,0]],np.int8);phase=np.array([0,1,2,2],np.int8)
    @contextmanager
    def load(path: str, allow_pickle: bool=False) -> object:
        """
        機能: 人工の出生配列を返す。
        引数: path(str)、allow_pickle(bool)。
        返り値: objectは人工辞書のcontext manager。
        """
        assert not allow_pickle;yield {'directions':matrix,'phases':phase}
    old=(module.B.load_context,module.B.captures,module.B.P.read,module.np.load)
    try:
        module.B.load_context=lambda new:SimpleNamespace(event_phases=phase)
        module.B.captures=lambda context:['人工時計']
        module.B.P.read=lambda path:{'rules':[{'id':'後辞書'},{'id':'先辞書'}]}
        module.np.load=load
        module.initialize('人工出生.npz','人工辞書.json')
        assert module.CAPS==['人工時計']
        for index,name in enumerate(('後辞書','先辞書')):
            np.testing.assert_array_equal(module.DIRS[name+'/NORMAL'],matrix[index])
            np.testing.assert_array_equal(module.DIRS[name+'/REVERSE'],-matrix[index])
        module.B.load_context=lambda new:SimpleNamespace(event_phases=np.array([2,1,2,2],np.int8))
        try:module.initialize('人工出生.npz','人工辞書.json')
        except AssertionError:pass
        else:raise AssertionError('phase不一致を拒否しなかった')
    finally:
        module.B.load_context,module.B.captures,module.B.P.read,module.np.load=old


def evaluation(module: object) -> None:
    """
    機能: global1一回の再生と実側/幅/期限・三期間マスクを検査する。
    引数: module(object)は数量段階モジュール。
    返り値: None。金額計算を人工の金融代用に置換する。
    """
    scene=np.array([0,47,48,49,50,53]);phase=np.array([0,1,2,1,0,2],np.int8)
    sides=np.array([0,1,1,0,1,0]);wi=np.array([0,1,0,1,1,0]);hi=np.array([1,0,1,0,1,0])
    labels=np.zeros((6,2,2,2),np.int8)
    labels[np.arange(6),sides,wi,hi]=np.array([1,-1,2,0,1,-1])
    context=SimpleNamespace(event_phases=phase,table=SimpleNamespace(horizons=['H30','H60']),
        case_scene=scene,scenes=[{} for _ in range(54)],arrays={'label':labels})
    selected=SimpleNamespace(cases=np.arange(6),sides=sides,phases=phase)
    calls=[];finance=[]
    old=(module.B.replay,module.B.financial,module.RISK.path_summary,module.compact_risk)
    try:
        module.CTX=context;module.CAPS=['人工予約']
        module.DIRS={'HT0/NORMAL':np.ones(6,np.int8),'HB0/NORMAL':-np.ones(6,np.int8)}
        def replay(*args: tuple) -> tuple:
            """
            機能: 追加禁止再生の呼出引数を保存する人工代用。
            引数: args(tuple)はcontext・birth・幅・期限・fallback・時計。
            返り値: tupleは人工の実取得。
            """
            calls.append(args);return selected,None,wi,hi,None,{'audits':[{'peak_global_reserved':1,'skipped_held_core':3}]}
        def financial(ctx: object, value: tuple, mask: np.ndarray, eligible: np.ndarray) -> dict:
            """
            機能: 金融評価へ渡す期間・取得マスクを保存する。
            引数: ctx(object)、value(tuple)、mask/eligible(np.ndarray)。
            返り値: dictは人工四帯の群。
            """
            finance.append((mask.copy(),eligible.copy()))
            return {'phases_diagnostic':{b:{} for b in ('DAY','PRE','POST')},'session_groups_required':{'NIGHT':{}}}
        module.B.replay=replay;module.B.financial=financial
        module.RISK.path_summary=lambda group:copy.deepcopy(group);module.compact_risk=lambda risk:risk
        policy={'id':'人工Night','band':'NIGHT','route':'前48',
            'options':{'PRE':[rule('HT','PRE')],'POST':[rule('HB','POST')]}}
        result=module.evaluate(policy)
        assert len(calls)==1 and calls[0][5] is False and calls[0][6]==['人工予約']
        np.testing.assert_array_equal(calls[0][1]['core'],[0,1,-1,1,0,-1])
        assert not calls[0][1]['technical'].any()
        for index,eligible in enumerate((np.ones(54,bool),np.arange(54)<48,np.arange(54)>=48)):
            np.testing.assert_array_equal(finance[index][0],eligible[scene])
            np.testing.assert_array_equal(finance[index][1],eligible)
        assert result['periods']['全期']['NIGHT']['resolved_scene_count']==2
        assert result['periods']['前48']['NIGHT']['resolved_scene_count']==1
        assert result['periods']['後25']['NIGHT']['resolved_scene_count']==1
        assert result['count']==6 and result['max_reserved']==1 and result['held_rejected']==3
    finally:
        module.B.replay,module.B.financial,module.RISK.path_summary,module.compact_risk=old


def ranking(module: object) -> None:
    """
    機能: 二案の共同経路/支持分離と選択期間guardを確認する。
    引数: module(object)は数量段階モジュール。
    返り値: None。順位は人工の比較可能値を使う。
    """
    old=module.RISK.candidate_key
    try:
        module.RISK.candidate_key=lambda g,risk,field:(g['rank'],)
        rows=[row({'id':f'案{i}','route':'前48'}) for i in range(5)]
        for index,value in enumerate(rows):
            value['periods']['前48']['PRE']['rank']=index
            value['paths']['前48']['PRE']['support']['participating_scene_count']=6+index
        selected=module.band_rank(rows,'前48','PRE',2)
        assert [r['id'] for r in selected]==['案0','案4']
        altered=copy.deepcopy(rows)
        for value in altered:
            value['periods']['全期']['PRE']={'故意に無効な別期間':True}
            value['paths']['全期']['PRE']={}
        assert [r['id'] for r in selected]==[r['id'] for r in module.band_rank(altered,'前48','PRE',2)]
        for value in rows:value['periods']['前48']['PRE']['trades']['all_count']=0
        assert module.band_rank(rows,'前48','PRE',2)==[]
    finally:module.RISK.candidate_key=old


def compaction(module: object) -> None:
    """
    機能: 小型経路へ省略しても実順位キーが変わらないことを確認する。
    引数: module(object)は数量段階モジュール。
    返り値: None。元の経路辞書の非破壊も確認する。
    """
    group={'decision':{'status':'適合'},'trades':{'all_count':30,'known_count':30,
        'unknown_count':0,'known_net':1000,'known_profit':2000,
        'IFD_FIRSTFANC':{'first_f_rate_reached':.8}}}
    path={'max_drawdown_amount':300,'initial_minimum':-200,'unrecovered_at_end':False,
        'max_underwater_scenes':3,'cumulative':[0,-200,1000],'underwater_episodes':[{'人工':True}]}
    risk={'complete_runs':[{'人工':True}],'scene_order':['人工場'],
        'exact_path':copy.deepcopy(path),'known_contribution':copy.deepcopy(path),
        'complete_prefix':{'path':copy.deepcopy(path)},
        'windows':{'5':{'complete_window_count':1,'negative_net_share_complete':.2,
            'negative_median_share_complete':.1,'worst_net_window':{'net':-100},'windows':[{'人工':True}]}},
        'support':{'zero_scene_count':0,'phase_diagnostic_goal_met':True,'active_calendar_blocks':3,
            'active_block_fraction':1,'minimum_participating_fraction_per_block':.5,'acquisitions_per_scene':1}}
    original=copy.deepcopy(risk);small=module.compact_risk(risk)
    assert module.RISK.candidate_key(group,risk,'DAY')==module.RISK.candidate_key(group,small,'DAY')
    assert risk==original and 'scene_order' not in small and 'cumulative' not in small['exact_path']


def construction(module: object) -> dict:
    """
    機能: mainを人工読書き/再生へ差替え、六群・帯・trial/folder結合を検査する。
    引数: module(object)は数量段階モジュール。
    返り値: dictは段階別の人工政策数。
    """
    old=(module.B.P.read,module.B.P.save,module.run_stage,module.RISK.candidate_key,sys.argv)
    counts={};saved={};input_value={};families=('HT','HB','HR','HM','LC','RL')
    def read(path: Path) -> dict:
        """
        機能: mainが読む固定短表を人工辞書から返す。
        引数: path(Path)。
        返り値: dictはその段階の人工短表。
        """
        assert path.parent==HERE/'人工176';return {'選択':input_value}
    def save(path: Path, value: dict) -> None:
        """
        機能: mainの保存先と内容をメモリに記録する。
        引数: path(Path)、value(dict)。
        返り値: None。ファイルは生成しない。
        """
        assert path.parent==HERE/'人工176';saved[path.name]=value
    def stage(folder: Path, trial: int, name: str, policies: list, birth: Path, catalog: Path, workers: int) -> list:
        """
        機能: 政策構成を検査し、人工評価行だけを返す。
        引数: folder/birth/catalog(Path)、trial/workers(int)、name(str)、policies(list)。
        返り値: listは金融未読の人工行。
        """
        assert trial==176 and folder==HERE/'人工176' and workers==1
        assert len({p['id'] for p in policies})==len(policies)
        for p in policies:
            assert p['id'].startswith(p['route'])
            for band,rules in p['options'].items():
                assert len(rules)<=6 and len({r['family'] for r in rules})==len(rules)
                assert all(r['id'].endswith(band) for r in rules)
            if name=='Night接合':assert set(p['options'])=={'PRE','POST'}
            if name=='三帯接合':assert set(p['options'])=={'DAY','PRE','POST'}
        counts[name]=len(policies);rows=[row(p) for p in policies]
        for value in rows:
            for period in ('全期','前48','後25'):
                if period!=value['policy']['route']:
                    value['periods'][period]={'別期間を読んだら不正':True};value['paths'][period]={}
        return rows
    try:
        module.B.P.read=read;module.B.P.save=save;module.run_stage=stage
        module.RISK.candidate_key=lambda g,risk,field:(g['rank'],)
        for current in ('single','mix','night','joint'):
            if current=='single':
                input_value={route:{b:[rule(f,b) for f in families] for b in ('DAY','PRE','POST')} for route in ('全期','前48')}
            elif current=='mix':
                input_value={route:{b:{f:[{'id':f'{route}_{f}_{b}','options':{b:[rule(f,b)]}}] for f in families}
                    for b in ('DAY','PRE','POST')} for route in ('全期','前48')}
            elif current=='night':
                input_value={route:{b:[{'id':f'{route}_{b}_{i}','options':{b:[rule('HT',b,i)]}} for i in range(2)]
                    for b in ('DAY','PRE','POST')} for route in ('全期','前48')}
            else:
                input_value={route:{'DAY':[{'id':f'{route}_D{i}','options':{'DAY':[rule('HT','DAY',i)]}} for i in range(2)],
                    'NIGHT':[{'id':f'{route}_N{i}','options':{'PRE':[rule('HT','PRE',i)],'POST':[rule('HB','POST',i)]}} for i in range(2)]}
                    for route in ('全期','前48')}
            sys.argv=['数量段階を進める.py','--stage',current,'--trial','176','--folder',str(HERE/'人工176'),
                '--birth',str(HERE/'人工出生.npz'),'--catalog',str(HERE/'人工辞書.json'),'--workers','1']
            module.main()
        assert counts=={'単独':36,'六局面':378,'Night接合':8,'三帯接合':8}
        fixed=saved['旧73の固定選択.json']['選択']
        assert all(fixed[route]['主案'] is not None for route in ('全期','前48'))
    finally:
        module.B.P.read,module.B.P.save,module.run_stage,module.RISK.candidate_key,sys.argv=old
    return counts


def main() -> None:
    """
    機能: 数量段階の独立人工検査とSource不変を記録する。
    引数: なし。
    返り値: None。結果票を同じ検査フォルダへ保存する。
    """
    before=hashlib.sha256(SOURCE.read_bytes()).hexdigest();sys.addaudithook(no_natural)
    sys.path.insert(0,str(SOURCE.parent));spec=importlib.util.spec_from_file_location('数量段階の人工検査対象',SOURCE)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    initialization(module);evaluation(module);ranking(module);compaction(module);counts=construction(module)
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==before
    result={'成功':True,'確認日':'2026-11-16','自然金融未読':True,'SourceSHA256':before,
        'Source前後不変':True,'正逆配列と辞書行対応':True,'三期間マスクと実側軸':True,
        'Night双方を単一global再生':True,'旧T追加禁止':True,'前48選択への別期間混入なし':True,
        'family二案は共同経路一案と支持一案':True,'六群各一以内':True,'trial176/folder引数':True,
        '経路小型化の実順位キー不変':True,
        '人工段階政策数':counts,'注意':'run_stageの実ProcessPoolとF2書込はSourceレビュー。人工評価値を選択へ渡す検査。'}
    (HERE/'数量段階の独立結果.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (HERE/'検査対象Source/数量段階を進める.py').write_bytes(SOURCE.read_bytes())
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
