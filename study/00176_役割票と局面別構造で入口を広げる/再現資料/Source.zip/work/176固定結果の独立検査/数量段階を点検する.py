"""176の数量四段階を、既存175の独立一覧法と期間guardへ接続する。"""
from pathlib import Path
import copy
import importlib.util
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'work/176役割票入口の再探索'
STAGE=ROOT/'work/175局面別入口の再探索/数量段階を進める.py'
HELPER=ROOT/'work/175数量結果の独立検査/数量経路を点検する.py'


def load_module(path: Path, name: str) -> object:
    """
    機能: 検査用Sourceをmainを実行せずに明示名で読む。
    引数: path(Path)、name(str)。
    返り値: moduleは読込み済み部品。
    """
    specification=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(specification);sys.modules[name]=module
    specification.loader.exec_module(module);return module


def joint_flags(row: dict, route: str) -> tuple:
    """
    機能: 固定した175共同支持仕様を保存群から独立判定する。
    引数: row(dict)、route(str)は選択期間。
    返り値: tuple[bool,bool,bool]は両中央値と全場・両群先着支持・小帯支持。
    """
    groups=row['periods'][route];risks=row['paths'][route]
    medians=all(groups[b]['decision']['status']=='適合' for b in ('DAY','NIGHT'))
    coverage=all(risks[b]['support']['zero_scene_count']==0 for b in ('DAY','NIGHT'))
    quality=[]
    for band in ('DAY','NIGHT'):
        group=groups[band];trade=group['trades'];fa=trade['IFD_FIRSTFANC']
        quality.append((fa['first_f_rate_reached'] or 0)>=.7 and fa['reached_count']>=12
            and trade['all_count']>=24 and group['resolved_scene_count']>=6)
    phase=all(risks[b]['support']['phase_diagnostic_goal_met'] for b in ('PRE','POST'))
    return medians and coverage,all(quality),phase


def main() -> None:
    """
    機能: 単独・六局面・Night・Jointを全期間で別集計し、選択の保存結果も照合する。
    引数: なし。Rootの固定GO後だけ実行する。
    返り値: None。正式Source/金融/選択は変更せず検査JSONだけを保存する。
    """
    independent=load_module(HELPER,'independent175_for176')
    sys.path.insert(0,str(STAGE.parent));stage=load_module(STAGE,'stage176_independent_review')
    names=('単独','六局面','Night接合','三帯接合')
    paths=[SOURCE/(name+'.json.gz') for name in names]
    paths += [SOURCE/name for name in ('単独短表.json','帯短表.json','Night短表.json','旧73の固定選択.json')]
    paths += [STAGE,HELPER,ROOT/'work/175経路と支持の評価/path175.py',Path(__file__)]
    before=[independent.fingerprint(path) for path in paths]
    counts={'scalar':0,'group':0,'compact_key':0,'period_guard':0,'all_wait_rejected':0,'shortlist':0}
    modes={'exact':0,'unknown':0};sizes={};joint_rows=[];selected_details=[]
    for name in names:
        document=independent.read(SOURCE/(name+'.json.gz'));rows=document['rows'];sizes[name]=len(rows)
        for relative,digest in document['Sourceと出生'].items():
            assert independent.fingerprint(ROOT/relative)['sha256']==digest,relative
        for row in rows:
            assert row['max_reserved']<=1
            for period,groups in row['periods'].items():
                for field,group in groups.items():
                    saved=row['paths'][period][field];expected=independent.independent_risk(group)
                    actual={k:v for k,v in saved.items() if k not in ('version','notes')}
                    independent.compare(expected,actual,row['id']+'/'+period+'/'+field,counts)
                    full=stage.RISK.path_summary(group)
                    assert stage.compact_risk(full)==saved,(row['id'],period,field,'圧縮')
                    assert stage.RISK.candidate_key(group,full,field)==stage.RISK.candidate_key(group,saved,field)
                    counts['group']+=1;counts['compact_key']+=1;modes['exact' if saved['exact_path'] is not None else 'unknown']+=1
        if name=='三帯接合':
            joint_rows=rows;continue
        short_name={'単独':'単独短表.json','六局面':'帯短表.json','Night接合':'Night短表.json'}[name]
        short=independent.read(SOURCE/short_name)['選択']
        for route in ('全期','前48'):
            fields=('NIGHT',) if name=='Night接合' else ('DAY','PRE','POST')
            for field in fields:
                families=('HT','HB','HR','HM','LC','RL') if name=='単独' else (None,)
                for family in families:
                    subset=[r for r in rows if r['policy']['route']==route and r['policy']['band']==field
                        and (family is None or r['policy']['family']==family)]
                    maximum=2 if family is not None else 8
                    actual=stage.band_rank(subset,route,field,maximum)
                    wanted=short[route][field][family] if family is not None else short[route][field]
                    assert [r['id'] for r in actual]==[r['id'] for r in wanted],(name,route,field,family,'短表')
                    guarded=[{**r,'periods':independent.OnlyPeriod({route:r['periods'][route]}),
                        'paths':independent.OnlyPeriod({route:r['paths'][route]})} for r in subset]
                    assert [r['id'] for r in stage.band_rank(guarded,route,field,maximum)]==[r['id'] for r in actual]
                    counts['period_guard']+=1;counts['shortlist']+=1
                    if subset:
                        zero=copy.deepcopy(subset[0]);zero['id']='全静観人工'
                        for p in zero['periods']:zero['periods'][p][field]['trades']['all_count']=0
                        assert stage.band_rank([zero],route,field,maximum)==[]
                        assert [r['id'] for r in stage.band_rank([zero,*subset],route,field,maximum)]==[r['id'] for r in actual]
                        counts['all_wait_rejected']+=1
        del document,rows
    # ----------------------------------------
    fixed=independent.read(SOURCE/'旧73の固定選択.json')['選択'];joint_selected=[]
    for route in ('全期','前48'):
        matching=[r for r in joint_rows if r['policy']['route']==route]
        def rank(row: dict) -> tuple:
            """
            機能: Rootの固定共同支持仕様を同じ公開キーで再現する。
            引数: row(dict)は指定期間だけを持っていてもよい。
            返り値: tupleは昇順。
            """
            groups=row['periods'][route];risks=row['paths'][route];flags=joint_flags(row,route)
            keys=[stage.RISK.candidate_key(groups[b],risks[b],b) for b in ('DAY','NIGHT')]
            zero=sum(risks[b]['support']['zero_scene_count'] for b in ('DAY','NIGHT'))
            return (-int(all(flags)),-int(flags[0]),zero,-int(flags[2]),-int(flags[1]),max(keys),row['id'])
        matching.sort(key=rank);eligible=[r for r in matching if all(joint_flags(r,route))]
        actual=eligible[:2] if eligible else matching[:2]
        assert [r['id'] for r in actual]==fixed[route]['参考候補']
        assert (eligible[0]['id'] if eligible else None)==fixed[route]['主案']
        assert len(eligible)==fixed[route]['共同支持適合数']
        guarded=[{**r,'periods':independent.OnlyPeriod({route:r['periods'][route]}),
            'paths':independent.OnlyPeriod({route:r['paths'][route]})} for r in matching]
        assert [r['id'] for r in sorted(guarded,key=rank)]==[r['id'] for r in matching]
        counts['period_guard']+=1;counts['shortlist']+=1
        joint_selected.append({'route':route,'主案':fixed[route]['主案'],'共同支持':len(eligible),'参照':[r['id'] for r in actual]})
    assert before==[independent.fingerprint(path) for path in paths]
    result={'成功':True,'対象':sizes,'検査':counts,'金融完全性':modes,'不一致':0,'Sourceと入力不変':True,
        '入力':before,'最終選択':joint_selected,'範囲':'保存済みgroupの場行から経路/窓/暦支持を独立一覧法で計算。取得/金融そのものの再生は別検査。'}
    (HERE/'数量四段階の独立結果.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k in ('成功','対象','検査','金融完全性','不一致','Sourceと入力不変','最終選択')},ensure_ascii=False))


if __name__=='__main__':
    main()
