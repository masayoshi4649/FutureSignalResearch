"""176固定四案の台帳・両中央値・完全経路を別集計する。戦略や選択は変更しない。"""
from pathlib import Path
from itertools import groupby
import copy
import importlib.util
import json
import statistics
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PACK=ROOT/'work/176追加七場適用'
FIXED=ROOT/'work/176役割票入口の再探索/旧73の固定選択.json'
EXPECTED_SHA='5c14da27758d9770a6913100cb2bc02116e71e4fbc88231ce480379d3975adbe'


def module(path: Path, name: str) -> object:
    """
    機能: 主処理を起動せず検査用の純部品を読み込む。
    引数: path(Path)は部品Source、name(str)は一意のモジュール名。
    返り値: objectは読み込んだモジュール。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


V=module(ROOT/'work/175数量結果の独立検査/数量経路を点検する.py','independent175_financial176')
F=module(HERE/'financial176.py','financial176_independent')


def full_path(rows: list, exact: bool) -> dict:
    """
    機能: 場末累計の一覧と連続真偽群から、省略前の経路詳細を独立計算する。
    引数: rows(list[dict])は日時順の場、exact(bool)は金融完全性。
    返り値: dictは全累計と水面下区間を含む経路。
    """
    result=V.independent_path(rows,exact)
    cumulative=[sum(r['known_net'] for r in rows[:i+1]) for i in range(len(rows))]
    underwater=[value<max([0.0,*cumulative[:index]]) for index,value in enumerate(cumulative)]
    episodes=[]
    for flag,items in groupby(enumerate(underwater),key=lambda pair:pair[1]):
        indices=[index for index,_ in items]
        if not flag:continue
        start=indices[0]-1;recovery=indices[-1]+1 if indices[-1]+1<len(rows) else None
        episodes.append({'start_index':start,'recovery_index':recovery,'underwater_scenes':len(indices),
            'scenes_to_recovery':None if recovery is None else recovery-start,'recovered':recovery is not None})
    result.update({'cumulative':cumulative,'underwater_episodes':episodes});return result


def full_risk(group: dict) -> dict:
    """
    機能: 省略前の経路・完全連続区間・全5/10場窓を独立に構成する。
    引数: group(dict)は独立金融群のsessions.rowsとtrades。
    返り値: dictは版名/説明文以外のpath175全診断。
    """
    result=V.independent_risk(group);rows=sorted(group['sessions']['rows'],key=lambda r:(r['scene'][:10],r['scene']))
    unknown=sum(r['unknown_count'] for r in rows)
    result.update({'scene_order':[r['scene'] for r in rows],'exact_path':None if unknown else full_path(rows,True),
        'known_contribution':full_path(rows,not unknown)})
    prefix=result['complete_prefix']['scene_count'];result['complete_prefix']['path']=full_path(rows[:prefix],True)
    runs=[]
    for complete,items in groupby(enumerate(rows),key=lambda pair:not pair[1]['unknown_count']):
        selected=[r for _,r in items]
        if complete:runs.append({'start_scene':selected[0]['scene'],'end_scene':selected[-1]['scene'],
            'scene_count':len(selected),'path_reset_to_zero':full_path(selected,True)})
    result['complete_runs']=runs
    for width in (5,10):
        complete=[]
        for index in range(max(0,len(rows)-width+1)):
            selected=rows[index:index+width]
            if any(r['unknown_count'] for r in selected):continue
            values=[r['known_net'] for r in selected]
            complete.append({'start_scene':selected[0]['scene'],'end_scene':selected[-1]['scene'],
                'net':sum(values),'session_median':statistics.median(values),
                'acquisition_count':sum(r['all_count'] for r in selected)})
        result['windows'][str(width)]['windows']=complete
    return result


def financial_actual(financial: dict) -> dict:
    """
    機能: 保存済み金融の五群を独立集計と同じ名前で取り出す。
    引数: financial(dict)はmetrics173全体。
    返り値: dict[str,dict]はALL/DAY/PRE/POST/NIGHT。
    """
    return {'ALL':financial['all_reference'],**financial['phases_diagnostic'],
        'NIGHT':financial['session_groups_required']['NIGHT']}


def check_groups(groups: dict, financial: dict, paths: dict, where: str, counters: dict) -> None:
    """
    機能: 台帳からの金融群と全経路を正本へ再帰照合する。
    引数: groups/financial/paths(dict)、where(str)は照合箇所、counters(dict)は件数。
    返り値: None。不一致は例外。
    """
    actual=financial_actual(financial)
    for band,group in groups.items():
        V.compare(group,actual[band],where+'/'+band+'/金融',counters)
        risk={k:v for k,v in paths[band].items() if k not in ('version','notes')}
        V.compare(full_risk(group),risk,where+'/'+band+'/経路',counters)
        counters['financial_group']+=1;counters['full_risk']+=1
    V.compare(groups['DAY'],financial['session_groups_required']['DAY'],where+'/DAY二重保存',counters)
    statuses={band:groups[band]['decision']['status'] for band in ('DAY','NIGHT')}
    status=('不適合' if '不適合' in statuses.values() else '評価不能' if '評価不能' in statuses.values()
        else '保留' if '保留' in statuses.values() else '適合')
    V.compare(status,financial['required_decision']['status'],where+'/共同判定',counters)
    V.compare(statuses,financial['required_decision']['by_group'],where+'/必須群判定',counters)
    assert financial['required_decision']['phase_medians_are_diagnostic_only']
    assert financial['eligibility_by_phase_explicit']


def eligibility(context: object, mask: np.ndarray) -> tuple:
    """
    機能: 共用Contextの全場時間から、0取得場込みの帯別対象を直接列挙する。
    引数: context(object)、mask(np.ndarray[bool])は対象場。
    返り値: tuple[dict,dict]は対象場と総時間。
    """
    names=('DAY','PRE','POST')
    return ({band:[scene for i,scene in enumerate(context.sessions) if mask[i] and context.hours[i,j]>0]
        for j,band in enumerate(names)},
        {band:float(sum(context.hours[i,j] for i in range(len(mask)) if mask[i])) for j,band in enumerate(names)})


def check_shared_ledger(context: object, row: dict, where: str, counters: dict) -> None:
    """
    機能: 取得packの添字・方向・幅期限から恒久金融と実場を照合する。
    引数: context(object)は共用金融、row(dict)は固定取得pack、where(str)、counters(dict)。
    返り値: None。再生戦略の変更や候補の再選択はしない。
    """
    names=('cases','sides','events','phases','origins','widths','horizons','tiers')
    count=len(row['cases']);assert all(len(row[name])==count for name in names)
    cases,sides,events,wi,hi=[np.asarray(row[name],dtype=np.int32) for name in ('cases','sides','events','widths','horizons')]
    key=(cases,sides,wi,hi);known=context.arrays['known'][key]
    expected={'known':known.tolist(),'label':context.arrays['label'][key].tolist(),
        'net':[float(n) if k else None for n,k in zip(context.arrays['net'][key],known,strict=True)],
        'scene':[context.sessions[int(i)] for i in context.case_scene[cases]]}
    V.compare(expected,row['ledger'],where+'/共用金融',counters)
    V.compare(context.event_phases[events].tolist(),row['phases'],where+'/q0時間帯',counters)
    assert row['engine']['capacity']==1 and row['engine']['contracts_per_request']==1
    assert all(a['peak_global_reserved']<=1 for a in row['engine']['audits'])
    assert sum(a['filled'] for a in row['engine']['audits'])==count
    assert len(row['engine']['records'])==count
    for index,record in enumerate(row['engine']['records']):
        V.compare({'event':row['events'][index],'case':row['cases'][index],'side':row['sides'][index],
            'width':context.table.widths[row['widths'][index]],'origin':row['origins'][index],
            'tier':row['tiers'][index]},record,where+'/取得対照/'+str(index),counters)
    assert all(origin==0 for origin in row['origins'])
    counters['shared_ledger']+=count


def check_periods(context: object, row: dict, where: str, counters: dict) -> dict:
    """
    機能: 前48/後25の対象場と取得台帳を別切出しし、期間金融と経路を検査する。
    引数: context(object)、row(dict)、where(str)、counters(dict)。
    返り値: dictは期間ごとの五群。追加7の前48/後25はローカル添字で全7/空となる。
    """
    records=F.normalize(row);index={scene:i for i,scene in enumerate(context.sessions)};output={}
    for period,predicate in [('全期',lambda i:True),('前48',lambda i:i<48),('後25',lambda i:i>=48)]:
        mask=np.asarray([predicate(i) for i in range(len(context.sessions))],dtype=bool)
        eligible,hours=eligibility(context,mask)
        selected={name:[v for i,v in enumerate(values) if predicate(index[row['ledger']['scene'][i]])]
            for name,values in row['ledger'].items()}
        selected_row={'ledger':selected,'phases':[v for i,v in enumerate(row['phases']) if predicate(index[records[i]['scene']])],
            'origins':[v for i,v in enumerate(row['origins']) if predicate(index[records[i]['scene']])]}
        groups=F.financial_groups(selected_row,eligible,hours);output[period]=groups
        selected_records=F.normalize(selected_row)
        for band in ('DAY','PRE','POST','NIGHT'):
            group=copy.deepcopy(groups[band]);group.pop('origins');group.pop('concentration')
            resolved=[r for r in selected_records if r['label'] in ('F','A') and (r['phase'] in ('PRE','POST') if band=='NIGHT' else r['phase']==band)]
            counts={scene:sum(r['scene']==scene for r in resolved) for scene in context.sessions}
            group.update({'resolved_scene_count':sum(v>0 for v in counts.values()),
                'max_resolved_scene_count':max(counts.values(),default=0)})
            V.compare(group,row['periods'][period][band],where+'/'+period+'/'+band+'/金融',counters)
            saved={k:v for k,v in row['period_paths'][period][band].items() if k not in ('version','notes')}
            V.compare(full_risk(groups[band]),saved,where+'/'+period+'/'+band+'/経路',counters)
            counters['period_group']+=1;counters['full_risk']+=1
    return output


def brief(group: dict) -> dict:
    """
    機能: 独立検算済みの金融・支持・経路を誤認しない要約へまとめる。
    引数: group(dict)は独立金融群。
    返り値: dictは回数、先着、中央値、完全/既知寄与DD、初期損失と窓。
    """
    t=group['trades'];s=group['sessions'];risk=full_risk(group);known=risk['known_contribution'];prefix=risk['complete_prefix']
    return {'取得':t['all_count'],'参加場':s['participating_count'],'対象場':s['eligible_count'],
        '先着':t['IFD_FIRSTFANC'],'利益':t['known_profit'],'損失':t['known_loss'],'既知収支':t['known_net'],
        '金融未知':t['unknown_count'],'建玉中央値':t['net_median'],'場中央値':s['net_median'],
        '両中央値判定':group['decision']['status'],'取得毎時':group['acquisitions_per_hour'],
        '支持':risk['support'],'完全経路':risk['exact_path'],
        '既知寄与':{k:v for k,v in known.items() if k not in ('cumulative','underwater_episodes')},
        '初回未知前完全':prefix,'連続窓':{k:{name:value for name,value in w.items() if name!='windows'} for k,w in risk['windows'].items()},
        'DD既知利益比':risk['known_drawdown_to_known_profit']}


def overlap(old: dict, added: dict, first: str, second: str) -> dict:
    """
    機能: 近接候補二案の入口・幅期限・金融の一致率を実取得列から計算する。
    引数: old/added(dict)はID別取得pack、first/second(str)は固定候補ID。
    返り値: dictは同一入口と同一幅期限取得の集合差、順序一致、政策差。
    """
    output={}
    for period,rows in [('旧73',old),('追加7',added)]:
        a,b=rows[first],rows[second]
        def signatures(row: dict, exact: bool) -> list:
            """
            機能: 取得の実場・event・case・方向を、必要なら幅期限込みで一意化する。
            引数: row(dict)、exact(bool)。
            返り値: list[tuple]は保存順の取得。
            """
            return [(scene,event,case,side,*((wi,hi) if exact else ())) for scene,event,case,side,wi,hi in
                zip(row['ledger']['scene'],row['events'],row['cases'],row['sides'],row['widths'],row['horizons'],strict=True)]
        entry_a,entry_b=signatures(a,False),signatures(b,False);exact_a,exact_b=signatures(a,True),signatures(b,True)
        assert len(set(entry_a))==len(entry_a) and len(set(entry_b))==len(entry_b)
        same=set(entry_a)&set(entry_b);all_entries=set(entry_a)|set(entry_b)
        output[period]={'候補A取得':len(entry_a),'候補B取得':len(entry_b),'同一入口':len(same),
            '入口集合Jaccard':len(same)/len(all_entries) if all_entries else None,
            '入口順一致':entry_a==entry_b,'幅期限付き同一取得':len(set(exact_a)&set(exact_b)),
            '幅期限順一致':exact_a==exact_b,'台帳全一致':a['ledger']==b['ledger'],
            '入口Aのみ':[list(v) for v in sorted(set(entry_a)-set(entry_b))],
            '入口Bのみ':[list(v) for v in sorted(set(entry_b)-set(entry_a))]}
    policy_a,policy_b=old[first]['policy'],old[second]['policy']
    output['政策差']={band:{'A':policy_a['options'][band],'B':policy_b['options'][band]}
        for band in ('DAY','PRE','POST') if policy_a['options'][band]!=policy_b['options'][band]}
    return output


def artificial_checks() -> int:
    """
    機能: 未知中央値の境界・空集合・0取得場保持を人工値で確認する。
    引数: なし。
    返り値: intは人工検査数。
    """
    assert F.median_bounds([],0)['possible_signs']==[]
    unknown=F.median_bounds([],1)
    assert unknown['lower_unbounded'] and unknown['upper_unbounded']
    assert unknown['possible_signs']==['負','ゼロ','正'] and not unknown['strictly_positive_guaranteed']
    positive=F.median_bounds([3,5],1)
    assert positive['lower']==3 and positive['upper']==5 and positive['strictly_positive_guaranteed']
    negative=F.median_bounds([-3,-1],1)
    assert negative['upper']==-1 and not negative['strictly_positive_possible']
    crossing=F.median_bounds([-2,3],1)
    assert crossing['lower']==-2 and crossing['upper']==3 and not crossing['strictly_positive_guaranteed']
    records=[{'net':None,'known':False,'label':'F','scene':'2026-01-01_Day','phase':'DAY','origin':'主'}]
    group=F.aggregate(records,['2026-01-01_Day','2026-01-02_Day'],2.0)
    assert group['sessions']['rows'][0]['all_net'] is None
    assert group['sessions']['rows'][1]['all_net']==0 and group['sessions']['zero_acquisition_count']==1
    assert group['trades']['IFD_FIRSTFANC']['F']==1 and group['trades']['unknown_count']==1
    assert full_risk(group)['exact_path'] is None
    return 7


def main() -> None:
    """
    機能: Rootが固定した四案だけを独立再計算し、比較用の検査票を保存する。
    引数: なし。176自然金融の閲覧はRootのGO済み。
    返り値: None。担当workだけに結果JSONを保存し、凍結Sourceは変更しない。
    """
    files=[PACK/(name+'.json.gz') for name in ('旧73の全取得176','追加7の全取得176','全80の両中央値176')]
    files += [FIXED,PACK/'固定政策を適用する.py',PACK/'金融前の出生固定.json',PACK/'完了.json',
        Path(__file__),HERE/'financial176.py',ROOT/'work/175数量結果の独立検査/数量経路を点検する.py']
    before=[V.fingerprint(path) for path in files]
    assert V.fingerprint(FIXED)['sha256']==EXPECTED_SHA
    fixed=V.read(FIXED);ids=[p['id'] for route in ('全期','前48') for p in fixed['選択'][route]['candidates']]
    assert ids==['全期_J002','全期_J003','前48_J018','前48_J019']
    assert all(fixed['選択'][route]['主案'] is None for route in ('全期','前48'))
    documents={name:V.read(path) for name,path in zip(('旧73','追加7','全80'),files[:3])}
    assert all([r['id'] for r in body['rows']]==ids for body in documents.values())
    sys.path.insert(0,str(ROOT/'work/173両中央値と単一建玉'));import 基盤173 as B
    counters={'scalar':0,'financial_group':0,'period_group':0,'full_risk':0,'shared_ledger':0,'artificial':artificial_checks()}
    independent={};periods={};by_id={name:{row['id']:row for row in body['rows']} for name,body in documents.items()}
    for new,name in ((False,'旧73'),(True,'追加7')):
        context=B.load_context(new);document=documents[name]
        assert context.sessions==document['場順'] and len(context.scenes)==document['場数']
        eligible,hours=eligibility(context,np.ones(len(context.scenes),bool))
        V.compare(eligible,document['対象場'],name+'/対象場',counters);V.compare(hours,document['対象時間'],name+'/対象時間',counters)
        independent[name]={};periods[name]={}
        for row in document['rows']:
            where=name+'/'+row['id'];check_shared_ledger(context,row,where,counters)
            groups=F.financial_groups(row,eligible,hours);independent[name][row['id']]=groups
            check_groups(groups,row['financial'],row['paths'],where,counters)
            periods[name][row['id']]=check_periods(context,row,where,counters)
        del context
    # ----------------------------------------
    # 全80を旧73+追加7の実台帳から再構築し、中央値・支持・DDを再計算する。
    old,added,all_body=[documents[name] for name in ('旧73','追加7','全80')]
    eligible={band:old['対象場'][band]+added['対象場'][band] for band in ('DAY','PRE','POST')}
    hours={band:old['対象時間'][band]+added['対象時間'][band] for band in ('DAY','PRE','POST')}
    assert not set(old['場順'])&set(added['場順'])
    V.compare(eligible,all_body['対象場'],'全80/対象場',counters);V.compare(hours,all_body['対象時間'],'全80/対象時間',counters)
    independent['全80']={}
    for candidate in ids:
        a,b,row=[by_id[name][candidate] for name in ('旧73','追加7','全80')]
        joined={'ledger':{key:a['ledger'][key]+b['ledger'][key] for key in ('net','known','label','scene')},
            'phases':a['phases']+b['phases'],'origins':a['origins']+b['origins']}
        for field in joined:V.compare(joined[field],row[field],'全80/'+candidate+'/'+field,counters)
        groups=F.financial_groups(joined,eligible,hours);independent['全80'][candidate]=groups
        check_groups(groups,row['financial'],row['paths'],'全80/'+candidate,counters)
        V.compare(a['financial'],row['旧73'],'全80/'+candidate+'/旧73',counters)
        V.compare(b['financial'],row['追加7'],'全80/'+candidate+'/追加7',counters)
    assert before==[V.fingerprint(path) for path in files]
    summaries={scope:{candidate:{band:brief(groups[band]) for band in ('DAY','PRE','POST','NIGHT','ALL')}
        for candidate,groups in values.items()} for scope,values in independent.items()}
    for period in ('前48','後25'):
        summaries[period]={candidate:{band:brief(groups[period][band]) for band in ('DAY','PRE','POST','NIGHT','ALL')}
            for candidate,groups in periods['旧73'].items()}
    pairs={route:overlap(by_id['旧73'],by_id['追加7'],*pair) for route,pair in
        [('全期',('全期_J002','全期_J003')),('前48',('前48_J018','前48_J019'))]}
    result={'成功':True,'固定SHA256':EXPECTED_SHA,'対象ID':ids,'主案null維持':True,'検査':counters,'不一致':0,
        'Sourceと入力不変':True,'入力':before,'要約':summaries,'近傍重複':pairs,
        '限界':['独立対象は取得packと共用数値表の照合、金融集計、経路、期間切出し。純出生や注文再生engine自体の独立実装ではない。',
            '追加7を含め全80は既使用場。未見評価ではない。',
            'DDは場末実現収支。保有中時価DDではない。金融未知を0円の全件経路に置かず、完全経路・完全区間と既知寄与を分ける。',
            '追加7packの前48/後25はローカル添字による全7/空。前後差の判断は旧73の前48/後25だけを用いる。']}
    target=HERE/'固定四案の独立結果.json';target.write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('成功','対象ID','検査','不一致','Sourceと入力不変')},ensure_ascii=False))


if __name__=='__main__':main()
