"""176固定案の台帳から金融・両中央値を別集計する純部品。ファイルは読まない。"""
from collections import defaultdict
import math
import statistics


def median_bounds(values: list, missing: int) -> dict:
    """
    機能: 未知へ片側無限値を直接置き、中央値の上下界を独立計算する。
    引数: values(list[float])は既知損益、missing(int)は未知件数。
    返り値: dictはmetrics173の中央値契約に合わせた集計。
    """
    total=len(values)+missing
    center=lambda data:statistics.median(data) if data else None
    low=center([*values,*([-math.inf]*missing)]);high=center([*values,*([math.inf]*missing)])
    lower_inf=low is not None and math.isinf(low);upper_inf=high is not None and math.isinf(high)
    return {'known_count':len(values),'unknown_count':missing,'all_count':total,
        'known_median':center(values),'all_median':center(values) if total and not missing else None,
        'all_median_exact':bool(total and not missing),'lower':None if lower_inf else low,
        'upper':None if upper_inf else high,'lower_unbounded':lower_inf,'upper_unbounded':upper_inf,
        'possible_signs':[label for label,ok in [('負',total and low<0),('ゼロ',total and low<=0<=high),('正',total and high>0)] if ok],
        'strictly_positive_guaranteed':bool(total and low>0),'strictly_positive_possible':bool(total and high>0)}


def normalize(row: dict) -> list:
    """
    機能: packの並列台帳を厳密に正規化する。
    引数: row(dict)はledger(net/known/label/scene)、phases、origins。
    返り値: list[dict]は1取得ずつの独立集計用台帳。
    """
    ledger=row['ledger'];count=len(ledger['net'])
    assert all(len(ledger[k])==count for k in ('known','label','scene'))
    assert len(row['phases'])==len(row['origins'])==count
    output=[];labels={1:'F',-1:'A',0:'N',2:'C','F':'F','A':'A','N':'N','C':'C'}
    phases={0:'DAY',1:'PRE',2:'POST','DAY':'DAY','PRE':'PRE','POST':'POST'}
    origins={0:'主',2:'補完','主':'主','補完':'補完'}
    for index in range(count):
        known=ledger['known'][index];net=ledger['net'][index]
        assert type(known) is bool
        if known:
            assert isinstance(net,(int,float)) and not isinstance(net,bool) and math.isfinite(net)
        else:assert net is None
        label=labels[ledger['label'][index]];phase=phases[row['phases'][index]];origin=origins[row['origins'][index]]
        assert not (known and label=='C')
        assert isinstance(ledger['scene'][index],str) and ledger['scene'][index]
        output.append({'net':float(net) if known else None,'known':known,'label':label,
            'scene':ledger['scene'][index],'phase':phase,'origin':origin})
    return output


def trade_metrics(records: list) -> dict:
    """
    機能: 取得台帳を直接一覧し利益・損失・未知・先着を集計する。
    引数: records(list[dict])は対象の取得台帳。
    返り値: dictはmetrics173の建玉単位指標。
    """
    values=[r['net'] for r in records if r['known']];unknown=len(records)-len(values)
    positive=sum(v>0 for v in values);negative=sum(v<0 for v in values);flat=sum(v==0 for v in values)
    labels={label:sum(r['label']==label for r in records) for label in ('F','A','N','C')}
    reached=labels['F']+labels['A']
    return {'all_count':len(records),'known_count':len(values),'unknown_count':unknown,
        'known_profit':sum(v for v in values if v>0),'known_loss':-sum(v for v in values if v<0),
        'known_net':sum(values),'known_positive_count':positive,'known_negative_count':negative,'known_zero_count':flat,
        'positive_settlement_rate_known':positive/len(values) if values else None,
        'positive_settlement_rate_all_lower':positive/len(records) if records else None,
        'positive_settlement_rate_all_upper':(positive+unknown)/len(records) if records else None,
        'net_median':median_bounds(values,unknown),
        'IFD_FIRSTFANC':{**labels,'reached_count':reached,'first_f_rate_reached':labels['F']/reached if reached else None}}


def decision(trade_median: dict, scene_median: dict) -> dict:
    """
    機能: 建玉・全場両中央値の符号を未知境界から判定する。
    引数: trade_median/scene_median(dict)は中央値境界。
    返り値: dictはmetrics173のdecision契約。
    """
    bounds=[trade_median,scene_median]
    if any(not r['all_count'] for r in bounds):
        status='評価不能';reason='建玉または対象セッションが0件。'
    elif all(r['strictly_positive_guaranteed'] for r in bounds):
        status='適合';reason='両中央値の下限が0円を厳密に上回る。'
    elif any(not r['strictly_positive_possible'] for r in bounds):
        status='不適合';reason='少なくとも一方の中央値の上限が0円以下。'
    else:
        status='保留';reason='未知値によって必須中央値の符号が変わり得る。'
    return {'status':status,'reason':reason,'strictly_positive_required':True,
        'unknown_values_present':any(r['unknown_count'] for r in bounds),'both_exact':all(r['all_median_exact'] for r in bounds)}


def aggregate(records: list, eligible: list, hours: float | None) -> dict:
    """
    機能: 0取得場を保持し、場・主補完・集中を独立に再集計する。
    引数: records(list[dict])は群の取得、eligible(list[str])は対象場の保存順、hours(float|None)は対象時間。
    返り値: dictはmetrics173の一群に一致する金融指標。
    """
    assert len(set(eligible))==len(eligible)
    by_scene=defaultdict(list)
    for record in records:
        assert record['scene'] in eligible
        by_scene[record['scene']].append(record)
    rows=[]
    for scene in eligible:
        selected=by_scene[scene];t=trade_metrics(selected)
        rows.append({'scene':scene,'all_count':t['all_count'],'known_count':t['known_count'],'unknown_count':t['unknown_count'],
            'known_profit':t['known_profit'],'known_loss':t['known_loss'],'known_net':t['known_net'],
            'complete':t['unknown_count']==0,'all_net':t['known_net'] if t['unknown_count']==0 else None,
            'main_count':sum(r['origin']=='主' for r in selected),'supplement_count':sum(r['origin']=='補完' for r in selected)})
    trade=trade_metrics(records);complete=[r['known_net'] for r in rows if r['complete']]
    active=sum(r['all_count']>0 for r in rows);scene_median=median_bounds(complete,len(rows)-len(complete))
    sessions={'eligible_count':len(rows),'complete_count':len(complete),'unknown_count':len(rows)-len(complete),
        'participating_count':active,'zero_acquisition_count':len(rows)-active,'participation_rate':active/len(rows) if rows else None,
        'zero_acquisition_scenes':[r['scene'] for r in rows if not r['all_count']],
        'known_contribution_median_all_scenes':statistics.median(r['known_net'] for r in rows) if rows else None,
        'net_median':scene_median,'complete_positive_count':sum(r['complete'] and r['known_net']>0 for r in rows),
        'complete_negative_count':sum(r['complete'] and r['known_net']<0 for r in rows),
        'complete_zero_count':sum(r['complete'] and r['known_net']==0 for r in rows),'rows':rows}
    origins={}
    for name in sorted({'主','補完'}|{r['origin'] for r in records}):
        selected=[r for r in records if r['origin']==name];scenes={r['scene'] for r in selected}
        origins[name]={'acquisition_count':len(selected),'participating_scene_count':len(scenes),
            'participation_rate':len(scenes)/len(rows) if rows else None,'metrics':trade_metrics(selected)}
    concentration={}
    for name in ('known_profit','known_loss','known_net','all_count'):
        total=sum(r[name] for r in rows);ordered=sorted(rows,key=lambda r:(-r[name],r['scene']))
        concentration[name]=[]
        for count in (1,3,5,10):
            selected=ordered[:count];value=sum(r[name] for r in selected)
            concentration[name].append({'requested_top_count':count,'actual_top_count':len(selected),
                'scenes':[r['scene'] for r in selected],'value':value,'share':value/total if total else None})
    return {'trades':trade,'sessions':sessions,'origins':origins,'eligible_hours':hours,
        'acquisitions_per_hour':len(records)/hours if hours else None,'concentration':concentration,
        'decision':decision(trade['net_median'],scene_median)}


def financial_groups(row: dict, eligible: dict, hours: dict) -> dict:
    """
    機能: 一政策の台帳からALL・DAY・PRE・POST・NIGHTを独立に再集計する。
    引数: row(dict)は取得pack、eligible(dict[str,list[str]])は帯別対象場、hours(dict[str,float])は帯別時間。
    返り値: dict[str,dict]は各群。PRE/POSTは同じNightを共有する。
    """
    records=normalize(row);order=list(dict.fromkeys(s for band in ('DAY','PRE','POST') for s in eligible[band]))
    groups={'ALL':aggregate(records,order,sum(hours.values()))}
    for band in ('DAY','PRE','POST'):
        selected=[r for r in records if r['phase']==band]
        groups[band]=aggregate(selected,eligible[band],hours[band])
    nights=list(dict.fromkeys([*eligible['PRE'],*eligible['POST']]))
    groups['NIGHT']=aggregate([r for r in records if r['phase'] in ('PRE','POST')],nights,hours['PRE']+hours['POST'])
    return groups
