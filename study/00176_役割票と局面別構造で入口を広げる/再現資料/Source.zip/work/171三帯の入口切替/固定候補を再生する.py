"""171の固定主案と前48選択A/Bだけを純特徴から可変S場へ適用する。"""
from pathlib import Path
import sys
import route171

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/168数量枠の因果再生'))
import 再生する as R168
from 共通163 import save


def births(features: object,candidate: dict,setting: dict) -> dict:
    """
    機能: 取得/金融を引数に取らず、171のq0帯切替と固定技術補完を作る。
    引数: features(FeatureDataset)、candidate/setting(dict)。
    返り値: dictはcore/branches/technical/tier等の当時方向配列。
    """
    return route171.births(features,candidate,setting)


def run_context(context: object,candidates: list,setting: dict,output: Path) -> dict:
    """
    機能: 主案とnonnullA/Bの最大3固定案を168未改変cap10で再生する。
    引数: context(GenericContext)、candidates(list[dict])、setting(dict)、output(Path)は未作成先。
    返り値: dictは全場・前後/二時計三帯・枝/売買・数量の報告。
            追加7場全5120探索は行わず、既使用基準期として扱う。
    """
    assert setting['trial']==171 and 1<=len(candidates)<=3 and not output.exists()
    output.mkdir(parents=True);reports=[];refs=[];audits=[]
    for choice in candidates:
        birth=births(context.features,choice,setting)
        value=R168.replay_candidate(context,birth,choice,10)
        selected,origins,widths,tiers,result=value
        reports.append({'id':choice['id'],'candidate':choice,'cap10':R168.describe(context,birth,choice,value)})
        refs.append({'id':choice['id'],'cases':selected.cases.tolist(),'sides':selected.sides.tolist(),
            'events':selected.events.tolist(),'phases':selected.phases.tolist(),'widths':widths.tolist(),
            'origins':origins.tolist(),'tiers':tiers.tolist()})
        audits.append({'id':choice['id'],'audits':result['audits'],'requests':result['requests']})
    report={'成功':True,'場数':len(context.scenes),'場順':context.sessions,'rows':reports,
        '範囲':'171事前主案と前半固定A/Bだけ。追加期は既使用基準、全候補探索はしない。'}
    save(output/'全取得参照.json',{'成功':True,'rows':refs})
    save(output/'数量と要求の監査.json.gz',{'成功':True,'rows':audits})
    save(output/'固定候補の数量比較.json',report)
    return report
