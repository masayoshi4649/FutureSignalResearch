"""q0三帯で複合技術式を選ぶ純部品。確認armは165の全場履歴を維持する。"""
from pathlib import Path
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/167固定入口の別期間'))
import 適用基盤167 as BASE


def route(day_directions: np.ndarray,day_branches: np.ndarray,pre_directions: np.ndarray,
          pre_branches: np.ndarray,post_directions: np.ndarray,post_branches: np.ndarray,
          phases: np.ndarray) -> tuple:
    """
    機能: 当該q0の帯で方向/枝を選ぶ。帯境界でarmを生成/resetしない。
    引数: 六方向/枝(np.ndarray[N])は全場履歴で先に評価した三技術式、phases(np.ndarray[N])は0/1/2。
    返り値: tuple[np.ndarray,np.ndarray]は方向int8と枝−1待機/0MP/1fade。
    """
    n=len(phases);assert np.isin(phases,(0,1,2)).all()
    for directions,branches in [(day_directions,day_branches),(pre_directions,pre_branches),(post_directions,post_branches)]:
        assert directions.shape==branches.shape==(n,) and np.isin(directions,(-1,0,1)).all()
        assert np.array_equal(branches==-1,directions==0) and np.isin(branches,(-1,0,1)).all()
    directions=np.where(phases==0,day_directions,np.where(phases==1,pre_directions,post_directions)).astype(np.int8)
    branches=np.where(phases==0,day_branches,np.where(phases==1,pre_branches,post_branches)).astype(np.int8)
    return directions,branches


def option_births(features: object,profile: dict,options: list) -> dict:
    """
    機能: 純特徴から各帯候補を全場履歴で先に評価し、165のarm消費をそのまま再用する。
    引数: features(FeatureDataset)、profile(dict)はMP/EX、options(list[dict])は8確認候補。
    返り値: dictは全候補directions/branches[8,N]とid順。金融・取得を入力に取らない。
    """
    library=BASE.library;catalog={r['id']:r for r in library.candidate_catalog()}
    evaluator=library.PreparedEvaluator(features.buy_X,features.sell_X,list(features.columns),target_points=200)
    mp=evaluator.evaluate_one(catalog[profile['momentum']])['directions']
    original=evaluator.evaluate_one(catalog[profile['fade']])['directions'];spread_limit=catalog[profile['fade']]['settings']['spread_max']
    scenes=np.array([q['session_index'] for q in features.q0_meta]);times=np.array([q['q0_time'] for q in features.q0_meta])
    for scene in np.unique(scenes):
        assert len({q['contract'] for q in features.q0_meta if q['session_index']==scene})==1
    long_votes=np.stack([evaluator.factor(side,'long_up_votes')[0] for side in (0,1)])
    basic=[];strong=[]
    for side in (0,1):
        def value(name: str) -> np.ndarray:
            """
            機能: 当時実側の純特徴又は派生だけを返す。
            引数: name(str)。
            返り値: np.ndarrayは未知NaNを残す。
            """
            return evaluator.factor(side,name)[0]
        spread=value('q0_spread_points')
        flag=(value('m5_hist_delta_to_side')>0)&(value('m5_rsi_delta_to_side')>0)&\
            (value('q0_last_minus_m1_close_atr5_to_side')>0)&(np.abs(value('m5_rsi_delta_to_side'))<=12)&\
            (spread>0)&(spread<=spread_limit)&(value('abs_q0_close_gap')<=1)
        basic.append(flag);strong.append(flag&(value('m5_di_difference_to_side')>0)&(value('m1_volume_relative_prior3')>=.75))
    basic=np.stack(basic);strong=np.stack(strong);directions=[];branches=[]
    for option in options:
        k=option['background'];timing=option['timing']
        background=np.ones_like(long_votes,dtype=bool) if k==0 else np.isfinite(long_votes)&(long_votes>=k)
        if timing=='OFF':direction=mp.copy();branch=np.where(direction!=0,0,-1).astype(np.int8)
        else:
            if timing=='IMMEDIATE':
                fade=-original;side=np.where(fade==1,0,1)
                fade=np.where(background[side,np.arange(len(mp))],fade,0).astype(np.int8)
            else:
                minutes=5 if timing.startswith('CONF5_') else 10
                assert timing in ('CONF5_BASIC','CONF10_BASIC','CONF5_STRONG','CONF10_STRONG')
                fade=BASE.birth165.confirmed_fade(original,strong if timing.endswith('STRONG') else basic,background,scenes,times,minutes*60)
            conflict=(mp!=0)&(fade!=0)&(mp!=fade)
            direction=np.where(conflict,0,np.where(mp!=0,mp,fade)).astype(np.int8)
            branch=np.where(direction==0,-1,np.where(mp!=0,0,1)).astype(np.int8)
        directions.append(direction);branches.append(branch)
    return {'ids':[o['id'] for o in options],'directions':np.stack(directions),'branches':np.stack(branches)}


def births(features: object,candidate: dict,setting: dict) -> dict:
    """
    機能: 固定したPRE/POST候補をq0でrouteし、同じL180S4/H200補完を残す。
    引数: features(FeatureDataset)、candidate/setting(dict)。
    返り値: dictはcore/branches/technical/tier等の全q0配列。金融を参照しない。
    """
    assert setting['pre_options']==setting['post_options']
    options=option_births(features,candidate['profile'],setting['pre_options'])
    lookup={name:i for i,name in enumerate(options['ids'])}
    day=lookup['IMMEDIATE_B0'];pre=lookup[candidate['pre']];post=lookup[candidate['post']]
    core,branches=route(options['directions'][day],options['branches'][day],options['directions'][pre],options['branches'][pre],
        options['directions'][post],options['branches'][post],features.q0_timeband)
    base=BASE.births(features,candidate);base['core']=core;base['branches']=branches
    return base
