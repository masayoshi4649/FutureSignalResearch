"""固定正本を読取り、175/176の研究記録と版8の設定票を作成する。"""
import gzip
import json
import os
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[2]
STUDIES={175:ROOT/'study/00175_局面別入口を累計経路と支持で探索する',
    176:ROOT/'study/00176_役割票と局面別構造で入口を広げる'}


def read(path: Path) -> object:
    """
    機能: 固定JSONを圧縮の有無に応じて読む。
    引数: path(Path)。
    返り値: objectは正本の値。
    """
    if path.suffix=='.gz':
        with gzip.open(path,'rt',encoding='utf-8') as stream:return json.load(stream)
    return json.loads(path.read_text(encoding='utf-8'))


def money(value: float|None) -> str:
    """
    機能: 既知金額を整数の円表示へ整える。
    引数: value(float|None)。
    返り値: strは未知を補完しない表示。
    """
    return '未確定' if value is None else f'{value:,.0f}'


def bounds(value: dict) -> str:
    """
    機能: 未知を含む中央値の確定値又は上下限を表示する。
    引数: value(dict)はnet_median。
    返り値: str。Noneの境界は無界と区別する。
    """
    lower=value['lower'];upper=value['upper']
    if lower is not None and lower==upper:return money(lower)
    return ('−∞' if lower is None else money(lower))+'～'+('+∞' if upper is None else money(upper))


def table_row(identity: str,band: str,group: dict) -> str:
    """
    機能: 一候補一帯の固定金融をMarkdownの一行にする。
    引数: identity/band(str)、group(dict)。
    返り値: strは取得・参加・先着・利益損失・未知・中央値。
    """
    trades=group['trades'];sessions=group['sessions'];fa=trades['IFD_FIRSTFANC']
    rate=fa['first_f_rate_reached'];percent='未到達' if rate is None else f'{100*rate:.2f}%'
    return f"|{identity}|{band}|{trades['all_count']}|{sessions['participating_count']}/{sessions['eligible_count']}|{fa['F']}/{fa['A']}/{fa['N']}/{fa['C']}・{percent}|{money(trades['known_profit'])}|{money(trades['known_loss'])}|{money(trades['known_net'])}|{bounds(trades['net_median'])}|{bounds(sessions['net_median'])}|{group['decision']['status']}|"


def header() -> str:
    """
    機能: 研究の金融表の列見出しを返す。
    引数: なし。
    返り値: str。
    """
    return '|候補|帯|取得|取得場/全場|F/A/N/C・到達済先着率|既知利益円|既知損失円|既知収支円|建玉中央値円|場中央値円|両中央値|\n|---|---|---:|---:|---|---:|---:|---:|---:|---:|---|\n'


def common() -> str:
    """
    機能: 両試行で同じ数量・費用・評価時計と入力の制約を記録する。
    引数: なし。
    返り値: strはMarkdown。
    """
    return '''## 入力・時計・費用

対象はNK225ラージの当時板・1分特徴を用いた日経mini1枚相当の研究。1pt=100円、税込片道38.5円、追加片道5ptの滑りを課し、実BBOの売買側価格とスプレッドを反映する。mini実板の枚数・注文順位・約定保証の検証ではない。

当時の買/売それぞれ100特徴とq0識別だけから純出生を生成し、金融を入力しない。場・限月の変更又は180秒超の欠測で履歴をリセットし、未公表を0/中立へ補完しない。局所LCは同じ場・限月で15分MACDヒストグラム増分が一度でも公表された後は、gapで再許可しない。原q0でDAY/PRE/POSTを区分し、NY09:30の夏冬を自動変換する。NY境界で技術履歴をリセットしない。

買売合計の保有＋未決予約は最大1枚。q0要求後の別原行q1で取得代用し、保有中・pending中の追加はできない。未知決済は場末まで枠を占有し、同秒返済では秒末に解放する。NightはPRE/POST合成後に一口座で再生し、両小帯の単独成績を足し算しない。0取引場も全場中央値と参加の分母に残す。

出口は同幅IFD_FIRST、幅125/150/175/200/225/250/300/350/400/500/750/1000pt、期限30/60/120分又は場末を比較した。取得後の最初の確定到達をF/A、観測できた未到達をN、観測不足をCとする。F/(F+A)と決済黒字率を区別し、Nの期限返済も利益・損失に含める。Cの収支を0円へ埋めず、建玉・場の両中央値は未知に対する上下限も評価する。追尾出口の改善試行ではなく、単純IFDで入口と幅・期限を比較する研究である。

旧73は37Day＋36Night、前48は24Day＋24Night、後25は13Day＋12Night。追加7は3Day＋4Nightで、全80は40Day＋40Night。旧73全期発見と前48だけの段階選択を分けるが、全期間は以前の研究でも既使用であり、後25や追加7を独立な未見性能とは呼ばない。

## 探索と判定

6群×48論理規則×ALL/EDGEで576純候補。正/逆2方向×12幅×4期限を共用価格表で予備評価し、同一caseの最初の純q0へ物理正準化する。逆方向は同じq0の実BBO側で再評価し、1−pで作らない。独立一枚の予備成績は口座収支ではない。

各群・帯・選択期間から支持先着/参加/利益損失/疎な支持の最大4枠を選ぶ。予備支持は12取得・6到達・6取得場・4到達場・C20%以下・一場到達50%以下。単独global1→各群2案又はoffの局面合成→PRE/POSTのNight接合→Day/Night接合へ進める。反対方向が同時成立なら待機、同方向の幅期限は固定ID順。旧Tを自動追加して参加を作らない。

主案はDay/Night双方の建玉ごと・セッション別の費用後中央値が厳密に正で、全場最低1取得、双方の到達済先着率70%以上と支持件数を共同で満たすことを目指す。PRE/POSTの取得場50%以上・平均0.5取得/場は支持比較の追加軸であり、各小帯への強制定時注文はしない。初期損失、累計DD、回復/水面下、5/10場完全窓、14日非重複暦ブロックも比較し、中央値や累計黒字だけで安定採用しない。未知後の経路は「既知寄与」とし全件DDとは呼ばない。
'''


def readme175() -> str:
    """
    機能: 175の不採用理由と次仮説を固定正本から記録する。
    引数: なし。
    返り値: strは研究README。
    """
    folder=ROOT/'work/175局面別入口の再探索';rows=read(folder/'三帯接合.json.gz')['rows']
    lines=[]
    for identity in ('全期_J018','全期_J026'):
        row=next(x for x in rows if x['id']==identity)
        lines.extend(table_row(identity,b,row['periods']['全期'][b]) for b in ('DAY','NIGHT'))
    return '''# 00175 局面別入口を累計経路と支持で探索する

2026-11-16。**新入口群は不採用、全期/前48とも主案null。** 全ANDの局面別入口は成立が少なく、旧73の三帯接合64案で全場取得・両中央値・率と支持を共同達成した案は0だった。追加7は本試行では未実行。参考候補のCSVも出力していない。

[設定と結果](設定と結果.md)、[金融前固定条件](条件.json)、[176の後続比較](../00176_役割票と局面別構造で入口を広げる/README.md)を併読する。

## 仮説と技術の役割

173前48J026の初期赤字と174米後の希少高率を踏まえ、低ADX回復だけを広げず、高ADX押戻しHT・高ADX突破HB・高ADX失速反転HR・背景混在整理HM・長期未公表LC・低ADX帯端RLを別の複合技術として生んだ。ADXは強弱、EMA/DIは方向、MACD/RSIは動力、BBと価格端は構造、実体と観測量は現在の確認、ATRは取得位置とスパイク警戒に分担する。

市場心理の仮説は、順行枝では背景の参加が押戻し後にも残ること、反転枝では元方向の圧力が弱まった後に反対側が価格帯を取り戻すこと。過熱だけでは反転しない。これらは売買主体の心理の直接観測ではなく、固定した組合せを検証するための説明である。

''' + common() + '''
## 結果

単独40、六局面116、Night17、三帯接合64政策をglobal1再生した。前48ではDAYの予備候補8枠は残ったが、PRE/POSTは各0で、共同の三帯政策まで成立しなかった。全期の参考はJ018/J026のみ、主案への昇格はしない。

以下は旧73の全期成績。F/A/N/Cは先着の区別、利益・損失は費用後の既知決済だけ。未知がある群の全件収支は未確定。

''' + header()+'\n'.join(lines)+'''

J018のDAYは27/37場、Night22/36場。0取引場を残した場中央値がともに0円のため不適合。J018のDAYは前48で既知+146,229円、後25+10,922円。後25のDayは7F/6A、既知寄与DD104,462円で、通期黒字を安定性の根拠にしない。Nightは初期既知寄与最小−70,385円。J026は近傍比較でありJ018と交換しない。

## 原因と次の仮説

純出生の和集合では、HTはDAY/PRE/POST各12/16/12q0、HB21/2/14、HR0/0/0、HM1/0/4、LC187/0/0、RL37/25/33だった。高ADX四群では必要列が既知でも複合条件が通らないq0が数千あり、単なる履歴不足ではない。

175は複数足EMA/DI、MACD/RSI、実体、価格回復と履歴イベントをすべて同時ANDで要求した。HT米後は15分MACD増分だけを外す非金融仮想で65q0/22場が増え、RLは共通のentry−EMA下限とlive回復を共に外すと51q0/14場が増える。これらは成立を遮断した位置の診断であり、除外後の利益を計算したものではない。

次の176では必須の役割を保ち、重複票の全ANDを方向票・動力票の必要数と代替構造へ変更した。175の閾値・Source・結果はそのまま残す。176も全置換では未達だったため、177は174の固定幹を保ち高ADX枝だけを足す別試行へ進む。

## 検査・再現・資料

純Sourceは人工122,112セルで鏡像・prefix・未来改変・NaN・gap・LC公表everを確認。段階接続の人工検査は正逆の行対応・旧Tなし・Night単一再生・前48参照範囲を確認した。単独/六局面468群、75,412スカラーの経路・支持独立検査は不一致0で、順位キーと42短表も一致。これを市場利益の独立な証明とはしない。

金融前条件の後、順位の人工境界を補強した[固定追補](検査/F0a_順位の人工境界補強.json)を数量金融前に保存した。旧173/174の固定条件と当時選択は改変していない。

- [共有Source](../00176_役割票と局面別構造で入口を広げる/再現資料/Source.zip)：純辞書・builder・段階再生・独立検査Source。
- [共有出生と比較正本](../00176_役割票と局面別構造で入口を広げる/再現資料/出生と比較正本.zip)：固定出生、各段金融と短表、175/176原因診断。
- [共有保存索引](../00176_役割票と局面別構造で入口を広げる/再現資料/保存索引.json)：サイズ・SHA・由来。大きい原板と予備統計NPZは重複保存しない。
- [共同再現手順](../00176_役割票と局面別構造で入口を広げる/再現手順.md)。正式入力と隔離再現の確認票を参照する。

一次資料は共有正本ZIP内 `work/175入口の調査/一次資料と入口仮説.md` に2026-11-16確認で保存した。[ADX](https://www.fidelity.com/viewpoints/active-investor/average-directional-index-ADX)、[EMA](https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/ema)、[RSI](https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/RSI)、[MACD](https://www.fidelity.com/learning-center/trading-investing/technical-analysis/technical-indicator-guide/macd)、[先物volume](https://www.cmegroup.com/education/courses/introduction-to-futures/what-is-volume)の一般説明を使った。ADX20/25、5/15/30分、持続秒やスパイク上限は本研究の仮説であり、教材がNK225の70%を保証する値ではない。
'''


def readme176() -> str:
    """
    機能: 176の旧73・追加7・全80と期間差を固定正本から記録する。
    引数: なし。
    返り値: strは研究README。
    """
    old=read(ROOT/'work/176役割票入口の再探索/三帯接合.json.gz')['rows']
    all80=read(ROOT/'work/176追加七場適用/全80の両中央値176.json.gz')['rows']
    extra=read(ROOT/'work/176追加七場適用/追加7の全取得176.json.gz')['rows']
    table80=[];table_period=[];table_extra=[]
    for row in all80:
        table80.extend(table_row(row['id'],b,row['financial']['session_groups_required'][b]) for b in ('DAY','NIGHT'))
    for identity in ('全期_J002','前48_J018'):
        row=next(x for x in old if x['id']==identity)
        for period in ('前48','後25'):
            table_period.extend(table_row(identity+'・'+period,b,row['periods'][period][b]) for b in ('DAY','NIGHT'))
    for row in extra:
        table_extra.extend(table_row(row['id'],b,row['financial']['session_groups_required'][b]) for b in ('DAY','NIGHT'))
    return '''# 00176 役割票と局面別構造で入口を広げる

2026-11-16。**役割票で成立と参加は増えたが、新入口群の全置換は不採用。全期/前48の主案nullを維持する。** 旧73の三帯接合128案は共同支持適合0。固定参考4案を追加7にも適用したが、Nightの未到達と後半の赤字が残った。4案は候補別CSV未出力で、損益の閲覧主案として採用しない。

[設定と結果](設定と結果.md)、[金融前固定条件](条件.json)、[175の前段](../00175_局面別入口を累計経路と支持で探索する/README.md)、[共同再現手順](再現手順.md)を参照する。

## 仮説と技術の役割

175の全ANDが狭すぎたため、同じHT/HB/HR/HM/LC/RL六群を方向・動力・構造の役割票へ変更した。HT/HBでは5/15/30分EMA傾きとDI差の6票中2又は3票、かつ長期票1以上。他群は5分EMA傾き・DI差・gapの3票中1又は2票。動力は5分MACD増分・RSI増分の2票中1又は2票。構造は各枝の履歴イベント、実体回復、現在の価格進行という3パターン中1以上を求める。

ADX水準/傾き、長期の混在/反対方向、BB位置、相対量、スパイクと追いかけのATR制約は票の外の必須として保持した。HRはADX低下と元方向失速後の回復を使い、過熱だけで反転しない。必要列が一つでも未知なら役割全体をNaNとするため、未公表を0票に変えない。MA/MACD/RSIの票を独立した確率として掛け合わせない。

心理仮説は175の役割分担を継承するが、回復の兆候の全一致を待つと取得位置が遅れる可能性を考え、異なる価格回復パターンを代替とした。一方、代替によって小さな一時回復を反転完了と誤る可能性も結果で確かめる。

''' + common() + '''
## 旧73の結果と期間差

単独100、六局面750、Night128、三帯128政策をglobal1再生した。全期64案では両中央値適合16・全場取得0・両群70%と支持12、前48の64案では両中央値適合16・全場取得0・率支持0。全期最大Day35/37場・Night36/36場まで広がったが、共同適合0。全期参考J002/J003、前48参考J018/J019を固定して以後の選び直しをしない。

全期J002/J003の旧73Dayは94取得・40F/27A/24N/3C、先着59.70%、既知利益886,150円・損失728,157円・収支+157,993円。Nightは138取得・27F/17A/74N/20C、61.36%、既知利益1,185,303円・損失1,057,389円・収支+127,914円。N74とC20を落として確率の高さを主張しない。Dayは両中央値下限+3,923円/+692円、Nightは未知により保留だった。

以下の前48/後25は固定候補をそのまま事後分解した結果。全期発見と、前48だけの選択を交換しない。

''' + header()+'\n'.join(table_period)+'''

J002のDayは前48赤字を後25が回収する経路で、既知寄与初期最小−119,542円・DD172,157円・最長水面下28場。Nightは後25で12F/13Aとなり、既知−161,389円。前48選択J018の後25Nightは6F/17A・既知−457,620円で、前半の支持が維持されなかった。

## 固定4案の追加7・全80参考適用

追加7は以前にも使った期間であり、未見確認ではない。旧73固定票SHA `5c14da27758d9770a6913100cb2bc02116e71e4fbc88231ce480379d3975adbe` の4案だけを同体適用した。追加7を見てSource・閾値・順位を選び直していない。

''' + header()+'\n'.join(table_extra)+'''

全80は以下。金額は既知寄与、未知を含む全件収支は未確定。J002/J003は実取得・金融が同じでも異なる固定構成のIDを保持する。

''' + header()+'\n'.join(table80)+'''

全期J002のNightは全40場を取れても先着32/56=57.14%、N85/C21、既知収支−28,857円。既知寄与DD360,928円。前48J018の全80Nightは既知−420,706円・DD547,238円、J019は−430,706円・DD557,238円。参加を増やすことと安定利益が両立したとは言えない。

## 原因と次の仮説

175→176で純成立はHTのDAY/PRE/POSTが12/16/12→869/495/687q0、HB21/2/14→162/80/130、HR0/0/0→69/31/26、HM1/0/4→247/88/138と増えた。成立不足だけの問題は改善したが、広幅でのN、方向判別、期間差が残る。LCは未公表everのため夜間0、RLは新たな短期方向票で175より狭くなった。

共通W200/H60・profile0・低い必要票・確認0秒の既存独立予備対照では、HB米後の相対量.5→1で先着68.12%→73.68%、26→24成立場。HT米前は37.19%→40.69%、HR米前35.29%→30.00%、HM米前30.23%→31.03%と、量だけでは解消しない。逆方向の実BBO対照はそれぞれHT米前51.52%、HR米前61.11%、HM米前52.38%で、逆にするだけの一般則も70%には届かない。

同じ既存票のHM0007はDay44F/15A・74.58%、米前4F/10A・28.57%。HT米後は方向3票＋動力2票＋60秒で14F/5A・73.68%だが32caseに減る。HB米後は60秒確認で改善しない。技術条件や待機秒を全帯へ一律に課すのではなく、局面・回復位置・量を分けて比較する余地がある。これらは金融を持つ独立一枚の予備票で、global1口座成績ではない。

次の177は174固定幹を維持し、175/176の高ADX四群だけを当時ADX>20の新枝として追加する別試行。元幹優先、幹0時のみ新枝、枝の異方向は待機、旧Tの機構も保持する。176全置換と幹への増分を分け、既に機能していた低ADX/補完の条件まで失う影響を切り分ける。177の結果を176の成績へ遡って加えない。

## 検査・再現・資料

純Sourceの人工122,112セルで鏡像・prefix・未来改変・NaN・gap・LC公表everを確認。数量4段4,470群・639,692スカラーの経路/支持独立検査と、固定4案の162,773スカラー・1,100台帳照合は不一致0。未知None、0取引場、Nightの単一global枠、固定近傍ID、主案nullを保持した。指標単独の効果や将来の実注文性能を証明した検査ではない。

- [Source.zip](再現資料/Source.zip)：175/176純辞書、段階再生、共同runner、独立検査。
- [出生と比較正本.zip](再現資料/出生と比較正本.zip)：各段正本、旧73固定票、176追加7/全80、175/176の原因診断と一次資料。
- [保存索引](再現資料/保存索引.json)：由来・サイズ・SHA。共用原板・大きい予備統計NPZは参照/再生成する。
- [再現手順](再現手順.md)：正式入力を使う隔離再現。原板の不要な複製をしない。

純Source/金融前条件は変更していない。175/176参考4CSVはこの2試行では出力しておらず、現在の閲覧主案に使うものではない。
'''


def setting(trial: int) -> str:
    """
    機能: 汎用表版8の全63手法×9尺度をコピーし、使用セルと閾値票を加える。
    引数: trial(int)は175又は176。
    返り値: strは設定結果Markdown。原版を変更せずリンクだけ保存先へ補正する。
    """
    source=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md';text=source.read_text(encoding='utf-8')
    def rebase(match: re.Match) -> str:
        """
        機能: 元文書の相対リンクを同じ対象へのstudy相対リンクにする。
        引数: match(re.Match)。
        返り値: strはURL又は相対パス。
        """
        target=match.group(1)
        if '://' in target or target.startswith('#'):return match.group(0)
        return ']('+Path(os.path.relpath((source.parent/target).resolve(),STUDIES[trial])).as_posix()+')'
    text=re.sub(r'\]\(([^)]+)\)',rebase,text)
    used={'I01':(0,3,4,5),'I02':(0,3),'I03':(3,4),'I04':(3,),'I05':(4,),
        'I08':(3,4,5),'I09':(0,1,3),'C01':(3,4,5),'C02':(3,4),'C03':(0,1,3,4),
        'C04':(3,4,5),'C07':(3,4,5),'P01':(1,3),'P05':(1,),
        'P06':(0,1),'P07':(0,1),'P08':(0,3),'P09':(0,3,4),'V01':(1,),'B01':(0,),
        'E01':(0,),'E02':(0,)}
    rows=[];cells=0;methods=0
    for line in text.splitlines():
        parts=line.split('|')
        if len(parts)==13 and re.fullmatch(r'[ICPVBEXM]\d{2}',parts[1].strip()):
            methods+=1;identity=parts[1].strip()
            for scale in used.get(identity,()):parts[3+scale]=f' S{trial}-TECH / R{trial} '
            cells+=9;line='|'.join(parts)
        rows.append(line)
    assert methods==63 and cells==567,(methods,cells)
    text='\n'.join(rows)+'\n'
    text=text.replace('全セルは未設定・未検証。','本コピーでS'+str(trial)+'-TECH / R'+str(trial)+'を記したセルは下の設定明細で検証済み。他セルは本試行では未使用・未検証。')
    design175='''|S175-TECH|I01/02/03/04/05/08/09、C01/02/03/04/07、P01/05/06/07/08/09、V01、B01の記入尺度|ADX/EMA/DI/動力/価格構造/量/ATR品質|HT/HB/HR/HM/RLは実時間5/10分履歴、確認0/60秒。HT/HBのADX>=20/25、RSI増分絶対値<=8/4、相対量>=.5/.75/1。共通entry−EMA8>=−.25かつ<=1（LC<=.5/1）、M1TR/ATR5<=1.5、M5TR/直前ATR<=2.5、spread>0かつ<=20。HTはEMA/DI各2足以上・長期2/3票・短期2票＋MACD/RSI改善＋実体/live＋NP。HBはADX増分>=−.25/0・履歴Hist最小>=0・実体>=.2/.4・break。HRはADX低下・反対背景＋Hist/ATR増分(0,.15]・RSI増分(0,4]＋NS。HMはADX15..30/20..40・長期1..3票＋NX。RLはADX<=15/20・BB位置<=−.25・平均回帰余地>0＋NR。LCはM15HistΔ未公表ever＋120/180分経過・5分EMA/DI/Hist/RSI・実体・終値位置・量|元Sourceの条件は全AND。売買符号対称。576候補。厳密な全演算子は封印辞書を正本とする|全期主案null。支持不足で不採用。Sourceと辞書は共有ZIP内work/175局面別の純入口/|'''
    design176='''|S176-TECH|I01/02/03/04/05/08/09、C01/02/03/04/07、P01/05/06/07/08/09、V01、B01の記入尺度|方向票・動力票・代替構造＋必須背景/量/品質|HT/HB方向6票中2/3＋長期>=1、他群5分3票中1/2。動力MACDΔ/RSIΔの2票中1/2。構造3パターン中>=1で全必要列既知。相対量>=.5/.75/1、profile0/1で履歴5/10分・RSIスパイク<=8/4・chase<=1/.75。HT/HB ADX>=20/25、entry下限−.5。HBはADXΔ>=−.5/0かつ現3分端突破>0/.1。HRはADX>=20/25かつΔ<=0/−.25、長期<=2/1、BB<=.5、entry下限−2/−1.5。HMはADX15..30/20..40、長期1..3票。RLはADX<=15/20、BB<=−.5/−1、余地>0。LCはM15HistΔ未公表ever・120/180分経過。全体方向を0/60秒確認してALL/EDGE|方向/動力/構造の各役割は必須で、単一指標入口ではない。必要列NaNを0票にしない。576候補|全期/前48とも主案null。既使用追加7でNight赤字。不採用。封印辞書は共有ZIP内work/176局面別の役割票/|'''
    design=design175 if trial==175 else design176
    result='全期64三帯案、両中央値共同0・全場0。J018旧73DAY37取得+157,151円/Night37取得既知+59,382円、場中央値とも0。追加7未実行。' if trial==175 else '全期/前48各64三帯案、共同適合0。全80J002DAY103取得既知+238,300円/Night162取得既知−28,857円。全80Day38/40/Night40/40場。未知3/21件。'
    text+='''
## 本試行で設定したセルの明細

表は版8の63手法×9尺度をすべてコピーした。記入セルは複合条件に使用した尺度であり、指標単独の比較を行ったという意味ではない。3/60分足・日足、VWAP/OBV/CCI/ER/CHOP/SuperTrend等は本試行では未使用。実時間の5/10分履歴を新しい5/10分足に読み替えない。足の公開時点・連続性は既存100特徴の定義を継承する。

|設定ID|手法ID・尺度|役割|閾値・期間・初期化|複合化・売買対称性|実行結果・正本|
|---|---|---|---|---|---|
'''+design+f'''
|S{trial}-IFD|E01/E02・原行|入口の同幅先着と固定決済|幅125/150/175/200/225/250/300/350/400/500/750/1000、H30/H60/H120/SESSION。geometry200は入口の既存派生だけで出口幅非依存|F/A/N/Cを分離。N期限返済を含む、C未知、固定IFD監視。追尾幅の最適化は未実施|R{trial}。費用と金融の全表はREADME|
|S{trial}-G1|原q0→別原行q1|追加禁止と費用|mini1枚、1pt100円、税込片道38.5円＋片道5pt。買売保有＋pending<=1、未知場末、同秒末枠解放|Night合成後一口座、q0帯・NY夏冬。旧T追加なし|独立一枚予備票とglobal1を区別|

## 複合評価の結果

|評価ID|構成|対象・分母|結果|未知・限界|
|---|---|---|---|---|
|R{trial}|S{trial}-TECH＋S{trial}-IFD＋S{trial}-G1|旧73全期発見と前48だけの選択を分離、0取引場を分母に含む|{result}|過去は既使用。金融未知Noneを維持、既知寄与を全件損益としない。先着率と決済黒字率を区別|

詳細の金融・期間差・原因・検査・再現資料は[README](README.md)、全条件固定は[条件.json](条件.json)。設定の短い要約で全演算子や元Sourceの同体を置換しない。
'''
    return text


def main() -> None:
    """
    機能: 依頼されたstudy175/176のREADMEと設定結果だけを更新する。
    引数: なし。
    返り値: None。固定Source・条件JSON・金融・CSVを変更しない。
    """
    for trial,body in ((175,readme175()),(176,readme176())):
        path=STUDIES[trial];(path/'README.md').write_text(body,encoding='utf-8')
        (path/'設定と結果.md').write_text(setting(trial),encoding='utf-8')
        print(trial,len(body),(path/'設定と結果.md').stat().st_size)


if __name__=='__main__':
    main()
