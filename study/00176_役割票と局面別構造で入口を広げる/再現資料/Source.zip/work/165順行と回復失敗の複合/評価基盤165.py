"""新技術の初参加補完を過去の実取得と未決注文だけで制御する。"""
from pathlib import Path
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/163入口と任意幅'))
from 共通163 import read,module
from 評価163 import summary_cube,FIELDS,PERIODS
sys.path.insert(0,str(ROOT/'work/162入口探索'))
from 評価基盤 import Selection

prior=module(ROOT/'work/164先着確定と反転比較/比較する.py','first_ifd165')
FIELDS165=FIELDS+('technical_first_count','core_count')
INTEGRATIONS165=('N','U','F','T150','T200')


def quote_key(quote: dict) -> tuple:
    """
    機能: 物理気配を同秒の原行順まで比較可能にする。
    引数: quote(dict)はtime/index/source_lineを持つ。
    返り値: tupleは時刻/index/source_line。
    """
    return quote['time'],quote['index'],quote['source_line']


class Context165(prior.Context164):
    """新規要求と技術初参加要求を同一の実取得へ結ぶ。"""
    def __init__(self) -> None:
        """
        機能: 固定q0/captureから要求・終了原行を作り、損益を制御へ渡さない。
        引数: self(Context165)。
        返り値: None。技術初参加はSource C1参照と独立に評価する。
        """
        super().__init__()
        captures,_=self.data.read_json_ref(self.data.FORMAL_REFS['captures'])
        by_event={r['event_id']:r for r in captures['rows']}
        self.capture_rows=[by_event[q['event_id']] for q in self.features.q0_meta]
        self.event_keys=[(q['q0_time'],q['q0_index'],q['q0_line']) for q in self.features.q0_meta]
        self.end_keys=[]
        for row in self.capture_rows:
            expiry=(row['expires'],float('inf'),float('inf'))
            terminated=quote_key(row['terminated_at']) if row.get('terminated_at') is not None else expiry
            self.end_keys.append(min(expiry,terminated))
        self.scene_events=[np.flatnonzero(self.event_scenes==i) for i in range(73)]

    def technical_integrate(self, core_directions: np.ndarray, core: Selection,
                            technical_directions: np.ndarray, after_seconds: int=2700) -> tuple:
        """
        機能: 主新規未取得・主注文未決なしの時だけ最初の技術補完を逐次予約する。
        引数: core_directions(np.ndarray[int8])、core(Selection)、technical_directions(np.ndarray[int8])、after_seconds(int)。
        返り値: tuple[Selection,np.ndarray,list]は取得・origin0主/2技術補完・全73場の因果監査。
        """
        fallback=[];audits=[]
        for scene,events in enumerate(self.scene_events):
            main_rows=np.flatnonzero(self.case_scene[core.cases]==scene)
            first_main=min(((self.arrays['entry_time'][core.cases[i]],int(self.arrays['entry_index'][core.cases[i]]),
                int(self.arrays['entry_line'][core.cases[i]])) for i in main_rows),default=(float('inf'),float('inf'),float('inf')))
            requests=events[core_directions[events]!=0]
            pending_until=None;attempts=[];wait_pending=0;chosen=None
            for event in events:
                now=self.event_keys[event]
                if now[0]<self.scenes[scene]['start']+after_seconds:continue
                if first_main<=now:break
                if pending_until is not None and pending_until>now:continue
                if core_directions[event]!=0:continue
                if technical_directions[event]==0:continue
                pending=any(self.event_keys[r]<=now and self.end_keys[r]>now for r in requests)
                if pending:
                    wait_pending+=1;continue
                capture=self.capture_rows[event]
                attempts.append({'event_index':int(event),'q0':list(now),'side':int(technical_directions[event]),
                    'status':capture['status'],'pending_until':[v if np.isfinite(v) else None for v in self.end_keys[event]]})
                if capture['status']=='filled':
                    case=self.case_map[capture['case_id']]
                    chosen=(case,0 if technical_directions[event]==1 else 1,int(event),int(self.event_phases[event]))
                    fallback.append(chosen)
                    # 要求後の新主取得で予約を事後取消ししない。最初Tの取得までは未決として扱う。
                    break
                pending_until=self.end_keys[event]
            audits.append({'scene_index':scene,'session':self.sessions[scene],'first_core_q1':list(first_main) if np.isfinite(first_main[0]) else None,
                'attempts':attempts,'core_pending_waits':wait_pending,'technical_case':chosen[0] if chosen is not None else None,
                'financial_not_used':True})
        records=[(int(case),int(side),int(event),int(phase),0) for case,side,event,phase in
            zip(core.cases,core.sides,core.events,core.phases,strict=True)]
        records.extend((*row,2) for row in fallback)
        records.sort(key=lambda r:(r[2],r[4]))
        seen=set();rows=[]
        for row in records:
            if row[0] in seen:continue
            seen.add(row[0]);rows.append(row)
        selected=Selection(np.array([r[0] for r in rows],dtype=np.int32),np.array([r[1] for r in rows],dtype=np.int8),
            np.array([r[2] for r in rows],dtype=np.int32),np.array([r[3] for r in rows],dtype=np.int8),np.zeros(len(rows),dtype=bool))
        origins=np.array([r[4] for r in rows],dtype=np.int8)
        return selected,origins,audits


def widths_for_selection(context: Context165, selected: Selection, origins: np.ndarray, branches: np.ndarray,
                         momentum_width: int, fade_width: int, technical_width: int) -> np.ndarray:
    """
    機能: 当時決めた主枝幅又は補完幅を各物理取得へ固定する。
    引数: context(Context165)、selected(Selection)、origins/branches(np.ndarray[int8])、
          momentum_width/fade_width/technical_width(int)は対称IFD幅。
    返り値: np.ndarray[int8]は各取得の共用幅添字。
    """
    widths=np.full(len(selected.cases),context.table.widths.index(200),dtype=np.int8)
    for origin in (0,2):
        mask=origins==origin
        if origin==2:
            widths[mask]=context.table.widths.index(technical_width);continue
        events=selected.events[mask];assert np.all(events>=0)
        branch=branches[events];assert np.isin(branch,(0,1)).all()
        widths[mask]=np.where(branch==0,context.table.widths.index(momentum_width),context.table.widths.index(fade_width))
    return widths


def extended_cube(context: Context165, selected: Selection, origins: np.ndarray, widths: np.ndarray) -> np.ndarray:
    """
    機能: 共通25指標へ主枝・技術補完の件数を追加する。
    引数: context(Context165)、selected(Selection)、origins/widths(np.ndarray[int])。
    返り値: np.ndarray[float,H,3,27]は金融未知と新旧帰属を保持する統計。
    """
    main=summary_cube(context,selected,widths)
    result=np.full((*main.shape[:-1],len(FIELDS165)),np.nan);result[:,:,:len(FIELDS)]=main
    scenes=context.case_scene[selected.cases]
    for pi,period in enumerate(PERIODS):
        rows=np.ones(len(scenes),dtype=bool)
        if period=='前48場':rows &= scenes<48
        if period=='後25場':rows &= scenes>=48
        result[:,pi,len(FIELDS)]=int(np.sum((origins==2)&rows))
        result[:,pi,len(FIELDS)+1]=int(np.sum((origins==0)&rows))
    return result
