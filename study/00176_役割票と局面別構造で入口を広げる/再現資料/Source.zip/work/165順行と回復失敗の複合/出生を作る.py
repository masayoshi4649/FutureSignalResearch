"""順行と回復失敗の複合・新技術補完をq0情報だけで作る。"""
from pathlib import Path
from itertools import product
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00165_順行と回復失敗を組み合わせ技術条件で初参加を補う'
BOOK_SHA='f2b6aace1ee8fe79b3977d79fc2346cc03fd3c752f15609a628a3f189c93b5af'
sys.path.insert(0,str(ROOT/'work/163入口と任意幅'))
from 共通163 import read,save,sha,module,data_module


def confirmed_fade(original: np.ndarray, confirmation: np.ndarray, background: np.ndarray,
                   scenes: np.ndarray, times: np.ndarray, lifetime: int) -> np.ndarray:
    """
    機能: 元回復の成立で反対側をarmし、期限内の初失速確認だけで発火する。
    引数: original(np.ndarray[int8])、confirmation/background(np.ndarray[bool,2,N])、
          scenes(np.ndarray[int])、times(np.ndarray[float])、lifetime(int秒)。
    返り値: np.ndarray[int8]は未来値を使わない失速確認出生。
    """
    output=np.zeros(len(original),dtype=np.int8);armed=np.full(2,np.nan);previous=0
    for i,side in enumerate(original):
        if i==0 or scenes[i]!=scenes[i-1] or times[i]-times[i-1]>180:
            armed[:]=np.nan;previous=0
        if side and side!=previous:
            intended=-int(side);armed[0 if intended==1 else 1]=times[i]
        hits=[]
        for si in (0,1):
            if not np.isfinite(armed[si]):continue
            if times[i]-armed[si]>lifetime:
                armed[si]=np.nan;continue
            if confirmation[si,i] and background[si,i]:
                hits.append(1 if si==0 else -1);armed[si]=np.nan
        if len(hits)==1:output[i]=hits[0]
        previous=int(side)
    return output


def technical_first(features: object, evaluator: object) -> np.ndarray:
    """
    機能: 方向・動力・量・価格位置の複合票から対称な補完方向を作る。
    引数: features(object)は当時100X、evaluator(object)は対象幅の純特徴評価器。
    返り値: np.ndarray[int8]は高得点側だけを資格確認した新規方向。
    """
    scores=[];passed=[]
    for side in (0,1):
        def value(name: str) -> np.ndarray:
            """
            機能: 当該実側の当時値又は派生だけを取り出す。
            引数: name(str)は列又は派生名。
            返り値: np.ndarray[float]は未知NaNを残した値。
            """
            return evaluator.factor(side,name)[0]
        score=value('technical_score');scores.append(score)
        trend=(value('ema_up_count')>=2)|(value('di_up_count')>=2)
        momentum=((value('m5_hist_delta_to_side')>0)&(value('m15_hist_delta_to_side')>=0))|\
            ((value('m5_rsi_delta_to_side')>0)&(value('m15_rsi_delta_to_side')>=0))|\
            ((value('m5_body_ratio_to_side')>0)&(value('m5_close_position_to_side')>.5))
        spread=value('q0_spread_points')
        flag=np.isfinite(score)&(score>=5)&trend&momentum&(spread>0)&(spread<=20)&\
            (value('abs_q0_close_gap')<=1)&(value('q0_entry_minus_ema8_atr5_to_side')<=1)&\
            (value('m5_rsi_center_to_side')<=25)&(np.abs(value('m5_rsi_delta_to_side'))<=12)&\
            (value('m1_volume_relative_prior3')>=.5)
        passed.append(flag)
    margin=scores[0]-scores[1]
    return np.where((margin>=1)&passed[0],1,np.where((margin<=-1)&passed[1],-1,0)).astype(np.int8)


# ----------------------------------------
def main() -> None:
    """
    機能: 240複合profileと二つの技術初参加補完を金融未入力で固定する。
    引数: なし。固定165条件・100X・163固定出生だけを使用する。
    返り値: None。方向/枝/補完の数値正本とSource証跡を保存する。
    """
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    setting=read(TRIAL/'条件.json');out=HERE/'全出生';assert not out.exists()
    parent=ROOT/'work/163入口と任意幅';proof=read(parent/'全出生/全出生の確認.json')
    path=parent/'全出生/出生200.npz';assert sha(path)==proof['files'][path.name]['sha256']
    before={Path(__file__).relative_to(ROOT).as_posix():sha(Path(__file__)),path.relative_to(ROOT).as_posix():sha(path)}
    save(TRIAL/'検査/F0_複合出生前.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと入力':before,'金融未入力':True})
    with np.load(path,allow_pickle=False) as source:base=source['ALL'].copy()
    lookup={r:i for i,r in enumerate(proof['規則順'])}
    data=data_module();features=data.load_feature_dataset()
    library_path=ROOT/'work/162複合入口候補/rules162.py'
    assert sha(library_path)==setting['candidate_sources']['rules162.py']['sha256']
    library=module(library_path,'rules165_parent');catalog={r['id']:r for r in library.candidate_catalog()}
    evaluator=library.PreparedEvaluator(features.buy_X,features.sell_X,list(features.columns),target_points=200)
    scenes=np.array([q['session_index'] for q in features.q0_meta]);times=np.array([q['q0_time'] for q in features.q0_meta])
    long_votes=np.stack([evaluator.factor(si,'long_up_votes')[0] for si in (0,1)])
    background={k:np.ones_like(long_votes,dtype=bool) if k==0 else np.isfinite(long_votes)&(long_votes>=k)
        for k in setting['fade_background_votes']}
    fades={}
    for ex in setting['fade_rules']:
        original=base[lookup[ex]];spread_limit=catalog[ex]['settings']['spread_max']
        basic=[];strong=[]
        for si in (0,1):
            def get(name: str) -> np.ndarray:
                """
                機能: 当時実側の確認列だけを返す。
                引数: name(str)は列又は派生。
                返り値: np.ndarrayは未知NaNを保持する。
                """
                return evaluator.factor(si,name)[0]
            spread=get('q0_spread_points')
            flag=(get('m5_hist_delta_to_side')>0)&(get('m5_rsi_delta_to_side')>0)&\
                (get('q0_last_minus_m1_close_atr5_to_side')>0)&(np.abs(get('m5_rsi_delta_to_side'))<=12)&\
                (spread>0)&(spread<=spread_limit)&(get('abs_q0_close_gap')<=1)
            basic.append(flag);strong.append(flag&(get('m5_di_difference_to_side')>0)&(get('m1_volume_relative_prior3')>=.75))
        basic=np.stack(basic);strong=np.stack(strong)
        for k in setting['fade_background_votes']:
            immediate=-original
            side_index=np.where(immediate==1,0,1)
            fades[(ex,k,'IMMEDIATE')]=np.where(background[k][side_index,np.arange(len(original))],immediate,0).astype(np.int8)
            for minutes,confirm_name,confirm in product((5,10),('BASIC','STRONG'),(None,)):
                actual=basic if confirm_name=='BASIC' else strong
                fades[(ex,k,f'CONF{minutes}_{confirm_name}')]=confirmed_fade(original,actual,background[k],scenes,times,minutes*60)
    profiles=[];directions=[];branches=[]
    for mp,ex,k,timing in product(setting['momentum_rules'],setting['fade_rules'],setting['fade_background_votes'],setting['fade_timing']):
        a=base[lookup[mp]];b=fades[(ex,k,timing)]
        conflict=(a!=0)&(b!=0)&(a!=b)
        direction=np.where(conflict,0,np.where(a!=0,a,b)).astype(np.int8)
        branch=np.where(direction==0,-1,np.where(a!=0,0,1)).astype(np.int8)
        profiles.append({'id':f'{mp}_{ex}_B{k}_{timing}','momentum':mp,'fade':ex,'background':k,'timing':timing,
            'born':int(np.count_nonzero(direction)),'conflicts':int(conflict.sum())})
        directions.append(direction);branches.append(branch)
    assert len(profiles)==setting['profile_count']==240
    technical=[]
    for width in setting['technical_first']['widths']:
        ev=library.PreparedEvaluator(features.buy_X,features.sell_X,list(features.columns),target_points=width)
        technical.append(technical_first(features,ev))
    out.mkdir();np.savez_compressed(out/'複合と技術補完.npz',directions=np.stack(directions),branches=np.stack(branches),technical=np.stack(technical))
    save(out/'全出生の確認.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと入力':before,'金融未入力':True,
        'profiles':profiles,'technical_widths':setting['technical_first']['widths'],
        'technical_born':[int(np.count_nonzero(x)) for x in technical],'features':features.sources,
        'files':{'複合と技術補完.npz':{'sha256':sha(out/'複合と技術補完.npz'),'bytes':(out/'複合と技術補完.npz').stat().st_size}}})


if __name__=='__main__':
    main()
