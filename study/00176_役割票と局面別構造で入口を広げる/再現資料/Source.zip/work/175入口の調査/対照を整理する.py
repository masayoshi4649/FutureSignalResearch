"""175で再利用する173/174固定八政策の正式参照を整理する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def physical(path: Path) -> dict:
    """
    機能: 既存正式ファイルの位置・サイズ・SHA256を返す。
    引数: path(Path)はリポジトリ内の正式資料。
    返り値: dictはpath/bytes/sha256。元ファイルは変更しない。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,
        'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def member_json(archive: zipfile.ZipFile, name: str) -> dict:
    """
    機能: 既存正式ZIPから通常又はgzip JSONを読む。
    引数: archive(zipfile.ZipFile)、name(str)は固定member名。
    返り値: dictは復元JSON。新175候補の金融は読まない。
    """
    body=archive.read(name)
    return json.loads(gzip.decompress(body) if name.endswith('.gz') else body)


def main() -> None:
    """
    機能: 固定8政策の純条件と再現member、共通schemaを抽出する。
    引数: なし。正式173/174だけを読取する。
    返り値: None。workに小型索引JSONを保存する。
    """
    records=[]
    for number in (173,174):
        trial=next((ROOT/'study').glob(f'{number:05}_*'))
        source_path=trial/'再現資料/Source.zip'
        data_path=trial/'再現資料/出生と比較正本.zip'
        stage_dir='173両中央値と単一建玉' if number==173 else '174参加と両中央値の再探索'
        choice_member=f'work/{stage_dir}/旧73jointの固定選択.json'
        with zipfile.ZipFile(data_path) as archive,zipfile.ZipFile(source_path) as source:
            fixed=member_json(archive,choice_member)['選択']
            policies=[]
            for route in ('全期','前48'):
                for policy in fixed[route]['candidates']:
                    options={band:[{key:rule[key] for key in ('source','rule','mode','orientation','width','horizon','birth_key')}
                                   for rule in rules] for band,rules in policy['options'].items()}
                    policies.append({'対照ID':f"{number}:{policy['id']}",'id':policy['id'],'route':route,
                        '当時の主案':fixed[route]['主案']==policy['id'],'options':options,
                        'fallback':policy['fallback'],'fallback_by_band':policy['fallback_by_band'],
                        'day_fallback_after_minutes':policy.get('day_fallback_after_minutes',45)})
            old_member=f'work/{number}追加七場適用/旧73の全取得{number}.json.gz'
            new_member=f'work/{number}追加七場適用/追加7の全取得{number}.json.gz'
            all_member=f'work/{number}追加七場適用/全80の両中央値{number}.json.gz'
            old=member_json(archive,old_member)
            sample=old['rows'][0]
            required_source=[
                'work/173両中央値と単一建玉/基盤173.py',
                'work/173両中央値と単一建玉/構成173.py',
                'work/173追加なしの因果再生/engine173.py',
                'work/173追加なしの評価/metrics173.py',
                'work/172ナイト入口探索/選定政策の出生.py']
            if number==174:required_source.append('work/174参加と両中央値の再探索/段階再生174.py')
            assert all(name in source.namelist() for name in required_source)
            records.append({'試行':number,'SourceZIP':physical(source_path),'小正本ZIP':physical(data_path),
                '固定票member':choice_member,'旧73取得member':old_member,'追加7取得member':new_member,
                '全80再計算member':all_member,'必要SourceMember':required_source,'政策':policies,
                '取得packのfields':list(sample),'ledgerのfields':list(sample['ledger']),
                'financialのfields':list(sample['financial']),
                '幅軸':old['幅順'],'期限軸':old['期限順'],
                '純出生member':{period:f'work/{number}追加七場適用/{period}の純出生{number}.npz' for period in ('旧73','追加7')}})
    output={'確認日':'2026-11-16','性質':'175の固定対照8件の参照整理。新候補の金融は未読。',
        '対照合計':sum(len(record['政策']) for record in records),'参照':records,
        '共通注意':[
            '旧73も追加7も既使用。新しい独立未見とは称さない。',
            '固定選択・主案・近傍・前48経路を交換しない。173の当時主案nullを保持。',
            '金融未知のledger.netはNone、sceneは文字列。unknownを0円へ置換しない。',
            'widths/horizonsは値そのものではなく共通軸の位置。',
            'base+旧純入口をglobal1で再生し、買売合計保有と未決予約を合わせて一件まで。',
            '175の幅/期限/補完条件を変えたものは固定対照の同体再現と称さない。']}
    (HERE/'既存八対照の正式参照.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'対照合計':output['対照合計'],'試行':[r['試行'] for r in records]},ensure_ascii=False))


if __name__=='__main__':
    main()
