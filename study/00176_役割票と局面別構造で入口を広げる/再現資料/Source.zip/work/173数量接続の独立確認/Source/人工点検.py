"""F1固定Sourceを変更せず、AST定義と人工値だけで173数量接続を独立点検する。"""

from __future__ import annotations

import ast
import copy
import hashlib
import heapq
import json
import math
import statistics
import sys
from collections import Counter
from collections.abc import Mapping, Sequence
from itertools import combinations, product
from numbers import Real
from pathlib import Path
from types import ModuleType, SimpleNamespace

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
TARGET = ROOT / "work/173両中央値と単一建玉"
DESTINATION = HERE.parent


def sha(path: Path) -> str:
    """
    機能: Sourceの物理指紋を読み、点検前後の不変を確認する。
    引数: path（Path）Sourceファイル。
    返り値: str。SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def functions_only(path: Path, name: str, environment: dict) -> ModuleType:
    """
    機能: ASTから関数定義だけを読み込み、import・自然loader・mainを実行しない。
    引数: path（Path）固定Source、name（str）独立module名、environment（dict）人工の依存束。
    返り値: ModuleType。固定Sourceの関数定義をそのままコンパイルしたmodule。
    """
    parsed = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    definitions = [node for node in parsed.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]
    module = ModuleType(name)
    module.__dict__.update(environment)
    exec(compile(ast.Module(body=definitions, type_ignores=[]), str(path), "exec"), module.__dict__)
    return module


def selection(cases, sides, events, phases, flags) -> SimpleNamespace:
    """
    機能: 自然の評価基盤をimportせず、Selectionと同じ項目を持つ人工束を作る。
    引数: cases/sides/events/phases/flags（np.ndarray）取得の並列配列。
    返り値: SimpleNamespace。接続器が参照する配列だけを持つ。
    """
    return SimpleNamespace(cases=cases, sides=sides, events=events, phases=phases, flags=flags)


class ReadAudit:
    """人工配列の実参照キーを記録し、callbackが選んだ幅・期限を直接検査する。"""

    def __init__(self, values: np.ndarray) -> None:
        """
        機能: 人工配列と整数キーの参照履歴を保持する。
        引数: self（ReadAudit）、values（np.ndarray）人工の既知フラグ配列。
        返り値: None。
        """
        self.values = values
        self.keys = []

    def __getitem__(self, key):
        """
        機能: 配列参照を転送し、callbackの4整数キーだけを記録する。
        引数: self（ReadAudit）、key（tuple）通常または高度な配列索引。
        返り値: object。元配列の参照値。
        """
        if isinstance(key, tuple) and all(isinstance(value, (int, np.integer)) for value in key):
            self.keys.append(tuple(int(value) for value in key))
        return self.values[key]


def artificial_context() -> tuple:
    """
    機能: 主期限・旧T期限・未知・pending/held・0取得場を含む6場8要求を作る。
    引数: なし。
    返り値: tuple。人工Context、出生、主幅、補完代用幅、event期限、取得descriptor。
    """
    starts = np.arange(6, dtype=float) * 20000
    times = np.array([3000, 3005, 3030, 3061, 22800, 25000, 43000, 63000], dtype=float)
    scenes = np.array([0, 0, 0, 0, 1, 1, 2, 3], dtype=np.int16)
    phases = np.array([0, 0, 0, 0, 1, 2, 0, 2], dtype=np.int8)
    keys = [(float(value), row * 2, row * 2) for row, value in enumerate(times)]
    descriptors = [{"status": "filled", "case": row,
                    "fill_key": (float(value + 10), row * 2 + 1, row * 2 + 1),
                    "finish_key": (float(value + 10), row * 2 + 1, row * 2 + 1)}
                   for row, value in enumerate(times)]
    shape = (8, 2, 3, 3)
    known = np.ones(shape, dtype=bool)
    exit_time = np.broadcast_to((times + 20)[:, None, None, None], shape).copy()
    labels = np.ones(shape, dtype=np.int8)
    net = np.zeros(shape, dtype=float)
    exit_time[0, :, 0, 0] = 3050
    exit_time[3, :, 2, 2] = 3090
    known[4, :, 1, 1] = False
    labels[4, :, 1, 1] = 2
    for case, amount in ((0, 10), (3, -4), (4, 123456), (6, 2), (7, -2)):
        net[case] = amount
    labels[3] = 0
    labels[6] = 0
    labels[7] = -1
    sessions = ["人工0_Day", "人工0_Night", "人工1_Day", "人工1_Night", "人工2_Day", "人工2_Night"]
    hours = np.array([[2, 0, 0], [0, 1, 1]] * 3, dtype=float)
    context = SimpleNamespace(
        table=SimpleNamespace(widths=[150, 200, 300], horizons=["H30", "H60", "H120"]),
        arrays={"known": known, "exit_time": exit_time, "label": labels, "net": net},
        event_keys=keys, event_scenes=scenes, event_phases=phases,
        scenes=[{"start": start, "end": start + 10000} for start in starts],
        sessions=sessions, case_scene=scenes, hours=hours,
    )
    core = np.array([1, -1, -1, -1, 0, -1, 1, 1], dtype=np.int8)
    technical = np.array([0, 0, 0, 0, 1, -1, 0, 0], dtype=np.int8)
    birth = {"core": core, "branches": np.where(core != 0, 0, -1).astype(np.int8),
             "technical": technical, "tier": np.where(technical != 0, 1, 0).astype(np.int8)}
    widths = np.array([150, 300, 300, 300, 150, 150, 150, 300], dtype=np.int16)
    horizon = np.array([0, 2, 2, 2, 0, 0, 0, 2], dtype=np.int8)
    return context, birth, widths, widths.copy(), horizon, descriptors


class OnePeriod(dict):
    """人工の選択範囲以外を参照した瞬間に例外を出す辞書。"""

    def __getitem__(self, key):
        """
        機能: 許可された一期間だけを返し、別期間のアクセスを検出する。
        引数: self（OnePeriod）期間辞書、key（str）要求期間。
        返り値: object。許可期間の群。
        """
        if key not in self:
            raise AssertionError(f"別期間を参照した: {key}")
        return super().__getitem__(key)


def artificial_group(value: float = 2) -> dict:
    """
    機能: 段階ルートだけを確認する十分な支持の人工群を作る。
    引数: value（float）人工の両中央値下限。
    返り値: dict。選択器とjoint判定が参照する最小metrics。
    """
    median = {"lower": value, "lower_unbounded": False, "strictly_positive_guaranteed": value > 0}
    return {"resolved_scene_count": 8, "max_resolved_scene_count": 5,
            "decision": {"status": "適合" if value > 0 else "不適合"},
            "trades": {"all_count": 30, "known_count": 30, "unknown_count": 0, "known_net": 100,
                       "net_median": median, "IFD_FIRSTFANC": {"F": 24, "A": 6, "reached_count": 30, "first_f_rate_reached": 0.8}},
            "sessions": {"participating_count": 8, "zero_acquisition_count": 2, "net_median": median, "rows": []}}


def inspect_routes(stage: ModuleType, selector: ModuleType) -> dict:
    """
    機能: 実ファイルを読まず、人工の段階短表と別期間アクセスguardで全ルートを実行する。
    引数: stage（ModuleType）固定段階Source、selector（ModuleType）固定選択Source。
    返り値: dict。単独・OR・DayT・Night接合・jointの人工政策数。
    """
    memory, observed, prepared = {}, {}, []
    source_path = TARGET / "人工短表.json"
    reports = {}
    for route in ("全期", "前48"):
        reports[route] = {"短表": {}}
        for band in ("DAY", "PRE", "POST"):
            reports[route]["短表"][band] = [
                {"id": f"{route}_{band}_R{i}", "birth_key": f"{route}_{band}_B{i}", "width": 150 + 150 * i,
                 "horizon": "H30" if i == 0 else "H120", "family": f"人工技術{i}", "source": "人工Source"}
                for i in range(2)]
    memory[source_path] = {"選択": reports}

    def read(path: Path):
        """
        機能: 人工メモリだけから段階入力を返し、実ファイル読込を禁止する。
        引数: path（Path）段階Sourceが要求した名前。
        返り値: object。人工の段階資料。
        """
        if path not in memory:
            raise AssertionError(f"許可していない資料を要求: {path}")
        return memory[path]

    def save(path: Path, value: dict) -> None:
        """
        機能: 段階の保存要求を人工メモリへ閉じ込める。
        引数: path（Path）保存名、value（dict）人工の出力。
        返り値: None。実ファイルは生成しない。
        """
        memory[path] = value

    def prepare(rows: list) -> None:
        """
        機能: 短表の抽出予定だけを記録し、自然出生NPZを開かない。
        引数: rows（list）人工短表。
        返り値: None。
        """
        prepared.extend(rows)

    def run_stage(name: str, policies: list, workers: int) -> list:
        """
        機能: 金融再生をせず、各政策の選択期間だけを持つ人工結果を返す。
        引数: name（str）段階、policies（list）人工政策、workers（int）未使用。
        返り値: list。別期間アクセスguardを持つ人工評価。
        """
        observed[name] = copy.deepcopy(policies)
        output = []
        for policy in policies:
            groups = {band: artificial_group() for band in ("DAY", "PRE", "POST", "NIGHT")}
            output.append({"id": policy["id"], "policy": policy,
                           "periods": OnePeriod({policy["route"]: groups})})
        memory[TARGET / (name + ".json.gz")] = {"rows": output}
        return output

    stage.B = SimpleNamespace(P=SimpleNamespace(read=read, save=save))
    stage.prepare, stage.run_stage = prepare, run_stage
    stage.choose = selector.choose
    previous_module = sys.modules.get("数量候補を選ぶ")
    sys.modules["数量候補を選ぶ"] = selector
    try:
        stage.singles(source_path, 1)
        stage.or_stage(1)
        stage.night_stage(1)
        final = stage.joint_stage(1)
    finally:
        if previous_module is None:
            sys.modules.pop("数量候補を選ぶ", None)
        else:
            sys.modules["数量候補を選ぶ"] = previous_module
    assert len(prepared) == 12
    assert all(not policy["fallback"] for policy in observed["単独global1"])
    day_t = [policy for policy in observed["異技術ORglobal1"] if policy["id"].endswith("_T")]
    assert len(day_t) == 6
    assert all(policy["fallback"] and policy["fallback_by_band"] == {"DAY": True, "PRE": False, "POST": False}
               and set(policy["options"]) == {"DAY"} for policy in day_t)
    for policy in observed["Night接合global1"]:
        assert set(policy["options"]) == {"PRE", "POST"}
        assert policy["fallback_by_band"] == {"DAY": False, "PRE": policy["fallback"], "POST": policy["fallback"]}
    for policy in observed["三帯接合global1"]:
        assert set(policy["options"]) == {"DAY", "PRE", "POST"}
        flags = policy["fallback_by_band"]
        assert flags["PRE"] == flags["POST"] and policy["fallback"] == (flags["DAY"] or flags["PRE"])
    assert all(final[route]["主案"] is not None for route in ("全期", "前48"))
    return {name: len(policies) for name, policies in observed.items()}


def main() -> None:
    """
    機能: 固定Sourceの重要接続だけをAST・人工で独立確認し、小さい結果と指紋を保存する。
    引数: なし。
    返り値: None。自然入力・候補結果を読み込まず、固定Sourceを編集しない。
    """
    source_paths = [TARGET / name for name in ("基盤173.py", "構成173.py", "数量候補を選ぶ.py", "段階再生173.py")]
    source_paths += [ROOT / "work/173追加なしの因果再生/engine173.py", ROOT / "work/173追加なしの評価/metrics173.py"]
    before = {path.relative_to(ROOT).as_posix(): sha(path) for path in source_paths}
    shared = {"np": np, "Path": Path, "math": math, "heapq": heapq, "statistics": statistics,
              "Mapping": Mapping, "Sequence": Sequence, "Real": Real, "Counter": Counter,
              "combinations": combinations, "product": product}
    engine = functions_only(source_paths[4], "engine173_independent", shared)
    metrics = functions_only(source_paths[5], "metrics173_independent", shared)
    baseline = functions_only(source_paths[0], "base173_independent", {**shared,
                              "P": SimpleNamespace(Selection=selection), "engine173": engine, "metrics173": metrics})
    composer = functions_only(source_paths[1], "compose173_independent", shared)
    selector = functions_only(source_paths[2], "select173_independent", shared)
    stage = functions_only(source_paths[3], "stage173_independent", {**shared, "ROOT": ROOT, "HERE": TARGET})
    assert composer.artificial()["成功"] and selector.artificial()["成功"]

    # ----------------------------------------
    # 実engineへの主eventH・旧T200/H60 callbackと未知None・global1・0場をまとめて確認する。
    context, birth, mw, fw, hi, descriptors = artificial_context()
    known_audit = ReadAudit(context.arrays["known"])
    context.arrays["known"] = known_audit
    value = baseline.replay(context, birth, mw, fw, hi, True, descriptors)
    selected, origins, wi, observed_hi, tiers, result = value
    assert selected.events.tolist() == [0, 3, 4, 6, 7]
    assert origins.tolist() == [0, 0, 2, 0, 0]
    assert observed_hi.tolist() == [0, 2, 1, 0, 2]
    assert known_audit.keys == [(0, 0, 0, 0), (3, 1, 2, 2), (4, 0, 1, 1), (6, 0, 0, 0), (7, 0, 2, 2)]
    callback_keys = list(known_audit.keys)
    assert [context.table.widths[index] for index in wi] == [150, 300, 200, 150, 300]
    assert result["audits"][0]["skipped_pending_core"] == 1
    assert result["audits"][0]["skipped_held_core"] == 1
    assert result["audits"][1]["unknown_held_to_end"] == 1
    assert result["audits"][1]["skipped_held_core"] == 1
    assert len(result["audits"]) == 6
    assert all(row["peak_global_reserved"] <= 1 and row["peak_global_held"] <= 1 for row in result["audits"])
    no_fallback = baseline.replay(context, birth, mw, fw, hi, False, descriptors)
    assert 2 not in no_fallback[1].tolist()
    mirrored = dict(birth, core=-birth["core"], technical=-birth["technical"])
    mirror = baseline.replay(context, mirrored, mw, fw, hi, True, descriptors)
    assert np.array_equal(mirror[0].events, selected.events) and np.array_equal(mirror[0].sides, 1 - selected.sides)
    financial = baseline.financial(context, value)
    totals = financial["all_reference"]["trades"]
    assert totals["known_profit"] == 12 and totals["known_loss"] == 6 and totals["known_net"] == 6
    assert totals["unknown_count"] == 1 and totals["net_median"]["known_median"] == 0
    assert totals["net_median"]["all_median"] is None
    assert financial["session_groups_required"]["DAY"]["decision"]["status"] == "適合"
    assert financial["session_groups_required"]["NIGHT"]["decision"]["status"] == "不適合"
    assert financial["required_decision"]["status"] == "不適合"
    for name in ("DAY", "NIGHT"):
        group = financial["session_groups_required"][name]
        assert group["sessions"]["eligible_count"] == 3 and group["sessions"]["zero_acquisition_count"] == 1
        assert len(group["sessions"]["rows"]) == 3
    assert [row["scene"] for row in financial["session_groups_required"]["DAY"]["sessions"]["rows"]] == ["人工0_Day", "人工1_Day", "人工2_Day"]
    assert financial["session_groups_required"]["NIGHT"]["sessions"]["unknown_count"] == 1
    assert financial["session_groups_required"]["NIGHT"]["sessions"]["rows"][0]["all_net"] is None
    eligible = np.array([True, True, True, True, False, False])
    mask = eligible[context.case_scene[selected.cases]]
    prior = baseline.financial(context, value, mask, eligible)
    assert prior["session_groups_required"]["DAY"]["sessions"]["net_median"]["all_median"] == 4

    # ----------------------------------------
    # 同秒exitは秒末まで枠を解放しない。OR反対待機は旧Tへ代用しない。
    same_second_context, same_birth, same_mw, same_fw, same_hi, same_descriptors = artificial_context()
    same_second_context.event_keys[3] = (3050.0, 6, 6)
    same_descriptors[3]["fill_key"] = same_descriptors[3]["finish_key"] = (3060.0, 7, 7)
    same_second = baseline.replay(same_second_context, same_birth, same_mw, same_fw, same_hi, True, same_descriptors)
    assert 3 not in same_second[0].events.tolist()
    a = np.array([1, 1, 0, -1, -1, 0], np.int8)
    b = np.array([1, -1, -1, -1, 1, 1], np.int8)
    phases = np.array([0, 0, 1, 1, 2, 2], np.int8)
    options = {name: [{"id": "Z", "birth_key": "b", "width": 300, "horizon": "H120"},
                      {"id": "A", "birth_key": "a", "width": 150, "horizon": "H30"}]
               for name in ("DAY", "PRE", "POST")}
    composed = composer.compose(phases, options, {"a": a, "b": b}, np.ones(6, np.int8), np.ones(6, np.int8),
                                ["H30", "H60", "H120"], {"DAY": True, "PRE": False, "POST": True})
    assert composed[0]["core"].tolist() == [1, 0, -1, -1, 0, 1]
    assert composed[0]["technical"].tolist() == [1, 0, 0, 0, 0, 1]
    assert composed[1].tolist() == [150, 200, 300, 150, 200, 300]
    assert composed[3].tolist() == [0, 1, 2, 0, 1, 2]

    # ----------------------------------------
    # 段階ルートは自然結果でなく人工メモリだけで通す。別期間はアクセス時点で失敗させる。
    routes = inspect_routes(stage, selector)
    assert all(sha(ROOT / name) == value for name, value in before.items())
    result = {"確認日": "2026-11-15", "自然金融入力読込": False, "自然候補結果読込": False,
              "固定Source編集": False, "Source前後指紋一致": True,
              "検査": ["AST関数定義だけ実行・import/main/自然loader不実行", "主eventHと旧T200/H60 callback",
                       "未知Noneを場末保持・偽の123456円を収支から排除", "同秒exitは秒末解放",
                       "global1のpendingとheld両棄却", "買売鏡像", "eligibleはsession文字列で全場を保持",
                       "0取引場を0円で両中央値へ保持", "DAYとNIGHTを独立必須判定", "OR同方向1・反対は旧Tも停止",
                       "ID順で幅/期限優先固定", "phase別旧TとDayT/Night接合/joint route",
                       "一期間guardで前48以外の参照を禁止", "入力順を変えても同点順位固定"],
              "人工取得": {"件数": len(selected.cases), "主": int((origins == 0).sum()), "補完": int((origins == 2).sum()),
                           "既知収支": totals["known_net"], "未知": totals["unknown_count"],
                           "callback実参照キー_case_side_widthindex_horizonindex": callback_keys,
                           "Day判定": financial["session_groups_required"]["DAY"]["decision"]["status"],
                           "Night判定": financial["session_groups_required"]["NIGHT"]["decision"]["status"]},
              "人工ルート政策数": routes, "不具合": [], "SourceSHA256": before, "結果": "全検査成功"}
    (DESTINATION / "人工結果.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    proof = {"Source/人工点検.py": sha(Path(__file__)), "人工結果.json": sha(DESTINATION / "人工結果.json")}
    (DESTINATION / "SHA256.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"結果": "成功", "自然金融入力": False, "人工取得数": len(selected.cases), "ルート": routes}, ensure_ascii=True))


if __name__ == "__main__":
    main()
