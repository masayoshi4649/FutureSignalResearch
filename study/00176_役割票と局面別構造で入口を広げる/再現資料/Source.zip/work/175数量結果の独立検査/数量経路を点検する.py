"""175の保存済み数量結果を、別の一覧法で経路・支持・選択へ照合する。"""
from pathlib import Path
from datetime import date, timedelta
from itertools import groupby
from collections import defaultdict
import copy
import gzip
import hashlib
import importlib.util
import json
import math
import statistics
import sys

ROOT=Path(__file__).resolve().parents[2]
SOURCE=ROOT/'work/175局面別入口の再探索'
HERE=Path(__file__).resolve().parent


def read(path: Path) -> dict:
    """
    機能: UTF-8又はgzipの保存正本を読む。
    引数: path(Path)。
    返り値: dictはJSON。
    """
    body=path.read_bytes()
    return json.loads(gzip.decompress(body) if path.suffix=='.gz' else body)


def fingerprint(path: Path) -> dict:
    """
    機能: Source又は保存正本の物理指紋を返す。
    引数: path(Path)。
    返り値: dictは相対path/bytes/sha256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,
        'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def independent_path(rows: list, exact: bool) -> dict:
    """
    機能: 累計一覧とピーク候補の列挙から場末DDと回復を別計算する。
    引数: rows(list[dict])は時刻順の全場、exact(bool)は金融完全性。
    返り値: dictはcompact後の経路要約と一致する計測値。
    """
    values=[float(row['known_net']) for row in rows]
    cumulative=[sum(values[:i+1]) for i in range(len(values))]
    peaks=[max([0.0,*cumulative[:i]]) for i in range(len(values))]
    drawdowns=[max(0.0,p-v) for p,v in zip(peaks,cumulative)]
    maximum=max(drawdowns,default=0.0);worst=None
    if maximum>0:
        bottom=drawdowns.index(maximum);peak=peaks[bottom]
        possible=[-1] if peak==0 else []
        possible += [i for i in range(bottom) if cumulative[i]==peak]
        top=max(possible)
        recovery=next((i for i in range(bottom+1,len(rows)) if cumulative[i]>=peak),None)
        worst={'amount':maximum,'peak_index':top,'trough_index':bottom,
            'peak_scene':None if top<0 else rows[top]['scene'],'trough_scene':rows[bottom]['scene'],
            'peak_value':peak,'trough_value':cumulative[bottom],
            'recovery_index':recovery,'recovery_scene':None if recovery is None else rows[recovery]['scene'],
            'scenes_from_peak_to_recovery':None if recovery is None else recovery-top,
            'scenes_from_trough_to_recovery':None if recovery is None else recovery-bottom}
    underwater=[dd>0 for dd in drawdowns]
    water_runs=[len(list(items)) for is_water,items in groupby(underwater) if is_water]
    negative_runs=[len(list(items)) for is_negative,items in groupby(v<0 for v in values) if is_negative]
    minimum=min([0.0,*cumulative]);minimum_index=cumulative.index(minimum) if minimum<0 else None
    nonnegative=next((i for i,v in enumerate(cumulative) if v>=0),None)
    negatives=[i for i,v in enumerate(cumulative) if v<0]
    sustained=negatives[-1]+1 if negatives and negatives[-1]<len(rows)-1 else None
    return {'exact':exact,'meaning':'全件確定の場末実現損益' if exact else '既知寄与だけ。未知を0円と確定した経路ではない。',
        'scene_count':len(rows),'acquisition_count':sum(row['all_count'] for row in rows),
        'net':sum(values),'initial_minimum':minimum,'initial_minimum_index':minimum_index,
        'initial_minimum_scene':None if minimum_index is None else rows[minimum_index]['scene'],
        'below_initial_zero_scenes':len(negatives),
        'first_nonnegative_scene':None if nonnegative is None else rows[nonnegative]['scene'],
        'sustained_nonnegative_scene':None if sustained is None else rows[sustained]['scene'],
        'max_drawdown':worst,'max_drawdown_amount':maximum,
        'max_underwater_scenes':max(water_runs,default=0),
        'unrecovered_at_end':bool(underwater and underwater[-1]),
        'max_consecutive_negative_scenes':max(negative_runs,default=0),
        'worst_scene_net':min(values,default=None)}


def independent_window(rows: list, width: int) -> dict:
    """
    機能: 窓の元行を毎回直接参照し、完全窓の収支と中央値を別計算する。
    引数: rows(list[dict])、width(int)は5又は10場。
    返り値: dictはcompact後の窓要約。
    """
    all_count=max(0,len(rows)-width+1);complete=[]
    for index in range(all_count):
        selected=rows[index:index+width]
        if sum(row['unknown_count'] for row in selected):continue
        values=[row['known_net'] for row in selected]
        complete.append({'start_scene':selected[0]['scene'],'end_scene':selected[-1]['scene'],
            'net':sum(values),'session_median':statistics.median(values),
            'acquisition_count':sum(row['all_count'] for row in selected)})
    return {'width_scenes':width,'all_window_count':all_count,'complete_window_count':len(complete),
        'unknown_window_count':all_count-len(complete),
        'negative_net_count':sum(w['net']<0 for w in complete),
        'negative_net_share_complete':sum(w['net']<0 for w in complete)/len(complete) if complete else None,
        'negative_median_count':sum(w['session_median']<0 for w in complete),
        'negative_median_share_complete':sum(w['session_median']<0 for w in complete)/len(complete) if complete else None,
        'no_acquisition_complete_count':sum(w['acquisition_count']==0 for w in complete),
        'worst_net_window':min(complete,key=lambda w:(w['net'],w['start_scene'])) if complete else None,
        'worst_median_window':min(complete,key=lambda w:(w['session_median'],w['start_scene'])) if complete else None,
        'median_of_complete_window_net':statistics.median(w['net'] for w in complete) if complete else None,
        'overlapping_windows_are_independent':False}


def independent_risk(group: dict) -> dict:
    """
    機能: sessions.rowsだけの別集計で保存済みcompact_riskの全計量を再構成する。
    引数: group(dict)はmetrics173の一群。
    返り値: dictはSourceの版名/説明notes以外のcompact要約。
    """
    rows=sorted(group['sessions']['rows'],key=lambda r:(date.fromisoformat(r['scene'][:10]),r['scene']))
    total=sum(r['all_count'] for r in rows);unknown=sum(r['unknown_count'] for r in rows)
    prefix=next((i for i,r in enumerate(rows) if r['unknown_count']),len(rows))
    known_path=independent_path(rows,unknown==0)
    exact_path=known_path if unknown==0 else None
    active=sum(r['all_count']>0 for r in rows);counts=sorted((r['all_count'] for r in rows),reverse=True)
    anchor=date(1970,1,5);by_block=defaultdict(list)
    for row in rows:
        day=date.fromisoformat(row['scene'][:10]);index=(day-anchor).days//14
        by_block[index].append(row)
    blocks=[]
    for index,selected in sorted(by_block.items()):
        start=anchor+timedelta(days=14*index)
        participating=sum(r['all_count']>0 for r in selected)
        blocks.append({'block_start':start.isoformat(),'block_end':(start+timedelta(days=13)).isoformat(),
            'eligible_scenes':len(selected),'participating_scenes':participating,
            'participating_fraction':participating/len(selected),
            'acquisition_count':sum(r['all_count'] for r in selected),'unknown_count':sum(r['unknown_count'] for r in selected),
            'known_net':sum(r['known_net'] for r in selected)})
    active_blocks=sum(b['acquisition_count']>0 for b in blocks);profit=group['trades']['known_profit']
    support={'eligible_scene_count':len(rows),'acquisition_count':total,'unknown_count':unknown,
        'participating_scene_count':active,'zero_scene_count':len(rows)-active,
        'participating_fraction':active/len(rows) if rows else None,
        'acquisitions_per_scene':total/len(rows) if rows else None,
        'phase_diagnostic_goal_met':bool(rows and active*2>=len(rows) and total*2>=len(rows)),
        'goal_is_hard_adoption_rule':False,'acquisition_top1_scene_share':counts[0]/total if total else None,
        'acquisition_top3_scene_share':sum(counts[:3])/total if total else None,
        'calendar_block_days':14,'calendar_anchor':anchor.isoformat(),'eligible_calendar_blocks':len(blocks),
        'active_calendar_blocks':active_blocks,'active_block_fraction':active_blocks/len(blocks) if blocks else None,
        'minimum_participating_fraction_per_block':min((b['participating_fraction'] for b in blocks),default=None),'blocks':blocks}
    return {'calendar_dates_available':True,'exact_path':exact_path,'known_contribution':known_path,
        'complete_prefix':{'scene_count':prefix,'first_unknown_scene':rows[prefix]['scene'] if prefix<len(rows) else None,
            'path':independent_path(rows[:prefix],True)},
        'windows':{str(w):independent_window(rows,w) for w in (5,10)},'support':support,
        'known_drawdown_to_known_profit':known_path['max_drawdown_amount']/profit if profit>0 else None,
        'exact_drawdown_to_known_profit':None if exact_path is None or profit<=0 else exact_path['max_drawdown_amount']/profit}


def compare(expected: object, actual: object, where: str, counters: dict) -> None:
    """
    機能: 再帰的に全計量を照合し、浮動小数の集計順だけ許容する。
    引数: expected/actual(object)、where(str)、counters(dict)は照合件数。
    返り値: None。不一致では例外。
    """
    if isinstance(expected,dict):
        assert set(expected)==set(actual),(where,'key',set(expected)^set(actual))
        for key,value in expected.items():compare(value,actual[key],where+'/'+key,counters)
    elif isinstance(expected,list):
        assert len(expected)==len(actual),(where,'length')
        for index,(a,b) in enumerate(zip(expected,actual)):compare(a,b,where+'/'+str(index),counters)
    elif type(expected) is float:
        assert isinstance(actual,(int,float)) and math.isclose(expected,actual,rel_tol=1e-12,abs_tol=1e-8),(where,expected,actual)
        counters['scalar']+=1
    else:
        assert expected==actual,(where,expected,actual)
        counters['scalar']+=1


class OnlyPeriod(dict):
    """
    機能: 指定期間以外の金融参照を例外で検出する辞書。
    引数: dictの通常初期値を受け、許可期間を一つだけ保存する。
    返り値: OnlyPeriodのインスタンス。
    """
    def __getitem__(self,key: object) -> object:
        """
        機能: 存在しない他期間への参照を明示的に拒否する。
        引数: key(object)は期間。
        返り値: objectは許可された期間の値。
        """
        if key not in self:raise AssertionError('選択期間以外を参照: '+str(key))
        return super().__getitem__(key)


def main() -> None:
    """
    機能: 単独/六局面156政策の全期間を独立照合し、選択・圧縮・静観を検査する。
    引数: なし。
    返り値: None。検査結果だけを担当workへ保存し、凍結Sourceへ書き込まない。
    """
    paths=[SOURCE/'単独.json.gz',SOURCE/'六局面.json.gz',SOURCE/'単独短表.json',SOURCE/'帯短表.json',
        SOURCE/'数量段階を進める.py',ROOT/'work/175経路と支持の評価/path175.py']
    before=[fingerprint(p) for p in paths]
    documents={name:read(SOURCE/(name+'.json.gz')) for name in ('単独','六局面')}
    for document in documents.values():
        for relative,digest in document['Sourceと出生'].items():
            assert fingerprint(ROOT/relative)['sha256']==digest,relative
    sys.path.insert(0,str(SOURCE))
    specification=importlib.util.spec_from_file_location('stage175_independent_review',SOURCE/'数量段階を進める.py')
    stage=importlib.util.module_from_spec(specification);specification.loader.exec_module(stage)
    counts={'scalar':0,'group':0,'compact_key':0,'period_guard':0,'all_wait_rejected':0,'shortlist':0}
    known_modes={'exact':0,'unknown':0};ids={};details=[]
    for name,document in documents.items():
        rows=document['rows'];ids[name]=len(rows)
        for row in rows:
            assert row['max_reserved']<=1
            for period,groups in row['periods'].items():
                for field,group in groups.items():
                    saved=row['paths'][period][field]
                    expected=independent_risk(group)
                    actual={k:v for k,v in saved.items() if k not in ('version','notes')}
                    compare(expected,actual,row['id']+'/'+period+'/'+field,counts)
                    full=stage.RISK.path_summary(group)
                    compact=stage.compact_risk(full)
                    assert compact==saved,(row['id'],period,field,'Root圧縮と保存値')
                    assert stage.RISK.candidate_key(group,full,field)==stage.RISK.candidate_key(group,saved,field)
                    counts['group']+=1;counts['compact_key']+=1
                    known_modes['exact' if saved['exact_path'] is not None else 'unknown']+=1
        routes=('全期','前48')
        short=read(SOURCE/('単独短表.json' if name=='単独' else '帯短表.json'))['選択']
        for route in routes:
            for field in ('DAY','PRE','POST'):
                families=('HT','HB','HR','HM','LC','RL') if name=='単独' else (None,)
                for family in families:
                    subset=[r for r in rows if r['policy']['route']==route and r['policy']['band']==field
                            and (family is None or r['policy']['family']==family)]
                    maximum=2 if family is not None else 8
                    original=stage.band_rank(subset,route,field,maximum)
                    wanted=short[route][field][family] if family is not None else short[route][field]
                    assert [r['id'] for r in original]==[r['id'] for r in wanted],(name,route,field,family,'短表')
                    counts['shortlist']+=1
                    guarded=[]
                    for row in subset:
                        copied={**row,'periods':OnlyPeriod({route:row['periods'][route]}),
                            'paths':OnlyPeriod({route:row['paths'][route]})}
                        guarded.append(copied)
                    selected=stage.band_rank(guarded,route,field,maximum)
                    assert [r['id'] for r in selected]==[r['id'] for r in original]
                    counts['period_guard']+=1
                    if subset:
                        zero=copy.deepcopy(subset[0]);zero['id']='全静観人工'
                        for p in zero['periods']:
                            g=zero['periods'][p][field]
                            g['trades']['all_count']=0
                        assert stage.band_rank([zero],route,field,maximum)==[]
                        assert [r['id'] for r in stage.band_rank([zero,*subset],route,field,maximum)]==[r['id'] for r in original]
                        counts['all_wait_rejected']+=1
                    details.append({'段階':name,'期間':route,'帯':field,'family':family,'入力政策':len(subset),
                        '選択':[r['id'] for r in original]})
    assert before==[fingerprint(p) for p in paths]
    result={'成功':True,'対象':ids,'検査':counts,'金融完全性':known_modes,'不一致':0,
        'Sourceと入力不変':True,'入力':before,'選択照合':details,
        '検査範囲':'保存済みmetrics173のsessions.rowsから経路・支持を別一覧法で再計算。売買取得や金融配列自体の独立再生は本票の範囲外。',
        '注意':['前48のみ参照は数量段階band_rankをguard辞書で実行して確認。候補辞書の出生研究過程まで未見とする検査ではない。',
                'compact_riskは配列・完全区間詳細だけ省略し、candidate_keyの返り値は全群で同じ。',
                '静観だけの入力は空短表。静観を混ぜても実候補の選択不変。']}
    (HERE/'独立検査結果.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k in ('成功','対象','検査','金融完全性','不一致','Sourceと入力不変')},ensure_ascii=False))


if __name__=='__main__':
    main()
