"""175旧固定二案の正式148射影packを、台帳から独立金融へ照合する。"""
from pathlib import Path
import importlib.util
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 175固定二案の取得台帳・金融・完全経路を独立検算する。
    引数: なし。追加7の175評価は実行しない。
    返り値: None。担当workへ結果を保存し、固定結果や戦略Sourceは変更しない。
    """
    source=ROOT/'work/176固定結果の独立検査/固定金融を点検する.py'
    spec=importlib.util.spec_from_file_location('financial176_for175',source);Q=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=Q;spec.loader.exec_module(Q);V=Q.V
    path=ROOT/'work/175固定少数の再現/旧73の全取得175.json.gz'
    files=[path,ROOT/'work/175固定少数の再現/完了.json',source,Path(__file__)]
    before=[V.fingerprint(p) for p in files];document=V.read(path)
    assert document['成功'] and document['場数']==73
    assert V.read(files[1])['175追加7未実行']
    sys.path.insert(0,str(ROOT/'work/173両中央値と単一建玉'));import 基盤173 as B
    context=B.load_context(False);eligible,hours=Q.eligibility(context,np.ones(len(context.scenes),bool))
    counters={'scalar':0,'financial_group':0,'period_group':0,'full_risk':0,'shared_ledger':0};summaries={}
    assert eligible==document['対象場'] and context.sessions==document['場順']
    V.compare(hours,document['対象時間'],'対象時間',counters)
    for row in document['rows']:
        Q.check_shared_ledger(context,row,row['id'],counters)
        groups=Q.F.financial_groups(row,eligible,hours)
        Q.check_groups(groups,row['financial'],row['paths'],row['id'],counters)
        periods=Q.check_periods(context,row,row['id'],counters)
        summaries[row['id']]={period:{band:Q.brief(group) for band,group in values.items()} for period,values in periods.items()}
    assert len(summaries)==2 and before==[V.fingerprint(p) for p in files]
    result={'成功':True,'対象候補':list(summaries),'検査':counters,'不一致':0,'Sourceと入力不変':True,
        '175追加7未実行':True,'入力':before,'要約':summaries,
        '範囲':'正式148射影で再生成された175旧固定二案packの添字→共用数値表、独立台帳金融と経路を照合。純出生・engine自体の独立実装ではない。'}
    (HERE/'固定二案の金融独立結果.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({k:result[k] for k in ('成功','対象候補','検査','不一致','Sourceと入力不変','175追加7未実行')},ensure_ascii=False))


if __name__=='__main__':main()
