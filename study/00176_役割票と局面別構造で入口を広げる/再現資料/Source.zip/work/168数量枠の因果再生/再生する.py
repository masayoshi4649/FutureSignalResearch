"""固定二案を無制限と片側10枚で再生し、全場・取得参照・損益を保存する。"""
from pathlib import Path
import json
import sys
import numpy as np
import engine168

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00168_固定複合入口を片側十枚の数量枠で再生する'
BOOK_SHA='b8acd5daf5050b16a0d36c74d207db8e60d77a817b6fb62964f08b416c8b1f89'
sys.path.insert(0,str(ROOT/'work/167固定入口の別期間'))
import 適用基盤167 as BASE
from 共通163 import read,save,sha
from 評価基盤 import Selection


def capture_descriptors(context: object) -> list:
    """
    機能: captureの価格・金融を除き、取得又は失効の時計だけを純engineへ渡す。
    引数: context(GenericContext)。
    返り値: list[dict]はstatus/finish_keyと、取得時だけcase/fill_key。
    """
    result=[]
    for event,row in enumerate(context.capture_rows):
        record={'status':row['status'],'finish_key':tuple(context.end_keys[event])}
        if row['status']=='filled':
            record['case']=int(context.event_cases[event]);assert record['case']>=0
            record['fill_key']=BASE.quote_key(row['q1'])
        result.append(record)
    return result


def replay_candidate(context: object,birth: dict,candidate: dict,capacity: int|None) -> tuple:
    """
    機能: 固定出生を数量engineへ渡し、取得属性を既存統計APIへ接続する。
    引数: context(GenericContext)、birth(dict)、candidate(dict)、capacity(int|None)。
    返り値: tupleはSelection/origins/widths/tiers/engine全結果。
    """
    hi=context.table.horizons.index(candidate['horizon']);width_map={int(w):i for i,w in enumerate(context.table.widths)}
    def exit_lookup(case: int,side: int,width: int) -> float|None:
        """
        機能: 取得後の決済イベントを時計だけでキューへ置くための情報を返す。
        引数: case/side/width(int)は取得済み建玉の識別。
        返り値: floatは既知exit秒、Noneは未知。損益・先着labelを参照しない。
        """
        wi=width_map[width]
        if not context.arrays['known'][case,side,wi,hi]:return None
        return float(context.arrays['exit_time'][case,side,wi,hi])
    result=engine168.replay(context.event_keys,context.event_scenes,
        np.array([s['start'] for s in context.scenes]),np.array([s['end'] for s in context.scenes]),
        capture_descriptors(context),birth['core'],birth['branches'],birth['technical'],birth['tier'],
        int(candidate['momentum_width']),int(candidate['fade_width']),int(candidate['integration'][1:]),
        exit_lookup,capacity=capacity)
    records=result['records'];events=np.array([r['event'] for r in records],dtype=np.int32)
    selected=Selection(np.array([r['case'] for r in records],dtype=np.int32),
        np.array([r['side'] for r in records],dtype=np.int8),events,context.event_phases[events],np.zeros(len(records),dtype=bool))
    origins=np.array([r['origin'] for r in records],dtype=np.int8)
    widths=np.array([width_map[r['width']] for r in records],dtype=np.int8)
    tiers=np.array([r['tier'] for r in records],dtype=np.int8)
    return selected,origins,widths,tiers,result


def describe(context: object,birth: dict,candidate: dict,value: tuple) -> dict:
    """
    機能: 全場と前後/三帯/枝/売買を同一取得分母で集計する。
    引数: context(GenericContext)、birth/candidate(dict)、value(tuple)は再生返り値。
    返り値: dictは取得・数量診断・既知/未知・費用後利益損失。
    """
    selected,origins,widths,tiers,result=value;hi=context.table.horizons.index(candidate['horizon'])
    scene=context.case_scene[selected.cases];s=len(context.scenes)
    def stats(mask: np.ndarray|None=None,eligible: np.ndarray|None=None,hours: float|None=None) -> dict:
        """
        機能: 固定された取得部分集合を共通統計へ渡す。
        引数: mask/eligible(np.ndarray|None)、hours(float|None)。
        返り値: dictは共通金融統計。
        """
        return BASE.statistics(context,selected,widths,hi,mask,eligible,hours)
    periods={'全期':stats()}
    if s==73:
        for name,eligible in [('前48場',np.arange(s)<48),('後25場',np.arange(s)>=48)]:
            periods[name]=stats(eligible[scene],eligible)
    bands={}
    for clock,phases in [('q0',selected.phases),('q1',context.case_phases[selected.cases])]:
        bands[clock]={}
        for band,name in enumerate(('DAY','NY前','NY後')):
            eligible=context.hours[:,band]>0
            bands[clock][name]=stats(phases==band,eligible,float(context.hours[:,band].sum()))
    branches={'主順行':stats((origins==0)&(birth['branches'][selected.events]==0)),
        '主失速':stats((origins==0)&(birth['branches'][selected.events]==1)),
        '旧T':stats((origins==2)&(tiers==1)),'局所':stats((origins==2)&(tiers==2))}
    by_scene=[]
    for si,session in enumerate(context.sessions):
        eligible=np.arange(s)==si
        by_scene.append({'session':session,**stats(scene==si,eligible),'capacity':result['audits'][si]})
    return {'periods':periods,'timebands':bands,'branches':branches,
        'sides':{name:stats(selected.sides==side) for side,name in enumerate(('BUY','SELL'))},'scenes':by_scene,
        'quantity_rejected_core':sum(a['quantity_rejected_core'] for a in result['audits']),
        'quantity_rejected_technical':sum(a['quantity_rejected_technical'] for a in result['audits']),
        'peak_reserved_total':np.max([a['peak_reserved_total'] for a in result['audits']],axis=0).tolist(),
        'peak_held':np.max([a['peak_held'] for a in result['audits']],axis=0).tolist(),
        'peak_pending':np.max([a['peak_pending'] for a in result['audits']],axis=0).tolist()}


def run_context(context: object,candidates: list,output: Path) -> dict:
    """
    機能: 任意S場の二固定案を無制限同体確認後にcap10で再生する。
    引数: context(GenericContext)、candidates(list[dict])は168固定二案、output(Path)は未作成先。
    返り値: dictは集計報告。取得参照と数量予約監査も保存する。
    """
    assert not output.exists();output.mkdir(parents=True)
    reports=[];refs=[];controls=[];audits=[];bindings=[]
    for candidate in candidates:
        birth=BASE.births(context.features,candidate)
        baseline=BASE.selection(context,birth,candidate)
        unlimited=replay_candidate(context,birth,candidate,None)
        fields=[]
        for name,a,b in [('cases',baseline[0].cases,unlimited[0].cases),('sides',baseline[0].sides,unlimited[0].sides),
            ('events',baseline[0].events,unlimited[0].events),('phases',baseline[0].phases,unlimited[0].phases),
            ('origins',baseline[1],unlimited[1]),('widths',baseline[2],unlimited[2]),('tiers',baseline[3],unlimited[3])]:
            assert np.array_equal(a,b),(candidate['id'],name,a.shape,b.shape);fields.append(name)
        bindings.append({'id':candidate['id'],'取得':len(unlimited[0].cases),'全同体属性':fields,
            '比較先':'167 GenericContext selection。旧73では166全方向/取得/金融同体が別票で確認済み。'})
        capped=replay_candidate(context,birth,candidate,10)
        for value,rows,mode in [(unlimited,controls,'無制限'),(capped,refs,'cap10')]:
            selected,origins,widths,tiers,result=value
            rows.append({'id':candidate['id'],'cases':selected.cases.tolist(),'sides':selected.sides.tolist(),
                'events':selected.events.tolist(),'phases':selected.phases.tolist(),'widths':widths.tolist(),
                'origins':origins.tolist(),'tiers':tiers.tolist()})
            audits.append({'id':candidate['id'],'mode':mode,'audits':result['audits'],'requests':result['requests']})
        reports.append({'id':candidate['id'],'candidate':candidate,'無制限':describe(context,birth,candidate,unlimited),
            'cap10':describe(context,birth,candidate,capped)})
    save(output/'全取得参照.json',{'成功':True,'mode':'cap10','rows':refs})
    save(output/'無制限取得参照.json',{'成功':True,'rows':controls})
    save(output/'数量と要求の監査.json.gz',{'成功':True,'rows':audits})
    save(output/'無制限の取得同体.json',{'成功':True,'確認':bindings})
    report={'成功':True,'場数':len(context.scenes),'場順':context.sessions,'rows':reports,
        '注意':'未知金融は未確定。各要求1枚/片側10枚、実mini板や注文マッチングの再現ではない。'}
    save(output/'二案の数量比較.json',report)
    return report


# ----------------------------------------
def main() -> None:
    """
    機能: Source/人工を固定して旧73場だけを数量枠で再生する。
    引数: なし。追加7場はこのmainから開かない。
    返り値: None。旧73比較と停止前入力/Source指紋を保存する。
    """
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    setting=read(TRIAL/'条件.json');artificial=read(HERE/'人工検査結果.json')
    assert artificial['成功'] and artificial['engineSHA256']==sha(HERE/'engine168.py')
    assert artificial['検査SourceSHA256']==sha(HERE/'人工検査.py')
    paths=[Path(__file__),HERE/'engine168.py',HERE/'人工検査.py',HERE/'人工検査結果.json',
        ROOT/'work/167固定入口の別期間/適用基盤167.py',ROOT/'work/167固定入口の別期間/旧73の同体.json',TRIAL/'条件.json']
    before={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    save(TRIAL/'検査/F0_旧七十三場の数量再生前.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと人工':before,'追加七場未読':True})
    old=BASE.Context165();context=BASE.GenericContext(old.features,old.table,old.capture_rows)
    report=run_context(context,setting['candidates'],HERE/'旧73比較')
    assert all(sha(ROOT/name)==digest for name,digest in before.items())
    save(HERE/'旧73比較/完了.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと人工':before,'追加七場未読':True,
        'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in (HERE/'旧73比較').iterdir() if p.is_file()}})
    print(json.dumps({'成功':True,'rows':[{'id':r['id'],'無制限':r['無制限']['periods']['全期'],
        'cap10':r['cap10']['periods']['全期'],'数量棄却':r['cap10']['quantity_rejected_core']+r['cap10']['quantity_rejected_technical'],
        'peak':r['cap10']['peak_reserved_total']} for r in report['rows']]},ensure_ascii=False))


if __name__=='__main__':main()
