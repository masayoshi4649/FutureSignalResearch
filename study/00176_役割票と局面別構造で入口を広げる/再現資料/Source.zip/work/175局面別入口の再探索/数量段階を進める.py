"""純短表から単独・六局面・Night・三帯をglobal1で段階再生する。"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from itertools import product
from datetime import datetime,timezone
import argparse
import copy
import json
import math
import sys
import numpy as np
from 基盤175 import ROOT,B,compose

sys.path.insert(0,str(ROOT/'work/175経路と支持の評価'))
import path175 as RISK

CTX=DIRS=CAPS=None


def initialize(birth_path: str, catalog_path: str) -> None:
    """
    機能: workerへ旧73入力と固定純方向を一度だけ接続する。
    引数: birth_path/catalog_path(str)は金融前固定済みの出生/辞書。
    返り値: None。追加7を読まない。
    """
    global CTX,DIRS,CAPS
    CTX=B.load_context(False);CAPS=B.captures(CTX)
    rules=B.P.read(Path(catalog_path))['rules']
    with np.load(birth_path,allow_pickle=False) as source:
        matrix=source['directions'];assert np.array_equal(source['phases'],CTX.event_phases)
        DIRS={r['id']+'/'+o:(matrix[i] if o=='NORMAL' else -matrix[i]) for i,r in enumerate(rules) for o in ('NORMAL','REVERSE')}


def compact_risk(risk: dict) -> dict:
    """
    機能: 順位に必要な経路要約を残し、全件転記の重複配列だけを省く。
    引数: risk(dict)はpath_summaryの全診断。
    返り値: dict。固定少数案では全診断を別に再生成する。
    """
    result=copy.deepcopy(risk);result.pop('complete_runs',None);result.pop('scene_order',None)
    for name in ('exact_path','known_contribution'):
        if result[name] is not None:
            for key in ('cumulative','underwater_episodes'):result[name].pop(key,None)
    for key in ('cumulative','underwater_episodes'):result['complete_prefix']['path'].pop(key,None)
    for value in result['windows'].values():value.pop('windows',None)
    return result


def evaluate(policy: dict) -> dict:
    """
    機能: 六局面の固定構成をglobal1で再生し、三期間の金融と経路を評価する。
    引数: policy(dict)はid/route/band/optionsを持つ。
    返り値: dictは全取得数・占有監査・期間別group/paths。旧Tを追加しない。
    """
    birth,mw,fw,hi,_,conflict=compose(CTX.event_phases,policy['options'],DIRS,list(CTX.table.horizons))
    value=B.replay(CTX,birth,mw,fw,hi,False,CAPS)
    scene=CTX.case_scene[value[0].cases];periods={};paths={}
    labels=CTX.arrays['label'][value[0].cases,value[0].sides,value[2],value[3]]
    for name,eligible in [('全期',np.ones(len(CTX.scenes),bool)),('前48',np.arange(len(CTX.scenes))<48),('後25',np.arange(len(CTX.scenes))>=48)]:
        metric=B.financial(CTX,value,eligible[scene],eligible);groups={**metric['phases_diagnostic'],'NIGHT':metric['session_groups_required']['NIGHT']}
        fields=('DAY','PRE','POST','NIGHT') if policy['band']=='JOINT' else (policy['band'],)
        periods[name]={};paths[name]={}
        for field in fields:
            group=groups[field]
            phase_rows=value[0].phases>0 if field=='NIGHT' else value[0].phases==('DAY','PRE','POST').index(field)
            resolved=eligible[scene]&phase_rows&((labels==1)|(labels==-1))
            scene_counts=np.bincount(scene[resolved],minlength=len(CTX.scenes))
            group['resolved_scene_count']=int((scene_counts>0).sum())
            group['max_resolved_scene_count']=int(scene_counts.max())
            risk=RISK.path_summary(group)
            group.pop('origins',None);group.pop('concentration',None)
            periods[name][field]=group;paths[name][field]=compact_risk(risk)
    return {'id':policy['id'],'policy':policy,'periods':periods,'paths':paths,'count':len(value[0].cases),
        'max_reserved':max((a['peak_global_reserved'] for a in value[-1]['audits']),default=0),
        'conflict_q0':int(conflict.sum()),'held_rejected':sum(a['skipped_held_core'] for a in value[-1]['audits'])}


def band_rank(rows: list, route: str, field: str, maximum: int=8) -> list:
    """
    機能: 共同条件・支持・経路・率の別枠で候補を最大8へ絞る。
    引数: rows(list[dict])、route/field(str)、maximum(int)。
    返り値: list[dict]は元の結果行。0取得だけなら空。
    """
    candidates=[r for r in rows if r['periods'][route][field]['trades']['all_count']]
    out=[];seen=set()
    for view in ('共同と経路','支持','経路','率'):
        options=sorted(candidates,key=lambda r:r['id'])
        def key(row: dict) -> tuple:
            """
            機能: 一期間だけの群から固定の観点順位を返す。
            引数: row(dict)。
            返り値: tupleは昇順。
            """
            g=row['periods'][route][field];risk=row['paths'][route][field];s=risk['support'];t=g['trades']
            general=RISK.candidate_key(g,risk,field)
            if view=='共同と経路':return general
            if view=='支持':return (-s['participating_scene_count'],-s['active_calendar_blocks'],-t['all_count'],general)
            if view=='経路':
                windows=[w for w in risk['windows'].values() if w['complete_window_count']]
                return (-int(g['decision']['status']=='適合'),-int(s['phase_diagnostic_goal_met']),
                    max((w['negative_net_share_complete'] for w in windows),default=math.inf),general)
            fa=t['IFD_FIRSTFANC'];n=fa['reached_count'];p=fa['first_f_rate_reached'] or 0
            return (-int(n>=12 and s['participating_scene_count']>=6),-p,-n,general)
        options.sort(key=key)
        taken=0
        for row in options:
            if row['id'] in seen:continue
            out.append(row);seen.add(row['id']);taken+=1
            if taken==(1 if maximum==2 else 2) or len(out)==maximum:break
        if len(out)==maximum:break
    return out


def run_stage(folder: Path, trial: int, name: str, policies: list, birth: Path, catalog: Path, workers: int) -> list:
    """
    機能: 政策群とSourceを先に保存してから旧73だけを並列再生する。
    引数: folder(Path)、trial(int)、name(str)、policies(list)、birth/catalog(Path)、workers(int)。
    返り値: list[dict]は当該段階の新正本。
    """
    target=folder/(name+'.json.gz');assert not target.exists()
    trial_dir=next((ROOT/'study').glob(f'{trial:05}_*'));(trial_dir/'検査').mkdir(exist_ok=True)
    sources=[Path(__file__),Path(__file__).parent/'基盤175.py',ROOT/'work/175経路と支持の評価/path175.py',birth,catalog]
    before={p.relative_to(ROOT).as_posix():B.P.sha(p) for p in sources}
    B.P.save(trial_dir/'検査'/('F2_'+name+'.json'),{'成功':True,'UTC':datetime.now(timezone.utc).isoformat(),'Sourceと出生':before,'policies':policies,'追加7未読':True})
    rows=[]
    with ProcessPoolExecutor(max_workers=workers,initializer=initialize,initargs=(str(birth),str(catalog))) as executor:
        for row in executor.map(evaluate,policies,chunksize=4):
            rows.append(row)
            if len(rows)%100==0:print(json.dumps({'段階':name,'再生':len(rows),'全数':len(policies)},ensure_ascii=False),flush=True)
    assert all(B.P.sha(ROOT/p)==v for p,v in before.items())
    B.P.save(target,{'成功':True,'rows':rows,'Sourceと出生':before})
    return rows


def main() -> None:
    """
    機能: 純短表から単独・局面組合せ・Night・Jointの指定一段を進める。
    引数: --stage(str)、--trial(int)、--folder/--birth/--catalog(Path)、--workers(int)。
    返り値: None。段階ごとの短表と固定候補を保存する。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=('single','mix','night','joint'),required=True)
    parser.add_argument('--trial',type=int,default=175);parser.add_argument('--folder',type=Path,default=Path(__file__).parent)
    parser.add_argument('--birth',type=Path,required=True);parser.add_argument('--catalog',type=Path,required=True)
    parser.add_argument('--workers',type=int,default=4);args=parser.parse_args();folder=args.folder.resolve();policies=[]
    args.birth=args.birth.resolve();args.catalog=args.catalog.resolve()
    if args.stage=='single':
        short=B.P.read(folder/f'予備短表{args.trial}.json')['選択']
        for route,bands in short.items():
            for band,rules in bands.items():
                for i,r in enumerate(rules):policies.append({'id':f'{route}_{band}_S{i:03}','route':route,'band':band,'family':r['family'],'options':{band:[r]}})
        rows=run_stage(folder,args.trial,'単独',policies,args.birth,args.catalog,args.workers)
        chosen={route:{band:{} for band in ('DAY','PRE','POST')} for route in ('全期','前48')}
        for route,bands in chosen.items():
            for band,groups in bands.items():
                for family in ('HT','HB','HR','HM','LC','RL'):
                    subset=[r for r in rows if r['policy']['route']==route and r['policy']['band']==band and r['policy']['family']==family]
                    groups[family]=[r['policy'] for r in band_rank(subset,route,band,2)]
        B.P.save(folder/'単独短表.json',{'成功':True,'選択':chosen})
    elif args.stage=='mix':
        source=B.P.read(folder/'単独短表.json')['選択']
        for route,bands in source.items():
            for band,groups in bands.items():
                choices=[[None,*items] for items in groups.values()]
                for index,combination in enumerate(product(*choices)):
                    active=[p for p in combination if p is not None]
                    if not active:continue
                    rules=[p['options'][band][0] for p in active]
                    policies.append({'id':f'{route}_{band}_M{index:04}','route':route,'band':band,'options':{band:rules}})
        rows=run_stage(folder,args.trial,'六局面',policies,args.birth,args.catalog,args.workers)
        chosen={route:{band:[r['policy'] for r in band_rank([r for r in rows if r['policy']['route']==route and r['policy']['band']==band],route,band)] for band in ('DAY','PRE','POST')} for route in ('全期','前48')}
        B.P.save(folder/'帯短表.json',{'成功':True,'選択':chosen})
    elif args.stage=='night':
        source=B.P.read(folder/'帯短表.json')['選択']
        for route,bands in source.items():
            blank=lambda band:{'id':'空','options':{band:[]}}
            for index,(a,b) in enumerate(product(bands['PRE'] or [blank('PRE')],bands['POST'] or [blank('POST')])):
                policies.append({'id':f'{route}_N{index:03}','route':route,'band':'NIGHT','options':{**a['options'],**b['options']}})
        rows=run_stage(folder,args.trial,'Night接合',policies,args.birth,args.catalog,args.workers)
        chosen={route:{'DAY':source[route]['DAY'],'NIGHT':[r['policy'] for r in band_rank([r for r in rows if r['policy']['route']==route],route,'NIGHT')]} for route in ('全期','前48')}
        B.P.save(folder/'Night短表.json',{'成功':True,'選択':chosen})
    else:
        source=B.P.read(folder/'Night短表.json')['選択']
        for route,bands in source.items():
            for index,(a,b) in enumerate(product(bands['DAY'],bands['NIGHT'])):
                policies.append({'id':f'{route}_J{index:03}','route':route,'band':'JOINT','options':{**a['options'],**b['options']}})
        rows=run_stage(folder,args.trial,'三帯接合',policies,args.birth,args.catalog,args.workers);fixed={}
        for route in ('全期','前48'):
            matching=[r for r in rows if r['policy']['route']==route]
            def flags(row: dict) -> tuple:
                """
                機能: 既存必須・率・新小帯支持を別々に判定する。
                引数: row(dict)。
                返り値: tupleは両中央値と全場/両群70/両小帯支持。
                """
                groups=row['periods'][route];risks=row['paths'][route]
                median=all(groups[b]['decision']['status']=='適合' for b in ('DAY','NIGHT'))
                coverage=all(risks[b]['support']['zero_scene_count']==0 for b in ('DAY','NIGHT'))
                rate=all((groups[b]['trades']['IFD_FIRSTFANC']['first_f_rate_reached'] or 0)>=.7 and groups[b]['trades']['IFD_FIRSTFANC']['reached_count']>=12 and groups[b]['trades']['all_count']>=24 and groups[b]['resolved_scene_count']>=6 for b in ('DAY','NIGHT'))
                phase=all(risks[b]['support']['phase_diagnostic_goal_met'] for b in ('PRE','POST'))
                return median and coverage,rate,phase
            def key(row: dict) -> tuple:
                """
                機能: 支持目標と未知、最も悪い累計経路を固定順で比較する。
                引数: row(dict)。
                返り値: tupleは昇順。未知経路を完全DDと同一視しない。
                """
                groups=row['periods'][route];risks=row['paths'][route];fs=flags(row)
                keys=[RISK.candidate_key(groups[b],risks[b],b) for b in ('DAY','NIGHT')]
                zero=sum(risks[b]['support']['zero_scene_count'] for b in ('DAY','NIGHT'))
                return (-int(all(fs)),-int(fs[0]),zero,-int(fs[2]),-int(fs[1]),max(keys),row['id'])
            matching.sort(key=key);eligible=[r for r in matching if all(flags(r))]
            selected=eligible[:2] if eligible else matching[:2]
            fixed[route]={'主案':eligible[0]['id'] if eligible else None,'共同支持適合数':len(eligible),'参考候補':[r['id'] for r in selected],'candidates':[r['policy'] for r in selected]}
        B.P.save(folder/'旧73の固定選択.json',{'成功':True,'選択':fixed,'追加7当該候補金融未読':True})
        print(json.dumps({route:{k:v for k,v in val.items() if k!='candidates'} for route,val in fixed.items()},ensure_ascii=False))
    if args.stage!='joint':print(json.dumps({'成功':True,'段階':args.stage,'政策数':len(rows)},ensure_ascii=False))


if __name__=='__main__':
    main()
