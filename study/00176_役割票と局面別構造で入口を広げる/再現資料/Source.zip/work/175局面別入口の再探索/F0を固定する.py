"""175の局面別入口探索の条件とSourceを自然実行前に固定する。"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00175_局面別入口を累計経路と支持で探索する'


def ref(path: Path) -> dict:
    """
    機能: Source又は固定入力の物理指紋を返す。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 新出生/金融評価前に有限候補・選択期間・数量・費用・経路目標を固定する。
    引数: なし。
    返り値: None。条件.jsonは一度だけ作成する。
    """
    TRIAL.mkdir(parents=True,exist_ok=True);(TRIAL/'検査').mkdir(exist_ok=True)
    target=TRIAL/'条件.json';assert not target.exists()
    folders=['175局面別の純入口','175経路と支持の評価','175局面別入口の再探索']
    paths=[p for folder in folders for p in (ROOT/'work'/folder).glob('*.py')]
    paths+=[ROOT/'work/175局面別の純入口/候補辞書175.json']
    body={'試行':175,'GO':True,'確認日':'2026-11-16','UTC':datetime.now(timezone.utc).isoformat(),
        '仮説':'低ADX回復しかない入口と初期補完損失を改め、局面別の複合技術を広く探索し、累計経路と支持を同時に比較。',
        '候補':'HT/HB/HR/HM/LC/RL各48論理規則×ALL/EDGE=576。幾何200固定で出口幅非依存。自然金融前に全辞書とSourceを固定。',
        '旧対照':'173/174固定各4案を追加禁止のまま保持し同体再生。主/近傍/前48を交換しない。',
        '費用':'mini1枚/要求、1pt100円、税込片道38.5円、追加片道5pt滑り、実BBO spread。',
        '数量時計':'全買売保有＋pending一枠。原q0→別原行q1。未知は場末保持、同秒決済は秒末解放。NY09:30自動夏冬変換、新規はq0帯。',
        '出口':'既存IFD_FIRST。幅125/150/175/200/225/250/300/350/400/500/750/1000、期限H30/H60/H120/SESSION。未到達期限返済も含む。',
        '予備':'576×正逆2×12幅×4期限、三帯×全期/前48。全case最初q0を物理正準化し、逆向きは同q0の実BBO側で再評価。',
        '短表':'各route/帯/六群に支持先着・参加・利益損失・疎な支持の4枠。支持は取得12/FA6/取得場6/FA場4/未知20%以下/一場FA50%以下。各出生から幅期限派生2まで。',
        '組合せ':'global1単独後に各帯各群2案＋offを選び、最大3^6-1構成/帯を評価。旧T自動追加なし、LCを新主の一枝とする。反対方向同時は待機、同方向はID順の幅期限。',
        '段階選択':'共同条件・支持の広がり・経路・率を別枠で次段最大8。PRE×POSTのNight最大64、Day×Night最大64/route。各段のSourceと政策を金融前に別固定。',
        '必須と比較':'建玉/全Day/全Nightの両費用後中央値正、全場最低1取得、Day/Night双方の先着70%以上を主支持目標に維持。PRE/POSTの50%以上場＋平均.5取得/場は支持の新比較軸で、無条件発注や新しい硬い合格閾値にしない。',
        '安定性':'初期損失・DD・回復/水面下・5/10場窓収支と中央値・14日非重複暦ブロック支持を比較。硬いDD金額上限は置かず、中央値だけで安定採用としない。',
        '未知':'Cを0円に置かず、全件DDは全件既知群だけ。未知群は既知寄与/初回未知前/完全窓と明記。0取引場も残す。',
        '選択期間':'旧73全期発見と前48だけの段階選択を分離。追加7は各route最大2固定案だけ参考適用。旧73/追加7は既使用で未見ではない。',
        '出力':'MDと候補別フォルダのCSV。別手法をCSVへ混在させず、xlsxを生成しない。大きいscreen中間/Rawを重複保存しない。',
        'Source':[ref(p) for p in sorted(set(paths))]}
    target.write_text(json.dumps(body,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(ref(target),ensure_ascii=False))


if __name__=='__main__':
    main()
