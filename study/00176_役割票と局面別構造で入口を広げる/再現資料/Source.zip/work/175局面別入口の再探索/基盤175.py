"""175の複数局面入口を、既存の単一建玉・共用IFD金融へ接続する。"""
from pathlib import Path
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/173両中央値と単一建玉'))
import 基盤173 as B


def compose(phases: np.ndarray, options: dict, directions: dict, horizons: list) -> tuple:
    """
    機能: 各帯の最大6局面を、ID順優先・逆方向同時は待機として純合成する。
    引数: phases(np.ndarray[N])、options(dict[str,list[dict]])、directions(dict[str,np.ndarray[N]])、horizons(list[str])。
    返り値: tupleはbirth/二幅/event期限/component/競合。旧初参加Tを新案へ自動追加しない。
    """
    n=len(phases);core=np.zeros(n,np.int8);width=np.full(n,200,np.int16)
    hi=np.full(n,horizons.index('H60'),np.int8);component=np.full(n,-1,np.int16);conflict=np.zeros(n,bool)
    for phase,name in enumerate(('DAY','PRE','POST')):
        rules=sorted(options.get(name,[]),key=lambda r:r['id'])
        assert len(rules)<=6
        if not rules:continue
        stack=np.asarray([directions[r['birth_key']] for r in rules],dtype=np.int8)
        assert stack.shape==(len(rules),n) and np.isin(stack,(-1,0,1)).all()
        opposing=(stack==1).any(axis=0)&(stack==-1).any(axis=0)
        active=(stack!=0).any(axis=0)&~opposing
        choice=np.argmax(stack!=0,axis=0)
        mask=(phases==phase)&active
        core[mask]=stack[choice[mask],np.flatnonzero(mask)]
        component[mask]=choice[mask]
        conflict[phases==phase]=opposing[phases==phase]
        for index,rule in enumerate(rules):
            chosen=mask&(choice==index)
            assert rule['width']>0 and rule['horizon'] in horizons
            width[chosen]=rule['width'];hi[chosen]=horizons.index(rule['horizon'])
    birth={'core':core,'branches':np.where(core!=0,0,-1).astype(np.int8),
        'technical':np.zeros(n,np.int8),'tier':np.zeros(n,np.int8)}
    return birth,width,width.copy(),hi,component,conflict


def scene_ledger(context: object, value: tuple) -> dict:
    """
    機能: 実取得から未知Noneを保った最小金融台帳を作る。
    引数: context(GenericContext)、value(tuple)はB.replayの実取得。
    返り値: dictはnet/known/label/scene/phase/originとevent。
    """
    selected,origins,wi,hi,_,_=value
    key=(selected.cases,selected.sides,wi,hi);known=context.arrays['known'][key]
    return {'net':[float(v) if k else None for v,k in zip(context.arrays['net'][key],known,strict=True)],
        'known':known.tolist(),'label':context.arrays['label'][key].tolist(),
        'scene':[context.sessions[int(s)] for s in context.case_scene[selected.cases]],
        'phase':selected.phases.tolist(),'origin':origins.tolist(),'event':selected.events.tolist()}


def artificial() -> dict:
    """
    機能: 6局面の優先・逆向き待機・鏡像・prefixを自然入力なしで確認する。
    引数: なし。
    返り値: dictは人工確認票。
    """
    phases=np.array([0,0,1,1,2,2],np.int8)
    directions={'a':np.array([1,1,1,-1,1,0],np.int8),'b':np.array([1,-1,0,-1,0,-1],np.int8)}
    rules=[{'id':'a','birth_key':'a','width':150,'horizon':'H30'}, {'id':'b','birth_key':'b','width':300,'horizon':'H120'}]
    options={p:rules for p in ('DAY','PRE','POST')};hs=['H30','H60','H120','SESSION']
    out=compose(phases,options,directions,hs)
    assert out[0]['core'].tolist()==[1,0,1,-1,1,-1]
    assert out[1].tolist()==[150,200,150,150,150,300]
    assert not out[0]['technical'].any() and out[-1].tolist()==[False,True,False,False,False,False]
    mirror=compose(phases,options,{k:-v for k,v in directions.items()},hs)
    assert np.array_equal(mirror[0]['core'],-out[0]['core'])
    for end in range(1,len(phases)+1):
        short=compose(phases[:end],options,{k:v[:end] for k,v in directions.items()},hs)
        assert np.array_equal(short[0]['core'],out[0]['core'][:end])
    return {'成功':True,'自然入力未読':True,'同方向ID順':True,'逆方向待機':True,'鏡像とprefix':True,'旧T自動追加なし':True}


if __name__=='__main__':
    import json
    print(json.dumps(artificial(),ensure_ascii=False))
