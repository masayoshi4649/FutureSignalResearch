"""175純入口を当時特徴だけから生成し、金融を読む前に封印する。"""
from pathlib import Path
import argparse
import json
import numpy as np
from 基盤175 import ROOT,B

HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: F0のSource指紋を確認し、旧73の純出生と全方向の由来を固定する。
    引数: --f0(Path)は事前固定した条件票。
    返り値: None。NPZと金融未入力の確認票を保存する。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--f0',type=Path,required=True);args=parser.parse_args()
    f0=B.P.read(args.f0);assert f0['試行']==175 and f0['GO']
    for record in f0['Source']:
        assert B.P.sha(ROOT/record['path'])==record['sha256'],record['path']
    source=ROOT/'work/175局面別の純入口/rules175.py'
    builder=B.P.module(source,'birth175_pure')
    data=B.P.R168.BASE.data_module();features=data.load_feature_dataset()
    result=builder.build(features,np.asarray([s['start'] for s in features.scenes]),features.q0_timeband)
    rules=B.P.read(ROOT/'work/175局面別の純入口/候補辞書175.json')['rules']
    assert result['candidate_ids']==[r['id'] for r in rules]
    target=HERE/'純出生175.npz';assert not target.exists()
    np.savez_compressed(target,directions=result['directions'],phases=features.q0_timeband)
    B.P.save(target.with_suffix('.json'),{'成功':True,'金融未入力':True,'候補数':len(rules),'q0数':len(features.q0_meta),
        'F0SHA256':B.P.sha(args.f0),'出生SHA256':B.P.sha(target),'SourceSHA256':B.P.sha(source),
        'geometry':200,'ALL_EDGE既適用':True,'特徴':features.sources})
    print(json.dumps({'成功':True,'候補数':len(rules),'q0数':len(features.q0_meta),'出生SHA256':B.P.sha(target)},ensure_ascii=False))


if __name__=='__main__':
    main()
