"""新576出生を共用金融で予備評価し、global1単独再生へ小型短表を渡す。"""
from pathlib import Path
import argparse
import json
import time
import numpy as np
from 基盤175 import B,ROOT

HERE=Path(__file__).resolve().parent
FIELDS=('count','F','A','N','C','known','profit','loss','net','pf','scenes','resolved_scenes','max_fa_share','rate','per_hour','positive_rate')
PERIODS=('全期','前48')
BANDS=('DAY','PRE','POST')


def summarize(context: object, cases: np.ndarray, sides: np.ndarray, phases: np.ndarray) -> np.ndarray:
    """
    機能: 独立取得の全幅/全期限を一度に読み、三帯二期間の16指標へ集計する。
    引数: context(GenericContext)、cases/sides/phases(np.ndarray[N])は物理重複排除後。
    返り値: np.ndarray[3,2,W,H,16]。独立予備評価であり口座収支とは呼ばない。
    """
    nw=len(context.table.widths);nh=len(context.table.horizons)
    key=(cases[:,None,None],sides[:,None,None],np.arange(nw)[None,:,None],np.arange(nh)[None,None,:])
    labels=context.arrays['label'][key];known=context.arrays['known'][key];net=context.arrays['net'][key]
    scenes=context.case_scene[cases];out=np.full((3,2,nw,nh,len(FIELDS)),np.nan)
    for bi in range(3):
        for pi in range(2):
            eligible=(context.hours[:,bi]>0)&((np.arange(len(context.scenes))<48) if pi else True)
            mask=(phases==bi)&eligible[scenes]
            labs=labels[mask];valid=known[mask];money=net[mask];ss=scenes[mask];count=int(mask.sum())
            fa=(labs==1)|(labs==-1);f=(labs==1).sum(axis=0);a=(labs==-1).sum(axis=0)
            profit=np.where(valid,np.maximum(money,0),0).sum(axis=0)
            loss=np.where(valid,np.maximum(-money,0),0).sum(axis=0)
            if count:
                unique,first=np.unique(ss,return_index=True)
                per_scene=np.add.reduceat(fa.astype(np.int32),first,axis=0)
                reached=(per_scene>0).sum(axis=0);maximum=per_scene.max(axis=0)
                scenes_count=len(unique)
            else:
                reached=np.zeros((nw,nh));maximum=reached;scenes_count=0
            hours=float(context.hours[eligible,bi].sum())
            values={'count':count,'F':f,'A':a,'N':(labs==0).sum(axis=0),'C':(labs==2).sum(axis=0),
                'known':valid.sum(axis=0),'profit':profit,'loss':loss,'net':profit-loss,
                'pf':np.divide(profit,loss,out=np.full((nw,nh),np.nan),where=loss!=0),
                'scenes':scenes_count,'resolved_scenes':reached,
                'max_fa_share':np.divide(maximum,f+a,out=np.ones((nw,nh)),where=f+a!=0),
                'rate':np.divide(f,f+a,out=np.full((nw,nh),np.nan),where=f+a!=0),
                'per_hour':count/hours if hours else np.nan,
                'positive_rate':np.divide((valid&(money>0)).sum(axis=0),valid.sum(axis=0),out=np.full((nw,nh),np.nan),where=valid.sum(axis=0)!=0)}
            for fi,name in enumerate(FIELDS):out[bi,pi,:,:,fi]=values[name]
    return out


def physical(directions: np.ndarray, event_cases: np.ndarray, phases: np.ndarray) -> tuple:
    """
    機能: 同一caseの最初の純成立q0だけを選び、実側と帯を返す。
    引数: directions/event_cases/phases(np.ndarray[N])。
    返り値: tupleはcases/sides/phases。先に全場履歴で正準化する。
    """
    events=np.flatnonzero((directions!=0)&(event_cases>=0))
    if len(events):
        first=np.unique(event_cases[events],return_index=True)[1];events=events[np.sort(first)]
    return event_cases[events],np.where(directions[events]==1,0,1).astype(np.int8),phases[events]


def select(metrics: np.ndarray, rules: list, widths: list, horizons: list) -> dict:
    """
    機能: 同じ選択期間だけの支持から、各帯/六群最大4設定を純選択する。
    引数: metrics(np.ndarray[R,2,3,2,W,H,16])、rules(list)、widths/horizons(list)。
    返り値: dictは全期/前48の帯短表。中央値・DD・global1成績の達成は未判定。
    """
    from math import sqrt
    result={}
    for pi,period in enumerate(PERIODS):
        result[period]={}
        for bi,band in enumerate(BANDS):
            chosen=[]
            for family in ('HT','HB','HR','HM','LC','RL'):
                rows=[]
                for ri,rule in enumerate(rules):
                    if rule['group']!=family:continue
                    for oi in range(2):
                        for wi,width in enumerate(widths):
                            for hi,horizon in enumerate(horizons):
                                values=metrics[ri,oi,bi,pi,wi,hi];s=dict(zip(FIELDS,values.tolist(),strict=True))
                                support=(s['count']>=12 and s['F']+s['A']>=6 and s['scenes']>=6 and s['resolved_scenes']>=4
                                    and s['C']<=.2*s['count'] and s['max_fa_share']<=.5)
                                if not support:continue
                                n=s['F']+s['A'];p=s['F']/n;z=1.959963984540054
                                w=(p+z*z/(2*n)-z*sqrt(p*(1-p)/n+z*z/(4*n*n)))/(1+z*z/n)
                                orientation=('NORMAL','REVERSE')[oi];key=f"{rule['id']}/{orientation}"
                                identity=f"{rule['id']}_{orientation}_W{width}_{horizon}_{band}"
                                rows.append({'id':identity,'family':family,'rule_id':rule['id'],'rule_index':ri,'orientation':orientation,
                                    'birth_key':key,'width':int(width),'horizon':horizon,'mode':rule['mode'],
                                    'proxy':{k:v if np.isfinite(v) else None for k,v in s.items()},'wilson':w})
                seen=set();birth_counts={}
                for view in ('支持先着','参加','利益損失','疎な支持'):
                    options=sorted(rows,key=lambda r:r['id'])
                    if view=='支持先着':options.sort(key=lambda r:(r['wilson'],r['proxy']['resolved_scenes'],r['proxy']['scenes']),reverse=True)
                    elif view=='参加':options.sort(key=lambda r:(r['proxy']['scenes'],r['proxy']['count'],r['wilson']),reverse=True)
                    elif view=='利益損失':options.sort(key=lambda r:(r['proxy']['net']>0,r['proxy']['positive_rate'] or 0,r['wilson'],r['proxy']['scenes']),reverse=True)
                    else:options.sort(key=lambda r:(r['wilson'],r['proxy']['scenes'],r['proxy']['net']),reverse=True)
                    for row in options:
                        if row['id'] in seen or birth_counts.get(row['birth_key'],0)>=2:continue
                        chosen.append({**row,'selected_by':view});seen.add(row['id']);birth_counts[row['birth_key']]=birth_counts.get(row['birth_key'],0)+1
                        break
            result[period][band]=chosen
    return result


def main() -> None:
    """
    機能: F0と純出生を確認した後だけ旧73共用金融で予備評価する。
    引数: --f0(Path)、--birth(Path)、--catalog(Path)は固定済み入力。
    返り値: None。小型統計と短表をworkへ保存し、追加7金融は読まない。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--f0',type=Path,required=True)
    parser.add_argument('--birth',type=Path,required=True);parser.add_argument('--catalog',type=Path,required=True)
    args=parser.parse_args();f0=B.P.read(args.f0);assert f0['試行']==175 and f0['GO']
    for r in f0['Source']:
        assert B.P.sha(ROOT/r['path'])==r['sha256'],r['path']
    proof=B.P.read(args.birth.with_suffix('.json'));assert proof['金融未入力'] and B.P.sha(args.birth)==proof['出生SHA256']
    rules=B.P.read(args.catalog)['rules'];context=B.load_context(False)
    with np.load(args.birth,allow_pickle=False) as source:directions=source['directions'];assert np.array_equal(source['phases'],context.event_phases)
    assert directions.shape==(len(rules),len(context.event_cases))
    metrics=np.empty((len(rules),2,3,2,len(context.table.widths),len(context.table.horizons),len(FIELDS)))
    start=time.monotonic()
    for ri,direction in enumerate(directions):
        cases,sides,phases=physical(direction,context.event_cases,context.event_phases)
        for oi in range(2):metrics[ri,oi]=summarize(context,cases,sides if oi==0 else 1-sides,phases)
        if (ri+1)%48==0:print(json.dumps({'予備評価':ri+1,'全数':len(rules),'経過秒':round(time.monotonic()-start,1)},ensure_ascii=False),flush=True)
    target=HERE/'予備統計175.npz';assert not target.exists();np.savez_compressed(target,metrics=metrics)
    axis={'指標':FIELDS,'方向':['NORMAL','REVERSE'],'帯':BANDS,'期間':PERIODS,'幅':list(context.table.widths),'期限':list(context.table.horizons),'候補順':[r['id'] for r in rules]}
    B.P.save(HERE/'予備軸175.json',axis)
    selected=select(metrics,rules,list(context.table.widths),list(context.table.horizons))
    B.P.save(HERE/'予備短表175.json',{'成功':True,'選択':selected,'出生SHA256':B.P.sha(args.birth),'F0SHA256':B.P.sha(args.f0),
        '予備統計SHA256':B.P.sha(target),'経過秒':time.monotonic()-start,'注意':'独立一枚の代理選択。DD/両中央値/global1は次段。'})
    print(json.dumps({'成功':True,'短表':{p:{b:len(v) for b,v in bs.items()} for p,bs in selected.items()}},ensure_ascii=False))


if __name__=='__main__':
    main()
