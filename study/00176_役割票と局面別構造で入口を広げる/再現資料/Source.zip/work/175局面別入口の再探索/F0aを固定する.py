"""金融評価前の人工境界補強を、旧F0を保持して追補固定する。"""
from pathlib import Path
from datetime import datetime,timezone
import json
from F0を固定する import ROOT,TRIAL,ref


def main() -> None:
    """
    機能: 全件未知群の共同順位補強を自然金融評価前に記録する。
    引数: なし。
    返り値: None。旧F0と純出生を変更せずF0aを作る。
    """
    parent=TRIAL/'条件.json';body=json.loads(parent.read_text(encoding='utf-8'))
    assert not (ROOT/'work/175局面別入口の再探索/予備統計175.npz').exists()
    body['親F0']=ref(parent);body['追補UTC']=datetime.now(timezone.utc).isoformat()
    body['追補']='自然金融未実行。共同順位は既知決済が存在し既知net>0も必要とする人工境界補強。純入口と生成済み出生は不変。'
    paths=[ROOT/r['path'] for r in body['Source']]
    paths.append(Path(__file__).resolve())
    body['Source']=[ref(p) for p in sorted(set(paths))]
    target=TRIAL/'検査/F0a_順位の人工境界補強.json';assert not target.exists()
    target.write_text(json.dumps(body,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(ref(target),ensure_ascii=False))


if __name__=='__main__':
    main()
