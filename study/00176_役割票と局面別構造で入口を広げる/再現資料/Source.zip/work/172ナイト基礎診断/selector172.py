"""旧1460と新768の同形統計から、固定支持と順位でナイト短表を選ぶ純部品。"""
from collections import Counter
import math
import re

import numpy as np

VERSION = '172短表選択1'
Z95 = 1.959963984540054
SPEC = {
    'version': VERSION,
    'bands': ['PRE', 'POST'],
    'full_stream_order': ['WILSON95', 'FREQUENCY', 'STABILITY'],
    'each_full_stream_maximum': 5,
    'full_group_maximum_combined': 3,
    'front_maximum': 5,
    'front_group_maximum': 3,
    'maximum_per_band': 20,
    'stability': 'min(Wilson95前48,Wilson95後25)。到達0のWilson下限は0。支持条件を追加しない。',
    'full_ties': 'Wilson順位は頻度→到達数、頻度順位はWilson→安定、安定順位は全期Wilson→頻度。その後はsource/rule/mode/orient/width/Hで昇順。',
    'front_support': {'minimum_count': 25, 'minimum_resolved': 15, 'minimum_night_scenes': 6,
                      'maximum_unknown_fraction': .1, 'minimum_rate': .65, 'minimum_pf': 1.1},
    'front_ranking': '前48 Wilson95下限→前48頻度→前48到達数→固定識別順。全期順位とは独立に最大5を固定し、最後に重複を除く。',
    'zero_loss_pf': '利益>0かつ損失0はPF無限大として支持可。利益損失とも0は支持不可。',
    'duplicates': '全期3順位は既選択を飛ばして次へ進む。前48枠は独立選択後に全期と重複除去し、重複分を補充しない。',
    'shortfall': '支持・群上限を緩めず不足数を記録。独立一枚短表でありcap10採用結果ではない。'
}


def wilson_lower(f: float, a: float) -> float:
    """
    機能: 到達F/Aの二側95% Wilson下限を返す。
    引数: f/a(float)は順先着/逆先着の非負件数。
    返り値: floatは0〜1。到達0件は順位上の0とする。
    """
    n = f + a
    if n <= 0:
        return 0.
    p = f / n
    z2 = Z95 * Z95
    return (p + z2 / (2*n) - Z95 * math.sqrt(p*(1-p)/n + z2/(4*n*n))) / (1 + z2/n)


def support_mask(values: np.ndarray, fields: dict, support: dict, concentration: bool) -> np.ndarray:
    """
    機能: 件数・到達・参加Night場・未知・率・PFの固定支持を評価する。
    引数: values(np.ndarray[...,指標])、fields(dict[str,int])、support(dict)、concentration(bool)。
    返り値: np.ndarray[bool]は支持適格。全期だけ指定集中率も用いる。
    """
    count = values[..., fields['count']]
    resolved = values[..., fields['F']] + values[..., fields['A']]
    profit, loss = values[..., fields['profit']], values[..., fields['loss']]
    result = (count >= support['minimum_count']) & (resolved >= support['minimum_resolved']) & \
        (values[..., fields['scenes']] >= support['minimum_night_scenes']) & \
        (values[..., fields['C']] <= support['maximum_unknown_fraction'] * count) & \
        (values[..., fields['rate']] >= support['minimum_rate']) & \
        (profit > 0) & (profit >= support['minimum_pf'] * loss)
    if concentration:
        result &= values[..., fields['max_scene_share']] <= support['maximum_scene_share']
    return result


def validate_pool(pool: dict) -> tuple:
    """
    機能: 辞書・統計軸・配列を同一の規則順へ束縛して検査する。
    引数: pool(dict)はsource/axes/metricsと、任意dictionary又はgroupsを持つ。
    返り値: tupleは軸、指標位置、群辞書、規則順。自然指標を加工しない。
    """
    assert isinstance(pool['source'], str) and pool['source']
    axes, metrics = pool['axes'], pool['metrics']
    keys = ('規則順', '発火方式', '方向', '幅', '時計', '帯', '期間', '指標')
    assert metrics.shape == tuple(len(axes[key]) for key in keys)
    assert axes['期間'] == ['全期', '前48場', '後25場']
    assert 'PRE' in axes['帯'] and 'POST' in axes['帯']
    ids = axes['規則順']
    assert len(ids) == len(set(ids))
    required = ('count', 'F', 'A', 'N', 'C', 'rate', 'profit', 'loss', 'net', 'pf',
                'scenes', 'per_hour', 'max_scene_share')
    fields = {name: i for i, name in enumerate(axes['指標'])}
    assert all(name in fields for name in required)
    if 'dictionary' in pool:
        dictionary = pool['dictionary']
        if isinstance(dictionary, dict):
            dictionary = dictionary['候補'] if '候補' in dictionary else dictionary['rules']
        groups = {row['id']: row['group'] for row in dictionary}
        assert set(ids) <= set(groups)
    elif 'groups' in pool:
        groups = pool['groups']
        if isinstance(groups, list):
            assert len(groups) == len(ids)
            groups = dict(zip(ids, groups, strict=True))
        assert set(ids) <= set(groups)
    else:
        groups = {rule: re.match(r'[A-Za-z]+', rule).group() for rule in ids}
    assert all(isinstance(groups[rule], str) and groups[rule] for rule in ids)
    return axes, fields, groups, ids


def public_row(record: dict, reason: str) -> dict:
    """
    機能: 選択政策の識別と前後指標を有限JSONへ写す。
    引数: record(dict)は内部候補、reason(str)は選択順位名。
    返り値: dictはSource/規則/群/発火/方向/幅/期限/位置/前後成績を持つ。
    """
    fields, values = record['fields'], record['values']
    periods = {period: {field: float(row[index]) if np.isfinite(row[index]) else None
                        for field, index in fields.items()}
               for period, row in zip(('全期', '前48場', '後25場'), values, strict=True)}
    identity = record['identity']
    return {'key': record['policy_key'], 'policy_key': record['policy_key'], 'source': identity[0], 'rule': identity[1],
            'rule_index': record['position'][0],
            'group': record['group'], 'entry_mode': identity[2], 'orientation': identity[3],
            'width': identity[4], 'horizon': identity[5], 'position': record['position'],
            'band': record['band'], 'selected_by': reason,
            'selection_reasons': [reason],
            'full_eligible': record['full_eligible'], 'front_eligible': record['front_eligible'],
            'wilson95_full': record['wilson'], 'wilson95_front': record['front_wilson'],
            'wilson95_back': record['back_wilson'], 'stability_score': record['stability'],
            'periods': periods}


def select_shortlist(pools: list, setting: dict) -> dict:
    """
    機能: OLD/NEW共通配列を併合し、固定支持と3順位＋前半枠で各帯最大20を選ぶ。
    引数: pools(list[dict])はsource/axes/metricsと任意dictionary/groups、setting(dict)は172条件。
    返り値: dictはPRE/POSTの短表・支持母数・不足・群配分。入出力以外の副作用なし。
    """
    assert pools and len({p['source'] for p in pools}) == len(pools)
    support = setting['shortlist_support']
    results = {}
    for band in SPEC['bands']:
        records, pool_reports = [], []
        for pool in sorted(pools, key=lambda p: p['source']):
            axes, fields, groups, ids = validate_pool(pool)
            bi = axes['帯'].index(band)
            values = pool['metrics'][:, :, :, :, :, bi]
            full = support_mask(values[..., 0, :], fields, support, True)
            front = support_mask(values[..., 1, :], fields, SPEC['front_support'], False)
            pool_reports.append({'source': pool['source'], '政策数': int(full.size),
                                 '全期支持適格': int(full.sum()),
                                 '全期支持かつ70%以上': int((full & (values[..., 0, fields['rate']] >= .7)).sum()),
                                 '前48専用支持適格': int(front.sum())})
            for p in np.argwhere(full | front):
                ri, mi, oi, wi, hi = map(int, p)
                rows = values[tuple(p)]
                identity = (pool['source'], ids[ri], axes['発火方式'][mi], axes['方向'][oi],
                            int(axes['幅'][wi]), axes['時計'][hi])
                f = fields
                wl = [wilson_lower(row[f['F']], row[f['A']]) for row in rows]
                record = {'identity': identity,
                          'policy_key': '_'.join(map(str, (*identity[:4], 'W'+str(identity[4]), identity[5]))),
                          'position': p.tolist(), 'group': groups[ids[ri]], 'band': band,
                          'fields': fields, 'values': rows, 'wilson': wl[0],
                          'front_wilson': wl[1], 'back_wilson': wl[2], 'stability': min(wl[1:]),
                          'full_eligible': bool(full[tuple(p)]), 'front_eligible': bool(front[tuple(p)]),
                          'frequency': float(rows[0, f['per_hour']]),
                          'front_frequency': float(rows[1, f['per_hour']]),
                          'resolved': float(rows[0, f['F']] + rows[0, f['A']]),
                          'front_resolved': float(rows[1, f['F']] + rows[1, f['A']])}
                records.append(record)
        chosen, selected_keys, full_groups = [], set(), Counter()
        full_rows = [r for r in records if r['full_eligible']]
        rankings = {
            'WILSON95': lambda r: (-r['wilson'], -r['frequency'], -r['resolved'], r['identity']),
            'FREQUENCY': lambda r: (-r['frequency'], -r['wilson'], -r['stability'], r['identity']),
            'STABILITY': lambda r: (-r['stability'], -r['wilson'], -r['frequency'], r['identity'])}
        streams = {}
        for stream in SPEC['full_stream_order']:
            selected = []
            for row in sorted(full_rows, key=rankings[stream]):
                if row['policy_key'] in selected_keys or full_groups[row['group']] >= SPEC['full_group_maximum_combined']:
                    continue
                selected_keys.add(row['policy_key'])
                full_groups[row['group']] += 1
                public = public_row(row, stream)
                selected.append(public['policy_key'])
                chosen.append(public)
                if len(selected) == SPEC['each_full_stream_maximum']:
                    break
            streams[stream] = selected
        front_rows = [r for r in records if r['front_eligible']]
        front_rows.sort(key=lambda r: (-r['front_wilson'], -r['front_frequency'], -r['front_resolved'], r['identity']))
        front_selected, front_groups, front_public = [], Counter(), []
        for row in front_rows:
            if front_groups[row['group']] >= SPEC['front_group_maximum']:
                continue
            front_groups[row['group']] += 1
            public = public_row(row, 'FRONT_ONLY_SELECTION')
            front_selected.append(public['policy_key'])
            front_public.append(public)
            if len(front_selected) == SPEC['front_maximum']:
                break
        front_added, front_duplicates = [], []
        for public in front_public:
            if public['policy_key'] in selected_keys:
                front_duplicates.append(public['policy_key'])
                duplicate = next(row for row in chosen if row['policy_key'] == public['policy_key'])
                duplicate['前48独立選択にも採用'] = True
                duplicate['selection_reasons'].append('FRONT_ONLY_SELECTION')
                continue
            selected_keys.add(public['policy_key'])
            front_added.append(public['policy_key'])
            chosen.append(public)
        assert len(chosen) == len(selected_keys) <= SPEC['maximum_per_band']
        assert not full_groups or max(full_groups.values()) <= SPEC['full_group_maximum_combined']
        assert not front_groups or max(front_groups.values()) <= SPEC['front_group_maximum']
        results[band] = {'pool_reports': pool_reports, '全期順位別': streams,
                         '全期群配分': dict(full_groups), '前48専用選択': front_selected,
                         '前48独立選択rows': front_public, '前48から新規追加': front_added,
                         '前48と全期の重複': front_duplicates,
                         '前48枠群配分': dict(front_groups), '候補数': len(chosen),
                         '最大20からの不足数': SPEC['maximum_per_band'] - len(chosen), 'rows': chosen}
    return {'成功': True, 'version': VERSION, '仕様': SPEC, '全期支持': support, 'bands': results,
            '注意': '既使用旧73の独立一枚短表。前48選択にも後25を見た支持条件を加えない。NEW追加時は同じ純部品で併合し直す。'}


def stage2_rows(report: dict) -> dict:
    """
    機能: Root数量再生が使うPRE/POSTの政策配列だけを取り出す。
    引数: report(dict)はselect_shortlistの返り値。
    返り値: dictはPRE/POSTそれぞれのkey/source/rule_index/位置/幅/期限を含む最大20政策。
    """
    assert report['成功'] and report['version'] == VERSION
    return {band: report['bands'][band]['rows'] for band in SPEC['bands']}
