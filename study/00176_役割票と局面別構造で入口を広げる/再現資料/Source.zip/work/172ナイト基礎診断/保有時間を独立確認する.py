"""171保有時間を区間端点の走査で別実装し、和集合の計算を検算する。"""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import gzip
import hashlib
import json

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def read(path: Path) -> dict:
    """
    機能: 元JSON又はgzipを読む。
    引数: path(Path)は既存の入力。
    返り値: dictは復元済み内容。
    """
    body = path.read_bytes()
    return json.loads(gzip.decompress(body) if body[:2] == b'\x1f\x8b' else body)


def sweep(intervals: list, start: float, end: float) -> float:
    """
    機能: 開始終了端点の枚数変化を走査し、正保有時間を積分する。
    引数: intervals(list[tuple[float,float]])、start/end(float)はUTC秒。
    返り値: floatは指定範囲の保有和集合秒。
    """
    changes = {start: 0, end: 0}
    for a, b in intervals:
        a, b = max(a, start), min(b, end)
        if b > a:
            changes[a] = changes.get(a, 0) + 1
            changes[b] = changes.get(b, 0) - 1
    amount, total, prior = 0, 0., start
    for at, change in sorted(changes.items()):
        if amount:
            total += at - prior
        amount += change
        assert amount >= 0
        prior = at
    assert amount == 0
    return total


def main() -> None:
    """
    機能: 主/補完別の全保有時間セルを正本配列へ直接結んで照合する。
    引数: なし。既知・未知の区間を各帯へ別実装で配賦する。
    返り値: None。独立検査票だけを新規保存する。
    """
    expected = read(HERE / '171全80のナイト基礎診断.json')
    verified = 0
    for new, name, folder in ((False, '旧73既使用', '旧73固定候補'),
                              (True, '追加7既使用基準', '追加7固定候補')):
        base = ROOT / ('inputs/00167_追加七場の入口と共用価格索引' if new else
                       'inputs/00148_全1分入口母集団')
        population = base / '入口母集団' if new else base
        scenes = read(population / '固定取得入力.json.gz')['scenes']
        numeric = base / '自然数値表' if new else ROOT / 'inputs/00163_任意幅の共用価格索引/数値表'
        meta = read(numeric / '任意幅識別.json.gz')
        with np.load(numeric / '任意幅配列.npz', allow_pickle=False) as z:
            entry, exit_at, known, scene_ix = (z[k].copy() for k in ('entry_time', 'exit_time', 'known', 'session_index'))
        ref = read(ROOT / 'work/171三帯の入口切替' / folder / '全取得参照.json')['rows'][0]
        hi = meta['horizons'].index('H60')
        rows = []
        for i, case in enumerate(ref['cases']):
            side, wi, origin, tier = (ref[k][i] for k in ('sides', 'widths', 'origins', 'tiers'))
            width = meta['widths'][wi]
            source = '主順行' if origin == 0 and width == 200 else '主回復失敗' if origin == 0 else '旧T' if tier == 1 else '局所'
            k = bool(known[case, side, wi, hi])
            rows.append({'source': source, 'scene': int(scene_ix[case]), 'known': k, 'start': float(entry[case]),
                         'end': float(exit_at[case, side, wi, hi]) if k else None})
        for group in expected['期間'][name]['集計']:
            use = [r for r in rows if group == '全部' or group == '主入口' and r['source'].startswith('主') or
                   group == '補完' and not r['source'].startswith('主') or group == r['source']]
            for band_name in ('全帯', 'DAY', 'PRE', 'POST'):
                low, high, denominator = 0., 0., 0.
                for si, scene in enumerate(scenes):
                    day = scene['session'].endswith('_Day')
                    if band_name == 'DAY' and not day or band_name in ('PRE', 'POST') and day:
                        continue
                    start, end = scene['start'], scene['end'] - 300
                    split = datetime.fromisoformat(scene['session'][:10] + 'T09:30').replace(
                        tzinfo=ZoneInfo('America/New_York')).timestamp()
                    if band_name == 'PRE':
                        end = min(end, split)
                    if band_name == 'POST':
                        start = max(start, split)
                    denominator += end - start
                    subset = [r for r in use if r['scene'] == si]
                    low += sweep([(r['start'], r['end']) for r in subset if r['known']], start, end)
                    high += sweep([(r['start'], r['end'] if r['known'] else scene['end'] - 300) for r in subset], start, end)
                actual = {'既知保有和集合秒': low, '未知場末上限和集合秒': high, '対象ザラバ秒': denominator}
                want = expected['期間'][name]['集計'][group][band_name]['実時間保有']
                for key, value in actual.items():
                    assert value == want[key], (name, group, band_name, key)
                    verified += 1
    report = {'成功': True, '確認日': '2026-11-15', '独立手法': '区間端点の枚数変化を走査し、正保有の時間を積分。元の区間結合関数は呼ばない。',
              '全照合セル数': verified, '対象': '旧73/追加7×7帰属×全帯/DAY/PRE/POST×既知下限/未知場末上限/分母秒',
              'SourceSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              '対象診断SHA256': hashlib.sha256((HERE / '171全80のナイト基礎診断.json').read_bytes()).hexdigest()}
    (HERE / '171保有時間の独立確認.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, ensure_ascii=False))


if __name__ == '__main__':
    main()
