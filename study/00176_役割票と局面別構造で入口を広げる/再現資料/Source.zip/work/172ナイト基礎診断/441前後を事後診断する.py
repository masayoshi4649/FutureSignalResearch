"""旧73の完成済み441数量政策を再生せず、指定された前後帯別の支持だけを診断する。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / 'work/172ナイト入口探索/旧73数量比較.json.gz'
FIELDS = ('count', 'F', 'A', 'N', 'C', 'rate', 'known', 'unknown', 'profit', 'loss',
          'net', 'pf', 'all_net', 'scenes', 'eligible_scenes', 'per_hour', 'max_scene_share',
          'core_count', 'technical_count')


def eligible(value: dict) -> bool:
    """
    機能: 指定された各帯各期間のFA6・先着70%・PF1を判定する。
    引数: value(dict)は既存cap10の一金融集計。
    返り値: boolは適格旗。未知率・頻度・参加場の追加条件は課さない。
    """
    return value['F'] + value['A'] >= 6 and 10 * value['F'] >= 7 * (value['F'] + value['A']) and \
        value['profit'] > 0 and value['profit'] >= value['loss']


def materialize(row: dict, group: str) -> dict:
    """
    機能: 完成政策の識別と必要な全期/前後の金融値だけを取り出す。
    引数: row(dict)は441政策の一件、group(str)は全部又は主。
    返り値: dictは既存政策の値。新規出生・再生・選択順位を作らない。
    """
    policy = row['candidate']
    return {'id': row['id'], 'PRE': policy['PRE']['key'] if policy['PRE'] else '171固定',
            'POST': policy['POST']['key'] if policy['POST'] else '171固定',
            '集計帰属': group,
            'periods': {period: {band: {field: row['cap10']['periods'][period][band][group][field]
                                      for field in FIELDS}
                                 for band in ('PRE', 'POST', 'NIGHT')}
                        for period in ('全期', '前48場', '後25場')}}


def main() -> None:
    """
    機能: 完成441の両帯前後支持を数え、既存主案との事後比較だけを保存する。
    引数: なし。条件はRootから診断依頼されたFA6/PF1/p70を固定する。
    返り値: None。入力指紋、適格ID、代表既存政策、短い説明を保存する。
    """
    body = SOURCE.read_bytes()
    source = json.loads(gzip.decompress(body))
    assert source['成功'] and source['全政策デイ同体'] and len(source['rows']) == 441
    rows = source['rows']
    groups, passed = {}, {}
    for group in ('全部', '主'):
        use = [row for row in rows if all(eligible(row['cap10']['periods'][period][band][group])
               for period in ('前48場', '後25場') for band in ('PRE', 'POST'))]
        passed[group] = use
        groups[group] = {'該当政策数': len(use), 'ids': [r['id'] for r in use],
                         'PRE政策': sorted({r['candidate']['PRE']['key'] if r['candidate']['PRE'] else '171固定' for r in use}),
                         'POST政策': sorted({r['candidate']['POST']['key'] if r['candidate']['POST'] else '171固定' for r in use})}
    examples = [materialize(row, '全部') for row in rows if row['id'] in ('B05_01', 'B05_04', 'B05_11', 'B05_13')]
    report = {'成功': True, '確認日': '2026-11-15',
        '目的': '既存441の前後安定性の事後診断だけ。新案採用・主案交換・追加7適用はしない。',
        '条件': 'PRE/POST×前48/後25の全4セルでF+A>=6、F/(F+A)>=.7、PF>=1。損失0正利益はPF無限大。',
        '条件の限界': '各セルのC率・頻度・場支持に追加条件は課していない。該当は未見性能や将来保証を意味しない。',
        '結果': groups, '全部の適格政策': [materialize(row, '全部') for row in passed['全部']],
        '既存代表例': examples,
        '入力': {'path': SOURCE.relative_to(ROOT).as_posix(), 'bytes': len(body),
                 'sha256': hashlib.sha256(body).hexdigest()},
        'SourceSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    out = HERE / '441前後帯別の事後診断.json'
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    lines = ['# 441政策の両帯前後支持の事後診断', '',
        '2026-11-15。旧73の完成済み441数量政策に、PRE/POST×前48/後25の全4セルでFA6以上・先着70%以上・既知PF1以上という診断を当てた。新規出生・再生・主案交換・追加7適用は行っていない。', '',
        f"主と補完を含む全部では{groups['全部']['該当政策数']}政策、主入口だけでは{groups['主']['該当政策数']}政策が該当した。", '',
        '全部の36政策は、PRE番号02/05/12/13/14/15とPOST番号04/05/11/13/14/15の組合せだった。各番号は固定の数量政策JSONの順序であり、新しい候補番号ではない。', '',
        '既存主案B05_01はPOST前48が2F/0A・99取得・N87/C10で、既知PF0.487・差引−388,853円。100%という到達済み先着率だけでは、前半の支持と期限決済を含む利益損失を支えない。', '',
        '同じPREのB05_04は、POSTを既存CP0031正125/H30にした既存政策で、PRE前34F12A・73.91%、後28F3A・90.32%、POST前11F1A・91.67%、後18F3A・85.71%、全4セルの既知PFは1以上。ただしPOST49取得/19Night・0.188回/時、Night140取得・0.301回/時だった。B05_01のNight288取得・0.619回/時より低頻度である。', '',
        'B05_11は同じPREにCP0031正150/H30を組み、POST前10F1A・90.91%、後16F3A・84.21%、Night140取得・0.301回/時。B05_13のPOST NR0038正225/H120も前16F5A・76.19%、後11F1A・91.67%を保つが、POST41取得/12Night、後25の参加は4Nightと小さい。', '',
        '該当36件は相互に入口を共有する組合せであり、36個の独立な裏付けではない。C率や参加場数の前後追加条件は課しておらず、未知と低頻度をJSONへ残した。これは診断依頼後の事後比較で、今回固定した主案・追加期対象を置き換える採用結果ではない。']
    (HERE / '441前後帯別の事後診断.md').write_text('\n'.join(lines)+'\n', encoding='utf-8')
    print(json.dumps({'成功': True, '結果': groups, '保存': out.relative_to(ROOT).as_posix()}, ensure_ascii=False))


if __name__ == '__main__':
    main()
