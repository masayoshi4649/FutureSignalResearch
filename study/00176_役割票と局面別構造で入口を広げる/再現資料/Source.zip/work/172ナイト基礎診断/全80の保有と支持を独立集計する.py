"""固定6政策の取得参照と共用金融だけから、全80の保有時間・先着支持を独立集計する。"""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from collections import Counter, defaultdict
import gzip
import hashlib
import json
import math

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
AUTHOR = ROOT / 'work/172ナイト入口探索'
INPUTS = {}
BANDS = ('DAY', 'PRE', 'POST', 'NIGHT', '全帯')
GROUPS = ('全部', '主', '補完')


def fingerprint(path: Path) -> dict:
    """
    機能: ファイルの物理サイズとSHA256を求める。
    引数: path(Path)は存在する入力又は出力。
    返り値: dictはbytes/sha256。
    """
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'bytes': path.stat().st_size, 'sha256': digest}


def read(path: Path) -> dict:
    """
    機能: 指紋付きでJSON又はgzipを読む。
    引数: path(Path)は入力ファイル。
    返り値: dictは全CRC確認済みの内容。
    """
    INPUTS[path.relative_to(ROOT).as_posix()] = fingerprint(path)
    body = path.read_bytes()
    return json.loads(gzip.decompress(body) if body[:2] == b'\x1f\x8b' else body)


def ny_open(session: str) -> float:
    """
    機能: セッション日のNY09:30を夏冬時間込みのUTC秒に変換する。
    引数: session(str)は場名。
    返り値: floatは境界UTC秒。
    """
    return datetime.fromisoformat(session[:10]+'T09:30').replace(tzinfo=ZoneInfo('America/New_York')).timestamp()


def phase(session: str, at: float) -> str:
    """
    機能: q0又はq1の実時計をDAY/PRE/POSTへ分ける。
    引数: session(str)、at(float)はUTC秒。
    返り値: strは帯名。境界等号はPOST。
    """
    return 'DAY' if session.endswith('_Day') else 'PRE' if at < ny_open(session) else 'POST'


def scene_range(scene: dict, band: str) -> tuple | None:
    """
    機能: 全ザラバの場範囲を指定帯へ切り詰める。
    引数: scene(dict)はstart/end/session、band(str)は帯名。
    返り値: tuple[float,float]又はNoneは実時間範囲。
    """
    day = scene['session'].endswith('_Day')
    if band == 'DAY' and not day or band in ('PRE', 'POST', 'NIGHT') and day:
        return None
    start, end = scene['start'], scene['end'] - 300
    if band == 'PRE':
        end = min(end, ny_open(scene['session']))
    if band == 'POST':
        start = max(start, ny_open(scene['session']))
    return start, end


def load_period(new: bool) -> dict:
    """
    機能: 可変幅・可変期限の固定取得と共用数値配列を直接読む。
    引数: new(bool)は旧73又は追加7の指定。
    返り値: dictは場順、q0取得対応、数値配列、6固定取得、固定金融正本。
    """
    base = ROOT / ('inputs/00167_追加七場の入口と共用価格索引' if new else 'inputs/00148_全1分入口母集団')
    population = base / '入口母集団' if new else base
    numeric = base / '自然数値表' if new else ROOT / 'inputs/00163_任意幅の共用価格索引/数値表'
    fixed = read(population / '固定取得入力.json.gz')
    captures = read(population / '取得対応.json.gz')['rows']
    meta = read(numeric / '任意幅識別.json.gz')
    path = numeric / '任意幅配列.npz'
    INPUTS[path.relative_to(ROOT).as_posix()] = fingerprint(path)
    keys = ('entry_time', 'entry_index', 'entry_line', 'exit_time', 'label', 'direction', 'known', 'net5', 'session_index')
    with np.load(path, allow_pickle=False) as source:
        arrays = {key: source[key].copy() for key in keys}
    scenes = [{key: s[key] for key in ('session', 'start', 'end')} for s in fixed['scenes']]
    assert [s['session'] for s in scenes] == meta['session_order']
    prefix = '追加7' if new else '旧73'
    refs = read(AUTHOR / (prefix+'の全取得.json.gz'))['rows']
    financial = read(AUTHOR / (prefix+'の固定比較.json.gz'))
    assert financial['成功'] and financial['全固定政策デイ同体']
    assert len(refs) == 6 and [r['id'] for r in refs] == [r['id'] for r in financial['rows']]
    return {'meta': meta, 'arrays': arrays, 'scenes': scenes, 'captures': captures,
            'refs': refs, 'financial': financial}


def rows_for_policy(context: dict, record: dict) -> list:
    """
    機能: 行ごとの実側・幅・期限を直接参照しIFD_FIRST金融と保有区間を復元する。
    引数: context(dict)、record(dict)は一政策の固定取得参照。
    返り値: list[dict]はq0/q1帯、先着、既知金額、q1/exit、帰属を持つ。
    """
    a, meta = context['arrays'], context['meta']
    n = len(record['cases'])
    for key in ('cases', 'sides', 'events', 'phases', 'origins', 'widths', 'horizons', 'tiers'):
        assert len(record[key]) == n
    assert len(set(record['cases'])) == n
    output = []
    for i, case in enumerate(record['cases']):
        side, wi, hi = (record[key][i] for key in ('sides', 'widths', 'horizons'))
        assert side in (0, 1) and 0 <= wi < len(meta['widths']) and 0 <= hi < len(meta['horizons'])
        event = record['events'][i]
        capture = context['captures'][event]
        assert capture['status'] == 'filled' and capture['case_id'] == meta['case_ids'][case]
        scene = context['scenes'][int(a['session_index'][case])]
        session = scene['session']
        assert session == capture['session'] == meta['sessions'][case]
        assert tuple(a['entry_'+key][case] for key in ('time', 'index', 'line')) == \
            tuple(capture['q1'][key] for key in ('time', 'index', 'source_line'))
        q0 = phase(session, capture['q0']['time'])
        assert ('DAY', 'PRE', 'POST').index(q0) == record['phases'][i]
        key = (case, side, wi, hi)
        known, direction, strict = bool(a['known'][key]), int(a['direction'][key]), int(a['label'][key])
        label = direction if known and direction in (-1, 1) else 0 if strict == 0 else 2
        assert (label == 2) == (not known)
        money = int(a['net5'][key])
        assert known or money == 0
        assert record['origins'][i] in (0, 2)
        entry, exit_at = float(a['entry_time'][case]), float(a['exit_time'][key]) if known else None
        assert capture['q0']['time'] <= entry and (exit_at is None or exit_at >= entry)
        output.append({'session': session, 'q0': q0, 'q1': phase(session, entry), 'label': label,
            'known': known, 'net': money if known else None, 'entry': entry, 'exit': exit_at,
            'origin': record['origins'][i], 'width': meta['widths'][wi], 'horizon': meta['horizons'][hi]})
    return output


def subset(rows: list, group: str, band: str | None=None) -> list:
    """
    機能: 主/補完とq0出生帯の指定に従って取得を抽出する。
    引数: rows(list[dict])、group(str)、band(str|None)は帰属と出生帯。
    返り値: list[dict]は指定部分集合。
    """
    return [r for r in rows if (group == '全部' or r['origin'] == (0 if group == '主' else 2)) and
            (band is None or band == '全帯' or band == 'NIGHT' and r['q0'] != 'DAY' or r['q0'] == band)]


def financial(rows: list, scenes: list, band: str) -> dict:
    """
    機能: q0帯別の取得・先着・既知金額・到達した場支持を集計する。
    引数: rows(list[dict])は既にq0帯/帰属で抽出済み、scenes(list[dict])、band(str)。
    返り値: dictはFANC、既知収支、到達場数、F/A件数の最大場集中率。
    """
    counter = Counter(r['label'] for r in rows)
    f, a, n, c = (counter[key] for key in (1, -1, 0, 2))
    money = [r['net'] for r in rows if r['known']]
    profit, loss = sum(max(m, 0) for m in money), -sum(min(m, 0) for m in money)
    captures = Counter(r['session'] for r in rows)
    fc = Counter(r['session'] for r in rows if r['label'] == 1)
    ac = Counter(r['session'] for r in rows if r['label'] == -1)
    resolved = fc + ac
    denominator = sum(b-a for s in scenes if (x := scene_range(s, band)) is not None for a, b in [x])
    eligible = sum(scene_range(s, band) is not None for s in scenes)
    return {'count': len(rows), 'F': f, 'A': a, 'N': n, 'C': c,
        'rate': f/(f+a) if f+a else None, 'known': len(money), 'unknown': c,
        'profit': profit, 'loss': loss, 'net': profit-loss, 'pf': profit/loss if loss else None,
        'all_net': profit-loss if c == 0 else None,
        'wins': sum(m > 0 for m in money), 'loss_trades': sum(m < 0 for m in money),
        'scenes': len(captures), 'eligible_scenes': eligible,
        'all_scenes': len(captures) == eligible, 'hours': denominator/3600,
        'per_hour': len(rows)/(denominator/3600),
        'max_scene_share': max(captures.values())/len(rows) if rows else None,
        'core_count': sum(r['origin'] == 0 for r in rows), 'technical_count': sum(r['origin'] == 2 for r in rows),
        'F参加場数': len(fc), 'A参加場数': len(ac), 'FA到達参加場数': len(resolved),
        'FA解決件数': f+a, 'FA解決件数最大場集中率': max(resolved.values())/(f+a) if f+a else None,
        'FA最大場': sorted(s for s, count in resolved.items() if count == max(resolved.values())) if resolved else [],
        'F件数最大場集中率': max(fc.values())/f if f else None,
        'A件数最大場集中率': max(ac.values())/a if a else None}


def sweep(intervals: list, start: float, end: float) -> float:
    """
    機能: 枚数変化の端点を走査し、保有が正の時間を積分する。
    引数: intervals(list[tuple[float,float]])、start/end(float)は対象実時間帯。
    返り値: floatは重複保有を一度だけ数えた秒。
    """
    changes = {start: 0, end: 0}
    for a, b in intervals:
        a, b = max(a, start), min(b, end)
        if b > a:
            changes[a] = changes.get(a, 0)+1
            changes[b] = changes.get(b, 0)-1
    held, prior, seconds = 0, start, 0.
    for at, change in sorted(changes.items()):
        if held:
            seconds += at-prior
        held += change
        assert held >= 0
        prior = at
    assert held == 0
    return seconds


def holding(rows: list, scenes: list, band: str) -> dict:
    """
    機能: q0帯を問わず実時間帯へ配賦した保有和集合の下限/上限を求める。
    引数: rows(list[dict])は帰属だけで抽出済み、scenes(list[dict])、band(str)。
    返り値: dictは既知決済のみ下限、未知を場末まで保持する上限、全ザラバ分母。
    """
    by_scene = defaultdict(list)
    for row in rows:
        by_scene[row['session']].append(row)
    low, high, total, low_scenes, high_scenes = 0., 0., 0., 0, 0
    for scene in scenes:
        bounds = scene_range(scene, band)
        if bounds is None:
            continue
        start, end = bounds
        total += end-start
        use = by_scene[scene['session']]
        lower = [(r['entry'], r['exit']) for r in use if r['known']]
        upper = [(r['entry'], r['exit'] if r['known'] else scene['end']-300) for r in use]
        l, h = sweep(lower, start, end), sweep(upper, start, end)
        assert 0 <= l <= h <= end-start
        low += l
        high += h
        low_scenes += l > 0
        high_scenes += h > 0
    return {'既知保有和集合秒': low, '未知場末上限和集合秒': high, '対象ザラバ秒': total,
        '既知保有参加率_pct': 100*low/total, '未知場末上限参加率_pct': 100*high/total,
        '既知保有参加場数': low_scenes, '上限保有参加場数': high_scenes}


def describe(rows: list, scenes: list) -> dict:
    """
    機能: 主/補完の金融q0帯と実時間保有を同じ取得参照から記述する。
    引数: rows(list[dict])、scenes(list[dict])は対象政策と全場。
    返り値: dictは帯別/帰属別の金融・到達支持・保有。
    """
    return {band: {group: {'q0金融と到達支持': financial(subset(rows, group, band), scenes, band),
                          '実時間保有': holding(subset(rows, group), scenes, band)}
                   for group in GROUPS} for band in BANDS}


def main() -> None:
    """
    機能: 固定6政策の旧73/追加7を独立集計し、全80の加法とDay171同体を検査する。
    引数: なし。取得/数量/候補を変更せず、行ごとの幅と期限を尊重する。
    返り値: None。小型JSONと指紋・全金融照合検査を保存する。CSVは作らない。
    """
    all_rows, all_scenes, per_period = defaultdict(list), [], {}
    numerical_cells, day_fields = 0, 0
    candidate_conditions = {}
    for new, name in ((False, '旧73既使用'), (True, '追加7既使用参考')):
        context = load_period(new)
        refs = context['refs']
        baseline = next(r for r in refs if r['id'] == 'BASE171')
        day = np.array(baseline['phases']) == 0
        per_period[name] = {}
        all_scenes.extend(context['scenes'])
        for record, original in zip(refs, context['financial']['rows'], strict=True):
            assert record['id'] == original['id']
            actual_day = np.array(record['phases']) == 0
            for key in ('cases', 'sides', 'events', 'phases', 'origins', 'widths', 'horizons', 'tiers'):
                assert np.array_equal(np.array(record[key])[actual_day], np.array(baseline[key])[day]), (name, record['id'], key)
                day_fields += 1
            rows = rows_for_policy(context, record)
            all_rows[record['id']].extend(rows)
            candidate_conditions[record['id']] = original['candidate']
            actual = describe(rows, context['scenes'])
            per_period[name][record['id']] = actual
            for band in BANDS:
                for group in GROUPS:
                    expected = original['cap10']['periods']['全期'][band][group]
                    observed = actual[band][group]['q0金融と到達支持']
                    for key, value in expected.items():
                        if key not in observed:
                            continue
                        if value is None:
                            assert observed[key] is None, (name, record['id'], band, group, key)
                        elif isinstance(value, float):
                            assert math.isclose(observed[key], value, rel_tol=1e-12, abs_tol=1e-10), (name, record['id'], band, group, key)
                        else:
                            assert observed[key] == value, (name, record['id'], band, group, key)
                        numerical_cells += 1
    assert len(all_scenes) == len({s['session'] for s in all_scenes}) == 80
    combined = {policy: describe(rows, all_scenes) for policy, rows in all_rows.items()}
    old171 = read(HERE / '171全80のナイト基礎診断.json')['全80加法']['全部']['DAY']['実時間保有']
    baseline_day = combined['BASE171']['DAY']['全部']['実時間保有']
    for key in ('既知保有和集合秒', '未知場末上限和集合秒', '対象ザラバ秒'):
        assert baseline_day[key] == old171[key]
    for policy, result in combined.items():
        assert result['DAY'] == combined['BASE171']['DAY'], policy
        for band in BANDS:
            for group in GROUPS:
                for key in ('count', 'F', 'A', 'N', 'C', 'known', 'unknown', 'profit', 'loss', 'net',
                            'wins', 'loss_trades', 'scenes', 'eligible_scenes', 'core_count', 'technical_count',
                            'F参加場数', 'A参加場数', 'FA到達参加場数', 'FA解決件数'):
                    expected = sum(per_period[name][policy][band][group]['q0金融と到達支持'][key] for name in per_period)
                    assert result[band][group]['q0金融と到達支持'][key] == expected
    for name, value in INPUTS.items():
        assert fingerprint(ROOT/name) == value
    report = {'成功': True, '確認日': '2026-11-15', '対象': '固定BASE171と172参考5政策の全80既使用',
        '時計': '金融・到達支持はq0帯。保有はq1→実決済を実時間帯へ配賦し、出生帯で区間を切り捨てない。',
        '金融': '行ごとの幅とH添字を共用金融NPZへ直接参照。IFD_FIRST、N/Cを区別。Cは0円で全件収支を確定しない。',
        '保有': '端点の枚数変化を走査。既知決済だけを下限、未知を当該ザラバ末まで加えたcapモデルを上限。pending除外。',
        '支持': 'F/Aそれぞれと和集合の参加場数、FA解決件数、解決件数の最大場集中率。取得参加場と区別。',
        '政策条件': candidate_conditions, '全80加法': combined, '期間': per_period}
    output = HERE / '全80の保有と到達支持.json'
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    proof = {'成功': True, 'SourceSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), '入力': INPUTS,
        '行のcaseIDとq1原行一致': True, 'q0出生帯と固定phases一致': True,
        '各行可変幅可変期限を直接参照': True, '固定正本とのq0金融照合セル': numerical_cells,
        'Day取得8属性同体検査数': day_fields, '全6政策のDay金融保有支持同体': True,
        'Day171保有同体': baseline_day, '結果': {'path': output.relative_to(ROOT).as_posix(), **fingerprint(output)}}
    (HERE / '全80独立集計の検査.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'Day171保有同体': baseline_day, '金融照合セル': numerical_cells,
        '全80': {policy: {band: {'金融': values[band]['全部']['q0金融と到達支持'],
                               '保有': values[band]['全部']['実時間保有']} for band in ('PRE', 'POST', 'NIGHT')}
                for policy, values in combined.items()}}, ensure_ascii=False))


if __name__ == '__main__':
    main()
