"""自然価格・出生・金融を読まず、172短表選択の固定仕様を人工配列で確認する。"""
from pathlib import Path
import copy
import hashlib
import json

import numpy as np
import selector172 as S

HERE = Path(__file__).resolve().parent
FIELDS = ['count', 'F', 'A', 'N', 'C', 'rate', 'profit', 'loss', 'net', 'pf',
          'known', 'unknown', 'scenes', 'eligible_scenes', 'per_hour', 'max_scene_share']
FI = {name: i for i, name in enumerate(FIELDS)}
SETTING = {'shortlist_support': {'minimum_count': 40, 'minimum_resolved': 25,
           'minimum_night_scenes': 10, 'maximum_unknown_fraction': .1, 'minimum_rate': .65,
           'minimum_pf': 1.1, 'maximum_scene_share': .25}}


def pool(source: str, count: int=40) -> dict:
    """
    機能: 8群の人工候補と、同形の全期/前後統計を作る。
    引数: source(str)はSource名、count(int)は人工規則数。
    返り値: dictは純選択APIのプール。
    """
    ids = [f'G{i//5:02d}R{i:04d}' for i in range(count)]
    axes = {'規則順': ids, '発火方式': ['ALL'], '方向': ['NORMAL'], '幅': [200],
            '時計': ['H60'], '帯': ['NIGHT', 'PRE', 'POST'], '期間': ['全期', '前48場', '後25場'],
            '指標': FIELDS}
    data = np.zeros((count, 1, 1, 1, 1, 3, 3, len(FIELDS)))
    for ri in range(count):
        for bi in range(3):
            for pi in range(3):
                n, f, a, c = (100+ri, 55+ri%7, 20, 2) if pi == 0 else \
                    (40+ri%3, 21+ri%7, 8, 1) if pi == 1 else (50, 30-ri%7, 10, 1)
                profit, loss = 30000+ri*100, 10000
                values = {'count': n, 'F': f, 'A': a, 'N': n-f-a-c, 'C': c, 'rate': f/(f+a),
                          'profit': profit, 'loss': loss, 'net': profit-loss, 'pf': profit/loss,
                          'known': n-c, 'unknown': c, 'scenes': 16 if pi == 0 else 8,
                          'eligible_scenes': 36 if pi == 0 else 24 if pi == 1 else 12,
                          'per_hour': 1+ri/100 if pi == 0 else .7+ri/100, 'max_scene_share': .1}
                for field, value in values.items():
                    data[ri, 0, 0, 0, 0, bi, pi, FI[field]] = value
    return {'source': source, 'axes': axes, 'metrics': data,
            'groups': {rule: f'GROUP{ri//5:02d}' for ri, rule in enumerate(ids)}}


def main() -> None:
    """
    機能: 支持境界・群上限・決定性・統合・前48の未来非依存を検査する。
    引数: なし。人工配列のみを使う。
    返り値: None。人工結果と固定Source指紋を保存する。
    """
    edge = np.zeros(len(FIELDS))
    for field, value in {'count': 40, 'F': 17, 'A': 8, 'N': 11, 'C': 4, 'rate': .68,
                         'profit': 11000, 'loss': 10000, 'scenes': 10, 'max_scene_share': .25}.items():
        edge[FI[field]] = value
    assert bool(S.support_mask(edge, FI, SETTING['shortlist_support'], True))
    for field, value in (('count', 39), ('F', 16), ('scenes', 9), ('C', 5), ('rate', .64),
                         ('profit', 10999), ('max_scene_share', .251)):
        bad = edge.copy()
        bad[FI[field]] = value
        assert not bool(S.support_mask(bad, FI, SETTING['shortlist_support'], True)), field
    zero_loss = edge.copy()
    zero_loss[FI['loss']] = 0
    zero_loss[FI['profit']] = 1
    zero_loss[FI['pf']] = np.nan
    assert bool(S.support_mask(zero_loss, FI, SETTING['shortlist_support'], True))
    zero_loss[FI['profit']] = 0
    assert not bool(S.support_mask(zero_loss, FI, SETTING['shortlist_support'], True))
    assert S.wilson_lower(0, 0) == 0 and 0 < S.wilson_lower(50, 10) < 50/60
    old, new = pool('OLD1460'), pool('NEW768')
    result = S.select_shortlist([old], SETTING)
    repeated = S.select_shortlist([old], SETTING)
    assert result == repeated
    for band in ('PRE', 'POST'):
        report = result['bands'][band]
        assert sum(len(v) for v in report['全期順位別'].values()) == 15
        assert len(report['前48専用選択']) == 5
        assert max(report['全期群配分'].values()) <= 3
        assert max(report['前48枠群配分'].values()) <= 3
        assert report['候補数'] <= 20 and len({r['key'] for r in report['rows']}) == report['候補数']
        for row in report['rows']:
            assert row['key'] == row['policy_key'] and row['rule_index'] == row['position'][0]
        for key in report['前48と全期の重複']:
            assert 'FRONT_ONLY_SELECTION' in next(r for r in report['rows'] if r['key'] == key)['selection_reasons']
    changed = copy.deepcopy(old)
    changed['metrics'][..., 2, FI['F']] = 0
    changed['metrics'][..., 2, FI['A']] = 50
    changed['metrics'][..., 2, FI['rate']] = 0
    after = S.select_shortlist([changed], SETTING)
    for band in ('PRE', 'POST'):
        assert result['bands'][band]['前48専用選択'] == after['bands'][band]['前48専用選択']
    combined = S.select_shortlist([old, new], SETTING)
    assert combined == S.select_shortlist([new, old], SETTING)
    exported = S.stage2_rows(combined)
    assert set(exported) == {'PRE', 'POST'}
    bad_axis = copy.deepcopy(old)
    bad_axis['axes']['期間'] = ['前48場', '全期', '後25場']
    try:
        S.select_shortlist([bad_axis], SETTING)
        raise RuntimeError('不正な期間軸を受理した')
    except AssertionError:
        pass
    tiny = pool('TINY', 2)
    lack = S.select_shortlist([tiny], SETTING)
    assert all(v['候補数'] == 2 and v['最大20からの不足数'] == 18 for v in lack['bands'].values())
    proof = {'成功': True, '自然入力未使用': True, '検査': [
        '支持7境界と損失0/利益0', 'Wilson未到達0', '同群3と3順位各5/前48独立5',
        '選択決定性とOLD/NEW入力順不変', '後25改変で前48選択ID不変', '全期と前48重複理由保持',
        '不正期間軸棄却', '支持不足を埋めず18不足保持', 'Stage2識別schema'],
        'SourceSHA256': hashlib.sha256((HERE / 'selector172.py').read_bytes()).hexdigest(),
        '人工SourceSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), '仕様': S.SPEC}
    (HERE / 'selector人工検査.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
