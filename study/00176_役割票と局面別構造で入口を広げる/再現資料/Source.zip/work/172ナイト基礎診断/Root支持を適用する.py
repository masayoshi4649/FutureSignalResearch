"""固定済み純選択部品を旧1460の完成統計へ適用し、JSONだけを保存する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

import numpy as np
import selector172 as SELECT

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00172_デイを固定しナイト米国前後の複合入口を探索する'


def read(path: Path) -> dict:
    """
    機能: 日本語UTF-8のJSONを読む。
    引数: path(Path)は存在する入力。
    返り値: dictはJSON内容。
    """
    return json.loads(path.read_text(encoding='utf-8'))


def save(name: str, value: dict) -> None:
    """
    機能: 新しい短表結果だけをUTF-8 JSONへ保存する。
    引数: name(str)、value(dict)は新出力名と有限内容。
    返り値: None。
    """
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def main() -> None:
    """
    機能: 自然適用前固定を確認し、旧1460だけのRoot支持短表を出す。
    引数: なし。Root条件と完成済み統計を読む。
    返り値: None。固定Sourceを変更せず、旧単独短表とStage2用政策JSONを保存する。
    """
    freeze = read(HERE / 'selector自然適用前の固定.json')
    for ref in freeze['固定']:
        assert hashlib.sha256((ROOT / ref['path']).read_bytes()).hexdigest() == ref['sha256']
    proof = read(HERE / '1460再集計の完了.json')
    assert proof['成功']
    axes = read(HERE / '1460純新規のナイト診断軸.json')
    with np.load(HERE / '1460純新規のナイト診断配列.npz', allow_pickle=False) as source:
        metrics = source['metrics'].copy()
    setting = read(TRIAL / '条件.json')
    report = SELECT.select_shortlist([{'source': 'OLD1460', 'axes': axes, 'metrics': metrics}], setting)
    report['適用UTC'] = datetime.now(timezone.utc).isoformat()
    report['旧screen完了票SHA256'] = hashlib.sha256((HERE / '1460再集計の完了.json').read_bytes()).hexdigest()
    report['固定票SHA256'] = hashlib.sha256((HERE / 'selector自然適用前の固定.json').read_bytes()).hexdigest()
    save('旧1460のRoot支持短表.json', report)
    save('旧1460のRoot支持政策.json', SELECT.stage2_rows(report))
    summary = {}
    for band, value in report['bands'].items():
        summary[band] = {'support': value['pool_reports'], '候補数': value['候補数'],
                         '不足': value['最大20からの不足数'], '全期群': value['全期群配分'],
                         '選択先頭': [{key: row[key] for key in ('key', 'group', 'selected_by', 'periods')}
                                    for row in value['rows'][:5]]}
    print(json.dumps({'成功': True, 'summary': summary,
                      '旧164正本との照合セル': proof['旧164正本の3技術全幅全期限正逆2発火10指標一致セル数']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
