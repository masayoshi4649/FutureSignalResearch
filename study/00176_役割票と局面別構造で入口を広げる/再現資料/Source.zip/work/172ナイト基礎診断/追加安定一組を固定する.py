"""既使用441の事後安定36群から、追加7参考比較用の一組だけを固定順位で返す。"""
from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE = ROOT / 'work/172ナイト入口探索/旧73数量比較.json.gz'
SPEC = {
    '対象': '既存441政策のALL、旧73既使用結果だけ。新7の当該結果を入力にしない。',
    '支持': 'PRE/POST×前48/後25の全4セルでF+A>=6、F/(F+A)>=.7、PF>=1。',
    'PF': '正利益かつ利益>=損失で判定。損失0の正利益はPF無限大、利益損失0は不合格。',
    '順位': 'POST幅>125を優先→4セルWilson二側95%下限のmin降順→全期ALL NIGHT頻度降順→既存ID昇順。',
    '選択数': 1,
    '役割': '旧73を見て定めた後選の安定性診断対照。事前主を交換せず、追加7は既使用参考で未見主張しない。'
}


def wilson(f: int, a: int) -> float:
    """
    機能: 先着F/Aに対する二側95% Wilson下限を計算する。
    引数: f/a(int)は順/逆先着件数。
    返り値: floatは率の下限。到達0は0。
    """
    n = f+a
    if n == 0:
        return 0.
    z = 1.959963984540054
    p = f/n
    return (p+z*z/(2*n)-z*math.sqrt(p*(1-p)/n+z*z/(4*n*n)))/(1+z*z/n)


def eligible(cell: dict) -> bool:
    """
    機能: 指定された事後診断の4セル支持を判定する。
    引数: cell(dict)は既存ALL集計一セル。
    返り値: boolはFA6/率70/PF1の適格旗。
    """
    return cell['F']+cell['A'] >= 6 and 10*cell['F'] >= 7*(cell['F']+cell['A']) and \
        cell['profit'] > 0 and cell['profit'] >= cell['loss']


def main() -> None:
    """
    機能: 選択前固定票を照合し、旧441だけを読んで事後一組を確定する。
    引数: なし。追加7の金融・出生・再生結果は読まない。
    返り値: None。支持全36の全列gzip正本と一組選択JSONを保存する。
    """
    freeze_path = HERE / '追加安定一組の選択前固定.json'
    freeze = json.loads(freeze_path.read_text(encoding='utf-8'))
    assert freeze['SourceSHA256'] == hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    body = SOURCE.read_bytes()
    assert freeze['入力']['sha256'] == hashlib.sha256(body).hexdigest()
    result = json.loads(gzip.decompress(body))
    assert result['成功'] and result['全政策デイ同体'] and len(result['rows']) == 441
    rows = []
    for row in result['rows']:
        cells = [row['cap10']['periods'][period][band]['全部']
                 for period in ('前48場', '後25場') for band in ('PRE', 'POST')]
        if all(eligible(cell) for cell in cells):
            post = row['candidate']['POST']
            score = min(wilson(cell['F'], cell['A']) for cell in cells)
            rows.append({'id': row['id'], 'post_over_125': post is not None and post['width'] > 125,
                         'minimum_four_wilson95': score,
                         'night_per_hour': row['cap10']['periods']['全期']['NIGHT']['全部']['per_hour'],
                         'row': row})
    rows.sort(key=lambda r: (not r['post_over_125'], -r['minimum_four_wilson95'], -r['night_per_hour'], r['id']))
    assert len(rows) == 36
    raw = json.dumps({'成功': True, '仕様': SPEC, '入力': freeze['入力'],
                      'rows': [r['row'] for r in rows]}, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
    all_path = HERE / '441前後安定36政策の全列.json.gz'
    all_path.write_bytes(gzip.compress(raw, mtime=0))
    selected = rows[0] if rows else None
    public = None if selected is None else {**{k: v for k, v in selected.items() if k != 'row'},
        'candidate': selected['row']['candidate'], 'cap10': selected['row']['cap10']}
    report = {'成功': True, '固定UTC': datetime.now(timezone.utc).isoformat(),
        '新7の当該結果未読': True, '仕様': SPEC,
        '選択前固定SHA256': hashlib.sha256(freeze_path.read_bytes()).hexdigest(),
        'SourceSHA256': freeze['SourceSHA256'], '入力': freeze['入力'],
        '支持政策数': len(rows), 'POST幅125超の支持政策数': sum(r['post_over_125'] for r in rows),
        '全順位': [{k: v for k, v in r.items() if k != 'row'} for r in rows],
        '選択': public, '全列正本': {'path': all_path.relative_to(ROOT).as_posix(),
                'bytes': all_path.stat().st_size, 'sha256': hashlib.sha256(all_path.read_bytes()).hexdigest()}}
    (HERE / '追加安定一組の固定.json').write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    print(json.dumps({'成功': True, '政策': selected['id'], 'POST125超': selected['post_over_125'],
                      '4セル最小Wilson95': selected['minimum_four_wilson95'],
                      'Night頻度': selected['night_per_hour'], 'SourceSHA256': freeze['SourceSHA256'],
                      '全列正本': report['全列正本']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
