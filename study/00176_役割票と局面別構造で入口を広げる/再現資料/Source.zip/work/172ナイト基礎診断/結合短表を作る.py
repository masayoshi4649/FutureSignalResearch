"""固定selectorを旧1460と新768へ共通適用し、Root数量再生向け短表を保存する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys

import numpy as np
import selector172 as SELECT

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00172_デイを固定しナイト米国前後の複合入口を探索する'


def read(path: Path) -> dict:
    """
    機能: 日本語UTF-8 JSONを読む。
    引数: path(Path)は入力パス。
    返り値: dictは復元内容。
    """
    return json.loads(path.read_text(encoding='utf-8'))


def ref(path: Path) -> dict:
    """
    機能: 入力又は出力の物理指紋を記録する。
    引数: path(Path)は存在するファイル。
    返り値: dictは相対パス・bytes・SHA256。
    """
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest}


def save(name: str, value: dict) -> None:
    """
    機能: 結合結果をUTF-8 JSONとして保存する。
    引数: name(str)は出力名、value(dict)は有限値の内容。
    返り値: None。
    """
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')


def main() -> None:
    """
    機能: Source固定を確認し、OLD/NEWを同じselectorで併合する。
    引数: なし。前半独立選択を含め支持・順位・上限を変更しない。
    返り値: None。全短表JSON・Root政策JSON・入力指紋票を保存する。
    """
    freeze = read(HERE / 'selector自然適用前の固定.json')
    for value in freeze['固定']:
        assert ref(ROOT / value['path'])['sha256'] == value['sha256']
    setting = read(TRIAL / '条件.json')
    new_dir = ROOT / 'work/172ナイト複合候補'
    sys.path.insert(0, str(new_dir))
    import rules172_night as NEW
    new_dictionary = NEW.candidate_catalog()
    inputs, pools = [], []
    for source, directory, stem in (
        ('OLD1460', HERE, '1460純新規'), ('NEW768', new_dir / '金融比較', '新768')):
        ap = directory / f'{stem}のナイト診断軸.json'
        np = directory / f'{stem}のナイト診断配列.npz'
        axes = read(ap)
        with __import__('numpy').load(np, allow_pickle=False) as values:
            metrics = values['metrics'].copy()
        pool = {'source': source, 'axes': axes, 'metrics': metrics}
        if source == 'NEW768':
            pool['dictionary'] = new_dictionary
        pools.append(pool)
        inputs.extend((ref(ap), ref(np)))
    report = SELECT.select_shortlist(pools, setting)
    report['適用UTC'] = datetime.now(timezone.utc).isoformat()
    report['自然結果で支持変更なし'] = True
    report['Source'] = [ref(HERE / 'selector172.py'), ref(HERE / 'selector自然適用前の固定.json'),
                        ref(new_dir / 'rules172_night.py'), ref(Path(__file__))]
    report['入力'] = inputs
    save('旧新結合のRoot支持短表.json', report)
    save('旧新結合のRoot支持政策.json', SELECT.stage2_rows(report))
    save('結合短表の完了.json', {'成功': True, 'Source': report['Source'], '入力': inputs,
         '結果': [ref(HERE / '旧新結合のRoot支持短表.json'), ref(HERE / '旧新結合のRoot支持政策.json')],
         '帯': {band: {'候補数': value['候補数'], '不足数': value['最大20からの不足数'],
                       '全期群': value['全期群配分'], '前48群': value['前48枠群配分'],
                       'pool_reports': value['pool_reports']}
                for band, value in report['bands'].items()}})
    print(json.dumps({'成功': True, '帯': {band: {'候補数': value['候補数'],
         '不足数': value['最大20からの不足数'], '全期群': value['全期群配分'],
         '前48群': value['前48枠群配分'], 'pool_reports': value['pool_reports']}
         for band, value in report['bands'].items()}}, ensure_ascii=False))


if __name__ == '__main__':
    main()
