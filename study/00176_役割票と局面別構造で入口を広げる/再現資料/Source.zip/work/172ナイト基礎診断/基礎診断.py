"""171固定取得と163保存出生から、原板を再読せずナイトの基礎診断を作る。"""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from collections import Counter
import argparse
import gzip
import hashlib
import json
import time

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
INPUTS = {}
WIDTHS = (125, 150, 175, 200, 225, 250, 300, 350, 400, 500, 750, 1000)
HORIZONS = ('H30', 'H60', 'H120', 'SESSION')
BANDS = ('NIGHT', 'PRE', 'POST')
PERIODS = ('全期', '前48場', '後25場')
FIELDS = ('count', 'F', 'A', 'N', 'C', 'rate', 'profit', 'loss', 'net', 'pf',
          'known', 'unknown', 'scenes', 'eligible_scenes', 'per_hour', 'max_scene_share')


def read(path: Path) -> dict:
    """
    機能: 入力の物理指紋を記録し、gzipは全CRCを確認して読む。
    引数: path(Path)はJSON又はJSON.gzの入力。
    返り値: dictは復元済みJSON内容。
    """
    body = path.read_bytes()
    INPUTS[path.relative_to(ROOT).as_posix()] = {
        'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
    return json.loads(gzip.decompress(body) if body[:2] == b'\x1f\x8b' else body)


def record(path: Path) -> None:
    """
    機能: NPZ等の物理指紋を入力記録へ加える。
    引数: path(Path)は存在する入力。
    返り値: None。
    """
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    INPUTS[path.relative_to(ROOT).as_posix()] = {'bytes': path.stat().st_size, 'sha256': digest}


def save(name: str, value: dict) -> None:
    """
    機能: 新しい診断出力だけを日本語UTF-8 JSONとして保存する。
    引数: name(str)は出力名、value(dict)はJSON可能な値。
    返り値: None。
    """
    (HERE / name).write_text(json.dumps(value, ensure_ascii=False, indent=2,
                                     allow_nan=False) + '\n', encoding='utf-8')


def boundary(session: str) -> float:
    """
    機能: セッション日のNY09:30を夏冬時間込みのUTC秒へ変換する。
    引数: session(str)はセッション名。
    返り値: floatは境界UTC秒。
    """
    return datetime.fromisoformat(session[:10] + 'T09:30').replace(
        tzinfo=ZoneInfo('America/New_York')).timestamp()


def band(session: str, at: float) -> int:
    """
    機能: 判定又は取得時刻をデイ・米国前・米国後へ区分する。
    引数: session(str)、at(float)はUTC秒。
    返り値: intはDAY0、PRE1、POST2。境界等号はPOST。
    """
    return 0 if session.endswith('_Day') else 1 if at < boundary(session) else 2


def load(new: bool) -> dict:
    """
    機能: 共用の取得対応・場範囲・金融小型配列を読む。
    引数: new(bool)は追加7場か旧73場か。
    返り値: dictは場順、取得q0、case辞書と金融配列。
    """
    base = ROOT / ('inputs/00167_追加七場の入口と共用価格索引' if new else
                   'inputs/00148_全1分入口母集団')
    population = base / '入口母集団' if new else base
    fixed = read(population / '固定取得入力.json.gz')
    captures = read(population / '取得対応.json.gz')['rows']
    numeric = base / '自然数値表' if new else ROOT / 'inputs/00163_任意幅の共用価格索引/数値表'
    meta = read(numeric / '任意幅識別.json.gz')
    path = numeric / '任意幅配列.npz'
    record(path)
    keys = ('label', 'direction', 'known', 'net5', 'entry_time', 'exit_time', 'session_index')
    with np.load(path, allow_pickle=False) as source:
        arrays = {key: source[key].copy() for key in keys}
    scenes = [{key: scene[key] for key in ('session', 'start', 'end')} for scene in fixed['scenes']]
    assert [s['session'] for s in scenes] == meta['session_order']
    scene_map = {s['session']: i for i, s in enumerate(scenes)}
    hours = np.zeros((len(scenes), 3))
    for si, scene in enumerate(scenes):
        start, end = scene['start'], scene['end'] - 300
        if scene['session'].endswith('_Day'):
            hours[si, 0] = (end - start) / 3600
        else:
            split = boundary(scene['session'])
            hours[si, 1] = max(0, min(end, split) - start) / 3600
            hours[si, 2] = max(0, end - max(start, split)) / 3600
    case_map = {case: i for i, case in enumerate(meta['case_ids'])}
    event_cases = np.array([case_map[r['case_id']] if r['status'] == 'filled' else -1
                            for r in captures], dtype=np.int32)
    event_scene = np.array([scene_map[r['session']] for r in captures], dtype=np.int16)
    phases = np.array([band(r['session'], r['q0']['time']) for r in captures], dtype=np.int8)
    if not new:
        prior_meta = read(ROOT / 'work/151過去場判別の評価/入口選択/cache/feature_only/features_meta.json')
        assert [r['event_id'] for r in captures] == [r['event_id'] for r in prior_meta['q0_meta']]
    return {'new': new, 'meta': meta, 'arrays': arrays, 'captures': captures,
            'scenes': scenes, 'hours': hours, 'event_cases': event_cases,
            'event_scene': event_scene, 'event_phases': phases}


def labels(context: dict, cases: np.ndarray, sides: np.ndarray, wi: object, hi: object) -> tuple:
    """
    機能: STRICT_Hを保持した配列から164主時計IFD_FIRSTを作る。
    引数: context(dict)、cases/sides(np.ndarray)、wi/hi(int又は配列)は金融位置。
    返り値: tupleはlabel/known/net/exit配列。未知を0円へ補わない。
    """
    arrays = context['arrays']
    key = (cases, sides, wi, hi)
    strict, direction, known = (arrays[name][key] for name in ('label', 'direction', 'known'))
    result = np.where(known & (direction != 0), direction, np.where(strict == 0, 0, 2)).astype(np.int8)
    assert np.array_equal(result == 2, ~known)
    return result, known, arrays['net5'][key], arrays['exit_time'][key]


def union_seconds(intervals: list, lower: float, upper: float) -> float:
    """
    機能: 区間を指定時間帯へ切り詰め、重複を一回だけ数える。
    引数: intervals(list[tuple[float,float]])、lower/upper(float)はUTC秒。
    返り値: floatは区間和集合の秒数。
    """
    clipped = sorted((max(a, lower), min(b, upper)) for a, b in intervals
                     if min(b, upper) > max(a, lower))
    total, start, end = 0., None, None
    for a, b in clipped:
        if start is None:
            start, end = a, b
        elif a <= end:
            end = max(end, b)
        else:
            total += end - start
            start, end = a, b
    return total + (end - start if start is not None else 0.)


def holdings(context: dict, rows: list, clock_band: int | None) -> dict:
    """
    機能: 保有区間の和集合を既知決済下限と未知場末上限で計る。
    引数: context(dict)、rows(list[dict])、clock_band(int|None)は実時間帯の指定。
    返り値: dictは全ザラバ分母の秒数・比率。出生帯で区間を切り捨てない。
    """
    known_intervals, upper_intervals = {}, {}
    for row in rows:
        si = row['scene']
        scene = context['scenes'][si]
        entry = row['entry']
        if row['known']:
            known_intervals.setdefault(si, []).append((entry, row['exit']))
        upper_intervals.setdefault(si, []).append((entry, row['exit'] if row['known'] else scene['end'] - 300))
    lower_total, upper_total, denominator = 0., 0., 0.
    for si, scene in enumerate(context['scenes']):
        start, end = scene['start'], scene['end'] - 300
        day = scene['session'].endswith('_Day')
        if clock_band == 0 and not day:
            continue
        if clock_band in (1, 2) and day:
            continue
        if clock_band == 1:
            end = min(end, boundary(scene['session']))
        if clock_band == 2:
            start = max(start, boundary(scene['session']))
        denominator += max(0., end - start)
        lower_total += union_seconds(known_intervals.get(si, []), start, end)
        upper_total += union_seconds(upper_intervals.get(si, []), start, end)
    return {'既知保有和集合秒': lower_total, '未知場末上限和集合秒': upper_total,
            '対象ザラバ秒': denominator, '既知保有参加率_pct': 100 * lower_total / denominator,
            '未知場末上限参加率_pct': 100 * upper_total / denominator}


def summarize(rows: list, context: dict, phase: int | None) -> dict:
    """
    機能: 主又は補完の取得をq0帯で金融集計する。
    引数: rows(list[dict])、context(dict)、phase(int|None)は出生帯。
    返り値: dictは件数、参加場、先着、既知利益損失と未知。
    """
    use = [r for r in rows if phase is None or r['phase'] == phase]
    counter = Counter(r['label'] for r in use)
    money = [r['net'] for r in use if r['known']]
    f, a, n, c = (counter[k] for k in (1, -1, 0, 2))
    profit, loss = sum(max(v, 0) for v in money), -sum(min(v, 0) for v in money)
    hours = float(context['hours'].sum() if phase is None else context['hours'][:, phase].sum())
    eligible = len(context['scenes']) if phase is None else int((context['hours'][:, phase] > 0).sum())
    return {'count': len(use), 'F': f, 'A': a, 'N': n, 'C': c,
            'rate': f / (f + a) if f + a else None,
            'profit': profit, 'loss': loss, 'net': profit - loss,
            'pf': profit / loss if loss else None, 'known': len(money), 'unknown': c,
            'all_net': profit - loss if not c else None,
            'scenes': len({r['scene'] for r in use}), 'eligible_scenes': eligible,
            'hours': hours, 'per_hour': len(use) / hours,
            'wins': sum(v > 0 for v in money), 'loss_trades': sum(v < 0 for v in money)}


def baseline() -> None:
    """
    機能: 171固定主案の全80を主枝/補完とq0三帯で分解する。
    引数: なし。正式共用入力と固定取得参照を読む。
    返り値: None。保有時間unionの下限/上限とJSON/短報だけを保存する。
    """
    reports, checks = {}, []
    for new, name, folder in ((False, '旧73既使用', '旧73固定候補'),
                              (True, '追加7既使用基準', '追加7固定候補')):
        context = load(new)
        refs = read(ROOT / 'work/171三帯の入口切替' / folder / '全取得参照.json')['rows']
        assert len(refs) == 1 and refs[0]['id'] == 'PRIMARY171'
        ref = refs[0]
        cases, sides, widths = (np.array(ref[k]) for k in ('cases', 'sides', 'widths'))
        hi = context['meta']['horizons'].index('H60')
        ls, known, money, exits = labels(context, cases, sides, widths, hi)
        rows = []
        for i, case in enumerate(cases):
            width = context['meta']['widths'][widths[i]]
            origin, tier = ref['origins'][i], ref['tiers'][i]
            source = '主順行' if origin == 0 and width == 200 else '主回復失敗' if origin == 0 else '旧T' if tier == 1 else '局所'
            rows.append({'scene': int(context['arrays']['session_index'][case]),
                         'phase': ref['phases'][i], 'label': int(ls[i]), 'known': bool(known[i]),
                         'net': int(money[i]) if known[i] else None,
                         'entry': float(context['arrays']['entry_time'][case]),
                         'exit': float(exits[i]) if known[i] else None, 'source': source})
        groups = {'全部': rows, '主入口': [r for r in rows if r['source'].startswith('主')],
                  '補完': [r for r in rows if not r['source'].startswith('主')]}
        groups.update({source: [r for r in rows if r['source'] == source]
                       for source in ('主順行', '主回復失敗', '旧T', '局所')})
        by_group = {}
        for group, group_rows in groups.items():
            by_group[group] = {}
            for phase, band_name in ((None, '全帯'), (0, 'DAY'), (1, 'PRE'), (2, 'POST')):
                by_group[group][band_name] = {'q0金融': summarize(group_rows, context, phase),
                                             '実時間保有': holdings(context, group_rows, phase)}
        original = read(ROOT / 'work/171三帯の入口切替' / folder / '固定候補の数量比較.json')['rows'][0]['cap10']
        for band_name, original_name in (('DAY', 'DAY'), ('PRE', 'NY前'), ('POST', 'NY後')):
            actual = by_group['全部'][band_name]['q0金融']
            expected = original['timebands']['q0'][original_name]
            for key in ('count', 'F', 'A', 'N', 'C', 'profit', 'loss', 'net', 'known', 'unknown', 'scenes'):
                assert actual[key] == expected[key], (name, band_name, key)
        checks.append({'期間': name, '固定正本のq0全三帯金融11指標一致': True})
        reports[name] = {'場数': len(context['scenes']), '集計': by_group}
    combined = {}
    for group in reports['旧73既使用']['集計']:
        combined[group] = {}
        for band_name in ('全帯', 'DAY', 'PRE', 'POST'):
            pair = [reports[p]['集計'][group][band_name] for p in reports]
            vals = [r['q0金融'] for r in pair]
            summable = ('count', 'F', 'A', 'N', 'C', 'profit', 'loss', 'net', 'known',
                        'unknown', 'scenes', 'eligible_scenes', 'hours', 'wins', 'loss_trades')
            summed = {k: sum(v[k] for v in vals) for k in summable}
            f, a = summed['F'], summed['A']
            summed.update({'rate': f / (f + a) if f + a else None,
                           'pf': summed['profit'] / summed['loss'] if summed['loss'] else None,
                           'all_net': summed['net'] if not summed['C'] else None,
                           'per_hour': summed['count'] / summed['hours']})
            holds = [r['実時間保有'] for r in pair]
            totals = {k: sum(v[k] for v in holds) for k in ('既知保有和集合秒', '未知場末上限和集合秒', '対象ザラバ秒')}
            totals.update({'既知保有参加率_pct': 100 * totals['既知保有和集合秒'] / totals['対象ザラバ秒'],
                           '未知場末上限参加率_pct': 100 * totals['未知場末上限和集合秒'] / totals['対象ザラバ秒']})
            combined[group][band_name] = {'q0金融': summed, '実時間保有': totals}
    assert combined['全部']['全帯']['q0金融']['count'] == 644
    assert combined['全部']['全帯']['q0金融']['net'] == 4322107
    save('171全80のナイト基礎診断.json', {
        '成功': True, '確認日': '2026-11-15', '固定候補': 'PRIMARY171',
        '範囲': '171の既使用固定取得。新出生・新戦略・数量再生を行わない。',
        '時計': 'q0金融と実時間保有を区別。保有区間はq1から決済まで、帯をまたぐ部分も実時間へ配賦。',
        '未知': '下限は既知決済だけの保有union、上限は未知取得を当該場ザラバ末まで加えたunion。',
        '参加時間の限界': 'pendingは含まない。未知の決済事実や実mini約定成立を推定した値ではない。',
        '期間': reports, '全80加法': combined, '検査': checks, '入力': INPUTS})
    lines = ['# 171ナイト基礎診断', '', '2026-11-15。全80は既使用の固定171取得。原板再読・新規出生・新数量再生なし。', '',
             '|q0帯|入口|取得|参加場|F/A/N/C|到達済み先着率|既知利益|既知損失|既知差引|実時間保有union下限〜上限|',
             '|---|---|---:|---:|---|---:|---:|---:|---:|---:|']
    for band_name in ('PRE', 'POST'):
        for group in ('全部', '主入口', '補完', '主順行', '主回復失敗', '旧T', '局所'):
            r = combined[group][band_name]
            q, h = r['q0金融'], r['実時間保有']
            rate = f"{100*q['rate']:.2f}%" if q['rate'] is not None else '未定義'
            lines.append(f"|{band_name}|{group}|{q['count']}|{q['scenes']}/{q['eligible_scenes']}|"
                         f"{q['F']}/{q['A']}/{q['N']}/{q['C']}|{rate}|{q['profit']:,}|{q['loss']:,}|{q['net']:+,}|"
                         f"{h['既知保有参加率_pct']:.2f}%〜{h['未知場末上限参加率_pct']:.2f}%|")
    lines += ['', '金融は出生q0帯で分類する。保有時間はq1→決済の区間を実時計で帯へ切り詰めた和集合であり、q0帯の取引だけへ限定していない。',
              '下限は金融既知だけのunion、上限は未知をザラバ末まで保有したunion。主と補完が重なるため、両者の時間率は加算できない。pendingは含まない。',
              '既知差引は観測不足を除く既知部分であり、C>0の全件収支は未確定。全80は未見検証ではない。']
    (HERE / '171ナイト基礎診断.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '全80PRE': combined['全部']['PRE'],
                      '全80POST': combined['全部']['POST']}, ensure_ascii=False), flush=True)


# ----------------------------------------
def metric_cube(context: dict, cases: np.ndarray, sides: np.ndarray, phases: np.ndarray, wi: int) -> np.ndarray:
    """
    機能: 純新規取得をナイト全体/PRE/POST×前後×全4期限で集計する。
    引数: context(dict)、cases/sides/phases(np.ndarray)、wi(int)は取得・実側・q0帯・幅位置。
    返り値: np.ndarray[4,3,3,len(FIELDS)]は金融既知と未知を分けた統計。
    """
    scene = context['arrays']['session_index'][cases]
    his = [context['meta']['horizons'].index(h) for h in HORIZONS]
    ls, known, money, _ = labels(context, cases[:, None], sides[:, None], wi, np.array(his)[None, :])
    output = np.full((len(HORIZONS), len(BANDS), len(PERIODS), len(FIELDS)), np.nan)
    hours = context['hours']
    for bi, name in enumerate(BANDS):
        phase_mask = phases > 0 if name == 'NIGHT' else phases == (1 if name == 'PRE' else 2)
        band_hours = hours[:, 1:].sum(axis=1) if name == 'NIGHT' else hours[:, 1 if name == 'PRE' else 2]
        for pi, period in enumerate(PERIODS):
            eligible = band_hours > 0
            if period == '前48場':
                eligible &= np.arange(len(hours)) < 48
            if period == '後25場':
                eligible &= np.arange(len(hours)) >= 48
            rows = phase_mask & eligible[scene]
            n = int(rows.sum())
            counts = np.bincount(scene[rows], minlength=len(hours))
            l, k, m = ls[rows], known[rows], money[rows]
            f, a, und, c = [(l == code).sum(axis=0) for code in (1, -1, 0, 2)]
            profit = np.where(k, np.maximum(m, 0), 0).sum(axis=0)
            loss = np.where(k, np.maximum(-m, 0), 0).sum(axis=0)
            rate = np.divide(f, f + a, out=np.full(len(his), np.nan), where=f+a != 0)
            pf = np.divide(profit, loss, out=np.full(len(his), np.nan), where=loss != 0)
            total_hours = float(band_hours[eligible].sum())
            values = {'count': n, 'F': f, 'A': a, 'N': und, 'C': c, 'rate': rate,
                      'profit': profit, 'loss': loss, 'net': profit-loss, 'pf': pf,
                      'known': k.sum(axis=0), 'unknown': n-k.sum(axis=0),
                      'scenes': np.count_nonzero(counts), 'eligible_scenes': int(eligible.sum()),
                      'per_hour': n / total_hours,
                      'max_scene_share': int(counts.max()) / n if n else np.nan}
            for fi, field in enumerate(FIELDS):
                output[:, bi, pi, fi] = values[field]
    return output


def materialize(value: np.ndarray) -> dict:
    """
    機能: 一帯一政策の前後統計を有限JSONへ写す。
    引数: value(np.ndarray[3,len(FIELDS)])は全期/前48/後25。
    返り値: dictは期間別指標。
    """
    return {period: {field: float(v) if np.isfinite(v) else None
                     for field, v in zip(FIELDS, row, strict=True)}
            for period, row in zip(PERIODS, value, strict=True)}


def screen() -> None:
    """
    機能: 163保存1460出生を未変更で結び、旧73ナイトを純新規N診断する。
    引数: なし。12幅・4期限・2発火・正逆2方向を再集計する。
    返り値: None。主統計NPZ、軸、支持付き上位と反転対照JSONを保存する。
    """
    context = load(False)
    proof = read(ROOT / 'work/163入口と任意幅/全出生/全出生の確認.json')
    assert proof['成功'] and proof['金融未入力']
    ids = proof['規則順']
    assert len(ids) == 1460
    original_path = ROOT / 'work/164先着確定と反転比較/比較/最初到達の統計配列.npz'
    original_axis = read(original_path.parent / '統計軸.json')
    record(original_path)
    oracle_indices = np.array((0, 730, 1459))
    with np.load(original_path, allow_pickle=False) as source:
        oracle = source['metrics'][oracle_indices, :, :, :, :, 0, 0, :].copy()
    oracle_fields = {name: i for i, name in enumerate(original_axis['指標'])}
    verified_cells = 0
    metrics = np.full((len(ids), 2, 2, len(WIDTHS), len(HORIZONS), len(BANDS), len(PERIODS), len(FIELDS)), np.nan)
    start = time.monotonic()
    event_cases = context['event_cases']
    for wj, width in enumerate(WIDTHS):
        wi = context['meta']['widths'].index(width)
        path = ROOT / 'work/163入口と任意幅/全出生' / f'出生{width}.npz'
        record(path)
        assert INPUTS[path.relative_to(ROOT).as_posix()] == proof['files'][path.name]
        with np.load(path, allow_pickle=False) as source:
            matrices = {mode: source[mode].copy() for mode in ('ALL', 'EDGE')}
        for mi, mode in enumerate(('ALL', 'EDGE')):
            matrix = matrices[mode]
            assert matrix.shape == (1460, len(event_cases))
            for ri, directions in enumerate(matrix):
                events = np.flatnonzero((directions != 0) & (event_cases >= 0))
                if len(events):
                    first = np.unique(event_cases[events], return_index=True)[1]
                    events = events[np.sort(first)]
                cases = event_cases[events]
                sides = np.where(directions[events] == 1, 0, 1).astype(np.int8)
                phases = context['event_phases'][events]
                for oi in (0, 1):
                    actual_sides = sides if oi == 0 else 1-sides
                    metrics[ri, mi, oi, wj] = metric_cube(context, cases, actual_sides, phases, wi)
                    if ri in oracle_indices:
                        his = np.array([context['meta']['horizons'].index(h) for h in HORIZONS])
                        ls, known, money, _ = labels(context, cases[:, None], actual_sides[:, None], wi, his[None, :])
                        expected = oracle[list(oracle_indices).index(ri), mi, oi, wi]
                        profit = np.where(known, np.maximum(money, 0), 0).sum(axis=0)
                        loss = np.where(known, np.maximum(-money, 0), 0).sum(axis=0)
                        actual = {'count': len(cases), 'F': (ls == 1).sum(axis=0), 'A': (ls == -1).sum(axis=0),
                                  'N': (ls == 0).sum(axis=0), 'C': (ls == 2).sum(axis=0), 'profit': profit,
                                  'loss': loss, 'net': profit-loss, 'known': known.sum(axis=0),
                                  'unknown': (~known).sum(axis=0)}
                        for key, value in actual.items():
                            assert np.array_equal(np.broadcast_to(value, (len(HORIZONS),)),
                                                  expected[:, oracle_fields[key]]), (ri, mi, oi, wi, key)
                            verified_cells += len(HORIZONS)
        print(json.dumps({'幅': width, 'ナイト再集計済み': True, '経過秒': round(time.monotonic()-start, 1)}, ensure_ascii=False), flush=True)
    np.savez_compressed(HERE / '1460純新規のナイト診断配列.npz', metrics=metrics)
    save('1460純新規のナイト診断軸.json', {'成功': True, '規則順': ids, '発火方式': ['ALL', 'EDGE'],
        '方向': ['NORMAL', 'REVERSE'], '幅': WIDTHS, '時計': HORIZONS, '帯': BANDS,
        '期間': PERIODS, '指標': FIELDS, 'shape': list(metrics.shape), '主label': 'IFD_FIRST',
        '統合': 'Nのみ。旧C1参照補完F/Uと技術補完を混ぜない。', '数量': '独立一枚。cap10の口座再生ではない。',
        '出生': '163固定出生の全場履歴・当時の発火状態を保持。q0帯で取得結果を分解した事後診断。',
        '既使用': '旧73全て既使用。後25を未見と呼ばない。追加7の1460候補探索は行わない。', '入力': INPUTS})
    field = {name: i for i, name in enumerate(FIELDS)}
    # ----------------------------------------
    # 支持条件はナイトの説明に使う診断表示用であり、172の採用条件ではない。
    for bi, name in enumerate(BANDS):
        cube = metrics[:, :, :, :, :, bi]
        full, front, back = cube[..., 0, :], cube[..., 1, :], cube[..., 2, :]
        resolved = full[..., field['F']] + full[..., field['A']]
        support = (resolved >= 30) & (full[..., field['scenes']] >= 12) & \
            (full[..., field['C']] <= .1 * full[..., field['count']])
        eligible = support & (full[..., field['rate']] >= .65)
        positions = list(np.argwhere(eligible))
        positions.sort(key=lambda p: (-cube[tuple(p)][0, field['scenes']],
                                     -cube[tuple(p)][0, field['count']], -cube[tuple(p)][0, field['rate']]))
        rows = []
        for p in positions[:60]:
            ri, mi, oi, wj, hi = map(int, p)
            same = cube[ri, mi, 1-oi, wj, hi]
            rows.append({'rule': ids[ri], 'entry_mode': ('ALL', 'EDGE')[mi],
                         'orientation': ('NORMAL', 'REVERSE')[oi], 'width': WIDTHS[wj], 'horizon': HORIZONS[hi],
                         'position': p.tolist(), 'periods': materialize(cube[tuple(p)]),
                         '前後各6到達': bool(front[tuple(p)][field['F']]+front[tuple(p)][field['A']] >= 6 and
                                               back[tuple(p)][field['F']]+back[tuple(p)][field['A']] >= 6),
                         '同時点実BBOの反対方向': materialize(same)})
        reverse_positions = list(np.argwhere(support & (full[..., field['rate']] <= .4)))
        reverse_positions.sort(key=lambda p: (-cube[tuple(p)][0, field['count']], cube[tuple(p)][0, field['rate']]))
        bad = []
        for p in reverse_positions[:30]:
            ri, mi, oi, wj, hi = map(int, p)
            bad.append({'rule': ids[ri], 'entry_mode': ('ALL', 'EDGE')[mi],
                        'orientation': ('NORMAL', 'REVERSE')[oi], 'width': WIDTHS[wj], 'horizon': HORIZONS[hi],
                        'periods': materialize(cube[tuple(p)]),
                        '同時点実BBOの反対方向': materialize(cube[ri, mi, 1-oi, wj, hi])})
        small_positions = list(np.argwhere((~support) & (resolved >= 6) &
                                          (full[..., field['rate']] >= .7)))
        small_positions.sort(key=lambda p: (-cube[tuple(p)][0, field['rate']],
                                            -cube[tuple(p)][0, field['F']]-cube[tuple(p)][0, field['A']]))
        small = []
        for p in small_positions[:20]:
            ri, mi, oi, wj, hi = map(int, p)
            small.append({'rule': ids[ri], 'entry_mode': ('ALL', 'EDGE')[mi],
                          'orientation': ('NORMAL', 'REVERSE')[oi], 'width': WIDTHS[wj], 'horizon': HORIZONS[hi],
                          'periods': materialize(cube[tuple(p)])})
        save(f'{name}の支持付き診断.json', {'成功': True, '帯': name,
            '診断支持': '30到達/12参加Night場/全期C<=10%。適格表示は全期先着65%以上。前後は全件報告し、既使用基礎診断の表示条件であって研究採用条件ではない。',
            '支持政策数': int(support.sum()), '適格表示政策数': len(positions),
            '支持かつ先着70%以上政策数': int((support & (full[..., field['rate']] >= .7)).sum()), '上位': rows,
            '逆行過多表示政策数': len(reverse_positions), '逆行過多上位': bad,
            '支持不足70%以上表示政策数': len(small_positions), '支持不足上位': small,
            '注意': '全期を見た既使用小群の発見。実BBO反対側を再参照し、単純な1-pは用いない。単独指標の効果ではない。'})
    save('1460再集計の完了.json', {'成功': True, '経過秒': time.monotonic()-start,
        '旧164正本の3技術全幅全期限正逆2発火10指標一致セル数': verified_cells,
        'SourceSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), '入力': INPUTS,
        '結果': {p.name: {'bytes': p.stat().st_size,
                         'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
                  for p in HERE.iterdir() if p.name.startswith(('1460純新規', 'NIGHTの', 'PREの', 'POSTの'))}})


def main() -> None:
    """
    機能: 指定された基礎診断だけを実行する。
    引数: コマンド行mode(str)はbaseline又はscreen。
    返り値: None。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('mode', choices=('baseline', 'screen'))
    args = parser.parse_args()
    baseline() if args.mode == 'baseline' else screen()


if __name__ == '__main__':
    main()
