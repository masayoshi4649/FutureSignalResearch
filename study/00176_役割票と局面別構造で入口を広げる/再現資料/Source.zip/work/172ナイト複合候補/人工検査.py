"""自然価格・先着・金融を読まない172候補部品の小さい人工検査。"""
from pathlib import Path
import inspect
import json

import numpy as np

from rules172_night import NightEvaluator, candidate_catalog, manifest

ROOT = Path(__file__).resolve().parents[2]


def metadata(count: int) -> list[dict]:
    """
    機能: 1分間隔で単一場/限月を観測する人工q0台帳を作る。
    引数: count(int)は行数。
    返り値: list[dict]は自然情報を含まないq0時計と物理順。
    """
    return [{'session': '人工Night', 'session_index': 0, 'contract': '人工限月A',
        'q0_time': i * 60., 'q0_index': i, 'q0_line': i + 1} for i in range(count)]


def fixture(group: str, columns: list) -> np.ndarray:
    """
    機能: 指定技術群で100分目に一度だけ状態遷移する人工特徴を作る。
    引数: group(str)は八群ID、columns(list[str])は既存100列名。
    返り値: np.ndarray[140,100]は遷移前の反対状態と遷移後の確認値。
    """
    values = np.zeros((140, 100)); names = {name: i for i, name in enumerate(columns)}

    def put(name: str, before: float, after: float | None = None) -> None:
        """
        機能: 遷移前後の人工単列を設定する。
        引数: name(str)、before(float)、after(float又はNone)は列名と値。
        返り値: None。閉包の人工行列だけを変更する。
        """
        values[:, names[name]] = before
        if after is not None:
            values[100:, names[name]] = after

    for name, number in {'q0_spread_points': 5, 'q0_entry_minus_ema8_atr5_to_side': .2,
        'm1_tr_atr5_ratio': 1, 'm5_tr_previous_atr_ratio': 1, 'm1_volume_relative_prior3': 2,
        'm5_hist_delta_to_side': .2, 'm15_hist_delta_to_side': .1,
        'm5_rsi_delta_to_side': 1, 'm5_body_ratio_to_side': .5, 'm1_body_ratio_to_side': .5,
        'm1_body_reclaim_atr5_to_side': .3, 'q0_last_minus_m1_close_atr5_to_side': .1,
        'm1_close_delta_atr5_to_side': .2, 'm15_adx': 10, 'm15_adx_delta': -.2,
        'bb15_mean_room_125_ratio_to_side': .5, 'bb15_width_atr_ratio': 4,
        'q0_last_minus_prior3_forward_edge_atr5_to_side': .2, 'm5_hist_atr_to_side': .1,
        'q0_entry_prior3_percent_to_side': .5, 'bb15_sigma': 2}.items():
        put(name, number)
    for timeframe in (15, 30):
        for suffix in ('ema21_delta_to_side', 'di_difference_to_side'):
            put(f'm{timeframe}_{suffix}', 1 if group in ('NP', 'NC', 'NA') else -1)
    if group == 'NP':
        put('m5_price_ema8_atr_to_side', -.5, .2)
    elif group == 'NR':
        put('bb15_position_sigma_to_side', -1.6)
        put('m1_close_delta_atr5_to_side', -.2, .2)
    elif group == 'NB':
        put('bb15_position_sigma_to_side', -2.5, -.5)
    elif group == 'NF':
        put('q0_entry_prior3_percent_to_side', -.5, .5)
        put('m1_body_reclaim_atr5_to_side', -.3, .3)
        put('m1_previous_body_ratio_to_side', -.5)
    elif group == 'NS':
        put('m5_rsi_delta_to_side', -12, 1)
        put('m5_hist_delta_atr_to_side', -.1, .05)
        put('bb15_position_sigma_to_side', -.5)
    elif group == 'NC':
        put('bb15_sigma', 2, 1.2)
        values[90:100, names['bb15_sigma']] = 1
        put('bb15_position_sigma_to_side', .5)
    elif group == 'NA':
        put('m5_hist_atr_to_side', -.1, .1)
    elif group == 'NX':
        put('m5_di_difference_to_side', -10, 10)
        put('m30_di_difference_to_side', 1)
        put('m30_ema21_delta_to_side', 1)
    else:
        raise KeyError(group)
    return values


def run() -> dict:
    """
    機能: 八群の発火・全候補の対称/未来非依存/幅非依存と未知/resetを検査する。
    引数: なし。
    返り値: dictは成功した検査数と人工的な発火位置だけを記した結果。
    """
    definitions = json.loads((ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json').read_text(encoding='utf-8-sig'))
    columns = [c['name'] for c in definitions]; index = {name: i for i, name in enumerate(columns)}
    catalog = candidate_catalog(); meta = metadata(140)
    assert len(catalog) == 768 and len({r['id'] for r in catalog}) == 768
    assert set(inspect.signature(NightEvaluator).parameters) == {
        'buy_X', 'sell_X', 'columns', 'target_points', 'q0_meta', 'maximum_gap_seconds', 'minimum_coverage_ratio'}
    mirror_checks = 0; prefix_checks = 0; width_checks = 0; triggers = {}
    for group in manifest()['groups']:
        buy = fixture(group, columns); sell = np.full_like(buy, np.nan)
        base = NightEvaluator(buy, sell, columns, q0_meta=meta)
        mirror = NightEvaluator(sell, buy, columns, q0_meta=meta)
        width = NightEvaluator(buy, sell, columns, target_points=1000, q0_meta=meta)
        poisoned = buy.copy(); poisoned[112:] = 1e6
        future = NightEvaluator(poisoned, sell, columns, q0_meta=meta)
        prefix = NightEvaluator(buy[:112], sell[:112], columns, q0_meta=meta[:112])
        representative = next(r for r in catalog if r['group'] == group)
        expected = 101 if group == 'NB' else 100
        assert base.evaluate_one(representative)['buy_pass'][expected], (group, expected)
        triggers[group] = expected
        for rule in catalog:
            decision = base.evaluate_one(rule); reflected = mirror.evaluate_one(rule)
            assert np.array_equal(decision['directions'], -reflected['directions'])
            assert np.array_equal(decision['buy_pass'], reflected['sell_pass'])
            assert np.array_equal(decision['unknown_buy'], reflected['unknown_sell'])
            mirror_checks += 1
            for altered in (future.evaluate_one(rule), prefix.evaluate_one(rule)):
                for key in ('directions', 'buy_pass', 'sell_pass', 'conflicts', 'unknown_buy', 'unknown_sell'):
                    assert np.array_equal(decision[key][:112], altered[key][:112])
                prefix_checks += 1
            assert np.array_equal(decision['directions'], width.evaluate_one(rule)['directions'])
            width_checks += 1
        missing = buy.copy(); missing[expected, index['m1_volume_relative_prior3']] = np.nan
        absent = NightEvaluator(missing, sell, columns, q0_meta=meta).evaluate_one(representative)
        assert not absent['buy_pass'][expected] and absent['unknown_buy'][expected]
    # ----------------------------------------
    buy = fixture('NB', columns); sell = np.full_like(buy, np.nan)
    baseline = NightEvaluator(buy, sell, columns, q0_meta=meta)
    factor = 'n_event|NB|5|1.5|180'
    assert baseline.factor(0, factor)[0][103] == 1
    reset_checks = 0
    for changed_field in ('session', 'session_index', 'contract'):
        changed = [dict(row) for row in meta]
        for row in changed[101:]:
            row[changed_field] = 1 if changed_field == 'session_index' else '人工変更'
        result = NightEvaluator(buy, sell, columns, q0_meta=changed).factor(0, factor)[0]
        assert np.isnan(result[103]); reset_checks += 1
    for extra_seconds in (120, 121):
        changed = [dict(row) for row in meta]
        for row in changed[101:]:
            row['q0_time'] += extra_seconds
        result = NightEvaluator(buy, sell, columns, q0_meta=changed).factor(0, factor)[0]
        if extra_seconds == 120:
            assert result[103] == 1
        else:
            assert np.isnan(result[103])
        reset_checks += 1
    missing = buy.copy(); missing[101, index['bb15_position_sigma_to_side']] = np.nan
    result = NightEvaluator(missing, sell, columns, q0_meta=meta).factor(0, factor)[0]
    assert np.isnan(result[103]) and not np.any(result[102:110] == 1)
    # ----------------------------------------
    exact = fixture('NB', columns)
    exact[100:, index['bb15_position_sigma_to_side']] = -1.5
    assert not np.any(NightEvaluator(exact, sell, columns, q0_meta=meta).factor(0, 'n_event|NB|5|1.5|60')[0] == 1)
    one = NightEvaluator(buy, sell, columns, q0_meta=meta)
    assert one.factor(0, 'n_event|NB|5|1.5|60')[0][100] == 0
    assert one.factor(0, 'n_event|NB|5|1.5|60')[0][101] == 1
    common = next(r for r in catalog if r['group'] == 'NB')
    spike_checks = 0
    for name, threshold in [('m1_tr_atr5_ratio', 1.5), ('m5_tr_previous_atr_ratio', 2.5), ('m5_rsi_delta_to_side', 12)]:
        exact = buy.copy(); exact[101, index[name]] = threshold
        assert NightEvaluator(exact, sell, columns, q0_meta=meta).evaluate_one(common)['buy_pass'][101]
        exact[101, index[name]] = threshold + 1e-6
        assert not NightEvaluator(exact, sell, columns, q0_meta=meta).evaluate_one(common)['buy_pass'][101]
        spike_checks += 1
    duplicate = [dict(row) for row in meta]
    for row in duplicate:
        row['q0_time'] = 0
    assert np.isnan(NightEvaluator(buy, sell, columns, q0_meta=duplicate).rolling(0, 'bb15_sigma', 5, 'min')).all()
    bad = [dict(row) for row in meta]; bad[103]['q0_index'] = 99
    rejected = False
    try:
        NightEvaluator(buy, sell, columns, q0_meta=bad)
    except AssertionError:
        rejected = True
    assert rejected
    # ----------------------------------------
    generator = np.random.default_rng(172)
    sample = generator.normal(size=buy.shape)
    sample[30:34, index['bb15_sigma']] = np.nan
    sample[119, index['m5_price_ema8_atr_to_side']] = np.nan
    irregular = metadata(len(sample))
    for i, row in enumerate(irregular):
        row['q0_time'] = (i // 2) * 60. + (181 if i >= 70 else 0)
        if i >= 110:
            row['contract'] = '人工限月B'
    checker = NightEvaluator(sample, sell, columns, q0_meta=irregular)
    rolling_checks = 0
    for source, minutes, kind in product_for_reference():
        expected = np.full(len(sample), np.nan); begin = 0
        for i, row in enumerate(irregular):
            if i and (row['contract'] != irregular[i - 1]['contract'] or
                      row['q0_time'] - irregular[i - 1]['q0_time'] > 180):
                begin = i
            positions = [j for j in range(begin, i) if irregular[j]['q0_time'] >= row['q0_time'] - minutes * 60]
            if not positions:
                continue
            times = {irregular[j]['q0_time'] for j in positions}
            observed = sample[positions, index[source]]
            if len(times) >= max(3, minutes // 2) and row['q0_time'] - min(times) >= minutes * 60 * .8 and np.isfinite(observed).all():
                expected[i] = min(observed) if kind == 'min' else max(observed)
        assert np.allclose(expected, checker.rolling(0, source, minutes, kind), equal_nan=True)
        rolling_checks += 1
    return {'status': '成功', 'candidate_count': len(catalog), 'group_triggers': triggers,
        'mirror_checks': mirror_checks, 'prefix_and_future_checks': prefix_checks,
        'width_independence_checks': width_checks, 'required_unknown_checks': 8,
        'reset_and_gap_boundary_checks': reset_checks, 'unknown_breaks_arm': True,
        'cross_and_hold_boundary_checks': 3, 'spike_limit_checks': spike_checks,
        'independent_brute_window_checks': rolling_checks,
        'same_time_does_not_inflate_coverage': True, 'bad_order_rejected': rejected,
        'natural_data': '不使用。既存100列名定義だけを参照。'}


def product_for_reference() -> list[tuple]:
    """
    機能: 独立した総当たり窓検査に使う有限条件を列挙する。
    引数: なし。
    返り値: list[tuple[str,int,str]]は二特徴・三窓・二集約の12条件。
    """
    return [(source, minutes, kind) for source in ('bb15_sigma', 'm5_price_ema8_atr_to_side')
            for minutes in (5, 15, 30) for kind in ('min', 'max')]


if __name__ == '__main__':
    result = run()
    folder = Path(__file__).resolve().parent
    (folder / '人工検査.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (folder / '候補辞書.json').write_text(json.dumps(manifest(), ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False, indent=2))
