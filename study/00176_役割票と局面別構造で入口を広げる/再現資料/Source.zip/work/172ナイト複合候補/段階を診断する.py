"""封印済み768規則を変更せず、ナイト純特徴の成立段階を事後分解する。"""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys

import numpy as np

from rules172_night import NightEvaluator, candidate_catalog
from 出生を作る import ROOT, HERE, DATA_SOURCE, DATA_SHA256, sha, physical

STAGES = ('履歴遷移と確認秒', '加えて固定過熱guard', '加えて観測量', '加えて背景', '加えて動力と構造', '両側競合を除く')


def distribution(values: list[int]) -> dict:
    """
    機能: 一群の候補件数の分布を短くまとめる。
    引数: values(list[int])は候補ごとの成立q0数。
    返り値: dictは最小・中央値・最大・ゼロ候補数。
    """
    return {'最小': min(values), '中央値': float(np.median(values)), '最大': max(values),
        'ゼロ候補数': sum(value == 0 for value in values)}


def main() -> None:
    """
    機能: 自然結果の観測後に純特徴の段階別減少を記録し、規則は変更しない。
    引数: なし。F0a封印済みSourceと既存feature-only入力だけを再参照する。
    返り値: None。段階診断JSONとMarkdownを新規保存する。
    """
    proof_path = HERE / '全出生/全出生の確認.json'
    proof = json.loads(proof_path.read_text(encoding='utf-8'))
    assert proof['成功'] and proof['金融未入力']
    assert sha(DATA_SOURCE) == DATA_SHA256
    for ref in proof['Source']:
        assert physical(ROOT / ref['path']) == ref
    out = HERE / '段階診断'
    assert not out.exists()
    specification = importlib.util.spec_from_file_location('data172_stage_only', DATA_SOURCE)
    data = importlib.util.module_from_spec(specification); sys.modules[specification.name] = data
    specification.loader.exec_module(data)
    features = data.load_feature_dataset()
    evaluator = NightEvaluator(features.buy_X, features.sell_X, list(features.columns), q0_meta=features.q0_meta)
    phases = features.q0_timeband; scene = np.asarray([row['session_index'] for row in features.q0_meta])
    registry = candidate_catalog(); rows = []; union = {}
    with np.load(HERE / '全出生/新768の出生.npz', allow_pickle=False) as source:
        sealed = source['ALL'].copy()
    for ri, rule in enumerate(registry):
        items = rule['conditions']; assert items[8]['factor'].startswith('n_event|')
        background = [item for item in items[9:] if item['factor'] in (
            'long_up_votes', 'm15_adx', 'm15_adx_delta', 'm30_di_difference_to_side', 'm15_di_difference_to_side')]
        remainder = [item for item in items[9:] if item not in background]
        subsets = [[items[8]], items[:7], [items[7]], background, remainder]
        flags = [np.ones(len(phases), dtype=bool), np.ones(len(phases), dtype=bool)]
        stage_flags = []
        for subset in subsets:
            for side in (0, 1):
                for item in subset:
                    flags[side] &= evaluator.comparison(side, item)[0]
            stage_flags.append(flags[0] | flags[1])
        decision = evaluator.evaluate_one(rule)
        assert np.array_equal(decision['directions'], sealed[ri])
        stage_flags.append(decision['directions'] != 0)
        record = {'rule': rule['id'], 'group': rule['group']}
        for name, mask in [('NIGHT', phases > 0), ('PRE', phases == 1), ('POST', phases == 2)]:
            stage_values = [int((flag & mask).sum()) for flag in stage_flags]
            final = stage_flags[-1] & mask
            record[name] = {'対象q0': int(mask.sum()), '段階': dict(zip(STAGES, stage_values, strict=True)),
                '全必要値が片側以上既知': int(((~decision['unknown_buy'] | ~decision['unknown_sell']) & mask).sum()),
                '両側とも必要値未知': int((decision['unknown_buy'] & decision['unknown_sell'] & mask).sum()),
                '成立場': len(set(scene[final]))}
            key = (rule['group'], name)
            if key not in union:
                union[key] = np.zeros((len(STAGES), len(phases)), dtype=bool)
            union[key] |= np.asarray(stage_flags) & mask
        rows.append(record)
    groups = {}
    for group in dict.fromkeys(rule['group'] for rule in registry):
        selected = [row for row in rows if row['group'] == group]
        groups[group] = {}
        for name in ('NIGHT', 'PRE', 'POST'):
            groups[group][name] = {'候補数': len(selected),
                '候補別段階件数の分布': {stage: distribution([row[name]['段階'][stage] for row in selected]) for stage in STAGES},
                '全96候補の成立q0和集合': {stage: int(flag.sum()) for stage, flag in zip(STAGES, union[(group, name)], strict=True)},
                '最終成立場の分布': distribution([row[name]['成立場'] for row in selected])}
    for ref in proof['Source']:
        assert physical(ROOT / ref['path']) == ref
    out.mkdir()
    result = {'成功': True, '種類': '金融screen後の純特徴事後診断。候補の変更又は採用ではない。',
        'Source': physical(Path(__file__)), '封印': physical(proof_path), 'features': features.sources,
        '段階順': STAGES, '全8群': groups, '全候補': rows,
        '限界': 'q0段階件数は物理取得数ではない。段階減少はこの固定順での条件追加の結果であり、単独指標の因果効果ではない。'}
    path = out / '全8群の成立段階.json'
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    lines = ['# 新768の純特徴成立段階', '', '金融screen後の事後診断。固定候補の変更・採用は行わない。', '',
        '|群|帯|履歴遷移と確認秒|+固定guard|+量|+背景|+動力構造|競合除外後|最終成立場|',
        '|---|---|---:|---:|---:|---:|---:|---:|---:|']
    for group, by_band in groups.items():
        for name in ('PRE', 'POST'):
            distributions = by_band[name]['候補別段階件数の分布']
            values = [str(distributions[stage]['中央値']) for stage in STAGES]
            values.append(str(by_band[name]['最終成立場の分布']['中央値']))
            lines.append('|' + '|'.join((group, name, *values)) + '|')
    lines += ['', '各値は同群96候補の中央値。q0件数であり、物理取得数・到達済み件数とは異なる。',
        '「全96候補の和集合」と候補別の最小/中央値/最大はJSONに保存した。必要未知は不成立のままである。',
        '背景はlong_up_votes、15分ADX/増分、15/30分DI条件。それ以外の群別条件を動力と構造へ分類した。',
        '段階減少はこの順で条件を追加したときの変化であり、指標単独の因果効果ではない。']
    (out / '全8群の成立段階.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '群': groups}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
