"""封印済み新768出生を同じ物理取得へ結び、ナイトだけの独立一枚比較を行う。"""
from pathlib import Path
import argparse
import importlib.util
import json
import sys
import time

import numpy as np

from 出生を作る import ROOT, HERE, Q0_KEYS, sha, canonical_sha, physical, verify_f0

BASE_SOURCE = ROOT / 'work/172ナイト基礎診断/基礎診断.py'


def baseline_module() -> object:
    """
    機能: 自動実行を伴わず固定済み基礎診断の関数定義を読む。
    引数: なし。
    返り値: objectはload(False)/metric_cube等を公開する未改変module。
    """
    specification = importlib.util.spec_from_file_location('baseline172_for_new768', BASE_SOURCE)
    module = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = module
    specification.loader.exec_module(module)
    return module


def verify_financial_sources(f0_path: Path, expected_sha: str) -> tuple:
    """
    機能: 純出生Sourceに加え、本金融集計と基礎診断のF0束縛を検査する。
    引数: f0_path(Path)、expected_sha(str)は出生前にRootが固定したF0。
    返り値: tuple[dict,list[dict]]はF0物理参照と全必要Source。
    """
    f0_ref, sources = verify_f0(f0_path, expected_sha)
    fixed = {str(row['path']).replace('\\', '/'): row
             for row in json.loads(f0_path.read_text(encoding='utf-8-sig'))['固定対象']}
    for path in (Path(__file__), BASE_SOURCE):
        row = physical(path)
        assert row['path'] in fixed and row['sha256'] == fixed[row['path']]['sha256'] and row['bytes'] == fixed[row['path']]['bytes'], row['path']
        sources.append(row)
    return f0_ref, sources


def select_physical(directions: np.ndarray, event_cases: np.ndarray, event_phases: np.ndarray) -> tuple:
    """
    機能: 全場の出生から同一物理caseの最初の成立q0を一度だけ採る。
    引数: directions(np.ndarray[int8,N])、event_cases(np.ndarray[N])、event_phases(np.ndarray[N])。
    返り値: tuple[np.ndarray,np.ndarray,np.ndarray,np.ndarray]はcase/実側/最初q0帯/event位置。
    """
    assert directions.shape == event_cases.shape == event_phases.shape
    assert np.isin(directions, (-1, 0, 1)).all() and np.isin(event_phases, (0, 1, 2)).all()
    events = np.flatnonzero((directions != 0) & (event_cases >= 0))
    if len(events):
        first = np.unique(event_cases[events], return_index=True)[1]
        events = events[np.sort(first)]
    cases = event_cases[events]
    sides = np.where(directions[events] == 1, 0, 1).astype(np.int8)
    return cases, sides, event_phases[events], events


def artificial() -> dict:
    """
    機能: 自然入力なしで物理重複排除・最初q0帯・方向反転と空集合を確認する。
    引数: なし。
    返り値: dictは人工検査成功と基礎診断と同じ軸の仕様。
    """
    directions = np.array((1, -1, 1, 1, 0), dtype=np.int8)
    cases = np.array((8, 8, 9, -1, 10), dtype=np.int32)
    phases = np.array((1, 2, 2, 1, 2), dtype=np.int8)
    selected, sides, first_phases, events = select_physical(directions, cases, phases)
    assert np.array_equal(selected, (8, 9)) and np.array_equal(sides, (0, 0))
    assert np.array_equal(first_phases, (1, 2)) and np.array_equal(events, (0, 2))
    reflected = select_physical(-directions, cases, phases)
    assert np.array_equal(selected, reflected[0]) and np.array_equal(1 - sides, reflected[1])
    assert np.array_equal(first_phases, reflected[2]) and np.array_equal(events, reflected[3])
    assert all(len(array) == 0 for array in select_physical(np.zeros(5, dtype=np.int8), cases, phases))
    base = baseline_module()
    assert len(base.WIDTHS) == 12 and len(base.HORIZONS) == 4 and len(base.BANDS) == len(base.PERIODS) == 3
    return {'成功': True, '自然入力': '不使用', '物理重複排除': True, '最初q0帯': True,
        '同case正逆': True, '空集合': True,
        'shape': [768, 2, 2, len(base.WIDTHS), len(base.HORIZONS), len(base.BANDS), len(base.PERIODS), len(base.FIELDS)]}


def save(path: Path, value: object) -> None:
    """
    機能: 非有限値を拒否した日本語UTF-8 JSONを新しい比較先へ保存する。
    引数: path(Path)、value(object)は出力先と標準JSON可能な内容。
    返り値: None。
    """
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')


def diagnostic_reports(metrics: np.ndarray, ids: list[str], base: object, out: Path) -> None:
    """
    機能: 全期発見の表示支持で上位・逆行過多・支持不足を各ナイト帯へ整理する。
    引数: metrics(np.ndarray)、ids(list[str])、base(object)、out(Path)は比較配列・規則順・未改変基礎診断・出力先。
    返り値: None。研究採用とは別の診断表示JSONを保存する。
    """
    field = {name: i for i, name in enumerate(base.FIELDS)}
    for bi, name in enumerate(base.BANDS):
        cube = metrics[:, :, :, :, :, bi]
        full, front, back = cube[..., 0, :], cube[..., 1, :], cube[..., 2, :]
        resolved = full[..., field['F']] + full[..., field['A']]
        support = (resolved >= 30) & (full[..., field['scenes']] >= 12) & (full[..., field['C']] <= .1 * full[..., field['count']])
        positions = list(np.argwhere(support & (full[..., field['rate']] >= .65)))
        positions.sort(key=lambda p: (-cube[tuple(p)][0, field['scenes']], -cube[tuple(p)][0, field['count']], -cube[tuple(p)][0, field['rate']]))

        def row(position: np.ndarray) -> dict:
            """
            機能: 一政策の全期/前後と同物理取得の実反対側を取り出す。
            引数: position(np.ndarray[int,5])は規則/発火/正逆/幅/期限位置。
            返り値: dictは設定・前後指標・実BBO反対側の同軸比較。
            """
            ri, mi, oi, wi, hi = map(int, position)
            return {'rule': ids[ri], 'entry_mode': ('ALL', 'EDGE')[mi], 'orientation': ('NORMAL', 'REVERSE')[oi],
                'width': base.WIDTHS[wi], 'horizon': base.HORIZONS[hi], 'position': position.tolist(),
                'periods': base.materialize(cube[tuple(position)]),
                '前後各6到達': bool(front[tuple(position)][field['F']] + front[tuple(position)][field['A']] >= 6 and
                                        back[tuple(position)][field['F']] + back[tuple(position)][field['A']] >= 6),
                '同時点実BBOの反対方向': base.materialize(cube[ri, mi, 1 - oi, wi, hi])}

        bad_positions = list(np.argwhere(support & (full[..., field['rate']] <= .4)))
        bad_positions.sort(key=lambda p: (-cube[tuple(p)][0, field['count']], cube[tuple(p)][0, field['rate']]))
        small_positions = list(np.argwhere((~support) & (resolved >= 6) & (full[..., field['rate']] >= .7)))
        small_positions.sort(key=lambda p: (-cube[tuple(p)][0, field['rate']], -cube[tuple(p)][0, field['F']] - cube[tuple(p)][0, field['A']]))
        save(out / f'{name}の支持付き診断.json', {'成功': True, '帯': name,
            '診断支持': '30到達/12参加Night場/全期C<=10%。適格表示は全期先着65%以上。研究採用条件ではない。',
            '支持政策数': int(support.sum()), '適格表示政策数': len(positions),
            '支持かつ先着70%以上政策数': int((support & (full[..., field['rate']] >= .7)).sum()),
            '上位': [row(p) for p in positions[:60]], '逆行過多表示政策数': len(bad_positions),
            '逆行過多上位': [row(p) for p in bad_positions[:30]], '支持不足70%以上表示政策数': len(small_positions),
            '支持不足上位': [row(p) for p in small_positions[:20]],
            '注意': '旧73は全て既使用。全期発見を未見成績又は自動採用と呼ばない。逆方向は同caseの実BBO反対側を参照し1-pを使わない。'})


# ----------------------------------------
def screen(f0_path: Path, expected_f0_sha: str) -> None:
    """
    機能: 封印済み新768出生を12幅4期限・正逆・q0ナイト帯で独立一枚比較する。
    引数: f0_path(Path)、expected_f0_sha(str)は出生前に金融Sourceも固定したF0。
    返り値: None。金融比較へ全統計NPZ・軸・上位診断・入力指紋を新規保存する。
    """
    f0_ref, before = verify_financial_sources(f0_path, expected_f0_sha)
    out = HERE / '金融比較'
    assert not out.exists(), '金融比較の出力先が既に存在する'
    birth_folder = HERE / '全出生'
    proof_path = birth_folder / '全出生の確認.json'
    proof = json.loads(proof_path.read_text(encoding='utf-8'))
    assert proof['成功'] and proof['金融未入力'] and proof['F0'] == f0_ref
    birth_path = birth_folder / '新768の出生.npz'
    assert sha(birth_path) == proof['files'][birth_path.name]['sha256']
    birth_refs = [physical(proof_path), physical(birth_path)]
    for source in proof['Source']:
        assert source in before
    ids = proof['規則順']
    assert len(ids) == len(set(ids)) == 768 and proof['入口は出口幅非依存']
    with np.load(birth_path, allow_pickle=False) as source:
        assert set(source.files) == {'ALL', 'EDGE', 'phases'}
        matrices = {mode: source[mode].copy() for mode in ('ALL', 'EDGE')}
        phases = source['phases'].copy()
    assert all(matrix.dtype == np.int8 and matrix.shape == (768, len(phases)) and np.isin(matrix, (-1, 0, 1)).all()
               for matrix in matrices.values())
    base = baseline_module()
    context = base.load(False)
    assert np.array_equal(phases, context['event_phases'])
    feature_meta_path = ROOT / 'work/151過去場判別の評価/入口選択/cache/feature_only/features_meta.json'
    feature_meta = base.read(feature_meta_path)
    assert sha(feature_meta_path) == proof['features']['cache161']['meta']['sha256']
    assert canonical_sha([[q[key] for key in Q0_KEYS] for q in feature_meta['q0_meta']]) == proof['q0']['ordered_keys_sha256']
    for capture, q0 in zip(context['captures'], feature_meta['q0_meta'], strict=True):
        assert (capture['event_id'], capture['session'], capture['q0']['time'], capture['q0']['index'], capture['q0']['source_line']) == \
               (q0['event_id'], q0['session'], q0['q0_time'], q0['q0_index'], q0['q0_line'])
    del feature_meta
    metrics = np.full((768, 2, 2, len(base.WIDTHS), len(base.HORIZONS), len(base.BANDS), len(base.PERIODS), len(base.FIELDS)), np.nan)
    event_cases = context['event_cases']
    assert event_cases.shape == phases.shape
    width_indices = [context['meta']['widths'].index(width) for width in base.WIDTHS]
    begin = time.monotonic()
    checks = []
    for mi, mode in enumerate(('ALL', 'EDGE')):
        for ri, directions in enumerate(matrices[mode]):
            cases, sides, first_phases, events = select_physical(directions, event_cases, phases)
            assert len(cases) == len(set(cases)) and np.array_equal(first_phases, phases[events])
            for oi in (0, 1):
                actual_sides = sides if oi == 0 else 1 - sides
                for wi, numeric_wi in enumerate(width_indices):
                    metrics[ri, mi, oi, wi] = base.metric_cube(context, cases, actual_sides, first_phases, numeric_wi)
            if ri in (0, 383, 767):
                checks.append({'rule': ids[ri], 'mode': mode, '全場物理取得': len(cases),
                    'NIGHT': int((first_phases > 0).sum()), 'PRE': int((first_phases == 1).sum()),
                    'POST': int((first_phases == 2).sum()), '最初q0を正逆共用': True})
            if (ri + 1) % 96 == 0:
                print(json.dumps({'発火': mode, '比較済み': ri + 1, '全候補': 768,
                    '経過秒': round(time.monotonic() - begin, 1)}, ensure_ascii=False), flush=True)
    assert [physical(ROOT / row['path']) for row in before] == before
    assert [physical(ROOT / row['path']) for row in birth_refs] == birth_refs
    assert physical(f0_path) == f0_ref
    out.mkdir()
    array_path = out / '新768のナイト診断配列.npz'
    np.savez_compressed(array_path, metrics=metrics)
    save(out / '新768のナイト診断軸.json', {'成功': True, '規則順': ids,
        '発火方式': ['ALL', 'EDGE'], '方向': ['NORMAL', 'REVERSE'], '幅': base.WIDTHS,
        '時計': base.HORIZONS, '帯': base.BANDS, '期間': base.PERIODS, '指標': base.FIELDS,
        'shape': list(metrics.shape), '主label': 'IFD_FIRST', 'F0': f0_ref, 'Source': before,
        '出生': birth_refs, 'q0': proof['q0'], '入力': base.INPUTS,
        '出生と幅': '新768のtarget_points200封印を全出口幅で共用。出生は出口幅非依存。',
        '統合': '純新規Nのみ。旧参照補完F/U・技術補完を混ぜない。デイ金融をナイト統計へ混ぜない。',
        '数量': '独立一枚の診断。買売各10枚の未決予約込み口座再生とは呼ばない。',
        '時計の扱い': '全場履歴で最初の物理取得q0を固定後、そのq0帯で分解。NY境界で再武装しない。',
        '既使用': '旧73全て既使用。前48/後25も未見と呼ばない。追加7を候補探索へ使用しない。'})
    diagnostic_reports(metrics, ids, base, out)
    assert [physical(ROOT / row['path']) for row in before] == before
    assert [physical(ROOT / row['path']) for row in birth_refs] == birth_refs
    assert physical(f0_path) == f0_ref
    save(out / '完了.json', {'成功': True, 'F0': f0_ref, 'Source': before, '出生': birth_refs,
        '入力': base.INPUTS, '確認': checks, '経過秒': time.monotonic() - begin,
        'files': {path.name: {'bytes': path.stat().st_size, 'sha256': sha(path)} for path in out.iterdir() if path.is_file()}})
    print(json.dumps({'成功': True, 'shape': list(metrics.shape), '出力': str(out),
        '経過秒': round(time.monotonic() - begin, 1)}, ensure_ascii=False), flush=True)


def main() -> None:
    """
    機能: 自然入力なしの人工検査又はF0束縛済み金融比較を実行する。
    引数: コマンド行の--f0/--f0-sha256(str)又は--artificial(bool)。
    返り値: None。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--f0', type=Path)
    parser.add_argument('--f0-sha256')
    parser.add_argument('--artificial', action='store_true')
    args = parser.parse_args()
    if args.artificial:
        assert args.f0 is None and args.f0_sha256 is None
        print(json.dumps(artificial(), ensure_ascii=False), flush=True)
    else:
        assert args.f0 is not None and args.f0_sha256 is not None
        screen(args.f0.resolve(), args.f0_sha256)


if __name__ == '__main__':
    main()
