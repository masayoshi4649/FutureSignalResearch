"""ナイト入口向けの有限複合技術辞書。入力は当時実側100特徴とq0履歴だけ。"""
from collections import deque
from dataclasses import dataclass
from itertools import product
from pathlib import Path
import math
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'work/162複合入口候補'))
from rules162 import PreparedEvaluator, term

VERSION = '172ナイト複合候補1'
GROUPS = {
    'NP': ('長短押戻し後の構造再開', ['移動平均', 'DMI/ADX', 'MACD', '実体回復', 'ATR', '観測量']),
    'NR': ('低ADXの帯端で短期動力が回復', ['BB', 'DMI/ADX', 'MACD', '短期値動き', 'ATR', '観測量']),
    'NB': ('BB外から内への再入場を維持', ['BB', 'DMI/ADX', 'MACD', '実体回復', 'ATR', '観測量']),
    'NF': ('当時3分端の逸脱後に実体を回復', ['価格構造', 'DMI/ADX', 'MACD', '実体回復', 'ATR', '観測量']),
    'NS': ('反対動力の急変後に失速を確認', ['RSI', 'MACD', 'DMI/ADX', 'BB', '実体回復', 'ATR', '観測量']),
    'NC': ('BB圧縮後の解放と価格推進', ['BB', '移動平均', 'DMI/ADX', 'MACD', '価格構造', 'ATR', '観測量']),
    'NA': ('長期方向内の短期動力が再加速', ['移動平均', 'DMI/ADX', 'MACD', '価格構造', 'ATR', '観測量']),
    'NX': ('背景混在で短期DIが反対から復帰', ['移動平均', 'DMI/ADX', 'MACD', 'RSI', '実体回復', 'ATR', '観測量']),
}


def candidate_catalog() -> list[dict]:
    """
    機能: 金融・取得結果を使わず八群各96の候補を決定的に作る。
    引数: なし。
    返り値: list[dict]は技術役割・時間窓・全比較条件を記した768規則。
    """
    rules = []
    for group in GROUPS:
        windows = (15, 30, 60) if group == 'NC' else (5, 10, 20)
        depths = {'NP': (0, .25), 'NR': (1, 1.5), 'NB': (1.5, 2), 'NF': (0, .25),
                  'NS': (8, 12), 'NC': (.7, .85), 'NA': (.03, .08), 'NX': (0, 5)}[group]
        holds = (60, 180) if group == 'NB' else (0, 60)
        volumes = (1, 1.25) if group == 'NC' else (.75, 1.25)
        for window, depth, hold, volume, regime, spread in product(windows, depths, holds, volumes, (0, 1), (10, 20)):
            conditions = [
                term('q0_spread_points', '>', 0), term('q0_spread_points', '<=', spread),
                term('abs_q0_close_gap', '<=', 1),
                term('q0_entry_minus_ema8_atr5_to_side', '<=', 1),
                term('m1_tr_atr5_ratio', '<=', 1.5),
                term('m5_tr_previous_atr_ratio', '<=', 2.5),
                term('n_abs_rsi_delta5', '<=', 12),
                term('m1_volume_relative_prior3', '>=', volume),
                term(f'n_event|{group}|{window}|{depth}|{hold}', '>', .5),
            ]
            if group == 'NP':
                conditions += [term('long_up_votes', '>=', 2 + regime),
                    term('m15_hist_delta_to_side', '>=', 0), term('m5_hist_delta_to_side', '>', 0),
                    term('live_reclaim', '>', 0), term('m1_body_ratio_to_side', '>', 0),
                    term('q0_entry_minus_ema8_atr5_to_side', '>=', -.25)]
            elif group == 'NR':
                conditions += [term('m15_adx', '<=', 20 + 5 * regime),
                    term('long_up_votes', '<=', 2), term('m5_hist_delta_to_side', '>', 0),
                    term('bb15_position_sigma_to_side', '<=', -.25), term('m5_body_ratio_to_side', '>', 0),
                    term('bb15_mean_room_125_ratio_to_side', '>', 0)]
            elif group == 'NB':
                conditions += [term('long_up_votes', '<=', 1 + regime),
                    term('m15_adx_delta', '<=', 0), term('m5_hist_delta_to_side', '>', 0),
                    term('m5_rsi_delta_to_side', '>', 0), term('live_reclaim', '>', 0),
                    term('m1_body_ratio_to_side', '>', 0), term('bb15_position_sigma_to_side', '<=', .5)]
            elif group == 'NF':
                conditions += [term('long_up_votes', '<=', 1 + regime),
                    term('m15_adx_delta', '<=', 0), term('m5_hist_delta_to_side', '>', 0),
                    term('m1_body_ratio_to_side', '>', 0), term('live_reclaim', '>', 0),
                    term('q0_entry_prior3_percent_to_side', '>=', .25),
                    term('q0_entry_prior3_percent_to_side', '<=', 1)]
            elif group == 'NS':
                conditions += [term('long_up_votes', '<=', 1 + regime),
                    term('m15_adx_delta', '<=', 0), term('m5_hist_delta_atr_to_side', '>', 0),
                    term('m5_hist_delta_atr_to_side', '<=', .15), term('m5_rsi_delta_to_side', '>', 0),
                    term('m5_rsi_delta_to_side', '<=', 4), term('bb15_position_sigma_to_side', '<=', 0),
                    term('m1_body_ratio_to_side', '>', 0), term('live_reclaim', '>', 0)]
            elif group == 'NC':
                conditions += [term('long_up_votes', '>=', 2 + regime),
                    term('bb15_width_atr_ratio', '<=', 8), term('bb15_position_sigma_to_side', '>=', 0),
                    term('bb15_position_sigma_to_side', '<=', 1.5), term('m5_hist_delta_to_side', '>', 0),
                    term('m5_body_ratio_to_side', '>', .2),
                    term('q0_last_minus_prior3_forward_edge_atr5_to_side', '>', 0)]
            elif group == 'NA':
                conditions += [term('long_up_votes', '>=', 2 + regime),
                    term('m15_hist_delta_to_side', '>=', 0), term('m5_hist_atr_to_side', '>=', depth),
                    term('m5_hist_delta_to_side', '>', 0), term('m1_close_delta_atr5_to_side', '>', 0),
                    term('m5_rsi_center_to_side', '<=', 20)]
            else:
                conditions += [term('long_up_votes', '>=', 1), term('long_up_votes', '<=', 3),
                    term('m5_di_difference_to_side', '>=', depth), term('m5_hist_delta_to_side', '>', 0),
                    term('m15_hist_delta_to_side', '>', 0), term('m5_rsi_delta_to_side', '>', 0),
                    term('m5_rsi_center_to_side', '<=', 20), term('live_reclaim', '>', 0)]
                conditions += ([term('m30_di_difference_to_side', '<=', 0)] if regime else
                               [term('m15_di_difference_to_side', '<=', 0)])
            rule_id = f'{group}{sum(r["group"] == group for r in rules) + 1:04d}'
            rules.append({'id': rule_id, 'group': group, 'description': GROUPS[group][0],
                'technical_families': GROUPS[group][1], 'timeframes': [1, 5, 15, 30],
                'roles': ['背景方向/混在', '過去状態からの遷移', '当時の動力/構造', '観測量', '過熱/値幅上限'],
                'settings': {'window_minutes': window, 'depth': depth, 'hold_seconds': hold,
                    'volume_min': volume, 'regime': regime, 'spread_max': spread}, 'conditions': conditions})
    assert len(rules) == len({r['id'] for r in rules}) == 768
    assert all(len(set(r['technical_families'])) >= 3 for r in rules)
    return rules


# ----------------------------------------
@dataclass
class NightEvaluator(PreparedEvaluator):
    target_points: float = 200
    q0_meta: list | None = None
    maximum_gap_seconds: float = 180
    minimum_coverage_ratio: float = .8

    def __post_init__(self) -> None:
        """
        機能: 当時実側100特徴と場/限月/q0順を検査し、因果履歴を区切る。
        引数: self(NightEvaluator)はbuy_X/sell_X/columns/target_points/q0_metaを保持する。
        返り値: None。場・scene・限月変更又はgap>180秒で前状態を破棄する。
        """
        super().__post_init__()
        assert self.q0_meta is not None and len(self.q0_meta) == len(self.arrays[0])
        assert self.maximum_gap_seconds == 180 and self.minimum_coverage_ratio == .8
        self._history_cache = {}; self._event_cache = {}; self._segments = []
        previous = None; begin = 0
        for index, row in enumerate(self.q0_meta):
            scene = row.get('session_index', row.get('scene', row['session']))
            current = (row['session'], scene, row['contract'], row['q0_time'], row['q0_index'], row['q0_line'])
            assert isinstance(current[3], (int, float)) and not isinstance(current[3], bool) and math.isfinite(current[3])
            if previous is not None:
                same = current[:3] == previous[:3]
                if same:
                    assert current[3:] >= previous[3:] and current[4] > previous[4] and current[5] > previous[5]
                if not same or current[3] - previous[3] > self.maximum_gap_seconds:
                    self._segments.append((begin, index)); begin = index
            previous = current
        if self.q0_meta:
            self._segments.append((begin, len(self.q0_meta)))
        self._times = np.asarray([q['q0_time'] for q in self.q0_meta], dtype=np.float64)

    def previous(self, values: np.ndarray) -> np.ndarray:
        """
        機能: 同一有効区間の直前q0値だけを参照する。
        引数: values(np.ndarray)は現在を含むq0順の配列。
        返り値: np.ndarrayは場・scene・限月・長い欠測後の先頭をNaNとした前値。
        """
        result = np.full(len(values), np.nan)
        for start, end in self._segments:
            result[start + 1:end] = values[start:end - 1]
        return result

    def rolling(self, side: int, source: str, minutes: int, kind: str) -> np.ndarray:
        """
        機能: 現在を除いた実時間窓の最小/最大値を完全既知の範囲で作る。
        引数: side(int)は買0/売1、source(str)は特徴名、minutes(int)は分数、kind(str)はmin/max。
        返り値: np.ndarrayは80%時間被覆・max(3,分数//2)異時刻観測を満たす値、他NaN。
        """
        key = (side, source, minutes, kind)
        if key in self._history_cache:
            return self._history_cache[key]
        assert kind in ('min', 'max') and minutes > 0
        values, known = super().factor(side, source)
        result = np.full(len(values), np.nan); seconds = minutes * 60
        for start, end in self._segments:
            times = self._times[start:end]
            lefts = np.searchsorted(times, times - seconds, side='left') + start
            missing = np.r_[0, np.cumsum(~known[start:end])]
            changes = np.r_[0, np.cumsum(np.r_[False, np.diff(times) != 0])]
            queue = deque()
            for index in range(start, end):
                previous = index - 1; left = int(lefts[index - start])
                if previous >= start:
                    while queue and ((values[queue[-1]] >= values[previous]) if kind == 'min' else (values[queue[-1]] <= values[previous])):
                        queue.pop()
                    queue.append(previous)
                while queue and queue[0] < left:
                    queue.popleft()
                if previous < left or not queue:
                    continue
                distinct = 1 + changes[previous - start + 1] - changes[left - start + 1]
                complete = missing[previous - start + 1] == missing[left - start]
                covered = self._times[index] - self._times[left]
                if complete and distinct >= max(3, minutes // 2) and covered >= seconds * self.minimum_coverage_ratio:
                    result[index] = values[queue[0]]
        self._history_cache[key] = result
        return result

    def event_state(self, side: int, group: str, minutes: int, depth: float, hold: int) -> np.ndarray:
        """
        機能: 過去窓の根拠を持つ新しい遷移を検出し、連続維持と経過秒を確認する。
        引数: side(int)、group(str)、minutes(int)、depth(float)、hold(int)は辞書固定条件。
        返り値: np.ndarrayは成立1/非成立0/必要未知NaN。未知又は維持失敗でarmを破棄する。
        """
        key = (side, group, minutes, depth, hold)
        if key in self._event_cache:
            return self._event_cache[key]

        def value(name: str) -> np.ndarray:
            """
            機能: 当時の単列又は既存派生だけを取得する。
            引数: name(str)は特徴名。
            返り値: np.ndarrayは未知NaNを保持した値。
            """
            return super(NightEvaluator, self).factor(side, name)[0]

        def lower(source: str) -> np.ndarray:
            """
            機能: 現在を含めない同一有効区間の窓最小値を取る。
            引数: source(str)は特徴名。
            返り値: np.ndarrayは完全既知の過去窓最小値。
            """
            return self.rolling(side, source, minutes, 'min')

        if group == 'NP':
            current = value('m5_price_ema8_atr_to_side'); before = self.previous(current)
            context = lower('m5_price_ema8_atr_to_side')
            known = np.isfinite(current) & np.isfinite(before) & np.isfinite(context)
            event = (before <= 0) & (current > 0) & (context <= -depth)
            maintain = current >= 0
        elif group == 'NR':
            current = value('m1_close_delta_atr5_to_side'); before = self.previous(current)
            position = value('bb15_position_sigma_to_side'); context = lower('bb15_position_sigma_to_side')
            known = np.isfinite(current) & np.isfinite(before) & np.isfinite(position) & np.isfinite(context)
            event = (before <= 0) & (current > 0) & (position <= -depth) & (context <= -depth)
            maintain = (current >= 0) & (position <= .5)
        elif group == 'NB':
            current = value('bb15_position_sigma_to_side'); before = self.previous(current)
            context = lower('bb15_position_sigma_to_side')
            known = np.isfinite(current) & np.isfinite(before) & np.isfinite(context)
            event = (before <= -depth) & (current > -depth) & (context <= -depth)
            maintain = (current > -depth) & (current <= .5)
        elif group == 'NF':
            current = value('m1_body_reclaim_atr5_to_side'); before = self.previous(current)
            body = value('m1_previous_body_ratio_to_side'); position = value('q0_entry_prior3_percent_to_side')
            context = lower('q0_entry_prior3_percent_to_side')
            known = np.isfinite(current) & np.isfinite(before) & np.isfinite(body) & np.isfinite(position) & np.isfinite(context)
            event = (before <= 0) & (current > 0) & (body < 0) & (position >= .25) & (context <= -depth)
            maintain = (current >= 0) & (position >= .25)
        elif group == 'NS':
            current = value('m5_hist_delta_atr_to_side'); before = self.previous(current)
            rsi = value('m5_rsi_delta_to_side'); context = lower('m5_rsi_delta_to_side')
            known = np.isfinite(current) & np.isfinite(before) & np.isfinite(rsi) & np.isfinite(context)
            event = (before <= 0) & (current > 0) & (rsi > 0) & (context <= -depth)
            maintain = (current >= 0) & (rsi >= 0)
        elif group == 'NC':
            sigma = value('bb15_sigma'); low = lower('bb15_sigma')
            high = self.rolling(side, 'bb15_sigma', minutes, 'max')
            ratio = np.divide(sigma, low, out=np.full_like(sigma, np.nan), where=low > 0)
            contraction = np.divide(low, high, out=np.full_like(low, np.nan), where=high > 0)
            before = self.previous(ratio); position = value('bb15_position_sigma_to_side')
            known = np.isfinite(ratio) & np.isfinite(before) & np.isfinite(contraction) & np.isfinite(position)
            event = (before < 1.1) & (ratio >= 1.1) & (contraction <= depth) & (position >= 0)
            maintain = (ratio >= 1.1) & (position >= 0)
        elif group == 'NA':
            current = value('m5_hist_atr_to_side'); before = self.previous(current)
            context = lower('m5_hist_atr_to_side')
            known = np.isfinite(current) & np.isfinite(before) & np.isfinite(context)
            event = (before <= 0) & (current > 0) & (context <= -depth)
            maintain = current >= 0
        elif group == 'NX':
            current = value('m5_di_difference_to_side'); before = self.previous(current)
            context = lower('m5_di_difference_to_side')
            known = np.isfinite(current) & np.isfinite(before) & np.isfinite(context)
            event = (before <= 0) & (current > 0) & (context <= -depth)
            maintain = current >= 0
        else:
            raise KeyError('未知の技術群: ' + group)
        result = np.full(len(self.arrays[0]), np.nan)
        for start, end in self._segments:
            armed = None
            for index in range(start, end):
                if not known[index]:
                    armed = None
                    continue
                if not maintain[index]:
                    armed = None
                if event[index] and maintain[index]:
                    armed = self._times[index]
                age = np.nan if armed is None else self._times[index] - armed
                result[index] = float(armed is not None and hold <= age <= minutes * 60)
                if armed is not None and age > minutes * 60:
                    armed = None
        self._event_cache[key] = result
        return result

    def factor(self, side_index: int, name: str) -> tuple:
        """
        機能: 既存の純派生と固定した履歴イベントの値・既知性を返す。
        引数: side_index(int)は実側買0/売1、name(str)は単列/派生名。
        返り値: tuple[np.ndarray,np.ndarray]は値と既知mask。
        """
        if not name.startswith('n_'):
            return super().factor(side_index, name)
        key = (side_index, name)
        if key not in self._factor_cache:
            if name == 'n_abs_rsi_delta5':
                result = np.abs(super().factor(side_index, 'm5_rsi_delta_to_side')[0])
            elif name.startswith('n_event|'):
                _, group, minutes, depth, hold = name.split('|')
                result = self.event_state(side_index, group, int(minutes), float(depth), int(hold))
            else:
                raise KeyError('未知の履歴派生: ' + name)
            self._factor_cache[key] = (result, np.isfinite(result))
        return self._factor_cache[key]

    def iter_decisions(self, candidates: list | None = None):
        """
        機能: 巨大な候補行列を保存せず八群の判定を逐次返す。
        引数: candidates(list[dict]又はNone)は候補、Noneなら固定768規則。
        返り値: generator[dict]は既存evaluate_one互換の方向・競合・未知mask。
        """
        for candidate in candidate_catalog() if candidates is None else candidates:
            yield self.evaluate_one(candidate)


# ----------------------------------------
def manifest() -> dict:
    """
    機能: 金融実行前の全有限候補と時間・既知性・表現限界を公開する。
    引数: なし。
    返り値: dictは版・768候補・八技術群・純入力契約と制限。
    """
    rules = candidate_catalog()
    return {'version': VERSION, 'candidate_count': len(rules),
        'groups': {g: {'description': v[0], 'technical_families': v[1],
            'count': sum(r['group'] == g for r in rules)} for g, v in GROUPS.items()},
        'input': '当時実側buy_X/sell_X/100列定義とq0_metaのみ。取得・未来足・先着ラベル・金融を受けない。',
        'width': '入口条件は出口幅非依存。target_pointsの既定値は200で既存API互換のため保持する。NRのBB平均余地125比は正負だけを比較し、出口幅の閾値に使わない。',
        'q0_fields': ['session', 'session_index又はscene（なければsession）', 'contract', 'q0_time', 'q0_index', 'q0_line'],
        'clock': '場/scene/限月内のq0順。gap>180秒でreset。窓は実分で現在を除外し80%時間被覆とmax(3,分数//2)異時刻を要求。',
        'temporal': '全必要窓値がknownの新しい交差だけをarmし、0/60秒（NBは60/180秒）連続維持後に成立。窓分数を過ぎると失効する。未知又は維持失敗でarm破棄。帯境界ではresetしない。',
        'unknown': '必要未知はNaNを保持して不成立。未知を0/前値へ代用せず、未知maskを別返却する。',
        'symmetry': '同じ有限規則を実BUY/SELLのside正規化100Xへ適用。両側成立は競合待機。',
        'guard': '正常spread10/20以下、q0近接1ATR以下、追値1ATR以下、1分TR/ATR5≤1.5、5分TR/前ATR5≤2.5、5分RSI増分絶対≤12。',
        'limitations': [
            'NP/NA/NXの持続はq0で観測した指標状態の実秒持続であり、異なる確定5分足の本数とは呼ばない。',
            'NBは当時ごとに更新されるBB位置の外→内クロスであり、過去同一バンド絶対価格の再取得ではない。',
            'NFは当時prior3端の逸脱後の実体回復。更新されるprior3の比率を使い、過去絶対突破水準を固定したリテストの完全再現ではない。',
            'NCは当時BB15σの過去min/maxと現在/過去minによる圧縮拡大近似であり、原典のbandwidth分位点仕様とは異なる。',
            'NR/NSは低ADX/動力の遷移と価格回復を別役割で組み合わせる研究仮説。心理又は将来の反転成功を直接観測しない。',
            '観測量は既存累積差分の当時特徴であり、攻撃側約定量ではない。',
            '候補方向列は取得でも口座収支でもない。同一episodeの出生正準化・再武装・数量枠・約定・金融は呼出側の責務。',
            'PRE/POST切替は全場履歴の判定後に呼出側で行う。デイ既存条件を本辞書で置換しない。'],
        'rules': rules}
