"""当時の純特徴だけから新768候補の全自然出生を金融前に封印する。"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import sys
import time

import numpy as np

from rules172_night import NightEvaluator, candidate_catalog, manifest

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
DATA_SOURCE = ROOT / 'work/161三時間帯入口のデータ/data161.py'
DATA_SHA256 = '1aa4ab452d26d507f532c78ebf036ca37690642cd1cf140f01eb0423f0fe03fe'
Q0_KEYS = ('event_id', 'session', 'contract', 'session_index', 'q0_time', 'q0_index', 'q0_line')


def sha(path: Path) -> str:
    """
    機能: ファイルを副本化せず物理SHA256を計算する。
    引数: path(Path)は存在する入力又は出力。
    返り値: strは小文字16進SHA256。
    """
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def canonical_sha(value: object) -> str:
    """
    機能: 順序付き識別値の標準JSON表現を指紋化する。
    引数: value(object)は有限JSON可能な識別値。
    返り値: strはUTF-8・区切り固定・非有限拒否のSHA256。
    """
    body = json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')
    return hashlib.sha256(body).hexdigest()


def physical(path: Path) -> dict:
    """
    機能: リポジトリ相対名・物理サイズ・指紋をまとめる。
    引数: path(Path)はリポジトリ内のファイル。
    返り値: dictはpath/bytes/sha256を持つ固定参照。
    """
    resolved = path.resolve()
    return {'path': resolved.relative_to(ROOT).as_posix(), 'bytes': resolved.stat().st_size, 'sha256': sha(resolved)}


def required_sources() -> list[Path]:
    """
    機能: 自然出生前にF0へ束縛する純判定部品を列挙する。
    引数: なし。
    返り値: list[Path]は自Source・候補辞書・人工検査・162基底・161入力部品・列定義。
    """
    return [Path(__file__), HERE / 'rules172_night.py', HERE / '候補辞書.json',
        HERE / '人工検査.py', HERE / '人工検査.json', ROOT / 'work/162複合入口候補/rules162.py',
        DATA_SOURCE, ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json']


def verify_f0(f0_path: Path, expected_sha: str) -> tuple:
    """
    機能: 呼出者が指定したF0指紋と必要純Sourceの固定を自然読込前に確認する。
    引数: f0_path(Path)は既存F0、expected_sha(str)は呼出者が固定した64桁指紋。
    返り値: tuple[dict,list[dict]]はF0物理参照と検査済み純Source。無関係な金融入力は開かない。
    """
    assert len(expected_sha) == 64 and set(expected_sha) <= set('0123456789abcdef')
    assert sha(f0_path) == expected_sha, 'F0指紋不一致'
    f0 = json.loads(f0_path.read_text(encoding='utf-8-sig'))
    assert isinstance(f0['固定対象'], list)
    fixed = {}
    for row in f0['固定対象']:
        name = str(row['path']).replace('\\', '/')
        assert name not in fixed, 'F0固定対象の重複'
        fixed[name] = row
    before = [physical(path) for path in required_sources()]
    for row in before:
        assert row['path'] in fixed, 'F0に必要Sourceが未固定: ' + row['path']
        assert row['sha256'] == fixed[row['path']]['sha256'] and row['bytes'] == fixed[row['path']]['bytes'], row['path']
    assert sha(DATA_SOURCE) == DATA_SHA256
    return physical(f0_path), before


def edge_directions(directions: np.ndarray, q0_meta: list[dict]) -> np.ndarray:
    """
    機能: 同方向の継続を除き、場/scene/限月/gap180秒超で再武装する。
    引数: directions(np.ndarray[int8,N])は全q0方向、q0_meta(list[dict])は当時識別時計。
    返り値: np.ndarray[int8,N]は遷移時だけの方向。NY帯境界をreset条件に含めない。
    """
    assert directions.shape == (len(q0_meta),) and directions.dtype == np.int8
    assert np.isin(directions, (-1, 0, 1)).all()
    if not len(directions):
        return directions.copy()
    keys = [(q['session'], q.get('session_index', q.get('scene', q['session'])), q['contract']) for q in q0_meta]
    times = np.asarray([q['q0_time'] for q in q0_meta], dtype=np.float64)
    reset = np.r_[True, np.asarray([keys[i] != keys[i - 1] or times[i] - times[i - 1] > 180
                                   for i in range(1, len(keys))], dtype=bool)]
    previous = np.r_[np.int8(0), directions[:-1]]
    return np.where(reset | (previous != directions), directions, 0).astype(np.int8)


def artificial() -> dict:
    """
    機能: 自然入力なしでEDGEの継続・帯非reset・場/限月・gap等号を確認する。
    引数: なし。
    返り値: dictは人工検査成功と境界の仕様。
    """
    times = (0, 60, 120, 180, 360, 541, 601, 661, 721, 781)
    meta = [{'event_id': f'人工{i}', 'session': '人工Night' if i < 9 else '人工別Night',
        'session_index': 0 if i < 8 else 1, 'contract': '人工A' if i < 7 else '人工B',
        'q0_time': float(at), 'q0_index': i, 'q0_line': i + 1} for i, at in enumerate(times)]
    directions = np.ones(len(meta), dtype=np.int8)
    expected = np.array((1, 0, 0, 0, 0, 1, 0, 1, 1, 1), dtype=np.int8)
    assert np.array_equal(edge_directions(directions, meta), expected)
    for count in range(1, len(meta) + 1):
        assert np.array_equal(edge_directions(directions[:count], meta[:count]), expected[:count])
    varied = np.array((1, 1, 0, -1, -1, -1, 0, 1, 1, 1), dtype=np.int8)
    assert np.array_equal(edge_directions(varied, meta), np.array((1, 0, 0, -1, 0, -1, 0, 1, 1, 1), dtype=np.int8))
    assert np.array_equal(edge_directions(-varied, meta), -edge_directions(varied, meta))
    assert edge_directions(np.empty(0, dtype=np.int8), []).shape == (0,)
    return {'成功': True, '自然入力': '不使用', 'gap180秒': '継続', 'gap181秒': 'reset',
        '場scene限月': '変更でreset', '帯': 'NY帯はEDGE引数にもreset条件にも含めない', 'prefix': True, '対称': True}


# ----------------------------------------
def seal(f0_path: Path, f0_sha256: str) -> None:
    """
    機能: feature-onlyの既存100特徴を一度だけ読み、新768のALL/EDGE出生を封印する。
    引数: f0_path(Path)、f0_sha256(str)はRootが作成・指定した出生前固定証拠。
    返り値: None。全出生NPZと再現指紋・件数・純入力証拠JSONを新規保存する。
    """
    f0_ref, before = verify_f0(f0_path, f0_sha256)
    out = HERE / '全出生'
    assert not out.exists(), '出生出力先が既に存在する'
    test = artificial()
    prior_test = json.loads((HERE / '人工検査.json').read_text(encoding='utf-8'))
    assert prior_test['status'] == '成功' and prior_test['candidate_count'] == 768
    stored_manifest = json.loads((HERE / '候補辞書.json').read_text(encoding='utf-8'))
    assert stored_manifest == manifest()
    specification = importlib.util.spec_from_file_location('data172_feature_only', DATA_SOURCE)
    data = importlib.util.module_from_spec(specification)
    sys.modules[specification.name] = data
    specification.loader.exec_module(data)
    begin = time.monotonic()
    features = data.load_feature_dataset()
    definitions, column_evidence = data.read_json_ref(data.FileRef(
        ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json', data.CATALOG_SHA256))
    columns = list(features.columns)
    assert columns == [column['name'] for column in definitions]
    assert all(set(q) == set(Q0_KEYS) for q in features.q0_meta)
    phases = np.asarray(features.q0_timeband, dtype=np.int8)
    assert np.array_equal(phases, np.asarray([data.timeband(q['session'], q['q0_time']) for q in features.q0_meta], dtype=np.int8))
    registry = candidate_catalog()
    count = len(features.q0_meta)
    assert len(registry) == 768 and count == 35339
    evaluator = NightEvaluator(features.buy_X, features.sell_X, columns, target_points=200, q0_meta=features.q0_meta)
    matrix = np.empty((len(registry), count), dtype=np.int8)
    edges = np.empty_like(matrix)
    counts = []
    for index, decision in enumerate(evaluator.iter_decisions(registry)):
        assert decision['candidate_id'] == registry[index]['id']
        matrix[index] = decision['directions']
        edges[index] = edge_directions(matrix[index], features.q0_meta)
        summary = {'rule': decision['candidate_id'], 'group': registry[index]['group'],
            'conflict': int(decision['conflicts'].sum()), 'unknown_buy': int(decision['unknown_buy'].sum()),
            'unknown_sell': int(decision['unknown_sell'].sum())}
        for label, mask in [('全帯', np.ones(count, dtype=bool)), ('DAY', phases == 0),
                            ('NIGHT', phases > 0), ('PRE', phases == 1), ('POST', phases == 2)]:
            summary[label] = {'ALL': int(np.count_nonzero(matrix[index, mask])),
                              'EDGE': int(np.count_nonzero(edges[index, mask]))}
        counts.append(summary)
        if (index + 1) % 96 == 0:
            print(json.dumps({'純出生判定済み': index + 1, '全候補': len(registry),
                '経過秒': round(time.monotonic() - begin, 1)}, ensure_ascii=False), flush=True)
    q0_ordered = [[q[key] for key in Q0_KEYS] for q in features.q0_meta]
    assert [physical(ROOT / row['path']) for row in before] == before
    assert physical(f0_path) == f0_ref
    out.mkdir()
    path = out / '新768の出生.npz'
    np.savez_compressed(path, ALL=matrix, EDGE=edges, phases=phases)
    proof = {'成功': True, '金融未入力': True, '版': stored_manifest['version'],
        'F0': f0_ref, 'Source': before, '規則順': [rule['id'] for rule in registry],
        '候補数': len(registry), '判定幅': 200, '入口は出口幅非依存': True,
        'shape': list(matrix.shape), 'dtype': str(matrix.dtype), '発火方式': ['ALL', 'EDGE'],
        '帯': ['DAY', 'PRE', 'POST'], '採用範囲': 'Nightのみ。Dayも純出生を算出するが固定171デイ条件を変更しない。',
        'EDGE': '直前q0からの方向変化又は場/scene/限月変更/gap>180秒だけで再発火。NY境界resetなし。',
        'q0': {'keys': list(Q0_KEYS), 'rows': count, 'ordered_keys_sha256': canonical_sha(q0_ordered),
               'serialization': 'keys順の各行listを全q0順へ並べたUTF-8 JSON。ensure_ascii=False,separators=(comma,colon),allow_nan=False。'},
        'columns': {'count': len(columns), 'order': columns, 'ordered_names_sha256': canonical_sha(columns),
                    'definition': column_evidence},
        'features': features.sources, '人工EDGE確認': test, 'counts': counts,
        '数値配列の指紋': {name: {'shape': list(array.shape), 'dtype': str(array.dtype),
            'row_major_bytes_sha256': hashlib.sha256(array.tobytes(order='C')).hexdigest()}
            for name, array in [('ALL', matrix), ('EDGE', edges), ('phases', phases)]},
        'files': {path.name: {'bytes': path.stat().st_size, 'sha256': sha(path)}},
        '経過秒': time.monotonic() - begin,
        '範囲': 'feature-onlyの100X/q0と列定義だけ。取得対応・教師・未来足・費用・金融を読込/参照しない。'}
    (out / '全出生の確認.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    assert [physical(ROOT / row['path']) for row in before] == before
    assert physical(f0_path) == f0_ref
    print(json.dumps({'成功': True, '金融未入力': True, '候補数': len(registry),
        'q0数': count, '出生': proof['files'], '経過秒': round(time.monotonic() - begin, 1)}, ensure_ascii=False), flush=True)


def main() -> None:
    """
    機能: 自然出生封印又は自然入力を使わないEDGE人工検査を実行する。
    引数: コマンド行の--f0/--f0-sha256(str)又は--artificial(bool)。
    返り値: None。自然実行ではF0指定を必須とする。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--f0', type=Path)
    parser.add_argument('--f0-sha256')
    parser.add_argument('--artificial', action='store_true')
    args = parser.parse_args()
    if args.artificial:
        assert args.f0 is None and args.f0_sha256 is None
        print(json.dumps(artificial(), ensure_ascii=False), flush=True)
    else:
        assert args.f0 is not None and args.f0_sha256 is not None, '自然実行にはRootのF0と固定SHA256が必要'
        seal(args.f0.resolve(), args.f0_sha256)


if __name__ == '__main__':
    main()
