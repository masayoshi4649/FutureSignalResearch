"""金融比較後の独立検算。候補又は選択条件を変更せず、八群代表を直接集計する。"""
from pathlib import Path
from collections import Counter
import importlib.util
import json

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 群代表の出生EDGEと実取得・正逆・全幅期限・q0帯前後の金融を別実装で照合する。
    引数: なし。候補封印と完成済み金融比較、固定共用金融だけを参照する。
    返り値: None。比較Sourceを変えず独立検算JSONを追加保存する。
    """
    baseline_path = ROOT / 'work/172ナイト基礎診断/基礎診断.py'
    specification = importlib.util.spec_from_file_location('baseline172_independent', baseline_path)
    base = importlib.util.module_from_spec(specification); specification.loader.exec_module(base)
    context = base.load(False)
    proof = json.loads((HERE / '全出生/全出生の確認.json').read_text(encoding='utf-8'))
    axis = json.loads((HERE / '金融比較/新768のナイト診断軸.json').read_text(encoding='utf-8'))
    assert proof['規則順'] == axis['規則順']
    representatives = list(range(0, 768, 96))
    with np.load(HERE / '全出生/新768の出生.npz', allow_pickle=False) as source:
        matrices = {mode: source[mode][representatives].copy() for mode in ('ALL', 'EDGE')}
    with np.load(HERE / '金融比較/新768のナイト診断配列.npz', allow_pickle=False) as source:
        actual = source['metrics'][representatives].copy()
    meta = json.loads((ROOT / 'work/151過去場判別の評価/入口選択/cache/feature_only/features_meta.json').read_text(encoding='utf-8'))['q0_meta']
    fields = {name: i for i, name in enumerate(axis['指標'])}
    case_map = {name: i for i, name in enumerate(context['meta']['case_ids'])}
    array = context['arrays']; checked = 0; edge_rows = 0
    for local, ri in enumerate(representatives):
        direction = matrices['ALL'][local]
        expected_edge = np.zeros(len(direction), dtype=np.int8)
        for i, current in enumerate(direction):
            reset = i == 0
            if i:
                prior, now = meta[i - 1], meta[i]
                reset = (prior['session'], prior['session_index'], prior['contract']) != (now['session'], now['session_index'], now['contract']) or now['q0_time'] - prior['q0_time'] > 180
            if reset or current != direction[i - 1]:
                expected_edge[i] = current
        assert np.array_equal(expected_edge, matrices['EDGE'][local])
        edge_rows += len(direction)
        for mi, mode in enumerate(('ALL', 'EDGE')):
            seen = set(); selected = []
            for i, sign in enumerate(matrices[mode][local]):
                capture = context['captures'][i]
                if sign == 0 or capture['status'] != 'filled' or capture['case_id'] in seen:
                    continue
                seen.add(capture['case_id'])
                case = case_map[capture['case_id']]
                selected.append((case, 0 if sign == 1 else 1, base.band(capture['session'], capture['q0']['time'])))
            for oi in (0, 1):
                for wj, width in enumerate(axis['幅']):
                    wi = context['meta']['widths'].index(width)
                    for hj, horizon in enumerate(axis['時計']):
                        hi = context['meta']['horizons'].index(horizon)
                        records = []
                        for case, side, phase in selected:
                            si = int(array['session_index'][case]); actual_side = side if oi == 0 else 1 - side
                            known = bool(array['known'][case, actual_side, wi, hi])
                            reached = int(array['direction'][case, actual_side, wi, hi])
                            strict = int(array['label'][case, actual_side, wi, hi])
                            label = reached if known and reached else 0 if strict == 0 else 2
                            assert (label == 2) == (not known)
                            records.append((si, phase, label, known, int(array['net5'][case, actual_side, wi, hi]) if known else 0))
                        for bi, band in enumerate(axis['帯']):
                            hours = context['hours'][:, 1:].sum(axis=1) if band == 'NIGHT' else context['hours'][:, 1 if band == 'PRE' else 2]
                            for pi, period in enumerate(axis['期間']):
                                eligible = [i for i, hour in enumerate(hours) if hour > 0 and (pi == 0 or (i < 48 if pi == 1 else i >= 48))]
                                use = [r for r in records if r[0] in eligible and (r[1] > 0 if band == 'NIGHT' else r[1] == (1 if band == 'PRE' else 2))]
                                label_counts = Counter(row[2] for row in use)
                                f, a, n, c = [label_counts[code] for code in (1, -1, 0, 2)]
                                profit = sum(max(row[4], 0) for row in use if row[3])
                                loss = sum(max(-row[4], 0) for row in use if row[3])
                                count = len(use); scene_counts = Counter(row[0] for row in use)
                                expected = {'count': count, 'F': f, 'A': a, 'N': n, 'C': c,
                                    'rate': f / (f + a) if f + a else np.nan,
                                    'profit': profit, 'loss': loss, 'net': profit - loss,
                                    'pf': profit / loss if loss else np.nan,
                                    'known': count - c, 'unknown': c, 'scenes': len(scene_counts),
                                    'eligible_scenes': len(eligible), 'per_hour': count / sum(hours[i] for i in eligible),
                                    'max_scene_share': max(scene_counts.values()) / count if count else np.nan}
                                for name, expected_value in expected.items():
                                    value = actual[local, mi, oi, wj, hj, bi, pi, fields[name]]
                                    assert np.isclose(value, expected_value, equal_nan=True, rtol=1e-12, atol=1e-12), (ri, mi, oi, width, horizon, band, period, name)
                                    checked += 1
    result = {'成功': True, '種類': '金融比較後の独立検算。候補又は選択の調整ではない。',
        '代表規則': [axis['規則順'][i] for i in representatives],
        '全場EDGEを別ループで照合したq0行': edge_rows,
        '物理取得と全幅全期限正逆帯前後16指標の照合セル': checked,
        '基礎診断の再用範囲': '入力読込とNY帯変換のみ。select_physical/labels/metric_cubeは使わず別実装で集計。'}
    (HERE / '金融比較/独立検算.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
