"""151の全q0特徴と、H60両側完了の物理case教師を分離して射影する。"""
from dataclasses import dataclass, field
from pathlib import Path
from collections import Counter
import copy
import gzip
import hashlib
import json
import math

import numpy as np

WORK_ROOT=Path(__file__).resolve().parents[1]
CATALOG_DEFINITION_SHA256='c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4'
SIDE_ORDER=(1,-1)


# ----------------------------------------
# 特徴と教師は別の型として保持します。
@dataclass(frozen=True)
class FileRef:
    path: str | Path
    sha256: str
    decoded_sha256: str


@dataclass
class FeatureMetadata:
    q0_meta: list[dict]
    scenes: list[dict]
    sources: dict=field(default_factory=dict)


@dataclass
class FeatureDataset:
    columns: tuple[str,...]
    buy_X: np.ndarray
    sell_X: np.ndarray
    q0_meta: list[dict]
    scenes: list[dict]
    sources: dict=field(default_factory=dict)

    def feature_meta(self) -> FeatureMetadata:
        """
        機能: 教師射影へXを渡さず識別/時計だけのcopyを返す。
        引数: self(FeatureDataset)。返り値: FeatureMetadata。
        """
        return FeatureMetadata(copy.deepcopy(self.q0_meta),copy.deepcopy(self.scenes),copy.deepcopy(self.sources))


@dataclass
class TeacherDataset:
    rows: list[dict]
    labels: np.ndarray
    pair_complete: np.ndarray
    known_at: np.ndarray
    event_to_teacher_index: np.ndarray
    canonical_feature_index: np.ndarray
    counts: dict
    sources: dict=field(default_factory=dict)

    @property
    def canonical_rows(self) -> list[dict]:
        """
        機能: 純teacher selectorへ渡すrows配列を別名で公開する。
        引数: self(TeacherDataset)。返り値: list[dict]。
        """
        return self.rows


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: 物理ファイルを固定bufferで指紋化する。
    引数: path(Path)。返り値: str。
    """
    digest=hashlib.sha256()
    with path.open('rb')as source:
        for block in iter(lambda:source.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()


def _nonfinite(token: str):
    """
    機能: JSON標準外のNaN/Infinityリテラルを拒否する。
    引数: token(str)。返り値: なし、ValueError。
    """
    raise ValueError('JSON非有限値:'+token)


def read_ref(ref: FileRef) -> tuple[object,dict]:
    """
    機能: 物理/解凍SHA・gzip全CRC・前後statを確認してJSONを読む。
    引数: ref(FileRef)。返り値: tuple[object,dict]。解凍副本は書かない。
    """
    path=Path(ref.path);before=path.stat()
    assert all(len(h)==64 and set(h)<=set('0123456789abcdef')for h in (ref.sha256,ref.decoded_sha256))
    assert sha(path)==ref.sha256
    with path.open('rb')as check:compressed=check.read(2)==b'\x1f\x8b'
    with (gzip.open(path,'rb')if compressed else path.open('rb'))as source:body=source.read()
    decoded=hashlib.sha256(body).hexdigest();assert decoded==ref.decoded_sha256
    value=json.loads(body,parse_constant=_nonfinite);after=path.stat()
    fields=('st_dev','st_ino','st_size','st_mtime_ns')
    assert all(getattr(before,k)==getattr(after,k)for k in fields)and sha(path)==ref.sha256
    evidence={'path':str(path.resolve()),'sha256':ref.sha256,'decoded_sha256':decoded,'physical_bytes':before.st_size,'decoded_bytes':len(body),'gzip':compressed,'full_crc_checked':compressed,'stat_before':[getattr(before,k)for k in fields],'stat_after':[getattr(after,k)for k in fields]}
    return value,evidence


def _stamp(quote: dict) -> tuple:
    """
    機能: 有限時刻・非負index・正の物理行を取り出す。
    引数: quote(dict)。返り値: tuple[float,int,int]。
    """
    assert type(quote['time'])in (int,float)and math.isfinite(quote['time'])
    assert type(quote['index'])is int and quote['index']>=0 and type(quote['source_line'])is int and quote['source_line']>0
    return quote['time'],quote['index'],quote['source_line']


def _scenes(fixed: dict,expected_sessions: int | None=None) -> list[dict]:
    """
    機能: Source固定入力から場時計だけをallowlistで射影する。
    引数: fixed(dict)、expected_sessions(int又はNone)。返り値: list[dict]。entries等は返さない。
    """
    scenes=[];seen=set()
    for original in fixed['scenes']:
        scene={k:copy.deepcopy(original[k])for k in ('session','contract','start','end','force_close')}
        assert scene['session']not in seen and scene['session']and scene['contract'];seen.add(scene['session'])
        assert all(type(scene[k])in (int,float)and math.isfinite(scene[k])for k in ('start','end','force_close'))
        assert scene['start']<scene['force_close']<=scene['end']
        if scenes:assert scenes[-1]['end']<=scene['start']and scenes[-1]['session']<scene['session']
        scenes.append(scene)
    assert scenes and(expected_sessions is None or len(scenes)==expected_sessions)
    return scenes


# ----------------------------------------
def feature_dataset_from_objects(features: dict,fixed: dict,expected_sessions: int | None=None,expected_rows: int | None=None) -> FeatureDataset:
    """
    機能: 全q0の両方向100列だけをfloat64へ写しNoneをNaNとして保持する。
    引数: features/fixed(dict)、expected_sessions/expected_rows(int又はNone)。返り値: FeatureDataset。
    """
    assert features['success']and features['trial']==148 and not features['financial_labels_used']and not features['strategy_selected']and features['selected_trade_count']is None
    assert features['catalog_definition_sha256']==CATALOG_DEFINITION_SHA256
    columns=tuple(c['name']for c in features['catalog']);assert len(columns)==len(set(columns))==100 and list(columns)==sorted(columns)
    scenes=_scenes(fixed,expected_sessions);assert features['sessions']==[s['session']for s in scenes];scene_map={s['session']:(i,s)for i,s in enumerate(scenes)}
    n=len(features['rows']);assert expected_rows is None or n==expected_rows
    buy=np.full((n,100),np.nan,dtype=np.float64);sell=buy.copy();meta=[];seen=set();previous=None
    for index,row in enumerate(features['rows']):
        event=row['event_id'];assert event not in seen;seen.add(event);session_index,scene=scene_map[row['session']];assert row['contract']==scene['contract'];time,raw_index,line=_stamp(row['metadata']['q0'])
        assert scene['start']<=time<=scene['end'];order=(session_index,raw_index,line,event)
        if previous is not None:assert order>previous
        previous=order
        for name,side,destination in [('buy',1,buy),('sell',-1,sell)]:
            values=row[name]['x'];assert row[name]['side']==side and len(values)==100
            assert all(v is None or type(v)in (int,float)and math.isfinite(v)for v in values)
            destination[index]=[np.nan if v is None else v for v in values]
        meta.append({'event_id':event,'session':row['session'],'contract':row['contract'],'session_index':session_index,'q0_time':time,'q0_index':raw_index,'q0_line':line})
    return FeatureDataset(columns,buy,sell,meta,scenes)


def load_feature_dataset(features_ref: FileRef,fixed_ref: FileRef,expected_sessions: int=73,expected_rows: int=35339) -> FeatureDataset:
    """
    機能: captureや観測を引数に取らず特徴専用データを読む。
    引数: features_ref/fixed_ref(FileRef)、expected_sessions/expected_rows(int)。返り値: FeatureDataset。
    """
    features,a=read_ref(features_ref);fixed,b=read_ref(fixed_ref);result=feature_dataset_from_objects(features,fixed,expected_sessions,expected_rows);result.sources={'features':a,'fixed':b};return result


# ----------------------------------------
def _label(stream: dict,execution_end: float) -> dict:
    """
    機能: BBO H60完了のclassとendpoint時刻だけを射影する。
    引数: stream(dict)、execution_end(float)。返り値: dict。IFD/金額は参照しない。
    """
    assert stream['status']=='filled'and stream['axis']=='BBO';entry=stream['entry'];_stamp(entry);assert entry['quote_ok']and 0<entry['bid']<entry['ask']
    side=stream['birth']['side'];assert side in (-1,1)and stream['entry_price']==entry['ask'if side==1 else 'bid']
    outcomes=[o for o in stream['outcomes']if o['seconds']==3600];assert len(outcomes)==1;o=outcomes[0];assert o['deadline']==entry['time']+3600
    touches=[t for t in o['touches']if t['width']==125];assert len(touches)==1;t=touches[0];assert type(t['direction'])is int and t['direction']in (-1,0,1)and(t['quote']is None)==(t['direction']==0)
    if t['quote']:
        q=t['quote'];_stamp(q);assert entry['time']<=q['time']<=o['deadline']and q['time']<execution_end and q['index']>entry['index']and q['source_line']>entry['source_line']
    if o['status']!='complete':assert o['endpoint']is None;return {'complete':False,'label':None,'known_at':None}
    q=o['endpoint'];assert q is not None;_stamp(q)
    assert o['deadline']<=q['time']<=o['deadline']+30 and q['time']<execution_end and q['quote_ok']and 0<q['bid']<q['ask']and q['index']>entry['index']and q['source_line']>entry['source_line']
    return {'complete':True,'label':t['direction'],'known_at':q['time']}


def teacher_dataset_from_objects(feature_meta: FeatureMetadata,captures: dict,metadata: dict,fixed: dict,observations: dict) -> TeacherDataset:
    """
    機能: filledの物理q1をcanonical化し両側完了だけに教師を付ける。
    引数: feature_meta(FeatureMetadata)、captures/metadata/fixed/observations(dict)。返り値: TeacherDataset。
    """
    assert isinstance(feature_meta,FeatureMetadata)
    scenes=_scenes(fixed);sessions=[s['session']for s in scenes];assert scenes==feature_meta.scenes and sessions==captures['sessions']==metadata['sessions']
    assert captures['success']and captures['trial']==metadata['trial']==148 and metadata['success']
    assert not captures['financial_labels_used']and not metadata['financial_labels_used']
    assert observations['success']and observations['trial']==133 and observations['source_entry_count']==fixed['expected_entry_count']
    assert [s['session']for s in observations['scenes']]==sessions
    event_map={r['event_id']:(i,r)for i,r in enumerate(feature_meta.q0_meta)};cap_map={r['event_id']:r for r in captures['rows']};assert len(event_map)==len(feature_meta.q0_meta)==len(cap_map)==len(captures['rows'])and set(event_map)==set(cap_map)
    descriptors={r['case_id']:r for r in metadata['population148']['cases']};links={r['event_id']:r for r in metadata['population148']['event_case_links']};assert len(descriptors)==len(metadata['population148']['cases'])and len(links)==len(metadata['population148']['event_case_links'])
    cases={};physical_fixed={}
    for scene,observed,original_scene in zip(scenes,observations['scenes'],fixed['scenes']):
        assert observed['success']and observed['execution_end']==scene['end']-300;entries={e['id']:e for e in original_scene['entries']};assert len(entries)==len(original_scene['entries'])==len(observed['cases'])
        for c in observed['cases']:
            key=c['id'];assert key not in cases and key in entries and key in descriptors;d=descriptors[key];e=entries[key]
            assert d['session']==scene['session']and d['contract']==scene['contract']and d['original_side']==c['original_side']==e['side']
            assert c['original']['entry']==c['reverse']['entry']==e['entry'];q=e['entry'];_stamp(q);assert scene['start']<=q['time']<min(scene['force_close'],scene['end']-3900)
            assert c['original']['birth']['side']==c['original_side']==-c['reverse']['birth']['side']
            cases[key]=(scene,c);physical_fixed[key]=(scene['session'],scene['contract'],*_stamp(q))
    assert len(cases)==fixed['expected_entry_count']and set(cases)==set(descriptors)
    groups={};counts=Counter();seen_links=set()
    for event,(feature_index,q0)in event_map.items():
        cap=cap_map[event];assert cap['session']==q0['session']and cap['contract']==q0['contract']and _stamp(cap['q0'])==(q0['q0_time'],q0['q0_index'],q0['q0_line'])
        assert cap['status']in ('filled','expired','entry_limit','quality_lost','eof_unfilled');counts['capture/'+cap['status']]+=1
        if cap['status']!='filled':assert cap['q1']is None and cap['case_id']is None and event not in links;continue
        case_id=cap['case_id'];scene,c=cases[case_id];link=links[event];seen_links.add(event)
        assert scene['session']==q0['session']and scene['contract']==q0['contract']and cap['q1']==c['original']['entry']and cap['q1']['time']>=q0['q0_time']+1 and cap['q1']['time']<cap['expires']
        buy=cap['buy_stream'];sell=cap['sell_stream'];assert {buy,sell}=={'original','reverse'}and link['case_id']==case_id and link['buy_stream']==buy and link['sell_stream']==sell
        d=descriptors[case_id];assert d['buy_stream']==buy and d['sell_stream']==sell and c[buy]['birth']['side']==1 and c[sell]['birth']['side']==-1
        a=_label(c[buy],scene['end']-300);b=_label(c[sell],scene['end']-300);pair=a['complete']and b['complete'];known=max(a['known_at'],b['known_at'])if pair else None
        fingerprint=(q0['session_index'],a['complete'],b['complete'],a['label'],b['label'],a['known_at'],b['known_at']);physical=physical_fixed[case_id]
        if physical not in groups:groups[physical]={'fingerprint':fingerprint,'entry':copy.deepcopy(cap['q1']),'members':[],'pair':pair,'known_at':known,'buy':a['label']if pair else None,'sell':b['label']if pair else None}
        group=groups[physical];assert group['fingerprint']==fingerprint and group['entry']==cap['q1'],'同物理q1の教師/既知時刻矛盾'
        group['members'].append({'feature_index':feature_index,'case_id':case_id,**copy.deepcopy(q0)})
    assert seen_links==set(links)
    canonical=[]
    for group in groups.values():
        members=sorted(group['members'],key=lambda r:(r['q0_index'],r['q0_line'],r['event_id']));first=members[0]
        canonical.append({'case_id':first['case_id'],'event_id':first['event_id'],'session_index':first['session_index'],'session':first['session'],'contract':first['contract'],'q0_index':first['q0_index'],'q0_line':first['q0_line'],'q0_time':first['q0_time'],'known_at':group['known_at'],'pair_complete':bool(group['pair']),'label_buy':group['buy'],'label_sell':group['sell'],'feature_index':first['feature_index'],'aliases':[r['event_id']for r in members],'alias_feature_indices':[r['feature_index']for r in members],'case_aliases':sorted({r['case_id']for r in members})})
        counts['pair_complete'if group['pair']else 'pair_incomplete']+=1;counts['one_side_complete']+=int(group['fingerprint'][1]!=group['fingerprint'][2])
    canonical.sort(key=lambda r:(r['session_index'],r['q0_index'],r['q0_line'],r['event_id'],r['case_id']))
    event_to_teacher=np.full(len(feature_meta.q0_meta),-1,dtype=np.int64);labels=np.full((len(canonical),2),np.nan,dtype=np.float64);known_at=np.full(len(canonical),np.nan,dtype=np.float64)
    for i,row in enumerate(canonical):
        event_to_teacher[row['alias_feature_indices']]=i
        if row['pair_complete']:labels[i]=[row['label_buy'],row['label_sell']];known_at[i]=row['known_at']
        else:assert row['label_buy']is None and row['label_sell']is None and row['known_at']is None
    counts.update({'feature_rows':len(feature_meta.q0_meta),'canonical_cases':len(canonical),'filled_events':int(np.sum(event_to_teacher>=0)),'unfilled_features':int(np.sum(event_to_teacher<0)),'extra_alias_events':int(np.sum(event_to_teacher>=0))-len(canonical),'observation_cases_without_feature_capture':len(cases)-len({cap['case_id']for cap in cap_map.values()if cap['status']=='filled'})})
    return TeacherDataset(canonical,labels,np.array([r['pair_complete']for r in canonical],dtype=np.bool_),known_at,event_to_teacher,np.array([r['feature_index']for r in canonical],dtype=np.int64),dict(counts))


def project_teacher(feature_meta: FeatureMetadata,captures_ref: FileRef,metadata_ref: FileRef,fixed_ref: FileRef,observations_ref: FileRef) -> TeacherDataset:
    """
    機能: 特徴行列を受けず固定4入力から教師専用データを読む。
    引数: feature_meta(FeatureMetadata)、captures_ref/metadata_ref/fixed_ref/observations_ref(FileRef)。返り値: TeacherDataset。
    """
    captures,a=read_ref(captures_ref);metadata,b=read_ref(metadata_ref);fixed,c=read_ref(fixed_ref);observations,d=read_ref(observations_ref)
    assert observations['input_sha256']==fixed_ref.decoded_sha256==metadata['fixed_input_sha256']
    result=teacher_dataset_from_objects(feature_meta,captures,metadata,fixed,observations);result.sources={'captures':a,'metadata':b,'fixed':c,'observations':d};return result


# ----------------------------------------
def _cache_dir(path: str | Path) -> Path:
    """
    機能: work内の未作成先だけをcache保存先として確定する。
    引数: path(str又はPath)。返り値: Path。
    """
    target=Path(path).resolve();root=WORK_ROOT.resolve();assert target!=root and target.is_relative_to(root),'cacheはwork配下のみ'
    target.mkdir(parents=True,exist_ok=False);return target


def save_feature_cache(dataset: FeatureDataset,output_dir: str | Path) -> dict:
    """
    機能: 教師を含まない特徴npzとflat metadataをworkだけへ保存する。
    引数: dataset(FeatureDataset)、output_dir(str又はPath)。返り値: dict。
    """
    target=_cache_dir(output_dir);npz=target/'features.npz';meta=target/'features_meta.json'
    with npz.open('xb')as source:np.savez_compressed(source,buy_X=dataset.buy_X,sell_X=dataset.sell_X,columns=np.array(dataset.columns,dtype=np.str_))
    with meta.open('x',encoding='utf-8')as source:json.dump({'success':True,'trial':151,'label_fields_present':False,'q0_meta':dataset.q0_meta,'scenes':dataset.scenes,'sources':dataset.sources},source,ensure_ascii=False,indent=2,allow_nan=False);source.write('\n')
    return {'npz':str(npz),'npz_sha256':sha(npz),'metadata':str(meta),'metadata_sha256':sha(meta)}


def save_teacher_cache(dataset: TeacherDataset,output_dir: str | Path) -> dict:
    """
    機能: 教師metaとside順BUY/SELLの配列を特徴cacheから分離保存する。
    引数: dataset(TeacherDataset)、output_dir(str又はPath)。返り値: dict。
    """
    target=_cache_dir(output_dir);npz=target/'teachers.npz';meta=target/'teachers_meta.json'
    with npz.open('xb')as source:np.savez_compressed(source,labels=dataset.labels,pair_complete=dataset.pair_complete,known_at=dataset.known_at,event_to_teacher_index=dataset.event_to_teacher_index,canonical_feature_index=dataset.canonical_feature_index,side_order=np.array(SIDE_ORDER,dtype=np.int8))
    with meta.open('x',encoding='utf-8')as source:json.dump({'success':True,'trial':151,'rows':dataset.rows,'counts':dataset.counts,'sources':dataset.sources,'side_order':SIDE_ORDER},source,ensure_ascii=False,indent=2,allow_nan=False);source.write('\n')
    return {'npz':str(npz),'npz_sha256':sha(npz),'metadata':str(meta),'metadata_sha256':sha(meta)}
