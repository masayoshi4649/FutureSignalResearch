"""自然金融を使わず、175経路評価を独立一覧法と人工境界で確認する。"""
from pathlib import Path
from datetime import date, timedelta
from itertools import product
import copy
import hashlib
import importlib.util
import json
import random
import statistics

import path175 as P

ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location('metrics173_for175_artificial', ROOT/'work/173追加なしの評価/metrics173.py')
M = importlib.util.module_from_spec(SPEC); SPEC.loader.exec_module(M)


def make_group(values: list, active: list | None = None) -> dict:
    """
    機能: 人工1日1取得の入力を既存純metricsへ渡す。
    引数: values(list[float|None])は場収支、active(list[bool]|None)は取得有無。
    返り値: dictはDAY群。非取得場は0円として対象へ残す。
    """
    scenes = [(date(2020,1,1)+timedelta(days=i)).isoformat()+'_Day' for i in range(len(values))]
    if active is None:active=[True]*len(values)
    positions=[i for i,v in enumerate(active) if v]
    net=[values[i] for i in positions]
    label=[2 if v is None else 1 if v>0 else -1 if v<0 else 0 for v in net]
    metrics=M.evaluate_metrics(net,[v is not None for v in net],label,[scenes[i] for i in positions],
        [0]*len(net),[0]*len(net),{'DAY':scenes,'PRE':[],'POST':[]},{'DAY':float(len(values)),'PRE':0.0,'POST':0.0})
    return metrics['session_groups_required']['DAY']


def brute(values: list) -> dict:
    """
    機能: すべてのピーク底の組を列挙し、独立に場末DDと回復を求める。
    引数: values(list[float])は有限人工損益。
    返り値: dictはDD・開始来最低・回復までの位置。
    """
    cumulative=[0.0]
    for value in values:cumulative.append(cumulative[-1]+value)
    candidates=[(cumulative[i]-cumulative[j],i,j) for i in range(len(cumulative)) for j in range(i+1,len(cumulative))]
    maximum=max((max(0.0,v[0]) for v in candidates),default=0.0)
    return {'dd':maximum,'minimum':min(cumulative),'net':sum(values),
        'negative':sum(v<0 for v in cumulative[1:])}


def main() -> None:
    """
    機能: DD一覧法、未知の区別、窓中央値、支持と非静観順位を人工確認する。
    引数: なし。
    返り値: None。人工JSONとSource指紋だけを保存する。
    """
    cases=0
    for n in range(8):
        for values in product((-3.0,0.0,2.0),repeat=n):
            rows=[{'scene':str(i),'known_net':v,'all_count':1} for i,v in enumerate(values)]
            actual=P._path(rows,True);expected=brute(list(values))
            assert actual['max_drawdown_amount']==expected['dd']
            assert actual['initial_minimum']==expected['minimum']
            assert actual['net']==expected['net'] and actual['below_initial_zero_scenes']==expected['negative']
            worst=actual['max_drawdown']
            if worst is not None:
                cs=actual['cumulative'];peak=worst['peak_value'];bottom=worst['trough_index']
                expected_recovery=next((i for i in range(bottom+1,len(cs)) if cs[i]>=peak),None)
                assert worst['recovery_index']==expected_recovery
            cases+=1
    # ----------------------------------------
    group=make_group([-4,1,1,3,-8,2,2,4,1,2,0,3])
    before=copy.deepcopy(group);risk=P.path_summary(group)
    assert risk['exact_path'] is not None and risk['exact_path']['max_drawdown_amount']==8
    assert risk['windows']['5']['all_window_count']==8 and risk['windows']['10']['all_window_count']==3
    assert risk['windows']['5']['worst_median_window']['session_median']==1
    assert group==before
    assert risk['support']['eligible_scene_count']==12 and risk['support']['participating_scene_count']==12
    changed=make_group([-4,1,None,3,-8,2,2,4,1,2,0,3])
    unknown=P.path_summary(changed)
    assert unknown['exact_path'] is None and unknown['known_contribution']['exact'] is False
    assert unknown['complete_prefix']['scene_count']==2
    assert unknown['complete_prefix']['path']['net']==-3
    assert unknown['windows']['5']['unknown_window_count']==3
    assert len(unknown['complete_runs'])==2
    assert unknown['complete_runs'][1]['path_reset_to_zero']['exact'] is True
    assert unknown['complete_runs'][1]['scene_count']==9
    empty=P.path_summary(make_group([0]*40,[False]*40))
    assert empty['exact_path']['max_drawdown_amount']==0
    assert empty['support']['phase_diagnostic_goal_met'] is False
    assert empty['windows']['5']['no_acquisition_complete_count']==36
    positive_group=make_group([5]*40)
    positive=P.path_summary(positive_group)
    assert P.candidate_key(positive_group,positive,'DAY') < P.candidate_key(make_group([0]*40,[False]*40),empty,'DAY')
    half=P.path_summary(make_group([5 if i%2==0 else 0 for i in range(40)],[i%2==0 for i in range(40)]))
    assert half['support']['phase_diagnostic_goal_met'] is True
    assert half['support']['acquisitions_per_scene']==.5
    phase_group=make_group([5]*19+[-1]+[0]*20,[True]*20+[False]*20)
    phase_risk=P.path_summary(phase_group)
    assert phase_group['decision']['status']=='不適合'
    assert P.candidate_key(phase_group,phase_risk,'PRE')[1]==-1
    assert P.candidate_key(phase_group,phase_risk,'DAY')[1]==0
    unknown_group=make_group([None]*40)
    unknown_group['trades']['IFD_FIRSTFANC']={'F':40,'A':0,'N':0,'C':0,'reached_count':40,'first_f_rate_reached':1.0}
    unknown_risk=P.path_summary(unknown_group)
    assert P.candidate_key(unknown_group,unknown_risk,'PRE')[1]==0
    assert P.candidate_key(positive_group,positive,'PRE') < P.candidate_key(unknown_group,unknown_risk,'PRE')
    # ----------------------------------------
    randomizer=random.Random(175)
    prefixes=0;windows=0
    for _ in range(200):
        values=[float(randomizer.randint(-10,15)) for _ in range(35)]
        group=make_group(values);risk=P.path_summary(group)
        split=randomizer.randint(1,34)
        earlier=P.path_summary(make_group(values[:split]))
        assert earlier['known_contribution']['cumulative']==risk['known_contribution']['cumulative'][:split]
        old_blocks={r['block_start']:r for r in earlier['support']['blocks']}
        full_blocks={r['block_start']:r for r in risk['support']['blocks']}
        for key,block in old_blocks.items():
            if block['block_end'] < earlier['scene_order'][-1][:10]:assert block==full_blocks[key]
        prefixes+=1
        for width in (5,10):
            actual=risk['windows'][str(width)]
            sums=[sum(values[i:i+width]) for i in range(len(values)-width+1)]
            medians=[statistics.median(values[i:i+width]) for i in range(len(values)-width+1)]
            assert actual['negative_net_count']==sum(v<0 for v in sums)
            assert actual['negative_median_count']==sum(v<0 for v in medians)
            assert actual['worst_net_window']['net']==min(sums)
            assert actual['worst_median_window']['session_median']==min(medians)
            windows+=len(sums)
    permuted=copy.deepcopy(group);permuted['sessions']['rows'].reverse()
    assert P.path_summary(permuted)==P.path_summary(group)
    invalid=copy.deepcopy(group);invalid['sessions']['rows'][0]['unknown_count']=1;invalid['sessions']['rows'][0]['all_net']=0
    try:P.path_summary(invalid)
    except ValueError:pass
    else:raise AssertionError('未知0円を拒否しなかった')
    result={'成功':True,'自然金融未入力':True,'DD一覧法パターン':cases,'未来追加とprefix':prefixes,
        '独立窓計算':windows,'未知prefixと完全窓の分離':True,'0取得場保持と全静観降格':True,
        '14日固定暦ブロック':True,'入力不変と日付順正規化':True,
        'Source':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(P.__file__),Path(__file__)]}}
    target=Path(__file__).resolve().parent/'人工結果.json'
    target.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':
    main()
