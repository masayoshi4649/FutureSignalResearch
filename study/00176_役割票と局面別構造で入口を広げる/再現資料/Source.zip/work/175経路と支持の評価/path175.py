"""175向けの純粋な経路・支持評価。自然データやファイルを読み込まない。"""
from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping
from datetime import date, timedelta
import math
import statistics

VERSION = '175経路と支持1'


def _date(value: object) -> date | None:
    """
    機能: 日付又は場識別子の先頭から暦日を読む。
    引数: value(object)はdate又はYYYY-MM-DDで始まる文字列。
    返り値: date|None。暦日を判定できない場合はNone。
    """
    if isinstance(value, date):
        return value
    try:
        return date.fromisoformat(str(value)[:10])
    except (ValueError, TypeError):
        return None


def _path(rows: list[dict], exact: bool) -> dict:
    """
    機能: 場末累計の初期損失・DD・水面下と回復を計算する。
    引数: rows(list[dict])は時刻順の場、exact(bool)は全件確定か既知寄与か。
    返り値: dict。空集合の損益/値幅は0、支持数は別に保持する。
    """
    cumulative = 0.0; peak = 0.0; peak_index = -1; trough = 0.0; trough_index = None
    curves = []; worst = None; episodes = []; water_start = None
    negative_streak = 0; max_negative_streak = 0; below_zero = 0
    for index, row in enumerate(rows):
        value = row['known_net']; cumulative += value; curves.append(cumulative)
        if cumulative < trough:
            trough = cumulative; trough_index = index
        below_zero += cumulative < 0
        if cumulative < peak:
            if water_start is None:
                water_start = peak_index
            drawdown = peak - cumulative
            if worst is None or drawdown > worst['amount']:
                worst = {'amount': drawdown, 'peak_index': peak_index, 'trough_index': index,
                    'peak_scene': None if peak_index < 0 else rows[peak_index]['scene'],
                    'trough_scene': row['scene'], 'peak_value': peak, 'trough_value': cumulative}
        else:
            if water_start is not None:
                episodes.append({'start_index': water_start, 'recovery_index': index,
                    'underwater_scenes': index - water_start - 1,
                    'scenes_to_recovery': index - water_start, 'recovered': True})
                water_start = None
            peak = cumulative; peak_index = index
        negative_streak = negative_streak + 1 if value < 0 else 0
        max_negative_streak = max(max_negative_streak, negative_streak)
    if water_start is not None:
        episodes.append({'start_index': water_start, 'recovery_index': None,
            'underwater_scenes': len(rows) - 1 - water_start,
            'scenes_to_recovery': None, 'recovered': False})
    if worst is not None:
        reached = [i for i in range(worst['trough_index'] + 1, len(rows)) if curves[i] >= worst['peak_value']]
        recovery = reached[0] if reached else None
        worst.update({'recovery_index': recovery,
            'recovery_scene': None if recovery is None else rows[recovery]['scene'],
            'scenes_from_peak_to_recovery': None if recovery is None else recovery - worst['peak_index'],
            'scenes_from_trough_to_recovery': None if recovery is None else recovery - worst['trough_index']})
    initial_crossings = [i for i, value in enumerate(curves) if value >= 0]
    last_negative = max((i for i, value in enumerate(curves) if value < 0), default=None)
    sustained = None if last_negative is None or last_negative == len(rows) - 1 else last_negative + 1
    return {'exact': exact, 'meaning': '全件確定の場末実現損益' if exact else '既知寄与だけ。未知を0円と確定した経路ではない。',
        'scene_count': len(rows), 'acquisition_count': sum(r['all_count'] for r in rows),
        'net': cumulative, 'cumulative': curves,
        'initial_minimum': trough, 'initial_minimum_index': trough_index,
        'initial_minimum_scene': None if trough_index is None else rows[trough_index]['scene'],
        'below_initial_zero_scenes': below_zero,
        'first_nonnegative_scene': None if not initial_crossings else rows[initial_crossings[0]]['scene'],
        'sustained_nonnegative_scene': None if sustained is None else rows[sustained]['scene'],
        'max_drawdown': worst, 'max_drawdown_amount': 0.0 if worst is None else worst['amount'],
        'max_underwater_scenes': max((e['underwater_scenes'] for e in episodes), default=0),
        'unrecovered_at_end': bool(episodes and not episodes[-1]['recovered']),
        'max_consecutive_negative_scenes': max_negative_streak,
        'worst_scene_net': min((r['known_net'] for r in rows), default=None), 'underwater_episodes': episodes}


def _windows(rows: list[dict], width: int) -> dict:
    """
    機能: 連続場の完全既知窓だけで収支と場中央値を評価する。
    引数: rows(list[dict])は全場、width(int)は窓場数。
    返り値: dict。未知窓を分母から隠さず、重なる窓を独立とは扱わない。
    """
    count = max(0, len(rows) - width + 1); complete = []; unknown = 0
    for start in range(count):
        selected = rows[start:start + width]
        if any(r['unknown_count'] for r in selected):
            unknown += 1
            continue
        values = [r['known_net'] for r in selected]
        complete.append({'start_scene': selected[0]['scene'], 'end_scene': selected[-1]['scene'],
            'net': sum(values), 'session_median': statistics.median(values),
            'acquisition_count': sum(r['all_count'] for r in selected)})
    negative = sum(r['net'] < 0 for r in complete)
    negative_median = sum(r['session_median'] < 0 for r in complete)
    return {'width_scenes': width, 'all_window_count': count, 'complete_window_count': len(complete),
        'unknown_window_count': unknown, 'negative_net_count': negative,
        'negative_net_share_complete': negative / len(complete) if complete else None,
        'negative_median_count': negative_median,
        'negative_median_share_complete': negative_median / len(complete) if complete else None,
        'no_acquisition_complete_count': sum(r['acquisition_count'] == 0 for r in complete),
        'worst_net_window': min(complete, key=lambda r: (r['net'], r['start_scene'])) if complete else None,
        'worst_median_window': min(complete, key=lambda r: (r['session_median'], r['start_scene'])) if complete else None,
        'median_of_complete_window_net': statistics.median(r['net'] for r in complete) if complete else None,
        'windows': complete, 'overlapping_windows_are_independent': False}


def path_summary(group: Mapping, scene_dates: Mapping[str, str] | None = None,
                 calendar_block_days: int = 14) -> dict:
    """
    機能: metrics173の一群へ、正確/未知寄与の経路と参加分布を追加する。
    引数: group(Mapping)はtrades/sessions.rowsを持つ群、scene_dates(Mapping[str,str]|None)は暦日の明示、
          calendar_block_days(int)は1970-01-05起算の非重複ブロック日数。既定14日。
    返り値: dict。exact_pathは全場既知のときだけ。未知を除いた完全窓と初回未知前区間を別に残す。
    """
    if type(calendar_block_days) is not int or calendar_block_days <= 0:
        raise ValueError('暦ブロック日数は正の整数。')
    rows = []
    for source in group['sessions']['rows']:
        row = dict(source); scene = row['scene']
        if not isinstance(scene, str) or not scene:
            raise ValueError('sceneは空でない実セッションID文字列。')
        for field in ('all_count', 'unknown_count'):
            if type(row[field]) is not int or row[field] < 0:
                raise ValueError('場の取得/未知件数は0以上の整数。')
        if row['unknown_count'] > row['all_count']:
            raise ValueError('場の未知件数が取得数を超えている。')
        value = row['known_net']
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError('場の既知寄与は有限実数。')
        row['known_net'] = float(value)
        if not row['all_count'] and (row['unknown_count'] or row['known_net']):
            raise ValueError('無取得場は未知0・寄与0で残す。')
        if 'all_net' in row and ((row['unknown_count'] > 0) != (row['all_net'] is None)):
            raise ValueError('未知のある場の全件収支はNone。')
        row['_date'] = _date(scene_dates.get(scene) if scene_dates is not None else scene)
        rows.append(row)
    if len({r['scene'] for r in rows}) != len(rows):
        raise ValueError('同一群に場IDが重複。')
    dated = all(r['_date'] is not None for r in rows)
    if dated:
        rows.sort(key=lambda r: (r['_date'], r['scene']))
    if len(rows) != group['sessions']['eligible_count']:
        raise ValueError('eligible全場数とrowsが不一致。')
    count = sum(r['all_count'] for r in rows); unknown = sum(r['unknown_count'] for r in rows)
    if count != group['trades']['all_count'] or unknown != group['trades']['unknown_count']:
        raise ValueError('建玉の取得数/未知数と場集計が不一致。')
    prefix = next((i for i, r in enumerate(rows) if r['unknown_count']), len(rows))
    exact_path = _path(rows, True) if not unknown else None
    known_path = _path(rows, not unknown)
    complete_runs = []; start = None
    for index in range(len(rows) + 1):
        complete = index < len(rows) and not rows[index]['unknown_count']
        if complete and start is None:
            start = index
        elif not complete and start is not None:
            selected = rows[start:index]
            complete_runs.append({'start_scene': selected[0]['scene'], 'end_scene': selected[-1]['scene'],
                'scene_count': len(selected), 'path_reset_to_zero': _path(selected, True)})
            start = None
    blocks = defaultdict(list); anchor = date(1970, 1, 5)
    if dated:
        for row in rows:
            index = (row['_date'] - anchor).days // calendar_block_days
            blocks[index].append(row)
    block_rows = []
    for index, selected in sorted(blocks.items()):
        begin = anchor + timedelta(days=index * calendar_block_days)
        active = sum(r['all_count'] > 0 for r in selected)
        block_rows.append({'block_start': begin.isoformat(), 'block_end': (begin + timedelta(days=calendar_block_days - 1)).isoformat(),
            'eligible_scenes': len(selected), 'participating_scenes': active,
            'participating_fraction': active / len(selected),
            'acquisition_count': sum(r['all_count'] for r in selected),
            'unknown_count': sum(r['unknown_count'] for r in selected),
            'known_net': sum(r['known_net'] for r in selected)})
    active = sum(r['all_count'] > 0 for r in rows)
    gross_profit = float(group['trades']['known_profit'])
    acquisitions_sorted = sorted((r['all_count'] for r in rows), reverse=True)
    active_blocks = sum(r['acquisition_count'] > 0 for r in block_rows)
    return {'version': VERSION, 'calendar_dates_available': dated, 'scene_order': [r['scene'] for r in rows],
        'exact_path': exact_path, 'known_contribution': known_path,
        'complete_prefix': {'scene_count': prefix, 'first_unknown_scene': rows[prefix]['scene'] if prefix < len(rows) else None,
            'path': _path(rows[:prefix], True)},
        'complete_runs': complete_runs, 'windows': {str(w): _windows(rows, w) for w in (5, 10)},
        'support': {'eligible_scene_count': len(rows), 'acquisition_count': count, 'unknown_count': unknown,
            'participating_scene_count': active, 'zero_scene_count': len(rows) - active,
            'participating_fraction': active / len(rows) if rows else None,
            'acquisitions_per_scene': count / len(rows) if rows else None,
            'phase_diagnostic_goal_met': bool(rows and active / len(rows) >= .5 and count / len(rows) >= .5),
            'goal_is_hard_adoption_rule': False,
            'acquisition_top1_scene_share': acquisitions_sorted[0] / count if count else None,
            'acquisition_top3_scene_share': sum(acquisitions_sorted[:3]) / count if count else None,
            'calendar_block_days': calendar_block_days, 'calendar_anchor': anchor.isoformat(),
            'eligible_calendar_blocks': len(block_rows), 'active_calendar_blocks': active_blocks,
            'active_block_fraction': active_blocks / len(block_rows) if block_rows else None,
            'minimum_participating_fraction_per_block': min((r['participating_fraction'] for r in block_rows), default=None),
            'blocks': block_rows},
        'known_drawdown_to_known_profit': known_path['max_drawdown_amount'] / gross_profit if gross_profit > 0 else None,
        'exact_drawdown_to_known_profit': None if exact_path is None or gross_profit <= 0 else exact_path['max_drawdown_amount'] / gross_profit,
        'notes': ['場末実現収支であり建玉保有中の時価DDではない。', '未知後の既知寄与を全件のDD・回復と称さない。',
            '完全区間の経路は各区間で0へリセットした局所診断。区間間を繋いだ全件経路ではない。',
            '暦ブロックは固定起算・非重複。5/10場窓は重なるため独立試行数ではない。']}


def candidate_key(group: Mapping, risk: Mapping, field: str) -> tuple:
    """
    機能: 一つの選択期間だけの共同目標・支持・経路から昇順の固定順位を作る。
    引数: group(Mapping)は一群、risk(Mapping)はpath_summaryの返り値、field(str)はDAY/NIGHT/PRE/POST。
    返り値: tuple。全静観を優先せず、硬いDD金額閾値は設けない。ID同点処理は呼出側が行う。
    """
    if field not in ('DAY', 'NIGHT', 'PRE', 'POST'):
        raise ValueError('fieldはDAY/NIGHT/PRE/POST。')
    support = risk['support']; trade = group['trades']; fa = trade['IFD_FIRSTFANC']
    count = trade['all_count']; rate = fa['first_f_rate_reached']
    dual = group['decision']['status'] == '適合'
    participation = support['zero_scene_count'] == 0 if field in ('DAY', 'NIGHT') else support['phase_diagnostic_goal_met']
    rate_goal = rate is not None and rate >= .7
    required_dual = dual if field in ('DAY', 'NIGHT') else True
    financial_evidence = trade['known_count'] > 0 and trade['known_net'] > 0
    joint = bool(count and financial_evidence and required_dual and participation and rate_goal)
    complete_windows = [r for r in risk['windows'].values() if r['complete_window_count']]
    unknown_ratio = trade['unknown_count'] / count if count else 1.0
    negative_windows = max((w['negative_net_share_complete'] for w in complete_windows), default=math.inf)
    negative_medians = max((w['negative_median_share_complete'] for w in complete_windows), default=math.inf)
    worst_sum = min((w['worst_net_window']['net'] for w in complete_windows), default=None)
    profit = trade['known_profit']
    loss_burden = -min(0.0, worst_sum) / profit if worst_sum is not None and profit > 0 else math.inf
    path = risk['exact_path'] if risk['exact_path'] is not None else risk['known_contribution']
    dd_ratio = path['max_drawdown_amount'] / profit if profit > 0 else math.inf
    initial_ratio = -path['initial_minimum'] / profit if profit > 0 else math.inf
    return (-int(count > 0), -int(joint), -int(required_dual), -int(rate_goal), -int(participation),
        -min(support['active_calendar_blocks'], 2), -(support['active_block_fraction'] or 0),
        -(support['minimum_participating_fraction_per_block'] or 0), unknown_ratio,
        negative_windows, negative_medians, loss_burden, dd_ratio,
        int(path['unrecovered_at_end']), path['max_underwater_scenes'], initial_ratio, -int(dual),
        -(rate or 0), -(support['acquisitions_per_scene'] or 0), -trade['known_net'])
