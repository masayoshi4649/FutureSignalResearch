"""前48枠を優先する別選択部品を旧Sourceと人工統計で固定する。"""
from pathlib import Path
from types import SimpleNamespace
import ast
import copy
import hashlib
import importlib.util
import json
import sys

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OLD = ROOT / 'work/172ナイト入口探索/数量比較する.py'
NEW = ROOT / 'work/172ナイト入口探索/補正選択.py'
SELECTOR = ROOT / 'work/172ナイト基礎診断/selector172.py'


def sha(path: Path) -> str:
    """
    機能: Sourceを物理指紋化する。
    引数: path(Path)はSource。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def module(path: Path, name: str) -> object:
    """
    機能: 自然入力を持たない指定moduleを読み込む。
    引数: path(Path)、name(str)はSourceと識別名。
    返り値: objectは純module。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def old_functions(selector: object) -> dict:
    """
    機能: 旧Sourceのselect/supportedだけをASTから読み込む。
    引数: selector(object)は純Wilson計算を持つ部品。
    返り値: dictは旧選択関数。prepare/initialize/mainは実行しない。
    """
    tree = ast.parse(OLD.read_text(encoding='utf-8'))
    body = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in {'supported', 'select'}]
    namespace = {'R': SimpleNamespace(module=lambda path, name: selector), 'ROOT': ROOT}
    exec(compile(ast.Module(body=body, type_ignores=[]), str(OLD), 'exec'), namespace)
    return namespace


def stats(f: int, a: int, count: int, scenes: int, share: float = .2) -> dict:
    """
    機能: 選択基準の境界を持つ人工帯統計を作る。
    引数: f/a/count/scenes(int)、share(float)は件数と集中率。
    返り値: dictは人工選択入力。
    """
    return {'count': count, 'F': f, 'A': a, 'C': 0, 'scenes': scenes, 'profit': 2000, 'loss': 1000,
            'max_scene_share': share, 'rate': f / (f+a) if f+a else None, 'per_hour': .5}


def row(identity: str, full: dict, front: dict | None = None) -> dict:
    """
    機能: 全期と前48の人工政策を構築する。
    引数: identity(str)、full(dict)、front(dict|None)は識別と人工統計。
    返り値: dictは二帯置換のselect入力。
    """
    front = stats(10, 10, 24, 5) if front is None else front
    return {'id': identity, 'candidate': {'PRE': {'key': identity + 'P'}, 'POST': {'key': identity + 'Q'}},
            'cap10': {'periods': {
                '全期': {'PRE': {'全部': copy.deepcopy(full)}, 'POST': {'全部': copy.deepcopy(full)},
                         'NIGHT': {'全部': {'per_hour': full['per_hour']}}},
                '前48場': {'PRE': {'全部': copy.deepcopy(front)}, 'POST': {'全部': copy.deepcopy(front)},
                           'NIGHT': {'全部': {'per_hour': front['per_hour']}}}}}}


def main() -> None:
    """
    機能: 旧バグ再現と修正後の前48保持、支持順位同体を人工固定する。
    引数: なし。自然ファイルを読まずRoot旧Sourceを変更しない。
    返り値: None。補正選択の人工確認.jsonとSourceSHAを保存する。
    """
    sys.stdout.reconfigure(encoding='utf-8')
    paths = [OLD, NEW, SELECTOR, Path(__file__)]
    source = {p.relative_to(ROOT).as_posix(): sha(p) for p in paths}
    selector = module(SELECTOR, 'pure_selector172_corrected_review')
    old = old_functions(selector)['select']
    new = module(NEW, 'corrected_selection172').select
    rows = [row('FULL1', stats(18, 7, 40, 10)), row('FULL2', stats(19, 6, 40, 10)),
            row('NEAR1', stats(650, 350, 1000, 10)), row('NEAR2', stats(660, 340, 1000, 10)),
            row('NEAR3', stats(670, 330, 1000, 10)),
            row('FRONT', stats(24, 1, 30, 6), stats(24, 1, 25, 6))]
    previous, corrected = old(rows), new(rows)
    assert previous['参考適用ID'] == ['FULL2', 'FULL1', 'NEAR3', 'NEAR2', 'NEAR1']
    assert corrected['参考適用ID'] == ['FULL2', 'FRONT', 'FULL1', 'NEAR3', 'NEAR2']
    assert previous['前48固定'] == corrected['前48固定'] == 'FRONT'
    assert previous['主案'] == corrected['主案'] == 'FULL2'
    assert new([])['主案'] is None and new([])['参考適用ID'] == []
    assert new([row('近傍だけ', stats(26, 14, 50, 10))])['主案'] is None
    same = new([row('主と前半が同じ', stats(28, 12, 50, 10), stats(18, 7, 25, 6))])
    assert same['主案'] == same['前48固定'] and same['参考適用ID'] == [same['主案']]
    front_only = new([row('前半だけ', stats(20, 20, 40, 10), stats(18, 7, 25, 6))])
    assert front_only['主案'] is None and front_only['参考適用ID'] == ['前半だけ']
    # ----------------------------------------
    # 2,000人工政策群で支持数・主/前半順位と指定順を旧Sourceから照合する。
    rng = np.random.default_rng(202611151725)
    count = 0
    for sample in range(2000):
        generated = []
        for index in range(int(rng.integers(0, 35))):
            full_count = int(rng.integers(20, 1000))
            f = int(rng.integers(0, full_count + 1))
            full = stats(f, full_count - f, full_count, int(rng.integers(5, 37)), float(rng.choice([.2, .25, .26])))
            front_count = int(rng.integers(10, 100))
            ff = int(rng.integers(0, front_count + 1))
            front = stats(ff, front_count - ff, front_count, int(rng.integers(4, 25)))
            for values in (full, front):
                values['C'] = int(rng.integers(0, 4))
                values['profit'] = int(rng.integers(0, 2501))
            candidate = row(f'人工{index:03}', full, front)
            if rng.random() < .15:
                candidate['candidate']['PRE' if rng.random() < .5 else 'POST'] = None
            if rng.random() < .3:
                candidate['cap10']['periods']['全期']['POST']['全部']['rate'] = .64
            generated.append(candidate)
        before = copy.deepcopy(generated)
        a, b = old(generated), new(generated)
        assert generated == before
        for key in ('主案', '前48固定', '両帯支持70以上数', '両帯支持65以上数', '前48支持65以上数', '注意'):
            assert a[key] == b[key], (sample, key)
        expected_order = ([a['主案']] if a['主案'] else []) + ([a['前48固定']] if a['前48固定'] else []) + a['参考適用ID']
        assert b['参考適用ID'] == list(dict.fromkeys(expected_order))[:5]
        assert len(b['参考適用ID']) == len(set(b['参考適用ID'])) <= 5
        assert b['主案'] is None or b['主案'] in b['参考適用ID']
        assert b['前48固定'] is None or b['前48固定'] in b['参考適用ID']
        count += len(generated)
    assert all(sha(ROOT / path) == digest for path, digest in source.items())
    proof = {'成功': True, '自然値読取': False, 'Root旧Source変更': False,
             '補正SourceSHA256': sha(NEW), 'Source': source,
             '修正前': previous, '修正後': corrected,
             '原因': '旧wantedはfull2とnear3を先に積み、重複除去後の最大5で末尾の前48固定を落とし得た。',
             '修正': 'primary→front固定→full上位2→near上位3の順で重複除去し最大5。支持と順位は不変。',
             '人工政策群': 2000, '照合政策数': count,
             '空集合と主null': True, '前48単独を保持': True, '主と前48が同じ場合重複なし': True,
             '支持数と主前48順位は旧同体': True, '前半gate追加なし': True,
             '入力統計不変': True, '最大5と主前48保持': True}
    (HERE / '補正選択の人工確認.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (HERE / '補正選択_SourceSHA256.json').write_text(json.dumps(source, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '補正SourceSHA256': sha(NEW), '人工政策群': 2000,
                      '照合政策数': count, '修正前ID': previous['参考適用ID'], '修正後ID': corrected['参考適用ID']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
