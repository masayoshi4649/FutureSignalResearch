"""Root参考適用後の追加7を封印出生・共用numeric・一覧時計で独立確認する。"""
from pathlib import Path
import importlib.util
import json
import sys
import time

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
AUTHOR = ROOT / 'work/172ナイト入口探索'


def module(path: Path, name: str) -> object:
    """
    機能: mainを呼ばず独立部品又は共用contextを読み込む。
    引数: path(Path)、name(str)はSourceと識別名。
    返り値: objectはmodule。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


def main() -> None:
    """
    機能: 固定6政策の追加7について全engine・取得8属性・金融を別実装照合する。
    引数: なし。Root適用完了後に追加7読取を承認された範囲だけを使う。
    返り値: None。追加7独立検算.jsonと追加7一覧再生結果.json.gzを保存する。
    """
    sys.stdout.reconfigure(encoding='utf-8')
    independent = module(HERE / '旧73を独立検算する.py', 'list_qa172_shared')
    paths = [Path(__file__), HERE / '旧73を独立検算する.py', AUTHOR / '再生172.py',
        AUTHOR / '追加7の固定純出生.npz', AUTHOR / '追加7の固定比較.json.gz', AUTHOR / '追加7の全取得.json.gz']
    before = {path.relative_to(ROOT).as_posix(): independent.sha(path) for path in paths}
    started = time.monotonic()
    root = independent.module(AUTHOR / '再生172.py', 'author172_context_for_independent7')
    base_dir = ROOT / 'inputs/00167_追加七場の入口と共用価格索引'
    features, input_captures, _ = root.R168.BASE.load_features(base_dir / '入口母集団')
    adapter = independent.module(ROOT / 'work/166可変場の数値化/arrays166.py', 'numeric166_for_independent172')
    numeric_proof = independent.read(base_dir / '生成の完了.json')
    table = adapter.load_table(base_dir / '自然数値表', numeric_proof['cache'])
    context = root.R168.BASE.GenericContext(features, table, input_captures)
    assert len(context.scenes) == 7
    with np.load(AUTHOR / '追加7の固定純出生.npz', allow_pickle=False) as source:
        base = {key[len('BASE__'):]: source[key].copy() for key in source.files if key.startswith('BASE__')}
        directions = {key: source[key].copy() for key in source.files if not key.startswith('BASE__')}
    assert {'core', 'branches', 'technical', 'tier'} <= set(base)
    captures = root.R168.capture_descriptors(context)
    raw = context.table.arrays
    hours = independent.hours_from_scenes(context)
    reports = independent.read(AUTHOR / '追加7の固定比較.json.gz')
    references = independent.read(AUTHOR / '追加7の全取得.json.gz')
    targets = {row['id']: row for row in reports['rows']}
    receipts = {row['id']: row for row in references['rows']}
    assert set(targets) == set(receipts) == set(independent.IDENTITIES)
    widths = {int(value): i for i, value in enumerate(table.widths)}
    horizons = {value: i for i, value in enumerate(table.horizons)}
    output = []
    checks = []
    cells = 0
    for identity in independent.IDENTITIES:
        expected = targets[identity]
        birth = independent.route(context, base, expected['candidate'], directions)
        actual = independent.replay_list(context, birth, captures, raw)
        assert actual == receipts[identity]['engine'], identity
        obtained_ref = {key: [] for key in ('cases', 'sides', 'events', 'phases', 'origins', 'widths', 'horizons', 'tiers')}
        for row in actual['records']:
            horizon = 'H60' if row['origin'] == 2 else birth[4][row['event']]
            values = (row['case'], row['side'], row['event'], int(context.event_phases[row['event']]),
                      row['origin'], widths[row['width']], horizons[horizon], row['tier'])
            for key, value in zip(obtained_ref, values, strict=True):
                obtained_ref[key].append(value)
        assert all(values == receipts[identity][key] for key, values in obtained_ref.items())
        for band, phase in [('全帯', None), ('DAY', 0), ('PRE', 1), ('POST', 2), ('NIGHT', -1)]:
            for group, origin in [('全部', None), ('主', 0), ('補完', 2)]:
                obtained = independent.statistics(context, raw, actual, birth, hours, 0, 7, phase, origin)
                wanted = expected['cap10']['periods']['全期'][band][group]
                for key, value in obtained.items():
                    if isinstance(value, float):
                        assert wanted[key] is not None and abs(value - wanted[key]) <= 1e-8, (identity, band, group, key)
                    else:
                        assert value == wanted[key], (identity, band, group, key)
                    cells += 1
        for scene in range(7):
            obtained = independent.statistics(context, raw, actual, birth, hours, scene, scene+1, None, None)
            wanted = expected['cap10']['scenes'][scene]
            for key, value in obtained.items():
                assert value == wanted[key] or (isinstance(value, float) and abs(value-wanted[key]) <= 1e-8), (identity, scene, key)
                cells += 1
            assert wanted['quantity'] == actual['audits'][scene]
        for side, name in enumerate(('BUY', 'SELL')):
            side_result = {**actual, 'records': [row for row in actual['records'] if row['side'] == side]}
            obtained = independent.statistics(context, raw, side_result, birth, hours, 0, 7, None, None)
            wanted = expected['cap10']['sides'][name]
            for key, value in obtained.items():
                assert value == wanted[key] or (isinstance(value, float) and abs(value-wanted[key]) <= 1e-8), (identity, name, key)
                cells += 1
        output.append({'id': identity, **obtained_ref, 'engine': actual})
        checks.append({'id': identity, '取得': len(actual['records']), '要求': len(actual['requests']),
                       '場監査': len(actual['audits']), '全engineと取得8属性一致': True})
        print(json.dumps(checks[-1], ensure_ascii=False), flush=True)
    independent.save(HERE / '追加7一覧再生結果.json.gz', {'成功': True, 'rows': output})
    assert all(independent.sha(ROOT / path) == digest for path, digest in before.items())
    proof = {'成功': True, 'engine172実行': False, 'Root集計実行': False,
        'Root適用完了後の追加7読取': True, '入力': 'F4封印の追加7固定純出生と167共用numeric',
        '一覧法の政策': checks, '金融集計一致セル': cells,
        '独立NY時刻のhours一致': True, 'Sourceと入力': before,
        '出力SHA256': independent.sha(HERE / '追加7一覧再生結果.json.gz'), '経過秒': time.monotonic()-started}
    independent.save(HERE / '追加7独立検算.json', proof)
    print(json.dumps(proof, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
