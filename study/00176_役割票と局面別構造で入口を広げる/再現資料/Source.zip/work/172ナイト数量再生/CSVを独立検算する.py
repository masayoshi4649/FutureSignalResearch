"""4CSVをRoot型付き入力・集計関数なしで共用numericから独立確認する。"""
from pathlib import Path
from collections import Counter
import csv
import json
import sys

import numpy as np

from 旧73を独立検算する import module, read, save, sha, hours_from_scenes


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
AUTHOR = ROOT / 'work/172ナイト入口探索'
OUTPUT = ROOT / 'outputs/00172_デイ固定とナイト入口の比較'
ROLES = {'BASE171': '171固定対照', 'B05_01': '全期発見の事前主', 'B05_02': '主近傍',
         'B05_03': '主近傍', 'B06_18': '前48順位・上流全期候補含む',
         'B05_11': '旧73を見た後選の安定性対照'}


def csv_rows(name: str) -> tuple:
    """
    機能: 編集せずCSVの列名と行を読み込む。
    引数: name(str)は拡張子を除く表名。
    返り値: tuple[list[str],list[dict]]は列名と文字列セル。
    """
    with (OUTPUT / (name + '.csv')).open(encoding='utf-8-sig', newline='') as source:
        reader = csv.DictReader(source)
        return reader.fieldnames, list(reader)


def equal(actual: str, expected: object, location: tuple) -> None:
    """
    機能: 空欄・文字・整数・率を型に応じて照合する。
    引数: actual(str)はCSVセル、expected(object)は独立算値、location(tuple)は位置。
    返り値: None。数値許容差は絶対1e-8と相対1e-12の大きい方。
    """
    if expected is None:
        assert actual == '', (location, actual, expected)
    elif isinstance(expected, str):
        assert actual == expected, (location, actual, expected)
    elif isinstance(expected, (int, np.integer)):
        assert actual and float(actual) == int(expected), (location, actual, expected)
    else:
        assert actual and abs(float(actual)-float(expected)) <= max(1e-8, abs(float(expected))*1e-12), (location, actual, expected)


def selected_scenes(period: str) -> set:
    """
    機能: 期間の表示名を80場の位置集合へ変換する。
    引数: period(str)はCSV上の期間。
    返り値: set[int]は該当場位置。
    """
    bounds = {'旧73既使用': (0, 73), '旧前48既使用': (0, 48), '旧後25既使用': (48, 73),
              '追加7既使用参考': (73, 80), '全80既使用加法': (0, 80)}
    low, high = bounds[period]
    return set(range(low, high))


def aggregate(trades: list, scenes: list, scope: set, phase: str, group: str) -> dict:
    """
    機能: 素取引のPython一覧から帯・帰属・期間の金融と参加を集計する。
    引数: trades/scenes(list[dict])はnumeric由来、scope(set[int])は場、phase/group(str)は帯と帰属。
    返り値: dictはCSVで使う日本語列名と独立算値。
    """
    phases = {'DAY': {0}, 'PRE': {1}, 'POST': {2}, 'NIGHT': {1, 2}, '全帯': {0, 1, 2}}[phase]
    origin = {'全部': None, '主': 0, '補完': 2}[group]
    rows = [row for row in trades if row['scene'] in scope and row['phase'] in phases
            and (origin is None or row['origin'] == origin)]
    eligible = {index for index in scope if sum(scenes[index]['hours'][p] for p in phases) > 0}
    hours = sum(sum(scenes[index]['hours'][p] for p in phases) for index in eligible)
    codes = Counter(row['label'] for row in rows)
    cash = [row['net'] for row in rows if row['known']]
    profit = sum(max(value, 0) for value in cash)
    loss = sum(max(-value, 0) for value in cash)
    wins = sum(value > 0 for value in cash)
    rate = codes[1] / (codes[1]+codes[-1]) if codes[1]+codes[-1] else None
    frequency = len(rows) / hours if hours else None
    return {'取得数': len(rows), '順先着F': codes[1], '逆先着A': codes[-1], '未到達N': codes[0], '不足C': codes[2],
            '到達済み先着率': rate, '既知利益円': profit, '既知損失円': loss, '既知差引円': profit-loss,
            'PF': profit/loss if loss else None, '利益決済数': wins, '損失決済数': sum(value < 0 for value in cash),
            '既知決済勝率': wins/len(cash) if cash else None,
            '主取得数': sum(row['origin'] == 0 for row in rows), '補完取得数': sum(row['origin'] == 2 for row in rows),
            '取得参加場数': len({row['scene'] for row in rows}), '全対象場数': len(eligible),
            '平均取得回毎時': frequency, '平均取得間隔分': 60/frequency if frequency else None,
            '全件収支円_不足あり空欄': profit-loss if codes[2] == 0 else None,
            '全ザラバ時間': hours}


def main() -> None:
    """
    機能: 型付き入力を読まず共用numericと取得参照から4CSVを検算する。
    引数: なし。CSVは読み取りだけで保存・exportを行わない。
    返り値: None。CSV独立検算.jsonへ小さな検査票とSource指紋を保存する。
    """
    sys.stdout.reconfigure(encoding='utf-8')
    files = [OUTPUT / (name+'.csv') for name in ('候補比較', '時間帯別', '全セッション', '条件一覧')]
    refs = [AUTHOR / '旧73の全取得.json.gz', AUTHOR / '追加7の全取得.json.gz']
    setting_path = ROOT / 'study/00172_デイを固定しナイト米国前後の複合入口を探索する/条件.json'
    paths = [Path(__file__), HERE / '旧73を独立検算する.py', setting_path,
             AUTHOR / '適用五組の固定.json',
             ROOT / 'work/171三帯の入口切替/旧73固定候補/全取得参照.json',
             ROOT / 'work/171三帯の入口切替/追加7固定候補/全取得参照.json', *refs, *files]
    before = {path.relative_to(ROOT).as_posix(): sha(path) for path in paths}
    root = module(AUTHOR / '再生172.py', 'context_only_for_csv172_qa')
    original = root.R168.BASE.Context165()
    old = root.R168.BASE.GenericContext(original.features, original.table, original.capture_rows)
    base_dir = ROOT / 'inputs/00167_追加七場の入口と共用価格索引'
    features, captures, _ = root.R168.BASE.load_features(base_dir / '入口母集団')
    numeric = module(ROOT / 'work/166可変場の数値化/arrays166.py', 'numeric166_for_csv172_qa')
    extra_table = numeric.load_table(base_dir / '自然数値表', read(base_dir / '生成の完了.json')['cache'])
    extra = root.R168.BASE.GenericContext(features, extra_table, captures)
    scenes = []
    trades = {identity: [] for identity in ROLES}
    references = []
    for context, ref_path, offset in ((old, refs[0], 0), (extra, refs[1], 73)):
        hours = hours_from_scenes(context)
        scenes.extend({'session': session, 'hours': hours[index].tolist()}
                      for index, session in enumerate(context.sessions))
        saved = {row['id']: row for row in read(ref_path)['rows']}
        references.append(saved)
        assert set(saved) == set(ROLES)
        raw = context.table.arrays
        for identity, ref in saved.items():
            assert len(ref['cases']) == len(ref['events']) == len(ref['engine']['records'])
            for i, case in enumerate(ref['cases']):
                side, wi, hi = ref['sides'][i], ref['widths'][i], ref['horizons'][i]
                event, origin = ref['events'][i], ref['origins'][i]
                assert ref['phases'][i] == int(context.event_phases[event])
                key = (case, side, wi, hi)
                direction = int(raw['direction'][key])
                label = direction if direction else int(raw['label'][key])
                known = bool(raw['known'][key])
                assert (label == 2) == (not known)
                trades[identity].append({'scene': offset + int(context.case_scene[case]), 'phase': ref['phases'][i],
                    'origin': origin, 'label': label, 'known': known, 'net': int(raw['net5'][key]) if known else None})
    assert len(scenes) == 80 and sum(scene['hours'][0] > 0 for scene in scenes) == 40
    checks = {}
    for name, expected_count in [('候補比較', 60), ('時間帯別', 360)]:
        headers, rows = csv_rows(name)
        assert len(rows) == expected_count
        cells = len(headers)
        identities = set()
        for i, row in enumerate(rows, 2):
            identity, period, phase, group = (row[key] for key in ('候補ID', '期間', 'q0帯', '入口帰属'))
            identities.add((identity, period, phase, group))
            expected = aggregate(trades[identity], scenes, selected_scenes(period), phase, group)
            expected.update({'候補ID': identity, '役割': ROLES[identity], '期間': period, 'q0帯': phase, '入口帰属': group})
            assert len(headers) == 25 and set(headers) == set(expected) - {'全ザラバ時間'}
            for header in headers:
                equal(row[header], expected[header], (name, i, header))
                cells += 1
        periods = ('旧73既使用', '旧前48既使用', '旧後25既使用', '追加7既使用参考', '全80既使用加法')
        phases = ('NIGHT', '全帯') if name == '候補比較' else ('DAY', 'PRE', 'POST', 'NIGHT')
        groups = ('全部',) if name == '候補比較' else ('全部', '主', '補完')
        assert len(identities) == len(rows) and identities == {
            (identity, period, phase, group) for identity in ROLES for period in periods for phase in phases for group in groups}
        checks[name] = {'行数': len(rows), '照合セル': cells}
    # ----------------------------------------
    # 全場0件も残し、累計は未知を含む経路のまま、全件確定値だけを空欄にする。
    headers, rows = csv_rows('全セッション')
    assert len(rows) == 480
    seen = set()
    cumulative = Counter()
    unknown = Counter()
    cells = len(headers)
    blank_cumulative = 0
    for i, row in enumerate(rows, 2):
        identity, session = row['候補ID'], row['セッション']
        scene = next(index for index, value in enumerate(scenes) if value['session'] == session)
        assert (identity, scene) not in seen
        seen.add((identity, scene))
        assert scene == len([key for key in seen if key[0] == identity]) - 1
        values = aggregate(trades[identity], scenes, {scene}, '全帯', '全部')
        cumulative[identity] += values['既知差引円']
        unknown[identity] += values['不足C']
        ref = references[0 if scene < 73 else 1][identity]
        audit = ref['engine']['audits'][scene if scene < 73 else scene-73]
        expected = {**values, '候補ID': identity, '役割': ROLES[identity], 'セッション': session,
            '期間': '旧73既使用' if scene < 73 else '追加7既使用参考',
            '既知累計円': cumulative[identity], '累計不足C': unknown[identity],
            '全件累計円_不足あり空欄': cumulative[identity] if unknown[identity] == 0 else None,
            '取得回毎時': values['平均取得回毎時'], '主数量棄却': audit['quantity_rejected_core'],
            '買い最大予約保有': audit['peak_reserved_total'][0], '売り最大予約保有': audit['peak_reserved_total'][1]}
        blank_cumulative += unknown[identity] > 0
        for header in headers:
            equal(row[header], expected[header], ('全セッション', i, header))
            cells += 1
    checks['全セッション'] = {'行数': len(rows), '照合セル': cells, '累計不足による全件空欄': blank_cumulative}
    # ----------------------------------------
    # 全40Dayの取得・金融は全候補でBASE171へ同体。BASE自体も171保存属性へ直接照合する。
    day_reference = aggregate(trades['BASE171'], scenes, set(range(80)), 'DAY', '全部')
    assert day_reference['取得参加場数'] == day_reference['全対象場数'] == 40
    for identity in ROLES:
        assert aggregate(trades[identity], scenes, set(range(80)), 'DAY', '全部') == day_reference
    for index, context in enumerate((old, extra)):
        prior = ROOT / 'work/171三帯の入口切替' / ('旧73固定候補' if index == 0 else '追加7固定候補') / '全取得参照.json'
        previous = read(prior)['rows'][0]
        base = references[index]['BASE171']
        for field in ('cases', 'sides', 'events', 'phases', 'origins', 'widths', 'tiers'):
            left = [previous[field][i] for i, phase in enumerate(previous['phases']) if phase == 0]
            right = [base[field][i] for i, phase in enumerate(base['phases']) if phase == 0]
            assert left == right, (index, field)
    # ----------------------------------------
    # 条件一覧は型付きinputを使わず、固定票・172条件と読める定義へ照合する。
    headers, rows = csv_rows('条件一覧')
    assert headers == ['項目', '設定', '注意'] and len(rows) == 24
    conditions = {row['項目']: row for row in rows}
    fixed, setting = read(AUTHOR / '適用五組の固定.json'), read(setting_path)
    assert setting['cost'] == {'point_yen': 100, 'fee_round_trip': 77, 'additional_round_trip_slippage_yen': 1000}
    general = {
        '対象': ('NK225ラージの実BBOをmini取得・返済代用へ適用', '全80既使用。mini実板約定ではない。'),
        '数量': ('要求mini1枚、買い/売り各上限10枚', 'pendingも枠を予約、未知は場末まで保持。'),
        '費用': ('1pt100円、片道税込38.5円、追加片道5pt', '往復77円+1000円、実spreadも含む。'),
        '時計': ('既存全1分q0→別原行q1取得', '指標足幅と判断時計は別。NY09:30夏冬自動。'),
        '主率': ('F/(F+A)', '未到達Nと観測不足Cを分け、決済勝率と混同しない。'),
        '全件収支': ('C>0は空欄', '既知差引を全件確定の利益としない。'),
        'Day固定': ('171の主/補完・200/400・H60・cap10', '全政策・全80の要求/取得/監査が同体。'),
        '夜補完固定': ('171 L180_S4/H200・決済H60', '主0でも補完が参加。主の場数・損益も別記。'),
        '未知の期間': ('旧73/追加7とも既使用', '追加7を新規未見と呼ばない。'),
        '主選択': (fixed['主案'], '旧73の441数量再生から全期発見。'),
        '事後対照': (fixed['事後安定性追加'], '旧73を見て4セルの安定性から後選。主交換なし。'),
        '過去だけの選択': ('B06_18は前48順位だが上流に全期shortlistを含む', '完全な過去順・未見の選択とは呼ばない。')}
    for identity in ROLES:
        choice = next((value for value in fixed['candidates'] if value['id'] == identity), None)
        for band in ('PRE', 'POST'):
            option = None if identity == 'BASE171' else choice[band]
            text = '171固定' if option is None else '/'.join([option['source'], option['rule'], option['entry_mode'],
                option['orientation'], f"±{option['width']}pt", option['horizon']])
            general[identity+'_'+band] = (text, ROLES[identity])
    assert set(conditions) == set(general)
    for key, values in general.items():
        assert (conditions[key]['設定'], conditions[key]['注意']) == values
    checks['条件一覧'] = {'行数': 24, '照合セル': 24*3+3}
    assert all(sha(ROOT / path) == digest for path, digest in before.items())
    proof = {'成功': True, 'CSV本体変更': False, 'Root型付き入力読取': False, 'Root集計関数実行': False,
        '方法': '旧73/追加7の全取得参照から共用numericを直接引き、Python一覧でFANC/金融/率/場数/累計を再計算。',
        '四表': checks, '期間帯帰属の全組合せ保持': True,
        '照合セル合計': sum(value['照合セル'] for value in checks.values()),
        '全80Dayの171七属性同体': True, '全候補のDay金融取得と全40場同体': True,
        'Day共通結果': day_reference, 'Sourceと入力': before,
        '限界': '全件の値と空欄を検算。表示QAはRootのartifact-tool検査に分離。'}
    save(HERE / 'CSV独立検算.json', proof)
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
