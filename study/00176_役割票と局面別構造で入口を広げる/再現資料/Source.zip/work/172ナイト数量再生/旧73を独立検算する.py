"""旧73の固定5政策を一覧時計と共用numericの別集計で独立検算する。"""
from pathlib import Path
from datetime import datetime, time as clock_time
from zoneinfo import ZoneInfo
import argparse
import gzip
import hashlib
import importlib.util
import json
import math
import sys
import time

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
AUTHOR = ROOT / 'work/172ナイト入口探索'
IDENTITIES = ('BASE171', 'B05_01', 'B05_02', 'B05_03', 'B06_18', 'B05_11')


def sha(path: Path) -> str:
    """
    機能: 入力とSourceを指紋化する。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def read(path: Path) -> dict:
    """
    機能: JSON又はgzip JSONを読む。
    引数: path(Path)は対象。
    返り値: dictは保存内容。
    """
    body = gzip.decompress(path.read_bytes()) if path.suffix == '.gz' else path.read_bytes()
    return json.loads(body)


def save(path: Path, value: dict) -> None:
    """
    機能: 日本語UTF-8の検算結果を保存する。
    引数: path(Path)は保存先、value(dict)は内容。
    返り値: None。
    """
    body = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    path.write_bytes(gzip.compress(body, mtime=0) if path.suffix == '.gz' else body)


def module(path: Path, name: str) -> object:
    """
    機能: Sourceを明示名で読み込む。
    引数: path(Path)、name(str)はSourceと識別名。
    返り値: objectはmodule。engineのreplayは呼ばない。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


def route(context: object, base: dict, choice: dict, directions: dict) -> tuple:
    """
    機能: 全eventを個別走査し、旧枝又は出生帯の指定方向・幅・期限を選ぶ。
    引数: context(object)、base/choice/directions(dict)は共用出生と固定政策。
    返り値: tupleは主方向・技術方向・tier・幅・期限のPython一覧。
    """
    main = []
    technical = []
    tiers = []
    widths = []
    horizons = []
    for event, phase in enumerate(context.event_phases):
        option = choice.get('PRE' if phase == 1 else 'POST') if phase else None
        if option is None:
            main.append(int(base['core'][event]))
            widths.append(200 if base['branches'][event] == 0 else 400)
            horizons.append('H60')
        else:
            main.append(int(directions[option['key']][event]))
            widths.append(int(option['width']))
            horizons.append(option['horizon'])
        technical.append(int(base['technical'][event]))
        tiers.append(int(base['tier'][event]))
    assert all(width > 0 for width in widths)
    return main, technical, tiers, widths, horizons


def replay_list(context: object, birth: tuple, captures: list, raw: dict) -> dict:
    """
    機能: heapを使わず未処理時計の一覧最小値だけで要求・取得・監査を再生する。
    引数: context(object)、birth(tuple)は独立route、captures(list)は取得時計、raw(dict)は共用numeric。
    返り値: dictは全records/requests/audits。engine172は一切呼ばない。
    """
    main, technical, tiers, widths, horizons = birth
    width_map = {int(value): i for i, value in enumerate(context.table.widths)}
    horizon_map = {value: i for i, value in enumerate(context.table.horizons)}
    records = []
    requests = []
    audits = []
    serial = 0
    for scene, scene_data in enumerate(context.scenes):
        held = [0, 0]
        pending_count = [0, 0]
        pending = {}
        positions = {}
        calendar = []
        seen = set()
        ever = False
        events = np.flatnonzero(context.event_scenes == scene).tolist()
        audit = {'scene_index': scene, 'events': len(events), 'accepted_core': 0, 'accepted_technical': 0,
            'quantity_rejected_core': 0, 'quantity_rejected_technical': 0, 'quantity_rejected_by_side': [0, 0],
            'alias_fills_skipped': 0, 'cancelled': 0, 'filled': 0, 'unknown_held_to_end': 0,
            'peak_held': [0, 0], 'peak_pending': [0, 0], 'peak_reserved_total': [0, 0],
            'technical_wait_core_pending': 0, 'pending_at_scene_end': [0, 0]}

        def observe() -> None:
            """
            機能: 一覧法の数量ピークと不変式を更新する。
            引数: なし。場内の数量状態を読む。
            返り値: None。
            """
            assert all(0 <= held[s] + pending_count[s] <= 10 for s in (0, 1))
            for name, values in [('peak_held', held), ('peak_pending', pending_count),
                                 ('peak_reserved_total', [held[s] + pending_count[s] for s in (0, 1)])]:
                audit[name] = [max(audit[name][s], values[s]) for s in (0, 1)]

        for event in events + [None]:
            now = (float(scene_data['end']), math.inf, math.inf) if event is None else tuple(context.event_keys[event])
            while calendar:
                index = min(range(len(calendar)), key=lambda i: calendar[i][:2])
                at, order, kind, token = calendar[index]
                if at > now:
                    break
                calendar.pop(index)
                if kind == 'release':
                    held[positions.pop(token)['side']] -= 1
                    observe()
                    continue
                row = pending.pop(token)
                side = row['side']
                pending_count[side] -= 1
                if kind == 'cancel':
                    audit['cancelled'] += 1
                    observe()
                    continue
                case = row['case']
                if case in seen:
                    audit['alias_fills_skipped'] += 1
                    observe()
                    continue
                seen.add(case)
                ever = True
                held[side] += 1
                audit['filled'] += 1
                record = {key: row[key] for key in ('event', 'case', 'side', 'width', 'origin', 'tier')}
                records.append(record)
                positions[token] = record
                horizon = 'H60' if row['origin'] == 2 else horizons[row['event']]
                key = (case, side, width_map[row['width']], horizon_map[horizon])
                if bool(raw['known'][key]):
                    release = float(raw['exit_time'][key])
                    assert at[0] <= release <= scene_data['end']
                else:
                    release = float(scene_data['end'])
                    audit['unknown_held_to_end'] += 1
                serial += 1
                calendar.append(((release, math.inf, math.inf), serial, 'release', token))
                observe()
            if event is None:
                break
            if main[event]:
                side = 0 if main[event] == 1 else 1
                width, origin, tier = widths[event], 0, 0
            else:
                if now[0] < scene_data['start'] + 2700 or ever or not technical[event]:
                    continue
                if any(value['origin'] == 2 for value in pending.values()):
                    continue
                if any(value['origin'] == 0 for value in pending.values()):
                    audit['technical_wait_core_pending'] += 1
                    continue
                side = 0 if technical[event] == 1 else 1
                width, origin, tier = 200, 2, tiers[event]
            row = {'event': event, 'scene_index': scene, 'side': side, 'width': width, 'origin': origin,
                   'tier': tier, 'at': list(now), 'held_before': held[side], 'pending_before': pending_count[side]}
            row['accepted'] = held[side] + pending_count[side] < 10
            requests.append(row)
            if not row['accepted']:
                audit['quantity_rejected_core' if origin == 0 else 'quantity_rejected_technical'] += 1
                audit['quantity_rejected_by_side'][side] += 1
                continue
            capture = captures[event]
            filled = capture['status'] == 'filled'
            key = tuple(capture['fill_key'] if filled else capture['finish_key'])
            token = len(requests) - 1
            pending[token] = {**row, 'case': int(capture['case']) if filled else -1}
            pending_count[side] += 1
            audit['accepted_core' if origin == 0 else 'accepted_technical'] += 1
            serial += 1
            calendar.append((key, serial, 'fill' if filled else 'cancel', token))
            observe()
        audit['pending_at_scene_end'] = pending_count.copy()
        audit['held_at_scene_end'] = held.copy()
        assert held == [0, 0] and not positions
        audits.append(audit)
    records.sort(key=lambda row: (row['event'], row['origin']))
    assert len({row['case'] for row in records}) == len(records)
    return {'records': records, 'requests': requests, 'audits': audits, 'capacity': 10,
            'contracts_per_request': 1, 'exit_clock': '同秒決済は秒末解放、未知は場末まで保持'}


def hours_from_scenes(context: object) -> np.ndarray:
    """
    機能: 場時計とzoneinfoのNY09:30から時間分母を独立計算する。
    引数: context(object)は場名と開始終了時計。
    返り値: np.ndarray[S,3]はDAY/PRE/POSTの時間数。
    """
    hours = np.zeros((len(context.scenes), 3))
    for index, scene in enumerate(context.scenes):
        start, end = float(scene['start']), float(scene['end']) - 300.
        session = context.sessions[index]
        if session.endswith('_Day'):
            hours[index, 0] = (end - start) / 3600
        else:
            date = datetime.strptime(session[:10], '%Y-%m-%d').date()
            boundary = datetime.combine(date, clock_time(9, 30), tzinfo=ZoneInfo('America/New_York')).timestamp()
            hours[index, 1] = max(0., min(end, boundary) - start) / 3600
            hours[index, 2] = max(0., end - max(start, boundary)) / 3600
    assert np.allclose(hours, context.hours, atol=1e-12, rtol=0)
    return hours


def statistics(context: object, raw: dict, result: dict, birth: tuple, hours: np.ndarray,
               low: int, high: int, phase: int | None, origin: int | None) -> dict:
    """
    機能: 取得一覧をPython条件で分け、元numericから先着と費用後金融を別集計する。
    引数: context(object)、raw/result(dict)、birth(tuple)、hours(np.ndarray)、
          low/high(int)は期間、phase(int|None)は帯、origin(int|None)は主補完。
    返り値: dictはRootのstatisticsと同じ指標。集計関数は呼ばない。
    """
    selected = [r for r in result['records'] if low <= context.case_scene[r['case']] < high
        and (phase is None or (context.event_phases[r['event']] > 0 if phase == -1 else context.event_phases[r['event']] == phase))
        and (origin is None or r['origin'] == origin)]
    eligible = [i for i in range(low, high) if phase is None or
        (hours[i, 1:].sum() > 0 if phase == -1 else hours[i, phase] > 0)]
    denominator = sum(float(hours[i].sum() if phase is None else hours[i, 1:].sum() if phase == -1 else hours[i, phase]) for i in eligible)
    labels = []
    money = []
    counts = [0] * len(context.scenes)
    core_count = 0
    width_map = {int(value): i for i, value in enumerate(context.table.widths)}
    horizon_map = {value: i for i, value in enumerate(context.table.horizons)}
    for record in selected:
        case, side, event = record['case'], record['side'], record['event']
        horizon = 'H60' if record['origin'] == 2 else birth[4][event]
        key = (case, side, width_map[record['width']], horizon_map[horizon])
        direction = int(raw['direction'][key])
        known = bool(raw['known'][key])
        label = direction if direction else int(raw['label'][key])
        assert (label == 2) == (not known)
        labels.append(label)
        if known:
            money.append(int(raw['net5'][key]))
        counts[int(context.case_scene[case])] += 1
        core_count += record['origin'] == 0
    f, a, und, c = [labels.count(code) for code in (1, -1, 0, 2)]
    profit = sum(max(value, 0) for value in money)
    loss = sum(max(-value, 0) for value in money)
    count = len(selected)
    return {'count': count, 'F': f, 'A': a, 'N': und, 'C': c,
        'rate': f / (f+a) if f+a else None, 'known': len(money), 'unknown': c,
        'profit': profit, 'loss': loss, 'net': profit-loss, 'pf': profit/loss if loss else None,
        'all_net': profit-loss if c == 0 else None,
        'wins': sum(value > 0 for value in money), 'loss_trades': sum(value < 0 for value in money),
        'scenes': sum(value > 0 for value in counts), 'eligible_scenes': len(eligible),
        'all_scenes': bool(eligible and all(counts[index] > 0 for index in eligible)),
        'hours': denominator, 'per_hour': count / denominator if denominator else None,
        'max_scene_share': max(counts) / count if count else None,
        'core_count': int(core_count), 'technical_count': count-int(core_count)}


def main() -> None:
    """
    機能: 指定旧73政策を一覧法で再生し、441保存統計と任意のRoot全結果へ照合する。
    引数: --reference(Path|None)はRootの5政策全engine保存票。
    返り値: None。旧73独立検算.jsonと一覧再生結果.json.gzを保存する。
    """
    sys.stdout.reconfigure(encoding='utf-8')
    parser = argparse.ArgumentParser()
    parser.add_argument('--reference', type=Path)
    args = parser.parse_args()
    paths = [Path(__file__), AUTHOR / '再生172.py', AUTHOR / '数量比較する.py',
             AUTHOR / '旧73数量比較.json.gz', AUTHOR / '短表の純出生.npz']
    before = {path.relative_to(ROOT).as_posix(): sha(path) for path in paths}
    started = time.monotonic()
    root = module(AUTHOR / '再生172.py', 'author172_context_for_independent')
    original = root.R168.BASE.Context165()
    context = root.R168.BASE.GenericContext(original.features, original.table, original.capture_rows)
    assert len(context.scenes) == 73
    base, _, _ = root.baseline(context)
    captures = root.R168.capture_descriptors(context)
    raw = context.table.arrays
    hours = hours_from_scenes(context)
    with np.load(AUTHOR / '短表の純出生.npz', allow_pickle=False) as source:
        directions = {key: source[key].copy() for key in source.files}
    comparison = read(AUTHOR / '旧73数量比較.json.gz')
    targets = {row['id']: row for row in comparison['rows'] if row['id'] in IDENTITIES}
    assert set(targets) == set(IDENTITIES)
    output = []
    checks = []
    cells = 0
    for identity in IDENTITIES:
        expected = targets[identity]
        birth = route(context, base, expected['candidate'], directions)
        actual = replay_list(context, birth, captures, raw)
        for period, low, high in [('全期', 0, 73), ('前48場', 0, 48), ('後25場', 48, 73)]:
            for band, phase in [('全帯', None), ('DAY', 0), ('PRE', 1), ('POST', 2), ('NIGHT', -1)]:
                for group, origin in [('全部', None), ('主', 0), ('補完', 2)]:
                    obtained = statistics(context, raw, actual, birth, hours, low, high, phase, origin)
                    wanted = expected['cap10']['periods'][period][band][group]
                    for key, value in obtained.items():
                        if isinstance(value, float):
                            assert wanted[key] is not None and abs(value - wanted[key]) <= 1e-8, (identity, period, band, group, key)
                        else:
                            assert value == wanted[key], (identity, period, band, group, key, value, wanted[key])
                        cells += 1
        quantity = expected['cap10']['quantity']
        assert sum(a['quantity_rejected_core'] for a in actual['audits']) == quantity['rejected_core']
        assert sum(a['quantity_rejected_technical'] for a in actual['audits']) == quantity['rejected_technical']
        assert np.max([a['peak_reserved_total'] for a in actual['audits']], axis=0).tolist() == quantity['peak_reserved']
        output.append({'id': identity, 'engine': actual})
        checks.append({'id': identity, '取得': len(actual['records']), '要求': len(actual['requests']),
                       '場監査': len(actual['audits']), '441保存統計一致': True})
        print(json.dumps(checks[-1], ensure_ascii=False), flush=True)
    save(HERE / '旧73一覧再生結果.json.gz', {'成功': True, 'Sourceと入力': before, 'rows': output})
    reference_checked = False
    if args.reference is not None:
        reference = read(args.reference)
        references = {row['id']: row for row in reference['rows']}
        for row in output:
            target = references[row['id']]
            expected_engine = target.get('engine', target.get('result'))
            assert expected_engine is not None
            assert row['engine'] == expected_engine, row['id']
            birth = route(context, base, targets[row['id']]['candidate'], directions)
            width_map = {int(value): i for i, value in enumerate(context.table.widths)}
            horizon_map = {value: i for i, value in enumerate(context.table.horizons)}
            obtained_ref = {key: [] for key in ('cases', 'sides', 'events', 'phases', 'origins', 'widths', 'horizons', 'tiers')}
            for record in row['engine']['records']:
                horizon = 'H60' if record['origin'] == 2 else birth[4][record['event']]
                values = (record['case'], record['side'], record['event'], int(context.event_phases[record['event']]),
                          record['origin'], width_map[record['width']], horizon_map[horizon], record['tier'])
                for key, value in zip(obtained_ref, values, strict=True):
                    obtained_ref[key].append(value)
            assert all(values == target[key] for key, values in obtained_ref.items()), row['id']
        reference_checked = True
    assert all(sha(ROOT / path) == digest for path, digest in before.items())
    proof = {'成功': True, '追加7読取': False, 'engine172実行': False, 'Root集計実行': False,
             '一覧法の政策': checks, '独立金融統計セル': cells, '独立NY時刻のhours一致': True,
             'Root全engine票と取得8属性一致': reference_checked, 'Sourceと入力': before,
             '出力SHA256': sha(HERE / '旧73一覧再生結果.json.gz'), '経過秒': time.monotonic()-started}
    if args.reference is not None:
        proof['Root参照'] = {'path': str(args.reference), 'sha256': sha(args.reference)}
    save(HERE / '旧73独立検算.json', proof)
    print(json.dumps(proof, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
