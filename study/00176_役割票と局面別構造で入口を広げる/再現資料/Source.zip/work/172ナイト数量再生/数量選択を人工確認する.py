"""数量比較の出生対応・デイ固定・選択固有条件を自然入力なしで確認する。"""
from pathlib import Path
from types import SimpleNamespace
import ast
import copy
import hashlib
import importlib.util
import json
import sys

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TARGET = ROOT / 'work/172ナイト入口探索/数量比較する.py'
SELECTOR = ROOT / 'work/172ナイト基礎診断/selector172.py'


def sha(path: Path) -> str:
    """
    機能: Sourceの物理指紋を得る。
    引数: path(Path)はSource。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def definitions(path: Path, names: set, namespace: dict) -> dict:
    """
    機能: importやmainを実行せず指定した関数定義だけを読み込む。
    引数: path(Path)、names(set[str])、namespace(dict)は人工環境。
    返り値: dictは読み込んだ関数を持つ名前空間。
    """
    tree = ast.parse(path.read_text(encoding='utf-8'))
    body = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    assert len(body) == len(names)
    exec(compile(ast.Module(body=body, type_ignores=[]), str(path), 'exec'), namespace)
    return namespace


def pure_selector() -> object:
    """
    機能: 自然読取を持たないselector純部品を読み込む。
    引数: なし。
    返り値: objectはselector172。
    """
    spec = importlib.util.spec_from_file_location('selector172_review_stage2', SELECTOR)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def stats(f: int = 28, a: int = 12, count: int = 50, scenes: int = 10,
          share: float = .2) -> dict:
    """
    機能: selection境界を操作できる人工統計を作る。
    引数: f/a/count/scenes(int)、share(float)は人工件数と集中率。
    返り値: dictはsupported/scoreが参照する人工統計。
    """
    return {'count': count, 'F': f, 'A': a, 'C': 0, 'scenes': scenes,
            'profit': 2000, 'loss': 1000, 'max_scene_share': share,
            'rate': f / (f + a) if f + a else None, 'per_hour': .5}


def row(identity: str, full: dict, front: dict | None = None,
        both: bool = True, post: dict | None = None) -> dict:
    """
    機能: 二帯・前後期間を持つ人工数量政策を作る。
    引数: identity(str)、full/front/post(dict|None)、both(bool)は二帯置換か。
    返り値: dictはselect入力一政策。
    """
    front = stats(10, 10, 24, 5) if front is None else front
    post = full if post is None else post
    return {'id': identity, 'candidate': {'PRE': {'key': identity + 'P'},
            'POST': {'key': identity + 'Q'} if both else None},
            'cap10': {'periods': {
                '全期': {'PRE': {'全部': copy.deepcopy(full)}, 'POST': {'全部': copy.deepcopy(post)},
                         'NIGHT': {'全部': {'per_hour': full['per_hour']}}},
                '前48場': {'PRE': {'全部': copy.deepcopy(front)}, 'POST': {'全部': copy.deepcopy(front)},
                           'NIGHT': {'全部': {'per_hour': front['per_hour']}}}}}}


def verify_prepare(functions: dict, selector: object) -> dict:
    """
    機能: NPZを人工辞書へ置換し、旧幅別/新共通/正逆/方式の対応を確認する。
    引数: functions(dict)は対象関数環境、selector(object)は純短表抽出。
    返り値: dictは生成方向と政策数・読取先の証拠。
    """
    load_paths = []
    saved = {}
    original = np.array([[1, 0, -1, 0, 1, -1], [-1, 1, 0, -1, 0, 1]], dtype=np.int8)
    sources = {
        '出生125.npz': {'ALL': original.copy(), 'EDGE': -original.copy()},
        '出生400.npz': {'ALL': -original.copy(), 'EDGE': original.copy()},
        '新768の出生.npz': {'ALL': np.zeros_like(original), 'EDGE': original.copy(),
                           'phases': np.array([0, 1, 2, 0, 1, 2], dtype=np.int8)}}

    class ArtificialNPZ(dict):
        """np.loadのcontext managerを人工辞書で代替する。"""

        def __enter__(self) -> dict:
            """
            機能: 人工配列を返す。
            引数: self(ArtificialNPZ)。
            返り値: dictは人工Source。
            """
            return self

        def __exit__(self, exc_type: object, exc: object, trace: object) -> bool:
            """
            機能: 人工Sourceを閉じる。
            引数: self(ArtificialNPZ)、exc_type/exc/trace(object)は例外情報。
            返り値: boolのFalseは例外を抑制しない。
            """
            return False

    def load(path: Path, allow_pickle: bool) -> object:
        """
        機能: 実ファイルを開かず人工NPZを返す。
        引数: path(Path)は指定先、allow_pickle(bool)は安全指定。
        返り値: ArtificialNPZは人工配列。
        """
        assert allow_pickle is False
        load_paths.append(path.relative_to(ROOT).as_posix())
        return ArtificialNPZ(sources[path.name])

    def save_npz(path: Path, **arrays: dict) -> None:
        """
        機能: 出力配列をメモリへ記録しRootファイルを書かない。
        引数: path(Path)、arrays(dict[str,np.ndarray])は生成方向。
        返り値: None。
        """
        saved['directions'] = {k: v.copy() for k, v in arrays.items()}

    options = [
        {'key': 'OLD125', 'source': 'OLD1460', 'width': 125, 'entry_mode': 'ALL',
         'rule_index': 1, 'orientation': 'NORMAL', 'horizon': 'H30'},
        {'key': 'OLD400REV', 'source': 'OLD1460', 'width': 400, 'entry_mode': 'EDGE',
         'rule_index': 0, 'orientation': 'REVERSE', 'horizon': 'H60'},
        {'key': 'NEW125', 'source': 'NEW768', 'width': 125, 'entry_mode': 'EDGE',
         'rule_index': 1, 'orientation': 'NORMAL', 'horizon': 'H30'},
        {'key': 'NEW1000REV', 'source': 'NEW768', 'width': 1000, 'entry_mode': 'EDGE',
         'rule_index': 1, 'orientation': 'REVERSE', 'horizon': 'SESSION'}]
    report = {'成功': True, 'version': selector.VERSION,
              'bands': {'PRE': {'rows': options[:2]}, 'POST': {'rows': options[2:]}}}
    fake_r = SimpleNamespace(module=lambda path, name: selector, read=lambda path: report,
        sha=lambda path: '人工SHA', save=lambda path, value: saved.update(policy=value))
    functions['R'] = fake_r
    functions['np'] = SimpleNamespace(load=load, savez_compressed=save_npz)
    choices = functions['prepare'](ROOT / 'work/人工短表.json')
    functions['np'] = np
    directions = saved['directions']
    assert np.array_equal(directions['OLD125'], original[1])
    assert np.array_equal(directions['OLD400REV'], -original[0])
    assert np.array_equal(directions['NEW125'], original[1])
    assert np.array_equal(directions['NEW1000REV'], -original[1])
    assert np.array_equal(sources['出生400.npz']['EDGE'], original)
    assert len(choices) == 1 + 2 + 2 + 2 * 2 == 9
    assert len({choice['id'] for choice in choices}) == len(choices)
    assert load_paths[0].endswith('/出生125.npz') and load_paths[1].endswith('/出生400.npz')
    assert all(path.endswith('/新768の出生.npz') for path in load_paths[2:])
    # ----------------------------------------
    # 方向がDay/PRE/POSTへ意図したmaskだけで結合されることを別routeで確認する。
    route_ns = definitions(ROOT / 'work/172ナイト入口探索/再生172.py', {'route'}, {'np': np})
    phases = np.array([0, 1, 2, 0, 1, 2], dtype=np.int8)
    context = SimpleNamespace(event_keys=[None] * 6, event_phases=phases,
        table=SimpleNamespace(widths=[125, 200, 400, 1000], horizons=['H30', 'H60', 'H120', 'SESSION']))
    base = {'core': np.ones(6, dtype=np.int8), 'branches': np.zeros(6, dtype=np.int8),
            'technical': -np.ones(6, dtype=np.int8), 'tier': np.ones(6, dtype=np.int8)}
    birth, _, _, hi = route_ns['route'](context, base, {'PRE': options[0], 'POST': options[3]}, directions)
    expected = np.array([1, original[1, 1], -original[1, 2], 1, original[1, 4], -original[1, 5]], dtype=np.int8)
    assert np.array_equal(birth['core'], expected)
    assert np.array_equal(birth['technical'], base['technical'])
    assert [context.table.horizons[h] for h in hi] == ['H60', 'H30', 'SESSION', 'H60', 'H30', 'SESSION']
    return {'政策数': len(choices), 'Source読取先': load_paths, '対応方向キー': list(directions),
            '正逆がSource配列を変更しない': True, 'Day_PRE_POST対応': True}


def main() -> None:
    """
    機能: prepare/evaluate/day_guard/selectを人工だけで確認し発見を保存する。
    引数: なし。Source以外の自然ファイルを読まない。
    返り値: None。数量選択人工レビュー.jsonを保存する。
    """
    sys.stdout.reconfigure(encoding='utf-8')
    sources = {p.relative_to(ROOT).as_posix(): sha(p) for p in [TARGET, SELECTOR, Path(__file__)]}
    functions = definitions(TARGET, {'prepare', 'day_guard', 'evaluate', 'supported', 'select'},
        {'np': np, 'Path': Path, 'ROOT': ROOT, 'HERE': ROOT / 'work/172ナイト入口探索'})
    selector = pure_selector()
    prepare = verify_prepare(functions, selector)
    functions['R'] = SimpleNamespace(module=lambda path, name: selector)
    choose = functions['select']
    assert choose([])['主案'] is None and choose([])['参考適用ID'] == []
    singles = row('SINGLE', stats(90, 10, 100, 20), both=False)
    badpost = row('BADPOST', stats(90, 10, 100, 20), post=stats(26, 14, 50, 10))
    badsupport = row('BADSUPPORT', stats(), post=stats(28, 12, 39, 10))
    assert choose([singles, badpost, badsupport])['主案'] is None
    near = row('NEAR', stats(26, 14, 50, 10))
    chosen = choose([near])
    assert chosen['主案'] is None and chosen['参考適用ID'] == ['NEAR']
    full_badfront = row('FULL', stats(28, 12, 50, 10), front=stats(0, 0, 0, 0))
    assert choose([full_badfront])['主案'] == 'FULL'
    boundary = stats(18, 7, 40, 10, .25)
    assert functions['supported'](boundary)
    for key, invalid in [('count', 39), ('scenes', 9), ('C', 5), ('profit', 1000), ('max_scene_share', .251)]:
        changed = {**boundary, key: invalid}
        assert not functions['supported'](changed)
    front = stats(10, 5, 25, 6, .9)
    assert functions['supported'](front, True)
    # ----------------------------------------
    # 全期2・近傍3・前半1が別になる人工で、最大5切詰めと前半固定の関係を調べる。
    rows = [row('FULL1', stats(18, 7, 40)), row('FULL2', stats(19, 6, 40)),
            row('NEAR1', stats(650, 350, 1000)), row('NEAR2', stats(660, 340, 1000)),
            row('NEAR3', stats(670, 330, 1000)),
            row('FRONT', stats(24, 1, 30, 6), front=stats(24, 1, 25, 6))]
    crowded = choose(rows)
    assert crowded['主案'] == 'FULL2'
    assert len(crowded['参考適用ID']) == len(set(crowded['参考適用ID'])) <= 5
    assert '全80は既使用' in crowded['注意'] and '全期選択' in crowded['注意']
    front_retained = crowded['前48固定'] in crowded['参考適用ID']
    # ----------------------------------------
    # evaluateが同じglobalsを再生へ渡し、Day差分を黙って保存しないことを確認する。
    ctx = SimpleNamespace(event_phases=np.array([0, 1, 2]), hours=np.array([[4., 0., 0.], [0., 1., 3.]]))
    result = {'records': [{'event': 0, 'case': 1}, {'event': 1, 'case': 2}],
              'requests': [{'event': 0, 'accepted': True}], 'audits': [{'day': True}, {'night': True}]}
    expected = copy.deepcopy(result)
    functions['day_guard'](result, expected, ctx)
    changed = copy.deepcopy(result)
    changed['records'][0]['case'] = 9
    try:
        functions['day_guard'](changed, expected, ctx)
    except AssertionError:
        pass
    else:
        raise AssertionError('Day差分を拒否しなかった')
    called = []

    def replay(context: object, base: object, choice: dict, directions: object, captures: object) -> tuple:
        """
        機能: evaluateから渡された人工引数を記録する。
        引数: context/base/directions/captures(object)、choice(dict)は人工値。
        返り値: tupleは人工engine結果を末尾に持つ。
        """
        called.append((context, base, choice, directions, captures))
        return ('人工Selection', result)

    functions.update(CTX=ctx, BASE='人工基準', DIRS='人工方向', CAPTURES='人工取得', BASE_RESULT=expected,
        R=SimpleNamespace(replay=replay, describe=lambda context, value: {'人工集計': True}))
    evaluated = functions['evaluate']({'id': 'ARTIFICIAL'})
    assert evaluated['デイ同体'] and evaluated['cap10'] == {'人工集計': True}
    assert len(called) == 1 and called[0] == (ctx, '人工基準', {'id': 'ARTIFICIAL'}, '人工方向', '人工取得')
    assert all(sha(ROOT / path) == digest for path, digest in sources.items())
    proof = {'成功': True, '自然入力読取': False, 'RootSource変更': False, 'Source': sources,
        '出生対応': prepare, '両帯支持と主null': True, '片帯政策を主から除外': True,
        '全期主の前半支持gateなしを仕様として確認': True, '前48未見主張を避ける注意あり': True,
        'Day差分を拒否': True, 'evaluateの引数対応': True,
        '最大5と重複除去': True, '混雑人工の選択': crowded,
        '前48固定が参考適用に保持': front_retained,
        '指摘': [] if front_retained else ['全期2と近傍3と前48が全て別のとき、前48固定IDが参考適用ID最大5から落ちる。']}
    (HERE / '数量選択人工レビュー.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
