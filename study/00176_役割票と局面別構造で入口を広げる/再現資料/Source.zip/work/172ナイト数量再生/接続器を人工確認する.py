"""Rootの172接続器をSource定義抽出と人工73場だけで独立確認する。"""
from pathlib import Path
from types import SimpleNamespace
from collections import namedtuple
import ast
import hashlib
import importlib.util
import json
import sys

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TARGET = ROOT / 'work/172ナイト入口探索/再生172.py'
CHECK = ROOT / 'work/172ナイト入口探索/基準を確認する.py'


def sha(path: Path) -> str:
    """
    機能: レビュー対象Sourceを物理指紋化する。
    引数: path(Path)はSource。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def extract() -> dict:
    """
    機能: 自然入力を読むimportを実行せず、対象四関数だけを読み込む。
    引数: なし。対象SourceをASTで解析する。
    返り値: dictはroute/replay/statistics/describeを持つ人工名前空間。
    """
    spec = importlib.util.spec_from_file_location('pure_engine172_review', HERE / 'engine172.py')
    engine = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(engine)
    names = {'route', 'replay', 'statistics', 'describe'}
    tree = ast.parse(TARGET.read_text(encoding='utf-8'))
    body = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    assert len(body) == 4
    selected = namedtuple('Selection', 'cases sides events phases old')
    namespace = {'np': np, 'engine172': engine, 'Selection': selected}
    exec(compile(ast.Module(body=body, type_ignores=[]), str(TARGET), 'exec'), namespace)
    return namespace


def artificial() -> tuple:
    """
    機能: q0三帯・欠測・技術補完を持つ人工73場を生成する。
    引数: なし。
    返り値: tupleは人工context/base/captures/directions。
    """
    starts = np.arange(73) * 20000.
    ends = starts + 15000.
    event_scenes = np.repeat(np.arange(73), 2)
    times = np.repeat(starts, 2) + np.tile([2800., 6000.], 73)
    phases = np.array([0 if scene % 2 == 0 else 1 + event % 2
                       for event, scene in enumerate(event_scenes)], dtype=np.int8)
    captures = [{'status': 'filled', 'case': i,
                 'fill_key': (float(t + (4000 if i % 17 == 0 else 2)), i * 10 + 2, i * 10 + 2),
                 'finish_key': (float(t + (4000 if i % 17 == 0 else 2)), i * 10 + 2, i * 10 + 2)}
                for i, t in enumerate(times)]
    n = len(times)
    widths = [125, 200, 400, 1000]
    horizons = ['H30', 'H60', 'H120', 'SESSION']
    shape = (n, 2, len(widths), len(horizons))
    known = np.ones(shape, dtype=bool)
    labels = np.empty(shape, dtype=np.int8)
    money = np.empty(shape, dtype=np.int64)
    exits = np.empty(shape, dtype=float)
    for case in range(n):
        for side in (0, 1):
            for wi, width in enumerate(widths):
                for hi, horizon in enumerate(horizons):
                    code = (case + side + wi + hi) % 4
                    label = (1, -1, 0, 2)[code]
                    labels[case, side, wi, hi] = label
                    known[case, side, wi, hi] = label != 2
                    money[case, side, wi, hi] = (width * 100 - 1077) * (1 if label == 1 else -1) if label != 2 else 0
                    fill = captures[case]['fill_key'][0]
                    end = ends[event_scenes[case]]
                    exits[case, side, wi, hi] = (end if horizon == 'SESSION' else
                        min(end, fill + int(horizon[1:]) * 60)) if label != 2 else np.nan
    hours = np.array([[4., 0., 0.] if i % 2 == 0 else [0., 1.5, 2.5] for i in range(73)])
    context = SimpleNamespace(table=SimpleNamespace(widths=widths, horizons=horizons),
        arrays={'label': labels, 'known': known, 'net': money, 'exit_time': exits},
        event_keys=[(float(t), i * 10 + 1, i * 10 + 1) for i, t in enumerate(times)],
        event_scenes=event_scenes, event_phases=phases, case_scene=event_scenes.copy(),
        scenes=[{'start': float(a), 'end': float(b)} for a, b in zip(starts, ends, strict=True)],
        sessions=[f'人工{i}' for i in range(73)], hours=hours)
    core = np.where(np.arange(n) % 7 == 0, 0, np.where(np.arange(n) % 2 == 0, 1, -1)).astype(np.int8)
    base = {'core': core, 'branches': np.where(core == 0, -1, np.arange(n) % 2).astype(np.int8),
            'technical': np.ones(n, dtype=np.int8), 'tier': np.ones(n, dtype=np.int8)}
    directions = {'P': np.where(np.arange(n) % 5 == 0, 0, 1).astype(np.int8),
                  'Q': np.where(np.arange(n) % 3 == 0, 0, -1).astype(np.int8)}
    return context, base, captures, directions


def verify_statistics(context: object, value: tuple, report: dict) -> int:
    """
    機能: 全期/前48/後25・五帯・三群の集計maskをPython一覧で照合する。
    引数: context(object)は人工場、value(tuple)は取得、report(dict)は対象describe結果。
    返り値: intは照合した集計セル数。
    """
    selected, origins, wi, hi, _, _ = value
    cells = 0
    for period, low, high in [('全期', 0, 73), ('前48場', 0, 48), ('後25場', 48, 73)]:
        for name, phase in [('全帯', None), ('DAY', 0), ('PRE', 1), ('POST', 2), ('NIGHT', -1)]:
            eligible = [i for i in range(low, high) if phase is None or
                        (context.hours[i, 1:].sum() > 0 if phase == -1 else context.hours[i, phase] > 0)]
            hours = sum(float(context.hours[i].sum() if phase is None else
                        context.hours[i, 1:].sum() if phase == -1 else context.hours[i, phase]) for i in eligible)
            for group, origin in [('全部', None), ('主', 0), ('補完', 2)]:
                indices = [i for i, case in enumerate(selected.cases)
                    if low <= context.case_scene[case] < high
                    and (phase is None or (selected.phases[i] > 0 if phase == -1 else selected.phases[i] == phase))
                    and (origin is None or origins[i] == origin)]
                counts = [sum(context.case_scene[selected.cases[i]] == scene for i in indices) for scene in range(73)]
                labels = [int(context.arrays['label'][selected.cases[i], selected.sides[i], wi[i], hi[i]]) for i in indices]
                nets = [int(context.arrays['net'][selected.cases[i], selected.sides[i], wi[i], hi[i]])
                        for i in indices if context.arrays['known'][selected.cases[i], selected.sides[i], wi[i], hi[i]]]
                expected = {'count': len(indices), 'eligible_scenes': len(eligible),
                    'all_scenes': bool(eligible and all(counts[i] > 0 for i in eligible)),
                    'scenes': sum(c > 0 for c in counts), 'hours': hours,
                    'F': labels.count(1), 'A': labels.count(-1), 'N': labels.count(0), 'C': labels.count(2),
                    'profit': sum(max(n, 0) for n in nets), 'loss': sum(max(-n, 0) for n in nets)}
                actual = report['periods'][period][name][group]
                for key, expected_value in expected.items():
                    assert actual[key] == expected_value, (period, name, group, key)
                    cells += 1
    return cells


def main() -> None:
    """
    機能: RootSourceを変更せず、接続・統計・Day同体を人工検査する。
    引数: なし。自然ファイルは読まない。
    返り値: None。接続器人工レビュー.jsonへ記録する。
    """
    sys.stdout.reconfigure(encoding='utf-8')
    sources = {p.relative_to(ROOT).as_posix(): sha(p) for p in [TARGET, CHECK, HERE / 'engine172.py', Path(__file__)]}
    functions = extract()
    context, base, captures, directions = artificial()
    baseline = functions['replay'](context, base, {}, {}, captures=captures)
    rejected = 0
    for option in ({'key': 'P', 'width': 0, 'horizon': 'H30'},
                   {'key': 'P', 'width': -125, 'horizon': 'H30'},
                   {'key': 'P', 'width': 150, 'horizon': 'H30'},
                   {'key': 'P', 'width': 125.5, 'horizon': 'H30'},
                   {'key': 'P', 'width': 125, 'horizon': 'H90'}):
        try:
            functions['route'](context, base, {'PRE': option}, directions)
        except AssertionError:
            rejected += 1
        else:
            raise AssertionError(option)
    summary_cells = 0
    for post_horizon in ('H30', 'H60', 'H120', 'SESSION'):
        choice = {'PRE': {'key': 'P', 'width': 125, 'horizon': 'H30'},
                  'POST': {'key': 'Q', 'width': 1000, 'horizon': post_horizon}}
        current = functions['replay'](context, base, choice, directions, captures=captures)
        selected, origins, wi, hi, _, engine = current
        for i, event in enumerate(selected.events):
            phase = context.event_phases[event]
            expected_horizon = 'H60' if origins[i] == 2 or phase == 0 else 'H30' if phase == 1 else post_horizon
            expected_width = 200 if origins[i] == 2 else 125 if phase == 1 else 1000 if phase == 2 else 200 if base['branches'][event] == 0 else 400
            assert context.table.horizons[hi[i]] == expected_horizon
            assert context.table.widths[wi[i]] == expected_width
        day_scenes = set(np.flatnonzero(context.hours[:, 0] > 0).tolist())
        for key in ('records', 'requests'):
            original = [r for r in baseline[-1][key] if context.event_scenes[r['event']] in day_scenes]
            changed = [r for r in engine[key] if context.event_scenes[r['event']] in day_scenes]
            assert original == changed
        assert [baseline[-1]['audits'][i] for i in day_scenes] == [engine['audits'][i] for i in day_scenes]
        report = functions['describe'](context, current, details=True)
        summary_cells += verify_statistics(context, current, report)
        assert engine['audits'][0]['unknown_held_to_end'] >= 0
    # ----------------------------------------
    # 新期限側だけ未知の10建玉がcap10を占め、後続2要求を棄却する接続を確認する。
    small, _, _, _ = artificial()
    small.event_keys = [(float(2800 + i * 3), i * 10 + 1, i * 10 + 1) for i in range(12)]
    small.event_scenes = np.zeros(12, dtype=np.int16)
    small.event_phases = np.ones(12, dtype=np.int8)
    small.case_scene = np.zeros(146, dtype=np.int16)
    small.scenes = [{'start': 0., 'end': 15000.}]
    small.sessions = ['人工未知場']
    small.hours = np.array([[0., 1.5, 2.5]])
    small.arrays['known'][:10, :, :, :] = False
    small.arrays['label'][:10, :, :, :] = 2
    small.arrays['net'][:10, :, :, :] = 0
    short_birth = {'core': np.ones(12, dtype=np.int8), 'branches': np.zeros(12, dtype=np.int8),
                   'technical': np.zeros(12, dtype=np.int8), 'tier': np.zeros(12, dtype=np.int8)}
    short_captures = [{'status': 'filled', 'case': i,
                       'fill_key': (key[0] + 1, i * 10 + 2, i * 10 + 2),
                       'finish_key': (key[0] + 1, i * 10 + 2, i * 10 + 2)}
                      for i, key in enumerate(small.event_keys)]
    choice = {'PRE': {'key': 'P', 'width': 125, 'horizon': 'H30'}}
    unknown = functions['replay'](small, short_birth, choice,
                                  {'P': np.ones(12, dtype=np.int8)}, captures=short_captures)
    assert len(unknown[0].cases) == 10
    assert unknown[-1]['audits'][0]['unknown_held_to_end'] == 10
    assert unknown[-1]['audits'][0]['quantity_rejected_core'] == 2
    assert unknown[-1]['audits'][0]['peak_reserved_total'] == [10, 0]
    assert all(sha(ROOT / path) == digest for path, digest in sources.items())
    proof = {'成功': True, '自然入力読取': False, '対象import実行': False, 'RootSource変更': False,
             '定義抽出関数': ['route', 'replay', 'statistics', 'describe'],
             '人工場数': 73, '期限別条件数': 4, '統計独立照合セル': summary_cells,
             'q0期限と技術T200_H60': True, 'Day全要求取得場監査同体': True,
             '非法幅期限の拒否数': rejected, '未知10保有後続2棄却': True,
             'Source': sources,
             '注意': '正幅/table所属/期限のassertを確認。自然基準確認mainは未実行。'}
    (HERE / '接続器人工レビュー.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
