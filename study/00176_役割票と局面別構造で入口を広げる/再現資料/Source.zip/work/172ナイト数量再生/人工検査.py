"""172の出生別exit callbackと旧170同体を自然入力なしで検査する。"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import math
import sys

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OLD = ROOT / 'work/170ATRと三時間帯/engine170.py'
OLD_SHA = 'a834cdad94eac7e71bc1dce0ff267c16c6d2ca43fe4e4f9caa5ca7365ada10b8'


def sha(path: Path) -> str:
    """
    機能: SourceのSHA256を計算する。
    引数: path(Path)は読み込むSource。
    返り値: strはSHA256の16進表記。
    """
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def module(path: Path, name: str) -> object:
    """
    機能: 純engineだけを別名で読み込む。
    引数: path(Path)はSource、name(str)はmodule識別名。
    返り値: objectは読み込んだmodule。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def fixture(times: list, core: list, technical: list | None = None,
            end: float = 20000.) -> dict:
    """
    機能: 人工的な一場の要求・取得時計と配列幅を作る。
    引数: times(list[float])はq0秒、core(list[int])は主方向、
          technical(list[int]|None)は技術方向、end(float)は場末秒。
    返り値: dictは価格・金融・自然特徴を持たないengine入力。
    """
    n = len(times)
    technical = [0] * n if technical is None else technical
    return {
        'event_keys': [(float(t), i * 10 + 1, i * 10 + 1) for i, t in enumerate(times)],
        'event_scenes': np.zeros(n, dtype=np.int64),
        'scene_starts': np.array([0.]), 'scene_ends': np.array([end]),
        'captures': [{'status': 'filled', 'case': i,
                      'fill_key': (float(t + 1), i * 10 + 2, i * 10 + 2),
                      'finish_key': (float(t + 1), i * 10 + 2, i * 10 + 2)}
                     for i, t in enumerate(times)],
        'core': np.asarray(core),
        'branches': np.where(np.asarray(core) == 0, -1, np.arange(n) % 2),
        'technical': np.asarray(technical),
        'tiers': np.where(np.asarray(technical) == 0, 0, 1 + np.arange(n) % 2),
        'momentum_width': np.full(n, 200, dtype=np.int64),
        'fade_width': np.full(n, 400, dtype=np.int64),
        'technical_width': 150, 'after_seconds': 2700,
        'exit_lookup': lambda event, case, side, width: None,
    }


def oracle(data: dict, capacity: int | None) -> dict:
    """
    機能: heapを使わず時計一覧の全走査で数量枠を再生する独立oracle。
    引数: data(dict)は人工入力、capacity(int|None)は片側上限。
    返り値: dictは全要求・取得・予約ピーク・場末未決。engineを呼ばない。
    """
    records = []
    requests = []
    peaks = []
    final_pending = []
    serial = 0
    for scene, end in enumerate(data['scene_ends']):
        held = [0, 0]
        pending = [0, 0]
        calendar = []
        waiting = {}
        seen = set()
        ever = False
        peak = [0, 0]
        events = np.flatnonzero(data['event_scenes'] == scene).tolist()
        for event in events + [None]:
            now = (float(end), math.inf, math.inf) if event is None else data['event_keys'][event]
            while calendar:
                earliest = min(range(len(calendar)), key=lambda i: calendar[i][:2])
                key, order, kind, row = calendar[earliest]
                if key > now:
                    break
                calendar.pop(earliest)
                side = row['side']
                if kind == 'release':
                    held[side] -= 1
                    continue
                pending[side] -= 1
                waiting.pop(order)
                if kind == 'cancel' or row['case'] in seen:
                    continue
                seen.add(row['case'])
                held[side] += 1
                ever = True
                records.append({k: row[k] for k in ('event', 'case', 'side', 'width', 'origin', 'tier')})
                release = data['exit_lookup'](row['event'], row['case'], side, row['width'])
                release = end if release is None else release
                serial += 1
                calendar.append(((float(release), math.inf, math.inf), serial, 'release', row))
            if event is None:
                break
            original = int(data['core'][event])
            chosen = int(data['momentum_width'][event] if data['branches'][event] == 0
                         else data['fade_width'][event])
            effective = original if chosen > 0 else 0
            if effective:
                side = 0 if effective > 0 else 1
                origin = 0
                tier = 0
                width = chosen
            else:
                tech = int(data['technical'][event])
                if now[0] < data['scene_starts'][scene] + data['after_seconds'] or ever or not tech:
                    continue
                if waiting:
                    continue
                side = 0 if tech > 0 else 1
                origin = 2
                tier = int(data['tiers'][event])
                width = data['technical_width']
            row = {'event': event, 'scene_index': scene, 'side': side, 'width': width,
                   'origin': origin, 'tier': tier, 'at': list(now),
                   'held_before': held[side], 'pending_before': pending[side],
                   'accepted': capacity is None or held[side] + pending[side] < capacity}
            requests.append(row)
            if not row['accepted']:
                continue
            capture = data['captures'][event]
            filled = capture['status'] == 'filled'
            key = tuple(capture['fill_key'] if filled else capture['finish_key'])
            queued = {**row, 'case': capture['case'] if filled else -1}
            pending[side] += 1
            serial += 1
            calendar.append((key, serial, 'fill' if filled else 'cancel', queued))
            waiting[serial] = queued
            peak = [max(peak[s], held[s] + pending[s]) for s in (0, 1)]
        assert held == [0, 0]
        peaks.append(peak)
        final_pending.append(pending)
    records.sort(key=lambda row: (row['event'], row['origin']))
    return {'records': records, 'requests': requests, 'peaks': peaks, 'pending': final_pending}


def compare(engine: object, data: dict, capacity: int | None) -> dict:
    """
    機能: 172と独立一覧oracleの全要求・取得・数量ピークを照合する。
    引数: engine(object)は172、data(dict)は人工入力、capacity(int|None)は枠。
    返り値: dictは172の再生結果。相違時はAssertionError。
    """
    actual = engine.replay(**data, capacity=capacity)
    expected = oracle(data, capacity)
    assert actual['records'] == expected['records']
    assert actual['requests'] == expected['requests']
    assert [a['peak_reserved_total'] for a in actual['audits']] == expected['peaks']
    assert [a['pending_at_scene_end'] for a in actual['audits']] == expected['pending']
    return actual


def verify_ast() -> None:
    """
    機能: 旧170との実行AST差分がcallbackへeventを渡す一点だけと確認する。
    引数: なし。旧Sourceと新Sourceを読む。
    返り値: None。Docstring以外の追加変更があればAssertionError。
    """
    old_tree = ast.parse(OLD.read_text(encoding='utf-8'))
    new_tree = ast.parse((HERE / 'engine172.py').read_text(encoding='utf-8'))
    for tree in (old_tree, new_tree):
        tree.body = tree.body[1:]
        replay = next(node for node in tree.body if isinstance(node, ast.FunctionDef))
        replay.body = replay.body[1:]
    calls = [node for node in ast.walk(new_tree) if isinstance(node, ast.Call)
             and isinstance(node.func, ast.Name) and node.func.id == 'exit_lookup']
    assert len(calls) == 1 and len(calls[0].args) == 4
    assert ast.unparse(calls[0].args[0]) == "record['event']"
    calls[0].args = calls[0].args[1:]
    assert ast.dump(old_tree, include_attributes=False) == ast.dump(new_tree, include_attributes=False)


def main() -> None:
    """
    機能: 旧同体・可変幅・出生期限・枠・未知・aliasを人工入力だけで検査する。
    引数: なし。自然特徴・原板・金融・試行条件は読まない。
    返り値: None。人工確認.jsonとSourceSHA256.jsonを保存する。
    """
    sys.stdout.reconfigure(encoding='utf-8')
    assert sha(OLD) == OLD_SHA
    verify_ast()
    old = module(OLD, 'engine170_control172')
    new = module(HERE / 'engine172.py', 'engine172_target')
    rng = np.random.default_rng(20261115172)
    constant_rows = 0
    variable_rows = 0
    mirrored_rows = 0
    prefix_rows = 0
    # ----------------------------------------
    # 同じ旧H60時計をevent無視adapterで渡し、全dictの同体を確認する。
    for sample in range(240):
        n = 60
        times = (np.arange(n) * 7 + 2700).tolist()
        data = fixture(times, rng.choice((-1, 0, 1), n).tolist(),
                       rng.choice((-1, 0, 1), n).tolist())
        exits = {}
        for first in range(0, n, 2):
            fill = float(times[first + 1] + rng.integers(1, 40))
            key = (fill, first * 10 + 8, first * 10 + 8)
            cancelled = rng.random() < .2
            for event in (first, first + 1):
                data['captures'][event] = ({'status': 'cancelled', 'finish_key': key} if cancelled else
                    {'status': 'filled', 'case': first, 'fill_key': key, 'finish_key': key})
            exits[first] = None if rng.random() < .15 else fill + 3600.

        def old_h60(case: int, side: int, width: int) -> float | None:
            """
            機能: 人工H60決済時計を旧callback形式で返す。
            引数: case/side/width(int)は取得済み建玉。
            返り値: float|Noneは人工既知時計又は未知。
            """
            return exits[case]

        def adapted_h60(event: int, case: int, side: int, width: int) -> float | None:
            """
            機能: eventを無視して既存H60 callbackを172へ接続する。
            引数: event/case/side/width(int)は取得済み出生と建玉。
            返り値: float|Noneは旧H60時計そのもの。
            """
            return old_h60(case, side, width)

        capacity = (None, 1, 2, 10)[sample % 4]
        expected = old.replay(**{**data, 'exit_lookup': old_h60}, capacity=capacity)
        data['exit_lookup'] = adapted_h60
        actual = new.replay(**data, capacity=capacity)
        assert actual == expected
        constant_rows += n
        # ----------------------------------------
        # 幅配列とevent別時計を変更し、別の一覧実装・鏡像・未来接頭を照合する。
        data['momentum_width'] = rng.choice([0, 150, 200, 400, 750, 1000], n)
        data['fade_width'] = rng.choice([0, 175, 250, 500, 1000], n)
        event_exits = rng.choice([1800, 3600, 7200, -1, 20000], n)

        def event_exit(event: int, case: int, side: int, width: int) -> float | None:
            """
            機能: 出生と取得幅に応じる人工時計を返す。
            引数: event/case/side/width(int)は取得済み出生と建玉。
            返り値: float|Noneは場末以下の時計又は未知。
            """
            if event_exits[event] == -1:
                return None
            fill = data['captures'][event]['fill_key'][0]
            return min(float(data['scene_ends'][0]), fill + event_exits[event] + width / 1000)

        data['exit_lookup'] = event_exit
        actual = compare(new, data, capacity)
        variable_rows += n
        reflected = {**data, 'core': -data['core'], 'technical': -data['technical']}
        other = compare(new, reflected, capacity)
        for a, b in zip(actual['records'], other['records'], strict=True):
            assert all(a[k] == b[k] for k in a if k != 'side') and a['side'] == 1 - b['side']
        assert [a['peak_reserved_total'][::-1] for a in actual['audits']] == [
            a['peak_reserved_total'] for a in other['audits']]
        mirrored_rows += n
        cut = sample % n
        poisoned = {**data, 'momentum_width': data['momentum_width'].copy(),
                    'fade_width': data['fade_width'].copy()}
        poisoned['momentum_width'][cut:] = 0
        poisoned['fade_width'][cut:] = 0
        future = compare(new, poisoned, capacity)
        assert [r for r in actual['requests'] if r['event'] < cut] == [
            r for r in future['requests'] if r['event'] < cut]
        prefix_rows += cut
    # ----------------------------------------
    # 同じcase/side/widthでもeventによりDay/PRE/POST/技術を区別する。
    data = fixture([20, 40, 60, 80, 100, 120], [1, 1, 1, 1, 1, 1])
    data['after_seconds'] = 0
    data['core'][0] = 0
    data['branches'][0] = -1
    data['technical'][0] = 1
    data['tiers'][0] = 1
    data['core'][1] = 1
    data['technical'][1] = 1
    data['tiers'][1] = 2
    data['momentum_width'][1] = 0
    data['fade_width'][1] = 0
    phases = ['POST', 'PRE', 'DAY', 'PRE', 'POST', 'POST']
    horizons = ['SESSION', 'H120', 'H120', 'H30', 'H120', 'SESSION']
    chosen = np.where(data['branches'] == 0, data['momentum_width'], data['fade_width'])
    effective_core = (data['core'] != 0) & (chosen > 0)
    observed = []

    def phase_exit(event: int, case: int, side: int, width: int) -> float:
        """
        機能: 人工q0帯と実効coreを用い、技術/DayはH60、夜間主は指定期限にする。
        引数: event/case/side/width(int)は取得済み出生と建玉。
        返り値: floatは人工取得時からの期限時計又は場末。
        """
        horizon = 'H60' if not effective_core[event] or phases[event] == 'DAY' else horizons[event]
        observed.append((event, case, side, width, horizon))
        fill = data['captures'][event]['fill_key'][0]
        return float(data['scene_ends'][0]) if horizon == 'SESSION' else fill + int(horizon[1:]) * 60

    data['exit_lookup'] = phase_exit
    result = new.replay(**data, capacity=10)
    # event1の技術は初参加後なので要求されない。同じ原core非ゼロ/幅0の単独場で別確認する。
    assert [(r[0], r[-1]) for r in observed] == [(0, 'H60'), (2, 'H60'), (3, 'H30'),
                                                                   (4, 'H120'), (5, 'SESSION')]
    assert result['records'][0]['origin'] == 2
    fallback = fixture([40], [1], [1])
    fallback['after_seconds'] = 0
    fallback['momentum_width'][0] = fallback['fade_width'][0] = 0
    fallback_seen = []

    def fallback_exit(event: int, case: int, side: int, width: int) -> float:
        """
        機能: 幅0で無効になった元coreの技術補完をH60として確認する。
        引数: event/case/side/width(int)は取得済み出生と建玉。
        返り値: floatは人工取得後H60の時計。
        """
        fallback_seen.append((event, case, side, width))
        return 41. + 3600.

    fallback['exit_lookup'] = fallback_exit
    assert new.replay(**fallback, capacity=1)['records'][0]['origin'] == 2
    assert fallback_seen == [(0, 0, 0, 150)]
    # ----------------------------------------
    # q0がPREで取得がPOSTへ遅れた場合も、callbackへ元eventを渡す。
    crossing = fixture([40, 60], [1, 1])
    crossing['captures'][0]['fill_key'] = (70., 8, 8)
    crossing['captures'][0]['finish_key'] = (70., 8, 8)
    birth_seen = []

    def birth_exit(event: int, case: int, side: int, width: int) -> float:
        """
        機能: 取得時刻ではなくq0で区分した人工期限を返す。
        引数: event/case/side/width(int)は取得済み出生と建玉。
        返り値: floatはPREのH30又はPOSTのH120時計。
        """
        phase = 'PRE' if crossing['event_keys'][event][0] < 50 else 'POST'
        birth_seen.append((event, phase))
        return crossing['captures'][event]['fill_key'][0] + (1800 if phase == 'PRE' else 7200)

    crossing['exit_lookup'] = birth_exit
    new.replay(**crossing, capacity=1)
    assert birth_seen == [(0, 'PRE')]
    # ----------------------------------------
    # 同秒exitは秒末、未知は場末、保有と未決は片側別に枠を使う。
    same = fixture([0, 1, 6, 7], [1, 1, 1, 1])
    same['captures'][0]['fill_key'] = (2., 8, 8)
    same['exit_lookup'] = lambda event, case, side, width: 6. if case == 0 else 19000.
    assert [r['event'] for r in compare(new, same, 1)['records']] == [0, 3]
    unknown = fixture([0, 3, 4, 5], [1, 1, -1, -1])
    unknown['exit_lookup'] = lambda event, case, side, width: None
    result = compare(new, unknown, 1)
    assert [r['event'] for r in result['records']] == [0, 2]
    assert result['audits'][0]['unknown_held_to_end'] == 2
    assert result['audits'][0]['peak_reserved_total'] == [1, 1]
    pending = fixture([0, 5], [1, 1], end=100.)
    pending['captures'][0]['fill_key'] = pending['captures'][0]['finish_key'] = (110., 8, 8)
    result = compare(new, pending, 1)
    assert result['records'] == [] and result['audits'][0]['pending_at_scene_end'] == [1, 0]
    assert result['requests'][1]['accepted'] is False
    # ----------------------------------------
    # 既知期限の長短が後続要求へ影響し、未知を短期限として空けない。
    duration = fixture([0, 2000, 4000, 8000], [1, 1, 1, 1])
    release = {}
    for name, seconds in [('H30', 1800), ('H60', 3600), ('H120', 7200), ('SESSION', None)]:
        duration['exit_lookup'] = (lambda event, case, side, width, sec=seconds:
            20000. if sec is None else duration['captures'][event]['fill_key'][0] + sec)
        release[name] = [r['event'] for r in compare(new, duration, 1)['records']]
    assert release == {'H30': [0, 1, 2, 3], 'H60': [0, 2, 3], 'H120': [0, 3], 'SESSION': [0]}
    # ----------------------------------------
    # 場を跨ぐリセットと、aliasではcallbackを二重に呼ばないことを確認する。
    scenes = fixture([0, 20], [1, 1])
    scenes['event_scenes'] = np.array([0, 1])
    scenes['scene_starts'] = np.array([0., 10.])
    scenes['scene_ends'] = np.array([10., 30.])
    assert len(compare(new, scenes, 1)['records']) == 2
    alias = fixture([0, 1, 5], [1, 1, 1])
    alias['captures'][0] = {'status': 'filled', 'case': 99, 'fill_key': (3., 8, 8), 'finish_key': (3., 8, 8)}
    alias['captures'][1] = dict(alias['captures'][0])
    calls = []

    def alias_exit(event: int, case: int, side: int, width: int) -> float | None:
        """
        機能: alias取得でcallbackが一度だけ呼ばれることを記録する。
        引数: event/case/side/width(int)は実際に採用された取得元。
        返り値: Noneは未知であり場末まで保有する。
        """
        calls.append((event, case))
        return None

    alias['exit_lookup'] = alias_exit
    result = new.replay(**alias, capacity=2)
    assert calls == [(0, 99), (2, 2)]
    assert result['audits'][0]['alias_fills_skipped'] == 1
    assert sha(OLD) == OLD_SHA
    sources = {p.relative_to(ROOT).as_posix(): sha(p) for p in [OLD, HERE / 'engine172.py', Path(__file__)]}
    proof = {'成功': True, '自然特徴と原板と金融の入力': False,
             '旧170全dict同体H60行数': constant_rows, '独立一覧oracle可変幅行数': variable_rows,
             '売買鏡像行数': mirrored_rows, '未来幅の接頭照合行数': prefix_rows,
             'Day主H60と技術補完H60': True, 'Night主のH30_H60_H120_SESSION選択': True,
             'q0出生帯と取得後帯を区別': True, '元core非ゼロ幅0の技術補完': True,
             '同秒exitは秒末解放': True, '未知exitは場末保持': True,
             '場末未決を保持': True, '場跨ぎ状態リセット': True,
             'aliasでcallback重複なし': True, '片側capと未決予約を維持': True,
             '期限別の後続取得': release, '旧170の実行AST差分はcallback第一引数だけ': True,
             '元170Source不変': True, 'Source': sources,
             '限界': '純engineと人工時計だけの検査。自然数量再生adapter、自然取得・損益、NY日時変換は未検証。'}
    (HERE / '人工確認.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (HERE / 'SourceSHA256.json').write_text(json.dumps(sources, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
