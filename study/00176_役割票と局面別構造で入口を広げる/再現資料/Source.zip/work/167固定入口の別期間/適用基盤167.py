"""固定した複合入口を可変個数の場へ同じ式で適用する。"""
from pathlib import Path
from types import SimpleNamespace
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/163入口と任意幅'))
from 共通163 import read,sha,module,data_module
sys.path.insert(0,str(ROOT/'work/165順行と回復失敗の複合'))
from 評価基盤165 import Context165,quote_key
sys.path.insert(0,str(ROOT/'work/162入口探索'))
from 評価基盤 import Context

birth165=module(ROOT/'work/165順行と回復失敗の複合/出生を作る.py','birth165_for167')
local=module(ROOT/'work/166可用指標の階層化/local166.py','local166_for167')
library=module(ROOT/'work/162複合入口候補/rules162.py','rules162_for167')


def load_features(directory: Path) -> tuple:
    """
    機能: 接続器の全非金融出力を指紋確認し、既存100列の型へ接続する。
    引数: directory(Path)は接続器の完了済み出力先。
    返り値: tuple[FeatureDataset,list,dict]は当時特徴・取得対応・ファイル指紋。
    """
    proof=read(directory/'完了.json')
    assert proof['success'] and proof['financial_labels_used'] is False and proof['strategy_selected'] is False
    values={}
    for name,ref in proof['files'].items():
        path=directory/name
        assert path.stat().st_size==ref['bytes'] and sha(path)==ref['sha256']
        values[name]=read(path)
        assert values[name]['success'] and values[name]['financial_labels_used'] is False
    data=data_module();source=values['当時特徴.json.gz'];fixed=values['固定取得入力.json.gz']
    scenes=[{k:s[k] for k in data.SCENE_KEYS} for s in fixed['scenes']]
    scene_map={s['session']:i for i,s in enumerate(scenes)}
    meta=[];buy=[];sell=[]
    for row in source['rows']:
        q0=row['metadata']['q0']
        meta.append({'event_id':row['event_id'],'session':row['session'],'contract':row['contract'],
            'session_index':scene_map[row['session']],'q0_time':q0['time'],
            'q0_index':q0['index'],'q0_line':q0['source_line']})
        assert row['buy']['side']==1 and row['sell']['side']==-1
        buy.append(row['buy']['x']);sell.append(row['sell']['x'])
    names=[c['name'] for c in source['catalog']]
    result=data.feature_dataset_from_objects(names,np.array(buy,dtype=float).reshape(-1,100),
        np.array(sell,dtype=float).reshape(-1,100),meta,scenes,proof['files'],len(scenes),len(meta))
    return result,values['取得対応.json.gz']['rows'],proof['files']


def births(features: object, candidate: dict) -> dict:
    """
    機能: 主順行・回復失敗・既存T・長期未知時局所を元と同じ式で作る。
    引数: features(FeatureDataset)は非金融100列、candidate(dict)は固定候補。
    返り値: dictはcore/branches/technical/tier等の全q0方向。金融引数は持たない。
    """
    profile=candidate['profile'];assert profile['background']==0 and profile['timing']=='IMMEDIATE'
    catalog={r['id']:r for r in library.candidate_catalog()}
    evaluator=library.PreparedEvaluator(features.buy_X,features.sell_X,list(features.columns),target_points=200)
    a=evaluator.evaluate_one(catalog[profile['momentum']])['directions']
    b=-evaluator.evaluate_one(catalog[profile['fade']])['directions']
    conflict=(a!=0)&(b!=0)&(a!=b)
    direction=np.where(conflict,0,np.where(a!=0,a,b)).astype(np.int8)
    branch=np.where(direction==0,-1,np.where(a!=0,0,1)).astype(np.int8)
    tw=int(candidate['integration'][1:]);assert tw in (150,200)
    evaluator=library.PreparedEvaluator(features.buy_X,features.sell_X,list(features.columns),target_points=tw)
    old=birth165.technical_first(features,evaluator)
    hierarchy=candidate['hierarchy']
    result=local.evaluate_local(features.buy_X,features.sell_X,list(features.columns),features.q0_meta,
        np.array([s['start'] for s in features.scenes]),hierarchy['after_minutes'],hierarchy['minimum_score'])
    combined,tier=local.merge_hierarchy(np.stack((old,old)),result['directions'])
    assert np.array_equal(combined[0],combined[1])
    return {'core':direction,'branches':branch,'technical':combined[0],'tier':tier[0],
        'oldtechnical':old,'local':result['directions'],'local_eligible':result['eligible']}


class GenericContext:
    """母集団の場数を変えても当時の取得/pending制御を直接再利用する。"""
    link=Context.link
    technical_integrate=Context165.technical_integrate

    def __init__(self, features: object, table: object, captures: list) -> None:
        """
        機能: 非金融取得対応と指紋済み数値表を同じ原行キーで結ぶ。
        引数: self(GenericContext)、features(FeatureDataset)、table(RawOutcomeTable)、captures(list[dict])。
        返り値: None。C1参照は作らず、場0件・未知・正常価格時計を保持する。
        """
        self.features=features;self.table=table;self.arrays=table.root_arrays().copy()
        strict=self.arrays['label'];known=self.arrays['known'];direction=table.arrays['direction']
        labels=np.where(known&(direction!=0),direction,np.where(strict==0,0,2)).astype(np.int8)
        assert np.array_equal(labels==2,~known)
        maturity=np.where((labels==1)|(labels==-1),self.arrays['exit_time'],self.arrays['known_at'])
        self.arrays['label']=labels;self.arrays['known_at']=np.where(labels!=2,maturity,np.nan)
        self.case_map=table.case_to_index();self.sessions=list(table.session_order)
        self.scenes=features.scenes;assert [s['session'] for s in self.scenes]==self.sessions
        self.case_scene=self.arrays['session_index'];self.starts=np.array([s['start'] for s in self.scenes])
        self.event_scenes=np.array([q['session_index'] for q in features.q0_meta],dtype=np.int16)
        self.event_phases=features.q0_timeband
        by_event={r['event_id']:r for r in captures};assert len(by_event)==len(captures)==len(features.q0_meta)
        self.capture_rows=[by_event[q['event_id']] for q in features.q0_meta]
        self.event_keys=[(q['q0_time'],q['q0_index'],q['q0_line']) for q in features.q0_meta]
        self.event_cases=np.full(len(features.q0_meta),-1,dtype=np.int32)
        self.end_keys=[]
        for i,row in enumerate(self.capture_rows):
            assert quote_key(row['q0'])==self.event_keys[i]
            expiry=(row['expires'],float('inf'),float('inf'))
            terminated=quote_key(row['terminated_at']) if row.get('terminated_at') is not None else expiry
            self.end_keys.append(min(expiry,terminated))
            if row['status']=='filled':
                case=self.case_map[row['case_id']];self.event_cases[i]=case
                assert self.case_scene[case]==self.event_scenes[i]
                assert tuple(self.arrays['entry_'+k][case] for k in ('time','index','line'))==quote_key(row['q1'])
        self.scene_events=[np.flatnonzero(self.event_scenes==i) for i in range(len(self.scenes))]
        data=data_module();self.hours=np.zeros((len(self.scenes),3))
        for i,scene in enumerate(self.scenes):
            end=scene['end']-300
            if scene['session'].endswith('_Day'):self.hours[i,0]=(end-scene['start'])/3600
            else:
                boundary=data.us_open_time(scene['session'])
                self.hours[i,1]=max(0,min(end,boundary)-scene['start'])/3600
                self.hours[i,2]=max(0,end-max(scene['start'],boundary))/3600
        self.case_phases=np.array([data.timeband(s,float(t)) for s,t in
            zip(table.sessions,self.arrays['entry_time'],strict=True)],dtype=np.int8)


def selection(context: GenericContext, birth: dict, candidate: dict) -> tuple:
    """
    機能: 固定出生を実取得に結び、枝幅と補完階層を対応付ける。
    引数: context(GenericContext)、birth(dict[np.ndarray])、candidate(dict)。
    返り値: tupleはSelection/origins/widths/tiers/audits。
    """
    core=context.link(birth['core'])
    selected,origins,audits=context.technical_integrate(birth['core'],core,birth['technical'])
    width=np.where(origins==2,int(candidate['integration'][1:]),
        np.where(birth['branches'][selected.events]==0,candidate['momentum_width'],candidate['fade_width']))
    assert np.isin(width,context.table.widths).all()
    widths=np.array([context.table.widths.index(int(w)) for w in width],dtype=np.int8)
    tiers=np.where(origins==2,birth['tier'][selected.events],0).astype(np.int8)
    assert np.isin(tiers[origins==2],(1,2)).all()
    return selected,origins,widths,tiers,audits


def statistics(context: GenericContext, selected: object, widths: np.ndarray, hi: int,
               mask: np.ndarray | None=None, eligible_scenes: np.ndarray | None=None,
               hours: float | None=None) -> dict:
    """
    機能: 可変場の先着と既知損益を同じ取得分母のまま集計する。
    引数: context(GenericContext)、selected(Selection)、widths(np.ndarray[int])、hi(int)、
          mask/eligible_scenes(np.ndarray[bool]|None)、hours(float|None)は分解範囲。
    返り値: dictはFANC・率・利益損失・参加・保有。未知の全件収支はnullを残す。
    """
    if mask is None:mask=np.ones(len(selected.cases),dtype=bool)
    if eligible_scenes is None:eligible_scenes=np.ones(len(context.scenes),dtype=bool)
    if hours is None:hours=float(context.hours[eligible_scenes].sum())
    cases=selected.cases[mask];sides=selected.sides[mask];wi=widths[mask]
    labels=context.arrays['label'][cases,sides,wi,hi];known=context.arrays['known'][cases,sides,wi,hi]
    money=context.arrays['net'][cases,sides,wi,hi][known]
    f,a,n,c=[int(np.sum(labels==code)) for code in (1,-1,0,2)]
    assert len(cases)==f+a+n+c and c==int((~known).sum())
    profit=int(np.maximum(money,0).sum());loss=int(-np.minimum(money,0).sum())
    count=np.bincount(context.case_scene[cases],minlength=len(context.scenes))
    hold=context.arrays['exit_time'][cases,sides,wi,hi][known]-context.arrays['entry_time'][cases][known]
    return {'count':len(cases),'F':f,'A':a,'N':n,'C':c,'rate':f/(f+a) if f+a else None,
        'complete_rate':f/(f+a+n) if f+a+n else None,'all_rate':f/len(cases) if len(cases) else None,
        'profit':profit,'loss':loss,'net':profit-loss,'pf':profit/loss if loss else None,
        'known':int(known.sum()),'unknown':c,'all_net':profit-loss if c==0 else None,
        'wins':int((money>0).sum()),'loss_trades':int((money<0).sum()),
        'realized_win_rate':float((money>0).mean()) if len(money) else None,
        'scenes':int(np.count_nonzero(count)),'eligible_scenes':int(eligible_scenes.sum()),
        'all_scenes':bool(eligible_scenes.any() and np.all(count[eligible_scenes]>0)),
        'hours':hours,'per_hour':len(cases)/hours if hours else None,
        'max_scene_share':int(count.max())/len(cases) if len(cases) else None,
        'hold_mean_seconds':float(hold.mean()) if len(hold) else None,
        'hold_median_seconds':float(np.median(hold)) if len(hold) else None}
