"""固定した163金融算術を再用し、場数・case数・q1入力の由来だけを一般化する。"""
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import sys

ROOT = Path(__file__).resolve().parents[2]
DEPENDENCY = ROOT / 'work/163任意幅の数値化/arrays163.py'
DEPENDENCY_SHA = '0231ea14ce03979a733d1a307c175266ff6aed2492dbc283162de63e153b23e6'


def sha(path: Path) -> str:
    """
    機能: 入力又は固定依存Sourceの全物理指紋を計算する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


assert sha(DEPENDENCY) == DEPENDENCY_SHA
_spec = importlib.util.spec_from_file_location('arrays163_frozen_for166', DEPENDENCY)
_old = importlib.util.module_from_spec(_spec)
sys.modules[_spec.name] = _old
_spec.loader.exec_module(_old)

# ----------------------------------------
# 金融・未知mask・保存形式は同じ関数を直接呼び、複製した別算術を作らない。
RawOutcomeTable = _old.RawOutcomeTable
allocate = _old.allocate
fill_case = _old.fill_case
save_table = _old.save_table
load_table = _old.load_table
checked_json = _old.checked_json
checked_raw_ref = _old.checked_raw_ref
load_records = _old.load_records


def fixed_json(path: Path, expected: str, decoded_expected: str | None) -> tuple[dict, str]:
    """
    機能: 可変q1入力を圧縮有無に依存せず全SHA/CRC付きで読み取る。
    引数: path(Path)、expected(str)、decoded_expected(str|None)。
    返り値: tuple[dict,str]は内容と実解凍SHA。
    """
    assert sha(path) == expected
    body = path.read_bytes()
    decoded = gzip.decompress(body) if body[:2] == b'\x1f\x8b' else body
    actual = hashlib.sha256(decoded).hexdigest()
    assert decoded_expected is None or decoded_expected == actual
    value = json.loads(decoded, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
    assert sha(path) == expected
    return value, actual


def read_table(index_directory: Path, index_sha: str, observation_directory: Path,
               observation_sha: str, config_path: Path, config_sha: str,
               fixed_path: Path, fixed_sha: str, fixed_decoded_sha: str | None = None) -> RawOutcomeTable:
    """
    機能: 固定された任意個数の場・q1を旧163と同じ純金融配列へ写す。
    引数: index_directory/observation_directory/config_path/fixed_path(Path)、
          index_sha/observation_sha/config_sha/fixed_sha(str)、fixed_decoded_sha(str|None)。
    返り値: RawOutcomeTableはcase辞書順×両実側×幅×期限。case0の場もsession_orderへ残す。
    """
    im = checked_json(index_directory / 'manifest.json', index_sha)
    om = checked_json(observation_directory / 'manifest.json', observation_sha)
    config = checked_json(config_path, config_sha)
    fixed, decoded = fixed_json(fixed_path, fixed_sha, fixed_decoded_sha)
    assert im['success'] and im['version'] in (163, 166)
    assert om['success'] and type(om['trial']) is int and om['trial'] > 0 and om['new_entry_selection'] is False
    assert om.get('component_version') == 166 or om['trial'] in (163, 166)
    assert om['index_manifest_sha256'] == index_sha and om['config_sha256'] == config_sha and om['config'] == config
    assert om['input_sha256'] == fixed_sha
    if om['trial'] == 163 and om.get('component_version') != 166:
        assert im['input_sha256'] == fixed_sha and im['input_decoded_sha256'] == decoded
    else:
        assert om['input_decoded_sha256'] == decoded
        assert om['index_input_sha256'] == im['input_sha256']
        assert om['index_input_decoded_sha256'] == im['input_decoded_sha256']
        assert om['index_input_differs_from_entries'] == (im['input_sha256'] != fixed_sha)
    scenes = fixed['scenes']
    assert 0 < len(scenes) < 32768
    order = tuple(scene['session'] for scene in scenes)
    assert len(order) == len(set(order)) and len(om['scenes']) == len(scenes)
    assert [scene['session'] for scene in om['scenes']] == list(order)
    indexed = {scene['session']: scene for scene in im['scenes']}
    assert len(indexed) == len(im['scenes'])
    all_entries = [entry for scene in scenes for entry in scene['entries']]
    ids = tuple(sorted(entry['id'] for entry in all_entries))
    assert len(ids) == len(set(ids)) == fixed['expected_entry_count'] == om['source_entry_count']
    assert all(type(case_id) is str and case_id for case_id in ids)
    mapping = {case_id: i for i, case_id in enumerate(ids)}
    sessions = [''] * len(ids)
    widths = tuple(config['widths'])
    horizon_ids = tuple(horizon['id'] for horizon in config['horizons'])
    arrays = allocate(len(ids), widths, horizon_ids)
    status_codes = {}
    previous_end = 0
    for scene_index, (scene, observed_ref) in enumerate(zip(scenes, om['scenes'], strict=True)):
        session = scene['session']
        assert scene['start'] > previous_end and scene['end'] > scene['start']
        previous_end = scene['end']
        index_ref = indexed[session]
        assert index_ref['success'] and observed_ref['success'] and index_ref['all_entries_matched']
        assert index_ref['contract'] == scene['contract']
        assert scene.get('expected_quality') is None or index_ref['quality'] == scene['expected_quality']
        assert not scene.get('expected_accepted', 0) or index_ref['rows'] == scene['expected_accepted']
        checked_raw_ref(scene['raw'], index_ref)
        index_name = index_ref['index']['path']
        observed_name = observed_ref['file']['path']
        assert index_name == session + '.quotes.bin.gz' and observed_name == session + '.outcomes.json.gz'
        records = load_records(index_directory / index_name, index_ref['index']['sha256'], index_ref['rows'])
        observed = checked_json(observation_directory / observed_name, observed_ref['file']['sha256'], True)
        assert observed['success'] and observed['session'] == session
        entries = {entry['id']: entry for entry in scene['entries']}
        assert len(entries) == len(scene['entries']) == observed_ref['cases']
        seen = set()
        for case in observed['cases']:
            case_id = case['id']
            assert case_id in entries and case_id not in seen
            row = mapping[case_id]
            fill_case(arrays, row, case, entries[case_id], records, widths, horizon_ids,
                      config, status_codes, scene['end'] - 300)
            arrays['session_index'][row] = scene_index
            sessions[row] = session
            seen.add(case_id)
        assert seen == set(entries)
    assert all(sessions)
    evidence = {'成功': True, '純観測のみ': True, '採否なし': True, '入力物理SHA256': fixed_sha,
                '入力解凍SHA256': decoded, '索引manifestSHA256': index_sha,
                '観測manifestSHA256': observation_sha, '観測条件SHA256': config_sha,
                '全対象場': order, '場数': len(order), 'case数': len(ids),
                '全索引と観測gzipの物理SHAとCRC': True, 'side_order': [1, -1], '条件': config,
                '固定依存Source': {'path': str(DEPENDENCY), 'sha256': DEPENDENCY_SHA},
                '未知net0は格納値': '必ずknownを伴って集計する。points/時計は未知NaN。',
                'SESSION成熟時計': '境界を最初に観測した原行の価格時計。清算endpoint時計とは分ける。',
                'label時計': '163 strictを保存。観測済みtouchの164再分類は利用側で別に固定する。',
                '実行試行': om['trial'], '部品版': 166}
    return RawOutcomeTable(ids, tuple(sessions), order, widths, horizon_ids, horizon_ids,
                           arrays, tuple(sorted(status_codes, key=status_codes.get)), evidence)
