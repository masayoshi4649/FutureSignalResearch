"""174固定少数政策をデイ補完遅延込みで純出生封印し、追加七場と全80場を評価する。"""
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime, timezone
import gzip
import argparse
import hashlib
import json
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'work/173両中央値と単一建玉'))
import 基盤173 as B
from 構成173 import compose

FIXED = ROOT / 'work/174参加と両中央値の再探索/旧73jointの固定選択.json'
OLD_REPORT = ROOT / 'work/174参加と両中央値の再探索/三帯接合global1.json.gz'
STAGE_SOURCE = ROOT / 'work/174参加と両中央値の再探索/段階再生174.py'
HORIZONS = ['H30', 'H60', 'H120', 'SESSION']


def physical(path: Path) -> dict:
    """
    機能: 正式参照・Source・生成出生の物理指紋を返す。
    引数: path(Path)はリポジトリ内ファイル。
    返り値: dictはpath/bytes/sha256。
    """
    with path.open('rb') as source:
        digest = hashlib.file_digest(source, 'sha256').hexdigest()
    return {'path': path.resolve().relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest}


def save(path: Path, value: dict) -> None:
    """
    機能: 非有限値を拒否して日本語UTF-8のJSON又はgzipを保存する。
    引数: path(Path)は出力、value(dict)は保存値。
    返り値: None。
    """
    raw = (json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n').encode('utf-8')
    path.write_bytes(gzip.compress(raw, mtime=0) if path.suffix == '.gz' else raw)


def fixed_policies(expected_sha: str) -> list[dict]:
    """
    機能: Root固定SHAを確認し全期/前48各最大二件の保存政策だけを取り出す。
    引数: expected_sha(str)はRootがGO時に示す固定選択票のSHA256。追加七場の金融は読まない。
    返り値: list[dict]は全期/前48の保存順の政策。候補追加・再選択・閾値変更は行わない。
    """
    assert len(expected_sha) == 64 and physical(FIXED)['sha256'] == expected_sha
    fixed = B.P.read(FIXED)
    assert fixed['成功'] and fixed['追加7当該候補結果未読']
    choices = []
    for route in ('全期', '前48'):
        rows = fixed['選択'][route]['candidates']
        assert len(rows) <= 2 and all(r['route'] == route for r in rows)
        choices.extend(rows)
    assert choices and len({r['id'] for r in choices}) == len(choices)
    return choices


def sources() -> list[Path]:
    """
    機能: 実行前後に同体確認する固定部品と新再現Sourceを列挙する。
    引数: なし。
    返り値: list[Path]はSourceと固定選択票・旧正本。
    """
    return [Path(__file__), HERE/'README.md', FIXED, OLD_REPORT,
        ROOT/'work/173両中央値と単一建玉/基盤173.py', ROOT/'work/173両中央値と単一建玉/構成173.py',
        STAGE_SOURCE, ROOT/'work/174参加と両中央値の再探索/数量候補を選ぶ.py',
        ROOT/'work/173追加なしの因果再生/engine173.py', ROOT/'work/173追加なしの評価/metrics173.py',
        ROOT/'work/172ナイト入口探索/選定政策の出生.py', ROOT/'work/171三帯の入口切替/route171.py',
        ROOT/'work/167固定入口の別期間/適用基盤167.py', ROOT/'work/173局所技術の主入口/local173.py',
        ROOT/'work/173局所技術の主入口/SourceCatalog.json', ROOT/'work/174参加と両中央値の再探索/短表の純出生173.npz']


def build_directions(features: object, policies: list[dict]) -> dict:
    """
    機能: 固定政策の旧1460/新768を172純出生部品、LOCALを固定173純部品で再生成する。
    引数: features(FeatureDataset)は当時純特徴、policies(list[dict])は固定参考案。
    返り値: dict[str,np.ndarray]は既適用modeと正逆を含むbirth_key別方向。金融を入力しない。
    """
    rules = {r['birth_key']: r for p in policies for rows in p['options'].values() for r in rows}
    builder = B.P.module(ROOT/'work/172ナイト入口探索/選定政策の出生.py', 'birth172_for174_added')
    options = [{'key': key, 'source': r['source'], 'rule': r['rule'], 'entry_mode': r['mode'],
        'orientation': r['orientation'], 'width': r['width'], 'horizon': r['horizon']}
        for key, r in rules.items() if r['source'] in ('OLD1460', 'NEW768')]
    result = builder.build(features, options)
    local_rules = {key: r for key, r in rules.items() if r['source'] == 'LOCAL173'}
    if local_rules:
        local = B.P.module(ROOT/'work/173局所技術の主入口/local173.py', 'local173_added')
        born = local.build({'buy_X': features.buy_X, 'sell_X': features.sell_X, 'columns': features.columns,
            'q0_meta': features.q0_meta, 'scene_starts': np.array([s['start'] for s in features.scenes]),
            'phases': features.q0_timeband})
        lookup = {name: i for i, name in enumerate(born['candidate_ids'])}
        for key, rule in local_rules.items():
            direction = born['directions'][lookup[rule['rule']]].copy()
            result[key] = direction if rule['orientation'] == 'NORMAL' else -direction
    assert set(result) == set(rules)
    return result


def freeze_births(policies: list[dict], before: dict, stage: object) -> dict:
    """
    機能: 旧73と追加7の純出生・幅・期限を金融読込前に固定する。
    引数: policies(list[dict])は固定案、before(dict)は実行前Source指紋、stage(object)は174のデイ補完遅延純部品。
    返り値: dictは出生NPZ参照・非金融入力指紋・旧出生の一致記録。
    """
    data = B.P.R168.BASE.data_module()
    old = data.load_feature_dataset()
    added_dir = ROOT/'inputs/00167_追加七場の入口と共用価格索引/入口母集団'
    added, _, _ = B.P.R168.BASE.load_features(added_dir)
    inputs = [ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only/features.npz',
        ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only/features_meta.json',
        *[added_dir/n for n in ('完了.json', '当時特徴.json.gz', '固定取得入力.json.gz', '取得対応.json.gz')]]
    proof = {'成功': True, '追加7金融未読': True, 'Sourceと固定選択': before,
        '非金融入力': {p.relative_to(ROOT).as_posix(): physical(p) for p in inputs}, '期間': {}}
    for period, features in (('旧73', old), ('追加7', added)):
        directions = build_directions(features, policies)
        if period == '旧73':
            with np.load(ROOT/'work/174参加と両中央値の再探索/短表の純出生173.npz', allow_pickle=False) as sealed:
                assert all(np.array_equal(value, sealed[key]) for key, value in directions.items())
        base, _, _ = B.P.baseline(SimpleNamespace(features=features))
        arrays = {}
        counts = []
        for policy in policies:
            birth, mw, fw, hi, component, conflict = compose(features.q0_timeband, policy['options'], directions,
                base['technical'], base['tier'], HORIZONS, policy.get('fallback_by_band', policy.get('fallback', False)))
            birth = stage.delay_day_fallback(birth, features.q0_timeband,
                np.asarray([q['session_index'] for q in features.q0_meta]),
                [(q['q0_time'], q['q0_index'], q['q0_line']) for q in features.q0_meta],
                np.asarray([s['start'] for s in features.scenes]), policy.get('day_fallback_after_minutes', 45))
            prefix = policy['id'] + '__'
            arrays.update({prefix+key: value for key, value in birth.items()})
            arrays.update({prefix+key: value for key, value in (('mw', mw), ('fw', fw), ('hi', hi), ('component', component), ('conflict', conflict))})
            counts.append({'id': policy['id'], '主成立q0': int(np.count_nonzero(birth['core'])),
                '補完成立q0': int(np.count_nonzero(birth['technical'])), '競合q0': int(conflict.sum()),
                'デイ補完開始分': policy.get('day_fallback_after_minutes', 45)})
        arrays['phases'] = features.q0_timeband
        target = HERE/(period+'の純出生174.npz')
        assert not target.exists()
        np.savez_compressed(target, **arrays)
        proof['期間'][period] = {'場順': [s['session'] for s in features.scenes], 'q0数': len(features.q0_meta),
            '出生': physical(target), '主技術のbirth_key数': len(directions), '診断': counts,
            '旧短表全方向一致': period == '旧73'}
    assert all(physical(ROOT/name) == value for name, value in before.items())
    save(HERE/'金融前の出生固定.json', proof)
    return proof


def ledger(context: object, value: tuple) -> dict:
    """
    機能: 固定取得を未知Noneと実セッションID文字列の並列台帳へ写す。
    引数: context(GenericContext)、value(tuple)はglobal1再生結果。
    返り値: dictはnet/known/label/scene。phases/originsは取得packの同順配列を共用する。
    """
    selected, _, wi, hi, _, _ = value
    key = (selected.cases, selected.sides, wi, hi)
    known = context.arrays['known'][key]
    return {'net': [float(n) if k else None for n, k in zip(context.arrays['net'][key], known, strict=True)],
        'known': known.tolist(), 'label': context.arrays['label'][key].tolist(),
        'scene': [context.sessions[int(si)] for si in context.case_scene[selected.cases]]}


def pack(context: object, value: tuple, policy: dict) -> dict:
    """
    機能: 172形式の全取得packへ固定政策・173金融・未知保持台帳を追加する。
    引数: context(GenericContext)、value(tuple)、policy(dict)は固定政策。
    返り値: dictはcase/実側/q0/帯/起源/幅位置/期限位置/階層/全engineとfinancial/ledger。
    """
    selected, origin, wi, hi, tier, engine = value
    return {'id': policy['id'], 'policy': policy, 'cases': selected.cases.tolist(),
        'sides': selected.sides.tolist(), 'events': selected.events.tolist(), 'phases': selected.phases.tolist(),
        'origins': origin.tolist(), 'widths': wi.tolist(), 'horizons': hi.tolist(), 'tiers': tier.tolist(),
        'engine': engine, 'financial': B.financial(context, value), 'ledger': ledger(context, value)}


def eligibility(context: object) -> tuple:
    """
    機能: 全対象Day/Nightを残す帯別ID一覧と時間を作る。
    引数: context(GenericContext)は旧73又は追加7。
    返り値: tuple[dict,dict]はDAY/PRE/POSTの対象場文字列一覧と全時間。
    """
    names = ('DAY', 'PRE', 'POST')
    eligible = {name: [context.sessions[i] for i in np.flatnonzero(context.hours[:, bi] > 0)] for bi, name in enumerate(names)}
    hours = {name: float(context.hours[:, bi].sum()) for bi, name in enumerate(names)}
    return eligible, hours


def run(expected_sha: str) -> None:
    """
    機能: 固定少数案の純出生を先に封印し、旧73同体・追加7・全80の両中央値を保存する。
    引数: expected_sha(str)はRoot固定選択票のSHA256。出力先はこのworkに限定し、固定174/173Sourceや旧結果を変更しない。
    返り値: None。圧縮JSON取得pack・全80統計・入力指紋・完了票を保存する。
    """
    assert not (HERE/'金融前の出生固定.json').exists()
    policies = fixed_policies(expected_sha)
    ids = [policy['id'] for policy in policies]
    stage = B.P.module(STAGE_SOURCE, 'stage174_same_fixed')
    before = {p.relative_to(ROOT).as_posix(): physical(p) for p in sources()}
    save(HERE/'出生前の固定.json', {'成功': True, 'UTC': datetime.now(timezone.utc).isoformat(),
        'Sourceと固定選択': before, '対象ID': ids, '固定選択SHA256': expected_sha, '追加7当該候補金融未読': True})
    proof = freeze_births(policies, before, stage)
    proof_ref = physical(HERE/'金融前の出生固定.json')
    expected = {r['id']: r for r in B.P.read(OLD_REPORT)['rows'] if r['id'] in ids}
    assert set(expected) == set(ids)
    decorator = stage
    contexts, reports, checks = {}, {}, []
    # ----------------------------------------
    # この位置より前では追加七場の金融表・金融結果を開かない。
    for new, period in ((False, '旧73'), (True, '追加7')):
        context = B.load_context(new)
        contexts[period] = context
        assert context.sessions == proof['期間'][period]['場順']
        birth_path = HERE/(period+'の純出生174.npz')
        assert physical(birth_path) == proof['期間'][period]['出生']
        rows = []
        with np.load(birth_path, allow_pickle=False) as sealed:
            assert np.array_equal(sealed['phases'], context.event_phases)
            for policy in policies:
                prefix = policy['id'] + '__'
                birth = {key: sealed[prefix+key] for key in ('core', 'branches', 'technical', 'tier')}
                mw, fw, hi = [sealed[prefix+key] for key in ('mw', 'fw', 'hi')]
                value = B.replay(context, birth, mw, fw, hi, policy.get('fallback', False))
                if not new:
                    assert expected[policy['id']]['policy'] == policy
                    si = context.case_scene[value[0].cases]
                    for name, eligible in (('全期', np.ones(len(context.scenes), bool)),
                            ('前48', np.arange(len(context.scenes)) < 48), ('後25', np.arange(len(context.scenes)) >= 48)):
                        selected = eligible[si]
                        actual = decorator.decorate(context, value, B.financial(context, value, selected, eligible), selected)
                        assert actual == expected[policy['id']]['periods'][name], (policy['id'], name)
                    assert max(a['peak_global_reserved'] for a in value[-1]['audits']) == expected[policy['id']]['global_reserved_max']
                    checks.append({'id': policy['id'], '旧73三期間全群の固定金融一致': True})
                rows.append(pack(context, value, policy))
        eligible, hours = eligibility(context)
        reports[period] = {'成功': True, '場数': len(context.scenes), '場順': context.sessions,
            '幅順': list(context.table.widths), '期限順': list(context.table.horizons), '対象場': eligible,
            '対象時間': hours, '出生固定': proof_ref, 'rows': rows,
            '位置づけ': '旧73既使用の固定再現' if not new else '追加7既使用の参考適用。新規独立未見ではない。'}
        save(HERE/(period+'の全取得174.json.gz'), reports[period])
    # ----------------------------------------
    # 平均や中央値を加算せず、実取得台帳と実セッションIDを連結して全80を再計算する。
    all_eligible = {name: reports['旧73']['対象場'][name]+reports['追加7']['対象場'][name] for name in ('DAY', 'PRE', 'POST')}
    all_hours = {name: reports['旧73']['対象時間'][name]+reports['追加7']['対象時間'][name] for name in ('DAY', 'PRE', 'POST')}
    all_rows = []
    for index, policy in enumerate(policies):
        old, added = reports['旧73']['rows'][index], reports['追加7']['rows'][index]
        assert old['id'] == added['id'] == policy['id']
        joined = {name: old['ledger'][name]+added['ledger'][name] for name in ('net', 'known', 'label', 'scene')}
        phases, origins = old['phases']+added['phases'], old['origins']+added['origins']
        financial = B.metrics173.evaluate_metrics(joined['net'], joined['known'], joined['label'],
            joined['scene'], phases, origins, all_eligible, all_hours)
        assert all(isinstance(scene, str) and scene for scene in joined['scene'])
        all_rows.append({'id': policy['id'], 'policy': policy, 'financial': financial,
            '旧73': old['financial'], '追加7': added['financial'], 'ledger': joined, 'phases': phases, 'origins': origins})
    save(HERE/'全80の両中央値174.json.gz', {'成功': True, '場数': 80, '対象場': all_eligible,
        '対象時間': all_hours, 'rows': all_rows, '注意': '全80既使用。未知None。全場中央値境界と完全場のみの既知中央値は別。固定候補を選び直さない。'})
    assert physical(HERE/'金融前の出生固定.json') == proof_ref
    assert all(physical(ROOT/name) == value for name, value in before.items())
    save(HERE/'完了.json', {'成功': True, '出生固定': proof_ref, 'Sourceと固定選択': before,
        '旧73同体確認': checks, '追加7': '既使用参考、未見ではない',
        'files': {path.name: physical(path) for path in HERE.iterdir() if path.is_file() and path.name != '完了.json'}})
    print(json.dumps({'成功': True, '対象ID': ids, '旧73同体': len(checks), '全80場': True,
        '取得数': {p: {r['id']: len(r['cases']) for r in report['rows']} for p, report in reports.items()}}, ensure_ascii=False))


def main() -> None:
    """
    機能: RootのGOと固定選択SHAが明示された時だけ参考適用を開始する。
    引数: --fixed-sha256(str)は固定票指紋、--execute(bool)はRootのGO後の明示指定。
    返り値: None。引数なしで自然計算を開始しない。
    """
    parser = argparse.ArgumentParser(description='174固定少数政策の追加七場参考適用')
    parser.add_argument('--fixed-sha256', required=True)
    parser.add_argument('--execute', action='store_true', required=True)
    args = parser.parse_args()
    run(args.fixed_sha256)


if __name__ == '__main__':
    main()
