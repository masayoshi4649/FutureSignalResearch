"""買売合計で保有・未決を一件までとする173の純数量再生部品。"""
import heapq
import math

import numpy as np


def replay(event_keys: list, event_scenes: np.ndarray, scene_starts: np.ndarray,
           scene_ends: np.ndarray, captures: list, core: np.ndarray, branches: np.ndarray,
           technical: np.ndarray, tiers: np.ndarray, momentum_width: np.ndarray,
           fade_width: np.ndarray, technical_width: int, exit_lookup: object,
           capacity: int = 1, after_seconds: int = 2700) -> dict:
    """
    機能: 当時までに到来した時計だけで、全側保有0・全側未決0の要求を一件受理する。
    引数: event_keys(list[tuple])は時刻/index/line、event_scenes(np.ndarray[N])は場位置、
          scene_starts/scene_ends(np.ndarray[S])は場時計、captures(list[dict])は
          status/finish_key、取得時はcase(int)/fill_keyを持つ非金融取得時計。
          任意のreason又はtermination_reason(str)があれば取消等の由来を監査へ集計する。
          core/branches/technical/tiers(np.ndarray[N])は事前固定出生、主二width(np.ndarray[N])は
          event別の非負整数幅、technical_width(int)は正の固定補完幅。
          exit_lookup(callable)は取得後だけ(event,case,side0買1売,width)から既知exit秒又はNoneを返す。
          event別期限はcallbackの閉包で選ぶ。金融値・先着ラベルを本部品へ渡さない。
          capacity(int)は必ず1。None・10等を拒否し、after_seconds(int)は初参加補完の開始秒。
    返り値: dictは取得records、全要求requests、場別audits。各要求mini一枚、買売合計一件。
            未知は場末保持、同秒exitは秒末解放。保有中は逆側も受けず、未来exitで先に枠を空けない。
    """
    n = len(event_keys)
    s = len(scene_starts)
    assert len(captures) == n and len(scene_ends) == s and np.shape(event_scenes) == (n,)
    for array in (core, branches, technical, tiers):
        assert np.shape(array) == (n,)
    assert np.isin(core, (-1, 0, 1)).all() and np.isin(technical, (-1, 0, 1)).all()
    assert np.array_equal(np.asarray(branches) == -1, np.asarray(core) == 0)
    assert np.isin(np.asarray(branches)[np.asarray(core) != 0], (0, 1)).all()
    assert np.isin(np.asarray(tiers)[np.asarray(technical) != 0], (1, 2)).all()
    assert type(capacity) is int and capacity == 1
    assert type(technical_width) is int and technical_width > 0
    assert type(after_seconds) is int and after_seconds >= 0
    momentum_width = np.asarray(momentum_width)
    fade_width = np.asarray(fade_width)
    assert momentum_width.shape == fade_width.shape == (n,)
    assert np.issubdtype(momentum_width.dtype, np.integer) and np.issubdtype(fade_width.dtype, np.integer)
    assert (momentum_width >= 0).all() and (fade_width >= 0).all()
    original_core = np.asarray(core).copy()
    chosen_width = np.where(np.asarray(branches) == 0, momentum_width, fade_width)
    core = np.where(chosen_width > 0, core, 0).astype(np.int8)
    branches = np.where(core != 0, branches, -1).astype(np.int8)
    assert np.isfinite(scene_starts).all() and np.isfinite(scene_ends).all()
    assert np.all(np.asarray(scene_ends) > np.asarray(scene_starts))
    previous = None
    for event, key in enumerate(event_keys):
        assert len(key) == 3 and all(math.isfinite(v) for v in key)
        scene = int(event_scenes[event])
        assert 0 <= scene < s and scene_starts[scene] <= key[0] < scene_ends[scene]
        current = (scene, *key)
        assert previous is None or current > previous
        previous = current
    records, requests, audits = [], [], []
    serial = 0
    # ----------------------------------------
    # 場ごとに状態を閉じる。未知保有・未決予約を次場へ引き継がない。
    for scene in range(s):
        events = np.flatnonzero(np.asarray(event_scenes) == scene)
        held = np.zeros(2, dtype=np.int64)
        pending_count = np.zeros(2, dtype=np.int64)
        pending, positions, seen_cases, queue = {}, {}, set(), []
        ever_acquired = False
        audit = {'scene_index': scene, 'events': len(events), 'accepted_core': 0, 'accepted_technical': 0,
            'core_signal_events': int(np.count_nonzero(original_core[events])),
            'effective_core_signal_events': int(np.count_nonzero(core[events])),
            'disabled_width_core_events': int(np.sum((original_core[events] != 0) & (core[events] == 0))),
            'technical_signal_events': int(np.count_nonzero(np.asarray(technical)[events])),
            'technical_before_start_events': 0, 'technical_after_start_events': 0,
            'technical_eligible_before_first_fill': 0, 'core_suppressed_technical_events': 0,
            'quantity_rejected_core': 0, 'quantity_rejected_technical': 0, 'quantity_rejected_by_side': [0, 0],
            'skipped_held_core': 0, 'skipped_held_technical': 0,
            'skipped_pending_core': 0, 'skipped_pending_technical': 0,
            'alias_fills_skipped': 0, 'alias_fills_skipped_core': 0, 'alias_fills_skipped_technical': 0,
            'cancelled': 0, 'cancelled_core': 0, 'cancelled_technical': 0,
            'filled': 0, 'filled_core': 0, 'filled_technical': 0, 'unknown_held_to_end': 0,
            'capture_status_core': {}, 'capture_status_technical': {},
            'capture_reason_core': {}, 'capture_reason_technical': {},
            'peak_held': [0, 0], 'peak_pending': [0, 0], 'peak_reserved_total': [0, 0],
            'peak_global_held': 0, 'peak_global_pending': 0, 'peak_global_reserved': 0,
            'technical_wait_core_pending': 0, 'technical_after_first_fill': 0,
            'pending_at_scene_end': [0, 0]}

        def observe() -> None:
            """
            機能: 買売合計の保有・未決が一件以下という不変式と側別最大を確認する。
            引数: なし。場内held/pending_countを参照する。
            返り値: None。
            """
            assert (held >= 0).all() and (pending_count >= 0).all()
            assert int(held.sum() + pending_count.sum()) <= 1
            for name, values in (('peak_held', held), ('peak_pending', pending_count),
                                 ('peak_reserved_total', held + pending_count)):
                audit[name] = np.maximum(audit[name], values).tolist()
            for name, value in (('peak_global_held', int(held.sum())),
                                ('peak_global_pending', int(pending_count.sum())),
                                ('peak_global_reserved', int(held.sum() + pending_count.sum()))):
                audit[name] = max(audit[name], value)

        def advance(now: tuple) -> None:
            """
            機能: 現在原行までに到来した取得・失効・決済だけを反映する。
            引数: now(tuple)は現在の時刻/index/line。場末はindex/line無限大。
            返り値: None。exitの原行不明は秒末に置き、未知は場末まで保持する。
            """
            nonlocal ever_acquired, serial
            while queue and queue[0][0] <= now:
                key, _, kind, token = heapq.heappop(queue)
                if kind == 'exit':
                    position = positions.pop(token)
                    held[position['side']] -= 1
                    observe()
                    continue
                request_row = pending.pop(token)
                side = request_row['side']
                role = 'core' if request_row['origin'] == 0 else 'technical'
                pending_count[side] -= 1
                if kind == 'cancel':
                    audit['cancelled'] += 1
                    audit['cancelled_' + role] += 1
                    observe()
                    continue
                assert kind == 'fill'
                case = request_row['case']
                if case in seen_cases:
                    audit['alias_fills_skipped'] += 1
                    audit['alias_fills_skipped_' + role] += 1
                    observe()
                    continue
                seen_cases.add(case)
                ever_acquired = True
                held[side] += 1
                audit['filled'] += 1
                audit['filled_' + role] += 1
                record = {name: request_row[name] for name in ('event', 'case', 'side', 'width', 'origin', 'tier')}
                records.append(record)
                positions[token] = record
                exit_time = exit_lookup(record['event'], case, side, record['width'])
                if exit_time is None:
                    exit_time = float(scene_ends[scene])
                    audit['unknown_held_to_end'] += 1
                else:
                    assert math.isfinite(exit_time) and key[0] <= exit_time <= scene_ends[scene]
                serial += 1
                heapq.heappush(queue, ((float(exit_time), math.inf, math.inf), serial, 'exit', token))
                observe()

        def request(event: int, side: int, width: int, origin: int, tier: int) -> None:
            """
            機能: 全側が空の要求だけ一枚受理し、保有中・未決中の棄却理由を分ける。
            引数: event/side/width/origin/tier(int)は要求出生・実側・幅・主0又は補完2・階層。
            返り値: None。同じq0で別側や補完へ代用せず、未決中も逆側を予約しない。
            """
            nonlocal serial
            held_total = int(held.sum())
            pending_total = int(pending_count.sum())
            reason = 'held' if held_total else 'pending' if pending_total else None
            row = {'event': int(event), 'scene_index': scene, 'side': side, 'width': width,
                'origin': origin, 'tier': tier, 'at': list(event_keys[event]),
                'held_before': int(held[side]), 'pending_before': int(pending_count[side]),
                'held_total_before': held_total, 'pending_total_before': pending_total,
                'accepted': reason is None, 'skip_reason': reason}
            requests.append(row)
            role = 'core' if origin == 0 else 'technical'
            if reason is not None:
                audit['quantity_rejected_' + role] += 1
                audit['quantity_rejected_by_side'][side] += 1
                audit['skipped_' + reason + '_' + role] += 1
                if origin == 2 and reason == 'pending' and any(r['origin'] == 0 for r in pending.values()):
                    audit['technical_wait_core_pending'] += 1
                return
            capture = captures[event]
            status = str(capture['status'])
            reason_text = capture.get('reason', capture.get('termination_reason'))
            reason_text = '未提供' if reason_text is None else str(reason_text)
            for name, value in (('capture_status_' + role, status), ('capture_reason_' + role, reason_text)):
                audit[name][value] = audit[name].get(value, 0) + 1
            key = tuple(capture['fill_key'] if capture['status'] == 'filled' else capture['finish_key'])
            assert event_keys[event] <= key and key[0] >= event_keys[event][0]
            token = len(requests) - 1
            pending[token] = {**row, 'case': int(capture['case']) if capture['status'] == 'filled' else -1}
            pending_count[side] += 1
            audit['accepted_' + role] += 1
            serial += 1
            heapq.heappush(queue, (key, serial, 'fill' if capture['status'] == 'filled' else 'cancel', token))
            observe()

        for event in events:
            event = int(event)
            now = tuple(event_keys[event])
            advance(now)
            if technical[event] != 0:
                if now[0] < scene_starts[scene] + after_seconds:
                    audit['technical_before_start_events'] += 1
                else:
                    audit['technical_after_start_events'] += 1
                    if core[event] != 0:
                        audit['core_suppressed_technical_events'] += 1
            if core[event] != 0:
                width = int(momentum_width[event] if branches[event] == 0 else fade_width[event])
                request(event, 0 if core[event] == 1 else 1, width, 0, 0)
                continue
            if now[0] < scene_starts[scene] + after_seconds or technical[event] == 0:
                continue
            if ever_acquired:
                audit['technical_after_first_fill'] += 1
                continue
            audit['technical_eligible_before_first_fill'] += 1
            request(event, 0 if technical[event] == 1 else 1, technical_width, 2, int(tiers[event]))
        advance((float(scene_ends[scene]), math.inf, math.inf))
        audit['pending_at_scene_end'] = pending_count.tolist()
        audit['held_at_scene_end'] = held.tolist()
        assert not positions and (held == 0).all()
        for role in ('core', 'technical'):
            assert audit['quantity_rejected_' + role] == audit['skipped_held_' + role] + audit['skipped_pending_' + role]
        audits.append(audit)
    records.sort(key=lambda r: (r['event'], r['origin']))
    assert len({r['case'] for r in records}) == len(records)
    return {'records': records, 'requests': requests, 'audits': audits, 'capacity': 1,
        'capacity_scope': '買売合計の保有と未決予約を合わせて一件', 'contracts_per_request': 1,
        'exit_clock': '同秒決済は秒末解放、未知は場末まで保持'}
