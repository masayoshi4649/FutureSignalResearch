"""173の買売合計一件制約と時計を自然入力なしの一覧oracleで検査する。"""
from pathlib import Path
import ast
import copy
import hashlib
import importlib.util
import json
import math

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
OLD = ROOT / 'work/172ナイト数量再生/engine172.py'
OLD_SHA = 'd1b1fab0daad8f74d8928ea985a311288e5417a4455bf7209783c263b17a91a7'


def sha(path: Path) -> str:
    """
    機能: 純部品と検査Sourceの物理指紋を計算する。
    引数: path(Path)はSourceパス。
    返り値: strはSHA256。
    """
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def module(path: Path, name: str) -> object:
    """
    機能: 価格・特徴・金融の読込器を経由せず純engineだけを読む。
    引数: path(Path)はSource、name(str)は登録名。
    返り値: objectは読み込んだモジュール。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def fixture(times: list, core: list, technical: list | None = None, end: float = 10000.) -> dict:
    """
    機能: 主・補完・取得時計だけを持つ人工入力を構成する。
    引数: times(list[float])はq0秒、core(list[int])は方向、technical(list[int]|None)は補完、end(float)は場末。
    返り値: dictはengine入力。自然特徴・価格・損益・先着ラベルを持たない。
    """
    n = len(times)
    technical = [0] * n if technical is None else technical
    data = {'event_keys': [(float(t), i * 10 + 1, i * 10 + 1) for i, t in enumerate(times)],
        'event_scenes': np.zeros(n, dtype=np.int64), 'scene_starts': np.array([0.]),
        'scene_ends': np.array([end]),
        'captures': [{'status': 'filled', 'case': i, 'fill_key': (float(t + 1), i * 10 + 2, i * 10 + 2),
            'finish_key': (float(t + 1), i * 10 + 2, i * 10 + 2)} for i, t in enumerate(times)],
        'core': np.asarray(core, dtype=np.int8),
        'branches': np.where(np.asarray(core) == 0, -1, np.arange(n) % 2).astype(np.int8),
        'technical': np.asarray(technical, dtype=np.int8),
        'tiers': np.where(np.asarray(technical) == 0, 0, 1 + np.arange(n) % 2).astype(np.int8),
        'momentum_width': np.full(n, 200, dtype=np.int64), 'fade_width': np.full(n, 400, dtype=np.int64),
        'technical_width': 200, 'after_seconds': 2700}

    def exit_clock(event: int, case: int, side: int, width: int) -> float:
        """
        機能: 人工取得から30秒後又は場末の早い方を返す。
        引数: event/case/side/width(int)は取得済み出生。
        返り値: floatは人工決済時計。
        """
        scene = int(data['event_scenes'][event])
        return min(float(data['scene_ends'][scene]), data['captures'][event]['fill_key'][0] + 30)

    data['exit_lookup'] = exit_clock
    return data


def oracle(data: dict) -> dict:
    """
    機能: 単一の保有/未決オブジェクトと時計一覧の最小探索で独立再生する。
    引数: data(dict)は人工engine入力。engineやheapを呼ばない。
    返り値: dictは全要求・取得・監査で、173の同じ意味の出力へ照合する。
    """
    records, requests, audits = [], [], []
    serial = 0
    for scene, end in enumerate(data['scene_ends']):
        events = np.flatnonzero(data['event_scenes'] == scene).tolist()
        position, waiting = None, None
        calendar, seen, ever = [], set(), False
        effective = {e: int(data['core'][e]) if (data['momentum_width'][e] if data['branches'][e] == 0
                     else data['fade_width'][e]) > 0 else 0 for e in events}
        audit = {'scene_index': scene, 'events': len(events), 'accepted_core': 0, 'accepted_technical': 0,
            'core_signal_events': sum(data['core'][e] != 0 for e in events),
            'effective_core_signal_events': sum(effective[e] != 0 for e in events),
            'disabled_width_core_events': sum(data['core'][e] != 0 and effective[e] == 0 for e in events),
            'technical_signal_events': sum(data['technical'][e] != 0 for e in events),
            'technical_before_start_events': 0, 'technical_after_start_events': 0,
            'technical_eligible_before_first_fill': 0, 'core_suppressed_technical_events': 0,
            'quantity_rejected_core': 0, 'quantity_rejected_technical': 0, 'quantity_rejected_by_side': [0, 0],
            'skipped_held_core': 0, 'skipped_held_technical': 0,
            'skipped_pending_core': 0, 'skipped_pending_technical': 0,
            'alias_fills_skipped': 0, 'alias_fills_skipped_core': 0, 'alias_fills_skipped_technical': 0,
            'cancelled': 0, 'cancelled_core': 0, 'cancelled_technical': 0,
            'filled': 0, 'filled_core': 0, 'filled_technical': 0, 'unknown_held_to_end': 0,
            'capture_status_core': {}, 'capture_status_technical': {},
            'capture_reason_core': {}, 'capture_reason_technical': {},
            'peak_held': [0, 0], 'peak_pending': [0, 0], 'peak_reserved_total': [0, 0],
            'peak_global_held': 0, 'peak_global_pending': 0, 'peak_global_reserved': 0,
            'technical_wait_core_pending': 0, 'technical_after_first_fill': 0,
            'pending_at_scene_end': [0, 0]}

        def observe() -> None:
            """
            機能: 単一状態から側別・全側の最大保有を作る。
            引数: なし。oracle内のposition/waitingを参照する。
            返り値: None。
            """
            held = [int(position is not None and position['side'] == s) for s in (0, 1)]
            pending = [int(waiting is not None and waiting['side'] == s) for s in (0, 1)]
            assert sum(held) + sum(pending) <= 1
            for name, values in (('peak_held', held), ('peak_pending', pending),
                                  ('peak_reserved_total', [held[s] + pending[s] for s in (0, 1)])):
                audit[name] = [max(a, b) for a, b in zip(audit[name], values)]
            audit['peak_global_held'] = max(audit['peak_global_held'], sum(held))
            audit['peak_global_pending'] = max(audit['peak_global_pending'], sum(pending))
            audit['peak_global_reserved'] = max(audit['peak_global_reserved'], sum(held) + sum(pending))

        for event in events + [None]:
            now = (float(end), math.inf, math.inf) if event is None else data['event_keys'][event]
            while calendar:
                earliest = min(range(len(calendar)), key=lambda i: calendar[i][:2])
                key, _, kind, row = calendar[earliest]
                if key > now:
                    break
                calendar.pop(earliest)
                role = 'core' if row['origin'] == 0 else 'technical'
                if kind == 'release':
                    assert position is row
                    position = None
                else:
                    assert waiting is row
                    waiting = None
                    if kind == 'cancel':
                        audit['cancelled'] += 1
                        audit['cancelled_' + role] += 1
                    elif row['case'] in seen:
                        audit['alias_fills_skipped'] += 1
                        audit['alias_fills_skipped_' + role] += 1
                    else:
                        seen.add(row['case'])
                        position = row
                        ever = True
                        audit['filled'] += 1
                        audit['filled_' + role] += 1
                        records.append({k: row[k] for k in ('event', 'case', 'side', 'width', 'origin', 'tier')})
                        release = data['exit_lookup'](row['event'], row['case'], row['side'], row['width'])
                        if release is None:
                            release = float(end)
                            audit['unknown_held_to_end'] += 1
                        serial += 1
                        calendar.append(((float(release), math.inf, math.inf), serial, 'release', row))
                observe()
            if event is None:
                break
            active_tech = data['technical'][event] != 0
            after = now[0] >= data['scene_starts'][scene] + data['after_seconds']
            if active_tech:
                audit['technical_after_start_events' if after else 'technical_before_start_events'] += 1
                if after and effective[event]:
                    audit['core_suppressed_technical_events'] += 1
            if effective[event]:
                side, origin, tier = (0 if effective[event] > 0 else 1), 0, 0
                width = int(data['momentum_width'][event] if data['branches'][event] == 0 else data['fade_width'][event])
            else:
                if not after or not active_tech:
                    continue
                if ever:
                    audit['technical_after_first_fill'] += 1
                    continue
                audit['technical_eligible_before_first_fill'] += 1
                side, origin, tier = (0 if data['technical'][event] > 0 else 1), 2, int(data['tiers'][event])
                width = data['technical_width']
            reason = 'held' if position is not None else 'pending' if waiting is not None else None
            row = {'event': event, 'scene_index': scene, 'side': side, 'width': width, 'origin': origin,
                'tier': tier, 'at': list(now), 'held_before': int(position is not None and position['side'] == side),
                'pending_before': int(waiting is not None and waiting['side'] == side),
                'held_total_before': int(position is not None), 'pending_total_before': int(waiting is not None),
                'accepted': reason is None, 'skip_reason': reason}
            requests.append(row)
            role = 'core' if origin == 0 else 'technical'
            if reason:
                audit['quantity_rejected_' + role] += 1
                audit['quantity_rejected_by_side'][side] += 1
                audit['skipped_' + reason + '_' + role] += 1
                if origin == 2 and reason == 'pending' and waiting['origin'] == 0:
                    audit['technical_wait_core_pending'] += 1
                continue
            capture = data['captures'][event]
            for name, value in (('capture_status_' + role, str(capture['status'])),
                    ('capture_reason_' + role, str(capture.get('reason', capture.get('termination_reason')))
                     if capture.get('reason', capture.get('termination_reason')) is not None else '未提供')):
                audit[name][value] = audit[name].get(value, 0) + 1
            kind = 'fill' if capture['status'] == 'filled' else 'cancel'
            waiting = {**row, 'case': int(capture['case']) if kind == 'fill' else -1}
            key = tuple(capture['fill_key'] if kind == 'fill' else capture['finish_key'])
            serial += 1
            calendar.append((key, serial, kind, waiting))
            audit['accepted_' + role] += 1
            observe()
        audit['pending_at_scene_end'] = [int(waiting is not None and waiting['side'] == s) for s in (0, 1)]
        audit['held_at_scene_end'] = [int(position is not None and position['side'] == s) for s in (0, 1)]
        assert position is None
        audits.append(audit)
    records.sort(key=lambda r: (r['event'], r['origin']))
    return {'records': records, 'requests': requests, 'audits': audits, 'capacity': 1,
        'capacity_scope': '買売合計の保有と未決予約を合わせて一件', 'contracts_per_request': 1,
        'exit_clock': '同秒決済は秒末解放、未知は場末まで保持'}


def compare(engine: object, data: dict) -> dict:
    """
    機能: 純engineと独立一覧oracleの全要求・取得・全監査を照合する。
    引数: engine(object)は173、data(dict)は人工入力。
    返り値: dictはengineの結果。相違時はAssertionError。
    """
    actual = engine.replay(**data)
    expected = oracle(data)
    assert actual == expected, (actual, expected)
    assert all(a['peak_global_reserved'] <= 1 for a in actual['audits'])
    assert all(not r['accepted'] or r['held_total_before'] == r['pending_total_before'] == 0
               for r in actual['requests'])
    return actual


def mirror_result(result: dict) -> dict:
    """
    機能: 結果の買売側だけを交換して鏡像の期待値を作る。
    引数: result(dict)は元方向の再生結果。
    返り値: dictは側と側別監査だけが鏡像となる独立コピー。
    """
    other = copy.deepcopy(result)
    for row in other['records'] + other['requests']:
        row['side'] = 1 - row['side']
    for audit in other['audits']:
        for name in ('quantity_rejected_by_side', 'peak_held', 'peak_pending',
                     'peak_reserved_total', 'pending_at_scene_end', 'held_at_scene_end'):
            audit[name] = audit[name][::-1]
    return other


def scenario_checks(engine: object, old: object) -> list[str]:
    """
    機能: 上限・逆側・未決・再取得・未知・同秒・補完・場リセットを明示例で検査する。
    引数: engine/old(object)は173と未改変172。
    返り値: list[str]は通過した人工シナリオ名。
    """
    passed = []
    data = fixture([10, 12, 13, 41, 42], [1, 1, -1, -1, -1])
    value = compare(engine, data)
    assert [r['event'] for r in value['records']] == [0, 4]
    assert [r['skip_reason'] for r in value['requests']] == [None, 'held', 'held', 'held', None]
    passed.extend(['買売合計一件上限', '同側追加と逆側両建て禁止', '同秒exit秒末まで禁止', '返済後の次q0で再取得'])
    # ----------------------------------------
    # 主未決取消後の技術補完と、補完未決中の主・補完の棄却を別記する。
    data = fixture([2700, 2701, 2702, 2710, 2711, 2712, 2720], [1, -1, 0, 0, 1, 0, 1], [0, 0, 1, -1, 0, 1, 0])
    data['captures'][0] = {'status': 'no_price', 'reason': '正常価格不足', 'finish_key': (2705., 9, 9)}
    data['captures'][3]['fill_key'] = data['captures'][3]['finish_key'] = (2715., 39, 39)
    value = compare(engine, data)
    assert [r['event'] for r in value['records']] == [3]
    audit = value['audits'][0]
    assert audit['skipped_pending_core'] == 2 and audit['skipped_pending_technical'] == 2
    assert audit['cancelled_core'] == 1 and audit['filled_technical'] == 1
    assert audit['capture_reason_core'] == {'正常価格不足': 1}
    assert audit['technical_wait_core_pending'] == 1
    passed.extend(['主と補完の未決棄却理由', '主pending取消後に初参加補完', '価格不足statusとreasonを保持'])
    # ----------------------------------------
    # 最初の取得はglobal1により失われず、補完の開始前・取得後は対象外のまま。
    for sample in (fixture([2600, 2700, 2701], [0, 0, 1], [1, -1, 0]),
                   fixture([2700, 2702, 2704], [1, -1, 0], [0, 0, 1])):
        actual = compare(engine, sample)
        previous = old.replay(**sample, capacity=10)
        assert actual['records'][:1] == previous['records'][:1]
        assert actual['records']
    data = fixture([2700, 2732, 2733], [0, 0, 0], [1, -1, 1])
    value = compare(engine, data)
    assert len(value['records']) == 1 and value['audits'][0]['technical_after_first_fill'] == 2
    passed.extend(['旧172と最初の取得一致', '技術補完45分開始を維持', '技術補完は初取得後に停止'])
    # ----------------------------------------
    # 同秒の別原行と取得aliasは異なる。aliasでは新建玉・callbackを作らない。
    data = fixture([10, 10, 11, 12, 13], [1, -1, -1, 1, 0])
    data['captures'][0]['fill_key'] = data['captures'][0]['finish_key'] = (10., 2, 2)
    data['captures'][2]['fill_key'] = data['captures'][2]['finish_key'] = (11., 22, 22)
    data['captures'][3]['case'] = 0
    calls = []

    def instant(event: int, case: int, side: int, width: int) -> float:
        """
        機能: 取得秒を決済秒としcallbackの実呼出を記録する。
        引数: event/case/side/width(int)は取得済み出生。
        返り値: floatは人工取得秒。
        """
        calls.append((event, case, side, width))
        return data['captures'][event]['fill_key'][0]

    data['exit_lookup'] = instant
    value = compare(engine, data)
    assert [r['event'] for r in value['records']] == [0, 2]
    assert value['audits'][0]['alias_fills_skipped'] == 1
    assert len(calls) == 4
    passed.extend(['同秒別原行の保有判定', '取得aliasは一建玉のみ'])
    # ----------------------------------------
    # 未知は場末まで保持し、次場で数量と初参加状態を初期化する。
    data = fixture([10, 20, 1010, 1020], [1, -1, 0, 1], [0, 0, -1, 0], end=100.)
    data['event_scenes'] = np.array([0, 0, 1, 1])
    data['scene_starts'] = np.array([0., 1000.])
    data['scene_ends'] = np.array([100., 1100.])
    data['after_seconds'] = 0

    def unknown(event: int, case: int, side: int, width: int) -> None:
        """
        機能: 決済時計未知を常に返す。
        引数: event/case/side/width(int)は人工取得。
        返り値: Noneは未知。
        """
        return None

    data['exit_lookup'] = unknown
    value = compare(engine, data)
    assert [r['event'] for r in value['records']] == [0, 2]
    assert all(a['unknown_held_to_end'] == 1 and a['held_at_scene_end'] == [0, 0] for a in value['audits'])
    passed.extend(['未知は場末までglobal枠保持', '場リセットで補完を再評価'])
    # ----------------------------------------
    # 無信号・開始前だけ・取消・場末未決という0参加理由を監査で見分ける。
    empty = compare(engine, fixture([10, 20], [0, 0]))['audits'][0]
    assert empty['core_signal_events'] == empty['technical_signal_events'] == empty['filled'] == 0
    before = compare(engine, fixture([10, 20], [0, 0], [1, 1]))['audits'][0]
    assert before['technical_before_start_events'] == 2 and before['accepted_technical'] == 0
    data = fixture([10, 20], [1, 0], [0, -1], end=100.)
    data['captures'][0] = {'status': 'unavailable', 'termination_reason': '観測不足', 'finish_key': (150., 8, 8)}
    data['after_seconds'] = 0
    audit = compare(engine, data)['audits'][0]
    assert audit['pending_at_scene_end'] == [1, 0] and audit['skipped_pending_technical'] == 1 and audit['filled'] == 0
    passed.append('0参加の無主信号・無技術信号・開始前・取消・未決・価格不足を監査で区別')
    data = fixture([10, 20], [1, -1], end=100.)
    data['captures'][0] = {'status': 'unavailable', 'reason': '場末まで取得時計なし', 'finish_key': (150., 8, 8)}
    actual = compare(engine, data)
    previous = old.replay(**data, capacity=10)
    assert not actual['records'] and [r['event'] for r in previous['records']] == [1]
    assert actual['audits'][0]['pending_at_scene_end'] == [1, 0]
    assert actual['audits'][0]['skipped_pending_core'] == 1
    passed.append('初要求が場末未決なら後続を止め0参加になり得ることを監査で説明')
    # ----------------------------------------
    # capacity引数から数量制約を解除できない。
    for bad in (None, 0, 2, 10, True, 1.0):
        try:
            engine.replay(**fixture([10], [1]), capacity=bad)
        except AssertionError:
            continue
        raise AssertionError('不正capacityを受理: ' + repr(bad))
    passed.append('capacityは整数1固定、Noneと10等は拒否')
    return passed


def random_checks(engine: object) -> dict:
    """
    機能: 可変幅・event期限・未知・取消・aliasを混在させ一覧・鏡像・prefixを確認する。
    引数: engine(object)は純173。
    返り値: dictは固定乱数種と検査規模。
    """
    rng = np.random.default_rng(20261115173)
    samples = 320
    rows = 0
    for sample in range(samples):
        n = 80
        times = [5 + (e // 2) * 7 if e < 40 else 1005 + ((e-40) // 2) * 7 for e in range(n)]
        data = fixture(times, rng.choice((-1, 0, 1), n).tolist(), rng.choice((-1, 0, 1), n).tolist())
        data['event_scenes'] = np.repeat([0, 1], n//2)
        data['scene_starts'] = np.array([0., 1000.])
        data['scene_ends'] = np.array([500., 1500.])
        data['after_seconds'] = int((0, 45, 90)[sample % 3])
        data['momentum_width'] = rng.choice((0, 150, 200, 400, 750), n)
        data['fade_width'] = rng.choice((0, 175, 250, 500, 1000), n)
        durations = rng.choice((-1, 0, 1, 7, 30, 60), n)
        for event, t in enumerate(times):
            key = (float(t + rng.integers(0, 40)), event * 10 + 2, event * 10 + 2)
            if rng.random() < .25:
                data['captures'][event] = {'status': 'no_price' if event % 2 else 'cancelled',
                    'reason': '正常価格不足' if event % 2 else '有効時間終了', 'finish_key': key}
            else:
                data['captures'][event] = {'status': 'filled', 'case': event//2*2,
                    'fill_key': key, 'finish_key': key}

        def variable_exit(event: int, case: int, side: int, width: int) -> float | None:
            """
            機能: 当該eventの事前時計と幅から決済秒又は未知を返す。
            引数: event/case/side/width(int)は人工取得。
            返り値: float|Noneは既知時計又は未知。方向には依存しない。
            """
            if durations[event] < 0:
                return None
            end = data['scene_ends'][data['event_scenes'][event]]
            return min(float(end), data['captures'][event]['fill_key'][0] + durations[event] + width/1000)

        data['exit_lookup'] = variable_exit
        actual = compare(engine, data)
        reflected = {**data, 'core': -data['core'], 'technical': -data['technical']}
        assert compare(engine, reflected) == mirror_result(actual)
        cut = sample % n
        future = {**data, 'core': data['core'].copy(), 'technical': data['technical'].copy(),
            'branches': data['branches'].copy(), 'momentum_width': data['momentum_width'].copy(),
            'fade_width': data['fade_width'].copy()}
        future['core'][cut:] = -future['core'][cut:]
        future['technical'][cut:] = -future['technical'][cut:]
        future['momentum_width'][cut:] = 0
        future['fade_width'][cut:] = 0
        changed = compare(engine, future)
        assert [r for r in actual['requests'] if r['event'] < cut] == [r for r in changed['requests'] if r['event'] < cut]
        assert [r for r in actual['records'] if r['event'] < cut] == [r for r in changed['records'] if r['event'] < cut]
        rows += n
    return {'乱数種': 20261115173, '人工母集団': samples, '母集団q0': rows,
        '通常鏡像prefixの再生本数': samples * 3, '各再生の全要求全取得全監査が一覧oracle一致': True}


def main() -> None:
    """
    機能: 自然入力を読まず人工検査を実施し、Source指紋と結果だけを保存する。
    引数: なし。純engine172/173とこの人工Sourceを読む。
    返り値: None。人工確認.jsonとSourceSHA256.jsonを保存する。
    """
    assert sha(OLD) == OLD_SHA
    target = HERE / 'engine173.py'
    tree = ast.parse(target.read_text(encoding='utf-8'))
    imported = [n.names[0].name for n in tree.body if isinstance(n, ast.Import)]
    assert imported == ['heapq', 'math', 'numpy']
    assert not any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ('open', 'eval', 'exec')
                   for n in ast.walk(tree))
    engine = module(target, 'engine173_artificial')
    old = module(OLD, 'engine172_unchanged173')
    scenarios = scenario_checks(engine, old)
    random = random_checks(engine)
    assert sha(OLD) == OLD_SHA
    sources = {p.relative_to(ROOT).as_posix(): sha(p) for p in (target, Path(__file__), OLD, HERE / 'README.md')}
    result = {'成功': True, '自然価格特徴金融未読': True, '旧172未改変': True,
        '明示シナリオ': scenarios, '乱数検査': random,
        '監査': '主/補完別の保有中・未決中棄却、無信号、開始前、初取得後停止、取消、価格理由、場末未決を区別。',
        'SourceSHA256': sources}
    (HERE / '人工確認.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (HERE / 'SourceSHA256.json').write_text(json.dumps(sources, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
