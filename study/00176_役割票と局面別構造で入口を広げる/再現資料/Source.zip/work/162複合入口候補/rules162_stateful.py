"""162の別版。判断q0までの履歴から技術状態の遷移を検出する。"""
from dataclasses import dataclass
from itertools import product
from collections import deque
import math

import numpy as np
from rules162 import PreparedEvaluator,term

VERSION='162候補辞書2_履歴'
GROUPS={
    'SB':('BBσの圧縮から再拡大',['BB','ATR','移動平均','MACD','RSI','実体','観測量']),
    'BR':('当時バンド基準の端から内への回復',['BB','MACD','RSI','実体','観測量']),
    'IR':('Impulse近似の長短許可と短期解除',['移動平均','MACD','価格構造','観測量']),
    'SP':('RSI持続と過大増分除外の順行',['移動平均','DMI/ADX','MACD','RSI','観測量']),
    'SF':('反対側RSI急変後の動力回復',['BB','MACD','RSI','実体','観測量']),
    'HP':('Hist再加速の持続と方向整合',['移動平均','DMI/ADX','MACD','RSI','観測量'])}


def candidate_catalog() -> list[dict]:
    """
    機能: 履歴技術六群の候補を自然結果なしで決定的に作る。
    引数: なし。
    返り値: list[dict]は別版の全規則。初版辞書を変更しない。
    """
    rules=[]
    def add(group: str,settings: dict,conditions: list[dict]) -> None:
        """
        機能: 対称な履歴規則をspread10/20の二候補として登録する。
        引数: group(str)、settings(dict)、conditions(list[dict])。
        返り値: None。閉包の候補配列へ追加する。
        """
        for spread in (10,20):
            rule_id=f'{group}{sum(r["group"]==group for r in rules)+1:04d}'
            rules.append({'id':rule_id,'group':group,'description':GROUPS[group][0],
                'technical_families':GROUPS[group][1],'settings':{**settings,'spread_max':spread},
                'conditions':[term('q0_spread_points','>',0),term('q0_spread_points','<=',spread),
                    term('abs_q0_close_gap','<=',1),*conditions]})
    # ----------------------------------------
    for window,expansion,compression,long_votes,volume in product((30,60),(1.1,1.25,1.5),(.7,.85),(2,3),(1,1.25)):
        add('SB',dict(window=window,expansion=expansion,compression=compression,long_min=long_votes,volume=volume),[
            term(f'h_bb_expand_edge_{window}_{expansion}','>',.5),
            term(f'h_bb_prior_contract_{window}','<=',compression),term('bb15_width_atr_ratio','<=',8),
            term('long_up_votes','>=',long_votes),term('m5_body_ratio_to_side','>',.2),
            term('m5_hist_delta_to_side','>',0),term('m5_rsi_delta_to_side','>',0),
            term('m1_volume_relative_prior3','>=',volume)])
    for level,body,volume,long_max in product((1.5,2,2.5),(.1,.3),(.5,1,1.5),(1,2)):
        add('BR',dict(outside_level=level,body_min=body,volume=volume,long_max=long_max),[
            term(f'h_bb_reentry_{level}','>',.5),term('long_up_votes','<=',long_max),
            term('m15_adx_delta','<=',0),term('m5_body_ratio_to_side','>=',body),
            term('m5_hist_delta_to_side','>',0),term('m5_rsi_delta_to_side','>',0),
            term('m1_volume_relative_prior3','>=',volume)])
    for slow,structure,volume,long_votes in product((15,30),('1分回復','5分実体'),(.5,1,1.25),(2,3)):
        conditions=[term(f'h_impulse_release_{slow}','>',.5),term('long_up_votes','>=',long_votes),
            term('q0_entry_minus_ema8_atr5_to_side','<=',1),term('m1_volume_relative_prior3','>=',volume)]
        conditions += ([term('live_reclaim','>',0),term('m1_body_ratio_to_side','>',0)] if structure=='1分回復'
            else [term('m5_body_ratio_to_side','>',0),term('q0_last_minus_m1_close_atr5_to_side','>=',0)])
        add('IR',dict(slow=slow,structure=structure,volume=volume,long_min=long_votes),conditions)
    for window,rsi,jump,volume,chase in product((10,20),(0,5,10),(8,12,16),(.5,1),(.5,1)):
        add('SP',dict(window=window,rsi_min=rsi,jump_max=jump,volume=volume,chase=chase),[
            term(f'h_rsi_min_{window}','>=',rsi),term(f'h_rsi_absdelta_max_{window}','<=',jump),
            term('long_up_votes','>=',3),term('m5_hist_to_side','>',0),term('m5_rsi_delta_to_side','>=',0),
            term('q0_entry_minus_ema8_atr5_to_side','<=',chase),term('m1_volume_relative_prior3','>=',volume)])
    for window,jump,sigma,current_delta,volume in product((10,20),(8,12),(-1,0),(2,4),(.75,1.25)):
        add('SF',dict(window=window,past_opposite_jump=jump,sigma_max=sigma,current_delta_max=current_delta,volume=volume),[
            term(f'h_rsi_delta_min_{window}','<=',-jump),term('m5_rsi_delta_to_side','>',0),
            term('m5_rsi_delta_to_side','<=',current_delta),term('bb15_position_sigma_to_side','<=',sigma),
            term('m5_hist_delta_to_side','>',0),term('m5_body_ratio_to_side','>',0),
            term('q0_last_minus_m1_close_atr5_to_side','>=',0),term('m1_volume_relative_prior3','>=',volume)])
    for window,jump,hist,long_votes,volume in product((10,20),(8,12),(.05,.1),(2,3),(.75,1.25)):
        add('HP',dict(window=window,jump_max=jump,hist_atr_min=hist,long_min=long_votes,volume=volume),[
            term(f'h_histdelta_min_{window}','>=',0),term(f'h_rsi_absdelta_max_{window}','<=',jump),
            term('m5_hist_atr_to_side','>=',hist),term('long_up_votes','>=',long_votes),
            term('m15_adx_delta','>=',0),term('m1_volume_relative_prior3','>=',volume)])
    assert len({r['id'] for r in rules})==len(rules)
    return rules


# ----------------------------------------
@dataclass
class StatefulEvaluator(PreparedEvaluator):
    q0_meta: list|None=None
    maximum_gap_seconds: float=180
    minimum_coverage_ratio: float=.8

    def __post_init__(self) -> None:
        """
        機能: 当時q0時計の場/限月/順序を検査し、因果的な履歴区切りを固定する。
        引数: self(StatefulEvaluator)は実側100X・幅・q0_metaと固定履歴仕様。
        返り値: None。取得時計や金融を受けない。
        """
        super().__post_init__()
        assert self.q0_meta is not None and len(self.q0_meta)==len(self.arrays[0])
        assert self.maximum_gap_seconds==180 and self.minimum_coverage_ratio==.8
        self._history_cache={};self._previous_cache={}
        previous=None;segments=[];begin=0
        for index,row in enumerate(self.q0_meta):
            current=(row['session'],row['contract'],row['q0_time'],row['q0_index'],row['q0_line'])
            assert isinstance(current[2],(int,float)) and math.isfinite(current[2])
            if previous is not None:
                same=current[:2]==previous[:2]
                if same:
                    assert current[2:]>=previous[2:] and current[3]>previous[3] and current[4]>previous[4]
                if not same or current[2]-previous[2]>self.maximum_gap_seconds:
                    segments.append((begin,index));begin=index
            previous=current
        if self.q0_meta:segments.append((begin,len(self.q0_meta)))
        self._segments=segments
        self._times=np.array([r['q0_time'] for r in self.q0_meta],dtype=np.float64)

    def previous(self,values: np.ndarray) -> np.ndarray:
        """
        機能: 同一有効区間の一つ前の当時値を返す。
        引数: values(np.ndarray)はq0順の値。
        返り値: np.ndarrayは先頭/場境界/長い欠測後をNaNとする前値。
        """
        result=np.full(len(values),np.nan)
        for start,end in self._segments:
            result[start+1:end]=values[start:end-1]
        return result

    def rolling(self,side_index: int,source: str,minutes: int,kind: str,include_current: bool) -> np.ndarray:
        """
        機能: 実時間窓の全既知値から最小/最大を計算し、過去不足を残す。
        引数: side_index(int)、source(str)、minutes(int)、kind(str)はmin/max/absmax、include_current(bool)。
        返り値: np.ndarrayは80%時間被覆・最低観測数を満たす因果窓、他NaN。
        """
        key=(side_index,source,minutes,kind,include_current)
        if key in self._history_cache:return self._history_cache[key]
        values,known=super().factor(side_index,source)
        result=np.full(len(values),np.nan);seconds=minutes*60
        minimum_observations=max(3,minutes//2)
        for start,end in self._segments:
            history=deque()
            for index in range(start,end):
                now=self._times[index]
                while history and self._times[history[0]]<now-seconds:history.popleft()
                if include_current:history.append(index)
                positions=list(history)
                # 同価格秒の複数原行は時間支持を水増ししない。
                if positions and len({self._times[i] for i in positions})>=minimum_observations:
                    covered=now-self._times[positions[0]]
                    if covered>=seconds*self.minimum_coverage_ratio and known[positions].all():
                        window=values[positions]
                        result[index]=(np.min(window) if kind=='min' else np.max(window) if kind=='max' else np.max(np.abs(window)))
                if not include_current:history.append(index)
        self._history_cache[key]=result
        return result

    def factor(self,side_index: int,name: str) -> tuple:
        """
        機能: 初版派生又は事前固定した履歴状態を当時までの情報で作る。
        引数: side_index(int)は実側、name(str)は派生名。
        返り値: tuple[np.ndarray,np.ndarray]は値・known mask。
        """
        if not name.startswith('h_'):return super().factor(side_index,name)
        key=(side_index,name)
        if key in self._factor_cache:return self._factor_cache[key]
        pieces=name.split('_');result=np.full(len(self.arrays[0]),np.nan)
        if name.startswith('h_bb_expand_edge_'):
            minutes=int(pieces[-2]);multiple=float(pieces[-1])
            current,_=super().factor(side_index,'bb15_sigma')
            low=self.rolling(side_index,'bb15_sigma',minutes,'min',False)
            ratio=np.divide(current,low,out=np.full_like(current,np.nan),where=low>0)
            before=self.previous(ratio)
            known=np.isfinite(ratio)&np.isfinite(before)
            result=np.where(known,((ratio>=multiple)&(before<multiple)).astype(float),np.nan)
        elif name.startswith('h_bb_prior_contract_'):
            minutes=int(pieces[-1])
            low=self.rolling(side_index,'bb15_sigma',minutes,'min',False)
            high=self.rolling(side_index,'bb15_sigma',minutes,'max',False)
            result=np.divide(low,high,out=np.full_like(low,np.nan),where=high>0)
        elif name.startswith('h_bb_reentry_'):
            level=float(pieces[-1]);current,_=super().factor(side_index,'bb15_position_sigma_to_side')
            before=self.previous(current);known=np.isfinite(current)&np.isfinite(before)
            result=np.where(known,((before<=-level)&(current>-level)&(current<=0)).astype(float),np.nan)
        elif name.startswith('h_impulse_release_'):
            slow=int(pieces[-1]);a,ka=super().factor(side_index,'m5_ema21_delta_to_side')
            b,kb=super().factor(side_index,'m5_hist_delta_to_side')
            c,kc=super().factor(side_index,f'm{slow}_ema21_delta_to_side')
            d,kd=super().factor(side_index,f'm{slow}_hist_delta_to_side')
            fast=np.where(ka&kb,np.where((a>0)&(b>0),1,np.where((a<0)&(b<0),-1,0)),np.nan)
            prior=self.previous(fast)
            slow_state=np.where(kc&kd,np.where((c>0)&(d>0),1,np.where((c<0)&(d<0),-1,0)),np.nan)
            known=np.isfinite(fast)&np.isfinite(prior)&np.isfinite(slow_state)
            result=np.where(known,((prior<0)&(fast>=0)&(slow_state>=0)).astype(float),np.nan)
        elif name.startswith('h_rsi_min_'):
            result=self.rolling(side_index,'m5_rsi_center_to_side',int(pieces[-1]),'min',True)
        elif name.startswith('h_rsi_absdelta_max_'):
            result=self.rolling(side_index,'m5_rsi_delta_to_side',int(pieces[-1]),'absmax',True)
        elif name.startswith('h_rsi_delta_min_'):
            result=self.rolling(side_index,'m5_rsi_delta_to_side',int(pieces[-1]),'min',False)
        elif name.startswith('h_histdelta_min_'):
            result=self.rolling(side_index,'m5_hist_delta_to_side',int(pieces[-1]),'min',True)
        else:raise KeyError('未知の履歴派生: '+name)
        known=np.isfinite(result);self._factor_cache[key]=(result,known)
        return result,known

    def iter_decisions(self,candidates: list|None=None):
        """
        機能: 別版履歴規則だけを初版と同じ結果形式で逐次評価する。
        引数: candidates(list[dict]又はNone)は履歴規則。
        返り値: generator[dict]は買売方向・競合・未知mask。
        """
        for candidate in candidate_catalog() if candidates is None else candidates:
            yield self.evaluate_one(candidate)


def manifest() -> dict:
    """
    機能: 別版履歴候補の規則と因果時計・表現限界を公開する。
    引数: なし。
    返り値: dictは版、全規則、時間窓と既知性の契約。
    """
    rules=candidate_catalog()
    return {'version':VERSION,'candidate_count':len(rules),
        'groups':{g:{'description':v[0],'technical_families':v[1],'count':sum(r['group']==g for r in rules)} for g,v in GROUPS.items()},
        'input':'当時実側100Xとq0だけのsession/contract/time/index/line。q1/金融/未来足を受けない。',
        'clock':'同じ場/限月のq0物理順。gap>180秒で履歴reset。窓は実分、80%時間被覆かつmax(3,分数//2)異なる価格秒が必要。窓内必要値は全known。',
        'prior':'BB圧縮/拡大基準と反対RSI急変の窓は現在を除外。RSI/Hist持続と過大増分除外は現在を含む。',
        'limitations':['BB復帰は各q0当時バンドへの位置クロス。固定した過去同一バンド価格を再取得した意味ではない。',
            'BB圧縮はsigmaの過去min/max比、拡大は現在sigma/過去minの上抜け。厳密なBB bandwidth/中心価格の比ではない。',
            'Impulseは既存EMA21とHist増分による近似派生で、原著EMA13の完全再現ではない。単独注文でなく別構造/量triggerと組み合わせる。',
            'RSI持続はq0時点の公表値の時間持続であり、異なる確定5分足本数へ勝手に換算しない。',
            '価格時計と原行順による研究。失われた実受信時計を復元するものではない。'],
        'rules':rules}
