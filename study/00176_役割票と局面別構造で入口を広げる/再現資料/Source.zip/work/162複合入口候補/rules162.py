"""162の新規複合テクニカル候補。自然価格・取得・金融を読まない。"""
from dataclasses import dataclass
from itertools import product
import json
import math

import numpy as np

VERSION='162候補辞書1'
FAMILIES={
    'TP':('多時間軸の押戻し順行',['移動平均','DMI/ADX','MACD','RSI','観測量']),
    'MX':('背景混在時の短期再加速',['移動平均','DMI/ADX','MACD','RSI','実体','観測量']),
    'TR':('旧方向失速から短期回復',['移動平均','DMI/ADX','MACD','RSI','価格構造','BB','観測量']),
    'EX':('バンド端の動力回復',['BB','MACD','RSI','ヒゲ','観測量']),
    'CP':('低BB幅からの推進近似',['BB','ATR','移動平均','MACD','RSI','実体','観測量']),
    'BO':('直近3分端突破と動力',['価格構造','MACD','RSI','実体','観測量']),
    'RG':('低ADX帯内の回復',['DMI/ADX','BB','MACD','RSI','実体','観測量']),
    'RM':('目標余地を確認した順行',['移動平均','DMI/ADX','BB','MACD','RSI']),
    'MP':('勢い持続と過熱上限',['DMI/ADX','MACD','RSI','観測量']),
    'SC':('異技法の確認票を合算',['移動平均','DMI/ADX','MACD','RSI','実体','観測量','BB','ATR'])}


def term(factor: str, operator: str, threshold: float) -> dict:
    """
    機能: 一つの有限比較条件を構成する。
    引数: factor(str)は列又は派生、operator(str)は比較演算子、threshold(float)は閾値。
    返り値: dictは副作用のない比較記述。
    """
    assert operator in ('>','>=','<','<=') and math.isfinite(threshold)
    return {'factor':factor,'operator':operator,'threshold':threshold}


def candidate_catalog() -> list[dict]:
    """
    機能: 結果を見ず固定した十技術群の有限候補辞書を作る。
    引数: なし。
    返り値: list[dict]はID・系統・技法・閾値・全比較条件を持つ候補。
    """
    rules=[]
    def add(group: str, settings: dict, conditions: list[dict]) -> None:
        """
        機能: 二つの正常気配上限を持つ対称規則を登録する。
        引数: group(str)、settings(dict)、conditions(list[dict])は技術群と設定。
        返り値: None。閉包rulesへ決定的順序で追加する。
        """
        for spread in (10,20):
            rule_id=f'{group}{sum(r["group"]==group for r in rules)+1:04d}'
            rules.append({'id':rule_id,'group':group,'description':FAMILIES[group][0],
                'technical_families':FAMILIES[group][1],
                'settings':{**settings,'spread_max':spread},
                'conditions':[term('q0_spread_points','>',0),term('q0_spread_points','<=',spread),
                    term('abs_q0_close_gap','<=',1),*conditions]})
    # ----------------------------------------
    for align,chase,momentum,volume,lower in product((2,3),(.25,.5,1),(2,3),(.5,1,1.25),(-.5,0)):
        add('TP',dict(align=align,chase=chase,momentum=momentum,volume=volume,distance_lower=lower),[
            term('ema_up_count','>=',align),term('di_up_count','>=',align),
            term('momentum_up_count','>=',momentum),term('m5_hist_delta_to_side','>',0),
            term('m5_rsi_delta_to_side','>',0),term('q0_entry_minus_ema8_atr5_to_side','>=',lower),
            term('q0_entry_minus_ema8_atr5_to_side','<=',chase),term('m1_volume_relative_prior3','>=',volume)])
    for body,volume,rsi,short in product((.1,.3,.5),(.5,1,1.5),(10,20),(2,3)):
        add('MX',dict(body_min=body,volume=volume,rsi_max=rsi,short_min=short),[
            term('background_up_votes','>=',2),term('background_up_votes','<=',4),
            term('short_up_votes','>=',short),term('m5_body_ratio_to_side','>=',body),
            term('m5_hist_delta_to_side','>',0),term('m5_rsi_delta_to_side','>',0),
            term('m5_rsi_center_to_side','<=',rsi),term('q0_entry_minus_ema8_atr5_to_side','>=',-.5),
            term('q0_entry_minus_ema8_atr5_to_side','<=',1),term('m1_volume_relative_prior3','>=',volume)])
    for sigma,adx,volume,structure in product((-.5,0,.5),(0,-.25),(.5,1,1.25),('1分回復','5分実体')):
        conditions=[term('long_up_votes','<=',1),term('m15_adx_delta','<=',adx),
            term('m5_di_difference_to_side','>',0),term('m5_hist_delta_to_side','>',0),
            term('m5_rsi_delta_to_side','>',0),term('bb15_position_sigma_to_side','<=',sigma),
            term('q0_entry_minus_ema8_atr5_to_side','<=',1),term('m1_volume_relative_prior3','>=',volume)]
        conditions += ([term('live_reclaim','>',0),term('m1_body_ratio_to_side','>',0)] if structure=='1分回復'
            else [term('m5_body_ratio_to_side','>',0),term('q0_last_minus_m1_close_atr5_to_side','>=',0)])
        add('TR',dict(sigma_max=sigma,adx_delta_max=adx,volume=volume,structure=structure),conditions)
    for sigma,wick,volume,rsi in product((-1,-1.5,-2),(.2,.4,.6),(.5,1,1.5),(-5,5)):
        add('EX',dict(sigma_max=sigma,wick_min=wick,volume=volume,rsi_max=rsi),[
            term('bb15_position_sigma_to_side','<=',sigma),term('m5_opposite_wick_ratio','>=',wick),
            term('m5_rsi_center_to_side','<=',rsi),term('m5_rsi_delta_to_side','>',0),
            term('m5_hist_delta_to_side','>',0),term('m5_body_ratio_to_side','>=',0),
            term('m1_volume_relative_prior3','>=',volume)])
    for width,body,volume,long_votes in product((4,6,8),(.2,.4,.6),(1,1.25,1.5),(2,3)):
        add('CP',dict(bb_width_max=width,body_min=body,volume=volume,long_min=long_votes),[
            term('bb15_width_atr_ratio','<=',width),term('bb15_position_sigma_to_side','>=',0),
            term('bb15_position_sigma_to_side','<=',1.5),term('long_up_votes','>=',long_votes),
            term('m5_body_ratio_to_side','>=',body),term('m5_hist_delta_to_side','>',0),
            term('m5_rsi_delta_to_side','>',0),term('m1_volume_relative_prior3','>=',volume)])
    for edge,body,volume,rsi in product((0,.1,.25),(.2,.4),(.75,1,1.5),(15,25)):
        add('BO',dict(edge_min=edge,body_min=body,volume=volume,rsi_max=rsi),[
            term('q0_last_minus_prior3_forward_edge_atr5_to_side','>',edge),
            term('m5_body_ratio_to_side','>=',body),term('m5_hist_delta_to_side','>',0),
            term('m5_rsi_delta_to_side','>',0),term('m5_rsi_center_to_side','<=',rsi),
            term('m1_volume_relative_prior3','>=',volume)])
    for adx,sigma,room,volume in product((15,20,25),(-.5,-1,-1.5),(.25,.5,1),(.5,1)):
        add('RG',dict(adx_max=adx,sigma_max=sigma,mean_room_target_min=room,volume=volume),[
            term('m15_adx','<=',adx),term('bb15_position_sigma_to_side','<=',sigma),
            term('bb_mean_room_target','>=',room),term('m5_body_ratio_to_side','>',0),
            term('m5_hist_delta_to_side','>',0),term('m5_rsi_delta_to_side','>',0),
            term('m1_volume_relative_prior3','>=',volume)])
    for room,long_votes,chase,rsi in product((.5,1,1.5),(2,3,4),(.5,1),(10,20)):
        add('RM',dict(forward_room_target_min=room,long_min=long_votes,chase=chase,rsi_max=rsi),[
            term('long_up_votes','>=',long_votes),term('bb_forward_room_target','>=',room),
            term('m5_hist_delta_to_side','>',0),term('m5_rsi_delta_to_side','>',0),
            term('m5_rsi_center_to_side','<=',rsi),term('q0_entry_minus_ema8_atr5_to_side','>=',0),
            term('q0_entry_minus_ema8_atr5_to_side','<=',chase)])
    for hist,rsi,delta,adx,volume in product((0,.1,.2),(0,5),(0,.5),(15,20,25),(.75,1)):
        add('MP',dict(hist_atr_min=hist,rsi_min=rsi,rsi_delta_min=delta,adx_min=adx,volume=volume),[
            term('m5_hist_atr_to_side','>=',hist),term('m15_hist_to_side','>',0),
            term('m5_hist_delta_to_side','>=',0),term('m5_rsi_center_to_side','>=',rsi),
            term('m5_rsi_center_to_side','<=',25),term('m5_rsi_delta_to_side','>',delta),
            term('m15_adx','>=',adx),term('m15_adx_delta','>=',0),
            term('m1_volume_relative_prior3','>=',volume)])
    for score,chase,rsi,room in product((6,7,8),(.5,1,1.5),(15,25),(0,.5)):
        add('SC',dict(score_min=score,chase=chase,rsi_max=rsi,room_target_min=room),[
            term('technical_score','>=',score),term('q0_entry_minus_ema8_atr5_to_side','<=',chase),
            term('m5_rsi_center_to_side','<=',rsi),term('bb_forward_room_target','>=',room)])
    assert len({r['id'] for r in rules})==len(rules)
    assert all(len(set(r['technical_families']))>=3 for r in rules)
    return rules


# ----------------------------------------
@dataclass
class PreparedEvaluator:
    buy_X: object
    sell_X: object
    columns: list
    target_points: float=125

    def __post_init__(self) -> None:
        """
        機能: 当時実側の二配列だけを検査し、派生・比較の再用cacheを準備する。
        引数: self(PreparedEvaluator)。target_points(float)は事前に選ぶ対称IFD幅。
        返り値: None。教師・取得・金融を参照しない。
        """
        self.names=[c['name'] if isinstance(c,dict) else c for c in self.columns]
        assert len(self.names)==len(set(self.names))==100
        assert isinstance(self.target_points,(int,float)) and not isinstance(self.target_points,bool)
        assert math.isfinite(self.target_points) and self.target_points>0
        self.arrays=(np.asarray(self.buy_X,dtype=np.float64),np.asarray(self.sell_X,dtype=np.float64))
        assert self.arrays[0].shape==self.arrays[1].shape and self.arrays[0].ndim==2 and self.arrays[0].shape[1]==100
        assert not any(np.isinf(x).any() for x in self.arrays)
        self.index={name:i for i,name in enumerate(self.names)}
        self._factor_cache={};self._comparison_cache={}

    def factor(self, side_index: int, name: str) -> tuple:
        """
        機能: 指定した列又は派生を有限known maskとともに作る。
        引数: side_index(int)は買0/売1、name(str)は派生名又は既存列名。
        返り値: tuple[np.ndarray,np.ndarray]は値と既知性。未知を0へ置換しない。
        """
        key=(side_index,name)
        if key in self._factor_cache:return self._factor_cache[key]
        x=self.arrays[side_index]
        def values(names: list[str]) -> tuple:
            """
            機能: 派生の必要列を同時抽出する。
            引数: names(list[str])は列名。
            返り値: tuple[np.ndarray,np.ndarray]は行列と全列有限mask。
            """
            matrix=x[:,[self.index[n] for n in names]]
            return matrix,np.isfinite(matrix).all(axis=1)
        if name in self.index:
            result=x[:,self.index[name]];known=np.isfinite(result)
        elif name=='abs_q0_close_gap':
            result,known=self.factor(side_index,'q0_last_minus_m1_close_atr5_to_side');result=np.abs(result)
        elif name in ('ema_up_count','di_up_count','background_up_votes','long_up_votes','short_up_votes','momentum_up_count'):
            groups={
                'ema_up_count':[f'm{m}_ema21_delta_to_side' for m in (5,15,30)],
                'di_up_count':[f'm{m}_di_difference_to_side' for m in (5,15,30)],
                'background_up_votes':[f'm{m}_{k}' for m in (5,15,30) for k in ('ema21_delta_to_side','di_difference_to_side')],
                'long_up_votes':[f'm{m}_{k}' for m in (15,30) for k in ('ema21_delta_to_side','di_difference_to_side')],
                'short_up_votes':['m5_ema21_delta_to_side','m5_gap_to_side','m5_di_difference_to_side'],
                'momentum_up_count':[f'm{m}_{k}' for m in (5,15) for k in ('hist_delta_to_side','rsi_delta_to_side')]}
            matrix,known=values(groups[name]);result=(matrix>0).sum(axis=1).astype(np.float64)
            result=np.where(known,result,np.nan)
        elif name=='live_reclaim':
            matrix,known=values(['m1_body_reclaim_atr5_to_side','q0_last_minus_m1_close_atr5_to_side']);result=matrix.sum(axis=1)
        elif name in ('bb_forward_room_target','bb_mean_room_target'):
            source='bb15_forward_room_125_ratio_to_side' if name=='bb_forward_room_target' else 'bb15_mean_room_125_ratio_to_side'
            original,known=self.factor(side_index,source);result=original*125/self.target_points
        elif name=='technical_score':
            requested=['m5_ema21_delta_to_side','m15_ema21_delta_to_side','m30_ema21_delta_to_side',
                'm5_di_difference_to_side','m15_di_difference_to_side','m30_di_difference_to_side',
                'm5_hist_delta_to_side','m15_hist_delta_to_side','m5_rsi_delta_to_side','m15_rsi_delta_to_side',
                'm5_body_ratio_to_side','m5_close_position_to_side','m1_volume_relative_prior3',
                'bb15_position_sigma_to_side','bb15_forward_room_125_ratio_to_side',
                'q0_entry_minus_ema8_atr5_to_side','m5_tr_atr_ratio']
            matrix,known=values(requested);a={n:matrix[:,j] for j,n in enumerate(requested)}
            votes=[(matrix[:,:3]>0).sum(axis=1)>=2,(matrix[:,3:6]>0).sum(axis=1)>=2,
                (a['m5_hist_delta_to_side']>0)&(a['m15_hist_delta_to_side']>0),
                (a['m5_rsi_delta_to_side']>0)&(a['m15_rsi_delta_to_side']>=0),
                (a['m5_body_ratio_to_side']>0)&(a['m5_close_position_to_side']>.5),
                a['m1_volume_relative_prior3']>=1,
                (np.abs(a['bb15_position_sigma_to_side'])<=1)&(a['bb15_forward_room_125_ratio_to_side']*125/self.target_points>=.5),
                (np.abs(a['q0_entry_minus_ema8_atr5_to_side'])<=1)&(a['m5_tr_atr_ratio']<=1.5)]
            result=np.sum(votes,axis=0).astype(np.float64);result=np.where(known,result,np.nan)
        else:raise KeyError('未定義の派生: '+name)
        self._factor_cache[key]=(result,known)
        return result,known

    def comparison(self, side_index: int, item: dict) -> tuple:
        """
        機能: 単一条件の真偽と既知性を再用可能に計算する。
        引数: side_index(int)、item(dict)は比較記述。
        返り値: tuple[np.ndarray,np.ndarray]は成立と既知mask。
        """
        key=(side_index,item['factor'],item['operator'],item['threshold'])
        if key not in self._comparison_cache:
            value,known=self.factor(side_index,item['factor']);threshold=item['threshold']
            operation={'>':np.greater,'>=':np.greater_equal,'<':np.less,'<=':np.less_equal}[item['operator']]
            self._comparison_cache[key]=(operation(value,threshold)&known,known)
        return self._comparison_cache[key]

    def evaluate_one(self, candidate: dict) -> dict:
        """
        機能: 一規則の実側成立を対称に評価し、両側成立を競合待機へする。
        引数: candidate(dict)は事前固定候補。
        返り値: dictはID・方向int8・競合・両側未知と成立mask。
        """
        flags=[];knowns=[]
        for side in (0,1):
            passed=np.ones(len(self.arrays[0]),dtype=bool);known=passed.copy()
            for item in candidate['conditions']:
                truth,available=self.comparison(side,item);passed &= truth;known &= available
            flags.append(passed);knowns.append(known)
        conflict=flags[0]&flags[1]
        directions=np.where(flags[0]&~flags[1],1,np.where(flags[1]&~flags[0],-1,0)).astype(np.int8)
        return {'candidate_id':candidate['id'],'directions':directions,'conflicts':conflict,
            'unknown_buy':~knowns[0],'unknown_sell':~knowns[1],
            'buy_pass':flags[0],'sell_pass':flags[1],'target_points':self.target_points}

    def iter_decisions(self, candidates: list|None=None):
        """
        機能: 大きな全候補×全q0行列を保存せず判定を逐次提供する。
        引数: candidates(list[dict]又はNone)は候補辞書、Noneなら固定全候補。
        返り値: generator[dict]はevaluate_oneの各判定。
        """
        for candidate in candidate_catalog() if candidates is None else candidates:
            yield self.evaluate_one(candidate)


def manifest() -> dict:
    """
    機能: 自然実行前の候補辞書と既知の表現限界を公開する。
    引数: なし。
    返り値: dictは版・候補数・技術群・全規則・時計と対称性の契約。
    """
    rules=candidate_catalog()
    return {'version':VERSION,'candidate_count':len(rules),
        'groups':{g:{'description':v[0],'technical_families':v[1],'count':sum(r['group']==g for r in rules)} for g,v in FAMILIES.items()},
        'input':'当時実側BUY/SELL100Xのみ。q1/教師/金融を引数へ取らない。',
        'width':'事前target_pointsを渡し、BB余地125比を価格ptへ戻して対象幅で割る。元125の観測ラベルは使わない。',
        'unknown':'必要列が一つでも未知ならその側は不成立、未知maskへ別記。0や前値へ代用しない。',
        'symmetry':'同じ規則を実BUY/SELLのside正規化Xに適用。両側成立は競合待機。',
        'limitations':['CPは一時点BB幅の低さと現在推進の組合せ。厳密な過去squeeze→拡大の検出ではない。',
            'TR/EX/RGは当時の動力と短期回復。厳密な失敗突破やバンド外→内の履歴patternを新生成しない。',
            '観測量は既存の累積差分に基づく当時指標であり、全攻撃側約定量ではない。',
            '同じepisodeの近接q0を独立した相場とみなさない。取得側の正準化・再武装は評価器の別責務。'],
        'rules':rules}
