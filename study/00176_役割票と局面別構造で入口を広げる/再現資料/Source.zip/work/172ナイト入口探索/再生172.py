"""171デイを同体固定し、q0帯別の新主入口だけを可変幅・期限で再生する。"""
from pathlib import Path
import sys
import importlib.util
import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'work/168数量枠の因果再生'))
import 再生する as R168
from 共通163 import read, save, sha
from 評価基盤 import Selection
sys.path.insert(0, str(ROOT / 'work/172ナイト数量再生'))
import engine172


def module(path: Path, name: str) -> object:
    """
    機能: 固定Sourceを明示名で読み込む。
    引数: path(Path)、name(str)。
    返り値: objectは読み込んだmodule。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    sys.modules[name] = result
    spec.loader.exec_module(result)
    return result


def baseline(context: object) -> tuple:
    """
    機能: 171固定デイと旧夜間対照を全場履歴から同じ式で復元する。
    引数: context(GenericContext)。
    返り値: tuple[dict,dict,dict]は出生・候補・171条件。
    """
    source = ROOT / 'work/171三帯の入口切替'
    sys.path.insert(0, str(source))
    runner = module(source / '固定候補を再生する.py', 'runner171_for172')
    setting = read(ROOT / 'study/00171_三時間帯で順行と回復失敗の確認を切り替える/条件.json')
    choice = read(source / '旧73探索/主案と前半A-Bの封印.json')['事前固定主案']['candidate']
    return runner.births(context.features, choice, setting), choice, setting


def route(context: object, base: dict, choice: dict, directions: dict) -> tuple:
    """
    機能: q0帯ごとに主入口を置換し、デイと初参加補完は変更しない。
    引数: context(GenericContext)、base(dict)、choice(dict)、directions(dict[str,np.ndarray])。
    返り値: tupleは出生、主順行幅、主反転幅、event別期限位置。
    """
    birth = {k: v.copy() if isinstance(v, np.ndarray) else v for k, v in base.items()}
    n = len(context.event_keys)
    mw, fw = np.full(n, 200, np.int16), np.full(n, 400, np.int16)
    hi = np.full(n, context.table.horizons.index('H60'), np.int8)
    for phase, name in ((1, 'PRE'), (2, 'POST')):
        option = choice.get(name)
        if option is None:
            continue
        assert isinstance(option['width'], int) and option['width'] > 0 and option['width'] in context.table.widths
        assert option['horizon'] in ('H30', 'H60', 'H120', 'SESSION') and option['horizon'] in context.table.horizons
        mask = context.event_phases == phase
        proposed = directions[option['key']]
        assert proposed.shape == (n,) and np.isin(proposed, (-1, 0, 1)).all()
        birth['core'][mask] = proposed[mask]
        birth['branches'][mask] = np.where(proposed[mask] != 0, 0, -1)
        mw[mask] = fw[mask] = option['width']
        hi[mask] = context.table.horizons.index(option['horizon'])
    assert np.array_equal(birth['core'][context.event_phases == 0], base['core'][context.event_phases == 0])
    assert np.array_equal(birth['branches'][context.event_phases == 0], base['branches'][context.event_phases == 0])
    assert (mw > 0).all() and (fw > 0).all(), '主幅0による補完への暗黙切替を許さない'
    return birth, mw, fw, hi


def replay(context: object, base: dict, choice: dict, directions: dict,
           captures: list | None = None) -> tuple:
    """
    機能: event別期限を取得時に固定し、予約込み買売各10枚で因果再生する。
    引数: context(GenericContext)、base/choice/directions(dict)、captures(list|None)。
    返り値: tupleはSelection、origin、幅位置、期限位置、tier、engine全結果。
    """
    birth, mw, fw, event_hi = route(context, base, choice, directions)
    width_map = {int(w): i for i, w in enumerate(context.table.widths)}
    fallback_hi = context.table.horizons.index('H60')

    def exit_lookup(event: int, case: int, side: int, width: int) -> float | None:
        """
        機能: 当該出生の主期限又は技術補完H60の決済時計だけを返す。
        引数: event/case/side/width(int)は取得済み建玉。
        返り値: floatは既知決済秒、Noneは未知。labelと金額は参照しない。
        """
        hi = int(event_hi[event]) if birth['core'][event] != 0 else fallback_hi
        wi = width_map[width]
        return float(context.arrays['exit_time'][case, side, wi, hi]) \
            if context.arrays['known'][case, side, wi, hi] else None

    result = engine172.replay(context.event_keys, context.event_scenes,
        np.array([s['start'] for s in context.scenes]), np.array([s['end'] for s in context.scenes]),
        R168.capture_descriptors(context) if captures is None else captures,
        birth['core'], birth['branches'], birth['technical'], birth['tier'], mw, fw, 200,
        exit_lookup, capacity=10)
    rows = result['records']
    events = np.array([r['event'] for r in rows], np.int32)
    selected = Selection(np.array([r['case'] for r in rows], np.int32),
        np.array([r['side'] for r in rows], np.int8), events, context.event_phases[events],
        np.zeros(len(rows), bool))
    origins = np.array([r['origin'] for r in rows], np.int8)
    wi = np.array([width_map[r['width']] for r in rows], np.int8)
    hi = np.where(origins == 2, fallback_hi, event_hi[events]).astype(np.int8)
    tiers = np.array([r['tier'] for r in rows], np.int8)
    return selected, origins, wi, hi, tiers, result


def statistics(context: object, value: tuple, mask: np.ndarray,
               eligible: np.ndarray, hours: float) -> dict:
    """
    機能: 異なる幅・期限の取得を、金融既知と不足を区別して集計する。
    引数: context(GenericContext)、value(tuple)、mask/eligible(np.ndarray)、hours(float)。
    返り値: dictはFANC・利益損失・頻度・支持場数。
    """
    selected, origins, wi, hi, tiers, _ = value
    cases, sides, ws, hs = selected.cases[mask], selected.sides[mask], wi[mask], hi[mask]
    key = (cases, sides, ws, hs)
    labels, known, money = [context.arrays[n][key] for n in ('label', 'known', 'net')]
    f, a, und, c = [int((labels == code).sum()) for code in (1, -1, 0, 2)]
    assert len(cases) == f + a + und + c and c == int((~known).sum())
    profit = int(np.maximum(money[known], 0).sum())
    loss = int(np.maximum(-money[known], 0).sum())
    counts = np.bincount(context.case_scene[cases], minlength=len(context.scenes))
    return {'count': len(cases), 'F': f, 'A': a, 'N': und, 'C': c,
        'rate': f / (f+a) if f+a else None, 'known': int(known.sum()), 'unknown': c,
        'profit': profit, 'loss': loss, 'net': profit-loss, 'pf': profit/loss if loss else None,
        'all_net': profit-loss if c == 0 else None,
        'wins': int((money[known] > 0).sum()), 'loss_trades': int((money[known] < 0).sum()),
        'scenes': int((counts > 0).sum()), 'eligible_scenes': int(eligible.sum()),
        'all_scenes': bool(eligible.any() and (counts[eligible] > 0).all()),
        'hours': hours, 'per_hour': len(cases)/hours if hours else None,
        'max_scene_share': int(counts.max())/len(cases) if len(cases) else None,
        'core_count': int((origins[mask] == 0).sum()),
        'technical_count': int((origins[mask] == 2).sum())}


def describe(context: object, value: tuple, details: bool = False) -> dict:
    """
    機能: 夜間帯・前後・主補完・買売の同一取得を分解する。
    引数: context(GenericContext)、value(tuple)、details(bool)は全場詳細の指定。
    返り値: dictは期間・q0帯別統計と数量監査。
    """
    selected, origins, wi, hi, tiers, engine = value
    scenes = context.case_scene[selected.cases]
    total = len(context.scenes)
    period_masks = {'全期': np.ones(total, bool)}
    if total == 73:
        period_masks.update({'前48場': np.arange(total) < 48, '後25場': np.arange(total) >= 48})
    groups = {'全部': np.ones(len(scenes), bool), '主': origins == 0, '補完': origins == 2}
    output = {'periods': {}}
    for period, pmask in period_masks.items():
        output['periods'][period] = {}
        for phase, name in ((None, '全帯'), (0, 'DAY'), (1, 'PRE'), (2, 'POST'), (-1, 'NIGHT')):
            eligible = pmask & (np.ones(total, bool) if phase is None else
                context.hours[:, 1:].sum(axis=1) > 0 if phase == -1 else context.hours[:, phase] > 0)
            hours = float(context.hours[eligible].sum()) if phase is None else \
                float(context.hours[eligible, 1:].sum()) if phase == -1 else float(context.hours[eligible, phase].sum())
            rows = pmask[scenes] & (np.ones(len(scenes), bool) if phase is None else
                selected.phases > 0 if phase == -1 else selected.phases == phase)
            output['periods'][period][name] = {g: statistics(context, value, rows & gm, eligible, hours)
                for g, gm in groups.items()}
    output['quantity'] = {'rejected_core': sum(a['quantity_rejected_core'] for a in engine['audits']),
        'rejected_technical': sum(a['quantity_rejected_technical'] for a in engine['audits']),
        'peak_reserved': np.max([a['peak_reserved_total'] for a in engine['audits']], axis=0).tolist()}
    if details:
        output['scenes'] = [{'session': context.sessions[si],
            **statistics(context, value, scenes == si, np.arange(total) == si, float(context.hours[si].sum())),
            'quantity': engine['audits'][si]} for si in range(total)]
        output['sides'] = {name: statistics(context, value, selected.sides == side,
            np.ones(total, bool), float(context.hours.sum())) for side, name in enumerate(('BUY', 'SELL'))}
    return output
