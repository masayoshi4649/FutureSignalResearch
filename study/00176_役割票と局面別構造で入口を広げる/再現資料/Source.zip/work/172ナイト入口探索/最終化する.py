"""文書修正だけをSource ZIPへ反映し、正式保存物とリンクを最終確認する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re
import urllib.parse
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00172_デイを固定しナイト米国前後の複合入口を探索する'


def ref(path: Path) -> dict:
    """
    機能: 正式保存対象のrepo相対名・サイズ・SHA256を取る。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: CP/窓/リンク等の文書生成器訂正を保存し、全正本・CSV・条件と再現を確認する。
    引数: なし。
    返り値: None。最終完了確認JSONを保存する。取引条件・出生・金融は変更しない。
    """
    index_path = TRIAL / '再現資料/保存索引.json'
    index = json.loads(index_path.read_bytes())
    source = ROOT / index['Source']['archive']['path']
    before = ref(source)
    assert before == index['Source']['archive']
    members = {}
    with zipfile.ZipFile(source) as archive:
        assert archive.testzip() is None
        for entry in index['Source']['members']:
            body = archive.read(entry['path'])
            assert len(body) == entry['bytes'] and hashlib.sha256(body).hexdigest() == entry['sha256']
            members[entry['path']] = body
    name = 'work/172ナイト入口探索/正式保存する.py'
    changed = [path for path, body in members.items() if (ROOT / path).read_bytes() != body]
    assert changed == [name], changed
    members[name] = (ROOT / name).read_bytes()
    members[Path(__file__).relative_to(ROOT).as_posix()] = Path(__file__).read_bytes()
    with zipfile.ZipFile(source, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for path, body in sorted(members.items()):
            archive.writestr(path, body)
    index['Source'] = {'archive': ref(source), 'members': [ref(ROOT / p) for p in sorted(members)]}
    index['保存準備後の文書補正'] = {'旧SourceZIP': before, '変更Source': changed,
        '内容': '文書生成器のCP閾値・NEW窓・候補辞書所在・草稿時制・リンクだけ。売買実装、条件F0、出生、金融、CSV、比較正本ZIPは不変。',
        '最終確認Source追加': Path(__file__).relative_to(ROOT).as_posix()}
    # ----------------------------------------
    verified = []
    for key in ('Source', '正本'):
        item = index[key]
        path = ROOT / item['archive']['path']
        assert ref(path) == item['archive']
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            assert set(archive.namelist()) == {r['path'] for r in item['members']}
            for entry in item['members']:
                body = archive.read(entry['path'])
                assert len(body) == entry['bytes'] and hashlib.sha256(body).hexdigest() == entry['sha256']
        verified.append({'種別': key, 'member数': len(item['members']), '全CRC_SHA一致': True})
    for entry in index['CSV']:
        assert ref(ROOT / entry['path']) == entry
    assert len(index['CSV']) == 4
    assert ref(ROOT / 'study/00171_三時間帯で順行と回復失敗の確認を切り替える/条件.json')['sha256'] == \
        'c310ea07df25078b2b811fc5422849c07277eef88fcd0a0693d581a6fa9dc766'
    for filename in ('正式入力の固定再現.json', '隔離復元の固定再現.json', 'CSV独立検算.json',
                     '旧73独立検算.json', '追加7独立検算.json', '全80保有支持の独立検査.json'):
        evidence = json.loads((TRIAL / '検査' / filename).read_bytes())
        assert evidence.get('成功', evidence.get('success')) is True, filename
    # ----------------------------------------
    docs = [*TRIAL.glob('*.md'), ROOT / 'docs/議論/デイを固定しナイト米国前後の入口を探す.md']
    links = []
    for path in docs:
        text = path.read_text(encoding='utf-8')
        assert '\ufffd' not in text and '\x00' not in text
        for href in re.findall(r'\]\(([^)]+)\)', text):
            if re.match(r'^(https?|mailto):', href):
                continue
            target = urllib.parse.unquote(href.split('#', 1)[0]).strip('<>')
            if not target:
                continue
            resolved = (path.parent / target).resolve()
            assert resolved.exists(), (str(path), href)
            links.append({'from': path.relative_to(ROOT).as_posix(), 'to': href})
    index_path.write_text(json.dumps(index, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    result = {'成功': True, '完了UTC': datetime.now(timezone.utc).isoformat(),
        '条件': ref(TRIAL / '条件.json'), '保存索引': ref(index_path), '全保存確認': verified,
        '文書': [ref(p) for p in docs], 'localリンク数': len(links), '全localリンク成立': True,
        'CSV': index['CSV'], 'Day171条件不変': True,
        '正式_隔離_固定六政策再現': '両方成功、Sourceと正本だけを展開した隔離Rootでも全報告/要求/取得同体。',
        '採否': '有望な夜間の後選対照B05_11を得て一旦停止。事前主B05_01を交換しない。',
        '限界': '全80既使用、主119/補完31・0.290回/時・未知8、PRE追加4Night主0。主POST100%単場集中を残す。',
        'Source': ref(Path(__file__))}
    target = TRIAL / '検査/最終完了確認.json'
    assert not target.exists()
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '最終票': ref(target), 'Sourceと正本': verified,
        'localリンク数': len(links), '正式ZIP合計bytes': sum(index[k]['archive']['bytes'] for k in ('Source', '正本'))}, ensure_ascii=False))


if __name__ == '__main__':
    main()
