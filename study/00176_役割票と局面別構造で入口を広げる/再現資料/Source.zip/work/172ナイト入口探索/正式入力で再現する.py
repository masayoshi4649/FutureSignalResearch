"""作業特徴cacheを使わず、正式共有入力から固定六政策を再現する。"""
from pathlib import Path
from io import BytesIO
import argparse
import json
import gzip
import zipfile
import numpy as np
import 再生172 as R
from 固定案を参考適用する import pack

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / 'study/00172_デイを固定しナイト米国前後の複合入口を探索する'


def main() -> None:
    """
    機能: 正式148射影・共有163/167を直接使い、出生・全engine・全金融報告を照合する。
    引数: --output(Path)は未作成のwork内確認先。
    返り値: None。候補探索・未見検証ではなく固定結果の再現確認を保存する。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, default=ROOT / 'work/172正式入力の固定再現')
    args = parser.parse_args()
    output = args.output.resolve()
    assert output.is_relative_to(ROOT / 'work') and not output.exists()
    reference = TRIAL / '再現資料/出生と比較正本.zip'
    builder = R.module(ROOT / 'work/172ナイト入口探索/選定政策の出生.py', 'formal172_builder')
    with zipfile.ZipFile(reference) as archive:
        def get(name: str) -> object:
            """
            機能: 正式ZIPのJSONを元byteから読み出す。
            引数: name(str)はwork相対member。
            返り値: objectは復元JSON。
            """
            body = archive.read(name)
            return json.loads(gzip.decompress(body) if name.endswith('.gz') else body)

        fixed = get('work/172ナイト入口探索/適用五組の固定.json')
        choices = [{'id': 'BASE171', 'PRE': None, 'POST': None}, *fixed['candidates']]
        options = list({r[band]['key']: r[band] for r in choices for band in ('PRE', 'POST') if r[band] is not None}.values())
        shared = json.loads((TRIAL / '検査/共用入力の指紋.json').read_text(encoding='utf-8'))
        data = R.R168.BASE.birth165.data_module() if hasattr(R.R168.BASE.birth165, 'data_module') else None
        if data is None:
            from 共通163 import data_module
            data = data_module()
        features = data.load_feature_from_formal()
        old_captures = R.read(ROOT / 'inputs/00148_全1分入口母集団/取得対応.json.gz')['rows']
        adapter = R.module(ROOT / 'work/163任意幅の数値化/arrays163.py', 'formal172_arrays')
        old_dir = ROOT / 'inputs/00163_任意幅の共用価格索引/数値表'
        old_table = adapter.load_table(old_dir, shared['旧73数値表'])
        old_context = R.R168.BASE.GenericContext(features, old_table, old_captures)
        new_root = ROOT / 'inputs/00167_追加七場の入口と共用価格索引'
        new_features, new_captures, _ = R.R168.BASE.load_features(new_root / '入口母集団')
        new_table = adapter.load_table(new_root / '自然数値表', shared['追加7数値表'])
        new_context = R.R168.BASE.GenericContext(new_features, new_table, new_captures)
        checks = []
        for label, context in [('旧73', old_context), ('追加7', new_context)]:
            directions = builder.build(context.features, options)
            born, _, _ = R.baseline(context)
            if label == '旧73':
                source = np.load(BytesIO(archive.read('work/172ナイト入口探索/短表の純出生.npz')), allow_pickle=False)
            else:
                source = np.load(BytesIO(archive.read('work/172ナイト入口探索/追加7の固定純出生.npz')), allow_pickle=False)
            with source:
                for key, direction in directions.items():
                    assert np.array_equal(direction, source[key]), (label, key)
                if label == '追加7':
                    for key, array in born.items():
                        if isinstance(array, np.ndarray):
                            assert np.array_equal(array, source['BASE__'+key], equal_nan=True), key
            expected_report = {r['id']: r for r in get(f'work/172ナイト入口探索/{label}の固定比較.json.gz')['rows']}
            expected_refs = {r['id']: r for r in get(f'work/172ナイト入口探索/{label}の全取得.json.gz')['rows']}
            for choice in choices:
                value = R.replay(context, born, choice, directions)
                assert R.describe(context, value, details=True) == expected_report[choice['id']]['cap10']
                assert {'id': choice['id'], **pack(context, value)} == expected_refs[choice['id']]
                checks.append({'期間': label, 'id': choice['id'], '取得': len(value[0].cases),
                    '全engine全取得全報告同体': True})
    output.mkdir(parents=True)
    result = {'成功': True, '正式正本SHA256': R.sha(reference), '確認': checks,
        '旧73特徴': '正式148の共有gzipから151/161の固定式で射影。feature cacheは読まない。',
        '金融': '恒久共有163/167のみ。原板・作業数値表・旧162教師cacheは読まない。',
        '注意': '固定六政策の再現。855552帯別設定の再探索又は新規未見性能ではない。'}
    R.save(output / '再現確認.json', result)
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
