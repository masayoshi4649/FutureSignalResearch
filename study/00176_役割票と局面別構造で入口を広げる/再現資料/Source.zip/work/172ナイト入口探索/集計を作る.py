"""固定五組と171対照を全80・前後・各帯・全場へ整理しCSV用の型付き表を作る。"""
from pathlib import Path
import json
import 再生172 as R

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
ROLES = {'BASE171': '171固定対照', 'B05_01': '全期発見の事前主', 'B05_02': '主近傍',
         'B05_03': '主近傍', 'B06_18': '前48順位・上流全期候補含む', 'B05_11': '旧73を見た後選の安定性対照'}
ADDITIVE = ('count', 'F', 'A', 'N', 'C', 'known', 'unknown', 'profit', 'loss', 'net',
            'wins', 'loss_trades', 'scenes', 'eligible_scenes', 'hours', 'core_count', 'technical_count')


def combine(left: dict, right: dict) -> dict:
    """
    機能: 重ならない旧73と追加7の加法指標を合算し、率を再計算する。
    引数: left/right(dict)は同帯・同主補完帰属の統計。
    返り値: dictは全80の既知部分、未知を残した統計。
    """
    value = {k: left[k] + right[k] for k in ADDITIVE}
    n, f, a, c = (value[k] for k in ('count', 'F', 'A', 'C'))
    value.update({'rate': f/(f+a) if f+a else None,
        'pf': value['profit']/value['loss'] if value['loss'] else None,
        'all_net': value['net'] if c == 0 else None,
        'all_scenes': left['all_scenes'] and right['all_scenes'],
        'per_hour': n/value['hours'] if value['hours'] else None,
        'max_scene_share': max((left['max_scene_share'] or 0)*left['count'],
                              (right['max_scene_share'] or 0)*right['count'])/n if n else None})
    return value


def stats_row(identity: str, period: str, band: str, group: str, value: dict) -> list:
    """
    機能: 各表共通の金融値を欠測・未到達を保った一行へ写す。
    引数: identity/period/band/group(str)、value(dict)。
    返り値: listは比較列順の型付き値。
    """
    count, known = value['count'], value['known']
    return [identity, ROLES[identity], period, band, group, count, value['F'], value['A'], value['N'], value['C'],
        value['rate'], value['profit'], value['loss'], value['net'], value['pf'], value['wins'],
        value['loss_trades'], value['wins']/known if known else None, value['core_count'], value['technical_count'],
        value['scenes'], value['eligible_scenes'], value['per_hour'],
        60/value['per_hour'] if value['per_hour'] else None, value['all_net']]


def main() -> None:
    """
    機能: 正本の全80加法と閲覧四表のJSON入力を保存する。
    引数: なし。固定比較と追加7結果を読み、CSV自体はartifact-toolへ渡す。
    返り値: None。全80の比較JSONと型付き閲覧入力を生成する。
    """
    old_path, new_path = HERE / '旧73の固定比較.json.gz', HERE / '追加7の固定比較.json.gz'
    old, new = R.read(old_path), R.read(new_path)
    fixed = R.read(HERE / '適用五組の固定.json')
    new_map = {r['id']: r for r in new['rows']}
    reports = []
    for row in old['rows']:
        identity = row['id']
        extra = new_map[identity]
        combined = {band: {group: combine(value, extra['cap10']['periods']['全期'][band][group])
            for group, value in groups.items()} for band, groups in row['cap10']['periods']['全期'].items()}
        reports.append({'id': identity, 'role': ROLES[identity], 'candidate': row['candidate'],
            'periods': {'旧73既使用': row['cap10']['periods']['全期'],
                '旧前48既使用': row['cap10']['periods']['前48場'],
                '旧後25既使用': row['cap10']['periods']['後25場'],
                '追加7既使用参考': extra['cap10']['periods']['全期'], '全80既使用加法': combined},
            'scenes': row['cap10']['scenes'] + extra['cap10']['scenes']})
    R.save(HERE / '全80の固定比較.json', {'成功': True, '主案': fixed['主案'],
        '事後安定性対照': fixed['事後安定性追加'], 'rows': reports})
    # ----------------------------------------
    headers = ['候補ID', '役割', '期間', 'q0帯', '入口帰属', '取得数', '順先着F', '逆先着A', '未到達N', '不足C',
        '到達済み先着率', '既知利益円', '既知損失円', '既知差引円', 'PF', '利益決済数', '損失決済数',
        '既知決済勝率', '主取得数', '補完取得数', '取得参加場数', '全対象場数', '平均取得回毎時',
        '平均取得間隔分', '全件収支円_不足あり空欄']
    summary, bands, scene_rows = [], [], []
    for row in reports:
        identity = row['id']
        for period, values in row['periods'].items():
            for scope in ('NIGHT', '全帯'):
                summary.append(stats_row(identity, period, scope, '全部', values[scope]['全部']))
            for band in ('DAY', 'PRE', 'POST', 'NIGHT'):
                for group in ('全部', '主', '補完'):
                    bands.append(stats_row(identity, period, band, group, values[band][group]))
        cumulative = unknown = 0
        for i, scene in enumerate(row['scenes']):
            cumulative += scene['net']
            unknown += scene['C']
            scene_rows.append([identity, ROLES[identity], scene['session'], '旧73既使用' if i < 73 else '追加7既使用参考',
                scene['count'], scene['F'], scene['A'], scene['N'], scene['C'], scene['rate'],
                scene['profit'], scene['loss'], scene['net'], cumulative, unknown,
                cumulative if unknown == 0 else None, scene['core_count'], scene['technical_count'],
                scene['wins'], scene['loss_trades'], scene['pf'], scene['hours'], scene['per_hour'],
                scene['quantity']['quantity_rejected_core'], scene['quantity']['peak_reserved_total'][0],
                scene['quantity']['peak_reserved_total'][1]])
    # ----------------------------------------
    condition = [['対象', 'NK225ラージの実BBOをmini取得・返済代用へ適用', '全80既使用。mini実板約定ではない。'],
        ['数量', '要求mini1枚、買い/売り各上限10枚', 'pendingも枠を予約、未知は場末まで保持。'],
        ['費用', '1pt100円、片道税込38.5円、追加片道5pt', '往復77円+1000円、実spreadも含む。'],
        ['時計', '既存全1分q0→別原行q1取得', '指標足幅と判断時計は別。NY09:30夏冬自動。'],
        ['主率', 'F/(F+A)', '未到達Nと観測不足Cを分け、決済勝率と混同しない。'],
        ['全件収支', 'C>0は空欄', '既知差引を全件確定の利益としない。'],
        ['Day固定', '171の主/補完・200/400・H60・cap10', '全政策・全80の要求/取得/監査が同体。'],
        ['夜補完固定', '171 L180_S4/H200・決済H60', '主0でも補完が参加。主の場数・損益も別記。'],
        ['未知の期間', '旧73/追加7とも既使用', '追加7を新規未見と呼ばない。'],
        ['主選択', fixed['主案'], '旧73の441数量再生から全期発見。'],
        ['事後対照', fixed['事後安定性追加'], '旧73を見て4セルの安定性から後選。主交換なし。'],
        ['過去だけの選択', 'B06_18は前48順位だが上流に全期shortlistを含む', '完全な過去順・未見の選択とは呼ばない。']]
    for row in reports:
        choice = row['candidate']
        for band in ('PRE', 'POST'):
            option = choice[band]
            text = '171固定' if option is None else \
                f"{option['source']}/{option['rule']}/{option['entry_mode']}/{option['orientation']}/±{option['width']}pt/{option['horizon']}"
            condition.append([row['id']+'_'+band, text, ROLES[row['id']]])
    inputs = {name: {'path': p.relative_to(ROOT).as_posix(), 'sha256': R.sha(p)} for name, p in
        [('旧73正本', old_path), ('追加7正本', new_path), ('固定票', HERE / '適用五組の固定.json'),
         ('全80加法', HERE / '全80の固定比較.json')]}
    tables = {'候補比較': {'headers': headers, 'rows': summary},
        '時間帯別': {'headers': headers, 'rows': bands},
        '全セッション': {'headers': ['候補ID', '役割', 'セッション', '期間', '取得数', '順先着F', '逆先着A',
            '未到達N', '不足C', '到達済み先着率', '既知利益円', '既知損失円', '既知差引円', '既知累計円',
            '累計不足C', '全件累計円_不足あり空欄', '主取得数', '補完取得数', '利益決済数', '損失決済数',
            'PF', '全ザラバ時間', '取得回毎時', '主数量棄却', '買い最大予約保有', '売り最大予約保有'], 'rows': scene_rows},
        '条件一覧': {'headers': ['項目', '設定', '注意'], 'rows': condition}}
    R.save(HERE / 'CSVの型付き入力.json', {'trial': 172, 'inputs': inputs, 'tables': tables})
    print(json.dumps({'成功': True, '表行数': {k: len(v['rows']) for k, v in tables.items()},
        '全80': [{'id': r['id'], 'PRE': r['periods']['全80既使用加法']['PRE']['全部'],
            'POST': r['periods']['全80既使用加法']['POST']['全部']} for r in reports]}, ensure_ascii=False))


if __name__ == '__main__':
    main()
