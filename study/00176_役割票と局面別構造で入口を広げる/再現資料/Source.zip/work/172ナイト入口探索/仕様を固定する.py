"""承認済みデイを固定し、ナイトの純技術入口を二段階で探索する条件を保存する。"""
from pathlib import Path
import json
import hashlib

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00172_デイを固定しナイト米国前後の複合入口を探索する'


def ref(path: Path) -> dict:
    """
    機能: 固定対照又は共用部品を指紋付きで参照する。
    引数: path(Path)。
    返り値: dictはpath/bytes/SHA256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,
        'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 夜間だけの評価分母・純出生・数量再生・固定デイの同体を事前に定める。
    引数: なし。171条件と停止済み計算部品を読む。
    返り値: None。新172条件と未実行READMEを保存する。
    """
    assert not TRIAL.exists()
    assert max(int(p.name[:5]) for p in (ROOT/'study').iterdir() if p.is_dir() and p.name[:5].isdigit())==171
    setting={'trial':172,'date':'2026-11-15','name':'デイを固定しナイト米国前後の複合入口を探索する',
        'user_direction':'171のデイは低参加でも確率で補えるとしてユーザーが承認。Dayの主/補完・200/400/H60・数量枠は変更せず、Night PRE/POSTの技術条件を探す。',
        'baseline':ref(ROOT/'study/00171_三時間帯で順行と回復失敗の確認を切り替える/条件.json'),
        'scope':'NK225旧73場を探索、追加7場は既使用参考期。Day40/Night40の全80保持、帯別支持をDay高率で希釈しない。',
        'timeband':'判断q0のNY09:30厳密前/等号以後を夏冬変換。q1帯も記録、保有が境界をまたいでも強制返済しない。',
        'old_candidates':'162/163の既存1460規則を固定対照。元幅ごとの既存出生のgeometryを保持し、純N/ALL/EDGE/正逆を比較。旧診断と今回新規出生を区別する。',
        'new_candidates':'金融未入力のrules172_night.py/manifestで8群768の複合履歴規則を固定。源と辞書SHAは自然出生前F0へ束縛。最低3技術役割、未知は不成立、同場限月/gap180リセット。',
        'new_geometry':'新768の入口geometryはtarget_points=200、出口幅非依存。単点条件と履歴確認を区別する。幅を変えたため新規成立が変わったと偽らない。',
        'widths':[125,150,175,200,225,250,300,350,400,500,750,1000],
        'horizons':['H30','H60','H120','SESSION'],
        'orientation':['NORMAL','REVERSE'],'entry_modes':['ALL','EDGE'],
        'episode':'EDGEは0/逆→当該方向だけを採る。場・限月・180秒超でresetし、NY境界で新arm/episodeを作らない。逆向きは実反対側BBOで再観測、1−pを使わない。',
        'stage1':'旧73場の純主入口NをPRE/POST/全Nightへ再集計。独立一枚スクリーニングであり数量枠付き口座収支ではない。全期発見と前48場からの選択を別枠で残す。',
        'shortlist_support':{'minimum_count':40,'minimum_resolved':25,'minimum_night_scenes':10,
            'maximum_unknown_fraction':.10,'minimum_rate':.65,'minimum_pf':1.1,'maximum_scene_share':.25},
        'shortlist_ranking':'各帯で支持適格からWilson95下限・頻度・前後安定性を別順位とし、各最大5、同一技術群最大3で合計最大15設定。前48だけの支持/count>=25,到達>=15,>=6Night,率>=.65,PF>=1.1,未知<=10%から最大5を別に追加。重複除去最大20/帯。上限は候補数を隠す採用基準ではない。',
        'stage2':'帯別shortlistを組み合わせ、全80でDay171同体・cap10/未決予約・1要求1miniを再生する。Stage1高率を最終成績とせず、主と補完を分ける。幅/期限で枠解放と後続要求も再計算。',
        'reference_routes':'171固定Night、候補PREだけ置換+POST171、POSTだけ置換+PRE171、PRE/POST両置換を別ID。追加7に全母集団を探索せず、旧73で固定した主/近傍/前半選択の最大5組だけ参考確認。',
        'night_fallback':'まず171 L180S4/H200の初参加補完を固定対照として維持。純主N0も別計数。補完条件を追加変更する場合は新試行とし、補完による全場参加を本体の参加と呼ばない。',
        'night_goal':'PRE/POSTそれぞれの同幅先着70%以上・費用後利益損失・支持Night数を重視。全Night最低1取得、平均概ね1回/時を比較し、保有時間のunion参加下限/上限も報告。各小帯への強制取得・一律時間除外は追加しない。',
        'financial':'IFD_FIRST。欠測前に確定した先着F/Aは保持、未到達Nと不足Cを区別。1pt100円、片道38.5円、追加片道5ptを控除。未知を0決済で枠解除しない。',
        'cost':{'point_yen':100,'fee_round_trip':77,'additional_round_trip_slippage_yen':1000},
        'day_guard':'旧73Day37/追加Day3の全主/補完要求・取得・側・q0・幅・期限・損益を171と同体照合。新指標やNight閾値をDayへ反映しない。',
        'execution_clock':'全1分知得q0→別原行q1の既存母集団を維持。指標の5/15/30分と新規時計を混同せず、全Raw毎行実運用と称さない。',
        'holding':'entry～exit区間の和集合を各帯に分配。既知のみ下限、未知をザラバ末まで保有するcapモデル上限。両建て・枚数・重複を二重計上せず、pendingは保有時間へ加えない。',
        'limit':'全80場は既使用、追加7を新規独立未見と呼ばない。多重比較・小標本・未知・Night集中を残す。日中利益で夜間赤字を合算採用せず、未達原因から別仮説へ進む。',
        'outputs':'Markdown/V8設定表/小型統計配列/正式Source/CSV。巨大Raw・共用索引の複製と新xlsxは禁止。'}
    TRIAL.mkdir();(TRIAL/'検査').mkdir()
    path=TRIAL/'条件.json';path.write_text(json.dumps(setting,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (TRIAL/'README.md').write_text('# 00172 デイを固定しナイト米国前後の複合入口を探索する\n\n2026-11-15。ユーザーが171デイを一旦承認したため、Dayを固定しNight PRE/POSTを別評価する。[条件](条件.json)を新自然出生前に固定。現在未実行。純主スクリーニングと数量再生、主と初参加補完を区別する。\n',encoding='utf-8')
    print(json.dumps({'成功':True,'条件SHA256':ref(path)['sha256']},ensure_ascii=False))


if __name__=='__main__':
    main()
