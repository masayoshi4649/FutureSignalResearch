"""可変期限接続器のH60退化形が171取得・要求・デイ監査と同体か確認する。"""
from pathlib import Path
import json
import numpy as np
import 再生172 as R

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def check(context: object, name: str) -> dict:
    """
    機能: 172の無置換再生と旧168再生・171固定正本を同じ時計で照合する。
    引数: context(GenericContext)、name(str)は旧73又は追加7の171出力名。
    返り値: dictは全取得7属性・要求監査・全帯金融の一致証拠。
    """
    birth, candidate, _ = R.baseline(context)
    original = R.R168.replay_candidate(context, birth, candidate, 10)
    current = R.replay(context, birth, {'id': 'BASE171', 'PRE': None, 'POST': None}, {})
    old_sel, old_origin, old_wi, old_tier, old_result = original
    selected, origins, wi, hi, tiers, result = current
    for field in ('cases', 'sides', 'events', 'phases'):
        assert np.array_equal(getattr(old_sel, field), getattr(selected, field)), field
    for left, right in ((old_origin, origins), (old_wi, wi), (old_tier, tiers)):
        assert np.array_equal(left, right)
    assert (hi == context.table.horizons.index('H60')).all()
    assert old_result == result, 'records/requests/auditsの差分'
    prior = ROOT / 'work/171三帯の入口切替' / name
    ref = R.read(prior / '全取得参照.json')['rows'][0]
    for field, actual in [('cases', selected.cases), ('sides', selected.sides), ('events', selected.events),
                         ('phases', selected.phases), ('origins', origins), ('widths', wi), ('tiers', tiers)]:
        assert ref[field] == actual.tolist(), field
    prior_audit = R.read(prior / '数量と要求の監査.json.gz')['rows'][0]
    assert prior_audit['audits'] == result['audits']
    assert prior_audit['requests'] == result['requests']
    report = R.describe(context, current, details=True)
    prior_report = R.read(prior / '固定候補の数量比較.json')['rows'][0]['cap10']
    for band, label in [('DAY', 'DAY'), ('PRE', 'NY前'), ('POST', 'NY後')]:
        actual = report['periods']['全期'][band]['全部']
        expected = prior_report['timebands']['q0'][label]
        for field in ('count', 'F', 'A', 'N', 'C', 'profit', 'loss', 'net', 'scenes', 'hours'):
            assert abs(actual[field] - expected[field]) < 1e-8, (band, field)
    return {'成功': True, '場数': len(context.scenes), '取得': len(selected.cases),
        '要求': len(result['requests']), '全取得属性': 7, '全engine辞書同体': True,
        '171保存済み要求取得監査同体': True, '全三帯10金融指標一致': True, 'report': report}


def main() -> None:
    """
    機能: 旧73だけの基準同体確認を実行し正式検査へ保存する。
    引数: なし。追加7はこのmainでは開かない。
    返り値: None。基準確認JSONを保存する。
    """
    old = R.R168.BASE.Context165()
    context = R.R168.BASE.GenericContext(old.features, old.table, old.capture_rows)
    result = check(context, '旧73固定候補')
    result['Source'] = {p.relative_to(ROOT).as_posix(): R.sha(p)
        for p in (Path(__file__), HERE / '再生172.py', ROOT / 'work/172ナイト数量再生/engine172.py')}
    R.save(HERE / '171基準の同体.json', result)
    print(json.dumps({k: v for k, v in result.items() if k != 'report'}, ensure_ascii=False))


if __name__ == '__main__':
    main()
