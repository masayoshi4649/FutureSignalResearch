"""選定政策出生部品を自然値なしで検査する。列名定義以外は人工入力。"""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import hashlib
import importlib.util
import json
import sys

import numpy as np

from 選定政策の出生 import ROOT, build, edge163, edge172
from rules162 import PreparedEvaluator, candidate_catalog as static_catalog
from rules162_stateful import StatefulEvaluator, candidate_catalog as history_catalog
from rules172_night import NightEvaluator, candidate_catalog as night_catalog

HERE = Path(__file__).resolve().parent


def policy(key: str, source: str, rule: str, width: int, mode: str = 'ALL', orientation: str = 'NORMAL') -> dict:
    """
    機能: 自然成績を含まない人工政策の識別設定を作る。
    引数: key/source/rule/mode/orientation(str)、width(int)は政策設定。
    返り値: dictはbuildに渡す有限設定。
    """
    return {'key': key, 'source': source, 'rule': rule, 'width': width,
        'entry_mode': mode, 'orientation': orientation, 'horizon': 'H60'}


def main() -> None:
    """
    機能: 旧新規則の直結、幅geometry、EDGE契約、反転・prefix・重複cacheを人工入力で照合する。
    引数: なし。正式100列名だけを読み、旧73/追加7の自然値は開かない。
    返り値: None。人工確認JSONを保存する。
    """
    columns = [column['name'] for column in json.loads((ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json').read_text(encoding='utf-8-sig'))]
    path = ROOT / 'work/172ナイト複合候補/人工検査.py'
    specification = importlib.util.spec_from_file_location('fixture172_selected', path)
    fixture = importlib.util.module_from_spec(specification); sys.modules[specification.name] = fixture
    specification.loader.exec_module(fixture)
    buy = fixture.fixture('NB', columns); sell = np.full_like(buy, np.nan); meta = fixture.metadata(len(buy))
    features = SimpleNamespace(buy_X=buy, sell_X=sell, columns=columns, q0_meta=meta)
    options = [policy('旧静的', 'OLD1460', 'TP0001', 200),
        policy('旧履歴', 'OLD1460', 'BR0001', 250), policy('旧履歴EDGE', 'OLD1460', 'BR0001', 250, 'EDGE'),
        policy('旧履歴反転', 'OLD1460', 'BR0001', 250, 'EDGE', 'REVERSE'),
        policy('新150', 'NEW768', 'NB0001', 150), policy('新1000', 'NEW768', 'NB0001', 1000),
        policy('新EDGE', 'NEW768', 'NB0001', 200, 'EDGE'),
        policy('新反転', 'NEW768', 'NB0001', 200, 'EDGE', 'REVERSE')]
    results = build(features, options)
    old_static = PreparedEvaluator(buy, sell, columns, 200)
    old_history = StatefulEvaluator(buy, sell, columns, 250, q0_meta=meta)
    new = NightEvaluator(buy, sell, columns, 200, q0_meta=meta)
    assert np.array_equal(results['旧静的'], old_static.evaluate_one(next(r for r in static_catalog() if r['id'] == 'TP0001'))['directions'])
    expected = old_history.evaluate_one(next(r for r in history_catalog() if r['id'] == 'BR0001'))['directions']
    assert np.array_equal(results['旧履歴'], expected)
    assert results['旧履歴'][100] == 1
    assert np.array_equal(results['旧履歴EDGE'], edge163(expected, meta))
    assert np.array_equal(results['旧履歴反転'], -results['旧履歴EDGE'])
    expected = new.evaluate_one(next(r for r in night_catalog() if r['id'] == 'NB0001'))['directions']
    assert np.array_equal(results['新150'], expected) and np.array_equal(results['新1000'], expected)
    assert results['新150'][101] == 1
    assert np.array_equal(results['新EDGE'], edge172(expected, meta))
    assert np.array_equal(results['新反転'], -results['新EDGE'])
    for name, values in results.items():
        assert values.dtype == np.int8 and values.shape == (140,)
    # ----------------------------------------
    short = SimpleNamespace(buy_X=buy[:112], sell_X=sell[:112], columns=columns, q0_meta=meta[:112])
    prefix = build(short, options)
    poisoned = buy.copy(); poisoned[112:] = 1e6
    future = build(SimpleNamespace(buy_X=poisoned, sell_X=sell, columns=columns, q0_meta=meta), options)
    mirror = build(SimpleNamespace(buy_X=sell, sell_X=buy, columns=columns, q0_meta=meta), options)
    for key in results:
        assert np.array_equal(results[key][:112], prefix[key]) and np.array_equal(results[key][:112], future[key][:112])
        assert np.array_equal(results[key], -mirror[key])
    # ----------------------------------------
    range_buy = fixture.fixture('NR', columns)
    range_features = SimpleNamespace(buy_X=range_buy, sell_X=sell, columns=columns, q0_meta=meta)
    geometric = build(range_features, [policy('旧125', 'OLD1460', 'RG0001', 125), policy('旧1000', 'OLD1460', 'RG0001', 1000)])
    assert np.count_nonzero(geometric['旧125']) > 0 and not np.any(geometric['旧1000'])
    # ----------------------------------------
    calls = {'static': 0, 'history': 0, 'new': 0}
    static_original = PreparedEvaluator.evaluate_one
    history_original = StatefulEvaluator.evaluate_one
    new_original = NightEvaluator.evaluate_one

    def count_static(self: object, candidate: dict) -> dict:
        """
        機能: 人工cache検査中だけ旧静的規則の実評価回数を数える。
        引数: self(object)、candidate(dict)は純評価器と規則。
        返り値: dictは元評価の結果。
        """
        calls['static'] += 1
        return static_original(self, candidate)

    def count_history(self: object, candidate: dict) -> dict:
        """
        機能: 人工cache検査中だけ旧履歴規則の実評価回数を数える。
        引数: self(object)、candidate(dict)は純評価器と規則。
        返り値: dictは元評価の結果。
        """
        calls['history'] += 1
        return history_original(self, candidate)

    def count_new(self: object, candidate: dict) -> dict:
        """
        機能: 人工cache検査中だけ新規則の実評価回数を数える。
        引数: self(object)、candidate(dict)は純評価器と規則。
        返り値: dictは元評価の結果。
        """
        calls['new'] += 1
        return new_original(self, candidate)

    with patch.object(PreparedEvaluator, 'evaluate_one', count_static), \
         patch.object(StatefulEvaluator, 'evaluate_one', count_history), \
         patch.object(NightEvaluator, 'evaluate_one', count_new):
        duplicated = build(features, options + options)
    assert calls == {'static': 1, 'history': 1, 'new': 1} and set(duplicated) == set(results)
    collision = dict(options[0]); collision['width'] = 250
    rejected = False
    try:
        build(features, [options[0], collision])
    except AssertionError:
        rejected = True
    assert rejected and build(None, []) == {}
    # ----------------------------------------
    test_meta = [{'session': '人工Night', 'session_index': 0, 'contract': '人工A', 'q0_time': t}
                 for t in (0., 60., 240., 421., 481., 541.)]
    test_meta[4]['contract'] = '人工B'; test_meta[5]['contract'] = '人工B'; test_meta[5]['session_index'] = 1
    ones = np.ones(6, dtype=np.int8)
    assert np.array_equal(edge163(ones, test_meta), (1, 0, 0, 1, 0, 1))
    assert np.array_equal(edge172(ones, test_meta), (1, 0, 0, 1, 1, 1))
    # ----------------------------------------
    result = {'成功': True, '自然値': '旧73/追加7とも不使用。100列名定義だけ参照。',
        '旧静的と旧履歴と新規則の直結': True, '旧幅geometryが効く': True, '新入口は幅200固定': True,
        'EDGE元契約': 'OLDは163同式scene/gap>180。NEWは172封印と同じ場/scene/contract/gap>180。NY境界参照なし。',
        'gap180と181境界': True, '限月単独resetの旧新差を保持': True,
        '対称と反転': True, 'prefixと未来毒入れ': True, '全8政策': len(options),
        '同key重複と生方向cacheの実評価数': calls, 'key衝突拒否': rejected,
        'Source': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (HERE / '選定政策の出生.py', Path(__file__))}}
    (HERE / '選定政策出生の人工確認.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
