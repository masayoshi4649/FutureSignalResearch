"""全期主案と前48固定の両方を最大5組へ保持する172の純選択部品。"""
import math


def select(rows: list) -> dict:
    """
    機能: 旧73数量統計から主案と前48固定の枠を優先し最大5組を選ぶ。
    引数: rows(list[dict])は二帯政策・全期/前48のFANCと数量再生統計。
    返り値: dictは主案nullable、前48固定nullable、参考適用IDと支持数。
            全期主の前半支持gateは追加せず、全期の弱帯Wilson下限を使う。
            既使用期の全期発見と上流全期選択を含む前48政策を未見と呼ばない。
    """

    def supported(stats: dict, front: bool = False) -> bool:
        """
        機能: 旧数量選択と同じ件数・場数・未知・利益損失の支持を判定する。
        引数: stats(dict)は帯別統計、front(bool)は前48専用基準か。
        返り値: boolは支持適格。先着率の閾値は呼出側で別判定する。
        """
        count, resolved = stats['count'], stats['F'] + stats['A']
        return count >= (25 if front else 40) and resolved >= (15 if front else 25) \
            and stats['scenes'] >= (6 if front else 10) and stats['C'] <= .1 * count \
            and stats['profit'] > 0 and stats['profit'] >= 1.1 * stats['loss'] \
            and (front or (stats['max_scene_share'] or 1) <= .25)

    def wilson_lower(f: float, a: float) -> float:
        """
        機能: 旧短表selectorと同じ二側95% Wilson下限を計算する。
        引数: f/a(float)は順先着/逆先着の非負件数。
        返り値: floatは0〜1。到達0件では順位上の0。
        """
        n = f + a
        if n <= 0:
            return 0.
        p = f / n
        z = 1.959963984540054
        z2 = z * z
        return (p + z2 / (2*n) - z * math.sqrt(p*(1-p)/n + z2/(4*n*n))) / (1 + z2/n)

    def score(row: dict, period: str = '全期') -> tuple:
        """
        機能: 二帯の弱いWilson下限、夜間頻度、政策IDで旧順位を再現する。
        引数: row(dict)は一政策、period(str)は全期又は前48場。
        返り値: tupleは昇順ソート用の固定順位。
        """
        bands = row['cap10']['periods'][period]
        lower = [wilson_lower(bands[b]['全部']['F'], bands[b]['全部']['A']) for b in ('PRE', 'POST')]
        return (-min(lower), -bands['NIGHT']['全部']['per_hour'], row['id'])

    both = [r for r in rows if r['candidate']['PRE'] is not None and r['candidate']['POST'] is not None]
    full = [r for r in both if all(supported(r['cap10']['periods']['全期'][b]['全部']) and
        (r['cap10']['periods']['全期'][b]['全部']['rate'] or 0) >= .7 for b in ('PRE', 'POST'))]
    full.sort(key=score)
    near = [r for r in both if all(supported(r['cap10']['periods']['全期'][b]['全部']) and
        (r['cap10']['periods']['全期'][b]['全部']['rate'] or 0) >= .65 for b in ('PRE', 'POST'))]
    near.sort(key=score)
    front = [r for r in both if all(supported(r['cap10']['periods']['前48場'][b]['全部'], True) and
        (r['cap10']['periods']['前48場'][b]['全部']['rate'] or 0) >= .65 for b in ('PRE', 'POST'))]
    front.sort(key=lambda r: score(r, '前48場'))
    primary = full[0]['id'] if full else None
    front_id = front[0]['id'] if front else None
    # ----------------------------------------
    # 主案と前48固定を先に確保し、残枠を全期上位2・近傍上位3で埋める。
    wanted = ([primary] if primary else []) + ([front_id] if front_id else []) \
        + [r['id'] for r in full[:2]] + [r['id'] for r in near[:3]]
    ids = list(dict.fromkeys(wanted))[:5]
    assert len(ids) == len(set(ids)) <= 5
    assert primary is None or primary in ids
    assert front_id is None or front_id in ids
    return {'成功': True, '選択版': '172数量選択_前48枠予約1',
        '主案': primary, '両帯支持70以上数': len(full), '両帯支持65以上数': len(near),
        '前48支持65以上数': len(front), '前48固定': front_id,
        '参考適用ID': ids,
        '固定順': 'primary→front固定(あれば)→full上位2→near上位3を重複除去して最大5',
        '採否': '両帯の全部取得で支持・先着70以上を主案。追加7はこの固定最大5組だけ。',
        '注意': '全80は既使用。前48政策は本選択関数だけで前48を用いるが、上流shortlistには全期選択も含むため完全な過去だけの探索とは呼ばない。'}
