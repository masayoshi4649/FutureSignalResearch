"""固定政策だけの純出生部品。入力は当時特徴と政策の識別・技術設定だけ。"""
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'work/162複合入口候補'))
sys.path.insert(0, str(ROOT / 'work/172ナイト複合候補'))
from rules162 import PreparedEvaluator, candidate_catalog as static_catalog
from rules162_stateful import StatefulEvaluator, candidate_catalog as history_catalog
from rules172_night import NightEvaluator, candidate_catalog as night_catalog

VERSION = '172固定政策の純出生1'


def edge163(directions: np.ndarray, q0_meta: list[dict]) -> np.ndarray:
    """
    機能: 163元Sourceと同じ場/180秒超gapによるEDGEを全場履歴で計算する。
    引数: directions(np.ndarray[int8,N])は未反転ALL方向、q0_meta(list[dict])は当時識別時計。
    返り値: np.ndarray[int8,N]は遷移出生。限月単独又はNY帯によるresetを追加しない。
    """
    assert directions.shape == (len(q0_meta),) and directions.dtype == np.int8
    assert np.isin(directions, (-1, 0, 1)).all()
    if not len(directions):
        return directions.copy()
    sessions = np.asarray([q['session_index'] for q in q0_meta])
    times = np.asarray([q['q0_time'] for q in q0_meta], dtype=np.float64)
    previous = np.r_[np.int8(0), directions[:-1]]
    reset = np.r_[True, (sessions[1:] != sessions[:-1]) | (times[1:] - times[:-1] > 180)]
    return np.where((directions != previous) | reset, directions, 0).astype(np.int8)


def edge172(directions: np.ndarray, q0_meta: list[dict]) -> np.ndarray:
    """
    機能: 172新768の封印Sourceと同じ場/scene/限月/180秒超gapのEDGEを作る。
    引数: directions(np.ndarray[int8,N])は未反転ALL方向、q0_meta(list[dict])は当時識別時計。
    返り値: np.ndarray[int8,N]は全場履歴の遷移出生。NY帯を参照しない。
    """
    assert directions.shape == (len(q0_meta),) and directions.dtype == np.int8
    assert np.isin(directions, (-1, 0, 1)).all()
    if not len(directions):
        return directions.copy()
    keys = [(q['session'], q.get('session_index', q.get('scene', q['session'])), q['contract']) for q in q0_meta]
    times = np.asarray([q['q0_time'] for q in q0_meta], dtype=np.float64)
    reset = np.r_[True, np.asarray([keys[i] != keys[i - 1] or times[i] - times[i - 1] > 180
                                   for i in range(1, len(keys))], dtype=bool)]
    previous = np.r_[np.int8(0), directions[:-1]]
    return np.where(reset | (previous != directions), directions, 0).astype(np.int8)


# ----------------------------------------
def build(features: object, options: list[dict]) -> dict:
    """
    機能: 選定済みOLD1460/NEW768政策だけを純特徴から計算し、全q0方向を返す。
    引数: features(object)はbuy_X/sell_X/columns/q0_metaだけ、options(list[dict])はkey/source/rule/width/entry_mode/orientation/horizonを持つ政策。
    返り値: dict[str,np.ndarray[int8,N]]は政策key別方向。同keyは一度だけ計算し、帯routing・取得・金融を行わない。
    """
    assert isinstance(options, list)
    if not options:
        return {}
    unique = {}
    for policy in options:
        key = policy['key']
        assert isinstance(key, str) and key
        source, rule = policy['source'], policy['rule']
        mode, orientation = policy['entry_mode'], policy['orientation']
        width, horizon = policy['width'], policy['horizon']
        assert source in ('OLD1460', 'NEW768') and isinstance(rule, str)
        assert mode in ('ALL', 'EDGE') and orientation in ('NORMAL', 'REVERSE')
        assert isinstance(width, int) and not isinstance(width, bool) and width > 0
        assert horizon in ('H30', 'H60', 'H120', 'SESSION')
        identity = (source, rule, mode, orientation, width, horizon)
        if key in unique:
            assert unique[key][0] == identity, '同keyに異なる政策設定'
        else:
            unique[key] = (identity, policy)
    columns = list(features.columns)
    q0_meta = features.q0_meta
    n = len(q0_meta)
    static = {rule['id']: rule for rule in static_catalog()}
    history = {rule['id']: rule for rule in history_catalog()}
    night = {rule['id']: rule for rule in night_catalog()}
    assert len(static) + len(history) == 1460 and not set(static).intersection(history)
    assert len(night) == 768
    static_evaluators = {}; history_evaluators = {}; night_evaluator = None
    raw_cache = {}; mode_cache = {}; results = {}
    for key, (identity, _) in unique.items():
        source, rule_id, mode, orientation, width, _ = identity
        geometry = width if source == 'OLD1460' else 200
        raw_key = (source, rule_id, geometry)
        if raw_key not in raw_cache:
            if source == 'NEW768':
                assert rule_id in night, '未定義NEW768規則'
                if night_evaluator is None:
                    night_evaluator = NightEvaluator(features.buy_X, features.sell_X, columns,
                        target_points=200, q0_meta=q0_meta)
                direction = night_evaluator.evaluate_one(night[rule_id])['directions']
            elif rule_id in static:
                if geometry not in static_evaluators:
                    static_evaluators[geometry] = PreparedEvaluator(features.buy_X, features.sell_X,
                        columns, target_points=geometry)
                direction = static_evaluators[geometry].evaluate_one(static[rule_id])['directions']
            else:
                assert rule_id in history, '未定義OLD1460規則'
                if geometry not in history_evaluators:
                    history_evaluators[geometry] = StatefulEvaluator(features.buy_X, features.sell_X,
                        columns, target_points=geometry, q0_meta=q0_meta)
                direction = history_evaluators[geometry].evaluate_one(history[rule_id])['directions']
            assert direction.shape == (n,) and direction.dtype == np.int8 and np.isin(direction, (-1, 0, 1)).all()
            raw_cache[raw_key] = direction
        mode_key = (*raw_key, mode)
        if mode_key not in mode_cache:
            direction = raw_cache[raw_key]
            mode_cache[mode_key] = direction if mode == 'ALL' else (edge163 if source == 'OLD1460' else edge172)(direction, q0_meta)
        direction = mode_cache[mode_key]
        results[key] = direction.copy() if orientation == 'NORMAL' else (-direction).astype(np.int8)
    return results
