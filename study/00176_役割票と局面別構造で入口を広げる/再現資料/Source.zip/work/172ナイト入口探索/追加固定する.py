"""初回F0を保持したまま、実行直前に追加SourceをF0aへ束縛する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / 'study/00172_デイを固定しナイト米国前後の複合入口を探索する'


def ref(path: Path) -> dict:
    """
    機能: 追加固定する入力の相対名・サイズ・指紋を取る。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 新768純出生と金融screenをまだ実行していない段階のSourceを封印する。
    引数: なし。
    返り値: None。既存F0の非改変を確認し別F0aを保存する。
    """
    source = TRIAL / '検査/出生前F0.json'
    result = json.loads(source.read_text(encoding='utf-8'))
    for row in result['固定対象']:
        assert ref(ROOT / row['path']) == row
    names = {row['path'] for row in result['固定対象']}
    paths = [Path(__file__), ROOT / 'work/172ナイト複合候補/出生を作る.py',
        ROOT / 'work/172ナイト複合候補/金融比較する.py', ROOT / 'work/162複合入口候補/rules162.py',
        ROOT / 'work/161三時間帯入口のデータ/data161.py',
        ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json']
    result['固定対象'] += [ref(p) for p in paths if p.relative_to(ROOT).as_posix() not in names]
    result['元F0'] = ref(source)
    result['追加固定UTC'] = datetime.now(timezone.utc).isoformat()
    result['追加時点'] = '新768の自然出生・金融比較は未実行。旧1460の固定出生再集計は完了済み。'
    target = TRIAL / '検査/出生前F0a.json'
    assert not target.exists()
    assert not (ROOT / 'work/172ナイト複合候補/全出生').exists()
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'F0a': ref(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
