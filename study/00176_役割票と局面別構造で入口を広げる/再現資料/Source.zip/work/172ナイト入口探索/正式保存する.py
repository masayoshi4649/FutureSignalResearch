"""夜間入口の条件・選択の出生・正本・小型Sourceを正式172へ保存する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import sys
import zipfile
import shutil
import 再生172 as R

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00172_デイを固定しナイト米国前後の複合入口を探索する'
NAMES = {'BASE171': '171固定', 'B05_01': '全期主', 'B06_18': '前48順位',
         'B05_02': '主近傍2', 'B05_03': '主近傍3', 'B05_11': '事後安定性対照'}


def ref(path: Path) -> dict:
    """
    機能: 共用入力又は保存物の物理位置・サイズ・指紋を記録する。
    引数: path(Path)。
    返り値: dictはrepo相対path/bytes/sha256。
    """
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size, 'sha256': R.sha(path)}


def archive(target: Path, paths: list) -> dict:
    """
    機能: 元byteを保持し、Sourceは圧縮・既圧縮数値は再圧縮せず保存する。
    引数: target(Path)は新規ZIP、paths(list[Path])は重複排除前の保存対象。
    返り値: dictはZIPと全memberのサイズ・SHA。CRC/元byteも検査する。
    """
    assert not target.exists()
    values = sorted(set(paths))
    with zipfile.ZipFile(target, 'x') as output:
        for path in values:
            compress = zipfile.ZIP_STORED if path.suffix in ('.npz', '.gz', '.zip') else zipfile.ZIP_DEFLATED
            output.write(path, path.relative_to(ROOT).as_posix(), compress_type=compress)
    members = []
    with zipfile.ZipFile(target) as check:
        assert check.testzip() is None
        for path in values:
            name = path.relative_to(ROOT).as_posix()
            assert check.read(name) == path.read_bytes()
            members.append(ref(path))
    return {'archive': ref(target), 'members': members}


def table(rows: list, period: str, bands: tuple = ('PRE', 'POST', 'NIGHT')) -> str:
    """
    機能: 既知利益・損失と不足を落とさず比較Markdownを組む。
    引数: rows(list[dict])、period(str)、bands(tuple[str])。
    返り値: strは見出しと表。
    """
    lines = ['|候補|帯|取得|F/A/N/C|先着率|利益円|損失円|既知差引円|参加場|回/時|',
             '|---|---|---:|---|---:|---:|---:|---:|---:|---:|']
    for row in rows:
        for band in bands:
            q = row['periods'][period][band]['全部']
            rate = f"{q['rate']:.2%}" if q['rate'] is not None else '未定義'
            lines.append(f"|{row['id']}|{band}|{q['count']}|{q['F']}/{q['A']}/{q['N']}/{q['C']}|{rate}|"
                f"{q['profit']:,}|{q['loss']:,}|{q['net']:+,}|{q['scenes']}/{q['eligible_scenes']}|{q['per_hour']:.3f}|")
    return '\n'.join(lines)


def main() -> None:
    """
    機能: 検証済み研究を小型正式正本へ保存し、共通目次が参照できる資料を作る。
    引数: なし。保存済み固定結果・独立検査を読む。
    返り値: None。既存171を変えず、172のREADME・V8・Source/正本ZIPを保存する。
    """
    data = R.read(HERE / '全80の固定比較.json')
    hold = R.read(ROOT / 'work/172ナイト基礎診断/全80の保有と到達支持.json')
    rows = data['rows']
    for name in ('旧73独立検算.json', '追加7独立検算.json', 'CSV独立検算.json'):
        value = R.read(ROOT / 'work/172ナイト数量再生' / name)
        assert value.get('成功', value.get('success')) is True
        shutil.copyfile(ROOT / 'work/172ナイト数量再生' / name, TRIAL / '検査' / name)
    shutil.copyfile(ROOT / 'work/172ナイト基礎診断/全80独立集計の検査.json', TRIAL / '検査/全80保有支持の独立検査.json')
    shutil.copyfile(HERE / 'CSV作成確認.json', TRIAL / '検査/CSV作成確認.json')
    shutil.copyfile(HERE / '条件心理の草稿.md', TRIAL / '条件と市場心理.md')
    text = (TRIAL / '条件と市場心理.md').read_text(encoding='utf-8').replace(
        '# 172の固定三組を条件と心理仮説から読む草稿', '# 172の固定三組を条件と心理仮説から読む').replace(
        '172の正式文書へ統合する前の草稿。', '172の固定条件の説明。')
    text = text.replace('この草稿ではラベルを再読していないため、件数はRootが最終統計から差し込む。',
        '全80では34F/0A/154N/17C、到達4Night・最大場集中79.41%。数値の正本は[README](README.md)を参照する。')
    text = text.replace('最終文書では、主案・安定性対照・前半選択の役割を保持し、',
        '本試行では[README](README.md)と[閲覧資料](閲覧資料.md)で、主案・安定性対照・前半選択の役割を保持し、')
    text = text.replace('(../172ナイト入口の外部調査/外部調査と複合入口候補.md)', '(外部調査と候補.md)')
    text = text.replace('(../162複合入口候補/rules162.py)', '(再現資料/Source.zip)').replace(
        '(../162複合入口候補/rules162_stateful.py)', '(再現資料/Source.zip)').replace(
        '(選定政策の出生.py)', '(再現資料/Source.zip)')
    (TRIAL / '条件と市場心理.md').write_text(text, encoding='utf-8')
    shutil.copyfile(ROOT / 'work/172ナイト入口の外部調査/外部調査と複合入口候補.md', TRIAL / '外部調査と候補.md')
    external_path = TRIAL / '外部調査と候補.md'
    external_text = external_path.read_text(encoding='utf-8').replace(
        '正式な実行条件・結果・採否は次の試行で固定する。',
        'これは探索前の提案であり、全案を172で実装したという記録ではない。172で実行した8群・条件・結果・採否は[README](README.md)と[設定表](設定と結果.md)へ分けた。')
    external_path.write_text(external_text, encoding='utf-8')
    # ----------------------------------------
    selected = [r for r in rows if r['id'] in ('BASE171', 'B05_01', 'B05_11')]
    readme = '''# 00172 デイを固定しナイト米国前後の複合入口を探索する

2026-11-15。171デイはユーザー判断で固定し、ナイトの複合入口だけを探索した。**米国前EX0064反転・±400pt/場末と、米国後CP0031・±150pt/30分の組合せB05_11を、次に優先して確かめる有望な安定性対照として残す。** 旧73を見た事後選択であり、事前主B05_01と交換しない。

B05_11は全40ナイト・150取得、95順21逆26未到達8不足、到達済み先着率81.90%。既知利益2,842,530円／損失594,464円／差引2,248,066円。米国前78.75%、米国後88.89%。主119取得＋初参加補完31取得であり、全場参加を主だけの成績としない。頻度は0.290回/時、平均約3時間27分に一回で、概ね1回/時には達していない。

## 全80の夜間比較

'''+table(selected, '全80既使用加法')+'''

F/A/N/Cは順側先着/逆側先着/未到達/観測不足。主率はF/(F+A)。未到達の期限返済も金融へ含め、到達済み先着率を決済勝率と混同しない。C>0の全件収支は未確定。利益・損失・差引は既知分で、Nを除いた利益ではない。

## 100%案と安定性対照を分ける理由

全期順位の事前主B05_01は、PRE=EX0064逆400/SESSION、POST=HP0050正400/H30。POSTは34F/0Aで100%だが、205取得のうち154件が未到達、17件が不足。到達したのは4/40ナイト、34Fのうち27件が2026-11-05_Nightに集中する。前48POSTは2F/0Aでも既知差引−388,853円、追加7POSTは0F/0A/8N・−57,616円であり、安定した100%勝利ではない。

対するB05_11のPOSTは32F/4A・88.89%、到達17/40ナイト、到達件数の最大場集中16.67%。前48は10F/1A・+128,306円、後25は16F/3A・+188,152円、追加7参考は6F/0A・+83,538円。125pt超を優先した事後安定性対照であり、未見で選んだ主案とは称さない。

PRE主は64取得・54F/5A/0N/5C・91.53%だが17/40ナイトに成立し、追加4ナイトでは主0件だった。共通の初参加補完31件は9F/12A/10N・既知−48,387円。補完を含めるとPREは78.75%・全40ナイトになる。将来も同じ条件が十分な頻度で現れるという証拠ではない。

## 探索・入力・費用

旧73場の固定1460複合規則と、新しく金融前に固定した8群768履歴規則を比較。ALL/EDGE×正逆×12幅×四期限で427,776設定、PRE/POSTでは855,552帯別設定を独立一枚評価した。高率を小群から選ぶ自由度を明記し、候補数を隠さない。正逆は同q0の実反対側BBOで再評価し、1−pは使わない。

幅は125対照と150/175/200/225/250/300/350/400/500/750/1000pt、期限はH30/H60/H120/SESSION。支持とWilson下限・頻度・前後安定性から各帯20政策を短表化し、171対照・片帯置換・両帯置換の441政策を予約込み買売各10枚で再生した。全期の両帯70%以上支持は123政策。前48順位も別固定したが上流短表には全期選択が含まれるため、完全な過去だけの探索ではない。

新8群は押戻し再開・低ADX端回復・BB帰還・過去端逸脱後回復・反対動力失速・圧縮解放・上位再加速・混在DI回復。768を金融前封印し、旧出生と同じものとは扱わない。新NRはPOST短表に入ったが最終五組へは残らず、NCはイベント自体が少なく最終自然成立0件だった。複数技術の同時要求が頻度を減らした段階も残した。

入力は正式148の当時100特徴・q0/q1取得対応、共有163の旧73任意幅金融、共有167の追加7。旧73も追加7も既使用であり、追加7を新しい独立未見と呼ばない。全1分q0→別原行q1という既存母集団で、Raw毎行の実注文成立を検証したものではない。

要求mini1枚、買売各10枚を未決予約込みで管理し、未知決済で枠を空けない。税込片道38.5円、1pt100円、追加片道5ptの滑りを控除。実BBOのspreadも含む。注文枠・約定代用・時間足・NY境界は[条件](条件.json)と[設定表V8](設定と結果.md)を参照。

## 参加・保持と限界

'''
    lines = ['|政策|Night主参加場|Night全取得場|主/補完取得|回/時|保有時間union下限〜上限|',
             '|---|---:|---:|---:|---:|---:|']
    for identity in ('BASE171', 'B05_01', 'B05_11'):
        h = hold['全80加法'][identity]['NIGHT']
        q = h['全部']['q0金融と到達支持']; main = h['主']['q0金融と到達支持']; seconds = h['全部']['実時間保有']
        lines.append(f"|{identity}|{main['scenes']}/40|{q['scenes']}/40|{q['core_count']}/{q['technical_count']}|{q['per_hour']:.3f}|"
            f"{seconds['既知保有参加率_pct']:.2f}%〜{seconds['未知場末上限参加率_pct']:.2f}%|")
    readme += '\n'.join(lines)+'''

保有時間はq1→決済区間の和集合を実時間帯へ配賦する。既知決済だけを下限、未知をザラバ末まで保持するcapモデルを上限とし、枚数・両建てを二重計上しない。pendingは保有時間へ加えない。PRE出生がPOSTへ持ち越す同セッション内の保有も含み、新規の帯別取得率とは別である。

Dayは全六政策とも40/40場・365取得、170F/32A/158N/5C、先着84.16%、既知利益5,874,211円／損失1,643,931円で171と同体。保有率22.8044〜25.8862%も同じ。Dayの好成績をNight採否へ加算しない。

## 確認と閲覧

純768の対称・prefix・未来改変・未知・幅独立・履歴窓を人工確認。代表八群の金融221,184セルと、選定出生247,373方向セルを独立照合した。固定六政策の二期間は別一覧法で全要求/取得/監査一致、金融9,522セル一致。保有・到達支持の別集計4,140セル、四CSV全23,131セルも一致した。

[条件と市場心理](条件と市場心理.md)は実装の全条件を掲載し、一般論・心理仮説・実証を分ける。[外部調査](外部調査と候補.md)、[探索の経過](探索の経過.md)、[閲覧CSV](閲覧資料.md)、[再現手順](再現手順.md)、[保存索引](再現資料/保存索引.json)。有望候補を得たため、新規条件の探索はここで一旦止める。将来再現、注文成立、未知取引を含む利益を保証しない。
'''
    (TRIAL / 'README.md').write_text(readme, encoding='utf-8')
    # ----------------------------------------
    progress = '# 探索の経過と候補の出生\n\n2026-11-15。固定条件と結果はREADME、条件.json、正本ZIPを優先する。\n\n'
    progress += '1. 171夜間だけを診断し、PRE46.15%・POST63.16%、全Night保有下限13.82%を確認。デイは変更しない。\n'
    progress += '2. 外部一次資料と既存教材から8技術群768を金融前に固定。旧1460は既存出生を全12幅・四期限・正逆・帯別へ再集計した。\n'
    progress += '3. 支持を伴う各帯20候補を純部品で固定し、441政策を数量再生。独立一枚の高率を口座収支へ読み替えなかった。\n'
    progress += '4. 全期主B05_01、近傍2、前48順位B06_18を選択。一般の人工例で前48枠が最大5から落ち得る選択器の不具合を修正した。今回の4IDは不変で順序だけ変更し、旧Source/結果も保存。\n'
    progress += '5. 主POSTの前半支持不足を調べ、4セルでFA>=6・先着>=70%・PF>=1の36政策を事後診断。POST幅125超優先→4セル最小Wilson下限→頻度→IDでB05_11を後選した。主交換はせず、計5組を追加7金融前に固定した。\n'
    progress += '6. 純出生を封印して追加7へ参考適用。PRE主0、HP400未到達8件に対してCP150は6F/0A。全80の支持集中を診断し、HPの34Fは4Night・27Fが単場、CPは17Night到達と確認した。\n'
    progress += '7. 有望な比較対象を保存して一旦停止。頻度不足、初参加補完の赤字、PREの追加期間無成立、未知、探索多重性は未解決として残す。次回は新しい試行で、主入口の成立分布と背景の可用性、確認追加による取得位置悪化を分けて調べる。\n\n'
    progress += '上記の36群の選択は旧73を見た後選であり、事前登録した主の成績を上書きしない。追加7も既使用である。高率だけの順位から、前後の収支・到達した場数・未到達を別々に調べる必要があるという知見を残す。\n'
    (TRIAL / '探索の経過.md').write_text(progress, encoding='utf-8')
    # ----------------------------------------
    template = (ROOT / 'docs/議論/手法と時間スケールの汎用表_版8.md').read_text(encoding='utf-8')
    template = template.replace('(../technical-analysis/', '(../../docs/technical-analysis/').replace('(手法と時間スケールの汎用表_版7.md)', '(../../docs/議論/手法と時間スケールの汎用表_版7.md)')
    template = template.replace('(逆行200ptより先に順行400ptへ届く入口.md)', '(../../docs/議論/逆行200ptより先に順行400ptへ届く入口.md)')
    template = template.replace('全セルは未設定・未検証。', '以下はV8を複写した原表。個別セルの実使用は末尾の設定ID表で上書きし、それ以外は本試行の当該組として未使用。')
    template += '\n\n## 172設定IDと結果\n\n版8・63×9を複写。複合成績を指標単独の効果としない。期間・足幅・履歴実分・判断q0を分ける。\n\n'
    template += '|設定ID|使用する系統・尺度|閾値・複合ID|結果の正本|\n|---|---|---|---|\n'
    template += '|N172-PRE|I03/I04の5分、I05の15分、Sの5分足形、Vの1分、I09換算と板spread|EX0064の元方向を反転。σ−1.5、ヒゲ0.6、RSI中心<=5、ΔRSI/ΔHist>0、実体>=0、量>=0.5、spread<=20、gap<=1ATR。±400/SESSION|B05_01/11のPRE。主と補完は別|\n'
    template += '|N172-HP|I03/I04の5分列の20実分履歴、I01/I08の長短票、Vの1分|HistΔ20実分min>=0、absRSIΔmax<=12、Hist/ATR>=.05、long票>=2、15分ADXΔ>=0、量>=.75、spread<=20。±400/H30|B05_01 POST。F34全4Night集中・N154|\n'
    template += '|N172-CP|I03/I04の5分、I01/I08の15/30分、I05/I09の15分、Vの1分|BB幅/ATR15<=4、BB位置0..1.5σ、15/30分EMA/DI方向4票中>=3、実体>=.6、HistΔ/RSIΔ>0、量>=1.25、spread<=10、gap<=1ATR。±150/H30|B05_11 POST、32F4A16N3C|\n'
    template += '|N172-NEW8|I01/I03/I04/I05/I08/I09・S価格端・V観測量、原板品質/1/5/15/30分と5/10/20実分履歴（NCは15/30/60実分）|NP/NR/NB/NF/NS/NC/NA/NX各96。全閾値は出生と比較正本.zip内work/172ナイト複合候補/候補辞書.json。入口geometry200固定・出口幅非依存|純768出生、NEWの金融比較。NC成立0。NRはPOST短表のみ|\n'
    template += '|N172-IFD|Cの売買同一式とE対称IFD、原行時計、H30/H60/H120/SESSION|12幅125..1000、実反対BBO、各要求1mini・各側cap10、補完200/H60|全441及び固定6政策|\n'
    template += '|N172-DAY/T|171固定I03/I04/I05/I08/V/S及び旧T/局所階層|Dayの200/400/H60、T200/H60・L180S4を維持。30分を含む既知票と未知は元仕様通り|全80Day同体、初参加補完赤字を別計|\n\n'
    template += '各規則の全条件・係数・票の重複と心理の限界は[条件と市場心理](条件と市場心理.md)。支持不足/未使用/条件不成立/指標未知を区別する。CCI・Stochastic・OBV・MFI等の外部案を調査したが、本試行で新計算して検証したとはしない。\n'
    (TRIAL / '設定と結果.md').write_text(template, encoding='utf-8')
    # ----------------------------------------
    viewer = '''# 閲覧CSV

2026-11-15。新規xlsxは作成しない。6候補の全80セッションを残し、未知を空欄にする。

- [候補比較](../../outputs/00172_デイ固定とナイト入口の比較/候補比較.csv)：60行。全80・NIGHTのB05_11を、BASE171/B05_01と比較する。
- [時間帯別](../../outputs/00172_デイ固定とナイト入口の比較/時間帯別.csv)：360行。DAY/PRE/POST/NIGHT、全部/主/補完を分離。
- [全セッション](../../outputs/00172_デイ固定とナイト入口の比較/全セッション.csv)：480行。6候補×80場、既知利益・損失・既知累計・累計不足Cを保持。
- [条件一覧](../../outputs/00172_デイ固定とナイト入口の比較/条件一覧.csv)：24行。幅/期限/費用/数量/候補の出生を参照。

F/(F+A)は到達済み先着率であり、未到達の期限決済や不足を含む決済勝率とは違う。全件収支はC>0で空欄。1mini/要求、各側10枚までの因果再生で、利益を一律10倍した結果ではない。全80は既使用。

artifact-tool2.8.157・Node24.22.1で型付き表を著作・再計算・全セル照合・四表描画確認。元numericと全取得から別実装で全23,131セル、累計不足後の空欄448セルを確認した。[独立票](検査/CSV独立検算.json)。
'''
    (TRIAL / '閲覧資料.md').write_text(viewer, encoding='utf-8')
    # ----------------------------------------
    permanent = TRIAL / '再現資料'
    permanent.mkdir(exist_ok=True)
    sources = [p for folder in (HERE, ROOT / 'work/172ナイト複合候補', ROOT / 'work/172ナイト基礎診断',
        ROOT / 'work/172ナイト数量再生') for pattern in ('*.py', '*.mjs') for p in folder.glob(pattern)]
    sources += [ROOT / 'work/151過去場判別/data151.py', ROOT / 'work/161三時間帯入口のデータ/data161.py',
        ROOT / 'work/163任意幅の数値化/arrays163.py', ROOT / 'work/166可変場の数値化/arrays166.py',
        ROOT / 'work/162複合入口候補/rules162.py', ROOT / 'work/162複合入口候補/rules162_stateful.py',
        ROOT / 'work/171三帯の入口切替/route171.py', ROOT / 'work/171三帯の入口切替/固定候補を再生する.py']
    for value in list(sys.modules.values()):
        filename = getattr(value, '__file__', None)
        if filename:
            p = Path(filename).resolve()
            if p.suffix == '.py' and p.is_relative_to(ROOT / 'work'):
                sources.append(p)
    source_archive = archive(permanent / 'Source.zip', sources)
    results = [p for p in HERE.iterdir() if p.is_file() and p.suffix in ('.json', '.gz', '.npz')]
    results += [ROOT / 'work/171三帯の入口切替/旧73探索/主案と前半A-Bの封印.json',
        ROOT / 'work/172ナイト複合候補/候補辞書.json', ROOT / 'work/172ナイト複合候補/人工検査.json',
        ROOT / 'work/172ナイト複合候補/全出生/新768の出生.npz', ROOT / 'work/172ナイト複合候補/全出生/全出生の確認.json']
    results += [p for folder in (ROOT / 'work/172ナイト基礎診断', ROOT / 'work/172ナイト数量再生')
        for p in folder.iterdir() if p.is_file() and p.suffix in ('.json', '.gz')
        and not p.name.endswith('一覧再生結果.json.gz')]
    results += [p for folder in (ROOT / 'work/172ナイト複合候補/金融比較', ROOT / 'work/172ナイト複合候補/段階診断')
        for p in folder.iterdir() if p.is_file() and p.suffix in ('.json', '.gz')]
    result_archive = archive(permanent / '出生と比較正本.zip', results)
    # ----------------------------------------
    shared = {}
    for key, folder in [('旧73数値表', ROOT / 'inputs/00163_任意幅の共用価格索引/数値表'),
                        ('追加7数値表', ROOT / 'inputs/00167_追加七場の入口と共用価格索引/自然数値表')]:
        shared[key] = {p.name: {'bytes': p.stat().st_size, 'sha256': R.sha(p)}
            for p in (folder / '任意幅配列.npz', folder / '任意幅識別.json.gz')}
    R.save(TRIAL / '検査/共用入力の指紋.json', shared)
    index = {'成功': True, '保存UTC': datetime.now(timezone.utc).isoformat(),
        '条件': ref(TRIAL / '条件.json'), 'Source': source_archive, '正本': result_archive,
        '共用': {'旧73': 'inputs/00163_任意幅の共用価格索引', '追加7': 'inputs/00167_追加七場の入口と共用価格索引',
            '旧100特徴': 'inputs/00148_全1分入口母集団'},
        '中間を省く': '旧1460と新768の全screen数値NPZ計81MBは再生成中間としてworkにだけ置く。正式には軸・全指紋・診断上位・短表・441全統計・固定6案・Sourceを保存し、旧全出生は正式163を参照する。原板・共用金融・feature cacheは複製しない。',
        '省略中間指紋': [ref(ROOT / 'work/172ナイト基礎診断/1460純新規のナイト診断配列.npz'),
            ref(ROOT / 'work/172ナイト複合候補/金融比較/新768のナイト診断配列.npz')],
        'CSV': [ref(p) for p in (ROOT / 'outputs/00172_デイ固定とナイト入口の比較').glob('*.csv')]}
    R.save(permanent / '保存索引.json', index)
    print(json.dumps({'成功': True, 'Source': source_archive['archive'], '正本': result_archive['archive'],
        'Source数': len(source_archive['members']), '正本数': len(result_archive['members'])}, ensure_ascii=False))


if __name__ == '__main__':
    main()
