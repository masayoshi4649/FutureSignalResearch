import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {Workbook} from '@oai/artifact-tool';

const here=path.dirname(fileURLToPath(import.meta.url));
const root=path.resolve(here,'../..');
const input=path.join(here,'CSVの型付き入力.json');
const output=path.join(root,'outputs','00172_デイ固定とナイト入口の比較');

/**
 * 機能: 内容のSHA256を返す。
 * @param {Buffer|string} value - 指紋化する内容。
 * @returns {string} 十六進SHA256。
 */
function sha(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

/**
 * 機能: 型付き値を引用規則に従ったCSVセルへ変える。
 * @param {number|string|boolean|null} value - 一セルの元値。
 * @returns {string} CSVの文字列。
 */
function field(value) {
  const s=value===null?'':String(value);
  return /[",\r\n]/.test(s)?'"'+s.replaceAll('"','""')+'"':s;
}

// ----------------------------------------
const bytes=await fs.readFile(input);
const data=JSON.parse(bytes);
assert.equal(data.trial,172);
assert.deepEqual(Object.keys(data.tables),['候補比較','時間帯別','全セッション','条件一覧']);
for (const ref of Object.values(data.inputs)) {
  assert.equal(sha(await fs.readFile(path.resolve(root,ref.path))),ref.sha256);
}
const workbook=Workbook.create();
const owners=[];
for (const [name,t] of Object.entries(data.tables)) {
  const original=[t.headers,...t.rows];
  assert.ok(original.every(r=>r.length===t.headers.length));
  const sheet=workbook.worksheets.add(name);
  const range=sheet.getRangeByIndexes(0,0,original.length,t.headers.length);
  range.values=original;
  sheet.showGridLines=false;
  range.format.font={name:'Arial',size:10};
  range.format.verticalAlignment='center';
  range.format.rowHeight=32;
  sheet.getRangeByIndexes(0,0,1,t.headers.length).format={
    fill:'#334155',font:{name:'Arial',size:10,color:'#FFFFFF',bold:true},
    wrapText:true,horizontalAlignment:'center',rowHeight:58
  };
  for (let j=0;j<t.headers.length;j++) {
    const column=sheet.getRangeByIndexes(0,j,original.length,1);
    column.format.columnWidthPx=j<5?130:100;
    if (name!=='条件一覧'&&j>=5) {
      const body=sheet.getRangeByIndexes(1,j,t.rows.length,1);
      if (t.headers[j].includes('率')) body.setNumberFormat('0.00%');
      else if (t.headers[j]==='PF'||t.headers[j].includes('毎時')||t.headers[j].includes('間隔')) body.setNumberFormat('0.00');
      else body.setNumberFormat('#,##0');
    }
  }
  sheet.getRangeByIndexes(0,1,original.length,1).format.columnWidthPx=name==='条件一覧'?530:240;
  if (name==='条件一覧') {
    sheet.getRangeByIndexes(0,2,original.length,1).format.columnWidthPx=470;
    range.format.wrapText=true;
    range.format.rowHeight=45;
  }
  sheet.freezePanes.freezeRows(1);
  owners.push({name,t,original,sheet,range});
}
workbook.recalculate();
await fs.mkdir(output,{recursive:true});
const proof={成功:true,試行:172,入力SHA256:sha(bytes),元正本:data.inputs,node:process.version,
  出力器SHA256:sha(await fs.readFile(fileURLToPath(import.meta.url))),表:{}};
for (const {name,t,original,range} of owners) {
  const actual=range.values;
  assert.deepEqual(actual,original);
  assert.ok(range.formulas.flat().every(v=>v===''||v===null||v===undefined));
  const body='\uFEFF'+actual.map(r=>r.map(field).join(',')).join('\r\n')+'\r\n';
  await fs.writeFile(path.join(output,name+'.csv'),body,{encoding:'utf8',flag:'wx'});
  const shown=name==='条件一覧'?'A1:C12':'A1:N10';
  const inspected=await workbook.inspect({kind:'table',range:name+'!'+shown,
    include:'values,formulas',tableMaxRows:12,tableMaxCols:14,maxChars:1000});
  const preview=await workbook.render({sheetName:name,range:shown,scale:1,format:'png'});
  await fs.writeFile(path.join(here,name+'_表示確認.png'),new Uint8Array(await preview.arrayBuffer()),{flag:'wx'});
  proof.表[name]={データ行:t.rows.length,列:t.headers.length,全セル照合:actual.length*t.headers.length,
    SHA256:sha(body),inspect:inspected.ndjson};
}
const errors=await workbook.inspect({kind:'match',
  searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!',
  options:{useRegex:true,maxResults:10},maxChars:1000});
proof.エラー走査=errors.ndjson;
assert.equal(sha(await fs.readFile(input)),sha(bytes));
for (const ref of Object.values(data.inputs)) {
  assert.equal(sha(await fs.readFile(path.resolve(root,ref.path))),ref.sha256);
}
await fs.writeFile(path.join(here,'CSV作成確認.json'),JSON.stringify(proof,null,2)+'\n',{encoding:'utf8',flag:'wx'});
console.log(JSON.stringify({成功:true,表:proof.表}));
