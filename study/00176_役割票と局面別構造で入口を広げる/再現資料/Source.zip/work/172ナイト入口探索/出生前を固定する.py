"""新規自然出生と旧出生金融再集計の前に、条件と純特徴実装を固定する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / 'study/00172_デイを固定しナイト米国前後の複合入口を探索する'


def ref(path: Path) -> dict:
    """
    機能: 入力の位置・サイズ・SHA256を記録する。
    引数: path(Path)は固定対象。
    返り値: dictは指紋。
    """
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 金融結果を入力する前の新規規則と評価条件を束縛する。
    引数: なし。
    返り値: None。出生前F0票を保存する。
    """
    condition_path = TRIAL / '条件.json'
    condition = json.loads(condition_path.read_text(encoding='utf-8'))
    condition['night_fallback_horizon'] = '補完入口は171と同じ幅200/H60を固定。主入口だけが帯別幅・期限を持つ。'
    condition_path.write_text(json.dumps(condition, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    paths = [condition_path, Path(__file__),
        ROOT / 'work/172ナイト複合候補/rules172_night.py',
        ROOT / 'work/172ナイト複合候補/候補辞書.json',
        ROOT / 'work/172ナイト複合候補/人工検査.py',
        ROOT / 'work/172ナイト複合候補/人工検査.json',
        ROOT / 'work/172ナイト基礎診断/1460自然再集計前の固定.json',
        ROOT / 'work/172ナイト基礎診断/基礎診断.py',
        ROOT / 'work/172ナイト基礎診断/診断仕様.json']
    result = {'成功': True, '固定UTC': datetime.now(timezone.utc).isoformat(),
        '既閲覧': '171の固定取得と基礎診断、163/164等の旧結果は既使用。172新768自然出生・旧1460の新帯別screenはまだ実行していない。',
        '手順': '純特徴768出生を固定してから共用金融表を結ぶ。旧1460は固定出生を再集計。両者を同じ新規候補と偽らない。',
        '条件': condition, '固定対象': [ref(p) for p in paths]}
    target = TRIAL / '検査/出生前F0.json'
    assert not target.exists()
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'F0': ref(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
