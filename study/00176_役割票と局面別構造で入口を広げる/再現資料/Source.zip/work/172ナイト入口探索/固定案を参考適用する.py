"""旧73で固定した最大五組だけを追加七場へ純出生封印後に参考適用する。"""
from pathlib import Path
from types import SimpleNamespace
from datetime import datetime, timezone
import argparse
import json
import numpy as np
import 再生172 as R
import 数量比較する as Q

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00172_デイを固定しナイト米国前後の複合入口を探索する'


def pack(context: object, value: tuple) -> dict:
    """
    機能: 後から金融・数量を独立確認できる取得属性を小さく保存する。
    引数: context(GenericContext)、value(tuple)は数量再生結果。
    返り値: dictは取得位置・側・幅・期限・出生・補完階層と全監査。
    """
    selected, origin, wi, hi, tier, result = value
    return {'cases': selected.cases.tolist(), 'sides': selected.sides.tolist(), 'events': selected.events.tolist(),
        'phases': selected.phases.tolist(), 'origins': origin.tolist(), 'widths': wi.tolist(),
        'horizons': hi.tolist(), 'tiers': tier.tolist(), 'engine': result}


def run(context: object, base: dict, choices: list, directions: dict, name: str) -> dict:
    """
    機能: 基準と最大五組を同じ取得母集団で再生し、全場明細を保存する。
    引数: context(GenericContext)、base(dict)、choices(list[dict])、directions(dict)、name(str)。
    返り値: dictは全政策の報告。正式ViewerやCSVはこの小型参照から生成する。
    """
    baseline_choice = {'id': 'BASE171', 'PRE': None, 'POST': None}
    baseline = R.replay(context, base, baseline_choice, {})
    rows, refs = [], []
    for choice in [baseline_choice, *choices]:
        value = baseline if choice['id'] == 'BASE171' else R.replay(context, base, choice, directions)
        Q.day_guard(value[-1], baseline[-1], context)
        rows.append({'id': choice['id'], 'candidate': choice, 'cap10': R.describe(context, value, details=True)})
        refs.append({'id': choice['id'], **pack(context, value)})
    result = {'成功': True, '場数': len(context.scenes), '場順': context.sessions,
        '全固定政策デイ同体': True, 'rows': rows}
    R.save(HERE / f'{name}の固定比較.json.gz', result)
    R.save(HERE / f'{name}の全取得.json.gz', {'成功': True, 'rows': refs})
    return result


def main() -> None:
    """
    機能: 旧73同体を確認し、追加七場の純出生を先に封印してから金融を読む。
    引数: --fixed(Path)は最大五組の固定票。
    返り値: None。旧73/追加7の詳細と金融前F4を保存する。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--fixed', type=Path, required=True)
    args = parser.parse_args()
    fixed_path = args.fixed.resolve()
    fixed = R.read(fixed_path)
    choices = fixed['candidates']
    assert 1 <= len(choices) <= 5 and len({r['id'] for r in choices}) == len(choices)
    options = list({r[band]['key']: r[band] for r in choices for band in ('PRE', 'POST')
        if r[band] is not None}.values())
    builder_path = HERE / '選定政策の出生.py'
    builder = R.module(builder_path, 'selected_birth172')
    source_paths = [Path(__file__), HERE / '再生172.py', HERE / '数量比較する.py', builder_path, fixed_path]
    before = {p.relative_to(ROOT).as_posix(): R.sha(p) for p in source_paths}
    R.save(TRIAL / '検査/追加参考前F3.json', {'成功': True, 'UTC': datetime.now(timezone.utc).isoformat(),
        'Sourceと固定案': before, '追加7の今回候補結果未読': True, '政策数': len(choices),
        '位置づけ': '既使用の参考期間。新たな独立未見ではない。'})
    # ----------------------------------------
    original = R.R168.BASE.Context165()
    old_context = R.R168.BASE.GenericContext(original.features, original.table, original.capture_rows)
    old_dirs = builder.build(old_context.features, options)
    cells = 0
    with np.load(HERE / '短表の純出生.npz', allow_pickle=False) as sealed:
        for key, array in old_dirs.items():
            assert np.array_equal(array, sealed[key]), key
            cells += array.size
    R.save(HERE / '選定出生の旧73同体.json', {'成功': True, '全方向一致セル': cells, '政策key数': len(options),
        'SourceSHA256': R.sha(builder_path), '選択票SHA256': R.sha(fixed_path)})
    old_base, _, _ = R.baseline(old_context)
    old_report = run(old_context, old_base, choices, old_dirs, '旧73')
    previous = {r['id']: r for r in R.read(HERE / '旧73数量比較.json.gz')['rows']}
    for row in old_report['rows']:
        assert row['cap10']['periods'] == previous[row['id']]['cap10']['periods']
        assert row['cap10']['quantity'] == previous[row['id']]['cap10']['quantity']
    # ----------------------------------------
    base_dir = ROOT / 'inputs/00167_追加七場の入口と共用価格索引'
    features, captures, inputs = R.R168.BASE.load_features(base_dir / '入口母集団')
    new_dirs = builder.build(features, options)
    feature_context = SimpleNamespace(features=features)
    new_base, _, _ = R.baseline(feature_context)
    born_path = HERE / '追加7の固定純出生.npz'
    assert not born_path.exists()
    np.savez_compressed(born_path, **new_dirs, **{'BASE__'+k: v for k, v in new_base.items() if isinstance(v, np.ndarray)})
    R.save(TRIAL / '検査/追加金融前F4.json', {'成功': True, 'UTC': datetime.now(timezone.utc).isoformat(),
        'Sourceと固定案': before, '非金融入力': inputs, '金融未入力': True,
        '出生SHA256': R.sha(born_path), '出生bytes': born_path.stat().st_size,
        '旧73全方向同体セル': cells, '新q0数': len(features.q0_meta)})
    assert all(R.sha(ROOT / path) == digest for path, digest in before.items())
    # ----------------------------------------
    adapter = R.module(ROOT / 'work/166可変場の数値化/arrays166.py', 'arrays166_for172')
    numeric_proof = R.read(base_dir / '生成の完了.json')
    table = adapter.load_table(base_dir / '自然数値表', numeric_proof['cache'])
    context = R.R168.BASE.GenericContext(features, table, captures)
    new_report = run(context, new_base, choices, new_dirs, '追加7')
    from 基準を確認する import check
    baseline_check = check(context, '追加7固定候補')
    R.save(HERE / '追加7の171基準同体.json', baseline_check)
    assert all(R.sha(ROOT / path) == digest for path, digest in before.items())
    R.save(HERE / '固定案の参考適用完了.json', {'成功': True, 'Sourceと固定案': before,
        '全固定案デイ同体': True, '旧73全方向同体セル': cells,
        '保存結果': {p.name: {'bytes': p.stat().st_size, 'sha256': R.sha(p)} for p in HERE.iterdir()
            if p.name in ('旧73の固定比較.json.gz', '旧73の全取得.json.gz', '追加7の固定比較.json.gz',
                          '追加7の全取得.json.gz', '追加7の固定純出生.npz')}})
    print(json.dumps({'成功': True, '固定政策数': len(choices), '旧73全方向一致セル': cells,
        '追加7': [{'id': r['id'], 'PRE': r['cap10']['periods']['全期']['PRE']['全部'],
                  'POST': r['cap10']['periods']['全期']['POST']['全部']} for r in new_report['rows']]}, ensure_ascii=False))


if __name__ == '__main__':
    main()
