"""主案を交換せず、前半枠修正と事後安定性対照を最大五組へ束縛する。"""
from pathlib import Path
from datetime import datetime, timezone
import json
import 再生172 as R
from 補正選択 import select

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00172_デイを固定しナイト米国前後の複合入口を探索する'


def main() -> None:
    """
    機能: 旧73だけで選んだ五組を、今回の追加7金融比較前に固定する。
    引数: なし。441数量表と別票の事後安定性対照を読む。
    返り値: None。F3b及び適用五組の固定票を保存する。
    """
    source = HERE / '旧73数量比較.json.gz'
    rows = R.read(source)['rows']
    result = select(rows)
    prior = R.read(HERE / '旧73の固定選択.json')
    assert result['主案'] == prior['主案'] and result['前48固定'] == prior['前48固定']
    stable_path = ROOT / 'work/172ナイト基礎診断/追加安定一組の固定.json'
    stable = R.read(stable_path)
    stable_id = stable['選択']['id']
    ids = [*result['参考適用ID']]
    if stable_id not in ids:
        assert len(ids) < 5
        ids.append(stable_id)
    result['当初補正ID'] = result['参考適用ID']
    result['参考適用ID'] = ids
    result['事後安定性追加'] = stable_id
    result['追加の出生'] = '441旧73結果を見て前後4セルの支持を診断し、既存条件から1組を後選。新規入口条件を追加せず、主案は交換しない。'
    result['candidates'] = [r['candidate'] for identity in ids for r in rows if r['id'] == identity]
    result['UTC'] = datetime.now(timezone.utc).isoformat()
    paths = [Path(__file__), HERE / '補正選択.py', source, stable_path,
        ROOT / 'work/172ナイト数量再生/補正選択の人工確認.json']
    result['Sourceと選択根拠'] = {p.relative_to(ROOT).as_posix(): R.sha(p) for p in paths}
    target = HERE / '適用五組の固定.json'
    assert not target.exists() and not (HERE / '追加7の固定比較.json.gz').exists()
    R.save(target, result)
    R.save(TRIAL / '検査/適用案固定F3b.json', {'成功': True, 'UTC': result['UTC'],
        '主案': result['主案'], '最大五組ID': ids, '今回の新7当該候補結果未読': True,
        '固定票SHA256': R.sha(target), 'Sourceと選択根拠': result['Sourceと選択根拠'],
        '修正': '旧selectは一般の人工例で前48枠が落ち得たため予約を修正。今回の旧4組は同じで順序だけ変更。追加安定性対照は事後選択と分ける。'})
    print(json.dumps({'成功': True, '主案': result['主案'], '固定ID': ids, '事後追加': stable_id}, ensure_ascii=False))


if __name__ == '__main__':
    main()
