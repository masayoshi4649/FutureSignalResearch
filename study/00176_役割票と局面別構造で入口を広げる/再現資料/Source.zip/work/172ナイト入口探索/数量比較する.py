"""事前の帯別短表を全組み合わせし、デイ固定・夜間の数量枠を再生する。"""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
from itertools import product
from datetime import datetime, timezone
import argparse
import json
import time
import numpy as np
import 再生172 as R

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00172_デイを固定しナイト米国前後の複合入口を探索する'
CTX = BASE = CAPTURES = DIRS = BASE_RESULT = None


def prepare(shortlist_path: Path) -> list:
    """
    機能: 固定短表にある純出生だけを抜き、米国前後の置換政策を列挙する。
    引数: shortlist_path(Path)はSource固定済みselectorの結果。
    返り値: list[dict]は171対照、片帯置換、両帯置換の全組合せ。
    """
    selector = R.module(ROOT / 'work/172ナイト基礎診断/selector172.py', 'selector172_stage2')
    short = selector.stage2_rows(R.read(shortlist_path))
    options = {r['key']: r for band in ('PRE', 'POST') for r in short[band]}
    directions = {}
    for key, row in options.items():
        if row['source'] == 'OLD1460':
            path = ROOT / 'work/163入口と任意幅/全出生' / f"出生{row['width']}.npz"
        else:
            assert row['source'] == 'NEW768'
            path = ROOT / 'work/172ナイト複合候補/全出生/新768の出生.npz'
        with np.load(path, allow_pickle=False) as source:
            directions[key] = source[row['entry_mode']][row['rule_index']].copy()
        if row['orientation'] == 'REVERSE':
            directions[key] *= -1
    np.savez_compressed(HERE / '短表の純出生.npz', **directions)
    choices = [{'id': 'BASE171', 'PRE': None, 'POST': None}]
    for band in ('PRE', 'POST'):
        for i, row in enumerate(short[band]):
            choices.append({'id': f'{band}{i+1:02}', 'PRE': row if band == 'PRE' else None,
                'POST': row if band == 'POST' else None})
    for i, pre in enumerate(short['PRE']):
        for j, post in enumerate(short['POST']):
            choices.append({'id': f'B{i+1:02}_{j+1:02}', 'PRE': pre, 'POST': post})
    R.save(HERE / '数量政策.json', {'成功': True, '短表': {'path': str(shortlist_path.relative_to(ROOT)),
        'sha256': R.sha(shortlist_path)}, 'candidates': choices})
    return choices


def initialize() -> None:
    """
    機能: workerごとに旧73の共用金融と固定済み少数出生を一度読み込む。
    引数: なし。
    返り値: None。追加7は開かない。
    """
    global CTX, BASE, CAPTURES, DIRS, BASE_RESULT
    original = R.R168.BASE.Context165()
    CTX = R.R168.BASE.GenericContext(original.features, original.table, original.capture_rows)
    BASE, _, _ = R.baseline(CTX)
    CAPTURES = R.R168.capture_descriptors(CTX)
    with np.load(HERE / '短表の純出生.npz', allow_pickle=False) as source:
        DIRS = {key: source[key].copy() for key in source.files}
    BASE_RESULT = R.replay(CTX, BASE, {'id': 'BASE171', 'PRE': None, 'POST': None}, {}, CAPTURES)[-1]


def day_guard(result: dict, expected: dict, context: object) -> None:
    """
    機能: 全数量政策でデイの取得・要求・数量予約を固定対照へ照合する。
    引数: result/expected(dict)はengine結果、context(GenericContext)。
    返り値: None。差分があれば中断する。
    """
    for field in ('records', 'requests'):
        assert [r for r in result[field] if context.event_phases[r['event']] == 0] == \
            [r for r in expected[field] if context.event_phases[r['event']] == 0], ('デイ', field)
    day_scenes = np.flatnonzero(context.hours[:, 0] > 0)
    assert [result['audits'][i] for i in day_scenes] == [expected['audits'][i] for i in day_scenes]


def evaluate(choice: dict) -> dict:
    """
    機能: 旧73一政策を数量再生し、夜間帯ごとの主/補完・前後を保存可能にする。
    引数: choice(dict)は幅と期限を含む二帯政策。
    返り値: dictは政策と統計。全取得の大量複製はしない。
    """
    value = R.replay(CTX, BASE, choice, DIRS, CAPTURES)
    day_guard(value[-1], BASE_RESULT, CTX)
    return {'id': choice['id'], 'candidate': choice, 'デイ同体': True, 'cap10': R.describe(CTX, value)}


def supported(stats: dict, front: bool = False) -> bool:
    """
    機能: 短表と同じ支持を数量再生後にも確認する。
    引数: stats(dict)、front(bool)は前48だけの支持か。
    返り値: boolは支持・未知・損益が基準を満たすか。
    """
    count, resolved = stats['count'], stats['F'] + stats['A']
    return count >= (25 if front else 40) and resolved >= (15 if front else 25) \
        and stats['scenes'] >= (6 if front else 10) and stats['C'] <= .1 * count \
        and stats['profit'] > 0 and stats['profit'] >= 1.1 * stats['loss'] \
        and (front or (stats['max_scene_share'] or 1) <= .25)


def select(rows: list) -> dict:
    """
    機能: 追加7を開く前に主案・近傍・前半選択を最大5組へ固定する。
    引数: rows(list[dict])は旧73だけの全数量統計。
    返り値: dictは主案nullableと参考適用する固定ID。全期発見を未見と呼ばない。
    """
    selector = R.module(ROOT / 'work/172ナイト基礎診断/selector172.py', 'selector172_choices')

    def score(row: dict, period: str = '全期') -> tuple:
        """
        機能: 二帯の弱い方のWilson下限、頻度、政策IDで順位を固定する。
        引数: row(dict)、period(str)。
        返り値: tupleは昇順ソート用。
        """
        bands = row['cap10']['periods'][period]
        lower = [selector.wilson_lower(bands[b]['全部']['F'], bands[b]['全部']['A']) for b in ('PRE', 'POST')]
        return (-min(lower), -bands['NIGHT']['全部']['per_hour'], row['id'])

    both = [r for r in rows if r['candidate']['PRE'] is not None and r['candidate']['POST'] is not None]
    full = [r for r in both if all(supported(r['cap10']['periods']['全期'][b]['全部']) and
        (r['cap10']['periods']['全期'][b]['全部']['rate'] or 0) >= .7 for b in ('PRE', 'POST'))]
    full.sort(key=score)
    near = [r for r in both if all(supported(r['cap10']['periods']['全期'][b]['全部']) and
        (r['cap10']['periods']['全期'][b]['全部']['rate'] or 0) >= .65 for b in ('PRE', 'POST'))]
    near.sort(key=score)
    front = [r for r in both if all(supported(r['cap10']['periods']['前48場'][b]['全部'], True) and
        (r['cap10']['periods']['前48場'][b]['全部']['rate'] or 0) >= .65 for b in ('PRE', 'POST'))]
    front.sort(key=lambda r: score(r, '前48場'))
    primary = full[0]['id'] if full else None
    wanted = ([primary] if primary else []) + [r['id'] for r in full[:2]] \
        + [r['id'] for r in near[:3]] + ([front[0]['id']] if front else [])
    ids = list(dict.fromkeys(wanted))[:5]
    return {'成功': True, '主案': primary, '両帯支持70以上数': len(full), '両帯支持65以上数': len(near),
        '前48支持65以上数': len(front), '前48固定': front[0]['id'] if front else None,
        '参考適用ID': ids, '採否': '両帯の全部取得で支持・先着70以上を主案。追加7はこの固定最大5組だけ。',
        '注意': '全80は既使用。前48政策は本選択関数だけで前48を用いるが、上流shortlistには全期選択も含むため完全な過去だけの探索とは呼ばない。'}


def main() -> None:
    """
    機能: 帯別短表を封印し、旧73全組合せを数量再生して最大5組を固定する。
    引数: --shortlist(str)、--workers(int)は入力と並列数。
    返り値: None。正式F2、数量統計、旧73選択を保存する。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--shortlist', type=Path, required=True)
    parser.add_argument('--workers', type=int, default=4)
    args = parser.parse_args()
    args.shortlist = args.shortlist.resolve()
    target = HERE / '旧73数量比較.json.gz'
    assert not target.exists()
    candidates = prepare(args.shortlist)
    paths = [Path(__file__), HERE / '再生172.py', HERE / '数量政策.json', HERE / '短表の純出生.npz',
        ROOT / 'work/172ナイト数量再生/engine172.py', args.shortlist]
    before = {p.relative_to(ROOT).as_posix(): R.sha(p) for p in paths}
    R.save(TRIAL / '検査/数量比較前F2.json', {'成功': True, 'UTC': datetime.now(timezone.utc).isoformat(),
        'Sourceと入力': before, '政策数': len(candidates), '追加7候補金融未読': True})
    start = time.monotonic()
    rows = []
    with ProcessPoolExecutor(max_workers=args.workers, initializer=initialize) as executor:
        for row in executor.map(evaluate, candidates, chunksize=4):
            rows.append(row)
            if len(rows) % 40 == 0:
                print(json.dumps({'数量再生': len(rows), '全政策': len(candidates),
                    '経過秒': round(time.monotonic()-start, 1)}, ensure_ascii=False), flush=True)
    R.save(target, {'成功': True, '場数': 73, 'rows': rows, '全政策デイ同体': True,
        'Sourceと入力': before, '経過秒': time.monotonic()-start})
    fixed = select(rows)
    fixed['数量統計SHA256'] = R.sha(target)
    fixed['candidates'] = [r['candidate'] for r in rows if r['id'] in fixed['参考適用ID']]
    R.save(HERE / '旧73の固定選択.json', fixed)
    assert all(R.sha(ROOT / p) == digest for p, digest in before.items())
    print(json.dumps(fixed, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
