"""Rootの最終GO後に、173継承Sourceと174小型正本・CSV参照を正式保存する。"""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import argparse
import hashlib
import json
import os
import tempfile
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00174_共同条件を残して単一建玉の入口を広げる'
PARENT = ROOT / 'study/00173_追加建てを禁止し両中央値で入口を再探索する/再現資料'
DESTINATION = TRIAL / '再現資料'
CSV_DIRECTORY = ROOT / 'outputs/00174_追加禁止と両中央値の比較'
POLICIES = {'全期_J002', '全期_J003', '前48_J000', '前48_J001'}
RESULT_SUFFIXES = {'.json', '.gz', '.npz', '.md'}


def fingerprint(path: Path) -> dict:
    """
    機能: 共有入力を複製せず物理指紋を計算する。
    引数: path(Path)はリポジトリ内のファイル。
    返り値: dictはrepo相対path/bytes/sha256。
    """
    path = path.resolve()
    assert path.is_relative_to(ROOT)
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest}


def byte_reference(name: str, body: bytes) -> dict:
    """
    機能: 物理保存先を持たない継承memberの元byte指紋を作る。
    引数: name(str)はrepo相対member名、body(bytes)は元内容。
    返り値: dictはpath/bytes/sha256。
    """
    validate_member(name)
    return {'path': name, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}


def validate_member(name: str) -> None:
    """
    機能: ZIPの名前がrepo相対の安全な形式であることを確認する。
    引数: name(str)はmember名。
    返り値: None。絶対名・親移動・Windows区切り・ドライブ指定を拒否する。
    """
    path = PurePosixPath(name)
    assert name and '\\' not in name and ':' not in name
    assert not path.is_absolute() and '..' not in path.parts and name == path.as_posix()


def read_json(path: Path) -> dict:
    """
    機能: 小型の標準JSONを読む。
    引数: path(Path)はJSONパス。
    返り値: dictは解析値。
    """
    return json.loads(path.read_text(encoding='utf-8-sig'))


def work_directories() -> list[Path]:
    """
    機能: 174用作業フォルダだけを列挙する。
    引数: なし。
    返り値: list[Path]は名前が174で始まるwork直下フォルダ。
    """
    return sorted(path for path in (ROOT / 'work').glob('174*') if path.is_dir())


def task_files(directory: Path):
    """
    機能: 依存package・cache・隔離repoを辿らず174自身のファイルだけを列挙する。
    引数: directory(Path)は174workフォルダ。
    返り値: generator[Path]は収録候補。node_modulesの巨大な複製を作らない。
    """
    for current, directories, files in os.walk(directory, followlinks=False):
        directories[:] = [name for name in directories if name not in
            ('node_modules', '__pycache__', '.git', '.venv', 'venv', '.pnpm', 'repo')]
        for name in files:
            yield Path(current)/name


def inherited_sources() -> tuple[dict, dict[str, bytes]]:
    """
    機能: 173正式Sourceの174memberを正式索引と全CRC/SHAへ照合し元byteで受け取る。
    引数: なし。現在の旧work Sourceは参照しない。
    返り値: tuple[dict,dict]は継承元ZIP/索引/member指紋とmember元byte辞書。
    """
    archive_path, index_path = PARENT/'Source.zip', PARENT/'保存索引.json'
    index = read_json(index_path)
    assert fingerprint(archive_path) == index['Source']['archive']
    expected = {r['path']: r for r in index['Source']['members']}
    assert len(expected) == 174
    contents = {}
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        names = archive.namelist()
        assert len(names) == len(set(names)) == 174 and set(names) == set(expected)
        for name in names:
            body = archive.read(name)
            assert byte_reference(name, body) == expected[name], name
            contents[name] = body
    return {'archive': fingerprint(archive_path), 'index': fingerprint(index_path),
        'members': [expected[name] for name in sorted(expected)], 'member_count': 174,
        '継承': '173の正式ZIP内元byteを継承。旧workの現在値へ置き換えない。'}, contents


def inherited_small_inputs() -> tuple[list[dict], dict[str, bytes]]:
    """
    機能: 固定4と比較CSVの再現に必要な旧小入力だけを正式ZIPから元byteで継承する。
    引数: なし。172の171seal、173のLOCAL Catalogと全80ledgerを対象にする。
    返り値: tuple[list[dict],dict]は継承元と小member元byte。旧小正本全体を重複保存しない。
    """
    dependencies = {
        ROOT/'study/00172_デイを固定しナイト米国前後の複合入口を探索する/再現資料':
            ['work/171三帯の入口切替/旧73探索/主案と前半A-Bの封印.json'],
        PARENT: ['work/173局所技術の主入口/SourceCatalog.json', 'work/173追加七場適用/全80の両中央値173.json.gz']}
    contents, records = {}, []
    for folder, names in dependencies.items():
        source = folder/'出生と比較正本.zip'
        index_path = folder/'保存索引.json'
        index = read_json(index_path)
        assert fingerprint(source) == index['正本']['archive']
        expected = {r['path']: r for r in index['正本']['members']}
        members = []
        with zipfile.ZipFile(source) as archive:
            assert archive.testzip() is None
            for name in names:
                body = archive.read(name)
                assert byte_reference(name, body) == expected[name], name
                assert name not in contents
                contents[name] = body
                members.append(expected[name])
        records.append({'archive': fingerprint(source), 'index': fingerprint(index_path), 'members': members})
    return records, contents


def collect_sources() -> list[Path]:
    """
    機能: 174の新規Python/JavaScript Sourceを修正前保存分も含め列挙する。
    引数: なし。
    返り値: list[Path]は.py/.mjsの重複のないパス。
    """
    paths = [p for directory in work_directories() for p in task_files(directory)
        if p.is_file() and p.suffix in ('.py', '.mjs')]
    assert ROOT/'work/174参加と両中央値の再探索/正式入力で再現する.py' in paths
    assert Path(__file__) in paths
    return sorted(set(paths))


def omission_reason(path: Path) -> str | None:
    """
    機能: 小正本へ重複保存しない大きいscreen統計を判別する。
    引数: path(Path)は174work内候補。
    返り値: str|Noneは除外理由又は収録許可。
    """
    relative = path.relative_to(ROOT).as_posix()
    if path.is_relative_to(HERE):
        return '保存器の計画・実行出力は自己参照を避け、正式索引側へ記録する'
    if path.suffix == '.npz' and ('screen' in relative or path.name == '統計配列.npz'):
        return '再生成可能な大きい予備screen統計NPZ。軸・pool・Source・入力指紋を保持する'
    return None


def collect_results() -> tuple[list[Path], list[dict]]:
    """
    機能: 全段結果・短表・小出生・catalog・独立結果・固定票を選び大きい中間を除く。
    引数: なし。旧原板・共有金融・feature cacheは探索対象にしない。
    返り値: tuple[list[Path],list[dict]]は収録候補と除外ファイルの理由・物理指紋。
    """
    paths, omitted = [], []
    for directory in work_directories():
        if directory == HERE:
            continue
        for path in task_files(directory):
            if not path.is_file() or path.suffix not in RESULT_SUFFIXES:
                continue
            reason = omission_reason(path)
            if reason:
                omitted.append({'file': fingerprint(path), '理由': reason})
            else:
                assert path.stat().st_size < 16*1024*1024, '小正本の想定を超える入力: '+str(path)
                paths.append(path)
    for path in TRIAL.rglob('*.json'):
        if not path.is_relative_to(DESTINATION):
            paths.append(path)
    return sorted(set(paths)), sorted(omitted, key=lambda r: r['file']['path'])


def completion_gates(extra_required: list[Path]) -> dict:
    """
    機能: 最終GO時に固定四政策・全段正本・独立全80・CSV独立一致を確認する。
    引数: extra_required(list[Path])はRootが追加指定する必須ファイル。
    返り値: dictは必須入力指紋と成功検査。未完ならZIPを作る前に停止する。
    """
    required = [TRIAL/'条件.json',
        ROOT/'work/174参加と両中央値の再探索/正式入力で再現する.py',
        *[ROOT/'work/174参加と両中央値の再探索'/name for name in ('単独global1.json.gz', '異技術ORglobal1.json.gz',
            'Night接合global1.json.gz', '三帯接合global1.json.gz', '単独global1の短表.json', '帯ごとの数量短表.json',
            'Night接合の短表.json', '旧73jointの固定選択.json', '短表の純出生173.npz')],
        *[ROOT/'work/174追加七場適用'/name for name in ('金融前の出生固定.json', '旧73の全取得174.json.gz',
            '追加7の全取得174.json.gz', '全80の両中央値174.json.gz', '完了.json')],
        ROOT/'work/174参加と両中央値の選択/自然選択/選択後の不変と併合確認.json',
        ROOT/'work/174自然結果の独立検査/旧73独立結果174.json',
        ROOT/'work/174自然結果の独立検査/追加7と全80の独立結果174.json',
        ROOT/'work/174自然結果の独立検査/CSV独立検算.json',
        ROOT/'work/174参加と両中央値の再探索/CSVの型付き入力.json',
        ROOT/'work/174参加と両中央値の再探索/CSV作成確認.json',
        ROOT/'work/174参加と両中央値の再探索/CSV表示確認.json', *extra_required]
    assert all(path.is_file() for path in required), [str(p) for p in required if not p.is_file()]
    selected = read_json(ROOT/'work/174参加と両中央値の再探索/旧73jointの固定選択.json')
    ids = {p['id'] for route in selected['選択'].values() for p in route['candidates']}
    assert ids == POLICIES and selected['成功']
    for path in (ROOT/'work/174追加七場適用/完了.json',):
        assert read_json(path)['成功'] is True
    assert read_json(ROOT/'work/174参加と両中央値の選択/自然選択/選択後の不変と併合確認.json')['成功'] is True
    for name, scene_count in (('旧73独立結果174.json', 73), ('追加7と全80の独立結果174.json', 80)):
        value = read_json(ROOT/'work/174自然結果の独立検査'/name)
        assert value['結果'] == '全検査成功' and value['検査前後Source一致'] is True
        assert value['全場数'] == scene_count and set(value['対象']) == POLICIES
        assert len(value['policies']) == 4
        for policy in value['policies']:
            if scene_count == 73:
                assert policy['占有違反'] == 0 and policy['財務照合大項目数'] > 0
                assert len(policy['要求SHA256']) == len(policy['取得SHA256']) == 64
            else:
                assert policy['追加7独立再生一致'] is True and policy['全80財務一致'] is True
                assert policy['枠占有違反'] == 0
    csv_proof = read_json(ROOT/'work/174参加と両中央値の再探索/CSV作成確認.json')
    csv_input = ROOT/'work/174参加と両中央値の再探索/CSVの型付き入力.json'
    assert csv_proof['成功'] is True and csv_proof['試行'] == 174
    assert fingerprint(csv_input)['sha256'] == csv_proof['入力SHA256']
    csv_display = read_json(ROOT/'work/174参加と両中央値の再探索/CSV表示確認.json')
    assert csv_display['成功'] is True and csv_display['入力SHA256'] == csv_proof['入力SHA256']
    current_writer = fingerprint(ROOT/'work/174参加と両中央値の再探索/CSVへ出力する.mjs')['sha256']
    assert current_writer == csv_display['出力器SHA256']
    assert len(csv_proof['表']) == 4
    assert set(csv_display['表']) == set(csv_proof['表'])
    assert {p.stem for p in CSV_DIRECTORY.glob('*.csv')} == set(csv_proof['表'])
    for name, table in csv_proof['表'].items():
        assert all(table[k] == csv_display['表'][name][k] for k in ('SHA256', 'データ行', '列', '全セル照合'))
        assert fingerprint(CSV_DIRECTORY/(name+'.csv'))['sha256'] == table['SHA256']
    csv_independent = read_json(ROOT/'work/174自然結果の独立検査/CSV独立検算.json')
    assert csv_independent['結果'] == '全検査成功' and csv_independent['全セル一致'] is True
    assert csv_independent['検査セル数'] > 0 and len(csv_independent['ファイル指紋']) == 4
    for ref in csv_independent['ファイル指紋']:
        assert fingerprint(ROOT/ref['path']) == ref
    return {'成功': True, '固定参考政策': sorted(ids), '独立73と全80成功': True,
        'CSV全セル独立一致': True, '正式CSV': [fingerprint(p) for p in sorted(CSV_DIRECTORY.glob('*.csv'))],
        'CSV出力器の由来': {'CSV作成時SourceSHA256': csv_proof['出力器SHA256'],
            '表示専用実行の現SourceSHA256': current_writer, '四CSVと型付き入力は両票同一': True},
        '必須': [fingerprint(p) for p in sorted(set(required))]}


def write_archive(path: Path, contents: dict[str, bytes]) -> dict:
    """
    機能: 受け取った元byteだけを新規ZIPへ保存し全CRC・全member指紋を照合する。
    引数: path(Path)は未作成ZIP、contents(dict[str,bytes])はmember元byte。
    返り値: dictはarchive物理指紋と全member指紋。
    """
    assert not path.exists() and len(contents) == len(set(contents))
    with zipfile.ZipFile(path, 'x') as archive:
        for name, body in sorted(contents.items()):
            validate_member(name)
            compress = zipfile.ZIP_STORED if PurePosixPath(name).suffix in ('.npz', '.gz', '.zip') else zipfile.ZIP_DEFLATED
            archive.writestr(name, body, compress_type=compress)
    members = [byte_reference(name, body) for name, body in sorted(contents.items())]
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None and set(archive.namelist()) == set(contents)
        for expected in members:
            assert byte_reference(expected['path'], archive.read(expected['path'])) == expected
    return {'archive': fingerprint(path), 'members': members}


def execute(extra_required: list[Path]) -> dict:
    """
    機能: Rootの明示GO後に174のSource・小正本・保存索引を正式先へ新規保存する。
    引数: extra_required(list[Path])は追加の完了必須入力。
    返り値: dictは正式保存索引。文書・条件・売買Source・既存成果物を編集しない。
    """
    targets = [DESTINATION/name for name in ('Source.zip', '出生と比較正本.zip', '保存索引.json')]
    assert not any(path.exists() for path in targets), '正式保存先に既存物があるため上書きしない'
    gates = completion_gates(extra_required)
    inherited, source_contents = inherited_sources()
    small_inputs, small_contents = inherited_small_inputs()
    source_paths = collect_sources()
    result_paths, omitted = collect_results()
    before = {p.relative_to(ROOT).as_posix(): fingerprint(p) for p in source_paths+result_paths}
    for path in source_paths:
        name = path.relative_to(ROOT).as_posix()
        assert name not in source_contents
        source_contents[name] = path.read_bytes()
    results = {path.relative_to(ROOT).as_posix(): path.read_bytes() for path in result_paths}
    assert not (set(results) & set(small_contents))
    results.update(small_contents)
    DESTINATION.mkdir(parents=True, exist_ok=True)
    # ----------------------------------------
    # 検査済み一時ZIPだけを最終名へ置く。元入力やpartial結果は移動・削除しない。
    with tempfile.TemporaryDirectory(prefix='保存一時_', dir=HERE) as temporary:
        temporary = Path(temporary).resolve()
        assert temporary.is_relative_to(HERE)
        source = write_archive(temporary/'Source.zip', source_contents)
        canonical = write_archive(temporary/'出生と比較正本.zip', results)
        for name, expected in before.items():
            assert fingerprint(ROOT/name) == expected, name
        assert fingerprint(PARENT/'Source.zip') == inherited['archive']
        (temporary/'Source.zip').replace(targets[0])
        (temporary/'出生と比較正本.zip').replace(targets[1])
    source['archive'] = fingerprint(targets[0])
    canonical['archive'] = fingerprint(targets[1])
    index = {'成功': True, '保存UTC': datetime.now(timezone.utc).isoformat(),
        '保存Source': fingerprint(Path(__file__)), '条件': fingerprint(TRIAL/'条件.json'),
        'Source': source, '正本': canonical, 'Source継承元': inherited, '正本継承小入力': small_inputs,
        '174新Source': [fingerprint(p) for p in source_paths], '完了gate': gates, 'CSV': gates['正式CSV'],
        '省略中間指紋': omitted,
        '保存範囲': '174全段stage・短表・小出生・F0/F2・固定4取得pack/全80・人工独立検査・CSV型付き入力と作成票。必要小入力は旧正式ZIPから継承。',
        '収録対象外': 'node_modules・仮想環境・cache・隔離repoは走査しない。PNG/CSV本文はZIPへ重複保存しない。',
        '共用入力': {'旧73金融': 'inputs/00163_任意幅の共用価格索引/数値表',
            '追加7非金融と金融': 'inputs/00167_追加七場の入口と共用価格索引',
            '旧特徴と取得対応': 'inputs/00148_全1分入口母集団',
            '方針': '旧原板・金融配列・feature cacheは複製しない。大きい予備統計は再生成中間として軸と物理指紋だけを保存する。'},
        '注意': '全80既使用、固定参考四案。保存処理では政策・出生・金融額・中央値・採否を変更しない。CSVや画像は本ZIPへ重複保存しない。'}
    targets[2].write_text(json.dumps(index, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    assert read_json(targets[2]) == index
    return index


def main() -> None:
    """
    機能: 明示execute/goの両方がある時だけ最終archiveを作る。
    引数: --execute/--go(bool)はRoot最終指示、--require(Path,反復可)は追加必須ファイル。
    返り値: None。引数なしではSource準備状態の説明だけを返す。
    """
    parser = argparse.ArgumentParser(description='174正式保存。Root最終GO前には実行しない。')
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--go', action='store_true')
    parser.add_argument('--require', type=Path, action='append', default=[])
    args = parser.parse_args()
    if not (args.execute and args.go):
        assert not args.execute and not args.go
        print(json.dumps({'準備済み': True, '正式archive未作成': True,
            '実行': 'Root最終GO後に --execute --go を両方指定する'}, ensure_ascii=False))
        return
    extra = [(p if p.is_absolute() else ROOT/p).resolve() for p in args.require]
    index = execute(extra)
    print(json.dumps({'成功': True, 'Source': index['Source']['archive'], '正本': index['正本']['archive'],
        '173継承member': len(index['Source継承元']['members']), 'Source数': len(index['Source']['members']),
        '正本数': len(index['正本']['members'])}, ensure_ascii=False))


if __name__ == '__main__':
    main()
