"""自然値を読む前に定めた173用の純短表選択器。金融計算や注文再生は行わない。"""

from __future__ import annotations

import hashlib
import json
import math
from collections import Counter
from collections.abc import Iterable


仕様 = {
    "版": "173事前短表案1",
    "帯": ["DAY", "PRE", "POST"],
    "選択期間": ["全期", "前48"],
    "上限": {"観点ごと": 6, "帯ごと": 36, "同技術群": 8, "同出生": 2},
    "支持": {
        "全期": {
            "通常": {"取得": 24, "到達": 16, "取得場": 8, "到達場": 6, "一場到達比上限": 0.35},
            "疎補完": {"取得": 8, "到達": 6, "取得場": 4, "到達場": 3, "一場到達比上限": 0.50},
        },
        "前48": {
            "通常": {"取得": 16, "到達": 10, "取得場": 6, "到達場": 4, "一場到達比上限": 0.40},
            "疎補完": {"取得": 6, "到達": 4, "取得場": 3, "到達場": 2, "一場到達比上限": 0.60},
        },
    },
    "観測不足又は金融未知比上限": 0.20,
    "観点の順番": ["先着支持", "中央値の見通し", "参加の広さ", "未取得場の補い", "新768の多様性", "疎な補完"],
    "先着率の硬い足切り": None,
    "中央値の硬い足切り": None,
    "意味": "独立一枚screenからglobal1再生へ渡す短表。採用条件でもglobal1成績の代用でもない",
}


def 未知を含む中央値の範囲(既知値: list[float], 未知数: int) -> dict:
    """機能: 金融未知値を負無限大・正無限大へ置いた中央値の上下界を返す。

    引数: 既知値 (list[float]) は有限な損益、未知数 (int) は未確定損益数。
    返り値: dict。空集合は未定義、上下界が有限でなくても符号判定を保持する。
    """
    if 未知数 < 0 or not isinstance(未知数, int):
        raise ValueError("未知数は0以上の整数で指定する")
    if any(not math.isfinite(値) for 値 in 既知値):
        raise ValueError("既知損益は有限値で指定する")
    件数 = len(既知値) + 未知数
    if 件数 == 0:
        return {"件数": 0, "既知のみ中央値": None, "下界": None, "上界": None, "判定": "未定義"}

    def 中央値(値: list[float]) -> float:
        """機能: 拡張実数の中央値を計算する。

        引数: 値 (list[float]) は片側の無限大だけを含められる非空標本。
        返り値: float。偶数標本では中央2値の平均を返す。
        """
        並び = sorted(値)
        中 = len(並び) // 2
        return 並び[中] if len(並び) % 2 else (並び[中 - 1] + 並び[中]) / 2

    下界 = 中央値(既知値 + [-math.inf] * 未知数)
    上界 = 中央値(既知値 + [math.inf] * 未知数)
    判定 = "正を確定" if 下界 > 0 else "正ではないと確定" if 上界 <= 0 else "符号未確定"
    return {"件数": 件数, "既知のみ中央値": 中央値(既知値) if 既知値 else None, "下界": 下界, "上界": 上界, "判定": 判定}


def ウィルソン下限(F: int, A: int) -> float:
    """機能: 独立取引仮定の参考Wilson95%下限を順位用に計算する。

    引数: F (int) は利確側先着、A (int) は損切側先着の件数。
    返り値: float。未到達だけなら負無限大を返す。将来保証には用いない。
    """
    n = F + A
    if n == 0:
        return -math.inf
    p = F / n
    z = 1.959963984540054
    return (p + z * z / (2 * n) - z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))) / (1 + z * z / n)


def 支持を判定する(統計: dict, 期間: str) -> str | None:
    """機能: 指定された選択期間だけの取得・到達・場支持を判定する。

    引数: 統計 (dict) は独立screenの小統計、期間 (str) は全期又は前48。
    返り値: strは通常又は疎補完、支持不足はNone。中央値・総利益で排除しない。
    """
    n = 統計["count"]
    if sum(統計[文字] for 文字 in ["F", "A", "N", "C"]) != n:
        raise ValueError("F/A/N/Cの和と取得数が一致しない")
    if not 0 <= 統計["unknown_financial"] <= n:
        raise ValueError("金融未知数が取得数の範囲外")
    取得場 = set(統計["filled_scene_ids"])
    if len(取得場) != 統計["filled_scenes"] or 統計["filled_scenes"] > 統計["eligible_scenes"]:
        raise ValueError("取得場の集合又は対象場数が不整合")
    if 統計["resolved_scenes"] > 統計["filled_scenes"]:
        raise ValueError("到達場数が取得場数より多い")
    if not 0 <= 統計["max_resolved_scene_count"] <= 統計["F"] + 統計["A"]:
        raise ValueError("最多一場到達数が全到達数の範囲外")
    if n == 0:
        return None
    for 単位 in ["trade", "session"]:
        if 統計[f"{単位}_median_lower"] > 統計[f"{単位}_median_upper"]:
            raise ValueError("中央値の下界が上界を超えている")
    if max(統計["C"], 統計["unknown_financial"]) / n > 仕様["観測不足又は金融未知比上限"]:
        return None
    到達 = 統計["F"] + 統計["A"]
    比 = 統計["max_resolved_scene_count"] / 到達 if 到達 else math.inf
    for 階層 in ["通常", "疎補完"]:
        下限 = 仕様["支持"][期間][階層]
        if (n >= 下限["取得"] and 到達 >= 下限["到達"]
                and 統計["filled_scenes"] >= 下限["取得場"]
                and 統計["resolved_scenes"] >= 下限["到達場"]
                and 比 <= 下限["一場到達比上限"]):
            return 階層
    return None


def 順位キー(候補: dict, 観点: str) -> tuple:
    """機能: 選択期間内の支持と複数目的から降順比較キーを作る。

    引数: 候補 (dict) は正規化済み候補、観点 (str) は事前に定めた選定観点。
    返り値: tuple。自然値に応じて順位方式や重みを変更しない。
    """
    s = 候補["stats"]
    到達 = s["F"] + s["A"]
    w = ウィルソン下限(s["F"], s["A"])
    参加 = s["filled_scenes"] / s["eligible_scenes"]
    到達参加 = s["resolved_scenes"] / s["eligible_scenes"]
    両正 = s["trade_median_lower"] > 0 and s["session_median_lower"] > 0
    正可能 = s["trade_median_upper"] > 0 and s["session_median_upper"] > 0
    中央値級 = 2 if 両正 else 1 if 正可能 else 0
    主キー = {
        "先着支持": (w, 到達参加, 参加),
        "中央値の見通し": (中央値級, s["trade_median_lower"], s["session_median_lower"], w),
        "参加の広さ": (参加, 到達参加, w),
        "未取得場の補い": (参加, 到達参加, w),
        "新768の多様性": (w, 参加, 中央値級),
        "疎な補完": (w, 到達参加, 中央値級),
    }[観点]
    return 主キー + (-max(s["C"], s["unknown_financial"]) / s["count"], 到達)


def 純短表を選ぶ(行集合: Iterable[dict], 期間: str) -> dict:
    """機能: 同じ指定期間の支持だけを使い3帯の多様な短表を決定する。

    引数: 行集合 (Iterable[dict]) は候補メタデータと期間別screen統計、期間 (str) は全期又は前48。
    返り値: dict。最大36候補/帯と支持棄却数を返す。注文・損益の再計算は行わない。
    """
    if 期間 not in 仕様["選択期間"]:
        raise ValueError("全期又は前48を明示する")
    棄却 = Counter()
    母集団 = {帯: [] for 帯 in 仕様["帯"]}
    既出 = set()
    for 行 in 行集合:
        if 行["id"] in 既出:
            raise ValueError("候補IDが重複している")
        既出.add(行["id"])
        if 行["band"] not in 母集団:
            raise ValueError("対象外の帯")
        統計 = 行["periods"][期間]
        階層 = 支持を判定する(統計, 期間)
        if 階層 is None:
            棄却[行["band"]] += 1
            continue
        メタデータ = {項目: 行[項目] for 項目 in ["id", "source", "family", "birth_key", "band", "rule", "mode", "orientation", "width", "horizon"]}
        for 項目 in ["key", "rule_index", "position", "birth_ref", "birth_layout", "birth_array", "mode_index", "axis_mode"]:
            if 項目 in 行:
                メタデータ[項目] = 行[項目]
        メタデータ.update({"stats": 統計, "support_tier": 階層})
        母集団[行["band"]].append(メタデータ)

    # ----------------------------------------
    短表 = {}
    for 帯 in 仕様["帯"]:
        選択 = []
        選択ID = set()
        群数 = Counter()
        出生数 = Counter()
        被覆 = set()
        for 観点 in 仕様["観点の順番"]:
            for _ in range(仕様["上限"]["観点ごと"]):
                選択肢 = [行 for 行 in 母集団[帯] if 行["id"] not in 選択ID
                    and 群数[(行["source"], 行["family"])] < 仕様["上限"]["同技術群"]
                    and 出生数[行["birth_key"]] < 仕様["上限"]["同出生"]]
                if 観点 == "新768の多様性":
                    選択肢 = [行 for 行 in 選択肢 if 行["source"] == "NEW768"]
                elif 観点 == "疎な補完":
                    選択肢 = [行 for 行 in 選択肢 if 行["support_tier"] == "疎補完"]
                else:
                    選択肢 = [行 for 行 in 選択肢 if 行["support_tier"] == "通常"]
                if not 選択肢:
                    break
                選択肢.sort(key=lambda 行: 行["id"])
                if 観点 == "未取得場の補い":
                    選択肢.sort(key=lambda 行: (len(set(行["stats"]["filled_scene_ids"]) - 被覆), 順位キー(行, 観点)), reverse=True)
                    if not (set(選択肢[0]["stats"]["filled_scene_ids"]) - 被覆):
                        break
                else:
                    選択肢.sort(key=lambda 行: 順位キー(行, 観点), reverse=True)
                採る = dict(選択肢[0])
                採る["selected_by"] = 観点
                選択.append(採る)
                選択ID.add(採る["id"])
                群数[(採る["source"], 採る["family"])] += 1
                出生数[採る["birth_key"]] += 1
                被覆.update(採る["stats"]["filled_scene_ids"])
        短表[帯] = 選択
    仕様本文 = json.dumps(仕様, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return {
        "選択期間": 期間,
        "仕様SHA256": hashlib.sha256(仕様本文).hexdigest(),
        "読んだ結果範囲": f"periods[{期間}]だけ。別期間の成績は選択に使わない",
        "母集団件数": len(既出),
        "支持不足件数": dict(棄却),
        "短表": 短表,
        "判定": "独立screenからglobal1再生へ渡すだけ。両median・参加・70%の達成判定は未実行",
    }
