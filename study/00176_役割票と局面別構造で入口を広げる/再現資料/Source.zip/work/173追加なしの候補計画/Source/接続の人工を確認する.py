"""Stage1 adapterの必要条件filter・添字・元出生参照を、作成した人工NPZだけで確認する。"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import sys
import unittest
from pathlib import Path

import numpy as np

from 支持と多様性で短表を選ぶ import 支持を判定する, 純短表を選ぶ


場所 = Path(__file__).resolve().parent
定義 = importlib.util.spec_from_file_location("adapter173_artificial", 場所 / "Stage1から短表を作る.py")
adapter = importlib.util.module_from_spec(定義)
sys.modules[定義.name] = adapter
定義.loader.exec_module(adapter)
人工先 = 場所.parent / "人工接続"


def 金融を参照する(context: dict, cases: np.ndarray, sides: np.ndarray, wi: int, hi: int) -> tuple:
    """機能: 作成済み人工配列だけを共通lookup形式で参照する。

    引数: context (dict)、cases/sides (np.ndarray)、wi/hi (int) は人工金融の添字。
    返り値: tuple[np.ndarray,np.ndarray,np.ndarray,np.ndarray]はlabel・known・net・ダミーexit。
    """
    key = (cases, sides, wi, hi)
    return tuple(context["arrays"][項目][key] for 項目 in ["label", "known", "net5", "exit_time"])


def 人工contextを作る() -> dict:
    """機能: 8Day・8Night、3帯各16取得の小さい共通金融を作る。

    引数: なし。
    返り値: dictは実ファイルを読まない人工context。
    """
    場 = [f"人工{i:02d}_Day" for i in range(8)] + [f"人工{i:02d}_Night" for i in range(8)]
    case場, phase = [], []
    for si in range(16):
        for bi in ([0, 0] if si < 8 else [1, 1, 2, 2]):
            case場.append(si)
            phase.append(bi)
    n = len(phase)
    label = np.empty((n, 2, 2, 2), dtype=np.int8)
    for case in range(n):
        for side in range(2):
            値 = 2 if case % 13 == 0 else -1 if (case + side) % 4 == 0 else 1
            label[case, side] = 値
    known = label != 2
    money = np.where(known, label.astype(float) * 100 - 7, 99999)
    hours = np.zeros((16, 3))
    hours[:8, 0] = 6
    hours[8:, 1:] = [5, 7]
    return {"scenes": [{"session": 値} for 値 in 場], "hours": hours,
        "event_cases": np.arange(n, dtype=np.int32), "event_phases": np.array(phase, dtype=np.int8),
        "meta": {"widths": [200, 400], "horizons": ["H60", "SESSION"]},
        "arrays": {"session_index": np.array(case場, dtype=np.int16), "label": label,
                   "known": known, "net5": money, "exit_time": np.ones_like(money)}}


def 人工blockを作る(context: dict, 源: str) -> dict:
    """機能: 独立に計数したscreenと、3形式の小さい出生NPZを作る。

    引数: context (dict) は人工共通金融、源 (str) はOLD1460/NEW768/LOCAL173。
    返り値: dictはpool173互換の人工block。
    """
    n = len(context["event_cases"])
    modes = ["DECLARED"] if 源 == "LOCAL173" else ["ALL", "EDGE"]
    axis = {"規則順": ["人工A", "人工B"], "発火方式": modes, "方向": ["NORMAL", "REVERSE"],
        "幅": [200, 400], "時計": ["H60", "SESSION"], "帯": ["DAY", "PRE", "POST"],
        "期間": ["全期", "前48場", "後25場"],
        "指標": ["count", "F", "A", "N", "C", "rate", "profit", "loss", "net", "pf", "known", "unknown", "scenes", "eligible_scenes", "per_hour", "max_scene_share"]}
    files, matrices = {}, {}
    for 幅 in ([200, 400] if 源 == "OLD1460" else [0]):
        matrix = np.ones((2, n), dtype=np.int8)
        matrix[1, ::3] = 0
        if 源 == "OLD1460" and 幅 == 400:
            matrix[0, ::4] = 0
        data = {"directions": matrix, "phases": context["event_phases"]} if 源 == "LOCAL173" else {"ALL": matrix, "EDGE": matrix.copy(), "phases": context["event_phases"]}
        path = 人工先 / f"{源}_{幅}.npz"
        np.savez_compressed(path, **data)
        files[str(幅) if 幅 else "shared"] = {"path": path.name, "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}
        matrices[幅] = matrix
    metrics = np.full((2, len(modes), 2, 2, 2, 3, 3, 16), np.nan)
    for ri in range(2):
        for mi in range(len(modes)):
            for oi in range(2):
                for wi, 幅 in enumerate(axis["幅"]):
                    方向 = matrices[幅 if 源 == "OLD1460" else 0][ri]
                    for hi in range(2):
                        for bi in range(3):
                            採用 = np.flatnonzero((方向 != 0) & (context["event_phases"] == bi))
                            side = np.full(len(採用), oi, dtype=np.int8)
                            ls, known, money, _ = 金融を参照する(context, 採用, side, wi, hi)
                            si = context["arrays"]["session_index"][採用]
                            count = np.bincount(si, minlength=16)
                            F, A, N, C = [int((ls == code).sum()) for code in [1, -1, 0, 2]]
                            profit, loss = float(money[known & (money > 0)].sum()), -float(money[known & (money < 0)].sum())
                            vals = [len(採用), F, A, N, C, F / (F + A) if F + A else np.nan, profit, loss, profit - loss,
                                profit / loss if loss else np.nan, int(known.sum()), int((~known).sum()),
                                int((count > 0).sum()), 8, len(採用) / 40, int(count.max()) / len(採用) if len(採用) else np.nan]
                            metrics[ri, mi, oi, wi, hi, bi, :2] = vals
    birth = {"layout": "width_dependent" if 源 == "OLD1460" else "declared" if 源 == "LOCAL173" else "shared",
             "files": files, "q0_count": n, "array_modes": modes}
    result = {"source": 源, "ids": axis["規則順"], "families": ["人工A", "人工B"], "axis": axis, "metrics": metrics, "birth": birth,
        "declared_modes": None}
    if 源 == "LOCAL173":
        result["declared_modes"] = ["ALL", "EDGE"]
        birth["array_name"] = "directions"
    return result


class 接続人工(unittest.TestCase):
    """自然ファイルを一切参照せず、adapterの契約を確認する。"""

    def test_支持可能な候補を事前filterで捨てない(self) -> None:
        """機能: 最緩必要条件filterが通常・疎補完の通過を妨げないことを検査する。

        引数: self (接続人工) は検査インスタンス。
        返り値: None。2期間×2000人工統計で支持適格なら事前filterも通る。
        """
        rng = np.random.default_rng(20261115)
        fields = ["count", "F", "A", "N", "C", "unknown", "scenes"]
        for period in ["全期", "前48"]:
            for _ in range(2000):
                n = int(rng.integers(0, 150))
                FA = int(rng.integers(0, n + 1))
                C = int(rng.integers(0, n - FA + 1))
                filled = min(n, int(rng.integers(0, 37)))
                reached = min(filled, FA, int(rng.integers(0, 20)))
                maximum = FA if reached == 0 else math.ceil(FA / reached)
                stats = {"count": n, "F": FA, "A": 0, "N": n - FA - C, "C": C,
                    "unknown_financial": C, "eligible_scenes": 40, "filled_scenes": filled,
                    "resolved_scenes": reached, "max_resolved_scene_count": maximum,
                    "filled_scene_ids": list(range(filled)), "trade_median_lower": 0, "trade_median_upper": 0,
                    "session_median_lower": 0, "session_median_upper": 0}
                if 支持を判定する(stats, period) is not None:
                    row = np.array([n, FA, 0, n - FA - C, C, C, filled], dtype=float)
                    self.assertTrue(bool(adapter.保守的事前フィルター(row, fields, period)))

    def test_全3出生形式と元添字を保持する(self) -> None:
        """機能: 幅別・ALL/EDGE共通・DECLARED方向から同じscreen計数を復元する。

        引数: self (接続人工) は検査インスタンス。
        返り値: None。LOCALを再EDGE化せず、元添字と出生参照が短表に残ることを確認。
        """
        context = 人工contextを作る()
        blocks = [人工blockを作る(context, 源) for 源 in ["OLD1460", "NEW768", "LOCAL173"]]
        resolver = adapter.出生解決(人工先, len(context["event_cases"]))
        for period in ["全期", "前48"]:
            audit = {}
            records = list(adapter.recordを流す(blocks, context, 金融を参照する, resolver, period, audit))
            self.assertTrue(records)
            for record in records:
                self.assertEqual(record["rule_index"], record["position"][0])
                self.assertIn("birth_ref", record)
                self.assertEqual(set(record["periods"]), {period})
                if record["source"] == "LOCAL173":
                    self.assertEqual(record["axis_mode"], "DECLARED")
                    self.assertEqual(record["mode"], ["ALL", "EDGE"][record["rule_index"]])
                    self.assertEqual(record["birth_array"], "directions")
            chosen = 純短表を選ぶ(records, period)
            self.assertTrue(any(r["source"] == "LOCAL173" for rows in chosen["短表"].values() for r in rows))

    def test_F1なしで自然入口を通さない(self) -> None:
        """機能: Rootの固定SHAとGOが揃わないF1を拒否する。

        引数: self (接続人工) は検査インスタンス。
        返り値: None。人工F1のGOなし・指紋違いを拒否する。
        """
        path = 人工先 / "人工F1.json"
        path.write_text(json.dumps({"試行": 173, "GO": False}), encoding="utf-8")
        sha = hashlib.sha256(path.read_bytes()).hexdigest()
        with self.assertRaises(ValueError):
            adapter.F1を確認する(path, sha)
        with self.assertRaises(ValueError):
            adapter.F1を確認する(path, "0" * 64)


if __name__ == "__main__":
    人工先.mkdir(exist_ok=True)
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(接続人工)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    proof = {"成功": result.wasSuccessful(), "自然入力": "不使用。生成した人工NPZのみ", "検査数": result.testsRun,
        "支持可能候補を落とさない人工統計数": 4000,
        "adapterSHA256": hashlib.sha256((場所 / "Stage1から短表を作る.py").read_bytes()).hexdigest()}
    (場所.parent / "接続の人工確認.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    raise SystemExit(0 if result.wasSuccessful() else 1)
