"""173の独立screen配列を支持付き純短表へ接続する。自然実行にはRootのF1 GOを要する。"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import sys
import time
from pathlib import Path

import numpy as np

from 支持と多様性で短表を選ぶ import 仕様, 未知を含む中央値の範囲, 純短表を選ぶ


根 = Path(__file__).resolve().parents[3]
期間対応 = {"全期": "全期", "前48": "前48場"}


def モジュールを読む(場所: Path, 名前: str) -> object:
    """機能: 実行入口を起動せず定義だけを明示名で読み込む。

    引数: 場所 (Path) はSource、名前 (str) は独立したモジュール名。
    返り値: objectは読み込まれたモジュール。
    """
    定義 = importlib.util.spec_from_file_location(名前, 場所)
    結果 = importlib.util.module_from_spec(定義)
    sys.modules[名前] = 結果
    定義.loader.exec_module(結果)
    return 結果


def 物理指紋(場所: Path) -> dict:
    """機能: 参照ファイルの大きさとSHA256を取得する。

    引数: 場所 (Path) はファイル。
    返り値: dictは絶対パス・bytes・sha256。
    """
    with 場所.open("rb") as 入力:
        SHA = hashlib.file_digest(入力, "sha256").hexdigest()
    return {"path": str(場所.resolve()), "bytes": 場所.stat().st_size, "sha256": SHA}


def F1を確認する(場所: Path, 期待SHA: str) -> dict:
    """機能: 自然ファイルへ触れる前にRootの173・F1 GOを確認する。

    引数: 場所 (Path) はF1 JSON、期待SHA (str) はRootから渡された固定指紋。
    返り値: dictは一致したF1物理指紋。不一致又はGOなしでは例外。
    """
    指紋 = 物理指紋(場所)
    if 指紋["sha256"] != 期待SHA:
        raise ValueError("RootのF1 SHA256と一致しない")
    内容 = json.loads(場所.read_text(encoding="utf-8-sig"))
    if 内容.get("GO") is not True or 内容.get("試行", 内容.get("trial")) != 173:
        raise ValueError("試行173のRoot F1 GOが必要")
    return 指紋


def 保守的事前フィルター(統計: np.ndarray, 指標: list[str], 期間: str) -> np.ndarray:
    """機能: 最緩支持層で必要な既存4項目だけを使い支持不可能な設定を除く。

    引数: 統計 (np.ndarray) は末尾が指標軸の配列、指標 (list[str]) は軸名、期間 (str) は全期/前48。
    返り値: np.ndarray[bool]。到達場・中央値・最多一場比を推測せず、支持可能候補を残す。
    """
    軸 = {名前: 位置 for 位置, 名前 in enumerate(指標)}
    下限 = 仕様["支持"][期間]["疎補完"]
    n = 統計[..., 軸["count"]]
    到達 = 統計[..., 軸["F"]] + 統計[..., 軸["A"]]
    不足 = np.maximum(統計[..., 軸["C"]], 統計[..., 軸["unknown"]])
    return ((n >= 下限["取得"]) & (到達 >= 下限["到達"])
            & (統計[..., 軸["scenes"]] >= 下限["取得場"])
            & (不足 <= 仕様["観測不足又は金融未知比上限"] * n))


def 最初の物理取得(方向: np.ndarray, 対応case: np.ndarray, 帯: np.ndarray) -> tuple:
    """機能: 全場q0履歴から同じ物理caseの最初の成立だけを保持する。

    引数: 方向 (np.ndarray) は純出生、対応case (np.ndarray) は取得対応、帯 (np.ndarray) はq0のDAY/PRE/POST。
    返り値: tuple[np.ndarray,np.ndarray,np.ndarray]はcase・買0売1・最初q0帯。
    """
    if 方向.shape != 対応case.shape or 方向.shape != 帯.shape or not np.isin(方向, [-1, 0, 1]).all():
        raise ValueError("純出生・取得対応・帯の長さ又は方向が不整合")
    位置 = np.flatnonzero((方向 != 0) & (対応case >= 0))
    if len(位置):
        最初 = np.unique(対応case[位置], return_index=True)[1]
        位置 = 位置[np.sort(最初)]
    return 対応case[位置], np.where(方向[位置] == 1, 0, 1).astype(np.int8), 帯[位置]


class 出生解決:
    """指紋が一致する出生NPZだけを一つずつ保持し、旧幅別・新共通・局所DECLAREDを扱う。"""

    def __init__(self, 基準: Path, q0数: int) -> None:
        """機能: 自然ファイル未読の空キャッシュを初期化する。

        引数: 基準 (Path) はrepo根、q0数 (int) は共通取得対応の長さ。
        返り値: None。
        """
        self.基準 = 基準
        self.q0数 = q0数
        self.現在 = None
        self.配列 = {}
        self.検査済み = {}

    def 方向を読む(self, block: dict, 規則位置: int, 発火位置: int, 幅: int) -> tuple:
        """機能: 設定の純方向と、再生側へ渡す元出生参照を取り出す。

        引数: block (dict) はpool単位、規則位置/発火位置/幅 (int) は元添字と出口幅。
        返り値: tuple[np.ndarray,dict,str]は方向・物理参照・NPZ配列名。
        """
        出生 = block["birth"]
        if 出生.get("q0_count", self.q0数) != self.q0数:
            raise ValueError("出生と金融のq0数が一致しない")
        参照 = 出生["files"][str(幅) if 出生["layout"] == "width_dependent" else "shared"]
        場所 = self.基準 / 参照["path"]
        if str(場所) not in self.検査済み:
            指紋 = 物理指紋(場所)
            if any(指紋[項目] != 参照[項目] for 項目 in ["bytes", "sha256"]):
                raise ValueError("出生NPZの指紋がpool参照と不一致")
            self.検査済み[str(場所)] = 指紋
        if self.現在 != str(場所):
            with np.load(場所, allow_pickle=False) as 入力:
                名前 = [出生.get("array_name", "directions")] if 出生["layout"] == "declared" or block.get("declared_modes") is not None else 出生.get("array_modes", ["ALL", "EDGE"])
                self.配列 = {名前: 入力[名前].copy() for 名前 in 名前}
            self.現在 = str(場所)
        配列名 = 出生.get("array_name", "directions") if 出生["layout"] == "declared" or block.get("declared_modes") is not None else block["axis"]["発火方式"][発火位置]
        配列 = self.配列[配列名]
        if 配列.shape != (len(block["ids"]), self.q0数):
            raise ValueError("出生NPZの規則順又はq0数がpoolと不一致")
        return 配列[規則位置], 参照, 配列名


def 不足列を集計する(context: dict, lookup: object, cases: np.ndarray, sides: np.ndarray,
                 phases: np.ndarray, 帯名: str, 期間: str, 幅: int, 期限: str) -> dict:
    """機能: 事前filter後の実caseから到達場・取得場・未知中央値だけを追加集計する。

    引数: context (dict) とlookup (callable) は共通金融、cases/sides/phases (np.ndarray) は最初の物理取得。
          帯名/期間/期限 (str)、幅 (int) は固定設定。
    返り値: dictは純selector用の同期間小統計。保有枠付き成績ではない。
    """
    帯位置 = {"DAY": 0, "PRE": 1, "POST": 2}[帯名]
    対象 = context["hours"][:, 帯位置] > 0
    if 期間 == "前48":
        対象 &= np.arange(len(対象)) < 48
    scene = context["arrays"]["session_index"][cases]
    採用 = (phases == 帯位置) & 対象[scene]
    c, s, si = cases[採用], sides[採用], scene[採用]
    wi, hi = context["meta"]["widths"].index(幅), context["meta"]["horizons"].index(期限)
    label, known, money, _ = lookup(context, c, s, wi, hi)
    known = np.asarray(known, dtype=bool)
    money = np.asarray(money)
    到達 = np.isin(label, [1, -1])
    場数 = len(対象)
    場取得 = np.bincount(si, minlength=場数)
    場到達 = np.bincount(si[到達], minlength=場数)
    場未知 = np.bincount(si[~known], minlength=場数)
    場既知額 = np.bincount(si[known], weights=money[known], minlength=場数)
    建玉中央値 = 未知を含む中央値の範囲(money[known].astype(float).tolist(), int((~known).sum()))
    場中央値 = 未知を含む中央値の範囲(場既知額[対象 & (場未知 == 0)].tolist(), int((対象 & (場未知 > 0)).sum()))
    結果 = {"count": len(c), **{名前: int((label == 符号).sum()) for 名前, 符号 in [("F", 1), ("A", -1), ("N", 0), ("C", 2)]},
        "known_financial": int(known.sum()), "unknown_financial": int((~known).sum()), "eligible_scenes": int(対象.sum()),
        "filled_scenes": int((場取得 > 0).sum()), "resolved_scenes": int((場到達 > 0).sum()),
        "max_resolved_scene_count": int(場到達.max(initial=0)),
        "filled_scene_ids": [context["scenes"][i]["session"] for i in np.flatnonzero(場取得 > 0)],
        "trade_median_lower": 建玉中央値["下界"], "trade_median_upper": 建玉中央値["上界"],
        "session_median_lower": 場中央値["下界"], "session_median_upper": 場中央値["上界"],
        "profit": float(np.maximum(money[known], 0).sum()), "loss": float(np.maximum(-money[known], 0).sum()),
        "net": float(money[known].sum()), "median_scope": "独立一枚screen。global1必須中央値の代用ではない"}
    return 結果


def recordを流す(blocks: object, context: dict, lookup: object, resolver: 出生解決,
              期間: str, 監査: dict, 進捗: object = None):
    """機能: pool別NPZを保守filterし、必要な設定だけをselector recordとして流す。

    引数: blocks (Iterable[dict])、context (dict)、lookup (callable)、resolver (出生解決)、期間 (str)、
          監査 (dict) は件数の記録先、進捗 (callable | None) は途中状態の通知先。
    返り値: Iterator[dict]は指定期間だけのrecord。別期間結果を補助順位にも使わない。
    """
    for block in blocks:
        axis, metrics = block["axis"], block["metrics"]
        pi = axis["期間"].index(期間対応[期間])
        指標 = list(axis["指標"])
        field = {名前: i for i, 名前 in enumerate(指標)}
        if list(axis["帯"]) != ["DAY", "PRE", "POST"]:
            raise ValueError("poolの帯はDAY/PRE/POST順に正規化する")
        対象配列 = metrics[..., pi, :]
        filter = 保守的事前フィルター(対象配列, 指標, 期間)
        位置列 = np.argwhere(filter)
        if len(位置列):
            順 = np.lexsort((位置列[:, 5], 位置列[:, 4], 位置列[:, 2], 位置列[:, 0], 位置列[:, 1], 位置列[:, 3]))
            位置列 = 位置列[順]
        件数 = {帯: {"事前filter前": int(np.prod(filter.shape[:5])), "事前filter通過": int(filter[..., bi].sum())}
              for bi, 帯 in enumerate(axis["帯"])}
        監査[block["source"]] = 件数
        if 進捗:
            進捗({"期間": 期間, "源": block["source"], "事前filter": 件数})
        直前 = None
        for 計算数, 位置 in enumerate(位置列, 1):
            ri, mi, oi, wi, hi, bi = map(int, 位置)
            幅, 期限, 帯名 = int(axis["幅"][wi]), axis["時計"][hi], axis["帯"][bi]
            方向, 参照, 配列名 = resolver.方向を読む(block, ri, mi, 幅)
            物理キー = (参照["path"], ri, mi)
            if 直前 != 物理キー:
                cases, 基本側, phases = 最初の物理取得(方向, context["event_cases"], context["event_phases"])
                直前 = 物理キー
            sides = 基本側 if axis["方向"][oi] == "NORMAL" else 1 - 基本側
            統計 = 不足列を集計する(context, lookup, cases, sides, phases, 帯名, 期間, 幅, 期限)
            元 = 対象配列[tuple(位置)]
            比較 = {"count": "count", "F": "F", "A": "A", "N": "N", "C": "C", "known": "known_financial", "unknown": "unknown_financial",
                    "scenes": "filled_scenes", "eligible_scenes": "eligible_scenes", "profit": "profit", "loss": "loss", "net": "net"}
            for 元名, 追加名 in 比較.items():
                if not math.isclose(float(元[field[元名]]), float(統計[追加名]), rel_tol=0, abs_tol=1e-7):
                    raise ValueError(f"実case再集計とStage1が不一致: {block['source']}/{ri}/{帯名}/{期間}/{元名}")
            mode = block["declared_modes"][ri] if block.get("declared_modes") is not None else axis["発火方式"][mi]
            rule = block["ids"][ri]
            key = f"{block['source']}_{rule}_{mode}_{axis['方向'][oi]}_W{幅}_{期限}"
            geometry = 幅 if block["birth"]["layout"] == "width_dependent" else "共通"
            yield {"id": key + "_" + 帯名, "key": key, "source": block["source"], "family": block["families"][ri],
                "birth_key": f"{block['source']}/{rule}/{mode}/{axis['方向'][oi]}/geometry{geometry}",
                "band": 帯名, "rule": rule, "rule_index": ri, "mode": mode, "mode_index": mi,
                "axis_mode": axis["発火方式"][mi], "orientation": axis["方向"][oi], "width": 幅, "horizon": 期限,
                "position": [ri, mi, oi, wi, hi], "birth_ref": 参照, "birth_layout": block["birth"]["layout"],
                "birth_array": 配列名, "periods": {期間: 統計}}
            if 進捗 and 計算数 % 10000 == 0:
                進捗({"期間": 期間, "源": block["source"], "実case補完済み": 計算数, "補完対象": len(位置列)})


def JSON可能にする(値: object) -> object:
    """機能: 未知中央値の非有界を明示した標準JSONへ変換する。

    引数: 値 (object) は純selectorの結果。
    返り値: objectは無限大を文字列Infinity/-Infinityで保持し、NaNを拒否した値。
    """
    if isinstance(値, dict):
        return {キー: JSON可能にする(内容) for キー, 内容 in 値.items()}
    if isinstance(値, (tuple, list)):
        return [JSON可能にする(内容) for 内容 in 値]
    if isinstance(値, float) and not math.isfinite(値):
        if math.isnan(値):
            raise ValueError("NaNは出力しない")
        return "Infinity" if 値 > 0 else "-Infinity"
    return 値


def 主処理() -> None:
    """機能: Root F1 GO後だけ自然poolを読み、2期間×3帯の短表と監査を保存する。

    引数: CLIの--day-output/--addition/--out(Path)、--f1-go(Path)、--f1-sha256(str)。
    返り値: None。既存出力を上書きせずworkへ出力する。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--day-output", type=Path, required=True)
    parser.add_argument("--addition", type=Path, action="append", default=[])
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parents[1] / "短表")
    parser.add_argument("--f1-go", type=Path, required=True)
    parser.add_argument("--f1-sha256", required=True)
    args = parser.parse_args()
    F1 = F1を確認する(args.f1_go.resolve(), args.f1_sha256)
    出力先 = args.out.resolve()
    if 根 / "work" not in 出力先.parents or 出力先.exists():
        raise ValueError("work配下の未作成出力先を指定する")
    pool = モジュールを読む(根 / "work/173予備入口screen/pool173.py", "pool173_for_selector")
    base = モジュールを読む(根 / "work/172ナイト基礎診断/基礎診断.py", "base172_for_selector173")
    context = base.load(False)
    resolver = 出生解決(根, len(context["event_cases"]))
    監査 = {}
    結果 = {}
    開始 = time.monotonic()
    for 期間 in ["全期", "前48"]:
        監査[期間] = {}
        blocks = pool.iter_blocks(args.day_output.resolve(), additions=[p.resolve() for p in args.addition])
        stream = recordを流す(blocks, context, base.labels, resolver, 期間, 監査[期間],
                            lambda 内容: print(json.dumps(内容, ensure_ascii=False), flush=True))
        結果[期間] = 純短表を選ぶ(stream, 期間)
    出力先.mkdir()
    (出力先 / "短表173.json").write_text(json.dumps(JSON可能にする({"成功": True, "選択": 結果}), ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    確認 = {"成功": True, "試行": 173, "F1": F1, "事前filter": 監査,
        "短表件数": {期間: {帯: len(行) for 帯, 行 in 内容["短表"].items()} for 期間, 内容 in 結果.items()},
        "金融参照": base.INPUTS, "出生参照": resolver.検査済み,
        "事前filterの意味": "最緩支持の取得/到達/取得場/未知比だけ。中央値・到達場・最多到達場比を推定して足切りしない",
        "注意": "全80のglobal1評価は別工程。これは独立screenからの候補圧縮だけ。0場は独立セッション中央値にも保持",
        "無限大の表記": "標準JSONでは文字列Infinity/-Infinity。未知を0へ置換したものではない",
        "経過秒": time.monotonic() - 開始}
    (出力先 / "接続実行の確認.json").write_text(json.dumps(JSON可能にする(確認), ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


if __name__ == "__main__":
    主処理()
