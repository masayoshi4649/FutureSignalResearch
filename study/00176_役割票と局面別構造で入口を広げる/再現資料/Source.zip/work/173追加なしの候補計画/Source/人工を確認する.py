"""173の純短表案を人工値だけで確認する。自然入力・金融ファイルは読み込まない。"""

from __future__ import annotations

import copy
import hashlib
import json
import math
import unittest
from pathlib import Path

from 支持と多様性で短表を選ぶ import 未知を含む中央値の範囲, 純短表を選ぶ


def 人工候補(番号: int, 帯: str = "PRE", 疎: bool = False) -> dict:
    """機能: 読み込みのない決定的な人工候補を生成する。

    引数: 番号 (int) は識別用、帯 (str) は3帯のいずれか、疎 (bool) は補完支持の例。
    返り値: dict。全期・前48の統計は同じ人工値とする。
    """
    数 = 8 if 疎 else 32
    F = 5 if 疎 else 20 + 番号 % 5
    A = 1 if 疎 else 4
    場 = [f"人工{(番号 + k) % 40:02d}" for k in range(4 if 疎 else 12)]
    統計 = {"count": 数, "F": F, "A": A, "N": 数 - F - A, "C": 0,
        "unknown_financial": 0, "eligible_scenes": 40, "filled_scenes": len(場),
        "resolved_scenes": 3 if 疎 else 8, "max_resolved_scene_count": 2 if 疎 else 4,
        "filled_scene_ids": 場, "trade_median_lower": 100.0, "trade_median_upper": 100.0,
        "session_median_lower": 0.0, "session_median_upper": 0.0}
    return {"id": f"人工_{帯}_{番号:03d}", "source": "NEW768" if 番号 % 2 else "OLD1460",
        "family": f"人工群{番号 % 7}", "birth_key": f"人工出生{番号 // 2}",
        "band": 帯, "rule": f"人工規則{番号 // 2}", "mode": "EDGE", "orientation": "NORMAL",
        "width": 200 if 番号 % 2 else 400, "horizon": "H60",
        "periods": {期間: copy.deepcopy(統計) for 期間 in ["全期", "前48", "後25", "追加7"]}}


class 人工確認(unittest.TestCase):
    """人工値で前後漏洩・未知符号・疎な小帯・多様性の規約を確認する。"""

    def test_取得0は未定義中央値のまま支持不足(self) -> None:
        """機能: 自然screenに多数存在する取得0規則を安全に記録する。

        引数: self (人工確認) は検査インスタンス。
        返り値: None。建玉中央値Noneを0へ捏造せず、支持不足へ分類する。
        """
        候補 = 人工候補(1)
        s = 候補["periods"]["全期"]
        for 項目 in ["count", "F", "A", "N", "C", "unknown_financial", "filled_scenes", "resolved_scenes", "max_resolved_scene_count"]:
            s[項目] = 0
        s["filled_scene_ids"] = []
        s["trade_median_lower"] = None
        s["trade_median_upper"] = None
        結果 = 純短表を選ぶ([候補], "全期")
        self.assertEqual(結果["短表"]["PRE"], [])
        self.assertEqual(結果["支持不足件数"]["PRE"], 1)

    def test_前48選択は別期間の成績を読まない(self) -> None:
        """機能: 前48選択への別期間結果の混入を検知する。

        引数: self (人工確認) は検査インスタンス。
        返り値: None。別期間を壊しても短表が一致することを確認する。
        """
        行 = [人工候補(番号) for 番号 in range(50)]
        前 = 純短表を選ぶ(行, "前48")
        変更 = copy.deepcopy(行)
        for 候補 in 変更:
            候補["periods"]["全期"] = {"読むと失敗": True}
            候補["periods"]["後25"] = {"読むと失敗": True}
            候補["periods"]["追加7"] = {"読むと失敗": True}
        self.assertEqual(前, 純短表を選ぶ(変更, "前48"))

    def test_小帯のゼロ中央値で排除しない(self) -> None:
        """機能: 小帯単独の全Night中央値0を採用条件と混同しない。

        引数: self (人工確認) は検査インスタンス。
        返り値: None。疎なPRE候補も短表へ残ることを確認する。
        """
        候補 = 人工候補(51, 疎=True)
        結果 = 純短表を選ぶ([候補], "全期")
        self.assertEqual(len(結果["短表"]["PRE"]), 1)
        self.assertEqual(結果["短表"]["PRE"][0]["support_tier"], "疎補完")

    def test_場集中は支持不足として残す(self) -> None:
        """機能: 多数の同一場反復を多数場の支持に置換しない。

        引数: self (人工確認) は検査インスタンス。
        返り値: None。単一到達場への集中を短表へ通さない。
        """
        候補 = 人工候補(1)
        候補["periods"]["全期"]["resolved_scenes"] = 1
        候補["periods"]["全期"]["max_resolved_scene_count"] = 25
        結果 = 純短表を選ぶ([候補], "全期")
        self.assertEqual(結果["短表"]["PRE"], [])
        self.assertEqual(結果["支持不足件数"]["PRE"], 1)

    def test_未知の中央値は符号範囲を保つ(self) -> None:
        """機能: 既知のみ中央値の正を全件中央値の正へ読み替えない。

        引数: self (人工確認) は検査インスタンス。
        返り値: None。未知による確定正と符号未確定を区別する。
        """
        例 = 未知を含む中央値の範囲([10.0], 1)
        self.assertEqual(例["判定"], "符号未確定")
        self.assertEqual(例["下界"], -math.inf)
        self.assertEqual(例["上界"], math.inf)
        self.assertEqual(未知を含む中央値の範囲([10.0, 20.0, 30.0], 1)["判定"], "正を確定")
        self.assertEqual(未知を含む中央値の範囲([], 0)["判定"], "未定義")

    def test_ゼロ場をセッション中央値に含める(self) -> None:
        """機能: 無取引場を中央値の分母に残す。

        引数: self (人工確認) は検査インスタンス。
        返り値: None。2場の利益だけなら正でも全5場では0になることを確認する。
        """
        self.assertGreater(未知を含む中央値の範囲([100.0, 200.0], 0)["下界"], 0)
        self.assertEqual(未知を含む中央値の範囲([100.0, 200.0, 0.0, 0.0, 0.0], 0)["下界"], 0)

    def test_順番非依存と上限(self) -> None:
        """機能: 入力順による候補選択の変動と多重派生の占有を防ぐ。

        引数: self (人工確認) は検査インスタンス。
        返り値: None。最大36/帯・2/出生・8/技術群と逆順一致を確認する。
        """
        行 = [人工候補(番号, 帯) for 帯 in ["DAY", "PRE", "POST"] for 番号 in range(80)]
        結果 = 純短表を選ぶ(行, "全期")
        self.assertEqual(結果, 純短表を選ぶ(reversed(行), "全期"))
        for 短表 in 結果["短表"].values():
            self.assertLessEqual(len(短表), 36)
            for 出生 in {候補["birth_key"] for 候補 in 短表}:
                self.assertLessEqual(sum(候補["birth_key"] == 出生 for 候補 in 短表), 2)
            for 源, 群 in {(候補["source"], 候補["family"]) for 候補 in 短表}:
                self.assertLessEqual(sum(候補["source"] == 源 and 候補["family"] == 群 for 候補 in 短表), 8)


if __name__ == "__main__":
    検査 = unittest.defaultTestLoader.loadTestsFromTestCase(人工確認)
    結果 = unittest.TextTestRunner(verbosity=2).run(検査)
    保存 = {"成功": 結果.wasSuccessful(), "人工検査数": 結果.testsRun, "自然入力を読んだか": False,
        "失敗数": len(結果.failures), "例外数": len(結果.errors),
        "仕様SHA256": 純短表を選ぶ([], "全期")["仕様SHA256"],
        "選択SourceのSHA256": hashlib.sha256((Path(__file__).parent / "支持と多様性で短表を選ぶ.py").read_bytes()).hexdigest()}
    (Path(__file__).resolve().parents[1] / "人工確認.json").write_text(json.dumps(保存, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    raise SystemExit(0 if 結果.wasSuccessful() else 1)
