"""176役割票の因果性・対称性・未知と局所状態を自然入力なしで確認する。"""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import importlib.util
import json

import numpy as np
import rules176 as R

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('synthetic175_for176',ROOT/'work/175局面別の純入口/人工検査.py')
A=importlib.util.module_from_spec(spec);spec.loader.exec_module(A)


def synthetic(group: str,n: int=70) -> tuple:
    """
    機能: 175人工場を新しい代替構造の必要列へ拡張する。
    引数: group(str)は六群、n(int)はq0数。
    返り値: tupleはfeatures(SimpleNamespace)と場開始秒np.ndarray。
    """
    features,starts=A.synthetic(group,n)
    for name,value in [('m1_previous_body_ratio_to_side',-.5),('m5_opposite_wick_ratio',.5)]:
        if name not in features.columns:
            position=next(i for i,column in enumerate(features.columns) if column.startswith('人工未使用'))
            features.columns[position]=name
            features.buy_X[:,position]=value
            features.sell_X[:,position]=value
    return features,starts


def main() -> None:
    """
    機能: 六局面成立・鏡像・prefix・未来改変・未知・gapとLC公表状態を確認する。
    引数: なし。
    返り値: None。自然金融なしの確認票と全辞書を保存する。
    """
    here=Path(__file__).resolve().parent;catalog=R.catalog();checks={};cells=0
    assert len(catalog['rules'])==576
    for group in R.GROUPS:
        features,starts=synthetic(group)
        ids=[r['id'] for r in catalog['rules'] if r['group']==group]
        result=R.build(features,starts,candidate_ids=ids)
        assert result['directions'].any(),group
        swapped=SimpleNamespace(buy_X=features.sell_X.copy(),sell_X=features.buy_X.copy(),columns=features.columns,q0_meta=features.q0_meta)
        assert np.array_equal(R.build(swapped,starts,candidate_ids=ids)['directions'],-result['directions']),group
        for end in (20,36,50):
            prefix=R.build(A.take(features,end),starts,candidate_ids=ids)['directions']
            assert np.array_equal(prefix,result['directions'][:,:end]),(group,end)
            future=A.take(features,len(features.q0_meta));future.buy_X[end:]=np.nan;future.sell_X[end:]=np.nan
            after=R.build(future,starts,candidate_ids=ids)['directions']
            assert np.array_equal(after[:,:end],result['directions'][:,:end]),group
            cells+=prefix.size+after[:,:end].size
        unknown=A.take(features,len(features.q0_meta));unknown.buy_X[:]=np.nan;unknown.sell_X[:]=np.nan
        assert not R.build(unknown,starts,candidate_ids=ids)['directions'].any(),group
        gap=A.take(features,len(features.q0_meta));boundary=len(gap.q0_meta)//2+1
        for q in gap.q0_meta[boundary:]:q['q0_time']+=300
        gap_result=R.build(gap,starts,candidate_ids=ids)
        assert gap_result['diagnostics']['history_reset'][boundary]
        if group!='LC':assert not gap_result['directions'][:,boundary:boundary+4].any(),group
        for ri,rule in enumerate([r for r in catalog['rules'] if r['group']==group]):
            if rule['confirmation_seconds']==60:assert gap_result['directions'][ri,boundary]==0
        checks[group]={'候補数':96,'人工成立セル':int(np.count_nonzero(result['directions'])),
            '鏡像':True,'prefixと未来変更':True,'全未知待機':True,'gapで状態と確認をreset':True}
    # ----------------------------------------
    features,starts=synthetic('HR')
    missing=features.columns.index('m1_previous_body_ratio_to_side');features.buy_X[:,missing]=np.nan
    evaluator=R.Evaluator176(features,starts)
    values,known=evaluator.factor(0,'v176_structure|HR|5|8')
    assert not known.any() and np.isnan(values).all()
    features,starts=synthetic('LC',80);column=features.columns.index('m15_hist_delta_to_side')
    features.buy_X[20,column]=.1
    for q in features.q0_meta[40:]:q['q0_time']+=300
    result=R.build(features,starts,candidate_ids=['LC0001_ALL'])
    assert result['diagnostics']['local_allowed'][:20].all() and not result['diagnostics']['local_allowed'][20:].any()
    assert not result['directions'][:,20:].any()
    for q in features.q0_meta[50:]:q['contract']='次限月'
    other=R.build(features,starts,candidate_ids=['LC0001_ALL'])
    assert other['diagnostics']['local_allowed'][50:].all() and other['diagnostics']['history_reset'][50]
    path=here/'候補辞書176.json';path.write_text(json.dumps(catalog,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    proof={'成功':True,'自然特徴と金融未読':True,'群':checks,'照合セル':cells,
        '役割必要列が未知なら役割全体NaN':True,'局所公表everと限月reset':True,
        'SourceSHA256':hashlib.sha256((here/'rules176.py').read_bytes()).hexdigest(),
        '候補辞書SHA256':hashlib.sha256(path.read_bytes()).hexdigest()}
    (here/'人工確認176.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
