"""176固定入力だけで、自然成立・独立予備票・global1不適原因を短く診断する。"""
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'work/176局面別の役割票'))
sys.path.insert(0,str(ROOT/'work/161三時間帯入口のデータ'))
import rules176 as R
import data161

HERE=Path(__file__).resolve().parent


def read(path: Path) -> object:
    """
    機能: JSON又はgzip JSONを読み込む。
    引数: path(Path)。
    返り値: objectは既存の固定結果。
    """
    if path.suffix=='.gz':
        with gzip.open(path,'rt',encoding='utf-8') as stream:return json.load(stream)
    return json.loads(path.read_text(encoding='utf-8'))


def sha(path: Path) -> str:
    """
    機能: 読取対象の変更を検知する指紋を返す。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def count(mask: np.ndarray,phases: np.ndarray,scenes: np.ndarray) -> dict:
    """
    機能: 候補間重複を除いたq0と場の成立数を三帯別に数える。
    引数: mask/phases/scenes(np.ndarray[N])。
    返り値: dictはDAY/PRE/POSTごとのq0数と場数。
    """
    return {name:{'q0':int(np.count_nonzero(mask&(phases==i))),
        '場数':int(len(np.unique(scenes[mask&(phases==i)])))} for i,name in enumerate(('DAY','PRE','POST'))}


def funnel() -> dict:
    """
    機能: 固定自然出生を照合し、必要未知と条件不成立、既知条件だけの遮断を分ける。
    引数: なし。
    返り値: dictは非金融成立票。条件を外した仮想数は損益を持たない。
    """
    features=data161.load_feature_dataset();phases=features.q0_timeband
    scenes=np.asarray([q['session_index'] for q in features.q0_meta]);n=len(phases)
    starts=np.asarray([s['start'] for s in features.scenes]);evaluator=R.Evaluator176(features,starts)
    rules=R.candidate_catalog();matrix=np.load(ROOT/'work/176役割票入口の再探索/純出生176.npz')['directions']
    old_matrix=np.load(ROOT/'work/175局面別入口の再探索/純出生175.npz')['directions']
    old_rules=R.P.candidate_catalog();out={}
    for group in R.GROUPS:
        indices=[i for i,r in enumerate(rules) if r['group']==group and r['mode']=='ALL']
        old_indices=[i for i,r in enumerate(old_rules) if r['group']==group and r['mode']=='ALL']
        passed=np.any(matrix[indices]!=0,axis=0);known=np.zeros(n,bool);relax={};missing={}
        for ri in indices:
            rule=rules[ri];actual=evaluator.evaluate_one(rule)
            assert np.array_equal(actual['directions'],matrix[ri]),rule['id']
            known |= (~actual['unknown_buy'])|(~actual['unknown_sell'])
            if rule['confirmation_seconds']!=0:continue
            for side in (0,1):
                pairs=[evaluator.comparison(side,t) for t in rule['conditions']]
                truths=[x[0] for x in pairs];knowns=[x[1] for x in pairs]
                prefix=[np.ones(n,bool)]
                for truth in truths:prefix.append(prefix[-1]&truth)
                suffix=[None]*(len(truths)+1);suffix[-1]=np.ones(n,bool)
                for i in range(len(truths)-1,-1,-1):suffix[i]=suffix[i+1]&truths[i]
                for i,t in enumerate(rule['conditions']):
                    key=f"{t['factor']} {t['operator']} {t['threshold']}"
                    others=prefix[i]&suffix[i+1]
                    relax.setdefault(key,np.zeros(n,bool))[:] |= others&knowns[i]&~truths[i]
                    missing.setdefault(key,np.zeros(n,bool))[:] |= others&~knowns[i]
        def top(items: dict) -> dict:
            """
            機能: 三帯それぞれの既知単条件遮断又は未知遮断の上位4項目を取る。
            引数: items(dict[str,np.ndarray])。
            返り値: dict。和集合の既成立点は除外し、異なる項目間を合算しない。
            """
            values={k:count(v&~passed,phases,scenes) for k,v in items.items()}
            return {b:[{'条件':k,**v[b]} for k,v in sorted(values.items(),key=lambda x:(-x[1][b]['q0'],x[0]))[:4]] for b in ('DAY','PRE','POST')}
        out[group]={'175成立':count(np.any(old_matrix[old_indices]!=0,axis=0),phases,scenes),
            '176成立':count(passed,phases,scenes),'全必要既知':count(known,phases,scenes),
            '未知で候補全滅':count(~known,phases,scenes),'既知だが不成立':count(known&~passed,phases,scenes),
            '既知単条件だけを外した増分上位':top(relax),'単条件未知だけが遮断の上位':top(missing)}
        print(json.dumps({'群':group,'175':out[group]['175成立'],'176':out[group]['176成立']},ensure_ascii=False),flush=True)
    return {'群':out,'注意':'非金融ファネル。成立は要求や実取得とは異なる。単条件除外は0秒確認のALL候補だけの仮想数で、候補和集合の既成立q0を除く。源泉条件の変更はしていない。'}


def compact_group(row: dict,period: str,band: str) -> dict:
    """
    機能: global1結果から参加・先着・両中央値と累計経路を短く抜粋する。
    引数: row(dict)、period/band(str)。
    返り値: dict。未知後の経路は既知寄与という名称を保持する。
    """
    group=row['periods'][period][band];trades=group['trades'];sessions=group['sessions']
    risk=row['paths'][period][band];path=risk['known_contribution']
    return {'取得':trades['all_count'],'取得場':sessions['participating_count'],'全場':sessions['eligible_count'],
        '先着':trades['IFD_FIRSTFANC'],'既知利益':trades['known_profit'],'既知損失':trades['known_loss'],
        '既知収支':trades['known_net'],'建玉中央値':trades['net_median'],
        '場中央値':sessions['net_median'],'両中央値判定':group['decision']['status'],
        '既知寄与初期最小':path['initial_minimum'],'既知寄与DD':path['max_drawdown_amount'],
        '既知寄与最長水面下場数':path['max_underwater_scenes'],
        '完全5場窓赤字比率':risk['windows']['5']['negative_net_share_complete'],
        '完全10場窓赤字比率':risk['windows']['10']['negative_net_share_complete']}


def finance() -> dict:
    """
    機能: 175/176の既存旧73金融だけを要約し、固定同条件の量・方向対照を並べる。
    引数: なし。
    返り値: dict。独立一枚の予備票とglobal1口座再生を分け、新規金融は計算しない。
    """
    out={};folders={175:ROOT/'work/175局面別入口の再探索',176:ROOT/'work/176役割票入口の再探索'}
    for trial,folder in folders.items():
        axis=read(folder/f'予備軸{trial}.json');metrics=np.load(folder/f'予備統計{trial}.npz')['metrics']
        joint=read(folder/'三帯接合.json.gz')['rows'];mixture=read(folder/'六局面.json.gz')['rows']
        record={'三帯接合':{},'六局面':{},'既存条件の独立一枚対照':[]}
        for route in ('全期','前48'):
            matches=[r for r in joint if r['policy']['route']==route]
            def flags(row: dict) -> tuple:
                """
                機能: 固定選択と同じ中央値・参加・率・支持の別判定を返す。
                引数: row(dict)。
                返り値: tuple[bool,bool,bool,bool]は両中央値、全場、先着支持、両小帯支持。
                """
                groups=row['periods'][route];risks=row['paths'][route]
                median=all(groups[b]['decision']['status']=='適合' for b in ('DAY','NIGHT'))
                coverage=all(risks[b]['support']['zero_scene_count']==0 for b in ('DAY','NIGHT'))
                rate=all((groups[b]['trades']['IFD_FIRSTFANC']['first_f_rate_reached'] or 0)>=.7
                    and groups[b]['trades']['IFD_FIRSTFANC']['reached_count']>=12
                    and groups[b]['trades']['all_count']>=24 and groups[b]['resolved_scene_count']>=6 for b in ('DAY','NIGHT'))
                phase=all(risks[b]['support']['phase_diagnostic_goal_met'] for b in ('PRE','POST'))
                return median,coverage,rate,phase
            all_flags=[flags(r) for r in matches]
            record['三帯接合'][route]={'候補数':len(matches),
                '両中央値適合':sum(x[0] for x in all_flags),'全場取得':sum(x[1] for x in all_flags),
                '両帯先着70支持':sum(x[2] for x in all_flags),'両小帯参加支持':sum(x[3] for x in all_flags),
                '全共同':sum(all(x) for x in all_flags),
                '最大取得場':{b:max((r['periods'][route][b]['sessions']['participating_count'] for r in matches),default=0) for b in ('DAY','NIGHT')}}
            for band in ('DAY','PRE','POST'):
                rows=[r for r in mixture if r['policy']['route']==route and r['policy']['band']==band]
                groups=[r['periods'][route][band] for r in rows]
                record['六局面'][route+'_'+band]={'候補数':len(rows),
                    '両中央値判定':dict(Counter(g['decision']['status'] for g in groups)),
                    '最大取得場':max((g['sessions']['participating_count'] for g in groups),default=0),
                    '最大取得数':max((g['trades']['all_count'] for g in groups),default=0)}
        # ----------------------------------------
        # 全候補に共通の比較時計。最大成績や別幅の選び直しは行わない。
        wi=axis['幅'].index(200);hi=axis['期限'].index('H60');fields=axis['指標']
        for group in ('HT','HB','HR','HM','LC','RL'):
            numbers=(1,9,17) if trial==176 else (1,)
            for number in numbers:
                identity=f'{group}{number:04d}_ALL';ri=axis['候補順'].index(identity)
                for bi,band in enumerate(axis['帯']):
                    for oi,orientation in enumerate(axis['方向']):
                        values=dict(zip(fields,metrics[ri,oi,bi,0,wi,hi].tolist(),strict=True))
                        row={k:(v if np.isfinite(v) else None) for k,v in values.items()}
                        record['既存条件の独立一枚対照'].append({'ID':identity,'帯':band,'方向':orientation,
                            '幅':200,'期限':'H60','統計':row})
        if trial==176:
            ids=('全期_J002','全期_J003','前48_J018','前48_J019')
            record['固定参考候補']={identity:{p:{b:compact_group(next(r for r in joint if r['id']==identity),p,b)
                for b in ('DAY','PRE','POST','NIGHT')} for p in ('全期','前48','後25')} for identity in ids}
            # 方向票・動力票・持続の既存8設定だけを、量.5・profile0で比較する。
            role_rows=[]
            for group in ('HT','HB','HR','HM'):
                for number in range(1,9):
                    identity=f'{group}{number:04d}_ALL';ri=axis['候補順'].index(identity)
                    for bi,band in enumerate(axis['帯']):
                        for oi,orientation in enumerate(axis['方向']):
                            values=dict(zip(fields,metrics[ri,oi,bi,0,wi,hi].tolist(),strict=True))
                            role_rows.append({'ID':identity,'帯':band,'方向':orientation,
                                '統計':{k:(v if np.isfinite(v) else None) for k,v in values.items()}})
            record['既存役割票8設定の独立対照']=role_rows
        out[str(trial)]=record
    return out


def main() -> None:
    """
    機能: 固定読取対象を指紋付きで診断し、小型JSON票へ保存する。
    引数: なし。
    返り値: None。Source・出生・金融結果は変更しない。
    """
    paths=[ROOT/'work/175局面別の純入口/rules175.py',ROOT/'work/176局面別の役割票/rules176.py']
    for trial,folder in ((175,'175局面別入口の再探索'),(176,'176役割票入口の再探索')):
        paths.extend(ROOT/'work'/folder/name for name in (f'純出生{trial}.npz',f'予備統計{trial}.npz','六局面.json.gz','三帯接合.json.gz'))
    before={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    result={'成功':True,'対象':'175/176の固定済み旧73場のみ。新規条件金融と追加7を計算しない。',
        '自然成立':funnel(),'既存金融':finance(),'読取指紋':before}
    assert before=={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    target=HERE/'原因診断176.json';target.write_text(json.dumps(result,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'保存先':str(target),'bytes':target.stat().st_size},ensure_ascii=False))


if __name__=='__main__':
    main()
