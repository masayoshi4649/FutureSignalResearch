"""176の役割票による純入口。175を変更せず方向・動力・代替構造を分離する。"""
from itertools import product
from pathlib import Path
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/175局面別の純入口'))
import rules175 as P
from rules162 import term

VERSION='176局面別役割票1'
GROUPS={**P.GROUPS}


def candidate_catalog() -> list[dict]:
    """
    機能: 六群各48論理規則へALL/EDGEを適用した576候補を生成する。
    引数: なし。
    返り値: list[dict]は必須の背景・方向票・動力票・構造と全閾値。
    """
    rules=[]
    for group in GROUPS:
        for number,(profile,volume,direction,momentum,hold) in enumerate(product((0,1),(.5,.75,1.0),(1,2),(1,2),(0,60)),1):
            window=5+5*profile;depth={'HT':0 if profile==0 else .25,'HB':.1*profile,
                'HR':8+4*profile,'HM':5*profile,'RL':1+.5*profile,'LC':0}[group]
            conditions=[term('q0_spread_points','>',0),term('q0_spread_points','<=',20),
                term('abs_q0_close_gap','<=',1),term('m1_tr_atr5_ratio','<=',1.5),
                term('m5_tr_previous_atr_ratio','<=',2.5),term('n_abs_rsi_delta5','<=',8-4*profile),
                term('m1_volume_relative_prior3','>=',volume),
                term('q0_entry_minus_ema8_atr5_to_side','<=',1-.25*profile),
                term(f'v176_direction|{group}','>=',direction+1 if group in ('HT','HB') else direction),
                term(f'v176_momentum|{group}','>=',momentum),
                term(f'v176_structure|{group}|{window}|{depth}','>=',1)]
            if group in ('HT','HB'):
                conditions += [term('m15_adx','>=',20+5*profile),term('long_up_votes','>=',1),
                    term('m5_rsi_center_to_side','<=',20),term('q0_entry_minus_ema8_atr5_to_side','>=',-.5)]
                if group=='HB':conditions += [term('m15_adx_delta','>=',-.5 if profile==0 else 0),
                    term('q0_last_minus_prior3_forward_edge_atr5_to_side','>',depth)]
            elif group=='HR':
                conditions += [term('m15_adx','>=',20+5*profile),term('m15_adx_delta','<=',0 if profile==0 else -.25),
                    term('long_up_votes','<=',2-profile),term('bb15_position_sigma_to_side','<=',.5),
                    term('q0_entry_minus_ema8_atr5_to_side','>=',-2+.5*profile)]
            elif group=='HM':
                conditions += [term('m15_adx','>=',15+5*profile),term('m15_adx','<=',30+10*profile),
                    term('long_up_votes','>=',1),term('long_up_votes','<=',3),
                    term('m5_rsi_center_to_side','<=',20),term('q0_entry_minus_ema8_atr5_to_side','>=',-.5)]
            elif group=='RL':
                conditions += [term('m15_adx','<=',15+5*profile),term('long_up_votes','<=',2),
                    term('bb15_position_sigma_to_side','<=',-.5-.5*profile),
                    term('bb15_mean_room_125_ratio_to_side','>',0),
                    term('q0_entry_minus_ema8_atr5_to_side','>=',-2+.5*profile)]
            else:
                conditions += [term('p175_local_allowed','>',.5),term('p175_elapsed_minutes','>=',120+60*profile),
                    term('m5_rsi_center_to_side','>=',-5),term('m5_rsi_center_to_side','<=',20),
                    term('m5_tr_atr_ratio','<=',2),term('q0_entry_minus_ema8_atr5_to_side','>=',-.5)]
            logical=f'{group}{number:04d}'
            for mode in ('ALL','EDGE'):
                rules.append({'id':logical+'_'+mode,'logical_id':logical,'group':group,'family':group,
                    'description':GROUPS[group][0]+'の役割票','technical_families':GROUPS[group][1],
                    'timeframes':[1,5] if group=='LC' else [1,5,15,30],
                    'settings':{'profile':profile,'window_minutes':window,'depth':depth,'volume_min':volume,
                        'direction_votes_min':direction+1 if group in ('HT','HB') else direction,
                        'momentum_votes_min':momentum,'structure_votes_min':1,'hold_seconds':hold,'geometry_points':200},
                    'mode':mode,'confirmation_seconds':hold,'conditions':conditions})
    assert len(rules)==576 and len({r['id'] for r in rules})==576
    return rules


def catalog() -> dict:
    """
    機能: 自然実行前の辞書と役割票の意味を公開する。
    引数: なし。
    返り値: dictは版・576候補・役割・入力と限界。
    """
    return {'version':VERSION,'logical_count':288,'candidate_count':576,'rules':candidate_catalog(),
        'groups':{g:{'logical_count':48,'candidate_count':96,'technical_families':v[1]} for g,v in GROUPS.items()},
        'roles':{'direction':'HT/HBは5/15/30分EMA/DIの6票中2/3。他群は5分EMA/DI/gapの3票中1/2。全必要列既知。',
            'momentum':'5分MACD増分とRSI増分の2票中1/2。両列既知。過熱水準だけで向きを決めない。',
            'structure':'枝ごとの履歴イベント・実体回復・現在価格進行の3パターン中1以上。全パターンの必要列が既知。',
            'context':'ADX水準/傾きと長期方向の背景は票の外の必須。HRはADX低下と長期反対/混在を保持。'},
        'input':'当時実側100特徴、q0_meta、場開始秒だけ。金融・教師・取得を読まない。',
        'clock':'175純部品の場/scene/限月/gap>180秒履歴reset、LC公表ever状態を再用。全最終条件方向を0/60秒確認後ALL/EDGE。',
        'width':'geometry200固定、出口幅非依存。',
        'unknown':'役割票の必要列が一つでも未知ならその票役割全体を未知にする。NaNを0票へ補完しない。',
        'limitations':['175の自然成立funnelを見た後の別試行で、175のSource/出生/結果は変更しない。',
            '代替構造を増やすことの収益性・安定性・先着率・頻度は未検証。',
            '役割票は相関した指標の独立投票とは扱わず、複数技術を必須の役割として分離する研究仮説。',
            'ADX20以上は中間帯を含む研究閾値で、上昇トレンド又は強さの確定ではない。',
            '株価構造の端とBBは当時ごとに更新される。過去の絶対価格を固定した完全なリテストではない。']}


class Evaluator176(P.Evaluator175):
    def role_factor(self,side: int,name: str) -> tuple:
        """
        機能: 必須列全既知の範囲で方向・動力・代替構造の票を作る。
        引数: side(int)は実側、name(str)はv176固定派生。
        返り値: tuple[np.ndarray,np.ndarray]は票数と役割全体の既知mask。
        """
        parts=name.split('|');kind,group=parts[:2]

        def value(column: str) -> tuple:
            """
            機能: 175/172の既存純因果factorを取得する。
            引数: column(str)。
            返り値: tuple[np.ndarray,np.ndarray]は値と既知性。
            """
            return super(Evaluator176,self).factor(side,column)

        def positive(column: str,threshold: float=0) -> tuple:
            """
            機能: 一つの条件を、その必要列の既知性と組にする。
            引数: column(str)、threshold(float)は厳密下限。
            返り値: tuple[np.ndarray,np.ndarray]は成立と既知性。
            """
            data,known=value(column);return data>threshold,known

        def together(*items: tuple) -> tuple:
            """
            機能: 代替構造一パターンの必要条件を束ねる。
            引数: items(tuple)は真偽/既知maskの組。
            返り値: tuple[np.ndarray,np.ndarray]は同時成立と全既知。
            """
            return np.logical_and.reduce([x[0] for x in items]),np.logical_and.reduce([x[1] for x in items])

        if kind=='v176_direction':
            columns=([f'm{m}_{column}' for m in (5,15,30) for column in ('ema21_delta_to_side','di_difference_to_side')]
                if group in ('HT','HB') else ['m5_ema21_delta_to_side','m5_di_difference_to_side','m5_gap_to_side'])
            patterns=[positive(column) for column in columns]
        elif kind=='v176_momentum':
            patterns=[positive('m5_hist_delta_to_side'),positive('m5_rsi_delta_to_side')]
        elif kind=='v176_structure':
            window=int(parts[2]);depth=float(parts[3])
            body=positive('m1_body_ratio_to_side');live=positive('live_reclaim');advance=positive('m1_close_delta_atr5_to_side')
            if group=='HT':
                price,known=value('m5_price_ema8_atr_to_side')
                patterns=[positive(f'n_event|NP|{window}|{depth}|0',.5),together(body,(price>=0,known)),together(live,advance)]
            elif group=='HB':
                patterns=[positive(f'p175_break|{window}|{depth}|0',.5),body,advance]
            elif group=='HR':
                previous,known=value('m1_previous_body_ratio_to_side')
                patterns=[positive(f'n_event|NS|{window}|{depth}|0',.5),
                    together((previous<0,known),live,body),together(positive('m5_opposite_wick_ratio',.2),live,advance)]
            elif group=='HM':
                patterns=[positive(f'n_event|NX|{window}|{depth}|0',.5),
                    positive('q0_last_minus_prior3_forward_edge_atr5_to_side'),together(live,body)]
            elif group=='RL':
                patterns=[positive(f'n_event|NR|{window}|{depth}|0',.5),live,together(body,advance)]
            else:
                patterns=[together(positive('m5_body_ratio_to_side'),positive('m5_close_position_to_side',.5)),
                    live,together(body,advance)]
        else:raise KeyError('未定義の176役割: '+name)
        known=np.logical_and.reduce([p[1] for p in patterns])
        votes=np.sum([p[0] for p in patterns],axis=0).astype(np.float64)
        return np.where(known,votes,np.nan),known

    def factor(self,side_index: int,name: str) -> tuple:
        """
        機能: 176の固定役割票を既存純派生へ追加する。
        引数: side_index(int)、name(str)。
        返り値: tuple[np.ndarray,np.ndarray]は値と既知性。
        """
        if not name.startswith('v176_'):return super().factor(side_index,name)
        key=(side_index,name)
        if key not in self._factor_cache:self._factor_cache[key]=self.role_factor(side_index,name)
        return self._factor_cache[key]


def build(features: object,scene_starts: object=None,phases: object=None,candidate_ids: list|None=None) -> dict:
    """
    機能: 当時純特徴から176のmode適用済み候補方向を作る。
    引数: features(object)、scene_starts(object|None)、phases(object|None)は診断のみ、candidate_ids(list|None)は部分集合。
    返り値: dictはcandidate_ids/directions[候補,N]と履歴/公表状態の診断。
    """
    if scene_starts is None:scene_starts=P._get(features,'scene_starts')
    evaluator=Evaluator176(features,scene_starts);rules=candidate_catalog()
    if candidate_ids is not None:
        requested=set(candidate_ids);assert len(requested)==len(candidate_ids)
        mapping={r['id']:r for r in rules};assert requested<=set(mapping)
        rules=[mapping[name] for name in candidate_ids]
    matrix=np.asarray([evaluator.evaluate_one(r)['directions'] for r in rules],dtype=np.int8)
    if not rules:matrix=np.zeros((0,len(evaluator.q0_meta)),dtype=np.int8)
    result={'version':VERSION,'candidate_ids':[r['id'] for r in rules],'directions':matrix,
        'diagnostics':{'history_reset':evaluator._reset175.copy(),'local_allowed':evaluator._local_allowed175.copy(),
            'elapsed_minutes':evaluator._elapsed.copy()}}
    if phases is not None:
        values=np.asarray(phases);assert values.shape==(matrix.shape[1],) and np.isin(values,(0,1,2)).all()
        result['phases']=values.copy()
    return result
