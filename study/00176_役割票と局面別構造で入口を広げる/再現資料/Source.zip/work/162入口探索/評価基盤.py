"""新規q0と物理取得を結び、多数のIFD条件を再用可能な配列で比較する。"""
from dataclasses import dataclass
from pathlib import Path
import numpy as np
from 共通 import ROOT,HERE,book,read,module,data_module,sha


@dataclass
class Selection:
    cases: np.ndarray
    sides: np.ndarray
    events: np.ndarray
    phases: np.ndarray
    old: np.ndarray

    def take(self, mask: np.ndarray) -> 'Selection':
        """
        機能: 同じ行maskで取得の全属性を抽出する。
        引数: self(Selection)、mask(np.ndarray[bool又はint])。
        返り値: Selectionは属性を揃えた部分集合。
        """
        return Selection(*(v[mask] for v in (self.cases,self.sides,self.events,self.phases,self.old)))


def join(a: Selection, b: Selection) -> Selection:
    """
    機能: 互いに物理重複のない二集合を連結する。
    引数: a/b(Selection)。
    返り値: Selectionは連結した取得。
    """
    assert not np.intersect1d(a.cases,b.cases).size
    return Selection(*(np.concatenate((x,y)) for x,y in zip(
        (a.cases,a.sides,a.events,a.phases,a.old),(b.cases,b.sides,b.events,b.phases,b.old),strict=True)))


class Context:
    """固定出生・取得対応・数値金融を時計ごとに分けて保持する。"""
    def __init__(self) -> None:
        """
        機能: 全出生の完成を確認後に共有取得と純金融配列を読む。
        引数: self(Context)。
        返り値: None。新規判断はここでは生成しない。
        """
        self.setting=book();self.data=data_module();self.features=self.data.load_feature_dataset()
        outcome_path=ROOT/'work/162可変幅評価/outcomes162.py'
        assert sha(outcome_path)=='f46b1aa101b0b1ea9fb30e94479e0ec987fc8cefad2c3979b6dfc1824844b16f'
        outcomes=module(outcome_path,'outcomes162_engine')
        cache=ROOT/'work/162可変幅評価/自然射影'
        proof=read(cache/'完了.json');assert proof['成功']
        self.table=outcomes.load_table(cache,proof['cache']);self.arrays=self.table.root_arrays()
        self.case_map=self.table.case_to_index();self.sessions=list(self.table.session_order)
        self.scene_map={s:i for i,s in enumerate(self.sessions)}
        self.scenes=self.features.scenes
        assert [s['session'] for s in self.scenes]==self.sessions and len(self.sessions)==73
        self.case_scene=self.arrays['session_index'];self.starts=np.array([s['start'] for s in self.scenes])
        self.event_times=np.array([q['q0_time'] for q in self.features.q0_meta])
        self.event_scenes=np.array([q['session_index'] for q in self.features.q0_meta],dtype=np.int16)
        self.event_phases=self.features.q0_timeband
        self.events={q['event_id']:i for i,q in enumerate(self.features.q0_meta)}
        captures,self.capture_proof=self.data.read_json_ref(self.data.FORMAL_REFS['captures'])
        capture_by_event={c['event_id']:c for c in captures['rows']}
        self.event_cases=np.full(len(self.events),-1,dtype=np.int32)
        for event,index in self.events.items():
            capture=capture_by_event[event];q=self.features.q0_meta[index]
            assert (capture['q0']['time'],capture['q0']['index'],capture['q0']['source_line'])==(q['q0_time'],q['q0_index'],q['q0_line'])
            if capture['status']=='filled':
                ci=self.case_map[capture['case_id']];self.event_cases[index]=ci
                assert self.case_scene[ci]==q['session_index']
                assert tuple(self.arrays['entry_'+k][ci] for k in ('time','index','line'))==tuple(capture['q1'][k] for k in ('time','index','source_line'))
        legacy,self.legacy_proof=self.data.load_legacy_signals()
        self.legacy_rows=legacy
        self.legacy=self.from_legacy(legacy)
        first={}
        for row in legacy:
            scene=self.scene_map[row['session']]
            key=tuple(row['signal_quote'][k] for k in ('time','index','source_line'))+(row['case_id'],)
            if scene not in first or key<first[scene][0]:first[scene]=(key,row)
        assert len(first)==73 and len(self.legacy.cases)==87
        self.first_rows=[first[i][1] for i in range(73)]
        self.first_legacy=self.from_legacy(self.first_rows)
        self.first_birth=np.array([r['signal_quote']['time'] for r in self.first_rows])
        self.first_index=np.array([r['signal_quote']['index'] for r in self.first_rows])
        self.first_line=np.array([r['signal_quote']['source_line'] for r in self.first_rows])
        self.hours=np.zeros((73,3),dtype=np.float64)
        for i,scene in enumerate(self.scenes):
            end=scene['end']-300
            if scene['session'].endswith('_Day'):self.hours[i,0]=(end-scene['start'])/3600
            else:
                boundary=self.data.us_open_time(scene['session'])
                self.hours[i,1]=(min(end,boundary)-scene['start'])/3600
                self.hours[i,2]=(end-max(scene['start'],boundary))/3600
        assert abs(self.hours.sum()-(720+55/60))<1e-10
        self.case_phases=np.array([self.data.timeband(s,float(t)) for s,t in zip(self.table.sessions,self.arrays['entry_time'],strict=True)],dtype=np.int8)
        for hi in range(len(self.table.horizons)):
            completed=self.arrays['label'][:,:,:,hi]!=2
            mature=self.arrays['known_at'][:,:,:,hi]
            assert np.isfinite(mature[completed]).all()
            next_start=np.r_[self.starts[1:],np.inf][self.case_scene,None,None]
            assert np.all((~completed)|(mature<next_start))

    def from_legacy(self, rows: list) -> Selection:
        """
        機能: 固定旧信号の当時出生を新q0と混同せず配列化する。
        引数: rows(list[dict])はC1参照。
        返り値: Selectionは旧出生帯・実側・物理case。
        """
        return Selection(np.array([self.case_map[r['case_id']] for r in rows],dtype=np.int32),
            np.array([0 if r['side']==1 else 1 for r in rows],dtype=np.int8),np.full(len(rows),-1,dtype=np.int32),
            np.array([self.data.timeband(r['session'],r['signal_quote']['time']) for r in rows],dtype=np.int8),np.ones(len(rows),dtype=bool))

    def link(self, directions: np.ndarray) -> Selection:
        """
        機能: 全q0判断を物理取得へ結び、最初に成立したq0だけを採る。
        引数: directions(np.ndarray[int8])は全q0の−1/0/+1。
        返り値: Selectionは重複のない新規取得。取消や未取得は加算しない。
        """
        assert directions.shape==self.event_cases.shape and np.isin(directions,(-1,0,1)).all()
        events=np.flatnonzero((directions!=0)&(self.event_cases>=0))
        if len(events):
            first=np.unique(self.event_cases[events],return_index=True)[1]
            events=events[np.sort(first)]
        cases=self.event_cases[events]
        return Selection(cases,np.where(directions[events]==1,0,1).astype(np.int8),events.astype(np.int32),
            self.event_phases[events],np.zeros(len(events),dtype=bool))

    def integrate(self, new: Selection, mode: str) -> Selection:
        """
        機能: 純新規N、旧全保持U、因果的初参加補完Fを分ける。
        引数: new(Selection)、mode(str)はN/U/F。
        返り値: Selectionは旧優先で物理取得を一意にした統合結果。
        """
        if mode=='N':return new
        if mode=='U':old=self.legacy
        else:
            assert mode=='F'
            scene=self.case_scene[new.cases]
            times=self.arrays['entry_time'][new.cases];indices=self.arrays['entry_index'][new.cases];lines=self.arrays['entry_line'][new.cases]
            t=self.first_birth[scene];idx=self.first_index[scene];line=self.first_line[scene]
            before=(times<t)|((times==t)&((indices<idx)|((indices==idx)&(lines<=line))))
            filled=np.bincount(scene[before],minlength=73)
            old=self.first_legacy.take(filled==0)
        return join(new.take(~np.isin(new.cases,old.cases)),old)

    def stats(self, selected: Selection, wi: int, hi: int, period: str='全期', band: int|None=None) -> dict:
        """
        機能: 同一幅・期限で先着、未知、利益損失、参加、頻度を計算する。
        引数: selected(Selection)、wi/hi(int)、period(str)、band(int又はNone)は取得q1帯。
        返り値: dictは研究集計。独立入口合算を数量制約付き口座収支とはしない。
        """
        eligible=np.ones(73,dtype=bool)
        if period=='前48場':eligible[48:]=False
        elif period=='後25場':eligible[:48]=False
        else:assert period=='全期'
        if band is not None:eligible &= self.hours[:,band]>0
        scenes=self.case_scene[selected.cases]
        mask=eligible[scenes]
        if band is not None:mask &= self.case_phases[selected.cases]==band
        rows=selected.take(mask);scene=self.case_scene[rows.cases]
        labels=self.arrays['label'][rows.cases,rows.sides,wi,hi]
        known=self.arrays['known'][rows.cases,rows.sides,wi,hi]
        money=self.arrays['net'][rows.cases,rows.sides,wi,hi][known]
        counts=np.bincount(scene,minlength=73);f=int(np.sum(labels==1));a=int(np.sum(labels==-1));n=int(np.sum(labels==0));c=int(np.sum(labels==2))
        profit=int(np.maximum(money,0).sum());loss=int(-np.minimum(money,0).sum())
        hours=float(self.hours[eligible].sum() if band is None else self.hours[eligible,band].sum())
        duration=self.arrays['exit_time'][rows.cases,rows.sides,wi,hi][known]-self.arrays['entry_time'][rows.cases][known]
        return {'count':len(labels),'F':f,'A':a,'N':n,'C':c,'rate':f/(f+a) if f+a else None,
            'complete_rate':f/(f+a+n) if f+a+n else None,'all_rate':f/len(labels) if len(labels) else None,
            'profit':profit,'loss':loss,'net':profit-loss,'pf':profit/loss if loss else None,
            'known':int(known.sum()),'unknown':len(known)-int(known.sum()),'scenes':int(np.count_nonzero(counts)),
            'eligible_scenes':int(eligible.sum()),'all_scenes':bool(eligible.any() and np.all(counts[eligible]>0)),
            'hours':hours,'per_hour':len(labels)/hours if hours else None,
            'max_scene_share':int(counts.max())/len(labels) if len(labels) else None,'new_count':int((~rows.old).sum()),
            'old_count':int(rows.old.sum()),'hold_median_seconds':float(np.median(duration)) if len(duration) else None}

    def old_controls(self) -> dict:
        """
        機能: 旧153/152の主要取得集合を同じ新しい幅でも評価可能にする。
        引数: self(Context)。
        返り値: dict[str,Selection]は旧固定対照。旧条件や保存結果は書き換えない。
        """
        controls={'C1':self.legacy}
        for folder,names in [('00152_複合回復の方向切替',('A0','U0','B0','U1')),
            ('00153_先行高安の独立出生',('N15','U15'))]:
            source=read(ROOT/'inputs'/folder/'選択対応.json.gz')
            for name in names:
                rows=source['政策'][name];events=np.array([self.events.get(r['event_id'],-1) for r in rows],dtype=np.int32)
                phases=[]
                legacy_by_case={r['case_id']:r for r in self.legacy_rows}
                for row,event in zip(rows,events,strict=True):
                    phases.append(int(self.event_phases[event]) if event>=0 else self.data.timeband(row['session'],legacy_by_case[row['case_id']]['signal_quote']['time']))
                controls[f'{folder[:5]}_{name}']=Selection(np.array([self.case_map[r['case_id']] for r in rows],dtype=np.int32),
                    np.array([0 if r['side']==1 else 1 for r in rows],dtype=np.int8),events,np.array(phases,dtype=np.int8),
                    np.array([r['origin']=='C1' for r in rows],dtype=bool))
        return controls
