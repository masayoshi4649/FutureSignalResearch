"""多数の入口条件を同一契約で比較するための共通処理。"""
from pathlib import Path
import gzip
import hashlib
import importlib.util
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00162_複合入口を広く探索し値幅ごとに過去選択する'
BOOK_SHA='4f890114b789da404d400f49a5cb888e9b9014013b00fcc0f77dc6ffd691088c'


def sha(path: Path) -> str:
    """
    機能: ファイルのSHA256を計算する。
    引数: path(Path)はファイル。
    返り値: strは物理指紋。
    """
    with path.open('rb') as source:
        return hashlib.file_digest(source,'sha256').hexdigest()


def module(path: Path, name: str) -> object:
    """
    機能: 主処理を呼ばず固定部品を読込む。
    引数: path(Path)、name(str)はSourceと登録名。
    返り値: objectはmodule。
    """
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec);sys.modules[name]=value;spec.loader.exec_module(value)
    return value


def read(path: Path) -> object:
    """
    機能: UTF-8のJSON又はgzip JSONを全読了する。
    引数: path(Path)は入力。
    返り値: objectは解析値。
    """
    body=gzip.decompress(path.read_bytes()) if path.suffix=='.gz' else path.read_bytes()
    return json.loads(body)


def save(path: Path, value: object) -> None:
    """
    機能: 標準JSONをUTF-8、必要なら決定的gzipへ保存する。
    引数: path(Path)、value(object)は保存値。
    返り値: None。
    """
    body=(json.dumps(value,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode('utf-8')
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.suffix=='.gz':
        with path.open('wb') as source:
            with gzip.GzipFile(filename='',mode='wb',mtime=0,fileobj=source) as target:
                target.write(body)
    else:
        path.write_bytes(body)


def book() -> dict:
    """
    機能: 自然実行前に固定した条件を読み指紋を照合する。
    引数: なし。
    返り値: dictは固定条件。
    """
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    return read(TRIAL/'条件.json')


def data_module() -> object:
    """
    機能: 旧共用100特徴と三帯の入力部品を読み込む。
    引数: なし。
    返り値: objectは161データ部品。
    """
    path=ROOT/'work/161三時間帯入口のデータ/data161.py'
    assert sha(path)=='1aa4ab452d26d507f532c78ebf036ca37690642cd1cf140f01eb0423f0fe03fe'
    return module(path,'data162')
