"""161の入力を旧151の固定射影から読み、判断q0の三時間帯を付加する。"""
from dataclasses import dataclass, field
from datetime import datetime, time
from pathlib import Path
from zoneinfo import ZoneInfo
import copy
import gzip
import hashlib
import importlib.util
import json
import math
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
DAY, PRE_US, POST_US = 0, 1, 2
TIMEBAND_NAMES = ("デイ", "米国前", "米国後")
SIDE_ORDER = (1, -1)
Q0_KEYS = frozenset(("event_id", "session", "contract", "session_index", "q0_time", "q0_index", "q0_line"))
SCENE_KEYS = frozenset(("session", "contract", "start", "end", "force_close"))
CATALOG_SHA256 = "c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4"
OLD_DATA_SOURCE_SHA256 = "3b92ff77a28bf82e6cf8e5dc504cc5586f4101c1e28d0bc12b29bc7cd0efdd8c"
CACHE = ROOT / "work/151過去場判別の評価/入口選択/cache"


# ----------------------------------------
@dataclass(frozen=True)
class FileRef:
    path: str | Path
    sha256: str
    decoded_sha256: str | None = None


FEATURE_NPZ = FileRef(CACHE / "feature_only/features.npz", "5b309e0821403fcf1b122956fc6c9fe20ec5dfbe4327d7d674193b8e58f99b44")
FEATURE_META = FileRef(CACHE / "feature_only/features_meta.json", "71df54db57a3093eb4de2f5ce26c654c758f9181e07f61660cb1a192f6fa4602")
TEACHER_NPZ = FileRef(CACHE / "teacher_only/teachers.npz", "ec613a27461c32d1aa09aed4ecf3b013c2d7dc827d86ba642385698547f22689")
TEACHER_META = FileRef(CACHE / "teacher_only/teachers_meta.json", "3b723ca78d5ddc8ab4f301d5f9ba18ee08bea4e0159a085558296f824d736106")
LEGACY_META = FileRef(ROOT / "inputs/00148_全1分入口母集団/入口参照.json.gz", "ad53cccf8e4da093ebd32c1ddc80132ddcd4c73d8f20897c4033f0895fc966b6", "66511104a6efd7bc936b0e624469a2de43e9fa5b5fa7645304499f793c25329c")
FORMAL_REFS = {
    "features": FileRef(ROOT / "inputs/00148_全1分入口母集団/当時特徴.json.gz", "464dad9dce7acb20f043c344e96c9fa6d19ab0049a9d557e6fc96f6d189abcb7", "572705d7db8529555c876eb1953f7d8e1cd1de0e554bf9de729a7d377e4d91af"),
    "fixed": FileRef(ROOT / "inputs/00148_全1分入口母集団/固定取得入力.json.gz", "99f10a996ca6e8b6c428061f1b48624bbc479ec84c500a9633818d47e4298e2a", "12c43fe60e0ffd5ffa44bec7b5f7dd3d60bb92b291e0008db23587dcf19536d3"),
    "captures": FileRef(ROOT / "inputs/00148_全1分入口母集団/取得対応.json.gz", "7c27420abe6af0867f6cf3d8fd838205da3ed099df8db8e5b5d62892cbadf6bc", "e433b79f87411c34232acac57a8aed191da71bcd1888376b19196099cbf9909a"),
    "metadata": LEGACY_META,
    "observations": FileRef(ROOT / "study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz", "bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61", "d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc"),
}


# ----------------------------------------
@dataclass
class FeatureMetadata:
    q0_meta: list[dict]
    scenes: list[dict]
    q0_timeband: np.ndarray
    sources: dict = field(default_factory=dict)


@dataclass
class FeatureDataset:
    columns: tuple[str, ...]
    buy_X: np.ndarray
    sell_X: np.ndarray
    q0_meta: list[dict]
    scenes: list[dict]
    q0_timeband: np.ndarray
    sources: dict = field(default_factory=dict)

    def feature_meta(self) -> FeatureMetadata:
        """
        機能: Xや教師を含めず、識別と当時時計の独立コピーを返す。
        引数: self(FeatureDataset)。
        返り値: FeatureMetadataはq0の識別・三時間帯・場時計・由来。
        """
        return FeatureMetadata(copy.deepcopy(self.q0_meta), copy.deepcopy(self.scenes), self.q0_timeband.copy(), copy.deepcopy(self.sources))


@dataclass
class TeacherDataset:
    rows: list[dict]
    labels: np.ndarray
    pair_complete: np.ndarray
    known_at: np.ndarray
    event_to_teacher_index: np.ndarray
    canonical_feature_index: np.ndarray
    teacher_timeband: np.ndarray
    counts: dict
    sources: dict = field(default_factory=dict)

    @property
    def canonical_rows(self) -> list[dict]:
        """
        機能: 過去教師選択器へ渡す全体正準の物理pair行を公開する。
        引数: self(TeacherDataset)。
        返り値: list[dict]は帯分割前の正準行。現在場等の除外は選択器で行う。
        """
        return self.rows


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: 保存ファイルを固定サイズずつ読みSHA256を計算する。
    引数: path(Path)は入力の物理パス。
    返り値: strは小文字16進SHA256。
    """
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for block in iter(lambda: source.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def _reject_constant(token: str) -> None:
    """
    機能: JSON標準外のNaN及びInfinityを拒否する。
    引数: token(str)は解析器が受けた非有限リテラル。
    返り値: None。常にValueErrorを送出する。
    """
    raise ValueError("JSON非有限値: " + token)


def _before(ref: FileRef) -> tuple[Path, tuple]:
    """
    機能: 入力の物理指紋を確認し読取前statを固定する。
    引数: ref(FileRef)は期待SHAを持つ入力参照。
    返り値: tuple[Path,tuple]は入力パスと識別stat。
    """
    path = Path(ref.path)
    assert len(ref.sha256) == 64 and set(ref.sha256) <= set("0123456789abcdef")
    stat = path.stat()
    state = tuple(getattr(stat, k) for k in ("st_dev", "st_ino", "st_size", "st_mtime_ns"))
    assert sha(path) == ref.sha256, "入力物理SHA不一致: " + str(path)
    return path, state


def _after(ref: FileRef, before: tuple) -> dict:
    """
    機能: 読取後に同じ物理ファイル・指紋であることを確認する。
    引数: ref(FileRef)、before(tuple)は入力参照と読取前stat。
    返り値: dictはパス・サイズ・物理SHA・前後statの証跡。
    """
    path = Path(ref.path)
    stat = path.stat()
    state = tuple(getattr(stat, k) for k in ("st_dev", "st_ino", "st_size", "st_mtime_ns"))
    assert state == before and sha(path) == ref.sha256, "入力読取中の変更"
    return {"path": str(path.resolve()), "sha256": ref.sha256, "physical_bytes": stat.st_size, "stat_before": list(before), "stat_after": list(state)}


def read_json_ref(ref: FileRef) -> tuple[object, dict]:
    """
    機能: 物理/解凍SHAとgzip全CRCを確認してJSONを副本なしで読む。
    引数: ref(FileRef)は物理SHAと任意の解凍SHAを持つ参照。
    返り値: tuple[object,dict]は解析値と読取証跡。
    """
    path, state = _before(ref)
    with path.open("rb") as source:
        compressed = source.read(2) == b"\x1f\x8b"
    with (gzip.open(path, "rb") if compressed else path.open("rb")) as source:
        body = source.read()
    decoded = hashlib.sha256(body).hexdigest()
    assert decoded == (ref.decoded_sha256 or ref.sha256)
    value = json.loads(body, parse_constant=_reject_constant)
    evidence = _after(ref, state)
    evidence.update(decoded_sha256=decoded, decoded_bytes=len(body), gzip=compressed, full_crc_checked=compressed)
    return value, evidence


def read_npz_ref(ref: FileRef, keys: set[str]) -> tuple[dict, dict]:
    """
    機能: pickleを拒否し全配列を読みZIP各メンバーのCRCを確認する。
    引数: ref(FileRef)、keys(set[str])は入力参照と許可した厳密キー集合。
    返り値: tuple[dict,dict]は数値等の配列と物理読取証跡。
    """
    path, state = _before(ref)
    with np.load(path, allow_pickle=False) as source:
        assert set(source.files) == keys
        arrays = {key: source[key].copy() for key in source.files}
    assert all(array.dtype.kind != "O" for array in arrays.values())
    return arrays, _after(ref, state)


# ----------------------------------------
def us_open_time(session: str) -> float | None:
    """
    機能: ナイト開始日のNY09:30を夏冬自動変換しUTC秒で返す。
    引数: session(str)はYYYY-MM-DD_Day又はYYYY-MM-DD_Night。
    返り値: float又はNone。デイは米国境界を適用しない。
    """
    date_text, kind = session.rsplit("_", 1)
    date = datetime.strptime(date_text, "%Y-%m-%d").date()
    assert kind in ("Day", "Night")
    return None if kind == "Day" else datetime.combine(date, time(9, 30), ZoneInfo("America/New_York")).timestamp()


def timeband(session: str, q0_time: float) -> int:
    """
    機能: 判断q0をデイ/NY09:30厳密前/等号以後へ区分する。
    引数: session(str)は場名、q0_time(float)は当時判断のUTC秒。
    返り値: intはDAY=0/PRE_US=1/POST_US=2。静観や境界返済を加えない。
    """
    assert type(q0_time) in (int, float) and math.isfinite(q0_time)
    boundary = us_open_time(session)
    return DAY if boundary is None else PRE_US if q0_time < boundary else POST_US


def feature_dataset_from_objects(columns: list | tuple, buy_X: np.ndarray, sell_X: np.ndarray, q0_meta: list[dict], scenes: list[dict], sources: dict | None = None, expected_sessions: int | None = None, expected_rows: int | None = None) -> FeatureDataset:
    """
    機能: 旧100特徴を実買/実売のまま保持し、識別時計だけから三時間帯を付ける。
    引数: columns(list又はtuple)、buy_X/sell_X(np.ndarray)、q0_meta/scenes(list[dict])、sources(dict又はNone)、expected_sessions/expected_rows(int又はNone)。
    返り値: FeatureDataset。非有限Infinityを拒否し、未知NaNと数値0を区別する。
    """
    names = tuple(columns)
    assert len(names) == len(set(names)) == 100 and list(names) == sorted(names)
    buy, sell = np.array(buy_X, dtype=np.float64, copy=True), np.array(sell_X, dtype=np.float64, copy=True)
    assert buy.shape == sell.shape == (len(q0_meta), 100) and not np.isinf(buy).any() and not np.isinf(sell).any()
    assert expected_rows is None or len(q0_meta) == expected_rows
    assert scenes and (expected_sessions is None or len(scenes) == expected_sessions)
    scene_map = {}
    for index, scene in enumerate(scenes):
        assert set(scene) == SCENE_KEYS and scene["session"] not in scene_map
        assert all(type(scene[k]) in (int, float) and math.isfinite(scene[k]) for k in ("start", "end", "force_close"))
        assert scene["start"] < scene["force_close"] <= scene["end"]
        if index:
            assert scenes[index-1]["end"] <= scene["start"] and scenes[index-1]["session"] < scene["session"]
        scene_map[scene["session"]] = (index, scene)
    previous, seen, bands = None, set(), []
    for row in q0_meta:
        assert set(row) == Q0_KEYS and row["event_id"] not in seen
        seen.add(row["event_id"])
        index, scene = scene_map[row["session"]]
        assert row["session_index"] == index and row["contract"] == scene["contract"]
        assert type(row["q0_index"]) is int and row["q0_index"] >= 0 and type(row["q0_line"]) is int and row["q0_line"] > 0
        assert scene["start"] <= row["q0_time"] <= scene["end"]
        order = (index, row["q0_index"], row["q0_line"], row["event_id"])
        assert previous is None or order > previous
        previous = order
        bands.append(timeband(row["session"], row["q0_time"]))
    return FeatureDataset(names, buy, sell, copy.deepcopy(q0_meta), copy.deepcopy(scenes), np.array(bands, dtype=np.int8), copy.deepcopy(sources or {}))


def load_feature_dataset(npz_ref: FileRef = FEATURE_NPZ, meta_ref: FileRef = FEATURE_META, expected_sessions: int | None = 73, expected_rows: int | None = 35339) -> FeatureDataset:
    """
    機能: SHA固定済み旧151の特徴専用cacheだけを読み、教師を受け取らない。
    引数: npz_ref/meta_ref(FileRef)、expected_sessions/expected_rows(int又はNone)は期待個数。
    返り値: FeatureDataset。自然入力での実行は161のF0後に限る。
    """
    arrays, a = read_npz_ref(npz_ref, {"buy_X", "sell_X", "columns"})
    meta, b = read_json_ref(meta_ref)
    assert meta["success"] and meta["trial"] == 151 and meta["label_fields_present"] is False
    result = feature_dataset_from_objects(arrays["columns"].tolist(), arrays["buy_X"], arrays["sell_X"], meta["q0_meta"], meta["scenes"], meta["sources"], expected_sessions, expected_rows)
    result.sources["cache161"] = {"npz": a, "meta": b, "projection_source_sha256": OLD_DATA_SOURCE_SHA256}
    return result


# ----------------------------------------
def teacher_dataset_from_objects(feature_meta: FeatureMetadata, arrays: dict, meta: dict) -> TeacherDataset:
    """
    機能: 全体正準の旧物理pairと両側厳密H60教師を検査し、正準q0の帯を対応させる。
    引数: feature_meta(FeatureMetadata)、arrays(dict[str,np.ndarray])、meta(dict)は特徴識別と旧教師cache。
    返り値: TeacherDataset。帯ごとの再正準化・現在場学習選択・成熟判定は行わない。
    """
    assert isinstance(feature_meta, FeatureMetadata) and meta["success"] and meta["trial"] == 151
    assert tuple(arrays["side_order"].tolist()) == SIDE_ORDER and tuple(meta["side_order"]) == SIDE_ORDER
    assert arrays["labels"].dtype.kind == arrays["known_at"].dtype.kind == "f" and arrays["pair_complete"].dtype.kind == "b"
    assert arrays["event_to_teacher_index"].dtype.kind in "iu" and arrays["canonical_feature_index"].dtype.kind in "iu"
    if "fixed" in feature_meta.sources and "fixed" in meta["sources"]:
        assert feature_meta.sources["fixed"]["sha256"] == meta["sources"]["fixed"]["sha256"]
    rows = copy.deepcopy(meta["rows"])
    labels = np.array(arrays["labels"], dtype=np.float64, copy=True)
    pair = np.array(arrays["pair_complete"], dtype=np.bool_, copy=True)
    known = np.array(arrays["known_at"], dtype=np.float64, copy=True)
    event_map = np.array(arrays["event_to_teacher_index"], dtype=np.int64, copy=True)
    canonical = np.array(arrays["canonical_feature_index"], dtype=np.int64, copy=True)
    count, features = len(rows), feature_meta.q0_meta
    assert labels.shape == (count, 2) and pair.shape == known.shape == canonical.shape == (count,)
    assert event_map.shape == (len(features),) and len(feature_meta.q0_timeband) == len(features)
    assert ((event_map >= -1) & (event_map < count)).all() and ((canonical >= 0) & (canonical < len(features))).all()
    assert not np.isinf(labels).any() and not np.isinf(known).any() and np.isin(labels[pair], (-1, 0, 1)).all()
    assert np.isfinite(known[pair]).all() and np.isnan(labels[~pair]).all() and np.isnan(known[~pair]).all()
    rebuilt = np.full(len(features), -1, dtype=np.int64)
    seen_cases, previous = set(), None
    for index, row in enumerate(rows):
        fi = int(canonical[index])
        q0 = features[fi]
        assert row["case_id"] not in seen_cases and row["feature_index"] == fi
        seen_cases.add(row["case_id"])
        assert all(row[key] == q0[key] for key in Q0_KEYS)
        aliases = row["alias_feature_indices"]
        assert aliases and len(aliases) == len(set(aliases)) and all(0 <= i < len(features) for i in aliases)
        assert aliases == sorted(aliases, key=lambda i: (features[i]["q0_index"], features[i]["q0_line"], features[i]["event_id"])) and aliases[0] == fi
        assert row["aliases"] == [features[i]["event_id"] for i in aliases]
        assert all(features[i]["session"] == q0["session"] and features[i]["contract"] == q0["contract"] for i in aliases)
        assert (rebuilt[aliases] == -1).all()
        rebuilt[aliases] = index
        assert row["pair_complete"] is bool(pair[index])
        if pair[index]:
            assert [row["label_buy"], row["label_sell"]] == labels[index].tolist() and row["known_at"] == known[index] and known[index] > q0["q0_time"]
        else:
            assert row["label_buy"] is row["label_sell"] is row["known_at"] is None
        order = (row["session_index"], row["q0_index"], row["q0_line"], row["event_id"], row["case_id"])
        assert previous is None or order > previous
        previous = order
    assert np.array_equal(event_map, rebuilt)
    return TeacherDataset(rows, labels, pair, known, event_map, canonical, feature_meta.q0_timeband[canonical].copy(), copy.deepcopy(meta["counts"]), copy.deepcopy(meta["sources"]))


def load_teacher_dataset(feature_meta: FeatureMetadata, npz_ref: FileRef = TEACHER_NPZ, meta_ref: FileRef = TEACHER_META) -> TeacherDataset:
    """
    機能: 特徴Xを引数へ受けず旧151の厳密H60物理pair教師cacheを読む。
    引数: feature_meta(FeatureMetadata)、npz_ref/meta_ref(FileRef)は識別と固定入力参照。
    返り値: TeacherDataset。過去20場・strict成熟・支持下限はモデル側で適用する。
    """
    arrays, a = read_npz_ref(npz_ref, {"labels", "pair_complete", "known_at", "event_to_teacher_index", "canonical_feature_index", "side_order"})
    meta, b = read_json_ref(meta_ref)
    result = teacher_dataset_from_objects(feature_meta, arrays, meta)
    result.sources["cache161"] = {"npz": a, "meta": b, "projection_source_sha256": OLD_DATA_SOURCE_SHA256}
    return result


# ----------------------------------------
def load_original_projection(source_path: Path = ROOT / "work/151過去場判別/data151.py") -> object:
    """
    機能: 正式151から復元できる旧射影SourceをSHA固定で読み込み、実行入口は呼ばない。
    引数: source_path(Path)は元151のdata151.py又は同体の隔離復元先。
    返り値: objectは旧射影module。学習・採否・金融・Raw読取を行わない。
    """
    assert sha(source_path) == OLD_DATA_SOURCE_SHA256
    name = "固定151データ射影_161再用"
    spec = importlib.util.spec_from_file_location(name, source_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    assert sha(source_path) == OLD_DATA_SOURCE_SHA256
    return module


def load_feature_from_formal(source_path: Path = ROOT / "work/151過去場判別/data151.py") -> FeatureDataset:
    """
    機能: 旧cacheが無い環境でも正式148の共有2gzipから同じ全q0特徴を射影する。
    引数: source_path(Path)はSHA固定した旧151の射影Source。
    返り値: FeatureDataset。派生cache副本やRaw走査を作らずF0後のみ実行する。
    """
    original = load_original_projection(source_path)
    data = original.load_feature_dataset(FORMAL_REFS["features"], FORMAL_REFS["fixed"])
    sources = copy.deepcopy(data.sources)
    sources["formal161"] = {"projection_source_sha256": OLD_DATA_SOURCE_SHA256, "cache_used": False}
    return feature_dataset_from_objects(data.columns, data.buy_X, data.sell_X, data.q0_meta, data.scenes, sources, 73, 35339)


def load_teacher_from_formal(feature_meta: FeatureMetadata, source_path: Path = ROOT / "work/151過去場判別/data151.py") -> TeacherDataset:
    """
    機能: 正式148の共有4gzipと旧151射影から厳密H60教師を復元する。
    引数: feature_meta(FeatureMetadata)、source_path(Path)はXを含まない識別と固定旧Source。
    返り値: TeacherDataset。大観測の解凍はメモリだけとし、学習選択は行わない。
    """
    original = load_original_projection(source_path)
    old_meta = original.FeatureMetadata(copy.deepcopy(feature_meta.q0_meta), copy.deepcopy(feature_meta.scenes), copy.deepcopy(feature_meta.sources))
    data = original.project_teacher(old_meta, FORMAL_REFS["captures"], FORMAL_REFS["metadata"], FORMAL_REFS["fixed"], FORMAL_REFS["observations"])
    arrays = {key: getattr(data, key) for key in ("labels", "pair_complete", "known_at", "event_to_teacher_index", "canonical_feature_index")}
    arrays["side_order"] = np.array(SIDE_ORDER, dtype=np.int64)
    meta = {"success": True, "trial": 151, "rows": data.rows, "counts": data.counts, "sources": data.sources, "side_order": list(SIDE_ORDER)}
    result = teacher_dataset_from_objects(feature_meta, arrays, meta)
    result.sources["formal161"] = {"projection_source_sha256": OLD_DATA_SOURCE_SHA256, "cache_used": False}
    return result


# ----------------------------------------
def legacy_signals_from_metadata(metadata: dict, expected_count: int | None = 87) -> list[dict]:
    """
    機能: C1の当時出生と取得を明示分離し、観測側のbirth=entryを使用しない。
    引数: metadata(dict)は正式148入口参照、expected_count(int又はNone)は旧C1件数。
    返り値: list[dict]は旧信号時計・実取得時計・固定方向・由来。新研究q0とは別集合。
    """
    assert metadata["success"] and metadata["trial"] == 148 and metadata["financial_labels_used"] is False
    entries = metadata["entries"]
    assert expected_count is None or len(entries) == expected_count
    result, seen, stamps = [], set(), set()
    for entry in entries:
        assert entry["id"] not in seen and len(entry["origins"]) == 1
        seen.add(entry["id"])
        origin = entry["origins"][0]
        birth, acquired = origin["birthQuote"], entry["entry_quote"]
        assert all(type(q[k]) is int and q[k] >= (1 if k == "source_line" else 0) for q in (birth, acquired) for k in ("index", "source_line"))
        assert all(type(q["time"]) in (int, float) and math.isfinite(q["time"]) for q in (birth, acquired))
        assert birth["time"] + 1 <= acquired["time"] and birth["index"] < acquired["index"] and birth["source_line"] < acquired["source_line"]
        assert acquired["quote_ok"] and 0 < acquired["bid"] < acquired["ask"]
        assert type(entry["native_side"]) is int and entry["native_side"] in (-1, 1)
        if entry["model"] == "C0":
            assert origin["birth_quote_source"] == "metadata.birth.quote" and origin["entryQuote"] == acquired
        else:
            assert entry["model"] in ("A0", "B0") and origin["family"] == entry["model"]
        physical = (entry["session"], entry["contract"], acquired["time"], acquired["index"], acquired["source_line"])
        assert physical not in stamps
        stamps.add(physical)
        result.append({"case_id": entry["id"], "session": entry["session"], "contract": entry["contract"], "side": entry["native_side"], "model": entry["model"], "signal_quote": copy.deepcopy(birth), "entry_quote": copy.deepcopy(acquired), "signal_clock_source": origin.get("birth_quote_source", "145.event.birth"), "source_locator": copy.deepcopy(origin["source_locator"]), "source_file_sha": origin.get("source_file_sha"), "limitations": origin.get("original_execution", "145の出生/取得票を継承。Raw再走査なし")})
    return sorted(result, key=lambda r: (r["session"], r["signal_quote"]["index"], r["signal_quote"]["source_line"], r["case_id"]))


def load_legacy_signals(ref: FileRef = LEGACY_META) -> tuple[list[dict], dict]:
    """
    機能: 正式148の指紋を確認してC1出生/取得時計を読み出す。
    引数: ref(FileRef)は物理・解凍SHAを固定した148入口参照。
    返り値: tuple[list[dict],dict]は旧87信号と入力証跡。採否・損益は計算しない。
    """
    metadata, evidence = read_json_ref(ref)
    return legacy_signals_from_metadata(metadata), evidence
