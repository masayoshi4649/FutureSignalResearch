"""既知の最初IFD到達を主分類にし、全条件の方向反転を実BBOで比較する。"""
from pathlib import Path
import sys
import json
import time
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00164_IFD最初到達の確定時計で入口と反転を比較する'
BOOK_SHA='e415f92ee290b8adad74e378255432e384114d67abe16082505af06a10b65f5d'
sys.path.insert(0,str(ROOT/'work/163入口と任意幅'))
from 共通163 import read,save,sha
from 評価163 import Context163,summary_cube,materialize,FIELDS,PERIODS,INTEGRATIONS,ENTRY_MODES

ORIENTATIONS=('NORMAL','REVERSE')


class Context164(Context163):
    """金融を変えず、最初IFD到達の分類と成熟だけを追加する。"""
    def __init__(self) -> None:
        """
        機能: 旧strictの既知touchを未来完了によって除かず主labelへする。
        引数: self(Context164)。
        返り値: None。旧label・金額を保持し、未知Cを推定で補わない。
        """
        super().__init__()
        self.strict_labels=self.arrays['label'];self.strict_maturity=self.arrays['known_at']
        direction=self.table.arrays['direction'];known=self.arrays['known']
        assert np.isin(direction,(-1,0,1)).all() and np.all(known[direction!=0])
        labels=np.where(direction!=0,direction,self.strict_labels).astype(np.int8)
        assert np.array_equal(labels[self.strict_labels!=2],self.strict_labels[self.strict_labels!=2])
        assert np.array_equal(labels==2,~known)
        maturity=np.where(direction!=0,self.arrays['exit_time'],self.strict_maturity)
        assert np.array_equal(np.isfinite(maturity),labels!=2)
        self.arrays={**self.arrays,'label':labels,'known_at':maturity}
        self.reclassification={'old_C':int((self.strict_labels==2).sum()),'new_C':int((labels==2).sum()),
            'C_to_F':int(((self.strict_labels==2)&(labels==1)).sum()),
            'C_to_A':int(((self.strict_labels==2)&(labels==-1)).sum()),'financial_changed':False}


def ready_mask(array: np.ndarray, setting: dict) -> np.ndarray:
    """
    機能: 固定した報告支持・品質・前後収支で発見候補を抽出する。
    引数: array(np.ndarray)は任意候補軸×期間×指標、setting(dict)は164固定条件。
    返り値: np.ndarray[bool]は報告支持を満たす候補軸mask。
    """
    f={name:i for i,name in enumerate(FIELDS)};full=array[...,0,:];front=array[...,1,:];back=array[...,2,:]
    return (full[...,f['count']]>=setting['minimum_count'])&(full[...,f['new_count']]>=setting['minimum_new_count'])&\
        (full[...,f['F']]+full[...,f['A']]>=setting['minimum_resolved'])&\
        (front[...,f['F']]+front[...,f['A']]>=setting['minimum_resolved_each_period'])&\
        (back[...,f['F']]+back[...,f['A']]>=setting['minimum_resolved_each_period'])&\
        (full[...,f['all_scenes']]==1)&(full[...,f['rate']]>=setting['minimum_rate'])&\
        (front[...,f['rate']]>=setting['minimum_rate_each_period'])&(back[...,f['rate']]>=setting['minimum_rate_each_period'])&\
        (full[...,f['unknown']]<=setting['maximum_financial_unknown_fraction']*full[...,f['count']])&\
        (front[...,f['net']]>setting['minimum_known_net_each_period'])&(back[...,f['net']]>setting['minimum_known_net_each_period'])


# ----------------------------------------
def main() -> None:
    """
    機能: 新規1460条件のNORMAL/REVERSEを12幅4期限で測り、旧strict対照を残す。
    引数: なし。164条件と163固定出生/Raw数値表を参照する。
    返り値: None。主統計NPZ・分類差分・発見上位JSONを保存する。
    """
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    setting=read(TRIAL/'条件.json');out=HERE/'比較';assert not out.exists()
    parent=ROOT/'work/163入口と任意幅';proof=read(parent/'全出生/全出生の確認.json')
    assert proof['成功'] and proof['金融未入力']
    paths=[Path(__file__),parent/'評価163.py',parent/'共通163.py',ROOT/'work/162入口探索/評価基盤.py',
        parent/'全出生/全出生の確認.json',ROOT/'work/163任意幅の数値化/arrays163.py']
    before={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    save(TRIAL/'検査/F0_最初到達比較前.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと全出生':before,
        '方向反転は定数−1を全q0へ掛けるのみ':True,'未知補完なし':True})
    context=Context164();out.mkdir();begin=time.monotonic()
    ids=proof['規則順'];nr=len(ids);nw=len(context.table.widths);nh=len(context.table.horizons)
    metrics=np.full((nr,2,2,nw,nh,3,3,len(FIELDS)),np.nan)
    old=context.old_controls();old_metrics=np.full((len(old),nw,nh,3,len(FIELDS)),np.nan)
    for wi,width in enumerate(context.table.widths):
        path=parent/'全出生'/f'出生{int(width)}.npz';assert sha(path)==proof['files'][path.name]['sha256']
        with np.load(path,allow_pickle=False) as source:matrices={mode:source[mode].copy() for mode in ENTRY_MODES}
        for mi,mode in enumerate(ENTRY_MODES):
            for oi,orientation in enumerate(ORIENTATIONS):
                sign=1 if orientation=='NORMAL' else -1
                for ri,rule in enumerate(ids):
                    new=context.link(sign*matrices[mode][ri])
                    for ii,integration in enumerate(INTEGRATIONS):
                        selected=context.integrate(new,integration)
                        metrics[ri,mi,oi,wi,:,ii]=summary_cube(context,selected,wi)
        for ci,selected in enumerate(old.values()):old_metrics[ci,wi]=summary_cube(context,selected,wi)
        print(json.dumps({'幅':width,'NORMAL/REVERSE完了':True,'経過秒':round(time.monotonic()-begin)},ensure_ascii=False),flush=True)
    np.savez_compressed(out/'最初到達の統計配列.npz',metrics=metrics,controls=old_metrics)
    unchanged=[i for i,name in enumerate(FIELDS) if name not in ('F','A','N','C','rate','complete_rate','all_rate')]
    with np.load(parent/'広い評価/全探索の統計配列.npz',allow_pickle=False) as source:
        previous=source['fixed']
    current=metrics[:,:,0]
    assert np.array_equal(np.take(current,unchanged,axis=-1),np.take(previous,unchanged,axis=-1),equal_nan=True)
    save(out/'分類差分と金融不変.json',{'成功':True,'reclassification':context.reclassification,
        'NORMALの全取得と金融不変':True,'不変指標':[FIELDS[i] for i in unchanged],
        '既存strict参照':{'path':str((parent/'広い評価/全探索の統計配列.npz').relative_to(ROOT)),
            'sha256':sha(parent/'広い評価/全探索の統計配列.npz')}})
    save(out/'統計軸.json',{'成功':True,'trial':164,'規則順':ids,'発火方式':ENTRY_MODES,'方向':ORIENTATIONS,
        '幅':context.table.widths,'時計':context.table.horizons,'統合':INTEGRATIONS,'期間':PERIODS,'指標':FIELDS,
        '旧対照順':list(old),'shape':list(metrics.shape),'主label':'IFD_FIRST','旧label':'STRICT_Hを163へ保持'})
    columns={name:i for i,name in enumerate(FIELDS)}
    positions=np.argwhere(ready_mask(metrics,setting['discovery_support']))
    positions=sorted(positions,key=lambda p:(-metrics[tuple(p)][0,columns['count']],-metrics[tuple(p)][0,columns['rate']]))
    found=[]
    for p in positions[:200]:
        ri,mi,oi,wi,hi,ii=map(int,p)
        found.append({'rule':ids[ri],'entry_mode':ENTRY_MODES[mi],'orientation':ORIENTATIONS[oi],
            'width':context.table.widths[wi],'horizon':context.table.horizons[hi],'integration':INTEGRATIONS[ii],
            'position':p.tolist(),'periods':materialize(metrics[tuple(p)])})
    save(out/'有望な発見候補.json',{'成功':True,'全期探索で未採用':True,'総政策数':nr*2*2*nw*nh*3,
        '報告支持合格':len(positions),'preferred_frequency':setting['discovery_support']['frequency_preferred_per_hour'],
        'preferred_frequency合格':int(sum(metrics[tuple(p)][0,columns['per_hour']]>=.8 for p in positions)),
        'fixed':found})
    assert all(sha(ROOT/p)==v for p,v in before.items())
    save(out/'完了.json',{'成功':True,'条件SHA256':BOOK_SHA,'Source':before,'経過秒':time.monotonic()-begin,
        'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()}})
    print(json.dumps({'成功':True,'報告支持合格':len(positions),'上位':found[:4]},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
