"""173の固定済み段階結果を読み、短表による取りこぼしを事後診断する。再選択・再生はしない。"""

from __future__ import annotations

import gzip
import hashlib
import importlib.util
import json
from pathlib import Path


根 = Path(__file__).resolve().parents[2]
入力先 = 根 / "work/173両中央値と単一建玉"
出力先 = Path(__file__).resolve().parent


def 読む(名前: str) -> dict:
    """機能: 固定済みJSON又はgzip JSONを読む。

    引数: 名前 (str) は入力先からのファイル名。
    返り値: dictは内容。入力ファイルは変更しない。
    """
    内容 = (入力先 / 名前).read_bytes()
    return json.loads(gzip.decompress(内容) if 名前.endswith(".gz") else 内容)


def 両立する(行: dict, 期間: str, 帯: str) -> bool:
    """機能: 保存済みの両中央値適合と先着70%以上を共同判定する。

    引数: 行 (dict) は一政策、期間/帯 (str) は参照軸。
    返り値: bool。未知を除いた中央値で適合を作らない。
    """
    群 = 行["periods"][期間][帯]
    return 群["decision"]["status"] == "適合" and (群["trades"]["IFD_FIRSTFANC"]["first_f_rate_reached"] or 0) >= .7


def 要約する(行: dict, 期間: str, 帯: str, 選択器: object) -> dict:
    """機能: 率・両中央値・場支持・0場・未知を小さい数値表へ写す。

    引数: 行 (dict)、期間/帯 (str)、選択器 (object) は凍結した173の支持判定。
    返り値: dictは既知成績の要約。金額は全件確定と称さない。
    """
    g = 行["periods"][期間][帯]
    t, s = g["trades"], g["sessions"]
    fa = t["IFD_FIRSTFANC"]
    return {"id": 行["id"], "route": 行["policy"]["route"], "period": 期間, "band": 帯,
        "両中央値": g["decision"]["status"], "共同適合": 両立する(行, 期間, 帯),
        "支持層": 選択器.support(g), "取得": t["all_count"], "F": fa["F"], "A": fa["A"],
        "先着率": fa["first_f_rate_reached"], "到達場": g["resolved_scene_count"],
        "建玉中央値下界": t["net_median"]["lower"], "場中央値下界": s["net_median"]["lower"],
        "取引0場": s["zero_acquisition_count"], "全場": s["eligible_count"],
        "既知差引": t["known_net"], "金融未知": t["unknown_count"],
        "最終jointの支持も満たす": t["all_count"] >= 24 and fa["reached_count"] >= 12
            and g["resolved_scene_count"] >= 6 and t["known_net"] > 0,
        "families": 行["policy"]["families"]}


def 主処理() -> None:
    """機能: 段階ごとの共同適合の保持を照合し、短い事後診断を保存する。

    引数: なし。
    返り値: None。work/173選択診断だけへJSONとMarkdownを保存する。
    """
    spec = importlib.util.spec_from_file_location("choose173_for_diagnosis", 入力先 / "数量候補を選ぶ.py")
    selector = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(selector)
    段階 = {名前: 読む(名前 + ".json.gz")["rows"] for 名前 in ["単独global1", "異技術ORglobal1", "Night接合global1", "三帯接合global1"]}
    選択 = {名前: 読む(名前 + ".json")["選択"] for 名前 in ["単独global1の短表", "帯ごとの数量短表", "Night接合の短表"]}
    件数表 = []
    for 名前, 行集合 in 段階.items():
        for route in ["全期", "前48"]:
            帯集合 = ["NIGHT"] if 名前 == "Night接合global1" else ["DAY", "NIGHT"] if 名前 == "三帯接合global1" else ["DAY", "PRE", "POST"]
            for 帯 in 帯集合:
                部分 = [行 for 行 in 行集合 if 行["policy"]["route"] == route and (名前 == "三帯接合global1" or 行["policy"]["band"] == 帯)]
                med = [行 for 行 in 部分 if 行["periods"][route][帯]["decision"]["status"] == "適合"]
                good = [行 for 行 in 部分 if 両立する(行, route, 帯)]
                件数表.append({"段階": 名前, "ルート": route, "帯": 帯, "政策数": len(部分), "両中央値適合": len(med), "両中央値と70%": len(good)})
    Night = {}
    for route in ["全期", "前48"]:
        元 = [行 for 行 in 段階["Night接合global1"] if 行["policy"]["route"] == route]
        採用 = 選択["Night接合の短表"][route]["NIGHT"]
        採用ID = {行["id"] for 行 in 採用}
        good = [行 for 行 in 元 if 両立する(行, route, "NIGHT")]
        Night[route] = {"共同適合数": len(good), "共同適合の保持数": sum(行["id"] in 採用ID for 行 in good),
            "共同適合の要約": [要約する(行, route, "NIGHT", selector) | {"保持": 行["id"] in 採用ID} for 行 in good],
            "選ばれた政策": [要約する(next(元行 for 元行 in 元 if 元行["id"] == 行["id"]), route, "NIGHT", selector) | {"選択観点": 行["selected_by"]} for 行 in 採用],
            "選ばれた政策の全期": [要約する(next(元行 for 元行 in 元 if 元行["id"] == 行["id"]), "全期", "NIGHT", selector) for 行 in 採用]}
    Day = {}
    for route in ["全期", "前48"]:
        元 = [行 for 名前 in ["単独global1", "異技術ORglobal1"] for 行 in 段階[名前] if 行["policy"]["route"] == route and 行["policy"]["band"] == "DAY"]
        med = [行 for 行 in 元 if 行["periods"][route]["DAY"]["decision"]["status"] == "適合"]
        med.sort(key=lambda 行: (-(行["periods"][route]["DAY"]["trades"]["IFD_FIRSTFANC"]["first_f_rate_reached"] or 0), 行["id"]))
        Day[route] = {"既存再生で共同適合数": sum(両立する(行, route, "DAY") for 行 in 元),
            "両中央値適合の率上位": [要約する(行, route, "DAY", selector) for 行 in med[:3]]}
    参照名 = [名前 + ".json.gz" for 名前 in 段階] + [名前 + ".json" for 名前 in 選択] + ["段階再生173.py", "数量候補を選ぶ.py"]
    指紋 = {名前: hashlib.sha256((入力先 / 名前).read_bytes()).hexdigest() for 名前 in 参照名}
    結果 = {"確認日": "2026-11-15", "性質": "173旧73の保存結果に対する事後診断。追加7未使用。固定Source・短表・政策・結果は変更しない",
        "件数": 件数表, "Nightの保持": Night, "Dayの現状": Day, "参照SHA256": 指紋}
    (出力先 / "選択診断.json").write_text(json.dumps(結果, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    文章 = ["# 173・共同条件の短表保持診断", "", "2026-11-15。旧73場の固定済み結果に対する事後診断。全期はDay37/Night36、前48はDay24/Night24。追加7を選択に使わず、凍結Sourceと173正本は変更していない。", "", "## 結論", "", "全期Night接合128組には両中央値適合＋先着70%以上が8組あるが、次段短表では0組になった。全期の三帯jointでNightの共同適合が0なのは、Night候補が不存在だったためではない。全期Dayは単独31＋OR/旧補完54の既存再生に共同適合が0であり、再生済み結果の選び直しだけでは解決しない。", "", "## Nightの取りこぼし", "", "全期の共同適合8組は全て通常支持2かつ最終jointの取得24/到達12/到達場6/既知差引正も満たす。代表の全期_N001_N0は53取得・17F/1A=94.4444%、建玉中央値下界10,923円・場中央値下界9,884.5円、0場6/36、既知差引723,227円・未知4件。全期_N009_N0は同じ要約成績。", "", "現chooseは共同適合層を予約しない。先着支持枠は15F/0A=100%のN048/N056を選ぶが、0場19/36で場中央値0円。両中央値枠はN023/N031の64.5833%、参加枠はN017_T/N025_Tの65.4545%を選ぶ。疎補完枠は支持層1だけで、通常支持の共同適合8組を救済しない。群上限に落とされたというより、別々の目的の極端な政策が各枠を占めた。似た結果の政策2本が各枠を占めている点もある。", "", "前48Nightは24共同適合中6を保持し、選択期間内では取りこぼしによる全滅はない。ただし、その6政策に全期共同適合は0。前48ルート内で全期共同適合の4組は別に存在するが、それを全期を見て救済するのは後選択である。既使用の前48選択と新未見検証を混同しない。", "", "次試行では『両中央値＋70%＋支持』適格を最低2枠予約し、その層内では0場の少なさ、場/建玉中央値下界、未知、先着支持の順に比較する。全場参加を満たす政策があればその部分層も予約する。これは173を見た後の選択改善案であり、173へ遡及適用しない。", "", "## Dayの不足", "", "両中央値適合の中で最も高い全期率は全期_DAY_S004_Tの24F/12A=66.6667%。51取得、取引0場0/37、建玉中央値18,923円・場中央値3,923円、未知0。前48の最高も66.6667%。これらは既存短表内に残っており、全期Dayの共同適合候補を数量選択が捨てたとはいえない。", "", "173のStage1では31設定しかglobal1へ進めていないため、探索母集団全体の不存在までは言えない。174ではSource×技術群×向き×発火方式を分け、率・参加・既知差引の複数観点、幅/期限の派生を広く残してglobal1を再生する必要がある。独立screenからの率や中央値をglobal1の代用とせず、173のDay31は対照として全て包含する。", "", "## 再現", "", "`python work/173選択診断/173選択を診断する.py`。個別数値、8組/24組の保持、入力SHAは選択診断.json。新候補の選定・再生は本Sourceでは行わない。", ""]
    (出力先 / "診断.md").write_text("\n".join(文章), encoding="utf-8")
    print(json.dumps({"成功": True, "Night全期共同": Night["全期"]["共同適合数"], "Night全期保持": Night["全期"]["共同適合の保持数"]}, ensure_ascii=True))


if __name__ == "__main__":
    主処理()
