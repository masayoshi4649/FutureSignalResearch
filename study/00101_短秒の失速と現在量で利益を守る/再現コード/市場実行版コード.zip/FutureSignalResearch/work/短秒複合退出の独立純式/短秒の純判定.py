"""S5Q/S515Qを公開Inputと実保有方向だけから独立計算する。金融/市場は呼ばない。"""

import copy
import hashlib
import importlib.util
import math
from pathlib import Path
import sys


ROOT=Path(__file__).resolve().parents[2]
X5_PATH=ROOT/"work/101X5独立純式/X5の純判定.py"
X5_SHA="d927cc9ad9139a40a8aec9ef099eda5ffc226717fbaa8e8df8043942aab5dd7b"
if hashlib.sha256(X5_PATH.read_bytes()).hexdigest()!=X5_SHA:raise ValueError("固定X5独立のSHA差")
SPEC=importlib.util.spec_from_file_location("X5公開品質だけ_短秒独立",X5_PATH)
X5=importlib.util.module_from_spec(SPEC);sys.modules[SPEC.name]=X5;SPEC.loader.exec_module(X5)
need=X5.need;f=X5.f;flag=X5.flag


def current_quantity(incoming,side,price_known):
    """
    機能: 同Current出典のDay OFI/Night四量差を仕様から抽出する。
    引数: incoming(dict)、side(int)、price_known(bool)は公開Input/実側/現在品質。
    返り値: tuple[dict,float|None]は量根拠と方向付き値。X5のP/M/採否は使わない。
    """
    c=incoming["current"];time=f(c["time"])
    q={"kind":incoming["kind"],"known":False,"time":0.0,"index":0,"own_at":0.0,"value":None,
       "bid_refill":None,"ask_refill":None,"bid_deplete":None,"ask_deplete":None}
    raw=0.0
    if incoming["kind"]=="Day":
        v=c["buy" if side==1 else "sell"];q.update(time=time,index=c["source_index"],own_at=f(v["own_at"]))
        known=bool(price_known and v["ofi_known"] and f(v["own_at"])==time);raw=f(v["ofi30"])
    else:
        n=c["night"];b=n["band"];q.update(time=f(b["time"]),index=b["index"])
        known=bool(price_known and n["available"] and n["window"]=="E08" and b["quantity_known"] and f(b["time"])==time and b["index"]==c["source_index"])
        if known:
            raw=f(b["bid_refill"])+f(b["ask_deplete"])-f(b["ask_refill"])-f(b["bid_deplete"])
            q.update({name:f(b[name]) for name in ("bid_refill","ask_refill","bid_deplete","ask_deplete")})
    need(math.isfinite(raw),"派生量が非有限")
    q["known"]=known
    if known:q["value"]=raw
    return q,float(side)*raw if known else None


def window(value,current,width,side,price_known):
    """
    機能: 既知の短秒窓の元pt/秒・両端・実経過の整合を検査する。
    引数: value/current(dict)、width(float,5/15)、side(int)、price_known(bool)は公開値。
    返り値: dictは窓全文と利用既知性/方向速度。未知は0へ補完しない。
    """
    known=flag(value["known"]);out={"known":False,"window":copy.deepcopy(value),"signed_speed":None}
    if not known:return out
    short=current["short"];time=f(short["time"]);elapsed=f(value["elapsed"]);speed=f(value["speed"]);move=f(value["move"])
    need(time==f(current["time"]) and f(short["mid"])>0 and f(short["mid"])==f(current["bid"])+(f(current["ask"])-f(current["bid"]))/2,"既知短秒の時計/中値")
    need(elapsed>=width and elapsed==time-f(value["endpoint"]) and f(value["endpoint"])<=time-width,"既知短秒の実経過/両端")
    need(f(value["delay"])==elapsed-width and 0<=f(value["delay"])<=15,"既知短秒の遅れ")
    need(abs(speed-move/elapsed)<=1e-12*max(1,abs(speed)),"既知短秒のpt/秒単位")
    out["known"]=price_known
    if price_known:out["signed_speed"]=float(side)*speed
    return out


def validate(incoming,side,policy):
    """
    機能: 固定X5の公開品質を候補なしで再用し、短秒固有の既知窓を検査する。
    引数: incoming(dict)、side(int)、policy(str,S5Q/S515Q)は公開Input/実側/政策。
    返り値: None。旧X5の判断/P/MをS採否へ入れない。
    """
    need(policy in ("S5Q","S515Q"),"短秒政策")
    X5.validate(incoming,side)
    # ----------------------------------------
    # 元Goが再用するX5の未使用派生差も、数値破損だけを同じ範囲で拒否する。
    t=incoming["chart"]["chart"]["Technical"];at=f(incoming["at"]);end=f(t["bar3_end"])
    role_known=incoming["chart"]["three"]["data_known"] and end>0 and at-end<180 and t["exit_known"]
    if role_known:
        need(math.isfinite(f(t["close3"])-f(t["ema8_3"])) and math.isfinite(f(t["histogram3"])-f(t["previous_histogram3"])),"旧公開品質の派生差が非有限")
    window(incoming["current"]["short"]["five"],incoming["current"],5.0,side,False)
    window(incoming["current"]["short"]["fifteen"],incoming["current"],15.0,side,False)


def assess(incoming,side,policy):
    """
    機能: 短秒速度と現在量のstrict反対を三値ANDで独立計算する。
    引数: incoming(dict)、side(int)、policy(str)は公開値/実方向/政策。
    返り値: dictはdecision/checks/evidence全値。入力/金融状態は変更しない。
    """
    validate(incoming,side,policy)
    c=incoming["current"];at=f(incoming["at"]);time=f(c["time"])
    price=bool(c["reference"]=="NK225" and time>0 and c["source_index"]>=0 and c["source_line"]>0 and f(c["last"])>0 and 0<f(c["bid"])<f(c["ask"]) and at-time<=15)
    five=window(c["short"]["five"],c,5.0,side,price);fifteen=window(c["short"]["fifteen"],c,15.0,side,price)
    q,signed=current_quantity(incoming,side,price)
    e={"scene_id":incoming["chart"]["scene"]["id"],"contract":incoming["chart"]["scene"]["contract"],
       "current":{n:copy.deepcopy(c[n]) for n in ("reference","time","received","source_index","source_line","last","bid","ask")},
       "price_age":at-time if time>0 else None,"short_time":f(c["short"]["time"]),"short_mid":f(c["short"]["mid"]),
       "five":five,"fifteen":fifteen,"quantity":q,"signed_quantity":signed}
    rows=[("S.現在価格時計",price,True,"正常なCurrentの価格時計15秒以内。金融最新Quoteへの外部bindは別責務"),
          ("S.5秒速度",five["known"],five["known"] and five["signed_speed"]<0,"実両端が既知の保有方向付き5秒窓pt/秒がstrict負")]
    if policy=="S515Q":rows.append(("S.15秒速度",fifteen["known"],fifteen["known"] and fifteen["signed_speed"]<0,"実両端が既知の保有方向付き15秒窓pt/秒がstrict負"))
    rows.append(("S.現在量",q["known"],q["known"] and signed<0,"同Current出典の保有方向付きDay OFI30又はNight E08四量差がstrict負"))
    checks=[{"id":name,"known":known,"passed":bool(known and passed),"reason":reason} for name,known,passed,reason in rows]
    denied=any(row["known"] and not row["passed"] for row in checks);all_known=all(row["known"] for row in checks)
    known=bool(denied or all_known);allowed=bool(all_known and not denied)
    role,reason=("短秒複合失効","短秒進行と現在量が保有方向へ反対") if allowed else (("追加退出なし","公開済みの必要条件が不成立") if known else ("判定不能","既知の否定条件はなく必要な短秒又は現在量が未知"))
    return {"decision":{"policy":policy,"snapshot_id":incoming["snapshot_id"],"at":at,"side":side,"known":known,"allowed":allowed,"role":role,"reason":reason},"checks":checks,"evidence":e}
