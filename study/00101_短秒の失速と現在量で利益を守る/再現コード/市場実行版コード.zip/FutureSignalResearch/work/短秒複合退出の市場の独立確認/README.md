# 短秒複合退出の市場接続を独立に確認する準備

この版は停止済み完全Input人工の24帳簿だけで接続確認した。実市場の新12帳簿、旧100 P0四帳簿のPython全文照合はまだ実行していない。実行者はRootとし、この準備ではRaw、実Native、市場Tape、生成済み実streamを開かない。

`市場と短秒を照合する.py` は金融式・純式・字句parserを複写せず、停止668aの `Entries`、931cの `ShortPath`、旧100の `ProtectionPath`、固定TapeのScalar/Source復元、00d8の辞書復元・全record読戻しをSHA参照する。保存されたS判断を期待採否へ入力しない。Book内の `short_exit_events` と `short_exit_point` は独立台帳が生成した全値との比較対象である。

新市場Nativeには全12 Bookと全入口checkがあるため、外部へのS判断の重複転記は不要。`short_bindings` は独立callback/要求/fill件数にも結ぶ。原行Inputはheader辞書とstreamからその行だけを復元し、同じInputを四つの私有Actorへ供給する。P0は短秒Inputを金融判断に使わない。Force/GridではSを呼ばない。

市場では固定00d8で全recordを一巡検査した後、別の一巡で正NK原行だけを金融へ配送する。人工は手製Last0・公表履歴・Endingを含むため、市場用の全履歴検査へ偽装しない。停止668aの人工専用復元検査を通した24帳簿を新しい金融配送へ接続している。Source/ATR/技法の自然形成の証明ではない。

## 実行前固定とCLI

市場金融の同じ条件JSONを `--condition-sha` で固定する。新監査の停止JSONと実金融完了SHAはRootが引数で固定し、未知SHAを後からコードへ埋めない。条件・停止・コード・許可集合・入力SHAを検査し終えるまで、Tape/Native/streamの意味展開を始めない。内容SHAの確認は必要である。

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/短秒複合退出の市場の独立確認/市場と短秒を照合する.py' `
  --condition '<市場金融と同じ条件.json>' --condition-sha '<そのSHA256>' `
  --run '<first2金融出力dir>' --completion-sha '<完了.jsonのSHA256>' `
  --audit-stop 'work/短秒複合退出の市場の独立確認/停止.json' `
  --audit-stop-sha '<監査停止SHA256>' --stage first2 --workers 1 `
  --out '<未使用の独立照合.json>'
```

full54は `--stage full54` と同条件の54金融出力を指定し、さらに `--first2-audit '<先頭2場の独立照合.json>' --first2-audit-sha '<そのSHA256>'` が必要。先頭2場は2026-09-21 Day/Nightに固定し、54場は固定100閉鎖のNative集合と完全一致させる。金融完了と独立先頭2場が別条件・別コードなら拒否する。workerは1〜4。出力は新規fileだけ。

FileRefは条件dir、code/dependencyとproducer receiptのpathはrepo root、Tape indexの相対pathはindex dirが基準。旧100 Nativeは閉鎖4a8が指名した正式 `成果物/<session>.json.gz` に限定する。字句射影は旧100のP0四Bookと必要metadataだけを展開し、他出口・Shadows・全Source・全Gridを展開しない。

consumerはe290、producerは条件stageの停止/全所有コードへ別に結ぶ。cf49等のproducerをe290と同一SHAにする必要はない。同じpathへ異なるSHAを宣言した場合は拒否する。

## 範囲

全MTM、半円費用、Source予約優先、S判定前の旧Step完了、未予約量、同原行fill禁止、D1、容量非解放、終了0、注文/約定/専用point・traceは停止金融器へ独立配送して比較する。入口は当時の完全Inputと現在候補からE3S全checkを再計算する。

真の到着順、mini板の流動性、想定5ptの実測、未使用期間の利益安定性はこの監査では証明しない。Source・指標・チャートを再形成しない。機会損失、未参加仮想利益、決済後価格、回収率は算出しない。

Rootの実行後にだけ、市場の新P0独立全文・全12成功を主張できる。人工成功を市場成功へ読み替えない。
