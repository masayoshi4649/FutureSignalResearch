"""固定市場接続の保存値を、停止済み金融・純式へ独立配送する。"""

import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
import copy
import gzip
import hashlib
from pathlib import Path
import re
import sys


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
COUPLED_PATH = ROOT / 'work/短秒複合退出の再生の独立確認/再生と短秒を照合する.py'
COUPLED_SHA = '668a164c2558fc6c13cc3c304f9bf99d4ee93de32b0e04a29c67d135e59c0815'
WRAPPER_STOP = ROOT / 'work/短秒複合退出の市場接続/停止.json'
WRAPPER_SHA = '2657346bc6a2bf0f759c5275de15ef52db49da752979fd3ccac0890b90e96767'
PROOF_SHA = '4a8bc486e329f65f17e2395f781b2efd7cf76c5630d91924b611e90254725af3'
RUNTIME_SHA = 'ff571dba63a439e9df2fc855f722da1e506ee26cc1ef483de9aa4356e39e2eb7'
CONSUMER_SHA = 'e2901b5a4d0207bb86fb1af579cdc824d8e94cd3d37654ead732ec5a28732869'
FINANCE_SHA = 'f3606e629a84df0530266d6c43fc89d48df87985841baaaeb0c1471ec6046501'
PURE_SHA = '0e2e50bc391586daf0040cb9abab2b388b3f9ff23980d50d4f0e50eaa3580f9e'
SCOPE = 'Root固定条件の旧100/Tape/連続sidecar金融接続'
AUDIT_SCOPE = '固定市場接続の全12金融と当時E3S/S純式の独立再構成'
FIRST_IDS = ['2026-09-21_Day', '2026-09-21_Night']


def digest(path):
    """
    機能: 明示したファイルの内容指紋を逐次求める。
    引数: path(Path)は許可済み入力又はコード。
    返り値: strはSHA256。Sourceや特徴値を形成しない。
    """
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def need(condition, label):
    """
    機能: metadata又は保存値の不成立を停止する。
    引数: condition(bool)、label(str)は条件と出典。
    返り値: None。不成立時はValueError。
    """
    if not condition:
        raise ValueError(label)


def fixed(name, path, expected):
    """
    機能: 停止済み部品をSHA付きでimportする。
    引数: name/expected(str)、path(Path)は識別・指紋・場所。
    返り値: moduleは無変更の独立部品。市場本文は開かない。
    """
    import importlib.util
    need(digest(path) == expected, '固定コードSHA差: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


C = fixed('短秒市場の停止結合668a', COUPLED_PATH, COUPLED_SHA)
R, T, BASE, SHORT = C.READER, C.TAPE, C.BASE, C.SHORT
CORE_PATH = ROOT / 'work/101保有技法の抽出実行案/保有枠の抽出.py'
CORE_SHA = '799e407575b76951fe2879ece3a900b823916684c65dbbd941082cb8e7759950'
CORE = fixed('短秒市場の固定字句799e', CORE_PATH, CORE_SHA)
KEYS, P0_KEYS = tuple(C.KEYS), tuple(C.P0_KEYS)


def load(path):
    """
    機能: 明示されたJSONを既存の厳密decoderへ渡す。
    引数: path(Path)はmetadata又は許可済み保存JSON。
    返り値: objectは重複key・非有限を拒否した値。
    """
    return R.loads(Path(path).read_text(encoding='utf-8'))


def absolute(base, name):
    """
    機能: 一つの基準だけでpathを解決する。
    引数: base(Path)、name(str)は基準と宣言。
    返り値: Pathは絶対path。別場所への探索はしない。
    """
    need(type(name) is str and bool(name), '空path')
    path = Path(name)
    return (path if path.is_absolute() else Path(base) / path).resolve()


def ref(base, value, before):
    """
    機能: FileRefの内容とpathを前後検査へ加える。
    引数: base(Path)、value/before(dict)は宣言と指紋集合。
    返り値: dictは絶対pathと検査済みsha256。
    """
    need(set(value) == {'path', 'sha256'} and re.fullmatch('[0-9a-f]{64}', value['sha256']) is not None, '未固定FileRef')
    path = absolute(base, value['path'])
    need(path.is_file() and digest(path) == value['sha256'], 'FileRef差: ' + str(path))
    need(str(path) not in before or before[str(path)] == value['sha256'], '同path異SHA')
    before[str(path)] = value['sha256']
    return dict(path=str(path), sha256=value['sha256'])


def selected_ids(stage, allowed):
    """
    機能: 完全2場又は固定許可54を選ぶ。
    引数: stage(str)、allowed(dict)はstageと固定100集合。
    返り値: list[str]は昇順ID。別日や任意limitは許さない。
    """
    need(stage in ('first2', 'full54') and len(allowed) == 54, 'stage/許可54不足')
    need(set(FIRST_IDS) <= set(allowed), '先頭2場不足')
    return FIRST_IDS if stage == 'first2' else sorted(allowed)


def validate_completion(value, condition_sha, condition, ids):
    """
    機能: 市場金融の完了と全12/P0四・同条件・前後不変を確認する。
    引数: value/condition(dict)、condition_sha(str)、ids(list[str])は固定metadata。
    返り値: None。Book本文をまだ開かない。
    """
    need(set(value) == {'scope', '成功', '試行', 'stage', '条件SHA256', '全12Key', '結果', 'コードSHA256',
                       'Go依存SHA256', '入力前SHA256', '入力後SHA256', '前後不変', 'source_reexecuted',
                       'features_recomputed', 'charts_recomputed', 'Raw読取'}, '金融完了全tag')
    need(value['成功'] is True and value['前後不変'] is True and value['試行'] == 101
         and value['scope'] == SCOPE and value['条件SHA256'] == condition_sha
         and value['全12Key'] == list(KEYS) and value['コードSHA256'] == condition['コードSHA256']
         and value['Go依存SHA256'] == condition['Go依存SHA256']
         and value['入力前SHA256'] == value['入力後SHA256'] and bool(value['入力前SHA256'])
         and all(value[name] is False for name in ('source_reexecuted', 'features_recomputed', 'charts_recomputed'))
         and type(value['Raw読取']) is int and value['Raw読取'] == 0, '金融完了/同条件/非生成差')
    need([row['session'] for row in value['結果']] == ids, '金融完全集合/順序')
    for row in value['結果']:
        need(set(row) == {'session', 'path', 'sha256', 'p0_books', 'books'}
             and type(row['books']) is int and row['books'] == 12
             and type(row['p0_books']) is int and row['p0_books'] == 4, '全12/P0四の完了不足')


def current_frames(header, records, tape):
    """
    機能: 検査済みstreamの正NK原行だけを固定辞書復元器へ射影する。
    引数: header/tape(dict)、records(iterator[dict])は全値検査済み入力。
    返り値: iterator[tuple[int,dict]]は旧Tape ordinalと当時Input。parserや数値式は複写しない。
    """
    for record in records:
        if record['kind'] != 'row':
            continue
        row = record['row']
        refs = row['recent3_refs']
        yield record['tape_ordinal'], dict(snapshot_id=tape['session']['id'] + '-R' + str(row['positive_nk_ordinal']),
            at=row['scalar']['time'], kind=tape['session']['kind'],
            chart=R.materialize(header, row['chart_state']),
            recent3=None if refs is None else [R.materialize(header, state) for state in refs], current=row['current'])


def inspect_financial(tape, native, baseline, frames, counts, stream_sha, header_sha):
    """
    機能: 停止済み私有台帳へ全Scalar/Source/Force/Gridを配送する。
    引数: tape/native/baseline/counts(dict)、frames(iterator)、stream_sha/header_sha(str)は公開入力と保存期待値。
    返り値: dictは12新会計・旧P0四の独立全文照合。金融式・純式は追加しない。
    """
    audit = C.Audit()
    books = native['books']
    audit.equal(set(books), set(KEYS), '市場12本名key')
    audit.equal(set(baseline), set(P0_KEYS), '旧P0四key')
    audit.equal(tape['version'], 1, 'Tape版')
    audit.need(set(tape) in ({'version','scope','session','capabilities','events'},
                            {'version','scope','session','capabilities','events','provenance'}), 'Tape全tag')
    audit.equal(tape['capabilities'], T.CAPABILITIES, 'Tape対応範囲')
    for book in list(books.values()) + list(baseline.values()):
        BASE.compare_tree(book['session'], tape['session'], audit, '全金融場時計')
        audit.need(book['finished'] is True and book['complete'] is True and book['failure'] == '', '全金融完結')
    contexts = [event['context'] for event in tape['events'] if event['kind'] == 'grid']
    entries = C.Entries(contexts, books, native['gate_assessments'], audit, KEYS)
    models = [SHORT.ShortPath(books[key], audit, entries, native['contract']) for key in KEYS]
    base_records = [row for row in native['gate_assessments'] if row['key'] in P0_KEYS]
    base_entries = C.Entries(contexts, baseline, base_records, audit, P0_KEYS)
    controls = [C.OLD.ProtectionPath(baseline[key], audit, base_entries) for key in P0_KEYS]
    clocks, kinds, last_lines, callbacks = [], Counter(), {}, Counter()
    previous = 0
    for ordinal, event in enumerate(tape['events'], 1):
        audit.need(type(event['ordinal']) is int and event['ordinal'] == ordinal
                   and BASE.finite(event['at']) and event['at'] >= previous, '全Tape順序/時計')
        audit.need(set(event) <= {'ordinal', 'kind', 'at', 'quote', 'methods', 'non_empty', 'context'}, 'Tape全tag')
        previous, kind = event['at'], event['kind']
        kinds[kind] += 1
        if kind in ('quote', 'force'):
            batches = T.restore_batches(event, last_lines, audit)
            if kind == 'quote':
                q, atr = T.scalar_quote(event['quote'], audit)
                source_ordinal, incoming = next(frames)
                audit.equal(source_ordinal, ordinal, '当原行InputとTape ordinal')
                for model in models:
                    if model.short_policy:
                        candidates, assessments = model.short_step(q, batches, atr, incoming, event['quote']['received'])
                        callbacks[model.key] += len(candidates)
                    else:
                        model.step(q, batches, atr)
                for model in controls:
                    model.step(q, batches, atr)
            else:
                audit.need('quote' not in event and 'context' not in event, 'Forceに架空気配なし')
                for model in models + controls:
                    model.timer(event['at'], batches)
        elif kind == 'grid':
            audit.need('quote' not in event and not event.get('methods') and not event.get('non_empty'), 'gridに架空Sourceなし')
            entries.begin_grid(event['context'], models[0].last)
            base_entries.begin_grid(event['context'], controls[0].last)
            for model in models + controls:
                model.grid(event['at'])
            clocks.append(event['at'])
        else:
            raise ValueError('未知Tape種別')
    audit.need(next(frames, None) is None, '余剰正NK Inputなし')
    details = [model.finish() for model in models]
    old_details = [model.finish() for model in controls]
    entry_counts, old_entry_counts = entries.finish(clocks), base_entries.finish(clocks)
    expected = {}
    for model in models:
        expected[model.key] = dict(callbacks=callbacks[model.key], exit_requests=model.short_requests, exit_fills=model.short_fills)
    BASE.compare_tree(native['short_bindings'], expected, audit, 'Book内S候補/専用pointと外件数')
    passes = [dict(policy=policy, rows=counts['rows'], controls=counts['controls'], grids=counts['grids'],
                   compressed_sha256=stream_sha, header_canonical_sha256=header_sha, shared_actors=4)
              for policy in ('S5Q', 'S515Q')]
    BASE.compare_tree(native['stream_passes'], passes, audit, '同Input四私有/全stream一巡')
    for key in P0_KEYS:
        BASE.compare_tree(books[key], baseline[key], audit, key + '/新旧P0全文除外0')
    return dict(成功=True, 新会計数=12, 新P0独立全文会計=4, 旧100P0独立全文会計=4, P0除外=[],
                照合項目数=audit.checks, 不一致数=0, Tape=dict(kinds), 入口=entry_counts,
                旧P0入口=old_entry_counts, S件数=expected, details=details, 旧P0=old_details,
                Source再形成=False, 特徴チャート再計算=False, Raw読取=0)


def prior_p0(path):
    """
    機能: 固定字句parserで旧100のmetadataとP0四帳簿だけを射影する。
    引数: path(Path)は閉鎖100が指名したgzip。
    返り値: dictは許可fieldのみ。旧Source/他出口/PnL集計を展開しない。
    """
    with gzip.open(path, 'rt', encoding='utf-8') as stream:
        text = stream.read()
    selector = {name: True for name in ('trial', 'version', 'session', 'contract', 'tape_provenance',
                                       'actual_run_complete', 'source_reexecuted', 'charts_recomputed')}
    selector['books'] = {key: True for key in P0_KEYS}
    value, end = CORE.project_value(text, 0, selector)
    need(CORE.whitespace(text, end) == len(text) and set(value) == set(selector), '旧100限定field不足')
    return value


def inspect_scene(scene):
    """
    機能: 指紋確認済み一場を読戻し・金融独立器へ接続する。
    引数: scene(dict)はprepareが作成した絶対pathとSHA。
    返り値: dictは全値/全金融の結果。新市場実行はRootのCLI指示後だけ。
    """
    paths = {name: Path(scene[name]['path']) for name in ('native', 'old', 'tape', 'header', 'records')}
    for name, path in paths.items():
        need(digest(path) == scene[name]['sha256'], '場の入力SHA差: ' + name)
    with gzip.open(paths['native'], 'rt', encoding='utf-8') as stream:
        native = R.loads(stream.read())
    with gzip.open(paths['tape'], 'rt', encoding='utf-8') as stream:
        tape = R.loads(stream.read())
    header, old = load(paths['header']), prior_p0(paths['old'])
    validate_native(native, scene)
    need(tape['session']['id'] == scene['session'], 'index/新Native/旧Tapeの場ID')
    need(old['trial'] == 100 and old['version'] == 1 and old['session'] == scene['session']
         and old['contract'] == native['contract'] and old['actual_run_complete'] is True
         and old['source_reexecuted'] is False and old['charts_recomputed'] is False
         and old['tape_provenance']['sha256'] == scene['tape']['sha256'], '旧100P0由来差')
    need(header['provenance']['old_tape_gzip_sha256'] == scene['tape']['sha256']
         and header['provenance']['proof100_sha256'] == PROOF_SHA
         and header['legacy_tape_canonical_sha256'] == C.go_sha(tape)
         and header['features_recomputed'] is True and header['charts_recomputed'] is True,
         'producer生成と旧Tape/100閉鎖の由来')
    stream_result = R.inspect_values(header, R.read_records(paths['records']), tape)
    counts = dict(rows=header['row_count'], controls=header['trace_count'] - header['row_count'], grids=len(header['grids']))
    result = inspect_financial(tape, native, old['books'], current_frames(header, R.read_records(paths['records']), tape),
                               counts, scene['records']['sha256'], C.go_sha(header))
    result.update(session=scene['session'], 保存record読戻し=stream_result, 入力SHA256={str(p): scene[n]['sha256'] for n,p in paths.items()})
    need(all(digest(path) == scene[name]['sha256'] for name, path in paths.items()), '場の前後不変差')
    result['前後不変'] = True
    return result


def validate_native(value, scene):
    """
    機能: 新Nativeの全保存型・参照・全12・由来を確認する。
    引数: value/scene(dict)は新保存値とRoot固定計画。
    返り値: None。欠落をfalse/0へ補わない。
    """
    need(set(value) == {'scope','trial','version','session','contract','books','gate_assessments','short_bindings',
                       'stream_passes','input','condition_sha256','stops','p0_100_match','actual_run_complete',
                       'source_reexecuted','features_recomputed','charts_recomputed'}, '新Native全tag')
    need(value['scope'] == SCOPE and value['trial'] == 101 and value['version'] == 1
         and value['session'] == scene['session'] and value['actual_run_complete'] is True
         and value['condition_sha256'] == scene['condition_sha'] and set(value['books']) == set(KEYS)
         and all(value[n] is False for n in ('source_reexecuted','features_recomputed','charts_recomputed')), '新Native完結/同条件/非生成')
    need(value['input'] == scene['input'] and value['stops'] == scene['stops'], '新Nativeの完全由来')
    need(value['p0_100_match'] == dict(keys=list(P0_KEYS), excluded=[], full_json=True, native100_sha256=scene['old']['sha256']), 'P0旧100四全文metadata')


def prepare(args):
    """
    機能: 完了/条件/停止/コード/完全許可集合を本文より前に固定する。
    引数: args(argparse.Namespace)はRootの明示pathとSHA。
    返り値: dictは絶対入力・配送計画・前指紋。未固定/別日/別版は拒否。
    """
    before = {}
    condition_ref = ref(ROOT, dict(path=args.condition, sha256=args.condition_sha), before)
    condition_path = Path(condition_ref['path'])
    condition = load(condition_path)
    need(condition['試行'] == 101 and condition['version'] == 1 and condition['市場損益を開く前の固定'] is True
         and condition['全12Key'] == list(KEYS) and set(condition['stages']) == {'first2','full54'}, '未固定市場条件')
    refs = {name: ref(condition_path.parent, condition[name], before) for name in
            ('固定100完了','許可54','市場wrapper停止','runtime停止','金融停止','純式停止','sidecar版2停止','実行物')}
    for name, expected in (('固定100完了',PROOF_SHA),('市場wrapper停止',WRAPPER_SHA),('runtime停止',RUNTIME_SHA),
                           ('金融停止',FINANCE_SHA),('純式停止',PURE_SHA),('sidecar版2停止',CONSUMER_SHA)):
        need(refs[name]['sha256'] == expected, '停止由来差: ' + name)
    need(Path(refs['固定100完了']['path']) == ROOT / 'study/00100_費用後利益化の前後で保護を分ける/完了記録.json', '旧100正本path')
    closed, wrapper = load(refs['固定100完了']['path']), load(refs['市場wrapper停止']['path'])
    need(closed['試行'] == 100 and closed['比較保存完了'] is True and closed['場数'] == 54, '固定100閉鎖')
    catalog = {Path(name).stem.removesuffix('.json'): sha for name,sha in closed['自己を除く正式指紋'].items()
               if re.fullmatch(r'成果物/\d{4}-\d{2}-\d{2}_(Day|Night)\.json\.gz', name.replace('\\','/'))}
    ids = selected_ids(args.stage, catalog)
    allow = load(refs['許可54']['path'])
    need(allow['version'] == 1 and allow['proof100_sha256'] == PROOF_SHA
         and len(allow['entries']) == 54 and {row['session']:row['sha256'] for row in allow['entries']} == catalog, '許可54/閉鎖差')
    expected_code = dict(wrapper['必須コードSHA256'])
    stage_refs = {}
    for stage in ('first2','full54'):
        spec = condition['stages'][stage]
        producer = ref(condition_path.parent, spec['producer_stop'], before)
        stop = load(producer['path'])
        need(spec['schema_version'] == 1 and stop['成功'] is True and spec['producer_code'] == stop['所有コードSHA256'], 'producer/code差')
        for name, sha in spec['producer_code'].items():
            need(name not in expected_code or expected_code[name] == sha, 'consumer/producer同path異版')
            expected_code[name] = sha
        index = ref(condition_path.parent, spec['index'], before)
        receipt = ref(condition_path.parent, spec['sidecar_receipt'], before)
        index_value, receipt_value = load(index['path']), load(receipt['path'])
        expected_ids = selected_ids(stage, catalog)
        need(index_value['version'] == 1 and index_value['stage'] == stage
             and sorted(row['session'] for row in index_value['entries']) == expected_ids, 'Tape完全stage集合')
        need(receipt_value['成功'] is True and receipt_value['前後不変'] is True and receipt_value['stage'] == stage
             and receipt_value['scope'] == '固定100と旧Tapeの連続技法sidecar構築'
             and receipt_value['固定100完了SHA256'] == PROOF_SHA
             and receipt_value['所有コードSHA256'] == spec['producer_code']
             and all(receipt_value[n] is False for n in ('source_reexecuted','financial_executed'))
             and all(receipt_value[n] is True for n in ('features_recomputed','charts_recomputed'))
             and receipt_value['sessions'] == expected_ids, 'producer receipt同版/非金融/完全stage')
        need(sorted(row['session'] for row in spec['scenes']) == expected_ids
             and sorted(row['session'] for row in receipt_value['details']) == expected_ids, 'sidecar詳細完全stage')
        stage_refs[stage] = (spec, producer, index, receipt, index_value, receipt_value)
    need(condition['コードSHA256'] == expected_code and condition['Go依存SHA256'] == wrapper['Go依存SHA256'], '市場code完全停止集合差')
    for group in (condition['コードSHA256'], condition['Go依存SHA256']):
        for name, sha in group.items():
            ref(ROOT, dict(path=name,sha256=sha), before)
    financial_before = dict(before)
    audit_stop = ref(ROOT, dict(path=args.audit_stop,sha256=args.audit_stop_sha), before)
    own = load(audit_stop['path'])
    need(own['成功'] is True and own['市場wrapper停止SHA256'] == WRAPPER_SHA
         and own['結合独立SHA256'] == COUPLED_SHA, '独立器停止差')
    for name, sha in own['所有コードSHA256'].items():
        ref(ROOT,dict(path=name,sha256=sha),before)
    need(own['所有コードSHA256'].get(str(Path(__file__).resolve().relative_to(ROOT)).replace('\\','/')) == digest(Path(__file__)), '実行独立器省略')
    completion_ref = ref(ROOT,dict(path=str(Path(args.run)/'完了.json'),sha256=args.completion_sha),before)
    completion = load(completion_ref['path'])
    need(completion['stage'] == args.stage,'金融完了stage差')
    validate_completion(completion,args.condition_sha,condition,ids)
    need(all(completion['入力前SHA256'].get(name) == sha for name,sha in financial_before.items()),
         '金融完了の条件/両stage metadata/全code/依存の前後指紋不足')
    for name, sha in completion['入力前SHA256'].items():
        ref(ROOT,dict(path=name,sha256=sha),before)
    for value in refs.values():
        need(completion['入力前SHA256'].get(value['path']) == value['sha256'], '金融完了必要入力不足')
    if args.stage == 'full54':
        prior_ref = ref(ROOT,dict(path=args.first2_audit,sha256=args.first2_audit_sha),before)
        first = load(prior_ref['path'])
        need(first['成功'] is True and first['scope'] == AUDIT_SCOPE and first['stage'] == 'first2'
             and first['sessions'] == FIRST_IDS and first['条件SHA256'] == args.condition_sha
             and first['前後不変'] is True and first['監査コードSHA256'] == own['所有コードSHA256']
             and first['新会計数'] == 24 and first['新P0独立全文会計'] == 8, '同条件first2独立成功が必要')
        for name,sha in first['入力SHA256前'].items():
            ref(ROOT,dict(path=name,sha256=sha),before)
    spec, producer, index, receipt, index_value, receipt_value = stage_refs[args.stage]
    by_index = {row['session']:row for row in index_value['entries']}
    by_spec = {row['session']:row for row in spec['scenes']}
    by_detail = {row['session']:row for row in receipt_value['details']}
    scenes = []
    for row in completion['結果']:
        sid = row['session']
        entry, declared, detail = by_index[sid], by_spec[sid], by_detail[sid]
        tape = ref(Path(index['path']).parent,dict(path=entry['path'],sha256=entry['sha256']),before)
        old = ref(ROOT/'study/00100_費用後利益化の前後で保護を分ける',dict(path='成果物/'+sid+'.json.gz',sha256=catalog[sid]),before)
        header = ref(condition_path.parent,declared['header'],before)
        records = ref(condition_path.parent,declared['records'],before)
        need(header == dict(path=str(absolute(ROOT,detail['header'])),sha256=detail['header_SHA256'])
             and records == dict(path=str(absolute(ROOT,detail['path'])),sha256=detail['SHA256']), 'producer receipt path基準差')
        native = ref(Path(completion_ref['path']).parent,dict(path=row['path'],sha256=row['sha256']),before)
        input_refs = dict(native100=old,tape=tape,sidecar_receipt=receipt,sidecar_header=header,sidecar_records=records,producer_stop=producer)
        need(all(completion['入力前SHA256'].get(v['path']) == v['sha256'] for v in input_refs.values()), '金融場の入力指紋不足')
        scenes.append(dict(session=sid,native=native,old=old,tape=tape,header=header,records=records,input=input_refs,
                           condition_sha=args.condition_sha,stops=dict(runtime=RUNTIME_SHA,finance=FINANCE_SHA,pure=PURE_SHA,
                             consumer_builder=CONSUMER_SHA,producer=producer['sha256'],proof100=PROOF_SHA)))
    return dict(scenes=scenes,before=before,own=own['所有コードSHA256'],completion_sha=args.completion_sha)


def main():
    """
    機能: 固定metadata検査後だけ独立金融を各場へ配送し新規証拠を残す。
    引数: CLIは条件/完了/独立停止のpathとSHA、stage、新規out、workers。
    返り値: None。不一致は成功を保存せず例外又は非0終了。
    """
    parser = argparse.ArgumentParser()
    for name in ('condition','condition-sha','run','completion-sha','audit-stop','audit-stop-sha','out'):
        parser.add_argument('--'+name,required=True)
    parser.add_argument('--stage',required=True,choices=('first2','full54'))
    parser.add_argument('--workers',type=int,choices=range(1,5),default=1)
    parser.add_argument('--first2-audit',default='')
    parser.add_argument('--first2-audit-sha',default='')
    args = parser.parse_args()
    out = Path(args.out).resolve()
    need(not out.exists(),'出力は新規fileのみ')
    plan = prepare(args)
    details = []
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        jobs = {pool.submit(inspect_scene,scene):scene['session'] for scene in plan['scenes']}
        for job in as_completed(jobs):
            result = job.result()
            details.append(result)
            print('独立場完了 '+result['session'],flush=True)
    details.sort(key=lambda row:row['session'])
    after = {name:digest(Path(name)) for name in plan['before']}
    need(after == plan['before'],'全入力/コードの前後SHA差')
    value = dict(成功=True,scope=AUDIT_SCOPE,stage=args.stage,sessions=[r['session'] for r in details],
                 条件SHA256=args.condition_sha,金融完了SHA256=plan['completion_sha'],監査コードSHA256=plan['own'],
                 新会計数=sum(r['新会計数'] for r in details),新P0独立全文会計=sum(r['新P0独立全文会計'] for r in details),
                 旧100P0独立全文会計=sum(r['旧100P0独立全文会計'] for r in details),
                 照合項目数=sum(r['照合項目数'] for r in details),不一致数=0,details=details,
                 入力SHA256前=plan['before'],入力SHA256後=after,前後不変=True,
                 Source再形成=False,特徴チャート再計算=False,Raw読取=0,機会損失算出=False,
                 scopeの限界='固定Source/Scalar/公開Inputの保存金融検算。真の受信順/mini流動性/未使用期間の利益安定性は証明しない。')
    import json
    out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2)
        stream.write('\n')


if __name__ == '__main__':
    main()
