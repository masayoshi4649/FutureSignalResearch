package shortport101

import (
	"bytes"
	"encoding/json"
	"fmt"
	"reflect"
	"sort"
	"strings"

	port "github.com/masayoshi4649/SessionTradeExecuter/actorport97"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	e3 "github.com/masayoshi4649/SessionTradeExecuter/minie3"
	finance "github.com/masayoshi4649/SessionTradeExecuter/minishortfinance"
)

type Result struct {
	Scope              string                      `json:"scope"`
	ReplayPasses       int                         `json:"replay_passes"`
	Result             port.RunResult              `json:"result"`
	Entry              []port.GateAssessmentRecord `json:"gate_assessments"`
	Held               []ShortAssessmentRecord     `json:"short_assessments"`
	Streams            []PassReceipt               `json:"stream_passes"`
	SourceReexecuted   bool                        `json:"source_reexecuted"`
	FeaturesRecomputed bool                        `json:"features_recomputed"`
	ChartsRecomputed   bool                        `json:"charts_recomputed"`
}

// Keys はP0/S5Q/S515Qそれぞれ費用/遅延4設定の本名を返します。
//
// 引数: ありません。
// 返り値: []stringは固定12keyです。
func Keys() []string {
	out := []string{}
	for _, prefix := range []string{"", "S5Q_", "S515Q_"} {
		for _, cfg := range BaseConfigurations() {
			out = append(out, fmt.Sprintf("%sE3S_B5Q_P0_C%.0f_D%d", prefix, cfg.Slip, cfg.Delay))
		}
	}
	return out
}

// Replay は同じTapeを3pass、同じ圧縮sidecarをSの2passだけ一巡します。
//
// 引数: input(tape.Tape)、source(StreamSource)、contract(string)、artificial(bool)は既供給値です。
// 返り値: Result/errorは12会計/実callback/一巡証拠又は入力不整合です。市場入力を生成しません。
func Replay(input tape.Tape, source StreamSource, contract string, artificial bool) (Result, error) {
	out := Result{Scope: input.Scope, ReplayPasses: 3, Result: port.RunResult{Books: map[string]json.RawMessage{}, StateSHA256: map[string]string{}, GateCallbacks: map[string]int{}}, Entry: []port.GateAssessmentRecord{}, Held: []ShortAssessmentRecord{}, Streams: []PassReceipt{}}
	if artificial && (!strings.HasPrefix(input.Scope, "固定短秒Go型人工") || len(input.Provenance) != 0) {
		return out, fmt.Errorf("人工接続へ市場Tapeは渡せません")
	}
	if contract == "" {
		return out, fmt.Errorf("外部正本の期待限月が必要")
	}
	before, err := json.Marshal(input)
	if err != nil {
		return out, err
	}
	headerBefore, err := json.Marshal(source.Header)
	if err != nil {
		return out, err
	}
	for _, policy := range []finance.ExitPolicy{"", finance.ExitS5Q, finance.ExitS515Q} {
		var cursor *streamCursor
		if policy != "" {
			cursor, err = openCursor(input, source)
			if err != nil {
				return out, err
			}
		}
		next := 0
		factory := Factory{ExitPolicy: policy, Contract: contract, Cursor: cursor, Entry: &out.Entry, Held: &out.Held, NextActor: &next}
		var part port.RunResult
		if artificial {
			part, err = port.Run(input, factory, BaseConfigurations())
		} else {
			part, err = port.RunProduction(input, factory, BaseConfigurations())
		}
		if err != nil {
			if cursor != nil {
				cursor.close()
			}
			return out, err
		}
		if cursor != nil {
			receipt, e := cursor.finish(string(policy))
			cursor.close()
			if e != nil {
				return out, e
			}
			out.Streams = append(out.Streams, receipt)
		}
		for key, body := range part.Books {
			if _, ok := out.Result.Books[key]; ok {
				return out, fmt.Errorf("pass間key重複")
			}
			out.Result.Books[key] = body
			out.Result.GateCallbacks[key] = part.GateCallbacks[key]
			if artificial {
				out.Result.StateSHA256[key] = part.StateSHA256[key]
			}
		}
		after, e := json.Marshal(input)
		headerAfter, he := json.Marshal(source.Header)
		if e != nil || he != nil || !bytes.Equal(before, after) || !bytes.Equal(headerBefore, headerAfter) {
			return out, fmt.Errorf("共有Tape/headerを書換え")
		}
	}
	ranks := map[string]int{}
	for i, k := range Keys() {
		ranks[k] = i
	}
	sort.SliceStable(out.Entry, func(i, j int) bool {
		a, b := out.Entry[i], out.Entry[j]
		if a.Candidate.At != b.Candidate.At {
			return a.Candidate.At < b.Candidate.At
		}
		if a.Key != b.Key {
			return ranks[a.Key] < ranks[b.Key]
		}
		return a.Ordinal < b.Ordinal
	})
	sort.SliceStable(out.Held, func(i, j int) bool {
		a, b := out.Held[i], out.Held[j]
		if a.Candidate.At != b.Candidate.At {
			return a.Candidate.At < b.Candidate.At
		}
		return ranks[a.Key] < ranks[b.Key]
	})
	if err = validateRecords(input, out); err != nil {
		return out, err
	}
	return out, nil
}

// validateRecords は12keyと実callbackの全保存集合を照合します。
//
// 引数: input(tape.Tape)、out(Result)は同運転の公開値です。
// 返り値: errorは入口本名/全check/金融traceの不整合です。存在しない候補を追加しません。
func validateRecords(input tape.Tape, out Result) error {
	if len(out.Result.Books) != 12 || len(out.Result.GateCallbacks) != 12 || len(out.Streams) != 2 {
		return fmt.Errorf("12Book/2stream集合不足")
	}
	frames := map[float64]int{}
	for i, e := range input.Events {
		if e.Kind == "grid" {
			if _, ok := frames[e.At]; ok {
				return fmt.Errorf("grid重複")
			}
			frames[e.At] = i
		}
	}
	ranks := map[string]bool{}
	for _, k := range Keys() {
		ranks[k] = true
		if !json.Valid(out.Result.Books[k]) {
			return fmt.Errorf("Book欠落/JSON不正")
		}
	}
	for k := range out.Result.Books {
		if !ranks[k] {
			return fmt.Errorf("候補外key")
		}
	}
	counts, seen := map[string]int{}, map[string]bool{}
	for _, r := range out.Entry {
		i, ok := frames[r.Candidate.At]
		if !ok || !ranks[r.Key] || r.Ordinal != r.Candidate.Ordinal || r.Ordinal <= 0 || !reflect.DeepEqual(r.Source, r.Candidate.Source) {
			return fmt.Errorf("入口実候補出典差")
		}
		v, err := e3.AssessTechnicalGate(*input.Events[i].Context, r.Candidate, "E3S")
		if err != nil || len(r.Assessment.Checks) != 9 || !reflect.DeepEqual(v, r.Assessment) {
			return fmt.Errorf("入口純E3S全check差")
		}
		id := fmt.Sprintf("%s/%d/%g", r.Key, r.Ordinal, r.Candidate.At)
		if seen[id] {
			return fmt.Errorf("入口callback重複")
		}
		seen[id] = true
		counts[r.Key]++
	}
	for _, k := range Keys() {
		if counts[k] != out.Result.GateCallbacks[k] {
			return fmt.Errorf("入口callback件数差")
		}
	}
	expected := map[string]finance.ShortExitPoint{}
	for _, k := range Keys() {
		var b finance.ActualResult
		if err := json.Unmarshal(out.Result.Books[k], &b); err != nil || b.Key != k {
			return fmt.Errorf("Book本文key/型差")
		}
		for _, event := range b.ShortExitEvents {
			for _, p := range event.Positions {
				if p.Candidate == nil && p.Assessment == nil {
					continue
				}
				if p.Candidate == nil || p.Assessment == nil {
					return fmt.Errorf("短秒trace片側欠落")
				}
				id := fmt.Sprintf("%s/%s/%s", k, p.PositionID, p.Candidate.SnapshotID)
				if _, ok := expected[id]; ok {
					return fmt.Errorf("短秒trace重複")
				}
				expected[id] = finance.ShortExitPoint{Candidate: *p.Candidate, Assessment: *p.Assessment}
			}
		}
	}
	seen = map[string]bool{}
	for _, r := range out.Held {
		id := fmt.Sprintf("%s/%s/%s", r.Key, r.Candidate.PositionID, r.Candidate.SnapshotID)
		v, ok := expected[id]
		if !ok || seen[id] || !reflect.DeepEqual(v, finance.ShortExitPoint{Candidate: r.Candidate, Assessment: r.Assessment}) {
			return fmt.Errorf("実held recordと金融trace集合差")
		}
		seen[id] = true
	}
	if len(seen) != len(expected) {
		return fmt.Errorf("短秒callback欠落")
	}
	return nil
}

// CompareP0100 は旧100公開APIのP0四と全JSON/任意の全時点を除外0比較します。
//
// 引数: current(Result)、old(port.RunResult)、allPoints(bool)は同じ人工入力の結果です。
// 返り値: errorはkey/bytes/全時点差です。nil/空/ID/ラベルの置換はしません。
func CompareP0100(current Result, old port.RunResult, allPoints bool) error {
	if len(old.Books) != 4 {
		return fmt.Errorf("旧100P0は4会計が必要")
	}
	for _, key := range Keys()[:4] {
		if !bytes.Equal(current.Result.Books[key], old.Books[key]) || !json.Valid(old.Books[key]) || current.Result.GateCallbacks[key] != old.GateCallbacks[key] || allPoints && (current.Result.StateSHA256[key] == "" || current.Result.StateSHA256[key] != old.StateSHA256[key]) {
			return fmt.Errorf("旧100P0全JSON/全時点差: %s", key)
		}
	}
	return nil
}
