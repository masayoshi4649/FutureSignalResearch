package main

import (
	"flag"
	"fmt"
	"io"
	"os"

	app "github.com/masayoshi4649/SessionTradeExecuter/shortport101"
)

// main は宣言された市場口を未固定のまま入力読取前に拒否します。
//
// 引数: os.Args([]string)は将来の停止/条件/台帳/receipt/新規出力の宣言です。
// 返り値: ありません。helpは0、現在の実行要求は2です。
func main() {
	var r app.MarketRequest
	flag.StringVar(&r.Condition, "condition", "", "Root固定条件（現在未固定）")
	flag.StringVar(&r.Proof100, "proof100", "", "固定100完了")
	flag.StringVar(&r.FinanceStop, "finance-stop", "", "停止S金融")
	flag.StringVar(&r.PureStop, "pure-stop", "", "停止S純式")
	flag.StringVar(&r.BuilderStop, "builder-stop", "", "停止sidecar版2")
	flag.StringVar(&r.SidecarReceipt, "sidecar-receipt", "", "sidecar成功receipt")
	flag.StringVar(&r.Index, "index", "", "固定2/54台帳")
	flag.StringVar(&r.Stage, "stage", "first2", "first2/full54")
	flag.StringVar(&r.Output, "out", "", "未使用の新規出力")
	flag.Parse()
	err := app.ValidateMarketRequest(r, func(path string) (io.ReadCloser, error) { return os.Open(path) })
	fmt.Fprintln(os.Stderr, err)
	os.Exit(2)
}
