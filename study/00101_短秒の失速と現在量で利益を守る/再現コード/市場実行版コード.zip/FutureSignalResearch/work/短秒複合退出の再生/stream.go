package shortport101

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"reflect"

	warm "github.com/masayoshi4649/SessionTradeExecuter/chartwarmup96"
	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	actual "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
)

type bankSnapshot = warm.Snapshot

// StreamSource は受領済みheader/圧縮bytes指紋と一巡用の公開readerを分けます。
// OpenはSのpassごとに1回だけ呼ぶ。P0は呼ばない。市場許可は別guardの責務です。
type StreamSource struct {
	Header                continuous.Sidecar
	HeaderCanonicalSHA256 string
	CompressedSHA256      string
	Open                  func() (io.ReadCloser, error)
}
type PassReceipt struct {
	Policy                string `json:"policy"`
	Rows                  int    `json:"rows"`
	Controls              int    `json:"controls"`
	Grids                 int    `json:"grids"`
	CompressedSHA256      string `json:"compressed_sha256"`
	HeaderCanonicalSHA256 string `json:"header_canonical_sha256"`
	SharedActors          int    `json:"shared_actors"`
}
type streamCursor struct {
	source                    StreamSource
	input                     tape.Tape
	reader                    io.ReadCloser
	gz                        *gzip.Reader
	decoder                   *json.Decoder
	hash                      hashWriter
	rows, controls, grids     int
	lastOrdinal               int
	lastAt                    float64
	mergeOrdinal              int
	nextAll                   map[string]int64
	lastNKLine                int64
	currentOrdinal, consumers int
	frame                     actual.TechnicalGateInput
	frameBefore               []byte
	expectedQuotes            []tape.TapeEvent
	expectedGrids             map[int]tape.TapeEvent
	seenGrids                 map[int]bool
}

// hashWriter は圧縮bytesを一巡しながら測る最小のhash口です。
type hashWriter interface {
	io.Writer
	Sum([]byte) []byte
}

// digestValue は公開値のcanonical Go JSON指紋を返します。
//
// 引数: value(any)は有限な公開値です。
// 返り値: string/errorはJSON指紋又は不正です。元gzipのSHAとは分けます。
func digestValue(value any) (string, error) {
	body, err := json.Marshal(value)
	if err != nil {
		return "", err
	}
	return fmt.Sprintf("%x", sha256.Sum256(body)), nil
}

// openCursor は停止版headerを旧Tape全文へ結合してからS専用streamを一度開きます。
//
// 引数: input(tape.Tape)、source(StreamSource)は外部で固定した公開入力です。
// 返り値: *streamCursor/errorは4actor共有の一巡口又はmetadata不整合です。
func openCursor(input tape.Tape, source StreamSource) (*streamCursor, error) {
	h := source.Header
	if source.Open == nil || len(source.CompressedSHA256) != 64 || len(source.HeaderCanonicalSHA256) != 64 || h.Version != 1 || h.Session != input.Session || !h.Streamed || h.Rows != nil || h.Trace != nil || h.SourceReexecuted || h.FinancialExecuted {
		return nil, fmt.Errorf("sidecar header/場/版/生成範囲の差")
	}
	d, err := digestValue(h)
	if err != nil || d != source.HeaderCanonicalSHA256 {
		return nil, fmt.Errorf("header canonical SHA差")
	}
	d, err = digestValue(input)
	if err != nil || d != h.LegacySHA {
		return nil, fmt.Errorf("旧Tape canonical SHA差")
	}
	c := &streamCursor{source: source, input: input, expectedQuotes: []tape.TapeEvent{}, expectedGrids: map[int]tape.TapeEvent{}, seenGrids: map[int]bool{}, nextAll: map[string]int64{"NK225": 0, "TOPIX": 0}}
	gi := 0
	bindings := []continuous.Binding{}
	for i, e := range input.Events {
		if e.Ordinal != i+1 {
			return nil, fmt.Errorf("旧Tape ordinal差")
		}
		switch e.Kind {
		case "quote":
			if e.Quote == nil {
				return nil, fmt.Errorf("旧Scalar欠落")
			}
			c.expectedQuotes = append(c.expectedQuotes, e)
		case "grid":
			if gi >= len(h.Grids) || e.Context == nil || !reflect.DeepEqual(h.Grids[gi], *e.Context) {
				return nil, fmt.Errorf("sidecar旧grid Input全文差")
			}
			gi++
			c.expectedGrids[e.Ordinal] = e
			bindings = append(bindings, continuous.Binding{TapeOrdinal: e.Ordinal, Kind: "grid", SidecarOrdinal: gi})
		case "force":
		default:
			return nil, fmt.Errorf("旧種別不正")
		}
	}
	bindingsMatch := len(bindings) == len(h.Bindings)
	for i, v := range bindings {
		if !bindingsMatch || v != h.Bindings[i] {
			bindingsMatch = false
			break
		}
	}
	if h.RowCount != len(c.expectedQuotes) || gi != len(h.Grids) || !bindingsMatch {
		return nil, fmt.Errorf("sidecar原行/grid集合差")
	}
	c.reader, err = source.Open()
	if err != nil {
		return nil, err
	}
	c.hash = sha256.New()
	c.gz, err = gzip.NewReader(io.TeeReader(c.reader, c.hash))
	if err != nil {
		c.reader.Close()
		return nil, err
	}
	c.decoder = json.NewDecoder(c.gz)
	c.decoder.DisallowUnknownFields()
	return c, nil
}

// close はI/Oだけを終了し成功へ読み替えません。
//
// 引数: ありません。
// 返り値: ありません。検査完了はfinishが別に行います。
func (c *streamCursor) close() {
	if c.gz != nil {
		c.gz.Close()
	}
	if c.reader != nil {
		c.reader.Close()
	}
}

// nextRecord はcontrolの出典/辞書を検査し、次の正NK原行まで逐次進めます。
//
// 引数: ありません。
// 返り値: *continuous.Record/errorはrow又はEOF/破損です。全streamをRAMへ貯めません。
func (c *streamCursor) nextRecord() (*continuous.Record, error) {
	for {
		var r continuous.Record
		if err := c.decoder.Decode(&r); err != nil {
			return nil, err
		}
		if r.Kind == "row" {
			if r.Row == nil || r.Control != nil {
				return nil, fmt.Errorf("row型の片側/欠落差")
			}
			return &r, nil
		}
		if r.Kind != "control" || r.Control == nil || r.Row != nil {
			return nil, fmt.Errorf("stream種別/型破損")
		}
		v := r.Control
		if v.Kind == "raw" && v.Identity == nil || v.Kind != "raw" && v.Identity != nil {
			return nil, fmt.Errorf("control物理出典の欠落/混入")
		}
		if v.At < c.lastAt {
			return nil, fmt.Errorf("control時計逆行")
		}
		c.lastAt = v.At
		controlSnapshot, err := continuous.Materialize(c.source.Header, v.Chart)
		if err != nil {
			return nil, err
		}
		if v.Kind == "grid" {
			e, ok := c.expectedGrids[r.TapeOrdinal]
			if !ok || c.seenGrids[r.TapeOrdinal] || r.TapeOrdinal <= c.lastOrdinal || v.At != e.At || !reflect.DeepEqual(controlSnapshot, e.Context.Chart) {
				return nil, fmt.Errorf("control gridの旧ordinal/公開Chart差")
			}
			c.seenGrids[r.TapeOrdinal] = true
			c.lastOrdinal = r.TapeOrdinal
			c.grids++
		} else {
			if r.TapeOrdinal != 0 || (v.Kind != "raw" && v.Kind != "publication") {
				return nil, fmt.Errorf("control種別/ordinal差")
			}
		}
		if v.Identity != nil {
			id := v.Identity
			if v.Kind != "raw" || id.Time != v.At || id.MergeOrdinal != c.mergeOrdinal+1 || id.PhysicalLine <= 0 || (id.Market != "NK225" && id.Market != "TOPIX") || id.AllIndex != c.nextAll[id.Market] || id.FeaturesIndex != nil && *id.FeaturesIndex < 0 {
				return nil, fmt.Errorf("control rawの物理順差")
			}
			if id.Market == "NK225" {
				last := controlSnapshot.LastInput
				if !controlSnapshot.HasLastInput || last.Time != id.Time || last.Line != id.PhysicalLine || last.Index != id.AllIndex || last.Valid || last.Last > 0 || id.FeaturesIndex != nil {
					return nil, fmt.Errorf("NK Last0 controlと全受理出典差")
				}
				if id.PhysicalLine <= c.lastNKLine {
					return nil, fmt.Errorf("NK物理行逆行")
				}
				c.lastNKLine = id.PhysicalLine
			}
			c.mergeOrdinal = v.Identity.MergeOrdinal
			c.nextAll[id.Market]++
		}
		c.controls++
	}
}

// frameFor は1rawのCurrent/Chart/Recent3を復元し4actorへ同じ値を供給します。
//
// 引数: actor(int)、o(native.Observation)、line(int64)は停止runnerの当配送です。
// 返り値: *actual.TechnicalGateInput/errorは共有値又は旧原行/連番空間の差です。
func (c *streamCursor) frameFor(actor int, o native.Observation, line int64) (*actual.TechnicalGateInput, error) {
	if actor < 0 || actor > 3 || actor != c.consumers {
		return nil, fmt.Errorf("共有4actorの配送順が不正")
	}
	q, err := tape.ProjectQuote(o, line)
	if err != nil {
		return nil, err
	}
	if actor == 0 {
		r, err := c.nextRecord()
		if err != nil {
			return nil, fmt.Errorf("正NK原行stream不足: %w", err)
		}
		row := r.Row
		if c.rows >= len(c.expectedQuotes) {
			return nil, fmt.Errorf("正NK原行過剰")
		}
		expected := c.expectedQuotes[c.rows]
		id := row.Identity
		if r.TapeOrdinal != expected.Ordinal || r.TapeOrdinal <= c.lastOrdinal || row.Ordinal != c.rows+1 || q != row.Scalar || q != *expected.Quote || expected.At != q.Time || q.Time < c.lastAt || id.Market != "NK225" || id.Time != q.Time || id.PhysicalLine != line || id.FeaturesIndex == nil || *id.FeaturesIndex != q.Index || id.AllIndex != c.nextAll["NK225"] || id.MergeOrdinal != c.mergeOrdinal+1 {
			return nil, fmt.Errorf("rowの旧ordinal/Scalar11/Time/Features/物理行差")
		}
		if line <= c.lastNKLine {
			return nil, fmt.Errorf("正NK物理行逆行")
		}
		c.lastNKLine = line
		v := row.Current
		if v.Reference != "NK225" || v.Time != q.Time || v.Received != q.Received || v.SourceIndex != q.Index || v.SourceLine != line || v.Last != q.Last || v.Bid != q.Bid || v.Ask != q.Ask {
			return nil, fmt.Errorf("row.Currentと同Scalar出典差")
		}
		s, err := continuous.Materialize(c.source.Header, row.Chart)
		if err != nil {
			return nil, err
		}
		if s.At != q.Time || !s.HasLastInput || s.LastInput.Time != q.Time || s.LastInput.Line != line || s.LastInput.Last != q.Last || s.LastInput.Index != id.AllIndex || !s.LastInput.Valid {
			return nil, fmt.Errorf("Chart.LastInputと全受理index/原行差")
		}
		var recent []bankSnapshot
		if row.Recent3 != nil {
			recent = []bankSnapshot{}
		}
		if len(row.Recent3) > 3 {
			return nil, fmt.Errorf("Recent3参照数が超過")
		}
		for i, state := range row.Recent3 {
			v, e := continuous.Materialize(c.source.Header, state)
			if e != nil {
				return nil, e
			}
			if v.Scene != s.Scene || v.At > q.Time || v.At != v.Three.BarEnd || i > 0 && v.At <= recent[i-1].At {
				return nil, fmt.Errorf("Recent3の場/未来/順序差")
			}
			recent = append(recent, v)
		}
		c.frame = actual.TechnicalGateInput{SnapshotID: fmt.Sprintf("%s-R%d", c.input.Session.ID, row.Ordinal), At: q.Time, Kind: c.input.Session.Kind, Chart: s, Recent3: recent, Current: v}
		c.frameBefore, err = json.Marshal(c.frame)
		if err != nil {
			return nil, err
		}
		c.rows++
		c.currentOrdinal = r.TapeOrdinal
		c.lastOrdinal = r.TapeOrdinal
		c.lastAt = q.Time
		c.mergeOrdinal = id.MergeOrdinal
		c.nextAll["NK225"]++
	} else if c.frame.At != q.Time || c.frame.Current.SourceIndex != q.Index || c.frame.Current.SourceLine != line {
		return nil, fmt.Errorf("同raw共有値へ別原行を配送")
	}
	return &c.frame, nil
}

// done は4actorの各Step後に共有Inputが変わらないことを確認します。
//
// 引数: actor(int)は配送順位です。
// 返り値: errorは共有値の改変/配送順差です。
func (c *streamCursor) done(actor int) error {
	if actor != c.consumers {
		return fmt.Errorf("actor完了順差")
	}
	c.consumers++
	if c.consumers == 4 {
		after, err := json.Marshal(c.frame)
		if err != nil || !bytes.Equal(after, c.frameBefore) {
			return fmt.Errorf("4actor共有RawContextの書換え")
		}
		c.consumers = 0
	}
	return nil
}

// finish は残controlを読み切り、欠落/余分なrow/圧縮SHAを成功前に確認します。
//
// 引数: policy(string)は今回S政策です。
// 返り値: PassReceipt/errorは一巡の件数/指紋又は未完です。
func (c *streamCursor) finish(policy string) (PassReceipt, error) {
	r, err := c.nextRecord()
	if err != io.EOF || r != nil {
		return PassReceipt{}, fmt.Errorf("stream末尾/余分原行不整合: %v", err)
	}
	sha := fmt.Sprintf("%x", c.hash.Sum(nil))
	h := c.source.Header
	if c.consumers != 0 || c.rows != h.RowCount || c.grids != len(h.Grids) || c.rows+c.controls != h.TraceCount || sha != c.source.CompressedSHA256 {
		return PassReceipt{}, fmt.Errorf("stream一巡の件数/SHA差")
	}
	return PassReceipt{Policy: policy, Rows: c.rows, Controls: c.controls, Grids: c.grids, CompressedSHA256: sha, HeaderCanonicalSHA256: c.source.HeaderCanonicalSHA256, SharedActors: 4}, nil
}
