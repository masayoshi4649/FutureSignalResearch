package shortport101

import (
	"encoding/json"
	"fmt"

	port "github.com/masayoshi4649/SessionTradeExecuter/actorport97"
	actual "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	short "github.com/masayoshi4649/SessionTradeExecuter/minishortexit"
	finance "github.com/masayoshi4649/SessionTradeExecuter/minishortfinance"
)

type ShortAssessmentRecord struct {
	Key        string                     `json:"key"`
	Candidate  finance.ShortHeldCandidate `json:"candidate"`
	Assessment short.Assessment           `json:"assessment"`
}
type Factory struct {
	ExitPolicy finance.ExitPolicy
	Contract   string
	Cursor     *streamCursor
	Entry      *[]port.GateAssessmentRecord
	Held       *[]ShortAssessmentRecord
	NextActor  *int
}
type actor struct {
	book      *finance.ActualBook
	key       string
	policy    finance.ExitPolicy
	cursor    *streamCursor
	index     int
	callbacks int
	entry     *[]port.GateAssessmentRecord
	held      *[]ShortAssessmentRecord
}

// BaseConfigurations は旧E3S/B5Q/P0の費用/遅延4設定だけを返します。
//
// 引数: ありません。
// 返り値: []port.ConfigにExitは含めず、factoryの明示政策へ分けます。
func BaseConfigurations() []port.Config {
	out := []port.Config{}
	for _, cost := range []float64{0, 5} {
		for _, delay := range []int{0, 1} {
			out = append(out, port.Config{Gate: "E3S", Slip: cost, Delay: delay})
		}
	}
	return out
}

// New は1pass内だけ独立した金融を4口座生成します。
//
// 引数: session(native.Session)、cfg(port.Config)は場/旧設定です。
// 返り値: port.Actor/errorは実金融wrapper又は政策/共有口の不整合です。
func (f Factory) New(session native.Session, cfg port.Config) (port.Actor, error) {
	if f.NextActor == nil || f.Entry == nil || f.Held == nil || cfg.Gate != "E3S" || cfg.Harvest != "" || f.ExitPolicy != "" && f.ExitPolicy != finance.ExitS5Q && f.ExitPolicy != finance.ExitS515Q || f.ExitPolicy == "" && f.Cursor != nil || f.ExitPolicy != "" && (f.Cursor == nil || f.Contract == "") {
		return nil, fmt.Errorf("短秒factory設定差")
	}
	config := finance.ActorConfig{Policy: "P0", EntryTiming: "B5Q", GatePolicy: "E3S", USOpen: session.USOpen, SlipPts: cfg.Slip, DelaySeconds: cfg.Delay, ExitPolicy: f.ExitPolicy}
	var b *finance.ActualBook
	var err error
	if f.ExitPolicy == "" {
		b, err = finance.NewActualBook(session, config)
	} else {
		b, err = finance.NewShortExitBook(session, config, f.Contract)
	}
	if err != nil {
		return nil, err
	}
	i := *f.NextActor
	*f.NextActor = i + 1
	if i > 3 {
		return nil, fmt.Errorf("同passで4actor超過")
	}
	return &actor{book: b, key: b.Snapshot().Key, policy: f.ExitPolicy, cursor: f.Cursor, index: i, entry: f.Entry, held: f.Held}, nil
}

// convertBatches は名前付き外型だけを変え、全Delta/配列状態を保ちます。
//
// 引数: values([]actual.NativeBatch)は旧Tapeが復元した元手法順です。
// 返り値: []finance.NativeBatchは同じ値の通知です。
func convertBatches(values []actual.NativeBatch) []finance.NativeBatch {
	if values == nil {
		return nil
	}
	out := make([]finance.NativeBatch, len(values))
	for i, v := range values {
		out[i] = finance.NativeBatch{Method: v.Method, Delta: v.Delta}
	}
	return out
}

// convertCandidate は金融が作った実新規候補の全Source欄を対応します。
//
// 引数: c(finance.EntryCandidate)は旧適格性を通った実候補です。
// 返り値: actual.EntryCandidateは採否/方向/数量を変えない型変換です。
func convertCandidate(c finance.EntryCandidate) actual.EntryCandidate {
	s := c.Source
	return actual.EntryCandidate{Ordinal: c.Ordinal, At: c.At, Side: c.Side, Quote: c.Quote, Available: c.Available, Quantity: c.Quantity, Source: actual.SourceIdentity{Method: s.Method, SignalID: s.SignalID, Kind: s.Kind, Parent: s.Parent, SourceID: s.SourceID, QuantityMicro: s.QuantityMicro, BirthQuantity: s.BirthQuantity, BirthTime: s.BirthTime, BirthQuote: s.BirthQuote}}
}

// Step は旧通知を一字も変更せず旧処理後の実保有だけを停止純式へ渡します。
//
// 引数: o(native.Observation)、line(int64)、batches([]actual.NativeBatch)は旧当原行です。
// 返り値: errorはstream/純式/金融出典の不整合です。P0はsidecar無効です。
func (a *actor) Step(o native.Observation, line int64, batches []actual.NativeBatch) error {
	if a.policy == "" {
		return a.book.OnNativeStepWithShortExit(o, line, convertBatches(batches), nil, nil)
	}
	input, err := a.cursor.frameFor(a.index, o, line)
	if err != nil {
		return err
	}
	gate := func(c finance.ShortHeldCandidate, in short.TechnicalGateInput) (short.Assessment, error) {
		if c.Policy != a.policy || c.At != o.Time || c.Quote.Index != o.Index || c.Quote.SourceLine != line || c.SnapshotID != input.SnapshotID {
			return short.Assessment{}, fmt.Errorf("実held候補の同原行差")
		}
		v, e := short.AssessShortExit(in, c.Side, string(a.policy))
		if e == nil {
			*a.held = append(*a.held, ShortAssessmentRecord{Key: a.key, Candidate: c, Assessment: v})
		}
		return v, e
	}
	if err = a.book.OnNativeStepWithShortExit(o, line, convertBatches(batches), input, gate); err != nil {
		return err
	}
	return a.cursor.done(a.index)
}

// Force は元timer通知だけを渡し、S文脈/気配を再時刻化しません。
//
// 引数: at(float64)、batches([]actual.NativeBatch)は元時計と全通知です。
// 返り値: errorは金融の不整合です。
func (a *actor) Force(at float64, batches []actual.NativeBatch) error {
	return a.book.OnNativeForce(at, convertBatches(batches))
}

// Grid は旧TapeのInputを実E3Sへそのまま渡し、S査定を追加しません。
//
// 引数: at(float64)、in(*actual.TechnicalGateInput)は元5分値です。
// 返り値: errorは入口/金融の不整合です。
func (a *actor) Grid(at float64, in *actual.TechnicalGateInput) error {
	if in == nil || in.At != at {
		return fmt.Errorf("元grid Input欠落")
	}
	gate := func(c finance.EntryCandidate) (finance.GateDecision, error) {
		a.callbacks++
		v, err := finance.AssessEntryTechnical(*in, c, "E3S")
		if err != nil {
			return finance.GateDecision{}, err
		}
		candidate := convertCandidate(c)
		*a.entry = append(*a.entry, port.GateAssessmentRecord{Key: a.key, Ordinal: c.Ordinal, Source: candidate.Source, Candidate: candidate, Assessment: v})
		d := v.Decision
		return finance.GateDecision{Policy: d.Policy, SnapshotID: d.SnapshotID, Known: d.Known, Allowed: d.Allowed, Role: d.Role, Reason: d.Reason}, nil
	}
	return a.book.OnEntryGridWithGate(at, gate)
}

// Snapshot は人工の全時点対照用に金融全JSONを返します。
//
// 引数: ありません。
// 返り値: json.RawMessage/errorは全結果又は保存不能値です。
func (a *actor) Snapshot() (json.RawMessage, error) { return json.Marshal(a.book.Snapshot()) }

// Finish は架空fillなしで全量/予約/未約定の完結を要求します。
//
// 引数: ありません。
// 返り値: string/json.RawMessage/errorはkey/全JSON又は未完です。
func (a *actor) Finish() (string, json.RawMessage, error) {
	r, err := a.book.Finish()
	if err != nil {
		return "", nil, err
	}
	body, err := json.Marshal(r)
	return r.Key, body, err
}

// Callbacks は元runnerへ実入口callback数だけを返します。
//
// 引数: ありません。
// 返り値: intは本名E3Sの実候補数です。
func (a *actor) Callbacks() int { return a.callbacks }
