package shortport101

import (
	"fmt"
	"io"
	"reflect"

	port "github.com/masayoshi4649/SessionTradeExecuter/actorport97"
)

const (
	Proof100SHA256        = "4a8bc486e329f65f17e2395f781b2efd7cf76c5630d91924b611e90254725af3"
	FinanceStopSHA256     = "f3606e629a84df0530266d6c43fc89d48df87985841baaaeb0c1471ec6046501"
	PureStopSHA256        = "0e2e50bc391586daf0040cb9abab2b388b3f9ff23980d50d4f0e50eaa3580f9e"
	BuilderStopSHA256     = "e2901b5a4d0207bb86fb1af579cdc824d8e94cd3d37654ead732ec5a28732869"
	MarketConditionSHA256 = ""
)

type Metadata struct {
	Proof100, FinanceStop, PureStop, BuilderStop string
	Keys                                         []string
	SidecarSuccess                               bool
	SidecarReceiptSHA256                         string
	First2Success                                bool
}
type MarketRequest struct{ Condition, Proof100, FinanceStop, PureStop, BuilderStop, SidecarReceipt, Index, Stage, Output string }

// ValidateMetadata は供給済みの停止/12key/sidecar/2→54宣言だけを確認します。
//
// 引数: got(Metadata)、stage(string)は本文を開く前に確認すべきmetadataです。
// 返り値: errorは不備です。条件固定やファイルSHA検算の代用にはしません。
func ValidateMetadata(got Metadata, stage string) error {
	if got.Proof100 != Proof100SHA256 || got.FinanceStop != FinanceStopSHA256 || got.PureStop != PureStopSHA256 || got.BuilderStop != BuilderStopSHA256 || !reflect.DeepEqual(got.Keys, Keys()) || !got.SidecarSuccess || len(got.SidecarReceiptSHA256) != 64 || stage != "first2" && stage != "full54" || stage == "full54" && !got.First2Success {
		return fmt.Errorf("停止/12key/sidecar receipt/2→54の宣言不足")
	}
	return nil
}

// ValidateMarketRequest は未固定の市場口をすべてのファイル読取前に拒否します。
//
// 引数: request(MarketRequest)、open(func(string)(io.ReadCloser,error))は宣言と読取監視口です。
// 返り値: errorは未固定拒否です。今回市場batch/原板readerは作りません。
func ValidateMarketRequest(request MarketRequest, open func(string) (io.ReadCloser, error)) error {
	if MarketConditionSHA256 == "" {
		return fmt.Errorf("短秒市場条件は未固定のためTape/sidecar本文読取前に拒否します")
	}
	return fmt.Errorf("この人工prototypeは市場dispatcher未実装です")
}

// ValidateStageIndex は停止runnerの2/54完全集合検査を直接使います。
//
// 引数: index(port.TapeIndex)、stage(string)、allowed(map[string]string)はmetadata値です。
// 返り値: errorは重複/欠落/対象外/指紋不備です。市場許可ではありません。
func ValidateStageIndex(index port.TapeIndex, stage string, allowed map[string]string) error {
	return port.ValidateIndex(index, stage, allowed)
}
