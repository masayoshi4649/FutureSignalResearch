package shortport101

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	port "github.com/masayoshi4649/SessionTradeExecuter/actorport97"
	warm "github.com/masayoshi4649/SessionTradeExecuter/chartwarmup96"
	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	old100 "github.com/masayoshi4649/SessionTradeExecuter/grossport100"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	actual "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	finance "github.com/masayoshi4649/SessionTradeExecuter/minishortfinance"
)

type financeCall struct {
	Kind        string                     `json:"kind"`
	At          float64                    `json:"at"`
	Observation *native.Observation        `json:"observation"`
	Line        int64                      `json:"line"`
	Batches     []finance.NativeBatch      `json:"batches"`
	Input       *actual.TechnicalGateInput `json:"input"`
}
type artifactFixture struct {
	Tape       tape.Tape
	Header     continuous.Sidecar
	Records    []continuous.Record
	Compressed []byte
	Side       int
}

// clone は人工の破損用にmap/pointerも独立した値を作ります。
//
// 引数: v(T)はJSON保存可能な公開値です。
// 返り値: Tは深い値copyです。
func clone[T any](v T) T {
	body, err := json.Marshal(v)
	if err != nil {
		panic(err)
	}
	var out T
	if err = json.Unmarshal(body, &out); err != nil {
		panic(err)
	}
	return out
}

// storeSnapshot は手製の公開SnapshotをV2公開Payload/State型へ分けます。
//
// 引数: header(*continuous.Sidecar)、s(warm.Snapshot)は人工辞書/公開値です。
// 返り値: continuous.Stateは内容SHA参照です。Bank/Featuresを計算しません。
func storeSnapshot(header *continuous.Sidecar, s warm.Snapshot) continuous.State {
	p := continuous.Payload{Scene: s.Scene, Chart: s.Chart, Three: s.Three, Fifteen: s.Fifteen, Carried: s.CarriedNumericSeed}
	key, err := digestValue(p)
	if err != nil {
		panic(err)
	}
	header.Payloads[key] = p
	return continuous.State{PayloadSHA: key, At: s.At, HasObserved: s.HasObservedClock, Observed: s.ObservedClock, HasLast: s.HasLastInput, Last: s.LastInput, Invalidated: s.InvalidatedAt, Sealed: s.Sealed}
}

// gridFixture は元Scalarだけを現在原行にし、新規の手製E3S公開値を付けます。
//
// 引数: scene(native.Session)、q(tape.ScalarQuote)、at(float64)、side(int)、ordinal(int)です。
// 返り値: actual.TechnicalGateInputは純入口の型人工です。元のSourceやScalarは変えません。
func gridFixture(scene native.Session, q tape.ScalarQuote, at float64, side, ordinal int, seed actual.TechnicalGateInput) actual.TechnicalGateInput {
	o := q.Observation()
	ctx := cloneInputFromRaw(o, q.SourceLine, seed)
	ctx.At = at
	ctx.SnapshotID = fmt.Sprintf("%s-G%04d", scene.ID, ordinal)
	ctx.Chart.At = at
	ctx.Chart.Scene = warm.Scene{ID: scene.ID, Start: scene.Start, Contract: "人工限月"}
	ctx.Chart.ObservedClock = at + 100
	t := &ctx.Chart.Chart.Technical
	s := float64(side)
	t.TrendKnown, t.SpikeKnown, t.ATRKnown = true, true, true
	t.EMA8_3 = q.Last
	t.EMA21_3 = q.Last - s*10
	t.EMA8_15 = q.Last
	t.EMA21_15 = q.Last - s*10
	t.Close3 = q.Last + s*5
	t.Histogram3 = s
	t.PreviousHistogram3 = 0
	t.RSI3, t.PreviousRSI3 = 55, 54
	t.TR3, t.ATR3, t.PreviousATR3 = 20, 20, 20
	t.Bar3End = float64(int64(at) / 180 * 180)
	t.Bar15End = float64(int64(at) / 900 * 900)
	for i, p := range []*warm.BarEvidence{&ctx.Chart.Three, &ctx.Chart.Fifteen} {
		end := t.Bar3End
		if i == 1 {
			end = t.Bar15End
		}
		p.BarEnd = end
		p.AvailableAt = end
		p.ObservedClock = at + 100
		p.LastSource.Time = q.Time
		p.LastSource.Last = q.Last
	}
	ctx.Current.Buy.OFI30, ctx.Current.Sell.OFI30 = s, s
	ctx.Current.Buy.OFIKnown, ctx.Current.Sell.OFIKnown = true, true
	return ctx
}

// cloneInputFromRaw は停止金融人工のInputだけを別口で受け取る補助です。
//
// 引数: o(native.Observation)、line(int64)、seed(actual.TechnicalGateInput)は手製原行と公開種です。
// 返り値: actual.TechnicalGateInputは後で上書きする最小の人工公開型です。
func cloneInputFromRaw(o native.Observation, line int64, seed actual.TechnicalGateInput) actual.TechnicalGateInput {
	v := clone(seed)
	v.At = o.Time
	v.Chart.At = o.Time
	v.Current.Time = o.Time
	v.Current.Received = o.Received
	v.Current.SourceIndex = o.Index
	v.Current.SourceLine = line
	v.Current.Last = o.Last
	v.Current.Bid = o.Bid
	v.Current.Ask = o.Ask
	v.Current.Buy.OwnAt = o.Time
	v.Current.Sell.OwnAt = o.Time
	return v
}

// makeFixture は停止S Go型からSource/Scalarを無改変でTapeへ移します。
//
// 引数: t(*testing.T)、side(int)は買売人工の指定です。
// 返り値: artifactFixtureは全Input/Last0/同Time異Lineを含むAPI接続器具です。
func makeFixture(t *testing.T, side int) artifactFixture {
	t.Helper()
	home := filepath.Join("..", "短秒複合退出の金融")
	var stop struct {
		Owned map[string]string `json:"全所有SHA256"`
	}
	read, err := os.ReadFile(filepath.Join(home, "停止.json"))
	if err != nil {
		t.Fatal(err)
	}
	sum, _ := digestBytes(read)
	if sum != FinanceStopSHA256 {
		t.Fatal("元金融停止差")
	}
	if err = json.Unmarshal(read, &stop); err != nil {
		t.Fatal(err)
	}
	rel := filepath.Join("人工", "公開型16", fmt.Sprintf("方向%d_S5Q_C0_D0.json", side))
	body, err := os.ReadFile(filepath.Join(home, rel))
	if err != nil {
		t.Fatal(err)
	}
	sum, _ = digestBytes(body)
	if sum != stop.Owned[rel] {
		t.Fatal("元金融公開型差")
	}
	var stored struct {
		Calls []financeCall        `json:"calls"`
		Book  finance.ActualResult `json:"book"`
	}
	if err = json.Unmarshal(body, &stored); err != nil {
		t.Fatal(err)
	}
	f := artifactFixture{Side: side, Tape: tape.Tape{Version: 1, Scope: "固定短秒Go型人工・Source/Scalarは停止S API、全context手製", Session: stored.Book.Session, Capabilities: tape.Capabilities(), Events: []tape.TapeEvent{}}, Header: continuous.Sidecar{Version: 1, Scope: "手製公開型・指標/量の自然生成未検査", Session: stored.Book.Session, Streamed: true, Payloads: map[string]continuous.Payload{}, Grids: []actual.TechnicalGateInput{}, Bindings: []continuous.Binding{}, SkippedGrids: []float64{}}, Records: []continuous.Record{}}
	var last tape.ScalarQuote
	var lastContext actual.TechnicalGateInput
	positive, all, merge, grids := 0, -1, 0, 0
	sourceLines := map[string]int64{}
	for _, call := range stored.Calls {
		e := tape.TapeEvent{Ordinal: len(f.Tape.Events) + 1, Kind: call.Kind, At: call.At}
		if call.Kind == "grid" {
			grids++
			ctx := gridFixture(stored.Book.Session, last, call.At, side, grids, lastContext)
			e.Context = &ctx
			f.Header.Grids = append(f.Header.Grids, ctx)
			state := storeSnapshot(&f.Header, ctx.Chart)
			f.Records = append(f.Records, continuous.Record{TapeOrdinal: e.Ordinal, Kind: "control", Control: &continuous.Trace{Kind: "grid", At: e.At, Chart: state}})
			f.Header.Bindings = append(f.Header.Bindings, continuous.Binding{TapeOrdinal: e.Ordinal, Kind: "grid", SidecarOrdinal: grids})
		} else {
			batches := make([]actual.NativeBatch, len(call.Batches))
			for i, b := range call.Batches {
				batches[i] = actual.NativeBatch{Method: b.Method, Delta: b.Delta}
			}
			e.Methods, e.NonEmpty, err = tape.CompressBatches(batches)
			if err != nil {
				t.Fatal(err)
			}
			if call.Kind == "quote" {
				if call.Input == nil || call.Observation == nil {
					t.Fatal("停止公開Input欠落")
				}
				q, er := tape.ProjectQuote(*call.Observation, call.Line)
				if er != nil {
					t.Fatal(er)
				}
				last = q
				e.Quote = &q
				positive++
				in := clone(*call.Input)
				if positive == 1 {
					all++
					merge++
					bad := clone(in.Chart)
					bad.At = q.Time - 0.25
					bad.HasLastInput = true
					bad.LastInput = warm.SourceStamp{Time: bad.At, Index: int64(all), Line: q.SourceLine - 1, Last: 0, Valid: false}
					bad.InvalidatedAt = bad.At
					bad.Three.DataKnown = false
					bad.Fifteen.DataKnown = false
					state := storeSnapshot(&f.Header, bad)
					f.Records = append(f.Records, continuous.Record{Kind: "control", Control: &continuous.Trace{Kind: "raw", At: bad.At, Identity: &continuous.Identity{Market: "NK225", Time: bad.At, PhysicalLine: bad.LastInput.Line, AllIndex: int64(all), MergeOrdinal: merge}, Chart: state}})
				}
				all++
				merge++
				lastContext = in
				in.Chart.HasLastInput = true
				in.Chart.LastInput = warm.SourceStamp{Time: q.Time, Index: int64(all), Line: q.SourceLine, Last: q.Last, Valid: true}
				state := storeSnapshot(&f.Header, in.Chart)
				var recent []continuous.State
				if positive == 6 {
					published := clone(in.Chart)
					published.At = published.Three.BarEnd
					published.LastInput = published.Three.LastSource
					recent = []continuous.State{storeSnapshot(&f.Header, published)}
				}
				idx := q.Index
				row := continuous.RawContext{Ordinal: positive, Identity: continuous.Identity{Market: "NK225", Time: q.Time, PhysicalLine: q.SourceLine, AllIndex: int64(all), FeaturesIndex: &idx, MergeOrdinal: merge}, Scalar: q, Current: in.Current, Chart: state, Recent3: recent}
				f.Records = append(f.Records, continuous.Record{TapeOrdinal: e.Ordinal, Kind: "row", Row: &row})
			}
			restored, er := tape.RestoreBatches(e, sourceLines)
			want, _ := json.Marshal(batches)
			got, _ := json.Marshal(restored)
			if er != nil || !bytes.Equal(want, got) {
				t.Fatal("Source通知全field差", er)
			}
		}
		f.Tape.Events = append(f.Tape.Events, e)
	}
	f.Header.RowCount = positive
	f.Header.TraceCount = len(f.Records)
	f.Header.LegacySHA, err = digestValue(f.Tape)
	if err != nil {
		t.Fatal(err)
	}
	f.Header.Ending = storeSnapshot(&f.Header, warm.Snapshot{Scene: warm.Scene{ID: stored.Book.Session.ID, Contract: "人工限月", Start: stored.Book.Session.Start}, At: last.Time, Sealed: true})
	f.Compressed = encodeRecords(t, f.Records)
	return f
}

// digestBytes は明示bytesのSHAを得ます。
//
// 引数: b([]byte)です。
// 返り値: string/errorはSHA。errorは常にnilです。
func digestBytes(b []byte) (string, error) { h := sha256.Sum256(b); return fmt.Sprintf("%x", h), nil }

// encodeRecords は人工Recordを実gzip JSONLへ保存可能なbytesにします。
//
// 引数: t(*testing.T)、records([]continuous.Record)は公開型人工です。
// 返り値: []byteは圧縮streamです。
func encodeRecords(t *testing.T, records []continuous.Record) []byte {
	t.Helper()
	var b bytes.Buffer
	gz := gzip.NewWriter(&b)
	enc := json.NewEncoder(gz)
	for _, r := range records {
		if err := enc.Encode(r); err != nil {
			t.Fatal(err)
		}
	}
	if err := gz.Close(); err != nil {
		t.Fatal(err)
	}
	return b.Bytes()
}

// source は同じgzip bytesを2回独立に開ける読取口を作ります。
//
// 引数: opens(*int)は実Open回数の監視です。
// 返り値: StreamSourceはheader/stream指紋を保持します。
func (f artifactFixture) source(opens *int) StreamSource {
	h, _ := digestValue(f.Header)
	s, _ := digestBytes(f.Compressed)
	return StreamSource{Header: f.Header, HeaderCanonicalSHA256: h, CompressedSHA256: s, Open: func() (io.ReadCloser, error) { *opens++; return io.NopCloser(bytes.NewReader(f.Compressed)), nil }}
}

// oldP0 は固定100公開factoryに同じTapeだけを渡します。
//
// 引数: t(*testing.T)、input(tape.Tape)はAPI人工です。
// 返り値: port.RunResultはP0四の全時点/最終値です。市場Nativeを読みません。
func oldP0(t *testing.T, input tape.Tape) port.RunResult {
	t.Helper()
	records := []port.GateAssessmentRecord{}
	r, err := port.Run(input, old100.ProtectionFactory{Records: &records}, BaseConfigurations())
	if err != nil {
		t.Fatal(err)
	}
	return r
}

// TestReplayShortComplete は12会計×鏡像の全原行接続とP0全文を検査します。
//
// 引数: t(*testing.T)です。
// 返り値: ありません。Sごと一巡し4actorで共有することも数えます。
func TestReplayShortComplete(t *testing.T) {
	for _, side := range []int{1, -1} {
		t.Run(fmt.Sprintf("方向%d", side), func(t *testing.T) {
			f := makeFixture(t, side)
			opens := 0
			got, err := Replay(f.Tape, f.source(&opens), "人工限月", true)
			if err != nil {
				t.Fatal(err)
			}
			if opens != 2 {
				t.Fatal("Sごと1巡でない", opens)
			}
			if err = CompareP0100(got, oldP0(t, f.Tape), true); err != nil {
				t.Fatal(err)
			}
			if len(got.Result.Books) != 12 {
				t.Fatal("12会計欠落")
			}
			for _, key := range Keys() {
				var b finance.ActualResult
				if err = json.Unmarshal(got.Result.Books[key], &b); err != nil {
					t.Fatal(err)
				}
				if len(b.Fills) == 0 || len(b.Positions) != 1 || b.Positions[0].Quantity != 0 {
					t.Fatal("非0/完結不足", key)
				}
				if b.Config.ExitPolicy != "" && (b.Metrics.ShortExitRequests != 1 || b.Metrics.ShortExitFills != 1) {
					t.Fatal("S実純式非0不足", key)
				}
			}
			again, err := Replay(f.Tape, f.source(&opens), "人工限月", false)
			if err != nil || !reflect.DeepEqual(got.Result.Books, again.Result.Books) || len(again.Result.StateSHA256) != 0 {
				t.Fatal("production供給値の差", err)
			}
			t.Log("P0四全時点/最終除外0、S8非0、同Time異Line、Last0でall/Features差、一巡共有、Source/P0先行")
		})
	}
}

// TestReplayShortPolicyUnknown は同じRawの15秒/量未知を政策ごとに区別します。
//
// 引数: t(*testing.T)です。
// 返り値: ありません。P0のInput/Sourceは変えず未知を0へ補完しません。
func TestReplayShortPolicyUnknown(t *testing.T) {
	for _, state := range []string{"15未知", "15順", "量未知"} {
		t.Run(state, func(t *testing.T) {
			f := makeFixture(t, 1)
			for i := range f.Records {
				r := f.Records[i].Row
				if r == nil || r.Current.Short.Five.Speed >= 0 {
					continue
				}
				switch state {
				case "15未知":
					r.Current.Short.Fifteen.Known = false
				case "15順":
					r.Current.Short.Fifteen.Speed = 1
					r.Current.Short.Fifteen.Move = r.Current.Short.Fifteen.Elapsed
				case "量未知":
					r.Current.Buy.OFIKnown = false
					r.Current.Sell.OFIKnown = false
				}
			}
			f.Compressed = encodeRecords(t, f.Records)
			opens := 0
			got, err := Replay(f.Tape, f.source(&opens), "人工限月", true)
			if err != nil {
				t.Fatal(err)
			}
			if err = CompareP0100(got, oldP0(t, f.Tape), true); err != nil {
				t.Fatal(err)
			}
			for _, key := range Keys()[4:] {
				var b finance.ActualResult
				json.Unmarshal(got.Result.Books[key], &b)
				want := 0
				if b.Config.ExitPolicy == finance.ExitS5Q && state != "量未知" {
					want = 1
				}
				if b.Metrics.ShortExitRequests != want {
					t.Fatal("政策/未知差", state, key, b.Metrics)
				}
			}
		})
	}
}

// TestReplayShortStreamCorruptions は元Scalar/出典/辞書/圧縮streamの破損を拒否します。
//
// 引数: t(*testing.T)です。
// 返り値: ありません。receipt規範や停止側の式を緩めません。
func TestReplayShortStreamCorruptions(t *testing.T) {
	for _, name := range []string{"旧ordinal", "正NKordinal", "ScalarATR", "FeaturesIndex", "物理行", "Current価格", "ChartallIndex", "辞書欠落", "Recent欠落", "Recent未来", "Last0欠落", "Last0物理逆行", "grid欠落", "原行欠落", "stream余分", "型破損", "gzip切断", "圧縮SHA", "headerSHA", "別限月"} {
		t.Run(name, func(t *testing.T) {
			f := makeFixture(t, 1)
			row := -1
			for i, r := range f.Records {
				if r.Row != nil {
					row = i
					break
				}
			}
			r := f.Records[row].Row
			switch name {
			case "旧ordinal":
				f.Records[row].TapeOrdinal++
			case "正NKordinal":
				r.Ordinal++
			case "ScalarATR":
				r.Scalar.ATR++
			case "FeaturesIndex":
				*r.Identity.FeaturesIndex++
			case "物理行":
				r.Identity.PhysicalLine++
			case "Current価格":
				r.Current.Bid++
			case "ChartallIndex":
				r.Chart.Last.Index++
			case "辞書欠落":
				delete(f.Header.Payloads, r.Chart.PayloadSHA)
			case "Recent欠落":
				r.Recent3 = []continuous.State{{PayloadSHA: "欠落"}}
			case "Recent未来":
				s := r.Chart
				s.At = r.Scalar.Time + 1
				r.Recent3 = []continuous.State{s}
			case "Last0欠落":
				f.Records = f.Records[1:]
			case "Last0物理逆行":
				f.Records[0].Control.Identity.PhysicalLine = 1000
			case "grid欠落":
				for i, v := range f.Records {
					if v.Control != nil && v.Control.Kind == "grid" {
						f.Records = append(f.Records[:i], f.Records[i+1:]...)
						break
					}
				}
			case "原行欠落":
				f.Records = append(f.Records[:row], f.Records[row+1:]...)
			case "stream余分":
				f.Records = append(f.Records, clone(f.Records[row]))
			case "型破損":
				f.Records[row].Kind = "unknown"
			}
			f.Compressed = encodeRecords(t, f.Records)
			if name == "gzip切断" {
				f.Compressed = f.Compressed[:len(f.Compressed)-4]
			}
			opens := 0
			source := f.source(&opens)
			if name == "圧縮SHA" {
				source.CompressedSHA256 = string(bytes.Repeat([]byte("0"), 64))
			}
			if name == "headerSHA" {
				source.HeaderCanonicalSHA256 = string(bytes.Repeat([]byte("0"), 64))
			}
			contract := "人工限月"
			if name == "別限月" {
				contract = "別限月"
			}
			if _, err := Replay(f.Tape, source, contract, true); err == nil {
				t.Fatal("stream破損が成功")
			}
		})
	}
}

// TestReplayShortP0AndGuard はP0のsidecar無効と未固定市場読取0を確認します。
//
// 引数: t(*testing.T)です。
// 返り値: ありません。旧100完了/各停止/12key/2→54はmetadataのみで確認します。
func TestReplayShortP0AndGuard(t *testing.T) {
	f := makeFixture(t, 1)
	entry := []port.GateAssessmentRecord{}
	held := []ShortAssessmentRecord{}
	next := 0
	r, err := port.Run(f.Tape, Factory{Entry: &entry, Held: &held, NextActor: &next}, BaseConfigurations())
	if err != nil {
		t.Fatal(err)
	}
	old := oldP0(t, f.Tape)
	if !reflect.DeepEqual(r, old) || len(held) != 0 {
		t.Fatal("P0sidecar無効/全文差")
	}
	opened := 0
	err = ValidateMarketRequest(MarketRequest{Condition: "読取禁止", Index: "読取禁止", SidecarReceipt: "読取禁止", Output: "作成禁止", Stage: "full54"}, func(string) (io.ReadCloser, error) { opened++; return nil, fmt.Errorf("読取禁止") })
	if err == nil || opened != 0 {
		t.Fatal("未固定入力へ触れた")
	}
	valid := Metadata{Proof100: Proof100SHA256, FinanceStop: FinanceStopSHA256, PureStop: PureStopSHA256, BuilderStop: BuilderStopSHA256, Keys: Keys(), SidecarSuccess: true, SidecarReceiptSHA256: string(bytes.Repeat([]byte("a"), 64))}
	if err = ValidateMetadata(valid, "first2"); err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"100", "金融", "純式", "builder", "12key", "receipt", "2先行"} {
		v := clone(valid)
		switch name {
		case "100":
			v.Proof100 = ""
		case "金融":
			v.FinanceStop = ""
		case "純式":
			v.PureStop = ""
		case "builder":
			v.BuilderStop = ""
		case "12key":
			v.Keys = v.Keys[:11]
		case "receipt":
			v.SidecarSuccess = false
		}
		stage := "first2"
		if name == "2先行" {
			stage = "full54"
		}
		if err = ValidateMetadata(v, stage); err == nil {
			t.Fatal("metadata破損成功", name)
		}
	}
}

// TestExportShortReplay は実Go型/gzip/旧100P0を新規rootへ明示保存します。
//
// 引数: t(*testing.T)、環境変数SHORT_RUNTIME_EXPORT(string)は未使用rootです。
// 返り値: ありません。通常testはskip、Source/技法を生成したとは称しません。
func TestExportShortReplay(t *testing.T) {
	root := os.Getenv("SHORT_RUNTIME_EXPORT")
	if root == "" {
		t.Skip("明示exportのみ")
	}
	if _, err := os.Stat(root); !os.IsNotExist(err) {
		t.Fatal("使用済みroot")
	}
	if err := os.MkdirAll(root, 0755); err != nil {
		t.Fatal(err)
	}
	for _, side := range []int{1, -1} {
		f := makeFixture(t, side)
		opens := 0
		source := f.source(&opens)
		out, err := Replay(f.Tape, source, "人工限月", true)
		if err != nil {
			t.Fatal(err)
		}
		old := oldP0(t, f.Tape)
		if err = CompareP0100(out, old, true); err != nil {
			t.Fatal(err)
		}
		value := struct {
			Scope              string             `json:"scope"`
			Tape               tape.Tape          `json:"tape"`
			Header             continuous.Sidecar `json:"header"`
			StreamSHA          string             `json:"stream_sha256"`
			HeaderCanonicalSHA string             `json:"header_canonical_sha256"`
			Output             Result             `json:"output"`
			P0100              port.RunResult     `json:"baseline100_p0_api"`
			Exclusions         []string           `json:"field_exclusions"`
			P0Match            bool               `json:"p0_all_points_equal"`
			Stops              map[string]string  `json:"stops"`
		}{"手製Source/Chart/Current/短秒の型接続。市場/自然生成未検査", f.Tape, f.Header, source.CompressedSHA256, source.HeaderCanonicalSHA256, out, old, []string{}, true, map[string]string{"finance": FinanceStopSHA256, "pure": PureStopSHA256, "builder": BuilderStopSHA256}}
		body, err := json.MarshalIndent(value, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		for ext, data := range map[string][]byte{".json": body, ".records.jsonl.gz": f.Compressed} {
			path := filepath.Join(root, fmt.Sprintf("方向%d%s", side, ext))
			file, e := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
			if e != nil {
				t.Fatal(e)
			}
			_, e = file.Write(data)
			ce := file.Close()
			if e != nil || ce != nil {
				t.Fatal(e, ce)
			}
		}
	}
}
