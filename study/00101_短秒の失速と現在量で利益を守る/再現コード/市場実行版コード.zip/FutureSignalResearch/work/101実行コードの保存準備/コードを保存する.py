"""固定101のコードと小metadataだけを元配置のまま保存する。市場の意味展開はしない。"""
from __future__ import annotations

import argparse
import ast
import collections
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import tempfile
import zipfile


SEEDS = {
    "work/短秒複合退出の市場接続/停止.json": "2657346bc6a2bf0f759c5275de15ef52db49da752979fd3ccac0890b90e96767",
    "work/101連続入力の試作_版3/停止.json": "cf49b2b643afcfda478a5d383c6d5e73bbbee3b477d2a0edc0e45b745ef4d16c",
    "work/短秒複合退出の市場の独立確認/停止.json": "213de78f3ab44e0d4ec7575b7bea64fae994c82bc32f66d7d771eb9b95bd673c",
    "work/101市場条件の固定/停止.json": "b698f05840ba655f50dd29523a3a2018d0019638e262e1ea0c12a7ab9080b6a0",
    "work/101市場条件の固定_版2/停止.json": "24ee130e218266b2a1ae4f4d36ca2a91b9bfffef75bcdd53f19549a4bc10554f",
    "work/短秒複合退出の市場の独立確認_版2/停止.json": "077eac32aed7d4a9d0031f1178c31151f72ee1a5370db966b233b81ccf823167",
    "work/101集計と閲覧資料/停止.json": "2d94387f2443e8c127eafde8716df1688a63d1760adae1278dd288957aa399d7",
    "work/101producer指定の読取照合/停止.json": "e29818549c7a13581dfdb79f8352aae9a6aed4d368bacfab3959212eec1eea7d",
    "work/101連続入力の読取照合/停止.json": "11ce4ded7e9168ffce41d6f2827307a77de5ac2fd4cde6329f545930a2fc9a24",
    "work/101連続入力の全54読取照合/停止.json": "72730ff759bcf447b2d44eb9b271a50a71291ec9cabc1fbbf4677215f035c091",
    "work/101連続入力の全54場_版3/停止.json": "a75e4aa6fd9eac4bdb9707add16d3c33847e950ae096b924b622504f3e0f272a",
    "work/短秒複合退出の再生/停止.json": "ff571dba63a439e9df2fc855f722da1e506ee26cc1ef483de9aa4356e39e2eb7",
    "work/短秒複合退出の金融/停止.json": "f3606e629a84df0530266d6c43fc89d48df87985841baaaeb0c1471ec6046501",
    "work/短秒複合退出の純式/停止.json": "0e2e50bc391586daf0040cb9abab2b388b3f9ff23980d50d4f0e50eaa3580f9e",
    "work/101連続入力の試作_版2/停止.json": "e2901b5a4d0207bb86fb1af579cdc824d8e94cd3d37654ead732ec5a28732869",
}
CODE_FIELDS = {"コードSHA256", "所有コードSHA256", "必須コードSHA256", "由来SHA256", "入力根拠SHA256", "Python再用依存SHA256"}
SOURCE_EXTENSIONS = {".go", ".mod", ".sum", ".py", ".md", ".patch"}
PROOF100 = "study/00100_費用後利益化の前後で保護を分ける/完了記録.json"
MAX_SOURCE_BYTES = 2 * 1024 * 1024
MAX_METADATA_BYTES = 8 * 1024 * 1024


def need(ok: bool, reason: str) -> None:
    """
    機能: 保存範囲・指紋の不成立を停止する。
    引数: ok(bool)、reason(str)は成立と理由。
    返り値: None。不成立時はValueError。
    """
    if not ok:
        raise ValueError(reason)


def digest(path: Path) -> str:
    """
    機能: 許可したコード又はmetadataのbytes指紋を求める。
    引数: path(Path)は選択済み対象。
    返り値: strはSHA256。入力市場本文は対象にしない。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def sha(value) -> bool:
    """
    機能: 小文字SHA256の型と形式を確認する。
    引数: value(object)は候補。
    返り値: boolは正しい64桁か。
    """
    return isinstance(value, str) and re.fullmatch("[0-9a-f]{64}", value) is not None


def bytes_json(value: object) -> bytes:
    """
    機能: metadataをUTF-8/LFの再現可能な表現へ変換する。
    引数: value(object)はJSON値。
    返り値: bytesは末尾LF付き。
    """
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def archive_name(root: Path, path: Path) -> str:
    """
    機能: repoと既存siblingだけを安全なzip prefixへ写す。
    引数: root/path(Path)はrepoとコード位置。
    返り値: strは絶対pathや..を含まないentry名。
    """
    root, path = root.resolve(), path.resolve()
    for base in (root, root.parent / "SessionTradeExecuter"):
        if path.is_relative_to(base):
            result = base.name + "/" + path.relative_to(base).as_posix()
            need(not PurePosixPath(result).is_absolute() and ".." not in PurePosixPath(result).parts, "安全でないentry")
            return result
    raise ValueError("コード保存を許可していないroot: " + str(path))


def classify(path: Path) -> str | None:
    """
    機能: コード/小metadataの明示許可を判定する。
    引数: path(Path)は参照先。市場本文は開かない。
    返り値: str又はNoneは保存区分又は参照のみ。
    """
    low = path.as_posix().lower()
    if any(x in low for x in ("/venv", "/pkg/mod/", "/人工/", "/成果物/")) or low.endswith((".exe", ".gz", ".jsonl", ".csv", ".png", ".log")):
        return None
    if path.suffix.lower() in SOURCE_EXTENSIONS:
        return "コード・仕様"
    if path.suffix.lower() == ".json" and (path.name in {"停止.json", "許可54.json", "由来.json", "由来と配置差.json", "完了記録.json"}
                                          or path.name.endswith("の雛形.json")):
        return "停止・小metadata"
    return None


def eval_path(node: ast.AST, env: dict) -> object:
    """
    機能: Pythonの静的path式だけを解釈し実importを避ける。
    引数: node(AST)、env(dict)は字句と既知定数。
    返り値: objectはPath/str/int。非静的式はValueError。
    """
    if isinstance(node, ast.Constant) and isinstance(node.value, (str, int)):
        return node.value
    if isinstance(node, ast.Name) and node.id in env:
        return env[node.id]
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Div):
        return Path(eval_path(node.left, env)) / eval_path(node.right, env)
    if isinstance(node, ast.Attribute):
        value = eval_path(node.value, env)
        if node.attr == "parent":
            return Path(value).parent
        if node.attr == "parents":
            return Path(value).parents
    if isinstance(node, ast.Subscript):
        return eval_path(node.value, env)[eval_path(node.slice, env)]
    if isinstance(node, ast.Call):
        if isinstance(node.func, ast.Name) and node.func.id == "Path" and len(node.args) == 1:
            return Path(eval_path(node.args[0], env))
        if isinstance(node.func, ast.Attribute):
            value = Path(eval_path(node.func.value, env))
            if node.func.attr == "resolve" and not node.args:
                return value.resolve()
            if node.func.attr == "with_name" and len(node.args) == 1:
                return value.with_name(eval_path(node.args[0], env))
    raise ValueError("非静的path式")


class Collector:
    """停止mapと静的Python参照だけから保存閉包を求める。市場値は評価しない。"""

    def __init__(self, root: Path):
        """
        機能: 保存候補・除外参照の台帳を初期化する。
        引数: root(Path)はrepo。
        返り値: None。
        """
        self.root = root.resolve()
        self.files: dict[Path, dict] = {}
        self.queue: list[Path] = []
        self.excluded: dict[tuple[str, str], set[str]] = collections.defaultdict(set)
        self.python_edges: set[tuple[str, str, str]] = set()
        self.unresolved: set[tuple[str, str]] = set()

    def relative(self, path: Path) -> str:
        """
        機能: 元repoからの位置を保持する。
        引数: path(Path)はコード又は参照先。
        返り値: strはsiblingの../を含み得る元path。zip entryとは分離する。
        """
        try:
            return os.path.relpath(path.resolve(), self.root).replace("\\", "/")
        except ValueError:
            # 別driveのGo cache等は復元用の元絶対pathだけを保持する。
            return path.resolve().as_posix()

    def add(self, path: Path, expected: str | None, cause: str) -> None:
        """
        機能: 許可対象だけをhashし候補へ加える。
        引数: path(Path)、expected(str又はNone)、cause(str)は出典。
        返り値: None。除外対象は宣言SHA参照だけ記録する。
        """
        path = path.resolve()
        kind = classify(path)
        if kind is None:
            self.excluded[(self.relative(path), expected or "未宣言")].add(cause)
            return
        archive_name(self.root, path)
        need(path.is_file(), "コード/停止欠落: " + str(path))
        need(path.stat().st_size <= (MAX_METADATA_BYTES if path.suffix == ".json" else MAX_SOURCE_BYTES), "小型保存上限超過: " + str(path))
        actual = digest(path)
        need(expected is None or sha(expected) and actual == expected, "保存元SHA差: " + str(path))
        if path in self.files:
            need(self.files[path]["sha256"] == actual, "同pathの保存中差")
            self.files[path]["根拠"].add(cause)
            return
        self.files[path] = {"source_path": self.relative(path), "entry": archive_name(self.root, path),
                            "sha256": actual, "bytes": path.stat().st_size, "区分": kind, "根拠": {cause}}
        self.queue.append(path)

    def metadata(self, path: Path) -> None:
        """
        機能: 停止/由来のコード参照mapを辿る。
        引数: path(Path)は許可済み小metadata。
        返り値: None。過去金融結果や全指紋mapは展開しない。
        """
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        if not isinstance(value, dict):
            return
        for label in CODE_FIELDS:
            mapping = value.get(label)
            if not isinstance(mapping, dict):
                continue
            for name, expected in mapping.items():
                if not isinstance(name, str) or not sha(expected):
                    continue
                p = Path(name)
                if not p.is_absolute():
                    p = (self.root if name.replace("\\", "/").startswith(("work/", "scripts/", "study/", "docs/", "../")) else path.parent) / p
                self.add(p, expected, self.relative(path) + "#" + label)

    def python(self, path: Path) -> None:
        """
        機能: 静的Python pathと固定SHAの参照閉包を求める。
        引数: path(Path)は保存済みPython。
        返り値: None。コードの実行/importはしない。
        """
        tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
        env = {"__file__": str(path), "ROOT": self.root, "HERE": path.parent}
        for node in tree.body:
            if isinstance(node, (ast.Assign, ast.AnnAssign)):
                targets = node.targets if isinstance(node, ast.Assign) else [node.target]
                try:
                    v = eval_path(node.value, env)
                except (ValueError, TypeError, KeyError, IndexError, AttributeError):
                    continue
                for target in targets:
                    if isinstance(target, ast.Name):
                        env[target.id] = v
        for name, value in tuple(env.items()):
            if not isinstance(value, Path) or value.suffix not in {".py", ".json"}:
                continue
            expected = None
            for suffix in ("_PATH", "_STOP"):
                if name.endswith(suffix):
                    for candidate in (name.removesuffix(suffix) + "_SHA", name + "_SHA"):
                        if sha(env.get(candidate)):
                            expected = env[candidate]
                            break
            if sha(env.get(name + "_SHA")):
                expected = env[name + "_SHA"]
            self.add(value, expected, self.relative(path) + "#静的定数:" + name)
            if value.suffix == ".py":
                self.python_edges.add((self.relative(path), self.relative(value), expected or "静的path・現物SHA"))
        # ----------------------------------------
        # HERE/ROOTとliteralを結ぶ式も拾う。市場入力を指す文字列は分類後に除外する。
        for node in ast.walk(tree):
            if not isinstance(node, ast.BinOp) or not isinstance(node.op, ast.Div):
                continue
            try:
                v = eval_path(node, env)
            except (ValueError, TypeError, KeyError, IndexError, AttributeError):
                continue
            if isinstance(v, Path) and v.suffix == ".py" and v.is_file():
                self.add(v, None, self.relative(path) + "#静的path式")
                self.python_edges.add((self.relative(path), self.relative(v), "静的path・現物SHA"))

    def close(self) -> None:
        """
        機能: 許可metadata/Pythonだけを閉包まで読む。
        引数: なし。
        返り値: None。順序は元pathで決定する。
        """
        while self.queue:
            p = self.queue.pop(0)
            if p.suffix == ".py":
                self.python(p)
            elif p.suffix == ".json":
                self.metadata(p)


def module_info(name: str) -> dict:
    """
    機能: Go cache pathから取得module版だけを抽出する。
    引数: name(str)は固定依存path。
    返り値: dictはmodule/version/取得手順又はrepo依存の区分。
    """
    normalized = name.replace("\\", "/")
    match = re.search(r"/pkg/mod/cache/download/(.+?)/@v/([^/]+)\.(?:mod|info|ziphash|zip)$", normalized)
    if not match:
        match = re.search(r"/pkg/mod/(?!cache/)(.+?)@([^/]+)/", normalized)
    if not match:
        return {"種別": "repo又は既存ローカル依存", "本文保存": False}
    module = re.sub(r"!([a-z])", lambda m: m[1].upper(), match[1])
    return {"種別": "Go module cache", "module": module, "version": match[2],
            "取得": "go mod download " + module + "@" + match[2], "本文保存": False}


def build(root: Path, out: Path, own: list[Path]) -> dict:
    """
    機能: 候補manifest/zipを新規保存し全entryを読み戻す。
    引数: root/out(Path)、own(list[Path])はrepo・未使用出力・保存道具。
    返り値: dictはzip/manifest/全entry確認の小receipt。
    """
    need(not out.exists(), "出力dirは新規のみ")
    c = Collector(root)
    for name, expected in SEEDS.items():
        c.add(root / name, expected, "固定seed停止")
    wrapper = json.loads((root / next(iter(SEEDS))).read_bytes())
    producer = json.loads((root / "work/101連続入力の試作_版3/停止.json").read_bytes())
    code = dict(wrapper["必須コードSHA256"])
    need(len(code) == 299 and len(producer["所有コードSHA256"]) == 13, "元code件数差")
    for name, expected in producer["所有コードSHA256"].items():
        need(name not in code or code[name] == expected, "producer union衝突")
        code[name] = expected
    need(len(code) == 312 and len(wrapper["Go依存SHA256"]) == 250, "完全code/依存件数差")
    for name, expected in code.items():
        c.add(root / name, expected, "候補市場条件コード312")
    for p in own:
        c.add(p, None, "今回の保存・条件metadata確認道具")
    c.close()
    entries = []
    for p, v in sorted(c.files.items(), key=lambda pair: pair[1]["entry"]):
        entries.append({**v, "根拠": sorted(v["根拠"])})
    dependencies = [{"original_path": n, "sha256": h, **module_info(n)} for n, h in sorted(wrapper["Go依存SHA256"].items())]
    manifest = {"version": 1, "試行候補": 101, "scope": "市場実行前のwork停止コード保存候補（金融/入力本文処理なし）",
                "元repo": str(root), "停止seed": SEEDS, "条件候補コードSHA256": code,
                "条件候補code数": 312, "Go依存": dependencies, "Go依存数": 250,
                "Go依存本文": "新たにGo cacheを複製しない。条件code312と重なるローカルcodeだけはその正本を保存。取得後250件の指紋一致が必要。",
                "entries": entries, "Python静的参照": [dict(source=a, target=b, expected_sha256=h) for a,b,h in sorted(c.python_edges)],
                "本文を保存しない参照": [dict(source_path=p, sha256=h, 根拠=sorted(causes), 現物本文読取=False)
                                       for (p,h),causes in sorted(c.excluded.items())],
                "市場未使用の対応版": "canonical4moduleは別指紋の人工対応。今回のruntime/金融/consumer/producer/importを差し替えない。",
                "復元": "FutureSignalResearch/とSessionTradeExecuter/をsiblingとして復元。元path/絶対Go cache path制約を留保し、元コードを書換えない。",
                "除外": ["Raw/CSV", "実header/records", "Tape/Native", "実結果/市場読戻し本文", "exe/venv/Go cache本文", "巨大人工JSON/画像/log"],
                "未実施": ["実conditionとの結合", "コード移植/書換え/再build", "市場金融/技法採否", "Source/Current/Chart形成", "Raw/Native/stream意味展開"]}
    body = bytes_json(manifest)
    out.mkdir(parents=True, exist_ok=False)
    archive = out / "市場実行版コード_候補.zip"
    manifest_path = out / "候補manifest.json"
    try:
        with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for row in entries:
                data = (root / row["source_path"]).read_bytes()
                need(hashlib.sha256(data).hexdigest() == row["sha256"], "archive前の元code差")
                info = zipfile.ZipInfo(row["entry"], date_time=(2026, 11, 9, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                info.external_attr = 0o100644 << 16
                z.writestr(info, data)
            info = zipfile.ZipInfo("manifest.json", date_time=(2026, 11, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, body)
        checks = []
        with zipfile.ZipFile(archive) as z:
            need(set(z.namelist()) == {r["entry"] for r in entries} | {"manifest.json"} and len(z.namelist()) == len(entries) + 1, "zip entry集合/重複差")
            for row in entries:
                need(hashlib.sha256(z.read(row["entry"])).hexdigest() == row["sha256"], "zip読戻しSHA差")
                checks.append(row["entry"])
            need(z.read("manifest.json") == body, "zip内manifest bytes差")
            need(z.testzip() is None, "zip CRC差")
        for p, row in c.files.items():
            need(digest(p) == row["sha256"], "保存前後code差")
        manifest_path.write_bytes(body)
        receipt = {"成功": True, "scope": manifest["scope"], "停止seed": SEEDS,
                   "manifest": {"path": manifest_path.name, "sha256": hashlib.sha256(body).hexdigest()},
                   "archive": {"path": archive.name, "sha256": digest(archive), "bytes": archive.stat().st_size},
                   "候補条件code": 312, "外部Go指紋": 250, "保存ファイル": len(entries), "zip全entry": len(entries)+1,
                   "読戻し確認": len(checks)+1, "差": 0, "CRC差": 0, "元code前後不変": True,
                   "元codeSHA256": {r["source_path"]: r["sha256"] for r in entries},
                   "Python参照edge": len(c.python_edges), "除外参照": len(c.excluded),
                   "実condition/金融/市場本文/移植/再build/正式編集": 0}
        (out / "確認.json").write_bytes(bytes_json(receipt))
        return receipt
    except BaseException:
        # 作成途中のdirは調査用に保持し、成功receiptは作らない。
        raise


def check_condition(manifest_path: Path, condition_path: Path, expected: str) -> dict:
    """
    機能: 後日実conditionのmetadataだけを候補集合へ結合する。
    引数: manifest_path/condition_path(Path)、expected(str)は実条件のRoot固定SHA。
    返り値: dictは集合・停止・依存の一致。参照した入力本文は開かない。
    """
    need(sha(expected) and digest(condition_path) == expected, "条件SHA未固定/差")
    m = json.loads(manifest_path.read_bytes())
    c = json.loads(condition_path.read_bytes())
    need(c.get("試行") == 101 and c.get("version") == 1 and c.get("市場損益を開く前の固定") is True, "条件版/前固定差")
    need(c.get("コードSHA256") == m["条件候補コードSHA256"], "条件code集合/指紋差")
    need(c.get("Go依存SHA256") == {r["original_path"]:r["sha256"] for r in m["Go依存"]}, "条件Go依存集合差")
    need(set(c.get("stages", {})) == {"first2", "full54"}, "条件stage差")
    producer = "cf49b2b643afcfda478a5d383c6d5e73bbbee3b477d2a0edc0e45b745ef4d16c"
    for spec in c["stages"].values():
        need(spec.get("producer_stop", {}).get("sha256") == producer, "入力producer版差")
    labels = {"市場wrapper停止":"work/短秒複合退出の市場接続/停止.json", "runtime停止":"work/短秒複合退出の再生/停止.json",
              "金融停止":"work/短秒複合退出の金融/停止.json", "純式停止":"work/短秒複合退出の純式/停止.json",
              "sidecar版2停止":"work/101連続入力の試作_版2/停止.json"}
    for label, name in labels.items():
        need(c.get(label, {}).get("sha256") == SEEDS[name], "条件停止差:"+label)
    return {"成功": True, "scope": "条件metadataと保存候補の結合だけ", "条件SHA256": expected,
            "manifestSHA256": digest(manifest_path), "code数": 312, "Go依存数": 250,
            "code/依存/停止一致": True, "市場本文/金融/入力参照展開": 0}


def main() -> None:
    """
    機能: コード候補の保存又は後日の条件metadata確認を行う。
    引数: CLIのbuild/check-condition。市場CLIではない。
    返り値: None。成功receiptを表示する。
    """
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    b = sub.add_parser("build")
    b.add_argument("--root", type=Path, required=True)
    b.add_argument("--out", type=Path, required=True)
    q = sub.add_parser("check-condition")
    q.add_argument("--manifest", type=Path, required=True)
    q.add_argument("--condition", type=Path, required=True)
    q.add_argument("--condition-sha", required=True)
    q.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    if a.command == "build":
        here = Path(__file__).resolve().parent
        value = build(a.root.resolve(), a.out.resolve(), [here/n for n in ("コードを保存する.py", "保存人工.py", "README.md")])
    else:
        need(not a.out.exists(), "確認出力は新規のみ")
        value = check_condition(a.manifest, a.condition, a.condition_sha)
        with a.out.open("xb") as f:
            f.write(bytes_json(value))
    print(json.dumps({k:v for k,v in value.items() if k != "元codeSHA256"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
