"""保存先・コード閉包・本文除外・後日の条件metadata結合だけを確認する。"""
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("archive101", HERE/"コードを保存する.py")
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)


class ArchiveTests(unittest.TestCase):
    """実市場値のない小型ファイルだけで保存規約を確認する。"""

    def test_go_module_version(self):
        """
        機能: 展開cacheとdownload metadataの取得版を区別する。
        引数: self(ArchiveTests)はテスト。
        返り値: None。Go cache本文を開かない。
        """
        for p in ("C:/go/pkg/mod/github.com/!burnt!sushi/toml@v1.5.0/a.go",
                  "C:/go/pkg/mod/cache/download/github.com/!burnt!sushi/toml/@v/v1.5.0.mod"):
            value=M.module_info(p)
            self.assertEqual(value["module"],"github.com/BurntSushi/toml")
            self.assertEqual(value["version"],"v1.5.0")
            self.assertEqual(value["取得"],"go mod download github.com/BurntSushi/toml@v1.5.0")

    def test_safe_sibling_and_rejection(self):
        """
        機能: 元repo/siblingの安全なprefixと他root拒否を確認する。
        引数: self(ArchiveTests)はテスト。
        返り値: None。
        """
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)/"FutureSignalResearch"
            self.assertEqual(M.archive_name(root, root/"work/a.py"), "FutureSignalResearch/work/a.py")
            self.assertEqual(M.archive_name(root, root.parent/"SessionTradeExecuter/internal/a.go"), "SessionTradeExecuter/internal/a.go")
            with self.assertRaises(ValueError):
                M.archive_name(root, root.parent/"outside/a.go")
            with self.assertRaises(ValueError):
                M.archive_name(root, root/"../outside/a.go")

    def test_code_closure_without_import(self):
        """
        機能: 静的Python参照と固定SHAを辿り、コードを実行しない。
        引数: self(ArchiveTests)はテスト。
        返り値: None。実行すると必ず失敗するcodeをopaqueに保存する。
        """
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)/"FutureSignalResearch"
            here = root/"work/a"; there = root/"work/b"
            here.mkdir(parents=True); there.mkdir(parents=True)
            child = there/"b.py"; child.write_text("raise RuntimeError('実行禁止')\n", encoding="utf-8")
            parent = here/"a.py"
            parent.write_text("from pathlib import Path\nROOT=Path(__file__).resolve().parents[2]\nCHILD_PATH=ROOT/'work/b/b.py'\nCHILD_SHA='"+M.digest(child)+"'\nraise RuntimeError('import禁止')\n", encoding="utf-8")
            c = M.Collector(root); c.add(parent, M.digest(parent), "人工seed"); c.close()
            self.assertEqual(len(c.files), 2)
            self.assertTrue(any(e[1] == "work/b/b.py" for e in c.python_edges))
            parent.write_text(parent.read_text(encoding="utf-8").replace(M.digest(child), "a"*64), encoding="utf-8")
            c = M.Collector(root); c.add(parent, M.digest(parent), "人工seed")
            with self.assertRaises(ValueError):
                c.close()

    def test_forbidden_body_is_not_opened(self):
        """
        機能: 禁止参照のSHA宣言だけを残し本文を開かない。
        引数: self(ArchiveTests)はテスト。
        返り値: None。
        """
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)/"FutureSignalResearch"; c=M.Collector(root)
            refs=["raw.csv", "a.header.json", "a.records.jsonl.gz", "a.tape.gz", "a.exe", "人工/a.json", "成果物/結果.json", "venvs/x/a.py"]
            with mock.patch.object(Path,"open",side_effect=AssertionError("禁止本文のopen")):
                for name in refs:
                    c.add(root/name,"a"*64,"除外人工")
            self.assertEqual(len(c.files),0)
            self.assertEqual(len(c.excluded),len(refs))

    def test_metadata_condition_binding_only(self):
        """
        機能: 実入力参照を開かず条件code/依存/停止の一致だけを結ぶ。
        引数: self(ArchiveTests)はテスト。
        返り値: None。差分又は未固定SHAは拒否する。
        """
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            code={"c"+str(i):"a"*64 for i in range(312)}
            deps={"d"+str(i):"b"*64 for i in range(250)}
            manifest={"条件候補コードSHA256":code,"Go依存":[{"original_path":n,"sha256":h} for n,h in deps.items()]}
            c={"試行":101,"version":1,"市場損益を開く前の固定":True,"コードSHA256":code,"Go依存SHA256":deps,
               "stages":{s:{"producer_stop":{"path":"開かない停止","sha256":M.SEEDS['work/101連続入力の試作_版3/停止.json']}} for s in ("first2","full54")}}
            for label,name in [("市場wrapper停止","市場接続"),("runtime停止","再生"),("金融停止","金融"),("純式停止","純式")]:
                c[label]={"path":"開かない停止","sha256":M.SEEDS['work/短秒複合退出の'+name+'/停止.json']}
            c['sidecar版2停止']={"path":"開かない停止","sha256":M.SEEDS['work/101連続入力の試作_版2/停止.json']}
            mp=root/'manifest.json';cp=root/'condition.json'
            mp.write_bytes(M.bytes_json(manifest));cp.write_bytes(M.bytes_json(c))
            self.assertTrue(M.check_condition(mp,cp,M.digest(cp))["成功"])
            with self.assertRaises(ValueError):M.check_condition(mp,cp,"")
            c["コードSHA256"]={**code,"追加":"c"*64};cp.write_bytes(M.bytes_json(c))
            with self.assertRaises(ValueError):M.check_condition(mp,cp,M.digest(cp))


if __name__ == "__main__":
    unittest.main(verbosity=2)
