# 101の市場実行版コードを保存する準備

本作業は金融・技法採否を実行せず、停止metadataとコードをそのまま保存する。正式101にはまだ配置しない。元work、既存停止、旧100/236、Source、条件、canonical4moduleを書換えず、移植・再buildもしない。

市場の実行予定版はwork wrapper265734、runtime ff571d、金融f3606e、短秒純式0e2e50、consumer e290、入力producer cf49である。条件組立helperは実full54のproducer_stopを扱う版2停止24ee13、市場独立器は許可54のnative_sha256を扱う版2停止077eacを現行として保存し、旧b698/213deも由来として残す。保存postprocessor停止2d9438とPython依存25も保存する。canonical4moduleは別指紋の人工対応であり、今回の市場実行版ではない。

## 保存集合

`コードを保存する.py build`はwrapper必須299＋producer所有13＝312の厳密union、停止seed、監査/読戻し/helper/保存器の所有code・由来map、固定Python pathの静的参照を閉包まで辿る。PythonはASTだけを読み、import・関数呼出・金融式評価を行わない。固定SHAが宣言されたコードは現物へ一致を要求する。その他の静的pathは現物SHAを記録する。停止の過去前後入力mapや閉鎖の全成果物mapを市場値へ展開しない。

保存するものはGo/Python本体・go.mod/go.sum・README/計画・patch、小さい停止/許可54/由来/雛形/必要閉鎖metadataである。実条件がない現時点では『条件候補コードSHA256』312と外部Go250の取得版・元path・SHAだけを記録する。Go cache本文は複製しない。250のうち312と重なるrepo/sibling codeは312の正本として一度だけ格納し、新しいcacheコピーは作らない。取得後に全250SHAの一致が必要である。

実header/records、Raw/CSV、Tape/Native、実結果・市場readback本文、exe、venv、画像/log、巨大人工JSONは入れない。コードや停止内の参照SHAと除外理由は残すが、それらの対象を開かない。手製fixtureを同梱したことにも、コードだけで元人工の全再実行が可能なことにもしない。元停止が参照する小metadataはそのまま保持するので、記載された過去成果物の存在・成功を新規に確認した意味ではない。

zip内では`FutureSignalResearch/<元repo内path>`と`SessionTradeExecuter/<元sibling内path>`を用い、entry名に絶対pathや`..`を入れない。manifestは元repo相対pathと安全entry名を別々に保存する。解凍時は二repoをsiblingとして配置する。Go cacheなど既存絶対path制約は留保し、復元先変更のため元コードを書き換えたとは扱わない。

## 作成と読戻し

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101実行コードの保存準備/コードを保存する.py' build `
  --root (Get-Location).Path --out 'work/101実行コードの保存準備/候補'
```

出力dirは新規のみ。`候補manifest.json`と同体のmanifestをzip内にも保存し、全entryのSHA/集合/重複/CRC、元コード前後SHAを確認する。zip自体のSHAは外の`確認.json`へ保存する。作成途中に失敗した場合は調査用dirだけを残し、成功receiptを作らない。

## 実条件が届いた後の小metadata確認口

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101実行コードの保存準備/コードを保存する.py' check-condition `
  --manifest 'work/101実行コードの保存準備/候補/候補manifest.json' `
  --condition 'Rootが固定した条件.json' --condition-sha 'Rootの完全SHA' `
  --out '未使用の条件結合確認.json'
```

この口は条件JSONと保存manifestだけを読み、コード312/依存250/停止の集合とSHAを照合する。条件が指すTape/Native/Header/Records/実行物は開かず、実金融のpreflightや全入力検査の代用にはしない。Root実condition受領前には実行しない。

`保存人工.py`は安全prefix/他root拒否、静的コード閉包と非import、本文除外、未固定条件/集合差拒否を小型人工で確認する。今回の停止ではこの人工と候補zip読戻しを分けて記録する。
