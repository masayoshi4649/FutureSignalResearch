"""連続sidecarの場末公開値を旧100の限定正本へ全値照合する。"""

import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
BASELINE = Path(__file__).with_name("旧先頭2場の場末.json")
BASELINE_SHA = "99795af83771bad57380a9a4438dc9fcb1294ecba70fefc6ad74506ec2d15ede"


def digest(path: Path) -> str:
    """機能: ファイルの指紋を得る。

    引数: path (Path) は対象ファイル。
    返り値: str はSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def materialize(header: dict, state: dict) -> dict:
    """機能: 公開辞書と場末stateからSnapshot全値を復元する。

    引数: header/state (dict) は保存した公開辞書と場末参照。
    返り値: dict はSnapshot全field。辞書SHAのGo encoding検査を代用しない。
    """
    payload = header["chart_payloads"][state["payload_sha256"]]
    return {
        "scene": payload["scene"],
        "at": state["at"],
        "has_observed_clock": state["has_observed_clock"],
        "observed_clock": state["observed_clock"],
        "has_last_input": state["has_last_input"],
        "last_input": state["last_input"],
        "invalidated_at": state["invalidated_at"],
        "chart": payload["chart"],
        "three": payload["three"],
        "fifteen": payload["fifteen"],
        "carried_numeric_seed": payload["carried_numeric_seed"],
        "sealed": state["sealed"],
    }


def main() -> None:
    """機能: 先頭2場の成功receiptと限定場末正本を結ぶ。

    引数: CLI --receipt/--out (Path) は既存成功と新規保存先。
    返り値: None。Raw/金融本文や後続データを読まない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--receipt", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    assert not args.out.exists() and digest(BASELINE) == BASELINE_SHA
    receipt = json.loads(args.receipt.read_text(encoding="utf-8"))
    assert receipt["成功"] and receipt["前後不変"] and receipt["stage"] == "first2"
    assert receipt["sessions"] == ["2026-09-21_Day", "2026-09-21_Night"]
    baseline = json.loads(BASELINE.read_text(encoding="utf-8"))
    assert baseline["成功"] and baseline["前後不変"]
    before = {str(p): digest(p) for p in (BASELINE, args.receipt, Path(__file__))}
    results = []
    for row in baseline["rows"]:
        path = args.receipt.parent / (row["session"] + ".header.json")
        before[str(path)] = digest(path)
        header = json.loads(path.read_text(encoding="utf-8"))
        actual = materialize(header, header["ending"])
        assert actual == row["chart_end"], row["session"] + "の場末全文差"
        assert header["source_reexecuted"] is False and header["financial_executed"] is False
        results.append({"session": row["session"], "一致": True, "field除外": [], "header_SHA256": before[str(path)], "元NativeSHA256": row["native_SHA256"]})
    assert all(digest(Path(p)) == sha for p, sha in before.items())
    value = {"成功": True, "scope": "先頭2場sidecar場末の独立辞書復元と固定100 chart_endの全値比較", "場末": results, "入力コードSHA256前後": before, "前後不変": True, "Raw/新金融/新約定/新損益/機会損失": 0}
    with args.out.open("x", encoding="utf-8", newline="\n") as target:
        json.dump(value, target, ensure_ascii=False, indent=2)
        target.write("\n")
    print(json.dumps({"成功": True, "場数": len(results), "SHA256": digest(args.out)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
