# 連続技法sidecarの公開型試作（実データ未実行）

版2は旧停止d7bac2e1を保持した接続修正版。旧100 Tape台帳の相対pathはrepo基準でなく台帳ディレクトリ基準で解決し、Abs化する。Tape Sourceの存在/通常ファイル/SHAは新規出力作成前に検査する。価格・ATR・特徴・時計・Source通知の数式変更はない。

元計画は[cb9ea799](../101連続入力の拡張計画/停止.json)、今回の範囲は[実装前計画](実装前計画.md)。旧正式コードは変更せず、固定93/96のFeatures/Bank公開APIだけを呼ぶ。Source/Actual/退出式は運転しない。

`Build(Request,*warm.Seed) (Sidecar,*warm.Seed,error)`は公開Board/Candle/SessionからCurrent/Chartを作る。`Materialize(Sidecar,State)`は内容SHA付き辞書からfull warm.Snapshotを復元する。`BindLegacy(Sidecar,oldTape)`は全Scalar11・全5分TechnicalGateInputを比較し、小型LegacyMatchを返す。巨大sidecarのJSON再複写を比較のために行わない。旧Tape自体を上書きしない。

新規の旧5分Inputは元SnapshotID/Current/Recent3/Chartを全値比較する。同秒は公表→Grid→raw、Sourceの旧Forceは旧Tape内でGridより先のまま。新RawのCurrentを同秒Gridへ戻さない。Last0はchart失効だけ、FeaturesはLast正のみ。badBBO/Last正の特徴更新は残す。FeaturesIndex/物理行/chart全受理indexを混同しない。

`input.go`は固定96原本のpackage名1箇所だけ変更した機械派生。関数本文、closed CSV・Time+interval+delay、CurrentPriceTime→Time/Received、同秒両市場stable順は維持する。Receivedは実受信時計を証明しない。生成前に固定100閉鎖・54場・台帳・旧Tape指紋・停止コード/実行物を検査し、終了後も全入力/コードを検査する。旧100の圧縮Native本文はロードしない。

Featuresは場ごとに新規作成し、夜間P→U時刻でresetしない。チャート数値Seedだけ同限月でメモリ継承し、前3分追跡/形成/公開maskは初期化する。私有SeedはJSONへ保存せず、任意の途中場から助走を省略しない。CLIは固定先頭2場の成功後だけ同版54へ進める。

人工は公開型の手製板/CSVであり、実原板のSource形成・市場旧同値・実受信時刻の証明ではない。人工の旧Tape型にもSource判断を補完しない。full CurrentにはShort/Buy/Sell/Night全文を残す。X5のP/Mは確定3分値のため連続Currentだけで変化するとは限らず、改善を仮定しない。新しい退出条件・閾値・損益・機会損失を評価しない。

## 人工と実行口

```powershell
go test -count=1 ./...
go vet ./...
go build -o 連続入力.exe ./cmd/build
```

Rootの別許可後にだけ、repoルートから次を実行する。`--out`は未存在dirを指定する。全54の実行は本準備では行わない。

```powershell
& 'work/101連続入力の試作_版2/連続入力.exe' --run `
  --root (Get-Location).Path `
  --proof100 'study/00100_費用後利益化の前後で保護を分ける/完了記録.json' `
  --allowed 'work/101連続入力の試作_版2/許可54.json' `
  --manifest 'study/00080_FAR後期三手法の15分移植と利益保護/入力台帳.json' `
  --index 'study/00100_費用後利益化の前後で保護を分ける/接続2場Tape台帳.json' `
  --stop 'work/101連続入力の試作_版2/停止.json' `
  --stage first2 --out 'work/101連続入力の実行/接続2場_版2'
```

上記manifestは固定SHA b939…と照合する。CLIは一致する明示pathだけを許可する。全54は`--stage full54`・正式54Tape台帳・同版first2の`完了.json`を`--first2`へ指定する。

実CLIは`BuildToSink`を用い、一場ごとの`.records.jsonl.gz`と`.header.json`、小型`完了.json`を作る。headerは辞書/全旧5分Input/終値を保持する。原行は`Record{kind:row,row,tape_ordinal}`、公表/Grid/TOPIX/Last0は`Record{kind:control,control,tape_ordinal?}`。positiveNKのraw Traceを重複出力しない。原行Recent3はState参照だけとし、header辞書から元公開Snapshot全文へ戻す。原行対応はrecordの旧ordinal、headerの旧bindingはGrid分だけを持つ。旧Tapeのcanonical JSON SHAと元gzip SHAを区別する。

Currentの可変窓mapは値型窓だけを複写し、JSON再parseを毎行挟まない。全Rows/全rawTraceは実CLIのRAMへ貯めず、元Raw・CSV・旧Tapeも複製しない。旧loaderの一括配列はそのままなので入力側のメモリは残る。場ごとの行数/圧縮bytes/全経過秒/stream経過秒/1024recordごとのGo heap・Sys標本最大を保存する。OSの真のRSSピークではない。既定資源上限は100万positiveNK行、heap標本4GiB。`--max-nk-rows`/`--max-heap-mib`で明示でき、超過時は成功receiptを出さず停止する。上限変更は売買条件変更ではない。

全費用/遅延Actorは将来同じsidecarを参照できる。Snapshot辞書にもLast0の失効maskを残す。人工のstream→再構成全文一致は実データでの同値・圧縮効果・速度を保証しない。first2の容量/時間/メモリをRootが確認するまで54を実行しない。

数値Seedの公開永続化APIがないため、別プロセスのfull54では先頭2場も時系列prefixとして再処理する。first2の公開headerをSeedとみなして助走を省略しない。旧Source・金融はこの再処理にも含まない。

旧Tapeにchart_endはないため、本CLIの旧値比較はScalar11と全5分Inputだけである。Endingは新bank.Sealの保存/無損失復元までで、旧Ending一致は未実施とreceiptへ明示する。旧Endingとの市場比較はRootが別途限定出典を用意する段階であり、本CLIの成功へ含めない。旧助走をもう一度Rawから再生して比較値を作らない。
