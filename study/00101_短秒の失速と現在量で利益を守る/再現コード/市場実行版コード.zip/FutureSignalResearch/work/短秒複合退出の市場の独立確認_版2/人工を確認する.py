"""停止済み完全接続人工24と小型metadataだけを新しい配送へ接続する。"""

from collections import Counter
import copy
import gzip
import importlib.util
import json
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SPEC = importlib.util.spec_from_file_location('短秒市場独立_人工', HERE/'市場と短秒を照合する.py')
M = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = M
SPEC.loader.exec_module(M)


def reject(name, action, rows):
    """
    機能: 狭い破損を成功へ読み替えないことを確認する。
    引数: name(str)、action(callable)、rows(list)は識別・破損処理・証拠。
    返り値: None。拒否しなければAssertionError。
    """
    try:
        action()
    except (ValueError, KeyError, AssertionError, StopIteration) as error:
        rows.append(dict(名前=name,拒否=True,理由=str(error)))
        return
    raise AssertionError('破損を受理: '+name)


def native_fixture(value):
    """
    機能: 保存型差だけの人工envelopeを既存Go型値から構成する。
    引数: value(dict)は停止完全接続人工。
    返り値: dictは金融値を変更しない配送用fixture。実市場Nativeではない。
    """
    output = value['output']
    counts = Counter(row['key'] for row in output['short_assessments'])
    bindings = {key:dict(callbacks=counts[key],exit_requests=book['metrics'].get('short_exit_requests',0),
                         exit_fills=book['metrics'].get('short_exit_fills',0))
                for key,book in output['result']['books'].items()}
    return dict(books=output['result']['books'],contract='人工限月',gate_assessments=output['gate_assessments'],
                short_bindings=bindings,stream_passes=output['stream_passes'])


def run_fixture(value, records):
    """
    機能: 人工専用stream検査と市場用金融配送を分けて接続する。
    引数: value(dict)、records(list[dict])は停止完全人工。
    返り値: dictは新12・旧P0四の独立結果。人工の自然形成を主張しない。
    """
    audit = M.C.Audit()
    expected, counts = M.C.restore_inputs(value['header'],records,value['tape'],audit,'人工限月')
    frames = dict(M.current_frames(value['header'],iter(records),value['tape']))
    audit.equal(set(frames),set(expected),'停止復元APIと薄い射影のordinal集合')
    for ordinal, frame in frames.items():
        M.BASE.compare_tree(frame,expected[ordinal],audit,'停止復元APIと薄い射影/'+str(ordinal))
    return M.inspect_financial(value['tape'],native_fixture(value),value['baseline100_p0_api']['books'],
        iter(frames.items()),counts,value['stream_sha256'],value['header_canonical_sha256'])


def main():
    """
    機能: 旧24人工の再接続と必要metadata/金融破損だけを確認する。
    引数: なし。市場/Raw/Nativeの実入力は開かない。
    返り値: None。小さい人工確認JSONを新規保存する。
    """
    root = ROOT/'work/短秒複合退出の再生'
    stop_path = root/'停止.json'
    M.need(M.digest(stop_path)==M.RUNTIME_SHA,'停止runtime差')
    stop = M.load(stop_path)
    owned = {name.replace('\\','/'):sha for name,sha in stop['全所有SHA256'].items()}
    before, details, denied = {}, [], []
    fixtures = []
    for side in (1,-1):
        path = root/'人工/完全接続'/('方向'+str(side)+'.json')
        stream_path = path.with_suffix('.records.jsonl.gz')
        for p in (path,stream_path):
            sha = owned[str(p.relative_to(root)).replace('\\','/')]
            M.need(M.digest(p)==sha,'停止人工差')
            before[str(p)] = sha
        value = M.load(path)
        records = list(M.R.read_records(stream_path))
        fixtures.append((value,records))
        details.append(run_fixture(value,records))
    original, records = fixtures[0]
    bad = copy.deepcopy(original)
    book = bad['output']['result']['books']['S5Q_E3S_B5Q_P0_C0_D1']
    order = next(row for row in book['orders'] if row.get('short_exit_point'))
    order['quantity'] += 1
    reject('S要求量破損',lambda:run_fixture(bad,records),denied)
    bad2 = copy.deepcopy(original)
    book = bad2['output']['result']['books']['S5Q_E3S_B5Q_P0_C0_D1']
    order = next(row for row in book['orders'] if row.get('short_exit_point'))
    order['short_exit_point']['assessment']['decision']['allowed'] = False
    reject('S純採否破損',lambda:run_fixture(bad2,records),denied)
    bad3 = copy.deepcopy(original)
    bad3['baseline100_p0_api']['books'][M.P0_KEYS[0]]['totals']['gross_yen'] += 1
    reject('旧100P0保存額破損',lambda:run_fixture(bad3,records),denied)
    catalog = {('人工集合'+str(i)): 'a'*64 for i in range(52)}
    catalog.update({key:'b'*64 for key in M.FIRST_IDS})
    # 集合は実日付を選別しないmetadata器具。許可54の本番由来を代用しない。
    M.need(len(catalog)==54 and len(M.selected_ids('first2',catalog))==2 and len(M.selected_ids('full54',catalog))==54,'完全2→54人工')
    reject('未許可stage',lambda:M.selected_ids('newday',catalog),denied)
    reject('55場混入',lambda:M.selected_ids('full54',dict(catalog,extra='c'*64)),denied)
    allowed_path = ROOT/'work/101連続入力の試作_版3/許可54.json'
    allowed = M.load(allowed_path)
    producer = M.load(allowed_path.with_name('停止.json'))
    producer_allowed_sha = producer['所有コードSHA256'][str(allowed_path.relative_to(ROOT)).replace('\\','/')]
    M.need(M.digest(allowed_path)==producer_allowed_sha,'producer許可54metadata出典')
    before[str(allowed_path)] = producer_allowed_sha
    actual_catalog = {row['session']:row['native_sha256'] for row in allowed['entries']}
    M.validate_allowed(allowed,actual_catalog)
    M.need(len(M.selected_ids('first2',actual_catalog))==2
           and len(M.selected_ids('full54',actual_catalog))==54,'正確producer型の共通stage接続')
    for name, change in (
        ('producer NativeSHA欠落',lambda x:x['entries'][0].pop('native_sha256')),
        ('producer 偽NativeSHA',lambda x:x['entries'][0].update(native_sha256='f'*64)),
        ('producer 同場重複',lambda x:x['entries'].__setitem__(1,copy.deepcopy(x['entries'][0]))),
        ('producer 別固定100',lambda x:x.update(proof100_sha256='f'*64)),
        ('producer 旧Reader型へfallback禁止',lambda x:x['entries'][0].update(sha256=x['entries'][0].pop('native_sha256'))),
        ('producer 54欠落',lambda x:x['entries'].pop()),
        ('producer bool版',lambda x:x.update(version=True))):
        changed = copy.deepcopy(allowed)
        change(changed)
        reject(name,lambda v=changed:M.validate_allowed(v,actual_catalog),denied)
    condition = {'コードSHA256':{'人工code':'c'*64},'Go依存SHA256':{'人工dep':'d'*64}}
    completion = {'scope':M.SCOPE,'成功':True,'試行':101,'stage':'first2','条件SHA256':'a'*64,'全12Key':list(M.KEYS),
        '結果':[dict(session=sid,path=sid+'.json.gz',sha256='b'*64,p0_books=4,books=12) for sid in M.FIRST_IDS],
        'コードSHA256':condition['コードSHA256'],'Go依存SHA256':condition['Go依存SHA256'],
        '入力前SHA256':{'人工入力':'e'*64},'入力後SHA256':{'人工入力':'e'*64},'前後不変':True,
        'source_reexecuted':False,'features_recomputed':False,'charts_recomputed':False,'Raw読取':0}
    M.validate_completion(completion,'a'*64,condition,M.FIRST_IDS)
    for name, change in (
        ('未完',lambda x:x.update(成功=False)),
        ('別条件',lambda x:x.update(条件SHA256='f'*64)),
        ('旧P0四不足',lambda x:x['結果'][0].update(p0_books=3)),
        ('11会計',lambda x:x['結果'][0].update(books=11)),
        ('場欠落',lambda x:x['結果'].pop()),
        ('入力変更',lambda x:x['入力後SHA256'].update(人工入力='f'*64)),
        ('Source再実行',lambda x:x.update(source_reexecuted=True)),
        ('Raw欠落',lambda x:x.pop('Raw読取'))):
        changed = copy.deepcopy(completion)
        change(changed)
        reject(name,lambda v=changed:M.validate_completion(v,'a'*64,condition,M.FIRST_IDS),denied)
    before[str(M.COUPLED_PATH)] = M.COUPLED_SHA
    before[str(stop_path)] = M.RUNTIME_SHA
    M.need(all(M.digest(Path(path))==sha for path,sha in before.items()),'人工入力/固定部品前後不変')
    result = dict(成功=True,scope='停止完全Input人工24の薄い市場配送接続とmetadata器具。市場実行ではない。',
                  新会計数=sum(r['新会計数'] for r in details),新P0独立全文会計=sum(r['新P0独立全文会計'] for r in details),
                  旧100P0独立全文会計=sum(r['旧100P0独立全文会計'] for r in details),
                  照合項目数=sum(r['照合項目数'] for r in details),不一致数=0,details=details,
                  拒否=denied,入力SHA256=before,前後不変=True,市場新P0独立全文=False,Raw読取=0,Go追加実行=0,
                  市場全record読戻しは未実行=True,金融式純式parser複写=0)
    (HERE/'人工確認.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({key:result[key] for key in ('成功','新会計数','新P0独立全文会計','照合項目数')},ensure_ascii=False))


if __name__ == '__main__':
    main()
