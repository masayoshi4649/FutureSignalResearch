"""市場本文を開かず、人工とコードの最終指紋だけを停止する。"""

import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def digest(path):
    """
    機能: 明示したコード/証拠だけをhashする。
    引数: path(Path)は入力。
    返り値: strはSHA256。市場ファイルは探索しない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    """
    機能: 人工確認と構文/CLI・固定由来を結び停止JSONを新規保存する。
    引数: なし。実市場CLIは起動しない。
    返り値: None。停止は人工接続だけの成功を表す。
    """
    names = ['市場と短秒を照合する.py','人工を確認する.py','停止をまとめる.py','README.md','計画.md','市場wrapperの読取レビュー.md']
    owned = {str((HERE/name).relative_to(ROOT)).replace('\\','/'):digest(HERE/name) for name in names}
    for name in names:
        if name.endswith('.py'):
            ast.parse((HERE/name).read_text(encoding='utf-8'))
    proof = json.loads((HERE/'人工確認.json').read_text(encoding='utf-8'))
    assert proof['成功'] is True and proof['新会計数']==24 and proof['新P0独立全文会計']==8
    assert proof['旧100P0独立全文会計']==8 and proof['不一致数']==0 and proof['前後不変'] is True
    assert len(proof['拒否'])==20
    deps = {
      'work/短秒複合退出の市場の独立確認/停止.json':'213de78f3ab44e0d4ec7575b7bea64fae994c82bc32f66d7d771eb9b95bd673c',
      'work/短秒複合退出の市場接続/停止.json':'2657346bc6a2bf0f759c5275de15ef52db49da752979fd3ccac0890b90e96767',
      'work/短秒複合退出の再生の独立確認/再生と短秒を照合する.py':'668a164c2558fc6c13cc3c304f9bf99d4ee93de32b0e04a29c67d135e59c0815',
      'work/短秒複合退出の再生の独立確認/停止.json':'0154400320bf7d0731ad3821b7dc3f359379cc5738e16a6caaa44c7ff3dd49b3',
      'work/短秒複合退出の金融の独立確認/短秒と金融の照合.py':'931cb8a0c425c91fc57cc2af20ca96ba19c6c6693827f2351f681fce3623a5c4',
      'work/短秒複合退出の独立純式/短秒の純判定.py':'d50202814e046a7a7f69579882544102e5180e09cf9e88ce46168a542bc9126b',
      'work/101連続入力の読取照合/読み戻しを照合する.py':'00d8c55f12a43e31be3857feadae9373ac53901efcbbeff394fb0eef27543345',
      'work/101保有技法の抽出実行案/保有枠の抽出.py':'799e407575b76951fe2879ece3a900b823916684c65dbbd941082cb8e7759950',
      'scripts/FAR利益化前後の保護の監査/費用前ガードと金融の照合.py':'d6b2eb4dc18c082f3acf39dbc2f74553b127e0e1491bd601671c7e50c17aa6e7',
      'scripts/FAR初回利益確定の監査/Tapeと金融の照合.py':'31fdf1d566f3c117b2cb6c5ec64e3211e7c8ae33a9cab75d84c1e38af1f4dff7',
      'study/00100_費用後利益化の前後で保護を分ける/完了記録.json':'4a8bc486e329f65f17e2395f781b2efd7cf76c5630d91924b611e90254725af3'}
    before = {str((ROOT/name).resolve()):digest(ROOT/name) for name in deps}
    assert all(before[str((ROOT/name).resolve())]==sha for name,sha in deps.items())
    cli = subprocess.run([sys.executable,'-B','-X','utf8',str(HERE/'市場と短秒を照合する.py'),'--help'],
                         capture_output=True,text=True,encoding='utf-8')
    assert cli.returncode==0
    rejected = subprocess.run([sys.executable,'-B','-X','utf8',str(HERE/'市場と短秒を照合する.py')],
                              capture_output=True,text=True,encoding='utf-8')
    assert rejected.returncode==2
    after = {name:digest(Path(name)) for name in before}
    assert after==before
    assert owned=={str((HERE/name).relative_to(ROOT)).replace('\\','/'):digest(HERE/name) for name in names}
    source = ROOT/'work/短秒複合退出の市場の独立確認/市場と短秒を照合する.py'
    old_tree = ast.parse(source.read_text(encoding='utf-8'))
    new_tree = ast.parse((HERE/'市場と短秒を照合する.py').read_text(encoding='utf-8'))
    old_functions = {n.name:ast.dump(n,include_attributes=False) for n in old_tree.body if isinstance(n,ast.FunctionDef)}
    new_functions = {n.name:ast.dump(n,include_attributes=False) for n in new_tree.body if isinstance(n,ast.FunctionDef)}
    assert set(new_functions)-set(old_functions)=={'validate_allowed'}
    assert [name for name in old_functions if old_functions[name]!=new_functions[name]]==['prepare']
    value = {'成功':True,'版':2,'状態':'producer許可54型のmetadata訂正と停止完全Input人工24だけ。市場実行はRootまで未了。',
      '市場wrapper停止SHA256':deps['work/短秒複合退出の市場接続/停止.json'],
      '結合独立SHA256':deps['work/短秒複合退出の再生の独立確認/再生と短秒を照合する.py'],
      '所有コードSHA256':owned,'由来SHA256':deps,'人工確認SHA256':digest(HERE/'人工確認.json'),
      '人工新会計':24,'人工新P0全文':8,'人工旧100P0全文':8,'人工照合項目数':proof['照合項目数'],'人工不一致':0,
      '狭い拒否':len(proof['拒否']),'構文':True,'CLIヘルプ終了':0,'CLI必須引数拒否終了':2,
      'API':['prepare(args)','inspect_scene(scene)','inspect_financial(tape,native,baseline,frames,counts,stream_sha,header_sha)'],
      '未固定SHAの供給':'条件/金融完了/独立停止/first2独立証拠をRootがCLIのpath+shaで固定。条件最終SHAのソース埋込なし。',
      '前SHA256':before,'後SHA256':after,'前後不変':True,'旧エンジン/純式/parser複写':0,
      '版1停止SHA256':deps['work/短秒複合退出の市場の独立確認/停止.json'],
      '由来差':'版1の別字句Reader許可54型をproducer許可54のnative_sha256正確型へ訂正。fallback/保存値変換なし。',
      '既存関数AST差':['prepare'],'新関数':['validate_allowed'],'全金融配送/式/採否/Source/純式/辞書復元AST同体':True,
      '市場実行':0,'市場新P0独立全文':'未了','Raw/実Native/市場Tape/実stream意味展開':0,
      '新Go実行':0,'正式編集':0,'Source形成':0,'機会損失算出':False,
      '限界':'人工24の型接続だけ。自然形成/真受信時計/実mini流動性/未使用期間の安定利益は証明しない。'}
    with (HERE/'停止.json').open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2)
        stream.write('\n')
    print(digest(HERE/'停止.json'))


if __name__=='__main__':
    main()
