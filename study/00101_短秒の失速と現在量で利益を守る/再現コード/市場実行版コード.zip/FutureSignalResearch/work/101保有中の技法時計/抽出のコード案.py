"""保有技法時計の最小射影とcutoffの人工型案。市場Native読取口は常時拒否する。"""

import argparse
import copy
import hashlib
import json
import math
from pathlib import Path


ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
KEYS=tuple(f"E3S_B5Q_P0_C{c}_D{d}" for c in (0,5) for d in (0,1))
SOURCE_FIELDS={"method","signal_id","kind","parent","source_id","quantity_micro","birth_quantity","birth_time","birth_quote"}
POSITION_FIELDS=("id","entry_order_id","source","source_hold_id","side","initial_quantity","entry_quote","closed_quote","protection_active","activation")
ORDER_FIELDS=("id","kind","quantity","position_id","request_time","request_quote","status","fill_id","cancel_time","reason")
FILL_FIELDS=("id","order_id","position_id","action","quantity","quote","reason","source")


def need(ok: bool,text: str) -> None:
    """
    機能: 人工型と因果cutoffの条件を検査する。
    引数: ok(bool)、text(str)は条件と識別。
    返り値: None。不成立ならValueError。
    """
    if not ok:raise ValueError(text)


def finite(value,where: str) -> float:
    """
    機能: 観測時刻又は指標の有限数値だけを受ける。
    引数: value(int|float)、where(str)は値と識別。
    返り値: floatは有限値。bool/NaN/Infを拒否する。
    """
    need(type(value) in (int,float) and math.isfinite(value),where+"は有限数値")
    return float(value)


def source_key(session: str,source: dict) -> tuple:
    """
    機能: 実Sourceの正規識別をserialから補完せず取得する。
    引数: session(str)、source(dict)は場とNative実Source。
    返り値: tuple[str,str,str]は場/手法/SignalID。
    """
    need(type(source) is dict and set(source)==SOURCE_FIELDS,"実Source全tag")
    need(type(session) is str and session and type(source["method"]) is str and source["method"] and type(source["signal_id"]) is str and source["signal_id"],"実Source識別必須")
    return session,source["method"],source["signal_id"]


def project_artificial(value: dict) -> dict:
    """
    機能: P0の最小履歴と共有技法を元型の値コピーだけで射影する。
    引数: value(dict)は人工包絡。API呼出し側が人工scopeを明示する。
    返り値: dictは型案。価格/損益/ピーク/全marksを複製せず新注文も作らない。
    """
    need(value.get("scope")=="101型検査専用・既存100Go人工の値コピー","人工型専用scope")
    out={"schema":"101保有技法時計の型案1","scope":value["scope"],"session":value["session"],"books":{},"chart_grids":copy.deepcopy(value["chart_grids"]),"gate_context_refs":[]}
    for key in KEYS:
        book=value["books"][key];need(book["key"]==key and book["config"].get("harvest_policy","")=="","P0四つだけ")
        row={"key":key,"session":copy.deepcopy(book["session"]),"config":copy.deepcopy(book["config"]),"positions":[],"orders":[],"fills":[],"source_request_stamps":[],"grid_quotes":[]}
        position_ids=set()
        for p in book["positions"]:
            identity=source_key(value["session"],p["source"]);need(p["id"] not in position_ids,"実玉ID重複なし");position_ids.add(p["id"])
            minimal={name:copy.deepcopy(p[name]) for name in POSITION_FIELDS};minimal["source_key"]=identity;row["positions"].append(minimal)
        for order in book["orders"]:
            if order["position_id"] not in position_ids:continue
            minimal={name:copy.deepcopy(order[name]) for name in ORDER_FIELDS};minimal["protection_request"]=order["protection_point"] is not None
            row["orders"].append(minimal)
        for fill in book["fills"]:
            if fill["position_id"] in position_ids:row["fills"].append({name:copy.deepcopy(fill[name]) for name in FILL_FIELDS})
        exit_ids={o["id"] for o in row["orders"] if o["kind"]=="exit"}
        for event in book["source_events"]:
            if event["order_id"] in exit_ids:row["source_request_stamps"].append({name:copy.deepcopy(event[name]) for name in ("at","phase","order_id","quote")})
        row["grid_quotes"]=[{name:copy.deepcopy(g[name]) for name in ("at","quote","quote_known")} for g in book["grid_traces"]]
        out["books"][key]=row
    snapshots={g["at"]:g["snapshot_id"] for g in value["chart_grids"]};need(len(snapshots)==len(value["chart_grids"]),"共有枠一意")
    for record in value["gate_assessments"]:
        if record["key"] not in KEYS:continue
        at=record["candidate"]["at"];sid=record["assessment"]["decision"]["snapshot_id"]
        need(snapshots.get(at)==sid,"元新規文脈と共有枠ID")
        out["gate_context_refs"].append({"key":record["key"],"ordinal":record["ordinal"],"at":at,"snapshot_id":sid})
    return out


def activation_before_grid(point: dict|None,at: float) -> bool:
    """
    機能: 原行Activationをgrid以前へ前倒ししない。
    引数: point(dict|None)、at(float)は初回正益点と枠。
    返り値: boolは既起動。現在u正益や未予約を意味しない。
    """
    finite(at,"grid")
    if point is None:return False
    need(point["phase"] in ("pre_fill","after_source") and finite(point["unit_net"],"起動u")>0,"正常strictu起動点")
    return finite(point["quote"]["time"],"起動時計")<at


def quantity_at_grid(position: dict,fills: list,at: float) -> int:
    """
    機能: 同時刻raw fillを除き、実取得と途中返済から枠残量を得る。
    引数: position(dict)、fills(list[dict])、at(float)は最小実玉/実約定/枠。
    返り値: intは実残量。最終positions.quantityは使わない。
    """
    if position["entry_quote"]["time"]>=at:return 0
    quantity=position["initial_quantity"];need(type(quantity) is int and 0<quantity<=10,"実初期量")
    for fill in fills:
        if fill["position_id"]==position["id"] and fill["action"]=="close" and fill["quote"]["time"]<at:quantity-=fill["quantity"]
    need(0<=quantity<=position["initial_quantity"],"実返済残量")
    return quantity


def request_before_grid(order: dict,at: float,timer_before_proven: bool) -> bool|None:
    """
    機能: 返済受理の同時計をtimerとrawへ区別する。
    引数: order(dict)、at(float)、timer_before_proven(bool)は注文/枠/別出典による証明。
    返り値: bool|Noneは受理済み/後/起源不明。stale quoteだけでtimerを創作しない。
    """
    t=finite(order["request_time"],"要求時計");q=finite(order["request_quote"]["time"],"要求quote時計")
    need(q<=t,"要求quote未来なし")
    if t<at:return True
    if t>at:return False
    if q==at:
        need(not timer_before_proven,"grid前timerに同clockrawを混入しない")
        return False
    return True if timer_before_proven else None


def free_at_grid(position: dict,orders: list,fills: list,at: float,timer_proofs: set) -> dict:
    """
    機能: 部分残と受理済み返済の未約定予約を分ける。
    引数: position(dict)、orders/fills(list)、at(float)、timer_proofs(set[str])は最小履歴/枠/厳密証明済み注文ID。
    返り値: dictはquantity/reserved/free又は予約未知。新注文は一切作らない。
    """
    quantity=quantity_at_grid(position,fills,at)
    if quantity==0:return {"quantity":0,"reserved":0,"free":0,"known":True}
    by_id={f["id"]:f for f in fills};reserved=0
    for order in orders:
        if order["kind"]!="exit" or order["position_id"]!=position["id"]:continue
        before=request_before_grid(order,at,order["id"] in timer_proofs)
        if before is None:return {"quantity":quantity,"reserved":None,"free":None,"known":False,"reason":"同clock要求のtimer/raw起源未確定"}
        if not before:continue
        if order["fill_id"]:
            need(order["fill_id"] in by_id,"実約定IDの欠落なし")
            if by_id[order["fill_id"]]["quote"]["time"]<at:continue
        cancelled=order["cancel_time"]
        if cancelled is not None:
            if cancelled<at:continue
            if cancelled==at:return {"quantity":quantity,"reserved":None,"free":None,"known":False,"reason":"同clock取消の位相未確定"}
        reserved+=order["quantity"]
    need(0<=reserved<=quantity,"過剰予約なし")
    return {"quantity":quantity,"reserved":reserved,"free":quantity-reserved,"known":True}


def availability(context: dict,grid_quote: dict,at: float,side: int) -> dict:
    """
    機能: 新しい退出信号を作らず、公表/時計/Knownの利用可能性だけを分ける。
    引数: context/grid_quote(dict)、at(float)、side(int,±1)は共有確定文脈と実保有側。
    返り値: dictは基本/RSI/Recent3の可用性。入口採否や値の符号を転記しない。
    """
    need(side in (-1,1) and context["at"]==at,"実側/当枠文脈");finite(at,"枠時計")
    q=grid_quote["quote"];chart=context["chart"];t=chart["chart"]["Technical"];c=context["current"]
    if t["trend_known"]:
        for name in ("ema8_3","ema21_3","ema8_15","ema21_15"):finite(t[name],"既知EMA:"+name)
    if t["exit_known"]:
        for name in ("close3","ema8_3","histogram3","previous_histogram3"):finite(t[name],"既知価格/勢い:"+name)
    if t["spike_known"]:
        for name in ("rsi3","previous_rsi3","tr3","previous_atr3"):finite(t[name],"既知RSI/TR:"+name)
    price=bool(grid_quote["quote_known"] and q is not None and q["quote_ok"] and 0<q["bid"]<q["ask"] and 0<=at-finite(q["time"],"Quote時計")<=15)
    three=bool(chart["three"]["data_known"] and chart["three"]["available_at"]<=at and 0<=at-t["bar3_end"]<180)
    fifteen=bool(chart["fifteen"]["data_known"] and chart["fifteen"]["available_at"]<=at and 0<=at-t["bar15_end"]<900)
    current_bound=bool(q is not None and c["time"]==q["time"] and c["source_line"]==q["source_line"] and c["source_index"]==q["index"])
    if context["kind"]=="Day":
        v=c["buy"] if side==1 else c["sell"];quantity=bool(v["ofi_known"] and v["own_at"]==c["time"])
        if quantity:finite(v["ofi30"],"既知OFI30")
    else:
        n=c["night"];band=n["band"];quantity=bool(n["available"] and n["window"]=="E08" and band["quantity_known"] and band["time"]==c["time"] and band["index"]==c["source_index"])
        if quantity:
            for name in ("bid_refill","ask_deplete","ask_refill","bid_deplete"):finite(band[name],"既知E08量:"+name)
    basic=bool(price and three and fifteen and t["trend_known"] and t["exit_known"] and current_bound and quantity)
    recent=context["recent3"];sequence=len(recent)==3
    if sequence:
        sequence=all(x["scene"]==chart["scene"] and x["three"]["data_known"] and x["at"]==x["three"]["bar_end"] and x["three"]["available_at"]<=at for x in recent)
        sequence=sequence and all(recent[i]["at"]-recent[i-1]["at"]==180 for i in (1,2))
    return {"price_fresh":price,"three_published_fresh":three,"fifteen_published_fresh":fifteen,"current_quote_bound":current_bound,"quantity_known":quantity,
            "basic_input_available":basic,"rsi_input_available":bool(basic and t["spike_known"]),"recent3_sequence_available":bool(basic and sequence),"exit_signal_evaluated":False,"current_u_at_grid":None}


def main() -> int:
    """
    機能: 人工型以外のNative読取を最初に拒否する。
    引数: --native(Path)は未許可市場口。--selftestは別人工helperの案内。
    返り値: intは0又は例外。現在市場ファイルを開くコードは存在しない。
    """
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument("--native",type=Path);args=parser.parse_args()
    if args.native is not None:raise ValueError("計画/人工型案で停止中。Rootの別実行指示と固定入力契約前はNative本文読取を禁止")
    print("人工型検査は 人工型を確認する.py を使う。市場抽出は未実装・未実行。")
    return 0


if __name__=="__main__":raise SystemExit(main())
