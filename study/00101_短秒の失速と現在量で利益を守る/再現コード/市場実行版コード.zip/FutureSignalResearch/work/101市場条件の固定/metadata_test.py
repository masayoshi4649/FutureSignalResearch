"""opaque bytesとmetadataだけの人工。実Native/Tape/streamを解凍・査定しない。"""
import argparse
import hashlib
import importlib.util
import json
import tempfile
import unittest
from unittest import mock
from datetime import date, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("assemble101", HERE / "条件を組み立てる.py")
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)


def save(path: Path, value) -> str:
    """機能: 人工JSONだけを保存する。引数: path(Path),value(object)。返り値: str(SHA)。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return hashlib.sha256(path.read_bytes()).hexdigest()


def opaque(path: Path, label: str) -> str:
    """機能: 解釈不能bytesを人工参照にする。引数: path(Path),label(str)。返り値: str(SHA)。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(("不透明・解凍禁止:" + label).encode("utf-8"))
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fixture(root: Path):
    """機能: 2/54metadataとopaque参照を作る。引数: root(Path)。返り値: tuple(args,proofSHA)。"""
    start, end = date(2026, 9, 21), date(2026, 10, 27)
    ids = []
    while start <= end:
        if start.weekday() < 5:
            ids.extend([start.isoformat() + "_Day", start.isoformat() + "_Night"])
        start += timedelta(days=1)
    assert len(ids) == 54
    base = root / M.STUDY100
    files, details, entries = {}, {}, []
    for sid in ids:
        native_sha = opaque(base / "成果物" / (sid + ".json.gz"), sid + "native")
        tape_path = root / "opaque" / (sid + ".tape.gz")
        tape_sha = opaque(tape_path, sid + "tape")
        header_path = root / "opaque" / (sid + ".header.json")
        records_path = root / "opaque" / (sid + ".records.gz")
        hsha, rsha = opaque(header_path, sid + "header"), opaque(records_path, sid + "records")
        files["成果物/" + sid + ".json.gz"] = native_sha
        entries.append({"session": sid, "path": "../../opaque/" + tape_path.name, "sha256": tape_sha})
        details[sid] = {"session": sid, "path": str(records_path.relative_to(root)), "SHA256": rsha, "header": str(header_path.relative_to(root)), "header_SHA256": hsha}
    for stage, name, es in [("first2", "接続2場Tape台帳.json", entries[:2]), ("full54", "正式54Tape台帳.json", entries)]:
        # 台帳dirはroot/study/00100なのでopaqueへは2段戻る。
        files[name] = save(base / name, {"version": 1, "stage": stage, "entries": es})
    proof_sha = save(base / "完了記録.json", {"試行": 100, "比較保存完了": True, "場数": 54, "自己を除く正式指紋": files})
    allowed_path = root / "許可54.json"
    allowed_sha = save(allowed_path, {"version": 1, "proof100_sha256": proof_sha, "entries": [{"session": sid, "native_sha256": files["成果物/" + sid + ".json.gz"]} for sid in ids]})
    pcode = {str(allowed_path): allowed_sha}
    producer_path = root / "producer.stop.json"
    producer_sha = save(producer_path, {"成功": True, "所有コードSHA256": pcode})
    code_path, dep_path, exe_path = root / "code.txt", root / "dep.mod", root / "never_run.exe"
    code_sha, dep_sha, exe_sha = opaque(code_path, "code"), opaque(dep_path, "dep"), opaque(exe_path, "exe")
    comp_sha = {}
    for label, (name, field, code_field) in M.COMPONENTS.items():
        comp_sha[field] = save(root / name, {"成功": True, code_field: {str(code_path): code_sha}})
    wrapper_path = root / "wrapper.stop.json"
    wrapper_sha = save(wrapper_path, {"成功": True, "module": "github.com/masayoshi4649/SessionTradeExecuter/shortmarket101", "必須コードSHA256": {str(code_path): code_sha}, "Go依存SHA256": {str(dep_path): dep_sha}, "exe": {"path": str(exe_path), "sha256": exe_sha}, **comp_sha})
    caches, evidence = {}, {}
    for stage, stage_ids in [("first2", ids[:2]), ("full54", ids)]:
        cache_path = root / (stage + ".cache.json")
        csha = save(cache_path, {"成功": True, "前後不変": True, "scope": "固定100と旧Tapeの連続技法sidecar構築", "stage": stage, "固定100完了SHA256": proof_sha, "source_reexecuted": False, "financial_executed": False, "features_recomputed": True, "charts_recomputed": True, "所有コードSHA256": pcode, "sessions": stage_ids, "details": [details[sid] for sid in stage_ids]})
        caches[stage] = (cache_path, csha)
        readback_path = root / (stage + ".readback.json")
        scope = "人工readbackのmetadata型"
        rsha = save(readback_path, {"成功": True, "前後不変": True, "scope": scope, "stage": stage, "sessions": stage_ids, "入力構築receiptSHA256": csha, "builder停止SHA256": producer_sha,
                                    "details": [{"session": sid, "成功": True, "処理完了": True, "前後不変": True, "不一致": 0, "入力SHA256": {str(root / details[sid]["header"]): details[sid]["header_SHA256"], str(root / details[sid]["path"]): details[sid]["SHA256"]}} for sid in stage_ids]})
        evidence[stage + "_readback"] = {"path": readback_path.name, "sha256": rsha, "scope": scope}
        ending_path = root / (stage + ".ending.json")
        scope = "人工Endingのmetadata型"
        esha = save(ending_path, {"成功": True, "前後不変": True, "scope": scope, "場末": [{"session": sid, "一致": True, "field除外": [], "header_SHA256": details[sid]["header_SHA256"], "元NativeSHA256": files["成果物/" + sid + ".json.gz"]} for sid in stage_ids]})
        evidence[stage + "_ending"] = {"path": ending_path.name, "sha256": esha, "scope": scope}
    evidence_path = root / "side.json"
    evidence_sha = save(evidence_path, {"version": 1, "evidence": evidence})
    a = argparse.Namespace(root=str(root), out=str(root / "new" / "条件.json"), wrapper_stop=str(wrapper_path), wrapper_stop_sha=wrapper_sha, producer_stop=str(producer_path), producer_stop_sha=producer_sha, first2_receipt=str(caches["first2"][0]), first2_sha=caches["first2"][1], full54_receipt=str(caches["full54"][0]), full54_sha=caches["full54"][1], side_evidence=str(evidence_path), side_evidence_sha=evidence_sha)
    return a, proof_sha


class MetadataTest(unittest.TestCase):
    """署名/件数だけをprivate置換したmetadataテスト。CLIからは指定しない。"""

    def test_complete_and_relative(self):
        """機能: 完成2/54・相対path・全hash・schema非追加を確認する。引数: self。返り値: None。"""
        with tempfile.TemporaryDirectory() as tmp:
            a, proof = fixture(Path(tmp))
            c, r = M.assemble(a, _proof_sha=proof, _counts=(1, 1, 1))
            self.assertEqual(len(c["stages"]["first2"]["scenes"]), 2)
            self.assertEqual(len(c["stages"]["full54"]["scenes"]), 54)
            self.assertEqual(len(c["全12Key"]), 12)
            self.assertNotIn("side_evidence", c)
            for label in ["固定100完了", "許可54", "市場wrapper停止", "runtime停止", "金融停止", "純式停止", "sidecar版2停止", "実行物"]:
                self.assertFalse(Path(c[label]["path"]).is_absolute())
            M.publish(a, c, r)
            self.assertEqual(hashlib.sha256(Path(a.out).read_bytes()).hexdigest(), r["condition"]["sha256"])
            with self.assertRaises(ValueError):
                M.assemble(a, _proof_sha=proof, _counts=(1, 1, 1))

    def test_incomplete_and_corruptions(self):
        """機能: 未完/根拠欠落/指紋/集合を条件作成前に拒否する。引数: self。返り値: None。"""
        for name in ["full未完", "full欠落", "RootSHA未固定", "record改変", "Ending除外", "readback取違", "code改変"]:
            with self.subTest(name=name), tempfile.TemporaryDirectory() as tmp:
                a, proof = fixture(Path(tmp))
                if name == "full欠落":
                    Path(a.full54_receipt).unlink()
                elif name == "RootSHA未固定":
                    a.full54_sha = ""
                elif name == "full未完":
                    p = Path(a.full54_receipt)
                    v = json.loads(p.read_text(encoding="utf-8")); v["成功"] = False
                    a.full54_sha = save(p, v)
                elif name in ("Ending除外", "readback取違"):
                    mp = Path(a.side_evidence); m = json.loads(mp.read_text(encoding="utf-8"))
                    role = "full54_ending" if name == "Ending除外" else "first2_readback"
                    p = mp.parent / m["evidence"][role]["path"]
                    v = json.loads(p.read_text(encoding="utf-8"))
                    if name == "Ending除外": v["場末"][0]["field除外"] = ["破損を除外"]
                    else: v["入力構築receiptSHA256"] = "a" * 64
                    m["evidence"][role]["sha256"] = save(p, v)
                    a.side_evidence_sha = save(mp, m)
                elif name == "record改変":
                    p = Path(tmp) / "opaque/2026-09-21_Day.records.gz"; p.write_bytes(b"corrupt")
                else:
                    (Path(tmp) / "code.txt").write_bytes(b"corrupt")
                with self.assertRaises(ValueError):
                    M.assemble(a, _proof_sha=proof, _counts=(1, 1, 1))
                self.assertFalse(Path(a.out).exists())
                self.assertFalse(Path(a.out).with_name("条件_確認.json").exists())

    def test_production_pins_reject_fixture(self):
        """機能: private人工を本番関数の既定値で拒否する。引数: self。返り値: None。"""
        with tempfile.TemporaryDirectory() as tmp:
            a, _ = fixture(Path(tmp))
            with self.assertRaises(ValueError):
                M.assemble(a)

    def test_publish_failure_keeps_condition_absent(self):
        """機能: 排他publish失敗時に成功確認を残さない。引数: self。返り値: None。"""
        with tempfile.TemporaryDirectory() as tmp:
            a, proof = fixture(Path(tmp))
            c, r = M.assemble(a, _proof_sha=proof, _counts=(1, 1, 1))
            original = M.os.link
            def fail_condition(source, target):
                """機能: 条件publishだけを失敗させる。引数: source/target(Path)。返り値: None。"""
                if Path(target) == Path(a.out):
                    raise OSError("人工publish失敗")
                return original(source, target)
            with mock.patch.object(M.os, "link", side_effect=fail_condition):
                with self.assertRaises(OSError):
                    M.publish(a, c, r)
            self.assertFalse(Path(a.out).exists())
            self.assertFalse(Path(a.out).with_name("条件_確認.json").exists())
            self.assertEqual(list(Path(a.out).parent.iterdir()), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
