# 101市場条件のRoot前固定helper

`条件を組み立てる.py` は停止[市場wrapper](../短秒複合退出の市場接続/停止.json) 2657346b…のGo条件schemaを変更せず組み立てる。wrapper/producer停止・完成cache・固定100閉鎖・許可54・2/54 Tape台帳の**metadata**だけをJSON読取する。Header/Records/Tape/旧100 Nativeは解凍・JSON化せずbytesのSHAだけを検査する。金融・Source・Features・Bank・退出採否・損益・機会損失を実行しない。

現在の既定参照はwrapper2657、producer版3 cf49、first2 cache e1a。full54 cacheはRootが完成後にpathと完全SHAを必ず指定する。未完・欠落・成功false・場集合差なら、条件も確認receiptも作らない。今回の準備では実cacheを対象にhelperを実行していない。

## 前提と検査

- 停止の必須code299＋producer所有13を厳密unionし、Go依存250/exeを含む現物指紋を全件検査する。同path異指紋を拒否する。元code keyのrepo基準/明示絶対pathを維持する。
- 固定100閉鎖4a8b…からNative54の許可集合と両Tape台帳SHAを取り、producerの許可54と一致させる。Tape entryの相対pathは台帳dir基準。旧producer receiptのpath/headerはその明示契約どおりrepo root基準。
- 両cache receiptの成功/前後不変・Source/金融再実行なし・producer code全集合・2/54場順/全集合を確認する。各sceneのHeader/Records指紋を条件へ入れ、同じNative/Tape/Header/Recordsの現物SHAを確認する。未測定を0/falseにしない。
- readback/Endingの4役割をRootが別manifestで前固定する。readbackはcache receiptSHA/producerSHA/各場の完了・差0/入力Header/RecordsSHAへ、Endingは各場の除外0・HeaderSHA・固定100 NativeSHAへ結ぶ。これらは条件本体へ欄を足さず、helperの小receiptだけへ保存する。
- 最終再hashと候補bytes確認をすべて済ませ、新規targetへのhardlinkで確認receipt→条件の順に排他的publishする。既存条件を上書きしない。条件が最後に公開され、検査失敗時は条件なしを維持する。

`FileRef`は出力条件JSONのdir基準へ相対化する。consumer Go依存e290と入力producer cf49は分け、どちらの停止も書き換えない。Rootが実行前に引数へ完全SHAを明示する。

## side evidence manifest

manifestのpathはそのmanifestのdir基準。各`scope`には指定した証拠JSONの実際のscopeを記す。説明用の省略値をそのまま実行に用いない。

```json
{
  "version": 1,
  "evidence": {
    "first2_readback": {"path":"…","sha256":"…","scope":"証拠の実scope"},
    "first2_ending": {"path":"…","sha256":"…","scope":"証拠の実scope"},
    "full54_readback": {"path":"…","sha256":"…","scope":"証拠の実scope"},
    "full54_ending": {"path":"…","sha256":"…","scope":"証拠の実scope"}
  }
}
```

既知の先頭2場はreadback `work/101producer指定の読取照合/版3実2場.json`（0d1c8a…）、Ending `work/101連続入力の実行/接続2場_版3/場末の独立照合.json`（11c073…）。全54の証拠は完成後にRootが指定する。未生成のSHAや成功を作らない。

## Root実行方法（今回未実行）

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101市場条件の固定/条件を組み立てる.py' `
  --root (Get-Location).Path `
  --wrapper-stop 'work/短秒複合退出の市場接続/停止.json' `
  --wrapper-stop-sha '2657346bc6a2bf0f759c5275de15ef52db49da752979fd3ccac0890b90e96767' `
  --producer-stop 'work/101連続入力の試作_版3/停止.json' `
  --producer-stop-sha 'cf49b2b643afcfda478a5d383c6d5e73bbbee3b477d2a0edc0e45b745ef4d16c' `
  --first2-receipt 'work/101連続入力の実行/接続2場_版3/完了.json' `
  --first2-sha 'e1a29ceef23ca53424ac8d45b9d2e78566d2e1c885a647ec846da6cb0e9c7c48' `
  --full54-receipt '完成した全54cache/完了.json' --full54-sha 'その完全SHA' `
  --side-evidence 'Rootの4前提manifest.json' --side-evidence-sha 'その完全SHA' `
  --out '新規の101条件.json'
```

出力は指定JSONと同dirの`<stem>_確認.json`。stdoutに条件bytesのSHAを返す。RootはこのSHAを市場wrapperの`--condition-sha`へ渡す。条件にhelper自身のcodeを混ぜると停止wrapperの厳密unionを壊すため、helper SHA/side evidence/全確認入力指紋は小receiptへだけ置く。

同じ条件でfirst2→full54へ進めるため、両cacheと4前提が完成してから組み立てる。後から条件を変えた場合は新しい条件でfirst2も確認する。

## 人工と限界

`metadata_test.py` は2/54のmetadataと解釈不能opaque bytesだけを作る。private関数引数で署名/件数を縮小し、CLI既定値ではこの人工を拒否する。実市場・指標形成・金融成功の証明ではない。全参照はSHAのみで扱うため、opaque Header/Native/RecordsにJSON parserやgzip decoderを当てないことも確認できる。

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101市場条件の固定/metadata_test.py'
```

本helperはRootのreadback/Ending成功証拠に依存し、それ自体の数値器を再検査しない。Rootの実条件固定・市場CLIは別段階。旧停止・正式code・試行条件は変更しない。
