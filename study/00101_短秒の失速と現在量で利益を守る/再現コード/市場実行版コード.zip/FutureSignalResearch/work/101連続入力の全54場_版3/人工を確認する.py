"""版3のSource固定値差だけをmetadata器具で確認する。実cacheは読まない。"""

import ast
import copy
import importlib.util
import json
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent


def main():
    """
    機能: Source差替え/旧関数保持/未固定拒否を人工だけで確認する。
    引数: なし。実行前条件雛形は値copyへ人工SHAを入れる。
    返り値: None。不一致は例外で停止する。
    """
    path = HERE / '版3の接続.py'
    spec = importlib.util.spec_from_file_location('版3接続_人工', path)
    link = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = link
    spec.loader.exec_module(link)
    for name in ('版3の接続.py', '生成と場末を照合する.py', '全54場を読み戻す.py'):
        ast.parse((HERE / name).read_text(encoding='utf-8'))
    old_globals = (link.GEN.BUILDER, link.GEN.FIRST_SHA, link.READ.BUILDER, link.READ.FIRST_SHA)
    generation = json.loads((HERE / '生成条件の雛形.json').read_text(encoding='utf-8'))
    reading = json.loads((HERE / '読戻し条件の雛形.json').read_text(encoding='utf-8'))
    for value in (generation, reading):
        value['監査コードSHA256'] = link.owned()
        value['first2_readback'] = {'path': 'work/101連続入力の全54場_版3/人工readback.json', 'sha256': 'a' * 64}
    reading['生成receiptSHA256'] = 'b' * 64
    condition_path = HERE / '人工条件_未保存.json'
    gen, paths = link.bind(generation, '生成', condition_path, check_files=False)
    read, _ = link.bind(reading, '読戻し', condition_path, check_files=False)
    assert gen['BUILDER'] == link.ROOT / 'work/101連続入力の試作_版3'
    assert gen['FIRST_SHA'] == generation['first2_receipt']['sha256']
    assert gen['FIRST_ENDING_SHA'] == generation['first2_ending']['sha256']
    assert read['FIRST_SHA'] == 'a' * 64 and read['FIRST_RECEIPT_SHA'] == generation['first2_receipt']['sha256']
    assert read['BUILDER'] == paths['producer_stop']
    assert gen['CORE'] is link.GEN.CORE and read['CORE'] is link.READ.CORE
    assert gen['run'].__code__ is link.GEN.run.__code__
    assert gen['extract_endings'].__code__ is link.GEN.extract_endings.__code__
    assert gen['compare_headers'].__code__ is link.GEN.compare_headers.__code__
    assert read['prepare'].__code__ is link.READ.prepare.__code__
    assert read['validate_completion'].__code__ is link.READ.validate_completion.__code__
    projected_gen, projected_read = gen['load'](condition_path), read['load'](condition_path)
    assert set(projected_gen) == {'version', 'scope', 'stage', 'builder停止SHA256', 'first2SHA256',
                                  'first2EndingSHA256', 'readbackSHA256', 'positiveNK上限',
                                  'heap標本上限MiB', 'worker', '新規出力', 'Source再実行', '金融実行'}
    assert set(projected_read) == link.READ.CONDITION_KEYS
    read['validate_condition'](projected_read, 'b' * 64, link.path_value(reading['生成先']), link.owned())
    assert generation['version'] == reading['version'] == 3
    assert old_globals == (link.GEN.BUILDER, link.GEN.FIRST_SHA, link.READ.BUILDER, link.READ.FIRST_SHA)
    ids = ['2026-09-21_Day', '2026-09-21_Night']
    fake_stop = {'所有コードSHA256': {'新producer.go': 'c' * 64}}
    first = {'成功': True, '前後不変': True, 'stage': 'first2', 'sessions': ids,
             '固定100完了SHA256': gen['PROOF_SHA'], 'scope': '固定100と旧Tapeの連続技法sidecar構築',
             'source_reexecuted': False, 'financial_executed': False,
             '所有コードSHA256': fake_stop['所有コードSHA256'],
             'details': [{'session': sid, 'header_SHA256': str(i+1) * 64} for i, sid in enumerate(ids)]}
    ending = {'成功': True, '前後不変': True,
              'scope': '先頭2場sidecar場末の独立辞書復元と固定100 chart_endの全値比較',
              '場末': [{'session': sid, '一致': True, 'field除外': [], 'header_SHA256': str(i+1) * 64}
                       for i, sid in enumerate(ids)],
              '入力コードSHA256前後': {'新receipt': generation['first2_receipt']['sha256']}}
    gen['validate_first'](first, ending, fake_stop)
    rejected = []
    def reject(name, fn):
        """
        機能: 未固定Source/条件/型の狭い拒否を確認する。
        引数: name(str)、fn(callable)は破損名と検査呼出。
        返り値: None。受理されたらAssertionError。
        """
        try:
            fn()
        except (ValueError, KeyError, TypeError, AssertionError) as exc:
            rejected.append({'破損': name, '拒否': str(exc)})
        else:
            raise AssertionError('破損を受理: ' + name)
    for field in ('producer_stop', 'first2_receipt', 'first2_ending', 'first2_readback'):
        value = copy.deepcopy(generation); value[field]['sha256'] = ''
        reject(field + '未固定', lambda value=value: link.bind(value, '生成', condition_path, check_files=False))
    reject('所有コード未固定', lambda: link.validate_condition({**generation, '監査コードSHA256': {}}, '生成', link.owned()))
    reject('Source実行true', lambda: link.validate_condition({**generation, 'Source再実行': True}, '生成', link.owned()))
    reject('金融実行true', lambda: link.validate_condition({**generation, '金融実行': True}, '生成', link.owned()))
    reject('stage未許可', lambda: link.validate_condition({**generation, 'stage': 'full66'}, '生成', link.owned()))
    reject('生成worker2', lambda: link.validate_condition({**generation, 'workers': 2}, '生成', link.owned()))
    reject('読戻しworker5', lambda: link.validate_condition({**reading, 'workers': 5}, '読戻し', link.owned()))
    reject('読戻しでもheap低下を拒否', lambda: link.validate_condition({**reading, 'heap標本上限MiB': 1}, '読戻し', link.owned()))
    reject('読戻しreceipt未固定', lambda: link.validate_condition({**reading, '生成receiptSHA256': ''}, '読戻し', link.owned()))
    reject('repo外metadata', lambda: link.path_value('../禁止metadata.json'))
    reject('旧first2成功の転記', lambda: gen['validate_first']({**first, '所有コードSHA256': {'旧producer.go': 'd' * 64}}, ending, fake_stop))
    reject('実CLIで偽SHAの現物なし', lambda: link.bind(generation, '生成', condition_path, check_files=True))
    value = {'成功': True, 'scope': '版3のSource差だけmetadata人工', '正常項目': 10,
             '破損拒否数': len(rejected), '破損拒否': rejected,
             '旧生成コードSHA256': link.GEN_SHA, '旧読戻しコードSHA256': link.READ_SHA,
             '旧関数code object保持': True, '固定Core799/00d8同一module': True,
             '旧module globals不変': True, '市場本文/Go/Raw/Native/金融実行': 0,
             '実first2/readback成功転記': False}
    (HERE / '人工確認.json').write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({key: value[key] for key in ('成功', '正常項目', '破損拒否数', '旧関数code object保持',
                                                '旧module globals不変', '市場本文/Go/Raw/Native/金融実行')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
