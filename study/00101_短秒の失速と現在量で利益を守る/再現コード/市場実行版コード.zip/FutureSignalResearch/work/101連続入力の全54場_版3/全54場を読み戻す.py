"""停止核00d8と旧727wrapperを使い、版3生成cacheだけを独立読戻しする。"""

import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
import importlib.util
import json
from pathlib import Path
import re
import sys
import types


HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('版3接続_読戻し', HERE / '版3の接続.py')
LINK = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = LINK
SPEC.loader.exec_module(LINK)


def main():
    """
    機能: 版3Source/先行証拠を旧metadata検査へ結び核の一場一巡へ委譲する。
    引数: --run/--condition/--condition-sha/--receipt-sha/--input/--outは明示入力。
    返り値: intは成功0又は不一致1。生成・Source/金融/特徴再計算はしない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true', required=True)
    for name in ('condition', 'input', 'out'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--condition-sha', required=True)
    parser.add_argument('--receipt-sha', required=True)
    args = parser.parse_args()
    LINK.need(re.fullmatch('[0-9a-f]{64}', args.condition_sha or '') is not None
              and LINK.digest(args.condition) == args.condition_sha, '版3読戻し条件SHA')
    condition = LINK.READ.load(args.condition)
    namespace, _ = LINK.bind(condition, '読戻し', args.condition)
    LINK.need(args.out.resolve() == LINK.path_value(condition['出力'])
              and args.input.resolve() == LINK.path_value(condition['生成先'])
              and args.receipt_sha == condition['生成receiptSHA256'], '版3読戻しの入力/出力/SHA bind')
    legacy_args = types.SimpleNamespace(condition=args.condition, condition_sha=args.condition_sha,
                                       receipt_sha=args.receipt_sha, input=args.input, out=args.out,
                                       workers=condition['workers'])
    tasks, before, _ = namespace['prepare'](legacy_args)
    details, errors = [], {}
    with ProcessPoolExecutor(max_workers=condition['workers']) as pool:
        futures = {pool.submit(namespace['CORE'].inspect_scene, *task): task[0].name for task in tasks}
        for future in as_completed(futures):
            try:
                details.append(future.result())
                print('版3監査完了 ' + futures[future], flush=True)
            except Exception as exc:
                errors[futures[future]] = str(exc)
    after = {path: LINK.digest(Path(path)) for path in before}
    counts = Counter()
    for row in details:
        counts.update(row['counts'])
    success = not errors and len(details) == 54 and before == after
    value = {'成功': success, '版': 3, 'scope': LINK.READ.SCOPE, 'stage': 'full54',
             'sessions': sorted(row['session'] for row in details), '入力構築receiptSHA256': args.receipt_sha,
             '実行条件SHA256': args.condition_sha, 'producer_stop': condition['producer_stop'],
             'first2_receipt': condition['first2_receipt'], 'first2_ending': condition['first2_ending'],
             'first2_readback': condition['first2_readback'], '読戻し核SHA256': LINK.READ.CORE_SHA,
             'details': sorted(details, key=lambda row: row['session']), 'errors': errors, 'counts': dict(counts),
             '入力codeSHA256前': before, '入力codeSHA256後': after, '前後不変': before == after,
             'RawCSV旧Native追加読取': 0, '特徴Source金融再生成': 0, '退出採否/PnL': 0,
             '旧市場Ending比較': False, '限定Endingの実証': '生成CLIの別receiptへ参照・読戻し成功で代用しない'}
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    return 0 if success else 1


if __name__ == '__main__':
    raise SystemExit(main())
