"""Root条件の版3Source/先行証拠を旧生成wrapperへ結ぶ薄いCLI。"""

import argparse
import importlib.util
import json
from pathlib import Path
import re
import sys
import types


HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('版3接続_生成', HERE / '版3の接続.py')
LINK = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = LINK
SPEC.loader.exec_module(LINK)


def main():
    """
    機能: 実行前条件SHAを確認後、旧生成の全検査と本文処理へ委譲する。
    引数: --run/--condition/--condition-sha/--stop/--outはRootの明示条件と新規先。
    返り値: intは成功0。未固定なら本文前に例外で拒否する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true', required=True)
    parser.add_argument('--condition', type=Path, required=True)
    parser.add_argument('--condition-sha', required=True)
    parser.add_argument('--stop', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    LINK.need(re.fullmatch('[0-9a-f]{64}', args.condition_sha or '') is not None
              and LINK.digest(args.condition) == args.condition_sha, '版3実行前条件SHA')
    condition = LINK.GEN.load(args.condition)
    namespace, paths = LINK.bind(condition, '生成', args.condition)
    LINK.need(LINK.digest(args.condition) == args.condition_sha, 'Source結合前後の条件SHA')
    LINK.need(args.out.resolve() == LINK.path_value(condition['出力']), '版3生成出力の条件bind')
    legacy_args = types.SimpleNamespace(condition=args.condition, readback=paths['first2_readback'],
                                       readback_sha=condition['first2_readback']['sha256'], stop=args.stop, out=args.out)
    value = namespace['run'](legacy_args)
    LINK.need(LINK.digest(args.condition) == args.condition_sha, '版3生成後の条件SHA')
    # 旧receiptの意味を変えず、版3入力の明示条件を別receiptへ結ぶ。
    namespace['save_new'](args.out / '版3実行条件の結合.json', {
        '成功': True, '条件SHA256': args.condition_sha, '版': 3,
        'producer_stop': condition['producer_stop'], 'first2_receipt': condition['first2_receipt'],
        'first2_ending': condition['first2_ending'], 'first2_readback': condition['first2_readback'],
        '生成receiptSHA256': LINK.digest(args.out / '完了.json'),
        '限定Ending照合SHA256': LINK.digest(args.out / '全54場の完了照合.json'),
        'full54独立readback': '別receipt・この生成CLIでは未実施', 'Source/金融/新損益': 0,
    })
    print(json.dumps({'成功': value['成功'], '場数': len(value['sessions']), '版': 3}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
