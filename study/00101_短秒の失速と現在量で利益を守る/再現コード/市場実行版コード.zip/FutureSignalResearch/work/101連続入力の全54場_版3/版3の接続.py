"""旧生成/読戻しwrapperを無改変再用し、Source固定値だけ実行前条件へ分離する。"""

import hashlib
import importlib.util
from pathlib import Path
import re
import sys
import types


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
GEN_PATH = ROOT / 'work/101連続入力の全54場/生成と場末を照合する.py'
GEN_SHA = '3ae7f443e3e267af19c17e7b883046b6d790f12acf674c79ed5148baa9fec223'
GEN_STOP = ROOT / 'work/101連続入力の全54場/停止.json'
GEN_STOP_SHA = '720fd2ba37f89b622f5908f4e62c279ff709216d3411f9d1f89b18b783d3a702'
READ_PATH = ROOT / 'work/101連続入力の全54読取照合/全54場を読み戻す.py'
READ_SHA = '877de72e6f0bc2052c964320d1524df3fd3d3b843864df47185d9d366acaed3a'
READ_STOP = ROOT / 'work/101連続入力の全54読取照合/停止.json'
READ_STOP_SHA = '72730ff759bcf447b2d44eb9b271a50a71291ec9cabc1fbbf4677215f035c091'
CONDITION_KEYS = {'version', 'mode', 'scope', 'stage', 'producer_stop', 'first2_receipt', 'first2_ending',
                  'first2_readback', '生成先', '生成receiptSHA256', '出力', 'positiveNK上限',
                  'heap標本上限MiB', 'workers', '監査コードSHA256', '実行前固定', 'Source再実行', '金融実行'}
SCOPE = '版3の許可54連続入力・限定Ending・独立読戻しの別receipt'


def need(value, reason):
    """
    機能: 実行前metadata不一致を拒否する。
    引数: value(bool)、reason(str)は条件と説明。
    返り値: None。不成立ならValueError。
    """
    if not value:
        raise ValueError(reason)


def digest(path):
    """
    機能: 明示ファイルの内容指紋を得る。
    引数: path(Path)はコード又はRootが指定するmetadata。
    返り値: strはSHA256。
    """
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def fixed(name, path, expected):
    """
    機能: 旧停止wrapperを指紋確認してimportする。
    引数: name/expected(str)、path(Path)は識別・指紋・コード。
    返り値: moduleは不変の旧部品。mainは実行しない。
    """
    need(digest(path) == expected, '旧wrapper SHA差')
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


need(digest(GEN_STOP) == GEN_STOP_SHA and digest(READ_STOP) == READ_STOP_SHA, '旧2停止SHA差')
GEN = fixed('固定720生成wrapper_版3', GEN_PATH, GEN_SHA)
READ = fixed('固定727読戻しwrapper_版3', READ_PATH, READ_SHA)


def owned():
    """
    機能: 版3の所有コード/計画/雛形を列挙する。
    引数: なし。
    返り値: dictはrepo相対8file→SHA。
    """
    names = ('版3の接続.py', '生成と場末を照合する.py', '全54場を読み戻す.py', '人工を確認する.py',
             '計画.md', 'README.md', '生成条件の雛形.json', '読戻し条件の雛形.json')
    return {str((HERE / name).relative_to(ROOT)).replace('\\', '/'): digest(HERE / name) for name in names}


def path_value(value):
    """
    機能: Root指定のmetadata pathをrepo内の絶対pathへ解決する。
    引数: value(str)は相対又は絶対path。
    返り値: Pathはrepo内の対象。新日やRawを探索しない。
    """
    need(type(value) is str and bool(value), 'metadata path未固定')
    path = Path(value)
    path = path.resolve() if path.is_absolute() else (ROOT / path).resolve()
    need(path.is_relative_to(ROOT), 'metadataはrepo内の明示先だけ')
    return path


def validate_condition(condition, mode, code):
    """
    機能: 版3の未固定Source/先行2場/出力を本文前に拒否する。
    引数: condition(dict)、mode(str)、code(dict)はRoot条件・実行種別・所有指紋。
    返り値: dictは4つの明示metadata path。内容はまだ読まない。
    """
    need(set(condition) == CONDITION_KEYS, '版3条件の全key')
    need(mode in ('生成', '読戻し'), '版3の実行mode')
    need(type(condition['version']) is int and condition['version'] == 3 and condition['mode'] == mode
         and condition['scope'] == SCOPE and condition['stage'] == 'full54'
         and condition['実行前固定'] is True and condition['Source再実行'] is False
         and condition['金融実行'] is False, '版3条件のscope/非売買')
    need(condition['監査コードSHA256'] == code, '版3所有codeの実行前固定')
    need(type(condition['positiveNK上限']) is int and condition['positiveNK上限'] == 4000000
         and type(condition['heap標本上限MiB']) is int and condition['heap標本上限MiB'] == 32768,
         '版3資源上限')
    need(type(condition['workers']) is int
         and (condition['workers'] == 1 if mode == '生成' else 1 <= condition['workers'] <= 4), '版3worker')
    result = {}
    for name in ('producer_stop', 'first2_receipt', 'first2_ending', 'first2_readback'):
        value = condition[name]
        need(type(value) is dict and set(value) == {'path', 'sha256'}
             and type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}', value['sha256'])
             and set(value['sha256']) != {'0'}, '版3先行path/SHA未固定: ' + name)
        result[name] = path_value(value['path'])
    output, generation = path_value(condition['出力']), path_value(condition['生成先'])
    need(generation.parent == HERE and output.parent == HERE, '版3専用workの新規出力')
    if mode == '生成':
        need(output == generation and condition['生成receiptSHA256'] == '', '生成は新規cacheだけ')
    else:
        need(output != generation and re.fullmatch('[0-9a-f]{64}', condition['生成receiptSHA256'] or '') is not None,
             '読戻しは完成生成receiptを先行固定')
    return result


def clone_functions(module, changes):
    """
    機能: 旧関数code objectを保持したままSource定数のnamespaceを独立作成する。
    引数: module、changes(dict)は旧wrapperと明示するpath/SHA/所有差。
    返り値: dictは独立namespace。旧moduleのglobalsを書換えない。
    """
    namespace = dict(vars(module), **changes)
    for name, value in vars(module).items():
        if isinstance(value, types.FunctionType) and value.__globals__ is vars(module):
            fn = types.FunctionType(value.__code__, namespace, value.__name__, value.__defaults__, value.__closure__)
            fn.__kwdefaults__ = value.__kwdefaults__
            namespace[name] = fn
    namespace.update(changes)
    return namespace


def bind(condition, mode, condition_path, check_files=True):
    """
    機能: 旧検査を保持しSource固定値だけRoot条件の明示値へ結ぶ。
    引数: condition(dict)、mode(str)、condition_path(Path)、check_files(bool)は実条件又は小人工。
    返り値: tuple[namespace,dict]は委譲口と解決metadata。check_files=Falseは人工専用。
    """
    paths = validate_condition(condition, mode, owned())
    if check_files:
        for name, path in paths.items():
            need(path.is_file() and digest(path) == condition[name]['sha256'], '版3先行証拠の現物SHA: ' + name)
    producer = paths['producer_stop'].parent
    changes = dict(ROOT=ROOT, HERE=HERE, BUILDER=producer if mode == '生成' else paths['producer_stop'],
                   BUILDER_SHA=condition['producer_stop']['sha256'], FIRST_SHA=condition['first2_receipt']['sha256'] if mode == '生成' else condition['first2_readback']['sha256'],
                   FIRST=paths['first2_receipt'] if mode == '生成' else paths['first2_readback'],
                   FIRST_ENDING=paths['first2_ending'], FIRST_ENDING_SHA=condition['first2_ending']['sha256'],
                   FIRST_RECEIPT=paths['first2_receipt'], FIRST_RECEIPT_SHA=condition['first2_receipt']['sha256'],
                   ALLOWED=producer / '許可54.json', INPUT=path_value(condition['生成先']), owned=owned)
    if mode == '読戻し' and check_files:
        changes['ALLOWED_SHA'] = digest(producer / '許可54.json')
    module = GEN if mode == '生成' else READ
    namespace = clone_functions(module, changes)
    if mode == '生成':
        projected = dict(version=1, scope=GEN.SCOPE, stage='full54',
                         builder停止SHA256=condition['producer_stop']['sha256'], first2SHA256=condition['first2_receipt']['sha256'],
                         first2EndingSHA256=condition['first2_ending']['sha256'], readbackSHA256=condition['first2_readback']['sha256'],
                         positiveNK上限=4000000, heap標本上限MiB=32768, worker=1,
                         新規出力=condition['生成先'], Source再実行=False, 金融実行=False)
    else:
        projected = dict(version=1, scope=READ.SCOPE, stage='full54', builder停止SHA256=condition['producer_stop']['sha256'],
                         読戻し核SHA256=READ.CORE_SHA, first2readbackSHA256=condition['first2_readback']['sha256'],
                         first2生成receiptSHA256=condition['first2_receipt']['sha256'], 固定100完了SHA256=READ.PROOF_SHA,
                         許可54SHA256=namespace.get('ALLOWED_SHA', READ.ALLOWED_SHA), 生成receiptSHA256=condition['生成receiptSHA256'],
                         生成先=condition['生成先'], 監査コードSHA256=owned(), 実行前固定=True,
                         Source再実行=False, 金融実行=False, 特徴再生成=False, 退出採否=False)
    def load_adapter(path):
        """
        機能: 実条件の追加path欄を旧wrapperの固定schemaへ値copyで射影する。
        引数: path(Path)は条件又は既存metadata。
        返り値: dictは旧検査用値。実条件ファイルのbytes/SHAは変更しない。
        """
        return dict(projected) if path.resolve() == condition_path.resolve() else module.load(path)
    namespace['load'] = load_adapter
    return namespace, paths
