# 版3の全54入力工程

2026-11-09。旧生成720fd/旧全54読戻し72730は変更せず、[版3の接続](版3の接続.py)でSource固定値だけをRootの実行前条件へ結ぶ。固定100/許可54/Core799/読戻し核00d8/旧RootEnding復元をそのまま再用する。[計画](計画.md)を参照。

producerは[版3停止cf49](../101連続入力の試作_版3/停止.json)。Root通知の新first2 receipt e1a29とEnding11c0まで雛形へ反映した。新first2独立readbackと全54生成receiptは準備時点で未受領なので空欄とし、旧fb53を新実証へ転記しない。Rootが実行直前に新しい条件ファイルへ実path/SHAと[今回停止](停止.json)の所有コード辞書を固定する。後日コードへ未知SHAを埋めない。

雛形を直接編集せず、新規の生成条件.json/読戻し条件.jsonへ保存する。全項目固定後にファイルSHAを計算しCLIへ同じ値を渡す。条件自体のbytesは旧検査用のschema投影で書き換えず、実行証拠へ保存する。

生成のRoot専用CLI（未受領欄があれば実行しない）:

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101連続入力の全54場_版3/生成と場末を照合する.py' --run `
  --condition 'work/101連続入力の全54場_版3/生成条件.json' `
  --condition-sha <Rootが固定した条件SHA256> `
  --stop 'work/101連続入力の全54場_版3/停止.json' `
  --out 'work/101連続入力の全54場_版3/生成'
```

同54prefixの先頭2場も新プロセスで再処理しprivate Seedを継承する。単一worker/4,000,000positiveNK行/32,768MiB heap標本。旧Scalar11/全5分Inputと最後の限定NativeEnding全54比較は720fdの検査へ委譲する。出力は新規だけ。Source/金融/新損益は実行しない。

生成後の独立readbackは別Root条件/別CLI/別receipt:

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101連続入力の全54場_版3/全54場を読み戻す.py' --run `
  --condition 'work/101連続入力の全54場_版3/読戻し条件.json' `
  --condition-sha <Rootが固定した読戻し条件SHA256> `
  --receipt-sha <新しい版3全54生成receiptのSHA256> `
  --input 'work/101連続入力の全54場_版3/生成' `
  --out 'work/101連続入力の全54場_版3/全54読戻し.json'
```

読戻しは停止72730のmetadata/正規path/SHA検査と00d8のinspect_sceneへ各場一回委譲し、worker1..4は実行前条件に固定する。Raw/CSV/旧Nativeの追加意味展開や特徴の再形成は行わない。新streamのSeal復元と旧100Endingの限定全値比較は別の証拠として保持する。

APIは`bind(condition, mode, condition_path, check_files=True)`。旧関数のcode objectを保ち独立namespaceへ定数を差し替え、旧moduleのglobalsは変更しない。check_files=Falseはmetadata人工だけに使い、実CLIは必ず現物SHAを先行確認する。未固定・別版・集合差は元の検査を維持して拒否する。

人工だけの再現:

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101連続入力の全54場_版3/人工を確認する.py'
```

この準備でRaw/Native/CSV/stream市場本文と失敗成果物は読まない。旧版の停止・失敗・部分cacheを上書き/削除しない。S金融/機会損失/退出後価格は扱わない。入力保存の成功は新売買や未知期間安定性の成功ではない。
