"""固定100全金融を継承し、旧Step後のS5Q/S515Qだけを独立再構成する。"""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[2]
OLD_PATH = ROOT / 'scripts/FAR利益化前後の保護の監査/費用前ガードと金融の照合.py'
OLD_SHA = 'd6b2eb4dc18c082f3acf39dbc2f74553b127e0e1491bd601671c7e50c17aa6e7'
PURE_PATH = ROOT / 'work/短秒複合退出の独立純式/短秒の純判定.py'
PURE_SHA = 'd50202814e046a7a7f69579882544102e5180e09cf9e88ce46168a542bc9126b'
FINANCE_STOP = ROOT / 'work/短秒複合退出の金融/停止.json'
FINANCE_SHA = 'f3606e629a84df0530266d6c43fc89d48df87985841baaaeb0c1471ec6046501'
REASON = '利益起動後の短秒進行・現在量の複合失効'
COUNTERS = {'short_exit_requests', 'short_exit_fills'}
POLICIES = ('', 'S5Q', 'S515Q')
KEYS = tuple((policy + '_' if policy else '') + f'E3S_B5Q_P0_C{cost}_D{delay}'
             for policy in POLICIES for cost in (0, 5) for delay in (0, 1))


def sha(path):
    """
    機能: 明示したコード又は人工の内容指紋を取得する。
    引数: path(Path)は許可済みファイル。
    返り値: strはSHA256。市場を探索しない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fixed(name, path, expected):
    """
    機能: 内容SHAを検査して停止済み独立部品を読み込む。
    引数: name/expected(str)、path(Path)はmodule名・指紋・コード。
    返り値: moduleは固定Python部品。Goは実行しない。
    """
    if sha(path) != expected:
        raise ValueError('停止部品のSHA差: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


OLD = fixed('固定100全金融_短秒独立', OLD_PATH, OLD_SHA)
PURE = fixed('固定短秒独立純式_金融', PURE_PATH, PURE_SHA)
if sha(FINANCE_STOP) != FINANCE_SHA:
    raise ValueError('短秒金融停止のSHA差')
BASE, Audit, TAPE = OLD.BASE, OLD.Audit, OLD.TAPE


class ArtificialEntry:
    """元API人工に明示されたE3S許可stubだけを定数から再現する。"""

    def __init__(self, audit):
        """
        機能: 新規stub呼出集合を空から用意する。
        引数: audit(Audit)は独立比較器。
        返り値: None。保存Decisionを期待値へ戻さない。
        """
        self.audit, self.used = audit, []

    def claim(self, key, opportunity):
        """
        機能: 旧金融前資格を通った人工候補に宣言された許可を返す。
        引数: key(str)、opportunity(dict)は独立会計と元出生の候補。
        返り値: dictは固定stub。自然E3Sの成立を証明しない。
        """
        marker = key, opportunity['ordinal']
        self.audit.need(marker not in self.used, '人工新規callback一回')
        self.used.append(marker)
        return dict(policy='E3S', snapshot_id='人工入口', known=True, allowed=True,
                    role='順行', reason='金融接続の入口stub')


class ShortPath(OLD.ProtectionPath):
    """Source/P0/費用/全MTMは固定し、旧Step後の短秒要求だけを追加する。"""

    def __init__(self, actual, audit, entry_gate, expected_contract):
        """
        機能: 新型全tagを検査し、共通初期化だけを旧100P0へ投影する。
        引数: actual(dict)、audit(Audit)、entry_gate、expected_contract(str)は保存・比較器・新規口・外部期待限月。
        返り値: None。全新欄は最終全文比較に保持する。
        """
        audit.need(type(expected_contract) is str and expected_contract.strip() == expected_contract
                   and bool(expected_contract), '外部期待限月の明示')
        audit.need(actual['key'] in KEYS, '短秒全12key')
        cfg = actual['config']
        policy = cfg.get('exit_policy', '')
        audit.need(policy in POLICIES and ('exit_policy' in cfg) == bool(policy), 'S政策/空omitempty')
        fields = {'policy', 'entry_timing', 'us_open', 'slip_pts', 'delay_seconds', 'gate_policy'}
        if policy:
            fields.add('exit_policy')
        audit.equal(set(cfg), fields, '短秒config全tag・Harvest/Risk対象外')
        audit.need(cfg['policy'] == 'P0' and cfg['entry_timing'] == 'B5Q'
                   and cfg['gate_policy'] == 'E3S', '共通E3S/B5Q/P0')
        base_key = f"E3S_B5Q_P0_C{cfg['slip_pts']:g}_D{cfg['delay_seconds']}"
        audit.equal(actual['key'], (policy + '_' if policy else '') + base_key, '短秒本名key')
        top = {'session', 'key', 'config', 'orders', 'fills', 'positions', 'source_events', 'metrics',
               'totals', 'account', 'finished', 'complete', 'failure', 'stream_scope',
               'entry_opportunities', 'grid_traces', 'grid_metrics'}
        if policy:
            top.add('short_exit_contract')
            audit.equal(actual['short_exit_contract'], expected_contract, 'constructorの外部期待限月')
            if 'short_exit_events' in actual:
                audit.need(type(actual['short_exit_events']) is list and len(actual['short_exit_events']) > 0,
                           'S traceのomitempty')
                top.add('short_exit_events')
        audit.equal(set(actual), top, '短秒金融全top・未知欄を落とさない')
        audit.need(set(actual['metrics']) <= BASE.METRIC_FIELDS | COUNTERS
                   and BASE.METRIC_FIELDS <= set(actual['metrics']), '短秒全metrics')
        for name in COUNTERS & set(actual['metrics']):
            audit.need(bool(policy) and type(actual['metrics'][name]) is int and actual['metrics'][name] > 0,
                       'S counterの正数omitempty')
        common = copy.deepcopy(actual)
        common['key'] = base_key
        common['config'].pop('exit_policy', None)
        common.pop('short_exit_contract', None)
        common.pop('short_exit_events', None)
        for name in COUNTERS:
            common['metrics'].pop(name, None)
        super().__init__(common, audit, entry_gate)
        self.actual, self.extra_actual, self.key = actual, actual, actual['key']
        self.config = actual['config']
        self.short_policy, self.expected_contract = policy, expected_contract
        self.short_events, self.short_requests, self.short_fills = [], 0, 0
        self.last_received, self.callback_count = None, 0
        self.trace_statuses = {}

    def bind_input(self, incoming, q, received):
        """
        機能: 当原行Inputを金融場・外部期待限月・同原行Currentへ結ぶ。
        引数: incoming/q(dict)、received(float)は公開型・独立金融気配・元受理時計。
        返り値: None。純採否の品質検査は実callback時に別に行う。
        """
        PURE.X5.PUBLIC.finite_tree(incoming)
        a, chart, current = self.audit, incoming['chart'], incoming['current']
        a.need(type(incoming['snapshot_id']) is str and bool(incoming['snapshot_id']), 'S SnapshotID非空')
        a.equal((incoming['at'], chart['at'], incoming['kind']),
                (q['time'], q['time'], self.session['kind']), 'S当原行At/Kind')
        a.equal((chart['scene']['id'], chart['scene']['start'], chart['scene']['contract']),
                (self.session['id'], self.session['start'], self.expected_contract), 'S外部場/期待限月')
        expected = dict(reference='NK225', time=q['time'], received=received, source_index=q['index'],
                        source_line=q['source_line'], last=q['last'], bid=q['bid'], ask=q['ask'])
        for name, value in expected.items():
            a.equal(current[name], value, 'S Currentと原行: ' + name)

    def request_short(self, position, q, candidate, assessment):
        """
        機能: 独立S成立後の未予約残全量だけを共通要求口へ渡す。
        引数: position/q/candidate/assessment(dict)は私有玉・原行・独立候補・純判断。
        返り値: dictは専用point付き期待注文。
        """
        free = position['quantity'] - position['reserved']
        self.audit.need(free > 0 and assessment['decision']['known']
                        and assessment['decision']['allowed'], 'S要求の正未予約量/純判断')
        point = dict(candidate=copy.deepcopy(candidate), assessment=copy.deepcopy(assessment))
        order = super().request('exit', -position['side'], free, position['source'], q['time'], q,
                                REASON, position)
        self.metrics['source_exit_requests'] -= 1
        self.audit.need(self.metrics['source_exit_requests'] >= 0, 'SをSource要求へ重複計上しない')
        self.short_requests += 1
        order['short_exit_point'] = point
        return order

    def short_step(self, q, batches, atr, incoming, received):
        """
        機能: 旧Step全処理後に私有保有からS候補・採否・traceを作る。
        引数: q/atr/incoming(dict)、batches(list)、received(float)は当原行と公開Input。
        返り値: tuple[list,list]は実callback候補/純判定。Go保存値は計算に使わない。
        """
        self.bind_input(incoming, q, received)
        super().step(q, batches, atr)
        self.last_received = received
        self.capacity(1)
        self.capacity(-1)
        candidates, assessments = [], []
        if not self.short_policy:
            return candidates, assessments
        trace = dict(at=incoming['at'], snapshot_id=incoming['snapshot_id'], quote=copy.deepcopy(q), positions=[])
        for position in self.positions.values():
            if position['quantity'] == 0:
                continue
            free = position['quantity'] - position['reserved']
            row = dict(position_id=position['id'], quantity=position['quantity'], reserved=position['reserved'],
                       free=free, status='対象外', reason='P0利益起動前', candidate=None,
                       assessment=None, requested=0, order_id='')
            if position['protection_active']:
                activation = position['activation']
                self.audit.need(activation is not None and activation['unit_net'] > 0
                                and all(BASE.finite(activation[name]) for name in ('unit_net', 'gain_points'))
                                and activation['quote']['time'] <= q['time']
                                and activation['quote']['index'] <= q['index'], 'S私有strict u正益起動証拠')
                if free == 0:
                    row['reason'] = '先行Source/P0/短秒が全量予約済み'
                elif not BASE.quote_ok(q):
                    row.update(status='判定不能', reason='金融の最新QuoteOK/BBOが不良')
                else:
                    candidate = dict(policy=self.short_policy, session_id=self.session['id'], kind=self.session['kind'],
                                     contract=self.expected_contract, position_id=position['id'], source=copy.deepcopy(position['source']),
                                     source_hold_id=position['source_hold_id'], side=position['side'], at=q['time'],
                                     snapshot_id=incoming['snapshot_id'], quote=copy.deepcopy(q), quote_received=received,
                                     quantity=position['quantity'], reserved=position['reserved'], activation=copy.deepcopy(activation))
                    before = TAPE.canonical(incoming)
                    assessment = PURE.assess(incoming, position['side'], self.short_policy)
                    self.audit.equal(TAPE.canonical(incoming), before, 'S純式入力不変')
                    row.update(candidate=copy.deepcopy(candidate), assessment=copy.deepcopy(assessment),
                               status='不成立' if assessment['decision']['known'] else '判定不能',
                               reason=assessment['decision']['reason'])
                    candidates.append(candidate)
                    assessments.append(assessment)
                    self.callback_count += 1
                    if assessment['decision']['allowed']:
                        order = self.request_short(position, q, candidate, assessment)
                        row.update(status='返済要求', reason=REASON, requested=free, order_id=order['id'])
            self.trace_statuses[row['status']] = self.trace_statuses.get(row['status'], 0) + 1
            trace['positions'].append(row)
        if trace['positions']:
            self.short_events.append(trace)
        self.capacity(1)
        self.capacity(-1)
        return candidates, assessments

    def fill_pending(self, q, atr):
        """
        機能: 固定nextEligible/費用/所有配分の後、S約定だけ専用計数へ分ける。
        引数: q/atr(dict)は当原行と公開幅。
        返り値: None。S要求と同じ原行では約定しない。
        """
        before = len(self.fills)
        super().fill_pending(q, atr)
        by_id = {order['id']: order for order in self.orders}
        for fill in self.fills[before:]:
            order = by_id[fill['order_id']]
            if 'short_exit_point' in order:
                self.audit.need(fill['action'] == 'close' and fill['reason'] == REASON
                                and order['protection_point'] is None
                                and fill['quote']['index'] > order['request_quote']['index']
                                and fill['quote']['time'] >= order['request_time'] + self.config['delay_seconds'],
                                'S strict後続適格/D1/Source-P0分類')
                self.short_fills += 1

    def finish(self):
        """
        機能: 全旧金融とS専用記録/計数を全必要fieldで閉じる。
        引数: なし。
        返り値: dictは一会計の独立検査範囲。
        """
        if self.short_policy:
            self.audit.equal('short_exit_events' in self.actual, bool(self.short_events), 'S trace省略の正規形')
            BASE.compare_tree(self.actual.get('short_exit_events', []), self.short_events,
                              self.audit, self.key + '/S全event/候補/判断')
        for name, value in (('short_exit_requests', self.short_requests), ('short_exit_fills', self.short_fills)):
            self.audit.equal(name in self.actual['metrics'], value > 0, 'S counter省略の正規形')
            if value:
                self.metrics[name] = value
        result = super().finish()
        return dict(result, short_policy=self.short_policy or 'P0', short_events=len(self.short_events),
                    short_callbacks=self.callback_count, short_exit_requests=self.short_requests,
                    short_exit_fills=self.short_fills, statuses=self.trace_statuses)


def inspect_fixture(value, expected_contract='人工限月'):
    """
    機能: 停止Go型人工の全callを固定金融と独立S純式へ配送する。
    引数: value(dict)、expected_contract(str)は明示人工/外部期待限月。
    返り値: dictは一会計の全経路照合結果。市場CLIは持たない。
    """
    before = TAPE.canonical(value)
    audit = Audit()
    audit.equal(set(value), {'scope', 'side', 'calls', 'book'}, 'S人工top全field')
    audit.need(type(value['scope']) is str and '人工' in value['scope'], 'S人工scopeの明示')
    audit.need(type(value['side']) is int and value['side'] in (-1, 1), 'S人工鏡像側')
    audit.need(type(value['calls']) is list and bool(value['calls']), 'S全API列')
    gate = ArtificialEntry(audit)
    model = ShortPath(value['book'], audit, gate, expected_contract)
    audit.need(value['book']['finished'] is True and value['book']['complete'] is True
               and value['book']['failure'] == '', '公開型人工は正常完結値だけ')
    counts, callbacks = {}, 0
    for ordinal, call in enumerate(value['calls'], 1):
        audit.equal(set(call), {'kind', 'at', 'observation', 'line', 'batches', 'input', 'candidates', 'assessments'},
                    'S全API call字段')
        kind = call['kind']
        audit.need(type(call['line']) is int and BASE.finite(call['at']), 'S call時計/物理行型')
        counts[kind] = counts.get(kind, 0) + 1
        for field in ('candidates', 'assessments', 'batches'):
            audit.need(call[field] is None or type(call[field]) is list, 'S call配列型: ' + field)
        candidates, assessments = [], []
        try:
            if kind == 'quote':
                audit.need(type(call['observation']) is dict and type(call['line']) is int,
                           'S原行の明示型')
                q, atr = BASE.observation_quote(call['observation'], call['line'])
                audit.equal(call['at'], q['time'], 'S call当原行時計')
                audit.need(type(call['input']) is dict and type(call['batches']) is list,
                           'S原行の完全Input/Source')
                candidates, assessments = model.short_step(q, call['batches'], atr, call['input'],
                                                          call['observation']['Received'])
            elif kind in ('grid', 'force'):
                audit.need(call['observation'] is None and call['input'] is None and call['line'] == 0,
                           'grid/ForceにS原行を捏造しない')
                if kind == 'grid':
                    audit.need(call['batches'] is None, '人工gridはSource配送なし')
                    model.grid(call['at'])
                else:
                    for batch in call['batches'] or []:
                        audit.equal(batch['delta']['source_line'], model.last['source_line'], 'Force直前Source物理行')
                    model.timer(call['at'], call['batches'] or [])
            else:
                raise ValueError('S人工の未知API')
            BASE.compare_tree(call['candidates'] or [], candidates, audit, f'call{ordinal}/実callback候補')
            BASE.compare_tree(call['assessments'] or [], assessments, audit, f'call{ordinal}/独立純式全文')
            callbacks += len(candidates)
        except (ValueError, KeyError, TypeError, AssertionError) as exc:
            raise ValueError(f'{model.key}/call{ordinal}/{kind}: {exc}') from exc
    detail = model.finish()
    audit.need(all(position['side'] == value['side'] for position in model.positions.values()), '人工鏡像側と実出生側')
    expected = {(model.key, p['ordinal']) for p in value['book']['entry_opportunities'] if p.get('gate') is not None}
    audit.equal(set(gate.used), expected, '人工入口stub全適用集合')
    audit.equal(TAPE.canonical(value), before, 'S人工全入力前後不変')
    return {'成功': True, '会計数': 1, '非0会計数': int(detail['positions'] > 0), '照合項目数': audit.checks,
            '不一致数': 0, '全API': counts, '実S callback': callbacks, 'details': detail,
            '全経路金融MTM': True, '新P0のPython全文対照': False,
            'scope': 'Source/ATR/短秒/量は手製公開API、新規E3Sは宣言stub。S退出は完全Inputから独立実式。市場/原板/自然Sourceは未検査。'}
