# 短秒と現在量の保有退出：純式の人工試作

[仕様](仕様.md)のS5Q/S515Qだけを実装した。APIは `AssessShortExit(input TechnicalGateInput, side int, policy string) (Assessment,error)`。Source・特徴形成・金融・実市場は実行しない。

停止X5の公開APIで全Input品質、Currentの正常性/時計と出典、Day/Nightの現在量だけを再用する。X5の最終判断や確定3分P/Mの採否は使わない。X5側で未使用値の有限性/未来も検査するため、未使用fieldを架空0に補った縮小入力は渡さない。

S5Qは5秒窓速度と量、S515Qは15秒窓速度も必要とする。量の定義・単位・短秒両端を保存し、未知はnullで記録する。現在量や短秒が保有と反対でも、金融が起動前・予約済みなら発注対象にならない。純式はその私有判断を作らない。

人工は停止X5のGo公開Inputを指紋照合して再用し、短秒値を手製で追加したもの。鏡像/日夜、15秒の必要性、等号、未知/既知否定、鮮度境界、使用/未使用の既知窓破損、全Inputの破損を確認する。実際のFARや原板から同じパターンが出ることを示さない。

```powershell
go test -count=1 -json ./...
go vet ./...
```

実Go Marshalの人工16ケースは `公開型.json`。再作成時は新規保存先を `SHORT_EXIT_FIXTURE_OUT` に設定し `go test -count=1 -run '^TestExport$' -json ./...` を使う。通常はexportをskipする。Go判定を期待値にしない独立Pythonでの全出力照合は、別作業で行う。

費用/約定遅延・起動/free・Source優先・同原行約定禁止・片側上限は、将来の金融接続で検証する。現段階の市場損益、利益保護成績、機会損失の算出は0である。
