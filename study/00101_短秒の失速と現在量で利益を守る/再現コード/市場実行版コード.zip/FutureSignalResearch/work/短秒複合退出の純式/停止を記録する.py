"""短秒複合退出の純式と人工の指紋を固定する。"""

import hashlib
import json
from pathlib import Path


BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]


def digest(path: Path) -> str:
    """機能: ファイルの指紋を得る。

    引数: path (Path) は検査するファイル。
    返り値: str は小文字のSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """機能: 実検査ログと旧依存不変を検査して新規停止を保存する。

    引数: なし。
    返り値: None。停止JSONを新規保存する。
    """
    stop = ROOT / "work/101X5純式/停止.json"
    assert digest(stop) == "f57be6c9f32cac86cbfb34cffd931d8a76250144c2d2f544b55f8f1dc9f7b62b"
    old = json.loads(stop.read_text(encoding="utf-8"))
    for name, sha in old["コードSHA256"].items():
        assert digest(stop.parent / name) == sha, name
    for name, sha in old["Go依存SHA256"].items():
        assert digest(Path(name)) == sha, name
    for name in ("最終人工検査.exit", "vet.exit", "export.exit"):
        assert (BASE / name).read_text(encoding="utf-8-sig").strip() == "0", name
    tests = [json.loads(line) for line in (BASE / "最終人工検査.jsonl").read_text(encoding="utf-8-sig").splitlines()]
    assert not any(row["Action"] == "fail" for row in tests)
    passes = [r for r in tests if r["Action"] == "pass" and "Test" in r]
    assert len(passes) == 30
    fixture = json.loads((BASE / "公開型.json").read_text(encoding="utf-8"))
    rows = fixture["cases"]
    assert fixture["人工"] and len(rows) == 16
    allowed = sum(r["result"]["decision"]["allowed"] for r in rows)
    unknown = sum(not r["result"]["decision"]["known"] for r in rows)
    assert allowed == 10 and unknown == 3

    # ----------------------------------------
    names = ["仕様.md", "README.md", "short.go", "short_test.go", "go.mod", "go.sum", "停止を記録する.py"]
    evidence = ["公開型.json", "最終人工検査.jsonl", "最終人工検査.stderr", "最終人工検査.exit", "vet.stdout", "vet.stderr", "vet.exit", "export.jsonl", "export.stderr", "export.exit"]
    value = {
        "成功": True,
        "状態": "S5Q/S515Q純式と人工だけで停止・未採用",
        "module": "github.com/masayoshi4649/SessionTradeExecuter/minishortexit",
        "API": "AssessShortExit(input,side,policy)(Assessment,error)",
        "コードSHA256": {name: digest(BASE / name) for name in names},
        "証拠SHA256": {name: digest(BASE / name) for name in evidence},
        "旧X5停止SHA256": digest(stop),
        "旧X5コードとGo依存前後一致": True,
        "Go人工成功_小試験含む": len(passes),
        "Go公開型人工": {"件数": len(rows), "成立": allowed, "未知": unknown, "既知不成立": len(rows)-allowed-unknown},
        "金融/Source/特徴形成/Raw/Native/Tape市場読取/新約定/新損益/機会損失": 0,
        "独立Python": "未実施",
        "限界": "手製の短秒値。実市場での成立/約定/保護/改善・未知期間の安定性は示さない",
    }
    with (BASE / "停止.json").open("x", encoding="utf-8", newline="\n") as out:
        json.dump(value, out, ensure_ascii=False, indent=2)
        out.write("\n")
    print(json.dumps({"成功": True, "停止SHA256": digest(BASE / "停止.json"), "人工": len(rows)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
