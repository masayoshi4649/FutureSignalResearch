"""公開入力と実保有方向だけからX5を独立計算する。金融や市場は実行しない。"""

import copy
import hashlib
import importlib.util
import math
from pathlib import Path
import sys


ROOT=Path(__file__).resolve().parents[2]
PUBLIC_PATH=ROOT/"scripts/FAR5分枠の技法判定の監査/技法の保存照合.py"
PUBLIC_SHA="b5d1af7fb85d4446a47573a4389abfa433177189cb01d901bdd53a8a38b8d5e6"
if hashlib.sha256(PUBLIC_PATH.read_bytes()).hexdigest()!=PUBLIC_SHA:raise ValueError("固定96の公開品質コードSHA差")
SPEC=importlib.util.spec_from_file_location("固定96公開品質_X5独立",PUBLIC_PATH)
PUBLIC=importlib.util.module_from_spec(SPEC);sys.modules[SPEC.name]=PUBLIC;SPEC.loader.exec_module(PUBLIC)
need=PUBLIC.need
f=PUBLIC.f
flag=PUBLIC.flag


def integer(value,label):
    """
    機能: Go公開型のint64をbool/floatと区別して検査する。
    引数: value(object)、label(str)は出典値と識別。
    返り値: intは型範囲内の値。Source/Chart連番を相互に同値化しない。
    """
    need(type(value) is int and -(2**63)<=value<2**63,"出典整数型:"+label)
    return value


def validate_snapshot(snapshot,at):
    """
    機能: 固定96 Pythonの公開検査へ、元Goにある出典境界を補う。
    引数: snapshot(dict)、at(float)は公開値と判断時計。
    返り値: None。未知/空足は許容し、観測上限や半開足の破損を拒否する。
    """
    PUBLIC.validate_snapshot(snapshot,at)
    a=f(snapshot["at"]);observed=f(snapshot["observed_clock"])
    need(observed>=0 and (not flag(snapshot["has_observed_clock"]) or observed>=a),"観測上限が公開時計より過去")
    if snapshot["has_last_input"]:
        integer(snapshot["last_input"]["index"],"Chart最終Index");integer(snapshot["last_input"]["line"],"Chart最終Line")
    for name,width in (("three",180.0),("fifteen",900.0)):
        bar=snapshot[name];end=f(bar["bar_end"]);available=f(bar["available_at"])
        integer(bar["rows"],name+"入力行数")
        need(end<=0 or (snapshot["has_observed_clock"] and f(bar["observed_clock"])>=available),"足観測上限と公開時計")
        need((bar["rows"]>0)==flag(bar["has_last_source"]),"足入力数と原行有無")
        if bar["has_last_source"]:
            q=bar["last_source"];integer(q["index"],name+"源Index");integer(q["line"],name+"源Line")
            need(f(q["time"])>=max(f(snapshot["scene"]["start"]),end-width),"足の源原行が半開足の開始前")


def validate_current(current,at):
    """
    機能: 固定96 PythonのCurrent検査と、Goの連番/全数量成分制約を結ぶ。
    引数: current(dict)、at(float)は公開Currentと判断時計。
    返り値: None。有限性だけで未知値を既知へしない。
    """
    PUBLIC.validate_current_times(current,at)
    reference=current["reference"];time=f(current["time"])
    index=integer(current["source_index"],"Current Index");line=integer(current["source_line"],"Current物理行")
    need(type(reference) is str and reference in ("","NK225"),"Current市場")
    need(line>=0 and (time<=0 or (index>=0 and line>0)),"Current原行出典")
    need(all(f(current[n])>=0 for n in ("last","bid","ask")),"Current負価格")
    for name in ("buy","sell"):
        flag(current[name]["ofi_known"])
    night=current["night"];band=night["band"]
    flag(night["available"]);flag(band["quantity_known"])
    for owner,fields in ((night,("index",)),(band,("index","start_index"))):
        for name in fields:need(integer(owner[name],"夜間"+name)<=index,"夜間の源連番が未来")
    for hold in (night["buy"],night["sell"]):
        for owner in (hold,hold["barrier"],hold["support"]):need(integer(owner["index"],"保持帯Index")<=index,"保持帯の源連番が未来")
        need(integer(hold["pressure_index"],"保持帯PressureIndex")<=index,"保持帯圧力連番が未来")
    need(all(f(band[n])>=0 for n in ("common_bid_up","common_ask_up","common_bid_down","common_ask_down")),"負の共通価格数量成分")


def validate(incoming,side):
    """
    機能: candidateなしで保有専用の入力/品質を検査する。
    引数: incoming(dict)は固定96公開Input全値、side(int)は実保有方向±1。
    返り値: None。金融active/free、QuoteOK、金融最新Quoteは受け取らない。
    """
    PUBLIC.finite_tree(incoming)
    need(type(side) is int and side in (-1,1),"実保有方向")
    at=f(incoming["at"]);chart=incoming["chart"];scene=chart["scene"]
    need(type(incoming["snapshot_id"]) is str and incoming["snapshot_id"] and at>0 and f(chart["at"])==at,"保有判断ID/時計")
    need(incoming["kind"] in ("Day","Night") and type(scene["id"]) is str and scene["id"] and type(scene["contract"]) is str and scene["contract"] and f(scene["start"])>0,"保有の場/限月")
    validate_snapshot(chart,at);validate_current(incoming["current"],at)
    recent=incoming["recent3"]
    need(recent is None or type(recent) is list,"直近公開足の配列型")
    recent=recent or [];need(len(recent)<=3,"直近公開足は最大3")
    previous=None
    for point in recent:
        validate_snapshot(point,at)
        need(point["scene"]==scene and f(point["at"])==f(point["three"]["bar_end"]) and (previous is None or f(point["at"])>previous),"直近足の場/公開順")
        previous=f(point["at"])


def assess(incoming,side):
    """
    機能: 価格/勢い/量の保有方向へのstrict反対を独立計算する。
    引数: incoming(dict)は公開値、side(int)は±1。Go判断/期待checkは入力しない。
    返り値: dictはdecision/checks/evidence全値。原入力を変更しない。
    """
    validate(incoming,side)
    at=f(incoming["at"]);current=incoming["current"];snapshot=incoming["chart"];technical=snapshot["chart"]["Technical"]
    time=f(current["time"]);end=f(technical["bar3_end"])
    price_known=bool(current["reference"]=="NK225" and time>0 and current["source_index"]>=0 and current["source_line"]>0 and f(current["last"])>0 and 0<f(current["bid"])<f(current["ask"]) and at-time<=15)
    three_known=bool(snapshot["three"]["data_known"] and end>0 and at-end<180)
    role_known=bool(three_known and technical["exit_known"])
    signed_price=float(side)*(f(technical["close3"])-f(technical["ema8_3"])) if role_known else None
    signed_momentum=float(side)*(f(technical["histogram3"])-f(technical["previous_histogram3"])) if role_known else None
    # ----------------------------------------
    # 日中OFIと夜間四量差の値/出典を別定義で作る。
    quantity={"kind":incoming["kind"],"known":False,"time":0.0,"index":0,"own_at":0.0,"value":None,
              "bid_refill":None,"ask_refill":None,"bid_deplete":None,"ask_deplete":None}
    raw_quantity=0.0
    if incoming["kind"]=="Day":
        support=current["buy" if side==1 else "sell"]
        quantity.update(time=time,index=current["source_index"],own_at=f(support["own_at"]))
        quantity_known=bool(price_known and support["ofi_known"] and f(support["own_at"])==time)
        raw_quantity=f(support["ofi30"])
    else:
        night=current["night"];band=night["band"]
        quantity.update(time=f(band["time"]),index=band["index"])
        quantity_known=bool(price_known and night["available"] and night["window"]=="E08" and band["quantity_known"] and f(band["time"])==time and band["index"]==current["source_index"])
        if quantity_known:
            raw_quantity=f(band["bid_refill"])+f(band["ask_deplete"])-f(band["ask_refill"])-f(band["bid_deplete"])
            quantity.update({name:f(band[name]) for name in ("bid_refill","ask_refill","bid_deplete","ask_deplete")})
    quantity["known"]=quantity_known
    signed_quantity=float(side)*raw_quantity if quantity_known else None
    if quantity_known:quantity["value"]=raw_quantity
    evidence={"scene_id":snapshot["scene"]["id"],"contract":snapshot["scene"]["contract"],
              "current":{n:copy.deepcopy(current[n]) for n in ("reference","time","received","source_index","source_line","last","bid","ask")},
              "price_age":at-time if time>0 else None,"three_age":at-end if end>0 else None,"three":copy.deepcopy(snapshot["three"]),
              "quantity":quantity,"signed_close_ema":signed_price,"signed_histogram_delta":signed_momentum,"signed_quantity":signed_quantity}
    PUBLIC.finite_tree(evidence);need(math.isfinite(raw_quantity),"派生量の非有限")
    # ----------------------------------------
    # 既知否定を優先し、未知を0/既知不成立へ変えない。
    definitions=(
        ("X5.現在価格時計",price_known,True,"Currentの正常BBO/Last正・価格時計15秒以内。金融最新Quoteとの外部bindは別責務"),
        ("X5.公開3分",three_known,True,"当場の既知確定3分・公開済み・足齢180秒未満"),
        ("X5.P",role_known,role_known and signed_price<0,"保有方向付きClose3-同足EMA8_3がstrict負・等号は不成立"),
        ("X5.M",role_known,role_known and signed_momentum<0,"保有方向付き3分hist増分がstrict負・水準0交差は不要"),
        ("X5.Q",quantity_known,quantity_known and signed_quantity<0,"同Current出典のDay OFI30又はNight E08差が保有方向へstrict負・約定量ではない"))
    checks=[{"id":name,"known":known,"passed":bool(known and passed),"reason":reason} for name,known,passed,reason in definitions]
    denied=any(x["known"] and not x["passed"] for x in checks)
    all_known=all(x["known"] for x in checks)
    known=bool(denied or all_known);allowed=bool(all_known and not denied)
    role,reason=("複合失効","価格・勢い・現在量の反対状態が成立") if allowed else (("追加退出なし","公開済みの必要条件が不成立") if known else ("判定不能","既知の否定条件はなく必要な公開値が未知"))
    decision={"policy":"X5","snapshot_id":incoming["snapshot_id"],"at":at,"side":side,"known":known,"allowed":allowed,"role":role,"reason":reason}
    return {"decision":decision,"checks":checks,"evidence":evidence}
