"""停止した完全Tape/stream人工だけを新12金融と旧P0へ独立配送する。"""

from collections import Counter
import copy
import gzip
import hashlib
import importlib.util
import re
from pathlib import Path
import sys
import types


ROOT = Path(__file__).resolve().parents[2]
SHORT_PATH = ROOT / 'work/短秒複合退出の金融の独立確認/短秒と金融の照合.py'
SHORT_SHA = '931cb8a0c425c91fc57cc2af20ca96ba19c6c6693827f2351f681fce3623a5c4'
READER_PATH = ROOT / 'work/101連続入力の読取照合/読み戻しを照合する.py'
READER_SHA = '00d8c55f12a43e31be3857feadae9373ac53901efcbbeff394fb0eef27543345'
RUNTIME_STOP = ROOT / 'work/短秒複合退出の再生/停止.json'
RUNTIME_SHA = 'ff571dba63a439e9df2fc855f722da1e506ee26cc1ef483de9aa4356e39e2eb7'


def digest(path):
    """
    機能: 明示したコード/人工の指紋を得る。
    引数: path(Path)は対象。
    返り値: strはSHA256。市場を探索しない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fixed(name, path, expected):
    """
    機能: 停止済み金融/辞書復元だけを内容SHAで読み込む。
    引数: name/expected(str)、path(Path)はmodule名・指紋・コード。
    返り値: moduleは固定Python部品。
    """
    if digest(path) != expected:
        raise ValueError('固定コードSHA差: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


SHORT = fixed('固定S金融931_完全接続', SHORT_PATH, SHORT_SHA)
READER = fixed('固定辞書GoJSON00d8_完全接続', READER_PATH, READER_SHA)
if digest(RUNTIME_STOP) != RUNTIME_SHA:
    raise ValueError('runtime停止SHA差')
OLD, BASE, TAPE, Audit = SHORT.OLD, SHORT.BASE, SHORT.TAPE, SHORT.Audit
KEYS, P0_KEYS = SHORT.KEYS, SHORT.KEYS[:4]
CALLBACK_KEYS = {'key', 'ordinal', 'source', 'candidate', 'assessment'}


class Entries(OLD.ENTRY.RecomputedGates):
    """現在の公開E3Sを全本名keyへ独立計算する。"""

    def __init__(self, contexts, books, records, audit, keys):
        """
        機能: 固定99入口のconstructorだけを新key集合へ限定適用する。
        引数: contexts/records(list)、books(dict)、audit(Audit)、keys(tuple)は全入力と許可key。
        返り値: None。純式/候補/Sourceの式は変更しない。
        """
        normalized = copy.deepcopy(contexts)
        for context in normalized:
            if context['recent3'] is None:
                context['recent3'] = []
        namespace = dict(OLD.ENTRY.__dict__, KEYS=keys)
        constructor = types.FunctionType(OLD.ENTRY.RecomputedGates.__init__.__code__, namespace)
        constructor(self, normalized, {'books': books, 'chart_grids': normalized, 'gate_assessments': records}, audit)

    def claim(self, key, opportunity):
        """
        機能: 固定99の候補/採否計算へGo nil Recent3だけ型対応する。
        引数: key(str)、opportunity(dict)は独立金融候補。
        返り値: dictは実E3S Decision。元Input/保存出力はnullのまま保持する。
        """
        namespace = dict(OLD.ENTRY.__dict__, PURE=types.SimpleNamespace(assess=entry_assess))
        method = types.FunctionType(OLD.ENTRY.RecomputedGates.claim.__code__, namespace)
        return method(self, key, opportunity)


def entry_assess(incoming, candidate, policy):
    """
    機能: Go合法nil sliceを固定Python公開validatorの空listへ値copyで対応する。
    引数: incoming/candidate(dict)、policy(str)は当時の公開Inputと実候補。
    返り値: dictは固定c84のE3S全check。閾値/三値式は変更しない。
    """
    value = copy.deepcopy(incoming)
    if value['recent3'] is None:
        value['recent3'] = []
    return OLD.PURE.assess(value, candidate, policy)


def go_sha(value):
    """
    機能: 既存独立Go JSON表現器で保存公開値の内容SHAを得る。
    引数: value(object)は明示された公開JSON。
    返り値: strはSHA256。新しい技法数値は計算しない。
    """
    return hashlib.sha256(READER.go_json(value).encode('utf-8')).hexdigest()


def restore_inputs(header, records, tape, audit, expected_contract):
    """
    機能: 手製streamを旧Scalar/gridと結び当原行Inputを復元する。
    引数: header/tape(dict)、records(list)、audit(Audit)、expected_contract(str)は公開人工と外部期待限月。
    返り値: tuple[dict,dict]はTapeOrdinal→Inputと件数。自然Bank更新は推定しない。
    """
    audit.need(header['version'] == 1 and header['streamed'] is True
               and header['rows'] is None and header['trace'] is None
               and header['source_reexecuted'] is False and header['financial_executed'] is False
               and header['features_recomputed'] is False and header['charts_recomputed'] is False,
               '手製stream header/非生成scope')
    BASE.compare_tree(header['session'], tape['session'], audit, 'header/Tapeの場')
    audit.equal(header['legacy_tape_canonical_sha256'], go_sha(tape), '旧Tape内容SHA')
    for key, payload in header['chart_payloads'].items():
        audit.equal(set(payload), {'scene', 'chart', 'three', 'fifteen', 'carried_numeric_seed'}, '全payload')
        audit.equal(key, go_sha(payload), '辞書内容SHA')
    expected_grids = [event for event in tape['events'] if event['kind'] == 'grid']
    BASE.compare_tree(header['grids'], [event['context'] for event in expected_grids], audit, '旧全grid Input')
    BASE.compare_tree(header['legacy_bindings'], [dict(tape_ordinal=event['ordinal'], kind='grid', sidecar_ordinal=i)
                                                for i, event in enumerate(expected_grids, 1)], audit, '旧grid binding')
    expected_quotes = [event for event in tape['events'] if event['kind'] == 'quote']
    row_count, grid_count, merge, last_ordinal, last_at = 0, 0, 0, 0, 0
    all_index, feature_index, last_line = Counter(), Counter(), {}
    incoming, counts = {}, Counter()
    for record in records:
        row, control = record.get('row'), record.get('control')
        audit.need((row is not None) != (control is not None), 'stream record排他')
        if row is not None:
            audit.equal(set(record), {'kind', 'row', 'tape_ordinal'}, 'row全tag')
            audit.equal(record['kind'], 'row', 'row種別')
            audit.equal(set(row), {'positive_nk_ordinal', 'identity', 'scalar', 'current', 'chart_state', 'recent3_refs'}, 'RawContext全tag')
            identity, at = row['identity'], row['scalar']['time']
            snapshot = READER.materialize(header, row['chart_state'])
            audit.need(row_count < len(expected_quotes), '余剰原行禁止')
            event = expected_quotes[row_count]
            row_count += 1
            audit.equal(record['tape_ordinal'], event['ordinal'], '原行旧ordinal')
            audit.need(record['tape_ordinal'] > last_ordinal and row['positive_nk_ordinal'] == row_count, '原行順/正NK連番')
            BASE.compare_tree(row['scalar'], event['quote'], audit, '旧Scalar11全文')
            q, _ = TAPE.scalar_quote(row['scalar'], audit)
            audit.equal(identity['market'], 'NK225', '正NK専用row')
            audit.equal(identity['features_index'], feature_index['NK225'], 'Features連番')
            audit.equal(identity['features_index'], q['index'], 'ScalarのFeatures連番')
            feature_index['NK225'] += 1
            audit.equal(set(identity), {'market', 'time', 'physical_line', 'market_all_index', 'features_index', 'merge_ordinal'}, '全原行出典')
            audit.equal(identity['physical_line'], q['source_line'], '物理行')
            stamp = snapshot['last_input']
            audit.need(snapshot['has_last_input'] is True and stamp['valid'] is True
                       and stamp['time'] == q['time'] and stamp['index'] == identity['market_all_index']
                       and stamp['line'] == q['source_line'] and stamp['last'] == q['last'], 'Chart全受理源とScalar別index')
            expected_current = dict(reference='NK225', time=q['time'], received=row['scalar']['received'],
                                    source_index=q['index'], source_line=q['source_line'], last=q['last'], bid=q['bid'], ask=q['ask'])
            for name, value in expected_current.items():
                audit.equal(row['current'][name], value, 'Current同Scalar: ' + name)
            refs = row['recent3_refs']
            audit.need(refs is None or type(refs) is list and len(refs) <= 3, 'Recent3型/上限')
            recent = None if refs is None else [READER.materialize(header, state) for state in refs]
            for i, value in enumerate(recent or []):
                BASE.compare_tree(value['scene'], snapshot['scene'], audit, 'Recent3場/限月')
                audit.need(value['at'] == value['three']['bar_end'] and value['at'] <= at
                           and (i == 0 or value['at'] > recent[i-1]['at']), 'Recent3当時/未来/順序')
            frame = dict(snapshot_id=tape['session']['id'] + '-R' + str(row_count), at=at,
                         kind=tape['session']['kind'], chart=snapshot, recent3=recent, current=copy.deepcopy(row['current']))
            incoming[event['ordinal']] = frame
            last_ordinal = event['ordinal']
            counts['rows'] += 1
        else:
            audit.need(set(record) <= {'kind', 'control', 'tape_ordinal'} and record['kind'] == 'control', 'control全tag')
            audit.need(set(control) <= {'kind', 'at', 'identity', 'chart_state'}, 'Trace全tag')
            kind, at = control['kind'], control['at']
            snapshot = READER.materialize(header, control['chart_state'])
            identity = control.get('identity')
            if kind == 'grid':
                audit.need(identity is None and grid_count < len(expected_grids), 'grid control集合')
                event = expected_grids[grid_count]
                audit.need(record['tape_ordinal'] == event['ordinal'] and event['ordinal'] > last_ordinal
                           and at == event['at'], 'grid旧順序')
                BASE.compare_tree(snapshot, event['context']['chart'], audit, 'grid公開Chart全文')
                last_ordinal = event['ordinal']
                grid_count += 1
                counts['grids'] += 1
            else:
                audit.need(kind in ('raw', 'publication') and record.get('tape_ordinal', 0) == 0, '非grid control種別/ordinal')
                if kind == 'raw':
                    audit.need(identity is not None and identity['features_index'] is None, '手製Last0の非Source性')
                    stamp = snapshot['last_input']
                    audit.need(snapshot['has_last_input'] is True and stamp['valid'] is False and stamp['last'] <= 0
                               and stamp['time'] == at and stamp['index'] == identity['market_all_index']
                               and stamp['line'] == identity['physical_line'], 'Last0 control全受理源')
                    counts['last0_controls'] += 1
                else:
                    audit.need(identity is None, '公表に物理出典混入なし')
            counts['controls'] += 1
        audit.need(BASE.finite(at) and at >= last_at and snapshot['at'] == at and snapshot['sealed'] is False,
                   'record当時時計/非Seal')
        BASE.compare_tree(snapshot['scene'], dict(id=tape['session']['id'], start=tape['session']['start'],
                                                 contract=expected_contract), audit, '全recordの外部場/限月')
        SHORT.PURE.X5.PUBLIC.finite_tree(snapshot)
        if identity is not None:
            market = identity['market']
            audit.need(market in ('NK225', 'TOPIX') and identity['time'] == at, 'raw市場/時計')
            audit.equal(identity['market_all_index'], all_index[market], '市場全行連番')
            all_index[market] += 1
            merge += 1
            audit.equal(identity['merge_ordinal'], merge, 'merge連番')
            audit.need(identity['physical_line'] > last_line.get(market, 0), '同秒もstrict物理行')
            last_line[market] = identity['physical_line']
        last_at = at
    audit.need(row_count == header['row_count'] == len(expected_quotes)
               and grid_count == len(header['grids']) and len(records) == header['trace_count'], '全record集合')
    counts['records'] = len(records)
    audit.need(counts['last0_controls'] == 1, '本人工の手製Last0 prefix1')
    return incoming, counts


def inspect_values(value, records, expected_contract='人工限月', source_original=None):
    """
    機能: 完全人工の新12と旧100P0四を公開入力から独立再構成する。
    引数: value(dict)、records(list)、expected_contract(str)、source_original(dict|None)は停止artifact/復号列/外部期待限月/元公開API。
    返り値: dictは一鏡像の新12と旧4の検査結果。実市場は扱わない。
    """
    before = TAPE.canonical({'value': value, 'records': records})
    audit = Audit()
    audit.equal(set(value), {'scope', 'tape', 'header', 'stream_sha256', 'header_canonical_sha256', 'output',
                             'baseline100_p0_api', 'field_exclusions', 'p0_all_points_equal', 'stops'}, '完全接続artifact全tag')
    audit.need(value['scope'] == '手製Source/Chart/Current/短秒の型接続。市場/自然生成未検査'
               and value['tape']['scope'].startswith('固定短秒Go型人工')
               and not value['tape'].get('provenance'), '完全人工scope')
    audit.equal(value['stops'], {'builder': 'e2901b5a4d0207bb86fb1af579cdc824d8e94cd3d37654ead732ec5a28732869',
                                'finance': SHORT.FINANCE_SHA,
                                'pure': '0e2e50bc391586daf0040cb9abab2b388b3f9ff23980d50d4f0e50eaa3580f9e'}, '元停止由来')
    output, tape, header = value['output'], value['tape'], value['header']
    audit.equal(set(tape), {'version', 'scope', 'session', 'capabilities', 'events'}, 'Tape全tag')
    audit.equal(tape['version'], 1, 'Tape版')
    audit.equal(tape['capabilities'], TAPE.CAPABILITIES, '固定Source/Scalarの対応範囲')
    audit.equal(set(output), {'scope', 'replay_passes', 'result', 'gate_assessments', 'short_assessments',
                              'stream_passes', 'source_reexecuted', 'features_recomputed', 'charts_recomputed'}, '新output全tag')
    audit.need(output['replay_passes'] == 3 and output['source_reexecuted'] is False
               and output['features_recomputed'] is False and output['charts_recomputed'] is False,
               '3pass/非生成')
    audit.equal(output['scope'], tape['scope'], 'output/Tape scope')
    audit.equal(value['header_canonical_sha256'], go_sha(header), 'header全内容SHA')
    frames, stream_counts = restore_inputs(header, records, tape, audit, expected_contract)
    books = output['result']['books']
    audit.equal(set(output['result']), {'books', 'state_sha256', 'gate_callbacks'}, 'RunResult全tag')
    audit.equal(set(books), set(KEYS), '新12本名key')
    for key, book in books.items():
        BASE.compare_tree(book['session'], tape['session'], audit, key + '/全場時計')
        audit.need(book['finished'] is True and book['complete'] is True and book['failure'] == '', '新全12の正常完結')
    contexts = [event['context'] for event in tape['events'] if event['kind'] == 'grid']
    entries = Entries(contexts, books, output['gate_assessments'], audit, KEYS)
    models = [SHORT.ShortPath(books[key], audit, entries, expected_contract) for key in KEYS]
    baseline = value['baseline100_p0_api']
    audit.equal(set(baseline), {'books', 'state_sha256', 'gate_callbacks'}, '旧100P0 RunResult全tag')
    audit.equal(set(baseline['books']), set(P0_KEYS), '旧P0四')
    for key, book in baseline['books'].items():
        BASE.compare_tree(book['session'], tape['session'], audit, key + '/旧P0場時計')
        audit.need(book['finished'] is True and book['complete'] is True and book['failure'] == '', '旧P0全4の正常完結')
    base_records = [record for record in output['gate_assessments'] if record['key'] in P0_KEYS]
    base_entries = Entries(contexts, baseline['books'], base_records, audit, P0_KEYS)
    controls = [OLD.ProtectionPath(baseline['books'][key], audit, base_entries) for key in P0_KEYS]
    held, clocks, kinds, last_lines = [], [], Counter(), {}
    previous = 0
    if source_original is not None:
        audit.equal(len(tape['events']), len(source_original['calls']), '元S API全呼出集合')
    for ordinal, event in enumerate(tape['events'], 1):
        audit.need(type(event['ordinal']) is int and event['ordinal'] == ordinal and event['at'] >= previous,
                   '全Tape呼出順')
        audit.need(set(event) <= {'ordinal', 'kind', 'at', 'quote', 'methods', 'non_empty', 'context'}, 'Tape event全tag')
        previous = event['at']
        kind = event['kind']
        kinds[kind] += 1
        original = None if source_original is None else source_original['calls'][ordinal-1]
        if original is not None:
            audit.equal((kind, event['at']), (original['kind'], original['at']), '元Source時計/種別不変')
        if kind in ('quote', 'force'):
            batches = TAPE.restore_batches(event, last_lines, audit)
            if original is not None:
                BASE.compare_tree(batches, original['batches'], audit, '元S APIのSource通知全field')
            if kind == 'quote':
                q, atr = TAPE.scalar_quote(event['quote'], audit)
                if original is not None:
                    old_q, old_atr = BASE.observation_quote(original['observation'], original['line'])
                    BASE.compare_tree(q, old_q, audit, '元S APIのScalar金融7field')
                    BASE.compare_tree(atr, old_atr, audit, '元S APIの公開ATR全field')
                    audit.equal(event['quote']['received'], original['observation']['Received'], '元Received不変')
                    BASE.compare_tree(frames[ordinal]['current'], original['input']['current'], audit, '元S APIのRaw Current全文')
                for model in models:
                    if model.short_policy:
                        candidates, assessments = model.short_step(q, batches, atr, frames[ordinal], event['quote']['received'])
                        held.extend(dict(key=model.key, candidate=candidate, assessment=assessment)
                                    for candidate, assessment in zip(candidates, assessments))
                    else:
                        model.step(q, batches, atr)
                for model in controls:
                    model.step(q, batches, atr)
            else:
                audit.need('quote' not in event and 'context' not in event, 'Forceに架空気配/Inputなし')
                for model in models + controls:
                    model.timer(event['at'], batches)
        elif kind == 'grid':
            audit.need('quote' not in event and not event.get('methods') and not event.get('non_empty'), 'gridに架空Sourceなし')
            entries.begin_grid(event['context'], models[0].last)
            base_entries.begin_grid(event['context'], controls[0].last)
            for model in models + controls:
                model.grid(event['at'])
            clocks.append(event['at'])
        else:
            raise ValueError('未知Tape種別')
    details = [model.finish() for model in models]
    old_details = [model.finish() for model in controls]
    gate_counts, base_gate_counts = entries.finish(clocks), base_entries.finish(clocks)
    rank = {key: i for i, key in enumerate(KEYS)}
    held.sort(key=lambda record: (record['candidate']['at'], rank[record['key']]))
    BASE.compare_tree(output['short_assessments'], held, audit, '実held全recordの独立候補/純式')
    BASE.compare_tree(output['result']['gate_callbacks'], gate_counts['口座別'], audit, '新全入口callback計数')
    BASE.compare_tree(baseline['gate_callbacks'], base_gate_counts['口座別'], audit, '旧P0全入口callback計数')
    audit.need(value['field_exclusions'] == [] and value['p0_all_points_equal'] is True, 'Go空P0の除外0対照metadata')
    for key in P0_KEYS:
        BASE.compare_tree(books[key], baseline['books'][key], audit, key + '/新旧P0全JSON対照')
        audit.equal(output['result']['state_sha256'][key], baseline['state_sha256'][key], 'GoP0全時点SHA鎖の新旧一致')
    audit.equal(set(output['result']['state_sha256']), set(KEYS), '新全時点SHA鎖key集合')
    audit.need(all(type(sha) is str and re.fullmatch('[0-9a-f]{64}', sha)
                   for sha in output['result']['state_sha256'].values()), '全時点SHAの型')
    expected_passes = [dict(policy=policy, rows=stream_counts['rows'], controls=stream_counts['controls'],
                            grids=stream_counts['grids'], compressed_sha256=value['stream_sha256'],
                            header_canonical_sha256=value['header_canonical_sha256'], shared_actors=4)
                       for policy in ('S5Q', 'S515Q')]
    BASE.compare_tree(output['stream_passes'], expected_passes, audit, 'S各一巡/同Input4口座の記録')
    audit.equal(TAPE.canonical({'value': value, 'records': records}), before, '完全接続の入力前後不変')
    return {'成功': True, '新会計数': 12, '非0新会計数': sum(row['positions'] > 0 for row in details),
            '旧100P0独立全文会計': 4, '新P0独立全文会計': 4, 'P0除外': [], '照合項目数': audit.checks,
            '不一致数': 0, 'stream': dict(stream_counts), 'Tape': dict(kinds), '入口': gate_counts,
            '旧P0入口': base_gate_counts, 'S callback': len(held), 'details': details, '旧P0': old_details,
            '全金融MTM/Source/費用/予約/遅延': True, 'Go全時点SHAのPython再計算': False,
            '元S16Source/Scalar/Current全文照合': source_original is not None,
            'scope': '手製Source/ATR/Chartの完全Input人工。入口E3SとS退出は実純式。自然形成/市場ではない。'}


def inspect_file(path, stream_path):
    """
    機能: 明示した停止人工JSON/gzipをSHA確認して接続する。
    引数: path/stream_path(Path)は公開人工2ファイル。
    返り値: dictは新12/旧4の独立結果。市場ファイルへ使わない。
    """
    value = READER.loads(path.read_text(encoding='utf-8'))
    before = {str(p): digest(p) for p in (path, stream_path)}
    if before[str(stream_path)] != value['stream_sha256']:
        raise ValueError('人工stream圧縮SHA差')
    with gzip.open(stream_path, 'rt', encoding='utf-8') as stream:
        records = [READER.loads(line) for line in stream]
    match = re.fullmatch(r'方向(-?1)', path.stem)
    if match is None:
        raise ValueError('停止鏡像人工の名前だけ')
    original_path = SHORT.FINANCE_STOP.parent / '人工/公開型16' / ('方向' + match[1] + '_S5Q_C0_D0.json')
    finance_stop = READER.loads(SHORT.FINANCE_STOP.read_text(encoding='utf-8'))
    expected = finance_stop['全所有SHA256'][str(original_path.relative_to(SHORT.FINANCE_STOP.parent))]
    if digest(original_path) != expected:
        raise ValueError('元S API出典のSHA差')
    before[str(original_path)] = expected
    source = READER.loads(original_path.read_text(encoding='utf-8'))
    result = inspect_values(value, records, source_original=source)
    if before != {name: digest(Path(name)) for name in before}:
        raise ValueError('完全人工の前後SHA差')
    return result
