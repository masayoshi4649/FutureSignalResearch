package shortmarket101

import (
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"regexp"
	"sort"

	port "github.com/masayoshi4649/SessionTradeExecuter/actorport97"
	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	runtime "github.com/masayoshi4649/SessionTradeExecuter/shortport101"
)

const wrapperHome = "work/短秒複合退出の市場接続"
const study100 = "study/00100_費用後利益化の前後で保護を分ける"

type trust struct {
	proof, runtime, finance, pure, builder, scope string
	coreCount, postCount                          int
	self                                          []string
	exe                                           func() (string, error)
	sidecarScope                                  string
	recomputed                                    bool
	first2                                        []string
}

// first2IDs はCLI固定2場又はprivate人工の縮小集合を返します。
//
// 引数: profile(trust)は外部から変更できない規範です。
// 返り値: []stringは先頭集合です。人工profileの指定口はCLIへ公開しません。
func first2IDs(profile trust) []string {
	if profile.first2 != nil {
		return profile.first2
	}
	return []string{"2026-09-21_Day", "2026-09-21_Night"}
}

// validateIndex は本番の停止validatorを使い、人工の縮小集合だけを分離します。
//
// 引数: index(port.TapeIndex)、stage(string)、allowed(map[string]string)、profile(trust)です。
// 返り値: errorは版/集合/指紋破損です。
func validateIndex(index port.TapeIndex, stage string, allowed map[string]string, profile trust) error {
	if profile.first2 == nil || stage != "first2" {
		return port.ValidateIndex(index, stage, allowed)
	}
	if index.Version != 1 || index.Stage != stage || len(index.Entries) != len(profile.first2) {
		return fmt.Errorf("人工縮小集合差")
	}
	ids := map[string]bool{}
	for _, id := range profile.first2 {
		ids[id] = true
	}
	for _, e := range index.Entries {
		if !ids[e.Session] || e.Path == "" || !validSHA(e.SHA256) {
			return fmt.Errorf("人工縮小集合/指紋差")
		}
		delete(ids, e.Session)
	}
	return nil
}

// productionTrust はCLIで変更できない元停止と固定100を返します。
//
// 引数: ありません。
// 返り値: trustは本番wrapper専用のmetadata規範です。人工の置換profileは公開しません。
func productionTrust() trust {
	return trust{proof: runtime.Proof100SHA256, runtime: "ff571dba63a439e9df2fc855f722da1e506ee26cc1ef483de9aa4356e39e2eb7", finance: runtime.FinanceStopSHA256, pure: runtime.PureStopSHA256, builder: runtime.BuilderStopSHA256, scope: "Root固定条件の旧100/Tape/連続sidecar金融接続", coreCount: 236, postCount: 5, self: OwnedPaths(), exe: os.Executable, sidecarScope: "固定100と旧Tapeの連続技法sidecar構築", recomputed: true}
}

// OwnedPaths は停止が省略できないwrapperの本文を返します。
//
// 引数: ありません。
// 返り値: []stringはrepo相対の必須所有ファイルです。停止/条件自体は別参照にします。
func OwnedPaths() []string {
	names := []string{"types.go", "io.go", "guard.go", "scene.go", "batch.go", "market_test.go", "go.mod", "go.sum", "cmd/run/main.go", "README.md"}
	out := []string{}
	for _, n := range names {
		out = append(out, wrapperHome+"/"+n)
	}
	return out
}

type stopInfo struct {
	Success      bool              `json:"成功"`
	Required     map[string]string `json:"必須コードSHA256"`
	Dependencies map[string]string `json:"Go依存SHA256"`
	Code         map[string]string `json:"コードSHA256"`
	Owned        map[string]string `json:"所有コードSHA256"`
	Exe          FileRef           `json:"exe"`
	Runtime      string            `json:"runtime停止SHA256"`
	Finance      string            `json:"金融停止SHA256"`
	Pure         string            `json:"純式停止SHA256"`
	Builder      string            `json:"builder停止SHA256"`
}
type closure struct {
	Trial    int               `json:"試行"`
	Complete bool              `json:"比較保存完了"`
	Scenes   int               `json:"場数"`
	Files    map[string]string `json:"自己を除く正式指紋"`
	Core     map[string]string `json:"固定金融/監査236"`
	Post     map[string]string `json:"後処理コードSHA256"`
}
type sidecarDetail struct {
	Session      string `json:"session"`
	Path         string `json:"path"`
	SHA256       string `json:"SHA256"`
	Header       string `json:"header"`
	HeaderSHA256 string `json:"header_SHA256"`
}
type sidecarProof struct {
	Success   bool              `json:"成功"`
	Scope     string            `json:"scope"`
	Stage     string            `json:"stage"`
	Proof     string            `json:"固定100完了SHA256"`
	Sessions  []string          `json:"sessions"`
	Code      map[string]string `json:"所有コードSHA256"`
	Unchanged bool              `json:"前後不変"`
	Source    *bool             `json:"source_reexecuted"`
	Financial *bool             `json:"financial_executed"`
	Features  *bool             `json:"features_recomputed"`
	Charts    *bool             `json:"charts_recomputed"`
	Details   []sidecarDetail   `json:"details"`
}
type scenePlan struct {
	Session                       string
	Tape, Native, Header, Records FileRef
}
type plan struct {
	Root, Output, ConditionSHA string
	Condition                  Condition
	Before                     map[string]string
	Scenes                     []scenePlan
	Receipt                    FileRef
	Profile                    trust
}

// sameMaps はpath/SHA宣言の全集合を比較します。
//
// 引数: a/b(map[string]string)はRoot固定値です。
// 返り値: boolは欠落・追加・異値がない場合に真です。
func sameMaps(a, b map[string]string) bool { return reflect.DeepEqual(a, b) }

// addVerified は現在指紋を検査して前後対象へ加えます。
//
// 引数: before(map[string]string)、base(string)、ref(FileRef)は固定宣言です。
// 返り値: FileRef/errorは絶対path/同SHA又はIO不整合です。
func addVerified(before map[string]string, base string, ref FileRef) (FileRef, error) {
	r, err := verify(base, ref)
	if err == nil {
		if old, ok := before[r.Path]; ok && old != r.SHA256 {
			return r, fmt.Errorf("同pathの異なる指紋")
		}
		before[r.Path] = r.SHA256
	}
	return r, err
}

// requireCode は停止に記録した全本文を条件codeへ結びます。
//
// 引数: root/home(string)、declared/required(map[string]string)は2種のpath基準です。
// 返り値: errorは省略又は同pathの異値です。コードの本文を変更しません。
func requireCode(root, home string, declared, required map[string]string) error {
	byPath := map[string]string{}
	for k, v := range declared {
		p, err := resolve(root, k)
		if err != nil || !validSHA(v) {
			return fmt.Errorf("code宣言が不正")
		}
		if old, ok := byPath[p]; ok && old != v {
			return fmt.Errorf("code aliasの異値")
		}
		byPath[p] = v
	}
	for k, v := range required {
		p, err := resolve(home, k)
		if err != nil || !validSHA(v) || byPath[p] != v {
			return fmt.Errorf("必要なcode指紋が条件にない: %s", k)
		}
	}
	return nil
}

// prepare は固定条件/停止/集合を確認し、最後に対象本文の指紋だけを検査します。
//
// 引数: args(Arguments)、profile(trust)はCLI宣言と変更不可の規範です。
// 返り値: plan/errorは新規出力前の完全計画又は拒否です。Source/Rawを読みません。
func prepare(args Arguments, profile trust) (plan, error) {
	p := plan{Before: map[string]string{}, Profile: profile}
	if args.Root == "" || args.Condition == "" || !validSHA(args.ConditionSHA256) || args.Output == "" || (args.Stage != "first2" && args.Stage != "full54") || args.Workers < 1 || args.Workers > 4 {
		return p, fmt.Errorf("必須引数/未固定condition-sha/worker不正")
	}
	var err error
	p.Root, err = filepath.Abs(args.Root)
	if err != nil {
		return p, err
	}
	p.Output, err = filepath.Abs(args.Output)
	if err != nil {
		return p, err
	}
	if _, err = os.Stat(p.Output); !os.IsNotExist(err) {
		return p, fmt.Errorf("出力は未使用dirだけです")
	}
	conditionRef, err := addVerified(p.Before, ".", FileRef{Path: args.Condition, SHA256: args.ConditionSHA256})
	if err != nil {
		return p, err
	}
	base := filepath.Dir(conditionRef.Path)
	p.ConditionSHA = args.ConditionSHA256
	if err = readJSON(conditionRef.Path, &p.Condition); err != nil {
		return p, err
	}
	c := &p.Condition
	if c.Trial != 101 || c.Version != 1 || !c.Fixed || !reflect.DeepEqual(c.Keys, runtime.Keys()) || len(c.Code) == 0 || len(c.Dependencies) == 0 || len(c.Stages) != 2 {
		return p, fmt.Errorf("Root試行101条件が未固定/12key/完全code不明")
	}
	refs := []struct {
		field *FileRef
		pin   string
	}{{&c.Proof100, profile.proof}, {&c.Allowed54, ""}, {&c.WrapperStop, ""}, {&c.RuntimeStop, profile.runtime}, {&c.FinanceStop, profile.finance}, {&c.PureStop, profile.pure}, {&c.BuilderStop, profile.builder}, {&c.Exe, ""}}
	for _, r := range refs {
		if r.pin != "" && r.field.SHA256 != r.pin {
			return p, fmt.Errorf("固定100/停止SHAの取り違え")
		}
		*r.field, err = addVerified(p.Before, base, *r.field)
		if err != nil {
			return p, err
		}
	}
	var own stopInfo
	if err = readJSON(c.WrapperStop.Path, &own); err != nil {
		return p, err
	}
	expectedCode := map[string]string{}
	for k, v := range own.Required {
		expectedCode[k] = v
	}
	for _, stage := range []string{"first2", "full54"} {
		s, ok := c.Stages[stage]
		if !ok || s.SchemaVersion != 1 {
			return p, fmt.Errorf("両stageのproducer/schema宣言が必要")
		}
		s.ProducerStop, err = addVerified(p.Before, base, s.ProducerStop)
		if err != nil {
			return p, err
		}
		var producer stopInfo
		if err = readJSON(s.ProducerStop.Path, &producer); err != nil || !producer.Success || len(producer.Owned) == 0 || !sameMaps(s.ProducerCode, producer.Owned) {
			return p, fmt.Errorf("入力producer停止/全code差")
		}
		for k, v := range s.ProducerCode {
			if prior, ok := expectedCode[k]; ok && prior != v {
				return p, fmt.Errorf("producer/consumerの同path異版混在")
			}
			expectedCode[k] = v
		}
		c.Stages[stage] = s
	}
	if !own.Success || !sameMaps(c.Code, expectedCode) || !sameMaps(c.Dependencies, own.Dependencies) || own.Exe.SHA256 != c.Exe.SHA256 || own.Runtime != profile.runtime || own.Finance != profile.finance || own.Pure != profile.pure || own.Builder != profile.builder {
		return p, fmt.Errorf("wrapper停止とcode/依存/exe/各停止の差")
	}
	for _, name := range profile.self {
		if !validSHA(c.Code[name]) {
			return p, fmt.Errorf("wrapper本文省略: %s", name)
		}
	}
	exe, err := profile.exe()
	if err != nil {
		return p, err
	}
	exe, err = filepath.Abs(exe)
	if err != nil || exe != c.Exe.Path {
		return p, fmt.Errorf("起動exe path差")
	}
	for _, group := range []map[string]string{c.Code, c.Dependencies} {
		for name, h := range group {
			if _, err = addVerified(p.Before, p.Root, FileRef{Path: name, SHA256: h}); err != nil {
				return p, err
			}
		}
	}
	components := []struct {
		r      FileRef
		rooted bool
	}{{c.RuntimeStop, false}, {c.FinanceStop, false}, {c.PureStop, false}, {c.BuilderStop, true}}
	for _, r := range components {
		var s stopInfo
		if err = readJSON(r.r.Path, &s); err != nil || !s.Success {
			return p, fmt.Errorf("停止の成功/schema不明: %v", err)
		}
		home := filepath.Dir(r.r.Path)
		required := s.Code
		if r.rooted {
			home = p.Root
			required = s.Owned
		}
		if len(required) == 0 {
			return p, fmt.Errorf("停止のコード集合不足")
		}
		if err = requireCode(p.Root, home, c.Code, required); err != nil {
			return p, err
		}
	}
	proofPath, err := resolve(p.Root, study100+"/完了記録.json")
	if err != nil || proofPath != c.Proof100.Path {
		return p, fmt.Errorf("固定100閉鎖の正本path差")
	}
	var closed closure
	if err = readJSON(c.Proof100.Path, &closed); err != nil {
		return p, err
	}
	if closed.Trial != 100 || !closed.Complete || closed.Scenes != 54 || len(closed.Core) != profile.coreCount || len(closed.Post) != profile.postCount {
		return p, fmt.Errorf("100閉鎖の成功/全集合が不明")
	}
	if err = requireCode(p.Root, p.Root, c.Code, closed.Core); err != nil {
		return p, err
	}
	if err = requireCode(p.Root, p.Root, c.Code, closed.Post); err != nil {
		return p, err
	}
	catalog := map[string]string{}
	pattern := regexp.MustCompile(`^成果物/(\d{4}-\d{2}-\d{2}_(?:Day|Night))\.json\.gz$`)
	for name, h := range closed.Files {
		if m := pattern.FindStringSubmatch(filepath.ToSlash(name)); m != nil {
			if _, ok := catalog[m[1]]; ok || !validSHA(h) {
				return p, fmt.Errorf("100Native重複/SHA不正")
			}
			catalog[m[1]] = h
		}
	}
	if len(catalog) != 54 {
		return p, fmt.Errorf("100Native許可54不足")
	}
	var allowed continuous.Allowed
	if err = readJSON(c.Allowed54.Path, &allowed); err != nil {
		return p, err
	}
	if allowed.Version != 1 || allowed.ProofSHA != profile.proof || len(allowed.Entries) != 54 {
		return p, fmt.Errorf("許可54 metadata差")
	}
	seen := map[string]bool{}
	for _, v := range allowed.Entries {
		if seen[v.Session] || catalog[v.Session] != v.NativeSHA {
			return p, fmt.Errorf("許可54の欠落/追加/重複")
		}
		seen[v.Session] = true
	}
	indices := map[string]port.TapeIndex{}
	specs := map[string]StageSpec{}
	for _, stage := range []string{"first2", "full54"} {
		s, ok := c.Stages[stage]
		if !ok {
			return p, fmt.Errorf("両stage宣言が必要")
		}
		s.Index, err = addVerified(p.Before, base, s.Index)
		if err != nil {
			return p, err
		}
		s.SidecarReceipt, err = addVerified(p.Before, base, s.SidecarReceipt)
		if err != nil {
			return p, err
		}
		var index port.TapeIndex
		if err = readJSON(s.Index.Path, &index); err != nil {
			return p, err
		}
		if err = validateIndex(index, stage, catalog, profile); err != nil {
			return p, err
		}
		var receipt sidecarProof
		if err = readJSON(s.SidecarReceipt.Path, &receipt); err != nil {
			return p, err
		}
		if !receipt.Success || receipt.Scope != profile.sidecarScope || receipt.Stage != stage || receipt.Proof != profile.proof || !receipt.Unchanged || receipt.Source == nil || receipt.Financial == nil || receipt.Features == nil || receipt.Charts == nil || *receipt.Source || *receipt.Financial || *receipt.Features != profile.recomputed || *receipt.Charts != profile.recomputed || !sameMaps(receipt.Code, s.ProducerCode) || len(receipt.Sessions) != len(index.Entries) || len(receipt.Details) != len(index.Entries) || len(s.Scenes) != len(index.Entries) {
			return p, fmt.Errorf("sidecar receiptの同producer成功/場数/schema差")
		}
		bySpec := map[string]SceneFiles{}
		for _, v := range s.Scenes {
			if _, ok := bySpec[v.Session]; ok || !validSHA(v.Header.SHA256) || !validSHA(v.Records.SHA256) {
				return p, fmt.Errorf("sidecar条件の重複/SHA不備")
			}
			bySpec[v.Session] = v
		}
		byDetail := map[string]sidecarDetail{}
		for _, v := range receipt.Details {
			if _, ok := byDetail[v.Session]; ok {
				return p, fmt.Errorf("sidecar receipt重複")
			}
			byDetail[v.Session] = v
		}
		for _, entry := range index.Entries {
			v, ok := bySpec[entry.Session]
			d, dok := byDetail[entry.Session]
			if !ok || !dok {
				return p, fmt.Errorf("sidecarの場集合差")
			}
			header, he := resolve(base, v.Header.Path)
			records, re := resolve(base, v.Records.Path)
			dh, dhe := resolve(p.Root, d.Header)
			dr, dre := resolve(p.Root, d.Path)
			if he != nil || re != nil || dhe != nil || dre != nil || header != dh || records != dr || v.Header.SHA256 != d.HeaderSHA256 || v.Records.SHA256 != d.SHA256 {
				return p, fmt.Errorf("sidecar条件とproducer宣言path/SHA差")
			}
		}
		ids := append([]string{}, receipt.Sessions...)
		sort.Strings(ids)
		expected := []string{}
		for _, e := range index.Entries {
			expected = append(expected, e.Session)
		}
		sort.Strings(expected)
		if !reflect.DeepEqual(ids, expected) {
			return p, fmt.Errorf("sidecar全場集合差")
		}
		specs[stage] = s
		indices[stage] = index
	}
	selected := specs[args.Stage]
	if args.Stage == "full54" {
		if err = verifyFirst2(args.First2, p, catalog); err != nil {
			return p, err
		}
	}
	p.Receipt = selected.SidecarReceipt
	byScene := map[string]SceneFiles{}
	for _, v := range selected.Scenes {
		byScene[v.Session] = v
	}
	for _, entry := range indices[args.Stage].Entries {
		file := byScene[entry.Session]
		t, er := addVerified(p.Before, filepath.Dir(selected.Index.Path), FileRef{Path: entry.Path, SHA256: entry.SHA256})
		if er != nil {
			return p, er
		}
		n, er := addVerified(p.Before, filepath.Join(p.Root, study100), FileRef{Path: "成果物/" + entry.Session + ".json.gz", SHA256: catalog[entry.Session]})
		if er != nil {
			return p, er
		}
		h, er := addVerified(p.Before, base, file.Header)
		if er != nil {
			return p, er
		}
		r, er := addVerified(p.Before, base, file.Records)
		if er != nil {
			return p, er
		}
		p.Scenes = append(p.Scenes, scenePlan{Session: entry.Session, Tape: t, Native: n, Header: h, Records: r})
	}
	sort.Slice(p.Scenes, func(i, j int) bool { return p.Scenes[i].Session < p.Scenes[j].Session })
	return p, nil
}

// verifyFirst2 は同condition/codeの先頭2場成功と全出力指紋を要求します。
//
// 引数: path(string)、p(plan)、catalog(map[string]string)は宣言済み入力です。
// 返り値: errorは未完/別版/改変です。先頭2Nativeの本文を再読しません。
func verifyFirst2(path string, p plan, catalog map[string]string) error {
	if path == "" {
		return fmt.Errorf("full54は同条件のfirst2成功が必要")
	}
	absolute, err := filepath.Abs(path)
	if err != nil {
		return err
	}
	h, err := digest(absolute)
	if err != nil {
		return err
	}
	var c Completion
	if err = readJSON(absolute, &c); err != nil {
		return err
	}
	if err = requireJSONFields(absolute, "scope", "成功", "試行", "stage", "条件SHA256", "全12Key", "結果", "コードSHA256", "Go依存SHA256", "入力前SHA256", "入力後SHA256", "前後不変", "source_reexecuted", "features_recomputed", "charts_recomputed", "Raw読取"); err != nil {
		return err
	}
	if !c.Success || c.Scope != p.Profile.scope || c.Trial != 101 || c.Stage != "first2" || c.ConditionSHA256 != p.ConditionSHA || !c.Unchanged || c.SourceReexecuted || c.FeaturesRecomputed || c.ChartsRecomputed || c.RawReads != 0 || !reflect.DeepEqual(c.Keys, runtime.Keys()) || !sameMaps(c.Code, p.Condition.Code) || !sameMaps(c.Dependencies, p.Condition.Dependencies) || len(c.Before) == 0 || !sameMaps(c.Before, c.After) || len(c.Results) != len(first2IDs(p.Profile)) {
		return fmt.Errorf("first2の同条件/成功/不変が不明")
	}
	for _, r := range []FileRef{p.Condition.Proof100, p.Condition.Allowed54, p.Condition.WrapperStop, p.Condition.RuntimeStop, p.Condition.FinanceStop, p.Condition.PureStop, p.Condition.BuilderStop, p.Condition.Exe} {
		if c.Before[r.Path] != r.SHA256 {
			return fmt.Errorf("first2の必要入力前後指紋不足")
		}
	}
	expected := map[string]bool{}
	for _, id := range first2IDs(p.Profile) {
		expected[id] = true
	}
	for _, v := range c.Results {
		if !expected[v.Session] || v.Error != "" || v.P0Books != 4 || v.Books != 12 || !validSHA(catalog[v.Session]) {
			return fmt.Errorf("first2全結果の集合差")
		}
		delete(expected, v.Session)
		r, er := addVerified(p.Before, filepath.Dir(absolute), FileRef{Path: v.Path, SHA256: v.SHA256})
		if er != nil {
			return er
		}
		_ = r
	}
	p.Before[absolute] = h
	return nil
}
