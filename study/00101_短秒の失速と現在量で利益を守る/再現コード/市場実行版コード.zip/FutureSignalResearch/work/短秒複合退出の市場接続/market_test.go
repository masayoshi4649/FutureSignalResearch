package shortmarket101

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"

	port "github.com/masayoshi4649/SessionTradeExecuter/actorport97"
	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	old100 "github.com/masayoshi4649/SessionTradeExecuter/grossport100"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	runtime "github.com/masayoshi4649/SessionTradeExecuter/shortport101"
)

type savedArtificial struct {
	Tape      tape.Tape          `json:"tape"`
	Header    continuous.Sidecar `json:"header"`
	StreamSHA string             `json:"stream_sha256"`
}
type testData struct {
	input   tape.Tape
	source  runtime.StreamSource
	prior   Prior100
	refs    InputRefs
	file    FileRef
	header  FileRef
	records FileRef
}

// boolValue は明示falseと欠落を区別する独立値を作ります。
//
// 引数: v(bool)です。
// 返り値: *boolは独立値です。
func boolValue(v bool) *bool { return &v }

// saveFixture は人工だけを新規JSON/gzipへ保存し指紋を返します。
//
// 引数: t(*testing.T)、path(string)、value(any)、compressed(bool)です。
// 返り値: FileRefは絶対path/SHAです。
func saveFixture(t *testing.T, path string, value any, compressed bool) FileRef {
	t.Helper()
	if err := os.MkdirAll(filepath.Dir(path), 0755); err != nil {
		t.Fatal(err)
	}
	if err := writeNew(path, value, compressed); err != nil {
		t.Fatal(err)
	}
	h, err := digest(path)
	if err != nil {
		t.Fatal(err)
	}
	return FileRef{path, h}
}

// copyFixture はGo停止人工のbytesを変更せず別の試験dirへ置きます。
//
// 引数: t(*testing.T)、source/target(string)は人工だけです。
// 返り値: FileRefは複写先のbytes指紋です。
func copyFixture(t *testing.T, source, target string) FileRef {
	t.Helper()
	body, err := os.ReadFile(source)
	if err != nil {
		t.Fatal(err)
	}
	if err = os.MkdirAll(filepath.Dir(target), 0755); err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(target, body, 0644); err != nil {
		t.Fatal(err)
	}
	h, err := digest(target)
	if err != nil {
		t.Fatal(err)
	}
	return FileRef{target, h}
}

// fixtureData は停止ff571dの買売完全人工を再用します。
//
// 引数: t(*testing.T)、side(int)、root(string)は人工選択/未使用保存先です。
// 返り値: testDataは実金融を公開APIへ流した旧100十二口座と供給値です。
// 旧市場Native/Raw/Source engineは読まず、手製Sourceの範囲を継承します。
func fixtureData(t *testing.T, side int, root string) testData {
	t.Helper()
	home := filepath.Join("..", "短秒複合退出の再生")
	stopBody, err := os.ReadFile(filepath.Join(home, "停止.json"))
	if err != nil {
		t.Fatal(err)
	}
	if fmt.Sprintf("%x", sha256.Sum256(stopBody)) != "ff571dba63a439e9df2fc855f722da1e506ee26cc1ef483de9aa4356e39e2eb7" {
		t.Fatal("停止runtime差")
	}
	var stop struct {
		Owned map[string]string `json:"全所有SHA256"`
	}
	json.Unmarshal(stopBody, &stop)
	rel := filepath.Join("人工", "完全接続", fmt.Sprintf("方向%d.json", side))
	body, err := os.ReadFile(filepath.Join(home, rel))
	if err != nil || fmt.Sprintf("%x", sha256.Sum256(body)) != stop.Owned[rel] {
		t.Fatal("停止完全人工差", err)
	}
	var stored savedArtificial
	if err = json.Unmarshal(body, &stored); err != nil {
		t.Fatal(err)
	}
	d := testData{input: stored.Tape}
	d.file = saveFixture(t, filepath.Join(root, "input", "tape.json.gz"), d.input, true)
	recordsRel := filepath.Join("人工", "完全接続", fmt.Sprintf("方向%d.records.jsonl.gz", side))
	d.records = copyFixture(t, filepath.Join(home, recordsRel), filepath.Join(root, "input", "records.jsonl.gz"))
	if d.records.SHA256 != stored.StreamSHA || d.records.SHA256 != stop.Owned[recordsRel] {
		t.Fatal("停止stream差")
	}
	records := []port.GateAssessmentRecord{}
	old, err := port.Run(d.input, old100.ProtectionFactory{Records: &records}, old100.Configurations())
	if err != nil {
		t.Fatal(err)
	}
	d.prior = Prior100{Trial: 100, Version: 1, Session: d.input.Session.ID, Contract: "人工限月", Books: old.Books, ActualRunComplete: true, SourceReexecuted: boolValue(false), ChartsRecomputed: boolValue(false)}
	d.prior.Tape.SHA = d.file.SHA256
	d.refs.Native100 = saveFixture(t, filepath.Join(root, study100, "成果物", d.input.Session.ID+".json.gz"), d.prior, true)
	stored.Header.Provenance = map[string]string{"old_tape_gzip_sha256": d.file.SHA256, "proof100_sha256": strings.Repeat("a", 64)}
	d.header = saveFixture(t, filepath.Join(root, "input", "header.json"), stored.Header, false)
	raw, _ := json.Marshal(stored.Header)
	hs := fmt.Sprintf("%x", sha256.Sum256(raw))
	d.source = runtime.StreamSource{Header: stored.Header, HeaderCanonicalSHA256: hs, CompressedSHA256: d.records.SHA256, Open: func() (io.ReadCloser, error) { return os.Open(d.records.Path) }}
	d.refs.Tape = d.file
	d.refs.SidecarHeader = d.header
	d.refs.SidecarRecords = d.records
	return d
}

// TestMarketScene24 は2人工×12の全値とコンパクト保存再読を確認します。
//
// 引数: t(*testing.T)です。
// 返り値: ありません。private金融情報や入力全量を転記しないことも確認します。
func TestMarketScene24(t *testing.T) {
	for _, side := range []int{1, -1} {
		t.Run(fmt.Sprintf("方向%d", side), func(t *testing.T) {
			root := t.TempDir()
			d := fixtureData(t, side, root)
			meta := SceneMetadata{Scope: "人工公開APIだけ", ConditionSHA256: strings.Repeat("b", 64), Proof100SHA256: strings.Repeat("a", 64), ProducerStopSHA256: strings.Repeat("c", 64), Input: d.refs}
			out, err := BuildNative(d.input, d.source, d.prior, meta)
			if err != nil {
				t.Fatal(err)
			}
			if len(out.Books) != 12 || len(out.P0100Match.Keys) != 4 || len(out.P0100Match.Excluded) != 0 || !out.P0100Match.FullJSON {
				t.Fatal("12/P0四不足")
			}
			for key, raw := range out.Books {
				var b struct {
					Positions []json.RawMessage `json:"positions"`
					Fills     []json.RawMessage `json:"fills"`
					Metrics   struct {
						Requests int `json:"short_exit_requests"`
						Fills    int `json:"short_exit_fills"`
					} `json:"metrics"`
				}
				if err = json.Unmarshal(raw, &b); err != nil || len(b.Positions) != 1 || len(b.Fills) == 0 {
					t.Fatal("24全非0不足", key, err)
				}
				if strings.HasPrefix(key, "S") && (b.Metrics.Requests != 1 || b.Metrics.Fills != 1) {
					t.Fatal("S実純式非0不足", key)
				}
			}
			path := saveFixture(t, filepath.Join(root, "new.json.gz"), out, true)
			var restored Envelope
			if err = readGzip(path.Path, &restored); err != nil || !reflect.DeepEqual(out, restored) {
				t.Fatal("保存再読差", err)
			}
			var keys map[string]json.RawMessage
			if err = readGzip(path.Path, &keys); err != nil {
				t.Fatal(err)
			}
			for _, name := range []string{"shadows", "chart_grids", "source_rows", "short_assessments", "feature_config"} {
				if _, ok := keys[name]; ok {
					t.Fatal("重複全量を転載", name)
				}
			}
			changed := d.prior
			changed.Books = map[string]json.RawMessage{}
			for k, v := range d.prior.Books {
				changed.Books[k] = v
			}
			var b map[string]any
			json.Unmarshal(changed.Books[runtime.Keys()[0]], &b)
			b["key"] = "破損"
			changed.Books[runtime.Keys()[0]], _ = json.Marshal(b)
			if _, err = BuildNative(d.input, d.source, changed, meta); err == nil {
				t.Fatal("旧P0全field破損成功化")
			}
			changed = d.prior
			changed.SourceReexecuted = nil
			if _, err = BuildNative(d.input, d.source, changed, meta); err == nil {
				t.Fatal("未計測Sourceをfalse補完")
			}
		})
	}
}

type ioFixture struct {
	args      Arguments
	profile   trust
	condition Condition
	data      testData
	root      string
}

// conditionFixture は署名値/件数だけを置換したprivate metadata器具です。
//
// 引数: t(*testing.T)です。
// 返り値: ioFixtureは1場に縮小したI/O検査専用。CLIでは選択できません。
// 54宣言の未対象ファイルは作らず、全54成功を主張しません。実金融は停止Go人工そのものです。
func conditionFixture(t *testing.T) ioFixture {
	t.Helper()
	root := t.TempDir()
	d := fixtureData(t, 1, root)
	if err := os.WriteFile(filepath.Join(root, "fixture.go"), []byte("人工コード"), 0644); err != nil {
		t.Fatal(err)
	}
	codeSHA, _ := digest(filepath.Join(root, "fixture.go"))
	code := map[string]string{"fixture.go": codeSHA}
	if err := os.WriteFile(filepath.Join(root, "producer3.go"), []byte("別producerの人工コード"), 0644); err != nil {
		t.Fatal(err)
	}
	p3SHA, _ := digest(filepath.Join(root, "producer3.go"))
	producer3 := map[string]string{"producer3.go": p3SHA}
	depPath := filepath.Join(root, "dep.mod")
	os.WriteFile(depPath, []byte("人工依存"), 0644)
	depSHA, _ := digest(depPath)
	deps := map[string]string{"dep.mod": depSHA}
	exePath := filepath.Join(root, "fixture.exe")
	os.WriteFile(exePath, []byte("実行しない人工exe"), 0644)
	exeSHA, _ := digest(exePath)
	component := saveFixture(t, filepath.Join(root, "component.stop.json"), stopInfo{Success: true, Code: code, Owned: code}, false)
	p3 := saveFixture(t, filepath.Join(root, "producer3.stop.json"), stopInfo{Success: true, Owned: producer3}, false)
	closed := closure{Trial: 100, Complete: true, Scenes: 54, Files: map[string]string{}, Core: code, Post: map[string]string{}}
	allowed := continuous.Allowed{Version: 1, Entries: []continuous.AllowedEntry{}}
	ids := []string{}
	for day := time.Date(2026, 9, 21, 0, 0, 0, 0, time.UTC); !day.After(time.Date(2026, 10, 27, 0, 0, 0, 0, time.UTC)); day = day.AddDate(0, 0, 1) {
		if day.Weekday() == time.Saturday || day.Weekday() == time.Sunday {
			continue
		}
		ids = append(ids, day.Format("2006-01-02")+"_Day", day.Format("2006-01-02")+"_Night")
	}
	if len(ids) != 54 {
		t.Fatal("人工54宣言数")
	}
	for _, id := range ids {
		h := strings.Repeat("d", 64)
		if id == d.input.Session.ID {
			h = d.refs.Native100.SHA256
		}
		closed.Files["成果物/"+id+".json.gz"] = h
		allowed.Entries = append(allowed.Entries, continuous.AllowedEntry{Session: id, NativeSHA: h})
	}
	proof := saveFixture(t, filepath.Join(root, study100, "完了記録.json"), closed, false)
	allowed.ProofSHA = proof.SHA256
	allowRef := saveFixture(t, filepath.Join(root, "allowed.json"), allowed, false)
	profile := trust{proof: proof.SHA256, runtime: component.SHA256, finance: component.SHA256, pure: component.SHA256, builder: component.SHA256, scope: "人工metadata縮小1場・実市場の成功ではない", coreCount: 1, postCount: 0, self: []string{"fixture.go"}, exe: func() (string, error) { return exePath, nil }, sidecarScope: "人工metadata・producer形成未検査", recomputed: false, first2: []string{d.input.Session.ID}}
	// Headerの由来だけを人工閉鎖へ結ぶ。元停止型/stream/数式を変更しない。
	d.source.Header.Provenance["proof100_sha256"] = proof.SHA256
	os.Remove(d.header.Path)
	d.header = saveFixture(t, d.header.Path, d.source.Header, false)
	d.refs.SidecarHeader = d.header
	index2 := port.TapeIndex{Version: 1, Stage: "first2", Entries: []port.TapeEntry{{Session: d.input.Session.ID, Path: "../input/tape.json.gz", SHA256: d.file.SHA256}}}
	index54 := port.TapeIndex{Version: 1, Stage: "full54", Entries: []port.TapeEntry{}}
	for _, id := range ids {
		e := port.TapeEntry{Session: id, Path: "../未生成/" + id + ".gz", SHA256: strings.Repeat("e", 64)}
		if id == d.input.Session.ID {
			e = index2.Entries[0]
		}
		index54.Entries = append(index54.Entries, e)
	}
	i2 := saveFixture(t, filepath.Join(root, "index", "first2.json"), index2, false)
	i54 := saveFixture(t, filepath.Join(root, "index", "full54.json"), index54, false)
	stages := map[string]StageSpec{}
	for _, stage := range []string{"first2", "full54"} {
		stageIDs := ids
		producer := p3
		producerCode := producer3
		index := i54
		if stage == "first2" {
			stageIDs = []string{d.input.Session.ID}
			producer = component
			producerCode = code
			index = i2
		}
		receipt := sidecarProof{Success: true, Scope: profile.sidecarScope, Stage: stage, Proof: proof.SHA256, Sessions: stageIDs, Code: producerCode, Unchanged: true, Source: boolValue(false), Financial: boolValue(false), Features: boolValue(false), Charts: boolValue(false), Details: []sidecarDetail{}}
		scenes := []SceneFiles{}
		for _, id := range stageIDs {
			h := FileRef{Path: "未生成/" + id + ".header", SHA256: strings.Repeat("f", 64)}
			r := FileRef{Path: "未生成/" + id + ".records", SHA256: strings.Repeat("f", 64)}
			if id == d.input.Session.ID {
				h = d.header
				r = d.records
			}
			scenes = append(scenes, SceneFiles{Session: id, Header: h, Records: r})
			receipt.Details = append(receipt.Details, sidecarDetail{Session: id, Path: r.Path, SHA256: r.SHA256, Header: h.Path, HeaderSHA256: h.SHA256})
		}
		rref := saveFixture(t, filepath.Join(root, stage+".sidecar.json"), receipt, false)
		stages[stage] = StageSpec{Index: index, SidecarReceipt: rref, ProducerStop: producer, ProducerCode: producerCode, SchemaVersion: 1, Scenes: scenes}
	}
	union := map[string]string{"fixture.go": codeSHA, "producer3.go": p3SHA}
	exe := FileRef{Path: exePath, SHA256: exeSHA}
	own := saveFixture(t, filepath.Join(root, "wrapper.stop.json"), stopInfo{Success: true, Required: code, Dependencies: deps, Exe: exe, Runtime: component.SHA256, Finance: component.SHA256, Pure: component.SHA256, Builder: component.SHA256}, false)
	c := Condition{Trial: 101, Version: 1, Fixed: true, Keys: runtime.Keys(), Proof100: proof, Allowed54: allowRef, WrapperStop: own, RuntimeStop: component, FinanceStop: component, PureStop: component, BuilderStop: component, Exe: exe, Code: union, Dependencies: deps, Stages: stages}
	cref := saveFixture(t, filepath.Join(root, "condition.json"), c, false)
	return ioFixture{args: Arguments{Root: root, Condition: cref.Path, ConditionSHA256: cref.SHA256, Stage: "first2", Output: filepath.Join(root, "new-output"), Workers: 2}, profile: profile, condition: c, data: d, root: root}
}

// TestMarketPrivateIO は条件/相対Tapepath/producer分離/保存再読を人工で接続します。
//
// 引数: t(*testing.T)です。
// 返り値: ありません。人工profileはCLIへ公開せず実2/54成功に数えません。
func TestMarketPrivateIO(t *testing.T) {
	f := conditionFixture(t)
	if err := run(f.args, f.profile); err != nil {
		t.Fatal(err)
	}
	var receipt Completion
	if err := readJSON(filepath.Join(f.args.Output, "完了.json"), &receipt); err != nil || !receipt.Success || receipt.Scope != f.profile.scope || len(receipt.Results) != 1 || !receipt.Unchanged {
		t.Fatal("人工I/O保存差", err)
	}
	var native Envelope
	if err := readGzip(receipt.Results[0].Path, &native); err != nil || len(native.Books) != 12 {
		t.Fatal("Native再読の12不足", err)
	}
	if native.Stops["consumer_builder"] != runtime.BuilderStopSHA256 || native.Stops["producer"] != f.condition.Stages["first2"].ProducerStop.SHA256 {
		t.Fatal("producerとconsumerの由来混同")
	}
	if len(native.P0100Match.Keys) != 4 {
		t.Fatal("P0四全文不足")
	}
	p, err := prepare(Arguments{Root: f.args.Root, Condition: f.args.Condition, ConditionSHA256: f.args.ConditionSHA256, Stage: "first2", Output: filepath.Join(f.root, "別新規"), Workers: 1}, f.profile)
	if err != nil {
		t.Fatal(err)
	}
	if err = verifyFirst2(filepath.Join(f.args.Output, "完了.json"), p, map[string]string{f.data.input.Session.ID: f.data.refs.Native100.SHA256}); err != nil {
		t.Fatal("同条件first2 metadata", err)
	}
	var damaged map[string]any
	if err = readJSON(filepath.Join(f.args.Output, "完了.json"), &damaged); err != nil {
		t.Fatal(err)
	}
	delete(damaged, "source_reexecuted")
	bad := saveFixture(t, filepath.Join(f.root, "欠落first2.json"), damaged, false)
	if err = verifyFirst2(bad.Path, p, map[string]string{f.data.input.Session.ID: f.data.refs.Native100.SHA256}); err == nil {
		t.Fatal("未計測Sourceをfalse補完したfirst2")
	}
	if err = run(f.args, f.profile); err == nil {
		t.Fatal("出力上書き成功")
	}
	for _, ref := range []FileRef{f.data.file, f.data.refs.Native100, f.data.header, f.data.records} {
		got, err := digest(ref.Path)
		if err != nil || got != ref.SHA256 {
			t.Fatal("人工入力変更", err)
		}
	}
}

// TestMarketGuards は未固定/集合/各停止/入力指紋を出力前に拒否します。
//
// 引数: t(*testing.T)です。
// 返り値: ありません。実市場ファイルを開かずprivate人工だけを破損します。
func TestMarketGuards(t *testing.T) {
	for _, name := range []string{"条件SHA空", "未固定", "12key不足", "依存省略", "code省略", "producer型", "停止取違", "exeSHA", "旧Native改変", "stream改変", "full先頭なし"} {
		t.Run(name, func(t *testing.T) {
			f := conditionFixture(t)
			c := f.condition
			a := f.args
			switch name {
			case "条件SHA空":
				a.ConditionSHA256 = ""
			case "未固定":
				c.Fixed = false
			case "12key不足":
				c.Keys = c.Keys[:11]
			case "依存省略":
				c.Dependencies = map[string]string{}
			case "code省略":
				delete(c.Code, "producer3.go")
			case "producer型":
				s := c.Stages["full54"]
				s.SchemaVersion = 2
				c.Stages["full54"] = s
			case "停止取違":
				c.RuntimeStop.SHA256 = strings.Repeat("a", 64)
			case "exeSHA":
				c.Exe.SHA256 = strings.Repeat("a", 64)
			case "旧Native改変":
				os.WriteFile(f.data.refs.Native100.Path, []byte("破損"), 0644)
			case "stream改変":
				os.WriteFile(f.data.records.Path, []byte("破損"), 0644)
			case "full先頭なし":
				a.Stage = "full54"
			}
			if name != "条件SHA空" {
				os.Remove(a.Condition)
				ref := saveFixture(t, a.Condition, c, false)
				a.ConditionSHA256 = ref.SHA256
			}
			err := run(a, f.profile)
			if err == nil {
				t.Fatal("guard破損成功化")
			}
			if name == "full先頭なし" && !strings.Contains(err.Error(), "first2") {
				t.Fatal("54本文より先にfirst2を確認していない", err)
			}
			if _, err = os.Stat(a.Output); !os.IsNotExist(err) {
				t.Fatal("拒否時に出力作成")
			}
		})
	}
	f := conditionFixture(t)
	if err := Run(f.args); err == nil {
		t.Fatal("人工Root署名を本番CLIで許可")
	}
	if _, err := os.Stat(f.args.Output); !os.IsNotExist(err) {
		t.Fatal("本番拒否で出力")
	}
}
