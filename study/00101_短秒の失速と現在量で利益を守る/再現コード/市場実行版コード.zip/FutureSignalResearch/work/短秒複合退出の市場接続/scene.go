package shortmarket101

import (
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	old100 "github.com/masayoshi4649/SessionTradeExecuter/grossport100"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	runtime "github.com/masayoshi4649/SessionTradeExecuter/shortport101"
)

// Prior100 は正本の必要欄だけを読む型で、旧Shadows/全Source/全Gridを複写しません。
type Prior100 struct {
	Trial    int                        `json:"trial"`
	Version  int                        `json:"version"`
	Session  string                     `json:"session"`
	Contract string                     `json:"contract"`
	Books    map[string]json.RawMessage `json:"books"`
	Tape     struct {
		SHA string `json:"sha256"`
	} `json:"tape_provenance"`
	ActualRunComplete bool  `json:"actual_run_complete"`
	SourceReexecuted  *bool `json:"source_reexecuted"`
	ChartsRecomputed  *bool `json:"charts_recomputed"`
}
type SceneMetadata struct {
	Scope, ConditionSHA256, Proof100SHA256, ProducerStopSHA256 string
	Input                                                      InputRefs
}

// BuildNative は固定済み公開値を停止runtimeへ渡し、重複のない新保存型を作ります。
//
// 引数: input(tape.Tape)、source(runtime.StreamSource)、prior(Prior100)、meta(SceneMetadata)は既読/供給値です。
// 返り値: Envelope/errorは12Book/入口全check/小型結合情報又は不一致です。ファイル/Source/指標を生成しません。
func BuildNative(input tape.Tape, source runtime.StreamSource, prior Prior100, meta SceneMetadata) (Envelope, error) {
	var out Envelope
	if meta.Scope == "" || !validSHA(meta.ConditionSHA256) || !validSHA(meta.Proof100SHA256) || !validSHA(meta.ProducerStopSHA256) || prior.Trial != 100 || prior.Version != 1 || prior.Session != input.Session.ID || prior.Contract == "" || len(prior.Books) != 12 || !prior.ActualRunComplete || prior.SourceReexecuted == nil || prior.ChartsRecomputed == nil || *prior.SourceReexecuted || *prior.ChartsRecomputed || prior.Tape.SHA != meta.Input.Tape.SHA256 {
		return out, fmt.Errorf("旧100/条件/場/保存範囲が不明")
	}
	for _, key := range old100.Keys() {
		if !json.Valid(prior.Books[key]) {
			return out, fmt.Errorf("旧100の12key不足")
		}
	}
	if source.Header.Provenance["old_tape_gzip_sha256"] != meta.Input.Tape.SHA256 || source.Header.Provenance["proof100_sha256"] != meta.Proof100SHA256 {
		return out, fmt.Errorf("sidecarの旧Tape/100閉鎖由来差")
	}
	for _, event := range input.Events {
		if event.Kind == "grid" && (event.Context == nil || event.Context.Chart.Scene.ID != input.Session.ID || event.Context.Chart.Scene.Start != input.Session.Start || event.Context.Chart.Scene.Contract != prior.Contract) {
			return out, fmt.Errorf("旧gridと100の場/限月差")
		}
	}
	result, err := runtime.Replay(input, source, prior.Contract, false)
	if err != nil {
		return out, err
	}
	matched := []string{}
	bindings := map[string]ShortCounts{}
	for _, key := range runtime.Keys() {
		raw, ok := result.Result.Books[key]
		if !ok {
			return out, fmt.Errorf("新12key不足")
		}
		var b struct {
			Key      string         `json:"key"`
			Session  native.Session `json:"session"`
			Complete bool           `json:"complete"`
			Finished bool           `json:"finished"`
			Failure  string         `json:"failure"`
			Metrics  struct {
				Requests int `json:"short_exit_requests"`
				Fills    int `json:"short_exit_fills"`
			} `json:"metrics"`
		}
		if err = json.Unmarshal(raw, &b); err != nil || b.Key != key || b.Session != input.Session || !b.Complete || !b.Finished || b.Failure != "" {
			return out, fmt.Errorf("新12金融の完結/場時計差: %s", key)
		}
		bindings[key] = ShortCounts{ExitRequests: b.Metrics.Requests, ExitFills: b.Metrics.Fills}
	}
	for _, r := range result.Held {
		v := bindings[r.Key]
		v.Callbacks++
		bindings[r.Key] = v
	}
	for _, key := range runtime.Keys()[:4] {
		var oldSession struct {
			Session native.Session `json:"session"`
		}
		if err = json.Unmarshal(prior.Books[key], &oldSession); err != nil || oldSession.Session != input.Session {
			return out, fmt.Errorf("旧100P0とTape場時計差")
		}
		equal, e := equalJSON(result.Result.Books[key], prior.Books[key])
		if e != nil || !equal {
			return out, fmt.Errorf("旧100P0全JSON除外0差: %s", key)
		}
		matched = append(matched, key)
	}
	out = Envelope{Scope: meta.Scope, Trial: 101, Version: 1, Session: input.Session.ID, Contract: prior.Contract, Books: result.Result.Books, GateAssessments: result.Entry, ShortBindings: bindings, StreamPasses: result.Streams, Input: meta.Input, ConditionSHA256: meta.ConditionSHA256, Stops: map[string]string{"runtime": "ff571dba63a439e9df2fc855f722da1e506ee26cc1ef483de9aa4356e39e2eb7", "finance": runtime.FinanceStopSHA256, "pure": runtime.PureStopSHA256, "consumer_builder": runtime.BuilderStopSHA256, "producer": meta.ProducerStopSHA256, "proof100": meta.Proof100SHA256}, P0100Match: P0Match{Keys: matched, Excluded: []string{}, FullJSON: true, Native100SHA256: meta.Input.Native100.SHA256}, ActualRunComplete: true}
	// result.Heldの全値はBooks内に保存済み。外部への二重転記はせず件数/結合だけ残す。
	return out, nil
}

// processScene は前検査で固定した一場だけを読取し、新gzipを排他的保存します。
//
// 引数: p(plan)、s(scenePlan)、stage(string)は許可済み計画と一場です。
// 返り値: Outcomeは全12/P0四対照成功又は不一致です。旧Source/全Gridを新Nativeへ転載しません。
func processScene(p plan, s scenePlan, stage string) Outcome {
	out := Outcome{Session: s.Session}
	input, err := tape.LoadCache(s.Tape.Path, s.Tape.SHA256)
	if err != nil {
		out.Error = err.Error()
		return out
	}
	if input.Session.ID != s.Session {
		out.Error = "indexとTape場ID差"
		return out
	}
	var prior Prior100
	if err = readGzip(s.Native.Path, &prior); err != nil {
		out.Error = err.Error()
		return out
	}
	var header continuous.Sidecar
	if err = readJSON(s.Header.Path, &header); err != nil {
		out.Error = err.Error()
		return out
	}
	canonical, err := json.Marshal(header)
	if err != nil {
		out.Error = err.Error()
		return out
	}
	headerSHA := fmt.Sprintf("%x", sha256.Sum256(canonical))
	source := runtime.StreamSource{Header: header, HeaderCanonicalSHA256: headerSHA, CompressedSHA256: s.Records.SHA256, Open: func() (io.ReadCloser, error) { return os.Open(s.Records.Path) }}
	spec := p.Condition.Stages[stage]
	refs := InputRefs{Native100: s.Native, Tape: s.Tape, SidecarReceipt: p.Receipt, SidecarHeader: s.Header, SidecarRecords: s.Records, ProducerStop: spec.ProducerStop}
	value, err := BuildNative(input, source, prior, SceneMetadata{Scope: p.Profile.scope, ConditionSHA256: p.ConditionSHA, Proof100SHA256: p.Profile.proof, ProducerStopSHA256: spec.ProducerStop.SHA256, Input: refs})
	if err != nil {
		out.Error = err.Error()
		return out
	}
	out.Path = filepath.Join(p.Output, s.Session+".json.gz")
	if err = writeNew(out.Path, value, true); err != nil {
		out.Error = err.Error()
		return out
	}
	out.SHA256, err = digest(out.Path)
	if err != nil {
		out.Error = err.Error()
		return out
	}
	out.Books = 12
	out.P0Books = 4
	return out
}
