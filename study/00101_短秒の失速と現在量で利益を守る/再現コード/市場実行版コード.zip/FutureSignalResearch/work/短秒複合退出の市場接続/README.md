# 短秒複合退出の市場接続wrapper（準備・人工のみ）

停止した[短秒runtime](../短秒複合退出の再生/停止.json) ff571dを直接importする別module `shortmarket101`。旧runtimeの空SHA拒否、金融f3606e、純式0e2e50、旧100・236コードを変更しない。本CLIはRootが実行前に固定した条件JSONとそのSHAを引数で受け、検査後に停止runtimeの明示値APIを呼ぶ。今回の実行は人工だけで、実市場Native/Tape/sidecar本文、Raw、新日、S市場損益は読んでいない。

## 実行前固定と段階

`--condition-sha` は条件JSONを開く前に形式を確認し、条件bytesのSHAと照合する。試行101/version1・`市場損益を開く前の固定=true`・完全12key・停止/コード/依存/exe・固定100閉鎖/許可54・両stageのTape台帳/sidecar proofを確認する。未固定、不足、型不整合を「未知0」「成功falseの省略」として補わない。

workerは1～4、各場は独立。出力は未使用dirだけを排他的に作る。対象の旧100 Native/Tape/Header/Recordsは指紋確認後にだけ本文へ進む。全code・依存・入力を終了後にも再hashし、不一致/未完があれば`完了.json`を成功にしない。full54は**同条件SHA/同code/同依存のfirst2成功**、先頭2結果gzipのSHA、全12/P0四対照が必須。first2成功の確認は54本文の読取より先に行う。

CLI本番profileは固定100閉鎖SHA4a8bc486…、runtime ff571d、金融 f3606e、純式0e2e50、消費側builder e2901bをコードに保持する。人工で使う縮小署名profileを指定するCLI引数はない。条件SHAの空定数を後で編集する方式は使わない。

## 条件JSON schema

`FileRef = {"path":"…","sha256":"小文字64桁"}`。FileRefの相対pathは**条件JSONのdir基準**、code/Go依存のkeyは**repo root基準（外部依存は絶対pathも可）**。Tape台帳entryの相対pathは**その台帳dir基準**。producer v2/v3 receiptに記録されたpath/headerは旧producer契約の**repo root基準**であり、この区別を明示して条件のFileRefへ照合する。探索fallbackはしない。

```json
{
  "試行": 101,
  "version": 1,
  "市場損益を開く前の固定": true,
  "全12Key": ["P0四→S5Q四→S515Q四の本名（下記APIで取得）"],
  "固定100完了": {"path":"…","sha256":"…"},
  "許可54": {"path":"…","sha256":"…"},
  "市場wrapper停止": {"path":"…/停止.json","sha256":"…"},
  "runtime停止": {"path":"…","sha256":"ff571d…"},
  "金融停止": {"path":"…","sha256":"f3606e…"},
  "純式停止": {"path":"…","sha256":"0e2e50…"},
  "sidecar版2停止": {"path":"…","sha256":"e2901b…"},
  "実行物": {"path":"…/市場接続.exe","sha256":"…"},
  "コードSHA256": {"必須全code＋両producer codeの厳密union":"…"},
  "Go依存SHA256": {"wrapper停止のGo依存全集合":"…"},
  "stages": {
    "first2": {
      "index":{"path":"…","sha256":"…"},
      "sidecar_receipt":{"path":"…/完了.json","sha256":"…"},
      "producer_stop":{"path":"…","sha256":"…"},
      "producer_code":{"producer停止の所有コード全集合":"…"},
      "schema_version":1,
      "scenes":[{"session":"2026-09-21_Day","header":{"path":"…","sha256":"…"},"records":{"path":"…","sha256":"…"}}]
    },
    "full54": {"同じschemaで全54場を固定":"…"}
  }
}
```

上記は説明用で実行可能な条件ではない。完全keyは停止runtimeの `Keys()`。本番のfirst2は9/21Day/Nightの2場、full54は固定100閉鎖に保存された54場だけ。`許可54`は版2の公開`Allowed`型。旧100 Nativeのpath/SHAは閉鎖正本から取得し、条件で別Nativeへ差し替えない。

wrapper停止の`必須コードSHA256`と`Go依存SHA256`を基礎にする。前者にはwrapper本文、固定100の236＋後処理5、金融/純式/runtime/消費側builderの各停止全集合を含める。条件codeはこの基礎と両stageの`producer_code`の厳密union。Rootは完全cacheが揃ってから両stageを固定でき、同条件SHAで2→54へ進める。条件変更時にはfirst2も新条件で確認し直す。

**消費側Go依存と入力producerは別**。このwrapperがimportするMaterializeはe2901b版。入力producerはstage別のstop/code/receiptを固定し、first2が版2・full54が別停止版でも宣言可能。同schema1のtyped Header/Record、内容SHA、全Scalar/Current/Chart出典、旧5分Input全文を検査する。wrapperでnil/emptyや公開値を黙って正規化しない。producer版変更は消費側Go依存の差し替えを意味しない。

## Nativeと独立復元

1場ずつ `SID.json.gz` を保存する。新12Bookは全fieldを維持し、入口 `gate_assessments` は実候補の全checkを保存する。旧100 Native/Tape/sidecar receipt/header/recordsは絶対path＋SHA参照へ留め、旧Shadows/Source全量/全Gridは転載しない。

Sの実candidate/assessmentはBookの`short_exit_events`/`short_exit_point`に保存済み。外部`short_assessments`を再転記せず、key別callback/要求/fill件数の`short_bindings`とstream一巡証拠を保存する。独立器は参照したTape/Grid/stream/Headerから入力を復元し、Book内の完全証拠へ結合できる。

P0四は固定100P0四の全JSONを除外0で比較する。JSONオブジェクトの表記順/空白だけを正規化し、field・配列順・null/空・key/注文ID・数値を削らない。旧100のH0/HGや過去の対99成功を新101成功として使わない。

## Root実行手順（今回未実行）

```powershell
& 'work/短秒複合退出の市場接続/検査/市場接続.exe' `
  --root (Get-Location).Path `
  --condition 'Rootが固定した条件.json' --condition-sha 'その完全SHA256' `
  --stage first2 --workers 1 --out '未使用の先頭2場出力dir'

& 'work/短秒複合退出の市場接続/検査/市場接続.exe' `
  --root (Get-Location).Path `
  --condition '同じ条件.json' --condition-sha '同じ完全SHA256' `
  --stage full54 --workers 1 --first2 '上記/完了.json' `
  --out '未使用の全54場出力dir'
```

## 人工の範囲

停止ff571dの完全Go型2鏡像を再用し、新24口座/旧100公開APIのP0四全文/半円を含む全Book保存再読を確認する。Source/Scalarと手製contextの範囲は元停止を継承し、自然Features/Bank生成の証明にはしない。

ファイルI/O・条件/停止/producer分離の人工だけはprivate profileで署名SHA・code件数・first2件数を1場へ縮小する。金融は同じ実Go API入力であり、偽の金融成績やSource生成値を補わない。54宣言の未対象ファイルは作らず、これは全54成功証拠ではない。CLI本番profileからこの人工は拒否される。実2/54市場実行・新Source/Raw再計算・機会損失の計算は0。

通常検査は `go test -json ./...` / `go vet ./...`。Root条件は別途固定し、このprototypeの停止を市場実行許可としない。
