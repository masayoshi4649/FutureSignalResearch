package shortmarket101

import (
	"encoding/json"

	port "github.com/masayoshi4649/SessionTradeExecuter/actorport97"
	runtime "github.com/masayoshi4649/SessionTradeExecuter/shortport101"
)

type FileRef struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
}
type SceneFiles struct {
	Session string  `json:"session"`
	Header  FileRef `json:"header"`
	Records FileRef `json:"records"`
}
type StageSpec struct {
	Index          FileRef           `json:"index"`
	SidecarReceipt FileRef           `json:"sidecar_receipt"`
	ProducerStop   FileRef           `json:"producer_stop"`
	ProducerCode   map[string]string `json:"producer_code"`
	SchemaVersion  int               `json:"schema_version"`
	Scenes         []SceneFiles      `json:"scenes"`
}
type Condition struct {
	Trial        int                  `json:"試行"`
	Version      int                  `json:"version"`
	Fixed        bool                 `json:"市場損益を開く前の固定"`
	Keys         []string             `json:"全12Key"`
	Proof100     FileRef              `json:"固定100完了"`
	Allowed54    FileRef              `json:"許可54"`
	WrapperStop  FileRef              `json:"市場wrapper停止"`
	RuntimeStop  FileRef              `json:"runtime停止"`
	FinanceStop  FileRef              `json:"金融停止"`
	PureStop     FileRef              `json:"純式停止"`
	BuilderStop  FileRef              `json:"sidecar版2停止"`
	Exe          FileRef              `json:"実行物"`
	Code         map[string]string    `json:"コードSHA256"`
	Dependencies map[string]string    `json:"Go依存SHA256"`
	Stages       map[string]StageSpec `json:"stages"`
}
type Arguments struct {
	Root, Condition, ConditionSHA256, Stage, Output, First2 string
	Workers                                                 int
}
type InputRefs struct {
	Native100      FileRef `json:"native100"`
	Tape           FileRef `json:"tape"`
	SidecarReceipt FileRef `json:"sidecar_receipt"`
	SidecarHeader  FileRef `json:"sidecar_header"`
	SidecarRecords FileRef `json:"sidecar_records"`
	ProducerStop   FileRef `json:"producer_stop"`
}
type ShortCounts struct {
	Callbacks    int `json:"callbacks"`
	ExitRequests int `json:"exit_requests"`
	ExitFills    int `json:"exit_fills"`
}
type P0Match struct {
	Keys            []string `json:"keys"`
	Excluded        []string `json:"excluded"`
	FullJSON        bool     `json:"full_json"`
	Native100SHA256 string   `json:"native100_sha256"`
}
type Envelope struct {
	Scope              string                      `json:"scope"`
	Trial              int                         `json:"trial"`
	Version            int                         `json:"version"`
	Session            string                      `json:"session"`
	Contract           string                      `json:"contract"`
	Books              map[string]json.RawMessage  `json:"books"`
	GateAssessments    []port.GateAssessmentRecord `json:"gate_assessments"`
	ShortBindings      map[string]ShortCounts      `json:"short_bindings"`
	StreamPasses       []runtime.PassReceipt       `json:"stream_passes"`
	Input              InputRefs                   `json:"input"`
	ConditionSHA256    string                      `json:"condition_sha256"`
	Stops              map[string]string           `json:"stops"`
	P0100Match         P0Match                     `json:"p0_100_match"`
	ActualRunComplete  bool                        `json:"actual_run_complete"`
	SourceReexecuted   bool                        `json:"source_reexecuted"`
	FeaturesRecomputed bool                        `json:"features_recomputed"`
	ChartsRecomputed   bool                        `json:"charts_recomputed"`
}
type Outcome struct {
	Session string `json:"session"`
	Path    string `json:"path"`
	SHA256  string `json:"sha256"`
	P0Books int    `json:"p0_books"`
	Books   int    `json:"books"`
	Error   string `json:"error,omitempty"`
}
type Completion struct {
	Scope              string            `json:"scope"`
	Success            bool              `json:"成功"`
	Trial              int               `json:"試行"`
	Stage              string            `json:"stage"`
	ConditionSHA256    string            `json:"条件SHA256"`
	Keys               []string          `json:"全12Key"`
	Results            []Outcome         `json:"結果"`
	Code               map[string]string `json:"コードSHA256"`
	Dependencies       map[string]string `json:"Go依存SHA256"`
	Before             map[string]string `json:"入力前SHA256"`
	After              map[string]string `json:"入力後SHA256"`
	Unchanged          bool              `json:"前後不変"`
	SourceReexecuted   bool              `json:"source_reexecuted"`
	FeaturesRecomputed bool              `json:"features_recomputed"`
	ChartsRecomputed   bool              `json:"charts_recomputed"`
	RawReads           int               `json:"Raw読取"`
}
