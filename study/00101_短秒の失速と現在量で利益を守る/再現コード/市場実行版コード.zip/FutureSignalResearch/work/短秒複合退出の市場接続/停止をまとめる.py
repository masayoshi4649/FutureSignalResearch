"""wrapperのコード/人工ログ/停止由来を結合する。実市場/Sourceを実行しない。"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

WORK = Path(__file__).resolve().parent
ROOT = WORK.parent.parent


def sha(path: Path) -> str:
    """機能: bytes指紋を返す。引数: path(Path)。返り値: str(SHA256)。"""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path):
    """機能: 明示metadataを読む。引数: path(Path)。返り値: object。市場Nativeは指定しない。"""
    return json.loads(path.read_text(encoding="utf-8-sig"))


def stream(path: Path) -> list[dict]:
    """機能: Go連結JSONを分解する。引数: path(Path)。返り値: list[dict]。"""
    text = path.read_text(encoding="utf-8-sig")
    decoder, result, at = json.JSONDecoder(), [], 0
    while at < len(text):
        if text[at].isspace():
            at += 1
            continue
        row, at = decoder.raw_decode(text, at)
        result.append(row)
    return result


def main() -> None:
    """機能: 全検査後に人工停止を排他的保存する。引数: なし。返り値: None。"""
    before = load(WORK / "検査/不変確認の前.json")
    after = {p: sha(Path(p)) for p in before}
    assert before == after
    rows = stream(WORK / "検査/Go通常.jsonl")
    assert not any(r["Action"] == "fail" for r in rows)
    passed = [r["Test"] for r in rows if r["Action"] == "pass" and "Test" in r]
    assert len(passed) == 16 and len([p for p in passed if "/" not in p]) == 3
    assert (WORK / "検査/vet.log").stat().st_size == 0
    assert (WORK / "検査/build.log").stat().st_size == 0
    assert "未固定condition-sha" in (WORK / "検査/CLI_未固定拒否.log").read_text(encoding="utf-8-sig")
    assert not (WORK / "作成禁止").exists()
    required = load(WORK / "検査/必須コード.json")
    own_names = ["types.go", "io.go", "guard.go", "scene.go", "batch.go", "market_test.go", "go.mod", "go.sum", "cmd/run/main.go", "README.md"]
    for name in own_names:
        p = WORK / name
        assert required[str(p.relative_to(ROOT)).replace("\\", "/")] == sha(p)
    # 条件生成の由来/差分/helperも同じ停止へ含める。停止JSON自身をcodeへ入れる循環は作らない。
    for name in ["由来.json", "差分.patch", "停止をまとめる.py"]:
        p = WORK / name
        required[str(p.relative_to(ROOT)).replace("\\", "/")] = sha(p)
    for name, expected in required.items():
        assert sha(ROOT / name) == expected, name
    deps = {}
    for row in stream(WORK / "検査/Go依存.jsonl"):
        if row.get("Standard"):
            continue
        for name in row.get("GoFiles", []) + row.get("CgoFiles", []):
            p = Path(row["Dir"]) / name
            deps[str(p)] = sha(p)
    modules = stream(WORK / "検査/module.jsonl")
    for row in modules:
        p = Path(row.get("GoMod", ""))
        if p.is_file():
            deps[str(p)] = sha(p)
    missing = []
    for link in re.findall(r"\]\(([^)]+)\)", (WORK / "README.md").read_text(encoding="utf-8")):
        if not (WORK / link).exists():
            missing.append(link)
    assert not missing
    exe = WORK / "検査/市場接続.exe"
    record = {
        "成功": True,
        "状態": "市場wrapperの条件/入出力人工だけで停止、Root実データCLI未実行",
        "module": "github.com/masayoshi4649/SessionTradeExecuter/shortmarket101",
        "runtime停止SHA256": "ff571dba63a439e9df2fc855f722da1e506ee26cc1ef483de9aa4356e39e2eb7",
        "金融停止SHA256": "f3606e629a84df0530266d6c43fc89d48df87985841baaaeb0c1471ec6046501",
        "純式停止SHA256": "0e2e50bc391586daf0040cb9abab2b388b3f9ff23980d50d4f0e50eaa3580f9e",
        "builder停止SHA256": "e2901b5a4d0207bb86fb1af579cdc824d8e94cd3d37654ead732ec5a28732869",
        "必須コードSHA256": required,
        "Go依存SHA256": deps,
        "exe": {"path": str(exe), "sha256": sha(exe)},
        "コードSHA256": {name: sha(WORK / name) for name in own_names},
        "由来": load(WORK / "由来.json"),
        "通常検査": {"test_exit": 0, "top成功": 3, "小試験込み成功": 16, "vet_exit": 0, "build_exit": 0, "help_exit": 0, "未固定CLI_exit": 1, "未固定本文読取": 0, "未固定出力作成": 0},
        "人工範囲": {
            "公開値金融": "停止ff571dの2鏡像完全Tapeを再用。24会計全非0、P0四/鏡像の全JSON除外0、S16要求/fillがあることを確認。旧100P0は公開100factoryを同じ人工へ運転。",
            "入出力": "Root署名/件数だけprivate profileで1場へ縮小。CLIでは指定不可。12Book gzip再読/前後hash/新規出力/producer分離を確認。54宣言の未対象ファイルは生成せず、実2/54成功を主張しない。",
            "拒否": ["条件SHA空", "未固定", "12key不足", "依存省略", "code省略", "producer schema差", "停止取り違え", "exeSHA差", "旧Native改変", "stream改変", "full54先頭成功なし", "人工署名を本番CLIへ", "出力再利用", "旧P0field改変", "未計測Source欠落", "first2のfalse欄欠落"],
            "人工出力の保持": "t.TempDir内のNative/条件metadataを保存再読後に破棄。大量の旧入力/Shadowを重複保存せず、停止型・Go検査ログ/コードへ結合。",
        },
        "Native型": "新12Book全field/entry全checks/S件数と結合/stream一巡/旧100-Tape-sidecar path+SHA。外部short_assessments・旧Shadows/全Source/全Gridの重複保存なし。",
        "条件方式": "Root condition JSONと明示--condition-sha。コードの空SHA定数を書き換えない。stage別producer stop/codeとconsumer e290は分離。両stageを同条件へ固定。",
        "path基準": {"条件FileRef": "条件JSON dir", "Tape entry": "Tape台帳dir", "旧producer receipt path/header": "repo root（明示旧契約）", "code/依存": "repo root又は明示絶対path", "fallback": False},
        "前後不変": before == after,
        "前SHA256": before,
        "後SHA256": after,
        "module解決": modules,
        "READMEリンク欠落": missing,
        "未実施": ["Root実データCLI first2/full54", "実市場100Native/Tape/sidecar本文/Raw/新日読取", "Source/特徴/チャート再形成", "S市場損益/機会損失/退出後仮想利益", "新producer3との実金融接続", "本wrapperの独立Python全面検査"],
        "留保": ["producer版3の具体stop/cache SHAはRootの条件へ後から固定する。本停止に未確定値を創作しない。", "private人工profileは署名/件数だけのI/O器具であり本番Rootの認証を満たさない。", "全入力を一場ずつ処理するが新金融Book全fieldは維持するため、大きなtraceを持つ場は相応のメモリ/容量が必要。"],
    }
    record["全所有SHA256"] = {str(p.relative_to(WORK)): sha(p) for p in sorted(WORK.rglob("*")) if p.is_file() and p.name != "停止.json"}
    assert before == {p: sha(Path(p)) for p in before}
    with (WORK / "停止.json").open("x", encoding="utf-8", newline="\n") as f:
        json.dump(record, f, ensure_ascii=False, indent=2)
        f.write("\n")
    print(json.dumps({"停止SHA256": sha(WORK / "停止.json"), "必須code": len(required), "Go依存等": len(deps), "modules": len(modules), "exeSHA256": sha(exe)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
