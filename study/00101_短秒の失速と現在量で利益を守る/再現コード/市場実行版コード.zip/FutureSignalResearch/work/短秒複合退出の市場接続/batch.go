package shortmarket101

import (
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"sync"

	runtime "github.com/masayoshi4649/SessionTradeExecuter/shortport101"
)

// Run はRootが実行前固定した条件だけを受け付けるCLI公開口です。
//
// 引数: args(Arguments)はRoot/条件SHA/stage/新規出力/workerの宣言です。
// 返り値: errorは固定不明/不一致/未完です。人工profileを外部指定する口はありません。
func Run(args Arguments) error { return run(args, productionTrust()) }

// run はmetadata確認後にだけ各場を独立workerへ配送します。
//
// 引数: args(Arguments)、profile(trust)はCLI宣言とprivate規範です。
// 返り値: errorは不一致です。全前後検査後にだけ成功receiptを保存します。
func run(args Arguments, profile trust) error {
	p, err := prepare(args, profile)
	if err != nil {
		return err
	}
	if err = os.MkdirAll(filepath.Dir(p.Output), 0755); err != nil {
		return err
	}
	if err = os.Mkdir(p.Output, 0755); err != nil {
		return fmt.Errorf("出力の排他作成失敗: %w", err)
	}
	jobs, results := make(chan scenePlan), make(chan Outcome, len(p.Scenes))
	var wg sync.WaitGroup
	for i := 0; i < args.Workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for s := range jobs {
				results <- processScene(p, s, args.Stage)
			}
		}()
	}
	go func() {
		for _, s := range p.Scenes {
			jobs <- s
		}
		close(jobs)
		wg.Wait()
		close(results)
	}()
	all := []Outcome{}
	success := true
	for result := range results {
		all = append(all, result)
		if result.Error != "" {
			success = false
		}
		fmt.Printf("場完了 %s 成功=%t\n", result.Session, result.Error == "")
	}
	sort.Slice(all, func(i, j int) bool { return all[i].Session < all[j].Session })
	after := map[string]string{}
	for path, expected := range p.Before {
		h, e := digest(path)
		if e != nil || h != expected {
			success = false
		}
		after[path] = h
	}
	unchanged := reflect.DeepEqual(p.Before, after)
	success = success && unchanged
	completion := Completion{Scope: profile.scope, Success: success, Trial: 101, Stage: args.Stage, ConditionSHA256: p.ConditionSHA, Keys: runtime.Keys(), Results: all, Code: p.Condition.Code, Dependencies: p.Condition.Dependencies, Before: p.Before, After: after, Unchanged: unchanged}
	if err = writeNew(filepath.Join(p.Output, "完了.json"), completion, false); err != nil {
		return err
	}
	if !success {
		return fmt.Errorf("金融/入力/コードが不一致。成功へ読み替えません")
	}
	return nil
}
