package shortmarket101

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
)

// validSHA は小文字十六進の64桁だけを許可します。
//
// 引数: value(string)は宣言指紋です。
// 返り値: boolは正規形式なら真です。
func validSHA(value string) bool { return regexp.MustCompile(`^[0-9a-f]{64}$`).MatchString(value) }

// digest は明示されたファイルをbytesとして一巡hashします。
//
// 引数: path(string)は許可済みの明示pathです。
// 返り値: string/errorはSHA又はIOエラーです。Sourceや数値器を呼びません。
func digest(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	if _, err = io.Copy(h, f); err != nil {
		return "", err
	}
	return fmt.Sprintf("%x", h.Sum(nil)), nil
}

// resolve は指定された一つの基準だけで相対pathを解決します。
//
// 引数: base/path(string)は宣言済み基準dirと値です。
// 返り値: string/errorは絶対pathです。別rootへの推測fallbackはしません。
func resolve(base, path string) (string, error) {
	if path == "" {
		return "", fmt.Errorf("pathが空です")
	}
	if !filepath.IsAbs(path) {
		path = filepath.Join(base, filepath.FromSlash(path))
	}
	return filepath.Abs(path)
}

// verify はFileRefを一つの基準で解決し指紋を確認します。
//
// 引数: base(string)、ref(FileRef)は明示基準と指紋です。
// 返り値: FileRef/errorは絶対path/同SHA又は不整合です。
func verify(base string, ref FileRef) (FileRef, error) {
	if !validSHA(ref.SHA256) {
		return ref, fmt.Errorf("未固定/不正なSHA")
	}
	p, err := resolve(base, ref.Path)
	if err != nil {
		return ref, err
	}
	h, err := digest(p)
	if err != nil || h != ref.SHA256 {
		return ref, fmt.Errorf("固定ファイルSHA差: %s (%v)", p, err)
	}
	return FileRef{Path: p, SHA256: h}, nil
}

// readJSON は明示JSONを一つだけ読み、末尾の別JSONを拒否します。
//
// 引数: path(string)、target(any)はmetadata又は許可済み保存型です。
// 返り値: errorはIO/型/余剰JSONの不整合です。
func readJSON(path string, target any) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()
	return decodeOne(f, target)
}

// requireJSONFields はfalse/0の正当な保存値と欠落/nullを区別します。
//
// 引数: path(string)、names(...string)は小型metadataと必須欄です。
// 返り値: errorは欠落/nullです。未知をfalseへ補完しません。
func requireJSONFields(path string, names ...string) error {
	var value map[string]json.RawMessage
	if err := readJSON(path, &value); err != nil {
		return err
	}
	for _, name := range names {
		raw, ok := value[name]
		if !ok || bytes.Equal(bytes.TrimSpace(raw), []byte("null")) {
			return fmt.Errorf("metadataの必要欄が欠落/null: %s", name)
		}
	}
	return nil
}

// decodeOne はgzipを含むreaderから1JSONだけを読み切ります。
//
// 引数: reader(io.Reader)、target(any)は保存型です。
// 返り値: errorは型/余剰/CRC等の不整合です。未知の旧欄は転記せずskipします。
func decodeOne(reader io.Reader, target any) error {
	d := json.NewDecoder(reader)
	if err := d.Decode(target); err != nil {
		return err
	}
	var extra any
	if err := d.Decode(&extra); err != io.EOF {
		return fmt.Errorf("末尾の余分/不正JSON: %v", err)
	}
	return nil
}

// readGzip は既に指紋確認した保存JSONを解凍して必要欄だけ読みます。
//
// 引数: path(string)、target(any)は許可済みファイルと型です。
// 返り値: errorはIO/gzip/型の不整合です。
func readGzip(path string, target any) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()
	gz, err := gzip.NewReader(f)
	if err != nil {
		return err
	}
	defer gz.Close()
	return decodeOne(gz, target)
}

// writeNew は既存ファイルを変更せずJSONを排他的保存します。
//
// 引数: path(string)、value(any)、compressed(bool)は新規pathと全保存値です。
// 返り値: errorは既存/IO/保存不整合です。失敗を成功へ読み替えません。
func writeNew(path string, value any, compressed bool) error {
	f, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if err != nil {
		return err
	}
	if compressed {
		gz := gzip.NewWriter(f)
		e := json.NewEncoder(gz).Encode(value)
		ge := gz.Close()
		fe := f.Close()
		if e != nil {
			return e
		}
		if ge != nil {
			return ge
		}
		return fe
	}
	e := json.NewEncoder(f).Encode(value)
	fe := f.Close()
	if e != nil {
		return e
	}
	return fe
}

// canonical は全JSONの値/配列/nullを保ちオブジェクト順と空白だけを揃えます。
//
// 引数: raw(json.RawMessage)は保存された全Bookです。
// 返り値: []byte/errorは全値の正規表記です。fieldの除外やラベル変更はしません。
func canonical(raw json.RawMessage) ([]byte, error) {
	var value any
	if err := json.Unmarshal(raw, &value); err != nil {
		return nil, err
	}
	return json.Marshal(value)
}

// equalJSON は全fieldを除外0で比較します。
//
// 引数: a/b(json.RawMessage)は新旧の同口座です。
// 返り値: bool/errorは完全同値又はJSON不整合です。
func equalJSON(a, b json.RawMessage) (bool, error) {
	x, e := canonical(a)
	if e != nil {
		return false, e
	}
	y, e := canonical(b)
	return e == nil && bytes.Equal(x, y), e
}
