package main

import (
	"flag"
	"fmt"
	"os"

	app "github.com/masayoshi4649/SessionTradeExecuter/shortmarket101"
)

// main はRootが固定した条件JSONとSHAを明示したときだけ実行します。
//
// 引数: os.Args([]string)は条件/stage/新規出力/workerです。
// 返り値: ありません。拒否/不一致は非0、helpは0です。
func main() {
	var a app.Arguments
	flag.StringVar(&a.Root, "root", "", "repo root")
	flag.StringVar(&a.Condition, "condition", "", "Root固定条件JSON")
	flag.StringVar(&a.ConditionSHA256, "condition-sha", "", "実行前に固定した条件SHA256")
	flag.StringVar(&a.Stage, "stage", "first2", "first2/full54")
	flag.StringVar(&a.Output, "out", "", "未使用の新規dir")
	flag.StringVar(&a.First2, "first2", "", "full54用の同条件first2完了.json")
	flag.IntVar(&a.Workers, "workers", 1, "1..4")
	flag.Parse()
	if err := app.Run(a); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
