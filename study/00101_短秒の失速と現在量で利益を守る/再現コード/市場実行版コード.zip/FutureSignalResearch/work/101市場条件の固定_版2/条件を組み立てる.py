"""Root実行前のmetadataだけから101市場条件を組み立てる。本文の解凍/金融実行はしない。"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import tempfile
from pathlib import Path

PROOF100_SHA = "4a8bc486e329f65f17e2395f781b2efd7cf76c5630d91924b611e90254725af3"
WRAPPER_SHA = "2657346bc6a2bf0f759c5275de15ef52db49da752979fd3ccac0890b90e96767"
PRODUCER_SHA = "cf49b2b643afcfda478a5d383c6d5e73bbbee3b477d2a0edc0e45b745ef4d16c"
FIRST2_SHA = "e1a29ceef23ca53424ac8d45b9d2e78566d2e1c885a647ec846da6cb0e9c7c48"
STUDY100 = "study/00100_費用後利益化の前後で保護を分ける"
COMPONENTS = {
    "runtime停止": ("work/短秒複合退出の再生/停止.json", "runtime停止SHA256", "コードSHA256"),
    "金融停止": ("work/短秒複合退出の金融/停止.json", "金融停止SHA256", "コードSHA256"),
    "純式停止": ("work/短秒複合退出の純式/停止.json", "純式停止SHA256", "コードSHA256"),
    "sidecar版2停止": ("work/101連続入力の試作_版2/停止.json", "builder停止SHA256", "所有コードSHA256"),
}


def demand(ok: bool, reason: str) -> None:
    """機能: 未固定/欠測をfailにする。引数: ok(bool),reason(str)。返り値: None。"""
    if not ok:
        raise ValueError(reason)


def is_sha(value) -> bool:
    """機能: 指紋の形式を確認する。引数: value(object)。返り値: bool。"""
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def resolve(base: Path, value: str) -> Path:
    """機能: 一つの基準だけでpathを解決する。引数: base(Path),value(str)。返り値: Path。"""
    demand(isinstance(value, str) and bool(value), "path欠落")
    p = Path(value)
    return (p if p.is_absolute() else base / p).resolve()


def keys() -> list[str]:
    """機能: 固定12本名を列挙する。引数: なし。返り値: list[str]。"""
    return [f"{prefix}E3S_B5Q_P0_C{c}_D{d}" for prefix in ("", "S5Q_", "S515Q_") for c in (0, 5) for d in (0, 1)]


class Check:
    """metadata読取と圧縮bytesのhashを分けて記録する。解凍/売買/指標計算は行わない。"""

    def __init__(self):
        """機能: 確認mapを作る。引数: なし。返り値: None。"""
        self.hashes: dict[str, str] = {}
        self.metadata: list[str] = []

    def file(self, path: Path, expected: str) -> Path:
        """機能: bytes指紋を確認する。引数: path(Path),expected(str)。返り値: Path。"""
        path = path.resolve()
        demand(is_sha(expected), f"SHA未固定: {path}")
        demand(path.is_file(), f"未完成/ファイル欠落: {path}")
        h = hashlib.sha256()
        with path.open("rb") as f:
            for block in iter(lambda: f.read(1024 * 1024), b""):
                h.update(block)
        actual = h.hexdigest()
        demand(actual == expected, f"SHA差: {path}")
        demand(str(path) not in self.hashes or self.hashes[str(path)] == expected, "同path異指紋")
        self.hashes[str(path)] = expected
        return path

    def meta(self, path: Path, expected: str) -> dict:
        """機能: 固定metadata JSONだけを読む。引数: path(Path),expected(str)。返り値: dict。"""
        path = self.file(path, expected)
        self.metadata.append(str(path))
        value = json.loads(path.read_text(encoding="utf-8-sig"))
        demand(isinstance(value, dict), f"metadata型差: {path}")
        return value


def ref(out_dir: Path, path: Path, sha: str) -> dict:
    """機能: 出力条件dir基準の参照を作る。引数: out_dir/path(Path),sha(str)。返り値: dict。"""
    demand(is_sha(sha), "参照SHA不備")
    return {"path": os.path.relpath(path.resolve(), out_dir.resolve()).replace("\\", "/"), "sha256": sha}


def file_ref(base: Path, value: dict) -> tuple[Path, str]:
    """機能: 宣言済み参照を取り出す。引数: base(Path),value(dict)。返り値: tuple[Path,str]。"""
    demand(isinstance(value, dict) and set(value) >= {"path", "sha256"}, "FileRef欠落")
    demand(is_sha(value["sha256"]), "FileRef SHA欠落")
    return resolve(base, value["path"]), value["sha256"]


def bind_readback_producer(stage: str, value: dict, root: Path, producer_path: Path, producer_sha: str) -> None:
    """
    機能: stageごとの実readback契約でproducerを厳密に結ぶ。
    引数: stage(str)、value(dict)、root/producer_path(Path)、producer_sha(str)はRoot固定参照。
    返り値: None。first2は旧builder欄、full54はproducer_stopのpath/SHAだけを必須とする。
    """
    if stage == "first2":
        demand(value.get("builder停止SHA256") == producer_sha, "first2 readback/producer SHA差")
    else:
        demand(stage == "full54", "未定義readback stage")
        declared = value.get("producer_stop")
        demand(isinstance(declared, dict) and set(declared) == {"path", "sha256"}, "full54 producer_stop欠落/型差")
        demand(is_sha(declared["sha256"]) and declared["sha256"] == producer_sha,
               "full54 readback/producer SHA差")
        demand(resolve(root, declared["path"]) == producer_path.resolve(), "full54 readback/producer path差")


def required_code(check: Check, root: Path, code: dict) -> None:
    """機能: code/deps全件を検査する。引数: check(Check),root(Path),code(dict)。返り値: None。"""
    demand(isinstance(code, dict) and bool(code), "code/deps集合欠落")
    for name, sha in code.items():
        check.file(resolve(root, name), sha)


def assemble(args, *, _proof_sha: str = PROOF100_SHA, _counts: tuple[int, int, int] = (299, 250, 13)) -> tuple[dict, dict]:
    """機能: 全metadataと現物hashから条件を作る。引数: args(Namespace)、private人工置換。返り値: tuple[dict,dict]。"""
    root = Path(args.root).resolve()
    out = Path(args.out).resolve()
    receipt_path = out.with_name(out.stem + "_確認.json")
    demand(not out.exists() and not receipt_path.exists(), "条件/確認は未使用の新規JSONのみ")
    demand(out.suffix.lower() == ".json", "--outはJSON")
    check = Check()
    wrapper_path = resolve(root, args.wrapper_stop)
    producer_path = resolve(root, args.producer_stop)
    wrapper = check.meta(wrapper_path, args.wrapper_stop_sha)
    producer = check.meta(producer_path, args.producer_stop_sha)
    demand(wrapper.get("成功") is True and producer.get("成功") is True, "wrapper/producer停止未完")
    demand(wrapper.get("module") == "github.com/masayoshi4649/SessionTradeExecuter/shortmarket101", "wrapper型差")
    code, deps, pc = wrapper.get("必須コードSHA256"), wrapper.get("Go依存SHA256"), producer.get("所有コードSHA256")
    demand(isinstance(code, dict) and len(code) == _counts[0] and isinstance(deps, dict) and len(deps) == _counts[1] and isinstance(pc, dict) and len(pc) == _counts[2], "停止の完全code/deps件数差")
    code = dict(code)
    for name, sha in pc.items():
        demand(name not in code or code[name] == sha, "producer/consumer同path異指紋")
        code[name] = sha
    required_code(check, root, code)
    required_code(check, root, deps)
    exe_path, exe_sha = file_ref(root, wrapper.get("exe"))
    check.file(exe_path, exe_sha)
    condition = {"試行": 101, "version": 1, "市場損益を開く前の固定": True, "全12Key": keys(),
                 "市場wrapper停止": ref(out.parent, wrapper_path, args.wrapper_stop_sha),
                 "実行物": ref(out.parent, exe_path, exe_sha), "コードSHA256": code, "Go依存SHA256": deps, "stages": {}}
    for label, (name, field, code_field) in COMPONENTS.items():
        path = resolve(root, name)
        expected = wrapper.get(field)
        value = check.meta(path, expected)
        demand(value.get("成功") is True, f"停止未完: {label}")
        declared = value.get(code_field)
        demand(isinstance(declared, dict) and bool(declared), f"停止code欠落: {label}")
        for k, sha in declared.items():
            target = resolve(root if label == "sidecar版2停止" else path.parent, k)
            matching = [h for n, h in code.items() if resolve(root, n) == target]
            demand(bool(matching) and set(matching) == {sha}, f"wrapper必須codeの省略: {target}")
        condition[label] = ref(out.parent, path, expected)
    proof_path = root / STUDY100 / "完了記録.json"
    proof = check.meta(proof_path, _proof_sha)
    demand(proof.get("試行") == 100 and proof.get("比較保存完了") is True and proof.get("場数") == 54, "固定100閉鎖未完")
    catalog = {}
    for name, sha in proof.get("自己を除く正式指紋", {}).items():
        match = re.fullmatch(r"成果物/(\d{4}-\d{2}-\d{2}_(?:Day|Night))\.json\.gz", name.replace("\\", "/"))
        if match:
            demand(match[1] not in catalog and is_sha(sha), "100Native重複/SHA不正")
            catalog[match[1]] = sha
    demand(len(catalog) == 54, "100Nativeの許可54不足")
    ids54 = sorted(catalog)
    ids2 = ["2026-09-21_Day", "2026-09-21_Night"]
    demand(set(ids2) <= set(catalog), "固定先頭2場がない")
    allowed_names = [name for name in pc if Path(name).name == "許可54.json"]
    demand(len(allowed_names) == 1, "producerの許可54正本が非一意")
    allowed_path = resolve(root, allowed_names[0])
    allowed_sha = pc[allowed_names[0]]
    allowed = check.meta(allowed_path, allowed_sha)
    expected_allowed = [{"session": sid, "native_sha256": catalog[sid]} for sid in ids54]
    demand(allowed == {"version": 1, "proof100_sha256": _proof_sha, "entries": expected_allowed}, "許可54と固定100差")
    condition["固定100完了"] = ref(out.parent, proof_path, _proof_sha)
    condition["許可54"] = ref(out.parent, allowed_path, allowed_sha)
    cached: dict[str, dict] = {}
    index_names = {"first2": "接続2場Tape台帳.json", "full54": "正式54Tape台帳.json"}
    for stage, receipt_arg, receipt_sha in [("first2", args.first2_receipt, args.first2_sha), ("full54", args.full54_receipt, args.full54_sha)]:
        expected_ids = ids2 if stage == "first2" else ids54
        cache_path = resolve(root, receipt_arg)
        cache = check.meta(cache_path, receipt_sha)
        for field, value in {"成功": True, "前後不変": True, "scope": "固定100と旧Tapeの連続技法sidecar構築", "stage": stage,
                             "固定100完了SHA256": _proof_sha, "source_reexecuted": False, "financial_executed": False,
                             "features_recomputed": True, "charts_recomputed": True, "所有コードSHA256": pc}.items():
            demand(field in cache and type(cache[field]) is type(value) and cache[field] == value, f"cache未完/型差: {stage}/{field}")
        demand(cache.get("sessions") == expected_ids, f"cache場順/全集合差: {stage}")
        details = cache.get("details")
        demand(isinstance(details, list) and len(details) == len(expected_ids), "cache明細不足")
        by_id = {}
        for d in details:
            demand(isinstance(d, dict) and isinstance(d.get("session"), str) and d["session"] not in by_id, "cache明細の型/重複")
            by_id[d["session"]] = d
        demand(set(by_id) == set(expected_ids), "cache欠落/追加場")
        index_path = root / STUDY100 / index_names[stage]
        index_sha = proof.get("自己を除く正式指紋", {}).get(index_names[stage])
        index = check.meta(index_path, index_sha)
        demand(index.get("version") == 1 and index.get("stage") == stage, "Tape台帳版/stage差")
        entries = index.get("entries")
        demand(isinstance(entries, list) and len(entries) == len(expected_ids), "Tape台帳場数差")
        seen, scenes = set(), []
        for e in entries:
            sid = e.get("session")
            demand(sid in by_id and sid not in seen, "Tape台帳追加/重複")
            seen.add(sid)
            tape_path, tape_sha = file_ref(index_path.parent, e)
            check.file(tape_path, tape_sha)
            native_path = root / STUDY100 / "成果物" / (sid + ".json.gz")
            check.file(native_path, catalog[sid])
            d = by_id[sid]
            header_path, records_path = resolve(root, d.get("header")), resolve(root, d.get("path"))
            check.file(header_path, d.get("header_SHA256"))
            check.file(records_path, d.get("SHA256"))
            scenes.append({"session": sid, "header": ref(out.parent, header_path, d["header_SHA256"]), "records": ref(out.parent, records_path, d["SHA256"])})
        demand(seen == set(expected_ids), "Tape台帳欠落")
        condition["stages"][stage] = {"index": ref(out.parent, index_path, index_sha), "sidecar_receipt": ref(out.parent, cache_path, receipt_sha),
                                       "producer_stop": ref(out.parent, producer_path, args.producer_stop_sha), "producer_code": pc, "schema_version": 1,
                                       "scenes": sorted(scenes, key=lambda s: s["session"])}
        cached[stage] = {"path": cache_path, "sha": receipt_sha, "by_id": by_id, "ids": expected_ids}
    evidence_path = resolve(root, args.side_evidence)
    manifest = check.meta(evidence_path, args.side_evidence_sha)
    roles = {"first2_readback", "first2_ending", "full54_readback", "full54_ending"}
    demand(manifest.get("version") == 1 and isinstance(manifest.get("evidence"), dict) and set(manifest["evidence"]) == roles, "side evidenceの4役割が不足")
    evidence = {}
    for role, declared in sorted(manifest["evidence"].items()):
        stage = role.split("_", 1)[0]
        path, expected = file_ref(evidence_path.parent, declared)
        value = check.meta(path, expected)
        demand(value.get("成功") is True and value.get("前後不変") is True and isinstance(declared.get("scope"), str) and declared["scope"] and value.get("scope") == declared["scope"], f"side evidence成功/範囲差: {role}")
        c = cached[stage]
        if role.endswith("readback"):
            demand(value.get("stage") == stage and value.get("sessions") == c["ids"] and value.get("入力構築receiptSHA256") == c["sha"], f"readback/cache結合差: {role}")
            bind_readback_producer(stage, value, root, producer_path, args.producer_stop_sha)
            rows = value.get("details")
            demand(isinstance(rows, list) and len(rows) == len(c["ids"]), f"readback明細欠落: {role}")
            done = set()
            for d in rows:
                sid = d.get("session")
                demand(sid in c["by_id"] and sid not in done and d.get("成功") is True and d.get("処理完了") is True and d.get("前後不変") is True and type(d.get("不一致")) is int and d["不一致"] == 0, f"readbackの場完了/差0不明: {role}")
                hashes = d.get("入力SHA256")
                demand(isinstance(hashes, dict), "readbackの入力指紋欠落")
                cache_detail = c["by_id"][sid]
                for path_key, hash_key in [("header", "header_SHA256"), ("path", "SHA256")]:
                    target = resolve(root, cache_detail[path_key])
                    matched = [h for name, h in hashes.items() if resolve(root, name) == target]
                    demand(matched and set(matched) == {cache_detail[hash_key]}, f"readbackのheader/records参照差: {role}/{sid}")
                done.add(sid)
        else:
            endings = value.get("場末")
            demand(isinstance(endings, list) and len(endings) == len(c["ids"]), f"Ending場数不足: {role}")
            done = set()
            for d in endings:
                sid = d.get("session")
                demand(sid in c["by_id"] and sid not in done and d.get("一致") is True and d.get("field除外") == [] and d.get("header_SHA256") == c["by_id"][sid]["header_SHA256"] and d.get("元NativeSHA256") == catalog[sid], f"Ending/原Native/header結合差: {role}")
                done.add(sid)
        evidence[role] = {**ref(out.parent, path, expected), "scope": declared["scope"]}
    # ----------------------------------------
    # 条件schemaはGo停止版のまま。side evidenceは小receiptへだけ保存する。
    body = (json.dumps(condition, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    before = dict(check.hashes)
    receipt = {"成功": True, "scope": "Root前固定metadataの条件組立（金融/本文解凍なし）", "condition": {"path": out.name, "sha256": hashlib.sha256(body).hexdigest()},
               "helper_SHA256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "side_evidence_manifest": ref(out.parent, evidence_path, args.side_evidence_sha),
               "side_evidence": evidence, "入力SHA256": check.hashes, "metadata読取": check.metadata,
               "code数": len(code), "Go依存数": len(deps), "全12Key": keys(), "S金融/Source/Raw/Native/stream本文解凍/採否/損益計算": 0}
    # 最後の検査もpublish前に済ませる。本文JSON化/解凍対象はmetadataだけ。
    for path, expected in tuple(check.hashes.items()):
        check.file(Path(path), expected)
    receipt["入力前SHA256"] = before
    receipt["入力後SHA256"] = dict(check.hashes)
    receipt["前後不変"] = before == check.hashes
    demand(receipt["前後不変"], "publish前の入力指紋差")
    return condition, receipt


def publish(args, condition: dict, receipt: dict) -> None:
    """機能: 検査済み条件と小receiptを新規保存する。引数: args/condition/receipt。返り値: None。"""
    out = Path(args.out).resolve()
    proof = out.with_name(out.stem + "_確認.json")
    demand(not out.exists() and not proof.exists(), "出力使用済み")
    condition_body = (json.dumps(condition, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    demand(hashlib.sha256(condition_body).hexdigest() == receipt["condition"]["sha256"], "候補bytes差")
    receipt_body = (json.dumps(receipt, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    out.parent.mkdir(parents=True, exist_ok=True)
    candidates = []
    published_proof = False
    try:
        for payload in [receipt_body, condition_body]:
            with tempfile.NamedTemporaryFile(prefix=".101候補-", dir=out.parent, delete=False) as f:
                candidates.append(Path(f.name))
                f.write(payload)
                f.flush()
                os.fsync(f.fileno())
        demand(candidates[0].read_bytes() == receipt_body and candidates[1].read_bytes() == condition_body, "候補保存bytes差")
        # hardlinkは新規targetだけへ原子的にpublishする。条件はすべての検査後に最後に公開。
        os.link(candidates[0], proof)
        published_proof = True
        os.link(candidates[1], out)
    except BaseException:
        if published_proof:
            proof.unlink()
        raise
    finally:
        for path in candidates:
            try:
                path.unlink(missing_ok=True)
            except OSError:
                # publish後のcleanupを検証失敗へ読み替えない。候補名は条件参照に使わない。
                pass


def parser() -> argparse.ArgumentParser:
    """機能: Rootが前固定する入力を宣言する。引数: なし。返り値: ArgumentParser。"""
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root", required=True)
    p.add_argument("--wrapper-stop", default="work/短秒複合退出の市場接続/停止.json")
    p.add_argument("--wrapper-stop-sha", default=WRAPPER_SHA)
    p.add_argument("--producer-stop", default="work/101連続入力の試作_版3/停止.json")
    p.add_argument("--producer-stop-sha", default=PRODUCER_SHA)
    p.add_argument("--first2-receipt", default="work/101連続入力の実行/接続2場_版3/完了.json")
    p.add_argument("--first2-sha", default=FIRST2_SHA)
    p.add_argument("--full54-receipt", required=True)
    p.add_argument("--full54-sha", required=True)
    p.add_argument("--side-evidence", required=True)
    p.add_argument("--side-evidence-sha", required=True)
    p.add_argument("--out", required=True)
    return p


def main() -> None:
    """機能: 全検査後にだけ条件を保存する。引数: CLI。返り値: None。"""
    args = parser().parse_args()
    condition, receipt = assemble(args)
    publish(args, condition, receipt)
    print(receipt["condition"]["sha256"])


if __name__ == "__main__":
    main()
