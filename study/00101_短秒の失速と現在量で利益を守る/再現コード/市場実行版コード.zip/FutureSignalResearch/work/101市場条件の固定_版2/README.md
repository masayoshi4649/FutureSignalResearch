# 101市場条件のRoot前固定helper・読戻しstage契約版2

旧[helper停止b698](../101市場条件の固定/停止.json)は変更しない。新しい条件の作成・市場本文の解凍・金融実行は今回行わず、opaque bytesとmetadataによる人工だけを確認する。

変更はreadbackのproducer結合だけである。first2は従来どおり`builder停止SHA256`を必須とする。full54は、[停止a75の実出力コード](../101連続入力の全54場_版3/全54場を読み戻す.py)が保存する`producer_stop={path,sha256}`を必須とし、pathをrepo rootから解決して`--producer-stop`の解決済みpathへ、SHAを`--producer-stop-sha`へ完全一致させる。同じbytesを持つ別pathも拒否する。full54に旧builder欄だけがある場合は受理しない。欠落時の補完やschemaの推測は行わない。

条件本体のGo schema・全12Key・299＋13のコードunion・250のGo依存・exe・両cache/両Tape/許可54/固定100閉鎖・4役割のside evidence・全場Header/Recordsのbytes指紋・publish前の再hashと排他保存は旧版と同じである。Header/Records/Tape/Nativeはbytesの指紋のみ扱い、意味展開しない。FileRefは出力条件dir、code/Go依存はrepo root又は明示絶対path、Tape entryは台帳dir、producer receiptのpath/headerとreadback full54のproducer_stop.pathはrepo root基準である。

消費側builder e290と入力producer cf49を区別する。canonical4moduleは別の対応版であり、この実行用work停止版を差し替えない。

## Root実行方法（今回未実行）

全54読戻し成功・差0・前後不変と、first2/full54のreadback/Endingの4証拠SHAがそろってから、Rootが別manifestを固定する。`--side-evidence`の形は[旧README](../101市場条件の固定/README.md#side-evidence-manifest)と同じである。

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101市場条件の固定_版2/条件を組み立てる.py' `
  --root (Get-Location).Path `
  --wrapper-stop 'work/短秒複合退出の市場接続/停止.json' `
  --wrapper-stop-sha '2657346bc6a2bf0f759c5275de15ef52db49da752979fd3ccac0890b90e96767' `
  --producer-stop 'work/101連続入力の試作_版3/停止.json' `
  --producer-stop-sha 'cf49b2b643afcfda478a5d383c6d5e73bbbee3b477d2a0edc0e45b745ef4d16c' `
  --first2-receipt 'work/101連続入力の実行/接続2場_版3/完了.json' `
  --first2-sha 'e1a29ceef23ca53424ac8d45b9d2e78566d2e1c885a647ec846da6cb0e9c7c48' `
  --full54-receipt 'work/101連続入力の全54場_版3/生成/完了.json' `
  --full54-sha '9ed1a959d9178f6ff6d4f4402c886cc81fc90aced7846d5d8c706f44ef0b0cd3' `
  --side-evidence 'Rootが固定した4前提manifest.json' --side-evidence-sha 'その完全SHA' `
  --out '未使用の101条件.json'
```

出力は条件JSONと`<stem>_確認.json`。確認receiptにはhelper自身・4証拠・全確認入力の前後指紋を保存する。helper自身やside evidenceを条件codeへ足すと停止wrapperの厳密unionを壊すため、条件schemaは増やさない。同条件SHAで金融first2→その独立監査→full54へ進め、条件変更時はfirst2から確認する。

## 人工と差分

`metadata_test.py`は旧4topを再用し、full54 fixtureを実schemaへ変えた。7種類のfull54破損（producer欄欠落、SHA欠落、偽SHA、path欠落、空path、同体別path、旧builder欄だけ）、first2旧SHA破損、full54の相対/絶対path正常を追加する。opaqueなNative/Tape/Header/Records/実行物を解凍しない。private署名/件数置換はテスト関数のみで、CLIからは指定できない。

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101市場条件の固定_版2/metadata_test.py'
```

`差分.patch`と`由来と差分.json`に旧SHA、変更箇所、その他関数AST同一を記録する。今回の成功はmetadata接続人工であり、実cacheにhelperを実行した証拠でも新しい金融成功でもない。archiveの保存候補は旧b698を根拠に作成途中で保留し、zip/manifestは未生成のまま、別作業として再開を待つ。
