"""固定readback核を無改変で全54cacheへ委譲する。準備中は人工だけ。"""

import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor,as_completed
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CORE_PATH=ROOT/'work/101連続入力の読取照合/読み戻しを照合する.py'
CORE_SHA='00d8c55f12a43e31be3857feadae9373ac53901efcbbeff394fb0eef27543345'
BUILDER=ROOT/'work/101連続入力の試作_版2/停止.json'
BUILDER_SHA='e2901b5a4d0207bb86fb1af579cdc824d8e94cd3d37654ead732ec5a28732869'
FIRST=ROOT/'work/101連続入力の読取照合/実2場.json'
FIRST_SHA='fb5341772170b68444ff95c5a656bef2a7fcf57ed1cf4369b13b2988b616425a'
FIRST_RECEIPT=ROOT/'work/101連続入力の実行/接続2場_版2/完了.json'
FIRST_RECEIPT_SHA='1771bde305487fac60045c878f4ccdf827d0b98f2963a6cf876e5528909128bd'
PROOF=ROOT/'study/00100_費用後利益化の前後で保護を分ける/完了記録.json'
PROOF_SHA='4a8bc486e329f65f17e2395f781b2efd7cf76c5630d91924b611e90254725af3'
ALLOWED=BUILDER.with_name('許可54.json');ALLOWED_SHA='04916ef4de2ce12568a2d76cbf66d25e3ff42e73cadd187ca5be8996635c462e'
INPUT=ROOT/'work/101連続入力の全54場/生成'
SCOPE='固定100許可54の連続入力の全保存record読戻し・技法値の再生成なし'
FIRST_SCOPE='固定100由来の連続入力first2の全保存record読戻し・技法値の再生成なし'
CONDITION_KEYS={'version','scope','stage','builder停止SHA256','読戻し核SHA256','first2readbackSHA256','first2生成receiptSHA256','固定100完了SHA256','許可54SHA256','生成receiptSHA256','生成先','監査コードSHA256','実行前固定','Source再実行','金融実行','特徴再生成','退出採否'}


def sha(path):
    """
    機能: 明示コード又は許可ファイルをhashする。
    引数: path(Path)は対象。
    返り値: strはSHA256。入力探索はしない。
    """
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


if sha(CORE_PATH)!=CORE_SHA:raise ValueError('固定核SHA差')
SPEC=importlib.util.spec_from_file_location('固定101readback核_全54',CORE_PATH);CORE=importlib.util.module_from_spec(SPEC);sys.modules[SPEC.name]=CORE;SPEC.loader.exec_module(CORE)
need=CORE.need


def load(path):
    """
    機能: 停止核のJSON parserへ明示metadata/headerを渡す。
    引数: path(Path)は対象。
    返り値: objectは既存parserの値。parserを複写しない。
    """
    return CORE.loads(path.read_text(encoding='utf-8'))


def owned():
    """
    機能: wrapperの所有5ファイルを固定する。
    引数: なし。
    返り値: dict[str,str]はrepo相対path→SHA。
    """
    return {str((HERE/name).relative_to(ROOT)).replace('\\','/'):sha(HERE/name) for name in ('全54場を読み戻す.py','人工を確認する.py','計画.md','README.md','実行条件の雛形.json')}


def catalog():
    """
    機能: 閉鎖4a8とe290許可54をmetadataだけで一致させる。
    引数: なし。
    返り値: tuple[list[str],dict]は完全54IDと旧閉鎖。Nativeを開かない。
    """
    need(sha(PROOF)==PROOF_SHA and sha(ALLOWED)==ALLOWED_SHA,'固定閉鎖/許可54 SHA');p=load(PROOF);a=load(ALLOWED);need(p['比較保存完了'] is True and p['試行']==100 and p['場数']==54,'固定100完了')
    expected=[]
    for name,h in p['自己を除く正式指紋'].items():
        m=re.fullmatch(r'成果物/(\d{4}-\d{2}-\d{2}_(?:Day|Night))\.json\.gz',name.replace('\\','/'))
        if m:expected.append({'session':m[1],'native_sha256':h})
    expected.sort(key=lambda x:x['session']);need(a=={'version':1,'proof100_sha256':PROOF_SHA,'entries':expected} and len(expected)==54 and len({r['session'] for r in expected})==54,'完全54台帳全値')
    return [r['session'] for r in expected],p


def validate_first(first,receipt):
    """
    機能: first2成功を元receipt/各3入力SHAへ結ぶ。
    引数: first/receipt(dict)は停止readbackと元構築metadata。
    返り値: None。54成功とは扱わない。
    """
    ids=['2026-09-21_Day','2026-09-21_Night'];need(first['成功'] is True and first['前後不変'] is True and first['scope']==FIRST_SCOPE and first['stage']=='first2' and first['sessions']==ids,'first2成功scope')
    need(first['入力構築receiptSHA256']==FIRST_RECEIPT_SHA and first['builder停止SHA256']==BUILDER_SHA and receipt['成功'] is True and receipt['sessions']==ids and receipt['stage']=='first2','first2元構築bind')
    by={r['session']:r for r in first['details']};need(set(by)==set(ids) and len(first['details'])==2,'first2全2詳細')
    for r in receipt['details']:
        d=by[r['session']];need(d['成功'] is True and d['処理完了'] is True and d['不一致']==0 and d['前後不変'] is True and len(d['入力SHA256'])==3,'first2場成功/3SHA')
        outputs={str((ROOT/r[name]).resolve()):r[field] for name,field in (('header','header_SHA256'),('path','SHA256'))}
        for key,h in d['入力SHA256'].items():
            need(first['入力codeSHA256前'][key]==h==first['入力codeSHA256後'][key],'first2readback入力前後bind')
            need(outputs.get(key,receipt['入力コードSHA256前後'].get(key))==h,'first2生成出力/旧Tape SHA bind')
        need(set(outputs)<=set(d['入力SHA256']),'first2header/stream集合')


def validate_completion(receipt,ids,builder):
    """
    機能: 同版builderの完全54成功metadataを検査する。
    引数: receipt/builder(dict)、ids(list[str])は生成完了/停止/許可集合。
    返り値: None。header/stream本文はまだ開かない。
    """
    need(set(receipt)=={'成功','scope','stage','固定100完了SHA256','sessions','所有コードSHA256','入力コードSHA256前後','前後不変','details','source_reexecuted','financial_executed','features_recomputed','charts_recomputed'},'builder receipt全tag')
    CORE.PURE.PUBLIC.finite_tree(receipt)
    need(receipt['成功'] is True and receipt['前後不変'] is True and receipt['scope']=='固定100と旧Tapeの連続技法sidecar構築' and receipt['stage']=='full54' and receipt['sessions']==ids and len(ids)==54 and len(set(ids))==54,'同版完全54成功scope')
    need(receipt['固定100完了SHA256']==PROOF_SHA and receipt['所有コードSHA256']==builder['所有コードSHA256'],'builder同版/閉鎖')
    need(receipt['source_reexecuted'] is False and receipt['financial_executed'] is False and receipt['features_recomputed'] is True and receipt['charts_recomputed'] is True,'構築と監査のscope区別')
    need(len(receipt['details'])==54 and {d['session'] for d in receipt['details']}==set(ids),'54場詳細集合/重複')
    need(type(receipt['入力コードSHA256前後']) is dict and receipt['入力コードSHA256前後'] and all(type(p) is str and re.fullmatch('[0-9a-f]{64}',h or '') for p,h in receipt['入力コードSHA256前後'].items()),'builder入力SHA全型')
    for d in receipt['details']:
        need(set(d)=={'session','path','SHA256','header','header_SHA256','圧縮bytes','場全経過秒','stream統計','資源上限','旧Scalar/全5分Input','旧Ending全文比較','Ending範囲','品質'},'builder場詳細全tag')
        need(all(type(d[k]) is str for k in ('session','path','header','Ending範囲')) and all(re.fullmatch('[0-9a-f]{64}',d[k] or '') for k in ('SHA256','header_SHA256')),'場詳細path/SHA型')
        need(type(d['圧縮bytes']) is int and d['圧縮bytes']>0 and d['場全経過秒']>=0 and d['旧Ending全文比較'] is False,'場保存量/範囲')
        stats=d['stream統計'];need(set(stats)=={'records','rows','elapsed_seconds','sampled_go_heap_max_bytes','sampled_go_sys_max_bytes','sample_interval_records'} and all(type(stats[k]) is int and stats[k]>=0 for k in ('records','rows','sampled_go_heap_max_bytes','sampled_go_sys_max_bytes','sample_interval_records')) and stats['records']>=stats['rows'] and stats['elapsed_seconds']>=0,'stream統計全型')


def validate_condition(condition,receipt_sha,input_path,code):
    """
    機能: Rootの実行前条件を完全keyと値で検査する。
    引数: condition(dict)、receipt_sha(str)、input_path(Path)、code(dict)は条件/明示SHA/入力/所有指紋。
    返り値: None。未固定/空placeholderを本文前に拒否。
    """
    need(set(condition)==CONDITION_KEYS,'条件全key')
    need(type(condition['version']) is int and condition['version']==1 and condition['scope']==SCOPE and condition['stage']=='full54' and condition['実行前固定'] is True,'条件scope/固定')
    for field,expected in (('builder停止SHA256',BUILDER_SHA),('読戻し核SHA256',CORE_SHA),('first2readbackSHA256',FIRST_SHA),('first2生成receiptSHA256',FIRST_RECEIPT_SHA),('固定100完了SHA256',PROOF_SHA),('許可54SHA256',ALLOWED_SHA)):need(condition[field]==expected,'条件固定値:'+field)
    need(re.fullmatch('[0-9a-f]{64}',receipt_sha or '') is not None and condition['生成receiptSHA256']==receipt_sha,'実行前receipt SHA')
    need((ROOT/condition['生成先']).resolve()==input_path.resolve()==INPUT.resolve(),'固定生成先')
    need(condition['監査コードSHA256']==code and all(condition[k] is False for k in ('Source再実行','金融実行','特徴再生成','退出採否')),'所有停止/非再生成条件')


def prepare(args):
    """
    機能: 全固定metadataと54場の出典をデータ検査前に閉じる。
    引数: args(Namespace)は条件/明示SHA/入力/新規先/worker。
    返り値: tuple[tasks,before,condition]は明示3path各場・指紋・条件。
    """
    need(not args.out.exists() and args.out.resolve().parent==HERE.resolve() and 1<=args.workers<=4,'所有workの新規出力/worker1..4');need(re.fullmatch('[0-9a-f]{64}',args.condition_sha or '') is not None and sha(args.condition)==args.condition_sha,'条件SHA')
    condition=load(args.condition);validate_condition(condition,args.receipt_sha,args.input,owned())
    need(sha(BUILDER)==BUILDER_SHA and sha(FIRST)==FIRST_SHA and sha(FIRST_RECEIPT)==FIRST_RECEIPT_SHA,'先行3証拠SHA');builder=load(BUILDER);validate_first(load(FIRST),load(FIRST_RECEIPT));ids,proof=catalog()
    receipt_path=args.input/'完了.json';need(sha(receipt_path)==args.receipt_sha,'full54 receipt指紋');receipt=load(receipt_path);validate_completion(receipt,ids,builder)
    index_path=PROOF.with_name('正式54Tape台帳.json');need(sha(index_path)==proof['自己を除く正式指紋']['正式54Tape台帳.json'],'旧54Tape台帳SHA');index=load(index_path);need(index['version']==1 and index['stage']=='full54' and len(index['entries'])==54 and {r['session'] for r in index['entries']}==set(ids),'旧Tape完全54')
    by_tape={}
    for r in index['entries']:
        p=Path(r['path']);p=(index_path.parent/p).resolve() if not p.is_absolute() else p.resolve();by_tape[r['session']]=(p,r['sha256'])
    paths=[args.condition,receipt_path,BUILDER,FIRST,FIRST_RECEIPT,PROOF,ALLOWED,index_path,CORE_PATH,CORE.PURE_PATH,CORE.PURE.PUBLIC_PATH,*[ROOT/p for p in owned()]];tasks=[]
    for d in sorted(receipt['details'],key=lambda x:x['session']):
        sid=d['session'];hp=(ROOT/d['header']).resolve();sp=(ROOT/d['path']).resolve();need(hp.parent==sp.parent==args.input.resolve() and hp.name==sid+'.header.json' and sp.name==sid+'.records.jsonl.gz','場別正規配置')
        need(sha(hp)==d['header_SHA256'] and sha(sp)==d['SHA256'],'生成物SHA');h=load(hp);tp,th=by_tape[sid];p=h['provenance'];need(Path(p['old_tape_path']).resolve()==tp and p['old_tape_gzip_sha256']==th and p['proof100_sha256']==PROOF_SHA,'旧Tape出典')
        need(receipt['入力コードSHA256前後'][str(tp)]==th and sha(tp)==th,'旧Tape前後/現物SHA');need(h['session']['id']==sid,'header場bind');paths.extend([hp,sp,tp]);tasks.append((hp,sp,tp))
    before={str(p.resolve()):sha(p) for p in paths};return tasks,before,condition


def main():
    """
    機能: Rootが受領したfull54cacheだけを一場一回監査する。
    引数: CLI --run/--condition/--condition-sha/--receipt-sha/--input/--out/--workers。
    返り値: intは成功0、失敗1。実cache未生成なら実行しない。
    """
    ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true');ap.add_argument('--condition',type=Path,required=True);ap.add_argument('--condition-sha',required=True);ap.add_argument('--receipt-sha',required=True);ap.add_argument('--input',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--workers',type=int,default=4);args=ap.parse_args();need(args.run,'Root別許可後の明示runが必要')
    tasks,before,condition=prepare(args);details=[];errors={}
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures={pool.submit(CORE.inspect_scene,*task):task[0].name for task in tasks}
        for future in as_completed(futures):
            try:details.append(future.result());print('監査完了 '+futures[future],flush=True)
            except Exception as exc:errors[futures[future]]=str(exc);print('監査不一致 '+futures[future]+':'+str(exc),flush=True)
    after={p:sha(Path(p)) for p in before};unchanged=before==after;counts=Counter()
    for d in details:counts.update(d['counts'])
    success=not errors and len(details)==54 and unchanged
    value={'成功':success,'scope':SCOPE,'stage':'full54','sessions':sorted(d['session'] for d in details),'入力構築receiptSHA256':args.receipt_sha,'実行条件SHA256':args.condition_sha,'builder停止SHA256':BUILDER_SHA,'読戻し核SHA256':CORE_SHA,'first2先行readbackSHA256':FIRST_SHA,'details':sorted(details,key=lambda x:x['session']),'errors':errors,'counts':dict(counts),'前後不変':unchanged,'入力codeSHA256前':before,'入力codeSHA256後':after,'RawCSV旧Native追加読取':0,'特徴Source金融再生成':0,'退出採否/PnL':0,'旧市場Ending比較':False,'限界':'停止核と同じ。Endingは新stream Seal復元まで、旧市場Endingの一致は生成側の別限定照合。first2成功を54へ転記しない'}
    args.out.parent.mkdir(parents=True,exist_ok=True)
    with args.out.open('x',encoding='utf-8') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
    return 0 if success else 1


if __name__=='__main__':raise SystemExit(main())
