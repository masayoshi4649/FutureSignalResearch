"""全54wrapperのmetadata guardと停止核への委譲だけを人工確認する。"""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
SPEC=importlib.util.spec_from_file_location('101全54wrapper人工',HERE/'全54場を読み戻す.py');W=importlib.util.module_from_spec(SPEC);sys.modules[SPEC.name]=W;SPEC.loader.exec_module(W)


def main():
    """
    機能: 実54本文を読まずmetadata正負と委譲一例を検査する。
    引数: なし。
    返り値: intは成功0。実54成功receiptを作らない。
    """
    ids,proof=W.catalog();builder=W.load(W.BUILDER);first=W.load(W.FIRST);receipt=W.load(W.FIRST_RECEIPT);W.validate_first(first,receipt)
    fake=copy.deepcopy(receipt);fake['stage']='full54';fake['sessions']=ids;fake['details']=[]
    for i,sid in enumerate(ids):d=copy.deepcopy(receipt['details'][i%2]);d['session']=sid;fake['details'].append(d)
    W.validate_completion(fake,ids,builder);condition=W.load(HERE/'実行条件の雛形.json');condition['生成receiptSHA256']='a'*64;condition['監査コードSHA256']=W.owned();W.validate_condition(condition,'a'*64,W.INPUT,W.owned())
    rejected=[]
    completion_bad=[('未完',lambda v:v.__setitem__('成功',False)),('53',lambda v:v['details'].pop()),('55',lambda v:v['details'].append(copy.deepcopy(v['details'][0]))),('重複',lambda v:v['details'][1].__setitem__('session',v['details'][0]['session'])),('Source',lambda v:v.__setitem__('source_reexecuted',True)),('金融',lambda v:v.__setitem__('financial_executed',True)),('別builder',lambda v:v.__setitem__('所有コードSHA256',{})),('別stage',lambda v:v.__setitem__('stage','first2')),('余計なtag',lambda v:v.__setitem__('仮成功',True)),('不正型',lambda v:v['details'][0]['stream統計'].__setitem__('records',True))]
    for label,mutate in completion_bad:
        v=copy.deepcopy(fake);mutate(v)
        try:W.validate_completion(v,ids,builder)
        except (ValueError,KeyError,TypeError):rejected.append(label)
        else:raise ValueError('破損metadata受理:'+label)
    condition_bad=[('空receipt',lambda v:v.__setitem__('生成receiptSHA256','')),('未固定',lambda v:v.__setitem__('実行前固定',False)),('別核',lambda v:v.__setitem__('読戻し核SHA256','b'*64)),('コード不足',lambda v:v.__setitem__('監査コードSHA256',{})),('未知条件',lambda v:v.__setitem__('追加ルール',1)),('bool版',lambda v:v.__setitem__('version',True))]
    for label,mutate in condition_bad:
        v=copy.deepcopy(condition);mutate(v)
        try:W.validate_condition(v,'a'*64,W.INPUT,W.owned())
        except (ValueError,KeyError,TypeError):rejected.append(label)
        else:raise ValueError('条件破損受理:'+label)
    bad=copy.deepcopy(first);bad['入力構築receiptSHA256']='b'*64
    try:W.validate_first(bad,receipt)
    except ValueError:rejected.append('first2元receipt差')
    else:raise ValueError('first2混同受理')
    p=ROOT/'work/101連続入力の試作_版2/人工_停止版/買い.json';v=W.load(p);result=W.CORE.inspect_values(v['stream_header'],iter(v['stream_records']),v['legacy_artificial']);W.need(result['処理完了'] is True and result['不一致']==0,'停止核委譲')
    before={str(x.relative_to(ROOT)):W.sha(x) for x in (W.CORE_PATH,W.BUILDER,W.FIRST,W.FIRST_RECEIPT,W.PROOF,W.ALLOWED,p)}
    out={'成功':True,'scope':'metadata正負と停止Go人工一例だけ。full54本文/Source/金融/Raw未実行','正常':['閉鎖54集合','first2 fb53→1771三指紋','手製full54 metadata型','実行前条件型','停止核一例委譲'],'拒否':rejected,'核委譲':result,'コードSHA256':W.sha(HERE/'全54場を読み戻す.py'),'入力コードSHA256':before,'新parser品質形成器複写':0,'実full54本文読取':0}
    with (HERE/'人工確認.json').open('x',encoding='utf-8') as stream:json.dump(out,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps({'成功':True,'正常':5,'拒否':len(rejected),'full54実行':0},ensure_ascii=False));return 0


if __name__=='__main__':raise SystemExit(main())
