# 全54場の読戻しwrapper（人工停止用）

[計画](計画.md)に従い、停止核00d8を無改変importする。新parser/品質/形成器は作らず、各場の`CORE.inspect_scene`を一回だけ実行する。workerは1..4。今回の準備はmetadata人工と既存Go公開型一例だけで、生成中のfull54本文は読まない。

Rootが全54生成成功を受領後、[実行条件の雛形](実行条件の雛形.json)を別の新規JSONへ保存する。空の`生成receiptSHA256`に生成/完了.jsonのSHAを、空の`監査コードSHA256`に本停止.jsonの`所有コードSHA256`を入れる。雛形/コードは編集しない。条件JSON自体のSHAもCLIへ明示する。空・未固定・別receipt・別コード・53/55/重複場・異なるbuilderを本文前に拒否する。

Rootだけが生成完了受領後に実行する形：

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101連続入力の全54読取照合/全54場を読み戻す.py' --run `
  --input 'work/101連続入力の全54場/生成' `
  --condition 'work/101連続入力の全54読取照合/実行条件.json' `
  --condition-sha <実行前固定した条件JSONのSHA256> `
  --receipt-sha <生成/完了.jsonのSHA256> `
  --out 'work/101連続入力の全54読取照合/全54場.json' --workers 4
```

全54は一場一回で再試行せず、失敗場もerrorsへ保持する。成功は全54の全recordの保存整合性で、Source/金融/退出/技法値の再生成ではない。旧市場Endingとの一致は生成側の限定照合で、本wrapperは停止核どおり新stream最終Sealの復元まで。

`prepare(args)`は全metadata/同版/出典指紋を検査し`tasks,before,condition`を返す。`validate_first`は成功first2 fb534を元構築1771と各3入力SHAへ結ぶ。header/streamは元receiptの出力指紋、旧Tapeは元receiptの入力指紋へ別に結ぶ。`validate_completion`は完全54原receiptの全tag・型・集合、`validate_condition`は実行前Root条件を検査する。

本wrapperのJSON parserとhash以外のデータ監査は停止核のAPIだけを使用する。Raw/CSV/旧Nativeを新たにhash/展開しない。許可集合は旧100閉鎖metadataとe290許可台帳04916を全値一致させ、Native価格/損益を読まない。生成側の43da台帳は異なるschemaだが、双方が同じ4a8の54場を起点とする。

人工再現：

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101連続入力の全54読取照合/人工を確認する.py'
```

出力が既に存在する場合は上書きせず拒否する。機会損失・未参加/退出後価格・PnL・新しい退出採否は評価しない。first2成功を全54成功へ拡大表現しない。
