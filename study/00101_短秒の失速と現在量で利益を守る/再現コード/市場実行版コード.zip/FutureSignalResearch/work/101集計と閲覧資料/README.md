# 101の保存集計・Viewer形式の準備

実市場は未実行。停止した完全Input/Tape/streamの買売2鏡像、各12会計の保存値だけで実装を確認する。2鏡像は同じDay場IDを使う人工であり、実Day/Nightのfirst2成功ではない。正式101のREADME/計画/表は変更しない。

`集計.py`は旧100保存4175cf45と旧保存共通算術、旧Viewer実Fill変換をSHA固定で再用する。入口はE3S、基本保護P0、Harvest/Riskは空、出口P0/S5Q/S515Q×C0/C5×D0/D1の全12本名を保持する。新金融engine・原板・Source・Features・チャートを作らない。

## 保存検算と独立全経路の分担

全実約定、所有配賦、半円費用、滑り、残0、注文IDと実玉、Source出生/比例close、予約・全5分枠・現在E3S候補/checkを旧規範で検算する。新規の全5分ContextはNativeが明示参照するsidecar Header.gridsから得る。保存器は全stream recordsを再走査しない。

S専用candidate/assessment/point/trace/counterを落とさず検算する。旧Timeline内部ではSをSource後自己予約に対応する私有MTM点へ算術変換する。原NativeのS専用point・理由・本名・Source通知・要求量は変更せず、Source/P0/Sの要求/約定回数・枚数を排他的に出す。Source先行、P0後、S要求前の未予約量と起動履歴を別に検査する。SをP0として運転したり、偽の受理を作ったりしない。

保存されたMTM点・DD二点・最終床の算術と、全原行で最初/最大/欠落評価/要求義務が正しいことは別である。後者は停止した独立器の成功receiptへ同条件・同Native/header/records/Tape/旧100の5指紋で結ぶ。`inspect_scene`等の独立金融をこの保存器から再実行しない。

## 集約とViewer

`結果.json/md`に実現gross/fee/slip/net、正負/PF、u/W正益前後の最終損失と各玉分母、日中/夜間・日別、保存極値をflat場間連結したDD、回数・枚数、判断4分類、Source/P0/S注文別を出す。uの利益起動とWの正益観測は代用しない。PF未定義や無取引を黒字安定としない。

12比較はP0→S5Q、P0→S515Q、S5Q→S515Q×C/D。実Source出生全文を一致させた後、要求時計・Quote全値と実取得時計/Index/物理行/Quote全値/方向/価格/初期量が一致した場合だけ同実入口の退出差と呼ぶ。取得変更、片側の実参加、双方の実在額を分ける。未参加や退出後の仮想利益、機会損失、理想峰/MFE回収、資本不明ROIは算出しない。

Viewerはschema1、`101_key_session`、title=`短秒の失速と現在量 key session`、point_value=100。`BASE.viewer_trades`の実Fillのみを変換し、fee欄は指定手数料＋当運転の仮定slip。別の所有/純現金計算で全約定・部分返済・半円・最終0へ再結合する。0取引は空trades。既存8092/PID19844へのHTTP・登録・設定変更・起動停止は一切行わない。

## CLIとRootの実行前固定

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101集計と閲覧資料/集計.py' `
  --fixed 'Rootが固定した保存実行条件.json' --fixed-sha 'その実SHA256' `
  --stage first2 --out '未使用の接続保存dir'

# 同条件で金融/独立のfull54が成功した後、別の事前固定を渡す。
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101集計と閲覧資料/集計.py' `
  --fixed 'Rootが固定した正式保存実行条件.json' --fixed-sha 'その実SHA256' `
  --stage full54 --out '未使用の正式保存dir'
```

実行固定は`version=1,試行=101,scope='101保存集計を同条件の金融と独立成功へ結ぶ実行前固定',固定=true,stage,condition:{path,sha256},run,completion_sha256,audit:{path,sha256},first2_audit`。FileRefとrunの相対pathはこの固定JSONのdir基準。first2では`first2_audit=null`、full54では同条件のfirst2独立成功FileRefが必須。準備雛形は`固定=false`なので市場metadataや本文へ進む前に拒否する。架空の器具SHAを実入力へ使わない。

市場metadataは停止独立器版2の`prepare(args)`を無改変再用し、完全12Key/許可2又は54場/各NativeSHA/条件とコード/前後不変/first2→full54を確認する。独立成功も同条件・同金融完了・同監査コード・全場12/4/4・全5入力・全record読戻し完了へ結ぶ。版2コード`e343746d…`・停止`077eac32…`はproducer許可54の`native_sha256`型を正確に検査し、旧`sha256`型へfallbackしない。旧6c11/213de停止は保持し、訂正の由来を分ける。

新規出力は一覧/resources、12×場の実trades、集約JSON/MD、Native参照を含む保存完了receipt。全BookやSource/Rawを再転記しない。入力/コードは生成前後にSHAを再確認する。表版5の結果更新と固定Plan保存はRootの実市場成功後に別工程で行う。

## 人工

`人工を確認する.py`は停止runtime ff571dの公開2鏡像だけを使う。`人工_停止版/方向±1`へ各12資源・結果JSON/MDを保存した。保存24会計、Viewer24資源・全72Fill、partial24玉、半円48表示行、S保存callback32、旧100P0八全文（除外なし）、狭い破損20拒否、空Viewer型、未固定CLI本文前拒否を確認した。新金融や全経路の再計算は行っていない。初回の器具出力は`人工/`へ保持する。
