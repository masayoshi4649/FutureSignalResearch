"""固定100閉鎖だけからP0保有技法時計を抽出する。今回の準備中は市場実行しない。"""

import argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys


ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
PROOF=ROOT/"study/00100_費用後利益化の前後で保護を分ける/完了記録.json"
PROOF_SHA="4a8bc486e329f65f17e2395f781b2efd7cf76c5630d91924b611e90254725af3"
PLAN=HERE/"実行前の固定計画.md"
CORE_PATH=HERE/"保有枠の抽出.py"
SPEC=importlib.util.spec_from_file_location("101実行案の保有枠",CORE_PATH);CORE=importlib.util.module_from_spec(SPEC);sys.modules[SPEC.name]=CORE;SPEC.loader.exec_module(CORE)
need=CORE.need


def digest(path: Path) -> str:
    """
    機能: 明示証拠/コード/固定gzipの指紋を得る。
    引数: path(Path)は対象。
    返り値: strはSHA256。gzip値を展開しない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict:
    """
    機能: 明示metadataだけを標準JSONとして読む。
    引数: path(Path)はmetadata。
    返り値: dictはmeta値。この関数へNativeを渡さない。
    """
    return json.loads(path.read_text(encoding="utf-8"))


def catalog(proof_path: Path) -> tuple:
    """
    機能: 固定4a8閉鎖から正式100の54gzipとコード依存をmetadataだけで得る。
    引数: proof_path(Path)は正式完了記録。
    返り値: tuple[dict,dict]は許可台帳と固定コード。Native本文は読まない。
    """
    need(proof_path.resolve()==PROOF.resolve() and digest(proof_path)==PROOF_SHA,"固定100閉鎖path/SHA")
    proof=load(proof_path);need(proof["比較保存完了"] is True and proof["試行"]==100 and proof["場数"]==54,"固定100完了metadata")
    entries=[]
    for name,sha in proof["自己を除く正式指紋"].items():
        match=re.fullmatch(r"成果物/(\d{4}-\d{2}-\d{2}_(?:Day|Night))\.json\.gz",name.replace("\\","/"))
        if match:
            path=(proof_path.parent/name).resolve();need(path.parent==(proof_path.parent/"成果物").resolve() and re.fullmatch(r"[0-9a-f]{64}",sha),"許可gzip配置/SHA")
            entries.append({"session":match[1],"path":str(path.relative_to(ROOT)),"sha256":sha})
    need(len(entries)==54 and len({x["session"] for x in entries})==54,"固定54だけ")
    dependencies={**proof["固定金融/監査236"],**proof["後処理コードSHA256"]}
    need(len(proof["固定金融/監査236"])==236 and len(proof["後処理コードSHA256"])==5,"固定236/Reader5")
    return {"version":1,"proof100_sha256":PROOF_SHA,"plan_sha256":digest(PLAN),"entries":sorted(entries,key=lambda x:x["session"])},dependencies


def choose(value: dict,expected: dict,stage: str) -> list:
    """
    機能: 台帳の全集合/全tag/重複/配置をmetadata完全一致で閉じる。
    引数: value/expected(dict)、stage(str)は実台帳/閉鎖からの正本/first2又はfull54。
    返り値: list[dict]は許可2又は54。余計な日を選ばない。
    """
    need(stage in ("first2","full54") and value==expected,"許可54台帳の全体同体")
    if stage=="full54":return value["entries"]
    rows=[r for r in value["entries"] if r["session"] in {"2026-09-21_Day","2026-09-21_Night"}]
    need(len(rows)==2,"固定first2");return rows


def owned_codes() -> dict:
    """
    機能: 実行器と純型依存/計画を停止指紋へ結ぶ。
    引数: なし。
    返り値: dict[str,str]はrepo相対pathとSHA256。
    """
    paths=[Path(__file__),CORE_PATH,CORE.MODEL_PATH,CORE.PUBLIC_PATH,PLAN,HERE/"人工を確認する.py",HERE/"README.md"]
    return {str(p.relative_to(ROOT)):digest(p) for p in paths}


def validate_stop(path: Path) -> dict:
    """
    機能: Root受領前の未停止実行とコード/計画差をNative読取前に拒否する。
    引数: path(Path)は今回の停止証拠。
    返り値: dictは成功停止。停止証拠そのものの採否はRootの指示へ従う。
    """
    stop=load(path);need(stop["成功"] is True and stop["市場Native本文読取"]==0 and stop["閉鎖100SHA256"]==PROOF_SHA,"実行前停止scope")
    need(stop["所有コードSHA256"]==owned_codes(),"停止コード/新計画同体")
    return stop


def validate_first2(path: Path,code: dict,catalog_sha: str) -> None:
    """
    機能: 同じ固定実装/入力で先頭2場が成功した後だけ54へ進める。
    引数: path(Path)、code(dict)、catalog_sha(str)は先頭成功証拠/停止実装/台帳SHA。
    返り値: None。不成功/別版/異なる集合を拒否する。
    """
    first=load(path);need(first["成功"] is True and first["stage"]=="first2" and first["sessions"]==["2026-09-21_Day","2026-09-21_Night"],"first2成功を先行")
    need(first["scope"]=="固定100Nativeの保有時計抽出" and first["人工"] is False,"first2人工の成功を市場へ代用しない")
    need(first["閉鎖100SHA256"]==PROOF_SHA and first["所有コードSHA256"]==code and first["台帳SHA256"]==catalog_sha and first["前後不変"] is True,"first2同実装/入力/前後")
    need(first["個別Native読取"]==2 and first["Raw/新日/Source形成/指標形成/金融再生/新売買/仮想利益/機会損失"]==0,"first2のscope")
    expected,_=catalog(PROOF)
    for row in choose(expected,expected,"first2"):
        need(first["入力コードSHA256前後"].get(str((ROOT/row["path"]).resolve()))==row["sha256"],"first2の正規Native出典")


def inspect_task(row: dict) -> dict:
    """
    機能: 許可gzipをSHA確認後に必要fieldだけへ射影する。
    引数: row(dict)は停止台帳が許可した一場。
    返り値: dictはP0保有可用性。Rootの別実行指示まで呼び出さない。
    """
    path=ROOT/row["path"];body=path.read_bytes();need(hashlib.sha256(body).hexdigest()==row["sha256"],"固定Native gzipSHA")
    value=CORE.project_text(gzip.decompress(body).decode("utf-8"));need(value["session"]==row["session"],"場ID")
    result=CORE.analyze(value,"固定100");need(digest(path)==row["sha256"],"Native前後不変")
    return {**result,"input_sha256":row["sha256"]}


def render(summary: dict) -> str:
    """
    機能: 可用性の四段階を玉/枠で短く示す。
    引数: summary(dict)は抽出成功集計。
    返り値: strはMarkdown。新しい売買損益や現在正益を意味しない。
    """
    lines=["# 保有技法時計の可用性","",f"stage={summary['stage']}、{len(summary['sessions'])}場。固定100P0の既存経路のみ。","","|Key|実玉|実保有 枠/玉|基本可用 枠/玉|起動後基本 枠/玉|freeあり起動後基本 枠/玉|予約未知枠|","|---|---:|---:|---:|---:|---:|---:|"]
    for key,c in summary["counts"].items():lines.append(f"|{key}|{c['positions']}|{c['held_grids']}/{c['held_positions']}|{c['basic_grids']}/{c['basic_positions']}|{c['activation_basic_grids']}/{c['activated_basic_positions']}|{c['free_activation_basic_grids']}/{c['free_activated_basic_positions']}|{c['reservation_unknown_grids']}|")
    lines.extend(["","|Key/profile|保有枠|可用枠/玉|起動後可用枠/玉|freeあり起動後枠/玉|","|---|---:|---:|---:|---:|"])
    for key,profiles in summary["profiles"].items():
        for name,c in profiles.items():lines.append(f"|{key}/{name}|{c['held_grids']}|{c['available_grids']}/{c['available_positions']}|{c['activation_available_grids']}/{c['activation_available_positions']}|{c['free_activation_available_grids']}/{c['free_activation_available_positions']}|")
    return "\n".join(lines+["","旧basicとexit3/exit3_quantityを別profileで保存。量/Spike/Recent3は別計数。起動後を当枠の現在u正益と呼ばず、既存経路の判定入力だけを数える。新exit/仮想利益/機会損失の評価なし。",""])


def main() -> int:
    """
    機能: metadata-only又はRoot専用の2→54抽出を新規先へ保存する。
    引数: --metadata-only/--run、--proof100/--catalog/--stop/--out/--first2(Path)、--stage(str)、--workers(int,1..8)。
    返り値: intは成功0。今回の準備ではmetadata-onlyと人工以外を実行しない。
    """
    parser=argparse.ArgumentParser(description=__doc__);mode=parser.add_mutually_exclusive_group(required=True);mode.add_argument("--metadata-only",action="store_true");mode.add_argument("--run",action="store_true")
    parser.add_argument("--proof100",type=Path,required=True);parser.add_argument("--out",type=Path,required=True)
    for name in ("catalog","stop","first2"):parser.add_argument("--"+name,type=Path)
    parser.add_argument("--stage",choices=("first2","full54"));parser.add_argument("--workers",type=int,choices=range(1,9),default=1)
    args=parser.parse_args();need(not args.out.exists(),"新規出力だけ")
    expected,deps=catalog(args.proof100.resolve())
    if args.metadata_only:
        args.out.parent.mkdir(parents=True,exist_ok=True);args.out.write_text(json.dumps(expected,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n");print("許可54metadataのみ。Native本文読取0。");return 0
    need(args.stage and args.catalog and args.stop,"停止/台帳/stage必須")
    stop=validate_stop(args.stop);rows=choose(load(args.catalog),expected,args.stage);code=owned_codes();catalog_sha=digest(args.catalog)
    if args.stage=="full54":need(args.first2 is not None,"first2成功証拠必須");validate_first2(args.first2,code,catalog_sha)
    before={str((ROOT/n).resolve()):h for n,h in deps.items()}
    before.update({str((ROOT/n).resolve()):h for n,h in code.items()})
    for p in (args.proof100,args.catalog,args.stop,PLAN,CORE.MODEL_PATH,Path(__file__),CORE_PATH):before[str(p.resolve())]=digest(p)
    if args.first2 is not None:before[str(args.first2.resolve())]=digest(args.first2)
    for row in rows:before[str((ROOT/row["path"]).resolve())]=row["sha256"]
    need(all(digest(Path(p))==h for p,h in before.items()),"抽出前固定入力/コード")
    args.out.mkdir(parents=True);results=[]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        futures={pool.submit(inspect_task,row):row["session"] for row in rows}
        for future in as_completed(futures):
            result=future.result();results.append(result);(args.out/(result["session"]+".json")).write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n");print("101保有時計抽出 "+result["session"]+" 完了",flush=True)
    need(len(results)==len(rows) and all(digest(Path(p))==h for p,h in before.items()),"抽出完了/前後")
    from collections import Counter
    counts={key:Counter() for key in CORE.KEYS}
    profiles={key:{name:Counter() for name in ("exit3","exit3_quantity")} for key in CORE.KEYS}
    for result in results:
        for key,book in result["books"].items():
            counts[key].update(book["counts"])
            for name,c in book["profiles"].items():profiles[key][name].update(c)
    summary={"成功":True,"scope":"固定100Nativeの保有時計抽出","人工":False,"stage":args.stage,"sessions":sorted(x["session"] for x in results),"閉鎖100SHA256":PROOF_SHA,"台帳SHA256":catalog_sha,"所有コードSHA256":code,"停止SHA256":digest(args.stop),
             "counts":counts,"profiles":profiles,"Source四感度共通":sum(x["source_common_four"] for x in results),"Source和集合":sum(x["source_count"] for x in results),"入力コードSHA256前後":before,"前後不変":True,
             "個別Native読取":len(rows),"Raw/新日/Source形成/指標形成/金融再生/新売買/仮想利益/機会損失":0,"限定":"固定100の実保有における技法入力可用性だけ。現在uや新exitの有効性を計算しない。"}
    (args.out/"結果.json").write_text(json.dumps(summary,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n");(args.out/"結果.md").write_text(render(summary),encoding="utf-8",newline="\n")
    print(json.dumps({"成功":True,"stage":args.stage,"場数":len(results),"Native読取":len(rows)},ensure_ascii=False));return 0


if __name__=="__main__":raise SystemExit(main())
