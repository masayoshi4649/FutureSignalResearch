"""101抽出実装のGo人工型/手製cutoff/metadataだけを検査し、Nativeは開かない。"""

import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile


ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
PATH=HERE/"固定Nativeを抽出する.py"
SPEC=importlib.util.spec_from_file_location("101抽出の人工",PATH);RUN=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(RUN);CORE=RUN.CORE;need=CORE.need


def reject(call,label: str) -> dict:
    """
    機能: 狭い破損/未固定を拒否する。
    引数: call(callable)、label(str)は実行と名称。
    返り値: dictは拒否証拠。未検出なら例外。
    """
    try:call()
    except (ValueError,KeyError,TypeError) as error:return {"ケース":label,"拒否":True,"理由":str(error)}
    raise ValueError("拒否されません:"+label)


def hand_state(template: dict,reserved: bool) -> dict:
    """
    機能: 現在量/Activation/予約の型だけを手計算できる状態器具を作る。
    引数: template(dict)、reserved(bool)は停止Go人工とForce全予約の有無。
    返り値: dictは手製保有状態。正常金融出力や実Source生成とは呼ばない。
    """
    context=copy.deepcopy(template["chart_grids"][0]);at=context["at"];quote=copy.deepcopy(template["actors"][CORE.KEYS[0]]["grid_traces"][0]["quote"]);quote["index"]=3
    context["chart"]["scene"]["id"]=template["session"]["id"]
    for s in context["recent3"]:s["scene"]["id"]=template["session"]["id"]
    context["current"]["source_index"]=3
    result={"session":template["session"]["id"],"books":{},"chart_grids":[context],"gate_assessments":[]}
    source=copy.deepcopy(template["actors"][CORE.KEYS[0]]["positions"][0]["source"]);source["birth_time"]=at-200;source["birth_quote"]={"time":at-200,"index":0,"source_line":1}
    entry={"time":at-100,"index":1,"source_line":2};close={"time":at+1,"index":5,"source_line":23}
    for key in CORE.KEYS:
        base=template["actors"][key];pid=key+"-実玉";eid=key+"-新規";xid=key+"-返済";nf=eid+"-F";xf=xid+"-F"
        req=copy.deepcopy(quote)
        if not reserved:req["time"]=at;req["index"]=4;req["source_line"]=22
        p={"id":pid,"entry_order_id":eid,"source":copy.deepcopy(source),"source_hold_id":"元保持","side":1,"initial_quantity":2,"entry_quote":entry,"closed_quote":close,"protection_active":True,"activation":{"quote":{"time":at-50,"index":2,"source_line":3},"phase":"after_source","quantity":2,"reserved":0,"unit_net":1}}
        entry_order={"id":eid,"kind":"entry","quantity":2,"position_id":pid,"request_time":at-101,"request_quote":{"time":at-101,"index":0,"source_line":1},"status":"filled","fill_id":nf,"cancel_time":None,"reason":"手製新規","protection_point":None}
        exit_order={"id":xid,"kind":"exit","quantity":2,"position_id":pid,"request_time":at,"request_quote":req,"status":"filled","fill_id":xf,"cancel_time":None,"reason":"手製Source","protection_point":None}
        fills=[{"id":nf,"order_id":eid,"position_id":pid,"action":"new","quantity":2,"quote":entry,"reason":"手製新規","source":copy.deepcopy(source)},
               {"id":xf,"order_id":xid,"position_id":pid,"action":"close","quantity":2,"quote":close,"reason":"手製Source","source":copy.deepcopy(source)}]
        result["books"][key]={"session":copy.deepcopy(base["session"]),"key":key,"config":copy.deepcopy(base["config"]),"complete":True,"finished":True,"positions":[p],"orders":[entry_order,exit_order],"fills":fills,
                              "source_events":[{"at":at,"phase":"source_close","order_id":xid,"quote":copy.deepcopy(req)}],"grid_traces":[{"at":at,"quote":copy.deepcopy(quote),"quote_known":True}]}
        result["books"][key]["session"]["force_close"]=at
    return result


def main() -> int:
    """
    機能: 既存Go P0買売8型、手製四段階、字句射影と集合guardを確認する。
    引数: なし。Native/Rawではなく固定人工/閉鎖metadataだけを読む。
    返り値: intは成功0。市場の分母/損益はまだ算出しない。
    """
    paths=[ROOT/f"work/100利益保護案/人工/停止版/方向{s}_Source部分先行.json" for s in (-1,1)]
    expected,deps=RUN.catalog(RUN.PROOF);cat=RUN.load(HERE/"許可54.json");need(cat==expected,"計画/許可metadata同体")
    before={str(p.relative_to(ROOT)):RUN.digest(p) for p in paths+[RUN.PROOF,RUN.PLAN,CORE.MODEL_PATH,CORE.PUBLIC_PATH,PATH,RUN.CORE_PATH,Path(__file__),HERE/"README.md",HERE/"許可54.json"]}
    details=[];projections=[]
    for p in paths:
        f=json.loads(p.read_text(encoding="utf-8"));value={"session":f["session"]["id"],"books":f["actors"],"chart_grids":f["chart_grids"],"gate_assessments":f["gate_assessments"],"禁止":{"peak":0.123}}
        text=json.dumps(value,ensure_ascii=False).replace('"peak_gain": '+str(f['actors'][CORE.KEYS[0]]['positions'][0]['peak_gain']),'"peak_gain": 1e999999').replace('"禁止": {"peak": 0.123}','"禁止": {"peak": 1e999999}')
        projected=CORE.project_text(text);need("禁止" not in projected and all("peak_gain" not in pos and "realized_net" not in pos for book in projected["books"].values() for pos in book["positions"]),"禁止値を数値展開しない")
        output=CORE.analyze(projected,"人工");need(len(output["books"])==4,"Go人工P0四型")
        details.append({"入力":p.name,"P0会計":4,"Source和集合":output["source_count"],"Source四感度共通":output["source_common_four"],"scope":"既存Go人工の型/所有/出典結合。市場ではない。"});projections.append(projected)
    template=json.loads(paths[1].read_text(encoding="utf-8"));free=hand_state(template,False);reserved=hand_state(template,True)
    free_result=CORE.analyze(free,"人工");reserved_result=CORE.analyze(reserved,"人工")
    for key in CORE.KEYS:
        need(free_result["books"][key]["counts"]["free_activation_basic_grids"]==1,"四段階すべて1")
        need(reserved_result["books"][key]["counts"]["activation_basic_grids"]==1 and reserved_result["books"][key]["counts"]["free_activation_basic_grids"]==0,"Force予約で第四だけ0")
    unknown=copy.deepcopy(reserved);key=CORE.KEYS[0];unknown["books"][key]["source_events"].append(copy.deepcopy(unknown["books"][key]["source_events"][0]))
    u=CORE.analyze(unknown,"人工");need(u["books"][key]["counts"]["reservation_unknown_grids"]==1,"重複Force出典はunknown")
    variants=[]
    for name in ("量だけ未知","ObservedClockはdrain上限","Activation同clock","ChartIndexは別系統"):
        v=copy.deepcopy(free);ctx=v["chart_grids"][0];at=ctx["at"]
        if name=="量だけ未知":ctx["current"]["buy"]["ofi_known"]=False
        if name=="ObservedClockはdrain上限":
            ctx["chart"]["observed_clock"]=at+600
            for scale in ("three","fifteen"):ctx["chart"][scale]["observed_clock"]=at+600
        if name=="Activation同clock":v["books"][key]["positions"][0]["activation"]["quote"]["time"]=at
        if name=="ChartIndexは別系統":ctx["chart"]["last_input"]["index"]+=100
        got=CORE.analyze(v,"人工");c=got["books"][key]["counts"]
        need(c["basic_grids"]==1 and c["free_activation_basic_grids"]==(0 if name=="Activation同clock" else 1),name)
        if name=="量だけ未知":
            need(c["quantity_known_grids"]==0,"量を基本から分離")
            need(got["books"][key]["profiles"]["exit3"]["available_grids"]==1 and got["books"][key]["profiles"]["exit3_quantity"]["available_grids"]==0,"exit3と量profileを分離")
        variants.append({"ケース":name,"counts":c})
    for name in ("15分通常未知","15分通常古い"):
        v=copy.deepcopy(free);ch=v["chart_grids"][0]["chart"];t=ch["chart"]["Technical"];at=ch["at"]
        if name=="15分通常未知":
            t["trend_known"]=False;t["bar15_end"]=0
            ch["fifteen"].update({"bar_end":0,"available_at":0,"observed_clock":0,"rows":0,"data_known":False,"has_last_source":False})
        else:
            t["bar15_end"]=at-900;ch["fifteen"]["bar_end"]=at-900;ch["fifteen"]["available_at"]=at-900;ch["fifteen"]["last_source"]["time"]=at-901
        got=CORE.analyze(v,"人工");b=got["books"][key]
        need(b["counts"]["basic_grids"]==0 and b["profiles"]["exit3"]["free_activation_available_grids"]==1 and b["profiles"]["exit3_quantity"]["free_activation_available_grids"]==1,name)
        variants.append({"ケース":name,"counts":b["counts"],"profiles":b["profiles"]})
    breaks=[]
    empty_cases=[]
    for name in ("全空list","positions","orders","fills","source_events","全null"):
        v=copy.deepcopy(free)
        for b in v["books"].values():
            for field in ("positions","orders","fills","source_events"):b[field]=None if name in (field,"全null") else []
        original=copy.deepcopy(v);got=CORE.analyze(v,"人工");need(v==original,"nil正規化の元入力不変")
        need(got["source_count"]==0 and all(b["counts"]["positions"]==0 and b["counts"]["held_grids"]==0 and all(c["held_grids"]==0 for c in b["profiles"].values()) for b in got["books"].values()),"合法空P0の分母0:"+name)
        empty_cases.append({"ケース":name,"四会計の玉/Source/四段階0":True,"元入力不変":True})
    for name in ("欠落slice","非list slice"):
        v=copy.deepcopy(free)
        if name=="欠落slice":v["books"][key].pop("positions")
        else:v["books"][key]["orders"]="[]"
        breaks.append(reject(lambda v=v:CORE.analyze(v,"人工"),name))
    for name in ("entry注文を他exitへ","FillID重複","Source出生Kind差","exit取消","別注文FillID","未来AvailableAt","未来Current出典"):
        broken=copy.deepcopy(free);b=broken["books"][key]
        if name=="entry注文を他exitへ":b["positions"][0]["entry_order_id"]=b["orders"][1]["id"]
        if name=="FillID重複":b["fills"].append(copy.deepcopy(b["fills"][0]))
        if name=="Source出生Kind差":b["fills"][0]["source"]["kind"]="別出生"
        if name=="exit取消":b["orders"][1]["cancel_time"]=broken["chart_grids"][0]["at"]
        if name=="別注文FillID":b["orders"][1]["fill_id"]=b["fills"][0]["id"]
        if name=="未来AvailableAt":broken["chart_grids"][0]["chart"]["three"]["available_at"]=broken["chart_grids"][0]["at"]+1
        if name=="未来Current出典":broken["chart_grids"][0]["current"]["short"]["time"]=broken["chart_grids"][0]["at"]+1
        breaks.append(reject(lambda v=broken:CORE.analyze(v,"人工"),name))
    need(len(RUN.choose(cat,expected,"first2"))==2 and len(RUN.choose(cat,expected,"full54"))==54,"許可stage集合")
    for name in ("台帳重複","対象外日","gzipSHA差","Nativepath差","計画SHA差"):
        bad=copy.deepcopy(cat)
        if name=="台帳重複":bad["entries"].append(copy.deepcopy(bad["entries"][0]))
        if name=="対象外日":bad["entries"][0]["session"]="2026-11-05_Day"
        if name=="gzipSHA差":bad["entries"][0]["sha256"]="0"*64
        if name=="Nativepath差":bad["entries"][0]["path"]="別Native.json.gz"
        if name=="計画SHA差":bad["plan_sha256"]="0"*64
        breaks.append(reject(lambda b=bad:RUN.choose(b,expected,"first2"),name))
    with tempfile.TemporaryDirectory(dir=HERE,prefix="metadata人工_") as directory:
        temp=Path(directory).resolve();need(temp.is_relative_to(HERE.resolve()),"人工一時先が所有work内");invalid=temp/"未成功.json";invalid.write_text('{"成功":false}',encoding="utf-8")
        breaks.append(reject(lambda:RUN.validate_stop(invalid),"未停止実行"));breaks.append(reject(lambda:RUN.validate_first2(invalid,RUN.owned_codes(),RUN.digest(HERE/"許可54.json")),"first2未成功で54禁止"))
        process=subprocess.run([sys.executable,"-B","-X","utf8",str(PATH),"--run","--stage","first2","--proof100",str(RUN.PROOF),"--catalog",str(HERE/"許可54.json"),"--stop",str(invalid),"--out",str(temp/"出力しない")],capture_output=True,text=True,encoding="utf-8",cwd=ROOT)
        need(process.returncode!=0 and "実行前停止scope" in process.stderr and not (temp/"出力しない").exists(),"市場口は未停止をNative読取前に拒否")
    for p in (PATH,RUN.CORE_PATH,Path(__file__)):
        tree=ast.parse(p.read_text(encoding="utf-8"));need(all(ast.get_docstring(n) and "\n" in ast.get_docstring(n) and "返り値:" in ast.get_docstring(n) for n in ast.walk(tree) if isinstance(n,ast.FunctionDef)),"関数説明規約")
    need(all(RUN.digest(ROOT/n)==h for n,h in before.items()),"旧型/人工/metadata/コード不変")
    result={"成功":True,"scope":"Go人工8型＋手製保有状態の四段階/因果/集合だけ。市場Native本文は0。","Go人工型":details,"手製四段階":{"free":[free_result["books"][k]["counts"] for k in CORE.KEYS],"Force全予約":[reserved_result["books"][k]["counts"] for k in CORE.KEYS]},"分離境界":variants,"合法空slice":empty_cases,"破損/guard拒否":breaks,"件数":len(breaks),"入力コードSHA256前後":before,"前後不変":True,"市場口Native読取前拒否":True,"市場Native本文/Raw/新日/Source形成/技法形成/金融再生/PnL評価":0}
    out=HERE/"人工の確認.json";need(not out.exists(),"新規人工証拠だけ");out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n");print(json.dumps({"成功":True,"Go人工型":8,"拒否":len(breaks),"証拠SHA256":RUN.digest(out)},ensure_ascii=False));return 0


if __name__=="__main__":raise SystemExit(main())
