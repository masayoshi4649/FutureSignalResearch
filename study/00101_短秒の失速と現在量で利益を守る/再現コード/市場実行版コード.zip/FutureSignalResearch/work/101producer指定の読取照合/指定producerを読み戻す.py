"""停止核00d8をproducer指定のfirst2へ無改変委譲する。"""

import argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import time

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
CORE_PATH=ROOT/'work/101連続入力の読取照合/読み戻しを照合する.py';CORE_SHA='00d8c55f12a43e31be3857feadae9373ac53901efcbbeff394fb0eef27543345'
PROOF=ROOT/'study/00100_費用後利益化の前後で保護を分ける/完了記録.json';PROOF_SHA='4a8bc486e329f65f17e2395f781b2efd7cf76c5630d91924b611e90254725af3'
IDS=['2026-09-21_Day','2026-09-21_Night'];SCOPE='固定100由来の連続入力first2の全保存record読戻し・技法値の再生成なし'
KEYS={'version','scope','stage','producer停止path','producer停止SHA256','生成receiptSHA256','生成先','読戻し核SHA256','固定100完了SHA256','監査コードSHA256','実行前固定','Source再実行','金融実行','特徴再生成','退出採否'}


def sha(path):
    """
    機能: 明示コード/保存入力だけの指紋を得る。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


if sha(CORE_PATH)!=CORE_SHA:raise ValueError('停止核SHA差')
SPEC=importlib.util.spec_from_file_location('101producer指定の固定核',CORE_PATH);CORE=importlib.util.module_from_spec(SPEC);sys.modules[SPEC.name]=CORE;SPEC.loader.exec_module(CORE)
need=CORE.need


def load(path):
    """
    機能: 停止核parserを無改変再用する。
    引数: path(Path)はmetadata/header。
    返り値: objectはJSON値。
    """
    return CORE.loads(path.read_text(encoding='utf-8'))


def owned():
    """
    機能: producer wrapperの所有5指紋を返す。
    引数: なし。
    返り値: dict[str,str]はrepo相対path→SHA。
    """
    return {str((HERE/n).relative_to(ROOT)).replace('\\','/'):sha(HERE/n) for n in ('指定producerを読み戻す.py','人工を確認する.py','計画.md','README.md','実行条件の雛形.json')}


def validate_condition(c,producer_path,producer_sha,receipt_sha,input_path,code):
    """
    機能: Rootが固定するproducer/receipt/コードをmetadataだけで確認する。
    引数: c(dict)、path2件(Path)、sha2件(str)、code(dict)は条件と明示値。
    返り値: None。空/別producer/別receiptを本文前に拒否。
    """
    need(set(c)==KEYS and type(c['version']) is int and c['version']==1 and c['scope']==SCOPE and c['stage']=='first2' and c['実行前固定'] is True,'実行前条件scope/全tag')
    need(all(re.fullmatch('[0-9a-f]{64}',h or '') for h in (producer_sha,receipt_sha)),'producer/receipt SHAが未固定')
    need(c['producer停止SHA256']==producer_sha and c['生成receiptSHA256']==receipt_sha and (ROOT/c['producer停止path']).resolve()==producer_path.resolve(),'指定producer/receipt bind')
    need(c['読戻し核SHA256']==CORE_SHA and c['固定100完了SHA256']==PROOF_SHA and c['監査コードSHA256']==code and (ROOT/c['生成先']).resolve()==input_path.resolve(),'核/閉鎖/生成先/所有指紋')
    need(input_path.resolve().is_relative_to((ROOT/'work').resolve()) and all(c[n] is False for n in ('Source再実行','金融実行','特徴再生成','退出採否')),'work限定/非再生成')


def validate_receipt(r,producer):
    """
    機能: 新producerによる完全2場成功を型と所有コードへ結ぶ。
    引数: r/producer(dict)は新生成完了/停止。
    返り値: None。旧first2結果を期待値にしない。
    """
    need(producer['成功'] is True and producer['固定100完了SHA256']==PROOF_SHA and len(producer['所有コードSHA256'])==13,'producer停止schema')
    need(r['成功'] is True and r['前後不変'] is True and r['scope']=='固定100と旧Tapeの連続技法sidecar構築' and r['stage']=='first2' and r['sessions']==IDS,'新first2成功scope')
    need(r['固定100完了SHA256']==PROOF_SHA and r['所有コードSHA256']==producer['所有コードSHA256'] and r['source_reexecuted'] is False and r['financial_executed'] is False,'新producer同版/非金融')
    need(len(r['details'])==2 and {d['session'] for d in r['details']}==set(IDS),'完全2詳細/重複なし')


def prepare(args):
    """
    機能: Root指定条件と新生成物の全出典を先に検査する。
    引数: args(Namespace)は条件/producer/receipt/生成先/新規out/worker。
    返り値: tuple[tasks,before,condition]は各3pathと固定指紋。
    """
    need(not args.out.exists() and args.out.resolve().parent==HERE.resolve() and 1<=args.workers<=2,'新規out/worker1..2');need(sha(args.condition)==args.condition_sha,'実行前条件SHA');c=load(args.condition);validate_condition(c,args.producer_stop,args.producer_stop_sha,args.receipt_sha,args.input,owned())
    need(sha(args.producer_stop)==args.producer_stop_sha and sha(PROOF)==PROOF_SHA,'producer/旧閉鎖SHA');producer=load(args.producer_stop);rp=args.input/'完了.json';need(sha(rp)==args.receipt_sha,'新receipt SHA');r=load(rp);validate_receipt(r,producer)
    proof=load(PROOF);ip=PROOF.with_name('接続2場Tape台帳.json');need(sha(ip)==proof['自己を除く正式指紋']['接続2場Tape台帳.json'],'旧first2 Tape台帳');idx=load(ip);need(idx['version']==1 and idx['stage']=='first2' and len(idx['entries'])==2 and {e['session'] for e in idx['entries']}==set(IDS),'旧Tape完全2')
    old={}
    for e in idx['entries']:
        p=Path(e['path']);old[e['session']]=((ip.parent/p).resolve() if not p.is_absolute() else p.resolve(),e['sha256'])
    paths=[args.condition,args.producer_stop,rp,PROOF,ip,CORE_PATH,CORE.PURE_PATH,CORE.PURE.PUBLIC_PATH,*[ROOT/p for p in owned()]];tasks=[]
    for d in sorted(r['details'],key=lambda x:x['session']):
        sid=d['session'];hp=(ROOT/d['header']).resolve();sp=(ROOT/d['path']).resolve();need(hp.parent==sp.parent==args.input.resolve() and hp.name==sid+'.header.json' and sp.name==sid+'.records.jsonl.gz','新生成物配置');need(sha(hp)==d['header_SHA256'] and sha(sp)==d['SHA256'],'新生成物SHA');h=load(hp);tp,th=old[sid];p=h['provenance'];need(Path(p['old_tape_path']).resolve()==tp and p['old_tape_gzip_sha256']==th and p['proof100_sha256']==PROOF_SHA,'同じ旧Tape出典');need(sha(tp)==th and r['入力コードSHA256前後'][str(tp)]==th,'旧Tape SHA');paths.extend([hp,sp,tp]);tasks.append((hp,sp,tp))
    return tasks,{str(p.resolve()):sha(p) for p in paths},c


def main():
    """
    機能: Rootが受領した新first2へ停止核を各一回適用する。
    引数: CLI flagsは全metadata/新規先を明示する。
    返り値: intは成功0、失敗1。Source/金融を呼ばない。
    """
    ap=argparse.ArgumentParser();ap.add_argument('--run',action='store_true')
    for n in ('input','condition','producer-stop','out'):ap.add_argument('--'+n,type=Path,required=True)
    for n in ('condition-sha','producer-stop-sha','receipt-sha'):ap.add_argument('--'+n,required=True)
    ap.add_argument('--workers',type=int,default=2);args=ap.parse_args();need(args.run,'明示runとRoot別許可が必要');start=time.time();tasks,before,c=prepare(args);details=[]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for f in as_completed([pool.submit(CORE.inspect_scene,*t) for t in tasks]):details.append(f.result())
    after={p:sha(Path(p)) for p in before};need(before==after and sorted(d['session'] for d in details)==IDS,'全2/入力前後不変');value={'成功':True,'scope':SCOPE,'stage':'first2','sessions':IDS,'入力構築receiptSHA256':args.receipt_sha,'builder停止SHA256':args.producer_stop_sha,'producer停止path':str(args.producer_stop.resolve()),'読戻し核SHA256':CORE_SHA,'品質コードSHA256':CORE.PURE_SHA,'実行条件SHA256':args.condition_sha,'details':sorted(details,key=lambda x:x['session']),'前後不変':True,'入力codeSHA256前':before,'入力codeSHA256後':after,'経過秒':time.time()-start,'RawCSV旧Native追加読取':0,'特徴Source金融再生成':0,'退出採否/PnL':0,'旧市場Ending比較':False,'旧fb534の成功流用':False}
    with args.out.open('x',encoding='utf-8') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps({'成功':True,'新producer':args.producer_stop_sha,'新receipt':args.receipt_sha,'場数':2},ensure_ascii=False));return 0


if __name__=='__main__':raise SystemExit(main())
