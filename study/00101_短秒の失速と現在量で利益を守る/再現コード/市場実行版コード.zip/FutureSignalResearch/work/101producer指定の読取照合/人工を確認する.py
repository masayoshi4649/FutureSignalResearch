"""producer指定wrapperのmetadataだけを検査する。新cache本文を読まない。"""

import copy
import importlib.util
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
SPEC=importlib.util.spec_from_file_location('101producer読戻し人工',HERE/'指定producerを読み戻す.py');W=importlib.util.module_from_spec(SPEC);sys.modules[SPEC.name]=W;SPEC.loader.exec_module(W)


def main():
    """
    機能: 停止metadataの型結合と未固定拒否を人工確認する。
    引数: なし。Rootの新2場本文を開かない。
    返り値: intは成功0。
    """
    producer_path=ROOT/'work/101連続入力の試作_版3/停止.json';producer=W.load(producer_path);producer_sha=W.sha(producer_path);old=W.load(ROOT/'work/101連続入力の実行/接続2場_版2/完了.json');fake=copy.deepcopy(old);fake['所有コードSHA256']=producer['所有コードSHA256'];W.validate_receipt(fake,producer)
    c=W.load(HERE/'実行条件の雛形.json');c['producer停止SHA256']=producer_sha;c['生成receiptSHA256']='a'*64;c['監査コードSHA256']=W.owned();inp=ROOT/c['生成先'];W.validate_condition(c,producer_path,producer_sha,'a'*64,inp,W.owned());bad=[]
    for label,mutate in [('未完',lambda v:v.__setitem__('成功',False)),('旧所有',lambda v:v.__setitem__('所有コードSHA256',old['所有コードSHA256'])),('欠場',lambda v:v['details'].pop()),('重複',lambda v:v['details'][1].__setitem__('session',v['details'][0]['session'])),('Source',lambda v:v.__setitem__('source_reexecuted',True)),('金融',lambda v:v.__setitem__('financial_executed',True))]:
        v=copy.deepcopy(fake);mutate(v)
        try:W.validate_receipt(v,producer)
        except (ValueError,KeyError):bad.append(label)
        else:raise ValueError('receipt破損受理:'+label)
    for label,mutate in [('空SHA',lambda v:v.__setitem__('生成receiptSHA256','')),('旧producer',lambda v:v.__setitem__('producer停止SHA256','b'*64)),('未固定',lambda v:v.__setitem__('実行前固定',False)),('コード差',lambda v:v.__setitem__('監査コードSHA256',{})),('核差',lambda v:v.__setitem__('読戻し核SHA256','b'*64)),('余計なtag',lambda v:v.__setitem__('新退出',True))]:
        v=copy.deepcopy(c);mutate(v)
        try:W.validate_condition(v,producer_path,producer_sha,'a'*64,inp,W.owned())
        except (ValueError,KeyError):bad.append(label)
        else:raise ValueError('condition破損受理:'+label)
    out={'成功':True,'scope':'producer/receipt metadata人工だけ・新first2本文未読','正常':2,'拒否':bad,'核SHA256':W.sha(W.CORE_PATH),'producer停止SHA256':producer_sha,'新first2cache本文読取':0,'RawCSVNativeSource金融処理':0}
    with (HERE/'人工確認.json').open('x',encoding='utf-8') as stream:json.dump(out,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps({'成功':True,'正常':2,'拒否':len(bad)},ensure_ascii=False));return 0


if __name__=='__main__':raise SystemExit(main())
