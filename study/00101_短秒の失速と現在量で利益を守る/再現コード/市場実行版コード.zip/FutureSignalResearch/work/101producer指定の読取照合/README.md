# 新producer first2の薄い読戻し口

停止核00d8を無改変importし、新producerの完全2場を各一回検査する。旧fb534は旧e290の証拠として保存し、新成功へ転記しない。現在はmetadata人工だけの準備段階。Raw/CSV/旧Native/Source/金融/新指標/退出採否/PnLを処理しない。

Rootは[雛形](実行条件の雛形.json)を別の新規実行条件.jsonへ保存し、producer停止SHA、生成receiptSHA、所有コードSHA256を固定する。producer停止path/生成先も引数と一致させる。コードを後日SHA定数のために編集しない。

版3でRootが指定する値はcf49b2…（producer）とe1a29c…（生成receipt）。全てのSHAはCLIへ省略なく渡す。条件JSON SHAはRootが新規作成した本文から計算する。

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101producer指定の読取照合/指定producerを読み戻す.py' --run `
  --input 'work/101連続入力の実行/接続2場_版3' `
  --producer-stop 'work/101連続入力の試作_版3/停止.json' `
  --producer-stop-sha cf49b2b643afcfda478a5d383c6d5e73bbbee3b477d2a0edc0e45b745ef4d16c `
  --receipt-sha e1a29ceef23ca53424ac8d45b9d2e78566d2e1c885a647ec846da6cb0e9c7c48 `
  --condition 'work/101producer指定の読取照合/実行条件.json' `
  --condition-sha <Root固定条件JSONのSHA256> `
  --out 'work/101producer指定の読取照合/版3実2場.json' --workers 2
```

条件の`監査コードSHA256`はこの停止.jsonの`所有コードSHA256`をコピーする。空欄のままでは本文前に拒否する。出力は所有workの未存在JSONだけ。Rootだけが実行する。

結果scopeは旧核と同じ説明、入力構築receiptSHA256/builder停止SHA256/details各3SHA/前後不変も旧schemaを維持する。producer停止path/核SHAを追加し、新receiptへ明示bindする。旧市場EndingはRoot別照合で、本監査はstream最終Seal復元まで。

`prepare(args)`は新生成物の配置/指紋/同producer/完全2場と旧100first2 Tape出典を検査する。データ検査は`CORE.inspect_scene`だけ。新parser/品質/形成器は複写しない。今回の人工は条件/receiptの正常と少数破損だけで、新実2場の成功ではない。
