"""生成済み連続入力を逐次読戻しし、特徴や金融を再生成しない。"""

import argparse
from collections import Counter
from concurrent.futures import ProcessPoolExecutor, as_completed
import copy
from decimal import Decimal
import gzip
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys
import time


ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
PURE_PATH=ROOT/'work/101X5独立純式/X5の純判定.py'
PURE_SHA='d927cc9ad9139a40a8aec9ef099eda5ffc226717fbaa8e8df8043942aab5dd7b'
INPUT=ROOT/'work/101連続入力の実行/接続2場_版2'
RECEIPT_SHA='1771bde305487fac60045c878f4ccdf827d0b98f2963a6cf876e5528909128bd'
BUILDER_STOP=ROOT/'work/101連続入力の試作_版2/停止.json'
BUILDER_SHA='e2901b5a4d0207bb86fb1af579cdc824d8e94cd3d37654ead732ec5a28732869'
SESSIONS=['2026-09-21_Day','2026-09-21_Night']


def digest(path):
    """
    機能: 明示済みファイルだけの指紋を逐次得る。
    引数: path(Path)は今回の入力又はコード。
    返り値: strはSHA256。Raw/Native探索をしない。
    """
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
    return h.hexdigest()


if digest(PURE_PATH)!=PURE_SHA:raise ValueError('固定品質純式のSHA差')
SPEC=importlib.util.spec_from_file_location('101読戻しの固定品質',PURE_PATH)
PURE=importlib.util.module_from_spec(SPEC);sys.modules[SPEC.name]=PURE;SPEC.loader.exec_module(PURE)


def need(value,label):
    """
    機能: 照合不成立を出典付きで停止する。
    引数: value(bool)、label(str)は条件と識別。
    返り値: None。不成立はValueError。
    """
    if not value:raise ValueError(label)


def pairs(items):
    """
    機能: JSONの重複keyを拒否する。
    引数: items(list[tuple])は字句順の組。
    返り値: dictは順序を保持した値。
    """
    value={}
    for key,item in items:need(key not in value,'重複JSON key:'+key);value[key]=item
    return value


def loads(text):
    """
    機能: 明示値だけを標準JSONで読む。
    引数: text(str)は許可入力。
    返り値: objectは値。非有限字句/重複keyは拒否。
    """
    return json.loads(text,object_pairs_hook=pairs,parse_int=lambda t:-0.0 if t=='-0' else int(t),parse_constant=lambda t:(_ for _ in ()).throw(ValueError('非有限JSON:'+t)))


def go_json(value):
    """
    機能: Go encoding/jsonの公開struct順とfloat表記で辞書SHAを再現する。
    引数: value(object)はJSONから読んだ公開payload。
    返り値: strは空白なしの内容。価格指標を計算しない。
    """
    if value is None:return 'null'
    if type(value) is bool:return 'true' if value else 'false'
    if type(value) is int:return str(value)
    if type(value) is float:
        need(math.isfinite(value),'非有限payload')
        if value==0:return '-0' if math.copysign(1,value)<0 else '0'
        text=repr(value)
        if 1e-6<=abs(value)<1e21:
            text=format(Decimal(text),'f')
            return text.rstrip('0').rstrip('.') if '.' in text else text
        mantissa,exponent=text.lower().split('e');mantissa=mantissa.removesuffix('.0');exponent=int(exponent)
        return mantissa+'e'+('+' if exponent>=0 else '-')+str(abs(exponent))
    if type(value) is str:return json.dumps(value,ensure_ascii=False).replace('&','\\u0026').replace('<','\\u003c').replace('>','\\u003e').replace('\u2028','\\u2028').replace('\u2029','\\u2029')
    if type(value) is list:return '['+','.join(go_json(v) for v in value)+']'
    need(type(value) is dict,'payload型')
    return '{'+','.join(go_json(k)+':'+go_json(v) for k,v in value.items())+'}'


def materialize(header,state):
    """
    機能: 辞書とstateから公開Snapshot全文を独立復元する。
    引数: header/state(dict)は辞書と当時参照。
    返り値: dictは公開値。辞書参照欠落は停止。
    """
    need(set(state)=={'payload_sha256','at','has_observed_clock','observed_clock','has_last_input','last_input','invalidated_at','sealed'},'State全tag')
    p=header['chart_payloads'][state['payload_sha256']]
    return {'scene':p['scene'],'at':state['at'],'has_observed_clock':state['has_observed_clock'],'observed_clock':state['observed_clock'],'has_last_input':state['has_last_input'],'last_input':state['last_input'],'invalidated_at':state['invalidated_at'],'chart':p['chart'],'three':p['three'],'fifteen':p['fifteen'],'carried_numeric_seed':p['carried_numeric_seed'],'sealed':state['sealed']}


def zero_tree(value):
    """
    機能: 初回Currentの未供給を型のゼロ値として確認する。
    引数: value(object)は公開値。
    返り値: boolは数値0/false/空文字/nilだけならtrue。
    """
    if type(value) is dict:return all(zero_tree(v) for v in value.values())
    if type(value) is list:return not value
    return value is None or value is False or value==0 or value==''


def short_quality(current,scalar):
    """
    機能: Shortの公開単位と当時時計式を検査する。
    引数: current/scalar(dict)は同原行値。
    返り値: None。窓のMoveや価格履歴を新計算しない。
    """
    at=current['time'];s=current['short'];need(s['time']==at,'Short当行Time')
    need(s['mid']==((scalar['bid']+scalar['ask'])*.5 if scalar['quote_ok'] else 0),'Short同気配中央')
    for name,width in (('five',5),('fifteen',15)):
        w=s[name];need(set(w)=={'known','move','speed','elapsed','endpoint','delay','reason'},'Short窓tag');PURE.flag(w['known'])
        if w['known']:
            need(w['endpoint']<=at-width and w['elapsed']==at-w['endpoint'] and w['delay']==at-width-w['endpoint'] and 0<=w['delay']<=15 and w['elapsed']>0,'Short既知時計')
            need(w['speed']==w['move']/w['elapsed'],'Short pt/秒式')
    for support in (current['buy'],current['sell']):
        need(support['peer_at']==0 or support['peer_at']<at,'strict過去peer')
        if support['ofi_known']:need(support['own_at']==at,'同原行OFI出典')
    n=current['night'];b=n['band']
    if n['available'] and n['window']=='E08' and b['quantity_known']:need(b['time']==at and b['index']==current['source_index'],'E08同原行量')
    need(b['line']==b['index'] and b['start_line']==b['start_index'],'E08 Lineの特徴連番名前空間')


def crosses_last0(window,current_time,last0_time):
    """
    機能: 元形成契約でLast0を挟んだ既知短秒を補助計数する。
    引数: window(dict)、current_time/last0_time(float)は保存窓と最後のLast0時計。
    返り値: boolはKnownかつEndpoint<Last0<=Current。既知旗を変更しない。
    """
    return bool(window['known'] and last0_time>0 and window['endpoint']<last0_time<=current_time)


def inspect_values(header,records,tape):
    """
    機能: 全recordの時計/源/品質/旧Input/Sealを逐次検査する。
    引数: header(dict)、records(iterator[dict])、tape(dict)は許可済み保存値。
    返り値: dictは件数と範囲。指標/Source/金融/退出採否は生成しない。
    """
    need(header['version']==1 and header['streamed'] is True and header['rows'] is None and header['trace'] is None,'stream header版/保持列')
    need(header['source_reexecuted'] is False and header['financial_executed'] is False and header['legacy_ending_compared'] is False,'計算scope')
    need(header['session']==tape['session'] and tape['version']==1,'旧Tape場')
    for key,p in header['chart_payloads'].items():
        need(set(p)=={'scene','chart','three','fifteen','carried_numeric_seed'},'Payload全tag')
        need(hashlib.sha256(go_json(p).encode('utf-8')).hexdigest()==key,'辞書内容SHA:'+key)
    quotes=[];grids=[];last_tape_time=0
    for i,e in enumerate(tape['events'],1):
        need(e['ordinal']==i and e['at']>=last_tape_time,'旧Tape ordinal/時計');last_tape_time=e['at'];need(e['kind'] in ('quote','grid','force'),'旧Tape種別')
        if e['kind']=='quote':quotes.append(e)
        if e['kind']=='grid':grids.append(e)
    session=header['session'];start=session['start'];last_at=0;phase=-1;nk_at=None;last_input=None;last_current=None;last_snapshot=None;invalidated=0;last0_time=0
    all_index=Counter();feature_index=Counter();last_line={};last_market_time={};merge=0;row_count=0;grid_count=0;history=[];pending=[];next3=start+180;next15=start+900
    forms={180:{'rows':0,'bad':False,'last':None},900:{'rows':0,'bad':False,'last':None}};counts=Counter()
    for record_no,rec in enumerate(records,1):
        row=rec.get('row');control=rec.get('control');need((row is not None)!=(control is not None),'record排他')
        if row is not None:
            need(rec['kind']=='row' and set(rec)=={'kind','row','tape_ordinal'},'row全tag');identity=row['identity'];state=row['chart_state'];at=identity['time'];kind='raw';raw=True
        else:
            need(rec['kind']=='control' and set(rec)<= {'kind','control','tape_ordinal'},'control全tag');kind=control['kind'];need(kind in ('publication','grid','raw'),'control種別');identity=control.get('identity');state=control['chart_state'];at=control['at'];raw=kind=='raw'
        need(at>=last_at,'record時計逆行');order=0 if kind=='publication' else 1 if kind=='grid' else 2
        if at!=last_at:phase=-1;nk_at=None
        need(order>=phase,'同秒公表/Grid/raw順');phase=order;last_at=at
        snapshot=materialize(header,state);need(snapshot['at']==at and snapshot['scene']['id']==session['id'] and snapshot['scene']['start']==start,'当時Snapshot場/At')
        need(not snapshot['sealed'],'stream途中Seal');PURE.validate_snapshot(snapshot,at)
        if not raw:pending.append((at,snapshot['observed_clock']))
        if kind=='publication':
            need(at==next3,'3分公表の連続性');next3+=180;invalidated=0
            for width,name in ((180,'three'),(900,'fifteen')):
                if width==900 and at!=next15:continue
                form=forms[width];bar=snapshot[name];need(bar['bar_end']==at and bar['available_at']==at and bar['rows']==form['rows'] and bar['has_last_source']==(form['rows']>0) and bar['data_known']==(form['rows']>0 and not form['bad']),'足の公開/全行数/Last既知')
                if form['last'] is not None:need(bar['last_source']==form['last'],'足の最終源')
                forms[width]={'rows':0,'bad':False,'last':None}
                if width==900:next15+=900
            history=(history+[snapshot])[-3:];counts['publications']+=1
        elif kind=='grid':
            need(grid_count<len(grids),'余分Grid');old=grids[grid_count];need(rec['tape_ordinal']==old['ordinal'],'Grid旧ordinal');g=header['grids'][grid_count]
            need(g==old['context'],'旧5分Input全文');need(g['chart']==snapshot and g['at']==at and g['kind']==session['kind'] and g['recent3']==history,'Grid公開値復元')
            need(g['current']==last_current if last_current is not None else zero_tree(g['current']),'Grid直前Current・同秒先取禁止')
            PURE.validate(g,1);grid_count+=1;counts['quality_inputs']+=1
        else:
            need(identity is not None and set(identity)=={'market','time','physical_line','market_all_index','features_index','merge_ordinal'},'raw識別全tag')
            market=identity['market'];need(market in ('TOPIX','NK225'),'raw市場');need(identity['time']==at,'raw時計源');merge+=1
            need(type(identity['market_all_index']) is int and identity['market_all_index']==all_index[market] and identity['merge_ordinal']==merge,'全受理/merge連番');all_index[market]+=1
            need(type(identity['physical_line']) is int and identity['physical_line']>last_line.get(market,0) and at>=last_market_time.get(market,0),'物理行/同Time順');last_line[market]=identity['physical_line'];last_market_time[market]=at
            if market=='TOPIX':need(nk_at!=at,'同時計TOPIX先行')
            else:nk_at=at
            idx=identity['features_index']
            if idx is not None:need(type(idx) is int and idx==feature_index[market],'FeaturesIndex');feature_index[market]+=1
            need(snapshot['observed_clock']==at,'raw観測時計')
            for logical,observed in pending:need(logical<=at and observed==at,'公表drain上限の源')
            pending=[]
            if market=='NK225':
                stamp=snapshot['last_input'];need(snapshot['has_last_input'] and stamp['time']==at and stamp['index']==identity['market_all_index'] and stamp['line']==identity['physical_line'],'Chart当NK全受理源')
                if row is None:
                    need(idx is None and stamp['valid'] is False and stamp['last']<=0,'Last0偽Current禁止');invalidated=at;last0_time=at;counts['nk_bad_last']+=1
                    need(not any(snapshot['chart']['Technical'][n] for n in ('trend_known','exit_known','reversal_known','spike_known','atr_known')) and not snapshot['chart']['Previous3Known'],'Last0の技法失効')
                else:
                    need(idx is not None and stamp['valid'] is True,'正NK marker');row_count+=1;q=row['scalar'];c=row['current'];need(row['positive_nk_ordinal']==row_count and row_count<=len(quotes),'正NK連番/集合');old=quotes[row_count-1]
                    need(rec['tape_ordinal']==old['ordinal'] and q==old['quote'],'旧Scalar11全文/ordinal')
                    need(set(q)=={'time','received','index','source_line','last','bid','ask','quote_ok','atr','atr_available','atr_nominal'},'Scalar11全tag')
                    need(q['time']==at==q['received'] and q['index']==idx and q['source_line']==identity['physical_line'] and q['last']>0 and q['quote_ok']==(0<q['bid']<q['ask']),'Scalar識別/気配')
                    need(type(q['quote_ok']) is bool and q['atr']>=0 and 0<=q['atr_nominal']<=q['atr_available']<=at,'Scalar ATR公開/気配型')
                    need(stamp['last']==q['last'],'Chart同Last')
                    need(c['reference']=='NK225' and all(c[a]==q[b] for a,b in [('time','time'),('received','received'),('source_index','index'),('source_line','source_line'),('last','last'),('bid','bid'),('ask','ask')]),'Current同Scalar原行')
                    recent=[materialize(header,ref) for ref in row['recent3_refs']];need(recent==history,'Recent3当時State全文')
                    incoming={'snapshot_id':session['id']+'-R'+str(row_count),'at':at,'kind':session['kind'],'chart':snapshot,'recent3':recent,'current':c};PURE.validate(incoming,1);short_quality(c,q);counts['quality_inputs']+=1
                    counts['short5_known']+=int(c['short']['five']['known']);counts['short15_known']+=int(c['short']['fifteen']['known']);counts['bad_bbo']+=int(not q['quote_ok']);last_current=c
                    counts['short5_known_cross_last0']+=int(crosses_last0(c['short']['five'],at,last0_time));counts['short15_known_cross_last0']+=int(crosses_last0(c['short']['fifteen'],at,last0_time))
                for form in forms.values():form['rows']+=1;form['bad']=form['bad'] or not stamp['valid'];form['last']=stamp
                last_input=stamp
            else:need(row is None,'TOPIXにCurrentを作らない')
            counts['raw_'+market]+=1
            if last_snapshot is not None and not (market=='NK225' and row is None):need(snapshot['chart']==last_snapshot['chart'],'公表/Last0以外の数値更新禁止')
        need(snapshot['invalidated_at']==invalidated,'Last0失効時計')
        need(snapshot['last_input']==last_input if last_input is not None else not snapshot['has_last_input'],'Snapshot最新NK源')
        last_snapshot=snapshot;counts['records']+=1
        if record_no%50000==0:print(session['id']+' 読戻し '+str(record_no),flush=True)
    need(not pending and row_count==header['row_count']==len(quotes) and grid_count==len(header['grids'])==len(grids) and counts['records']==header['trace_count'],'全record/Raw/Grid集合')
    ending=materialize(header,header['ending']);expected=dict(last_snapshot);expected['sealed']=True;need(ending==expected,'Endingは最終streamのSealだけ');PURE.validate_snapshot(ending,ending['at'])
    return {'処理完了':True,'session':session['id'],'不一致':0,'counts':dict(counts),'正NK原行':row_count,'全旧5分Input':grid_count,'辞書':len(header['chart_payloads']),'Ending復元':True,'旧市場Ending比較':False,'Source/特徴/金融再計算':0,'退出採否/PnL':0}


def read_records(path):
    """
    機能: 許可されたJSONLだけを逐次展開する。
    引数: path(Path)は生成済みstream。
    返り値: iterator[dict]は全record。Rawを開かない。
    """
    with gzip.open(path,'rt',encoding='utf-8') as stream:
        for text in stream:yield loads(text)


def inspect_scene(header_path,stream_path,tape_path):
    """
    機能: 許可一場の保存値だけを読み戻す。
    引数: 3path(Path)はheader/stream/既存Tape。
    返り値: dictは監査結果。Source通知の意味展開はしない。
    """
    before={str(p.resolve()):digest(p) for p in (header_path,stream_path,tape_path)};header=loads(header_path.read_text(encoding='utf-8'))
    with gzip.open(tape_path,'rt',encoding='utf-8') as stream:tape=loads(stream.read())
    result=inspect_values(header,read_records(stream_path),tape);after={str(p.resolve()):digest(p) for p in (header_path,stream_path,tape_path)};need(before==after,'場入力前後不変');result.update({'成功':True,'前後不変':True,'入力SHA256':before});return result


def main():
    """
    機能: Root許可first2成功receiptへ結んだ監査だけを実行する。
    引数: CLI --input/--out/--workersは生成済み2場/新規先/1..2。
    返り値: intは成功0、例外時1。
    """
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--workers',type=int,default=2);args=ap.parse_args()
    need(args.input.resolve()==INPUT.resolve() and not args.out.exists() and 1<=args.workers<=2,'固定first2/新規出力/worker')
    receipt_path=args.input/'完了.json';need(digest(receipt_path)==RECEIPT_SHA and digest(BUILDER_STOP)==BUILDER_SHA,'固定receipt/停止SHA')
    receipt=loads(receipt_path.read_text(encoding='utf-8'));need(receipt['成功'] is True and receipt['前後不変'] is True and receipt['stage']=='first2' and receipt['sessions']==SESSIONS and len(receipt['details'])==2,'完全成功2場')
    need(receipt['source_reexecuted'] is False and receipt['financial_executed'] is False,'実行scope')
    paths=[receipt_path,BUILDER_STOP,Path(__file__),HERE/'計画.md',HERE/'README.md',HERE/'人工を確認する.py',PURE_PATH,PURE.PUBLIC_PATH];tasks=[]
    for detail in receipt['details']:
        hp=ROOT/detail['header'];sp=ROOT/detail['path'];need(digest(hp)==detail['header_SHA256'] and digest(sp)==detail['SHA256'],'生成物SHA');h=loads(hp.read_text(encoding='utf-8'));tp=Path(h['provenance']['old_tape_path']);need(detail['session'] in SESSIONS and h['session']['id']==detail['session'],'許可scene')
        need(digest(tp)==h['provenance']['old_tape_gzip_sha256']==receipt['入力コードSHA256前後'][str(tp)],'既存first2 Tape出典')
        paths.extend([hp,sp,tp]);tasks.append((hp,sp,tp))
    before={str(p.resolve()):digest(p) for p in paths};details=[];start=time.time()
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for fut in as_completed([pool.submit(inspect_scene,*task) for task in tasks]):details.append(fut.result())
    after={str(p.resolve()):digest(p) for p in paths};need(before==after,'入力code前後不変')
    result={'成功':True,'scope':'固定100由来の連続入力first2の全保存record読戻し・技法値の再生成なし','stage':'first2','sessions':SESSIONS,'入力構築receiptSHA256':RECEIPT_SHA,'builder停止SHA256':BUILDER_SHA,'品質コードSHA256':PURE_SHA,'details':sorted(details,key=lambda x:x['session']),'前後不変':True,'入力codeSHA256前':before,'入力codeSHA256後':after,'経過秒':time.time()-start,'RawCSV旧Native追加読取':0,'特徴Source金融再生成':0,'退出採否/PnL':0,'限界':['技法/Short/OFI/E08の値をRawから再計算していない','TOPIXの正Last markerの原板真偽は既存builderに依存','品質validateのみでassess/金融active/freeを評価しない','Endingは最終streamのSeal一致。旧市場EndingはRoot別照合a9e76a42']}
    args.out.parent.mkdir(parents=True,exist_ok=True)
    with args.out.open('x',encoding='utf-8') as stream:json.dump(result,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps({'成功':True,'場数':len(details),'records':sum(x['counts']['records'] for x in details),'出力':str(args.out)},ensure_ascii=False));return 0


if __name__=='__main__':
    try:raise SystemExit(main())
    except Exception as exc:print(str(exc),file=sys.stderr);raise
