"""停止Go公開型だけで読戻し正常と狭い破損を確認する。"""

import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
SPEC=importlib.util.spec_from_file_location('101読戻し人工',HERE/'読み戻しを照合する.py');CORE=importlib.util.module_from_spec(SPEC);sys.modules[SPEC.name]=CORE;SPEC.loader.exec_module(CORE)


def main():
    """
    機能: 既存Go型人工の正常と保存値破損を検査する。
    引数: なし。新しい特徴/金融運転をしない。
    返り値: intは成功0。不成立は例外。
    """
    paths=sorted((ROOT/'work/101連続入力の試作_版2/人工_停止版').glob('*.json'));CORE.need(len(paths)==2,'停止Go人工2本');normal=[];bad=[]
    for p in paths:
        value=CORE.loads(p.read_text(encoding='utf-8'));h=value['stream_header'];records=value['stream_records'];t=value['legacy_artificial'];normal.append(CORE.inspect_values(h,iter(records),t))
    value=CORE.loads(paths[0].read_text(encoding='utf-8'));h=value['stream_header'];records=value['stream_records'];t=value['legacy_artificial'];ri=next(i for i,r in enumerate(records) if r['kind']=='row');gi=next(i for i,r in enumerate(records) if r.get('control',{}).get('kind')=='grid');rj=next(i for i,r in enumerate(records) if r.get('row',{}).get('recent3_refs'))
    cases=[('FeaturesIndex',lambda hh,rr,tt:rr[ri]['row']['identity'].__setitem__('features_index',9)),('旧ordinal',lambda hh,rr,tt:rr[ri].__setitem__('tape_ordinal',999)),('物理行',lambda hh,rr,tt:rr[ri]['row']['identity'].__setitem__('physical_line',0)),('Current出典',lambda hh,rr,tt:rr[ri]['row']['current'].__setitem__('source_line',999)),('Chart源',lambda hh,rr,tt:rr[ri]['row']['chart_state']['last_input'].__setitem__('index',99)),('Last0偽Current',lambda hh,rr,tt:rr[ri]['row']['chart_state']['last_input'].__setitem__('valid',False)),('Recent参照',lambda hh,rr,tt:rr[rj]['row']['recent3_refs'][0].__setitem__('payload_sha256','missing')),('Short時間',lambda hh,rr,tt:rr[ri]['row']['current']['short'].__setitem__('time',999)),('Grid復元',lambda hh,rr,tt:rr[gi]['control']['chart_state'].__setitem__('at',1)),('Ending未来',lambda hh,rr,tt:hh['ending'].__setitem__('at',hh['ending']['at']+1)),('辞書改変',lambda hh,rr,tt:next(iter(hh['chart_payloads'].values()))['chart']['Technical'].__setitem__('close3',123))]
    for name,mutate in cases:
        hh,rr,tt=copy.deepcopy((h,records,t));mutate(hh,rr,tt)
        try:CORE.inspect_values(hh,iter(rr),tt)
        except (ValueError,KeyError,AssertionError,IndexError) as exc:bad.append({'破損':name,'拒否':str(exc)})
        else:raise ValueError('破損を受理:'+name)
    checks=[({'known':True,'endpoint':10},30,20,True),({'known':True,'endpoint':20},30,20,False),({'known':False,'endpoint':10},30,20,False),({'known':True,'endpoint':10},15,20,False)]
    for w,at,last,expected in checks:CORE.need(CORE.crosses_last0(w,at,last)==expected,'Last0補助境界')
    result={'成功':True,'scope':'停止Go公開型人工だけ・Source/金融/Raw/Native未実行','正常':normal,'破損拒否':bad,'Last0補助境界':len(checks),'入力SHA256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},'コードSHA256':hashlib.sha256((HERE/'読み戻しを照合する.py').read_bytes()).hexdigest()}
    out=HERE/'人工確認.json'
    with out.open('x',encoding='utf-8') as stream:json.dump(result,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps({'成功':True,'正常':len(normal),'破損拒否':len(bad)},ensure_ascii=False));return 0


if __name__=='__main__':raise SystemExit(main())
