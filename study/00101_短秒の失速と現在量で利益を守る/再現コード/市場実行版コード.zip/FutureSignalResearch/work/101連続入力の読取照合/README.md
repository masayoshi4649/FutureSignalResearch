# 連続入力の保存読戻し監査

固定builder版2 e290とfirst2成功receipt1771へ結び、既存header/stream/first2 Tapeだけを逐次読み戻す。[計画](計画.md)の範囲で、Raw/CSV/旧Nativeを追加で開かず、技法値/Source/金融を再生成しない。

公開APIは`inspect_values(header,records,tape)->dict`と`inspect_scene(header_path,stream_path,tape_path)->dict`。SnapshotはPayload/Stateを独立復元し、Go JSON内容SHAを照合する。全旧5分Inputは旧Tapeと、streamの当時公表値/直前Currentの両方へ結ぶ。Endingは最終stream状態のSeal一致までで、旧市場EndingはRoot別a9e7証拠と区別する。

品質関数は停止d927の`validate`だけを使用し、assess/符号採否を実行しない。Shortの既知時計式は検査するが、Move/OFI/E08を新形成しない。Last0をFeaturesへ入れない旧契約の補助観測として、Known5/15秒のEndpoint<直前Last0<=Currentを別計数し、未知へ書き換えない。

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101連続入力の読取照合/人工を確認する.py'

& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101連続入力の読取照合/読み戻しを照合する.py' `
  --input 'work/101連続入力の実行/接続2場_版2' `
  --out 'work/101連続入力の読取照合/実2場.json' --workers 2
```

実CLIは成功receipt・完全2場・入力SHA・新規出力を検査する。全54への拡張はこのCLIで行わず、Rootの別許可/条件へ汎用APIを接続する段階とする。topの`入力構築receiptSHA256`は1771、`前後不変`はこの監査が読んだ入力/コード集合について保存する。`details[].入力SHA256`は各場header/stream/旧Tapeの3path→SHAで、Raw/CSVの再認証ではない。

原板の真の価格/数量を再検算する監査ではない。TOPIX正Last markerの真偽、OFI/E08の形成、技法数値の計算正しさは固定builderと旧証拠に依存する。入力品質の整合性を退出成立/利益改善とは呼ばない。機会損失/未参加・退出後価格は扱わない。
