"""Root専用の全54入力生成と、固定Native場末だけの限定照合。準備中は人工のみ。"""

import argparse
import gzip
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import re
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PROOF = ROOT / 'study/00100_費用後利益化の前後で保護を分ける/完了記録.json'
PROOF_SHA = '4a8bc486e329f65f17e2395f781b2efd7cf76c5630d91924b611e90254725af3'
CATALOG = ROOT / 'work/101保有技法の抽出実行案/許可54.json'
CATALOG_SHA = '43da423e99a760023b3dafea1a00e1529411d0f84b663105b823ad9879b8d6c8'
CORE_PATH = CATALOG.with_name('保有枠の抽出.py')
CORE_SHA = '799e407575b76951fe2879ece3a900b823916684c65dbbd941082cb8e7759950'
SELECTOR_PATH = CATALOG.with_name('固定Nativeを抽出する.py')
SELECTOR_SHA = '744dab154cda438e829f35caf72c58164fa7c5b82a1b08413561317e77795df0'
BUILDER = ROOT / 'work/101連続入力の試作_版2'
BUILDER_SHA = 'e2901b5a4d0207bb86fb1af579cdc824d8e94cd3d37654ead732ec5a28732869'
FIRST = ROOT / 'work/101連続入力の実行/接続2場_版2/完了.json'
FIRST_SHA = '1771bde305487fac60045c878f4ccdf827d0b98f2963a6cf876e5528909128bd'
FIRST_ENDING = FIRST.with_name('場末の独立照合.json')
FIRST_ENDING_SHA = 'a9e76a42145a27efa21803f9babb797c59d9cdb380d2e2a3da38f35b5515fa43'
MATERIALIZE_PATH = ROOT / 'work/101連続入力の実行/場末を照合する.py'
MATERIALIZE_SHA = '4b8db87a53de8c1994ba7db2f364989e44629190d99027650ff45b684c526f66'
MANIFEST = ROOT / 'study/00080_FAR後期三手法の15分移植と利益保護/入力台帳.json'
MANIFEST_SHA = 'b939bc91b33fd86e933534c3b991d844b8a0200a5f14710e1bd5004edc1aab42'
INDEX = PROOF.with_name('正式54Tape台帳.json')
FIRST_IDS = ['2026-09-21_Day', '2026-09-21_Night']
SCOPE = '固定100許可54の連続入力生成と限定Ending照合'
READBACK_SCOPE = '固定100由来の連続入力first2の全保存record読戻し・技法値の再生成なし'


def need(value, reason):
    """
    機能: 実行前条件又は限定照合の不一致を明示的に拒否する。
    引数: value(bool)、reason(str)は条件と理由。
    返り値: None。不成立ならValueError。
    """
    if not value:
        raise ValueError(reason)


def digest(path):
    """
    機能: 明示したコード/metadata/許可gzipの内容指紋を得る。
    引数: path(Path)は対象。
    返り値: strはSHA256。gzipを意味展開しない。
    """
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path):
    """
    機能: metadata又は生成headerだけをJSONへ展開する。
    引数: path(Path)は明示先。Nativeへこの関数を使わない。
    返り値: dictは重複key/非有限を拒否した値。
    """
    def pairs(rows):
        """
        機能: 同じobject内の重複keyを拒否する。
        引数: rows(list[tuple])はJSON decoderの順序値。
        返り値: dictは一意のobject。
        """
        result = {}
        for key, value in rows:
            need(key not in result, 'JSON重複key')
            result[key] = value
        return result
    def bad(value):
        """
        機能: 非有限JSON定数を拒否する。
        引数: value(str)は定数表記。
        返り値: None。常にValueError。
        """
        raise ValueError('JSON非有限: ' + value)
    return json.loads(path.read_text(encoding='utf-8'), object_pairs_hook=pairs, parse_constant=bad)


def fixed(name, path, expected):
    """
    機能: 停止済み射影/metadata/場末復元だけを指紋付きで読み込む。
    引数: name/expected(str)、path(Path)はmodule名・指紋・コード。
    返り値: moduleは固定部品。importで市場本文は開かない。
    """
    need(digest(path) == expected, '固定部品SHA差: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


CORE = fixed('固定限定射影799_全54Ending', CORE_PATH, CORE_SHA)
SELECTOR = fixed('固定許可54metadata744_全54Ending', SELECTOR_PATH, SELECTOR_SHA)
END = fixed('固定Root場末復元_全54Ending', MATERIALIZE_PATH, MATERIALIZE_SHA)


def project(text):
    """
    機能: 固定字句射影へsession/contract/chart_endだけを許可する。
    引数: text(str)はSHA確認済みNative又は小人工。
    返り値: dictは3fieldのみ。books/Source/損益/峰を展開しない。
    """
    value, end = CORE.project_value(text, 0, {name: True for name in ('session', 'contract', 'chart_end')})
    need(CORE.whitespace(text, end) == len(text) and set(value) == {'session', 'contract', 'chart_end'},
         '限定3fieldの完全性')
    return value


def same(actual, expected, label):
    """
    機能: 公開Endingを全tag/型/値で除外なく比較する。
    引数: actual/expected(object)、label(str)は復元値・旧値・位置。
    返り値: intは比較葉数。int/floatのJSON数値表記だけを同値とする。
    """
    if type(expected) is dict:
        need(type(actual) is dict and set(actual) == set(expected), label + ':全tag')
        return 1 + sum(same(actual[key], value, label + '/' + key) for key, value in expected.items())
    if type(expected) is list:
        need(type(actual) is list and len(actual) == len(expected), label + ':配列')
        return 1 + sum(same(a, b, label + '/' + str(i)) for i, (a, b) in enumerate(zip(actual, expected)))
    if type(expected) in (int, float):
        need(type(actual) in (int, float) and math.isfinite(actual) and math.isfinite(expected)
             and actual == expected, label + ':数値')
    else:
        need(type(actual) is type(expected) and actual == expected, label + ':型/値')
    return 1


def validate_ending(value, session):
    """
    機能: 限定Nativeの場/限月とsealed公開Snapshotを検査する。
    引数: value(dict)、session(str)は3fieldと許可ID。
    返り値: None。未来足/0補完を追加しない。
    """
    need(value['session'] == session and type(value['contract']) is str and bool(value['contract']), '限定場/限月')
    ending = value['chart_end']
    need(ending['scene']['id'] == session and ending['scene']['contract'] == value['contract']
         and ending['sealed'] is True, '限定Ending場/限月/sealed')
    CORE.PUBLIC.finite_tree(ending)
    CORE.PUBLIC.validate_snapshot(ending, ending['at'])


def validate_first(first, ending, builder_stop):
    """
    機能: 既済みfirst2と限定Endingを同版13コードへ結ぶ。
    引数: first/ending/builder_stop(dict)は固定成功2証拠と版2停止。
    返り値: None。完全2場/除外0を必要とする。
    """
    need(first['成功'] is True and first['前後不変'] is True and first['stage'] == 'first2'
         and first['sessions'] == FIRST_IDS and first['固定100完了SHA256'] == PROOF_SHA,
         '同版first2成功/完全2場')
    need(first['scope'] == '固定100と旧Tapeの連続技法sidecar構築'
         and first['source_reexecuted'] is False and first['financial_executed'] is False,
         'first2 Source/金融非実行')
    need(first['所有コードSHA256'] == builder_stop['所有コードSHA256'], '2→54 builder同版')
    need([row['session'] for row in first['details']] == FIRST_IDS, 'first2詳細全集合')
    need(ending['成功'] is True and ending['前後不変'] is True
         and ending['scope'] == '先頭2場sidecar場末の独立辞書復元と固定100 chart_endの全値比較'
         and [row['session'] for row in ending['場末']] == FIRST_IDS,
         'first2限定Ending成功/完全2場')
    by_first = {row['session']: row for row in first['details']}
    for row in ending['場末']:
        need(row['一致'] is True and row['field除外'] == []
             and row['header_SHA256'] == by_first[row['session']]['header_SHA256'], 'first2 Ending除外0/header結合')
    need(FIRST_SHA in ending['入力コードSHA256前後'].values(), 'first2 Endingと1771 receiptの結合')


def validate_readback(value, expected_sha, supplied_sha, first=None, tapes=None):
    """
    機能: Rootが実行条件へ固定した独立readbackをfirst2成功へ結ぶ。
    引数: value(dict)、expected_sha/supplied_sha(str)、first/tapes(dict|None)は成功meta・条件値・CLI値・先行出典。
    返り値: None。未受領/別版/不完全2場を拒否する。
    """
    need(type(expected_sha) is str and re.fullmatch('[0-9a-f]{64}', expected_sha)
         and expected_sha == supplied_sha and set(expected_sha) != {'0'}, 'readback SHAの事前明示')
    need(value['成功'] is True and value['前後不変'] is True and value['stage'] == 'first2'
         and value['sessions'] == FIRST_IDS and value['入力構築receiptSHA256'] == FIRST_SHA
         and value['builder停止SHA256'] == BUILDER_SHA,
         'readback成功/1771 first2/完全2場')
    need(value['scope'] == READBACK_SCOPE, 'readback成功scope')
    need(value['入力codeSHA256前'] == value['入力codeSHA256後'] and bool(value['入力codeSHA256前']),
         'readback入力/コード前後辞書')
    need(all(type(value[name]) is int and value[name] == 0
             for name in ('RawCSV旧Native追加読取', '特徴Source金融再生成', '退出採否/PnL')),
         'readbackの非再生成/非金融scope')
    need(type(value['details']) is list and [row['session'] for row in value['details']] == FIRST_IDS,
         'readback全2場詳細')
    by_first = {} if first is None else {row['session']: row for row in first['details']}
    for row in value['details']:
        need(row['成功'] is True and row['処理完了'] is True and type(row['不一致']) is int
             and row['不一致'] == 0 and row['前後不変'] is True
             and row['Ending復元'] is True and row['旧市場Ending比較'] is False,
             'readback場別成功/Ending復元scope')
        need(row['Source/特徴/金融再計算'] == 0 and row['退出採否/PnL'] == 0, 'readback場別の非売買scope')
        need(type(row['counts']) is dict and bool(row['counts'])
             and all(type(row[name]) is int and row[name] > 0 for name in ('正NK原行', '全旧5分Input', '辞書')),
             'readback各計数の型/非空')
        hashes = row['入力SHA256']
        need(type(hashes) is dict and len(hashes) == 3
             and all(Path(path).is_absolute() and re.fullmatch('[0-9a-f]{64}', sha)
                     for path, sha in hashes.items()), 'readbackは3明示入力のSHA')
        if first is not None:
            source = by_first[row['session']]
            wanted = {source['header_SHA256'], source['SHA256'], tapes[row['session']]}
            need(set(hashes.values()) == wanted, 'readbackのheader/stream/Tape出典')


def owned():
    """
    機能: 市場前停止で必要な自コード/計画/人工を列挙する。
    引数: なし。
    返り値: dictはrepo相対5fileの指紋。
    """
    names = ('生成と場末を照合する.py', '人工を確認する.py', '計画.md', 'README.md', '実行条件の雛形.json')
    return {str((HERE / name).relative_to(ROOT)): digest(HERE / name) for name in names}


def save_new(path, value):
    """
    機能: 新規の小型JSONだけを保存する。
    引数: path(Path)、value(dict)は新規先と値。
    返り値: None。既存は上書きしない。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def prepare(args):
    """
    機能: 全54実行前のmetadataだけを固定し、Native/Raw本文はまだ開かない。
    引数: args(argparse.Namespace)はcondition/readback/readback_sha/stop/out。
    返り値: tupleは条件/許可54/前後指紋/Builder停止。
    """
    need(not args.out.exists() and args.out.resolve().parent == HERE.resolve(), '新規出力は全54work直下だけ')
    condition = load(args.condition)
    need(set(condition) == {'version', 'scope', 'stage', 'builder停止SHA256', 'first2SHA256', 'first2EndingSHA256',
                            'readbackSHA256', 'positiveNK上限', 'heap標本上限MiB', 'worker', '新規出力',
                            'Source再実行', '金融実行'}, '実行条件の全field')
    need(type(condition['version']) is int and condition['version'] == 1
         and condition['scope'] == SCOPE and condition['stage'] == 'full54'
         and condition['builder停止SHA256'] == BUILDER_SHA and condition['first2SHA256'] == FIRST_SHA
         and condition['first2EndingSHA256'] == FIRST_ENDING_SHA
         and type(condition['positiveNK上限']) is int and condition['positiveNK上限'] == 4000000
         and type(condition['heap標本上限MiB']) is int and condition['heap標本上限MiB'] == 32768
         and type(condition['worker']) is int and condition['worker'] == 1
         and condition['Source再実行'] is False and condition['金融実行'] is False
         and (ROOT / condition['新規出力']).resolve() == args.out.resolve(), '固定54/資源/非売買条件')
    need(re.fullmatch('[0-9a-f]{64}', args.readback_sha or '') is not None
         and condition['readbackSHA256'] == args.readback_sha, 'readback未固定は本文前拒否')
    need(digest(args.readback) == args.readback_sha, 'readbackファイルSHA差')
    validate_readback(load(args.readback), condition['readbackSHA256'], args.readback_sha)
    stop = load(args.stop)
    need(stop['成功'] is True and stop['市場本文読取'] == 0 and stop['所有コードSHA256'] == owned(), '今回停止コード同体')
    fixed_files = {PROOF: PROOF_SHA, CATALOG: CATALOG_SHA, CORE_PATH: CORE_SHA, SELECTOR_PATH: SELECTOR_SHA,
                   BUILDER / '停止.json': BUILDER_SHA, FIRST: FIRST_SHA, FIRST_ENDING: FIRST_ENDING_SHA,
                   MATERIALIZE_PATH: MATERIALIZE_SHA, MANIFEST: MANIFEST_SHA}
    need(all(digest(path) == sha for path, sha in fixed_files.items()), '先行固定metadata/コードSHA')
    builder_stop = load(BUILDER / '停止.json')
    need(builder_stop['成功'] is True and builder_stop['固定100完了SHA256'] == PROOF_SHA, 'builder停止成功')
    validate_first(load(FIRST), load(FIRST_ENDING), builder_stop)
    expected, dependencies = SELECTOR.catalog(PROOF)
    catalog = load(CATALOG)
    rows = SELECTOR.choose(catalog, expected, 'full54')
    need(len(rows) == 54, '許可54全体だけ')
    proof = load(PROOF)
    need(digest(INDEX) == proof['自己を除く正式指紋']['正式54Tape台帳.json'], '固定100の正式54Tape台帳')
    index = load(INDEX)
    need(index['version'] == 1 and index['stage'] == 'full54'
         and [row['session'] for row in index['entries']] == [row['session'] for row in rows], '旧Tape54全集合')
    before = {str(path.resolve()): sha for path, sha in fixed_files.items()}
    for path, sha in load(args.readback)['入力codeSHA256前'].items():
        absolute = str(Path(path).resolve())
        need(absolute not in before or before[absolute] == sha, 'readbackと今回固定指紋の競合')
        before[absolute] = sha
    for path in (args.condition, args.readback, args.stop, INDEX):
        before[str(path.resolve())] = digest(path)
    for path, sha in {**dependencies, **owned(), **builder_stop['所有コードSHA256']}.items():
        before[str((ROOT / path).resolve())] = sha
    exe = BUILDER / '連続入力.exe'
    before[str(exe.resolve())] = builder_stop['実行物SHA256']
    need(all(digest(Path(path)) == sha for path, sha in before.items()), '実行前全固定コード/入力meta')
    first_index = INDEX.with_name('接続2場Tape台帳.json')
    need(digest(first_index) == proof['自己を除く正式指紋']['接続2場Tape台帳.json'], '旧first2 Tape台帳SHA')
    first_tapes = load(first_index)
    need(first_tapes['stage'] == 'first2'
         and [row['session'] for row in first_tapes['entries']] == FIRST_IDS, '旧first2 Tape全集合')
    validate_readback(load(args.readback), condition['readbackSHA256'], args.readback_sha,
                      load(FIRST), {row['session']: row['sha256'] for row in first_tapes['entries']})
    before[str(first_index.resolve())] = digest(first_index)
    return condition, rows, before, builder_stop


def delegated_sources(rows):
    """
    機能: 台帳metadataだけから許可54×6Raw/CSVと旧Tapeの期待指紋を作る。
    引数: rows(list)は許可Nativeの場集合。本文は開かない。
    返り値: dictは絶対path→SHA。実内容検査は固定builderへ委ねる。
    """
    manifest, index = load(MANIFEST), load(INDEX)
    by_session = {row['id']: row for row in manifest['sessions']}
    by_tape = {row['session']: row for row in index['entries']}
    expected = {}
    keys = {f'{ref}_{name}' for ref in ('NK225', 'TOPIX') for name in ('book', 'candle_60', 'candle_300')}
    source_root = Path(manifest['source_root']).resolve()
    for row in rows:
        session = row['session']
        entry = by_session[session]
        need(set(entry['files']) == keys, '許可場の明示6入力')
        for file in entry['files'].values():
            relative = Path(file['path'])
            need(not relative.is_absolute() and '..' not in relative.parts, 'Raw/CSVの台帳相対path')
            path = (source_root / relative).resolve()
            need(path.is_relative_to(source_root) and re.fullmatch('[0-9a-f]{64}', file['sha256']), 'Raw/CSV固定根/SHA')
            expected[str(path)] = file['sha256']
        tape = Path(by_tape[session]['path'])
        if not tape.is_absolute():
            tape = INDEX.parent / tape
        expected[str(tape.resolve())] = by_tape[session]['sha256']
    need(len(expected) == 54 * 7, '54場のRaw/CSV324とTape54の一意集合')
    return expected


def validate_full_receipt(receipt, rows, builder_stop):
    """
    機能: builderが同版で許可全54を処理し非売買で閉じたことを確認する。
    引数: receipt/builder_stop(dict)、rows(list)は生成完了・停止・許可集合。
    返り値: None。未完や部分集合を成功化しない。
    """
    ids = [row['session'] for row in rows]
    need(receipt['成功'] is True and receipt['前後不変'] is True and receipt['stage'] == 'full54'
         and receipt['scope'] == '固定100と旧Tapeの連続技法sidecar構築'
         and len(ids) == 54 and len(set(ids)) == 54 and receipt['sessions'] == ids
         and receipt['固定100完了SHA256'] == PROOF_SHA
         and receipt['所有コードSHA256'] == builder_stop['所有コードSHA256']
         and receipt['source_reexecuted'] is False and receipt['financial_executed'] is False,
         'builder同版完全54成功/非売買')
    need(type(receipt['details']) is list and [row['session'] for row in receipt['details']] == ids,
         'builder54詳細の全集合')


def extract_endings(rows, before):
    """
    機能: Root実行時だけ許可54Nativeから限定3fieldを逐次抽出する。
    引数: rows(list)、before(dict)は許可台帳と前後指紋。
    返り値: listは小型場末。Source/政策/損益/peakを展開しない。
    """
    result = []
    for row in rows:
        path = (ROOT / row['path']).resolve()
        need(digest(path) == row['sha256'], '限定Native固定SHA: ' + row['session'])
        before[str(path)] = row['sha256']
        with gzip.open(path, 'rt', encoding='utf-8') as stream:
            value = project(stream.read())
        validate_ending(value, row['session'])
        need(digest(path) == row['sha256'], '限定Native前後不変')
        result.append({**value, 'native_path': row['path'], 'native_SHA256': row['sha256']})
        print('限定Ending抽出 ' + row['session'], flush=True)
    return result


def compare_headers(receipt, expected_rows, before):
    """
    機能: Builder全54headerのEndingを旧場末正本へ全値照合する。
    引数: receipt(dict)、expected_rows(list)、before(dict)は生成成功・限定正本・前後指紋。
    返り値: listは除外0の場別結果。records本文は展開しない。
    """
    by_header = {row['session']: row for row in receipt['details']}
    need(len(by_header) == len(expected_rows) == 54
         and set(by_header) == {row['session'] for row in expected_rows}, '生成/限定正本の完全54')
    results = []
    for row in expected_rows:
        detail = by_header[row['session']]
        path = Path(detail['header'])
        if not path.is_absolute():
            path = ROOT / path
        path = path.resolve()
        need(path.parent == Path(receipt['_out']).resolve()
             and path.name == row['session'] + '.header.json', '生成header正規配置')
        need(digest(path) == detail['header_SHA256'], '生成header出典SHA')
        before[str(path)] = detail['header_SHA256']
        header = load(path)
        need(header['source_reexecuted'] is False and header['financial_executed'] is False
             and header['streamed'] is True and header['rows'] is None and header['trace'] is None,
             'header非売買/stream形式')
        state = header['ending']
        need(set(state) == {'payload_sha256', 'at', 'has_observed_clock', 'observed_clock',
                            'has_last_input', 'last_input', 'invalidated_at', 'sealed'}, 'Ending状態の全field')
        payload = header['chart_payloads'][state['payload_sha256']]
        need(set(payload) == {'scene', 'chart', 'three', 'fifteen', 'carried_numeric_seed'}, 'Ending辞書の全field')
        actual = END.materialize(header, state)
        count = same(actual, row['chart_end'], row['session'] + '/Ending')
        results.append({'session': row['session'], '一致': True, 'field除外': [], '比較項目数': count,
                        'header_SHA256': detail['header_SHA256'], '元NativeSHA256': row['native_SHA256']})
    return results


def run(args):
    """
    機能: Root専用full54生成と限定Ending比較を一回だけ実行する。
    引数: args(argparse.Namespace)は全明示入力と新規出力。
    返り値: dictは比較保存完了。新金融や損益を計算しない。
    """
    condition, rows, before, builder_stop = prepare(args)
    for row in rows:
        path = (ROOT / row['path']).resolve()
        need(path.is_file() and digest(path) == row['sha256'], 'Native preflight固定54')
        before[str(path)] = row['sha256']
    command = [str(BUILDER / '連続入力.exe'), '--run', '--root', str(ROOT), '--proof100', str(PROOF),
               '--allowed', str(BUILDER / '許可54.json'), '--manifest', str(MANIFEST), '--index', str(INDEX),
               '--stop', str(BUILDER / '停止.json'), '--stage', 'full54', '--first2', str(FIRST),
               '--out', str(args.out), '--max-nk-rows', '4000000', '--max-heap-mib', '32768']
    process = subprocess.run(command, cwd=ROOT, check=False)
    need(process.returncode == 0, 'builder失敗。未完出力を保持して停止')
    receipt_path = args.out / '完了.json'
    receipt = load(receipt_path)
    validate_full_receipt(receipt, rows, builder_stop)
    before[str(receipt_path.resolve())] = digest(receipt_path)
    # ----------------------------------------
    # Raw/CSV/Tapeの実内容指紋は固定builderの全6入力/場・前後検査へ結ぶ。
    delegated = receipt['入力コードSHA256前後']
    expected_sources = delegated_sources(rows)
    normalized_delegated = {str(Path(path).resolve()): sha for path, sha in delegated.items()}
    need(all(normalized_delegated.get(path) == sha for path, sha in expected_sources.items()),
         'builderのRaw/CSV324とTape54を元台帳へ結合')
    endings = extract_endings(rows, before)
    old_path = args.out / '旧100場末の限定正本.json'
    save_new(old_path, {'成功': True, 'scope': '固定100の許可54 session/contract/chart_endだけ', 'rows': endings,
                        '固定100SHA256': PROOF_SHA, '台帳SHA256': CATALOG_SHA})
    before[str(old_path.resolve())] = digest(old_path)
    comparisons = compare_headers({**receipt, '_out': str(args.out)}, endings, before)
    need(all(digest(Path(path)) == sha for path, sha in before.items()), '全54完了前後の入力/コード/Native/header')
    value = {'成功': True, 'scope': SCOPE, 'stage': 'full54', 'sessions': [row['session'] for row in rows],
             '固定100SHA256': PROOF_SHA, 'builder停止SHA256': BUILDER_SHA, 'first2SHA256': FIRST_SHA,
             'first2EndingSHA256': FIRST_ENDING_SHA, 'first2readbackSHA256': args.readback_sha,
             '実行条件SHA256': digest(args.condition), '生成receiptSHA256': digest(receipt_path),
             '場末': comparisons, '入力コードSHA256前後': before, 'builder入力前後検査辞書': delegated,
             '前後不変': True, '個別Native限定展開': 54, 'Raw/CSV処理': '固定builderだけ・台帳明示6入力/場',
             'Source/金融/新損益/機会損失/退出後値幅': 0,
             'full54独立stream読戻し': '本CLIでは未実施。first2成功を全54へ水増ししない。',
             '限定': '公開入力cacheと限定Ending全値。金融/Sの有効性/真受信時計/未知安定を証明しない。'}
    save_new(args.out / '全54場の完了照合.json', value)
    return value


def main():
    """
    機能: Rootが成功readbackを明示固定した後だけ全54を実行する。
    引数: --run(bool)、--condition/--readback/--stop/--out(Path)、--readback-sha(str)は明示入力。
    返り値: intは成功0。未固定/不一致は例外で本文処理前に拒否する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true', required=True)
    for name in ('condition', 'readback', 'stop', 'out'):
        parser.add_argument('--' + name, type=Path, required=True)
    parser.add_argument('--readback-sha', required=True)
    args = parser.parse_args()
    value = run(args)
    print(json.dumps({'成功': value['成功'], '場数': len(value['sessions']), '出力': str(args.out)}, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
