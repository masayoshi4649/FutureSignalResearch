# 全54場の連続入力と限定Ending

2026-11-09。[計画](計画.md)の準備段階。Root専用の実行口を作成しただけで、この準備では市場Native/Raw/CSV/stream本文を読まない。旧100/236/既存停止コードは編集しない。

`生成と場末を照合する.py`は版2e290 builderを全54/単一worker/4,000,000positiveNK行/32,768MiB heap標本上限で呼ぶ。先頭2場も私有Seedの順序のため同プロセスで再処理する。Source/金融/新しい約定や損益は再生成しない。旧Nativeは固定Core799の字句射影でsession/contract/chart_endだけを展開する。

必須先行証拠はfirst2 builder1771、Root限定Ending a9e7、独立readback fb534。readbackの成功scope/完全2場/1771結合/前後不変/3入力SHAを検査する。readback SHAはコードへ埋めず、Rootが実行条件JSONとCLIへ同じ値を明示する。条件JSON自体も前後指紋へ含める。[雛形](実行条件の雛形.json)は成功fb534の受領後の値であり、未固定/空/不成功へ差し替えても通らない。

実行前にRootが雛形を新規の実行条件.jsonへ保存し、その内容を確認する。停止準備の担当者は次の実コマンドを実行しない。

```powershell
if (Test-Path -LiteralPath 'work/101連続入力の全54場/実行条件.json') {
  throw '実行条件.jsonは既に存在します。内容を確認してください。'
}
Copy-Item -LiteralPath 'work/101連続入力の全54場/実行条件の雛形.json' `
  -Destination 'work/101連続入力の全54場/実行条件.json' -ErrorAction Stop

& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101連続入力の全54場/生成と場末を照合する.py' --run `
  --condition 'work/101連続入力の全54場/実行条件.json' `
  --readback 'work/101連続入力の読取照合/実2場.json' `
  --readback-sha fb5341772170b68444ff95c5a656bef2a7fcf57ed1cf4369b13b2988b616425a `
  --stop 'work/101連続入力の全54場/停止.json' `
  --out 'work/101連続入力の全54場/生成'
```

実行条件と生成先は新規のみ。既存の実行条件.jsonがある場合はコピーせず内容を確認する。実行条件の保存はRootが行い、固定雛形/コードを編集して成功を作らない。生成先に途中結果があれば上書きせず停止する。

生成先はbuilderの全header/records/完了.jsonに加え、小型の旧100場末の限定正本.json、全54場の完了照合.jsonを持つ。全header Endingを旧chart_endへ全値・除外0で照合し、場別Native/生成headerと固定コード/条件の前後SHAを保存する。Raw/CSV324入力と旧Tape54入力の内容検査は固定builderの前後辞書に結び、追加の原板走査を重ねない。

APIは`prepare(args)`（metadata・停止・指紋）、`project(text)`（限定3field）、`extract_endings(rows,before)`、`compare_headers(receipt,oldrows,before)`。後2つはRoot実行時以外に市場入力へ呼ばない。`run(args)`は全体を一度だけ実行する。

限定Ending一致は全原行Current/Raw/Recent3のfull54独立読戻しではない。first2の独立readbackを全54成功へ水増ししない。Source/金融/退出採否/新PNL・未知安定性・真受信順序も証明しない。機会損失・退出後価格は計算しない。

人工確認だけは次で再現できる。小さいGo公開型Snapshotとmetadataを使用し、実Native/原板/CSV/streamを開かない。

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101連続入力の全54場/人工を確認する.py'
```
