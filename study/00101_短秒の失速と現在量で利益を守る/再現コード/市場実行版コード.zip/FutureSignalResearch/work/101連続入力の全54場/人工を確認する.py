"""許可集合・先行証拠と限定Endingの小さい人工だけを確認する。実市場本文は開かない。"""

import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def digest(path):
    """
    機能: 明示コード/metadata/公開人工の指紋を得る。
    引数: path(Path)は対象。
    返り値: strはSHA256。実NativeやRawへ呼ばない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def module():
    """
    機能: 今回のCLIをimportし、構文と固定依存を確認する。
    引数: なし。
    返り値: moduleは今回の実行器。main/runは呼ばない。
    """
    path = HERE / '生成と場末を照合する.py'
    ast.parse(path.read_text(encoding='utf-8'))
    spec = importlib.util.spec_from_file_location('全54Ending_人工', path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = value
    spec.loader.exec_module(value)
    return value


def main():
    """
    機能: 市場前guard・射影・全値比較を人工で確認し証拠を保存する。
    引数: なし。実市場データへアクセスするCLI引数を持たない。
    返り値: None。受理すべき差が出たら例外で停止する。
    """
    engine = module()
    public = ROOT / 'work/101X5純式/人工/公開型.json'
    assert digest(public) == '3e644241ba177976172f461720748f7cfccb73f4ccd9f5d698de48830a6787f6'
    paths = [public, engine.CORE_PATH, engine.SELECTOR_PATH, engine.CATALOG, engine.PROOF,
             engine.FIRST, engine.FIRST_ENDING, engine.BUILDER / '停止.json', engine.MATERIALIZE_PATH,
             ROOT / 'work/101連続入力の読取照合/実2場.json']
    before = {str(path.relative_to(ROOT)): digest(path) for path in paths}
    fixture = json.loads(public.read_text(encoding='utf-8'))
    sample = next(row for row in fixture['cases'] if not row['error'])
    chart = copy.deepcopy(sample['input']['chart'])
    chart['sealed'] = True
    expected = {'session': chart['scene']['id'], 'contract': chart['scene']['contract'], 'chart_end': chart}
    artificial = {**expected, 'books': {'policy': '禁止policy', 'closed': [{'純額': 123, 'peak': 999}]},
                  'shadows': {'Source': {'利益': 777}}, 'unused': [0, True, None]}
    text = json.dumps(artificial, ensure_ascii=False)
    parsed = []
    real_loads = engine.CORE.json.loads
    def allowed_loads(value, *args, **kwargs):
        """
        機能: 射影時に禁止subtreeがJSON展開されないことを監視する。
        引数: value(str)、args/kwargsは元decoderの引数。
        返り値: objectは元decoderの値。禁止markerが含まれれば例外。
        """
        assert all(word not in value for word in ('禁止policy', '純額', 'peak', '利益'))
        parsed.append(value)
        return real_loads(value, *args, **kwargs)
    engine.CORE.json.loads = allowed_loads
    try:
        actual = engine.project(text)
    finally:
        engine.CORE.json.loads = real_loads
    assert actual == expected and len(parsed) == 3
    engine.validate_ending(actual, chart['scene']['id'])
    leaves = engine.same(actual['chart_end'], chart, '人工Ending')
    payload_fields = ('scene', 'chart', 'three', 'fifteen', 'carried_numeric_seed')
    state_fields = ('at', 'has_observed_clock', 'observed_clock', 'has_last_input', 'last_input', 'invalidated_at', 'sealed')
    payload = {name: copy.deepcopy(chart[name]) for name in payload_fields}
    state = {name: copy.deepcopy(chart[name]) for name in state_fields}
    key = hashlib.sha256(json.dumps(payload, ensure_ascii=False).encode()).hexdigest()
    state['payload_sha256'] = key
    header = {'chart_payloads': {key: payload}}
    restored = engine.END.materialize(header, state)
    assert engine.same(restored, chart, '人工辞書復元') == leaves
    first, ending = engine.load(engine.FIRST), engine.load(engine.FIRST_ENDING)
    stop = engine.load(engine.BUILDER / '停止.json')
    engine.validate_first(first, ending, stop)
    readback_path = ROOT / 'work/101連続入力の読取照合/実2場.json'
    readback = engine.load(readback_path)
    readback_sha = digest(readback_path)
    assert readback_sha == 'fb5341772170b68444ff95c5a656bef2a7fcf57ed1cf4369b13b2988b616425a'
    first_index = engine.load(engine.INDEX.with_name('接続2場Tape台帳.json'))
    tapes = {row['session']: row['sha256'] for row in first_index['entries']}
    engine.validate_readback(readback, readback_sha, readback_sha, first, tapes)
    catalog = engine.load(engine.CATALOG)
    expected_catalog, _ = engine.SELECTOR.catalog(engine.PROOF)
    assert catalog == expected_catalog
    rows = engine.SELECTOR.choose(catalog, expected_catalog, 'full54')
    assert len(rows) == 54
    full_index = engine.load(engine.INDEX)
    assert [row['session'] for row in full_index['entries']] == [row['session'] for row in rows]
    sources = engine.delegated_sources(rows)
    assert len(sources) == 378
    full = {'成功': True, '前後不変': True, 'stage': 'full54',
            'scope': '固定100と旧Tapeの連続技法sidecar構築', 'sessions': [row['session'] for row in rows],
            '固定100完了SHA256': engine.PROOF_SHA, '所有コードSHA256': stop['所有コードSHA256'],
            'source_reexecuted': False, 'financial_executed': False,
            'details': [{'session': row['session']} for row in rows]}
    engine.validate_full_receipt(full, rows, stop)
    rejected = []
    def reject(name, fn):
        """
        機能: 狭い破損が成功化されないことを検査する。
        引数: name(str)、fn(callable)はラベルと破損確認。
        返り値: None。拒否されなければAssertionError。
        """
        try:
            fn()
        except (ValueError, KeyError, TypeError, AssertionError) as exc:
            rejected.append({'破損': name, '拒否': str(exc)})
        else:
            raise AssertionError('破損を受理: ' + name)
    reject('禁止root3field欠落', lambda: engine.project('{"books":{},"session":"人工"}'))
    reject('Endingに余剰field', lambda: engine.same({**chart, 'future': 0}, chart, '人工'))
    reject('boolを数値0へ置換', lambda: engine.same({**chart, 'sealed': 1}, chart, '人工'))
    changed = copy.deepcopy(chart); changed['chart']['Technical']['close3'] += 1
    reject('Endingの数値差', lambda: engine.same(changed, chart, '人工'))
    reject('Ending場の入替え', lambda: engine.validate_ending(expected, '別場'))
    reject('不足台帳53', lambda: engine.SELECTOR.choose({**catalog, 'entries': rows[:-1]}, catalog, 'full54'))
    reject('55場混入', lambda: engine.SELECTOR.choose({**catalog, 'entries': rows + [rows[0]]}, catalog, 'full54'))
    reject('重複と欠落を入替え', lambda: engine.SELECTOR.choose({**catalog, 'entries': rows[:-1] + [rows[0]]}, catalog, 'full54'))
    reject('未許可stage', lambda: engine.SELECTOR.choose(catalog, catalog, 'full66'))
    reject('first2未完', lambda: engine.validate_first({**first, '成功': False}, ending, stop))
    reject('first2別版', lambda: engine.validate_first({**first, '所有コードSHA256': {}}, ending, stop))
    reject('readback SHA未固定', lambda: engine.validate_readback(readback, '', '', first, tapes))
    reject('readback不成功', lambda: engine.validate_readback({**readback, '成功': False}, readback_sha, readback_sha, first, tapes))
    reject('readback別receipt', lambda: engine.validate_readback({**readback, '入力構築receiptSHA256': '0' * 64}, readback_sha, readback_sha, first, tapes))
    reject('readback1場だけ', lambda: engine.validate_readback({**readback, 'details': readback['details'][:1]}, readback_sha, readback_sha, first, tapes))
    broken_detail = copy.deepcopy(readback)
    broken_detail['details'][0]['入力SHA256'] = {str(ROOT / '人工'): '1' * 64}
    reject('readback入力出典不足', lambda: engine.validate_readback(broken_detail, readback_sha, readback_sha, first, tapes))
    reject('full54未完', lambda: engine.validate_full_receipt({**full, '前後不変': False}, rows, stop))
    reject('full54が53場', lambda: engine.validate_full_receipt({**full, 'details': full['details'][:-1]}, rows, stop))
    reject('full54で金融true', lambda: engine.validate_full_receipt({**full, 'financial_executed': True}, rows, stop))
    after = {str(path.relative_to(ROOT)): digest(path) for path in paths}
    assert before == after
    value = {'成功': True, '区分': '小型人工と実成功receiptのmetadataだけ',
             '正常項目': ['限定3fieldと禁止subtree非展開', 'Ending公開型品質', '全field比較', '辞書復元',
                         'first2同版/限定Ending', '実readback1771結合', '許可54全集合', '明示378入力metadata', '完全54receipt人工'],
             'Ending比較葉数': leaves, '破損拒否数': len(rejected), '破損拒否': rejected,
             '入力コードSHA256前後': before, '前後不変': True,
             'Native/Raw/CSV/stream市場本文読取': 0, 'Go/Source/金融実行': 0,
             '注記': 'first2/readbackは成功metadataだけを読取。新全54の本文/Source/金融を実行していない。'}
    (HERE / '人工確認.json').write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '正常': len(value['正常項目']), '拒否': len(rejected),
                      '市場本文読取': 0, '前後不変': True}, ensure_ascii=False))


if __name__ == '__main__':
    main()
