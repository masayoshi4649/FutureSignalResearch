"""101の全648資源を既存Viewerの保存会計へ結ぶ準備補助。"""

import argparse
import ast
import copy
from decimal import Decimal
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import re
import sys
import types
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parents[2]
OLD_PATH = ROOT / "scripts/FAR利益化前後の保護の監査/表示監査.py"
OLD_SHA = "cfa035dc0c6f01aa911373277ab1d1a37d3ccc3c90f0b84f4d980ec8d9946aee"
SAVED_STOP = ROOT / "work/101集計と閲覧資料/停止.json"
SAVED_STOP_SHA = "2d94387f2443e8c127eafde8716df1688a63d1760adae1278dd288957aa399d7"
FIXED_SCOPE = "101Viewer全648と保存実約定会計の一致だけを確認する実行前固定"
KEYS = tuple(prefix + f"E3S_B5Q_P0_C{cost}_D{delay}" for prefix in ("", "S5Q_", "S515Q_") for cost in (0, 5) for delay in (0, 1))


def digest(path: Path) -> str:
    """
    機能: 明示されたコード又は表示入力の指紋を得る。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fixed_module():
    """
    機能: 旧100の停止表示算術とAPI部品をSHA固定で再用する。
    引数: なし。
    返り値: moduleは読取/代替transport又は後日の既存API口。
    """
    if digest(OLD_PATH) != OLD_SHA:
        raise ValueError("固定100表示SHA差")
    spec = importlib.util.spec_from_file_location("固定100表示101", OLD_PATH)
    value = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = value
    spec.loader.exec_module(value)
    return value


OLD = fixed_module()
BASE, F96 = OLD.BASE, OLD.F96
need, decimal = OLD.need, OLD.decimal


def key_config(key: str) -> tuple:
    """
    機能: 101本名を空Risk/E3S/P0又はSと費用遅延へ分ける。
    引数: key(str)は許可12key。
    返り値: tupleはrisk,gate,exit,cost,delay。
    """
    need(key in KEYS, "101全12key")
    policy = "S515Q" if key.startswith("S515Q_") else "S5Q" if key.startswith("S5Q_") else "P0"
    return "", "E3S", policy, int(key.split("_")[-2][1:]), int(key.split("_")[-1][1:])


def require_pins(pins: dict) -> None:
    """
    機能: Rootの金融/独立/保存が未確定なら表示本文とHTTP前に拒否する。
    引数: pins(dict)はprepareが検査した固定指紋。
    返り値: None。
    """
    names = {"集計コードSHA256", "条件SHA256", "金融完了SHA256", "独立金融監査SHA256", "結果SHA256", "一覧SHA256", "固定100完了SHA256"}
    need(type(pins) is dict and set(pins) == names and all(type(value) is str and re.fullmatch("[0-9a-f]{64}", value) for value in pins.values()), "101Viewerの実成功SHA未固定")


def component_hashes() -> dict:
    """
    機能: 本補助と既存renderer/APIの指紋を列挙する。
    引数: なし。
    返り値: dictはコードpath→SHA。
    """
    return {**OLD.component_hashes(), str(OLD_PATH): OLD_SHA, str(Path(__file__).resolve()): digest(Path(__file__))}


def saved_header(result: dict, limit: int, pins: dict) -> None:
    """
    機能: 保存結果をRoot固定の金融/独立/旧100P0全文へ結ぶ。
    引数: result(dict)、limit(int)、pins(dict)は結果・54場・固定指紋。
    返り値: None。
    """
    require_pins(pins)
    need(limit == 54 and all(result[name] == pins[name] for name in ("集計コードSHA256", "条件SHA256", "金融完了SHA256", "独立金融監査SHA256")), "101結果の同条件結合")
    dependencies = result["入力依存SHA256前後"]
    need(type(dependencies) is dict and dependencies and set(pins[name] for name in ("集計コードSHA256", "条件SHA256", "金融完了SHA256", "独立金融監査SHA256", "固定100完了SHA256")) <= set(dependencies.values()), "101保存依存の結合不足")
    controls = result["P0旧100全文対照"]
    need(len(controls) == 54 and len({row["session"] for row in controls}) == 54
         and {row["session"] for row in controls} == OLD.scene_set(54)
         and all(row["対照会計"] == 4 and type(row["対照会計"]) is int and row["除外"] == []
                 and re.fullmatch("[0-9a-f]{64}", row["固定100保存SHA256"]) for row in controls), "101旧P0四全文の完全54")


def derived_local_source() -> str:
    """
    機能: 旧100local_inputsの識別3箇所だけを101へ機械対応する。
    引数: なし。
    返り値: strは同じ会計/全実約定/費用/所有算術の関数本文。
    """
    source = inspect.getsource(OLD.local_inputs)
    replacements = (( 'result["試行"] == 100', 'result["試行"] == 101'),
                    ('rid = "100_"', 'rid = "101_"'),
                    ('"利益化前後の保護 "', '"短秒の失速と現在量 "'))
    for original, new in replacements:
        need(source.count(original) == 1, "旧表示本文の識別箇所差")
        source = source.replace(original, new)
    ast.parse(source)
    return source


def local_inputs(catalog_path: Path, result_path: Path, limit: int = 54, artificial: bool = False, pins=None) -> dict:
    """
    機能: 旧100保存/約定/半円/純額検算本文へ101識別と固定headerを渡す。
    引数: catalog_path/result_path(Path)、limit(int)、artificial(bool)、pins(dict|None)は入力とscope。
    返り値: dictは既存API比較の期待値。金融engineは呼ばない。
    """
    if not artificial:
        require_pins(pins)
        need(digest(catalog_path) == pins["一覧SHA256"] and digest(result_path) == pins["結果SHA256"], "Root固定の一覧/結果SHA差")
    need(type(artificial) is bool, "人工bool型")
    namespace = {**vars(OLD), "KEYS": KEYS, "key_config": key_config, "component_hashes": component_hashes,
                 "require_fixed": lambda: require_pins(pins), "saved_header": lambda result, count: saved_header(result, count, pins)}
    exec(compile(derived_local_source(), str(Path(__file__).with_name("旧100識別対応")), "exec"), namespace)
    return namespace["local_inputs"](catalog_path, result_path, limit, artificial)


def run(catalog_path: Path, result_path: Path, pins=None, url: str = "http://127.0.0.1:8092", workers: int = 8,
        transport=None, progress: bool = True, limit: int = 54, artificial: bool = False) -> dict:
    """
    機能: 固定96のAPI全件照合本文を101保存入力へ渡す。
    引数: catalog_path/result_path(Path)、pins(dict|None)、url(str)、workers(int)、transport(callable|None)、progress/artificial(bool)、limit(int)。
    返り値: dictはViewer保存会計一致のみ。プロセス/設定は変更しない。
    """
    if not artificial:
        require_pins(pins)
    need(not artificial or transport is not None, "人工に実HTTPを使わない")

    def inputs(catalog, result, count, test):
        """
        機能: 固定rendererの当呼出へだけRoot pinを束縛する。
        引数: catalog/result(Path)、count(int)、test(bool)はrenderer引数。
        返り値: dictは保存検算した期待値。
        """
        return local_inputs(catalog, result, count, test, pins)

    namespace = {**vars(F96), "local_inputs": inputs, "KEYS": KEYS}
    runner = types.FunctionType(F96._run_fixed.__code__, namespace, argdefs=F96._run_fixed.__defaults__)
    result = runner(catalog_path, result_path, url, workers, transport, progress, limit, artificial)
    result.update({"試行": 101, "成功の範囲": "Viewer保存会計一致", "監査コードSHA256": digest(Path(__file__)),
                   "固定100表示SHA256": OLD_SHA, "全再用部品SHA256": component_hashes(), "保存約定の会計検算": True,
                   "S金融全経路の新検査": False, "実Source生成": 0})
    identities = {row["id"]: row["method_id"] for row in json.loads(catalog_path.read_text(encoding="utf-8"))["resources"]}
    for row in result["資源"]:
        key = identities[row["id"]]
        risk, gate, policy, cost, delay = key_config(key)
        row.update(Actor=key, EntryGate=gate, ExitPolicy=policy, HarvestPolicy="", InitialRiskPolicy=risk,
                   EntryTiming="B5Q", 費用基準="C" + str(cost), 約定遅延秒=delay)
    return result


def read_ref(base: Path, value: dict, before: dict) -> tuple:
    """
    機能: Root明示FileRefを一つの基準で解決し指紋を検査する。
    引数: base(Path)、value/before(dict)は固定基準・参照・前指紋。
    返り値: tupleは絶対PathとJSON値。
    """
    need(type(value) is dict and set(value) == {"path", "sha256"} and value["path"] and re.fullmatch("[0-9a-f]{64}", value["sha256"] or ""), "未固定FileRef")
    path = Path(value["path"])
    path = (path if path.is_absolute() else base / path).resolve()
    need(path.is_file() and digest(path) == value["sha256"], "固定FileRef差:" + str(path))
    before[str(path)] = value["sha256"]
    return path, json.loads(path.read_text(encoding="utf-8"))


def validate_fixed(value: dict) -> None:
    """
    機能: 未生成Root固定をHTTP/保存本文の読取前に拒否する。
    引数: value(dict)はRootが固定する表示実行JSON。
    返り値: None。
    """
    names = {"version", "試行", "scope", "固定", "stage", "condition", "financial", "independent", "saved", "result", "catalog", "saved_code"}
    need(set(value) == names and type(value["version"]) is int and value["version"] == 1 and type(value["試行"]) is int and value["試行"] == 101
         and value["scope"] == FIXED_SCOPE and value["固定"] is True and value["stage"] == "full54", "101Viewer実成功が未固定")
    for name in names - {"version", "試行", "scope", "固定", "stage"}:
        ref = value[name]
        need(type(ref) is dict and set(ref) == {"path", "sha256"} and type(ref["path"]) is str and bool(ref["path"])
             and re.fullmatch("[0-9a-f]{64}", ref["sha256"] or ""), "未確定Viewer入力:" + name)


def prepare(fixed_path: Path, fixed_sha: str) -> dict:
    """
    機能: Root固定のfull54金融/独立/保存/結果/全648をmetadataで結ぶ。
    引数: fixed_path(Path)、fixed_sha(str)は実行前固定の正本。
    返り値: dictはcatalog/result/pins/入力前指紋。Native/Tape/原板を開かない。
    """
    need(re.fullmatch("[0-9a-f]{64}", fixed_sha or ""), "表示固定SHA未指定")
    fixed_path = fixed_path.resolve()
    need(digest(fixed_path) == fixed_sha, "表示固定JSON SHA差")
    value = json.loads(fixed_path.read_text(encoding="utf-8"))
    validate_fixed(value)
    before = {str(fixed_path): fixed_sha}
    refs, bodies = {}, {}
    for name in ("condition", "financial", "independent", "saved", "result", "catalog"):
        refs[name], bodies[name] = read_ref(fixed_path.parent, value[name], before)
    code = value["saved_code"]
    code_path = Path(code["path"])
    code_path = (code_path if code_path.is_absolute() else fixed_path.parent / code_path).resolve()
    need(code_path.is_file() and digest(code_path) == code["sha256"], "保存コードSHA差")
    before[str(code_path)] = code["sha256"]
    condition, financial, audit, saved, result = (bodies[name] for name in ("condition", "financial", "independent", "saved", "result"))
    need(condition["試行"] == 101 and condition["市場損益を開く前の固定"] is True and condition["全12Key"] == list(KEYS), "101条件全12")
    condition_sha = value["condition"]["sha256"]
    need(financial["成功"] is True and financial["試行"] == 101 and financial["stage"] == "full54" and financial["条件SHA256"] == condition_sha
         and financial["全12Key"] == list(KEYS) and financial["前後不変"] is True and financial["入力前SHA256"] == financial["入力後SHA256"]
         and all(financial[name] is False for name in ("source_reexecuted", "features_recomputed", "charts_recomputed")) and financial["Raw読取"] == 0, "full54金融未完")
    scenes = financial["結果"]
    need(len(scenes) == len({row["session"] for row in scenes}) == 54 and all(row["books"] == 12 and row["p0_books"] == 4 for row in scenes), "金融54/12/P0四不足")
    ids = [row["session"] for row in scenes]
    need(ids == sorted(OLD.scene_set(54)), "旧100と同じ完全54場")
    need(audit["成功"] is True and audit["stage"] == "full54" and audit["sessions"] == ids and audit["条件SHA256"] == condition_sha
         and audit["金融完了SHA256"] == value["financial"]["sha256"] and audit["新会計数"] == 648
         and audit["新P0独立全文会計"] == audit["旧100P0独立全文会計"] == 216 and audit["不一致数"] == 0
         and audit["前後不変"] is True and audit["入力SHA256前"] == audit["入力SHA256後"]
         and audit["Source再形成"] is False and audit["特徴チャート再計算"] is False and audit["Raw読取"] == 0, "独立full54未完")
    need(saved["成功"] is True and saved["stage"] == "full54" and saved["場数"] == 54 and saved["会計数"] == 648 and saved["前後不変"] is True
         and saved["条件SHA256"] == condition_sha and saved["金融完了SHA256"] == value["financial"]["sha256"]
         and saved["独立金融監査SHA256"] == value["independent"]["sha256"] and saved["集計コードSHA256"] == code["sha256"]
         and saved["結果SHA256"] == value["result"]["sha256"], "保存full54未完/別条件")
    native_map = {row["session"]: row["sha256"] for row in scenes}
    need(len(saved["Native参照"]) == 54 and {row["session"]: row["native_sha256"] for row in saved["Native参照"]} == native_map, "保存と金融の全NativeSHA差")
    need([row["session"] for row in audit["details"]] == ids, "独立details完全54")
    audit_rows = {row["session"]: row for row in audit["details"]}
    for row in scenes:
        need(audit["入力SHA256前"].get(str(Path(row["path"]).resolve())) == row["sha256"], "独立と金融のNativeSHA差")
        detail = audit_rows[row["session"]]
        need(detail["成功"] is True and detail["前後不変"] is True and detail["新会計数"] == 12 and detail["P0除外"] == []
             and detail["入力SHA256"].get(str(Path(row["path"]).resolve())) == row["sha256"], "独立場のNative/全12差")
    need(result["試行"] == 101 and result["成功"] is True and result["scope"] == "正式" and result["場数"] == 54 and result["会計数"] == 648, "保存結果full54 scope")
    pins = {"集計コードSHA256": code["sha256"], "条件SHA256": condition_sha, "金融完了SHA256": value["financial"]["sha256"],
            "独立金融監査SHA256": value["independent"]["sha256"], "結果SHA256": value["result"]["sha256"],
            "一覧SHA256": value["catalog"]["sha256"], "固定100完了SHA256": "4a8bc486e329f65f17e2395f781b2efd7cf76c5630d91924b611e90254725af3"}
    saved_header(result, 54, pins)
    before.update(component_hashes())
    return dict(catalog=refs["catalog"], result=refs["result"], pins=pins, before=before)


def main() -> None:
    """
    機能: 準備人工又はRoot固定成功後だけViewer全648を検証する。
    引数: --self-test/--run、--fixed/--fixed-sha、--out、--workers、--urlは実行口。
    返り値: None。差/未完は非0。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--self-test", action="store_true")
    mode.add_argument("--run", action="store_true")
    parser.add_argument("--fixed", type=Path)
    parser.add_argument("--fixed-sha", default="")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--workers", type=int, choices=range(1, 9), default=8)
    parser.add_argument("--url", default="http://127.0.0.1:8092")
    args = parser.parse_args()
    need(not args.out.exists(), "新規Viewer証拠だけ")
    if args.self_test:
        need(args.fixed is None and not args.fixed_sha, "人工へ市場固定を渡さない")
        from 人工を確認する import self_test
        result = self_test(sys.modules[__name__])
    else:
        need(args.fixed is not None, "Root表示固定JSONを明示")
        prepared = prepare(args.fixed, args.fixed_sha)
        result = run(prepared["catalog"], prepared["result"], prepared["pins"], args.url, args.workers)
        need(all(digest(Path(path)) == sha for path, sha in prepared["before"].items()), "表示全入力前後差")
        result["Root固定SHA256"] = args.fixed_sha
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    if not result["成功"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
