"""停止保存24資源の代替APIと未固定拒否を確認し、実HTTPを行わない。"""

import copy
from decimal import Decimal
import hashlib
import json
from pathlib import Path
from urllib.parse import parse_qs, urlparse


def self_test(module) -> dict:
    """
    機能: 停止保存2鏡像24資源を固定API照合本文へ渡す。
    引数: module(module)は101表示補助。
    返り値: dictは正常/破損/入力前後の証拠。実HTTP0。
    """
    root = module.ROOT
    need = module.need
    need(module.digest(module.SAVED_STOP) == module.SAVED_STOP_SHA, "101保存人工停止SHA差")
    stopped = json.loads(module.SAVED_STOP.read_bytes())
    paths = [root / "work/101集計と閲覧資料/人工_停止版" / f"方向{side}" for side in (1, -1)]
    results, rejections, all_inputs = [], [], {str(module.SAVED_STOP): module.SAVED_STOP_SHA}
    half = partial = 0
    for ordinal, path in enumerate(paths):
        for file in path.iterdir():
            if file.is_file():
                relative = file.relative_to(module.SAVED_STOP.parent).as_posix()
                need(module.digest(file) == stopped["証拠と人工SHA256"][relative], "保存人工の全SHA差")
        catalog_path, result_path = path / "一覧.resources.json", path / "結果.json"
        local = module.local_inputs(catalog_path, result_path, limit=1, artificial=True)
        all_inputs.update(local["入力SHA256"])
        resolved = {resource["id"]: {**resource, "pnl_path": str(path / resource["pnl_path"]),
                     "market_path": str(path / "市場" / resource["market_path"])} for resource in local["resources"]}
        half += sum(module.decimal(row["fee_yen"]) % 1 != 0 for trades in local["trades"].values() for row in trades)
        for trades in local["trades"].values():
            closing = {}
            for trade in trades:
                if trade["type"].endswith("R"):
                    closing[trade["position_id"]] = closing.get(trade["position_id"], 0) + 1
            partial += sum(count > 1 for count in closing.values())

        def fake(method, url, payload=None):
            """
            機能: 停止約定から既存Viewerと同じ応答schemaだけを返す。
            引数: method/url(str)、payload(dict|None)は代替API引数。
            返り値: tupleはJSON/本文/応答SHA。ネットワークは使わない。
            """
            if url.endswith("/api/info"):
                value = {"resource_root": str(root / "work"), "data_root": str(path / "市場"), "listen": "127.0.0.1:8092"}
            elif url.endswith("/api/catalogs/load"):
                value = {"catalog_id": "人工101", "path": str(catalog_path), "resources": list(resolved.values())}
            else:
                identity = parse_qs(urlparse(url).query)["resource"][0]
                events = local["events"][identity]
                net = sum(row["realized_delta_yen"] for row in events)
                value = {"resource": resolved[identity], "summary": {"long_qty": 0, "short_qty": 0, "realized_pnl_yen": net, "unrealized_pnl_yen": 0},
                         "state_columns": ["long_qty", "short_qty", "realized_pnl_yen", "unrealized_pnl_yen"], "states": [[0, 0, net, 0]], "events": events,
                         "files": {"pnl": resolved[identity]["pnl_path"], "market": resolved[identity]["market_path"], "catalog": str(catalog_path)}}
            raw = json.dumps(value).encode()
            return value, raw, {"x-chart-data-sha256": hashlib.sha256(raw).hexdigest()}

        good = module.run(catalog_path, result_path, workers=2, transport=fake, progress=False, limit=1, artificial=True)
        need(good["成功"] and good["完了資源"] == 12 and good["不一致数"] == 0, "101正常12資源")
        need(all(row["HarvestPolicy"] == "" and row["ExitPolicy"] in ("P0", "S5Q", "S515Q") for row in good["資源"]), "SをHarvestへ偽装しない")
        results.append({"人工根": str(path), "成功": True, "資源": 12, "照合項目数": good["照合項目数"], "入力不変": good["入力不変"]})
        if ordinal:
            continue
        for corruption in ("半円", "枚数", "S本名", "所有", "本文SHA", "資源欠落", "通信未完"):

            def broken(method, url, payload=None):
                """
                機能: 代替Viewer応答の一項目だけを破損させる。
                引数: method/url(str)、payload(dict|None)は通信代替引数。
                返り値: tupleは破損JSON/本文/SHA。実API0。
                """
                if corruption == "通信未完" and "/api/data?" in url:
                    raise module.BASE.ViewerError("通信", url, "人工未完")
                value, _, _ = fake(method, url, payload)
                value = copy.deepcopy(value)
                if "/api/data?" in url:
                    if corruption == "半円" and value["events"]:
                        value["events"][0]["realized_delta_yen"] += .5
                    elif corruption == "枚数" and value["events"]:
                        value["events"][0]["qty"] += 1
                    elif corruption == "S本名":
                        value["resource"]["method_id"] = "HG_E3S_B5Q_P0_C0_D0"
                    elif corruption == "所有" and len(value["events"]) > 1:
                        value["events"][1]["position_id"] = "別所有"
                elif corruption == "資源欠落" and url.endswith("/api/catalogs/load"):
                    value["resources"].pop()
                raw = json.dumps(value).encode()
                return value, raw, {"x-chart-data-sha256": "破損" if corruption == "本文SHA" else hashlib.sha256(raw).hexdigest()}

            need(not module.run(catalog_path, result_path, workers=2, transport=broken, progress=False, limit=1, artificial=True)["成功"], "API破損を受理:" + corruption)
            rejections.append(corruption)
    # ----------------------------------------
    identity = next(iter(resolved))

    def empty_api(method, url, payload=None):
        """
        機能: API比較の0取引schemaだけを既存比較式へ渡す。
        引数: method/url(str)、payload(dict|None)は通信代替引数。
        返り値: tupleは空events/所有0/純額0。架空の金融成功を作らない。
        """
        value, _, _ = fake(method, url, payload)
        value = copy.deepcopy(value)
        if "/api/data?" in url:
            value["events"] = []
            value["summary"] = {"long_qty": 0, "short_qty": 0, "realized_pnl_yen": 0, "unrealized_pnl_yen": 0}
            value["states"] = [[0, 0, 0, 0]]
        raw = json.dumps(value).encode()
        return value, raw, {"x-chart-data-sha256": hashlib.sha256(raw).hexdigest()}

    empty_row = module.OLD.LEGACY.check_one(("http://127.0.0.1:8092/api/data?resource=" + identity, resolved[identity], [], 0, catalog_path), empty_api)
    need(empty_row["完了"] and empty_row["不一致数"] == 0, "空events/所有0/純額0のAPI型")
    need(half == 48 and partial == 24, "半円/partial coverage")
    try:
        module.run(Path("未読一覧"), Path("未読結果"))
    except ValueError as error:
        rejections.append("未固定の実run本文前拒否:" + str(error))
    else:
        raise AssertionError("未固定実runを受理")
    try:
        module.run(Path("未読一覧"), Path("未読結果"), artificial=True)
    except ValueError as error:
        rejections.append("人工HTTP拒否:" + str(error))
    else:
        raise AssertionError("人工で実HTTPへ進んだ")
    template = {"version": 1, "試行": 101, "scope": module.FIXED_SCOPE, "固定": False, "stage": "full54",
                **{name: {"path": "", "sha256": ""} for name in ("condition", "financial", "independent", "saved", "result", "catalog", "saved_code")}}
    try:
        module.validate_fixed(template)
    except ValueError:
        rejections.append("空固定雛形拒否")
    else:
        raise AssertionError("未生成Root固定を受理")
    need(all(module.digest(Path(path)) == sha for path, sha in all_inputs.items()), "人工/コード前後差")
    return {"成功": True, "試行": 101, "scope": "停止保存人工24資源の代替transportのみ", "正常資源": 24,
            "照合項目数": sum(row["照合項目数"] for row in results), "不一致数": 0, "人工根": results,
            "partial玉": partial, "半円片": half, "破損等拒否": rejections, "入力SHA256前後": all_inputs, "入力不変": True,
            "空API型_金融生成なし": True,
            "実HTTP_登録_設定_起動停止": 0, "原板_Tape_Native市場本文読取": 0,
            "限定": "買売2鏡像は同じ場IDの別人工。市場first2/full54成功、S市場効果、Source/全MTMの新証明ではない。"}
