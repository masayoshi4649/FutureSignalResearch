"""停止Viewer補助の不足コードだけを追加ZIPへ保存し、全entryを読み戻す。"""

import binascii
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
STOP = HERE / "停止.json"
STOP_SHA = "bb5af60ba0387968320f0ffb62cd66f8b08274d667e8f646f48773afdb74a54d"
BASE_ZIP = ROOT / "study/00101_短秒の失速と現在量で利益を守る/再現コード/市場実行版コード.zip"
BASE_SHA = "4b2bafe2bac89a0d158b4274d54963390ad98f387999262d2de21f437d4a6587"


def sha(data: bytes) -> str:
    """
    機能: 明示bytesのSHA256を得る。
    引数: data(bytes)はコード又はZIP/metadata。
    返り値: strはSHA256。
    """
    return hashlib.sha256(data).hexdigest()


def save_new(path: Path, value: dict) -> None:
    """
    機能: 既存証拠を上書きせず小型JSONを保存する。
    引数: path(Path)、value(dict)は新規先と証拠。
    返り値: None。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def main() -> None:
    """
    機能: 既存427コードの再用と追加コードを区別し全ZIP entryのSHA/CRCを検査する。
    引数: なし。Root指示の停止版と既存ZIPだけを対象にする。
    返り値: None。Source不一致/重複/禁止物は例外で停止する。
    """
    assert sha(STOP.read_bytes()) == STOP_SHA
    assert sha(BASE_ZIP.read_bytes()) == BASE_SHA
    stopped = json.loads(STOP.read_bytes())
    assert stopped["成功"] is True
    candidates = {ROOT / name: value for name, value in stopped["コードSHA256"].items()}
    candidates[STOP] = STOP_SHA
    candidates[Path(__file__).resolve()] = sha(Path(__file__).read_bytes())
    evidence = {"人工確認_停止版.json": stopped["人工確認SHA256"],
                "metadata人工.json": stopped["metadata人工SHA256"],
                "識別3箇所.patch": stopped["識別差分SHA256"]}
    candidates.update({HERE / name: value for name, value in evidence.items()})
    for name in ("CLI_help.log", "CLI_未固定拒否.log"):
        candidates[HERE / name] = sha((HERE / name).read_bytes())
    for name, value in stopped["再用部品SHA256"].items():
        path = Path(name).resolve()
        assert path.is_relative_to(ROOT)
        candidates[path] = value
    # self-testだけに必要な小型停止metadata。大きい保存人工は同梱しない。
    saved_stop = ROOT / "work/101集計と閲覧資料/停止.json"
    candidates[saved_stop] = stopped["固定保存人工停止SHA256"]
    before = {str(path): sha(path.read_bytes()) for path in candidates}
    assert all(before[str(path)] == expected for path, expected in candidates.items())
    additions, reused = {}, []
    with ZipFile(BASE_ZIP) as source:
        infos = source.infolist()
        assert len(infos) == len({row.filename for row in infos}) == 428
        assert len([row for row in infos if row.filename != "manifest.json"]) == 427
        base_rows = {}
        for info in infos:
            assert not info.is_dir()
            body = source.read(info.filename)
            assert len(body) == info.file_size and binascii.crc32(body) & 0xffffffff == info.CRC
            base_rows[info.filename] = {"SHA256": sha(body), "CRC32": f"{info.CRC:08x}", "bytes": len(body)}
        for path, expected in sorted(candidates.items(), key=lambda row: row[0].as_posix()):
            relative = path.relative_to(ROOT).as_posix()
            assert ".." not in Path(relative).parts
            existing = "FutureSignalResearch/" + relative
            if existing in base_rows:
                assert base_rows[existing]["SHA256"] == expected
                reused.append({"repo相対path": relative, "既存entry": existing, **base_rows[existing]})
                continue
            body = path.read_bytes()
            assert path.suffix in (".py", ".md", ".json", ".log", ".patch") and len(body) < 1_000_000
            assert not any(part in ("venv", "venvs", ".venv", "__pycache__", "node_modules") for part in path.parts)
            additions[relative] = body
    manifest_path = HERE / "Viewer追加コード.manifest.json"
    manifest = {"version": 1, "scope": "停止bb5af60bのViewer補助と不足コードのみ。市場/入力本文の保存なし",
                "Viewer停止SHA256": STOP_SHA, "既存ZIP": {"path": BASE_ZIP.relative_to(ROOT).as_posix(), "SHA256": BASE_SHA, "コードentry": 427, "manifest込みentry": 428},
                "追加entry": {name: {"SHA256": sha(body), "CRC32": f"{binascii.crc32(body) & 0xffffffff:08x}", "bytes": len(body)} for name, body in additions.items()},
                "既存entry再用": reused, "既存全entry読戻し": {"数": len(base_rows), "SHA_CRC一覧のSHA256": sha(json.dumps(base_rows, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()), "全CRC一致": True},
                "復元": "本追加ZIPはFutureSignalResearch repo rootへ展開する。既存ZIPは元manifestのFutureSignalResearch/とSessionTradeExecuter/配置を維持する。",
                "別参照": ["work/101集計と閲覧資料/人工_停止版の24資源本文は非同梱。元停止2d94387fの別入力が必要", "実市場の条件/金融完了/独立/保存結果/catalog/tradesはRoot実成功後に別途指紋で渡す"],
                "除外": ["原板", "Tape", "Native", "exe", "venv", "巨大人工本文", "初回の重複人工証拠"],
                "未実施": {"実HTTP_登録_設定_起動停止": 0, "正式ファイル変更": 0, "既存ZIP変更": 0, "新市場再生": 0}}
    save_new(manifest_path, manifest)
    additions[manifest_path.relative_to(ROOT).as_posix()] = manifest_path.read_bytes()
    output = HERE / "Viewer追加コード.zip"
    with ZipFile(output, "x", compression=ZIP_DEFLATED, compresslevel=9) as target:
        for name, body in sorted(additions.items()):
            info = ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            target.writestr(info, body, compress_type=ZIP_DEFLATED, compresslevel=9)
    checked = {}
    with ZipFile(output) as target:
        assert set(target.namelist()) == set(additions) and len(target.namelist()) == len(additions)
        for info in target.infolist():
            body = target.read(info.filename)
            assert body == additions[info.filename]
            assert binascii.crc32(body) & 0xffffffff == info.CRC
            checked[info.filename] = {"SHA256": sha(body), "CRC32": f"{info.CRC:08x}", "bytes": len(body)}
    after = {path: sha(Path(path).read_bytes()) for path in before}
    assert before == after and sha(STOP.read_bytes()) == STOP_SHA and sha(BASE_ZIP.read_bytes()) == BASE_SHA
    receipt = {"成功": True, "scope": "Viewer追加コードの保存と全entry読戻しだけ。市場/実APIの成功追加なし",
               "停止SHA256": STOP_SHA, "追加ZIP": {"path": output.relative_to(ROOT).as_posix(), "SHA256": sha(output.read_bytes()), "entry数": len(checked), "bytes": output.stat().st_size},
               "manifestSHA256": sha(manifest_path.read_bytes()), "全entrySHA_CRC": checked, "全entry読戻しSHA_CRC一致": True,
               "既存再用数": len(reused), "既存全428entryCRC一致": True, "既存ZIP前後SHA256": BASE_SHA,
               "入力SHA256前": before, "入力SHA256後": after, "前後不変": True,
               "実HTTP_登録_設定_起動停止": 0, "原板_Tape_Native本文読取": 0, "正式ファイル変更": 0,
               "非同梱入力を成功補完": False, "既存ZIP変更": False}
    receipt_path = HERE / "Viewer追加コードの保存確認.json"
    save_new(receipt_path, receipt)
    print(json.dumps({"成功": True, "ZIP_SHA256": sha(output.read_bytes()), "entry": len(checked), "既存再用": len(reused), "保存確認SHA256": sha(receipt_path.read_bytes())}, ensure_ascii=False))


if __name__ == "__main__":
    main()
