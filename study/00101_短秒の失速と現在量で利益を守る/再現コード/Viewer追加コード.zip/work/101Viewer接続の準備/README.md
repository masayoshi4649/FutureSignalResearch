# 101Viewer接続の準備

市場の表示監査は未実行。新補助はこのworkだけに置き、正式101の既存zip・金融・保存器・固定236/後段5を変更しない。正式先の候補は` scripts/短秒複合退出の監査/表示監査.py `で、配置はRootの別工程とする。

旧100表示`cfa035dc…`の保存/全約定/費用/所有検算と、固定96以下のAPI比較本文を再用する。旧100の`local_inputs`は試行番号・資源ID・titleの3識別だけを機械対応し、逆置換で全文同体を確認する。点価100円、38.5円片道、C0/C5、半円、partial、所有上限・最終0、Viewer純額の計算本文は変えない。SをHarvestPolicyへ置換せず、P0/S5Q/S515QをExitPolicy本名へ残す。

IDは`101_key_session`、titleは`短秒の失速と現在量 key session`、12key×54場=648資源。成功scopeは**Viewer保存会計一致**。全実Fill、費用後純額と所有0をAPIへ結ぶもので、Source生成、全MTM DD、mini実板執行、S利益改善を新しく証明しない。

## 今回の人工

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101Viewer接続の準備/表示監査.py' --self-test `
  --out '未使用の人工証拠.json'
```

停止保存2d94387fの`人工_停止版/方向±1`を読む。2鏡像は同じDay名の別ケースであり、一つのcatalogや実first2へ合算しない。各12、計24資源、partial24玉、半円48片、1,178項目差0を代替transportで確認した。半円・枚数・S名・所有・応答SHA・資源欠落・通信未完の7応答破損を拒否し、未固定実run、人工で実HTTPへ進む口、空固定も拒否する。空events/所有0/純額0のAPI型も確認するが、架空の空金融成功は補わない。

実HTTP、catalog登録、Viewer設定・起動・停止、Raw/Tape/市場Native本文読取は0。既存8092/PID19844を操作していない。

## 将来Rootが許可した全648実行

```powershell
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/101Viewer接続の準備/表示監査.py' --run `
  --fixed 'Rootが固定したViewer実行条件.json' --fixed-sha 'その実SHA256' `
  --out '新規のViewer照合.json' --workers 8 --url 'http://127.0.0.1:8092'
```

実行固定JSONは`version=1,試行=101,scope='101Viewer全648と保存実約定会計の一致だけを確認する実行前固定',固定=true,stage='full54'`と、`condition/financial/independent/saved/result/catalog/saved_code`の7FileRef `{path,sha256}`。FileRefの相対pathは固定JSONのdir基準。金融/独立/保存成功が揃ってからRootが実SHAを入力し、その固定JSONのSHAをCLIへ与える。雛形は`固定=false`、空path/SHAなのでHTTP・結果本文へ進む前に拒否する。

金融full54/12/P0四、独立648/P0新旧216、保存54/648とNative54指紋、同条件SHA、保存結果/一覧/コードSHA、全入力前後不変をmetadataで結ぶ。未確定値を0や成功へ補わない。全NativeのSHAはmetadata対応だけを確認し、Viewer補助からNativeや原板本文を再読しない。

guard成功後にだけ旧rendererのGET info→catalog読込→data width1/rawの数値照合を使う。新しいサーバーを起動・停止・再設定する処理は持たない。今はこの実行を許可又は実施したものではない。
