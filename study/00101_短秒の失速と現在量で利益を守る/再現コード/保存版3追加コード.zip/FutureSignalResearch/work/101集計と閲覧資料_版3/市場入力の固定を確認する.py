"""停止市場独立器のprepareを再用し、独立成功と保存入力の同一性を確認する。"""

import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import types

ROOT = Path(__file__).resolve().parents[2]
MARKET_PATH = ROOT / "work/短秒複合退出の市場の独立確認_版2/市場と短秒を照合する.py"
MARKET_SHA = "e343746dfcdac03695b16e9a4c60f3f14a65c18e1beb35dafe601d8577ed2855"
AUDIT_STOP = ROOT / "work/短秒複合退出の市場の独立確認_版2/停止.json"
AUDIT_STOP_SHA = "077eac32aed7d4a9d0031f1178c31151f72ee1a5370db966b233b81ccf823167"
FIXED_SCOPE = "101保存集計を同条件の金融と独立成功へ結ぶ実行前固定"


def need(value, message: str) -> None:
    """
    機能: metadataの不正を例外として停止する。
    引数: value(bool)、message(str)は条件と理由。
    返り値: None。
    """
    if not value:
        raise ValueError(message)


def digest(path: Path) -> str:
    """
    機能: 明示metadata又は検査済み入力のSHAを得る。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def market_module():
    """
    機能: 停止市場独立器のmetadata APIだけを再用する。
    引数: なし。
    返り値: moduleはprepare/validate_nativeを持つ。金融のinspectは呼ばない。
    """
    need(digest(MARKET_PATH) == MARKET_SHA and digest(AUDIT_STOP) == AUDIT_STOP_SHA, "独立metadata器停止SHA差")
    spec = importlib.util.spec_from_file_location("101保存の停止市場metadata", MARKET_PATH)
    value = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = value
    spec.loader.exec_module(value)
    return value


def validate_fixed(value: dict, stage: str) -> None:
    """
    機能: 空の準備雛形や未固定を市場metadataの読取前に拒否する。
    引数: value(dict)、stage(str)はRoot固定宣言と要求段階。
    返り値: None。
    """
    need(set(value) == {"version", "試行", "scope", "固定", "stage", "condition", "run", "completion_sha256", "audit", "first2_audit"}, "保存固定全tag")
    need(type(value["version"]) is int and value["version"] == 1 and type(value["試行"]) is int and value["試行"] == 101
         and value["固定"] is True and value["scope"] == FIXED_SCOPE and value["stage"] == stage
         and stage in ("first2", "full54"), "未固定の保存宣言")
    need(type(value["run"]) is str and bool(value["run"]) and re.fullmatch("[0-9a-f]{64}", value["completion_sha256"] or "") is not None, "未確定金融完了")
    for name in ("condition", "audit") + (("first2_audit",) if stage == "full54" else ()):
        ref = value[name]
        need(type(ref) is dict and set(ref) == {"path", "sha256"} and type(ref["path"]) is str and bool(ref["path"])
             and re.fullmatch("[0-9a-f]{64}", ref["sha256"] or "") is not None, "未確定保存FileRef:" + name)
    if stage == "first2":
        need(value["first2_audit"] is None, "first2へ他段階証拠を混入しない")


def validate_audit(value: dict, plan: dict, stage: str, condition_sha: str, completion_sha: str, audit_scope: str) -> None:
    """
    機能: 同条件・同Native・完全場集合の独立成功だけを保存へ結ぶ。
    引数: value/plan(dict)、stage/condition_sha/completion_sha/audit_scope(str)は証拠と既検査metadata。
    返り値: None。保存額を期待金融へ戻さない。
    """
    scenes = plan["scenes"]
    ids = [row["session"] for row in scenes]
    count = 2 if stage == "first2" else 54
    need(len(ids) == count and len(set(ids)) == count, "完全保存stage集合")
    need(value["成功"] is True and value["scope"] == audit_scope and value["stage"] == stage and value["sessions"] == ids
         and value["条件SHA256"] == condition_sha and value["金融完了SHA256"] == completion_sha
         and value["監査コードSHA256"] == plan["own"] and value["新会計数"] == count * 12
         and value["新P0独立全文会計"] == count * 4 and value["旧100P0独立全文会計"] == count * 4
         and type(value["不一致数"]) is int and value["不一致数"] == 0 and value["前後不変"] is True
         and value["入力SHA256前"] == value["入力SHA256後"] and bool(value["入力SHA256前"])
         and value["Source再形成"] is False and value["特徴チャート再計算"] is False
         and type(value["Raw読取"]) is int and value["Raw読取"] == 0 and value["機会損失算出"] is False,
         "独立成功の条件/全集合/再生成scope差")
    need([row["session"] for row in value["details"]] == ids, "独立details完全順序")
    for scene, detail in zip(scenes, value["details"]):
        need(detail["成功"] is True and detail["前後不変"] is True and detail["新会計数"] == 12
             and detail["新P0独立全文会計"] == 4 and detail["旧100P0独立全文会計"] == 4
             and detail["不一致数"] == 0 and detail["P0除外"] == [], "独立場12/P0四全文未完")
        expected = {scene[name]["path"]: scene[name]["sha256"] for name in ("native", "old", "tape", "header", "records")}
        need(detail["入力SHA256"] == expected and all(value["入力SHA256前"].get(path) == sha for path, sha in expected.items()), "独立と保存の全5入力SHA差")
        readback = detail["保存record読戻し"]
        need(readback["処理完了"] is True and readback["不一致"] == 0 and readback["session"] == scene["session"], "独立record読戻し未完")


def prepare(fixed_path: Path, fixed_sha: str, stage: str, output: Path) -> tuple:
    """
    機能: Root固定宣言→旧metadata prepare→独立成功の順で本文入力を許可する。
    引数: fixed_path/output(Path)、fixed_sha/stage(str)はRoot固定JSON/SHA/段階/新規先。
    返り値: tupleはtasks、前指紋、結果へ保存する結合証拠。
    """
    need(re.fullmatch("[0-9a-f]{64}", fixed_sha or "") is not None, "保存固定SHA未指定")
    fixed_path = fixed_path.resolve()
    need(digest(fixed_path) == fixed_sha, "保存固定JSONのSHA差")
    value = json.loads(fixed_path.read_text(encoding="utf-8"))
    validate_fixed(value, stage)
    need(not output.exists(), "保存先は新規dirのみ")
    market = market_module()
    before = {str(fixed_path): fixed_sha}
    condition = market.ref(fixed_path.parent, value["condition"], before)
    audit = market.ref(fixed_path.parent, value["audit"], before)
    run = market.absolute(fixed_path.parent, value["run"])
    first2 = None if stage == "first2" else market.ref(fixed_path.parent, value["first2_audit"], before)
    args = types.SimpleNamespace(condition=condition["path"], condition_sha=condition["sha256"], run=str(run),
            completion_sha=value["completion_sha256"], audit_stop=str(AUDIT_STOP), audit_stop_sha=AUDIT_STOP_SHA,
            stage=stage, first2_audit="" if first2 is None else first2["path"], first2_audit_sha="" if first2 is None else first2["sha256"])
    plan = market.prepare(args)
    independent = market.load(audit["path"])
    validate_audit(independent, plan, stage, condition["sha256"], value["completion_sha256"], market.AUDIT_SCOPE)
    before.update(plan["before"])
    for path, sha in independent["入力SHA256前"].items():
        market.ref(ROOT, dict(path=path, sha256=sha), before)
    own_files = sorted(Path(__file__).parent.glob("*.py")) + [Path(__file__).parent / "README.md", Path(__file__).parent / "計画.md"]
    for path in own_files + [MARKET_PATH, AUDIT_STOP]:
        before[str(path.resolve())] = digest(path)
    tasks = [dict(session=scene["session"], native=scene["native"]["path"], native_sha256=scene["native"]["sha256"],
                  header=scene["header"]["path"], native100=scene["old"]["path"], metadata=scene) for scene in plan["scenes"]]
    proof = {"保存実行固定SHA256": fixed_sha, "条件SHA256": condition["sha256"], "金融完了SHA256": value["completion_sha256"],
             "独立金融監査SHA256": audit["sha256"], "独立metadataコードSHA256": MARKET_SHA,
             "集計コードSHA256": digest(Path(__file__).parent / "集計.py"),
             "P0旧100全文対照": [dict(session=scene["session"], 対照会計=4, 除外=[], 固定100保存SHA256=scene["old"]["sha256"]) for scene in plan["scenes"]]}
    return tasks, before, proof
