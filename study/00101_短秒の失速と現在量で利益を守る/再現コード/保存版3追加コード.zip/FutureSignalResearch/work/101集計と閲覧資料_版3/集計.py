"""101の保存会計を検算し実現集計・Viewer約定・短い結果MDへ変換する。"""

import argparse
from collections import Counter, defaultdict
import copy
from decimal import Decimal
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import types

ROOT = Path(__file__).resolve().parents[2]
OLD_PATH = ROOT / "scripts/FAR利益化前後の保護の監査/集計.py"
OLD_SHA = "4175cf4557b8ed4093893fa87d04c31bb9520e6c887dce609be8dddd44228222"
COUPLED_PATH = ROOT / "work/短秒複合退出の再生の独立確認/再生と短秒を照合する.py"
COUPLED_SHA = "668a164c2558fc6c13cc3c304f9bf99d4ee93de32b0e04a29c67d135e59c0815"
WRAPPER_PATH = ROOT / "work/短秒複合退出の市場接続/停止.json"
WRAPPER_SHA = "2657346bc6a2bf0f759c5275de15ef52db49da752979fd3ccac0890b90e96767"
PROOF100 = ROOT / "study/00100_費用後利益化の前後で保護を分ける/完了記録.json"
PROOF100_SHA = "4a8bc486e329f65f17e2395f781b2efd7cf76c5630d91924b611e90254725af3"
SCOPE = "101保存点会計・実現集計・Viewer変換。金融の全経路は独立成功証拠へ結合"


def digest(path: Path) -> str:
    """
    機能: 明示ファイルのSHA256を得る。
    引数: path(Path)は固定コード又は許可入力。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fixed(name: str, path: Path, expected: str):
    """
    機能: 停止した保存算術又は独立純式部品をSHA固定でimportする。
    引数: name/expected(str)、path(Path)は識別名・指紋・対象。
    返り値: moduleは金融再生を実行しない読取部品。
    """
    if digest(path) != expected:
        raise ValueError("固定部品SHA差: " + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


OLD = fixed("固定100保存算術101", OLD_PATH, OLD_SHA)
COUPLED = fixed("固定S独立の保存接続101", COUPLED_PATH, COUPLED_SHA)
BASE, BIRTH, GRID, DIAG = OLD.BASE, OLD.BIRTH, OLD.GRID, OLD.DIAG
need, equal, number, integer = OLD.need, OLD.equal, OLD.number, OLD.integer
KEYS = COUPLED.KEYS
P0_KEYS = KEYS[:4]
POSITION_FIELDS = OLD.POSITION_FIELDS
ORDER_FIELDS = OLD.ORDER_FIELDS
FILL_FIELDS = OLD.FILL_FIELDS
SHORT_COUNTERS = {"short_exit_requests", "short_exit_fills"}
ZERO = Decimal(0)


def exit_policy(key: str) -> str:
    """
    機能: 本名12keyからP0/S5Q/S515Qを識別する。
    引数: key(str)は金融key。
    返り値: strは出口名。
    """
    need(key in KEYS, "101全12Key")
    return "S515Q" if key.startswith("S515Q_") else "S5Q" if key.startswith("S5Q_") else "P0"


def key_config(key: str) -> tuple:
    """
    機能: 本名を保持して旧共通算術の費用・遅延へ対応する。
    引数: key(str)は101key。
    返り値: tupleはgate,risk空,key,旧95,旧94,cost,delay。
    """
    exit_policy(key)
    tail = key.split("_")
    cost, delay = int(tail[-2][1:]), int(tail[-1][1:])
    common = f"P0_C{cost}_D{delay}"
    return "E3S", "", key, "B5Q_" + common, common, cost, delay


def grid_config(key: str) -> tuple:
    """
    機能: 政策非限定の旧出生枠検算へ対応する。
    引数: key(str)は原101key。
    返り値: tupleはgate,旧95,旧94,cost,delay。
    """
    gate, _, _, old95, old94, cost, delay = key_config(key)
    return gate, old95, old94, cost, delay


def accepted_at(book: dict, at, quote) -> set:
    """
    機能: 旧B5Qの当枠容量算術だけを本名12keyへ再用する。
    引数: book(dict)、at(number)、quote(dict|None)は実保存と枠。
    返り値: setは実受理した原注文ID。
    """
    return BIRTH.accepted_entries_at_grid(dict(book, key=key_config(book["key"])[3]), at, quote)


class SavedGates:
    """全当時E3S候補を固定純式へ接続する保存索引。"""

    def __init__(self, value: dict):
        """
        機能: Headerの公開全枠と保存5tagから固定独立入口を作る。
        引数: value(dict)はbooks/chart_grids/gate_assessments。
        返り値: None。保存採否を期待値にしない。
        """
        self.audit = COUPLED.Audit()
        contexts = OLD.OLD.pure_values(value["chart_grids"])
        records = OLD.OLD.pure_values(value["gate_assessments"])
        self.core = COUPLED.Entries(contexts, value["books"], records, self.audit, KEYS)
        self.by_at = {row["at"]: row for row in contexts}
        equal(len(self.by_at), len(contexts), "共有枠一意")
        rank = {key: i for i, key in enumerate(KEYS)}
        order = [(row["candidate"]["at"], rank[row["key"]], row["ordinal"]) for row in records]
        equal(order, sorted(order), "入口判定の時計/12key/ordinal順")

    def claim(self, key: str, candidate: dict) -> dict:
        """
        機能: 保存金融から独立に得た当候補を現在E3Sへ渡す。
        引数: key(str)、candidate(dict)は本名と前資格通過候補。
        返り値: dictは固定純式Decision。
        """
        need(candidate["evaluated_at"] in self.by_at, "当枠Context")
        self.core.current = self.by_at[candidate["evaluated_at"]]
        return self.core.claim(key, OLD.OLD.pure_values(candidate))

    def finish(self, clocks: list) -> dict:
        """
        機能: 全保存入口callbackと全枠の集合を閉じる。
        引数: clocks(list)は同12口座の全枠。
        返り値: dictは検査件数。
        """
        equal(self.core.used, set(self.core.records), "全E3S callback集合")
        equal([row["at"] for row in self.core.grids.values()], clocks, "全共有枠時計")
        return {"共有枠": len(clocks), "適格出生判定": len(self.core.used), "口座別": dict(self.core.calls)}


def order_classes(book: dict) -> dict:
    """
    機能: 実注文/実fillをSource/P0/Sへ排他的に数える。
    引数: book(dict)は原101口座。
    返り値: dictは常に3原因の要求/約定回数枚数。
    """
    rows = {name: {"要求回数": 0, "要求枚数": 0, "約定回数": 0, "約定枚数": 0} for name in ("Source", "P0", "S")}
    orders = {row["id"]: row for row in book["orders"]}
    equal(len(orders), len(book["orders"]), "注文ID一意")
    for order in orders.values():
        if order["kind"] != "exit":
            continue
        need(not ("short_exit_point" in order and order["protection_point"] is not None), "S/P0 point混在")
        cause = "S" if "short_exit_point" in order else "P0" if order["protection_point"] is not None else "Source"
        rows[cause]["要求回数"] += 1
        rows[cause]["要求枚数"] += order["quantity"]
    for fill in book["fills"]:
        if fill["action"] != "close":
            continue
        order = orders[fill["order_id"]]
        cause = "S" if "short_exit_point" in order else "P0" if order["protection_point"] is not None else "Source"
        rows[cause]["約定回数"] += 1
        rows[cause]["約定枚数"] += fill["quantity"]
    return rows


def saved_point(candidate: dict, position: dict, timeline) -> dict:
    """
    機能: S要求点の当時Fillと候補から旧Timeline型の私有検算点を作る。
    引数: candidate/position(dict)、timeline(Timeline)は原候補/玉/実Fill履歴。
    返り値: dictはSource後自己予約の算術点。原Nativeへは保存しない。
    """
    quote = candidate["quote"]
    state = timeline.state_at(position["id"], {"quote": quote, "phase": "after_source"})
    need(state is not None, "S非保有点")
    mark = quote["bid" if position["side"] == 1 else "ask"]
    gain = position["side"] * (mark - position["entry_price"])
    unit = gain * BASE.POINT - 2 * (BASE.FEE + timeline.slip)
    return {"quote": quote, "phase": "after_source", "quantity": candidate["quantity"], "reserved": candidate["reserved"],
            "mark_price": mark, "gain_points": gain, "unit_net": unit,
            "realized_net": state["realized"], "whole_net": state["realized"] + state["quantity"] * unit}


def verify_assessment(candidate: dict, assessment: dict) -> None:
    """
    機能: S保存判断の全tag・符号・三値と候補出典を検算する。
    引数: candidate/assessment(dict)は原S公開記録。
    返り値: None。元Features形成や全評価義務の証明は独立全経路へ分担する。
    """
    equal(set(assessment), {"decision", "checks", "evidence"}, "S判断全tag")
    decision, evidence = assessment["decision"], assessment["evidence"]
    equal(set(decision), {"policy", "snapshot_id", "at", "side", "known", "allowed", "role", "reason"}, "S Decision全tag")
    for name in ("policy", "snapshot_id", "at", "side"):
        equal(decision[name], candidate[name], "S候補と判断:" + name)
    need(type(decision["known"]) is bool and type(decision["allowed"]) is bool, "S判断bool型")
    equal(set(evidence), {"scene_id", "contract", "current", "price_age", "short_time", "short_mid", "five", "fifteen", "quantity", "signed_quantity"}, "S evidence全tag")
    equal(evidence["scene_id"], candidate["session_id"], "S evidence場")
    equal(evidence["contract"], candidate["contract"], "S evidence限月")
    current = evidence["current"]
    equal(set(current), {"reference", "time", "received", "source_index", "source_line", "last", "bid", "ask"}, "S current全tag")
    expected_current = dict(reference="NK225", received=candidate["quote_received"], source_index=candidate["quote"]["index"],
                            source_line=candidate["quote"]["source_line"], **{name: candidate["quote"][name] for name in ("time", "last", "bid", "ask")})
    equal(current, expected_current, "S保存Currentと同原行候補")
    equal(evidence["price_age"], candidate["at"] - current["time"], "S価格age")
    need(0 <= evidence["price_age"] <= 15 and 0 < current["bid"] < current["ask"] and current["last"] > 0, "S正常現在価格")
    for label, width in (("five", 5), ("fifteen", 15)):
        row = evidence[label]
        equal(set(row), {"known", "window", "signed_speed"}, "S窓根拠全tag")
        window = row["window"]
        equal(set(window), {"known", "move", "speed", "elapsed", "endpoint", "delay", "reason"}, "元窓全tag")
        need(type(row["known"]) is bool and type(window["known"]) is bool, "S窓既知型")
        equal(row["known"], window["known"], "正常Currentでの窓既知性")
        if row["known"]:
            equal(evidence["short_time"], current["time"], "S窓Time")
            equal(evidence["short_mid"], current["bid"] + (current["ask"] - current["bid"]) / 2, "S窓mid")
            equal(window["elapsed"], current["time"] - window["endpoint"], "S窓実経過")
            need(window["elapsed"] >= width and 0 <= window["delay"] <= 15, "S窓幅と遅れ")
            equal(window["delay"], window["elapsed"] - width, "S窓delay")
            need(abs(Decimal(window["speed"]) - Decimal(window["move"]) / Decimal(window["elapsed"])) <= Decimal("1e-12") * max(1, abs(window["speed"])), "S窓単位")
            equal(row["signed_speed"], candidate["side"] * window["speed"], "S速度符号")
        else:
            equal(row["signed_speed"], None, "未知速度を0補完しない")
    quantity = evidence["quantity"]
    equal(set(quantity), {"kind", "known", "time", "index", "own_at", "value", "bid_refill", "ask_refill", "bid_deplete", "ask_deplete"}, "S量全tag")
    equal(quantity["kind"], candidate["kind"], "S量の場種")
    need(type(quantity["known"]) is bool, "S量Known型")
    if quantity["known"]:
        equal((quantity["time"], quantity["index"]), (current["time"], current["source_index"]), "S量時計/FeaturesIndex")
        if quantity["kind"] == "Day":
            equal(quantity["own_at"], current["time"], "Day OFI自身時計")
        else:
            equal(quantity["value"], Decimal(str(float(quantity["bid_refill"]) + float(quantity["ask_deplete"]) - float(quantity["ask_refill"]) - float(quantity["bid_deplete"]))), "Night四量差・元の倍精度順序")
        equal(evidence["signed_quantity"], candidate["side"] * quantity["value"], "S量符号")
    else:
        equal((quantity["value"], evidence["signed_quantity"]), (None, None), "未知量を0補完しない")
    expected = [("S.現在価格時計", True, True), ("S.5秒速度", evidence["five"]["known"], evidence["five"]["known"] and evidence["five"]["signed_speed"] < 0)]
    if candidate["policy"] == "S515Q":
        expected.append(("S.15秒速度", evidence["fifteen"]["known"], evidence["fifteen"]["known"] and evidence["fifteen"]["signed_speed"] < 0))
    expected.append(("S.現在量", quantity["known"], quantity["known"] and evidence["signed_quantity"] < 0))
    equal(len(assessment["checks"]), len(expected), "S必要check数")
    for row, (name, known, passed) in zip(assessment["checks"], expected):
        equal(set(row), {"id", "known", "passed", "reason"}, "S check全tag")
        need(type(row["known"]) is bool and type(row["passed"]) is bool, "S check bool型")
        equal((row["id"], row["known"], row["passed"]), (name, known, passed), "S保存check三値")
        need(type(row["reason"]) is str and row["reason"], "S理由型")
    denied = any(known and not passed for _, known, passed in expected)
    all_known = all(known for _, known, _ in expected)
    equal((decision["known"], decision["allowed"]), (denied or all_known, all_known and not denied), "S既知否定優先AND")


def verify_short(book: dict, checked: dict, timeline, contract: str) -> dict:
    """
    機能: S専用trace全行と注文pointを保有/予約/起動/当時判断へ結ぶ。
    引数: book/checked(dict)、timeline(Timeline)、contract(str)は原保存/検算/外部期待限月。
    返り値: dictは保存対象/成立/未知等の件数。欠落全原行の検出は独立監査へ分担する。
    """
    policy = exit_policy(book["key"])
    events = book.get("short_exit_events", [])
    counts = Counter({"対象外": 0, "不成立": 0, "判定不能": 0, "返済要求": 0})
    used, callbacks, last = set(), 0, None
    for event in events:
        equal(set(event), {"at", "snapshot_id", "quote", "positions"}, "S event全tag")
        equal(event["at"], event["quote"]["time"], "S event時計")
        stamp = BASE.quote(event["quote"], "S event quote", normal=False)
        need(last is None or last < stamp, "S event原行順")
        last = stamp
        need(type(event["positions"]) is list and event["positions"], "S event空省略")
        seen = set()
        for row in event["positions"]:
            equal(set(row), {"position_id", "quantity", "reserved", "free", "status", "reason", "candidate", "assessment", "requested", "order_id"}, "S玉trace全tag")
            pid = row["position_id"]
            need(pid in checked["positions"] and pid not in seen, "S実所有trace一意")
            seen.add(pid)
            position = checked["positions"][pid]
            state = timeline.state_at(pid, {"quote": event["quote"], "phase": "after_source"})
            need(state is not None and state["quantity"] > 0, "S非保有trace")
            reserved = 0
            for order in checked["orders"].values():
                if order["kind"] != "exit" or order["position_id"] != pid:
                    continue
                index, current = order["request_quote"]["index"], event["quote"]["index"]
                accepted = order["request_time"] <= event["at"] and (index < current or (index == current and "short_exit_point" not in order))
                fill = timeline.fill_by_order.get(order["id"])
                filled = fill is not None and fill["quote"]["index"] <= current
                if accepted and not filled:
                    reserved += order["quantity"]
            equal((row["quantity"], row["reserved"], row["free"]), (state["quantity"], reserved, state["quantity"] - reserved), "旧P0/Source後のS未予約量")
            need(row["status"] in counts, "S状態分類")
            counts[row["status"]] += 1
            candidate, assessment = row["candidate"], row["assessment"]
            if candidate is None:
                equal((assessment, row["requested"], row["order_id"]), (None, 0, ""), "S候補なし偽要求")
                need(row["status"] in ("対象外", "判定不能"), "S候補なし状態")
                continue
            callbacks += 1
            equal(set(candidate), {"policy", "session_id", "kind", "contract", "position_id", "source", "source_hold_id", "side", "at", "snapshot_id", "quote", "quote_received", "quantity", "reserved", "activation"}, "S候補全tag")
            for name, value in (("policy", policy), ("session_id", book["session"]["id"]), ("kind", book["session"]["kind"]),
                                ("contract", contract), ("position_id", pid), ("source", position["source"]),
                                ("source_hold_id", position["source_hold_id"]), ("side", position["side"]), ("at", event["at"]),
                                ("snapshot_id", event["snapshot_id"]), ("quote", event["quote"]), ("quantity", row["quantity"]),
                                ("reserved", row["reserved"]), ("activation", position["activation"])):
                equal(candidate[name], value, "S候補:" + name)
            need(position["protection_active"] and position["activation"]["unit_net"] > 0 and row["free"] > 0, "S利益起動済/free")
            need(BASE.point_order(position["activation"]) <= (event["quote"]["index"], BASE.PHASE["after_source"]), "S起動後phase")
            active_quote = position["activation"]["quote"]
            need(active_quote["time"] <= event["at"] and active_quote["source_line"] <= event["quote"]["source_line"], "S起動後の価格時計/物理行")
            verify_assessment(candidate, assessment)
            allowed = assessment["decision"]["allowed"]
            expected = "返済要求" if allowed else "不成立" if assessment["decision"]["known"] else "判定不能"
            equal(row["status"], expected, "S三値と要求")
            if allowed:
                order = checked["orders"][row["order_id"]]
                need(order["id"] not in used, "S要求一意")
                used.add(order["id"])
                equal(order["short_exit_point"], {"candidate": candidate, "assessment": assessment}, "S trace/注文全point")
                equal((order["quantity"], row["requested"]), (row["free"], row["free"]), "S全未予約残要求")
                equal((order["request_time"], order["request_quote"], order["reason"]), (event["at"], event["quote"], COUPLED.SHORT.REASON), "S注文出典と専用理由")
                need(order["kind"] == "exit" and order["protection_point"] is None and not order["native_close_signal_id"] and not order["native_close_notice_id"], "Source/P0/S排他")
            else:
                equal((row["requested"], row["order_id"]), (0, ""), "不成立/未知のS注文禁止")
    equal(used, {row["id"] for row in book["orders"] if "short_exit_point" in row}, "S専用全注文とtrace集合")
    return {"保存event": len(events), "保存callback": callbacks, "状態": dict(counts)}


def verify_saved_book(book: dict, key: str, gates: SavedGates, full_clock: bool, contract: str) -> dict:
    """
    機能: 旧共通保存算術へS自己予約の位相だけを明示対応し全新fieldを別検算する。
    引数: book(dict)、key(str)、gates(SavedGates)、full_clock(bool)、contract(str)は原保存/範囲/限月。
    返り値: dictは原注文/実玉/全額とSource/P0/S分類。全経路再生成はしない。
    """
    policy, common = exit_policy(key), key_config(key)[4]
    expected = {"policy": "P0", "entry_timing": "B5Q", "us_open": book["config"]["us_open"], "gate_policy": "E3S",
                "slip_pts": key_config(key)[5], "delay_seconds": key_config(key)[6]}
    if policy != "P0":
        expected["exit_policy"] = policy
    equal(book["config"], expected, "101設定本名・Harvest/Risk空")
    equal(book["key"], key, "101本名key")
    base_top = {"session", "key", "config", "orders", "fills", "positions", "source_events", "metrics", "totals", "account", "finished", "complete", "failure", "stream_scope", "entry_opportunities", "grid_traces", "grid_metrics"}
    if policy != "P0":
        base_top.add("short_exit_contract")
        equal(book["short_exit_contract"], contract, "S外部期待限月")
        if "short_exit_events" in book:
            need(type(book["short_exit_events"]) is list and book["short_exit_events"], "S trace省略正規形")
            base_top.add("short_exit_events")
    equal(set(book), base_top, "101金融top全tag")
    equal(book["stream_scope"], "固定93と同じLast>0のSource受理行。Last0未供給数は共有qualityを参照。", "101金融観測scope")
    equal(set(book["metrics"]) - SHORT_COUNTERS, COUPLED.SHORT.BASE.METRIC_FIELDS, "101共通metric全tag")
    for name in SHORT_COUNTERS & set(book["metrics"]):
        need(policy != "P0" and integer(book["metrics"][name], name, 1) > 0, "S counter正数omitempty")
    for position in book["positions"]:
        equal(set(position), POSITION_FIELDS, "101Position全tag")
    for order in book["orders"]:
        equal(set(order), ORDER_FIELDS | ({"short_exit_point"} if "short_exit_point" in order else set()), "101Order全tag")
        if "short_exit_point" in order:
            need(policy != "P0", "P0へS混入")
            equal(set(order["short_exit_point"]), {"candidate", "assessment"}, "S注文point全tag")
    for fill in book["fills"]:
        equal(set(fill), FILL_FIELDS, "101Fill全tag")
    classes = order_classes(book)
    proxy = {name: copy.deepcopy(value) for name, value in book.items() if name not in {"entry_opportunities", "grid_traces", "grid_metrics", "short_exit_contract", "short_exit_events"}}
    proxy["key"], proxy["config"] = common, {"policy": "P0", "slip_pts": key_config(key)[5], "delay_seconds": key_config(key)[6]}
    positions = {row["id"]: row for row in book["positions"]}
    original_orders = {row["id"]: row for row in book["orders"]}
    timeline = BASE.Timeline(book["fills"], Decimal(key_config(key)[5]) * BASE.POINT, original_orders)
    for order in proxy["orders"]:
        if "short_exit_point" in order:
            candidate = order["short_exit_point"]["candidate"]
            order["protection_point"] = saved_point(candidate, positions[order["position_id"]], timeline)
    for name in SHORT_COUNTERS:
        proxy["metrics"].pop(name, None)
    proxy["metrics"]["protection_exit_requests"] += classes["S"]["要求回数"]
    proxy["metrics"]["protection_exit_fills"] += classes["S"]["約定回数"]

    def source_validator(projected, orders, current_timeline):
        """
        機能: Sourceを自己予約Sと区別して旧出生/比例closeへ結ぶ。
        引数: projected/ orders(dict)、current_timeline(Timeline)は私有算術対応。
        返り値: None。元のSource通知値は変更しない。
        """
        BIRTH.verify_source_b(book, orders, current_timeline)

    checked = types.FunctionType(BASE.verify_book.__code__, {**vars(BASE), "verify_source_events": source_validator}, "101共通保存会計")(proxy, common)
    checked["orders"], checked["positions"], checked["注文別"] = original_orders, positions, classes
    checked["S保存判断"] = verify_short(book, checked, checked["timeline"], contract)
    for metric, cause, field in (("source_exit_requests", "Source", "要求回数"), ("protection_exit_requests", "P0", "要求回数"),
                                 ("protection_exit_fills", "P0", "約定回数"), ("short_exit_requests", "S", "要求回数"), ("short_exit_fills", "S", "約定回数")):
        equal(book["metrics"].get(metric, 0), classes[cause][field], "原counterの排他:" + metric)
        checked["counts"][metric] = classes[cause][field]
    namespace = {**vars(GRID), "key_config": grid_config, "accepted_entries_at_grid": accepted_at}
    types.FunctionType(GRID.verify_grid.__code__, namespace, "101出生とE3Sの保存検算")(book, original_orders, checked["timeline"], gates, full_clock)
    return checked


def comparisons() -> list:
    """
    機能: P0→S5Q/P0→S515Q/S5Q→S515Qの12比較を列挙する。
    引数: なし。
    返り値: list[tuple]はbefore/after本名。
    """
    result = []
    for cost in (0, 5):
        for delay in (0, 1):
            base = f"E3S_B5Q_P0_C{cost}_D{delay}"
            result.extend(((base, "S5Q_" + base), (base, "S515Q_" + base), ("S5Q_" + base, "S515Q_" + base)))
    return result


def entry_fingerprint(position: dict, orders: dict) -> tuple:
    """
    機能: 同出生の要求/実取得の全公開属性を比較する。
    引数: position/ orders(dict)は実玉と原注文。
    返り値: tupleは時計/Index/物理行/Quote/side/価格/初期量。
    """
    order = orders[position["entry_order_id"]]
    request, fill = order["request_quote"], position["entry_quote"]
    quote_fields = ("time", "index", "source_line", "last", "bid", "ask", "quote_ok")
    return (order["request_time"], tuple(request[name] for name in quote_fields), position["side"],
            tuple(fill[name] for name in quote_fields), position["entry_price"], position["initial_quantity"])


def compare_positions(before: dict, after: dict) -> dict:
    """
    機能: Source出生→同実入口/取得変更/片側参加と双方実金額を分解する。
    引数: before/after(dict)は保存検算の返り値。
    返り値: dictは実在額の加法分解。
    """
    aa = {BASE.source_identity(row["source"]): row for row in before["positions"].values()}
    bb = {BASE.source_identity(row["source"]): row for row in after["positions"].values()}
    for source in aa.keys() & bb.keys():
        equal(aa[source]["source"], bb[source]["source"], "共通Source出生全文")
    return types.FunctionType(OLD.compare_positions.__code__, {**vars(OLD), "entry_fingerprint": entry_fingerprint})(before, after)


def daynight_rows(rows: list) -> dict:
    """
    機能: 場別の検算済み実現額と保存DDを日中/夜間別に要約する。
    引数: rows(list[dict])は実在場別行。
    返り値: dictは2区分×12keyの分母付き集計。
    """
    result = {}
    for kind in ("Day", "Night"):
        result[kind] = {}
        for key in KEYS:
            scenes = [row for row in rows if row["key"] == key and row["session"].endswith("_" + kind)]
            diagnostic, totals, counts = DIAG.new_row(), Counter(), Counter()
            for scene in scenes:
                totals.update(scene["totals"])
                counts.update(scene["counts"])
                for name in DIAG.COUNTERS:
                    diagnostic[name] += scene["実現診断"][name]
            DIAG.finish_row(diagnostic, key_config(key)[3])
            diagnostic["保存極値を連結した最大DD円"] = DIAG.joined_dd([dict(session=row["session"], **row["実現診断"]) for row in sorted(scenes, key=lambda row: row["session"])])
            result[kind][key] = {"場数": len(scenes), "totals": dict(totals), "counts": dict(counts), "実現診断": diagnostic}
    return result


def analyze_values(values: list, scope: str) -> dict:
    """
    機能: 検算した12会計の実現額・判断・日別・比較を集約する。
    引数: values(list[dict])、scope(str)は明示入力と人工/接続/正式。
    返り値: dictは実在結果のみ。全Book本文は転記しない。
    """
    need(scope in ("人工", "接続", "正式"), "101保存scope")
    groups = {key: defaultdict(Decimal) for key in KEYS}
    diags = {key: DIAG.new_row() for key in KEYS}
    by_scene = {key: [] for key in KEYS}
    orders = {key: {name: Counter() for name in ("Source", "P0", "S")} for key in KEYS}
    rows, sessions, pairs, judgments, gates_all = [], set(), defaultdict(list), {}, []
    for value in values:
        equal(value["trial"], 101, "101識別")
        session = value["session"]
        need(session not in sessions, "場重複")
        sessions.add(session)
        equal(set(value["books"]), set(KEYS), "101全12口座")
        gates = SavedGates(value)
        clocks = [row["at"] for row in value["books"][KEYS[0]]["grid_traces"]]
        checked = {}
        for key in KEYS:
            book = value["books"][key]
            equal([row["at"] for row in book["grid_traces"]], clocks, "12口座同枠")
            current = checked[key] = verify_saved_book(book, key, gates, scope != "人工", value["contract"])
            diagnostic = types.FunctionType(OLD.realized_row.__code__, {**vars(OLD), "key_config": key_config})(book)
            equal(diagnostic["純額円"], current["totals"]["net_yen"], "実玉と口座純額")
            for name in DIAG.COUNTERS:
                diags[key][name] += diagnostic[name]
            by_scene[key].append(dict(session=session, **diagnostic))
            rows.append(dict(session=session, key=key, totals=current["totals"], counts=current["counts"],
                             grid_metrics=book["grid_metrics"], 実現診断=diagnostic, 注文別=current["注文別"], S保存判断=current["S保存判断"]))
            for collection in (current["totals"], current["counts"]):
                for name, amount in collection.items():
                    groups[key][name] += amount
            for name, amount in book["grid_metrics"].items():
                groups[key]["grid_" + name] += amount
            groups[key]["active_sessions"] += current["counts"]["positions"] > 0
            groups[key]["negative_sessions"] += current["totals"]["net_yen"] < 0
            for cause, metrics in current["注文別"].items():
                orders[key][cause].update(metrics)
        gates_all.append(dict(session=session, **gates.finish(clocks)))
        for before, after in comparisons():
            pairs[after + "対" + before].append(dict(session=session, **compare_positions(checked[before], checked[after])))
        judge = types.FunctionType(OLD.OLD.judgment_counts.__code__, {**vars(OLD.OLD), "key_config": key_config})(value)
        OLD.OLD.merge_judgments(judgments, judge)
    if scope != "人工":
        equal(len(sessions), 2 if scope == "接続" else 54, "正式場分母")
    for key, row in diags.items():
        DIAG.finish_row(row, key_config(key)[3])
        row["保存極値を連結した最大DD円"] = DIAG.joined_dd(sorted(by_scene[key], key=lambda row: row["session"]))
        row["場内最大DD円"] = max((row["場内最大DD円"] for row in by_scene[key]), default=ZERO)
    daily = types.FunctionType(OLD.daily_rows.__code__, {**vars(OLD), "key_config": key_config})(rows)
    return {"試行": 101, "成功": True, "scope": scope, "場数": len(sessions), "Actor数": 12, "会計数": len(rows),
            "Actor設定": {key: {"入口": "E3S", "出口": exit_policy(key), "初期risk": "", "共通基本保護": "P0", "slip_pts": key_config(key)[5], "delay_seconds": key_config(key)[6]} for key in KEYS},
            "集計": {key: dict(row) for key, row in groups.items()}, "実現診断": diags, "場別": rows, "日別": daily,
            "日夜別": daynight_rows(rows),
            "注文別": {key: {name: dict(row) for name, row in causes.items()} for key, causes in orders.items()},
            "出口間の同実入口と実参加差": dict(pairs), "判断分類": judgments, "純判定と共有枠": gates_all,
            "保存検算": SCOPE, "独立監査への分担": "全原行の最初/極値/欠落評価・Source/Features/Scalar出典は独立成功証拠へ結合。保存点だけで全経路検査とは呼ばない。",
            "未実施": {"Raw_CSV_Source_技法_金融再生": 0, "機会損失_退出後_理想峰_MFE回収": 0, "資本金不明ROI": None}}


def render(result: dict) -> str:
    """
    機能: 転記を抑えた実現会計と分母をMarkdownへ変換する。
    引数: result(dict)は検算済み結果。
    返り値: strは結果閲覧文書。
    """
    lines = ["# 101：短秒の失速と現在量・保存会計", "", f"scope={result['scope']}、{result['場数']}場/{result['会計数']}会計。", "",
             "|Key|玉/枚|gross円|fee円|slip円|net円|PF|u起動後最終赤字/起動玉|連結DD円|", "|---|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for key in KEYS:
        row, diagnostic = result["集計"][key], result["実現診断"][key]
        lines.append(f"|{key}|{row['positions']}/{row['entry_quantity']}|{row['gross_yen']}|{row['fee_yen']}|{row['slip_yen']}|{row['net_yen']}|{diagnostic['PF']}|{row['unit_positive_closed_negative']}/{row['unit_positive_positions']}|{diagnostic['保存極値を連結した最大DD円']}|")
    lines.extend(["", "同実入口は実Source出生と要求/取得の全時計・Index・物理行・Quote・価格・初期量が一致するものだけ。取得変更・片側参加額は別帰属。", "",
                  "DDは検算済み保存極値のflat場間連結。全経路完全性は独立証拠へ結ぶ。PF未定義や無取引を黒字安定としない。未参加/退出後仮想利益、機会損失、理想峰回収、資本不明ROIは算出しない。", ""])
    return "\n".join(lines)


def write_viewer(out: Path, values: list) -> list:
    """
    機能: 原実Fillだけを101namespace/schema1のViewer資源へ変換する。
    引数: out(Path)、values(list[dict])は新規出力先と検算済み保存。
    返り値: list[dict]は一覧資源。HTTPやViewer設定を操作しない。
    """
    resources = []
    for value in values:
        session = value["session"]
        for key in KEYS:
            rid = "101_" + key + "_" + session
            name = rid + ".trades.jsonl"
            with (out / name).open("x", encoding="utf-8", newline="\n") as stream:
                for trade in BASE.viewer_trades(value["books"][key]):
                    stream.write(json.dumps(trade, ensure_ascii=False, default=BASE.serial, allow_nan=False) + "\n")
            resources.append(dict(id=rid, title="短秒の失速と現在量 " + key + " " + session, symbol="NK225", product="NK225mini",
                                  session=session, method_id=key, point_value=100, pnl_format="trades", pnl_basis="net", pnl_path=name,
                                  market_path="NK225/" + session + "/book.jsonl.gz"))
    return resources


def verify_viewer(resource: dict, trades: list, book: dict) -> None:
    """
    機能: 表示行から独立所有と純現金を計算し全実Fill・最終0へ結ぶ。
    引数: resource(dict)、trades(list)、book(dict)は表示資源/行/原会計。
    返り値: None。価格の全原行照合や実API照合は行わない。
    """
    key, session = book["key"], book["session"]["id"]
    equal((resource["id"], resource["title"], resource["point_value"], resource["pnl_basis"]),
          ("101_" + key + "_" + session, "短秒の失速と現在量 " + key + " " + session, 100, "net"), "101表示ラベル/倍率")
    equal(trades, BASE.viewer_trades(book), "全実約定の表示全値")
    holds, net = {}, ZERO
    for row in trades:
        qty, pid = row["qty"], row["position_id"]
        need(integer(qty, "表示量", 1) > 0, "表示整数枚数")
        if row["type"].endswith("N"):
            need(pid not in holds, "表示所有一意")
            holds[pid] = [qty, row["price"], 1 if row["type"].startswith("Long") else -1]
        else:
            need(pid in holds and 0 < qty <= holds[pid][0], "表示返済所有")
            hold = holds[pid]
            net += hold[2] * (row["price"] - hold[1]) * 100 * qty
            hold[0] -= qty
        net -= row["fee_yen"]
    need(all(row[0] == 0 for row in holds.values()), "表示残0")
    equal(net, book["totals"]["net_yen"], "表示現金純額")


def load_json(path: Path, financial: bool = False):
    """
    機能: 指紋確認後の明示metadata又はNativeを標準JSONで読む。
    引数: path(Path)、financial(bool)は対象とDecimal会計指定。
    返り値: JSON互換値。
    """
    raw = gzip.decompress(path.read_bytes()) if path.suffix == ".gz" else path.read_bytes()
    return json.loads(raw, parse_float=Decimal if financial else float)


def main() -> int:
    """
    機能: 事前固定JSONと同条件の独立成功がそろった市場保存だけを処理する。
    引数: CLIの--fixed/--fixed-sha/--stage/--outは固定宣言・SHA・段階・新規先。
    返り値: intは成功0。空の準備雛形は入力本文前に拒否する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixed", type=Path, required=True)
    parser.add_argument("--fixed-sha", required=True)
    parser.add_argument("--stage", choices=("first2", "full54"), required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    # 市場metadata guardは別小型moduleへ分離し、保存算術の人工口を維持する。
    from 市場入力の固定を確認する import prepare, market_module
    tasks, before, proofs = prepare(args.fixed, args.fixed_sha, args.stage, args.out)
    market = market_module()
    values = []
    for task in tasks:
        value = load_json(Path(task["native"]), True)
        market.validate_native(value, task["metadata"])
        equal((value["trial"], value["version"], value["session"], value["condition_sha256"]), (101, 1, task["session"], proofs["条件SHA256"]), "101Nativeと実行条件")
        need(value["actual_run_complete"] is True and all(value[name] is False for name in ("source_reexecuted", "features_recomputed", "charts_recomputed")), "Nativeの新再生成なし")
        equal(set(value["books"]), set(KEYS), "Native全12")
        header = load_json(Path(task["header"]), True)
        value = {**value, "chart_grids": header["grids"]}
        old = load_json(Path(task["native100"]), True)
        for key in P0_KEYS:
            equal(value["books"][key], old["books"][key], "新P0旧100全JSON除外0")
        values.append(value)
    result = analyze_values(values, "接続" if args.stage == "first2" else "正式")
    result.update(proofs)
    result["入力依存SHA256前後"] = before
    need(all(digest(Path(path)) == sha for path, sha in before.items()), "保存前の指紋差")
    args.out.mkdir(parents=True)
    resources = write_viewer(args.out, values)
    for value in values:
        for resource in (row for row in resources if row["session"] == value["session"]):
            trades = [json.loads(line, parse_float=Decimal) for line in (args.out / resource["pnl_path"]).read_text(encoding="utf-8").splitlines()]
            verify_viewer(resource, trades, value["books"][resource["method_id"]])
    BASE.write_json(args.out / "結果.json", result)
    BASE.write_json(args.out / "一覧.resources.json", {"schema_version": 1, "path_base": "catalog", "resources": resources})
    (args.out / "結果.md").write_text(render(result), encoding="utf-8", newline="\n")
    need(all(digest(Path(path)) == sha for path, sha in before.items()), "保存後の指紋差")
    BASE.write_json(args.out / "保存完了.json", {"成功": True, "scope": SCOPE, "stage": args.stage, "場数": len(values), "会計数": len(values) * 12,
                                                "Native参照": tasks, "前後不変": True, "結果SHA256": digest(args.out / "結果.json"), **proofs})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
