"""停止完全接続24会計の保存算術・Viewer型と狭い破損を確認する。"""

import copy
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ARTIFACTS = ROOT / "work/短秒複合退出の再生/人工/完全接続"


def module(name: str, path: Path):
    """
    機能: 新規保存器又はmetadata器具を明示importする。
    引数: name(str)、path(Path)は識別名と対象。
    返り値: moduleは当人工対象。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


def reject(label: str, call, rejected: list) -> None:
    """
    機能: 狭い破損が受理されないことを確認する。
    引数: label(str)、call(callable)、rejected(list)は識別/実行/記録。
    返り値: None。受理された場合は失敗する。
    """
    try:
        call()
    except (ValueError, AssertionError, KeyError, TypeError) as error:
        rejected.append({"破損": label, "拒否": str(error)})
    else:
        raise AssertionError("破損を受理: " + label)


def project(value: dict) -> dict:
    """
    機能: 完全人工の既存値だけを保存器の公開入力型へ射影する。
    引数: value(dict)は元Go型人工。
    返り値: dictは新金融やSource生成を含まない保存対象。
    """
    return {"trial": 101, "session": value["tape"]["session"]["id"], "contract": "人工限月",
            "books": value["output"]["result"]["books"], "chart_grids": [event["context"] for event in value["tape"]["events"] if event["kind"] == "grid"],
            "gate_assessments": value["output"]["gate_assessments"]}


def main() -> None:
    """
    機能: 24口座の保存算術・表示変換と新metadata口を人工で閉じる。
    引数: なし。市場/Raw/Nativeの引数は持たない。
    返り値: None。
    """
    save = module("101保存器人工", HERE / "集計.py")
    guard = module("101保存metadata人工", HERE / "市場入力の固定を確認する.py")
    runtime_stop = ROOT / "work/短秒複合退出の再生/停止.json"
    assert save.digest(runtime_stop) == "ff571dba63a439e9df2fc855f722da1e506ee26cc1ef483de9aa4356e39e2eb7"
    runtime = json.loads(runtime_stop.read_bytes())
    snapshots = {str(runtime_stop): save.digest(runtime_stop), str(save.OLD_PATH): save.digest(save.OLD_PATH),
                 str(save.COUPLED_PATH): save.digest(save.COUPLED_PATH)}
    for path, sha in runtime["前SHA256"].items():
        assert save.digest(ROOT / path) == sha
        snapshots[str((ROOT / path).resolve())] = sha
    cases, values, partial, half, fills, callbacks = [], [], 0, 0, 0, 0
    artifact_out = HERE / "人工_停止版"
    assert not artifact_out.exists()
    artifact_out.mkdir()
    for side in (1, -1):
        path = ARTIFACTS / f"方向{side}.json"
        expected = runtime["全所有SHA256"][f"人工\\完全接続\\方向{side}.json"]
        assert save.digest(path) == expected
        snapshots[str(path)] = expected
        source = json.loads(path.read_bytes(), parse_float=Decimal)
        value = project(source)
        result = save.analyze_values([value], "人工")
        output = artifact_out / f"方向{side}"
        output.mkdir()
        resources = save.write_viewer(output, [value])
        assert len(resources) == 12
        for resource in resources:
            book = value["books"][resource["method_id"]]
            trades = [json.loads(line, parse_float=Decimal) for line in (output / resource["pnl_path"]).read_text(encoding="utf-8").splitlines()]
            save.verify_viewer(resource, trades, book)
            fills += len(trades)
            half += sum(row["fee_yen"] % 1 != 0 for row in trades)
            for position in book["positions"]:
                partial += sum(row["action"] == "close" and row["position_id"] == position["id"] for row in book["fills"]) > 1
        for key in save.P0_KEYS:
            assert value["books"][key] == source["baseline100_p0_api"]["books"][key]
        save.BASE.write_json(output / "結果.json", result)
        save.BASE.write_json(output / "一覧.resources.json", {"schema_version": 1, "path_base": "catalog", "resources": resources})
        (output / "結果.md").write_text(save.render(result), encoding="utf-8", newline="\n")
        callbacks += sum(row["S保存判断"]["保存callback"] for row in result["場別"])
        cases.append({"方向": side, "元SHA256": expected, "会計": 12, "資源": 12, "純額": {key: result["集計"][key]["net_yen"] for key in save.KEYS}})
        values.append(value)
    rejected = []
    original = values[0]
    for label, mutate in [
        ("fee半円改変", lambda value: value["books"][save.KEYS[0]]["fills"][0].__setitem__("fee_yen", Decimal(0))),
        ("実Fill枚数改変", lambda value: value["books"][save.KEYS[0]]["fills"][0].__setitem__("quantity", 9)),
        ("未知Position field", lambda value: value["books"][save.KEYS[0]]["positions"][0].__setitem__("unknown", 1)),
        ("S専用counter不一致", lambda value: value["books"][save.KEYS[4]]["metrics"].__setitem__("short_exit_requests", 7)),
        ("SourceとS二重point", lambda value: next(order for order in value["books"][save.KEYS[4]]["orders"] if "short_exit_point" in order).__setitem__("protection_point", {})),
        ("S候補量改変", lambda value: next(order for order in value["books"][save.KEYS[4]]["orders"] if "short_exit_point" in order)["short_exit_point"]["candidate"].__setitem__("quantity", 9)),
        ("S判断符号改変", lambda value: next(order for order in value["books"][save.KEYS[4]]["orders"] if "short_exit_point" in order)["short_exit_point"]["assessment"]["evidence"].__setitem__("signed_quantity", 1)),
        ("入口check改変", lambda value: value["gate_assessments"][0]["assessment"]["checks"][0].__setitem__("passed", False)),
    ]:
        broken = copy.deepcopy(original)
        mutate(broken)
        reject(label, lambda: save.analyze_values([broken], "人工"), rejected)
    # ----------------------------------------
    catalog = json.loads((artifact_out / "方向1/一覧.resources.json").read_bytes())
    resource = catalog["resources"][0]
    book = original["books"][resource["method_id"]]
    trades = save.BASE.viewer_trades(book)
    for label, change in [("表示fee改変", lambda rows: rows[0].__setitem__("fee_yen", 0)),
                          ("表示枚数改変", lambda rows: rows[0].__setitem__("qty", 9))]:
        broken = copy.deepcopy(trades)
        change(broken)
        reject(label, lambda: save.verify_viewer(resource, broken, book), rejected)
    bad_resource = dict(resource, title="別のラベル")
    reject("表示ラベル改変", lambda: save.verify_viewer(bad_resource, trades, book), rejected)
    empty = {"key": book["key"], "session": book["session"], "fills": [], "totals": {"net_yen": 0}}
    save.verify_viewer(resource, [], empty)
    # ----------------------------------------
    fixed = {"version": 1, "試行": 101, "scope": guard.FIXED_SCOPE, "固定": True, "stage": "first2",
             "condition": {"path": "未生成条件.json", "sha256": "a" * 64}, "run": "未生成金融",
             "completion_sha256": "b" * 64, "audit": {"path": "未生成独立.json", "sha256": "c" * 64}, "first2_audit": None}
    guard.validate_fixed(fixed, "first2")
    for label, change in [("未固定宣言", lambda value: value.__setitem__("固定", False)),
                          ("金融SHA空", lambda value: value.__setitem__("completion_sha256", "")),
                          ("別stage", lambda value: value.__setitem__("stage", "full54")),
                          ("独立SHA空", lambda value: value["audit"].__setitem__("sha256", ""))]:
        broken = copy.deepcopy(fixed)
        change(broken)
        reject(label, lambda: guard.validate_fixed(broken, "first2"), rejected)
    first_ids = ["2026-09-21_Day", "2026-09-21_Night"]
    scenes = [dict(session=sid, **{name: {"path": f"{sid}_{name}", "sha256": "d" * 64} for name in ("native", "old", "tape", "header", "records")}) for sid in first_ids]
    plan = {"scenes": scenes, "own": {"audit.py": "e" * 64}}
    details, inputs = [], {}
    for scene in scenes:
        files = {scene[name]["path"]: scene[name]["sha256"] for name in ("native", "old", "tape", "header", "records")}
        inputs.update(files)
        details.append(dict(session=scene["session"], 成功=True, 前後不変=True, 新会計数=12, 新P0独立全文会計=4, 旧100P0独立全文会計=4, 不一致数=0,
                            P0除外=[], 入力SHA256=files, 保存record読戻し={"処理完了": True, "不一致": 0, "session": scene["session"]}))
    audit = dict(成功=True, scope="監査scope器具", stage="first2", sessions=first_ids, 条件SHA256="a" * 64, 金融完了SHA256="b" * 64,
                 監査コードSHA256=plan["own"], 新会計数=24, 新P0独立全文会計=8, 旧100P0独立全文会計=8, 不一致数=0, 前後不変=True,
                 入力SHA256前=inputs, 入力SHA256後=copy.deepcopy(inputs), Source再形成=False, 特徴チャート再計算=False, Raw読取=0, 機会損失算出=False, details=details)
    guard.validate_audit(audit, plan, "first2", "a" * 64, "b" * 64, "監査scope器具")
    for label, change in [("同条件差", lambda value: value.__setitem__("条件SHA256", "f" * 64)),
                          ("独立24不足", lambda value: value.__setitem__("新会計数", 12)),
                          ("NativeSHA差", lambda value: value["details"][0]["入力SHA256"].__setitem__(scenes[0]["native"]["path"], "f" * 64)),
                          ("readback未完", lambda value: value["details"][0]["保存record読戻し"].__setitem__("処理完了", False)),
                          ("前後差", lambda value: value.__setitem__("前後不変", False))]:
        broken = copy.deepcopy(audit)
        change(broken)
        reject(label, lambda: guard.validate_audit(broken, plan, "first2", "a" * 64, "b" * 64, "監査scope器具"), rejected)
    template = dict(fixed, 固定=False, condition={"path": "", "sha256": ""}, run="", completion_sha256="", audit={"path": "", "sha256": ""})
    template_path = HERE / "実行固定_雛形.json"
    template_path.write_text(json.dumps(template, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    cli = subprocess.run([sys.executable, "-B", "-X", "utf8", str(HERE / "集計.py"), "--fixed", str(template_path),
                          "--fixed-sha", save.digest(template_path), "--stage", "first2", "--out", str(HERE / "未生成出力")], capture_output=True, text=True, encoding="utf-8")
    assert cli.returncode != 0 and "未固定の保存宣言" in cli.stderr and not (HERE / "未生成出力").exists()
    assert all(save.digest(Path(path)) == sha for path, sha in snapshots.items())
    result = {"成功": True, "scope": "停止完全Inputの公開型人工2鏡像24会計の保存点とViewer形式。全経路の再金融なし",
              "人工": cases, "会計数": 24, "Viewer資源": 24, "全Fill表示行": fills, "部分返済玉": partial, "半円表示行": half,
              "S保存callback": callbacks, "空Viewer型": True, "旧100P0全文会計": 8, "P0除外": [],
              "狭い破損拒否数": len(rejected), "破損拒否": rejected, "metadata正常": 2,
              "CLI未固定拒否終了": cli.returncode, "未固定で本文/出力へ進まない": True,
              "入力コードSHA256前後": snapshots, "前後不変": True, "Raw_CSV_Native市場本文追加": 0,
              "Source_Features_金融再生": 0, "機会損失_退出後_理想峰回収": 0}
    save.BASE.write_json(HERE / "人工確認_停止版.json", result)
    print(json.dumps({"成功": True, "会計": 24, "表示資源": 24, "破損拒否": len(rejected), "人工確認SHA256": save.digest(HERE / "人工確認_停止版.json")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
