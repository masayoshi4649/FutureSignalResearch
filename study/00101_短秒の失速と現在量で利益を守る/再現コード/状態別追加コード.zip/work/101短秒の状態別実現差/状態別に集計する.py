"""S5Qの最初の実要求時だけを分類し、同実入口の実現差を記述する。"""

import argparse
from collections import defaultdict
from decimal import Decimal
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
SAVED_PATH = ROOT / "work/101集計と閲覧資料/集計.py"
SAVED_SHA = "88d6c372281a299ae524733cea10c33121b2011ef1d73fe9ed20b111e0f2c207"
PURE_PATH = ROOT / "work/短秒複合退出の独立純式/短秒の純判定.py"
PURE_SHA = "d50202814e046a7a7f69579882544102e5180e09cf9e88ce46168a542bc9126b"
SCOPE = "S5Q初回実要求時の15秒/uと同実入口の実現差。新売買/順位/機会損失評価なし"


def digest(path: Path) -> str:
    """
    機能: 許可された明示入力の指紋を得る。
    引数: path(Path)はコード又は固定入力。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fixed(name: str, path: Path, expected: str):
    """
    機能: 停止保存器又は独立窓式をSHA固定でimportする。
    引数: name/expected(str)、path(Path)は識別/指紋/対象。
    返り値: moduleは保存/純算術のみ。金融を再生しない。
    """
    if digest(path) != expected:
        raise ValueError("固定コードSHA差:" + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


SAVE = fixed("101状態別の停止保存算術", SAVED_PATH, SAVED_SHA)
PURE = fixed("101状態別の停止d502窓", PURE_PATH, PURE_SHA)
need, equal = SAVE.need, SAVE.equal


def pure_value(value):
    """
    機能: 純窓式のGo float入力だけを既存の表現器へ対応する。
    引数: value(JSON互換値)は保存窓/根拠。
    返り値: JSON互換値。円会計のDecimalは元側に保持する。
    """
    return SAVE.OLD.OLD.pure_values(value)


def classify_fifteen(point: dict) -> dict:
    """
    機能: 実S5Q要求に保存された当時15秒をd502.windowで再確認する。
    引数: point(dict)は元short_exit_pointのcandidate/assessment。
    返り値: dictは反対/0/同方向/S515Q必要未知。S5Qのgateは追加しない。
    """
    candidate, assessment = point["candidate"], point["assessment"]
    need(candidate["policy"] == "S5Q" and assessment["decision"]["policy"] == "S5Q"
         and assessment["decision"]["known"] is True and assessment["decision"]["allowed"] is True, "基準は実S5Q要求")
    evidence = pure_value(assessment["evidence"])
    current = {**evidence["current"], "short": {"time": evidence["short_time"], "mid": evidence["short_mid"]}}
    quote = candidate["quote"]
    for name, source in (("time", "time"), ("bid", "bid"), ("ask", "ask"), ("last", "last"), ("source_index", "index"), ("source_line", "source_line")):
        equal(current[name], quote[source], "当要求とCurrent:" + name)
    price = current["reference"] == "NK225" and 0 < current["bid"] < current["ask"] and current["last"] > 0 and 0 <= candidate["at"] - current["time"] <= 15
    need(price, "実S5Q要求の正常現在値")
    rebuilt = PURE.window(evidence["fifteen"]["window"], current, 15.0, candidate["side"], price)
    equal(rebuilt, evidence["fifteen"], "d502の15秒窓全文")
    speed = rebuilt["signed_speed"]
    label = "S515Q必要未知" if not rebuilt["known"] else "反対" if speed < 0 else "0" if speed == 0 else "同方向"
    return {"15秒状態": label, "15秒既知": rebuilt["known"], "方向付き15秒速度": speed,
            "窓": rebuilt["window"], "現在価格時計": current["time"]}


def compact_book(book: dict) -> dict:
    """
    機能: 停止保存器の同実入口と実参加差の公開口へ対応する。
    引数: book(dict)は既存完結口座。
    返り値: dictは原注文/実玉/総額。値を生成しない。
    """
    need(book["complete"] is True and book["finished"] is True and book["failure"] == "", "完結保存だけ")
    orders, positions = {row["id"]: row for row in book["orders"] or []}, {row["id"]: row for row in book["positions"] or []}
    equal(len(orders), len(book["orders"] or []), "注文一意")
    equal(len(positions), len(book["positions"] or []), "実玉一意")
    need(all(row["quantity"] == 0 and row["reserved"] == 0 for row in positions.values()), "期末残0")
    equal(sum((row["realized_net"] for row in positions.values()), Decimal(0)), book["totals"]["net_yen"], "既存玉と口座純額")
    return {"orders": orders, "positions": positions, "totals": book["totals"]}


def first_request(book: dict, position: dict) -> dict | None:
    """
    機能: positionの最初の実S5Q要求を注文時計/原行/受理順で選ぶ。
    引数: book/position(dict)は実注文列と実玉。
    返り値: dict|Noneは原注文。純式callbackの最初を代用しない。
    """
    rows = [(n, order) for n, order in enumerate(book["orders"] or [])
            if order["kind"] == "exit" and order["position_id"] == position["id"] and "short_exit_point" in order]
    if not rows:
        return None
    return min(rows, key=lambda row: (row[1]["request_time"], row[1]["request_quote"]["index"], row[1]["request_quote"]["source_line"], row[0]))[1]


def unit_state(unit) -> str:
    """
    機能: 当要求のuを正/0/負へ記述分類する。
    引数: unit(number)は既存保存算術による単価益。
    返り値: strは閾値を増やさない符号区分。
    """
    return "正" if unit > 0 else "0" if unit == 0 else "負"


def observe_request(book: dict, position: dict, order: dict) -> dict:
    """
    機能: 初回実要求の当時u/実残/Source-P0先行予約を保存履歴へ結ぶ。
    引数: book/position/order(dict)は原口座・玉・最初のS要求。
    返り値: dictは当時だけの分類と出典。未来fillを予約解放へ使わない。
    """
    point = order["short_exit_point"]
    candidate = point["candidate"]
    quote = order["request_quote"]
    equal((candidate["quote"], candidate["at"], candidate["position_id"], candidate["source"], candidate["side"]),
          (quote, order["request_time"], position["id"], position["source"], position["side"]), "実S要求の候補出典")
    equal(candidate["activation"], position["activation"], "当要求の起動出典")
    active = candidate["activation"]
    need(active["unit_net"] > 0 and active["quote"]["time"] <= order["request_time"] and active["quote"]["index"] <= quote["index"], "既存strict u起動後")
    equal(order["quantity"], candidate["quantity"] - candidate["reserved"], "実S要求の未予約残")
    need(order["quantity"] > 0 and order["protection_point"] is None and not order["native_close_notice_id"], "S要求とSource/P0を分離")
    orders = {row["id"]: row for row in book["orders"] or []}
    cost = Decimal(book["config"]["slip_pts"]) * SAVE.BASE.POINT
    timeline = SAVE.BASE.Timeline(book["fills"] or [], cost, orders)
    state = timeline.state_at(position["id"], {"quote": quote, "phase": "after_source"})
    need(state is not None, "S前の実取得")
    equal(state["quantity"], candidate["quantity"], "当原行Fill後の実量")
    reserved = {"Source": 0, "P0": 0, "S": 0}
    selected_index = next(n for n, row in enumerate(book["orders"]) if row["id"] == order["id"])
    for prior in book["orders"][:selected_index]:
        if prior["kind"] != "exit" or prior["position_id"] != position["id"]:
            continue
        need(prior["request_time"] <= order["request_time"] and prior["request_quote"]["index"] <= quote["index"], "前要求の因果順")
        fill = timeline.fill_by_order.get(prior["id"])
        if fill is not None and fill["quote"]["index"] <= quote["index"]:
            continue
        cause = "S" if "short_exit_point" in prior else "P0" if prior["protection_point"] is not None else "Source"
        reserved[cause] += prior["quantity"]
    equal(sum(reserved.values()), candidate["reserved"], "初回S前の先行予約")
    mtm = SAVE.saved_point(candidate, position, timeline)
    unit = mtm["unit_net"]
    return {"position_id": position["id"], "order_id": order["id"], "要求時計": order["request_time"], "要求Quote": quote,
            "現在u": unit, "u状態": unit_state(unit), "実保有枚": candidate["quantity"],
            "S要求枚": order["quantity"], "先行予約枚": reserved, "S前既返済枚": position["initial_quantity"] - candidate["quantity"],
            "部分量": order["quantity"] < position["initial_quantity"], **classify_fifteen(point)}


def diagnose_case(session: str, books: dict) -> dict:
    """
    機能: C/D別に初回S5Q観測を一度作り、同実入口だけを状態別に集約する。
    引数: session(str)、books(dict)は許可された既存口座群。
    返り値: dictは記述集計と取得変更の加法分解。新条件/成績を生成しない。
    """
    need(set(books) <= set(SAVE.KEYS), "101本名だけ")
    observed, comparisons = [], []
    for cost in (0, 5):
        for delay in (0, 1):
            base = f"E3S_B5Q_P0_C{cost}_D{delay}"
            key = "S5Q_" + base
            if key not in books:
                continue
            book = books[key]
            reference = compact_book(book)
            source_rows, class_rows = {}, {}
            for position in reference["positions"].values():
                source = SAVE.BASE.source_identity(position["source"])
                need(source not in source_rows, "1Source出生1実玉")
                source_rows[source] = position
                first = first_request(book, position)
                row = {"session": session, "S5Qkey": key, "source": position["source"], "初期量": position["initial_quantity"],
                       "初回実S要求あり": first is not None}
                if first is None:
                    row.update({"15秒状態": "実S要求なし", "u状態": "観測点なし", "現在u": None, "S要求枚": 0})
                else:
                    row.update(observe_request(book, position, first))
                observed.append(row)
                class_rows[source] = row
            for target in ("S515Q_" + base, base):
                if target not in books:
                    comparisons.append({"S5Qkey": key, "比較先key": target, "測定": False, "理由": "許可人工にこの実口座が無い。架空口座は補完しない"})
                    continue
                other = compact_book(books[target])
                partition = SAVE.compare_positions(reference, other)
                other_sources = {SAVE.BASE.source_identity(row["source"]): row for row in other["positions"].values()}
                groups = {}
                changed = []
                for source in sorted(source_rows.keys() & other_sources.keys()):
                    pa, pb = source_rows[source], other_sources[source]
                    if SAVE.entry_fingerprint(pa, reference["orders"]) != SAVE.entry_fingerprint(pb, other["orders"]):
                        changed.append({"source": pa["source"], "S5Q実現net": pa["realized_net"], "比較先実現net": pb["realized_net"]})
                        continue
                    classification = class_rows[source]
                    group_id = classification["15秒状態"] + "/u=" + classification["u状態"]
                    group = groups.setdefault(group_id, {"玉数": 0, "S5Q実現net": Decimal(0), "比較先実現net": Decimal(0), "差_比較先minusS5Q": Decimal(0),
                        "S5Q_u起動玉": 0, "比較先_u起動玉": 0, "S5Q_u後最終赤字玉": 0, "比較先_u後最終赤字玉": 0,
                        "S5Q_u後最終負額": Decimal(0), "比較先_u後最終負額": Decimal(0), "Source先行予約あり玉": 0, "P0先行予約あり玉": 0,
                        "部分量玉": 0, "S要求枚": 0})
                    group["玉数"] += 1
                    group["S5Q実現net"] += pa["realized_net"]
                    group["比較先実現net"] += pb["realized_net"]
                    group["差_比較先minusS5Q"] += pb["realized_net"] - pa["realized_net"]
                    for label, position in (("S5Q", pa), ("比較先", pb)):
                        activated = position["marks"]["first_unit_positive"] is not None
                        group[label + "_u起動玉"] += activated
                        negative = activated and position["realized_net"] < 0
                        group[label + "_u後最終赤字玉"] += negative
                        group[label + "_u後最終負額"] += position["realized_net"] if negative else 0
                    if classification["初回実S要求あり"]:
                        group["Source先行予約あり玉"] += classification["先行予約枚"]["Source"] > 0
                        group["P0先行予約あり玉"] += classification["先行予約枚"]["P0"] > 0
                        group["部分量玉"] += classification["部分量"]
                        group["S要求枚"] += classification["S要求枚"]
                equal(sum(row["玉数"] for row in groups.values()), partition["同実入口"], "1玉1初回分類の分母")
                equal(sum((row["差_比較先minusS5Q"] for row in groups.values()), Decimal(0)), partition["同実入口差円"], "状態群の同実入口差")
                comparisons.append({"S5Qkey": key, "比較先key": target, "測定": True, "参加差分解": partition, "同実入口の状態別": groups, "取得変更_出口差対象外": changed})
    return {"session": session, "初回観測": observed, "比較": comparisons}


def render(result: dict) -> str:
    """
    機能: 状態群と実現差だけを短い閲覧表へ出す。
    引数: result(dict)は検査済み記述結果。
    返り値: strは因果/新gate/採用順位を主張しないMarkdown。
    """
    lines = ["# 101短秒の状態別実現差", "", SCOPE, "", "|場/比較|15秒/u|同実玉|S5Q net|比較先 net|比較先−S5Q|", "|---|---|---:|---:|---:|---:|"]
    for scene in result["details"]:
        for pair in scene["比較"]:
            if not pair["測定"]:
                continue
            for label, row in pair["同実入口の状態別"].items():
                lines.append(f"|{scene['session']} {pair['比較先key']}対{pair['S5Qkey']}|{label}|{row['玉数']}|{row['S5Q実現net']}|{row['比較先実現net']}|{row['差_比較先minusS5Q']}|")
    return "\n".join(lines + ["", "初回は純式成立でなく実S5Q要求。15秒未知はS515Qに必要な未知で、S5Qの新gateではない。C/Dとpolicyを独立市場例に数えず、取得変更/片側参加は退出差へ帰属しない。実現差は後の記述値だけで分類に使わない。", ""])


def main() -> None:
    """
    機能: Root固定の金融/独立/保存成功後だけ新101Native54を記述する。
    引数: --fixed/--fixed-sha/--outはRoot宣言・SHA・新規dir。
    返り値: None。未生成雛形は本文前拒否する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixed", type=Path, required=True)
    parser.add_argument("--fixed-sha", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    from 実行前固定を確認する import prepare
    tasks, before, proofs = prepare(args.fixed, args.fixed_sha, args.out)
    details = []
    for task in tasks:
        body = gzip.decompress(Path(task["path"]).read_bytes())
        value = json.loads(body, parse_float=Decimal)
        equal((value["trial"], value["version"], value["session"], value["condition_sha256"]), (101, 1, task["session"], proofs["条件SHA256"]), "固定新Native識別")
        equal(set(value["books"]), set(SAVE.KEYS), "新12口座")
        need(value["actual_run_complete"] is True, "新金融完了")
        details.append(diagnose_case(value["session"], value["books"]))
    union = {(row["session"], row["source"]["method"], row["source"]["signal_id"]) for scene in details for row in scene["初回観測"] if row["初回実S要求あり"]}
    result = {"成功": True, "scope": SCOPE, "details": details, "S5Q実要求Source出生のC_D和集合": len(union),
              "独立市場例数の推定": False, "入力SHA256前後": before, "前後不変": True, **proofs,
              "再金融_約定生成_退出後価格_MFE_機会損失_新gate": 0}
    need(all(digest(Path(path)) == sha for path, sha in before.items()), "診断前後入力差")
    args.out.mkdir(parents=True)
    SAVE.BASE.write_json(args.out / "結果.json", result)
    (args.out / "結果.md").write_text(render(result), encoding="utf-8", newline="\n")


if __name__ == "__main__":
    main()
