"""状態別補助の停止コードだけを既存ZIPと重複させず保存する。"""

import binascii
import hashlib
import json
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
STOP = HERE / "停止.json"
STOP_SHA = "85075ce3af5672ea09d24b84333229a93fff7760e33a4ab9eb7732f5a0fe5d55"
BASE = ROOT / "study/00101_短秒の失速と現在量で利益を守る/再現コード/市場実行版コード.zip"
BASE_SHA = "4b2bafe2bac89a0d158b4274d54963390ad98f387999262d2de21f437d4a6587"


def sha(body: bytes) -> str:
    """
    機能: コードと小型証拠の指紋を得る。
    引数: body(bytes)は対象の全bytes。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


def row(body: bytes) -> dict:
    """
    機能: ZIP照合用の指紋とCRCを得る。
    引数: body(bytes)はentry全文。
    返り値: dictはSHA256/CRC32/bytes。
    """
    return {"SHA256": sha(body), "CRC32": f"{binascii.crc32(body) & 0xffffffff:08x}", "bytes": len(body)}


def save_new(path: Path, value: dict) -> None:
    """
    機能: 新規の保存証拠だけを書き込む。
    引数: path(Path)は未存在先、value(dict)は証拠。
    返り値: None。
    """
    with path.open("x", encoding="utf-8", newline="\n") as output:
        json.dump(value, output, ensure_ascii=False, indent=2)
        output.write("\n")


def main() -> None:
    """
    機能: 停止補助と不足参照だけを追加ZIP化し全entryを読み戻す。
    引数: なし。固定停止と既存427コードZIPだけを参照する。
    返り値: None。SHA/CRC差、既存出力、禁止本文は例外で停止する。
    """
    assert sha(STOP.read_bytes()) == STOP_SHA and sha(BASE.read_bytes()) == BASE_SHA
    stopped = json.loads(STOP.read_bytes())
    assert stopped["成功"] is True
    candidates = {ROOT / name: value for name, value in stopped["コードSHA256"].items()}
    candidates[STOP] = STOP_SHA
    candidates[Path(__file__).resolve()] = sha(Path(__file__).read_bytes())
    candidates[HERE / "人工確認.json"] = stopped["人工確認SHA256"]
    for name in ("人工結果.md", "CLI_help.log"):
        candidates[HERE / name] = sha((HERE / name).read_bytes())
    # ----------------------------------------
    # 保存算術の依存集合は停止metadataから取り、人工入力本文は開かない。
    saved_stop = ROOT / "work/101集計と閲覧資料/停止.json"
    candidates[saved_stop] = "2d94387f2443e8c127eafde8716df1688a63d1760adae1278dd288957aa399d7"
    assert sha(saved_stop.read_bytes()) == candidates[saved_stop]
    saved = json.loads(saved_stop.read_bytes())
    for names in (saved["コードSHA256"], saved["Python再用依存SHA256"]):
        for name, expected in names.items():
            path = Path(name)
            path = (path if path.is_absolute() else ROOT / path).resolve()
            assert path.is_relative_to(ROOT)
            candidates[path] = expected
    for name in ("work/短秒複合退出の市場接続/停止.json",
                 "work/短秒複合退出の市場の独立確認_版2/停止.json"):
        candidates[ROOT / name] = sha((ROOT / name).read_bytes())
    before = {str(path): sha(path.read_bytes()) for path in candidates}
    assert all(before[str(path)] == expected for path, expected in candidates.items())
    additions, reused, base_rows = {}, [], {}
    with ZipFile(BASE) as source:
        infos = source.infolist()
        assert len(infos) == len({info.filename for info in infos}) == 428
        assert len([info for info in infos if info.filename != "manifest.json"]) == 427
        for info in infos:
            body = source.read(info.filename)
            assert not info.is_dir() and len(body) == info.file_size
            assert binascii.crc32(body) & 0xffffffff == info.CRC
            base_rows[info.filename] = row(body)
        for path, expected in sorted(candidates.items(), key=lambda item: item[0].as_posix()):
            relative = path.relative_to(ROOT).as_posix()
            entry = "FutureSignalResearch/" + relative
            if entry in base_rows:
                assert base_rows[entry]["SHA256"] == expected
                reused.append({"repo相対path": relative, "既存entry": entry, **base_rows[entry]})
                continue
            body = path.read_bytes()
            assert path.suffix in (".py", ".md", ".json", ".log") and len(body) < 1_000_000
            assert not any(part in ("venv", "venvs", ".venv", "__pycache__") for part in path.parts)
            additions[relative] = body
    manifest = {"version": 1, "scope": "85075ce3停止の状態別実現差補助と不足参照コードだけの保存",
                "状態別停止SHA256": STOP_SHA,
                "既存ZIP": {"path": BASE.relative_to(ROOT).as_posix(), "SHA256": BASE_SHA, "コードentry": 427, "manifest込みentry": 428},
                "追加entry": {name: row(body) for name, body in additions.items()}, "既存entry再用": reused,
                "既存全entry読戻し": {"数": 428, "全CRC一致": True, "SHA_CRC一覧のSHA256": sha(json.dumps(base_rows, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode())},
                "復元": "追加ZIPはFutureSignalResearch rootへ展開する。既存ZIPの元配置を保持する。",
                "別参照": {"人工と固定入力のSHA": stopped["入力SHA256前後"], "非同梱": "人工の元停止/S16/完全24本文、実Native、Tape、Raw。停止metadataが出典であり本ZIPから成功を補完しない。"},
                "未実施": {"市場実行": 0, "金融再生": 0, "市場Native_Raw_Tape本文読取": 0, "実HTTP": 0, "正式変更": 0, "既存ZIP変更": 0}}
    manifest_path = HERE / "状態別追加コード.manifest.json"
    save_new(manifest_path, manifest)
    additions[manifest_path.relative_to(ROOT).as_posix()] = manifest_path.read_bytes()
    output = HERE / "状態別追加コード.zip"
    with ZipFile(output, "x", compression=ZIP_DEFLATED, compresslevel=9) as target:
        for name, body in sorted(additions.items()):
            info = ZipInfo(name, (1980, 1, 1, 0, 0, 0))
            info.compress_type = ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            target.writestr(info, body, compress_type=ZIP_DEFLATED, compresslevel=9)
    checked = {}
    with ZipFile(output) as target:
        assert len(target.infolist()) == len(additions) and set(target.namelist()) == set(additions)
        for info in target.infolist():
            body = target.read(info.filename)
            assert body == additions[info.filename] and binascii.crc32(body) & 0xffffffff == info.CRC
            checked[info.filename] = row(body)
    after = {path: sha(Path(path).read_bytes()) for path in before}
    assert before == after and sha(BASE.read_bytes()) == BASE_SHA and sha(STOP.read_bytes()) == STOP_SHA
    receipt = {"成功": True, "scope": "状態別補助のコード保存のみ。新しい市場診断/金融/HTTP成功を追加しない",
               "停止SHA256": STOP_SHA, "追加ZIP": {"path": output.relative_to(ROOT).as_posix(), **row(output.read_bytes()), "entry数": len(checked)},
               "manifestSHA256": sha(manifest_path.read_bytes()), "全entrySHA_CRC": checked, "全entry読戻しSHA_CRC一致": True,
               "既存entry再用数": len(reused), "既存428entrySHA_CRC一致": True, "既存ZIP前後SHA256": BASE_SHA,
               "入力SHA256前": before, "入力SHA256後": after, "前後不変": True,
               "実市場_金融再生_HTTP": 0, "正式変更": 0, "原板_Tape_Native本文読取": 0}
    receipt_path = HERE / "状態別追加コードの保存確認.json"
    save_new(receipt_path, receipt)
    print(json.dumps({"成功": True, "ZIP_SHA256": sha(output.read_bytes()), "manifest_SHA256": sha(manifest_path.read_bytes()),
                      "保存確認_SHA256": sha(receipt_path.read_bytes()), "entry": len(checked), "既存再用": len(reused)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
