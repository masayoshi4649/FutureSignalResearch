"""停止S16と実在P0を含む完全人工24から初回分類と実現差分解を確認する。"""

import copy
from decimal import Decimal
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def module(name: str, path: Path):
    """
    機能: 今回の小型記述器を明示importする。
    引数: name(str)、path(Path)は識別と対象。
    返り値: moduleは金融を再生しない診断口。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    sys.modules[name] = value
    spec.loader.exec_module(value)
    return value


def main() -> None:
    """
    機能: 最初の実要求・当時窓/予約と同実入口の記述集計を人工で確認する。
    引数: なし。市場入力引数を持たない。
    返り値: None。
    """
    diag = module("短秒状態別人工", HERE / "状態別に集計する.py")
    guard = module("短秒状態別metadata人工", HERE / "実行前固定を確認する.py")
    root16 = ROOT / "work/短秒複合退出の金融"
    finance_stop = root16 / "停止.json"
    runtime_root = ROOT / "work/短秒複合退出の再生"
    runtime_stop = runtime_root / "停止.json"
    assert diag.digest(finance_stop) == "f3606e629a84df0530266d6c43fc89d48df87985841baaaeb0c1471ec6046501"
    assert diag.digest(runtime_stop) == "ff571dba63a439e9df2fc855f722da1e506ee26cc1ef483de9aa4356e39e2eb7"
    fstop, rstop = json.loads(finance_stop.read_bytes()), json.loads(runtime_stop.read_bytes())
    before = {str(finance_stop): diag.digest(finance_stop), str(runtime_stop): diag.digest(runtime_stop)}
    by_side, fixtures, shape, pure_count = {}, {}, [], 0
    for side in (1, -1):
        books = {}
        for path in sorted((root16 / "人工/公開型16").glob(f"方向{side}_*.json")):
            h = diag.digest(path)
            # 元停止は所有相対pathを固定する。元金融の再運転は行わない。
            expected = fstop["全所有SHA256"][str(path.relative_to(root16))]
            assert h == expected
            before[str(path)] = h
            value = json.loads(path.read_bytes(), parse_float=Decimal)
            book = value["book"]
            books[book["key"]] = book
            fixtures[book["key"], side] = value
            if book["key"].startswith("S5Q_"):
                p = book["positions"][0]
                o = diag.first_request(book, p)
                calls = [call for call in value["calls"] if call["input"] is not None and call["input"]["snapshot_id"] == o["short_exit_point"]["candidate"]["snapshot_id"]]
                assert len(calls) == 1
                actual = diag.PURE.assess(diag.pure_value(calls[0]["input"]), side, "S5Q")
                assert actual == diag.pure_value(o["short_exit_point"]["assessment"])
                pure_count += 1
                assert any(call["candidates"] and call["at"] < o["request_time"] for call in value["calls"])
        by_side[side] = books
        row = diag.diagnose_case(books[next(iter(books))]["session"]["id"], books)
        assert sum(pair["測定"] for pair in row["比較"]) == 4
    # ----------------------------------------
    full_details = []
    for side in (1, -1):
        path = runtime_root / f"人工/完全接続/方向{side}.json"
        h = diag.digest(path)
        assert h == rstop["全所有SHA256"][str(path.relative_to(runtime_root))]
        before[str(path)] = h
        value = json.loads(path.read_bytes(), parse_float=Decimal)
        books = value["output"]["result"]["books"]
        for key, original in by_side[side].items():
            a, b = diag.compact_book(original), diag.compact_book(books[key])
            pa, pb = next(iter(a["positions"].values())), next(iter(b["positions"].values()))
            assert pa["source"] == pb["source"] and diag.SAVE.entry_fingerprint(pa, a["orders"]) == diag.SAVE.entry_fingerprint(pb, b["orders"])
            shape.append({"side": side, "key": key, "Source出生全文同体": True, "実入口全文同体": True,
                          "Book全文同体": original == books[key], "由来差": "SnapshotID命名と入口stubのID/理由。Bookを正規化せず各人工内で比較"})
        result = diag.diagnose_case(value["tape"]["session"]["id"], books)
        assert len(result["初回観測"]) == 4 and len(result["比較"]) == 8 and all(pair["測定"] for pair in result["比較"])
        assert all(row["先行予約枚"] == {"Source": 3, "P0": 0, "S": 0} and row["S要求枚"] == 5 and row["S前既返済枚"] == 0 for row in result["初回観測"])
        full_details.append(result)
    # ----------------------------------------
    fixture = fixtures["S5Q_E3S_B5Q_P0_C0_D0", 1]
    book = fixture["book"]
    position = book["positions"][0]
    order = diag.first_request(book, position)
    original_input = next(call["input"] for call in fixture["calls"] if call["input"] is not None and call["input"]["snapshot_id"] == order["short_exit_point"]["candidate"]["snapshot_id"])
    labels = []
    for label, speed in (("反対", -1), ("0", 0), ("同方向", 1), ("S515Q必要未知", None)):
        incoming = diag.pure_value(copy.deepcopy(original_input))
        window = incoming["current"]["short"]["fifteen"]
        window["known"] = speed is not None
        if speed is not None:
            window["speed"], window["move"] = speed, speed * window["elapsed"]
        assessment = diag.PURE.assess(incoming, 1, "S5Q")
        assert assessment["decision"]["allowed"] is True
        observed = diag.classify_fifteen({"candidate": diag.pure_value(order["short_exit_point"]["candidate"]), "assessment": assessment})
        assert observed["15秒状態"] == label
        labels.append(label)
    assert [diag.unit_state(value) for value in (Decimal("-.5"), Decimal(0), Decimal(".5"))] == ["負", "0", "正"]
    rejected = []
    for label, change in (("S要求量改変", lambda b: next(o for o in b["orders"] if "short_exit_point" in o).__setitem__("quantity", 8)),
                          ("15秒根拠の符号改変", lambda b: next(o for o in b["orders"] if "short_exit_point" in o)["short_exit_point"]["assessment"]["evidence"]["fifteen"].__setitem__("signed_speed", 1)),
                          ("同秒次Lineの未来fillを前行へ移す", lambda b: next(f for f in b["fills"] if f["action"] == "close")["quote"].__setitem__("index", order["request_quote"]["index"]))):
        changed = copy.deepcopy(book)
        change(changed)
        try:
            diag.observe_request(changed, changed["positions"][0], diag.first_request(changed, changed["positions"][0]))
        except (ValueError, AssertionError):
            rejected.append(label)
        else:
            raise AssertionError("破損を受理:" + label)
    changed_books = copy.deepcopy(by_side[1])
    changed_books["S515Q_E3S_B5Q_P0_C0_D0"]["positions"][0]["entry_quote"]["source_line"] += 1
    changed_result = diag.diagnose_case(book["session"]["id"], changed_books)
    changed_pair = next(pair for pair in changed_result["比較"] if pair["比較先key"] == "S515Q_E3S_B5Q_P0_C0_D0")
    assert changed_pair["参加差分解"]["取得変更"] == 1 and changed_pair["同実入口の状態別"] == {}
    template = {"version": 1, "試行": 101, "固定": False, "stage": "full54", "scope": guard.SCOPE,
                **{name: {"path": "", "sha256": ""} for name in ("condition", "financial", "independent", "saved", "result", "saved_code")}}
    template_path = HERE / "Root診断固定_雛形.json"
    template_path.write_text(json.dumps(template, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    cli = subprocess.run([sys.executable, "-B", "-X", "utf8", str(HERE / "状態別に集計する.py"), "--fixed", str(template_path), "--fixed-sha", diag.digest(template_path), "--out", str(HERE / "未生成市場結果")], capture_output=True, text=True, encoding="utf-8")
    assert cli.returncode != 0 and "診断の実成功が未固定" in cli.stderr and not (HERE / "未生成市場結果").exists()
    assert all(diag.digest(Path(path)) == sha for path, sha in before.items())
    result = {"成功": True, "scope": "停止S16/停止完全24の保存値と純窓式の準備だけ。再金融/市場0", "S16会計": 16,
              "S5Q全純式再確認": pure_count, "完全人工Book": 24, "実在P0を含む比較": 16, "初回実要求分類": 8,
              "Source先行予約と同秒次Line未解放": True, "15秒分類境界": labels, "u符号3境界": True,
              "実入口変更を出口差から分離": True, "狭い破損拒否": rejected, "CLI未固定拒否": cli.returncode,
              "S16と完全人工の対応": shape, "入力SHA256前後": before, "前後不変": True,
              "details": full_details, "市場独立例数の推定": False, "市場54_Native_Raw_再金融_退出後価格_MFE_機会損失": 0}
    diag.SAVE.BASE.write_json(HERE / "人工確認.json", result)
    (HERE / "人工結果.md").write_text(diag.render(result), encoding="utf-8", newline="\n")
    print(json.dumps({"成功": True, "S16": 16, "完全人工": 24, "比較": 16, "初回分類": 8, "人工確認SHA256": diag.digest(HERE / "人工確認.json")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
