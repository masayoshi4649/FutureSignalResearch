"""状態別診断を同条件のfull54金融・独立・保存成功へ結ぶmetadata guard。"""

from datetime import date, timedelta
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
SCOPE = "101の同実入口の初回S5Q要求状態別実現差を固定成功後だけ記述する"


def need(value, message: str) -> None:
    """
    機能: 不一致や未固定を例外として停止する。
    引数: value(bool)、message(str)は条件と理由。
    返り値: None。
    """
    if not value:
        raise ValueError(message)


def digest(path: Path) -> str:
    """
    機能: 明示metadata又は許可新Nativeの指紋を得る。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate(value: dict) -> None:
    """
    機能: 準備雛形や別scopeを市場Native前に拒否する。
    引数: value(dict)はRootが固定する宣言。
    返り値: None。
    """
    refs = {"condition", "financial", "independent", "saved", "result", "saved_code"}
    need(set(value) == refs | {"version", "試行", "固定", "stage", "scope"}, "診断固定全tag")
    need(type(value["version"]) is int and value["version"] == 1 and type(value["試行"]) is int and value["試行"] == 101
         and value["固定"] is True and value["stage"] == "full54" and value["scope"] == SCOPE, "診断の実成功が未固定")
    for name in refs:
        row = value[name]
        need(type(row) is dict and set(row) == {"path", "sha256"} and type(row["path"]) is str and bool(row["path"])
             and re.fullmatch("[0-9a-f]{64}", row["sha256"] or ""), "未確定診断入力:" + name)


def prepare(fixed_path: Path, fixed_sha: str, output: Path) -> tuple:
    """
    機能: 同条件full54/648・全NativeSHA・保存結果の実成功後だけ読取対象を作る。
    引数: fixed_path/output(Path)、fixed_sha(str)はRoot固定/新規先/実SHA。
    返り値: tupleはtasks、前指紋、結果へ残す結合指紋。
    """
    need(re.fullmatch("[0-9a-f]{64}", fixed_sha or ""), "Root診断固定SHA未指定")
    fixed_path = fixed_path.resolve()
    need(digest(fixed_path) == fixed_sha, "Root診断固定SHA差")
    value = json.loads(fixed_path.read_text(encoding="utf-8"))
    validate(value)
    need(not output.exists(), "新規診断出力だけ")
    before, refs, bodies = {str(fixed_path): fixed_sha}, {}, {}
    for name in ("condition", "financial", "independent", "saved", "result", "saved_code"):
        ref = value[name]
        path = Path(ref["path"])
        path = (path if path.is_absolute() else fixed_path.parent / path).resolve()
        need(path.is_file() and digest(path) == ref["sha256"], "Root診断FileRef差:" + name)
        before[str(path)] = ref["sha256"]
        refs[name] = path
        if name != "saved_code":
            bodies[name] = json.loads(path.read_text(encoding="utf-8"))
    condition, financial, audit, saved, result = (bodies[name] for name in ("condition", "financial", "independent", "saved", "result"))
    condition_sha = value["condition"]["sha256"]
    need(condition["試行"] == 101 and condition["市場損益を開く前の固定"] is True, "固定101条件")
    keys = [prefix + f"E3S_B5Q_P0_C{cost}_D{delay}" for prefix in ("", "S5Q_", "S515Q_") for cost in (0, 5) for delay in (0, 1)]
    need(condition["全12Key"] == financial["全12Key"] == keys, "101同じ本名12口座")
    need(financial["成功"] is True and financial["試行"] == 101 and financial["stage"] == "full54"
         and financial["条件SHA256"] == condition_sha and financial["前後不変"] is True
         and financial["入力前SHA256"] == financial["入力後SHA256"]
         and all(financial[name] is False for name in ("source_reexecuted", "features_recomputed", "charts_recomputed"))
         and financial["Raw読取"] == 0, "金融full54未完")
    sessions, cursor = [], date(2026, 9, 21)
    while cursor <= date(2026, 10, 27):
        if cursor.weekday() < 5:
            sessions.extend(cursor.isoformat() + "_" + kind for kind in ("Day", "Night"))
        cursor += timedelta(days=1)
    tasks = financial["結果"]
    need(len(tasks) == 54 and [row["session"] for row in tasks] == sessions and all(row["books"] == 12 and row["p0_books"] == 4 for row in tasks), "同54金融完全12")
    need(audit["成功"] is True and audit["stage"] == "full54" and audit["sessions"] == sessions and audit["条件SHA256"] == condition_sha
         and audit["金融完了SHA256"] == value["financial"]["sha256"] and audit["新会計数"] == 648
         and audit["新P0独立全文会計"] == audit["旧100P0独立全文会計"] == 216 and audit["不一致数"] == 0
         and audit["前後不変"] is True and audit["入力SHA256前"] == audit["入力SHA256後"]
         and audit["Source再形成"] is False and audit["特徴チャート再計算"] is False, "独立full54未完")
    need(saved["成功"] is True and saved["stage"] == "full54" and saved["場数"] == 54 and saved["会計数"] == 648 and saved["前後不変"] is True
         and saved["条件SHA256"] == condition_sha and saved["金融完了SHA256"] == value["financial"]["sha256"]
         and saved["独立金融監査SHA256"] == value["independent"]["sha256"] and saved["結果SHA256"] == value["result"]["sha256"]
         and saved["集計コードSHA256"] == value["saved_code"]["sha256"], "保存full54未完")
    need(result["試行"] == 101 and result["成功"] is True and result["scope"] == "正式" and result["場数"] == 54 and result["Actor数"] == 12 and result["会計数"] == 648, "保存結果scope")
    need(all(result[name] == saved[name] for name in ("条件SHA256", "金融完了SHA256", "独立金融監査SHA256", "集計コードSHA256")), "結果と保存完了の同条件")
    native_map = {row["session"]: row["native_sha256"] for row in saved["Native参照"]}
    need(len(saved["Native参照"]) == 54 and native_map == {row["session"]: row["sha256"] for row in tasks}, "全Native54SHA結合")
    need([row["session"] for row in audit["details"]] == sessions, "独立details完全54")
    for task, detail in zip(tasks, audit["details"]):
        path = Path(task["path"]).resolve()
        need(path.name == task["session"] + ".json.gz" and re.fullmatch("[0-9a-f]{64}", task["sha256"]), "新Native名とSHA")
        need(detail["成功"] is True and detail["前後不変"] is True and detail["入力SHA256"].get(str(path)) == task["sha256"]
             and audit["入力SHA256前"].get(str(path)) == task["sha256"], "独立と金融のNative差")
        need(digest(path) == task["sha256"], "新Native現在SHA差")
        before[str(path)] = task["sha256"]
    for path in Path(__file__).parent.iterdir():
        if path.is_file() and path.suffix in (".py", ".md"):
            before[str(path.resolve())] = digest(path)
    proofs = {"Root診断固定SHA256": fixed_sha, "条件SHA256": condition_sha, "金融完了SHA256": value["financial"]["sha256"],
              "独立金融監査SHA256": value["independent"]["sha256"], "保存完了SHA256": value["saved"]["sha256"], "保存結果SHA256": value["result"]["sha256"]}
    return tasks, before, proofs
