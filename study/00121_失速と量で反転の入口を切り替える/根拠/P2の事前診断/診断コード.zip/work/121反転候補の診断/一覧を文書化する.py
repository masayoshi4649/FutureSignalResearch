"""
P2診断JSONの全件表と既定条件の交差分解をMarkdownへ保存する。

条件・出生・約定を再計算せず、固定結果から期間所属だけを確認する。
"""

from __future__ import annotations

from collections import Counter
import hashlib
import json
from pathlib import Path
from typing import Any

from 診断する import AGGREGATE, AGGREGATE_SHA, RESULT, RESULT_SHA, describe, digest


OUT = Path(__file__).resolve().parent


# ----------------------------------------
def number(value: Any) -> str:
    """
    機能: Markdownだけの数値表示を作り、元JSONの精度は変更しない。
    引数: value(Any)は表示するscalar。
    返り値: str。未知は長音記号、実数は小数3桁以内。
    """
    if value is None:
        return '—'
    if isinstance(value, bool):
        return '有' if value else '無'
    if isinstance(value, float):
        return f'{value:.3f}'.rstrip('0').rstrip('.')
    return str(value)


# ----------------------------------------
def table(headers: list[str], rows: list[list[Any]]) -> str:
    """
    機能: 所与の行順を保ったMarkdown表を作る。
    引数: headers(list[str])、rows(list[list[Any]])。
    返り値: str型の表。セルの改行と縦棒だけを表示用に置換する。
    """
    def cells(row: list[Any]) -> str:
        """
        機能: Markdown一行の各scalarを表示する。
        引数: row(list[Any])は表の一行。
        返り値: str型のMarkdown表行。
        """
        return '| ' + ' | '.join(number(x).replace('|', '／').replace('\n', ' ') for x in row) + ' |'
    return '\n'.join([cells(headers), cells(['---'] * len(headers)), *[cells(row) for row in rows]])


# ----------------------------------------
def main() -> None:
    """
    機能: 全22件と結果を省略しない交差分解を保存し、次仮説を明記する。
    引数: なし。固定結果・固定集計・自生成の二診断JSONだけを読む。
    返り値: None。自然Raw、入力.json、11/09は読まない。
    """
    assert digest(RESULT.read_bytes()) == RESULT_SHA and digest(AGGREGATE.read_bytes()) == AGGREGATE_SHA
    original = json.loads(RESULT.read_text(encoding='utf-8'))
    data = json.loads((OUT / 'P2全件実測.json').read_text(encoding='utf-8'))
    summary = json.loads((OUT / 'P2事前条件の分解.json').read_text(encoding='utf-8'))
    rows = data['実測']
    periods = {c['birth']['id']: '既定54場' if i < 54 else '追加16場' for i, s in enumerate(original['scenes']) for c in s['candidates'] if c['policy'] == 'P2'}
    cross = {}
    for adx in (True, False, None):
        for volume in (True, False, None):
            selected = [r for r in rows if r['ADX30低下'] is adx and r['RVOL5が1以上'] is volume]
            cross[f'ADX低下={adx}/RVOL1以上={volume}'] = describe(selected)
    period_rows = {}
    for period in ('既定54場', '追加16場'):
        selected = [r for r in rows if periods[r['ID']] == period]
        period_rows[period] = {'全P2': describe(selected), 'ADX低下': describe([r for r in selected if r['ADX30低下'] is True]), 'RVOL1以上': describe([r for r in selected if r['RVOL5が1以上'] is True])}
    extra = {'参照試行': 120, '結果SHA256': RESULT_SHA, 'ADXと量の交差': cross, '既定期間の分解': period_rows, '新閾値探索': False}
    with (OUT / 'P2既定条件の交差分解.json').open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(json.dumps(extra, ensure_ascii=False, indent=2) + '\n')
    grouped = summary['事前に存在した条件による分解']
    chosen = [('全P2', summary['全P2'])]
    chosen += [(f'ADX30低下={k}', v) for k, v in grouped['ADX30低下'].items()]
    chosen += [(f'RVOL5≥1={k}', v) for k, v in grouped['RVOL5が1以上'].items()]
    chosen += [(f'Hist5改善={k}', v) for k, v in grouped['Hist5改善'].items()]
    chosen += [(f'両勢い改善={k}', v) for k, v in grouped['両方改善'].items()]
    chosen += [(f'P2plus既定3条件={k}', v) for k, v in grouped['P2plus既定3条件'].items()]
    count_table = table(['条件', '全出生', '未約定', '完了', '順行', '逆行', '未到達', '順行率%'], [[k, v['全出生'], v['未約定'], v['H60完了'], v['順行'], v['逆行'], v['未到達'], None if v['全完了順行率'] is None else 100 * v['全完了順行率']] for k, v in chosen])
    cross_table = table(['ADX30低下', 'RVOL5≥1', '全出生', '未約定', '順行', '逆行'], [[('未知' if adx is None else adx), ('未知' if volume is None else volume), cross[f'ADX低下={adx}/RVOL1以上={volume}']['全出生'], cross[f'ADX低下={adx}/RVOL1以上={volume}']['未約定'], cross[f'ADX低下={adx}/RVOL1以上={volume}']['順行'], cross[f'ADX低下={adx}/RVOL1以上={volume}']['逆行']] for adx in (True, False, None) for volume in (True, False, None)])
    technical_table = table(['No', '出生JST', '売買', '主評価', 'ADX30/前値', 'Hist増分s', 'RSI増分s', 'RVOL5', '30分MA'], [[i, r['出生日時JST'][5:19].replace('T', ' '), r['売買'], r['主評価ラベル'], f"{number(r['ADX30'])}/{number(r['前ADX30'])}", r['Hist5符号増分'], r['RSI5符号増分'], r['RVOL5'], '不一致' if r['30分配置傾き'] == '不一致' else '全て逆向き'] for i, r in enumerate(rows, 1)])
    structure_table = table(['No', '前5本Low/High', '当1分O/H/L/C', '突破深さpt', 'Close回復pt', '出生Last回復pt', '出生risk pt', '実取得risk pt', 'cap取消'], [[i, f"{number(r['イベント']['previous5range']['low'])}/{number(r['イベント']['previous5range']['high'])}", '/'.join(number(r['イベント']['bar']['ohlc'][k]) for k in ('open', 'high', 'low', 'close')), r['突破深さpt'], r['確定終値の回復pt'], r['出生Lastの回復pt'], r['出生時否定距離pt'], r['実取得の否定距離pt'], r['候補状態'] == 'entry_cap_rejected'] for i, r in enumerate(rows, 1)])
    period_table = table(['期間', '対象', '出生', '未約定', '順行', '逆行'], [[p, k, v['全出生'], v['未約定'], v['順行'], v['逆行']] for p, group in period_rows.items() for k, v in group.items()])
    text = f'''# P2の当時特徴と主評価の全件診断

2026-11-10。120の固定結果だけを再読した診断。P2は22出生、5件はentry capで取消、17約定は全て60分観測完了、±100pt先着は順行10・逆行7（58.824%）。未到達・観測不足は0で、解決済み先着率と全完了順行率は一致する。P2plusは3出生中1件cap取消、2約定2順行。2例を完成手法としない。

ここでの順行/逆行は120の事前固定した60分±100pt主評価であり、自然無効化位置によるIFD損切りや利確の実再生ではない。「不成立」を全RawでのP2不成立と読み替えない。保存された22出生の中で、主評価の順行/逆行と未約定の違いを調べている。未出生原行の当時特徴はこの結果JSONだけから復元しない。

## 当時分けられる違い

{count_table}

ADX≤25自体は14完了8順6逆（57.143%）、ADX>25で低下は3完了2順1逆（66.667%）。絶対水準で「弱い」より、直前公表から低下しているかに差が見える。ただし低下群7例は小さく、同場相関や既知データへの着目もある。未知の前ADXを低下なしへ混ぜていない。

Hist5の順側改善は5順4逆、RSI5改善と両方改善は4順3逆。この22出生ではRSI改善群が全てHist改善群に含まれた。勢いの条件を増やしたこと自体では精度改善を確認できない。RVOL5≥1の群は5順1逆だが、10出生の4件がcap取消で、約定後の6例だけの成績である。

{cross_table}

ADX低下を必須、かつRVOL≥1も必須とすれば残るのは2例で、P2plusの2勝と重なる。全条件を機械的にANDするだけでは根拠の薄い極少数へ縮む。交差表は既存のADX前回比較・RVOL1・勢い増分0を用いた記述で、新しい分割閾値を探索していない。

## 構造の違い

順行10件と逆行7件の突破深さ中央値は10pt/20pt、確定終値回復中央値は25pt/20pt。出生risk中央値は両方45pt、ATR5比中央値も0.324/0.328で大きく重なる。実取得risk中央値も両方45pt。今回の中央値から「深さは何ptまで」と採用閾値を逆算しない。個々の重なりは下表と実測JSONに残した。

30分EMA配置と両傾きが新規方向へ一致する出生は0。21出生は3条件とも逆向きで、その約定16件は9順7逆。残る1出生は配置と傾き不一致で1順。上位MAを同方向必須にするだけでは反転候補がなくなる。反転では元トレンドが弱まったかと、失敗突破からの回復を別に判定する必要がある、という次仮説につながる。

## 期間の偏り

{period_table}

54/16は以前から使う期間区分のままで、未知テストとはしない。全70場を既に利用している。好成績の小群が前半へ偏る場合は、その率を次の場へ保証しない。

## 全22出生：技術票

符号sは買い+1、売り−1。Hist/RSI増分の正は新規方向への改善。日時は出生RawのJST。詳細Fields、参照公表Ref、Raw index/物理行は[P2全件実測](P2全件実測.json)に保存。

{technical_table}

## 全22出生：1分構造と取得制限

突破深さは前5本の逆側端から当1分極値まで、回復は同じ端から終値/出生Lastまでの順側距離。riskは当1分逆側極値の外5ptからの距離。cap取消5件はその後の仮想先着で採点せず、利益0にも置換しない。

{structure_table}

## 121へ向けた仮説案（未実行）

候補出生を「BB/RSIが極端」の条件から、前5本1分の失敗突破と回復維持へ広げる。120の同構造・TR制限・出生Last/実行Lastのhold・cap・自然否定距離・売買対称を固定対照として残す。BB/RSIはその出生の背景分類とし、極端が必須な旧P2と分母を分ける。

切替仮説は、失敗突破に対して、長期ADXが低下する失速経路と、直近RVOL≥1で参加が増す経路を分けること。ADXが25以下でも上昇中なら、トレンド発生途中への逆張りかを警戒する。ADX低下と量を同時必須にする対照、各経路の対照、両経路以外を待つ対照を事前固定し、結果を見た最良セルだけで70%を宣言しない。

5分Hist/RSIは水準と改善を診断に残し、両方改善必須の旧P2plusを固定対照にする。1分回復時点では5分確認が未成立でも勝っていた例があるため、全出生の必須ゲートとして増やす案と、別候補として後の確認を待つ案を区別する。後の確認候補は新しい出生/取得時計を持つので同母集団の効果と混同しない。

これは120を見た探索仮説であり、85.7%/83.3%や2勝0敗を未知場へ移した証拠はない。次試行の条件固定と実再生を必要とする。利益追尾、IFD/逆指値、費用、実約定の検証も別に必要である。

## 入力と再現

- 許可入力：120固定結果 `e61846c01ff849fa132697dc456dfed32a8b470697286620d1c28a5f0925a4d6` と固定集計 `bb6c0b4248e74244bca6e5809c6b49e17ff0cac1d01af7cb8f1471a0feec7fff` の二JSON。
- [事前条件の分解](P2事前条件の分解.json)、[交差分解](P2既定条件の交差分解.json)、[確認](確認.json)。生成は`診断する.py`→`一覧を文書化する.py`。各新規出力は上書きを拒否する。
- 自然Raw・入力.json・11/09は未読。120の既定コード・結果を変更せず、指標や注文を再生していない。
'''
    with (OUT / 'README.md').open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(text)
    assert digest(RESULT.read_bytes()) == RESULT_SHA and digest(AGGREGATE.read_bytes()) == AGGREGATE_SHA
    print(json.dumps({'期間分解': period_rows, 'README_SHA256': digest((OUT / 'README.md').read_bytes()), '交差SHA256': digest((OUT / 'P2既定条件の交差分解.json').read_bytes())}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
