"""
120の固定結果だけからP2の当時特徴と60分±100pt先着を分解する。

自然Raw、入力.json、11/09は読まず、閾値探索と売買再生は行わない。
"""

from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone, timedelta
import hashlib
import json
from pathlib import Path
from statistics import median
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
RESULT = ROOT / 'work/120入口比較/全70場の入口結果.json'
AGGREGATE = ROOT / 'work/120入口比較/集計.json'
RESULT_SHA = 'e61846c01ff849fa132697dc456dfed32a8b470697286620d1c28a5f0925a4d6'
AGGREGATE_SHA = 'bb6c0b4248e74244bca6e5809c6b49e17ff0cac1d01af7cb8f1471a0feec7fff'


# ----------------------------------------
def digest(data: bytes) -> str:
    """
    機能: 指定バイト列の指紋を求める。
    引数: data(bytes)は対象バイト列。
    返り値: str型のSHA256。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def value(fields: dict[str, Any], name: str) -> float | None:
    """
    機能: 保存Fieldsの既知値を取り出し、未知をNoneのまま残す。
    引数: fields(dict[str, Any])は当時票、name(str)は項目名。
    返り値: float | None。未知を0に補完しない。
    """
    item = fields.get(name, {})
    return item.get('value') if item.get('known') else None


# ----------------------------------------
def signed_delta(fields: dict[str, Any], current: str, previous: str, side: int) -> float | None:
    """
    機能: 二つとも既知の場合だけ売買符号を掛けた増分を求める。
    引数: fields(dict[str, Any])、current/previous(str)、side(int)。
    返り値: float | None型の順側増分。
    """
    now, old = value(fields, current), value(fields, previous)
    return None if now is None or old is None else side * (now - old)


# ----------------------------------------
def flag(number: float | None, threshold: float = 0, inclusive: bool = False) -> bool | None:
    """
    機能: 数値の既知性を維持して固定閾値へ比較する。
    引数: number(float | None)、threshold(float)、inclusive(bool)。
    返り値: bool | None。Noneは未判定を表す。
    """
    return None if number is None else number >= threshold if inclusive else number > threshold


# ----------------------------------------
def label(row: dict[str, Any]) -> str:
    """
    機能: 全出生を約定と固定主評価の状態へ分ける。
    引数: row(dict[str, Any])は実測1件。
    返り値: str型の順行・逆行・未到達・観測不足・未約定ラベル。
    """
    if row['候補状態'] != 'filled':
        return '未約定'
    if row['H60状態'] != 'complete':
        return '観測不足'
    return {1: '順行', -1: '逆行', 0: '未到達'}[row['H60_100pt先着']]


# ----------------------------------------
def describe(rows: list[dict[str, Any]]) -> dict[str, Any]:
    """
    機能: 一群の全出生/未約定/主評価先着の分母を省略せず集計する。
    引数: rows(list[dict[str, Any]])は所与の群。
    返り値: dict[str, Any]型の件数と二種類の率。
    """
    count = Counter(label(row) for row in rows)
    forward, adverse, untouched = (count[x] for x in ('順行', '逆行', '未到達'))
    complete, resolved = forward + adverse + untouched, forward + adverse
    return {
        '全出生': len(rows), '未約定': count['未約定'], '観測不足': count['観測不足'],
        'H60完了': complete, '順行': forward, '逆行': adverse, '未到達': untouched,
        '解決済み先着率': forward / resolved if resolved else None,
        '全完了順行率': forward / complete if complete else None,
        '元ID': [row['ID'] for row in rows],
    }


# ----------------------------------------
def make_row(scene: dict[str, Any], candidate: dict[str, Any]) -> dict[str, Any]:
    """
    機能: P2候補の当時票と保存された固定評価を対応づける。
    引数: scene(dict[str, Any])は場、candidate(dict[str, Any])はP2候補。
    返り値: dict[str, Any]型の当時特徴/主評価の実測一行。
    """
    event = scene['events'][candidate['event']]
    assert event['id'] == candidate['birth']['id'] and event['policy'] == 'P2'
    side, fields, ohlc, pr = event['side'], event['fields'], event['bar']['ohlc'], event['previous5range']
    broken = pr['low'] if side > 0 else pr['high']
    extreme = ohlc['low'] if side > 0 else ohlc['high']
    adx, prev_adx = value(fields, 'adx30'), value(fields, 'previous_adx30')
    hist = signed_delta(fields, 'hist5', 'previous_hist5', side)
    rsi = signed_delta(fields, 'rsi5', 'previous_rsi5', side)
    rvol = value(fields, 'rvol5')
    hist_ok, rsi_ok, vol_ok = flag(hist), flag(rsi), flag(rvol, 1, True)
    outcome = next((o for o in candidate['outcomes'] if o['seconds'] == 3600), None)
    touch = next((t for t in outcome['touches'] if t['width'] == 100), None) if outcome else None
    entry = candidate.get('entry_price')
    ma = [None if value(fields, k) is None else side * value(fields, k) for k in ('gap30', 'ema8_delta30', 'ema21_delta30')]
    if any(x is None for x in ma):
        alignment = '未知'
    elif all(x > 0 for x in ma):
        alignment = '配置と両傾きが同方向'
    elif all(x < 0 for x in ma):
        alignment = '配置と両傾きが逆方向'
    else:
        alignment = '不一致'
    adx_kind = '25以下' if adx is not None and adx <= 25 else '25超で低下' if adx is not None and prev_adx is not None and adx < prev_adx else '未知又は条件不一致'
    evaluation = candidate.get('evaluation')
    side_quote = None if not evaluation or not evaluation.get('quote_ok') else evaluation['ask' if side > 0 else 'bid']
    plus_peers = [e for e in scene['events'] if e['policy'] == 'P2plus' and e['side'] == side and e['at'] == event['at']]
    row = {
        '場': scene['session'], 'ID': event['id'], '出生日時JST': datetime.fromtimestamp(event['at']['time'], timezone(timedelta(hours=9))).isoformat(),
        '売買': '買い' if side > 0 else '売り', 'side': side, '候補状態': candidate['status'],
        'H60状態': outcome['status'] if outcome else None, 'H60_100pt先着': touch['direction'] if touch else None,
        '先着日時JST': touch['quote']['clock'] if touch and touch['quote'] else None,
        'H60期限清算C5円': outcome.get('net5') if outcome else None,
        'ADX30': adx, '前ADX30': prev_adx, 'ADX背景区分': adx_kind,
        'ADX30低下': None if adx is None or prev_adx is None else adx < prev_adx,
        'Hist5符号水準': None if value(fields, 'hist5') is None else side * value(fields, 'hist5'),
        'Hist5符号増分': hist, 'RSI5': value(fields, 'rsi5'), 'RSI5符号増分': rsi,
        'Hist5改善': hist_ok, 'RSI5改善': rsi_ok, '両方改善': hist_ok and rsi_ok,
        'RVOL5': rvol, 'RVOL5が1以上': vol_ok,
        'P2plus既定3条件': hist_ok is True and rsi_ok is True and vol_ok is True,
        '同時P2plusID': [e['id'] for e in plus_peers],
        '30分配置傾き': alignment, '30分符号Gap': ma[0], '30分符号EMA8傾き': ma[1], '30分符号EMA21傾き': ma[2],
        'RSI15': value(fields, 'rsi15'), 'ATR5': value(fields, 'atr5'),
        '突破深さpt': side * (broken - extreme), '確定終値の回復pt': side * (ohlc['close'] - broken),
        '出生Lastの回復pt': side * (event['at']['last'] - broken),
        '出生時否定距離pt': value(fields, 'risk_at_last'),
        '出生時否定距離_ATR5比': value(fields, 'risk_at_last') / value(fields, 'atr5'),
        '実取得の否定距離pt': None if entry is None else side * (entry - event['invalidation']),
        '実取得の回復pt': None if entry is None else side * (entry - broken),
        'cap余裕pt': side * (event['entry_cap'] - event['at']['last']),
        '評価BBOのcap超過pt': None if side_quote is None else side * (side_quote - event['entry_cap']),
        'イベント': event,
    }
    row['主評価ラベル'] = label(row)
    assert row['P2plus既定3条件'] == bool(plus_peers)
    return row


# ----------------------------------------
def metric_summary(rows: list[dict[str, Any]], keys: list[str]) -> dict[str, Any]:
    """
    機能: 閾値を探索せず、既知の連続値をラベル別の最小/中央値/最大で記す。
    引数: rows(list[dict[str, Any]])、keys(list[str])は測定項目。
    返り値: dict[str, Any]型。分位点を新しい採用閾値へ変換しない。
    """
    result = {}
    for name in ('順行', '逆行', '未約定', '観測不足', '未到達'):
        selected = [r for r in rows if r['主評価ラベル'] == name]
        result[name] = {}
        for key in keys:
            values = [r[key] for r in selected if r[key] is not None]
            result[name][key] = {'件数': len(values), '未知': len(selected) - len(values), '最小': min(values) if values else None, '中央値': median(values) if values else None, '最大': max(values) if values else None}
    return result


# ----------------------------------------
def write_new(name: str, obj: Any) -> None:
    """
    機能: 診断JSONを未作成ファイルへUTF-8で保存する。
    引数: name(str)は保存名、obj(Any)はJSON可能値。
    返り値: None。既存成果を上書きしない。
    """
    with (OUT / name).open('x', encoding='utf-8', newline='\n') as handle:
        handle.write(json.dumps(obj, ensure_ascii=False, allow_nan=False, indent=2) + '\n')


# ----------------------------------------
def main() -> None:
    """
    機能: 固定120結果と集計の二JSONだけを読み、22P2出生を全件診断する。
    引数: なし。入力パスとSHAは本コードで固定する。
    返り値: None。前後SHA一致と全件分母を検査してJSONを保存する。
    """
    raw, aggregate_raw = RESULT.read_bytes(), AGGREGATE.read_bytes()
    assert digest(raw) == RESULT_SHA and digest(aggregate_raw) == AGGREGATE_SHA
    result, aggregate = json.loads(raw), json.loads(aggregate_raw)
    assert result['trial'] == 120 and result['success'] and aggregate['元結果SHA256'] == RESULT_SHA
    rows = [make_row(s, c) for s in result['scenes'] for c in s['candidates'] if c['policy'] == 'P2']
    assert len(rows) == 22
    all_counts = describe(rows)
    assert all_counts['順行'] == 10 and all_counts['逆行'] == 7 and all_counts['未約定'] == 5 and all_counts['H60完了'] == 17
    groups = {}
    for name in ('ADX背景区分', 'ADX30低下', 'Hist5改善', 'RSI5改善', '両方改善', 'RVOL5が1以上', 'P2plus既定3条件', '30分配置傾き'):
        groups[name] = {}
        for v in dict.fromkeys(r[name] for r in rows):
            key = '未知' if v is None else str(v)
            groups[name][key] = describe([r for r in rows if r[name] == v])
    combos = {}
    for r in rows:
        key = f"Hist改善={r['Hist5改善']}/RSI改善={r['RSI5改善']}/RVOL1以上={r['RVOL5が1以上']}"
        combos.setdefault(key, []).append(r)
    groups['既定追加条件の組'] = {k: describe(v) for k, v in combos.items()}
    metrics = ['ADX30', 'Hist5符号増分', 'RSI5符号増分', 'RVOL5', '突破深さpt', '確定終値の回復pt', '出生Lastの回復pt', '出生時否定距離pt', '出生時否定距離_ATR5比', '実取得の否定距離pt', '実取得の回復pt', 'cap余裕pt', '30分符号Gap']
    summary = {'試行参照': 120, '主評価': '60分±100pt・完全観測', '固定結果SHA256': RESULT_SHA, '全P2': all_counts, '事前に存在した条件による分解': groups, '連続値の記述統計': metric_summary(rows, metrics), '新閾値探索': False, '相関と個別効果の区別': '同じ22出生の条件で分解した記述であり因果効果や未知場の精度を証明しない'}
    assert digest(RESULT.read_bytes()) == RESULT_SHA and digest(AGGREGATE.read_bytes()) == AGGREGATE_SHA
    write_new('P2全件実測.json', {'試行参照': 120, '件数': len(rows), '入力SHA256': RESULT_SHA, '実測': rows})
    write_new('P2事前条件の分解.json', summary)
    write_new('確認.json', {'成功': True, '入力': {str(RESULT): RESULT_SHA, str(AGGREGATE): AGGREGATE_SHA}, '入力前後不変': True, 'P2全出生': len(rows), '主評価件数': all_counts, 'P2plus同時出生と既定票の一致': True, '自然Raw/入力/11月09読取': 0, '閾値探索': False, '金融再生': False, 'コードSHA256': digest(Path(__file__).read_bytes())})
    print(json.dumps({'全P2': all_counts, '群別': groups, '連続値': summary['連続値の記述統計']}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
