"""結果を読む前に121の入口条件と実行コードを固定する。"""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 全bytesのSHA256を計算する。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 実行前文書・入力・コード・ビルド済み実行体をF1へ固定する。
    引数: なし。返り値: None。自然結果が存在する場合は拒否する。
    """
    assert not (OWN / '全70場の入口結果.json').exists()
    study = ROOT / 'study/00121_失速と量で反転の入口を切り替える'
    code = []
    for folder in (OWN, ROOT / 'work/121入口の反転切替', ROOT / 'work/118複数技法の入口条件', ROOT / 'work/120入口の1分構造'):
        code.extend(folder.rglob('*.go'))
        code.append(folder / 'go.mod')
    code.extend(OWN / p for p in ('実行する.py', '集計する.py', '条件を固定する.py', '対照を照合する.py'))
    input_path = ROOT / 'work/118入口比較/入力.json'
    input_sha = '574771f654937036b48c78eceadb46a4c5ff3c10265f60b0ec7879efb0d862c3'
    assert sha(input_path) == input_sha
    docs = [study / '実行前原文' / name for name in ('README.md', '設定と結果.md')]
    assert all(sha(p) == sha(study / p.name) for p in docs)
    condition = {'trial':121,'fixed':True,'source_signals_used':False,'policies':['C0','E0','V0','EV','B0','B1'],'independent_mini_quantity':1,'portfolio_pnl':False,'target':'同幅先着70%以上を目指す入口精度。未到達・観測不足・少数例を別記。IFD実約定未検証。','horizons_seconds':[1800,3600],'widths_points':[25,50,100,125,200],'signal_source':'確定1分の回復又は突破。未確定足完成形なし。','same_policy_side_cooldown_seconds':300,'maximum_structure_risk':'min(100pt,.5ATR5)','entry_cap':'1分終値±min(10pt,.15ATR5)。初回正常BBOで不適なら即取消。','market_order_seconds':30,'delay_seconds':1,'normal_bbo_gap_seconds':300,'endpoint_grace_seconds':30,'fee_round_yen':77,'slip_stress_round_yen':[0,1000],'new_entry_clock':'原行から形成した確定1分構造。Source新規・取消・旧出口を候補出生に使わない。','new_entry_end':'SourceのForceClose未満','observation_end':'Session.Endまで。期限到達の最初の正常原行で終え、同秒後続原行を混ぜない。','known_sessions':70,'out_of_sample':False,'11月09読取':False,'input':{'path':str(input_path),'sha256':input_sha},'code_sha256':{str(p):sha(p) for p in sorted(set(code))},'premarket_documents':{str(p):sha(p) for p in docs},'executable':{'path':str(OWN / '入口比較.exe'),'sha256':sha(OWN / '入口比較.exe')},'Go_version':subprocess.check_output(['go','version'],text=True).strip()}
    condition['structure_hold'] = '全政策で出生と取得評価のLastが前5本逆側境界から側5pt以上を維持。最初の正常BBOでcap→hold→risk、拒否後に待たない。'
    condition['minute_raw_gap_reset_seconds'] = 60
    condition['cohort'] = 'C0の出生/冷却からE0/V0/EVを同原行派生、B1の出生/冷却からB0を同原行派生。将来約定結果を出生へ返さない。'
    condition['source_control'] = 'C0を120P2の22出生17取得へ全件対応させ、共通event情報・要求・状態・取得・期限評価が同体かを検査する。'
    condition['hypothesis_status'] = '120既知結果の診断後に立てた探索仮説。ADX低下の7例は元54場6順0逆/追加16場0順1逆。未知再現性は未証明。'
    condition['primary_metric'] = {'horizon_seconds': 3600, 'symmetric_width_points': 100, 'target_favorable_first_rate': 0.70}
    path = OWN / 'F1.json'
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(condition,ensure_ascii=False,indent=2)+'\n')
    with (OWN / 'F1.sha256').open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(sha(path)+'\n')
    print(json.dumps({'固定':True,'F1_SHA256':sha(path),'コード数':len(condition['code_sha256'])},ensure_ascii=False))


if __name__ == '__main__':
    main()
