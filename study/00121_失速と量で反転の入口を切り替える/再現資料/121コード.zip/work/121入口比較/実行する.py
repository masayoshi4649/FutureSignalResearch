"""実行前に固定した121の条件・コードと入力を認証する。"""
from pathlib import Path
import hashlib
import json
import subprocess

OWN = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: ファイルの全bytesの指紋を計算する。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: F1を照合して70場を新規保存先へ一度実行する。
    引数: なし。返り値: None。Source通知を出生に使わない。
    """
    fixed = OWN / 'F1.json'
    seal = (OWN / 'F1.sha256').read_text(encoding='utf-8').strip()
    assert sha(fixed) == seal
    condition = json.loads(fixed.read_text(encoding='utf-8'))
    assert condition['fixed'] and condition['trial'] == 121 and not condition['source_signals_used']
    before = dict(condition['code_sha256'])
    before[condition['input']['path']] = condition['input']['sha256']
    before[condition['executable']['path']] = condition['executable']['sha256']
    before.update(condition['premarket_documents'])
    assert all(sha(Path(p)) == expected for p, expected in before.items())
    output = OWN / '全70場の入口結果.json'
    assert not output.exists() and not (OWN / '全70場の完了.json').exists()
    command = [condition['executable']['path'], '--input', condition['input']['path'], '--sha256', condition['input']['sha256'], '--output', str(output), '--workers', '8']
    process = subprocess.run(command, cwd=OWN, check=False)
    assert process.returncode == 0, '失敗を完了扱いしない'
    after = {p: sha(Path(p)) for p in before}
    assert before == after and sha(fixed) == seal
    value = json.loads(output.read_text(encoding='utf-8'))
    assert value['success'] and value['trial'] == 121 and value['input_sha256'] == condition['input']['sha256']
    assert not value['source_signals_used'] and len(value['scenes']) == 70
    assert all(s['success'] and not s['source_signals_used'] for s in value['scenes'])
    zones = sum(len(s['events']) for s in value['scenes'])
    cases = sum(len(s['candidates']) for s in value['scenes'])
    assert cases == zones
    subprocess.run(['python','-X','utf8',str(OWN / '対照を照合する.py')],cwd=OWN,check=True)
    proof = {'試行': 121, '成功': True, 'F1_SHA256': seal, '入力コード前SHA256': before, '入力コード後SHA256': after, '前後不変': True, '場数': 70, '構造出生数': zones, '政策別候補数': cases, '結果': {'path': str(output), 'sha256': sha(output)}, '単位': '独立1mini入口試験、口座収支ではない', 'コマンド': command, '条件変更': False, '11月09読取': False, 'Source通知使用': False}
    with (OWN / '全70場の完了.json').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'成功': True, '出生': zones, '候補数': cases, '結果SHA256': sha(output), '完了SHA256': sha(OWN / '全70場の完了.json')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
