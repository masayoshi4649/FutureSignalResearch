"""121の人工検査版と現コード・実行前文書を市場実行前に照合する。"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: ファイルの全bytes指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 純条件・執行・固定参照・原文の同体を確認して新規証跡へ保存する。
    引数: なし。返り値: None。自然Raw・入力本文・121結果を読まない。
    """
    first = ROOT/'work/121入口の反転切替/検査/確認.json'
    assert sha(first)=='be14d71916516713ba67a717631eaf327a828b8685242ad6e0c3148a2689ca03'
    pure=json.loads(first.read_text(encoding='utf-8'))
    sources=dict(pure['所有ファイルSHA256'])
    for ref in pure['固定参照'].values():
        sources.update(ref['source'])
    assert all(sha(Path(p))==expected for p,expected in sources.items())
    second=ROOT/'work/121入口実装検査/確認.json'
    runner=json.loads(second.read_text(encoding='utf-8'))
    assert runner['成功']
    for ref in runner['コード']:
        path=ROOT/ref['path']
        assert sha(path)==ref['sha256'] and path.stat().st_size==ref['bytes'],ref['path']
    study=ROOT/'study/00121_失速と量で反転の入口を切り替える'
    expected_docs={'README.md':'c062b969229890f5b09169d641d1adac24596ad6aec8b2799a0790dc046292be','設定と結果.md':'e224a9eb829d2c52fa5dbd9fa7874017b543ccc4d8f0174dabd5ac0f4b45b68e'}
    for name,expected in expected_docs.items():
        assert sha(study/name)==sha(study/'実行前原文'/name)==expected
    proof={'成功':True,'試行':121,'純条件証跡SHA256':sha(first),'執行証跡SHA256':sha(second),'参照ソース全同体':True,'実行前原文SHA256':expected_docs,'入力Raw121市場結果読取':False}
    with (OWN/'実行前照合.json').open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
