"""121の固定対照と共有出生が120の入口時計を保つことを確認する。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent


def sha(value: bytes) -> str:
    """
    機能: bytes指紋を求める。
    引数: value(bytes)。返り値: strはSHA256。
    """
    return hashlib.sha256(value).hexdigest()


def main() -> None:
    """
    機能: 全C0を旧P2と、全派生を基礎cohortと対照し、相違を拒否する。
    引数: なし。返り値: None。Rawや新指標を読まず保存結果だけを比較する。
    """
    old_path = ROOT / 'study/00120_1分構造と無効化距離で入口を作る/成果物/全70場の入口結果.json.gz'
    new_path = OWN / '全70場の入口結果.json'
    old_bytes = old_path.read_bytes()
    decoded = gzip.decompress(old_bytes)
    assert sha(decoded) == 'e61846c01ff849fa132697dc456dfed32a8b470697286620d1c28a5f0925a4d6'
    new_bytes = new_path.read_bytes()
    old, new = json.loads(decoded), json.loads(new_bytes)
    assert old['success'] and old['trial']==120 and new['success'] and new['trial']==121
    old_rows, new_rows = {}, {}
    keep = ['request','expires','entry','entry_price','outcomes','last_normal_time','status','limit','entry_cap','invalidation','atr5','maximum_risk','risk_at_decision','evaluation','hold_boundary','hold_minimum','hold_strict']
    for scene in old['scenes']:
        for c in scene['candidates']:
            if c['policy']!='P2':
                continue
            e=scene['events'][c['event']]
            key=(scene['session'],c['birth']['side'],e['bar']['end'])
            assert key not in old_rows
            old_rows[key]=(c,e)
    subset_counts={p:0 for p in ('E0','V0','EV','B0')}
    for scene in new['scenes']:
        bases={c['cohort_id']:c for c in scene['candidates'] if c['policy'] in ('C0','B1')}
        for c in scene['candidates']:
            e=scene['events'][c['event']]
            assert c['cohort_id']==e['cohort_id']
            if c['policy']=='C0':
                key=(scene['session'],c['birth']['side'],e['bar']['end'])
                assert key not in new_rows
                new_rows[key]=(c,e)
            else:
                base=bases[c['cohort_id']]
                expected='B1' if c['policy']=='B0' else 'C0'
                if c['policy']=='B1':
                    continue
                assert base['policy']==expected and base['birth']['side']==c['birth']['side']
                b_event=scene['events'][base['event']]
                for field in ('at','bar','previous5range','refs','entry_cap','invalidation'):
                    assert e[field]==b_event[field], (c['policy'],field)
                assert all(c[field]==base[field] for field in keep), c['policy']
                subset_counts[c['policy']]+=1
    assert set(old_rows)==set(new_rows) and len(old_rows)==22
    for key,(c,e) in new_rows.items():
        other,event=old_rows[key]
        assert all(c[field]==other[field] for field in keep), key
        for field in ('at','bar','previous5range','refs','entry_cap','invalidation'):
            assert e[field]==event[field], (key,field)
        for field,value in event['fields'].items():
            assert e['fields'][field]==value, (key,field)
    assert sum(c['entry'] is not None for c,_ in new_rows.values())==17
    assert old_path.read_bytes()==old_bytes and new_path.read_bytes()==new_bytes
    proof={'成功':True,'試行':121,'旧展開結果SHA256':sha(decoded),'旧圧縮SHA256':sha(old_bytes),'新結果SHA256':sha(new_bytes),'C0_P2全出生対応':22,'C0_P2全取得対応':17,'共通要求取得期限値同体':True,'派生全出生同体':subset_counts,'将来約定での出生選別':False,'自然Raw読取':False,'11月09読取':False}
    with (OWN/'対照の確認.json').open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
