"""120P2の保存値診断を121の事前根拠として少量保管する。"""
from pathlib import Path
import hashlib
import io
import json
import zipfile

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / 'work/121反転候補の診断'
DEST = ROOT / 'study/00121_失速と量で反転の入口を切り替える/根拠/P2の事前診断'


def sha(data: bytes) -> str:
    """
    機能: 全バイト列の指紋を返す。
    引数: data(bytes)は保存対象。
    返り値: strはSHA256の小文字16進値。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 完了指紋で診断JSONと生成コードを認証し正式保存する。
    引数: なし。返り値: None。121市場結果/Raw/入力は読まない。
    """
    completion_bytes = (SOURCE / '完了.json').read_bytes()
    completion = json.loads(completion_bytes)
    assert completion['成功'] and completion['編集停止']
    DEST.mkdir(parents=True, exist_ok=True)
    refs = []
    for name in ('P2全件実測.json', 'P2事前条件の分解.json', 'P2既定条件の交差分解.json', '確認.json', '完了.json'):
        data = (SOURCE / name).read_bytes()
        if name != '完了.json':
            assert sha(data) == completion['SHA256'][name]
        target = DEST / name
        assert not target.exists() or target.read_bytes() == data
        target.write_bytes(data)
        refs.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
    buffer = io.BytesIO()
    entries = []
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
        for name in ('診断する.py', '一覧を文書化する.py'):
            data = (SOURCE / name).read_bytes()
            assert sha(data) == completion['SHA256'][name]
            relative = (SOURCE / name).relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            stream.writestr(info, data, compresslevel=9)
            entries.append({'entry': relative, 'sha256': sha(data), 'bytes': len(data)})
    zipped = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(zipped)) as stream:
        assert stream.testzip() is None
        for entry in entries:
            assert sha(stream.read(entry['entry'])) == entry['sha256']
    target = DEST / '診断コード.zip'
    assert not target.exists() or target.read_bytes() == zipped
    target.write_bytes(zipped)
    refs.append({'path': target.name, 'bytes': len(zipped), 'sha256': sha(zipped), 'entries': entries})
    proof = {'試行': 121, '用途': '120固定結果から作った事前診断の保存。121市場結果ではない。', '成功': True, '保存対象': refs, '元診断完了SHA256': sha(completion_bytes), '全件転記MDの複写': False, '金融再生': False, '121市場結果読取': False, 'Raw読取': 0, '入力JSON読取': False, '11月09読取': False}
    (DEST / '保管の確認.json').write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'JSON数': 5, 'コードZIPbytes': len(zipped), 'コードZIP_SHA256': sha(zipped)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
