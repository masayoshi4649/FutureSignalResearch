"""121の成功結果・最終CSV器・独立検算を、金融再計算せず保管する。"""
from pathlib import Path
import gzip
import hashlib
import io
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / 'work/121入口比較'
TRIAL = ROOT / 'study/00121_失速と量で反転の入口を切り替える'


def sha(data: bytes) -> str:
    """
    機能: 全bytesの指紋を返す。
    引数: data(bytes)は保存対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def save(path: Path, data: bytes, derived: bool = False) -> dict:
    """
    機能: 新規又は同体を保存し、非金融の派生packだけ最終版へ更新する。
    引数: path(Path)、data(bytes)、derived(bool)は保存先・内容・派生更新可否。
    返り値: dictは相対path・サイズ・SHA256。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists() and not derived:
        assert path.read_bytes() == data, str(path)
    else:
        path.write_bytes(data)
    assert path.read_bytes() == data
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data), 'sha256': sha(data)}


# ----------------------------------------
def main() -> None:
    """
    機能: 結果gzip・正本・CSV検査と最終コードZIPを同体保存する。
    引数: なし。返り値: None。Raw/Native/市場入力/11/09を読まない。
    """
    f1_bytes = (WORK / 'F1.json').read_bytes()
    assert sha(f1_bytes) == 'a190ea40ee0dc40f208032fc4998116141dfd242ccdc01675e18f85f3964d643'
    fixed = json.loads(f1_bytes)
    assert all(sha(Path(p).read_bytes()) == expected for p, expected in fixed['code_sha256'].items())
    assert all(sha(Path(p).read_bytes()) == expected for p, expected in fixed['premarket_documents'].items())
    raw = (WORK / '全70場の入口結果.json').read_bytes()
    assert sha(raw) == '57118383d3e69ce341db955d0c34873b77177e497c801f6093630f4f31dd83bd'
    sources = [
        (WORK / '集計.json', '成果物/集計.json', '5f103dae6636cee921f62e86f3869602be0c62e3f7ee7576152870f282eedb96'),
        (WORK / '全70場の完了.json', '検査/全70場の完了.json', '036b798cacf592858d658d291f5a27fbc54dc751dfa1031911dbe172df05c4eb'),
        (WORK / '対照の確認.json', '検査/対照の確認.json', '52dd60ab290c18f0e3e00a0c775e9fe8e5f60ad439a823b2220e151e99c0cba7'),
        (ROOT / 'work/121入口実装検査/独立検算.json', '検査/独立検算.json', 'c4c384cd79a262a9f54a2b0993305c9086abf803a429e5b47bf60cd7280d91a2'),
        (ROOT / 'work/121入口CSV出力/全70独立再読.json', '検査/CSVの独立再読.json', None),
        (ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/121入口比較CSV/CSVの確認.json', '検査/CSVの生成確認.json', None),
    ]
    refs = []
    for source, dest, expected in sources:
        data = source.read_bytes()
        if expected is not None:
            assert sha(data) == expected
        refs.append(save(TRIAL / dest, data))
    buffer = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=buffer, mtime=0, compresslevel=9) as stream:
        stream.write(raw)
    packed = buffer.getvalue()
    assert gzip.decompress(packed) == raw
    ref = save(TRIAL / '成果物/全70場の入口結果.json.gz', packed)
    ref['展開後bytes'], ref['展開後SHA256'] = len(raw), sha(raw)
    refs.append(ref)

    # ----------------------------------------
    # 事前packの固定金融コードを保ち、非金融CSV最終器と独立checkerだけを結合する。
    previous = json.loads((TRIAL / '再現資料/コード復元索引.json').read_text(encoding='utf-8'))
    paths = {ROOT / row['restore_relative'] for row in previous['entries']}
    paths.add(ROOT / 'work/121入口実装検査/独立検算する.py')
    paths.add(Path(__file__).resolve())
    assert sha((ROOT / 'work/121入口実装検査/独立検算する.py').read_bytes()) == '9bbb41a8c17b8fc477962493b1b1806a0d0cc9266b126dda68302280aeed3392'
    assert sha((ROOT / 'work/121入口CSV出力/出力する.mjs').read_bytes()) == '9fad9685a2bfd6aefec5cbb306c13c9f2c3d7c83288808827e9786d48becfeb7'
    entries = []
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(paths):
            data = path.read_bytes()
            relative = path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data, compresslevel=9)
            entries.append({'entry': relative, 'restore_relative': relative, 'bytes': len(data), 'sha256': sha(data)})
    zipped = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(zipped)) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == {row['entry'] for row in entries}
        for row in entries:
            data = archive.read(row['entry'])
            assert sha(data) == row['sha256'] and len(data) == row['bytes']
    zip_ref = save(TRIAL / '再現資料/121コード.zip', zipped, True)
    refs.append(zip_ref)
    index = dict(previous)
    index.update({'段階': '固定コード・最終CSV器・独立検算の保管', 'zip': zip_ref, 'entries': entries, '初期コードZIP_SHA256': '71e82c564aeff40bd5e1dbe4c679d017f824d727fe435cc4a33e7ef6b9921cea', '更新範囲': '固定金融コードを変更せず、非金融CSV器の小範囲プレビュー修正と独立checker・結果保管器を結合'})
    refs.append(save(TRIAL / '再現資料/コード復元索引.json', (json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode('utf-8'), True))
    assert all(sha(Path(p).read_bytes()) == expected for p, expected in fixed['code_sha256'].items())
    assert all(sha(Path(p).read_bytes()) == expected for p, expected in fixed['premarket_documents'].items())
    assert (WORK / '全70場の入口結果.json').read_bytes() == raw
    proof = {'試行': 121, '成功': True, '段階': '固定コード・最終CSV器・独立検算コードの最終保管', '保存対象': refs, '旧120pureは正式120ZIPの4entry参照を維持': True, 'ZIP全entrySHAサイズCRC一致': True, '結果gzip全bytes復元一致': True, '固定金融コードと原文不変': True, '初期packからの非金融変更': index['更新範囲'], '市場入力本文読取': False, 'Raw読取': 0, 'Native読取': 0, '11月09読取': False, '金融再実行': False, '金融再集計': False, '入力実行物原板Native重複複写': False, '保管器SHA256': sha(Path(__file__).read_bytes())}
    save(TRIAL / '検査/コード保管の確認.json', (json.dumps(proof, ensure_ascii=False, indent=2) + '\n').encode('utf-8'), True)
    print(json.dumps({'成功': True, '結果gzip': ref, 'コードZIP': zip_ref, 'entry数': len(entries)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
