"""121の固定コードと事前証拠を、市場結果を読まずに保管する。"""
from pathlib import Path
import hashlib
import io
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / 'work/121入口比較'
TRIAL = ROOT / 'study/00121_失速と量で反転の入口を切り替える'
OLDZIP = ROOT / 'study/00120_1分構造と無効化距離で入口を作る/再現資料/120コード.zip'


def sha(data: bytes) -> str:
    """
    機能: 全bytesの指紋を求める。
    引数: data(bytes)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def save(path: Path, data: bytes) -> dict:
    """
    機能: 正式先へ新規保存し、既存なら全bytes同体を認証する。
    引数: path(Path)は正式先、data(bytes)は内容。
    返り値: dictは相対path・サイズ・SHA256。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, str(path)
    else:
        path.write_bytes(data)
    assert path.read_bytes() == data
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data), 'sha256': sha(data)}


# ----------------------------------------
def main() -> None:
    """
    機能: F1・人工証跡とソースを認証し、旧120pureを参照で保存する。
    引数: なし。返り値: None。121市場結果・入力本文・Rawを読まない。
    """
    f1_bytes = (WORK / 'F1.json').read_bytes()
    assert sha(f1_bytes) == 'a190ea40ee0dc40f208032fc4998116141dfd242ccdc01675e18f85f3964d643'
    fixed = json.loads(f1_bytes)
    assert all(sha(Path(p).read_bytes()) == expected for p, expected in fixed['code_sha256'].items())
    assert all(sha(Path(p).read_bytes()) == expected for p, expected in fixed['premarket_documents'].items())
    copies = [
        ('work/121入口比較/F1.json', '検査/F1.json', sha(f1_bytes)),
        ('work/121入口比較/F1.sha256', '検査/F1.sha256', None),
        ('work/121入口比較/実行前照合.json', '検査/実行前照合.json', None),
        ('work/121入口の反転切替/検査/確認.json', '検査/発生器の人工検査.json', 'be14d71916516713ba67a717631eaf327a828b8685242ad6e0c3148a2689ca03'),
        ('work/121入口実装検査/確認.json', '検査/執行器の人工検査.json', '8a9e0c849cdd982876a4b4b4c9c38a7bb1c9f5d228734d6ef9e31cb70ac97515'),
        ('work/121入口レビュー/確認.json', '検査/独立コードレビュー.json', '3b9aeeb37106f9d81a638043049a66682e3ff1f40dc5fb6cd39fea5f70dfc1dc'),
        ('work/121入口レビュー/事前論理レビュー.md', '検査/事前論理レビュー.md', None),
    ]
    refs = []
    for source, dest, expected in copies:
        data = (ROOT / source).read_bytes()
        if expected is not None:
            assert sha(data) == expected
        refs.append(save(TRIAL / dest, data))
    old_bytes = OLDZIP.read_bytes()
    assert sha(old_bytes) == 'ac3c159fe9b9cffda8e8ed4260029e191577e9921537d982a973f6e454ced771'
    prefix = ROOT / 'work/120入口の1分構造'
    allpaths = {Path(p) for p in fixed['code_sha256']}
    external, paths = [], set()
    with zipfile.ZipFile(io.BytesIO(old_bytes)) as archive:
        for path in allpaths:
            if path.is_relative_to(prefix):
                entry = path.relative_to(ROOT).as_posix()
                data = archive.read(entry)
                expected = fixed['code_sha256'][str(path)]
                assert sha(data) == expected
                external.append({'source_zip': OLDZIP.relative_to(ROOT).as_posix(), 'source_zip_sha256': sha(old_bytes), 'entry': entry, 'restore_relative': entry, 'bytes': len(data), 'sha256': expected})
            else:
                paths.add(path)
    paths.update(ROOT / p for p in (
        'work/121入口比較/README.md', 'work/121入口の反転切替/README.md', 'work/118複数技法の入口条件/README.md',
        'work/121入口比較/実行前を照合する.py', 'work/121実行準備を作る.py', 'work/121設定を準備する.py', 'work/121診断根拠を保存する.py',
        'work/121入口CSV出力/出力する.mjs', 'work/121入口CSV出力/CSVを独立再読する.py', 'work/121入口CSV出力/README.md',
    ))
    paths.add(Path(__file__).resolve())
    entries = []
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(paths):
            data = path.read_bytes()
            relative = path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data, compresslevel=9)
            entries.append({'entry': relative, 'restore_relative': relative, 'bytes': len(data), 'sha256': sha(data)})
    zipped = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(zipped)) as archive:
        assert archive.testzip() is None
        assert set(archive.namelist()) == {row['entry'] for row in entries}
        for row in entries:
            assert sha(archive.read(row['entry'])) == row['sha256']
    zip_ref = save(TRIAL / '再現資料/121コード.zip', zipped)
    refs.append(zip_ref)
    index = {'試行': 121, '成功': True, '段階': '市場結果未読の固定コード保管', 'zip': zip_ref, 'restore_root': str(ROOT), 'entries': entries, 'external_entries': external, '120pureの重複保存': False, '入力は同梱しない': fixed['input'], '実行物は同梱しない': fixed['executable'], '依存': {'Go': '1.24.2 windows/amd64', 'Python': '3.14.3', 'Node': '24.22.1', 'artifact_tool': '2.8.129'}, '旧対照': {'result_gzip': 'study/00120_1分構造と無効化距離で入口を作る/成果物/全70場の入口結果.json.gz', 'decoded_sha256': 'e61846c01ff849fa132697dc456dfed32a8b470697286620d1c28a5f0925a4d6'}}
    refs.append(save(TRIAL / '再現資料/コード復元索引.json', (json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode('utf-8')))
    assert all(sha(Path(p).read_bytes()) == expected for p, expected in fixed['code_sha256'].items())
    proof = {'試行': 121, '成功': True, '段階': 'コードと事前検査のみ。市場結果保存は未実施', '保存対象': refs, 'ZIP全entrySHAサイズCRC一致': True, '旧120ZIPからの外部entry認証数': len(external), '固定コードと原文不変': True, '121市場結果読取': False, '市場入力本文読取': False, 'Raw読取': 0, 'Native読取': 0, '11月09読取': False, '金融再実行': False, '入力実行物原板Native重複複写': False, '保管器SHA256': sha(Path(__file__).read_bytes())}
    save(TRIAL / '検査/コード保管の確認.json', (json.dumps(proof, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'成功': True, 'コードZIP': zip_ref, 'entry数': len(entries), '外部120pure参照数': len(external), '121市場結果読取': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
