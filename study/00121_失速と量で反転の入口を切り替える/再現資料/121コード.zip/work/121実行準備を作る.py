"""120の固定評価を再用し、121の共有出生へ適応する。"""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main() -> None:
    """
    機能: 121の集計・固定・実行コードを新規保存する。
    引数: なし。返り値: None。121市場結果を読まない。
    """
    before = ROOT / 'work/120入口比較'
    own = ROOT / 'work/121入口比較'
    own.mkdir(exist_ok=True)
    for name in ('集計する.py','実行する.py','条件を固定する.py'):
        text = (before / name).read_text(encoding='utf-8').replace('120','121')
        if name == '条件を固定する.py':
            text = text.replace('1分構造と無効化距離で入口を作る','失速と量で反転の入口を切り替える').replace('121入口の1分構造','121入口の反転切替')
            text = text.replace("'P1','P1plus','P2','P2plus','P3','P3plus'", "'C0','E0','V0','EV','B0','B1'")
            text = text.replace("condition['minute_raw_gap_reset_seconds'] = 60", "condition['minute_raw_gap_reset_seconds'] = 60\n    condition['cohort'] = 'C0の出生/冷却からE0/V0/EVを同原行派生、B1の出生/冷却からB0を同原行派生。将来約定結果を出生へ返さない。'\n    condition['source_control'] = 'C0を120P2の22出生17取得へ全件対応させ、共通event情報・要求・状態・取得・期限評価が同体かを検査する。'\n    condition['hypothesis_status'] = '120既知結果の診断後に立てた探索仮説。ADX低下の7例は元54場6順0逆/追加16場0順1逆。未知再現性は未証明。'")
            text = text.replace("condition['structure_hold'] = '出生と取得評価のLastでP1前1分順側境界strict/P2前5本逆側境界+側5pt以上/P3前5本順側境界strictを維持。最初の正常BBOでcap→hold→risk、拒否後に待たない。'", "condition['structure_hold'] = '全政策で出生と取得評価のLastが前5本逆側境界から側5pt以上を維持。最初の正常BBOでcap→hold→risk、拒否後に待たない。'")
        elif name == '集計する.py':
            text = text.replace("c['family'] = c['policy'].removesuffix('plus')", "c['family'] = 'B1' if c['policy'] in ('B0','B1') else 'C0'\n            c['cohort_id'] = event['cohort_id']")
            text = text.replace("c['role'] = '追加確認' if c['policy'].endswith('plus') else '構造背景'", "c['role'] = '基礎候補' if c['policy'] in ('C0','B1') else '追加条件'")
            text = text.replace("baseline.get((c['session'], c['family'], c['bar_end'], c['birth']['side']))", "baseline.get((c['session'], c['cohort_id']))")
            text = text.replace("baseline = {(c['session'], c['family'], c['bar_end'], c['birth']['side']): c for c in rows if not c['policy'].endswith('plus')}", "baseline = {(c['session'], c['cohort_id']): c for c in rows if c['policy'] in ('C0','B1')}")
        with (own/name).open('x',encoding='utf-8',newline='\n') as stream:
            stream.write(text)
    print('121実行前コードを準備。市場実行/F1固定は未実施。')


if __name__=='__main__':
    main()
