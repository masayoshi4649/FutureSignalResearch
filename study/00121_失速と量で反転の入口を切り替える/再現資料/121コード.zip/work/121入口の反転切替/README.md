# 121：失敗突破からの反転経路切替

120の既知結果を踏まえた新仮説を実装する純条件モジュール。60分±100ptの主評価でP2は10順7逆、ADX30低下群は既定54場6順0逆に対し追加16場0順1逆だった。RVOL≥1群も追加16場は2順1逆。これらは同場依存・小標本・既知結果への着目を含む探索で、70%以上の精度を確認した手法ではない。[全22出生の診断](../121反転候補の診断/README.md)を根拠とし、121の実市場結果は未読・未実行。

## APIと固定core

```go
detector := entrybirth121.NewDetector()
detector.StartSession(sessionID, contract)
events, err := detector.Observe(bank, quote)
stats := detector.Stats()
```

`bank`は118の`entryrules118.Bank`、`quote`は`rules.Quote`。Event/Stats/Bar/Range/Snapshotの基本形は120と同じ。Eventへ`CohortID string`（JSON`cohort_id`）を追加する。

120固定ソースの形成・品質・状態16関数を同bytesの意味で再用し、Go AST同体検査を行う。RawのUTC1分因果形成、前14本TR平均、空分とRaw価格時計差>60秒のreset、30秒fresh、5/15/30公表、TR≤2前ATR1、順側実体と終値位置、cap/hold/自然否定距離、300秒基礎冷却は同じ。固定120は変更しない。

当1分の逆側極値が前5本1分rangeをstrict一時突破し、終値はrange内へ境界から5pt以上回復。出生RawのLastも回復5ptを維持する。新規価格追い過ぎcapと自然否定距離を出生時にも要求し、Rootが次Raw執行時にも再確認する。相関する指標の票数を確信度へ置き換えない。

## 6政策

|政策|条件と役割|
|---|---|
|C0|120P2の完全対照。30分ADX≤25又は低下、1分逆側極値が15分BB20±2母σへ接触、15分RSI買い≤35/売り≥65、失敗突破→回復構造|
|E0|C0基礎出生のうち30分ADXの既知低下を伴うもの|
|V0|C0基礎出生のうちRVOL5既知≥1を伴うもの|
|EV|C0基礎出生のうちADX既知低下かつRVOL5≥1を伴うもの|
|B1|広い帯の別基礎出生。極値がBB15中線の逆側、15分RSI買い≤50/売り≥50、ADX30既知低下、RVOL5≥1、同じ失敗突破→回復構造|
|B0|B1基礎出生のうち5分Hist増分とRSI増分がともに新規方向へ改善したもの|

BB中線・RSI50は等号可、ADX低下・勢い改善はstrict。RVOL1は等号可。B0/B1はADX>25でも低下していれば候補を許す。MA方向は要求しない。120のP2ではほぼ全てが30分MA配置・両傾きに逆向きであり、同方向必須では反転候補自体が消えるため。売買は符号反転した同条件を使う。

## 基礎出生と派生

まずC0用条件とC0/sideの冷却を通過した原行で基礎出生を作り、その**同原行だけ**でE0/V0/EVを条件派生する。派生の独立冷却はない。元C0が未約定でも冷却は消費する。後の原行でE/V条件だけが成立してもC0冷却中なら派生しない。

B1を別の基礎としてB1/side冷却を通過後、同原行で勢い条件が真ならB0を派生する。B0も独立冷却しない。C0とB1の基礎冷却は別で、相互に出生を妨げない。`LastSignals`に保存するキーはC0/B1×sideだけ。

C0→E0/V0/EVとB1→B0は、それぞれ同じ`CohortID`を持つ。Event.IDは政策ごとに異なり、同一場の基礎出生連番を共有する。Fieldsの`cohort_sequence`と`cohort_base`（C0=0/B1=1）、`cohort_derived`でも対応を記録する。State.Sequenceは基礎出生数、Stats.Birthsは派生を含むEvent総数である。

## 保存票と統計

C0は120P2の既存Fields全キー値、At/Bar/PreviousFiveRange/Refs/EntryCap/Invalidationを維持し、新票だけを追加する。追加はBB15下限/中線/上限、ADX30/前ADX/増分と既知性、Hist/RSIの符号増分、外側/広帯、量、勢い、回復構造と共通条件の当時真偽、cohort情報。未知の原値はKnown=falseのままで、既知性フラグと分ける。

Statsの共通分母は120と同じ。各政策/sideのConsideredは共通品質を通過した足数で、Shape/Risk/Cap/Hold/Background/Structure/ExtraPassは独立ゲート件数。AllGatesPassは**基礎冷却前**の当政策全条件AND。基礎冷却が拒否した原行で派生政策の全条件も真なら、派生のCooldownRejectedにも加算する。全6政策で`AllGatesPass=Births+CooldownRejected`となる。

実約定、1秒遅延、30秒寿命、正常BBO、ForceClose、費用、固定30/60分、IFDと利益追尾はRootの実行側の責務。このモジュールは損益を算出せず、独立1mini候補を運用口座へ合計しない。

```powershell
go test -count=1 -v ./...
go vet ./...
go build ./...
```

人工7主テストで6政策鏡像・同cohort派生・基礎冷却/統計・広帯と高ADX・未知と等号・現在hold/Raw欠測・120core AST16関数同体・旧120DetectorとC0の人工Raw/旧全票同体を確認する。テストのみ固定120moduleをimportする。自然Raw・入力.json・121市場結果・11/09は読まない。120市場結果は別の診断で読んでおり、後付け仮説であることを隠さない。
