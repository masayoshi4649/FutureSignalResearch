package entrybirth121

import (
	"bytes"
	"encoding/json"
	"fmt"
	old "github.com/masayoshi4649/SessionTradeExecuter/entrybirth120"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"reflect"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// ----------------------------------------
// known は、人工の既知値を作ります。
//
// 引数: v(float64)。返り値: rules.Valueです。
func known(v float64) rules.Value { return rules.Value{Known: true, Value: v} }

// ----------------------------------------
// artificial は、自然入力を使わない3公表と1分履歴を作ります。
//
// 引数: side(int)、reversal(bool)。返り値: *Detector/rules.Snapshot/Bar/rules.Quoteです。
func artificial(side int, reversal bool) (*Detector, rules.Snapshot, Bar, rules.Quote) {
	d := NewDetector()
	_ = d.StartSession("S", "K")
	end := 1200.0
	s := rules.Snapshot{SessionID: "S", Contract: "K", Frames: map[int]rules.Publication{}, BB15: rules.Bands{Known: true, Lower: 990, Upper: 1010}, RVOL5: known(1)}
	for _, w := range []int{300, 900, 1800} {
		f := rules.ChartFrame{ID: fmt.Sprintf("S/%d/1200", w), SessionID: "S", Contract: "K", Width: w, Start: end - float64(w), End: end, AvailableAt: end, DeliveryAt: end, PriceKnown: true, VolumeKnown: true, Volume: 100, OHLC: rules.OHLC{Open: 1000, High: 1010, Low: 990, Close: 1000}, Technical: rules.Technical{EMA8: known(1001), EMA21: known(1000), Gap: known(1), EMA8Delta: known(1), EMA21Delta: known(1), ATR: known(100), PreviousATR: known(100), TR: known(20), RSI: known(60), PreviousRSI: known(55), Histogram: known(1), PreviousHistogram: known(.5)}}
		p := rules.Publication{Stamp: rules.Stamp{Time: end, Index: 0, Line: 1}, Frame: rules.Frame{Frame: f, DMI: rules.DMI{PlusDI: known(30), MinusDI: known(20), ADX: known(24), PreviousADX: known(26)}}}
		s.Frames[w] = p
		s.Refs = append(s.Refs, rules.Ref{ID: f.ID, Width: w, End: end, Delivered: p.Stamp})
	}
	low, high, close := 990.0, 1010.0, 1000.0
	b := Bar{Start: end, End: end + 60, OHLC: rules.OHLC{Open: 995, High: 1025, Low: 990, Close: 1020}, TR: known(35), Rows: 4}
	if reversal {
		low, high, close = 1000, 1020, 1010
		b.OHLC = rules.OHLC{Open: 1003, High: 1020, Low: 995, Close: 1015}
		b.TR = known(25)
		s.BB15 = rules.Bands{Known: true, Lower: 1000, Upper: 1040}
		p := s.Frames[900]
		p.Frame.Frame.Technical.RSI = known(30)
		s.Frames[900] = p
	}
	for i := 0; i < 14; i++ {
		at := end - float64((14-i)*60)
		d.history = append(d.history, Bar{Start: at, End: at + 60, OHLC: rules.OHLC{Open: close, High: high, Low: low, Close: close}, TR: known(20), Rows: 4})
	}
	if side < 0 {
		for i := range d.history {
			o := d.history[i].OHLC
			d.history[i].OHLC = rules.OHLC{Open: 2000 - o.Open, High: 2000 - o.Low, Low: 2000 - o.High, Close: 2000 - o.Close}
		}
		o := b.OHLC
		b.OHLC = rules.OHLC{Open: 2000 - o.Open, High: 2000 - o.Low, Low: 2000 - o.High, Close: 2000 - o.Close}
		lower, upper := s.BB15.Lower, s.BB15.Upper
		s.BB15.Lower = 2000 - upper
		s.BB15.Upper = 2000 - lower
		for w, p := range s.Frames {
			z := &p.Frame.Frame.Technical
			z.EMA8 = known(2000 - z.EMA8.Value)
			z.EMA21 = known(2000 - z.EMA21.Value)
			z.Gap.Value *= -1
			z.EMA8Delta.Value *= -1
			z.EMA21Delta.Value *= -1
			z.RSI.Value = 100 - z.RSI.Value
			z.PreviousRSI.Value = 100 - z.PreviousRSI.Value
			z.Histogram.Value *= -1
			z.PreviousHistogram.Value *= -1
			p.Frame.DMI.PlusDI, p.Frame.DMI.MinusDI = p.Frame.DMI.MinusDI, p.Frame.DMI.PlusDI
			s.Frames[w] = p
		}
	}
	d.lastKnownBB15 = &BandWidth{Width: s.BB15.Upper - s.BB15.Lower, Ref: s.Refs[1]}
	s.BB15.Mean = (s.BB15.Lower + s.BB15.Upper) / 2
	d.previousKnownBB15 = &BandWidth{Width: 80, Ref: rules.Ref{ID: "prior15", Width: 900, End: 300}}
	q := rules.Quote{Time: b.End, Index: 100, Line: 101, Last: b.OHLC.Close}
	return d, s, b, q
}

// ----------------------------------------
// TestSixPoliciesMirrorIncludesCohort は、6政策の鏡像と二基礎出生の対応を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestSixPoliciesMirrorIncludesCohort(t *testing.T) {
	var buy map[string]Event
	for _, side := range []int{1, -1} {
		d, s, b, q := artificial(side, true)
		events := d.analyze(s, b, q)
		found := map[string]Event{}
		for _, policy := range Policies {
			got := selectPolicy(events, policy, side)
			if len(got) != 1 {
				t.Fatalf("%s side%d %#v", policy, side, events)
			}
			found[policy] = got[0]
		}
		for _, p := range []string{"E0", "V0", "EV"} {
			if found[p].CohortID != found["C0"].CohortID || found[p].At != found["C0"].At || found[p].Fields["cohort_sequence"] != found["C0"].Fields["cohort_sequence"] {
				t.Fatal("C0派生出生差", p)
			}
		}
		if found["B0"].CohortID != found["B1"].CohortID || found["B1"].CohortID == found["C0"].CohortID {
			t.Fatal("B1出生差")
		}
		for k, c := range d.Stats().Policies {
			if c.AllGatesPass != c.Births+c.CooldownRejected {
				t.Fatal("統計代数", k, c)
			}
		}
		if side > 0 {
			buy = found
		} else {
			for _, p := range Policies {
				if buy[p].EntryCap+found[p].EntryCap != 2000 || buy[p].Invalidation+found[p].Invalidation != 2000 || buy[p].Fields["hold_gap_at_birth"] != found[p].Fields["hold_gap_at_birth"] {
					t.Fatal("非対称", p)
				}
			}
		}
		found["E0"].Fields["atr5"] = known(1)
		if found["C0"].Fields["atr5"].Value == 1 {
			t.Fatal("派生票共有")
		}
	}
}

// ----------------------------------------
// TestBaseCooldownOwnsDerivedSubset は、派生条件が後から成立しても基礎冷却を迂回しないことを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestBaseCooldownOwnsDerivedSubset(t *testing.T) {
	d, s, b, q := artificial(1, true)
	p := s.Frames[1800]
	p.Frame.DMI.PreviousADX = known(23)
	s.Frames[1800] = p
	s.RVOL5 = rules.Value{}
	e := d.analyze(s, b, q)
	if len(e) != 1 || e[0].Policy != "C0" {
		t.Fatalf("C0のみ %#v", e)
	}
	p.Frame.DMI.PreviousADX = known(26)
	s.Frames[1800] = p
	s.RVOL5 = known(1)
	q.Time += 60
	e = d.analyze(s, b, q)
	if len(e) != 2 || len(selectPolicy(e, "B0", 1)) != 1 || len(selectPolicy(e, "B1", 1)) != 1 {
		t.Fatalf("基礎ごとの冷却 %#v", e)
	}
	for _, policy := range []string{"C0", "E0", "V0", "EV"} {
		c := d.Stats().Policies[policy+"/1"]
		if c.CooldownRejected != 1 || c.AllGatesPass != c.Births+c.CooldownRejected {
			t.Fatal("C0冷却の派生計数", policy, c)
		}
	}
	if len(d.lastSignals) != 2 {
		t.Fatal("派生が独立cooldown", d.lastSignals)
	}
	q.Time += 240
	e = d.analyze(s, b, q)
	for _, policy := range []string{"C0", "E0", "V0", "EV"} {
		if len(selectPolicy(e, policy, 1)) != 1 {
			t.Fatal("300秒等号", policy, e)
		}
	}
}

// ----------------------------------------
// broadOnly は、外側過熱ではないが中線側・失速・量がそろう人工票を作ります。
//
// 引数: side(int)。返り値: *Detector/rules.Snapshot/Bar/rules.Quoteです。
func broadOnly(side int) (*Detector, rules.Snapshot, Bar, rules.Quote) {
	d, s, b, q := artificial(side, true)
	p := s.Frames[1800]
	p.Frame.DMI.ADX = known(40)
	p.Frame.DMI.PreviousADX = known(42)
	s.Frames[1800] = p
	p = s.Frames[900]
	p.Frame.Frame.Technical.RSI = known(50 - 5*float64(side))
	s.Frames[900] = p
	if side > 0 {
		s.BB15 = rules.Bands{Known: true, Lower: 990, Mean: 1020, Upper: 1050}
	} else {
		s.BB15 = rules.Bands{Known: true, Lower: 950, Mean: 980, Upper: 1010}
	}
	return d, s, b, q
}

// ----------------------------------------
// TestBroadBandHighADXAndMomentumCohort は、広い帯の高ADX失速とB1からの勢い派生を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestBroadBandHighADXAndMomentumCohort(t *testing.T) {
	for _, side := range []int{1, -1} {
		d, s, b, q := broadOnly(side)
		p := s.Frames[300]
		p.Frame.Frame.Technical.PreviousHistogram = p.Frame.Frame.Technical.Histogram
		s.Frames[300] = p
		e := d.analyze(s, b, q)
		if len(e) != 1 || e[0].Policy != "B1" || e[0].Fields["tight_zone"].Value != 0 || e[0].Fields["broad_zone"].Value != 1 {
			t.Fatal("広い帯のみ", e)
		}
		p.Frame.Frame.Technical.PreviousHistogram = known(.5 * float64(side))
		s.Frames[300] = p
		q.Time += 60
		if e = d.analyze(s, b, q); len(e) != 0 {
			t.Fatal("B0が基礎冷却を迂回")
		}
		q.Time += 240
		e = d.analyze(s, b, q)
		if len(selectPolicy(e, "B0", side)) != 1 || len(selectPolicy(e, "B1", side)) != 1 {
			t.Fatal("B0/B1冷却等号")
		}
		if c := d.Stats().Policies[fmt.Sprintf("B0/%d", side)]; c.CooldownRejected != 1 || c.AllGatesPass != c.Births+c.CooldownRejected {
			t.Fatal(c)
		}
	}
}

// ----------------------------------------
// TestKnownBoundariesAndUnknown は、ADX低下strict・量等号・RSI中立/中線等号と未知拒否を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestKnownBoundariesAndUnknown(t *testing.T) {
	for _, side := range []int{1, -1} {
		d, s, b, q := artificial(side, true)
		p := s.Frames[1800]
		p.Frame.DMI.PreviousADX = p.Frame.DMI.ADX
		s.Frames[1800] = p
		e := d.analyze(s, b, q)
		if len(e) != 2 || len(selectPolicy(e, "C0", side)) != 1 || len(selectPolicy(e, "V0", side)) != 1 {
			t.Fatal("ADX同値を低下扱い", e)
		}
		d, s, b, q = artificial(side, true)
		p = s.Frames[1800]
		p.Frame.DMI.PreviousADX = rules.Value{}
		s.Frames[1800] = p
		s.RVOL5 = rules.Value{}
		e = d.analyze(s, b, q)
		if len(e) != 1 || e[0].Policy != "C0" || e[0].Fields["adx30_delta_known"].Value != 0 || e[0].Fields["adx30_falling"].Known || e[0].Fields["vol_ge1"].Known {
			t.Fatal("未知を支持又は補完", e)
		}
		d, s, b, q = broadOnly(side)
		extreme := b.OHLC.Low
		if side < 0 {
			extreme = b.OHLC.High
		}
		s.BB15.Mean = extreme
		p = s.Frames[900]
		p.Frame.Frame.Technical.RSI = known(50)
		s.Frames[900] = p
		e = d.analyze(s, b, q)
		if len(e) != 2 {
			t.Fatal("中線/RSI50等号を拒否", e)
		}
		d, s, b, q = broadOnly(side)
		s.RVOL5 = known(.999)
		if e = d.analyze(s, b, q); len(e) != 0 {
			t.Fatal("量不足を支持", e)
		}
	}
}

// ----------------------------------------
// TestCurrentHoldAndRawGapRemain は、出生Lastの維持とRaw87秒欠測resetを継承します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestCurrentHoldAndRawGapRemain(t *testing.T) {
	for _, side := range []int{1, -1} {
		d, s, b, q := artificial(side, true)
		boundary := d.history[len(d.history)-1].OHLC.Low
		if side < 0 {
			boundary = d.history[len(d.history)-1].OHLC.High
		}
		q.Last = boundary + 4.99*float64(side)
		if e := d.analyze(s, b, q); len(e) != 0 {
			t.Fatal("現在の回復喪失を受理")
		}
	}
	d, s, b, _ := artificial(1, true)
	bank := artificialBank(t, s)
	d.current = &b
	last := rules.Quote{Time: 1202, Index: 1, Line: 2, Last: 1003}
	d.last = &last
	if e, err := d.Observe(bank, rules.Quote{Time: 1289, Index: 2, Line: 3, Last: 1015}); err != nil || len(e) != 0 || len(d.history) != 0 || d.Stats().RawGapResets != 1 {
		t.Fatal("Raw欠測の継承", err, e)
	}
}

// ----------------------------------------
// functionAST は、指定Goソースの関数を整形したASTで比較できる形へ取り出します。
//
// 引数: t(*testing.T)、path/name(string)。返り値: []byte型の整形関数です。
func functionAST(t *testing.T, path, name string) []byte {
	t.Helper()
	set := token.NewFileSet()
	file, err := parser.ParseFile(set, path, nil, parser.ParseComments)
	if err != nil {
		t.Fatal(err)
	}
	for _, decl := range file.Decls {
		if fn, ok := decl.(*ast.FuncDecl); ok && fn.Name.Name == name {
			var b bytes.Buffer
			if err := format.Node(&b, set, fn); err != nil {
				t.Fatal(err)
			}
			return b.Bytes()
		}
	}
	t.Fatal("関数なし", name)
	return nil
}

// ----------------------------------------
// TestFrozen120CoreASTSame は、形成・品質・状態の16関数が固定120と同体であることを確認します。
//
// 引数: t(*testing.T)。返り値: なし。参照はソースのみで自然入力を開きません。
func TestFrozen120CoreASTSame(t *testing.T) {
	for _, name := range []string{"NewDetector", "StartSession", "Snapshot", "Stats", "makeBar", "updateBar", "priorRange", "priorATR", "updateBB", "positive", "deltaPositive", "centered", "trendBackground", "reverseBackground", "knownValue", "Observe"} {
		if !bytes.Equal(functionAST(t, "../120入口の1分構造/detector.go", name), functionAST(t, "detector.go", name)) {
			t.Fatal("固定core差", name)
		}
	}
}

// ----------------------------------------
// TestC0Matches120P2OnArtificialRaw は、人工原行による元P2/C0の時点・全旧票・構造同体を確認します。
//
// 引数: t(*testing.T)。返り値: なし。政策名とIDだけは新試行の識別子へ置換されます。
func TestC0Matches120P2OnArtificialRaw(t *testing.T) {
	for _, side := range []int{1, -1} {
		_, s, b, _ := artificial(side, true)
		bank := rules.NewBank()
		for _, width := range []int{300, 900, 1800} {
			for i := 0; i < 20; i++ {
				p := s.Frames[width]
				end := 1200 - float64((20-i)*width)
				p.Frame.Frame.SessionID = "prior"
				p.Frame.Frame.ID = fmt.Sprintf("prior/%d/%d", width, i)
				p.Frame.Frame.Start = end - float64(width)
				p.Frame.Frame.End = end
				p.Frame.Frame.AvailableAt = end
				p.Frame.Frame.DeliveryAt = end
				p.Stamp = rules.Stamp{Time: end, Index: i, Line: i + 1}
				price := 1010.0
				if side < 0 {
					price = 990
				}
				p.Frame.Frame.OHLC = rules.OHLC{Open: price, High: price, Low: price, Close: price}
				if err := bank.Add(p); err != nil {
					t.Fatal(err)
				}
			}
		}
		if err := bank.StartSession("S", "K"); err != nil {
			t.Fatal(err)
		}
		for _, width := range []int{300, 900, 1800} {
			if err := bank.Add(s.Frames[width]); err != nil {
				t.Fatal(err)
			}
		}
		d := NewDetector()
		_ = d.StartSession("S", "K")
		control := old.NewDetector()
		_ = control.StartSession("S", "K")
		index := 1
		var got []Event
		var oldEvents []old.Event
		// observe は、新旧双方へ同じ人工原行を配送します。
		//
		// 引数: at/last(float64)。返り値: なし。
		observe := func(at, last float64) {
			q := rules.Quote{Time: at, Index: index, Line: index + 1, Last: last}
			index++
			e, err := d.Observe(bank, q)
			if err != nil {
				t.Fatal(err)
			}
			got = append(got, e...)
			o, err := control.Observe(bank, q)
			if err != nil {
				t.Fatal(err)
			}
			oldEvents = append(oldEvents, o...)
		}
		for i := 0; i < 15; i++ {
			at := 300 + float64(i*60)
			low, high, close := 1000.0, 1020.0, 1010.0
			if side < 0 {
				low, high, close = 980, 1000, 990
			}
			observe(at, close)
			observe(at+10, low)
			observe(at+20, high)
			observe(at+59, close)
		}
		observe(1200, b.OHLC.Open)
		observe(1210, b.OHLC.Low)
		observe(1220, b.OHLC.High)
		observe(1259, b.OHLC.Close)
		observe(1260, b.OHLC.Close)
		c0 := selectPolicy(got, "C0", side)
		oldP2 := []old.Event{}
		for _, e := range oldEvents {
			if e.Policy == "P2" && e.Side == side {
				oldP2 = append(oldP2, e)
			}
		}
		if len(c0) != 1 || len(oldP2) != 1 {
			t.Fatal("対照出生数", len(c0), len(oldP2))
		}
		a, z := c0[0], oldP2[0]
		ab, _ := json.Marshal(a.Bar)
		zb, _ := json.Marshal(z.Bar)
		ar, _ := json.Marshal(a.PreviousFiveRange)
		zr, _ := json.Marshal(z.PreviousFiveRange)
		if a.At != z.At || a.EntryCap != z.EntryCap || a.Invalidation != z.Invalidation || !bytes.Equal(ab, zb) || !bytes.Equal(ar, zr) || !reflect.DeepEqual(a.Refs, z.Refs) {
			t.Fatal("構造/時計/Refの対照差")
		}
		for k, v := range z.Fields {
			if a.Fields[k] != v {
				t.Fatal("旧票差", k, a.Fields[k], v)
			}
		}
		for _, k := range []string{"bb15_lower", "bb15_mean", "bb15_upper", "adx30_delta", "adx30_delta_known", "tight_zone", "broad_zone", "vol_ge1", "momentum_both", "cohort_sequence", "cohort_base"} {
			if _, ok := a.Fields[k]; !ok {
				t.Fatal("診断票なし", k)
			}
		}
	}
}

// ----------------------------------------
// selectPolicy は、人工の返り値から政策と売買が一致するものを選びます。
//
// 引数: events([]Event)、policy(string)、side(int)。返り値: []Eventです。
func selectPolicy(events []Event, policy string, side int) []Event {
	out := []Event{}
	for _, e := range events {
		if e.Policy == policy && e.Side == side {
			out = append(out, e)
		}
	}
	return out
}

// ----------------------------------------
// artificialBank は、人工snapshotの3公表だけをbankへ配送します。
//
// 引数: t(*testing.T)、s(rules.Snapshot)。返り値: *rules.Bankです。
func artificialBank(t *testing.T, s rules.Snapshot) *rules.Bank {
	t.Helper()
	bank := rules.NewBank()
	if err := bank.StartSession("S", "K"); err != nil {
		t.Fatal(err)
	}
	for _, w := range []int{300, 900, 1800} {
		if err := bank.Add(s.Frames[w]); err != nil {
			t.Fatal(err)
		}
	}
	return bank
}
