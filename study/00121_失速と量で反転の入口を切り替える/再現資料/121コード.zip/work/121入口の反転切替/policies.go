package entrybirth121

import (
	"fmt"
	"math"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// ----------------------------------------
// booleanValue は、当時既知の条件票を数値で保存します。
//
// 引数: known/pass(bool)。返り値: rules.Value。未知はKnown=falseを維持します。
func booleanValue(known, pass bool) rules.Value {
	v := 0.0
	if pass {
		v = 1
	}
	return rules.Value{Known: known, Value: v}
}

// ----------------------------------------
// rawDelta は、二つの既知値の当公表から前公表を引きます。
//
// 引数: now/previous(rules.Value)。返り値: rules.Valueは不足を未知のまま保持します。
func rawDelta(now, previous rules.Value) rules.Value {
	if !now.Known || !previous.Known {
		return rules.Value{}
	}
	return knownValue(now.Value - previous.Value)
}

// ----------------------------------------
// cloneFields は、同出生群の別政策へ票のmap参照を共有しません。
//
// 引数: fields(map[string]rules.Value)。返り値: map[string]rules.Value型の私有票です。
func cloneFields(fields map[string]rules.Value) map[string]rules.Value {
	r := make(map[string]rules.Value, len(fields))
	for k, v := range fields {
		r[k] = v
	}
	return r
}

// ----------------------------------------
// analyze は、C0/B1の基礎出生と同原行の条件派生を評価します。
//
// 引数: s(rules.Snapshot)、b(Bar)、q(rules.Quote)。返り値: []Event。
// 120P2の共通品質・技術・C0取得票を保持し、派生政策は独立に冷却しません。
func (d *Detector) analyze(s rules.Snapshot, b Bar, q rules.Quote) []Event {
	if len(s.Missing) > 0 {
		d.stats.PublicationMissing++
		return nil
	}
	for _, w := range []int{300, 900, 1800} {
		if p, ok := s.Frames[w]; !ok || !p.Frame.Frame.PriceKnown {
			d.stats.PublicationMissing++
			return nil
		}
	}
	a1 := priorATR(d.history, b.Start)
	t5 := s.Frames[300].Frame.Frame.Technical
	t15 := s.Frames[900].Frame.Frame.Technical
	if !a1.Known || a1.Value <= 0 {
		d.stats.ATR1Unavailable++
		return nil
	}
	if !b.TR.Known {
		d.stats.CurrentTRUnavailable++
		return nil
	}
	if b.TR.Value > 2*a1.Value {
		d.stats.SpikeRejected++
		return nil
	}
	if !t5.ATR.Known || t5.ATR.Value <= 0 {
		d.stats.ATR5Unavailable++
		return nil
	}
	if b.OHLC.High <= b.OHLC.Low {
		d.stats.RangeRejected++
		return nil
	}
	range5 := priorRange(d.history, 5, b.Start)
	if len(d.history) == 0 {
		return nil
	}
	previous := d.history[len(d.history)-1]
	adx := s.Frames[1800].Frame.DMI.ADX
	previousADX := s.Frames[1800].Frame.DMI.PreviousADX
	adxDelta := rawDelta(adx, previousADX)
	decay := adxDelta.Known && adxDelta.Value < 0
	volume := s.RVOL5.Known && s.RVOL5.Value >= 1
	var events []Event

	// ----------------------------------------
	// 同じ確定1分の買売を鏡像で評価し、基礎出生の可否を先に固定する。
	for _, side := range []int{1, -1} {
		sign := float64(side)
		extreme, previousBoundary, location := b.OHLC.Low, previous.OHLC.High, (b.OHLC.Close-b.OHLC.Low)/(b.OHLC.High-b.OHLC.Low)
		broken, band := range5.Low, s.BB15.Lower
		if side < 0 {
			extreme, previousBoundary, location = b.OHLC.High, previous.OHLC.Low, (b.OHLC.High-b.OHLC.Close)/(b.OHLC.High-b.OHLC.Low)
			broken, band = range5.High, s.BB15.Upper
		}
		invalidation := extreme - sign*5
		maximumRisk := math.Min(100, .5*t5.ATR.Value)
		risk := sign * (q.Last - invalidation)
		cap := b.OHLC.Close + sign*math.Min(10, .15*t5.ATR.Value)
		riskOK, capOK, shapeOK := risk > 0 && risk <= maximumRisk, sign*(q.Last-cap) <= 0, sign*(b.OHLC.Close-b.OHLC.Open) > 0 && location >= .7
		holdGap := sign * (q.Last - broken)
		holdOK := range5.Known && holdGap >= 5
		structure := range5.Known && sign*(extreme-broken) < 0 && sign*(b.OHLC.Close-broken) >= 5 && b.OHLC.Close >= range5.Low && b.OHLC.Close <= range5.High
		tightZone := s.BB15.Known && sign*(extreme-band) <= 0 && centered(t15.RSI, side, math.Inf(-1), -15)
		broadZone := s.BB15.Known && sign*(extreme-s.BB15.Mean) <= 0 && centered(t15.RSI, side, math.Inf(-1), 0)
		tightBackground := reverseBackground(s)
		histDelta, rsiDelta := rawDelta(t5.Histogram, t5.PreviousHistogram), rawDelta(t5.RSI, t5.PreviousRSI)
		histDelta.Value *= sign
		rsiDelta.Value *= sign
		momentum := histDelta.Known && histDelta.Value > 0 && rsiDelta.Known && rsiDelta.Value > 0
		passed := map[string]bool{}
		for _, policy := range Policies {
			background, priceStructure, extra := tightBackground, tightZone && structure, true
			switch policy {
			case "E0":
				background = background && decay
			case "V0":
				extra = volume
			case "EV":
				background = background && decay
				extra = volume
			case "B0":
				background = decay
				priceStructure = broadZone && structure
				extra = volume && momentum
			case "B1":
				background = decay
				priceStructure = broadZone && structure
				extra = volume
			}
			key := fmt.Sprintf("%s/%d", policy, side)
			c := d.stats.Policies[key]
			c.Considered++
			if riskOK {
				c.RiskPass++
			}
			if capOK {
				c.CapPass++
			}
			if shapeOK {
				c.ShapePass++
			}
			if holdOK {
				c.HoldPass++
			}
			if background {
				c.BackgroundPass++
			}
			if priceStructure {
				c.StructurePass++
			}
			if extra {
				c.ExtraPass++
			}
			passed[policy] = riskOK && capOK && shapeOK && holdOK && background && priceStructure && extra
			if passed[policy] {
				c.AllGatesPass++
			}
			d.stats.Policies[key] = c
		}

		// ----------------------------------------
		// C0は120P2と同じ固定票を持ち、追加した原値票だけを後ろへ足す。
		distance := rules.Value{Known: t5.EMA21.Known, Value: sign * (extreme - t5.EMA21.Value)}
		fields := map[string]rules.Value{
			"atr5": t5.ATR, "atr1_before14": a1, "min1_tr": b.TR,
			"min1_range": knownValue(b.OHLC.High - b.OHLC.Low), "min1_close_position": knownValue(location), "min1_body_signed": knownValue(sign * (b.OHLC.Close - b.OHLC.Open)),
			"maximum_risk": knownValue(maximumRisk), "risk_at_last": knownValue(risk), "previous1_boundary": knownValue(previousBoundary), "extreme_ema21_5_signed": distance,
			"bb15_width": {Known: s.BB15.Known, Value: s.BB15.Upper - s.BB15.Lower}, "previous_known_bb15_width": {},
			"rvol5": s.RVOL5, "rsi5": t5.RSI, "previous_rsi5": t5.PreviousRSI, "hist5": t5.Histogram, "previous_hist5": t5.PreviousHistogram, "rsi15": t15.RSI,
			"gap30": s.Frames[1800].Frame.Frame.Technical.Gap, "ema8_delta30": s.Frames[1800].Frame.Frame.Technical.EMA8Delta, "ema21_delta30": s.Frames[1800].Frame.Frame.Technical.EMA21Delta,
			"adx15": s.Frames[900].Frame.DMI.ADX, "plus_di15": s.Frames[900].Frame.DMI.PlusDI, "minus_di15": s.Frames[900].Frame.DMI.MinusDI, "adx30": adx, "previous_adx30": previousADX,
			"hold_boundary": {Known: range5.Known, Value: broken}, "hold_minimum": knownValue(5), "hold_strict": knownValue(0), "hold_gap_at_birth": knownValue(holdGap),
			"bb15_lower": {Known: s.BB15.Known, Value: s.BB15.Lower}, "bb15_mean": {Known: s.BB15.Known, Value: s.BB15.Mean}, "bb15_upper": {Known: s.BB15.Known, Value: s.BB15.Upper},
			"adx30_delta": adxDelta, "adx30_delta_known": booleanValue(true, adxDelta.Known), "adx30_falling": booleanValue(adxDelta.Known, decay),
			"hist5_delta_signed": histDelta, "rsi5_delta_signed": rsiDelta, "hist5_improving": booleanValue(histDelta.Known, histDelta.Value > 0), "rsi5_improving": booleanValue(rsiDelta.Known, rsiDelta.Value > 0),
			"momentum_both": booleanValue(histDelta.Known && rsiDelta.Known, momentum), "vol_ge1": booleanValue(s.RVOL5.Known, volume),
			"tight_zone": booleanValue(s.BB15.Known && t15.RSI.Known, tightZone), "broad_zone": booleanValue(s.BB15.Known && t15.RSI.Known, broadZone),
			"tight_background": booleanValue(adx.Known && (adx.Value <= 25 || previousADX.Known), tightBackground), "recovered_structure": booleanValue(range5.Known, structure),
			"risk_pass": booleanValue(true, riskOK), "cap_pass": booleanValue(true, capOK), "shape_pass": booleanValue(true, shapeOK), "hold_pass": booleanValue(range5.Known, holdOK),
		}

		// ----------------------------------------
		// 派生は元出生の冷却を消費して初めて発生し、後から独立再出現しない。
		for baseIndex, base := range []string{"C0", "B1"} {
			if !passed[base] {
				continue
			}
			children := []string{"C0", "E0", "V0", "EV"}
			if base == "B1" {
				children = []string{"B0", "B1"}
			}
			baseKey := fmt.Sprintf("%s/%d", base, side)
			if last, ok := d.lastSignals[baseKey]; ok && q.Time-last < 300 {
				for _, p := range children {
					if passed[p] {
						key := fmt.Sprintf("%s/%d", p, side)
						c := d.stats.Policies[key]
						c.CooldownRejected++
						d.stats.Policies[key] = c
					}
				}
				continue
			}
			d.sequence++
			cohort := fmt.Sprintf("%s/%s/%d/%06d", d.scope.SessionID, base, side, d.sequence)
			d.lastSignals[baseKey] = q.Time
			for _, p := range children {
				if !passed[p] {
					continue
				}
				key := fmt.Sprintf("%s/%d", p, side)
				c := d.stats.Policies[key]
				c.Births++
				d.stats.Policies[key] = c
				d.stats.Births++
				f := cloneFields(fields)
				f["cohort_sequence"], f["cohort_base"], f["cohort_derived"] = knownValue(float64(d.sequence)), knownValue(float64(baseIndex)), booleanValue(true, p != base)
				events = append(events, Event{CohortID: cohort, ID: fmt.Sprintf("%s/%s/%d/%06d", d.scope.SessionID, p, side, d.sequence), Scope: d.scope, Policy: p, Side: side, At: q, Bar: b, PreviousFiveRange: range5, Refs: append([]rules.Ref{}, s.Refs...), Fields: f, EntryCap: cap, Invalidation: invalidation})
			}
		}
	}
	return events
}
