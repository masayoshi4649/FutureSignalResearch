package entrybirth121

import (
	"fmt"
	"math"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// ----------------------------------------
// NewDetector は、場開始前の空の発生器を作ります。
//
// 引数: なし。返り値: *Detector。Observeより先にStartSessionを呼びます。
func NewDetector() *Detector { return &Detector{} }

// ----------------------------------------
// StartSession は、1分履歴・BB比較・政策別クールダウンを当場へ初期化します。
//
// 引数: sessionID/contract(string)。返り値: errorは空の識別子です。
func (d *Detector) StartSession(sessionID, contract string) error {
	if sessionID == "" || contract == "" {
		return fmt.Errorf("場又は限月が空です")
	}
	*d = Detector{scope: Scope{SessionID: sessionID, Contract: contract}, lastSignals: map[string]float64{}, stats: Stats{Policies: map[string]PolicyStats{}}}
	for _, policy := range Policies {
		for _, side := range []int{1, -1} {
			d.stats.Policies[fmt.Sprintf("%s/%d", policy, side)] = PolicyStats{}
		}
	}
	return nil
}

// ----------------------------------------
// Snapshot は、外部と参照を共有しない現在の形成状態を返します。
//
// 引数: receiver(*Detector)。返り値: Stateは作業中足と最大20本履歴を含みます。
func (d *Detector) Snapshot() State {
	s := State{Scope: d.scope, History: append([]Bar{}, d.history...), LastSignals: map[string]float64{}, Sequence: d.sequence, Stats: d.Stats()}
	if d.last != nil {
		v := *d.last
		s.Last = &v
	}
	if d.current != nil {
		v := *d.current
		s.Current = &v
	}
	if d.lastKnownBB15 != nil {
		v := *d.lastKnownBB15
		s.LastKnownBB15 = &v
	}
	if d.previousKnownBB15 != nil {
		v := *d.previousKnownBB15
		s.PreviousKnownBB15 = &v
	}
	for k, v := range d.lastSignals {
		s.LastSignals[k] = v
	}
	return s
}

// ----------------------------------------
// Stats は、共通品質と政策別の独立ゲート件数を私有値として返します。
//
// 引数: receiver(*Detector)。返り値: Stats。各Passは同じConsidered分母、AllGatesPassは全条件ANDです。
func (d *Detector) Stats() Stats {
	s := d.stats
	s.Policies = map[string]PolicyStats{}
	for k, v := range d.stats.Policies {
		s.Policies[k] = v
	}
	return s
}

// ----------------------------------------
// makeBar は、UTCの60秒床へ属する最初の価格で1分足を作ります。
//
// 引数: q(rules.Quote)。返り値: *Bar。終了時計の原行は次足へ属します。
func makeBar(q rules.Quote) *Bar {
	start := math.Floor(q.Time/60) * 60
	return &Bar{Start: start, End: start + 60, OHLC: rules.OHLC{Open: q.Last, High: q.Last, Low: q.Last, Close: q.Last}, Rows: 1, First: q, Last: q}
}

// ----------------------------------------
// updateBar は、当該1分内の当時価格だけで形成足を更新します。
//
// 引数: b(*Bar)、q(rules.Quote)。返り値: なし。未確定足から信号は発しません。
func updateBar(b *Bar, q rules.Quote) {
	b.OHLC.High = math.Max(b.OHLC.High, q.Last)
	b.OHLC.Low = math.Min(b.OHLC.Low, q.Last)
	b.OHLC.Close = q.Last
	b.Rows++
	b.Last = q
}

// ----------------------------------------
// priorRange は、直前n本の連続確定1分足の高安を求めます。
//
// 引数: history([]Bar)、n(int)、end(float64)。返り値: Rangeは不足や不連続なら未知です。
func priorRange(history []Bar, n int, end float64) Range {
	r := Range{Count: n}
	if len(history) < n || n < 1 {
		return r
	}
	list := history[len(history)-n:]
	r.Start = list[0].Start
	r.End = end
	r.Low = math.Inf(1)
	r.High = math.Inf(-1)
	for i, b := range list {
		if b.End != b.Start+60 || (i > 0 && b.Start != list[i-1].End) {
			return Range{Count: n}
		}
		r.Low = math.Min(r.Low, b.OHLC.Low)
		r.High = math.Max(r.High, b.OHLC.High)
	}
	if list[n-1].End != end {
		return Range{Count: n}
	}
	r.Known = true
	return r
}

// ----------------------------------------
// priorATR は、当足を含めない前14本の既知TR単純平均を返します。
//
// 引数: history([]Bar)、end(float64)は評価当足の開始。返り値: rules.Valueは不足を未知のまま残します。
func priorATR(history []Bar, end float64) rules.Value {
	if !priorRange(history, 14, end).Known {
		return rules.Value{}
	}
	sum := 0.0
	for _, b := range history[len(history)-14:] {
		if !b.TR.Known {
			return rules.Value{}
		}
		sum += b.TR.Value
	}
	return rules.Value{Known: true, Value: sum / 14}
}

// ----------------------------------------
// updateBB は、同場の異なる既知15分公表の幅だけを順序保持します。
//
// 引数: s(rules.Snapshot)。返り値: なし。未知公表は既知の前比較値へ置換しません。
func (d *Detector) updateBB(s rules.Snapshot) {
	p, ok := s.Frames[900]
	if !ok || p.Frame.Frame.ID == d.last15ID {
		return
	}
	d.last15ID = p.Frame.Frame.ID
	if !s.BB15.Known || !p.Frame.Frame.PriceKnown {
		return
	}
	ref := rules.Ref{ID: p.Frame.Frame.ID, Width: 900, End: p.Frame.Frame.End, Delivered: p.Stamp}
	d.previousKnownBB15 = d.lastKnownBB15
	d.lastKnownBB15 = &BandWidth{Width: s.BB15.Upper - s.BB15.Lower, Ref: ref}
}

// ----------------------------------------
// positive は、既知値が売買符号の正側かを判定します。
//
// 引数: v(rules.Value)、side(int)。返り値: boolは未知を真としません。
func positive(v rules.Value, side int) bool { return v.Known && float64(side)*v.Value > 0 }

// ----------------------------------------
// deltaPositive は、前後とも既知の差分が売買符号の正側かを判定します。
//
// 引数: now/previous(rules.Value)、side(int)。返り値: boolです。
func deltaPositive(now, previous rules.Value, side int) bool {
	return now.Known && previous.Known && float64(side)*(now.Value-previous.Value) > 0
}

// ----------------------------------------
// centered は、RSIの中心50からの符号距離が閉区間内かを判定します。
//
// 引数: rsi(rules.Value)、side(int)、low/high(float64)。返り値: boolです。
func centered(rsi rules.Value, side int, low, high float64) bool {
	v := float64(side) * (rsi.Value - 50)
	return rsi.Known && v >= low && v <= high
}

// ----------------------------------------
// trendBackground は、長期配置/両傾きと中期方向/強さの同時成立を判定します。
//
// 引数: s(rules.Snapshot)、side(int)。返り値: boolです。
func trendBackground(s rules.Snapshot, side int) bool {
	t := s.Frames[1800].Frame.Frame.Technical
	d := s.Frames[900].Frame.DMI
	return positive(t.Gap, side) && positive(t.EMA8Delta, side) && positive(t.EMA21Delta, side) && d.PlusDI.Known && d.MinusDI.Known && float64(side)*(d.PlusDI.Value-d.MinusDI.Value) > 0 && d.ADX.Known && d.ADX.Value >= 20
}

// ----------------------------------------
// reverseBackground は、長期が弱い又は直前公表より失速した背景を判定します。
//
// 引数: s(rules.Snapshot)。返り値: boolです。
func reverseBackground(s rules.Snapshot) bool {
	d := s.Frames[1800].Frame.DMI
	return d.ADX.Known && (d.ADX.Value <= 25 || (d.PreviousADX.Known && d.ADX.Value < d.PreviousADX.Value))
}

// ----------------------------------------
// knownValue は、内部計算済みの有限値を保存用の既知値へ包みます。
//
// 引数: value(float64)。返り値: rules.Valueです。
func knownValue(value float64) rules.Value { return rules.Value{Known: true, Value: value} }

// ----------------------------------------
// Observe は、採用済み原行の価格時計順に1分を確定し技術候補を一度だけ返します。
//
// 引数: bank(*rules.Bank)は当原行までの公表、q(rules.Quote)は当時価格です。
// 返り値: []Event/error。同一原行再読は冪等、欠分は補間せず、確定から30秒超の信号を発しません。
func (d *Detector) Observe(bank *rules.Bank, q rules.Quote) ([]Event, error) {
	if bank == nil || d.scope.SessionID == "" {
		return nil, fmt.Errorf("場開始又はbankがありません")
	}
	s, err := bank.Current(q)
	if err != nil {
		return nil, err
	}
	if s.SessionID != d.scope.SessionID || s.Contract != d.scope.Contract {
		return nil, fmt.Errorf("公表と発生器の場又は限月差")
	}
	if d.last != nil {
		if q.Index == d.last.Index {
			if q != *d.last {
				return nil, fmt.Errorf("同原行の改変")
			}
			return nil, nil
		}
		if q.Index < d.last.Index || q.Line <= d.last.Line || q.Time < d.last.Time {
			return nil, fmt.Errorf("原行順が逆転")
		}
	}
	d.updateBB(s)
	d.stats.RawRows++
	currentStart := math.Floor(q.Time/60) * 60
	if d.last != nil && q.Time-d.last.Time > 60 {
		d.stats.RawGapResets++
		if d.current != nil && currentStart != d.current.End && currentStart != d.current.Start {
			d.stats.GapResets++
		}
		d.history = nil
		d.current = makeBar(q)
		v := q
		d.last = &v
		return nil, nil
	}
	var events []Event
	if d.current == nil {
		d.current = makeBar(q)
	} else if currentStart == d.current.Start {
		updateBar(d.current, q)
	} else {
		b := *d.current
		d.stats.ClosedMinuteBars++
		if q.Time-b.End > 30 {
			d.stats.StaleClosures++
		}
		if currentStart != b.End {
			d.history = nil
			d.stats.GapResets++
		} else {
			if len(d.history) > 0 {
				previous := d.history[len(d.history)-1]
				b.TR = rules.Value{Known: true, Value: math.Max(b.OHLC.High-b.OHLC.Low, math.Max(math.Abs(b.OHLC.High-previous.OHLC.Close), math.Abs(b.OHLC.Low-previous.OHLC.Close)))}
			}
			if q.Time-b.End <= 30 {
				d.stats.EligibleClosures++
				events = d.analyze(s, b, q)
			}
			d.history = append(d.history, b)
			if len(d.history) > 20 {
				d.history = append([]Bar{}, d.history[len(d.history)-20:]...)
			}
		}
		d.current = makeBar(q)
	}
	v := q
	d.last = &v
	return events, nil
}
