"""主ORへ含める規則の指定だけを独立検査し、初回8群の票を維持する。"""
from pathlib import Path
import copy
import hashlib
import importlib.util
import io
import json
import unittest

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CODE = ROOT / 'scripts/入口研究/固定特徴から可読条件を選択する.py'
OLD_PROOF = HERE / '準備の確認.json'
OLD_SHA = '3abcb57055951aa3ac1462b59de9ccc7718b25d7158a17a2be05012bf2be3ad9'
NEW_SHA = '2f46be32a23ce2c1e5e99f2714ed4fd1eb14c545e4e150a2efd8d112e5c5344a'
spec = importlib.util.spec_from_file_location('初回人工を再用する', HERE / '独立人工.py')
prior = importlib.util.module_from_spec(spec)
spec.loader.exec_module(prior)
selector = prior.selector


def digest(path: Path) -> str:
    """
    機能: 固定コードと既停止票の物理SHAを求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def differential_check() -> None:
    """
    機能: union_rulesの追加だけを逆変換して旧Sourceの全bytesへ照合する。
    引数: なし。返り値: None。復元文字列はディスクへ保存しない。
    """
    current = CODE.read_text(encoding='utf-8')
    changes = [
        ("    members = book.get('union_rules', ids)\n    assert members and len(members) == len(set(members)) and set(members) <= set(ids)\n", ''),
        ("    members = set(book.get('union_rules', [rule['id'] for rule in book['rules']]))\n", ''),
        ("        sides = {row['order_side'] for row in evidence if row['rule'] in members and policy == book['union_id'] or row['rule'] == policy}",
         "        sides = {row['order_side'] for row in evidence if policy == book['union_id'] or row['rule'] == policy}"),
        ("    union_rules = set(book.get('union_rules', [rule['id'] for rule in book['rules']]))\n", ''),
        ("            evidence = [hit for hit in row['decision']['evidence'] if hit['order_side'] == side and\n                        (policy == book['union_id'] and hit['rule'] in union_rules or hit['rule'] == policy)]",
         "            evidence = [hit for hit in row['decision']['evidence'] if hit['order_side'] == side and (policy == book['union_id'] or hit['rule'] == policy)]"),
    ]
    for new, old in changes:
        assert current.count(new) == 1, new
        current = current.replace(new, old)
    assert hashlib.sha256(current.encode('utf-8')).hexdigest() == OLD_SHA


def extended_book(same_condition: bool = True) -> dict:
    """
    機能: 主Aと診断FAを持ち、主ORはAだけの人工票を作る。
    引数: same_condition(bool)。返り値: dict。
    """
    conditions = prior.book()
    rule = copy.deepcopy(conditions['rules'][0])
    rule.update({'id': 'FA', 'order_sign': -1})
    if not same_condition:
        rule['when'] = {'all': [prior.leaf('direction', '<', 0), prior.leaf('volume', '>=', 1)]}
    conditions['rules'].append(rule)
    conditions['union_rules'] = ['A']
    return conditions


class UnionSupplement(unittest.TestCase):
    """診断規則は残すが主ORへ混ぜない独立境界。"""

    def test_09_diagnostic_opposition_not_main_conflict(self) -> None:
        """
        機能: 除外FAが反対を向いても主ORを待機にしないことを確認する。
        引数: self(UnionSupplement)。返り値: None。
        """
        conditions = extended_book()
        answer = prior.decide([1, 2, 1], [0, None, None], conditions)
        self.assertEqual(answer['directions'], {'A': 1, 'FA': -1, 'OR': 1})
        self.assertFalse(answer['conflicts']['OR'])
        del conditions['union_rules']
        default = prior.decide([1, 2, 1], [0, None, None], conditions)
        self.assertEqual(default['directions']['OR'], 0)
        self.assertTrue(default['conflicts']['OR'])
        conditions['union_rules'] = ['FA']
        self.assertEqual(prior.decide([1, 2, 1], [0, None, None], conditions)['directions']['OR'], -1)

    def test_10_diagnostic_only_not_main_born_or_canonical(self) -> None:
        """
        機能: 先行FAだけのq0が主ORのcanonicalを予約しないことを確認する。
        引数: self(UnionSupplement)。返り値: None。
        """
        conditions = extended_book(False)
        early, ec = prior.event('診断のみ', 10, [1, -1, 1], [0, None, None])
        late, lc = prior.event('主成立', 20, [1, 1, 1], [0, None, None])
        early['decision'] = prior.decide([1, -1, 1], [0, None, None], conditions)
        late['decision'] = prior.decide([1, 1, 1], [0, None, None], conditions)
        result = selector.connect([late, early], [lc, ec], prior.descriptors(), prior.SESSIONS, conditions)
        self.assertEqual(result['政策']['FA'][0]['event_id'], '診断のみ')
        self.assertEqual(result['政策']['OR'][0]['event_id'], '主成立')
        self.assertEqual(result['候補と取得']['OR'], {'born': 1, 'filled': 1})
        self.assertEqual(result['政策']['OR'][0]['成立ID'], ['A'])
        self.assertEqual([h['rule'] for h in result['政策']['OR'][0]['evidence']], ['A'])
        self.assertEqual(len(result['政策']['U0']), 2)

    def test_11_same_side_evidence_excluded_and_c1_kept(self) -> None:
        """
        機能: 同側診断が成立しても主根拠へ入れず旧対照優先を維持する。
        引数: self(UnionSupplement)。返り値: None。
        """
        conditions = extended_book()
        conditions['rules'][1]['order_sign'] = 1
        d, c = prior.event('旧への重複', 10, [1, 1, 1], [0, None, None], '旧')
        d['decision'] = prior.decide([1, 1, 1], [0, None, None], conditions)
        result = selector.connect([d], [c], prior.descriptors(), prior.SESSIONS, conditions)
        self.assertEqual(result['政策']['OR'][0]['成立ID'], ['A'])
        self.assertEqual({h['rule'] for h in result['政策']['OR'][0]['evidence']}, {'A'})
        self.assertEqual(result['政策']['FA'][0]['成立ID'], ['FA'])
        self.assertEqual((result['政策']['U0'][0]['side'], result['政策']['U0'][0]['stream']), (-1, 'original'))

    def test_12_member_schema_and_true_main_conflict(self) -> None:
        """
        機能: 空/重複/未定義を拒否し、採用member同士の両方向は待機にする。
        引数: self(UnionSupplement)。返り値: None。
        """
        for members in ([], ['A', 'A'], ['不存在']):
            conditions = extended_book(); conditions['union_rules'] = members
            with self.assertRaises(AssertionError): selector.validate(conditions, prior.CATALOG)
        conditions = extended_book(); conditions['union_rules'] = ['A', 'FA']
        result = prior.decide([1, 1, 1], [0, None, None], conditions)
        self.assertEqual(result['directions']['OR'], 0)
        self.assertTrue(result['conflicts']['OR'])


def main() -> None:
    """
    機能: 初回8群と差分4群を再検査し、初回票不変更の追補票を保存する。
    引数: なし。返り値: None。自然特徴・金融・Raw・追加2場は開かない。
    """
    old_before = digest(OLD_PROOF)
    assert old_before == 'f4185f88e33e7071cda3c65b15c7f7a45845600307cd837f7d1a98715b8a4f9b'
    assert digest(CODE) == prior.SOURCE_SHA == NEW_SHA
    differential_check()
    suite = unittest.TestSuite([
        unittest.defaultTestLoader.loadTestsFromTestCase(prior.IndependentSelector),
        unittest.defaultTestLoader.loadTestsFromTestCase(UnionSupplement)])
    log_stream = io.StringIO()
    result = unittest.TextTestRunner(stream=log_stream, verbosity=2).run(suite)
    log = HERE / 'union追補の人工ログ.txt'
    log.write_text(log_stream.getvalue(), encoding='utf-8')
    assert result.wasSuccessful(), log_stream.getvalue()
    assert digest(OLD_PROOF) == old_before and digest(CODE) == NEW_SHA
    proof = {'成功': True, '編集停止': True, '対象SHA256': NEW_SHA,
             '旧対象SHA256': OLD_SHA, '初回8群の票SHA256': old_before,
             '初回8群の票は変更なし': True, '初回8群再実行': 8, '差分独立人工': 4,
             'union追加5置換の逆変換で旧源全bytesとSHA一致': True,
             '確認': ['未指定は従来all', '診断の反対方向が主ORの競合へ混入しない',
                    '診断のみ先行q0が主canonicalを予約しない', '主evidence/成立IDへ非memberを混ぜない',
                    '診断個別政策は保持/C1優先保持', '空/重複/未定義拒否/member同士の反対は待機'],
             '自然選択/特徴の自然条件適用/金融/Raw/CSV/追加2場読取': False,
             'Source/既149変更': False, '重大未解決': [],
             'コードSHA256': digest(Path(__file__)), '人工ログSHA256': digest(log)}
    output = HERE / 'union範囲の追補確認.json'
    output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '人工': result.testsRun, '旧票保持': True,
                      '対象SHA256': NEW_SHA, '追補SHA256': digest(output)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
