"""共通可読選択器を小さな独立fixtureで検査し、自然選択は行わない。"""
from pathlib import Path
from unittest import mock
import contextlib
import copy
import gzip
import hashlib
import importlib.util
import io
import json
import math
import re
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CODE = ROOT / 'scripts/入口研究/固定特徴から可読条件を選択する.py'
SOURCE_SHA = hashlib.sha256(CODE.read_bytes()).hexdigest()
SPEC = importlib.util.spec_from_file_location('共通可読選択の確認対象', CODE)
selector = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(selector)
CATALOG = [{'name': 'common', 'role': '値幅'}, {'name': 'direction', 'role': '方向'},
           {'name': 'volume', 'role': '量'}]
SESSIONS = ['人工A_Day', '人工B_Night']


def leaf(name: str, op: str = '>', value: float = 0) -> dict:
    """
    機能: 小型の比較条件を独立に組み立てる。
    引数: name/op(str)、value(float)。返り値: dictは葉条件。
    """
    return {'var': name, 'op': op, 'value': value}


def book() -> dict:
    """
    機能: 自然8局面を使わず3列2場1旧対照の条件票を作る。
    引数: なし。返り値: dict。
    """
    return {'trial': 777, 'parent_trial': 148, 'catalog_count': 3, 'session_count': 2,
            'legacy_count': 1, 'minimum_technical_roles': 2,
            'catalog_definition_sha256': '人工列定義SHA', 'derived': {},
            'common': leaf('common'),
            'rules': [{'id': 'A', 'order_sign': 1,
                       'when': {'all': [leaf('direction'), leaf('volume', '>=', 1)]}}],
            'union_id': 'OR', 'legacy_id': 'C1', 'main_id': 'U0'}


def decide(buy: list, sell: list, conditions: dict | None = None) -> dict:
    """
    機能: 小型条件を検証してから対象q0関数を呼び出す。
    引数: buy/sell(list)、conditions(dict又はNone)。返り値: dict。
    """
    conditions = conditions or book()
    index, roles = selector.validate(conditions, CATALOG)
    return selector.decide(buy, sell, conditions, index, roles)


def descriptors() -> list:
    """
    機能: 反対向き旧対照と一つの新caseを人工生成する。
    引数: なし。返り値: list[dict]。
    """
    return [{'case_id': '旧', 'session': SESSIONS[0], 'contract': '人工限月', 'original_side': -1,
             'buy_stream': 'reverse', 'sell_stream': 'original', 'c1_reused': True},
            {'case_id': '新', 'session': SESSIONS[0], 'contract': '人工限月', 'original_side': 1,
             'buy_stream': 'original', 'sell_stream': 'reverse', 'c1_reused': False}]


def event(eid: str, idx: int, buy: list, sell: list, case: str = '新', session: str = SESSIONS[0]) -> tuple:
    """
    機能: q0判断と、それから独立した取得票を用意する。
    引数: eid/case/session(str)、idx(int)、buy/sell(list)。返り値: tuple[dict,dict]。
    """
    q0 = {'time': 1000 + idx, 'index': idx, 'source_line': 100 + idx}
    decision = {'event_id': eid, 'session': session, 'contract': '人工限月',
                'q0_time': q0['time'], 'q0_index': idx, 'q0_line': q0['source_line'],
                'decision': decide(buy, sell)}
    capture = {'event_id': eid, 'session': session, 'contract': '人工限月', 'q0': q0,
               'status': 'filled', 'case_id': case,
               'buy_stream': 'reverse' if case == '旧' else 'original',
               'sell_stream': 'original' if case == '旧' else 'reverse',
               'q1': {'time': 2000, 'index': 1000, 'source_line': 1100, 'bid': 100, 'ask': 110, 'last': 105}}
    return decision, capture


class IndependentSelector(unittest.TestCase):
    """未来取得を使わず判定する共通選択器の独立人工。"""

    def test_01_derived_null_and_dependency(self) -> None:
        """
        機能: 和/差/依存連鎖・未知・非有限の扱いを確認する。
        引数: self(IndependentSelector)。返り値: None。
        """
        b = book()
        b['derived'] = {'sum': {'op': 'sum', 'vars': ['direction', 'volume']},
                        'diff': {'op': 'difference', 'vars': ['sum', 'volume']}}
        b['rules'][0]['when'] = leaf('sum', '>=', 3)
        index, roles = selector.validate(b, CATALOG)
        values, deps = selector.context([1, 2, 1], index, b['derived'])
        self.assertEqual((values['sum'], values['diff']), (3, 2))
        self.assertEqual(deps['diff'], {'direction', 'volume'})
        self.assertEqual(selector.decide([1, 2, 1], [0, None, None], b, index, roles)['directions']['A'], 1)
        values, _ = selector.context([1, None, 1], index, b['derived'])
        self.assertIsNone(values['sum']); self.assertIsNone(values['diff'])
        for bad in (math.nan, math.inf, True):
            with self.assertRaises(AssertionError): selector.context([1, bad, 1], index, b['derived'])
        for vars_ in (['future', 'direction'], ['diff', 'direction']):
            invalid = copy.deepcopy(b); invalid['derived']['sum']['vars'] = vars_
            with self.assertRaises(AssertionError): selector.validate(invalid, CATALOG)

    def test_02_three_value_truth_and_edges(self) -> None:
        """
        機能: all/anyの9組合せと比較の等号/厳密境界を独立期待表へ照合する。
        引数: self(IndependentSelector)。返り値: None。
        """
        truth_values = [(1, True), (0, False), (None, None)]
        index, _ = selector.validate(book(), CATALOG)
        for a, at in truth_values:
            for b, bt in truth_values:
                values, deps = selector.context([1, a, b], index, {})
                for op in ('all', 'any'):
                    if op == 'all': expected = False if False in (at, bt) else None if None in (at, bt) else True
                    else: expected = True if True in (at, bt) else None if None in (at, bt) else False
                    actual, _ = selector.evaluate({op: [leaf('direction'), leaf('volume')]}, values, deps)
                    self.assertIs(actual, expected)
        values, deps = selector.context([1, 0, 1], index, {})
        for op, expected in [('>', False), ('>=', True), ('<', False), ('<=', True), ('==', True)]:
            self.assertIs(selector.evaluate(leaf('direction', op), values, deps)[0], expected)
        bounds = {'all': [leaf('direction', '>=', -1), leaf('direction', '<=', 1)]}
        for value, expected in [(-1, True), (1, True), (-1.00001, False), (1.00001, False), (None, None)]:
            values, deps = selector.context([1, value, 1], index, {})
            self.assertIs(selector.evaluate(bounds, values, deps)[0], expected)

    def test_03_roles_common_and_unknown_branch(self) -> None:
        """
        機能: commonを技法数にせず、未知OR枝だけでは2役割を満たせないことを確認する。
        引数: self(IndependentSelector)。返り値: None。
        """
        b = book(); b['rules'][0]['when'] = {'any': [leaf('direction'), leaf('volume')]}
        with self.assertRaises(AssertionError): decide([1, 1, None], [0, 0, 0], b)
        with self.assertRaises(AssertionError): decide([1, 1, 0], [0, 0, 0], b)
        result = decide([1, 1, 1], [0, None, None], b)
        self.assertEqual(result['evidence'][0]['roles'], ['方向', '量'])
        b['rules'][0]['when'] = leaf('direction')
        with self.assertRaises(AssertionError): decide([1, 1, None], [0, 0, 0], b)
        self.assertEqual(decide([None, 1, 1], [0, 0, 0])['directions']['OR'], 0)

    def test_04_signal_order_symmetry_and_conflict(self) -> None:
        """
        機能: 既side変換配列を再反転せず、信号と注文符号・同側根拠・競合を確認する。
        引数: self(IndependentSelector)。返り値: None。
        """
        b = book(); b['rules'][0]['order_sign'] = -1
        for buy, sell, expected_signal, expected_order in [([1, 2, 1], [0, None, None], 1, -1),
                                                         ([0, None, None], [1, 2, 1], -1, 1)]:
            answer = decide(buy, sell, b)
            self.assertEqual(answer['directions']['A'], expected_order)
            self.assertEqual(answer['evidence'][0]['signal_side'], expected_signal)
        both = decide([1, 2, 1], [1, 2, 1])
        self.assertTrue(both['conflicts']['A']); self.assertTrue(both['conflicts']['OR'])
        self.assertEqual(both['directions']['OR'], 0)
        b = book(); b['rules'].append({**copy.deepcopy(b['rules'][0]), 'id': 'B'})
        same = decide([1, 2, 1], [0, None, None], b)
        self.assertEqual({x['rule'] for x in same['evidence']}, {'A', 'B'})
        self.assertEqual(same['directions']['OR'], 1)
        b['rules'][1]['order_sign'] = -1
        opposed = decide([1, 2, 1], [0, None, None], b)
        self.assertEqual((opposed['directions']['A'], opposed['directions']['B'], opposed['directions']['OR']), (1, -1, 0))

    def test_05_canonical_legacy_and_no_mutation(self) -> None:
        """
        機能: q1共有時の最初q0、C1優先、未取得と入力非改変を確認する。
        引数: self(IndependentSelector)。返り値: None。
        """
        early, ec = event('早', 10, [1, 2, 1], [0, None, None])
        late, lc = event('遅', 20, [0, None, None], [1, 2, 1])
        old, oc = event('旧重複', 30, [1, 2, 1], [0, None, None], '旧')
        pending, pc = event('未取得', 10, [1, 2, 1], [0, None, None], session=SESSIONS[1])
        pc.update({'status': 'ttl', 'case_id': None, 'q1': None})
        ds, cs, cases = [late, old, pending, early], [oc, lc, ec, pc], descriptors()
        before = copy.deepcopy((ds, cs, cases))
        result = selector.connect(ds, cs, cases, SESSIONS, book())
        selected = {r['case_id']: r for r in result['政策']['OR']}
        self.assertEqual((selected['新']['event_id'], selected['新']['side']), ('早', 1))
        protected = next(r for r in result['政策']['U0'] if r['case_id'] == '旧')
        self.assertEqual((protected['side'], protected['stream'], protected['event_id']), (-1, 'original', None))
        self.assertEqual(result['候補と取得']['OR'], {'born': 4, 'filled': 3, 'duplicate_q1': 1, 'ttl': 1})
        self.assertEqual(len(result['政策']['U0']), 2)
        self.assertTrue(result['旧C1重複'][0]['opposite'])
        self.assertEqual(before, (ds, cs, cases))

    def test_06_connection_and_book_guards(self) -> None:
        """
        機能: q0境界・限月・重複・文法・依存先の不整合を拒否する。
        引数: self(IndependentSelector)。返り値: None。
        """
        d, c = event('例', 10, [1, 2, 1], [0, None, None])
        for key in ('time', 'index', 'source_line'):
            invalid = copy.deepcopy(c); invalid['q0'][key] += 1
            with self.assertRaises(AssertionError): selector.connect([d], [invalid], descriptors(), SESSIONS, book())
        invalid = copy.deepcopy(c); invalid['contract'] = '異限月'
        with self.assertRaises(AssertionError): selector.connect([d], [invalid], descriptors(), SESSIONS, book())
        with self.assertRaises(AssertionError): selector.connect([d, d], [c], descriptors(), SESSIONS, book())
        with self.assertRaises(AssertionError): selector.connect([d], [c], descriptors(), SESSIONS + SESSIONS[:1], book())
        for mutation in ('op', 'var', 'role_count', 'ids'):
            invalid = book()
            if mutation == 'op': invalid['rules'][0]['when'] = leaf('direction', '!=')
            if mutation == 'var': invalid['rules'][0]['when'] = leaf('未来')
            if mutation == 'role_count': invalid['minimum_technical_roles'] = 1
            if mutation == 'ids': invalid['main_id'] = invalid['union_id']
            with self.assertRaises(AssertionError): selector.validate(invalid, CATALOG)

    def test_07_main_gzip_parse_order_q1_invariance(self) -> None:
        """
        機能: gzip/JSONを混ぜ、全decide完了前load禁止とq1価格非依存を確認する。
        引数: self(IndependentSelector)。返り値: None。
        """
        all_events = [event('早', 10, [1, 2, 1], [0, None, None]),
                      event('遅', 20, [0, None, None], [1, 2, 1]),
                      event('旧重複', 30, [1, 2, 1], [0, None, None], '旧')]
        ds, cs = [x[0] for x in all_events], [x[1] for x in all_events]
        rows = []
        for i, (d, c) in enumerate(all_events):
            buy, sell = ([0, None, None], [1, 2, 1]) if i == 1 else ([1, 2, 1], [0, None, None])
            rows.append({'event_id': d['event_id'], 'session': d['session'], 'contract': d['contract'],
                         'metadata': {'q0': c['q0']}, 'buy': {'side': 1, 'x': buy}, 'sell': {'side': -1, 'x': sell}})
        common = {'success': True, 'trial': 148, 'sessions': SESSIONS, 'financial_labels_used': False,
                  'strategy_selected': False, 'selected_trade_count': None,
                  'counts': {'eligible': 3}, 'statuses': {'filled': 3}}
        for key in ('input_sha256', 'parent_source_sha256', 'parent_gzip_sha256', 'background_sha256', 'catalog_sha256'):
            common[key] = '人工' + key
        common['catalog_definition_sha256'] = book()['catalog_definition_sha256']
        features = {**common, 'catalog': CATALOG, 'rows': rows}
        metadata = {'success': True, 'trial': 148, 'sessions': SESSIONS,
                    'financial_labels_used': False, 'population148': {'cases': descriptors()}}
        saved = []
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            actual_load, actual_decide = selector.load, selector.decide
            for attempt in range(2):
                captures = {**common, 'rows': copy.deepcopy(cs)}
                for item in captures['rows']:
                    for key in ('bid', 'ask', 'last'): item['q1'][key] += attempt * 10000
                values = {'book': book(), 'features': features, 'captures': captures, 'metadata': metadata}
                paths = {name: base / (name + str(attempt) + ('.json.gz' if name in ('features', 'metadata') else '.json')) for name in values}
                for name, path in paths.items():
                    raw = json.dumps(values[name], ensure_ascii=False).encode('utf-8')
                    path.write_bytes(gzip.compress(raw, mtime=0) if path.suffix == '.gz' else raw)
                count = [0]
                def spy_decide(*args):
                    """
                    機能: q0判定の完了数を数える。
                    引数: args(tuple)。返り値: dictは対象の判定。
                    """
                    answer = actual_decide(*args); count[0] += 1
                    return answer
                def spy_load(path):
                    """
                    機能: 取得/旧対照をparseするとき全q0完了を必須にする。
                    引数: path(Path)。返り値: objectは読取JSON。
                    """
                    if path in (paths['captures'], paths['metadata']): self.assertEqual(count[0], len(ds))
                    return actual_load(path)
                output = base / f'output{attempt}'
                argv = ['共通選択器', '--output-dir', str(output)]
                for name, path in paths.items(): argv += ['--' + name, str(path), '--' + name + '-sha256', hashlib.sha256(path.read_bytes()).hexdigest()]
                with mock.patch.object(selector, 'decide', side_effect=spy_decide), mock.patch.object(selector, 'load', side_effect=spy_load), mock.patch.object(sys, 'argv', argv), contextlib.redirect_stdout(io.StringIO()):
                    selector.main()
                saved.append((output / 'q0の判断.json').read_bytes())
            self.assertEqual(saved[0], saved[1])

    def test_08_load_crc_and_json_end(self) -> None:
        """
        機能: gzip CRC破損・JSON後続不正と保存先重複を拒否する。
        引数: self(IndependentSelector)。返り値: None。
        """
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp) / '人工.json.gz'
            good = gzip.compress('{"値": 1}'.encode('utf-8'), mtime=0)
            p.write_bytes(good)
            self.assertEqual(selector.load(p), {'値': 1})
            broken = bytearray(good); broken[-8] ^= 1; p.write_bytes(broken)
            with self.assertRaises((gzip.BadGzipFile, EOFError)): selector.load(p)
            q = Path(temp) / '人工.json'; q.write_text('{} trailing', encoding='utf-8')
            with self.assertRaises(json.JSONDecodeError): selector.load(q)
            with self.assertRaises(FileExistsError): selector.save(q, {})


def first_row(path: Path) -> dict:
    """
    機能: 自然features先頭1行のshapeだけを確認する。
    引数: path(Path)。返り値: dict。自然行を条件判定へ渡さない。
    """
    text = ''
    with path.open(encoding='utf-8') as stream:
        while True:
            chunk = stream.read(65536)
            assert chunk
            text += chunk
            marker = re.search(r'"rows"\s*:\s*\[', text)
            if marker:
                try:
                    return json.JSONDecoder().raw_decode(text[marker.end():].lstrip())[0]
                except json.JSONDecodeError:
                    pass
            assert len(text) < 1048576


def main() -> None:
    """
    機能: 私有8群と限定schemaを検査し停止票を保存する。
    引数: なし。返り値: None。自然選択・金融ラベル・Raw・追加2場を読まない。
    """
    assert hashlib.sha256(CODE.read_bytes()).hexdigest() == SOURCE_SHA
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(IndependentSelector))
    log = HERE / '人工のログ.txt'
    log.write_text(stream.getvalue(), encoding='utf-8')
    assert result.wasSuccessful(), stream.getvalue()
    feature = first_row(ROOT / 'work/148全1分母集団の評価/母集団生成/当時特徴.json')
    q0 = feature['metadata']['q0']
    assert set(('time', 'index', 'source_line')) <= q0.keys()
    assert feature['buy']['side'] == 1 and feature['sell']['side'] == -1
    assert len(feature['buy']['x']) == len(feature['sell']['x']) == 100
    assert all(feature[key] for key in ('event_id', 'session', 'contract'))
    assert hashlib.sha256(CODE.read_bytes()).hexdigest() == SOURCE_SHA
    proof = {'成功': True, '状態': '共通可読選択器の独立準備・編集停止',
             '独立人工主群': result.testsRun, '対象コード': str(CODE.relative_to(ROOT)),
             '対象SHA256': SOURCE_SHA, '対象前後同体': True,
             '範囲': ['和/差/依存連鎖/未知/非有限', '三値all/any18組と比較厳密境界',
                    'common役割除外/OR未知枝を2技法へ水増ししない', '信号方向と注文符号/同側複数ID/両側競合',
                    'q1canonical/C1反対方向も旧優先/未取得計数/非改変', '小catalog2場1旧対照のmain',
                    'gzip/JSON/CRC/末尾/排他保存', '全decide完了前capture/meta load禁止spy',
                    'q1価格だけ変更してq0判断bytes一致'],
             '自然schema': '148features先頭1rowのキー・両side100だけ。条件適用なし。',
             '自然選択/観測ラベル/Raw/CSV/追加2場読取': False,
             'Source/既149編集': False, '重大未解決': [],
             '人工ログSHA256': hashlib.sha256(log.read_bytes()).hexdigest(),
             '私有コードSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    target = HERE / '準備の確認.json'
    target.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '人工': result.testsRun, '対象SHA256': SOURCE_SHA,
                      '停止票SHA256': hashlib.sha256(target.read_bytes()).hexdigest()}, ensure_ascii=False))


if __name__ == '__main__':
    main()
