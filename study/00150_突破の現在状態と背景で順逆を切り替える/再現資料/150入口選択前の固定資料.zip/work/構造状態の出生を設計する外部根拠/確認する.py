"""構造状態の設計メモに、確認した一次教材とローカル根拠の指紋を付ける。"""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCES = [
    ('CME Group', 'Support and Resistance', 'https://www.cmegroup.com/education/courses/technical-analysis/support-and-resistance',
     '既存高安・MAによる支持抵抗、役割転換、水準を帯として扱う説明'),
    ('StockCharts', 'Rectangle', 'https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/rectangle',
     '終値突破・量による確認と突破水準への再接近'),
    ('StockCharts', 'Wyckoff Market Analysis', 'https://chartschool.stockcharts.com/table-of-contents/market-analysis/wyckoff-analysis-articles/wyckoff-market-analysis',
     '突破失敗と、その後の低い戻り・量を伴う支持割れを分ける例'),
    ('StockCharts', 'Average Directional Index', 'https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-indicators/average-directional-index-adx',
     'DI方向とADX強度、平滑遅れ、方向転換時にも高いADXの例'),
    ('John Bollinger', 'Bollinger Band Rules', 'https://www.bollingerbands.com/bollinger-band-rules',
     '接触単独は信号でない、bandwalk、帯外終値の継続解釈、役割の異なる指標'),
    ('StockCharts', 'Support & Resistance', 'https://chartschool.stockcharts.com/table-of-contents/chart-analysis/support-and-resistance',
     '一時的な水準越えと支持抵抗帯の説明'),
]


def fingerprint(path: Path) -> dict:
    """
    機能: 小型ローカル文書と既停止根拠の指紋を保存する。
    引数: path(Path)。返り値: dictは相対path・bytes・sha256。
    """
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw),
            'sha256': hashlib.sha256(raw).hexdigest()}


def main() -> None:
    """
    機能: 設計メモのリンクと原条件不変更を確認し小証跡を作る。
    引数: なし。返り値: None。web本文の再取得や自然金融の読取を行わない。
    """
    local = [ROOT / name for name in (
        'work/次候補_入口局面と構造水準の役割を切り替える.md',
        'work/149追加代数診断の独立検査/独立検査の確認.json',
        'work/149入口の価格時計と確認遅延の点検/時計と取得位置の短報.md',
        'docs/technical-analysis/組み合わせ/DMIとADXによる方向と強さ.md',
        'work/149可読局面の入口選択/選択する.py',
        'work/149候補_可読8局面.json')]
    before = {str(path): fingerprint(path) for path in local}
    memo = HERE / 'README.md'
    text = memo.read_text(encoding='utf-8')
    external = set()
    count = 0
    for target in re.findall(r'\]\(([^)]+)\)', text):
        if target.startswith('https://'):
            external.add(target)
        elif not target.startswith('#'):
            assert (memo.parent / target.split('#', 1)[0]).exists(), target
            count += 1
    assert external == {row[2] for row in SOURCES}
    assert before == {str(path): fingerprint(path) for path in local}
    proof = {'成功': True, '編集停止': True, '確認日': '2026-11-12',
             '状態': '未採用の外部根拠・独立設計レビュー',
             'web確認': '検索後に全6ページ本文をopen。原文転載なし・要点のみ。',
             '出典': [{'提供元': provider, '題名': title, 'URL': url, '確認範囲': scope,
                       '確認日': '2026-11-12', '区分': '提供元公式教材'}
                      for provider, title, url, scope in SOURCES],
             '一次性の限界': 'StockChartsは公式解説だがWyckoff原著ではない。日足例を分足へそのまま適用しない。',
             '一般説明/心理仮説/149事実/未採用設計を分離': True,
             '当時の内側復帰と将来リテスト成功を分離': True,
             '新Source/新金融/Raw/CSV/追加2場読取/新採番': False,
             '現Source/条件変更': False, '金融事実の追加算出': False,
             'ローカルリンク実在': count, '根拠と原源の前後同体': list(before.values()),
             'メモ': fingerprint(memo), '確認コード': fingerprint(Path(__file__))}
    output = HERE / '確認の記録.json'
    output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '出典': len(SOURCES), 'ローカルリンク': count,
                      'MD_SHA256': fingerprint(memo)['sha256'],
                      '停止票SHA256': fingerprint(output)['sha256']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
