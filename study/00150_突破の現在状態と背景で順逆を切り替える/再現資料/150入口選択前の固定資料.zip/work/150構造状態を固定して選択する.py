"""150の条件と共有gzip入力を固定し、金融ラベルを渡さず全q0を選択する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT / 'work/150構造状態の評価'
FORMAL = ROOT / 'study/00150_突破の現在状態と背景で順逆を切り替える'
SELECTOR = ROOT / 'scripts/入口研究/固定特徴から可読条件を選択する.py'
BOOK = ROOT / 'inputs/00150_構造状態の可読選択/条件.json'
INPUTS = {'book': BOOK,
    'features': ROOT / 'inputs/00148_全1分入口母集団/当時特徴.json.gz',
    'captures': ROOT / 'inputs/00148_全1分入口母集団/取得対応.json.gz',
    'metadata': ROOT / 'inputs/00148_全1分入口母集団/入口参照.json.gz'}
EXPECTED = {'book': 'b0f3652a3a7f912a1e18a1c9aad8b990d9a07e7ccaa524a38cd141830d07453a',
    'features': '464dad9dce7acb20f043c344e96c9fa6d19ab0049a9d557e6fc96f6d189abcb7',
    'captures': '7c27420abe6af0867f6cf3d8fd838205da3ed099df8db8e5b5d62892cbadf6bc',
    'metadata': 'ad53cccf8e4da093ebd32c1ddc80132ddcd4c73d8f20897c4033f0895fc966b6'}


def sha(path: Path) -> str:
    """
    機能: 保存bytesを全保持せず物理SHAを求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for block in iter(lambda: source.read(1048576), b''):
            digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def load_helper() -> object:
    """
    機能: 選択器の排他保存関数だけを読み込む。
    引数: なし。
    返り値: objectは選択器モジュール。
    """
    spec = importlib.util.spec_from_file_location('可読選択150補助', SELECTOR)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


# ----------------------------------------
def verify(value: dict) -> None:
    """
    機能: 固定票に記載した全物理源の指紋を照合する。
    引数: value(dict)はファイル辞書を持つ固定票。
    返り値: None。不一致は停止。
    """
    for path, expected in value['ファイル'].items():
        assert sha(Path(path)) == expected, path


# ----------------------------------------
def main() -> None:
    """
    機能: F0条件固定→共通選択器の実行→入口固定後F1を新規保存する。
    引数: CLI mode(str)は固定又は選択。
    返り値: None。先着観測を開かず、旧試行や既存成果物を改変しない。
    """
    parser = argparse.ArgumentParser(description='150の構造状態を固定して選択する')
    parser.add_argument('--mode', choices=('固定', '選択'), required=True)
    args = parser.parse_args()
    assert sha(SELECTOR) == '2f46be32a23ce2c1e5e99f2714ed4fd1eb14c545e4e150a2efd8d112e5c5344a'
    helper = load_helper()
    OWN.mkdir(parents=True, exist_ok=True)
    f0 = OWN / 'F0入口選択前.json'
    output = OWN / '入口選択'
    if args.mode == '固定':
        assert all(sha(path) == EXPECTED[name] for name, path in INPUTS.items())
        formal_preparation = ROOT / 'work/150正式文書の準備確認.json'
        assert sha(formal_preparation) == '52a44bd8bcc4c24e4e7c9e5d074170b3dde19338593dfd6b0b133f6798aa07bb'
        prepared = json.loads(formal_preparation.read_bytes())
        assert prepared['成功'] and prepared['定義57行9尺度513セル']
        for name, expected in prepared['正式3MD'].items():
            assert sha(FORMAL / name) == expected
        for name, expected in prepared['指紋'].items():
            assert sha(ROOT / name) == expected
        files = set(INPUTS.values()) | {Path(__file__).resolve(), SELECTOR,
            formal_preparation,
            ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json',
            ROOT / 'study/00148_全1分知得から入口品質の母集団を固定する/検査/正式保存の最終確認.json',
            ROOT / 'study/00149_継続と反転を可読8局面で判定する/検査/正式保存の最終確認.json'}
        checks = [ROOT / 'work/共通可読選択器の作者人工/準備の確認.json',
            ROOT / 'work/共通可読選択器の独立準備レビュー/準備の確認.json',
            ROOT / 'work/共通可読選択器の独立準備レビュー/union範囲の追補確認.json',
            ROOT / 'work/構造状態から入口を生む容量調査/停止.json',
            ROOT / 'work/構造状態から入口を生む容量調査/FD_RT_R追補/停止.json',
            ROOT / 'work/構造状態の出生を設計する外部根拠/確認の記録.json']
        for check in checks:
            assert json.loads(check.read_bytes())['成功']
            files.update(path for path in check.parent.iterdir() if path.is_file() and path.suffix in ('.py', '.json', '.md', '.txt'))
        for name in ('README.md', '条件.md', '設定と結果.md'):
            assert (FORMAL / name).is_file()
            files.add(FORMAL / name)
        helper.save(f0, {'成功': True, '試行': 150, '段階': '入口選択前F0',
            'UTC': datetime.now(timezone.utc).isoformat(), '主政策': 'U0',
            '主ORへFAを含める': False, '金融ラベルを選択へ渡す': False,
            '全73場は既使用': True, '追加2場価格未読': True,
            'ファイル': {str(path.resolve()): sha(path) for path in sorted(files)}})
        print(json.dumps({'F0_SHA256': sha(f0), '固定源数': len(files)}, ensure_ascii=False))
        return
    fixed = json.loads(f0.read_bytes())
    verify(fixed)
    assert not output.exists()
    command = [sys.executable, '-X', 'utf8', str(SELECTOR)]
    for name, path in INPUTS.items():
        command += ['--' + name, str(path), '--' + name + '-sha256', EXPECTED[name]]
    command += ['--output-dir', str(output)]
    subprocess.run(command, cwd=ROOT, check=True)
    verify(fixed)
    decisions = helper.load(output / 'q0の判断.json')
    selected = helper.load(output / '選択の確認.json')
    assert decisions['出生判断数'] == len(decisions['rows']) == 35339 and not decisions['金融ラベル利用']
    assert selected['成功'] and selected['金融ラベル未読']
    expected = {'FA': 1259, 'FD': 820, 'RT': 51, 'RB': 350, 'N0': 1175, 'C1': 87, 'U0': 1259}
    assert selected['政策別取得数'] == expected, selected['政策別取得数']
    files = {Path(path) for path in fixed['ファイル']} | {f0}
    files.update(path for path in output.iterdir() if path.is_file())
    f1 = OWN / 'F1入口選択後.json'
    helper.save(f1, {'成功': True, '試行': 150, '段階': '全q0判断と取得参照後F1',
        'UTC': datetime.now(timezone.utc).isoformat(), 'F0_SHA256': sha(f0),
        '金融ラベルを開く前に全q0判断済み': True, '政策別取得数': expected,
        '別実装の非金融容量と全政策件数一致': True,
        '親観測SHA256': 'd1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc',
        'ファイル': {str(path.resolve()): sha(path) for path in sorted(files)}})
    print(json.dumps({'成功': True, 'F1_SHA256': sha(f1), '政策別取得数': expected}, ensure_ascii=False))


if __name__ == '__main__':
    main()
