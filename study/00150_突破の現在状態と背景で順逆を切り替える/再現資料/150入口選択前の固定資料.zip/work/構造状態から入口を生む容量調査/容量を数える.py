"""既存100特徴から構造状態の非金融容量だけを数える。"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import math
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
PLAIN=ROOT/'work/148全1分母集団の評価/母集団生成'
SAVED=ROOT/'inputs/00148_全1分入口母集団'
REFS={'当時特徴':('572705d7db8529555c876eb1953f7d8e1cd1de0e554bf9de729a7d377e4d91af','464dad9dce7acb20f043c344e96c9fa6d19ab0049a9d557e6fc96f6d189abcb7'),'取得対応':('e433b79f87411c34232acac57a8aed191da71bcd1888376b19196099cbf9909a','7c27420abe6af0867f6cf3d8fd838205da3ed099df8db8e5b5d62892cbadf6bc'),'入口参照':('66511104a6efd7bc936b0e624469a2de43e9fa5b5fa7645304499f793c25329c','ad53cccf8e4da093ebd32c1ddc80132ddcd4c73d8f20897c4033f0895fc966b6')}
TOTAL_SECONDS=720*3600+55*60
SPEC_SHA='222f2fa7496e91cebbc2c4f48cf8b3641a77584692b1edd83eec59f4c2405503'


def sha(path: Path) -> str:
    """
    機能: 共有入力を固定bufferで指紋化する。
    引数: path(Path)。返り値: str。
    """
    h=hashlib.sha256()
    with path.open('rb')as source:
        for block in iter(lambda:source.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def rows(path: Path):
    """
    機能: 固定整形JSONのrowsを全ファイル複写なしで順に読む。
    引数: path(Path)。返り値: Iterator[dict]。
    """
    decoder=json.JSONDecoder();buffer=''
    with path.open(encoding='utf-8')as source:
        while True:
            chunk=source.read(1<<20)
            if not chunk:raise ValueError('rowsなし')
            buffer+=chunk;match=re.search(r'(?m)^  "rows": \[',buffer)
            if match:buffer=buffer[match.end():];break
        while True:
            buffer=buffer.lstrip()
            if buffer.startswith(']'):return
            if buffer.startswith(','):buffer=buffer[1:].lstrip()
            try:value,end=decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                chunk=source.read(1<<20)
                if not chunk:raise ValueError('rows途中切れ')
                buffer+=chunk;continue
            yield value;buffer=buffer[end:]


def conjunction(values: list):
    """
    機能: 未知をfalseへ補わず3値ANDを求める。
    引数: values(list[bool又はNone])。返り値: bool又はNone。
    """
    return False if any(v is False for v in values)else None if any(v is None for v in values)else True


def disjunction(values: list):
    """
    機能: 既知trueを未知で消さず3値ORを求める。
    引数: values(list[bool又はNone])。返り値: bool又はNone。
    """
    return True if any(v is True for v in values)else None if any(v is None for v in values)else False


def compare(value,operation: str,threshold: float):
    """
    機能: 必要値の既知と固定不等号を分離する。
    引数: value(float又はNone)、operation(str)、threshold(float)。返り値: bool又はNone。
    """
    if value is None:return None
    assert type(value)in (int,float)and math.isfinite(value)
    return {'>':value>threshold,'>=':value>=threshold,'<':value<threshold,'<=':value<=threshold}[operation]


def evaluate(x: dict) -> dict:
    """
    機能: q0の保存100列だけでF0/Rを符号側sとして判定する。
    引数: x(dict[str,float又はNone])。返り値: dict。
    """
    gap=x['q0_last_minus_m1_close_atr5_to_side'];edge=x['q0_last_minus_prior3_forward_edge_atr5_to_side'];c_break=None if gap is None or edge is None else edge-gap
    common={'spread正':compare(x['q0_spread_points'],'>',0),'spread20以内':compare(x['q0_spread_points'],'<=',20),'知得差1以内':compare(None if gap is None else abs(gap),'<=',1)}
    fgates={**common,'終値端突破':compare(c_break,'>',0),'現在端内復帰':compare(edge,'<=',0),'先行3平均量以上':compare(x['m1_volume_relative_prior3'],'>=',1),'元側正実体':compare(x['m1_body_ratio_to_side'],'>',0)}
    reclaim=compare(x['m1_body_reclaim_atr5_to_side'],'>=',0);wick=compare(x['m1_opposite_wick_ratio'],'>=',.4);body=compare(x['m1_body_ratio_to_side'],'>',0)
    rgates={**common,'ADX20以下':compare(x['m15_adx'],'<=',20),'BB端位置':compare(x['q0_entry_minus_bbmean_sigma_to_side'],'<=',-1),'RSI5改善':compare(x['m5_rsi_delta_to_side'],'>',0),'前足量以上':compare(x['m1_volume_ratio_previous'],'>=',1),'TR1.5以内':compare(x['m1_tr_atr5_ratio'],'<=',1.5),'回復又は拒否':disjunction([reclaim,conjunction([wick,body])])}
    range_flag=compare(x['m15_adx'],'<=',25);weak_flag=compare(x['m15_adx_delta'],'<',0)
    route='レンジ'if range_flag is True else '弱化'if weak_flag is True else '強化等'if range_flag is False and weak_flag is False else '未知'
    return {'F0':{'gates':fgates,'pass':conjunction(list(fgates.values()))},'R':{'gates':rgates,'pass':conjunction(list(rgates.values()))},'route':route,'range':range_flag,'weak':weak_flag,'hist':compare(x['m5_hist_delta_atr_to_side'],'>',0),'di':compare(x['m15_di_difference_to_side'],'>',0),'cBreak':c_break,'liveBreak':edge,'R子条件':{'回復':reclaim,'逆ヒゲ':wick,'正実体':body}}


def audit(counter: dict,decision: dict) -> None:
    """
    機能: 全s判定分母で各gateと説明用累積を3値計数する。
    引数: counter(dict[str,Counter])、decision(dict)。返り値: None。
    """
    prefix=[]
    for name,value in decision['gates'].items():
        prefix.append(value);counter.setdefault('各gate/'+name,Counter())[str(value)]+=1;counter.setdefault('説明用累積/'+name,Counter())[str(conjunction(prefix))]+=1
    counter.setdefault('全条件',Counter())[str(decision['pass'])]+=1


def select_q0(candidates: list,families: tuple) -> tuple:
    """
    機能: 同q0の反対方向は待機、同方向の由来はまとめる。
    引数: candidates(list[dict])、families(tuple[str])。返り値: tuple[list,dict]。
    """
    selected=[];conflicts=[];technical=0
    for row in candidates:
        origins=[o for o in row['origins']if o['family']in families]
        if not origins:continue
        technical+=len(origins);sides={o['fill_side']for o in origins}
        if len(sides)>1:conflicts.append(row['event_id']);continue
        selected.append({**row,'fill_side':next(iter(sides)),'origins':origins})
    return selected,{'技術成立s数':technical,'成立q0':len(selected)+len(conflicts),'方向競合q0':len(conflicts),'候補q0':len(selected),'競合event_ids':conflicts}


def capacity(candidates: list,capture: dict,metadata: dict) -> dict:
    """
    機能: 判断済み候補だけを既存取得へ結合しuniqueq1/C1容量を数える。
    引数: candidates(list[dict])、capture/metadata(dict)。返り値: dict。
    """
    lookup={r['event_id']:r for r in capture['rows']};descriptors={d['case_id']:d for d in metadata['population148']['cases']};old={e['id']for e in metadata['entries']};sessions=metadata['sessions'];assert len(old)==87 and len(sessions)==73
    statuses=Counter();physical={};filled=0
    for row in candidates:
        cap=lookup[row['event_id']];assert cap['session']==row['session']and cap['contract']==row['contract']and (cap['q0']['time'],cap['q0']['index'],cap['q0']['source_line'])==(row['q0_time'],row['q0_index'],row['q0_line'])
        statuses[cap['status']]+=1
        if cap['status']!='filled':assert cap['q1']is None;continue
        filled+=1;case=cap['case_id'];d=descriptors[case];assert d['session']==row['session']and d['contract']==row['contract'];q1=cap['q1'];assert q1['quote_ok']and 0<q1['bid']<q1['ask']and row['q0_time']+1<=q1['time']<cap['expires']
        physical.setdefault(case,[]).append({**row,'case_id':case,'q1_time':q1['time'],'q1_index':q1['index'],'q1_line':q1['source_line']})
    unique={case:sorted(rs,key=lambda r:(r['q0_index'],r['q0_line'],r['event_id']))[0]for case,rs in physical.items()};union=old|set(unique);count=Counter(descriptors[k]['session']for k in unique);combined=Counter(descriptors[k]['session']for k in union)
    return {'候補q0':len(candidates),'取得状態':dict(statuses),'filled_events':filled,'uniqueq1':len(unique),'同q1追加event':filled-len(unique),'同q1複数方向由来':sum(len({r['fill_side']for r in rs})>1 for rs in physical.values()),'C1重複q1':len(old&set(unique)),'C1重複うち方向相違':sum(unique[k]['fill_side']!=descriptors[k]['original_side']for k in old&set(unique)),'C1union':len(union),'容量毎時':len(unique)/(TOTAL_SECONDS/3600),'C1union容量毎時':len(union)/(TOTAL_SECONDS/3600),'毎時1容量あり':len(unique)*3600>=TOTAL_SECONDS,'C1union毎時1容量あり':len(union)*3600>=TOTAL_SECONDS,'全73場':{s:{'単独':count[s],'C1union':combined[s]}for s in sessions},'単独0件場':[s for s in sessions if not count[s]],'C1union0件場':[s for s in sessions if not combined[s]],'単独最大場件数':max(count.values(),default=0),'C1union最大場件数':max(combined.values(),default=0)}


def main() -> None:
    """
    機能: 案固定後に全q0を判断し、その後だけ非金融取得表へ結合する。
    引数: なし。返り値: None。
    """
    inputs={HERE/'固定案.md':SPEC_SHA,SAVED/'100特徴の列定義.json':'c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4',Path(__file__):sha(Path(__file__))}
    for name,(decoded,physical)in REFS.items():
        plain=PLAIN/(name+'.json');saved=SAVED/(name+'.json.gz');assert sha(plain)==decoded and sha(saved)==physical
        digest=hashlib.sha256()
        with gzip.open(saved,'rb')as source:
            for block in iter(lambda:source.read(1<<20),b''):digest.update(block)
        assert digest.hexdigest()==decoded;inputs[plain]=decoded;inputs[saved]=physical
    assert all(sha(p)==h for p,h in inputs.items())
    stat_before={str(p):[p.stat().st_size,p.stat().st_mtime_ns]for p in inputs};catalog=json.loads((SAVED/'100特徴の列定義.json').read_bytes());indices={c['name']:i for i,c in enumerate(catalog)}
    counters={'F0':{},'R':{}};candidates=[];total=0;digest=hashlib.sha256();f0_origins=[]
    for record in rows(PLAIN/'当時特徴.json'):
        total+=1;q=record['metadata']['q0'];origins=[];trace=[]
        for side in ('buy','sell'):
            s=record[side]['side'];assert s==(1 if side=='buy'else -1);x={key:record[side]['x'][i]for key,i in indices.items()};decision=evaluate(x)
            for family in ('F0','R'):
                audit(counters[family],decision[family])
                if decision[family]['pass']is True:
                    origin={'family':family,'source_side':s,'fill_side':-s if family=='F0'else s,'route':decision['route'],'range':decision['range'],'weak':decision['weak'],'hist':decision['hist'],'di':decision['di']};origins.append(origin)
            trace.append([s,decision])
        digest.update(json.dumps([record['event_id'],trace],ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8'));digest.update(b'\n')
        if origins:candidates.append({'event_id':record['event_id'],'session':record['session'],'contract':record['contract'],'q0_time':q['time'],'q0_index':q['index'],'q0_line':q['source_line'],'origins':origins})
    assert total==35339
    with (HERE/'q0全判断の確認.json').open('x',encoding='utf-8')as target:json.dump({'成功':True,'取得表本文未読段階':True,'q0数':total,'方向s判定数':total*2,'判断digest':digest.hexdigest(),'gate分母':counters,'技術成立候補q0':len(candidates)},target,ensure_ascii=False,indent=2);target.write('\n')
    # ----------------------------------------
    # 全q0判断が完成してから、取得状態と旧C1はここだけで受け取ります。
    capture=json.loads((PLAIN/'取得対応.json').read_bytes());metadata=json.loads((PLAIN/'入口参照.json').read_bytes());assert capture['sessions']==metadata['sessions']and len(capture['rows'])==total
    capacities={};checks={}
    for name,families in [('F0',('F0',)),('R',('R',)),('union',('F0','R'))]:
        selected,check=select_q0(candidates,families);capacities[name]=capacity(selected,capture,metadata);checks[name]=check
    routes={}
    for route in ('レンジ','弱化','強化等','未知'):
        routes[route]={}
        for suffix,required in [('追加なし',()),('Hist正',('hist',)),('DI正',('di',)),('HistとDI正',('hist','di'))]:
            filtered=[{**r,'origins':[o for o in r['origins']if o['family']=='F0'and o['route']==route and all(o[k]is True for k in required)]}for r in candidates];selected,check=select_q0(filtered,('F0',));routes[route][suffix]={**check,**capacity(selected,capture,metadata)}
    flags={name:{value:sum(o[name]is expected for r in candidates for o in r['origins']if o['family']=='F0')for value,expected in [('True',True),('False',False),('None',None)]}for name in ('range','weak','hist','di')}
    assert all(sha(p)==h for p,h in inputs.items())and stat_before=={str(p):[p.stat().st_size,p.stat().st_mtime_ns]for p in inputs}
    result={'成功':True,'未採用準備':True,'金融ラベル使用':False,'Raw追加読取':False,'149所属要求':False,'全q0':total,'全s分母':total*2,'全時間秒':TOTAL_SECONDS,'全時間h':TOTAL_SECONDS/3600,'毎時1最低uniqueq1':math.ceil(TOTAL_SECONDS/3600),'gate3値と累積':counters,'主な集合':{name:{**checks[name],**v}for name,v in capacities.items()},'F0排他背景ルート':routes,'F0重複可flag':flags,'限界':'保存データの取得可能容量。選択頻度・独立標本数・運用収支・70%達成ではない。'}
    with (HERE/'結果.json').open('x',encoding='utf-8')as target:json.dump(result,target,ensure_ascii=False,indent=2,allow_nan=False);target.write('\n')
    with (HERE/'技術成立候補.json').open('x',encoding='utf-8')as target:json.dump({'成功':True,'判断digest':digest.hexdigest(),'rows':candidates},target,ensure_ascii=False,indent=2,allow_nan=False);target.write('\n')
    with (HERE/'実行の確認.json').open('x',encoding='utf-8')as target:json.dump({'成功':True,'全q0判断後に取得meta読取':True,'gzip物理解凍同体':True,'前後SHA_stat同体':True,'源':[{'path':str(p.relative_to(ROOT)).replace('\\','/'),'sha256':h,'stat':stat_before[str(p)]}for p,h in inputs.items()],'結果SHA256':sha(HERE/'結果.json'),'候補SHA256':sha(HERE/'技術成立候補.json')},target,ensure_ascii=False,indent=2);target.write('\n')
    print(json.dumps({'成功':True,'集合':{name:{key:value[key]for key in ('候補q0','filled_events','uniqueq1','C1union','C1union容量毎時')}for name,value in capacities.items()}},ensure_ascii=False))


if __name__=='__main__':
    main()
