"""3値論理・方向反転・同q0競合を自然なしで確認する。"""
from pathlib import Path
import importlib.util
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('capacity',HERE/'容量を数える.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def values() -> dict:
    """
    機能: F0が真になる保存側sの人工特徴を作る。
    引数: なし。返り値: dict。
    """
    return {'q0_spread_points':10,'q0_last_minus_m1_close_atr5_to_side':-.4,'q0_last_minus_prior3_forward_edge_atr5_to_side':0,'m1_volume_relative_prior3':1,'m1_body_ratio_to_side':.5,'m1_body_reclaim_atr5_to_side':0,'m1_opposite_wick_ratio':.2,'m15_adx':20,'m15_adx_delta':None,'q0_entry_minus_bbmean_sigma_to_side':-1,'m5_rsi_delta_to_side':1,'m1_volume_ratio_previous':1,'m1_tr_atr5_ratio':1.5,'m5_hist_delta_atr_to_side':1,'m15_di_difference_to_side':1}


class Tests(unittest.TestCase):
    """容量だけを固定する3主群。"""

    def test_未知ORと境界(self) -> None:
        """
        機能: 未知をfalse化せず回復又はヒゲ拒否を評価する。
        引数: self(Tests)。返り値: None。
        """
        self.assertTrue(m.disjunction([True,None]));self.assertIsNone(m.disjunction([False,None]));self.assertFalse(m.conjunction([False,None]))
        x=values();d=m.evaluate(x);self.assertTrue(d['F0']['pass']);self.assertTrue(d['R']['pass']);self.assertEqual(d['route'],'レンジ')
        x['q0_last_minus_prior3_forward_edge_atr5_to_side']=-.4;self.assertFalse(m.evaluate(x)['F0']['pass'])
        x=values();x['m1_body_reclaim_atr5_to_side']=None;x['m1_opposite_wick_ratio']=.4;self.assertTrue(m.evaluate(x)['R']['pass'])

    def test_同q0方向競合(self) -> None:
        """
        機能: F0は-s/Rは+sとした同時反対候補をunionで待機する。
        引数: self(Tests)。返り値: None。
        """
        candidate={'event_id':'人工','origins':[{'family':'F0','source_side':1,'fill_side':-1},{'family':'R','source_side':1,'fill_side':1}]}
        self.assertEqual(len(m.select_q0([candidate],('F0',))[0]),1);self.assertEqual(m.select_q0([candidate],('F0','R'))[1]['方向競合q0'],1)

    def test_未知を強化にしない(self) -> None:
        """
        機能: 背景の両false既知と欠測を別にする。
        引数: self(Tests)。返り値: None。
        """
        x=values();x['m15_adx']=30;self.assertEqual(m.evaluate(x)['route'],'未知');x['m15_adx_delta']=0;self.assertEqual(m.evaluate(x)['route'],'強化等');x['m15_adx_delta']=-1;self.assertEqual(m.evaluate(x)['route'],'弱化')


if __name__=='__main__':
    unittest.main(verbosity=2)
