"""元F0容量を変えずFD/RT/Rの役割別容量を一度だけ数える。"""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json

HERE=Path(__file__).resolve().parent
BASE=HERE.parent
ROOT=HERE.parents[2]
SPEC=HERE/'追補の固定案.md'
FIXED={BASE/'容量を数える.py':'798738600e3350c606cfa2fc710fc0f1af109d0b59696d3d75434cf6196a518a',BASE/'技術成立候補.json':'66bedce7e0e70ab4e4cedc111d0015c380468abd991f10cce5e35b158a2902ea',BASE/'結果.json':'88602accb1254f1f6f448343a6593766e1067a37f0672c3abe6409fc1b8e6ff1',BASE/'停止.json':'8e9db926270419d3a23266006a1b84df8d4aeef286efa7b58b76a26a154dab81',SPEC:'02fc03ee45d3e7673e4933e4b791cf16b70f9ad011be0c2f33c2d3a3dc693b4a'}
KEYS=('m15_adx','m15_adx_delta','m15_di_difference_to_side','m30_ema21_delta_atr_to_side','m5_hist_delta_atr_to_side','m1_body_reclaim_atr5_to_side','q0_last_minus_m1_close_atr5_to_side')


def module():
    """
    機能: 停止済み非金融容量の純関数だけを読み込む。
    引数: なし。返り値: ModuleType。
    """
    spec=importlib.util.spec_from_file_location('fixed_capacity',BASE/'容量を数える.py');value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


def classify(x: dict,base) -> dict:
    """
    機能: 既成立F0の元s側からFD/RTだけを判別する。
    引数: x(dict[str,float又はNone])、base(ModuleType)。返り値: dict。
    """
    range_flag=base.compare(x['m15_adx'],'<=',25);weak=base.compare(x['m15_adx_delta'],'<',0);live=None if x['m1_body_reclaim_atr5_to_side']is None or x['q0_last_minus_m1_close_atr5_to_side']is None else x['m1_body_reclaim_atr5_to_side']+x['q0_last_minus_m1_close_atr5_to_side']
    gates={'ADX25超':base.compare(x['m15_adx'],'>',25),'ADX増分非負':base.compare(x['m15_adx_delta'],'>=',0),'DI15元側正':base.compare(x['m15_di_difference_to_side'],'>',0),'EMA21増分30元側正':base.compare(x['m30_ema21_delta_atr_to_side'],'>',0),'Hist増分5元側正':base.compare(x['m5_hist_delta_atr_to_side'],'>',0),'現在実体回復正':base.compare(live,'>',0)}
    fd=base.disjunction([range_flag,weak]);rt=base.conjunction(list(gates.values()));assert not(fd is True and rt is True)
    return {'FD':fd,'RT':rt,'range':range_flag,'weak':weak,'live_recovery':live,'RTgates':gates}


def main() -> None:
    """
    機能: 追加案固定後にF0のRT必要列だけを結合し非金融容量を保存する。
    引数: なし。返り値: None。
    """
    base=module();inputs={**FIXED,Path(__file__):base.sha(Path(__file__))}
    for name,(decoded,_)in base.REFS.items():inputs[base.PLAIN/(name+'.json')]=decoded
    inputs[base.SAVED/'100特徴の列定義.json']='c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4'
    assert all(base.sha(p)==h for p,h in inputs.items());stat={str(p):[p.stat().st_size,p.stat().st_mtime_ns]for p in inputs}
    old=json.loads((BASE/'技術成立候補.json').read_bytes());old_result=json.loads((BASE/'結果.json').read_bytes());needed={r['event_id']for r in old['rows']if any(o['family']=='F0'for o in r['origins'])};catalog=json.loads((base.SAVED/'100特徴の列定義.json').read_bytes());indices={r['name']:i for i,r in enumerate(catalog)};features={}
    for r in base.rows(base.PLAIN/'当時特徴.json'):
        if r['event_id']in needed:features[r['event_id']]={s:{key:r[s]['x'][indices[key]]for key in KEYS}for s in ('buy','sell')}
    assert set(features)==needed
    candidates=[];trace=[];counts={'FD':{},'RT':{}};digest=hashlib.sha256()
    for r in old['rows']:
        origins=[]
        for origin in r['origins']:
            if origin['family']=='R':origins.append(copy.deepcopy(origin));continue
            assert origin['family']=='F0';s=origin['source_side'];x=features[r['event_id']]['buy'if s==1 else 'sell'];d=classify(x,base);assert origin['range']==d['range']and origin['weak']==d['weak']
            base.audit(counts['FD'],{'gates':{'ADXレンジ又は減速':d['FD']},'pass':d['FD']});base.audit(counts['RT'],{'gates':d['RTgates'],'pass':d['RT']})
            trace.append({'event_id':r['event_id'],'session':r['session'],'source_side':s,'values':x,'decision':d})
            for family in ('FD','RT'):
                if d[family]is True:origins.append({**origin,'family':family,'fill_side':-s if family=='FD'else s})
        if origins:candidates.append({**r,'origins':origins})
    digest.update(json.dumps(trace,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8'));assert len(trace)==1387
    with (HERE/'判断の確認.json').open('x',encoding='utf-8')as target:json.dump({'成功':True,'capture_meta_JSON結合前':True,'元F0分母':len(trace),'判断digest':digest.hexdigest(),'FD_RTゲート':counts},target,ensure_ascii=False,indent=2);target.write('\n')
    # ----------------------------------------
    # FD/RTのq0判断を凍結後にだけ元取得対応と旧C1を結合します。
    capture=json.loads((base.PLAIN/'取得対応.json').read_bytes());metadata=json.loads((base.PLAIN/'入口参照.json').read_bytes());capacities={};checks={}
    for name,families in [('FD',('FD',)),('RT',('RT',)),('R',('R',)),('FD_R',('FD','R')),('FD_RT_R',('FD','RT','R'))]:
        selected,check=base.select_q0(candidates,families);checks[name]=check;capacities[name]={**check,**base.capacity(selected,capture,metadata)}
    assert all(capacities['R'][k]==v for k,v in old_result['主な集合']['R'].items())
    assert all(base.sha(p)==h for p,h in inputs.items())and stat=={str(p):[p.stat().st_size,p.stat().st_mtime_ns]for p in inputs}
    out={'成功':True,'金融ラベル使用':False,'新採用':False,'全q0既判断のF0分母':len(trace),'FD_RTゲート':counts,'単純allF0fade比較':old_result['主な集合']['F0'],'容量':capacities,'全時間h':base.TOTAL_SECONDS/3600,'全73場':metadata['sessions'],'RT原値と判断':trace,'候補':candidates,'限界':'取得可能容量。次の主条件の成功・先着率・運用頻度ではない。'}
    with (HERE/'結果.json').open('x',encoding='utf-8')as target:json.dump(out,target,ensure_ascii=False,indent=2,allow_nan=False);target.write('\n')
    with (HERE/'実行の確認.json').open('x',encoding='utf-8')as target:json.dump({'成功':True,'元容量票不変更':True,'全源前後SHA_stat同体':True,'源':[{'path':str(p.relative_to(ROOT)).replace('\\','/'),'sha256':h,'stat':stat[str(p)]}for p,h in inputs.items()],'結果SHA256':base.sha(HERE/'結果.json')},target,ensure_ascii=False,indent=2);target.write('\n')
    print(json.dumps({'成功':True,'容量':{name:{k:v[k]for k in ('候補q0','方向競合q0','uniqueq1','C1union','C1union容量毎時')}for name,v in capacities.items()}},ensure_ascii=False))


if __name__=='__main__':
    main()
