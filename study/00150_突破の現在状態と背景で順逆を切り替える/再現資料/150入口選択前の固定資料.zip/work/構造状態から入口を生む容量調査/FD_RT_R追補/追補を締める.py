"""役割別容量の結果を短報へ保存し、金融未読のまま停止する。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 小成果のbytes指紋を返す。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 追加人工をUTF-8 strictで記録し容量短報/停止票を作る。
    引数: なし。返り値: None。
    """
    for path in HERE.glob('*.py'):ast.parse(path.read_text(encoding='utf-8'))
    process=subprocess.run([sys.executable,'-X','utf8',str(HERE/'人工検査.py')],capture_output=True,env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'})
    stdout=process.stdout.decode('utf-8','strict');stderr=process.stderr.decode('utf-8','strict');assert process.returncode==0 and '\ufffd'not in stdout+stderr
    with (HERE/'人工の確認.json').open('x',encoding='utf-8')as target:json.dump({'成功':True,'人工主群':2,'構文':True,'UTF8_strict':True,'標準出力':stdout,'標準エラー':stderr},target,ensure_ascii=False,indent=2);target.write('\n')
    result=json.loads((HERE/'結果.json').read_bytes());text=['# FD・RT・Rの非金融容量追補','','元容量票を変更せず、Rootの追加式を固定してから1回だけ件数を確認した。金融ラベル・正逆観測・Raw・CSV・追加2場は未読。未採用準備であり成績や70%達成を示さない。','','| 集合 | 技術成立s数 | 成立q0 | 競合待機q0 | 候補q0 | uniqueq1 | C1union | 単独/統合毎時 | 単独0件場数 |','|---|---:|---:|---:|---:|---:|---:|---|---:|']
    all_sets={'allF0fade':result['単純allF0fade比較'],**result['容量']}
    for name,row in all_sets.items():text.append(f"| {name} | {row['技術成立s数']} | {row['成立q0']} | {row['方向競合q0']} | {row['候補q0']} | {row['uniqueq1']} | {row['C1union']} | {row['容量毎時']:.3f}/{row['C1union容量毎時']:.3f} | {len(row['単独0件場'])} |")
    text+=['','FDはF0にADX<=25 OR ADX増分<0を追加し、少なくとも一方既知trueの919候補。820取得可能q1・旧C1統合904件で1.254件/時。FD+Rは28方向競合を待機させ、1,124 uniqueq1・C1統合1,208件で1.676件/時。','',
        'RTはF0の強化背景から、元sのDI15・EMA21増分30・Hist増分5・現在実体回復を全て要求した53候補、TTL未取得2、51 uniqueq1。FD/RTは同一元sで同時trueにならず、RTとRもADX背景が異なる。これは成功確認ではなく、元方向再試行の仮説の容量である。','',
        '主案候補FD+RT+Rは1,369技術成立s所属→1,341成立q0→反対方向競合28を待機→1,313候補→1,175 uniqueq1。TTL未取得135、品質喪失3。旧C1重複3は全て同方向で、C1統合1,259件・1.746件/時。単独には0件場が9場あるが、C1統合では全73場min1を保持する。最大場件数は単独49、C1統合50で、場ごとの頻度偏りを残す。','',
        '単純allF0fadeは1,259 uniqueq1・旧C1統合1,343件だった。主案のC1統合1,259という同じ数字は別の集合の件数であり、同体ではない。FDは−s、RT/Rは+sなので、単純allF0の方向を部分的に戻す役割分離を次に比較する材料である。','',
        '## 追加RTの削減','','元F0の1,387sを分母とする説明用累積はADX>25で581、ADX増分>=0で327、DI15元側>0で168、EMA21増分30元側>0で162、Hist増分5元側>0で84、現在実体回復>0で53。最終false1,281/unknown53/true53を区別し、未知を継続・反転へ補わない。各gate単独の分母も結果JSONへ保存した。','',
        '## 再現・境界','','追補の固定案.md→人工検査.py→追補を数える.py→追補を締める.py。FD ORは一方trueなら他unknownでもtrue、trueがなくunknownがあると非成立。ADX=25はFD側、ADX増分=0はRTの非負側、現在実体回復=0はRT不成立。30EMA増分のATR分母は当該30分ATRでありATR5へ変更しない。判定は全て元sのX、FD注文側だけ−sである。','',
        '旧F0判定票を継承し、追加必要7列だけを同q0同sの100Xから取り出した。判断digestを保存後にcapture/metaを結合。元容量票/旧R全値/入力SHA_statは不変更。価格数値を新計算せず、既存列の指定加減算だけを使用した。','',
        '総時間720時間55分に対する取得可能容量であり、実保有制約・同時注文管理・選択後trade頻度・独立標本数・運用損益は未評価。金融優位や同幅70%は次の金融前固定と保存正逆比較を経るまで不明。']
    with (HERE/'短報.md').open('x',encoding='utf-8')as target:target.write('\n'.join(text)+'\n')
    files=sorted(p for p in HERE.iterdir()if p.is_file()and p.name!='停止.json');proof={'成功':True,'編集停止':True,'元容量票不変更':True,'金融ラベル未読':True,'新条件の正式採用':False,'停止ファイル':[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}for p in files]}
    with (HERE/'停止.json').open('x',encoding='utf-8')as target:json.dump(proof,target,ensure_ascii=False,indent=2);target.write('\n')
    print(json.dumps({'成功':True,'停止SHA256':sha(HERE/'停止.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
