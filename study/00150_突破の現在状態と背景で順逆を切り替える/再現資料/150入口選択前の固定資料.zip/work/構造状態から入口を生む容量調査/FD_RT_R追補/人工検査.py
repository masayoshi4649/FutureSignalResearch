"""FDの未知ORとRTの既知全AND・境界・符号を自然なしで検査する。"""
from pathlib import Path
import importlib.util
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('supplement_capacity',HERE/'追補を数える.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);base=m.module()


class Tests(unittest.TestCase):
    """自然・金融なしの2主群。"""

    def test_役割境界と未知(self) -> None:
        """
        機能: ADX25/増分0境界と未知ORを固定条件どおりに扱う。
        引数: self(Tests)。返り値: None。
        """
        x={'m15_adx':25,'m15_adx_delta':None,'m15_di_difference_to_side':1,'m30_ema21_delta_atr_to_side':1,'m5_hist_delta_atr_to_side':1,'m1_body_reclaim_atr5_to_side':.5,'q0_last_minus_m1_close_atr5_to_side':-.4}
        self.assertTrue(m.classify(x,base)['FD']);self.assertFalse(m.classify(x,base)['RT'])
        x['m15_adx']=None;x['m15_adx_delta']=-1;self.assertTrue(m.classify(x,base)['FD'])
        x['m15_adx']=26;x['m15_adx_delta']=0;d=m.classify(x,base);self.assertFalse(d['FD']);self.assertTrue(d['RT'])
        x['q0_last_minus_m1_close_atr5_to_side']=-.5;self.assertFalse(m.classify(x,base)['RT'])

    def test_強化未知をRTへ補わない(self) -> None:
        """
        機能: RT必要値未知は不採用でFDもfalseのままにする。
        引数: self(Tests)。返り値: None。
        """
        x={k:1 for k in m.KEYS};x['m15_adx']=26;x['m15_adx_delta']=0;x['m30_ema21_delta_atr_to_side']=None
        d=m.classify(x,base);self.assertFalse(d['FD']);self.assertIsNone(d['RT'])


if __name__=='__main__':
    unittest.main(verbosity=2)
