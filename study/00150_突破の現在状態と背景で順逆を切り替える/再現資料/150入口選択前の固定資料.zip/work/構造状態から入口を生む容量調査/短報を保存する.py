"""非金融容量の正本から短報・人工ログ・停止指紋を作る。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

HERE=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 保存小成果のbytes指紋を返す。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 金融を読まず固定件数と容量限界を転記して停止する。
    引数: なし。返り値: None。
    """
    for path in HERE.glob('*.py'):ast.parse(path.read_text(encoding='utf-8'))
    process=subprocess.run([sys.executable,'-X','utf8',str(HERE/'人工検査.py')],capture_output=True,env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'})
    stdout=process.stdout.decode('utf-8','strict');stderr=process.stderr.decode('utf-8','strict');assert process.returncode==0 and '\ufffd'not in stdout+stderr
    with (HERE/'人工の確認.json').open('x',encoding='utf-8')as target:json.dump({'成功':True,'人工主群':3,'構文':True,'UTF8_strict':True,'標準出力':stdout,'標準エラー':stderr},target,ensure_ascii=False,indent=2);target.write('\n')
    result=json.loads((HERE/'結果.json').read_bytes())
    text=['# 構造状態から入口を生む容量調査','','未採用の非金融準備。固定案を先保存し、148全適格35,339q0・70,678方向s判定から構造状態だけを抽出した。149枝所属、金融ラベル、正逆観測、Raw、CSV、追加2場を使用していない。旧源/149正式は不変更。','','全q0判断digestを保存した後にだけcapture/metadataをJSON結合した。3gzipの物理/全解凍SHAを同workplainの確定SHAと照合し、入力/源の前後SHA・stat同体を確認した。データを複写していない。','','## 主な容量','','| 集合 | 技術成立s数 | 成立q0 | 競合待機q0 | 候補q0 | filled/uniqueq1 | C1重複 | C1union | 単独/統合毎時 | 単独0件場数 |','|---|---:|---:|---:|---:|---:|---:|---:|---|---:|']
    for name,row in result['主な集合'].items():
        text.append(f"| {name} | {row['技術成立s数']} | {row['成立q0']} | {row['方向競合q0']} | {row['候補q0']} | {row['filled_events']}/{row['uniqueq1']} | {row['C1重複q1']} | {row['C1union']} | {row['容量毎時']:.3f}/{row['C1union容量毎時']:.3f} | {len(row['単独0件場'])} |")
    text+=['','F0単独は1,259 uniqueq1・全73場で取得可能、1.746件/時。旧C1統合は1,343件・1.863件/時で、1時間平均1件に必要な721件の源容量を上回る。F0+Rは同q0の反対方向28件を待機させた後、1,563 uniqueq1、旧C1統合1,647件・2.285件/時。旧C1重複3件は全て同方向で、保護87件は不変更。','',
        'R単独は350件・41場で、旧C1を加えても437件・0.606件/時に留まる。全場min1はC1統合で維持できるが、1時間平均1件の主源には不足。同q1複数event/複数方向由来は今回0件。容量は最大場への偏りを許す平均であり、各1時間に必ず1件という保証ではない。','',
        'F0は128/1,387候補がTTL未取得。Rは44/397がTTL、3/397が品質喪失。unionの1,728候補ではTTL162・品質喪失3。候補成立を取得へ数えず、filledだけをunique化した。','',
        '## F0背景ルートと追加確認','','背景は価格方向sの判定を分類したもの。F0の取得方向は−sであり、Hist/DI正は反転後の向きへ読み替えない。説明用ルートはレンジ優先の排他分類。レンジと弱化の重複flagそのものは結果JSONへ別保存した。','','| 排他ルート | 追加確認 | 技術成立q0 | uniqueq1 | C1union | 統合毎時 |','|---|---|---:|---:|---:|---:|']
    for route,variants in result['F0排他背景ルート'].items():
        for variant,row in variants.items():text.append(f"| {route} | {variant} | {row['候補q0']} | {row['uniqueq1']} | {row['C1union']} | {row['C1union容量毎時']:.3f} |")
    text+=['','レンジ単独593 uniqueq1は旧C1統合678件・0.940件/時で不足する。レンジ+弱化の排他2ルートを合わせると820 uniqueq1、旧C1重複3を引いた統合904件・1.254件/時の容量になる。ただしこれは件数の合成であり、この背景を売買主条件として採用したものではない。Hist正/DI正の追加はどのルートでもさらに減り、レンジ+弱化で両方追加なら246 uniqueq1まで減る。金融性能を見て緩和・選択していない。','',
        '## どこで細るか','','全方向sの説明用累積で、共通条件trueは67,236。F0は終値端突破10,269→現在端内復帰3,028→先行3平均量以上1,599→正実体1,387。主な減少は終値端突破と現在復帰の構造、次に同足量である。ただしこの順番は説明用のAND積算であり、別々の時刻を証明するepisode状態ではない。OHLC内の全順序や実注文フローも断定しない。','',
        'Rは共通67,236→ADX<=20が18,114→BB端位置4,629→RSI改善1,524→前足量以上750→TR制限741→回復又はヒゲ拒否397。最後のORは、回復既知trueならヒゲ未知でもtrue。全条件が不明のsもF0 4,505、R 1,928として残し、未知をfalse/0/強化へ補っていない。各gate単独と累積の3値全分母は結果JSONを参照する。','',
        '## 解釈と再現','','F0には1/h以上を検証できる件数余地がある。補助Rや確認の強ANDを主源にすると再び容量不足になる可能性を非金融で確認した。70%・費用・実逆優位は一切計算しておらず、どの背景や方向が良いかは未確認。次に正式採用する場合は主/副・全q0判断・同時計実逆・旧C1保護を先固定し、この結果を勝率成功と呼ばない。','',
        '固定案.md→人工検査.py→容量を数える.py→短報を保存する.py。全q0判断の確認.jsonには判断digestと全s分母、技術成立候補.jsonは成立q0のlocator/由来だけ、結果.jsonは全73場/未取得/候補・取得・unique容量の正本。総時間720時間55分はRoot指定を固定し、選択後売買頻度や保有可能数へ読み替えない。']
    with (HERE/'短報.md').open('x',encoding='utf-8')as target:target.write('\n'.join(text)+'\n')
    files=sorted(p for p in HERE.iterdir()if p.is_file()and p.name!='停止.json');proof={'成功':True,'編集停止':True,'金融ラベル又は新損益の読取':False,'新採番又は採用':False,'旧源変更':False,'停止ファイル':[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}for p in files]}
    with (HERE/'停止.json').open('x',encoding='utf-8')as target:json.dump(proof,target,ensure_ascii=False,indent=2);target.write('\n')
    print(json.dumps({'成功':True,'停止SHA256':sha(HERE/'停止.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
