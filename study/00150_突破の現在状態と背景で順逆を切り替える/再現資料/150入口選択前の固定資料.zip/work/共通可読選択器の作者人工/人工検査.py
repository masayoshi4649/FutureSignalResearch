"""可読選択器の未知・役割・方向・取得結合を小さい人工例で検査する。"""
from pathlib import Path
import importlib.util
import unittest

ROOT = Path(__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location('可読選択器', ROOT / 'scripts/入口研究/固定特徴から可読条件を選択する.py')
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def fixture() -> tuple:
    """
    機能: 3列・2技術役割の最小条件を作る。
    引数: なし。
    返り値: tupleはbook/catalog。
    """
    catalog = [{'name': 'a', 'role': '構造'}, {'name': 'b', 'role': '量'}, {'name': 'q', 'role': '値幅'}]
    book = {'catalog_count': 3, 'minimum_technical_roles': 2, 'session_count': 1, 'legacy_count': 1,
        'derived': {'z': {'op': 'difference', 'vars': ['a', 'b']}},
        'common': {'var': 'q', 'op': '<=', 'value': 20},
        'rules': [{'id': 'F', 'order_sign': -1, 'when': {'all': [
            {'var': 'z', 'op': '>', 'value': 0}, {'var': 'b', 'op': '>', 'value': 0}]}}],
        'union_id': 'N0', 'legacy_id': 'C1', 'main_id': 'U0'}
    return book, catalog


# ----------------------------------------
class SelectorTests(unittest.TestCase):
    """当時情報と後段取得の境界を確認する。"""

    def test_未知と三値論理(self) -> None:
        """
        機能: 未知算術とall/anyの真偽を確認する。
        引数: self(SelectorTests)。
        返り値: None。
        """
        book, catalog = fixture()
        index, roles = MODULE.validate(book, catalog)
        values, dependencies = MODULE.context([3, None, 10], index, book['derived'])
        self.assertIsNone(values['z'])
        unknown = {'var': 'z', 'op': '>', 'value': 0}
        positive = {'var': 'a', 'op': '>', 'value': 0}
        negative = {'var': 'a', 'op': '<', 'value': 0}
        self.assertIsNone(MODULE.evaluate({'all': [positive, unknown]}, values, dependencies)[0])
        self.assertIs(MODULE.evaluate({'all': [negative, unknown]}, values, dependencies)[0], False)
        self.assertIs(MODULE.evaluate({'any': [positive, unknown]}, values, dependencies)[0], True)
        self.assertIsNone(MODULE.evaluate({'any': [negative, unknown]}, values, dependencies)[0])
        self.assertEqual(MODULE.decide([3, None, 10], [-3, None, 10], book, index, roles)['directions']['N0'], 0)

    def test_信号と注文の鏡像及び役割(self) -> None:
        """
        機能: 売買を同じ関数で判定し、単独役割や非有限値を拒否する。
        引数: self(SelectorTests)。
        返り値: None。
        """
        book, catalog = fixture()
        index, roles = MODULE.validate(book, catalog)
        buy, sell = [3, 1, 10], [-3, 1, 10]
        native = MODULE.decide(buy, sell, book, index, roles)
        mirrored = MODULE.decide(sell, buy, book, index, roles)
        self.assertEqual(native['directions']['N0'], -1)
        self.assertEqual(mirrored['directions']['N0'], 1)
        self.assertEqual(native['evidence'][0]['signal_side'], 1)
        self.assertEqual(native['evidence'][0]['roles'], ['構造', '量'])
        self.assertEqual(MODULE.decide(buy, buy, book, index, roles)['directions']['N0'], 0)
        book['rules'][0]['when'] = {'var': 'a', 'op': '>', 'value': 0}
        with self.assertRaises(AssertionError):
            MODULE.decide(buy, sell, book, index, roles)
        with self.assertRaises(AssertionError):
            MODULE.context([float('nan'), 1, 10], index, {})

    def test_同q1の正本と旧優先(self) -> None:
        """
        機能: 後発q0を重複計数せず、旧C1との反対方向も旧側で保持する。
        引数: self(SelectorTests)。
        返り値: None。
        """
        book, _ = fixture()
        rows, captures = [], []
        for event, index in [('later', 20), ('first', 10), ('legacy', 30)]:
            rows.append({'event_id': event, 'session': 'S', 'contract': 'K', 'q0_time': 100 + index,
                'q0_index': index, 'q0_line': index + 1, 'decision': {
                    'directions': {'F': 1, 'N0': 1}, 'conflicts': {'F': False, 'N0': False},
                    'evidence': [{'rule': 'F', 'order_side': 1, 'signal_side': -1, 'roles': ['構造', '量']}]}})
            captures.append({'event_id': event, 'session': 'S', 'contract': 'K',
                'q0': {'time': 100 + index, 'index': index, 'source_line': index + 1},
                'status': 'filled', 'case_id': 'OLD' if event == 'legacy' else 'NEW',
                'buy_stream': 'reverse' if event == 'legacy' else 'original',
                'sell_stream': 'original' if event == 'legacy' else 'reverse'})
        descriptors = [{'case_id': 'OLD', 'session': 'S', 'contract': 'K', 'original_side': -1,
            'c1_reused': True, 'buy_stream': 'reverse', 'sell_stream': 'original'},
            {'case_id': 'NEW', 'session': 'S', 'contract': 'K', 'original_side': 1,
            'c1_reused': False, 'buy_stream': 'original', 'sell_stream': 'reverse'}]
        result = MODULE.connect(rows, captures, descriptors, ['S'], book)
        self.assertEqual(len(result['政策']['U0']), 2)
        self.assertEqual(result['政策']['N0'][0]['event_id'], 'first')
        self.assertEqual(result['候補と取得']['N0']['duplicate_q1'], 1)
        self.assertEqual(result['政策']['U0'][0]['side'], -1)
        self.assertTrue(result['旧C1重複'][0]['opposite'])

    def test_診断対照を主ORへ混ぜない(self) -> None:
        """
        機能: 追加の逆方向対照は残し、union_rulesで主OR対象だけを選ぶ。
        引数: self(SelectorTests)。
        返り値: None。
        """
        book, catalog = fixture()
        book['rules'].append({'id': 'D', 'order_sign': 1, 'when': book['rules'][0]['when']})
        index, roles = MODULE.validate(book, catalog)
        self.assertEqual(MODULE.decide([3, 1, 10], [-3, 1, 10], book, index, roles)['directions']['N0'], 0)
        book['union_rules'] = ['F']
        MODULE.validate(book, catalog)
        decision = MODULE.decide([3, 1, 10], [-3, 1, 10], book, index, roles)
        self.assertEqual(decision['directions'], {'F': -1, 'D': 1, 'N0': -1})
        book['union_rules'] = ['未定義']
        with self.assertRaises(AssertionError):
            MODULE.validate(book, catalog)


if __name__ == '__main__':
    unittest.main(verbosity=2)
