"""150正式文書の原文・513セル・先頭状態・リンクだけを非金融で確認する。"""
from pathlib import Path
import gzip
import hashlib
import json
import re
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
FORMAL = ROOT / 'study/00150_突破の現在状態と背景で順逆を切り替える'


def fingerprint(path: Path) -> dict:
    """
    機能: 小文書の物理bytesを指紋化する。
    引数: path(Path)。返り値: dict。
    """
    raw = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def rows(text: str) -> list[str]:
    """
    機能: 後追記表を除き版7の57行だけを抽出する。
    引数: text(str)。返り値: list[str]。
    """
    return [line for line in text.splitlines() if re.match(r'^\|\s+[A-Z]\d{2}\s+\|', line)
            and len(line.split('|')) == 13]


def main() -> None:
    """
    機能: 原文prefix・513セル・README先頭・全ローカルリンクを確認して停止する。
    引数: なし。返り値: None。金融/ラベルJSONやリンク先本文を開かず正式を編集しない。
    """
    author = FORMAL / '検査/正式資料の最終反映確認.json'
    snapshot = FORMAL / '検査/F1実行前文書.json.gz'
    paths = [FORMAL / name for name in ('README.md', '条件.md', '設定と結果.md')] + [author, snapshot]
    before = {path: fingerprint(path) for path in paths}
    assert before[author]['sha256'] == '3db75b92056d19fb7f08eb348b61ae6470d5584cc551cb3569ea91dca356df02'
    old = json.loads(gzip.decompress(snapshot.read_bytes()))
    by_path = {item['path'].replace('\\', '/'): item for item in old['文書']}
    original = {}
    for name in ('README.md', '条件.md', '設定と結果.md'):
        item = by_path[(FORMAL / name).relative_to(ROOT).as_posix()]
        raw = item['本文'].encode('utf-8')
        assert hashlib.sha256(raw).hexdigest() == item['sha256']
        original[name] = raw
    for name in ('条件.md', '設定と結果.md'):
        assert (FORMAL / name).read_bytes().startswith(original[name])
    current = rows((FORMAL / '設定と結果.md').read_text(encoding='utf-8'))
    assert current == rows(original['設定と結果.md'].decode('utf-8')) and len(current) == 57
    assert len({r.split('|')[1].strip() for r in current}) == 57
    assert all(len(r.split('|')[3:-1]) == 9 for r in current)
    readme = (FORMAL / 'README.md').read_text(encoding='utf-8')
    intro = readme.split('\n\n')[1]
    assert '実行・保存済み' in intro and '主U0' in intro and '未達・不採用' in intro
    links = 0
    for path in paths[:3]:
        for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            if '://' in target or target.startswith('#'): continue
            local = unquote(target.strip('<>').split('#', 1)[0])
            assert (path.parent / local).exists(), (path.name, target)
            links += 1
    assert before == {path: fingerprint(path) for path in paths}
    proof = {'成功': True, '試行': 150, '編集停止': True,
             '条件/設定のF1元全bytesがprefix保持': True,
             'V7': {'手法': 57, '尺度': 9, 'セル': 513, '全57行文字同体': True},
             'README先頭': '実行・保存済み/主U0未達・不採用', '全ローカルリンク実在': links,
             '金融/ラベルJSON/Raw/追加2場読取': False, '金額/率の妥当性検査': False,
             '金融の数値確認': 'Root別算術票へ分離', '正式/他準備編集': False,
             '対象前後同体': list(before.values()), '確認コード': fingerprint(Path(__file__))}
    output = HERE / '確認の記録.json'
    output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'セル': 513, 'リンク': links,
                      '停止票SHA256': fingerprint(output)['sha256']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
