"""根拠側/注文側・固定境界・旧当時条件所属を自然なしで確認する。"""
from pathlib import Path
import importlib.util
import unittest

HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('diagnosis150',HERE/'診断する.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


class Tests(unittest.TestCase):
    """自然なし3主群。"""

    def test_形状量の等号と未知(self) -> None:
        """
        機能: 根拠側の.5/1/1.25境界を重複しない群にする。
        引数: self(Tests)。返り値: None。
        """
        signal={'m1_body_range_prior3_to_side':.5,'m1_volume_relative_prior3':1};order={'m5_ema21_delta_to_side':1,'m15_ema21_delta_to_side':1,'m30_ema21_delta_to_side':1,'m30_di_difference_to_side':1}
        out=m.classifiers(signal,order);self.assertEqual(out['形状'],'>=.5');self.assertEqual(out['量'],'[1,1.25)')
        signal['m1_volume_relative_prior3']=1.25;self.assertEqual(m.classifiers(signal,order)['量'],'>=1.25');signal['m1_volume_relative_prior3']=None;self.assertEqual(m.classifiers(signal,order)['量'],'未知')

    def test_注文側raw背景とゼロ(self) -> None:
        """
        機能: 注文側負方向・ゼロ・未知を根拠側から混ぜず判定する。
        引数: self(Tests)。返り値: None。
        """
        signal={'m1_body_range_prior3_to_side':0,'m1_volume_relative_prior3':0};order={'m5_ema21_delta_to_side':-1,'m15_ema21_delta_to_side':-2,'m30_ema21_delta_to_side':-3,'m30_di_difference_to_side':-4}
        out=m.classifiers(signal,order);self.assertEqual((out['30分方向'],out['5/15/30方向']),('両<0','全<0'))
        order['m30_ema21_delta_to_side']=0;out=m.classifiers(signal,order);self.assertEqual((out['30分方向'],out['5/15/30方向']),('混在','混在ゼロ'))
        order['m30_ema21_delta_to_side']=None;self.assertEqual(m.classifiers(signal,order)['30分方向'],'未知')

    def test_競合でも旧成立IDを保持(self) -> None:
        """
        機能: 149最終方向0を条件不成立へ読み替えず向き別IDを照合する。
        引数: self(Tests)。返り値: None。
        """
        old={'判断':{'成立ID':{'1':['T4'],'-1':['T4','R3']},'方向':{'T4':0}}}
        self.assertTrue(m.old_member(old,'T4',1));self.assertTrue(m.old_member(old,'T4',-1));self.assertTrue(m.old_member(old,'R3',-1));self.assertFalse(m.old_member(old,'R3',1))


if __name__=='__main__':
    unittest.main(verbosity=2)
