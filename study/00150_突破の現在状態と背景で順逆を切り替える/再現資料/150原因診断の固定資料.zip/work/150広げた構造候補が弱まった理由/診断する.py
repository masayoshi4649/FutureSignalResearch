"""150の選択済み構造候補を先固定した形状・量・方向・旧所属で診断する。"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import importlib.util
import json
import math
import re

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
SELECT=ROOT/'work/150構造状態の評価/入口選択/選択対応.json'
SUMMARY=ROOT/'work/150構造状態の評価/金融診断/集計.json'
X=ROOT/'inputs/00148_全1分入口母集団/当時特徴.json.gz'
CAPTURE=ROOT/'inputs/00148_全1分入口母集団/取得対応.json.gz'
OBS=ROOT/'study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz'
CATALOG=ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json'
OLD_DECISIONS=ROOT/'work/149可読8局面の評価/入口選択/q0の判断.json'
OLD_SELECT=ROOT/'work/149可読8局面の評価/入口選択/選択対応.json'
CALCULATE=ROOT/'work/149局面の位置と急変と実反転の診断/診断する.py'
SPEC=HERE/'区分の固定.md'
EXPECTED={SELECT:'f6d5441a58f305d2f123011d85dca472629d5b18c7772614c0ecb6e0d9a29f16',SUMMARY:'d878c8e3df3fcda25324741cc92f5f7b9d5342a3097d88f2062e03db5d414178',X:'464dad9dce7acb20f043c344e96c9fa6d19ab0049a9d557e6fc96f6d189abcb7',CAPTURE:'7c27420abe6af0867f6cf3d8fd838205da3ed099df8db8e5b5d62892cbadf6bc',OBS:'bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61',CATALOG:'c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4',OLD_DECISIONS:'3ef42f65f50db41f243dd753528484dee6e90bc20362e6ce87dc37a25de1f2b4',OLD_SELECT:'ecb45e18bccad7c8df50dc7edb9908233a453108e73ff41196af328cbb5eeacb',CALCULATE:'963044ab01273131755f4f6df963af986e49a44d0100fa6258c4b340f1e9140a',SPEC:'8fbb99c1a0772487dcd233a67f56160415d2d8a25b294d2220728b57163c033b'}
DECODED={X:'572705d7db8529555c876eb1953f7d8e1cd1de0e554bf9de729a7d377e4d91af',CAPTURE:'e433b79f87411c34232acac57a8aed191da71bcd1888376b19196099cbf9909a',OBS:'d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'}
POLICIES=('FA','FD','RT','RB')
KEYS=('m1_body_range_prior3_to_side','m1_volume_relative_prior3','m30_ema21_delta_to_side','m30_di_difference_to_side','m5_ema21_delta_to_side','m15_ema21_delta_to_side')
LEVELS={'形状':('>=.5','<.5','未知'),'量':('>=1.25','[1,1.25)','<1','未知'),'30分方向':('両>0','両<0','混在','未知'),'5/15/30方向':('全>0','全<0','混在ゼロ','未知')}


def sha(path: Path,decoded: bool=False) -> str:
    """
    機能: 圧縮又は全解凍bytesの指紋とCRCを検査する。
    引数: path(Path)、decoded(bool)。返り値: str。
    """
    h=hashlib.sha256()
    with (gzip.open(path,'rb')if decoded else path.open('rb'))as source:
        for block in iter(lambda:source.read(1<<20),b''):h.update(block)
    return h.hexdigest()


def array_items(path: Path,key: str):
    """
    機能: 固定整形gzip/plain JSONの指定トップ配列を一つずつ読む。
    引数: path(Path)、key(str)。返り値: Iterator[dict]。
    """
    decoder=json.JSONDecoder();buffer=''
    with (gzip.open(path,'rt',encoding='utf-8')if path.suffix=='.gz'else path.open(encoding='utf-8'))as source:
        while True:
            block=source.read(1<<20)
            if not block:raise ValueError('配列なし')
            buffer+=block;match=re.search(r'(?m)^  "'+re.escape(key)+r'": \[',buffer)
            if match:buffer=buffer[match.end():];break
        while True:
            buffer=buffer.lstrip()
            if buffer.startswith(']'):
                source.read();return
            if buffer.startswith(','):buffer=buffer[1:].lstrip()
            try:record,end=decoder.raw_decode(buffer)
            except json.JSONDecodeError:
                block=source.read(1<<20)
                if not block:raise ValueError('配列途中切れ')
                buffer+=block;continue
            yield record;buffer=buffer[end:]


def classifiers(signal: dict,order: dict) -> dict:
    """
    機能: 根拠側の形状/量と注文側のraw背景符号を固定分類する。
    引数: signal/order(dict[str,float又はNone])。返り値: dict。
    """
    body=signal['m1_body_range_prior3_to_side'];volume=signal['m1_volume_relative_prior3'];ema=order['m30_ema21_delta_to_side'];di=order['m30_di_difference_to_side'];all_ema=[order[k]for k in ('m5_ema21_delta_to_side','m15_ema21_delta_to_side','m30_ema21_delta_to_side')]
    return {'形状':'未知'if body is None else '>=.5'if body>=.5 else '<.5','量':'未知'if volume is None else '>=1.25'if volume>=1.25 else '[1,1.25)'if volume>=1 else '<1','30分方向':'未知'if ema is None or di is None else '両>0'if ema>0 and di>0 else '両<0'if ema<0 and di<0 else '混在','5/15/30方向':'未知'if any(x is None for x in all_ema)else '全>0'if all(x>0 for x in all_ema)else '全<0'if all(x<0 for x in all_ema)else '混在ゼロ'}


def old_member(record: dict,policy: str,side: int) -> bool:
    """
    機能: 最終方向が待機でも149当時の向き別全成立IDから所属を得る。
    引数: record(dict)、policy(str)、side(int)。返り値: bool。
    """
    return policy in record['判断']['成立ID'][str(side)]


def load_calculation():
    """
    機能: 停止済みquote直接算術だけを私有importする。
    引数: なし。返り値: ModuleType。
    """
    spec=importlib.util.spec_from_file_location('fixed149quote',CALCULATE);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


def strata(rows: list,sessions: list,arithmetic) -> dict:
    """
    機能: 指定単軸・形状×量・当時旧所属を元群固定で前後比較する。
    引数: rows(list[dict])、sessions(list[str])、arithmetic(ModuleType)。返り値: dict。
    """
    out={}
    for part,scope in [('all',sessions),('train',sessions[:48]),('validation',sessions[48:])]:
        out[part]={}
        for policy in POLICIES:
            selected=[r for r in rows if r['policy']==policy and r['session']in scope]
            singles={name:{level:arithmetic.paired([r for r in selected if r['bins'][name]==level])for level in levels}for name,levels in LEVELS.items()}
            cross={body:{volume:arithmetic.paired([r for r in selected if r['bins']['形状']==body and r['bins']['量']==volume])for volume in LEVELS['量']}for body in LEVELS['形状']}
            for bins in singles.values():assert sum(x['元方向']['件数']for x in bins.values())==len(selected)
            assert sum(x['元方向']['件数']for bins in cross.values()for x in bins.values())==len(selected)
            old={}if policy=='RT'else {state:arithmetic.paired([r for r in selected if r['旧当時条件成立']is value])for state,value in [('成立',True),('不成立又は未知',False)]}
            if old:assert sum(x['元方向']['件数']for x in old.values())==len(selected)
            out[part][policy]={'全取得':arithmetic.paired(selected),'単軸':singles,'形状×量':cross,'旧T4又はR3当時所属':old}
    return out


def main() -> None:
    """
    機能: 準備停止後に選択済みq0/同q1と旧当時判断を結合し診断する。
    引数: なし。返り値: None。
    """
    preparation=HERE/'準備の確認.json';prep=json.loads(preparation.read_bytes());assert prep['成功']and all(sha(ROOT/p)==h for p,h in prep['源'].items())
    assert all(sha(p)==h for p,h in EXPECTED.items())and all(sha(p,True)==h for p,h in DECODED.items());before={**EXPECTED,preparation:sha(preparation)};stat={str(p):[p.stat().st_size,p.stat().st_mtime_ns]for p in before}
    selection=json.loads(SELECT.read_bytes());summary=json.loads(SUMMARY.read_bytes());sessions=selection['全73場'];assert len(sessions)==73
    needed={c['event_id']for policy in POLICIES for c in selection['政策'][policy]};ids={c['case_id']for policy in POLICIES for c in selection['政策'][policy]};catalog=json.loads(CATALOG.read_bytes());indices={column['name']:i for i,column in enumerate(catalog)};features={}
    for record in array_items(X,'rows'):
        if record['event_id']in needed:features[record['event_id']]={'session':record['session'],'contract':record['contract'],'q0':record['metadata']['q0'],'sides':{side:{key:record[side]['x'][indices[key]]for key in KEYS}for side in ('buy','sell')}}
    assert set(features)==needed
    old_all=json.loads(OLD_DECISIONS.read_bytes());old={r['event_id']:r for r in old_all['rows']if r['event_id']in needed};assert set(old)==needed
    with gzip.open(CAPTURE,'rt',encoding='utf-8')as source:captures={r['event_id']:r for r in json.load(source)['rows']if r['event_id']in needed}
    assert set(captures)==needed;cases={};scene_count=0
    for scene in array_items(OBS,'scenes'):
        assert scene['success'];scene_count+=1
        for case in scene['cases']:
            if case['id']in ids:assert case['id']not in cases;cases[case['id']]={'session':scene['session'],'execution_end':scene['execution_end'],'case':case}
    assert scene_count==73 and set(cases)==ids
    arithmetic=load_calculation();rows=[];foundation=Counter()
    for policy in POLICIES:
        physical=set()
        for choice in selection['政策'][policy]:
            event=choice['event_id'];feature=features[event];old_q0=old[event];cap=captures[event];witness=cases[choice['case_id']];case=witness['case'];order_side=choice['side'];matches=[h for h in choice['evidence']if h['rule']==policy and h['order_side']==order_side];signal_sides={h['signal_side']for h in matches};assert len(signal_sides)==1
            signal_side=next(iter(signal_sides));assert order_side==signal_side*(-1 if policy in ('FA','FD')else 1)
            q0=feature['q0'];assert (q0['time'],q0['index'],q0['source_line'])==(choice['q0_time'],choice['q0_index'],choice['q0_line'])==(old_q0['q0_time'],old_q0['q0_index'],old_q0['q0_line'])
            assert feature['session']==choice['session']==old_q0['session']==cap['session']==witness['session']and feature['contract']==old_q0['contract']==cap['contract'];assert cap['status']=='filled'and cap['case_id']==choice['case_id']
            stream=choice['stream'];inverse='reverse'if stream=='original'else 'original';q1=case[stream]['entry'];assert q1==cap['q1']==case[inverse]['entry']and choice['stream']==cap['buy_stream'if order_side==1 else 'sell_stream']
            assert case[stream]['birth']['side']==order_side==-case[inverse]['birth']['side']and q0['time']+1<=q1['time']<cap['expires']and q1['time']<witness['execution_end'];foundation['同q1']+=1
            key=(choice['session'],feature['contract'],q1['time'],q1['index'],q1['source_line']);assert key not in physical;physical.add(key)
            for name in (stream,inverse):
                o=next(x for x in case[name]['outcomes']if x['seconds']==3600);t=next(x for x in o['touches']if x['width']==125)
                if t['quote']:assert q1['time']<=t['quote']['time']<=o['deadline']and t['quote']['time']<witness['execution_end'];foundation['touch']+=1
                if o['endpoint']:assert o['deadline']<=o['endpoint']['time']<=o['deadline']+30 and o['endpoint']['time']<witness['execution_end'];foundation['endpoint']+=1
            signal=feature['sides']['buy'if signal_side==1 else 'sell'];order=feature['sides']['buy'if order_side==1 else 'sell'];old_policy='T4'if policy in ('FA','FD')else 'R3'if policy=='RB'else None;member=old_member(old_q0,old_policy,signal_side if policy in ('FA','FD')else order_side)if old_policy else None
            rows.append({'policy':policy,'session':choice['session'],'contract':feature['contract'],'case_id':choice['case_id'],'event_id':event,'signal_side':signal_side,'order_side':order_side,'stream':stream,'q0_time':q0['time'],'q1_time':q1['time'],'q0_to_q1':q1['time']-q0['time'],'signal_values':signal,'order_values':order,'bins':classifiers(signal,order),'旧条件ID':old_policy,'旧当時条件成立':member,'native':arithmetic.one(case[stream]),'inverse':arithmetic.one(case[inverse])})
    result=strata(rows,sessions,arithmetic)
    for part in result:
        for policy in POLICIES:
            actual=result[part][policy]['全取得']['元方向'];expected=summary['集計'][part][policy]['BBO']['3600']['125']
            for a,b in [('件数','entries'),('F','forward'),('A','adverse'),('N','neither'),('C','censored'),('IFD既知','ifd_known'),('IFD未知','ifd_unknown'),('C5利益','ifd_net5_profit'),('C5損失絶対','ifd_net5_loss'),('C5差引','ifd_net5_sum')]:assert actual[a]==expected[b],(part,policy,a)
    old_selected=json.loads(OLD_SELECT.read_bytes());sets={p:{r['case_id']for r in old_selected['政策'][p]}for p in ('T4','R3')};comparison={}
    for policy in ('FA','FD','RB'):
        old_policy='T4'if policy in ('FA','FD')else 'R3';current={r['case_id']for r in rows if r['policy']==policy};membership={r['case_id']for r in rows if r['policy']==policy and r['旧当時条件成立']}
        comparison[policy]={'旧政策':old_policy,'旧選択取得':len(sets[old_policy]),'新選択取得':len(current),'新選択中の旧当時条件所属':len(membership),'旧選択とのcase交差':len(current&sets[old_policy]),'旧選択にない取得':len(current-sets[old_policy])}
    assert all(sha(p)==h for p,h in before.items())and stat=={str(p):[p.stat().st_size,p.stat().st_mtime_ns]for p in before}
    output={'成功':True,'試行':150,'全期事後':True,'新条件又は主変更':False,'全73場':sessions,'層別':result,'旧件数との差':comparison,'同q1とphase':dict(foundation),'元注文12対照の全stat一致':True,'詳細':rows,'限界':['RTはnormalized列のknownが主条件。本診断のraw符号分類と別','F2_SHA256という150既存keyは入口F1を指す。固定JSONは変更しない','全期既使用・小群・近接H60依存・複数固定区分']}
    with (HERE/'診断.json').open('x',encoding='utf-8')as target:json.dump(output,target,ensure_ascii=False,indent=2,allow_nan=False);target.write('\n')
    with (HERE/'診断の確認.json').open('x',encoding='utf-8')as target:json.dump({'成功':True,'全源前後SHA_stat同体':True,'gzip全解凍SHA_CRC一致':True,'源':{str(p.relative_to(ROOT)).replace('\\','/'):h for p,h in before.items()},'出力SHA256':sha(HERE/'診断.json'),'延べ選択所属':len(rows),'unique選択q0':len(needed),'unique取得':len(ids),'元注文12対照一致':True},target,ensure_ascii=False,indent=2);target.write('\n')
    print(json.dumps({'成功':True,'延べ':len(rows),'旧件数との差':comparison,'診断SHA256':sha(HERE/'診断.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
