"""全stat照合・近接依存を追加し、固定層別結果を短報へまとめる。"""
from pathlib import Path
from collections import Counter
from statistics import mean
import ast
import hashlib
import json
import math

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: 小成果のbytes指紋を返す。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def full_stats(rows: list) -> dict:
    """
    機能: 保存quote再算済み個票から固定正本の全statを再構成する。
    引数: rows(list[dict])。返り値: dict。
    """
    states=Counter(r['native']['state']for r in rows);n=len(rows);complete=n-states['C'];f=states['F'];a=states['A'];known=[r['native']for r in rows if r['native']['ifd_known']];nets=[v['net5']for v in known];gain=sum(v for v in nets if v>0);loss=-sum(v for v in nets if v<0)
    exits=Counter('観測不足'if not r['native']['ifd_known']else '順行到達'if r['native']['touch_direction']==1 else '逆行到達'if r['native']['touch_direction']==-1 else '期限清算'for r in rows)
    return {'entries':n,'sessions':len({r['session']for r in rows}),'complete':complete,'censored':states['C'],'forward':f,'adverse':a,'neither':states['N'],'resolved':f+a,'resolved_rate':f/(f+a)if f+a else None,'complete_rate':f/complete if complete else None,'target70':f/(f+a)>=.7 if f+a else None,'target70_all':f/complete>=.7 if complete else None,'ifd_known':len(known),'ifd_unknown':n-len(known),'ifd_exits':dict(exits),'ifd_net0_sum':sum(v+1000 for v in nets)if known else None,'ifd_net5_sum':sum(nets)if known else None,'ifd_net5_mean':mean(nets)if known else None,'ifd_net5_profit':gain if known else None,'ifd_net5_loss':loss if known else None,'ifd_net5_pf':gain/loss if loss else None,'ifd_net5_positive':sum(v>0 for v in nets),'ifd_points_mean':mean(v['points']for v in known)if known else None,'flips':sum(r['stream']=='reverse'for r in rows)}


def dependence(rows: list,sessions: list) -> dict:
    """
    機能: 同枝の名目H60窓連結と全場の0件/集中を残す。
    引数: rows(list[dict])、sessions(list[str])。返り値: dict。
    """
    counts=Counter(r['session']for r in rows);groups=[]
    for sid in sessions:
        end=None;size=0
        for time in sorted(r['q1_time']for r in rows if r['session']==sid):
            if end is None or time>=end:
                if size:groups.append(size)
                end=time+3600;size=1
            else:end=max(end,time+3600);size+=1
        if size:groups.append(size)
    return {'取得数':len(rows),'対象場数':len(sessions),'取得場数':len(counts),'全場件数':{s:counts[s]for s in sessions},'名目H60連結群数':len(groups),'最大連結群件数':max(groups,default=0),'最大場件数':max(counts.values(),default=0),'上位5場割合':sum(sorted(counts.values(),reverse=True)[:5])/len(rows)if rows else None}


def main() -> None:
    """
    機能: 元注文12対照の全statと固定層別を照合し新選択なしで停止する。
    引数: なし。返り値: None。
    """
    for p in HERE.glob('*.py'):ast.parse(p.read_text(encoding='utf-8'))
    source=HERE/'診断.json';data=json.loads(source.read_bytes());summary_path=ROOT/'work/150構造状態の評価/金融診断/集計.json';assert sha(summary_path)=='d878c8e3df3fcda25324741cc92f5f7b9d5342a3097d88f2062e03db5d414178';summary=json.loads(summary_path.read_bytes());sessions=data['全73場'];results=data['層別'];rows=data['詳細'];full={};dependency={};checks=0
    for part,scope in [('all',sessions),('train',sessions[:48]),('validation',sessions[48:])]:
        full[part]={};dependency[part]={}
        for policy in ('FA','FD','RT','RB'):
            selected=[r for r in rows if r['policy']==policy and r['session']in scope];actual=full_stats(selected);expected=summary['集計'][part][policy]['BBO']['3600']['125'];assert set(actual)==set(expected)
            for key,value in actual.items():
                if type(value)is float:assert math.isclose(value,expected[key],rel_tol=1e-12,abs_tol=1e-8),(part,policy,key)
                else:assert value==expected[key],(part,policy,key)
                checks+=1
            full[part][policy]=results[part][policy]['全取得'];dependency[part][policy]=dependence(selected,scope)
    output={'成功':True,'全stat検査セル数':checks,'全stat一致':True,'全12実正逆対照':full,'近接依存':dependency,'旧件数との差':data['旧件数との差'],'全期事後':True,'新条件採用':False}
    with (HERE/'要約.json').open('x',encoding='utf-8')as target:json.dump(output,target,ensure_ascii=False,indent=2,allow_nan=False);target.write('\n')
    text=['# 150 構造候補を広げて弱まった領域','','主U0の未達後に指定区分を先固定し、FA/FD/RT/RBの選択済み取得だけを同q1の実BBO正逆で診断した。主・条件・閾値・Source・正式は不変更。全期既使用、全期事後・複数比較・小群であり、前48/後25を未知期とは呼ばない。','','根拠signal側で形状/量、注文order側でraw EMA増分/DIを分類した。FA/FDはorder=−signal、RT/RBは同方向。実逆でも元群を変えず1−pを使わない。2480枝所属をunique全体へ加算せず、枝内は同q1重複0。元注文12対照の全24stat=288セルを固定150と一致確認した。','','## 元注文側と同時点実逆','','| 期間 | 枝 | 全件 | 注文 F/A/N/C | 注文C5円 | 実逆 F/A/N/C | 実逆C5円 | 注文/実逆IFD未知 |','|---|---|---:|---|---:|---|---:|---|']
    for part,policies in full.items():
        for policy,pair in policies.items():
            a=pair['元方向'];b=pair['実逆'];text.append(f"| {part} | {policy} | {a['件数']} | {'/'.join(str(a[k])for k in 'FANC')} | {a['C5差引']:,} | {'/'.join(str(b[k])for k in 'FANC')} | {b['C5差引']:,} | {a['IFD未知']}/{b['IFD未知']} |")
    text+=['','C5合計は各側の既知集合であり、両IFD既知ペア差と未知増減は診断JSONへ分離した。H不足でも既知touchはIFDへ残す。これらはmini1枚代用で、同時IFD合計を実口座収支と呼ばない。','','## 旧良群そのものと追加領域','','| 新枝 | 旧条件の元取得 | 新取得 | 同q0同方向の旧当時条件所属 | 所属群の注文F/A/N/C | 所属群C5円 | 非所属群C5円 |','|---|---:|---:|---:|---|---:|---:|']
    for policy in ('FA','FD','RB'):
        compare=data['旧件数との差'][policy];groups=results['all'][policy]['旧T4又はR3当時所属'];a=groups['成立']['元方向'];b=groups['不成立又は未知']['元方向'];text.append(f"| {policy} | {compare['旧政策']} {compare['旧選択取得']} | {compare['新選択取得']} | {compare['新選択中の旧当時条件所属']} | {'/'.join(str(a[k])for k in 'FANC')} | {a['C5差引']:,} | {b['C5差引']:,} |")
    text+=['','旧T4の64取得から、signal側がT4成立かつ知得時端復帰に該当する26件はFA/FDへ全件残り、注文側16F/4A/4N/2C・+112,998円を再現した。前17件+61,691円、後9件+51,307円も同体であり、同じ小群の価格/符号が壊れたわけではない。FAに追加された1233件は465F/549A・−2,553,092円、FD追加794件は294F/351A・−1,708,213円。26件の良さを広い失敗突破状態へ外挿できなかった。','',
        '旧149の当時成立IDをsignal側で直接確認しており、最終方向が両方向待機でも成立証拠を残した。日付・同caseの勝敗で旧所属を決めていない。旧64全てをFAへ移す比較でもなく、残る38件の取得漏れ利益を評価していない。','',
        'RBは旧R3全59取得を含み28F/16A・+109,611円を再現した。一方追加291件は102F/91A/46N/52C・−85,482円、IFD未知25。前期追加181件は−219,320円、後期110件は+133,838円と分かれる。旧R3の前逆実体と回復という束を、回復又はヒゲ拒否へ広げた領域は同じ技術domainとみなせない。逆側へ一律変更しても追加群は−1,195,328円へ悪化する。','',
        '## 固定した形状・量・背景だけでは救済しない','',
        '- signal側の実体/先行3幅>=.5かつ量/先行3平均>=1.25でもFA531件は195F/232A・−1,204,501円、FD356件は130F/149A・−685,488円。実逆も各−1,486,501円/−1,122,565円。旧26件の形状と量に似せるだけでは再現しない。','- FA全体は形状>=.5が687件、<.5が570件、未知2。高量>=1.25も944件あり、単に小実体又は量不足が全不達の理由ではない。FDも同様で、各単軸・全12形状×量群を診断JSONに残した。','- 注文側30EMA増分とDI30が両>0のFA450件は188F/190A・−561,418円、FD321件は125F/142A・−601,793円。5/15/30のEMA増分全>0でもFA316件141F/124A・−252,639円、FD199件78F/85A・−433,861円。上位方向への整合を単一に追加すれば70%になるとは示していない。','- RT全51件のraw三幅EMA増分は全て注文方向>0だが23F/21A/5N/2C・−52,927円。方向整合だけで費用後優位は保証されず、実逆15F/27A・−228,773円も改善しない。主RTはnormalized増分列のknown条件を別に持ち、本診断のraw符号分類へ置換したものではない。','- RBの形状<.5群は251件98F/77A・+100,982円、>=.5群81件30F/25A・−15,083円。形状の大小を全枝共通の強弱に読み替えない。注文側三幅EMA全<0は279件で102F/88A・−69,481円。未知群38件は13F/7A・+150,151円だが、未知を有利な売買条件に採用していない。','',
        '残る問いは、構造端への復帰だけでなく、その直前の推進状態・位置・背景の位相が同じかである。旧T4は低ADXかつ増分非負、5分gap/Hist改善、先行3幅に対する実体・位置・量を束ねる。FDのADX<=25 OR ADX低下はそれより広い別状態を含む。今回の指定層別では各要因を因果的に分離しておらず、どの省略条件が原因かは未証明。旧26の全束の保護/対照と追加領域を別にした次仕様で検証する問いに留め、今回の良い群を新主へ選んでいない。','',
        '## 依存・品質・再現','',
        '同q1/capture/選択stream/全Quote、H60touch/endpointのザラバ内、全入力の物理/解凍SHA/CRC・前後statを検査した。既存150のF2_SHA256というkeyは入口F1を指していたため由来の注意を残したが、固定JSONや数値は修正していない。','',
        '要約JSONへ全73/前48/後25の名目[q1,q1+3600)strict連結群・最大群・上位5場割合・0件場を保存した。連結群は独立標本数ではない。各群の未知と0件の率nullを残し、相関・小群を有意性へ読み替えない。','',
        '区分の固定.md→準備する.py→診断する.py→正本照合と短報を保存する.py。100Xを全転記せず、選択済みq0に必要な6列のsignal/order向きのみ保存した。正逆観測は既存gzipを直接参照し、巨大解凍副本を作らない。']
    with (HERE/'短報.md').open('x',encoding='utf-8')as target:target.write('\n'.join(text)+'\n')
    files=sorted(p for p in HERE.iterdir()if p.is_file()and p.name!='停止.json');proof={'成功':True,'編集停止':True,'主又はSource変更':False,'新条件金融選択':False,'全stat照合セル':checks,'停止ファイル':[{'name':p.name,'bytes':p.stat().st_size,'sha256':sha(p)}for p in files]}
    with (HERE/'停止.json').open('x',encoding='utf-8')as target:json.dump(proof,target,ensure_ascii=False,indent=2);target.write('\n')
    print(json.dumps({'成功':True,'全stat照合セル':checks,'停止SHA256':sha(HERE/'停止.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
