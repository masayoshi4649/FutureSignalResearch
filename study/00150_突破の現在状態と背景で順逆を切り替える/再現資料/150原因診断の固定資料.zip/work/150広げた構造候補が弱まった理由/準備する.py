"""150事後診断の指定区分・人工・源を自然診断前に固定する。"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: 小さなソースのbytes指紋を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 区分固定後の人工だけをUTF-8 strictで実行し準備票にする。
    引数: なし。返り値: None。
    """
    spec=importlib.util.spec_from_file_location('prepare150diagnosis',HERE/'診断する.py');diagnosis=importlib.util.module_from_spec(spec);spec.loader.exec_module(diagnosis)
    files=[*sorted(HERE.glob('*.py')),HERE/'区分の固定.md',diagnosis.CALCULATE];before={str(p.relative_to(ROOT)).replace('\\','/'):sha(p)for p in files}
    for path in HERE.glob('*.py'):ast.parse(path.read_text(encoding='utf-8'))
    process=subprocess.run([sys.executable,'-X','utf8',str(HERE/'人工検査.py')],capture_output=True,env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'});stdout=process.stdout.decode('utf-8','strict');stderr=process.stderr.decode('utf-8','strict');assert process.returncode==0 and '\ufffd'not in stdout+stderr
    assert all(sha(ROOT/path)==h for path,h in before.items());proof={'成功':True,'事後診断前':True,'主又は条件変更':False,'区分票SHA256':diagnosis.EXPECTED[diagnosis.SPEC],'人工主群':3,'構文':True,'UTF8_strict':True,'標準出力':stdout,'標準エラー':stderr,'源':before,'予定入力SHA256':{str(p.relative_to(ROOT)).replace('\\','/'):h for p,h in diagnosis.EXPECTED.items()}}
    with (HERE/'準備の確認.json').open('x',encoding='utf-8')as target:json.dump(proof,target,ensure_ascii=False,indent=2,allow_nan=False);target.write('\n')
    print(json.dumps({'成功':True,'準備SHA256':sha(HERE/'準備の確認.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
