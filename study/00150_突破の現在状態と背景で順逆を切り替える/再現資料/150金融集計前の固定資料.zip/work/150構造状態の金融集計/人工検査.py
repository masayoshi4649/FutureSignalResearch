"""自然金融を使わず720表・主除外・累計未知・gzip境界を検査する。"""
from pathlib import Path
import copy
import gzip
import hashlib
import importlib.util
import json
import tempfile
import unittest

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def module(path: Path,name: str):
    """
    機能: mainを実行せず人工用の純部品を読む。
    引数: path(Path)、name(str)。返り値: ModuleType。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value


m=module(HERE/'集計する.py','aggregate150test')
fixture148=module(ROOT/'work/148母集団の診断集計/人工検査.py','fixture148for150')


def fixture() -> tuple:
    """
    機能: 人工73場/87caseへ固定12政策を結合する。
    引数: なし。返り値: tuple。
    """
    observed,fixed,meta,ledger,capture=fixture148.fixture()
    for d in meta['population148']['cases']:d.update({'buy_stream':'original'if d['original_side']==1 else 'reverse','sell_stream':'reverse'if d['original_side']==1 else 'original'})
    base=module(m.PREPARE,'base148for150test');records,members,sessions,phase=base.prepare(observed,fixed,meta,ledger,capture,False)
    legacy=[{'case_id':key,'session':r['session'],'side':r['case']['original_side'],'stream':'original','event_id':None,'feature_ref':None,'origin':'C1'}for key,r in records.items()]
    policies={'C1':legacy,'U0':list(reversed(copy.deepcopy(legacy)))}
    for i,policy in enumerate(('FA','FD','RT','RB')):
        row=copy.deepcopy(legacy[i]);row.update({'origin':policy,'event_id':policy,'feature_ref':policy,'q0_time':99,'q0_index':8,'q0_line':9,'成立ID':[policy]});policies[policy]=[row]
    policies['N0']=[{**copy.deepcopy(policies[p][0]),'origin':'N0'}for p in ('FD','RT','RB')]
    selection={'成功':True,'試行':150,'選択時の金融ラベル利用':False,'政策':policies,'旧C1重複':[],'候補と取得':{},'全73場':sessions}
    parent=module(m.PARENT,'private149for150test');parent.POLICIES=m.POLICIES;arith=module(m.ARITHMETIC,'private124for150test');arith.POLICIES=m.POLICIES;arith.selected=m.selected
    return m.bind_choices(records,members,selection,False),sessions,fixed,selection,meta,parent,arith


class Tests(unittest.TestCase):
    """自然本文なしの4主群。"""

    def test_全720表と取得時刻順(self) -> None:
        """
        機能: 12政策720条件と累計入り三表・元売側の実逆を確認する。
        引数: self(Tests)。返り値: None。
        """
        records,sessions,fixed,selection,meta,parent,arith=fixture();values,p,f,goals,overlaps=parent.calculate(records,sessions,fixed['scenes'],arith);tables,curves=m.tables(records,sessions,values,p,f,overlaps,selection,meta,parent,arith)
        self.assertEqual([(len(t['rows']),len(t['headers']))for t in tables],[(720,34),(87,47),(73,64)])
        self.assertEqual(tables[1]['rows'][0][4],'人工00/0');self.assertEqual(m.selected(records['人工00/0'],'RU0','BBO')['birth']['side'],1)
        self.assertEqual(curves['U0'][sessions[-1]]['累計既知差引'],values['all']['U0']['BBO']['3600']['125']['ifd_net5_sum'])
        self.assertTrue(all(row[3]=='FA診断専用'for row in tables[0]['rows']if row[2]in ('FA','RFA')))

    def test_累計未知は既知後もnull(self) -> None:
        """
        機能: 未知1件を0円とせず後の既知利益でも確定総額を回復させない。
        引数: self(Tests)。返り値: None。
        """
        first=m.cumulative_step({}, {'ifd_net5_profit':100,'ifd_net5_loss':50,'ifd_unknown':0});self.assertEqual(first['累計全件確定差引'],50)
        second=m.cumulative_step(first,{'ifd_net5_profit':None,'ifd_net5_loss':None,'ifd_unknown':1});third=m.cumulative_step(second,{'ifd_net5_profit':200,'ifd_net5_loss':0,'ifd_unknown':0})
        self.assertEqual(third['累計既知差引'],250);self.assertEqual(third['累計IFD未知'],1);self.assertIsNone(third['累計全件確定差引'])

    def test_FA主混入を拒否(self) -> None:
        """
        機能: 固定主N0へ診断専用FAを混ぜた保存参照を拒否する。
        引数: self(Tests)。返り値: None。
        """
        records,_,_,selection,_,_,_=fixture();selection['政策']['N0'][0]['成立ID']=['FA'];members={'C0':set(list(records)[:81]),'C1':set(records)}
        with self.assertRaises(AssertionError):m.bind_choices(records,members,selection,False)

    def test_gzipCRCと解凍SHA(self) -> None:
        """
        機能: 解凍副本なし読取とCRC末尾/decodedSHA不一致の拒否を確認する。
        引数: self(Tests)。返り値: None。
        """
        with tempfile.TemporaryDirectory()as folder:
            path=Path(folder)/'人工.json.gz';body=json.dumps({'日本語':'人工'},ensure_ascii=False).encode('utf-8');path.write_bytes(gzip.compress(body,mtime=0));physical=m.sha(path);decoded=hashlib.sha256(body).hexdigest()
            self.assertEqual(m.load(path,physical,decoded),{'日本語':'人工'})
            with self.assertRaises(AssertionError):m.load(path,physical,'0'*64)
            damaged=bytearray(path.read_bytes());damaged[-8]^=1;path.write_bytes(damaged)
            with self.assertRaises((OSError,EOFError)):m.load(path,m.sha(path),decoded)


if __name__=='__main__':
    unittest.main(verbosity=2)
