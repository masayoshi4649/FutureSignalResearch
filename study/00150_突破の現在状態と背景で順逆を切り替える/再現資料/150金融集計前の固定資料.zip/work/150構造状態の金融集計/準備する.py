"""自然本文を開かず150集計の人工・構文・源を固定する。"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import os
import subprocess
import sys

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: 指定源のbytes指紋を求める。
    引数: path(Path)。返り値: str。
    """
    digest=hashlib.sha256()
    with path.open('rb')as source:
        for block in iter(lambda:source.read(1<<20),b''):digest.update(block)
    return digest.hexdigest()


def main() -> None:
    """
    機能: UTF-8人工だけを実行し本CLI未実行の準備票を保存する。
    引数: なし。返り値: None。
    """
    spec=importlib.util.spec_from_file_location('preparation150',HERE/'集計する.py');aggregate=importlib.util.module_from_spec(spec);spec.loader.exec_module(aggregate)
    sources=list(dict.fromkeys([*sorted(HERE.glob('*.py')),HERE/'条件.md',ROOT/'work/148母集団の診断集計/人工検査.py',*aggregate.SOURCES]));before={p:sha(p)for p in sources};assert all(before[p]==h for p,h in aggregate.SOURCES.items())
    for path in HERE.glob('*.py'):ast.parse(path.read_text(encoding='utf-8'))
    command=[sys.executable,'-X','utf8',str(HERE/'人工検査.py')];process=subprocess.run(command,cwd=ROOT,capture_output=True,env={**os.environ,'PYTHONUTF8':'1','PYTHONIOENCODING':'utf-8','PYTHONDONTWRITEBYTECODE':'1'});stdout=process.stdout.decode('utf-8','strict');stderr=process.stderr.decode('utf-8','strict');assert process.returncode==0 and '\ufffd'not in stdout+stderr
    assert all(sha(p)==h for p,h in before.items());proof={'成功':True,'試行':150,'自然金融集計':False,'自然価格又はRaw読取':False,'構文':True,'人工主検査数':4,'UTF8_strict':True,'実行':{'引数':command,'終了値':process.returncode,'標準出力':stdout,'標準エラー':stderr},'源':[{'path':str(p.relative_to(ROOT)).replace('\\','/'),'sha256':h,'bytes':p.stat().st_size}for p,h in before.items()],'前後指紋一致':True,'三表契約':{'正逆比較':[720,34],'入口別診断':[1259,47],'全セッション':[73,64]},'未知累積の全件確定差引':None,'Root実行待ち':True,'独立役':'本作者は149/148/124作者算術を再用。Root固定141の独立算術とは別。'}
    target=HERE/'準備の確認.json'
    with target.open('x',encoding='utf-8')as output:json.dump(proof,output,ensure_ascii=False,indent=2,allow_nan=False);output.write('\n')
    print(json.dumps({'成功':True,'準備票SHA256':sha(target),'三表契約':proof['三表契約']},ensure_ascii=False))


if __name__=='__main__':
    main()
