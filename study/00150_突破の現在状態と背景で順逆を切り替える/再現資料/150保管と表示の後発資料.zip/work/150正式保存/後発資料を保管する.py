"""150の保存・表示・限定独立監査を事前固定とは別の小型資料へ保管する。"""
from pathlib import Path
import json
from 保存部品 import ROOT, FORMAL, file_sha, save, resolve, json_bytes


def main() -> None:
    """
    機能: CSVと保存再現の証跡を保存し、後発小型源を共有又はZIP化する。
    引数: なし。結果やSource・条件bookを変更しない。
    返り値: None。大入力・観測・支援画像を重複複写しない。
    """
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    runtime = ROOT / 'work/150構造状態の評価'
    replay = ROOT / 'work/150恒久保存からの再集計/保存観測からの再現確認.json'
    assert file_sha(replay) == '28d1097af5cfc3c2e6a66d314db0296e1ee01c7cd8d602e1c94c540dddcd9b1a'
    csv_proof = runtime / '金融診断/CSV独立再読.json'
    checked = json.loads(csv_proof.read_bytes())
    assert checked['成功'] and checked['全データセル比較数'] == 88325 and checked['数値比較数'] == 43403
    saved = [save(replay, FORMAL / '検査/保存観測からの再現確認.json', file_sha(replay)),
             save(csv_proof, FORMAL / '検査/CSV独立再読.json', file_sha(csv_proof))]
    paths = list(Path(__file__).parent.glob('*.py'))
    paths += [ROOT / 'work/150正式文書を準備する.py',
              ROOT / 'work/150入口選択の独立全件監査/監査する.py',
              ROOT / 'work/150入口選択の独立全件監査/監査の確認.json']
    paths += list((ROOT / 'work/150累計と圧縮の独立準備レビュー').glob('*'))
    paths += [ROOT / 'work/確定三表のCSV出力/出力する.mjs',
              ROOT / 'work/確定三表のCSV出力/CSVを独立再読する.py',
              ROOT / 'work/確定三表のCSV出力/由来.json']
    items = {str(path): file_sha(path) for path in paths if path.is_file()}
    groups = resolve(items, '保管と表示の後発資料', [])
    packed = groups['固定ZIP']
    prior = FORMAL / '再現資料' / packed['ZIP']
    renamed = prior.with_name('150保管と表示の後発資料.zip')
    assert not renamed.exists()
    prior.rename(renamed)
    packed['ZIP'] = renamed.name
    output = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/150_突破状態と背景の切替'
    expected = {'正逆比較.csv': '1181e390d2b510d0fae637a6580c7c51ce7284fb2cad1219ed1c5dae54c44e1e',
                '入口別診断.csv': '7ead7d4cf1061e29c98621919f8a0e9b85048c7739be03de2c5bbc6f77cd65ff',
                '全セッション.csv': '4c4ad5a98c329dd1b831c3626654c3761cf499b88e49d4a247543db4d2479105'}
    outputs = []
    for name, digest in expected.items():
        path = output / name
        assert file_sha(path) == digest
        outputs.append({'保存元': path.relative_to(ROOT).as_posix(), 'SHA256': digest, 'bytes': path.stat().st_size})
    images = list((output / '支援画像').glob('*.png'))
    assert len(images) == 3
    index.update({'後発保存再現と表示の復元参照': groups, '後発保存証跡': saved,
        'CSV正本': outputs, 'CSV再読全セル': 88325, 'CSV再読数値': 43403,
        '支援PNG': [{'path': path.relative_to(ROOT).as_posix(), 'SHA256': file_sha(path)} for path in images],
        'Root支援PNG目視': 'Rootが2026-11-12の完了通知で3画像目視確認を報告。CSV転記検査・金融別算術と分離。',
        '後発資料はF0F1へ遡及固定': False,
        '段階': '金融・CSV・事後原因・保存再現を保管、最終文書独立確認待ち'})
    index_path.write_bytes(json_bytes(index))
    print(json.dumps({'成功': True, '後発ZIP_SHA256': file_sha(renamed), '保管索引SHA256': file_sha(index_path)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
