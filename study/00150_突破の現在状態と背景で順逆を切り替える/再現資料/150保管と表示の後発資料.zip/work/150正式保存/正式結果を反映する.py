"""150の固定条件・513セルを保ったまま正式3MDへ実行結果を記す。"""
from pathlib import Path
import gzip
import hashlib
import json
import re
from 保存部品 import ROOT, FORMAL, CORE, file_sha, json_bytes, write

CSV = '../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/150_突破状態と背景の切替/'


def number(value: object) -> str:
    """
    機能: 未知を0へ変えず整数を閲覧向けに整形する。
    引数: value(object)は整数又はNone。
    返り値: strは表示値。
    """
    return 'null' if value is None else f'{value:,}'


# ----------------------------------------
def rows(text: str) -> list:
    """
    機能: 版7の57手法と9尺度のセルを抽出する。
    引数: text(str)はMarkdown本文。
    返り値: listは元順の11セル行。
    """
    result = []
    for line in text.splitlines():
        parts = [item.strip() for item in line.split('|')[1:-1]]
        if len(parts) == 11 and re.fullmatch(r'[A-Z]\d{2}', parts[0]):
            result.append(parts)
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: 保存金融JSONから結果表を作り実行前原文との同体を検査する。
    引数: なし。未達後に条件・主政策・元表設定を変更しない。
    返り値: None。旧試行・選択・Source・金融正本は不変更。
    """
    source = FORMAL / '成果物/集計.json'
    assert file_sha(source) == 'd878c8e3df3fcda25324741cc92f5f7b9d5342a3097d88f2062e03db5d414178'
    summary = json.loads(source.read_bytes())
    with gzip.open(FORMAL / '検査/F1実行前文書.json.gz', 'rb') as stream:
        snapshot = json.load(stream)
    originals = {Path(item['path']).name: item['本文'] for item in snapshot['文書']}
    for name in CORE:
        assert (FORMAL / name).read_text(encoding='utf-8') == originals[name]
    stats = lambda policy, part='all': summary['集計'][part][policy]['BBO']['3600']['125']
    main_value = stats('U0')
    policy_lines = ['| 政策 | 取得/参加場 | 順/逆/未/不足 | 到達済み先着率 | C5既知利益 | C5既知損失 | C5既知差引 | IFD未知 |',
                    '| --- | --- | --- | --- | --- | --- | --- | --- |']
    for policy in ('C0','C1','RC1','FA','RFA','FD','RT','RB','N0','RN0','U0','RU0'):
        v = stats(policy)
        policy_lines.append(f"| {policy} | {v['entries']}/{v['sessions']} | {v['forward']}/{v['adverse']}/{v['neither']}/{v['censored']} | {v['resolved_rate']:.2%} | {number(v['ifd_net5_profit'])}円 | {number(v['ifd_net5_loss'])}円 | {number(v['ifd_net5_sum'])}円 | {v['ifd_unknown']} |")
    policy_table = '\n'.join(policy_lines)
    split_lines = ['| 参考区分 | 取得 | 順/逆/未/不足 | 到達済み先着率 | 平均取得/時 | C5既知利益 | C5既知損失 | C5既知差引 | IFD未知 |',
                   '| --- | --- | --- | --- | --- | --- | --- | --- | --- |']
    for part, title in [('train','前48場'),('validation','後25場'),('all','全73場')]:
        v = stats('U0', part)
        split_lines.append(f"| {title} | {v['entries']} | {v['forward']}/{v['adverse']}/{v['neither']}/{v['censored']} | {v['resolved_rate']:.2%} | {summary['頻度'][part]['U0']['全時間取得毎時']:.4f} | {number(v['ifd_net5_profit'])}円 | {number(v['ifd_net5_loss'])}円 | {number(v['ifd_net5_sum'])}円 | {v['ifd_unknown']} |")
    nav = f'[全セッションCSV]({CSV}全セッション.csv) / [入口別CSV]({CSV}入口別診断.csv) / [正逆比較CSV]({CSV}正逆比較.csv) / [金融正本](成果物/集計.json) / [固定条件](条件.md) / [設定と結果](設定と結果.md) / [保管索引](保管索引.json)'
    results = f'''## 金融結果・主U0は未達

主U0は全73場で1,259取得、場別1〜50回、全720時間55分を分母に平均1.7464回/時。参加と頻度の条件は満たしたが、同幅±125pt/H60の到達済み先着率は**484/(484+481)=50.16%**で70%に届かなかった。主をRB等へ交換せず不採用とする。

Hcompleteは1,116件、未到達151・観測不足143を残す。全1,259取得中の順行先着比は{main_value['forward']/main_value['entries']:.2%}、観測完了中の順行先着比は{main_value['complete_rate']:.2%}。50.16%は全取引勝率でも参加率でもない。観測不足でも早い到達が既知の場合があるため、IFD未知53件と観測不足143件は同じ分類ではない。

IFD既知1,206件のC5小計は**利益6,528,878円／損失7,899,740円／差引−1,370,862円**、利益/損失比0.8265。未知53件を0円にせず、全件確定差引はnullとする。手数料のみC0費用でも差引−164,862円で、C5との差−1,206,000円は既知1,206件×追加往復滑り1,000円に対応する。

{policy_table}

金額は全て独立mini1枚IFD代用の既知小計。C0という政策名と、手数料だけの「費用C0」を区別する。政策C0は旧81、C1は旧87、RC1はC1の同取得時点の実逆。RFA/RN0/RU0も保存実BBOの反対側であり、1−pの推測ではない。FA/RFAは背景なし反転の診断専用で主ORへ含めていない。

旧C1は87件・42順18逆21未6不足、到達済み率70%、既知差引+210,532円を維持したが頻度0.1207回/時である。N0は1,175件/64場、未参加9場、平均1.6299回/時・49.01%。旧C1との同case重複3件を旧優先にしてU0を1,259件とした。新候補を足せば旧70%を維持できるという仮説は支持されなかった。

## 前後期間と独立性の限界

{chr(10).join(split_lines)}

前後は全て既使用期間。後25場を未知期検証とは呼ばない。名目[q1,q1+H60)のstrict重複連結は全179群、最大46件/群であり、1,259取得を独立標本数や実同時保有可能数として数えない。連結群も独立性を証明する数ではない。

全73場min1・平均1回/時は満たす一方、先着率70%と費用後小計は未達。RTの整合条件は51件/52.27%にとどまり「リテスト成功」「再加速確認が成功した」とは呼ばない。RBの既知差引+24,129円も到達済み54.85%・41場・小さい頻度の個別診断であり、結果後の主採用としない。149の事後26件で見えた実逆80%は、状態を広げた本試行では再現しなかった。
'''
    old = originals['README.md']
    body = old[old.index('## 仮説と候補'):old.index('## 実行前の固定と再現予定')]
    readme = f'''# 00150 突破の現在状態と背景で順逆を切り替える

**実行・保存済み。主U0は全場参加と平均頻度を満たしたが、到達済み先着率50.16%で未達・不採用。** FD/RT/RBのORと旧C1全87を事前固定したまま評価し、結果後に閾値や主政策を交換していない。

{nav}

{results}

{body}

## 固定・再現と検査

F0入口選択前 `86f4295511108024f209cf5ceb607043c4f033e73020250510e513a0513aab81`、F1入口選択後 `d19e311a695da3de2098956e1fee4eda28bae924f65bc0c8c452938b3131bcdf`、金融前F2 `222b357225105a136575bfa1e914858bbe78515b11e4348a016b9e1c879bcd07`。各原文とF0/F1の実行前3MDは恒久保存した。

全35,339q0の独立選択監査と、Rootの720比較・17,280統計値の別算術検算が成功。CSV三表はRootが生成し、全88,325セル・数値43,403セルを独立再読、3画像を目視確認した。CSVの主詳細はq1時刻順。全セッション表は既知利益/損失/差引累計とIFD未知累計を分け、未知発生後の全件確定差引はnullを維持する。

数値条件は[条件JSON](../../inputs/00150_構造状態の可読選択/条件.json)、共通Sourceは[可読選択器](../../scripts/入口研究/固定特徴から可読条件を選択する.py)。148の3入力gzip・100列・大観測を共有し、150へ複製していない。集計正本のキーF2_SHA256にはCLIへ渡した入口F1(d19e…)が記録されているため、実金融前F2(222b…)とは保管索引と再現手順で分ける。作者の固定JSONは改変しない。後発の原因診断は別資料へ残し、本条件の事後変更には使わない。
'''
    (FORMAL / 'README.md').write_text(readme, encoding='utf-8', newline='\n')
    appendix = f'''\n\n---

## 150 金融実行後の追記

上段はF0/F1で固定した実行前記録であり、条件・閾値・513セルは変更していない。現在は自然選択・金融診断が完了。主U0は1,259取得/73場、484順481逆151未143不足、到達済み率50.1554%、平均1.7464回/時。C5既知利益6,528,878円・損失7,899,740円・差引−1,370,862円、未知53。参加・頻度は満たしたが70%未達で不採用。主の交換なし。

{policy_table}

全政策の金額・率は[金融正本](成果物/集計.json)と[README結果](README.md)を参照する。C1旧87は42/18/21/6・70%・C5既知差引+210,532円で同体。FAは主OR外、RTは成功したリテストの確認ではない。別算術720比較17,280値、CSV全88,325セル再読が成功。新閾値は採用しない。選択・金融は全期既使用の独立ケース診断で実口座収支ではなく、未知を0として全件確定収支を出さない。
'''
    for name in ('条件.md', '設定と結果.md'):
        (FORMAL / name).write_text(originals[name] + appendix, encoding='utf-8', newline='\n')
        assert (FORMAL / name).read_bytes().startswith(originals[name].encode('utf-8'))
    assert rows(originals['設定と結果.md']) == rows((FORMAL / '設定と結果.md').read_text(encoding='utf-8'))
    assert len(rows(originals['設定と結果.md'])) == 57
    actual_links = []
    for name in CORE:
        for match in re.finditer(r'\[[^\]]+\]\(([^)]+)\)', (FORMAL / name).read_text(encoding='utf-8')):
            link = match.group(1).split('#')[0]
            if link and '://' not in link:
                assert (FORMAL / link).exists(), (name, link)
                actual_links.append((name, link))
    proof = {'成功': True, '試行': 150, '正式3MD': {name: file_sha(FORMAL / name) for name in CORE},
        '条件と設定の元prefix保持': True, '57行513セル同体': True, '主未達と全場頻度を区別': True,
        '全政策実数を金融正本から生成': True, 'リンク数': len(actual_links), '全リンク実在': True,
        '金融SHA256': file_sha(source), '元数値/Source/旧試行を変更': False}
    write(FORMAL / '検査/正式結果の反映確認.json', json_bytes(proof))
    print(json.dumps(proof['正式3MD'], ensure_ascii=False))


if __name__ == '__main__':
    main()
