"""150のF0/F1を保存実体だけから復元照合する。金融内容を読まない。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile
from 保存部品 import ROOT, FORMAL, file_sha, json_bytes, write


def references(value: object, result: dict) -> None:
    """
    機能: 当試行の保管台帳から物理源の復元参照を集める。
    引数: value(object)は台帳の部分木、result(dict)はSHAから参照への辞書。
    返り値: None。価格・金融・選択本文を構造解析しない。
    """
    if isinstance(value, list):
        for child in value:
            references(child, result)
        return
    if not isinstance(value, dict):
        return
    if all(key in value for key in ('保存元', '解凍SHA256', '形式')):
        result[value['解凍SHA256']] = value
    if value.get('形式') == '文書snapshot':
        result[value['sha256']] = value
    if all(key in value for key in ('ZIP', 'ZIP_SHA256', '格納源')):
        for item in value['格納源']:
            result[item['sha256']] = {'形式': 'ZIP', '保存元ZIP': (FORMAL / '再現資料' / value['ZIP']).relative_to(ROOT).as_posix(),
                'ZIP_SHA256': value['ZIP_SHA256'], 'ZIP内path': item['path'], 'sha256': item['sha256']}
    for child in value.values():
        references(child, result)


# ----------------------------------------
def restored_sha(reference: dict, cache: dict) -> str:
    """
    機能: 保存ファイル・gzip・小ZIP・文書snapshotの原文指紋を検査する。
    引数: reference(dict)は復元参照、cache(dict)は照合済み物理ファイル。
    返り値: strは復元bytesのSHA256。共用gzipは再解凍しない。
    """
    source = ROOT / reference.get('保存元', reference.get('保存元ZIP', ''))
    expected = reference.get('保存SHA256', reference.get('ZIP_SHA256'))
    if source not in cache:
        cache[source] = file_sha(source)
    assert cache[source] == expected, str(source)
    kind = reference['形式']
    if kind == '同体':
        return cache[source]
    if kind == 'ZIP':
        with zipfile.ZipFile(source) as bundle:
            return hashlib.sha256(bundle.read(reference['ZIP内path'])).hexdigest()
    if kind == '文書snapshot':
        with gzip.open(source, 'rb') as packed:
            items = json.load(packed)['文書']
        original = next(item for item in items if item['path'] == reference['抽出キー'])
        return hashlib.sha256(original['本文'].encode('utf-8')).hexdigest()
    assert kind == 'gzip', kind
    digest = hashlib.sha256()
    with gzip.open(source, 'rb') as packed:
        for chunk in iter(lambda: packed.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 49直接源の保存復元と現在指紋を照合し正式検査票を保存する。
    引数: なし。現在の正式3MDも実行前状態のままか確認する。
    返り値: None。旧試行・固定源・選択・金融を変更しない。
    """
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    refs, cache = {}, {}
    references(index, refs)
    rows = []
    counts = {}
    for stage in ('F0', 'F1'):
        frozen = json.loads((ROOT / index[stage + '原文']['保存元']).read_bytes())
        assert file_sha(ROOT / index[stage + '原文']['保存元']) == index[stage + '_SHA256']
        counts[stage] = len(frozen['ファイル'])
        for name, expected in frozen['ファイル'].items():
            assert expected in refs, name
            reference = refs[expected]
            actual = restored_sha(reference, cache)
            assert actual == expected and file_sha(Path(name)) == expected, name
            rows.append({'段階': stage, 'path': Path(name).relative_to(ROOT).as_posix(), 'sha256': expected,
                         '形式': reference['形式'], '保存復元と現在源一致': True})
    assert counts == {'F0': 45, 'F1': 49}
    unique = {item['path']: item['sha256'] for item in rows}
    assert len(unique) == 49
    saved = index['新共用入力']
    assert len(saved) == 3
    proof = {'成功': True, '試行': 150, 'F0_SHA256': index['F0_SHA256'], 'F1_SHA256': index['F1_SHA256'],
        '全直接源数': counts, '全unique源数': len(unique), '保存bytesから全源復元一致': True,
        '正式3MDは実行前のまま': True, '共有入力3gzipは物理bytesで照合': True,
        '共有入力の新解凍': False, '選択3JSONは各一度gzip': True,
        '新3JSONの元bytes': sum(item['解凍bytes'] for item in saved),
        '新3gzipの保存bytes': sum(item['保存bytes'] for item in saved),
        '金融/観測/Raw/追加2場の本文読取': False, '全照合': rows, '重大不足': []}
    output = FORMAL / '検査/F0F1全源の復元参照確認.json'
    write(output, json_bytes(proof))
    index['F0F1復元参照確認'] = {'保存元': output.relative_to(ROOT).as_posix(), 'SHA256': file_sha(output)}
    index_path.write_bytes(json_bytes(index))
    print(json.dumps({'成功': True, '復元票SHA256': file_sha(output), '保管索引SHA256': file_sha(index_path),
                      '元bytes': proof['新3JSONの元bytes'], '保存bytes': proof['新3gzipの保存bytes']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
