"""150の恒久復元・条件不変・結果案内・リンクを最終検査する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import re
import zipfile
from 保存部品 import ROOT, FORMAL, CORE, registries, file_sha, json_bytes, write


def restored_sha(reference: dict, checked: dict) -> str:
    """
    機能: 保存ZIP・同体・gzip・文書snapshotから元bytesの指紋を検査する。
    引数: reference(dict)は恒久参照、checked(dict)は物理SHAのcache。
    返り値: strは復元SHA256。共有圧縮観測の新解凍は行わない。
    """
    source = ROOT / reference.get('保存元ZIP', reference.get('保存元'))
    expected = reference.get('ZIP_SHA256', reference.get('保存SHA256'))
    if source not in checked:
        checked[source] = file_sha(source)
    assert checked[source] == expected, source
    if '保存元ZIP' in reference:
        with zipfile.ZipFile(source) as bundle:
            return hashlib.sha256(bundle.read(reference['ZIP内path'])).hexdigest()
    if reference['形式'] == '文書snapshot':
        with gzip.open(source, 'rb') as stream:
            docs = json.load(stream)['文書']
        body = next(item['本文'] for item in docs if item['path'] == reference['抽出キー'])
        return hashlib.sha256(body.encode('utf-8')).hexdigest()
    if reference['形式'] == '同体':
        return checked[source]
    assert reference['形式'] == 'gzip', reference
    digest = hashlib.sha256()
    with gzip.open(source, 'rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


# ----------------------------------------
def table_rows(text: str) -> list:
    """
    機能: 57行の汎用表だけを抽出する。
    引数: text(str)はMarkdown本文。
    返り値: listはID/手法/9尺度の全セル。
    """
    result = []
    for line in text.splitlines():
        cells = [cell.strip() for cell in line.split('|')[1:-1]]
        if len(cells) == 11 and re.fullmatch(r'[A-Z]\d{2}', cells[0]):
            result.append(cells)
    return result


# ----------------------------------------
def main() -> None:
    """
    機能: 保存全源と文書を検査し、独立文書票受領後だけ最終停止票を作る。
    引数: --review-json(Path|None)は編集停止済み独立文書票。
    返り値: None。固定Source・条件・金融・旧試行を変更しない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--review-json', type=Path)
    args = parser.parse_args()
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    _, by_sha = registries()
    checked, unique, counts = {}, {}, {}
    for stage in ('F0', 'F1', 'F2'):
        source = ROOT / index[stage + '原文']['保存元']
        assert file_sha(source) == index[stage + '_SHA256']
        values = json.loads(source.read_bytes())['ファイル']
        counts[stage] = len(values)
        for name, expected in values.items():
            assert expected in by_sha, name
            assert restored_sha(by_sha[expected], checked) == expected, name
            rel = Path(name).relative_to(ROOT).as_posix()
            assert rel not in unique or unique[rel] == expected
            unique[rel] = expected
    assert counts == {'F0': 45, 'F1': 49, 'F2': 16}
    with gzip.open(FORMAL / '検査/F1実行前文書.json.gz', 'rb') as stream:
        original = {Path(item['path']).name: item['本文'].encode('utf-8') for item in json.load(stream)['文書']}
    for name in ('条件.md', '設定と結果.md'):
        assert (FORMAL / name).read_bytes().startswith(original[name])
    current_rows = table_rows((FORMAL / '設定と結果.md').read_text(encoding='utf-8'))
    assert len(current_rows) == 57 and current_rows == table_rows(original['設定と結果.md'].decode('utf-8'))
    assert file_sha(ROOT / 'inputs/00150_構造状態の可読選択/条件.json') == 'b0f3652a3a7f912a1e18a1c9aad8b990d9a07e7ccaa524a38cd141830d07453a'
    assert file_sha(ROOT / 'scripts/入口研究/固定特徴から可読条件を選択する.py') == '2f46be32a23ce2c1e5e99f2714ed4fd1eb14c545e4e150a2efd8d112e5c5344a'
    summary = json.loads((FORMAL / '成果物/集計.json').read_bytes())
    assert file_sha(FORMAL / '成果物/集計.json') == 'd878c8e3df3fcda25324741cc92f5f7b9d5342a3097d88f2062e03db5d414178'
    assert summary['主評価'] == {'全場最低1': True, '到達済70%': False, '全時間毎時1以上': True, '三目標共同': False}
    v = summary['集計']['all']['U0']['BBO']['3600']['125']
    assert [v[k] for k in ('entries','forward','adverse','neither','censored','ifd_unknown','ifd_net5_profit','ifd_net5_loss','ifd_net5_sum')] == [1259,484,481,151,143,53,6528878,7899740,-1370862]
    financial = json.loads((FORMAL / '検査/金融独立検算.json').read_bytes())
    assert financial['成功'] and financial['比較数'] == 720 and financial['統計キー数'] == 17280
    replay = json.loads((FORMAL / '検査/保存観測からの再現確認.json').read_bytes())
    assert replay['成功'] and replay['720比較/参加/頻度/累計/連結群の全dict一致'] and replay['全三表JSONbytes一致']
    csv = json.loads((FORMAL / '検査/CSV独立再読.json').read_bytes())
    assert csv['成功'] and csv['全データセル比較数'] == 88325 and csv['数値比較数'] == 43403
    for item in index['CSV正本']:
        assert file_sha(ROOT / item['保存元']) == item['SHA256']
    links = []
    documents = list(FORMAL.glob('*.md')) + [ROOT / rel for rel in ('README.md','docs/README.md','docs/議論/README.md','study/README.md')]
    documents.append(ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/150_突破状態と背景の切替/README.md')
    for path in documents:
        for match in re.finditer(r'\[[^\]]+\]\(([^)]+)\)', path.read_text(encoding='utf-8-sig')):
            target = match.group(1).strip('<>').split('#')[0]
            if target and '://' not in target:
                assert (path.parent / target).exists(), (path.relative_to(ROOT), target)
                links.append((path.relative_to(ROOT).as_posix(), target))
    text = (FORMAL / 'README.md').read_text(encoding='utf-8')
    assert '**実行・保存済み。主U0' in text and '旧小群と追加領域' in text
    assert '26件そのものは同体再現' in text and '一般化できなかった' in text
    proof = {'成功': True, '試行': 150, '各固定源数': counts, 'unique源数': len(unique),
        '全固定源を保存実体から復元SHA一致': True, '条件設定F1全bytes_prefixと57行513セル同体': True,
        '主U0未達/参加頻度達成/旧C1維持を分離': True, 'Root720比較17280値': True,
        '保存再現720全dictと三表bytes一致': True, 'CSV全セル': 88325, 'CSV数値': 43403,
        'ローカルリンク実在数': len(links), '正式3MD_SHA256': {name:file_sha(FORMAL / name) for name in CORE},
        '旧小群再現と追加域の弱化を分離': True, '原因は事後で主変更なし': True,
        '親大入力/観測の恒久再複製': False, '新Raw/追加2場/次試行採番': False, '重大不足': []}
    if args.review_json:
        source = args.review_json.resolve()
        review = json.loads(source.read_bytes())
        assert review['成功']
        target = FORMAL / '検査/正式文書の独立確認.json'
        write(target, source.read_bytes())
        code = source.parent / '確認する.py'
        archived = FORMAL / '再現資料/150文書の独立確認.zip'
        with zipfile.ZipFile(archived, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
            name = code.relative_to(ROOT).as_posix()
            bundle.writestr(name, code.read_bytes())
        index.update({'段階': '正式保存完了・編集停止', '正式3MD最終SHA256': proof['正式3MD_SHA256'],
            '正式文書の独立確認': {'保存元': target.relative_to(ROOT).as_posix(), 'SHA256': file_sha(target),
                '保存元ZIP': archived.relative_to(ROOT).as_posix(), 'ZIP_SHA256': file_sha(archived),
                'ZIP内path': name, 'sha256': file_sha(code), '区分': '金融数値再計算と別の文書原文・513・リンク確認'},
            '全源保存復元確認': {'段階別': counts, 'unique数': len(unique)},
            '未解決事項': [], '次の金融探索を実行': False})
        index_path.write_bytes(json_bytes(index))
        proof.update({'状態': '正式保存完了・編集停止', '独立文書票SHA256': file_sha(target),
            '保管索引SHA256': file_sha(index_path), 'F0_SHA256': index['F0_SHA256'],
            'F1_SHA256': index['F1_SHA256'], 'F2_SHA256': index['F2_SHA256']})
        target = FORMAL / '検査/正式保存の最終確認.json'
    else:
        target = FORMAL / '検査/正式資料の最終反映確認.json'
    write(target, json_bytes(proof))
    print(json.dumps({'成功': True, '最終票': target.relative_to(ROOT).as_posix(), 'SHA256': file_sha(target), 'リンク': len(links)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
