"""150結果へ4目次と出力案内から到達できるようにする。"""
from pathlib import Path
import os
from 保存部品 import ROOT, FORMAL, write


def main() -> None:
    """
    機能: 既存149記事を保持し150の完了結果を目次先頭へ追加する。
    引数: なし。最終金融値はRoot確定の150結果に固定する。
    返り値: None。旧試行・旧CSV・固定条件は変更しない。
    """
    for rel in ('README.md', 'docs/README.md', 'docs/議論/README.md', 'study/README.md'):
        path = ROOT / rel
        old = path.read_text(encoding='utf-8-sig')
        assert '[150：' not in old
        target = os.path.relpath(FORMAL / 'README.md', path.parent).replace('\\', '/')
        viewer = os.path.relpath(FORMAL / '閲覧資料.md', path.parent).replace('\\', '/')
        paragraph = f'[150：突破の現在状態と背景の切替を検証](<'+target+f'>)。主U0は1,259取得/全73場・平均1.7464件/時で参加と頻度を満たしたが、484順481逆151未到達143不足・到達済50.16%で70%未達。C5既知利益6,528,878円/損失7,899,740円/差引−1,370,862円、未知53。旧C1全87の70%/+210,532円を保持したが、新候補で同率を維持できず不採用。FAは主OR外、RTは成功リテストの確認ではない。[CSVと未知累計](<'+viewer+'>)。\n\n'
        index = old.index('[149：')
        path.write_text(old[:index] + paragraph + old[index:], encoding='utf-8', newline='\n')
    output = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/150_突破状態と背景の切替'
    text = '''# 150の損益CSV

最初は[全セッション.csv](全セッション.csv)を見る。全73場の主U0・N0・旧C1の既知利益/損失/差引と、未知件数・累計を残した。未知を0へ補完せず、未知を含む全件確定差引は空欄（JSONではnull）である。

[入口別診断.csv](入口別診断.csv)は主U0の1,259取得をq1時刻順、[正逆比較.csv](正逆比較.csv)は全12政策720比較。条件成立数や複数の同q1参照を重複取得として数えない。

主は484順481逆151未143不足、到達済み先着率50.16%、全73場・平均1.7464件/時。参加/頻度は満たしたが70%未達で不採用。C5既知小計は利益6,528,878円・損失7,899,740円・差引−1,370,862円、未知53件。mini独立1枚IFD診断の重複合算であり、10枚口座の運用収支ではない。

Rootが88,325セル/数値43,403セルを再読し支援PNG3枚を目視確認した。[正式レポート](../../../study/00150_突破の現在状態と背景で順逆を切り替える/README.md)、[閲覧資料](../../../study/00150_突破の現在状態と背景で順逆を切り替える/閲覧資料.md)、[再現手順](../../../study/00150_突破の現在状態と背景で順逆を切り替える/再現手順.md)を参照する。
'''
    write(output / 'README.md', text.encode('utf-8'))


if __name__ == '__main__':
    main()
