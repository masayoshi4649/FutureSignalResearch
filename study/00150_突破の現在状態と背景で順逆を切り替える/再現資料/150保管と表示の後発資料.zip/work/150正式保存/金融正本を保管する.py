"""150の金融前F2・集計・typed三表・独立票を一度恒久保存する。"""
from pathlib import Path
import json
import zipfile
from 保存部品 import ROOT, FORMAL, save, resolve, file_sha, json_bytes, write


def main() -> None:
    """
    機能: Root通知済み金融正本とF2源の復元参照を保存する。
    引数: なし。自然ラベルを使って選択・閾値を変更しない。
    返り値: None。148大観測を複製せず、正式3MDも変更しない。
    """
    runtime = ROOT / 'work/150構造状態の評価'
    folder = runtime / '金融診断'
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    f2 = runtime / 'F2金融集計前.json'
    f2_sha = '222b357225105a136575bfa1e914858bbe78515b11e4348a016b9e1c879bcd07'
    assert file_sha(f2) == f2_sha
    frozen = json.loads(f2.read_bytes())
    assert frozen['試行'] == 150 and frozen['主政策'] == 'U0'
    f1 = json.loads((ROOT / index['F1原文']['保存元']).read_bytes())
    for name in ('README.md', '条件.md', '設定と結果.md'):
        path = FORMAL / name
        assert file_sha(path) == f1['ファイル'][str(path)]
    completion = json.loads((folder / '集計完了.json').read_bytes())
    assert completion['成功'] and completion['集計SHA256'] == 'd878c8e3df3fcda25324741cc92f5f7b9d5342a3097d88f2062e03db5d414178'
    assert completion['表SHA256'] == '00eed952e2db37f3e0eaa1cf71ff458e41828dc6c90d5e0b11ca377b4fb39030'
    references = {item['復元先']: item for item in index['新共用入力'] + [index['F1原文']]}
    original = save(f2, FORMAL / '検査/F2金融集計前.json', f2_sha)
    groups = resolve(frozen['ファイル'], '金融集計前', [], references)
    summary = save(folder / '集計.json', FORMAL / '成果物/集計.json', completion['集計SHA256'])
    table = save(folder / 'CSV用の表.json', FORMAL / '成果物/CSV用の表.json.gz', completion['表SHA256'], True)
    extras = []
    for name, dest in [('集計完了.json', '成果物/集計完了.json'), ('独立検算.json', '検査/金融独立検算.json')]:
        source = folder / name
        extras.append(save(source, FORMAL / dest, file_sha(source)))
    parent = next((ROOT / 'study').glob('00148_*/保管索引.json'))
    inherited = json.loads(parent.read_bytes())
    index.update({'段階': 'F0/F1/F2・選択3正本・金融正本を保存。CSVと原因は後発段階',
        'F2_SHA256': f2_sha, 'F2原文': original, 'F2直接源数': len(frozen['ファイル']), 'F2復元参照': groups,
        '保存金融正本': summary, '保存CSV用の表': table, '金融完成と独立票': extras,
        '親148共有観測': inherited['保存済み正逆観測'], '主政策': 'U0', '最終選択取引数': 1259,
        '金融診断は運用収支': False,
        '集計metadataのF2_SHA256というキー': '作者CLIに渡した入口固定F1(d19e311a…)のSHA。金融集計前F2は別原本222b3572…であり混同しない。作者原本は不変。'})
    index_path.write_bytes(json_bytes(index))
    proof = {'成功': True, '試行': 150, 'F2_SHA256': f2_sha, 'F2直接源数': len(frozen['ファイル']),
        '集計SHA256': summary['解凍SHA256'], 'typed表SHA256': table['解凍SHA256'],
        '親148大入力又は観測の新複製': False, '正式3MDは結果変更前に保護済み': True,
        'Root720比較17280値独立票': extras[-1]['保存元'], '重大不足': []}
    target = FORMAL / '検査/金融正本の保管確認.json'
    write(target, json_bytes(proof))
    print(json.dumps({'成功': True, '金融保管票SHA256': file_sha(target), '保管索引SHA256': file_sha(index_path)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
