"""150の選択正本と共有保存gzipだけで金融720比較と三表を再現する。"""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import os
import subprocess
import sys
import zipfile
from 保存部品 import ROOT, FORMAL, registries, file_sha, json_bytes


def main() -> None:
    """
    機能: 新しいworkへ小型源だけを復元し、共有gzipから再集計する。
    引数: --destination(str)は未作成のwork内ディレクトリ。
    返り値: None。Raw・出生再生成・入口再選択・元正本上書きは行わない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--destination', required=True)
    args = parser.parse_args()
    destination = (ROOT / args.destination).resolve()
    assert destination.is_relative_to((ROOT / 'work').resolve()) and not destination.exists()
    destination.mkdir(parents=True)
    index = json.loads((FORMAL / '保管索引.json').read_bytes())
    f1 = json.loads((ROOT / index['F1原文']['保存元']).read_bytes())
    f2 = json.loads((ROOT / index['F2原文']['保存元']).read_bytes())
    completion = json.loads((FORMAL / '成果物/集計完了.json').read_bytes())
    by_path, by_sha = registries()
    fingerprints = {}
    for values in (f1['ファイル'], f2['ファイル'], completion['前後SHA256']):
        for name, digest in values.items():
            path = Path(name)
            if not path.is_absolute():
                path = ROOT / path
            fingerprints[path.relative_to(ROOT).as_posix()] = digest
    restored, checked = [], {}

    def restore(rel: str) -> Path:
        """
        機能: 小型源・選択JSONを保存実体から期待SHAで復元する。
        引数: rel(str)は元リポジトリ相対パス。
        返り値: Pathは隔離先。旧圧縮観測はhardlink参照だけとする。
        """
        expected = fingerprints[rel]
        target = destination / rel
        if target.exists():
            assert file_sha(target) == expected
            return target
        target.parent.mkdir(parents=True, exist_ok=True)
        reference = by_path.get(rel)
        if not reference or reference.get('解凍SHA256') != expected:
            reference = by_sha[expected]
        if '保存元ZIP' in reference:
            source = ROOT / reference['保存元ZIP']
            if source not in checked:
                checked[source] = file_sha(source)
            assert checked[source] == reference['ZIP_SHA256']
            with zipfile.ZipFile(source) as bundle:
                body = bundle.read(reference['ZIP内path'])
            target.write_bytes(body)
            method = '小型ZIPから復元'
        else:
            source = ROOT / reference['保存元']
            assert file_sha(source) == reference['保存SHA256']
            assert reference['形式'] in ('gzip', '同体')
            if reference['形式'] == '同体' and source.suffix == '.gz':
                os.link(source, target)
                method = '同一volumeの圧縮実体hardlink・読取専用扱い'
            else:
                opener = gzip.open if reference['形式'] == 'gzip' else open
                with opener(source, 'rb') as original, target.open('xb') as output:
                    for chunk in iter(lambda: original.read(1024 * 1024), b''):
                        output.write(chunk)
                method = '保存原文又は選択gzipから復元'
        assert file_sha(target) == expected
        restored.append({'path': rel, 'sha256': expected, 'bytes': target.stat().st_size, '方式': method})
        return target

    preparation = restore('work/150構造状態の金融集計/準備の確認.json')
    prep = json.loads(preparation.read_bytes())
    for item in prep['源']:
        rel = Path(item['path']).as_posix()
        fingerprints[rel] = item['sha256']
        restore(rel)
    for rel in ('work/149可読局面の金融集計/集計する.py',
                'work/148母集団の診断集計/集計する.py',
                'work/124入口の原因分析/集計する.py',
                'study/00145_押戻し完了と失敗突破を別の構造イベントで評価する/成果物/固定取得の正逆観測.json.gz',
                'study/00145_押戻し完了と失敗突破を別の構造イベントで評価する/成果物/集計.json',
                'work/150構造状態の評価/入口選択/選択対応.json'):
        restore(rel)
    replay_f1 = {**f1, 'ファイル': {str(destination / Path(name).relative_to(ROOT)): digest for name, digest in f1['ファイル'].items()},
                 '再現専用': True, '元F1_SHA256': index['F1_SHA256']}
    local_f1 = destination / '再現F1.json'
    local_f1.write_bytes(json_bytes(replay_f1))
    selection = destination / 'work/150構造状態の評価/入口選択/選択対応.json'
    observation = ROOT / index['親148共有観測']['保存元']
    before = file_sha(observation)
    assert before == index['親148共有観測']['保存SHA256']
    output = destination / '再集計'
    script = destination / 'work/150構造状態の金融集計/集計する.py'
    command = [sys.executable, '-X', 'utf8', str(script), '--preparation-sha256', file_sha(preparation),
        '--f1', str(local_f1), '--f1-sha256', file_sha(local_f1), '--selection', str(selection),
        '--selection-sha256', file_sha(selection), '--generation-dir', str(ROOT / 'inputs/00148_全1分入口母集団'),
        '--result', str(observation), '--result-sha256', before,
        '--result-decoded-sha256', index['親148共有観測']['解凍SHA256'], '--output-dir', str(output)]
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (destination / '再実行.txt').write_bytes(result.stdout + result.stderr)
    assert result.returncode == 0, (result.stdout + result.stderr).decode('utf-8', 'replace')
    expected = json.loads((ROOT / index['保存金融正本']['保存元']).read_bytes())
    actual = json.loads((output / '集計.json').read_bytes())
    assert actual['F2_SHA256'] == file_sha(local_f1)
    actual['F2_SHA256'] = expected['F2_SHA256']
    assert actual == expected
    assert file_sha(output / 'CSV用の表.json') == index['保存CSV用の表']['解凍SHA256']
    assert file_sha(observation) == before
    proof = {'成功': True, '試行': 150, '復元源': restored, '元F1_SHA256': index['F1_SHA256'],
        '実金融前F2_SHA256': index['F2_SHA256'], '再現F1_SHA256': file_sha(local_f1),
        '720比較/参加/頻度/累計/連結群の全dict一致': True, '全三表JSONbytes一致': True,
        '三表SHA256': index['保存CSV用の表']['解凍SHA256'],
        '許容差': '隔離pathを含む再現入口F1のSHAだけ。作者キー名F2_SHA256の実値は入口F1。全統計・セルは同体。',
        '共有4入力gzipを直接読取': True, '親大観測gzipを直接読取': True,
        '原板/出生/入口再選択': False, '大観測plain新副本': False, '恒久大入力複製': False, '元正本上書き': False}
    target = destination / '保存観測からの再現確認.json'
    target.write_bytes(json_bytes(proof))
    print(json.dumps({'成功': True, '保存再現票': target.relative_to(ROOT).as_posix(), 'SHA256': file_sha(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
