"""150の停止済み事後診断を保存し、旧小群と追加領域を分けて報告する。"""
from pathlib import Path
import json
from 保存部品 import ROOT, FORMAL, file_sha, save, resolve, json_bytes


def main() -> None:
    """
    機能: 停止票を検査し詳細一度gzip・小型源・短報を恒久化する。
    引数: なし。結果で主政策・固定条件・513セルを変更しない。
    返り値: None。旧良群の再現と広い追加域の弱化を区別する。
    """
    folder = ROOT / 'work/150広げた構造候補が弱まった理由'
    stop = folder / '停止.json'
    assert file_sha(stop) == '3abedb0d400e01db97164d263792999f7c0c6a4ce0151b0acdaf6011669db5fe'
    stopped = json.loads(stop.read_bytes())
    assert stopped['成功'] and stopped['編集停止'] and not stopped['主又はSource変更']
    files = {str(folder / item['name']): item['sha256'] for item in stopped['停止ファイル']}
    files[str(stop)] = file_sha(stop)
    assert all(file_sha(Path(path)) == expected for path, expected in files.items())
    reports = [save(folder / '短報.md', FORMAL / '根拠/広げた構造候補が弱まった理由.md', files[str(folder / '短報.md')]),
               save(folder / '要約.json', FORMAL / '根拠/原因診断の要約.json', files[str(folder / '要約.json')]),
               save(folder / '診断.json', FORMAL / '根拠/原因診断.json.gz', files[str(folder / '診断.json')], True)]
    groups = resolve(files, '原因診断', [], {item['復元先']: item for item in reports})
    index_path = FORMAL / '保管索引.json'
    index = json.loads(index_path.read_bytes())
    index.update({'事後原因診断の停止SHA256': file_sha(stop), '事後原因診断の正本': reports,
                  '事後原因診断の復元参照': groups, '原因診断から新政策採用': False})
    index_path.write_bytes(json_bytes(index))
    readme = FORMAL / 'README.md'
    text = readme.read_text(encoding='utf-8')
    text = text.replace('149の事後26件で見えた実逆80%は、状態を広げた本試行では再現しなかった。',
        '149の事後26件そのものは同体再現したが、その実逆80%を広げた群全体へ一般化できなかった。')
    paragraph = '''## 未達の原因を旧小群と追加領域に分ける

[停止済み原因短報](根拠/広げた構造候補が弱まった理由.md)・[詳細gzip](根拠/原因診断.json.gz)・[要約](根拠/原因診断の要約.json)を保存した。これは主結果を見た後の事後診断であり、新しい採用政策の成績ではない。

- 旧T4当時の端復帰26件は、150FA/FDでも16順4逆4未2不足・C5既知差引+112,998円を再現した。一方、追加FA1,233件は−2,553,092円、追加FD794件は−1,708,213円。小群の取得価格や符号が壊れたのではなく、より広い状態へその優位を外挿できなかった。
- RBは旧R3全59取得の28順16逆8未7不足・+109,611円を保持したが、追加291件は102順91逆46未52不足・−85,482円だった。追加分は前181件−219,320円、後110件+133,838円に分かれ、未知期の安定性を証明しない。一律実逆でも追加分は悪化した。
- 実体の大きさ×量、注文側30分EMA増分×DI、5/15/30分EMA整合を事後層別しても70%を説明できなかった。RT全51件は正規化前の5/15/30分EMA増分が注文向きでも23順21逆・−52,927円。方向整合を追加すれば必ず高精度になるとは示せない。

旧T4が持つ低ADXだけでなく増分非負・5分gap/Hist改善・実体/先行幅・位置・量という束と、FDの「ADX≤25又は低下」は異なる技術領域を含む。どの省略条件が原因かを因果分離した検査ではない。旧良群を保護した対照と追加領域の位相を分ける次の問いに留め、今回の良い事後群を選んで新主や70%達成にしない。

'''
    assert '## 未達の原因を旧小群' not in text
    text = text.replace('## 仮説と候補', paragraph + '## 仮説と候補', 1)
    readme.write_text(text, encoding='utf-8', newline='\n')
    for name in ('閲覧資料.md', '再現手順.md'):
        target = FORMAL / name
        with target.open('a', encoding='utf-8', newline='\n') as output:
            output.write('\n[事後原因短報](根拠/広げた構造候補が弱まった理由.md)は旧T4当時26/旧R3全59と追加領域を分ける。旧小群の良さを残しつつ、広い追加域へ一般化しなかった事実であり、良い群を選び直した採用成績ではない。詳細は[一度gzip](根拠/原因診断.json.gz)へ保存した。\n')
    assert all(file_sha(Path(path)) == expected for path, expected in files.items())
    print('原因保存・主条件不変更、README原因のみ追記')


if __name__ == '__main__':
    main()
