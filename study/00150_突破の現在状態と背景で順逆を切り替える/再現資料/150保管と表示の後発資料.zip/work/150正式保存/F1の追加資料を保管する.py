"""RootのF1通知後にだけ150の選択3正本を恒久保存する。"""
from pathlib import Path
import argparse
from 保存部品 import f1


def main():
    """明示通知のF1を保存器へ渡す。

    引数: --f1(Path)、--sha256(str)、--generated-dir(Path)。返り値: None。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--f1', required=True, type=Path)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--generated-dir', required=True, type=Path)
    args = parser.parse_args()
    f1(args.f1.resolve(), args.sha256, args.generated_dir.resolve())


if __name__ == '__main__':
    main()
