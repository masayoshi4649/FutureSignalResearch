"""150の四つの技術条件を別式で全件評価する。selector・金融はimportしない。"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
BASE = ROOT / 'work/150構造状態の評価'
MOTHER = ROOT / 'inputs/00148_全1分入口母集団'
FILES = {
    'F0': (BASE / 'F0入口選択前.json', '86f4295511108024f209cf5ceb607043c4f033e73020250510e513a0513aab81'),
    'F1': (BASE / 'F1入口選択後.json', 'd19e311a695da3de2098956e1fee4eda28bae924f65bc0c8c452938b3131bcdf'),
    'book': (ROOT / 'inputs/00150_構造状態の可読選択/条件.json', 'b0f3652a3a7f912a1e18a1c9aad8b990d9a07e7ccaa524a38cd141830d07453a'),
    'features': (MOTHER / '当時特徴.json.gz', '464dad9dce7acb20f043c344e96c9fa6d19ab0049a9d557e6fc96f6d189abcb7'),
    'captures': (MOTHER / '取得対応.json.gz', '7c27420abe6af0867f6cf3d8fd838205da3ed099df8db8e5b5d62892cbadf6bc'),
    'metadata': (MOTHER / '入口参照.json.gz', 'ad53cccf8e4da093ebd32c1ddc80132ddcd4c73d8f20897c4033f0895fc966b6'),
    'decisions': (BASE / '入口選択/q0の判断.json', '20e44b88a4a680bf4e9dfd76150b117111c6930329a205589bf521adcbcc56a9'),
    'selection': (BASE / '入口選択/選択対応.json', 'f6d5441a58f305d2f123011d85dca472629d5b18c7772614c0ecb6e0d9a29f16'),
    'confirmation': (BASE / '入口選択/選択の確認.json', '4bfc9baa33d26ce6e60d08aca6ec12f8f28b475bf0c88020922a09b2ef50e551'),
    'selector': (ROOT / 'scripts/入口研究/固定特徴から可読条件を選択する.py', '2f46be32a23ce2c1e5e99f2714ed4fd1eb14c545e4e150a2efd8d112e5c5344a'),
}
NAMES = ('FA', 'FD', 'RT', 'RB', 'N0')
MEMBERS = ('FD', 'RT', 'RB')
COUNTS = {'FA': 1259, 'FD': 820, 'RT': 51, 'RB': 350, 'N0': 1175, 'C1': 87, 'U0': 1259}


def fingerprint(path: Path) -> dict:
    """
    機能: 明示した非金融入力のSHA/statを取得する。
    引数: path(Path)。返り値: dict。
    """
    old = path.stat(); h = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(4 << 20), b''): h.update(chunk)
    now = path.stat()
    assert (old.st_size, old.st_mtime_ns) == (now.st_size, now.st_mtime_ns)
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': old.st_size,
            'mtime_ns': old.st_mtime_ns, 'sha256': h.hexdigest()}


def read(path: Path) -> dict:
    """
    機能: 許可済み非金融JSONをgzip終端まで復号する。
    引数: path(Path)。返り値: dict。
    """
    opener = gzip.open if path.suffix == '.gz' else Path.open
    with opener(path, 'rt', encoding='utf-8') as source: return json.load(source)


def all3(*values):
    """
    機能: 否定を優先し、未知を既知0にしないANDを求める。
    引数: values(tuple[bool|None])。返り値: bool又はNone。
    """
    return False if any(x is False for x in values) else None if any(x is None for x in values) else True


def any3(*values):
    """
    機能: 成立を優先するORを求める。
    引数: values(tuple[bool|None])。返り値: bool又はNone。
    """
    return True if any(x is True for x in values) else None if any(x is None for x in values) else False


def relation(value, operation: str, boundary: float):
    """
    機能: 単一の既知値を明示的な比較表で判定する。
    引数: value(float|None)、operation(str)、boundary(float)。返り値: bool又はNone。
    """
    if value is None: return None
    if operation == '>': return value > boundary
    if operation == '>=': return value >= boundary
    if operation == '<': return value < boundary
    assert operation == '<='
    return value <= boundary


def rules(vector: list, index: dict) -> tuple:
    """
    機能: 条件木実行器を使わずFA/FD/RT/RBを独立の明示式で判定する。
    引数: vector(list[float|None])、index(dict)。返り値: tupleは四条件と派生2値。
    """
    assert len(vector) == 100
    assert all(v is None or type(v) in (int, float) and math.isfinite(v) for v in vector)
    def x(name: str):
        """
        機能: 当時配列から列名で値を参照する。
        引数: name(str)。返り値: float又はNone。
        """
        return vector[index[name]]
    gap = x('q0_last_minus_m1_close_atr5_to_side')
    edge = x('q0_last_minus_prior3_forward_edge_atr5_to_side')
    reclaim = x('m1_body_reclaim_atr5_to_side')
    close = edge - gap if edge is not None and gap is not None else None
    live = reclaim + gap if reclaim is not None and gap is not None else None
    common = all3(relation(x('q0_spread_points'), '>', 0), relation(x('q0_spread_points'), '<=', 20),
                  relation(gap, '>=', -1), relation(gap, '<=', 1))
    fa = all3(relation(close, '>', 0), relation(edge, '<=', 0),
              relation(x('m1_body_ratio_to_side'), '>', 0), relation(x('m1_volume_relative_prior3'), '>=', 1))
    adx = x('m15_adx'); delta = x('m15_adx_delta')
    fd = all3(fa, any3(relation(adx, '<=', 25), relation(delta, '<', 0)))
    rt = all3(fa, relation(adx, '>', 25), relation(delta, '>=', 0),
              relation(x('m15_di_difference_to_side'), '>', 0),
              relation(x('m30_ema21_delta_atr_to_side'), '>', 0),
              relation(x('m5_hist_delta_atr_to_side'), '>', 0), relation(live, '>', 0))
    rb = all3(relation(adx, '<=', 20), relation(x('q0_entry_minus_bbmean_sigma_to_side'), '<=', -1),
              relation(x('m5_rsi_delta_to_side'), '>', 0), relation(x('m1_volume_ratio_previous'), '>=', 1),
              relation(x('m1_tr_atr5_ratio'), '<=', 1.5),
              any3(relation(reclaim, '>=', 0),
                   all3(relation(x('m1_opposite_wick_ratio'), '>=', .4), relation(x('m1_body_ratio_to_side'), '>', 0))))
    return common, {'FA': fa, 'FD': fd, 'RT': rt, 'RB': rb}, {'close_break': close, 'last_reclaim': live}


def expected_decision(row: dict, index: dict) -> dict:
    """
    機能: 両sideの明示条件から根拠方向/注文方向/役割/主ORを再構成する。
    引数: row(dict)、index(dict)。返り値: dict。
    """
    evidence = []
    expected_roles = {'FA': ['構造', '量'], 'FD': ['強度', '構造', '量'],
                      'RT': ['勢い', '強度', '方向', '構造', '量'],
                      'RB': ['値幅', '勢い', '強度', '構造', '量']}
    for side, key in ((1, 'buy'), (-1, 'sell')):
        assert row[key]['side'] == side
        common, flags, derived = rules(row[key]['x'], index)
        if common is not True: continue
        for name in NAMES[:4]:
            if flags[name] is True:
                evidence.append({'rule': name, 'signal_side': side, 'order_side': -side if name in ('FA', 'FD') else side,
                                 'roles': sorted(expected_roles[name]), 'derived': derived.copy()})
    directions, conflicts = {}, {}
    for name in NAMES:
        sides = {e['order_side'] for e in evidence if e['rule'] == name or (name == 'N0' and e['rule'] in MEMBERS)}
        directions[name] = list(sides)[0] if len(sides) == 1 else 0
        conflicts[name] = len(sides) > 1
    return {'directions': directions, 'conflicts': conflicts, 'evidence': evidence}


def main() -> None:
    """
    機能: 全q0判定を先に照合し、その後だけ取得を結合して全政策行を確認する。
    引数: なし。返り値: None。観測ラベル/金融/Raw/追加2場を読まない。
    """
    paths = {key: pair[0] for key, pair in FILES.items()}
    before = {key: fingerprint(path) for key, path in paths.items()}
    assert all(before[key]['sha256'] == pair[1] for key, pair in FILES.items())
    f0, f1, book = read(paths['F0']), read(paths['F1']), read(paths['book'])
    assert f0['成功'] and f1['成功'] and f0['試行'] == f1['試行'] == 150
    assert f1['F0_SHA256'] == before['F0']['sha256']
    manifests = [{str(Path(k).resolve()).casefold(): v for k, v in f['ファイル'].items()} for f in (f0, f1)]
    for key in ('book', 'features', 'captures', 'metadata', 'selector'):
        assert all(m[str(paths[key].resolve()).casefold()] == before[key]['sha256'] for m in manifests)
    for key in ('decisions', 'selection', 'confirmation'):
        assert manifests[1][str(paths[key].resolve()).casefold()] == before[key]['sha256']
    assert [r['id'] for r in book['rules']] == list(NAMES[:4])
    assert [r['order_sign'] for r in book['rules']] == [-1, -1, 1, 1]
    assert book['union_rules'] == list(MEMBERS) and book['minimum_technical_roles'] == 2
    features, actual_decisions = read(paths['features']), read(paths['decisions'])
    assert features['success'] and features['trial'] == 148 and not features['financial_labels_used']
    assert not features['strategy_selected'] and features['selected_trade_count'] is None
    assert actual_decisions['成功'] and actual_decisions['試行'] == 150 and not actual_decisions['金融ラベル利用']
    assert actual_decisions['q1結合前に全件判断']
    index = {c['name']: i for i, c in enumerate(features['catalog'])}
    assert len(index) == len(features['catalog']) == 100
    actual_by_id = {r['event_id']: r for r in actual_decisions['rows']}
    assert len(actual_by_id) == len(features['rows']) == len(actual_decisions['rows']) == 35339
    decisions = []
    hits = Counter()
    for row in features['rows']:
        q0 = row['metadata']['q0']
        decision = expected_decision(row, index)
        expected = {'event_id': row['event_id'], 'session': row['session'], 'contract': row['contract'],
                    'q0_time': q0['time'], 'q0_index': q0['index'], 'q0_line': q0['source_line'], 'decision': decision}
        assert expected == actual_by_id[row['event_id']], row['event_id']
        decisions.append(expected)
        for evidence in decision['evidence']: hits[(evidence['rule'], evidence['signal_side'])] += 1
    del features['rows']
    print(json.dumps({'段階': '全q0の方向/競合/役割/派生値/信号注文符号一致', '件数': len(decisions)}, ensure_ascii=False), flush=True)
    # ----------------------------------------
    # ここまで取得情報・C1未来表をparseしていない。
    captures, metadata, actual = read(paths['captures']), read(paths['metadata']), read(paths['selection'])
    sessions = features['sessions']
    assert len(sessions) == len(set(sessions)) == 73
    assert sessions == captures['sessions'] == metadata['sessions'] == actual['全73場']
    capture_map = {r['event_id']: r for r in captures['rows']}
    cases = {r['case_id']: r for r in metadata['population148']['cases']}
    assert len(capture_map) == len(captures['rows']) == len(decisions)
    assert set(capture_map) == {r['event_id'] for r in decisions} and len(cases) == 31642
    order = {sid: i for i, sid in enumerate(sessions)}
    decisions.sort(key=lambda r: (order[r['session']], r['q0_index'], r['q0_line'], r['event_id']))
    policy = {name: {} for name in NAMES}; counters = {name: Counter() for name in NAMES}
    for decision in decisions:
        acq = capture_map[decision['event_id']]
        assert (acq['session'], acq['contract']) == (decision['session'], decision['contract'])
        assert tuple(acq['q0'][k] for k in ('time', 'index', 'source_line')) == tuple(decision[k] for k in ('q0_time', 'q0_index', 'q0_line'))
        for name in NAMES:
            if decision['decision']['conflicts'][name]: counters[name]['conflict_wait'] += 1
            side = decision['decision']['directions'][name]
            if not side: continue
            counters[name]['born'] += 1; counters[name][acq['status']] += 1
            if acq['status'] != 'filled': continue
            cid = acq['case_id']; case = cases[cid]
            assert (case['session'], case['contract']) == (decision['session'], decision['contract'])
            if cid in policy[name]: counters[name]['duplicate_q1'] += 1; continue
            stream = 'original' if side == case['original_side'] else 'reverse'
            assert stream == acq['buy_stream' if side == 1 else 'sell_stream'] == case['buy_stream' if side == 1 else 'sell_stream']
            evidence = [e for e in decision['decision']['evidence'] if e['order_side'] == side and
                        (e['rule'] == name or (name == 'N0' and e['rule'] in MEMBERS))]
            assert evidence and (name != 'N0' or all(e['rule'] != 'FA' for e in evidence))
            policy[name][cid] = {'case_id': cid, 'session': decision['session'], 'side': side, 'stream': stream,
                'event_id': decision['event_id'], 'feature_ref': decision['event_id'], 'q0_time': decision['q0_time'],
                'q0_index': decision['q0_index'], 'q0_line': decision['q0_line'],
                '成立ID': sorted({e['rule'] for e in evidence}), 'evidence': evidence, 'origin': name}
    legacy = {cid: {'case_id': cid, 'session': case['session'], 'side': case['original_side'], 'stream': 'original',
                   'event_id': None, 'feature_ref': None, 'origin': 'C1'} for cid, case in cases.items() if case['c1_reused']}
    assert len(legacy) == 87
    union, overlaps = legacy.copy(), []
    for cid, row in policy['N0'].items():
        if cid in union:
            overlaps.append({'case_id': cid, 'legacy_side': union[cid]['side'], 'new_side': row['side'], 'opposite': union[cid]['side'] != row['side']})
        else: union[cid] = row
    policy['C1'], policy['U0'] = legacy, union
    expected = {'政策': {n: list(rows.values()) for n, rows in policy.items()},
                '候補と取得': {n: dict(rows) for n, rows in counters.items()}, '旧C1重複': overlaps,
                '全73場': sessions, '選択時の金融ラベル利用': False}
    for key, value in expected.items(): assert actual[key] == value, key
    counts = {n: len(rows) for n, rows in policy.items()}
    confirmation = read(paths['confirmation'])
    assert counts == COUNTS == f1['政策別取得数'] == confirmation['政策別取得数']
    assert len(policy['U0']) == 87 + len(policy['N0']) - len(overlaps)
    assert before == {key: fingerprint(path) for key, path in paths.items()}
    proof = {'成功': True, '試行': 150, '編集停止': True, '全q0': len(decisions),
             '4原子条件/N0方向/競合/evidence全件一致': True,
             '全signal_side/order_side/roles/derived全件一致': True,
             'q0判断後に取得/C1未来表をparse': True,
             '政策別uniqueq1': counts, '全候補/未取得/競合': expected['候補と取得'],
             'C1重複': len(overlaps), 'C1反対でも旧優先': sum(r['opposite'] for r in overlaps),
             'FA主混入なし/全canonical/stream/全参照順序一致': True,
             'F0F1の直接非金融入力SHA一致/対象源前後不変': True,
             'Source/selector/算術import/金融/観測ラベル/Raw/追加2場読取': False,
             'F0F1全源のRoot監査と分離': '本票は指定10非金融源だけを検査。原観測は開かない。',
             '作者境界': '148case builder作者だがselector作者でない。100数式/firstnormalは148既監査を継承。',
             '入力': list(before.values()), '監査コード': fingerprint(Path(__file__))}
    output = HERE / '監査の確認.json'
    output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '停止票SHA256': fingerprint(output)['sha256'], '政策別取得': counts}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
