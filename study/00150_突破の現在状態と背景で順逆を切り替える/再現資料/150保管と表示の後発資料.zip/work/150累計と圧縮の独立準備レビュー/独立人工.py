"""150集計器の累計・圧縮境界だけを人工で検査する。自然金融本文を開かない。"""
from pathlib import Path
from types import SimpleNamespace
import copy
import gzip
import hashlib
import importlib.util
import io
import json
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
CODE = ROOT / 'work/150構造状態の金融集計/集計する.py'
PREP = CODE.parent / '準備の確認.json'
CODE_SHA = '017b335b3b5c1fa20ccf1bcb32c1495b84e25c7461b46c70cb9318f688f8c15a'
PREP_SHA = 'f3f66016a0aeaa110cdd7749778ae48436882778f305e4111cee252e14955d9d'
spec = importlib.util.spec_from_file_location('150累計の確認対象', CODE)
target = importlib.util.module_from_spec(spec)
spec.loader.exec_module(target)


def sha(path: Path) -> str:
    """
    機能: 対象コード・小人工の物理SHAを取得する。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def stats(profit, loss, unknown: int = 0) -> dict:
    """
    機能: 累計検査に必要な人工統計を作る。
    引数: profit/loss(float|None)、unknown(int)。返り値: dict。
    """
    return {'ifd_net5_profit': profit, 'ifd_net5_loss': loss, 'ifd_unknown': unknown}


class CumulativeAndCompression(unittest.TestCase):
    """自然損益の検算とは分離した累計API・73行反映・圧縮境界。"""

    def test_01_unknown_never_recovers_and_inputs_unchanged(self) -> None:
        """
        機能: 一度未知後のnull維持と既知小計0/負/正、入力非改変を検査する。
        引数: self(CumulativeAndCompression)。返り値: None。
        """
        previous = {}; sequence = [stats(100, 20), stats(None, None, 2), stats(0, 200), stats(300, 0)]
        before = copy.deepcopy(sequence)
        expected = [(100, 20, 80, 0, 80), (100, 20, 80, 2, None),
                    (100, 220, -120, 2, None), (400, 220, 180, 2, None)]
        for row, values in zip(sequence, expected):
            old = copy.deepcopy(previous)
            actual = target.cumulative_step(previous, row)
            self.assertEqual(previous, old)
            self.assertEqual(tuple(actual[k] for k in target.CUMULATIVE_FIELDS), values)
            previous = actual
        self.assertEqual(sequence, before)
        self.assertEqual(target.cumulative_step({}, stats(None, None, 3)),
                         {'累計既知利益': 0, '累計既知損失絶対': 0, '累計既知差引': 0,
                          '累計IFD未知': 3, '累計全件確定差引': None})

    def test_02_all73_rows_and_json_curves_agree(self) -> None:
        """
        機能: 73場の政策別累計・表列順とJSON曲線の同体を人工stubだけで確認する。
        引数: self(CumulativeAndCompression)。返り値: None。
        """
        sessions = [f'人工{i:02d}_Day' for i in range(73)]
        records = {sid: {'session': sid, 'scene': {'start': i * 10000, 'end': i * 10000 + 8000,
                                                'force_close': i * 10000 + 5000}} for i, sid in enumerate(sessions)}
        per_scene = {}
        for policy, factor, unknown_at in [('U0', 1, 2), ('N0', 2, 8), ('C1', 3, 70)]:
            per_scene[policy] = {}
            for i, sid in enumerate(sessions):
                per_scene[policy][sid] = {**stats((i + 1) * factor, factor, int(i == unknown_at)),
                    'forward': 1, 'adverse': 0, 'neither': 0, 'censored': 0, 'ifd_known': 1,
                    'ifd_net5_sum': i * factor}
        sample = {'sessions': 73, 'entries': 73, 'flips': 0, 'complete': 73, 'censored': 0,
                  'forward': 40, 'adverse': 20, 'neither': 13, 'resolved_rate': 2/3, 'complete_rate': 40/73,
                  'target70': False, 'ifd_known': 72, 'ifd_unknown': 1, 'ifd_net0_sum': 10,
                  'ifd_net5_profit': 100, 'ifd_net5_loss': 90, 'ifd_net5_sum': 10, 'ifd_net5_mean': 10/72, 'ifd_net5_pf': 100/90}
        values = {part: {p: {axis: {str(h): {str(w): sample for w in target.WIDTHS}
                    for h in target.HORIZONS} for axis in target.AXES} for p in target.POLICIES}
                  for part in ('all', 'train', 'validation')}
        participation = {part: {p: {'対象場数': 73, '全場最低1取得': True} for p in target.POLICIES}
                         for part in values}
        frequency = {part: {p: {'全時間取得毎時': .1, '名目新規可時間毎時': .2} for p in target.POLICIES}
                     for part in values}
        overlaps = {'all': {'U0': {'場別': {sid: {'連結群数': 1, '最大群件数': 1} for sid in sessions}}}}
        parent = SimpleNamespace(COMPARISON_HEADERS=[f'比較列{i}' for i in range(34)],
                                 subset=lambda records, policy, scope: list(scope))
        arithmetic = SimpleNamespace(stats=lambda scope, policy, *args: per_scene[policy][scope[0]])
        selection = {'政策': {'N0': [], 'U0': []}, '旧C1重複': []}
        meta = {'population148': {'cases': []}, 'entries': []}
        tables, curves = target.tables(records, sessions, values, participation, frequency, overlaps, selection, meta, parent, arithmetic)
        scene = next(t for t in tables if t['name'] == '全セッション')
        self.assertEqual(len(scene['rows']), 73)
        for policy, factor, unknown_at in [('U0', 1, 2), ('N0', 2, 8), ('C1', 3, 70)]:
            for i, sid in enumerate(sessions):
                profit = factor * (i + 1) * (i + 2) // 2; loss = factor * (i + 1)
                unknown = int(i >= unknown_at)
                expected = [profit, loss, profit - loss, unknown, None if unknown else profit - loss]
                actual = [scene['rows'][i][scene['headers'].index(policy + field)] for field in target.CUMULATIVE_FIELDS]
                self.assertEqual(actual, expected)
                self.assertEqual([curves[policy][sid][field] for field in target.CUMULATIVE_FIELDS], expected)

    def test_03_physical_decoded_crc_and_json_end(self) -> None:
        """
        機能: 物理/解凍SHA、gzipCRC/短縮、JSON終端の各独立境界を確認する。
        引数: self(CumulativeAndCompression)。返り値: None。
        """
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder); plain = base / '人工.json'; zipped = base / '人工.json.gz'
            body = '{\n  "日本語": 1\n}\n'.encode('utf-8'); decoded = hashlib.sha256(body).hexdigest()
            plain.write_bytes(body); zipped.write_bytes(gzip.compress(body, mtime=0))
            self.assertNotEqual(sha(plain), sha(zipped))
            self.assertEqual(target.load(plain, sha(plain), decoded), {'日本語': 1})
            self.assertEqual(target.load(zipped, sha(zipped), decoded), {'日本語': 1})
            for path, physical, decoded_sha in [(plain, '0'*64, decoded), (zipped, sha(zipped), '0'*64)]:
                with self.assertRaises(AssertionError): target.load(path, physical, decoded_sha)
            broken = bytearray(zipped.read_bytes()); broken[-8] ^= 1; zipped.write_bytes(broken)
            with self.assertRaises(gzip.BadGzipFile): target.load(zipped, sha(zipped), decoded)
            zipped.write_bytes(gzip.compress(body, mtime=0)[:-4])
            with self.assertRaises(EOFError): target.load(zipped, sha(zipped), decoded)
            plain.write_bytes(b'{} trailing')
            with self.assertRaises(json.JSONDecodeError): target.load(plain, sha(plain))


def main() -> None:
    """
    機能: 限定3主人工を実行して自然金融未読の証跡を保存する。
    引数: なし。返り値: None。作者prepare/mainは呼ばない。
    """
    assert sha(CODE) == CODE_SHA and sha(PREP) == PREP_SHA
    log = io.StringIO()
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(CumulativeAndCompression))
    log_path = HERE / '人工のログ.txt'; log_path.write_text(log.getvalue(), encoding='utf-8')
    assert result.wasSuccessful(), log.getvalue()
    assert sha(CODE) == CODE_SHA and sha(PREP) == PREP_SHA
    proof = {'成功': True, '編集停止': True, '対象コードSHA256': CODE_SHA, '作者準備SHA256': PREP_SHA,
             '独立人工主群': result.testsRun, '73場3政策5累計セル': 73*3*5,
             '全件未知一度発生後null維持/既知小計と分離': True,
             '表の列とJSON曲線は同値/政策別累計を混ぜない': True,
             'gzip全readCRC/物理SHA/解凍SHA/JSON終端検査': True,
             '独立範囲': '累計step/load/表への累計反映のみ。全金融再計算や720表内容の独立検算ではない。',
             '自然150金融/観測ラベル/Raw/CSV/追加2場読取': False,
             '作者prepare/main/自然処理実行': False, 'Source/正式変更': False, '重大未解決': [],
             '私有人工SHA256': sha(Path(__file__)), '人工ログSHA256': sha(log_path)}
    output = HERE / '限定確認の記録.json'
    output.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '人工': result.testsRun, '累計セル': 1095,
                      '停止票SHA256': sha(output)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
