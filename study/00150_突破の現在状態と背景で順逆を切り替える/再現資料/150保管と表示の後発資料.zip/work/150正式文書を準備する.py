"""150の金融前3文書を、固定bookと版7から一度だけ準備する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import re

ROOT = Path(__file__).resolve().parent.parent
FORMAL = ROOT / 'study/00150_突破の現在状態と背景で順逆を切り替える'
INPUT = ROOT / 'inputs/00150_構造状態の可読選択/条件.json'
BOOK = ROOT / 'work/150構造状態の可読条件/条件.json'
SOURCE = ROOT / 'scripts/入口研究/固定特徴から可読条件を選択する.py'
TABLE = ROOT / 'docs/議論/手法と時間スケールの汎用表_版7.md'
CATALOG = ROOT / 'inputs/00148_全1分入口母集団/100特徴の列定義.json'
BOOK_SHA = 'b0f3652a3a7f912a1e18a1c9aad8b990d9a07e7ccaa524a38cd141830d07453a'
SOURCE_SHA = '2f46be32a23ce2c1e5e99f2714ed4fd1eb14c545e4e150a2efd8d112e5c5344a'
TABLE_SHA = '585d0d9ba69ff3601325e9e6564ede53aeb81b0d33a2da6cb67e20e175187c3d'
CATALOG_SHA = 'c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4'


def sha(path: Path) -> str:
    """
    機能: 小型の文書・コードを物理bytesで識別する。
    引数: path(Path)は対象ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path, text: str) -> None:
    """
    機能: 新しいUTF-8文書を排他的に保存する。
    引数: path(Path)は新規保存先、text(str)は本文。
    返り値: None。既存ファイルは上書きしない。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as output:
        output.write(text.rstrip() + '\n')


# ----------------------------------------
def relink(text: str, source: Path, target: Path) -> str:
    """
    機能: 汎用表の相対リンクを新しい試行から同じ実体へ向ける。
    引数: text(str)は元本文、source(Path)とtarget(Path)は文書パス。
    返り値: strはリンクだけを移設した本文。
    """
    def replace(match):
        """
        機能: 個々のローカルリンクを移設する。
        引数: match(re.Match)はリンクの一致。
        返り値: strは移設後のMarkdownリンク。
        """
        label, link = match.groups()
        if '://' in link or link.startswith('#'):
            return match.group(0)
        body, mark, anchor = link.partition('#')
        resolved = (source.parent / body).resolve()
        result = os.path.relpath(resolved, target.parent).replace('\\', '/')
        return '[' + label + '](' + result + (mark + anchor if mark else '') + ')'
    return re.sub(r'\[([^\]]+)\]\(([^)]+)\)', replace, text)


# ----------------------------------------
def table_rows(text: str) -> list:
    """
    機能: 版7の手法行だけを抽出する。
    引数: text(str)は表を含む本文。
    返り値: listはID・手法・9尺度の計11セルを持つ行。
    """
    rows = []
    for line in text.splitlines():
        parts = [item.strip() for item in line.split('|')[1:-1]]
        if len(parts) == 11 and re.fullmatch(r'[A-Z]\d{2}', parts[0]):
            rows.append(parts)
    return rows


# ----------------------------------------
def main() -> None:
    """
    機能: 正本指紋を確認し150の準備文書・検査票を保存する。
    引数: なし。自然データ・ラベル・金融評価を開かない。
    返り値: None。固定源や旧試行、目次を変更しない。
    """
    assert sha(BOOK) == BOOK_SHA and sha(SOURCE) == SOURCE_SHA
    assert sha(TABLE) == TABLE_SHA and sha(CATALOG) == CATALOG_SHA
    assert not FORMAL.exists(), '150正式フォルダが既に存在する'
    assert max(int(path.name[:5]) for path in (ROOT / 'study').iterdir()
               if path.is_dir() and re.match(r'\d{5}_', path.name)) == 149
    book = json.loads(BOOK.read_bytes())
    assert book['union_rules'] == ['FD', 'RT', 'RB']
    assert book['main_id'] == 'U0' and book['legacy_count'] == 87
    assert book['minimum_technical_roles'] == 2
    watched = [BOOK, SOURCE, TABLE, CATALOG,
        ROOT / 'work/共通可読選択器の作者人工/準備の確認.json',
        ROOT / 'work/共通可読選択器の独立準備レビュー/準備の確認.json',
        ROOT / 'work/共通可読選択器の独立準備レビュー/union範囲の追補確認.json',
        ROOT / 'work/構造状態から入口を生む容量調査/停止.json',
        ROOT / 'work/構造状態から入口を生む容量調査/FD_RT_R追補/停止.json',
        ROOT / 'work/構造状態の出生を設計する外部根拠/README.md',
        ROOT / 'work/構造状態の出生を設計する外部根拠/確認の記録.json']
    before = {str(path.relative_to(ROOT)).replace('\\', '/'): sha(path) for path in watched}
    assert not INPUT.exists(), '条件bookは一度だけ恒久保存する'
    INPUT.parent.mkdir(parents=True, exist_ok=True)
    with INPUT.open('xb') as output:
        output.write(BOOK.read_bytes())
    assert sha(INPUT) == BOOK_SHA

    readme = '''# 00150 突破の現在状態と背景で順逆を切り替える

**実行前の準備。150の自然選択・金融評価は未実行で、取得数・先着率・損益は未確定（null）。** 148の広い1分母集団から、当時の構造・背景・勢い・量を組み合わせて選ぶ。主は新規OR `N0=FD∨RT∨RB` と旧C1全87取得を統合した `U0`。FAは診断対照だけとし、N0へ含めない。

[固定条件](条件.md) / [版7・全513セルの設定](設定と結果.md) / [数値条件の正本JSON](../../inputs/00150_構造状態の可読選択/条件.json) / [親148](../00148_全1分知得から入口品質の母集団を固定する/README.md) / [前149](../00149_継続と反転を可読8局面で判定する/README.md)

## 仮説と候補

| ID | 当時の状態と組み合わせ | 注文方向・役割 |
| --- | --- | --- |
| FA | 既知1分終値は直前3本端を突破、q0現在Lastは端以内。正実体・突破足の相対量を併用 | 背景を分けず突破の反対側へ。診断対照 |
| FD | FAと同じ状態に、15分ADXの低さ又は低下を加える | 突破の反対側を試す反転仮説 |
| RT | 同じ端復帰状態に、強まりつつある15分ADX、元向きDI、30分EMA21傾き、5分Hist増分、現在Lastの前足始値回復を加える | 元の突破方向を試す再試行仮説 |
| RB | 低ADX、15分BB中心からの価格位置、5分RSI増分、1分量・TR、実体回復又は拒絶ヒゲを組み合わせる | 回復の仮説方向へ。レンジ端候補 |
| N0 | FD・RT・RBのOR。反対注文が同q0で競合すれば待機 | 新候補の統合 |
| C1 | 145で固定した旧87取得を全て保持 | 負けた旧新規6件も除外しない固定対照 |
| U0 | C1とN0を同q1 caseで統合し、重なればC1優先 | 主政策。反対方向の重複も隠さず記録 |

完全な閾値・等号・三値論理は条件bookを正本とする。表は説明であり追加フィルタではない。15分ADXは方向の強さ、DIは向き、30分EMA21は背景、5分Hist/RSIは勢い、1分実体・ヒゲ・高安端は構造、量は参加の代理として役割を分ける。同じ価格由来の複数指標を独立した証拠の票数として扱わない。

## 一般論・心理仮説・研究事実を分ける

一般教材では、突破した抵抗が支持へ変わる場合と水準を帯として見る考え方が説明される。端への再接近と、その後の支持・拒否の成立は別である。[CME](https://www.cmegroup.com/education/courses/technical-analysis/support-and-resistance)、[StockCharts・Rectangle](https://chartschool.stockcharts.com/table-of-contents/chart-analysis/chart-patterns/rectangle)

ADXは方向と独立した強さであり平滑遅れもある。高ADX・ADX低下のどちらも、継続や反転を単独で確定しない。BBへの接触単独も売買信号ではなく、帯沿いの継続がある。[StockCharts・ADX](https://chartschool.stockcharts.com/table-of-contents/technical-indicators-and-overlays/technical-indicators/average-directional-index-adx)、[Bollinger公式ルール](https://www.bollingerbands.com/bollinger-band-rules)

「端を維持できず突破参加者の返済が増える」「強い背景では押し目買い・戻り売りが支える」「低い方向性の下で帯端の偏りが修正される」は本試行の心理仮説である。主体や注文理由を観測していない。**終値突破→現在端以内という状態を、反転完成やリテスト成功とは呼ばない。** RTも次の再突破や成功したリテストを確認した手法ではない。直前3本端は、複数回試された支持抵抗と自動的に同一ではない。[Wyckoff教材](https://chartschool.stockcharts.com/table-of-contents/market-analysis/wyckoff-analysis-articles/wyckoff-market-analysis)

149の事後小群では、T4の端復帰26件が実逆16順4逆だった一方、R3の現在Lastが前足始値回復を失った25件は元向き14順6逆だった。この違いを背景と構造の役割で区別できるかが新しい問いである。全期既使用の事後群から着想しており、150の検証済み優位や未知期成功ではない。[149結果](../00149_継続と反転を可読8局面で判定する/README.md)、[共通知見](../../docs/議論/構造の成立水準と無効水準を局面別に分ける.md)

**FA/FD/RTの量は終値突破足rの量であり、その後に端へ戻った動きの量ではない。** OHLCVの総量は買い成行・売り成行の内訳でもない。未確認の反対構造、後続の回復足、将来pivotを当時の証拠へ足さない。資料確認日：2026-11-12。上記教材は日中NK225の±125pt先着70%や、本試行のADX等の最適閾値を裏付ける実証ではない。

## 入力・判断・評価

148の当時特徴・取得対応・入口参照の保存gzipと100列定義を共用する。BUY/SELLは同q0のAsk/Bidを使って別計算済みの100値であり、単なる符号反転ではない。全q0の判断を先に生成してから取得対応と結合する。q1価格・取得有無・将来ラベル・損益は条件の入力へ渡さない。

同q1 caseの新候補は最初のq0を代表にし、旧C1との重複は旧87を優先する。未知を既知0へ補完せず、反対方向の競合・未取得・品質取消・期限切れも記録する。固定73場は全て既使用。追加2場の価格は未読のままとし、独立未知期の検証とはしない。広い容量調査は非金融の成立余地を調べた参考資料で、150の自然選択・運用頻度・成功率の結果ではない。

主評価は実BBO・取得後60分・同幅±125ptの到達済み利確側先着率70%以上。順行・逆行・未到達・観測不足と全取得数を分け、全73場min1と、全720時間55分を分母にした平均概ね1回/時も別及び共同で判定する。場ごとの一律頻度や強制時刻は課さない。途中の条件成立数や枚数分割を取得回数へ代用しない。逆向きは保存した実BBO側を用い、1−pで推定しない。

mini1枚換算で1pt=100円、往復税込手数料77円。費用C0は手数料のみ、C5は片道5ptずつの追加滑り計10pt=1,000円を加える。期限清算や実逆も同条件で比較し、IFD金額の既知・未知を分ける。Lastはチャート側の先着診断とし実約定金額へ置換しない。全件の重複保有を許す独立ケースのIFD代用合算であり、片側10枚・両建て口座の収支や実注文、利益追尾の有効性を検証したものではない。

## 実行前の固定と再現予定

数値条件JSONのSHA256：`b0f3652a3a7f912a1e18a1c9aad8b990d9a07e7ccaa524a38cd141830d07453a`。
共通選択器のSHA256：`2f46be32a23ce2c1e5e99f2714ed4fd1eb14c545e4e150a2efd8d112e5c5344a`。

[共通選択器](../../scripts/入口研究/固定特徴から可読条件を選択する.py)、[100列定義](../../inputs/00148_全1分入口母集団/100特徴の列定義.json)、[148保管索引](../00148_全1分知得から入口品質の母集団を固定する/保管索引.json)を参照する。実行前3MD・コード・条件・容量と独立人工の指紋をF0へ固定してから、Rootの選択driverを実行する予定である。入口固定後に共有観測を評価し、条件を交換せず結果を追記する。金融CSVは未生成。新Raw走査・原板複写・追加インストールは不要である。
'''
    conditions = '''# 150 条件・実行前固定

作成日：2026-11-12。準備段階。自然選択・新金融評価は未実行。全数値条件と論理木の正本は[条件.json](../../inputs/00150_構造状態の可読選択/条件.json)。SHA256 `b0f3652a3a7f912a1e18a1c9aad8b990d9a07e7ccaa524a38cd141830d07453a`。Root運転用の同bytes原本は `work/150構造状態の可読条件/条件.json` で、内容差は許さない。

## 固定単位

- 主N0はFD・RT・RBのOR、主評価政策U0はN0と旧C1全87の統合。FAは個別診断だけでORから除外する。各政策を結果後に主へ交換しない。
- 対象は148に固定した全73場。C1は145旧87取得の全件を保護し、149や150で負け群を選別除外しない。前48/後25は既使用期間の参考分割であり独立未知期ではない。
- 入力は148の[当時特徴](../../inputs/00148_全1分入口母集団/当時特徴.json.gz)・[取得対応](../../inputs/00148_全1分入口母集団/取得対応.json.gz)・[入口参照](../../inputs/00148_全1分入口母集団/入口参照.json.gz)。[100列](../../inputs/00148_全1分入口母集団/100特徴の列定義.json)の物理SHAは `c85223fbe1543e5457c28d4391f817534099d1af1d19664035c668ff5fe8a7b4`。148の[保存実正逆観測](../00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz)を後段で共有する。
- q0全判断の生成とq1取得結合を段階分離する。選択器に金融ラベル・観測・Raw・新CSV・追加2場を渡さない。

## 式・方向・未知

`s`は技術状態を評価する側（買+1/売−1）で、最終注文側と分ける。rは最新の知得1分足、pはその直前の実隣接足、E_sはrを除く直前3本の買側最高値/売側最安値。`ATR5`は5分ATRである。

| 派生式 | 元100特徴からの式 | 意味 |
| --- | --- | --- |
| close_break | q0_last_minus_prior3_forward_edge_atr5_to_side − q0_last_minus_m1_close_atr5_to_side | s×(r.Close−E_s)/ATR5 |
| last_reclaim | m1_body_reclaim_atr5_to_side ＋ q0_last_minus_m1_close_atr5_to_side | s×(Last0−p.Open)/ATR5 |

共通は正常な正スプレッド20pt以下、q0Lastとr終値の符号付き距離がATR5の−1〜+1。完全な等号はJSONで固定する。共通品質を最小技術役割数へ加算せず、実際に成立へ寄与した別役割の元列が2種類以上必要である。量や価格のknownは100列定義どおりで、未知はnullのまま扱う。

FA/FD/RTは、終値の端突破（close_break>0）と現在Lastの端以内、正実体、r量が先行3本平均以上という同じ状態を使う。FDは15分ADX≤25又はADX増分<0で実注文をsの反対へ。RTはADX>25かつ増分≥0、DI・30分EMA21傾き・5分Hist増分がs向き、現在Lastがp始値をs向きに回復していればs向きへ。30分EMA21増分の正規化は**30分ATR**でありATR5ではない。ADXの方向を符号付きDIで代用したり、その逆にしたりしない。

RBは15分ADX≤20、q0実気配の15分BB中心からの距離がs向き−1σ以下、5分RSI増分>0、r/p量比≥1、rのTR/ATR5≤1.5と、次のORである。①r終値のp始値回復≥0、又は②逆側ヒゲ比≥0.4かつ正実体。①へ正実体条件を追加しない。−1σを±2σ帯接触へ置換しない。RBの回復はr終値の式であり、RTの現在Last回復と混同しない。

論理は三値で、ANDは偽が1つあれば偽、偽なしで未知があれば未知。ORは真が1つあれば真、真なしで未知があれば未知。成立しない枝の列を成立役割へ足さない。BUY/SELLの100値をそれぞれ明示評価し、FD/FAの注文だけsを反転する。反転のために将来q1価格を特徴へ入れず、技術側で成立した列を最終注文側の列へ差し替えない。同q0で同じ政策の両注文方向が成立すれば競合待機とする。

## 取得結合と旧対照

全q0判断の保存後にだけ取得対応・metadataを読み込む。自然母集団の既存q1 normal取得代用、1秒以降・30秒TTL、場/限月・phase・品質の規則を再選択で緩めない。ここで新しいpending、cap、hold、実逆側注文適格性を再構築するものではない。

取得参照はq0原行順に処理し、同q1 caseを複数q0が参照すれば最初を代表とする。条件成立・出生・未取得とunique case取得を分ける。U0は旧C1全87から始め、N0の新caseだけ追加。同q1で反対方向でもC1を優先し、その重複と方向差を隠さない。新policy同士の競合を結果や将来価格で解消しない。

## 評価と未評価の扱い

主は実BBO・取得後60分・同幅±125pt。Hcompleteの順行先着Fと逆行先着AについてF/(F+A)≥70%を目指す。未到達N・観測不足Cを別記し、全件比・観測完了比・IFD既知/未知も併記する。「勝率」だけで分母を省略しない。各場最低1取得、全720時間55分を分母とする平均概ね1回/時も必要で、いずれかだけの達成を全目標達成としない。場の不均等頻度を許容し、0場を除外しない。

保存されたH30/H60、幅25/50/100/125/200pt、BBO/Last、前48/後25/全73を条件交換なしで比較する。実逆は同取得時点の反対BBO streamを使い、1−pで推定しない。数量は独立mini1枚ケース、往復77円。費用C0は77円、C5はさらに片道5pt×2×100円=1,000円。期限清算代用のknown/unknownを残し、LastからIFD金額を作らない。重複保有ケースの診断合算と枚数上限のある実口座は別である。運用の利益追尾比較を実施したとはしない。

## 準備根拠・凍結予定

共通選択器は[固定特徴から可読条件を選択する.py](../../scripts/入口研究/固定特徴から可読条件を選択する.py)、SHA256 `2f46be32a23ce2c1e5e99f2714ed4fd1eb14c545e4e150a2efd8d112e5c5344a`。作者人工4群、独立初期8群＋union追補4群が成功。初期独立票は旧版を対象とし、最終Sourceへのbindはunion追補票である。自然選択成功の証跡へ読み替えない。

非金融容量調査は本仕様着想時に既知で、候補・unique取得参照・C1統合の容量を調べた資料に限る。150の自然選択や新金融の成績は未生成で、取得数・率・金額はnull。Rootが条件・Source・本3MD・容量・人工・共有入力の指紋をF0へ固定してから選択する。入口固定後のF1と後段金融は別段階とし、結果を見て閾値・主政策・対象場を変更しない。

外部資料の一般論、心理仮説、149の既使用事後群、新150仮説は[README](README.md)で区別した。外部確認日2026-11-12。端復帰は反転完成/リテスト成功ではなく、突破r量は復帰量ではない。日足教材の数日・百分率を分足へ移していない。原板/177MB入力/旧大観測/engineを重複保存せず共有する。
'''
    save(FORMAL / 'README.md', readme)
    save(FORMAL / '条件.md', conditions)

    template = TABLE.read_text(encoding='utf-8-sig')
    copied = relink(template[template.index('## 手法×時間スケール'):], TABLE, FORMAL / '設定と結果.md')
    copied = copied.replace('全セルは未設定・未検証。', '下表は150の実行前設定。使用セルも全て未検証であり、複合成績を単独指標の効果としない。')
    settings = {
        ('I01', 5): '150-RT：30分EMA21Δ/ATR30>0；準備・未検証',
        ('I03', 3): '150-RT：5分HistΔ/ATR5>0；準備・未検証',
        ('I04', 3): '150-RB：5分RSIΔを技術側>0；準備・未検証',
        ('I05', 4): '150-RB：15分BB中心距離/σ≤−1；準備・未検証',
        ('I08', 4): '150-FD/RT/RB：ADX水準/Δ・DI向きはbook；準備・未検証',
        ('I09', 3): '150-N0：5分ATRで距離/TRを正規化；準備・未検証',
        ('I09', 5): '150-RT：30分EMAΔの分母ATR30；準備・未検証',
        ('C01', 0): '150-RT/RB：MA・Hist・RSIは枝別併用；準備・未検証',
        ('C02', 0): '150-RB：BB位置×RSIΔ×量×構造；準備・未検証',
        ('C03', 0): '150-RB：BB位置×量×実体/ヒゲ；準備・未検証',
        ('C04', 0): '150-FD/RT/RB：強さと向きを分離；準備・未検証',
        ('C07', 0): '150-N0：30分背景/15分強さ/5分勢い/1分構造；準備・未検証',
        ('P01', 1): '150-FA/FD/RT/RB：実体・逆ヒゲ・p始値回復；準備・未検証',
        ('P02', 1): '150-FA/FD/RT：r除く実連続prior3端；準備・未検証',
        ('P03', 1): '150-N0：prior3端は支持抵抗完成と区別；準備・未検証',
        ('P05', 0): '150-N0：現在Lastと既知足/端の差；準備・未検証',
        ('P06', 0): '150-FA/FD/RT：現在Lastの端以内；準備・未検証',
        ('P07', 1): '150-FA/FD/RT：close_break>0；準備・未検証',
        ('P09', 0): '150-FD/RT：現在端復帰は反転/再試行の仮説；準備・未検証',
        ('V01', 1): '150-FA/FD/RT：r/先行3量≥1；RB：r/p量≥1；準備・未検証',
        ('B01', 0): '150共通：0<spread≤20pt；準備・未検証',
        ('E01', 0): '150主U0：取得後H60±125pt実BBO；準備・未検証',
        ('E01', 6): '150診断：H60/5幅・未到達/不足を分離；準備・未検証',
    }
    result_lines = []
    for line in copied.splitlines():
        parts = [item.strip() for item in line.split('|')[1:-1]]
        if len(parts) == 11 and re.fullmatch(r'[A-Z]\d{2}', parts[0]):
            for scale in range(9):
                parts[scale + 2] = settings.get((parts[0], scale), '未使用・未検証')
            line = '| ' + ' | '.join(parts) + ' |'
        result_lines.append(line)
    settings_text = '''# 150 設定と結果

状態：実行前準備。選択/新金融は未実行。数値条件の正本は[条件JSON](../../inputs/00150_構造状態の可読選択/条件.json)、説明は[条件.md](条件.md)。

汎用表は[版7](../../docs/議論/手法と時間スケールの汎用表_版7.md)、元SHA256 `585d0d9ba69ff3601325e9e6564ede53aeb81b0d33a2da6cb67e20e175187c3d`。57手法・9尺度＝513セル、ID・手法順を保持。相対リンクを本試行から同じ教材/コードへ移設した。新たな手法IDは追加しない。

共通設定ID150-Qはq0品質、150-FA/FD/RT/RBはbookの同名枝、150-N0はFD/RT/RBのOR、150-U0は旧C1を優先する主統合。表の閾値は短い索引で、完全な数値・AND/OR・等号はJSON正本へ従う。足幅と判断時計を分離し、1分のTRを1分ATR、30分EMAΔの分母を5分ATRと呼ばない。

''' + '\n'.join(result_lines) + '''

## 主政策と診断の実行状態

| 政策 | 新取得数 | 全場min1 | 平均取得/時 | H60±125pt到達済み先着率 | C5既知利益/損失/差引 | 状態 |
| --- | --- | --- | --- | --- | --- | --- |
| FA | null | null | null | null | null | 未実行・背景なし反転対照。主ORから除外 |
| FD | null | null | null | null | null | 未実行・減速背景で反転する仮説 |
| RT | null | null | null | null | null | 未実行・整合背景で元方向を再試行する仮説 |
| RB | null | null | null | null | null | 未実行・帯端の実体回復/ヒゲ拒絶仮説 |
| N0 | null | null | null | null | null | 未実行・FD/RT/RBのOR |
| C1 | 旧87を保持予定 | null | null | null | null | 旧値の再現照合は今後実行 |
| U0 | null | null | null | null | null | 主・C1優先統合。全目標の結果未判定 |

未知・未実行を0回/0%/0円へ置換しない。既存の非金融容量は実行前着想資料であり、本表の自然選択結果ではない。C1保護と参加の数値、到達済み率70%、平均概ね1回/時は別及び共同で判定する。先着率と全取引勝率を同義にしない。

元表の手法一覧を利用しているが全57手法の最適化ではない。未使用の100列や教材を条件へ暗黙追加せず、特にVWAP/VWMA・SAR・新MLモデルは本条件に使わない。決済追尾は本試行の変更対象ではなく、保存観測による固定IFDの入口診断である。
'''
    save(FORMAL / '設定と結果.md', settings_text)

    original_rows = table_rows(template)
    formal_rows = table_rows(settings_text)
    assert len(original_rows) == len(formal_rows) == 57
    assert len(formal_rows) * 9 == 513
    assert [row[0] for row in original_rows] == [row[0] for row in formal_rows]
    for old, new in zip(original_rows, formal_rows):
        assert relink(old[1], TABLE, FORMAL / '設定と結果.md') == new[1]
    links = []
    for name in ('README.md', '条件.md', '設定と結果.md'):
        path = FORMAL / name
        for match in re.finditer(r'\[[^\]]+\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            link = match.group(1).split('#')[0]
            if link and '://' not in link:
                assert (path.parent / link).exists(), (name, link)
                links.append({'文書': name, 'リンク': link})
    assert before == {str(path.relative_to(ROOT)).replace('\\', '/'): sha(path) for path in watched}
    proof = {'成功': True, '編集停止': True, '試行': 150,
        'UTC': datetime.now(timezone.utc).isoformat(), '段階': 'F0前の正式3MD準備',
        '主政策': 'U0', '主OR': ['FD', 'RT', 'RB'], 'FAは診断対照だけ': True,
        '自然選択': '未実行', '金融評価': '未実行', '最終選択数': None, '先着率': None, '損益': None,
        '新Raw/CSV/ラベル/追加2場の本文読取': False,
        '元条件と固定Source前後同体': True, '指紋': before,
        '定義57行9尺度513セル': True, 'ID手法順と教材リンク同体': True,
        '全ローカルリンク': len(links), 'リンク': links,
        '条件book一度恒久保存': {'path': str(INPUT.relative_to(ROOT)).replace('\\', '/'), 'bytes': INPUT.stat().st_size, 'sha256': sha(INPUT)},
        '正式3MD': {name: sha(FORMAL / name) for name in ('README.md', '条件.md', '設定と結果.md')},
        '旧試行と目次AGENTSを変更': False, '準備器SHA256': sha(Path(__file__))}
    save(ROOT / 'work/150正式文書の準備確認.json', json.dumps(proof, ensure_ascii=False, indent=2))
    print(json.dumps({'成功': True, '3MD': proof['正式3MD'], '準備票SHA256': sha(ROOT / 'work/150正式文書の準備確認.json'), 'リンク数': len(links)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
