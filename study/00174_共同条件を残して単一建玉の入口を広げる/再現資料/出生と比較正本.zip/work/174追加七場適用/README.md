# 174固定少数政策の追加七場適用

174の旧73joint固定選択票から、全期・前48のcandidatesを保存順に各最大2件だけ読む。RootがGO時に示す固定票SHA256を確認し、候補追加・並べ直し・閾値調整・追加7を見た再選択は行わない。追加7は既使用の参考期間であり、独立未見とは呼ばない。

173参考適用のSourceを別workへ適応し、共通の基盤173・構成173・engine173・metrics173を未改変で使う。主出生は172の選定政策出生部品、LOCAL主が含まれる場合は固定LOCAL173部品を使う。全場履歴で既適用のALL/EDGE・正逆・幅geometryを維持する。

純構成後、174の`段階再生174.delay_day_fallback`を呼び、policyの`day_fallback_after_minutes`（未指定時45分）によりデイ補完方向/tierだけをマスクする。主方向とNightを変えず、この遅延も含めて旧73・追加7のNPZを金融読込前に封印する。

旧73の選定主方向は174の保存済み短表純出生と全件一致を確認し、global1再生後は174段階結果の全期・前48・後25×DAY/PRE/POST/NIGHTの全金融dictへ一致確認する。追加7は固定政策のまま参考適用する。買売合計で保有・未決一件まで、未知場末保持・同秒exit秒末解放・同q0で別側へ代用しない規則は173共通基盤のままである。

出力schemaは173追加適用と同じ。`旧73の全取得174.json.gz`と`追加7の全取得174.json.gz`は172型cases/sides/events/phases/origins/widths/horizons/tiers/engineへpolicy、financial、ledgerを加える。ledgerのnetは未知None、sceneは実セッションID文字列。`全80の両中央値174.json.gz`は両期間の台帳を連結してmetrics173で再計算し、建玉中央値と全Day/Night場中央値の上下限、完全場だけの既知中央値、0取得場を区別する。中央値を加算しない。

`出生前の固定.json`、`金融前の出生固定.json`、`完了.json`へSource・固定選択・非金融入力・純出生・全成果物のSHA256を記録する。NPZは`旧73の純出生174.npz`と`追加7の純出生174.npz`。主・補完・幅・期限・成分・競合・共通phasesを保持する。旧173/174 Sourceや正式結果を編集せず、この新workだけに保存する。

Root GO後の実行：

```powershell
python work/174追加七場適用/固定政策を適用する.py --fixed-sha256 <Root提示の固定選択SHA256> --execute
```

出力未作成が前提で、上書き再生は行わない。自然のRaw・共有金融配列・feature cache・取得descriptor全件を不要に複製せず、恒久163/167と既存純特徴を参照する。CSVはこの処理では作らない。
