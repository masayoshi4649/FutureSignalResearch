"""173前48J026の累計経路を、各帯で独立に診断する。"""
from pathlib import Path
from datetime import date, datetime, timezone, timedelta
import csv
import gzip
import hashlib
import json
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[3]
HERE=Path(__file__).resolve().parent
SOURCE=ROOT/'outputs/00174_追加禁止と両中央値の比較/173_前48_J026'


def read_rows(path: Path) -> list:
    """
    機能: 候補別CSVを日付順の文字列辞書として読む。
    引数: path(Path)は固定CSV。
    返り値: list[dict[str,str]]はセッション開始日順。
    """
    with path.open(encoding='utf-8-sig',newline='') as stream:
        rows=list(csv.DictReader(stream))
    assert rows==sorted(rows,key=lambda r:r['セッション日'])
    assert len(rows)==40 and {r['候補'] for r in rows}=={'173:前48_J026'}
    return rows


def calendar_days(start: str | None, end: str | None) -> int | None:
    """
    機能: 日付の差を暦日数へ換算する。
    引数: start/end(str|None)はISO日付。開始前基準はNone。
    返り値: int|Noneは日差。基準日がない場合はNone。
    """
    return (date.fromisoformat(end)-date.fromisoformat(start)).days if start and end else None


def path_stats(dates: list, values: list) -> dict:
    """
    機能: ゼロ開始の確定又は既知寄与の累計経路を計算する。
    引数: dates(list[str])、values(list[float])は同順の各場損益。
    返り値: dictは累計底、DD、回復、全水面下区間、連続赤字場。
    """
    assert len(dates)==len(values)
    cumulative=[];total=0.0
    for value in values:
        total+=value;cumulative.append(total)
    if not values:
        return {'場数':0}
    lowest=min([0.0,*cumulative]);low_index=cumulative.index(lowest) if lowest<0 else None
    first_recovery=next((i for i,c in enumerate(cumulative) if c>=0),None)
    last_below=max((i for i,c in enumerate(cumulative) if c<0),default=None)
    permanently_above_index=last_below+1 if last_below is not None and last_below+1<len(cumulative) else None
    peak=0.0;peak_first=-1;peak_last=-1;maximum=0.0;drawdown=None
    open_episode=None;episodes=[]
    loss_start=None;loss_streaks=[]
    for i,(current,value) in enumerate(zip(cumulative,values,strict=True)):
        if current>=peak:
            if open_episode is not None:
                open_episode['回復日']=dates[i]
                open_episode['回復までの場数']=i-open_episode['ピーク位置']
                open_episode['水面下の場数']=i-open_episode['ピーク位置']-1
                open_episode['暦日数']=calendar_days(open_episode['最後のピーク日'],dates[i])
                episodes.append(open_episode);open_episode=None
            if current>peak:
                peak_first=i
            peak=current;peak_last=i
        else:
            dd=peak-current
            if open_episode is None:
                open_episode={'ピーク位置':peak_last,'ピーク初日':dates[peak_first] if peak_first>=0 else None,
                    '最後のピーク日':dates[peak_last] if peak_last>=0 else None,'ピーク累計':peak,
                    '水面下開始日':dates[i],'底日':dates[i],'底累計':current,'DD':dd}
            elif dd>open_episode['DD']:
                open_episode.update({'底日':dates[i],'底累計':current,'DD':dd})
            if dd>maximum:
                maximum=dd
                drawdown={'ピーク初日':dates[peak_first] if peak_first>=0 else None,
                    '最後のピーク日':dates[peak_last] if peak_last>=0 else None,'ピーク累計':peak,
                    '底日':dates[i],'底累計':current,'DD':dd,'ピーク位置':peak_last,'底位置':i}
        if value<0:
            if loss_start is None:loss_start=i
        elif loss_start is not None:
            loss_streaks.append({'開始':dates[loss_start],'終了':dates[i-1],'連続場数':i-loss_start,
                '合計損失':sum(values[loss_start:i])});loss_start=None
    if open_episode is not None:
        open_episode.update({'回復日':None,'回復までの場数':None,
            '水面下の場数':len(values)-open_episode['ピーク位置']-1,
            '暦日数':calendar_days(open_episode['最後のピーク日'],dates[-1])})
        episodes.append(open_episode)
    if loss_start is not None:
        loss_streaks.append({'開始':dates[loss_start],'終了':dates[-1],'連続場数':len(values)-loss_start,
            '合計損失':sum(values[loss_start:])})
    if drawdown:
        recovery=next((i for i in range(drawdown['底位置']+1,len(values)) if cumulative[i]>=drawdown['ピーク累計']),None)
        drawdown.update({'回復日':dates[recovery] if recovery is not None else None,
            '底から回復までの場数':recovery-drawdown['底位置'] if recovery is not None else None,
            'ピークから回復までの場数':recovery-drawdown['ピーク位置'] if recovery is not None else None,
            'ピークから回復までの暦日数':calendar_days(drawdown['最後のピーク日'],dates[recovery]) if recovery is not None else None})
    worst_index=min(range(len(values)),key=lambda i:values[i])
    return {'場数':len(values),'累計':cumulative,'最終累計':total,'ゼロ開始の累計最小値':lowest,
        'ゼロ開始の底日':dates[low_index] if low_index is not None else None,
        '初回ゼロ回復日':dates[first_recovery] if first_recovery is not None else None,
        '初回ゼロ回復は何場目':first_recovery+1 if first_recovery is not None else None,
        '以後ゼロを割らなくなる日':dates[permanently_above_index] if permanently_above_index is not None else None,
        '開始12場の累計負場数':sum(c<0 for c in cumulative[:12]),
        '最大DD':drawdown,'全水面下区間':episodes,
        '最長水面下区間':max(episodes,key=lambda e:e['水面下の場数']) if episodes else None,
        '最長連続赤字場':max(loss_streaks,key=lambda e:e['連続場数']) if loss_streaks else None,
        '全連続赤字場':loss_streaks,'最大損失場':{'日付':dates[worst_index],'損益':values[worst_index]}}


def trade_loss_streak(ledger: dict, phases: list, phase: int) -> dict:
    """
    機能: 金融未知で連続を区切り、各帯の既知建玉の連続損失を数える。
    引数: ledger(dict)はnet/known/scene、phases(list[int])、phase(int)は対象帯。
    返り値: dictは最大既知連敗。未知をまたぐ真の最大連敗は確定しない。
    """
    current=[];best=[];unknown=0
    for net,known,scene,p in zip(ledger['net'],ledger['known'],ledger['scene'],phases,strict=True):
        if p!=phase:continue
        if not known:
            unknown+=1;current=[]
        elif net<0:
            current.append({'scene':scene,'net':net})
            if len(current)>len(best):best=current.copy()
        else:
            current=[]
    return {'金融未知数':unknown,'最大既知連敗':len(best),'取引列':best,
        '意味':'対象帯の取得順。無取引場は取引列へ入れず、未知は連続を区切る。未知がある帯の真の最大連敗を確定しない。'}


def timed_drawdown(trades: list) -> dict:
    """
    機能: 実金融表の既知exit秒から決済順のDD到達時刻を確認する。
    引数: trades(list[dict])はknown/net/phase/exit_timeを持つ取引。
    返り値: dictは帯別の既知決済寄与DD時計。未知を含む帯は全件DDではない。
    """
    result={};jst=timezone(timedelta(hours=9))
    for phase,band in enumerate(('DAY','PRE','POST')):
        selected=[t for t in trades if t['phase']==phase]
        known=sorted([t for t in selected if t['known']],key=lambda t:t['exit_time'])
        total=0.0;peak=0.0;peak_time=None;maximum=0.0;maximum_info=None;points=[]
        for t in known:
            total+=t['net'];points.append((t['exit_time'],total))
            if total>=peak:
                peak=total;peak_time=t['exit_time']
            elif peak-total>maximum:
                maximum=peak-total
                maximum_info={'ピーク時刻':peak_time,'ピーク累計':peak,'底時刻':t['exit_time'],'底累計':total,'DD':maximum}
        if maximum_info:
            recovery=next((clock for clock,value in points if clock>maximum_info['底時刻'] and value>=maximum_info['ピーク累計']),None)
            maximum_info['回復時刻']=recovery
            for key in ('ピーク時刻','底時刻','回復時刻'):
                clock=maximum_info[key]
                maximum_info[key]=datetime.fromtimestamp(clock,jst).isoformat() if clock is not None else None
        zero_recovery=next((clock for clock,value in points if value>=0),None)
        result[band]={'金融未知数':len(selected)-len(known),'既知決済寄与の最大DD':maximum_info,
            '初回ゼロ回復時刻_既知寄与':datetime.fromtimestamp(zero_recovery,jst).isoformat() if zero_recovery is not None else None,
            '意味':'時刻は共用金融IFD_FIRSTのexit_timeをJST表示。場日付ラベルではない。未知ありの帯は全件確定DDではない。'}
    return result


def main() -> None:
    """
    機能: 固定173前48J026の3帯を読み、既知寄与と確定区間を別に集計する。
    引数: なし。
    返り値: None。作業領域へJSON/Markdownを保存し、主要値を表示する。
    """
    trial=next((ROOT/'study').glob('00173_*'))
    with zipfile.ZipFile(trial/'再現資料/出生と比較正本.zip') as archive:
        data=json.loads(gzip.decompress(archive.read('work/173追加七場適用/全80の両中央値173.json.gz')))
        timed=[]
        for period,directory in (('旧73','inputs/00163_任意幅の共用価格索引/数値表'),
                                 ('追加7','inputs/00167_追加七場の入口と共用価格索引/自然数値表')):
            packed=json.loads(gzip.decompress(archive.read(f'work/173追加七場適用/{period}の全取得173.json.gz')))
            row=next(r for r in packed['rows'] if r['id']=='前48_J026')
            with np.load(ROOT/directory/'任意幅配列.npz',allow_pickle=False) as source:
                exit_times=source['exit_time']
                for case,side,wi,hi,p,net,known in zip(row['cases'],row['sides'],row['widths'],row['horizons'],row['phases'],row['ledger']['net'],row['ledger']['known'],strict=True):
                    clock=float(exit_times[case,side,wi,hi]) if known else None
                    if known:assert np.isfinite(clock) and clock>0
                    timed.append({'phase':p,'net':net,'known':known,'exit_time':clock})
    fixed=next(r for r in data['rows'] if r['id']=='前48_J026')
    result={'候補':'173:前48_J026','基準':'各帯へ帰属した場末決済収支。建玉中の値動き/全ティックDDではない。','bands':{}}
    result['既知決済のDD到達時計']=timed_drawdown(timed)
    for phase,(band,name) in enumerate((('DAY','デイ'),('PRE','ナイト_米前'),('POST','ナイト_米後'))):
        path=SOURCE/(name+'.csv');rows=read_rows(path)
        dates=[r['セッション日'] for r in rows]
        known=[float(r['収支円_既知分']) for r in rows]
        unknown=[int(r['金融未知件数']) for r in rows]
        known_stats=path_stats(dates,known)
        assert known_stats['累計']==[float(r['累計収支円_既知分']) for r in rows]
        first_unknown=next((i for i,u in enumerate(unknown) if u),len(rows))
        prefix=path_stats(dates[:first_unknown],known[:first_unknown])
        assert all(r['累計収支円_全件確定']!='' for r in rows[:first_unknown])
        assert all(r['累計収支円_全件確定']=='' for r in rows[first_unknown:])
        result['bands'][band]={'CSV_SHA256':hashlib.sha256(path.read_bytes()).hexdigest(),
            '金融未知件数':sum(unknown),'最初の金融未知日':dates[first_unknown] if first_unknown<len(rows) else None,
            '既知寄与の全期経路':known_stats,'全件確定する連続前置区間':prefix,
            '全期の正確なDDを確定可能':not any(unknown),
            '建玉連敗':trade_loss_streak(fixed['ledger'],fixed['phases'],phase)}
        trade_rows=[(scene,net,known) for scene,net,known,p in zip(fixed['ledger']['scene'],fixed['ledger']['net'],fixed['ledger']['known'],fixed['phases'],strict=True) if p==phase]
        assert len(trade_rows)==sum(int(r['取得回数']) for r in rows)
        assert sum(float(net) for _,net,k in trade_rows if k)==known_stats['最終累計']
        trade_dates=[scene.split('_')[0] for scene,_,_ in trade_rows]
        trade_values=[float(net) if known else 0.0 for _,net,known in trade_rows]
        trade_path=path_stats(trade_dates,trade_values)
        result['bands'][band]['建玉決済順の既知寄与DD']={'取得数':len(trade_rows),
            'DD':trade_path['最大DD']['DD'] if trade_path.get('最大DD') else 0,
            'ピーク日':trade_path['最大DD']['最後のピーク日'] if trade_path.get('最大DD') else None,
            '底日':trade_path['最大DD']['底日'] if trade_path.get('最大DD') else None,
            '回復日':trade_path['最大DD']['回復日'] if trade_path.get('最大DD') else None,
            '意味':'取得順と決済順が一致するglobal1内の当該帯の既知決済寄与。建玉中の時価DDではない。金融未知ありの場合は全件確定DDではない。'}
        if phase==0:
            front_dates=set(dates[:12])
            by_origin={}
            for name,origin in (('主',0),('補完',2)):
                selected=[float(net) for scene,net,known,p,o in zip(fixed['ledger']['scene'],fixed['ledger']['net'],fixed['ledger']['known'],fixed['phases'],fixed['origins'],strict=True) if p==0 and scene.split('_')[0] in front_dates and o==origin and known]
                by_origin[name]={'取得':len(selected),'既知収支':sum(selected)}
            result['bands'][band]['最初12場の主補完加法分解']=by_origin
    HERE.mkdir(parents=True,exist_ok=True)
    (HERE/'173前48J026の経路診断.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    notes='''# 173 前48_J026の累計経路を再診断

2026-11-16。固定条件・正式CSV・金融正本は変更せず、候補別CSVの累計と正式173台帳を独立に読んだ。対象は要求mini1枚、買売合計保有/予約一件の同じ固定候補。

|帯|ゼロ開始累計の底|ゼロ回復|場末損益ベースの最大DD|確定性|
|---|---|---|---|---|
|デイ|−42,924円、10/05|初回9/29、再び沈み10/07以後ゼロ割れなし|48,385円。9/29 +5,461→10/05 −42,924、10/07回復|全40場・全67建玉既知。確定値|
|米前|−123,231円、9/23。開始3Night連続赤字|9/30（8場目）|全既知寄与の最大164,308円。10/23→10/27、寄与累計上は11/03回復|金融未知6件。全件の真の最大DD/回復日は未確定。初期−123,231と9/30回復は最初の未知10/06より前なので確定|
|米後|−2,077円、9/21|9/22|既知寄与最大28,154円、11/13で未回復|未知1件。11/10までの連続確定区間の最大DDは6,154円、10/30→11/09回復|

デイは最初12場中10場で累計マイナスだった。最初の水面下は9/21～9/28の6回の場末で、7場目9/29に回復。その後の最大DDでは5回の場末がピーク未満で、ピーク後6場目10/07に回復した。連続赤字場は最大3（10/09～10/13）、最大損失場は10/05の−25,154円。建玉単位の既知連敗も3（10/02～10/05）で、決済順累計の最大DDも48,385円だった。これは建玉中/全ティックの時価DDではない。

共用金融IFD_FIRSTのexit_timeで確認したデイ最大DDのピークは9/29 10:06:14 JST、底は10/05 15:39:59、ピーク回復は10/07 09:51:34。表の日付はCSVのセッション開始日ラベルで、ナイトの実決済は翌暦日になり得る。米前の既知寄与最大DDの底は実10/28 00:43:01、寄与上の回復は11/03 19:14:32。米後の既知寄与底は実11/14 00:55:45。ただし未知を含む帯の全件確定回復時刻ではない。

従って前回答の「デイDD48,385円」という数値自体は合っていたが、期間別合計/中央値が黒字という理由で安定と優先した判断は、開始時の沈み込みと回復の待ち時間を十分に示していなかった。ユーザーの指摘はデイにも当てはまり、米前ではさらに大きい開始損失が実在する。

米前10/26・10/27は各−82,154円、2Night合計−164,308円で、両日自体は金融既知。この局所下落額は確定している。ただしそれ以前/回復途上に未知があるため、全件累計のピーク水準・全期最大DD・11/03という全件回復日は確定しない。既知寄与累計を全件確定累計と呼ばない。

米後は無取引場が多く、低DDだけで頻繁に稼ぐ安定性の証拠とはしない。負け場の連続は各1場でも、無取引0円が間に入るため、建玉では11/13に2連敗している。

計算の全区間と各CSV SHAは `173前48J026の経路診断.json`。新CSV・新仮説・新研究試行は作っていない。
'''
    (HERE/'診断.md').write_text(notes,encoding='utf-8')
    for band,value in result['bands'].items():
        compact={k:v for k,v in value.items() if k not in ('既知寄与の全期経路','全件確定する連続前置区間')}
        for kind in ('既知寄与の全期経路','全件確定する連続前置区間'):
            compact[kind]={k:v for k,v in value[kind].items() if k not in ('累計','全水面下区間','全連続赤字場')}
        print(json.dumps({'band':band,**compact},ensure_ascii=False))


if __name__=='__main__':
    main()
