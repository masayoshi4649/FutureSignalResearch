"""固定候補の安定性再診断だけを小型の正式記録へ保存する。"""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00174_共同条件を残して単一建玉の入口を広げる'
DOC=ROOT/'docs/議論/安定性を累計経路と取引の広がりで評価する.md'


def ref(path: Path) -> dict:
    """
    機能: 正式資料のサイズ・位置・SHA256を返す。
    引数: path(Path)。
    返り値: dictはrepo相対path/bytes/sha256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,
        'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 新診断のSource/JSON/MDを元byteで保存し、原入力不変と案内を確認する。
    引数: なし。
    返り値: None。旧試行ZIP・条件・CSV・金融を変更しない。
    """
    here=Path(__file__).resolve().parent
    sources=[p for p in here.rglob('*') if p.is_file() and p.suffix in ('.py','.json','.md')]
    sources+=[ROOT/'scripts/実現利益の集中/累計経路を診断する.py',TRIAL/'検査/固定8候補の累計経路診断.json']
    target=TRIAL/'再現資料/安定性再診断.zip';assert not target.exists()
    before=[ref(p) for p in sorted(set(sources))]
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(set(sources)):
            archive.write(path,path.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        for record in before:
            assert hashlib.sha256(archive.read(record['path'])).hexdigest()==record['sha256']
    original=json.loads((TRIAL/'再現資料/保存索引.json').read_text(encoding='utf-8'))
    for name in ('Source.zip','出生と比較正本.zip'):
        assert ref(TRIAL/'再現資料'/name)['sha256'] in json.dumps(original)
    presentation=json.loads((TRIAL/'再現資料/候補別CSV索引.json').read_text(encoding='utf-8'))
    for record in presentation['現在のCSV']:
        assert ref(ROOT/record['path'])==record
    for path in (DOC,ROOT/'AGENTS.md',ROOT/'README.md',ROOT/'docs/README.md',TRIAL/'README.md',ROOT/'outputs/00174_追加禁止と両中央値の比較/README.md'):
        for link in re.findall(r'\[[^\]]*\]\(([^)]+)\)',path.read_text(encoding='utf-8-sig')):
            if re.match(r'[a-zA-Z]+://',link) or link.startswith('#'):continue
            name=link.split('#')[0].split('?')[0].strip('<>')
            assert not name or (path.parent/name).exists(),(str(path),link)
    result={'成功':True,'確認日':'2026-11-16','位置づけ':'固定8候補の事後診断と評価の見直し。新しい売買条件・政策の採用ではない。',
        'archive':ref(target),'members':before,'正式文書':ref(DOC),'既存研究ZIPと32CSV不変':True,
        '原資料':'173/174正式Source・小正本・恒久共用入力・候補別32CSV。Rawを複製していない。',
        '注意':'未知を含む経路は既知寄与だけ。場末実現損益DDと建玉中時価DDを区別。'}
    (TRIAL/'検査/安定性再診断の保存確認.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'member数':len(before),'ZIP':ref(target),'原データ不変':True},ensure_ascii=False))


if __name__=='__main__':
    main()
