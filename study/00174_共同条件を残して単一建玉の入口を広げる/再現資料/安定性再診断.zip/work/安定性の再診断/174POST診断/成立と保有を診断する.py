"""174全期J002のPOST頻度を既存出生・要求・占有時計から読取診断する。"""
from pathlib import Path
from io import BytesIO
from collections import Counter, defaultdict
import gzip
import json
import math
import sys
import zipfile
import numpy as np

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'work/173両中央値と単一建玉'))
import 基盤173 as B
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00174_共同条件を残して単一建玉の入口を広げる'


def read_member(archive: zipfile.ZipFile, name: str) -> dict:
    """
    機能: 正式ZIPのJSONを復元する。
    引数: archive(zipfile.ZipFile)、name(str)。
    返り値: dictはJSON又はgzip JSONの内容。
    """
    body=archive.read(name)
    return json.loads(gzip.decompress(body) if name.endswith('.gz') else body)


def pure_birth(source: object, prefix: str) -> tuple:
    """
    機能: 固定NPZから一政策の出生と幅・期限を取り出す。
    引数: source(np.lib.npyio.NpzFile)、prefix(str)は政策ID。
    返り値: tupleはbirth/mw/fw/hi。
    """
    start=prefix+'__'
    born={key:source[start+key].copy() for key in ('core','branches','technical','tier')}
    return born,source[start+'mw'].copy(),source[start+'fw'].copy(),source[start+'hi'].copy()


def occupied(context: object, pack: dict) -> list:
    """
    機能: 取得packの各保有区間をfill原行とexit秒末から復元する。
    引数: context(GenericContext)、pack(dict)は固定取得。
    返り値: list[dict]はscene/fill/exit/phase/originを含む保有区間。
    """
    descriptors=B.captures(context);rows=[]
    for i,event in enumerate(pack['events']):
        case,side,wi,hi=[int(pack[key][i]) for key in ('cases','sides','widths','horizons')]
        scene=int(context.event_scenes[event]);key=(case,side,wi,hi)
        end=float(context.arrays['exit_time'][key]) if context.arrays['known'][key] else float(context.scenes[scene]['end'])
        rows.append({'scene':scene,'fill':tuple(descriptors[event]['fill_key']),
            'exit':(end,math.inf,math.inf),'phase':int(pack['phases'][i]),
            'origin':int(pack['origins'][i]),'event':int(event)})
    return rows


def diagnose(context: object, pack: dict, born: dict, mw: np.ndarray, fw: np.ndarray, hi: np.ndarray) -> dict:
    """
    機能: POST出生を技術非成立・保有棄却・取得代用・初参加制御へ分ける。
    引数: context(GenericContext)、pack/born(dict)、mw/fw/hi(np.ndarray)。
    返り値: dictは帯別要求の件数と場別監査。反実仮想は件数診断だけを示す。
    """
    value=B.replay(context,born,mw,fw,hi,True)
    assert value[-1]==pack['engine']
    post=context.event_phases==2;intervals=occupied(context,pack)
    by_scene=defaultdict(list)
    for interval in intervals:by_scene[interval['scene']].append(interval)
    descriptors=B.captures(context)
    requests=[r for r in pack['engine']['requests'] if post[r['event']]]
    output={};scene_rows=[]
    for scene in np.flatnonzero(context.hours[:,2]>0):
        events=np.flatnonzero(post&(context.event_scenes==scene))
        current=[r for r in requests if r['scene_index']==scene]
        actual=[i for i,event in enumerate(pack['events']) if post[event] and context.event_scenes[event]==scene]
        stats=Counter()
        stats['POST_q0数']=len(events)
        stats['主技術成立q0']=int(np.count_nonzero(born['core'][events]))
        stats['補完技術成立q0']=int(np.count_nonzero(born['technical'][events]))
        for event in events:
            now=tuple(context.event_keys[event])
            if born['technical'][event] and not born['core'][event]:
                earlier=[r for r in by_scene[scene] if r['fill']<=now]
                if earlier:
                    first=min(earlier,key=lambda r:r['fill'])
                    stats['補完_初参加済みで要求なし_'+('PRE' if first['phase']==1 else 'POST')]+=1
        for request in current:
            event=request['event'];role='主' if request['origin']==0 else '補完'
            stats[role+'_要求']+=1
            if request['accepted']:
                stats[role+'_要求受理']+=1
                stats[role+'_取得代用_'+descriptors[event]['status']]+=1
            else:
                reason=request['skip_reason']
                if reason=='held':
                    now=tuple(context.event_keys[event])
                    holding=[r for r in by_scene[scene] if r['fill']<=now<r['exit']]
                    assert len(holding)==1,(request,holding)
                    stats[role+'_保有中棄却_'+('PRE' if holding[0]['phase']==1 else 'POST')]+=1
                else:
                    stats[role+'_未決棄却']+=1
        stats['実取得']=len(actual)
        stats['主実取得']=sum(pack['origins'][i]==0 for i in actual)
        stats['補完実取得']=sum(pack['origins'][i]==2 for i in actual)
        assert stats['主技術成立q0']==stats['主_要求']
        scene_rows.append({'scene':context.sessions[int(scene)],**dict(stats)})
    total=Counter()
    for row in scene_rows:
        for key,value in row.items():
            if key!='scene':total[key]+=value
    output['実政策のPOST']=dict(total)
    output['場数']={'対象':len(scene_rows),'主技術成立':sum(r.get('主技術成立q0',0)>0 for r in scene_rows),
        '実取得':sum(r.get('実取得',0)>0 for r in scene_rows),
        '主不成立':sum(r.get('主技術成立q0',0)==0 for r in scene_rows)}
    output['場別']=scene_rows
    # ----------------------------------------
    # 同じPOST規則だけを残す件数の反実仮想。新政策の採用や仮想利益の最適化は行わない。
    isolated={key:value.copy() for key,value in born.items()}
    for key in ('core','technical','tier'):isolated[key][~post]=0
    isolated['branches']=np.where(isolated['core']!=0,0,-1).astype(np.int8)
    for name,fallback in (('POSTのみ_元の初参加Tあり',True),('POST主のみ_Tなし',False)):
        replay=B.replay(context,isolated,mw,fw,hi,fallback)
        selected=replay[0]
        scenes=set(context.case_scene[selected.cases].tolist())
        output[name]={'取得':len(selected.cases),'取得場':len(scenes),
            '主取得':int((replay[1]==0).sum()),'補完取得':int((replay[1]==2).sum()),
            '注意':'PREを無効化した既存条件の原因診断。組合せの新政策又は元政策への加法利益ではない。金額による採用はしない。'}
    return output


def main() -> None:
    """
    機能: 旧73/追加7の固定POSTを照合し、頻度不足の原因を保存する。
    引数: なし。
    返り値: None。正式条件・金融・既存Sourceを変更せずworkへJSONを保存する。
    """
    source_paths=[Path(__file__).resolve(),ROOT/'work/173両中央値と単一建玉/基盤173.py',ROOT/'work/173追加なしの因果再生/engine173.py']
    before={str(p.relative_to(ROOT)):B.P.sha(p) for p in source_paths}
    output={'政策':'全期_J002','区分':'POST','位置づけ':'既存条件の原因診断。金融結果や条件の選択は変更しない。','期間':{}}
    with zipfile.ZipFile(TRIAL/'再現資料/出生と比較正本.zip') as archive:
        for period,new in (('旧73',False),('追加7',True)):
            context=B.load_context(new)
            packs=read_member(archive,f'work/174追加七場適用/{period}の全取得174.json.gz')
            pack=next(r for r in packs['rows'] if r['id']=='全期_J002')
            with np.load(BytesIO(archive.read(f'work/174追加七場適用/{period}の純出生174.npz')),allow_pickle=False) as pure:
                born,mw,fw,hi=pure_birth(pure,'全期_J002')
            output['期間'][period]=diagnose(context,pack,born,mw,fw,hi)
    assert all(B.P.sha(ROOT/path)==digest for path,digest in before.items())
    output['Source不変']=before
    (HERE/'成立と占有の診断.json').write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({period:{k:v for k,v in data.items() if k!='場別'} for period,data in output['期間'].items()},ensure_ascii=False))


if __name__=='__main__':
    main()
