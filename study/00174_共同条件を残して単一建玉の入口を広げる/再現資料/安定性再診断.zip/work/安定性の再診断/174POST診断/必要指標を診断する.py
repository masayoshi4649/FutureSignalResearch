"""POST主条件の非成立を必要指標未知と既知の条件不一致へ分ける。"""
from pathlib import Path
from collections import Counter
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[3]
sys.path.insert(0,str(ROOT/'work/173両中央値と単一建玉'))
import 基盤173 as B
sys.path.insert(0,str(ROOT/'work/162複合入口候補'))
sys.path.insert(0,str(ROOT/'work/172ナイト複合候補'))
from rules162 import PreparedEvaluator,candidate_catalog as old_catalog
from rules172_night import NightEvaluator,candidate_catalog as new_catalog


def rule_diagnosis(context: object, rule: dict, evaluator: object) -> dict:
    """
    機能: 既存一規則のPOST必要列・全条件・各条件の通過数を非金融で調べる。
    引数: context(GenericContext)、rule(dict)、evaluator(PreparedEvaluator)。
    返り値: dictはq0ごとの可用性と成立を場別に分けた診断。
    """
    truths=[];knowns=[];conditions=[]
    for side in (0,1):
        parts=[evaluator.comparison(side,c) for c in rule['conditions']]
        truths.append(np.stack([p[0] for p in parts]))
        knowns.append(np.stack([p[1] for p in parts]))
    known_all=[k.all(axis=0) for k in knowns];passed=[t.all(axis=0) for t in truths]
    decision=evaluator.evaluate_one(rule)
    scenes=[]
    adx,adx_known=evaluator.factor(0,'m15_adx')
    for scene in np.flatnonzero(context.hours[:,2]>0):
        rows=(context.event_scenes==scene)&(context.event_phases==2)
        entry={'scene':context.sessions[int(scene)],'POST_q0':int(rows.sum()),
            '必要条件全既知_片側以上':int((rows&(known_all[0]|known_all[1])).sum()),
            'どちら側も必要条件に未知':int((rows&~known_all[0]&~known_all[1]).sum()),
            '規則成立q0':int(np.count_nonzero(decision['directions'][rows])),
            '両側競合q0':int((rows&decision['conflicts']).sum())}
        observed=adx[rows&adx_known]
        entry['15分ADX_min_median_max']=[float(np.min(observed)),float(np.median(observed)),float(np.max(observed))]
        scenes.append(entry)
    rows=context.event_phases==2
    for index,condition in enumerate(rule['conditions']):
        conditions.append({**condition,
            '既知q0_片側以上':int((rows&(knowns[0][index]|knowns[1][index])).sum()),
            '通過q0_片側以上':int((rows&(truths[0][index]|truths[1][index])).sum()),
            'この条件だけを外すと全条件通過するq0':int((rows&(
                np.delete(truths[0],index,axis=0).all(axis=0)|np.delete(truths[1],index,axis=0).all(axis=0))).sum())})
    return {'規則':rule['id'],'全条件数':len(rule['conditions']),'場別':scenes,'条件ごと':conditions,
        '注意':'q0の当時特徴だけの原因診断。条件を外した売買・損益・採否の検証ではない。'}


def main() -> None:
    """
    機能: 追加7のPOSTについてRG0034とNR0009の可用性funnelを保存する。
    引数: なし。
    返り値: None。既存入力・条件・Sourceは変更しない。
    """
    context=B.load_context(True);features=context.features
    specs=[(next(r for r in old_catalog() if r['id']=='RG0034'),
        PreparedEvaluator(features.buy_X,features.sell_X,features.columns,target_points=150)),
        (next(r for r in new_catalog() if r['id']=='NR0009'),
        NightEvaluator(features.buy_X,features.sell_X,features.columns,target_points=200,q0_meta=features.q0_meta))]
    results=[rule_diagnosis(context,r,e) for r,e in specs]
    output={'区分':'追加4NightのPOST','非金融の当時特徴診断':True,'rules':results}
    path=Path(__file__).resolve().parent/'必要指標と条件の診断.json'
    path.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(output,ensure_ascii=False))


if __name__=='__main__':
    main()
