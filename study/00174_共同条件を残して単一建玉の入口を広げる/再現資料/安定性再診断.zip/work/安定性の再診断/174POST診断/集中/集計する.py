"""174全期J002のPOST既存取得を、場別に集中と既知決済へ分解する。"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[4]
HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 正式174小正本のPOST16取得について、場集中・主補完・FANC・決済勝敗を集計する。
    引数: なし。
    返り値: None。作業領域へJSONとMarkdownを保存する。既存政策と金融を変更しない。
    """
    source=ROOT/'study/00174_共同条件を残して単一建玉の入口を広げる/再現資料/出生と比較正本.zip'
    member='work/174追加七場適用/全80の両中央値174.json.gz'
    with zipfile.ZipFile(source) as archive:
        data=json.loads(gzip.decompress(archive.read(member)))
    row=next(r for r in data['rows'] if r['id']=='全期_J002')
    metric=row['financial']['phases_diagnostic']['POST']
    records=[]
    for i,phase in enumerate(row['phases']):
        if phase!=2:
            continue
        records.append({key:row['ledger'][key][i] for key in ('net','known','label','scene')}|{'origin':row['origins'][i]})
    assert len(records)==16
    scenes={}
    for r in records:
        target=scenes.setdefault(r['scene'],{'取得':0,'主':0,'補完':0,'F':0,'A':0,'N':0,'C':0,
            '既知利益':0,'既知損失':0,'既知差引':0,'金融未知':0,'決済勝':0,'決済負':0})
        target['取得']+=1
        target['主' if r['origin']==0 else '補完']+=1
        target[{1:'F',-1:'A',0:'N',2:'C'}[r['label']]]+=1
        if not r['known']:
            assert r['net'] is None
            target['金融未知']+=1
        else:
            net=r['net'];target['既知差引']+=net
            target['既知利益']+=max(net,0);target['既知損失']+=max(-net,0)
            target['決済勝' if net>0 else '決済負']+=1
    reached=[s for s,g in scenes.items() if g['F']+g['A']]
    max_f=max(g['F'] for g in scenes.values())
    top_f=[s for s,g in scenes.items() if g['F']==max_f]
    profits=sorted(scenes.items(),key=lambda pair:pair[1]['既知利益'],reverse=True)
    result={'成功':True,'対象':'174:全期_J002のPOST既存16取得のみ','確認日':'2026-11-16',
        '正式入力':{'path':source.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'member':member},
        '取得数':len(records),'参加場数':len(scenes),'対象場数':40,
        '主補完':dict(Counter('主' if r['origin']==0 else '補完' for r in records)),
        'FANC':{name:sum(g[name] for g in scenes.values()) for name in ('F','A','N','C')},
        'Fを得た場数':sum(g['F']>0 for g in scenes.values()),'到達場数':len(reached),
        '最多一場F数':max_f,'最多一場F比':max_f/10,'最多一場Fの場':top_f,
        '既知決済数':sum(r['known'] for r in records),'既知決済勝':sum(r['known'] and r['net']>0 for r in records),
        '既知決済負':sum(r['known'] and r['net']<0 for r in records),'金融未知':sum(not r['known'] for r in records),
        '既知利益':sum(g['既知利益'] for g in scenes.values()),'既知損失':sum(g['既知損失'] for g in scenes.values()),
        '既知差引':sum(g['既知差引'] for g in scenes.values()),
        '利益上位場':[{'scene':s,**g} for s,g in profits],
        '最多一場利益比':profits[0][1]['既知利益']/metric['trades']['known_profit'],
        '上位3場利益比':sum(g['既知利益'] for _,g in profits[:3])/metric['trades']['known_profit'],
        '全40場の内訳':{k:metric['sessions'][k] for k in ('complete_positive_count','complete_negative_count','complete_zero_count','unknown_count','zero_acquisition_count')},
        '場別':dict(sorted(scenes.items())),
        '追加7POST':row['追加7']['phases_diagnostic']['POST']['trades']['all_count'],
        '注意':'取得済みPOSTの診断であり、POST単独又は組替政策の成績ではない。未知を0円返済に置換しない。'}
    assert result['FANC']=={'F':10,'A':0,'N':4,'C':2}
    assert result['既知決済勝']==12 and result['既知決済負']==2
    assert result['既知利益']==290076 and result['既知損失']==19154 and result['既知差引']==270922
    (HERE/'集中と決済の独立集計.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':
    main()
