"""172正式文書を独立数値・条件・localリンクへ照合し、対象文書を変更せず検査票を作る。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import math
import re
import urllib.parse
import zipfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00172_デイを固定しナイト米国前後の複合入口を探索する'


def reference(path: Path) -> dict:
    """
    機能: 文書・Source・参照値の物理指紋を求める。
    引数: path(Path)は存在する入力。
    返り値: dictは相対パス、bytes、SHA256。
    """
    body = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(body),
            'sha256': hashlib.sha256(body).hexdigest()}


def main() -> None:
    """
    機能: 修正後文書の主要数値・条件・保存先・リンクを確認して小JSONを保存する。
    引数: なし。正式Markdownはread-only、出力はworkの検査票だけ。
    返り値: None。
    """
    global_paths = [ROOT / 'docs/README.md', ROOT / 'study/README.md', ROOT / 'AGENTS.md']
    paths = [TRIAL / name for name in ('README.md', '探索の経過.md', '設定と結果.md',
             '条件と市場心理.md', '外部調査と候補.md', '閲覧資料.md', '再現手順.md')]
    paths += global_paths + [ROOT / 'docs/議論/デイを固定しナイト米国前後の入口を探す.md']
    before = [reference(p) for p in paths]
    broken, links = [], 0
    for path in paths:
        for line_number, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
            if path in global_paths and '172' not in line and 'ナイト米国前後' not in line:
                continue
            for raw in re.findall(r'(?<!!)\[[^\]]+\]\(([^)]+)\)', line):
                target = raw.strip('<>')
                if urllib.parse.urlparse(target).scheme or target.startswith('#'):
                    continue
                target = urllib.parse.unquote(target.split('#')[0])
                links += 1
                if not (path.parent / target).exists():
                    broken.append({'path': path.relative_to(ROOT).as_posix(), 'line': line_number, 'target': raw})
    assert not broken, broken
    numeric_path = HERE / '全80の保有と到達支持.json'
    numeric = json.loads(numeric_path.read_text(encoding='utf-8'))
    cells = 0
    body = (TRIAL / 'README.md').read_text(encoding='utf-8')
    for line in body.splitlines():
        parts = [x.strip() for x in line.split('|')[1:-1]]
        if len(parts) == 10 and parts[0] in ('BASE171', 'B05_01', 'B05_11') and parts[1] in ('PRE', 'POST', 'NIGHT'):
            policy, band = parts[:2]
            value = numeric['全80加法'][policy][band]['全部']['q0金融と到達支持']
            assert int(parts[2]) == value['count']
            assert list(map(int, parts[3].split('/'))) == [value[k] for k in ('F', 'A', 'N', 'C')]
            assert math.isclose(float(parts[4][:-1]), round(100*value['rate'], 2), abs_tol=1e-9)
            for column, key in zip((5, 6, 7), ('profit', 'loss', 'net')):
                assert int(parts[column].replace(',', '')) == value[key]
            assert parts[8] == str(value['scenes'])+'/40'
            assert float(parts[9]) == round(value['per_hour'], 3)
            cells += 13
        if len(parts) == 6 and parts[0] in ('BASE171', 'B05_01', 'B05_11'):
            policy = parts[0]
            value = numeric['全80加法'][policy]['NIGHT']['全部']['q0金融と到達支持']
            core = numeric['全80加法'][policy]['NIGHT']['主']['q0金融と到達支持']
            hold = numeric['全80加法'][policy]['NIGHT']['全部']['実時間保有']
            assert parts[1] == str(core['scenes'])+'/40'
            assert parts[2] == str(value['scenes'])+'/40'
            assert parts[3] == str(value['core_count'])+'/'+str(value['technical_count'])
            assert float(parts[4]) == round(value['per_hour'], 3)
            pair = [float(x) for x in re.findall(r'[0-9.]+', parts[5])]
            assert pair == [round(hold['既知保有参加率_pct'], 2), round(hold['未知場末上限参加率_pct'], 2)]
            cells += 6
    assert cells == 135
    settings = (TRIAL / '設定と結果.md').read_text(encoding='utf-8')
    cp = next(line for line in settings.splitlines() if line.startswith('|N172-CP|'))
    for term in ('BB幅/ATR15<=4', 'BB位置0..1.5σ', '15/30分EMA/DI方向4票中>=3',
                 '実体>=.6', 'HistΔ/RSIΔ>0', '量>=1.25', 'spread<=10', 'gap<=1ATR'):
        assert term in cp
    assert 'TR5/前ATR' not in cp and 'ADXΔ15' not in cp
    new = next(line for line in settings.splitlines() if line.startswith('|N172-NEW8|'))
    assert '5/10/20実分' in new and '15/30/60実分' in new
    assert '出生と比較正本.zip内work/172ナイト複合候補/候補辞書.json' in new
    with zipfile.ZipFile(TRIAL / '再現資料/出生と比較正本.zip') as archive:
        assert 'work/172ナイト複合候補/候補辞書.json' in archive.namelist()
    psychological = (TRIAL / '条件と市場心理.md').read_text(encoding='utf-8')
    external = (TRIAL / '外部調査と候補.md').read_text(encoding='utf-8')
    assert all(word not in psychological for word in ('この草稿', '差し込む', '最終文書では'))
    assert '正式な実行条件・結果・採否は次の試行で固定する' not in external
    proofs = []
    for name in ('正式入力の固定再現.json', '隔離復元の固定再現.json'):
        path = TRIAL / '検査' / name
        value = json.loads(path.read_text(encoding='utf-8'))
        assert value['成功']
        proofs.append(reference(path))
    assert before == [reference(p) for p in paths]
    report = {'成功': True, '確認UTC': datetime.now(timezone.utc).isoformat(),
        '対象文書編集なし': True, 'Source': reference(Path(__file__)), '対象文書': before,
        '数値参照': reference(numeric_path), 'README独立数値照合セル': cells,
        'localリンク確認数': links, 'localリンク切れ': broken,
        '条件確認': ['CP0031全条件の短縮記述が辞書と整合', 'NEW8の実時間窓と候補辞書ZIP所在が整合',
                    '条件心理の草稿指示と外部調査の未来時制を修正済み'],
        '手動読合せ済み': ['主B05_01と後選B05_11を交換しない役割', 'Day171固定と主/補完の区別',
            'F/A/N/Cと決済勝率の分母の区別', '保有union下限/上限と頻度',
            '旧前48POSTの赤字と追加7未見主張なし', 'POST到達4Night/17Nightと単場27/34件の集中',
            '元方向反転と後続回復失敗確認の不存在', 'BB幅/ATRとスクイーズ履歴の不存在',
            '一般論・心理仮説・実証結果の区別'], '固定再現の成功票': proofs,
        '範囲': '外部URLの再閲覧は行わず、既存一次調査の位置付けとlocal文書間整合を確認した。'}
    out = HERE / '最終文書レビュー.json'
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False)+'\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'SourceSHA256': report['Source']['sha256'], '対象文書数': len(paths),
        '数値セル': cells, 'localリンク': links, '保存': out.relative_to(ROOT).as_posix()}, ensure_ascii=False))


if __name__ == '__main__':
    main()
