"""停止保存の名前接続だけを市場前の手製metadata検査後に固定する。"""

import ast
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

import 接続する as B


def main() -> None:
    """機能: 手製metadata人工と元code前後不変を確認して接続を停止する。

    引数: なし。市場Native・CSV・原板は開かない。
    返り値: None。既存停止を上書きしない。
    """
    require = B.require
    target = B.HERE / '停止.json'
    require(not target.exists(), '接続停止は新規のみ')
    before = {str(B.HERE / name): B.digest(B.HERE / name) for name in B.OWNED}
    _, original_before = B.old_dependencies()
    _, patch = B.patched_gate()
    for name in B.OWNED:
        if name.endswith('.py'):
            tree = ast.parse((B.HERE / name).read_text(encoding='utf-8'))
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    text = ast.get_docstring(node) or ''
                    require('\n' in text and all(k in text for k in ('機能', '引数', '返り値')), '関数コメント不足:' + node.name)
    result = subprocess.run([sys.executable, '-X', 'utf8', str(B.HERE / '人工検査.py')],
                            cwd=B.HERE, capture_output=True, text=True, encoding='utf-8', timeout=60)
    evidence_dir = B.HERE / '検査'
    evidence_dir.mkdir(exist_ok=False)
    (evidence_dir / '人工検査.txt').write_text(result.stdout + result.stderr, encoding='utf-8', newline='\n')
    require(result.returncode == 0, '人工検査失敗: ' + result.stdout + result.stderr)
    after = {name: B.digest(Path(name)) for name in before}
    require(before == after, '接続所有code前後差')
    require(original_before == {name: B.digest(Path(name)) for name in original_before}, '元停止code前後差')
    evidence = {'成功': True, '試行': 111, '市場前': True, '主人工': 3,
                '所有ファイルSHA256前': before, '所有ファイルSHA256後': after,
                '元停止全参照SHA256': original_before, 'AST変更': patch,
                '前後不変': True, '実市場Native読取': 0, 'Native金融解析': 0,
                '手製metadataの認証のみ': True, 'Raw/CSV本文読取': 0, '11月09日本文読取': 0}
    with (evidence_dir / '人工確認.json').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n')
    stopped = {'試行': 111, '成功': True, '市場前': True, '接続種別': B.KIND,
               '作成UTC': datetime.now(timezone.utc).isoformat(), '元保存停止': B.SAVE_STOP, '純保護停止': B.PURE_STOP,
               '所有ファイルSHA256': before, '再用ファイルSHA256': original_before, 'AST変更': patch,
               '人工確認': {'path': str(evidence_dir / '人工確認.json'), 'sha256': B.digest(evidence_dir / '人工確認.json')},
               '前後不変': True, '実市場Native読取': 0, 'Native金融解析': 0,
               'Raw/CSV本文読取': 0, '金融本体変更': False, '採用': False, '研究目標達成': False}
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(stopped, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'成功': True, '停止': {'path': str(target), 'sha256': B.digest(target)}, '主人工': 3}, ensure_ascii=True))


if __name__ == '__main__':
    main()
