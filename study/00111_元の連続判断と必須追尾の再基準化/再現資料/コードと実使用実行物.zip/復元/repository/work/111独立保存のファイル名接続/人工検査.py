"""入力本文を持たない手製metadataで名前接続の認証範囲を検査する。"""

from copy import deepcopy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

import 接続する as B


def write(path: Path, value: dict) -> dict:
    """機能: 手製metadataを新規保存して期待指紋を作る。

    引数: path(Path)、value(dict)は新規先と人工値。
    返り値: dictは絶対FileRef。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    return {'path': str(path.resolve()), 'sha256': B.digest(path)}


def fixture(base: Path, suffix: str) -> tuple[dict, dict]:
    """機能: 金融本文を含まないfirst2のRoot要求と自己停止を作る。

    引数: base(Path)、suffix(str)は隔離先と場名接尾辞。
    返り値: tuple[dict,dict]はRoot要求Refと要求内容。
    """
    base.mkdir()
    _, patch = B.patched_gate()
    stop = write(base / '手製接続停止.json', {'試行': 111, '成功': True, '市場前': True, '接続種別': B.KIND,
                 '元保存停止': B.SAVE_STOP, '純保護停止': B.PURE_STOP, 'AST変更': patch,
                 '所有ファイルSHA256': {str(B.HERE / name): B.digest(B.HERE / name) for name in B.OWNED}})
    code = write(base / '手製code.json', {'手製code': True})
    condition = write(base / '手製条件.json', {'trial': 111, 'fixed': True, 'code_sha256': {code['path']: code['sha256']}})
    results, scenes = [], []
    for kind in ('Day', 'Night'):
        sid = '2026-09-21_' + kind
        native = write(base / (sid + suffix), {'手製metadataのみ': True, '市場Native': False, 'session': sid})
        results.append({'session': sid, 'native': native, 'books': 24, 'S0_comparisons': 4,
                        'S0_equal': True, 'complete': True, 'open_quantity': 0, 'pending_quantity': 0})
        scenes.append({'session': sid, 'native': native, 'history_class': 'original54', 'market_path': '未作成価格.csv'})
    completion = write(base / '手製金融成功metadata.json', {'trial': 111, 'success': True, 'stage': 'first2', 'sessions': 2,
                       'books': 48, 'condition_sha256': condition['sha256'], 'unchanged': True,
                       'before': {code['path']: code['sha256']}, 'after': {code['path']: code['sha256']},
                       'all_original166_reference_events_equal': True, 'historical_saved_events_equal': False,
                       'all_original_signal_full_json_equal': False, 'results': results})
    request = {'version': 1, 'trial': 111, 'fixed': True, 'market_native_read_authorized': True, 'stage': 'first2',
               'completion': completion, 'condition': condition, 'code_stop': B.SAVE_STOP,
               'io_adapter_stop': stop, 'scenes': scenes}
    return write(base / '手製要求.json', request), request


class AdapterTests(unittest.TestCase):
    """金融を呼ばずに固定名・前後証拠・修正範囲を検査する。"""

    def test_exact_ast_and_file_identity(self) -> None:
        """機能: 定数1箇所以外のAST同体と元__file__維持を検査する。

        引数: self(AdapterTests)は試験器。
        返り値: None。
        """
        module, proof = B.patched_gate()
        self.assertEqual(proof['定数変更数'], 1)
        self.assertTrue(proof['定数を戻したAST同体'])
        self.assertFalse(proof['金融本体変更'])
        self.assertEqual(module.__file__, str(B.ORIGINAL / '入力ゲート.py'))

    def test_original_and_connected_basenames(self) -> None:
        """機能: 元gateと接続gateの新旧suffix受理を手製metadataで比較する。

        引数: self(AdapterTests)は試験器。
        返り値: None。Native金融の復元は呼ばない。
        """
        spec = importlib.util.spec_from_file_location('元の名前限定gate', B.ORIGINAL / '入力ゲート.py')
        original = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(original)
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            for suffix, accepted in (('.Native.json.gz', True), ('.json.gz', False), ('.Native.json', False)):
                ref, _ = fixture(root / ('人工' + suffix), suffix)
                target = Path(ref['path'])
                output = target.parent / '未作成出力'
                if accepted:
                    tasks, before, proofs = B.prepare(target, ref['sha256'], output)
                    self.assertEqual(len(tasks), 2)
                    self.assertFalse(output.exists())
                    self.assertIn(str(B.HERE / '接続する.py'), before)
                    self.assertIn(proofs['I/O接続停止SHA256'], before.values())
                    self.assertFalse(proofs['金融本体変更'])
                    self.assertEqual(before, {name: B.digest(Path(name)) for name in before})
                else:
                    with self.assertRaises(ValueError):
                        B.prepare(target, ref['sha256'], output)
                if suffix == '.json.gz':
                    self.assertEqual(len(original.prepare(target, ref['sha256'], output)[0]), 2)
                else:
                    with self.assertRaises(ValueError):
                        original.prepare(target, ref['sha256'], output)

    def test_fixed_and_existing_target_rejected(self) -> None:
        """機能: 自己停止欠落・期待SHA・元停止差・既存先を本文解析前に拒否する。

        引数: self(AdapterTests)は試験器。
        返り値: None。
        """
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder) / '人工'
            ref, request = fixture(base, '.Native.json.gz')
            output = base / '未作成出力'
            with self.assertRaises(ValueError):
                B.prepare(Path(ref['path']), '0' * 64, output)
            for name in ('自己停止欠落', '元保存停止差', '接続停止SHA差', '接続所有SHA差', 'AST範囲差'):
                bad = deepcopy(request)
                if name == '自己停止欠落':
                    del bad['io_adapter_stop']
                elif name == '元保存停止差':
                    bad['code_stop']['sha256'] = '0' * 64
                elif name == '接続停止SHA差':
                    bad['io_adapter_stop']['sha256'] = '0' * 64
                else:
                    stopped = json.loads(Path(bad['io_adapter_stop']['path']).read_text(encoding='utf-8'))
                    if name == '接続所有SHA差':
                        stopped['所有ファイルSHA256'][str(B.HERE / '接続する.py')] = '0' * 64
                    else:
                        stopped['AST変更']['定数変更数'] = 2
                    bad['io_adapter_stop'] = write(base / (name + '停止.json'), stopped)
                badref = write(base / (name + '.json'), bad)
                with self.subTest(name=name), self.assertRaises(ValueError):
                    B.prepare(Path(badref['path']), badref['sha256'], output)
            output.mkdir()
            with self.assertRaises(ValueError):
                B.prepare(Path(ref['path']), ref['sha256'], output)


if __name__ == '__main__':
    unittest.main(verbosity=2)
