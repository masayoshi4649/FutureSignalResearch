# 停止保存器のファイル名接続

停止Coreは場ID.Native.json.gzを出すが、停止保存299e3c…の入力ゲートは場ID.json.gzだけを許可する。この接続は元入力ゲート41eee8…をSHA認証してAST定数1箇所の「.json.gz」だけを「.Native.json.gz」へ変える。元のファイル位置を__file__へ維持する。金融本体、全24×場数、費用、Native認証、元Source対照、所有、保存形式、時刻順は変えない。

元保存・P監査・全所有/再用codeと、この接続4ファイル・接続停止を市場Nativeより前に認証する。元prepareの前指紋へ接続の指紋を足すため、元runの結果と保存会計確認の前後不変証拠にも残る。code_stopは元保存299のまま、Root保存要求へio_adapter_stopの絶対path/sha256だけを追加する。既存停止・Core・集計は書き換えない。

    python -X utf8 接続する.py --fixed <io_adapter_stopを追加したRoot要求> --sha256 <要求SHA> --output <未使用先>

人工は手製metadataだけで、元suffixの拒否/新suffixの受理、別名拒否、自己停止欠落・SHA差・元停止差、既存先拒否、AST差1箇所と__file__維持、元code・接続codeの前後不変を確認する。成功した市場Nativeは読まない。実金融の再検算はRootが要求を固定してこのCLIを実行するときに元保存器が行う。11月09日の本文・原板・CSVを読まない。
