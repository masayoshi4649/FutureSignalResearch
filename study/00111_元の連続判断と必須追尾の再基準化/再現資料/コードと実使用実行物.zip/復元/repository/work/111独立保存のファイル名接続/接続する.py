"""停止保存器の金融を変えず、CoreのNativeファイル名だけを接続する。"""

import argparse
import ast
import hashlib
import importlib
import json
from pathlib import Path
import sys
from types import ModuleType

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ORIGINAL = ROOT / 'work/111連続保護の独立保存'
SAVE_STOP = {'path': str(ORIGINAL / '検査_停止版/停止.json'),
             'sha256': '299e3c146b9d386d8faf7fcd58fcf795c7e692f57c81eb54fc56a439fc251348'}
PURE_STOP = {'path': str(ORIGINAL / 'P停止.json'),
             'sha256': 'c39c6da7577a7cbbb371b048f2da5b0ac3f4e296d95500f895b91bd1c42dd297'}
GATE_SHA = '41eee8d91fb56de5aa4544447b2acc55ff942285ccc8653df434d800a3c0708e'
OWNED = ('接続する.py', '人工検査.py', '検査して停止する.py', 'README.md')
KIND = '111停止保存器のNativeファイル名だけの接続'


def digest(path: Path) -> str:
    """機能: 明示metadata・コード・参照の全バイト指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(value: bool, label: str) -> None:
    """機能: 不完全な固定や修正範囲を成功へ補わず拒否する。

    引数: value(bool)、label(str)は条件と検査名。
    返り値: None。不成立はValueError。
    """
    if not value:
        raise ValueError(label)


def reference(ref: dict, before: dict) -> Path:
    """機能: 絶対FileRefを認証し前後不変台帳へ追加する。

    引数: ref(dict)、before(dict)は期待参照と認証台帳。
    返り値: Pathは認証済み位置。
    """
    require(set(ref) == {'path', 'sha256'}, 'FileRef集合')
    path = Path(ref['path'])
    require(path.is_absolute() and len(ref['sha256']) == 64, '絶対FileRefとSHA')
    path = path.resolve()
    require(digest(path) == ref['sha256'], '現物SHA差: ' + str(path))
    require(str(path) not in before or before[str(path)] == ref['sha256'], '同位置のSHA衝突')
    before[str(path)] = ref['sha256']
    return path


def read_ref(ref: dict, before: dict) -> dict:
    """機能: 認証後の小JSONだけを復元する。

    引数: ref(dict)、before(dict)は期待参照と認証台帳。
    返り値: dictは小metadata。Native金融の復元は行わない。
    """
    return json.loads(reference(ref, before).read_text(encoding='utf-8-sig'))


def old_dependencies() -> tuple[dict, dict]:
    """機能: 元保存299・P停止c39とその全所有/再用codeを認証する。

    引数: なし。
    返り値: tuple[dict,dict]は元停止metadataと前指紋。市場Nativeを探索しない。
    """
    before = {}
    stop = read_ref(SAVE_STOP, before)
    require(stop['試行'] == 111 and stop['成功'] is True and stop['市場前'] is True, '元保存の市場前停止')
    require(stop['純保護監査停止'] == PURE_STOP, '元保存とP停止の接続差')
    pure = read_ref(PURE_STOP, before)
    require(pure['成功'] is True and pure['市場前'] is True, 'P監査の市場前停止')
    for mapping in (stop['所有ファイルSHA256'], stop['再用ファイルSHA256'],
                    pure['所有ファイルSHA256'], pure['依存']):
        for path, sha in mapping.items():
            reference({'path': path, 'sha256': sha}, before)
    require(stop['所有ファイルSHA256'][str(ORIGINAL / '入力ゲート.py')] == GATE_SHA, '元gateの固定差')
    return stop, before


def patched_gate() -> tuple[ModuleType, dict]:
    """機能: 元gateのAST定数1箇所だけを変え同じ__file__で実行する。

    引数: なし。
    返り値: tuple[ModuleType,dict]は名前接続済みmoduleとAST同体の証拠。
    """
    original_path = ORIGINAL / '入力ゲート.py'
    require(digest(original_path) == GATE_SHA, '元gateのSHA差')
    raw = original_path.read_text(encoding='utf-8')
    tree = ast.parse(raw, filename=str(original_path))
    before = ast.dump(tree, include_attributes=False)
    matches = [node for node in ast.walk(tree) if isinstance(node, ast.Constant) and node.value == '.json.gz']
    require(len(matches) == 1, '修正対象定数は厳密に1箇所')
    target = matches[0]
    target.value = '.Native.json.gz'
    after = ast.dump(tree, include_attributes=False)
    target.value = '.json.gz'
    require(ast.dump(tree, include_attributes=False) == before, '定数以外のAST差')
    target.value = '.Native.json.gz'
    require(before != after, 'AST修正が未適用')
    if str(ORIGINAL) not in sys.path:
        sys.path.insert(0, str(ORIGINAL))
    module = ModuleType('入力ゲート')
    module.__file__ = str(original_path)
    exec(compile(tree, str(original_path), 'exec'), module.__dict__)
    proof = {'元gateSHA256': GATE_SHA, '定数変更数': 1, '変更前': '.json.gz', '変更後': '.Native.json.gz',
             '元AST_SHA256': hashlib.sha256(before.encode()).hexdigest(),
             '接続AST_SHA256': hashlib.sha256(after.encode()).hexdigest(),
             '定数を戻したAST同体': True, '__file__維持': module.__file__ == str(original_path),
             '金融本体変更': False}
    return module, proof


def bootstrap(fixed_path: Path, fixed_sha: str, output: Path) -> tuple[dict, dict]:
    """機能: 自己停止と元停止の全codeを市場Nativeより前に認証する。

    引数: fixed_path/output(Path)、fixed_sha(str)はRoot要求・未使用先・SHA。
    返り値: tuple[dict,dict]は前指紋と接続の証拠。
    """
    require(not output.exists(), '保存先は未作成')
    _, before = old_dependencies()
    request = read_ref({'path': str(fixed_path), 'sha256': fixed_sha}, before)
    require(request.get('code_stop') == SAVE_STOP, '元保存299をcode_stopへ維持')
    stop_ref = request.get('io_adapter_stop')
    require(isinstance(stop_ref, dict), 'io_adapter_stopが必要')
    stopped = read_ref(stop_ref, before)
    require(stopped.get('試行') == 111 and stopped.get('成功') is True and stopped.get('市場前') is True
            and stopped.get('接続種別') == KIND, '接続の市場前停止が必要')
    require(stopped.get('元保存停止') == SAVE_STOP and stopped.get('純保護停止') == PURE_STOP, '接続停止の元参照差')
    codes = stopped['所有ファイルSHA256']
    require(set(codes) == {str(HERE / name) for name in OWNED}, '接続所有4ファイル集合')
    for path, sha in codes.items():
        reference({'path': path, 'sha256': sha}, before)
    _, patch = patched_gate()
    require(stopped['AST変更'] == patch, '停止時AST修正と現物差')
    return before, {'I/O接続停止SHA256': stop_ref['sha256'], 'I/O接続の元保存停止SHA256': SAVE_STOP['sha256'],
                    'I/O接続修正': patch, '金融本体変更': False}


def prepare(fixed_path: Path, fixed_sha: str, output: Path) -> tuple:
    """機能: 名前だけ修正した元prepareを呼び自己codeを前後証拠へ結合する。

    引数: fixed_path/output(Path)、fixed_sha(str)はRoot要求・新規先・SHA。
    返り値: tupleは元tasks・結合前指紋・証拠。Native金融本文の解析はしない。
    """
    adapter_before, evidence = bootstrap(fixed_path, fixed_sha, output)
    module, _ = patched_gate()
    tasks, before, proofs = module.prepare(fixed_path, fixed_sha, output)
    for name, sha in adapter_before.items():
        require(name not in before or before[name] == sha, '元gateと接続の前指紋差')
        before[name] = sha
    proofs.update(evidence)
    return tasks, before, proofs


def run(fixed_path: Path, fixed_sha: str, output: Path) -> dict:
    """機能: 名前接続だけをimport境界に置き、元集計runを無変更で呼ぶ。

    引数: fixed_path/output(Path)、fixed_sha(str)はRoot固定要求と未使用先。
    返り値: dictは元金融・保存の成功件数。エラーは完成扱いしない。
    """
    bootstrap(fixed_path, fixed_sha, output)
    if str(ORIGINAL) not in sys.path:
        sys.path.insert(0, str(ORIGINAL))
    module, _ = patched_gate()
    module.prepare = prepare
    sys.modules['入力ゲート'] = module
    saved = importlib.import_module('集計')
    require(Path(saved.__file__).resolve() == ORIGINAL / '集計.py', '元集計module位置差')
    return saved.run(fixed_path, fixed_sha, output)


def main() -> None:
    """機能: 元保存と同じCLIでRootの明示要求だけを実行する。

    引数: CLI fixed/sha256/output(str)は要求・SHA・新規先。
    返り値: None。成功件数を標準出力へ返す。
    """
    parser = argparse.ArgumentParser(description=KIND)
    parser.add_argument('--fixed', required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    print(json.dumps(run(Path(args.fixed).resolve(), args.sha256, Path(args.output).resolve()), ensure_ascii=False))


if __name__ == '__main__':
    main()
