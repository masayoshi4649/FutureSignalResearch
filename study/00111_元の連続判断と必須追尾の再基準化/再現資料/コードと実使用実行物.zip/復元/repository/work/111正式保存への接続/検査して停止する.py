"""正式保存器の手製schema検査だけを実行して所有4ファイルを固定する。"""

import argparse
from pathlib import Path
import subprocess
import sys

import 正式保存する as F


def stop(output: Path) -> dict:
    """機能: 実市場を開かず人工成功と所有・再用codeの前後不変を固定する。

    引数: output(Path)は未作成の証拠先。
    返り値: dictは停止Ref。市場Native・Raw・価格CSVを読まない。
    """
    F.need(not output.exists(), '証拠先は未作成')
    owned = {str(F.OWN / name): F.sha(F.OWN / name) for name in ('正式保存する.py', '人工検査.py', '検査して停止する.py', 'README.md')}
    reused = {str(F.LEGACY_PATH): F.LEGACY_SHA, str(F.ZIP_PATH): F.ZIP_SHA,
              str(F.ROOT / 'work/109再現コードの準備/ZIPを正式保存する.py'): 'cb263d54b70bbb6ca94d227736fce98748a623d014924b960660039d8f98eae2'}
    for path, expected in reused.items():
        F.need(F.sha(Path(path)) == expected, '再用原本SHA')
    output.mkdir(parents=True, exist_ok=False)
    test = subprocess.run([sys.executable, '-X', 'utf8', str(F.OWN / '人工検査.py')],
                          capture_output=True, text=True, encoding='utf-8', cwd=F.OWN, timeout=60)
    log = output / '人工検査.txt'
    log.write_text(test.stdout + test.stderr, encoding='utf-8', newline='\n')
    F.need(test.returncode == 0, '全人工成功')
    F.need(all(F.sha(Path(path)) == expected for path, expected in {**owned, **reused}.items()), '全所有/再用code前後不変')
    evidence = {'試行': 111, '成功': True, '市場前': True, '主人工': 4, '器具': '全70×24手製schema・空約定・仮Native・仮oracle・仮GoRoot',
                '全70正本の同bytes経路': True, 'Viewer1680資源': True, 'oracle54保存経路': True,
                'GoRoot非同梱': True, '非GoRoot同path重複排除': True, '全entrySHA/CRC/安全名/集合': True,
                '破壊/欠落/失敗/遡り/既存先拒否': True, '前後不変': True, 'ログ': F.ref(log),
                '実市場Native読取': 0, '実Raw/価格CSV本文読取': 0, '金融再実行': False, 'CSV生成': False, '11月09日本文読取': False}
    evidence_path = output / '人工確認.json'
    F.write_json(evidence_path, evidence)
    record = {'試行': 111, '成功': True, '市場前': True, '所有ファイルSHA256': owned, '再用ファイルSHA256': reused,
              '人工確認': F.ref(evidence_path), '前後不変': True, '実市場Native読取': 0,
              '実Raw/価格CSV本文読取': 0, '11月09日本文読取': False, '研究目標達成': False, '採用': False}
    path = output / '停止.json'
    F.write_json(path, record)
    return {'成功': True, '停止': F.ref(path)}


def main() -> None:
    """機能: 未作成先を必須として市場前検査固定を呼ぶ。

    引数: CLI output(str)は新規の証拠先。
    返り値: None。停止Refだけを表示する。
    """
    import json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(stop(args.output.resolve()), ensure_ascii=False))


if __name__ == '__main__':
    main()
