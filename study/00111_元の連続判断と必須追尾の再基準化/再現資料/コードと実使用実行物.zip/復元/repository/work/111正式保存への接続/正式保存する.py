"""111の全70正本を同bytes保存し、標準Goを除くコード閉包を既存ZIP器へ渡す。"""

import argparse
from collections import defaultdict
from datetime import date, timedelta
from decimal import Decimal
import importlib.util
import json
from pathlib import Path
import re
import shutil
from types import SimpleNamespace


ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00111_元の連続判断と必須追尾の再基準化'
LEGACY_PATH = ROOT / 'work/110正式保存の準備/正式保存する.py'
LEGACY_SHA = 'f64894c928aadcfdfe8337b4968099d365a9c04c7a24ee463606279c3801246d'
ZIP_PATH = ROOT / 'work/110再現保存の最終準備/ZIPの共通部.py'
ZIP_SHA = '6fdc6ed6ba8d15fffe71bfecfcb516308cdfc14496a42ef70c0575a05b457f92'
POLICIES = ('S0', 'U100', 'W100', 'T100', 'B100', 'B50')
CONFIGS = tuple({'policy': p, 'slip_pts': c, 'delay_seconds': d} for p in POLICIES for c in (0, 5) for d in (0, 1))
KEYS = tuple(f"{c['policy']}_C{c['slip_pts']}_D{c['delay_seconds']}" for c in CONFIGS)
REQUIRED_REFS = {'condition', 'market', 'result', 'saved_check', 'oracle54', 'core_stop', 'source_stop',
                 'actor_stop', 'chart_stop', 'pure_stop', 'save_stop', 'P_stop', 'io_stop',
                 'parallel_stop', 'same_entry_stop', 'formal_stop'}


def load_module(path: Path, expected: str, name: str):
    """機能: 固定済みの共通器だけを現物SHA認証して読み込む。

    引数: path(Path)、expected/name(str)は元コード・期待SHA・module識別子。
    返り値: moduleは原本を変更しない共通処理。市場本文を開かない。
    """
    import hashlib
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise ValueError('既存共通器のSHA差: ' + str(path))
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


OLD = load_module(LEGACY_PATH, LEGACY_SHA, '111が使う110同bytes共通部')
need, sha = OLD.need, OLD.sha
Z = load_module(ZIP_PATH, ZIP_SHA, '111が使う既存ZIP三関数').load_common(SimpleNamespace(need=need, sha=sha))


def ref(path: Path) -> dict:
    """機能: 成果物の絶対位置と全bytes指紋を返す。

    引数: path(Path)は明示対象。
    返り値: dictはpath/sha256のFileRef。
    """
    return {'path': str(path.resolve()), 'sha256': sha(path)}


def bind(value: dict, before: dict) -> Path:
    """機能: 明示FileRefを旧110の指紋検査へ渡し不変台帳へ記録する。

    引数: value(dict)、before(dict)は参照と前後指紋。
    返り値: Pathは認証済み位置。Rawや共有価格を探索しない。
    """
    need(set(value) in ({'path', 'sha256'}, {'path', 'sha256', 'bytes'}), '明示FileRefの型')
    path = OLD.reference({k: value[k] for k in ('path', 'sha256')})
    if 'bytes' in value:
        need(path.stat().st_size == value['bytes'], '参照容量差')
    need(str(path) not in before or before[str(path)] == value['sha256'], '同位置の異なるSHA')
    before[str(path)] = value['sha256']
    return path


def read(value: dict, before: dict) -> dict:
    """機能: 認証した明示JSONだけを十進数で復元する。

    引数: value(dict)、before(dict)は小metadata参照と不変台帳。
    返り値: dictはmetadata。Nativeや原板の復号を行わない。
    """
    path = bind(value, before)
    need(path.suffix == '.json' and '.Native.' not in path.name, 'metadata JSONだけを復元')
    return json.loads(path.read_text(encoding='utf-8-sig'), parse_float=Decimal,
                      parse_constant=lambda s: (_ for _ in ()).throw(ValueError('非有限JSON数値' + s)))


def write_json(path: Path, value: dict) -> None:
    """機能: 正本を上書きせず日本語UTF-8のJSONを保存する。

    引数: path(Path)、value(dict)は未使用先と保存値。
    返り値: None。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False,
                  default=lambda x: int(x) if isinstance(x, Decimal) and x == x.to_integral_value() else float(x))
        stream.write('\n')


def sessions() -> list[str]:
    """機能: 11/06までの既使用70場を固定順に列挙する。

    引数: なし。
    返り値: list[str]は元54場と追加16場の全予定。11/09を含めない。
    """
    current, result = date(2026, 9, 21), []
    while current <= date(2026, 11, 6):
        if current.weekday() < 5:
            result.extend(f'{current.isoformat()}_{kind}' for kind in ('Day', 'Night'))
        current += timedelta(days=1)
    need(len(result) == 70, '全予定70場')
    return result


def validate(values: dict, request: dict) -> list[str]:
    """機能: F3全70・独立1680・原文oracle54・停止参照を一つの成功鎖へ結ぶ。

    引数: values/request(dict)は認証済みmetadataとRoot固定要求。
    返り値: list[str]は全70場。金融を再走せず、Rawで初回約定を再証明しない。
    """
    condition, market, result, saved, oracle = (values[k] for k in ('condition', 'market', 'result', 'saved_check', 'oracle54'))
    refs = request['refs']
    expected = sessions()
    need(condition['version'] == 1 and condition['trial'] == 111 and condition['fixed'] is True, '固定111市場条件')
    need(condition['actual_configurations'] == list(CONFIGS), '本名24宣言')
    need(condition['entry_grid_seconds'] is None and condition['extra_opening_quiet_seconds'] == 0
         and condition['chart_seed_mode'] == 'cold_each_session', '元連続時計と当場cold')
    need(condition['parallel_stop'] == refs['parallel_stop'] and condition['runtime_stop'] == refs['core_stop'], 'F3の並列/Core停止接続')
    need(condition['derivation']['financial_specifications_equal'] is True, '並列は金融仕様同体')
    need(condition['dependency_stops'] == {k: refs[k + '_stop'] for k in ('source', 'actor', 'chart', 'pure')}, '四部品の停止同体')
    need(market['version'] == 1 and market['trial'] == 111 and market['success'] is True and market['stage'] == 'full70', '正式は全70成功だけ')
    need((market['sessions'], market['books'], market['reused_sessions'], market['replayed_sessions']) == (70, 1680, 54, 16), 'F3の認証再用54と追加再生16')
    need(market['unchanged'] is True and market['before'] and market['before'] == market['after'], '市場入力code前後不変')
    need(market['condition_sha256'] == refs['condition']['sha256'], '同じF3条件')
    need(market['all_original166_reference_events_equal'] is True and market['historical_saved_events_equal'] is False
         and market['all_original_signal_full_json_equal'] is False, 'oracle照合と未証明の歴史同体を区別')
    need([x['session'] for x in market['results']] == expected, '金融全70順序')
    need(all(x['books'] == 24 and x['S0_comparisons'] == 4 and x['S0_equal'] is True and x['complete'] is True
             and x['open_quantity'] == x['pending_quantity'] == 0 for x in market['results']), '全70の24冊/対照4/残予約0')
    need(result['試行'] == 111 and result['成功'] is True and result['stage'] == 'full70'
         and result['場数'] == 70 and result['会計数'] == 1680 and result['主key'] == list(KEYS), '独立全1680')
    need(result['前後不変'] is True and result['入力codeSHA256前'] and result['入力codeSHA256前'] == result['入力codeSHA256後'], '独立入力不変')
    need(saved['試行'] == 111 and saved['成功'] is True and saved['前後不変'] is True and saved['不一致数'] == 0
         and saved['場数'] == 70 and saved['会計数'] == saved['資源'] == 1680 and saved['S0全金融比較'] == 280
         and saved['全残玉予約0'] is True, '独立保存全件検算')
    need(result['金融条件SHA256'] == saved['金融条件SHA256'] == refs['condition']['sha256'], '独立と金融条件同体')
    need(result['金融完了SHA256'] == saved['金融完了SHA256'] == refs['market']['sha256'], '独立と金融成功接続')
    need(result['保存器停止SHA256'] == refs['save_stop']['sha256'] and result['純保護監査停止SHA256'] == refs['P_stop']['sha256']
         and result['I/O接続停止SHA256'] == refs['io_stop']['sha256'], '旧保存/P/名前接続の停止維持')
    need(saved['出力SHA256']['結果.json'] == refs['result']['sha256'], '結果と保存確認結合')
    need(len(result['場別']) == 1680 and set(result['集計']) == set(KEYS), '全条件集計')
    need(result['Viewer形式資源'] == 1680 and len(result['Viewer保存再読']) == 70
         and all(r['資源'] == 24 and r['全残0'] is True for r in result['Viewer保存再読']), 'Viewer保存の独立再読')
    need(result['採用'] is False and result['研究目標達成'] is False, '保存を採用や研究目標達成にしない')
    for key in KEYS:
        need([r['session'] for r in result['場別'] if r['key'] == key] == expected, '0取引込み全場.' + key)
    need(oracle['trial'] == 111 and oracle['success'] is True and oracle['stage'] == 'original54' and oracle['sessions'] == 54
         and oracle['published_gross_checked'] is True and oracle['published_gross_equal'] is True
         and oracle['unchanged'] is True and oracle['before'] and oracle['before'] == oracle['after'], '原文oracle54成功と公表粗額')
    need(oracle['holdout_11_09_read'] is False and oracle['raw_copied'] is False
         and oracle['historical_saved_event_equality'] is False and oracle['all_signal_full_json_equal'] is False, 'oracle範囲')
    need(condition['original166_references'] == oracle['results'] and set(oracle['results']) == set(expected[:54]), '原文oracle54の同じEvent参照')
    for name in REQUIRED_REFS - {'condition', 'market', 'result', 'saved_check', 'oracle54'}:
        need(values[name].get('成功') is True, '成功停止だけ.' + name)
    need(values['save_stop']['純保護監査停止'] == refs['P_stop'], '保存停止からPへの結合')
    need(values['io_stop']['元保存停止'] == refs['save_stop'] and values['io_stop']['純保護停止'] == refs['P_stop'], '名前接続の元停止')
    need(values['formal_stop']['市場前'] is True, '正式保存器の市場前停止')
    return expected


def code_rows(condition: dict, values: dict, request: dict, before: dict, copied_sources: dict) -> tuple[list[dict], list[dict]]:
    """機能: 非標準Go閉包と所有コードを元path単位で一度だけ索引化する。

    引数: condition/values/request/before/copied_sources(dict)は固定閉包・停止・要求・指紋・正式外部所在。
    返り値: tuple[list, list]は全索引とZIP同梱行。GoRootは認証と索引だけ。
    """
    environment = request['go_environment']
    need(environment['version'] == 'go1.24.2', '再現Goは1.24.2')
    need(Path(environment['root']).is_absolute(), '明示GoRootの絶対位置')
    goroot = Path(environment['root']).resolve()
    need(all(Path(path).is_absolute() for path in request['restore_roots'].values()), '復元根は絶対位置')
    roots = {name: Path(path).resolve() for name, path in request['restore_roots'].items()}
    need(roots.get('repository') == ROOT.resolve() and 'module_cache' in roots, '元repoとmodule cacheの復元根')
    need(len({str(p).casefold() for p in roots.values()}) == len(roots), '復元根の重複なし')
    candidates = {}

    def add(path_value: str, expected: str, role: str) -> None:
        """機能: 同じ元pathの指紋衝突を拒み役割だけを統合する。

        引数: path_value/expected/role(str)は元位置・期待SHA・用途。
        返り値: None。市場Nativeや価格CSVを同梱候補にしない。
        """
        path = Path(path_value)
        path = (path if path.is_absolute() else ROOT / path).resolve()
        need('.Native.' not in path.name and path.suffix.lower() not in ('.csv', '.gz', '.jsonl'), 'コードZIPへ金融/Raw/CSVを混入しない')
        ident = str(path).casefold()
        if ident not in candidates:
            candidates[ident] = {'path': path, 'sha256': expected, 'roles': set()}
        need(candidates[ident]['sha256'] == expected, '同pathコードのSHA衝突')
        candidates[ident]['roles'].add(role)

    for path, expected in condition['code_sha256'].items():
        add(path, expected, 'F3の実選択Go閉包')
    for name, stopped in values.items():
        if name.endswith('_stop'):
            for field in ('所有コードSHA256', '所有ファイルSHA256'):
                for path, expected in stopped.get(field, {}).items():
                    add(path, expected, name + 'の所有コード')
            # ----------------------------------------
            # 再用一覧からはコードだけを受け、人工金融の全件重複を避ける。
            for path, expected in stopped.get('再用ファイルSHA256', {}).items():
                if Path(path).suffix in ('.py', '.go', '.mjs', '.ps1'):
                    add(path, expected, name + 'のコード依存')
    for name in ('actual_declaration', 'pure_declaration', 'chart_declaration'):
        add(condition[name]['path'], condition[name]['sha256'], name)
    for name in ('executable', 'oracle_executable'):
        add(condition[name]['path'], condition[name]['sha256'], '実使用実行物.' + name)
    for item in request.get('code_refs', []):
        need(set(item) == {'ref', 'role'}, '明示追加コードの型')
        add(item['ref']['path'], item['ref']['sha256'], item['role'])
    for path, expected in ((LEGACY_PATH, LEGACY_SHA), (ZIP_PATH, ZIP_SHA),
                           (ROOT / 'work/109再現コードの準備/ZIPを正式保存する.py', 'cb263d54b70bbb6ca94d227736fce98748a623d014924b960660039d8f98eae2')):
        add(str(path), expected, '改変しない保存共通部')
    index, archived = [], []
    for candidate in sorted(candidates.values(), key=lambda r: str(r['path']).casefold()):
        path = bind({'path': str(candidate['path']), 'sha256': candidate['sha256']}, before)
        row = {'original_path': str(path), 'sha256': candidate['sha256'], 'bytes': path.stat().st_size,
               'roles': sorted(candidate['roles'])}
        if path.is_relative_to(goroot):
            row.update(kind='GoRoot環境参照', restore={'root': 'GoRoot', 'relative': path.relative_to(goroot).as_posix()},
                       location={'kind': '環境参照のみ', 'go_version': environment['version']})
        elif str(path) in copied_sources:
            row.update(kind='正式metadata参照', location={'kind': '正式同bytes成果物', 'relative': copied_sources[str(path)]})
        else:
            matches = [(name, base) for name, base in roots.items() if path.is_relative_to(base)]
            need(len(matches) == 1, '元コードの復元根は一つ: ' + str(path))
            name, base = matches[0]
            relative = path.relative_to(base).as_posix()
            entry = '復元/' + name + '/' + relative
            need(Z.safe(entry), '安全な復元entry')
            row.update(kind='実使用実行物' if path.suffix == '.exe' else 'コードと宣言',
                       restore={'root': name, 'relative': relative}, location={'kind': 'このZIP', 'entry': entry})
            archived.append(row)
        index.append(row)
    return index, archived


def prepare(request_ref: dict) -> dict:
    """機能: Root全Ref認証と全保存計画を、正式先への初回書込み前に完成する。

    引数: request_ref(dict)は全70成功後に固定されたRoot要求。
    返り値: dictはcopy/ZIP/索引計画と前指紋。Nativeは復号せずbytesだけを認証する。
    """
    before = {}
    request = read(request_ref, before)
    need(request['version'] == 1 and request['trial'] == 111 and request['fixed'] is True
         and request['stage'] == 'full70' and request['market_native_read_authorized'] is True, 'Rootの正式保存解禁')
    need(REQUIRED_REFS <= set(request['refs']) and all(re.fullmatch('[A-Za-z0-9_]+', n) for n in request['refs']), '必須参照と安全な名称')
    values = {name: read(value, before) for name, value in request['refs'].items()}
    expected = validate(values, request)
    formal_stop = values['formal_stop']
    need(set(formal_stop['所有ファイルSHA256']) == {str(OWN / n) for n in ('正式保存する.py', '人工検査.py', '検査して停止する.py', 'README.md')}, 'この正式保存器の停止だけを使用')
    for path, expected_sha in formal_stop['所有ファイルSHA256'].items():
        bind({'path': path, 'sha256': expected_sha}, before)
    plans, targets, copied_sources = [], set(), {}

    def add(value: dict, relative: str) -> None:
        """機能: 安全な試行内の未使用先へ同bytesコピーを予約する。

        引数: value(dict)、relative(str)は明示FileRefと試行内相対位置。
        返り値: None。全計画が確定するまで正式先を作らない。
        """
        source = bind(value, before)
        need(Z.safe(relative), '安全な正式相対位置')
        target = (TRIAL / relative).resolve()
        need(target.is_relative_to(TRIAL.resolve()) and not target.exists(), '新規の試行内保存だけ')
        ident = str(target).casefold()
        need(ident not in targets, '正式先の正規化重複')
        need(str(source) not in copied_sources, '同じ元pathの重複正式保存を避ける')
        targets.add(ident)
        copied_sources[str(source)] = relative
        plans.append({'source': str(source), 'target': str(target), 'relative': relative, 'sha256': value['sha256']})

    # ----------------------------------------
    # 独立保存が明示した集合だけをコピーし、隣の途中ファイルを列挙しない。
    result, saved, market, condition, oracle = (values[n] for n in ('result', 'saved_check', 'market', 'condition', 'oracle54'))
    saved_dir = Path(request['refs']['result']['path']).resolve().parent
    need(Path(request['refs']['saved_check']['path']).resolve().parent == saved_dir, '結果と保存検算の同じfolder')
    expected_files = {'結果.json', '一覧.resources.json'} | {f'111_{key}_{sid}.trades.jsonl' for sid in expected for key in KEYS}
    need(set(saved['出力SHA256']) == expected_files and len(expected_files) == 1682, '独立保存の全1682出力集合')
    for name in sorted(expected_files):
        add({'path': str(saved_dir / name), 'sha256': saved['出力SHA256'][name]}, '成果物/' + name)
    add(request['refs']['saved_check'], '成果物/保存会計の確認.json')
    catalog = read({'path': str(saved_dir / '一覧.resources.json'), 'sha256': saved['出力SHA256']['一覧.resources.json']}, before)
    need(catalog['schema_version'] == 1 and catalog['path_base'] == 'catalog' and len(catalog['resources']) == 1680, 'Viewer全1680')
    want_ids = {f'111_{key}_{sid}' for sid in expected for key in KEYS}
    need({r['id'] for r in catalog['resources']} == want_ids, '全Viewer IDと一意性')
    need({r['pnl_path'] for r in catalog['resources']} == expected_files - {'結果.json', '一覧.resources.json'}, '全約定ファイルとの対応')
    need(all(r['symbol'] == 'NK225' and r['product'] == 'NK225mini' and r['point_value'] == 100
             and r['pnl_basis'] == 'net' and r['pnl_format'] == 'trades' for r in catalog['resources']), 'Viewer商品と費用後基準')
    native_index = []
    need([r['session'] for r in result['Native参照']] == expected, '独立Native全70順序')
    for independent, current in zip(result['Native参照'], market['results']):
        value = {'path': independent['path'], 'sha256': independent['sha256']}
        need(value == current['native'], '独立と金融の同じNative')
        sid = independent['session']
        path = Path(value['path'])
        need(path.name == sid + '.Native.json.gz', '正式Nativeの本名')
        relative = '成果物_金融/Native/' + path.name
        add(value, relative)
        native_index.append({'session': sid, 'history_class': 'original54' if sid in expected[:54] else 'additional16',
                             'relative': relative, 'sha256': value['sha256'], 'bytes': path.stat().st_size,
                             'origin': value, '同bytes': True, '会計': 24})
    # ----------------------------------------
    # 原文oracleの元54 Eventは再現根拠として保存し、Raw/価格CSVをコピーしない。
    for sid in expected[:54]:
        add(oracle['results'][sid], '原文oracle54/' + sid + '.oracle.json')
    for name, value in request['refs'].items():
        if name not in ('result', 'saved_check'):
            add(value, '検査/' + name + '.json')
    add(condition['manifest'], '検査/共用入力台帳_70場.json')
    if 'prior54' in market:
        add(market['prior54'], '検査/元54の成功.json')
    for item in request.get('extra_refs', []):
        need(set(item) == {'ref', 'target', 'role'}, '後段extraの明示型')
        need(item['target'].split('/')[0] in ('診断', '検査', 'CSV', '再現資料'), '後段extraの保存範囲')
        source_name = Path(item['ref']['path'])
        need(source_name.suffix in ('.json', '.md', '.csv') and '.Native.' not in source_name.name, '後段は診断/成功metadata/CSVだけ')
        add(item['ref'], item['target'])
    add(request_ref, '検査/正式保存の要求.json')
    code_index, archived = code_rows(condition, values, request, before, copied_sources)
    generated = ['成果物_金融/Native参照台帳.json', '再現資料/コードと実使用実行物.zip', '再現資料/コード所在索引.json', '再現資料/再現手順.md', '検査/正式保存の確認.json']
    for relative in generated:
        need(str((TRIAL / relative).resolve()).casefold() not in targets and not (TRIAL / relative).exists(), '生成先は未使用')
    return {'request': request, 'before': before, 'plans': plans, 'native': native_index,
            'code_index': code_index, 'archived': archived, 'generated': generated}


def execute(request_ref: dict) -> dict:
    """機能: 全計画後に正本を同bytes保存し、既存ZIP器でSHA/CRC/集合を検査する。

    引数: request_ref(dict)はRootの正式固定要求。
    返り値: dictは正式保存Ref。途中失敗を成功へ転用しない。
    """
    plan = prepare(request_ref)
    copied = []
    for row in plan['plans']:
        source, target = Path(row['source']), Path(row['target'])
        need(sha(source) == row['sha256'] and not target.exists(), 'コピー直前の不変と未作成')
        target.parent.mkdir(parents=True, exist_ok=True)
        with source.open('rb') as src, target.open('xb') as dst:
            shutil.copyfileobj(src, dst)
        need(sha(source) == sha(target) == row['sha256'], '全bytes同体コピー')
        copied.append({'relative': row['relative'], 'origin': {'path': row['source'], 'sha256': row['sha256']},
                       'sha256': row['sha256'], 'bytes': target.stat().st_size, '同bytes': True})
    native_path = TRIAL / '成果物_金融/Native参照台帳.json'
    write_json(native_path, {'試行': 111, '成功': True, '場数': 70, '会計数': 1680, 'Native': plan['native'],
                             '方針': 'F3元54成果物Refを認証再用し追加16とともに一回ずつ同bytes保存。再生で再証明したとは呼ばない。'})
    reproduction = TRIAL / '再現資料'
    reproduction.mkdir(parents=True, exist_ok=True)
    zip_path = reproduction / 'コードと実使用実行物.zip'
    Z.write_zip(zip_path, plan['archived'])
    checks = Z.verify_zip(zip_path, plan['archived'])
    for row in plan['code_index']:
        if row['location']['kind'] == 'このZIP':
            row['location'].update(checks[row['location']['entry']])
    index_path = reproduction / 'コード所在索引.json'
    index = {'試行': 111, '成功': True, 'Root要求': request_ref, 'ZIP': ref(zip_path),
             'restore_roots': plan['request']['restore_roots'], 'go_environment': plan['request']['go_environment'],
             'entries': plan['code_index'], '同梱数': len(plan['archived']),
             'GoRoot索引数': sum(r['kind'] == 'GoRoot環境参照' for r in plan['code_index']),
             '実使用実行物数': sum(r['kind'] == '実使用実行物' for r in plan['code_index']),
             '標準Go本文同梱': False, '全entrySHA/CRC/安全名/集合': True, '研究目標達成': False, '採用': False}
    write_json(index_path, index)
    procedure_path = reproduction / '再現手順.md'
    lines = ['# 111の保存と再現', '',
             'F3全70の24条件を正本とする。元54は同条件の認証済みNativeを再用し、追加16だけを新規再生した。途中F2直列の19場は中断であり、正式成功として再用しない。', '',
             '原文oracle54のEvent対照、条件・停止・入力指紋は検査と原文oracle54へ保存した。先頭2の金融/Viewer全件は最終70と重複させず、明示された成功metadata・bytes一致証拠だけを残す。', '',
             'コード所在索引.jsonのoriginal_pathとrestore.root/relativeに従い、同SHAのコードを元位置へ復元する。GoRoot標準ライブラリは索引だけで、ZIPには同梱しない。Go 1.24.2と記録されたGoRoot全選択ファイルSHAが一致する環境を別途用意する。標準Goが無い環境でこのZIPだけから完全復元できるとは主張しない。', '',
             '共用原板・分足・価格CSVは入力台帳の元位置とSHAを用いる。この保存器はそれらの本文を再読・複製しない。入力・条件のpathを勝手に書き換えない。', '',
             '元の実行物で原文oracle54、F3先頭2対照、同F3元54、同F3全70の順に実行する。全70は元54の成功Refを要求する。独立保存は名前adapterから実行し、停止299とP停止c39を維持する。正式保存はRoot要求を固定してこの保存器の--requestと--request-shaへ渡す。', '',
             'CSVはRootの専用artifact-tool出力を明示Refで接続し、この保存器では生成しない。Viewer資料は全1680資源と実約定であり、HTTP取得・描画の検査は別証拠である。', '',
             'Native台帳の独立監査は最初の適格正常原行をRaw別走査で証明したものではない。純保護も保存点のexact/boundedを分ける。研究目標達成と採用はfalse。', '',
             'Root正式要求SHA256: ' + request_ref['sha256'], 'コードZIP SHA256: ' + sha(zip_path), '']
    with procedure_path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write('\n'.join(lines))
    need(all(sha(Path(row['source'])) == sha(Path(row['target'])) == row['sha256'] for row in plan['plans']), '全コピー入力出力の最終同bytes')
    after = {path: sha(Path(path)) for path in plan['before']}
    need(after == plan['before'], '全入力code/GoRoot/成果物の前後不変')
    proof_path = TRIAL / '検査/正式保存の確認.json'
    proof = {'試行': 111, '成功': True, 'Root要求': request_ref, '同bytes成果物': copied,
             'Native台帳': ref(native_path), 'Native数': 70, '会計数': 1680, 'Viewer資源': 1680,
             '原文oracle54': 54, 'ZIP': ref(zip_path), 'コード所在索引': ref(index_path), '再現手順': ref(procedure_path),
             '全entrySHA/CRC/安全名/集合': True, '同梱entry数': len(plan['archived']), 'GoRoot索引数': index['GoRoot索引数'],
             '入力SHA256前': plan['before'], '入力SHA256後': after, '前後不変': True,
             'Raw本文再読複製': False, '価格CSV本文再読複製': False, '金融再実行': False, 'CSV生成': False,
             'F2途中の成功再用': 0, '旧93/94/110改変': False, '11月09日本文読取': False, '研究目標達成': False, '採用': False}
    write_json(proof_path, proof)
    return {'成功': True, '正式保存の確認': ref(proof_path), 'Native台帳': ref(native_path),
            'ZIP': ref(zip_path), '索引': ref(index_path), '再現手順': ref(procedure_path),
            'コピー数': len(copied), 'ZIP同梱数': len(plan['archived']), 'GoRoot索引数': index['GoRoot索引数']}


def main() -> None:
    """機能: Rootが固定した全70要求と期待SHAだけから新規保存する。

    引数: CLI request/request-sha(str)は要求JSON絶対位置と期待指紋。
    返り値: None。正式Refと件数だけを標準出力へ出す。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', required=True, type=Path)
    parser.add_argument('--request-sha', required=True)
    args = parser.parse_args()
    print(json.dumps(execute({'path': str(args.request.resolve()), 'sha256': args.request_sha}), ensure_ascii=False))


if __name__ == '__main__':
    main()
