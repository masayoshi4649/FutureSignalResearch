# 111正式保存への接続（市場前）

RootがF3全70と独立保存の成功後に固定した参照だけを正式保存する。市場Nativeを復号せず、同bytesのコピーとSHAを検査する。旧93・94・110、111の停止済み金融・独立保存・P監査・I/O名adapterは変更しない。市場を回し直さず、原板・共有分足・価格CSVの本文を再読・複製しない。

## 固定要求

`正式保存する.py --request <絶対要求JSON> --request-sha <期待SHA256>`。要求は以下を含む。

- `version:1, trial:111, fixed:true, stage:"full70", market_native_read_authorized:true`。
- `refs`：`condition`（最終F3）、`market`（全70完了）、`result`（独立結果）、`saved_check`、`oracle54`（原文oracle元54完了）、`core_stop/source_stop/actor_stop/chart_stop/pure_stop/save_stop/P_stop/io_stop/parallel_stop/same_entry_stop/formal_stop`。いずれも絶対 `path/sha256`。容量 `bytes` の付記も受理する。
- `go_environment:{version:"go1.24.2",root:<実選択GoRootの絶対位置>}`。
- `restore_roots:{repository:<このrepo絶対位置>,module_cache:<実選択Go module cache絶対位置>}`。閉包が他の根にある場合だけ重ならない明示根を追加する。
- 任意の `code_refs:[{ref:<FileRef>,role:<用途>}]`：Rootの条件固定器、再現スクリプト、必要なLICENSE・明示宣言など。F3の `code_sha256`、各stopの所有コード、旧保存・ZIP共通部、24条件等の宣言、最終並列実行物・原文oracle実行物は自動で含む。不要なSource薄CLI実行物は自動複製しない。
- 任意の `extra_refs:[{ref:<FileRef>,target:<試行内相対位置>,role:<用途>}]`：最終同入口比較（36集計・2520対照場別）、診断、先頭2の成功metadata、直列/並列bytes一致、中断記録、Root作成のCSV2点と確認等。先頭2の金融NativeやViewer全件は複製しない。保存先は `診断/検査/CSV/再現資料` 内の未使用位置に限る。CSV・最終文書はRootが作成し、この器は生成・改稿しない。

全Refは最終正式保存の前にRootが一つの要求へまとめる。この器は既存正式先への追記・上書きをしない。後段CSVなどが未確定なら要求固定と本実行を待つ。

## 正式先

`study/00111_元の連続判断と必須追尾の再基準化/` に次を新規保存する。

- `成果物/`：独立結果・検算・一覧・1680の約定ファイル。0約定も保持する。
- `成果物_金融/Native/`：最終全70のNativeを一回ずつ同bytes保存する。最初54の元pathはbase54出力先のまま認証できる。Nativeを再生・再生成したとは呼ばない。
- `原文oracle54/`：元54の小さな原文oracle Event参照を再現根拠として保持する。
- `検査/`：固定条件、各停止と成功、入力台帳、Root正式要求、正式確認。
- `再現資料/`：既存109・110のZIP三関数をそのまま使ったコードZIP、元path付き索引、復元根と限界を記す再現手順。
- `診断/CSV/` 等：Rootが明示した後段extraだけ。

F3 full70の成功は `reused_sessions=54/replayed_sessions=16` を区別する。F2直列の途中19場は中断であり、正式成功として再用しない。正式保存器は条件・結果・検算・全70Native参照・1682独立出力の集合、1680Viewer IDと約定ファイルの対応、原文oracle54の同じ参照集合を先に確認する。

## コード容量と復元

F3の実選択コード全閉包をSHA認証する。GoRootの標準Goは元path・相対位置・全SHA・容量・Go1.24.2を索引へ記録し、本文をZIPへ入れない。非GoRoot閉包と所有コード・宣言・必要実行物は元path単位で一度だけ保存し、役割を統合する。すでに正式metadataとして同bytesコピーするものはその所在を索引へ記し、ZIPで二重保存しない。

ZIPは全entryのSHA・サイズ・CRC・安全名・完全な集合を既存検査器で照合する。同じGo版と全標準SHAが一致する環境、共有原データは別に必要で、このZIPだけで環境全部を復元できるとは主張しない。入力pathや条件を勝手に書き換えない。

## 人工と停止

`人工検査.py` は全70×24の手製metadata、空の約定ファイル、復号しない仮Native、仮oracle、仮GoRootで保存経路を検査する。実市場・自然FAR生成・市場収支の検査ではない。標準Go非同梱、非標準コードの重複排除、base54元path許容、全bytes再読、ZIP全CRC、欠落・不一致・遡り・既存先の拒否を確認する。

```powershell
python -X utf8 人工検査.py
python -X utf8 検査して停止する.py --output <未作成の証拠先>
```

停止後はこのフォルダの所有4ファイルと共通部のSHAを固定する。本物の市場NativeはRootの要求固定後だけ認証・コピーする。金融再実行・CSV生成・Raw/価格CSV本文読取・11/09本文読取は0。保存成功で採用や研究目標達成を宣言せず、いずれもfalseとする。
