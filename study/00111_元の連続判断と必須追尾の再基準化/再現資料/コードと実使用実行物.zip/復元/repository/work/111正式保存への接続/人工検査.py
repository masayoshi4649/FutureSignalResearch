"""手製の全70保存schemaだけで正式保存とZIPの境界を検査する。"""

from copy import deepcopy
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import 正式保存する as F


def make_fixture(base: Path) -> dict:
    """機能: 市場本文を使わず全70×24の明示参照と停止・成果物を手製作成する。

    引数: base(Path)は一時人工領域。
    返り値: dictは要求Ref・fixture値・仮正式先。人工成功を市場成功へ転用しない。
    """
    base.mkdir()
    source = base / '手製入力'
    source.mkdir()

    def put(name: str, value: dict) -> dict:
        """機能: 手製metadataを新規保存して参照を返す。

        引数: name(str)、value(dict)は人工名と値。
        返り値: dictは人工FileRef。
        """
        path = source / name
        F.write_json(path, value)
        return F.ref(path)

    # ----------------------------------------
    # 仮の標準Goと非標準コード。原データを開く関数は持たない。
    goroot = source / '仮GoRoot'
    goroot.mkdir()
    standard = goroot / '標準.go'
    standard.write_text('package 手製\n', encoding='utf-8')
    custom = source / '手製.go'
    custom.write_text('package 手製\n', encoding='utf-8')
    exe = source / '手製並列.exe'
    oracle_exe = source / '手製oracle.exe'
    exe.write_bytes('実行しない器具'.encode())
    oracle_exe.write_bytes('実行しない原文器具'.encode())
    owned = {str(F.OWN / name): F.sha(F.OWN / name) for name in ('正式保存する.py', '人工検査.py', '検査して停止する.py', 'README.md')}
    refs = {}
    stopped = {'成功': True, '市場前': True, '所有ファイルSHA256': {}}
    for name in ('P_stop', 'source_stop', 'actor_stop', 'chart_stop', 'pure_stop', 'core_stop', 'parallel_stop', 'same_entry_stop'):
        refs[name] = put(name + '.json', stopped)
    refs['save_stop'] = put('save_stop.json', {**stopped, '純保護監査停止': refs['P_stop']})
    refs['io_stop'] = put('io_stop.json', {**stopped, '元保存停止': refs['save_stop'], '純保護停止': refs['P_stop']})
    refs['formal_stop'] = put('formal_stop.json', {**stopped, '所有ファイルSHA256': owned})
    expected = F.sessions()
    oracle_results = {sid: put(sid + '.oracle.json', {'手製Event': sid}) for sid in expected[:54]}
    immutable = {str(custom): F.sha(custom)}
    refs['oracle54'] = put('oracle54.json', {'trial': 111, 'success': True, 'stage': 'original54', 'sessions': 54,
                                           'published_gross_checked': True, 'published_gross_equal': True, 'unchanged': True,
                                           'before': immutable, 'after': immutable, 'holdout_11_09_read': False, 'raw_copied': False,
                                           'historical_saved_event_equality': False, 'all_signal_full_json_equal': False, 'results': oracle_results})
    manifest = put('手製共用入力台帳.json', {'人工': True, '本文なし': True})
    declarations = {name: put(name + '.json', {'手製宣言': name}) for name in ('actual_declaration', 'pure_declaration', 'chart_declaration')}
    condition = {'version': 1, 'trial': 111, 'fixed': True, 'actual_configurations': list(F.CONFIGS),
                 'entry_grid_seconds': None, 'extra_opening_quiet_seconds': 0, 'chart_seed_mode': 'cold_each_session',
                 'parallel_stop': refs['parallel_stop'], 'runtime_stop': refs['core_stop'],
                 'derivation': {'financial_specifications_equal': True},
                 'dependency_stops': {name: refs[name + '_stop'] for name in ('source', 'actor', 'chart', 'pure')},
                 'code_sha256': {str(custom): F.sha(custom), str(standard): F.sha(standard)},
                 'manifest': manifest, 'original166_references': oracle_results,
                 'executable': F.ref(exe), 'oracle_executable': F.ref(oracle_exe), **declarations}
    refs['condition'] = put('condition.json', condition)
    native, native_refs = [], []
    for index, sid in enumerate(expected):
        directory = source / ('仮base54' if index < 54 else '仮full70')
        directory.mkdir(exist_ok=True)
        path = directory / (sid + '.Native.json.gz')
        path.write_bytes(('復号しない仮Native:' + sid).encode())
        reference = F.ref(path)
        native.append({'session': sid, 'native': reference, 'books': 24, 'S0_comparisons': 4, 'S0_equal': True,
                       'complete': True, 'open_quantity': 0, 'pending_quantity': 0})
        native_refs.append({'session': sid, **reference})
    prior54 = put('仮base54完了.json', {'人工': True, 'success': True, 'sessions': 54})
    market = {'version': 1, 'trial': 111, 'success': True, 'stage': 'full70', 'sessions': 70, 'books': 1680,
              'reused_sessions': 54, 'replayed_sessions': 16, 'unchanged': True, 'before': immutable, 'after': immutable,
              'condition_sha256': refs['condition']['sha256'], 'all_original166_reference_events_equal': True,
              'historical_saved_events_equal': False, 'all_original_signal_full_json_equal': False, 'results': native, 'prior54': prior54}
    refs['market'] = put('market.json', market)
    saved_dir = source / '仮独立保存'
    saved_dir.mkdir()
    resources, output_sha = [], {}
    for sid in expected:
        for key in F.KEYS:
            name = f'111_{key}_{sid}.trades.jsonl'
            path = saved_dir / name
            path.write_bytes(b'')
            output_sha[name] = F.sha(path)
            resources.append({'id': f'111_{key}_{sid}', 'session': sid, 'method_id': key, 'pnl_path': name,
                              'symbol': 'NK225', 'product': 'NK225mini', 'point_value': 100, 'pnl_basis': 'net', 'pnl_format': 'trades'})
    catalog_path = saved_dir / '一覧.resources.json'
    F.write_json(catalog_path, {'schema_version': 1, 'path_base': 'catalog', 'resources': resources})
    output_sha[catalog_path.name] = F.sha(catalog_path)
    result = {'試行': 111, '成功': True, 'stage': 'full70', '場数': 70, '会計数': 1680, '主key': list(F.KEYS),
              '前後不変': True, '入力codeSHA256前': immutable, '入力codeSHA256後': immutable,
              '金融条件SHA256': refs['condition']['sha256'], '金融完了SHA256': refs['market']['sha256'],
              '保存器停止SHA256': refs['save_stop']['sha256'], '純保護監査停止SHA256': refs['P_stop']['sha256'],
              'I/O接続停止SHA256': refs['io_stop']['sha256'], 'Native参照': native_refs,
              'Viewer形式資源': 1680, 'Viewer保存再読': [{'session': sid, '資源': 24, '全残0': True} for sid in expected],
              '場別': [{'session': sid, 'key': key} for sid in expected for key in F.KEYS], '集計': {key: {} for key in F.KEYS},
              '採用': False, '研究目標達成': False}
    result_path = saved_dir / '結果.json'
    F.write_json(result_path, result)
    refs['result'] = F.ref(result_path)
    output_sha['結果.json'] = refs['result']['sha256']
    saved = {'試行': 111, '成功': True, '前後不変': True, '不一致数': 0, '場数': 70, '会計数': 1680, '資源': 1680,
             'S0全金融比較': 280, '全残玉予約0': True, '金融条件SHA256': refs['condition']['sha256'],
             '金融完了SHA256': refs['market']['sha256'], '出力SHA256': output_sha}
    saved_path = saved_dir / '保存会計の確認.json'
    F.write_json(saved_path, saved)
    refs['saved_check'] = F.ref(saved_path)
    csv_path = source / 'Root作成済みの仮CSV.csv'
    csv_path.write_text('手製列\n0\n', encoding='utf-8-sig')
    request = {'version': 1, 'trial': 111, 'fixed': True, 'stage': 'full70', 'market_native_read_authorized': True,
               'refs': refs, 'go_environment': {'version': 'go1.24.2', 'root': str(goroot)},
               'restore_roots': {'repository': str(F.ROOT), 'module_cache': str(source / '仮modulecache')},
               'code_refs': [{'ref': F.ref(custom), 'role': '同pathの二用途人工'}],
               'extra_refs': [{'ref': F.ref(csv_path), 'target': 'CSV/Root作成済み.csv', 'role': 'Root作成済みCSVのbyte接続'}]}
    request_ref = put('request.json', request)
    return {'ref': request_ref, 'request': request, 'values': {'condition': condition, 'market': market, 'result': result,
             'saved_check': saved}, 'trial': base / '仮正式先', 'standard': standard, 'custom': custom, 'source': source}


class FormalSaveTests(unittest.TestCase):
    """実市場を読まず正式保存schemaと全bytes境界を確認する。"""

    def setUp(self) -> None:
        """機能: この検査専用のrepo内一時領域を作る。

        引数: self(FormalSaveTests)は検査器。
        返り値: None。
        """
        self.temporary = tempfile.TemporaryDirectory(prefix='人工正式保存_', dir=F.OWN)
        self.base = Path(self.temporary.name)

    def tearDown(self) -> None:
        """機能: 一時人工だけをPython標準の管理で片付ける。

        引数: self(FormalSaveTests)は検査器。
        返り値: None。
        """
        self.temporary.cleanup()

    def test_full70_samebytes_and_zip(self) -> None:
        """機能: base54元pathを保つ全70・1680資源と標準Go非同梱を実保存する。

        引数: self(FormalSaveTests)は検査器。
        返り値: None。全て仮Native・空約定・仮oracleで実市場ではない。
        """
        fixture = make_fixture(self.base / '成功器具')
        with patch.object(F, 'TRIAL', fixture['trial']):
            result = F.execute(fixture['ref'])
            proof = F.read(result['正式保存の確認'], {})
            index = F.read(result['索引'], {})
            self.assertEqual(proof['Native数'], 70)
            self.assertEqual(proof['Viewer資源'], 1680)
            self.assertEqual(len(list((fixture['trial'] / '成果物').glob('*.trades.jsonl'))), 1680)
            self.assertEqual(len(list((fixture['trial'] / '原文oracle54').glob('*.json'))), 54)
            self.assertEqual(index['GoRoot索引数'], 1)
            self.assertEqual(sum(r['original_path'] == str(fixture['custom']) for r in index['entries']), 1)
            self.assertTrue(proof['前後不変'])
            self.assertFalse(proof['研究目標達成'])
            with zipfile.ZipFile(result['ZIP']['path']) as archive:
                self.assertIsNone(archive.testzip())
                self.assertTrue(all('仮GoRoot' not in name for name in archive.namelist()))
            for row in proof['同bytes成果物']:
                self.assertEqual(F.sha(fixture['trial'] / row['relative']), row['sha256'])
            with self.assertRaises(ValueError):
                F.execute(fixture['ref'])

    def test_corrupt_native_rejected_before_writing(self) -> None:
        """機能: Native bytesの破壊を正式先の作成前に拒否する。

        引数: self(FormalSaveTests)は検査器。
        返り値: None。
        """
        fixture = make_fixture(self.base / '破壊器具')
        path = Path(fixture['values']['market']['results'][0]['native']['path'])
        path.write_bytes(b'changed')
        with patch.object(F, 'TRIAL', fixture['trial']), self.assertRaises(ValueError):
            F.prepare(fixture['ref'])
        self.assertFalse(fixture['trial'].exists())

    def test_failure_and_missing_scope_rejected(self) -> None:
        """機能: 途中失敗・54再用の偽装・全場欠落を純gateで拒否する。

        引数: self(FormalSaveTests)は検査器。
        返り値: None。
        """
        fixture = make_fixture(self.base / '条件拒否器具')
        values = {name: F.read(value, {}) for name, value in fixture['request']['refs'].items()}
        for kind in ('failed', 'base54', 'replay70', 'missing', 'false_history', 'no_oracle', 'nonflat', 'adopted'):
            modified = deepcopy(values)
            if kind == 'failed':
                modified['market']['success'] = False
            elif kind == 'base54':
                modified['market']['stage'] = 'base54'
            elif kind == 'replay70':
                modified['market']['reused_sessions'] = 0
            elif kind == 'missing':
                modified['market']['results'].pop()
            elif kind == 'false_history':
                modified['market']['historical_saved_events_equal'] = True
            elif kind == 'no_oracle':
                modified['oracle54']['results'].pop(F.sessions()[0])
            elif kind == 'nonflat':
                modified['market']['results'][0]['pending_quantity'] = 1
            else:
                modified['result']['採用'] = True
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                F.validate(modified, fixture['request'])

    def test_unsafe_extra_and_existing_destination_rejected(self) -> None:
        """機能: 遡り相対先と既存正本をコピー開始前に拒否する。

        引数: self(FormalSaveTests)は検査器。
        返り値: None。
        """
        fixture = make_fixture(self.base / '保存先拒否器具')
        bad = deepcopy(fixture['request'])
        bad['extra_refs'][0]['target'] = '診断/../../外部.csv'
        path = fixture['source'] / 'bad.json'
        F.write_json(path, bad)
        with patch.object(F, 'TRIAL', fixture['trial']), self.assertRaises(ValueError):
            F.prepare(F.ref(path))
        target = fixture['trial'] / '成果物/結果.json'
        target.parent.mkdir(parents=True)
        target.write_bytes(b'prior')
        with patch.object(F, 'TRIAL', fixture['trial']), self.assertRaises(ValueError):
            F.prepare(fixture['ref'])
        self.assertEqual(target.read_bytes(), b'prior')


if __name__ == '__main__':
    unittest.main(verbosity=2)
