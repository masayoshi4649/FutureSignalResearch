"""111の同実入口差を、候補の初回狭幅時点のP/C/M/Bで分類する。"""

import argparse
from collections import Counter, defaultdict
from decimal import Decimal
from datetime import datetime, timezone, timedelta
import hashlib
import importlib.util
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE_PATH = ROOT / 'work/110出口の同入口比較_準備/比較する.py'
BASE_SHA = 'c9427ba73718d4de857b596e3eeaac7c9c81da80a3ad70d70e2403a7eb41959f'
if hashlib.sha256(BASE_PATH.read_bytes()).hexdigest() != BASE_SHA:
    raise ValueError('停止110の同入口比較器SHA差')
SPEC = importlib.util.spec_from_file_location('停止110の入口同体111', BASE_PATH)
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)
need, sha, load, serial = BASE.need, BASE.sha, BASE.load, BASE.serial
TRUTHS = {0: '未知', 1: '偽', 2: '真'}
P_GROUPS = ('P真・支持否定成立', 'P偽・既知の支持否定なし', 'P未知・情報不足', '狭幅なし')
PAIRS = tuple((f'W100_C{c}_D{d}', f'{policy}_C{c}_D{d}')
              for c in (0, 5) for d in (0, 1) for policy in ('T100', 'B100'))
OWN_NAMES = ('分類する.py', '分類の人工検査.py', 'README.md')


def truth_or(a: int, b: int) -> int:
    """機能: 未知を偽へ変換しない三値ORを評価する。

    引数: a/b(int)は未知0・偽1・真2。
    返り値: intは三値結果。
    """
    need(type(a) is int and type(b) is int and a in TRUTHS and b in TRUTHS, '三値ORの範囲')
    return 2 if 2 in (a, b) else 0 if 0 in (a, b) else 1


def narrow_class(position: dict, policy: str) -> tuple[str, tuple, dict | None]:
    """機能: 初狭幅保存点の既知P/C/M/Bをその時点だけで分類する。

    引数: position(dict)は候補実玉、policy(str)はT100/B100。
    返り値: tuple[str,tuple,dict/None]はP群・三値プロフィール・保存点。
    """
    need(policy in ('T100', 'B100'), '狭幅候補の政策')
    audit = position['protection111']
    trace = audit['first_narrowing']
    need((trace is not None) == audit['final_state']['narrowed'], '初狭幅と最終ラッチの有無')
    if trace is None:
        return P_GROUPS[3], (None, None, None, None), None
    s, d = trace['snapshot'], trace['decision']
    need(s['active'] and s['narrowed'] and d['narrowed_now'] and s['narrowed_at'] == trace['at'], '初狭幅の時計と起動')
    for name in ('c', 'm', 'p', 'b', 'warning'):
        need(type(d[name]) is int and d[name] in TRUTHS, '警戒の三値範囲/' + name)
    need(d['warning'] == d['m'] == 2, '初狭幅の複合警戒とM真')
    combine = truth_or(d['c'], d['p'])
    if policy == 'B100':
        combine = truth_or(combine, d['b'])
    need(combine == 2, '当時のC/P/Bで警戒が成立')
    p = s['latest']
    need(p is not None and trace['quote'] is not None and d['gain_points'] is not None,
         '初狭幅には当時の公表と正常価格評価が必要')
    expected_p = 0
    if p is not None and p['close'] is not None and p['prior_pivot'] is not None:
        expected_p = 2 if position['side'] * (p['close'] - p['prior_pivot']['price']) < 0 else 1
    need(d['p'] == expected_p, 'Pは当時公表Closeとprior pivotだけで判定')
    if p is not None:
        need(p['available_at'] <= trace['at'], '初狭幅公表の未来なし')
        need(d['c'] == p['c'] and d['m'] == p['m'], '初狭幅C/Mの原値')
        need(d['b'] == (p['bb']['contraction'] if p['bb'] is not None else 0), '初狭幅Bの原値')
        if p['prior_pivot'] is not None:
            need(p['prior_pivot']['published_at'] <= p['available_at'], 'prior pivot確認前の遡及なし')
    label = {2: P_GROUPS[0], 1: P_GROUPS[1], 0: P_GROUPS[2]}[d['p']]
    return label, tuple(d[k] for k in ('p', 'c', 'm', 'b')), trace


def aggregate_pairs(pairs: list[tuple[dict, dict]]) -> dict:
    """機能: 成立済み同入口ペアの実現額・正負・損失額差だけを加算する。

    引数: pairs(list[tuple[dict,dict]])はW100と候補の実玉。
    返り値: dictは両実績と実現差の加法。架空取引を作らない。
    """
    a, b = BASE.statistics([p[0] for p in pairs]), BASE.statistics([p[1] for p in pairs])
    deltas = [p[1]['realized_net'] - p[0]['realized_net'] for p in pairs]
    result = {'前': a, '後': b, '実現差円': b['実現円'] - a['実現円'],
              '実現増玉': sum(d > 0 for d in deltas), '実現減玉': sum(d < 0 for d in deltas),
              '同額玉': sum(d == 0 for d in deltas),
              '実現増額円': sum((d for d in deltas if d > 0), Decimal(0)),
              '実現減額円': sum((d for d in deltas if d < 0), Decimal(0)),
              '利益総額差円': b['利益総額円'] - a['利益総額円'],
              '損失総額差円': b['損失総額円'] - a['損失総額円']}
    need(result['実現差円'] == result['実現増額円'] + result['実現減額円'] ==
         result['利益総額差円'] + result['損失総額差円'], '分類内実現差の加法')
    return result


def compare_scene(a: dict, b: dict, session: str) -> tuple[dict, list[dict]]:
    """機能: 停止110の厳密入口同体を再用し、同入口だけを初狭幅状態へ分類する。

    引数: a/b(dict)はW100/候補実口座、session(str)は場。
    返り値: tuple[dict,list[dict]]は四群比較と同入口分類レコード。
    """
    ca, cb = a['config'], b['config']
    need(ca['policy'] == 'W100' and cb['policy'] in ('T100', 'B100'), '比較政策の限定')
    need(ca['slip_pts'] == cb['slip_pts'] and ca['delay_seconds'] == cb['delay_seconds'], '同費用・同遅延')
    result = BASE.compare(a, b)
    pa, fa = BASE.validate_book(a)
    pb, fb = BASE.validate_book(b)
    records = []
    for identity in sorted(pa.keys() & pb.keys()):
        if fa[identity] != fb[identity]:
            continue
        before, after = pa[identity], pb[identity]
        group, profile, trace = narrow_class(after, cb['policy'])
        records.append({'session': session, 'identity': identity, 'before': before,
                        'after': after, 'P群': group, 'profile': profile, 'trace': trace,
                        'delta': after['realized_net'] - before['realized_net']})
    need(len(records) == result['群']['同実入口']['前']['玉'], '同入口分類の玉集合')
    need(sum((r['delta'] for r in records), Decimal(0)) == result['群']['同実入口']['実現差円'], '同入口分類の実現差')
    return result, records


def example(record: dict) -> dict:
    """機能: 同入口実例の識別・当時技法・実返済額を小さく抜粋する。

    引数: record(dict)は照合済み同入口分類レコード。
    返り値: dictは実例。退出後の価格や仮想利益を含めない。
    """
    a, b, trace = record['before'], record['after'], record['trace']
    result = {'場': record['session'], 'Source手法': record['identity'][0], 'Source信号ID': record['identity'][1],
              '前PositionID': a['id'], '後PositionID': b['id'], '方向': a['side'], '枚数': a['initial_quantity'],
              '同体な実新規': {'価格': a['entry_price'], 'quote': a['entry_quote']},
              '前実現円': a['realized_net'], '後実現円': b['realized_net'], '実現差円': record['delta'],
              '前実返済原行': a.get('closed_quote'), '後実返済原行': b.get('closed_quote'), 'P群': record['P群']}
    if trace is None:
        result['初狭幅'] = None
        return result
    s, d, p = trace['snapshot'], trace['decision'], trace['snapshot']['latest']
    result['初狭幅'] = {'at': trace['at'], 'JST': datetime.fromtimestamp(float(trace['at']), timezone(timedelta(hours=9))).isoformat(),
                       'phase': trace['phase'], 'quote': trace['quote'], '三値': {k: d[k] for k in ('p', 'c', 'm', 'b', 'warning')},
                       '通常幅pt': s['normal_width'], '狭幅pt': s['width_points'], '床pt': s['floor_points'],
                       'g_pt': d['gain_points'], 'W円': d['whole_net_yen'], '公表ID': p['id'] if p is not None else None,
                       '公表時刻': p['available_at'] if p is not None else None,
                       'Close': p['close'] if p is not None else None,
                       'prior_pivot': p['prior_pivot'] if p is not None else None}
    return result


def summarize(scene_results: list[dict], records: list[dict]) -> dict:
    """機能: 四群の全実現差と同入口P群/三値プロフィールを厳密に再結合する。

    引数: scene_results(list[dict])は全場比較、records(list[dict])は同入口分類。
    返り値: dictは全体・四群・P群・プロフィール・小実例。
    """
    all_results = BASE.add_results(scene_results)
    groups = {}
    for label in P_GROUPS:
        selected = [r for r in records if r['P群'] == label]
        groups[label] = aggregate_pairs([(r['before'], r['after']) for r in selected])
        unknown = Counter()
        for r in selected:
            if label == P_GROUPS[2]:
                latest = r['trace']['snapshot']['latest']
                reason = '公表なし' if latest is None else 'Close未知' if latest['close'] is None else 'prior pivot未知'
                unknown[reason] += 1
        if unknown:
            groups[label]['P未知理由'] = dict(unknown)
    profiles = []
    for values in sorted({r['profile'] for r in records}, key=str):
        selected = [r for r in records if r['profile'] == values]
        profiles.append({'P_C_M_B': dict(zip(('p', 'c', 'm', 'b'), values)),
                         '三値表示': {k: TRUTHS[v] if v is not None else '対象外（狭幅時点なし）'
                                       for k, v in zip(('p', 'c', 'm', 'b'), values)},
                         **aggregate_pairs([(r['before'], r['after']) for r in selected])})
    same = all_results['群']['同実入口']
    need(sum(g['前']['玉'] for g in groups.values()) == same['前']['玉'], 'P群の同入口分母')
    need(sum((g['実現差円'] for g in groups.values()), Decimal(0)) == same['実現差円'] ==
         sum((r['実現差円'] for r in profiles), Decimal(0)), 'P群/三値プロフィール/同入口差の一致')
    rest = sum((all_results['群'][k]['実現差円'] for k in BASE.GROUPS[1:]), Decimal(0))
    need(all_results['全体']['実現差円'] == same['実現差円'] + rest, '全差−同入口差と非同入口群の一致')
    examples = []
    for label in P_GROUPS:
        selected = [r for r in records if r['P群'] == label and r['delta'] != 0]
        negative, positive = [r for r in selected if r['delta'] < 0], [r for r in selected if r['delta'] > 0]
        if negative:
            examples.append(example(min(negative, key=lambda r: (r['delta'], r['session'], r['identity']))))
        if positive:
            examples.append(example(max(positive, key=lambda r: (r['delta'], r['session'], r['identity']))))
    return {'四群比較': all_results, 'P群': groups, '初狭幅の三値プロフィール': profiles,
            '全差から同入口差を引いた円': rest, '実例': examples}


def verify_stop(ref: dict) -> dict:
    """機能: 人工後停止を先に認証し同じコードだけで実診断を受け付ける。

    引数: ref(dict)は停止JSONの絶対pathとSHA256。
    返り値: dictは認証した所有/再用指紋。
    """
    stop = load(Path(ref['path']), ref['sha256'])
    need(stop['成功'] is True and stop['市場前'] is True, '市場前人工成功の停止必須')
    expected_names = {str(HERE / n) for n in OWN_NAMES}
    need(set(stop['所有SHA256']) == expected_names, '停止所有集合')
    for path, expected in {**stop['所有SHA256'], **stop['再用SHA256']}.items():
        need(sha(Path(path)) == expected, '停止コードの現物SHA差')
    return {**stop['所有SHA256'], **stop['再用SHA256']}


def report_md(result: dict) -> str:
    """機能: 各費用/遅延を混ぜず小集計と当時情報による研究候補をMarkdownへ表す。

    引数: result(dict)は全比較の認証済み実現集計。
    返り値: strは小レポート。最適化済み手法や指標単独効果とは扱わない。
    """
    lines = [f"# 111 初狭幅時点の支持否定と実現差（{result['場数']}場）", '',
             'W100を対照に、同じ費用・遅延のT100/B100を比較した。入口はSource全文・新規注文・new fill・実玉の時刻/価格/枚数/気配/費用まで照合した。取得変更・片側のみは別群で、以下のP分類は同実入口群だけ。', '',
             'P偽は「既知の支持否定なし」、P未知は情報不足。P偽を支持継続や強いトレンドと読み替えない。「狭幅なし」は分類時点がなく、未知に補完しない。', '']
    for policy in ('T100', 'B100'):
        lines += [f'## W100 → {policy}', '',
                  '|費用/遅延|同入口玉|全実現差円|P真 玉/差円|P偽 玉/差円|P未知 玉/差円|狭幅なし 玉/差円|非同入口差円|',
                  '|---|---:|---:|---:|---:|---:|---:|---:|']
        for cost in (0, 5):
            for delay in (0, 1):
                r = result['比較'][f'W100_C{cost}_D{delay}→{policy}_C{cost}_D{delay}']
                cells = [f'C{cost}D{delay}', str(r['四群比較']['群']['同実入口']['前']['玉']),
                         f"{r['四群比較']['全体']['実現差円']:,}"]
                for label in P_GROUPS:
                    g = r['P群'][label]
                    cells.append(f"{g['前']['玉']} / {g['実現差円']:,}")
                cells.append(f"{r['全差から同入口差を引いた円']:,}")
                lines.append('|' + '|'.join(cells) + '|')
        lines += ['']
    lines += ['## 主条件C0D0の実例', '']
    for policy in ('T100', 'B100'):
        r = result['比較'][f'W100_C0_D0→{policy}_C0_D0']
        for label in P_GROUPS[:3]:
            examples = [e for e in r['実例'] if e['P群'] == label]
            if not examples:
                continue
            e = min(examples, key=lambda x: x['実現差円'])
            t = e['初狭幅']
            lines += [f"- {policy}・{label}：{e['場']} / `{e['Source信号ID']}`。同入口{e['枚数']}枚、W100実現{e['前実現円']:,}円 → {policy}実現{e['後実現円']:,}円、差{e['実現差円']:,}円。",
                      f"  初狭幅は{t['JST']}、P/C/M/B={t['三値']['p']}/{t['三値']['c']}/{t['三値']['m']}/{t['三値']['b']}（未知0・偽1・真2）、通常幅{t['通常幅pt']} → 狭幅{t['狭幅pt']}pt。その時点のClose/pivotと実返済原行はJSONへ保存。"]
    lines += ['', '## 事実と次の仮説', '',
              '分類は候補側が実際に最初に狭幅へ移った時点の保存値に基づく。表の差は両実政策の実現差であり、同じP状態を条件として新たに運転した収支ではない。P/C/M/Bの単独因果、最適な閾値、将来場での優位性は断言しない。費用/遅延違いを合算した独立標本とも扱わない。', '',
              '次の切替候補は、一定利益後の通常追尾を維持した上で、M真でもP偽なら「支持否定はまだ確認されていない」として通常幅を維持し、P未知も偽へ補完せず通常幅を維持する案。P真とM真の複合確認後に狭幅へ移る対照を新試行で固定できる。収束CやBB収縮Bは方向や支持否定そのものではなく、二票として数えない。これは今回の分類から立てる仮説で、現在の111を変更した結果ではない。', '',
              '取得変更・片側のみ、P/C/M/B全プロフィール、増益/減益/同額玉、利益総額差/損失総額差、原値出典は[集計.json](集計.json)を参照。全差＝同入口P群差＋非同入口差を照合し、全純額・損失総額・玉数を独立保存結果へ照合済み。', '',
              '原板・価格CSV・11月09日本文を読まず、金融再走・閾値変更・未参加/退出後の仮想利益評価は行っていない。', '']
    return '\n'.join(lines)


def run(request_ref: dict, saved_ref: dict, audit_ref: dict, stop_ref: dict, out: Path) -> dict:
    """機能: RootがSHA付き解禁した54/70Nativeから同じ停止器で8比較を行う。

    引数: 各ref(dict)はRoot解禁要求・独立結果・検算・本器停止、out(Path)は新規先。
    返り値: dictは小集計。Raw/価格CSV/11月09日/F2途中を開かない。
    """
    codes = verify_stop(stop_ref)
    request = load(Path(request_ref['path']), request_ref['sha256'])
    saved = load(Path(saved_ref['path']), saved_ref['sha256'])
    audit = load(Path(audit_ref['path']), audit_ref['sha256'])
    stage = request['stage']
    count = {'base54': 54, 'full70': 70}.get(stage)
    need(count is not None and request['trial'] == 111 and request['fixed'] is True and
         request['market_native_read_authorized'] is True and len(request['scenes']) == count, '解禁された全54/70だけ')
    for value in (saved, audit):
        need(value['成功'] is True and value['stage'] == stage and value['場数'] == count and
             value['Root保存要求SHA256'] == request_ref['sha256'] and
             value['金融完了SHA256'] == request['completion']['sha256'] and
             value['金融条件SHA256'] == request['condition']['sha256'], '独立保存成功と解禁の結合')
    completion = load(Path(request['completion']['path']), request['completion']['sha256'])
    need(completion['success'] is True and completion['sessions'] == count and completion['books'] == 24 * count,
         '金融の全場24成功')
    need(completion['condition_sha256'] == request['condition']['sha256'], '金融条件との結合')
    saved_natives = {r['session']: {'path': r['path'], 'sha256': r['sha256']} for r in saved['Native参照']}
    completed = {r['session']: r['native'] for r in completion['results']}
    need(len(saved_natives) == len(completed) == count, '保存/金融Native場の一意性')
    inputs = {request_ref['path']: request_ref['sha256'], saved_ref['path']: saved_ref['sha256'],
              audit_ref['path']: audit_ref['sha256'], stop_ref['path']: stop_ref['sha256'],
              request['completion']['path']: request['completion']['sha256']}
    results = {f'{a}→{b}': [] for a, b in PAIRS}
    records = {k: [] for k in results}
    sessions = []
    for scene in request['scenes']:
        sid, native_ref = scene['session'], scene['native']
        need(sid not in sessions and not sid.startswith('2026-11-09'), '場重複/11月09日本文の拒否')
        need(saved_natives.get(sid) == completed.get(sid) == native_ref, 'Root/金融/独立保存Native同体')
        sessions.append(sid)
        inputs[native_ref['path']] = native_ref['sha256']
        native = load(Path(native_ref['path']), native_ref['sha256'])
        actual = native['actual']
        need(actual['complete'] and actual['scope']['session']['id'] == sid, 'Native全体完結と場')
        for a, b in PAIRS:
            key = f'{a}→{b}'
            compared, members = compare_scene(actual['books'][a], actual['books'][b], sid)
            results[key].append(compared)
            records[key].extend(members)
        print(f'{len(sessions)}/{count} {sid} 認証後に8比較', flush=True)
    comparisons = {}
    for a, b in PAIRS:
        key = f'{a}→{b}'
        row = summarize(results[key], records[key])
        for side, candidate in (('前', a), ('後', b)):
            st = row['四群比較']['全体'][side]
            need(st['実現円'] == saved['集計'][candidate]['net_yen'] and
                 st['損失総額円'] == saved['集計'][candidate]['negative_yen'] and
                 st['玉'] == saved['集計'][candidate]['positions'], '全体実額/損失/玉数は独立保存と同体')
        comparisons[key] = row
    need(all(sha(Path(p)) == h for p, h in {**inputs, **codes}.items()), '読取前後の入力/停止コード同体')
    result = {'試行': 111, '成功': True, 'stage': stage, '場数': count, '比較数': 8,
              '停止SHA256': stop_ref['sha256'], '入力SHA256': inputs, 'コードSHA256': codes,
              '定義': {'同入口': '停止110のSource全文・新規注文・new fill・実玉全文照合。政策由来IDだけ除く。',
                       'P真': '初狭幅時点の公表Closeが買low/売highのprior pivotを支持否定側へ越えた。',
                       'P偽': '既知の支持否定なし。将来のトレンドや支持継続を保証しない。',
                       'P未知': 'その時点のClose又はprior pivot等が不足。偽に補完しない。',
                       '狭幅なし': '候補に初狭幅時点なし。P/C/M/Bを未知として補完せず対象外。',
                       '実現差': '候補の成立実現純額−W100の成立実現純額。機会損失ではない。'},
              '比較': comparisons, '全入力コード前後同体': True,
              '限界': ['候補側の初狭幅時点で分類した探索的記述。Pを入口/切替ゲートにした実装の収支ではない。',
                       '複合政策全体の差でありP/C/M/B単独の因果効果や最適閾値ではない。',
                       'first_narrowing以外の全原行・退出後の価格は再形成しない。'],
              'Raw/価格CSV/11月09日本文読取': False, '金融再走': False, '111固定変更': False,
              '未参加/退出後仮想利益の採点': False}
    need(not out.exists(), '結果先は新規だけ')
    out.mkdir(parents=True)
    (out / '集計.json').write_text(json.dumps(result, ensure_ascii=False, indent=2, default=serial) + '\n', encoding='utf-8')
    (out / 'レポート.md').write_text(report_md(result), encoding='utf-8')
    return result


def main() -> None:
    """機能: Rootが明示したRefだけを受け付け市場再走なしに診断する。

    引数: CLIのrequest/saved/audit/stop各pathとsha、outは新規先。
    返り値: None。不整合はValueErrorで終了。
    """
    parser = argparse.ArgumentParser(description='111同入口の初狭幅P/C/M/Bと実現差')
    for name in ('request', 'saved', 'audit', 'stop'):
        parser.add_argument('--' + name, type=Path, required=True)
        parser.add_argument('--' + name + '-sha', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    refs = [{'path': str(getattr(args, n).resolve()), 'sha256': getattr(args, n + '_sha')}
            for n in ('request', 'saved', 'audit', 'stop')]
    run(*refs, args.out.resolve())


if __name__ == '__main__':
    main()
