"""市場Nativeを使わず、入口四群・初狭幅三値・実現差の加法を止める。"""

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import unittest

import 分類する as A


def book(policy: str, specifications: list[tuple]) -> dict:
    """機能: 新規要求/実new/玉が一対一の非金融人工口座を作る。

    引数: policy(str)、specifications(list[tuple])はID・実現額・P又は狭幅なし。
    返り値: dictは入口同体と分類だけを検査する人工。相場を模擬しない。
    """
    positions, orders, fills = [], [], []
    for identity, net, p_value in specifications:
        q = {'time': 10, 'index': 1, 'source_line': 1, 'last': 100, 'bid': 100, 'ask': 105, 'quote_ok': True}
        source = {'method': '人工Source', 'signal_id': identity, 'birth_quantity': 1, 'birth_time': 9, 'birth_quote': q}
        pid, oid, fid, hold = policy + identity, policy + identity + '注文', policy + identity + '約定', identity + '元玉'
        audit = {'first_narrowing': None, 'final_state': {'narrowed': p_value is not None}}
        if p_value is not None:
            pivot = None if p_value == 0 else {'price': 110, 'published_at': 19}
            latest = {'id': '人工足', 'available_at': 20, 'close': 100 if p_value == 2 else 110,
                      'prior_pivot': pivot, 'c': 2, 'm': 2, 'bb': {'contraction': 1}}
            audit['first_narrowing'] = {'at': 20, 'phase': 'after_source', 'quote': q,
                                       'snapshot': {'active': True, 'narrowed': True, 'narrowed_at': 20, 'latest': latest,
                                                    'normal_width': 200, 'width_points': 20, 'floor_points': 80},
                                       'decision': {'p': p_value, 'c': 2, 'm': 2, 'b': 1, 'warning': 2, 'narrowed_now': True,
                                                    'gain_points': 100, 'whole_net_yen': 9923}}
        position = {'id': pid, 'entry_order_id': oid, 'source': source, 'source_hold_id': hold,
                    'side': 1, 'initial_quantity': 1, 'closed_quantity': 1, 'quantity': 0, 'reserved': 0,
                    'entry_price': 105, 'entry_quote': q, 'closed_quote': None, 'realized_net': net,
                    'marks': {'first_unit_positive': None, 'first_whole_positive': None},
                    'protection_active': True, 'activation': {'人工': True}, 'protection111': audit}
        order = {'id': oid, 'kind': 'entry', 'position_id': pid, 'side': 1, 'quantity': 1,
                 'source': source, 'source_hold_id': hold, 'request_time': 9, 'request_quote': q,
                 'reason': 'Source新規', 'status': 'filled', 'fill_id': fid}
        fill = {'id': fid, 'order_id': oid, 'position_id': pid, 'action': 'new', 'side': 1,
                'quantity': 1, 'price': 105, 'quote': q, 'source': source, 'source_hold_id': hold,
                'reason': 'Source新規', 'fee_yen': 38.5, 'slip_yen': 0,
                'gross_yen': 0, 'net_contribution_yen': -38.5, 'allocations': []}
        positions.append(deepcopy(position))
        orders.append(deepcopy(order))
        fills.append(deepcopy(fill))
    return {'config': {'policy': policy, 'slip_pts': 0, 'delay_seconds': 0},
            'positions': positions, 'orders': orders, 'fills': fills,
            'totals': {'net_yen': sum(p['realized_net'] for p in positions)}}


class ClassificationTests(unittest.TestCase):
    """三値と同入口を崩す改変の検出、実現差加法を確認する。"""

    def test_Pの真偽未知と狭幅なし(self):
        """機能: P偽を未知や支持保証へ変換せず狭幅なしを別にする。

        引数: self(TestCase)。返り値: None。
        """
        for value, expected in ((2, A.P_GROUPS[0]), (1, A.P_GROUPS[1]), (0, A.P_GROUPS[2]), (None, A.P_GROUPS[3])):
            position = book('T100', [('a', 100, value)])['positions'][0]
            label, profile, trace = A.narrow_class(position, 'T100')
            self.assertEqual(label, expected)
            self.assertEqual(profile[0], value)
            self.assertEqual(trace is None, value is None)

    def test_B追加と三値警戒の反例(self):
        """機能: BB収縮だけのOR追加をTとの違いとして検査する。

        引数: self(TestCase)。返り値: None。
        """
        p = book('B100', [('a', 100, 1)])['positions'][0]
        t = p['protection111']['first_narrowing']
        t['decision'].update(c=1, b=2)
        t['snapshot']['latest']['c'] = 1
        t['snapshot']['latest']['bb']['contraction'] = 2
        A.narrow_class(p, 'B100')
        with self.assertRaises(ValueError):
            A.narrow_class(p, 'T100')
        t['decision']['m'] = t['snapshot']['latest']['m'] = 0
        with self.assertRaises(ValueError):
            A.narrow_class(p, 'B100')

    def test_同Sourceでも実入口差を分ける(self):
        """機能: 政策ID差は同入口、新規価格/費用差は取得変更とする。

        引数: self(TestCase)。返り値: None。
        """
        a, b = book('W100', [('a', 100, None)]), book('T100', [('a', 50, 1)])
        compared, records = A.compare_scene(a, b, '人工場')
        self.assertEqual(len(records), 1)
        self.assertTrue(compared['全同実入口'])
        for change in ('価格', '費用'):
            changed = deepcopy(b)
            if change == '価格':
                changed['positions'][0]['entry_price'] = changed['fills'][0]['price'] = 110
            else:
                changed['fills'][0]['fee_yen'] += 1
            compared, records = A.compare_scene(a, changed, '人工場')
            self.assertEqual(len(records), 0)
            self.assertEqual(compared['群']['取得変更']['前']['玉'], 1)
        changed = deepcopy(b)
        changed['config']['delay_seconds'] = 1
        with self.assertRaises(ValueError):
            A.compare_scene(a, changed, '人工場')

    def test_四群とP群が全実現差へ戻る(self):
        """機能: 片側実取引に架空損益を付けず全差を再結合する。

        引数: self(TestCase)。返り値: None。
        """
        a = book('W100', [('同', 100, None), ('変', -20, None), ('前', -5, None)])
        b = book('T100', [('同', 50, 1), ('変', 10, 2), ('後', 7, 0)])
        b['positions'][1]['entry_price'] = b['fills'][1]['price'] = 110
        compared, records = A.compare_scene(a, b, '人工場')
        summary = A.summarize([compared], records)
        self.assertEqual(summary['四群比較']['全体']['実現差円'], -8)
        self.assertEqual(summary['P群'][A.P_GROUPS[1]]['実現差円'], -50)
        self.assertEqual(summary['全差から同入口差を引いた円'], 42)
        self.assertEqual([compared['群'][k]['実現差円'] for k in A.BASE.GROUPS], [-50, 30, 5, 7])

    def test_負値と0取引場と未知を期間で残す(self):
        """機能: 負値がCounter加算で消えず三値プロフィールとP群が一致する。

        引数: self(TestCase)。返り値: None。
        """
        a = book('W100', [('a', 100, None), ('b', -10, None), ('c', 5, None)])
        b = book('B100', [('a', 50, 0), ('b', -15, 1), ('c', 5, None)])
        first, records = A.compare_scene(a, b, '人工場')
        zero, none = A.compare_scene(book('W100', []), book('B100', []), '0取引場')
        summary = A.summarize([first, zero], records + none)
        self.assertEqual(summary['四群比較']['全体']['実現差円'], -55)
        self.assertEqual(summary['P群'][A.P_GROUPS[2]]['実現差円'], -50)
        self.assertEqual(summary['P群'][A.P_GROUPS[1]]['実現差円'], -5)
        self.assertEqual(summary['P群'][A.P_GROUPS[3]]['前']['玉'], 1)
        self.assertEqual(summary['P群'][A.P_GROUPS[2]]['P未知理由'], {'prior pivot未知': 1})

    def test_未来公表とP改竄と所有不整合を拒否(self):
        """機能: 保存時点Pを後付け変更せず入口所有の破損も拒否する。

        引数: self(TestCase)。返り値: None。
        """
        a, b = book('W100', [('a', 100, None)]), book('T100', [('a', 50, 1)])
        for mode in ('未来', 'P改竄', '所有', '公表なし'):
            changed = deepcopy(b)
            t = changed['positions'][0]['protection111']['first_narrowing']
            if mode == '未来':
                t['snapshot']['latest']['available_at'] = 21
            elif mode == 'P改竄':
                t['decision']['p'] = 2
            elif mode == '所有':
                changed['fills'][0]['position_id'] = '他玉'
            else:
                t['snapshot']['latest'] = None
            with self.assertRaises(ValueError):
                A.compare_scene(a, changed, '人工場')

    def test_買売のPは符号反転同一条件(self):
        """機能: 売りは上側pivot越えを同じ支持否定として読む。

        引数: self(TestCase)。返り値: None。
        """
        p = book('T100', [('a', 100, 2)])['positions'][0]
        p['side'] = -1
        p['protection111']['first_narrowing']['snapshot']['latest']['close'] = 120
        self.assertEqual(A.narrow_class(p, 'T100')[0], A.P_GROUPS[0])


def main() -> None:
    """機能: 市場前の人工と所有前後指紋を保存して以後の実診断を同体へ固定する。

    引数: CLIの--stop(Path)は任意の新規停止先。
    返り値: None。失敗時は停止JSONを作らない。
    """
    parser = argparse.ArgumentParser(description='111初狭幅P分類の人工と停止')
    parser.add_argument('--stop', type=Path)
    args = parser.parse_args()
    owned = {str(A.HERE / name): A.sha(A.HERE / name) for name in A.OWN_NAMES}
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(ClassificationTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    A.need(result.wasSuccessful(), '分類人工の失敗')
    A.need(owned == {p: A.sha(Path(p)) for p in owned}, '所有前後変更なし')
    A.need(A.sha(A.BASE_PATH) == A.BASE_SHA, '停止110の比較器不変')
    stop = {'試行': 111, '成功': True, '市場前': True, 'UTC': datetime.now(timezone.utc).isoformat(),
            '主人工': result.testsRun, '所有SHA256': owned, '再用SHA256': {str(A.BASE_PATH): A.BASE_SHA},
            '所有前後同体': True, 'Raw/価格/Native本文読取': False,
            '範囲': '厳密同入口四群・P真偽未知/狭幅なし・C/M/B三値・実現差加法。市場損益実績ではない。'}
    if args.stop:
        A.need(not args.stop.exists(), '停止JSONは新規のみ')
        args.stop.write_text(json.dumps(stop, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '主人工': result.testsRun}, ensure_ascii=False))


if __name__ == '__main__':
    main()
