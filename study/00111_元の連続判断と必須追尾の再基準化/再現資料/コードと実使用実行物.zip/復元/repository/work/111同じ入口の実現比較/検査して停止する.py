"""同じ実入口の比較codeとRoot人工だけを市場前に固定する。"""

import ast
from datetime import datetime, timezone
from pathlib import Path
import subprocess
import sys

import 比較する as C
import 人工検査 as T


def main() -> None:
    """機能: 人工48冊と破壊例を確認して比較codeを一度だけ停止する。

    引数: なし。市場Native・CSV・原板を開かない。
    返り値: None。既存停止を上書きしない。
    """
    target = C.HERE / '停止.json'
    C.need(not target.exists(), '比較停止は新規のみ')
    owned = {str(C.HERE / name): C.digest(C.HERE / name) for name in C.OWNED}
    _, before = C.fixed_dependencies()
    for name in C.OWNED:
        if name.endswith('.py'):
            tree = ast.parse((C.HERE / name).read_text(encoding='utf-8'))
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    doc = ast.get_docstring(node) or ''
                    C.need('\n' in doc and all(s in doc for s in ('機能', '引数', '返り値')), '関数コメント:' + node.name)
    result = subprocess.run([sys.executable, '-X', 'utf8', str(C.HERE / '人工検査.py')],
                            cwd=C.HERE, capture_output=True, text=True, encoding='utf-8', timeout=60)
    C.need(result.returncode == 0, '人工失敗:' + result.stdout + result.stderr)
    directory = C.HERE / '検査'
    directory.mkdir(exist_ok=False)
    (directory / '人工検査.txt').write_text(result.stdout + result.stderr, encoding='utf-8', newline='\n')
    artificial = {name: {'36実現対照': C.compare_scene(value)[0], 'BB8診断': C.compare_scene(value)[1]}
                  for name, value in T.fixtures().items()}
    art_ref = C.write(directory / '人工の実現比較.json', {'試行': 111, '市場': False, '人工48冊の比較': artificial})
    after = {name: C.digest(Path(name)) for name in before}
    C.need(before == after and owned == {name: C.digest(Path(name)) for name in owned}, '全code前後不変')
    proof = {'試行': 111, '成功': True, '市場前': True, '主人工': 5, 'RootCore人工会計': 48,
             '人工結果': art_ref, '前後不変': True, '元code前': before, '元code後': after,
             '実市場Native読取': 0, 'Raw/CSV本文読取': 0, '11月09日本文読取': 0, '市場閾値変更': False}
    check = C.write(directory / '人工確認.json', proof)
    stopped = {'試行': 111, '成功': True, '市場前': True, '日時UTC': datetime.now(timezone.utc).isoformat(),
               '所有ファイルSHA256': owned, '依存停止': C.DEPENDENCIES, '人工確認': check,
               '主人工': 5, 'RootCore人工会計': 48, '36対照': True, '前後不変': True,
               '実市場Native読取': 0, 'Raw/CSV本文読取': 0, '11月09日本文読取': 0,
               '市場閾値変更': False, '採用': False, '研究目標達成': False}
    ref = C.write(target, stopped)
    print(__import__('json').dumps({'成功': True, '停止': ref}, ensure_ascii=True))


if __name__ == '__main__':
    main()
