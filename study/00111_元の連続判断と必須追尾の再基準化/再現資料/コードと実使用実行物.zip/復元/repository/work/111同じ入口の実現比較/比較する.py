"""成立した実玉を同じ入口で対応づけ、実現収支の差だけを分解する。"""

import argparse
from collections import Counter
from datetime import date, timedelta
from decimal import Decimal
import gzip
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
POLICIES = ('S0', 'U100', 'W100', 'T100', 'B100', 'B50')
KEYS = tuple(f'{p}_C{c}_D{d}' for p in POLICIES for c in (0, 5) for d in (0, 1))
PAIRS = tuple([('S0', p) for p in POLICIES[1:]] +
              [('U100', 'W100'), ('W100', 'T100'), ('T100', 'B100'), ('B100', 'B50')])
OWNED = ('比較する.py', '人工検査.py', '検査して停止する.py', 'README.md')
DEPENDENCIES = {
    'Core': {'path': str(ROOT / 'work/111連続Sourceと可変保護の接続/停止.json'),
             'sha256': '87104939274e592ec18cd621b048c5e690eb23336ef390e382f2f32a3a9b8dd5'},
    '保存': {'path': str(ROOT / 'work/111連続保護の独立保存/検査_停止版/停止.json'),
             'sha256': '299e3c146b9d386d8faf7fcd58fcf795c7e692f57c81eb54fc56a439fc251348'},
    'P': {'path': str(ROOT / 'work/111連続保護の独立保存/P停止.json'),
          'sha256': 'c39c6da7577a7cbbb371b048f2da5b0ac3f4e296d95500f895b91bd1c42dd297'}}
ART = {'path': str(ROOT / 'work/111連続Sourceと可変保護の接続/人工_独立保存用/人工.json'),
       'sha256': 'bf51bebe5fe0b67cd39deb18b1f88da6164b513d0a87ea53ab77197b0423cc48'}


def need(value: bool, label: str) -> None:
    """機能: 不整合を完成へ補わず拒否する。

    引数: value(bool)、label(str)は条件と検査名。
    返り値: None。不成立はValueError。
    """
    if not value:
        raise ValueError(label)


def digest(path: Path) -> str:
    """機能: 明示参照の全bytes指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict:
    """機能: 明示JSONをDecimalで読み非有限値を拒否する。

    引数: path(Path)は認証済み参照。
    返り値: dictは保存値。
    """
    opener = gzip.open if path.suffix == '.gz' else open
    with opener(path, 'rt', encoding='utf-8-sig') as stream:
        return json.load(stream, parse_float=Decimal, parse_constant=reject_constant)


def reject_constant(value: str) -> None:
    """機能: 非標準の数値定数を拒否する。

    引数: value(str)は非有限定数。
    返り値: None。必ずValueError。
    """
    raise ValueError('非有限値: ' + value)


def serial(value: object) -> int | float:
    """機能: 有限DecimalだけをJSON数値へ写す。

    引数: value(object)は直列化対象。
    返り値: int|floatは有限の数値。その他はTypeError。
    """
    if isinstance(value, Decimal) and value.is_finite():
        return int(value) if value == value.to_integral_value() else float(value)
    raise TypeError(type(value).__name__)


def write(path: Path, value: dict) -> dict:
    """機能: UTF-8の新規JSONだけを保存する。

    引数: path(Path)、value(dict)は新規先と保存値。
    返り値: dictは保存FileRef。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, default=serial, allow_nan=False)
        stream.write('\n')
    return {'path': str(path.resolve()), 'sha256': digest(path)}


def reference(ref: dict, before: dict) -> Path:
    """機能: 絶対FileRefを認証して前後台帳へ追加する。

    引数: ref(dict)、before(dict)は期待参照と前指紋。
    返り値: Pathは認証した絶対位置。
    """
    need(set(ref) == {'path', 'sha256'}, 'FileRef集合')
    path = Path(ref['path'])
    need(path.is_absolute() and len(ref['sha256']) == 64, '絶対FileRef')
    path = path.resolve()
    need(digest(path) == ref['sha256'], '現物SHA差:' + str(path))
    need(str(path) not in before or before[str(path)] == ref['sha256'], '同位置の指紋差')
    before[str(path)] = ref['sha256']
    return path


def fixed_dependencies() -> tuple[dict, dict]:
    """機能: 市場前停止3点とその全固定codeを認証する。

    引数: なし。
    返り値: tuple[dict,dict]は停止metadataと前指紋。市場を探索しない。
    """
    before, values = {}, {}
    for key, ref in DEPENDENCIES.items():
        value = load(reference(ref, before))
        need(value['成功'] is True, '依存成功')
        need(value.get('市場前', value.get('停止')) is True, '市場前の依存停止')
        values[key] = value
        for name in ('所有コードSHA256', '全固定コードSHA256', '所有ファイルSHA256',
                     '再用ファイルSHA256', '依存'):
            for path, sha in value.get(name, {}).items():
                target = Path(path)
                if not target.is_absolute():
                    target = ROOT / target
                reference({'path': str(target.resolve()), 'sha256': sha}, before)
    return values, before


def canon(value: object) -> str:
    """機能: 対応づけの構造値を型を保った正準JSONへ写す。

    引数: value(object)は源識別又は実入口。
    返り値: strは比較キー。
    """
    return json.dumps(value, sort_keys=True, separators=(',', ':'), default=serial, allow_nan=False)


def birth_key(position: dict) -> tuple:
    """機能: 同じSource出生に由来する実玉を政策間で識別する。

    引数: position(dict)は実新規約定の所有履歴。
    返り値: tupleは手法・Signal・SourceHoldの結合。入口同体は別検査。
    """
    source = position['source']
    return source['method'], source['signal_id'], position['source_hold_id']


def entry_signature(position: dict) -> dict:
    """機能: 源出生と実新規の原行・方向・量・価格を分けて保持する。

    引数: position(dict)は実玉。
    返り値: dictは完全同体を要求する5項目です。
    """
    return {'Source出生': position['source'], '原行': position['entry_quote'], '方向': position['side'],
            '枚数': position['initial_quantity'], '価格': position['entry_price']}


def positions(book: dict) -> dict:
    """機能: 完結実玉を出生へ結び全純額へ照合する。

    引数: book(dict)は独立保存成功の一口座。
    返り値: dictは出生キー→実玉。未完結・重複は拒否する。
    """
    need(book['complete'] is True and book['finished'] is True and book['failure'] == '', '口座完結')
    out = {}
    for p in book['positions']:
        need(p['quantity'] == p['reserved'] == 0 and p['closed_quantity'] == p['initial_quantity'], '実玉完結')
        need(p['initial_quantity'] > 0 and p['side'] in (-1, 1), '実入口量と方向')
        key = birth_key(p)
        need(key not in out, '同じ源出生へ複数実玉')
        out[key] = p
    need(sum((p['realized_net'] for p in out.values()), Decimal(0)) == book['totals']['net_yen'], '実玉と口座の全純額')
    totals = book['totals']
    need(totals['closed_net_yen'] == totals['net_yen'] and
         totals['entry_quantity'] == totals['close_quantity'] == sum(p['initial_quantity'] for p in out.values()), '全実玉の量と実現完結')
    need(all(totals[name] == 0 for name in ('open_buy', 'open_sell', 'pending_buy', 'pending_sell')), '口座残玉予約0')
    return out


def sign(value: Decimal) -> str:
    """機能: 実現純額を勝ち・負け・同値へ分類する。

    引数: value(Decimal)は実現純額。
    返り値: strは勝/負/同値のいずれか。
    """
    return '勝' if value > 0 else '負' if value < 0 else '同値'


def empty_group() -> dict:
    """機能: 実現差の空集計を0件のまま保持する。

    引数: なし。
    返り値: dictは件数・両金額・差額の0初期値。
    """
    return {'件数': 0, '前枚数': 0, '後枚数': 0, '前実現円': Decimal(0), '後実現円': Decimal(0), '実現差円': Decimal(0)}


def add_group(group: dict, left: dict | None, right: dict | None) -> None:
    """機能: 成立した両実玉又は片側実玉の金額だけを加える。

    引数: group(dict)、left/right(dict|None)は集計先と実玉。
    返り値: None。未参加の仮想利益は作らない。
    """
    a, b = (left['realized_net'] if left else Decimal(0)), (right['realized_net'] if right else Decimal(0))
    group['件数'] += 1
    group['前枚数'] += left['initial_quantity'] if left else 0
    group['後枚数'] += right['initial_quantity'] if right else 0
    group['前実現円'] += a
    group['後実現円'] += b
    group['実現差円'] += b - a


def compare_books(left: dict, right: dict) -> dict:
    """機能: 同入口・入口変更・片側だけの実現差を全純額差へ結合する。

    引数: left/right(dict)は同C/Dの前後口座。
    返り値: dictは同入口9勝負群と非共通の実現額分解。
    """
    for field in ('slip_pts', 'delay_seconds'):
        need(left['config'][field] == right['config'][field], '同じ費用条件内だけの比較')
    a, b = positions(left), positions(right)
    groups = {x + '→' + y: empty_group() for x in ('勝', '負', '同値') for y in ('勝', '負', '同値')}
    changed, left_only, right_only = empty_group(), empty_group(), empty_group()
    flags = Counter()
    for key in sorted(a.keys() | b.keys()):
        l, r = a.get(key), b.get(key)
        if l is None:
            add_group(right_only, None, r)
        elif r is None:
            add_group(left_only, l, None)
        else:
            sa, sb = entry_signature(l), entry_signature(r)
            differences = [name for name in sa if canon(sa[name]) != canon(sb[name])]
            if differences:
                add_group(changed, l, r)
                flags.update(differences)
            else:
                add_group(groups[sign(l['realized_net']) + '→' + sign(r['realized_net'])], l, r)
    common = empty_group()
    for group in groups.values():
        for name in common:
            common[name] += group[name]
    delta = right['totals']['net_yen'] - left['totals']['net_yen']
    parts = (common, changed, left_only, right_only)
    need(sum(g['実現差円'] for g in parts) == delta, '全実現差の4区分連結')
    need(sum(g['前実現円'] for g in parts) == left['totals']['net_yen'], '前口座の全玉保持')
    need(sum(g['後実現円'] for g in parts) == right['totals']['net_yen'], '後口座の全玉保持')
    return {'前key': left['key'], '後key': right['key'], '共通玉': common, '共通玉の勝負別': groups,
            '実入口変更': changed, '入口変更項目件数': dict(flags), '前だけ': left_only, '後だけ': right_only,
            '前全純額円': left['totals']['net_yen'], '後全純額円': right['totals']['net_yen'], '全純額差円': delta,
            '全実現差連結': True}


def bb_diagnostics(book: dict) -> dict:
    """機能: 初回狭幅時のBBが警戒成立に必要だった実玉だけを数える。

    引数: book(dict)はB100/B50実口座。
    返り値: dictは件数。収益効果や単独因果とは扱わない。
    """
    out = {'初回狭幅玉数': 0, 'BBが警戒成立に必要な玉数': 0,
           'そのうちC不明': 0, 'そのうちC偽': 0, 'そのうちP不明': 0, 'そのうちP偽': 0}
    for p in book['positions']:
        first = (p.get('protection111') or {}).get('first_narrowing')
        if first is None:
            continue
        d = first['decision']
        need(d['narrowed_now'] is True and d['warning'] == 2, '初回狭幅の警戒真')
        out['初回狭幅玉数'] += 1
        if d['m'] == d['b'] == 2 and d['c'] != 2 and d['p'] != 2:
            out['BBが警戒成立に必要な玉数'] += 1
            out['そのうちC不明'] += d['c'] == 0
            out['そのうちC偽'] += d['c'] == 1
            out['そのうちP不明'] += d['p'] == 0
            out['そのうちP偽'] += d['p'] == 1
    return out


def compare_scene(value: dict) -> tuple[list, list]:
    """機能: 当場の全24冊から36実現対照とBB警戒件数を作る。

    引数: value(dict)は認証後のCore Native。
    返り値: tuple[list,list]は比較36行とBB8行。
    """
    actual = value['actual']
    need(actual['complete'] is True and value['S0_equal'] is True and value['S0_comparisons'] == 4, 'Core完結とS0四比較')
    books = actual['books']
    need(set(books) == set(KEYS), '全24の実口座集合')
    for policy in POLICIES:
        for cost in (0, 5):
            for delay in (0, 1):
                key = f'{policy}_C{cost}_D{delay}'
                need(books[key]['key'] == key and books[key]['config'] ==
                     {'policy': policy, 'slip_pts': cost, 'delay_seconds': delay}, '実口座keyと費用宣言')
    rows, bb = [], []
    sid = actual['scope']['session']['id']
    for c in (0, 5):
        for d in (0, 1):
            for a, b in PAIRS:
                rows.append({'session': sid, **compare_books(books[f'{a}_C{c}_D{d}'], books[f'{b}_C{c}_D{d}'])})
            for p in ('B100', 'B50'):
                key = f'{p}_C{c}_D{d}'
                bb.append({'session': sid, 'key': key, **bb_diagnostics(books[key])})
    return rows, bb


def sessions(stage: str) -> list[str]:
    """機能: 既使用first2/base54/full70の予定集合を固定列挙する。

    引数: stage(str)は段階。
    返り値: list[str]は元順序。11/09は含めない。
    """
    need(stage in ('first2', 'base54', 'full70'), 'stage')
    end = date(2026, 9, 21) if stage == 'first2' else date(2026, 10, 27) if stage == 'base54' else date(2026, 11, 6)
    day, out = date(2026, 9, 21), []
    while day <= end:
        if day.weekday() < 5:
            out += [f'{day.isoformat()}_{kind}' for kind in ('Day', 'Night')]
        day += timedelta(days=1)
    need(len(out) == {'first2': 2, 'base54': 54, 'full70': 70}[stage], '予定場数')
    return out


def prepare(fixed_path: Path, sha: str, output: Path) -> tuple:
    """機能: 新しいRoot解禁・独立保存成功・全Nativeを本文解析前に認証する。

    引数: fixed_path/output(Path)、sha(str)はRoot要求・新規先・期待SHA。
    返り値: tupleは要求・元完了・独立保存結果・前指紋。
    """
    need(not output.exists(), '比較出力は新規先')
    deps, before = fixed_dependencies()
    request = load(reference({'path': str(fixed_path), 'sha256': sha}, before))
    need(request['version'] == 1 and request['trial'] == 111 and request['fixed'] is True and
         request['market_native_read_authorized'] is True, 'Rootの新しい本文解禁要求が必要')
    stop = load(reference(request['comparison_stop'], before))
    need(stop['試行'] == 111 and stop['成功'] is True and stop['市場前'] is True, '比較の市場前停止')
    need(stop['依存停止'] == DEPENDENCIES, '比較の依存停止集合')
    codes = stop['所有ファイルSHA256']
    need(set(codes) == {str(HERE / name) for name in OWNED}, '比較所有code集合')
    for name, s in codes.items():
        reference({'path': name, 'sha256': s}, before)
    condition = load(reference(request['condition'], before))
    complete = load(reference(request['completion'], before))
    saved = load(reference(request['saved_result'], before))
    checked = load(reference(request['saved_check'], before))
    expected = sessions(request['stage'])
    n = len(expected)
    need(condition['trial'] == 111 and condition['fixed'] is True, '元市場条件')
    for name, s in deps['Core']['全固定コードSHA256'].items():
        need(condition['code_sha256'].get(name) == s, '元固定Core code同体')
    need(complete['trial'] == 111 and complete['success'] is True and complete['stage'] == request['stage']
         and complete['sessions'] == n and complete['books'] == 24 * n and complete['unchanged'] is True
         and complete['before'] == complete['after'] and complete['condition_sha256'] == request['condition']['sha256'],
         '同stage全金融成功')
    need(complete['all_original166_reference_events_equal'] is True and
         complete['historical_saved_events_equal'] is False and complete['all_original_signal_full_json_equal'] is False, '元Event対照範囲')
    for item in (saved, checked):
        need(item['試行'] == 111 and item['成功'] is True and item['stage'] == request['stage'] and
             item['場数'] == n and item['会計数'] == 24 * n and item['前後不変'] is True, '同stage独立保存成功')
        need(item['金融完了SHA256'] == request['completion']['sha256'] and
             item['金融条件SHA256'] == request['condition']['sha256'] and
             item['保存器停止SHA256'] == DEPENDENCIES['保存']['sha256'] and
             item['純保護監査停止SHA256'] == DEPENDENCIES['P']['sha256'], '同じ金融と独立監査')
    need(checked['出力SHA256']['結果.json'] == request['saved_result']['sha256'], '独立保存の結果現物')
    need(checked['全残玉予約0'] is True and checked['不一致数'] == 0, '独立保存の全残0')
    need([r['session'] for r in complete['results']] == expected, '予定全場順')
    need([r['session'] for r in saved['Native参照']] == expected, '独立保存の全場Native')
    for a, b in zip(complete['results'], saved['Native参照']):
        need(a['native'] == {'path': b['path'], 'sha256': b['sha256']}, '金融と独立保存のNative同体')
        need(a['books'] == 24 and a['complete'] is True and a['S0_equal'] is True and
             a['S0_comparisons'] == 4 and a['open_quantity'] == a['pending_quantity'] == 0, '各場24完結')
        reference(a['native'], before)
    need(len(saved['主key']) == 24 and set(saved['主key']) == set(KEYS) and len(saved['場別']) == 24 * n and
         {(r['session'], r['key']) for r in saved['場別']} == {(sid, key) for sid in expected for key in KEYS}, '独立保存全24行')
    return request, complete, saved, before


def aggregate(rows: list[dict]) -> list[dict]:
    """機能: 場別の全実現差分解を36対照へ加算する。

    引数: rows(list[dict])は場別対照。
    返り値: list[dict]は群別・全体とも差額照合した36対照。
    """
    out = {}
    for row in rows:
        key = (row['前key'], row['後key'])
        if key not in out:
            out[key] = {'前key': key[0], '後key': key[1], '場数': 0,
                        **{name: empty_group() for name in ('共通玉', '実入口変更', '前だけ', '後だけ')},
                        '共通玉の勝負別': {name: empty_group() for name in row['共通玉の勝負別']},
                        '入口変更項目件数': Counter(), '前全純額円': Decimal(0), '後全純額円': Decimal(0), '全純額差円': Decimal(0)}
        target = out[key]
        target['場数'] += 1
        for name in ('共通玉', '実入口変更', '前だけ', '後だけ'):
            for field, value in row[name].items():
                target[name][field] += value
        for name, group in row['共通玉の勝負別'].items():
            for field, value in group.items():
                target['共通玉の勝負別'][name][field] += value
        target['入口変更項目件数'].update(row['入口変更項目件数'])
        for name in ('前全純額円', '後全純額円', '全純額差円'):
            target[name] += row[name]
    for target in out.values():
        need(sum(target[n]['実現差円'] for n in ('共通玉', '実入口変更', '前だけ', '後だけ')) == target['全純額差円'], '集計後の実現差連結')
    return list(out.values())


def run(fixed_path: Path, sha: str, output: Path) -> dict:
    """機能: 解禁後の全Nativeだけを読み実現差分解を新規保存する。

    引数: fixed_path/output(Path)、sha(str)は新Root要求・未使用先・SHA。
    返り値: dictは成功と対照数。閾値や元codeを変更しない。
    """
    request, complete, saved, before = prepare(fixed_path, sha, output)
    rows, bb = [], []
    financial = {(r['session'], r['key']): r['net_yen'] for r in saved['場別']}
    for scene in complete['results']:
        value = load(Path(scene['native']['path']))
        need(value['actual']['scope']['session']['id'] == scene['session'], 'Nativeと成功参照の場')
        compared, diagnostics = compare_scene(value)
        for row in compared:
            need(row['前全純額円'] == financial[(scene['session'], row['前key'])] and
                 row['後全純額円'] == financial[(scene['session'], row['後key'])], '独立保存の実現純額と照合')
        rows += compared
        bb += diagnostics
    after = {name: digest(Path(name)) for name in before}
    need(before == after, '全参照とcode前後不変')
    summary = aggregate(rows)
    need(len(summary) == 36 and len(rows) == 36 * len(complete['results']), '36対照×全場保持')
    output.mkdir(parents=True, exist_ok=False)
    result = {'試行': 111, '成功': True, 'stage': request['stage'], '場数': len(complete['results']),
              '全対照数': len(rows), '集計': summary, '場別': rows, 'BB警戒成立の内訳': bb,
              '比較要求SHA256': sha, '元金融完了SHA256': request['completion']['sha256'],
              '独立保存結果SHA256': request['saved_result']['sha256'], '前後不変': True, 'before': before, 'after': after,
              '解釈': ['同じ実新規の源出生・原行・方向・枚数・価格が全て同体の玉だけを共通玉とする。',
                       '片側だけの玉も実現額を分解する。未参加や退出後の仮想利益・機会損失ではない。',
                       'U100→W100は起動会計と全玉床の複合変更。B100→B50はHだけの条件差。',
                       'BB件数はM真・B真・C/Pがそれぞれ真でない初回狭幅。unknownはfalseと区別する。単独収益効果や因果ではない。'],
              '市場閾値変更': False, '採用': False, '研究目標達成': False}
    ref = write(output / '結果.json', result)
    return {'成功': True, '場数': result['場数'], '対照数': len(rows), '結果': ref}


def main() -> None:
    """機能: Rootが後段で固定した新しい解禁要求だけを実行する。

    引数: CLI fixed/sha256/output(str)は要求・SHA・新規先。
    返り値: None。成功Refのみ標準出力へ返す。
    """
    parser = argparse.ArgumentParser(description='111同じ実入口の実現収支比較')
    parser.add_argument('--fixed', required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    print(json.dumps(run(Path(args.fixed).resolve(), args.sha256, Path(args.output).resolve()), ensure_ascii=False))


if __name__ == '__main__':
    main()
