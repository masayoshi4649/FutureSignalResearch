"""Rootが解禁した手製48冊と小metadataだけで実現差連結を検査する。"""

from copy import deepcopy
from decimal import Decimal
from pathlib import Path
import tempfile
import unittest

import 比較する as C


def fixtures() -> dict:
    """機能: RootCoreの認証済み人工48冊だけを読む。

    引数: なし。
    返り値: dictは買い・売りの手製値。市場Nativeは探索しない。
    """
    before = {}
    manifest = C.load(C.reference(C.ART, before))
    C.need(manifest['market_data'] is False and manifest['natural_FAR_signal'] is False
           and manifest['books'] == 48, 'Root人工の範囲')
    return {name: C.load(C.reference(ref, before)) for name, ref in manifest['references'].items()}


def manufactured_book(template: dict, policy: str, values: list[tuple]) -> dict:
    """機能: 比較算法の算術専用に実型の手製完結玉を作る。

    引数: template(dict)、policy(str)、values(list[tuple])は雛形・政策・ID/実現額列。
    返り値: dictは比較だけの人工。元会計で有効な市場成績とは主張しない。
    """
    book = deepcopy(template)
    book['config']['policy'] = policy
    book['key'] = policy + '_C0_D0'
    prototype = deepcopy(template['positions'][0])
    book['positions'] = []
    for label, net in values:
        p = deepcopy(prototype)
        p['id'] = label
        p['source']['signal_id'] = label
        p['source_hold_id'] = label
        p['realized_net'] = Decimal(net)
        book['positions'].append(p)
    book['totals']['net_yen'] = sum((p['realized_net'] for p in book['positions']), Decimal(0))
    book['totals']['closed_net_yen'] = book['totals']['net_yen']
    book['totals']['entry_quantity'] = book['totals']['close_quantity'] = sum(p['initial_quantity'] for p in book['positions'])
    return book


def gate_fixture(base: Path) -> tuple[dict, dict]:
    """機能: 金融本文を解析しないfirst2成功参照の手製集合を作る。

    引数: base(Path)は隔離先。
    返り値: tuple[dict,dict]は比較要求Refと手製要求。
    """
    base.mkdir()
    deps, _ = C.fixed_dependencies()
    codes = deps['Core']['全固定コードSHA256']
    condition = C.write(base / '条件.json', {'trial': 111, 'fixed': True, 'code_sha256': codes})
    rows, refs, natives = [], [], []
    for sid in C.sessions('first2'):
        ref = C.write(base / (sid + '.Native.json.gz'), {'手製metadataのみ': True, '金融Native': False})
        rows.append({'session': sid, 'native': ref, 'books': 24, 'complete': True, 'S0_equal': True,
                     'S0_comparisons': 4, 'open_quantity': 0, 'pending_quantity': 0})
        refs.append({'session': sid, **ref})
        natives.extend({'session': sid, 'key': key, 'net_yen': 0} for key in C.KEYS)
    complete = C.write(base / '完了metadata.json', {'trial': 111, 'success': True, 'stage': 'first2', 'sessions': 2,
                      'books': 48, 'unchanged': True, 'before': codes, 'after': codes, 'condition_sha256': condition['sha256'],
                      'all_original166_reference_events_equal': True, 'historical_saved_events_equal': False,
                      'all_original_signal_full_json_equal': False, 'results': rows})
    common = {'試行': 111, '成功': True, 'stage': 'first2', '場数': 2, '会計数': 48, '前後不変': True,
              '金融完了SHA256': complete['sha256'], '金融条件SHA256': condition['sha256'],
              '保存器停止SHA256': C.DEPENDENCIES['保存']['sha256'], '純保護監査停止SHA256': C.DEPENDENCIES['P']['sha256']}
    saved = C.write(base / '保存結果metadata.json', {**common, 'Native参照': refs, '主key': list(C.KEYS), '場別': natives})
    checked = C.write(base / '保存確認metadata.json', {**common, '全残玉予約0': True, '不一致数': 0,
                      '出力SHA256': {'結果.json': saved['sha256']}})
    stopped = C.write(base / '比較停止metadata.json', {'試行': 111, '成功': True, '市場前': True, '依存停止': C.DEPENDENCIES,
                      '所有ファイルSHA256': {str(C.HERE / name): C.digest(C.HERE / name) for name in C.OWNED}})
    request = {'version': 1, 'trial': 111, 'fixed': True, 'market_native_read_authorized': True, 'stage': 'first2',
               'comparison_stop': stopped, 'condition': condition, 'completion': complete, 'saved_result': saved, 'saved_check': checked}
    return C.write(base / '比較要求.json', request), request


class RealizedComparisonTests(unittest.TestCase):
    """同じ実入口の算術と成功参照gateを人工だけで検査する。"""

    @classmethod
    def setUpClass(cls) -> None:
        """機能: 認証した買売人工48冊を一度だけ準備する。

        引数: cls(type)は検査クラス。
        返り値: None。
        """
        cls.values = fixtures()

    def test_root_48_and_buy_sell_symmetry(self) -> None:
        """機能: 実取引のある48冊で36対照と売買対応を検査する。

        引数: self(RealizedComparisonTests)は検査器。
        返り値: None。自然FARや市場の成績とは扱わない。
        """
        buy, bb_buy = C.compare_scene(self.values['買い'])
        sell, bb_sell = C.compare_scene(self.values['売り'])
        self.assertEqual(len(buy), 36)
        self.assertEqual(len(bb_buy), 8)
        self.assertEqual(buy, sell)
        self.assertEqual(bb_buy, bb_sell)
        self.assertTrue(all(r['共通玉']['件数'] == 1 and r['共通玉']['前枚数'] == 2 for r in buy))
        combined = C.aggregate(buy + sell)
        self.assertEqual(len(combined), 36)
        self.assertTrue(all(r['場数'] == 2 for r in combined))

    def test_nine_outcomes_changed_and_one_sided(self) -> None:
        """機能: 9勝負群・入口変更・片側実玉を手計算の全差額72円へ結ぶ。

        引数: self(RealizedComparisonTests)は検査器。
        返り値: None。片側玉は実現額を使い仮想利益を作らない。
        """
        template = self.values['買い']['actual']['books']['S0_C0_D0']
        a, b = [], []
        for i, left in enumerate((-10, 0, 10)):
            for j, right in enumerate((-20, 0, 20)):
                a.append((f'共通{i}{j}', left))
                b.append((f'共通{i}{j}', right))
        left = manufactured_book(template, 'S0', a + [('入口変更', 5), ('前だけ', -30)])
        right = manufactured_book(template, 'W100', b + [('入口変更', 7), ('後だけ', 40)])
        changed = next(p for p in right['positions'] if p['id'] == '入口変更')
        changed['initial_quantity'] = changed['closed_quantity'] = 3
        changed['entry_price'] += 5
        right['totals']['entry_quantity'] = right['totals']['close_quantity'] = sum(p['initial_quantity'] for p in right['positions'])
        row = C.compare_books(left, right)
        self.assertEqual(row['共通玉']['件数'], 9)
        self.assertEqual(row['共通玉']['前枚数'], 18)
        self.assertTrue(all(g['件数'] == 1 for g in row['共通玉の勝負別'].values()))
        self.assertEqual(row['実入口変更']['実現差円'], 2)
        self.assertEqual(row['入口変更項目件数'], {'枚数': 1, '価格': 1})
        self.assertEqual(row['前だけ']['実現差円'], 30)
        self.assertEqual(row['後だけ']['実現差円'], 40)
        self.assertEqual(row['全純額差円'], 72)

    def test_birth_row_side_and_empty_cases(self) -> None:
        """機能: 原行/方向/Source出生の変更と全0取引を混同しない。

        引数: self(RealizedComparisonTests)は検査器。
        返り値: None。
        """
        template = self.values['買い']['actual']['books']['S0_C0_D0']
        left = manufactured_book(template, 'S0', [('対象', 10)])
        right = manufactured_book(template, 'W100', [('対象', 20)])
        right['positions'][0]['source']['birth_time'] += 1
        right['positions'][0]['entry_quote']['index'] += 1
        right['positions'][0]['side'] *= -1
        row = C.compare_books(left, right)
        self.assertEqual(row['共通玉']['件数'], 0)
        self.assertEqual(row['入口変更項目件数'], {'Source出生': 1, '原行': 1, '方向': 1})
        empty = C.compare_books(manufactured_book(template, 'S0', []), manufactured_book(template, 'W100', []))
        self.assertEqual(empty['全純額差円'], 0)
        self.assertTrue(all(g['件数'] == 0 for g in empty['共通玉の勝負別'].values()))
        bad = deepcopy(left)
        bad['positions'][0]['quantity'] = 1
        with self.assertRaises(ValueError):
            C.compare_books(bad, right)

    def test_bb_required_uses_or_with_unknown_separate(self) -> None:
        """機能: M∧(C∨P∨B)でBBが必要な警戒だけを数える。

        引数: self(RealizedComparisonTests)は検査器。
        返り値: None。収益効果や単独因果の件数ではない。
        """
        template = self.values['買い']['actual']['books']['S0_C0_D0']
        book = manufactured_book(template, 'B100', [(str(i), 0) for i in range(4)])
        for p, (c, structural) in zip(book['positions'], ((0, 1), (1, 0), (2, 1), (1, 2))):
            p['protection111'] = {'first_narrowing': {'decision': {'m': 2, 'b': 2, 'c': c, 'p': structural,
                                                                  'warning': 2, 'narrowed_now': True}}}
        row = C.bb_diagnostics(book)
        self.assertEqual(row['初回狭幅玉数'], 4)
        self.assertEqual(row['BBが警戒成立に必要な玉数'], 2)
        for name in ('そのうちC不明', 'そのうちC偽', 'そのうちP不明', 'そのうちP偽'):
            self.assertEqual(row[name], 1)

    def test_success_gate_metadata_only(self) -> None:
        """機能: 新Root解禁・自己停止・独立成功・全場の破壊を本文前に拒否する。

        引数: self(RealizedComparisonTests)は検査器。
        返り値: None。手製Native metadataの金融解析を行わない。
        """
        with tempfile.TemporaryDirectory() as folder:
            base = Path(folder) / '人工'
            ref, request = gate_fixture(base)
            out = base / '未作成出力'
            _, complete, _, before = C.prepare(Path(ref['path']), ref['sha256'], out)
            self.assertEqual(len(complete['results']), 2)
            self.assertFalse(out.exists())
            self.assertEqual(before, {name: C.digest(Path(name)) for name in before})
            for name in ('解禁なし', '未固定', '誤stage', '自己停止なし', '保存SHA差'):
                bad = deepcopy(request)
                if name == '解禁なし':
                    bad['market_native_read_authorized'] = False
                elif name == '未固定':
                    bad['fixed'] = False
                elif name == '誤stage':
                    bad['stage'] = 'full70'
                elif name == '自己停止なし':
                    bad['comparison_stop']['sha256'] = '0' * 64
                else:
                    bad['saved_result']['sha256'] = '0' * 64
                badref = C.write(base / (name + '.json'), bad)
                with self.subTest(name=name), self.assertRaises(ValueError):
                    C.prepare(Path(badref['path']), badref['sha256'], out)
            out.mkdir()
            with self.assertRaises(ValueError):
                C.prepare(Path(ref['path']), ref['sha256'], out)


if __name__ == '__main__':
    unittest.main(verbosity=2)
