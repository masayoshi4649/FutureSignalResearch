"""金融成功と独立保存成功を同入口の実現比較へ限定して解禁する。"""

import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def reference(path: str | Path, expected: str) -> dict:
    """機能: 明示した小metadataの絶対位置と指紋を認証する。

    引数: path(str|Path)、expected(str)は対象と期待SHA。
    返り値: dictは絶対FileRef。現物差は例外。
    """
    absolute = Path(path).resolve()
    if hashlib.sha256(absolute.read_bytes()).hexdigest() != expected:
        raise ValueError("比較の明示参照差: " + str(absolute))
    return {"path": str(absolute), "sha256": expected}


def main() -> None:
    """機能: 同じstageの金融・保存成功から新規の比較要求を作る。

    引数: CLIはcondition/completion/saved-result/saved-checkのpath/SHAとoutput。
    返り値: None。Native・Raw・価格CSVを開かず要求だけ固定する。
    """
    parser = argparse.ArgumentParser()
    for name in ("condition", "completion", "saved-result", "saved-check"):
        parser.add_argument("--" + name, required=True)
        parser.add_argument("--" + name + "-sha256", required=True)
    parser.add_argument("--output", required=True)
    args = vars(parser.parse_args())
    refs = {name: reference(args[name], args[name + "_sha256"]) for name in ("condition", "completion", "saved_result", "saved_check")}
    values = {key: json.loads(Path(ref["path"]).read_text(encoding="utf-8")) for key, ref in refs.items()}
    completed, saved, checked = values["completion"], values["saved_result"], values["saved_check"]
    stage = completed["stage"]
    if not completed["success"] or not saved["成功"] or not checked["成功"] or saved["stage"] != stage or checked["stage"] != stage:
        raise ValueError("同stageの金融・独立保存成功が必要")
    if completed["condition_sha256"] != refs["condition"]["sha256"]:
        raise ValueError("同条件ではない")
    stop = reference(ROOT / "work/111同じ入口の実現比較/停止.json", "7b4b670489753639d030d5ba2eba5786d4749b571981483cb8f4e61bedf9bf77")
    request = {"version": 1, "trial": 111, "fixed": True, "market_native_read_authorized": True,
               "stage": stage, "comparison_stop": stop, **refs}
    output = Path(args["output"]).resolve()
    with output.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(request, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"path": str(output), "sha256": hashlib.sha256(output.read_bytes()).hexdigest(), "stage": stage}, ensure_ascii=False))


if __name__ == "__main__":
    main()
