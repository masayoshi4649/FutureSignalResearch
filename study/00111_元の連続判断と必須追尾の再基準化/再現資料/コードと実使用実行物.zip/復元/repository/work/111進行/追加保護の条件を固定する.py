"""停止済み24政策と元手法の再実行参照を市場前の金融条件に結ぶ。"""

import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
STOPS = {
    "source": ("111元時計の連続再現", "08b1331b372d5cd7e50d46d90c247a8fa9c6a9bf657105ff181928041f156946"),
    "actor": ("111元通知の連続Actor", "6503962ebb7189213a182f8801916e99503ddfa88d0a99426107f3755535cbf2"),
    "chart": ("111連続保護のチャート公開", "38c01e07d276310c6c1d803dca11e27979fc9286cf64d9a495e60485ea7264bd"),
    "pure": ("111全玉利益と収束BBの純保護", "0042a6dc3f181150609deeca5b2c095c9f553d69fcaab1d833402ae31fdbc2c4"),
}


def digest(path: Path) -> str:
    """機能: 明示ファイルの全バイト指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_ref(ref: dict) -> dict | list:
    """機能: 指紋を確認した小metadataを復元する。

    引数: ref(dict)は絶対pathとsha256。
    返り値: dict|listは認証済みJSON。差は例外。
    """
    path = Path(ref["path"])
    if not path.is_absolute() or digest(path) != ref["sha256"]:
        raise ValueError("明示参照の現物差: " + str(path))
    return json.loads(path.read_text(encoding="utf-8"))


def merge_code(target: dict, values: dict) -> None:
    """機能: 停止コードを絶対位置へ統一して既固定mapへ追加する。

    引数: target(dict)、values(dict)は統合先と追加指紋。
    返り値: None。指紋衝突や現物差は例外。
    """
    for name, expected in values.items():
        path = Path(name)
        path = (path if path.is_absolute() else ROOT / path).resolve()
        if digest(path) != expected or (str(path) in target and target[str(path)] != expected):
            raise ValueError("全コードの現物差又は衝突: " + str(path))
        target[str(path)] = expected


def main() -> None:
    """機能: 24実宣言・四部品停止・原文参照を新規の条件へ固定する。

    引数: CLIはoracle-completion/sha256/output、任意のprior-first2/sha。
    返り値: None。原板・未見11/09は開かず、既存条件は変更しない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--oracle-completion", required=True)
    parser.add_argument("--oracle-sha256", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--prior-first2")
    parser.add_argument("--prior-first2-sha256")
    args = parser.parse_args()
    baseline_ref = {"path": str((ROOT / "work/111元手法基準の実行条件/H1_原文oracle前の固定.json").resolve()), "sha256": "46e1c16803e93b75c5580b1f67d61a687d1db0068f5c91f6e17374bb9e7dc05e"}
    baseline = read_ref(baseline_ref)
    completion_ref = {"path": str(Path(args.oracle_completion).resolve()), "sha256": args.oracle_sha256}
    oracle = read_ref(completion_ref)
    if not oracle["success"] or not oracle["unchanged"] or oracle["condition_sha256"] != baseline_ref["sha256"]:
        raise ValueError("H1の原文再実行成功ではない")
    if oracle["kind"] != "rerun_original166_pinned_code" or oracle["historical_saved_event_equality"] or oracle["all_signal_full_json_equal"]:
        raise ValueError("当時記録との区別差")
    if oracle["stage"] not in ("first2", "original54") or len(oracle["results"]) not in (2, 54):
        raise ValueError("元対照の範囲差")
    runtime_ref = {"path": str((ROOT / "work/111連続Sourceと可変保護の接続/停止.json").resolve()), "sha256": "87104939274e592ec18cd621b048c5e690eb23336ef390e382f2f32a3a9b8dd5"}
    runtime = read_ref(runtime_ref)
    if not runtime["成功"] or not runtime["停止"] or not runtime["自己コード全依存前後不変"]:
        raise ValueError("24会計の接続が未停止")
    code = dict(baseline["code_sha256"])
    merge_code(code, runtime["全固定コードSHA256"])
    merge_code(code, runtime["所有コードSHA256"])
    stop_refs, parts = {}, {}
    for key, (folder, expected) in STOPS.items():
        ref = {"path": str((ROOT / "work" / folder / "停止.json").resolve()), "sha256": expected}
        stop_refs[key] = ref
        parts[key] = read_ref(ref)
    actual_ref, pure_ref, chart_ref = parts["actor"]["実宣言"], parts["pure"]["実宣言"], parts["chart"]["実API宣言"]
    actual, pure = read_ref(actual_ref), read_ref(pure_ref)["configurations"]
    read_ref(chart_ref)
    if len(actual) != 24 or len(pure) != 24:
        raise ValueError("実宣言24が必要")
    for ref in oracle["results"].values():
        read_ref(ref)
    if digest(Path(runtime["実行物"]["path"])) != runtime["実行物"]["sha256"]:
        raise ValueError("接続exeの現物差")
    baseline.update({
        "executable": runtime["実行物"], "code_sha256": code,
        "original166_references": oracle["results"],
        "actual_policy": "original166_continuous_24books_mandatory_protection",
        "chart_seed_mode": "cold_each_session", "entry_grid_seconds": None,
        "extra_opening_quiet_seconds": 0,
        "actual_configurations": actual, "pure_configurations": pure,
        "dependency_stops": stop_refs,
        "actual_declaration": actual_ref, "pure_declaration": pure_ref, "chart_declaration": chart_ref,
        "runtime_stop": runtime_ref,
        "derivation": {"baseline": baseline_ref, "oracle_completion": completion_ref, "scope": "元166の連続判断と同一24実宣言。二対照から54対照への追加は比較参照だけの派生"},
    })
    if bool(args.prior_first2) != bool(args.prior_first2_sha256):
        raise ValueError("先頭2条件は位置と指紋が必要")
    if args.prior_first2:
        prior_ref = {"path": str(Path(args.prior_first2).resolve()), "sha256": args.prior_first2_sha256}
        prior = read_ref(prior_ref)
        for key in baseline:
            if key not in ("original166_references", "derivation") and baseline[key] != prior[key]:
                raise ValueError("比較参照以外の金融条件差: " + key)
        baseline["derivation"]["prior_first2_condition"] = prior_ref
    output = Path(args.output).resolve()
    with output.open("x", encoding="utf-8") as file:
        file.write(json.dumps(baseline, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"path": str(output), "sha256": digest(output), "実宣言": len(actual), "全コード": len(code), "元対照": len(oracle["results"])}, ensure_ascii=False))


if __name__ == "__main__":
    main()
