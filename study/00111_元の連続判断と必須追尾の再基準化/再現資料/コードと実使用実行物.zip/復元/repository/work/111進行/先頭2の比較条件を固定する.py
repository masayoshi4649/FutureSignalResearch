"""原文oracle先頭2の成功参照だけをH1へ接続する。売買条件は変更しない。"""

import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def digest(path: Path) -> str:
    """機能: 明示ファイルの全バイト指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify(path: Path, expected: str) -> dict:
    """機能: 小JSONの期待指紋を確認して復元する。

    引数: path(Path)、expected(str)は参照と期待SHA。
    返り値: dictは認証済みJSON。差は例外。
    """
    if digest(path) != expected:
        raise ValueError("参照差: " + str(path))
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> None:
    """機能: H1と原文再実行成功2参照からH2を新規固定する。

    引数: なし。原板・未見市場は開かない。
    返り値: None。参照追加・薄いCLI以外は同じ元算法。
    """
    base_path = ROOT / "work/111元手法基準の実行条件/H1_原文oracle前の固定.json"
    base_sha = "46e1c16803e93b75c5580b1f67d61a687d1db0068f5c91f6e17374bb9e7dc05e"
    base = verify(base_path, base_sha)
    completed_path = ROOT / "work/111原文oracle/先頭2場/完了.json"
    completed_sha = "234998444170d38c4518aead418fda06af5ee617473a5efe1279cae473dbc6fa"
    done = verify(completed_path, completed_sha)
    if not done["success"] or not done["unchanged"] or done["sessions"] != 2 or done["condition_sha256"] != base_sha:
        raise ValueError("H1の先頭2成功ではない")
    if done["kind"] != "rerun_original166_pinned_code" or done["historical_saved_event_equality"] or done["all_signal_full_json_equal"]:
        raise ValueError("原文再実行と当時記録の区別差")
    thin_path = ROOT / "work/111先頭2の元対照接続/停止.json"
    thin_sha = "b74d50a519694411ef17a044d33ca654f14e3c4b85091fc3048373b923031c97"
    thin = verify(thin_path, thin_sha)
    code = dict(base["code_sha256"])
    for key in ("所有コードSHA256", "Go閉包SHA256", "GoRootコードSHA256"):
        for name, expected in thin.get(key, {}).items():
            path = Path(name)
            path = (path if path.is_absolute() else ROOT / path).resolve()
            if digest(path) != expected:
                raise ValueError("薄いCLIコード現物差")
            if str(path) in code and code[str(path)] != expected:
                raise ValueError("既固定コードとの衝突")
            code[str(path)] = expected
    exe = ROOT / "work/111先頭2の元対照接続/検査/111先頭2元対照.exe"
    exe_sha = "5cac8fa71300b23ecc253534ce8c3c494b0b38edd289e463b5eed5263eeed249"
    if digest(exe) != exe_sha:
        raise ValueError("薄いCLI実物差")
    for ref in done["results"].values():
        if digest(Path(ref["path"])) != ref["sha256"]:
            raise ValueError("元再実行の参照差")
    base["code_sha256"] = code
    base["executable"] = {"path": str(exe.resolve()), "sha256": exe_sha}
    base["original166_references"] = done["results"]
    base["derivation"] = {"base": {"path": str(base_path.resolve()), "sha256": base_sha}, "oracle_completion": {"path": str(completed_path.resolve()), "sha256": completed_sha}, "scope": "比較参照2本と薄い先頭2CLIのみ追加。売買算法・時計・数量・費用は同体"}
    output = HERE / "H2_先頭2の元対照固定.json"
    with output.open("x", encoding="utf-8") as file:
        file.write(json.dumps(base, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"path": str(output.resolve()), "sha256": digest(output), "コード項目": len(code), "元対照": len(done["results"])}, ensure_ascii=False))


if __name__ == "__main__":
    main()
