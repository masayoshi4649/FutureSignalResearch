"""成功済み市場Nativeだけを独立保存器へ解禁するRoot要求を新規作成する。"""

import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def digest(path: Path) -> str:
    """機能: 明示ファイルの全バイト指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reference(path: str | Path, sha: str) -> dict:
    """機能: 小metadata参照を絶対位置と期待指紋で認証する。

    引数: path(str|Path)、sha(str)は対象と期待SHA。
    返り値: dictは絶対FileRef。現物差は例外。
    """
    absolute = Path(path).resolve()
    if digest(absolute) != sha:
        raise ValueError("固定参照の現物差: " + str(absolute))
    return {"path": str(absolute), "sha256": sha}


def load(ref: dict) -> dict:
    """機能: 認証済み小JSONを復元する。

    引数: ref(dict)は認証済みFileRef。
    返り値: dictは小JSON。原板・価格本文は開かない。
    """
    return json.loads(Path(ref["path"]).read_text(encoding="utf-8"))


def main() -> None:
    """機能: 同条件の全場成功とI/O修正停止を保存要求へ結ぶ。

    引数: CLIはcondition/completion/io-stopのpath/SHA、output。
    返り値: None。市場Nativeを解析せず、新規要求を作る。
    """
    parser = argparse.ArgumentParser()
    for name in ("condition", "completion", "io-stop"):
        parser.add_argument("--" + name, required=True)
        parser.add_argument("--" + name + "-sha256", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    condition_ref = reference(args.condition, args.condition_sha256)
    completion_ref = reference(args.completion, args.completion_sha256)
    adapter_ref = reference(args.io_stop, args.io_stop_sha256)
    condition, completion = load(condition_ref), load(completion_ref)
    if not condition["fixed"] or not completion["success"] or not completion["unchanged"]:
        raise ValueError("未固定又は不完了を解禁しない")
    if completion["condition_sha256"] != condition_ref["sha256"] or completion["before"] != completion["after"]:
        raise ValueError("同じ条件の入力前後不変成功ではない")
    size = {"first2": 2, "base54": 54, "full70": 70}[completion["stage"]]
    if completion["trial"] != 111 or completion["sessions"] != size or completion["books"] != 24 * size:
        raise ValueError("予定全24会計の不足")
    manifest_ref = reference(condition["manifest"]["path"], condition["manifest"]["sha256"])
    manifest = load(manifest_ref)
    sessions = manifest["sessions"][:size]
    if [r["session"] for r in completion["results"]] != [s["id"] for s in sessions]:
        raise ValueError("台帳と完了の予定順序差")
    source_root = Path(manifest["source_root"])
    scenes = []
    for row, session in zip(completion["results"], sessions):
        if row["books"] != 24 or row["S0_comparisons"] != 4 or not row["S0_equal"] or not row["complete"] or row["open_quantity"] != 0 or row["pending_quantity"] != 0:
            raise ValueError("場別の全会計・対照・残0失敗")
        scenes.append({"session": row["session"], "native": row["native"],
                       "history_class": "original54" if row["session"][:10] <= "2026-10-27" else "additional16",
                       "market_path": str((source_root / session["files"]["NK225_book"]["path"]).resolve())})
    saving_stop = reference(ROOT / "work/111連続保護の独立保存/検査_停止版/停止.json", "299e3c146b9d386d8faf7fcd58fcf795c7e692f57c81eb54fc56a439fc251348")
    fixed = {"version": 1, "trial": 111, "fixed": True, "market_native_read_authorized": True,
             "stage": completion["stage"], "condition": condition_ref, "completion": completion_ref,
             "code_stop": saving_stop, "io_adapter_stop": adapter_ref, "scenes": scenes}
    output = Path(args.output).resolve()
    with output.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(fixed, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"path": str(output), "sha256": digest(output), "場数": size, "会計数": 24 * size}, ensure_ascii=False))


if __name__ == "__main__":
    main()
