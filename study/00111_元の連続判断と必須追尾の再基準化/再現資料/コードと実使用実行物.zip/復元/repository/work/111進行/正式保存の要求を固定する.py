"""全70の正本・診断・コードを、重複を抑えた正式保存要求へ結ぶ。"""

import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def ref(path: str | Path, expected: str | None = None) -> dict:
    """機能: 明示ファイルの絶対位置と現物指紋を確認する。

    引数: path(str|Path)、expected(str|None)は対象と任意の期待SHA。
    返り値: dictは絶対FileRef。期待差は例外。
    """
    value = Path(path)
    value = (value if value.is_absolute() else ROOT / value).resolve()
    sha = hashlib.sha256(value.read_bytes()).hexdigest()
    if expected is not None and sha != expected:
        raise ValueError("正式保存の参照差: " + str(value))
    return {"path": str(value), "sha256": sha}


def main() -> None:
    """機能: 金融再計算せず、全Refと後段成果物を正式保存要求へ固定する。

    引数: なし。Raw・価格CSV・未見11/09は開かない。
    返り値: None。既存要求と正式成果物を上書きしない。
    """
    definitions = {
        "condition": ("work/111進行/F3_金融同体の並列実行条件.json", "a64326cd451a943030f569d7b278bf84d878d71ef67164cc566cfeff841d3a4a"),
        "market": ("work/111並列市場/全70場/完了.json", "a88f100f5fd13f747fe323e0d7c670831ae2d00d74f05e1a5de70f79fa7747ef"),
        "result": ("work/111独立保存/全70場/結果.json", "9a94259454f4f84effc44e09f3594cccda9a11a2dee5da2b1d78f0d435c49573"),
        "saved_check": ("work/111独立保存/全70場/保存会計の確認.json", "6eafe79db8549a0776a05c8cef9a362d1cef9c7caf424322e2f8fb172a354159"),
        "oracle54": ("work/111原文oracle/元54場/完了.json", "ebfa81d690ebe4cf52847f019cfcffda6732634dbdfb17e2cc5d3def5f9662c1"),
        "core_stop": ("work/111連続Sourceと可変保護の接続/停止.json", "87104939274e592ec18cd621b048c5e690eb23336ef390e382f2f32a3a9b8dd5"),
        "source_stop": ("work/111元時計の連続再現/停止.json", "08b1331b372d5cd7e50d46d90c247a8fa9c6a9bf657105ff181928041f156946"),
        "actor_stop": ("work/111元通知の連続Actor/停止.json", "6503962ebb7189213a182f8801916e99503ddfa88d0a99426107f3755535cbf2"),
        "chart_stop": ("work/111連続保護のチャート公開/停止.json", "38c01e07d276310c6c1d803dca11e27979fc9286cf64d9a495e60485ea7264bd"),
        "pure_stop": ("work/111全玉利益と収束BBの純保護/停止.json", "0042a6dc3f181150609deeca5b2c095c9f553d69fcaab1d833402ae31fdbc2c4"),
        "save_stop": ("work/111連続保護の独立保存/検査_停止版/停止.json", "299e3c146b9d386d8faf7fcd58fcf795c7e692f57c81eb54fc56a439fc251348"),
        "P_stop": ("work/111連続保護の独立保存/P停止.json", "c39c6da7577a7cbbb371b048f2da5b0ac3f4e296d95500f895b91bd1c42dd297"),
        "io_stop": ("work/111独立保存のファイル名接続/停止.json", "17f4deeb27efe54b9cca41a9b517083e991082a1d13af62b8488d738970fb9ba"),
        "parallel_stop": ("work/111独立セッションの並列接続/停止.json", "16aa63dfddb01f9425afb3bcbd72ba63fba74b52bd83f38f5327edc67b333e88"),
        "same_entry_stop": ("work/111同じ入口の実現比較/停止.json", "7b4b670489753639d030d5ba2eba5786d4749b571981483cb8f4e61bedf9bf77"),
        "formal_stop": ("work/111正式保存への接続/検査_停止版/停止.json", "81fa24757a4e38afa48eb8528cb74188c2be4bb39390bad06f038f0800e53de3"),
    }
    references = {key: ref(path, expected) for key, (path, expected) in definitions.items()}
    extra = []
    for path, target, role in (
        ("work/111同入口比較/全70場/結果.json", "診断/同入口の実現比較/結果.json", "36対照・2520対照場別"),
        ("work/111進行/並列先頭2の全bytes照合.json", "検査/先頭2の直列並列同体.json", "先頭2の全Native bytes対照"),
        ("work/111進行/直列F2の中断記録.json", "検査/直列F2の中断記録.json", "未完了19場の明示中断"),
        ("work/111市場/先頭2場/完了.json", "検査/直列先頭2の成功.json", "最終70とNativeを重複保存しない先行証拠"),
        ("work/111並列市場/先頭2場/完了.json", "検査/並列先頭2の成功.json", "同金融並列I/Oの先行証拠"),
        ("work/111独立保存/並列先頭2場/保存会計の確認.json", "検査/並列先頭2の独立検算.json", "先頭48独立保存の成功"),
        ("work/111元手法基準の実行条件/H1_原文oracle前の固定.json", "検査/原文oracle条件.json", "原文再実行の市場前固定"),
        ("work/111進行/F1_追加保護24の先頭2条件.json", "検査/派生条件/F1.json", "追加保護先頭2の固定"),
        ("work/111進行/F2_追加保護24の元54条件.json", "検査/派生条件/F2.json", "元対照54追加の同金融固定"),
        ("work/111進行/S5_全70の独立保存要求.json", "検査/独立保存の要求.json", "市場Nativeの限定解禁"),
        ("work/111進行/C5_全70の同入口比較要求.json", "検査/同入口比較の要求.json", "全70の実現比較解禁"),
        ("work/111先頭2の起動後赤字診断/診断.json", "診断/起動後赤字/診断.json", "−77円の床下検知と実約定"),
        ("work/111先頭2の起動後赤字診断/診断.md", "診断/起動後赤字/診断.md", "起動前後の損失の区別"),
        ("work/111保護返済後の実建玉接続調査/調査.md", "診断/実建玉との接続/調査.md", "固定Sourceと実約定反映の範囲"),
        ("work/111保護返済後の実建玉接続調査/コード参照索引.json", "診断/実建玉との接続/コード参照索引.json", "状態の一次コード参照"),
    ):
        extra.append({"ref": ref(path), "target": target, "role": role})
    narrow = ROOT / "work/111収束警戒と支持否定の実現差"
    for name in ("知見.md", "停止.json", "元54場/集計.json", "元54場/レポート.md", "全70場/集計.json", "全70場/レポート.md"):
        extra.append({"ref": ref(narrow / name), "target": "診断/収束警戒と支持否定/" + name, "role": "初狭幅時点のP/C/M/Bと実現差"})
    csv_folder = ROOT / "outputs/01a1889f-f2af-7943-a047-543275ee9ed2/111損益CSV"
    csv_evidence_path = HERE / "CSV正本の所在.json"
    evidence = {"試行": 111, "正本はoutputsのCSV2点": True, "重複コピー": False,
                "CSV": [ref(csv_folder / name) for name in ("候補別集計.csv", "全セッション.csv")],
                "独立再読": ref(csv_folder / "CSVの独立再読.json", "cdbd8fe6825e4984627fbd8729500f06efd35acd8a82234947162f89942ba5ac")}
    with csv_evidence_path.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(evidence, ensure_ascii=False, indent=2) + "\n")
    for path, target in ((csv_evidence_path, "CSV/正本の所在.json"), (csv_folder / "CSVの確認.json", "CSV/生成確認.json"), (csv_folder / "CSVの独立再読.json", "CSV/独立再読.json")):
        extra.append({"ref": ref(path), "target": target, "role": "CSVを重複保存しない検算証拠"})
    code = []
    for folder, patterns in ((HERE, ("*.py",)), (ROOT / "work/111損益CSVの出力", ("*.mjs", "*.py")), (narrow, ("*.py",))):
        for pattern in patterns:
            for path in sorted(folder.glob(pattern)):
                code.append({"ref": ref(path), "role": "Rootの固定・CSV又は追加診断の再現コード"})
    for path in (Path("C:/Users/masay/go/pkg/mod/github.com/expr-lang/expr@v1.17.8/LICENSE"), Path("C:/Users/masay/go/pkg/mod/github.com/!burnt!sushi/toml@v1.5.0/COPYING")):
        code.append({"ref": ref(path), "role": "非標準依存のライセンス"})
    request = {"version": 1, "trial": 111, "fixed": True, "stage": "full70", "market_native_read_authorized": True,
               "refs": references, "go_environment": {"version": "go1.24.2", "root": "C:\\Program Files\\Go"},
               "restore_roots": {"repository": str(ROOT), "module_cache": "C:\\Users\\masay\\go\\pkg\\mod", "strategy_repository": str(ROOT.parent / "SessionTradeExecuter")},
               "code_refs": code, "extra_refs": extra}
    output = HERE / "正式保存の要求.json"
    with output.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(request, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"要求": ref(output), "extra数": len(extra), "Root追加コード数": len(code)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
