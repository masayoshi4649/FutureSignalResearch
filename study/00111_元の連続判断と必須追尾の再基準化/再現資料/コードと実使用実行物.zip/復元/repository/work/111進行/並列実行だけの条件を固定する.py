"""金融条件を変えず、独立セッションの並列実行物だけをF2から派生する。"""

import argparse
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def digest(path: Path) -> str:
    """機能: 明示ファイルの全バイト指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_ref(path: str | Path, expected: str) -> tuple[dict, dict]:
    """機能: 停止・条件の小metadataを期待指紋で認証する。

    引数: path(str|Path)、expected(str)は位置とSHA。
    返り値: tuple[dict,dict]はFileRefとJSON。現物差は例外。
    """
    absolute = Path(path).resolve()
    if digest(absolute) != expected:
        raise ValueError("I/O固定参照の現物差: " + str(absolute))
    return {"path": str(absolute), "sha256": expected}, json.loads(absolute.read_text(encoding="utf-8"))


def main() -> None:
    """機能: 同じ政策・費用・時計・技術尺度のまま新CLIのF3を固定する。

    引数: CLIはparallel-stop/sha256/output。市場を開かない。
    返り値: None。既存F1/F2/停止済みコードは変更しない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--parallel-stop", required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    baseline_ref, baseline = read_ref(HERE / "F2_追加保護24の元54条件.json", "c432325e22a24fc985b9b879a1b2b3893fcb1984f4ecf70f15cac5735df7837a")
    before = json.loads(json.dumps(baseline))
    stop_ref, stopped = read_ref(args.parallel_stop, args.sha256)
    if not stopped["成功"] or not stopped["停止"]:
        raise ValueError("並列接続が未停止")
    code = dict(baseline["code_sha256"])
    for field in ("所有コードSHA256", "Go閉包SHA256", "GoRootコードSHA256"):
        for name, sha in stopped[field].items():
            path = Path(name)
            path = (path if path.is_absolute() else ROOT / path).resolve()
            if digest(path) != sha or (str(path) in code and code[str(path)] != sha):
                raise ValueError("コード現物差又は衝突: " + str(path))
            code[str(path)] = sha
    core_ref, _ = read_ref(ROOT / "work/111連続Sourceと可変保護の接続/停止.json", "87104939274e592ec18cd621b048c5e690eb23336ef390e382f2f32a3a9b8dd5")
    for ref in (core_ref, stop_ref):
        code[ref["path"]] = ref["sha256"]
    exe = stopped["実行物"]
    if set(exe) != {"path", "sha256"} or digest(Path(exe["path"])) != exe["sha256"]:
        raise ValueError("並列exe参照差")
    baseline.update({"executable": exe, "code_sha256": code,
                     "parallel_method": "isolated_session_process_v1", "parallel_stop": stop_ref,
                     "parallel_max_workers": 16,
                     "derivation": {"base_financial_condition": baseline_ref,
                                    "scope": "場ごとの別プロセスによるI/Oのみ。原行順・Source・Actor・Chart・純保護・全24政策・費用・時計は変更しない",
                                    "financial_specifications_equal": True}})
    changed = {key for key in before if before[key] != baseline[key]}
    if changed != {"executable", "code_sha256", "derivation"}:
        raise ValueError("実行物・コード参照・由来以外が変わった")
    output = Path(args.output).resolve()
    with output.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(baseline, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"path": str(output), "sha256": digest(output), "全コード項目": len(code), "金融条件差": 0, "元対照": len(baseline["original166_references"])}, ensure_ascii=False))


if __name__ == "__main__":
    main()
