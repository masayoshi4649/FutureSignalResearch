"""Rootの成功参照と停止codeをNative本文より先に認証する。"""

from datetime import date, timedelta
from pathlib import Path
import re

import 会計の独立検算 as A


def reference(ref: dict, before: dict) -> Path:
    """機能: 絶対FileRefのbytesを認証して前後不変台帳へ追加する。

    引数: ref(dict)はpath/sha256、before(dict)は認証台帳。
    返り値: Pathは解決済み対象。不一致・相対位置はValueError。
    """
    import 集計 as S
    A.equal(set(ref), {'path', 'sha256'}, 'FileRef集合')
    path = Path(ref['path'])
    A.need(path.is_absolute() and re.fullmatch('[a-f0-9]{64}', ref['sha256']) is not None, '絶対FileRefとSHA')
    path = path.resolve()
    A.equal(S.digest(path), ref['sha256'], 'FileRef現物SHA.' + str(path))
    if str(path) in before:
        A.equal(before[str(path)], ref['sha256'], '同じ参照の指紋一致')
    before[str(path)] = ref['sha256']
    return path


def planned_sessions(stage: str) -> list[str]:
    """機能: 事前に定めたfirst2/base54/full70の全場を欠落なく列挙する。

    引数: stage(str)は三段階のいずれか。
    返り値: list[str]は日付順のDay/Night。11/09は含めない。
    """
    A.need(stage in ('first2', 'base54', 'full70'), '保存stage')
    end = date(2026, 9, 21) if stage == 'first2' else date(2026, 10, 27) if stage == 'base54' else date(2026, 11, 6)
    current, values = date(2026, 9, 21), []
    while current <= end:
        if current.weekday() < 5:
            values.extend(f'{current.isoformat()}_{kind}' for kind in ('Day', 'Night'))
        current += timedelta(days=1)
    A.equal(len(values), {'first2': 2, 'base54': 54, 'full70': 70}[stage], '予定全場数')
    return values


def prepare(fixed_path: Path, fixed_sha: str, output: Path) -> tuple:
    """機能: Rootの市場解禁・成功完了・全場Native・停止codeを先に認証する。

    引数: fixed_path/output(Path)、fixed_sha(str)はRoot新規要求・新規保存先・期待SHA。
    返り値: tuple[list,dict,dict]は全場task、認証指紋、証拠。Raw/価格本文は読まない。
    """
    import 集計 as S
    A.need(not output.exists(), '保存先は未作成')
    before = {}
    fixed_path = reference({'path': str(fixed_path), 'sha256': fixed_sha}, before)
    fixed = S.load(fixed_path)
    A.need(fixed['version'] == 1 and fixed['trial'] == 111 and fixed['fixed'] is True
           and fixed['market_native_read_authorized'] is True, 'Root固定と市場Native解禁が必要')
    stage = fixed['stage']
    sessions = planned_sessions(stage)
    completion_path = reference(fixed['completion'], before)
    condition_path = reference(fixed['condition'], before)
    stop_path = reference(fixed['code_stop'], before)
    stop = S.load(stop_path)
    A.need(stop['試行'] == 111 and stop['成功'] is True and stop['市場前'] is True, '市場前の保存停止')
    owned = stop['所有ファイルSHA256']
    required = {'会計の独立検算.py', '集計.py', '入力ゲート.py', '人工検査.py', '検査して停止する.py', 'README.md'}
    A.equal({Path(p).name for p in owned}, required, '停止の所有ファイル集合')
    A.equal({Path(p).parent for p in owned}, {Path(__file__).resolve().parent}, 'この保存器の停止だけを使用')
    for path, sha in {**owned, **stop['再用ファイルSHA256']}.items():
        reference({'path': path, 'sha256': sha}, before)
    pstop_path = reference(stop['純保護監査停止'], before)
    pstop = S.load(pstop_path)
    A.need(pstop.get('成功') is True and pstop.get('市場前') is True, '純保護の市場前停止')
    for path, sha in pstop['所有ファイルSHA256'].items():
        reference({'path': path, 'sha256': sha}, before)
    completion, condition = S.load(completion_path), S.load(condition_path)
    A.need(condition['trial'] == 111 and condition['fixed'] is True, '111の事前市場条件')
    A.need(completion['trial'] == 111 and completion['success'] is True and completion['stage'] == stage
           and completion['sessions'] == len(sessions) and completion['books'] == len(sessions) * 24,
           '同stage全24会計の金融成功')
    A.equal(completion['condition_sha256'], fixed['condition']['sha256'], '同じ市場条件')
    A.need(completion['unchanged'] is True and completion['before'] == completion['after'], '市場入力code前後不変')
    A.need(completion['all_original166_reference_events_equal'] is True, '別実行oracleの元Event照合')
    A.need(completion['historical_saved_events_equal'] is False and completion['all_original_signal_full_json_equal'] is False,
           '未証明の歴史保存Event/全Signal同体を主張しない')
    for path, sha in condition['code_sha256'].items():
        code_path = Path(path)
        if not code_path.is_absolute():
            code_path = A.ROOT / code_path
        reference({'path': str(code_path.resolve()), 'sha256': sha}, before)
        A.equal(completion['before'].get(str(code_path.resolve())), sha, '市場完了時と同じcode')
    for path, sha in completion['before'].items():
        # 元Raw/価格は本文を再読せず、金融成功時に固定された参照として引き継ぐ。
        A.need(isinstance(path, str) and re.fullmatch('[a-f0-9]{64}', sha) is not None, '金融側の入力指紋型')
    results = completion['results']
    A.equal([task['session'] for task in results], sessions, '金融成功の全予定場と順序')
    A.equal([task['session'] for task in fixed['scenes']], sessions, 'Root保存要求の全予定場と順序')
    tasks = []
    for expected, task in zip(results, fixed['scenes']):
        A.need(expected['books'] == 24 and expected['S0_comparisons'] == 4 and expected['S0_equal'] is True
               and expected['complete'] is True and expected['open_quantity'] == 0 and expected['pending_quantity'] == 0,
               '場別全24/四対照/残玉予約0')
        A.equal(task['native'], expected['native'], '完了記録のNativeをそのまま保存')
        sid = task['session']
        history = 'original54' if sid[:10] <= '2026-10-27' else 'additional16'
        A.equal(task['history_class'], history, '元54と追加16の区別')
        A.need(isinstance(task['market_path'], str) and task['market_path'], 'Viewer価格参照の文字列')
        path = reference(task['native'], before)
        A.need(path.name == sid + '.json.gz', '場名Nativeだけを受理')
        tasks.append({**task, 'resolved_native': path})
    proofs = {'stage': stage, 'Root保存要求SHA256': fixed_sha, '金融完了SHA256': fixed['completion']['sha256'],
              '金融条件SHA256': fixed['condition']['sha256'], '保存器停止SHA256': fixed['code_stop']['sha256'],
              '純保護監査停止SHA256': stop['純保護監査停止']['sha256'],
              '金融側Source対照': {k: completion[k] for k in ('all_original166_reference_events_equal', 'historical_saved_events_equal', 'all_original_signal_full_json_equal')},
              '市場入力前後不変の証拠': {'before': completion['before'], 'after': completion['after']}}
    return tasks, before, proofs
