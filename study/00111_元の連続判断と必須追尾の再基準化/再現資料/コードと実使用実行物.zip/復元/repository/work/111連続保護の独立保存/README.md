# 111の独立保存・集計器（市場前）

元の連続Source通知を使う111のNative台帳をPythonで再読する。Rawや価格CSVの別走査、元戦略の再生、3分足・指標の再形成は行わない。旧94・110の停止済みコードは変更しない。

## 所有と再用

- この保存器：`会計の独立検算.py`、`集計.py`、`入力ゲート.py`、`人工検査.py`、`検査して停止する.py`、本書。
- 独立純保護監査：`新保護の独立監査.py`、`保護監査の人工検査.py`、その停止記録。別担当が独立に計算する。
- 旧94 `scripts/FAR連続出生と個別利益追尾/集計.py` のSHA256は `7c0c1d1b365226c74027405589099cb72382c7850090627a83788e1e2066c381`。全約定の所有・費用・配賦・Source部分返済・u/W・保存DDを検査する本文を再用する。政策prefix4文とATR後取得metric1式だけをASTで明示分離し、差があれば停止する。旧版のkeyやpolicyへ新政策名を偽装しない。

## 入出力

`集計.py --fixed <絶対要求JSON> --sha256 <期待SHA256> --output <未作成の絶対先>`。Rootが市場結果の解禁後に実行する。要求は `version=1, trial=111, fixed=true, market_native_read_authorized=true` とし、`stage=first2/base54/full70`、`condition/completion/code_stop` の絶対FileRef、全場 `scenes` を含める。各場は `session/native/history_class/market_path`。`history_class` は元54場が `original54`、追加16場が `additional16`。条件・完了・停止code・人工証拠の現物SHAを先に認証し、全入力の前後不変を確認する。既存先を上書きしない。

市場completionは同stage、`success=true`、`sessions=N`、`books=24N`、同条件SHA、`unchanged=true`、同じ `before/after`、予定全場順の `results` を必要とする。各場は `books=24, S0_comparisons=4, S0_equal=true, complete=true, open_quantity=0, pending_quantity=0`。Rootの別実行oracleとの元Event照合を記録し、未証明の歴史保存Event同体・全Signal同体とは分ける。

出力は `結果.json`、`保存会計の確認.json`、`一覧.resources.json`、全24×場数の `.trades.jsonl`。0約定の資源・場別行も残す。first2は48行、元54は1296行、全70は1680行。Viewer約定は別会計で全行を再読し、費用後純額と最後の残量0を照合する。価格参照は文字列だけを扱い、HTTP・描画確認は別処理とする。

金融JSONは `Actor設定/集計/場別/主key` を持つ。場別は `gross_yen, fee_yen, slip_yen, net_yen, positive_yen, negative_yen, positive_positions, negative_positions, zero_positions, PF, win_rate, average_profit_yen, average_loss_yen, average_profit_loss_ratio` を明示する。勝率は費用後正益の完結実玉数を全完結実玉数で割り、引分を分母に含む。平均損失は負値、PFは正益総額を損失総額の絶対値で割る。分母0はnullとする。売買別とSource/保護返済別の金額も残す。CSV生成は別処理で、旧固定枠の活動表を必須とする出力器をそのまま適用しない。

## 検査の範囲

全注文・約定・ID・元所有・片側10枚・38.5円の片道税込手数料・C0/C5・D0/D1・部分配賦・純現金・保存MTM・期末残玉予約0を検査する。S0の4冊はStreamScopeだけを除いてSource基準の全金融JSONと照合する。全24冊が同じ元通知列を受けたことも検査する。実D0新規はSource miniの初回fill原行・価格へ結び、割当枚数の減少を別計数する。

約定は要求より後のIndex・物理行、要求時刻＋遅延以降、正常BBOであることを照合する。ただしNativeは全正常原行を保持していないため「最初の適格正常原行」をRaw別走査で証明したとは呼ばない。別実行oracle・元Event照合・Goの約定機構人工と合わせて評価する。将来は直前正常原行witnessを追加する余地がある。

u（費用後残玉単価）とW（配賦済み実現額＋残玉の即時清算純額）は全実Fillから時点を再構成する。純保護の起動・床・狭幅・全予約hit・Finishedは別Python監査で検査する。現Actorは各保存点の直前Snapshotと全中間保護要求の純点を保存しないため、隣接性等を満たす保存点だけexact式を検査し、空白区間がある保存点はbounded制約に分ける。未保存の実保護要求はMTM・所有・未予約量・実約定までを検査し、純Decisionまで全件exactと主張しない。各件数と限界は新保護監査の返り値へ残す。

DDは口座保存極値の二点算術と、flat場の時系列連結を検査する。全原行の極値取り落としの別証明はしない。未参加や退出後の仮想利益、機会損失、元本不明のROIは算出しない。

## 判断時計・頻度

111は元Sourceの連続判断を基準とする。新規の5分/15分時計、研究側の開始静観、最低参加率判定を導入しない。頻度は原行数・異常BBO行数・実新規件数・実保有秒・買/売/両建保有秒・数量秒・実玉時間合計を別記する。保有秒は実Fill間の時間積分で、部分返済と両建てを扱う。全Raw原行に対する活動率へ読み替えない。

## 市場前人工

RootのCore手製買売48冊を固定SHAで認証する。自然FARのSignal生成や市場実績の器具ではない。同じ人工場IDの買売を架空の市場2場へ改称しない。

```powershell
python -X utf8 人工検査.py
python -X utf8 検査して停止する.py --p-stop <純保護停止の絶対位置> --p-sha256 <SHA> --output <未作成の証拠先>
```

9主検査で48会計、全0取引24、8種の金融破壊、Source/S0破壊、源部分返済の実未予約量、部分返済・両建時間の手計算、損益率・連結DDの手計算、48資源の保存再読、予定集合と入力拒否を確認する。停止後は所有codeと人工・再用入力のSHAを再認証して市場実行を解禁する。研究目標達成・採用は常にfalseとし、この保存器の成功で研究目標達成を宣言しない。
