"""独立保存の人工を実行し、全所有codeと入力指紋を市場前に固定する。"""

import argparse
from collections import Counter
from pathlib import Path
import subprocess
import sys

import 集計 as S
import 人工検査 as T


OWNED = ('会計の独立検算.py', '集計.py', '入力ゲート.py', '人工検査.py', '検査して停止する.py', 'README.md')


def stop(pstop: Path, psha: str, output: Path) -> dict:
    """機能: 純保護停止を認証し人工・保存再読後に所有範囲を不変固定する。

    引数: pstop/output(Path)、psha(str)は純保護停止・未作成証拠先・期待SHA。
    返り値: dictは停止指紋と人工成功。市場Native・Rawを読まない。
    """
    folder = Path(__file__).resolve().parent
    S.need(not output.exists(), '停止証拠は新規先')
    S.equal(S.digest(pstop), psha, '純保護停止SHA')
    pure = S.load(pstop)
    S.need(pure['成功'] is True and pure['市場前'] is True, '純保護の市場前成功')
    before = {str(folder / name): S.digest(folder / name) for name in OWNED}
    reuse = {str(S.A.BASE_PATH): S.A.BASE_SHA, str(pstop): psha, str(T.MANIFEST): T.MANIFEST_SHA}
    reuse.update(pure['所有ファイルSHA256'])
    manifest = S.load(T.MANIFEST)
    reuse.update({ref['path']: ref['sha256'] for ref in manifest['references'].values()})
    for path, sha in reuse.items():
        S.equal(S.digest(Path(path)), sha, '停止前の全再用入力')
    output.mkdir(parents=True, exist_ok=False)
    test = subprocess.run([sys.executable, '-X', 'utf8', str(folder / '人工検査.py')],
                          cwd=folder, capture_output=True, text=True, encoding='utf-8', timeout=60)
    (output / '人工検査.txt').write_text(test.stdout + test.stderr, encoding='utf-8', newline='\n')
    S.need(test.returncode == 0, '人工検査の全成功')
    totals = Counter()
    artificial = []
    for name, value in T.fixtures().items():
        result = S.inspect_scene(value, artificial=True)
        for checked in result['checked'].values():
            totals.update(checked['protection_counts'].get('counts', {}))
        artificial.append({'方向': name, '会計': 24, 'S0比較': result['source']['S0全金融JSON'],
                           '元通知全24同体': result['source']['全24の元通知同体']})
    after = {path: S.digest(Path(path)) for path in before}
    S.equal(before, after, '所有code前後不変')
    for path, sha in reuse.items():
        S.equal(S.digest(Path(path)), sha, '再用入力前後不変')
    evidence = {'試行': 111, '成功': True, '市場前': True, '主検査': 9, '実型人工会計': 48,
                '人工': artificial, '新保護保存点検査件数': dict(totals), '全0取引24保持': True,
                '人工検査ログ': {'path': str(output / '人工検査.txt'), 'sha256': S.digest(output / '人工検査.txt')},
                '所有ファイルSHA256前': before, '所有ファイルSHA256後': after,
                '再用ファイルSHA256': reuse, '前後不変': True, '実市場Native読取': 0, 'Raw/価格CSV本文読取': 0}
    S.BASE.write_json(output / '人工確認.json', evidence)
    record = {'試行': 111, '成功': True, '市場前': True, '所有ファイルSHA256': before, '再用ファイルSHA256': reuse,
              '純保護監査停止': {'path': str(pstop), 'sha256': psha},
              '人工確認': {'path': str(output / '人工確認.json'), 'sha256': S.digest(output / '人工確認.json')},
              '実市場Native読取': 0, 'Raw/価格CSV本文読取': 0, '研究目標達成': False, '採用': False}
    S.BASE.write_json(output / '停止.json', record)
    return {'成功': True, '停止': {'path': str(output / '停止.json'), 'sha256': S.digest(output / '停止.json')}}


def main() -> None:
    """機能: 明示の純保護停止と未作成先だけで検査固定を呼ぶ。

    引数: CLI p-stop/p-sha256/output(str)は認証参照と新規先。
    返り値: None。停止Refだけを標準出力へ表示する。
    """
    import json
    parser = argparse.ArgumentParser(description='111独立保存の市場前停止')
    parser.add_argument('--p-stop', required=True)
    parser.add_argument('--p-sha256', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    print(json.dumps(stop(Path(args.p_stop).resolve(), args.p_sha256, Path(args.output).resolve()), ensure_ascii=False))


if __name__ == '__main__':
    main()
