"""市場を読まず、手計算点・破壊反例とRoot解禁API人工48冊でP監査を止める。"""

import argparse
from copy import deepcopy
from datetime import datetime, timezone
import gzip
import hashlib
import json
from pathlib import Path
import sys
import unittest

from 会計の独立検算 import verify_finance, BASE_PATH, BASE_SHA
from 新保護の独立監査 import (ceil_multiple, fixed_parameters, warnings,
                           verify_exact_point, verify_bounded_point,
                           check_publication, verify_protection)


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CORE_MANIFEST = ROOT / 'work/111連続Sourceと可変保護の接続/人工_独立保存用/人工.json'
CORE_SHA = 'bf51bebe5fe0b67cd39deb18b1f88da6164b513d0a87ea53ab77197b0423cc48'
STOP_REFS = {'work/111全玉利益と収束BBの純保護/停止.json': '0042a6dc3f181150609deeca5b2c095c9f553d69fcaab1d833402ae31fdbc2c4',
             'work/111連続保護のチャート公開/停止.json': '38c01e07d276310c6c1d803dca11e27979fc9286cf64d9a495e60485ea7264bd',
             'work/111元通知の連続Actor/停止.json': '6503962ebb7189213a182f8801916e99503ddfa88d0a99426107f3755535cbf2'}


def initial(policy='W100', side=1, slip=0, atr=None) -> dict:
    """機能: 小さい手計算例の初期状態を明示値から構成する。

    引数: policy(str)、side(int)、slip(int)、atr(dict/None)は人工入力。
    返り値: dictは取得価格1000・初期2枚の人工純状態。
    """
    entry = {'scope': {'session': '人工場', 'contract': '人工限月', 'start': 0},
             'policy': policy, 'side': side, 'price': 1000, 'at': 10,
             'initial_quantity': 2, 'slip_points': slip, 'atr': atr}
    return {'entry': entry, 'threshold_points': 50 if policy == 'B50' else 100,
            'normal_width': 200, 'atr_unknown_fallback': atr is None,
            'cost_per_unit_yen': 77 if slip == 0 else 1077,
            'minimum_floor': 10 if slip == 0 else 20, 'active': False, 'activated_at': None,
            'narrowed': False, 'narrowed_at': None, 'peak_points': None, 'width_points': 200,
            'floor_points': None, 'whole_target_yen': 0, 'closed_net_yen': 0,
            'remaining': 2, 'reserved': 0, 'latest': None, 'at': 10, 'sequence': 0, 'finished': False}


def point(before: dict, gain, sequence: int, phase='pre_fill', **changes) -> dict:
    """機能: 独立期待値を持たない保存点の器だけを作る。

    引数: before(dict)、gain(数値/None)、sequence(int)、phase(str)、changes(dict)は人工入力。
    返り値: dictは手計算でSnapshot/Decisionを記入する器。
    """
    s = deepcopy(before)
    s.update(at=20 + sequence, sequence=sequence)
    s.update(changes)
    q = None if gain is None else {'index': sequence, 'time': s['at'], 'source_line': sequence,
                                  'bid': 1000 + before['entry']['side'] * gain,
                                  'ask': 1000 + before['entry']['side'] * gain}
    d = {'c': 0, 'm': 0, 'p': 0, 'b': 0, 'warning': 0,
         'gain_points': None, 'unit_net_yen': None, 'whole_net_yen': None,
         'activated_now': False, 'narrowed_now': False, 'width_source': '',
         'whole_floor': None, 'peak_floor': None, 'structural_floor': None,
         'protect_price': None, 'protect_price_valid': False, 'floor_hit': False,
         'all_reserved_hit': False, 'free_quantity': s['remaining'] - s['reserved'],
         'eligible_exit_quantity': 0}
    return {'at': s['at'], 'quote': q, 'phase': phase, 'snapshot': s, 'decision': d, 'exit_order_id': ''}


def activated(side=1) -> tuple[dict, dict]:
    """機能: 費用後10423円/枚で初起動する手計算点を作る。

    引数: side(int)は買売符号。
    返り値: tuple[dict,dict]は直前状態と明示した期待保存点。
    """
    old = initial(side=side)
    p = point(old, 105, 1)
    p['snapshot'].update(active=True, activated_at=21, peak_points=105,
                         floor_points=10, whole_target_yen=1846)
    p['decision'].update(gain_points=105, unit_net_yen=10423, whole_net_yen=20846,
                         activated_now=True, width_source='取得時固定通常幅', whole_floor=5,
                         peak_floor=-95, protect_price=1000 + side * 10, protect_price_valid=True)
    return old, p


def publication(c=2, m=2, b=None, v=20, pivot=None) -> dict:
    """機能: 3分公表の人工原値を構成する。

    引数: c/m(int)、b(dict/None)、v(数値/None)、pivot(dict/None)は公表値。
    返り値: dictは当場公表。
    """
    return {'scope': {'session': '人工場', 'contract': '人工限月', 'start': 0},
            'id': '足1', 'ordinal': 1, 'start': 0, 'end': 180, 'available_at': 180,
            'c': c, 'm': m, 'v': v, 'close': 1150, 'prior_pivot': pivot, 'bb': b}


class ProtectionArithmeticTests(unittest.TestCase):
    """手計算・不利な改変・三値/数量/未来の反例を独立に確認する。"""

    def test_数学ceilと負数半円(self):
        """機能: 負数と半円を含むceil境界を検査する。

        引数: self(TestCase)。返り値: None。
        """
        self.assertEqual(ceil_multiple((77 - 600) / 100), -5)
        self.assertEqual(ceil_multiple(-5), -5)
        self.assertEqual(ceil_multiple(-5.005), -5)
        self.assertEqual(ceil_multiple(5.005), 10)

    def test_H費用と通常幅の独立性(self):
        """機能: H感度で通常幅を変えず取得時ATRだけを固定する。

        引数: self(TestCase)。返り値: None。
        """
        for policy, h in (('B50', 50), ('B100', 100)):
            e = initial(policy=policy)['entry']
            self.assertEqual(fixed_parameters(e), {'threshold_points': h, 'normal_width': 200,
                             'atr_unknown_fallback': True, 'cost_per_unit_yen': 77, 'minimum_floor': 10})
            e['atr'] = {'id': '公開ATR', 'value': 120.5, 'available_at': 9}
            self.assertEqual(fixed_parameters(e)['normal_width'], 245)
        self.assertEqual(fixed_parameters(initial(slip=5)['entry'])['minimum_floor'], 20)

    def test_初起動の買売鏡像(self):
        """機能: 起動前峰を流用せず売買の同一条件を検査する。

        引数: self(TestCase)。返り値: None。
        """
        for side in (1, -1):
            before, p = activated(side)
            verify_exact_point(before, p)

    def test_全玉q0と残単位uの起動を分離(self):
        """機能: 部分返済後も全玉起動の分母q0を減らさずu対照と分ける。

        引数: self(TestCase)。返り値: None。
        """
        for policy in ('W100', 'U100'):
            before = initial(policy=policy)
            p = point(before, 200, 1, remaining=1, closed_net_yen=-9000)
            p['decision'].update(gain_points=200, unit_net_yen=19923, whole_net_yen=10923)
            if policy == 'U100':
                p['snapshot'].update(active=True, activated_at=21, peak_points=200, floor_points=10)
                p['decision'].update(activated_now=True, width_source='取得時固定通常幅', peak_floor=0,
                                     protect_price=1010, protect_price_valid=True)
            verify_exact_point(before, p)

    def test_H50の実起動と滑り控除(self):
        """機能: B50だけが55ptで起動しC5の110ptはまだ費用後H100未満と確認する。

        引数: self(TestCase)。返り値: None。
        """
        for policy in ('B50', 'B100'):
            before = initial(policy=policy)
            p = point(before, 55, 1)
            p['decision'].update(gain_points=55, unit_net_yen=5423, whole_net_yen=10846)
            if policy == 'B50':
                p['snapshot'].update(active=True, activated_at=21, peak_points=55, floor_points=10, whole_target_yen=1846)
                p['decision'].update(activated_now=True, width_source='取得時固定通常幅', whole_floor=5, peak_floor=-145,
                                     protect_price=1010, protect_price_valid=True)
            verify_exact_point(before, p)
        before = initial(slip=5)
        p = point(before, 110, 1)
        p['decision'].update(gain_points=110, unit_net_yen=9923, whole_net_yen=19846)
        verify_exact_point(before, p)

    def test_床等号と全予約(self):
        """機能: 床等号のafter_source要求と全予約時の重複防止を検査する。

        引数: self(TestCase)。返り値: None。
        """
        before = activated()[1]['snapshot']
        for reserved in (0, 2):
            p = point(before, 10, 2, 'after_source', reserved=reserved)
            p['decision'].update(gain_points=10, unit_net_yen=923, whole_net_yen=1846,
                                 width_source='取得時固定通常幅', whole_floor=10, peak_floor=-95,
                                 protect_price=1010, protect_price_valid=True, floor_hit=True,
                                 all_reserved_hit=reserved == 2, eligible_exit_quantity=2-reserved)
            verify_exact_point(before, p)
            damaged = deepcopy(p)
            damaged['decision']['floor_hit'] = False
            with self.assertRaises(ValueError):
                verify_exact_point(before, damaged)

    def test_部分返済の先行損失と半円(self):
        """機能: q0を維持し先行損失を全玉床へ入れ現在超過でも実要求にする。

        引数: self(TestCase)。返り値: None。
        """
        before = activated()[1]['snapshot']
        p = point(before, 50, 2, 'after_source', remaining=1, closed_net_yen=-9076.5,
                  floor_points=110, whole_target_yen=1846.5)
        p['decision'].update(gain_points=50, unit_net_yen=4923, whole_net_yen=-4153.5,
                             width_source='取得時固定通常幅', whole_floor=110, peak_floor=-95,
                             protect_price=1110, protect_price_valid=True, floor_hit=True, eligible_exit_quantity=1)
        verify_exact_point(before, p)
        self.assertGreater(p['decision']['protect_price'], p['quote']['bid'])
        for key, value in (('whole_floor', 105), ('whole_net_yen', 4923)):
            damaged = deepcopy(p)
            damaged['decision'][key] = value
            with self.assertRaises(ValueError):
                verify_exact_point(before, damaged)

    def test_nil価格と正常気配付き最終残0(self):
        """機能: 欠気配を架空評価せず正常Quote付き残0でも価格演算しない。

        引数: self(TestCase)。返り値: None。
        """
        before = activated()[1]['snapshot']
        p = point(before, None, 2)
        verify_exact_point(before, p)
        finished = point(before, 30, 2, 'after_source', remaining=0, closed_net_yen=5846, finished=True)
        verify_exact_point(before, finished)
        damaged = deepcopy(finished)
        damaged['decision']['gain_points'] = 30
        with self.assertRaises(ValueError):
            verify_exact_point(before, damaged)

    def test_三値とBB二重票防止(self):
        """機能: Mが偽/未知なら収束とBBだけでは警戒を作らない。

        引数: self(TestCase)。返り値: None。
        """
        for m, expected in ((0, 0), (1, 1), (2, 2)):
            p = publication(c=1, m=m, b={'contraction': 2})
            self.assertEqual(warnings(p, 'B100', 1)['warning'], expected)
            self.assertEqual(warnings(p, 'T100', 1)['warning'], 0 if m != 1 else 1)
        self.assertEqual(warnings(None, 'B50', -1)['warning'], 0)

    def test_複合警戒の狭幅と構造床(self):
        """機能: 現警戒と取得後中心のpivotだけを構造床へ追加する。

        引数: self(TestCase)。返り値: None。
        """
        before = activated()[1]['snapshot']
        before['entry']['policy'] = 'T100'
        pivot = {'scope': before['entry']['scope'], 'id': '確認済pivot', 'kind': 'low',
                 'price': 1110, 'center_start': 180, 'center_end': 360, 'confirm_end': 540, 'published_at': 540}
        pub = publication(pivot=pivot)
        p = point(before, 150, 2, 'after_source', latest=pub, at=600, narrowed=True, narrowed_at=600,
                  peak_points=150, width_points=20, floor_points=130, whole_target_yen=25846)
        p['at'] = p['quote']['time'] = 600
        p['decision'].update(c=2, m=2, p=1, warning=2, gain_points=150, unit_net_yen=14923, whole_net_yen=29846,
                             narrowed_now=True, width_source='狭幅現V', whole_floor=10, peak_floor=130,
                             structural_floor=105, protect_price=1130, protect_price_valid=True)
        verify_exact_point(before, p)
        damaged = deepcopy(p)
        damaged['decision']['structural_floor'] = None
        with self.assertRaises(ValueError):
            verify_exact_point(before, damaged)

    def test_狭幅は再拡大しても床Lを緩めない(self):
        """機能: 現V増加による幅再拡大と床/Lの非緩和を区別する。

        引数: self(TestCase)。返り値: None。
        """
        before = activated()[1]['snapshot']
        before['entry']['policy'] = 'B100'
        before.update(narrowed=True, narrowed_at=21, width_points=20, peak_points=150,
                      floor_points=130, whole_target_yen=25846)
        p = point(before, 140, 2, 'after_source', latest=publication(c=1, m=1, v=80), at=600, width_points=80)
        p['at'] = p['quote']['time'] = 600
        p['decision'].update(c=1, m=1, warning=1, gain_points=140, unit_net_yen=13923, whole_net_yen=27846,
                             width_source='狭幅現V', whole_floor=130, peak_floor=70,
                             protect_price=1130, protect_price_valid=True)
        verify_exact_point(before, p)
        damaged = deepcopy(p)
        damaged['snapshot']['floor_points'] = 70
        with self.assertRaises(ValueError):
            verify_exact_point(before, damaged)

    def test_未知後も幅を保ち床を捏造しない(self):
        """機能: reset後の未知公表と狭幅未知時の既存幅維持を検査する。

        引数: self(TestCase)。返り値: None。
        """
        before = activated()[1]['snapshot']
        before['entry']['policy'] = 'B100'
        before.update(narrowed=True, narrowed_at=21, width_points=20, peak_points=150,
                      floor_points=130, whole_target_yen=25846)
        p = point(before, 140, 2, 'after_source')
        p['decision'].update(gain_points=140, unit_net_yen=13923, whole_net_yen=27846,
                             width_source='狭幅尺度未知・既存幅保持', whole_floor=130, peak_floor=130,
                             protect_price=1130, protect_price_valid=True)
        verify_exact_point(before, p)

    def test_旧L区間と完全一致を区別(self):
        """機能: 非隣接点のFW可解区間が空になる改変を拒否する。

        引数: self(TestCase)。返り値: None。
        """
        before, p = activated()
        p['snapshot']['sequence'] = 9
        verify_bounded_point(p, before)
        damaged = deepcopy(p)
        damaged['decision']['whole_floor'] = -500
        with self.assertRaises(ValueError):
            verify_bounded_point(damaged, before)

    def test_未来公表とreset後旧ID復活を拒否(self):
        """機能: 保存出典の未来混入・strict後のresetを越す古いID復活を拒否する。

        引数: self(TestCase)。返り値: None。
        """
        p = publication()
        context = {'publications': [{'at': 180, 'buy': p, 'sell': p}], 'resets': []}
        check_publication(p, initial()['entry'], 181, context)
        with self.assertRaises(ValueError):
            check_publication(p, initial()['entry'], 179, context)
        context['resets'] = [{'at': 181, 'reason': '人工欠足'}]
        with self.assertRaises(ValueError):
            check_publication(p, initial()['entry'], 182, context)
        check_publication(None, initial()['entry'], 182, context)


def sha(path: Path) -> str:
    """機能: 実ファイルのSHA256を返す。

    引数: path(Path)は既存ファイル。返り値: strは小文字SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_core_fixture() -> dict:
    """機能: Root解禁の手製買売48冊を認証しA/P監査と破壊反例を行う。

    引数: なし。
    返り値: dictは入力指紋・件数・破壊検出。市場データを読まない。
    """
    if sha(CORE_MANIFEST) != CORE_SHA:
        raise ValueError('Root解禁人工のmanifest SHA差')
    manifest = json.loads(CORE_MANIFEST.read_text(encoding='utf-8-sig'))
    if manifest['market_data'] is not False or manifest['natural_FAR_signal'] is not False:
        raise ValueError('手製API人工以外を本検査へ混入')
    total = {}
    refs, mutations, supplemental = {}, [], []
    books = 0
    for reference in manifest['references'].values():
        path = Path(reference['path'])
        if sha(path) != reference['sha256']:
            raise ValueError('Root人工本体SHA差')
        refs[str(path)] = reference['sha256']
        actual = json.loads(gzip.decompress(path.read_bytes()))['actual']
        context = {k: actual[k] for k in ('scope', 'publications', 'resets', 'counts', 'final_chart')}
        for book in actual['books'].values():
            finance = verify_finance(book, book['config'])
            result = verify_protection(book, book['config'], finance, context)
            books += 1
            for k, v in result['counts'].items():
                total[k] = total.get(k, 0) + v
        book = next(b for b in actual['books'].values() if b['config']['policy'] == 'W100')
        for label, field, value in (('Hを改変', 'threshold_points', 50), ('q0を改変', 'initial_quantity', 1),
                                    ('Lを改変', 'whole_target_yen', -0.5)):
            damaged = deepcopy(book)
            audit = damaged['positions'][0]['protection111']
            if field == 'initial_quantity':
                audit['initial']['entry'][field] = value
            else:
                audit['initial'][field] = value
            try:
                verify_protection(damaged, damaged['config'], verify_finance(damaged, damaged['config']), context)
            except ValueError:
                mutations.append(label)
            else:
                raise ValueError('破壊反例を未検出/' + label)
        # ----------------------------------------
        # 元exportに無い要求保存点を、同原行のpre_fill→after_sourceという手製器具として補う。
        # 市場記録の補完や元exportを書き換える処理ではなく、監査APIの分岐検査だけに使う。
        decorated = deepcopy(book)
        p = decorated['positions'][0]
        audit = p['protection111']
        order = next(o for o in decorated['orders'] if o['protection_point'] is not None)
        request = deepcopy(audit['first_floor_hit'])
        if request['phase'] != 'pre_fill' or request['quote'] != order['request_quote']:
            raise ValueError('要求分岐人工の前提差')
        request['phase'] = 'after_source'
        request['snapshot']['sequence'] += 1
        request['decision']['eligible_exit_quantity'] = order['quantity']
        request['exit_order_id'] = order['id']
        request['after_request'] = deepcopy(request['snapshot'])
        request['after_request']['sequence'] += 1
        request['after_request']['reserved'] += order['quantity']
        audit['requests'] = [request]
        decorated_finance = verify_finance(decorated, decorated['config'])
        verified = verify_protection(decorated, decorated['config'], decorated_finance, context)
        if verified['counts']['request_points'] != 1 or verified['counts']['request_points_unstored'] != 0:
            raise ValueError('要求保存分岐人工の未検査')
        supplemental.append('同原行の実要求とnil価格の予約再同期を手製保存点で検査')
        broken = deepcopy(decorated)
        broken['positions'][0]['protection111']['requests'][0]['after_request']['floor_points'] += 5
        try:
            verify_protection(broken, broken['config'], verify_finance(broken, broken['config']), context)
        except ValueError:
            mutations.append('予約再同期で架空に床更新')
        else:
            raise ValueError('予約再同期の破壊を未検出')
        missing = deepcopy(book)
        missing_audit = missing['positions'][0]['protection111']
        missing_audit['last']['quote'] = None
        missing_audit['missing_quote'] += 1
        verify_protection(missing, missing['config'], verify_finance(missing, missing['config']), context)
        supplemental.append('欠気配の最終Finishedを手製保存点で検査')
    if books != 48:
        raise ValueError('Root人工が買売48冊でない')
    return {'冊数': books, 'counts': total, '破壊反例の検出数': len(mutations),
            '破壊反例': mutations, 'manifest': {'path': str(CORE_MANIFEST), 'sha256': CORE_SHA},
            '人工本体': refs, '追加の手製分岐検査': supplemental,
            'market_data': False, 'natural_FAR_signal': False}


def main() -> None:
    """機能: 手計算人工とRoot人工を検査しP専用の停止JSONを生成する。

    引数: CLIの--stop(Path)は任意の新規停止先。
    返り値: None。失敗時は停止JSONを作らない。
    """
    parser = argparse.ArgumentParser(description='111保護の独立保存点監査の人工検査')
    parser.add_argument('--stop', type=Path)
    args = parser.parse_args()
    owned = [HERE / '新保護の独立監査.py', Path(__file__).resolve()]
    before = {str(p): sha(p) for p in owned}
    dependencies = {str(HERE / '会計の独立検算.py'): sha(HERE / '会計の独立検算.py'), str(BASE_PATH): BASE_SHA}
    for relative, expected in STOP_REFS.items():
        p = ROOT / relative
        if sha(p) != expected:
            raise ValueError('停止済み保護/チャート/Actorの参照SHA差')
        dependencies[str(p)] = expected
    tests = unittest.defaultTestLoader.loadTestsFromTestCase(ProtectionArithmeticTests)
    run = unittest.TextTestRunner(verbosity=2).run(tests)
    if not run.wasSuccessful():
        raise ValueError('手計算人工の不一致')
    core = verify_core_fixture()
    after = {str(p): sha(p) for p in owned}
    if before != after:
        raise ValueError('P検査中に所有コード変更')
    if any(sha(Path(p)) != expected for p, expected in dependencies.items()):
        raise ValueError('P検査中に停止依存変更')
    result = {'版': 1, '成功': True, '市場前': True, '生成時刻UTC': datetime.now(timezone.utc).isoformat(),
              '所有ファイルSHA256': after, '所有前後同体': True, '手計算主人工数': run.testsRun,
              'Root_API人工': core, '依存': dependencies, '停止依存前後同体': True,
              'API': 'verify_protection(book:dict,config:dict,finance:dict,context:dict)->dict; 不正はValueError',
              '証明範囲': 'Go未使用の有理数・三値による少数保存点監査。起動点/隣接点は完全一致、その他は旧L区間とpost整合。',
              '限界': ['全原行を独立再走する別エンジンではない。', '未保存の中間要求は実会計/MTMまで。全純要求式を証明しない。',
                       '同秒の公表配送原行Indexとreset統合順は保存されず、出典/時刻下限/strict前後関係まで。',
                       'Raw未読。次正常原行の最初性・未保存区間の極値/初回性は証明しない。'],
              '非対象': ['未参加の仮想利益', '退出後の仮想利益', 'MFE回収率', '市場損益の評価']}
    if args.stop:
        if args.stop.exists():
            raise ValueError('既存停止先を上書きしない')
        args.stop.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '手計算主人工数': run.testsRun, 'Root冊数': core['冊数'], 'counts': core['counts']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
