"""市場を開かず、実Core人工48冊と破壊例で独立保存の会計境界を検査する。"""

from copy import deepcopy
from decimal import Decimal
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest

import 集計 as S
import 入力ゲート as G


MANIFEST = S.A.ROOT / 'work/111連続Sourceと可変保護の接続/人工_独立保存用/人工.json'
MANIFEST_SHA = 'bf51bebe5fe0b67cd39deb18b1f88da6164b513d0a87ea53ab77197b0423cc48'


def fixtures() -> dict:
    """機能: Rootが解禁した手製Core人工だけを全bytes認証して読む。

    引数: なし。
    返り値: dict[str,dict]は買い・売りの48冊。市場Nativeを探索しない。
    """
    S.equal(S.digest(MANIFEST), MANIFEST_SHA, 'Root人工manifest')
    manifest = S.load(MANIFEST)
    S.need(manifest['market_data'] is False and manifest['natural_FAR_signal'] is False and manifest['books'] == 48, '人工の限定')
    values = {}
    for name, ref in manifest['references'].items():
        path = Path(ref['path'])
        S.equal(S.digest(path), ref['sha256'], 'Root人工現物')
        values[name] = S.load(path)
    return values


def empty_book(book: dict) -> dict:
    """機能: 実型の空集合表現を保つ手製0取引口座を作る。

    引数: book(dict)は人工実型の雛形。
    返り値: dictは全数量・金額・観測数0の別値。市場結果へ転用しない。
    """
    result = deepcopy(book)
    for name in ('orders', 'fills', 'positions', 'source_events'):
        result[name] = []
    result['totals'] = {k: 0 for k in result['totals']}
    result['metrics'] = {k: 0 for k in result['metrics']}
    result['account'] = {k: 0 if k in ('max_drawdown', 'max_gap_seconds', 'count') else None for k in result['account']}
    return result


class IndependentSaveTests(unittest.TestCase):
    """手製入力だけで金額と出典の独立拒否を確認する。"""

    @classmethod
    def setUpClass(cls) -> None:
        """機能: 認証済み人工値を一度だけ準備する。

        引数: cls(type)は検査クラス。
        返り値: None。
        """
        cls.values = fixtures()

    def test_all_48_finance_and_source(self) -> None:
        """機能: 買売48冊の全会計とSource非干渉を検査する。

        引数: self(IndependentSaveTests)は検査器。
        返り値: None。
        """
        for value in self.values.values():
            before = repr(value)
            result = S.inspect_scene(value, artificial=True)
            self.assertEqual(len(result['checked']), 24)
            S.equal(repr(value), before, '人工原値の非変更')

    def test_fees_allocation_and_owner_rejected(self) -> None:
        """機能: 費用・配賦・所有・残予約の破壊を個別に拒否する。

        引数: self(IndependentSaveTests)は検査器。
        返り値: None。各破壊がValueErrorとなることを検査する。
        """
        source = self.values['買い']['actual']['books']['W100_C0_D0']
        for kind in ('fee', 'allocation', 'owner', 'reserved', 'same_row', 'delay', 'DD', 'source_side'):
            book = deepcopy(source)
            if kind == 'fee':
                book['fills'][0]['fee_yen'] += Decimal('0.5')
            elif kind == 'allocation':
                book['fills'][-1]['allocations'][0]['net_yen'] += 1
            elif kind == 'owner':
                book['fills'][-1]['source_hold_id'] = '他人の所有'
            elif kind == 'reserved':
                book['positions'][0]['reserved'] = 1
            elif kind == 'same_row':
                book['fills'][0]['quote']['index'] = book['orders'][0]['request_quote']['index']
            elif kind == 'delay':
                book['orders'][0]['request_time'] = book['fills'][0]['quote']['time'] + 1
            elif kind == 'DD':
                book['account']['max_drawdown'] += 1
            else:
                book['source_events'][0]['side'] *= -1
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                S.A.verify_finance(book, S.BY_KEY['W100_C0_D0'])

    def test_source_and_s0_mismatch_rejected(self) -> None:
        """機能: Source非干渉と四S0同体の破壊を拒否する。

        引数: self(IndependentSaveTests)は検査器。
        返り値: None。
        """
        value = deepcopy(self.values['買い'])
        value['actual']['books']['B50_C0_D0']['source_events'][0]['quantity'] += 1
        with self.assertRaises(ValueError):
            S.verify_source(value, True)
        value = deepcopy(self.values['買い'])
        value['source']['books']['S0_C0_D1']['totals']['net_yen'] += 1
        with self.assertRaises(ValueError):
            S.verify_source(value, True)

    def test_source_partial_free_rebuilt(self) -> None:
        """機能: 元部分返済前の未予約量を先行要求と同原行の順序から手計算する。

        引数: self(IndependentSaveTests)は検査器。
        返り値: None。保護予約1、源要求2、源要求2で実残5を使い切る器具。
        """
        book = {'positions': [{'id': '実玉', 'source': {'method': 'NK225_D164_15'}, 'source_hold_id': '源玉'}],
                'source_events': [{'kind': 'close_notice', 'method': 'NK225_D164_15', 'hold_id': '源玉',
                                   'quote': {'index': 5}, 'actual_free_before': a, 'actual_exit_requested': q,
                                   'actual_free_after': b, 'order_id': name}
                                  for name, a, q, b in (('源要求1', 4, 2, 2), ('源要求2', 2, 2, 0))]}
        orders = {name: {'id': name, 'kind': 'exit', 'position_id': '実玉', 'request_quote': {'index': index}, 'quantity': q}
                  for name, index, q in (('既存保護', 2, 1), ('源要求1', 5, 2), ('源要求2', 5, 2), ('同原行後の保護', 5, 1))}
        timeline = SimpleNamespace(state_at=lambda pid, point: {'quantity': 5}, fill_by_order={})
        finance = {'orders': orders, 'timeline': timeline}
        S.A.verify_source_reservations(book, finance)
        book['source_events'][1]['actual_free_before'] = 3
        with self.assertRaises(ValueError):
            S.A.verify_source_reservations(book, finance)

    def test_24_zero_trade_rows_preserved(self) -> None:
        """機能: 全0取引の24口座を欠落させず率をnullで保持する。

        引数: self(IndependentSaveTests)は検査器。
        返り値: None。
        """
        for key in S.KEYS:
            book = empty_book(self.values['買い']['actual']['books'][key])
            checked = S.A.verify_finance(book, S.BY_KEY[key])
            checked['protection_counts'] = {}
            row = S.summarize_book(book, checked)
            total = S.combine([{'session': '人工', **row}])
            self.assertEqual(total['net_yen'], 0)
            self.assertEqual(total['positions'], 0)
            self.assertIsNone(total['PF'])
            self.assertIsNone(total['win_rate'])

    def test_partial_and_hedged_holding_duration(self) -> None:
        """機能: 部分返済と両建てを含む実時間積分を手計算と照合する。

        引数: self(IndependentSaveTests)は検査器。
        返り値: None。
        """
        fills = [{'action': a, 'side': side, 'quantity': q, 'quote': {'time': t}}
                 for t, a, side, q in ((0, 'new', 1, 2), (10, 'close', -1, 1),
                                       (20, 'new', -1, 1), (30, 'close', -1, 1), (40, 'close', 1, 1))]
        positions = [{'entry_quote': {'time': 0}, 'closed_quote': {'time': 30}},
                     {'entry_quote': {'time': 20}, 'closed_quote': {'time': 40}}]
        actual = S.holding_diagnostics({'fills': fills, 'positions': positions, 'metrics': {'rows': 5, 'bad_quote_rows': 0}})
        self.assertEqual({k: actual[k] for k in ('held_seconds', 'buy_held_seconds', 'sell_held_seconds', 'both_held_seconds', 'quantity_seconds', 'position_seconds_sum')},
                         {'held_seconds': 40, 'buy_held_seconds': 30, 'sell_held_seconds': 20, 'both_held_seconds': 10, 'quantity_seconds': 60, 'position_seconds_sum': 50})

    def test_profit_ratios_and_saved_dd(self) -> None:
        """機能: 勝率分母・負値平均損失と場を跨ぐ保存DDを手計算で照合する。

        引数: self(IndependentSaveTests)は検査器。
        返り値: None。
        """
        row = {'positions': 4, 'positive_yen': Decimal(300), 'negative_yen': Decimal(-100),
               'positive_positions': 2, 'negative_positions': 1, 'zero_positions': 1}
        stats = S.profit_statistics(row)
        self.assertEqual(stats, {'PF': 3, 'win_rate': Decimal('0.5'), 'average_profit_yen': 150,
                                 'average_loss_yen': -100, 'average_profit_loss_ratio': Decimal('1.5')})
        first = {**row, 'session': '1', 'net_yen': 200, '場内時価DD': 50, '保存最大時価': 250,
                 '保存最小時価': -10, '売買別': {}, '注文別': {}, '頻度診断': {}}
        second = {**row, 'session': '2', 'net_yen': 200, '場内時価DD': 25, '保存最大時価': 225,
                  '保存最小時価': -100, '売買別': {}, '注文別': {}, '頻度診断': {}}
        self.assertEqual(S.combine([second, first])['保存点連結時価DD'], 150)

    def test_viewer_written_rows_reinspection(self) -> None:
        """機能: 買売各24資源を保存・再読して費用後純額とflatを照合する。

        引数: self(IndependentSaveTests)は検査器。
        返り値: None。人工資料は一時領域にのみ作る。
        """
        for value in self.values.values():
            with tempfile.TemporaryDirectory(prefix='111人工Viewer_') as tmp:
                output = Path(tmp)
                resources = S.save_viewer(value, output, '人工参照のみ')
                proof = S.verify_viewer(value, output, resources)
                self.assertEqual(proof['資源'], 24)
                self.assertTrue(proof['全残0'])
                self.assertEqual(len(list(output.iterdir())), 24)
                with self.assertRaises(FileExistsError):
                    S.save_viewer(value, output, '人工参照のみ')

    def test_scope_sets_and_gate_rejection(self) -> None:
        """機能: 54+16場の境界と未固定・相対参照・既存先の拒否を検査する。

        引数: self(IndependentSaveTests)は検査器。
        返り値: None。市場資料を開かない。
        """
        self.assertEqual(len(G.planned_sessions('full70')), 70)
        self.assertEqual(G.planned_sessions('full70')[:54], G.planned_sessions('base54'))
        self.assertEqual(len(G.planned_sessions('full70')[54:]), 16)
        self.assertEqual(G.planned_sessions('first2'), G.planned_sessions('full70')[:2])
        with self.assertRaises(ValueError):
            G.planned_sessions('11/09追加')
        with self.assertRaises(ValueError):
            G.reference({'path': '相対.json', 'sha256': 'a' * 64}, {})
        with tempfile.TemporaryDirectory(prefix='111入力拒否_') as tmp:
            with self.assertRaises(ValueError):
                G.prepare(MANIFEST, MANIFEST_SHA, Path(tmp))


if __name__ == '__main__':
    unittest.main(verbosity=2)
