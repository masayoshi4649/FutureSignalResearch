package main

import (
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"testing"
)

// compression は、量/TR増加前の人工収束6足を作ります。
//
// 引数: なし。返り値: []Snapです。
func compression() []Snap {
	seq := []Snap{}
	for n := 1; n <= 6; n++ {
		q := sample(n, rules.OHLC{Open: 110, High: 111, Low: 109, Close: 110}, 0, 0, 50, 50)
		q.Pub.Frame.Frame.VolumeKnown = true
		q.Pub.Frame.Frame.Volume = 100
		q.Pub.Frame.Frame.Technical.TR = value(5)
		seq = append(seq, q)
	}
	return seq
}

// TestCompressionBreakMirror は、過去収束と別足の放れ・量拡大・鏡像を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestCompressionBreakMirror(t *testing.T) {
	seq := compression()
	q := sample(7, rules.OHLC{Open: 111, High: 119, Low: 110, Close: 118}, 1, 0, 60, 55)
	q.Pub.Frame.Frame.VolumeKnown = true
	q.Pub.Frame.Frame.Volume = 200
	q.Pub.Frame.Frame.Technical.TR = value(20)
	seq = append(seq, q)
	a := newDetector(Scene{Session: "収束", ForceClose: 9999})
	b := newDetector(Scene{Session: "鏡像収束", ForceClose: 9999})
	for i, q := range seq {
		a.step(q)
		b.step(mirror(q))
		if i < 6 && (len(a.Events) != 0 || len(b.Events) != 0) {
			t.Fatal("収束と同足で放れ出生")
		}
	}
	if len(a.Events) != 1 || len(b.Events) != 1 || a.Events[0].Pattern != "S" || a.Events[0].Side != 1 || b.Events[0].Side != -1 {
		t.Fatal("S放れ/鏡像差")
	}
	if a.Events[0].RoleMask["S_path"] != "break" || len(a.Events[0].FrameRefs) < 6 {
		t.Fatal("S経路/収束参照不足")
	}
}

// TestFarBreakWaitsRetest は、遠い放れを追わず旧境界再試験を待つことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestFarBreakWaitsRetest(t *testing.T) {
	seq := compression()
	q := sample(7, rules.OHLC{Open: 110, High: 135, Low: 110, Close: 132}, 1, 0, 60, 55)
	q.Pub.Frame.Frame.VolumeKnown = true
	q.Pub.Frame.Frame.Volume = 200
	q.Pub.Frame.Frame.Technical.TR = value(20)
	seq = append(seq, q)
	d := newDetector(Scene{Session: "再試験", ForceClose: 9999})
	for _, v := range seq {
		d.step(v)
	}
	if len(d.Events) != 0 {
		t.Fatal("追い過ぎを即取得候補化")
	}
	r := sample(8, rules.OHLC{Open: 120, High: 125, Low: 112, Close: 122}, 2, 1, 62, 60)
	r.Pub.Frame.Frame.VolumeKnown = true
	r.Pub.Frame.Frame.Volume = 100
	d.step(r)
	if len(d.Events) != 1 || d.Events[0].Pattern != "S" || d.Events[0].RoleMask["S_path"] != "retest" {
		t.Fatal("再試験未成立")
	}
}
