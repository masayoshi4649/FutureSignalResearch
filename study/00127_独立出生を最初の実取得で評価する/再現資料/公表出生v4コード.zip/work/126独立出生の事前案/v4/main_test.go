package main

import (
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"testing"
)

// value は、人工の既知技法値を作ります。
//
// 引数: v(float64)。返り値: rules.Valueです。
func value(v float64) rules.Value { return rules.Value{Known: true, Value: v} }

// sample は、状態遷移用の人工確定足を作ります。
//
// 引数: n(int)、o(rules.OHLC)、hist/previous/RSI/previousRSI(float64)。返り値: Snapです。
func sample(n int, o rules.OHLC, h, ph, r, pr float64) Snap {
	t := rules.Technical{EMA8: value(110), EMA21: value(110), Gap: value(0), EMA8Delta: value(0), EMA21Delta: value(0), ATR: value(20), PreviousATR: value(20), TR: value(15), Histogram: value(h), PreviousHistogram: value(ph), RSI: value(r), PreviousRSI: value(pr)}
	p := rules.Publication{Stamp: rules.Stamp{Time: float64(n*300 + 60), Index: n, Line: n + 1}, Frame: rules.Frame{Frame: rules.ChartFrame{ID: string(rune('a' + n)), Width: 300, Start: float64(n*300 - 300), End: float64(n * 300), PriceKnown: true, OHLC: o, Technical: t}}}
	return Snap{Pub: p, View: rules.Snapshot{Frames: map[int]rules.Publication{}, RVOL5: value(1.2)}}
}

// mirror は、人工値だけを価格/売買鏡像へ変換します。
//
// 引数: q(Snap)。返り値: Snapです。
func mirror(q Snap) Snap {
	f := &q.Pub.Frame.Frame
	o := f.OHLC
	f.OHLC = rules.OHLC{Open: 1000 - o.Open, High: 1000 - o.Low, Low: 1000 - o.High, Close: 1000 - o.Close}
	t := &f.Technical
	t.EMA8.Value = 1000 - t.EMA8.Value
	t.EMA21.Value = 1000 - t.EMA21.Value
	t.Gap.Value = -t.Gap.Value
	t.EMA8Delta.Value = -t.EMA8Delta.Value
	t.EMA21Delta.Value = -t.EMA21Delta.Value
	t.Histogram.Value = -t.Histogram.Value
	t.PreviousHistogram.Value = -t.PreviousHistogram.Value
	t.RSI.Value = 100 - t.RSI.Value
	t.PreviousRSI.Value = 100 - t.PreviousRSI.Value
	return q
}

// TestReversalStagesMirror は、Rの段階分離と鏡像を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestReversalStagesMirror(t *testing.T) {
	seq := []Snap{}
	for n := 1; n <= 3; n++ {
		seq = append(seq, sample(n, rules.OHLC{Open: 110, High: 112, Low: 109, Close: 110}, 0, 0, 50, 50))
	}
	seq = append(seq, sample(4, rules.OHLC{Open: 95, High: 100, Low: 89, Close: 90}, -2, -1, 30, 35), sample(5, rules.OHLC{Open: 92, High: 99, Low: 90, Close: 97}, -1, -2, 35, 30), sample(6, rules.OHLC{Open: 101, High: 106, Low: 100, Close: 105}, 0, -1, 40, 35))
	a := newDetector(Scene{Session: "人工", ForceClose: 9999})
	b := newDetector(Scene{Session: "鏡像", ForceClose: 9999})
	for i, q := range seq {
		a.step(q)
		b.step(mirror(q))
		if i < 5 && (len(a.Events) != 0 || len(b.Events) != 0) {
			t.Fatal("同足又は途中段階で出生")
		}
	}
	if len(a.Events) != 1 || len(b.Events) != 1 {
		t.Fatalf("R出生数 %d/%d", len(a.Events), len(b.Events))
	}
	x, y := a.Events[0], b.Events[0]
	if x.Pattern != "R" || x.Side != 1 || y.Side != -1 || y.TriggerLevel != 1000-x.TriggerLevel || y.Invalidation != 1000-x.Invalidation || y.EntryCap != 1000-x.EntryCap {
		t.Fatal("R鏡像不一致")
	}
}

// TestTrendStagesAndUpperVeto は、Tの段階分離・未知maskと既知上位反対拒否を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestTrendStagesAndUpperVeto(t *testing.T) {
	seq := []Snap{sample(1, rules.OHLC{Open: 110, High: 115, Low: 109, Close: 114}, 2, 1, 60, 55), sample(2, rules.OHLC{Open: 112, High: 113, Low: 106, Close: 108}, 1, 2, 55, 60), sample(3, rules.OHLC{Open: 109, High: 120, Low: 108, Close: 119}, 3, 1, 60, 55)}
	for i := range seq {
		v := &seq[i].Pub.Frame.Frame.Technical
		v.EMA21 = value(105)
		v.Gap = value(5)
		v.EMA8Delta = value(1)
		v.EMA21Delta = value(.5)
	}
	a := newDetector(Scene{Session: "人工", ForceClose: 9999})
	b := newDetector(Scene{Session: "鏡像", ForceClose: 9999})
	for i, q := range seq {
		a.step(q)
		b.step(mirror(q))
		if i < 2 && len(a.Events) != 0 {
			t.Fatal("T途中出生")
		}
	}
	if len(a.Events) != 1 || len(b.Events) != 1 || a.Events[0].Pattern != "T" || b.Events[0].Side != -1 {
		t.Fatal("T未成立又は鏡像差")
	}
	if a.Events[0].RoleMask["upper15"] != nil {
		t.Fatal("未知上位を同向へ補完")
	}
	c := newDetector(Scene{Session: "上位反対", ForceClose: 9999})
	for _, q := range seq {
		opp := q.Pub
		opp.Frame.Frame.Technical = mirror(q).Pub.Frame.Frame.Technical
		opp.Frame.Frame.Width = 900
		q.View.Frames = map[int]rules.Publication{900: opp}
		c.step(q)
	}
	if len(c.Events) != 0 {
		t.Fatal("上位既知反対を突破")
	}
}
