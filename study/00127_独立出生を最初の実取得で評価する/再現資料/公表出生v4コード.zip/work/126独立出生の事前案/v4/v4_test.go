package main

import (
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"testing"
)

// TestLocalRangeRecoveryWithOneMomentum は、Q二足回復・OR勢い・弱量と鏡像を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestLocalRangeRecoveryWithOneMomentum(t *testing.T) {
	seq := []Snap{}
	for n := 1; n <= 6; n++ {
		q := sample(n, rules.OHLC{Open: 110, High: 120, Low: 100, Close: 110}, 0, 0, 50, 50)
		q.Pub.Frame.Frame.VolumeKnown = true
		q.Pub.Frame.Frame.Volume = 100
		seq = append(seq, q)
	}
	seq = append(seq, sample(7, rules.OHLC{Open: 105, High: 111, Low: 101, Close: 108}, 0, 1, 40, 41), sample(8, rules.OHLC{Open: 109, High: 116, Low: 107, Close: 114}, 0, 1, 41, 40))
	a := newDetector(Scene{Session: "局所Q", ForceClose: 9999})
	b := newDetector(Scene{Session: "局所Q鏡像", ForceClose: 9999})
	for i, q := range seq {
		q.Pub.Frame.Frame.VolumeKnown = true
		q.Pub.Frame.Frame.Volume = 100
		q.View.RVOL5 = value(.25)
		a.step(q)
		b.step(mirror(q))
		if i < 7 && (len(a.Events) != 0 || len(b.Events) != 0) {
			t.Fatal("Q同足又は中間出生")
		}
	}
	if len(a.Events) != 1 || len(b.Events) != 1 || a.Events[0].Pattern != "Q" || a.Events[0].Side != 1 || b.Events[0].Side != -1 {
		t.Fatal("Q/鏡像出生差")
	}
	m := a.Events[0].RoleMask
	if m["rsi_delta_pass"] != true || m["hist_delta_pass"] != false || m["volume_very_weak"] != true || m["momentum_rule"] != "OR" {
		t.Fatal("Q役割の誤表示")
	}
	q := seq[7]
	q.Pub.Frame.Frame.Technical.Gap = value(-5)
	q.Pub.Frame.Frame.Technical.EMA8Delta = value(-1)
	q.Pub.Frame.Frame.Technical.EMA21Delta = value(-1)
	q.Pub.Frame.DMI.ADX = value(30)
	q.Pub.Frame.DMI.PreviousADX = value(29)
	if !strongCounter(q, 1) {
		t.Fatal("強い逆トレンドを無視")
	}
}

// TestBackgroundPersistsAfterOldSetupInvalid は、旧I失効後の新押戻しを因果的に保存します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestBackgroundPersistsAfterOldSetupInvalid(t *testing.T) {
	seq := []Snap{sample(1, rules.OHLC{Open: 110, High: 115, Low: 109, Close: 114}, 2, 1, 60, 55), sample(2, rules.OHLC{Open: 112, High: 113, Low: 106, Close: 108}, 1, 2, 55, 60), sample(3, rules.OHLC{Open: 108, High: 111, Low: 100, Close: 105}, 1, 2, 54, 55), sample(4, rules.OHLC{Open: 108, High: 120, Low: 103, Close: 117}, 3, 1, 60, 55)}
	for i := range seq {
		v := &seq[i].Pub.Frame.Frame.Technical
		v.EMA21 = value(105)
		v.Gap = value(5)
		v.EMA8Delta = value(1)
		v.EMA21Delta = value(.5)
	}
	seq[2].Pub.Frame.Frame.Technical.EMA8Delta = value(-1)
	seq[3].Pub.Frame.Frame.Technical.EMA8Delta = value(-.1)
	d := newDetector(Scene{Session: "背景持続", ForceClose: 9999})
	for i, q := range seq {
		d.step(q)
		if i == 2 {
			w := d.Slots["T/1/"]
			if w.Phase != 2 || w.Second.Pub.Frame.Frame.ID != seq[2].Pub.Frame.Frame.ID || w.Invalidation != 95 {
				t.Fatal("失効足で新setupを保存しない")
			}
			if len(d.Events) != 0 {
				t.Fatal("新setupを同足成功へすり替え")
			}
		}
	}
	if len(d.Events) != 1 || d.Events[0].Pattern != "T" || d.Events[0].RoleMask["T_path"] != "background_persist" {
		t.Fatal("背景持続からの次足確認未成立")
	}
}
