package main

import (
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"testing"
)

// TestSameBarRejectionNextBarBirth は、侵入とClose回復を同足、出生を次足へ分けます。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestSameBarRejectionNextBarBirth(t *testing.T) {
	seq := []Snap{}
	for n := 1; n <= 3; n++ {
		seq = append(seq, sample(n, rules.OHLC{Open: 110, High: 112, Low: 109, Close: 110}, 0, 0, 50, 50))
	}
	seq = append(seq, sample(4, rules.OHLC{Open: 100, High: 116, Low: 100, Close: 115}, -1, -2, 40, 35), sample(5, rules.OHLC{Open: 116, High: 124, Low: 113, Close: 123}, 0, -1, 45, 40))
	a := newDetector(Scene{Session: "人工v2", ForceClose: 9999})
	b := newDetector(Scene{Session: "鏡像v2", ForceClose: 9999})
	for i, q := range seq {
		q.View.RVOL5 = value(.5)
		a.step(q)
		b.step(mirror(q))
		if i < 4 && (len(a.Events) > 0 || len(b.Events) > 0) {
			t.Fatal("拒否と同足で出生")
		}
	}
	if len(a.Events) != 1 || len(b.Events) != 1 || a.Events[0].Side != 1 || b.Events[0].Side != -1 {
		t.Fatal("二段階/鏡像出生差")
	}
	if a.Events[0].RoleMask["volume_weak"] != true || a.Events[0].RoleMask["two_stage_recovery"] != true {
		t.Fatal("弱量/段階mask差")
	}
}

// TestVolumeFloorAndFastEMATemporaryChange は、量閾値と短期傾きの一時変化を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestVolumeFloorAndFastEMATemporaryChange(t *testing.T) {
	q := sample(1, rules.OHLC{Open: 100, High: 110, Low: 99, Close: 108}, 2, 1, 60, 55)
	q.View.RVOL5 = value(.499)
	if common(q) {
		t.Fatal("量下限違反")
	}
	q.View.RVOL5 = rules.Value{}
	if common(q) {
		t.Fatal("量未知を支持")
	}
	q.View.RVOL5 = value(.5)
	if !common(q) {
		t.Fatal("量下端が除外")
	}
	seq := []Snap{sample(1, rules.OHLC{Open: 110, High: 115, Low: 109, Close: 114}, 2, 1, 60, 55), sample(2, rules.OHLC{Open: 112, High: 113, Low: 106, Close: 108}, 1, 2, 55, 60), sample(3, rules.OHLC{Open: 109, High: 120, Low: 108, Close: 119}, 3, 1, 60, 55)}
	for i := range seq {
		v := &seq[i].Pub.Frame.Frame.Technical
		v.EMA21 = value(105)
		v.Gap = value(5)
		v.EMA8Delta = value(1)
		v.EMA21Delta = value(.5)
	}
	seq[2].Pub.Frame.Frame.Technical.EMA8Delta = value(-.1)
	d := newDetector(Scene{Session: "短期傾き一時逆", ForceClose: 9999})
	for _, v := range seq {
		d.step(v)
	}
	if len(d.Events) != 1 || d.Events[0].Pattern != "T" {
		t.Fatal("EMA8傾きだけで背景を永久失効")
	}
}
