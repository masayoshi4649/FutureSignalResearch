"""v3を変更せず、T背景cacheと独立Qを事前仕様どおり別ソースへ追加する。"""
from pathlib import Path
import hashlib
import json

OWN=Path(__file__).resolve().parent


def once(text: str, old: str, new: str) -> str:
    """
    機能: 一箇所だけを置換する。
    引数: text/old/new(str)。返り値: str。
    """
    assert text.count(old)==1,old
    return text.replace(old,new)


# ----------------------------------------
def main() -> None:
    """
    機能: 固定v3からv4ソースを作る。Input/Raw/勝敗未読。
    引数: なし。返り値: None。
    """
    fixed=json.loads((OWN/'固定_v3.json').read_text(encoding='utf-8')); source=OWN/'v3/main.go'
    assert hashlib.sha256(source.read_bytes()).hexdigest()==fixed['コード文書']['work\\126独立出生の事前案\\v3\\main.go']
    target=OWN/'v4';target.mkdir(exist_ok=False);text=source.read_text(encoding='utf-8')
    text=once(text,'type Wait struct {','type Wait struct {\n ContactMask map[string]any')
    text=once(text,'type Detector struct {','type Detector struct {\n Background map[int]Snap')
    text=once(text,'return &Detector{Scene: scene,','return &Detector{Background:map[int]Snap{},Scene: scene,')
    text=text.replace('d.History = nil','d.History = nil;d.Background=map[int]Snap{}')
    text=once(text,'if len(d.History) > 6 {\n\t\td.History = d.History[len(d.History)-6:]','if len(d.History) > 7 {\n\t\td.History = d.History[len(d.History)-7:]')
    text=once(text,'d.Stats["評価5分"]++','d.Stats["評価5分"]++;defer d.refreshBackground(q)')
    text=once(text,'for _, pattern := range []string{"R", "T", "S"}','for _, pattern := range []string{"R", "T", "S", "Q"}')
    text=once(text,'if pattern == "S" {\n\t\t\t\td.stepS','if pattern=="Q" {d.stepQ(key,side,w,q);continue}\n\t\t\tif pattern == "S" {\n\t\t\t\td.stepS')
    text=once(text,'if pattern == "R" && armR2(w, q, side, d.History) {','if pattern=="T"&&d.rearmPullback(w,q,side) {d.Stats[key+"持続背景の新押戻し"]++;continue}\n\t\t\t\tif pattern == "R" && armR2(w, q, side, d.History) {')
    text=once(text,'refs := append([]rules.Ref(nil), q.View.Refs...)','refs := append([]rules.Ref(nil), q.View.Refs...)\n if pattern=="T" {mask["T_path"]=w.Path}\n if pattern=="Q" {refs=append(refs,w.RangeRefs...);mask["range_low"]=w.RangeLow;mask["range_high"]=w.RangeHigh;mask["contact_regime"]=w.ContactMask;mask["momentum_rsi_macd"]=nil;mask["momentum_rule"]="OR";mask["volume_very_weak"]=q.View.RVOL5.Value<.5;mask["rsi_delta_known"]=known(t.RSI,t.PreviousRSI);mask["hist_delta_known"]=known(t.Histogram,t.PreviousHistogram);mask["rsi_delta_pass"]=known(t.RSI,t.PreviousRSI)&&float64(side)*(t.RSI.Value-t.PreviousRSI.Value)>0;mask["hist_delta_pass"]=known(t.Histogram,t.PreviousHistogram)&&float64(side)*(t.Histogram.Value-t.PreviousHistogram.Value)>0}')
    text=text.replace('条件_v3.md','条件_v4.md').replace('出生カウント_v3.json','出生カウント_v4.json')
    text=once(text,'"S": per["S"],','"S": per["S"],"Q":per["Q"],')
    text=once(text,'R%d/T%d/S%d、イベント%d','R%d/T%d/S%d/Q%d、イベント%d')
    text=once(text,'counts["S"], len(all)','counts["S"],counts["Q"], len(all)')
    text+='''
// persistent は、短期傾きの一時変化と背景の消失を区別します。
//
// 引数: q(Snap)、side(int)。返り値: boolです。
func persistent(q Snap,side int) bool {t:=q.Pub.Frame.Frame.Technical;s:=float64(side);ok,_:=upper(q,side);return known(t.Gap,t.EMA21Delta)&&s*t.Gap.Value>0&&s*t.EMA21Delta.Value>=0&&ok}

// refreshBackground は、当足の全判定後にだけ背景cacheを更新します。
//
// 引数: q(Snap)。返り値: ありません。
func (d *Detector) refreshBackground(q Snap) {
 for _,side:=range []int{1,-1} {if !persistent(q,side) {delete(d.Background,side);continue};w:=&Wait{};if armT(w,q,side) {d.Background[side]=q} else if old,ok:=d.Background[side];ok&&q.Pub.Frame.Frame.End-old.Pub.Frame.Frame.End>1800 {delete(d.Background,side)}}
}

// rearmPullback は、前足までの背景を使い当足を新しい押戻しへ保存します。
//
// 引数: w(*Wait)、q(Snap)、side(int)。返り値: boolです。
func (d *Detector) rearmPullback(w *Wait,q Snap,side int) bool {
 old,ok:=d.Background[side];if !ok||!persistent(q,side)||len(d.History)<2 {return false};delta:=q.Pub.Frame.Frame.End-old.Pub.Frame.Frame.End
 if delta<=0||delta>1800||!pullback(q,d.History[len(d.History)-2],side) {return false}
 w.First=old;second(w,q,side,false);w.Path="background_persist";return true
}

// strongCounter は、既知の強く非減速な逆向きトレンドを拒否します。
//
// 引数: q(Snap)、side(int)。返り値: boolは逆張り拒否です。
func strongCounter(q Snap,side int) bool {
 frames:=[]rules.Publication{q.Pub};if p,ok:=q.View.Frames[1800];ok&&p.Frame.Frame.PriceKnown {frames=append(frames,p)}
 for _,p:=range frames {dir,k:=direction(p.Frame.Frame.Technical);a:=p.Frame.DMI;if k&&dir==-side&&known(a.ADX,a.PreviousADX)&&a.ADX.Value>=25&&a.ADX.Value>=a.PreviousADX.Value {return true}}
 return false
}

// weak は、局所の方向の弱さを既知値だけから判定します。
//
// 引数: q(Snap)。返り値: boolとmapは成立と各当時maskです。
func weak(q Snap) (bool,map[string]any) {
 t:=q.Pub.Frame.Frame.Technical;a:=q.Pub.Frame.DMI
 gap:=known(t.Gap,t.ATR)&&t.ATR.Value>0&&math.Abs(t.Gap.Value)<=.5*t.ATR.Value
 low:=a.ADX.Known&&a.ADX.Value<=20;fall:=known(a.ADX,a.PreviousADX)&&a.ADX.Value<a.PreviousADX.Value
 return gap||low||fall,map[string]any{"gap_compressed":gap,"adx5_low":low,"adx5_falling":fall,"adx5_known":a.ADX.Known}
}

// armQ は、前6本レンジ内の接触と拒否足を保存します。
//
// 引数: w(*Wait)、q(Snap)、side(int)、history([]Snap)。返り値: boolです。
func armQ(w *Wait,q Snap,side int,history []Snap) bool {
 if len(history)<7||strongCounter(q,side) {return false};f:=q.Pub.Frame.Frame;t:=f.Technical;ok,mask:=weak(q)
 if !ok||!t.ATR.Known||t.ATR.Value<=0||!rejection(f.OHLC,side) {return false}
 lo,hi:=math.Inf(1),math.Inf(-1);refs:=[]rules.Ref{}
 for _,v:=range history[len(history)-7:len(history)-1] {o:=v.Pub.Frame.Frame.OHLC;lo=math.Min(lo,o.Low);hi=math.Max(hi,o.High);refs=append(refs,reference(v))}
 if hi<=lo||f.OHLC.Close<lo||f.OHLC.Close>hi {return false}
 contact:=(side>0&&f.OHLC.Low<=lo+.2*(hi-lo))||(side<0&&f.OHLC.High>=hi-.2*(hi-lo));if !contact {return false}
 w.First=q;w.Second=q;w.Phase=2;w.RangeLow=lo;w.RangeHigh=hi;w.RangeRefs=refs;w.ContactMask=mask;w.Trigger=f.OHLC.Close+float64(side)*5;w.Invalidation=f.OHLC.Low-5;if side<0 {w.Invalidation=f.OHLC.High+5};return true
}

// confirmQ は、二足の回復とRSI又はHist改善、既知正量を確認します。
//
// 引数: w(*Wait)、q(Snap)、side(int)。返り値: boolです。
func confirmQ(w *Wait,q Snap,side int) bool {
 f:=q.Pub.Frame.Frame;t:=f.Technical;s:=float64(side);v:=q.View.RVOL5
 rsi:=known(t.RSI,t.PreviousRSI)&&s*(t.RSI.Value-t.PreviousRSI.Value)>0;hist:=known(t.Histogram,t.PreviousHistogram)&&s*(t.Histogram.Value-t.PreviousHistogram.Value)>0
 if strongCounter(q,side)||!rsi&&!hist||!known(t.ATR,t.PreviousATR,t.TR,v)||t.ATR.Value<=0||t.PreviousATR.Value<=0||t.TR.Value<0||t.TR.Value>2*t.PreviousATR.Value||!f.VolumeKnown||f.Volume<=0||v.Value<=0||v.Value>1.5 {return false}
 if f.OHLC.Close<w.RangeLow||f.OHLC.Close>w.RangeHigh {return false};delta:=s*(f.OHLC.Close-w.Trigger);risk:=s*(f.OHLC.Close-w.Invalidation)
 return delta>=0&&delta<=.5*t.ATR.Value&&risk>=10&&risk<=1.5*t.ATR.Value
}

// stepQ は、旧setup失効後も当足を新接触として再評価します。
//
// 引数: key(string)、side(int)、w(*Wait)、q(Snap)。返り値: ありません。
func (d *Detector) stepQ(key string,side int,w *Wait,q Snap) {
 f:=q.Pub.Frame.Frame
 if w.Phase>0&&f.End-w.First.Pub.Frame.Frame.End>300 {clear(w);d.Stats[key+"失効"]++}
 if w.Phase==2&&((side>0&&f.OHLC.Low<=w.Invalidation)||(side<0&&f.OHLC.High>=w.Invalidation)) {clear(w);d.Stats[key+"構造失効"]++}
 if w.Phase==0 {if w.LastBirth>0&&q.Pub.Stamp.Time-w.LastBirth<600 {return};if armQ(w,q,side,d.History) {d.Stats[key+"接触拒否"]++};return}
 if f.End-w.First.Pub.Frame.Frame.End==300 {if confirmQ(w,q,side) {d.emit(key,"Q",side,w,q)} else {clear(w);d.Stats[key+"確認未成立"]++;if armQ(w,q,side,d.History) {d.Stats[key+"接触拒否"]++}}}
}
'''
    (target/'main.go').write_text(text,encoding='utf-8',newline='\n')
    for name in ('main_test.go','v2_test.go','v3_test.go'): (target/name).write_bytes((OWN/'v3'/name).read_bytes())
    module=(OWN/'v3/go.mod').read_text(encoding='utf-8').replace('independentbirthproposal126v3','independentbirthproposal126v4')
    (target/'go.mod').write_text(module,encoding='utf-8',newline='\n')
    print('v4ソースを作成。Input/Raw/勝敗は未読。')


if __name__=='__main__':
    main()
