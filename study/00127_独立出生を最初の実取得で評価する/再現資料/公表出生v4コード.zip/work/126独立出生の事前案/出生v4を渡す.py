"""固定v4をRaw再生schemaへ転記し、背景手順とQのカバレッジを分ける。"""
from pathlib import Path
from collections import Counter
import hashlib
import json

OWN=Path(__file__).resolve().parent
ROOT=OWN.parents[1]


def sha(path: Path) -> str:
    """
    機能: 全bytesのSHA256を返す。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path, value: dict) -> None:
    """
    機能: 新規先へUTF-8 JSONを保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


# ----------------------------------------
def number(saved: dict) -> float | None:
    """
    機能: 既知値だけを返す。
    引数: saved(dict)。返り値: float | None。
    """
    return saved['value'] if saved['known'] else None


# ----------------------------------------
def frame_mask(publication: dict | None) -> dict:
    """
    機能: 参照済み5/15/30公表の背景既知maskを転記する。
    引数: publication(dict | None)。返り値: dict。
    """
    if publication is None: return {'available':False,'ma_direction':None,'adx':None,'adx_falling':None}
    f=publication['frame']['frame']; t=f['technical']; a=publication['frame']['dmi']
    terms=[number(t[k]) for k in ('gap','ema8_delta','ema21_delta')]
    direction=None
    if all(v is not None for v in terms):
        signs={1 if v>0 else -1 if v<0 else 0 for v in terms};direction=next(iter(signs)) if len(signs)==1 and 0 not in signs else 0
    adx,previous=number(a['adx']),number(a['previous_adx'])
    return {'available':True,'ref_id':f['id'],'price_known':f['price_known'],'ma_known':sum(v is not None for v in terms),'ma_direction':direction,
            'adx':adx,'previous_adx':previous,'adx_falling':None if adx is None or previous is None else adx<previous}


# ----------------------------------------
def main() -> None:
    """
    機能: 650出生を保持しmetadataだけを整え、全73場を比較する。
    引数: なし。返り値: None。Input公表だけを結合しRaw/Source/勝敗を読まない。
    """
    path=OWN/'v4/出生カウント_v4.json';assert sha(path)=='a7dd5a0eb710295ba4534c1ddbf87f66bca2c4ab5048a551f208083d9e743fc6'
    x=json.loads(path.read_text(encoding='utf-8'));fixed=json.loads((OWN/'固定_v4.json').read_text(encoding='utf-8'))
    for name,expected in {**fixed['コード文書'],**fixed['既存Bank依存']}.items(): assert sha(ROOT/name)==expected
    prior=json.loads((OWN/'v3/出生カウント_v3.json').read_text(encoding='utf-8'))
    assert [e for e in x['出生'] if e['pattern'] in ('R','S')]==[e for e in prior['出生'] if e['pattern'] in ('R','S')]
    input_path=ROOT/'work/122全場入力/入力.json';assert sha(input_path)==x['入力SHA256']
    source=json.loads(input_path.read_bytes());pubs={p['frame']['frame']['id']:p for scene in source['scenes'] for p in scene['publications']}
    assert len(pubs)==12794
    events=[];feasible=Counter()
    for e in x['出生']:
        refs={r['id']:r for r in e['frameRefs']+e['stage_refs']}; current={}
        for r in e['frameRefs']:
            if r['width_seconds'] not in current: current[r['width_seconds']]=pubs[r['id']]
        background={str(w//60):frame_mask(current.get(w)) for w in (300,900,1800)}
        side=e['side'];a=e['atr'];risk_cap=side*(e['entry_cap']-e['invalidation']);hold_risk=side*(e['trigger_level']-e['invalidation'])
        possible=max(10,hold_risk)<=min(125,1.5*a,risk_cap)
        feasible['可' if possible else 'Root追加125上限で不可']+=1
        assert 0<=side*(e['trigger_close']-e['trigger_level'])<=.5*a+1e-8
        assert 10-1e-8<=side*(e['trigger_close']-e['invalidation'])<=1.5*a+1e-8
        for r in refs.values():
            stamp=r['delivered'];assert stamp['time']<=e['pub_stamp']['time'] and stamp['index']<=e['pub_stamp']['index'] and stamp['source_line']<=e['pub_stamp']['source_line']
        events.append({'session':e['session'],'id':'v4/'+e['id'],'mode':e['pattern'],'side':side,'at':e['pub_stamp'],'entry_cap':e['entry_cap'],'invalidation':e['invalidation'],'atr5':a,
                       'hold_boundary':e['trigger_level'],'hold_minimum':0,'refs':list(refs.values()),
                       'fields':{'source_id':e['id'],'confirm_close':e['trigger_close'],'confirm_level':e['trigger_level'],'risk_min':10,'risk_max':1.5*a,'entry_ttl_seconds':30,
                          'stage_refs':e['stage_refs'],'background_5_15_30':background,'root_extra_risk125_feasible':possible,**e['role_mask']}})
    assert len(events)==650 and len({e['id'] for e in events})==650
    def coverage(label: str, subset: list[dict]) -> dict:
        """
        機能: 同じ全73場を分母に出生有無を数える。
        引数: label(str)、subset(list[dict])。返り値: dict。
        """
        active={e['session'] for e in subset}
        return {'比較':label,'出生数':len(subset),'出生有場':len(active),'出生0場':[s['session'] for s in x['全セッション'] if s['session'] not in active]}
    comparison=[coverage('v3固定R/T/S',prior['出生']),coverage('v3固定R/T/S+Q',prior['出生']+[e for e in x['出生'] if e['pattern']=='Q']),
                coverage('T背景手順だけ変更R/T新/S',[e for e in x['出生'] if e['pattern']!='Q']),coverage('v4全R/T新/S/Q',x['出生'])]
    target=OWN/'出生イベント_v4.json'
    save(target,{'success':True,'version':'v4','source_sha256':sha(path),'fixed_sha256':sha(OWN/'固定_v4.json'),'spec_sha256':fixed['条件SHA256'],'input_sha256':x['入力SHA256'],
                 'financial_labels_used':False,'raw_read':False,'actual_fills_tested':False,'events':events,'all_sessions':x['全セッション'],'coverage_comparison':comparison,
                 'birth_covered_sessions':73,'zero_birth_sessions':[],'root_extra_risk125_feasibility':dict(feasible),
                 'price_note':'atはpub配送stamp。confirm_closeは確定足終値で当RawLast/取得価格ではない。',
                 'execution_note':'K+.5ATR/hold K0/birth risk10〜1.5ATR。Rootは別の追加上限min125,1.5ATRを適用し未請求も保持。'})
    rows='\n'.join(f"|{s['session']}|{s['R']}|{s['T']}|{s['S']}|{s['Q']}|{s['出生数']}|" for s in x['全セッション'])
    comps='\n'.join(f"|{v['比較']}|{v['出生数']}|{v['出生有場']}|{len(v['出生0場'])}|" for v in comparison)
    qweak=Counter('0<RVOL<.5' if e['role_mask']['volume_very_weak'] else '.5<=RVOL<1' if e['role_mask']['volume_weak'] else '1<=RVOL<=1.5' for e in x['出生'] if e['pattern']=='Q')
    text=f'''# v4：全場にpub出生、実取得と精度は未評価

2026-11-11。同じ12794公表を因果配送し、**R147/T50/S89/Q364=650候補、全73/73場に出生**した。Raw/Source79/金融ラベル未使用。ここで達成したのは候補の存在であり、実BBO取得・先着70%・利益を達成したわけではない。全場最低1取得は次の再生で検証する。

## 手順と状態を分けた比較

|比較|出生数|出生有場/73|出生0場|
|---|---:|---:|---:|
{comps}

T背景手順変更だけでも、Q追加だけでも出生が全場へ届いた。複数変更のどちらで精度が良くなったかは未評価で、出生数の比較を損益差へ読み替えない。R/Sの全236イベントはv3と値・順序同体。新Tは50例で旧45例の単純な上位集合とは仮定しない。

Q364例の量区分は`{dict(qweak)}`。0.5未満の弱量も含むため、強い出来高確認で全場を覆えたとは言わない。RSI又はHistΔのORと各known/pass、5/15/30のMA/ADX既知maskを保存した。整場Nightの2020pt幅やADX中央値はsignalへ使用していない。

## 全73場

|場|R|T|S|Q|合計|
|---|---:|---:|---:|---:|---:|
{rows}

## 引渡しと境界

[条件](条件_v4.md)、[固定](固定_v4.json)、[元650出生/73場](v4/出生カウント_v4.json)、[再生器schema](出生イベント_v4.json)。全段階・frame refsは配送stamp以前で、当時確認終値のcap/riskも一致確認した。Kの±5を二重に足さずhold_boundary=K/minimum0とする。

出生の構造距離上限は1.5ATR。Root追加の取得上限min(125,1.5ATR)を組み合わせるmetadata上の可否は`{dict(feasible)}`であり、不可能なものも出生母集団から落とさない。Raw再生では実Lastの維持、実BBO、1秒後原行/30秒TTL、品質を確認し、未請求・未取得・取消を全73場へ残す。
'''
    (OWN/'出生の可用性_v4.md').write_text(text,encoding='utf-8',newline='\n')
    save(OWN/'出生引渡しの確認_v4.json',{'成功':True,'条件コード前後不変':True,'v3_RS全件同体':True,'出生数':650,'出生有場':73,'出生0場':[],'比較':comparison,
                 '元SHA256':sha(path),'引渡しSHA256':sha(target),'Root追加125上限の両立':dict(feasible),'金融ラベル使用':False,'Raw読取':False})
    print(json.dumps({'成功':True,'引渡しSHA256':sha(target),'出生有場':73,'出生数':650,'取得追加上限':dict(feasible),'比較':comparison},ensure_ascii=False))


if __name__=='__main__':
    main()
