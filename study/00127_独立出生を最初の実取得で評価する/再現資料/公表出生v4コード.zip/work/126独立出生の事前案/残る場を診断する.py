"""金融ラベルなしで残るNightの整場特徴と当時レンジ接触だけを診断する。"""
from pathlib import Path
from statistics import median
from collections import Counter
import hashlib
import json

OWN=Path(__file__).resolve().parent
SOURCE=OWN.parent/'122全場入力/入力.json'
TARGET='2026-10-16_Night'


def value(saved: dict | None) -> float | None:
    """
    機能: 保存公表から既知値だけを返す。
    引数: saved(dict | None)。返り値: float | None。
    """
    return saved['value'] if saved and saved['known'] else None


# ----------------------------------------
def main() -> None:
    """
    機能: 全体値を事後記述し、signalには当時窓だけを使うと明示する。
    引数: なし。返り値: None。Raw/Source/勝敗/損益未読。
    """
    data=SOURCE.read_bytes(); expected='6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
    assert hashlib.sha256(data).hexdigest()==expected
    source=json.loads(data); windows={}; last={}; contract=None; rows=[]; contacts=Counter()
    for scene in source['scenes']:
        if contract!=scene['contract']: windows={}; last={}; contract=scene['contract']
        current={}; history=[]; selected=scene['session']==TARGET
        pubs=scene['publications'];i=0
        while i<len(pubs):
            stamp=pubs[i]['stamp']; group=[]
            while i<len(pubs) and pubs[i]['stamp']==stamp: group.append(pubs[i]);i+=1
            for p in group:
                f=p['frame']['frame'];w=f['width_seconds']; previous=last.get(w)
                if previous and previous['session_id']==f['session_id'] and f['end']-previous['end']!=w: windows[w]=[]
                window=windows.get(w,[])
                rv=None
                if len(window)==20 and f['volume_known'] and all(v is not None for v in window) and sum(window)>0: rv=f['volume']/(sum(window)/20)
                windows[w]=(window+[f['volume'] if f['volume_known'] else None])[-20:]
                last[w]=f;current[w]=(p,rv)
            for p in group:
                f=p['frame']['frame']
                if f['width_seconds']!=300 or not selected: continue
                if not f['price_known'] or stamp['time']>=f['end']+360: history=[];continue
                if history and f['end']-history[-1]['end']!=300: history=[]
                if stamp['time']>=scene['force_close']: continue
                t=f['technical'];a=value(t['atr']);adx=value(p['frame']['dmi']['adx']);oldadx=value(p['frame']['dmi']['previous_adx']);gap=value(t['gap'])
                upper={}
                for width in (900,1800):
                    pub=current.get(width); upper[str(width//60)]=None
                    if pub:
                        z=pub[0]['frame']['frame'];q=pub[0]['stamp']
                        if z['price_known'] and stamp['time']<z['end']+width+60 and q['time']<=stamp['time'] and q['index']<=stamp['index'] and q['source_line']<=stamp['source_line']:
                            upper[str(width//60)]=value(pub[0]['frame']['dmi']['adx'])
                row={'end':f['end'],'ohlc':f['ohlc'],'atr5':a,'adx5':adx,'adx5_delta':None if adx is None or oldadx is None else adx-oldadx,'gap_atr5':None if gap is None or a is None or a<=0 else gap/a,'rvol5':current[300][1],'adx15':upper['15'],'adx30':upper['30']}
                if len(history)>=6:
                    z=history[-6:];lo=min(v['ohlc']['low'] for v in z);hi=max(v['ohlc']['high'] for v in z);span=hi-lo
                    if span>0:
                        lower=f['ohlc']['low']<=lo+.2*span; upper_touch=f['ohlc']['high']>=hi-.2*span
                        contacts['当時6本レンジ評価']+=1;contacts['下20%接触']+=lower;contacts['上20%接触']+=upper_touch
                        contacts['下接触かつClose旧域内']+=lower and lo<=f['ohlc']['close']<=hi
                        contacts['上接触かつClose旧域内']+=upper_touch and lo<=f['ohlc']['close']<=hi
                rows.append(row);history.append(f);history=history[-6:]
        if selected: break
    assert len(rows)==153
    def summary(key: str) -> dict:
        """
        機能: 整場の既知/未知と中央値を記述する。
        引数: key(str)。返り値: dict。この中央値はsignalへ使わない。
        """
        values=[r[key] for r in rows if r[key] is not None]
        return {'known':len(values),'unknown':len(rows)-len(values),'min':min(values) if values else None,'median':median(values) if values else None,'max':max(values) if values else None}
    result={'成功':True,'場':TARGET,'入力SHA256':expected,'Raw読取':False,'金融ラベル使用':False,'Source79参照':False,'整場集計は事後診断のみ':True,'5分数':len(rows),
            '整場公表高安幅':max(r['ohlc']['high'] for r in rows)-min(r['ohlc']['low'] for r in rows),
            '要約':{k:summary(k) for k in ('atr5','adx5','adx5_delta','adx15','adx30','rvol5','gap_atr5')},
            '弱方向数':{'absGapATR<=.5':sum(r['gap_atr5'] is not None and abs(r['gap_atr5'])<=.5 for r in rows),'ADX5<=20':sum(r['adx5'] is not None and r['adx5']<=20 for r in rows),'ADX5低下':sum(r['adx5_delta'] is not None and r['adx5_delta']<0 for r in rows)},
            '当時レンジ接触':dict(contacts),'限界':'整場集計を当時signalへ使用しない。レンジ内往復の可能性を記述するだけで、取引優位の証明ではない。'}
    with (OWN/'残るNightの事後診断.json').open('x',encoding='utf-8',newline='\n') as stream: stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':
    main()
