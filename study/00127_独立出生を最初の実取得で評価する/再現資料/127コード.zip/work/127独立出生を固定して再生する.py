"""127の出生・取得・最初の取得選択を金融再生前に固定して検証する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parent.parent
OWN=ROOT/'work/127独立出生の評価'
ENGINE=ROOT/'work/独立出生の再生器'
AGGREGATE=ROOT/'work/127独立出生の集計'
FORMAL=ROOT/'study/00127_独立出生を最初の実取得で評価する'


def sha(path: Path) -> str:
    """
    機能: ファイル全体のSHA256を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path,value: dict) -> None:
    """
    機能: 未作成先だけへ固定記録を保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


# ----------------------------------------
def verify(fixed: dict) -> None:
    """
    機能: コード・入力・事前文書・実行物の同体を検査する。
    引数: fixed(dict)。返り値: None。
    """
    expected={**fixed['コード'],**fixed['入力'],**fixed['事前文書']}
    expected[fixed['実行ファイル']['path']]=fixed['実行ファイル']['sha256']
    assert all(sha(Path(p))==value for p,value in expected.items())


# ----------------------------------------
def main() -> None:
    """
    機能: 固定後だけRaw再生と集計を行い、出生と取得の場数を分ける。
    引数: CLI --mode(str、固定/再生/集計)。返り値: None。
    """
    parser=argparse.ArgumentParser(description='127独立出生の事前固定と再生')
    parser.add_argument('--mode',choices=('固定','再生','集計'),required=True)
    mode=parser.parse_args().mode
    f1=OWN/'F1.json'
    if mode=='固定':
        input_path=OWN/'入力.json'
        assert sha(input_path)=='b8f382b90f345c4e2c7085ad743c95bbfd887e0cb36ec1f704f848b148bc4e85'
        events=ROOT/'work/126独立出生の事前案/出生イベント_v4.json'
        assert sha(events)=='056ff7ef8f14d2660b7f3c7a442388695a83bcc880badee58fe4667aa1ca5c83'
        code=set()
        for folder in (OWN,ENGINE,AGGREGATE):
            code.update(p for p in folder.rglob('*') if p.is_file() and (p.suffix in ('.py','.go') or p.name=='go.mod'))
        code.update([Path(__file__).resolve(),ROOT/'work/124入口の原因分析/集計する.py'])
        docs=[FORMAL/'README.md',FORMAL/'設定と結果.md',AGGREGATE/'条件.md',ROOT/'work/126独立出生の事前案/条件_v4.md']
        assert all(p.is_file() for p in docs)
        exe=ENGINE/'独立出生の再生.exe'
        assert exe.is_file()
        f={'成功':True,'試行':127,'固定UTC':datetime.now(timezone.utc).isoformat(),'主政策':'F0','主幅pt':125,'主秒':3600,
           '主選択':'各場最初の実取得。同行R/T/S/Q→最小risk→異方向同riskは当Raw見送り→同方向ID順。',
           '目標':'全73場で最低1実取得代用、resolved順行率70%以上。complete率/未到達/不足も別掲。',
           '入力':{str(p):sha(p) for p in (input_path,events)},'コード':{str(p):sha(p) for p in sorted(code)},
           '事前文書':{str(p):sha(p) for p in docs},'実行ファイル':{'path':str(exe),'sha256':sha(exe)},
           '旧79入口の出生使用':False,'未知期間検証':False,'実口座収支':False}
        save(f1,f);print(json.dumps({'F1固定':True,'SHA256':sha(f1),'コード数':len(code)},ensure_ascii=False));return
    fixed=json.loads(f1.read_text(encoding='utf-8'));verify(fixed)
    output=OWN/'全73場の独立出生結果.json'
    if mode=='再生':
        assert not output.exists()
        command=[fixed['実行ファイル']['path'],'--input',str(OWN/'入力.json'),'--sha256',sha(OWN/'入力.json'),'--output',str(output),'--workers','8']
        subprocess.run(command,cwd=ENGINE,check=True);verify(fixed)
        data=json.loads(output.read_text(encoding='utf-8'))
        assert data['success'] and data['trial']==127 and len(data['scenes'])==73 and all(s['success'] for s in data['scenes'])
        save(OWN/'再生完了.json',{'成功':True,'試行':127,'F1_SHA256':sha(f1),'結果SHA256':sha(output),'コード入力文書前後同体':True,'コマンド':command})
        print(json.dumps({'再生完了':True,'SHA256':sha(output)},ensure_ascii=False));return
    done=json.loads((OWN/'再生完了.json').read_text(encoding='utf-8'))
    assert done['結果SHA256']==sha(output)
    command=[sys.executable,'-X','utf8',str(AGGREGATE/'集計する.py'),'--result',str(output),'--sha256',sha(output),'--input-sha256',sha(OWN/'入力.json')]
    subprocess.run(command,cwd=ROOT,check=True);verify(fixed)
    save(OWN/'段階実行完了.json',{'成功':True,'試行':127,'F1_SHA256':sha(f1),'集計SHA256':sha(AGGREGATE/'集計.json'),'表SHA256':sha(AGGREGATE/'CSV用の表.json'),'コード入力文書前後同体':True})


if __name__=='__main__':
    main()
