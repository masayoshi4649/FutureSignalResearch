"""勝敗未使用のv4出生と既存73場metadataから127の再生入力を再構成する。"""
from pathlib import Path
import argparse
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parents[2]


def main() -> None:
    """
    機能: 旧取得時刻を使わず、出生の公表stampと元の最小riskを保存する。
    引数: CLI --output(str)。返り値: None。既存入力は上書きしない。
    """
    parser=argparse.ArgumentParser(description='127独立出生入力の再構成')
    parser.add_argument('--output',required=True)
    output=Path(parser.parse_args().output)
    path=ROOT/'work/126独立出生の事前案/出生イベント_v4.json'
    raw=path.read_bytes()
    assert hashlib.sha256(raw).hexdigest()=='056ff7ef8f14d2660b7f3c7a442388695a83bcc880badee58fe4667aa1ca5c83'
    source=json.loads(raw)
    assert not source['financial_labels_used'] and not source['raw_read']
    base=ROOT/'work/124入口の原因分析/入力.json'
    data=base.read_bytes()
    assert hashlib.sha256(data).hexdigest()=='b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
    scenes=[]
    for scene in json.loads(data)['scenes']:
        row={k:scene[k] for k in ('session','contract','start','end','force_close','raw','expected_accepted','expected_quality')}
        events=[]
        for event in source['events']:
            if event['session']!=scene['session']: continue
            copied=dict(event);copied.pop('session')
            risk=event['fields']['risk_min']
            assert type(risk) in (int,float) and math.isfinite(risk) and risk>=0
            copied['minimum_risk']=risk;events.append(copied)
        events.sort(key=lambda e:(e['at']['source_line'],e['id']))
        assert events
        row['events']=events;scenes.append(row)
    assert len(scenes)==73 and sum(len(s['events']) for s in scenes)==650
    value={'trial':127,'source_events_sha256':hashlib.sha256(raw).hexdigest(),'source_version':'v4','source_entry_births_used':False,'scenes':scenes}
    encoded=(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n').encode('utf-8')
    assert hashlib.sha256(encoded).hexdigest()=='b8f382b90f345c4e2c7085ad743c95bbfd887e0cb36ec1f704f848b148bc4e85'
    with output.open('xb') as stream: stream.write(encoded)
    print(json.dumps({'成功':True,'SHA256':hashlib.sha256(encoded).hexdigest(),'bytes':len(encoded)},ensure_ascii=False))


if __name__=='__main__':
    main()
