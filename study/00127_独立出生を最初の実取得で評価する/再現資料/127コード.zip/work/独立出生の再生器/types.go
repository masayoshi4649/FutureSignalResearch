// Package holdingohlc113 は実保有区間だけの原板OHLCと到達原行を独立に集計します。
package holdingohlc113

type FileRef struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
}

type Quote struct {
	Clock      string  `json:"clock,omitempty"`
	Time       float64 `json:"time"`
	Index      int64   `json:"index"`
	SourceLine int64   `json:"source_line"`
	Last       float64 `json:"last"`
	Bid        float64 `json:"bid"`
	Ask        float64 `json:"ask"`
	QuoteOK    bool    `json:"quote_ok"`
}

type PriceInterval struct {
	ID             string `json:"price_interval_id"`
	Session        string `json:"session"`
	Start          Quote  `json:"start_quote"`
	End            Quote  `json:"end_quote"`
	StartInclusive bool   `json:"start_inclusive"`
	EndInclusive   bool   `json:"end_inclusive"`
}

type Threshold struct {
	ID       string  `json:"id"`
	WholeYen float64 `json:"whole_yen"`
	Strict   bool    `json:"strict"`
}

type StateSlice struct {
	ID         string      `json:"query_id"`
	IntervalID string      `json:"price_interval_id"`
	Side       int         `json:"side"`
	EntryPrice float64     `json:"entry_price"`
	N          int         `json:"n"`
	R          float64     `json:"R"`
	K          float64     `json:"K"`
	Q0         int         `json:"q0"`
	Thresholds []Threshold `json:"thresholds"`
}

// Ledger は台帳側の他fieldを変更せず、価格区間と金融queryだけを読みます。
type Ledger struct {
	PriceIntervals  []PriceInterval  `json:"price_intervals"`
	StateSlices     []StateSlice     `json:"state_slices"`
	WitnessRequests []WitnessRequest `json:"witness_requests"`
}

type Counts struct {
	Lines           int64 `json:"lines"`
	ClockMissing    int64 `json:"clock_missing"`
	ClockInvalid    int64 `json:"clock_invalid"`
	Outside         int64 `json:"outside_session"`
	Backward        int64 `json:"backward_clock"`
	LastNonPositive int64 `json:"last_non_positive"`
	LastNonFinite   int64 `json:"last_non_finite"`
	BadBBO          int64 `json:"bad_bbo"`
	Accepted        int64 `json:"source_parser_accepted"`
	CutoffExcluded  int64 `json:"cutoff_excluded"`
	Delivered       int64 `json:"source_delivered"`
}

type Point struct {
	Value float64 `json:"value"`
	Quote Quote   `json:"quote"`
}

type Extreme struct {
	Value float64 `json:"value"`
	First Quote   `json:"first"`
	Last  Quote   `json:"last"`
}

type Series struct {
	Count int64    `json:"count"`
	Open  *Point   `json:"open"`
	High  *Extreme `json:"high"`
	Low   *Extreme `json:"low"`
	Close *Point   `json:"close"`
}

type PriceResult struct {
	Interval     PriceInterval    `json:"interval"`
	StartMatched bool             `json:"start_matched"`
	EndMatched   bool             `json:"end_matched"`
	RawRows      int64            `json:"raw_rows"`
	AcceptedRows int64            `json:"accepted_rows"`
	Excluded     map[string]int64 `json:"excluded"`
	BadBBORows   int64            `json:"bad_bbo_rows"`
	Last         Series           `json:"last"`
	Bid          Series           `json:"bid"`
	Ask          Series           `json:"ask"`
}

type ThresholdResult struct {
	Threshold Threshold `json:"threshold"`
	First     *Point    `json:"first"`
}

type StateResult struct {
	Query        StateSlice        `json:"query"`
	BadBBORows   int64             `json:"bad_bbo_rows"`
	WholeYen     Series            `json:"whole_yen"`
	Thresholds   []ThresholdResult `json:"thresholds"`
	WholeReturns Returns           `json:"whole_returns"`
	UnitReturns  Returns           `json:"unit_returns"`
}

// Returns は当状態片内の最初の正益と、非正/赤字への戻りの証拠だけです。
type Returns struct {
	FirstPositive                 *Point `json:"first_positive"`
	FirstNonpositive              *Point `json:"first_nonpositive"`
	FirstNegative                 *Point `json:"first_negative"`
	FirstNonpositiveAfterPositive *Point `json:"first_nonpositive_after_positive"`
	FirstNegativeAfterPositive    *Point `json:"first_negative_after_positive"`
}

type FileStat struct {
	Bytes     int64 `json:"bytes"`
	ModTimeNS int64 `json:"mtime_ns"`
}

type Scene struct {
	Session         string           `json:"session"`
	Contract        string           `json:"contract"`
	Start           float64          `json:"start"`
	End             float64          `json:"end"`
	Cutoff          float64          `json:"cutoff"`
	Raw             FileRef          `json:"raw"`
	RawBytes        int64            `json:"raw_bytes"`
	PriceIntervals  []PriceInterval  `json:"price_intervals"`
	StateSlices     []StateSlice     `json:"state_slices"`
	WitnessRequests []WitnessRequest `json:"witness_requests"`
}

type SceneResult struct {
	Version                      int                      `json:"version"`
	Trial                        int                      `json:"trial"`
	SourceTrial                  int                      `json:"source_trial"`
	Success                      bool                     `json:"success"`
	Session                      string                   `json:"session"`
	Raw                          FileRef                  `json:"raw"`
	ActualSHA256                 string                   `json:"actual_sha256"`
	CompressedBytes              int64                    `json:"compressed_bytes"`
	Before                       FileStat                 `json:"stat_before"`
	After                        FileStat                 `json:"stat_after"`
	Quality                      Counts                   `json:"quality"`
	Contracts                    []string                 `json:"contracts"`
	PriceIntervals               map[string]PriceResult   `json:"price_intervals"`
	StateQueries                 map[string]StateResult   `json:"state_queries"`
	Witnesses                    map[string]WitnessResult `json:"witnesses"`
	ClockBasis                   string                   `json:"clock_basis"`
	PayloadCumulativeHighLowUsed bool                     `json:"payload_cumulative_high_low_used"`
	RawPasses                    int                      `json:"raw_passes"`
}

type WitnessRequest struct {
	ID         string `json:"witness_id"`
	Session    string `json:"session"`
	Index      int64  `json:"index"`
	SourceLine int64  `json:"source_line"`
}
type WitnessResult struct {
	Request      WitnessRequest `json:"request"`
	Found        bool           `json:"found"`
	IndexMatched bool           `json:"index_matched"`
	Quote        Quote          `json:"quote"`
}
