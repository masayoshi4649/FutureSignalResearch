package holdingohlc113

import "testing"

// TestMinimumRiskMirror127 は入力で指定した最小距離を実取得側でも守ることを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestMinimumRiskMirror127(t *testing.T) {
	for _, reverse := range []bool{false, true} {
		for _, risk := range []float64{5, 10} {
			q := artificialQuote127(100, 0, 995, 1000, 1000)
			e := artificialBirth127(q)
			e.HoldBoundary = 1000
			e.EntryCap = 1050
			e.MinimumRisk = 10
			e.Invalidation = 1010 - risk
			fill := artificialQuote127(101, 1, 1000, 1010, 1000)
			if reverse {
				e = mirrorBirth127(e, 3000)
				q = mirrorQuote127(q, 3000)
				fill = mirrorQuote127(fill, 3000)
			}
			s := Scene127{Start: 90, End: 5000, ForceClose: 4900, ExpectedAccepted: 10, Events: []Birth127{e}}
			if _, err := validateBirths127(s); err != nil {
				t.Fatal(err)
			}
			r := request127(e, q, 4900)
			got := pendingBirth127(r, fill, 4900)
			if got != (risk == 10) {
				t.Fatalf("最小riskの鏡像/包含境界差:%t %g %s", reverse, risk, r.Status)
			}
		}
	}
}
