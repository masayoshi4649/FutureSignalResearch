package holdingohlc113

var Widths127 = []float64{25, 50, 100, 125, 200}
var Horizons127 = []float64{1800, 3600}

type FixedEntry127 struct {
	ID    string `json:"id"`
	Side  int    `json:"side"`
	Entry Quote  `json:"entry"`
}
type Scene127 struct {
	Session          string     `json:"session"`
	Contract         string     `json:"contract"`
	Start            float64    `json:"start"`
	End              float64    `json:"end"`
	ForceClose       float64    `json:"force_close"`
	Raw              FileRef    `json:"raw"`
	ExpectedAccepted int64      `json:"expected_accepted"`
	ExpectedQuality  *Counts    `json:"expected_quality"`
	Events           []Birth127 `json:"events"`
}
type Input127 struct {
	Scenes []Scene127 `json:"scenes"`
}
type Signal127 struct {
	ID    string  `json:"id"`
	Side  int     `json:"side"`
	Time  float64 `json:"time"`
	Index int64   `json:"index"`
	Line  int64   `json:"source_line"`
	Quote Quote   `json:"quote"`
}
type First127 struct {
	Width     float64 `json:"width"`
	Direction int     `json:"direction"`
	Quote     *Quote  `json:"quote"`
}
type Outcome127 struct {
	Seconds  float64    `json:"seconds"`
	Deadline float64    `json:"deadline"`
	Status   string     `json:"status"`
	Touches  []First127 `json:"touches"`
	Endpoint *Quote     `json:"endpoint"`
	Points   *float64   `json:"points"`
	Net0     *float64   `json:"net0"`
	Net5     *float64   `json:"net5"`
}
type Candidate127 struct {
	Status         string       `json:"status"`
	Axis           string       `json:"axis"`
	Birth          Signal127    `json:"birth"`
	Entry          *Quote       `json:"entry"`
	EntryPrice     *float64     `json:"entry_price"`
	LastNormalTime float64      `json:"last_normal_time"`
	Outcomes       []Outcome127 `json:"outcomes"`
}
type Case127 struct {
	SourceEvent   Birth127      `json:"source_event"`
	RequestQuote  *Quote        `json:"request_quote"`
	ID            string        `json:"id"`
	OriginalSide  int           `json:"original_side"`
	Original      *Candidate127 `json:"original"`
	Reverse       *Candidate127 `json:"reverse"`
	ChartOriginal *Candidate127 `json:"chart_original"`
	ChartReverse  *Candidate127 `json:"chart_reverse"`
}
type Result127 struct {
	Births          []*BirthResult127 `json:"births"`
	Session         string            `json:"session"`
	Success         bool              `json:"success"`
	Error           string            `json:"error,omitempty"`
	Raw             FileRef           `json:"raw"`
	ActualSHA       string            `json:"actual_sha256"`
	Before          FileStat          `json:"stat_before"`
	After           FileStat          `json:"stat_after"`
	RawEncoding     string            `json:"raw_encoding"`
	Quality         Counts            `json:"quality"`
	ExpectedQuality *Counts           `json:"expected_quality"`
	Cases           []*Case127        `json:"cases"`
	RawPasses       int               `json:"raw_passes"`
	SourceEntries   int               `json:"source_entries"`
}

// fixedCandidate127 は元の取得原行に正又は逆の取得価格を固定します。
//
// 引数: id(string)、side(int)、q(Quote)、chart(bool)。返り値: *Candidate127です。
func fixedCandidate127(id string, side int, q Quote, chart bool) *Candidate127 {
	price := q.Ask
	axis := "BBO"
	if side < 0 {
		price = q.Bid
	}
	if chart {
		price = q.Last
		axis = "Last価格方向診断"
	}
	x := q
	c := &Candidate127{Status: "filled", Axis: axis, Birth: Signal127{ID: id, Side: side, Time: q.Time, Index: q.Index, Line: q.SourceLine, Quote: q}, Entry: &x, EntryPrice: &price, LastNormalTime: q.Time, Outcomes: []Outcome127{}}
	for _, h := range Horizons127 {
		o := Outcome127{Seconds: h, Deadline: q.Time + h, Status: "pending", Touches: []First127{}}
		for _, w := range Widths127 {
			o.Touches = append(o.Touches, First127{Width: w})
		}
		c.Outcomes = append(c.Outcomes, o)
	}
	return c
}

// fixedCase127 は同じ取得原行のBBO正逆とLast参考正逆を一組にします。
//
// 引数: source(FixedEntry127)、q(Quote)。返り値: *Case127です。
func fixedCase127(source FixedEntry127, q Quote) *Case127 {
	return &Case127{ID: source.ID, OriginalSide: source.Side, Original: fixedCandidate127(source.ID, source.Side, q, false), Reverse: fixedCandidate127(source.ID, -source.Side, q, false), ChartOriginal: fixedCandidate127(source.ID, source.Side, q, true), ChartReverse: fixedCandidate127(source.ID, -source.Side, q, true)}
}

// candidates127 は同時刻から始まる四つの独立観測を返します。
//
// 引数: c(*Case127)。返り値: []*Candidate127です。
func candidates127(c *Case127) []*Candidate127 {
	return []*Candidate127{c.Original, c.Reverse, c.ChartOriginal, c.ChartReverse}
}

// stepCase127 はBBOに固定kernel、価格参考にmarkだけLastのkernelを適用します。
//
// 引数: c(*Case127)、q(Quote)、previous/end(float64)。返り値: boolは未完了が残る場合です。
func stepCase127(c *Case127, q Quote, previous, end float64) bool {
	outcome127(c.Original, q, previous, end)
	outcome127(c.Reverse, q, previous, end)
	chartOutcome127(c.ChartOriginal, q, previous, end)
	chartOutcome127(c.ChartReverse, q, previous, end)
	for _, candidate := range candidates127(c) {
		for _, o := range candidate.Outcomes {
			if o.Status == "pending" {
				return true
			}
		}
	}
	return false
}

// finalize127 は未完了を打切りにし、約定不可の参考観測の金額を保存しません。
//
// 引数: c(*Case127)。返り値: ありません。価格方向・先着の値は変更しません。
func finalize127(c *Case127) {
	for _, candidate := range candidates127(c) {
		for i := range candidate.Outcomes {
			o := &candidate.Outcomes[i]
			if o.Status == "pending" {
				o.Status = "eof_censored"
			}
			if candidate.Axis != "BBO" {
				o.Net0 = nil
				o.Net5 = nil
			}
		}
	}
}
