package holdingohlc113

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"sync"
)

type Stamp127 struct {
	Time  float64 `json:"time"`
	Index int64   `json:"index"`
	Line  int64   `json:"source_line"`
}
type Birth127 struct {
	ID           string          `json:"id"`
	Mode         string          `json:"mode"`
	Side         int             `json:"side"`
	At           Stamp127        `json:"at"`
	EntryCap     float64         `json:"entry_cap"`
	Invalidation float64         `json:"invalidation"`
	ATR5         float64         `json:"atr5"`
	MinimumRisk  float64         `json:"minimum_risk"`
	HoldBoundary float64         `json:"hold_boundary"`
	HoldMinimum  float64         `json:"hold_minimum"`
	Refs         json.RawMessage `json:"refs"`
	Fields       json.RawMessage `json:"fields"`
}
type BirthResult127 struct {
	Event       Birth127 `json:"event"`
	Request     *Quote   `json:"request"`
	Expires     float64  `json:"expires"`
	Status      string   `json:"status"`
	Evaluation  *Quote   `json:"evaluation"`
	Entry       *Quote   `json:"entry"`
	Risk        *float64 `json:"risk"`
	MaximumRisk float64  `json:"maximum_risk"`
}

// ----------------------------------------
// request127 は公表配送と同じ原行で、当時の構造が残る場合だけ注文要求を作ります。
//
// 引数: e(Birth127)、q(Quote)、force(float64)。返り値: *BirthResult127です。
func request127(e Birth127, q Quote, force float64) *BirthResult127 {
	r := &BirthResult127{Event: e, Expires: math.Min(q.Time+30, force), Status: "pending", MaximumRisk: math.Min(125, 1.5*e.ATR5)}
	if q.Time >= force {
		r.Status = "force_close"
		return r
	}
	if float64(e.Side)*(q.Last-e.HoldBoundary) < e.HoldMinimum {
		r.Status = "birth_structure_lost"
		return r
	}
	if float64(e.Side)*(q.Last-e.EntryCap) > 0 {
		r.Status = "birth_cap_rejected"
		return r
	}
	x := q
	r.Request = &x
	return r
}

// ----------------------------------------
// pendingBirth127 は1秒後の最初の正常BBOで価格上限・構造・リスクを検査します。
//
// 引数: r(*BirthResult127)、q(Quote)、force(float64)。返り値: boolは今回取得した場合です。
func pendingBirth127(r *BirthResult127, q Quote, force float64) bool {
	if r.Status != "pending" || r.Entry != nil {
		return false
	}
	if q.Time >= force {
		r.Status = "force_close"
		return false
	}
	if q.Time >= r.Expires {
		r.Status = "unfilled_expired"
		return false
	}
	if r.Request == nil || q.Time < r.Request.Time+1 || q.Index <= r.Request.Index || q.SourceLine <= r.Request.SourceLine || !q.QuoteOK || !normal(q) {
		return false
	}
	x := q
	r.Evaluation = &x
	price := q.Ask
	if r.Event.Side < 0 {
		price = q.Bid
	}
	d := float64(r.Event.Side)
	risk := d * (price - r.Event.Invalidation)
	r.Risk = &risk
	if d*(price-r.Event.EntryCap) > 0 {
		r.Status = "entry_cap_rejected"
		return false
	}
	if d*(q.Last-r.Event.HoldBoundary) < r.Event.HoldMinimum {
		r.Status = "structure_lost"
		return false
	}
	if risk <= 0 || risk < r.Event.MinimumRisk || risk > r.MaximumRisk {
		r.Status = "risk_rejected"
		return false
	}
	r.Entry = &x
	r.Status = "filled"
	return true
}

// ----------------------------------------
// validateBirths127 は公開時点・方向・境界・有限値を確認し、物理行へ索引化します。
//
// 引数: s(Scene127)。返り値: map[int64][]Birth127/errorです。
func validateBirths127(s Scene127) (map[int64][]Birth127, error) {
	wanted := map[int64][]Birth127{}
	ids := map[string]bool{}
	var previous int64 = -1
	for _, e := range s.Events {
		if !finite(e.MinimumRisk) || e.MinimumRisk < 0 || e.MinimumRisk > math.Min(125, 1.5*e.ATR5) || float64(e.Side)*(e.EntryCap-e.Invalidation) < e.MinimumRisk {
			return nil, fmt.Errorf("出生の最小risk又はcapとの両立差:%s", e.ID)
		}
		if e.ID == "" || ids[e.ID] || e.Mode == "" || (e.Side != 1 && e.Side != -1) || !finite(e.At.Time, e.EntryCap, e.Invalidation, e.ATR5, e.HoldBoundary, e.HoldMinimum) || e.ATR5 <= 0 || e.EntryCap <= 0 || e.Invalidation <= 0 || e.HoldBoundary <= 0 || (e.HoldMinimum != 0 && e.HoldMinimum != 5) || float64(e.Side)*(e.EntryCap-e.HoldBoundary) < e.HoldMinimum || float64(e.Side)*(e.EntryCap-e.Invalidation) <= 0 || e.At.Time < s.Start || e.At.Time > s.End || e.At.Index < 0 || e.At.Index >= s.ExpectedAccepted || e.At.Line < e.At.Index+1 || e.At.Line < previous {
			return nil, fmt.Errorf("出生値/順序差:%s", e.ID)
		}
		ids[e.ID] = true
		previous = e.At.Line
		wanted[e.At.Line] = append(wanted[e.At.Line], e)
	}
	return wanted, nil
}

// ----------------------------------------
// scanBirth127 は出生の原行配送、遅延取得、取得後の正逆観測を一走査で行います。
//
// 引数: s(Scene127)。返り値: Result127/errorです。出生0場もRawを検査します。
func scanBirth127(s Scene127) (out Result127, err error) {
	out = Result127{Session: s.Session, Raw: s.Raw, ExpectedQuality: s.ExpectedQuality, Cases: []*Case127{}, Births: []*BirthResult127{}, RawPasses: 1, SourceEntries: len(s.Events)}
	wanted, e := validateBirths127(s)
	if e != nil {
		return out, e
	}
	f, e := os.Open(s.Raw.Path)
	if e != nil {
		return out, e
	}
	defer f.Close()
	before, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.Before = FileStat{Bytes: before.Size(), ModTimeNS: before.ModTime().UnixNano()}
	h := sha256.New()
	tee := io.TeeReader(f, h)
	z, encoding, e := rawStream127(tee)
	if e != nil {
		return out, e
	}
	defer z.Close()
	out.RawEncoding = encoding
	scan := bufio.NewScanner(z)
	scan.Buffer(make([]byte, 65536), 8*1024*1024)
	scene := Scene{Session: s.Session, Contract: s.Contract, Start: s.Start, End: s.End, Raw: s.Raw}
	previous := s.Start
	var index int64
	contracts := map[string]bool{}
	pending := []*BirthResult127{}
	active := []*Case127{}
	matched := 0
	for scan.Scan() {
		out.Quality.Lines++
		oldTime := previous
		q, reason, next, e := decodeRow(scan.Bytes(), out.Quality.Lines, index, scene, previous, &out.Quality, contracts)
		previous = next
		if e != nil {
			return out, e
		}
		if q != nil {
			index++
		}
		for _, event := range wanted[out.Quality.Lines] {
			if q == nil || event.At.Time != q.Time || event.At.Index != q.Index || event.At.Line != q.SourceLine {
				return out, fmt.Errorf("出生配送原行差:%s:%s", event.ID, reason)
			}
			r := request127(event, *q, s.ForceClose)
			out.Births = append(out.Births, r)
			matched++
			if r.Status == "pending" {
				pending = append(pending, r)
			}
		}
		if q == nil {
			continue
		}
		keep := pending[:0]
		for _, r := range pending {
			if pendingBirth127(r, *q, s.ForceClose) {
				c := fixedCase127(FixedEntry127{ID: r.Event.ID, Side: r.Event.Side, Entry: *q}, *q)
				c.SourceEvent = r.Event
				c.RequestQuote = r.Request
				out.Cases = append(out.Cases, c)
				active = append(active, c)
			} else if r.Status == "pending" {
				keep = append(keep, r)
			}
		}
		pending = keep
		live := active[:0]
		for _, c := range active {
			if stepCase127(c, *q, oldTime, s.End) {
				live = append(live, c)
			}
		}
		active = live
	}
	if e = scan.Err(); e != nil {
		return out, e
	}
	if _, e = io.Copy(io.Discard, tee); e != nil {
		return out, e
	}
	after, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.After = FileStat{Bytes: after.Size(), ModTimeNS: after.ModTime().UnixNano()}
	out.ActualSHA = hex.EncodeToString(h.Sum(nil))
	if out.ActualSHA != s.Raw.SHA256 || out.Before != out.After || len(contracts) != 1 || !contracts[s.Contract] || index != s.ExpectedAccepted || matched != len(s.Events) {
		return out, fmt.Errorf("原板指紋/限月/採用数/出生配送数差")
	}
	if s.ExpectedQuality != nil && out.Quality != *s.ExpectedQuality {
		return out, fmt.Errorf("全行品質差")
	}
	for _, r := range pending {
		r.Status = "eof_unfilled"
	}
	for _, c := range out.Cases {
		finalize127(c)
	}
	out.Success = true
	return out, nil
}

// ----------------------------------------
// RunBirth127 は固定済み73場の出生入力を最大8並列で再生します。
//
// 引数: input/expected/output(string)、workers(int)。返り値: errorです。
func RunBirth127(input, expected, output string, workers int) error {
	if len(expected) != 64 || workers < 1 || workers > 8 {
		return fmt.Errorf("固定SHA/並列条件差")
	}
	b, e := os.ReadFile(input)
	if e != nil {
		return e
	}
	sum := sha256.Sum256(b)
	if hex.EncodeToString(sum[:]) != expected {
		return fmt.Errorf("入力SHA差")
	}
	var in Input127
	if e = json.Unmarshal(b, &in); e != nil {
		return e
	}
	if len(in.Scenes) != 73 {
		return fmt.Errorf("73場差")
	}
	prevEnd := 0.0
	prevName := ""
	seen := map[string]bool{}
	for _, s := range in.Scenes {
		if s.Session == "" || seen[s.Session] || s.Session <= prevName || s.Start <= prevEnd || s.ForceClose <= s.Start || s.ForceClose > s.End || s.Raw.Path == "" || len(s.Raw.SHA256) != 64 || s.ExpectedAccepted <= 0 || s.ExpectedQuality == nil {
			return fmt.Errorf("場定義差:%s", s.Session)
		}
		seen[s.Session] = true
		prevName = s.Session
		prevEnd = s.End
	}
	if _, e = os.Stat(output); !os.IsNotExist(e) {
		return fmt.Errorf("新規結果だけ")
	}
	results := make([]Result127, 73)
	jobs := make(chan int)
	var wg sync.WaitGroup
	for n := 0; n < workers; n++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range jobs {
				r, err := scanBirth127(in.Scenes[i])
				if err != nil {
					r.Error = err.Error()
				}
				results[i] = r
				fmt.Printf("%s 成功=%t %s\n", r.Session, r.Success, r.Error)
			}
		}()
	}
	for i := range in.Scenes {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	for _, r := range results {
		if !r.Success {
			return fmt.Errorf("%s:%s", r.Session, r.Error)
		}
	}
	after, e := os.ReadFile(input)
	if e != nil {
		return e
	}
	if sha256.Sum256(after) != sum {
		return fmt.Errorf("入力前後差")
	}
	encoded, e := json.MarshalIndent(map[string]any{"trial": 127, "success": true, "input_sha256": expected, "scenes": results, "widths": Widths127, "horizons": Horizons127, "candidate_quantity": 1, "portfolio_pnl": false, "source_entry_births_used": false}, "", "  ")
	if e != nil {
		return e
	}
	f, e := os.OpenFile(output, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return e
	}
	defer f.Close()
	_, e = f.Write(append(encoded, '\n'))
	return e
}
