"""機能: 127の政策選択と主要140集計をRoot関数を使わず照合する。

引数: コマンドライン引数なし。Rootが読取許可した固定結果と入力を使う。
返り値: なし。独立検算.jsonを新規保存する。Rawを読まない。
"""

import hashlib
import importlib.util
import json
from collections import Counter
from pathlib import Path


def sha(path: Path) -> str:
    """機能: ファイルのSHA256を求める。

    引数: path (Path) は対象。
    返り値: str は小文字16進表記。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def first(rows: list[dict], only: str | None = None) -> dict | None:
    """機能: 実取得順と既定優先から最初の一例を独立選択する。

    引数: rows (list[dict]) は同場の取得、only (str | None) はmode限定。
    返り値: dict | None は選んだ例又は全Raw未解決/取得なし。
    """
    groups = {}
    for row in rows:
        if only is not None and row["mode"] != only:
            continue
        q = row["case"]["original"]["entry"]
        groups.setdefault((q["time"], q["index"], q["source_line"]), []).append(row)
    for key in sorted(groups):
        current = groups[key]
        role = min("RTSQ".index(r["mode"]) for r in current)
        current = [r for r in current if "RTSQ".index(r["mode"]) == role]
        distance = min(r["risk"] for r in current)
        current = [r for r in current if r["risk"] == distance]
        if len({r["case"]["original_side"] for r in current}) > 1:
            continue
        return sorted(current, key=lambda r: r["case"]["id"])[0]
    return None


def pick(row: dict, policy: str, axis: str) -> dict:
    """機能: FRだけを同時点の実逆側へ切り替える。

    引数: row (dict)、policy/axis (str) は例・政策・価格軸。
    返り値: dict は固定された元/逆候補。
    """
    return row["case"][("chart_" if axis == "Last" else "") + ("reverse" if policy == "FR" else "original")]


# ----------------------------------------
BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
RESULT = ROOT / "work/127独立出生の評価/全73場の独立出生結果.json"
INPUT = ROOT / "work/127独立出生の評価/入力.json"
AGG = ROOT / "work/127独立出生の集計/集計.json"
HELPER = ROOT / "work/124正逆の独立検算/検算する.py"
FIXED = {RESULT: "ca45bd682152963c6f1e0fca72161e5cb77fc51e096d61fb2854e00e1ba58ecb",
         INPUT: "b8f382b90f345c4e2c7085ad743c95bbfd887e0cb36ec1f704f848b148bc4e85",
         AGG: "5e080bcfd6b20f6175aeec7c1a141a0e2ce445493674125a33b92050ce8bf9d7",
         HELPER: "0305f507a74f9728fbdb1ecabe406a3bfcb2f8657a4d1ee2556ca50dbe6585be"}
BEFORE = {str(p): sha(p) for p in (*FIXED, Path(__file__).resolve())}
assert all(BEFORE[str(p)] == h for p, h in FIXED.items())
spec = importlib.util.spec_from_file_location("own_independent_arithmetic124", HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
helper.pick = pick
data = json.loads(RESULT.read_bytes())
source = json.loads(INPUT.read_bytes())
aggregate = json.loads(AGG.read_bytes())
assert data["success"] and data["trial"] == 127 and data["candidate_quantity"] == 1
assert not data["portfolio_pnl"] and not data["source_entry_births_used"]
assert data["input_sha256"] == FIXED[INPUT]
assert aggregate["再生結果SHA256"] == FIXED[RESULT] and aggregate["出生入力SHA256"] == FIXED[INPUT]
POLICIES = ("F0", "FR", "A0", "R1", "T1", "S1", "Q1")
selected = {p: [] for p in POLICIES}
counts = Counter()
sessions = []
for scene, original in zip(data["scenes"], source["scenes"]):
    sid = scene["session"]
    sessions.append(sid)
    assert sid == original["session"] and scene["success"]
    assert scene["actual_sha256"] == original["raw"]["sha256"] and scene["stat_before"] == scene["stat_after"]
    assert scene["expected_quality"] == original["expected_quality"] == scene["quality"] and scene["raw_passes"] == 1
    assert [b["event"] for b in scene["births"]] == original["events"]
    births = {b["event"]["id"]: b for b in scene["births"]}
    cases = {c["id"]: c for c in scene["cases"]}
    assert set(cases) == {k for k, b in births.items() if b["status"] == "filled"}
    rows = []
    for identifier, birth in births.items():
        e = birth["event"]
        maximum = min(125, 1.5 * e["atr5"])
        assert e["minimum_risk"] == 10
        helper.equal(birth["maximum_risk"], maximum, "最大risk")
        helper.equal(birth["expires"], min(e["at"]["time"] + 30, original["force_close"]), "TTL")
        counts[birth["status"]] += 1
        request, evaluation = birth["request"], birth["evaluation"]
        if request is not None:
            assert all(request[k] == e["at"][k] for k in ("time", "index", "source_line"))
            assert e["side"] * (request["last"] - e["hold_boundary"]) >= e["hold_minimum"]
            assert e["side"] * (request["last"] - e["entry_cap"]) <= 0
        if evaluation is not None:
            assert request is not None and evaluation["time"] >= request["time"] + 1 and evaluation["time"] < birth["expires"]
            assert evaluation["time"] < original["force_close"] and evaluation["index"] > request["index"] and evaluation["source_line"] > request["source_line"]
            assert evaluation["quote_ok"] and 0 < evaluation["bid"] < evaluation["ask"]
            price = evaluation["ask"] if e["side"] > 0 else evaluation["bid"]
            helper.equal(birth["risk"], e["side"] * (price - e["invalidation"]), "評価risk")
        if identifier not in cases:
            assert birth["entry"] is None
            continue
        c = cases[identifier]
        assert c["source_event"] == e and c["request_quote"] == request and birth["entry"] == evaluation
        assert e["minimum_risk"] <= birth["risk"] <= maximum
        assert c["original"]["entry"] == c["reverse"]["entry"] == birth["entry"]
        price = evaluation["ask"] if e["side"] > 0 else evaluation["bid"]
        assert c["original"]["entry_price"] == price and e["side"] * (price - e["entry_cap"]) <= 0
        assert e["side"] * (evaluation["last"] - e["hold_boundary"]) >= e["hold_minimum"]
        assert c["reverse"]["entry_price"] == (evaluation["bid"] if e["side"] > 0 else evaluation["ask"])
        assert c["original"]["birth"]["side"] == e["side"] == c["original_side"] and c["reverse"]["birth"]["side"] == -e["side"]
        for name in ("chart_original", "chart_reverse"):
            assert c[name]["entry"] == evaluation and c[name]["entry_price"] == evaluation["last"]
            assert all(o["net0"] is None and o["net5"] is None for o in c[name]["outcomes"])
        rows.append({"session": sid, "case": c, "risk": birth["risk"], "mode": e["mode"]})
    chosen = first(rows)
    if chosen:
        selected["F0"].append(chosen)
        selected["FR"].append(chosen)
    selected["A0"].extend(sorted(rows, key=lambda r: (tuple(r["case"]["original"]["entry"][k] for k in ("time", "index", "source_line")), "RTSQ".index(r["mode"]), r["risk"], r["case"]["id"])))
    for mode in "RTSQ":
        chosen = first(rows, mode)
        if chosen:
            selected[mode + "1"].append(chosen)
assert len(sessions) == len(set(sessions)) == 73 and sum(counts.values()) == 650
assert len(selected["A0"]) == counts["filled"] == 164
stats, coverage = {}, {}
values_checked = 0
for policy, rows in selected.items():
    identities = [{"session": r["session"], "id": r["case"]["id"]} for r in rows]
    assert identities == aggregate["政策取得ID"][policy]
    filled_sessions = {r["session"] for r in rows}
    cov = {"target_sessions": 73, "filled_sessions": len(filled_sessions), "entries": len(rows),
           "empty_sessions": [s for s in sessions if s not in filled_sessions], "all_sessions_filled": len(filled_sessions) == 73}
    assert cov == aggregate["coverage"][policy]
    coverage[policy], stats[policy] = cov, {}
    for axis in ("BBO", "Last"):
        stats[policy][axis] = {}
        for horizon in (1800, 3600):
            stats[policy][axis][str(horizon)] = {}
            for width in (25, 50, 100, 125, 200):
                values = helper.independent_stats(rows, policy, axis, horizon, width)
                saved = aggregate["集計"][policy][axis][str(horizon)][str(width)]
                assert set(values) == set(saved)
                for key, value in values.items():
                    helper.equal(saved[key], value, f"{policy}/{axis}/{horizon}/{width}/{key}")
                    values_checked += 1
                stats[policy][axis][str(horizon)][str(width)] = values
assert dict(counts) == aggregate["出生状態"]
AFTER = {str(p): sha(p) for p in (*FIXED, Path(__file__).resolve())}
assert BEFORE == AFTER
out = {"成功": True, "試行": 127, "前SHA256": BEFORE, "後SHA256": AFTER, "前後不変": True,
       "全出生": 650, "全取得": 164, "全場": 73, "政策ID/coverage同体": True, "全140組": True,
       "集計値照合数": values_checked, "出生状態": dict(counts), "coverage": coverage,
       "主H60_125": {p: stats[p]["BBO"]["3600"]["125"] for p in POLICIES},
       "H60_Last125": {p: stats[p]["Last"]["3600"]["125"] for p in POLICIES},
       "Root集計関数import": False, "独立算術": "自作124検算器のFraction式のみ再用、政策選択は別実装。",
       "自然Raw再読": False, "金融再生": False, "限界": "bootstrap・全表・Raw先着最初性の再走査は対象外。"}
OUT = BASE / "独立検算.json"
with OUT.open("x", encoding="utf-8", newline="\n") as stream:
    stream.write(json.dumps(out, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"成功": True, "SHA256": sha(OUT), "照合値": values_checked, "主": out["主H60_125"]["F0"], "状態": dict(counts)}, ensure_ascii=False))
