"""機能: Qの取得位置を用いた実逆側の事後診断を保存する。

引数: なし。固定127結果・集計・診断と自作算術だけを使う。
返り値: なし。QのEMA側切替の追補.jsonを新規作成する。
"""

import hashlib
import importlib.util
import json
from pathlib import Path


def sha(path: Path) -> str:
    """機能: ファイルのSHA256を得る。

    引数: path (Path) は対象。
    返り値: str は小文字16進表記。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pick(row: dict, policy: str, axis: str) -> dict:
    """機能: Qかつ取得Lastが元側EMA21の反対なら実逆側を選ぶ。

    引数: row (dict)、policy/axis (str) は固定例・比較指定・価格軸。
    返り値: dict は同Raw正逆ペアの片側。未知又は境界0は元を維持。
    """
    position = row['feature']['entry_last_ema21_atr_signed']
    flip = policy == '切替' and row['case']['source_event']['mode'] == 'Q' and position is not None and position < 0
    return row['case'][('chart_' if axis == 'Last' else '')+('reverse' if flip else 'original')]


# ----------------------------------------
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
paths={ROOT/'work/127独立出生の評価/全73場の独立出生結果.json':'ca45bd682152963c6f1e0fca72161e5cb77fc51e096d61fb2854e00e1ba58ecb',
       ROOT/'work/127独立出生の集計/集計.json':'5e080bcfd6b20f6175aeec7c1a141a0e2ce445493674125a33b92050ce8bf9d7',
       BASE/'診断.json':'c5cb6c5622f2a54f0147bc682149a5bf078e7579a74f59486aeddb21a97d0930',
       ROOT/'work/124正逆の独立検算/検算する.py':'0305f507a74f9728fbdb1ecabe406a3bfcb2f8657a4d1ee2556ca50dbe6585be'}
before={str(p):sha(p) for p in (*paths,Path(__file__).resolve())}
assert all(before[str(p)]==h for p,h in paths.items())
result,aggregate,diagnosis=[json.loads(p.read_bytes()) for p in list(paths)[:3]]
helper_path=list(paths)[3]
spec=importlib.util.spec_from_file_location('自作124の算術',helper_path)
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper);helper.pick=pick
f={(r['session'],r['id']):r['features'] for r in diagnosis['取得164の当時票']}
rows={(s['session'],c['id']):{'session':s['session'],'case':c,'feature':f[(s['session'],c['id'])]} for s in result['scenes'] for c in s['cases']}
output={}
for group in ('F0','Q1','A0'):
    selected=[rows[(x['session'],x['id'])] for x in aggregate['政策取得ID'][group]]
    output[group]={axis:{str(width):{policy:helper.independent_stats(selected,policy,axis,3600,width) for policy in ('元','切替')} for width in (25,100,125)} for axis in ('BBO','Last')}
after={str(p):sha(p) for p in (*paths,Path(__file__).resolve())}
assert before==after
value={'成功':True,'試行':127,'事後追補':True,'条件':'mode Qかつ元side×(entry.Last−出生公表EMA21)<0なら同Raw実逆BBO、他は元。未知/0はkeep。',
       '前SHA256':before,'後SHA256':after,'前後不変':True,'比較':output,
       '限界':['127結果を見た後に提案された探索内の関連確認。128主条件を変更しない。',
               '127の元側で通過したcap/hold/risk・取得選択を固定した方向診断。逆向きの新規注文・逆向き無効化は再生していない。',
               '取得時Lastは当Rawで既知だが、公表時点だけの判別や注文前の確定条件とは異なる。',
               '各場取得数・対象場を減らさず、全場取得を保証する条件ができたとはしない。',
               '群別同場依存・結果参照・多重比較があり、70%や正収支でも未知期の確証にはしない。']}
dest=BASE/'QのEMA側切替の追補.json'
with dest.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'成功':True,'SHA256':sha(dest),'F0主':output['F0']['BBO']['125'],'Q先頭主':output['Q1']['BBO']['125']},ensure_ascii=False))
