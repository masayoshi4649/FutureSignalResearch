"""機能: 保存済127票と当時公表から未取得理由と技術的な関連を記録する。

引数: なし。固定済みの結果・出生入力・公表入力だけを参照する。
返り値: なし。診断.jsonを保存する。Raw、未知の金融結果、閾値探索は扱わない。
"""

import hashlib
import importlib.util
import json
import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path


def sha(path: Path) -> str:
    """機能: SHA256を求める。

    引数: path (Path) は対象ファイル。
    返り値: str は小文字16進表記。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def number(value: object) -> float | None:
    """機能: 真偽値・非有限値・未知を数値と区別する。

    引数: value (object) は元値。
    返り値: float | None は有限数又は未知。
    """
    return value if type(value) in (int, float) and math.isfinite(value) else None


def known(value: dict) -> float | None:
    """機能: 公表指標のknownを保持して値を取り出す。

    引数: value (dict) はknown/value票。
    返り値: float | None は既知値又は未知。
    """
    return number(value['value']) if value['known'] else None


def summary(values: list) -> dict:
    """機能: 全件数・既知数と値域を記録する。

    引数: values (list) は有限数又はNone。
    返り値: dict は未知を除いた最小/中央値/最大と母数。
    """
    v = [x for x in values if x is not None]
    return {'全件': len(values), '既知': len(v), '未知': len(values)-len(v),
            '最小': min(v) if v else None, '中央値': statistics.median(v) if v else None,
            '最大': max(v) if v else None}


def band(value: float | None, edges: tuple) -> str:
    """機能: 意味に基づく固定境界で関連を記述する。

    引数: value (float | None)、edges (tuple) は値と昇順境界。
    返り値: str は左閉右開区分又は未知。
    """
    if value is None:
        return '未知'
    bounds = (None, *edges, None)
    for low, high in zip(bounds, bounds[1:]):
        if (low is None or value >= low) and (high is None or value < high):
            return f'[{low if low is not None else "−∞"},{high if high is not None else "+∞"})'
    raise AssertionError(value)


def relation(value: float | None) -> str:
    """機能: 元注文方向とのMA整合を表す。

    引数: value (float | None) は方向積。
    返り値: str は同向/反対/不揃い/未知。
    """
    return '未知' if value is None else '同向' if value > 0 else '反対' if value < 0 else '不揃い'


# ----------------------------------------
BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
RESULT = ROOT/'work/127独立出生の評価/全73場の独立出生結果.json'
INPUT = ROOT/'work/127独立出生の評価/入力.json'
PUB = ROOT/'work/122全場入力/入力.json'
AGG = ROOT/'work/127独立出生の集計/集計.json'
HELPER = ROOT/'work/124正逆の独立検算/検算する.py'
EXPECTED = {RESULT:'ca45bd682152963c6f1e0fca72161e5cb77fc51e096d61fb2854e00e1ba58ecb',
            INPUT:'b8f382b90f345c4e2c7085ad743c95bbfd887e0cb36ec1f704f848b148bc4e85',
            PUB:'6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec',
            AGG:'5e080bcfd6b20f6175aeec7c1a141a0e2ce445493674125a33b92050ce8bf9d7',
            HELPER:'0305f507a74f9728fbdb1ecabe406a3bfcb2f8657a4d1ee2556ca50dbe6585be'}
before = {str(p):sha(p) for p in (*EXPECTED, Path(__file__).resolve())}
assert all(before[str(p)] == value for p,value in EXPECTED.items())
result, source, pubs, aggregate = [json.loads(p.read_bytes()) for p in (RESULT, INPUT, PUB, AGG)]
spec = importlib.util.spec_from_file_location('own_independent124', HELPER)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
helper.pick = lambda row,policy,axis: row['case'][('chart_' if axis == 'Last' else '')+('reverse' if policy == 'FR' else 'original')]
publications = {p['frame']['frame']['id']:p for scene in pubs['scenes'] for p in scene['publications']}
assert len(publications) == 12794


def public(ref: dict, event: dict) -> dict:
    """機能: 保存参照を当時の正本公表へ完全対応させる。

    引数: ref/event (dict) は参照と出生。
    返り値: dict は時刻・順序が出生以前の公表。
    """
    p = publications[ref['id']]
    f = p['frame']['frame']
    assert f['width_seconds'] == ref['width_seconds'] and f['end'] == ref['end']
    assert p['stamp'] == ref['delivered']
    assert all(p['stamp'][k] <= event['at'][k] for k in ('time','index','source_line'))
    assert f['available_at'] <= event['at']['time']
    return p


def features(event: dict, birth: dict) -> dict:
    """機能: 当時背景と取得価格の関連を未知保持で抽出する。

    引数: event/birth (dict) は出生原票と実行票。
    返り値: dict は取得後の指標再計算を含まない特徴。
    """
    side, fields = event['side'],event['fields']
    refs = {r['id']:r for r in event['refs']}
    out = {'mode':event['mode'],'side':side,'rvol5':number(fields.get('rvol5')),
           'atr5':event['atr5'],'confirm_close':number(fields.get('confirm_close')),
           'contact_regime':fields.get('contact_regime')}
    for width,bg in fields['background_5_15_30'].items():
        if not bg.get('available') or not bg.get('ref_id'):
            continue
        p = public(refs[bg['ref_id']],event)
        f, d = p['frame']['frame'],p['frame']['dmi']
        t = f['technical']
        out[f'direction{width}_signed'] = None if bg['ma_direction'] is None else side*bg['ma_direction']
        out[f'adx{width}'] = known(d['adx'])
        previous = known(d['previous_adx'])
        out[f'adx{width}_delta'] = out[f'adx{width}']-previous if None not in (out[f'adx{width}'],previous) else None
        if width != '5':
            continue
        for key in ('ema8','ema21','rsi','histogram','atr','previous_atr','tr'):
            out[key] = known(t[key])
        for key,previous in (('rsi','previous_rsi'),('histogram','previous_histogram')):
            a,b = known(t[key]),known(t[previous])
            out[key+'_delta_signed'] = side*(a-b) if None not in (a,b) else None
        out['rsi_side_level'] = 50+side*(out['rsi']-50) if out['rsi'] is not None else None
        out['histogram_signed'] = side*out['histogram'] if out['histogram'] is not None else None
        out['tr_previous_atr'] = out['tr']/out['previous_atr'] if out['previous_atr'] and out['tr'] is not None else None
        o = f['ohlc']; span = o['high']-o['low']
        out['body_signed_ratio'] = side*(o['close']-o['open'])/span if span > 0 else None
        out['favorable_wick_ratio'] = ((o['high']-max(o['open'],o['close'])) if side > 0 else min(o['open'],o['close'])-o['low'])/span if span > 0 else None
        out['close_location_signed'] = ((o['close']-o['low']) if side > 0 else o['high']-o['close'])/span if span > 0 else None
        out['current5_ref_id'] = f['id']
        out['pub_end_to_birth_seconds'] = event['at']['time']-f['end']
        out['available_to_birth_seconds'] = event['at']['time']-f['available_at']
        q = birth['entry']
        out['entry_last_ema21_atr_signed'] = side*(q['last']-out['ema21'])/event['atr5'] if q and out['ema21'] is not None else None
        out['entry_price_ema21_atr_signed'] = side*((q['ask'] if side>0 else q['bid'])-out['ema21'])/event['atr5'] if q and out['ema21'] is not None else None
        out['request_last_confirm_close_signed'] = side*(birth['request']['last']-out['confirm_close']) if birth['request'] and out['confirm_close'] is not None else None
        out['entry_last_confirm_close_signed'] = side*(q['last']-out['confirm_close']) if q and out['confirm_close'] is not None else None
        out['entry_spread'] = q['ask']-q['bid'] if q else None
    contact = fields.get('stage_refs',[])
    if event['mode'] == 'Q' and contact:
        p = public(contact[0],event)
        d = p['frame']['dmi']
        out['contact_adx5'] = known(d['adx'])
        previous = known(d['previous_adx'])
        out['contact_adx5_delta'] = out['contact_adx5']-previous if None not in (out['contact_adx5'],previous) else None
    return out


def bins(f: dict) -> dict:
    """機能: 既定指標水準と仕様の論理分岐を記述する。

    引数: f (dict) は当時特徴。
    返り値: dict は事後の関連集計用区分。条件探索や政策変更に使わない。
    """
    r,h = f.get('rsi_delta_signed'),f.get('histogram_delta_signed')
    momentum = ('両改善' if r>0 and h>0 else 'RSIのみ改善' if r>0 else 'Histのみ改善' if h>0 else '両改善なし') if None not in (r,h) else '一部未知'
    mask = f.get('contact_regime')
    contact = '+'.join(k for k in ('gap_compressed','adx5_low','adx5_falling') if mask.get(k)) if isinstance(mask,dict) else '対象外'
    return {'現在ADX5':band(f.get('adx5'),(20,25)), '接触ADX5':band(f.get('contact_adx5'),(20,25)),
            '現在ADX5低下': '未知' if f.get('adx5_delta') is None else str(f['adx5_delta']<0),
            '現在方向5':relation(f.get('direction5_signed')), '現在方向15':relation(f.get('direction15_signed')),
            '現在方向30':relation(f.get('direction30_signed')), 'RSI側水準':band(f.get('rsi_side_level'),(30,50,70)),
            '勢い改善':momentum,'量RVOL':band(f.get('rvol5'),(.5,1,1.5)),
            'TR前ATR':band(f.get('tr_previous_atr'),(1,2)),
            '取得Last_EMA21_ATR':band(f.get('entry_last_ema21_atr_signed'),(-1,0,1)),
            '確認足実体比':band(f.get('body_signed_ratio'),(-.5,0,.5)), '接触OR内訳':contact}


# ----------------------------------------
all_births, filled, missing, evaluated = [],[],[],[]
gate_counts = Counter()
for scene in result['scenes']:
    cases = {c['id']:c for c in scene['cases']}
    counts = Counter(b['status'] for b in scene['births'])
    if not cases:
        maxcount = max(counts.values()) if counts else 0
        missing.append({'session':scene['session'],'出生':sum(counts.values()),'状態':dict(counts),
                        '最大原因':[k for k,n in counts.items() if n==maxcount]})
    for birth in scene['births']:
        e,q = birth['event'],birth['evaluation']
        f = features(e,birth)
        row = {'session':scene['session'],'id':e['id'],'status':birth['status'],'features':f,'bins':bins(f)}
        all_births.append(row)
        if q:
            price = q['ask'] if e['side']>0 else q['bid']
            gates = {'cap不成立': e['side']*(price-e['entry_cap'])>0,
                     'hold不成立': e['side']*(q['last']-e['hold_boundary'])<e['hold_minimum'],
                     'risk非正':birth['risk']<=0,
                     'risk正だが10未満':0<birth['risk']<10,
                     'risk上限超':birth['risk']>birth['maximum_risk']}
            for k,v in gates.items():
                if v:
                    gate_counts[(birth['status'],k)] += 1
            evaluated.append({'session':scene['session'],'id':e['id'],'status':birth['status'],
                              'gates':gates,'risk':birth['risk'],'risk_max':birth['maximum_risk'],
                              'cap超過pt':max(0,e['side']*(price-e['entry_cap'])),
                              'hold不足pt':max(0,e['hold_minimum']-e['side']*(q['last']-e['hold_boundary'])),
                              '注文から評価秒':q['time']-birth['request']['time'],
                              '注文から評価Last順変化pt':e['side']*(q['last']-birth['request']['last'])})
        if e['id'] in cases:
            row['case'] = cases[e['id']]
            row['risk'] = birth['risk']
            filled.append(row)

assert len(all_births)==650 and len(filled)==164 and len(missing)==11 and len(evaluated)==280
by_id = {(r['session'],r['id']):r for r in filled}
policies = {p:[by_id[(x['session'],x['id'])] for x in aggregate['政策取得ID'][p]] for p in ('F0','FR','A0','R1','T1','S1','Q1')}
groups = {}
for policy in ('F0','Q1','R1','A0'):
    rows=policies[policy]
    groups[policy]={}
    for key in bins(rows[0]['features']):
        current=defaultdict(list)
        for row in rows:
            current[row['bins'][key]].append(row)
        groups[policy][key]={k:helper.independent_stats(v,policy,'BBO',3600,125) for k,v in sorted(current.items())}

metrics = ('entry_last_ema21_atr_signed','entry_price_ema21_atr_signed','entry_last_confirm_close_signed',
           'request_last_confirm_close_signed','pub_end_to_birth_seconds','available_to_birth_seconds',
           'body_signed_ratio','rsi_side_level','rsi_delta_signed','histogram_delta_signed','tr_previous_atr',
           'rvol5','adx5','adx15','adx30','entry_spread')
descriptions={}
for policy in ('F0','Q1','R1','A0'):
    partition=defaultdict(list)
    for row in policies[policy]:
        o=helper.observation(row['case']['original'],3600)
        label={1:'順行',-1:'逆行',0:'未到達'}[helper.touch(o,125)['direction']] if o['status']=='complete' else '観測不足'
        partition[label].append(row)
    descriptions[policy]={label:{key:summary([r['features'].get(key) for r in rows]) for key in metrics} for label,rows in partition.items()}

joint={}
for policy in ('F0','Q1'):
    current=defaultdict(list)
    for row in policies[policy]:
        b=row['bins']
        current[f"ADX5{b['現在ADX5']}・5分{b['現在方向5']}・30分{b['現在方向30']}"] .append(row)
    joint[policy]={k:helper.independent_stats(v,policy,'BBO',3600,125) for k,v in sorted(current.items())}

status_metrics={}
for status in sorted({r['status'] for r in evaluated}):
    rows=[r for r in evaluated if r['status']==status]
    status_metrics[status]={'件数':len(rows),'重複を許すgate不成立':{k:n for (s,k),n in gate_counts.items() if s==status},
                            '数値':{k:summary([r[k] for r in rows]) for k in ('risk','cap超過pt','hold不足pt','注文から評価秒','注文から評価Last順変化pt')}}
after={str(p):sha(p) for p in (*EXPECTED,Path(__file__).resolve())}
assert before==after
out={'成功':True,'試行':127,'前SHA256':before,'後SHA256':after,'前後不変':True,
     '対象':'既定H60±125、関連の記述のみ。政策・閾値・入力を変更しない。',
     '出生状態':dict(Counter(r['status'] for r in all_births)), '未取得11場':missing,
     '注文後評価280':status_metrics,'公表join総数':len(publications),
     '保存価格不足':{'出生前棄却':327,'理由':'request/evaluation=nil、event.atは時計のみ。出生Raw Lastやcap/hold超過幅は保存票だけでは復元不能。'},
     '政策別指標と勝敗':descriptions,'仕様と一般的水準による分解':groups,'方向とADXの重複分解':joint,
     '取得164の当時票':[{k:v for k,v in r.items() if k!='case'} | {'outcomes_H60_125':{p:{'status':helper.observation(r['case'][p],3600)['status'], 'direction':helper.touch(helper.observation(r['case'][p],3600),125)['direction'], 'IFD':helper.ifd_value(r['case'][p],3600,125,'BBO')} for p in ('original','reverse')}} for r in filled],
     '解釈限界':['群は同場で重複し独立標本ではない。小群の率を条件の効果や有意性としない。',
                 'End+60の同値足早期公開対照はこの検査では生成しない。遅延の因果効果は未測定。',
                 'EMA等は出生当時の保存公表。実取得時へ未来更新せず、取得価格との相対位置のみ算出。',
                 'ブートストラップは既存参考値で、この診断では再実装しない。',
                 'fields.risk_maxはSource原値。実行上限はmin(125,1.5ATR5)、この相違を入力変更で隠さない。']}
dest=BASE/'診断.json'
with dest.open('x',encoding='utf-8',newline='\n') as stream:
    stream.write(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'成功':True,'SHA256':sha(dest),'未取得場':len(missing),'評価状態':status_metrics},ensure_ascii=False))
