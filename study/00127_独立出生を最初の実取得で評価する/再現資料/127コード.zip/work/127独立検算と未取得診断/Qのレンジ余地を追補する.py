"""機能: Qの接触位置と実取得位置の違いを保存票で診断する。

引数: なし。固定127結果・集計と自作算術を使う。
返り値: なし。Qのレンジ余地の追補.jsonを新規保存する。
"""

import hashlib
import importlib.util
import json
from collections import defaultdict
from pathlib import Path


def sha(path: Path) -> str:
    """機能: ファイルのSHA256を求める。

    引数: path (Path) は対象。
    返り値: str は小文字16進表記。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pick(row: dict, policy: str, axis: str) -> dict:
    """機能: 元/実逆の保存候補を選ぶ。

    引数: row (dict)、policy/axis (str) は例・比較・価格軸。
    返り値: dict は同Rawの候補。
    """
    return row['case'][('chart_' if axis=='Last' else '')+('reverse' if policy=='逆' else 'original')]


# ----------------------------------------
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
paths={ROOT/'work/127独立出生の評価/全73場の独立出生結果.json':'ca45bd682152963c6f1e0fca72161e5cb77fc51e096d61fb2854e00e1ba58ecb',
       ROOT/'work/127独立出生の集計/集計.json':'5e080bcfd6b20f6175aeec7c1a141a0e2ce445493674125a33b92050ce8bf9d7',
       ROOT/'work/124正逆の独立検算/検算する.py':'0305f507a74f9728fbdb1ecabe406a3bfcb2f8657a4d1ee2556ca50dbe6585be'}
before={str(p):sha(p) for p in (*paths,Path(__file__).resolve())}
assert all(before[str(p)]==h for p,h in paths.items())
result,aggregate=[json.loads(p.read_bytes()) for p in list(paths)[:2]]
spec=importlib.util.spec_from_file_location('自作124レンジ追補',list(paths)[2]);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper);helper.pick=pick
rows={(s['session'],c['id']):{'session':s['session'],'case':c} for s in result['scenes'] for c in s['cases']}
groups={}
details={}
for policy in ('F0','Q1'):
    selected=[rows[(r['session'],r['id'])] for r in aggregate['政策取得ID'][policy] if rows[(r['session'],r['id'])]['case']['source_event']['mode']=='Q']
    partitions=defaultdict(lambda:defaultdict(list));detail=[]
    for row in selected:
        case=row['case'];event=case['source_event'];fields=event['fields'];side=event['side']
        low,high=fields['range_low'],fields['range_high'];span=high-low
        assert span>0
        price=case['original']['entry_price'];last=case['original']['entry']['last']
        contact_close=event['hold_boundary']-side*5
        relative=lambda p:(p-low)/span if side>0 else (high-p)/span
        position=relative(price)
        room=(high-price) if side>0 else (price-low)
        labels={'順側端まで125pt':'125以上' if room>=125 else '125未満',
                '元側取得位置50%':'後半0.5以上' if position>=.5 else '前半0.5未満',
                '範囲外':'逆側外' if position<0 else '順側外' if position>1 else '域内',
                '旧域幅125pt':'125以上' if span>=125 else '125未満'}
        for key,label in labels.items():partitions[key][label].append(row)
        detail.append({'session':row['session'],'id':case['id'],'side':side,'range_low':low,'range_high':high,'range_width':span,
                       'entry_price':price,'entry_last':last,'元側取得位置':position,'元側取得Last位置':relative(last),
                       '接触j終値位置':relative(contact_close),'確認k終値位置':relative(fields['confirm_close']),
                       '順側端までpt':room,'区分':labels,
                       '主先着':{p:{'status':helper.observation(case[p],3600)['status'],'direction':helper.touch(helper.observation(case[p],3600),125)['direction']} for p in ('original','reverse')}})
    groups[policy]={key:{label:{p:helper.independent_stats(current,p,'BBO',3600,125) for p in ('元','逆')} for label,current in values.items()} for key,values in partitions.items()}
    details[policy]=detail
after={str(p):sha(p) for p in (*paths,Path(__file__).resolve())};assert before==after
value={'成功':True,'試行':127,'事後追補':True,'前SHA256':before,'後SHA256':after,'前後不変':True,
       '定義':{'主':'H60±125pt/BBO','取得位置':'買(P−L)/(U−L)、売(U−P)/(U−L)。0が接触側、1が順側端。実Ask/Bid新規価格を使う。',
               '順側余地':'買U−entryAsk、売entryBid−L。負なら既に順側端の外。',
               '接触j終値':'QのK=Close_j+s×5から復元。接触した極値の位置と終値の位置を区別。'},
       '区分集計':groups,'全件票':details,
       '限界':['接触極値は端20%でも終値/確認/実取得を端20%に制限しない仕様の診断。',
               '125pt到達に反対端突破が必要でも失敗確定ではない。レンジ回転と継続突破を同じ成功条件で測った影響を分ける仮説。',
               '結果後の固定125pt/50%分解であり、次の条件の独立検証ではない。128主や旧v4を変更しない。',
               '逆は元の取得集合・時計を固定した実逆BBO診断で、逆注文のcap/hold/risk再生ではない。']}
dest=BASE/'Qのレンジ余地の追補.json'
with dest.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'成功':True,'SHA256':sha(dest),'区分':groups},ensure_ascii=False))
