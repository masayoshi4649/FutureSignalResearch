"""127の実行前原文とF1コード・650入力を、金融再実行なしで小型保管する。"""
from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent.parent
WORK = ROOT/'work/127独立出生の評価'
AGG = ROOT/'work/127独立出生の集計'
FORMAL = ROOT/'study/00127_独立出生を最初の実取得で評価する'
INPUTS = ROOT/'inputs/00127_独立出生'
BIRTH = ROOT/'work/126独立出生の事前案'


def sha(data: bytes) -> str:
    """
    機能: 全bytesの指紋を求める。
    引数: data(bytes)。返り値: strはSHA256。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def save(path: Path,value: dict) -> None:
    """
    機能: 未作成先へUTF-8 JSONを保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


# ----------------------------------------
def exact(source: Path,target: Path) -> dict:
    """
    機能: 原文を変更せず複写し同体を確認する。
    引数: source/target(Path)。返り値: dictは指紋とサイズ。
    """
    data = source.read_bytes()
    with target.open('xb') as stream:
        stream.write(data)
    assert target.read_bytes()==data
    return {'source':source.relative_to(ROOT).as_posix(),'target':target.relative_to(ROOT).as_posix(),
            'bytes':len(data),'sha256':sha(data)}


# ----------------------------------------
def compressed(source: Path,target: Path) -> dict:
    """
    機能: gzipを一度だけ保存し、解凍bytesを照合する。JSON値を解釈しない。
    引数: source/target(Path)。返り値: dictは圧縮・解凍の指紋。
    """
    data = source.read_bytes()
    encoded = gzip.compress(data,mtime=0)
    with target.open('xb') as stream:
        stream.write(encoded)
    assert gzip.decompress(target.read_bytes())==data
    return {'source':source.relative_to(ROOT).as_posix(),'target':target.relative_to(ROOT).as_posix(),
            'bytes':len(encoded),'sha256':sha(encoded),'decoded_bytes':len(data),'decoded_sha256':sha(data)}


# ----------------------------------------
def code_zip(target: Path,paths: list[Path]) -> dict:
    """
    機能: 復元相対pathを保った小型コードZIPを作り、全entryを検証する。
    引数: target(Path)、paths(list[Path])。返り値: dictはZIPと全entryの索引。
    """
    entries = []
    with zipfile.ZipFile(target,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in paths:
            name = path.relative_to(ROOT).as_posix()
            data = path.read_bytes()
            info = zipfile.ZipInfo(name,(1980,1,1,0,0,0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info,data)
            entries.append({'entry':name,'restore_relative':name,'bytes':len(data),'sha256':sha(data)})
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        for entry in entries:
            assert sha(archive.read(entry['entry']))==entry['sha256']
            entry['crc32'] = f"{archive.getinfo(entry['entry']).CRC:08x}"
    return {'zip':{'path':target.name,'bytes':target.stat().st_size,'sha256':sha(target.read_bytes())},'entries':entries}


# ----------------------------------------
def main() -> None:
    """
    機能: 原文保存→入力1回圧縮→別出自コード→結果圧縮の順で保管する。
    引数: なし。返り値: None。原板・177MB公表入力を開かず、金融再生しない。
    """
    for path in (FORMAL/'検査',FORMAL/'成果物',FORMAL/'再現資料',INPUTS):
        path.mkdir(exist_ok=True)
    f1 = json.loads((WORK/'F1.json').read_text(encoding='utf-8'))
    assert sha((WORK/'F1.json').read_bytes())=='5f4b809e22745072da22d6429bb95290d94c398c2a44fcd4ce8ea40e4f0bc061'
    frozen = {**f1['コード'],**f1['入力'],**f1['事前文書']}
    assert len(f1['コード'])==17 and len(f1['事前文書'])==4
    for path,digest in frozen.items():
        assert sha(Path(path).read_bytes())==digest,path
    # ----------------------------------------
    # 現README/設定へ結果を追記する前に、F1全4原文を同bytes確保する。
    originals = []
    for path,digest in f1['事前文書'].items():
        data = Path(path).read_bytes()
        text = data.decode('utf-8')
        assert text.encode('utf-8')==data
        originals.append({'restore_relative':Path(path).relative_to(ROOT).as_posix(),
                          'bytes':len(data),'sha256':digest,'utf8_text':text})
    encoded = (json.dumps({'trial':127,'F1_sha256':sha((WORK/'F1.json').read_bytes()),'原文':originals},ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    original_gz = gzip.compress(encoded,mtime=0)
    with (FORMAL/'検査/実行前文書.json.gz').open('xb') as stream:
        stream.write(original_gz)
    assert gzip.decompress(original_gz)==encoded
    save(FORMAL/'検査/実行前原文の確認.json',{'成功':True,'原文数':4,'結果更新前保存':True,
         'gzip_sha256':sha(original_gz),'gzip_bytes':len(original_gz),'decoded_sha256':sha(encoded),
         'decoded_bytes':len(encoded),'原文':[{k:v for k,v in e.items() if k!='utf8_text'} for e in originals]})
    inputs = [compressed(WORK/'入力.json',INPUTS/'入力.json.gz'),
              compressed(BIRTH/'出生イベント_v4.json',INPUTS/'出生イベント_v4.json.gz'),
              compressed(BIRTH/'v3/出生カウント_v3.json',INPUTS/'v3出生対照カウント.json.gz')]
    save(INPUTS/'指紋.json',{'trial':127,'inputs':inputs,'raw_duplicated':False,'publications_177MB_duplicated':False,
        'v3_note':'v4 schema転記の旧R/S同体とcoverage比較に必要な公表出生対照。金融ラベルではない。',
        'shared_publications':{'bytes':177709174,'sha256':'6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec',
                              'recipe':'study/00122_E0固定条件を全セッションで検証する/再現資料/再現手順.md'},
        'shared_scene_metadata':{'gzip':'inputs/00124_同入口正逆の共用入力/入力.json.gz',
                                  'decoded_sha256':'b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'}})
    copied = []
    for path,name in ((WORK/'F1.json','F1.json'),(WORK/'再生完了.json','再生完了.json'),
       (WORK/'段階実行完了.json','段階実行完了.json'),(WORK/'入力生成の確認.json','入力生成の確認.json'),
       (AGG/'集計完了.json','集計完了.json'),(AGG/'人工検査.json','集計器の人工検査.json'),
       (BIRTH/'出生引渡しの確認_v4.json','公表出生v4の引渡し確認.json'),
       (ROOT/'work/127独立出生CSV出力/独立再読の確認.json','CSV独立再読.json'),
       (ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/127独立出生CSV/CSVの確認.json','CSVの確認.json')):
        copied.append(exact(path,FORMAL/'検査'/name))
    copied.append(exact(AGG/'条件.md',FORMAL/'根拠/集計条件.md'))
    result_files = [compressed(WORK/'全73場の独立出生結果.json',FORMAL/'成果物/全73場の独立出生結果.json.gz'),
                    compressed(AGG/'集計.json',FORMAL/'成果物/集計.json.gz')]
    # ----------------------------------------
    # F1新規16と既存124共通1、F1外のv4生成コードを混同しない。
    paths = [Path(p) for p in f1['コード'] if Path(p).resolve()!=(ROOT/'work/124入口の原因分析/集計する.py').resolve()]
    assert len(paths)==16
    paths += [ROOT/'work/127独立出生CSV出力/出力する.mjs',ROOT/'work/127独立出生CSV出力/CSVを独立再読する.py',Path(__file__).resolve()]
    index = code_zip(FORMAL/'再現資料/127コード.zip',paths)
    index['trial'] = 127
    index['F1_sha256'] = sha((WORK/'F1.json').read_bytes())
    index['external_124'] = {'archive':'../../00124_逆行の原因と売買反転を同じ入口で検証する/再現資料/124コード.zip',
        'entry':'work/124入口の原因分析/集計する.py','sha256':'8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a'}
    save(FORMAL/'再現資料/コード復元索引.json',index)
    fixed = json.loads((BIRTH/'固定_v4.json').read_text(encoding='utf-8'))
    for path,digest in {**fixed['コード文書'],**fixed['既存Bank依存']}.items():
        assert sha((ROOT/path).read_bytes())==digest
    birth_paths = list(sorted((BIRTH/'v4').glob('*.go')))+[BIRTH/'v4/go.mod',BIRTH/'出生v4を渡す.py',BIRTH/'v4を準備する.py',BIRTH/'残る場を診断する.py']
    assert len(birth_paths)==9
    birth_index = code_zip(FORMAL/'再現資料/公表出生v4コード.zip',birth_paths)
    birth_index['financial_F1_member'] = False
    birth_index['fixed_v4_sha256'] = sha((BIRTH/'固定_v4.json').read_bytes())
    birth_index['external_bank'] = {'archive':'../../00118_指値待機と複数技法の取得確認で入口を比較する/再現資料/118コード.zip',
        'restore_prefix':'work/118複数技法の入口条件/','expected':fixed['既存Bank依存']}
    birth_index['restored_metadata'] = {'根拠/条件_v4.md':'work/126独立出生の事前案/条件_v4.md',
        '根拠/公表出生の固定_v4.json':'work/126独立出生の事前案/固定_v4.json',
        '根拠/残るNightの事後診断.json':'work/126独立出生の事前案/残るNightの事後診断.json'}
    save(FORMAL/'再現資料/公表出生コード復元索引.json',birth_index)
    for path,digest in frozen.items():
        assert sha(Path(path).read_bytes())==digest
    save(FORMAL/'検査/保存の確認.json',{'成功':True,'試行':127,'金融再実行なし':True,'原文4を結果追記前に保存':True,
        'F1全コード入力原文前後不変':True,'コピー':copied,'共用入力':inputs,'圧縮成果':result_files,
        'F1実行コードZIP':index['zip'],'F1外の公表出生ZIP':birth_index['zip'],
        '原板と177MB共用公表を複製しない':True,'ledgerと巨大表JSONはSource正本から再生成':True,
        '保存コードSHA256':sha(Path(__file__).read_bytes())})
    print(json.dumps({'成功':True,'入力':inputs,'成果物':result_files,'code':index['zip'],'birth_code':birth_index['zip'],
                      '保存proofSHA256':sha((FORMAL/'検査/保存の確認.json').read_bytes())},ensure_ascii=False))


if __name__=='__main__':
    main()
