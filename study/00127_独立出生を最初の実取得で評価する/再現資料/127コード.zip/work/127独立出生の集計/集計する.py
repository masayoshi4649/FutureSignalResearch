"""127の全出生を監査し、実取得時計だけでF0を選ぶ。自然実行はRoot固定後。"""
from pathlib import Path
from collections import Counter,defaultdict
from datetime import datetime,timezone,timedelta
import argparse
import hashlib
import importlib.util
import json
import math
import random

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
MODULE = ROOT/'work/124入口の原因分析/集計する.py'
MODULE_SHA = '8479ca348231ffd77a637360797750833c9e6617c7fc4a6502e015c7a1d9f04a'
POLICIES = ('F0','FR','A0','R1','T1','S1','Q1')
PRIORITY = {'R':0,'T':1,'S':2,'Q':3}
WIDTHS = (25,50,100,125,200)
HORIZONS = (1800,3600)


def sha(path: Path) -> str:
    """
    機能: ファイル全bytesの指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def save(path: Path,value: dict) -> None:
    """
    機能: 未作成先へUTF-8 JSONを保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')


# ----------------------------------------
def close(a: float,b: float) -> bool:
    """
    機能: 保存計算の再照合にだけ相対丸め許容を使う。選択tieには使わない。
    引数: a/b(float)。返り値: bool。
    """
    return math.isfinite(a) and math.isfinite(b) and abs(a-b)<=max(1e-9,abs(b)*1e-12)


# ----------------------------------------
def stamp(q: dict) -> tuple:
    """
    機能: 原行を時刻・採用Index・物理行の順で識別する。
    引数: q(dict)。返り値: tuple。
    """
    return q['time'],q['index'],q['source_line']


# ----------------------------------------
def clock(q: dict | None) -> str | None:
    """
    機能: 保存された時計をJSTで表示する。
    引数: q(dict|None)。返り値: str|None。
    """
    return datetime.fromtimestamp(q['time'],timezone(timedelta(hours=9))).isoformat(sep=' ') if q else None


# ----------------------------------------
def choose_first(records: list[dict],mode: str | None=None) -> tuple[dict | None,list[dict]]:
    """
    機能: 取得原行→mode→最小保存risk→side解決→IDの因果順で1件選ぶ。
    引数: records(list[dict])、mode(str|None)。返り値: tuple[dict|None,list[dict]]。
    """
    groups = defaultdict(list)
    for record in records:
        if mode is None or record['mode']==mode:
            groups[stamp(record['case']['original']['entry'])].append(record)
    trace = []
    for raw in sorted(groups):
        group = groups[raw]
        highest = min(PRIORITY[r['mode']] for r in group)
        same_mode = [r for r in group if PRIORITY[r['mode']]==highest]
        minimum = min(r['risk'] for r in same_mode)
        finalists = [r for r in same_mode if r['risk']==minimum]
        sides = {r['case']['original_side'] for r in finalists}
        item = {'entry':{'time':raw[0],'index':raw[1],'source_line':raw[2]},
                'mode':same_mode[0]['mode'],'minimum_risk_at_entry':minimum,
                'finalist_ids':sorted(r['case']['id'] for r in finalists),'sides':sorted(sides)}
        if len(sides)>1:
            trace.append({**item,'status':'direction_unresolved','selected_id':None})
            continue
        selected = min(finalists,key=lambda r:r['case']['id'])
        trace.append({**item,'status':'selected','selected_id':selected['case']['id']})
        return selected,trace
    return None,trace


# ----------------------------------------
def selected(record: dict,policy: str,axis: str) -> dict:
    """
    機能: FRだけを同じcaseの実逆側へ向け、他は元取得方向を使う。
    引数: record(dict)、policy/axis(str)。返り値: dictは保存済み観測候補。
    """
    return record['case'][('chart_' if axis=='Last' else '')+('reverse' if policy=='FR' else 'original')]


# ----------------------------------------
def module124():
    """
    機能: 元fileを変更せず固定stats/ifdを再用する。
    引数: なし。返り値: Pythonモジュール。
    """
    assert sha(MODULE)==MODULE_SHA
    spec = importlib.util.spec_from_file_location('fixed124_for_birth127',MODULE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.POLICIES = POLICIES
    module.selected = selected
    return module


# ----------------------------------------
def audit_records(data: dict,expected_births: int=650) -> tuple[list[str],list[dict],dict,list[dict]]:
    """
    機能: 全73場のRaw認証・全出生/取得対応・riskを確認する。
    引数: data(dict)、expected_births(int)。返り値: tupleは場順・取得行・場診断・全出生台帳。
    """
    assert data['trial']==127 and data['success'] and len(data['scenes'])==73
    assert tuple(data['widths'])==WIDTHS and tuple(data['horizons'])==HORIZONS
    records,sessions,scenes,ledger = [],[],{},[]
    born_count = 0
    for scene in data['scenes']:
        sid = scene['session']
        assert sid and sid not in scenes and scene['success']
        assert scene['actual_sha256']==scene['raw']['sha256'] and scene['stat_before']==scene['stat_after']
        assert scene['expected_quality'] is not None and scene['quality']==scene['expected_quality']
        assert scene['raw_passes']==1 and scene['source_entries']==len(scene['births'])
        sessions.append(sid)
        births = {b['event']['id']:b for b in scene['births']}
        cases = {c['id']:c for c in scene['cases']}
        assert len(births)==len(scene['births']) and len(cases)==len(scene['cases'])
        assert set(cases)=={key for key,b in births.items() if b['status']=='filled'}
        statuses = Counter(b['status'] for b in scene['births'])
        modes = Counter(b['event']['mode'] for b in scene['births'])
        assert set(modes)<=set(PRIORITY) and 'pending' not in statuses
        scenes[sid] = {'births':len(births),'fills':len(cases),'birth_modes':dict(modes),'birth_statuses':dict(statuses)}
        born_count += len(births)
        for key,born in births.items():
            event = born['event']
            assert event['side'] in (-1,1) and event['mode'] in PRIORITY
            assert event['minimum_risk']==10
            maximum = min(125,1.5*event['atr5'])
            assert maximum>=event['minimum_risk'] and close(born['maximum_risk'],maximum)
            request = born['request']
            if request is not None:
                assert stamp(request)==(event['at']['time'],event['at']['index'],event['at']['source_line'])
            item = {'session':sid,'id':key,'source_event':event,'status':born['status'],
                    'request':request,'expires':born['expires'],'evaluation':born['evaluation'],
                    'entry':born['entry'],'risk':born['risk'],'maximum_risk':born['maximum_risk']}
            ledger.append(item)
            if key not in cases:
                assert born['entry'] is None
                continue
            case = cases[key]
            assert case['source_event']==event and case['request_quote']==request and request is not None
            entry = case['original']['entry']
            assert entry==born['entry']==born['evaluation']==case['reverse']['entry']
            assert entry['time']>=request['time']+1 and entry['time']<born['expires']
            assert entry['index']>request['index'] and entry['source_line']>request['source_line']
            assert entry['quote_ok'] and 0<entry['bid']<entry['ask']
            side = event['side']
            assert case['original_side']==case['original']['birth']['side']==side
            assert case['reverse']['birth']['side']==-side
            price = entry['ask'] if side>0 else entry['bid']
            assert case['original']['entry_price']==price
            assert case['reverse']['entry_price']==(entry['bid'] if side>0 else entry['ask'])
            risk = side*(price-event['invalidation'])
            assert close(risk,born['risk']) and event['minimum_risk']<=born['risk']<=maximum
            assert side*(price-event['entry_cap'])<=0
            assert side*(entry['last']-event['hold_boundary'])>=event['hold_minimum']
            for name in ('chart_original','chart_reverse'):
                chart = case[name]
                assert chart['entry']==entry and chart['entry_price']==entry['last']
                assert chart['birth']['side']==(side if name=='chart_original' else -side)
                assert all(o['net0'] is None and o['net5'] is None for o in chart['outcomes'])
            records.append({'session':sid,'case':case,'mode':event['mode'],'risk':born['risk'],
                            'birth':born,'ledger':item,'feature':{'strategy':event['mode']}})
    assert sessions==sorted(sessions) and born_count==expected_births
    return sessions,records,scenes,ledger


# ----------------------------------------
def policies_for(records: list[dict],sessions: list[str]) -> tuple[dict,dict]:
    """
    機能: 各場の最初の1件と疎いmode比較を、結果非参照で選ぶ。
    引数: records(list[dict])、sessions(list[str])。返り値: tuple[dict,dict]は政策行と選択経過。
    """
    output = {p:[] for p in POLICIES}
    traces = {}
    by_scene = defaultdict(list)
    for r in records:
        by_scene[r['session']].append(r)
    for sid in sessions:
        group = by_scene[sid]
        traces[sid] = {}
        first,path = choose_first(group)
        traces[sid]['F0'] = path
        if first is not None:
            output['F0'].append(first)
            output['FR'].append(first)
        output['A0'].extend(sorted(group,key=lambda r:(stamp(r['case']['original']['entry']),PRIORITY[r['mode']],r['risk'],r['case']['id'])))
        for mode in ('R','T','S','Q'):
            first,path = choose_first(group,mode)
            traces[sid][mode+'1'] = path
            if first is not None:
                output[mode+'1'].append(first)
    return output,traces


# ----------------------------------------
def bootstrap(primary: list[dict],sessions: list[str],module) -> dict:
    """
    機能: 全73clusterを保持し、F0/FR平均とF0差の参考95%区間を求める。
    引数: primary(list[dict])、sessions(list[str])、module(モジュール)。返り値: dict。
    """
    rng = random.Random(124)
    samples = [[rng.randrange(len(sessions)) for _ in sessions] for _ in range(5000)]
    output = {}
    for policy in ('F0','FR'):
        sums,counts,deltas,paired = defaultdict(float),Counter(),defaultdict(float),Counter()
        for r in primary:
            c = selected(r,policy,'BBO')
            value = module.ifd(c,module.observation(c,3600),125,'BBO')
            base = selected(r,'F0','BBO')
            reference = module.ifd(base,module.observation(base,3600),125,'BBO')
            sid = r['session']
            if value['known']:
                sums[sid] += value['net5']; counts[sid] += 1
            if value['known'] and reference['known']:
                deltas[sid] += value['net5']-reference['net5']; paired[sid] += 1
        vectors = [(sums[sid],counts[sid],deltas[sid],paired[sid]) for sid in sessions]
        means,differences = [],[]
        for sample in samples:
            a=b=c=d=0
            for i in sample:
                values = vectors[i]
                a+=values[0]; b+=values[1]; c+=values[2]; d+=values[3]
            if b: means.append(a/b)
            if d: differences.append(c/d)
        output[policy] = {'C5平均代用円95区間':[module.percentile(means,.025),module.percentile(means,.975)],
                          'F0両側既知ペア平均差95区間':[module.percentile(differences,.025),module.percentile(differences,.975)],
                          '既知IFD数':sum(counts.values()),'両側既知ペア数':sum(paired.values())}
    return {'単位':'全73場を復元抽出。0取得場と未知だけの場もclusterに残すが0円取引を足さない。',
            '場数':len(sessions),'回数':5000,'seed':124,'主条件':[125,3600],'政策':output,
            '意味':'既知IFD条件付き平均の探索内参考。未知期間再現と多重比較補正済み有意性ではない。'}


# ----------------------------------------
def table_rows(records: list[dict],sessions: list[str],scene_info: dict,chosen: dict,traces: dict,aggregate: dict,coverage: dict,module) -> list[dict]:
    """
    機能: 140比較・全取得明細・主全73場を作り、0取得を金額0へしない。
    引数: records/sessions(list)、scene_info/chosen/traces/aggregate/coverage(dict)、module(モジュール)。返り値: list[dict]。
    """
    headers = ['試行','政策','価格軸','評価分','同幅pt','対象場数','取得場数','未取得場数','取得数','Source反転数','H完了','H不足','順行先着','逆行先着','両幅未到達','到達済み順行率','全完了順行率','先着70%達成','全73場取得','両条件達成','IFD代用既知','IFD代用未知','C0代用差引円','C5代用利益円','C5代用損失絶対円','C5代用差引円','C5代用平均円','C5代用PF']
    comparison = []
    for p in POLICIES:
        cov = coverage[p]
        for axis in ('BBO','Last'):
            for h in HORIZONS:
                for w in WIDTHS:
                    s = aggregate[p][axis][str(h)][str(w)]
                    comparison.append([127,p,axis,h/60,w,73,cov['filled_sessions'],len(cov['empty_sessions']),s['entries'],s['flips'],s['complete'],s['censored'],s['forward'],s['adverse'],s['neither'],s['resolved_rate'],s['complete_rate'],s['target70'],cov['all_sessions_filled'],s['target70'] is True and cov['all_sessions_filled'],s['ifd_known'],s['ifd_unknown'],s['ifd_net0_sum'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],s['ifd_net5_mean'],s['ifd_net5_pf']])
    # ----------------------------------------
    detail_headers = ['試行','セッション','出生ID','mode','元向き','出生JST','出生Index','出生物理行','RequestJST','取得JST','取得Index','取得物理行','取得risk','minimum_risk','maximum_risk','cap','invalidation','hold境界','hold最小','ATR5','元取得価格','逆取得価格','spread']
    detail_headers += [p+'採用' for p in POLICIES]
    detail_headers += ['H60状態','125原先着','125逆先着','125原Last先着','125逆Last先着','原IFD既知','逆IFD既知','原C5代用円','逆C5代用円','元再生正本参照']
    identities = {p:{(r['session'],r['case']['id']) for r in rows} for p,rows in chosen.items()}
    detail = []
    for r in chosen['A0']:
        case,born = r['case'],r['birth']
        e,q = case['source_event'],case['original']['entry']
        a,b = case['original'],case['reverse']
        ao,bo = module.observation(a,3600),module.observation(b,3600)
        ae,be = module.ifd(a,ao,125,'BBO'),module.ifd(b,bo,125,'BBO')
        row = [127,r['session'],case['id'],e['mode'],e['side'],clock(e['at']),e['at']['index'],e['at']['source_line'],clock(case['request_quote']),clock(q),q['index'],q['source_line'],r['risk'],e['minimum_risk'],born['maximum_risk'],e['entry_cap'],e['invalidation'],e['hold_boundary'],e['hold_minimum'],e['atr5'],a['entry_price'],b['entry_price'],q['ask']-q['bid']]
        row += [(r['session'],case['id']) in identities[p] for p in POLICIES]
        row += [ao['status'],module.touch(ao,125)['direction'],module.touch(bo,125)['direction'],module.touch(module.observation(case['chart_original'],3600),125)['direction'],module.touch(module.observation(case['chart_reverse'],3600),125)['direction'],ae['known'],be['known'],ae['net5'],be['net5'],f"再生正本:{r['session']}:{case['id']}"]
        detail.append(row)
    # ----------------------------------------
    session_headers = ['試行','セッション','出生数','取得候補数','出生状態内訳','主取得あり','主出生ID','主mode','主side','出生JST','RequestJST','取得JST','minimum_risk','取得risk','未解決で見送ったRaw数']
    for p in ('F0','FR'):
        session_headers += [p+'H60状態',p+'125順',p+'125逆',p+'125未到達',p+'H不足',p+'IFD既知',p+'IFD未知',p+'C5利益円',p+'C5損失絶対円',p+'C5既知差引円',p+'C5既知累計円（口座収支ではない）',p+'IFD未知累計']
    session_headers += ['未取得場累計']
    primary = {r['session']:r for r in chosen['F0']}
    cumulative,unknown,empty = {p:0 for p in ('F0','FR')},{p:0 for p in ('F0','FR')},0
    session_rows = []
    for sid in sessions:
        r = primary.get(sid)
        event = r['case']['source_event'] if r else None
        row = [127,sid,scene_info[sid]['births'],scene_info[sid]['fills'],json.dumps(scene_info[sid]['birth_statuses'],ensure_ascii=False,sort_keys=True),r is not None,r['case']['id'] if r else None,event['mode'] if r else None,event['side'] if r else None,clock(event['at']) if r else None,clock(r['case']['request_quote']) if r else None,clock(r['case']['original']['entry']) if r else None,event['minimum_risk'] if r else None,r['risk'] if r else None,sum(t['status']=='direction_unresolved' for t in traces[sid]['F0'])]
        if r is None:
            empty += 1
        for p in ('F0','FR'):
            if r is None:
                row += ['未取得',None,None,None,None,0,0,None,None,None,cumulative[p],unknown[p]]
                continue
            s = module.stats([r],p,'BBO',3600,125)
            o = module.observation(selected(r,p,'BBO'),3600)
            if s['ifd_net5_sum'] is not None:
                cumulative[p] += s['ifd_net5_sum']
            unknown[p] += s['ifd_unknown']
            row += [o['status'],s['forward'],s['adverse'],s['neither'],s['censored'],s['ifd_known'],s['ifd_unknown'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],cumulative[p],unknown[p]]
        row += [empty]
        session_rows.append(row)
    tables = [{'name':'正逆比較','headers':headers,'rows':comparison},{'name':'入口別診断','headers':detail_headers,'rows':detail},{'name':'全セッション','headers':session_headers,'rows':session_rows}]
    assert [len(t['rows']) for t in tables]==[140,len(records),73]
    assert all(len(set(t['headers']))==len(t['headers']) and all(len(r)==len(t['headers']) for r in t['rows']) for t in tables)
    return tables


# ----------------------------------------
def process(data: dict,module) -> tuple[dict,dict,dict]:
    """
    機能: 正本認証後に対象行を選び、140比較と出生台帳・閲覧3表を計算する。
    引数: data(dict)、module(モジュール)。返り値: tuple[dict,dict,dict]。
    """
    sessions,records,scene_info,ledger = audit_records(data)
    chosen,traces = policies_for(records,sessions)
    coverage = {p:{'target_sessions':73,'filled_sessions':len({r['session'] for r in rows}),
        'entries':len(rows),'empty_sessions':[s for s in sessions if not any(r['session']==s for r in rows)],
        'all_sessions_filled':len({r['session'] for r in rows})==73} for p,rows in chosen.items()}
    aggregate = {p:{axis:{str(h):{str(w):module.stats(rows,p,axis,h,w) for w in WIDTHS} for h in HORIZONS} for axis in ('BBO','Last')} for p,rows in chosen.items()}
    primary = aggregate['F0']['BBO']['3600']['125']
    ids = {p:[{'session':r['session'],'id':r['case']['id']} for r in rows] for p,rows in chosen.items()}
    result = {'成功':True,'試行':127,'主政策':'F0','主幅pt':125,'主時間秒':3600,
        '対象場数':73,'出生数':len(ledger),'全取得候補数':len(records),'coverage':coverage,'集計':aggregate,
        '主先着70達成':primary['target70'],'主全73場取得':coverage['F0']['all_sessions_filled'],
        '主両条件達成':primary['target70'] is True and coverage['F0']['all_sessions_filled'],
        '出生状態':dict(Counter(r['status'] for r in ledger)),'出生mode':dict(Counter(r['source_event']['mode'] for r in ledger)),
        '場診断':scene_info,'政策取得ID':ids,'bootstrap':bootstrap(chosen['F0'],sessions,module),
        '口座収支':False,'IFD実約定':False,'価格参考':'Last金額はすべてnull。FRは同時点実逆側の入口診断。',
        '固定集計moduleSHA256':MODULE_SHA}
    ledger_result = {'成功':True,'試行':127,'全出生':ledger,'選択経過':traces,
        '政策取得ID':ids,'時刻の意味':'SourceEvent.atは技術出生/配送。requestとevaluation/entryを区別。金融outcomesは元再生正本へ参照。'}
    return result,ledger_result,{'試行':127,'成功':True,'tables':table_rows(records,sessions,scene_info,chosen,traces,aggregate,coverage,module)}


# ----------------------------------------
def main() -> None:
    """
    機能: Root固定後に再生結果SHAを確認して集計を新規保存する。
    引数: CLI --result(Path)、--sha256(str)、--input-sha256(str)。返り値: None。
    """
    parser = argparse.ArgumentParser(description='127独立出生の最初実取得を固定規則で集計する')
    parser.add_argument('--result',type=Path,required=True)
    parser.add_argument('--sha256',required=True)
    parser.add_argument('--input-sha256',required=True)
    args = parser.parse_args()
    assert len(args.sha256)==len(args.input_sha256)==64 and sha(args.result)==args.sha256
    assert not any((OWN/name).exists() for name in ('集計.json','出生と選択の台帳.json','CSV用の表.json'))
    data = json.loads(args.result.read_text(encoding='utf-8'))
    assert data['input_sha256']==args.input_sha256
    result,ledger,tables = process(data,module124())
    assert result['出生mode']=={'Q':364,'R':147,'S':89,'T':50}
    for item in (result,ledger,tables):
        item['再生結果SHA256'] = args.sha256
        item['出生入力SHA256'] = args.input_sha256
        item['集計コードSHA256'] = sha(Path(__file__))
        item['条件SHA256'] = sha(OWN/'条件.md')
    assert sha(args.result)==args.sha256 and sha(MODULE)==MODULE_SHA
    save(OWN/'集計.json',result)
    save(OWN/'出生と選択の台帳.json',ledger)
    save(OWN/'CSV用の表.json',tables)
    save(OWN/'集計完了.json',{'成功':True,'試行':127,'入力前後不変':True,
        '集計SHA256':sha(OWN/'集計.json'),'出生台帳SHA256':sha(OWN/'出生と選択の台帳.json'),
        '表SHA256':sha(OWN/'CSV用の表.json'),'政策数':7,
        'CSV行数':[len(t['rows']) for t in tables['tables']]})
    print(json.dumps({'成功':True,'coverage':result['coverage'],
                      '主H60_125':result['集計']['F0']['BBO']['3600']['125'],
                      '主両条件達成':result['主両条件達成']},ensure_ascii=False))


if __name__=='__main__':
    main()
