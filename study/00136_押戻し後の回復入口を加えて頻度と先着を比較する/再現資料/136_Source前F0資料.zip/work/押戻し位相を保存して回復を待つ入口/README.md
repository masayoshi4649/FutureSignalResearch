# E1 A案の純状態部品

module `github.com/masayoshi4649/SessionTradeExecuter/e1episode`、package `e1episode`。自然出生・Raw/CSV本文・金融・新試行採番は行っていない。[条件表](条件表と差分案.md)のAだけを実装した。

```go
d := e1episode.New()
err := d.StartSession(sessionID, contract)
events, err := d.Observe(snapshot, quote, closedMinute, previousClosedMinutes)
d.RejectClock(reason)
stats := d.Stats()
trace := d.Lifecycle()
```

Quote/Barは129と同型。`closedMinute` はnil又は当Rawで既知となった確定1分、`previousClosedMinutes` はその足を含まない直前履歴。snapshotは同Rawの全5/15/30分公表を配送した後の `rules.Bank.Current`。場・限月・AsOf・refs・fresh時計・未来公表・既知値・確定1分の因果を部品側でも検査する。引数sliceやBarを可変参照で保存しない。

1分形成・量基準・EOFで閉じない処理はRootの `e1minute` adapterが担当する。価格時計gap>60秒は本部品でも取消し、adapterの時計拒否/欠分/閉鎖不良は `RejectClock` で通知する。量だけ未知の時は当足の量条件不成立として待機し、全episode取消しを通知しない。外部RejectClockのTrace.Atは部品へ最後に渡された原行なので、通知元の棄却行はadapterの証跡へ別記する。

`Event` はsession/id/mode=E1/side/at/entry_cap/invalidation/atr5/hold_boundary/hold_minimum/minimum_risk/refs/fieldsを持つ。方向はpatternのまま、T8未適用。拒否1分、K固定原行、15分準備位相、新5分改善ref、別回復1分、維持開始/経過/行数、episode/回復期限をfieldsへ保存する。`Stats` は理由別件数とactive/episodes/events、`Lifecycle` は接触→K固定→5分改善→1分回復→出生/取消の小証跡を返す。

新規のH60限界、E0最優先、旧L0との実取得競合、正常実BBO・1秒後・30秒TTL・実取得cap/riskはRootのSourceadapterが担当する。本部品はRaw reader・注文・損益を含まず、1場1回capも持たない。旧E0/L0は変更しない。Source133のPath!=E0を直接使うとgeometry検査を通らないため、E1専用取得adapterが必要。

`context` は129のcommon/directional、`rejection` は129の方向実体/ヒゲ式、K/I/cap/risk/量比較は129 C1の式を基準化した。変更は前Hist5正の削除、15分押戻し履歴、新5分改善、別1分回復、接触ATR固定、明示した時計とID消費。生データ経路は再実装していない。

人工は `go test -count=1 ./...`、静的検査は `go vet ./...`、buildは `go build ./...`。通常の成功・鏡像・負Hist回復・正Hist15への回復後も履歴保持、未来/古い足、900/120 strict、配送秒位相、現在未知、同15分再使用禁止・新15分再準備、600秒cooldown、接触ATR/cap非緩和を確認する。新しい2場を含む自然本文は未読。
