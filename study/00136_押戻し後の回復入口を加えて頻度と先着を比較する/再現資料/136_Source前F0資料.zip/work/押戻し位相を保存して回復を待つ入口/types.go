// Package e1episode は、A案の因果順序だけを扱う非金融の純状態部品です。
package e1episode

import rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"

type Quote struct {
	Clock      string  `json:"clock"`
	Time       float64 `json:"time"`
	Index      int64   `json:"index"`
	SourceLine int64   `json:"source_line"`
	Last       float64 `json:"last"`
	Bid        float64 `json:"bid"`
	Ask        float64 `json:"ask"`
	QuoteOK    bool    `json:"quote_ok"`
}

type Bar struct {
	Start       float64     `json:"start"`
	End         float64     `json:"end"`
	OHLC        rules.OHLC  `json:"ohlc"`
	TR          rules.Value `json:"tr"`
	Rows        int         `json:"rows"`
	First       rules.Quote `json:"first"`
	Last        rules.Quote `json:"last"`
	PriceKnown  bool        `json:"price_known"`
	VolumeKnown bool        `json:"volume_known"`
	Volume      float64     `json:"volume"`
}

type Stamp struct {
	Time  float64 `json:"time"`
	Index int64   `json:"index"`
	Line  int64   `json:"source_line"`
}

type Event struct {
	Session      string         `json:"session"`
	ID           string         `json:"id"`
	Mode         string         `json:"mode"`
	Side         int            `json:"side"`
	At           Stamp          `json:"at"`
	EntryCap     float64        `json:"entry_cap"`
	Invalidation float64        `json:"invalidation"`
	ATR5         float64        `json:"atr5"`
	HoldBoundary float64        `json:"hold_boundary"`
	HoldMinimum  float64        `json:"hold_minimum"`
	MinimumRisk  float64        `json:"minimum_risk"`
	Refs         []rules.Ref    `json:"refs"`
	Fields       map[string]any `json:"fields"`
}

type Trace struct {
	Session   string         `json:"session"`
	Contract  string         `json:"contract"`
	EpisodeID string         `json:"episode_id"`
	Side      int            `json:"side"`
	Stage     string         `json:"stage"`
	Reason    string         `json:"reason"`
	At        rules.Quote    `json:"at"`
	Fields    map[string]any `json:"fields"`
}

type Stats struct {
	Counts   map[string]uint64 `json:"counts"`
	Active   int               `json:"active"`
	Episodes uint64            `json:"episodes"`
	Events   uint64            `json:"events"`
}

type episode struct {
	id                      string
	side                    int
	cohort                  string
	contact                 rules.Quote
	low, high, atr, expires float64
	phase15                 rules.Ref
	hist15                  float64
	contact5                rules.Ref
	refs                    []rules.Ref
	reject                  *Bar
	frozenAt                *rules.Quote
	k, invalidation, cap    float64
	improvement             *rules.Publication
	recoverExpires          float64
	confirmed               *Bar
	cross                   *rules.Quote
	holdRows                int
}

type Detector struct {
	session, contract string
	active            map[int]*episode
	used              map[string]bool
	cooldown          map[int]float64
	last              *Quote
	sequence, events  uint64
	counts            map[string]uint64
	trace             []Trace
}
