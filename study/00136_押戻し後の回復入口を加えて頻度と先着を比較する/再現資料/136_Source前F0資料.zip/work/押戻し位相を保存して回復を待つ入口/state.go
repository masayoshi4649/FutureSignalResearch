package e1episode

import (
	"encoding/json"
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
)

// ----------------------------------------
// New は、自然データを読まない空の純状態部品を作ります。
//
// 引数: なし。返り値: *Detectorです。使用前にStartSessionを呼びます。
func New() *Detector { return &Detector{} }

// ----------------------------------------
// StartSession は、当場のepisode・消費済みID・cooldownを初期化します。
//
// 引数: sessionID/contract(string)。返り値: errorは空識別子です。
func (d *Detector) StartSession(sessionID, contract string) error {
	if sessionID == "" || contract == "" {
		return fmt.Errorf("場又は限月が空")
	}
	*d = Detector{session: sessionID, contract: contract, active: map[int]*episode{}, used: map[string]bool{}, cooldown: map[int]float64{}, counts: map[string]uint64{}, trace: []Trace{}}
	return nil
}

// ----------------------------------------
// Stats は、内部mapと独立した拒否理由の件数を返します。
//
// 引数: なし。返り値: Statsです。
func (d *Detector) Stats() Stats {
	s := Stats{Counts: map[string]uint64{}, Active: len(d.active), Episodes: d.sequence, Events: d.events}
	for k, v := range d.counts {
		s.Counts[k] = v
	}
	return s
}

// ----------------------------------------
// Lifecycle は、外部から状態を改変できないepisodeの小証跡を返します。
//
// 引数: なし。返り値: []Traceです。
func (d *Detector) Lifecycle() []Trace {
	data, err := json.Marshal(d.trace)
	if err != nil {
		panic(err)
	}
	out := []Trace{}
	if err = json.Unmarshal(data, &out); err != nil {
		panic(err)
	}
	return out
}

// ----------------------------------------
// record は、状態遷移と拒否理由だけを小さく保存します。
//
// 引数: e(*episode)、stage/reason(string)、q(Quote)、fields(map[string]any)。返り値: なし。
func (d *Detector) record(e *episode, stage, reason string, q Quote, fields map[string]any) {
	d.counts[stage+"/"+reason]++
	d.trace = append(d.trace, Trace{Session: d.session, Contract: d.contract, EpisodeID: e.id, Side: e.side, Stage: stage, Reason: reason, At: rq(q), Fields: fields})
}

// ----------------------------------------
// cancel は、Kや参照を書き換えずepisodeを終えます。消費済み15分IDは戻しません。
//
// 引数: e(*episode)、reason(string)、q(Quote)。返り値: なし。
func (d *Detector) cancel(e *episode, reason string, q Quote) {
	d.record(e, "取消", reason, q, map[string]any{"phase15": e.phase15, "expires": e.expires, "recovery_expires": e.recoverExpires})
	delete(d.active, e.side)
}

// ----------------------------------------
// RejectClock は、adapterの時計拒否・欠分・閉鎖不良等で全episodeを取り消します。
//
// 引数: reason(string)。返り値: なし。量だけ未知なら当足不成立で待機し、本関数を呼びません。
// 消費済みIDと出生cooldownは保持します。外部通知のTrace.Atは最後に部品へ渡された原行です。
func (d *Detector) RejectClock(reason string) {
	q := Quote{}
	if d.last != nil {
		q = *d.last
	}
	for _, side := range []int{1, -1} {
		if e := d.active[side]; e != nil {
			d.cancel(e, "短期未知/"+reason, q)
		}
	}
	if d.counts != nil {
		d.counts["短期未知通知/"+reason]++
	}
}

// ----------------------------------------
// arm は、15分押戻しの同ID/sideにつき一度だけ固定帯とATRを保存します。
//
// 引数: s(rules.Snapshot)、q(Quote)、side(int)、cohort(string)。返り値: なし。
func (d *Detector) arm(s rules.Snapshot, q Quote, side int, cohort string) {
	p15, ok := s.Frames[900]
	if !ok || !p15.Frame.Frame.PriceKnown {
		return
	}
	h := p15.Frame.Frame.Technical.Histogram
	if !known(h) || float64(side)*h.Value > 0 {
		d.counts["準備不可/15分押戻し未知又は未成立"]++
		return
	}
	key := fmt.Sprintf("%s/%d", p15.Frame.Frame.ID, side)
	if d.used[key] {
		d.counts["準備不可/15分ID消費済み"]++
		return
	}
	if at, yes := d.cooldown[side]; yes && q.Time-at < 600 {
		d.counts["準備不可/600秒cooldown"]++
		return
	}
	p5 := s.Frames[300]
	t := p5.Frame.Frame.Technical
	if !known(t.EMA8, t.EMA21) {
		d.counts["準備不可/5分帯未知"]++
		return
	}
	lo := math.Min(t.EMA8.Value, t.EMA21.Value) - .25*t.ATR.Value
	hi := math.Max(t.EMA8.Value, t.EMA21.Value) + .25*t.ATR.Value
	if q.Last < lo || q.Last > hi {
		return
	}
	d.sequence++
	e := &episode{id: fmt.Sprintf("%s/E1/%d/%06d", d.session, side, d.sequence), side: side, cohort: cohort, contact: rq(q), low: lo, high: hi, atr: t.ATR.Value, expires: q.Time + 900, phase15: reference(p15), hist15: h.Value, contact5: reference(p5), refs: merge(s.Refs)}
	d.active[side] = e
	d.used[key] = true
	d.record(e, "接触", "15分押戻し位相を保存", q, map[string]any{"hist15": h, "phase15": e.phase15, "band_low": lo, "band_high": hi, "contact_atr": e.atr, "expires": e.expires, "cohort": cohort})
}

// ----------------------------------------
// freeze は、129の拒否1分からK/Iを一度だけ作り、接触ATRでcapを固定します。
//
// 引数: e(*episode)、b(Bar)、history([]Bar)、s(rules.Snapshot)、q(Quote)。返り値: なし。
func (d *Detector) freeze(e *episode, b Bar, history []Bar, s rules.Snapshot, q Quote) {
	if b.End <= e.contact.Time || b.Last.Index < e.contact.Index || b.Last.Line < e.contact.Line || b.Last.Time < e.contact.Time || !quantity(b, history) || !rejection(b, e.side) || b.OHLC.High-b.OHLC.Low > e.atr || b.OHLC.Low > e.high || b.OHLC.High < e.low {
		d.record(e, "拒否1分待ち", "接触/拒否形/同足量/幅の不成立", q, nil)
		return
	}
	x := b
	at := rq(q)
	e.reject = &x
	e.frozenAt = &at
	if e.side > 0 {
		e.k = b.OHLC.High + 5
		e.invalidation = b.OHLC.Low - 5
	} else {
		e.k = b.OHLC.Low - 5
		e.invalidation = b.OHLC.High + 5
	}
	e.cap = e.k + float64(e.side)*math.Min(20, .25*e.atr)
	e.refs = merge(e.refs, s.Refs)
	d.record(e, "K固定", "拒否1分と接触ATRを固定", q, map[string]any{"reject_minute": b, "K": e.k, "I": e.invalidation, "cap": e.cap, "atr": e.atr, "expires": e.expires})
}

// ----------------------------------------
// improve は、K固定後に当原行へ配送された別5分の改善を保存します。
//
// 引数: e(*episode)、s(rules.Snapshot)、q(Quote)。返り値: なし。
func (d *Detector) improve(e *episode, s rules.Snapshot, q Quote) {
	p := s.Frames[300]
	f := p.Frame.Frame
	t := f.Technical
	if f.ID == e.contact5.ID || f.End <= e.contact5.End || f.End <= e.contact.Time || f.End < e.reject.End || p.Stamp.Time <= e.frozenAt.Time || p.Stamp.Index <= e.frozenAt.Index || p.Stamp.Line <= e.frozenAt.Line || p.Stamp != (rules.Stamp{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine)}) {
		return
	}
	if !known(t.Histogram, t.PreviousHistogram) || float64(e.side)*(t.Histogram.Value-t.PreviousHistogram.Value) <= 0 {
		d.record(e, "5分改善待ち", "後続Hist増分が未知又は非改善", q, nil)
		return
	}
	x := p
	e.improvement = &x
	e.recoverExpires = math.Min(e.expires, p.Stamp.Time+120)
	e.refs = merge(e.refs, s.Refs)
	d.record(e, "5分改善", "後続公表の改善を保存", q, map[string]any{"improvement": reference(p), "hist": t.Histogram, "previous_hist": t.PreviousHistogram, "recovery_expires": e.recoverExpires})
}

// ----------------------------------------
// recover は、改善配送後に始まった別1分のClose/同足量/実Lastだけを確認します。
//
// 引数: e(*episode)、b(Bar)、history([]Bar)、s(rules.Snapshot)、q(Quote)。返り値: なし。
func (d *Detector) recover(e *episode, b Bar, history []Bar, s rules.Snapshot, q Quote) {
	m := e.improvement.Stamp
	x := float64(e.side)
	if b.Start < m.Time || b.End <= e.reject.End || b.Start < e.reject.End || b.First.Index <= m.Index || b.First.Line <= m.Line || !quantity(b, history) || x*(b.OHLC.Close-e.k) < 0 || x*(q.Last-e.k) < 0 {
		d.record(e, "回復1分待ち", "後続別足/同足量/Close又はLast維持の不成立", q, nil)
		return
	}
	z := b
	e.confirmed = &z
	e.refs = merge(e.refs, s.Refs)
	d.record(e, "1分回復", "新5分配送後の別確定足", q, map[string]any{"recovery_minute": b, "previous_minute": history[len(history)-1], "K": e.k})
}

// ----------------------------------------
// hold は、回復確認原行を第1行として別Raw/1秒以上10秒以内で出生を返します。
//
// 引数: e(*episode)、s(rules.Snapshot)、q(Quote)。返り値: *Eventは出生又はnilです。
func (d *Detector) hold(e *episode, s rules.Snapshot, q Quote) *Event {
	x := float64(e.side)
	risk := x * (q.Last - e.invalidation)
	if x*(q.Last-e.k) < 0 || x*(q.Last-e.cap) > 0 || risk < 10 || risk > math.Min(125, 1.5*e.atr) {
		e.cross = nil
		e.holdRows = 0
		d.counts["維持待ち/K又はcap/risk不成立"]++
		return nil
	}
	if e.cross == nil || q.Time-e.cross.Time > 10 {
		at := rq(q)
		e.cross = &at
		e.holdRows = 1
		return nil
	}
	if int(q.Index) <= e.cross.Index || int(q.SourceLine) <= e.cross.Line {
		return nil
	}
	e.holdRows++
	if q.Time-e.cross.Time < 1 {
		return nil
	}
	e.refs = merge(e.refs, s.Refs)
	fields := map[string]any{"direction_policy": "pattern", "t8_applied": false, "cohort": e.cohort, "contact": e.contact, "phase15": e.phase15, "phase15_hist": e.hist15, "contact5": e.contact5, "reject_minute": *e.reject, "K_frozen_at": *e.frozenAt, "improvement_ref": reference(*e.improvement), "recovery_minute": *e.confirmed, "episode_expires": e.expires, "recovery_expires": e.recoverExpires, "hold_started_at": *e.cross, "hold_rows": e.holdRows, "hold_elapsed_seconds": q.Time - e.cross.Time, "entry_ttl_seconds": 30, "risk_min": 10, "risk_max": math.Min(125, 1.5*e.atr), "contact_atr": e.atr, "hold_strict": false}
	event := &Event{Session: d.session, ID: e.id + fmt.Sprintf("/%d", q.Index), Mode: "E1", Side: e.side, At: Stamp{Time: q.Time, Index: q.Index, Line: q.SourceLine}, EntryCap: e.cap, Invalidation: e.invalidation, ATR5: e.atr, HoldBoundary: e.k, HoldMinimum: 0, MinimumRisk: 10, Refs: append([]rules.Ref(nil), e.refs...), Fields: fields}
	d.events++
	d.cooldown[e.side] = q.Time
	d.record(e, "出生", "別Rawで1秒以上のK維持", q, map[string]any{"event_id": event.ID, "hold_started_at": *e.cross, "hold_rows": e.holdRows, "hold_elapsed_seconds": q.Time - e.cross.Time, "K": e.k, "I": e.invalidation, "cap": e.cap, "atr": e.atr})
	delete(d.active, e.side)
	return event
}

// ----------------------------------------
// Observe は、型付きの当時Snapshot/Raw/既知確定1分だけからE1を順に進めます。
//
// 引数: s(rules.Snapshot)、q(Quote)、closed(*Bar|nil)、previous([]Bar)はclosedを含まない履歴。
// 返り値: []Event/error。Raw reader・1分形成・注文・金融を含みません。
func (d *Detector) Observe(s rules.Snapshot, q Quote, closed *Bar, previous []Bar) ([]Event, error) {
	if err := validate(s, q, d.session, d.contract); err != nil {
		return nil, err
	}
	if closed != nil && !validBar(*closed, q) {
		current := q
		d.last = &current
		d.RejectClock("確定1分未知/遅延/未来")
		return nil, fmt.Errorf("確定1分の品質又は因果が不正")
	}
	if d.last != nil {
		if q.Index == d.last.Index {
			if q != *d.last {
				return nil, fmt.Errorf("同原行が改変")
			}
			return nil, nil
		}
		if q.Index < d.last.Index || q.SourceLine <= d.last.SourceLine || q.Time < d.last.Time {
			return nil, fmt.Errorf("原行順の逆転")
		}
		if q.Time-d.last.Time > 60 {
			current := q
			d.last = &current
			d.RejectClock("価格時計gap60超")
		}
	}
	current := q
	d.last = &current
	d.counts["採用原行"]++
	events := []Event{}
	for _, side := range []int{1, -1} {
		cohort, background := context(s, side)
		e := d.active[side]
		if e != nil {
			reason := ""
			if q.Time >= e.expires {
				reason = "episode900秒期限"
			} else if e.improvement != nil && q.Time >= e.recoverExpires {
				reason = "新5分配送120秒期限"
			} else if !background {
				reason = "現在背景が未知又は否定"
			} else if e.reject != nil && float64(side)*(q.Last-e.invalidation) <= 0 {
				reason = "凍結I到達"
			}
			if reason != "" {
				d.cancel(e, reason, q)
				e = nil
			}
		}
		if e == nil {
			if background {
				d.arm(s, q, side, cohort)
			} else {
				d.counts["準備不可/現在背景"]++
			}
			continue
		}
		if e.reject == nil && closed != nil {
			d.freeze(e, *closed, previous, s, q)
		}
		if e.reject != nil && e.improvement == nil {
			d.improve(e, s, q)
		}
		if e.improvement != nil && e.confirmed == nil && closed != nil {
			d.recover(e, *closed, previous, s, q)
		}
		if e.confirmed != nil {
			if event := d.hold(e, s, q); event != nil {
				events = append(events, *event)
			}
		}
	}
	return events, nil
}
