"""E1 A案の純状態だけを人工検査し、自然データを一切開かない。"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import subprocess

OWN = Path(__file__).resolve().parent
ROOT = OWN.parent.parent


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: 指定したコード・文書の全bytes指紋を得る。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def run(spec: tuple[str, list[str]]) -> tuple[str, subprocess.CompletedProcess]:
    """
    機能: 独立したGo人工/静的検査/buildを実行する。
    引数: spec(tuple[str,list[str]])。返り値: tuple[str,CompletedProcess]。
    """
    name, command = spec
    return name, subprocess.run(command, cwd=OWN, capture_output=True, text=True, encoding='utf-8')


# ----------------------------------------
def main() -> None:
    """
    機能: コード前後同体と人工6群の成功を準備証跡へ保存する。
    引数: なし。返り値: None。Raw reader・CSV・Source自然走査・金融は呼ばない。
    """
    names = ['go.mod', 'types.go', 'helpers.go', 'state.go', 'state_test.go',
             '条件表と差分案.md', 'README.md', '準備を確認する.py']
    before = {n: sha(OWN / n) for n in names}
    reused = [ROOT / 'work/129短期回復の出生' / n for n in
              ('context.go', 'detector.go', 'minute.go', 'minute_reuse.go', 'types.go', '仕様.md')]
    reused += [ROOT / 'work/121入口の反転切替/detector.go',
               ROOT / 'work/強い入口の探索期限を延ばす次仮説/Source入口の再生器/entry.go']
    sources = {str(p): sha(p) for p in reused}
    commands = [('人工', ['go', 'test', '-count=1', '-json', './...']),
                ('静的検査', ['go', 'vet', './...']), ('build', ['go', 'build', './...'])]
    checks = {}
    with ThreadPoolExecutor(max_workers=3) as pool:
        for name, result in pool.map(run, commands):
            assert result.returncode == 0, result.stdout + result.stderr
            log = OWN / (name + 'のログ.txt')
            log.write_text(result.stdout + result.stderr, encoding='utf-8')
            checks[name] = {'exit_code': result.returncode, 'log_sha256': sha(log)}
            if name == '人工':
                events = [json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
                passed = [e['Test'] for e in events if e.get('Action') == 'pass' and e.get('Test')]
                assert len(passed) == 6 and not any(e.get('Action') in ('fail', 'skip') for e in events)
                checks[name]['passed'] = passed
    assert before == {n: sha(OWN / n) for n in names}
    assert sources == {str(p): sha(p) for p in reused}
    proof = {'成功': True, '段階': 'A案純状態準備。自然実行・採番なし',
             'module': 'github.com/masayoshi4649/SessionTradeExecuter/e1episode', 'package': 'e1episode',
             'API': ['New', 'StartSession', 'Observe', 'RejectClock', 'Stats', 'Lifecycle'],
             '本部品SHA256': before, '再用定義の参照SHA256': sources, '検査': checks,
             '人工成功時計': {'contact': 10000, 'K_fixed': 10021, 'm_end': 10200,
                            'm_delivery': 10265, 'c_start': 10320, 'c_end': 10380,
                            'c_confirm_raw': 10381, 'birth_raw': 10382, 'hold_rows': 2,
                            'recovery_expires_exclusive': 10385, 'episode_expires_exclusive': 10900},
             '0秒と1秒配送位相の厳しさも人工固定': True, '売買鏡像': True,
             '15分ID側1回と600秒cooldown': True, '1場1回cap': False, '全出生返却': True,
             '入力コード前後同体': True, '参照コード前後同体': True,
             '自然RawとCSV本文読取': False, '新2場本文読取': False, '自然出生': False,
             '勝敗と損益計算': False, '新試行採番': False,
             '未実装の分離範囲': ['1分と量の形成はe1minute側', 'E0/L0競合と実取得はRoot adapter側',
                              'H60新規限界と実BBO cap/risk/30秒TTLはRoot adapter側']}
    dest = OWN / '準備の確認.json'
    dest.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'success': True, 'proof_sha256': sha(dest), 'files': before}, ensure_ascii=True))


if __name__ == '__main__':
    main()
