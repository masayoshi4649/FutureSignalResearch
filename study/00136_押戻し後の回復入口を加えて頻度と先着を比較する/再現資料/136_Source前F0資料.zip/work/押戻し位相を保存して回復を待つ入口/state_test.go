package e1episode

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
	"testing"
)

// ----------------------------------------
// tq は鏡像価格の人工Rawを作ります。
//
// 引数: at/price(float64)、side(int)。返り値: Quoteです。
func tq(at, price float64, side int) Quote {
	if side < 0 {
		price = 200 - price
	}
	return Quote{Clock: "人工", Time: at, Index: int64(at - 9000), SourceLine: int64(at-9000) + 1, Last: price, Bid: price - 1, Ask: price + 1, QuoteOK: true}
}

// ----------------------------------------
// ts は固定CSV同様のEnd+60以後配送による既知公表を作ります。
//
// 引数: q(Quote)、side(int)、contact(float64)、phaseRecovered(bool)、atr(float64)。返り値: rules.Snapshotです。
func ts(q Quote, side int, contact float64, phaseRecovered bool, atr float64) rules.Snapshot {
	s := rules.Snapshot{SessionID: "人工場", Contract: "人工限月", AsOf: rq(q), Frames: map[int]rules.Publication{}, RVOL5: rules.Value{Known: true, Value: 1}}
	initial15 := math.Floor((contact-65)/900) * 900
	initial5 := math.Floor((contact-65)/300) * 300
	for _, width := range []int{300, 900, 1800} {
		end := math.Floor((q.Time-65)/float64(width)) * float64(width)
		stamp := end + 65
		t := rules.Technical{EMA8: rules.Value{Known: true, Value: 100}, EMA21: rules.Value{Known: true, Value: 100}, Gap: rules.Value{Known: true, Value: float64(side) * 10}, EMA21Delta: rules.Value{Known: true, Value: float64(side)}, ATR: rules.Value{Known: true, Value: atr}, PreviousATR: rules.Value{Known: true, Value: atr}, TR: rules.Value{Known: true, Value: 30}, RSI: rules.Value{Known: true, Value: 50 + float64(side)*5}, PreviousRSI: rules.Value{Known: true, Value: 50 + float64(side)*4}, Histogram: rules.Value{Known: true, Value: -float64(side) * 2}, PreviousHistogram: rules.Value{Known: true, Value: -float64(side) * 3}}
		if width == 300 && end > initial5 {
			t.Histogram.Value = -float64(side)
			t.PreviousHistogram.Value = -float64(side) * 2
		}
		if width == 900 && phaseRecovered && end > initial15 {
			t.Histogram.Value = float64(side)
		}
		diPlus, diMinus := 30.0, 10.0
		if side < 0 {
			diPlus, diMinus = diMinus, diPlus
		}
		p := rules.Publication{Stamp: rules.Stamp{Time: stamp, Index: int(stamp - 9000), Line: int(stamp-9000) + 1}, Frame: rules.Frame{Frame: rules.ChartFrame{ID: fmt.Sprintf("人工%d/%v", width, end), SessionID: s.SessionID, Contract: s.Contract, Width: width, Start: end - float64(width), End: end, AvailableAt: end + 60, DeliveryAt: stamp, PriceKnown: true, OHLC: rules.OHLC{Open: 100, High: 110, Low: 90, Close: 100}, Technical: t}, DMI: rules.DMI{PlusDI: rules.Value{Known: true, Value: diPlus}, MinusDI: rules.Value{Known: true, Value: diMinus}, ADX: rules.Value{Known: true, Value: 25}}}}
		s.Frames[width] = p
		s.Refs = append(s.Refs, reference(p))
	}
	return s
}

// ----------------------------------------
// tb は、閉鎖の前後時計を持つ129同型の人工1分を作ります。
//
// 引数: start/open/high/low/close/volume(float64)、side(int)。返り値: Barです。
func tb(start, open, high, low, close, volume float64, side int) Bar {
	if side < 0 {
		open, high, low, close = 200-open, 200-low, 200-high, 200-close
	}
	return Bar{Start: start, End: start + 60, OHLC: rules.OHLC{Open: open, High: high, Low: low, Close: close}, Rows: 2, First: rq(tq(start+1, 100, side)), Last: rq(tq(start+59, close, 1)), PriceKnown: true, VolumeKnown: true, Volume: volume}
}

// ----------------------------------------
// observe は、人工だけを入力し予期しないerrorを検出します。
//
// 引数: t(*testing.T)、d(*Detector)、at/price/contact/atr(float64)、side(int)、recovered(bool)、b(*Bar)、history([]Bar)。返り値: []Eventです。
func observe(t *testing.T, d *Detector, at, price, contact, atr float64, side int, recovered bool, b *Bar, history []Bar) []Event {
	t.Helper()
	q := tq(at, price, side)
	events, err := d.Observe(ts(q, side, contact, recovered, atr), q, b, history)
	if err != nil {
		t.Fatal(err)
	}
	return events
}

// ----------------------------------------
// prepared は、接触・拒否K固定・新5分改善までを連続した人工Rawで進めます。
//
// 引数: t(*testing.T)、side(int)、contact(float64)、recovered(bool)、laterATR(float64)。返り値: *Detector/新5分配送timeです。
func prepared(t *testing.T, side int, contact float64, recovered bool, laterATR float64) (*Detector, float64) {
	t.Helper()
	d := New()
	if err := d.StartSession("人工場", "人工限月"); err != nil {
		t.Fatal(err)
	}
	observe(t, d, contact, 102, contact, 40, side, false, nil, nil)
	start := math.Floor(contact/60) * 60
	b := tb(start, 100, 104, 99, 103, 150, side)
	previous := tb(start-60, 100, 101, 99, 100, 100, side)
	observe(t, d, b.End+1, 103, contact, laterATR, side, recovered, &b, []Bar{previous})
	if d.active[side] == nil || d.active[side].reject == nil {
		t.Fatal("拒否1分が固定されない")
	}
	m := math.Ceil(contact/300)*300 + 65
	for at := b.End + 56; at < m; at += 55 {
		observe(t, d, at, 102, contact, laterATR, side, recovered, nil, nil)
	}
	observe(t, d, m, 102, contact, laterATR, side, recovered, nil, nil)
	if d.active[side] == nil || d.active[side].improvement == nil {
		t.Fatal("後の5分改善が保存されない")
	}
	return d, m
}

// ----------------------------------------
// finish は、新5分後に始まった別1分と2Raw/1秒の維持を人工生成します。
//
// 引数: t(*testing.T)、d(*Detector)、side(int)、contact/m/atr(float64)、recovered(bool)。返り値: Eventです。
func finish(t *testing.T, d *Detector, side int, contact, m, atr float64, recovered bool) Event {
	t.Helper()
	start := math.Floor(m/60)*60 + 60
	for at := m + 55; at < start+60; at += 55 {
		observe(t, d, at, 102, contact, atr, side, recovered, nil, nil)
	}
	b := tb(start, 102, 110, 101, 109, 200, side)
	p := tb(start-60, 102, 103, 101, 102, 100, side)
	if events := observe(t, d, b.End+1, 109, contact, atr, side, recovered, &b, []Bar{p}); len(events) != 0 {
		t.Fatal("1行だけで出生")
	}
	events := observe(t, d, b.End+2, 109, contact, atr, side, recovered, nil, nil)
	if len(events) != 1 {
		t.Fatalf("成立可能経路が出生しない: %+v", d.Lifecycle())
	}
	return events[0]
}

// ----------------------------------------
// TestSuccessMirrorAndFixedATR は、Aの成功、売買鏡像、接触ATR非緩和を確認します。
//
// 引数: t(*testing.T)。返り値: なし。接触前/回復時とも絶対Histは負領域です。
func TestSuccessMirrorAndFixedATR(t *testing.T) {
	var events []Event
	for _, side := range []int{1, -1} {
		d, m := prepared(t, side, 10000, false, 80)
		e := finish(t, d, side, 10000, m, 80, false)
		events = append(events, e)
		if e.ATR5 != 40 || e.Side != side || e.At.Time != 10382 || e.Fields["hold_rows"] != 2 || e.Fields["hold_elapsed_seconds"] != float64(1) || e.Fields["t8_applied"] != false {
			t.Fatal("ATR/方向/Raw維持を変更")
		}
		if d.Stats().Active != 0 || d.Stats().Events != 1 {
			t.Fatal("出生後のepisode保持")
		}
		trace := d.Lifecycle()
		trace[0].Fields["contact_atr"] = -1
		if d.Lifecycle()[0].Fields["contact_atr"] != float64(40) {
			t.Fatal("証跡が外から改変可能")
		}
	}
	if events[0].EntryCap+events[1].EntryCap != 200 || events[0].Invalidation+events[1].Invalidation != 200 || events[0].HoldBoundary+events[1].HoldBoundary != 200 {
		t.Fatal("鏡像価格不一致")
	}
}

// ----------------------------------------
// TestSavedPhaseSurvivesPositiveHist15 は、新15分が正へ回復しても保存位相を再要求しません。
//
// 引数: t(*testing.T)。返り値: なし。
func TestSavedPhaseSurvivesPositiveHist15(t *testing.T) {
	d, m := prepared(t, 1, 10700, true, 40)
	e := finish(t, d, 1, 10700, m, 40, true)
	q := tq(e.At.Time, 109, 1)
	s := ts(q, 1, 10700, true, 40)
	if s.Frames[900].Frame.Frame.Technical.Histogram.Value <= 0 || e.Fields["phase15_hist"].(float64) >= 0 {
		t.Fatal("履歴位相の保存になっていない")
	}
}

// ----------------------------------------
// TestFutureAndDifferentMinute は、未来公表・未閉鎖足・改善前開始の足を拒否します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestFutureAndDifferentMinute(t *testing.T) {
	d, m := prepared(t, 1, 10000, false, 40)
	q := tq(m+1, 102, 1)
	s := ts(q, 1, 10000, false, 40)
	p := s.Frames[300]
	p.Stamp.Time = q.Time + 1
	s.Frames[300] = p
	s.Refs[0] = reference(p)
	if _, err := d.Observe(s, q, nil, nil); err == nil {
		t.Fatal("未来公表を受理")
	}
	b := tb(10260, 102, 110, 101, 109, 200, 1)
	prior := tb(10200, 102, 103, 101, 102, 100, 1)
	observe(t, d, 10320, 102, 10000, 40, 1, false, nil, nil)
	if events := observe(t, d, 10321, 109, 10000, 40, 1, false, &b, []Bar{prior}); len(events) != 0 || d.active[1].confirmed != nil {
		t.Fatal("改善配送前開始の足を回復に使用")
	}
	q = tq(10322, 109, 1)
	future := tb(10320, 102, 110, 101, 109, 200, 1)
	if _, err := d.Observe(ts(q, 1, 10000, false, 40), q, &future, []Bar{b}); err == nil || d.Stats().Active != 0 {
		t.Fatal("未来1分を受理")
	}
}

// ----------------------------------------
// TestRecoveryDeadlineAndSecondPhase は、配送秒位相と120秒等号の厳しさを固定します。
//
// 引数: t(*testing.T)。返り値: なし。失敗例を自然件数で緩和しません。
func TestRecoveryDeadlineAndSecondPhase(t *testing.T) {
	d, m := prepared(t, 1, 10000, false, 40)
	observe(t, d, m+55, 102, 10000, 40, 1, false, nil, nil)
	observe(t, d, m+110, 102, 10000, 40, 1, false, nil, nil)
	b := tb(10320, 102, 110, 101, 109, 200, 1)
	p := tb(10260, 102, 103, 101, 102, 100, 1)
	if events := observe(t, d, m+120, 109, 10000, 40, 1, false, &b, []Bar{p}); len(events) != 0 || d.Stats().Active != 0 {
		t.Fatal("120秒等号を受理")
	}
	d = New()
	_ = d.StartSession("人工場", "人工限月")
	observe(t, d, 10000, 102, 10000, 40, 1, false, nil, nil)
	reject := tb(9960, 100, 104, 99, 103, 150, 1)
	prev := tb(9900, 100, 101, 99, 100, 100, 1)
	observe(t, d, 10021, 103, 10000, 40, 1, false, &reject, []Bar{prev})
	for at := 10076.0; at < 10261; at += 55 {
		observe(t, d, at, 102, 10000, 40, 1, false, nil, nil)
	}
	q := tq(10261, 102, 1)
	s := ts(tq(10265, 102, 1), 1, 10000, false, 40)
	s.AsOf = rq(q)
	pub := s.Frames[300]
	pub.Stamp = rules.Stamp{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine)}
	pub.Frame.Frame.DeliveryAt = q.Time
	s.Frames[300], s.Refs[0] = pub, reference(pub)
	if _, err := d.Observe(s, q, nil, nil); err != nil || d.active[1].improvement == nil {
		t.Fatal("End+61秒の改善配送が保存されない")
	}
	observe(t, d, 10316, 102, 10000, 40, 1, false, nil, nil)
	observe(t, d, 10371, 102, 10000, 40, 1, false, nil, nil)
	if events := observe(t, d, 10381, 109, 10000, 40, 1, false, &b, []Bar{p}); len(events) != 0 || d.Stats().Active != 0 {
		t.Fatal("配送+1秒位相の期限衝突を隠した")
	}
	// ----------------------------------------
	// 0秒配送Rawが1分のFirstならその足は不可、次足は120秒等号で不可です。
	d = New()
	_ = d.StartSession("人工場", "人工限月")
	observe(t, d, 10000, 102, 10000, 40, 1, false, nil, nil)
	observe(t, d, 10021, 103, 10000, 40, 1, false, &reject, []Bar{prev})
	for at := 10076.0; at < 10260; at += 55 {
		observe(t, d, at, 102, 10000, 40, 1, false, nil, nil)
	}
	q = tq(10260, 102, 1)
	s = ts(tq(10265, 102, 1), 1, 10000, false, 40)
	s.AsOf = rq(q)
	pub = s.Frames[300]
	pub.Stamp = rules.Stamp{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine)}
	pub.Frame.Frame.DeliveryAt = q.Time
	s.Frames[300], s.Refs[0] = pub, reference(pub)
	if _, err := d.Observe(s, q, nil, nil); err != nil {
		t.Fatal(err)
	}
	early := tb(10260, 102, 110, 101, 109, 200, 1)
	early.First = rq(q)
	earlyPrevious := tb(10200, 102, 103, 101, 102, 100, 1)
	observe(t, d, 10315, 102, 10000, 40, 1, false, nil, nil)
	observe(t, d, 10321, 109, 10000, 40, 1, false, &early, []Bar{earlyPrevious})
	if d.active[1].confirmed != nil {
		t.Fatal("新5分配送RawをFirstとする1分を受理")
	}
	observe(t, d, 10376, 102, 10000, 40, 1, false, nil, nil)
	if events := observe(t, d, 10380, 109, 10000, 40, 1, false, &b, []Bar{early}); len(events) != 0 || d.Stats().Active != 0 {
		t.Fatal("0秒配送の次足を120秒等号で受理")
	}
}

// ----------------------------------------
// TestIDConsumptionAndEpisodeExpiry は、取消し後の同15分再armingと900秒等号を拒否します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestIDConsumptionAndEpisodeExpiry(t *testing.T) {
	d := New()
	_ = d.StartSession("人工場", "人工限月")
	observe(t, d, 10000, 102, 10000, 40, 1, false, nil, nil)
	d.RejectClock("人工欠分")
	observe(t, d, 10001, 102, 10000, 40, 1, false, nil, nil)
	if d.Stats().Active != 0 || d.Stats().Episodes != 1 {
		t.Fatal("同15分IDを再利用")
	}
	for at := 10056.0; at < 10865; at += 55 {
		observe(t, d, at, 102, 10000, 40, 1, false, nil, nil)
	}
	observe(t, d, 10865, 102, 10000, 40, 1, false, nil, nil)
	if d.Stats().Episodes != 2 || d.Stats().Active != 1 {
		t.Fatal("新15分IDで再準備不可")
	}
	d = New()
	_ = d.StartSession("人工場", "人工限月")
	observe(t, d, 10000, 102, 10000, 40, 1, false, nil, nil)
	for at := 10055.0; at < 10900; at += 55 {
		observe(t, d, at, 102, 10000, 40, 1, false, nil, nil)
	}
	observe(t, d, 10900, 120, 10000, 40, 1, false, nil, nil)
	if d.Stats().Counts["取消/episode900秒期限"] != 1 {
		t.Fatal("900秒等号を拒否しない")
	}
}

// ----------------------------------------
// TestCooldownAndCurrentUnknown は、600秒cooldownと現在背景未知による取消しを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestCooldownAndCurrentUnknown(t *testing.T) {
	d, m := prepared(t, 1, 10000, false, 40)
	e := finish(t, d, 1, 10000, m, 40, false)
	for at := e.At.Time + 55; at < e.At.Time+599; at += 55 {
		observe(t, d, at, 102, 10000, 40, 1, false, nil, nil)
	}
	observe(t, d, e.At.Time+599, 102, 10000, 40, 1, false, nil, nil)
	if d.Stats().Active != 0 {
		t.Fatal("600秒前に再準備")
	}
	observe(t, d, e.At.Time+600, 102, 10000, 40, 1, false, nil, nil)
	if d.Stats().Active != 1 {
		t.Fatal("600秒等号で再準備を禁止")
	}
	q := tq(e.At.Time+601, 102, 1)
	s := ts(q, 1, 10000, false, 40)
	p := s.Frames[300]
	p.Frame.Frame.Technical.Histogram = rules.Value{}
	s.Frames[300] = p
	if _, err := d.Observe(s, q, nil, nil); err != nil || d.Stats().Active != 0 {
		t.Fatal("現在背景未知で取消さない")
	}
}
