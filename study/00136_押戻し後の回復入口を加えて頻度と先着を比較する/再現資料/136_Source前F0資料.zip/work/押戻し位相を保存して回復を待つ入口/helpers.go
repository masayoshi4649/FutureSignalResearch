package e1episode

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
)

// ----------------------------------------
// finite は既知値の有限性を検査します。
//
// 引数: values(...float64)。返り値: boolです。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// ----------------------------------------
// known は既知性と既知値の有限性を同時に検査します。
//
// 引数: values(...rules.Value)。返り値: boolです。未知を0として使いません。
func known(values ...rules.Value) bool {
	for _, v := range values {
		if !v.Known || !finite(v.Value) {
			return false
		}
	}
	return true
}

// ----------------------------------------
// rq は129同型Quoteから公開SnapshotのQuoteへ写します。
//
// 引数: q(Quote)。返り値: rules.Quoteです。
func rq(q Quote) rules.Quote {
	return rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last}
}

// ----------------------------------------
// reference は公表の当時出典だけを値で取得します。
//
// 引数: p(rules.Publication)。返り値: rules.Refです。
func reference(p rules.Publication) rules.Ref {
	f := p.Frame.Frame
	return rules.Ref{ID: f.ID, Width: f.Width, End: f.End, Delivered: p.Stamp}
}

// ----------------------------------------
// merge は参照を値で結合し同じ幅/IDを一度だけ保存します。
//
// 引数: lists(...[]rules.Ref)。返り値: []rules.Refです。
func merge(lists ...[]rules.Ref) []rules.Ref {
	out := []rules.Ref{}
	seen := map[string]bool{}
	for _, list := range lists {
		for _, r := range list {
			k := fmt.Sprintf("%d/%s", r.Width, r.ID)
			if !seen[k] {
				out = append(out, r)
				seen[k] = true
			}
		}
	}
	return out
}

// ----------------------------------------
// context は129 common/directionalの数式を再用し、Hist5の正符号だけを要求しません。
//
// 引数: s(rules.Snapshot)、side(int)。返り値: cohort(string)/boolです。
func context(s rules.Snapshot, side int) (string, bool) {
	p5, k5 := s.Frames[300]
	p15, k15 := s.Frames[900]
	if !k5 || !k15 || !p5.Frame.Frame.PriceKnown || !p15.Frame.Frame.PriceKnown {
		return "", false
	}
	t := p5.Frame.Frame.Technical
	x := float64(side)
	if !known(t.ATR, t.PreviousATR, t.TR, t.RSI, t.PreviousRSI, t.Histogram, s.RVOL5) || t.ATR.Value <= 0 || t.PreviousATR.Value <= 0 || t.TR.Value < 0 || t.TR.Value > 2*t.PreviousATR.Value || math.Abs(t.RSI.Value-t.PreviousRSI.Value) > 10 || s.RVOL5.Value < .5 || x*(t.RSI.Value-50) < -10 {
		return "", false
	}
	d := p15.Frame.DMI
	a15 := p15.Frame.Frame.Technical
	if !known(d.PlusDI, d.MinusDI, d.ADX) || x*(d.PlusDI.Value-d.MinusDI.Value) <= 0 || d.ADX.Value < 20 {
		return "", false
	}
	p30, present := s.Frames[1800]
	present = present && p30.Frame.Frame.PriceKnown
	a30 := p30.Frame.Frame.Technical
	if present && known(a30.Gap, a30.EMA21Delta) {
		return "B30", x*a30.Gap.Value > 0 && x*a30.EMA21Delta.Value > 0
	}
	if present && ((a30.Gap.Known && x*a30.Gap.Value <= 0) || (a30.EMA21Delta.Known && x*a30.EMA21Delta.Value <= 0)) {
		return "", false
	}
	return "B15", known(a15.Gap, a15.EMA21Delta) && x*a15.Gap.Value > 0 && x*a15.EMA21Delta.Value > 0
}

// ----------------------------------------
// validate は当場・当原行・freshな公表だけであることを検査します。
//
// 引数: s(rules.Snapshot)、q(Quote)、session/contract(string)。返り値: errorです。
func validate(s rules.Snapshot, q Quote, session, contract string) error {
	if session == "" || contract == "" || s.SessionID != session || s.Contract != contract || q.Index < 0 || q.SourceLine < 1 || !finite(q.Time, q.Last) || q.Last <= 0 || s.AsOf != rq(q) {
		return fmt.Errorf("当場/原行/Snapshot不整合")
	}
	if len(s.Refs) != len(s.Frames) {
		return fmt.Errorf("公表と参照数の不整合")
	}
	seen := map[int]bool{}
	for _, r := range s.Refs {
		p, ok := s.Frames[r.Width]
		f := p.Frame.Frame
		if !ok || seen[r.Width] || r != reference(p) || f.SessionID != session || f.Contract != contract || (r.Width != 300 && r.Width != 900 && r.Width != 1800) || f.ID == "" || !finite(f.Start, f.End, f.AvailableAt, f.DeliveryAt, p.Stamp.Time) || f.Start > f.End || f.End > f.AvailableAt || f.AvailableAt > f.DeliveryAt || f.DeliveryAt > p.Stamp.Time || p.Stamp.Time > q.Time || p.Stamp.Index < 0 || p.Stamp.Line < 1 || p.Stamp.Index > int(q.Index) || p.Stamp.Line > int(q.SourceLine) || q.Time >= f.End+float64(r.Width)+60 {
			return fmt.Errorf("未来/期限切れ/異場の公表")
		}
		seen[r.Width] = true
		o := f.OHLC
		if f.PriceKnown && (!finite(o.Open, o.High, o.Low, o.Close) || o.Low <= 0 || o.Low > o.Open || o.Low > o.Close || o.High < o.Open || o.High < o.Close) {
			return fmt.Errorf("既知OHLCが不正")
		}
		if f.VolumeKnown && (!finite(f.Volume) || f.Volume < 0) {
			return fmt.Errorf("既知数量が不正")
		}
		for _, v := range []rules.Value{f.Technical.EMA8, f.Technical.EMA21, f.Technical.Gap, f.Technical.EMA21Delta, f.Technical.ATR, f.Technical.PreviousATR, f.Technical.TR, f.Technical.RSI, f.Technical.PreviousRSI, f.Technical.Histogram, f.Technical.PreviousHistogram, p.Frame.DMI.PlusDI, p.Frame.DMI.MinusDI, p.Frame.DMI.ADX} {
			if v.Known && !finite(v.Value) {
				return fmt.Errorf("既知指標が非有限")
			}
		}
	}
	return nil
}

// ----------------------------------------
// validBar は当原行で既知となった確定1分を検査します。
//
// 引数: b(Bar)、q(Quote)。返り値: boolです。
func validBar(b Bar, q Quote) bool {
	o := b.OHLC
	return b.PriceKnown && b.Rows > 0 && finite(b.Start, b.End, o.Open, o.High, o.Low, o.Close, b.First.Time, b.Last.Time) && b.End == b.Start+60 && b.End <= q.Time && q.Time-b.End <= 30 && b.First.Time >= b.Start && b.Last.Time < b.End && b.Last.Time >= b.First.Time && b.First.Index >= 0 && b.First.Line >= 1 && b.First.Index <= b.Last.Index && b.First.Line <= b.Last.Line && int64(b.Last.Index) < q.Index && int64(b.Last.Line) < q.SourceLine && o.Low > 0 && o.Low <= o.Open && o.Low <= o.Close && o.High >= o.Open && o.High >= o.Close
}

// ----------------------------------------
// quantity は当足と直前連続1分の量を同じ定義で比較します。
//
// 引数: b(Bar)、history([]Bar)。返り値: boolです。形成中や未来足を使いません。
func quantity(b Bar, history []Bar) bool {
	if len(history) == 0 || !b.VolumeKnown || !finite(b.Volume) || b.Volume <= 0 {
		return false
	}
	p := history[len(history)-1]
	return p.PriceKnown && p.End == b.Start && p.End == p.Start+60 && p.VolumeKnown && finite(p.Volume) && p.Volume > 0 && b.Volume >= p.Volume && p.Last.Time < p.End && p.Last.Index < b.First.Index && p.Last.Line < b.First.Line
}

// ----------------------------------------
// rejection は129と同じ方向実体又は逆ヒゲ比0.25を判定します。
//
// 引数: b(Bar)、side(int)。返り値: boolです。
func rejection(b Bar, side int) bool {
	o := b.OHLC
	if float64(side)*(o.Close-o.Open) > 0 {
		return true
	}
	span := o.High - o.Low
	if span <= 0 {
		return false
	}
	wick := math.Min(o.Open, o.Close) - o.Low
	if side < 0 {
		wick = o.High - math.Max(o.Open, o.Close)
	}
	return wick/span >= .25
}
