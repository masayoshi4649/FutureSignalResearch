"""凍結Sourceを新しい作業先へ複写し、任意observerの接続点だけを加える。"""
from pathlib import Path
import json
import hashlib

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT/'work/強い入口の探索期限を延ばす次仮説/Source入口の再生器'
OWN = Path(__file__).resolve().parent
TARGET = OWN/'Source再生器'


def main() -> None:
    """
    機能: 旧コードを変更せず、新先へ必要Goソースと指紋を保存する。
    引数: なし。
    返り値: None。Raw/自然入力/金融は開かない。
    """
    TARGET.mkdir(exist_ok=False)
    files = list(SOURCE.glob('*.go')) + [SOURCE/'go.mod']
    hashes = {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    for p in files:
        (TARGET/p.name).write_bytes(p.read_bytes())
    path = TARGET/'entry.go'
    text = path.read_text('utf-8')
    old = 'func scan133(all []Scene133, at int) (out Result133, err error) {'
    new = '''func scan133(all []Scene133, at int) (Result133, error) {
	return scanCore133(all, at, nil)
}

// ----------------------------------------
// scanCore133 はlegacy処理を維持し任意の非金融observerへ同じ原行を通知します。
//
// 引数: all([]Scene133)、at(int)、observer(sourceObserver133又はnil)。
// 返り値: Result133/error。observerは元Bankや元状態を変更してはいけません。
func scanCore133(all []Scene133, at int, observer sourceObserver133) (out Result133, err error) {'''
    assert text.count(old) == 1
    text = text.replace(old,new)
    old = 'q, _, next, e := decodeRow(scan.Bytes(), out.Quality.Lines, index, scene, previous, &out.Quality, contracts)'
    new = 'q, reason, next, e := decodeRow(scan.Bytes(), out.Quality.Lines, index, scene, previous, &out.Quality, contracts)'
    assert text.count(old) == 1
    text = text.replace(old,new)
    old = '''		if q == nil {
			continue
		}'''
    new = '''		if q == nil {
			if observer != nil {
				observer.Rejected(reason)
			}
			continue
		}'''
    assert text.count(old) == 1
    text = text.replace(old,new)
    old = '		_ = newFills'
    new = '''		if observer != nil {
			if err = observer.Accepted(bank, *q, e0Born["L0"], newFills, scan.Bytes()); err != nil {
				return out, err
			}
		}'''
    assert text.count(old) == 1
    text = text.replace(old,new)
    path.write_text(text,encoding='utf-8')
    mod = TARGET/'go.mod'
    mod.write_text(mod.read_text('utf-8') + '''
require (
 github.com/masayoshi4649/SessionTradeExecuter/e1episode v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/e1minute v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/e1select v0.0.0
)
replace github.com/masayoshi4649/SessionTradeExecuter/e1episode => ../../押戻し位相を保存して回復を待つ入口
replace github.com/masayoshi4649/SessionTradeExecuter/e1minute => ../../押戻し回復の1分入力
replace github.com/masayoshi4649/SessionTradeExecuter/e1select => ../../押戻し回復の取得を時系列で選ぶ
''',encoding='utf-8')
    assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest() == value for p,value in hashes.items())
    proof = {'成功':True,'旧源前後同体':True,'旧源SHA256':hashes,
             '新先':str(TARGET),'変更':'任意observer接続点のみ。旧scan133はobserver無しへ委譲',
             '自然Raw読取':False,'金融読取':False}
    (OWN/'複写の確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'複写ファイル数':len(files),'元変更':False},ensure_ascii=False))


if __name__ == '__main__':
    main()
