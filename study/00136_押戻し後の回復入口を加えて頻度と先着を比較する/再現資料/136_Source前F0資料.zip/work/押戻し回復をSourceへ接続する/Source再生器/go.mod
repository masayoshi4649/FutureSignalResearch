module sourceentry133

go 1.24.2

require (
 github.com/masayoshi4649/SessionTradeExecuter/entryrules118 v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/entrybirth121 v0.0.0
)

replace github.com/masayoshi4649/SessionTradeExecuter/entryrules118 => ../../118複数技法の入口条件
replace github.com/masayoshi4649/SessionTradeExecuter/entrybirth121 => ../../121入口の反転切替

require (
 github.com/masayoshi4649/SessionTradeExecuter/e1episode v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/e1minute v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/e1select v0.0.0
)
replace github.com/masayoshi4649/SessionTradeExecuter/e1episode => ../../押戻し位相を保存して回復を待つ入口
replace github.com/masayoshi4649/SessionTradeExecuter/e1minute => ../../押戻し回復の1分入力
replace github.com/masayoshi4649/SessionTradeExecuter/e1select => ../../押戻し回復の取得を時系列で選ぶ
