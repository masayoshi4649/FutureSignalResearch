package holdingohlc113

import (
	"reflect"
	"testing"
)

// TestFrequencyKeepsAllAndDeduplicates は、最初1補完の副対照と全成立の主を区別します。
//
// 引数: t(*testing.T)。返り値: ありません。自然データや価格の成績は使いません。
func TestFrequencyKeepsAllAndDeduplicates(t *testing.T) {
	s := Scene133{Session: "s", Contract: "X"}
	legacy := Result133{Candidates: []*Candidate133{}}
	for i, x := range []struct {
		path  string
		at    float64
		index int64
	}{{"strong", 200, 20}, {"E0", 300, 30}} {
		q := testQuote133(x.at, x.index, 95, 105)
		legacy.Candidates = append(legacy.Candidates, &Candidate133{Policy: "L0", Path: x.path,
			Birth: Signal133{ID: []string{"旧補完", "旧E0"}[i], Quote: testQuote133(x.at-1, x.index-1, 95, 105)}, Entry: &q})
	}
	extra := []*E1Candidate{}
	for i, at := range []float64{100, 150, 200, 250, 400} {
		q := testQuote133(at, int64(at/10), 95, 105)
		extra = append(extra, &E1Candidate{ID: []string{"e1a", "e1b", "重複", "e1c", "e1d"}[i], DirectionPolicy: "pattern", Status: "filled",
			Birth: testQuote133(at-1, q.Index-1, 95, 105), Entry: &q})
	}
	frequency, err := frequencyE1Scene(s, legacy, extra)
	if err != nil {
		t.Fatal(err)
	}
	ids := []string{}
	for _, c := range frequency {
		ids = append(ids, c.ID)
	}
	want := []string{"e1a", "e1b", "旧補完", "e1c", "旧E0", "e1d"}
	if !reflect.DeepEqual(ids, want) {
		t.Fatal("全成立/旧対照包含/同原行重複差", ids)
	}
	first, err := selectE1Scene(s, legacy, extra)
	if err != nil {
		t.Fatal(err)
	}
	if len(first.C0) != 2 || len(first.S0) != 2 || first.S0[0].ID != "e1a" || first.S0[1].ID != "旧E0" {
		t.Fatal("固定の最初1補完を変更", first)
	}
	// ----------------------------------------
	// 取得Stampを変えず、後の価格や出生を変えても選択は変わらない。
	for _, c := range extra {
		c.Birth.Last = 10000
		c.Birth.Time = -10000
		c.Entry.Last = 50000
	}
	after, err := frequencyE1Scene(s, legacy, extra)
	if err != nil {
		t.Fatal(err)
	}
	afterIDs := []string{}
	for _, c := range after {
		afterIDs = append(afterIDs, c.ID)
	}
	if !reflect.DeepEqual(ids, afterIDs) {
		t.Fatal("価格又は出生で取得選択が変化")
	}
}
