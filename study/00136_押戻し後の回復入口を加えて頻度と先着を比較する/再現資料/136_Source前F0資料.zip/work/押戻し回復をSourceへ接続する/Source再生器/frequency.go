package holdingohlc113

import (
	"fmt"
	"sort"

	selectentry "github.com/masayoshi4649/SessionTradeExecuter/e1select"
)

// entryIdentity は、同じ場/限月の同一取得原行を識別します。
type entryIdentity struct {
	Session, Contract string
	Stamp             selectentry.Stamp
}

// ----------------------------------------
// frequencyE1Scene は、C0全件と重ならない全適格E1を頻度主A0へ加えます。
//
// 引数: s(Scene133)、legacy(Result133)、extra([]*E1Candidate)。
// 返り値: []selectentry.Candidate/error。1場の回数cap・将来価格・勝敗を使いません。
func frequencyE1Scene(s Scene133, legacy Result133, extra []*E1Candidate) ([]selectentry.Candidate, error) {
	selection, err := selectE1Scene(s, legacy, extra)
	if err != nil {
		return nil, err
	}
	rows := append([]selectentry.Candidate{}, selection.C0...)
	seen := map[entryIdentity]bool{}
	for _, c := range rows {
		key := entryIdentity{c.Session, c.Contract, c.EntryStamp}
		if seen[key] {
			return nil, fmt.Errorf("C0内の同一取得原行が複数。頻度を水増しせず停止")
		}
		seen[key] = true
	}
	for _, c := range extra {
		if c.Entry == nil {
			continue
		}
		stamp := selectionStamp(*c.Entry)
		key := entryIdentity{s.Session, s.Contract, stamp}
		if seen[key] {
			continue
		}
		seen[key] = true
		rows = append(rows, selectentry.Candidate{Session: s.Session, Contract: s.Contract, Kind: selectentry.E1, ID: c.ID,
			BirthStamp: selectionStamp(c.Birth), EntryStamp: stamp})
	}
	sort.Slice(rows, func(i, j int) bool {
		a, b := rows[i].EntryStamp, rows[j].EntryStamp
		if a.Time != b.Time {
			return a.Time < b.Time
		}
		if a.Index != b.Index {
			return a.Index < b.Index
		}
		return a.SourceLine < b.SourceLine
	})
	return rows, nil
}
