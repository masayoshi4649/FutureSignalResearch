package main

import (
	"flag"
	"fmt"
	"os"

	engine "sourceentry133"
)

// main は、F0後の明示実行だけを非金融のE1接続器へ渡します。
//
// 引数: CLIのinput/expected-sha/output(string)、workers(int)、execute-after-f0(bool)。
// 返り値: ありません。失敗時は終了コード1、未許可指定は2です。
func main() {
	input := flag.String("input", "", "固定入力")
	expected := flag.String("expected-sha", "", "固定SHA256")
	output := flag.String("output", "", "未作成出力")
	workers := flag.Int("workers", 8, "並列場数")
	execute := flag.Bool("execute-after-f0", false, "F0固定後の明示実行")
	flag.Parse()
	if !*execute || *input == "" || *expected == "" || *output == "" || flag.NArg() != 0 {
		fmt.Fprintln(os.Stderr, "F0後に入力・SHA・未作成出力を明示してください")
		os.Exit(2)
	}
	if err := engine.RunE1Source(*input, *expected, *output, *workers); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
