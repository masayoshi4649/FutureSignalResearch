package holdingohlc113

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	episode "github.com/masayoshi4649/SessionTradeExecuter/e1episode"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// artificialE1Event は、入口条件の代わりに専用取得adapterだけを試す手製票です。
//
// 引数: q(Quote)、side(int)。返り値: episode.Eventは左右鏡像のcap/risk/holdを持ちます。
func artificialE1Event(q Quote, side int) episode.Event {
	s := float64(side)
	return episode.Event{Session: "s", ID: fmt.Sprintf("s/E1/%d", side), Mode: "E1", Side: side,
		At:       episode.Stamp{Time: q.Time, Index: q.Index, Line: q.SourceLine},
		EntryCap: 100 + s*10, Invalidation: 100 - s*20, ATR5: 20,
		HoldBoundary: 100 - s, HoldMinimum: 0, MinimumRisk: 10}
}

// ----------------------------------------
// TestE1EntryGeometryAndMirror は、旧E0より広いE1リスクと次原行1秒を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。自然入力を使いません。
func TestE1EntryGeometryAndMirror(t *testing.T) {
	for _, side := range []int{1, -1} {
		q := testQuote133(100, 0, 95, 105)
		c, err := newE1Request(artificialE1Event(q, side), q, Scene133{Session: "s", Contract: "X", ForceClose: 500})
		if err != nil || c.Expires != 130 || c.DirectionPolicy != "pattern" || c.T8Applied {
			t.Fatal("出生と方向政策", err)
		}
		pendingE1(c, testQuote133(100, 1, 95, 105), 500)
		bad := testQuote133(101, 2, 95, 105)
		bad.QuoteOK = false
		pendingE1(c, bad, 500)
		if c.Entry != nil || c.Evaluation != nil {
			t.Fatal("同秒又は不正BBOを取得")
		}
		first := testQuote133(102, 3, 95, 105)
		pendingE1(c, first, 500)
		want := first.Ask
		if side < 0 {
			want = first.Bid
		}
		if c.Status != "filled" || *c.Entry != first || *c.EntryPrice != want || *c.RiskAtDecision != 25 {
			t.Fatal("E1専用risk又は売買鏡像", c)
		}
		pendingE1(c, testQuote133(103, 4, 85, 95), 500)
		if *c.Entry != first || *c.EntryPrice != want {
			t.Fatal("既取得を改変")
		}
	}
}

// ----------------------------------------
// TestE1RejectsAndExactBounds は、最初の不適格BBOで取消し有利化待機しないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestE1RejectsAndExactBounds(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, tc := range []struct {
			name string
			risk float64
			want string
		}{{"下限未満", 9, "risk_rejected"}, {"下限", 10, "filled"}, {"上限", 30, "filled"}, {"上限超", 31, "risk_rejected"}} {
			t.Run(fmt.Sprintf("%d%s", side, tc.name), func(t *testing.T) {
				q := testQuote133(100, 0, 95, 105)
				e := artificialE1Event(q, side)
				price := q.Ask
				if side < 0 {
					price = q.Bid
				}
				e.Invalidation = price - float64(side)*tc.risk
				c, err := newE1Request(e, q, Scene133{Session: "s", ForceClose: 500})
				if err != nil {
					t.Fatal(err)
				}
				pendingE1(c, testQuote133(101, 1, 95, 105), 500)
				if c.Status != tc.want {
					t.Fatal("risk境界", c)
				}
				if tc.want != "filled" {
					pendingE1(c, testQuote133(102, 2, 96, 104), 500)
					if c.Entry != nil || c.Status != tc.want {
						t.Fatal("取消後の価格改善を待った")
					}
				}
			})
		}
		for _, tc := range []struct {
			name string
			want string
		}{{"cap", "entry_cap_rejected"}, {"hold", "structure_lost"}, {"TTL", "unfilled_expired"}, {"新規限界", "force_close"}} {
			q := testQuote133(100, 0, 95, 105)
			e := artificialE1Event(q, side)
			if tc.name == "cap" {
				price := q.Ask
				if side < 0 {
					price = q.Bid
				}
				e.EntryCap = price - float64(side)
			}
			if tc.name == "hold" {
				e.HoldBoundary = 100 + float64(side)
			}
			c, err := newE1Request(e, q, Scene133{Session: "s", ForceClose: 500})
			if err != nil {
				t.Fatal(err)
			}
			at, force := 101.0, 500.0
			if tc.name == "TTL" {
				at = 130
			}
			if tc.name == "新規限界" {
				force = 101
			}
			pendingE1(c, testQuote133(at, 1, 95, 105), force)
			if c.Status != tc.want || c.Entry != nil {
				t.Fatal("取消境界", tc.name, c)
			}
		}
	}
}

// ----------------------------------------
// TestE1FutureRefAndE0Priority は、未来参照とE0同原行のE1取得を拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。Bankへは空の当場状態だけを渡します。
func TestE1FutureRefAndE0Priority(t *testing.T) {
	q := testQuote133(100, 0, 95, 105)
	e := artificialE1Event(q, 1)
	e.Refs = []rules.Ref{{Delivered: rules.Stamp{Time: 101, Index: 0, Line: 1}}}
	if _, err := newE1Request(e, q, Scene133{Session: "s", ForceClose: 500}); err == nil {
		t.Fatal("未来公表を受理")
	}
	for _, born := range []bool{true, false} {
		o, err := newE1Observer(Scene133{Session: "s", Contract: "X", Start: 90, End: 10000, ForceClose: 500})
		if err != nil {
			t.Fatal(err)
		}
		c, err := newE1Request(artificialE1Event(q, 1), q, o.Scene)
		if err != nil {
			t.Fatal(err)
		}
		o.Candidates = append(o.Candidates, c)
		bank := rules.NewBank()
		if err = bank.StartSession("s", "X"); err != nil {
			t.Fatal(err)
		}
		fills := []*Candidate133{}
		if !born {
			fills = append(fills, &Candidate133{Path: "E0", Policy: "L0"})
		}
		x := testQuote133(101, 1, 95, 105)
		if err = o.Accepted(bank, x, born, fills, []byte(`{}`)); err != nil {
			t.Fatal(err)
		}
		if c.Status != "cancelled_e0_priority" || c.Entry != nil {
			t.Fatal("E0優先がE1取得へ漏れた", c)
		}
	}
}

// ----------------------------------------
// TestE1PendingClockRejection は、出生後も時計否定で要求を取消し復活させないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。旧E0/L0の状態を入力しません。
func TestE1PendingClockRejection(t *testing.T) {
	for _, reason := range []string{"clock_missing", "clock_invalid", "backward_clock"} {
		o, err := newE1Observer(Scene133{Session: "s", Contract: "X", Start: 90, End: 10000, ForceClose: 500})
		if err != nil {
			t.Fatal(err)
		}
		q := testQuote133(100, 0, 95, 105)
		c, err := newE1Request(artificialE1Event(q, 1), q, o.Scene)
		if err != nil {
			t.Fatal(err)
		}
		o.Candidates = append(o.Candidates, c)
		o.Rejected(reason)
		pendingE1(c, testQuote133(101, 1, 95, 105), 500)
		if c.Status != "cancelled_clock_rejection" || c.Entry != nil || c.Evaluation != nil {
			t.Fatal("時計拒否をまたいで新規要求が復活", c)
		}
	}
}

// ----------------------------------------
// TestObserverLegacyParityAndSelection は、人工Rawの旧全値がobserverで変わらないことを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。自然Rawは開かず手製5行だけを使います。
func TestObserverLegacyParityAndSelection(t *testing.T) {
	times := []float64{100000, 100801, 100802, 115980, 115981}
	var plain []byte
	for _, at := range times {
		plain = append(plain, artificialLine133(t, at, 107, 105, 110)...)
	}
	path := filepath.Join(t.TempDir(), "人工.jsonl")
	if err := os.WriteFile(path, plain, 0600); err != nil {
		t.Fatal(err)
	}
	digest := sha256.Sum256(plain)
	s := Scene133{Session: "s", Contract: "X", Start: 90000, End: 120000, ForceClose: 119400,
		Raw: FileRef{Path: path, SHA256: hex.EncodeToString(digest[:])}, ExpectedAccepted: 5,
		ExpectedQuality: &Counts{Lines: 5, Accepted: 5, Delivered: 5}}
	for i, x := range []struct {
		at, end float64
		index   int
	}{{100000, 99940, 0}, {100801, 100740, 1}, {115980, 115920, 3}} {
		p := scorePublication133("s", 300, x.index, x.end)
		p.Frame.Frame.ID = fmt.Sprintf("s/5/%d", i)
		p.Stamp.Time = x.at
		s.Publications = append(s.Publications, p)
	}
	control, err := scan133([]Scene133{s}, 0)
	if err != nil {
		t.Fatal(err)
	}
	added, err := scanE1Source([]Scene133{s}, 0)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(control, added.Legacy) || !added.Success || added.RawPasses != 1 {
		t.Fatal("observerで旧全値が変化")
	}
	if len(added.Selection.C0) != 1 || !reflect.DeepEqual(added.Selection.C0, added.Selection.S0) {
		t.Fatal("E1無しで旧対照を欠落", added.Selection)
	}
	if len(added.E1Events) != 0 {
		t.Fatal("背景未知で新規E1を生成")
	}
}
