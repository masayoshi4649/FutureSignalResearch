"""接続器のコード・人工・実行ガードを固定する。自然入力は開かない。"""
from pathlib import Path
import subprocess
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
ENGINE = OWN/'Source再生器'


def main() -> None:
    """
    機能: 非キャッシュ人工・vet・build・CLIガードと旧源不変を保存する。
    引数: なし。
    返り値: None。Raw/自然CSV/金融は読まない。
    """
    proof = OWN/'Rootの準備の確認.json'
    assert not proof.exists()
    copy = json.loads((OWN/'複写の確認.json').read_bytes())
    assert all(hashlib.sha256((ROOT/p).read_bytes()).hexdigest() == value for p,value in copy['旧源SHA256'].items())
    files = list(ENGINE.glob('*.go')) + list((ENGINE/'cmd').rglob('*.go')) + [ENGINE/'go.mod',OWN/'接続の条件.md',Path(__file__).resolve()]
    for name in ('押戻し位相を保存して回復を待つ入口','押戻し回復の1分入力','押戻し回復の取得を時系列で選ぶ'):
        files += list((ROOT/'work'/name).glob('*.go')) + [ROOT/'work'/name/'go.mod']
    before = {str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    commands = [('go','test','-count=1','-json','./...'),('go','vet','./...'),('go','build','-o','E1接続Source.exe','./cmd/e1source')]
    logs = []
    tests = None
    for i,command in enumerate(commands):
        result = subprocess.run(command,cwd=ENGINE,capture_output=True,text=True,encoding='utf-8',check=False)
        assert result.returncode == 0,(command,result.stderr)
        path = OWN/f'人工実行{i+1}.txt'
        with path.open('x',encoding='utf-8',newline='\n') as stream:
            stream.write(result.stdout+result.stderr)
        logs.append({'command':list(command),'exit_code':0,'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
        if i == 0:
            parsed = [json.loads(line) for line in result.stdout.splitlines() if line.strip()]
            tests = {'主テスト':sum(x.get('Action')=='pass' and 'Test' in x and '/' not in x['Test'] for x in parsed),
                     '全passテスト':sum(x.get('Action')=='pass' and 'Test' in x for x in parsed),
                     'fail':sum(x.get('Action')=='fail' for x in parsed)}
            assert tests['fail'] == 0
    guard = subprocess.run([str(ENGINE/'E1接続Source.exe')],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',check=False)
    assert guard.returncode == 2 and not guard.stdout
    assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest() == value for p,value in before.items())
    result = {'成功':True,'コード前後同体':True,'旧Source前後同体':True,'ファイル':before,'コマンド':logs,'人工':tests,
              'CLI無指定拒否':{'exit_code':guard.returncode,'stderr':guard.stderr},
              'exe_sha256':hashlib.sha256((ENGINE/'E1接続Source.exe').read_bytes()).hexdigest(),
              '自然Raw読取':False,'自然CSV読取':False,'金融読取':False}
    with proof.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'人工':tests,'exe_sha256':result['exe_sha256'],'proof_sha256':hashlib.sha256(proof.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__ == '__main__':
    main()
