package e1select

import (
	"encoding/json"
	"fmt"
	"math"
	"math/rand"
	"reflect"
	"sort"
	"testing"
)

// candidate は、自然データを使わない識別候補を作ります。
//
// 引数: kind(Kind)、id(string)、time(float64)、index/line(int64)。
// 返り値: Candidateは場A/限月Kに属する人工候補です。
func candidate(kind Kind, id string, time float64, index, line int64) Candidate {
	return Candidate{Session: "A", Contract: "K", Kind: kind, ID: id,
		BirthStamp: Stamp{Time: 0, Index: 0, SourceLine: 1},
		EntryStamp: Stamp{Time: time, Index: index, SourceLine: line}}
}

// ----------------------------------------
// ids は、結果の選択順をID列にして照合します。
//
// 引数: values([]Candidate)。返り値: []stringはIDだけの私有スライスです。
func ids(values []Candidate) []string {
	out := make([]string, len(values))
	for i, value := range values {
		out[i] = value.ID
	}
	return out
}

// ----------------------------------------
// TestSelectChronology は、取得順・同原行優先・複数E0・出生非依存を確認します。
//
// 引数: t(*testing.T)。返り値: なし。入力は全て人工です。
func TestSelectChronology(t *testing.T) {
	e0a, e0b := candidate(E0, "e0a", 20, 2, 3), candidate(E0, "e0b", 40, 4, 5)
	l0 := candidate(L0, "l0", 30, 3, 4)
	e1 := candidate(E1, "e1", 10, 1, 2)
	cases := []struct {
		name  string
		input []Candidate
		c0    []string
		s0    []string
	}{
		{"空", nil, []string{}, []string{}},
		{"E0だけ複数保持", []Candidate{e0b, e0a}, []string{"e0a", "e0b"}, []string{"e0a", "e0b"}},
		{"E0先なら補完なし", []Candidate{l0, e0a, candidate(E1, "late", 35, 35, 36)}, []string{"e0a", "l0"}, []string{"e0a"}},
		{"E1先で旧補完を置換し後続E0保持", []Candidate{l0, e0b, e1, e0a}, []string{"e0a", "l0", "e0b"}, []string{"e1", "e0a", "e0b"}},
		{"旧補完先ならE1不採用", []Candidate{candidate(L0, "old", 5, 1, 2), e1, e0a}, []string{"old", "e0a"}, []string{"old", "e0a"}},
		{"E0なしでも補完一つ", []Candidate{l0, e1, candidate(E1, "late", 50, 5, 6)}, []string{"l0"}, []string{"e1"}},
		{"同原行はE0が両補完へ優先", []Candidate{candidate(E1, "new", 20, 2, 3), candidate(L0, "old", 20, 2, 3), e0a}, []string{"e0a", "old"}, []string{"e0a"}},
		{"同原行の旧補完優先はID順と独立", []Candidate{candidate(E1, "a-new", 10, 1, 2), candidate(L0, "z-old", 10, 1, 2)}, []string{"z-old"}, []string{"z-old"}},
		{"同TimeでもIndexが違えば別原行", []Candidate{candidate(L0, "old", 10, 2, 3), e1}, []string{"old"}, []string{"e1"}},
		{"同TimeIndexでもLineが違えば別原行", []Candidate{candidate(L0, "old", 10, 1, 3), e1}, []string{"old"}, []string{"e1"}},
		{"後続同原行のE0も全保持", []Candidate{e1, e0a, candidate(E0, "e0c", 20, 2, 3), l0}, []string{"e0a", "e0c", "l0"}, []string{"e1", "e0a", "e0c"}},
		{"旧対照は全旧補完を保持", []Candidate{candidate(L0, "old-a", 2, 2, 3), candidate(L0, "old-b", 3, 3, 4)}, []string{"old-a", "old-b"}, []string{"old-a"}},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			got, err := Select(tc.input)
			if err != nil {
				t.Fatal(err)
			}
			if !reflect.DeepEqual(ids(got.C0), tc.c0) || !reflect.DeepEqual(ids(got.S0), tc.s0) {
				t.Fatalf("取得選択の相違: C0=%v S0=%v", ids(got.C0), ids(got.S0))
			}
			if got.C0 == nil || got.S0 == nil {
				t.Fatal("空の結果がnil")
			}
		})
	}
	// 出生が早くても取得が遅い旧補完より、取得が早いE1を選びます。
	earlyBirth := l0
	earlyBirth.BirthStamp = Stamp{Time: -1000, Index: 0, SourceLine: 1}
	lateBirth := e1
	lateBirth.BirthStamp = Stamp{Time: 9999, Index: 9999, SourceLine: 9999}
	got, err := Select([]Candidate{earlyBirth, lateBirth})
	if err != nil || !reflect.DeepEqual(ids(got.S0), []string{"e1"}) || got.S0[0].BirthStamp != lateBirth.BirthStamp {
		t.Fatal("出生Stampを選択又は適格性へ混入")
	}
}

// ----------------------------------------
// TestSelectScopesAndCopies は、場/限月の独立と入力/結果の非共有を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestSelectScopesAndCopies(t *testing.T) {
	a := candidate(E0, "same", 1, 1, 2)
	b := candidate(E1, "same", 2, 2, 3)
	b.Contract = "L"
	c := candidate(L0, "same", 3, 3, 4)
	c.Session = "B"
	input := []Candidate{c, b, a}
	before := append([]Candidate{}, input...)
	got, err := Select(input)
	if err != nil || len(got.C0) != 2 || len(got.S0) != 3 {
		t.Fatalf("場/限月の混合: %+v %v", got, err)
	}
	if got.S0[0].Contract != "K" || got.S0[1].Contract != "L" || got.S0[2].Session != "B" {
		t.Fatal("出力の場/限月順が不定")
	}
	if !reflect.DeepEqual(input, before) {
		t.Fatal("入力スライスを並べ替えた")
	}
	got.C0[0].ID = "changed"
	if got.S0[0].ID != "same" || !reflect.DeepEqual(input, before) {
		t.Fatal("C0/S0/入力が配列を共有")
	}
}

// ----------------------------------------
// TestSelectRejectsAmbiguity は、識別子・取得原行・同種同原行の曖昧さを拒否します。
//
// 引数: t(*testing.T)。返り値: なし。取得適格性の金融検査は行いません。
func TestSelectRejectsAmbiguity(t *testing.T) {
	base := candidate(L0, "id", 1, 1, 2)
	mutations := []func(*Candidate){
		func(c *Candidate) { c.Session = " " },
		func(c *Candidate) { c.Contract = "" },
		func(c *Candidate) { c.ID = "\t" },
		func(c *Candidate) { c.Kind = "pending" },
		func(c *Candidate) { c.EntryStamp.Time = math.NaN() },
		func(c *Candidate) { c.EntryStamp.Time = math.Inf(1) },
		func(c *Candidate) { c.EntryStamp.Time = math.Inf(-1) },
		func(c *Candidate) { c.EntryStamp.Index = -1 },
		func(c *Candidate) { c.EntryStamp.SourceLine = 0 },
	}
	for i, mutate := range mutations {
		c := base
		mutate(&c)
		if _, err := Select([]Candidate{c}); err == nil {
			t.Fatalf("形式不正%dを受理", i)
		}
	}
	duplicateID := base
	duplicateID.Kind = E1
	for _, input := range [][]Candidate{{base, base}, {base, duplicateID},
		{base, candidate(L0, "other", 1, 1, 2)},
		{candidate(E1, "a", 1, 1, 2), candidate(E1, "b", 1, 1, 2)}} {
		if _, err := Select(input); err == nil {
			t.Fatal("ID重複又は同原行の同種補完を恣意的に選択")
		}
	}
}

// ----------------------------------------
// onlineRows は、原行単位で到着した人工候補を、その時点の取消し状態だけで処理します。
//
// 引数: candidates([]Candidate)は検査済み。返り値: Resultは独立した行単位の参照実装です。
// 将来のE0の位置を先に検索せず、当行にE0があれば当行の補完も止めます。
func onlineRows(candidates []Candidate) Result {
	rows := map[scope]map[Stamp][]Candidate{}
	for _, c := range candidates {
		key := scope{session: c.Session, contract: c.Contract}
		if rows[key] == nil {
			rows[key] = map[Stamp][]Candidate{}
		}
		rows[key][c.EntryStamp] = append(rows[key][c.EntryStamp], c)
	}
	keys := make([]scope, 0, len(rows))
	for key := range rows {
		keys = append(keys, key)
	}
	sort.Slice(keys, func(i, j int) bool {
		return keys[i].session < keys[j].session || keys[i].session == keys[j].session && keys[i].contract < keys[j].contract
	})
	result := Result{C0: []Candidate{}, S0: []Candidate{}}
	for _, key := range keys {
		stamps := make([]Stamp, 0, len(rows[key]))
		for stamp := range rows[key] {
			stamps = append(stamps, stamp)
		}
		sort.Slice(stamps, func(i, j int) bool {
			a, b := stamps[i], stamps[j]
			return a.Time < b.Time || a.Time == b.Time && (a.Index < b.Index || a.Index == b.Index && a.SourceLine < b.SourceLine)
		})
		stopped := false
		for _, stamp := range stamps {
			row := rows[key][stamp]
			e0s := []Candidate{}
			var old, added *Candidate
			for _, c := range row {
				switch c.Kind {
				case E0:
					e0s = append(e0s, c)
				case L0:
					v := c
					old = &v
				case E1:
					v := c
					added = &v
				}
			}
			sort.Slice(e0s, func(i, j int) bool { return e0s[i].ID < e0s[j].ID })
			result.C0 = append(result.C0, e0s...)
			if old != nil {
				result.C0 = append(result.C0, *old)
			}
			if len(e0s) > 0 {
				result.S0 = append(result.S0, e0s...)
				stopped = true
				continue
			}
			if stopped {
				continue
			}
			chosen := old
			if chosen == nil {
				chosen = added
			}
			if chosen != nil {
				result.S0 = append(result.S0, *chosen)
				stopped = true
			}
		}
	}
	return result
}

// ----------------------------------------
// TestJSONMergeEqualsOnline は、保存JSONの混合順が違っても行単位のオンライン選択と一致することを確認します。
//
// 引数: t(*testing.T)。返り値: なし。200人工系列、各20回の並べ替えを比較します。
func TestJSONMergeEqualsOnline(t *testing.T) {
	rng := rand.New(rand.NewSource(136))
	for series := 0; series < 200; series++ {
		input := []Candidate{}
		for row := 0; row < 25; row++ {
			for _, kind := range []Kind{E0, L0, E1} {
				if rng.Intn(3) == 0 {
					continue
				}
				c := candidate(kind, fmt.Sprintf("%d/%s", row, kind), float64(row/3), int64(row/2), int64(row+1))
				c.Session = fmt.Sprintf("S%d", row%2)
				c.Contract = fmt.Sprintf("K%d", row%3)
				input = append(input, c)
			}
		}
		expected := onlineRows(input)
		for permutation := 0; permutation < 20; permutation++ {
			rng.Shuffle(len(input), func(i, j int) { input[i], input[j] = input[j], input[i] })
			body, err := json.Marshal(input)
			if err != nil {
				t.Fatal(err)
			}
			var merged []Candidate
			if err := json.Unmarshal(body, &merged); err != nil {
				t.Fatal(err)
			}
			got, err := Select(merged)
			if err != nil || !reflect.DeepEqual(got, expected) {
				t.Fatalf("系列%d/並べ替え%dでオンライン処理と不一致: %v", series, permutation, err)
			}
		}
	}
}

// ----------------------------------------
// TestFutureRowsCannotChangeEarlierSelection は、後続取得・出生の変化で過去の選択が変わらないことを確認します。
//
// 引数: t(*testing.T)。返り値: なし。同原行全候補を受け取った後の境界で比較します。
func TestFutureRowsCannotChangeEarlierSelection(t *testing.T) {
	input := []Candidate{
		candidate(E1, "first", 10, 1, 2), candidate(L0, "same-row-old", 10, 1, 2),
		candidate(E0, "e0a", 20, 2, 3), candidate(E1, "late-new", 30, 3, 4),
		candidate(E0, "e0b", 40, 4, 5), candidate(L0, "late-old", 50, 5, 6),
	}
	full, err := Select(input)
	if err != nil {
		t.Fatal(err)
	}
	for _, cutoff := range []float64{10, 20, 30, 40, 50} {
		prefix := []Candidate{}
		for _, c := range input {
			if c.EntryStamp.Time <= cutoff {
				prefix = append(prefix, c)
			}
		}
		got, err := Select(prefix)
		if err != nil {
			t.Fatal(err)
		}
		past := []Candidate{}
		for _, c := range full.S0 {
			if c.EntryStamp.Time <= cutoff {
				past = append(past, c)
			}
		}
		if !reflect.DeepEqual(got.S0, past) {
			t.Fatalf("後続原行が過去%vの選択を変更", cutoff)
		}
	}
	before := ids(full.S0)
	for i := range input {
		input[i].BirthStamp = Stamp{Time: float64(10000 - i), Index: 999, SourceLine: 999}
	}
	after, err := Select(input)
	if err != nil || !reflect.DeepEqual(ids(after.S0), before) {
		t.Fatal("出生情報の変更が取得選択を変更")
	}
	// 公開入力の各フィールドを固定し、価格や将来成績を渡す入口がないことを確認します。
	typeOf := reflect.TypeOf(Candidate{})
	want := []string{"Session", "Contract", "Kind", "ID", "BirthStamp", "EntryStamp"}
	if typeOf.NumField() != len(want) {
		t.Fatal("選択APIへ追加の判断情報を混入")
	}
	for i, name := range want {
		if typeOf.Field(i).Name != name {
			t.Fatal("選択APIの入力フィールドが変更")
		}
	}
}
