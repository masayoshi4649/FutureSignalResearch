module github.com/masayoshi4649/SessionTradeExecuter/e1select

go 1.24.2
