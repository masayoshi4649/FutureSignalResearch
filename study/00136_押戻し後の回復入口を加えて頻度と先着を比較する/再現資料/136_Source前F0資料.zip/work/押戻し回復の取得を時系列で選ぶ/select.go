// Package e1select は、適格性を通過した取得候補の原行順だけで補完を一つ選びます。
package e1select

import (
	"fmt"
	"math"
	"sort"
	"strings"
)

// Kind は、旧L0に含まれるE0/補完と、独立に取得したE1を区別します。
type Kind string

const (
	// E0 は、旧L0の規則で取得した全保持対象です。
	E0 Kind = "E0"
	// L0 は、旧L0の取得済み補完です。
	L0 Kind = "L0"
	// E1 は、独立に注文適格性を通過した取得済みE1です。
	E1 Kind = "E1"
)

// Stamp は、価格時計と同時刻の原行順を表します。
//
// Timeは有限な秒値、Indexは0以上、SourceLineは1以上とします。
// 取得順はTime、Index、SourceLineの辞書順です。全値同体を同原行とします。
type Stamp struct {
	Time       float64 `json:"time"`
	Index      int64   `json:"index"`
	SourceLine int64   `json:"source_line"`
}

// Candidate は、上流で適格性と実取得代用が確定した候補の識別情報です。
//
// BirthStampは出力へ値コピーするだけで、選択・取消し・生存判定には使いません。
// 価格・方向・金融結果・pending・cap/riskの条件は本型へ含めません。
type Candidate struct {
	Session    string `json:"session"`
	Contract   string `json:"contract"`
	Kind       Kind   `json:"kind"`
	ID         string `json:"id"`
	BirthStamp Stamp  `json:"birth_stamp"`
	EntryStamp Stamp  `json:"entry_stamp"`
}

// Result は、同じ入力から得た固定対照C0と時系列選択S0です。
//
// C0は旧E0/L0の全取得、S0は全E0と最初のE0より前の最初の補完1件です。
// 空集合もnilでないスライスを返し、C0/S0と入力は配列を共有しません。
type Result struct {
	C0 []Candidate `json:"C0"`
	S0 []Candidate `json:"S0"`
}

// scope は、同一時系列として処理できる場と限月の組です。
type scope struct {
	session  string
	contract string
}

// identity は、原候補へ結合するIDの有効範囲です。
type identity struct {
	scope scope
	id    string
}

// complementRow は、同種補完の同一取得原行の曖昧さを検査します。
type complementRow struct {
	scope scope
	kind  Kind
	stamp Stamp
}

// ----------------------------------------
// compareStamp は、同時刻でも元の取得原行の順序を保って比較します。
//
// 引数: a/b(Stamp)。返り値: intはaが前なら-1、同原行なら0、後なら1です。
func compareStamp(a, b Stamp) int {
	if a.Time < b.Time {
		return -1
	}
	if a.Time > b.Time {
		return 1
	}
	if a.Index < b.Index {
		return -1
	}
	if a.Index > b.Index {
		return 1
	}
	if a.SourceLine < b.SourceLine {
		return -1
	}
	if a.SourceLine > b.SourceLine {
		return 1
	}
	return 0
}

// ----------------------------------------
// priority は、同原行をE0、旧L0補完、E1の順に処理する優先値を返します。
//
// 引数: kind(Kind)は検査済みの種別。返り値: intは0/1/2です。
func priority(kind Kind) int {
	switch kind {
	case E0:
		return 0
	case L0:
		return 1
	default:
		return 2
	}
}

// ----------------------------------------
// validate は、識別子と取得原行の形式・一意性だけを確認します。
//
// 引数: candidates([]Candidate)。返り値: errorは形式不正又は曖昧な結合です。
// 出生条件やBirthStamp、注文適格性、価格、将来の成績は評価しません。
func validate(candidates []Candidate) error {
	ids := make(map[identity]struct{}, len(candidates))
	rows := make(map[complementRow]struct{}, len(candidates))
	for i, c := range candidates {
		if strings.TrimSpace(c.Session) == "" || strings.TrimSpace(c.Contract) == "" || strings.TrimSpace(c.ID) == "" {
			return fmt.Errorf("候補%d: 場・限月・IDは空にできません", i)
		}
		if c.Kind != E0 && c.Kind != L0 && c.Kind != E1 {
			return fmt.Errorf("候補%d: 種別%qはE0/L0/E1ではありません", i, c.Kind)
		}
		s := c.EntryStamp
		if math.IsNaN(s.Time) || math.IsInf(s.Time, 0) || s.Index < 0 || s.SourceLine < 1 {
			return fmt.Errorf("候補%d: 取得Stampは有限時刻・非負Index・正SourceLineが必要です", i)
		}
		key := scope{session: c.Session, contract: c.Contract}
		id := identity{scope: key, id: c.ID}
		if _, exists := ids[id]; exists {
			return fmt.Errorf("候補%d: 同じ場・限月のID%qが重複しています", i, c.ID)
		}
		ids[id] = struct{}{}
		if c.Kind == E0 {
			continue
		}
		row := complementRow{scope: key, kind: c.Kind, stamp: s}
		if _, exists := rows[row]; exists {
			return fmt.Errorf("候補%d: 同原行・同種%qの補完が複数あり、上流での一意化が必要です", i, c.Kind)
		}
		rows[row] = struct{}{}
	}
	return nil
}

// ----------------------------------------
// Select は、取得候補を原行順に一巡し、金融を参照せず補完を選びます。
//
// 引数: candidates([]Candidate)はE0/旧L0補完/E1の取得済み識別情報です。
// 返り値: ResultはC0/S0、errorは形式又はID/同種補完原行の曖昧さです。
// C0は全E0/L0、S0は全E0と各場・限月で最初のE0より前の補完最初1件です。
// 同原行はE0優先、補完同士はL0優先。後続のE0は全て保持します。
// 入力順・出生順・価格・成果に依存せず、入力スライスを変更しません。
func Select(candidates []Candidate) (Result, error) {
	if err := validate(candidates); err != nil {
		return Result{}, err
	}
	ordered := append([]Candidate{}, candidates...)
	sort.Slice(ordered, func(i, j int) bool {
		a, b := ordered[i], ordered[j]
		if a.Session != b.Session {
			return a.Session < b.Session
		}
		if a.Contract != b.Contract {
			return a.Contract < b.Contract
		}
		if cmp := compareStamp(a.EntryStamp, b.EntryStamp); cmp != 0 {
			return cmp < 0
		}
		if a.Kind != b.Kind {
			return priority(a.Kind) < priority(b.Kind)
		}
		// 同原行のE0は全保持するため、IDはその出力順だけを安定させます。
		return a.ID < b.ID
	})
	result := Result{C0: make([]Candidate, 0, len(ordered)), S0: make([]Candidate, 0, len(ordered))}
	var current scope
	started, e0Seen, complementSelected := false, false, false
	for _, c := range ordered {
		key := scope{session: c.Session, contract: c.Contract}
		if !started || key != current {
			current, started = key, true
			e0Seen, complementSelected = false, false
		}
		if c.Kind != E1 {
			result.C0 = append(result.C0, c)
		}
		if c.Kind == E0 {
			result.S0 = append(result.S0, c)
			e0Seen = true
			continue
		}
		if !e0Seen && !complementSelected {
			result.S0 = append(result.S0, c)
			complementSelected = true
		}
	}
	return result, nil
}
