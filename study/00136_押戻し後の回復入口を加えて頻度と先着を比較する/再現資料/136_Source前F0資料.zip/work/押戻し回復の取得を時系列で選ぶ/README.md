# 取得原行だけで旧補完とE1を選ぶ

金融を使わない接続部品。旧L0の取得済みE0/補完と、独立に注文適格性を通過した取得済みE1の識別候補だけを受け取る。自然Raw・CSV・金融結果・正式試行は読まない。pending、価格、方向、cap/risk、注文適格性の再判定は上流へ分ける。

**第一段階の「最初1補完」固定対照**であり、今後の平均概ね1時間1回を探す頻度研究の選択器ではない。毎時定時・各場の一律回数・新しい上限を追加しない。Root側で全E1イベント/取得候補を保持し、後続の別仮説で利用する。

## 公開API

module `github.com/masayoshi4649/SessionTradeExecuter/e1select`、package `e1select`。外部依存なし、Go1.24.2。

```go
type Kind string
const E0 Kind = "E0"
const L0 Kind = "L0"
const E1 Kind = "E1"

type Stamp struct {
    Time float64
    Index int64
    SourceLine int64
}

type Candidate struct {
    Session string
    Contract string
    Kind Kind
    ID string
    BirthStamp Stamp
    EntryStamp Stamp
}

type Result struct {
    C0 []Candidate
    S0 []Candidate
}

func Select(candidates []Candidate) (Result, error)
```

本体は[select.go](select.go)。元候補本体はRoot側でSession/Contract/IDへ結合する。IDは同じ場・限月の中で一意とし、別の場/限月では再使用できる。出力は値コピーし、入力とC0/S0は配列を共有しない。空入力のC0/S0はnilでない空スライス。

## 選択規則

|出力|保持する取得|
|---|---|
|C0|旧L0の全E0と全L0補完。E1は含めない|
|S0|全E0を保持。旧L0補完/E1の最初の実取得を最大1件、最初のE0より前の場合にだけ採用|

順序は各Session/Contract内の`EntryStamp.Time → Index → SourceLine`。三値が同体なら同原行で、E0→L0→E1の順に処理する。同TimeでもIndex/SourceLineが違えば別原行。E0を先に取得した場は補完0、E1が先なら旧補完を置換、旧補完が先ならE1を採らない。複数あるE0は後続もすべて保持する。

全取得候補を整列後に一巡する。最初のE0又は補完の取得時点で他補完を止め、後のE0だけは保持する。将来のE0位置を事前検索せず、出生Stampや将来の価格・成績は参照しない。オンライン処理も同じ原行の候補を揃えE0/L0/E1優先で処理する。原行の途中でE1だけ先に決定する処理とは区別する。

出力順は場→限月→取得Stamp→種別優先。IDは同原行の複数E0の表示順だけを安定させ、補完の選択には使わない。同種補完L0又はE1が同原行に別IDで複数あれば一意に選べないのでerror。上流での適格性・競合処理を要求し、ID順や入力順で勝手に選ばない。

取得Stampは有限Time・Index≥0・SourceLine≥1が必要。場/限月/ID空、未知Kind、同じ場/限月のID重複もerror。BirthStampは付帯値としてコピーするだけで、出生→取得の整合や生存条件を本部品では検査しない。これらも取得の正規化を行う上流の責務。

## 人工確認

[人工テスト](select_test.go)は5主テスト・12ケースを含む。E0複数、各先着順、同原行優先、同時刻の別Index/Line、場/限月分離、出生順の無関係、非共有コピー、不正/曖昧入力を確認する。

200人工系列×20通りのJSON保存/再読・並べ替えを、別の原行単位オンライン取消し参照処理と比較する。同原行を受領し終わった各境界で、後続原行を追加しても過去の選択が変わらないことも確認する。APIの公開フィールドを固定し、価格・将来成績を渡す欄がないことを検査する。自然データでの取得数・先着率・損益を証明したものではない。

```powershell
go test -count=1 ./...
go vet ./...
python -X utf8 確認する.py
```

[確認票](人工の確認.json)と[Goテストログ](人工のログ.jsonl)に、コードSHA・Go版・人工結果・前後不変を残す。金融前F0/F1や正式採番は作成しない。
