"""e1selectの人工・静的検査を実行し、自然データを使わない停止可能な確認票を残す。"""
from pathlib import Path
import hashlib
import json
import subprocess

OWN = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 人工確認の固定コードの指紋を返す。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: Go人工テストとvetを実行し、前後SHAを確認して新規JSONへ保存する。
    引数: なし。
    返り値: None。自然Raw/CSV/金融ファイルや正式試行へアクセスしない。
    """
    target = OWN/'人工の確認.json'; log = OWN/'人工のログ.jsonl'
    assert not target.exists() and not log.exists()
    names = ('go.mod','select.go','select_test.go','README.md','確認する.py')
    before = {name:sha(OWN/name) for name in names}
    version = subprocess.run(['go','version'],cwd=OWN,capture_output=True,text=True,encoding='utf-8',check=True)
    tests = subprocess.run(['go','test','-count=1','-json','./...'],cwd=OWN,capture_output=True,text=True,encoding='utf-8')
    assert tests.returncode == 0,(tests.stdout,tests.stderr)
    log.write_text(tests.stdout,encoding='utf-8')
    events = [json.loads(line) for line in tests.stdout.splitlines() if line]
    passed = [event['Test'] for event in events if event.get('Action')=='pass' and 'Test' in event]
    main_tests = [name for name in passed if '/' not in name]
    subtests = [name for name in passed if '/' in name]
    assert len(main_tests)==5 and len(subtests)==12
    vet = subprocess.run(['go','vet','./...'],cwd=OWN,capture_output=True,text=True,encoding='utf-8')
    assert vet.returncode == 0,(vet.stdout,vet.stderr)
    after = {name:sha(OWN/name) for name in names}
    assert before==after
    value = {'成功':True,'対象':'金融なし・取得済み候補の時系列選択器',
             'module':'github.com/masayoshi4649/SessionTradeExecuter/e1select','Go版':version.stdout.strip(),
             'API':'Select([]Candidate) (Result,error)、Result.C0/S0 []Candidate',
             'コードSHA256':before,'コード前後不変':True,'主人工テスト':main_tests,'主人工数':5,'ケース数':12,
             'JSON混合の人工系列':200,'各系列の並べ替え':20,'全JSON混合比較':4000,
             '原行単位オンライン取消しと一致':True,'未来原行で過去選択を変更しない':True,
             '出生Stampの変更で取得選択を変更しない':True,'入力と結果の配列を共有しない':True,
             '場/限月を分離':True,'同原行E0優先と旧補完優先':True,'曖昧な同種補完は拒否':True,
             'go_vet成功':True,'GoテストログSHA256':sha(log),'金融結果を入力に含む':False,
             '自然Raw読取':False,'自然CSV読取':False,'自然金融読取':False,'正式試行変更':False,
             '頻度目的の新選択器として扱う':False,'F0_F1と正式採番の作成':False}
    with target.open('x',encoding='utf-8') as handle:
        handle.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'主人工数':5,'ケース数':12,'JSON混合比較':4000,
                      '確認SHA256':sha(target),'自然データ読取':False},ensure_ascii=False))


if __name__=='__main__':
    main()
