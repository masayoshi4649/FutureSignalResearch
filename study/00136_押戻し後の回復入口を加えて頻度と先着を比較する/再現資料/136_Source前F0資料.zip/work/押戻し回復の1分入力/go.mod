module github.com/masayoshi4649/SessionTradeExecuter/e1minute

go 1.24.2

require (
	github.com/masayoshi4649/SessionTradeExecuter/e1episode v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/entryrules118 v0.0.0
)

replace github.com/masayoshi4649/SessionTradeExecuter/e1episode => ../押戻し位相を保存して回復を待つ入口

replace github.com/masayoshi4649/SessionTradeExecuter/entryrules118 => ../118複数技法の入口条件
