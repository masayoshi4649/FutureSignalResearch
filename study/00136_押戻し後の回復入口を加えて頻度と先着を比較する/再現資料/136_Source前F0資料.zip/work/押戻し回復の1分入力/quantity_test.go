package e1minute

import "testing"

// TestQuantityDecoder は129同体のJSON量/時計解釈で未知と0を区別します。
//
// 引数: t(*testing.T)は人工検査状態です。
// 返り値: ありません。
func TestQuantityDecoder(t *testing.T) {
	v, at := Quantity([]byte(`{"TradingVolume":0,"TradingVolumeTime":"1970-01-01T09:00:01.5+09:00"}`))
	if v == nil || *v != 0 || at == nil || *at != 1.5 {
		t.Fatal("既知0/小数時計差")
	}
	for _, raw := range []string{`{`, `{}`, `{"TradingVolume":null,"TradingVolumeTime":"1970-01-01T00:00:01Z"}`, `{"TradingVolume":-1,"TradingVolumeTime":"1970-01-01T00:00:01Z"}`, `{"TradingVolume":"1","TradingVolumeTime":"1970-01-01T00:00:01Z"}`} {
		v, at = Quantity([]byte(raw))
		if v != nil || at != nil {
			t.Fatal("不正量を既知扱い", raw)
		}
	}
	v, at = Quantity([]byte(`{"TradingVolume":12,"TradingVolumeTime":"invalid"}`))
	if v == nil || *v != 12 || at != nil {
		t.Fatal("量既知/時計未知差")
	}
	v, at = Quantity([]byte(`{"TradingVolume":12}`))
	if v != nil || at != nil {
		t.Fatal("欠時計の129挙動差")
	}
}
