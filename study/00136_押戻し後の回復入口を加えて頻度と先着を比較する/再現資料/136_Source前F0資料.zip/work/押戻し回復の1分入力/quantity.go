package e1minute

import (
	"encoding/json"
	"time"
)

// Quantity は129と同じ当Rawの数量/数量時計を解釈します。
//
// 引数: raw([]byte)は原行JSONです。
// 返り値: *float64/*float64は既知量/時計又はnilです。価格時計への先行はObserveで未知にします。
func Quantity(raw []byte) (*float64, *float64) {
	var fields map[string]json.RawMessage
	if json.Unmarshal(raw, &fields) != nil {
		return nil, nil
	}
	var volume *float64
	var text string
	if json.Unmarshal(fields["TradingVolume"], &volume) != nil || volume == nil || !finite(*volume) || *volume < 0 || json.Unmarshal(fields["TradingVolumeTime"], &text) != nil {
		return nil, nil
	}
	t, e := time.Parse(time.RFC3339Nano, text)
	if e != nil {
		return volume, nil
	}
	stamp := float64(t.UnixNano()) / 1e9
	return volume, &stamp
}
