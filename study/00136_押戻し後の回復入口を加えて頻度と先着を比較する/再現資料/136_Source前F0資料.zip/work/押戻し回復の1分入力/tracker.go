// Package e1minute は採用Rawの価格時計から観測1分足と数量proxyだけを形成します。
package e1minute

import (
	"fmt"
	"math"

	episode "github.com/masayoshi4649/SessionTradeExecuter/e1episode"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

type observation struct {
	Quote      episode.Quote
	Volume     *float64
	VolumeTime *float64
}

// Tracker は売買判断を含まない1分形成状態です。場を跨いで再利用しません。
type Tracker struct {
	current      *episode.Bar
	history      []episode.Bar
	last         *observation
	volume       *float64
	volumeTime   *float64
	stats        map[string]int
	pendingReset string
}

// New は空の1分形成状態を返します。
//
// 引数: ありません。
// 返り値: *Trackerは履歴・数量基準を持たない初期状態です。
func New() *Tracker { return &Tracker{stats: map[string]int{}} }

// finite は129と同じ有限数値判定を行います。
//
// 引数: values(...float64)は検査値です。
// 返り値: boolは全て有限ならtrueです。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// sameValue はnilと既知0を区別し、129と同じ値比較を行います。
//
// 引数: a/b(*float64)は比較対象です。
// 返り値: boolは両方未知又は等しい既知値ならtrueです。
func sameValue(a, b *float64) bool { return a == nil && b == nil || a != nil && b != nil && *a == *b }

// cloneObservation は呼び出し元の数量ポインタから状態を分離します。
//
// 引数: o(observation)は採用行です。
// 返り値: observationは数量値を個別に複製した行です。
func cloneObservation(o observation) observation {
	if o.Volume != nil {
		v := *o.Volume
		o.Volume = &v
	}
	if o.VolumeTime != nil {
		v := *o.VolumeTime
		o.VolumeTime = &v
	}
	return o
}

// rq は価格時計と物理順だけを129と同じ価格足のQuoteへ写します。
//
// 引数: q(episode.Quote)は採用行です。
// 返り値: rules.Quoteは1分の最初/最後の観測です。
func rq(q episode.Quote) rules.Quote {
	return rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last}
}

// makeBar は129 minute_reuseの同じUTC floor60秒で価格足を初期化します。
//
// 引数: q(rules.Quote)は最初の採用価格です。
// 返り値: *episode.Barは[Start,End)の形成中足です。
func makeBar(q rules.Quote) *episode.Bar {
	start := math.Floor(q.Time/60) * 60
	return &episode.Bar{Start: start, End: start + 60, OHLC: rules.OHLC{Open: q.Last, High: q.Last, Low: q.Last, Close: q.Last}, Rows: 1, First: q, Last: q}
}

// updateBar は129と同じ価格OHLCを現在足内だけで更新します。
//
// 引数: b(*episode.Bar)、q(rules.Quote)は形成中足と現在価格です。
// 返り値: ありません。足はまだ確定しません。
func updateBar(b *episode.Bar, q rules.Quote) {
	b.OHLC.High = math.Max(b.OHLC.High, q.Last)
	b.OHLC.Low = math.Min(b.OHLC.Low, q.Last)
	b.OHLC.Close = q.Last
	b.Rows++
	b.Last = q
}

// clearShort は129と同じ短期履歴と数量基準のresetを行います。
//
// 引数: reason(string)は診断区分です。
// 返り値: ありません。現在足の扱いは呼び出し側が決めます。
func (t *Tracker) clearShort(reason string) {
	t.history = nil
	t.volume = nil
	t.volumeTime = nil
	t.stats[reason]++
}

// RejectClock は採用されなかった時計を現在足の未知と短期履歴resetへ反映します。
//
// 引数: reason(string)は呼び出し側の時計拒否理由です。
// 返り値: ありません。次の新しい採用行でもresetReasonを通知します。
func (t *Tracker) RejectClock(reason string) {
	if t.current != nil {
		t.current.PriceKnown = false
		t.current.VolumeKnown = false
	}
	reason = "時計拒否/" + reason
	t.clearShort(reason)
	t.pendingReset = reason
}

// addQuantity は129と同じ当Raw累積量の差分を現在区間へ割り当てます。
//
// 引数: o(observation)は価格行と数量/数量時計です。
// 返り値: ありません。基準不足・減少・先行時計等はその足の量を未知にします。
func (t *Tracker) addQuantity(o observation) {
	b := t.current
	q := o.Quote
	if o.Volume == nil || o.VolumeTime == nil || !finite(*o.Volume, *o.VolumeTime) || *o.Volume < 0 || *o.VolumeTime > q.Time {
		b.VolumeKnown = false
		t.volume = nil
		t.volumeTime = nil
		t.stats["数量未知"]++
		return
	}
	if t.volume == nil || *o.Volume < *t.volume || *o.VolumeTime < *t.volumeTime {
		b.VolumeKnown = false
		t.stats["数量基準reset"]++
	} else {
		sum := b.Volume + *o.Volume - *t.volume
		if !finite(sum) {
			b.VolumeKnown = false
			t.volume = nil
			t.volumeTime = nil
			t.stats["数量非有限"]++
			return
		}
		b.Volume = sum
	}
	v, at := *o.Volume, *o.VolumeTime
	t.volume = &v
	t.volumeTime = &at
}

// startMinute は価格形成を既知性フラグと当Raw数量差分で包みます。
//
// 引数: o(observation)は最初の採用行です。
// 返り値: ありません。空足の補間やEOF確定はしません。
func (t *Tracker) startMinute(o observation) {
	t.current = makeBar(rq(o.Quote))
	t.current.PriceKnown = true
	t.current.VolumeKnown = true
	t.addQuantity(o)
}

// Stats は内部を改変できない診断件数の写しを返します。
//
// 引数: ありません。
// 返り値: map[string]intは採用・閉鎖・品質reset等の累計です。
func (t *Tracker) Stats() map[string]int {
	out := make(map[string]int, len(t.stats))
	for k, v := range t.stats {
		out[k] = v
	}
	return out
}

// Observe は次の分の最初の採用行だけで直前の観測1分を確定します。
//
// 引数: q(episode.Quote)、volume/volumeTime(*float64)は採用行と当Raw累積量/数量時計です。
// 返り値: closed(*episode.Bar)は正常閉鎖だけ、previous([]episode.Bar)はclosedを含まない直前最大6本、
// resetReason(string)は短期未知の理由、err(error)は入力/同原行改変/逆順拒否です。
func (t *Tracker) Observe(q episode.Quote, volume, volumeTime *float64) (closed *episode.Bar, previous []episode.Bar, resetReason string, err error) {
	if !finite(q.Time, q.Last) || q.Last <= 0 || q.Index < 0 || q.SourceLine < 1 {
		return nil, nil, "", fmt.Errorf("採用Raw値不正")
	}
	o := observation{Quote: q, Volume: volume, VolumeTime: volumeTime}
	if t.last != nil {
		last := t.last.Quote
		if q.Index == last.Index {
			if q != last || !sameValue(volume, t.last.Volume) || !sameValue(volumeTime, t.last.VolumeTime) {
				return nil, nil, "", fmt.Errorf("同原行改変")
			}
			return nil, nil, "", nil
		}
		if q.Index <= last.Index || q.SourceLine <= last.SourceLine || q.Time < last.Time {
			return nil, nil, "", fmt.Errorf("原行順逆転")
		}
	}
	t.stats["採用Raw"]++
	resetReason = t.pendingReset
	t.pendingReset = ""
	// ----------------------------------------
	// gap時は現在足を閉じずに破棄し、当行から数量基準も再開します。
	if t.last != nil && q.Time-t.last.Quote.Time > 60 {
		t.current = nil
		t.clearShort("価格時計gap60超")
		if resetReason != "" {
			resetReason += ";"
		}
		resetReason += "価格時計gap60超"
	}
	currentStart := math.Floor(q.Time/60) * 60
	if t.current == nil {
		t.startMinute(o)
	} else if currentStart == t.current.Start {
		updateBar(t.current, rq(q))
		t.addQuantity(o)
	} else {
		b := *t.current
		t.stats["閉鎖1分"]++
		if currentStart != b.End || q.Time-b.End > 30 || !b.PriceKnown {
			reason := "閉鎖1分未知"
			t.clearShort(reason)
			if resetReason != "" {
				resetReason += ";"
			}
			resetReason += reason
		} else {
			previous = append([]episode.Bar(nil), t.history...)
			if len(t.history) > 0 {
				last := t.history[len(t.history)-1]
				b.TR = rules.Value{Known: true, Value: math.Max(b.OHLC.High-b.OHLC.Low, math.Max(math.Abs(b.OHLC.High-last.OHLC.Close), math.Abs(b.OHLC.Low-last.OHLC.Close)))}
			}
			t.stats["既知閉鎖1分"]++
			closed = &b
			t.history = append(t.history, b)
			if len(t.history) > 6 {
				t.history = t.history[len(t.history)-6:]
			}
		}
		t.startMinute(o)
	}
	saved := cloneObservation(o)
	t.last = &saved
	return closed, previous, resetReason, nil
}
