# E1用の観測1分入力

自然Raw/CSV・出生・金融結果を読まずに作成した純形成部品。売買方向・テクニカル背景・パターン・注文・場1回の上限を持たず、全採用Rawを継続して処理する。新しい場ではNewを呼ぶ。E1条件部品・Source133・129・正式資料は変更していない。

moduleは `github.com/masayoshi4649/SessionTradeExecuter/e1minute`、packageは `e1minute`。同階層のe1episodeとentryrules118をgo.modで参照する。

```go
tracker := e1minute.New()
volume, volumeTime := e1minute.Quantity(row)
closed, previous, resetReason, err := tracker.Observe(q, volume, volumeTime)
```

Observeのqは採用行の `e1episode.Quote`、量・量時計は `*float64`。closedは次の分の最初の採用行で正常閉鎖した `*e1episode.Bar` だけ、previousは今回closedを含まない直前の連続確定履歴（最大6本）のcopy。閉鎖しない行では両方nil。resetReasonが非空なら呼び出し側は短期episodeも取消す。errは入力・同原行改変・順序異常で、呼び出し側が停止して扱う。同一内容の同原行再提示は何も生成しない。

形成の定義は129のminute.go/minute_reuse.goを再利用した。価格時計をUTCの60秒床で区切り、[Start,End)の当時RawだけからOHLCと最初/最後の価格観測を保存する。後続分のRaw価格を閉じる旧足へ入れず、空足を補間せず、EOFでは閉じない。TRは連続確定履歴があるときだけ直前終値を含み、最初の足は未知。gap>60秒は形成中足を破棄して履歴/数量基準をreset、欠分・閉鎖遅れ>30秒・価格未知の閉鎖は返さずresetする。60秒gap・30秒遅れの等号は旧定義同様に許す。

Quantityの関数本文は129 scanner.goのquantityを公開名だけ変更して転記した。TradingVolumeの差分を現在Rawの区間へ配分し、真の取引所1分出来高とは呼ばない。初回基準不足・累積減少・数量時計後退・量/量時計の欠落/非有限・負量・価格時計より先行した数量時計は、その足の量を未知にする。既知差分0と未知を区別する。価格時計基準のため、数量発生時刻と受信時刻の完全な復元ではない。

RejectClock(reason string)は現在足の価格/量を未知へ落とし、履歴/数量基準を消す。次の新しい採用行のresetReasonにも通知し、未知足の閉鎖を正常足として返さない。拒否前の最後の採用時計/物理順は保持する。BBO不良だけで採用価格を捨てない。短期gapの優先判定は129同様にRaw時刻差であり、空分も通常は先にgap>60へ分類される。

Statsは内部mapのcopy。closed・previousも内部履歴から分離して返し、呼び出し元の量ポインタを内部へ共有しない。初回/異常後の観測開始足は、129と同じ「当該足で観測された価格」の足であり、分全体の全約定を復元したという意味のPriceKnownではない。

当フォルダで `go test -count=1 -v ./...`、`go vet ./...`、`go build ./...` を実行する。12主人工で因果閉鎖・最大6本/copy・60秒等号/61秒超・隣接分87秒/欠分・30秒等号/31秒遅閉鎖・時計拒否・同原行改変/逆順・未知と0・量異常8区分・価格鏡像・価格異常/BBO分離・量JSONを確認する。実データの足パリティや出生率・勝率・約定は未検証。依存するe1episodeの最終固定は別の作者証跡とRootの版固定で確認する。
