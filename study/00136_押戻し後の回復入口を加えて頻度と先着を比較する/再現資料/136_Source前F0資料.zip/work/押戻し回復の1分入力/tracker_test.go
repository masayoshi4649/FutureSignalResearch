package e1minute

import (
	"math"
	"reflect"
	"testing"

	episode "github.com/masayoshi4649/SessionTradeExecuter/e1episode"
)

// pointer は人工検査の既知値を作ります。
//
// 引数: value(float64)は検査値です。
// 返り値: *float64は独立した値のポインタです。
func pointer(value float64) *float64 { return &value }

// quote は自然データを使わず単調な物理順の価格行を作ります。
//
// 引数: at/price(float64)、index(int64)は価格時計・価格・採用順です。
// 返り値: episode.Quoteは人工行です。
func quote(at, price float64, index int64) episode.Quote {
	return episode.Quote{Time: at, Last: price, Index: index, SourceLine: index + 1, Bid: price - 5, Ask: price + 5, QuoteOK: true}
}

// observe は人工の既知数量を渡し、予期しない入力エラーを停止します。
//
// 引数: t(*testing.T)、tr(*Tracker)、at/price/volume(float64)、index(int64)は検査と入力です。
// 返り値: *episode.Bar/[]episode.Bar/stringは閉鎖足・直前履歴・reset理由です。
func observe(t *testing.T, tr *Tracker, at, price, volume float64, index int64) (*episode.Bar, []episode.Bar, string) {
	t.Helper()
	b, p, r, e := tr.Observe(quote(at, price, index), pointer(volume), pointer(at))
	if e != nil {
		t.Fatal(e)
	}
	return b, p, r
}

// TestCausalClosure は後続分の現在価格を旧足OHLCへ混入しないことを検査します。
//
// 引数: t(*testing.T)は検査状態です。
// 返り値: ありません。不一致は検査失敗です。
func TestCausalClosure(t *testing.T) {
	tr := New()
	if b, _, _ := observe(t, tr, 0, 100, 0, 0); b != nil {
		t.Fatal("初回で閉鎖")
	}
	if b, _, _ := observe(t, tr, 59, 110, 10, 1); b != nil {
		t.Fatal("同一分で閉鎖")
	}
	b, p, r := observe(t, tr, 60, 90, 15, 2)
	if b == nil || len(p) != 0 || r != "" || b.Start != 0 || b.End != 60 || b.Rows != 2 || b.OHLC.Open != 100 || b.OHLC.High != 110 || b.OHLC.Low != 100 || b.OHLC.Close != 110 || b.First.Time != 0 || b.Last.Time != 59 || b.TR.Known || b.VolumeKnown {
		t.Fatalf("旧足の因果差: %+v", b)
	}
	observe(t, tr, 119, 95, 20, 3)
	b, p, r = observe(t, tr, 120, 105, 22, 4)
	if b == nil || len(p) != 1 || p[0].End != b.Start || b.OHLC.Close != 95 || b.OHLC.High != 95 || b.OHLC.Low != 90 || !b.TR.Known || b.TR.Value != 20 || !b.VolumeKnown || b.Volume != 10 || r != "" {
		t.Fatalf("次足/前終値TR/量差: %+v %+v", b, p)
	}
	if tr.Stats()["閉鎖1分"] != 2 {
		t.Fatal("EOF相当で形成中足を閉じた")
	}
}

// TestHistoryCopies は最大6本と返却値・診断値の独立copyを検査します。
//
// 引数: t(*testing.T)は検査状態です。
// 返り値: ありません。
func TestHistoryCopies(t *testing.T) {
	tr := New()
	var last *episode.Bar
	var prior []episode.Bar
	for i := 0; i <= 16; i++ {
		b, p, _ := observe(t, tr, float64(i*30), 100+float64(i), float64(i), int64(i))
		if b != nil {
			last = b
			prior = p
		}
	}
	if len(prior) != 6 || len(tr.history) != 6 || last.End != 480 || prior[5].End != last.Start {
		t.Fatal("6本/今回除外差")
	}
	closePrice := tr.history[5].OHLC.Close
	last.OHLC.Close = -1
	prior[5].OHLC.Close = -2
	out := tr.Stats()
	out["採用Raw"] = -3
	if tr.history[5].OHLC.Close != closePrice || tr.history[4].OHLC.Close < 0 || tr.Stats()["採用Raw"] != 17 {
		t.Fatal("外部改変が状態へ伝播")
	}
}

// TestGapBoundary は60秒等号の採用と60秒超の全短期resetを検査します。
//
// 引数: t(*testing.T)は検査状態です。
// 返り値: ありません。
func TestGapBoundary(t *testing.T) {
	tr := New()
	observe(t, tr, 0, 100, 0, 0)
	b, _, r := observe(t, tr, 60, 101, 1, 1)
	if b == nil || r != "" {
		t.Fatal("60秒等号を誤拒否")
	}
	b, p, r := observe(t, tr, 121, 102, 2, 2)
	if b != nil || len(p) != 0 || r != "価格時計gap60超" || len(tr.history) != 0 || tr.current.VolumeKnown {
		t.Fatal("61秒gap差")
	}
	b, p, r = observe(t, tr, 180, 103, 3, 3)
	if b == nil || len(p) != 0 || r != "" || b.TR.Known || b.VolumeKnown {
		t.Fatal("gap後へ前史混入")
	}
}

// TestAdjacentMinuteGapAndMissing は隣接分でも87秒空白と空分をresetすることを検査します。
//
// 引数: t(*testing.T)は検査状態です。
// 返り値: ありません。
func TestAdjacentMinuteGapAndMissing(t *testing.T) {
	for _, at := range []float64{89, 180} {
		tr := New()
		observe(t, tr, 2, 100, 0, 0)
		b, p, r := observe(t, tr, at, 110, 2, 1)
		if b != nil || len(p) != 0 || r != "価格時計gap60超" || tr.current.Start != math.Floor(at/60)*60 {
			t.Fatal("gap/空分を補間")
		}
	}
}

// TestClosureLateness は閉鎖遅れ30秒等号を許し31秒を未知とすることを検査します。
//
// 引数: t(*testing.T)は検査状態です。
// 返り値: ありません。
func TestClosureLateness(t *testing.T) {
	for _, delay := range []float64{30, 31} {
		tr := New()
		observe(t, tr, 0, 100, 0, 0)
		observe(t, tr, 59, 101, 1, 1)
		b, p, r := observe(t, tr, 60+delay, 102, 2, 2)
		if delay == 30 {
			if b == nil || r != "" {
				t.Fatal("30秒等号を誤拒否")
			}
		} else if b != nil || len(p) != 0 || r != "閉鎖1分未知" || len(tr.history) != 0 || tr.current.VolumeKnown {
			t.Fatal("31秒遅れが既知")
		}
	}
}

// TestRejectedClock は破棄時計後の現在足未知と履歴/数量基準resetを検査します。
//
// 引数: t(*testing.T)は検査状態です。
// 返り値: ありません。
func TestRejectedClock(t *testing.T) {
	tr := New()
	observe(t, tr, 0, 100, 0, 0)
	observe(t, tr, 60, 101, 1, 1)
	observe(t, tr, 90, 102, 2, 2)
	tr.RejectClock("後退")
	if len(tr.history) != 0 || tr.current.PriceKnown || tr.volume != nil {
		t.Fatal("時計拒否reset差")
	}
	b, _, r := observe(t, tr, 119, 103, 3, 3)
	if b != nil || r != "時計拒否/後退" {
		t.Fatal("拒否通知差")
	}
	b, p, r := observe(t, tr, 120, 104, 4, 4)
	if b != nil || len(p) != 0 || r != "閉鎖1分未知" {
		t.Fatal("時計拒否足が閉鎖既知")
	}
	observe(t, tr, 179, 105, 5, 5)
	b, p, r = observe(t, tr, 180, 106, 6, 6)
	if b == nil || len(p) != 0 || r != "" || b.TR.Known || b.VolumeKnown {
		t.Fatal("拒否後へ旧履歴/量混入")
	}
}

// TestSameRowAndOrder は同原行改変・逆順・入力ポインタaliasを検査します。
//
// 引数: t(*testing.T)は検査状態です。
// 返り値: ありません。
func TestSameRowAndOrder(t *testing.T) {
	tr := New()
	q := quote(10, 100, 1)
	v, at := pointer(0), pointer(10)
	if _, _, _, e := tr.Observe(q, v, at); e != nil {
		t.Fatal(e)
	}
	*v = 99
	*at = 99
	before := tr.Stats()
	if _, _, _, e := tr.Observe(q, pointer(0), pointer(10)); e != nil {
		t.Fatal("入力alias", e)
	}
	changed := q
	changed.Last++
	for _, o := range []observation{{Quote: changed, Volume: pointer(0), VolumeTime: pointer(10)}, {Quote: q, Volume: nil, VolumeTime: pointer(10)},
		{Quote: quote(9, 100, 2), Volume: pointer(0), VolumeTime: pointer(9)}, {Quote: quote(11, 100, 0), Volume: pointer(0), VolumeTime: pointer(11)}} {
		if _, _, _, e := tr.Observe(o.Quote, o.Volume, o.VolumeTime); e == nil {
			t.Fatal("改変/逆順を誤採用")
		}
	}
	if !reflect.DeepEqual(before, tr.Stats()) {
		t.Fatal("拒否入力で状態変更")
	}
}

// TestKnownZeroVolume は初回未知と既知差分0を区別することを検査します。
//
// 引数: t(*testing.T)は検査状態です。
// 返り値: ありません。
func TestKnownZeroVolume(t *testing.T) {
	tr := New()
	observe(t, tr, 0, 100, 20, 0)
	observe(t, tr, 30, 101, 20, 1)
	b, _, _ := observe(t, tr, 60, 102, 20, 2)
	if b.VolumeKnown || b.Volume != 0 {
		t.Fatal("初回量を既知0へ変換")
	}
	observe(t, tr, 90, 103, 20, 3)
	b, _, _ = observe(t, tr, 120, 104, 20, 4)
	if !b.VolumeKnown || b.Volume != 0 {
		t.Fatal("既知差分0を未知扱い")
	}
}

// TestUnknownQuantityCases は減少・後退・先行・nil・非有限が当該足を未知にすることを検査します。
//
// 引数: t(*testing.T)は検査状態です。
// 返り値: ありません。
func TestUnknownQuantityCases(t *testing.T) {
	cases := []struct {
		name  string
		v, at *float64
	}{{"減少", pointer(1), pointer(90)}, {"時計後退", pointer(30), pointer(50)},
		{"時計先行", pointer(30), pointer(91)}, {"量なし", nil, pointer(90)}, {"時計なし", pointer(30), nil},
		{"負量", pointer(-1), pointer(90)}, {"非有限", pointer(math.NaN()), pointer(90)}, {"時計非有限", pointer(30), pointer(math.Inf(1))}}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			tr := New()
			observe(t, tr, 0, 100, 10, 0)
			observe(t, tr, 30, 101, 20, 1)
			observe(t, tr, 60, 102, 25, 2)
			if _, _, _, e := tr.Observe(quote(90, 103, 3), c.v, c.at); e != nil {
				t.Fatal(e)
			}
			b, _, _ := observe(t, tr, 120, 104, 40, 4)
			if b == nil || b.VolumeKnown {
				t.Fatal("未知量が既知")
			}
		})
	}
}

// TestMirror は価格を3000−価格へ写しても時間・量・TRが対称であることを検査します。
//
// 引数: t(*testing.T)は検査状態です。
// 返り値: ありません。
func TestMirror(t *testing.T) {
	a, b := New(), New()
	prices := []float64{1000, 1020, 990, 1010, 1030}
	for i, at := range []float64{0, 30, 59, 60, 120} {
		x, xp, xr := observe(t, a, at, prices[i], float64(i), int64(i))
		y, yp, yr := observe(t, b, at, 3000-prices[i], float64(i), int64(i))
		if (x == nil) != (y == nil) || len(xp) != len(yp) || xr != yr {
			t.Fatal("鏡像時計差")
		}
		if x == nil {
			continue
		}
		if y.OHLC.Open != 3000-x.OHLC.Open || y.OHLC.High != 3000-x.OHLC.Low || y.OHLC.Low != 3000-x.OHLC.High || y.OHLC.Close != 3000-x.OHLC.Close || y.TR != x.TR || y.VolumeKnown != x.VolumeKnown || y.Volume != x.Volume {
			t.Fatal("価格/量鏡像差")
		}
	}
}

// TestPriceValidationAndBadBBO は価格異常を拒否しBBO不良だけで価格足を捨てないことを検査します。
//
// 引数: t(*testing.T)は検査状態です。
// 返り値: ありません。
func TestPriceValidationAndBadBBO(t *testing.T) {
	for _, price := range []float64{0, -1, math.NaN(), math.Inf(1)} {
		if _, _, _, e := New().Observe(quote(0, price, 0), nil, nil); e == nil {
			t.Fatal("不正価格を採用")
		}
	}
	tr := New()
	q := quote(0, 100, 0)
	q.Bid = 0
	q.Ask = 0
	q.QuoteOK = false
	if _, _, _, e := tr.Observe(q, nil, nil); e != nil {
		t.Fatal("価格足をBBOで除外", e)
	}
	if b, _, _ := observe(t, tr, 60, 101, 1, 1); b == nil || !b.PriceKnown {
		t.Fatal("BBO不良と価格未知を混同")
	}
}
