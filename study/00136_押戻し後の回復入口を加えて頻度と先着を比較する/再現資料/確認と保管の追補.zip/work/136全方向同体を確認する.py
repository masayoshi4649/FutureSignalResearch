"""E1が出生しなかった136を、金融を重複計算せず非金融の全方向同体で確認する。"""
from pathlib import Path
from collections import Counter
import hashlib
import json

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT/'work/136押戻し回復の評価'


def main() -> None:
    """
    機能: C0/S0/A0の全取得・方向同体と、全時間の頻度を保存する。
    引数: なし。
    返り値: None。金融結果の再計算、新Raw、新足生成を行わない。
    """
    source_path = OWN/'Sourceの出生と取得.json'
    source_sha = hashlib.sha256(source_path.read_bytes()).hexdigest()
    data = json.loads(source_path.read_bytes())
    checked = json.loads((OWN/'Source非金融の確認.json').read_bytes())
    assert checked['成功'] and checked['Source_SHA256'] == source_sha
    rows = []
    stages = Counter()
    reasons = Counter()
    for s in data['scenes']:
        assert s['success'] and not s['e1_events'] and not s['e1_candidates']
        refs = s['selection']['C0']
        assert refs == s['selection']['S0'] == s['frequency_A0']
        legacy = s['legacy']
        mapping = {c['birth']['id']:c for c in legacy['candidates'] if c['policy']=='L0' and c['entry'] is not None}
        assert len(refs) == len(mapping) and refs
        for r in refs:
            c = mapping[r['id']]
            assert r['kind'] in ('E0','L0')
            assert c['direction']['selected_side'] in (-1,1)
            rows.append({'session':s['session'],'id':r['id'],'entry':c['entry'],
                         'source_side':c['birth']['side'],'selected_side':c['direction']['selected_side']})
        for trace in s['lifecycle']:
            stages[trace['stage']] += 1
            reasons[trace['reason']] += 1
    # ----------------------------------------
    # 全場の開始/終了時計は既存の小型共用metadataから取得する。
    import gzip
    metadata_bytes = gzip.decompress((ROOT/'inputs/00124_同入口正逆の共用入力/入力.json.gz').read_bytes())
    assert hashlib.sha256(metadata_bytes).hexdigest() == 'b2368b1f42c16e8c96a3acd098c58a902807a3b6a5023d6d4b1e75261f3ee51b'
    metadata = json.loads(metadata_bytes)
    assert [s['session'] for s in metadata['scenes']] == [s['session'] for s in data['scenes']]
    total_seconds = sum(s['end']-300-s['start'] for s in metadata['scenes'])
    counts = Counter(r['session'] for r in rows)
    assert len(rows) == 79 and len(counts) == 73 and min(counts.values()) == 1
    old_path = ROOT/'work/126複合切替の探索/集計.json'
    assert hashlib.sha256(old_path.read_bytes()).hexdigest() == 'e30aca19e553ded53ccdd3b1785bd6168e19dd210aa9c32c1f9625c0063fdcd8'
    result = {'成功':True,'試行':136,'Source_SHA256':source_sha,'主A0':True,
              'C0_S0_A0全取得参照と方向同体':True,'取得数':len(rows),'場数':len(counts),'最少取得':min(counts.values()),
              '取得と方向の正規化票SHA256':hashlib.sha256(json.dumps(rows,sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest(),
              '場別取得数の分布':dict(Counter(counts.values())),'全ザラバ秒':total_seconds,
              '全ザラバ時間':total_seconds/3600,'全時間平均取得回数毎時':len(rows)/(total_seconds/3600),
              '新E1出生':0,'新E1取得':0,'新しい入口なし':True,'状態段階件数':dict(stages),'理由件数':dict(reasons),
              '新金融F1':False,'新金融再計算':False,'新CSV生成':False,
              '既報の固定対照':'旧126 T8/旧135 C0の費用・時計・取得方向を同体により継承。今回新しい成績を生成した値ではない',
              '旧集計参照':{'path':'work/126複合切替の探索/集計.json','sha256':'e30aca19e553ded53ccdd3b1785bd6168e19dd210aa9c32c1f9625c0063fdcd8'},
              '限界':'Source非金融同体の証明。先着率/頻度の改善を意味しない。原因内訳は別診断。'}
    assert hashlib.sha256(source_path.read_bytes()).hexdigest() == source_sha
    output = OWN/'全方向同体の確認.json'
    with output.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'proof_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
                      '取得':len(rows),'場':len(counts),'平均回数毎時':result['全時間平均取得回数毎時']},ensure_ascii=False))


if __name__ == '__main__':
    main()
