"""136の保存済みlifecycle/statsだけで時計と位置条件の失敗を診断する。"""
from pathlib import Path
from collections import Counter
from datetime import datetime, timezone, timedelta
import hashlib
import json
import math

OWN = Path(__file__).resolve().parent
ROOT = OWN.parent.parent
SOURCE = ROOT / 'work/136押戻し回復の評価/Sourceの出生と取得.json'
EXPECTED = 'f777aa32ab145bf5b9ba570b06244ec071fb40356eff67efce55137ba197b6c2'


# ----------------------------------------
def earliest(delivery: float, expiry: float) -> dict:
    """
    機能: 配送後の完全な別1分と最低1秒保持の最速時計を求める。
    引数: delivery/expiry(float)。返り値: dict。実際の信号成立や約定を仮定しない。
    """
    start = math.floor(delivery / 60) * 60 + 60
    end = start + 60
    birth = end + 1
    return {'配送の分内秒': delivery % 60, '理論最早cStart': start, '理論最早cEnd': end,
            '理論最早保持完了': birth, 'strict期限': expiry, '理論上の余地秒': expiry - birth,
            '時計だけなら成立可能': birth < expiry}


# ----------------------------------------
def geometry(side: int, last: float, frozen: dict) -> dict:
    """
    機能: 保存した接触ATRとK/I/capによる当時Lastの位置だけを評価する。
    引数: side(int)、last(float)、frozen(dict)。返り値: dict。実BBOや利益を計算しない。
    """
    k = side * (last - frozen['K']); cap = side * (last - frozen['cap'])
    risk = side * (last - frozen['I']); maximum = min(125, 1.5 * frozen['atr'])
    return {'Last': last, 'Kから順側pt': k, 'cap超過pt': cap, 'risk_pt': risk, 'risk上限pt': maximum,
            'K側': k >= 0, 'cap内': cap <= 0, 'risk内': 10 <= risk <= maximum,
            '3条件すべて': k >= 0 and cap <= 0 and 10 <= risk <= maximum}


# ----------------------------------------
def jst(at: float) -> str:
    """機能: 価格時計をJST表示する。引数: at(float)。返り値: str。"""
    return datetime.fromtimestamp(at, timezone(timedelta(hours=9))).isoformat()


# ----------------------------------------
def main() -> None:
    """
    機能: 保存されたE1 lifecycle/statsだけを投影し全34改善/26期限/3回復を記録する。
    引数: なし。返り値: None。原板・CSV・金融・旧取得列を参照しない。
    """
    assert earliest(1260, 1380)['時計だけなら成立可能'] is False
    assert earliest(1261, 1381)['時計だけなら成立可能'] is False
    assert earliest(1265, 1385)['理論上の余地秒'] == 4
    assert earliest(1267, 1302)['時計だけなら成立可能'] is False
    a = geometry(1, 109, {'K': 109, 'I': 94, 'cap': 119, 'atr': 40})
    b = geometry(-1, 91, {'K': 91, 'I': 106, 'cap': 81, 'atr': 40})
    assert all(a[k] == b[k] for k in ('Kから順側pt', 'cap超過pt', 'risk_pt', 'risk上限pt', '3条件すべて'))
    data = SOURCE.read_bytes(); assert hashlib.sha256(data).hexdigest() == EXPECTED
    document = json.loads(data)
    scenes = [{'session': s['session'], 'stats': s['e1_stats'], 'lifecycle': s['lifecycle']} for s in document['scenes']]
    assert len(scenes) == 73
    del document
    episodes = {}; stages = Counter(); reasons = Counter(); scene_stats = {}; observed_recoveries = Counter()
    for s in scenes:
        scene_stats[s['session']] = s['stats']
        for row in s['lifecycle']:
            stages[row['stage']] += 1; reasons[row['stage'] + '/' + row['reason']] += 1
            episodes.setdefault(row['episode_id'], []).append(row)
            observed_recoveries[s['session']] += row['stage'] == '1分回復'
    assert [stages[k] for k in ('接触', 'K固定', '5分改善', '1分回復', '出生')] == [257, 145, 34, 3, 0]
    improvements = []; recoveries = []; phases = Counter(); timeout_phases = Counter(); count = Counter(); m_geometry = Counter()
    for identity, traces in episodes.items():
        ms = [t for t in traces if t['stage'] == '5分改善']
        if not ms:
            continue
        assert len(ms) == 1
        m = ms[0]; end = next(t for t in traces if t['stage'] == '取消')
        k = next(t for t in traces if t['stage'] == 'K固定')
        d = m['fields']['improvement']['delivered']['time']; expiry = m['fields']['recovery_expires']
        timing = earliest(d, expiry); phase = timing['配送の分内秒']; phases[str(phase)] += 1
        timeout = end['reason'] == '新5分配送120秒期限'
        possible = timing['時計だけなら成立可能']; count['全34/可能' if possible else '全34/不可能'] += 1
        if timeout:
            timeout_phases[str(phase)] += 1; count['120期限26/可能' if possible else '120期限26/不可能'] += 1
        g = geometry(m['side'], m['at']['last'], k['fields'])
        for name in ('K側', 'cap内', 'risk内', '3条件すべて'):
            m_geometry[name] += g[name]
        m_geometry['時計可能かつ3条件すべて'] += possible and g['3条件すべて']
        candidates = []
        for t in traces:
            if t['stage'] not in ('回復1分待ち', '1分回復') or t['at']['time'] < d:
                continue
            at = t['at']['time']; c_end = math.floor(at / 60) * 60; c_start = c_end - 60
            candidates.append({'確認Raw': at, '確認JST': jst(at), '記録段階': t['stage'],
                'Tracker定義からのcStart': c_start, 'Tracker定義からのcEnd': c_end,
                '配送後別足の時間条件を満たす': c_start >= timing['理論最早cStart'],
                'その確認Rawから1秒後が期限内': at + 1 < expiry,
                '量CloseLastの個別理由': '回復済み' if t['stage'] == '1分回復' else '合成理由のみで個別値未記録'})
        improvements.append({'session': m['session'], 'episode_id': identity, 'side': m['side'], '新5分End': m['fields']['improvement']['end'],
            '新5分配送': d, '配送JST': jst(d), **timing, '取消理由': end['reason'], '取消Raw': end['at'],
            '120秒取消': timeout, '改善時点Last幾何': g, '回復判定の小記録': candidates})
        for r in (t for t in traces if t['stage'] == '1分回復'):
            f = k['fields']; at = r['at']; now = geometry(r['side'], at['last'], f)
            failures = scene_stats[r['session']]['counts'].get('維持待ち/K又はcap/risk不成立', 0)
            span = end['at']['index'] - at['index']
            assert observed_recoveries[r['session']] == 1 and failures == span
            assert r['fields']['recovery_minute']['volume_known'] and r['fields']['previous_minute']['volume_known']
            assert r['fields']['recovery_minute']['volume'] >= r['fields']['previous_minute']['volume'] > 0
            recoveries.append({'session': r['session'], 'episode_id': identity, 'side': r['side'],
                '回復確認Raw': at, '確認JST': jst(at['time']), 'K': f['K'], 'I': f['I'], 'cap': f['cap'], 'ATR': f['atr'],
                '確認時点幾何': now, '回復後残秒': expiry - at['time'], '確認から最低1秒保持が時間上可能': at['time'] + 1 < expiry,
                '取消時点幾何': geometry(r['side'], end['at']['last'], f), '取消Raw': end['at'],
                '確認行から取消直前まで採用index差': span, '場の位置条件拒否件数': failures,
                '同場の回復episode数': 1, '全対象Raw分の拒否件数一致': True,
                '中間行のcapとrisk個別内訳': '未識別。値は記録されず、K/cap/risk合成拒否counterのみ'})
    assert len(improvements) == 34 and len(recoveries) == 3
    assert count['120期限26/可能'] + count['120期限26/不可能'] == 26
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == EXPECTED
    summary = {'成功': True, 'SourceSHA256': EXPECTED, '対象': 'E1 lifecycle/statsだけ。旧取得列と金融は未参照',
        '段階数': dict(stages), '遷移理由': dict(reasons), '配送phase34': dict(sorted(phases.items(), key=lambda v: float(v[0]))),
        '120期限取消26のphase': dict(sorted(timeout_phases.items(), key=lambda v: float(v[0]))),
        '理論時計の分解': dict(count), '改善時点Lastの既存幾何条件': dict(m_geometry),
        '理論の前提': '分の開始はfloor(time/60)*60。配送原行をFirstとする足を除き次の丸1分、理想的にEndで閉鎖、さらに1秒保持、期限はstrict。実データの成立を予測しない',
        '未識別': ['回復待ち合成理由の量/Close/Last内訳', '回復3例の中間各Rawの個別cap/risk値',
                  '完全な足/価格/実BBOの新しい取り直しは行わない'],
        '原板とCSV読取': False, '金融読取と再計算': False, '137反実仮想の計算': False, '136条件変更': False}
    for filename, value in (('時計と幾何の集約.json', summary), ('全34改善の時計.json', improvements), ('回復3例の位置条件.json', recoveries)):
        (OWN / filename).write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    proof = {'成功': True, 'Source前後SHA256': EXPECTED, 'Source不変': True, 'コードSHA256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        '人工境界': '0/1秒不可、5秒余地4秒、episode短縮、売買鏡像成功',
        '出力SHA256': {name: hashlib.sha256((OWN / name).read_bytes()).hexdigest() for name in
                      ('時計と幾何の集約.json', '全34改善の時計.json', '回復3例の位置条件.json')},
        '新Rawと金融': False, '新政策や閾値の追加': False}
    dest = OWN / '診断の確認.json'; dest.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'success': True, 'proof_sha256': hashlib.sha256(dest.read_bytes()).hexdigest(), 'counts': dict(count), 'geometry': dict(m_geometry)}, ensure_ascii=True))


if __name__ == '__main__':
    main()
