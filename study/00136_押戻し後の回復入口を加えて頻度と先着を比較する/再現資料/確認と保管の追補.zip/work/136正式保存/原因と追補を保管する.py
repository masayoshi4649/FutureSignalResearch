"""136の停止済み原因診断と非金融再現の追補を、F0固定資料と分けて保管する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=ROOT/'study/00136_押戻し後の回復入口を加えて頻度と先着を比較する'


def sha(body: bytes) -> str:
    """
    機能: 停止済み原文の指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def save(source: Path, target: Path, packed: bool=False) -> dict:
    """
    機能: 原文を一度だけ同体又はgzipで保管する。
    引数: source/target(Path)、packed(bool)。
    返り値: dictは保存/原文SHAと由来。
    """
    body=source.read_bytes();saved=gzip.compress(body,mtime=0) if packed else body
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as handle:handle.write(saved)
    return {'由来':source.relative_to(ROOT).as_posix(),'保存元':target.relative_to(ROOT).as_posix(),
            '形式':'gzip' if packed else '同体','保存SHA256':sha(saved),'原文SHA256':sha(body)}


# ----------------------------------------
def main() -> None:
    """
    機能: lifecycle限定原因を保存し、結果後の確認/再現コードを別ZIPにする。
    引数: なし。
    返り値: None。自然Raw再走査・金融F1/新集計/CSVを作らない。
    """
    cause=ROOT/'work/136順次確認が出生しない原因'
    assert sha((cause/'README.md').read_bytes())=='a7d81090edcf9f71d93bab7d34fb61b97d9e7401bf31c1e1cf95dcf7c794d79d'
    assert sha((cause/'診断の確認.json').read_bytes())=='4620d3673a7964cffd6b135a14a3f31bcbbccda6c8023318d8abefd4b9f2d16c'
    proof=json.loads((cause/'診断の確認.json').read_bytes())
    for name,expected in proof['出力SHA256'].items():assert sha((cause/name).read_bytes())==expected
    records=[]
    for name,target,packed in [('README.md','出生ゼロの原因.md',False),('診断の確認.json','原因診断の確認.json',False),
                               ('時計と幾何の集約.json','時計と幾何の集約.json',False),
                               ('全34改善の時計.json','全34改善の時計.json.gz',True),
                               ('回復3例の位置条件.json','回復3例の位置条件.json',False)]:
        records.append(save(cause/name,FORMAL/'根拠'/target,packed))
    (FORMAL/'根拠/原因資料.md').write_text('''# 出生ゼロを段階別に診断する

[診断短報](出生ゼロの原因.md)は保存Sourceのlifecycle/statsだけを利用した。[確認票](原因診断の確認.json)、[集約](時計と幾何の集約.json)、[改善34件の時計](全34改善の時計.json.gz)、[回復3例の位置](回復3例の位置条件.json)を原文同体で保存した。金融・実取得価格・新Rawを参照した分析ではない。

34改善中15は丸1分の後続足と最低1秒保持をstrict期限前に終えられない。回復3例は確認時点で全てLastが固定capを超え、維持geometryの有効開始に進まなかった。途中各行のcap/risk個別内訳は記録不足で識別しない。件数を実取得や利益の見込みにしない。

診断コードは[後発資料ZIP](../再現資料/確認と保管の追補.zip)へ保存した。136の期限・K/cap・条件は不変。後続137の市場Endと実配送を分ける案は別準備で、ここへ新結果を混ぜない。
''',encoding='utf-8')
    files=sorted((ROOT/'work/136正式保存').glob('*.py'))+sorted((FORMAL/'再現資料').glob('*.py'))
    files+=[ROOT/'work/136全方向同体を確認する.py',cause/'診断する.py']
    review=ROOT/'work/E1のSource接続を独立確認する'
    for path in review.iterdir():
        if not path.is_file() or path.name=='独立確認.json':continue
        if path.suffix in ('.go','.py','.md','.json','.jsonl'):files.append(path)
    archive=FORMAL/'再現資料/確認と保管の追補.zip';index=[]
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in sorted(set(files)):
            body=path.read_bytes();name=path.relative_to(ROOT).as_posix();z.writestr(name,body)
            index.append({'path':name,'bytes':len(body),'sha256':sha(body),'区分':'Source後の保管/原因と独立人工の補助。F0直接63源とは別'})
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in index:assert sha(z.read(item['path']))==item['sha256']
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes())
    m['原因資料']=records
    m['後発資料']={'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(index),'格納源':index}
    m['段階']='非金融同体試行。Source完了・新E1なし・新金融F1/集計/CSVを意図して生成しない'
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'原因資料':len(records),'後発ZIP源':len(index),'後発ZIP_SHA256':m['後発資料']['ZIP_SHA256'],'新金融実行':False},ensure_ascii=False))


if __name__=='__main__':
    main()
