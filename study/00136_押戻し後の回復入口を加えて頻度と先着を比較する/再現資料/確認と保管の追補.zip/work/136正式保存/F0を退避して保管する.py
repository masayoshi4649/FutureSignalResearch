"""136のSource実行前F0を退避し、新規源と旧133共有コードを最小構成で保管する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=ROOT/'study/00136_押戻し後の回復入口を加えて頻度と先着を比較する'
OWN=ROOT/'work/136押戻し回復の評価'
F0_SHA='3fe3ceae426787b689145fd7aa7730b4bc27ea1dfbb918c93f3d66eb463211ba'


def sha(body: bytes) -> str:
    """
    機能: 保存原文の指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def put(path: Path, body: bytes) -> None:
    """
    機能: 未作成の正式保管先へ原文を保存する。
    引数: path(Path)、body(bytes)。
    返り値: None。既存を上書きしない。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as handle: handle.write(body)


# ----------------------------------------
def main() -> None:
    """
    機能: 全12MDと小型F0源を照合し、旧コード/旧Sourceを重複保存しない索引を作る。
    引数: なし。
    返り値: None。実行中Source、Raw/177MB本文、金融、追加2場は操作しない。
    """
    original=(OWN/'F0.json').read_bytes(); assert sha(original)==F0_SHA
    f0=json.loads(original); assert len(f0['ファイル'])==63
    previous=ROOT/'study/00133_全場参加を維持して強い入口の探索期限を延ばす'
    prior=json.loads((previous/'保管索引.json').read_bytes())
    base=prior['固定コード']; archive=previous/'再現資料'/base['ZIP']
    assert sha(archive.read_bytes())==base['ZIP_SHA256']
    old_by_sha={item['sha256']:item for item in base['格納源']}
    shared=[]; new=[]; docs=[]; excluded=[]; saved_bodies={}
    legacy_source='work/133探索期限の評価/Sourceの出生と取得.json'
    for name,expected in f0['ファイル'].items():
        path=Path(name); relative=path.relative_to(ROOT).as_posix()
        if relative=='work/122全場入力/入力.json' or path.suffix=='.exe':
            excluded.append({'path':relative,'sha256':expected,'bytes':path.stat().st_size,
                             '理由':'共用177MB入力は生成元参照。実行体は元SHAを残しコードから別途再ビルド。本文の恒久複製なし'})
            continue
        if relative==legacy_source:
            continue
        assert path.stat().st_size<2_000_000,relative
        body=path.read_bytes(); assert sha(body)==expected,relative
        if path.suffix=='.md':
            docs.append({'path':relative,'bytes':len(body),'sha256':expected,'本文':body.decode('utf-8')})
        if expected in old_by_sha:
            prior_item=old_by_sha[expected]
            shared.append({'ZIP内path':prior_item['path'],'復元先':relative,'bytes':len(body),'sha256':expected,
                           '固定方法':'F0直接固定。旧133保存コードの復元先を写像'})
        else:
            item={'path':relative,'bytes':len(body),'sha256':expected,'固定方法':'F0直接固定'}
            new.append(item); saved_bodies[relative]=body
    assert len(docs)==12 and sum(x['path'].startswith('study/') for x in docs)==4
    assert len(shared)==13 and len(new)==47 and len(excluded)==2
    put(FORMAL/'検査/F0.json',original)
    snapshot={'試行':136,'段階':'Source自然実行前F0の結果編集前原文','F0_SHA256':F0_SHA,
              '文書数':12,'正式文書数':4,'金融前F1はまだ保存していない':True,'文書':docs}
    snapshot_body=(json.dumps(snapshot,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    put(FORMAL/'検査/実行前文書_F0.json.gz',gzip.compress(snapshot_body,mtime=0))
    indirect=json.loads((ROOT/'work/E1のSource接続を独立確認する/独立確認.json').read_bytes())
    assert sha((ROOT/'work/E1のSource接続を独立確認する/独立確認.json').read_bytes())=='5370014e83e576038fd621664bc37e331b5dfd0cd1b07fcb0c9fa453e1e4936c'
    dependencies=[]
    for name,expected in indirect['コードSHA256'].items():
        relative=Path(name).as_posix()
        if not relative.startswith(('work/118複数技法の入口条件/','work/121入口の反転切替/')):
            continue
        assert expected in old_by_sha,relative
        body=(ROOT/relative).read_bytes(); assert sha(body)==expected
        item=old_by_sha[expected]
        dependencies.append({'ZIP内path':item['path'],'復元先':relative,'bytes':len(body),'sha256':expected,
                             '固定方法':'F0内の独立確認JSONが持つ共有依存の間接指紋。F0直接63源へ後付けしない'})
    assert dependencies
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in shared+dependencies: assert sha(z.read(item['ZIP内path']))==item['sha256']
    source=next(x for x in prior['新共用入力'] if x['復元先']==legacy_source)
    body=(ROOT/source['保存元']).read_bytes(); assert sha(body)==source['保存SHA256']
    assert sha(gzip.decompress(body))==source['解凍SHA256']==f0['ファイル'][str(ROOT/legacy_source)]
    recipe=FORMAL/'再現資料'; recipe.mkdir(exist_ok=True)
    new_archive=recipe/'136_Source前F0資料.zip'
    with zipfile.ZipFile(new_archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for item in new: z.writestr(item['path'],saved_bodies[item['path']])
    with zipfile.ZipFile(new_archive) as z:
        assert z.testzip() is None
        for item in new: assert sha(z.read(item['path']))==item['sha256']
    manifest={'試行':136,'段階':'Source前F0の保管準備だけ。自然結果/金融F1/新損益は未保管',
              'F0_SHA256':F0_SHA,'F0直接源数':63,
              'F0追加資料':{'ZIP':new_archive.name,'ZIP_SHA256':sha(new_archive.read_bytes()),'ZIP_bytes':new_archive.stat().st_size,'格納源数':len(new),'格納源':new},
              'F0共有コード':{'保存元ZIP':archive.relative_to(ROOT).as_posix(),'ZIP_SHA256':base['ZIP_SHA256'],'格納源数':len(shared),'格納源':shared},
              '間接固定の共有依存':{'保存元ZIP':archive.relative_to(ROOT).as_posix(),'ZIP_SHA256':base['ZIP_SHA256'],'格納源数':len(dependencies),'格納源':dependencies},
              'F0共有入力':[source],'意図して複製しないF0源':excluded,
              'F0原文MD':{'gzip':'検査/実行前文書_F0.json.gz','保存SHA256':sha((FORMAL/'検査/実行前文書_F0.json.gz').read_bytes()),'解凍SHA256':sha(snapshot_body),'MD数':12,'正式MD数':4},
              '金融前F1を作成':False,'結果文面を編集':False,'Sourceプロセスを操作':False,
              '自然Raw/CSV/177MB本文/追加2場読取':False}
    put(FORMAL/'保管索引.json',(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    proof={'成功':True,'試行':136,'段階':'F0原文と最小コードの先行保管','F0_SHA256':F0_SHA,
           '全F0原文MD':12,'正式原文MD':4,'追加ZIP源':47,'共有コード':13,'間接固定依存':len(dependencies),
           '復元可能なF0直接源':61,'意図して未複製':excluded,'結果/金融/Sourceプロセス操作':False,
           '原文MD_gzip_SHA256':manifest['F0原文MD']['保存SHA256'],'追加ZIP_SHA256':manifest['F0追加資料']['ZIP_SHA256'],
           'コードSHA256':sha(Path(__file__).read_bytes())}
    put(FORMAL/'検査/F0原文と源の保管確認.json',(json.dumps(proof,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'F0_MD':12,'正式MD':4,'追加ZIP源':47,'共有13源と間接依存':len(dependencies),
                      'ZIP_SHA256':manifest['F0追加資料']['ZIP_SHA256'],'保管確認SHA256':sha((FORMAL/'検査/F0原文と源の保管確認.json').read_bytes())},ensure_ascii=False))


if __name__=='__main__':
    main()
