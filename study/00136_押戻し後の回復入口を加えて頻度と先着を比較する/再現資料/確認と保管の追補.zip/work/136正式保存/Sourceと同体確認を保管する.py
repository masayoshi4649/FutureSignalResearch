"""136の新Sourceを一度gzip保管し、新金融を行わない同体証拠を分けて保存する。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
FORMAL=ROOT/'study/00136_押戻し後の回復入口を加えて頻度と先着を比較する'
OWN=ROOT/'work/136押戻し回復の評価'


def sha(body: bytes) -> str:
    """
    機能: 保存原文の指紋を返す。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def put(path: Path, body: bytes) -> None:
    """
    機能: 未作成先へ同体資料を保存する。
    引数: path(Path)、body(bytes)。
    返り値: None。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as handle:handle.write(body)


# ----------------------------------------
def main() -> None:
    """
    機能: 全73場のSource正本と非金融同体proofを保管し、金融非実行を記録する。
    引数: なし。
    返り値: None。Raw/177MB・追加2場・新金融に触れない。
    """
    source=(OWN/'Sourceの出生と取得.json').read_bytes()
    assert len(source)==4_836_317 and sha(source)=='f777aa32ab145bf5b9ba570b06244ec071fb40356eff67efce55137ba197b6c2'
    checks=[('Source非金融の確認.json','006e38a423d2bdb68167e1f5803f1ba46fed7a9ad23b0911f23ed48699dd23e3'),
            ('全方向同体の確認.json','f6d9a5c43202d625b1e88facb298df28dcd17c5e2582d9e3bb4952ff824d1b0e')]
    for name,expected in checks:
        body=(OWN/name).read_bytes();assert sha(body)==expected
        put(FORMAL/'検査'/name,body)
    put(FORMAL/'検査/Source走査の完了.json',(OWN/'Source走査の完了.json').read_bytes())
    prepared=ROOT/'work/136押戻し回復と頻度の集計/準備の確認.json'
    assert sha(prepared.read_bytes())=='957c2dc1f55b9cc3b7761a0f54788e505c6a795c535bd2d369833d51173b34c9'
    put(FORMAL/'検査/未実行金融集計器の準備.json',prepared.read_bytes())
    folder=ROOT/'inputs/00136_E1のSource接続';folder.mkdir(exist_ok=True)
    packed=gzip.compress(source,compresslevel=9,mtime=0)
    saved=folder/'Sourceの出生と取得.json.gz';put(saved,packed)
    item={'保存元':saved.relative_to(ROOT).as_posix(),'復元先':'work/136押戻し回復の評価/Sourceの出生と取得.json',
          '形式':'gzip','保存bytes':len(packed),'保存SHA256':sha(packed),'解凍bytes':len(source),'解凍SHA256':sha(source)}
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes());assert '新Source入力' not in m
    m['新Source入力']=item
    m['金融非実行']={'新金融F1':False,'新金融集計':False,'新CSV':False,'正逆Raw再走査':False,
                     '理由':'新E1出生/取得0でC0/S0/A0の全79参照・方向が同体。旧対照を継承参照する'}
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'新Source_gzip_bytes':len(packed),'gzip_SHA256':sha(packed),
                      '金融F1/新集計/CSV':False,'Sourceを一度保存':True},ensure_ascii=False))


if __name__=='__main__':
    main()
