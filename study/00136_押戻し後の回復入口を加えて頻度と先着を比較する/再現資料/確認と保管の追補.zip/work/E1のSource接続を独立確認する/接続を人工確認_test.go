package holdingohlc113

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"testing"
	"time"

	episode "github.com/masayoshi4649/SessionTradeExecuter/e1episode"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// reviewValue は、手製の公表値を既知として作ります。
//
// 引数: n(float64)。返り値: rules.Value。市場入力を読みません。
func reviewValue(n float64) rules.Value { return rules.Value{Known: true, Value: n} }

// ----------------------------------------
// reviewQuote は、人工の原行を一意な時計で作ります。
//
// 引数: stamp(float64)、index/line(int64)。返り値: Quoteは正のBid<Askです。
func reviewQuote(stamp float64, index, line int64) Quote {
	return Quote{Clock: time.Unix(int64(stamp), 0).UTC().Format(time.RFC3339Nano), Time: stamp,
		Index: index, SourceLine: line, Last: 100, Bid: 95, Ask: 105, QuoteOK: true}
}

// ----------------------------------------
// reviewFixture は、3採用行と任意の時計欠落1行だけの人工Sourceを作ります。
//
// 引数: t(*testing.T)、broken(bool)。返り値: Scene133はt.TempDir内のJSONLだけを参照します。
func reviewFixture(t *testing.T, broken bool) Scene133 {
	t.Helper()
	var body []byte
	for i, stamp := range []float64{110800, 110801, 110802} {
		row := map[string]any{"Symbol": "X", "CurrentPriceTime": time.Unix(int64(stamp), 0).UTC().Format(time.RFC3339Nano), "CurrentPrice": 100}
		for depth := 1; depth <= 10; depth++ {
			row[fmt.Sprintf("Buy%d", depth)] = map[string]float64{"Price": 96 - float64(depth), "Qty": 1}
			row[fmt.Sprintf("Sell%d", depth)] = map[string]float64{"Price": 104 + float64(depth), "Qty": 1}
		}
		encoded, err := json.Marshal(row)
		if err != nil {
			t.Fatal(err)
		}
		body = append(body, append(encoded, '\n')...)
		if broken && i == 0 {
			body = append(body, []byte("{\"Symbol\":\"X\"}\n")...)
		}
	}
	path := filepath.Join(t.TempDir(), "独立人工.jsonl")
	if err := os.WriteFile(path, body, 0600); err != nil {
		t.Fatal(err)
	}
	digest := sha256.Sum256(body)
	s := Scene133{Session: "s", Contract: "X", Start: 100000, End: 130000, ForceClose: 129400,
		Raw: FileRef{Path: path, SHA256: hex.EncodeToString(digest[:])}, ExpectedAccepted: 3}
	for _, width := range []int{300, 900, 1800} {
		f := rules.ChartFrame{ID: fmt.Sprintf("s/%d/110740", width), SessionID: "s", Contract: "X", Width: width,
			Start: 110740 - float64(width), End: 110740, AvailableAt: 110800, DeliveryAt: 110800,
			PriceKnown: true, VolumeKnown: true, Volume: 100, OHLC: rules.OHLC{Open: 80, High: 110, Low: 70, Close: 100},
			Technical: rules.Technical{EMA8: reviewValue(105), EMA21: reviewValue(100), EMA8Delta: reviewValue(1), EMA21Delta: reviewValue(1), Gap: reviewValue(5),
				ATR: reviewValue(20), PreviousATR: reviewValue(20), TR: reviewValue(10), RSI: reviewValue(60), PreviousRSI: reviewValue(55),
				Histogram: reviewValue(1), PreviousHistogram: reviewValue(.5)}}
		s.Publications = append(s.Publications, rules.Publication{Stamp: rules.Stamp{Time: 110800, Index: 0, Line: 1},
			Frame: rules.Frame{Frame: f, DMI: rules.DMI{PlusDI: reviewValue(30), MinusDI: reviewValue(10), ADX: reviewValue(30), PreviousADX: reviewValue(25)}}})
	}
	return s
}

// reviewSpy は、観測位置の引数を記録するだけで旧状態へ書き込みません。
type reviewSpy struct {
	frames []int
	fills  []int
	quotes []Quote
}

// Accepted は、同原行の全公表と元pendingの取得が既に反映されたかを記録します。
//
// 引数: bank(*rules.Bank)、q(Quote)、born(bool)、fills([]*Candidate133)、row([]byte)。返り値: errorは読取矛盾です。
func (s *reviewSpy) Accepted(bank *rules.Bank, q Quote, born bool, fills []*Candidate133, row []byte) error {
	snap, err := bank.Current(quote133(q))
	if err != nil {
		return err
	}
	s.frames = append(s.frames, len(snap.Frames))
	s.fills = append(s.fills, len(fills))
	s.quotes = append(s.quotes, q)
	return nil
}

// Rejected は、元走査の結果を変えず通知を消費します。
//
// 引数: reason(string)。返り値: ありません。
func (s *reviewSpy) Rejected(reason string) {}

// ----------------------------------------
// TestIndependentE1FrozenLegacyParity は、旧scan本体・nil wrapper・実observerの旧全値を比較します。
//
// 引数: t(*testing.T)。返り値: ありません。旧補完の実取得を含む3行人工だけを使います。
func TestIndependentE1FrozenLegacyParity(t *testing.T) {
	s := reviewFixture(t, false)
	expected, err := frozenScanE1Review([]Scene133{s}, 0)
	if err != nil {
		t.Fatal(err)
	}
	without, err := scan133([]Scene133{s}, 0)
	if err != nil || !reflect.DeepEqual(expected, without) {
		t.Fatal("旧scan本体とnil wrapperの結果差", err)
	}
	o, err := newE1Observer(s)
	if err != nil {
		t.Fatal(err)
	}
	withObserver, err := scanCore133([]Scene133{s}, 0, o)
	if err != nil || !reflect.DeepEqual(expected, withObserver) {
		t.Fatal("追加observerが旧結果へ影響", err)
	}
	selected, err := selectE1Scene(s, withObserver, o.Candidates)
	if err != nil || len(selected.C0) != 1 || len(selected.S0) != 1 {
		t.Fatal("旧取得を含む人工になっていない", err, selected)
	}
	if selected.C0[0].EntryStamp.Time != 110801 || selected.C0[0].EntryStamp.Index != 1 || selected.C0[0].EntryStamp.SourceLine != 2 {
		t.Fatal("旧補完が出生ではなく取得時計で接続されていない")
	}
}

// ----------------------------------------
// TestIndependentE1ObserverOrder は、全公表配送・元pending取得の後に通知することを検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestIndependentE1ObserverOrder(t *testing.T) {
	s := reviewFixture(t, false)
	spy := &reviewSpy{}
	if _, err := scanCore133([]Scene133{s}, 0, spy); err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(spy.frames, []int{3, 3, 3}) || len(spy.fills) != 3 || spy.fills[0] != 0 || spy.fills[1] != 1 {
		t.Fatalf("公表/元pendingの通知順差: frames=%v fills=%v", spy.frames, spy.fills)
	}
	if spy.quotes[0].Index != 0 || spy.quotes[1].Index != 1 || spy.quotes[1].SourceLine != 2 {
		t.Fatal("observerの取得原行がずれた")
	}
}

// ----------------------------------------
// reviewPending は、同じ取得adapterを通せる手製の出生を作ります。
//
// 引数: q(Quote)、s(Scene133)。返り値: *E1Candidate/error。金融値は入力しません。
func reviewPending(q Quote, s Scene133) (*E1Candidate, error) {
	e := episode.Event{Session: s.Session, ID: "s/E1/独立人工", Mode: "E1", Side: 1,
		At: episode.Stamp{Time: q.Time, Index: q.Index, Line: q.SourceLine}, EntryCap: 110, Invalidation: 80,
		ATR5: 20, HoldBoundary: 99, HoldMinimum: 0, MinimumRisk: 10}
	return newE1Request(e, q, s)
}

// ----------------------------------------
// TestIndependentE1RejectedClockFlow は、decoder拒否通知から要求取消しと復活不能を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。時計欠落の手製1行を挟みます。
func TestIndependentE1RejectedClockFlow(t *testing.T) {
	s := reviewFixture(t, true)
	o, err := newE1Observer(s)
	if err != nil {
		t.Fatal(err)
	}
	c, err := reviewPending(reviewQuote(110800, 0, 1), o.Scene)
	if err != nil {
		t.Fatal(err)
	}
	o.Candidates = append(o.Candidates, c)
	out, err := scanCore133([]Scene133{s}, 0, o)
	if err != nil {
		t.Fatal(err)
	}
	if out.Quality.ClockMissing != 1 || o.RejectedBy["clock_missing"] != 1 || c.Status != "cancelled_clock_rejection" || c.Entry != nil || c.Evaluation != nil {
		t.Fatal("decoder時計拒否後にE1が評価又は取得された", c, out.Quality)
	}
	if c.Birth.Time+1 != 110801 {
		t.Fatal("有効BBOで取得可能な反例になっていない")
	}
}

// ----------------------------------------
// TestIndependentE1EOFDoesNotCloseMinute は、EOFがpending以外の状態を改変しないことを検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestIndependentE1EOFDoesNotCloseMinute(t *testing.T) {
	s := Scene133{Session: "s", Contract: "X", Start: 90, End: 10000, ForceClose: 500}
	o, err := newE1Observer(s)
	if err != nil {
		t.Fatal(err)
	}
	q := reviewQuote(100, 0, 1)
	c, err := reviewPending(q, o.Scene)
	if err != nil {
		t.Fatal(err)
	}
	o.Candidates = append(o.Candidates, c)
	if _, _, _, err = o.Minutes.Observe(e1Quote(q), nil, nil); err != nil {
		t.Fatal(err)
	}
	before := o.Minutes.Stats()
	stats := o.Detector.Stats()
	o.finish()
	if c.Status != "eof_unfilled" || c.Entry != nil || c.Evaluation != nil || c.EntryPrice != nil || !reflect.DeepEqual(before, o.Minutes.Stats()) || !reflect.DeepEqual(stats, o.Detector.Stats()) {
		t.Fatal("EOFが足又は金融評価を作成", c)
	}
}

// ----------------------------------------
// reviewFilledE1 は、頻度抽出だけを調べる取得済み識別候補を作ります。
//
// 引数: id(string)、q(Quote)。返り値: *E1Candidateは人工のpattern向き取得です。
func reviewFilledE1(id string, q Quote) *E1Candidate {
	birth := q
	birth.Time--
	birth.Index--
	birth.SourceLine--
	return &E1Candidate{ID: id, Path: "E1", DirectionPolicy: "pattern", T8Applied: false,
		Status: "filled", Birth: birth, Entry: &q}
}

// ----------------------------------------
// TestIndependentE1FrequencyAllFills は、A0が旧全取得と非重複の全E1を保持することを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。先着1補完のS0制限を混ぜない人工です。
func TestIndependentE1FrequencyAllFills(t *testing.T) {
	s := Scene133{Session: "s", Contract: "X"}
	q0, q1 := reviewQuote(20, 20, 21), reviewQuote(40, 40, 41)
	legacy := Result133{Candidates: []*Candidate133{
		{Path: "E0", Policy: "L0", Birth: Signal133{ID: "old-e0", Quote: reviewQuote(19, 19, 20)}, Entry: &q0, Status: "filled"},
		{Path: "deadline", Policy: "L0", Birth: Signal133{ID: "old-l0", Quote: reviewQuote(39, 39, 40)}, Entry: &q1, Status: "filled"},
	}}
	extra := []*E1Candidate{
		reviewFilledE1("before", reviewQuote(10, 10, 11)),
		reviewFilledE1("same-e0", q0),
		reviewFilledE1("after-a", reviewQuote(30, 30, 31)),
		reviewFilledE1("same-l0", q1),
		reviewFilledE1("same-second-other-line", reviewQuote(40, 40, 42)),
		reviewFilledE1("after-b", reviewQuote(50, 50, 51)),
		{ID: "not-filled", Status: "pending", DirectionPolicy: "pattern"},
	}
	a0, err := frequencyE1Scene(s, legacy, extra)
	if err != nil {
		t.Fatal(err)
	}
	want := []string{"before", "old-e0", "after-a", "old-l0", "same-second-other-line", "after-b"}
	got := []string{}
	for _, c := range a0 {
		got = append(got, c.ID)
		if c.Session != "s" || c.Contract != "X" {
			t.Fatal("場/限月の混入")
		}
	}
	if !reflect.DeepEqual(got, want) {
		t.Fatalf("A0全取得又は原行重複排除の相違: %v", got)
	}
	selection, err := selectE1Scene(s, legacy, extra)
	if err != nil || len(selection.C0) != 2 || len(selection.S0) != 2 || len(a0) <= len(selection.S0) {
		t.Fatal("A0へ最初1補完又はE0後の補完禁止を混入", err)
	}
}
