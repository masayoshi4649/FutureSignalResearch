"""作者の停止通知後だけE1接続の独立人工を実行し、コード前後不変を確認する。"""
from pathlib import Path
import argparse
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
NATIVE = ROOT/'work/押戻し回復をSourceへ接続する/Source再生器'
ORIGINAL = ROOT/'work/強い入口の探索期限を延ばす次仮説/Source入口の再生器'


def sha(path: Path) -> str:
    """
    機能: 比較するコードの指紋を返す。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def function(text: str, name: str) -> str:
    """
    機能: 後続の区切りまでの対象関数を切り出す。
    引数: text(str)、name(str)。
    返り値: strは関数宣言と本体。
    """
    start = text.index('func '+name+'(')
    end = text.find('\n// ----------------------------------------',start)
    return text[start:end if end>=0 else None].strip()


# ----------------------------------------
def main() -> None:
    """
    機能: 旧scan本体と接続差分を照合後、手製原行の独立人工だけを実行する。
    引数: CLI --execute-after-author-stop(bool)は作者の完了通知後にだけ指定する。
    返り値: None。自然Raw/CSV/金融/追加期間・正式成果は開かない。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('--execute-after-author-stop',action='store_true',required=True)
    args=parser.parse_args(); assert args.execute_after_author_stop
    target=OWN/'独立確認.json'; assert not target.exists()
    author_proof=NATIVE.parent/'Rootの準備の確認.json'
    author_sha='61a808f6b203fae50e09fbd8ac5f5490c2c1aeec96c72306305623244f1e4a50'
    assert sha(author_proof)==author_sha
    sources=[NATIVE.parent/'接続の条件.md']
    for folder in (NATIVE,ROOT/'work/118複数技法の入口条件',ROOT/'work/121入口の反転切替',
                   ROOT/'work/押戻し位相を保存して回復を待つ入口',ROOT/'work/押戻し回復の1分入力',
                   ROOT/'work/押戻し回復の取得を時系列で選ぶ'):
        sources += sorted(folder.rglob('*.go')) + sorted(folder.glob('go.mod'))
    sources += [ORIGINAL/'entry.go'] + sorted(OWN.glob('*.go')) + sorted(OWN.glob('*.py'))
    before={str(p.relative_to(ROOT)):sha(p) for p in sorted(set(sources))}
    shared=[]
    for old in ORIGINAL.glob('*.go'):
        relative=old.relative_to(ORIGINAL)
        if relative.as_posix()=='entry.go': continue
        current=NATIVE/relative
        assert old.read_bytes()==current.read_bytes(),str(relative)
        shared.append(relative.as_posix())
    old=function((ORIGINAL/'entry.go').read_text('utf-8'),'scan133')
    copy=function((OWN/'凍結走査の参照_test.go').read_text('utf-8'),'frozenScanE1Review')
    assert copy.replace('func frozenScanE1Review(','func scan133(',1)==old
    core=function((NATIVE/'entry.go').read_text('utf-8'),'scanCore133')
    restored=core.replace('func scanCore133(all []Scene133, at int, observer sourceObserver133)',
                         'func scan133(all []Scene133, at int)',1)
    restored=restored.replace('q, reason, next, e := decodeRow(', 'q, _, next, e := decodeRow(',1)
    rejected='\t\t\tif observer != nil {\n\t\t\t\tobserver.Rejected(reason)\n\t\t\t}\n'
    accepted='\t\tif observer != nil {\n\t\t\tif err = observer.Accepted(bank, *q, e0Born["L0"], newFills, scan.Bytes()); err != nil {\n\t\t\t\treturn out, err\n\t\t\t}\n\t\t}\n'
    assert restored.count(rejected)==1 and restored.count(accepted)==1
    restored=restored.replace(rejected,'',1).replace(accepted,'\t\t_ = newFills\n',1)
    assert restored==old
    command=['go','test','-overlay='+str(OWN/'overlay.json'),'-run','^TestIndependentE1','-count=1','-json','.']
    run=subprocess.run(command,cwd=NATIVE,capture_output=True,text=True,encoding='utf-8')
    (OWN/'人工のログ.jsonl').write_text(run.stdout,encoding='utf-8')
    assert run.returncode==0,(run.stdout,run.stderr)
    events=[json.loads(line) for line in run.stdout.splitlines() if line]
    tests=[e['Test'] for e in events if e.get('Action')=='pass' and 'Test' in e]
    assert len(tests)==5
    after={str(p.relative_to(ROOT)):sha(p) for p in sorted(set(sources))}
    assert before==after
    proof={'成功':True,'対象':'E1のSource接続とA0の独立人工','作者の完了通知後に実行':True,'Root準備票SHA256':author_sha,
           '静的照合':{'旧scanへ戻した本体同体':True,'独立参照は関数名変更のみ':True,'entry以外の走査package内旧Go源同体数':len(shared),'同体の旧Go源':shared,'旧CLIと新接続CLIは別':True},
           '人工主数':5,'人工':tests,'元走査/nil/実observerで旧全値同体':True,
           '旧補完の実取得を含む独立Raw':{'採用行':3,'公表尺度':3,'C0取得':1},
           '全公表配送と元pending取得後のobserver':True,'decoder時計拒否後pending取消しと復活不可':True,
           'EOFで足を閉じず未取得要求のみ終了':True,'A0人工取得数':6,'S0人工取得数':2,
           'A0がC0全件を包含':True,'A0が同原行C0優先で全非重複E1を保持':True,
           '同Time別IndexLineを同原行扱いしない':True,'Rootソース前後不変':True,'コードSHA256':before,
           '人工ログSHA256':sha(OWN/'人工のログ.jsonl'),'実行列':command,
           '旧73場79取得の自然同体確認':False,'自然Raw/CSV/金融/追加2場読取':False,'正式成果変更':False,
           '限界':'手製原行とコード差分による接続確認。E1の自然出生数、参加、頻度、先着率、損益は未検証。'}
    with target.open('x',encoding='utf-8') as handle:
        handle.write(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'独立人工':len(tests),'旧Go同体':len(shared),
                      '確認SHA256':sha(target),'自然データ読取':False},ensure_ascii=False))


if __name__=='__main__':
    main()
