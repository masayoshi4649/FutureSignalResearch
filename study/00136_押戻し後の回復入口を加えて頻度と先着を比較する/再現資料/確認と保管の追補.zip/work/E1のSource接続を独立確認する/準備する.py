"""旧133の走査本体を関数名だけ変えて独立overlayへ保存する。自然入力は開かない。"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
NATIVE = ROOT/'work/押戻し回復をSourceへ接続する/Source再生器'
ORIGINAL = ROOT/'work/強い入口の探索期限を延ばす次仮説/Source入口の再生器/entry.go'


def main() -> None:
    """
    機能: 旧scan本体の対照と追加人工だけを仮想テストとして準備する。
    引数: なし。
    返り値: None。作者ソース・正式・市場データは更新しない。
    """
    source = ORIGINAL.read_text('utf-8')
    start = source.index('func scan133(')
    end = source.index('\n// ----------------------------------------',start)
    original_body = source[start:end]
    renamed = original_body.replace('func scan133(', 'func frozenScanE1Review(',1)
    imports = {'bufio':'bufio','sha256':'crypto/sha256','hex':'encoding/hex','fmt':'fmt','io':'io','os':'os',
               'birth':'github.com/masayoshi4649/SessionTradeExecuter/entrybirth121',
               'rules':'github.com/masayoshi4649/SessionTradeExecuter/entryrules118'}
    lines = []
    for alias,path in imports.items():
        if alias+'.' in renamed:
            prefix = (alias+' ') if alias in ('birth','rules') else ''
            lines.append('\t'+prefix+'"'+path+'"')
    text = 'package holdingohlc113\n\nimport (\n'+'\n'.join(lines)+'\n)\n\n'
    text += '// frozenScanE1Review は、旧133の走査本体を関数名だけ変更して再使用します。\n//\n'
    text += '// 引数: all([]Scene133)、at(int)。返り値: Result133/error。自然データを使うテストは呼びません。\n'
    text += renamed+'\n'
    target = OWN/'凍結走査の参照_test.go'; assert not target.exists()
    target.write_text(text,encoding='utf-8')
    overlay = {'Replace':{
        str(NATIVE/'独立凍結走査_test.go'):str(target),
        str(NATIVE/'独立E1接続_test.go'):str(OWN/'接続を人工確認_test.go'),
    }}
    with (OWN/'overlay.json').open('x',encoding='utf-8') as handle:
        handle.write(json.dumps(overlay,ensure_ascii=False,indent=2)+'\n')
    value = {'成功':True,'旧entry.go_SHA256':hashlib.sha256(ORIGINAL.read_bytes()).hexdigest(),
             '旧scan本体SHA256':hashlib.sha256(original_body.encode('utf-8')).hexdigest(),
             '本体の変更':'関数名scan133→frozenScanE1Reviewのみ。imports/注釈を独立ファイルへ追加',
             '作者ソース変更':False,'自然入力読取':False,'検査の実行':False}
    with (OWN/'準備の確認.json').open('x',encoding='utf-8') as handle:
        handle.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


if __name__=='__main__':
    main()
