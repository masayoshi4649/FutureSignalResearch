package holdingohlc113

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	birth "github.com/masayoshi4649/SessionTradeExecuter/entrybirth121"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"io"
	"os"
)

// frozenScanE1Review は、旧133の走査本体を関数名だけ変更して再使用します。
//
// 引数: all([]Scene133)、at(int)。返り値: Result133/error。自然データを使うテストは呼びません。
func frozenScanE1Review(all []Scene133, at int) (out Result133, err error) {
	s := all[at]
	sourceForce := s.ForceClose
	s, err = sourceScene133(s)
	if err != nil {
		return out, err
	}
	out = Result133{Session: s.Session, Raw: s.Raw, Candidates: []*Candidate133{}, Events: []birth.Event{}, RawPasses: 1, ExpectedQuality: s.ExpectedQuality, Participation: map[string]*Participation133{}}
	for _, p := range Policies133[1:] {
		out.Participation[p] = &Participation133{}
	}
	bank := rules.NewBank()
	for i := 0; i < at; i++ {
		p := all[i]
		if err = bank.StartSession(p.Session, p.Contract); err != nil {
			return out, err
		}
		for _, pub := range p.Publications {
			if pub.Stamp.Time >= s.Start {
				return out, fmt.Errorf("前史が当場へ侵入")
			}
			if err = bank.Add(pub); err != nil {
				return out, err
			}
		}
	}
	if err = bank.StartSession(s.Session, s.Contract); err != nil {
		return out, err
	}
	detector := birth.NewDetector()
	if err = detector.StartSession(s.Session, s.Contract); err != nil {
		return out, err
	}
	f, e := os.Open(s.Raw.Path)
	if e != nil {
		return out, e
	}
	defer f.Close()
	before, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.Before = FileStat{Bytes: before.Size(), ModTimeNS: before.ModTime().UnixNano()}
	hash := sha256.New()
	tee := io.TeeReader(f, hash)
	z, encoding, e := rawStream133(tee)
	if e != nil {
		return out, e
	}
	defer z.Close()
	out.RawEncoding = encoding
	scan := bufio.NewScanner(z)
	scan.Buffer(make([]byte, 65536), 8*1024*1024)
	scene := Scene{Session: s.Session, Contract: s.Contract, Start: s.Start, End: s.End, Raw: s.Raw}
	previous := s.Start
	var index int64
	pi := 0
	contracts := map[string]bool{}
	seen := map[string]bool{}
	pending := []*Candidate133{}
	covered := map[string]bool{}
	window := &Window133{}
	for scan.Scan() {
		out.Quality.Lines++
		q, _, next, e := decodeRow(scan.Bytes(), out.Quality.Lines, index, scene, previous, &out.Quality, contracts)
		previous = next
		if e != nil {
			return out, e
		}
		if q == nil {
			continue
		}
		index++
		for pi < len(s.Publications) && int64(s.Publications[pi].Stamp.Index) <= q.Index {
			pub := s.Publications[pi]
			if int64(pub.Stamp.Index) != q.Index || int64(pub.Stamp.Line) != q.SourceLine || pub.Stamp.Time != q.Time {
				return out, fmt.Errorf("公表実配送行差")
			}
			if err = bank.Add(pub); err != nil {
				return out, err
			}
			window.observe(pub)
			pi++
		}
		events, e := detector.Observe(bank, quote133(*q))
		if e != nil {
			return out, e
		}
		e0Born := map[string]bool{}
		for _, event := range events {
			if event.Policy != "E0" {
				continue
			}
			if seen[event.ID] {
				return out, fmt.Errorf("イベントID重複")
			}
			seen[event.ID] = true
			eventIndex := len(out.Events)
			out.Events = append(out.Events, event)
			for _, policy := range Policies133 {
				c, e := new133(event, *q, eventIndex, s)
				if e != nil {
					return out, e
				}
				c.Policy = policy
				snap, err := bank.Current(quote133(*q))
				if err != nil {
					return out, err
				}
				c.Direction, err = direction133(c.Birth.Side, c.Path, snap)
				if err != nil {
					return out, err
				}
				out.Candidates = append(out.Candidates, c)
				if c.Status == "pending" {
					pending = append(pending, c)
					e0Born[policy] = true
				}
			}
		}
		// ----------------------------------------
		// 同RawのE0要求・取得を、補完要求の取消しと取得より先に評価する。
		var newFills []*Candidate133
		pending, newFills = processPending133(pending, *q, s.ForceClose, covered, e0Born)
		_ = newFills
		// ----------------------------------------
		// 未取得の政策だけで当時の技術票を評価し、注文後に方向を変えない。
		var decision *Decision133
		for _, policy := range Policies133[1:] {
			if covered[policy] || hasPending133(pending, policy) || q.Time >= s.ForceClose {
				continue
			}
			if decision == nil {
				d, e := score133(bank, *q, window)
				if e != nil {
					return out, e
				}
				decision = &d
			}
			d := *decision
			stats := out.Participation[policy]
			stats.ScoreChecks++
			if !d.Eligible {
				unavailable133(stats, d)
				continue
			}
			path := "deadline"
			if q.Time < deadlineAt133(policy, s) {
				strong, ok := strong133(d)
				if !ok {
					stats.StrongDenied++
					continue
				}
				d = strong
				path = "strong"
			} else if d.Side == 0 {
				unavailable133(stats, d)
				continue
			}
			c := supplement133(policy, path, d, *q, s)
			snap, err := bank.Current(quote133(*q))
			if err != nil {
				return out, err
			}
			c.Direction, err = direction133(c.Birth.Side, c.Path, snap)
			if err != nil {
				return out, err
			}
			out.Candidates = append(out.Candidates, c)
			pending = append(pending, c)
			stats.Requests++
		}

	}
	if e = scan.Err(); e != nil {
		return out, e
	}
	if _, e = io.Copy(io.Discard, tee); e != nil {
		return out, e
	}
	after, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.After = FileStat{Bytes: after.Size(), ModTimeNS: after.ModTime().UnixNano()}
	out.ActualSHA = hex.EncodeToString(hash.Sum(nil))
	if out.ActualSHA != s.Raw.SHA256 || out.Before != out.After {
		return out, fmt.Errorf("Raw SHA/stat差")
	}
	if len(contracts) != 1 || !contracts[s.Contract] || index != s.ExpectedAccepted || pi != len(s.Publications) {
		return out, fmt.Errorf("限月/全採用数/公表配送数差")
	}
	if s.ExpectedQuality != nil && out.Quality != *s.ExpectedQuality {
		return out, fmt.Errorf("全行品質metadata差")
	}
	for _, c := range pending {
		c.Status = "eof_unfilled"
	}

	for _, policy := range Policies133 {
		count, supplements := 0, 0
		for _, c := range out.Candidates {
			if c.Policy != policy {
				continue
			}
			if c.Path == "E0" {
				count++
			} else if c.Entry != nil {
				supplements++
			}
		}
		if count != len(out.Events) || supplements > 1 {
			return out, fmt.Errorf("E0保持又は補完1取得上限の差")
		}
	}
	out.DetectorStats = detector.Stats()
	out.Publications = pi
	out.SourceForceClose = sourceForce
	out.EntryCutoff = s.ForceClose
	out.ExecutionEnd = s.End - 300
	out.FallbackAt = map[string]float64{"L0": deadlineAt133("L0", s), "L1": deadlineAt133("L1", s)}
	out.Coverage = map[string]bool{}
	for _, p := range Policies133[1:] {
		out.Coverage[p] = covered[p]
	}
	out.Success = true
	return out, nil
}
