# 118入口比較のCSV出力

Rootが確定したJSONの`tables`二表を転記する。**独立1miniの入口試験の期限評価**であり、片側10枚の運用口座収支に合算しない。金額・率・分母・打切りの意味は入力表の定義を保ち、この出力器で金融計算を追加しない。

入力は`{tables:[{name,headers,rows},...]}`。表名は`候補別集計`と`全候補明細`、セルは文字列・有限数値・boolean・null。行列数を検査し、行順・列順・値を維持する。安全整数範囲外は拒否する。

Node 24.22.1、artifact-tool 2.8.129を使用。`node_modules`は既存runtimeの依存先へのjunctionで、依存自体は変更しない。今回はJS/Pythonの構文確認だけで、手製Workbook・自然CSV・markerはまだ作成/実行していない。

## Rootによる自然出力

JSONとSHA256を確定してから、**自然first authoringの直前にRootがcreate/2/csv markerを一度だけ実行**する。同じ操作の再試行ではmarkerを重ねない。builderと再読器はmarkerを自動実行しない。

```powershell
$nodeExe = 'C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
& $nodeExe 'C:/Users/masay/.codex/plugins/cache/openai-primary-runtime/spreadsheets/26.1104.22356/skills/spreadsheets/container_tools/mark_artifact_operation_started.mjs' --operation-kind create --expected-output-count 2 --output-format csv
& $nodeExe 'work/118入口CSV出力/出力する.mjs' --input 'Rootの確定表.json' --sha256 '64桁SHA256' --output 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/118入口比較CSV'
python -X utf8 'work/118入口CSV出力/CSVを独立再読する.py' --input 'Rootの確定表.json' --sha256 '64桁SHA256' --folder 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/118入口比較CSV' --output 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/118入口比較CSV/CSVの独立再読.json'
```

JSON以外の自然結果・Raw・Native・価格CSVは開かない。出力先は未作成必須で、既存ファイルを上書きしない。失敗時の不完了出力を成功扱いしない。

## 出力と確認

- `候補別集計.csv`、`全候補明細.csv`の二点。UTF-8 BOM・CRLF。nullは空欄、数値0は`0`、booleanは小文字`true`/`false`。文字の先頭0・改行・引用符も元の値で保持する。
- Workbookへ型付きで投入し、再計算、二表inspect、数式エラー走査、ヘッダを含む全セルの型/値比較を終えてからCSVを保存する。所与の数値を再集計する数式やxlsxは作らない。入力自体に`#N/A`等の文字列があれば、同じ文字として保持し検査数を記録する。
- `支援画像/候補別集計.png`、`支援画像/全候補明細.png`は各表のA1:H5以内。Rootが自然作成後に視認してQAする。現段階の視認成功は主張しない。
- `CSVの確認.json`へ入力SHA/前後不変、出力SHA/行列数、全セル数、エラー走査、依存版を保存する。
- 独立再読は標準`csv`と`Decimal`。数値は完全一致（許容差なし）、文字列exact、nullと数値0を分け、JSON・二CSVの前後SHAを確認する。未定義率を0へ置き換えない。

CSVは型情報を持たないため、nullと空文字は共に空欄となりCSV単体では区別不能。照合時は元JSONの型を使う。文字の先頭0などを表計算ソフトで保つ場合は文字列列として読み込む。
