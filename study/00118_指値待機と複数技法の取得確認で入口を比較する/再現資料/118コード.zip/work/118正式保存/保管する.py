"""既存の118結果とコードを認証し、再実行せず正式保存する。"""
from pathlib import Path
import gzip
import hashlib
import io
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / 'work/118入口比較'
TRIAL = ROOT / 'study/00118_指値待機と複数技法の取得確認で入口を比較する'


def sha(data: bytes) -> str:
    """
    機能: バイト列の保存指紋を求める。
    引数: data(bytes)は検査する全バイト列。
    返り値: strはSHA256の小文字16進値。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def save(path: Path, data: bytes) -> dict:
    """
    機能: 既存の同体を認証するか新規ファイルへ保存する。
    引数: path(Path)は正式保存先、data(bytes)は内容。
    返り値: dictは相対path・サイズ・SHA256。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, str(path)
    else:
        path.write_bytes(data)
    assert path.read_bytes() == data
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data), 'sha256': sha(data)}


# ----------------------------------------
def main() -> None:
    """
    機能: 結果gzip、元コードZIP、検査記録を同体確認して保存する。
    引数: なし。既存118成果・コードだけを使用する。
    返り値: None。金融計算・Raw・Native・11/09の読込を行わない。
    """
    expected = {
        'F1.json': '57295a629a3a54df04385597ec25329f1254692e01db4072fd5d295364b0ebfc',
        '全70場の完了.json': 'dca8ac525a4a41e1194fb9515ed591ecec3e5f22121fa04724e26b8376fd39eb',
        '全70場の入口結果.json': 'c8f40fd2192a94c85867e6de901d43a46deff27c73a02fa8416abd4a779e3382',
        '集計.json': '64eda52d1f8a75775b1a80ae64de0409aa14a9f8a410915e96995f3aa41801f1',
        '独立検算.json': 'e5cb7f5b8b3e6ab90a897d20c209a02bbdc8dce2a4b41065e68fb6e41d908cc4',
    }
    contents = {name: (WORK / name).read_bytes() for name in expected}
    assert all(sha(contents[name]) == wanted for name, wanted in expected.items())
    fixed = json.loads(contents['F1.json'])
    assert all(sha(Path(path).read_bytes()) == wanted for path, wanted in fixed['code_sha256'].items())
    assert sha((TRIAL / '実行前原文/README.md').read_bytes()) == fixed['README_sha256']
    assert sha((TRIAL / '実行前原文/設定と結果.md').read_bytes()) == fixed['table_sha256']
    refs = []
    refs.append(save(TRIAL / '成果物/集計.json', contents['集計.json']))
    for name in ('F1.json', '全70場の完了.json', '独立検算.json'):
        refs.append(save(TRIAL / '検査' / name, contents[name]))
    for source, name in (
        ('work/118複数技法の入口条件/検査/確認.json', '技術条件の人工検査.json'),
        ('work/118入口CSV出力/準備の確認.json', 'CSV器の準備.json'),
        ('work/118入口CSV出力/全70独立再読.json', 'CSVの独立再読.json'),
        ('outputs/01a1889f-f2af-7943-a047-543275ee9ed2/118入口比較CSV/CSVの確認.json', 'CSVの生成確認.json'),
    ):
        refs.append(save(TRIAL / '検査' / name, (ROOT / source).read_bytes()))
    raw = contents['全70場の入口結果.json']
    buffer = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=buffer, mtime=0, compresslevel=9) as stream:
        stream.write(raw)
    packed = buffer.getvalue()
    assert gzip.decompress(packed) == raw
    result_ref = save(TRIAL / '成果物/全70場の入口結果.json.gz', packed)
    result_ref['展開後bytes'] = len(raw)
    result_ref['展開後SHA256'] = sha(raw)
    refs.append(result_ref)

    # ----------------------------------------
    paths = {Path(path) for path in fixed['code_sha256']}
    paths.update(WORK / name for name in ('集計する.py', '独立検算する.py', '実行する.py', '表と条件を固定する.py'))
    paths.update((ROOT / 'work/118複数技法の入口条件').glob('README.md'))
    paths.update((ROOT / 'work/118入口CSV出力' / name) for name in ('出力する.mjs', 'CSVを独立再読する.py', 'README.md'))
    paths.add(Path(__file__).resolve())
    entries = []
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
        for path in sorted(paths):
            data = path.read_bytes()
            relative = path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            stream.writestr(info, data, compresslevel=9)
            entries.append({'entry': relative, 'restore_relative': relative, 'bytes': len(data), 'sha256': sha(data)})
    zipped = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(zipped)) as stream:
        assert stream.testzip() is None
        assert set(stream.namelist()) == {row['entry'] for row in entries}
        for row in entries:
            data = stream.read(row['entry'])
            assert sha(data) == row['sha256'] and len(data) == row['bytes']
    zip_ref = save(TRIAL / '再現資料/118コード.zip', zipped)
    refs.append(zip_ref)
    index = {'試行': 118, '成功': True, 'zip': zip_ref, 'restore_root': str(ROOT), 'entries': entries, '依存': {'Go': '1.24.2 windows/amd64', 'Python': '3.14.3', 'Node': '24.22.1', 'artifact_tool': '2.8.129'}, '実行物は同梱しない': fixed['executable'], '入力は同梱しない': fixed['input'], '原板Nativeは同梱しない': True}
    refs.append(save(TRIAL / '再現資料/コード復元索引.json', (json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode('utf-8')))
    assert all((WORK / name).read_bytes() == contents[name] for name in expected)
    proof = {'試行': 118, '成功': True, '保存対象': refs, '金融再実行': False, '金融再集計': False, 'Raw読取': 0, 'Native読取': 0, '11月09読取': False, '結果gzipの全bytes復元一致': True, 'コードZIP全entrySHAサイズCRC一致': True, '元正本前後不変': True, '入力RawNative実行物の重複保存': False, '保管器SHA256': sha(Path(__file__).read_bytes())}
    save(TRIAL / '検査/保管の確認.json', (json.dumps(proof, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'成功': True, '結果gzip': result_ref, 'コードZIP': zip_ref, 'code_entries': len(entries)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
