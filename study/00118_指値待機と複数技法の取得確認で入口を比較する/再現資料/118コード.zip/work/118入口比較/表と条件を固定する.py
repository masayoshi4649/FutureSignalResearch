"""118の教材全表と入口条件を結果計算前に固定する。"""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
STUDY = ROOT / 'study/00118_指値待機と複数技法の取得確認で入口を比較する'


def sha(path: Path) -> str:
    """
    機能: 明示された固定条件・コードの全bytes指紋を作る。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 汎用表504セルを保持して設定・7候補を記入し、実行前F1へ結ぶ。
    引数: なし。返り値: None。結果・Rawを読まない。
    """
    source = ROOT / 'docs/議論/手法と時間スケールの汎用表_版6.md'
    text = source.read_text(encoding='utf-8')
    table = text.split('## 設定明細')[0]
    table = table.replace('# 手法と時間スケールの汎用表・版6', '# 00118：設定と結果（汎用表・版6）', 1)
    table = table.replace('未設定・未検証', '追加未使用')
    selected = {'I01': {5: 'S03/TtrendのEMA21帯', 7: 'S03/Ttrendの配置・傾き'}, 'I03': {5: 'S05/順側又は改善'}, 'I04': {5: 'S05/水準・改善', 6: 'S04/過熱帯'}, 'I05': {6: 'S04/BB20±2σ'}, 'I08': {6: 'S03/DI方向・ADX20', 7: 'S04/ADX25又は低下'}, 'I09': {5: 'S07/TR≤前ATR×2・帯幅'}, 'V01': {5: 'S08/RVOL前20量'}, 'P02': {5: 'S05/後形成5分高安奪還'}, 'P05': {2: 'S02/固定50・100・200pt'}, 'X04': {2: 'S11/ラージ気配代用'}, 'C07': {5: 'S03〜05', 6: 'S03〜05', 7: 'S03〜05'}}
    lines = table.splitlines()
    for index, line in enumerate(lines):
        if not line.startswith('| '):
            continue
        cells = [c.strip() for c in line.strip('|').split('|')]
        if cells[0] in selected:
            for column, setting in selected[cells[0]].items():
                cells[column] = setting + '・判定予定（未実行）'
            lines[index] = '| ' + ' | '.join(cells) + ' |'
    table = '\n'.join(lines)
    def link(match):
        """
        機能: 元教材リンクを新試行からの相対参照へ変換する。
        引数: match(re.Match)。返り値: strは書換えたMarkdownリンク。
        """
        target = match.group(1)
        if '://' in target or target.startswith('#'):
            return match.group(0)
        body, sep, anchor = target.partition('#')
        converted = os.path.relpath((source.parent / body).resolve(), STUDY).replace('\\', '/')
        return '](' + converted + (sep + anchor if sep else '') + ')'
    table = re.sub(r'\]\(([^)]+)\)', link, table)
    settings = [
        ('S01','Source新規・原行','元方向候補','固定Source111の全mini新規558','通知Index/時刻以降のみ','全R','母集団558・結果未実行'),
        ('S02','P05・原板','価格位置','通知時Ask/Bid=P0固定','L=P0−side×50/100/200','R02〜04','未実行'),
        ('S03','I01/I08・5/15/30分','順行背景/押戻し','EMA8/21、DI/ADX14、ATR14','30分配置/両傾き順側、DI15順側、ADX15≥20、5分EMA21帯−1〜+.25ATR','R05/R07','未実行'),
        ('S04','I05/I04/I08・15/30分','反転領域','BB15終値20本±2母σ、RSI14、ADX14','ADX30≤25又は低下、逆側BB外、s(RSI15−50)≤−15','R06/R07','未実行'),
        ('S05','P02/I03/I04・5分/Raw','確認イベント','zone後RawかつEnd>zone時刻の確定5分足','高安strict奪還、trend Hist順側・RSI中立〜70/30、rev Hist/RSI順側改善','R05〜07','未実行'),
        ('S06','T01・公表時計','未知/前史','115確定公表・同限月数値窓のみcarry','当場3足fresh、Delivery/Index以前、未知は支持にしない','R05〜07','未実行'),
        ('S07','I09・5分','急伸回避','当TR/前ATR','TR≤2前ATR、ATR>0','R05〜07','未実行'),
        ('S08','V01・5分','量','当足観測量÷直前20本平均','trend≥.8、reversal≥1、未知/0分母はunknown','R05〜07','未実行'),
        ('S09','P05/T01・原板','固定観測','新規後30/60分、正常返済BBO','順逆25/50/100/125/200pt、等号到達、期限内先着','全R','未実行'),
        ('S10','期限清算評価','入口単独費用後評価','1mini=100円/pt、往復77円','期限後30秒内正常BBO、追加往復滑り0/10ptを費用化','全R','運用口座収支ではない'),
        ('S11','X04・原板','執行代用','全後Raw+1秒、買Ask/売Bid','指値は反対気配10pt通過、指値価格記帳、15分TTL/確認後30秒','全R','miniキュー未証明'),
        ('S12','観測品質','打切り','Raw又は正常BBOの300秒超欠測・場末・期限不足','損益0補完なし、未約定と未知は分離','全R','未実行'),
    ]
    table += '\n\n追加未使用は研究側の追加入口についてであり、固定Source内部の全技法対応を監査したという意味ではない。\n\n## 設定明細\n\n|設定ID|手法ID・尺度|役割|計算・入力|閾値|候補|状態|\n|---|---|---|---|---|---|---|\n'
    table += '\n'.join('| ' + ' | '.join(row) + ' |' for row in settings)
    policies = ['M0','L50','L100','L200','Ttrend','Treversal','Thybrid']
    table += '\n\n## 複合条件と結果\n\n|評価ID|候補|設定|分母と結果|費用・限界|\n|---|---|---|---|---|\n'
    for i, policy in enumerate(policies,1):
        ids = 'S01/S02/S09〜12' if i < 5 else 'S01/S03〜12'
        table += f'|R{i:02}|{policy}|{ids}|558出生、結果未実行|独立1mini、未約定を0円にしない。30/60分・C0/C5別。|\n'
    target = STUDY / '設定と結果.md'
    with target.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(table + '\n')
    code_paths = list(OWN.glob('*.go')) + [OWN/'go.mod',OWN/'cmd/run/main.go',OWN/'入力を準備する.py'] + list((ROOT/'work/118複数技法の入口条件').glob('*.go')) + [ROOT/'work/118複数技法の入口条件/go.mod']
    input_path = OWN/'入力.json'
    assert sha(input_path) == '574771f654937036b48c78eceadb46a4c5ff3c10265f60b0ec7879efb0d862c3'
    definition = {'trial':118,'fixed':True,'policies':policies,'independent_mini_quantity':1,'source_births':558,'horizons_seconds':[1800,3600],'widths_points':[25,50,100,125,200],'source_cancel_priority':True,'source_paper_close_cancel':False,'pending_seconds':900,'technical_order_seconds':30,'delay_seconds':1,'limit_opposite_bbo_cross_points':10,'technical_price_improvement_points':50,'normal_bbo_gap_seconds':300,'endpoint_grace_seconds':30,'fee_round_yen':77,'slip_stress_round_yen':[0,1000],'input':{'path':str(input_path),'sha256':sha(input_path)},'code_sha256':{str(p):sha(p) for p in code_paths},'executable':{'path':str(OWN/'入口比較.exe'),'sha256':sha(OWN/'入口比較.exe')},'README_sha256':sha(STUDY/'README.md'),'table_sha256':sha(target),'new_result_read':False,'11月09読取':False,'portfolio_pnl':False,'Go_version':subprocess.check_output(['go','version'],text=True).strip()}
    fixed = OWN/'F1.json'
    with fixed.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(definition,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'表SHA256':sha(target),'F1_SHA256':sha(fixed),'コード数':len(code_paths)},ensure_ascii=False))


if __name__=='__main__':
    main()
