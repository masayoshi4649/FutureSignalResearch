"""独立入口試験を集計し、運用口座収支と区別した閲覧表を作る。"""
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from statistics import mean, median
import hashlib
import json

OWN = Path(__file__).resolve().parent
JST = timezone(timedelta(hours=9))


def jst(value: float | None) -> str | None:
    """
    機能: 価格時計をJSTの読み取り用文字列へ変換する。
    引数: value(float|None)。返り値: str|None。受信時計ではない。
    """
    return None if value is None else datetime.fromtimestamp(value, JST).strftime('%Y-%m-%d %H:%M:%S')


def avg(values: list) -> float | None:
    """
    機能: 空集団の平均を0へ補完せず求める。
    引数: values(list[number])。返り値: float|None。
    """
    return mean(values) if values else None


def validate(candidate: dict) -> int:
    """
    機能: 指値/遅延/価格・期限評価の数式と保存証拠を独立に照合する。
    引数: candidate(dict)。返り値: intは検算した期限評価数。Raw初回性を再走査しない。
    """
    c = candidate
    if c['entry'] is None:
        assert c['entry_price'] is None and c['outcomes'] == [] and c['status'] != 'filled'
        return 0
    q, request, s = c['entry'], c['request'], c['birth']['side']
    assert c['status'] == 'filled' and q['quote_ok'] and 0 < q['bid'] < q['ask']
    assert q['index'] > request['index'] and q['source_line'] > request['source_line'] and q['time'] >= request['time'] + 1
    assert q['time'] < c['expires']
    if c['policy'] == 'M0':
        assert c['entry_price'] == (q['ask'] if s == 1 else q['bid'])
    else:
        assert c['entry_price'] == c['limit'] and s * ((q['ask'] if s == 1 else q['bid']) - c['limit']) <= -10
        if c['policy'].startswith('T'):
            assert c['limit'] == c['p0'] - s * 50 and c['technical']['truth'] == 2
            t = c['technical']['at']
            assert (t['time'], t['index'], t['source_line']) == (request['time'], request['index'], request['source_line'])
            for ref in c['technical']['snapshotrefs']:
                assert ref['end'] <= request['time'] and ref['delivered']['time'] <= request['time'] and ref['delivered']['index'] <= request['index'] and ref['delivered']['source_line'] <= request['source_line']
    count = 0
    assert [o['seconds'] for o in c['outcomes']] == [1800, 3600]
    for o in c['outcomes']:
        assert o['deadline'] == q['time'] + o['seconds']
        for t in o['touches']:
            assert t['direction'] in (-1, 0, 1)
            if t['direction'] == 0:
                assert t['quote'] is None
            else:
                point = t['quote']
                assert point['index'] > q['index'] and q['time'] <= point['time'] <= o['deadline']
                mark = point['bid'] if s == 1 else point['ask']
                assert t['direction'] * s * (mark - c['entry_price']) >= t['width']
        if o['status'] == 'complete':
            e = o['endpoint']
            assert o['deadline'] <= e['time'] <= o['deadline'] + 30 and e['quote_ok'] and 0 < e['bid'] < e['ask']
            g = s * ((e['bid'] if s == 1 else e['ask']) - c['entry_price'])
            assert (o['points'], o['net0'], o['net5']) == (g, 100 * g - 77, 100 * g - 1077)
            count += 1
        else:
            assert all(o[k] is None for k in ('endpoint', 'points', 'net0', 'net5'))
    return count


def stats(candidates: list, seconds: int, baseline: dict) -> dict:
    """
    機能: 全出生、実約定代用、観測完了と同出生の対照を区別して集計する。
    引数: candidates(list)、seconds(int)、baseline(dict)。返り値: dictは件数と平均評価。
    """
    entered = [c for c in candidates if c['entry'] is not None]
    complete = [(c, next(o for o in c['outcomes'] if o['seconds'] == seconds)) for c in entered]
    complete = [(c, o) for c, o in complete if o['status'] == 'complete']
    n0, n5 = [o['net0'] for _, o in complete], [o['net5'] for _, o in complete]
    pairs = []
    for c, o in complete:
        b = baseline[(c['session'], c['birth']['method'], c['birth']['id'])]
        if b['entry'] is None:
            continue
        other = next(x for x in b['outcomes'] if x['seconds'] == seconds)
        if other['status'] == 'complete':
            pairs.append({'delta': o['net5'] - other['net5'], 'baseline': other['net5'], 'candidate': o['net5'], 'entry_improvement': c['birth']['side'] * (b['entry_price'] - c['entry_price'])})
    touches = {}
    for width in (25, 50, 100, 125, 200):
        counts = Counter(next(t['direction'] for t in o['touches'] if t['width'] == width) for _, o in complete)
        touches[str(width)] = {'favorable': counts[1], 'adverse': counts[-1], 'neither': counts[0], 'resolved_rate': counts[1] / (counts[1] + counts[-1]) if counts[1] + counts[-1] else None}
    return {'births': len(candidates), 'requested': sum(c['request'] is not None for c in candidates), 'filled': len(entered), 'complete': len(complete), 'censored': len(entered) - len(complete), 'states': dict(Counter(c['status'] for c in candidates)), 'observations': dict(Counter(o['status'] for c in entered for o in c['outcomes'] if o['seconds'] == seconds)), 'tech_ever_true': sum(c['true_evaluations'] > 0 for c in candidates), 'tech_cap_denied': sum(c['cap_denied_evaluations'] > 0 for c in candidates), 'unknown_only': sum(c['unknown_evaluations'] > 0 and c['known_evaluations'] == 0 for c in candidates), 'touches': touches, 'mean_net0': avg(n0), 'mean_net5': avg(n5), 'median_net5': median(n5) if n5 else None, 'positive_net5': sum(v > 0 for v in n5), 'negative_net5': sum(v < 0 for v in n5), 'zero_net5': sum(v == 0 for v in n5), 'pairs': len(pairs), 'paired_baseline_mean_net5': avg([p['baseline'] for p in pairs]), 'paired_candidate_mean_net5': avg([p['candidate'] for p in pairs]), 'paired_mean_delta': avg([p['delta'] for p in pairs]), 'paired_median_delta': median([p['delta'] for p in pairs]) if pairs else None, 'paired_mean_entry_improvement': avg([p['entry_improvement'] for p in pairs])}


def label(c: dict, outcome: dict | None, width: int) -> str:
    """
    機能: 未約定・観測不足・未到達を別の文字列へ変換する。
    引数: c/outcome(dict|None)、width(int)。返り値: str。
    """
    if outcome is None:
        return '対象外（未約定）'
    t = next(t for t in outcome['touches'] if t['width'] == width)
    if outcome['status'] != 'complete':
        return '打切前順行' if t['direction'] == 1 else '打切前逆行' if t['direction'] == -1 else '観測不足'
    return '順行先着' if t['direction'] == 1 else '逆行先着' if t['direction'] == -1 else '両方未到達'


def main() -> None:
    """
    機能: 全70結果を検算して14集計と7812明細を作る。
    引数: なし。返り値: None。新候補の追加・閾値の変更をしない。
    """
    raw_path = OWN / '全70場の入口結果.json'
    value = json.loads(raw_path.read_text(encoding='utf-8'))
    assert value['success'] and value['trial'] == 118 and len(value['scenes']) == 70
    rows = []
    for index, scene in enumerate(value['scenes']):
        assert scene['success']
        for c in scene['candidates']:
            c['session'] = scene['session']
            c['history'] = '元54場' if index < 54 else '追加16場'
            rows.append(c)
    assert len(rows) == 558 * 7
    checked = sum(validate(c) for c in rows)
    baseline = {(c['session'], c['birth']['method'], c['birth']['id']): c for c in rows if c['policy'] == 'M0'}
    assert len(baseline) == 558
    aggregate = {}
    for p in value['policies']:
        subset = [c for c in rows if c['policy'] == p]
        assert len(subset) == 558
        aggregate[p] = {str(h): stats(subset, h, baseline) for h in (1800, 3600)}
    groups = {}
    for group, values in (('side', (-1, 1)), ('history', ('元54場', '追加16場')), ('method', sorted({c['birth']['method'] for c in rows}))):
        groups[group] = {}
        for v in values:
            subset = [c for c in rows if (c['birth'][group] if group in ('side', 'method') else c[group]) == v]
            groups[group][str(v)] = {p: {str(h): stats([c for c in subset if c['policy'] == p], h, baseline) for h in (1800, 3600)} for p in value['policies']}
    result = {'試行': 118, '成功': True, '元結果SHA256': hashlib.sha256(raw_path.read_bytes()).hexdigest(), '独立期限算術検査数': checked, '集計': aggregate, '群別': groups, '口座収支': False, '独立1miniの期限評価': True, '未約定0円補完': False, '全Rawの別再走査': False}
    with (OWN / '集計.json').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    headers = ['試行','候補','評価時間分','全出生','要求数','約定代用数','評価完了数','観測不足数','技術成立候補数','価格cap拒否候補数','技術未知のみ候補数','25pt順行先着','25pt逆行先着','25pt未到達','50pt順行先着','50pt逆行先着','50pt未到達','100pt順行先着','100pt逆行先着','100pt未到達','125pt順行先着','125pt逆行先着','125pt未到達','200pt順行先着','200pt逆行先着','200pt未到達','C0期限評価平均円','C5期限評価平均円','C5期限評価中央値円','C5正評価数','C5負評価数','同出生対照完了組数','同組M0のC5平均円','同組候補のC5平均円','同組C5平均差円','同組C5中央値差円','同組取得価格平均改善pt']
    summary = []
    for p in value['policies']:
        for h in (1800,3600):
            s = aggregate[p][str(h)]
            touches = [s['touches'][str(w)][k] for w in (25,50,100,125,200) for k in ('favorable','adverse','neither')]
            summary.append([118,p,h/60,s['births'],s['requested'],s['filled'],s['complete'],s['censored'],s['tech_ever_true'],s['tech_cap_denied'],s['unknown_only'],*touches,s['mean_net0'],s['mean_net5'],s['median_net5'],s['positive_net5'],s['negative_net5'],s['pairs'],s['paired_baseline_mean_net5'],s['paired_candidate_mean_net5'],s['paired_mean_delta'],s['paired_median_delta'],s['paired_mean_entry_improvement']])
    detail_headers = ['試行','セッション','期間区分','元手法','出生ID','方向','候補','評価時間分','新規状態','出生JST','出生側気配P0','注文要求JST','指値','約定代用JST','新規価格','観測状態','評価期限JST','期限評価原行JST','期限価格差pt','C0期限清算評価円','C5期限清算評価円','25pt先着','50pt先着','100pt先着','125pt先着','200pt先着','旧S0受理対応','旧S0取得対応']
    details = []
    for c in rows:
        for h in (1800,3600):
            o = next((x for x in c['outcomes'] if x['seconds']==h),None)
            details.append([118,c['session'],c['history'],c['birth']['method'],c['birth']['id'],'買' if c['birth']['side']==1 else '売',c['policy'],h/60,c['status'],jst(c['birth']['time']),c['p0'],jst(c['request']['time']) if c['request'] else None,c['limit'],jst(c['entry']['time']) if c['entry'] else None,c['entry_price'],o['status'] if o else 'not_entered',jst(o['deadline']) if o else None,jst(o['endpoint']['time']) if o and o['endpoint'] else None,o['points'] if o else None,o['net0'] if o else None,o['net5'] if o else None,*[label(c,o,w) for w in (25,50,100,125,200)],'有' if c['birth']['accepted_s0'] else '無','有' if c['birth']['filled_s0'] else '無'])
    assert len(summary)==14 and len(details)==7812 and all(len(r)==len(headers) for r in summary) and all(len(r)==len(detail_headers) for r in details)
    tables = {'試行':118,'成功':True,'result_sha256':result['元結果SHA256'],'意味':'独立1miniの入口評価。実運用口座収支ではない。C5は往復手数料77円＋往復10pt追加費用。','tables':[{'name':'候補別集計','headers':headers,'rows':summary},{'name':'全候補明細','headers':detail_headers,'rows':details}]}
    with (OWN / 'CSV用の表.json').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(tables,ensure_ascii=False,indent=2)+'\n')
    short={p:{k:aggregate[p]['3600'][k] for k in ('births','filled','complete','censored','tech_ever_true','tech_cap_denied','unknown_only','mean_net0','mean_net5','median_net5','pairs','paired_baseline_mean_net5','paired_mean_delta')}|{'100pt':aggregate[p]['3600']['touches']['100']} for p in value['policies']}
    print(json.dumps({'成功':True,'期限評価検算':checked,'60分':short},ensure_ascii=False))


if __name__ == '__main__':
    main()
