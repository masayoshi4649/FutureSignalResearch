package main

import (
	entry "entrycomparison118"
	"flag"
	"fmt"
	"os"
)

// main は固定した118の入口試験を新規結果へ実行します。
//
// 引数: CLI input/sha256/output(string)、workers(int)。返り値: ありません。
func main() {
	p := flag.String("input", "", "固定入力")
	s := flag.String("sha256", "", "入力SHA")
	o := flag.String("output", "", "新規結果")
	w := flag.Int("workers", 8, "場並列")
	flag.Parse()
	if err := entry.Run118(*p, *s, *o, *w); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
