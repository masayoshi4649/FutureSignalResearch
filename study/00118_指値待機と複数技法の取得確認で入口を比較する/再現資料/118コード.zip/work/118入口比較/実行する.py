"""結果計算前に固定した118条件とコードを認証して実行する。"""
from pathlib import Path
import hashlib
import json
import subprocess

OWN = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 固定コード・結果の全bytes指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 固定前後同体の70場入口比較を新規結果へ実行する。
    引数: なし。返り値: None。固定後に閾値を選び直さない。
    """
    fixed = OWN / 'F1.json'
    assert sha(fixed) == '57295a629a3a54df04385597ec25329f1254692e01db4072fd5d295364b0ebfc'
    condition = json.loads(fixed.read_text(encoding='utf-8'))
    assert condition['fixed'] and condition['trial'] == 118
    before = dict(condition['code_sha256'])
    before[condition['input']['path']] = condition['input']['sha256']
    before[condition['executable']['path']] = condition['executable']['sha256']
    assert all(sha(Path(p)) == expected for p, expected in before.items())
    output = OWN / '全70場の入口結果.json'
    assert not output.exists()
    command = [condition['executable']['path'], '--input', condition['input']['path'], '--sha256', condition['input']['sha256'], '--output', str(output), '--workers', '8']
    result = subprocess.run(command, cwd=OWN, check=False)
    assert result.returncode == 0, '入口比較の失敗を完了扱いしない'
    after = {p: sha(Path(p)) for p in before}
    assert after == before
    value = json.loads(output.read_text(encoding='utf-8'))
    assert value['success'] and value['trial'] == 118 and value['input_sha256'] == condition['input']['sha256']
    assert len(value['scenes']) == 70 and all(s['success'] for s in value['scenes'])
    assert sum(len(s['candidates']) for s in value['scenes']) == 558 * 7
    proof = {'試行': 118, '成功': True, 'F1_SHA256': sha(fixed), '入力コード前SHA256': before, '入力コード後SHA256': after, '前後不変': True, '場数': 70, '候補出生数': 558, '政策別候補数': 3906, '結果': {'path': str(output), 'sha256': sha(output)}, '単位': '独立1mini入口試験、口座収支ではない', 'コマンド': command, '条件変更': False, '11月09読取': False}
    with (OWN / '全70場の完了.json').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'成功': True, '結果SHA256': sha(output), '完了SHA256': sha(OWN / '全70場の完了.json')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
