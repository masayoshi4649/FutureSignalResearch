package holdingohlc113

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"io"
	"math"
	"os"
	"sort"
	"sync"
)

var Policies118 = []string{"M0", "L50", "L100", "L200", "Ttrend", "Treversal", "Thybrid"}
var Widths118 = []float64{25, 50, 100, 125, 200}
var Horizons118 = []float64{1800, 3600}

type Signal118 struct {
	ID         string  `json:"id"`
	Method     string  `json:"method"`
	Side       int     `json:"side"`
	Time       float64 `json:"time"`
	Index      int64   `json:"index"`
	Line       int64   `json:"source_line"`
	Quote      Quote   `json:"quote"`
	AcceptedS0 bool    `json:"accepted_s0"`
	FilledS0   bool    `json:"filled_s0"`
}
type Cancel118 struct {
	SignalID string  `json:"signal_id"`
	Method   string  `json:"method"`
	Time     float64 `json:"time"`
	Index    int64   `json:"index"`
	Line     int64   `json:"source_line"`
	Quote    Quote   `json:"quote"`
}
type Scene118 struct {
	Session          string              `json:"session"`
	Contract         string              `json:"contract"`
	Start            float64             `json:"start"`
	End              float64             `json:"end"`
	ForceClose       float64             `json:"force_close"`
	Raw              FileRef             `json:"raw"`
	ExpectedAccepted int64               `json:"expected_accepted"`
	Publications     []rules.Publication `json:"publications"`
	Signals          []Signal118         `json:"signals"`
	Cancellations    []Cancel118         `json:"cancellations"`
}
type Input118 struct {
	Scenes []Scene118 `json:"scenes"`
}
type First118 struct {
	Width     float64 `json:"width"`
	Direction int     `json:"direction"`
	Quote     *Quote  `json:"quote"`
}
type Outcome118 struct {
	Seconds  float64    `json:"seconds"`
	Deadline float64    `json:"deadline"`
	Status   string     `json:"status"`
	Touches  []First118 `json:"touches"`
	Endpoint *Quote     `json:"endpoint"`
	Points   *float64   `json:"points"`
	Net0     *float64   `json:"net0"`
	Net5     *float64   `json:"net5"`
}
type Candidate118 struct {
	Policy               string          `json:"policy"`
	Birth                Signal118       `json:"birth"`
	P0                   *float64        `json:"p0"`
	Status               string          `json:"status"`
	Limit                *float64        `json:"limit"`
	Request              *Quote          `json:"request"`
	Expires              float64         `json:"expires"`
	Entry                *Quote          `json:"entry"`
	EntryPrice           *float64        `json:"entry_price"`
	LastNormalTime       float64         `json:"last_normal_time"`
	Technical            *rules.Decision `json:"technical"`
	Watch                rules.Watch     `json:"watch"`
	UnknownEvaluations   int             `json:"unknown_evaluations"`
	KnownEvaluations     int             `json:"known_evaluations"`
	TrueEvaluations      int             `json:"true_evaluations"`
	CapDeniedEvaluations int             `json:"cap_denied_evaluations"`
	FirstTrue            *rules.Decision `json:"first_true"`
	LastTechnical        *rules.Decision `json:"last_technical"`
	Outcomes             []Outcome118    `json:"outcomes"`
}
type Result118 struct {
	Session      string          `json:"session"`
	Success      bool            `json:"success"`
	Error        string          `json:"error,omitempty"`
	Raw          FileRef         `json:"raw"`
	ActualSHA    string          `json:"actual_sha256"`
	Quality      Counts          `json:"quality"`
	Publications int             `json:"publications"`
	Candidates   []*Candidate118 `json:"candidates"`
}

// key118 はSourceの手法と新規IDを分離せず、出生キーを作ります。
//
// 引数: method/id(string)。返り値: stringは一意な連結キーです。
func key118(method, id string) string { return method + "\x00" + id }

// new118 は新規通知の当時気配だけから、独立mini1枚の待機候補を作ります。
//
// 引数: p(string)、s(Signal118)、force(float64)。返り値: *Candidate118は未約定状態です。
func new118(p string, s Signal118, force float64) *Candidate118 {
	c := &Candidate118{Policy: p, Birth: s, Status: "pending", Expires: math.Min(s.Time+900, force), Outcomes: []Outcome118{}}
	if !s.Quote.QuoteOK || !normal(s.Quote) {
		if p == "M0" {
			x := s.Quote
			c.Request = &x
			return c
		}
		c.Status = "birth_quote_unknown"
		return c
	}
	p0 := s.Quote.Ask
	if s.Side < 0 {
		p0 = s.Quote.Bid
	}
	c.P0 = &p0
	if p == "M0" || p == "L50" || p == "L100" || p == "L200" {
		x := s.Quote
		c.Request = &x
		if p != "M0" {
			offset := 50.0
			if p == "L100" {
				offset = 100
			}
			if p == "L200" {
				offset = 200
			}
			limit := p0 - float64(s.Side)*offset
			c.Limit = &limit
			if limit <= 0 {
				c.Status = "invalid_limit"
			}
		}
	}
	return c
}

// fillable118 は後Raw・1秒と、指値の反対側気配1ラージ呼値通過を要求します。
//
// 引数: c(*Candidate118)、q(Quote)。返り値: boolは約定代用が成立する場合です。
func fillable118(c *Candidate118, q Quote) bool {
	if c.Request == nil || q.Index <= c.Request.Index || q.Time < c.Request.Time+1 || !q.QuoteOK || !normal(q) {
		return false
	}
	if c.Policy == "M0" {
		return true
	}
	return c.Limit != nil && ((c.Birth.Side > 0 && q.Ask <= *c.Limit-10) || (c.Birth.Side < 0 && q.Bid >= *c.Limit+10))
}

// fill118 は約定代用を固定し、同じ価格から30分・60分の新評価を開始します。
//
// 引数: c(*Candidate118)、q(Quote)。返り値: ありません。損切りや追尾による観測終了はしません。
func fill118(c *Candidate118, q Quote) {
	price := q.Ask
	if c.Birth.Side < 0 {
		price = q.Bid
	}
	if c.Policy != "M0" {
		price = *c.Limit
	}
	c.Entry = &q
	c.EntryPrice = &price
	c.Status = "filled"
	c.LastNormalTime = q.Time
	for _, h := range Horizons118 {
		o := Outcome118{Seconds: h, Deadline: q.Time + h, Status: "pending", Touches: []First118{}}
		for _, w := range Widths118 {
			o.Touches = append(o.Touches, First118{Width: w})
		}
		c.Outcomes = append(c.Outcomes, o)
	}
}

// outcome118 は同幅先着と期限清算評価を別に保存し、欠測を0円へ埋めません。
//
// 引数: c(*Candidate118)、q(Quote)、previous/force(float64)。返り値: ありません。
func outcome118(c *Candidate118, q Quote, previous, force float64) {
	if c.Entry == nil || q.Index <= c.Entry.Index {
		return
	}
	lastNormal := c.LastNormalTime
	if q.QuoteOK && normal(q) {
		defer func() { c.LastNormalTime = q.Time }()
	}
	for i := range c.Outcomes {
		o := &c.Outcomes[i]
		if o.Status != "pending" {
			continue
		}
		if previous >= c.Entry.Time && q.Time-previous > 300 && previous < o.Deadline {
			o.Status = "gap_censored"
			continue
		}
		if lastNormal >= c.Entry.Time && lastNormal < o.Deadline && q.Time-lastNormal > 300 {
			o.Status = "bbo_gap_censored"
			continue
		}
		if q.Time > force {
			o.Status = "session_censored"
			continue
		}
		if q.Time > o.Deadline+30 {
			o.Status = "endpoint_missing"
			continue
		}
		if !q.QuoteOK || !normal(q) {
			continue
		}
		mark := q.Bid
		if c.Birth.Side < 0 {
			mark = q.Ask
		}
		gain := float64(c.Birth.Side) * (mark - *c.EntryPrice)
		if q.Time <= o.Deadline {
			for j := range o.Touches {
				t := &o.Touches[j]
				if t.Direction != 0 {
					continue
				}
				if gain >= t.Width {
					t.Direction = 1
					x := q
					t.Quote = &x
				} else if gain <= -t.Width {
					t.Direction = -1
					x := q
					t.Quote = &x
				}
			}
		}
		if q.Time >= o.Deadline {
			x := q
			o.Endpoint = &x
			o.Points = &gain
			n0 := gain*100 - 77
			n5 := n0 - 1000
			o.Net0 = &n0
			o.Net5 = &n5
			o.Status = "complete"
		}
	}
}

// scan118 は同じRawと公表・新規・取消を一走査で順序配送します。
//
// 引数: all([]Scene118)、at(int)。返り値: Result118/errorは入力同体と候補の終端状態です。
func scan118(all []Scene118, at int) (out Result118, err error) {
	s := all[at]
	out = Result118{Session: s.Session, Raw: s.Raw, Candidates: []*Candidate118{}}
	bank := rules.NewBank()
	for i := 0; i < at; i++ {
		p := all[i]
		if err = bank.StartSession(p.Session, p.Contract); err != nil {
			return out, err
		}
		for _, pub := range p.Publications {
			if pub.Stamp.Time >= s.Start {
				return out, fmt.Errorf("前史が当場へ侵入")
			}
			if err = bank.Add(pub); err != nil {
				return out, err
			}
		}
	}
	if err = bank.StartSession(s.Session, s.Contract); err != nil {
		return out, err
	}
	signals := append([]Signal118(nil), s.Signals...)
	sort.SliceStable(signals, func(i, j int) bool { return signals[i].Index < signals[j].Index })
	cancels := append([]Cancel118(nil), s.Cancellations...)
	sort.SliceStable(cancels, func(i, j int) bool { return cancels[i].Index < cancels[j].Index })
	seen := map[string]bool{}
	for _, birth := range signals {
		key := key118(birth.Method, birth.ID)
		if seen[key] || birth.ID == "" || (birth.Side != 1 && birth.Side != -1) || birth.Time != birth.Quote.Time || birth.Index != birth.Quote.Index || birth.Line != birth.Quote.SourceLine {
			return out, fmt.Errorf("出生定義不正")
		}
		seen[key] = true
	}
	f, e := os.Open(s.Raw.Path)
	if e != nil {
		return out, e
	}
	defer f.Close()
	before, e := f.Stat()
	if e != nil {
		return out, e
	}
	hash := sha256.New()
	tee := io.TeeReader(f, hash)
	z, e := gzip.NewReader(tee)
	if e != nil {
		return out, e
	}
	defer z.Close()
	scan := bufio.NewScanner(z)
	scan.Buffer(make([]byte, 65536), 8*1024*1024)
	scene := Scene{Session: s.Session, Contract: s.Contract, Start: s.Start, End: s.End, Raw: s.Raw}
	previous := s.Start
	var index int64
	contracts := map[string]bool{}
	bi, ci, pi := 0, 0, 0
	pending := []*Candidate118{}
	holding := []*Candidate118{}
	for scan.Scan() {
		out.Quality.Lines++
		q, _, next, e := decodeRow(scan.Bytes(), out.Quality.Lines, index, scene, previous, &out.Quality, contracts)
		oldTime := previous
		previous = next
		if e != nil {
			return out, e
		}
		if q == nil {
			continue
		}
		index++
		for pi < len(s.Publications) && int64(s.Publications[pi].Stamp.Index) <= q.Index {
			pub := s.Publications[pi]
			if int64(pub.Stamp.Index) != q.Index || int64(pub.Stamp.Line) != q.SourceLine || pub.Stamp.Time != q.Time {
				return out, fmt.Errorf("公表実配送行差")
			}
			if err = bank.Add(pub); err != nil {
				return out, err
			}
			pi++
		}
		for bi < len(signals) && signals[bi].Index <= q.Index {
			birth := signals[bi]
			if birth.Index != q.Index || !equalQuote(birth.Quote, *q) {
				return out, fmt.Errorf("新規通知原行差")
			}
			for _, p := range Policies118 {
				c := new118(p, birth, s.ForceClose)
				out.Candidates = append(out.Candidates, c)
				if c.Status == "pending" {
					pending = append(pending, c)
				}
			}
			bi++
		}
		cancelNow := map[string]bool{}
		for ci < len(cancels) && cancels[ci].Index <= q.Index {
			c := cancels[ci]
			if c.Index != q.Index || c.Time != q.Time || c.Line != q.SourceLine {
				return out, fmt.Errorf("取消実配送行差")
			}
			cancelNow[key118(c.Method, c.SignalID)] = true
			ci++
		}
		keep := pending[:0]
		for _, c := range pending {
			if cancelNow[key118(c.Birth.Method, c.Birth.ID)] {
				c.Status = "source_cancelled"
				continue
			}
			if q.Time >= c.Expires {
				if c.Request == nil {
					c.Status = "unconfirmed_expired"
					if c.KnownEvaluations == 0 && c.UnknownEvaluations > 0 {
						c.Status = "technical_unknown_expired"
					}
				} else {
					c.Status = "unfilled_expired"
				}
				continue
			}
			if c.Request == nil && q.Index > c.Birth.Index {
				decision, e := bank.Evaluate(rules.Mode(c.Policy), c.Birth.Side, rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last}, &c.Watch)
				if e != nil {
					return out, e
				}
				if decision.Truth == rules.Unknown {
					c.UnknownEvaluations++
				} else {
					c.KnownEvaluations++
				}
				c.LastTechnical = &decision
				if decision.Truth == rules.True {
					c.TrueEvaluations++
					if c.FirstTrue == nil {
						c.FirstTrue = &decision
					}
				}
				if decision.Truth == rules.True && q.QuoteOK && normal(*q) {
					cap := *c.P0 - float64(c.Birth.Side)*50
					price := q.Ask
					if c.Birth.Side < 0 {
						price = q.Bid
					}
					if cap > 0 && float64(c.Birth.Side)*(price-cap) <= -10 {
						x := *q
						c.Request = &x
						c.Limit = &cap
						c.Technical = &decision
						c.Expires = math.Min(c.Expires, q.Time+30)
					} else {
						c.CapDeniedEvaluations++
					}
				}
			}
			if fillable118(c, *q) {
				fill118(c, *q)
				holding = append(holding, c)
			} else {
				keep = append(keep, c)
			}
		}
		pending = keep
		active := holding[:0]
		for _, c := range holding {
			outcome118(c, *q, oldTime, s.End)
			alive := false
			for _, o := range c.Outcomes {
				if o.Status == "pending" {
					alive = true
				}
			}
			if alive {
				active = append(active, c)
			}
		}
		holding = active
	}
	if e = scan.Err(); e != nil {
		return out, e
	}
	if _, e = io.Copy(io.Discard, tee); e != nil {
		return out, e
	}
	after, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.ActualSHA = hex.EncodeToString(hash.Sum(nil))
	if out.ActualSHA != s.Raw.SHA256 || before.Size() != after.Size() || before.ModTime() != after.ModTime() {
		return out, fmt.Errorf("Raw SHA/stat差")
	}
	if len(contracts) != 1 || !contracts[s.Contract] || index != s.ExpectedAccepted || bi != len(signals) || ci != len(cancels) || pi != len(s.Publications) {
		return out, fmt.Errorf("限月/全採用数/通知配送数差")
	}
	for _, c := range pending {
		c.Status = "eof_unfilled"
	}
	for _, c := range holding {
		for i := range c.Outcomes {
			if c.Outcomes[i].Status == "pending" {
				c.Outcomes[i].Status = "eof_censored"
			}
		}
	}
	out.Publications = pi
	out.Success = true
	return out, nil
}

// Run118 はRoot固定入力から70場の入口独立試験だけを実行します。
//
// 引数: input/expected/output(string)、workers(int)。返り値: errorは指紋・配送・保存不整合です。
func Run118(input, expected, output string, workers int) error {
	data, err := os.ReadFile(input)
	if err != nil {
		return err
	}
	sum := sha256.Sum256(data)
	if hex.EncodeToString(sum[:]) != expected {
		return fmt.Errorf("入力SHA差")
	}
	var in Input118
	if err = json.Unmarshal(data, &in); err != nil {
		return err
	}
	if len(in.Scenes) != 70 || workers < 1 || workers > 16 {
		return fmt.Errorf("70場/並列条件差")
	}
	if _, err = os.Stat(output); !os.IsNotExist(err) {
		return fmt.Errorf("新規先だけ")
	}
	results := make([]Result118, len(in.Scenes))
	jobs := make(chan int)
	var wg sync.WaitGroup
	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for at := range jobs {
				r, e := scan118(in.Scenes, at)
				if e != nil {
					r.Error = e.Error()
				}
				results[at] = r
				fmt.Printf("%s 成功=%t %s\n", r.Session, r.Success, r.Error)
			}
		}()
	}
	for i := range in.Scenes {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	for _, r := range results {
		if !r.Success {
			return fmt.Errorf("%s: %s", r.Session, r.Error)
		}
	}
	encoded, err := json.MarshalIndent(map[string]any{"trial": 118, "success": true, "input_sha256": expected, "policies": Policies118, "horizons": Horizons118, "widths": Widths118, "scenes": results, "portfolio_pnl": false, "candidate_quantity": 1}, "", "  ")
	if err != nil {
		return err
	}
	after, err := os.ReadFile(input)
	if err != nil {
		return err
	}
	if sha256.Sum256(after) != sum {
		return fmt.Errorf("入力前後差")
	}
	f, err := os.OpenFile(output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return err
	}
	defer f.Close()
	_, err = f.Write(append(encoded, '\n'))
	return err
}
