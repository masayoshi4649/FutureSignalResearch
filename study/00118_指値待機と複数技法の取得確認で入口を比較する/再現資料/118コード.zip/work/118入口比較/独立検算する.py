"""
118の許可済み4JSONだけから、保存された約定証拠・期限算術・集計を独立照合する。

原板・Native・入力台帳・価格CSV・損益CSVを開かず、金融又は候補条件を変更しない。
全Rawの最初性、途中欠測、技術成立時BBOによるcap拒否は再証明しない。
"""

from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import re
from typing import Any


HERE = Path(__file__).absolute().parent
INPUTS = {
    "全70場の入口結果.json": "c8f40fd2192a94c85867e6de901d43a46deff27c73a02fa8416abd4a779e3382",
    "集計.json": "64eda52d1f8a75775b1a80ae64de0409aa14a9f8a410915e96995f3aa41801f1",
    "F1.json": "57295a629a3a54df04385597ec25329f1254692e01db4072fd5d295364b0ebfc",
    "全70場の完了.json": "dca8ac525a4a41e1194fb9515ed591ecec3e5f22121fa04724e26b8376fd39eb",
}
POLICIES = ["M0", "L50", "L100", "L200", "Ttrend", "Treversal", "Thybrid"]
HORIZONS = [1800, 3600]
WIDTHS = [25, 50, 100, 125, 200]
SHA_PATTERN = re.compile(r"[0-9a-f]{64}\Z")
JST = timezone(timedelta(hours=9))


# ----------------------------------------
def need(condition: bool, message: str) -> None:
    """
    機能: 照合条件を満たさない場合に中止する。
    引数: condition(bool)は検査結果、message(str)は失敗理由。
    返り値: None。失敗時はValueErrorを送出する。
    """
    if not condition:
        raise ValueError(message)


# ----------------------------------------
def sha(data: bytes) -> str:
    """
    機能: バイト列のSHA256を算出する。
    引数: data(bytes)は対象バイト列。
    返り値: str型の小文字16進SHA256。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def check_tree(saved: Any, rebuilt: Any, label: str, counts: Counter) -> None:
    """
    機能: 独立再集計した構造を保存集計へ全キー・全値で照合する。
    引数: saved(Any)は保存値、rebuilt(Any)は独立値、label(str)は位置、counts(Counter)は検査件数。
    返り値: None。比率・平均の分数はIEEE754倍精度への1回の丸め後に照合する。
    """
    if isinstance(rebuilt, dict):
        need(isinstance(saved, dict) and saved.keys() == rebuilt.keys(), f"{label}: キー不一致")
        for key, value in rebuilt.items():
            check_tree(saved[key], value, f"{label}/{key}", counts)
        return
    if isinstance(rebuilt, Fraction):
        target = Decimal(str(float(rebuilt)))
        need(saved is not None and Decimal(saved) == target, f"{label}: 比率・平均不一致 {saved} != {target}")
        counts["平均比率値"] += 1
        return
    need(saved == rebuilt, f"{label}: 値不一致 {saved!r} != {rebuilt!r}")
    counts["厳密値"] += 1


# ----------------------------------------
def session_bounds(session: str) -> tuple[int, int]:
    """
    機能: セッション名から所定の日中又は夜間の開始・終了を求める。
    引数: session(str)はYYYY-MM-DD_Day又はNight。
    返り値: tuple[int, int]型の開始・終了Unix秒。夜間終了は翌日06:00。
    """
    date_text, kind = session.rsplit("_", 1)
    day = datetime.strptime(date_text, "%Y-%m-%d").replace(tzinfo=JST)
    need(kind in ("Day", "Night") and date_text != "2026-11-09", "対象外のセッション")
    start = day + (timedelta(hours=8, minutes=45) if kind == "Day" else timedelta(hours=17))
    end = day + (timedelta(hours=15, minutes=45) if kind == "Day" else timedelta(days=1, hours=6))
    return int(start.timestamp()), int(end.timestamp())


# ----------------------------------------
def normal_quote(quote: dict[str, Any]) -> bool:
    """
    機能: 保存気配の生正常フラグと有限・正値・BidAsk順序を判定する。
    引数: quote(dict[str, Any])は保存気配。
    返り値: bool型の正常気配判定。
    """
    values = [Decimal(quote[key]) for key in ("last", "bid", "ask")]
    return quote["quote_ok"] is True and all(value.is_finite() for value in values) and values[0] > 0 and values[1] > 0 and values[2] > values[1]


# ----------------------------------------
def quote_check(quote: dict[str, Any], scene: dict[str, Any], counts: Counter, normal: bool = False) -> None:
    """
    機能: 保存気配の時計・採用Index・物理行の範囲を保存品質及びセッションへ照合する。
    引数: quote(dict[str, Any])は気配、scene(dict[str, Any])は場、counts(Counter)は件数、normal(bool)は正常必須指定。
    返り値: None。実原板への再結合及び最初行性は検査しない。
    """
    start, end = session_bounds(scene["session"])
    need(start <= quote["time"] <= end, "気配がセッション外")
    need(isinstance(quote["index"], int) and 0 <= quote["index"] < scene["quality"]["source_delivered"], "採用Indexが範囲外")
    need(isinstance(quote["source_line"], int) and quote["index"] + 1 <= quote["source_line"] <= scene["quality"]["lines"], "物理行が範囲外")
    if "clock" in quote:
        need(Decimal(str(datetime.fromisoformat(quote["clock"]).timestamp())) == quote["time"], "clockとUnix秒が不一致")
    if normal:
        need(normal_quote(quote), "正常返済又は取得気配ではない")
    counts["保存気配範囲"] += 1


# ----------------------------------------
def later(quote: dict[str, Any], prior: dict[str, Any], delay: int = 0) -> bool:
    """
    機能: 同秒別行を保持しながら、後の採用・物理行と指定時間差を検査する。
    引数: quote(dict[str, Any])は後行、prior(dict[str, Any])は前行、delay(int)は最低秒差。
    返り値: bool型の順序判定。
    """
    return quote["index"] > prior["index"] and quote["source_line"] > prior["source_line"] and quote["time"] >= prior["time"] + delay


# ----------------------------------------
def entry_mark(quote: dict[str, Any], side: int) -> Any:
    """
    機能: 新規側に必要な反対気配を選択する。
    引数: quote(dict[str, Any])は正常気配、side(int)は買1又は売-1。
    返り値: 数値型の買Ask又は売Bid。
    """
    return quote["ask"] if side == 1 else quote["bid"]


# ----------------------------------------
def exit_mark(quote: dict[str, Any], side: int) -> Any:
    """
    機能: 保有方向の返済側気配を選択する。
    引数: quote(dict[str, Any])は正常気配、side(int)は買1又は売-1。
    返り値: 数値型の買保有Bid又は売保有Ask。
    """
    return quote["bid"] if side == 1 else quote["ask"]


# ----------------------------------------
def technical_check(decision: dict[str, Any], candidate: dict[str, Any], counts: Counter) -> None:
    """
    機能: 保存された技術票の方向・三値・公表参照の時点と鮮度を検査する。
    引数: decision(dict[str, Any])は票、candidate(dict[str, Any])は出生、counts(Counter)は件数。
    返り値: None。未保存BBO又は全公表本文からの技法式再計算は行わない。
    """
    birth = candidate["birth"]
    stamp = decision["at"]
    need(decision["mode"] == candidate["policy"] and decision["side"] == birth["side"], "技術票のモード・方向不一致")
    need(stamp["time"] >= birth["time"] and stamp["time"] < candidate["expires"], "技術票の評価時点がTTL外")
    need(stamp["index"] >= birth["index"] and stamp["source_line"] >= birth["source_line"], "技術票が出生より前")
    need(decision["truth"] in (0, 1, 2), "技術票の三値が不正")
    trend, reversal = decision["trend"]["truth"], decision["reversal"]["truth"]
    need(trend in (0, 1, 2) and reversal in (0, 1, 2), "枝票の三値が不正")
    combined = 2 if 2 in (trend, reversal) else (0 if 0 in (trend, reversal) else 1)
    selected = {"Ttrend": trend, "Treversal": reversal, "Thybrid": combined}[candidate["policy"]]
    need(decision["truth"] == selected, "採用枝の三値又はORが不一致")
    widths: set[int] = set()
    for ref in decision.get("snapshotrefs") or []:
        width = ref["width_seconds"]
        delivered = ref["delivered"]
        need(width in (300, 900, 1800) and width not in widths, "公表参照足幅が不正又は重複")
        widths.add(width)
        need(ref["id"].startswith("frame:") and bool(SHA_PATTERN.fullmatch(ref["id"][6:])), "公表ID形式が不正")
        need(ref["end"] + 60 <= delivered["time"] <= stamp["time"] < ref["end"] + width + 60, "公表時刻・鮮度不一致")
        need(delivered["index"] <= stamp["index"] and delivered["source_line"] <= stamp["source_line"], "未来の公表配送")
        counts["技術公表参照"] += 1
    for branch_name in ("trend", "reversal"):
        branch = decision[branch_name]
        touch = branch.get("touch")
        if touch:
            at, ref = touch["at"], touch["frame5"]
            need(at["time"] >= birth["time"] and at["time"] <= stamp["time"], "接触票時点が不正")
            need(at["index"] >= birth["index"] and at["index"] <= stamp["index"], "接触票Indexが不正")
            need(ref["width_seconds"] == 300 and ref["end"] + 60 <= ref["delivered"]["time"] <= at["time"], "接触足の公表不整合")
    for field in decision["fields"].values():
        need(isinstance(field["known"], bool) and Decimal(field["value"]).is_finite(), "技術指標のKnown又は値が不正")
    counts["技術保存票"] += 1


# ----------------------------------------
def candidate_check(candidate: dict[str, Any], scene: dict[str, Any], counts: Counter) -> None:
    """
    機能: 1候補の要求・約定・期限損益・同幅到達の幾何及び保存技術票を照合する。
    引数: candidate(dict[str, Any])は候補、scene(dict[str, Any])は場、counts(Counter)は件数。
    返り値: None。最初の正常約定・到達・清算行だったことは再証明しない。
    """
    policy, birth = candidate["policy"], candidate["birth"]
    side = birth["side"]
    need(policy in POLICIES and side in (-1, 1), "政策又は方向が不正")
    quote_check(birth["quote"], scene, counts)
    need(all(birth[key] == birth["quote"][key] for key in ("time", "index", "source_line")), "出生と出生気配の時点が不一致")
    need(birth["time"] < candidate["expires"] <= birth["time"] + 900, "出生TTLが不正")
    if normal_quote(birth["quote"]):
        need(candidate["p0"] == entry_mark(birth["quote"], side), "P0が出生反対気配ではない")
    request, entry = candidate["request"], candidate["entry"]
    if policy == "M0":
        need(request == birth["quote"] and candidate["limit"] is None, "成行要求が出生原行ではない")
    elif policy.startswith("L"):
        offset = int(policy[1:])
        need(request == birth["quote"] and candidate["limit"] == candidate["p0"] - side * offset, "指値P0又は出生要求が不一致")
    else:
        known, unknown, true, cap = [candidate[key] for key in ("known_evaluations", "unknown_evaluations", "true_evaluations", "cap_denied_evaluations")]
        need(all(isinstance(value, int) and value >= 0 for value in (known, unknown, true, cap)), "技術カウンタが不正")
        need(0 <= cap <= true <= known, "技術True・cap・既知カウンタの順序不整合")
        need((candidate["first_true"] is not None) == (true > 0), "初回Trueと件数が不一致")
        if candidate["first_true"] is not None:
            need(candidate["first_true"]["truth"] == 2, "初回Trueが真ではない")
        for key in ("first_true", "last_technical", "technical"):
            if candidate[key] is not None:
                technical_check(candidate[key], candidate, counts)
        if candidate["status"] == "technical_unknown_expired":
            need(known == 0 and unknown > 0, "未知のみ期限切れの定義不一致")
        if request is not None:
            need(candidate["technical"] is not None and candidate["technical"]["truth"] == 2, "技術要求に真票がない")
            need(candidate["limit"] == candidate["p0"] - side * 50, "技術cap価格が不一致")
            need(normal_quote(request) and side * (entry_mark(request, side) - candidate["limit"]) <= -10, "技術要求時cap通過が不成立")
            need(candidate["expires"] <= request["time"] + 30, "技術要求TTLが30秒を超える")
    need((candidate["status"] == "filled") == (entry is not None), "約定状態と取得証拠が不一致")
    if entry is None:
        need(candidate["entry_price"] is None and candidate["outcomes"] == [], "未約定に損益又は期限評価がある")
        counts["未約定の損益未補完"] += 1
        return
    need(request is not None, "要求のない約定")
    quote_check(request, scene, counts)
    quote_check(entry, scene, counts, normal=True)
    need(later(entry, request, 1), "約定が要求後の原行かつ1秒後ではない")
    need(entry["time"] < candidate["expires"], "TTL後の約定")
    if policy == "M0":
        need(candidate["entry_price"] == entry_mark(entry, side), "成行記帳価格不一致")
    else:
        need(side * (entry_mark(entry, side) - candidate["limit"]) <= -10, "指値が反対BBO10pt通過を満たさない")
        need(candidate["entry_price"] == candidate["limit"], "指値の記帳価格がlimitではない")
        counts["指値通過と記帳"] += 1
    counts["約定後原行と1秒"] += 1
    need([outcome["seconds"] for outcome in candidate["outcomes"]] == HORIZONS, "期限の並び又は本数が不一致")
    touch_maps: list[dict[int, dict[str, Any]]] = []
    for outcome in candidate["outcomes"]:
        need(outcome["deadline"] == entry["time"] + outcome["seconds"], "期限計算不一致")
        need([touch["width"] for touch in outcome["touches"]] == WIDTHS, "先着幅が不一致")
        need(outcome["status"] in ("complete", "endpoint_missing", "eof_censored", "gap_censored", "bbo_gap_censored", "session_censored"), "未知の期限状態")
        if outcome["status"] == "complete":
            endpoint = outcome["endpoint"]
            need(endpoint is not None and later(endpoint, entry), "期限清算の原行が不正")
            quote_check(endpoint, scene, counts, normal=True)
            need(outcome["deadline"] <= endpoint["time"] <= outcome["deadline"] + 30, "清算が期限又は猶予外")
            gain = side * (exit_mark(endpoint, side) - candidate["entry_price"])
            need(outcome["points"] == gain and outcome["net0"] == gain * 100 - 77 and outcome["net5"] == gain * 100 - 1077, "期限損益又は費用が不一致")
            counts["期限純額2費用"] += 1
        else:
            need(all(outcome[key] is None for key in ("endpoint", "points", "net0", "net5")), "打切りを損益零等で補完している")
            counts["打切り純額nil"] += 1
        previous_hit: dict[str, Any] | None = None
        touch_map = {}
        for touch in outcome["touches"]:
            direction, quote = touch["direction"], touch["quote"]
            need(direction in (-1, 0, 1) and ((direction == 0) == (quote is None)), "先着方向と気配が不一致")
            if quote is not None:
                quote_check(quote, scene, counts, normal=True)
                need(later(quote, entry) and quote["time"] <= outcome["deadline"], "先着が取得原行又は期限外")
                signed = side * (exit_mark(quote, side) - candidate["entry_price"])
                need(direction * signed >= touch["width"], "先着の方向又は幅が不成立")
                if previous_hit is not None:
                    need(quote["index"] >= previous_hit["index"] and quote["source_line"] >= previous_hit["source_line"] and quote["time"] >= previous_hit["time"], "大幅先着が小幅先着より前")
                previous_hit = quote
                counts["先着気配の幅と方向"] += 1
            else:
                need(all(t["direction"] == 0 for t in outcome["touches"] if t["width"] > touch["width"]), "小幅未到達なのに大幅到達")
            touch_map[touch["width"]] = touch
        touch_maps.append(touch_map)
    for width in WIDTHS:
        short, long = touch_maps[0][width], touch_maps[1][width]
        if short["direction"]:
            need(short == long, "30分以内の既先着が60分側と不一致")
        elif long["direction"]:
            if long["quote"]["time"] <= entry["time"] + 1800 and candidate["outcomes"][0]["status"] == "complete":
                endpoint = candidate["outcomes"][0]["endpoint"]
                need(long["quote"]["time"] == endpoint["time"] == entry["time"] + 1800 and later(long["quote"], endpoint), "30分未到達と60分側の保存時点が矛盾")
                counts["期限同秒の清算後行"] += 1


# ----------------------------------------
def average(values: list[Any]) -> Fraction | None:
    """
    機能: 整数又は十進数の列の平均を厳密分数で計算する。
    引数: values(list[Any])は数値列。
    返り値: Fraction又はNone。空列を零で補完しない。
    """
    return sum((Fraction(value) for value in values), Fraction()) / len(values) if values else None


# ----------------------------------------
def median(values: list[Any]) -> Fraction | None:
    """
    機能: 昇順の中央値又は中央2値の平均を厳密分数で算出する。
    引数: values(list[Any])は数値列。
    返り値: Fraction又はNone。空列の中央値は未定義。
    """
    if not values:
        return None
    ordered = sorted(Fraction(value) for value in values)
    middle = len(ordered) // 2
    return ordered[middle] if len(ordered) % 2 else (ordered[middle - 1] + ordered[middle]) / 2


# ----------------------------------------
def summarize(rows: list[tuple[str, dict[str, Any]]], policy: str, seconds: int) -> dict[str, Any]:
    """
    機能: 政策・期限を指定して母数、完了のみの先着・平均・中央値及び同出生対照を再集計する。
    引数: rows(list[tuple[str, dict[str, Any]]])は場付き候補、policy(str)は政策、seconds(int)は期限。
    返り値: dict[str, Any]型の再集計。未約定・打切りは純額へ混ぜない。
    """
    selected = [(session, candidate) for session, candidate in rows if candidate["policy"] == policy]
    outcomes = [(session, candidate, outcome) for session, candidate in selected for outcome in candidate["outcomes"] if outcome["seconds"] == seconds]
    completed = [(session, candidate, outcome) for session, candidate, outcome in outcomes if outcome["status"] == "complete"]
    baseline = {}
    for session, candidate in rows:
        if candidate["policy"] == "M0":
            for outcome in candidate["outcomes"]:
                if outcome["seconds"] == seconds and outcome["status"] == "complete":
                    baseline[(session, candidate["birth"]["method"], candidate["birth"]["id"])] = (candidate, outcome)
    pairs = []
    for session, candidate, outcome in completed:
        key = (session, candidate["birth"]["method"], candidate["birth"]["id"])
        if key in baseline:
            original, original_outcome = baseline[key]
            pairs.append((original_outcome["net5"], outcome["net5"], candidate["birth"]["side"] * (original["entry_price"] - candidate["entry_price"])))
    net0 = [outcome["net0"] for _, _, outcome in completed]
    net5 = [outcome["net5"] for _, _, outcome in completed]
    touches = {}
    for width in WIDTHS:
        directions = Counter(next(touch["direction"] for touch in outcome["touches"] if touch["width"] == width) for _, _, outcome in completed)
        resolved = directions[1] + directions[-1]
        touches[str(width)] = {"favorable": directions[1], "adverse": directions[-1], "neither": directions[0], "resolved_rate": Fraction(directions[1], resolved) if resolved else None}
    return {
        "births": len(selected),
        "requested": sum(candidate["request"] is not None for _, candidate in selected),
        "filled": sum(candidate["entry"] is not None for _, candidate in selected),
        "complete": len(completed),
        "censored": len(outcomes) - len(completed),
        "states": dict(Counter(candidate["status"] for _, candidate in selected)),
        "observations": dict(Counter(outcome["status"] for _, _, outcome in outcomes)),
        "tech_ever_true": sum(candidate["first_true"] is not None for _, candidate in selected),
        "tech_cap_denied": sum(candidate["cap_denied_evaluations"] > 0 for _, candidate in selected),
        "unknown_only": sum(candidate["known_evaluations"] == 0 and candidate["unknown_evaluations"] > 0 for _, candidate in selected),
        "touches": touches,
        "mean_net0": average(net0),
        "mean_net5": average(net5),
        "median_net5": median(net5),
        "positive_net5": sum(value > 0 for value in net5),
        "negative_net5": sum(value < 0 for value in net5),
        "zero_net5": sum(value == 0 for value in net5),
        "pairs": len(pairs),
        "paired_baseline_mean_net5": average([row[0] for row in pairs]),
        "paired_candidate_mean_net5": average([row[1] for row in pairs]),
        "paired_mean_delta": average([row[1] - row[0] for row in pairs]),
        "paired_median_delta": median([row[1] - row[0] for row in pairs]),
        "paired_mean_entry_improvement": average([row[2] for row in pairs]),
    }


# ----------------------------------------
def serial(value: Any) -> Any:
    """
    機能: 独立分数値を確認JSON用の十進近似値へ変換する。
    引数: value(Any)は辞書・配列・分数又はscalar。
    返り値: Any型のJSON保存可能値。照合そのものは変換前の厳密分数を使用する。
    """
    if isinstance(value, Fraction):
        return float(value)
    if isinstance(value, dict):
        return {key: serial(item) for key, item in value.items()}
    if isinstance(value, list):
        return [serial(item) for item in value]
    return value


# ----------------------------------------
def main() -> None:
    """
    機能: SHA固定された4JSONの独立検算を実行し、新規の小確認JSONを保存する。
    引数: なし。許可済み4入力と自身のコード以外のファイルを開かない。
    返り値: None。成功後に確認先・SHA256・主要件数を標準出力へ表示する。
    """
    output = HERE / "独立検算.json"
    need(not output.exists(), "確認先が既に存在する")
    before = {}
    values = {}
    for name, expected_sha in INPUTS.items():
        path = HERE / name
        data = path.read_bytes()
        need(sha(data) == expected_sha, f"入力SHA256不一致: {name}")
        before[str(path)] = expected_sha
        values[name] = json.loads(data, parse_float=Decimal)
    code_path = Path(__file__).absolute()
    before[str(code_path)] = sha(code_path.read_bytes())
    result, saved, condition, completion = [values[name] for name in INPUTS]
    need(result["success"] is True and result["trial"] == 118 and result["candidate_quantity"] == 1 and result["portfolio_pnl"] is False, "独立1mini結果の範囲不一致")
    need(result["policies"] == condition["policies"] == POLICIES and result["horizons"] == condition["horizons_seconds"] == HORIZONS and result["widths"] == condition["widths_points"] == WIDTHS, "固定宣言と結果が不一致")
    need(condition["trial"] == 118 and condition["fixed"] is True and condition["source_births"] == 558 and condition["independent_mini_quantity"] == 1, "F1宣言不一致")
    need(condition["pending_seconds"] == 900 and condition["technical_order_seconds"] == 30 and condition["delay_seconds"] == 1 and condition["limit_opposite_bbo_cross_points"] == 10 and condition["technical_price_improvement_points"] == 50, "取得条件不一致")
    need(condition["fee_round_yen"] == 77 and condition["slip_stress_round_yen"] == [0, 1000] and condition["endpoint_grace_seconds"] == 30 and condition["normal_bbo_gap_seconds"] == 300, "期限又は費用条件不一致")
    need(condition["source_cancel_priority"] is True and condition["source_paper_close_cancel"] is False and condition["11月09読取"] is False and condition["portfolio_pnl"] is False, "Source又は範囲宣言不一致")
    need(result["input_sha256"] == condition["input"]["sha256"], "結果の入力SHAがF1と不一致")
    need(completion["成功"] is True and completion["前後不変"] is True and completion["入力コード前SHA256"] == completion["入力コード後SHA256"], "完了が成功又は前後不変ではない")
    need(completion["F1_SHA256"] == INPUTS["F1.json"] and completion["結果"]["sha256"] == INPUTS["全70場の入口結果.json"], "完了とF1又は結果が未結合")
    need(all(completion["入力コード前SHA256"].get(path) == value for path, value in condition["code_sha256"].items()), "F1と完了のコード指紋不一致")
    need(saved["成功"] is True and saved["元結果SHA256"] == INPUTS["全70場の入口結果.json"] and saved["口座収支"] is False and saved["未約定0円補完"] is False, "集計の範囲不一致")
    scenes = result["scenes"]
    names = [scene["session"] for scene in scenes]
    need(len(scenes) == completion["場数"] == 70 and names == sorted(set(names)), "場数・重複又は順序が不正")
    need(names[53] == "2026-10-27_Night" and names[54] == "2026-10-28_Day" and names[-1] == "2026-11-06_Night", "元54・追加16の境界不一致")
    counts: Counter = Counter()
    all_rows = []
    groups: dict[str, dict[str, list[tuple[str, dict[str, Any]]]]] = {"side": defaultdict(list), "history": defaultdict(list), "method": defaultdict(list)}
    births = set()
    tech_totals = {policy: Counter() for policy in POLICIES if policy.startswith("T")}
    for scene_index, scene in enumerate(scenes):
        need(scene["success"] is True and scene["raw"]["sha256"] == scene["actual_sha256"], "場成功又は保存RawSHA一致がない")
        need(scene["quality"]["source_parser_accepted"] == scene["quality"]["source_delivered"], "採用・配送件数が不一致")
        scene_births: dict[tuple[str, str], list[dict[str, Any]]] = defaultdict(list)
        for candidate in scene["candidates"]:
            candidate_check(candidate, scene, counts)
            birth = candidate["birth"]
            key = (birth["method"], birth["id"])
            scene_births[key].append(candidate)
            row = (scene["session"], candidate)
            all_rows.append(row)
            groups["side"][str(birth["side"])].append(row)
            groups["history"]["元54場" if scene_index < 54 else "追加16場"].append(row)
            groups["method"][birth["method"]].append(row)
            if candidate["policy"] in tech_totals:
                tech_totals[candidate["policy"]].update({key: candidate[key] for key in ("known_evaluations", "unknown_evaluations", "true_evaluations", "cap_denied_evaluations")})
        for key, candidates in scene_births.items():
            need([candidate["policy"] for candidate in candidates] == POLICIES, "出生の7政策が重複・欠落・順序不一致")
            need(all(candidate["birth"] == candidates[0]["birth"] for candidate in candidates), "政策間で出生原文が違う")
            full_key = (scene["session"], *key)
            need(full_key not in births, "複合出生キーが重複")
            births.add(full_key)
    need(len(births) == completion["候補出生数"] == 558 and len(all_rows) == completion["政策別候補数"] == 3906, "母数不一致")
    rebuilt = {policy: {str(seconds): summarize(all_rows, policy, seconds) for seconds in HORIZONS} for policy in POLICIES}
    check_tree(saved["集計"], rebuilt, "全政策", counts)
    group_brief = {}
    for kind, group in groups.items():
        need(saved["群別"][kind].keys() == group.keys(), f"{kind}: 群キーが不一致")
        group_brief[kind] = {}
        for name, rows in group.items():
            grouped = {policy: {str(seconds): summarize(rows, policy, seconds) for seconds in HORIZONS} for policy in POLICIES}
            check_tree(saved["群別"][kind][name], grouped, f"{kind}/{name}", counts)
            group_brief[kind][name] = {policy: {seconds: {key: item[key] for key in ("births", "filled", "complete", "mean_net5", "median_net5", "pairs", "paired_mean_delta")} for seconds, item in horizons.items()} for policy, horizons in grouped.items()}
    need(counts["期限純額2費用"] == saved["独立期限算術検査数"] == 2156, "完了期限の算術件数不一致")
    need(rebuilt["M0"]["3600"]["complete"] == 496 and rebuilt["M0"]["3600"]["touches"]["100"] == {"favorable": 234, "adverse": 252, "neither": 10, "resolved_rate": Fraction(234, 486)}, "M0速報不一致")
    need(rebuilt["L200"]["3600"]["filled"] == 71 and rebuilt["L200"]["3600"]["complete"] == 68 and rebuilt["L200"]["3600"]["touches"]["100"]["favorable"] == 22 and rebuilt["L200"]["3600"]["touches"]["100"]["adverse"] == 45, "L200速報不一致")
    need([rebuilt[policy]["3600"]["tech_ever_true"] for policy in tech_totals] == [3, 8, 11] and all(rebuilt[policy]["3600"]["filled"] == 0 for policy in tech_totals), "技術成立又は未約定速報不一致")
    after = {path: sha(Path(path).read_bytes()) for path in before}
    need(before == after, "許可入力又は検算コードが照合中に変化")
    proof = {
        "試行": 118,
        "成功": True,
        "場数": 70,
        "元場数": 54,
        "追加場数": 16,
        "出生数": len(births),
        "政策数": 7,
        "独立候補数": len(all_rows),
        "検査件数": dict(counts),
        "集計": serial(rebuilt),
        "群別の再集計要点": serial(group_brief),
        "技術の延べ評価件数": {key: dict(value) for key, value in tech_totals.items()},
        "入力SHA256": before,
        "後SHA256": after,
        "前後不変": True,
        "数値比較": "金額と件数は完全一致。平均・中央値・率は厳密Fractionで再算出し、保存JSONへのIEEE754倍精度1回丸めと照合。許容差による補正なし。",
        "分母": "期限損益・先着は当該政策で約定かつ期限completeの独立1miniだけ。pairsは同出生M0も当該政策もcompleteの共通群で、双方平均を同じ群へ限定。",
        "解釈": "新規単独の入口候補評価であり、運用口座の合計収支・mini片側10枚の実運用・収益目標達成を示さない。技術政策0約定の平均はnullであり損益零又は改善ではない。",
        "確認範囲": [
            "558出生の7政策同体、要求後Index・物理行・1秒、保存反対BBOの10pt通過と成行又は指値記帳価格",
            "期限30分・60分の正常返済側BBO、猶予30秒、C0=77円とC5=1077円、打切り純額null",
            "保存先着気配の25・50・100・125・200pt幾何、買売鏡像、幅及び期限間の保存整合",
            "全政策と元54・追加16・買売・Source3手法の全集計キー、件数、率、平均、中央値、同出生対照平均差",
            "技術保存票の三値・OR、方向、公表参照ID形式・時刻・配送Index・鮮度、既知未知・True・capカウンタ整合",
        ],
        "未証明": [
            "全Rawの別再走査及び約定・先着・期限清算の最初性。保存証拠だけから途中のRaw又は正常BBO欠測を再検出していない。",
            "技術first_true及びlast_technicalのAtにはBid・Askがないため、True時の50pt cap拒否の全価格条件は独立再算出不能。cap拒否は保存カウンタによる各出生の記録として照合した。",
            "技術公表本文及び全Raw評価列は許可入力にないため、全技法値・背景・接触からTrueとなる式の独立再形成又は評価回数のRaw分母は再証明しない。",
            "入力台帳とRaw本文は開かず、場別Raw期待SHAとactual_sha256の保存同体を検査した。TTLのforce_closeクリップ理由そのものは保存結果だけでは独立再形成しない。",
            "打切り方向0は到達なし確定又は負けではない。集計のneitherはcomplete群内だけ。固定期限であり旧S0保有終了を観測打切りへ使用していないという実装契約自体の再走査はしない。",
        ],
        "期限境界の注意": "10月29日Day L50のD164_15-000019、30分125ptは未到達。60分側の逆125pt気配は同じ30分期限秒の後原行にあるが、30分の実endpoint原行より後である。complete後の保存打切りと整合する一方、期限秒以下の全原行を含むという説明にはしない。検査件数の期限同秒の清算後行に記録する。",
        "原板再走査": False,
        "Native読取": 0,
        "CSV読取": 0,
        "条件変更": False,
        "金融実行": False,
        "運用口座合算": False,
        "目標達成": False,
        "11月09読取": False,
    }
    encoded = (json.dumps(proof, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")
    with output.open("xb") as handle:
        handle.write(encoded)
    print(json.dumps({"成功": True, "確認": str(output), "sha256": sha(encoded), "出生": len(births), "候補": len(all_rows), "検査件数": dict(counts)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
