package holdingohlc113

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// TestEntryDelayAndLimit は、1秒・後Raw・反対側1呼値通過と売買対称を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestEntryDelayAndLimit(t *testing.T) {
	for _, side := range []int{1, -1} {
		q := Quote{Time: 100, Index: 0, SourceLine: 1, Last: 1000, Bid: 990, Ask: 1010, QuoteOK: true}
		s := Signal118{ID: "s", Method: "m", Side: side, Time: 100, Index: 0, Line: 1, Quote: q}
		c := new118("L200", s, 5000)
		x := q
		x.Time = 101
		x.Index = 1
		x.SourceLine = 2
		if side > 0 {
			x.Bid = *c.Limit
			x.Ask = *c.Limit + 10
		} else {
			x.Ask = *c.Limit
			x.Bid = *c.Limit - 10
		}
		if fillable118(c, x) {
			t.Fatal("同側touchで約定")
		}
		if side > 0 {
			x.Bid = *c.Limit - 10
			x.Ask = *c.Limit
		} else {
			x.Ask = *c.Limit + 10
			x.Bid = *c.Limit
		}
		if fillable118(c, x) {
			t.Fatal("等号だけで約定")
		}
		if side > 0 {
			x.Bid = *c.Limit - 20
			x.Ask = *c.Limit - 10
		} else {
			x.Ask = *c.Limit + 20
			x.Bid = *c.Limit + 10
		}
		if !fillable118(c, x) {
			t.Fatal("反対側1呼値通過")
		}
		x.Time = 100
		if fillable118(c, x) {
			t.Fatal("1秒未満")
		}
		x.Time = 101
		x.Index = 0
		if fillable118(c, x) {
			t.Fatal("同原行")
		}
	}
}

// TestFixedOutcome は、先着で終了せず固定期限へ評価し、空白を不明にすることを検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestFixedOutcome(t *testing.T) {
	s := Signal118{Side: 1}
	c := &Candidate118{Policy: "M0", Birth: s}
	fill118(c, Quote{Time: 100, Index: 0, Bid: 95, Ask: 100, QuoteOK: true})
	outcome118(c, Quote{Time: 200, Index: 1, Bid: 125, Ask: 130, QuoteOK: true}, 199, 5000)
	if c.Outcomes[0].Touches[0].Direction != 1 || c.Outcomes[0].Status != "pending" {
		t.Fatal("先着で返済扱い")
	}
	for at := 400.0; at < 1900; at += 200 {
		outcome118(c, Quote{Time: at, Index: int64(at), Bid: 110, Ask: 115, QuoteOK: true}, at-1, 5000)
	}
	outcome118(c, Quote{Time: 1900, Index: 2, Bid: 90, Ask: 95, QuoteOK: true}, 1899, 5000)
	if c.Outcomes[0].Status != "complete" || *c.Outcomes[0].Net0 != -1077 || *c.Outcomes[0].Net5 != -2077 {
		t.Fatal("期限費用式")
	}
	d := &Candidate118{Policy: "M0", Birth: s}
	fill118(d, Quote{Time: 100, Index: 0, Bid: 95, Ask: 100, QuoteOK: true})
	outcome118(d, Quote{Time: 500, Index: 1, Bid: 200, Ask: 205, QuoteOK: true}, 100, 5000)
	if d.Outcomes[0].Status != "gap_censored" || d.Outcomes[0].Net0 != nil || d.Outcomes[0].Touches[0].Direction != 0 {
		t.Fatal("空白を確定/0円化")
	}
	b := &Candidate118{Policy: "M0", Birth: s}
	fill118(b, Quote{Time: 100, Index: 0, Bid: 95, Ask: 100, QuoteOK: true})
	outcome118(b, Quote{Time: 401, Index: 301, Last: 200, QuoteOK: false}, 400, 5000)
	if b.Outcomes[0].Status != "bbo_gap_censored" || b.Outcomes[0].Net0 != nil {
		t.Fatal("Last継続でBBO欠測を隠す")
	}
}

// TestMarketBirthUnknown は、成行対照だけは通知時BBO不明でも後正常気配を待てることを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestMarketBirthUnknown(t *testing.T) {
	s := Signal118{Side: 1, Time: 100, Quote: Quote{Time: 100, Index: 0, Last: 100, QuoteOK: false}}
	m := new118("M0", s, 5000)
	l := new118("L200", s, 5000)
	if m.Status != "pending" || l.Status != "birth_quote_unknown" || !fillable118(m, Quote{Time: 101, Index: 1, Bid: 100, Ask: 110, QuoteOK: true}) {
		t.Fatal("成行と基準価格指値の未知を混同")
	}
}

// TestCancelBeforeFill は、実parserの手製原板で同原行の取消を指値約定より先行させます。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestCancelBeforeFill(t *testing.T) {
	path := filepath.Join(t.TempDir(), "book.jsonl.gz")
	f, e := os.Create(path)
	if e != nil {
		t.Fatal(e)
	}
	z := gzip.NewWriter(f)
	quotes := []Quote{{Time: 100, Index: 0, SourceLine: 1, Last: 100, Bid: 100, Ask: 110, QuoteOK: true}, {Time: 101, Index: 1, SourceLine: 2, Last: 60, Bid: 55, Ask: 60, QuoteOK: true}, {Time: 102, Index: 2, SourceLine: 3, Last: 50, Bid: 45, Ask: 50, QuoteOK: true}}
	for _, q := range quotes {
		m := map[string]any{"Symbol": "X", "CurrentPrice": q.Last, "CurrentPriceTime": time.Unix(int64(q.Time), 0).UTC().Format(time.RFC3339)}
		for i := 1; i <= 10; i++ {
			name := []string{"Buy", "Sell"}
			for j, p := range []float64{q.Bid, q.Ask} {
				m[name[j]+string(rune('0'+i))] = map[string]float64{"Price": p, "Qty": 1}
			}
		}
		m["Buy10"] = m["Buy:"]
		m["Sell10"] = m["Sell:"]
		delete(m, "Buy:")
		delete(m, "Sell:")
		b, _ := json.Marshal(m)
		z.Write(append(b, '\n'))
	}
	z.Close()
	f.Close()
	b, _ := os.ReadFile(path)
	h := sha256.Sum256(b)
	s := Scene118{Session: "s", Contract: "X", Start: 100, End: 5000, ForceClose: 4900, Raw: FileRef{Path: path, SHA256: hex.EncodeToString(h[:])}, ExpectedAccepted: 3, Signals: []Signal118{{ID: "id", Method: "m", Side: 1, Time: 100, Index: 0, Line: 1, Quote: quotes[0]}}, Cancellations: []Cancel118{{SignalID: "id", Method: "m", Time: 102, Index: 2, Line: 3, Quote: quotes[2]}}}
	r, e := scan118([]Scene118{s}, 0)
	if e != nil || !r.Success {
		t.Fatalf("手製配送 %v", e)
	}
	for _, c := range r.Candidates {
		if c.Policy == "M0" && c.Status != "filled" {
			t.Fatal("約定済みを取消")
		}
		if c.Policy == "L50" && c.Status != "source_cancelled" {
			t.Fatal("取消前に指値約定")
		}
	}
}
