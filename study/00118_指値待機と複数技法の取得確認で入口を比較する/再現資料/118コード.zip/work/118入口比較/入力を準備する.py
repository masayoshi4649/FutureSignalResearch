"""許可115/117の保存Nativeから、新入口評価の出生と当時公表だけを抽出する。"""

import gc
import gzip
import hashlib
import json
from decimal import Decimal
from pathlib import Path
import sys

sys.stdout.reconfigure(encoding="utf-8")
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
REFERENCES = {
    "completion115": (ROOT / "work/115金融F1/全70場/完了.json", "8bba68dfa7df62d2fa7f40443e4a3cd89f48caa7ed398560ca1ee914e59e714b"),
    "completion117": (ROOT / "work/117金融F1/全70場/完了.json", "f9d5dfc49bef7f9b2dcf6bba55fe264b689dc2e8312e0e26c4530e4b1d2872e0"),
    "manifest": (ROOT / "study/00106_収束失速で保護の起動と幅を切り替える/入力台帳_70場.json", "902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8"),
    "relocation": (ROOT / "inputs/105生成原板/保存の確認.json", "7b4564fc7639afe4c831c3caa84789126a92ddfbdc84aeb6399ed0754c0bcec3"),
}


def need(condition, message):
    """
    機能: 不整合を補完せず停止する。
    引数: condition(bool)、message(str)は成立条件と説明。
    返り値: None。不成立はValueError。
    """
    if not condition:
        raise ValueError(message)


def digest(path):
    """
    機能: 許可されたmetadata又はNativeのSHAを求める。
    引数: path(Path)は明示許可入力。
    返り値: strはSHA256。原板へは使わない。
    """
    h = hashlib.sha256()
    with path.open("rb") as stream:
        while chunk := stream.read(1024 * 1024):
            h.update(chunk)
    return h.hexdigest()


def load_metadata(path, expected, before):
    """
    機能: 4種類の許可小metadataを認証して読む。
    引数: path(Path)、expected(str)、before(dict)は位置・期待SHA・台帳。
    返り値: dictはJSON数値をDecimalで保持した値。
    """
    need(digest(path) == expected, "metadata SHA差:" + str(path))
    before[str(path)] = expected
    return json.loads(path.read_text(encoding="utf-8"), parse_float=Decimal)


def load_native(ref, before):
    """
    機能: 認証済みcompletionに列挙されたNativeだけを復号する。
    引数: ref(dict)、before(dict)は明示参照と指紋集合。
    返り値: dictは保存Native。価格原板やCSVは開かない。
    """
    path = Path(ref["path"])
    need(path.is_absolute() and path.name.endswith(".Native.json.gz"), "Native参照形式")
    data = path.read_bytes()
    need(hashlib.sha256(data).hexdigest() == ref["sha256"], "Native SHA差:" + str(path))
    before[str(path)] = ref["sha256"]
    return json.loads(gzip.decompress(data), parse_float=Decimal)


def canonical_method(method):
    """
    機能: Source本来の3手法名を正式名として照合する。
    引数: method(str)は保存手法名。
    返り値: strはNK225接頭辞付き名。不明は拒否する。
    """
    result = method if method.startswith("NK225_") else "NK225_" + method
    need(result in ("NK225_D164_15", "NK225_P164_06", "NK225_U165_03"), "対象外Source手法")
    return result


def birth_identity(method, signal_id):
    """
    機能: 同じ場のSource出生を手法namespace付きで識別する。
    引数: method(str)、signal_id(str)は保存ID。
    返り値: tuple[str,str]は場内キー。
    """
    return canonical_method(method), signal_id


def extract_scene(sid, first, current, raw, native_refs):
    """
    機能: Source全同体を確認し、出生・明示取消・全公表を抽出する。
    引数: sid(str)、first/current(dict)は115/117、raw(dict)は未読価格参照、native_refs(dict)は由来。
    返り値: dictは入口だけのScene。旧返済/損益/新評価結果は含まない。
    """
    need(first["trial"] == 115 and current["trial"] == 117, "Native試行差")
    old_source, source = first["source"], current["source"]
    need(old_source == source, "115/117 Source JSON全文差:" + sid)
    need(source["trial"] == 111 and source["complete"] is True, "元Source成功")
    a115, actual = first["actual"], current["actual"]
    need(a115["complete"] is True and actual["complete"] is True, "外Actor完結")
    need(a115["scope"] == actual["scope"], "SourceCase/normalizations差:" + sid)
    session = actual["scope"]["session"]
    need(session["id"] == sid and source["session"] == session and source["contract"] == actual["scope"]["contract"], "場/限月差")
    need(a115["counts"]["rows"] == actual["counts"]["rows"], "115/117全受理行数差")
    need(a115["counts"]["bad_quotes"] == actual["counts"]["bad_quotes"], "115/117異常BBO数差")
    book = actual["books"]["S0_C0_D0"]
    accepted, filled = {}, {}
    for order in book["orders"]:
        if order["kind"] != "entry":
            continue
        key = birth_identity(order["source"]["method"], order["source"]["signal_id"])
        need(key not in accepted, "S0同出生のentry order重複")
        accepted[key] = {"order_id": order["id"], "quantity": order["quantity"]}
    for position in book["positions"]:
        key = birth_identity(position["source"]["method"], position["source"]["signal_id"])
        need(key not in filled and key in accepted, "S0 Positionと受理注文の出生差")
        filled[key] = {"position_id": position["id"], "entry_order_id": position["entry_order_id"]}
        need(position["entry_order_id"] == accepted[key]["order_id"], "S0取得注文ID差")
    signals, cancellations, births = [], [], set()
    ledgers = [(key, ledger) for key, ledger in source["sources"].items() if key.startswith("NK225mini_")]
    need(bool(ledgers), "mini Source台帳なし")
    for ledger_key, ledger in sorted(ledgers):
        product, method = ledger["config"]["product"], canonical_method(ledger["method"])
        need(product == "NK225mini", "mini台帳の商品差")
        source_fills = {}
        for record in ledger["fills"]:
            if record["action"] != "new":
                continue
            fill = record["fill"]
            need(fill["SignalID"] not in source_fills, "Source新規fill重複")
            source_fills[fill["SignalID"]] = {"signal_id": fill["SignalID"], "execution_id": fill["ExecutionID"], "hold_id": fill["HoldID"], "time": fill["Time"], "price": fill["Price"], "quantity": fill["Quantity"], "quote": record["quote"]}
        source_holds = {h["hold_id"]: h for h in ledger["holds"]}
        for record in ledger["signals"]:
            signal = record["signal"]
            if signal["action"] != "new":
                continue
            key = birth_identity(method, signal["id"])
            need(key not in births, "Source同出生重複")
            births.add(key)
            quote = record["quote"]
            need(record["at"] == signal["time"] == quote["time"] and signal["source_index"] == quote["index"], "出生原行差")
            need(session["start"] <= record["at"] <= session["end"] and signal["side"] in (-1, 1), "出生時計/方向")
            row = dict(record)
            row.update(id=signal["id"], method=method, product=product, side=signal["side"], time=record["at"], index=quote["index"], source_line=quote["source_line"], quote=quote, accepted_s0=key in accepted, filled_s0=key in filled)
            row["birth_key"] = [sid, product, method, signal["id"]]
            row["reference_s0_entry"] = {**accepted.get(key, {}), **filled.get(key, {})}
            paper_fill = source_fills.get(signal["id"])
            row["source_paper_entry_fill"] = paper_fill
            row["source_paper_hold"] = None
            if paper_fill is not None:
                hold = source_holds[paper_fill["hold_id"]]
                row["source_paper_hold"] = {name: hold[name] for name in ("hold_id", "internal_id", "entry_id", "parent", "source_id", "kind", "side", "initial_quantity", "entry_price", "entry_quote")}
                need(hold["entry_price"] == paper_fill["price"] and hold["entry_quote"] == paper_fill["quote"], "Source entry fill/hold差")
            signals.append(row)
        for record in ledger["cancellations"]:
            key = birth_identity(method, record["signal_id"])
            need(key in births, "取消の出生未同定")
            quote = record["quote"]
            need(record["at"] == quote["time"], "取消時計差")
            row = dict(record)
            row.update(method=method, product=product, time=record["at"], index=quote["index"], source_line=quote["source_line"], quote=quote)
            cancellations.append(row)
    need(set(accepted) <= births and set(filled) <= births, "元S0受理/取得のSource母集団欠落")
    signals.sort(key=lambda row: (row["index"], row["source_line"], row["method"]))
    cancellations.sort(key=lambda row: (row["index"], row["source_line"], row["method"]))
    publications = a115["entry_publications"]
    for publication in publications:
        stamp = publication["stamp"]
        need(session["start"] <= stamp["time"] <= session["end"] and 0 <= stamp["index"] < actual["counts"]["rows"] and stamp["source_line"] > 0, "公表原行の場/Index差")
    return {"session": sid, "contract": source["contract"], "start": session["start"], "end": session["end"], "force_close": session["force_close"], "raw": raw, "expected_accepted": actual["counts"]["rows"], "publications": publications, "signals": signals, "cancellations": cancellations, "native_refs": native_refs, "source_json_equal_115_117": True, "source_rows_equal_115_117": True}


# ----------------------------------------
def write_value(stream, value):
    """
    機能: Decimalを文字列やfloatへ変換せずJSONの数値として出力する。
    引数: stream(TextIO)、value(JSON型|Decimal)は出力先と値。
    返り値: None。115公表のJSON数値を保持する。
    """
    if isinstance(value, Decimal):
        need(value.is_finite(), "非有限Decimal")
        stream.write(str(value))
    elif isinstance(value, dict):
        stream.write("{")
        for index, (key, item) in enumerate(value.items()):
            if index:
                stream.write(",")
            stream.write(json.dumps(key, ensure_ascii=False) + ":")
            write_value(stream, item)
        stream.write("}")
    elif isinstance(value, list):
        stream.write("[")
        for index, item in enumerate(value):
            if index:
                stream.write(",")
            write_value(stream, item)
        stream.write("]")
    else:
        stream.write(json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":")))


def main():
    """
    機能: 許可70場を一場ずつ抽出し、認証後だけ新しい入力.jsonを保存する。
    引数: なし。明示された4metadataと両completionのNativeだけ読む。
    返り値: None。原板/価格CSV/結果計算/新金融は実行しない。
    """
    target = HERE / "入力.json"
    need(not target.exists(), "入力.jsonは新規先のみ")
    before = {str(Path(__file__).resolve()): digest(Path(__file__).resolve())}
    metadata = {name: load_metadata(path, expected, before) for name, (path, expected) in REFERENCES.items()}
    cm115, cm117 = metadata["completion115"], metadata["completion117"]
    for trial, completion in ((115, cm115), (117, cm117)):
        need(completion["trial"] == trial and completion["stage"] == "full70" and completion["success"] is True and completion["sessions"] == 70 and completion["unchanged"] is True and completion["before"] == completion["after"], "全70成功metadata")
    manifest = metadata["manifest"]
    need(len(manifest["sessions"]) == len(cm115["results"]) == len(cm117["results"]) == 70, "70場集合")
    relocated = {row["session"]: row["canonical"] for row in metadata["relocation"]["files"]}
    need(metadata["relocation"]["成功"] is True and metadata["relocation"]["manifest"]["sha256"] == REFERENCES["manifest"][1], "恒久移設の由来")
    scenes = []
    for index, (r115, r117, inp) in enumerate(zip(cm115["results"], cm117["results"], manifest["sessions"])):
        sid = inp["id"]
        need(sid == r115["session"] == r117["session"] and "2026-09-21_Day" <= sid <= "2026-11-06_Night", "場順/許可期間")
        source_ref = inp["files"]["NK225_book"]
        raw = {"path": str(Path(manifest["source_root"]) / source_ref["path"]), "sha256": source_ref["sha256"]}
        if sid in relocated:
            need(relocated[sid]["sha256"] == raw["sha256"], "移設は同SHAでpathだけ変更")
            raw["path"] = relocated[sid]["path"]
        first = load_native(r115["native"], before)
        current = load_native(r117["native"], before)
        scenes.append(extract_scene(sid, first, current, raw, {"trial115": r115["native"], "trial117": r117["native"]}))
        del first, current
        gc.collect()
        print(f"{index+1}/70 {sid} Source全文/公表/出生を確認", flush=True)
    totals = {"scenes": len(scenes), "births": sum(len(scene["signals"]) for scene in scenes), "accepted_s0": sum(row["accepted_s0"] for scene in scenes for row in scene["signals"]), "filled_s0": sum(row["filled_s0"] for scene in scenes for row in scene["signals"]), "cancellations": sum(len(scene["cancellations"]) for scene in scenes), "publications": sum(len(scene["publications"]) for scene in scenes)}
    need(totals["filled_s0"] == 558, "元558実取得の対応")
    after = {path: digest(Path(path)) for path in before}
    need(before == after, "metadata/コード/Native前後SHA差")
    output = {"version": 1, "trial": 118, "入力準備成功": True, "入力の固定と条件の固定は別": True, "scenes": scenes, "totals": totals, "Source全文115_117同体": True, "入力SHA256": before, "後SHA256": after, "前後不変": True, "price_paths_read": False, "Raw読取": 0, "価格CSV読取": 0, "金融再実行": False, "新評価結果": False, "11月09読取": False, "candidate_population": "全NK225mini Source新規Signal。accepted_s0とfilled_s0は診断用対応flagであり新入口の選別条件にしない。", "candidate_lifetime": "独立TTL15分。Source明示new cancellationは優先取消。旧Source paper closeを候補取消に使用しない。", "source_paper_mapping_scope": "元new fill/holdの取得IDと取得値だけ。旧退出・損益・保有結果は出力しない。", "source_signal_evidence_scope": "原new Signalと出生時Evidenceを保持。新取引のprofit/outcomeを評価しない。"}
    with target.open("x", encoding="utf-8", newline="\n") as stream:
        write_value(stream, output)
        stream.write("\n")
    print(json.dumps({"成功": True, "入力": str(target), "sha256": digest(target), **totals}, ensure_ascii=False))


if __name__ == "__main__":
    main()
