# 119入口比較のCSV出力

Rootが確定したJSONの`tables`四表を転記する。独立1miniの入口試験・固定期限評価を扱い、重複するケースを片側上限10枚の運用口座収支へ合算しない。集計、率、費用、観測不足の定義は入力表を保持し、出力器では金融計算や分母の変更を行わない。

入力は`{tables:[{name,headers,rows},...]}`。表名は`候補別集計`、`幅別先着率`、`全候補明細`、`全70場集計`の四つ。ヘッダはJSONから順序・表記を維持し、行順も変更しない。セルは文字列・有限数値・boolean・nullで、安全整数範囲外は拒否する。率はJSONとCSVともに0〜1の数値で、0.7は70%を意味する。表示用に100倍せず、未定義率は空欄を保つ。

Node 24.22.1、artifact-tool 2.8.129を固定する。`node_modules`は既存runtime依存先へのjunctionで、依存自体は変更しない。市場結果・自然Raw・Native・入力.json・11/09はこの準備で読まない。

## Rootによる自然出力

JSONとSHA256を固定してから、自然データでの最初の作成直前にRootが`create/4/csv`の操作記録を一度だけ実行する。成果CSV四点に対応するため出力予定数は4。同じ作成操作の再試行では記録を重ねない。builderと独立再読器は操作記録を自動実行しない。人工データによる専用work内の試験では自然出力用の操作記録を実行しない。

```powershell
$nodeExe = 'C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
& $nodeExe 'C:/Users/masay/.codex/plugins/cache/openai-primary-runtime/spreadsheets/26.1104.22356/skills/spreadsheets/container_tools/mark_artifact_operation_started.mjs' --operation-kind create --expected-output-count 4 --output-format csv
& $nodeExe 'work/119入口CSV出力/出力する.mjs' --input 'Rootの確定表.json' --sha256 '64桁SHA256' --output 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/119入口比較CSV'
C:/Python314/python.exe -X utf8 'work/119入口CSV出力/CSVを独立再読する.py' --input 'Rootの確定表.json' --sha256 '64桁SHA256' --folder 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/119入口比較CSV' --output 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/119入口比較CSV/CSVの独立再読.json'
```

出力先は未作成であることを要求し、既存成果物へ上書きしない。CSVはUTF-8 BOM・CRLF。nullは空欄、数値0は`0`、booleanは小文字`true`/`false`とする。文字列の先頭零・改行・引用符は元の値を保持する。

## 検査

四表を型付きでWorkbookへ投入し、再計算、各表inspect、数式エラー走査、ヘッダを含む全セルの型・値照合を終えてから保存する。所与の数値を再集計する数式やxlsxは作らない。元のJSONに`#N/A`等の文字列があれば同じ文字として保持し、検査数を記録する。

各表のA1:H5以内を`支援画像/表名.png`へ描画し、Rootが自然作成後に視認する。`CSVの確認.json`は入力SHA・前後不変、出力SHA・行列数、全セル数、エラー走査、依存版を持つ。人工プレビューの成功は自然成果物の視認完了を意味しない。

独立再読器は標準`csv`と`Decimal`で、指定JSONと四CSVだけを再読する。数値は許容差なしの完全一致、文字列も完全一致。nullと数値0を分け、全入力の前後SHAを確認する。CSV単体ではnullと空文字は区別できないため、照合は元JSONの型を基準にする。
