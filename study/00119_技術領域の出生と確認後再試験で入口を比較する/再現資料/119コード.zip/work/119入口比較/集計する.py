"""技術領域から独立に生んだ入口の同幅先着を集計する。"""
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from statistics import mean, median
import hashlib
import json
import math

OWN = Path(__file__).resolve().parent
JST = timezone(timedelta(hours=9))
WIDTHS = (25, 50, 100, 125, 200)
HORIZONS = (1800, 3600)


def avg(values: list) -> float | None:
    """
    機能: 空集団を0で補わず平均する。
    引数: values(list[number])。返り値: float|None。
    """
    return mean(values) if values else None


def jst(value: float | None) -> str | None:
    """
    機能: 価格時計をJST表記にする。
    引数: value(float|None)。返り値: str|None。受信時計ではない。
    """
    return None if value is None else datetime.fromtimestamp(value, JST).strftime('%Y-%m-%d %H:%M:%S')


def validate(c: dict, scene: dict) -> int:
    """
    機能: 役割・イベント・注文・期限評価の保存証拠を照合する。
    引数: c/scene(dict)。返り値: intは完了評価数。Raw再走査は行わない。
    """
    zone = scene['events'][c['zone_event']]
    assert zone['kind'] == 'zone' and zone['id'] == c['birth']['id']
    assert zone['mode'] == c['mode'] and zone['side'] == c['birth']['side']
    assert zone['current']['time'] == c['birth']['time']
    if c['confirm_event'] is not None:
        event = scene['events'][c['confirm_event']]
        assert event['kind'] == 'confirm' and event['id'] == zone['id'] and event['decision']['truth'] == 2
    if c['entry'] is None:
        assert c['entry_price'] is None and not c['outcomes'] and c['status'] != 'filled'
        return 0
    q, request, side = c['entry'], c['request'], c['birth']['side']
    assert c['status'] == 'filled' and q['quote_ok'] and 0 < q['bid'] < q['ask']
    assert q['index'] > request['index'] and q['source_line'] > request['source_line'] and q['time'] >= request['time'] + 1
    assert q['time'] < c['expires'] and c['last_background'][c['mode'].removeprefix('T')]['background'] == 2
    if c['role'] == 'zone':
        assert (request['time'], request['index'], request['source_line']) == (zone['current']['time'], zone['current']['index'], zone['current']['source_line'])
    else:
        assert c['confirm_event'] is not None
        event = scene['events'][c['confirm_event']]
        assert (request['time'], request['index'], request['source_line']) == (event['current']['time'], event['current']['index'], event['current']['source_line'])
    if c['order_style'] == 'market':
        assert c['entry_price'] == (q['ask'] if side == 1 else q['bid'])
    else:
        boundary = event['decision']['fields']['confirm5_boundary']['value']
        target = (math.floor(boundary / 5) if side == 1 else math.ceil(boundary / 5)) * 5
        assert c['role'] == 'retest' and c['limit'] == target == c['entry_price']
        assert side * ((q['ask'] if side == 1 else q['bid']) - target) <= -10
    checked = 0
    assert [o['seconds'] for o in c['outcomes']] == list(HORIZONS)
    for o in c['outcomes']:
        assert o['deadline'] == q['time'] + o['seconds']
        assert [t['width'] for t in o['touches']] == list(WIDTHS)
        for t in o['touches']:
            assert t['direction'] in (-1, 0, 1)
            if not t['direction']:
                assert t['quote'] is None
            else:
                p = t['quote']
                assert p['index'] > q['index'] and p['source_line'] > q['source_line'] and q['time'] <= p['time'] <= o['deadline']
                assert t['direction'] * side * ((p['bid'] if side == 1 else p['ask']) - c['entry_price']) >= t['width']
                if o['endpoint']:
                    assert p['index'] <= o['endpoint']['index']
        if o['status'] == 'complete':
            e = o['endpoint']
            assert o['deadline'] <= e['time'] <= o['deadline'] + 30 and e['quote_ok'] and 0 < e['bid'] < e['ask']
            points = side * ((e['bid'] if side == 1 else e['ask']) - c['entry_price'])
            assert (o['points'], o['net0'], o['net5']) == (points, points * 100 - 77, points * 100 - 1077)
            checked += 1
        else:
            assert all(o[k] is None for k in ('endpoint', 'points', 'net0', 'net5'))
    return checked


def stats(cases: list, seconds: int, baseline: dict) -> dict:
    """
    機能: 全出生・未約定・観測不足を残し、同幅先着と同出生対照を集計する。
    引数: cases(list[dict])、seconds(int)、baseline(dict)。返り値: dict。
    """
    entered = [c for c in cases if c['entry'] is not None]
    observed = [(c, next(o for o in c['outcomes'] if o['seconds'] == seconds)) for c in entered]
    complete = [(c, o) for c, o in observed if o['status'] == 'complete']
    n0, n5 = [o['net0'] for _, o in complete], [o['net5'] for _, o in complete]
    touches = {}
    for width in WIDTHS:
        counts = Counter(next(t['direction'] for t in o['touches'] if t['width'] == width) for _, o in complete)
        win, loss, neither = counts[1], counts[-1], counts[0]
        resolved = win + loss
        rate = win / resolved if resolved else None
        # ----------------------------------------
        # 同じ場・同じ波の依存があるため、二項区間は参考値としてのみ保存する。
        lower = None
        if resolved:
            z2 = 1.959963984540054 ** 2
            lower = (rate + z2 / (2 * resolved) - 1.959963984540054 * math.sqrt(rate * (1 - rate) / resolved + z2 / (4 * resolved ** 2))) / (1 + z2 / resolved)
        touches[str(width)] = {'favorable': win, 'adverse': loss, 'neither': neither, 'resolved': resolved, 'resolved_rate': rate, 'all_complete_favorable_rate': win / len(complete) if complete else None, 'reference_binomial_lower95': lower, 'target70_resolved': rate >= .7 if rate is not None else None, 'target70_all_complete': win / len(complete) >= .7 if complete else None}
    pairs = []
    for c, o in complete:
        b = baseline[(c['session'], c['birth']['id'])]
        other = next((x for x in b['outcomes'] if x['seconds'] == seconds and x['status'] == 'complete'), None)
        if other is not None:
            pairs.append({'baseline': other['net5'], 'candidate': o['net5'], 'delta': o['net5'] - other['net5'], 'price_improvement': c['birth']['side'] * (b['entry_price'] - c['entry_price'])})
    return {'births': len(cases), 'eligible_births': sum(c['expires'] > c['birth']['time'] for c in cases), 'requested': sum(c['request'] is not None for c in cases), 'filled': len(entered), 'complete': len(complete), 'censored': len(entered) - len(complete), 'filled_sessions': len({c['session'] for c in entered}), 'complete_sessions': len({c['session'] for c, _ in complete}), 'states': dict(Counter(c['status'] for c in cases)), 'observations': dict(Counter(o['status'] for _, o in observed)), 'touches': touches, 'mean_net0': avg(n0), 'mean_net5': avg(n5), 'median_net5': median(n5) if n5 else None, 'positive_net5': sum(v > 0 for v in n5), 'negative_net5': sum(v < 0 for v in n5), 'pairs': len(pairs), 'paired_zone_mean_net5': avg([p['baseline'] for p in pairs]), 'paired_candidate_mean_net5': avg([p['candidate'] for p in pairs]), 'paired_mean_delta': avg([p['delta'] for p in pairs]), 'paired_mean_price_improvement': avg([p['price_improvement'] for p in pairs])}


def label(o: dict | None, width: int) -> str:
    """
    機能: 未約定・観測不足と順逆の先着を区別して表示する。
    引数: o(dict|None)、width(int)。返り値: str。
    """
    if o is None:
        return '対象外（未約定）'
    direction = next(t['direction'] for t in o['touches'] if t['width'] == width)
    if o['status'] != 'complete':
        return '打切前順行' if direction == 1 else '打切前逆行' if direction == -1 else '観測不足'
    return '順行先着' if direction == 1 else '逆行先着' if direction == -1 else '両方未到達'


def main() -> None:
    """
    機能: 全70場から候補別・幅別・全候補・全場の閲覧表を保存する。
    引数: なし。返り値: None。閾値や採用条件を結果から書き換えない。
    """
    source = OWN / '全70場の入口結果.json'
    value = json.loads(source.read_text(encoding='utf-8'))
    assert value['trial'] == 119 and value['success'] and not value['source_signals_used'] and len(value['scenes']) == 70
    rows, events, checked = [], Counter(), 0
    for index, scene in enumerate(value['scenes']):
        assert scene['success'] and not scene['source_signals_used']
        events.update(e['kind'] for e in scene['events'])
        for c in scene['candidates']:
            c['session'] = scene['session']
            c['history'] = '元54場' if index < 54 else '追加16場'
            checked += validate(c, scene)
            rows.append(c)
    assert len(rows) == 3 * events['zone']
    baseline = {(c['session'], c['birth']['id']): c for c in rows if c['role'] == 'zone'}
    aggregate = {p: {str(h): stats([c for c in rows if c['policy'] == p], h, baseline) for h in HORIZONS} for p in value['policies']}
    groups = {}
    for group, values in (('side', (-1, 1)), ('history', ('元54場', '追加16場')), ('session', [s['session'] for s in value['scenes']])):
        groups[group] = {}
        for g in values:
            cases = [c for c in rows if (c['birth']['side'] if group == 'side' else c[group]) == g]
            groups[group][str(g)] = {p: {str(h): stats([c for c in cases if c['policy'] == p], h, baseline) for h in HORIZONS} for p in value['policies']}
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    result = {'試行': 119, '成功': True, '元結果SHA256': digest, 'イベント件数': dict(events), '独立期限算術検査数': checked, '集計': aggregate, '群別': groups, '口座収支': False, '未約定0円補完': False, 'Source通知使用': False, '参考二項区間の独立性': '同場・同波の依存を無視するため保証には使えない'}
    with (OWN / '集計.json').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
    summary_headers = ['試行','候補','評価時間分','全出生','出生時新規可能数','要求数','約定代用数','評価完了数','観測不足数','評価完了場数','C0期限評価平均円','C5期限評価平均円','C5期限評価中央値円','C5正評価数','C5負評価数','同出生対照完了組数','同組領域入口C5平均円','同組候補C5平均円','同組C5平均差円','同組取得価格平均改善pt']
    summary, reaches, details, scenes = [], [], [], []
    for p in value['policies']:
        for h in HORIZONS:
            s = aggregate[p][str(h)]
            summary.append([119,p,h/60,*[s[k] for k in ('births','eligible_births','requested','filled','complete','censored','complete_sessions','mean_net0','mean_net5','median_net5','positive_net5','negative_net5','pairs','paired_zone_mean_net5','paired_candidate_mean_net5','paired_mean_delta','paired_mean_price_improvement')]])
            for width in WIDTHS:
                t = s['touches'][str(width)]
                reaches.append([119,p,h/60,width,s['births'],s['filled'],s['complete'],s['censored'],t['favorable'],t['adverse'],t['neither'],t['resolved_rate'],t['all_complete_favorable_rate'],t['reference_binomial_lower95'],'到達' if t['target70_resolved'] else '未達' if t['target70_resolved'] is not None else '評価不能','到達' if t['target70_all_complete'] else '未達' if t['target70_all_complete'] is not None else '評価不能'])
    for c in rows:
        for h in HORIZONS:
            o = next((o for o in c['outcomes'] if o['seconds'] == h), None)
            details.append([119,c['session'],c['history'],c['mode'],c['birth']['id'],'買' if c['birth']['side']==1 else '売',c['role'],c['policy'],h/60,c['status'],jst(c['birth']['time']),jst(c['request']['time']) if c['request'] else None,c['limit'],jst(c['entry']['time']) if c['entry'] else None,c['entry_price'],o['status'] if o else 'not_entered',jst(o['deadline']) if o else None,jst(o['endpoint']['time']) if o and o['endpoint'] else None,o['points'] if o else None,o['net0'] if o else None,o['net5'] if o else None,*[label(o,w) for w in WIDTHS]])
    for session, policies in groups['session'].items():
        for p in value['policies']:
            for h in HORIZONS:
                s = policies[p][str(h)]
                t = s['touches']['100']
                scenes.append([119,session,p,h/60,s['births'],s['filled'],s['complete'],s['censored'],t['favorable'],t['adverse'],t['neither'],t['resolved_rate'],s['mean_net5']])
    tables = {'試行':119,'成功':True,'result_sha256':digest,'意味':'独立1mini入口試験。同幅先着70%を目指す診断。口座収支・IFD実約定の結果ではない。','tables':[{'name':'候補別集計','headers':summary_headers,'rows':summary},{'name':'幅別先着率','headers':['試行','候補','評価時間分','同幅pt','全出生','約定代用数','評価完了数','観測不足数','順行先着','逆行先着','両方未到達','到達済み分母順行率','全評価完了分母順行率','参考二項95下限','到達済み70%','全評価完了70%'],'rows':reaches},{'name':'全候補明細','headers':['試行','セッション','期間区分','方式','出生ID','方向','役割','候補','評価時間分','新規状態','出生JST','注文要求JST','指値','約定代用JST','新規価格','観測状態','評価期限JST','期限評価原行JST','期限価格差pt','C0期限清算評価円','C5期限清算評価円','25pt先着','50pt先着','100pt先着','125pt先着','200pt先着'],'rows':details},{'name':'全70場集計','headers':['試行','セッション','候補','評価時間分','全出生','約定代用数','評価完了数','観測不足数','100pt順行先着','100pt逆行先着','100pt未到達','100pt到達済み分母順行率','C5期限評価平均円'],'rows':scenes}]}
    for table in tables['tables']:
        assert all(len(r) == len(table['headers']) for r in table['rows'])
    with (OWN / 'CSV用の表.json').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(tables, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'成功':True,'イベント件数':dict(events),'候補数':len(rows),'60分':{p:aggregate[p]['3600'] for p in value['policies']}}, ensure_ascii=False))


if __name__ == '__main__':
    main()
