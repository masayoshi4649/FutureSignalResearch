package holdingohlc113

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"

	birth "github.com/masayoshi4649/SessionTradeExecuter/entrybirth119"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// testQuote119 は手製原行を作ります。
//
// 引数: at(float64)、index(int64)、bid/ask(float64)。返り値: Quoteは正常値です。
func testQuote119(at float64, index int64, bid, ask float64) Quote {
	return Quote{Time: at, Index: index, SourceLine: index + 1, Last: (bid + ask) / 2, Bid: bid, Ask: ask, QuoteOK: true}
}

// testEvent119 は手製の技術出生又は確認イベントを作ります。
//
// 引数: kind(birth.Kind)、side(int)、born/current(Quote)。返り値: birth.Eventです。
func testEvent119(kind birth.Kind, side int, born, current Quote) birth.Event {
	return birth.Event{Kind: kind, ID: fmt.Sprintf("s/Ttrend/%d/000001", side), Scope: birth.Scope{SessionID: "s", Contract: "X"}, Mode: rules.Ttrend, Side: side, Born: quote119(born), Current: quote119(current), Watch: rules.Watch{SessionID: "s", Contract: "X", Side: side}, Decision: rules.Decision{Mode: rules.Ttrend, Side: side, At: quote119(current), Truth: rules.True, Trend: rules.Branch{Background: rules.True}, Fields: map[string]rules.Value{"confirm5_boundary": {Known: true, Value: 1003}}}}
}

// TestZoneConfirmDelay119 は別時点のzone/confirm要求と後原行1秒を鏡像で検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestZoneConfirmDelay119(t *testing.T) {
	for _, side := range []int{1, -1} {
		q := testQuote119(100, 0, 990, 1010)
		e := testEvent119(birth.Zone, side, q, q)
		s := Scene119{Session: "s", Contract: "X", ForceClose: 5000}
		waves := map[string][]*Candidate119{}
		cs, err := applyEvent119(e, q, 0, s, waves)
		if err != nil || len(cs) != 3 {
			t.Fatal(err)
		}
		if cs[0].Expires != 130 || cs[1].Request != nil || cs[2].Request != nil {
			t.Fatal("zoneと確認待ちの混同")
		}
		x := testQuote119(100, 1, 990, 1010)
		if fillable119(cs[0], x) {
			t.Fatal("同秒取得")
		}
		x.Time = 101
		x.Index = 0
		if fillable119(cs[0], x) {
			t.Fatal("同原行取得")
		}
		x.Index = 1
		if !fillable119(cs[0], x) {
			t.Fatal("後行1秒取得")
		}
		confirm := testQuote119(110, 10, 990, 1010)
		e = testEvent119(birth.Confirm, side, q, confirm)
		if _, err = applyEvent119(e, confirm, 1, s, waves); err != nil {
			t.Fatal(err)
		}
		if cs[1].Request.Time != 110 || cs[1].Expires != 140 || cs[2].Expires != 410 || cs[1].ConfirmEvent == nil {
			t.Fatal("確認時計/TTL")
		}
		if fillable119(cs[1], confirm) {
			t.Fatal("確認同原行fill")
		}
		next := testQuote119(111, 11, 990, 1010)
		if !fillable119(cs[1], next) {
			t.Fatal("確認後fill")
		}
		fill119(cs[1], next)
		want := next.Ask
		if side < 0 {
			want = next.Bid
		}
		if *cs[1].EntryPrice != want {
			t.Fatal("成行の反対気配")
		}
	}
}

// TestRetestRoundingAndCross119 は買floor5/売ceil5と反対BBO10pt通過を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestRetestRoundingAndCross119(t *testing.T) {
	for _, side := range []int{1, -1} {
		q := testQuote119(100, 0, 990, 1010)
		s := Scene119{Session: "s", Contract: "X", ForceClose: 5000}
		waves := map[string][]*Candidate119{}
		cs, _ := applyEvent119(testEvent119(birth.Zone, side, q, q), q, 0, s, waves)
		at := testQuote119(200, 1, 990, 1010)
		if _, err := applyEvent119(testEvent119(birth.Confirm, side, q, at), at, 1, s, waves); err != nil {
			t.Fatal(err)
		}
		c := cs[2]
		want := 1000.0
		if side < 0 {
			want = 1005
		}
		if *c.Limit != want {
			t.Fatal("指値丸め")
		}
		x := testQuote119(201, 2, want-10, want)
		if side < 0 {
			x = testQuote119(201, 2, want, want+10)
		}
		if fillable119(c, x) {
			t.Fatal("反対気配等号だけ")
		}
		if side > 0 {
			x = testQuote119(201, 2, want-20, want-10)
		} else {
			x = testQuote119(201, 2, want+10, want+20)
		}
		if !fillable119(c, x) {
			t.Fatal("反対気配通過")
		}
		fill119(c, x)
		if *c.EntryPrice != want {
			t.Fatal("有利気配へ価格改善した")
		}
	}
}

// TestCancellationAndFilledSurvival119 は取消をfillより優先し既取得は撤回しないことを検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestCancellationAndFilledSurvival119(t *testing.T) {
	q := testQuote119(100, 0, 990, 1010)
	s := Scene119{Session: "s", Contract: "X", ForceClose: 5000}
	waves := map[string][]*Candidate119{}
	cs, _ := applyEvent119(testEvent119(birth.Zone, 1, q, q), q, 0, s, waves)
	fill119(cs[0], testQuote119(101, 1, 990, 1010))
	confirm := testQuote119(110, 10, 990, 1010)
	if _, err := applyEvent119(testEvent119(birth.Confirm, 1, q, confirm), confirm, 1, s, waves); err != nil {
		t.Fatal(err)
	}
	cancel := testQuote119(111, 11, 900, 910)
	if _, err := applyEvent119(testEvent119(birth.Invalidate, 1, q, cancel), cancel, 2, s, waves); err != nil {
		t.Fatal(err)
	}
	if err := pending119(cs[1], cancel, 5000, nil); err != nil {
		t.Fatal(err)
	}
	if cs[0].Status != "filled" || cs[1].Status != "wave_invalidate" || cs[2].Entry != nil || cs[0].Outcomes[0].Status != "pending" {
		t.Fatal("取消が既約定へ侵入又は未約定がfill")
	}
	c := new119(testEvent119(birth.Zone, 1, q, q), q, 0, 100)[0]
	if c.Request != nil || c.Status != "force_close" {
		t.Fatal("force後に新規")
	}
	c = new119(testEvent119(birth.Zone, 1, q, q), q, 0, 5000)[0]
	if err := pending119(c, testQuote119(130, 3, 990, 1010), 5000, nil); err != nil || c.Status != "unfilled_expired" {
		t.Fatal("期限等号で取得")
	}
}

// TestScopeAndWaveIdentity119 は場と出生・確認の複合同体及び重複を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestScopeAndWaveIdentity119(t *testing.T) {
	q := testQuote119(100, 0, 990, 1010)
	e := testEvent119(birth.Zone, 1, q, q)
	s := Scene119{Session: "s", Contract: "X", ForceClose: 5000}
	waves := map[string][]*Candidate119{}
	if _, err := applyEvent119(e, q, 0, s, waves); err != nil {
		t.Fatal(err)
	}
	if _, err := applyEvent119(e, q, 1, s, waves); err == nil {
		t.Fatal("同波重複")
	}
	e.Scope.Contract = "Y"
	if _, err := applyEvent119(e, q, 1, s, map[string][]*Candidate119{}); err == nil {
		t.Fatal("異限月")
	}
	x := testQuote119(110, 2, 990, 1010)
	e = testEvent119(birth.Confirm, 1, q, x)
	e.Born.Last++
	if _, err := applyEvent119(e, x, 2, s, waves); err == nil {
		t.Fatal("Born改変")
	}
	e = testEvent119(birth.Confirm, 1, q, x)
	if _, err := applyEvent119(e, x, 2, s, waves); err != nil {
		t.Fatal(err)
	}
	if _, err := applyEvent119(e, x, 3, s, waves); err == nil {
		t.Fatal("確認重複")
	}
}

// TestKernelAndArtificialRaw119 は旧期限kernelの同秒清算・猶予・欠測と人工gzipの全行認証を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。自然Raw又は入力JSONを読みません。
func TestKernelAndArtificialRaw119(t *testing.T) {
	c := &Candidate119{OrderStyle: "market", Birth: Signal119{Side: 1}}
	fill119(c, testQuote119(100, 0, 95, 100))
	for at := 300.0; at < 1900; at += 200 {
		outcome119(c, testQuote119(at, int64(at), 100, 105), at-1, 5000)
	}
	end := testQuote119(1900, 2000, 110, 115)
	outcome119(c, end, 1899, 5000)
	outcome119(c, testQuote119(1900, 2001, 250, 255), 1900, 5000)
	if c.Outcomes[0].Status != "complete" || *c.Outcomes[0].Net0 != 923 || c.Outcomes[0].Touches[0].Direction != 0 {
		t.Fatal("清算同秒の後行を再観測")
	}
	g := &Candidate119{OrderStyle: "market", Birth: Signal119{Side: 1}}
	fill119(g, testQuote119(100, 0, 95, 100))
	outcome119(g, testQuote119(401, 1, 100, 105), 100, 5000)
	if g.Outcomes[0].Status != "gap_censored" || g.Outcomes[0].Net0 != nil {
		t.Fatal("gapを零補完")
	}
	b := &Candidate119{OrderStyle: "market", Birth: Signal119{Side: 1}}
	fill119(b, testQuote119(100, 0, 95, 100))
	bad := testQuote119(401, 1, 100, 105)
	bad.QuoteOK = false
	outcome119(b, bad, 400, 5000)
	if b.Outcomes[0].Status != "bbo_gap_censored" {
		t.Fatal("BBOgap")
	}
	path := filepath.Join(t.TempDir(), "人工.jsonl.gz")
	f, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	z := gzip.NewWriter(f)
	for _, q := range []Quote{testQuote119(100, 0, 990, 1010), testQuote119(100, 1, 990, 1010), testQuote119(101, 2, 990, 1010)} {
		m := map[string]any{"Symbol": "X", "CurrentPrice": q.Last, "CurrentPriceTime": time.Unix(int64(q.Time), 0).UTC().Format(time.RFC3339)}
		for i := 1; i <= 10; i++ {
			m[fmt.Sprintf("Buy%d", i)] = map[string]float64{"Price": q.Bid, "Qty": 1}
			m[fmt.Sprintf("Sell%d", i)] = map[string]float64{"Price": q.Ask, "Qty": 1}
		}
		raw, _ := json.Marshal(m)
		if _, err = z.Write(append(raw, '\n')); err != nil {
			t.Fatal(err)
		}
	}
	if err = z.Close(); err != nil {
		t.Fatal(err)
	}
	if err = f.Close(); err != nil {
		t.Fatal(err)
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	hash := sha256.Sum256(raw)
	s := Scene119{Session: "s", Contract: "X", Start: 100, End: 5000, ForceClose: 4900, Raw: FileRef{Path: path, SHA256: hex.EncodeToString(hash[:])}, ExpectedAccepted: 3}
	got, err := scan119([]Scene119{s}, 0)
	if err != nil || !got.Success || got.Quality.Delivered != 3 || len(got.Candidates) != 0 || got.Before != got.After {
		t.Fatalf("人工Raw認証 %v %+v", err, got)
	}
	s.Raw.SHA256 = string(make([]byte, 64))
	if _, err = scan119([]Scene119{s}, 0); err == nil {
		t.Fatal("Raw改変SHAを受理")
	}
}
