package holdingohlc113

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"strings"
	"sync"

	birth "github.com/masayoshi4649/SessionTradeExecuter/entrybirth119"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

const InputSHA119 = "574771f654937036b48c78eceadb46a4c5ff3c10265f60b0ec7879efb0d862c3"

var Policies119 = []string{"Ttrend_zone", "Ttrend_confirm", "Ttrend_retest", "Treversal_zone", "Treversal_confirm", "Treversal_retest"}
var Widths119 = []float64{25, 50, 100, 125, 200}
var Horizons119 = []float64{1800, 3600}

type Scene119 struct {
	Session          string              `json:"session"`
	Contract         string              `json:"contract"`
	Start            float64             `json:"start"`
	End              float64             `json:"end"`
	ForceClose       float64             `json:"force_close"`
	Raw              FileRef             `json:"raw"`
	ExpectedAccepted int64               `json:"expected_accepted"`
	Publications     []rules.Publication `json:"publications"`
}
type Input119 struct {
	Scenes []Scene119 `json:"scenes"`
}
type Signal119 struct {
	ID    string  `json:"id"`
	Side  int     `json:"side"`
	Time  float64 `json:"time"`
	Index int64   `json:"index"`
	Line  int64   `json:"source_line"`
	Quote Quote   `json:"quote"`
}
type First119 struct {
	Width     float64 `json:"width"`
	Direction int     `json:"direction"`
	Quote     *Quote  `json:"quote"`
}
type Outcome119 struct {
	Seconds  float64    `json:"seconds"`
	Deadline float64    `json:"deadline"`
	Status   string     `json:"status"`
	Touches  []First119 `json:"touches"`
	Endpoint *Quote     `json:"endpoint"`
	Points   *float64   `json:"points"`
	Net0     *float64   `json:"net0"`
	Net5     *float64   `json:"net5"`
}
type Candidate119 struct {
	Policy                string          `json:"policy"`
	Mode                  rules.Mode      `json:"mode"`
	Role                  string          `json:"role"`
	OrderStyle            string          `json:"order_style"`
	Birth                 Signal119       `json:"birth"`
	ZoneEvent             int             `json:"zone_event"`
	ConfirmEvent          *int            `json:"confirm_event"`
	Status                string          `json:"status"`
	Limit                 *float64        `json:"limit"`
	Request               *Quote          `json:"request"`
	Expires               float64         `json:"expires"`
	Entry                 *Quote          `json:"entry"`
	EntryPrice            *float64        `json:"entry_price"`
	LastNormalTime        float64         `json:"last_normal_time"`
	Watch                 rules.Watch     `json:"watch"`
	LastBackground        *rules.Decision `json:"last_background"`
	BackgroundUnknownRows int             `json:"background_unknown_rows"`
	BackgroundTrueRows    int             `json:"background_true_rows"`
	Cancellation          *Quote          `json:"cancellation"`
	CancellationEvent     *int            `json:"cancellation_event"`
	Outcomes              []Outcome119    `json:"outcomes"`
}
type Result119 struct {
	Session           string          `json:"session"`
	Success           bool            `json:"success"`
	Error             string          `json:"error,omitempty"`
	Raw               FileRef         `json:"raw"`
	ActualSHA         string          `json:"actual_sha256"`
	Before            FileStat        `json:"stat_before"`
	After             FileStat        `json:"stat_after"`
	Quality           Counts          `json:"quality"`
	Publications      int             `json:"publications"`
	Events            []birth.Event   `json:"events"`
	Candidates        []*Candidate119 `json:"candidates"`
	RawPasses         int             `json:"raw_passes"`
	SourceSignalsUsed bool            `json:"source_signals_used"`
}

// cloneWatch119 は接触先の参照を共有しない監視値を返します。
//
// 引数: w(rules.Watch)。返り値: rules.Watchは各候補の私有値です。
func cloneWatch119(w rules.Watch) rules.Watch {
	if w.Trend != nil {
		x := *w.Trend
		w.Trend = &x
	}
	if w.Reversal != nil {
		x := *w.Reversal
		w.Reversal = &x
	}
	return w
}

// quote119 は原板気配から検出器用の当時価格時計を取り出します。
//
// 引数: q(Quote)。返り値: rules.Quoteは同Index/物理行/Lastです。
func quote119(q Quote) rules.Quote {
	return rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last}
}

// branch119 は指定モードの背景票だけを選びます。
//
// 引数: mode(rules.Mode)、d(rules.Decision)。返り値: rules.Branchです。
func branch119(mode rules.Mode, d rules.Decision) rules.Branch {
	if mode == rules.Ttrend {
		return d.Trend
	}
	return d.Reversal
}

// new119 は技術領域の同じ出生から3役の候補を独立に作ります。
//
// 引数: e(birth.Event)、q(Quote)、event(int)、force(float64)。返り値: []*Candidate119です。
func new119(e birth.Event, q Quote, event int, force float64) []*Candidate119 {
	out := []*Candidate119{}
	for _, role := range []string{"zone", "confirm", "retest"} {
		style := "market"
		if role == "retest" {
			style = "limit"
		}
		c := &Candidate119{Policy: string(e.Mode) + "_" + role, Mode: e.Mode, Role: role, OrderStyle: style, Birth: Signal119{ID: e.ID, Side: e.Side, Time: q.Time, Index: q.Index, Line: q.SourceLine, Quote: q}, ZoneEvent: event, Status: "waiting_confirm", Expires: math.Min(q.Time+1800, force), Watch: cloneWatch119(e.Watch), Outcomes: []Outcome119{}}
		if role == "zone" {
			x := q
			c.Request = &x
			c.Status = "pending"
			c.Expires = math.Min(q.Time+30, force)
		}
		if q.Time >= force {
			c.Status = "force_close"
			c.Request = nil
		}
		out = append(out, c)
	}
	return out
}

// open119 は未約定で取消又は期限切れになっていない候補を判定します。
//
// 引数: c(*Candidate119)。返り値: boolは新規を待機中の場合です。
func open119(c *Candidate119) bool {
	return c.Entry == nil && (c.Status == "pending" || c.Status == "waiting_confirm")
}

// applyEvent119 は公表後の出生・確認・取消を約定判定より前に適用します。
//
// 引数: e(birth.Event)、q(Quote)、at(int)、s(Scene119)、waves(map[string][]*Candidate119)。返り値: 新候補/errorです。
func applyEvent119(e birth.Event, q Quote, at int, s Scene119, waves map[string][]*Candidate119) ([]*Candidate119, error) {
	if e.Scope.SessionID != s.Session || e.Scope.Contract != s.Contract || e.ID == "" || (e.Mode != rules.Ttrend && e.Mode != rules.Treversal) || (e.Side != 1 && e.Side != -1) || e.Current != quote119(q) {
		return nil, fmt.Errorf("イベントの場/モード/当原行差")
	}
	list, exists := waves[e.ID]
	if e.Kind == birth.Zone {
		if exists || e.Born != e.Current {
			return nil, fmt.Errorf("同波出生重複又は出生原行差")
		}
		list = new119(e, q, at, s.ForceClose)
		waves[e.ID] = list
		return list, nil
	}
	if !exists {
		return nil, fmt.Errorf("出生のない後続イベント")
	}
	for _, c := range list {
		if c.Mode != e.Mode || c.Birth.Side != e.Side || quote119(c.Birth.Quote) != e.Born {
			return nil, fmt.Errorf("同波のBorn/Mode/Side差")
		}
	}
	switch e.Kind {
	case birth.Confirm:
		if e.Decision.Truth != rules.True {
			return nil, fmt.Errorf("確認票が真でない")
		}
		for _, c := range list {
			if c.ConfirmEvent != nil {
				return nil, fmt.Errorf("同波確認重複")
			}
			event := at
			c.ConfirmEvent = &event
			if !open119(c) || c.Role == "zone" {
				continue
			}
			if q.Time >= c.Expires || q.Time >= s.ForceClose {
				c.Status = "unconfirmed_expired"
				continue
			}
			c.Watch = cloneWatch119(e.Watch)
			x := q
			c.Request = &x
			c.Status = "pending"
			ttl := 30.0
			if c.Role == "retest" {
				ttl = 300
				v, ok := e.Decision.Fields["confirm5_boundary"]
				if !ok || !v.Known || !finite(v.Value) || v.Value <= 0 {
					return nil, fmt.Errorf("再取得境界が未知又は不正")
				}
				limit := math.Floor(v.Value/5) * 5
				if e.Side < 0 {
					limit = math.Ceil(v.Value/5) * 5
				}
				if limit <= 0 {
					return nil, fmt.Errorf("丸め後指値が不正")
				}
				c.Limit = &limit
			}
			c.Expires = math.Min(c.Expires, q.Time+ttl)
		}
	case birth.Expire, birth.Invalidate:
		for _, c := range list {
			if open119(c) {
				c.Status = "wave_" + string(e.Kind)
				x := q
				c.Cancellation = &x
				event := at
				c.CancellationEvent = &event
			}
		}
	default:
		return nil, fmt.Errorf("未知のイベント")
	}
	return nil, nil
}

// fillable119 は後原行・1秒・反対BBO10pt通過だけで約定代用を判定します。
//
// 引数: c(*Candidate119)、q(Quote)。返り値: bool。背景の三値は呼出し前に別判定します。
func fillable119(c *Candidate119, q Quote) bool {
	if c.Request == nil || q.Index <= c.Request.Index || q.SourceLine <= c.Request.SourceLine || q.Time < c.Request.Time+1 || !q.QuoteOK || !normal(q) {
		return false
	}
	if c.OrderStyle == "market" {
		return true
	}
	return c.OrderStyle == "limit" && c.Limit != nil && ((c.Birth.Side > 0 && q.Ask <= *c.Limit-10) || (c.Birth.Side < 0 && q.Bid >= *c.Limit+10))
}

// fill119 は成行又は指値価格を固定し、独立1miniの固定期限評価を開始します。
//
// 引数: c(*Candidate119)、q(Quote)。返り値: ありません。先着は返済注文を作りません。
func fill119(c *Candidate119, q Quote) {
	price := q.Ask
	if c.Birth.Side < 0 {
		price = q.Bid
	}
	if c.OrderStyle == "limit" {
		price = *c.Limit
	}
	x := q
	c.Entry = &x
	c.EntryPrice = &price
	c.Status = "filled"
	c.LastNormalTime = q.Time
	for _, h := range Horizons119 {
		o := Outcome119{Seconds: h, Deadline: q.Time + h, Status: "pending", Touches: []First119{}}
		for _, w := range Widths119 {
			o.Touches = append(o.Touches, First119{Width: w})
		}
		c.Outcomes = append(c.Outcomes, o)
	}
}

// pending119 は取消・期限・背景を先に判定して未約定候補だけを進めます。
//
// 引数: c(*Candidate119)、q(Quote)、force(float64)、bank(*rules.Bank)。返り値: errorは技術票不整合です。
func pending119(c *Candidate119, q Quote, force float64, bank *rules.Bank) error {
	if !open119(c) {
		return nil
	}
	if q.Time >= force {
		c.Status = "force_close"
		return nil
	}
	if q.Time >= c.Expires {
		c.Status = "unfilled_expired"
		if c.Request == nil {
			c.Status = "unconfirmed_expired"
		}
		return nil
	}
	if c.Request == nil {
		return nil
	}
	d, err := bank.Evaluate(c.Mode, c.Birth.Side, quote119(q), &c.Watch)
	if err != nil {
		return err
	}
	c.LastBackground = &d
	background := branch119(c.Mode, d).Background
	if background == rules.False {
		c.Status = "background_invalidated"
		x := q
		c.Cancellation = &x
		return nil
	}
	if background == rules.Unknown {
		c.BackgroundUnknownRows++
		return nil
	}
	c.BackgroundTrueRows++
	if fillable119(c, q) {
		fill119(c, q)
	}
	return nil
}

// scan119 は当場Rawを一度だけ読み、公表・検出イベント・待機注文・固定期限を配送します。
//
// 引数: all([]Scene119)、at(int)。返り値: Result119/error。Source新規/取消は入力型からも除外しています。
func scan119(all []Scene119, at int) (out Result119, err error) {
	s := all[at]
	out = Result119{Session: s.Session, Raw: s.Raw, Candidates: []*Candidate119{}, Events: []birth.Event{}, RawPasses: 1}
	bank := rules.NewBank()
	for i := 0; i < at; i++ {
		p := all[i]
		if err = bank.StartSession(p.Session, p.Contract); err != nil {
			return out, err
		}
		for _, pub := range p.Publications {
			if pub.Stamp.Time >= s.Start {
				return out, fmt.Errorf("前史が当場へ侵入")
			}
			if err = bank.Add(pub); err != nil {
				return out, err
			}
		}
	}
	if err = bank.StartSession(s.Session, s.Contract); err != nil {
		return out, err
	}
	detector := birth.NewDetector()
	if err = detector.StartSession(s.Session, s.Contract); err != nil {
		return out, err
	}
	f, e := os.Open(s.Raw.Path)
	if e != nil {
		return out, e
	}
	defer f.Close()
	before, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.Before = FileStat{Bytes: before.Size(), ModTimeNS: before.ModTime().UnixNano()}
	hash := sha256.New()
	tee := io.TeeReader(f, hash)
	z, e := gzip.NewReader(tee)
	if e != nil {
		return out, e
	}
	defer z.Close()
	scan := bufio.NewScanner(z)
	scan.Buffer(make([]byte, 65536), 8*1024*1024)
	scene := Scene{Session: s.Session, Contract: s.Contract, Start: s.Start, End: s.End, Raw: s.Raw}
	previous := s.Start
	var index int64
	pi := 0
	contracts := map[string]bool{}
	waves := map[string][]*Candidate119{}
	seenEvents := map[string]bool{}
	pending := []*Candidate119{}
	holding := []*Candidate119{}
	for scan.Scan() {
		out.Quality.Lines++
		q, _, next, e := decodeRow(scan.Bytes(), out.Quality.Lines, index, scene, previous, &out.Quality, contracts)
		oldTime := previous
		previous = next
		if e != nil {
			return out, e
		}
		if q == nil {
			continue
		}
		index++
		newFive := false
		for pi < len(s.Publications) && int64(s.Publications[pi].Stamp.Index) <= q.Index {
			pub := s.Publications[pi]
			if int64(pub.Stamp.Index) != q.Index || int64(pub.Stamp.Line) != q.SourceLine || pub.Stamp.Time != q.Time {
				return out, fmt.Errorf("公表実配送行差")
			}
			if err = bank.Add(pub); err != nil {
				return out, err
			}
			if pub.Frame.Frame.Width == 300 {
				newFive = true
			}
			pi++
		}
		events, e := detector.Observe(bank, quote119(*q), newFive)
		if e != nil {
			return out, e
		}
		for _, event := range events {
			key := event.ID + "/" + string(event.Kind)
			if seenEvents[key] {
				return out, fmt.Errorf("同波イベント重複")
			}
			seenEvents[key] = true
			atEvent := len(out.Events)
			out.Events = append(out.Events, event)
			created, e := applyEvent119(event, *q, atEvent, s, waves)
			if e != nil {
				return out, e
			}
			out.Candidates = append(out.Candidates, created...)
			pending = append(pending, created...)
		}
		keep := pending[:0]
		for _, c := range pending {
			if err = pending119(c, *q, s.ForceClose, bank); err != nil {
				return out, err
			}
			if c.Entry != nil {
				holding = append(holding, c)
			} else if open119(c) {
				keep = append(keep, c)
			}
		}
		pending = keep
		active := holding[:0]
		for _, c := range holding {
			outcome119(c, *q, oldTime, s.End)
			alive := false
			for _, o := range c.Outcomes {
				if o.Status == "pending" {
					alive = true
				}
			}
			if alive {
				active = append(active, c)
			}
		}
		holding = active
	}
	if e = scan.Err(); e != nil {
		return out, e
	}
	if _, e = io.Copy(io.Discard, tee); e != nil {
		return out, e
	}
	after, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.After = FileStat{Bytes: after.Size(), ModTimeNS: after.ModTime().UnixNano()}
	out.ActualSHA = hex.EncodeToString(hash.Sum(nil))
	if out.ActualSHA != s.Raw.SHA256 || out.Before != out.After {
		return out, fmt.Errorf("Raw SHA/stat差")
	}
	if len(contracts) != 1 || !contracts[s.Contract] || index != s.ExpectedAccepted || pi != len(s.Publications) {
		return out, fmt.Errorf("限月/全採用数/公表配送数差")
	}
	for _, c := range pending {
		c.Status = "eof_unfilled"
	}
	for _, c := range holding {
		for i := range c.Outcomes {
			if c.Outcomes[i].Status == "pending" {
				c.Outcomes[i].Status = "eof_censored"
			}
		}
	}
	if len(out.Candidates) != 3*len(waves) {
		return out, fmt.Errorf("領域出生と3役候補数が不一致")
	}
	out.Publications = pi
	out.Success = true
	return out, nil
}

// Run119 はRootの既固定入力だけを読み、8以下の独立場並列で新規結果へ保存します。
//
// 引数: input/expected/output(string)、workers(int)。返り値: errorは指紋・配送・保存不整合です。
func Run119(input, expected, output string, workers int) error {
	if expected != InputSHA119 {
		return fmt.Errorf("119が再用する入力SHAではない")
	}
	data, err := os.ReadFile(input)
	if err != nil {
		return err
	}
	sum := sha256.Sum256(data)
	if hex.EncodeToString(sum[:]) != expected {
		return fmt.Errorf("入力SHA差")
	}
	var in Input119
	if err = json.Unmarshal(data, &in); err != nil {
		return err
	}
	if len(in.Scenes) != 70 || workers < 1 || workers > 8 {
		return fmt.Errorf("70場/並列条件差")
	}
	pubs := 0
	seen := map[string]bool{}
	previousEnd := 0.0
	for _, s := range in.Scenes {
		if s.Session == "" || strings.HasPrefix(s.Session, "2026-11-09") || seen[s.Session] || s.Contract == "" || !finite(s.Start, s.End, s.ForceClose) || s.Start <= previousEnd || s.ForceClose <= s.Start || s.ForceClose > s.End || s.Raw.Path == "" || len(s.Raw.SHA256) != 64 || s.ExpectedAccepted <= 0 {
			return fmt.Errorf("場定義又は順序差")
		}
		seen[s.Session] = true
		previousEnd = s.End
		pubs += len(s.Publications)
	}
	if pubs != 12320 {
		return fmt.Errorf("公表総数が12320ではない")
	}
	if _, err = os.Stat(output); !os.IsNotExist(err) {
		return fmt.Errorf("新規先だけ")
	}
	results := make([]Result119, len(in.Scenes))
	jobs := make(chan int)
	var wg sync.WaitGroup
	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for at := range jobs {
				r, e := scan119(in.Scenes, at)
				if e != nil {
					r.Error = e.Error()
				}
				results[at] = r
				fmt.Printf("%s 成功=%t %s\n", r.Session, r.Success, r.Error)
			}
		}()
	}
	for i := range in.Scenes {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	for _, r := range results {
		if !r.Success {
			return fmt.Errorf("%s: %s", r.Session, r.Error)
		}
	}
	encoded, err := json.MarshalIndent(map[string]any{"trial": 119, "success": true, "input_sha256": expected, "policies": Policies119, "horizons": Horizons119, "widths": Widths119, "scenes": results, "portfolio_pnl": false, "candidate_quantity": 1, "source_signals_used": false, "endpoint_model": "期限に達した最初の正常原行まで。ラベルは元期限まで、純額は猶予30秒内の実endpointで評価"}, "", "  ")
	if err != nil {
		return err
	}
	after, err := os.ReadFile(input)
	if err != nil {
		return err
	}
	if sha256.Sum256(after) != sum {
		return fmt.Errorf("入力前後差")
	}
	f, err := os.OpenFile(output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return err
	}
	defer f.Close()
	_, err = f.Write(append(encoded, '\n'))
	return err
}
