"""コードの指紋と人工レビューの確認結果を日本語JSONへ保存する。"""

from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parents[2]
folders = ["work/119入口比較", "work/119入口の技術的出生", "work/118複数技法の入口条件"]
files = []
for folder in folders:
    for path in sorted((root / folder).rglob("*")):
        if path.is_file() and (path.suffix == ".go" or path.name in {"go.mod", "README.md"}):
            files.append({"path": path.relative_to(root).as_posix(), "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})

# ----------------------------------------
old = (root / "work/118入口比較/entry.go").read_text(encoding="utf-8")
old_kernel = old[old.index("func outcome118("):old.index("// scan118 は")].strip()
new = (root / "work/119入口比較/outcome.go").read_text(encoding="utf-8")
new_kernel = new[new.index("func outcome119("):].strip()
same_kernel = old_kernel.replace("118", "119") == new_kernel
assert same_kernel
proof = {
    "trial": 119,
    "purpose": "市場実行前の人工コードレビュー",
    "success": True,
    "source_changed": False,
    "natural_raw_read": False,
    "market_input_read": False,
    "market_result_read": False,
    "november09_read": False,
    "go_version": "go1.24.2 windows/amd64",
    "runner_test_non_cached_main_count": 5,
    "detector_test_main_count": 4,
    "tests": "3モジュール成功。119runnerは-count=1 -vで非キャッシュ成功",
    "vet": "3モジュール成功",
    "build": "3モジュール成功",
    "kernel118_119_same_except_names": same_kernel,
    "initial_environment_failure": "119runnerのみ共有Goキャッシュのcorrupt index。独立GOCACHEでtest/vet/build成功、ソース修正なし",
    "findings": "重大欠陥は見つからなかった。市場の優位性、保存指標の自然Rawからの再計算、mini実約定を保証しない",
    "files": files,
}
target = Path(__file__).with_name("確認.json")
assert not target.exists()
target.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"path": str(target), "sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "files": len(files), "success": True}, ensure_ascii=False))
