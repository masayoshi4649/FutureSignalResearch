package entrybirth119

import (
	"fmt"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// value は、手製の既知値を作ります。
//
// 引数: v(float64)。返り値: rules.Valueです。
func value(v float64) rules.Value { return rules.Value{Known: true, Value: v} }

// pub は、売買鏡像の手製技術公表を作ります。
//
// 引数: width/index/side(int)、end(float64)、session(string)。返り値: rules.Publicationです。
func pub(width, index, side int, end float64, session string) rules.Publication {
	s := float64(side)
	f := rules.ChartFrame{ID: fmt.Sprintf("%s/%d/%g", session, width, end), SessionID: session, Contract: "K", Width: width, End: end, AvailableAt: end, DeliveryAt: end, PriceKnown: true, VolumeKnown: true, Volume: 100, OHLC: rules.OHLC{Open: 100, High: 101, Low: 99, Close: 100}, Technical: rules.Technical{EMA8: value(100 + s), EMA21: value(100), EMA8Delta: value(s), EMA21Delta: value(s), Gap: value(s), ATR: value(10), PreviousATR: value(10), TR: value(2), RSI: value(50 + 10*s), PreviousRSI: value(50 + 5*s), Histogram: value(s), PreviousHistogram: value(.5 * s)}}
	return rules.Publication{Stamp: rules.Stamp{Time: end, Index: index, Line: index + 1}, Frame: rules.Frame{Frame: f, DMI: rules.DMI{PlusDI: value(25 + 5*s), MinusDI: value(25 - 5*s), ADX: value(24), PreviousADX: value(26)}}}
}

// setup は、同限月20本前史と当場3公表を持つbank/Detectorを作ります。
//
// 引数: t(*testing.T)、side(int)、reversal(bool)。返り値: *rules.Bank/*Detectorです。
func setup(t *testing.T, side int, reversal bool) (*rules.Bank, *Detector) {
	t.Helper()
	b := rules.NewBank()
	for _, w := range []int{300, 900, 1800} {
		for i := 0; i < 20; i++ {
			if err := b.Add(pub(w, i, side, 1000+float64((i+1)*w), "prior")); err != nil {
				t.Fatal(err)
			}
		}
	}
	if err := b.StartSession("current", "K"); err != nil {
		t.Fatal(err)
	}
	for _, w := range []int{300, 900, 1800} {
		p := pub(w, 0, side, 100000, "current")
		if reversal && w == 900 {
			p.Frame.Frame.Technical.RSI = value(50 - 20*float64(side))
		}
		if err := b.Add(p); err != nil {
			t.Fatal(err)
		}
	}
	d := NewDetector()
	if err := d.StartSession("current", "K"); err != nil {
		t.Fatal(err)
	}
	return b, d
}

// q は、同秒別Indexも表せる原行を作ります。
//
// 引数: index(int)、at/last(float64)。返り値: rules.Quoteです。
func q(index int, at, last float64) rules.Quote {
	return rules.Quote{Time: at, Index: index, Line: index + 1, Last: last}
}

// choose は、対象mode/side/Kindのイベントだけを選びます。
//
// 引数: e([]Event)、mode(rules.Mode)、side(int)、kind(Kind)。返り値: []Eventです。
func choose(e []Event, mode rules.Mode, side int, kind Kind) []Event {
	var r []Event
	for _, v := range e {
		if v.Mode == mode && v.Side == side && v.Kind == kind {
			r = append(r, v)
		}
	}
	return r
}

// TestBirthConfirmMirrorCopy は、Sourceなし出生/別足確認/一度発生/参照分離を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestBirthConfirmMirrorCopy(t *testing.T) {
	for _, side := range []int{1, -1} {
		b, d := setup(t, side, false)
		events, err := d.Observe(b, q(0, 100000, 100), true)
		if err != nil {
			t.Fatal(err)
		}
		born := choose(events, rules.Ttrend, side, Zone)
		if len(born) != 1 {
			t.Fatalf("出生 %d %#v", side, events)
		}
		id := born[0].ID
		born[0].Watch.Trend.At.Last = 1
		born[0].Decision.Fields["gap30_signed"] = value(999)
		s := d.Snapshot()
		if s.States[0].Watch == nil && side == 1 {
			t.Fatal("出生なし")
		}
		for _, v := range s.States {
			if v.Mode == rules.Ttrend && v.Side == side && v.Watch.Trend.At.Last != 100 {
				t.Fatal("Event参照共有")
			}
		}
		events, err = d.Observe(b, q(1, 100001, 100+2*float64(side)), false)
		if err != nil || len(choose(events, rules.Ttrend, side, Confirm)) != 0 {
			t.Fatal("接触前の足で確認")
		}
		if err := b.Add(pub(300, 2, side, 100300, "current")); err != nil {
			t.Fatal(err)
		}
		events, err = d.Observe(b, q(2, 100300, 100+2*float64(side)), true)
		done := choose(events, rules.Ttrend, side, Confirm)
		if err != nil || len(done) != 1 || done[0].ID != id || done[0].Born.Index != 0 || done[0].Decision.Fields["confirm5_boundary"].Known != true {
			t.Fatalf("確認 %#v %v", events, err)
		}
		events, err = d.Observe(b, q(2, 100300, 100+2*float64(side)), true)
		if err != nil || len(events) != 0 {
			t.Fatal("同Raw重複")
		}
		events, err = d.Observe(b, q(3, 100301, 100), false)
		if err != nil || len(choose(events, rules.Ttrend, side, Zone)) != 0 {
			t.Fatal("同wave重複出生")
		}
	}
}

// TestUnknownInvalidateAndDeadline は、背景未知の保留/既知偽失効/期限等号を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestUnknownInvalidateAndDeadline(t *testing.T) {
	b, d := setup(t, 1, false)
	if _, err := d.Observe(b, q(0, 100000, 100), true); err != nil {
		t.Fatal(err)
	}
	p := pub(900, 1, 1, 100900, "current")
	p.Frame.DMI.PlusDI = rules.Value{}
	if err := b.Add(p); err != nil {
		t.Fatal(err)
	}
	if err := b.Add(pub(300, 1, 1, 100900, "current")); err != nil {
		t.Fatal(err)
	}
	e, err := d.Observe(b, q(1, 100900, 100), true)
	if err != nil || len(choose(e, rules.Ttrend, 1, Invalidate)) != 0 {
		t.Fatal("背景未知を失効扱い")
	}
	p = pub(1800, 2, 1, 101000, "current")
	p.Frame.Frame.Technical.Gap = value(-1)
	if err := b.Add(p); err != nil {
		t.Fatal(err)
	}
	e, err = d.Observe(b, q(2, 101000, 100), false)
	if err != nil || len(choose(e, rules.Ttrend, 1, Invalidate)) != 1 {
		t.Fatalf("既知背景否定 %#v %v", e, err)
	}
	b, d = setup(t, 1, false)
	if _, err = d.Observe(b, q(0, 100000, 100), true); err != nil {
		t.Fatal(err)
	}
	e, err = d.Observe(b, q(1, 101800, 102), false)
	if err != nil || len(choose(e, rules.Ttrend, 1, Expire)) != 1 {
		t.Fatalf("30分等号 %#v %v", e, err)
	}
}

// TestRearmOnlyDistinctNewFive は、新公表の帯外離脱を待つ再出生を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestRearmOnlyDistinctNewFive(t *testing.T) {
	b, d := setup(t, 1, false)
	d.Observe(b, q(0, 100000, 100), true)
	b.Add(pub(300, 1, 1, 100300, "current"))
	d.Observe(b, q(1, 100300, 102), true)
	// 完了した同じ5分IDをnewFive=trueと誤って再配送しても再armしない。
	e, err := d.Observe(b, q(2, 100301, 110), true)
	if err != nil || len(choose(e, rules.Ttrend, 1, Zone)) != 0 {
		t.Fatal(err)
	}
	for _, s := range d.Snapshot().States {
		if s.Mode == rules.Ttrend && s.Side == 1 && s.Armed {
			t.Fatal("同5分IDで再arm")
		}
	}
	b.Add(pub(300, 3, 1, 100600, "current"))
	e, err = d.Observe(b, q(3, 100600, 110), true)
	if err != nil || len(choose(e, rules.Ttrend, 1, Zone)) != 0 {
		t.Fatal("再arm行に出生")
	}
	e, err = d.Observe(b, q(4, 100601, 100), false)
	born := choose(e, rules.Ttrend, 1, Zone)
	if err != nil || len(born) != 1 || born[0].ID != "current/Ttrend/1/000002" {
		t.Fatalf("再接触 %#v %v", e, err)
	}
}

// TestReversalAndScopeReset は、反転鏡像・4状態・Scope/原行防御を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestReversalAndScopeReset(t *testing.T) {
	for _, side := range []int{1, -1} {
		b, d := setup(t, side, true)
		e, err := d.Observe(b, q(0, 100000, 100), true)
		if err != nil || len(choose(e, rules.Treversal, side, Zone)) != 1 {
			t.Fatalf("反転出生 %#v %v", e, err)
		}
		p := pub(300, 1, side, 100300, "current")
		p.Frame.Frame.Technical.Histogram = value(-.1 * float64(side))
		p.Frame.Frame.Technical.PreviousHistogram = value(-.5 * float64(side))
		b.Add(p)
		e, err = d.Observe(b, q(1, 100300, 100+2*float64(side)), true)
		if err != nil || len(choose(e, rules.Treversal, side, Confirm)) != 1 {
			t.Fatalf("反転確認 %#v %v", e, err)
		}
		before := d.Snapshot()
		if _, err = d.Observe(b, q(0, 100301, 100), false); err == nil {
			t.Fatal("逆行を許可")
		}
		if d.Snapshot().Last.Index != before.Last.Index {
			t.Fatal("拒否で状態変更")
		}
		d.StartSession("next", "K")
		if _, err = d.Observe(b, q(0, 100400, 100), false); err == nil {
			t.Fatal("異場bankを許可")
		}
		if len(d.Snapshot().States) != 4 {
			t.Fatal("4状態なし")
		}
		for _, s := range d.Snapshot().States {
			if !s.Armed || s.Sequence != 0 || s.Watch != nil {
				t.Fatal("場reset不全")
			}
		}
	}
}
