// Package entrybirth119 は、技術領域への接触と確認の出生を原行順に発生させます。
package entrybirth119

import rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"

const ZoneLifetimeSeconds = 1800.0

type Scope struct {
	SessionID string `json:"session_id"`
	Contract  string `json:"contract"`
}

type Kind string

const (
	Zone       Kind = "zone"
	Confirm    Kind = "confirm"
	Expire     Kind = "expire"
	Invalidate Kind = "invalidate"
)

type Event struct {
	Kind     Kind           `json:"kind"`
	ID       string         `json:"id"`
	Scope    Scope          `json:"scope"`
	Mode     rules.Mode     `json:"mode"`
	Side     int            `json:"side"`
	Born     rules.Quote    `json:"born"`
	Current  rules.Quote    `json:"current"`
	Decision rules.Decision `json:"decision"`
	Watch    rules.Watch    `json:"watch"`
}

type State struct {
	Mode     rules.Mode   `json:"mode"`
	Side     int          `json:"side"`
	Armed    bool         `json:"armed"`
	Sequence uint64       `json:"sequence"`
	ID       string       `json:"id,omitempty"`
	Born     *rules.Quote `json:"born,omitempty"`
	Watch    *rules.Watch `json:"watch,omitempty"`
}

type Snapshot struct {
	Scope           Scope        `json:"scope"`
	States          []State      `json:"states"`
	Last            *rules.Quote `json:"last,omitempty"`
	LastRearmFiveID string       `json:"last_rearm_five_id,omitempty"`
}

type Detector struct {
	scope           Scope
	states          []State
	last            *rules.Quote
	lastRearmFiveID string
}
