# 119の入口技術イベント

118の `entryrules118` をそのまま再用する。Ttrend/Treversal × 買い/売りの4状態を、Source出生・P0・50pt価格capから独立して各原行で監視する。技術閾値は118と同じで、zone寿命だけ30分を事前固定した。未検証の研究候補であり、市場成績や優位性を主張しない。

```go
detector := entrybirth119.NewDetector()
detector.StartSession(sessionID, contract)
events, err := detector.Observe(bank, quote, newFive)
```

APIは `StartSession(string,string) error`、`Observe(*entryrules118.Bank,entryrules118.Quote,bool) ([]Event,error)`、`Snapshot() Snapshot`。bankの数値前史とAdd/StartSessionはRootの責任とし、発生器はbankを更新しない。

各状態は初期Armed=true/Watchなし。Armedのidle状態では毎Rawで空Watchから118の票を評価し、初回Touchが生じたらzoneイベントを出す。IDは `session/mode/side/6桁連番`。Born QuoteとWatchを固定しArmed=falseとする。

active Watchは各Rawで再評価し、`現在Time >= Born.Time+1800秒` ならexpireを最優先、背景Falseならinvalidate、Unknownなら保留、Decision.Trueならconfirmを一度だけ出す。終了時はactiveを解放するがArmed=falseは維持する。確認後の注文や背景監視へ干渉しない。

activeなし/Armed=falseの状態は、当原行に実配送された新5分公表だけで、空Watchからの背景False **又は** zoneFalseを確認すれば再armする。`newFive`に加え、最新5分の配送Stampが現在QuoteのTime/Index/Lineと一致し、前に処理したIDでないことが必要。同じ5分IDや同Rawの再配送で再armしない。再armしたその原行には出生を作らず、後続原行の再接触を待つ。期限切れや否定の原行にも再出生しない。

イベントはzone/confirm/expire/invalidate。各EventのDecision/Watch/値配列/マップは独立copyし、Snapshotも内部状態を共有しない。同一Quoteの再Observeはイベントなしで冪等、同Index改変やIndex/物理行/時計逆行、bankとのScope不一致は拒否する。拒否で内部状態を部分更新しない。StartSessionは4状態と連番をすべてresetする。

Rootはconfirm票の `Decision.Fields["confirm5_boundary"]` を確認後注文の構造水準に使える。baseline現在値/confirm成行/構造再試験指値は別の実行候補であり、このモジュールは指値、期限注文、価格cap、手数料、約定、損益を計算しない。

```powershell
go test -count=1 -v ./...
go vet ./...
go build ./...
```

手製4主は買売鏡像の出生/確認、旧足再利用の拒否、一度発生、30分等号、未知保留/背景偽、distinct新5分と再接触、参照分離、反転のHist水準と増分の区別、Scope/原行/場resetを確認する。自然Raw/Native/価格CSV/11月09は読まない。
