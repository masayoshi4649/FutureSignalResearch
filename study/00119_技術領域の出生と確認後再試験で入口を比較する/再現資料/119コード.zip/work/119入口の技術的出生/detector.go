package entrybirth119

import (
	"fmt"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// NewDetector は、場開始前の空の発生器を返します。
//
// 引数: なし。返り値: *Detectorです。StartSessionを先に呼びます。
func NewDetector() *Detector { return &Detector{} }

// StartSession は、4状態と出生連番を当場へ初期化します。
//
// 引数: sessionID/contract(string)。返り値: errorは空Scopeです。bank数値窓へ触れません。
func (d *Detector) StartSession(sessionID, contract string) error {
	if sessionID == "" || contract == "" {
		return fmt.Errorf("場/限月が空です")
	}
	d.scope = Scope{SessionID: sessionID, Contract: contract}
	d.states = nil
	d.last = nil
	d.lastRearmFiveID = ""
	for _, m := range []rules.Mode{rules.Ttrend, rules.Treversal} {
		for _, side := range []int{1, -1} {
			d.states = append(d.states, State{Mode: m, Side: side, Armed: true})
		}
	}
	return nil
}

// copyQuote は、原行の参照共有を避けます。
//
// 引数: q(*rules.Quote)。返り値: *rules.Quoteはnilを保ちます。
func copyQuote(q *rules.Quote) *rules.Quote {
	if q == nil {
		return nil
	}
	v := *q
	return &v
}

// copyTouch は、初回領域への接触を私有化します。
//
// 引数: p(*rules.ZoneTouch)。返り値: *rules.ZoneTouchはnilを保ちます。
func copyTouch(p *rules.ZoneTouch) *rules.ZoneTouch {
	if p == nil {
		return nil
	}
	v := *p
	return &v
}

// copyWatch は、枝別接触を含む監視値を私有化します。
//
// 引数: w(*rules.Watch)。返り値: *rules.Watchはnilを保ちます。
func copyWatch(w *rules.Watch) *rules.Watch {
	if w == nil {
		return nil
	}
	v := *w
	v.Trend = copyTouch(w.Trend)
	v.Reversal = copyTouch(w.Reversal)
	return &v
}

// copyBranch は、票の配列と接触を私有化します。
//
// 引数: b(rules.Branch)。返り値: rules.Branchです。
func copyBranch(b rules.Branch) rules.Branch {
	b.Touch = copyTouch(b.Touch)
	if b.Missing != nil {
		b.Missing = append([]string{}, b.Missing...)
	}
	if b.Denied != nil {
		b.Denied = append([]string{}, b.Denied...)
	}
	return b
}

// copyDecision は、返す票のmap/配列/接触を私有化します。
//
// 引数: r(rules.Decision)。返り値: rules.Decisionです。
func copyDecision(r rules.Decision) rules.Decision {
	r.Trend = copyBranch(r.Trend)
	r.Reversal = copyBranch(r.Reversal)
	if r.Missing != nil {
		r.Missing = append([]string{}, r.Missing...)
	}
	if r.Reason != nil {
		r.Reason = append([]string{}, r.Reason...)
	}
	if r.SnapshotRefs != nil {
		r.SnapshotRefs = append([]rules.Ref{}, r.SnapshotRefs...)
	}
	if r.Fields != nil {
		m := make(map[string]rules.Value, len(r.Fields))
		for k, v := range r.Fields {
			m[k] = v
		}
		r.Fields = m
	}
	return r
}

// copyStates は、内部監視状態を値複写します。
//
// 引数: states([]State)。返り値: []Stateです。
func copyStates(states []State) []State {
	if states == nil {
		return nil
	}
	r := append([]State{}, states...)
	for i := range r {
		r[i].Born = copyQuote(r[i].Born)
		r[i].Watch = copyWatch(r[i].Watch)
	}
	return r
}

// Snapshot は、現在の4状態を外部へ参照共有せず返します。
//
// 引数: receiver(*Detector)。返り値: Snapshotです。
func (d *Detector) Snapshot() Snapshot {
	return Snapshot{Scope: d.scope, States: copyStates(d.states), Last: copyQuote(d.last), LastRearmFiveID: d.lastRearmFiveID}
}

// selected は、当該modeだけの技術枝を選びます。
//
// 引数: mode(rules.Mode)、v(rules.Decision)。返り値: rules.Branchです。
func selected(mode rules.Mode, v rules.Decision) rules.Branch {
	if mode == rules.Ttrend {
		return v.Trend
	}
	return v.Reversal
}

// makeEvent は、内部の出生と当時票を外部用に値複写します。
//
// 引数: kind(Kind)、scope(Scope)、s(State)、q(rules.Quote)、v(rules.Decision)。返り値: Eventです。
func makeEvent(kind Kind, scope Scope, s State, q rules.Quote, v rules.Decision) Event {
	return Event{Kind: kind, ID: s.ID, Scope: scope, Mode: s.Mode, Side: s.Side, Born: *s.Born, Current: q, Decision: copyDecision(v), Watch: *copyWatch(s.Watch)}
}

// clearActive は、出生を終了し再arm前の状態へ戻します。
//
// 引数: s(*State)。返り値: なし。連番とArmed=falseを保持します。
func clearActive(s *State) { s.ID = ""; s.Born = nil; s.Watch = nil }

// Observe は、全Raw原行で接触/確認/期限/背景否定を一度だけ発生させます。
//
// 引数: bank(*rules.Bank)、q(rules.Quote)、newFive(bool)は当原行の新5分公表有無です。
// 返り値: []Event/error。注文・価格cap・Source通知は扱いません。
func (d *Detector) Observe(bank *rules.Bank, q rules.Quote, newFive bool) ([]Event, error) {
	if bank == nil || d.scope.SessionID == "" || len(d.states) != 4 {
		return nil, fmt.Errorf("場開始又はbankがありません")
	}
	snapshot, err := bank.Current(q)
	if err != nil {
		return nil, err
	}
	if snapshot.SessionID != d.scope.SessionID || snapshot.Contract != d.scope.Contract {
		return nil, fmt.Errorf("bankと発生器のScopeが違います")
	}
	if d.last != nil {
		if q.Index == d.last.Index {
			if q != *d.last {
				return nil, fmt.Errorf("同原行の改変です")
			}
			return nil, nil
		}
		if q.Index < d.last.Index || q.Line <= d.last.Line || q.Time < d.last.Time {
			return nil, fmt.Errorf("原行順が逆転しました")
		}
	}
	states := copyStates(d.states)
	fiveID := ""
	fiveDeliveredNow := false
	if p, ok := snapshot.Frames[300]; ok {
		fiveID = p.Frame.Frame.ID
		fiveDeliveredNow = p.Stamp.Time == q.Time && p.Stamp.Index == q.Index && p.Stamp.Line == q.Line
	}
	rearm := newFive && fiveDeliveredNow && fiveID != "" && fiveID != d.lastRearmFiveID
	var events []Event
	for i := range states {
		s := &states[i]
		if s.Watch != nil {
			v, e := bank.Evaluate(s.Mode, s.Side, q, s.Watch)
			if e != nil {
				return nil, e
			}
			br := selected(s.Mode, v)
			if q.Time >= s.Born.Time+ZoneLifetimeSeconds {
				events = append(events, makeEvent(Expire, d.scope, *s, q, v))
				clearActive(s)
				continue
			}
			if br.Background == rules.False {
				events = append(events, makeEvent(Invalidate, d.scope, *s, q, v))
				clearActive(s)
				continue
			}
			if v.Truth == rules.True {
				events = append(events, makeEvent(Confirm, d.scope, *s, q, v))
				clearActive(s)
			}
			continue
		}
		w := rules.Watch{}
		v, e := bank.Evaluate(s.Mode, s.Side, q, &w)
		if e != nil {
			return nil, e
		}
		br := selected(s.Mode, v)
		if !s.Armed {
			if rearm && (br.Background == rules.False || br.Zone == rules.False) {
				s.Armed = true
			}
			continue
		}
		if br.Touch != nil {
			s.Sequence++
			s.ID = fmt.Sprintf("%s/%s/%d/%06d", d.scope.SessionID, s.Mode, s.Side, s.Sequence)
			s.Born = copyQuote(&q)
			s.Watch = copyWatch(&w)
			s.Armed = false
			events = append(events, makeEvent(Zone, d.scope, *s, q, v))
		}
	}
	d.states = states
	d.last = copyQuote(&q)
	if rearm {
		d.lastRearmFiveID = fiveID
	}
	return events, nil
}
