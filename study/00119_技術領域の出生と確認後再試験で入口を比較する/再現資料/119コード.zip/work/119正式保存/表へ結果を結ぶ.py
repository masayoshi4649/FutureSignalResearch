"""119の既存集計を固定表のR行へ結び、カタログと閾値を保持する。"""
from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / 'study/00119_技術領域の出生と確認後再試験で入口を比較する'


def main() -> None:
    """
    機能: 既存集計の数値をR01〜06へ転記し設定セルを維持する。
    引数: なし。返り値: None。金融算術やRaw再生を実行しない。
    """
    path = TRIAL / '設定と結果.md'
    text = path.read_text(encoding='utf-8')
    original = (TRIAL / '実行前原文/設定と結果.md').read_text(encoding='utf-8')
    result = json.loads((TRIAL / '成果物/集計.json').read_text(encoding='utf-8'))
    original_header = '作成・実行前固定：2026-11-10。市場実行前の設定であり、結果は未算出。'
    updated_header = '作成・実行前固定：2026-11-10。全70場実行・独立検算を完了した。504セルとS閾値の「未実行」は固定時の用途記録を保持しており、現在の成績はR01〜06と[結果と限界](結果と限界.md)を参照する。'
    text = text.replace(original_header, updated_header)
    names = ['Ttrend_zone','Ttrend_confirm','Ttrend_retest','Treversal_zone','Treversal_confirm','Treversal_retest']
    for index, policy in enumerate(names, 1):
        prefix = f'|R{index:02}|{policy}|'
        old = next(line for line in text.splitlines() if line.startswith(prefix))
        fields = old.split('|')
        stats = result['集計'][policy]
        short, long = stats['1800'], stats['3600']
        touch = long['touches']['100']
        fields[4] = f"全出生{long['births']}・新規可能{long['eligible_births']}・要求{long['requested']}・約定{long['filled']}。30分完了{short['complete']}/60分完了{long['complete']}。60分±100順{touch['favorable']}/逆{touch['adverse']}/未{touch['neither']}、C5平均{long['mean_net5']:,.2f}円。"
        fields[5] = '30/60分×同幅25/50/100/125/200ptの全10条件で70%未達。両分母率は正本へ。'
        text = text.replace(old, '|'.join(fields))
    assert text[text.index('## 手法×時間スケール'):text.index('## 複合条件と結果')] == original[original.index('## 手法×時間スケール'):original.index('## 複合条件と結果')]
    path.write_text(text, encoding='utf-8', newline='\n')
    print('R01〜06更新。504セル・設定明細は実行前原文同体。')


if __name__ == '__main__':
    main()
