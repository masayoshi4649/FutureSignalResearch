"""119の既存成功結果・コードを認証し、再実行せず正式保存する。"""
from pathlib import Path
import gzip
import hashlib
import io
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
WORK = ROOT / 'work/119入口比較'
TRIAL = ROOT / 'study/00119_技術領域の出生と確認後再試験で入口を比較する'


def sha(data: bytes) -> str:
    """
    機能: バイト列の保存指紋を求める。
    引数: data(bytes)は検査する全バイト列。
    返り値: strはSHA256の小文字16進値。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def save(path: Path, data: bytes) -> dict:
    """
    機能: 既存の同体を認証するか新規ファイルへ保存する。
    引数: path(Path)は正式保存先、data(bytes)は内容。
    返り値: dictは相対path・サイズ・SHA256。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        if path.name in ('119コード.zip', 'コード復元索引.json', '保管の確認.json'):
            path.write_bytes(data)
        else:
            assert path.read_bytes() == data, str(path)
    else:
        path.write_bytes(data)
    assert path.read_bytes() == data
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data), 'sha256': sha(data)}


# ----------------------------------------
def main() -> None:
    """
    機能: 固定コード・結果gzip・検査記録の同体を確認して保管する。
    引数: なし。既存119結果・metadata・コードだけを使用する。
    返り値: None。金融計算・Raw・Native・11/09の読込を行わない。
    """
    fixed_bytes = (WORK / 'F1.json').read_bytes()
    assert sha(fixed_bytes) == '55d97efeceeb71f20a39e079f627fa38ad77b5414a64ee5b202a7befb9314006'
    fixed = json.loads(fixed_bytes)
    raw = (WORK / '全70場の入口結果.json').read_bytes()
    assert sha(raw) == '59451c632af132841f3f5f8a7540784ec1acc04a0c8b0c164e9ef466e3009cd2'
    aggregate = (WORK / '集計.json').read_bytes()
    assert sha(aggregate) == 'f0a5ca13fcb64235871146d15e18a296105cfb5ea348af23a67e9948c15371f9'
    independent = (ROOT / 'work/119入口レビュー/独立検算_確定.json').read_bytes()
    assert sha(independent) == '4e74d24f487a7e14e7b3a5a5d7ed6426d1c0f6bfc0be219c09b89407d47f613c'
    assert all(sha(Path(path).read_bytes()) == wanted for path, wanted in fixed['code_sha256'].items())
    assert all(sha(Path(path).read_bytes()) == wanted for path, wanted in fixed['premarket_documents'].items())
    completion = (WORK / '全70場の完了.json').read_bytes()
    assert json.loads(completion)['結果']['sha256'] == sha(raw)
    refs = [save(TRIAL / '成果物/集計.json', aggregate), save(TRIAL / '検査/F1.json', fixed_bytes), save(TRIAL / '検査/F1.sha256', (WORK / 'F1.sha256').read_bytes()), save(TRIAL / '検査/全70場の完了.json', completion), save(TRIAL / '検査/独立検算.json', independent)]
    for source, name in (
        ('work/119入口レビュー/確認.json', '市場前の独立コード検査.json'),
        ('work/119入口の技術的出生/検査/確認.json', '発生器の人工検査.json'),
        ('work/119入口CSV出力/準備の確認.json', 'CSV器の準備.json'),
        ('work/119入口CSV出力/全70独立再読.json', 'CSVの独立再読.json'),
        ('outputs/01a1889f-f2af-7943-a047-543275ee9ed2/119入口比較CSV/CSVの確認.json', 'CSVの生成確認.json'),
    ):
        refs.append(save(TRIAL / '検査' / name, (ROOT / source).read_bytes()))
    buffer = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=buffer, mtime=0, compresslevel=9) as stream:
        stream.write(raw)
    packed = buffer.getvalue()
    assert gzip.decompress(packed) == raw
    result_ref = save(TRIAL / '成果物/全70場の入口結果.json.gz', packed)
    result_ref['展開後bytes'] = len(raw)
    result_ref['展開後SHA256'] = sha(raw)
    refs.append(result_ref)

    # ----------------------------------------
    paths = {Path(path) for path in fixed['code_sha256']}
    paths.update(ROOT / p for p in ('work/119入口レビュー/独立検算する.py', 'work/119入口レビュー/README.md', 'work/119入口レビュー/レビュー記録.py', 'work/119入口の技術的出生/README.md', 'work/118複数技法の入口条件/README.md'))
    paths.update(ROOT / p for p in ('work/119入口CSV出力/出力する.mjs', 'work/119入口CSV出力/CSVを独立再読する.py', 'work/119入口CSV出力/README.md', 'work/119正式保存/表へ結果を結ぶ.py'))
    paths.add(Path(__file__).resolve())
    entries = []
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as stream:
        for path in sorted(paths):
            data = path.read_bytes()
            relative = path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            stream.writestr(info, data, compresslevel=9)
            entries.append({'entry': relative, 'restore_relative': relative, 'bytes': len(data), 'sha256': sha(data)})
    zipped = buffer.getvalue()
    with zipfile.ZipFile(io.BytesIO(zipped)) as stream:
        assert stream.testzip() is None
        assert set(stream.namelist()) == {row['entry'] for row in entries}
        for row in entries:
            data = stream.read(row['entry'])
            assert sha(data) == row['sha256'] and len(data) == row['bytes']
    zip_ref = save(TRIAL / '再現資料/119コード.zip', zipped)
    refs.append(zip_ref)
    index = {'試行': 119, '成功': True, 'zip': zip_ref, 'restore_root': str(ROOT), 'entries': entries, '依存': {'Go': '1.24.2 windows/amd64', 'Python': '3.14.3'}, '実行物は同梱しない': fixed['executable'], '入力は同梱しない': fixed['input'], '原板Nativeは同梱しない': True, '入力再生成は118正式資料を参照': True}
    refs.append(save(TRIAL / '再現資料/コード復元索引.json', (json.dumps(index, ensure_ascii=False, indent=2) + '\n').encode('utf-8')))
    assert (WORK / '全70場の入口結果.json').read_bytes() == raw
    assert (WORK / 'F1.json').read_bytes() == fixed_bytes
    assert (WORK / '集計.json').read_bytes() == aggregate
    proof = {'試行': 119, '成功': True, '保存対象': refs, '金融再実行': False, '金融再集計': False, 'Raw読取': 0, 'Native読取': 0, '11月09読取': False, '結果gzipの全bytes復元一致': True, 'コードZIP全entrySHAサイズCRC一致': True, '元正本前後不変': True, '入力RawNative実行物の重複保存': False, 'CSV作成と全セル再読はRootの別工程': True, 'CSV検査の正式保存': True, '保管器SHA256': sha(Path(__file__).read_bytes())}
    save(TRIAL / '検査/保管の確認.json', (json.dumps(proof, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    print(json.dumps({'成功': True, '結果gzip': result_ref, 'コードZIP': zip_ref, 'code_entries': len(entries)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
