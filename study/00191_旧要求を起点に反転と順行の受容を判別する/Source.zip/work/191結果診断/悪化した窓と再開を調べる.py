"""191の最悪窓・再開遅延・切替実取得を、観測済み特徴で説明する。"""
from pathlib import Path
from datetime import datetime,timezone,timedelta
import gzip
import json
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).parent
BASE=ROOT/'work/191要求起点の受容'
for folder in ('work/181共用接続','work/183単純IFD検証','work/191要求起点の受容'):
    sys.path.insert(0,str(ROOT/folder))
import 共用181 as C
import 当時価格183 as Q
import rules191 as R


def read(path: Path) -> object:
    """
    機能: 診断/結果のJSONを読む。
    引数: path(Path)。
    返り値: objectは保存済みの値。
    """
    data=path.read_bytes();return json.loads(gzip.decompress(data) if path.suffix=='.gz' else data)


def safe(value: object) -> object:
    """
    機能: NumPy/非有限値をJSONの有限値/Noneへ変換する。
    引数: value(object)。
    返り値: object。未知を0へ置換しない。
    """
    if isinstance(value,dict):return {str(k):safe(v) for k,v in value.items()}
    if isinstance(value,(list,tuple,np.ndarray)):return [safe(v) for v in value]
    if isinstance(value,np.integer):return int(value)
    if isinstance(value,np.bool_):return bool(value)
    if isinstance(value,(float,np.floating)):return float(value) if np.isfinite(value) else None
    return value


def rows(pack: dict) -> list:
    """
    機能: 列台帳を取得単位へ変換する。
    引数: pack(dict)。
    返り値: list[dict]。
    """
    return [{k:v[i] for k,v in pack['ledger'].items()} for i in range(len(pack['ledger']['net']))]


def key(row: dict) -> tuple:
    """
    機能: 別口座の同じ実取得を識別する。
    引数: row(dict)。
    返り値: tupleは場/実取得時計/側/幅/期限。
    """
    return tuple(row[k] for k in ('scene','entry_time','entry_line','side','width','horizon'))


def main() -> None:
    """
    機能: 主要案の最悪5場差と、新確認の当時技術・取得価格変化を保存する。
    引数: なし。
    返り値: None。既存Source/条件/金融を変更しない。
    """
    compare=read(BASE/'全候補比較.json.gz')
    packs={n:read(BASE/'集約'/('E191_'+n+'__C0_IFD.json.gz')) for n in ('00','04','06','07','08','10')}
    diag={leg:read(BASE/(leg+'_純成立診断.json.gz')) for leg in C.LEGS}
    inputs={}
    for leg in C.LEGS:
        pure=C.load_pure_leg(leg);f=pure['features'];f.q0_prices=Q.load_q0(pure)
        inputs[leg]=R.P._prepare(f)
    old=rows(packs['00']);result=[]
    names=('m5_ema21_delta_to_side','m5_di_difference_to_side','m5_gap_to_side','m5_hist_delta_to_side','m5_rsi_delta_to_side',
        'm15_ema21_delta_to_side','m15_di_difference_to_side','m30_ema21_delta_to_side','m30_di_difference_to_side',
        'm15_adx','m15_adx_delta','q0_entry_minus_bbmean_sigma_to_side','q0_entry_minus_ema8_atr5_to_side','m1_volume_relative_prior3')
    for number,pack in packs.items():
        if number=='00':continue
        identity=pack['id'];entry=pack['policy']['entry'];picked=rows(pack)
        small=next(r for r in compare['rows'] if r['id']==identity);window=small['期間']['全80']['DAY']['最悪5場既知寄与']
        window_names=[r['scene'] for r in pack['sessions'] if r['kind']=='DAY' and window['start_scene']<=r['scene']<=window['end_scene']]
        new_window=[r for r in picked if r['scene'] in window_names];old_window=[r for r in old if r['scene'] in window_names]
        oldkeys={key(r) for r in old_window};newkeys={key(r) for r in new_window}
        changes={'窓':window,'同じ窓の旧収支':sum(r['net'] for r in old_window if r['net'] is not None),
            '旧だけ':[r for r in old_window if key(r) not in newkeys],
            '候補だけ':[r for r in new_window if key(r) not in oldkeys]}
        transitions=[]
        for row in picked:
            detail=diag[row['leg']][entry];event=row['event']
            reverse=detail.get('reverse_confirmed',[False]*(event+1))[event]
            follow=detail.get('follow_confirmed',[False]*(event+1))[event]
            if not reverse and not follow:continue
            arrays,meta,times,phases,reset,prices=inputs[row['leg']];seed=int(detail['pending_from'][event]);actual=row['side'];source=1-actual if reverse else actual
            technical={label:{k:arrays[side][k][i] for k in names} for label,side,i in
                (('元要求時の元方向',source,seed),('発火時の元方向',source,event),('発火時の実方向',actual,event))}
            quote=prices['ask'] if actual==0 else prices['bid'];sign=1 if actual==0 else -1
            session=next(s for s in pack['sessions'] if s['scene']==row['scene'])
            transitions.append({**row,'種別':'反転再開' if reverse else '順行切替',
                '元要求q0':meta[seed],'発火q0':meta[event],'遅延秒':detail['delay_seconds'][event],
                '受容秒':detail['accept_seconds'][event],'固定水準':detail['level'][event],
                '元要求時の実方向quote':quote[seed],'発火時の実方向quote':quote[event],
                '同じ実方向quoteの進行pt':sign*(quote[event]-quote[seed]),
                '発火q0から取得q1まで秒':row['entry_time']-times[event],
                '取得時から場末締切まで秒':session['close_deadline']-row['entry_time'],
                '技術特徴':technical})
        result.append({'id':identity,'最悪5場の差':changes,'再開又は切替の実取得':transitions})
    output={'rows':result,'注意':'当時特徴の事後診断。閾値最適化・新政策適用ではない。元quoteと新quoteの差は取得遅延の価格変化で、未参加の仮想利益ではない。'}
    (HERE/'悪化窓と実取得の詳細191.json').write_text(json.dumps(safe(output),ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    for r in result:
        print(r['id'],'窓',r['最悪5場の差']['窓']['start_scene'],r['最悪5場の差']['窓']['known_net'],'旧',r['最悪5場の差']['同じ窓の旧収支'])
        for t in r['再開又は切替の実取得']:
            print(t['scene'],t['種別'],t['net'],'遅延',t['遅延秒'],'quote進行',t['同じ実方向quoteの進行pt'])


if __name__=='__main__':main()
