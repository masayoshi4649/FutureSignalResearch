"""105入力helperのコード/人工/静的由来だけを停止へ固定する。"""

import hashlib
import json
from pathlib import Path
import platform
import sys
import zlib


def digest(path):
    """
    機能: コード又はmetadataだけのSHA256を読む。
    引数: path(Path)は明示された小保存物又は旧純戦略コード。
    返り値: strは内容指紋。実原板/CSVは開かない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    """
    機能: 新4場の内容を読まず人工成功と元コード不変を記録する。
    引数: なし。
    返り値: None。停止.jsonを新規作成する。
    """
    here = Path(__file__).resolve().parent
    root = here.parents[1]
    pins = {
        "work/固定後4場の接続準備/停止.json": "d20b2027067c26022f9dd50e29f720b24915fd1ea2613070c0f6fee275ee22e6",
        "work/固定後4場の接続準備/入力metadataの下書き.json": "6641da2ae4609cb798818ebe759c0ad33da204501d5816a6d048a0d03da9f122",
        "study/00105_固定SourceとLD10の四場追加確認/開封前入力予約.json": "17804b1ae1cd6518fbc5749b83acddf64aaefda22f17f90501a5de32df91cbb2",
        "study/00080_FAR後期三手法の15分移植と利益保護/入力台帳.json": "b939bc91b33fd86e933534c3b991d844b8a0200a5f14710e1bd5004edc1aab42"
    }
    for name, value in pins.items():
        assert digest(root / name) == value
    reserved = json.loads((root / "study/00105_固定SourceとLD10の四場追加確認/開封前入力予約.json").read_text(encoding="utf-8-sig"))
    pins.update(reserved["参照SHA256"])
    static = ["scripts/FAR後期15分移植/入力固定.py", "scripts/FAR後期15分移植/原板照合.py",
              "scripts/FAR元三手法のmini連続再現/input.go", "work/104Source再生の接続準備/input.go"]
    pins.update({name: digest(root / name) for name in static})
    assert pins["work/104Source再生の接続準備/input.go"] == "ca4c298ebe0cb035fe5422561f75bcb98bc8537888db6faa2d19d28165896bb7"
    before = {str((root / name).resolve()): digest(root / name) for name in pins}
    assert before == {str((root / name).resolve()): expected for name, expected in pins.items()}
    old = json.loads((root / "study/00080_FAR後期三手法の15分移植と利益保護/入力台帳.json").read_text(encoding="utf-8-sig"))
    strategy = {str(Path(old["純戦略repo"]) / name): value for name, value in old["純戦略SHA256"].items()}
    assert len(strategy) == 43 and all(digest(Path(name)) == expected for name, expected in strategy.items())
    artifact = here / "人工確認.json"
    proof = json.loads(artifact.read_text(encoding="utf-8"))
    assert proof["成功"] and proof["helperSHA256"] == digest(here / "入力を固定する.py")
    assert proof["人工入力"] == 24 and proof["人工生成gzip"] == 6 and len(proof["必要な拒否"]) == 9
    assert proof["未固定Rootでの元本文アクセス"] == 0
    owned = {str((here / name).relative_to(root)).replace("\\", "/"): digest(here / name)
             for name in ("入力を固定する.py", "人工を確認する.py", "停止を記録する.py", "README.md", "由来.json", "人工確認.json")}
    after = {name: digest(Path(name)) for name in before}
    assert before == after and all(digest(Path(name)) == expected for name, expected in strategy.items())
    value = {"成功": True, "市場開封前": True, "scope": "105入力準備コード/手製4場人工だけ。実入力準備完了ではない",
        "所有SHA256": owned, "helperSHA256": digest(here / "入力を固定する.py"),
        "参照metadata/旧コードSHA256前": before, "参照metadata/旧コードSHA256後": after, "前後不変": True,
        "旧80純43SHA256": strategy, "旧純43不変": True, "静的境界": "共有親source_root/相対24refsで旧verifyInput/readBoards/readCandles不変。Symbol唯一コードをContractへ、年月推定なし",
        "人工": {"証拠": "work/105入力の固定準備/人工確認.json", "SHA256": digest(artifact), "入力": 24, "stat": 32,
            "生成gzip": 6, "共有gzip": 2, "共有CSV": 16, "元stat/SHA前後・解凍bytes同体": True, "破損拒否": 9,
            "未固定Rootで本文前拒否": True},
        "実行物": {"種別": "Python script", "path": "work/105入力の固定準備/入力を固定する.py", "SHA256": digest(here / "入力を固定する.py")},
        "環境": {"Python": sys.version, "executable": sys.executable, "OS": platform.platform(), "zlib": zlib.ZLIB_RUNTIME_VERSION},
        "Root実行argv": ["work/venvs/technical-tree/Scripts/python.exe", "-B", "-X", "utf8", "work/105入力の固定準備/入力を固定する.py", "--plan", "<Root固定RunPlan.json>", "--plan-sha", "<現物SHA256>"],
        "標準InputManifest": "source_root/sessions4{id,contract,files6{path,sha256,size}}/純戦略repo/純戦略SHA256。原/生成位置と全SHA/sizeは別の入力の由来と品質.jsonに24refsで保存",
        "RootPlan": "READMEのversion1/trial105/fixed/body_read_allowed/sessions4/source_root/source_finance_executedfalse/reservation178/output_root新規/code_sha256。Rootが別途sealするまで実行禁止",
        "未実施": ["新4場raw/CSV本文/内容SHA", "旧実raw先頭行の読取", "実gzip作成", "新4場Symbolの同定", "Source/特徴/指標/金融実行", "正式入力台帳作成"],
        "共用原ファイル/旧停止/Sourceコード変更": 0}
    path = here / "停止.json"
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2); stream.write("\n")
    print(json.dumps({"成功": True, "helperSHA256": value["helperSHA256"], "停止SHA256": digest(path)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
