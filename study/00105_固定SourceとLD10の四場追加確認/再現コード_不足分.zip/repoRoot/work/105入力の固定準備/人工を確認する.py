"""105入力helperを手製4場だけで検査し、新4場の本文を読まない。"""

import argparse
from datetime import datetime, timezone
import gzip
import importlib.util
import json
import os
from pathlib import Path
import tempfile
import zlib


def board(at, symbol, bad=False):
    """
    機能: 市場に由来しない手製板JSONを作る。
    引数: at(float|None)、symbol(str)、bad(bool)は人工時計/銘柄コード/異常板指定。
    返り値: dictは旧reader形式だけを持つ人工行。
    """
    value = {"Symbol": symbol, "CurrentPrice": 0 if bad else 1000}
    if at is not None:
        value["CurrentPriceTime"] = datetime.fromtimestamp(at, timezone.utc).isoformat()
    for n in range(1, 11):
        value["Buy" + str(n)] = {"Price": 990, "Qty": 1}
        value["Sell" + str(n)] = {"Price": 990 if bad else 1000, "Qty": 1}
    return value


def encode(rows):
    """
    機能: 最終LF無しを含む手製JSONL bytesを返す。
    引数: rows(list[dict])は人工行。
    返り値: bytesは人工入力。実原板を使わない。
    """
    return b"\n".join(json.dumps(r, ensure_ascii=False).encode("utf-8") for r in rows)


def main():
    """
    機能: 4場24入力/不足6gzipの人工と必要な拒否境界を確認する。
    引数: --out(Path)は新規人工証拠JSON。
    返り値: None。Source/金融/新4場入力を開かない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location("入力105人工対象", here / "入力を固定する.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    rejected = []

    def reject(name, action):
        """
        機能: 人工破損が正常化されないことを確認する。
        引数: name(str)、action(callable)は境界名と人工操作。
        返り値: None。拒否されなければAssertionError。
        """
        try:
            action()
        except (ValueError, KeyError, gzip.BadGzipFile, EOFError, zlib.error):
            rejected.append(name)
        else:
            raise AssertionError("破損を成功化:" + name)

    with tempfile.TemporaryDirectory(prefix="105人工_") as directory:
        shared = Path(directory)
        scenes = []
        for session in m.IDS:
            start, end = m.bounds(session)
            stats = []
            for market in m.MARKETS:
                folder = shared / "JP_OSE_Data/future" / market / session
                folder.mkdir(parents=True)
                symbol = "NK_TEST_CODE" if market == "NK225" else "TP_TEST_CODE"
                rows = [board(None, symbol), board(start - 1, symbol), board(start, symbol), board(start, symbol, True),
                        board(start + 1, symbol), board(start + 0.5, symbol), board(start + 2, symbol), board(end, symbol)]
                raw = folder / "book.jsonl"
                raw.write_bytes(encode(rows))
                if session == m.IDS[0]:
                    m.compress_new(raw, folder / "book.jsonl.gz")
                for name, interval in (("candle_1min.csv", 60), ("candle_5min.csv", 300)):
                    times = [datetime.fromtimestamp(start + i * interval, timezone.utc).isoformat() for i in range(2)]
                    text = "time,open,high,low,close,closed\n" + "".join(t + ",1000,1010,990,1000,true\n" for t in times)
                    text += "未確定は時計未使用,0,0,0,0,false\n"
                    (folder / name).write_text(text, encoding="utf-8", newline="")
                for name in m.NAMES:
                    p = folder / name
                    stats.append({"market": market, "name": name, "path": str(p), **m.stat_value(p), "sha256": None})
            scenes.append({"session": session, "contract": None, "stat": stats})
        metadata = {"fixed": False, "market_ready": False, "sessions": list(m.IDS), "scenes": scenes}
        table = m.validate_metadata(metadata, shared)
        before = m.snapshot_originals(table, True)
        output = shared / "FutureSignalResearch/work/105入力の固定準備/人工生成"
        strategy = {"純戦略repo": "人工のみ/Source未使用", "純戦略SHA256": {"人工Sourceを実行しない": "a" * 64}}
        result = m.build_inputs(metadata, shared, output, strategy)
        manifest, quality = m.load(output / "入力台帳.json"), m.load(output / "入力の由来と品質.json")
        assert result["生成gzip"] == 6 and result["共有gzip"] == 2 and result["入力"] == 24
        assert len(manifest["sessions"]) == 4 and all(len(s["files"]) == 6 for s in manifest["sessions"])
        assert all(s["contract"] == "NK_TEST_CODE" for s in manifest["sessions"])
        assert quality["元入力不変"] and quality["原32位置前"] == quality["原32位置後"] == before
        assert len(quality["InputManifest4x6"]) == 24 and sum(r["work生成"] for r in quality["InputManifest4x6"]) == 6
        for scene in manifest["sessions"]:
            for key, file in scene["files"].items():
                path = shared / file["path"]
                assert path.exists() and m.digest(path) == file["sha256"] and path.stat().st_size == file["size"]
                assert ".." not in Path(file["path"]).parts
                if key.endswith("_book"):
                    row = quality["品質"][scene["id"]]["入力品質"][key]
                    assert row["accepted"] == 4 and row["clock_missing"] == row["backward"] == 1 and row["outside"] == 2
                    assert row["bad_last"] == row["bad_quote"] == 1
                    assert row["same_time"] == 1
        assert m.verify_originals(before) == before

        # ----------------------------------------
        # gzip/元変更/型品質の拒否は人工出力のコピーだけを変更する。
        reject("既存生成先拒否", lambda: m.build_inputs(metadata, shared, output, strategy))
        raw = Path(table[m.IDS[0], "NK225", "book.jsonl"]["path"])
        existing = output / "gzip/NK225" / m.IDS[1] / "book.jsonl.gz"
        reject("既存gzip上書き拒否", lambda: m.compress_new(raw, existing))
        broken = shared / "CRC破損.gz"
        data = bytearray(existing.read_bytes()); data[-8] ^= 1; broken.write_bytes(data)
        reject("gzipCRC破損", lambda: m.inspect_gzip(broken, m.IDS[1], m.digest(Path(table[m.IDS[1], "NK225", "book.jsonl"]["path"]))))
        wrong = shared / "bytes差.gz"
        with gzip.open(wrong, "wb") as stream:
            stream.write(raw.read_bytes() + b"\n")
        reject("解凍bytes差", lambda: m.inspect_gzip(wrong, m.IDS[0], m.digest(raw)))
        for label, rows in (("Symbol複数", [board(m.bounds(m.IDS[0])[0], "A"), board(m.bounds(m.IDS[0])[0] + 1, "B")]),
                            ("Symbol欠損", [{"CurrentPriceTime": "2026-11-05T08:45:00+09:00"}])):
            raw_test, compressed = shared / (label + ".jsonl"), shared / (label + ".gz")
            raw_test.write_bytes(encode(rows)); m.compress_new(raw_test, compressed)
            reject(label, lambda p=compressed, r=raw_test: m.inspect_gzip(p, m.IDS[0], m.digest(r)))
        csv_bad = shared / "非有限.csv"
        csv_bad.write_text("time,open,high,low,close,closed\n2026-11-05T08:45:00+09:00,NaN,1,1,1,true\n", encoding="utf-8")
        reject("CSV非有限", lambda: m.inspect_csv(csv_bad, m.IDS[0], 60))
        isolated = shared / "元変更.jsonl"
        isolated.write_bytes(b"aaaa")
        old = {str(isolated): {**m.stat_value(isolated), "sha256": m.digest(isolated)}}
        stamp = isolated.stat(); isolated.write_bytes(b"bbbb"); os.utime(isolated, ns=(stamp.st_atime_ns, stamp.st_mtime_ns))
        reject("同size同mtimeでも元SHA変更", lambda: m.verify_originals(old))

        # ----------------------------------------
        # 未固定Root計画は本物metadataや原入力に達する前に拒否する。
        plan = shared / "未固定.json"
        plan.write_text(json.dumps({"version": 1, "trial": 105, "fixed": False}), encoding="utf-8")
        accesses, original = [], m.digest

        def tracked(path):
            """
            機能: 人工guardのhashアクセス先を記録する。
            引数: path(Path)は人工計画。
            返り値: strは元digestの値。
            """
            accesses.append(Path(path))
            return original(path)

        expected = original(plan)
        m.digest = tracked
        try:
            reject("Root未固定は本文前拒否", lambda: m.guard(plan, expected))
        finally:
            m.digest = original
        assert accesses == [plan]
        assert m.clock("2026-11-05 08:45:00+09:00") is None
        assert m.clock("2026-11-05T08:45:00.000000100+09:00") == float(int(m.bounds(m.IDS[0])[0]) * 1_000_000_000 + 100) / 1e9
    receipt = {"成功": True, "scope": "全て手製4場。新4場/旧実原板/CSV本文は0。Source/指標/金融は実行しない",
               "人工入力": 24, "人工stat": 32, "人工生成gzip": 6, "人工共有gzip": 2, "人工共有CSV": 16,
               "解凍bytes同体/元前後statSHA": True, "NK_SymbolをContractへ/年月変換なし": True,
               "共有親相対path結合": True, "必要な拒否": rejected, "未固定Rootでの元本文アクセス": 0,
               "helperSHA256": m.digest(here / "入力を固定する.py")}
    with args.out.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(receipt, stream, ensure_ascii=False, indent=2); stream.write("\n")
    print(json.dumps({"成功": True, "人工入力": 24, "生成gzip": 6, "拒否": len(rejected)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
