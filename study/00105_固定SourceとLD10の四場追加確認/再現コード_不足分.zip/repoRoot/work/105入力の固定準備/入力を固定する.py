"""105のRoot開封固定後だけ、不足6gzipと4場24入力の指紋を作る。"""

import argparse
import csv
from datetime import datetime, timedelta, timezone
import gzip
import hashlib
import json
import math
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[2]
SHARED = ROOT.parent
HERE = Path(__file__).resolve().parent
METADATA_PATH = ROOT / "work/固定後4場の接続準備/入力metadataの下書き.json"
METADATA_SHA = "6641da2ae4609cb798818ebe759c0ad33da204501d5816a6d048a0d03da9f122"
METADATA_STOP = ROOT / "work/固定後4場の接続準備/停止.json"
METADATA_STOP_SHA = "d20b2027067c26022f9dd50e29f720b24915fd1ea2613070c0f6fee275ee22e6"
OLD80 = ROOT / "study/00080_FAR後期三手法の15分移植と利益保護/入力台帳.json"
OLD80_SHA = "b939bc91b33fd86e933534c3b991d844b8a0200a5f14710e1bd5004edc1aab42"
RESERVATION = ROOT / "study/00105_固定SourceとLD10の四場追加確認/開封前入力予約.json"
RESERVATION_SHA = "17804b1ae1cd6518fbc5749b83acddf64aaefda22f17f90501a5de32df91cbb2"
IDS = ("2026-11-05_Day", "2026-11-05_Night", "2026-11-06_Day", "2026-11-06_Night")
MARKETS = ("NK225", "TOPIX")
NAMES = ("book.jsonl", "book.jsonl.gz", "candle_1min.csv", "candle_5min.csv")
BLOCK = 1024 * 1024
MAX_LINE = 4 * 1024 * 1024


def need(ok, reason):
    """
    機能: 品質や未固定の不成立を例外へする。
    引数: ok(bool)、reason(str)は成立条件と説明。
    返り値: None。不成立ならValueError。
    """
    if not ok:
        raise ValueError(reason)


def digest(path):
    """
    機能: 通常ファイルのbytesをstreamでSHA256へする。
    引数: path(Path)はRoot許可後の入力又はコード/metadata。
    返り値: strはSHA256。元ファイルは変更しない。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    """
    機能: 明示したmetadataのJSONを読む。
    引数: path(Path)は計画/予約/台帳。
    返り値: dictは保存値。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_new(path, value):
    """
    機能: 新規JSONだけをUTF-8で保存する。
    引数: path(Path)、value(dict)は出力先と値。
    返り値: None。既存先は拒否する。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def stat_value(path):
    """
    機能: 内容を読まず存在/size/mtime_nsを取得する。
    引数: path(Path)は原位置。
    返り値: dictはstat値。不存在はnullで明示。
    """
    if not path.exists():
        return {"exists": False, "size": None, "mtime_ns": None}
    need(path.is_file(), "入力が通常ファイルでない")
    value = path.stat()
    return {"exists": True, "size": value.st_size, "mtime_ns": value.st_mtime_ns}


def validate_metadata(value, shared):
    """
    機能: 32statの原位置と4場/二市場の完全集合を検査する。
    引数: value(dict)、shared(Path)は停止metadataと共有親。
    返り値: dictは(session,market,name)→元stat。本文はまだ読まない。
    """
    need(value["fixed"] is False and value["market_ready"] is False, "元metadataの未固定区別")
    need(value["sessions"] == list(IDS) and [s["session"] for s in value["scenes"]] == list(IDS), "候補4場だけ")
    table = {}
    for scene in value["scenes"]:
        need(scene["contract"] is None, "未読限月を補完しない")
        for item in scene["stat"]:
            key = scene["session"], item["market"], item["name"]
            need(key not in table and key[1] in MARKETS and key[2] in NAMES, "stat重複/集合")
            expected = (shared / "JP_OSE_Data/future" / key[1] / key[0] / key[2]).resolve()
            need(Path(item["path"]).resolve() == expected and item["sha256"] is None, "stat原位置/未読SHA")
            need(item["exists"] is (key[2] != "book.jsonl.gz" or key[0] == IDS[0]), "既存gzipは11/5Day二つのみ")
            table[key] = item
    need(set(table) == {(s, m, n) for s in IDS for m in MARKETS for n in NAMES}, "32stat完全集合")
    return table


def snapshot_originals(table, with_hash):
    """
    機能: 停止statの一致と存在26入力の現在指紋を記録する。
    引数: table(dict)、with_hash(bool)は32statと内容開封の有無。
    返り値: dictは絶対path→stat/SHA。with_hashはRoot許可後だけ真。
    """
    values = {}
    for item in table.values():
        path = Path(item["path"])
        current = stat_value(path)
        need(current == {k: item[k] for k in current}, "元statが変化:" + str(path))
        values[str(path)] = {**current, "sha256": digest(path) if with_hash and current["exists"] else None}
    return values


def verify_originals(before):
    """
    機能: 元32位置のsize/mtime/SHAが最後まで不変か再確認する。
    引数: before(dict)は開封前のstat/存在26SHA。
    返り値: dictは再読した後指紋。元変更は成功にしない。
    """
    after = {}
    for name, expected in before.items():
        path = Path(name)
        current = stat_value(path)
        after[name] = {**current, "sha256": digest(path) if current["exists"] else None}
        need(after[name] == expected, "元入力の前後変更:" + name)
    return after


def compress_new(source, target):
    """
    機能: 原bytesを新規work gzipへstream圧縮する。
    引数: source/target(Path)は原JSONLと不存在gzip。
    返り値: strは圧縮に使った原bytes SHA。価格/Source計算はしない。
    """
    need(source.resolve() != target.resolve() and not target.exists(), "圧縮先既存/原位置上書き拒否")
    target.parent.mkdir(parents=True, exist_ok=True)
    h = hashlib.sha256()
    with source.open("rb") as raw, target.open("xb") as destination:
        with gzip.GzipFile(filename="", mode="wb", compresslevel=6, fileobj=destination, mtime=0) as output:
            while chunk := raw.read(BLOCK):
                h.update(chunk)
                output.write(chunk)
    return h.hexdigest()


def bounds(session):
    """
    機能: 旧93の半開場時計をJSTで表す。
    引数: session(str)はYYYY-MM-DD_Day/Night。
    返り値: tuple[float,float]は開始/終了Unix秒。
    """
    day, kind = session.split("_")
    base = datetime.fromisoformat(day).replace(tzinfo=timezone(timedelta(hours=9)))
    if kind == "Day":
        return (base + timedelta(hours=8, minutes=45)).timestamp(), (base + timedelta(hours=15, minutes=45)).timestamp()
    need(kind == "Night", "場種不正")
    return (base + timedelta(hours=17)).timestamp(), (base + timedelta(days=1, hours=6)).timestamp()


def clock(value):
    """
    機能: timezone付き価格/足時計をUnix秒へ読む。
    引数: value(any)は原JSON/CSV時計。
    返り値: float又はNoneは有効時計又は配置不能。時計を補完しない。
    """
    if value is None:
        return None
    need(isinstance(value, str), "時計の型不正")
    matched = re.fullmatch(r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:[.,](\d{1,9}))?(Z|[+-]\d{2}:\d{2})", value)
    if matched is None:
        return None
    try:
        base, fraction, zone = matched.groups()
        parsed = datetime.fromisoformat(base + zone.replace("Z", "+00:00"))
        nanoseconds = int(parsed.timestamp()) * 1_000_000_000 + int((fraction or "").ljust(9, "0"))
        return float(nanoseconds) / 1e9
    except ValueError:
        return None


def finite(value):
    """
    機能: Goのnull→0と有限数値を品質検査用に読む。
    引数: value(any)は価格/板量/足値。
    返り値: floatは有限値。bool/非有限を支持や正常へ補完しない。
    """
    if value is None:
        return 0.0
    need(type(value) in (int, float) and math.isfinite(value), "数値型/非有限の破損")
    return float(value)


def inspect_gzip(path, session, expected_raw):
    """
    機能: gzip解凍bytes同体と原Symbol/価格時計の品質だけを検査する。
    引数: path(Path)、session/expected_raw(str)はgzip、場ID、元JSONL SHA。
    返り値: dictは旧93相当の時計/BBO品質件数と唯一Symbol。指標/損益は計算しない。
    """
    start, end = bounds(session)
    previous, had_previous, h, symbols = start, False, hashlib.sha256(), set()
    q = {name: 0 for name in ("lines", "clock_missing", "outside", "backward", "same_time", "bad_last", "bad_quote", "accepted")}
    with gzip.open(path, "rb") as stream:
        while line := stream.readline(MAX_LINE + 1):
            need(len(line) <= MAX_LINE, "旧reader上限を超える原行")
            h.update(line)
            q["lines"] += 1
            row = json.loads(line, parse_constant=invalid_constant)
            need(isinstance(row, dict) and isinstance(row.get("Symbol"), str) and bool(row["Symbol"].strip()), "Symbol欠損/型不正")
            symbols.add(row["Symbol"])
            at = clock(row.get("CurrentPriceTime"))
            if at is None:
                q["clock_missing"] += 1
                continue
            if not start <= at < end:
                q["outside"] += 1
                continue
            if at < previous:
                q["backward"] += 1
                continue
            q["same_time"] += had_previous and at == previous
            previous = at
            had_previous = True
            last = finite(row.get("CurrentPrice"))
            levels = {}
            for side in ("Buy", "Sell"):
                for n in range(1, 11):
                    name = side + str(n)
                    need(name in row and (row[name] is None or isinstance(row[name], dict)), "板階層の型/欠損")
                    value = row[name] or {}
                    levels[name] = (finite(value.get("Price")), finite(value.get("Qty")))
            bid, ask = levels["Buy1"][0], levels["Sell1"][0]
            q["bad_last"] += last <= 0
            q["bad_quote"] += bid <= 0 or ask <= bid
            q["accepted"] += 1
    need(h.hexdigest() == expected_raw, "gzip解凍bytesが元JSONLと不一致")
    need(q["accepted"] > 0 and len(symbols) == 1, "採用時計無し/複数Symbol")
    return {**q, "contracts": sorted(symbols), "uncompressed_sha256": h.hexdigest(),
            "contract_codesの意味": "原Symbolコードそのもの。年月は未解読/推定変換なし", "受信時計": "旧reader同様CurrentPriceTimeを代理にする。真の受信遅延は未査定"}


def invalid_constant(value):
    """
    機能: GoのJSON decoderが許さないNaN/Infinity tokenを拒否する。
    引数: value(str)は非標準JSON token。
    返り値: None。常にValueError。
    """
    raise ValueError("不正JSON定数:" + value)


def inspect_csv(path, session, interval):
    """
    機能: CSV指紋とは別に確定足の時計/形式だけを数える。
    引数: path(Path)、session(str)、interval(int)はCSV/場/60又は300秒。
    返り値: dictは時計品質。価格や損益の要約/指標再計算はしない。
    """
    start, end = bounds(session)
    q = {name: 0 for name in ("rows", "not_closed", "closed", "outside", "accepted", "backward", "same_time")}
    previous = None
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        need(set(("time", "open", "high", "low", "close", "closed")).issubset(reader.fieldnames or []), "足の列不足")
        for row in reader:
            q["rows"] += 1
            if row["closed"] != "true":
                q["not_closed"] += 1
                continue
            q["closed"] += 1
            at = clock(row["time"])
            need(at is not None, "確定足の時計不正")
            for name in ("open", "high", "low", "close"):
                finite(float(row[name]))
            if not start <= at < end:
                q["outside"] += 1
                continue
            q["backward"] += previous is not None and at < previous
            q["same_time"] += previous is not None and at == previous
            previous = at
            q["accepted"] += 1
    need(q["accepted"] > 0, "確定足無し")
    return {**q, "interval_seconds": interval, "時計逆行と同秒": "独立品質件数。旧loader自体にはCSV逆順検査なし",
            "未計算": "OHLC要約/テクニカル/損益。公開遅延は後段旧reader契約であり本helperで再時刻化しない"}


def build_inputs(metadata, shared, output, strategy):
    """
    機能: 許可後の26元入力を不変で固定し、不足6gzipだけを作る。
    引数: metadata(dict)、shared/output(Path)、strategy(dict)は停止stat/共有親/新work先/旧43参照。
    返り値: dictは成功件数。標準InputManifestと24入力由来表を別々に保存する。
    """
    table = validate_metadata(metadata, shared)
    need(not output.exists(), "生成先は新規のみ")
    before = snapshot_originals(table, True)
    need(sum(v["exists"] for v in before.values()) == 26, "元入力26存在")
    output.mkdir(parents=True)
    scenes, quality, origins, generated = [], {}, [], 0
    for session in IDS:
        files, scene_quality, contracts = {}, {}, {}
        for market in MARKETS:
            raw = Path(table[session, market, "book.jsonl"]["path"])
            old_gzip = Path(table[session, market, "book.jsonl.gz"]["path"])
            expected = before[str(raw)]["sha256"]
            if table[session, market, "book.jsonl.gz"]["exists"]:
                actual, created = old_gzip, False
            else:
                actual, created = output / "gzip" / market / session / "book.jsonl.gz", True
                need(compress_new(raw, actual) == expected, "圧縮中に元入力変更")
                generated += 1
            board_quality = inspect_gzip(actual, session, expected)
            contracts[market] = board_quality["contracts"][0]
            scene_quality[market + "_book"] = board_quality
            files[market + "_book"] = {"path": actual.relative_to(shared).as_posix(), "sha256": digest(actual), "size": actual.stat().st_size}
            origins.append({"session": session, "key": market + "_book", "原位置": str(raw), "原SHA256": expected,
                            "原size": raw.stat().st_size, "使用位置": str(actual), "work生成": created, "使用SHA256": files[market + "_book"]["sha256"],
                            "使用size": files[market + "_book"]["size"], "解凍SHA256": board_quality["uncompressed_sha256"]})
            for interval, name in ((60, "candle_1min.csv"), (300, "candle_5min.csv")):
                original = Path(table[session, market, name]["path"])
                key = market + "_candle_" + str(interval)
                files[key] = {"path": original.relative_to(shared).as_posix(), "sha256": before[str(original)]["sha256"], "size": original.stat().st_size}
                scene_quality[key] = inspect_csv(original, session, interval)
                origins.append({"session": session, "key": key, "原位置": str(original), "原SHA256": files[key]["sha256"],
                                "原size": files[key]["size"], "使用位置": str(original), "work生成": False,
                                "使用SHA256": files[key]["sha256"], "使用size": files[key]["size"]})
        need(len(files) == 6 and len(contracts) == 2, "二市場6入力/元Symbol")
        scenes.append({"id": session, "contract": contracts["NK225"], "files": files})
        quality[session] = {"入力品質": scene_quality, "NK契約コード": contracts["NK225"], "TOPIX契約コード": contracts["TOPIX"], "年月への変換": "未実施"}
    need(generated == 6 and len(origins) == 24, "不足6gzip/24入力")
    after = verify_originals(before)
    manifest = {"source_root": str(shared), "sessions": scenes, "純戦略repo": strategy["純戦略repo"], "純戦略SHA256": strategy["純戦略SHA256"]}
    write_new(output / "入力台帳.json", manifest)
    write_new(output / "入力の由来と品質.json", {"成功": True, "source_root": str(shared), "InputManifest4x6": origins,
        "原32位置前": before, "原32位置後": after, "元入力不変": True, "生成gzip": 6, "共有gzip": 2, "共有CSV": 16,
        "品質": quality, "価格/損益要約/Source/指標/金融": "未実施", "年月への推定変換": False})
    return {"成功": True, "場数": 4, "入力": 24, "生成gzip": 6, "共有gzip": 2, "原26SHA前後一致": True}


def guard(plan_path, plan_sha):
    """
    機能: Root開封計画/予約/全codeが固定される前に本文アクセスを拒否する。
    引数: plan_path(Path)、plan_sha(str)はRootが別途sealする計画参照。
    返り値: tupleはmetadata/共有親/新規先/旧43参照/前metadata指紋。
    """
    need(len(plan_sha) == 64 and digest(plan_path) == plan_sha, "Root計画SHA未固定")
    plan = load(plan_path)
    need(plan["version"] == 1 and plan["trial"] == 105 and plan["fixed"] is True and plan["body_read_allowed"] is True, "Rootの開封固定が必要")
    need(plan["sessions"] == list(IDS) and plan["source_finance_executed"] is False, "開封だけの4場scope")
    need(Path(plan["source_root"]).resolve() == SHARED, "source_rootは共用親")
    pinned = {METADATA_PATH: METADATA_SHA, METADATA_STOP: METADATA_STOP_SHA, OLD80: OLD80_SHA}
    for path, expected in pinned.items():
        need(digest(path) == expected, "停止metadata/旧80差")
    code = plan["code_sha256"]
    need(code and code.get(Path(__file__).resolve().relative_to(ROOT).as_posix()) == digest(Path(__file__)), "当helperの固定が必要")
    for name, expected in code.items():
        path = (ROOT / name).resolve()
        need(len(expected) == 64 and digest(path) == expected, "RootコードSHA差")
        pinned[path] = expected
    ref = plan["reservation"]
    need(set(ref) == {"path", "sha256"} and ref["path"] and len(ref["sha256"]) == 64, "Root予約FileRefが必要")
    reservation = (plan_path.parent / ref["path"]).resolve()
    need(reservation == RESERVATION and digest(reservation) == ref["sha256"] == RESERVATION_SHA, "Root予約SHA差")
    reserved = load(reservation)
    need(reserved["version"] == 1 and reserved["trial"] == 105 and reserved["予約固定"] is True and reserved["入力内容固定"] is False and reserved["sessions"] == list(IDS), "Root予約の位置付け")
    original_table = validate_metadata(load(METADATA_PATH), SHARED)
    expected_stats = [{"session": key[0], **{n: item[n] for n in ("market", "name", "path", "exists", "size", "mtime_ns")}} for key, item in original_table.items()]
    need(reserved["stat32"] == expected_stats, "Root予約と元32stat差")
    for name, expected in reserved["参照SHA256"].items():
        path = (ROOT / name).resolve()
        need(digest(path) == expected, "予約のSnapshot/補足/新metadata SHA差")
        pinned[path] = expected
    pinned[reservation] = ref["sha256"]
    output = (plan_path.parent / plan["output_root"]).resolve()
    need(output.is_relative_to(HERE) and output != HERE and not output.exists(), "work内の新規生成先のみ")
    strategy = load(OLD80)
    need(len(strategy["純戦略SHA256"]) == 43, "旧80純43")
    for name, expected in strategy["純戦略SHA256"].items():
        path = Path(strategy["純戦略repo"]) / name
        need(digest(path) == expected, "純43変更拒否")
        pinned[path] = expected
    pinned[plan_path] = plan_sha
    return load(METADATA_PATH), SHARED, output, strategy, pinned


def main():
    """
    機能: Root実行時だけ入力を準備し完了receiptを最後に保存する。
    引数: --plan/--plan-shaはRootが開封前にsealする小計画。
    返り値: None。未固定は元本文/内容SHAへ到達しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--plan-sha", required=True)
    args = parser.parse_args()
    metadata, shared, output, strategy, pinned = guard(args.plan.resolve(), args.plan_sha)
    result = build_inputs(metadata, shared, output, strategy)
    need(all(digest(p) == expected for p, expected in pinned.items()), "計画/予約/コード/純43の前後差")
    write_new(output / "完了.json", {**result, "Root計画SHA256": args.plan_sha,
        "入力台帳SHA256": digest(output / "入力台帳.json"), "由来品質SHA256": digest(output / "入力の由来と品質.json"),
        "metadata/予約/コード/純43前後SHA256": {str(p): h for p, h in pinned.items()}, "前後不変": True,
        "Source/指標/金融/新規実装実行": 0})
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
