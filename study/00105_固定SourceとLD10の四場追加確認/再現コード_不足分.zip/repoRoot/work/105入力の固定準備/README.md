# 105入力の固定準備

この停止はコードと人工だけ。新4場の原板・CSV本文・内容SHAは未読/未算出であり、入力準備の実成功ではない。Rootが105開封計画・予約・コードを先に固定し、別途実行を許可してから本CLIを実行する。Source・特徴・金融・指標は呼ばない。

元metadataは `work/固定後4場の接続準備/入力metadataの下書き.json`（6641da2a…）、停止d20b2027…、32stat/26存在を参照する。11月5日Dayの二市場gzipは共有参照。残る3場×二市場の6gzipだけを新workへ作り、16CSVは共有参照する。JP_OSE_Dataの原位置は作成/上書き/移動しない。

## RootがsealするRunPlan

```json
{
  "version": 1,
  "trial": 105,
  "fixed": true,
  "body_read_allowed": true,
  "sessions": ["2026-11-05_Day", "2026-11-05_Night", "2026-11-06_Day", "2026-11-06_Night"],
  "source_root": "S:/GitHub/masayoshi4649",
  "source_finance_executed": false,
  "reservation": {"path": "開封前入力予約.json", "sha256": "17804b1ae1cd6518fbc5749b83acddf64aaefda22f17f90501a5de32df91cbb2"},
  "output_root": "../../work/105入力の固定準備/生成",
  "code_sha256": {"work/105入力の固定準備/入力を固定する.py": "<停止済みの実SHA>"}
}
```

例の相対pathはRunPlanの親ディレクトリ基準。`code_sha256`キーはFutureSignalResearchのrepo基準又は絶対path。`source_root`だけは共有親の固定絶対pathである。生成先は本workフォルダ内の不存在ディレクトリに限る。Rootは必要なSnapshot/コード等をcode mapへ追加できる。予約の参照SHA256にある実行前README/設定/入力仕様補足/計画生成コード/新metadata等も全て開封前に検査する。

```powershell
& work/venvs/technical-tree/Scripts/python.exe -B -X utf8 `
  work/105入力の固定準備/入力を固定する.py `
  --plan '<RootがsealしたRunPlan.json>' --plan-sha '<その現物SHA256>'
```

これはRoot実行手順であり、本停止では実行しない。planのfixed/body_read_allowed/4ID/予約/コード/SHAが欠ける場合、原入力本文や内容SHAに到達する前に拒否する。`--help`は市場入力を読まない。

## 元ファイルとgzip

最初に32位置の存在/size/mtime_nsを停止metadataと照合し、存在26ファイルのSHAを取得する。6gzipをgzip level6・mtime0・空filename headerでstream圧縮する。既存gzip二つも含め全8gzipを最後まで解凍し、元JSONLとbytes SHAが同一であることとCRCを確認する。元26入力のsize/mtime/SHA、不在6位置のままかを最後に再確認する。既存生成先/gzipを上書きしない。

失敗時のwork生成物は未完了として残り得るが、完了.jsonを成功として作らない。再実行は別の不存在出力先をRoot計画へ固定する。共有原ファイルを復旧/訂正したと装わない。

## 限月・時計の意味

80 `入力固定.py` は旧28台帳contract_codesの唯一値をInputManifest.Contractへコピーする。80 `原板照合.py` と旧93/104 `readBoards` のcontractsは原JSONの `Symbol` 集合そのもの。年月202612へ変換しない。新4場の全行でNK Symbolが唯一・非空ならそのコードをContractへ固定し、TOPIXの唯一コードは別に保存する。複数/欠損/型不正は失敗。

原板品質は旧readerと同じ価格時計の半開場 `Start<=CurrentPriceTime<End`、後退除外/同時計保持、Last<=0/badBBOを別件数とする。時計欠損も件数へ残す。価格値・平均・損益は出力しない。Receivedは旧93同様CurrentPriceTimeの代理であり、真の受信遅延の品質を検証したとは呼ばない。Symbolは時計除外行も含む全行から集める。

CSVはtime/open/high/low/close/closedの形式、closed文字列true、半開場内の足開始時計を確認する。有限値は独立の品質検査として必須とし、逆順/同時計は件数で残す（旧loader自身にはCSV逆順検査なし）。OHLC要約/テクニカルは計算しない。旧replayの1分delay0/5分delay60による公開は後段の責務で、本helperで足を再時刻化しない。

## 出力と旧reader

標準 `入力台帳.json` は既存InputManifestの型だけを保つ。source_rootを共有親にし、`JP_OSE_Data/future/...` の既存gzip/CSVと `FutureSignalResearch/work/105入力の固定準備/...` の生成gzipを相対参照する。旧verifyInputの `filepath.Join(root, f.Path)` で混在解決できるため、readBoards/readCandlesは変更しない。

4場×6InputFileの原位置→共有/生成位置・原/使用/解凍SHA・sizeを `入力の由来と品質.json` の `InputManifest4x6` に全て保存する。標準Go型へ未知fieldを加えず、Root条件が両JSONのFileRefを固定する。最後の `完了.json` に両SHA、Root計画SHA、metadata/予約/コード/旧43の前後不変を記録する。

旧80純戦略43はその参照/現物SHAを再用し、Source停止コードも変更しない。入力を準備しただけでSource生成やLD10金融成功とは呼ばない。

## 人工

`人工を確認する.py --out <新規JSON>` は一時ディレクトリに手製4場/32位置を作るだけ。6gzip生成、共有2gzip/16CSV、解凍bytes同体、元不変、Symbolコード保持、同秒/逆行/場外/欠損時計を確認した。既存先、CRC破損、解凍bytes差、同size同mtimeでの元SHA変更、複数/欠損Symbol、CSV非有限、未固定Rootの9拒否を確認する。実4場や旧実原板先頭行も読まない。
