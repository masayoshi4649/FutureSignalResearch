"""105の小集計だけを四感度報告へ差し込み、原計画を別bytesで保持する。"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
from decimal import Decimal
from pathlib import Path
from typing import Any

WORK = Path(__file__).resolve().parent
KEYS = [f'LD10_B5Q_P0_C{cost}_D{delay}' for cost in (0, 5) for delay in (0, 1)]
STATUS_BEGIN = '<!-- REPORT105:STATUS:BEGIN -->'
STATUS_END = '<!-- REPORT105:STATUS:END -->'
RESULT_BEGIN = '<!-- REPORT105:RESULT:BEGIN -->'
RESULT_END = '<!-- REPORT105:RESULT:END -->'


def sha(path: Path) -> str:
    """
    機能: 明示した文書/小集計の実指紋を確認する。
    引数: path (Path) は対象ファイル。
    返り値: str は小文字64桁のSHA256。
    """
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read_json(path: Path) -> dict:
    """
    機能: 非有限値を拒否して小さい保存辞書を読む。
    引数: path (Path) はRoot固定後の集計又はmetadata。
    返り値: dict は半円をDecimalで保持した値。
    """
    def reject(value: str) -> None:
        """
        機能: JSONの非有限数値を拒否する。
        引数: value (str) は不正な定数。
        返り値: None。常にValueErrorを送出する。
        """
        raise ValueError(f'非有限JSON: {value}')
    return json.loads(path.read_text(encoding='utf-8-sig'), parse_float=Decimal, parse_constant=reject)


def file_ref(ref: dict, base: Path, fingerprints: dict[str, str]) -> Path:
    """
    機能: Root固定FileRefを解決し内容SHAへ結ぶ。
    引数: ref (dict)、base (Path)、fingerprints (dict[str,str]) は参照・基準・前指紋。
    返り値: Path は検査済みの絶対path。
    """
    assert isinstance(ref, dict) and set(ref) == {'path', 'sha256'}
    assert isinstance(ref['path'], str) and ref['path'].strip()
    assert re.fullmatch(r'[0-9a-f]{64}', ref['sha256'])
    path = Path(ref['path'])
    path = (path if path.is_absolute() else base / path).resolve()
    assert sha(path) == ref['sha256'], path
    fingerprints[str(path)] = ref['sha256']
    return path


def finite(value: Any) -> Decimal:
    """
    機能: 金額/計数を有限の数値として検査する。
    引数: value (Any) は元集計値。
    返り値: Decimal は補完しない元の値。
    """
    assert isinstance(value, (int, float, Decimal)) and not isinstance(value, bool)
    out = Decimal(str(value))
    assert out.is_finite()
    return out


def validate_totals(total: dict, denom: int) -> None:
    """
    機能: 保存集約の算術と参加・二旗の分母を確認する。
    引数: total (dict)、denom (int) は一感度の保存集約と予定枠。
    返り値: None。欠測fieldや不整合を0へ補完しない。
    """
    assert finite(total['gross_yen']) - finite(total['fee_yen']) - finite(total['slip_yen']) == finite(total['net_yen'])
    assert finite(total['gross_yen']) - finite(total['fee_yen']) == finite(total['gross_minus_fee_yen'])
    assert finite(total['positive_yen']) + finite(total['negative_yen']) == finite(total['net_yen'])
    assert finite(total['positive_yen']) >= 0 and finite(total['negative_yen']) <= 0
    assert sum(total[field] for field in ('positive_positions', 'negative_positions', 'zero_positions')) == total['positions']
    for field in ('unit_positive_positions', 'protection_activated_positions', 'unit_positive_closed_negative', 'activated_closed_negative'):
        assert type(total[field]) is int and 0 <= total[field] <= total['positions']
    assert total['unit_positive_closed_negative'] <= total['unit_positive_positions']
    assert total['activated_closed_negative'] <= total['protection_activated_positions']
    assert finite(total['unit_positive_closed_negative_yen']) <= 0 and finite(total['activated_closed_negative_yen']) <= 0
    assert finite(total['保存点連結時価DD']) >= 0
    if finite(total['negative_yen']) < 0:
        expected = finite(total['positive_yen']) / -finite(total['negative_yen'])
        assert abs(finite(total['PF']) - expected) <= Decimal('0.000000001')
    else:
        assert total['PF'] is None
    activity = total['活動主表']
    assert activity['denom'] == denom
    assert activity['new'] + activity['hold'] == activity['active']
    assert activity['active'] + activity['wait'] + activity['unknown'] == denom
    assert abs(finite(activity['参加率']) - Decimal(activity['active']) / denom) <= Decimal('0.000000000001')
    assert total['entry_quantity'] == total['close_quantity']
    assert all(total[field] == 0 for field in ('open_buy', 'open_sell', 'pending_buy', 'pending_sell'))


def prepare(fixed_path: Path, fixed_sha: str) -> tuple[dict, dict[str, str]]:
    """
    機能: 将来Rootが許可したfull4実績だけを結果化の入力へ結ぶ。
    引数: fixed_path (Path)、fixed_sha (str) は新規事後固定JSONと現物指紋。
    返り値: tuple[dict,dict[str,str]] は検査済み小集計と入力前指紋。
    """
    assert re.fullmatch(r'[0-9a-f]{64}', fixed_sha) and sha(fixed_path) == fixed_sha
    config = read_json(fixed_path)
    assert config['version'] == 1 and config['trial'] == 105 and config['fixed'] is True and config['result_ready'] is True
    before = {str(fixed_path.resolve()): fixed_sha}
    base = fixed_path.resolve().parent
    paths = {name: file_ref(config[name], base, before) for name in ('summary', 'saved_check', 'source_completion', 'financial_completion')}
    result, saved, source, financial = (read_json(paths[name]) for name in ('summary', 'saved_check', 'source_completion', 'financial_completion'))
    assert result['試行'] == 105 and result['成功'] is True and result['場数'] == 4 and result['会計数'] == 16
    assert result['stage'] == 'full4' and result['SourceMode'] == 'symmetric' and result['診断会計数'] == 0
    assert result['前後不変'] is True and result['入力codeSHA256前'] == result['入力codeSHA256後']
    assert result['旧市場golden'] == {'対象外': True, '対照会計': 0} and result['legacy/default金融会計'] == 0
    assert set(result['集計']) == set(KEYS) and set(result['実現診断']) == set(KEYS)
    assert saved['成功'] is True and saved['会計'] == 16 and saved['不一致数'] == 0
    assert saved['資源'] == 16 and saved['前後不変'] is True and saved['入力codeSHA256前'] == saved['入力codeSHA256後']
    assert saved['completionSHA256'] == sha(paths['financial_completion']) == result['completionSHA256']
    assert source['version'] == 1 and source['trial'] == 105 and source['stage'] == 'full4' and source['success'] is True and source['sessions'] == 4
    assert source['source_reformed'] is True and source['financial105_executed'] is False and source['unchanged'] is True
    assert source['before'] == source['after'] and len(source['cases']) == 12 and len(source['legacy_default_matches']) == 4
    assert all(row['old93_full_match'] is False and not row.get('error') for row in source['cases'])
    ids = {'2026-11-05_Day', '2026-11-05_Night', '2026-11-06_Day', '2026-11-06_Night'}
    assert {(row['session'], row['mode']) for row in source['cases']} == {(name, mode) for name in ids for mode in ('legacy', 'default', 'symmetric')}
    assert {row['session'] for row in source['legacy_default_matches']} == ids
    assert all(row['success'] and row['replay_result_bytes_equal'] and row['records_gzip_bytes_equal'] and row['records_jsonl_bytes_equal'] for row in source['legacy_default_matches'])
    assert financial['version'] == 1 and financial['trial'] == 105 and financial['stage'] == 'full4' and financial['success'] is True
    assert financial['sessions'] == 4 and financial['books_per_scene'] == 4 and financial['books'] == 16
    assert financial['old103_market_golden'] is False and financial['legacy_books'] == financial['default_books'] == 0
    assert financial['source_formed_here'] is False
    assert financial['unchanged'] is True and financial['before'] == financial['after'] and len(financial['results']) == 4
    assert {row['session'] for row in financial['results']} == ids
    assert all(row['books'] == 4 and not row.get('error') for row in financial['results'])
    assert sha(paths['source_completion']) in financial['before'].values()
    assert source['condition_sha256'] in financial['before'].values()
    for key in KEYS:
        total = result['集計'][key]
        validate_totals(total, 448)
        daynight = result['実現診断'][key]['日夜']
        assert set(daynight) == {'Day', 'Night'}
        validate_totals(daynight['Day'], 152)
        validate_totals(daynight['Night'], 296)
        assert sum(finite(daynight[k]['net_yen']) for k in daynight) == finite(total['net_yen'])
    return result, before


def amount(value: Any) -> str:
    """
    機能: 未検証と実数値を混同せず円表示する。
    引数: value (Any) は未取得のNone又は元の数値。
    返り値: str は未検証又は半円を保った数値表示。
    """
    if value is None:
        return '未検証'
    number = finite(value)
    return f'{number:,.0f}' if number == number.to_integral_value() else f'{number:,.1f}'


def result_block(result: dict | None) -> str:
    """
    機能: 四感度・二旗・日夜・価格出典の報告欄を作る。
    引数: result (dict | None) は検査済み保存集計又は未取込。
    返り値: str は市場損益を創作しない結果欄。
    """
    status = '未取込・未検証' if result is None else 'full4金融/保存確認を入力指紋へ結合済み'
    lines = [RESULT_BEGIN, '## 固定後4場の報告欄', '', f'状態：{status}。SourceAの生成口QAと、symmetric/B5Q/LD10の実現結果は別段階で記録する。', '',
             '| 評価ID/感度 | 粗額円 | 手数料円 | 仮定滑り円 | 純額円 | 全正額円 | 全負額円 | PF | DD円 | 玉/枚 |',
             '| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |']
    for i, key in enumerate(KEYS):
        total = result['集計'][key] if result else {}
        values = [amount(total.get(field)) for field in ('gross_yen', 'fee_yen', 'slip_yen', 'net_yen', 'positive_yen', 'negative_yen')]
        pf = ('未定義（負額0）' if total and total['PF'] is None else (f'{finite(total["PF"]):.4f}' if total else '未検証'))
        count = f'{total["positions"]}/{total["entry_quantity"]}' if total else '未検証'
        lines.append(f'| R{i+4:02d} {key.rsplit("_",2)[1]}/{key.rsplit("_",2)[2]} | ' + ' | '.join(values + [pf, amount(total.get('保存点連結時価DD')), count]) + ' |')
    lines += ['', '### u正益後赤字とLD10起動後赤字', '',
              '| 感度 | u正益観測玉 | u正益後赤字玉/実損失円 | LD10起動玉 | LD10起動後赤字玉/実損失円 |',
              '| --- | ---: | ---: | ---: | ---: |']
    for key in KEYS:
        t = result['集計'][key] if result else {}
        unit = f'{t["unit_positive_closed_negative"]}/{amount(t["unit_positive_closed_negative_yen"])}' if t else '未検証'
        active = f'{t["activated_closed_negative"]}/{amount(t["activated_closed_negative_yen"])}' if t else '未検証'
        lines.append(f'| {key.rsplit("_",2)[1]}/{key.rsplit("_",2)[2]} | {t.get("unit_positive_positions", "未検証")} | {unit} | {t.get("protection_activated_positions", "未検証")} | {active} |')
    lines += ['', 'uは現在残枚数1枚の費用後含み益。最初のstrict u>0と、LD10閾値 `u>=100*max(10,ATRLock.Value)` の起動は別旗。対応する旗の観測玉数を各赤字の分母とし、LD起動玉数をu正益後赤字へ流用しない。名目建値床は費用後黒字を保証しない。', '',
              '### 日夜の参加', '', '| 感度 | 日中純額円 | 日中参加/152 | 夜間純額円 | 夜間参加/296 | 全体参加/448 | 全体率 | 最低25%/目標50% |',
              '| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |']
    for key in KEYS:
        if result:
            t, dn = result['集計'][key], result['実現診断'][key]['日夜']
            rate = finite(t['活動主表']['参加率'])
            values = [amount(dn['Day']['net_yen']), f'{dn["Day"]["活動主表"]["active"]}（{finite(dn["Day"]["活動主表"]["参加率"]):.2%}）', amount(dn['Night']['net_yen']), f'{dn["Night"]["活動主表"]["active"]}（{finite(dn["Night"]["活動主表"]["参加率"]):.2%}）', str(t['活動主表']['active']), f'{rate:.5%}', ('達成' if rate >= Decimal('.25') else '未達') + '/' + ('達成' if rate >= Decimal('.50') else '未達')]
        else:
            values = ['未検証'] * 7
        lines.append(f'| {key.rsplit("_",2)[1]}/{key.rsplit("_",2)[2]} | ' + ' | '.join(values) + ' |')
    lines += ['', '主448枠は開始30分後からForce未満の全予定5分枠。副432枠は開始/末尾30分除外の観測表。ActualのUS静観も分母へ残し、欠測/判定不能を除外しない。参加は同枠実取得と当時実保有の和集合。受理新規だけを実約定と数えず、全体25%/50%と日夜を別に評価する。', '',
              '### 価格出典・検証範囲', '',
              'ViewerのNK225価格参照は、11/5 DayがJP_OSE_Data共有既存gzip1場、11/5 Night・11/6 Day/Nightが元raw不変からworkへ生成したgzip3場。入力全体（二市場）は共有2/work6。保存器は固定Manifestから絶対pathを参照する。価格の配置とViewer登録/API照合は別で、本helperは通信しない。API成功は未確認のまま、将来の別証拠へ結ぶ。', '',
              '旧93/旧103の市場goldenは新4場に存在しない。legacy/default全Result/全記録の相互同体を、旧市場再現やLD10の成績成功に代用しない。旧104の54場結果も加算しない。', '',
              '新4場・開始日2日の小標本で、4費用遅延感度や複数玉を独立した日数へ水増ししない。C5は起動/返済が変わる動的別運転で、C0純額から固定控除した結果に置換しない。損益の正負に関係なく未知期間の安定性・実mini執行は未証明。機会損失・未参加/退出後の仮想利益・MFE回収率・資本金不明のROIは算出しない。', RESULT_END, '']
    return '\n'.join(lines)


def render(readme: bytes, settings: bytes, result: dict | None) -> tuple[str, str]:
    """
    機能: 原文の55×9/S/Kを保持して結果段落とR欄だけを差し替える。
    引数: readme/settings (bytes)、result (dict | None) は原文と検査済み小集計。
    返り値: tuple[str,str] は新READMEと設定表。
    """
    r, s = readme.decode('utf-8-sig'), settings.decode('utf-8-sig')
    assert STATUS_BEGIN not in r and RESULT_BEGIN not in r and RESULT_BEGIN not in s
    prefix = '\n'.join([STATUS_BEGIN, '**報告下書き：市場実績は未取込・未検証。**' if result is None else '**固定後4場：金融/保存の完了証拠を結合した結果。**',
                        '原計画の同bytesは `原計画/` に保存。以下の原文は準備時の計画であり、進行状態と確定数値は結果欄で区別する。',
                        '米国時計は[時計仕様補足](時計仕様補足.md)を優先し、11/5・6はUS23:30、Actual静観[23:30,翌00:00)、Source P23:15/U23:45。金融式の変更ではない。', STATUS_END, '', ''])
    if result:
        lines = s.splitlines()
        for i, key in enumerate(KEYS):
            rid = f'R{i+4:02d}'
            found = [index for index, line in enumerate(lines) if line.startswith(f'| {rid} |')]
            assert len(found) == 1
            t = result['集計'][key]
            cost, delay = key.rsplit('_', 2)[1][1:], key.rsplit('_', 2)[2][1:]
            lines[found[0]] = f'| {rid} | symmetric | B5Q/LD10 | {cost} | {delay} | {amount(t["net_yen"])}円 | {finite(t["活動主表"]["参加率"]):.5%} | full4金融/保存確認済み |'
        for rid, mode, role in [('R01', 'legacy', '元生成口・全4場、旧93golden対象外'), ('R02', 'default', '新legacyと全Result/記録相互同体QA'), ('R03', 'symmetric', '固定修正Source全4場、LD10会計とは分離')]:
            found = [index for index, line in enumerate(lines) if line.startswith(f'| {rid} |')]
            assert len(found) == 1
            lines[found[0]] = f'| {rid} | {mode} | {role} | 完了証拠を結合済み・Source単独の採用成績とはしない |'
        s = '\n'.join(lines) + '\n'
    catalogue = lambda text: [line for line in text.splitlines() if re.match(r'^\| (?:I|C|P|V|B|X|M|E)\d{2} \|', line)]
    original_settings = settings.decode('utf-8-sig')
    assert catalogue(s) == catalogue(original_settings) and len(catalogue(s)) == 55
    setting_rows = lambda text: [line for line in text.splitlines() if re.match(r'^\| (?:S|K)\d{2} \|', line)]
    assert setting_rows(s) == setting_rows(original_settings) and len(setting_rows(s)) == 18
    assert len(re.findall(r'^\| R\d{2} \|', s, re.M)) == 7
    block = result_block(result)
    readme_body = (block + '\n<details>\n<summary>準備時の計画原文（当時の未実行表記を保持）</summary>\n\n' + r + '\n</details>\n') if result else r + '\n' + block
    return prefix + readme_body, prefix + s + '\n' + block


def main() -> None:
    """
    機能: 未検証の草案又はRoot許可後の新規報告を生成/照合する。
    引数: CLIのout/fixed/fixed-sha/checkは新規先・将来の事後固定・既存出力検査。
    返り値: None。正式trial/原入力を上書きしない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--fixed', type=Path)
    parser.add_argument('--fixed-sha')
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    assert (args.fixed is None) == (args.fixed_sha is None)
    result, before = prepare(args.fixed, args.fixed_sha) if args.fixed else (None, {})
    originals = {name: (WORK / '原文' / name).read_bytes() for name in ('README.md', '設定と結果.md', '時計仕様補足.md')}
    readme, settings = render(originals['README.md'], originals['設定と結果.md'], result)
    output = {'README.md': readme.encode('utf-8'), '設定と結果.md': settings.encode('utf-8'), '時計仕様補足.md': originals['時計仕様補足.md']}
    output.update({'原計画/' + name: body for name, body in originals.items()})
    if args.check:
        assert args.out.is_dir()
        assert all((args.out / name).read_bytes() == body for name, body in output.items())
    else:
        args.out.mkdir(parents=True, exist_ok=False)
        for name, body in output.items():
            path = args.out / name
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open('xb') as stream:
                stream.write(body)
    assert all(sha(Path(path)) == expected for path, expected in before.items())
    print(json.dumps({'成功': True, 'scope': '未検証草案' if result is None else 'full4保存小集計の報告', 'check': args.check,
                      'codeSHA256': sha(Path(__file__)), '入力SHA256': before, '原計画SHA256': {name: hashlib.sha256(body).hexdigest() for name, body in originals.items()},
                      '55x9/18設定/7評価保持': True, '正式編集/Native/Raw/Source/金融/API': 0}, ensure_ascii=False))


if __name__ == '__main__':
    main()
