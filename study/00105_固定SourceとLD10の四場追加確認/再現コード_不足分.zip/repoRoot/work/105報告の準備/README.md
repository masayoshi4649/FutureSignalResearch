# 105報告の準備（実結果未読）

2026-11-09。正式105の準備時README/設定/時計仕様補足を原文として同bytes保存し、報告欄の下書きと小さな差替helperだけを作る。新4場のSource・金融・保存結果は読まない。正式105/104、停止金融・Source・時計の本文は編集しない。

## 原文と出力

[原文の指紋](原文の指紋.json)は準備開始時のライブ3文書を結ぶ。市場前の正式Snapshotを置換するものではない。`原文/`は不変、草案の`原計画/`も同bytesとする。現在の結果値はすべて未検証で、原文の「価格開封前」等は準備時の計画として明示する。

`報告を差し替える.py` は55行×9尺度のカタログとS01〜S10/K01〜K08全18行を保持する。将来の結果取込みではR01〜R03のSource QA状態とR04〜R07の純額/参加率/状態だけを差し替え、評価ID・費用遅延・主448/副432・US時計・LD10閾値を変更しない。原計画は別bytesから復元可能。

```powershell
# 今回許可された未検証草案。実結果への参照を開かない
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/105報告の準備/報告を差し替える.py' --out '<新規草案directory>'
# 同じ原文/同じ入力での全文一致
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/105報告の準備/報告を差し替える.py' --out '<同じ草案directory>' --check
```

草案中の原文リンクは正式105の配置を基準に保持する。別階層の一時草案directoryをそのまま正式に見立てず、原文の参照元pathも保持する。正式反映はRootの後段であり、このhelperは既存出力・正式文書を上書きしない。

## 将来の実結果取込み口（今回は未実行）

Rootの正式実行成功通知後だけ、[事後固定雛形](実結果の固定雛形.json)を新規に固定して使う。`fixed=true/result_ready=true`、小集計/保存確認/Source full4完了/金融 full4完了の4FileRefが必須。FileRefは固定JSONのdirectory基準。

```powershell
# Root許可後のみ。今回この実績取込み口は市場データで実行していない
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/105報告の準備/報告を差し替える.py' `
  --fixed '<Root事後固定.json>' --fixed-sha '<そのSHA256>' --out '<新規実行版directory>'
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/105報告の準備/報告を差し替える.py' `
  --fixed '<同固定.json>' --fixed-sha '<同SHA256>' --out '<同実行版directory>' --check
```

旧市場golden対象外・legacy/default金融0、Source全12case/4相互QA、金融全4場16会計・前後不変、保存16会計差0、使われたSource完了/条件SHAと金融beforeの結合を検査する。金額/正負合計/PF、残予約0、参加448および日中152/夜間296、日夜純額の合計、u旗とLD起動旗の分母を検査する。実Native/Raw/Tapeを展開せず、保存器の小集計とmetadataだけを用いる。保存器schemaは停止b90facc5/集計5192dfd0の公開型に合わせた。

結果欄は全正額・全負額を符号のまま示し、DDやu正益後赤字を純額へ混ぜない。4場/開始日2日の小標本、同じ4感度の重複、SourceA QAとLD10経済成績の違い、C5動的別運転を明記する。機会損失・退出後仮想利益・MFE回収率は扱わない。

Viewer価格のNK225は共有既存gzip1場（11/5 Day）/work生成gzip3場（残り）。二市場全入力は共有2/work6。絶対pathは固定Manifestを使うという配置事実であり、登録/API成功ではない。本helperはAPI0、API照合は別の将来証拠として未確認のまま残す。

## 人工と停止範囲

人工は未検証草案、架空四感度/日夜値、半円表示、全負額、二旗/分母/PF破損拒否、未固定時の実績参照前拒否、原文/設定保持を確認する。人工値を実105の成績へ採用しない。市場実結果取込み・新4場/Raw/Source/金融/Viewerは0。Source/金融の実行状態はRootが管理し、今回の結果未読を未実行の歴史へ遡及変更しない。
