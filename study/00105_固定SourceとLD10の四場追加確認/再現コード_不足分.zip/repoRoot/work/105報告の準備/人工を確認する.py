"""市場結果を読まない報告差替の人工確認。"""
from __future__ import annotations

import copy
import importlib.util
import json
import tempfile
import unittest
from decimal import Decimal
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('report105', ROOT / '報告を差し替える.py')
REPORT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(REPORT)


def total(n: int, denom: int, slip: int, active: int) -> dict:
    """
    機能: 架空の保存集約を算術反証用に作る。
    引数: n/denom/slip/active (int) は架空玉数・分母・追加費用係数・参加枠。
    返り値: dict は自然Source/市場成績を表さない人工値。
    """
    gross, fee, slip_yen = 1000 * n, 77 * n, slip * 200 * n
    net = gross - fee - slip_yen
    positive = 1600 * n
    negative = net - positive
    return {'gross_yen': gross, 'fee_yen': fee, 'slip_yen': slip_yen, 'gross_minus_fee_yen': gross-fee, 'net_yen': net,
            'positive_yen': positive, 'negative_yen': negative, 'positive_positions': n//2, 'negative_positions': n//2, 'zero_positions': 0,
            'positions': n, 'entry_quantity': n, 'close_quantity': n, 'open_buy': 0, 'open_sell': 0, 'pending_buy': 0, 'pending_sell': 0,
            'unit_positive_positions': n, 'unit_positive_closed_negative': n//2, 'unit_positive_closed_negative_yen': negative,
            'protection_activated_positions': n//2, 'activated_closed_negative': 1, 'activated_closed_negative_yen': -77,
            'PF': positive/-negative, '保存点連結時価DD': n*100,
            '活動主表': {'denom': denom, 'new': 0, 'hold': active, 'active': active, 'wait': denom-active, 'unknown': 0, '参加率': active/denom}}


def summary() -> dict:
    """
    機能: full4報告の架空四感度を作る。
    引数: なし。
    返り値: dict は人工だけの結果型。
    """
    result = {'試行': 105, '成功': True, 'stage': 'full4', 'SourceMode': 'symmetric', '場数': 4, '会計数': 16, '診断会計数': 0,
              '前後不変': True, '入力codeSHA256前': {'人工': 'a'}, '入力codeSHA256後': {'人工': 'a'},
              '旧市場golden': {'対象外': True, '対照会計': 0}, 'legacy/default金融会計': 0, '集計': {}, '実現診断': {}}
    for key in REPORT.KEYS:
        slip = int(key[-4])
        result['集計'][key] = total(4, 448, slip, 100)
        result['実現診断'][key] = {'日夜': {'Day': total(2, 152, slip, 40), 'Night': total(2, 296, slip, 60)}}
    return result


def fixed_fixture(directory: Path) -> tuple[Path, dict]:
    """
    機能: 小さな架空metadataの参照だけで将来入口を検査する。
    引数: directory (Path) は一時保存先。
    返り値: tuple[Path,dict] は事後固定JSONと変更前の人工集計。
    """
    def put(name: str, value: dict) -> dict:
        """
        機能: 人工辞書を一時保存しFileRefを返す。
        引数: name (str)、value (dict) は名前と人工値。
        返り値: dict は実SHAを持つ一時参照。
        """
        path = directory / name
        path.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
        return {'path': str(path), 'sha256': REPORT.sha(path)}
    ids = ['2026-11-05_Day','2026-11-05_Night','2026-11-06_Day','2026-11-06_Night']
    source = {'version': 1, 'trial': 105, 'stage': 'full4', 'success': True, 'sessions': 4, 'source_reformed': True,
              'financial105_executed': False, 'unchanged': True, 'before': {'人工': 'a'}, 'after': {'人工': 'a'},
              'condition_sha256': 'c'*64, 'cases': [{'session': name, 'mode': mode, 'old93_full_match': False} for name in ids for mode in ('legacy','default','symmetric')],
              'legacy_default_matches': [{'session': name, 'success': True, 'replay_result_bytes_equal': True, 'records_gzip_bytes_equal': True, 'records_jsonl_bytes_equal': True} for name in ids]}
    source_ref = put('Source人工.json', source)
    financial = {'version': 1, 'trial': 105, 'stage': 'full4', 'success': True, 'sessions': 4, 'books_per_scene': 4, 'books': 16,
                 'old103_market_golden': False, 'legacy_books': 0, 'default_books': 0, 'source_formed_here': False,
                 'unchanged': True, 'before': {'Source': source_ref['sha256'], 'Source条件': source['condition_sha256']},
                 'after': {'Source': source_ref['sha256'], 'Source条件': source['condition_sha256']},
                 'results': [{'session': name, 'books': 4} for name in ids]}
    financial_ref = put('金融人工.json', financial)
    result = summary()
    result['completionSHA256'] = financial_ref['sha256']
    saved = {'成功': True, '会計': 16, '資源': 16, '不一致数': 0, '前後不変': True,
             '入力codeSHA256前': {'人工': 'a'}, '入力codeSHA256後': {'人工': 'a'}, 'completionSHA256': financial_ref['sha256']}
    config = {'version': 1, 'trial': 105, 'fixed': True, 'result_ready': True, 'summary': put('集計人工.json', result),
              'saved_check': put('保存人工.json', saved), 'source_completion': source_ref, 'financial_completion': financial_ref}
    ref = put('事後固定人工.json', config)
    return Path(ref['path']), result


class Tests(unittest.TestCase):
    """公開型と架空保存辞書だけを検査する。"""

    def test_draft(self) -> None:
        """
        機能: 原計画・全設定・未検証表示を保持する。
        引数: self (Tests) は試験器。
        返り値: None。市場結果は渡さない。
        """
        readme = (ROOT/'原文/README.md').read_bytes()
        settings = (ROOT/'原文/設定と結果.md').read_bytes()
        r, s = REPORT.render(readme, settings, None)
        self.assertIn('市場実績は未取込・未検証', r)
        self.assertIn('u正益後赤字', s)
        self.assertIn('共有既存gzip1場', r)
        self.assertIn('全負額円', s)

    def test_artificial_report(self) -> None:
        """
        機能: 四感度の正負/日夜/二旗を架空値で接続する。
        引数: self (Tests) は試験器。
        返り値: None。人工の黒字/赤字を実結果へ採用しない。
        """
        with tempfile.TemporaryDirectory() as tmp:
            path, result = fixed_fixture(Path(tmp))
            data, _ = REPORT.prepare(path, REPORT.sha(path))
            before = copy.deepcopy(data)
            r, s = REPORT.render((ROOT/'原文/README.md').read_bytes(), (ROOT/'原文/設定と結果.md').read_bytes(), data)
            self.assertIn('full4金融/保存確認済み', s)
            self.assertIn('未知期間の安定性', r)
            self.assertEqual(REPORT.amount(Decimal('38.5')), '38.5')
            self.assertEqual(data, before)

    def test_reject_numbers(self) -> None:
        """
        機能: 数値/二旗/分母の破損を検査する。
        引数: self (Tests) は試験器。
        返り値: None。既存数値へ補正しない。
        """
        mutations = [('net_yen', 1), ('negative_yen', 1), ('unit_positive_closed_negative', 99),
                     ('protection_activated_positions', 0), ('PF', 0), ('保存点連結時価DD', -1)]
        for field, value in mutations:
            data = copy.deepcopy(summary()['集計'][REPORT.KEYS[0]])
            data[field] = value
            with self.assertRaises(AssertionError):
                REPORT.validate_totals(data, 448)
        data = summary()['集計'][REPORT.KEYS[0]]
        data['活動主表']['denom'] = 432
        with self.assertRaises(AssertionError):
            REPORT.validate_totals(data, 448)

    def test_unfixed(self) -> None:
        """
        機能: 事後固定が未完なら実績参照を開かず拒否する。
        引数: self (Tests) は試験器。
        返り値: None。存在しない実績で成功しない。
        """
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'未固定.json'
            path.write_text(json.dumps({'version':1,'trial':105,'fixed':False,'result_ready':False}), encoding='utf-8')
            with self.assertRaises(AssertionError):
                REPORT.prepare(path, REPORT.sha(path))


if __name__ == '__main__':
    unittest.main()
