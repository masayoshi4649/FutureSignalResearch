package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	followup "github.com/masayoshi4649/SessionTradeExecuter/fixedfollowup"
)

// sourceMetadata は本文を持たない4場/12caseの手製metadataを作ります。
//
// 引数: なし。
// 返り値: Source105Completionは型/集合guard専用で、実Source成功の証拠ではありません。
func sourceMetadata() Source105Completion {
	f := false
	s := Source105Completion{Version: 1, Trial: 105, Stage: "full4", Success: true, ConditionSHA: strings.Repeat("a", 64), Sessions: 4, Before: map[string]string{"手製metadata": strings.Repeat("b", 64)}, After: map[string]string{"手製metadata": strings.Repeat("b", 64)}, Unchanged: true, SourceFormed: true, Finance: &f, Cases: []SourceCase{}, Mutual: []SourceMutual{}}
	for _, id := range followup.CandidateIDs() {
		refs := map[string]SourceCase{}
		for _, mode := range []string{"legacy", "default", "symmetric"} {
			r := SourceCase{Session: id, Mode: mode, Result: FileRef{id + mode + ".json", strings.Repeat("c", 64)}, Records: FileRef{id + mode + ".jsonl.gz", strings.Repeat("d", 64)}, Counts: Counts{Calls: 2}}
			s.Cases = append(s.Cases, r)
			refs[mode] = r
		}
		s.Mutual = append(s.Mutual, SourceMutual{Session: id, Success: true, Legacy: refs["legacy"].Records, Default: refs["default"].Records, LegacyResult: refs["legacy"].Result, DefaultResult: refs["default"].Result, ResultEqual: true, GzipEqual: true, JSONEqual: true})
	}
	return s
}

// TestSourceMetadata は4場/全mode/相互QAとgolden区分を確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。価格/Source/Native本文を開きません。
func TestSourceMetadata(t *testing.T) {
	base := sourceMetadata()
	if err := validateSource105(base, base.ConditionSHA); err != nil {
		t.Fatal(err)
	}
	mutators := map[string]func(*Source105Completion){
		"旧期間":          func(s *Source105Completion) { s.Cases[0].Session = "2026-09-21_Day" },
		"重複case":       func(s *Source105Completion) { s.Cases[1] = s.Cases[0] },
		"default欠落":    func(s *Source105Completion) { s.Cases = s.Cases[:11] },
		"golden誤true":  func(s *Source105Completion) { s.Cases[0].Match = true },
		"未完":           func(s *Source105Completion) { s.Success = false },
		"旧期全54":        func(s *Source105Completion) { s.Stage = "full54" },
		"金融欄欠落":        func(s *Source105Completion) { s.Finance = nil },
		"金融誤実行":        func(s *Source105Completion) { v := true; s.Finance = &v },
		"mutual重複":     func(s *Source105Completion) { s.Mutual[1] = s.Mutual[0] },
		"mutual結果別ref": func(s *Source105Completion) { s.Mutual[0].LegacyResult.Path = "別の結果" },
		"mutual偽同体":    func(s *Source105Completion) { s.Mutual[0].JSONEqual = false },
		"偽SHA":         func(s *Source105Completion) { s.Cases[0].Records.SHA = "bad" },
	}
	for name, mutate := range mutators {
		t.Run(name, func(t *testing.T) {
			x := sourceMetadata()
			mutate(&x)
			if validateSource105(x, base.ConditionSHA) == nil {
				t.Fatal("不正metadata受理")
			}
		})
	}
}

// TestUnfixedBeforeBody は未固定条件で本文読取や出力へ進まないことを確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。手製metadataだけを使います。
func TestUnfixedBeforeBody(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "条件.json")
	data, _ := json.Marshal(MarketCondition{Version: 1, Trial: 105, Fixed: false})
	if err := os.WriteFile(p, data, 0600); err != nil {
		t.Fatal(err)
	}
	h, _ := fileSHA(p)
	out := filepath.Join(dir, "生成しない")
	_, err := runMarket(MarketArguments{Condition: p, ConditionSHA: h, Stage: "first2", Out: out}, dir, "存在しない実行物")
	if err == nil {
		t.Fatal("未固定条件受理")
	}
	if _, err = os.Stat(out); !os.IsNotExist(err) {
		t.Fatal("未固定で出力を作った")
	}
}

// TestReuseBytes は旧配送/IOの無変更再用を確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。市場/旧Native/テストの再運転はしません。
func TestReuseBytes(t *testing.T) {
	for copy, original := range map[string]string{"replay104.go": "../104LD10の全場比較/replay.go", "io104.go": "../104LD10の全場比較/io.go"} {
		a, err := os.ReadFile(copy)
		if err != nil {
			t.Fatal(err)
		}
		b, err := os.ReadFile(original)
		if err != nil {
			t.Fatal(err)
		}
		if string(a) != string(b) {
			t.Fatal("停止元の本文差", copy)
		}
	}
}

// TestFixtureCLI は実CLI口へ手製bundleを渡し上書き/未知欄を拒否します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。Rootの実条件や新4場本文は使用しません。
func TestFixtureCLI(t *testing.T) {
	dir := t.TempDir()
	f := fixture(t, "2026-11-05_Day")
	data, _ := json.Marshal(f)
	p, out := filepath.Join(dir, "人工.json"), filepath.Join(dir, "人工出力.gz")
	if err := os.WriteFile(p, data, 0600); err != nil {
		t.Fatal(err)
	}
	if err := runFixture(p, out); err != nil {
		t.Fatal(err)
	}
	if err := runFixture(p, out); err == nil {
		t.Fatal("既存出力へ上書き")
	}
	if err := os.WriteFile(p, append(data, []byte(" {}")...), 0600); err != nil {
		t.Fatal(err)
	}
	if err := runFixture(p, filepath.Join(dir, "不正.gz")); err == nil {
		t.Fatal("末尾余剰受理")
	}
}

// TestPrepareMetadataPositive は正しいmetadataの全preflight経路を通します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。実価格の代わりに一時ダミーファイルをhashするだけで、LoadRequestは呼びません。
func TestPrepareMetadataPositive(t *testing.T) {
	dir := t.TempDir()
	root, err := filepath.Abs("../..")
	if err != nil {
		t.Fatal(err)
	}
	put := func(name string, value any) FileRef {
		p := filepath.Join(dir, name)
		if err := writeNew(p, value, false); err != nil {
			t.Fatal(err)
		}
		h, e := fileSHA(p)
		if e != nil {
			t.Fatal(e)
		}
		return FileRef{p, h}
	}
	code := map[string]string{}
	stops := []FileRef{{filepath.Join(root, "work/固定後4場の接続準備/停止.json"), ClockStopSHA}, {filepath.Join(root, "work/104新Sourceと判断時計の結合案/停止.json"), BindStopSHA}, {filepath.Join(root, "work/105四場Sourceの再形成/停止.json"), Source105StopSHA}}
	for _, ref := range stops {
		var v map[string]json.RawMessage
		if err := decode(ref.Path, &v, false, false); err != nil {
			t.Fatal(err)
		}
		var owned map[string]string
		for _, key := range []string{"所有コードSHA256", "所有SHA256"} {
			if raw, ok := v[key]; ok {
				if err := json.Unmarshal(raw, &owned); err != nil {
					t.Fatal(err)
				}
				break
			}
		}
		if len(owned) == 0 {
			t.Fatal("人工に必要な停止所有metadataが空")
		}
		for p, h := range owned {
			code[p] = h
		}
	}
	for _, name := range []string{"main.go", "market.go", "clock_tape.go", "replay104.go", "io104.go", "go.mod", "go.sum"} {
		p, _ := filepath.Abs(name)
		h, e := fileSHA(p)
		if e != nil {
			t.Fatal(e)
		}
		code[p] = h
	}
	pure := put("手製純戦略.json", map[string]string{"scope": "metadata人工だけ"})
	m := continuous.InputManifest{Root: dir, StrategyRoot: dir, StrategySHA256: map[string]string{filepath.Base(pure.Path): pure.SHA}, Sessions: []continuous.InputSession{}}
	for _, id := range followup.CandidateIDs() {
		row := continuous.InputSession{ID: id, Contract: "手製限月", Files: map[string]continuous.InputFile{}}
		for _, name := range []string{"NK225_book", "TOPIX_book", "NK225_candle_60", "NK225_candle_300", "TOPIX_candle_60", "TOPIX_candle_300"} {
			ref := put(id+name+".dummy", map[string]string{"scope": "市場非読取のmetadataダミー"})
			info, _ := os.Stat(ref.Path)
			row.Files[name] = continuous.InputFile{Path: ref.Path, SHA256: ref.SHA, Size: info.Size()}
		}
		m.Sessions = append(m.Sessions, row)
	}
	manifest := put("入力台帳.json", m)
	sc := put("Source条件.json", struct {
		Version  int               `json:"version"`
		Trial    int               `json:"trial"`
		Fixed    bool              `json:"fixed"`
		Manifest FileRef           `json:"input_manifest"`
		Code     map[string]string `json:"code_sha256"`
	}{1, 105, true, manifest, code})
	src := sourceMetadata()
	src.ConditionSHA = sc.SHA
	for i := range src.Cases {
		src.Cases[i].Result = put("結果"+src.Cases[i].Session+src.Cases[i].Mode+".json", map[string]string{"scope": "Source本文を開かない型人工"})
		src.Cases[i].Records = put("記録"+src.Cases[i].Session+src.Cases[i].Mode+".dummy", map[string]string{"scope": "JSONLには配送しない"})
	}
	for i, id := range followup.CandidateIDs() {
		l, d := src.Cases[i*3], src.Cases[i*3+1]
		src.Mutual[i] = SourceMutual{Session: id, Success: true, Legacy: l.Records, Default: d.Records, LegacyResult: l.Result, DefaultResult: d.Result, ResultEqual: true, GzipEqual: true, JSONEqual: true}
	}
	sourceFull := put("Source全4.json", src)
	binary := put("人工binary.dummy", map[string]string{"scope": "metadataのみ・起動しない"})
	c := MarketCondition{Version: 1, Trial: 105, Fixed: true, Manifest: manifest, SourceCondition: sc, SourceFull: sourceFull, SourceStop: stops[2], ClockStop: stops[0], BinderStop: stops[1], Binary: binary, Code: code}
	cond := put("金融条件.json", c)
	a := MarketArguments{Condition: cond.Path, ConditionSHA: cond.SHA, Stage: "first2", Out: filepath.Join(dir, "生成しない")}
	_, got, _, before, e := prepareMarket(a, root, binary.Path)
	if e != nil || len(got.Sessions) != 2 || len(before) == 0 {
		t.Fatal("正のmetadata接続失敗", e)
	}
	if _, e = os.Stat(a.Out); !os.IsNotExist(e) {
		t.Fatal("preflightが出力を作った")
	}
}
