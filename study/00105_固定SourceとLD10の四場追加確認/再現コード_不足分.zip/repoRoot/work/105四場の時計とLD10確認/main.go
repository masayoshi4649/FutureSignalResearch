package main

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	finance "github.com/masayoshi4649/SessionTradeExecuter/minidelayed103"
	binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
)

// Fixture は新公開型だけの人工接続口です。実市場条件を代用しません。
type Fixture struct {
	Artificial bool                             `json:"artificial"`
	Scope      string                           `json:"scope"`
	Request    continuous.Request               `json:"request"`
	Records    map[string][]binder.SourceRecord `json:"records"`
}

// Native は105の新しい外側と旧LD10四の金融全値を分けます。
type Native struct {
	Version            int                             `json:"version"`
	Trial              int                             `json:"trial"`
	Scope              string                          `json:"scope"`
	Session            finance.Session                 `json:"session"`
	Books              map[string]finance.ActualResult `json:"books"`
	SourceMode         string                          `json:"source_mode"`
	Bindings           map[string]binder.Proof         `json:"bindings"`
	Clock              ClockProof                      `json:"clock_proof"`
	Complete           bool                            `json:"complete"`
	Old103MarketGolden bool                            `json:"old103_market_golden"`
	GoldenScope        string                          `json:"golden_scope"`
	LegacyBooks        int                             `json:"legacy_books"`
	DefaultBooks       int                             `json:"default_books"`
	SourceFormedHere   bool                            `json:"source_formed_here"`
	GateExecuted       bool                            `json:"gate_executed"`
}

// RunFresh は新6入力由来の公開Requestと新Source通知をsym四会計へ接続します。
//
// 引数: req(continuous.Request)、records(map[string][]binder.SourceRecord)、scope(string)は固定後又は人工の明示入力です。
// 返り値: Native/FreshInput/errorは全四冊と接続証拠、又は不整合です。
func RunFresh(req continuous.Request, records map[string][]binder.SourceRecord, scope string) (Native, FreshInput, error) {
	out := Native{Version: 1, Trial: 105, Session: req.Session, SourceMode: "symmetric", Scope: scope, GoldenScope: "旧103市場goldenなし・対象外。人工/新接続成功を旧市場再現と呼ばない"}
	if scope == "" {
		return out, FreshInput{}, fmt.Errorf("明示scope必須")
	}
	input, err := BuildFromRequest(req, records)
	if err != nil {
		return out, input, err
	}
	result, err := RunModeObserved(input.Tapes["symmetric"], "symmetric", nil)
	if err != nil {
		return out, input, err
	}
	out.Books, out.Bindings, out.Clock, out.Complete = result.Books, input.Bindings, input.Clock, result.Complete
	return out, input, nil
}

// decodeStrict は公開人工bundleの未知fieldと末尾データを拒否します。
//
// 引数: r(io.Reader)、target(any)は明示入力と受け皿です。
// 返り値: errorはJSON型/未知field/余剰データです。
func decodeStrict(r io.Reader, target any) error {
	d := json.NewDecoder(r)
	d.DisallowUnknownFields()
	if err := d.Decode(target); err != nil {
		return err
	}
	var extra any
	if err := d.Decode(&extra); err != io.EOF {
		return fmt.Errorf("JSON末尾はEOF必須")
	}
	return nil
}

// saveGzip は新規pathへ公開全値を圧縮保存します。
//
// 引数: path(string)、value(any)は新規保存先と保存値です。
// 返り値: errorは既存/JSON/close失敗です。上書きしません。
func saveGzip(path string, value any) error {
	f, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return err
	}
	g := gzip.NewWriter(f)
	err = json.NewEncoder(g).Encode(value)
	if closeErr := g.Close(); err == nil {
		err = closeErr
	}
	if closeErr := f.Close(); err == nil {
		err = closeErr
	}
	return err
}

// runFixture は市場FileRefを持たない人工bundleだけを確認します。
//
// 引数: path/out(string)は人工入力と存在しない圧縮出力です。
// 返り値: errorは型/接続/会計/IO不正です。市場CLIではありません。
func runFixture(path, out string) error {
	data, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	var fixture Fixture
	if err = decodeStrict(bytes.NewReader(data), &fixture); err != nil {
		return err
	}
	if !fixture.Artificial || fixture.Scope == "" {
		return fmt.Errorf("人工宣言必須。Root固定市場条件はこの口で受理しない")
	}
	value, input, err := RunFresh(fixture.Request, fixture.Records, fixture.Scope)
	if err != nil {
		return err
	}
	before := sha256.Sum256(data)
	after, err := os.ReadFile(path)
	if err != nil || before != sha256.Sum256(after) {
		return fmt.Errorf("人工入力の前後差")
	}
	return saveGzip(out, struct {
		Native Native     `json:"output"`
		Input  FreshInput `json:"fresh_input"`
		SHA    string     `json:"fixture_sha256"`
	}{value, input, hex.EncodeToString(before[:])})
}

// main は人工のみの小CLIを起動します。
//
// 引数: os.Args([]string)のfixture/outは明示する人工入力と新規出力です。
// 返り値: なし。市場口はRoot固定条件/Source全4成功が無ければ入力本文より前に拒否します。
func main() {
	fixture := flag.String("fixture", "", "手製Request/全3mode記録のJSON")
	condition := flag.String("condition", "", "Root固定の市場条件JSON")
	conditionSHA := flag.String("condition-sha", "", "市場条件の実SHA256")
	stage := flag.String("stage", "", "first2/full4")
	first2 := flag.String("first2", "", "同条件先頭2完了JSON")
	first2SHA := flag.String("first2-sha", "", "同先頭2完了の実SHA256")
	out := flag.String("out", "", "存在しない圧縮出力path又は市場出力directory")
	flag.Parse()
	if *out == "" || (*fixture == "") == (*condition == "") {
		fmt.Fprintln(os.Stderr, "--out と fixture/condition の一方が必要")
		os.Exit(1)
	}
	var err error
	if *fixture != "" {
		err = runFixture(*fixture, *out)
	} else {
		_, file, _, ok := runtime.Caller(0)
		if !ok {
			err = fmt.Errorf("repo実path不明")
		} else {
			root := filepath.Dir(filepath.Dir(filepath.Dir(file)))
			exe, e := os.Executable()
			err = e
			if err == nil {
				_, err = runMarket(MarketArguments{*condition, *conditionSHA, *stage, *out, *first2, *first2SHA}, root, exe)
			}
		}
	}
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
