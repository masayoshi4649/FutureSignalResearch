package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"sort"
	"strings"
	"testing"
	"time"

	warm "github.com/masayoshi4649/SessionTradeExecuter/chartwarmup96"
	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	followup "github.com/masayoshi4649/SessionTradeExecuter/fixedfollowup"
	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
)

// fixture は新候補日付を使う手製公開型と空Source通知を作ります。
//
// 引数: t(*testing.T)、id(string)は試験器と候補IDです。
// 返り値: Fixtureは人工だけで、自然Source/CSV形成の成功ではありません。
func fixture(t *testing.T, id string) Fixture {
	t.Helper()
	carrier, err := followup.ClockCarrier(id)
	if err != nil {
		t.Fatal(err)
	}
	s := carrier.Session
	req := continuous.Request{Session: s, Scene: warm.Scene{ID: s.ID, Contract: "手製限月", Start: s.Start}, Rows: []continuous.Row{}, Candles: []continuous.CandleEvent{}, Grids: []float64{}}
	for _, g := range carrier.Events {
		req.Grids = append(req.Grids, g.At)
	}
	for i, at := range []float64{s.Start + 10, s.Start + 300, s.Start + 301, s.ForceClose + 1} {
		last := 40000.0
		if i == 1 {
			last = 0
		}
		req.Rows = append(req.Rows, continuous.Row{Board: strategy.Board{Reference: "NK225", Time: at, Received: at, Last: last, Bid: 39990, Ask: 40010, BidQuantity: 10, AskQuantity: 10}, PhysicalLine: int64(10 + i)})
	}
	for i, at := range []float64{s.Start + 300, s.ForceClose} {
		req.Rows = append(req.Rows, continuous.Row{Board: strategy.Board{Reference: "TOPIX", Time: at, Received: at, Last: 2800, Bid: 2799.5, Ask: 2800.5, BidQuantity: 10, AskQuantity: 10}, PhysicalLine: int64(20 + i)})
	}
	frames := []ClockFrame{}
	_, _, err = continuous.BuildToSink(req, nil, func(r continuous.Record) error {
		if r.Row != nil {
			q := r.Row.Scalar
			frames = append(frames, ClockFrame{len(frames) + 1, "quote", q.Time, &q})
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	events := []tape.TapeEvent{}
	for _, f := range frames {
		events = append(events, tape.TapeEvent{Kind: "quote", At: f.At, Quote: f.Scalar})
	}
	events = append(events, tape.TapeEvent{Kind: "force", At: s.ForceClose})
	if s.Kind == "Night" {
		events = append(events, tape.TapeEvent{Kind: "force", At: s.USOpen - 900})
	}
	sort.SliceStable(events, func(i, j int) bool {
		return events[i].At < events[j].At || events[i].At == events[j].At && events[i].Kind == "force"
	})
	records := []binder.SourceRecord{}
	last := map[string]int64{}
	for _, event := range events {
		for _, method := range methodsAt(s, event.At) {
			for _, product := range []string{"NK225micro", "NK225mini"} {
				origin, key := "timer", method+"/"+product
				var q *tape.ScalarQuote
				obs := ""
				if event.Kind == "quote" {
					origin = "quote"
					copy := *event.Quote
					q = &copy
					obs = strings.Repeat("a", 64)
					last[key] = q.SourceLine
				}
				delta := native.StepResult{At: event.At, Origin: origin, SourceLine: last[key], Signals: []native.SignalRecord{}, Fills: []native.FillRecord{}, Closes: []native.CloseNotice{}, Cancellations: []native.Cancellation{}}
				records = append(records, binder.SourceRecord{Ordinal: len(records) + 1, Session: s.ID, Kind: event.Kind, Method: method, Product: product, Scalar: q, ObservationSHA: obs, Delta: delta})
			}
		}
	}
	modeRecords := map[string][]binder.SourceRecord{}
	for _, mode := range []string{"legacy", "default", "symmetric"} {
		data, _ := json.Marshal(records)
		var cloned []binder.SourceRecord
		if err = json.Unmarshal(data, &cloned); err != nil {
			t.Fatal(err)
		}
		modeRecords[mode] = cloned
	}
	return Fixture{true, "手製板/空Source公開通知の新clock型人工。自然Source・新市場金融成功ではない", req, modeRecords}
}

// TestFreshClockEmptyBooks は四場の手製全board時計と終了四冊を確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。空型接続を非0自然Sourceの実証に拡張しません。
func TestFreshClockEmptyBooks(t *testing.T) {
	for _, id := range followup.CandidateIDs() {
		f := fixture(t, id)
		before, _ := json.Marshal(f)
		out, input, err := RunFresh(f.Request, f.Records, f.Scope)
		if err != nil || len(out.Books) != 4 || !out.Complete || out.Old103MarketGolden || out.LegacyBooks != 0 || out.DefaultBooks != 0 {
			t.Fatal(id, err)
		}
		if input.Clock.Rows != 3 || !input.Bindings["legacy"].NotificationsEqualOld || !input.Bindings["default"].NotificationsEqualOld {
			t.Fatal("空通知/Last0列")
		}
		for _, book := range out.Books {
			if !book.Complete || len(book.Positions) != 0 || book.Totals.NetYen != 0 {
				t.Fatal("空book完結")
			}
		}
		after, _ := json.Marshal(f)
		if string(before) != string(after) {
			t.Fatal("共用人工入力の変更")
		}
		if dir := os.Getenv("FRESH105_EXPORT"); dir != "" {
			data, _ := json.MarshalIndent(f, "", "  ")
			if err = os.WriteFile(filepath.Join(dir, id+".json"), data, 0600); err != nil {
				t.Fatal(err)
			}
			data, _ = json.MarshalIndent(out, "", "  ")
			if err = os.WriteFile(filepath.Join(dir, id+".Native.json"), data, 0600); err != nil {
				t.Fatal(err)
			}
		}
	}
}

// TestNovemberDSTClock は11月の新しいUS時計と旧Actorのquiet実式を確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。公開暦/手製板だけで、対象日の価格本文は読みません。
func TestNovemberDSTClock(t *testing.T) {
	zone, err := time.LoadLocation("Asia/Tokyo")
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []string{"2026-11-05_Night", "2026-11-06_Night"} {
		f := fixture(t, id)
		s := f.Request.Session
		if time.Unix(int64(s.USOpen), 0).In(zone).Format("15:04") != "23:30" {
			t.Fatal("新11月US時計のDST差")
		}
		out, _, err := RunFresh(f.Request, f.Records, f.Scope)
		if err != nil {
			t.Fatal(err)
		}
		for _, book := range out.Books {
			if book.Config.USOpen != s.USOpen {
				t.Fatal("旧9月時計混入")
			}
			quiet := 0
			for _, g := range book.GridTraces {
				expected := g.At >= s.USOpen && g.At < s.USOpen+1800
				if g.USQuiet == nil || *g.USQuiet != expected {
					t.Fatal("旧ActorのUSquiet実式差")
				}
				if expected {
					quiet++
				}
			}
			if quiet != 6 {
				t.Fatal("USquiet全6枠不足")
			}
		}
		t.Logf("%s USOpen=%s SourceP締切=%s U生成=%s Actorquiet=[%s,%s)", id, time.Unix(int64(s.USOpen), 0).In(zone).Format(time.RFC3339), time.Unix(int64(s.USOpen-900), 0).In(zone).Format(time.RFC3339), time.Unix(int64(s.USOpen+900), 0).In(zone).Format(time.RFC3339), time.Unix(int64(s.USOpen), 0).In(zone).Format(time.RFC3339), time.Unix(int64(s.USOpen+1800), 0).In(zone).Format(time.RFC3339))
	}
}

// TestFreshClockGuards は全商品/位相/Scalar/余剰を補完せず拒否します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。元Sourceの数量や向きを直して成功させません。
func TestFreshClockGuards(t *testing.T) {
	mutations := map[string]func(*Fixture){
		"mode不足":        func(f *Fixture) { delete(f.Records, "default") },
		"scalar差":       func(f *Fixture) { f.Records["legacy"][0].Scalar.Bid++ },
		"商品順差":          func(f *Fixture) { f.Records["legacy"][0].Product = "NK225mini" },
		"物理行差":          func(f *Fixture) { f.Records["legacy"][0].Delta.SourceLine++ },
		"Observation欠落": func(f *Fixture) { f.Records["legacy"][0].ObservationSHA = "" },
		"手法差":           func(f *Fixture) { f.Records["legacy"][0].Method = "U165_03" },
		"余剰":            func(f *Fixture) { f.Records["legacy"] = append(f.Records["legacy"], f.Records["legacy"][0]) },
		"Force不足": func(f *Fixture) {
			x := f.Records["legacy"]
			f.Records["legacy"] = x[:len(x)-2]
			f.Records["default"] = f.Records["legacy"]
		},
	}
	for name, mutate := range mutations {
		t.Run(name, func(t *testing.T) {
			f := fixture(t, "2026-11-05_Day")
			mutate(&f)
			if _, err := BuildFromRequest(f.Request, f.Records); err == nil {
				t.Fatal("破損受理")
			}
		})
	}
}

// TestClosesOnlyAndForcePhase はClosesだけの公開通知を落とさず保持します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。存在しない玉の返済を金融成功としては配送しません。
func TestClosesOnlyAndForcePhase(t *testing.T) {
	f := fixture(t, "2026-11-05_Day")
	input, err := BuildFromRequest(f.Request, f.Records)
	if err != nil {
		t.Fatal(err)
	}
	records := f.Records["legacy"]
	records[1].Delta.Closes = []native.CloseNotice{{ID: "型Close", ReferenceID: "型Hold", Before: 3, Quantity: 1, Reason: "保持する型値"}}
	baseline, _, err := BuildLegacyTape(f.Request.Session, input.Frames, records)
	if err != nil || len(baseline.Events) == 0 {
		t.Fatal(err)
	}
	_, proof, err := binder.Bind(baseline, records, "legacy")
	if err != nil || !proof.NotificationsEqualOld {
		t.Fatal("Closes-only往復", err)
	}
	// ----------------------------------------
	// 新基準を作る前の同秒raw→grid逆転もsortで隠さず拒否する。
	frames := append([]ClockFrame{}, input.Frames...)
	for i := 1; i < len(frames); i++ {
		if frames[i].Kind == "quote" {
			frames[i-1] = ClockFrame{i, "quote", frames[i].At, frames[i].Scalar}
			frames[i] = ClockFrame{i + 1, "grid", frames[i].At, nil}
			break
		}
	}
	if _, _, err = BuildLegacyTape(f.Request.Session, frames, records); err == nil {
		t.Fatal("同秒位相逆転受理")
	}
	if reflect.DeepEqual(input.Legacy, baseline) {
		t.Fatal("Closes追加を保存しない")
	}
}

// TestSourceEventsDirectGuards は相互QAより内側の出典拒否を確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。前段のlegacy/default差だけで拒否を代用しません。
func TestSourceEventsDirectGuards(t *testing.T) {
	mutations := map[string]func([]binder.SourceRecord) []binder.SourceRecord{
		"ordinal":     func(r []binder.SourceRecord) []binder.SourceRecord { r[0].Ordinal++; return r },
		"商品":          func(r []binder.SourceRecord) []binder.SourceRecord { r[0].Product = "NK225mini"; return r },
		"手法":          func(r []binder.SourceRecord) []binder.SourceRecord { r[0].Method = "U165_03"; return r },
		"quote原行":     func(r []binder.SourceRecord) []binder.SourceRecord { r[0].Delta.SourceLine++; return r },
		"Observation": func(r []binder.SourceRecord) []binder.SourceRecord { r[0].ObservationSHA = ""; return r },
		"Scalar":      func(r []binder.SourceRecord) []binder.SourceRecord { r[1].Scalar.Ask++; return r },
		"force原行": func(r []binder.SourceRecord) []binder.SourceRecord {
			for i := range r {
				if r[i].Kind == "force" {
					r[i].Delta.SourceLine++
					break
				}
			}
			return r
		},
		"force欠落": func(r []binder.SourceRecord) []binder.SourceRecord {
			out := []binder.SourceRecord{}
			for _, x := range r {
				if x.Kind != "force" {
					x.Ordinal = len(out) + 1
					out = append(out, x)
				}
			}
			return out
		},
	}
	for name, mutate := range mutations {
		t.Run(name, func(t *testing.T) {
			f := fixture(t, "2026-11-05_Day")
			if _, err := sourceEvents(f.Request.Session, mutate(f.Records["legacy"])); err == nil {
				t.Fatal("内側の出典破損受理")
			}
		})
	}
}
