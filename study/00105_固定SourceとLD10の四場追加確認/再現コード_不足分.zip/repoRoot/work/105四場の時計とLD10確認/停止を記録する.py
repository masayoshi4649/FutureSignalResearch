"""新四場clock/LD10接続の非市場停止を指紋と人工証拠へ結ぶ。"""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 実ファイルのSHA256を得る。
    引数: path (Path) は明示したコード又は人工metadata。
    返り値: str は小文字64桁の指紋。
    """
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path: Path) -> dict:
    """
    機能: 小さい公開metadata/人工を読む。
    引数: path (Path) は停止/検査又は人工JSON。
    返り値: dict は保存辞書。
    """
    return json.loads(path.read_text(encoding='utf-8-sig'))


def main() -> None:
    """
    機能: 元停止の不変と新部品の人工成功を確認して停止JSONを作る。
    引数: なし。新4場の実入力や実Sourceは使用しない。
    返り値: None。停止.jsonは新規のみで既存上書きを拒否する。
    """
    before = load(WORK / '検査/依存の前指紋.json')
    assert all(sha(Path(name)) == expected for name, expected in before.items())
    assert sha(ROOT / 'study/00104_重複時の方向裁定と元Sourceの再形成/完了記録.json') == '4d83ff059efef76a187d14a09f8832740be48488c2014aafa0dfbcc38765659c'
    result = load(WORK / '検査/終了.json')
    assert result == {'test': 0, 'vet': 0, 'build': 0}
    cli = load(WORK / '検査/CLI終了.json')
    assert cli == {'人工': 0, '未固定拒否': 1, '出力不存在': True}
    log = (WORK / '検査/test.txt').read_text(encoding='utf-8-sig')
    tests = re.findall(r'^--- PASS: ([^ ]+)', log, re.M)
    assert len(tests) == 10
    assert (WORK / 'replay104.go').read_bytes() == (ROOT / 'work/104LD10の全場比較/replay.go').read_bytes()
    assert (WORK / 'io104.go').read_bytes() == (ROOT / 'work/104LD10の全場比較/io.go').read_bytes()
    native = list((WORK / '人工').glob('*.Native.json'))
    assert len(native) == 4
    for path in native:
        value = load(path)
        assert value['complete'] and len(value['books']) == 4 and not value['old103_market_golden']
        assert value['source_mode'] == 'symmetric' and value['legacy_books'] == value['default_books'] == 0
        for book in value['books'].values():
            assert book['finished'] and book['complete'] and book['totals']['net_yen'] == 0
    owned = list(WORK.glob('*.go')) + [WORK / name for name in ['go.mod', 'go.sum', 'README.md', '条件の雛形.json', '停止を記録する.py']]
    artifacts = [p for folder in ['人工', '検査'] for p in (WORK / folder).rglob('*') if p.is_file() and p.suffix != '.exe']
    proof = {'成功': True, 'scope': '105新clock/全商品Source記録結合/3Bind/symLD10四のコードと手製空人工。新4場市場成功ではない',
             'module': 'github.com/masayoshi4649/SessionTradeExecuter/freshld105',
             '所有コードSHA256': {p.relative_to(ROOT).as_posix(): sha(p) for p in owned},
             '実行物': (WORK / '検査/時計とLD10.exe').relative_to(ROOT).as_posix(),
             '実行物SHA256': sha(WORK / '検査/時計とLD10.exe'),
             '元停止/直接依存前後SHA256': before, '依存前後不変': True, '直接依存件数': len(before),
             '再用': {'replay104全bytes同体': True, 'replay104元SHA256': sha(ROOT / 'work/104LD10の全場比較/replay.go'),
                       'io104全bytes同体': True, '時計停止': 'd20b2027067c26022f9dd50e29f720b24915fd1ea2613070c0f6fee275ee22e6',
                       'Bind停止': 'e66adae009ff3edfa59b38dd22ffa07c48f83843f045080a4ede0045dab0fbf2',
                       '105Source停止': 'f52676b0cc55fe2fbdbb0f6524161950af4babbb5891513723a01b5f2618c28a'},
             'Go検査': {'test': 0, 'vet': 0, 'build': 0, 'top': len(tests), '各top': tests},
             '人工': {'手製全4場Native': 4, '空会計': 16, '非0自然Source/金融': 0,
                       'Closes-only保持': True, 'Scalar/全商品順等拒否': 16, 'Source全4metadata拒否': 12,
                       '正metadata全preflight': True, 'CLI': cli,
                       'DST': {'USOpen_JST': '23:30', 'SourceP締切': '23:15', 'SourceU生成': '23:45',
                               'Actual_USquiet': '[23:30,翌00:00)', '全4感度quiet6枠': True}},
             '人工/検査SHA256': {p.relative_to(ROOT).as_posix(): sha(p) for p in artifacts},
             '旧103市場golden': False, '旧goldenの扱い': '新4場は存在せず対象外。Source相互同体や型接続で代用しない',
             '未実施': ['新4場の実価格/Raw/CSV/Source本文読取', '新4場の実市場金融', '非0自然通知からの新legacyTape接続', '独立全原行金融再計算'],
             '実市場/Raw/CSV/新4本文/Source再実行': 0, '旧104正式/停止元編集': 0, '機会損失/退出後仮想利益': 0}
    path = WORK / '停止.json'
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'停止SHA256': sha(path), '実行物SHA256': proof['実行物SHA256'], '所有': len(owned), '依存': len(before)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
