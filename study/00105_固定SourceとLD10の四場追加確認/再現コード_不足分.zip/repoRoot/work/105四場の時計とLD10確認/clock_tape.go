package main

import (
	"bytes"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"reflect"
	"sort"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	followup "github.com/masayoshi4649/SessionTradeExecuter/fixedfollowup"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	actual "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
)

// ClockFrame は新producerが実観測した正NK原行または全board由来gridです。
type ClockFrame struct {
	Ordinal int               `json:"ordinal"`
	Kind    string            `json:"kind"`
	At      float64           `json:"at"`
	Scalar  *tape.ScalarQuote `json:"scalar,omitempty"`
}

// ClockProof は新時計の接続と旧市場golden不在を区別します。
type ClockProof struct {
	Rows               int    `json:"positive_nk_rows"`
	Grids              int    `json:"all_board_grids"`
	Forces             int    `json:"source_forces"`
	Calls              int    `json:"source_calls"`
	Old54TapeUsed      bool   `json:"old54_tape_used"`
	Old103MarketGolden bool   `json:"old103_market_golden"`
	GoldenScope        string `json:"golden_scope"`
}

// FreshInput は新入力の基準Tapeと3modeの厳密結合だけを保持します。
type FreshInput struct {
	Session  actual.Session          `json:"session"`
	Frames   []ClockFrame            `json:"frames"`
	Legacy   tape.Tape               `json:"legacy_tape"`
	Bindings map[string]binder.Proof `json:"bindings"`
	Tapes    map[string]tape.Tape    `json:"tapes"`
	Clock    ClockProof              `json:"clock_proof"`
}

// methodsAt は元SourceのP継続/U追加と全手法Force順を固定暦へ結びます。
//
// 引数: s(actual.Session)、at(float64)は当場時計と通知時計です。
// 返り値: []stringは元のactive手法順です。生成済みSourceの方向や数量を計算しません。
func methodsAt(s actual.Session, at float64) []string {
	if s.Kind == "Day" {
		return []string{"D164_15"}
	}
	if at < s.USOpen+900 {
		return []string{"P164_06"}
	}
	return []string{"P164_06", "U165_03"}
}

// sourceEvents は全商品記録を消費し、miniの公開全Deltaを値copyします。
//
// 引数: s(actual.Session)、records([]binder.SourceRecord)は新場とlegacy全通知です。
// 返り値: []tape.TapeEvent/errorはSourceの元quote/Force順又は不足/出典差です。
func sourceEvents(s actual.Session, records []binder.SourceRecord) ([]tape.TapeEvent, error) {
	events := []tape.TapeEvent{}
	last := map[string]int64{}
	forceSeen := map[float64]bool{}
	forceTimes := map[float64]bool{s.ForceClose: true}
	if s.Kind == "Night" {
		forceTimes[s.USOpen-900] = true
	}
	previous := 0.0
	for cursor := 0; cursor < len(records); {
		first := records[cursor]
		at, kind := first.Delta.At, first.Kind
		if at < previous || (kind != "quote" && kind != "force") {
			return nil, fmt.Errorf("Source通知時計/種別不正 record%d", cursor+1)
		}
		previous = at
		if kind == "force" {
			if !forceTimes[at] || forceSeen[at] {
				return nil, fmt.Errorf("Force予定外/重複")
			}
			forceSeen[at] = true
		} else if first.Scalar == nil || first.Scalar.Time != at || at < s.Start || at >= s.End {
			return nil, fmt.Errorf("新Scalar時計欠落")
		}
		methods := methodsAt(s, at)
		event := tape.TapeEvent{Kind: kind, At: at, Methods: methods, NonEmpty: []actual.NativeBatch{}}
		if kind == "quote" {
			q := *first.Scalar
			event.Quote = &q
		}
		all := []actual.NativeBatch{}
		for _, method := range methods {
			for _, product := range []string{"NK225micro", "NK225mini"} {
				if cursor >= len(records) {
					return nil, fmt.Errorf("Source全商品記録不足")
				}
				r := records[cursor]
				cursor++
				if r.Ordinal != cursor || r.Session != s.ID || r.Kind != kind || r.Method != method || r.Product != product || r.Delta.At != at || r.Error != "" {
					return nil, fmt.Errorf("Source全記録順/手法/商品不正 record%d", cursor)
				}
				key := method + "/" + product
				origin := "timer"
				if kind == "quote" {
					origin = "quote"
					h, err := hex.DecodeString(r.ObservationSHA)
					if err != nil || len(h) != 32 || r.ObservationSHA != first.ObservationSHA || r.Scalar == nil || !reflect.DeepEqual(r.Scalar, event.Quote) {
						return nil, fmt.Errorf("Scalar11/完全Observation出典差 record%d", cursor)
					}
					last[key] = r.Scalar.SourceLine
				} else if r.Scalar != nil || r.ObservationSHA != "" {
					return nil, fmt.Errorf("Forceへ価格/Observation混入")
				}
				if r.Delta.Origin != origin || r.Delta.SourceLine != last[key] {
					return nil, fmt.Errorf("Source位相/直前物理行差 record%d", cursor)
				}
				if product == "NK225mini" {
					data, err := json.Marshal(r.Delta)
					if err != nil {
						return nil, err
					}
					var batch actual.NativeBatch
					batch.Method = method
					if err = json.Unmarshal(data, &batch.Delta); err != nil {
						return nil, err
					}
					all = append(all, batch)
					if len(batch.Delta.Signals)+len(batch.Delta.Fills)+len(batch.Delta.Cancellations)+len(batch.Delta.Closes) > 0 {
						event.NonEmpty = append(event.NonEmpty, batch)
					}
				}
			}
		}
		lines := map[string]int64{}
		for _, method := range methods {
			lines[method] = last[method+"/NK225mini"]
		}
		restored, err := tape.RestoreBatches(event, lines)
		a, _ := json.Marshal(all)
		b, _ := json.Marshal(restored)
		if err != nil || !bytes.Equal(a, b) {
			return nil, fmt.Errorf("mini全Delta往復差: %v", err)
		}
		events = append(events, event)
	}
	if len(forceSeen) != len(forceTimes) {
		return nil, fmt.Errorf("EOF後を含むSource Force不足")
	}
	return events, nil
}

// BuildLegacyTape は新clock frameと新legacy通知を厳密に結合します。
//
// 引数: s(actual.Session)、frames([]ClockFrame)、records([]binder.SourceRecord)は新生成値です。
// 返り値: tape.Tape/ClockProof/errorは新基準入力、限定証拠、又は接続不能です。
func BuildLegacyTape(s actual.Session, frames []ClockFrame, records []binder.SourceRecord) (tape.Tape, ClockProof, error) {
	p := ClockProof{Calls: len(records), GoldenScope: "旧103市場golden無し・対象外。新legacyの全値接続と型検査だけ"}
	out := tape.Tape{Version: 1, Session: s, Capabilities: tape.Capabilities(), Scope: "105新6入力のScalar11/全board時計と新legacy Source全通知。旧54Tape流用なし", Events: []tape.TapeEvent{}}
	carrier, err := followup.ClockCarrier(s.ID)
	if err != nil || carrier.Session != s {
		return out, p, fmt.Errorf("新4場の時計差")
	}
	stepEvents, err := sourceEvents(s, records)
	if err != nil {
		return out, p, err
	}
	quotes := []tape.TapeEvent{}
	for _, event := range stepEvents {
		if event.Kind == "force" {
			out.Events = append(out.Events, event)
			p.Forces++
		} else {
			quotes = append(quotes, event)
		}
	}
	ri := 0
	previous, previousGrid := 0.0, s.Start-1
	previousKind := ""
	for i, frame := range frames {
		if frame.Ordinal != i+1 || math.IsNaN(frame.At) || math.IsInf(frame.At, 0) || frame.At < previous || frame.At == previous && frame.Kind == "grid" && previousKind == "quote" {
			return out, p, fmt.Errorf("新clock frame順不正")
		}
		previous = frame.At
		previousKind = frame.Kind
		switch frame.Kind {
		case "quote":
			if frame.Scalar == nil || frame.At != frame.Scalar.Time || ri >= len(quotes) || !reflect.DeepEqual(frame.Scalar, quotes[ri].Quote) {
				return out, p, fmt.Errorf("新Scalar11とSource記録が不一致 frame%d", i+1)
			}
			out.Events = append(out.Events, quotes[ri])
			ri++
			p.Rows++
		case "grid":
			if frame.Scalar != nil || frame.At <= previousGrid || frame.At < s.Start || frame.At >= s.End || math.Mod(frame.At-s.Start, 300) != 0 {
				return out, p, fmt.Errorf("新全board grid不正")
			}
			previousGrid = frame.At
			out.Events = append(out.Events, tape.TapeEvent{Kind: "grid", At: frame.At})
			p.Grids++
		default:
			return out, p, fmt.Errorf("新clock frame未知種別")
		}
	}
	if ri != len(quotes) || ri == 0 {
		return out, p, fmt.Errorf("新Scalar数とSource quote数の不足/余剰")
	}
	priority := map[string]int{"force": 0, "grid": 1, "quote": 2}
	sort.SliceStable(out.Events, func(i, j int) bool {
		a, b := out.Events[i], out.Events[j]
		return a.At < b.At || a.At == b.At && priority[a.Kind] < priority[b.Kind]
	})
	for i := range out.Events {
		out.Events[i].Ordinal = i + 1
	}
	return out, p, nil
}

// BuildFromRequest は停止producerの全board時計を使い3modeを結合します。
//
// 引数: req(continuous.Request)、records(map[string][]binder.SourceRecord)は人工又はRoot固定後の新入力です。
// 返り値: FreshInput/errorは全3Bindと新基準、又は元入力の不整合です。Sourceを形成しません。
func BuildFromRequest(req continuous.Request, records map[string][]binder.SourceRecord) (FreshInput, error) {
	out := FreshInput{Session: req.Session, Frames: []ClockFrame{}, Bindings: map[string]binder.Proof{}, Tapes: map[string]tape.Tape{}}
	if len(records) != 3 {
		return out, fmt.Errorf("Source全3mode必須")
	}
	legacyJSON, e := json.Marshal(records["legacy"])
	defaultJSON, de := json.Marshal(records["default"])
	if e != nil || de != nil || !bytes.Equal(legacyJSON, defaultJSON) {
		return out, fmt.Errorf("legacy/default全商品SourceRecord本文差")
	}
	expected, err := followup.ObservedGridPrefix(req)
	if err != nil {
		return out, err
	}
	_, _, err = continuous.BuildToSink(req, nil, func(record continuous.Record) error {
		if record.Kind == "row" {
			if record.Row == nil {
				return fmt.Errorf("正NK row欠落")
			}
			q := record.Row.Scalar
			out.Frames = append(out.Frames, ClockFrame{len(out.Frames) + 1, "quote", q.Time, &q})
		} else if record.Kind == "control" && record.Control != nil && record.Control.Kind == "grid" {
			out.Frames = append(out.Frames, ClockFrame{len(out.Frames) + 1, "grid", record.Control.At, nil})
		}
		return nil
	})
	if err != nil {
		return out, err
	}
	grids := []float64{}
	for _, frame := range out.Frames {
		if frame.Kind == "grid" {
			grids = append(grids, frame.At)
		}
	}
	if !reflect.DeepEqual(grids, expected) {
		return out, fmt.Errorf("全board実観測grid prefix差")
	}
	out.Legacy, out.Clock, err = BuildLegacyTape(req.Session, out.Frames, records["legacy"])
	if err != nil {
		return out, err
	}
	for _, mode := range []string{"legacy", "default", "symmetric"} {
		if len(records[mode]) == 0 {
			return out, fmt.Errorf("mode記録欠落: %s", mode)
		}
		bound, proof, e := binder.Bind(out.Legacy, records[mode], mode)
		if e != nil {
			return out, fmt.Errorf("%s Bind: %w", mode, e)
		}
		out.Tapes[mode], out.Bindings[mode] = bound, proof
	}
	return out, nil
}
