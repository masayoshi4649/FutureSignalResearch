# 新4場の時計・Source通知・LD10四会計の接続

2026-11-09。候補は11/5・11/6のDay/Night四場。module `github.com/masayoshi4649/SessionTradeExecuter/freshld105`、package main。今回はコード/手製公開型人工だけで、実4場の原板・CSV・Source記録・Tape・金融結果を読まない。市場実行はRootが条件・入力・コード・実行物を先に固定してから行う。

## 再用と変更範囲

- 停止d20b2027の `followup.ClockCarrier/LoadFreshRequest` を直接importする。新6入力から停止producer `continuous.BuildToSink` を呼び、正NK Scalar11と全board由来の実観測gridだけを使う。旧54場のTapeや価格を新4場へ移さない。
- `BuildLegacyTape` はfresh Scalar11とlegacy全SourceRecordの全商品/手法順・完全Observation出典SHA・直前物理行・Forceを照合し、miniの全Deltaを値copyする。Closes-onlyも残し、`RestoreBatches` の全JSON往復を要求する。数量/Targets/Before/IDを推測して作らない。
- 予定ForceはSource側の全board timerから保存された記録を使う。全体をForce→grid→rawへ結び、同秒rawをgridへ先取りしない。EOF以後の未観測gridは足さず、SourceのEOF Forceを残す。
- legacy/defaultは全商品SourceRecordの全JSON同体を確認し、全3modeを停止Binder e66へ渡す。経済会計はsymmetricだけで、legacy/defaultの金融は0。
- `replay104.go` は停止104の `replay.go` の全bytes同体コピー。`RunModeObserved` を直接使う。旧103のActor/LD10四の数量・比例返済・B5Q・Source予約優先・ATRLock・費用・D1・Forceを変更しない。旧component内のTrial=104は105の外側へ流用せず、105 Nativeを別に保存する。`io104.go` も停止104のIO本文同体コピー。

旧103市場goldenは新4場に存在しない。`old103_market_golden=false` / `golden_scope=対象外` を保持し、新legacy基準Tapeの型接続やlegacy/default相互同体を旧市場再現成功と呼ばない。Sourceの自然形成は上流105Sourceの責務で、この接続器で再実行しない。

## US時計を混同しない

`native.USOpen` は同日ニューヨーク09:30をtzdataで変換する。11/5・11/6 NightはJST23:30で、9月の22:30を流用しない。

| 役割 | 11/5・11/6のJST時計 | 固定元 |
| --- | --- | --- |
| Source PのForce/取得締切 | 23:15（US−900秒） | 停止Source/旧103 |
| Source Uの生成 | 23:45（US+900秒） | 停止Source |
| Actual B5QのUS quiet | [23:30,翌00:00) | 旧103 `gridQuiet`: `[USOpen,USOpen+1800)` |

Sourceの±900秒境界とActualの開始後30分静観は別である。金融式を前後15分へ変更しない。全主分母448枠へUS quietを残す。人工は新US時計、各四冊のConfigと全6 quiet枠を確認した。

## 純APIと保存型

`BuildFromRequest(req continuous.Request, records map[string][]binder.SourceRecord) (FreshInput,error)` は全boardを持つRequestから新基準と3Bindを作る。`RunFresh` がsym四を追加する。`FreshInput.Frames` は新実観測quote/grid、`Legacy` は新legacy基準、`Tapes` は全3modeの結合型、`Bindings` は全3modeの限定proof。

Nightは上流Sourcefull成功（P/U両方の自然行・完結）を前提とする。US+900前のEOFでU未生成の短い失敗Sourceを一般に再生する器ではない。その場合は上流full4成功を満たさず市場preflightで拒否する。未生成Uを補完して新しい成功を作らない。

Nativeは `version=1/trial=105/session/books/source_mode=symmetric/bindings/clock_proof/complete/old103_market_golden=false/golden_scope/legacy_books=0/default_books=0/source_formed_here=false/gate_executed=false`。books内Key/Config/全金融fieldは `LD10_B5Q_P0_C0_D0/C0_D1/C5_D0/C5_D1` の原値。新しいouter namespaceへ金融内IDを変えない。

Completionは `version/trial/stage/success/condition_sha256/sessions/books_per_scene=4/books/results/before/after/unchanged/first2?/old103_market_golden=false/legacy_books=0/default_books=0/source_formed_here=false/error?`。resultsは各 `session/native/fresh_legacy_tape/symmetric_tape/books=4/error?`。FileRefは `{path,sha256}`。金融Nativeと新legacy/sym Tapeを圧縮保存し、default Tapeは全通知QAだけで別経済保存しない。

## Root固定条件

条件は `version:1/trial:105/fixed:true` と以下だけを持つ。雛形は[条件の雛形](条件の雛形.json)。未固定SHAを後でコードへ埋めず、条件のSHAを起動引数で固定する。

- `input_manifest`：新4場・各6入力と純戦略参照。Source条件の同台帳path/SHAと一致すること。
- `source_condition` / `source_full`：停止105Sourceの市場前条件とfull4成功完了。金融first2から上流全4成功を必須にする。全12case/4相互QA、old93全case false、financial105_executed=false、Source前後不変を検査。
- `source_stop`：停止f52676b0。所有集合を全codeへ含める。
- `clock_stop`：停止d20b2027、`binder_stop`：停止e66。各実物と所有集合を全codeへ含める。
- `binary` / `code_sha256`：起動実体と全依存。codeはrepo基準又は絶対path、当CLIの実7source/mod/sumを必須にする。条件内のFileRefは条件directory基準。

Manifest内の `source_root` と `純戦略repo` はManifest directory基準、6filesはsource_root基準。Source結果のcase参照は上流完了directory基準。実データへ進む前に全metadata・code・binary・対象入力SHAを確認する。上流before辞書を理由に既存54Rawを再hashしない。

```powershell
& 'work/105四場の時計とLD10確認/検査/時計とLD10.exe' `
  --condition '<Root固定条件.json>' --condition-sha '<そのSHA256>' `
  --stage first2 --out '<存在しない先頭2先>'

& 'work/105四場の時計とLD10確認/検査/時計とLD10.exe' `
  --condition '<同条件.json>' --condition-sha '<同じSHA256>' `
  --stage full4 --first2 '<同条件先頭2の完了.json>' --first2-sha '<そのSHA256>' `
  --out '<存在しない全4先>'
```

first2は11/5 Day/Night・8会計、full4は11/5–6全四場・16会計。主4設定、診断経済0。前段Native/Tape実SHAと同condition/code/binaryを継承し、各場4冊完結/残予約0を必須にする。新規directory/O_EXCL保存だけを許し、途中失敗を成功へ補わない。

## 人工と未実施

手製Board・空Source公開通知で新四場の全board時計→3Bind→4Book、全16冊の0取引完結を確認。TOPIX/Last0、同秒位相、全商品順、Scalar11/物理行、Force、EOF、Closes-only、未知field/末尾/上書き/未固定metadata拒否を検査した。Closes-onlyの型保持は存在しない玉の金融成功へは配送していない。

人工market metadataの正接続は、一時ダミーファイルと既存停止コード指紋だけを使用し、実LoadRequestは呼ばない。実105Sourceの自然通知非0、実新4場の金融、旧市場golden、独立全原行会計の成功はこの人工では未実施。

```powershell
& 'work/105四場の時計とLD10確認/検査/時計とLD10.exe' `
  --fixture '<手製Request/records bundle.json>' --out '<存在しない人工出力.json.gz>'
```

新Source形成と保護幅変更を混ぜず、LD10は不変。参加448主/432副、実現利益・損失・日夜・二つの正益/起動旗の評価は保存器/Rootの後段で行う。ここで採用判定、機会損失、退出後仮想利益、回収率を作らない。104正式は閉鎖後不変。
