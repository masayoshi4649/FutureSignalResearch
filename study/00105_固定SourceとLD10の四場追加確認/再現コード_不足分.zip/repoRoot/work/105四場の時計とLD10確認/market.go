package main

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"strings"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	followup "github.com/masayoshi4649/SessionTradeExecuter/fixedfollowup"
	binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
)

const ClockStopSHA = "d20b2027067c26022f9dd50e29f720b24915fd1ea2613070c0f6fee275ee22e6"
const BindStopSHA = "e66adae009ff3edfa59b38dd22ffa07c48f83843f045080a4ede0045dab0fbf2"
const Source105StopSHA = "f52676b0cc55fe2fbdbb0f6524161950af4babbb5891513723a01b5f2618c28a"

type MarketCondition struct {
	Version         int               `json:"version"`
	Trial           int               `json:"trial"`
	Fixed           bool              `json:"fixed"`
	Manifest        FileRef           `json:"input_manifest"`
	SourceCondition FileRef           `json:"source_condition"`
	SourceFull      FileRef           `json:"source_full"`
	SourceStop      FileRef           `json:"source_stop"`
	ClockStop       FileRef           `json:"clock_stop"`
	BinderStop      FileRef           `json:"binder_stop"`
	Binary          FileRef           `json:"binary"`
	Code            map[string]string `json:"code_sha256"`
}
type SourceMutual struct {
	Session       string  `json:"session"`
	Success       bool    `json:"success"`
	Legacy        FileRef `json:"legacy_records"`
	Default       FileRef `json:"default_records"`
	LegacyResult  FileRef `json:"legacy_result"`
	DefaultResult FileRef `json:"default_result"`
	ResultEqual   bool    `json:"replay_result_bytes_equal"`
	GzipEqual     bool    `json:"records_gzip_bytes_equal"`
	JSONEqual     bool    `json:"records_jsonl_bytes_equal"`
}
type Source105Completion struct {
	Version      int               `json:"version"`
	Trial        int               `json:"trial"`
	Stage        string            `json:"stage"`
	Success      bool              `json:"success"`
	ConditionSHA string            `json:"condition_sha256"`
	Sessions     int               `json:"sessions"`
	Cases        []SourceCase      `json:"cases"`
	Before       map[string]string `json:"before"`
	After        map[string]string `json:"after"`
	Unchanged    bool              `json:"unchanged"`
	SourceFormed bool              `json:"source_reformed"`
	Finance      *bool             `json:"financial105_executed"`
	Mutual       []SourceMutual    `json:"legacy_default_matches"`
	Error        string            `json:"error,omitempty"`
}
type MarketArguments struct{ Condition, ConditionSHA, Stage, Out, First2, First2SHA string }
type SceneOutput struct {
	Session       string  `json:"session"`
	Native        FileRef `json:"native"`
	LegacyTape    FileRef `json:"fresh_legacy_tape"`
	SymmetricTape FileRef `json:"symmetric_tape"`
	Books         int     `json:"books"`
	Error         string  `json:"error,omitempty"`
}
type MarketCompletion struct {
	Version       int               `json:"version"`
	Trial         int               `json:"trial"`
	Stage         string            `json:"stage"`
	Success       bool              `json:"success"`
	ConditionSHA  string            `json:"condition_sha256"`
	Sessions      int               `json:"sessions"`
	BooksPerScene int               `json:"books_per_scene"`
	Books         int               `json:"books"`
	Results       []SceneOutput     `json:"results"`
	Before        map[string]string `json:"before"`
	After         map[string]string `json:"after"`
	Unchanged     bool              `json:"unchanged"`
	First2        *FileRef          `json:"first2,omitempty"`
	Old103Golden  bool              `json:"old103_market_golden"`
	LegacyBooks   int               `json:"legacy_books"`
	DefaultBooks  int               `json:"default_books"`
	SourceFormed  bool              `json:"source_formed_here"`
	Error         string            `json:"error,omitempty"`
}

// fileSHA は指定したファイルの現物指紋を求めます。
//
// 引数: path(string)は明示参照です。
// 返り値: string/errorはSHA256又はIO失敗です。
func fileSHA(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	if _, err = io.Copy(h, f); err != nil {
		return "", err
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

// checkRef は同じ基準のpathとSHAを前後確認用辞書へ結びます。
//
// 引数: ref(FileRef)、base(string)、before(map[string]string)は参照・根・前指紋です。
// 返り値: string/errorは絶対path又は指紋差です。
func checkRef(ref FileRef, base string, before map[string]string) (string, error) {
	p, err := absolute(base, ref.Path)
	if err != nil || !validSHA(ref.SHA) {
		return "", fmt.Errorf("FileRef未固定")
	}
	h, err := fileSHA(p)
	if err != nil || h != ref.SHA {
		return "", fmt.Errorf("FileRef SHA差:%s", p)
	}
	before[p] = h
	return p, nil
}

// validateSource105 は元4場×3modeと相互QAの全metadataを確認します。
//
// 引数: s(Source105Completion)、expectedSHA(string)は上流完了と固定条件SHAです。
// 返り値: errorは不足/重複/旧golden成功の誤記です。本文は読みません。
func validateSource105(s Source105Completion, expectedSHA string) error {
	ids := followup.CandidateIDs()
	if s.Version != 1 || s.Trial != 105 || s.Stage != "full4" || !s.Success || !s.Unchanged || !s.SourceFormed || s.Finance == nil || *s.Finance || s.Error != "" || s.ConditionSHA != expectedSHA || s.Sessions != 4 || len(s.Cases) != 12 || len(s.Mutual) != 4 || len(s.Before) == 0 || !reflect.DeepEqual(s.Before, s.After) {
		return fmt.Errorf("Source全4成功metadata不正")
	}
	wanted := map[string]bool{}
	for _, id := range ids {
		for _, mode := range []string{"legacy", "default", "symmetric"} {
			wanted[id+"/"+mode] = true
		}
	}
	seen := map[string]SourceCase{}
	for _, row := range s.Cases {
		k := row.Session + "/" + row.Mode
		if !wanted[k] || seen[k].Session != "" || row.Match || row.Error != "" || !validSHA(row.Result.SHA) || !validSHA(row.Records.SHA) || strings.TrimSpace(row.Result.Path) == "" || strings.TrimSpace(row.Records.Path) == "" || row.Counts.Calls <= 0 {
			return fmt.Errorf("Source全12case集合/旧golden旗差")
		}
		seen[k] = row
	}
	mutual := map[string]bool{}
	for _, row := range s.Mutual {
		l, d := seen[row.Session+"/legacy"], seen[row.Session+"/default"]
		if l.Session == "" || mutual[row.Session] || !row.Success || !row.ResultEqual || !row.GzipEqual || !row.JSONEqual || row.Legacy != l.Records || row.Default != d.Records || row.LegacyResult != l.Result || row.DefaultResult != d.Result {
			return fmt.Errorf("Source相互QAの4場結合差")
		}
		mutual[row.Session] = true
	}
	return nil
}

// prepareMarket は全metadataと選択入力の指紋を出力前に固定します。
//
// 引数: a(MarketArguments)、root/exe(string)は実行引数・repo根・起動実体です。
// 返り値: 条件/台帳/上流完了/前指紋/errorは検査済み入力又は拒否です。
func prepareMarket(a MarketArguments, root, exe string) (MarketCondition, continuous.InputManifest, Source105Completion, map[string]string, error) {
	var c MarketCondition
	var m continuous.InputManifest
	var src Source105Completion
	before := map[string]string{}
	fail := func(e error) (MarketCondition, continuous.InputManifest, Source105Completion, map[string]string, error) {
		return c, m, src, before, e
	}
	if a.Stage != "first2" && a.Stage != "full4" {
		return fail(fmt.Errorf("stageはfirst2/full4のみ"))
	}
	cp, e := checkRef(FileRef{a.Condition, a.ConditionSHA}, root, before)
	if e != nil {
		return fail(e)
	}
	if e = decode(cp, &c, false, true); e != nil {
		return fail(e)
	}
	if c.Version != 1 || c.Trial != 105 || !c.Fixed || len(c.Code) == 0 {
		return fail(fmt.Errorf("市場前条件未固定"))
	}
	base := filepath.Dir(cp)
	if c.ClockStop.SHA != ClockStopSHA || c.BinderStop.SHA != BindStopSHA || c.SourceStop.SHA != Source105StopSHA {
		return fail(fmt.Errorf("停止済み時計/Bindの別版混入"))
	}
	ssp, e := checkRef(c.SourceStop, base, before)
	if e != nil {
		return fail(e)
	}
	var sourceStop struct {
		Success bool              `json:"成功"`
		Owned   map[string]string `json:"所有SHA256"`
	}
	if e = decode(ssp, &sourceStop, false, false); e != nil || !sourceStop.Success || len(sourceStop.Owned) == 0 {
		return fail(fmt.Errorf("停止105Source所有集合不正"))
	}

	for path, h := range c.Code {
		if _, e = checkRef(FileRef{path, h}, root, before); e != nil {
			return fail(e)
		}
	}
	for path, h := range sourceStop.Owned {
		p, _ := absolute(root, path)
		if before[p] != h {
			return fail(fmt.Errorf("105Source所有code不足:%s", path))
		}
	}
	_, sourceFile, _, ok := runtime.Caller(0)
	if !ok {
		return fail(fmt.Errorf("当CLI実path不明"))
	}
	for _, name := range []string{"main.go", "market.go", "clock_tape.go", "replay104.go", "io104.go", "go.mod", "go.sum"} {
		p, _ := absolute(filepath.Dir(sourceFile), name)
		if before[p] == "" {
			return fail(fmt.Errorf("当CLIコード固定漏れ:%s", p))
		}
	}
	for _, ref := range []FileRef{c.ClockStop, c.BinderStop} {
		p, e := checkRef(ref, base, before)
		if e != nil {
			return fail(e)
		}
		var stop BinderStop
		if e = decode(p, &stop, false, false); e != nil || !stop.Success || len(stop.Code) == 0 {
			return fail(fmt.Errorf("依存停止不正"))
		}
		for path, h := range stop.Code {
			p, _ := absolute(root, path)
			if before[p] != h {
				return fail(fmt.Errorf("依存所有SHA固定漏れ:%s", path))
			}
		}
	}
	binary, e := checkRef(c.Binary, base, before)
	if e != nil {
		return fail(e)
	}
	actual, _ := filepath.Abs(exe)
	if !strings.EqualFold(actual, binary) {
		return fail(fmt.Errorf("起動実行物path差"))
	}
	scp, e := checkRef(c.SourceCondition, base, before)
	if e != nil {
		return fail(e)
	}
	var sc struct {
		Version  int               `json:"version"`
		Trial    int               `json:"trial"`
		Fixed    bool              `json:"fixed"`
		Manifest FileRef           `json:"input_manifest"`
		Code     map[string]string `json:"code_sha256"`
	}
	if e = decode(scp, &sc, false, false); e != nil || sc.Version != 1 || sc.Trial != 105 || !sc.Fixed {
		return fail(fmt.Errorf("Source条件未固定"))
	}
	for path, h := range sc.Code {
		p, _ := absolute(root, path)
		if before[p] != h {
			return fail(fmt.Errorf("Source固定code不足"))
		}
	}
	mp, e := checkRef(c.Manifest, base, before)
	if e != nil {
		return fail(e)
	}
	smp, e := checkRef(sc.Manifest, filepath.Dir(scp), before)
	if e != nil || mp != smp || c.Manifest.SHA != sc.Manifest.SHA {
		return fail(fmt.Errorf("Sourceと時計の6入力台帳差"))
	}
	if e = decode(mp, &m, false, true); e != nil {
		return fail(e)
	}
	m.Root, e = absolute(filepath.Dir(mp), m.Root)
	if e != nil {
		return fail(e)
	}
	m.StrategyRoot, e = absolute(filepath.Dir(mp), m.StrategyRoot)
	if e != nil {
		return fail(e)
	}
	if e = continuous.ValidateManifest(m); e != nil {
		return fail(e)
	}
	ids := followup.CandidateIDs()
	if len(m.Sessions) != 4 {
		return fail(fmt.Errorf("新4場台帳不足"))
	}
	for i, row := range m.Sessions {
		if row.ID != ids[i] {
			return fail(fmt.Errorf("新4場順序/ID差"))
		}
	}
	sp, e := checkRef(c.SourceFull, base, before)
	if e != nil {
		return fail(e)
	}
	if e = decode(sp, &src, false, false); e != nil {
		return fail(e)
	}
	if e = validateSource105(src, c.SourceCondition.SHA); e != nil {
		return fail(e)
	}
	if a.Stage == "first2" {
		if a.First2 != "" || a.First2SHA != "" {
			return fail(fmt.Errorf("first2へ旧完了混入"))
		}
		m.Sessions = m.Sessions[:2]
	} else {
		fp, e := checkRef(FileRef{a.First2, a.First2SHA}, root, before)
		if e != nil {
			return fail(e)
		}
		var prior MarketCompletion
		if e = decode(fp, &prior, false, true); e != nil {
			return fail(e)
		}
		if !prior.Success || prior.Stage != "first2" || prior.Trial != 105 || prior.ConditionSHA != a.ConditionSHA || prior.Sessions != 2 || prior.Books != 8 || prior.Old103Golden || !prior.Unchanged || !reflect.DeepEqual(prior.Before, prior.After) || len(prior.Results) != 2 {
			return fail(fmt.Errorf("同条件first2成功不足"))
		}
		for i, row := range prior.Results {
			if row.Session != ids[i] || row.Books != 4 || row.Error != "" {
				return fail(fmt.Errorf("first2一意集合差"))
			}
			for _, ref := range []FileRef{row.Native, row.LegacyTape, row.SymmetricTape} {
				if _, e = checkRef(ref, filepath.Dir(fp), before); e != nil {
					return fail(e)
				}
			}
		}
	}
	selected := map[string]bool{}
	for _, row := range m.Sessions {
		selected[row.ID] = true
		for _, file := range row.Files {
			if _, e = checkRef(FileRef{file.Path, file.SHA256}, m.Root, before); e != nil {
				return fail(e)
			}
		}
	}
	for _, row := range src.Cases {
		if selected[row.Session] {
			for _, ref := range []FileRef{row.Result, row.Records} {
				if _, e = checkRef(ref, filepath.Dir(sp), before); e != nil {
					return fail(e)
				}
			}
		}
	}
	return c, m, src, before, nil
}

// runMarket は新6入力を一場ずつ生成しsymmetric四冊だけを保存します。
//
// 引数: a(MarketArguments)、root/exe(string)はRoot固定後の明示実行値です。
// 返り値: MarketCompletion/errorは全完結/入力前後一致、又は失敗記録です。
func runMarket(a MarketArguments, root, exe string) (MarketCompletion, error) {
	out := MarketCompletion{Version: 1, Trial: 105, Stage: a.Stage, ConditionSHA: a.ConditionSHA, BooksPerScene: 4, Results: []SceneOutput{}}
	var pathErr error
	a.Condition, pathErr = absolute(root, a.Condition)
	if pathErr != nil {
		return out, pathErr
	}
	a.Out, pathErr = absolute(root, a.Out)
	if pathErr != nil {
		return out, pathErr
	}
	if a.First2 != "" {
		a.First2, pathErr = absolute(root, a.First2)
		if pathErr != nil {
			return out, pathErr
		}
	}
	c, m, src, before, e := prepareMarket(a, root, exe)
	out.Before = before
	if e != nil {
		return out, e
	}
	if e = os.Mkdir(a.Out, 0755); e != nil {
		return out, e
	}
	out.Sessions = len(m.Sessions)
	if a.Stage == "full4" {
		out.First2 = &FileRef{a.First2, a.First2SHA}
	}
	sourcePath, _ := absolute(filepath.Dir(a.Condition), c.SourceFull.Path)
	for _, scene := range m.Sessions {
		row := SceneOutput{Session: scene.ID}
		records := map[string][]binder.SourceRecord{}
		for _, item := range src.Cases {
			if item.Session == scene.ID {
				p, _ := absolute(filepath.Dir(sourcePath), item.Records.Path)
				r, count, err := readRecords(p)
				if err != nil || count != item.Counts {
					e = fmt.Errorf("全Source記録件数差:%s/%s:%v", scene.ID, item.Mode, err)
					break
				}
				records[item.Mode] = r
			}
		}
		var value Native
		var input FreshInput
		if e == nil {
			request, _, err := followup.LoadFreshRequest(scene, m.Root)
			e = err
			if e == nil {
				value, input, e = RunFresh(request, records, "105固定後4場の新6入力時計/新Source。sym LD10四だけ。旧103市場golden対象外")
			}
		}
		if e == nil {
			path := filepath.Join(a.Out, scene.ID+".json.gz")
			e = writeNew(path, value, true)
			if e == nil {
				row.Native = FileRef{path, ""}
				row.Native.SHA, e = fileSHA(path)
			}
		}
		for _, mode := range []string{"legacy", "symmetric"} {
			if e != nil {
				break
			}
			path := filepath.Join(a.Out, scene.ID+"_"+mode+".tape.json.gz")
			e = writeNew(path, input.Tapes[mode], true)
			if e == nil {
				h, err := fileSHA(path)
				e = err
				if mode == "legacy" {
					row.LegacyTape = FileRef{path, h}
				} else {
					row.SymmetricTape = FileRef{path, h}
				}
			}
		}
		if e != nil {
			row.Error = e.Error()
			out.Error = e.Error()
		} else {
			row.Books = 4
			out.Books += 4
		}
		out.Results = append(out.Results, row)
		if e != nil {
			break
		}
	}
	out.After = map[string]string{}
	for p := range before {
		h, err := fileSHA(p)
		if err != nil && e == nil {
			e = err
		}
		out.After[p] = h
	}
	out.Unchanged = reflect.DeepEqual(out.Before, out.After)
	if !out.Unchanged && e == nil {
		e = fmt.Errorf("固定入力/code/binary前後差")
	}
	if e != nil {
		out.Error = e.Error()
	}
	out.Success = e == nil && len(out.Results) == out.Sessions && out.Books == 4*out.Sessions
	if err := writeNew(filepath.Join(a.Out, "完了.json"), out, false); err != nil && e == nil {
		e = err
	}
	return out, e
}
