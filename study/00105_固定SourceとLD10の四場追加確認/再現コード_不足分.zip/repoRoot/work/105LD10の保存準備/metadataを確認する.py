"""105保存のmetadataだけを人工検査し、実Nativeを読まない。"""

import argparse
import copy
import importlib.util
import json
from pathlib import Path
import tempfile


def main():
    """
    機能: 新4の集合/旧golden対象外/未固定拒否を人工metadataで確認する。
    引数: --out(Path)は新規receipt。
    返り値: None。新4実本文やSource/金融を呼ばない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location("保存105metadata人工", here / "集計.py")
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    condition = {"version": 1, "trial": 105, "fixed": True}
    a, b = "a" * 64, "b" * 64
    rejected = []
    for stage in ("first2", "full4"):
        ids = m.expected_ids(stage)
        value = {"version": 1, "trial": 105, "stage": stage, "success": True, "condition_sha256": a,
            "sessions": len(ids), "books_per_scene": 4, "books": 4 * len(ids), "old103_market_golden": False,
            "legacy_books": 0, "default_books": 0, "source_formed_here": False, "unchanged": True,
            "before": {"手製metadata": b}, "after": {"手製metadata": b},
            "results": [{"session": sid, "books": 4, **{name: {"path": sid + "_" + name + ".json.gz", "sha256": b} for name in ("native", "fresh_legacy_tape", "symmetric_tape")}} for sid in ids]}
        if stage == "full4": value["first2"] = {"path": "人工first2.json", "sha256": b}
        assert len(m.validate_completion(condition, value, stage, a)) == len(ids)
        for label in ("旧市場golden成功", "legacy経済化", "8設定混入", "旧ID混入", "前後差", "未成功", "空NativeRef", "Source再形成"):
            broken = copy.deepcopy(value)
            if label == "旧市場golden成功": broken["old103_market_golden"] = True
            elif label == "legacy経済化": broken["legacy_books"] = 4
            elif label == "8設定混入": broken["books_per_scene"] = 8
            elif label == "旧ID混入": broken["results"][0]["session"] = "2026-09-21_Day"
            elif label == "前後差": broken["after"] = {}
            elif label == "未成功": broken["success"] = False
            elif label == "空NativeRef": broken["results"][0]["native"]["path"] = ""
            elif label == "Source再形成": broken["source_formed_here"] = True
            try:
                m.validate_completion(condition, broken, stage, a)
            except (ValueError, KeyError): rejected.append(stage + ":" + label)
            else: raise AssertionError("metadata破損を成功化")
    with tempfile.TemporaryDirectory(prefix="105保存未固定_") as directory:
        p = Path(directory) / "未固定.json"
        p.write_text(json.dumps({"version": 1, "trial": 105, "phase": "StageB", "fixed": False}), encoding="utf-8")
        calls, original = [], m.OLD.load

        def track(path):
            """
            機能: 未固定人工のJSON読取先だけを追跡する。
            引数: path(Path)はRoot人工metadata。
            返り値: dictは元の値。
            """
            calls.append(path)
            return original(path)

        m.OLD.load = track
        try:
            try: m.prepare(p, m.OLD.digest(p), p.parent / "出力")
            except ValueError: pass
            else: raise AssertionError("未固定Rootを成功化")
        finally: m.OLD.load = original
        assert calls == [p] and not (p.parent / "出力").exists()
    result = {"成功": True, "scope": "人工metadata2/16拒否。金融Native未接続", "metadata正常": 2, "拒否": rejected,
              "未固定RootでNative前拒否": True, "予定主分母": 448, "予定副分母": 432,
              "旧市場golden": "対象外", "実新4場/金融/Raw/CSV本文読取": 0, "codeSHA256": m.OLD.digest(here / "集計.py")}
    with args.out.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2); stream.write("\n")
    print(json.dumps({"成功": True, "正常": 2, "拒否": len(rejected)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
