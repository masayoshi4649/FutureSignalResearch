# 105 sym LD10四の保存準備

新4場の金融結果はまだ読まない。`集計.py` は固定104保存0409をSHAで直接importし、その下の103aa1f/95/94の所有・部分返済・Source比例返済・半円費用・LD起動・MTM保存点・参加・実現算術をそのまま使う。Source/指標/金融/Raw/CSVの再実行は行わない。独立した全原行金融engine検証と呼ばない。

新経済会計はsymmetricのLD10四だけ。内Key `LD10_B5Q_P0_C0_D0/C0_D1/C5_D0/C5_D1` と全Book値を維持する。legacy/defaultは新Sourceの相互通知QAで金融0。新legacy基準Tapeと三Bindの一致は、旧54Tape/旧103市場goldenの成功ではない。旧市場goldenは対象外として保存し、旧103全文対照を作らない。

## Root成功後の固定とCLI

```json
{
  "version": 1,
  "trial": 105,
  "phase": "StageB",
  "fixed": true,
  "stage": "first2",
  "condition": {"path": "<105金融条件.json>", "sha256": "<64桁>"},
  "completion": {"path": "<105金融の完了.json>", "sha256": "<64桁>"},
  "code": {"path": "<本集計.py>", "sha256": "<停止済み64桁>"}
}
```

```powershell
& work/venvs/technical-tree/Scripts/python.exe -B -X utf8 `
  work/105LD10の保存準備/集計.py `
  --fixed '<Rootが成功後に固定したJSON>' --fixed-sha '<現物SHA>' --out '<新規保存先>'
```

FileRefは保持するJSONのparent基準、code_sha256キーはrepo基準/絶対path。first2は11/5Day/Nightの8会計、full4は11/6Day/Nightまで含む16会計。同じ条件とfirst2成功参照を検査する。条件はruntimeの `input_manifest/source_condition/source_full/source_stop/clock_stop/binder_stop/binary/code_sha256` をそのまま結ぶ。

金融Completionの `results[].native/fresh_legacy_tape/symmetric_tape` FileRefをSHA照合する。Nativeの経済四冊/SourceMode/完結/旧市場対象外と、保存された二Tapeの同じ観測grid列をBook.grid_tracesへ結ぶ。Source記録は圧縮現物SHAと金融beforeに結び、内容再生やSource生成をしない。入力のraw/CSVを再読・再hashしない。

## 母数・損失旗・時計

固定103参加算術の主 `[Start+1800,Force)` を保ち、全4場は448、副 `[Start+1800,End−1800)` は432。先頭2は224/216。欠測枠はunknownのまま分母へ残す。u正益後赤字とLD10保護起動後赤字を別に残し、日夜/日別/方向/Source・保護返済、PFと保存点連結DDを既存関数で集約する。費用感度四つを独立した市場標本へ水増ししない。

新11月NightのUSOpenは23:30 JST。既存ActualのUSquiet実式は `[USOpen,USOpen+1800)` =23:30〜翌00:00で、新規の制限。SourceP締切23:15とU生成開始23:45とは別。参加・会計の式を変えず、Rootの `study/00105_固定SourceとLD10の四場追加確認/時計仕様補足.md` に従い旧±15分という誤記を転記しない。

## Viewer資源

新専用ID `105_{innerKey}_{session}` で8又は16の一覧と実Fill tradesを生成する。実HTTPはこの保存器では行わない。

入力全体のgzipは共有2/work6。ViewerはNKだけなので共有1/work3を使う。固定InputManifestのNK225_bookと金融beforeのSHAに結んだ**実使用gzip絶対path**をmarket_pathへ記載する。既存Viewer.resolvePathが絶対pathを受けるため、共有先に無いgzipを相対参照したり設定を変更したりしない。市場価格gzipの本文は本保存器では再読しない。既存8092/PID19844の操作なし。

## 人工の範囲

runtime停止0a41056dの実Go型4Nativeは手製Request/全商品空通知の接続で、16空会計のみ。保存器へ全型を結び、主448/副432・Viewer形式16と10破損拒否を確認する。自然Sourceや非0金融を検証したとは呼ばない。104/103の非0保存検算は旧停止の直接再用根拠であり、105新4の非0成功へ流用しない。

`metadataを確認する.py` はfirst2/full4の正常2・16破損拒否と、Root未固定時にNative読取前で拒否することを検査する。`公開型を確認する.py --fixtures work/105四場の時計とLD10確認/人工 --out <新規証拠> --viewer-dir <新規人工先>` で型人工を再確認できる。

出力は結果.json/.md、保存会計の確認.json、一覧.resources.json、実trades。後のRoot成功通知まで実金融本文を読まない。未使用・未検証・対象外の別、実現損益中心の評価を維持し、機会損失/退出後価格/MFEは扱わない。
