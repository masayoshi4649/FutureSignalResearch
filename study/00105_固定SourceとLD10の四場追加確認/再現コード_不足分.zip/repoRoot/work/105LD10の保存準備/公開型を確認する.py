"""105実Go型の空Native四場を保存器へ接続する。市場結果を代用しない。"""

import argparse
import copy
import importlib.util
import json
from pathlib import Path


def main():
    """
    機能: 新公開型16空会計/分母/Viewer形式と狭い破損を検査する。
    引数: --fixtures/--out/--viewer-dir(Path)はGo型人工根と新規証拠先。
    返り値: None。Source形成/非0金融/実4場の成功へ拡張しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixtures", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--viewer-dir", type=Path, required=True)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location("105保存の公開型人工", here / "集計.py")
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    paths = [args.fixtures / (sid + ".Native.json") for sid in m.IDS]
    stop = m.ROOT / "work/105四場の時計とLD10確認/停止.json"
    stop_sha = "0a41056d1a9d0c14d13e0bf23d3f78fe7ce1ffb42b13dd2dfb898d8f81802299"
    assert m.OLD.digest(stop) == stop_sha
    runtime = m.OLD.load(stop)
    before = {str(p.resolve()): m.OLD.digest(p) for p in paths}
    for p in paths:
        name = p.resolve().relative_to(m.ROOT).as_posix()
        assert runtime["人工/検査SHA256"][name] == m.OLD.digest(p)
    before[str(stop)] = stop_sha
    before[str(m.BASE_PATH)] = m.BASE_SHA
    values, rows, resources = [], [], []
    need = m.need
    need(not args.viewer_dir.exists(), "人工Viewer新規先")
    args.viewer_dir.mkdir(parents=True)
    artificial_market = str((args.viewer_dir / "人工市場未読.gz").resolve())
    for path in paths:
        value = m.OLD.load(path)
        frozen = m.OLD.freeze(value)
        checked = m.inspect_scene(value, True)
        assert len(checked) == 4 and all(not v["positions"] and not v["orders"] for v in checked.values())
        rows.extend(m.scene_rows(value, checked))
        resources.extend(m.save_viewer(value, args.viewer_dir, artificial_market))
        assert frozen == m.OLD.freeze(value)
        values.append(value)
    summary, diagnostic = m.aggregate(rows, True)
    assert len(resources) == 16 and len({v["id"] for v in resources}) == 16
    assert all(r["market_path"] == artificial_market for r in resources)
    for row in summary.values():
        assert row["net_yen"] == row["gross_yen"] == row["fee_yen"] == row["slip_yen"] == 0
        assert row["活動主表"]["denom"] == 448 and row["活動副表"]["denom"] == 432
        assert row["活動主表"]["active"] == 0
    m.OLD.BASE.write_json(args.viewer_dir / "一覧.resources.json", {"schema_version": 1, "path_base": "catalog", "resources": resources})
    rejected = []
    for label in ("旧市場golden成功", "legacy経済追加", "mode差", "key不足", "LD政策差", "内場差", "旧54Tape流用", "Bind所属差", "grid数差", "保存純額差"):
        value = copy.deepcopy(values[0]); key = m.KEYS[0]
        if label == "旧市場golden成功": value["old103_market_golden"] = True
        elif label == "legacy経済追加": value["legacy_books"] = 4
        elif label == "mode差": value["source_mode"] = "legacy"
        elif label == "key不足": value["books"].pop(key)
        elif label == "LD政策差": value["books"][key]["config"]["activation_policy"] = "LD05"
        elif label == "内場差": value["books"][key]["session"]["id"] = m.IDS[1]
        elif label == "旧54Tape流用": value["clock_proof"]["old54_tape_used"] = True
        elif label == "Bind所属差": value["bindings"]["default"]["mode_declared"] = "symmetric"
        elif label == "grid数差": value["clock_proof"]["all_board_grids"] += 1
        elif label == "保存純額差": value["books"][key]["totals"]["net_yen"] += 1
        try: m.inspect_scene(value, True)
        except (ValueError, KeyError): rejected.append(label)
        else: raise AssertionError("型破損を成功化:" + label)
    assert all(m.OLD.digest(Path(p)) == h for p, h in before.items())
    result = {"成功": True, "scope": "実Go型の新4場16空会計。全board時計/三Bindの人工のみ。自然Source/非0金融は未実施",
        "公開型空会計": 16, "主分母": 448, "副分母": 432, "主active": 0, "Viewer形式": 16,
        "実HTTP": 0, "拒否": rejected, "公開型入力SHA256前後": before, "前後不変": True,
        "旧金融再用": "104保存0409→103aa1f→95/94を同一関数でimport。105の非0/実市場検算成功はまだ主張しない",
        "codeSHA256": m.OLD.digest(here / "集計.py"), "新4場/Raw/CSV/金融実本文読取": 0}
    with args.out.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2); stream.write("\n")
    print(json.dumps({"成功": True, "空会計": 16, "主分母": 448, "副分母": 432, "拒否": len(rejected)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
