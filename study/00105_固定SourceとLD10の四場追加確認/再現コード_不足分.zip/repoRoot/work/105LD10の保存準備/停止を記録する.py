"""105保存外周の実Go空型接続と固定再用元だけを停止へ結ぶ。"""

import importlib.util
import json
from pathlib import Path


def main():
    """
    機能: 元コード/Go型/人工証拠を照合し新規停止JSONを保存する。
    引数: なし。
    返り値: None。市場本文/金融/Source/原板/HTTPを実行しない。
    """
    here = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location("105保存停止", here / "集計.py")
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    root = m.ROOT
    paths = {m.BASE_PATH: m.BASE_SHA, m.BASE.LEGACY_PATH: m.BASE.LEGACY_SHA,
        m.OLD.GRID_PATH: m.OLD.GRID_SHA, m.OLD.GRID.BASE_PATH: m.OLD.GRID.BASE_SHA,
        root / "work/104LD10の保存/停止.json": "b4859a859f7b5dbfd3094824186984a4f7068fadf2a8819d88958728d3db2504",
        root / "work/105四場の時計とLD10確認/停止.json": "0a41056d1a9d0c14d13e0bf23d3f78fe7ce1ffb42b13dd2dfb898d8f81802299"}
    runtime = m.OLD.load(root / "work/105四場の時計とLD10確認/停止.json")
    for name, h in runtime["所有コードSHA256"].items(): paths[root / name] = h
    for name, h in runtime["人工/検査SHA256"].items():
        if name.endswith(".Native.json"): paths[root / name] = h
    before = {str(p): m.OLD.digest(p) for p in paths}
    m.equal(before, {str(p): h for p, h in paths.items()}, "固定再用元/runtime/Go型")
    code = m.OLD.digest(here / "集計.py")
    proofs = {}
    for name in ("公開型人工_最終.json", "metadata人工_最終.json"):
        p = here / name; v = m.OLD.load(p)
        m.need(v["成功"] is True and v["codeSHA256"] == code, "人工と現保存本体SHA")
        proofs[name] = {"path": p.relative_to(root).as_posix(), "SHA256": m.OLD.digest(p)}
    public, metadata = m.OLD.load(here / "公開型人工_最終.json"), m.OLD.load(here / "metadata人工_最終.json")
    m.need(public["公開型空会計"] == public["Viewer形式"] == 16 and public["主分母"] == 448 and public["副分母"] == 432, "公開型/新母数")
    m.need(len(public["拒否"]) == 10 and len(metadata["拒否"]) == 16 and metadata["未固定RootでNative前拒否"] is True, "破損拒否/未固定入口")
    owned = {str((here / n).relative_to(root)).replace("\\", "/"): m.OLD.digest(here / n) for n in (
        "集計.py", "公開型を確認する.py", "metadataを確認する.py", "停止を記録する.py", "README.md", "由来.json")}
    after = {str(p): m.OLD.digest(p) for p in paths}
    m.equal(before, after, "元コード/型の停止時不変")
    value = {"成功": True, "市場本文未読": True, "scope": "105保存準備。実Go16空型/metadataだけ。新4場市場保存成功ではない",
        "保存コードSHA256": code, "所有コードSHA256": owned, "再用元SHA256前": before, "再用元SHA256後": after, "前後不変": True,
        "人工証拠": proofs, "人工成功": {"Go型空会計": 16, "Viewer形式": 16, "型破損拒否": 10, "metadata正常": 2,
            "metadata拒否": 16, "未固定RootでNative前拒否": True, "主分母": 448, "副分母": 432, "実HTTP": 0},
        "直接再用": "固定1040409→103aa1f/95/94の会計/所有/Source比例/部分返済/半円/参加/二旗/実現/保存点DD。式変更なし",
        "主key": list(m.KEYS), "予定保存": {"first2": {"会計": 8, "主分母": 224, "副分母": 216}, "full4": {"会計": 16, "主分母": 448, "副分母": 432}},
        "旧市場golden": "対象外。全値旧市場対照を人工/新legacyへ置換しない", "legacy/default金融": 0,
        "Viewer市場参照": "入力全体共有2/work6のうちNK共有1/work3を固定Manifest絶対pathで参照。本文再読/設定変更なし",
        "Root固定schema": "version1/trial105/phaseStageB/fixedtrue/stagefirst2orfull4/condition,completion,code各FileRef。相対参照は固定JSONのparent基準",
        "Root実行argv": ["work/venvs/technical-tree/Scripts/python.exe", "-B", "-X", "utf8", "work/105LD10の保存準備/集計.py", "--fixed", "<Root保存用固定.json>", "--fixed-sha", "<現物SHA>", "--out", "<新規先>"],
        "未実施": ["新4場金融本文/Raw/CSV/市場価格読取", "新4場非0保存検算", "実Viewer/API", "全原行別金融engine", "機会損失/退出後/MFE"],
        "既存コード/金融/Source停止変更": 0}
    p = here / "停止.json"
    with p.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2); stream.write("\n")
    print(json.dumps({"成功": True, "保存コードSHA256": code, "停止SHA256": m.OLD.digest(p)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
