"""105追記前後を読取専用OOXML比較し、全旧セル/式/書式を守る。"""
from __future__ import annotations

import argparse
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import xml.etree.ElementTree as ET

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
BOOK = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/元アルゴリズムと現行代表候補の損益比較.xlsx'
BASE_SHA = 'd6af661a6ab3950fde14c74a46b2354f6f66b360a908ed8322ceb0c510c9257a'
SPEC = importlib.util.spec_from_file_location('既存103の読取専用OOXML', ROOT / 'work/xlsx比較_作成/103の保存比較QA.py')
OLD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)


def row_number(address: str) -> int:
    """
    機能: A1形式の先頭行を得る。
    引数: address (str) はセル又は範囲。
    返り値: int は行番号。
    """
    return int(re.search(r'\d+', address).group())


def sheet_form(parts: dict, part: str, cells: dict, original: bytes | None = None) -> str:
    """
    機能: 105追記行だけを除き既存worksheet構造を比較する。
    引数: parts/part/cells/original はZIP部品/対象/セル/元XML。
    返り値: str は参照文字列/relationshipを解決した正規XML。
    """
    tree = ET.fromstring(parts[part])
    if original is not None:
        prior = ET.fromstring(original)
        data = tree.find('m:sheetData', OLD.NS)
        for row in list(data):
            if int(row.attrib['r']) >= 79:
                data.remove(row)
        dimension = tree.find('m:dimension', OLD.NS)
        if dimension is not None:
            dimension.attrib = dict(prior.find('m:dimension', OLD.NS).attrib)
        merges = tree.find('m:mergeCells', OLD.NS)
        if merges is not None:
            for merge in list(merges):
                if row_number(merge.attrib['ref']) >= 79:
                    merges.remove(merge)
            merges.attrib = dict(prior.find('m:mergeCells', OLD.NS).attrib)
    for cell in tree.findall('.//m:sheetData/m:row/m:c', OLD.NS):
        if cell.attrib.get('t') == 's':
            cell.find('m:v', OLD.NS).text = str(cells[cell.attrib['r']]['value'])
    copied = dict(parts)
    copied[part] = ET.tostring(tree, encoding='utf-8')
    return OLD.normalized_part(copied, part)


def compare(before: Path, after: Path, appended: bool) -> dict:
    """
    機能: 全旧セル/式/スタイル/図表とworksheet構造を確認する。
    引数: before/after (Path)、appended (bool) は旧新と追記有無。
    返り値: dict は読取専用の保持証拠。
    """
    assert OLD.digest(before) == BASE_SHA
    pa, sa, ca = OLD.read_workbook(before)
    pb, sb, cb = OLD.read_workbook(after)
    assert list(sa) == list(sb) == ['比較', 'セッション明細', '新条件102', '一定利益後103']
    proof = []
    for name in sa:
        current = {k: v for k, v in cb[name].items() if row_number(k) < 79} if appended and name == '一定利益後103' else cb[name]
        assert current == ca[name], name + '既存全セル/式/型/スタイル差'
        right = sheet_form(pb, sb[name], cb[name], pa[sa[name]] if appended and name == '一定利益後103' else None)
        assert sheet_form(pa, sa[name], ca[name]) == right, name + '既存worksheet構造差'
        proof.append({'sheet': name, '旧全セル': len(ca[name]), '全値/式/型/スタイル保持': True, '旧worksheet構造保持': True})
    objects = [name for name in pa if name.startswith(('xl/charts/', 'xl/drawings/', 'xl/tables/'))]
    assert objects == [name for name in pb if name.startswith(('xl/charts/', 'xl/drawings/', 'xl/tables/'))]
    assert all(OLD.normalized_part(pa, name) == OLD.normalized_part(pb, name) for name in objects)
    for section in ('fonts', 'fills', 'borders', 'cellStyleXfs', 'cellXfs', 'cellStyles', 'dxfs', 'numFmts'):
        old = ET.fromstring(pa['xl/styles.xml']).find('m:' + section, OLD.NS)
        new = ET.fromstring(pb['xl/styles.xml']).find('m:' + section, OLD.NS)
        if old is not None:
            assert new is not None and len(new) >= len(old), section
            assert all(ET.tostring(a) == ET.tostring(b) for a, b in zip(old, new)), section
    for field in ('definedNames', 'bookViews', 'workbookProtection'):
        a = ET.fromstring(pa['xl/workbook.xml']).find('m:' + field, OLD.NS)
        b = ET.fromstring(pb['xl/workbook.xml']).find('m:' + field, OLD.NS)
        assert (ET.tostring(a) if a is not None else None) == (ET.tostring(b) if b is not None else None), field
    assert not [f'{name}!{key}' for name, cells in cb.items() for key, cell in cells.items() if cell['type'] == 'e']
    return {'旧4tab': proof, '旧図表parts保持': len(objects), '旧styles定義保持': True, '104_A64_L77保持': True, '全ZIP_CRC': True}


def main() -> None:
    """
    機能: 今回は読取baseline、将来は追記後の正本照合を実行する。
    引数: CLIのbaseline/source/source-sha/outはモード/将来入力/新規証拠保存先。
    返り値: None。xlsxを生成/編集しない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--baseline', action='store_true')
    parser.add_argument('--source', type=Path)
    parser.add_argument('--source-sha')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    before = BOOK if args.baseline else WORK / '105追記前.xlsx'
    proof = compare(before, BOOK, not args.baseline)
    if not args.baseline:
        assert args.source and args.source_sha and OLD.digest(args.source) == args.source_sha
        result = json.loads(args.source.read_text(encoding='utf-8-sig'), parse_float=Decimal)
        assert result['試行'] == 105 and result['場数'] == 4 and result['会計数'] == 16
        _, _, all_cells = OLD.read_workbook(BOOK)
        cells = all_cells['一定利益後103']
        for i, (cost, delay) in enumerate(((0,0),(0,1),(5,0),(5,1))):
            row, flag = 83 + i, 89 + i
            key = f'LD10_B5Q_P0_C{cost}_D{delay}'
            value = result['集計'][key]
            for column, name in [('B','gross_yen'),('C','fee_yen'),('D','slip_yen'),('E','net_yen'),('F','positive_yen'),('G','negative_yen'),('I','positions'),('J','entry_quantity')]:
                assert cells[column+str(row)]['value'] == value[name], (key, column)
            assert cells['K'+str(row)]['value'] == value['活動主表']['active']
            assert abs(cells['L'+str(row)]['value'] - Decimal(value['活動主表']['active'])/448) < Decimal('1e-14')
            for column, name in [('B','unit_positive_positions'),('C','unit_positive_closed_negative'),('D','unit_positive_closed_negative_yen'),('E','protection_activated_positions'),('F','activated_closed_negative'),('G','activated_closed_negative_yen'),('H','保存点連結時価DD')]:
                assert cells[column+str(flag)]['value'] == value[name]
        expected = {(x['session'], x['key']): x for x in result['場別']}
        ids = ['2026-11-05_Day','2026-11-05_Night','2026-11-06_Day','2026-11-06_Night']
        keys = [f'LD10_B5Q_P0_C{c}_D{d}' for c in (0,5) for d in (0,1)]
        for row, pair in enumerate(((name, key) for name in ids for key in keys), 95):
            value = expected[pair]
            for col, field in [('D','net_yen'),('E','positive_yen'),('F','negative_yen'),('G','positions'),('H','entry_quantity')]:
                assert cells[col+str(row)]['value'] == value[field]
            activity = value['活動主表']
            for col, field in [('I','new'),('J','hold'),('K','denom')]:
                assert cells[col+str(row)]['value'] == activity[field]
            assert abs(cells['L'+str(row)]['value'] - Decimal(activity['active'])/activity['denom']) < Decimal('1e-14')
        proof['105四感度/16場別正本一致'] = True
        proof['正本SHA256'] = args.source_sha
    proof.update({'成功': True, 'scope': '既存ブックの読取baselineのみ' if args.baseline else '105追記後の旧保持/正本照合',
                  'ブックSHA256': OLD.digest(BOOK), 'xlsx編集/生成/marker': 0, '105実結果読取': 0 if args.baseline else 1})
    with args.out.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
