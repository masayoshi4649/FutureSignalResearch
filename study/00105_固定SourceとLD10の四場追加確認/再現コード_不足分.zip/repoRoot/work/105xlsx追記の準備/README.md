# 105のxlsx追記コード（実編集前）

2026-11-09。スプレッドシートskill、編集workflow、Artifact API/style/scientific guidanceを読み、既存 `損益比較を作る.mjs` のappend104を参考に別workへ用意した。旧builder、104正式archive、既存xlsxは変更しない。今回の実105Source/金融/保存本文は読まない。

## 対象と配置

対象は `outputs/01a1889f-f2af-7943-a047-543275ee9ed2/元アルゴリズムと現行代表候補の損益比較.xlsx`。入力SHA256は `d6af661a6ab3950fde14c74a46b2354f6f66b360a908ed8322ceb0c510c9257a`。

4タブの順/名前、既存全cell/数式/書式/図表を保持する。第4タブ `一定利益後103` の104追記A64:L77は変更しない。空行78の下、**A79:L121だけ**を105のために予約する。

| 範囲 | 内容 |
| --- | --- |
| A79:L80 | 105の対象と4場の区分 |
| A82:L86 | 4感度の粗額/手数料/仮定滑り/純額/全正額/全負額/PF/玉枚数/活動枠/参加率 |
| A88:L92 | u正益旗とLD10起動旗の別赤字、保存点DD、新規/保有/待機/不能 |
| A94:L110 | 四場×四感度の16会計。場別損益/正負/量/参加分母と率 |
| A112:L121 | 小標本、Source QAと金融の区分、US時計、Viewer配置/確認範囲、正本参照/限界 |

新しいタブ/図/Excel Tableは増やさない。既存の列幅/描画/行へ触らず、追加範囲だけ既存のArial10・暗色headerに合わせる。金額は数値のまま半円を表示できるformat、日付はDate型、率は分子/分母の数式。PFの負額0は「未定義」で、未検証や欠測を0へ補わない。

Source/金融の旧golden対象外、legacy/default金融0、C5の動的別運転、小標本4場/2開始日を明示する。旧54場の利益に新4場を合算せず、機会損失/退出後仮想利益/MFE回収率は使わない。二つの旗の赤字とDDを最終純額へ混ぜない。

## 今回行った読取/純人工

- `105を追記する.mjs --review` は既存ブックのimport/inspect/renderだけ。xlsx export/編集は0。
- `現在の104末尾.png` を目視し、A64:L77の既存表示と、追加範囲の空白を確認。
- 読取専用OOXMLは全4タブ11,244セル、8図表parts、既存styles/列幅/結合/検証/印刷等を比較対象として保持基準へ収録。
- `純入力を検査する.mjs` は手製四感度/16会計・無取引PF・元入力不変と9破損拒否。Workbook作成/編集も市場実績読取も0。

`@oai/artifact-tool` はloader cacheの `dependencies/node/node_modules` を新workのjunctionで参照する。repo-local依存を著作libraryに使わない。Node実行物は同cacheの `dependencies/node/bin/node.exe`。PythonのOOXML検査はZIP読取だけでありExcel authoringを行わない。

## Rootの後段実行（まだ未実行）

実Source/金融/保存/Viewer確認後だけ、[事後固定JSON](実行固定の雛形.json)を別ファイルへ固定する。`fixed/result_ready/financial_checked/viewer_checked=true` と4FileRefの実SHAを要求する。`viewer_scope` は実際に確認した代表資源又は全件の範囲を記し、代表確認を全16API成功へ広げない。FileRefはこの事後固定JSONのdirectory基準。

**最初の編集コマンドの直前**に、skillのmarkerをedit/1xlsxとして成功実行する。今回、このmarkerは実行していない。

```powershell
& 'C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe' `
  'C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/plugins/openai-primary-runtime/plugins/spreadsheets/skills/spreadsheets/container_tools/mark_artifact_operation_started.mjs' `
  --operation-kind edit --expected-output-count 1 --output-format xlsx

& 'C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe' `
  'work/105xlsx追記の準備/105を追記する.mjs' --append '<Root事後固定.json>' '<そのSHA256>'
```

追記branchは、Source/金融を再実行せず小さな保存集計/完了/確認だけを読む。金融16完結、保存16差0、同completion SHA、保存確認の結果SHA、Viewer成功証拠を結ぶ。四場一意×四Key・場別合計→全体一致・全負額・二旗・主448/場別76,148を検査する。新規の資本金や合格gateを作らない。

編集時は `105追記前.xlsx` をworkへ同bytes退避し、追加範囲だけを書く。新範囲の数式入力反応と元値復元、recalculate、旧4タブの値/式/図参照保持、3領域renderと式error scanを実施してから同じxlsxへexportする。

```powershell
# 必須。保存後の全旧セル/式/型/スタイル/図表と105の正本を別に読み戻す
& 'work/venvs/technical-tree/Scripts/python.exe' -B -X utf8 `
  'work/105xlsx追記の準備/保存後を確認する.py' `
  --source '<105保存結果.json>' --source-sha '<そのSHA256>' `
  --out '<新規105保存後QA.json>'
```

保存後QAと新3画像の目視が通るまで最終成功/採用としない。旧値/式/書式/図表や105数値の差があればRootへ報告して停止し、検査を緩めない。Excel本体での実行確認は別であり、Artifactの再計算/PNGをExcel本体の実行証明にしない。

## 読取の再確認

```powershell
& 'C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe' `
  'work/105xlsx追記の準備/105を追記する.mjs' --review
```

read-onlyではmarkerを呼ばず、原ブックSHAが変わらないことを最後に確認する。今回の停止は編集コードの準備であり、新領域の実export/表示結果は未検証のまま残す。
