/**
 * 追記データの四感度/全16場別の純関数だけを人工で確認する。
 * 引数: なし。手製集約値を使う。
 * 返り値: Promise<void>。xlsx/市場実績/markerを開かない。
 */
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { prepareTables } from './105を追記する.mjs';

const ids = ['2026-11-05_Day','2026-11-05_Night','2026-11-06_Day','2026-11-06_Night'];
const keys = [0,5].flatMap(c=>[0,1].map(d=>`LD10_B5Q_P0_C${c}_D${d}`));

/**
 * 手製1場の保存集約を作る。
 * @param {string} session - 人工場ID。
 * @param {string} key - 費用遅延ID。
 * @returns {Object} 自然Sourceや実価格を表さない型人工。
 */
function row(session,key){
  const empty=key.endsWith('C5_D1'), cost=Number(key.match(/C(\d)/)[1]), denom=session.endsWith('_Day')?76:148;
  const gross=empty?0:2000,fee=empty?0:154,slip=empty?0:cost*400,net=gross-fee-slip,positive=empty?0:2500;
  const active=empty?0:20;
  return {session,key,gross_yen:gross,fee_yen:fee,slip_yen:slip,net_yen:net,positive_yen:positive,negative_yen:net-positive,
    positions:empty?0:2,entry_quantity:empty?0:2,unit_positive_positions:empty?0:2,unit_positive_closed_negative:empty?0:1,
    unit_positive_closed_negative_yen:empty?0:-77,protection_activated_positions:empty?0:1,activated_closed_negative:0,activated_closed_negative_yen:0,
    '活動主表':{denom,new:0,hold:active,active,wait:denom-active,unknown:0}};
}

/**
 * 手製四場を全体と場別の同じschemaへまとめる。
 * @returns {Object} 人工だけの105結果型。
 */
function fixture(){
  const r={'試行':105,'成功':true,stage:'full4',SourceMode:'symmetric','場数':4,'会計数':16,'legacy/default金融会計':0,
    '旧市場golden':{'対象外':true,'対照会計':0},'前後不変':true,'入力codeSHA256前':{},'入力codeSHA256後':{},'集計':{},'場別':[]};
  for(const key of keys){
    const scenes=ids.map(id=>row(id,key));r['場別'].push(...scenes);
    const t={};for(const field of Object.keys(scenes[0]))if(typeof scenes[0][field]==='number')t[field]=scenes.reduce((n,x)=>n+x[field],0);
    const active=scenes.reduce((n,x)=>n+x['活動主表'].active,0);
    t['活動主表']={denom:448,new:0,hold:active,active,wait:448-active,unknown:0};t['保存点連結時価DD']=123;
    t.PF=t.negative_yen<0?t.positive_yen/-t.negative_yen:null;r['集計'][key]=t;
  }
  return r;
}

const r=fixture(), before=JSON.stringify(r), tables=prepareTables(r);
assert.equal(tables.summary.length,4);assert.equal(tables.details.length,16);assert.equal(tables.flags.length,4);
assert.equal(JSON.stringify(r),before);assert.equal(tables.summary[3][1],0);assert.equal(r['集計'][keys[3]].PF,null);
let rejected=0;
for(const mutate of [
  x=>x['場別'].pop(),x=>x['場別'][1]=structuredClone(x['場別'][0]),x=>x.SourceMode='legacy',x=>x['旧市場golden']['対象外']=false,
  x=>x['集計'][keys[0]].net_yen++,x=>x['集計'][keys[0]].gross_yen=NaN,x=>x['場別'][0]['活動主表'].denom=72,
  x=>x['場別'][0]['活動主表'].new++,x=>x['集計'][keys[0]].activated_closed_negative=99,
]){
  const bad=fixture();mutate(bad);assert.throws(()=>prepareTables(bad));rejected++;
}
const proof={'成功':true,'scope':'手製集約だけ。workbook作成/編集/markerなし','四感度':4,'場別':16,'無取引PF未定義保持':true,
  '元入力不変':true,'破損拒否':rejected,'105実結果読取':0,'xlsx編集/export/marker':0};
await fs.writeFile(path.join(import.meta.dirname,'純入力の人工確認.json'),JSON.stringify(proof,null,2));
console.log(JSON.stringify(proof));
