/**
 * 105の比較表を既存ブックの第4タブ下へ限定追記する準備コード。
 * 引数: CLIの--review/--self-test/--appendと固定JSONは検査又は将来のRoot実行を指定する。
 * 返り値: Promise<void>。準備段階ではxlsxの編集/exportを実行しない。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import { FileBlob, SpreadsheetFile } from '@oai/artifact-tool';

const ROOT = path.resolve(import.meta.dirname, '../..');
const WORK = import.meta.dirname;
const BOOK = path.join(ROOT, 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/元アルゴリズムと現行代表候補の損益比較.xlsx');
const BOOK_SHA = 'd6af661a6ab3950fde14c74a46b2354f6f66b360a908ed8322ceb0c510c9257a';
const SHEETS = ['比較', 'セッション明細', '新条件102', '一定利益後103'];
const PRESERVED = ['A1:M91', 'A1:S452', 'A1:L52', 'A1:L77'];
const TARGET_SHEET = '一定利益後103';
const TARGET = 'A79:L121';
const KEYS = [0, 5].flatMap(cost => [0, 1].map(delay => `LD10_B5Q_P0_C${cost}_D${delay}`));
const IDS = ['2026-11-05_Day', '2026-11-05_Night', '2026-11-06_Day', '2026-11-06_Night'];

/**
 * bytesのSHA256を返す。
 * @param {Uint8Array|string} bytes - 明示入力。
 * @returns {string} 64桁の指紋。
 */
function sha(bytes) { return crypto.createHash('sha256').update(bytes).digest('hex'); }

/**
 * 相対FileRefと実体SHAを固定し、小JSONを読む。
 * @param {{path:string,sha256:string}} ref - 固定参照。
 * @param {string} base - 参照の基準directory。
 * @param {Map<string,string>} inputs - 入力前指紋。
 * @returns {Promise<{value:Object,path:string,sha256:string}>} 復号値と出典。
 */
async function readRef(ref, base, inputs) {
  assert.ok(ref && typeof ref.path === 'string' && ref.path.trim() && /^[0-9a-f]{64}$/.test(ref.sha256));
  const file = path.resolve(base, ref.path), bytes = await fs.readFile(file);
  assert.equal(sha(bytes), ref.sha256, file);
  inputs.set(file, ref.sha256);
  return { value: JSON.parse(bytes.toString('utf8').replace(/^\uFEFF/, '')), path: file, sha256: ref.sha256 };
}

/**
 * 実集約の算術・参加分母・二旗を補完せず検査する。
 * @param {Object} row - 保存済み場別又は全体の集約。
 * @param {number} denom - 対象予定枠。
 * @returns {void} 不整合なら例外。
 */
export function checkRow(row, denom) {
  for (const field of ['gross_yen', 'fee_yen', 'slip_yen', 'net_yen', 'positive_yen', 'negative_yen', 'positions', 'entry_quantity', 'unit_positive_positions', 'unit_positive_closed_negative', 'unit_positive_closed_negative_yen', 'protection_activated_positions', 'activated_closed_negative', 'activated_closed_negative_yen']) {
    assert.ok(typeof row[field] === 'number' && Number.isFinite(row[field]), field);
  }
  assert.equal(row.gross_yen - row.fee_yen - row.slip_yen, row.net_yen);
  assert.equal(row.positive_yen + row.negative_yen, row.net_yen);
  assert.ok(row.positive_yen >= 0 && row.negative_yen <= 0);
  assert.ok(row.unit_positive_closed_negative <= row.unit_positive_positions);
  assert.ok(row.activated_closed_negative <= row.protection_activated_positions);
  const a = row['活動主表'];
  assert.equal(a.denom, denom);
  assert.equal(a.new + a.hold, a.active);
  assert.equal(a.active + a.wait + a.unknown, denom);
  assert.ok([a.new, a.hold, a.active, a.wait, a.unknown].every(n => Number.isInteger(n) && n >= 0));
}

/**
 * 四場全16設定を検査し、書込用の型付き配列を作る。
 * @param {Object} result - 正本の105保存結果。
 * @returns {{summary:Array<Array<unknown>>,flags:Array<Array<unknown>>,details:Array<Array<unknown>>}} 追記表。
 */
export function prepareTables(result) {
  assert.equal(result['試行'], 105); assert.equal(result['成功'], true); assert.equal(result.stage, 'full4');
  assert.equal(result['SourceMode'], 'symmetric'); assert.equal(result['場数'], 4); assert.equal(result['会計数'], 16);
  assert.equal(result['legacy/default金融会計'], 0); assert.deepEqual(result['旧市場golden'], { '対象外': true, '対照会計': 0 });
  assert.equal(result['前後不変'], true); assert.deepEqual(result['入力codeSHA256前'], result['入力codeSHA256後']);
  assert.deepEqual(Object.keys(result['集計']).sort(), [...KEYS].sort());
  assert.equal(result['場別'].length, 16);
  const byPair = new Map();
  for (const row of result['場別']) {
    assert.ok(IDS.includes(row.session) && KEYS.includes(row.key));
    const id = `${row.session}/${row.key}`; assert.ok(!byPair.has(id));
    checkRow(row, row.session.endsWith('_Day') ? 76 : 148); byPair.set(id, row);
  }
  const summary = [], flags = [], details = [];
  for (const key of KEYS) {
    const r = result['集計'][key], label = key.match(/C\d_D\d$/)[0].replace('_', ' / ');
    checkRow(r, 448); assert.ok(Number.isFinite(r['保存点連結時価DD']) && r['保存点連結時価DD'] >= 0);
    const scenes = IDS.map(id => byPair.get(`${id}/${key}`)); assert.ok(scenes.every(Boolean));
    for (const field of ['gross_yen', 'fee_yen', 'slip_yen', 'net_yen', 'positive_yen', 'negative_yen', 'positions', 'entry_quantity', 'unit_positive_positions', 'unit_positive_closed_negative', 'unit_positive_closed_negative_yen', 'protection_activated_positions', 'activated_closed_negative', 'activated_closed_negative_yen']) {
      assert.equal(scenes.reduce((sum, x) => sum + x[field], 0), r[field], `${key}/${field}`);
    }
    assert.equal(scenes.reduce((sum, x) => sum + x['活動主表'].active, 0), r['活動主表'].active);
    assert.ok(r.PF === null && r.negative_yen === 0 || typeof r.PF === 'number' && Number.isFinite(r.PF) && Math.abs(r.PF-r.positive_yen/-r.negative_yen) < 1e-9);
    summary.push([label, r.gross_yen, r.fee_yen, r.slip_yen, null, r.positive_yen, r.negative_yen, null, r.positions, r.entry_quantity, r['活動主表'].active, null]);
    flags.push([label, r.unit_positive_positions, r.unit_positive_closed_negative, r.unit_positive_closed_negative_yen,
      r.protection_activated_positions, r.activated_closed_negative, r.activated_closed_negative_yen, r['保存点連結時価DD'],
      r['活動主表'].new, r['活動主表'].hold, r['活動主表'].wait, r['活動主表'].unknown]);
  }
  for (const id of IDS) for (const key of KEYS) {
    const r = byPair.get(`${id}/${key}`), label = key.match(/C\d_D\d$/)[0].replace('_', ' / ');
    details.push([new Date(`${id.slice(0,10)}T00:00:00Z`), id.endsWith('_Day') ? '日中' : '夜間', label,
      r.net_yen, r.positive_yen, r.negative_yen, r.positions, r.entry_quantity, r['活動主表'].new, r['活動主表'].hold, r['活動主表'].denom, null]);
  }
  return { summary, flags, details };
}

/**
 * Rootの金融・保存・Viewer確認後の固定入力だけを開く。
 * @param {string} fixedPath - 事後固定JSON。
 * @param {string} expectedSHA - 同JSONの実SHA。
 * @returns {Promise<Object>} 追記入力と参照指紋。
 */
async function readFixed(fixedPath, expectedSHA) {
  assert.match(expectedSHA ?? '', /^[0-9a-f]{64}$/);
  const file = path.resolve(fixedPath), bytes = await fs.readFile(file); assert.equal(sha(bytes), expectedSHA);
  const fixed = JSON.parse(bytes.toString('utf8').replace(/^\uFEFF/, ''));
  assert.equal(fixed.version, 1); assert.equal(fixed.trial, 105); assert.equal(fixed.fixed, true);
  assert.equal(fixed.result_ready, true); assert.equal(fixed.financial_checked, true); assert.equal(fixed.viewer_checked, true);
  const inputs = new Map([[file, expectedSHA]]), base = path.dirname(file);
  const refs = {};
  for (const name of ['summary', 'financial_completion', 'saved_check', 'viewer_evidence']) refs[name] = await readRef(fixed[name], base, inputs);
  const fin = refs.financial_completion.value, saved = refs.saved_check.value, viewer = refs.viewer_evidence.value;
  assert.equal(fin.trial, 105); assert.equal(fin.stage, 'full4'); assert.equal(fin.success, true);
  assert.equal(fin.sessions, 4); assert.equal(fin.books, 16); assert.equal(fin.books_per_scene, 4);
  assert.equal(fin.old103_market_golden, false); assert.equal(fin.legacy_books, 0); assert.equal(fin.default_books, 0);
  assert.equal(fin.unchanged, true); assert.deepEqual(fin.before, fin.after);
  assert.equal(saved['成功'], true); assert.equal(saved['会計'], 16); assert.equal(saved['不一致数'], 0);
  assert.equal(saved['completionSHA256'], refs.financial_completion.sha256);
  assert.equal(saved['出力SHA256']['結果.json'], refs.summary.sha256);
  assert.ok(viewer['成功'] === true || viewer.success === true);
  assert.ok(typeof fixed.viewer_scope === 'string' && fixed.viewer_scope.trim());
  assert.equal(refs.summary.value['completionSHA256'], refs.financial_completion.sha256);
  const tables = prepareTables(refs.summary.value);
  return { refs, inputs, fixed, tables };
}

/**
 * 旧4タブの既存領域と図表参照を公開APIから記録する。
 * @param {Object} book - importしたArtifact Workbook。
 * @returns {Array<Object>} 値・数式・図表参照のスナップショット。
 */
function snapshot(book) {
  return SHEETS.map((name, i) => {
    const sheet = book.worksheets.getItem(name), range = PRESERVED[i];
    return { name, range, values: sheet.getRange(range).values, formulas: sheet.getRange(range).formulas,
      charts: sheet.charts.items.map(c => ({ type: c.type, title: c.title.text,
        series: c.series.items.map(v => ({ formula: v.formula, categoryFormula: v.categoryFormula })) })) };
  });
}

/**
 * 旧領域が変更されていないことを確認する。
 * @param {Object} book - 現在又は保存再読したWorkbook。
 * @param {Array<Object>} previous - 変更前の記録。
 * @returns {void} 値/式/図参照に差があれば拒否する。
 */
function unchanged(book, previous) {
  assert.deepEqual(snapshot(book), previous);
}

/**
 * 現ブックの104末尾を読取専用で確認する。
 * @returns {Promise<void>} PNG/小metadataだけを保存し、xlsxはexportしない。
 */
async function review() {
  const before = await fs.readFile(BOOK); assert.equal(sha(before), BOOK_SHA);
  const book = await SpreadsheetFile.importXlsx(await FileBlob.load(BOOK));
  const prior = snapshot(book);
  const image = await book.render({ sheetName: TARGET_SHEET, range: 'A64:L84', scale: 1.05, format: 'png' });
  await fs.writeFile(path.join(WORK, '現在の104末尾.png'), new Uint8Array(await image.arrayBuffer()));
  const inspected = await book.inspect({ kind: 'table', range: `${TARGET_SHEET}!A64:L84`, include: 'values,formulas', tableMaxRows: 21, tableMaxCols: 12, maxChars: 8500 });
  await fs.writeFile(path.join(WORK, '現在の104末尾.ndjson'), inspected.ndjson);
  assert.ok(book.worksheets.getItem(TARGET_SHEET).getRange(TARGET).values.flat().every(x => x == null || x === ''));
  unchanged(book, prior);
  assert.equal(sha(await fs.readFile(BOOK)), BOOK_SHA);
  const proof = { '成功': true, '読取専用': true, 'ブックSHA256': BOOK_SHA, '旧4tab': prior.map(x => ({ name: x.name, range: x.range })),
    '104追記保持': 'A64:L77', '105予約範囲': TARGET, '予定領域空': true, 'xlsx編集/export/marker': 0, '105実結果読取': 0 };
  await fs.writeFile(path.join(WORK, '読取確認.json'), JSON.stringify(proof, null, 2));
  console.log(JSON.stringify(proof));
}

/**
 * 将来のRoot実行で105を追記する。直前のskill marker実行はRootが担当する。
 * @param {string} fixedPath - 金融/保存/Viewer確認後のRoot固定JSON。
 * @param {string} fixedSHA - そのSHA256。
 * @returns {Promise<void>} 同一xlsxへ限定追記し、全旧内容を後段QAへ結ぶ。
 */
async function append(fixedPath, fixedSHA) {
  const input = await readFixed(fixedPath, fixedSHA);
  const original = await fs.readFile(BOOK); assert.equal(sha(original), BOOK_SHA);
  const book = await SpreadsheetFile.importXlsx(await FileBlob.load(BOOK));
  const previous = snapshot(book), sheet = book.worksheets.getItem(TARGET_SHEET);
  assert.ok(sheet.getRange(TARGET).values.flat().every(x => x == null || x === ''));
  await fs.writeFile(path.join(WORK, '105追記前.xlsx'), original, { flag: 'wx' });
  // ----------------------------------------
  // 既存の列幅/行/4タブへ触れず、空いていた下部範囲だけを書く。
  sheet.getRange(TARGET).format.font = { name: 'Arial', size: 10, color: '#202A35' };
  sheet.getRange(TARGET).format.verticalAlignment = 'center';
  for (const [row, text] of [[79, '105 固定後4場の追加確認'], [80, '11/5–6の4場。symmetric Source・B5Q/LD10の四感度。旧54場の合計とは分けます。']]) {
    sheet.getRange(`A${row}:L${row}`).merge(); sheet.getRange(`A${row}`).values = [[text]];
    sheet.getRange(`A${row}:L${row}`).format.rowHeight = row === 79 ? 30 : 26;
  }
  sheet.getRange('A79').format.font = { name: 'Arial', size: 14, bold: true, color: '#23354D' };
  const headers = {
    82: ['費用 / 遅延', '粗額（円）', '手数料（円）', '仮定滑り（円）', '純損益（円）', '全正額（円）', '全負額（円）', '取引PF', '玉数', '取得枚数', '参加枠', '参加率 / 448'],
    88: ['費用 / 遅延', 'u正益玉', 'u後赤字玉', 'u後赤字額', 'LD起動玉', 'LD後赤字玉', 'LD後赤字額', '保存点DD', '実新規枠', '保有枠', '待機枠', '不能枠'],
    94: ['開始日', '場種', '費用 / 遅延', '純損益（円）', '全正額（円）', '全負額（円）', '玉数', '取得枚数', '実新規枠', '保有枠', '対象枠', '参加率'],
  };
  for (const [row, labels] of Object.entries(headers)) {
    const range = sheet.getRange(`A${row}:L${row}`); range.values = [labels];
    range.format.fill = '#23354D'; range.format.font = { name: 'Arial', size: 10, bold: true, color: '#FFFFFF' };
    range.format.horizontalAlignment = 'center'; range.format.wrapText = true; range.format.rowHeight = 42;
  }
  sheet.getRange('A83:L86').values = input.tables.summary;
  sheet.getRange('A89:L92').values = input.tables.flags;
  sheet.getRange('A95:L110').values = input.tables.details;
  for (const range of ['B83:L86', 'B89:L92', 'D95:L110']) sheet.getRange(range).format.horizontalAlignment = 'right';
  const number = '#,##0.0;[Red](#,##0.0);0';
  sheet.getRange('B83:G86').setNumberFormat(number); sheet.getRange('H83:H86').setNumberFormat('0.00');
  sheet.getRange('I83:K86').setNumberFormat('#,##0'); sheet.getRange('L83:L86').setNumberFormat('0.00%');
  sheet.getRange('B89:C92').setNumberFormat('#,##0'); sheet.getRange('D89:D92').setNumberFormat(number);
  sheet.getRange('E89:F92').setNumberFormat('#,##0'); sheet.getRange('G89:H92').setNumberFormat(number); sheet.getRange('I89:L92').setNumberFormat('#,##0');
  sheet.getRange('A95:A110').setNumberFormat('yyyy-mm-dd'); sheet.getRange('D95:F110').setNumberFormat(number);
  sheet.getRange('G95:K110').setNumberFormat('#,##0'); sheet.getRange('L95:L110').setNumberFormat('0.00%');
  for (const range of ['A83:L86', 'A89:L92', 'A95:L110']) sheet.getRange(range).format.rowHeight = 26;
  for (let i = 0; i < 4; i++) {
    const row = 83 + i;
    sheet.getRange(`E${row}`).formulas = [[`=B${row}-C${row}-D${row}`]];
    sheet.getRange(`H${row}`).formulas = [[`=IF(G${row}=0,"未定義",F${row}/-G${row})`]];
    sheet.getRange(`L${row}`).formulas = [[`=K${row}/448`]];
  }
  for (let row = 95; row <= 110; row++) sheet.getRange(`L${row}`).formulas = [[`=SUM(I${row}:J${row})/K${row}`]];
  const notes = {
    112: '4場・開始日2日の小標本。四感度や複数玉を独立市場例として加算せず、旧54場の利益とも合算しません。',
    113: 'Sourceのlegacy/default相互QAとLD10成績は別。旧93・旧103の市場goldenはこの4場では対象外です。',
    114: '主分母448＝日中152＋夜間296。開始30分後〜Force未満、US静観も分母へ残す。実新規と当時保有の和集合。',
    115: 'u正益後とLD10起動後の赤字は別旗。名目建値床は費用後黒字を保証せず、DDも最終純損益と分けます。',
    116: '11月US開始23:30、Actual静観23:30〜翌00:00。Source P締切23:15、U開始23:45。C5は動的別運転です。',
    117: `Viewer価格はNK共有1場/work生成3場。確認範囲：${input.fixed.viewer_scope}`,
    118: `正本：${path.relative(ROOT, input.refs.summary.path).replaceAll('\\', '/')}`,
    119: `正本SHA256：${input.refs.summary.sha256}`,
    120: '未知期間の安定性・実mini約定は未証明。機会損失・退出後仮想利益・MFE回収率は算出していません。',
    121: '参加の最低25%と目標50%は、全体だけでなく各場・日夜も別に確認します。保存形式とViewer API照合は別証拠です。',
  };
  for (const [row, text] of Object.entries(notes)) {
    sheet.getRange(`A${row}:L${row}`).merge(); sheet.getRange(`A${row}`).values = [[text]];
    sheet.getRange(`A${row}:L${row}`).format.wrapText = true; sheet.getRange(`A${row}:L${row}`).format.rowHeight = 30;
  }
  // ----------------------------------------
  // 小さな入力反応を新領域だけで確認し、必ず元値へ復元する。
  const old = sheet.getRange('B83').values[0][0], oldNet = input.refs.summary.value['集計'][KEYS[0]].net_yen;
  sheet.getRange('B83').values = [[old + 1]]; assert.equal(sheet.getRange('E83').values[0][0], oldNet + 1);
  sheet.getRange('B83').values = [[old]];
  book.recalculate(); unchanged(book, previous);
  for (let i = 0; i < 4; i++) {
    const row = 83 + i, value = input.refs.summary.value['集計'][KEYS[i]];
    assert.equal(sheet.getRange(`E${row}`).values[0][0], value.net_yen);
    assert.equal(sheet.getRange(`H${row}`).values[0][0], value.PF === null ? '未定義' : value.PF);
    assert.equal(sheet.getRange(`L${row}`).values[0][0], value['活動主表'].active / 448);
  }
  for (const [range, name] of [['A79:L92', '105四感度.png'], ['A94:L110', '105四場明細.png'], ['A112:L121', '105注記.png']]) {
    const image = await book.render({ sheetName: TARGET_SHEET, range, scale: 1.15, format: 'png' });
    await fs.writeFile(path.join(WORK, name), new Uint8Array(await image.arrayBuffer()));
  }
  const errors = await book.inspect({ kind: 'match', searchTerm: '#REF!|#DIV/0!|#VALUE!|#NAME\\?|#N/A|#NUM!|#NULL!|#SPILL!|#CALC!', options: { useRegex: true, maxResults: 100 }, maxChars: 5000 });
  await fs.writeFile(path.join(WORK, '105式検査.ndjson'), errors.ndjson);
  for (const [file, expected] of input.inputs) assert.equal(sha(await fs.readFile(file)), expected);
  await (await SpreadsheetFile.exportXlsx(book)).save(BOOK);
  const saved = await SpreadsheetFile.importXlsx(await FileBlob.load(BOOK)); unchanged(saved, previous);
  const proof = { '成功': true, '入力ブックSHA256': BOOK_SHA, '最終ブックSHA256': sha(await fs.readFile(BOOK)),
    '追記範囲': `${TARGET_SHEET}!${TARGET}`, '旧4tab既存値/式/図参照保持': true, '書式/全旧セルOOXML比較': '別の読戻しQAで必須',
    '入力SHA256': Object.fromEntries(input.inputs), '金融/Source/API再実行': 0, 'Excel本体実行': false };
  await fs.writeFile(path.join(WORK, '105追記の確認.json'), JSON.stringify(proof, null, 2));
  console.log(JSON.stringify(proof));
}

// ----------------------------------------
// 本番追記は明示オプションとRoot事後固定が揃う時だけ。
if (process.argv.includes('--review')) await review();
else if (process.argv.includes('--append')) {
  const i = process.argv.indexOf('--append'); await append(process.argv[i + 1], process.argv[i + 2]);
} else if (process.argv.includes('--self-test')) {
  assert.equal(BOOK_SHA.length, 64);
  console.log(JSON.stringify({ '純コード読込': true, 'xlsx作成/編集/marker': 0 }));
}
