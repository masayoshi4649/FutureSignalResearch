# 固定後4場のSource再形成の準備

105のSource外周を104版2から最小派生した非市場停止版です。対象は2026-11-05 Day/Night・11-06 Day/Nightの4場、順序は日付ごとDay→Nightです。現段階で新4場の原板・CSV・価格・Source結果本文は開いていません。Rootによる入力予約・品質確認・条件固定後にだけ市場CLIを使います。

## 再用と変更

- `record.go` は104版2（停止ea208380…）とbyte同体です。全Step/Force、空通知、micro/miniの全active method順、Scalar11・Observation SHA・Targets・Before・Closes・取消・配賦・物理SourceLineを保持します。
- `ReplayWithFactory` / `ReplayPrepared`、InputManifest reader、Features、Sourceprofile、range_side、数量・返済は既存停止moduleの直接importです。計算・配送本文の複写や改変はありません。
- 新外周だけをtrial105・正確な4場・first2/full4へ変更しました。旧93golden参照は存在しません。全caseの `old93_full_match` はfalseです。
- 場ごとの新legacy/defaultについて、全ReplayResultの保存bytes、全Recordのgzip bytes、解凍JSONL全bytes（SHAと長さ）を除外なしで比較します。JSONLは逐次解凍し、全記録をRAMへ保持しません。symmetricはこの同体成功の対象外です。相互同値は旧93golden、技法の収益、LD10の成績を証明しません。
- 当CLI実source5本（main/record/相互照合/go.mod/go.sum）、生成口・再生口停止所有集合、台帳の純戦略path/SHAを固定codeへ含めます。Rootが最終条件へ完全な依存集合と実行物を固定します。

## 条件と出力

条件JSONは `version=1, trial=105, fixed=true, input_manifest, generator_stop, replay_stop, binary, code_sha256, scenes, modes` です。`scenes` は `{session}` 4件、`modes` は `[legacy,default,symmetric]` の固定順です。FileRefは `{path,sha256}`、条件のRefは条件dirname基準、codeはrepo基準です。InputManifestの `source_root` / `純戦略repo` は台帳dirname基準へ解決し、各6入力のpathはsource_root基準です。共有親rootと元/生成ファイルの相対参照を受けられます。由来・品質の別資料をManifestの未知fieldとして混入しません。

`first2` は11/5 Day/Nightの2場×3mode、`full4` は同じ4場条件・code・binaryに結んだfirst2成功と6出力指紋を必須とします。新規出力directoryとO_EXCLで既存先を拒否します。失敗を成功へ補完せず、生成途中の結果も不成立として保持します。

完了topは `version/trial/stage/success/condition_sha256/sessions/cases/before/after/unchanged/source_reformed/financial105_executed/legacy_default_matches/error?` です。`financial105_executed=false` はLD10再生未実施を表します。SourceA自身の連続会計は各ReplayResultへ残ります。

各caseは `session/mode/result/records/counts/old93_full_match/error?` です。各相互証拠は `session/success/legacy_result/default_result/legacy_records/default_records/replay_result_bytes_equal/records_gzip_bytes_equal/records_jsonl_bytes_equal/jsonl_sha256/jsonl_bytes` です。全成果Refは絶対pathです。Source4場の6入力は本実行時にSHAを確認し、処理後にも同じ固定入力・code・binary・先行成果を再確認します。

## 実行口

```powershell
& 'work/105四場Sourceの再形成/検査/105Source.exe' --condition <Root固定条件.json> --condition-sha <SHA256> --stage first2 --out <新規first2>
& 'work/105四場Sourceの再形成/検査/105Source.exe' --condition <同じRoot固定条件.json> --condition-sha <同じSHA256> --stage full4 --first2 <first2/完了.json> --first2-sha <SHA256> --out <新規full4>
```

`条件の雛形.json` はfixed=falseで、入力・binary指紋を空欄にしています。実行許可ではありません。現在のコード試験は `go test -json ./...`、`go vet ./...`、`go build -o 検査/105Source.exe .` です。

## 人工と限界

旧104の公開型codec/記録人工を再用し、新しい4場集合・先行6case集合・相互証拠・SHA/本文破損・純戦略固定漏れ・既存先拒否を狭く確認します。再生人工は手製の二市場・確定足・timerでStep/Forceは非0、Source新規/Fillは0です。非0の自然Source形成や4場品質、LD10利益は未計測です。公開型の全欄を記録しますが、真の受信時計は旧Readerから得られません（Time/ReceivedはCurrentPriceTimeの代理）。

旧104v2、生成口、再生口、純戦略43および旧103/104の正式物は変更しません。Raw/CSV/new4本文・市場金融・Sourceの実運転はRootの後段です。
