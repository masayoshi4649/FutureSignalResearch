"""非市場試験・由来・依存の前後指紋を105の新規workへ保存する。"""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
OLD = BASE.parent / "104Source再形成CLIの準備_版2"
CHECK = BASE / "検査"


def digest(path):
    """
    機能: 明示したコード又はmetadataのSHA256を求める。
    引数: path(Path)は価格本文を含まない固定参照。
    返り値: strは小文字SHA256。
    """
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1048576), b""):
            h.update(block)
    return h.hexdigest()


def write(path, value):
    """
    機能: 新規の証拠JSONだけを保存する。
    引数: path(Path)、value(dict)は保存先と公開証拠。
    返り値: None。既存証拠は上書きしない。
    """
    with path.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, ensure_ascii=False, indent=2)
        f.write("\n")


def label(path):
    """
    機能: repo内は相対path、repo外は絶対pathへ表示する。
    引数: path(Path)は正規化した参照。
    返り値: strは再読できるpath。
    """
    try:
        return path.relative_to(ROOT).as_posix()
    except ValueError:
        return str(path)


def load(path):
    """
    機能: 停止又は台帳metadataだけを読む。
    引数: path(Path)は許可したJSON。
    返り値: dictはmetadata。台帳内の価格参照は開かない。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def run(args):
    """
    機能: 非市場のGo検査を実行して終了値と標準出力を保存する。
    引数: args(list[str])はGoコマンド。
    返り値: dictは終了値と出力。失敗時は例外。
    """
    r = subprocess.run(args, cwd=BASE, capture_output=True, text=True, encoding="utf-8", errors="strict")
    v = {"command": args, "exit_code": r.returncode, "stdout": r.stdout, "stderr": r.stderr}
    if r.returncode:
        raise RuntimeError(v)
    return v


def main():
    """
    機能: 停止元同体・人工・vet/build・コード前後不変の新停止を保存する。
    引数: なし。
    返り値: None。SourceCLI/Raw/CSV/新4場の実運転は行わない。
    """
    CHECK.mkdir(exist_ok=True)
    dependencies = {}
    stops = [OLD / "停止.json", BASE.parent / "104対称Sourceの生成口準備/停止.json", BASE.parent / "104Source再生の接続準備/停止.json"]
    for p in stops:
        dependencies[label(p)] = digest(p)
        data = load(p)
        for name, expected in data["所有SHA256"].items():
            f = (ROOT / name).resolve()
            got = digest(f)
            assert got == expected, (name, got, expected)
            dependencies[label(f)] = got
    # ----------------------------------------
    # 旧入力台帳の価格参照を開かず、純戦略43のコード指紋だけを検査する。
    manifest = ROOT / "study/00080_FAR後期三手法の15分移植と利益保護/入力台帳.json"
    m = load(manifest)
    dependencies[label(manifest)] = digest(manifest)
    assert len(m["純戦略SHA256"]) == 43
    for name, expected in m["純戦略SHA256"].items():
        f = Path(m["純戦略repo"]) / name
        got = digest(f)
        assert got == expected, name
        dependencies[label(f)] = got
    for folder in ["00103_元の多玉と数量を保つ一定利益後の追尾", "00104_重複時の方向裁定と元Sourceの再形成"]:
        f = ROOT / "study" / folder / "完了記録.json"
        dependencies[label(f)] = digest(f)
    # コンパイル対象の外部moduleもコードだけを指紋化する。
    dirs = run(["go", "list", "-deps", "-f", "{{if not .Standard}}{{.Dir}}{{end}}", "./..."])["stdout"].splitlines()
    for directory in dirs:
        d = Path(directory)
        if d == BASE:
            continue
        for f in sorted(d.glob("*.go")):
            dependencies[label(f)] = digest(f)
        for name in ["go.mod", "go.sum"]:
            f = d / name
            if f.is_file():
                dependencies[label(f)] = digest(f)
    before = dict(dependencies)
    write(BASE / "依存の前指紋.json", before)
    # ----------------------------------------
    # 派生した外周以外の公開Recorder・Source再生はbyte同体/直接参照。
    mapping = {}
    for name in ["record.go", "main.go", "record_test.go", "guard_test.go", "go.mod", "go.sum"]:
        old, new = OLD / name, BASE / name
        mapping[name] = {"元path": label(old), "元SHA256": digest(old), "新path": label(new), "新SHA256": digest(new), "byte同体": old.read_bytes() == new.read_bytes()}
    assert mapping["record.go"]["byte同体"] and mapping["go.sum"]["byte同体"]
    assert (OLD / "go.mod").read_text(encoding="utf-8").replace("/minisourcecli104", "/minisourcecli105") == (BASE / "go.mod").read_text(encoding="utf-8")
    patch = []
    for name in ["main.go", "record_test.go", "guard_test.go", "go.mod"]:
        patch.extend(difflib.unified_diff((OLD / name).read_text(encoding="utf-8").splitlines(True), (BASE / name).read_text(encoding="utf-8").splitlines(True), fromfile=label(OLD / name), tofile=label(BASE / name)))
    (BASE / "104版2との差分.patch").write_text("".join(patch), encoding="utf-8", newline="\n")
    write(BASE / "由来と差分.json", {"成功": True, "元停止": {"path": label(stops[0]), "SHA256": digest(stops[0])}, "対応": mapping, "新規": ["相互照合.go", "相互照合_test.go"], "Source計算変更": False, "Recorder同体": True, "変更範囲": ["trial105/4ID/first2→full4", "旧93golden参照削除", "新legacy/defaultの全Result/全Record相互同体", "台帳純戦略code包含", "実source5pathの固定包含"], "直接importの生成口停止SHA256": digest(stops[1]), "直接importの再生口停止SHA256": digest(stops[2])})
    # ----------------------------------------
    # 既済み最終Go testの全出力を保持し、同じcodeにvet/buildだけを実施する。
    testpath = BASE / "検査_test.tmp"
    events = [json.loads(s) for s in testpath.read_text(encoding="utf-8-sig").splitlines() if s]
    assert any(e.get("Action") == "pass" and "Test" not in e for e in events)
    assert not any(e.get("Action") == "fail" for e in events)
    testlog = CHECK / "test.jsonl"
    assert not testlog.exists()
    testpath.rename(testlog)
    testnames = [e["Test"] for e in events if e.get("Action") == "pass" and "Test" in e]
    vet = run(["go", "vet", "./..."])
    exe = CHECK / "105Source.exe"
    build = run(["go", "build", "-o", str(exe), "."])
    version = run(["go", "version"])["stdout"].strip()
    after = {}
    for name in before:
        p = Path(name)
        if not p.is_absolute():
            p = ROOT / p
        after[name] = digest(p)
    assert before == after
    artificial = {"成功": True, "Go版": version, "test": {"exit_code": 0, "path": label(testlog), "SHA256": digest(testlog), "top成功": sum("/" not in t for t in testnames), "小試験込成功": len(testnames), "成功試験": testnames}, "vet": vet, "build": build, "SourceStep/Force人工": "Day/Nightの手製二市場・確定足、Step/Force非0、Source新規/Fill0", "新4場実データ読取": 0, "Raw/CSV読取": 0, "LD10金融実行": 0, "前後不変": True}
    write(CHECK / "人工確認.json", artificial)
    write(BASE / "依存の前後照合.json", {"成功": True, "code/metadata参照数": len(before), "前": before, "後": after, "前後不変": before == after, "純戦略43差": 0, "旧103/104閉鎖": "完了記録のSHAのみ前後照合。全市場成果物本文の再読検査は実施0"})
    template = {"version": 1, "trial": 105, "fixed": False, "input_manifest": {"path": "<Root固定入力台帳>", "sha256": ""}, "generator_stop": {"path": str(stops[1]), "sha256": digest(stops[1])}, "replay_stop": {"path": str(stops[2]), "sha256": digest(stops[2])}, "binary": {"path": str(exe), "sha256": digest(exe)}, "code_sha256": {}, "scenes": [{"session": d + "_" + kind} for d in ["2026-11-05", "2026-11-06"] for kind in ["Day", "Night"]], "modes": ["legacy", "default", "symmetric"]}
    write(BASE / "条件の雛形.json", template)
    excluded = {"停止.json"}
    own = {label(p): digest(p) for p in sorted(BASE.iterdir()) if p.is_file() and p.name not in excluded}
    stop = {"成功": True, "module": "github.com/masayoshi4649/SessionTradeExecuter/minisourcecli105", "所有SHA256": own, "元停止": {"path": label(stops[0]), "SHA256": digest(stops[0])}, "参照停止": {label(p): digest(p) for p in stops[1:]}, "依存指紋": {"path": label(BASE / "依存の前指紋.json"), "SHA256": digest(BASE / "依存の前指紋.json")}, "exe": {"path": label(exe), "SHA256": digest(exe)}, "人工確認": {"path": label(CHECK / "人工確認.json"), "SHA256": digest(CHECK / "人工確認.json")}, "test/vet/build": {"test": 0, "vet": 0, "build": 0}, "前後不変": True, "Recorder同体": True, "Source再生": "旧停止moduleを直接import、本文複写/変更0", "旧93golden": "新4場なし。old93_full_matchは常にfalse", "legacy/default相互同体": "全ReplayResult保存bytes/全Record gzip bytes/解凍JSONL bytes、除外0", "symmetric同体主張": False, "市場Source実行": 0, "LD10金融実行": 0, "Raw/CSV/新4場本文読取": 0, "未実施": ["Root入力予約/品質確認/条件fixedtrue", "first2実Source形成", "full4実Source形成", "105LD10会計"]}
    write(BASE / "停止.json", stop)
    print(json.dumps({"停止path": label(BASE / "停止.json"), "停止SHA256": digest(BASE / "停止.json"), "exeSHA256": digest(exe), "top": artificial["test"]["top成功"], "小試験": len(testnames), "依存": len(before)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
