"""停止済み105報告へ実Viewerの限定証拠と全四感度の結論だけを補足する。"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import re
from pathlib import Path

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[1]
FORMAL = ROOT / 'study/00105_固定SourceとLD10の四場追加確認'
BASE = ROOT / 'work/105報告の準備/報告を差し替える.py'
BASE_SHA = 'e09539c38606e999f2e7278c3b078dcb470f2ee334ab811b21cb921fbc065b15'
FIXED_SHA = '9ff644b38896393de98b93c38710f9cb1522beaf0004bc3b358c512d19c91a0b'
XLSX_FIXED_SHA = '6607d0d41a99bdd51a1b6203209fcbaa97deba1b59e4038dcf183e3b3d152325'
NAMES = ('README.md', '設定と結果.md', '時計仕様補足.md')


def sha(path: Path) -> str:
    """
    機能: 明示した小入力・文書・コードの内容指紋を計算する。
    引数: path (Path) は対象ファイル。
    返り値: str はSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def finish() -> tuple[dict[str, bytes], dict]:
    """
    機能: 既存停止helperの算術検査と原文保持を再用して実報告を組み立てる。
    引数: なし。WORKの二つの事後固定JSONのみを参照する。
    返り値: tuple[dict[str,bytes],dict] は文書三本と生成証拠。
    """
    assert sha(BASE) == BASE_SHA
    spec = importlib.util.spec_from_file_location('report105_stopped', BASE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    result, inputs = module.prepare(WORK / '報告固定.json', FIXED_SHA)
    assert sha(WORK / 'xlsx固定.json') == XLSX_FIXED_SHA
    xfixed = json.loads((WORK / 'xlsx固定.json').read_text(encoding='utf-8'))
    viewer_path = Path(xfixed['viewer_evidence']['path'])
    assert sha(viewer_path) == xfixed['viewer_evidence']['sha256']
    viewer = json.loads(viewer_path.read_text(encoding='utf-8-sig'))
    assert viewer['成功'] is True and viewer['前後不変'] is True
    assert viewer['一覧資源数'] == 16 and viewer['実GET資源'] == len(viewer['details']) == 4
    expected = {
        '105_LD10_B5Q_P0_C0_D0_2026-11-05_Day',
        '105_LD10_B5Q_P0_C0_D1_2026-11-05_Night',
        '105_LD10_B5Q_P0_C5_D0_2026-11-06_Day',
        '105_LD10_B5Q_P0_C5_D1_2026-11-06_Night',
    }
    assert {d['id'] for d in viewer['details']} == expected
    assert result['completionSHA256'] in viewer['入力コードSHA256'].values()
    assert xfixed['summary']['sha256'] in viewer['入力コードSHA256'].values()
    assert xfixed['saved_check']['sha256'] in viewer['入力コードSHA256'].values()
    inputs[str(viewer_path)] = sha(viewer_path)
    inputs[str(WORK / 'xlsx固定.json')] = XLSX_FIXED_SHA
    for key, total in result['集計'].items():
        assert total['net_yen'] < 0 and total['PF'] < 1
        assert total['活動主表']['参加率'] >= .25 and total['活動主表']['参加率'] < .5
    originals = {n: (BASE.parent / '原文' / n).read_bytes() for n in NAMES}
    for n, body in originals.items():
        assert body == (FORMAL / '主金融前仕様' / n).read_bytes()
    readme, settings = module.render(originals['README.md'], originals['設定と結果.md'], result)
    lead = ('**固定後4場は四感度とも費用後赤字。** C0/D0 −52,854円、C0/D1 −18,700円、'
            'C5/D0 −154,854円、C5/D1 −118,700円。先頭2場の黒字だけを選ばず、全4場を結果とする。'
            '主参加は164/448又は163/448（36.61%又は36.38%）で最低25%は達成、目標50%は未達。'
            '**実採用なし・研究目標未達。**')
    viewer_text = ('本helperによる通信は0。Rootの別証拠[Viewer代表4資源](検査/主金融全4場/Viewer代表4資源.json)で'
                   '一覧16読込と事前選択した4場・四感度の代表4資源の実GETを確認した。全16資源の表示照合ではない。')
    old_viewer = '本helperは通信しない。API成功は未確認のまま、将来の別証拠へ結ぶ。'
    for label, text in [('README', readme), ('設定', settings)]:
        assert text.count(old_viewer) == 1, label
    readme = readme.replace('**固定後4場：金融/保存の完了証拠を結合した結果。**', lead)
    settings = settings.replace('**固定後4場：金融/保存の完了証拠を結合した結果。**', lead)
    readme = readme.replace(old_viewer, viewer_text)
    settings = settings.replace(old_viewer, viewer_text)
    for name, text in [('README.md', readme), ('設定と結果.md', settings)]:
        text = text.replace('原計画の同bytesは `原計画/` に保存。', '主金融前の原計画は[主金融前仕様](主金融前仕様/README.md)に同bytesで保存。')
        if name == 'README.md':
            readme = text
        else:
            settings = text
    links = ('\n## 確定証拠\n\n'
             '[Source全4場完了](検査/Source全4場/完了.json)、'
             '[金融全4場完了](検査/主金融全4場/金融完了.json)、'
             '[保存結果](成果物_主B/結果.json)、[保存会計確認](成果物_主B/保存会計の確認.json)、'
             '[Viewer代表4資源](検査/主金融全4場/Viewer代表4資源.json)、'
             '[報告生成](検査/主金融全4場/報告生成.json)。'
             '金融/保存/表示の検査成功は経済成績の成功や未知期間の安定性の証明ではない。\n')
    readme += links
    clock = originals['時計仕様補足.md'].decode('utf-8-sig')
    clock += ('\n## 実行後の確認\n\n'
              '上記はSource先頭2場再生中・主金融実行前に固定した訂正であり、今回の損益で時計を変更していない。'
              '全4場Source/金融/保存が完了し、主448枠にはActual静観12枠を含む。'
              '日中152枠、夜間296枠、各感度の実参加164又は163枠。'
              '全四感度は費用後赤字で、最低参加25%と50%目標を区別し、実採用・研究目標達成とはしない。'
              '主金融前の同bytes原本は[主金融前仕様](主金融前仕様/時計仕様補足.md)へ保存している。\n\n'
              '[金融完了](検査/主金融全4場/金融完了.json)・[保存結果](成果物_主B/結果.json)・'
              '[Viewer代表4](検査/主金融全4場/Viewer代表4資源.json)を参照。'
              'Viewerは一覧16と代表4資源の確認であり全16表示ではない。\n')
    output = {'README.md': readme.encode('utf-8'), '設定と結果.md': settings.encode('utf-8'), '時計仕様補足.md': clock.encode('utf-8')}
    # ----------------------------------------
    # 元の設定と尺度は表示更新から独立に固定する。
    old_s = originals['設定と結果.md'].decode('utf-8-sig')
    for pattern, count in [(r'^\| (?:I|C|P|V|B|X|M|E)\d{2} \|', 55), (r'^\| (?:S|K)\d{2} \|', 18)]:
        before = [s for s in old_s.splitlines() if re.match(pattern, s)]
        after = [s for s in settings.splitlines() if re.match(pattern, s)]
        assert before == after and len(after) == count
    assert len(re.findall(r'^\| R\d{2} \|', settings, re.M)) == 7
    proof = {'成功': True, 'scope': '全4場16会計の保存小集計と代表Viewer4証拠の報告',
             '停止helperSHA256': BASE_SHA, '補足helperSHA256': sha(Path(__file__)),
             '入力SHA256': inputs, '原計画SHA256': {n: hashlib.sha256(b).hexdigest() for n, b in originals.items()},
             '55x9/18設定/7評価保持': True, '全四感度赤字': True,
             '最低25達成': True, '目標50未達': True, '研究目標達成': False, '実採用': False,
             '実Viewer確認': {'一覧': 16, '代表GET': 4, '全16表示': False},
             '出力SHA256': {n: hashlib.sha256(b).hexdigest() for n, b in output.items()},
             '金融/Source/Raw/Native/API再実行': 0}
    return output, proof


def main() -> None:
    """
    機能: 新規草案を生成し、全文一致後だけ許可済みライブ三文書をbytes反映する。
    引数: --check/--apply (bool) は新規草案との照合又は正式三文書への反映。
    返り値: None。固定計画・結果・コードを変更しない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument('--check', action='store_true')
    parser.add_argument('--apply', action='store_true')
    args = parser.parse_args()
    output, proof = finish()
    draft = WORK / '最終報告案'
    if args.check or args.apply:
        assert all((draft / n).read_bytes() == b for n, b in output.items())
    else:
        draft.mkdir(exist_ok=False)
        for name, body in output.items():
            (draft / name).write_bytes(body)
    protected = json.loads((WORK / '保護対象の前指紋.json').read_text(encoding='utf-8'))
    assert all(sha(Path(p)) == s for p, s in protected.items())
    if args.apply:
        for name, body in output.items():
            (FORMAL / name).write_bytes(body)
        assert all((FORMAL / n).read_bytes() == b for n, b in output.items())
        assert all(sha(Path(p)) == s for p, s in protected.items())
        proof['保護対象不変数'] = len(protected)
        proof['正式三文書bytes一致'] = True
        dest = FORMAL / '検査/主金融全4場/報告生成.json'
        with dest.open('x', encoding='utf-8') as stream:
            json.dump(proof, stream, ensure_ascii=False, indent=2)
            stream.write('\n')
    with (WORK / ('正式反映の確認.json' if args.apply else '報告案の確認.json')).open('w', encoding='utf-8') as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'成功': True, 'check': args.check, 'apply': args.apply, '出力SHA256': proof['出力SHA256']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
