package followup

import (
	"reflect"
	"testing"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	replay "github.com/masayoshi4649/SessionTradeExecuter/minisourcereplay104"
	binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
)

// TestClockCarrierOnly は候補4場と時計・分母を価格なしで検査します。
//
// 引数: t(*testing.T)は人工器です。
// 返り値: なし。市場ファイルやSourceは開きません。
func TestClockCarrierOnly(t *testing.T) {
	main, secondary := 0, 0
	for _, id := range CandidateIDs() {
		carrier, err := ClockCarrier(id)
		if err != nil {
			t.Fatal(err)
		}
		want := 84
		if carrier.Session.Kind == "Night" {
			want = 156
			if carrier.Session.USOpen-carrier.Session.Start != 23400 {
				t.Fatal("旧US時計と候補11月の時差が不一致")
			}
		}
		if len(carrier.Events) != want || len(carrier.Capabilities) != 0 || reflect.DeepEqual(carrier.Capabilities, tape.Capabilities()) {
			t.Fatal("予定carrierを金融Tapeへ偽装")
		}
		for i, g := range carrier.Events {
			if g.Kind != "grid" || g.Ordinal != i+1 || g.At != carrier.Session.Start+float64(i)*300 || g.Quote != nil || g.Context != nil || len(g.Methods)+len(g.NonEmpty) != 0 {
				t.Fatal("時計carrierへ価格/Sourceが混入")
			}
			if g.At >= carrier.Session.Start+1800 && g.At < carrier.Session.ForceClose {
				main++
			}
			if g.At >= carrier.Session.Start+1800 && g.At < carrier.Session.End-1800 {
				secondary++
			}
		}
	}
	if main != 448 || secondary != 432 {
		t.Fatal("旧分母時計を変更した", main, secondary)
	}
	if _, err := ClockCarrier("2026-09-21_Day"); err == nil {
		t.Fatal("候補外を受理")
	}
}

// TestAllBoardClockAndEOF はTOPIX/Last0の上限もgridへ反映しEOF後を足しません。
//
// 引数: t(*testing.T)は人工器です。
// 返り値: なし。行の値は手製の時計・市場だけです。
func TestAllBoardClockAndEOF(t *testing.T) {
	carrier, _ := ClockCarrier(CandidateIDs()[0])
	s := carrier.Session
	req := continuous.Request{Session: s, Rows: []continuous.Row{
		{Board: strategy.Board{Reference: "TOPIX", Time: s.Start + 600, Received: s.Start + 600, Last: 0}, PhysicalLine: 1},
		{Board: strategy.Board{Reference: "NK225", Time: s.Start + 1, Received: s.Start + 1, Last: 1}, PhysicalLine: 1},
	}}
	grids, err := ObservedGridPrefix(req)
	if err != nil || !reflect.DeepEqual(grids, []float64{s.Start, s.Start + 300, s.Start + 600}) {
		t.Fatal("全board上限/EOF差", err)
	}
	req.Rows = nil
	grids, err = ObservedGridPrefix(req)
	if err != nil || len(grids) != 0 {
		t.Fatal("未観測gridを創作")
	}
	req.Rows = []continuous.Row{{Board: strategy.Board{Reference: "NK225", Time: s.End, Received: s.End}, PhysicalLine: 1}}
	if _, err = ObservedGridPrefix(req); err == nil {
		t.Fatal("場外原行を受理")
	}
}

// TestLegacyDefaultFullValues は新場goldenではない相互全文比較の境界を検査します。
//
// 引数: t(*testing.T)は人工器です。
// 返り値: なし。Sourceを動かさず、公開型の手製値だけを比較します。
func TestLegacyDefaultFullValues(t *testing.T) {
	left := replay.ReplayResult{Session: CandidateIDs()[0], SourceRows: map[string]int{"人工": 1}}
	right := replay.ReplayResult{Session: left.Session, SourceRows: map[string]int{"人工": 1}}
	rows := []binder.SourceRecord{{Ordinal: 1, Session: left.Session, Kind: "quote", Method: "人工", Product: "mini"}}
	if err := CompareLegacyDefault(left, right, rows, rows); err != nil {
		t.Fatal(err)
	}
	right.SourceRows["人工"]++
	if err := CompareLegacyDefault(left, right, rows, rows); err == nil {
		t.Fatal("全Result差を落とした")
	}
	right.SourceRows["人工"]--
	changed := append([]binder.SourceRecord{}, rows...)
	changed[0].Delta.SourceLine = 10
	if err := CompareLegacyDefault(left, right, rows, changed); err == nil {
		t.Fatal("全Recordの出典差を落とした")
	}
	if err := CompareLegacyDefault(left, right, nil, nil); err == nil {
		t.Fatal("記録不足を同値とした")
	}
}
