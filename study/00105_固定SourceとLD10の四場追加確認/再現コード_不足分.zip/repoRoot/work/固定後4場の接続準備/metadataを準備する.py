"""新4場の名前・size・mtimeだけから未固定の接続下書きを作る。"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from datetime import datetime

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
IDS = [f"2026-11-{d:02d}_{kind}" for d in (5, 6) for kind in ("Day", "Night")]


def describe(path: Path) -> dict:
    """
    機能: 入力本文を開かず、存在・ファイル名・size・mtimeを得る。
    引数: path (Path) は明示された候補ファイル。
    返り値: dict はstatだけの値。新入力のSHA256は求めない。
    """
    if not path.is_file():
        return {"path": str(path), "exists": False, "size": None, "mtime_ns": None, "sha256": None}
    s = path.stat()
    return {"path": str(path), "exists": True, "size": s.st_size, "mtime_ns": s.st_mtime_ns, "sha256": None}


def main() -> None:
    """
    機能: 未固定metadataを新規出力し、市場実行口は設けない。
    引数: --data-root/--out (str) はデータ根と新規JSON先。
    返り値: None。Raw/CSVのopen/hash、Source/金融を行わない。
    """
    parser = argparse.ArgumentParser(description="4場のstatだけ。市場実行は不可。")
    parser.add_argument("--data-root", default=str(ROOT.parent / "JP_OSE_Data/future"))
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    out = Path(args.out).resolve()
    if out.exists():
        raise FileExistsError(out)
    base = Path(args.data_root).resolve()
    scenes = []
    for sid in IDS:
        records = []
        for market in ("NK225", "TOPIX"):
            for filename in ("book.jsonl", "book.jsonl.gz", "candle_1min.csv", "candle_5min.csv"):
                records.append({"market": market, "name": filename, **describe(base / market / sid / filename)})
        scenes.append({"session": sid, "contract": None, "stat": records, "入力SHA256未固定": True})
    value = {"version": 1, "fixed": False, "market_ready": False,
             "scope": "4場のstatだけ。実データ未使用候補の監査結論を実価格品質へ拡張しない。",
             "確認日時": datetime.now().astimezone().isoformat(), "sessions": IDS, "scenes": scenes,
             "source_modes": ["legacy", "default", "symmetric"], "採用候補source_mode": "symmetric",
             "金融": {"entry": "B5Q", "policy": "P0", "activation_policy": "LD10", "cost_delay": [[0, 0], [0, 1], [5, 0], [5, 1]]},
             "旧93golden": None, "検査案": "新legacy/default全Result+全Record相互一致。旧93/技法/利益の証明と区別。",
             "新入力本文読取": 0, "新入力内容SHA算出": 0, "市場実行": 0, "新採番": None,
             "未充足": ["Rootの採番/計画/評価範囲固定", "限月と全6入力SHA/品質契約", "gzip入力の準備", "新legacyTapeの全board位相形成とBind", "同条件接続→4場の市場CLI/保存/監査固定"],
             "使用歴監査": {"path": "work/次の固定後確認の使用歴監査/停止.json", "sha256": "05e5575866c7cc4c59379a1085f2ce3ac19d12fdd42e76fc2d0253a7ca86062b"}}
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(value, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"出力": str(out), "場数": 4, "stat数": 32, "本文読取": 0, "SHA256": hashlib.sha256(out.read_bytes()).hexdigest()}, ensure_ascii=False))


if __name__ == "__main__":
    main()
