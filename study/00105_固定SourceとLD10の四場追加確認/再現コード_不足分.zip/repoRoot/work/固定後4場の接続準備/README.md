# 未使用候補4場へ固定symmetric/B5Q/LD10を接続する準備

確認日：2026-11-09。候補は11/5 Day/Night・11/6 Day/Nightの4場。使用歴の限定監査は[停止05e557](../次の固定後確認の使用歴監査/停止.json)。真に未見の完全証明ではない。**正式105・条件fixed=true・市場実行は今回行わない。** 103/104の停止元・条件・稼働プロセスは変更しない。

採用予定はSourceMode=symmetric、GateなしB5Q/P0/LD10、C0/C5×D0/D1の四会計だけ。入口/Sourceの数量・比例返済・quiet・Force・LD10閾値・費用・各側10枚は変えない。新期間を読んで条件を変えず、途中で都合の良い場・費用例へ対象を絞らない。legacy/defaultは実装互換のQAであり採用する経済候補を追加しない。

## 静的に確認した再用境界

| 部品 | 4場へそのまま使える範囲 | そのまま使えない外周 |
| --- | --- | --- |
| `104Source再生の接続準備` | InputManifest/ValidateManifestは日付・入力6参照の汎用型。SessionClock/USOpenは汎用暦。ReplayWithFactory/ReplayPreparedは指定場を同じ完全Featuresと元timer順で運転できる | コメントの「固定54」は関数の入力制限ではない。一方、新4場の限月/指紋/品質がないと有効入力にはならない |
| SourceCLI版2 | Recorder/SourceRecord全field、空通知・全商品/active method順、完全Observation SHA、Scalar11の写しは再用候補 | CLIのexpectedIDs54、旧93 golden、first2/full54、各入力/停止guardは旧固定用。新4場へ旧conditionを差し替えず、新しい薄い外周が必要。package mainのためRecorderは直接importできず、再用時はrecord.go同体抽出等を別diffへ残す |
| continuous producer | LoadRequestの固定reader、全board（TOPIX/Last0含む）の時計、同秒timer→grid→raw、Features/ProjectQuote/物理行、BuildToSinkは再用可 | 市場CLIの固定100完了/許可54/旧Tape台帳は新4場には不可。LoadRequestの旧Tape引数はSessionとgrid予定列だけを使うため、明示した新規予定時計carrierを与える小口を今回準備 |
| Binder e66 | fresh Scalar11と元recordの完全一致、全method/Force直前Line/空通知/Targets/Beforeを保つ検査を新legacy基準にも使える | 新4場の基準legacy Tapeが必要。旧54Tape/旧103Nativeを別日へ移して使わない。時刻AtだけのjoinやScalarからSource生成は不可 |
| 主B/103Actor | 停止103 ActualBook・LD10四の数値・B5Q/Source予約優先・D0/D1の金融は直接再用 | 主BCLIは54と旧103 goldenを固定する。新4場はgoldenなしを明記した別の薄い配送外周が必要。旧103市場全JSON一致という欄をtrueにしない |

## 新4場に旧93goldenがない場合の検査

同じ固定6入力を、停止Sourceのlegacyとdefaultへ独立に渡して **全ReplayResultと全SourceRecordのJSONを相互比較** する。件数/純額だけでなく全Signal/Fill/Close/Cancel・Targets/Before・Source量・Scalar/完全Observation SHAを保つ。今回の `CompareLegacyDefault` はその比較口だけで、Sourceを動かさない。

一致は「元生成口と既定式生成口が、この入力で同じ公開値を返した」という移植QAである。旧93保存物とのgolden同値、symmetricの妥当性・技法効果・新期間利益を証明しない。symmetricへ相互同値の成功を流用せず、新記録の全出典と品質を別に保持する。

## 新しいScalarとgrid/Tapeを作る最小手順案

1. Rootが別採番・計画・四場/二市場・費用/遅延・品質・評価・コードを先に固定する。入力の契約/6参照SHAを確定し、新場の失敗/品質未知も残す。4場を既存54へ混ぜて再選択しない。
2. `LoadFreshRequest` は新規 `ClockCarrier`（Session＋`[Start,End)`の全5分予定）を既存continuous.LoadRequestへ渡す。carrierには価格/通知/Capabilitiesがなく金融Tapeとしては使えない。旧54の価格やclock列を持ち込まない。
3. 新完全Requestを既存BuildToSinkへ渡し、fresh Scalar11/FeaturesIndex/物理Lineと全board由来の実観測grid列を新たに作る。TOPIX・Last0もtimer/grid上限を進める。EOF以後の未観測gridは足さない。`ObservedGridPrefix`はこの分母境界の小純関数で、実際の公表/配送順は既存BuildToSinkを権威とする。
4. 同じ新6入力からSourceReplay104＋Recorderで3modeの全recordを作る。新legacy記録のmini通知とfresh Scalar/全board制御時計から、新しいlegacy基準Tapeを組み立てる薄いadapterが次に必要。SourceのForce→grid→同秒raw、PのForce後空Step継続/U追加、EOFの残Force、Quote Index/Lineを保持する。SourceRecordは正NKへのStepしか持たないため、それだけから全board gridを復元しない。
5. その新legacy Tapeへlegacy/default/symmetric全recordを既存Bindで結合する。legacy/default相互全文と、全modeのfresh Scalar/時計/通知位相を検査する。Closes-onlyを捨てる旧CompressBatchesだけに依存せず、Targets/Before/空methodも保持する。
6. symmetric Tapeだけを旧103ActorのLD10四へ同じ配送で適用する。新4場なので旧103golden比較は未実施と明示し、保存会計・入力指紋・新しいSource/金融/Scalar出典を残す。

GateなしB5Q/LD10が使うATRは各場のNative FeaturesのATR5/旧ATR12であり、独立3/15分チャートのEMA種は金融に使わない。新規Scalar生成のために既使用54場の独立チャート助走を再運転する必要はない。旧chartの同限月種や新しい可変幅・技法gateを追加するなら、それは別の固定条件であり、この確認へ混ぜない。

Source側もcontinuous側もreaderは **book.jsonl.gzのgzip専用**。statでrawしかない場があれば、Rootが許可する別入力準備工程で圧縮し、raw↔gzip同体/新SHAを固定するか、別reader変更を別差分で検証する必要がある。今回、圧縮・入力hash・本文確認はしない。無圧縮rawを`.gz`の代わりに渡して成功扱いしない。

## 今回作ったコードと止める範囲

module `fixedfollowup` の `ClockCarrier` / `ObservedGridPrefix` / `CompareLegacyDefault` と、停止104汎用SessionClockの機械派生、将来用の `LoadFreshRequest` 委譲口だけ。Go人工は暦と手製公開metadataだけで、LoadFreshRequest/Source/金融を呼ばない。新legacy Tape組立・市場SourceCLI・金融CLI・保存本番は**未実装**であり、今回の停止を新4場の運転準備完了とは呼ばない。大きな新frameworkを先に作らず、この再用境界で止める。

```powershell
# statのみ。新しい入力内容のSHAも計算しない
python -B -X utf8 work/固定後4場の接続準備/metadataを準備する.py --out '<新規metadata.json>'
# 非市場のclock/公開型比較
Set-Location work/固定後4場の接続準備
go test -v ./...
go vet ./...
go build ./...
```

下書きはfixed=false/market_ready=false、限月/入力SHAはnull。本文未確認をデータ品質良好や収益確認へ読み替えない。4場の予定分母は旧条件なら主448/副432（US静観を落とさない）だが、実観測EOF不足はUNKNOWNとして分母と別記録にする案。市場の参加数・損益・未参加利益・MFE/退出後価格・機会損失は算出0。
