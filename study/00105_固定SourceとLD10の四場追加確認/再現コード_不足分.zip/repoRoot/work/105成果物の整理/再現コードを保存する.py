"""105の固定412コードと事後small codeを旧ZIP同体参照と不足ZIPへ分ける。"""

from collections import Counter
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import uuid
import zipfile


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00105_固定SourceとLD10の四場追加確認"
HERE = Path(__file__).resolve().parent
MODCACHE = Path("C:/Users/masay/go/pkg/mod")
OLD104 = ROOT / "study/00104_重複時の方向裁定と元Sourceの再形成"
OLD103 = ROOT / "study/00103_元の多玉と数量を保つ一定利益後の追尾"
CONDITION_SHA = "f13f90ecda3b3797d08c903017ad231abd267a9dad4ae2b7946c1ee713b8bb8e"
STOPS = {
    "work/105入力の固定準備/停止.json": "401b7f0451e7c1d0e9a2891a168e79e941e00bfbf6378a3bbb2eb00acd825348",
    "work/105四場Sourceの再形成/停止.json": "f52676b0cc55fe2fbdbb0f6524161950af4babbb5891513723a01b5f2618c28a",
    "work/105四場の時計とLD10確認/停止.json": "0a41056d1a9d0c14d13e0bf23d3f78fe7ce1ffb42b13dd2dfb898d8f81802299",
    "work/105LD10の保存準備/停止.json": "b90facc5612b6412ffcb760c8972c6cc6ad678eecb5922aa1082d5ef5b4db606",
    "work/105報告の準備/停止.json": "12872b928bbcb8f9199c10d257044330497671883a8267974c36c2aa81ae98ba",
    "work/105xlsx追記の準備/停止.json": "8f697bc39f585ece7a5a5087980db8a9a392a4683819441374f5763e242c28e0",
    "work/105正式反映の実行/停止.json": "37a03157f91d56f09e5e7973777d5d3170c189af6c5baa3ae9f35ba0e6f597a6"
}
CODE_SUFFIX = {".go", ".mod", ".sum", ".py", ".md", ".patch", ".json", ".mjs", ".js"}


def sha(path):
    """
    機能: コード/小metadata/コードZIPのSHA256を取得する。
    引数: path(Path)は明示ファイル。
    返り値: strは内容指紋。Rawや実結果を計算しない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    """
    機能: 固定条件/停止metadataを読む。
    引数: path(Path)はsmall JSON。
    返り値: dictは保存値。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def safe(name):
    """
    機能: ZIP entryが安全な相対POSIX pathか判定する。
    引数: name(str)はentry名。
    返り値: boolは絶対/drive/親移動/逆slashを含まなければ真。
    """
    return bool(name) and not name.startswith("/") and "\\" not in name and ":" not in name and ".." not in PurePosixPath(name).parts


def restore(path):
    """
    機能: 元絶対pathを再配置可能な論理rootと相対pathにする。
    引数: path(Path)は固定コード位置。
    返り値: dictはroot/relative。元../をZIP名へ直接流用しない。
    """
    for name, base in (("repoRoot", ROOT), ("neighborRoot", ROOT.parent), ("moduleCacheRoot", MODCACHE)):
        if path.is_relative_to(base):
            relative = path.relative_to(base).as_posix()
            assert safe(relative)
            return {"root": name, "relative": relative}
    raise ValueError("未定義の復元root:" + str(path))


def main():
    """
    機能: 全412所在と事後再現codeを同体参照/不足ZIPで正式保存する。
    引数: なし。Rootから最終helper確定連絡を受けた後だけ実行する。
    返り値: None。金融/Source/保存/Viewer/xlsxの処理は実行しない。
    """
    target, index = TRIAL / "再現コード_不足分.zip", TRIAL / "再現コードの所在.json"
    assert not target.exists() and not index.exists()
    condition_path = TRIAL / "主金融条件.json"
    assert sha(condition_path) == CONDITION_SHA
    condition = load(condition_path)
    assert len(condition["code_sha256"]) == 412
    items = {}

    def add(path, expected=None, role="事後再現"):
        """
        機能: 許可suffixのコード/metadataを期待SHAと役割へ束縛する。
        引数: path(Path)、expected(str|None)、role(str)は元位置/固定指紋/区分。
        返り値: None。衝突/対象外拡張子は拒否する。
        """
        path = path.resolve()
        assert path.is_file() and path.suffix in CODE_SUFFIX, path
        assert not any(path.name.endswith(x) for x in (".Native.json", ".result.json")), path
        value = sha(path)
        assert expected is None or value == expected, path
        key = str(path)
        if key not in items:
            items[key] = {"original_path": path.as_posix(), "SHA256": value, "bytes": path.stat().st_size,
                          "restore": restore(path), "roles": []}
        assert items[key]["SHA256"] == value
        if role not in items[key]["roles"]: items[key]["roles"].append(role)

    for name, expected in condition["code_sha256"].items():
        add(ROOT / name, expected, "主金融前固定412")
    for name, expected in STOPS.items():
        path = ROOT / name
        assert sha(path) == expected and load(path)["成功"] is True
        add(path, expected, "停止原文")
        stopped = load(path)
        for field in ("所有SHA256", "所有コードSHA256"):
            for n, h in stopped.get(field, {}).items(): add(ROOT / n, h, "停止所有コード")
    for folder in ("work/105入力の固定準備", "work/105LD10の保存準備"):
        for pattern in ("*人工確認.json", "*人工_最終.json"):
            for path in (ROOT / folder).glob(pattern): add(path, role="最終小人工証拠")
    for path in (ROOT / "work/105進行").glob("*.py"): add(path, role="Root進行helper")
    for path in (ROOT / "work/105進行").glob("*Go依存.json"): add(path, role="局所Go閉包metadata")
    for name in ("実報告を仕上げる.py", "報告固定.json", "xlsx固定.json", "正式反映の確認.json", "xlsx保存後QA.json", "xlsx実行と目視の確認.json"):
        add(ROOT / "work/105正式反映の実行" / name, role="報告xlsx実行の小再現参照")
    for path in HERE.glob("*.py"): add(path, role="成果物保存helper")
    for name in ("入力開封条件.json", "Source条件.json", "主金融条件.json", "開封前入力予約.json", "入力台帳.json", "入力の由来と品質.json"):
        add(TRIAL / name, role="105条件/入力由来metadata")
    assert sha(ROOT / "work/105報告の準備/報告を差し替える.py") == "e09539c38606e999f2e7278c3b078dcb470f2ee334ab811b21cb921fbc065b15"
    assert sha(ROOT / "work/105xlsx追記の準備/105を追記する.mjs") == "9235b992b95be3738d913e5df9cc3742bdb9d1afac4f00e75cd98b177c109ba9"
    assert sha(ROOT / "work/105正式反映の実行/実報告を仕上げる.py") == "445378fc086c0c5a04233a6e9acde2a9bb1832dfe2bcc08f408da38336349a46"

    # ----------------------------------------
    # 既存archiveは展開せず、entry bytes SHAだけを索引化する。
    old_paths = [OLD104 / name for name in ("Source再現コード.zip", "主B追加コード.zip", "先頭2結合検査コード.zip", "保存と照合コード.zip")]
    old_paths += [OLD103 / name for name in ("再現コード.zip", "保存と照合のコード.zip")]
    old_by_sha, archives = {}, []
    for path in old_paths:
        archive_ref = {"path": os.path.relpath(path, TRIAL).replace("\\", "/"), "SHA256": sha(path), "bytes": path.stat().st_size}
        archives.append(archive_ref)
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            for info in archive.infolist():
                if info.is_dir() or not safe(info.filename): continue
                value = hashlib.sha256(archive.read(info)).hexdigest()
                old_by_sha.setdefault(value, {"kind": "既存archive", "archive": archive_ref, "entry": info.filename})
    extra, rows = {}, []
    for name in sorted(items):
        item = items[name]
        value = item["SHA256"]
        if value in old_by_sha:
            storage = old_by_sha[value]
        else:
            if value not in extra:
                entry = item["restore"]["root"] + "/" + item["restore"]["relative"]
                assert safe(entry)
                extra[value] = {"entry": entry, "path": Path(name)}
            storage = {"kind": "新規不足archive", "archive": target.name, "entry": extra[value]["entry"]}
        rows.append({**item, "storage": storage})
    before = {name: sha(Path(name)) for name in items}
    archive_before = {str(p): sha(p) for p in old_paths}
    candidate = HERE / ("候補_" + uuid.uuid4().hex)
    candidate.mkdir()
    zip_path = candidate / target.name
    with zipfile.ZipFile(zip_path, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for value, detail in sorted(extra.items(), key=lambda x: x[1]["entry"]):
            data = detail["path"].read_bytes()
            assert hashlib.sha256(data).hexdigest() == value
            info = zipfile.ZipInfo(detail["entry"], date_time=(2026, 11, 9, 0, 0, 0)); info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
    with zipfile.ZipFile(zip_path) as archive:
        assert archive.testzip() is None and len(archive.namelist()) == len(extra)
        for value, detail in extra.items():
            assert safe(detail["entry"]) and hashlib.sha256(archive.read(detail["entry"])).hexdigest() == value
    assert all(sha(Path(name)) == h for name, h in before.items())
    assert all(sha(Path(name)) == h for name, h in archive_before.items())
    fixed_rows = [r for r in rows if "主金融前固定412" in r["roles"]]
    assert len(fixed_rows) == 412
    metadata = {"成功": True, "試行": 105, "scope": "主金融前412code全所在と事後small code。既存同SHAは旧archiveを参照。不足だけを新規ZIPへ同体保存",
        "主金融条件": {"path": condition_path.name, "SHA256": CONDITION_SHA}, "固定code数": 412,
        "固定codeのGo数": sum(Path(r["original_path"]).suffix == ".go" for r in fixed_rows),
        "固定code保存先別": dict(Counter(r["storage"]["kind"] for r in fixed_rows)),
        "全所在数": len(rows), "新ZIP": {"path": target.name, "SHA256": sha(zip_path), "bytes": zip_path.stat().st_size, "entry数": len(extra)},
        "既存archive": archives, "roots": {"repoRoot": str(ROOT), "neighborRoot": str(ROOT.parent), "moduleCacheRoot": str(MODCACHE)},
        "復元手順": ["既存archiveを一括で無条件展開せず、本索引storageのarchive/entryを読みSHAを照合する",
            "各entry bytesをrestore.rootを移設先で明示した根＋restore.relativeへ同体保存する。別名entryでも内容SHAが同じ時だけ対応する",
            "repoRoot=FutureSignalResearch、neighborRoot=その親（SessionTradeExecuter等）、moduleCacheRoot=既存Go cacheの取得版。元drive絶対pathは索引値として保持しZIP entryへ入れない",
            "旧コードには実行環境の絶対pathを参照する部分があり、別場所での再現にはRootのpath対応を要する。版/意味を自動置換して成功とはしない"],
        "entries": rows, "検査": {"全コード現物SHA一致": len(rows), "固定412所在欠落": 0, "新ZIP全entry読戻しSHA一致": len(extra), "新ZIP_CRC差": 0, "危険entry": 0,
            "元コード/停止/条件前後不変": True, "旧archive前後不変": True},
        "除外": ["原板/CSV", "生成入力gzip", "価格Tape", "金融Native", "Source全記録", "大log", "実行binary", "xlsx/画像", "人工の全帳簿出力", "GoRoot/巨大外部ライブラリ本文"],
        "外部実行環境": {"Node import": "@oai/artifact-tool（xlsx停止README/環境に従う。ライブラリ本体と原xlsxは非同梱）", "Go": "元停止に記録した実Go版/外部取得版とgo.mod/sumを維持。取得や再buildは本処理でしない"},
        "金融/Source/保存/Viewer/xlsx再実行": 0, "正式README/設定/目次/完了記録編集": 0}
    index_path = candidate / index.name
    index_path.write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for original, destination in ((zip_path, target), (index_path, index)):
        with destination.open("xb") as stream: stream.write(original.read_bytes())
        assert sha(destination) == sha(original)
    print(json.dumps({"成功": True, "固定412": len(fixed_rows), "全所在": len(rows), "不足entry": len(extra), "ZIP_SHA256": sha(target), "索引SHA256": sha(index)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
