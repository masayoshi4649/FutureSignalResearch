"""105完成Native4とSource結果12を、再計算せず正式成果物へ保存する。"""

import gzip
import hashlib
import json
import os
from pathlib import Path
import shutil


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00105_固定SourceとLD10の四場追加確認"
HERE = Path(__file__).resolve().parent
IDS = ["2026-11-05_Day", "2026-11-05_Night", "2026-11-06_Day", "2026-11-06_Night"]


def sha(path):
    """
    機能: 明示された保存物の内容SHA256をstreamで求める。
    引数: path(Path)は完成結果又はmetadata。
    返り値: strは内容指紋。金融/Source計算はしない。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    """
    機能: 完了metadataだけを読む。
    引数: path(Path)は成功完了JSON。
    返り値: dictは保存値。Native/Source経済本文はJSON解析しない。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write(path, value):
    """
    機能: 不存在JSONへUTF-8で新規保存する。
    引数: path(Path)、value(dict)は参照索引と値。
    返り値: None。上書きをしない。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2); stream.write("\n")


def ref(path, base):
    """
    機能: 索引を置くtrialdir基準のFileRefを作る。
    引数: path/base(Path)は保存先と基準。
    返り値: dictはpath/sha256/bytes。
    """
    return {"path": os.path.relpath(path, base).replace("\\", "/"), "sha256": sha(path), "bytes": path.stat().st_size}


def resolve(value, base):
    """
    機能: 明示FileRefを元ディレクトリから解決してSHAを照合する。
    引数: value(dict)、base(Path)は元参照と根。
    返り値: Pathは照合済みの保存ファイル。
    """
    path = (base / value["path"]).resolve()
    if sha(path) != value["sha256"]:
        raise ValueError("完成参照のSHA差:" + str(path))
    return path


def main():
    """
    機能: 四金融Nativeを同bytesで、12Source結果をSHA同一単位のgzipで保存する。
    引数: なし。Root成功通知に結び付いた固定完了だけを使う。
    返り値: None。Raw/価格Tape/records/金融再生/Source再生/APIは読取実行しない。
    """
    finance_path = ROOT / "work/105LD10市場/全4場/完了.json"
    source_path = ROOT / "work/105Source市場/全4場/完了.json"
    expected = {finance_path: "07452277aaefaf90d0fdc2a7bf24c4507d792d856b1bafac226af025a7cbed60",
                source_path: "8eeefe0fca05bde964dc2a247a42cb9d09192676ded32f1343abb4da2ef5a1d2"}
    assert all(sha(p) == h for p, h in expected.items())
    finance, source = load(finance_path), load(source_path)
    assert finance["success"] and finance["stage"] == "full4" and finance["books"] == 16
    assert [r["session"] for r in finance["results"]] == IDS and not finance["old103_market_golden"]
    assert source["success"] and source["stage"] == "full4" and len(source["cases"]) == 12
    assert {(r["session"], r["mode"]) for r in source["cases"]} == {(s, mode) for s in IDS for mode in ("legacy", "default", "symmetric")}
    dest_native = TRIAL / "成果物_主B/Native"
    dest_source = TRIAL / "成果物_Source/Result"
    native_index = TRIAL / "成果物_主B/Native参照台帳.json"
    source_index = TRIAL / "成果物_Source/Source結果参照台帳.json"
    assert not native_index.exists() and not source_index.exists()
    dest_native.mkdir(parents=True, exist_ok=True); dest_source.mkdir(parents=True, exist_ok=True)
    inputs = {str(p): h for p, h in expected.items()}
    rows, tape_refs = [], []
    for item in finance["results"]:
        original = resolve(item["native"], finance_path.parent)
        inputs[str(original)] = item["native"]["sha256"]
        target = dest_native / (item["session"] + ".json.gz")
        assert not target.exists()
        with original.open("rb") as src, target.open("xb") as dst: shutil.copyfileobj(src, dst)
        assert sha(target) == item["native"]["sha256"]
        rows.append({"session": item["session"], **ref(target, TRIAL), "work元": item["native"], "同bytes": True, "会計": 4})
        tape_refs.append({"session": item["session"], **{k: item[k] for k in ("fresh_legacy_tape", "symmetric_tape")}})
    write(native_index, {"成功": True, "試行": 105, "基準": "trialdir", "場数": 4, "金融会計": 16,
        "元金融完了": ref(finance_path, TRIAL), "旧市場golden": "対象外", "参照": rows,
        "価格Tape": {"保存": "work参照のみ・本文未読/非複製", "場別": tape_refs}, "金融本文JSON解析/金融再生": 0})

    # ----------------------------------------
    # 成績/方向を選別せず12case全てを登録し、同bytesだけSHAで共用する。
    source_rows, unique = [], {}
    for item in source["cases"]:
        assert not item["old93_full_match"] and not item.get("error")
        original = resolve(item["result"], source_path.parent)
        inputs[str(original)] = item["result"]["sha256"]
        raw_sha = item["result"]["sha256"]
        assert original.suffix == ".json"
        if raw_sha not in unique:
            target = dest_source / (raw_sha + ".json.gz")
            assert not target.exists()
            with original.open("rb") as src, target.open("xb") as dst:
                with gzip.GzipFile(filename="", mode="wb", fileobj=dst, compresslevel=6, mtime=0) as gz:
                    shutil.copyfileobj(src, gz)
            with gzip.open(target, "rb") as restored:
                decoded_sha = hashlib.file_digest(restored, "sha256").hexdigest()
            assert decoded_sha == raw_sha
            unique[raw_sha] = {**ref(target, TRIAL), "解凍SHA256": decoded_sha}
        source_rows.append({"session": item["session"], "mode": item["mode"], "原結果": item["result"],
            "原SHA256": raw_sha, "正式gzip": unique[raw_sha], "旧golden": "対象外・旧一致flagはfalse",
            "records": {**item["records"], "保存": "work参照のみ・本文未読/非複製"}})
    write(source_index, {"成功": True, "試行": 105, "基準": "trialdir", "元Source完了": ref(source_path, TRIAL),
        "case数": 12, "ユニークgzip数": len(unique), "同体の判定": "原ファイルbytesのSHA一致のみ。番号/価格/成績で選別しない",
        "cases": source_rows, "Source/価格/金融再計算": 0, "records本文読取": 0})
    assert all(sha(Path(p)) == h for p, h in inputs.items())
    receipt = {"成功": True, "scope": "完成金融Native4同bytesとSource全12resultの同体gzip保存。内容/損益の再計算なし",
        "金融Native": 4, "金融会計": 16, "Sourcecase": 12, "Sourceユニークgzip": len(unique),
        "Native索引": ref(native_index, TRIAL), "Source索引": ref(source_index, TRIAL),
        "元入力SHA256前後": inputs, "前後不変": True, "正式保存SHA": {**{r["path"]: r["sha256"] for r in rows},
            **{v["path"]: v["sha256"] for v in unique.values()}}, "価格Tape/records/Raw/CSV本文読取": 0,
        "金融/Source/Viewer再実行": 0, "README/設定/目次/完了記録変更": 0}
    output = HERE / "NativeとSource結果の確認.json"
    write(output, receipt)
    print(json.dumps({"成功": True, "Native": 4, "Sourcecase": 12, "Sourcegzip": len(unique),
        "Native索引SHA256": sha(native_index), "Source索引SHA256": sha(source_index), "確認SHA256": sha(output)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
