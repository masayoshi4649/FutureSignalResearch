"""105の入力開封条件を、入力本文を読まず新規保存する。"""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00105_固定SourceとLD10の四場追加確認"
HELPER = ROOT / "work/105入力の固定準備"


def sha(path):
    """
    機能: 計画・コード等の小ファイルの指紋を取得する。
    引数: path(Path)は入力価格を含まない固定対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    """
    機能: 予約と入力準備コードを先に固定し、新規の開封条件を保存する。
    引数: なし。採番済み105の所定位置だけを対象とする。
    返り値: None。既存条件又は生成先があれば停止する。
    """
    output = TRIAL / "入力開封条件.json"
    generated = HELPER / "生成_初回"
    assert not output.exists() and not generated.exists()
    reservation = TRIAL / "開封前入力予約.json"
    assert sha(reservation) == "17804b1ae1cd6518fbc5749b83acddf64aaefda22f17f90501a5de32df91cbb2"
    names = ["入力を固定する.py", "人工を確認する.py", "人工確認.json", "README.md", "由来.json", "停止.json"]
    paths = [HELPER / name for name in names] + [Path(__file__).resolve()]
    assert all(path.is_file() for path in paths)
    plan = {
        "version": 1, "trial": 105, "fixed": True, "body_read_allowed": True,
        "sessions": ["2026-11-05_Day", "2026-11-05_Night", "2026-11-06_Day", "2026-11-06_Night"],
        "source_root": ROOT.parent.as_posix(), "source_finance_executed": False,
        "reservation": {"path": "開封前入力予約.json", "sha256": sha(reservation)},
        "output_root": "../../work/105入力の固定準備/生成_初回",
        "code_sha256": {path.relative_to(ROOT).as_posix(): sha(path) for path in paths},
        "用途": "入力24参照の内容固定と品質だけ。Source・指標選択・金融は実行しない。",
    }
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(plan, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"path": output.relative_to(ROOT).as_posix(), "sha256": sha(output)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
