"""固定105Source全4成功後に、新時計と不変LD10四設定の条件を保存する。"""

import hashlib
import json
from pathlib import Path
import shutil
import subprocess


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00105_固定SourceとLD10の四場追加確認"
CLOCK = ROOT / "work/105四場の時計とLD10確認"
INPUT = ROOT / "work/105入力の固定準備/生成_初回"


def sha(path):
    """
    機能: コード又は小参照のSHA256を得る。
    引数: path(Path)は固定対象。原板・CSVを当処理では読まない。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    """
    機能: 小さい固定JSONを読む。
    引数: path(Path)は停止・条件・完了等。
    返り値: dictは保存内容。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    """
    機能: Source成功と公開時計補足を固定し、新規の主金融条件を保存する。
    引数: なし。105同一4場・symmetric LD10四を維持する。
    返り値: None。指紋差又は既存条件を拒否する。
    """
    destination = TRIAL / "主金融条件.json"
    assert not destination.exists()
    stop_path = CLOCK / "停止.json"
    assert sha(stop_path) == "0a41056d1a9d0c14d13e0bf23d3f78fe7ce1ffb42b13dd2dfb898d8f81802299"
    stop = load(stop_path)
    source_path = TRIAL / "Source条件.json"
    assert sha(source_path) == "fd027f68e68b2425dbf99206f6205fa103bd6d55fb848bd2ee718789d08e854c"
    source = load(source_path)
    full_path = ROOT / "work/105Source市場/全4場/完了.json"
    full = load(full_path)
    assert full["success"] and full["stage"] == "full4" and full["trial"] == 105
    assert full["condition_sha256"] == sha(source_path) and len(full["cases"]) == 12
    assert full["unchanged"] and len(full["legacy_default_matches"]) == 4
    code, normalized = {}, {}

    def add(path, expected=None):
        """
        機能: 小参照とコードを絶対位置で一意に固定する。
        引数: path(Path)、expected(str|None)は固定対象と既存指紋。
        返り値: None。差がある場合は停止する。
        """
        path = path.resolve()
        actual = sha(path)
        assert expected is None or expected == actual, str(path)
        key = path.as_posix()
        canonical = normalized.setdefault(key.lower(), key)
        assert canonical not in code or code[canonical] == actual, key
        code[canonical] = actual

    for mapping in [source["code_sha256"], stop["所有コードSHA256"], stop["元停止/直接依存前後SHA256"]]:
        for name, expected in mapping.items():
            add(ROOT / name, expected)

    # ----------------------------------------
    # 公開APIの局所依存だけでなく、実Go importの作業領域内閉包も固定する。
    listed = subprocess.run(["go", "list", "-mod=readonly", "-deps", "-json", "."], cwd=CLOCK,
                            capture_output=True, encoding="utf-8", check=True)
    decoder, offset, local = json.JSONDecoder(), 0, []
    while offset < len(listed.stdout):
        while offset < len(listed.stdout) and listed.stdout[offset].isspace():
            offset += 1
        if offset == len(listed.stdout):
            break
        package, offset = decoder.raw_decode(listed.stdout, offset)
        directory = Path(package["Dir"]).resolve()
        if not directory.is_relative_to(ROOT.parent):
            continue
        names = sorted(set(package.get("GoFiles", []) + package.get("CgoFiles", []) + package.get("EmbedFiles", [])))
        for name in names:
            add(directory / name)
        module = package.get("Module", {})
        module = module.get("Replace", module)
        if module.get("Dir"):
            module_root = Path(module["Dir"]).resolve()
            if module_root.is_relative_to(ROOT.parent):
                for name in ["go.mod", "go.sum"]:
                    if (module_root / name).is_file():
                        add(module_root / name)
        local.append({"import": package["ImportPath"], "directory": directory.as_posix(), "files": names})
    dependency_path = Path(__file__).parent / "主金融のGo依存.json"
    assert local and not dependency_path.exists()
    with dependency_path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump({"用途": "市場実行前のGo局所依存閉包。標準/外部moduleは実行物・go.sumで区別。", "packages": local}, stream, ensure_ascii=False, indent=2)
        stream.write("\n")

    snapshot = TRIAL / "主金融前仕様"
    assert not snapshot.exists()
    snapshot.mkdir()
    for name in ["README.md", "設定と結果.md", "時計仕様補足.md"]:
        shutil.copyfile(TRIAL / name, snapshot / name)
    for path in [stop_path, dependency_path, Path(__file__),
                 snapshot / "時計仕様補足.md", snapshot / "README.md", snapshot / "設定と結果.md",
                 ROOT / "work/105新時計のpeer確認/確認.json"]:
        add(path)
    condition = load(CLOCK / "条件の雛形.json")
    condition["fixed"] = True
    refs = {
        "input_manifest": INPUT / "入力台帳.json", "source_condition": source_path, "source_full": full_path,
        "source_stop": ROOT / "work/105四場Sourceの再形成/停止.json",
        "clock_stop": ROOT / "work/固定後4場の接続準備/停止.json",
        "binder_stop": ROOT / "work/104新Sourceと判断時計の結合案/停止.json",
        "binary": CLOCK / "検査/時計とLD10.exe",
    }
    for name, path in refs.items():
        condition[name] = {"path": path.as_posix(), "sha256": sha(path)}
    assert condition["binary"]["sha256"] == "75674f514d10f0dd479d04e25bf12dddf0d2baabe96382963bfea7cc1ca2085f"
    condition["code_sha256"] = code
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(condition, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"path": destination.relative_to(ROOT).as_posix(), "sha256": sha(destination),
                      "固定code数": len(code), "局所Goパッケージ数": len(local)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
