"""105の実保有履歴だけで、費用後正益経験玉の最終赤字を追尾起動有無へ分ける。"""

import gzip
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00105_固定SourceとLD10の四場追加確認"


def sha(path):
    """
    機能: 固定参照のSHA256を得る。
    引数: path(Path)は金融完了・圧縮Native・保存結果・当コード。
    返り値: strはSHA256。原板や価格Tapeは読まない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    """
    機能: 全4場の個別玉IDで二つの赤字集合と包含関係を検査する。
    引数: なし。105固定Source/LD10四感度だけを対象とする。
    返り値: None。実現額と正本集計が違えば保存せず停止する。
    """
    receipt = ROOT / "work/105LD10市場/全4場/完了.json"
    result = TRIAL / "成果物_主B/結果.json"
    before = {str(receipt): "07452277aaefaf90d0fdc2a7bf24c4507d792d856b1bafac226af025a7cbed60",
              str(result): "e3b9ad102b55c48f259194a468638125f7699e526dbb60ecd4f4642451476d4e",
              str(Path(__file__).resolve()): sha(Path(__file__))}
    assert all(sha(Path(name)) == expected for name, expected in before.items())
    done = json.loads(receipt.read_text(encoding="utf-8"))
    saved = json.loads(result.read_text(encoding="utf-8"))
    assert done["success"] and done["books"] == saved["会計数"] == 16
    groups = {key: {"u正益後最終赤字": [], "LD起動済み最終赤字": [], "LD未起動でu正益後最終赤字": []}
              for key in saved["主key"]}
    for scene in done["results"]:
        ref = scene["native"]
        path = (receipt.parent / ref["path"]).resolve()
        assert sha(path) == ref["sha256"]
        before[str(path)] = ref["sha256"]
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            value = json.load(stream)
        assert value["complete"] and value["trial"] == 105 and value["session"]["id"] == scene["session"]
        for key, book in value["books"].items():
            for position in book["positions"]:
                assert position["quantity"] == position["reserved"] == 0
                positive = position["marks"]["first_unit_positive"] is not None
                activated = position["protection_active"]
                if activated:
                    assert positive and position["activation"]["unit_net"] > 0
                if position["realized_net"] >= 0:
                    continue
                row = {"session": scene["session"], "position_id": position["id"], "realized_net": position["realized_net"]}
                if positive:
                    groups[key]["u正益後最終赤字"].append(row)
                    branch = "LD起動済み最終赤字" if activated else "LD未起動でu正益後最終赤字"
                    groups[key][branch].append(row)
    evidence = {}
    for key, rows in groups.items():
        sums = {name: {"玉数": len(items), "実現純額": sum(row["realized_net"] for row in items)} for name, items in rows.items()}
        total, active, inactive = (sums[name] for name in rows)
        assert total["玉数"] == active["玉数"] + inactive["玉数"]
        assert total["実現純額"] == active["実現純額"] + inactive["実現純額"]
        reference = saved["集計"][key]
        assert total["玉数"] == reference["unit_positive_closed_negative"]
        assert total["実現純額"] == reference["unit_positive_closed_negative_yen"]
        assert active["玉数"] == reference["activated_closed_negative"]
        assert active["実現純額"] == reference["activated_closed_negative_yen"]
        evidence[key] = {"集計": sums, "個別玉": rows}
    assert all(sha(Path(name)) == expected for name, expected in before.items())
    output = TRIAL / "検査/主金融全4場/追尾起動前後の赤字.json"
    proof = {"成功": True, "対象": "105全4場/16会計の実保有履歴。uは残玉1枚の費用後評価、赤字は全返済後の玉実現純額。",
             "集計": evidence, "LD起動済み赤字はu正益経験赤字の部分集合": True,
             "差分は個別玉で検算": True, "入力SHA256": before, "前後不変": True,
             "未検証": "未起動玉で当時C/M/P警戒が公表されていたか、早期起動が改善したか。",
             "原板/価格Tape/退出後価格/仮想損益/金融再実行": 0}
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "設定": len(evidence), "差分の検算": True, "path": output.relative_to(ROOT).as_posix()}, ensure_ascii=False))


if __name__ == "__main__":
    main()
