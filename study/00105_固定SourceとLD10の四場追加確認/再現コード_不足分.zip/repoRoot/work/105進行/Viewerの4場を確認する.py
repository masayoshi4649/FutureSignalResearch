"""既存Viewerへ105一覧を読み込み、固定した4場・四感度の表示を照合する。"""

from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
import hashlib
import json
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00105_固定SourceとLD10の四場追加確認"
BASE = "http://127.0.0.1:8092"
CATALOG = TRIAL / "成果物_主B/一覧.resources.json"
RECEIPT = ROOT / "work/105LD10市場/全4場/完了.json"
RESULT = CATALOG.parent / "結果.json"
CHECK = CATALOG.parent / "保存会計の確認.json"
SELECTED = [("LD10_B5Q_P0_C0_D0", "2026-11-05_Day"),
            ("LD10_B5Q_P0_C0_D1", "2026-11-05_Night"),
            ("LD10_B5Q_P0_C5_D0", "2026-11-06_Day"),
            ("LD10_B5Q_P0_C5_D1", "2026-11-06_Night")]


def request(route, payload=None):
    """
    機能: 既存Viewerの情報・一覧読込・表示データを取得する。
    引数: route(str)、payload(dict|None)は相対APIと一覧path。
    返り値: tuple[dict,str]は応答と本文SHA256。
    """
    body = None if payload is None else json.dumps(payload).encode("utf-8")
    req = Request(BASE + route, data=body, headers={"Content-Type": "application/json"})
    with urlopen(req, timeout=60) as response:
        raw = response.read()
        digest = hashlib.sha256(raw).hexdigest()
        claimed = response.headers.get("x-chart-data-sha256")
        assert claimed is None or claimed == digest
        return json.loads(raw, parse_float=Decimal), digest


def main():
    """
    機能: 一覧16資源と事前選択4表示の実約定・純額・残0を照合する。
    引数: なし。105金融・保存成功後だけ実行する。
    返り値: None。全16表示や金融再実行を検証したとは呼ばない。
    """
    paths = [CATALOG, RECEIPT, RESULT, CHECK, Path(__file__).resolve()]
    before = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
    complete = json.loads(RECEIPT.read_text(encoding="utf-8"))
    saved = json.loads(RESULT.read_text(encoding="utf-8"))
    checked = json.loads(CHECK.read_text(encoding="utf-8"))
    assert complete["success"] and complete["books"] == 16 and complete["stage"] == "full4"
    assert saved["成功"] and saved["会計数"] == 16 and checked["成功"] and checked["不一致数"] == 0
    resources = json.loads(CATALOG.read_text(encoding="utf-8"))["resources"]
    assert len(resources) == 16 and len({row["id"] for row in resources}) == 16
    info, _ = request("/api/info")
    assert Path(info["resource_root"]).resolve() == ROOT
    loaded, _ = request("/api/catalogs/load", {"path": CATALOG.relative_to(ROOT).as_posix()})
    assert len(loaded["resources"]) == 16
    expected = {(row["session"], row["key"]): row["net_yen"] for row in saved["場別"]}

    def check(item):
        """
        機能: 事前指定した一表示を保存実約定へ照合する。
        引数: item(tuple[str,str])は設定Keyと場ID。
        返り値: dictは表示限定の照合証拠。
        """
        key, session = item
        identity = f"105_{key}_{session}"
        resource = next(row for row in resources if row["id"] == identity)
        trades = CATALOG.parent / resource["pnl_path"]
        original = trades.read_bytes()
        query = urlencode({"catalog": loaded["catalog_id"], "resource": identity,
                           "width": 1, "interval": "raw", "price": "last"})
        value, digest = request("/api/data?" + query)
        summary = value["summary"]
        assert value["resource"]["id"] == identity
        assert summary["realized_pnl_yen"] == expected[(session, key)]
        assert summary["long_qty"] == summary["short_qty"] == summary["unrealized_pnl_yen"] == 0
        assert len(value["events"]) == len(original.splitlines()) and original == trades.read_bytes()
        return {"id": identity, "実約定行": len(value["events"]), "純額": expected[(session, key)], "本文SHA256": digest}

    with ThreadPoolExecutor(max_workers=4) as pool:
        details = list(pool.map(check, SELECTED))
    assert before == {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}
    proof = {"成功": True, "scope": "一覧16読込と事前固定4場/四感度の実表示。全16表示の検証ではない",
             "一覧資源数": 16, "実GET資源": 4, "details": details, "入力コードSHA256": before,
             "前後不変": True, "server停止再起動設定変更": 0, "金融再実行": 0, "Source再形成": 0}
    output = TRIAL / "検査/主金融全4場/Viewer代表4資源.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "一覧": 16, "実表示": 4, "照合差": 0}, ensure_ascii=False))


if __name__ == "__main__":
    main()
