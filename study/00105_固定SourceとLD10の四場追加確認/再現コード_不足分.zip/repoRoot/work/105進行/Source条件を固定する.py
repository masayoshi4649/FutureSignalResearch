"""105の入力準備が成功した後に、同じ4場のSource条件を一度だけ固定する。"""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00105_固定SourceとLD10の四場追加確認"
SOURCE = ROOT / "work/105四場Sourceの再形成"
INPUT = ROOT / "work/105入力の固定準備/生成_初回"


def sha(path):
    """
    機能: 固定参照の指紋を得る。
    引数: path(Path)はコード又は小さい入力台帳等。
    返り値: strはSHA256。価格本文はここで読まない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    """
    機能: 固定の小JSONを読む。
    引数: path(Path)は条件・停止・台帳。
    返り値: dictは保存内容。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main():
    """
    機能: 入力成功・由来と依存集合を確認し、Source条件を新規保存する。
    引数: なし。105の予約済み4場を変更しない。
    返り値: None。指紋差や既存条件は停止する。
    """
    destination = TRIAL / "Source条件.json"
    assert not destination.exists()
    stop_path = SOURCE / "停止.json"
    assert sha(stop_path) == "f52676b0cc55fe2fbdbb0f6524161950af4babbb5891513723a01b5f2618c28a"
    stop = load(stop_path)
    receipt = load(INPUT / "完了.json")
    assert receipt["成功"] and receipt["場数"] == 4 and receipt["入力"] == 24
    assert receipt["前後不変"] and receipt["原26SHA前後一致"]
    assert receipt["入力台帳SHA256"] == sha(INPUT / "入力台帳.json")
    assert receipt["由来品質SHA256"] == sha(INPUT / "入力の由来と品質.json")
    assert receipt["Root計画SHA256"] == "3516442f69932c34d7ddada882a4f2ec53b6d3a8d8891dfb2d523e85e44328e6"
    code = {}

    def add(path, expected=None):
        """
        機能: 絶対位置で重複をまとめ、既存指紋との一致を確認する。
        引数: path(Path)は小参照、expected(str|None)は既定指紋。
        返り値: None。内容差又は重複の異なる指紋は停止する。
        """
        path = path.resolve()
        actual = sha(path)
        assert expected is None or actual == expected, str(path)
        key = path.as_posix()
        assert key not in code or code[key] == actual, key
        code[key] = actual

    for mapping in [load(SOURCE / "依存の前指紋.json"), stop["所有SHA256"]]:
        for name, expected in mapping.items():
            add(ROOT / name, expected)
    manifest = load(INPUT / "入力台帳.json")
    assert len(manifest["sessions"]) == 4 and len(manifest["純戦略SHA256"]) == 43
    for name, expected in manifest["純戦略SHA256"].items():
        add(Path(manifest["純戦略repo"]) / name, expected)
    for path in [stop_path, INPUT / "完了.json", INPUT / "入力の由来と品質.json",
                 TRIAL / "入力開封条件.json", TRIAL / "開封前入力予約.json",
                 TRIAL / "実行前仕様/README.md", TRIAL / "実行前仕様/設定と結果.md",
                 TRIAL / "入力仕様補足.md", Path(__file__)]:
        add(path)
    condition = load(SOURCE / "条件の雛形.json")
    condition["fixed"] = True
    condition["input_manifest"] = {"path": (INPUT / "入力台帳.json").as_posix(), "sha256": sha(INPUT / "入力台帳.json")}
    condition["code_sha256"] = code
    assert sha(Path(condition["binary"]["path"])) == condition["binary"]["sha256"]
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(condition, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"path": destination.relative_to(ROOT).as_posix(), "sha256": sha(destination), "固定code数": len(code)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
