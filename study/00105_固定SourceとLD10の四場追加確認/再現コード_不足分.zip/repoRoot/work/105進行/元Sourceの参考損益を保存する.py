"""105で既に再生済みの元Source連続mini会計を、C5の参考値として保存する。"""

import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00105_固定SourceとLD10の四場追加確認"


def sha(path):
    """
    機能: 小さいSource結果と完了・当コードの指紋を取得する。
    引数: path(Path)はJSON又はコード。原板と価格Tapeは読まない。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    """
    機能: 事前指定symmetricの全4場・全mini口座を除外せず合算する。
    引数: なし。元会計の38.5円/片道5ptを確認する。
    返り値: None。残0・単純保存算術が違えば停止する。
    """
    receipt = ROOT / "work/105Source市場/全4場/完了.json"
    before = {str(receipt): "8eeefe0fca05bde964dc2a247a42cb9d09192676ded32f1343abb4da2ef5a1d2",
              str(Path(__file__).resolve()): sha(Path(__file__))}
    assert sha(receipt) == before[str(receipt)]
    done = json.loads(receipt.read_text(encoding="utf-8"))
    assert done["success"] and done["sessions"] == 4 and len(done["cases"]) == 12
    fields = ["entry_quantity", "close_quantity", "gross_yen", "fee_yen", "slippage_yen", "net_yen"]
    rows = []
    for case in [item for item in done["cases"] if item["mode"] == "symmetric"]:
        path = (receipt.parent / case["result"]["path"]).resolve()
        assert sha(path) == case["result"]["sha256"] and not case["old93_full_match"]
        before[str(path)] = case["result"]["sha256"]
        value = json.loads(path.read_text(encoding="utf-8"))
        mini = [(key, book) for key, book in value["books"].items() if book["config"]["product"] == "NK225mini"]
        assert len(mini) == (1 if case["session"].endswith("Day") else 2)
        row = {"session": case["session"], "books": len(mini), **{name: 0 for name in fields}}
        for key, book in mini:
            config, totals = book["config"], book["totals"]
            assert book["complete"] and book["finished"] and not book["failure"]
            assert config["fee_yen_per_side"] == 38.5 and config["slippage_points"] == 5 and config["point_value"] == 100
            assert all(totals[name] == 0 for name in ["open_buy_quantity", "open_sell_quantity", "pending_buy_quantity", "pending_sell_quantity", "open_entry_costs_yen"])
            assert totals["entry_quantity"] == totals["close_quantity"]
            assert totals["fee_yen"] == 77 * totals["entry_quantity"]
            assert totals["slippage_yen"] == 1000 * totals["entry_quantity"]
            assert totals["net_yen"] == totals["closed_net_yen"] == totals["gross_yen"] - totals["fee_yen"] - totals["slippage_yen"]
            for name in fields:
                row[name] += totals[name]
        rows.append(row)
    assert len(rows) == 4 and all(sha(Path(name)) == expected for name, expected in before.items())
    result = {"成功": True, "scope": "元Source連続会計の参考C5。B5Q・開始30分・追加全玉保護を備える主候補とは時計/取得が異なる。",
              "場別": rows, "合計": {name: sum(row[name] for row in rows) for name in fields},
              "合算口座数": sum(row["books"] for row in rows), "入力SHA256": before, "前後不変": True,
              "旧市場golden": "対象外", "未実施": ["C0への再生/推定変換", "入口差と保護効果の因果分解", "参加条件を満たす候補としての採用", "金融再実行"]}
    output = TRIAL / "検査/Source全4場/元Source参考損益.json"
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "合計": result["合計"], "path": output.relative_to(ROOT).as_posix()}, ensure_ascii=False))


if __name__ == "__main__":
    main()
