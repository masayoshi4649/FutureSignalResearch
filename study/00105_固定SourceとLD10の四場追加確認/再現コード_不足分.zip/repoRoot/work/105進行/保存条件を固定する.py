"""105金融完了後に、固定算術の保存実行条件を一度だけ作る。"""

import argparse
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]


def sha(path):
    """
    機能: 保存対象ではなく小さい固定参照の指紋を取得する。
    引数: path(Path)は条件・完了・コード等。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    """
    機能: 主金融の成功を確認し、保存器へ渡す3参照を固定する。
    引数: --stage(str)はfirst2又はfull4。
    返り値: None。金融未成功や既存先は拒否する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", required=True, choices=["first2", "full4"])
    args = parser.parse_args()
    phase = "先頭2場" if args.stage == "first2" else "全4場"
    count = 2 if args.stage == "first2" else 4
    condition = ROOT / "study/00105_固定SourceとLD10の四場追加確認/主金融条件.json"
    assert sha(condition) == "f13f90ecda3b3797d08c903017ad231abd267a9dad4ae2b7946c1ee713b8bb8e"
    completion = ROOT / "work/105LD10市場" / phase / "完了.json"
    done = json.loads(completion.read_text(encoding="utf-8-sig"))
    assert done["success"] and done["unchanged"] and done["stage"] == args.stage
    assert done["trial"] == 105 and done["sessions"] == count and done["books"] == 4 * count
    assert done["condition_sha256"] == sha(condition)
    code = ROOT / "work/105LD10の保存準備/集計.py"
    assert sha(code) == "5192dfd09bd22c3a9975273bcaedbc8778694b10635094effe7143c75fa549bd"
    stop = ROOT / "work/105LD10の保存準備/停止.json"
    assert sha(stop) == "b90facc5612b6412ffcb760c8972c6cc6ad678eecb5922aa1082d5ef5b4db606"
    destination = ROOT / "work/105保存の実行固定" / (args.stage + ".json")
    destination.parent.mkdir(parents=True, exist_ok=True)
    assert not destination.exists()
    value = {"version": 1, "trial": 105, "phase": "StageB", "fixed": True, "stage": args.stage}
    for name, path in {"condition": condition, "completion": completion, "code": code}.items():
        value[name] = {"path": path.as_posix(), "sha256": sha(path)}
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"path": destination.relative_to(ROOT).as_posix(), "sha256": sha(destination)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
