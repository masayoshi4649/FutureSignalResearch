"""111の元Source・24口座・確定足の接続を、市場を読まず検査して停止する。"""

import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DEPENDENCIES = {
    "111元時計の連続再現": "08b1331b372d5cd7e50d46d90c247a8fa9c6a9bf657105ff181928041f156946",
    "111元通知の連続Actor": "6503962ebb7189213a182f8801916e99503ddfa88d0a99426107f3755535cbf2",
    "111全玉利益と収束BBの純保護": "0042a6dc3f181150609deeca5b2c095c9f553d69fcaab1d833402ae31fdbc2c4",
    "111連続保護のチャート公開": "38c01e07d276310c6c1d803dca11e27979fc9286cf64d9a495e60485ea7264bd",
}


def digest(path: Path) -> str:
    """機能: 明示したファイルの全バイト指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def owned() -> dict:
    """機能: 所有するコード・説明だけの現物指紋を列挙する。

    引数: なし。
    返り値: dict[str,str]はリポジトリ相対pathとSHA256。
    """
    extensions = {".go", ".py", ".md"}
    return {
        path.relative_to(ROOT).as_posix(): digest(path)
        for path in sorted(HERE.rglob("*"))
        if path.is_file()
        and path.name != "停止.json"
        and (path.suffix in extensions or path.name in ("go.mod", "go.sum"))
        and not any(part in ("検査", "__pycache__") or part.startswith("人工_") for part in path.relative_to(HERE).parts)
    }


def execute(command: list[str], label: str, env: dict | None = None) -> dict:
    """機能: 市場を使わない検査の結果と出力を記録する。

    引数: command(list[str])、label(str)、env(dict|None)は起動内容。
    返り値: dictはコマンドと出力。失敗時は例外で止める。
    """
    result = subprocess.run(command, cwd=HERE, env=env, capture_output=True, text=True, encoding="utf-8")
    log = {"名": label, "command": command, "終了コード": result.returncode, "標準出力": result.stdout, "標準エラー": result.stderr}
    if result.returncode:
        raise ValueError(json.dumps(log, ensure_ascii=False))
    return log


def merge_map(target: dict, values: dict) -> None:
    """機能: 停止されたコード指紋を絶対位置へ正規化して統合する。

    引数: target(dict[str,str])、values(dict[str,str])は統合先と出典。
    返り値: None。同じ位置の指紋衝突・現物差は例外。
    """
    for name, expected in values.items():
        path = Path(name)
        path = (path if path.is_absolute() else ROOT / path).resolve()
        if len(expected) != 64 or digest(path) != expected:
            raise ValueError("停止コードの現物差: " + str(path))
        if str(path) in target and target[str(path)] != expected:
            raise ValueError("依存指紋の衝突: " + str(path))
        target[str(path)] = expected


def dependency_maps() -> tuple[dict, dict]:
    """機能: 四部品の固定停止と、その所有・Source全閉包を認証する。

    引数: なし。
    返り値: tuple[dict,dict]は停止参照と全コード指紋。
    """
    refs, codes = {}, {}
    for folder, expected in DEPENDENCIES.items():
        path = ROOT / "work" / folder / "停止.json"
        if digest(path) != expected:
            raise ValueError("部品の停止差: " + folder)
        value = json.loads(path.read_text(encoding="utf-8"))
        if not value.get("成功") or not value.get("停止"):
            raise ValueError("部品が未停止: " + folder)
        refs[folder] = {"path": str(path.resolve()), "sha256": expected}
        for key in ("所有コードSHA256", "再用コードSHA256", "Go閉包SHA256", "GoRootコードSHA256", "純戦略43SHA256"):
            merge_map(codes, value.get(key, {}))
    return refs, codes


def go_closure() -> tuple[dict, dict]:
    """機能: 実際の市場接続CLIの選択ソース閉包を取得する。

    引数: なし。
    返り値: tuple[dict,dict]は非GoRootとGoRootの指紋。
    """
    stream = execute(["go", "list", "-deps", "-json", "./cmd/run"], "実Go閉包")["標準出力"]
    decoder, index, local, standard = json.JSONDecoder(), 0, {}, {}
    while index < len(stream):
        while index < len(stream) and stream[index].isspace():
            index += 1
        if index == len(stream):
            break
        package, index = decoder.raw_decode(stream, index)
        if not package.get("Dir"):
            continue
        target = standard if package.get("Goroot") else local
        for key in ("GoFiles", "CgoFiles", "SFiles", "HFiles", "SysoFiles", "EmbedFiles"):
            for name in package.get(key, []):
                path = (Path(package["Dir"]) / name).resolve()
                target[str(path)] = digest(path)
        module = package.get("Module", {})
        if module.get("GoMod"):
            path = Path(module["GoMod"]).resolve()
            local[str(path)] = digest(path)
            if path.with_name("go.sum").exists():
                local[str(path.with_name("go.sum"))] = digest(path.with_name("go.sum"))
    return local, standard


def main() -> None:
    """機能: 人工・API・ビルド・全依存不変を確認し一度だけ停止する。

    引数: なし。実市場・原板・未見11/09は開かない。
    返り値: None。未成功を完了へ補完せず、既存停止を上書きしない。
    """
    if (HERE / "停止.json").exists():
        raise ValueError("停止記録を上書きしない")
    before = owned()
    for name in before:
        path = ROOT / name
        if path.suffix == ".py":
            for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    comment = ast.get_docstring(node) or ""
                    if "\n" not in comment or any(word not in comment for word in ("機能", "引数", "返り値")):
                        raise ValueError("Python関数コメント不足: " + node.name)
    refs, inherited = dependency_maps()
    local, standard = go_closure()
    all_codes = dict(inherited)
    merge_map(all_codes, local)
    merge_map(all_codes, standard)
    env = dict(os.environ, CGO_ENABLED="0", ARTIFICIAL111_OUT=str(HERE / "人工_停止版"))
    (HERE / "検査").mkdir(exist_ok=True)
    logs = [
        execute(["go", "test", "-json", "-count=1", "-cover", "./..."], "接続の全人工", env),
        execute(["go", "vet", "./..."], "vet", env),
        execute(["go", "build", "-o", str(HERE / "検査/111連続保護.exe"), "./cmd/run"], "市場CLIのbuild", env),
    ]
    tests = [json.loads(line) for line in logs[0]["標準出力"].splitlines() if line.startswith("{")]
    passed = [row for row in tests if row.get("Action") == "pass" and row.get("Test")]
    if len(passed) < 5:
        raise ValueError("接続の主人工が不足")
    doc = execute(["go", "doc", "-all", "."], "接続API")
    (HERE / "検査/API.txt").write_text(doc["標準出力"], encoding="utf-8")
    artificial = {str(p.resolve()): digest(p) for p in sorted((HERE / "人工_停止版").glob("*")) if p.is_file()}
    if len(artificial) != 3:
        raise ValueError("買売2本と人工宣言が必要")
    if owned() != before or any(digest(Path(path)) != sha for path, sha in all_codes.items()):
        raise ValueError("所有又は全依存コードの前後差")
    exe = HERE / "検査/111連続保護.exe"
    record = {
        "成功": True, "停止": True, "trial": 111,
        "UTC": datetime.now(timezone.utc).isoformat(),
        "範囲": "元Sourceを変更しない24会計・当場cold確定足・必須保護の接続と市場前ゲート。人工のみ",
        "所有コードSHA256": before, "Go閉包SHA256": local, "GoRootコードSHA256": standard,
        "部品停止": refs, "全固定コードSHA256": all_codes,
        "実行物": {"path": str(exe.resolve()), "sha256": digest(exe)},
        "人工SHA256": artificial, "主test": len(passed), "検査ログ": logs,
        "自己コード全依存前後不変": True,
        "市場実行": 0, "実原板読取": 0, "未見11月09日本文読取": 0,
        "当時保存Event同体": False, "全Signal全文同体": False,
        "採用": False, "研究目標達成": False,
    }
    (HERE / "停止.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "停止SHA256": digest(HERE / "停止.json"), "主test": len(passed), "exe": record["実行物"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
