package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"

	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	core "github.com/masayoshi4649/SessionTradeExecuter/continuousruntime111"
)

// run はRoot固定後だけ24口座の市場接続又は本文前認証を実行します。
//
// 引数: なし。CLIで固定Ref・段階・新規先・任意base54成功Refを受けます。
// 返り値: errorは固定・会計・対照・保存の不整合です。
func run() error {
	fixed := flag.String("fixed", "", "Rootの市場前固定")
	sha := flag.String("fixed-sha", "", "Root固定SHA256")
	stage := flag.String("stage", "", "metadata-only/first2/base54/full70")
	out := flag.String("out", "", "未使用出力先")
	prior := flag.String("prior54", "", "同条件base54の完了JSON")
	priorSHA := flag.String("prior54-sha", "", "base54完了SHA256")
	flag.Parse()
	if *fixed == "" || *sha == "" || *stage == "" || (*out == "" && *stage != "metadata-only") {
		return fmt.Errorf("固定Ref・段階・新規先が必要")
	}
	var previous *source.FileRef
	if *prior != "" || *priorSHA != "" {
		previous = &source.FileRef{Path: *prior, SHA256: *priorSHA}
	}
	ref := source.FileRef{Path: *fixed, SHA256: *sha}
	if *stage == "metadata-only" {
		plan, err := core.PrepareFixed(ref, *stage, previous)
		if err != nil {
			return err
		}
		return json.NewEncoder(os.Stdout).Encode(map[string]any{"metadata_verified": true, "financial_executed": false, "cases": len(plan.Source.Cases), "declared_books": 24, "historical_saved_events_equal": false})
	}
	result, err := core.RunFixed(ref, *stage, *out, previous)
	if err != nil {
		return err
	}
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"success": result.Success, "stage": result.Stage, "sessions": result.Sessions, "books": result.Books, "original_methods": result.OriginalMethods, "historical_saved_events_equal": false})
}

// main は不完了を成功へ読み替えず終了1で通知します。
//
// 引数: なし。
// 返り値: なし。成功0、不整合1です。
func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
