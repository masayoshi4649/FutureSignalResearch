package continuousruntime111

import (
	"compress/gzip"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"runtime"
	"sort"
	"strings"

	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	actor "github.com/masayoshi4649/SessionTradeExecuter/continuousactor111"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor111"
)

const ActualPolicy = "original166_continuous_24books_mandatory_protection"

// Fixed は停止Sourceの必須条件と、実接続する24口座のRoot固定を結びます。
type Fixed struct {
	source.Fixed
	ActualPolicy             string                    `json:"actual_policy"`
	ChartSeedMode            string                    `json:"chart_seed_mode"`
	EntryGridSeconds         *int                      `json:"entry_grid_seconds"`
	ExtraOpeningQuietSeconds int                       `json:"extra_opening_quiet_seconds"`
	ActualConfigurations     []actor.ActorConfig       `json:"actual_configurations"`
	PureConfigurations       []guard.Configuration     `json:"pure_configurations"`
	DependencyStops          map[string]source.FileRef `json:"dependency_stops"`
	ActualDeclaration        source.FileRef            `json:"actual_declaration"`
	PureDeclaration          source.FileRef            `json:"pure_declaration"`
	ChartDeclaration         source.FileRef            `json:"chart_declaration"`
}

// SceneResult は当場の24実口座と原文oracle照合を分けた保存参照です。
type SceneResult struct {
	Session         string              `json:"session"`
	Native          source.FileRef      `json:"native"`
	Golden          *source.GoldenProof `json:"original166_reference,omitempty"`
	Books           int                 `json:"books"`
	S0Comparisons   int                 `json:"S0_comparisons"`
	S0Equal         bool                `json:"S0_equal"`
	Complete        bool                `json:"complete"`
	OpenQuantity    int                 `json:"open_quantity"`
	PendingQuantity int                 `json:"pending_quantity"`
}

// Completion はbase54と同条件full70の新規保存だけを成功とする記録です。
type Completion struct {
	Version                    int               `json:"version"`
	Trial                      int               `json:"trial"`
	Stage                      string            `json:"stage"`
	Success                    bool              `json:"success"`
	ConditionSHA256            string            `json:"condition_sha256"`
	Sessions                   int               `json:"sessions"`
	ReusedSessions             int               `json:"reused_sessions"`
	ReplayedSessions           int               `json:"replayed_sessions"`
	Books                      int               `json:"books"`
	OriginalMethods            int               `json:"original_methods"`
	AllReferenceEventsEqual    bool              `json:"all_original166_reference_events_equal"`
	HistoricalSavedEventsEqual bool              `json:"historical_saved_events_equal"`
	AllSignalFullJSONEqual     bool              `json:"all_original_signal_full_json_equal"`
	Results                    []SceneResult     `json:"results"`
	Before                     map[string]string `json:"before"`
	After                      map[string]string `json:"after"`
	Unchanged                  bool              `json:"unchanged"`
	Prior54                    *source.FileRef   `json:"prior54,omitempty"`
}

// RunPlan は本文前認証済みのSource計画と実口座条件を保持します。
type RunPlan struct {
	Source  source.RunPlan
	Fixed   Fixed
	Stage   string
	Prior54 *Completion
}

// moduleDirectory は現在ビルドした接続moduleのコード位置を返します。
//
// 引数: なし。
// 返り値: string/errorは絶対module位置又はビルド元不明です。
func moduleDirectory() (string, error) {
	_, file, _, ok := runtime.Caller(0)
	if !ok {
		return "", fmt.Errorf("111接続のビルド元不明")
	}
	return filepath.Dir(file), nil
}

// readRef は期待SHAを確認してから小metadataを復元します。
//
// 引数: ref(source.FileRef)、value(any)は期待参照と復元先です。
// 返り値: errorは参照又はJSONの不一致です。
func readRef(ref source.FileRef, value any) error {
	if err := source.VerifyRef(ref); err != nil {
		return err
	}
	raw, err := os.ReadFile(ref.Path)
	if err != nil {
		return err
	}
	return json.Unmarshal(raw, value)
}

// RequiredCodePaths は実市場cmdの選択ソースと標準ライブラリの全閉包を取得します。
//
// 引数: なし。go listだけを接続module位置で実行し、入力本文は読みません。
// 返り値: []string/errorはGo/asm/embed/moduleの絶対位置又は取得失敗です。
func RequiredCodePaths() ([]string, error) {
	base, err := moduleDirectory()
	if err != nil {
		return nil, err
	}
	cmd := exec.Command("go", "list", "-deps", "-json", "./cmd/run")
	cmd.Dir = base
	cmd.Env = append(os.Environ(), "GOWORK=off", "CGO_ENABLED=0")
	raw, err := cmd.Output()
	if err != nil {
		return nil, fmt.Errorf("実Go閉包の取得失敗:%w", err)
	}
	decoder := json.NewDecoder(strings.NewReader(string(raw)))
	paths := map[string]bool{}
	for {
		var p struct {
			Dir                                                      string
			GoFiles, CgoFiles, SFiles, HFiles, SysoFiles, EmbedFiles []string
			Module                                                   *struct{ GoMod string }
		}
		if err = decoder.Decode(&p); err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
		if p.Dir == "" {
			continue
		}
		for _, names := range [][]string{p.GoFiles, p.CgoFiles, p.SFiles, p.HFiles, p.SysoFiles, p.EmbedFiles} {
			for _, name := range names {
				paths[filepath.Clean(filepath.Join(p.Dir, name))] = true
			}
		}
		if p.Module != nil && p.Module.GoMod != "" {
			paths[filepath.Clean(p.Module.GoMod)] = true
			sum := filepath.Join(filepath.Dir(p.Module.GoMod), "go.sum")
			if _, e := os.Stat(sum); e == nil {
				paths[sum] = true
			}
		}
	}
	out := []string{}
	for path := range paths {
		out = append(out, path)
	}
	sort.Strings(out)
	if len(out) < 100 {
		return nil, fmt.Errorf("実Go閉包が不足")
	}
	return out, nil
}

// dependencySpecifications は変更不可の四停止の位置と指紋を返します。
//
// 引数: なし。
// 返り値: map[string]source.FileRef/errorは固定停止又は位置解決失敗です。
func dependencySpecifications() (map[string]source.FileRef, error) {
	base, err := moduleDirectory()
	if err != nil {
		return nil, err
	}
	refs := map[string]source.FileRef{}
	for key, pair := range map[string][2]string{
		"source": {"111元時計の連続再現", "08b1331b372d5cd7e50d46d90c247a8fa9c6a9bf657105ff181928041f156946"},
		"actor":  {"111元通知の連続Actor", "6503962ebb7189213a182f8801916e99503ddfa88d0a99426107f3755535cbf2"},
		"pure":   {"111全玉利益と収束BBの純保護", "0042a6dc3f181150609deeca5b2c095c9f553d69fcaab1d833402ae31fdbc2c4"},
		"chart":  {"111連続保護のチャート公開", "38c01e07d276310c6c1d803dca11e27979fc9286cf64d9a495e60485ea7264bd"},
	} {
		refs[key] = source.FileRef{Path: filepath.Clean(filepath.Join(base, "..", pair[0], "停止.json")), SHA256: pair[1]}
	}
	return refs, nil
}

// checkDependencies は四停止の所有・再用・全Source閉包を固定mapへ要求します。
//
// 引数: fixed(Fixed)、before(map[string]string)はRoot固定と前指紋です。
// 返り値: errorは未固定部品・実宣言・停止後現物の差です。
func checkDependencies(fixed Fixed, before map[string]string) error {
	expected, err := dependencySpecifications()
	if err != nil {
		return err
	}
	if !reflect.DeepEqual(fixed.DependencyStops, expected) {
		return fmt.Errorf("四停止の参照集合差")
	}
	base, _ := moduleDirectory()
	root := filepath.Clean(filepath.Join(base, "../.."))
	for key, ref := range expected {
		var stop map[string]json.RawMessage
		if err = readRef(ref, &stop); err != nil {
			return err
		}
		var success, stopped bool
		if json.Unmarshal(stop["成功"], &success) != nil || json.Unmarshal(stop["停止"], &stopped) != nil || !success || !stopped {
			return fmt.Errorf("未成功停止:%s", key)
		}
		before[ref.Path] = ref.SHA256
		for _, name := range []string{"所有コードSHA256", "再用コードSHA256", "Go閉包SHA256", "GoRootコードSHA256", "純戦略43SHA256"} {
			if raw, ok := stop[name]; ok {
				var codes map[string]string
				if err = json.Unmarshal(raw, &codes); err != nil {
					return err
				}
				for path, sha := range codes {
					if !filepath.IsAbs(path) {
						path = filepath.Join(root, filepath.FromSlash(path))
					}
					path = filepath.Clean(path)
					if fixed.CodeSHA256[path] != sha {
						return fmt.Errorf("四停止codeの固定漏れ/差:%s", path)
					}
				}
			}
		}
		if key == "actor" || key == "pure" || key == "chart" {
			var declaration source.FileRef
			declarationKey := "実宣言"
			if key == "chart" {
				declarationKey = "実API宣言"
			}
			if err = json.Unmarshal(stop[declarationKey], &declaration); err != nil {
				return err
			}
			actual := fixed.ChartDeclaration
			if key == "actor" {
				actual = fixed.ActualDeclaration
			}
			if key == "pure" {
				actual = fixed.PureDeclaration
			}
			if actual != declaration {
				return fmt.Errorf("実宣言の停止参照差:%s", key)
			}
			if err = source.VerifyRef(actual); err != nil {
				return err
			}
			before[actual.Path] = actual.SHA256
		}
	}
	var actual []actor.ActorConfig
	var pure struct {
		Configurations []guard.Configuration `json:"configurations"`
	}
	if err = readRef(fixed.ActualDeclaration, &actual); err != nil {
		return err
	}
	if err = readRef(fixed.PureDeclaration, &pure); err != nil {
		return err
	}
	if !reflect.DeepEqual(actual, actor.DeclaredContinuousConfigurations()) || !reflect.DeepEqual(pure.Configurations, guard.DeclaredConfigurations()) {
		return fmt.Errorf("停止実宣言と現在の24条件差")
	}
	return nil
}

// validateOracleReference は当時保存との同体を主張せず原文再実行出典を認証します。
//
// 引数: ref(source.FileRef)、session(source.Session)は原文対照と対象場です。
// 返り値: errorは元100micro/10mini・出典・終了残の差です。
func validateOracleReference(ref source.FileRef, session source.Session) error {
	if err := source.ValidateGoldenRef(ref, session); err != nil {
		return err
	}
	var value struct {
		Mini   []source.GoldenResult `json:"mini_results"`
		Origin struct {
			Kind       string `json:"kind"`
			FAR        string `json:"FAR_commit"`
			Strategy   string `json:"strategy_commit"`
			Main       string `json:"main_git_blob_sha"`
			Input      string `json:"input_git_blob_sha"`
			Unchanged  bool   `json:"run_body_unchanged"`
			Historical bool   `json:"historical_saved_events"`
		} `json:"origin"`
	}
	if err := readRef(ref, &value); err != nil {
		return err
	}
	o := value.Origin
	if o.Kind != "rerun_original166_pinned_code" || o.FAR != "cf0717daa1eed78759f78a428bce50129e7f705b" || o.Strategy != "67ba01588a60961ce2fb505ee5654999473dedab" || o.Main != "6d8f1a63c94006e6cf7e80c9e988f06d995e2acb" || o.Input != "784579f65444f1377d41354aa4458783a3d2bcf1" || !o.Unchanged || o.Historical {
		return fmt.Errorf("元原文oracleの出典不足")
	}
	methods := []string{"NK225_D164_15"}
	if strings.HasSuffix(session.ID, "_Night") {
		methods = []string{"NK225_P164_06", "NK225_U165_03"}
	}
	if len(value.Mini) != len(methods) {
		return fmt.Errorf("元mini対照の手法数差")
	}
	seen := map[string]bool{}
	for _, r := range value.Mini {
		if r.Session != session.ID || r.Cap != 10 || r.Held != 0 || r.Pending != 0 || r.Error != "" || len(r.Differences) != 0 || math.IsNaN(r.Gross) || math.IsInf(r.Gross, 0) || seen[r.Method] {
			return fmt.Errorf("元mini対照が不成功")
		}
		seen[r.Method] = true
	}
	for _, method := range methods {
		if !seen[method] {
			return fmt.Errorf("元mini対照の手法集合差")
		}
	}
	return nil
}

// PrepareFixed はSourceの本文前認証に実閉包・24宣言・段階gateを追加します。
//
// 引数: condition(source.FileRef)、stage(string)、prior54(*source.FileRef|nil)は固定・段階・base54成功です。
// 返り値: RunPlan/errorは本文未読の計画又は固定差です。
func PrepareFixed(condition source.FileRef, stage string, prior54 *source.FileRef) (RunPlan, error) {
	plan := RunPlan{Stage: stage}
	s, err := source.PrepareMetadata(condition)
	if err != nil {
		return plan, err
	}
	plan.Source = s
	if err = readRef(condition, &plan.Fixed); err != nil {
		return plan, err
	}
	f := plan.Fixed
	var fields map[string]json.RawMessage
	if err = readRef(condition, &fields); err != nil {
		return plan, err
	}
	if f.ActualPolicy != ActualPolicy || f.ChartSeedMode != "cold_each_session" || f.EntryGridSeconds != nil || f.ExtraOpeningQuietSeconds != 0 ||
		string(fields["entry_grid_seconds"]) != "null" || fields["extra_opening_quiet_seconds"] == nil ||
		!reflect.DeepEqual(f.ActualConfigurations, actor.DeclaredContinuousConfigurations()) ||
		!reflect.DeepEqual(f.PureConfigurations, guard.DeclaredConfigurations()) {
		return plan, fmt.Errorf("111実口座政策/時計/cold/24宣言の差")
	}
	if err = checkDependencies(f, s.Before); err != nil {
		return plan, err
	}
	if err = source.VerifyRef(f.OracleExecutable); err != nil {
		return plan, err
	}
	s.Before[f.OracleExecutable.Path] = f.OracleExecutable.SHA256
	paths, err := RequiredCodePaths()
	if err != nil {
		return plan, err
	}
	for _, path := range paths {
		if _, ok := f.CodeSHA256[path]; !ok {
			return plan, fmt.Errorf("実Go閉包の固定漏れ:%s", path)
		}
	}
	count := 0
	switch stage {
	case "metadata-only":
		count = 70
	case "first2":
		count = 2
	case "base54":
		count = 54
	case "full70":
		count = 70
	default:
		return plan, fmt.Errorf("段階はmetadata-only/first2/base54/full70")
	}
	if stage != "metadata-only" {
		expected := 54
		if stage == "first2" && len(f.Golden) == 2 {
			expected = 2
		}
		if len(f.Golden) != expected {
			return plan, fmt.Errorf("元対照はfirst2で2又は54、base54/full70で54が必要")
		}
		for _, input := range s.Manifest.Sessions[:expected] {
			ref, ok := f.Golden[input.ID]
			if !ok {
				return plan, fmt.Errorf("元原文対照の欠落:%s", input.ID)
			}
			session, e := source.SessionFor(input.ID)
			if e != nil {
				return plan, e
			}
			if e = validateOracleReference(ref, session); e != nil {
				return plan, e
			}
			s.Before[ref.Path] = ref.SHA256
		}
	}
	s.Cases = append([]source.InputCase(nil), s.Manifest.Sessions[:count]...)
	s.Stage = stage
	plan.Source = s
	if stage == "full70" {
		if prior54 == nil {
			return plan, fmt.Errorf("同条件base54成功を先に要求")
		}
		var old Completion
		if err = readRef(*prior54, &old); err != nil {
			return plan, err
		}
		if err = validatePrior54(old, condition, s); err != nil {
			return plan, err
		}
		plan.Prior54 = &old
		s.Before[prior54.Path] = prior54.SHA256
		for _, row := range old.Results {
			s.Before[row.Native.Path] = row.Native.SHA256
		}
	} else if prior54 != nil {
		return plan, fmt.Errorf("prior54はfull70のみ")
	}
	plan.Source = s
	return plan, nil
}

// validatePrior54 は全70の前提となる同条件base54の成功記録を認証します。
//
// 引数: old(Completion)、condition(source.FileRef)、plan(source.RunPlan)は先行成功・今回固定・本文前計画です。
// 返り値: errorは固定/24N/全残量/前後同体/全54Native参照の差です。
func validatePrior54(old Completion, condition source.FileRef, plan source.RunPlan) error {
	if old.Version != 1 || old.Trial != 111 || !old.Success || old.Stage != "base54" || old.ConditionSHA256 != condition.SHA256 ||
		old.Sessions != 54 || old.Books != 1296 || old.OriginalMethods != 81 || !old.AllReferenceEventsEqual ||
		old.ReusedSessions != 0 || old.ReplayedSessions != 54 ||
		old.HistoricalSavedEventsEqual || old.AllSignalFullJSONEqual || !old.Unchanged || len(old.Results) != 54 ||
		!reflect.DeepEqual(old.Before, old.After) || !reflect.DeepEqual(old.Before, plan.Before) {
		return fmt.Errorf("同じ固定条件の全base54成功ではない")
	}
	for i, row := range old.Results {
		methods := 1
		if strings.HasSuffix(row.Session, "_Night") {
			methods = 2
		}
		if row.Session != plan.Manifest.Sessions[i].ID || row.Books != 24 || row.S0Comparisons != 4 || !row.S0Equal || !row.Complete || row.OpenQuantity != 0 || row.PendingQuantity != 0 ||
			row.Golden == nil || !row.Golden.EventsEqual || !row.Golden.MiniEventsEqual || row.Golden.ReferenceKind != "rerun_original166_pinned_code" ||
			row.Golden.Session != row.Session || row.Golden.Methods != methods || row.Golden.HistoricalSavedEventsEqual || row.Golden.AllSignalEqual || row.Golden.Reference != plan.Fixed.Golden[row.Session] {
			return fmt.Errorf("base54の場別成功・残量・元Event対照差")
		}
		if err := source.VerifyRef(row.Native); err != nil {
			return err
		}
	}
	return nil
}

// CheckReplay は金融結果が固定24条件で完結したことだけを検査します。
//
// 引数: value(ReplayResult)、fixed(Fixed)は同原行接続結果と事前固定です。
// 返り値: errorは24口座・S0対照・残量・時計の差です。金融額による候補選別はしません。
func CheckReplay(value ReplayResult, fixed Fixed) error {
	a := value.Actual
	if !value.Source.Complete || !a.Complete || !value.S0Equal || value.S0Comparisons != 4 || value.OriginalHistoricalEventsEqual ||
		len(a.Books) != 24 || !reflect.DeepEqual(a.Configurations, fixed.ActualConfigurations) || a.EntryGridSeconds != nil ||
		a.ExtraOpeningQuietSeconds != 0 || a.ExplicitTimers != 0 || a.ChartSeedMode != "cold_each_session" || a.FinalChart.CarriedNumericSeed ||
		a.Scope.Session.ID != value.Source.Session.ID || a.Scope.Contract != value.Source.Contract {
		return fmt.Errorf("111接続の24口座又は原時計の完結差")
	}
	for _, config := range fixed.ActualConfigurations {
		key := fmt.Sprintf("%s_C%.0f_D%d", config.Policy, config.SlipPts, config.DelaySeconds)
		b, ok := a.Books[key]
		if !ok || b.Key != key || b.Config != config || !b.Complete || !b.Finished || b.Failure != "" ||
			b.Totals.OpenBuy != 0 || b.Totals.OpenSell != 0 || b.Totals.PendingBuy != 0 || b.Totals.PendingSell != 0 ||
			b.Totals.OpenEntryCostsYen != 0 || b.Totals.EntryQuantity != b.Totals.CloseQuantity || b.Totals.NetYen != b.Totals.ClosedNetYen {
			return fmt.Errorf("111口座の宣言又は終了残:%s", key)
		}
		for _, p := range b.Positions {
			if p.Quantity != 0 || p.Reserved != 0 {
				return fmt.Errorf("111建玉の終了残:%s", key)
			}
		}
	}
	return nil
}

// saveNew は新規ファイルだけへ正準JSONを保存し同bytes用の指紋を返します。
//
// 引数: path(string)、value(any)、compressed(bool)は新規先・値・gzip指定です。
// 返り値: source.FileRef/errorは保存物又は既存先/書込異常です。
func saveNew(path string, value any, compressed bool) (source.FileRef, error) {
	raw, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return source.FileRef{}, err
	}
	raw = append(raw, '\n')
	f, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if err != nil {
		return source.FileRef{}, err
	}
	if compressed {
		z := gzip.NewWriter(f)
		_, err = z.Write(raw)
		if e := z.Close(); err == nil {
			err = e
		}
	} else {
		_, err = f.Write(raw)
	}
	if e := f.Close(); err == nil {
		err = e
	}
	if err != nil {
		return source.FileRef{}, err
	}
	sha, err := source.Digest(path)
	return source.FileRef{Path: path, SHA256: sha}, err
}

// RunFixed は固定元Sourceを一読し同じ通知を全24Actorへ配送して新規保存します。
//
// 引数: condition(source.FileRef)、stage/out(string)、prior54(*source.FileRef|nil)はRoot固定・段階・未使用先・先行成功です。
// 返り値: Completion/errorは全金融と元Event対照の成功又は不完了です。市場起動はRootが行います。
func RunFixed(condition source.FileRef, stage, out string, prior54 *source.FileRef) (complete Completion, err error) {
	complete = Completion{Version: 1, Trial: 111, Stage: stage, ConditionSHA256: condition.SHA256, Results: []SceneResult{}, Prior54: prior54}
	if stage == "metadata-only" {
		return complete, fmt.Errorf("metadata-onlyはPrepareFixedを使用")
	}
	plan, err := PrepareFixed(condition, stage, prior54)
	if err != nil {
		return complete, err
	}
	absolute, err := filepath.Abs(out)
	if err != nil {
		return complete, err
	}
	if _, e := os.Stat(absolute); !os.IsNotExist(e) {
		return complete, fmt.Errorf("保存先は未使用folder")
	}
	if err = os.MkdirAll(absolute, 0755); err != nil {
		return complete, err
	}
	current := ""
	defer func() {
		if err != nil {
			complete.Success = false
			_, _ = saveNew(filepath.Join(absolute, "不完了.json"), map[string]any{"version": 1, "trial": 111, "success": false, "stage": stage, "condition_sha256": condition.SHA256, "session": current, "saved_sessions": len(complete.Results), "reused_sessions": complete.ReusedSessions, "replayed_sessions": complete.ReplayedSessions, "error": err.Error(), "results": complete.Results, "before": plan.Source.Before}, false)
		}
	}()
	complete.Before = plan.Source.Before
	for i, input := range plan.Source.Cases {
		current = input.ID
		if plan.Prior54 != nil && i < 54 {
			row := copyValue(plan.Prior54.Results[i])
			complete.Results = append(complete.Results, row)
			complete.Books += row.Books
			complete.OriginalMethods += row.Golden.Methods
			complete.ReusedSessions++
			fmt.Printf("%d/%d %s 認証済みbase54 Native参照を再用\n", i+1, len(plan.Source.Cases), input.ID)
			continue
		}
		// ----------------------------------------
		// 全70では追加16だけを新しく再生し、認証済み54場のRawを再読しません。
		consumer := New()
		var original source.ReplayResult
		original, err = source.ReplayWithConsumer(plan.Source.Manifest.Root, input, consumer)
		if err != nil {
			return complete, err
		}
		var combined ReplayResult
		combined, err = ConnectResult(original, consumer)
		if err != nil {
			return complete, err
		}
		if err = CheckReplay(combined, plan.Fixed); err != nil {
			return complete, err
		}
		var proof *source.GoldenProof
		if i < 54 {
			var p source.GoldenProof
			p, err = source.CompareGolden(original, plan.Fixed.Golden[input.ID])
			if err != nil {
				return complete, err
			}
			if !p.EventsEqual || !p.MiniEventsEqual || p.ReferenceKind != "rerun_original166_pinned_code" || p.HistoricalSavedEventsEqual || p.AllSignalEqual {
				return complete, fmt.Errorf("原文再実行対照の範囲差")
			}
			proof = &p
			complete.OriginalMethods += p.Methods
		}
		var ref source.FileRef
		ref, err = saveNew(filepath.Join(absolute, input.ID+".Native.json.gz"), combined, true)
		if err != nil {
			return complete, err
		}
		complete.Results = append(complete.Results, SceneResult{Session: input.ID, Native: ref, Golden: proof, Books: 24, S0Comparisons: 4, S0Equal: true, Complete: true})
		complete.Books += 24
		complete.ReplayedSessions++
		fmt.Printf("%d/%d %s 24口座完結・元対照=%t\n", i+1, len(plan.Source.Cases), input.ID, proof != nil)
	}
	complete.After = map[string]string{}
	for path, sha := range complete.Before {
		var got string
		got, err = source.Digest(path)
		if err != nil {
			return complete, err
		}
		if got != sha {
			return complete, fmt.Errorf("固定入力/code/対照の実行前後差:%s", path)
		}
		complete.After[path] = got
	}
	complete.Unchanged = true
	complete.Sessions = len(plan.Source.Cases)
	if (stage == "full70" && (complete.ReusedSessions != 54 || complete.ReplayedSessions != 16)) ||
		(stage != "full70" && (complete.ReusedSessions != 0 || complete.ReplayedSessions != complete.Sessions)) {
		return complete, fmt.Errorf("認証済み再用と今回再生の場数差")
	}
	if (stage == "first2" && complete.OriginalMethods != 3) || (stage != "first2" && complete.OriginalMethods != 81) {
		return complete, fmt.Errorf("原文対照の全手法場数差")
	}
	complete.AllReferenceEventsEqual = true
	complete.Success = true
	_, err = saveNew(filepath.Join(absolute, "完了.json"), complete, false)
	return complete, err
}
