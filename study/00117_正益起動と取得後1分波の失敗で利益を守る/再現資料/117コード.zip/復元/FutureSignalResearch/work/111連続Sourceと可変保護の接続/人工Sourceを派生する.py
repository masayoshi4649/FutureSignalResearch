"""94の手製Source通知器具だけを、111接続の人工へ同体再用する。"""

import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent


def extract(text: str, marker: str, label: str) -> str:
    """機能: 整形済みGoの一つの宣言と直前の複数行コメントを取り出す。

    引数: text/marker/label(str)は元本文・一意な宣言先頭・検査名。
    返り値: strは本文。元の市場Sourceや実結果は実行しない。
    """
    matches = list(re.finditer(marker, text, flags=re.M))
    assert len(matches) == 1, label
    begin = matches[0].start()
    end = re.search(r"^}\s*$", text[matches[0].end():], flags=re.M)
    assert end is not None, label
    finish = matches[0].end() + end.end()
    previous = text[:begin].splitlines(keepends=True)
    while previous and previous[-1].lstrip().startswith("//"):
        begin -= len(previous.pop())
    return text[begin:finish].rstrip() + "\n"


def main() -> None:
    """機能: 手製の出生/返済器具を新規の試験ファイルへ保存する。

    引数: なし。固定94のactual_test.goとactual.goだけを参照する。
    返り値: None。市場、原板、11/09入力を開かず、元ファイルを変更しない。
    """
    originals = [ROOT / "scripts/FAR連続出生と個別利益追尾" / name
                 for name in ("actual_test.go", "actual.go")]
    before = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in originals}
    test, body = (p.read_text(encoding="utf-8-sig") for p in originals)
    declarations = [extract(test, r"^type fixtureSource94 struct", "器具型")]
    for name in ("newFixtureSource94", "session94", "observation94", "birth94", "close94"):
        declarations.append(extract(test, r"^func " + name + r"\(", name))
    declarations.append(extract(test, r"^func \(s \*fixtureSource94\) step\(", "人工通知"))
    for name in ("finiteActual", "quoteActual", "normalActual"):
        declarations.append(extract(body, r"^func " + name + r"\(", name))
    header = '''// 94の手製API通知器具だけの同体派生です。FAR自然生成や市場実績ではありません。
package continuousruntime111

import (
 "encoding/json"
 "math"
 "testing"
 "time"
 "github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
 native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
 protect "github.com/masayoshi4649/SessionTradeExecuter/miniprotect"
)

type Observation = native.Observation
type Session = native.Session
type QuoteStamp = native.QuoteStamp
type NativeBatch = protect.NativeBatch
type sourceEvidence struct {
 Kind string `json:"kind"`
 Parent string `json:"parent"`
 SourceID string `json:"source_id"`
 Method string `json:"method"`
 QuantityMicro int `json:"quantity_micro"`
}

'''
    output = HERE / "source_fixture_test.go"
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(header + "\n".join(declarations))
    assert before == {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in originals}
    proof = {"試行": 111, "元ファイル": before, "元前後不変": True,
             "範囲": "手製通知/所有器具のみ。実Source戦略の出生生成ではない", "宣言数": len(declarations)}
    with (HERE / "人工Sourceの派生記録.json").open("x", encoding="utf-8") as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


if __name__ == "__main__":
    main()
