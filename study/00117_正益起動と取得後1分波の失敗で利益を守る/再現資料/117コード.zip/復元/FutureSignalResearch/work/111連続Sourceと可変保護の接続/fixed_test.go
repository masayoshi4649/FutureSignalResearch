package continuousruntime111

import (
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	actor "github.com/masayoshi4649/SessionTradeExecuter/continuousactor111"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor111"
)

// fixtureRef は手製metadataだけを新規保存します。
//
// 引数: t(*testing.T)、path(string)、value(any)は試験器・新規先・人工値です。
// 返り値: source.FileRefは保存した期待指紋です。
func fixtureRef(t *testing.T, path string, value any) source.FileRef {
	t.Helper()
	if err := os.MkdirAll(filepath.Dir(path), 0755); err != nil {
		t.Fatal(err)
	}
	ref, err := saveNew(path, value, false)
	if err != nil {
		t.Fatal(err)
	}
	return ref
}

// fixtureFixed は未作成Rawを参照する70場と実コードだけの人工固定を作ります。
//
// 引数: t(*testing.T)、base(string)は試験器と隔離された人工先です。
// 返り値: FixedはRoot固定schemaの手製条件です。原板本文は読みません。
func fixtureFixed(t *testing.T, base string) Fixed {
	t.Helper()
	root, err := moduleDirectory()
	if err != nil {
		t.Fatal(err)
	}
	root = filepath.Clean(filepath.Join(root, "../.."))
	raw, err := os.ReadFile(filepath.Join(root, "study/00106_収束失速で保護の起動と幅を切り替える/入力台帳_70場.json"))
	if err != nil {
		t.Fatal(err)
	}
	var manifest source.InputManifest
	if err = json.Unmarshal(raw, &manifest); err != nil {
		t.Fatal(err)
	}
	manifest.Root = filepath.Join(base, "作らないRaw")
	exe, err := os.Executable()
	if err != nil {
		t.Fatal(err)
	}
	sha, err := source.Digest(exe)
	if err != nil {
		t.Fatal(err)
	}
	f := Fixed{Fixed: source.Fixed{Version: 1, Trial: 111, Fixed: true, Policy: "original166_continuous_baseline",
		FARCommit: "cf0717daa1eed78759f78a428bce50129e7f705b", StrategyCommit: "67ba01588a60961ce2fb505ee5654999473dedab",
		Executable: source.FileRef{Path: exe, SHA256: sha}, OracleExecutable: source.FileRef{Path: exe, SHA256: sha},
		CodeSHA256: map[string]string{}, Golden: map[string]source.FileRef{}},
		ActualPolicy: ActualPolicy, ChartSeedMode: "cold_each_session",
		ActualConfigurations: actor.DeclaredContinuousConfigurations(), PureConfigurations: guard.DeclaredConfigurations()}
	f.Manifest = fixtureRef(t, filepath.Join(base, "手製70台帳.json"), manifest)
	f.DependencyStops, err = dependencySpecifications()
	if err != nil {
		t.Fatal(err)
	}
	for key, ref := range f.DependencyStops {
		var stop map[string]json.RawMessage
		if err = readRef(ref, &stop); err != nil {
			t.Fatal(err)
		}
		for _, name := range []string{"所有コードSHA256", "再用コードSHA256", "Go閉包SHA256", "GoRootコードSHA256", "純戦略43SHA256"} {
			if value, ok := stop[name]; ok {
				var codes map[string]string
				if err = json.Unmarshal(value, &codes); err != nil {
					t.Fatal(err)
				}
				for path, sha := range codes {
					if !filepath.IsAbs(path) {
						path = filepath.Join(root, filepath.FromSlash(path))
					}
					f.CodeSHA256[filepath.Clean(path)] = sha
				}
			}
		}
		var declaration source.FileRef
		declarationKey := "実宣言"
		if key == "chart" {
			declarationKey = "実API宣言"
		}
		_ = json.Unmarshal(stop[declarationKey], &declaration)
		switch key {
		case "actor":
			f.ActualDeclaration = declaration
		case "pure":
			f.PureDeclaration = declaration
		case "chart":
			f.ChartDeclaration = declaration
		}
	}
	paths, err := RequiredCodePaths()
	if err != nil {
		t.Fatal(err)
	}
	for _, path := range paths {
		sha, e := source.Digest(path)
		if e != nil {
			t.Fatal(e)
		}
		f.CodeSHA256[path] = sha
	}
	return f
}

// addFixtureReferences は空Eventの手製原文形式を必要場数だけ追加します。
//
// 引数: t(*testing.T)、base(string)、f(*Fixed)、count(int)は試験器・人工先・対象固定・場数です。
// 返り値: なし。自然発生したFAR判断や当時保存Eventを作ったとは扱いません。
func addFixtureReferences(t *testing.T, base string, f *Fixed, count int) {
	t.Helper()
	var manifest source.InputManifest
	if err := readRef(f.Manifest, &manifest); err != nil {
		t.Fatal(err)
	}
	f.Golden = map[string]source.FileRef{}
	for _, scene := range manifest.Sessions[:count] {
		methods := []string{"NK225_D164_15"}
		if strings.HasSuffix(scene.ID, "_Night") {
			methods = []string{"NK225_P164_06", "NK225_U165_03"}
		}
		micro, mini := []source.GoldenResult{}, []source.GoldenResult{}
		for _, method := range methods {
			micro = append(micro, source.GoldenResult{Session: scene.ID, Method: method, Cap: 100})
			mini = append(mini, source.GoldenResult{Session: scene.ID, Method: method, Cap: 10})
		}
		f.Golden[scene.ID] = fixtureRef(t, filepath.Join(base, scene.ID+".json"), map[string]any{
			"Results": micro, "mini_results": mini, "Error": "<nil>", "origin": map[string]any{
				"kind": "rerun_original166_pinned_code", "FAR_commit": f.FARCommit, "strategy_commit": f.StrategyCommit,
				"main_git_blob_sha": "6d8f1a63c94006e6cf7e80c9e988f06d995e2acb", "input_git_blob_sha": "784579f65444f1377d41354aa4458783a3d2bcf1",
				"run_body_unchanged": true, "historical_saved_events": false}})
	}
}

// TestRuntimeMetadataBeforeRaw は24宣言と全閉包の認証だけでRawを開かないことを確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。金融成功ではなくmetadata成功だけを確認します。
func TestRuntimeMetadataBeforeRaw(t *testing.T) {
	base := t.TempDir()
	f := fixtureFixed(t, base)
	ref := fixtureRef(t, filepath.Join(base, "固定.json"), f)
	plan, err := PrepareFixed(ref, "metadata-only", nil)
	if err != nil || len(plan.Source.Cases) != 70 {
		t.Fatal(err)
	}
	if _, err = os.Stat(plan.Source.Manifest.Root); !os.IsNotExist(err) {
		t.Fatal("本文前認証がRawを作成")
	}
	if len(f.CodeSHA256) < 800 || len(f.ActualConfigurations) != 24 || len(f.PureConfigurations) != 24 {
		t.Fatal("全閉包又は実宣言不足")
	}
}

// TestRuntimeRejectsUndeclaredBeforeRaw は時計・政策・費用・依存の逸脱を本文前に拒否します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。各破壊は新しい条件SHAでも拒否されます。
func TestRuntimeRejectsUndeclaredBeforeRaw(t *testing.T) {
	base := t.TempDir()
	original := fixtureFixed(t, base)
	for _, name := range []string{"政策", "時計", "静観", "seed", "24口座", "費用", "純宣言", "停止", "実閉包欠落", "実宣言差", "未固定", "null省略"} {
		t.Run(name, func(t *testing.T) {
			f := copyValue(original)
			switch name {
			case "政策":
				f.ActualPolicy = "別政策"
			case "時計":
				n := 300
				f.EntryGridSeconds = &n
			case "静観":
				f.ExtraOpeningQuietSeconds = 1200
			case "seed":
				f.ChartSeedMode = "carry"
			case "24口座":
				f.ActualConfigurations = f.ActualConfigurations[:23]
			case "費用":
				f.ActualConfigurations[0].SlipPts = 10
			case "純宣言":
				f.PureConfigurations[0].Policy = guard.B50
			case "停止":
				r := f.DependencyStops["actor"]
				r.SHA256 = strings.Repeat("0", 64)
				f.DependencyStops["actor"] = r
			case "実閉包欠落":
				here, _ := moduleDirectory()
				delete(f.CodeSHA256, filepath.Join(here, "runtime.go"))
			case "実宣言差":
				f.ActualDeclaration = f.PureDeclaration
			case "未固定":
				f.Fixed.Fixed = false
			}
			var value any = f
			if name == "null省略" {
				raw, _ := json.Marshal(f)
				m := map[string]any{}
				_ = json.Unmarshal(raw, &m)
				delete(m, "entry_grid_seconds")
				value = m
			}
			ref := fixtureRef(t, filepath.Join(base, name+".json"), value)
			if _, err := PrepareFixed(ref, "metadata-only", nil); err == nil {
				t.Fatal("破壊固定を受理")
			}
		})
	}
}

// TestRuntimeStagesAndOracleProvenance はfirst2の二参照とbase54の全参照を区別します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。架空Rawは存在せず原文形式の小対照だけを使います。
func TestRuntimeStagesAndOracleProvenance(t *testing.T) {
	base := t.TempDir()
	f := fixtureFixed(t, base)
	addFixtureReferences(t, filepath.Join(base, "二対照"), &f, 2)
	ref := fixtureRef(t, filepath.Join(base, "F1.json"), f)
	first, err := PrepareFixed(ref, "first2", nil)
	if err != nil || len(first.Source.Cases) != 2 {
		t.Fatal(err)
	}
	if _, err = PrepareFixed(ref, "base54", nil); err == nil {
		t.Fatal("二対照でbase54を許可")
	}
	addFixtureReferences(t, filepath.Join(base, "全対照"), &f, 54)
	ref = fixtureRef(t, filepath.Join(base, "F2.json"), f)
	all, err := PrepareFixed(ref, "base54", nil)
	if err != nil || len(all.Source.Cases) != 54 {
		t.Fatal(err)
	}
	if _, err = PrepareFixed(ref, "full70", nil); err == nil {
		t.Fatal("base54未完で全70を許可")
	}
	bad := copyValue(f)
	bad.Golden[first.Source.Cases[0].ID] = fixtureRef(t, filepath.Join(base, "出典なし.json"), map[string]any{"Results": []source.GoldenResult{{Session: first.Source.Cases[0].ID, Method: "NK225_D164_15", Cap: 100}}})
	if _, err = PrepareFixed(fixtureRef(t, filepath.Join(base, "出典破壊.json"), bad), "base54", nil); err == nil {
		t.Fatal("出典なしを原文oracleと認定")
	}
}

// TestRuntimePrior54Gate は全70前に成功・残量・同条件・全54Native指紋を検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。Nativeはこのgate専用の手製metadataで金融結果を装いません。
func TestRuntimePrior54Gate(t *testing.T) {
	base := t.TempDir()
	f := fixtureFixed(t, base)
	addFixtureReferences(t, filepath.Join(base, "対照"), &f, 54)
	ref := fixtureRef(t, filepath.Join(base, "固定.json"), f)
	plan, err := PrepareFixed(ref, "base54", nil)
	if err != nil {
		t.Fatal(err)
	}
	old := Completion{Version: 1, Trial: 111, Stage: "base54", Success: true, ConditionSHA256: ref.SHA256, Sessions: 54, ReplayedSessions: 54, Books: 1296, OriginalMethods: 81, AllReferenceEventsEqual: true, Unchanged: true, Before: plan.Source.Before, After: copyValue(plan.Source.Before), Results: []SceneResult{}}
	for _, input := range plan.Source.Cases {
		native := fixtureRef(t, filepath.Join(base, "手製Native", input.ID+".json"), map[string]any{"gate専用人工": true})
		methods := 1
		if strings.HasSuffix(input.ID, "_Night") {
			methods = 2
		}
		old.Results = append(old.Results, SceneResult{Session: input.ID, Native: native, Books: 24, S0Comparisons: 4, S0Equal: true, Complete: true,
			Golden: &source.GoldenProof{ReferenceKind: "rerun_original166_pinned_code", Reference: f.Golden[input.ID], Session: input.ID, Methods: methods, EventsEqual: true, MiniEventsEqual: true}})
	}
	previous := fixtureRef(t, filepath.Join(base, "手製base54成功.json"), old)
	full, err := PrepareFixed(ref, "full70", &previous)
	if err != nil || len(full.Source.Cases) != 70 || full.Prior54 == nil {
		t.Fatal(err)
	}
	for _, name := range []string{"不成功", "別条件", "数量不足", "残玉", "未返済", "前後差", "歴史同体", "場順", "Native指紋", "mini未照合"} {
		t.Run(name, func(t *testing.T) {
			bad := copyValue(old)
			switch name {
			case "不成功":
				bad.Success = false
			case "別条件":
				bad.ConditionSHA256 = strings.Repeat("0", 64)
			case "数量不足":
				bad.Books--
			case "残玉":
				bad.Results[0].OpenQuantity = 1
			case "未返済":
				bad.Results[0].PendingQuantity = 1
			case "前後差":
				bad.After[ref.Path] = strings.Repeat("0", 64)
			case "歴史同体":
				bad.HistoricalSavedEventsEqual = true
			case "場順":
				bad.Results[0].Session = bad.Results[1].Session
			case "Native指紋":
				bad.Results[0].Native.SHA256 = strings.Repeat("0", 64)
			case "mini未照合":
				bad.Results[0].Golden.MiniEventsEqual = false
			}
			badRef := fixtureRef(t, filepath.Join(base, name+".json"), bad)
			if _, err := PrepareFixed(ref, "full70", &badRef); err == nil {
				t.Fatal("全70の前提破壊を受理")
			}
		})
	}
	// ----------------------------------------
	// すべてのRawが未作成でも、先行54参照を複写せず再用し55場目まで進めます。
	out := filepath.Join(base, "全70再用の不完了")
	partial, err := RunFixed(ref, "full70", out, &previous)
	if err == nil || partial.Success || partial.ReusedSessions != 54 || partial.ReplayedSessions != 0 ||
		len(partial.Results) != 54 || !reflect.DeepEqual(partial.Results, old.Results) {
		t.Fatal("全70の元54を再生又は再保存した", err)
	}
	entries, err := os.ReadDir(out)
	if err != nil || len(entries) != 1 || entries[0].Name() != "不完了.json" {
		t.Fatal("再用54Nativeを複製した", err)
	}
	var failure struct {
		Session string `json:"session"`
	}
	raw, _ := os.ReadFile(filepath.Join(out, "不完了.json"))
	if err = json.Unmarshal(raw, &failure); err != nil || failure.Session != full.Source.Cases[54].ID {
		t.Fatal("追加16の最初で失敗した記録ではない", err)
	}
}

// TestRuntimeResultGateAndSamebytes は実手製24口座の完結と決定的保存を検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。人工保有の実現値だけを使い将来利益を作りません。
func TestRuntimeResultGateAndSamebytes(t *testing.T) {
	value := handReplay(t, 1, 0)
	f := Fixed{ActualConfigurations: actor.DeclaredContinuousConfigurations()}
	if err := CheckReplay(value, f); err != nil {
		t.Fatal(err)
	}
	bad := copyValue(value)
	book := bad.Actual.Books["W100_C0_D0"]
	book.Totals.OpenBuy = 1
	bad.Actual.Books[book.Key] = book
	if err := CheckReplay(bad, f); err == nil {
		t.Fatal("終了残を受理")
	}
	base := t.TempDir()
	a, err := saveNew(filepath.Join(base, "a.json.gz"), value, true)
	if err != nil {
		t.Fatal(err)
	}
	b, err := saveNew(filepath.Join(base, "b.json.gz"), value, true)
	if err != nil || a.SHA256 != b.SHA256 {
		t.Fatal("同結果のgzip bytes差", err)
	}
	if _, err = saveNew(a.Path, value, true); err == nil {
		t.Fatal("既存Nativeを上書き")
	}
}

// TestRuntimeFailureIsNotCompletion は未作成Rawの読取失敗を不完了だけへ残します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。実市場を開かず新規出力・上書き拒否を検査します。
func TestRuntimeFailureIsNotCompletion(t *testing.T) {
	base := t.TempDir()
	f := fixtureFixed(t, base)
	addFixtureReferences(t, filepath.Join(base, "対照"), &f, 2)
	ref := fixtureRef(t, filepath.Join(base, "固定.json"), f)
	out := filepath.Join(base, "未完出力")
	value, err := RunFixed(ref, "first2", out, nil)
	if err == nil || value.Success {
		t.Fatal("存在しないRawを成功へ補完")
	}
	if _, err = os.Stat(filepath.Join(out, "不完了.json")); err != nil {
		t.Fatal(err)
	}
	if _, err = os.Stat(filepath.Join(out, "完了.json")); !os.IsNotExist(err) {
		t.Fatal("失敗後に完了を作成")
	}
	before, err := os.ReadFile(filepath.Join(out, "不完了.json"))
	if err != nil {
		t.Fatal(err)
	}
	if _, err = RunFixed(ref, "first2", out, nil); err == nil {
		t.Fatal("不完了先へ再保存")
	}
	after, _ := os.ReadFile(filepath.Join(out, "不完了.json"))
	if !reflect.DeepEqual(before, after) {
		t.Fatal("不完了を上書き")
	}
}
