package continuousruntime111

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

// TestExportHands は独立保存器用に手製の買売各24冊を一度だけ出力します。
//
// 引数: t(*testing.T)は試験器、環境変数ARTIFICIAL111_OUTは新規保存先です。
// 返り値: ありません。FAR自然生成や市場成績とは区別し、既存先を上書きしません。
func TestExportHands(t *testing.T) {
	root := os.Getenv("ARTIFICIAL111_OUT")
	if root == "" {
		t.Skip("人工の保存先は未指定")
	}
	if err := os.Mkdir(root, 0755); err != nil {
		t.Fatal(err)
	}
	refs := map[string]map[string]string{}
	for name, side := range map[string]int{"買い": 1, "売り": -1} {
		value := handReplay(t, side, 0)
		raw, err := json.Marshal(value)
		if err != nil {
			t.Fatal(err)
		}
		path := filepath.Join(root, name+".json.gz")
		file, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
		if err != nil {
			t.Fatal(err)
		}
		writer := gzip.NewWriter(file)
		if _, err = writer.Write(raw); err != nil {
			t.Fatal(err)
		}
		if err = writer.Close(); err != nil {
			t.Fatal(err)
		}
		if err = file.Close(); err != nil {
			t.Fatal(err)
		}
		stored, err := os.ReadFile(path)
		if err != nil {
			t.Fatal(err)
		}
		sum := sha256.Sum256(stored)
		refs[name] = map[string]string{"path": path, "sha256": hex.EncodeToString(sum[:])}
	}
	manifest := map[string]any{"version": 1, "trial": 111, "kind": "手製Source通知の接続人工", "natural_FAR_signal": false, "market_data": false, "books": 48, "references": refs}
	raw, err := json.MarshalIndent(manifest, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(filepath.Join(root, "人工.json"), raw, 0644); err != nil {
		t.Fatal(err)
	}
}
