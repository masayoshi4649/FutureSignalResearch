# 元の連続Sourceと24口座の可変保護

元166のD164_15/P164_06/U165_03を停止済みSourceで運転し、同じ原行の通知を24実口座へ一度ずつ配送する。外側の新規5分・15分時計や開始静観を加えない。Sourceの先行約定→Observe→当行通知→後続正常原行約定を維持し、追加保護の結果をSourceへ戻さない。

元算法→一定利益必須追尾→MA収束等のC/M/PとBBによる狭幅を区別する。S0/U100/W100/T100/B100/B50×片道滑り0/5pt×価格時計遅延0/1秒の24条件を一括で残す。片道手数料38.5円、mini各側上限10枚と費用配賦は停止Actorの実宣言を使う。利益のない場も除外しない。未参加・退出後の仮想利益や資金不明のROIを出さない。

## 公開接続

`New()`を`source.ReplayWithConsumer(root,input,consumer)`へ渡し、`ConnectResult(origin,consumer)`で結合する。`ReplayResult`の`source`は元基準4費用、`actual`は24実口座。S0四費用は説明用StreamScope以外の全金融JSONを元基準と比較する。確定足の追加保護は全場cold開始、独自新規時計・外Force・EOF補完を加えない。

`runtime.go`と既存人工はRoot所有。市場固定とCLIの実装は`fixed.go`、`cmd/run/main.go`、`fixed_test.go`で分ける。全市場の実行はRootが所有する。

## Root固定JSON

停止SourceのFixed schemaをそのまま使う。必須は`version=1,trial=111,fixed=true,policy=original166_continuous_baseline,FAR_commit=cf0717daa1eed78759f78a428bce50129e7f705b,strategy_commit=67ba01588a60961ce2fb505ee5654999473dedab`。`manifest/executable/oracle_executable`は絶対path/sha256のFileRef、`code_sha256`は全依存の絶対位置→SHA。`executable`は今回の`111連続保護.exe`とする。

次の追加項目をすべて記す。

- `actual_policy="original166_continuous_24books_mandatory_protection"`
- `chart_seed_mode="cold_each_session"`
- `entry_grid_seconds=null`。省略は拒否する。
- `extra_opening_quiet_seconds=0`。省略は拒否する。
- `actual_configurations`：`actor.DeclaredContinuousConfigurations()`の全24条件、順序も同体。
- `pure_configurations`：`guard.DeclaredConfigurations()`の全24条件、順序も同体。Actorのslip_ptsと純部品のslip_pointsを区別する。
- `dependency_stops`：キーsource/actor/chart/pureの4 FileRef。停止Source08b133…、Actor650396…、Chart38c01e…、Pure0042a6…の現物を要求する。
- `actual_declaration/pure_declaration/chart_declaration`：Actor・Pure停止JSONの「実宣言」、Chart停止の「実API宣言」FileRef。Actorは配列、Pureはconfigurations配列を持つobjectで、各実APIの24条件とも比較する。
- `original166_references`：first2で先頭2又は元54のRef、base54/full70で元54のRef。原文再実行originを必須とし、100microと10miniの全fill Eventを比較する。

`Source.PrepareMetadata`で台帳70場/戦略43項目/同実行物/固定mapを本文前に認証する。さらに四停止の所有・再用・全Source閉包をmapへ要求し、現在の実cmdを`go list -deps -json ./cmd/run`して、選択Go/asm/embed/moduleのmod/sumとGoRootを含む全閉包の固定漏れを拒否する。go listは入力本文を読まない。全コードSHAは停止器が作った現物mapを使う。

first2の二参照F1から全54参照F2への派生は、算法・費用・時計の変更と区別してRootが記録する。full70はF2と同じcondition SHAのbase54成功が必要。

## 段階とCLI

本文を開かない認証。

    111連続保護.exe --fixed <絶対固定JSON> --fixed-sha <SHA> --stage metadata-only

Root固定後の市場実行。

    111連続保護.exe --fixed <F1> --fixed-sha <SHA> --stage first2 --out <未使用先>
    111連続保護.exe --fixed <F2> --fixed-sha <SHA> --stage base54 --out <未使用先>
    111連続保護.exe --fixed <同F2> --fixed-sha <同SHA> --stage full70 --prior54 <base54完了JSON> --prior54-sha <SHA> --out <未使用先>

全70の前提はbase54成功、54場/1296口座/元81手法場、各場24口座・S0四比較、全残量/予約0、当時保存Eventと全Signalの同体はfalse、before=after、同条件SHA、全54Nativeの実SHA認証。全70の先頭54は認証済みNative参照をそのまま再用し、追加16だけを新しく再生する。元54のRaw再読・Native複写は行わない。同bytesは認証済み成果物の再用であり、再生による再証明とは呼ばない。元54当時の保存Eventが未発見のため、今回の原文run再実行対照と当時の履歴同体を区別する。

保存先は新規だけ。場別`.Native.json.gz`は結合ReplayResult、成功は`完了.json`、認証後の失敗は`不完了.json`に途中場と保存済み参照を残す。不完了を成功へ転用しない。

## 完了schemaと検査

完了JSONはversion/trial/success/stage(first2,base54,full70)/sessions/books=24N/condition_sha256/unchanged/before/after/resultsを持つ。reused_sessions/replayed_sessionsはfull70で54/16、base54で0/54、first2で0/2。各resultsはsession/native/original166_reference/books=24/S0_comparisons=4/S0_equal/complete/open_quantity=0/pending_quantity=0。original_methodsは先頭2で3、元54以降で81、all_original166_reference_events_equal=true。historical_saved_events_equalとall_original_signal_full_json_equalはfalse。

公開APIと全結果型はRootの停止記録に保存する。人工で売買鏡像の24口座、S0全金融同体、未来非干渉、Source API接続に加え、全閉包/宣言/時計破壊の本文前拒否、元対照2→54、base54の残量/指紋破壊、同結果gzip同bytes、失敗時の不完了・既存先拒否を確認する。人工の成功を市場成績や採用へ読み替えない。11月09日の本文と入力指紋は開かない。
