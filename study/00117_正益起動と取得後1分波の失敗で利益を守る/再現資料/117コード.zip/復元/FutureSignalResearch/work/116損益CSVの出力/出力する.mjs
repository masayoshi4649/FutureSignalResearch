/**
 * 独立保存済みの116損益を、候補別集計と全セッションのCSVへ出力する。
 * @param {string[]} process.argv - 結果JSON、期待SHA256、新規出力先の順。
 * @returns {Promise<void>} 再計算・検算したCSV二点と確認JSONを保存する。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {Workbook} from '@oai/artifact-tool';
import {openInput,ACTOR_KEYS,keyFor,sha as gateSha} from './入力と候補.mjs';

/**
 * 明示した入力・出力の指紋を計算する。
 * @param {Uint8Array|string} value - 対象バイト列又はUTF-8文字列。
 * @returns {string} SHA256。
 */
function sha(value) { return crypto.createHash('sha256').update(value).digest('hex'); }

/**
 * 保存された有限数値と計算値を比較する。
 * @param {number} actual - 計算値。
 * @param {number} expected - 保存値。
 * @param {string} label - 照合する項目。
 * @returns {void} 不一致は例外にする。
 */
function equalNumber(actual, expected, label) {
  assert.ok(Number.isFinite(actual) && Number.isFinite(expected), label);
  assert.ok(Math.abs(actual - expected) <= 0.000001, `${label}: ${actual} / ${expected}`);
}

/**
 * 分母が0の比率を空欄として、数値0と区別して検査する。
 * @param {number|null} actual - 計算値又は未定義。
 * @param {number|null} expected - 保存値又は未定義。
 * @param {string} label - 検査する項目。
 * @returns {void} 型又は値の差は例外にする。
 */
function equalNullable(actual, expected, label) {
  if (actual === null || expected === null) assert.equal(actual, expected, label);
  else equalNumber(actual, expected, label);
}

/**
 * 取引単位の利益と損失から比率の意味を検査する。
 * @param {Object} row - 場別又は候補別の独立集計。
 * @param {string} label - 対象ID。
 * @returns {void} 利益・損失の符号、件数、比率が違えば例外。
 */
function inspectMetrics(row, label) {
  assert.ok(row.positive_yen >= 0 && row.negative_yen <= 0, label);
  equalNumber(row.positive_yen + row.negative_yen, row.net_yen, `${label}/利益損失と純額`);
  assert.equal(row.positive_positions + row.negative_positions + row.zero_positions, row.positions, label);
  equalNullable(row.negative_yen === 0 ? null : row.positive_yen / -row.negative_yen, row.PF, `${label}/PF`);
  equalNullable(row.positions === 0 ? null : row.positive_positions / row.positions, row.win_rate, `${label}/勝率`);
  const gain = row.positive_positions === 0 ? null : row.positive_yen / row.positive_positions;
  const loss = row.negative_positions === 0 ? null : row.negative_yen / row.negative_positions;
  equalNullable(gain, row.average_profit_yen, `${label}/平均利益`);
  equalNullable(loss, row.average_loss_yen, `${label}/平均損失`);
  equalNullable(gain === null || loss === null ? null : gain / -loss, row.average_profit_loss_ratio, `${label}/平均損益比`);
}

/**
 * 正益経験の分母・赤字件数を検査して表示用の期待比率を返す。
 * @param {Object} row - 原本の場別又は集計。
 * @param {string} label - 検査対象。
 * @returns {number|null} 正益経験建玉を分母とした百分率。分母0はnull。
 */
function experiencedRate(row, label) {
  assert.ok(Number.isSafeInteger(row.whole_positive_positions) && row.whole_positive_positions >= 0 && row.whole_positive_positions <= row.positions, label + '/正益経験分母');
  assert.ok(Number.isSafeInteger(row.whole_positive_closed_negative) && row.whole_positive_closed_negative >= 0 && row.whole_positive_closed_negative <= row.whole_positive_positions, label + '/正益経験後赤字の包含');
  return row.whole_positive_positions === 0 ? null : row.whole_positive_closed_negative / row.whole_positive_positions * 100;
}

/**
 * CSVの文字列フィールドに必要な引用符だけを加える。
 * @param {string|number|null} value - 表の値。nullは未定義の空欄。
 * @returns {string} RFC4180のフィールド。
 */
function field(value) {
  const text = value == null ? '' : String(value);
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

/**
 * 計算済みの表をUTF-8 BOM付きCSVにする。
 * @param {Object} sheet - artifact-toolの表。
 * @param {number} rows - ヘッダ込み行数。
 * @param {number} columns - 列数。
 * @returns {string} 改行CRLFのCSV。
 */
function csv(sheet, rows, columns) {
  return '\uFEFF' + sheet.getRangeByIndexes(0, 0, rows, columns).values.map(row => row.map(field).join(',')).join('\r\n') + '\r\n';
}

// ----------------------------------------
// Root解禁又は人工ラベルを確認してから入力本文へ進みます。

const {input,expectedSHA,output,data,artificial,beforeRefs,rawStatus,rootRequest}=await openInput(process.argv.slice(2));
const packageInfo={version:'2.8.129'};
const sessions=data['場数'],keys=data['主key'];
assert.deepEqual(keys,ACTOR_KEYS,'Life外Entryの実宣言順');
assert.equal(data['会計数'],36*sessions);assert.equal(data['場別'].length,36*sessions);
const gateColumns = [
  ['元新規要求数', 'source_new'], ['入口許可要求数', 'allowed'],
  ['採用モード票が真の要求数', 'selected_true'], ['採用モード票が偽の要求数', 'selected_false'], ['採用モード票が未知の要求数', 'selected_unknown'],
  ['入力不足あり要求数', 'input_missing'], ['条件の否定あり要求数', 'known_denial'],
  ['新規受付要求数', 'accepted_requests'], ['新規受付枚数', 'accepted_quantity'],
  ['実取得新規fill数', 'actual_new_fills'], ['実取得枚数', 'actual_quantity']
];
const summaryHeader = ['試行','候補','追加保有根拠政策','共通保護政策','条件ID','セッション数','片道追加滑りpt','仮定遅延秒','新規件数','新規枚数','勝ち件数','負け件数','同値件数','勝率パーセント','利益総額円','損失総額円','PF','平均利益円','平均損失円','平均利益損失比','粗損益円','手数料円','追加滑り円','純損益円','保存点連結時価DD円','費用後正益を経験した建玉数','建玉全体の正益後赤字件数','正益経験建玉の最終赤字率パーセント','建玉全体の正益後赤字額円','追尾起動件数','追尾起動後赤字件数','追尾起動後赤字額円','保有時間秒','数量秒', '保有根拠失効要求件数','保有根拠失効約定件数','保有根拠失効返済純額円','Raw初回性監査範囲','独立検算の実行区分',...gateColumns.map(x=>x[0])];
const detailHeader = ['試行','候補','追加保有根拠政策','共通保護政策','条件ID','開始日JST','セッション','期間区分','片道追加滑りpt','仮定遅延秒','新規件数','新規枚数','粗損益円','手数料円','追加滑り円','純損益円','累計収支円','利益総額円','損失総額円','勝ち件数','負け件数','同値件数','場内時価DD円','費用後正益を経験した建玉数','建玉全体の正益後赤字件数','正益経験建玉の最終赤字率パーセント','追尾起動件数','追尾起動後赤字件数','保有時間秒','数量秒', '保有根拠失効要求件数','保有根拠失効約定件数','保有根拠失効返済純額円','Raw初回性監査範囲','独立検算の実行区分',...gateColumns.map(x=>x[0])];
const additive = ['positions','entry_quantity','close_quantity','gross_yen','fee_yen','slip_yen','net_yen','positive_yen','negative_yen','positive_positions','negative_positions','zero_positions','whole_positive_positions','whole_positive_closed_negative','whole_positive_closed_negative_yen','protection_activated_positions','activated_closed_negative','activated_closed_negative_yen'];
const summaryObjects = [], detailObjects = [], checks = [];
for (const key of keys) {
  const config = data['Actor設定'][key], aggregate = data['集計'][key];
  assert.equal(config.policy, 'P100'); assert.equal(config.candidate, key); assert.equal(keyFor(config),key); assert.ok(['X0','XC','XQ'].includes(config.life_mode));
  assert.equal(config.entry_timing, '元Source連続時計');
  const rows = data['場別'].filter(row => row.key === key).sort((a,b) => a.session.localeCompare(b.session));
  assert.equal(rows.length, sessions); assert.equal(new Set(rows.map(row=>row.session)).size, sessions);
  const sums = Object.fromEntries(additive.map(name=>[name,0]));
  const gateSums = Object.fromEntries(gateColumns.map(([,name])=>[name,0]));
  let cumulative=0, held=0, quantitySeconds=0,lifeRequests=0,lifeFills=0,lifeNet=0;
  for (const row of rows) {
    assert.match(row.session, /^2026-\d{2}-\d{2}_(Day|Night)$/);
    assert.ok(['original54','additional16'].includes(row.history_class));
    equalNumber(row.gross_yen-row.fee_yen-row.slip_yen,row.net_yen,key+'/費用控除');
    equalNumber(row.closed_net_yen,row.net_yen,key+'/場内完結');
    for (const name of ['open_buy','open_sell','pending_buy','pending_sell']) assert.equal(row[name],0,name);
    inspectMetrics(row,key+'/'+row.session);
    const life=row['注文別']['保有根拠失効'];
    for(const name of ['要求','約定']) assert.ok(Number.isSafeInteger(life[name])&&life[name]>=0,'life件数');
    assert.equal(row['保有根拠の独立検査']['counts'].exit_requests,life['要求']);assert.equal(row['保有根拠の独立検査']['counts'].exit_fills,life['約定']);
    if(config.life_mode==='X0') assert.deepEqual([life['要求'],life['約定'],life['返済片純額']],[0,0,0]);
    lifeRequests+=life['要求'];lifeFills+=life['約定'];lifeNet+=life['返済片純額'];
    for (const name of additive) sums[name]+=row[name];
    const counts = row['入口票検査'].counts;
    for (const [,name] of gateColumns) {
      assert.ok(Number.isSafeInteger(counts[name]) && counts[name]>=0,'入口の件数/枚数 '+name);
      gateSums[name]+=counts[name];
    }
    assert.equal(counts.selected_true+counts.selected_false+counts.selected_unknown,counts.source_new,'入口三値の全分母');
    assert.equal(counts.allowed,counts.selected_true,'許可の分母');
    assert.ok(counts.accepted_requests<=counts.allowed && counts.actual_new_fills<=counts.accepted_requests);
    assert.ok(counts.input_missing<=counts.source_new && counts.known_denial<=counts.source_new);
    assert.equal(counts.actual_new_fills,row.positions);assert.equal(counts.actual_quantity,row.entry_quantity);
    const duration=row['頻度診断'];held+=duration.held_seconds;quantitySeconds+=duration.quantity_seconds;cumulative+=row.net_yen;
    const [date,kind]=row.session.split('_');
    const obj={'試行':116,'候補':config.entry_mode,'追加保有根拠政策':config.life_mode,'共通保護政策':'P100','条件ID':key,'開始日JST':date+' JST','セッション':kind==='Day'?'デイ':'ナイト','期間区分':row.history_class==='original54'?'元54場':'追加16場','片道追加滑りpt':config.slip_pts,'仮定遅延秒':config.delay_seconds,
      '新規件数':row.positions,'新規枚数':row.entry_quantity,'粗損益円':row.gross_yen,'手数料円':row.fee_yen,'追加滑り円':row.slip_yen,'純損益円':row.net_yen,'累計収支円':cumulative,'利益総額円':row.positive_yen,'損失総額円':row.negative_yen,'勝ち件数':row.positive_positions,'負け件数':row.negative_positions,'同値件数':row.zero_positions,'場内時価DD円':row['場内時価DD'],'費用後正益を経験した建玉数':row.whole_positive_positions,'正益経験建玉の最終赤字率パーセント':experiencedRate(row,key+'/'+row.session),'建玉全体の正益後赤字件数':row.whole_positive_closed_negative,'追尾起動件数':row.protection_activated_positions,'追尾起動後赤字件数':row.activated_closed_negative,'保有時間秒':duration.held_seconds,'数量秒':duration.quantity_seconds};
    Object.assign(obj,{'保有根拠失効要求件数':life['要求'],'保有根拠失効約定件数':life['約定'],'保有根拠失効返済純額円':life['返済片純額'],'Raw初回性監査範囲':rawStatus,'独立検算の実行区分':artificial?'手製人工のみ':row.history_class==='original54'?'同F1の元54成功検算を認証継承':'追加16を新規独立照合'});
    for (const [header,name] of gateColumns) obj[header]=counts[name];
    detailObjects.push(obj);
  }
  if (!artificial) assert.equal(rows.filter(row=>row.history_class==='original54').length,54);
  for (const name of additive) equalNumber(sums[name],aggregate[name],key+'/'+name);
  inspectMetrics(aggregate,key);
  for (const [name,value] of [['held_seconds',held],['quantity_seconds',quantitySeconds]]) equalNumber(value,Object.hasOwn(aggregate['頻度診断'],name)?aggregate['頻度診断'][name]:0,key+'/'+name);
  const storedGate=data['入口票集計'][key];
  for (const [,name] of gateColumns) equalNumber(gateSums[name],Object.hasOwn(storedGate,name)?storedGate[name]:0,key+'/入口票集計/'+name);
  const obj={'試行':116,'候補':config.entry_mode,'追加保有根拠政策':config.life_mode,'共通保護政策':'P100','条件ID':key,'セッション数':sessions,'片道追加滑りpt':config.slip_pts,'仮定遅延秒':config.delay_seconds,
    '新規件数':sums.positions,'新規枚数':sums.entry_quantity,'勝ち件数':sums.positive_positions,'負け件数':sums.negative_positions,'同値件数':sums.zero_positions,'勝率パーセント':aggregate.win_rate===null?null:aggregate.win_rate*100,'利益総額円':sums.positive_yen,'損失総額円':sums.negative_yen,'PF':aggregate.PF,'平均利益円':aggregate.average_profit_yen,'平均損失円':aggregate.average_loss_yen,'平均利益損失比':aggregate.average_profit_loss_ratio,'粗損益円':sums.gross_yen,'手数料円':sums.fee_yen,'追加滑り円':sums.slip_yen,'純損益円':sums.net_yen,'保存点連結時価DD円':aggregate['保存点連結時価DD'],'費用後正益を経験した建玉数':sums.whole_positive_positions,'正益経験建玉の最終赤字率パーセント':experiencedRate(aggregate,key),'建玉全体の正益後赤字件数':sums.whole_positive_closed_negative,'建玉全体の正益後赤字額円':sums.whole_positive_closed_negative_yen,'追尾起動件数':sums.protection_activated_positions,'追尾起動後赤字件数':sums.activated_closed_negative,'追尾起動後赤字額円':sums.activated_closed_negative_yen,'保有時間秒':held,'数量秒':quantitySeconds};
  const storedLife=data['保有根拠検査集計'][key];
  for(const [name,value] of [['exit_requests',lifeRequests],['exit_fills',lifeFills]]) equalNumber(value,storedLife[name]??0,key+'/life/'+name);
  Object.assign(obj,{'保有根拠失効要求件数':lifeRequests,'保有根拠失効約定件数':lifeFills,'保有根拠失効返済純額円':lifeNet,'Raw初回性監査範囲':rawStatus,'独立検算の実行区分':artificial?'手製人工のみ':'同F1の元54成功検算を認証継承＋追加16新規独立照合'});
  for (const [header,name] of gateColumns) obj[header]=gateSums[name];
  summaryObjects.push(obj);checks.push({条件ID:key,場数:sessions,純損益円:sums.net_yen,入口票:gateSums});
}
for(const [name,expected] of Object.entries(beforeRefs)) assert.equal(sha(await fs.readFile(name)),expected,'本文前後認証');
const workbook=Workbook.create();
const summarySheet=workbook.worksheets.add('候補別集計');
const detailSheet=workbook.worksheets.add('全セッション');
const summaryRows=summaryObjects.map(row=>summaryHeader.map(header=>row[header]));
const detailRows=detailObjects.map(row=>detailHeader.map(header=>row[header]));
detailSheet.getRangeByIndexes(1,detailHeader.indexOf('開始日JST'),detailRows.length,1).setNumberFormat('@');
summarySheet.getRangeByIndexes(0,0,summaryRows.length+1,summaryHeader.length).values=[summaryHeader,...summaryRows];
detailSheet.getRangeByIndexes(0,0,detailRows.length+1,detailHeader.length).values=[detailHeader,...detailRows];

/**
 * 列番号をExcelのA1列表記へ変換する。
 * @param {number} index - 0起算の非負整数。
 * @returns {string} A1形式の列記号。
 */
function column(index) { let n=index+1,out='';while(n>0){n--;out=String.fromCharCode(65+n%26)+out;n=Math.floor(n/26);}return out; }
const index=Object.fromEntries(detailHeader.map((name,i)=>[name,i]));
const col=Object.fromEntries(Object.entries(index).map(([name,i])=>[name,column(i)]));
detailSheet.getRangeByIndexes(1,index['純損益円'],detailRows.length,1).formulas=detailObjects.map((row,i)=>[`=${col['粗損益円']}${i+2}-${col['手数料円']}${i+2}-${col['追加滑り円']}${i+2}`]);
detailSheet.getRangeByIndexes(1,index['累計収支円'],detailRows.length,1).formulas=detailObjects.map((row,i)=>[i===0||detailObjects[i-1]['条件ID']!==row['条件ID']?`=${col['純損益円']}${i+2}`:`=${col['累計収支円']}${i+1}+${col['純損益円']}${i+2}`]);
// ----------------------------------------
// 新しい率は各表の同じ行の実分母から計算し、場別率を平均/加算しません。
for (const [sheet,objects,headers] of [[summarySheet,summaryObjects,summaryHeader],[detailSheet,detailObjects,detailHeader]]) {
  const rateIndex=headers.indexOf('正益経験建玉の最終赤字率パーセント');
  const denominatorColumn=column(headers.indexOf('費用後正益を経験した建玉数'));
  const negativeColumn=column(headers.indexOf('建玉全体の正益後赤字件数'));
  sheet.getRangeByIndexes(1,rateIndex,objects.length,1).formulas=objects.map((_,i)=>[`=IF(${denominatorColumn}${i+2}=0,"",${negativeColumn}${i+2}/${denominatorColumn}${i+2}*100)`]);
}
for (const [sheet,rows,headers] of [[summarySheet,summaryRows,summaryHeader],[detailSheet,detailRows,detailHeader]]) {
  sheet.showGridLines=false;
  sheet.getRangeByIndexes(0,0,rows.length+1,headers.length).format.font={name:'Arial',size:10};
  sheet.getRangeByIndexes(0,0,1,headers.length).format={font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},fill:'#334155'};
  sheet.getRangeByIndexes(0,0,rows.length+1,headers.length).format.autofitColumns();
}
workbook.recalculate();
const computed=detailSheet.getRangeByIndexes(1,0,detailRows.length,detailHeader.length).values;
for(let i=0;i<computed.length;i++) {
  for(const name of ['純損益円','累計収支円']) equalNumber(computed[i][index[name]],detailRows[i][index[name]],'表再計算/'+i+'/'+name);
  assert.equal(computed[i][index['開始日JST']],detailRows[i][index['開始日JST']],'JST文字列のまま');
}
for (const [sheet,objects,headers] of [[summarySheet,summaryObjects,summaryHeader],[detailSheet,detailObjects,detailHeader]]) {
  const rateIndex=headers.indexOf('正益経験建玉の最終赤字率パーセント');
  const actual=sheet.getRangeByIndexes(1,rateIndex,objects.length,1).values;
  for (let i=0;i<objects.length;i++) {
    const expected=objects[i]['正益経験建玉の最終赤字率パーセント'];
    if (expected===null) assert.ok(actual[i][0]===null || actual[i][0]==='', '正益経験0分母は空欄');
    else equalNumber(actual[i][0],expected,'正益経験赤字率/'+i);
  }
}
const sample=await workbook.inspect({kind:'table',range:'候補別集計!A1:J4',include:'values,formulas',tableMaxRows:4,tableMaxCols:10,maxChars:3000});
const errors=await workbook.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:10},maxChars:1500});
await fs.mkdir(output,{recursive:false});
const outputs={};
for (const [name,sheet,rows,headers] of [['候補別集計.csv',summarySheet,summaryRows,summaryHeader],['全セッション.csv',detailSheet,detailRows,detailHeader]]) {
  const body=csv(sheet,rows.length+1,headers.length);
  await fs.writeFile(path.join(output,name),body,{encoding:'utf8',flag:'wx'});
  outputs[name]={sha256:sha(body),データ行数:rows.length,列数:headers.length};
}
if(artificial) {
  for(const sheet of ['候補別集計','全セッション']) {
    const preview=await workbook.render({sheetName:sheet,range:'A1:H4',scale:1.4,format:'png'});
    await fs.writeFile(path.join(output,sheet+'の人工プレビュー.png'),new Uint8Array(await preview.arrayBuffer()),{flag:'wx'});
  }
}
if(artificial){const i=summaryHeader.indexOf('保有根拠失効要求件数');const preview=await workbook.render({sheetName:'候補別集計',range:`${column(i)}1:${column(i+2)}16`,scale:1.2,format:'png'});await fs.writeFile(path.join(output,'保有根拠列の人工プレビュー.png'),new Uint8Array(await preview.arrayBuffer()),{flag:'wx'});}
assert.equal(sha(await fs.readFile(input)),expectedSHA,'入力の前後不変');
await fs.writeFile(path.join(output,'CSVの確認.json'),JSON.stringify({成功:true,試行:116,人工:artificial,入力:input,入力SHA256:expectedSHA,出力:outputs,全条件:checks,入力前後不変:true,固定枠参加率生成:false,正益経験分母合算:true,正益経験後赤字率:"whole_positive_closed_negative / whole_positive_positions × 100。0分母は空欄",金融再実行:false,表の確認:sample.ndjson,エラー走査:errors.ndjson,Root要求:rootRequest,Raw初回性監査範囲:rawStatus,認証済み入力:beforeRefs,実行環境:{node:process.version,artifact_tool:packageInfo.version},開始日:'JST文字列・@書式、CSV値はYYYY-MM-DD JST'},null,2),{flag:'wx'});
console.log(JSON.stringify({成功:true,人工:artificial,出力先:output,出力:outputs}));
