"""固定93の入力・所有台帳を新111へ派生し元の原行順序へ置き換える。"""

from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
OLD = ROOT / "scripts/FAR元三手法のmini連続再現"


def read_fixed(name: str, expected: str) -> str:
    """機能: 旧固定ソースを期待指紋と照合して読む。

    引数: name/expected(str)は旧名とSHA256。
    返り値: strは元UTF-8本文。不一致なら拒否する。
    """
    data = (OLD / name).read_bytes()
    if hashlib.sha256(data).hexdigest() != expected:
        raise ValueError("旧固定指紋差: " + name)
    return data.decode("utf-8")


def main() -> None:
    """機能: 旧版を変更せず新moduleの派生部だけを新規作成する。

    引数: なし。Rootの市場固定前に一度実行する。
    返り値: None。市場ファイルを開かない。
    """
    old_adapter = read_fixed("adapter.go", "ea823b57a9eedb9cae3ce3c83fb3e8868b869b79635dc3ab0356233bce0b048d")
    adapter = old_adapter.replace("package mininative", "package continuous111", 1)
    adapter = adapter.replace("failure   error", "failure   error\n\tnormalization NormalizationAudit\n\tforceCalls int")
    start, end = adapter.index("func NewAdapter("), adapter.index("// ready ")
    constructor = """func NewAdapter(method string, session strategy.Session, config ProductConfig) (*Adapter, error) {
\tshort := strings.TrimPrefix(method, "NK225_")
\tif short != "D164_15" && short != "P164_06" && short != "U165_03" { return nil, errors.New("対象は元の選定三手法だけです") }
\twant, err := OriginalConfig(config.Product)
\tif err != nil || config != want { return nil, errors.New("元166の正規化商品設定だけを受け付けます") }
\tif !finite(session.Start, session.ForceClose, session.End, session.USOpen, session.ExtraAt, session.NightCoreStart) || session.Start <= 0 || session.Start >= session.ForceClose || session.ForceClose > session.End { return nil, errors.New("元セッション時計が不正です") }
\tparams, err := strategy.ParametersForMethod("NK225", session.Kind, short)
\tif err != nil { return nil, err }
\trequested := strategy.Config{Reference: "NK225", Product: config.Product, CoreQuantity: 1, ExtraMaxQuantity: 1, Cap: config.Cap, LargeTick: 10, PointValue: config.PointValue, Parameters: params}
\tp, err := strategy.New(requested, session)
\tif err != nil { return nil, err }
\tif p.Selected == nil || p.Selected.Shadow == nil { return nil, errors.New("選定源の実設定がありません") }
\tdeadline := session.ForceClose
\tif short == "P164_06" { deadline = math.Min(deadline, session.USOpen-900) }
\tnormalization := NormalizationAudit{Requested: clone(requested), Effective: clone(p.Config), Source: clone(p.Selected.Shadow.Config), Scope: "元166の外Config1/1とselected内部源5/5/10を実objectから保存。全面同値の証明は別"}
\tr := &Adapter{book: &portfolioBook{p}, deadline: deadline, seen: map[string]bool{}, holdIndex: map[string]int{}, pending: []Signal{}, last: QuoteStamp{Index: -1}, normalization: normalization,
\t\tledger: Ledger{Method: "NK225_"+short, Session: session, Config: config, Signals: []SignalRecord{}, Fills: []FillRecord{}, Cancellations: []Cancellation{}, Holds: []HoldLedger{}, Pending: []Signal{}}}
\treturn r, nil
}

"""
    adapter = adapter[:start] + constructor + adapter[end:]
    start, end = adapter.index("// Step は"), adapter.index("// Force は")
    step = """// Step は元166の先行fill→Observe→当行通知→取消を原行内で進めます。
//
// 引数: o(strategy.Observation)、sourceLine(int64)は当時の観測と物理行です。
// 返り値: StepResult/errorは当行だけの全通知・約定又は不整合です。
func (r *Adapter) Step(o strategy.Observation, sourceLine int64) (StepResult, error) {
\tout := result(o.Time, "quote", sourceLine)
\tif err := r.ready(); err != nil { return out, err }
\tif o.Reference != "NK225" || !finite(o.Time,o.Received,o.Last,o.Bid,o.Ask) || o.Last <= 0 || o.Time <= 0 || o.Index < 0 || sourceLine <= 0 || r.started && (o.Time < r.last.Time || o.Index <= r.last.Index) { return out, errors.New("原行の市場・時計・価格・連番・物理行が不正です") }
\tq := stamp(o, sourceLine)
\tif err := r.fillPending(o,q,&out); err != nil { return out,r.stop(err) }
\tsignals, err := r.book.ObserveWithFreshness(o,true,true)
\tif err != nil { return out,r.stop(err) }
\tif err = r.accept(signals,o.Time,q,&out); err != nil { return out,r.stop(err) }
\tif err = r.cancel(r.book.SelectedCancellationIDs(),o.Time,q,"元166の当行Observe後取消",&out); err != nil { return out,r.stop(err) }
\tif o.Time >= r.deadline && !r.ledger.Forced { r.ledger.Forced, r.ledger.ForcedAt = true, o.Time }
\tr.started,r.last = true,q
\tif err = r.checkOwnership(); err != nil { return out,r.stop(err) }
\treturn clone(out),nil
}

"""
    adapter = adapter[:start] + step + adapter[end:]
    adapter = adapter.replace("r.book.OnOrderRejected(s.ID)", "r.book.OnOrderDone(s.ID)")
    adapter = adapter.replace("out.SourceLine = r.last.SourceLine\n\tr.ledger.Forced", "out.SourceLine = r.last.SourceLine\n\tr.forceCalls++\n\tr.ledger.Forced")
    old_input = read_fixed("input.go", hashlib.sha256((OLD / "input.go").read_bytes()).hexdigest())
    inp = old_input.replace("package mininative", "package continuous111", 1)
    inp = inp.replace('Contract string               `json:"contract"`', 'Contract string               `json:"contract"`\n\tCutoff float64 `json:"cutoff,omitempty"`')
    inp = inp.replace("t >= session.End", "t > session.End")
    inp = inp.replace("\t\tprevious = t\n", "")
    inp = inp.replace("\t\t\tq.BadLast++\n\t\t}", "\t\t\tq.BadLast++\n\t\t\tcontinue\n\t\t}\n\t\tprevious = t")
    inp = inp.replace("c.Time < session.Start || c.Time >= session.End", "c.Time < session.Start || c.Time+float64(interval) > session.End")
    mirror = (ROOT / "scripts/FAR連続出生と個別利益追尾/mirror_check.go").read_text(encoding="utf-8")
    mirror = mirror.replace("package miniprotect", "package continuous111", 1).replace("func checkMirrors(", "func CheckMiniMirrors(")
    outputs = {"adapter.go": adapter, "input.go": inp, "mirror.go": mirror}
    for name, text in outputs.items():
        path = OUT / name
        if path.exists():
            raise ValueError("新規派生だけ: " + name)
        path.write_text(text, encoding="utf-8", newline="\n")
    pins = {"旧93adapter": hashlib.sha256(old_adapter.encode()).hexdigest(), "旧93input": hashlib.sha256(old_input.encode()).hexdigest(),
            "旧94mirror": hashlib.sha256((ROOT / "scripts/FAR連続出生と個別利益追尾/mirror_check.go").read_bytes()).hexdigest(),
            "新出力": {name: hashlib.sha256((OUT / name).read_bytes()).hexdigest() for name in outputs},
            "原板読取": 0, "旧固定変更": 0, "市場金融実行": 0}
    (OUT / "派生の参照.json").write_text(json.dumps(pins, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")


if __name__ == "__main__":
    main()
