package continuous111

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	protect "github.com/masayoshi4649/SessionTradeExecuter/miniprotect"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"testing"
	"time"
)

// config111 は人工で元166の指定商品を使います。
//
// 引数: product(string)は対象商品です。
// 返り値: ProductConfigは有効な元設定です。
func config111(product string) ProductConfig {
	c, e := OriginalConfig(product)
	if e != nil {
		panic(e)
	}
	return c
}

// TestOriginalNormalization は外1/1と内5/5/10を実構築で確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。元FAR全Signal同体の主張はしません。
func TestOriginalNormalization(t *testing.T) {
	for _, method := range []string{"D164_15", "P164_06", "U165_03"} {
		for _, product := range []string{"NK225micro", "NK225mini"} {
			kind := "Night"
			if method == "D164_15" {
				kind = "Day"
			}
			r, e := NewAdapter(method, Session{ID: "人工_" + kind, Kind: kind, Start: 1000, End: 20000, ForceClose: 19400, USOpen: 10000}, config111(product))
			if e != nil {
				t.Fatal(e)
			}
			a := r.Normalization()
			if a.Requested.CoreQuantity != 1 || a.Requested.ExtraMaxQuantity != 1 || a.Effective.CoreQuantity != 1 || a.Source.CoreQuantity != 5 || a.Source.ExtraMaxQuantity != 5 || a.Source.Cap != 10 || a.Source.Product != "NK225mini" {
				t.Fatalf("実設定差:%+v", a)
			}
			if a.Effective.Cap != config111(product).Cap || a.ExplicitForceCalls != 0 {
				t.Fatal("Cap又はForce差")
			}
			a.Requested.Cap = 999
			if r.Normalization().Requested.Cap == 999 {
				t.Fatal("設定を外側から変更できる")
			}
		}
	}
	for _, product := range []string{"", "TOPIXmini"} {
		if _, e := OriginalConfig(product); e == nil {
			t.Fatal("対象外商品を受理")
		}
	}
	c := config111("NK225mini")
	c.CoreQuantity = 5
	if _, e := NewAdapter("D164_15", Session{ID: "人工_Day", Kind: "Day", Start: 1000, End: 20000, ForceClose: 19400}, c); e == nil {
		t.Fatal("元Config以外を受理")
	}
}

// TestBoundaryIsObservedAfterPendingFill は境界原行の前にForceを挿入しません。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。境界での新規fillと後続返済の原行を確認します。
func TestBoundaryIsObservedAfterPendingFill(t *testing.T) {
	for _, side := range []int{1, -1} {
		r, b := artificial(t, config111("NK225mini"))
		r.deadline = 1101
		b.script[0] = []Signal{newSignal("初回", side, 2)}
		b.script[1] = []Signal{closeSignal("境界返済", "初回-玉", side, 2)}
		first := step(t, r, observation(side, 0, 0, true))
		if len(first.Fills) != 0 {
			t.Fatal("同原行fill")
		}
		second := step(t, r, observation(side, 1, 10, true))
		if len(second.Fills) != 1 || second.Fills[0].Action != "new" || len(second.Signals) != 1 || second.Signals[0].Signal.Action != "close" || b.forceCount != 0 || r.forceCalls != 0 {
			t.Fatal("境界で先行fill→当行返済にならない")
		}
		third := step(t, r, observation(side, 2, 30, true))
		if len(third.Fills) != 1 || third.Fills[0].Action != "close" {
			t.Fatal("返済が後原行でない")
		}
		out, e := r.Finish()
		if e != nil || !out.Complete {
			t.Fatal(e)
		}
	}
}

// TestSameClockBadQuoteAndMirror は同時計複数行と異常BBOでも元通知を省きません。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。売買鏡像の2商品を検査します。
func TestSameClockBadQuoteAndMirror(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, product := range []string{"NK225micro", "NK225mini"} {
			r, b := artificial(t, config111(product))
			b.script[0] = []Signal{newSignal("初回", side, 2)}
			b.script[2] = []Signal{closeSignal("返済", "初回-玉", side, 2)}
			for i := int64(0); i < 4; i++ {
				move := float64(i * 10)
				if i == 3 {
					move = 50
				}
				o := observation(side, i, move, i != 1)
				o.Time, o.Received = 1100, 1100
				delta := step(t, r, o)
				if i == 1 && (len(delta.Fills) != 0 || len(b.observed) != 2) {
					t.Fatal("異常板を判断から除外又は約定")
				}
				if i == 2 && (len(delta.Fills) != 1 || len(delta.Signals) != 1) {
					t.Fatal("同時計のstrict後Index")
				}
			}
			out, e := r.Finish()
			if e != nil {
				t.Fatal(e)
			}
			if out.Totals.GrossYen != float64(2*20)*config111(product).PointValue || out.Totals.FeeYen != 0 {
				t.Fatalf("鏡像/点価差:%+v", out.Totals)
			}
		}
	}
}

// TestEOFAndExplicitEmergencyForce はEOFを架空約定にせず明示Forceを記録します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。
func TestEOFAndExplicitEmergencyForce(t *testing.T) {
	r, b := artificial(t, config111("NK225mini"))
	b.script[0] = []Signal{newSignal("初回", 1, 1)}
	step(t, r, observation(1, 0, 0, true))
	if _, e := r.Finish(); e == nil {
		t.Fatal("未約定EOF成功")
	}
	step(t, r, observation(1, 1, 0, true))
	if _, e := r.Finish(); e == nil {
		t.Fatal("保有EOF成功")
	}
	delta, e := r.Force(1101)
	if e != nil || len(delta.Fills) != 0 || len(delta.Signals) != 1 || r.Normalization().ExplicitForceCalls != 1 {
		t.Fatal("Forceが即fill又は未記録", e)
	}
	step(t, r, observation(1, 2, 20, true))
	if _, e = r.Finish(); e != nil {
		t.Fatal(e)
	}
}

// TestUSWindowAndInvalidObservation はU開始の等号と不正入力を分けます。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。
func TestUSWindowAndInvalidObservation(t *testing.T) {
	s := Session{Kind: "Night", USOpen: 10000}
	if activeMethod("U165_03", 10899.999, s) || !activeMethod("U165_03", 10900, s) || !activeMethod("P164_06", 10900, s) {
		t.Fatal("元US時計の差")
	}
	for _, bad := range []func(*Observation){func(o *Observation) { o.Last = 0 }, func(o *Observation) { o.Time = math.NaN() }, func(o *Observation) { o.Reference = "TOPIX" }, func(o *Observation) { o.Index = -1 }} {
		r, _ := artificial(t, config111("NK225mini"))
		o := observation(1, 0, 0, true)
		bad(&o)
		if _, e := r.Step(o, 1); e == nil {
			t.Fatal("不正原行受理")
		}
	}
}

// TestMiniFourCostBooks は元源を共用し四費用口座の実約定・半円を確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。同じ価格時計の複数行を実時刻の1秒と混同しません。
func TestMiniFourCostBooks(t *testing.T) {
	for _, side := range []int{1, -1} {
		r, b := artificial(t, config111("NK225mini"))
		b.script[0] = []Signal{newSignal("初回", side, 3)}
		b.script[3] = []Signal{closeSignal("返済", "初回-玉", side, 3)}
		actors := map[string]*protect.ActualBook{}
		for _, cfg := range ActorConfigs() {
			a, e := protect.NewActualBook(r.ledger.Session, cfg)
			if e != nil {
				t.Fatal(e)
			}
			actors[fmt.Sprintf("S0_C%.0f_D%d", cfg.SlipPts, cfg.DelaySeconds)] = a
		}
		times := []float64{1100, 1100, 1101, 1101, 1101, 1102}
		steps := []NativeStep{}
		for i, at := range times {
			o := observation(side, int64(i), float64(i*20), true)
			o.Time, o.Received = at, at
			delta := step(t, r, o)
			batch := []NativeBatch{{Method: "D164_15", Delta: delta}}
			before := clone(batch)
			for _, a := range actors {
				if e := a.OnNativeStep(o, o.Index+20, batch); e != nil {
					t.Fatal(e)
				}
			}
			if !reflect.DeepEqual(batch, before) {
				t.Fatal("共用Sourceを変更")
			}
			steps = append(steps, NativeStep{Observation: o, SourceLine: o.Index + 20, Mini: clone(batch), Holds: r.touchedHolds("NK225mini", "D164_15", delta)})
		}
		source, e := r.Finish()
		if e != nil {
			t.Fatal(e)
		}
		result := map[string]ActualResult{}
		for key, a := range actors {
			v, e := a.Finish()
			if e != nil {
				t.Fatal(e)
			}
			result[key] = v
			if v.Totals.FeeYen != 231 || v.Totals.SlipYen != float64(600*v.Config.SlipPts) {
				t.Fatal("費用差")
			}
		}
		if e = CheckMiniMirrors(result, map[string]Ledger{"D164_15": source}); e != nil {
			t.Fatal(e)
		}
		if e = CheckSourceDelivery(result, map[string]Ledger{"D164_15": source}); e != nil {
			t.Fatal(e)
		}
		if result["S0_C0_D1"].Fills[0].Quote.Time != 1101 {
			t.Fatal("1価格秒遅延を同時計の後行でfill")
		}
		if folder := os.Getenv("FSR111_ART_OUT"); folder != "" {
			if e = os.MkdirAll(folder, 0755); e != nil {
				t.Fatal(e)
			}
			data, _ := json.MarshalIndent(map[string]any{"session": r.ledger.Session, "side": side, "steps": steps, "source": source, "books": result}, "", "  ")
			if e = os.WriteFile(filepath.Join(folder, fmt.Sprintf("方向%dの連続配送.json", side)), data, 0644); e != nil {
				t.Fatal(e)
			}
		}
	}
}

// TestSameRowSourceCancellation は同原行の出生取消を四口座へ重複なく配送します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。取消を実約定や後日の再参加へ補完しません。
func TestSameRowSourceCancellation(t *testing.T) {
	r, b := artificial(t, config111("NK225mini"))
	b.script[0] = []Signal{newSignal("取消", 1, 3)}
	b.cancelAt[0] = []string{"取消"}
	o := observation(1, 0, 0, true)
	delta := step(t, r, o)
	if len(delta.Signals) != 1 || len(delta.Cancellations) != 1 || len(delta.Fills) != 0 {
		t.Fatal("同原行の取消差")
	}
	source, e := r.Finish()
	if e != nil {
		t.Fatal(e)
	}
	books := map[string]ActualResult{}
	for _, cfg := range ActorConfigs() {
		a, e := protect.NewActualBook(r.ledger.Session, cfg)
		if e != nil {
			t.Fatal(e)
		}
		if e = a.OnNativeStep(o, 20, []NativeBatch{{Method: "D164_15", Delta: delta}}); e != nil {
			t.Fatal(e)
		}
		v, e := a.Finish()
		if e != nil {
			t.Fatal(e)
		}
		books[v.Key] = v
	}
	if e = CheckMiniMirrors(books, map[string]Ledger{"D164_15": source}); e != nil {
		t.Fatal(e)
	}
	if e = CheckSourceDelivery(books, map[string]Ledger{"D164_15": source}); e != nil {
		t.Fatal(e)
	}
	bad := clone(books)
	v := bad["S0_C0_D0"]
	v.SourceEvents[0].Quantity++
	bad["S0_C0_D0"] = v
	if e = CheckSourceDelivery(bad, map[string]Ledger{"D164_15": source}); e == nil {
		t.Fatal("取消配送の破壊を受理")
	}
}

type collectingConsumer struct {
	observations []Observation
	mutate       bool
	begins, ends int
}

// Begin は人工consumerの開始設定を受け取ります。
//
// 引数: c(SourceCase)は実構築設定です。
// 返り値: errorは常にnilです。
func (c *collectingConsumer) Begin(v SourceCase) error {
	c.begins++
	if c.mutate {
		for k, a := range v.Normalizations {
			a.Requested.Cap = 999
			v.Normalizations[k] = a
		}
	}
	return nil
}

// Step は当時までの公開だけを検査し源と独立した観測を保存します。
//
// 引数: v(NativeStep)は当行の配送値です。
// 返り値: errorは未来の公開が含まれる場合に非nilです。
func (c *collectingConsumer) Step(v NativeStep) error {
	for _, p := range v.Publications {
		if p.At > v.Observation.Time || p.Candle.Time+float64(p.Interval)+60 != p.At {
			return fmt.Errorf("未来の公開")
		}
	}
	c.observations = append(c.observations, cloneObservation(v.Observation))
	if c.mutate {
		if v.Observation.Selected.DayBuy.Components != nil {
			v.Observation.Selected.DayBuy.Components.Windows["破壊"] = strategy.SelectedDay164Window{Known: true}
		}
		for _, b := range v.Mini {
			for _, s := range b.Delta.Signals {
				if len(s.Signal.Evidence) > 0 {
					s.Signal.Evidence[0] = '!'
				}
			}
		}
	}
	return nil
}

// End はEOFで源が完結し明示timerが0であることを確認します。
//
// 引数: v(SourceEnd)は源の終端です。
// 返り値: errorは完結又はtimer差です。
func (c *collectingConsumer) End(v SourceEnd) error {
	c.ends++
	if !v.Complete || v.ExplicitTimerCalls != 0 {
		return fmt.Errorf("EOF差")
	}
	return nil
}

// TestConsumerIsolationAndFutureCandles は未来足の差と外側変更が過去源へ作用しません。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。実市場の有望性を示す人工ではありません。
func TestConsumerIsolationAndFutureCandles(t *testing.T) {
	session, e := sessionClock("2026-09-21_Day")
	if e != nil {
		t.Fatal(e)
	}
	boards := []BoardEvent{}
	for i := 0; i < 70; i++ {
		at := session.Start + float64(i*60)
		boards = append(boards, BoardEvent{Board: strategy.Board{Reference: "NK225", Time: at, Received: at, Last: 1000, Bid: 990, Ask: 1010}, Line: int64(i + 1)})
	}
	candles := []CandlePublication{}
	for _, ref := range []string{"TOPIX", "NK225"} {
		for _, iv := range []int{60, 300} {
			for i := 0; i < 90; i++ {
				at := session.Start + float64(i*iv)
				candles = append(candles, CandlePublication{ref, iv, strategy.Candle{Time: at, Open: 1000, High: 1020, Low: 980, Close: 1000, Closed: true}, at + float64(iv) + 60})
			}
		}
	}
	left, right := &collectingConsumer{}, &collectingConsumer{mutate: true}
	a, e := ReplayEvents(session, "人工", boards, candles, left)
	if e != nil {
		t.Fatal(e)
	}
	changed := append([]CandlePublication(nil), candles...)
	for i := range changed {
		if changed[i].At > boards[len(boards)-1].Board.Time {
			changed[i].Candle.Close = 100000
			changed[i].Candle.High = 100001
		}
	}
	b, e := ReplayEvents(session, "人工", boards, changed, right)
	if e != nil {
		t.Fatal(e)
	}
	av, _ := json.Marshal(a)
	bv, _ := json.Marshal(b)
	if !bytes.Equal(av, bv) || !reflect.DeepEqual(left.observations, right.observations) || left.begins != 1 || right.ends != 1 {
		t.Fatal("未来足又はconsumerが源/過去観測を変更")
	}
}

// TestOriginalRawSelection はLast欠測で時計基準を進めずEnd等号を元通り採用します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。使うgzipは手製だけです。
func TestOriginalRawSelection(t *testing.T) {
	session, _ := sessionClock("2026-09-21_Day")
	path := filepath.Join(t.TempDir(), "手製.gz")
	file, e := os.Create(path)
	if e != nil {
		t.Fatal(e)
	}
	z := gzip.NewWriter(file)
	for _, p := range []struct{ delta, last float64 }{{5, 1000}, {8, 0}, {7, 1001}, {25200, 1002}} {
		at := time.Unix(int64(session.Start+p.delta), 0).UTC().Format(time.RFC3339Nano)
		v := map[string]any{"Symbol": "人工", "CurrentPriceTime": at, "CurrentPrice": p.last}
		for i := 1; i <= 10; i++ {
			v[fmt.Sprintf("Buy%d", i)] = map[string]any{"Price": 990, "Qty": 1}
			v[fmt.Sprintf("Sell%d", i)] = map[string]any{"Price": 1010, "Qty": 1}
		}
		data, _ := json.Marshal(v)
		if _, e = z.Write(append(data, '\n')); e != nil {
			t.Fatal(e)
		}
	}
	z.Close()
	file.Close()
	rows, q, e := readBoards(path, "NK225", session)
	if e != nil {
		t.Fatal(e)
	}
	if len(rows) != 3 || q.BadLast != 1 || q.Backward != 0 || rows[1].Line != 3 || rows[2].Board.Time != session.End {
		t.Fatalf("元Raw選択差:%+v %+v", rows, q)
	}
}

// TestGoldenBindsEverySavedEvent は総額一致だけでは原行や方向の差を通しません。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。全Signal同体flagは必ずfalseです。
func TestGoldenBindsEverySavedEvent(t *testing.T) {
	r, b := artificial(t, config111("NK225micro"))
	b.script[0] = []Signal{newSignal("初回", 1, 2)}
	b.script[2] = []Signal{closeSignal("返済", "初回-玉", 1, 2)}
	for i := int64(0); i < 4; i++ {
		step(t, r, observation(1, i, float64(i*10), true))
	}
	ledger, e := r.Finish()
	if e != nil {
		t.Fatal(e)
	}
	events, e := ledgerEvents(ledger)
	if e != nil {
		t.Fatal(e)
	}
	result := ReplayResult{Session: r.ledger.Session, Sources: map[string]Ledger{"NK225micro_D164_15": ledger}}
	golden := []GoldenResult{{Session: r.ledger.Session.ID, Method: "NK225_D164_15", Cap: 100, Events: events, Gross: ledger.Totals.GrossYen}}
	proof, e := CompareGoldenValues(result, golden, FileRef{Path: "手製", SHA256: "手製"})
	if e != nil || !proof.EventsEqual || proof.AllSignalEqual {
		t.Fatal("保存Event範囲差", e)
	}
	for _, mutate := range []func(*GoldenEvent){func(e *GoldenEvent) { e.DecisionIndex-- }, func(e *GoldenEvent) { e.FillIndex++ }, func(e *GoldenEvent) { e.Price++ }, func(e *GoldenEvent) { e.Side = -e.Side }, func(e *GoldenEvent) { e.Quantity++ }, func(e *GoldenEvent) { e.Time++ }, func(e *GoldenEvent) { e.Gross++ }} {
		bad := clone(golden)
		mutate(&bad[0].Events[0])
		if _, e = CompareGoldenValues(result, bad, FileRef{}); e == nil {
			t.Fatal("元保存Eventの破壊を受理")
		}
	}
}

// TestOracleReferenceBothProductsAndHistoricalFlag は再実行対照と当時記録を区別します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。ここで用いる値は手製であり実oracle結果ではありません。
func TestOracleReferenceBothProductsAndHistoricalFlag(t *testing.T) {
	result := ReplayResult{Sources: map[string]Ledger{}}
	references := map[string][]GoldenResult{}
	for _, product := range []string{"NK225micro", "NK225mini"} {
		r, b := artificial(t, config111(product))
		b.script[0] = []Signal{newSignal("初回", 1, 2)}
		b.script[2] = []Signal{closeSignal("返済", "初回-玉", 1, 2)}
		for i := int64(0); i < 4; i++ {
			step(t, r, observation(1, i, float64(i*10), true))
		}
		l, e := r.Finish()
		if e != nil {
			t.Fatal(e)
		}
		result.Session = r.ledger.Session
		result.Sources[product+"_D164_15"] = l
		events, e := ledgerEvents(l)
		if e != nil {
			t.Fatal(e)
		}
		references[product] = []GoldenResult{{Session: result.Session.ID, Method: "NK225_D164_15", Cap: l.Config.Cap, Events: events, Gross: l.Totals.GrossYen}}
	}
	origin := map[string]any{"kind": "rerun_original166_pinned_code", "FAR_commit": "cf0717daa1eed78759f78a428bce50129e7f705b", "strategy_commit": "67ba01588a60961ce2fb505ee5654999473dedab", "main_git_blob_sha": "6d8f1a63c94006e6cf7e80c9e988f06d995e2acb", "input_git_blob_sha": "784579f65444f1377d41354aa4458783a3d2bcf1", "run_body_unchanged": true, "historical_saved_events": false}
	value := map[string]any{"Results": references["NK225micro"], "mini_results": references["NK225mini"], "origin": origin}
	path := filepath.Join(t.TempDir(), "手製oracle形式.json")
	ref := writeFixtureJSON(t, path, value)
	proof, e := CompareGolden(result, ref)
	if e != nil || !proof.EventsEqual || !proof.MiniEventsEqual || proof.HistoricalSavedEventsEqual || proof.AllSignalEqual {
		t.Fatal("再実行の確認範囲差", e)
	}
	origin["historical_saved_events"] = true
	ref = writeFixtureJSON(t, filepath.Join(t.TempDir(), "歴史の偽認定.json"), value)
	if _, e = CompareGolden(result, ref); e == nil {
		t.Fatal("再実行を当時記録と偽認定")
	}
	origin["historical_saved_events"] = false
	mini := references["NK225mini"]
	mini[0].Events[0].Price++
	ref = writeFixtureJSON(t, filepath.Join(t.TempDir(), "mini改変.json"), value)
	if _, e = CompareGolden(result, ref); e == nil {
		t.Fatal("microだけでminiの差を見逃した")
	}
}
