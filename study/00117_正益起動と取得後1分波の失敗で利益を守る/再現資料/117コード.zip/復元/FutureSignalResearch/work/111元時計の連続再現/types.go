// Package continuous111 は元166の原行順を基準に選定三手法を連続判断します。
package continuous111

import (
	"fmt"
	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	protect "github.com/masayoshi4649/SessionTradeExecuter/miniprotect"
)

type Observation = native.Observation
type Session = native.Session
type Signal = native.Signal
type Fill = native.Fill
type ProductConfig = native.ProductConfig
type QuoteStamp = native.QuoteStamp
type CloseNotice = native.CloseNotice
type SignalRecord = native.SignalRecord
type CloseAllocation = native.CloseAllocation
type FillRecord = native.FillRecord
type Cancellation = native.Cancellation
type HoldLedger = native.HoldLedger
type Ledger = native.Ledger
type StepResult = native.StepResult
type ActualResult = protect.ActualResult

// NormalizationAudit は宣言と実Portfolio・内側源の設定を分けます。
type NormalizationAudit struct {
	Requested          strategy.Config `json:"requested"`
	Effective          strategy.Config `json:"effective"`
	Source             strategy.Config `json:"source"`
	Scope              string          `json:"scope"`
	ExplicitForceCalls int             `json:"explicit_force_calls"`
}

// OriginalConfig は元166のCore/Extra1/1と商品別Cap/点価だけを作ります。
//
// 引数: product(string)はNK225micro又はNK225miniです。
// 返り値: ProductConfig/errorは費用0の源規格又は対象外商品です。
func OriginalConfig(product string) (ProductConfig, error) {
	switch product {
	case "NK225micro":
		return ProductConfig{Product: product, CoreQuantity: 1, ExtraMaxQuantity: 1, Cap: 100, PointValue: 10, LargeTick: 10}, nil
	case "NK225mini":
		return ProductConfig{Product: product, CoreQuantity: 1, ExtraMaxQuantity: 1, Cap: 10, PointValue: 100, LargeTick: 10}, nil
	}
	return ProductConfig{}, fmt.Errorf("元166の対象商品ではありません:%s", product)
}

// Normalization は実構築した外側と内側の設定を独立値で返します。
//
// 引数: なし。Adapterの実構築情報を用います。
// 返り値: NormalizationAuditは設定の実物抜粋と明示Force回数です。
func (r *Adapter) Normalization() NormalizationAudit {
	out := clone(r.normalization)
	out.ExplicitForceCalls = r.forceCalls
	return out
}

// ActorConfigs は保護を追加しない4費用・遅延口座だけを宣言します。
//
// 引数: なし。
// 返り値: []protect.ActorConfigはS0のC0/C5×D0/D1です。
func ActorConfigs() []protect.ActorConfig {
	out := []protect.ActorConfig{}
	for _, c := range []float64{0, 5} {
		for _, d := range []int{0, 1} {
			out = append(out, protect.ActorConfig{Policy: "S0", SlipPts: c, DelaySeconds: d})
		}
	}
	return out
}
