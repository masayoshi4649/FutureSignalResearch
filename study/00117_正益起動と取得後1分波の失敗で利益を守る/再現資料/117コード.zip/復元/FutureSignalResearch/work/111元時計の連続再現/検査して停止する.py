"""元時計の基準と原文oracleの人工・ビルド・閉包を一度だけ停止する。"""

import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def digest(path: Path) -> str:
    """機能: 明示したコードや人工の全バイト指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def owned() -> dict:
    """機能: 検査/人工を除く全所有ソースと説明資料の指紋を作る。

    引数: なし。
    返り値: dictはRoot相対pathとSHA256。
    """
    return {p.relative_to(ROOT).as_posix(): digest(p) for p in sorted(HERE.rglob("*"))
            if p.is_file() and not any(x in p.relative_to(HERE).parts for x in ("検査", "人工_停止版", "__pycache__"))
            and p.name not in ("停止.json", "人工確認.json")}


def run(command: list[str], name: str, env: dict | None = None) -> dict:
    """機能: 人工/ビルドの終了コードと出力を記録する。

    引数: command(list[str])、name(str)、env(dict|None)は実行と検査名・環境。
    返り値: dictは終了コードとログ。不成功は例外にする。
    """
    result = subprocess.run(command, cwd=HERE, env=env, capture_output=True, text=True, encoding="utf-8")
    value = {"名": name, "command": command, "終了コード": result.returncode, "標準出力": result.stdout, "標準エラー": result.stderr}
    if result.returncode:
        print(result.stdout+result.stderr)
        raise ValueError("停止前検査失敗: "+name)
    return value


def go_closure() -> tuple[dict, dict]:
    """機能: 実ビルド対象2cmdの選択ソース閉包をgo listから取得する。

    引数: なし。
    返り値: tuple[dict,dict]は非GoRootとGoRootの現物指紋。
    """
    result = run(["go", "list", "-deps", "-json", "./cmd/baseline", "./cmd/oracle"], "実Go閉包")
    text, decoder, index = result["標準出力"], json.JSONDecoder(), 0
    local, standard = {}, {}
    while index < len(text):
        while index < len(text) and text[index].isspace():
            index += 1
        if index == len(text):
            break
        package, index = decoder.raw_decode(text, index)
        if not package.get("Dir"):
            continue
        target = standard if package.get("Goroot") else local
        for key in ("GoFiles", "CgoFiles", "SFiles", "HFiles", "SysoFiles", "EmbedFiles"):
            for name in package.get(key, []):
                path = (Path(package["Dir"]) / name).resolve()
                target[str(path)] = digest(path)
        module = package.get("Module", {})
        if module.get("GoMod"):
            path = Path(module["GoMod"]).resolve()
            local[str(path)] = digest(path)
            if path.with_name("go.sum").exists():
                local[str(path.with_name("go.sum"))] = digest(path.with_name("go.sum"))
    return local, standard


def main() -> None:
    """機能: 市場0の人工・実行物・全依存不変を確認して一度だけ停止する。

    引数: なし。Rootの市場固定/原板/新しい結果を開かない。
    返り値: None。未成功の停止記録を作らない。
    """
    if (HERE / "停止.json").exists() or (HERE / "人工確認.json").exists():
        raise ValueError("固定停止を上書きしない")
    before = owned()
    for name in before:
        path = ROOT / name
        if path.suffix == ".py":
            for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    comment = ast.get_docstring(node) or ""
                    if not ("\n" in comment and all(x in comment for x in ("機能", "引数", "返り値"))):
                        raise ValueError("Python関数コメント不足: "+node.name)
    condition = json.loads((ROOT / "study/00093_元三手法のmini連続再現と費用/条件.json").read_text(encoding="utf-8"))
    strategy = {str((Path(condition["純戦略repo"]) / p).resolve()): s for p, s in condition["純戦略SHA256"].items()}
    if len(strategy) != 43 or any(digest(Path(p)) != s for p, s in strategy.items()):
        raise ValueError("固定43純戦略の現物差")
    deps, standard = go_closure()
    env = dict(os.environ)
    env["CGO_ENABLED"] = "0"
    env["FSR111_ART_OUT"] = str(HERE / "人工_停止版")
    (HERE / "検査").mkdir(exist_ok=True)
    logs = [run(["go", "test", "-json", "-count=1", "-cover", "./..."], "全人工", env),
            run(["go", "vet", "./..."], "vet", env),
            run(["go", "build", "-o", str(HERE / "検査/111元時計.exe"), "./cmd/baseline"], "基準build", env),
            run(["go", "build", "-o", str(HERE / "検査/111原文oracle.exe"), "./cmd/oracle"], "原文oracle build", env)]
    tests = [json.loads(line) for line in logs[0]["標準出力"].splitlines() if line.startswith("{")]
    passed = [row for row in tests if row.get("Action") == "pass" and row.get("Test")]
    if len(passed) < 14:
        raise ValueError("全人工testが不足")
    artifacts = {str(p.relative_to(ROOT)).replace("\\", "/"): digest(p) for p in (HERE / "人工_停止版").glob("*.json")}
    if len(artifacts) != 2:
        raise ValueError("買売の全配送人工が不足")
    if owned() != before or any(digest(Path(p)) != s for p, s in {**deps, **standard, **strategy}.items()):
        raise ValueError("コード/全依存/純戦略の前後差")
    proof = {"成功": True, "UTC": datetime.now(timezone.utc).isoformat(), "主test": len(passed),
             "Go検査": logs, "人工SHA256": artifacts, "自己コード全依存前後不変": True,
             "市場実行": 0, "実原板読取": 0, "実golden読取": 0, "11月09日本文読取": 0,
             "当時保存Event同体": False, "全Signal全文同体": False, "採用": False, "研究目標達成": False}
    (HERE / "人工確認.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    binaries = {str(p.resolve()): digest(p) for p in (HERE / "検査").glob("*.exe")}
    stop = {"成功": True, "停止": True, "UTC": datetime.now(timezone.utc).isoformat(), "主test": len(passed),
            "所有コードSHA256": before, "Go閉包SHA256": deps, "GoRootコードSHA256": standard, "純戦略43SHA256": strategy,
            "実行物SHA256": binaries, "人工確認SHA256": digest(HERE / "人工確認.json"), "人工SHA256": artifacts,
            "自己コード全依存前後不変": True,
            "範囲": "元166原行順の新Source/mini4S0、固定原文oracle run/入力選別AST、明示consumer、metadataゲートの人工とbuild",
            "市場実行": 0, "実原板読取": 0, "当時保存Event同体": False, "全Signal全文同体": False,
            "未見11月09日本文読取": False, "採用": False, "研究目標達成": False}
    (HERE / "停止.json").write_text(json.dumps(stop, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"成功": True, "停止SHA256": digest(HERE / "停止.json"), "主test": len(passed),
                      "Go閉包": len(deps), "GoRoot": len(standard), "人工": len(artifacts), "exe": binaries}, ensure_ascii=False))


if __name__ == "__main__":
    main()
