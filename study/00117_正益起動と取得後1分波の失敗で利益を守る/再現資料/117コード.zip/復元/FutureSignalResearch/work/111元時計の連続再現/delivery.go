package continuous111

import (
	"fmt"
	"reflect"
	"sort"
)

type deliveryKey struct {
	Method, Kind, Signal, Execution, Hold, Notice string
	At                                            float64
	Quote                                         QuoteStamp
	Side, Quantity, Before                        int
}
type sourceEvent struct {
	Index  int64
	Phase  int
	Signal *SignalRecord
	Fill   *FillRecord
	Cancel *Cancellation
}

// CheckSourceDelivery は全出生・取消・源fill・返済通知が4Actorへ同じに届いたか検査します。
//
// 引数: books(map[string]ActualResult)、sources(map[string]Ledger)は4費用口座とmini源です。
// 返り値: errorは出典・原行・所有量・元通知分母の差です。D1の実fill一致は要求しません。
func CheckSourceDelivery(books map[string]ActualResult, sources map[string]Ledger) error {
	expected := map[deliveryKey]int{}
	births, cancels, newfills, closefills, notices := 0, 0, 0, 0, 0
	for _, ledger := range sources {
		method := ledger.Method
		events := []sourceEvent{}
		signals := map[string]SignalRecord{}
		for i := range ledger.Signals {
			s := &ledger.Signals[i]
			signals[s.Signal.ID] = *s
			events = append(events, sourceEvent{Index: s.Quote.Index, Phase: 1, Signal: s})
		}
		for i := range ledger.Fills {
			f := &ledger.Fills[i]
			events = append(events, sourceEvent{Index: f.Quote.Index, Phase: 0, Fill: f})
		}
		for i := range ledger.Cancellations {
			c := &ledger.Cancellations[i]
			events = append(events, sourceEvent{Index: c.Quote.Index, Phase: 2, Cancel: c})
		}
		sort.SliceStable(events, func(i, j int) bool {
			if events[i].Index == events[j].Index {
				return events[i].Phase < events[j].Phase
			}
			return events[i].Index < events[j].Index
		})
		qty, reserved := map[string]int{}, map[string]int{}
		for _, e := range events {
			if e.Fill != nil {
				f := e.Fill
				kind := "close_fill"
				if f.Action == "new" {
					kind = "new_fill"
					newfills++
					qty[f.Fill.HoldID] = f.Fill.Quantity
				} else {
					closefills++
					for _, t := range f.Fill.Closed {
						qty[t.ID] -= t.Quantity
						reserved[t.ID] -= t.Quantity
					}
				}
				expected[deliveryKey{Method: method, Kind: kind, Signal: f.Fill.SignalID, Execution: f.Fill.ExecutionID, Hold: f.Fill.HoldID, At: f.Quote.Time, Quote: f.Quote, Side: f.Side, Quantity: f.Fill.Quantity}]++
			} else if e.Signal != nil {
				r := e.Signal
				s := r.Signal
				if s.Action == "new" {
					births++
					expected[deliveryKey{Method: method, Kind: "new_signal", Signal: s.ID, At: r.At, Quote: r.Quote, Side: s.Side, Quantity: s.Quantity}]++
				} else {
					for _, t := range s.Targets {
						before := qty[t.ID] - reserved[t.ID]
						notices++
						expected[deliveryKey{Method: method, Kind: "close_notice", Signal: s.ID, Hold: t.ID, Notice: s.ID + "|" + t.ID, At: r.At, Quote: r.Quote, Side: s.Side, Quantity: t.Quantity, Before: before}]++
						reserved[t.ID] += t.Quantity
					}
				}
			} else {
				c := e.Cancel
				s, ok := signals[c.SignalID]
				if !ok {
					return fmt.Errorf("取消に出生がない")
				}
				cancels++
				expected[deliveryKey{Method: method, Kind: "cancel", Signal: c.SignalID, At: c.At, Quote: c.Quote, Side: s.Signal.Side, Quantity: s.Signal.Quantity}]++
			}
		}
	}
	for key, book := range books {
		actual := map[deliveryKey]int{}
		for _, e := range book.SourceEvents {
			actual[deliveryKey{Method: e.Method, Kind: e.Kind, Signal: e.SignalID, Execution: e.ExecutionID, Hold: e.HoldID, Notice: e.NoticeID, At: e.At, Quote: e.Quote, Side: e.Side, Quantity: e.Quantity, Before: e.Before}]++
		}
		if !reflect.DeepEqual(actual, expected) {
			return fmt.Errorf("全源通知/取消/fill/所有分母の配送差:%s", key)
		}
		m := book.Metrics
		if m.NativeNewSignals != births || m.NativeCancels != cancels || m.NativeNewFills != newfills || m.NativeCloseFills != closefills || m.NativeCloseNotices != notices {
			return fmt.Errorf("源配送計数の差:%s", key)
		}
	}
	return nil
}
