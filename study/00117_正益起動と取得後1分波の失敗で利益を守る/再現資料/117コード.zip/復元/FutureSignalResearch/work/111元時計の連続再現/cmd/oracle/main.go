package main

import (
	"compress/gzip"
	"encoding/json"
	"flag"
	"fmt"
	core "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	"io"
	"os"
	"path/filepath"
)

type gzipInput struct {
	*gzip.Reader
	file *os.File
}

// Close は展開器と元ファイルを閉じます。
//
// 引数: なし。
// 返り値: errorは展開又はファイルの終了差です。
func (g *gzipInput) Close() error {
	a := g.Reader.Close()
	b := g.file.Close()
	if a != nil {
		return a
	}
	return b
}

// openInput は原板の重複ファイルを作らずgzipを原文scannerへ渡します。
//
// 引数: path(string)は認証済み共有原板です。
// 返り値: io.ReadCloser/errorは非圧縮ストリーム又は入出力異常です。
func openInput(path string) (io.ReadCloser, error) {
	f, e := os.Open(path)
	if e != nil {
		return nil, e
	}
	if filepath.Ext(path) != ".gz" {
		return f, nil
	}
	z, e := gzip.NewReader(f)
	if e != nil {
		f.Close()
		return nil, e
	}
	return &gzipInput{Reader: z, file: f}, nil
}

// saveNew はoracleの新規JSONを既存先へ上書きせず保存します。
//
// 引数: path(string)、value(any)は新規先と値です。
// 返り値: core.FileRef/errorは結果指紋又は保存差です。
func saveNew(path string, value any) (core.FileRef, error) {
	raw, e := json.MarshalIndent(value, "", "  ")
	if e != nil {
		return core.FileRef{}, e
	}
	f, e := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if e != nil {
		return core.FileRef{}, e
	}
	_, e = f.Write(append(raw, '\n'))
	if c := f.Close(); e == nil {
		e = c
	}
	if e != nil {
		return core.FileRef{}, e
	}
	s, e := core.Digest(path)
	return core.FileRef{Path: path, SHA256: s}, e
}

// originalScene は固定台帳の位置だけを元166のSceneへ適応します。
//
// 引数: root(string)、input(core.InputCase)は共有入力根と固定場です。
// 返り値: Scene/errorは元時計と認証済み参照です。価格を複製しません。
func originalScene(root string, input core.InputCase) (Scene, error) {
	s, e := core.SessionFor(input.ID)
	if e != nil {
		return Scene{}, e
	}
	scene := Scene{Session: input.ID, Kind: s.Kind, Start: s.Start, End: s.End, Cutoff: input.Cutoff, USOpen: s.USOpen, ForceClose: s.ForceClose, Books: map[string]string{}, Candles: map[string]map[string]string{}}
	for _, ref := range []string{"TOPIX", "NK225"} {
		p, e := core.VerifyInput(root, input.Files[ref+"_book"])
		if e != nil {
			return scene, e
		}
		scene.Books[ref] = p
		scene.Candles[ref] = map[string]string{}
		for _, iv := range []int{60, 300} {
			p, e = core.VerifyInput(root, input.Files[fmt.Sprintf("%s_candle_%d", ref, iv)])
			if e != nil {
				return scene, e
			}
			scene.Candles[ref][fmt.Sprint(iv)] = p
		}
	}
	return scene, nil
}

// checkResults は原文runが返した源の終了所有・予約・異常を検査します。
//
// 引数: result([]Result)、cap(int)は原文runの戻した商品別結果です。
// 返り値: errorは未完了又は不成功です。公表粗額一致とは分けます。
func checkResults(result []Result, cap int) error {
	if len(result) == 0 {
		return fmt.Errorf("元runの結果がない")
	}
	for _, r := range result {
		if r.Cap != cap || r.Error != "" || r.Pending != 0 || r.Held != 0 || len(r.Differences) != 0 {
			return fmt.Errorf("元run未完了:%s %s", r.Session, r.Method)
		}
	}
	return nil
}

// runCLI はRoot固定の元原文を別実行し、当時保存と混同しない新対照を作ります。
//
// 引数: CLIのfixed/fixed-sha/stage/outはRoot固定、段階、新規先です。
// 返り値: errorは未固定、原文run、入力不変又は保存の差です。
func runCLI() error {
	fixed := flag.String("fixed", "", "Root固定")
	fixedSHA := flag.String("fixed-sha", "", "固定SHA")
	stage := flag.String("stage", "", "first2/original54")
	out := flag.String("out", "", "未使用出力先")
	flag.Parse()
	if *fixed == "" || *fixedSHA == "" || *stage == "" || *out == "" {
		return fmt.Errorf("固定Ref・stage・新規先が必要")
	}
	plan, e := core.PrepareOracleRun(core.FileRef{Path: *fixed, SHA256: *fixedSHA}, *stage)
	if e != nil {
		return e
	}
	absolute, e := filepath.Abs(*out)
	if e != nil {
		return e
	}
	if _, e = os.Stat(absolute); !os.IsNotExist(e) {
		return fmt.Errorf("oracle先は未使用folder")
	}
	if e = os.MkdirAll(absolute, 0755); e != nil {
		return e
	}
	refs := map[string]core.FileRef{}
	totals := map[string]float64{}
	miniTotals := map[string]float64{}
	for i, input := range plan.Cases {
		scene, e := originalScene(plan.Manifest.Root, input)
		if e != nil {
			return e
		}
		micro, e := run(scene, 100)
		if e != nil {
			return e
		}
		if e = checkResults(micro, 100); e != nil {
			return e
		}
		mini, e := run(scene, 10)
		if e != nil {
			return e
		}
		if e = checkResults(mini, 10); e != nil {
			return e
		}
		for _, r := range micro {
			totals[r.Method] += r.Gross
		}
		for _, r := range mini {
			miniTotals[r.Method] += r.Gross
		}
		for _, file := range input.Files {
			if _, e = core.VerifyInput(plan.Manifest.Root, file); e != nil {
				return e
			}
		}
		value := map[string]any{"Results": micro, "mini_results": mini, "Error": "", "origin": map[string]any{"kind": "rerun_original166_pinned_code", "FAR_commit": plan.Fixed.FARCommit, "strategy_commit": plan.Fixed.StrategyCommit, "main_git_blob_sha": "6d8f1a63c94006e6cf7e80c9e988f06d995e2acb", "input_git_blob_sha": "784579f65444f1377d41354aa4458783a3d2bcf1", "run_body_unchanged": true, "historical_saved_events": false}, "scope": "固定原文runを現在の固定純戦略と既使用入力で再実行した対照。当時保存Event同体は未証明。importとgzip読取I/Oだけ適応"}
		ref, e := saveNew(filepath.Join(absolute, input.ID+".oracle.json"), value)
		if e != nil {
			return e
		}
		refs[input.ID] = ref
		fmt.Printf("%d/%d %s 原文oracle完結\n", i+1, len(plan.Cases), input.ID)
	}
	after := map[string]string{}
	for path, s := range plan.Before {
		got, e := core.Digest(path)
		if e != nil || got != s {
			return fmt.Errorf("oracleの固定入力/code不変差:%s", path)
		}
		after[path] = got
	}
	expected := map[string]float64{"NK225_D164_15": 1248500, "NK225_P164_06": 392000, "NK225_U165_03": 1181000}
	publicMatch := *stage == "original54"
	for key, want := range expected {
		if totals[key] != want {
			publicMatch = false
		}
	}
	completion := map[string]any{"version": 1, "trial": 111, "stage": *stage, "success": true, "condition_sha256": *fixedSHA, "sessions": len(plan.Cases), "results": refs, "micro_gross": totals, "mini_gross": miniTotals, "published_micro_gross": expected, "published_gross_checked": *stage == "original54", "published_gross_equal": publicMatch, "historical_saved_event_equality": false, "all_signal_full_json_equal": false, "kind": "rerun_original166_pinned_code", "before": plan.Before, "after": after, "unchanged": true, "raw_copied": false, "holdout_11_09_read": false}
	_, e = saveNew(filepath.Join(absolute, "完了.json"), completion)
	return e
}

// main は原文oracleだけを呼び、旧mainや旧golden比較を呼びません。
//
// 引数: なし。
// 返り値: なし。成功0、失敗1です。
func main() {
	if e := runCLI(); e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
}
