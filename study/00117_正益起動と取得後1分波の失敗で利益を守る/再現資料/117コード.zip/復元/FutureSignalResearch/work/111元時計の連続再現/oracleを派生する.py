"""元166原文runを変更せずimport・gzip入力だけを新moduleへ適応する。"""

import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def git_blob(data: bytes) -> str:
    """機能: Gitが示した原文blob指紋を再計算する。

    引数: data(bytes)は原文。
    返り値: strはGit blob SHA1。
    """
    return hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()


def main() -> None:
    """機能: run本体を保った独立oracleのソースを新規作成する。

    引数: なし。取得済み原文2ファイルだけを読む。
    返り値: None。原板・旧コードを読み書きしない。
    """
    pins = {"main.go": "6d8f1a63c94006e6cf7e80c9e988f06d995e2acb", "input.go": "784579f65444f1377d41354aa4458783a3d2bcf1"}
    out = HERE / "cmd/oracle"
    out.mkdir(parents=True, exist_ok=True)
    proof = {}
    for name, expected in pins.items():
        path = HERE / "oracle原文" / (name+".txt")
        data = path.read_text(encoding="utf-8").rstrip("\n")+"\n"
        if git_blob(data.encode()) != expected:
            raise ValueError("元Git blob差: "+name)
        changed = data.replace('"futurealgorithm/sessiontrader/internal/strategy"', '"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"')
        if name == "main.go":
            changed = changed.replace("func main() {", "func originalMainUnused() {", 1)
        else:
            changed = changed.replace("os.Open(scene.Books[ref])", "openInput(scene.Books[ref])")
        target = out / ("original_"+name)
        if target.exists():
            raise ValueError("oracle派生は新規だけ")
        target.write_text(changed, encoding="utf-8", newline="\n")
        proof[name] = {"git_blob_sha": expected, "原文sha256": hashlib.sha256(data.encode()).hexdigest(),
                       "派生sha256": hashlib.sha256(target.read_bytes()).hexdigest()}
    (HERE / "oracle派生の参照.json").write_text(json.dumps({"原文": proof, "変更範囲": ["import先", "旧main名（呼出しなし）", "原板os.Openをgzip読取対応へ"], "run本体変更": 0, "原板複写": 0}, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")


if __name__ == "__main__":
    main()
