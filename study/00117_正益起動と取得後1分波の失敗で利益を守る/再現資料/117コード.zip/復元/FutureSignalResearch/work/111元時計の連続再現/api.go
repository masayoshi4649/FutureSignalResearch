package continuous111

import (
	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	protect "github.com/masayoshi4649/SessionTradeExecuter/miniprotect"
	"sort"
)

type InputCase = InputSession
type BoardEvent = replayBoard
type CandlePublication = candleEvent
type NativeBatch = protect.NativeBatch
type NativeNotification = StepResult
type NativeFill = FillRecord
type SourceHold = HoldLedger

// SessionFor は元の場・US時計を外側CLIにも同じ定義で渡します。
//
// 引数: id(string)は開始日付き場IDです。
// 返り値: Session/errorは元のセッション又は不正IDです。
func SessionFor(id string) (Session, error) { return sessionClock(id) }

// VerifyInput は元166oracleのI/O適応からも共通の入力指紋を認証します。
//
// 引数: root(string)、file(InputFile)は共有入力根と固定参照です。
// 返り値: string/errorは認証済み絶対位置又は実物差です。
func VerifyInput(root string, file InputFile) (string, error) { return verifyInput(root, file) }

// SourceCase は開始時に渡す元時計と実構築設定です。
type SourceCase struct {
	Session        Session                       `json:"session"`
	Contract       string                        `json:"contract"`
	Normalizations map[string]NormalizationAudit `json:"normalizations"`
}

// HoldEvent は当行に影響されたSource所有の現在値です。
type HoldEvent struct {
	Product string     `json:"product"`
	Method  string     `json:"method"`
	Hold    SourceHold `json:"hold"`
}

// NativeStep は一回だけのRaw読取から外Actorへ渡す因果的な値です。
type NativeStep struct {
	Observation  Observation         `json:"observation"`
	SourceLine   int64               `json:"source_line"`
	Mini         []NativeBatch       `json:"mini"`
	Micro        []NativeBatch       `json:"micro"`
	Holds        []HoldEvent         `json:"holds"`
	Publications []CandlePublication `json:"publications"`
}

// SourceEnd はEOFに架空返済を足さず完結を確認した後の通知です。
type SourceEnd struct {
	Session            Session `json:"session"`
	Complete           bool    `json:"complete"`
	ExplicitTimerCalls int     `json:"explicit_timer_calls"`
}

// SourceConsumer は同じ源通知を別の保護Actorへ配送する接続口です。
// 受け取る値は源と別所有で、返り値のerrorは再生を中止します。
type SourceConsumer interface {
	Begin(SourceCase) error
	Step(NativeStep) error
	End(SourceEnd) error
}

// cloneObservation は当時特徴の可変Componentsだけを独立複写します。
//
// 引数: o(Observation)は元Featuresが返した値です。
// 返り値: Observationは外consumerが変更しても源を変えない値です。
func cloneObservation(o Observation) Observation {
	for _, s := range []*strategy.SelectedDay164Support{&o.Selected.DayBuy, &o.Selected.DaySell} {
		if s.Components != nil {
			copy := *s.Components
			copy.Windows = map[string]strategy.SelectedDay164Window{}
			for k, v := range s.Components.Windows {
				copy.Windows[k] = v
			}
			s.Components = &copy
		}
	}
	return o
}

// touchedHolds は当行の新規fill又は返済通知/約定に関係する所有だけを返します。
//
// 引数: product/method(string)、delta(StepResult)は配送の出典です。
// 返り値: []HoldEventは現在量を持つ独立値です。未取得の仮想所有を作りません。
func (r *Adapter) touchedHolds(product, method string, delta StepResult) []HoldEvent {
	ids := map[string]bool{}
	for _, f := range delta.Fills {
		if f.Action == "new" {
			ids[f.Fill.HoldID] = true
		}
		for _, a := range f.Allocations {
			ids[a.HoldID] = true
		}
	}
	for _, c := range delta.Closes {
		ids[c.ReferenceID] = true
	}
	keys := []string{}
	for id := range ids {
		keys = append(keys, id)
	}
	sort.Strings(keys)
	out := []HoldEvent{}
	for _, id := range keys {
		if i, ok := r.holdIndex[id]; ok {
			out = append(out, HoldEvent{product, method, clone(r.ledger.Holds[i])})
		}
	}
	return out
}

// ReplayWithConsumer は原板を一度だけ読み、基準4口座と外Actorへ同じ源を送ります。
//
// 引数: root(string)、input(InputCase)、consumer(SourceConsumer|nil)は固定根・場・追加Actor接続です。
// 返り値: ReplayResult/errorは基準と外接続の成否です。外保護を源へ戻しません。
func ReplayWithConsumer(root string, input InputCase, consumer SourceConsumer) (ReplayResult, error) {
	return replayInput(root, input, consumer)
}

// ReplayEvents は市場ファイルを開かない手製又は認証済みイベント接続です。
//
// 引数: session(Session)、contract(string)、boards([]BoardEvent)、candles([]CandlePublication)、consumer(SourceConsumer|nil)は明示入力です。
// 返り値: ReplayResult/errorは元時計の基準4口座と全源です。外部timerを追加しません。
func ReplayEvents(session Session, contract string, boards []BoardEvent, candles []CandlePublication, consumer SourceConsumer) (ReplayResult, error) {
	return replayEventsWithConsumer(session, contract, boards, candles, map[string]RawQuality{}, consumer)
}
