package continuous111

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// writeFixtureJSON は市場を含まない手製metadataを新規保存します。
//
// 引数: t(*testing.T)、path(string)、value(any)は試験器・先・人工値です。
// 返り値: FileRefは生成した期待指紋です。
func writeFixtureJSON(t *testing.T, path string, value any) FileRef {
	t.Helper()
	if e := os.MkdirAll(filepath.Dir(path), 0755); e != nil {
		t.Fatal(e)
	}
	ref, e := writeNewJSON(path, value, false)
	if e != nil {
		t.Fatal(e)
	}
	return ref
}

// artificialFixed はRaw未作成でも準備検査できる70場固定を作ります。
//
// 引数: t(*testing.T)、base(string)は試験器と一時領域です。
// 返り値: FileRef/Fixedは手製条件と全設定です。金融は実行しません。
func artificialFixed(t *testing.T, base string) (FileRef, Fixed) {
	t.Helper()
	old, err := os.ReadFile("../../study/00093_元三手法のmini連続再現と費用/条件.json")
	if err != nil {
		t.Fatal(err)
	}
	var c struct {
		Strategy map[string]string `json:"純戦略SHA256"`
		Root     string            `json:"純戦略repo"`
	}
	if err = json.Unmarshal(old, &c); err != nil {
		t.Fatal(err)
	}
	m := InputManifest{Root: filepath.Join(base, "開かないRaw"), StrategyRoot: c.Root, StrategySHA256: c.Strategy}
	day, _ := time.Parse("2006-01-02", "2026-09-21")
	for ; day.Format("2006-01-02") <= "2026-11-06"; day = day.AddDate(0, 0, 1) {
		if day.Weekday() == time.Saturday || day.Weekday() == time.Sunday {
			continue
		}
		for _, kind := range []string{"Day", "Night"} {
			files := map[string]InputFile{}
			for _, name := range []string{"NK225_book", "TOPIX_book", "NK225_candle_60", "NK225_candle_300", "TOPIX_candle_60", "TOPIX_candle_300"} {
				files[name] = InputFile{Path: "未作成/" + day.Format("2006-01-02") + kind + name, Size: 1, SHA256: "0000000000000000000000000000000000000000000000000000000000000000"}
			}
			m.Sessions = append(m.Sessions, InputSession{ID: day.Format("2006-01-02") + "_" + kind, Contract: "人工", Files: files})
		}
	}
	f := Fixed{Version: 1, Trial: 111, Fixed: true, Policy: "original166_continuous_baseline", FARCommit: "cf0717daa1eed78759f78a428bce50129e7f705b", StrategyCommit: "67ba01588a60961ce2fb505ee5654999473dedab", CodeSHA256: map[string]string{}, Golden: map[string]FileRef{}}
	f.Manifest = writeFixtureJSON(t, filepath.Join(base, "台帳.json"), m)
	exe, e := os.Executable()
	if e != nil {
		t.Fatal(e)
	}
	s, e := Digest(exe)
	if e != nil {
		t.Fatal(e)
	}
	f.Executable = FileRef{Path: exe, SHA256: s}
	for _, path := range sourceCodePaths() {
		s, e := Digest(path)
		if e != nil {
			t.Fatal(e)
		}
		f.CodeSHA256[path] = s
	}
	for _, scene := range m.Sessions[:54] {
		s, _ := sessionClock(scene.ID)
		g := []GoldenResult{}
		for _, method := range methodsFor(s) {
			g = append(g, GoldenResult{Session: s.ID, Method: "NK225_" + method, Cap: 100})
		}
		f.Golden[scene.ID] = writeFixtureJSON(t, filepath.Join(base, scene.ID+".json"), map[string]any{"Results": g, "Error": "<nil>"})
	}
	return writeFixtureJSON(t, filepath.Join(base, "固定.json"), f), f
}

// TestPrepareRequiresFixedBeforeRaw は未固定・途中・改変・誤対照を本文前に拒否します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。Rawフォルダが存在しないまま準備成功を確認します。
func TestPrepareRequiresFixedBeforeRaw(t *testing.T) {
	base := t.TempDir()
	ref, f := artificialFixed(t, base)
	plan, e := PrepareRun(ref, "first2", nil)
	if e != nil {
		t.Fatal(e)
	}
	if len(plan.Cases) != 2 {
		t.Fatal("first2集合")
	}
	if _, e = os.Stat(plan.Manifest.Root); !os.IsNotExist(e) {
		t.Fatal("Rawを作成/読取")
	}
	if _, e = PrepareRun(ref, "full70", nil); e == nil {
		t.Fatal("元54未確認で全70を許可")
	}
	bad := f
	bad.Fixed = false
	badRef := writeFixtureJSON(t, filepath.Join(base, "未固定.json"), bad)
	if _, e = PrepareRun(badRef, "first2", nil); e == nil {
		t.Fatal("未固定受理")
	}
	if _, e = PrepareRun(FileRef{Path: ref.Path, SHA256: "0000000000000000000000000000000000000000000000000000000000000000"}, "first2", nil); e == nil {
		t.Fatal("誤SHA受理")
	}
	bad = f
	bad.Golden = map[string]FileRef{}
	badRef = writeFixtureJSON(t, filepath.Join(base, "元欠落.json"), bad)
	if _, e = PrepareRun(badRef, "first2", nil); e == nil {
		t.Fatal("元54対照欠落を受理")
	}
	// ----------------------------------------
	// 期待SHAを作り直しても失敗した元Event保存は市場本文前に拒否します。
	bad = f
	bad.Golden = map[string]FileRef{}
	for k, v := range f.Golden {
		bad.Golden[k] = v
	}
	first := plan.Manifest.Sessions[0].ID
	bad.Golden[first] = writeFixtureJSON(t, filepath.Join(base, "失敗Golden.json"), map[string]any{"Error": "未完了"})
	badRef = writeFixtureJSON(t, filepath.Join(base, "元不成功.json"), bad)
	if _, e = PrepareRun(badRef, "first2", nil); e == nil {
		t.Fatal("元不成功を受理")
	}
	if _, e = PrepareRun(ref, "wrong", nil); e == nil {
		t.Fatal("不明stage受理")
	}
}

// TestMetadataAndOracleDoNotNeedHistoricalGolden は原文再実行の準備を歴史資料不足で止めません。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。Raw未作成、金融未実行を保ちます。
func TestMetadataAndOracleDoNotNeedHistoricalGolden(t *testing.T) {
	base := t.TempDir()
	_, f := artificialFixed(t, base)
	f.Golden = nil
	f.OracleExecutable = f.Executable
	ref := writeFixtureJSON(t, filepath.Join(base, "oracle固定.json"), f)
	plan, e := PrepareOracleRun(ref, "first2")
	if e != nil || len(plan.Cases) != 2 {
		t.Fatal(e)
	}
	meta, e := PrepareMetadata(ref)
	if e != nil || len(meta.Cases) != 70 {
		t.Fatal(e)
	}
	if _, e = PrepareRun(ref, "first2", nil); e == nil {
		t.Fatal("対照なしの本比較を許可")
	}
	if _, e = PrepareOracleRun(ref, "full70"); e == nil {
		t.Fatal("oracleで元54段階を飛ばした")
	}
	if _, e = os.Stat(meta.Manifest.Root); !os.IsNotExist(e) {
		t.Fatal("準備でRawを作成")
	}
}
