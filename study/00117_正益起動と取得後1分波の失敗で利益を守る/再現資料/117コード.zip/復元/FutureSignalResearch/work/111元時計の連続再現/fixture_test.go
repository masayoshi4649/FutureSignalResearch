package continuous111

import (
	"encoding/json"
	"fmt"
	"reflect"
	"testing"

	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
)

// fakeBook は元判断を捏造せず、約定/所有接続だけを手計算する器具です。
type fakeBook struct {
	script     map[int64][]Signal
	cancelAt   map[int64][]string
	owned      []strategy.SelectedLot
	orders     map[string]Signal
	done       map[string]bool
	cancels    []string
	observed   []int64
	fills      []Fill
	rejected   []string
	lastIndex  int64
	forced     bool
	forceCount int
}

// lots は人工所有を値コピーします。
//
// 引数: ありません。
// 返り値: []strategy.SelectedLotは人工の現在所有です。
func (b *fakeBook) lots() []strategy.SelectedLot { return append([]strategy.SelectedLot{}, b.owned...) }

// ObserveWithFreshness は人工の発行原行を元APIと同じ契約で進めます。
//
// 引数: o(Observation)、allow/fresh(bool)は当行と旧接続旗です。
// 返り値: []Signal/errorは今回の人工要求だけです。
func (b *fakeBook) ObserveWithFreshness(o Observation, allow, fresh bool) ([]Signal, error) {
	if !allow || !fresh {
		return nil, fmt.Errorf("元全原行判断を変更しました")
	}
	b.observed = append(b.observed, o.Index)
	b.lastIndex = o.Index
	b.cancels = append([]string{}, b.cancelAt[o.Index]...)
	out := []Signal{}
	for _, s := range b.script[o.Index] {
		if b.forced && s.Action == "new" {
			continue
		}
		s.Time, s.SourceIndex = o.Time, o.Index
		s.Evidence = json.RawMessage(fmt.Sprintf(`{"kind":"initial","parent":"親","source_id":"元源","method":"NK225_D164_15","quantity_micro":%d}`, s.Quantity*10))
		b.orders[s.ID] = s
		out = append(out, s)
	}
	return out, nil
}

// OnFill は費用0・実BBOの約定を人工の同じHoldIDへ反映します。
//
// 引数: f(Fill)は当行の実約定です。
// 返り値: errorは注文/所有/費用の不整合です。
func (b *fakeBook) OnFill(f Fill) error {
	s, ok := b.orders[f.SignalID]
	if !ok || b.done[s.ID] || f.Fee != 0 {
		return fmt.Errorf("人工Fill契約違反")
	}
	if s.Action == "new" {
		b.owned = append(b.owned, strategy.SelectedLot{ID: f.ExecutionID, HoldID: f.HoldID, EntryID: s.ID, Parent: "親", SourceID: "元源", Kind: "initial", Owner: s.Owner, Side: s.Side, Quantity: f.Quantity, InitialQuantity: f.Quantity, Entry: f.Price, At: f.Time})
	} else {
		if !reflect.DeepEqual(f.Closed, s.Targets) {
			return fmt.Errorf("返済所有を変更しました")
		}
		for _, target := range f.Closed {
			found := false
			for i := range b.owned {
				l := &b.owned[i]
				if l.HoldID == target.ID {
					if target.Quantity > l.Quantity {
						return fmt.Errorf("過剰返済")
					}
					l.Quantity -= target.Quantity
					l.Realized += float64(l.Side) * (f.Price - l.Entry) * float64(target.Quantity) * 100
					found = true
				}
			}
			if !found {
				return fmt.Errorf("未知所有")
			}
		}
	}
	b.fills = append(b.fills, clone(f))
	return nil
}

// OnOrderDone は全量約定又は取消後の注文終了を記録します。
//
// 引数: id(string)は元Signal IDです。
// 返り値: errorは二重又は未知ID終了です。
func (b *fakeBook) OnOrderDone(id string) error {
	if _, ok := b.orders[id]; !ok || b.done[id] {
		return fmt.Errorf("未知又は二重終了")
	}
	b.done[id] = true
	kept := []string{}
	for _, v := range b.cancels {
		if v != id {
			kept = append(kept, v)
		}
	}
	b.cancels = kept
	return nil
}

// OnOrderRejected は取消を実約定に数えず注文を終了します。
//
// 引数: id(string)は元新規IDです。
// 返り値: errorは元終了の失敗です。
func (b *fakeBook) OnOrderRejected(id string) error {
	b.rejected = append(b.rejected, id)
	return b.OnOrderDone(id)
}

// SelectedCancellationIDs は未処理の人工取消を返します。
//
// 引数: ありません。
// 返り値: []stringは現在の取消要求です。
func (b *fakeBook) SelectedCancellationIDs() []string { return append([]string{}, b.cancels...) }

// Flatten は既存予約を引いた現在所有だけの返済を発行します。
//
// 引数: at(float64)、reason(string)は境界時計と理由です。
// 返り値: []Signalは新しい未予約分だけです。
func (b *fakeBook) Flatten(at float64, reason string) []Signal {
	b.forced = true
	b.forceCount++
	reserved := map[string]int{}
	for id, s := range b.orders {
		if !b.done[id] && s.Action == "close" {
			for _, v := range s.Targets {
				reserved[v.ID] += v.Quantity
			}
		}
	}
	out := []Signal{}
	for _, l := range b.owned {
		qty := l.Quantity - reserved[l.HoldID]
		if qty <= 0 {
			continue
		}
		s := Signal{ID: fmt.Sprintf("強制%d-%s", b.forceCount, l.HoldID), Owner: "core", Action: "close", Side: -l.Side, Quantity: qty, Time: at, SourceIndex: b.lastIndex, Reason: reason, Targets: []strategy.LotTarget{{ID: l.HoldID, Quantity: qty}}}
		b.orders[s.ID] = s
		out = append(out, s)
	}
	return out
}

// artificial は元公開constructor後に約定接続だけを人工bookへ差し替えます。
//
// 引数: t(*testing.T)、config(ProductConfig)は試験器と商品規格です。
// 返り値: *Adapter/*fakeBookは新しい空会計です。元信号の自然発生の証明ではありません。
func artificial(t *testing.T, config ProductConfig) (*Adapter, *fakeBook) {
	t.Helper()
	r, err := NewAdapter("D164_15", Session{ID: "人工_Day", Kind: "Day", Start: 1000, ForceClose: 20000, End: 20600}, config)
	if err != nil {
		t.Fatal(err)
	}
	b := &fakeBook{script: map[int64][]Signal{}, cancelAt: map[int64][]string{}, orders: map[string]Signal{}, done: map[string]bool{}, lastIndex: -1}
	r.book = b
	return r, b
}

// observation は売買を価格2000に対して鏡像にした原行です。
//
// 引数: side(int)、index(int64)、move(float64)、good(bool)は人工条件です。
// 返り値: Observationは一つの受理原行です。
func observation(side int, index int64, move float64, good bool) Observation {
	bid, ask := 1000+move, 1010+move
	if side < 0 {
		bid, ask = 2000-ask, 2000-bid
	}
	if !good {
		ask = bid - 1
	}
	o := Observation{Reference: "NK225", Time: 1100 + float64(index), Received: 1100 + float64(index), Index: index, Last: (bid + ask) / 2, Bid: bid, Ask: ask, QuoteOK: good}
	// 夜間特徴の既知状態は空のまま、公開APIの当原行出典だけを結びます。
	o.Selected.NightAvailable, o.Selected.NightTime, o.Selected.NightIndex = true, o.Time, o.Index
	return o
}

// newSignal は元段階を変えない人工の新規通知です。
//
// 引数: id(string)、side/qty(int)は通知ID・方向・枚数です。
// 返り値: Signalは時刻がObserve時に固定される人工要求です。
func newSignal(id string, side, qty int) Signal {
	return Signal{ID: id, Owner: "core", Action: "new", Side: side, Quantity: qty, Reason: "人工新規"}
}

// closeSignal は同じ所有HoldIDの一部返済通知です。
//
// 引数: id/hold(string)、side/qty(int)は通知と所有です。
// 返り値: Signalは返済側を所有方向の逆へ固定します。
func closeSignal(id, hold string, side, qty int) Signal {
	return Signal{ID: id, Owner: "core", Action: "close", Side: -side, Quantity: qty, Reason: "人工部分返済", Targets: []strategy.LotTarget{{ID: hold, Quantity: qty}}}
}

// step は人工原行を物理行へ結び正常終了を要求します。
//
// 引数: t(*testing.T)、r(*Adapter)、o(Observation)は試験器と当行です。
// 返り値: StepResultは今回の新通知だけです。
func step(t *testing.T, r *Adapter, o Observation) StepResult {
	t.Helper()
	v, err := r.Step(o, o.Index+20)
	if err != nil {
		t.Fatal(err)
	}
	return v
}
