package main

import (
	"encoding/json"
	"flag"
	"fmt"
	core "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	"os"
)

// run はRoot固定後だけ元時計の基準再生を起動します。
//
// 引数: なし。CLIは固定Ref・段階・新規先・任意の元54成功Refです。
// 返り値: errorは未固定、元対照、会計、保存の差です。
func run() error {
	fixed := flag.String("fixed", "", "Rootの市場前固定")
	fixedSHA := flag.String("fixed-sha", "", "Root固定SHA256")
	stage := flag.String("stage", "", "first2/original54/full70")
	out := flag.String("out", "", "未使用出力先")
	prior := flag.String("prior54", "", "元54成功の完了JSON")
	priorSHA := flag.String("prior54-sha", "", "元54完了のSHA256")
	flag.Parse()
	if *fixed == "" || *fixedSHA == "" || *stage == "" || (*out == "" && *stage != "metadata-only") {
		return fmt.Errorf("固定Ref・段階・新規先が必要")
	}
	if *stage == "metadata-only" {
		plan, e := core.PrepareMetadata(core.FileRef{Path: *fixed, SHA256: *fixedSHA})
		if e != nil {
			return e
		}
		return json.NewEncoder(os.Stdout).Encode(map[string]any{"metadata_verified": true, "financial_executed": false, "cases": len(plan.Cases), "historical_event_equality": false})
	}
	var ref *core.FileRef
	if *prior != "" || *priorSHA != "" {
		ref = &core.FileRef{Path: *prior, SHA256: *priorSHA}
	}
	result, e := core.RunFixed(core.FileRef{Path: *fixed, SHA256: *fixedSHA}, *stage, *out, ref)
	if e != nil {
		return e
	}
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"成功": result.Success, "場数": result.Sessions, "会計": result.Books, "元手法場": result.OriginalMethods, "全Signal全文同体": false})
}

// main は市場固定不足を終了1として扱い成功へ補完しません。
//
// 引数: なし。
// 返り値: なし。正常完了0、不整合1です。
func main() {
	if e := run(); e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
}
