# 111：元166の原行時計による連続基準

市場未実行の準備版。元D164_15/P164_06/U165_03を、NK225原行ごとの先行pending約定→Observe→当行通知→取消で運転する。外側5分/15分新規gate、開始20/30分の外側静観、外部timer Forceを基準へ加えない。元内部の準備・US前後15分静観・末尾10分前の返済は維持する。追加利益保護とテクニカルは外consumerに接続する。

## 基準化した点

- 元166と同じ外ConfigはCore/Extra=1/1、Cap=100micro又は10mini、点価10又は100、LargeTick=10。実構築したPortfolio.Configと内側Selected.Shadow.Configを保存し、源側5/5/10への正規化も記録する。
- 元166のrun本文は独立cmd/oracleへ同体派生した。変更はstrategy importの独立repo対応、旧main名、gzipを展開ストリームで読むI/Oだけ。run本体と原板選別のAST同体を人工検査する。原文blobはoracle原文、一次確認は元166一次参照.json。
- 元166 input.goに合わせ、Last<=0は除外してprevious時計も進めない。Last>0の異常BBOはObserveへ配送し、fillだけ正常後原行まで待つ。End等号は採用、任意Cutoff以降は除外。二市場はTOPIX→NK225で時刻安定結合する。
- 同価格時計でもSourceIndexのstrict後原行だけをfillする。EOFにForceや架空価格を加えず、残玉/予約があれば不成功にする。明示Force APIは緊急用として別記録し、基準runnerは呼ばない。
- 源は手数料0。mini源の通知を旧94のS0会計4条件へ配送し、38.5円/片道、追加0/5pt、0/1価格秒を分離する。外費用・退出を源へ戻さない。S0返却wrapperのStreamScopeは新111の実配送へ訂正する。
- D0の全実fill/所有/価格/枚数/費用をmini源へ照合する。全4口座で源の出生・取消・源fill・close noticeの所有分母を照合する。D1は異なる実運転で、D0と実fillの同体を要求しない。

## 外Actorと公開API

moduleはgithub.com/masayoshi4649/SessionTradeExecuter/continuous111。

- ReplayWithConsumer(root, InputCase, SourceConsumer)：共有Rawを一度読み、同じ源から基準4口座と外側Actorへ配送する。
- SourceConsumer.Begin(SourceCase)：元Session・限月・実構築設定を受ける。
- SourceConsumer.Step(NativeStep)：Observation、SourceLine、Mini/Micro NativeBatch、当行で影響されたSourceHold、当時までに公表されたCandlePublicationを受ける。
- SourceConsumer.End(SourceEnd)：元源の完結と外timer0を受ける。外Actorの未完了はerrorを返せる。
- ReplayEvents：手製又は認証済みのBoardEvent/CandlePublicationを明示投入する。
- InputCaseはInputSession、NativeBatchは旧miniprotect.NativeBatch、NativeNotification/NativeFill/SourceHoldは旧mininativeの公開型をaliasする。
- SessionForとVerifyInputで、別oracleも同じ場時計・共有入力指紋を利用する。

Publicationsは1分/5分足のAt=足始＋Interval＋60秒で、当時のNK225 Observation.Time以下だけをまとめて渡す。外Actorが3分/15分やBBを形成する場合もこの公開順を使える。Observationの可変Components、通知slice/Evidence、開始設定を独立コピーする。外側の変更で源を変更しない。全Rawや全観測行の別形式コピーは作らない。

## 原文oracleと当時記録を分ける

元54の当時Event保存は、確認した固定ref直下には見付からない。そこでcmd/oracleは未改変runを固定純戦略67ba0158…と共有入力で再実行する。100microと10miniを独立に運転し、新しい対照JSONへResults/mini_resultsを保存する。

origin.kindはrerun_original166_pinned_code。元166 run/inputのGit blob、固定commit、run本文無変更を付ける。当時保存Event同体、全Signal全文同体はfalse。原文run再実行の全Eventと、当時の公表3gross（D+1,248,500/P+392,000/U+1,181,000円）は別に照合する。公表粗額が一致しても全Signal全文同体とは呼ばない。

基準側CompareGoldenはこの新対照の100micro/10miniの全fill Eventを、判断/約定Index・時刻・方向・価格・量・grossで照合する。同一原行・同価格の分割約定だけを集約する。ReferenceKindとHistoricalSavedEventsEqualを別記し、再実行を当時記録へ読み替えない。原文oracleでも公表粗額が違えば、その差を残して入力境界や実装同値を調べる。

## Rootが固定する条件

Fixed JSONの必須項目はversion=1、trial=111、fixed=true、policy=original166_continuous_baseline、FAR_commit=cf0717daa1eed78759f78a428bce50129e7f705b、strategy_commit=67ba01588a60961ce2fb505ee5654999473dedab。manifest/executable/oracle_executableは絶対path/sha256のFileRef、code_sha256は全依存コードの絶対path→SHA256。

manifestは既使用70場の93形式で、元54は先頭2026-09-21_Day〜10-27_Night、追加16は11/06_Nightまで。純戦略43項目も検査する。必須の基準/直接再用ソースの固定漏れは拒否する。Rootは停止記録のGo閉包を条件へ接続する。

original166_referencesは元54場ID→FileRef。最初の原文oracle実行とmetadata-onlyでは空でもよい。oracle成功後の新対照Refを取得し、売買算法・費用・時計を変更しない比較参照追加として、Rootが元の固定からの派生を記録する。基準first2/original54では全54対照を認証する。full70は同条件original54成功、元81手法場の全Event比較、先頭54Nativeの同bytesを必須にする。

## コマンド

    go test -count=1 ./...
    go vet ./...
    go build -o 検査/111元時計.exe ./cmd/baseline
    go build -o 検査/111原文oracle.exe ./cmd/oracle

市場を開かないmetadata検査。

    検査/111元時計.exe --fixed <Root固定の絶対path> --fixed-sha <SHA256> --stage metadata-only

Root固定後、原文oracleはfirst2→original54。

    検査/111原文oracle.exe --fixed <Root固定> --fixed-sha <SHA256> --stage first2 --out <未使用先>
    検査/111原文oracle.exe --fixed <Root固定> --fixed-sha <SHA256> --stage original54 --out <未使用先>

成功した原文oracle対照を明示して、基準はfirst2→original54→full70。

    検査/111元時計.exe --fixed <比較Refを含む固定> --fixed-sha <SHA256> --stage first2 --out <未使用先>
    検査/111元時計.exe --fixed <同固定> --fixed-sha <SHA256> --stage original54 --out <未使用先>
    検査/111元時計.exe --fixed <同固定> --fixed-sha <SHA256> --stage full70 --prior54 <元54完了> --prior54-sha <SHA256> --out <未使用先>

## 人工と停止

元Config実物、売買鏡像、境界の先行fill、同秒複数物理行、異常BBO、US開始等号、明示Force/EOF、4費用、同原行出生取消、全源配送、consumer非干渉、未来足非干渉、元Raw選別、元Event破壊、両商品oracle形式、metadata/未固定/全54前の全70拒否を検査する。人工は自然発生した入口優位や市場損益を示さない。

検査して停止する.pyはGo test/vet、2実行物、原文AST、関数コメント、Go閉包・旧依存の前後不変を記録する。人工_停止版には買売の手製連続配送だけを置く。旧93/94・旧停止済みは変更しない。派生の参照.json内の初回出力SHAはgofmt前の履歴であり、現在の正本は停止.jsonの所有指紋とする。

新しい保護・BB尺度・利益化起動水準・採用/目標達成をこのmoduleで決めない。未参加/退出後の仮想利益、機会損失、資金不明ROI、xlsx、実注文、未見11/09の本文は扱わない。市場再生はRootの新条件固定後にだけ実行する。
