package main

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

// functionBody はGo関数本体だけを同じ書式で抽出します。
//
// 引数: t(*testing.T)、path/name(string)は試験器・原文又は派生・関数名です。
// 返り値: []byteはimportやmain名の差を含まない本体です。
func functionBody(t *testing.T, path, name string) []byte {
	t.Helper()
	set := token.NewFileSet()
	file, e := parser.ParseFile(set, path, nil, parser.ParseComments)
	if e != nil {
		t.Fatal(e)
	}
	for _, d := range file.Decls {
		if f, ok := d.(*ast.FuncDecl); ok && f.Name.Name == name {
			var b bytes.Buffer
			if e = format.Node(&b, set, f.Body); e != nil {
				t.Fatal(e)
			}
			return b.Bytes()
		}
	}
	t.Fatal("元関数がない")
	return nil
}

// TestOriginalRunBodyIsUnchanged は元runの算法・Core/Extra・原行順が無変更です。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。原文runの再実行と当時保存Eventを混同しません。
func TestOriginalRunBodyIsUnchanged(t *testing.T) {
	a := functionBody(t, "../../oracle原文/main.go.txt", "run")
	b := functionBody(t, "original_main.go", "run")
	if !bytes.Equal(a, b) {
		t.Fatal("元run本体が変更されている")
	}
	old, e := os.ReadFile("../../oracle原文/input.go.txt")
	if e != nil {
		t.Fatal(e)
	}
	derived, e := os.ReadFile("original_input.go")
	if e != nil {
		t.Fatal(e)
	}
	// ----------------------------------------
	// 元入力のI/O名とimportだけを元に戻してAST本体を照合します。
	text := strings.ReplaceAll(string(derived), "openInput(scene.Books[ref])", "os.Open(scene.Books[ref])")
	temp := filepath.Join(t.TempDir(), "入力.go")
	if e = os.WriteFile(temp, []byte(text), 0644); e != nil {
		t.Fatal(e)
	}
	if !bytes.Equal(functionBody(t, "../../oracle原文/input.go.txt", "loadBoards"), functionBody(t, temp, "loadBoards")) {
		t.Fatal("原板選別の算法を変更")
	}
	if len(old) == 0 {
		t.Fatal("原文なし")
	}
}

// TestOriginalOracleReadsGzipWithoutCopy は手製gzipを原文runへ直接渡します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。実原板を開かず2商品/日夜の元run分岐を通します。
func TestOriginalOracleReadsGzipWithoutCopy(t *testing.T) {
	for _, kind := range []string{"Day", "Night"} {
		dir := t.TempDir()
		start := float64(100000)
		end := start + 25200
		scene := Scene{Session: "人工_" + kind, Kind: kind, Start: start, End: end, ForceClose: end - 600, USOpen: start + 3000, Books: map[string]string{}, Candles: map[string]map[string]string{}}
		for _, ref := range []string{"TOPIX", "NK225"} {
			path := filepath.Join(dir, ref+".gz")
			f, e := os.Create(path)
			if e != nil {
				t.Fatal(e)
			}
			z := gzip.NewWriter(f)
			for _, at := range []float64{start + 100, start + 4000, end - 1} {
				board := map[string]any{"CurrentPriceTime": time.Unix(int64(at), 0).UTC().Format(time.RFC3339Nano), "CurrentPrice": 1000, "Buy1": map[string]int{"Price": 990, "Qty": 10}, "Sell1": map[string]int{"Price": 1010, "Qty": 10}}
				raw, _ := json.Marshal(board)
				if _, e = z.Write(append(raw, '\n')); e != nil {
					t.Fatal(e)
				}
			}
			z.Close()
			f.Close()
			scene.Books[ref] = path
			scene.Candles[ref] = map[string]string{}
			for _, iv := range []int{60, 300} {
				p := filepath.Join(dir, ref+time.Duration(iv).String()+".csv")
				text := "time,open,high,low,close,closed\n" + time.Unix(int64(start), 0).UTC().Format(time.RFC3339Nano) + ",1000,1010,990,1000,true\n"
				if e = os.WriteFile(p, []byte(text), 0644); e != nil {
					t.Fatal(e)
				}
				scene.Candles[ref][time.Duration(iv).String()] = p
				if iv == 60 {
					scene.Candles[ref]["60"] = p
				} else {
					scene.Candles[ref]["300"] = p
				}
			}
		}
		before, e := os.ReadDir(dir)
		if e != nil {
			t.Fatal(e)
		}
		for _, cap := range []int{100, 10} {
			result, e := run(scene, cap)
			if e != nil {
				t.Fatal(e)
			}
			if e = checkResults(result, cap); e != nil {
				t.Fatal(e)
			}
			want := 1
			if kind == "Night" {
				want = 2
			}
			if len(result) != want {
				t.Fatal("元手法数差")
			}
		}
		after, _ := os.ReadDir(dir)
		if len(before) != len(after) {
			t.Fatal("展開Rawを複製")
		}
	}
}
