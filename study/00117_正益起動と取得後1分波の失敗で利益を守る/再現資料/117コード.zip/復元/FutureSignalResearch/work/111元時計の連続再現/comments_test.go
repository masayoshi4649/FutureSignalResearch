package continuous111

import (
	"go/ast"
	"go/parser"
	"go/token"
	"io/fs"
	"path/filepath"
	"strings"
	"testing"
)

// TestFunctionCommentsHaveContract は全新Go関数の複数行契約を確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。機能説明・引数型・返り値型を持たない関数を拒否します。
func TestFunctionCommentsHaveContract(t *testing.T) {
	count := 0
	e := filepath.WalkDir(".", func(path string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		if d.IsDir() {
			if path == "検査" || path == "人工_停止版" {
				return filepath.SkipDir
			}
			return nil
		}
		if !strings.HasSuffix(path, ".go") {
			return nil
		}
		file, e := parser.ParseFile(token.NewFileSet(), path, nil, parser.ParseComments)
		if e != nil {
			return e
		}
		for _, decl := range file.Decls {
			if f, ok := decl.(*ast.FuncDecl); ok {
				count++
				if f.Doc == nil || len(f.Doc.List) < 3 || !strings.Contains(f.Doc.Text(), "引数") || !strings.Contains(f.Doc.Text(), "返り値") {
					t.Errorf("関数コメント不足:%s/%s", path, f.Name.Name)
				}
			}
		}
		return nil
	})
	if e != nil {
		t.Fatal(e)
	}
	if count < 60 {
		t.Fatal("全関数を走査していない")
	}
	t.Logf("複数行の契約コメント%d関数", count)
}
