package continuous111

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"reflect"
)

// GoldenEvent は元166が保存した判断/約定原行と実配分です。
type GoldenEvent struct {
	DecisionIndex int64
	FillIndex     int64
	Time          float64
	Price         float64
	Gross         float64
	Action        string
	Side          int
	Quantity      int
}

// GoldenResult は元166の同値確認済み手法場です。
type GoldenResult struct {
	Session     string
	Method      string
	Cap         int
	Events      []GoldenEvent
	Gross       float64
	Pending     int
	Held        int
	Differences []string
	Error       string
}

// GoldenProof は全Signalではなく保存Event全件の照合範囲を示します。
type GoldenProof struct {
	ReferenceKind              string  `json:"reference_kind"`
	MiniEventsEqual            bool    `json:"mini_saved_fill_events_equal"`
	HistoricalSavedEventsEqual bool    `json:"historical_saved_events_equal"`
	Reference                  FileRef `json:"reference"`
	Session                    string  `json:"session"`
	Methods                    int     `json:"methods"`
	EventsEqual                bool    `json:"all_saved_fill_events_equal"`
	AllSignalEqual             bool    `json:"all_signal_full_json_equal"`
	Scope                      string  `json:"scope"`
}

type eventKey struct {
	Decision, Fill int64
	Time, Price    float64
	Action         string
	Side           int
}
type eventSum struct {
	Quantity int
	Gross    float64
}

// eventTotals は同じ元判断・約定原行の分割約定だけを集約します。
//
// 引数: events([]GoldenEvent)は元又は今回の実約定イベントです。
// 返り値: map[eventKey]eventSum/errorは全イベント又は不正数値です。
func eventTotals(events []GoldenEvent) (map[eventKey]eventSum, error) {
	out := map[eventKey]eventSum{}
	for _, e := range events {
		if !finite(e.Time, e.Price, e.Gross) || e.Price <= 0 || e.Time <= 0 || e.FillIndex <= e.DecisionIndex || e.Quantity <= 0 || (e.Side != 1 && e.Side != -1) || (e.Action != "new" && e.Action != "close") {
			return nil, fmt.Errorf("元Eventの時計/方向/量が不正")
		}
		k := eventKey{e.DecisionIndex, e.FillIndex, e.Time, e.Price, e.Action, e.Side}
		s := out[k]
		s.Quantity += e.Quantity
		s.Gross += e.Gross
		out[k] = s
	}
	return out, nil
}

// ledgerEvents は今回の全fillを先行Signalと結合し元166の保存粒度へ写します。
//
// 引数: ledger(Ledger)は費用0の元商品会計です。
// 返り値: []GoldenEvent/errorは全fill又は未知Signalです。
func ledgerEvents(ledger Ledger) ([]GoldenEvent, error) {
	signals := map[string]SignalRecord{}
	for _, s := range ledger.Signals {
		signals[s.Signal.ID] = s
	}
	out := []GoldenEvent{}
	for _, f := range ledger.Fills {
		s, ok := signals[f.Fill.SignalID]
		if !ok {
			return nil, fmt.Errorf("fillの元Signalがない")
		}
		out = append(out, GoldenEvent{s.Signal.SourceIndex, f.Quote.Index, f.Quote.Time, f.Fill.Price, f.GrossYen, f.Action, f.Side, f.Fill.Quantity})
	}
	return out, nil
}

// CompareGoldenValues は元100microの全保存Eventと終了残を照合します。
//
// 引数: result(ReplayResult)、expected([]GoldenResult)、ref(FileRef)は今回・元保存と認証参照です。
// 返り値: GoldenProof/errorは全イベント同体の範囲又は差です。全Signalの同体へ拡張しません。
func CompareGoldenValues(result ReplayResult, expected []GoldenResult, ref FileRef) (GoldenProof, error) {
	proof := GoldenProof{Reference: ref, Session: result.Session.ID, Scope: "元166の全保存fill Eventを判断Index/約定Index/時刻/方向/価格/量/grossで照合。同原行・同価格の分割約定だけ集約。全Signal全文は未提供のため未照合"}
	methods := methodsFor(result.Session)
	if len(expected) != len(methods) {
		return proof, fmt.Errorf("元手法場数差")
	}
	seen := map[string]bool{}
	for _, g := range expected {
		short := g.Method
		if len(short) > 6 && short[:6] == "NK225_" {
			short = short[6:]
		}
		if seen[short] || g.Session != result.Session.ID || g.Cap != 100 || g.Pending != 0 || g.Held != 0 || g.Error != "" || len(g.Differences) > 0 {
			return proof, fmt.Errorf("元100micro成功保存ではない")
		}
		seen[short] = true
		ledger, ok := result.Sources["NK225micro_"+short]
		if !ok {
			return proof, fmt.Errorf("元手法の欠落")
		}
		ours, err := ledgerEvents(ledger)
		if err != nil {
			return proof, err
		}
		a, err := eventTotals(g.Events)
		if err != nil {
			return proof, err
		}
		b, err := eventTotals(ours)
		if err != nil {
			return proof, err
		}
		if !reflect.DeepEqual(a, b) || math.Abs(g.Gross-ledger.Totals.GrossYen) > 0.000001 {
			return proof, fmt.Errorf("元166の全Event又はgross差:%s", short)
		}
	}
	for _, m := range methods {
		if !seen[m] {
			return proof, fmt.Errorf("元手法集合の差")
		}
	}
	proof.Methods = len(methods)
	proof.EventsEqual = true
	return proof, nil
}

// CompareGolden は期待指紋の元166小JSONだけを読む照合です。
//
// 引数: result(ReplayResult)、ref(FileRef)は今回と元の期待指紋です。
// 返り値: GoldenProof/errorは保存Event同体と範囲又は入出力差です。
func CompareGolden(result ReplayResult, ref FileRef) (GoldenProof, error) {
	proof := GoldenProof{Reference: ref}
	if err := VerifyRef(ref); err != nil {
		return proof, err
	}
	raw, err := os.ReadFile(ref.Path)
	if err != nil {
		return proof, err
	}
	var value struct {
		Results     []GoldenResult
		MiniResults []GoldenResult `json:"mini_results"`
		Origin      struct {
			Kind           string `json:"kind"`
			FARCommit      string `json:"FAR_commit"`
			StrategyCommit string `json:"strategy_commit"`
			MainBlob       string `json:"main_git_blob_sha"`
			InputBlob      string `json:"input_git_blob_sha"`
			RunUnchanged   bool   `json:"run_body_unchanged"`
			Historical     bool   `json:"historical_saved_events"`
		} `json:"origin"`
		Error string
	}
	if err = json.Unmarshal(raw, &value); err != nil {
		return proof, err
	}
	if value.Error != "" && value.Error != "<nil>" {
		return proof, fmt.Errorf("元166保存が失敗")
	}
	proof, err = CompareGoldenValues(result, value.Results, ref)
	if err != nil {
		return proof, err
	}
	proof.ReferenceKind = "unclassified_saved_reference"
	if value.Origin.Kind != "" {
		if value.Origin.Kind != "rerun_original166_pinned_code" || value.Origin.FARCommit != "cf0717daa1eed78759f78a428bce50129e7f705b" || value.Origin.StrategyCommit != "67ba01588a60961ce2fb505ee5654999473dedab" || value.Origin.MainBlob != "6d8f1a63c94006e6cf7e80c9e988f06d995e2acb" || value.Origin.InputBlob != "784579f65444f1377d41354aa4458783a3d2bcf1" || !value.Origin.RunUnchanged || value.Origin.Historical {
			return proof, fmt.Errorf("原文再実行の出典が不正")
		}
		if err = compareMiniOracle(result, value.MiniResults); err != nil {
			return proof, err
		}
		proof.MiniEventsEqual = true
		proof.ReferenceKind = value.Origin.Kind
		proof.Scope = "固定原文runを固定純戦略/既使用入力で再実行した100micro/10miniの全fill Eventと同体。当時保存Event同体・全Signal全文同体は未証明"
	}
	return proof, nil
}

// compareMiniOracle は原文run再実行のmini整数配分も全Eventで照合します。
//
// 引数: result(ReplayResult)、expected([]GoldenResult)は今回と原文oracleのmini値です。
// 返り値: errorはminiの方向・原行・価格・量・gross差です。
func compareMiniOracle(result ReplayResult, expected []GoldenResult) error {
	methods := methodsFor(result.Session)
	if len(expected) != len(methods) {
		return fmt.Errorf("mini oracleの手法場数差")
	}
	seen := map[string]bool{}
	for _, g := range expected {
		short := g.Method
		if len(short) > 6 && short[:6] == "NK225_" {
			short = short[6:]
		}
		l, ok := result.Sources["NK225mini_"+short]
		if !ok || seen[short] || g.Cap != 10 || g.Session != result.Session.ID || g.Error != "" || g.Held != 0 || g.Pending != 0 {
			return fmt.Errorf("mini oracleの規格/成功差")
		}
		seen[short] = true
		events, e := ledgerEvents(l)
		if e != nil {
			return e
		}
		a, e := eventTotals(g.Events)
		if e != nil {
			return e
		}
		b, e := eventTotals(events)
		if e != nil {
			return e
		}
		if !reflect.DeepEqual(a, b) || g.Gross != l.Totals.GrossYen {
			return fmt.Errorf("mini oracleの全Event差:%s", short)
		}
	}
	return nil
}

// ValidateGoldenRef は元54対照の成功・場・商品を市場本文より先に確認します。
//
// 引数: ref(FileRef)、session(Session)は元166保存と期待場です。
// 返り値: errorは未成功・誤場・不正イベント等の差です。今回の金融を計算しません。
func ValidateGoldenRef(ref FileRef, session Session) error {
	if err := VerifyRef(ref); err != nil {
		return err
	}
	raw, err := os.ReadFile(ref.Path)
	if err != nil {
		return err
	}
	var value struct {
		Results []GoldenResult
		Error   string
	}
	if err = json.Unmarshal(raw, &value); err != nil {
		return err
	}
	if value.Error != "" && value.Error != "<nil>" {
		return fmt.Errorf("元166対照が不成功")
	}
	methods := methodsFor(session)
	if len(value.Results) != len(methods) {
		return fmt.Errorf("元166手法場の欠落")
	}
	seen := map[string]bool{}
	for _, g := range value.Results {
		short := g.Method
		if len(short) > 6 && short[:6] == "NK225_" {
			short = short[6:]
		}
		if seen[short] || g.Session != session.ID || g.Cap != 100 || g.Pending != 0 || g.Held != 0 || g.Error != "" || len(g.Differences) > 0 || !finite(g.Gross) {
			return fmt.Errorf("元166の成功/場/規格が不一致")
		}
		seen[short] = true
		if _, err = eventTotals(g.Events); err != nil {
			return err
		}
	}
	for _, m := range methods {
		if !seen[m] {
			return fmt.Errorf("元166手法集合の差")
		}
	}
	return nil
}
