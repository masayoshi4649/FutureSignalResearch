package continuous111

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"sort"
	"strings"
)

// FileRef は成功後に書き換えない小metadata又は明示入力の参照です。
type FileRef struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
}

// Fixed はRootが市場実行前に固定する元時計の基準条件です。
type Fixed struct {
	OracleExecutable FileRef            `json:"oracle_executable"`
	Version          int                `json:"version"`
	Trial            int                `json:"trial"`
	Fixed            bool               `json:"fixed"`
	Policy           string             `json:"policy"`
	FARCommit        string             `json:"FAR_commit"`
	StrategyCommit   string             `json:"strategy_commit"`
	Manifest         FileRef            `json:"manifest"`
	Executable       FileRef            `json:"executable"`
	CodeSHA256       map[string]string  `json:"code_sha256"`
	Golden           map[string]FileRef `json:"original166_references"`
}

// SceneResult は元全Event同体と今回の金融保存を場単位で結びます。
type SceneResult struct {
	Session  string       `json:"session"`
	Native   FileRef      `json:"native"`
	Golden   *GoldenProof `json:"original166_reference,omitempty"`
	Books    int          `json:"books"`
	Sources  int          `json:"sources"`
	MirrorD0 bool         `json:"mini_source_D0_fill_equal"`
}

// Completion は全54確認を全70へ接続する成功記録です。
type Completion struct {
	Version                    int               `json:"version"`
	Trial                      int               `json:"trial"`
	Stage                      string            `json:"stage"`
	Success                    bool              `json:"success"`
	ConditionSHA256            string            `json:"condition_sha256"`
	Sessions                   int               `json:"sessions"`
	Books                      int               `json:"books"`
	OriginalMethods            int               `json:"original_methods"`
	AllSavedFillEventsEqual    bool              `json:"all_original166_reference_events_equal"`
	HistoricalSavedEventsEqual bool              `json:"historical_saved_events_equal"`
	AllSignalFullJSONEqual     bool              `json:"all_original_signal_full_json_equal"`
	Results                    []SceneResult     `json:"results"`
	Before                     map[string]string `json:"before"`
	After                      map[string]string `json:"after"`
	Unchanged                  bool              `json:"unchanged"`
	Prior54                    *FileRef          `json:"prior54,omitempty"`
}

// RunPlan は市場本文を開く前に認証した元時計の入力計画です。
type RunPlan struct {
	Fixed      Fixed
	Manifest   InputManifest
	Cases      []InputCase
	Stage      string
	Condition  FileRef
	Prior54    *Completion
	Prior54Ref *FileRef
	Before     map[string]string
}

// Digest は明示参照の全バイト指紋を計算します。
//
// 引数: path(string)は明示したファイルです。
// 返り値: string/errorはSHA256又は入出力異常です。
func Digest(path string) (string, error) {
	f, e := os.Open(path)
	if e != nil {
		return "", e
	}
	defer f.Close()
	h := sha256.New()
	if _, e = io.Copy(h, f); e != nil {
		return "", e
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

// VerifyRef は絶対位置・期待指紋を満たす参照だけを認証します。
//
// 引数: ref(FileRef)は対象と期待SHAです。
// 返り値: errorは型又は実物差です。
func VerifyRef(ref FileRef) error {
	if !filepath.IsAbs(ref.Path) || len(ref.SHA256) != 64 {
		return fmt.Errorf("絶対FileRefが必要")
	}
	if _, e := hex.DecodeString(ref.SHA256); e != nil {
		return e
	}
	got, e := Digest(ref.Path)
	if e != nil {
		return e
	}
	if got != ref.SHA256 {
		return fmt.Errorf("FileRef実物差:%s", ref.Path)
	}
	return nil
}

// readJSONRef は認証後の小JSONを明示型へ復元します。
//
// 引数: ref(FileRef)、value(any)は期待参照と復元先です。
// 返り値: errorは指紋又はJSON型の差です。
func readJSONRef(ref FileRef, value any) error {
	if e := VerifyRef(ref); e != nil {
		return e
	}
	raw, e := os.ReadFile(ref.Path)
	if e != nil {
		return e
	}
	return json.Unmarshal(raw, value)
}

// sourceCodePaths はこの基準と直接再用する源/会計の必須ソースを列挙します。
//
// 引数: なし。
// 返り値: []stringはビルド元の絶対位置です。標準ライブラリは停止台帳で別記します。
func sourceCodePaths() []string {
	_, file, _, ok := runtime.Caller(0)
	if !ok {
		panic("ビルド元不明")
	}
	base := filepath.Dir(file)
	paths := []string{}
	for _, name := range []string{"adapter.go", "api.go", "delivery.go", "fixed.go", "golden.go", "input.go", "mirror.go", "replay.go", "types.go", "go.mod", "go.sum", "cmd/baseline/main.go", "cmd/oracle/main.go", "cmd/oracle/original_main.go", "cmd/oracle/original_input.go"} {
		paths = append(paths, filepath.Join(base, filepath.FromSlash(name)))
	}
	root := filepath.Clean(filepath.Join(base, "../.."))
	for folder, names := range map[string][]string{
		"FAR元三手法のmini連続再現": {"adapter.go", "input.go", "replay.go", "types.go", "go.mod", "go.sum"},
		"FAR連続出生と個別利益追尾":   {"actual.go", "actual_types.go", "input.go", "mirror_check.go", "replay.go", "go.mod", "go.sum"},
	} {
		for _, name := range names {
			paths = append(paths, filepath.Join(root, "scripts", folder, name))
		}
	}
	sort.Strings(paths)
	return paths
}

// PrepareRun は固定条件・54元対照・実行物を本文読取前に認証します。
//
// 引数: condition(FileRef)、stage(string)、prior54(*FileRef|nil)はRoot固定、段階、全54成功です。
// 返り値: RunPlan/errorはRaw未読の計画又は不正条件です。
func PrepareRun(condition FileRef, stage string, prior54 *FileRef) (RunPlan, error) {
	return prepareRun(condition, stage, prior54, true, false)
}

// PrepareOracleRun は当時goldenがなくても原文run再実行を固定条件で準備します。
//
// 引数: condition(FileRef)、stage(string)はRoot固定とfirst2/original54です。
// 返り値: RunPlan/errorは原文oracleのRaw未読計画又は条件差です。
func PrepareOracleRun(condition FileRef, stage string) (RunPlan, error) {
	if stage != "first2" && stage != "original54" {
		return RunPlan{}, fmt.Errorf("oracle段階はfirst2/original54")
	}
	return prepareRun(condition, stage, nil, false, true)
}

// PrepareMetadata は全市場・元Eventを読まず固定依存と入力目録だけを認証します。
//
// 引数: condition(FileRef)はRoot固定です。
// 返り値: RunPlan/errorは本文前検査の成否です。金融完了ではありません。
func PrepareMetadata(condition FileRef) (RunPlan, error) {
	return prepareRun(condition, "metadata-only", nil, false, false)
}

// prepareRun は基準・原文oracle・metadata-onlyの本文前検査を共用します。
//
// 引数: condition(FileRef)、stage(string)、prior54(*FileRef|nil)、comparisons/oracle(bool)は固定と比較範囲です。
// 返り値: RunPlan/errorはRaw未読の計画です。
func prepareRun(condition FileRef, stage string, prior54 *FileRef, comparisons, oracle bool) (RunPlan, error) {
	plan := RunPlan{Condition: condition, Stage: stage, Before: map[string]string{}}
	if e := readJSONRef(condition, &plan.Fixed); e != nil {
		return plan, e
	}
	f := plan.Fixed
	if f.Version != 1 || f.Trial != 111 || !f.Fixed || f.Policy != "original166_continuous_baseline" || f.FARCommit != "cf0717daa1eed78759f78a428bce50129e7f705b" || f.StrategyCommit != "67ba01588a60961ce2fb505ee5654999473dedab" {
		return plan, fmt.Errorf("元時計のRoot固定が必要")
	}
	plan.Before[condition.Path] = condition.SHA256
	targetExe := f.Executable
	if oracle {
		targetExe = f.OracleExecutable
	}
	if e := VerifyRef(targetExe); e != nil {
		return plan, e
	}
	exe, e := os.Executable()
	if e != nil {
		return plan, e
	}
	actual, e := Digest(exe)
	if e != nil || actual != targetExe.SHA256 {
		return plan, fmt.Errorf("実行中のexe指紋差")
	}
	plan.Before[targetExe.Path] = targetExe.SHA256
	if len(f.CodeSHA256) < 10 {
		return plan, fmt.Errorf("全依存コードの固定が不足")
	}
	for _, path := range sourceCodePaths() {
		if _, ok := f.CodeSHA256[path]; !ok {
			return plan, fmt.Errorf("基準/直接再用codeの固定漏れ:%s", path)
		}
	}
	for path, s := range f.CodeSHA256 {
		if e := VerifyRef(FileRef{path, s}); e != nil {
			return plan, e
		}
		plan.Before[path] = s
	}
	if e := readJSONRef(f.Manifest, &plan.Manifest); e != nil {
		return plan, e
	}
	plan.Before[f.Manifest.Path] = f.Manifest.SHA256
	m := plan.Manifest
	if len(m.StrategySHA256) != 43 || len(m.Sessions) != 70 {
		return plan, fmt.Errorf("固定43戦略と既使用70場が必要")
	}
	if e := ValidateManifest(m); e != nil {
		return plan, e
	}
	for name, s := range m.StrategySHA256 {
		plan.Before[filepath.Join(m.StrategyRoot, filepath.FromSlash(name))] = s
	}
	for i, c := range m.Sessions {
		if c.ID < "2026-09-21_Day" || c.ID > "2026-11-06_Night" {
			return plan, fmt.Errorf("既使用70範囲外")
		}
		for _, file := range c.Files {
			clean := filepath.Clean(filepath.FromSlash(file.Path))
			if filepath.IsAbs(clean) || clean == ".." || strings.HasPrefix(clean, ".."+string(filepath.Separator)) {
				return plan, fmt.Errorf("入力根外の参照を拒否")
			}
		}
		if comparisons && i < 54 {
			if _, ok := f.Golden[c.ID]; !ok {
				return plan, fmt.Errorf("元54のEvent対照が不足:%s", c.ID)
			}
		}
	}
	if comparisons && len(f.Golden) != 54 {
		return plan, fmt.Errorf("元54対照の集合差")
	}
	if m.Sessions[0].ID != "2026-09-21_Day" || m.Sessions[53].ID != "2026-10-27_Night" || m.Sessions[69].ID != "2026-11-06_Night" {
		return plan, fmt.Errorf("元54と追加16の境界差")
	}
	count := 0
	switch stage {
	case "metadata-only":
		count = 70
	case "first2":
		count = 2
	case "original54":
		count = 54
	case "full70":
		count = 70
	default:
		return plan, fmt.Errorf("段階はfirst2/original54/full70")
	}
	if comparisons {
		for _, c := range m.Sessions[:54] {
			ref := f.Golden[c.ID]
			session, _ := sessionClock(c.ID)
			if e := ValidateGoldenRef(ref, session); e != nil {
				return plan, e
			}
			plan.Before[ref.Path] = ref.SHA256
		}
	}
	if stage == "full70" {
		if prior54 == nil {
			return plan, fmt.Errorf("先に元54の全Event対照成功が必要")
		}
		var old Completion
		if e := readJSONRef(*prior54, &old); e != nil {
			return plan, e
		}
		if !old.Success || old.Stage != "original54" || old.ConditionSHA256 != condition.SHA256 || old.Sessions != 54 || old.OriginalMethods != 81 || !old.AllSavedFillEventsEqual || old.AllSignalFullJSONEqual || !old.Unchanged || len(old.Results) != 54 {
			return plan, fmt.Errorf("同じ固定条件の元54成功ではない")
		}
		for i, r := range old.Results {
			if r.Session != m.Sessions[i].ID || r.Golden == nil || !r.Golden.EventsEqual {
				return plan, fmt.Errorf("元54の場/保存Event確認不足")
			}
			if e := VerifyRef(r.Native); e != nil {
				return plan, e
			}
		}
		plan.Prior54 = &old
		plan.Prior54Ref = prior54
		plan.Before[prior54.Path] = prior54.SHA256
	} else if prior54 != nil {
		return plan, fmt.Errorf("prior54は全70だけ")
	}
	plan.Cases = append([]InputCase(nil), m.Sessions[:count]...)
	return plan, nil
}

// writeNewJSON は明示した新規ファイルだけへUTF-8を保存します。
//
// 引数: path(string)、value(any)、compressed(bool)は保存先・値・gzip指定です。
// 返り値: FileRef/errorは同bytes出力又は既存先/JSON差です。
func writeNewJSON(path string, value any, compressed bool) (FileRef, error) {
	data, e := json.MarshalIndent(value, "", "  ")
	if e != nil {
		return FileRef{}, e
	}
	data = append(data, '\n')
	f, e := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if e != nil {
		return FileRef{}, e
	}
	if compressed {
		z := gzip.NewWriter(f)
		_, e = z.Write(data)
		if c := z.Close(); e == nil {
			e = c
		}
	} else {
		_, e = f.Write(data)
	}
	if c := f.Close(); e == nil {
		e = c
	}
	if e != nil {
		return FileRef{}, e
	}
	s, e := Digest(path)
	return FileRef{path, s}, e
}

// RunFixed は認証済み段階だけを実行し元54確認後に全70へ広げます。
//
// 引数: condition(FileRef)、stage/out(string)、prior54(*FileRef|nil)は固定・段階・新規先・元54成功です。
// 返り値: Completion/errorは全会計と元Event比較の完了又は不整合です。
func RunFixed(condition FileRef, stage, out string, prior54 *FileRef) (Completion, error) {
	complete := Completion{Version: 1, Trial: 111, Stage: stage, ConditionSHA256: condition.SHA256, Results: []SceneResult{}, Prior54: prior54}
	plan, e := PrepareRun(condition, stage, prior54)
	if e != nil {
		return complete, e
	}
	absolute, e := filepath.Abs(out)
	if e != nil {
		return complete, e
	}
	if _, e = os.Stat(absolute); !os.IsNotExist(e) {
		return complete, fmt.Errorf("保存先は未使用folderが必要")
	}
	if e = os.MkdirAll(absolute, 0755); e != nil {
		return complete, e
	}
	complete.Before = plan.Before
	for i, input := range plan.Cases {
		result, err := Replay(plan.Manifest.Root, input)
		if err != nil {
			_, _ = writeNewJSON(filepath.Join(absolute, "不完了.json"), map[string]any{"session": input.ID, "error": err.Error(), "result": result}, false)
			return complete, err
		}
		var proof *GoldenProof
		if i < 54 {
			checked, err := CompareGolden(result, plan.Fixed.Golden[input.ID])
			if err != nil {
				return complete, err
			}
			proof = &checked
			complete.OriginalMethods += checked.Methods
		}
		ref, err := writeNewJSON(filepath.Join(absolute, input.ID+".Native.json.gz"), result, true)
		if err != nil {
			return complete, err
		}
		if plan.Prior54 != nil && i < 54 && ref.SHA256 != plan.Prior54.Results[i].Native.SHA256 {
			return complete, fmt.Errorf("元54から全70へのNative同bytes差")
		}
		complete.Results = append(complete.Results, SceneResult{input.ID, ref, proof, 4, len(result.Sources), result.MirrorD0})
		complete.Books += 4
		fmt.Printf("%d/%d %s 元保存Event照合=%t\n", i+1, len(plan.Cases), input.ID, proof != nil)
	}
	complete.After = map[string]string{}
	keys := []string{}
	for path := range complete.Before {
		keys = append(keys, path)
	}
	sort.Strings(keys)
	for _, path := range keys {
		s, e := Digest(path)
		if e != nil || s != complete.Before[path] {
			return complete, fmt.Errorf("実行前後の固定入力/code差:%s", path)
		}
		complete.After[path] = s
	}
	complete.Unchanged = true
	complete.Sessions = len(plan.Cases)
	complete.AllSavedFillEventsEqual = true
	complete.Success = true
	_, e = writeNewJSON(filepath.Join(absolute, "完了.json"), complete, false)
	return complete, e
}
