package continuous111

import (
	"bytes"
	"encoding/json"
	"fmt"
	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	protect "github.com/masayoshi4649/SessionTradeExecuter/miniprotect"
	"reflect"
	"sort"
	"strings"
)

// ReplayResult は元micro/mini源と費用別Actual4を別に保存します。
type ReplayResult struct {
	Version                    int                           `json:"version"`
	Trial                      int                           `json:"trial"`
	Session                    Session                       `json:"session"`
	Contract                   string                        `json:"contract"`
	Quality                    map[string]RawQuality         `json:"quality"`
	FeatureConfig              json.RawMessage               `json:"feature_config"`
	SourceRows                 map[string]int                `json:"source_rows"`
	Sources                    map[string]Ledger             `json:"sources"`
	Normalizations             map[string]NormalizationAudit `json:"normalizations"`
	Books                      map[string]ActualResult       `json:"books"`
	Complete                   bool                          `json:"complete"`
	MirrorD0                   bool                          `json:"mini_source_D0_fill_equal"`
	ExplicitTimerCalls         int                           `json:"explicit_timer_calls"`
	SourceAllSignalGoldenEqual bool                          `json:"source_all_signal_golden_equal"`
	Scope                      string                        `json:"scope"`
}

// methodsFor は元166が作る手法を時間帯だけで選びます。
//
// 引数: session(Session)は場です。
// 返り値: []stringはデイD又はナイトP/Uの元順序です。
func methodsFor(session Session) []string {
	if session.Kind == "Day" {
		return []string{"D164_15"}
	}
	return []string{"P164_06", "U165_03"}
}

// activeMethod は元Uの開始下端だけを判定します。
//
// 引数: method(string)、at(float64)、session(Session)は手法と当時の場時計です。
// 返り値: boolは当行Observeを呼ぶ場合だけ真です。
func activeMethod(method string, at float64, session Session) bool {
	return method != "U165_03" || at >= session.USOpen+900
}

// replayEvents は手製又は読取済み原行を元順序で源とActualへ配送します。
//
// 引数: session(Session)、contract(string)、boards([]replayBoard)、candles([]candleEvent)、quality(map)は当場の明示入力です。
// 返り値: ReplayResult/errorは全通知・会計と不整合です。外timerやEOF架空気配を追加しません。
func replayEvents(session Session, contract string, boards []replayBoard, candles []candleEvent, quality map[string]RawQuality) (ReplayResult, error) {
	return replayEventsWithConsumer(session, contract, boards, candles, quality, nil)
}

// replayEventsWithConsumer は元時計と外Actorの配送を同じ原行で進めます。
//
// 引数: session(Session)、contract(string)、boards([]replayBoard)、candles([]candleEvent)、quality(map)、consumer(SourceConsumer|nil)は場と接続です。
// 返り値: ReplayResult/errorは源を変更しない接続結果です。
func replayEventsWithConsumer(session Session, contract string, boards []replayBoard, candles []candleEvent, quality map[string]RawQuality, consumer SourceConsumer) (ReplayResult, error) {
	out := ReplayResult{Version: 1, Trial: 111, Session: session, Contract: contract, Quality: quality, SourceRows: map[string]int{}, Sources: map[string]Ledger{}, Normalizations: map[string]NormalizationAudit{}, Books: map[string]ActualResult{}, Scope: "元166の原行pending fill→Observe→当行通知/取消。源費用0とActual38.5円/片道を分離。全Signalの元全文照合は未実施"}
	methods := methodsFor(session)
	params, err := strategy.ParametersForMethod("NK225", session.Kind, methods[0])
	if err != nil {
		return out, err
	}
	for _, m := range methods[1:] {
		p, e := strategy.ParametersForMethod("NK225", session.Kind, m)
		if e != nil {
			return out, e
		}
		if !reflect.DeepEqual(p.Features, params.Features) {
			return out, fmt.Errorf("元三手法の特徴設定差")
		}
	}
	if !reflect.DeepEqual(params.Features, strategy.DefaultParameters("NK225", session.Kind).Features) {
		return out, fmt.Errorf("元166のDefault特徴条件と差がある")
	}
	out.FeatureConfig, err = json.Marshal(params.Features)
	if err != nil {
		return out, err
	}
	features, err := strategy.NewFeatures(session, map[string]float64{"NK225": 10, "TOPIX": .5}, params.Features)
	if err != nil {
		return out, err
	}
	features.EnableResearch()
	// ----------------------------------------
	// 元166同様、未来公開予定を登録しても当時の公開時計まではFeaturesに参照させません。
	for _, c := range candles {
		if _, err = features.AddCandles(c.Reference, c.Interval, []strategy.Candle{c.Candle}, c.At); err != nil {
			return out, err
		}
	}
	adapters := map[string]*Adapter{}
	order := []string{}
	for _, product := range []string{"NK225micro", "NK225mini"} {
		cfg, _ := OriginalConfig(product)
		for _, m := range methods {
			key := product + "_" + m
			adapters[key], err = NewAdapter(m, session, cfg)
			if err != nil {
				return out, err
			}
			order = append(order, key)
		}
	}
	actors := map[string]*protect.ActualBook{}
	actorKeys := []string{}
	for _, cfg := range ActorConfigs() {
		actor, e := protect.NewActualBook(session, cfg)
		if e != nil {
			return out, e
		}
		key := fmt.Sprintf("S0_C%.0f_D%d", cfg.SlipPts, cfg.DelaySeconds)
		actors[key] = actor
		actorKeys = append(actorKeys, key)
	}
	if consumer != nil {
		setup := SourceCase{Session: session, Contract: contract, Normalizations: map[string]NormalizationAudit{}}
		for key, a := range adapters {
			setup.Normalizations[key] = a.Normalization()
		}
		if err = consumer.Begin(setup); err != nil {
			return out, err
		}
	}
	public := append([]candleEvent(nil), candles...)
	sort.SliceStable(public, func(i, j int) bool { return public[i].At < public[j].At })
	ci := 0
	for _, row := range boards {
		o, e := features.OnBoard(row.Board)
		if e != nil {
			return out, e
		}
		if o.Reference != "NK225" {
			continue
		}
		batches := []protect.NativeBatch{}
		micros := []NativeBatch{}
		holds := []HoldEvent{}
		for _, key := range order {
			method := strings.TrimPrefix(strings.TrimPrefix(key, "NK225micro_"), "NK225mini_")
			if !activeMethod(method, o.Time, session) {
				continue
			}
			delta, e := adapters[key].Step(o, row.Line)
			if e != nil {
				return out, fmt.Errorf("%s:%w", key, e)
			}
			out.SourceRows[key]++
			if strings.HasPrefix(key, "NK225mini_") {
				batches = append(batches, protect.NativeBatch{Method: method, Delta: delta})
				if consumer != nil {
					holds = append(holds, adapters[key].touchedHolds("NK225mini", method, delta)...)
				}
			} else {
				micros = append(micros, NativeBatch{Method: method, Delta: delta})
			}
		}
		before, _ := json.Marshal(batches)
		for _, key := range actorKeys {
			if e = actors[key].OnNativeStep(o, row.Line, batches); e != nil {
				return out, fmt.Errorf("%s:%w", key, e)
			}
		}
		after, _ := json.Marshal(batches)
		if !bytes.Equal(before, after) {
			return out, fmt.Errorf("Actorが源通知を変更しました")
		}
		published := []CandlePublication{}
		for ci < len(public) && public[ci].At <= o.Time {
			published = append(published, public[ci])
			ci++
		}
		if consumer != nil {
			notification := NativeStep{Observation: cloneObservation(o), SourceLine: row.Line, Mini: clone(batches), Micro: clone(micros), Holds: holds, Publications: published}
			if e = consumer.Step(notification); e != nil {
				return out, e
			}
		}
	}
	// ----------------------------------------
	// EOFではFinishで残玉・予約を検査し、Force要求や架空fillを補いません。
	minis := map[string]native.Ledger{}
	for _, key := range order {
		ledger, e := adapters[key].Finish()
		out.Sources[key] = ledger
		out.Normalizations[key] = adapters[key].Normalization()
		if e != nil {
			return out, fmt.Errorf("%s EOF:%w", key, e)
		}
		if strings.HasPrefix(key, "NK225mini_") {
			minis[strings.TrimPrefix(key, "NK225mini_")] = ledger
		}
		if adapters[key].forceCalls != 0 {
			return out, fmt.Errorf("元基準に明示Forceが入りました")
		}
	}
	for _, key := range actorKeys {
		book, e := actors[key].Finish()
		book.StreamScope = "111の元166と同じLast>0の原行受理。異常BBOは判断へ配送し約定だけ待機。外timer Forceなし。元Last欠測/不配置はqualityへ別記"
		out.Books[key] = book
		if e != nil {
			return out, fmt.Errorf("%s EOF:%w", key, e)
		}
	}
	if err = CheckMiniMirrors(out.Books, minis); err != nil {
		return out, err
	}
	if err = CheckSourceDelivery(out.Books, minis); err != nil {
		return out, err
	}
	out.MirrorD0 = true
	out.Complete = true
	if consumer != nil {
		if err = consumer.End(SourceEnd{Session: session, Complete: true}); err != nil {
			return out, err
		}
	}
	return out, nil
}

// Replay は原板6参照を認証し元時計の一場を再生します。
//
// 引数: root(string)、input(InputSession)は原データ根と固定指紋・任意Cutoffです。
// 返り値: ReplayResult/errorは源2商品とActual4口座です。元資料の期待値を書き換えません。
func Replay(root string, input InputSession) (ReplayResult, error) {
	return replayInput(root, input, nil)
}

// replayInput は固定Raw読取を共用しconsumerへ一回だけ配送します。
//
// 引数: root(string)、input(InputSession)、consumer(SourceConsumer|nil)は根・場・追加接続です。
// 返り値: ReplayResult/errorは入力不変を確認した源と基準会計です。
func replayInput(root string, input InputSession, consumer SourceConsumer) (ReplayResult, error) {
	session, err := sessionClock(input.ID)
	if err != nil {
		return ReplayResult{}, err
	}
	boards := []replayBoard{}
	candles := []candleEvent{}
	quality := map[string]RawQuality{}
	if input.Cutoff < 0 || input.Cutoff > 0 && (input.Cutoff <= session.Start || input.Cutoff > session.End) {
		return ReplayResult{}, fmt.Errorf("Cutoffが当場範囲外")
	}
	for _, ref := range []string{"TOPIX", "NK225"} {
		path, e := verifyInput(root, input.Files[ref+"_book"])
		if e != nil {
			return ReplayResult{}, e
		}
		rows, q, e := readBoards(path, ref, session)
		if e != nil {
			return ReplayResult{}, e
		}
		if len(q.Contracts) != 1 || ref == "NK225" && q.Contracts[0] != input.Contract {
			return ReplayResult{}, fmt.Errorf("限月差")
		}
		quality[ref] = q
		for _, row := range rows {
			if input.Cutoff <= 0 || row.Board.Time < input.Cutoff {
				boards = append(boards, row)
			}
		}
		for _, iv := range []int{60, 300} {
			path, e = verifyInput(root, input.Files[fmt.Sprintf("%s_candle_%d", ref, iv)])
			if e != nil {
				return ReplayResult{}, e
			}
			c, e := readCandles(path, ref, iv, 60, session)
			if e != nil {
				return ReplayResult{}, e
			}
			candles = append(candles, c...)
		}
	}
	sort.SliceStable(boards, func(i, j int) bool { return boards[i].Board.Time < boards[j].Board.Time })
	result, err := replayEventsWithConsumer(session, input.Contract, boards, candles, quality, consumer)
	if err != nil {
		return result, err
	}
	for _, file := range input.Files {
		if _, err = verifyInput(root, file); err != nil {
			return result, fmt.Errorf("入力の実行後不変差:%w", err)
		}
	}
	return result, nil
}
