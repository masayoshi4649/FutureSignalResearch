# 117Nativeの可逆bytes保管

旧116の純bytes保管器を117の固定F1・全70金融完了へ薄く派生する。変更はtrial、条件/完了SHA、20口座、S0四/旧112十二対照の入力ゲートと出力版識別。金融値の再計算やJSON意味解析は行わず、旧保管器・既存Native・正式成果物は変更しない。現在は人工だけで、自然Nativeの追加読取/全70保管はRootの新要求まで行わない。

対象はRoot全70完了が列挙する70 gzipだけ。Root確認の合計は45,439,595bytesで、元54Native参照再用＋追加16再生の同F1成功、Source同体・旧112全840対照・全flatを小metadataで認証する。metadata-onlyはNativeをopen/stat/hashしない。未固定/未解禁は他Refや出力の作成前に拒否する。

各場の元gzipを一回read/decompressし、その全展開bytesをzstdへ保存する。Python3.14.3標準compression.zstd/zstd1.5.7、level3/window_log29/LDM/checksum、辞書なしを固定。メモリ再展開と保存zstd再展開を全bytes/SHAで照合し、Go1.24.2のgzip.NewWriter defaultへ一括Writeする保存済み実exeで元gzipの全bytes/SHA/sizeまで戻せるか全件検査する。Go source/exeは旧116と同bytesで再ビルドせず、stdin/stdoutの契約も変えない。

出力はNative_zstdと同じ親のNative可逆圧縮索引.json。元gzip Ref/size、展開JSON SHA/size、保存zstd SHA/size、復元方法/実exeを記録する。存在しない通常Native.json.gzを指す偽catalogを作らない。必要時は保存相対zstdからworkの未作成先へ元gzipを同SHAで復元する。元/旧正式Nativeを消さず、削除は一場ごとに新作成した照合用一時gzipだけとする。失敗時は不完了を残す。

```text
python -X utf8 保管する.py --request ABS --sha256 SHA --output ROOT_REQUEST_NEW --metadata-only
python -X utf8 保管する.py --request ABS --sha256 SHA --output ROOT_REQUEST_NEW
python -X utf8 保管する.py --restore-index SUCCESS_INDEX --sha256 SHA --session ID --restore-out WORK_NEW_GZIP --restorer SAVED_EXE
```

人工6主は `python -X utf8 人工検査.py`、停止前proofは `python -X utf8 検査して停止する.py`。Rootレビュー後だけ同helperへ `--reviewed --stop` を渡す。新未許可テンプレからRootが新要求を固定して全70を一度保管する。Rootが金融停止/報告を仕上げるための保存部品であり、新戦略・閾値探索はしない。
