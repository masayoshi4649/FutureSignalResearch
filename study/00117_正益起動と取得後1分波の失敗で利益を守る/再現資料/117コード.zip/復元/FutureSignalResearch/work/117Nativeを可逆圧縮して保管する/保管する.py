"""117の許可Nativeを意味解析せず可逆圧縮し、元gzipの指紋まで復元確認する。"""
from pathlib import Path
from time import perf_counter
import argparse
import compression.zstd as zstd
import gzip
import hashlib
import json
import os
import platform
import re
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
POLICY='native_payload_zstd3_window29_ldm_restore_go1242_v1'
F1_SHA='522fe2343b914243fadc4f48d32128a79ecdafcabd84d5a58b5ca399af90d1b0'
COMPLETE_SHA='f9d5dfc49bef7f9b2dcf6bba55fe264b689dc2e8312e0e26c4530e4b1d2872e0'
SOURCE_TOTAL_BYTES=45439595
RESTORER_SHA='a06c854ce4bfe6db22a3329e28a571a56454dfaaf11c90af1e33efc9a4e12c9c'
RESTORER_SOURCE_SHA='21f1ba26ff4afd4eba42d01156b6d4b70a92854f81858456ff78ffbbd01e6656'
OWNED=('保管する.py','人工検査.py','gzipを再現する.go','gzipを再現する.exe','README.md','検査して停止する.py')
OPTIONS={'compression_level':3,'window_log':29,'enable_long_distance_matching':1,'checksum_flag':1}


def need(value: bool,label: str) -> None:
    """
    機能: bytes保管の根拠又は範囲差を拒否する。
    引数: value(bool)、label(str)。返り値: None。不成立ならValueError。
    """
    if not value:raise ValueError(label)


def digest(data: bytes) -> str:
    """
    機能: bytesのSHA256を計算する。
    引数: data(bytes)。返り値: strは小文字指紋。
    """
    return hashlib.sha256(data).hexdigest()


def file_ref(path: Path) -> dict:
    """
    機能: 明示小ファイルの絶対参照を作る。
    引数: path(Path)。返り値: dictはpath/sha256。Nativeはpack_oneの一回読取だけ。
    """
    return {'path':str(path.resolve()),'sha256':digest(path.read_bytes())}


def normalize_ref(ref: dict) -> dict:
    """
    機能: path/shaと任意bytesだけのFileRefを形式検査する。
    引数: ref(dict)。返り値: dictはpath/shaのみの正規形。本文は読まない。
    """
    need(isinstance(ref,dict) and {'path','sha256'}<=set(ref)<={'path','sha256','bytes'},'FileRefのfield差')
    need(isinstance(ref['path'],str) and Path(ref['path']).is_absolute() and isinstance(ref['sha256'],str) and re.fullmatch('[0-9a-f]{64}',ref['sha256']) is not None,'絶対FileRef/SHA形式')
    if 'bytes' in ref:need(type(ref['bytes']) is int and ref['bytes']>=0,'Ref bytes型')
    return {'path':os.path.normpath(ref['path']),'sha256':ref['sha256']}


def read_json(ref: dict,before: dict) -> dict:
    """
    機能: 固定要求・停止・完了・索引という小JSONだけをSHA認証して読む。
    引数: ref/before(dict)。返り値: dictは小metadata。gzip/zstdは受理しない。
    """
    normalized=normalize_ref(ref);p=Path(normalized['path']);need(p.suffix=='.json','小JSON metadataだけ')
    raw=p.read_bytes();need(digest(raw)==normalized['sha256'],'小metadata SHA差')
    if 'bytes' in ref:need(len(raw)==ref['bytes'],'小metadata bytes差')
    need(str(p) not in before or before[str(p)]==normalized['sha256'],'同pathのSHA衝突')
    before[str(p)]=normalized['sha256'];return json.loads(raw.decode('utf-8-sig'))


def validate_completion(value: dict,condition_sha: str) -> list[dict]:
    """
    機能: 同F1/70場20会計/Source非干渉/840旧対照と全flatを検査する。
    引数: value(dict)、condition_sha(str)。返り値: list[dict]は許可された70Native参照。
    """
    for name,expected in {'version':1,'trial':117,'success':True,'stage':'full70','sessions':70,'books':1400,'condition_sha256':condition_sha,'unchanged':True,'reference112_comparisons':840,'all_reference112_equal':True,'all_source111_equal':True,'all_original166_reference_events_equal':True,'original_methods':81,'historical_saved_events_equal':False,'all_original_signal_full_json_equal':False,'reused_sessions':54,'replayed_sessions':16}.items():need(type(value[name]) is type(expected) and value[name]==expected,'金融完了の固定差:'+name)
    need(value['before']==value['after'],'金融完了前後不変')
    rows=value['results'];need(len(rows)==70,'金融Native70集合');seen=set();paths=set();selected=[]
    for row in rows:
        sid=row['session'];need(re.fullmatch(r'2026-\d{2}-\d{2}_(Day|Night)',sid) is not None and '2026-09-21_Day'<=sid<='2026-11-06_Night' and sid not in seen,'許可70場ID/11月09除外')
        for name,expected in {'books':20,'S0_comparisons':4,'S0_equal':True,'complete':True,'open_quantity':0,'pending_quantity':0,'reference112_comparisons':12,'reference112_equal':True,'source111_equal':True}.items():need(type(row[name]) is type(expected) and row[name]==expected,'場別20/4/12/flat差:'+name)
        ref=normalize_ref(row['native']);need(ref['path'].endswith('.Native.json.gz') and ref['path'] not in paths,'Native形式/重複')
        seen.add(sid);paths.add(ref['path']);selected.append({'session':sid,'source_gzip':ref})
    need([r['session'] for r in rows]==sorted(seen) and rows[0]['session']=='2026-09-21_Day' and rows[53]['session']=='2026-10-27_Night' and rows[-1]['session']=='2026-11-06_Night','全70場順序/54境界')
    return selected


def prepare(request_ref: dict,output: Path) -> dict:
    """
    機能: Root許可・自己停止・実Go復元exe・同F1金融完了だけを本文前に認証する。
    引数: request_ref(dict)、output(Path)は固定要求と新規work先。
    返り値: dictはNative本文もstatも未読の計画。
    """
    before={};request=read_json(request_ref,before)
    need(request['version']==1 and request['trial']==117 and request['fixed'] is True and request['native_read_authorized'] is True and request['policy']==POLICY,'RootのNative70読取新固定許可が必要')
    need(platform.python_version()=='3.14.3' and zstd.zstd_version=='1.5.7','固定Python/zstd圧縮器の版')
    output=output.resolve();need(not output.exists() and output.is_relative_to((ROOT/'work').resolve()) and str(output)==str(Path(request['output_dir']).resolve()),'未作成work出力だけ。正式先へ直接書かない')
    stopped=read_json(request['code_stop'],before)
    need(stopped['試行']==117 and stopped['成功'] is True and stopped['停止'] is True and stopped['市場前'] is True,'この保管器のRootレビュー後停止')
    expected={str((HERE/name).resolve()) for name in OWNED};need(set(stopped['所有ファイルSHA256'])==expected,'保管器所有6')
    for name,sha in stopped['所有ファイルSHA256'].items():need(digest(Path(name).read_bytes())==sha,'自己所有code/exe SHA差');before[name]=sha
    restorer=normalize_ref(request['restorer']);need(restorer['sha256']==RESTORER_SHA and restorer==normalize_ref(stopped['実Go復元物']),'実使用Go1.24.2復元exe')
    need(digest(Path(restorer['path']).read_bytes())==RESTORER_SHA and digest((HERE/'gzipを再現する.go').read_bytes())==RESTORER_SOURCE_SHA,'Go復元物/sourceの同bytes差')
    need(request['condition']['sha256']==F1_SHA and request['completion']['sha256']==COMPLETE_SHA,'Root指定金融F1/全70完了SHA')
    fixed=read_json(request['condition'],before);need(fixed['trial']==117 and fixed['fixed'] is True and len(fixed['actual_configurations'])==20,'117同F1金融条件')
    complete=read_json(request['completion'],before);selected=validate_completion(complete,F1_SHA)
    need(request['compression']==OPTIONS,'zstd level3/window29/LDM/checksumの固定差')
    return {'request':request,'request_ref':normalize_ref(request_ref),'before':before,'selected':selected,'output':output,'restorer':restorer}


def save_new(path: Path,data: bytes) -> None:
    """
    機能: 新規先だけへbytesを保存する。
    引数: path(Path)、data(bytes)。返り値: None。元Nativeを上書きしない。
    """
    with path.open('xb') as stream:need(stream.write(data)==len(data),'全bytes保存')


def go_restore(payload: bytes,target: Path,executable: Path) -> dict:
    """
    機能: 固定実exeへstdinでpayloadを渡し、gzip.NewWriterへ一括Writeする。
    引数: payload(bytes)、target/executable(Path)。返り値: dictは小復元metadata。
    """
    need(not target.exists() and digest(executable.read_bytes())==RESTORER_SHA,'固定Go実exeと新規復元先')
    options={'creationflags':subprocess.CREATE_NO_WINDOW} if os.name=='nt' else {}
    result=subprocess.run([str(executable),'--out',str(target)],input=payload,capture_output=True,timeout=600,**options)
    need(result.returncode==0,'Go復元失敗:'+result.stderr.decode('utf-8',errors='replace'))
    value=json.loads(result.stdout);need(value['成功'] is True and value['一括Write回数']==1 and value['展開bytes']==len(payload),'Go一括Write契約');return value


def pack_one(item: dict,folder: Path,temporary: Path,executable: Path) -> dict:
    """
    機能: 許可一場を一回読取/展開し、zstd保存と元gzip完全復元を検査する。
    引数: item(dict)、folder/temporary/executable(Path)は許可参照・新規先・一時先・Go物。
    返り値: dictは保存zstd/展開JSON/元gzipの指紋。JSON意味解析は0。
    """
    sid=item['session'];need(re.fullmatch(r'[A-Za-z0-9_-]+',sid) is not None,'安全な場ファイル名')
    source=Path(item['source_gzip']['path']);need(source.resolve().parent!=folder.resolve(),'元と保存先を分離')
    with source.open('rb') as stream:
        stat_before=os.fstat(stream.fileno());compressed=stream.read();stat_after=os.fstat(stream.fileno())
    need(stat_before.st_size==len(compressed)==stat_after.st_size and stat_before.st_mtime_ns==stat_after.st_mtime_ns and digest(compressed)==item['source_gzip']['sha256'],'元gzipの一回読取/指紋')
    started=perf_counter();payload=gzip.decompress(compressed);unpack_seconds=perf_counter()-started;json_sha=digest(payload)
    started=perf_counter();packed=zstd.compress(payload,options={getattr(zstd.CompressionParameter,name):value for name,value in OPTIONS.items()});compression_seconds=perf_counter()-started
    need(zstd.decompress(packed,options={zstd.DecompressionParameter.window_log_max:29})==payload,'zstdメモリ展開bytes差')
    target=folder/(sid+'.Native.json.zst');save_new(target,packed);saved=target.read_bytes();need(saved==packed,'保存zstd全bytes差')
    started=perf_counter();restored_payload=zstd.decompress(saved,options={zstd.DecompressionParameter.window_log_max:29});restore_seconds=perf_counter()-started
    need(restored_payload==payload and digest(restored_payload)==json_sha,'保存zstdから全JSON bytes/SHA差')
    restored_gzip=temporary/(sid+'.照合用.Native.json.gz');started=perf_counter();go=go_restore(restored_payload,restored_gzip,executable);gzip_seconds=perf_counter()-started
    need(go['gzip_SHA256']==item['source_gzip']['sha256'] and go['gzip_bytes']==len(compressed),'元gzip SHA/size差')
    need(restored_gzip.read_bytes()==compressed,'元gzip全bytes差')
    after=source.stat();need(after.st_size==stat_before.st_size and after.st_mtime_ns==stat_before.st_mtime_ns,'元gzip前後stat差')
    # ----------------------------------------
    # 削除するのは今作成した一場の照合用ファイルだけ。元gzip/旧Nativeへunlinkしない。
    need(restored_gzip.resolve().parent==temporary.resolve() and temporary.resolve().is_relative_to(folder.parent.resolve()),'照合用新規ファイルの所有範囲')
    restored_gzip.unlink()
    return {'session':sid,'source_original_gzip':item['source_gzip'],'source_gzip_bytes':len(compressed),'json_bytes':len(payload),'json_sha256':json_sha,
            'stored_format':'zstd_of_exact_json_bytes','stored_relative':'Native_zstd/'+target.name,'stored_zstd':{'path':str(target),'sha256':digest(saved),'bytes':len(saved)},
            'restored_gzip_sha256':go['gzip_SHA256'],'restored_gzip_bytes':go['gzip_bytes'],'restored_json_all_bytes_equal':True,'restored_gzip_all_bytes_equal':True,
            'gzip_decompressions_of_source':1,'source_file_reads':1,'seconds':{'gzip_decompress':unpack_seconds,'zstd_compress':compression_seconds,'zstd_decompress_saved':restore_seconds,'Go_gzip_restore':gzip_seconds}}


def execute(plan: dict) -> dict:
    """
    機能: 全70だけを逐次保管し、全件一致・入力不変後だけ索引を成功保存する。
    引数: plan(dict)は認証済み計画。返り値: dictは実zstd索引Ref。失敗時は不完了を残す。
    """
    output=plan['output'];output.mkdir();folder=output/'Native_zstd';temporary=output/'照合用_新規一時';folder.mkdir();temporary.mkdir();rows=[]
    try:
        for item in plan['selected']:
            rows.append(pack_one(item,folder,temporary,Path(plan['restorer']['path'])))
            print(json.dumps({'場数':len(rows),'session':item['session'],'元gzip_bytes':rows[-1]['source_gzip_bytes'],'保存zstd_bytes':rows[-1]['stored_zstd']['bytes']},ensure_ascii=False),flush=True)
        need(len(rows)==70 and sum(r['source_gzip_bytes'] for r in rows)==SOURCE_TOTAL_BYTES and all(digest(Path(p).read_bytes())==sha for p,sha in plan['before'].items()),'全70集合/指定元gzip合計bytes/小metadata code前後差')
        need(not list(temporary.iterdir()),'照合用gzipの残存なし');temporary.rmdir()
        value={'version':1,'trial':117,'success':True,'policy':POLICY,'sessions':70,'condition':plan['request']['condition'],'financial_completion':plan['request']['completion'],'Root要求':plan['request_ref'],
               'compression':OPTIONS,'python':platform.python_version(),'zstd_version':zstd.zstd_version,'restore':{'executable':plan['restorer'],'source':file_ref(HERE/'gzipを再現する.go'),'Go_version':'go1.24.2','method':'gzip.NewWriter default、展開bytesを一括Write一回、元headerを変更しない'},
               'Native_zstd':rows,'total_source_gzip_bytes':sum(r['source_gzip_bytes'] for r in rows),'total_stored_zstd_bytes':sum(r['stored_zstd']['bytes'] for r in rows),'all_json_bytes_equal':True,'all_original_gzip_bytes_equal':True,
               '通常Native.json.gzのcatalog作成':False,'元Native削除/上書き':False,'金融計算/JSON意味解析':False,'Raw/CSV/11月09読取':False,'入力codeSHA256前':plan['before'],'入力codeSHA256後':dict(plan['before']),'前後不変':True}
        target=output/'Native可逆圧縮索引.json';save_new(target,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'));return file_ref(target)
    except Exception as error:
        save_new(output/'不完了.json',(json.dumps({'trial':117,'success':False,'processed_sessions':len(rows),'error':str(error),'元Native削除/上書き':False},ensure_ascii=False,indent=2)+'\n').encode('utf-8'));raise


def restore_one(index_ref: dict,session: str,target: Path,executable: Path) -> dict:
    """
    機能: 成功索引の実zstdから一場の元gzipを新規work先へ正確に復元する。
    引数: index_ref(dict)、session(str)、target/executable(Path)は索引/場/新規先/保存実exe。
    返り値: dictは元gzipと同SHAの復元物Ref。保存索引を通常gzip所在と偽装しない。
    """
    before={};index=read_json(index_ref,before);need(index['version']==1 and index['trial']==117 and index['success'] is True and index['policy']==POLICY and index['sessions']==70 and index['all_json_bytes_equal'] is True and index['all_original_gzip_bytes_equal'] is True,'全70可逆圧縮成功索引だけ')
    need(index['compression']==OPTIONS and index['restore']['executable']['sha256']==RESTORER_SHA,'保存方式/元Go物')
    target=target.resolve();need(not target.exists() and target.is_relative_to((ROOT/'work').resolve()) and target.parent.is_dir(),'復元は既存work親配下の新規先だけ')
    selected=[r for r in index['Native_zstd'] if r['session']==session];need(len(selected)==1,'成功索引の場一意性');row=selected[0]
    base=Path(normalize_ref(index_ref)['path']).parent;stored=base/row['stored_relative'];need(stored.resolve().is_relative_to(base.resolve()) and row['stored_relative']=='Native_zstd/'+session+'.Native.json.zst','実zstdの安全な保存相対位置')
    packed=stored.read_bytes();need(len(packed)==row['stored_zstd']['bytes'] and digest(packed)==row['stored_zstd']['sha256'],'保存zstdの指紋')
    payload=zstd.decompress(packed,options={zstd.DecompressionParameter.window_log_max:29});need(len(payload)==row['json_bytes'] and digest(payload)==row['json_sha256'],'元JSON bytes指紋')
    restored=go_restore(payload,target,executable);need(restored['gzip_SHA256']==row['source_original_gzip']['sha256'] and restored['gzip_bytes']==row['source_gzip_bytes'],'元gzip SHA/sizeを復元')
    need(all(digest(Path(p).read_bytes())==sha for p,sha in before.items()),'索引前後差');return {'path':str(target),'sha256':restored['gzip_SHA256']}


def main() -> None:
    """
    機能: Root許可保管又は成功索引からの明示work復元を分けて実行する。
    引数: CLI request/sha256/output又はrestore-index/session/restore-out/restorer。返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--request',type=Path);parser.add_argument('--sha256');parser.add_argument('--output',type=Path);parser.add_argument('--metadata-only',action='store_true')
    parser.add_argument('--restore-index',type=Path);parser.add_argument('--session');parser.add_argument('--restore-out',type=Path);parser.add_argument('--restorer',type=Path)
    args=parser.parse_args()
    if args.restore_index is not None:
        need(args.request is None and args.output is None and not args.metadata_only and args.session and args.restore_out and args.restorer and args.sha256,'保管と復元のCLIを混ぜない')
        result=restore_one({'path':str(args.restore_index.resolve()),'sha256':args.sha256},args.session,args.restore_out,args.restorer.resolve())
    else:
        need(args.request and args.sha256 and args.output and args.session is None and args.restore_out is None and args.restorer is None,'Root保管要求と新規先が必要')
        plan=prepare({'path':str(args.request.resolve()),'sha256':args.sha256},args.output)
        result={'成功':True,'Native本文/stat読取':False,'場数':len(plan['selected'])} if args.metadata_only else execute(plan)
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
