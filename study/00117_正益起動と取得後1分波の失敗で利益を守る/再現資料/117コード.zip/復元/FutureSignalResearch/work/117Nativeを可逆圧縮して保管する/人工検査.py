"""Native可逆保管を意味不明の手製bytesとmetadataだけで検査する。"""
from copy import deepcopy
from datetime import date,timedelta
from pathlib import Path
import gzip
import json
import tempfile
import unittest
import 保管する as M


def completion_fixture(folder: Path) -> dict:
    """
    機能: 実在しない70Native参照の手製完了metadataを作る。
    引数: folder(Path)は一時親。返り値: dictは人工だけで金融成功証拠ではない。
    """
    value={'version':1,'trial':117,'success':True,'stage':'full70','sessions':70,'books':1400,'condition_sha256':M.F1_SHA,'unchanged':True,
           'reference112_comparisons':840,'all_reference112_equal':True,'all_source111_equal':True,'all_original166_reference_events_equal':True,'original_methods':81,
           'historical_saved_events_equal':False,'all_original_signal_full_json_equal':False,'reused_sessions':54,'replayed_sessions':16,'before':{},'after':{},'results':[],'人工':True}
    day=date(2026,9,21)
    while len(value['results'])<70:
        if day.weekday()<5:
            for kind in ('Day','Night'):
                sid=day.isoformat()+'_'+kind
                value['results'].append({'session':sid,'native':{'path':str(folder/(sid+'.Native.json.gz')),'sha256':'0'*64},'books':20,'S0_comparisons':4,'S0_equal':True,'complete':True,'open_quantity':0,'pending_quantity':0,'reference112_comparisons':12,'reference112_equal':True,'source111_equal':True})
        day+=timedelta(days=1)
    return value


class ArchiveTests(unittest.TestCase):
    def test_opaque_bytes_exact_pack(self):
        """
        機能: JSONでない全byte値を含む手製payloadでも一回読取/可逆保管できる。
        引数: self(ArchiveTests)。返り値: None。意味解析を通さない証拠とする。
        """
        with tempfile.TemporaryDirectory(dir=M.HERE) as folder:
            base=Path(folder);source=base/'人工.Native.json.gz';exe=M.HERE/'gzipを再現する.exe'
            payload=(bytes(range(256))+b'JSON_not_required\x00')*4096
            M.go_restore(payload,source,exe);original=source.read_bytes();source_ref=M.file_ref(source)
            output,temporary=base/'Native_zstd',base/'新規照合用';output.mkdir();temporary.mkdir()
            row=M.pack_one({'session':'ArtificialOne','source_gzip':source_ref},output,temporary,exe)
            self.assertEqual(row['source_file_reads'],1);self.assertEqual(row['gzip_decompressions_of_source'],1)
            self.assertTrue(row['restored_json_all_bytes_equal'] and row['restored_gzip_all_bytes_equal'])
            self.assertEqual(source.read_bytes(),original);self.assertEqual(list(temporary.iterdir()),[])
            self.assertEqual(row['stored_relative'],'Native_zstd/ArtificialOne.Native.json.zst')
            self.assertFalse((base/'ArtificialOne.Native.json.gz').exists())

    def test_source_sha_rejected_without_output(self):
        """
        機能: 元gzip指紋差ではzstdも復元物も作らない。
        引数: self(ArchiveTests)。返り値: None。人工gzipだけを読む。
        """
        with tempfile.TemporaryDirectory(dir=M.HERE) as folder:
            base=Path(folder);source=base/'人工.gz';source.write_bytes(gzip.compress(b'opaque'))
            output,temporary=base/'Native_zstd',base/'新規照合用';output.mkdir();temporary.mkdir()
            with self.assertRaises(ValueError):M.pack_one({'session':'Artificial','source_gzip':{'path':str(source),'sha256':'0'*64}},output,temporary,M.HERE/'gzipを再現する.exe')
            self.assertEqual(list(output.iterdir()),[]);self.assertEqual(list(temporary.iterdir()),[])

    def test_completion_metadata_without_native_files(self):
        """
        機能: 同F1/20/840/前後不変のmetadata検査でNativeへstat/openしない。
        引数: self(ArchiveTests)。返り値: None。70参照先は全て不存在。
        """
        with tempfile.TemporaryDirectory(dir=M.HERE) as folder:
            data=completion_fixture(Path(folder));selected=M.validate_completion(data,M.F1_SHA)
            self.assertEqual(len(selected),70);self.assertFalse(any(Path(x['source_gzip']['path']).exists() for x in selected))
            for kind in ('books','source','comparison','same_input','duplicate','future'):
                bad=deepcopy(data)
                if kind=='books':bad['books']=840
                elif kind=='source':bad['all_source111_equal']=False
                elif kind=='comparison':bad['results'][0]['S0_comparisons']=12
                elif kind=='same_input':bad['after']={'changed':'bad'}
                elif kind=='duplicate':bad['results'][1]['native']=bad['results'][0]['native']
                else:bad['results'][-1]['session']='2026-11-09_Day'
                with self.assertRaises(ValueError):M.validate_completion(bad,M.F1_SHA)

    def test_unfixed_rejected_before_refs(self):
        """
        機能: 未固定/未許可を他RefやNativeと出力作成より前に拒否する。
        引数: self(ArchiveTests)。返り値: None。
        """
        with tempfile.TemporaryDirectory(dir=M.HERE) as folder:
            root=Path(folder);request=root/'未許可.json'
            for fixed,authorized in ((False,True),(True,False)):
                request.write_text(json.dumps({'version':1,'trial':117,'fixed':fixed,'native_read_authorized':authorized,'policy':M.POLICY}),encoding='utf-8')
                with self.assertRaises(ValueError):M.prepare(M.file_ref(request),root/'作らない')
                self.assertFalse((root/'作らない').exists())

    def test_restorer_fingerprint_and_existing_path(self):
        """
        機能: 別exeと既存復元先を実行又は上書きしない。
        引数: self(ArchiveTests)。返り値: None。
        """
        with tempfile.TemporaryDirectory(dir=M.HERE) as folder:
            base=Path(folder);exe=base/'別.exe';exe.write_bytes(b'not executable')
            with self.assertRaises(ValueError):M.go_restore(b'opaque',base/'出力.gz',exe)
            target=base/'既存.gz';target.write_bytes(b'keep')
            with self.assertRaises(ValueError):M.go_restore(b'opaque',target,M.HERE/'gzipを再現する.exe')
            self.assertEqual(target.read_bytes(),b'keep')

    def test_ref_and_success_index_gate(self):
        """
        機能: optional bytes型と不完了索引の復元拒否を検査する。
        引数: self(ArchiveTests)。返り値: None。
        """
        with tempfile.TemporaryDirectory(dir=M.HERE) as folder:
            base=Path(folder);index=base/'不完了.json';index.write_text(json.dumps({'version':1,'trial':117,'success':False}),encoding='utf-8')
            ref=M.file_ref(index);ref['bytes']=index.stat().st_size
            self.assertEqual(M.normalize_ref(ref),M.file_ref(index))
            for invalid in (True,-1,'1'):
                with self.assertRaises(ValueError):M.normalize_ref({**ref,'bytes':invalid})
            with self.assertRaises((ValueError,KeyError)):M.restore_one(M.file_ref(index),'Artificial',base/'復元.gz',M.HERE/'gzipを再現する.exe')
            self.assertFalse((base/'復元.gz').exists())


if __name__=='__main__':unittest.main(verbosity=2)
