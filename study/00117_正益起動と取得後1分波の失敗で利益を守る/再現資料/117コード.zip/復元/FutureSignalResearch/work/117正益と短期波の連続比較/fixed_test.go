package shortcomparison117

import (
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	actor "github.com/masayoshi4649/SessionTradeExecuter/continuousactor117"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor117"
	short "github.com/masayoshi4649/SessionTradeExecuter/shortwave117"
)

// testRef は人工又は許可されたmetadataの実参照を作ります。
//
// 引数: t(*testing.T)、path(string)は試験器と小ファイルです。
// 返り値: source.FileRefは実指紋付き参照です。Native本文には使いません。
func testRef(t *testing.T, path string) source.FileRef {
	t.Helper()
	sha, err := source.Digest(path)
	if err != nil {
		t.Fatal(err)
	}
	return source.FileRef{Path: path, SHA256: sha}
}

// metadataFixture は旧成功の小metadataだけを用いた新117外ゲートの人工条件です。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: source.FileRef/Fixedは人工停止を使う条件です。旧Native本文/指紋とRawは読みません。
func metadataFixture(t *testing.T) (source.FileRef, Fixed) {
	t.Helper()
	here, _ := Directory()
	root := filepath.Clean(filepath.Join(here, "../.."))
	base := t.TempDir()
	deps, err := BasisStops()
	if err != nil {
		t.Fatal(err)
	}
	// ----------------------------------------
	// 停止前部品を市場へ解禁せず、tempの明示人工停止と実関数宣言だけで外ゲートを検査する。
	for _, key := range []string{"actor", "pure", "shortwave"} {
		r, e := SaveNew(filepath.Join(base, key+"_人工停止.json"), map[string]any{"成功": true, "停止": true, "市場前": true, "人工": true}, false)
		if e != nil {
			t.Fatal(e)
		}
		deps[key] = r
	}
	actual, err := SaveNew(filepath.Join(base, "Actor実関数宣言.json"), actor.DeclaredContinuousConfigurations(), false)
	if err != nil {
		t.Fatal(err)
	}
	h0e, _ := guard.H0DefinitionFor(guard.H0E)
	h0m, _ := guard.H0DefinitionFor(guard.H0M)
	pure, err := SaveNew(filepath.Join(base, "純実関数宣言.json"), map[string]any{"version": 117, "configurations": guard.DeclaredConfigurations(), "definitions": guard.DeclaredDefinitions(), "h0_definitions": []guard.H0Definition{h0e, h0m}}, false)
	if err != nil {
		t.Fatal(err)
	}
	shortRef, err := SaveNew(filepath.Join(base, "短期実関数定義.json"), short.DeclaredDefinition(), false)
	if err != nil {
		t.Fatal(err)
	}
	chart := testRef(t, filepath.Join(here, "../111連続保護のチャート公開/検査/API宣言.json"))
	paths, err := RequiredCodePaths()
	if err != nil {
		t.Fatal(err)
	}
	copyRef := source.FileRef{Path: filepath.Join(root, "work/113進行/高速コピーの自然2場対照.json"), SHA256: "6ea49e767982a994d8fd2f5053133ef2070b348d2a344d5a6be8b2a9dd3ec861"}
	if err := source.VerifyRef(copyRef); err != nil {
		t.Fatal(err)
	}
	codes := map[string]string{copyRef.Path: copyRef.SHA256}
	for _, path := range paths {
		ref := testRef(t, path)
		codes[path] = ref.SHA256
	}
	for _, ref := range deps {
		codes[ref.Path] = ref.SHA256
	}
	for _, ref := range []source.FileRef{actual, pure, chart, shortRef} {
		codes[ref.Path] = ref.SHA256
	}
	exe, _ := os.Executable()
	exeRef := testRef(t, exe)
	stopRef, err := SaveNew(filepath.Join(base, "人工停止.json"), RuntimeStop{Success: true, Stopped: true, Trial: 117, AllCode: copyValue(codes), Owned: map[string]string{}, Executable: exeRef, Dependencies: deps, CopyBasis: copyRef}, false)
	if err != nil {
		t.Fatal(err)
	}
	codes[stopRef.Path] = stopRef.SHA256
	trialRoot := filepath.Join(root, "study/00112_支持否定の確認と通常追尾幅の比較")
	oldRef := source.FileRef{Path: filepath.Join(trialRoot, "検査/condition.json"), SHA256: "893fa4dbaa0525f0f37579e750a46d5e846a9dbc83bf4b816e16e97e4527ad69"}
	var old source.Fixed
	if err = readRef(oldRef, &old); err != nil {
		t.Fatal(err)
	}
	catalogRef := source.FileRef{Path: filepath.Join(trialRoot, "成果物_金融/Native参照台帳.json"), SHA256: "8f156a252ad9f53951c0feba87424a46112e939276490b510261b491a581811d"}
	var catalog any
	if err = readRef(catalogRef, &catalog); err != nil {
		t.Fatal(err)
	}
	// ----------------------------------------
	// コピーするのは索引metadataだけです。参照先のNativeを作らず認証経路を通します。
	fakeCatalog := filepath.Join(base, "旧112/成果物_金融/Native参照台帳.json")
	if err = os.MkdirAll(filepath.Dir(fakeCatalog), 0755); err != nil {
		t.Fatal(err)
	}
	catalogRef, err = SaveNew(fakeCatalog, catalog, false)
	if err != nil {
		t.Fatal(err)
	}
	f := Fixed{Version: 1, Trial: 117, Fixed: true, Policy: Policy, SourceTrial: 111, FARCommit: old.FARCommit, StrategyCommit: old.StrategyCommit,
		Manifest: old.Manifest, Executable: exeRef, CodeSHA256: codes, Golden: old.Golden, RuntimeStop: stopRef, DependencyStops: deps, CopyBasis: copyRef,
		ActualPolicy: ActualPolicy, ChartSeedMode: "cold_each_session", ActualConfigurations: actor.DeclaredContinuousConfigurations(),
		PureConfigurations: guard.DeclaredConfigurations(), Definitions: guard.DeclaredDefinitions(), ActualDeclaration: actual, PureDeclaration: pure, ChartDeclaration: chart,
		H0Definitions: DeclaredH0Definitions(), ShortDefinition: short.DeclaredDefinition(), ShortDeclaration: shortRef,
		Reference112:   References112{Condition: oldRef, Market: source.FileRef{Path: filepath.Join(trialRoot, "検査/market.json"), SHA256: "0bf84f14196632787ba7d520a21bf30cc723a185fe3300599f6533e420149cf9"}, NativeCatalog: catalogRef},
		ParallelMethod: ParallelMethod, ParallelMaxWorkers: 16}
	ref, err := SaveNew(filepath.Join(base, "人工固定113.json"), f, false)
	if err != nil {
		t.Fatal(err)
	}
	return ref, f
}

// TestMetadataGateWithoutNative は117外ゲートの全認証を旧Native未作成のまま通します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。市場や旧金融本文を読みません。
func TestMetadataGateWithoutNative(t *testing.T) {
	ref, f := metadataFixture(t)
	plan, err := PrepareFixed(ref, "metadata-only", nil)
	if err != nil || len(plan.Source.Cases) != 70 || len(plan.LegacyNatives) != 70 {
		t.Fatal(err)
	}
	for _, native := range plan.LegacyNatives {
		if _, err := os.Stat(native.Path); !os.IsNotExist(err) {
			t.Fatal("旧Nativeが必要になった", err)
		}
	}
	if plan.Fixed.Trial != 117 || plan.Source.Fixed.Trial != 117 {
		t.Fatal("試行の偽装")
	}
	for _, stage := range []string{"first2", "base54"} {
		got, err := PrepareFixed(ref, stage, nil)
		if err != nil || len(got.Source.Cases) != map[string]int{"first2": 2, "base54": 54}[stage] {
			t.Fatal(stage, err)
		}
	}
	for _, mode := range []string{"旧試行偽装", "設定変更", "定義変更", "H0昇格変更", "短期仕様変更", "実行物変更", "閉包欠落", "旧参照欠落"} {
		t.Run(mode, func(t *testing.T) {
			bad := copyValue(f)
			switch mode {
			case "旧試行偽装":
				bad.Trial = 112
			case "設定変更":
				bad.ActualConfigurations[0].SlipPts = 3
			case "定義変更":
				bad.Definitions[1].NormalWidthMinimum = 400
			case "H0昇格変更":
				x := bad.H0Definitions[guard.H0E]
				x.NewPeakRequired = true
				bad.H0Definitions[guard.H0E] = x
			case "短期仕様変更":
				bad.ShortDefinition.MACDFast = 8
			case "実行物変更":
				bad.Executable.SHA256 = "別実行物"
			case "閉包欠落":
				for path := range bad.CodeSHA256 {
					delete(bad.CodeSHA256, path)
					break
				}
			case "旧参照欠落":
				delete(bad.Golden, "2026-09-21_Day")
			}
			b, err := SaveNew(filepath.Join(t.TempDir(), "破壊.json"), bad, false)
			if err != nil {
				t.Fatal(err)
			}
			if _, err := PrepareFixed(b, "metadata-only", nil); err == nil {
				t.Fatal("破壊を受理")
			}
		})
	}
	if _, err := PrepareFixed(ref, "full70", nil); err == nil {
		t.Fatal("元54成功なしを受理")
	}
	if _, err := PrepareFixed(ref, "未知", nil); err == nil {
		t.Fatal("未知段階を受理")
	}
}

// TestPrior54GateAndNativeFingerprints は同117の全54成功と同bytes再用を手製metadataで検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。Native内容は人工の印だけです。
func TestPrior54GateAndNativeFingerprints(t *testing.T) {
	condition, f := metadataFixture(t)
	p, err := PrepareFixed(condition, "base54", nil)
	if err != nil {
		t.Fatal(err)
	}
	old := Completion{Version: 1, Trial: 117, Stage: "base54", Success: true, ConditionSHA256: condition.SHA256, Sessions: 54, ReplayedSessions: 54, Books: 1080, OriginalMethods: 81,
		AllReferenceEventsEqual: true, Reference112Comparisons: 648, AllReference112Equal: true, AllSource111Equal: true, Unchanged: true, Before: copyValue(p.Source.Before), After: copyValue(p.Source.Before)}
	for i, input := range p.Source.Cases {
		native, err := SaveNew(filepath.Join(t.TempDir(), input.ID+".Native.json.gz"), map[string]any{"人工": true}, true)
		if err != nil {
			t.Fatal(err)
		}
		methods := 1
		if i%2 == 1 {
			methods = 2
		}
		old.Results = append(old.Results, SceneResult{Session: input.ID, Native: native, Golden: &source.GoldenProof{Reference: f.Golden[input.ID], Session: input.ID, Methods: methods, EventsEqual: true, MiniEventsEqual: true, ReferenceKind: "rerun_original166_pinned_code"}, Books: 20, S0Comparisons: 4, S0Equal: true, Complete: true, Reference112: p.LegacyNatives[input.ID], Reference112Comparisons: 12, Reference112Equal: true, Source111Equal: true})
	}
	if err := validatePrior54(old, condition, p); err != nil {
		t.Fatal(err)
	}
	prior, err := SaveNew(filepath.Join(t.TempDir(), "元54成功.json"), old, false)
	if err != nil {
		t.Fatal(err)
	}
	got, err := PrepareFixed(condition, "full70", &prior)
	if err != nil || len(got.Source.Cases) != 70 || got.Prior54 == nil || !reflect.DeepEqual(got.Prior54.Results, old.Results) {
		t.Fatal(err)
	}
	for _, mode := range []string{"旧対照不足", "金融未完了", "欠落場", "前証拠差", "元Event差", "Native差"} {
		t.Run(mode, func(t *testing.T) {
			bad := copyValue(old)
			switch mode {
			case "旧対照不足":
				bad.Results[0].Reference112Comparisons = 11
			case "金融未完了":
				bad.Results[0].PendingQuantity = 1
			case "欠落場":
				bad.Results = bad.Results[:53]
			case "前証拠差":
				bad.Before = map[string]string{}
			case "元Event差":
				bad.Results[0].Golden.EventsEqual = false
			case "Native差":
				bad.Results[0].Native.SHA256 = "別Native"
			}
			if validatePrior54(bad, condition, p) == nil {
				t.Fatal("未完了を再用")
			}
		})
	}
}

// TestMetadataCurrentExeGate は停止と条件を別ファイルへ揃えても実行中exe差を拒否します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。Go実市場処理を呼びません。
func TestMetadataCurrentExeGate(t *testing.T) {
	_, f := metadataFixture(t)
	var stop RuntimeStop
	if err := readRef(f.RuntimeStop, &stop); err != nil {
		t.Fatal(err)
	}
	fake, err := SaveNew(filepath.Join(t.TempDir(), "別実行物.json"), map[string]bool{"人工": true}, false)
	if err != nil {
		t.Fatal(err)
	}
	delete(f.CodeSHA256, f.RuntimeStop.Path)
	f.Executable = fake
	stop.Executable = fake
	f.RuntimeStop, err = SaveNew(filepath.Join(t.TempDir(), "別停止.json"), stop, false)
	if err != nil {
		t.Fatal(err)
	}
	f.CodeSHA256[f.RuntimeStop.Path] = f.RuntimeStop.SHA256
	if err := verifyRuntime(f, map[string]string{}); err == nil {
		t.Fatal("実行中exe不一致を受理")
	}
}

// TestCheckReplayRejectsFinancialAndClockChanges は手製の正当20と破壊条件を検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。利益率による条件選別は行いません。
func TestCheckReplayRejectsFinancialAndClockChanges(t *testing.T) {
	current := handReplay(t, 1, 0)
	f := Fixed{ActualConfigurations: actor.DeclaredContinuousConfigurations(), ShortDefinition: short.DeclaredDefinition()}
	if err := CheckReplay(current, f); err != nil {
		t.Fatal(err)
	}
	for _, mode := range []string{"残量", "別版", "新規時計", "20欠落"} {
		bad := copyValue(current)
		switch mode {
		case "残量":
			b := bad.Actual.Books["P100_C0_D0"]
			b.Totals.OpenBuy = 1
			bad.Actual.Books[b.Key] = b
		case "別版":
			bad.Source.Trial = 117
		case "新規時計":
			n := 300
			bad.Actual.EntryGridSeconds = &n
		case "20欠落":
			delete(bad.Actual.Books, "S0_C0_D0")
		}
		if CheckReplay(bad, f) == nil {
			t.Fatal(mode, "破壊を受理")
		}
	}
	// ----------------------------------------
	// 保存のJSON経路を通しても117版・源111版の区別を保持します。
	raw, _ := json.Marshal(current)
	var copied ReplayResult
	if err := json.Unmarshal(raw, &copied); err != nil || copied.Trial != 117 || copied.Source.Trial != 111 {
		t.Fatal(err)
	}
}
