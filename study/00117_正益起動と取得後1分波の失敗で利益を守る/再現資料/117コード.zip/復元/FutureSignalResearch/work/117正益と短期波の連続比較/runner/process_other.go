//go:build !windows

package parallel117

import "os/exec"

// configureProcess はWindows以外では既存の子起動設定を保ちます。
//
// 引数: cmd(*exec.Cmd)は起動直前の独立workerです。
// 返り値: なし。表示窓を持たない通常のexecを使います。
func configureProcess(cmd *exec.Cmd) {}
