package main

import (
	"encoding/json"
	"os"

	actor "github.com/masayoshi4649/SessionTradeExecuter/continuousactor117"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor117"
	short "github.com/masayoshi4649/SessionTradeExecuter/shortwave117"
)

// main は実APIの20口座・五政策・二H0・短期定義だけを出力します。
//
// 引数: なし。返り値: なし。原板・Native・CSVは開きません。
func main() {
	e, _ := guard.H0DefinitionFor(guard.H0E)
	m, _ := guard.H0DefinitionFor(guard.H0M)
	v := map[string]any{"version": 117, "actor": actor.DeclaredContinuousConfigurations(), "pure": map[string]any{"version": 117, "definitions": guard.DeclaredDefinitions(), "configurations": guard.DeclaredConfigurations(), "h0_definitions": []guard.H0Definition{e, m}}, "h0_definitions": map[guard.Policy]guard.H0Definition{guard.H0E: e, guard.H0M: m}, "short": short.DeclaredDefinition()}
	enc := json.NewEncoder(os.Stdout)
	enc.SetIndent("", "  ")
	enc.SetEscapeHTML(false)
	if err := enc.Encode(v); err != nil {
		panic(err)
	}
}
