"""117の原行接続と並列CLIを人工・実宣言・コード閉包で検査し、Rootだけが停止する。"""
from datetime import datetime, timezone
from pathlib import Path
import argparse
import ast
import hashlib
import json
import os
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
BASE = {
    "source": ("111元時計の連続再現/停止.json", "08b1331b372d5cd7e50d46d90c247a8fa9c6a9bf657105ff181928041f156946"),
    "chart": ("111連続保護のチャート公開/停止.json", "38c01e07d276310c6c1d803dca11e27979fc9286cf64d9a495e60485ea7264bd"),
    "core112": ("112支持否定と通常幅の連続比較/停止.json", "42782f38f7767b9763b04983ace2e5e7fa134bb579f816e0d215d6901d70369d"),
    "fast112": ("113高速コピーの自然対照準備/core/停止.json", "5675b2b3d5956490199c8482627c5bb0aea8084850eb0ed62a0f13938b1cd0f0"),
}
OWNED = ("runtime.go", "runtime_test.go", "short_test.go", "source_fixture_test.go", "fixed.go", "fixed_test.go",
         "runner/parallel.go", "runner/parallel_test.go", "runner/process_windows.go", "runner/process_other.go",
         "cmd/run/main.go", "cmd/declaration/main.go", "go.mod", "go.sum", "README.md", "派生する.py",
         "派生の参照.json", Path(__file__).name)
CODE_FIELDS = ("所有コードSHA256", "全固定コードSHA256", "Go閉包SHA256", "GoRootコードSHA256",
               "再用コードSHA256", "実Go依存SHA256", "実Go依存コードSHA256")


def digest(path: Path) -> str:
    """
    機能: 指定コード又は小metadata/人工の全bytes指紋を計算する。
    引数: path(Path)は対象。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ref(path: Path) -> dict:
    """
    機能: 明示されたファイルを絶対FileRefへ変換する。
    引数: path(Path)は対象。返り値: dictはpath/sha256。
    """
    return {"path": str(path.resolve()), "sha256": digest(path)}


def read(reference: dict) -> object:
    """
    機能: SHAを認証した小metadata又は人工宣言JSONだけを読む。
    引数: reference(dict)は明示Ref。返り値: objectはJSON値。
    """
    path = Path(reference["path"])
    if digest(path) != reference["sha256"]:
        raise ValueError("小参照のSHA差:" + str(path))
    return json.loads(path.read_text(encoding="utf-8-sig"))


def merge(target: dict, values: dict) -> None:
    """
    機能: 固定コードだけを絶対化して現物一致・衝突を検査する。
    引数: target/values(dict)は統合先とコードmap。返り値: None。
    """
    for name, sha in values.items():
        path = Path(name)
        path = (path if path.is_absolute() else ROOT / path).resolve()
        if digest(path) != sha or (str(path) in target and target[str(path)] != sha):
            raise ValueError("固定コードの差:" + str(path))
        target[str(path)] = sha


def run(command: list[str], env: dict) -> dict:
    """
    機能: 人工・閉包・宣言・API・buildだけを実行し不成功を拒否する。
    引数: command(list[str])/env(dict)は実行列と環境。返り値: dictは成功ログ。
    """
    done = subprocess.run(command, cwd=HERE, env=env, capture_output=True, text=True,
                          encoding="utf-8", timeout=60)
    out = {"command": command, "exit_code": done.returncode, "stdout": done.stdout, "stderr": done.stderr}
    if done.returncode:
        raise ValueError(json.dumps(out, ensure_ascii=False))
    return out


def closure(env: dict) -> tuple[dict, dict]:
    """
    機能: 金融CLIの実選択GoソースをGoRootとそれ以外に分類する。
    引数: env(dict)はGo環境。返り値: tuple[dict,dict]はローカルと環境のSHAmap。
    """
    raw = run(["go", "list", "-deps", "-json", "./cmd/run"], env)["stdout"]
    decoder, position, local, standard = json.JSONDecoder(), 0, {}, {}
    while raw[position:].strip():
        position += len(raw[position:]) - len(raw[position:].lstrip())
        package, position = decoder.raw_decode(raw, position)
        if not package.get("Dir"):
            continue
        target = standard if package.get("Goroot") else local
        for field in ("GoFiles", "CgoFiles", "SFiles", "HFiles", "SysoFiles", "EmbedFiles"):
            for name in package.get(field, []):
                path = (Path(package["Dir"]) / name).resolve()
                target[str(path)] = digest(path)
        module = package.get("Module") or {}
        for item in (module, module.get("Replace") or {}):
            if item.get("GoMod"):
                path = Path(item["GoMod"]).resolve()
                local[str(path)] = digest(path)
                if path.with_name("go.sum").exists():
                    local[str(path.with_name("go.sum"))] = digest(path.with_name("go.sum"))
    compiler = Path(shutil.which("go")).resolve()
    standard[str(compiler)] = digest(compiler)
    return local, standard


def write_new(path: Path, value: object) -> None:
    """
    機能: 未作成先だけへ日本語UTF-8/LF JSONを保存する。
    引数: path(Path)/value(object)は新規先と値。返り値: None。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def authenticate_stop(reference: dict, before: dict) -> dict:
    """
    機能: 依存停止と実コードmapを本文市場読取なしで認証する。
    引数: reference(dict)/before(dict)は停止と台帳。返り値: dictは停止metadata。
    """
    value = read(reference)
    if value.get("成功") is not True or value.get("停止") is not True:
        raise ValueError("未停止依存を拒否")
    merge(before, {reference["path"]: reference["sha256"]})
    for field in CODE_FIELDS:
        merge(before, value.get(field, {}))
    return value


def declaration_from_stop(stop: dict, expected: object) -> dict:
    """
    機能: 停止が明示した実宣言Refを実関数値へ結合する。
    引数: stop(dict)/expected(object)は停止と期待宣言。返り値: dictは同体な宣言Ref。
    """
    for key in ("実20宣言", "実宣言", "実定義", "宣言設定", "実Actor宣言"):
        candidate = stop.get(key)
        if not isinstance(candidate, dict) or not all(k in candidate for k in ("path", "sha256")):
            continue
        actual = read(candidate)
        equal = actual == expected
        if isinstance(expected, dict) and isinstance(actual, dict):
            equal = all(actual.get(k) == v for k, v in expected.items())
        if equal:
            return {"path": candidate["path"], "sha256": candidate["sha256"]}
    raise ValueError("停止内の実関数同体宣言がない")


def main() -> None:
    """
    機能: 117Core人工証拠と未固定素材、又はRootレビュー後の停止を新規保存する。
    引数: CLI --output/--proof-only又は--reviewed、新3部品の--actor/pure/short-stopと各-sha。
    返り値: None。市場・Raw・Native・CSVの自然本文を開かない。
    """
    parser = argparse.ArgumentParser()
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument("--proof-only", action="store_true")
    modes.add_argument("--reviewed", action="store_true")
    parser.add_argument("--output", type=Path, required=True)
    for name in ("actor", "pure", "short"):
        parser.add_argument("--" + name + "-stop", type=Path)
        parser.add_argument("--" + name + "-sha")
    args = parser.parse_args()
    output, stop_path = args.output.resolve(), HERE / "停止.json"
    if output.exists() or (args.reviewed and stop_path.exists()):
        raise ValueError("出力と停止は未作成先のみ")
    new_refs = {}
    for label, key in (("actor", "actor"), ("pure", "pure"), ("short", "shortwave")):
        path, sha = getattr(args, label + "_stop"), getattr(args, label + "_sha")
        if bool(path) != bool(sha):
            raise ValueError("依存停止のpath/SHA両方が必要")
        if path:
            new_refs[key] = {"path": str(path.resolve()), "sha256": sha}
    if (args.reviewed or new_refs) and len(new_refs) != 3:
        raise ValueError("新Actor/Pure/Shortwave三停止を揃える")
    env = dict(os.environ, CGO_ENABLED="0", GOWORK="off", GOTOOLCHAIN="local")
    if run(["go", "version"], env)["stdout"].strip() != "go version go1.24.2 windows/amd64":
        raise ValueError("Go1.24.2 windows/amd64が必要")
    inherited, dependencies, stops = {}, {}, {}
    for key, (name, sha) in BASE.items():
        dependencies[key] = {"path": str((ROOT / "work" / name).resolve()), "sha256": sha}
    dependencies.update(new_refs)
    for key, reference in dependencies.items():
        stops[key] = authenticate_stop(reference, inherited)
    owned = {str((HERE / name).resolve()): digest(HERE / name) for name in OWNED}
    for name in OWNED:
        if name.endswith(".py"):
            for node in ast.walk(ast.parse((HERE / name).read_text(encoding="utf-8-sig"))):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    doc = ast.get_docstring(node) or ""
                    if "\n" not in doc or any(k not in doc for k in ("機能", "引数", "返り値")):
                        raise ValueError("関数コメント差:" + node.name)
    local, standard = closure(env)
    full = dict(inherited)
    for values in (owned, local, standard):
        merge(full, values)
    output.mkdir(parents=True)
    artificial_env = dict(env, CORE117_ART_OUT=str(output / "人工_金融"), PARALLEL117_ART_OUT=str(output / "人工_I_O"))
    logs = [run(["go", "test", "-count=1", "-json", "./..."], artificial_env),
            run(["go", "vet", "./..."], env),
            run(["go", "build", "-o", str(output / "117連続比較.exe"), "./cmd/run"], env),
            run(["go", "run", "./cmd/declaration"], env), run(["go", "doc", "-all", "."], env)]
    passed = [(event["Package"], event["Test"]) for line in logs[0]["stdout"].splitlines() if line.startswith("{")
              for event in [json.loads(line)] if event.get("Action") == "pass" and "Test" in event and "/" not in event["Test"]]
    names = {name for _, name in passed}
    if not {"TestHandNonzeroAndMirrors", "TestShortWaveCoreMirror", "TestShortGapAndClosedOnce", "TestMetadataGateWithoutNative",
            "TestPrior54GateAndNativeFingerprints", "TestPoolParallelismAndPlannedOrder", "TestPoolFull70Reuses54", "TestExportArtificial"}.issubset(names):
        raise ValueError("必須の金融/短期/metadata/並列人工が不足")
    actual = json.loads(logs[3]["stdout"])
    if actual["version"] != 117 or len(actual["actor"]) != 20 or len(actual["pure"]["configurations"]) != 20 or len(actual["pure"]["definitions"]) != 5:
        raise ValueError("117の実20/五定義差")
    refs = {}
    for label, value in (("actor", actual["actor"]), ("pure", actual["pure"]), ("shortwave", actual["short"])):
        path = output / (label + "_実関数宣言.json")
        write_new(path, value)
        refs[label] = declaration_from_stop(stops[label], value) if label in new_refs else ref(path)
        merge(full, {refs[label]["path"]: refs[label]["sha256"]})
    chart_ref = stops["chart"]["実API宣言"]
    merge(full, {chart_ref["path"]: chart_ref["sha256"]})
    copy_ref = {"path": str((ROOT / "work/113進行/高速コピーの自然2場対照.json").resolve()),
                "sha256": "6ea49e767982a994d8fd2f5053133ef2070b348d2a344d5a6be8b2a9dd3ec861"}
    read(copy_ref)
    merge(full, {copy_ref["path"]: copy_ref["sha256"]})
    # ----------------------------------------
    # 元112正式の実folder名は固定条件の所在からだけ決め、金融Native本文は開かない。
    condition_paths = [p for p in (ROOT / "study").glob("00112_*/検査/condition.json")]
    if len(condition_paths) != 1:
        raise ValueError("旧112正式条件の所在が一意でない")
    old_ref = ref(condition_paths[0])
    if old_ref["sha256"] != "893fa4dbaa0525f0f37579e750a46d5e846a9dbc83bf4b816e16e97e4527ad69":
        raise ValueError("旧112条件の指定SHA差")
    old = read(old_ref)
    trial112 = condition_paths[0].parents[1]
    reference112 = {"condition": old_ref,
                    "market": {"path": str(trial112 / "検査/market.json"), "sha256": "0bf84f14196632787ba7d520a21bf30cc723a185fe3300599f6533e420149cf9"},
                    "native_catalog": {"path": str(trial112 / "成果物_金融/Native参照台帳.json"), "sha256": "8f156a252ad9f53951c0feba87424a46112e939276490b510261b491a581811d"}}
    for reference in reference112.values():
        read(reference)
    after = {path: digest(Path(path)) for path in full}
    if full != after:
        raise ValueError("旧依存/所有/実Go閉包の前後差")
    executable = ref(output / "117連続比較.exe")
    artificial_ref = ref(output / "人工_金融/人工.json")
    io_ref = ref(output / "人工_I_O/完了.json")
    with (output / "API.txt").open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(logs[4]["stdout"])
    proof = {"成功": True, "停止": args.reviewed, "市場前": True, "試行": 117, "trial": 117,
             "UTC": datetime.now(timezone.utc).isoformat(), "所有コードSHA256": owned,
             "再用コードSHA256": inherited, "Go閉包SHA256": local, "GoRootコードSHA256": standard,
             "全固定コードSHA256": full, "コードSHA256前": full, "コードSHA256後": after, "前後不変": True,
             "依存停止": dependencies, "新三部品停止受領": len(new_refs) == 3,
             "実行物": executable, "高速コピー同体証拠": copy_ref,
             "実20宣言": refs["actor"], "純実定義": refs["pure"], "短期実定義": refs["shortwave"],
             "金融人工": artificial_ref, "並列人工": io_ref, "実API": ref(output / "API.txt"),
             "成功主test数": len(passed), "成功主test": passed, "検査ログ": logs,
             "市場/Raw/Native/価格CSV/損益CSV/11月09本文読取": 0,
             "金融市場実行": False, "既停止変更": False, "Rootレビュー後": args.reviewed}
    destination = stop_path if args.reviewed else output / "停止前の確認.json"
    write_new(destination, proof)
    if args.reviewed:
        full = dict(full)
        full[str(stop_path)] = digest(stop_path)
    material = {"version": 1, "trial": 117, "fixed": False,
                "policy": "original166_source111_positive_costfloor_shortwave117", "source_trial": 111,
                "FAR_commit": old["FAR_commit"], "strategy_commit": old["strategy_commit"],
                "manifest": old["manifest"], "executable": executable, "code_sha256": full,
                "original166_references": old["original166_references"],
                "runtime_stop": ref(stop_path) if args.reviewed else {"path": "", "sha256": ""},
                "dependency_stops": dependencies, "actual_policy": "positive_costfloor_shortwave117",
                "chart_seed_mode": "cold_each_session", "entry_grid_seconds": None, "extra_opening_quiet_seconds": 0,
                "actual_configurations": actual["actor"], "pure_configurations": actual["pure"]["configurations"],
                "policy_definitions": actual["pure"]["definitions"], "h0_definitions": actual["h0_definitions"],
                "short_definition": actual["short"], "actual_declaration": refs["actor"],
                "pure_declaration": refs["pure"], "short_declaration": refs["shortwave"],
                "chart_declaration": chart_ref, "reference112": reference112,
                "copy_basis": copy_ref, "parallel_method": "isolated_session_process117_v1", "parallel_max_workers": 16}
    write_new(output / "条件の素材.json", material)
    print(json.dumps({"成功": True, "停止": args.reviewed, "確認": ref(destination),
                      "素材": ref(output / "条件の素材.json"), "実行物": executable}, ensure_ascii=False))


if __name__ == "__main__":
    main()
