package shortcomparison117

import (
	"compress/gzip"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"runtime"
	"sort"
	"strings"

	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	actor "github.com/masayoshi4649/SessionTradeExecuter/continuousactor117"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor117"
	short "github.com/masayoshi4649/SessionTradeExecuter/shortwave117"
	legacyCore "github.com/masayoshi4649/SessionTradeExecuter/supportcomparison112"
)

const Policy = "original166_source111_positive_costfloor_shortwave117"
const ActualPolicy = "positive_costfloor_shortwave117"
const ParallelMethod = "isolated_session_process117_v1"

// References112 は固定済み112の金融条件・成功・正式Native索引の由来です。
type References112 struct {
	Condition     source.FileRef `json:"condition"`
	Market        source.FileRef `json:"market"`
	NativeCatalog source.FileRef `json:"native_catalog"`
}

// Fixed は111へ偽装せず117としてRootが事前固定する条件です。
type Fixed struct {
	Version                  int                                 `json:"version"`
	Trial                    int                                 `json:"trial"`
	Fixed                    bool                                `json:"fixed"`
	Policy                   string                              `json:"policy"`
	SourceTrial              int                                 `json:"source_trial"`
	FARCommit                string                              `json:"FAR_commit"`
	StrategyCommit           string                              `json:"strategy_commit"`
	Manifest                 source.FileRef                      `json:"manifest"`
	Executable               source.FileRef                      `json:"executable"`
	CodeSHA256               map[string]string                   `json:"code_sha256"`
	Golden                   map[string]source.FileRef           `json:"original166_references"`
	RuntimeStop              source.FileRef                      `json:"runtime_stop"`
	DependencyStops          map[string]source.FileRef           `json:"dependency_stops"`
	ActualPolicy             string                              `json:"actual_policy"`
	ChartSeedMode            string                              `json:"chart_seed_mode"`
	EntryGridSeconds         *int                                `json:"entry_grid_seconds"`
	ExtraOpeningQuietSeconds int                                 `json:"extra_opening_quiet_seconds"`
	ActualConfigurations     []actor.ActorConfig                 `json:"actual_configurations"`
	PureConfigurations       []guard.Configuration               `json:"pure_configurations"`
	Definitions              []guard.Definition                  `json:"policy_definitions"`
	H0Definitions            map[guard.Policy]guard.H0Definition `json:"h0_definitions"`
	ShortDefinition          short.Definition                    `json:"short_definition"`
	ActualDeclaration        source.FileRef                      `json:"actual_declaration"`
	PureDeclaration          source.FileRef                      `json:"pure_declaration"`
	ChartDeclaration         source.FileRef                      `json:"chart_declaration"`
	ShortDeclaration         source.FileRef                      `json:"short_declaration"`
	Reference112             References112                       `json:"reference112"`
	CopyBasis                source.FileRef                      `json:"copy_basis"`
	ParallelMethod           string                              `json:"parallel_method"`
	ParallelMaxWorkers       int                                 `json:"parallel_max_workers"`
}

// SceneResult は当場の20金融・原文Event・旧112の12対照を別に記録します。
type SceneResult struct {
	Session                 string              `json:"session"`
	Native                  source.FileRef      `json:"native"`
	Golden                  *source.GoldenProof `json:"original166_reference,omitempty"`
	Books                   int                 `json:"books"`
	S0Comparisons           int                 `json:"S0_comparisons"`
	S0Equal                 bool                `json:"S0_equal"`
	Complete                bool                `json:"complete"`
	OpenQuantity            int                 `json:"open_quantity"`
	PendingQuantity         int                 `json:"pending_quantity"`
	Reference112            source.FileRef      `json:"reference112"`
	Reference112Comparisons int                 `json:"reference112_comparisons"`
	Reference112Equal       bool                `json:"reference112_equal"`
	Source111Equal          bool                `json:"source111_equal"`
}

// Completion は117の全段階の成功と同条件54参照再用を結びます。
type Completion struct {
	Version                    int               `json:"version"`
	Trial                      int               `json:"trial"`
	Stage                      string            `json:"stage"`
	Success                    bool              `json:"success"`
	ConditionSHA256            string            `json:"condition_sha256"`
	Sessions                   int               `json:"sessions"`
	ReusedSessions             int               `json:"reused_sessions"`
	ReplayedSessions           int               `json:"replayed_sessions"`
	Books                      int               `json:"books"`
	OriginalMethods            int               `json:"original_methods"`
	AllReferenceEventsEqual    bool              `json:"all_original166_reference_events_equal"`
	HistoricalSavedEventsEqual bool              `json:"historical_saved_events_equal"`
	AllSignalFullJSONEqual     bool              `json:"all_original_signal_full_json_equal"`
	Reference112Comparisons    int               `json:"reference112_comparisons"`
	AllReference112Equal       bool              `json:"all_reference112_equal"`
	AllSource111Equal          bool              `json:"all_source111_equal"`
	Results                    []SceneResult     `json:"results"`
	Before                     map[string]string `json:"before"`
	After                      map[string]string `json:"after"`
	Unchanged                  bool              `json:"unchanged"`
	Prior54                    *source.FileRef   `json:"prior54,omitempty"`
}

// RunPlan は117外ゲートが認証した入力計画です。Sourceの111ゲートは呼びません。
type RunPlan struct {
	Source        source.RunPlan
	Fixed         Fixed
	Stage         string
	Prior54       *Completion
	LegacyNatives map[string]source.FileRef
}

// RuntimeStop は金融部品と接続CLIの市場前停止をRoot条件へ渡します。
type RuntimeStop struct {
	Success      bool                      `json:"成功"`
	Stopped      bool                      `json:"停止"`
	Trial        int                       `json:"trial"`
	Owned        map[string]string         `json:"所有コードSHA256"`
	AllCode      map[string]string         `json:"全固定コードSHA256"`
	Executable   source.FileRef            `json:"実行物"`
	Dependencies map[string]source.FileRef `json:"依存停止"`
	CopyBasis    source.FileRef            `json:"高速コピー同体証拠"`
}

// Directory は117接続のビルド元を返します。
//
// 引数: なし。
// 返り値: string/errorは絶対module位置又は不明です。
func Directory() (string, error) {
	_, file, _, ok := runtime.Caller(0)
	if !ok {
		return "", fmt.Errorf("117ビルド元不明")
	}
	return filepath.Dir(file), nil
}

// readRef は絶対参照をSHA認証して小JSONだけを復元します。
//
// 引数: ref(source.FileRef)、value(any)は期待参照と復元先です。
// 返り値: errorは指紋又はJSONの差です。
func readRef(ref source.FileRef, value any) error {
	if err := source.VerifyRef(ref); err != nil {
		return err
	}
	raw, err := os.ReadFile(ref.Path)
	if err != nil {
		return err
	}
	return json.Unmarshal(raw, value)
}

// BasisStops は変更しないSource/Chartと112基準部品の絶対参照を返します。
//
// 引数: なし。
// 返り値: map[string]source.FileRef/errorは4旧停止又は位置不明です。
func BasisStops() (map[string]source.FileRef, error) {
	base, err := Directory()
	if err != nil {
		return nil, err
	}
	out := map[string]source.FileRef{}
	for key, pair := range map[string][2]string{
		"source":  {"111元時計の連続再現", "08b1331b372d5cd7e50d46d90c247a8fa9c6a9bf657105ff181928041f156946"},
		"chart":   {"111連続保護のチャート公開", "38c01e07d276310c6c1d803dca11e27979fc9286cf64d9a495e60485ea7264bd"},
		"core112": {"112支持否定と通常幅の連続比較", "42782f38f7767b9763b04983ace2e5e7fa134bb579f816e0d215d6901d70369d"},
		"fast112": {"113高速コピーの自然対照準備/core", "5675b2b3d5956490199c8482627c5bb0aea8084850eb0ed62a0f13938b1cd0f0"},
	} {
		out[key] = source.FileRef{Path: filepath.Clean(filepath.Join(base, "..", pair[0], "停止.json")), SHA256: pair[1]}
	}
	return out, nil
}

// RequiredCodePaths は117実cmdの選択コード閉包を入力本文なしで取得します。
//
// 引数: なし。
// 返り値: []string/errorはGo/asm/embed/module/GoRootの絶対位置です。
func RequiredCodePaths() ([]string, error) {
	base, err := Directory()
	if err != nil {
		return nil, err
	}
	cmd := exec.Command("go", "list", "-deps", "-json", "./cmd/run")
	cmd.Dir = base
	cmd.Env = append(os.Environ(), "GOWORK=off", "CGO_ENABLED=0")
	raw, err := cmd.Output()
	if err != nil {
		return nil, err
	}
	decoder := json.NewDecoder(strings.NewReader(string(raw)))
	paths := map[string]bool{}
	for {
		var p struct {
			Dir                                                      string
			GoFiles, CgoFiles, SFiles, HFiles, SysoFiles, EmbedFiles []string
			Module                                                   *struct{ GoMod string }
		}
		err = decoder.Decode(&p)
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
		if p.Dir == "" {
			continue
		}
		for _, names := range [][]string{p.GoFiles, p.CgoFiles, p.SFiles, p.HFiles, p.SysoFiles, p.EmbedFiles} {
			for _, name := range names {
				paths[filepath.Clean(filepath.Join(p.Dir, name))] = true
			}
		}
		if p.Module != nil && p.Module.GoMod != "" {
			paths[filepath.Clean(p.Module.GoMod)] = true
			sum := filepath.Join(filepath.Dir(p.Module.GoMod), "go.sum")
			if _, e := os.Stat(sum); e == nil {
				paths[sum] = true
			}
		}
	}
	out := []string{}
	for path := range paths {
		out = append(out, path)
	}
	sort.Strings(out)
	return out, nil
}

// verifyRuntime は117宣言・全閉包・親子実行物を本文前に認証します。
//
// 引数: f(Fixed)、before(map[string]string)はRoot条件と前指紋です。
// 返り値: errorは停止・宣言・実行物・閉包の差です。
func verifyRuntime(f Fixed, before map[string]string) error {
	var stop RuntimeStop
	if err := readRef(f.RuntimeStop, &stop); err != nil {
		return err
	}
	if !stop.Success || !stop.Stopped || stop.Trial != 117 || stop.Executable != f.Executable || stop.CopyBasis != f.CopyBasis || !reflect.DeepEqual(stop.Dependencies, f.DependencyStops) {
		return fmt.Errorf("117接続の市場前停止/依存/実行物差")
	}
	basis, err := BasisStops()
	if err != nil {
		return err
	}
	if len(f.DependencyStops) != 7 {
		return fmt.Errorf("117の7部品停止が必要")
	}
	for _, key := range []string{"actor", "pure", "shortwave"} {
		if f.DependencyStops[key].Path == "" {
			return fmt.Errorf("117新部品停止の欠落:%s", key)
		}
	}
	for key, ref := range basis {
		if f.DependencyStops[key] != ref {
			return fmt.Errorf("旧112停止の差:%s", key)
		}
	}
	for key, ref := range f.DependencyStops {
		var status map[string]json.RawMessage
		if err = readRef(ref, &status); err != nil {
			return err
		}
		var success, stopped bool
		if json.Unmarshal(status["成功"], &success) != nil || json.Unmarshal(status["停止"], &stopped) != nil || !success || !stopped {
			return fmt.Errorf("部品の停止不足:%s", key)
		}
		before[ref.Path] = ref.SHA256
	}
	expected := map[string]string{}
	for _, codes := range []map[string]string{stop.AllCode, stop.Owned} {
		for path, sha := range codes {
			if old, ok := expected[path]; ok && old != sha {
				return fmt.Errorf("117停止codeの衝突")
			}
			expected[path] = sha
		}
	}
	expected[f.RuntimeStop.Path] = f.RuntimeStop.SHA256
	if f.CopyBasis.SHA256 != "6ea49e767982a994d8fd2f5053133ef2070b348d2a344d5a6be8b2a9dd3ec861" || expected[f.CopyBasis.Path] != f.CopyBasis.SHA256 {
		return fmt.Errorf("117の基礎とする高速自然2場同体の指定差")
	}
	var copyProof struct {
		Success   bool `json:"成功"`
		Trial     int  `json:"金融定義試行"`
		F1Changed bool `json:"市場条件F1変更"`
		Sessions  int  `json:"場数"`
		Books     int  `json:"口座"`
		Equal     bool `json:"全JSON/Source/全保存時点同体"`
		FullTick  bool `json:"全tick独立監査"`
	}
	if err = readRef(f.CopyBasis, &copyProof); err != nil || !copyProof.Success || copyProof.Trial != 112 || copyProof.F1Changed || copyProof.Sessions != 2 || copyProof.Books != 48 || !copyProof.Equal || copyProof.FullTick {
		return fmt.Errorf("高速コピーの自然対照の証明範囲差:%v", err)
	}
	if !reflect.DeepEqual(expected, f.CodeSHA256) {
		return fmt.Errorf("117停止の全閉包とRoot固定map差")
	}
	for path, sha := range expected {
		if err = source.VerifyRef(source.FileRef{Path: path, SHA256: sha}); err != nil {
			return err
		}
		before[path] = sha
	}
	paths, err := RequiredCodePaths()
	if err != nil {
		return err
	}
	for _, path := range paths {
		if _, ok := expected[path]; !ok {
			return fmt.Errorf("117実Go閉包の固定漏れ:%s", path)
		}
	}
	exe, err := os.Executable()
	if err != nil {
		return err
	}
	actual, err := source.Digest(exe)
	if err != nil || actual != f.Executable.SHA256 {
		return fmt.Errorf("117実行中exeのSHA差")
	}
	if err = source.VerifyRef(f.Executable); err != nil {
		return err
	}
	before[f.Executable.Path] = f.Executable.SHA256
	for _, ref := range []source.FileRef{f.ActualDeclaration, f.PureDeclaration, f.ChartDeclaration, f.ShortDeclaration} {
		if err = source.VerifyRef(ref); err != nil {
			return err
		}
		if expected[ref.Path] != ref.SHA256 {
			return fmt.Errorf("実宣言が全固定閉包にない")
		}
	}
	var declaredActual []actor.ActorConfig
	if err = readRef(f.ActualDeclaration, &declaredActual); err != nil || !reflect.DeepEqual(declaredActual, f.ActualConfigurations) {
		return fmt.Errorf("117 Actor実宣言と固定20差:%v", err)
	}
	var pure struct {
		Configurations []guard.Configuration `json:"configurations"`
		Definitions    []guard.Definition    `json:"definitions"`
		Version        int                   `json:"version"`
		H0Definitions  []guard.H0Definition  `json:"h0_definitions"`
	}
	h0e, _ := guard.H0DefinitionFor(guard.H0E)
	h0m, _ := guard.H0DefinitionFor(guard.H0M)
	if err = readRef(f.PureDeclaration, &pure); err != nil || pure.Version != 117 || !reflect.DeepEqual(pure.Configurations, f.PureConfigurations) || !reflect.DeepEqual(pure.Definitions, f.Definitions) || !reflect.DeepEqual(pure.H0Definitions, []guard.H0Definition{h0e, h0m}) {
		return fmt.Errorf("117純保護実宣言と固定20/5定義差:%v", err)
	}
	var shortDeclaration short.Definition
	if err = readRef(f.ShortDeclaration, &shortDeclaration); err != nil || !reflect.DeepEqual(shortDeclaration, f.ShortDefinition) {
		return fmt.Errorf("117短期実定義と固定条件差:%v", err)
	}
	return nil
}

// reference112 は旧正式索引のmetadataだけを結び、旧Native本文は読みません。
//
// 引数: f(Fixed)、manifest(source.InputManifest)、before(map[string]string)は新固定・入力・前指紋です。
// 返り値: map[string]source.FileRef/errorは旧70Nativeの期待参照又は由来差です。
func reference112(f Fixed, manifest source.InputManifest, before map[string]string) (map[string]source.FileRef, error) {
	if f.Reference112.Condition.SHA256 != "893fa4dbaa0525f0f37579e750a46d5e846a9dbc83bf4b816e16e97e4527ad69" ||
		f.Reference112.Market.SHA256 != "0bf84f14196632787ba7d520a21bf30cc723a185fe3300599f6533e420149cf9" {
		return nil, fmt.Errorf("112の指定済み正式条件/全70成功の指紋差")
	}
	var old source.Fixed
	var market legacyCore.Completion
	if err := readRef(f.Reference112.Condition, &old); err != nil {
		return nil, err
	}
	if err := readRef(f.Reference112.Market, &market); err != nil {
		return nil, err
	}
	if old.Version != 1 || old.Trial != 112 || !old.Fixed || old.Policy != legacyCore.Policy ||
		old.StrategyCommit != f.StrategyCommit || old.FARCommit != f.FARCommit || old.Manifest.SHA256 != f.Manifest.SHA256 ||
		!market.Success || market.Trial != 112 || market.Stage != "full70" || market.ConditionSHA256 != f.Reference112.Condition.SHA256 ||
		market.Sessions != 70 || market.Books != 1680 || !market.Unchanged || !reflect.DeepEqual(market.Before, market.After) || len(market.Results) != 70 ||
		!market.AllReferenceEventsEqual || market.HistoricalSavedEventsEqual || market.AllSignalFullJSONEqual {
		return nil, fmt.Errorf("旧112の同Source/入力/全70成功参照が必要")
	}
	for _, ref := range []source.FileRef{f.Reference112.Condition, f.Reference112.Market, f.Reference112.NativeCatalog} {
		before[ref.Path] = ref.SHA256
	}
	var catalog struct {
		Trial    int  `json:"試行"`
		Success  bool `json:"成功"`
		Sessions int  `json:"場数"`
		Books    int  `json:"会計数"`
		Native   []struct {
			Session  string         `json:"session"`
			Relative string         `json:"relative"`
			SHA256   string         `json:"sha256"`
			Origin   source.FileRef `json:"origin"`
		} `json:"Native"`
	}
	if err := readRef(f.Reference112.NativeCatalog, &catalog); err != nil {
		return nil, err
	}
	if catalog.Trial != 112 || !catalog.Success || catalog.Sessions != 70 || catalog.Books != 1680 || len(catalog.Native) != 70 {
		return nil, fmt.Errorf("112正式Native索引70が必要")
	}
	trialRoot := filepath.Dir(filepath.Dir(f.Reference112.NativeCatalog.Path))
	natives := map[string]source.FileRef{}
	for i, row := range catalog.Native {
		sid := manifest.Sessions[i].ID
		expected := filepath.ToSlash(filepath.Join("成果物_金融", "Native", sid+".Native.json.gz"))
		if row.Session != sid || row.Relative != expected || market.Results[i].Session != sid || row.Origin != market.Results[i].Native || row.SHA256 != row.Origin.SHA256 {
			return nil, fmt.Errorf("112正式Nativeの同bytes/場順参照差")
		}
		natives[sid] = source.FileRef{Path: filepath.Join(trialRoot, filepath.FromSlash(row.Relative)), SHA256: row.SHA256}
	}
	if len(f.Golden) != 54 || len(old.Golden) != 54 {
		return nil, fmt.Errorf("同Sourceの原文oracle54参照が必要")
	}
	for _, input := range manifest.Sessions[:54] {
		ref, ok := f.Golden[input.ID]
		if !ok || ref.SHA256 != old.Golden[input.ID].SHA256 {
			return nil, fmt.Errorf("元54oracleのsamebytes参照差")
		}
		session, err := source.SessionFor(input.ID)
		if err != nil {
			return nil, err
		}
		if err = source.ValidateGoldenRef(ref, session); err != nil {
			return nil, err
		}
		before[ref.Path] = ref.SHA256
	}
	return natives, nil
}

// PrepareFixed はtrial117の独立外ゲートで70台帳・43戦略・旧12対照を認証します。
//
// 引数: condition(source.FileRef)、stage(string)、prior(*source.FileRef|nil)は117固定・段階・同117元54成功です。
// 返り値: RunPlan/errorは本文未読計画。111へのtrial偽装を行いません。
func PrepareFixed(condition source.FileRef, stage string, prior *source.FileRef) (RunPlan, error) {
	p := RunPlan{Stage: stage, Source: source.RunPlan{Condition: condition, Stage: stage, Before: map[string]string{}}}
	if err := readRef(condition, &p.Fixed); err != nil {
		return p, err
	}
	f := p.Fixed
	if f.Version != 1 || f.Trial != 117 || !f.Fixed || f.Policy != Policy || f.SourceTrial != 111 ||
		f.FARCommit != "cf0717daa1eed78759f78a428bce50129e7f705b" || f.StrategyCommit != "67ba01588a60961ce2fb505ee5654999473dedab" ||
		f.ActualPolicy != ActualPolicy || f.ParallelMethod != ParallelMethod || f.ParallelMaxWorkers != 16 ||
		f.ChartSeedMode != "cold_each_session" || f.EntryGridSeconds != nil || f.ExtraOpeningQuietSeconds != 0 ||
		!reflect.DeepEqual(f.ActualConfigurations, actor.DeclaredContinuousConfigurations()) ||
		!reflect.DeepEqual(f.PureConfigurations, guard.DeclaredConfigurations()) || !reflect.DeepEqual(f.Definitions, guard.DeclaredDefinitions()) || !reflect.DeepEqual(f.H0Definitions, DeclaredH0Definitions()) || !reflect.DeepEqual(f.ShortDefinition, short.DeclaredDefinition()) {
		return p, fmt.Errorf("117のRoot固定/実宣言/定義/原時計が必要")
	}
	var fields map[string]json.RawMessage
	if err := readRef(condition, &fields); err != nil {
		return p, err
	}
	if string(fields["entry_grid_seconds"]) != "null" || fields["extra_opening_quiet_seconds"] == nil {
		return p, fmt.Errorf("新規時計なし/静観0の明示が必要")
	}
	before := p.Source.Before
	before[condition.Path] = condition.SHA256
	if err := verifyRuntime(f, before); err != nil {
		return p, err
	}
	if err := readRef(f.Manifest, &p.Source.Manifest); err != nil {
		return p, err
	}
	before[f.Manifest.Path] = f.Manifest.SHA256
	m := p.Source.Manifest
	if len(m.Sessions) != 70 || len(m.StrategySHA256) != 43 || !filepath.IsAbs(m.Root) || !filepath.IsAbs(m.StrategyRoot) {
		return p, fmt.Errorf("既使用70と純43の絶対台帳が必要")
	}
	if err := source.ValidateManifest(m); err != nil {
		return p, err
	}
	for name, sha := range m.StrategySHA256 {
		before[filepath.Join(m.StrategyRoot, filepath.FromSlash(name))] = sha
	}
	for _, input := range m.Sessions {
		if input.ID < "2026-09-21_Day" || input.ID > "2026-11-06_Night" {
			return p, fmt.Errorf("未使用期間を拒否")
		}
		for _, file := range input.Files {
			clean := filepath.Clean(filepath.FromSlash(file.Path))
			if filepath.IsAbs(clean) || clean == ".." || strings.HasPrefix(clean, ".."+string(filepath.Separator)) {
				return p, fmt.Errorf("入力根外の相対参照を拒否")
			}
		}
	}
	if m.Sessions[0].ID != "2026-09-21_Day" || m.Sessions[53].ID != "2026-10-27_Night" || m.Sessions[69].ID != "2026-11-06_Night" {
		return p, fmt.Errorf("元54/追加16の境界差")
	}
	natives, err := reference112(f, m, before)
	if err != nil {
		return p, err
	}
	p.LegacyNatives = natives
	n := map[string]int{"metadata-only": 70, "first2": 2, "base54": 54, "full70": 70}[stage]
	if n == 0 {
		return p, fmt.Errorf("stageはmetadata-only/first2/base54/full70")
	}
	p.Source.Cases = append([]source.InputCase(nil), m.Sessions[:n]...)
	// ----------------------------------------
	// source.RunPlanは公開入力型の容器だけに使用し、111のPrepareMetadataを呼びません。
	p.Source.Fixed = source.Fixed{Version: f.Version, Trial: f.Trial, Fixed: f.Fixed, Policy: f.Policy, FARCommit: f.FARCommit, StrategyCommit: f.StrategyCommit, Manifest: f.Manifest, Executable: f.Executable, CodeSHA256: f.CodeSHA256, Golden: f.Golden}
	if stage == "full70" {
		if prior == nil {
			return p, fmt.Errorf("同117固定のbase54成功を先に要求")
		}
		var old Completion
		if err = readRef(*prior, &old); err != nil {
			return p, err
		}
		if err = validatePrior54(old, condition, p); err != nil {
			return p, err
		}
		p.Prior54 = &old
		p.Source.Prior54Ref = prior
		before[prior.Path] = prior.SHA256
		for _, row := range old.Results {
			before[row.Native.Path] = row.Native.SHA256
		}
	} else if prior != nil {
		return p, fmt.Errorf("prior54はfull70だけ")
	}
	return p, nil
}

// validatePrior54 は117の同条件・全20・旧12対照・81Event対照・全残0を確認します。
//
// 引数: old(Completion)、condition(source.FileRef)、p(RunPlan)は先行成功と今回計画です。
// 返り値: errorは54成功不足又はNativeSHAの差です。
func validatePrior54(old Completion, condition source.FileRef, p RunPlan) error {
	if old.Version != 1 || old.Trial != 117 || !old.Success || old.Stage != "base54" || old.ConditionSHA256 != condition.SHA256 ||
		old.Sessions != 54 || old.Books != 1080 || old.OriginalMethods != 81 || old.ReusedSessions != 0 || old.ReplayedSessions != 54 ||
		old.Reference112Comparisons != 648 || !old.AllReference112Equal || !old.AllSource111Equal || !old.AllReferenceEventsEqual ||
		old.HistoricalSavedEventsEqual || old.AllSignalFullJSONEqual || !old.Unchanged || len(old.Results) != 54 ||
		!reflect.DeepEqual(old.Before, old.After) || !reflect.DeepEqual(old.Before, p.Source.Before) {
		return fmt.Errorf("同条件の117全base54成功ではない")
	}
	for i, row := range old.Results {
		methods := 1
		if i%2 == 1 {
			methods = 2
		}
		if row.Session != p.Source.Manifest.Sessions[i].ID || row.Books != 20 || row.S0Comparisons != 4 || !row.S0Equal || !row.Complete || row.OpenQuantity != 0 || row.PendingQuantity != 0 ||
			row.Reference112Comparisons != 12 || !row.Reference112Equal || !row.Source111Equal || row.Reference112 != p.LegacyNatives[row.Session] ||
			row.Golden == nil || !row.Golden.EventsEqual || !row.Golden.MiniEventsEqual || row.Golden.Methods != methods ||
			row.Golden.Reference != p.Fixed.Golden[row.Session] || row.Golden.ReferenceKind != "rerun_original166_pinned_code" || row.Golden.HistoricalSavedEventsEqual || row.Golden.AllSignalEqual {
			return fmt.Errorf("117元54の場別成功/対照不足")
		}
		if err := source.VerifyRef(row.Native); err != nil {
			return err
		}
	}
	return nil
}

// CheckReplay は117当場の20条件が原時計で完結したことを確認します。
//
// 引数: value(ReplayResult)、fixed(Fixed)は当場値とRoot固定です。
// 返り値: errorは宣言・数量・時計・源S0対照の差です。金融額で候補を選びません。
func CheckReplay(value ReplayResult, fixed Fixed) error {
	a := value.Actual
	if value.Version != 1 || value.Trial != 117 || value.Source.Trial != 111 || !value.Source.Complete || !a.Complete || a.Trial != 117 ||
		!value.S0Equal || value.S0Comparisons != 4 || value.OriginalHistoricalEventsEqual || len(a.Books) != 20 ||
		!reflect.DeepEqual(a.Configurations, fixed.ActualConfigurations) || a.EntryGridSeconds != nil || a.ExtraOpeningQuietSeconds != 0 ||
		a.ExplicitTimers != 0 || a.ChartSeedMode != "cold_each_session" || a.FinalChart.CarriedNumericSeed ||
		a.Scope.Session.ID != value.Source.Session.ID || a.Scope.Contract != value.Source.Contract {
		return fmt.Errorf("117の全20/原時計/源対照差")
	}
	if err := checkShortDelivery(a, fixed.ShortDefinition); err != nil {
		return err
	}
	for _, config := range fixed.ActualConfigurations {
		key := fmt.Sprintf("%s_C%.0f_D%d", config.Policy, config.SlipPts, config.DelaySeconds)
		b, ok := a.Books[key]
		if !ok || b.Key != key || b.Config != config || !b.Complete || !b.Finished || b.Failure != "" ||
			b.Totals.OpenBuy != 0 || b.Totals.OpenSell != 0 || b.Totals.PendingBuy != 0 || b.Totals.PendingSell != 0 ||
			b.Totals.OpenEntryCostsYen != 0 || b.Totals.EntryQuantity != b.Totals.CloseQuantity || b.Totals.NetYen != b.Totals.ClosedNetYen {
			return fmt.Errorf("117口座の完結差:%s", key)
		}
		for _, position := range b.Positions {
			if position.Quantity != 0 || position.Reserved != 0 {
				return fmt.Errorf("117実玉の終了残")
			}
		}
	}
	return nil
}

// DeclaredH0Definitions は通常H0と短期H0の本名ごとの実定義を返します。
//
// 引数: なし。返り値: map[guard.Policy]guard.H0Definitionは二つの独立値です。
func DeclaredH0Definitions() map[guard.Policy]guard.H0Definition {
	a, _ := guard.H0DefinitionFor(guard.H0E)
	b, _ := guard.H0DefinitionFor(guard.H0M)
	return map[guard.Policy]guard.H0Definition{guard.H0E: a, guard.H0M: b}
}

// checkShortDelivery は短期結果が当場の受理原行だけで形成されEOF確定を加えていないか検査します。
//
// 引数: a(Result)/definition(short.Definition)は当場結果と固定実定義。返り値: errorは配送数・場・足根拠の差です。
func checkShortDelivery(a Result, definition short.Definition) error {
	if !reflect.DeepEqual(a.ShortDefinition, definition) || !reflect.DeepEqual(definition, short.DeclaredDefinition()) || a.Counts.ShortDeliveryRows != a.Counts.Rows || a.Counts.ShortClosed != len(a.ShortClosed) || a.Counts.ShortGaps != len(a.ShortGaps) || a.FinalShortBank.TotalClosedBars != len(a.ShortClosed) || a.FinalShortBank.ResetCount != len(a.ShortGaps) || a.FinalShortBank.Scope != (short.Scope{Session: a.Scope.Session.ID, Contract: a.Scope.Contract, Start: a.Scope.Session.Start}) {
		return fmt.Errorf("117短期の場/実定義/原行配送/閉足/欠足数の差")
	}
	if a.Counts.Rows == 0 {
		if a.FinalShortBank.HaveQuote {
			return fmt.Errorf("未配送の短期原行を生成")
		}
		return nil
	}
	if err := short.ValidateSnapshot(a.FinalShortBank); err != nil {
		return err
	}
	seen := map[string]bool{}
	for _, b := range a.ShortClosed {
		if !b.Complete || b.ID == "" || seen[b.ID] || b.End != b.Start+60 || b.Published.Time < b.End || b.Published.Index <= b.Last.Index || b.Published.SourceLine <= b.Last.SourceLine {
			return fmt.Errorf("117確定1分足の重複/原行/公表根拠差")
		}
		seen[b.ID] = true
	}
	return nil
}

// SaveNew は111と同じJSON整形/LF/gzipで117結果を新規保存します。
//
// 引数: path(string)、value(any)、compressed(bool)は新規先と保存値です。
// 返り値: source.FileRef/errorは保存指紋又は既存/書込異常です。
func SaveNew(path string, value any, compressed bool) (source.FileRef, error) {
	raw, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return source.FileRef{}, err
	}
	f, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if err != nil {
		return source.FileRef{}, err
	}
	if compressed {
		z := gzip.NewWriter(f)
		_, err = z.Write(append(raw, '\n'))
		if e := z.Close(); err == nil {
			err = e
		}
	} else {
		_, err = f.Write(append(raw, '\n'))
	}
	if e := f.Close(); err == nil {
		err = e
	}
	if err != nil {
		return source.FileRef{}, err
	}
	sha, err := source.Digest(path)
	return source.FileRef{Path: path, SHA256: sha}, err
}
