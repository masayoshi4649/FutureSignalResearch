# 正益と短期波の連続比較

元Source111の原行順と時計を保ち、旧3分bank・旧112三政策対照の骨格を113Coreから別moduleへ派生した117の接続部品。S0/W100/P100/H0E/H0MとC0/C5・D0/D1の20口座を同じSource通知へ渡す。取得条件・数量・Source戦略43項目を変更しない。5分/15分の研究側時計・開始静観・三時間軸入口gateは追加しない。

旧3分bankはcoldのまま、公開イベントのreset/observation順に旧型をActorへ渡す。同じSource受理NK原行から別のshortwave117.Bankを当場coldで更新し、H0M四口座だけへSetShortwaveSnapshotを先行配送してから全20のOnNativeStepを呼ぶ。短期SnapshotのTime/Index/SourceLine/Lastと処理原行の同体はActorが検査する。現在値を未来の足終値へ置換せず、EOFで1分足を確定させない。

Resultに全tickは複写しない。`short_closed` は各ClosedNowを一度、`short_gaps` は欠足が判明した原行のGapを一度保存し、`final_short_bank` は実最終原行の未確定prefixを含む。`short_definition` とcounts.short_delivery_rows/short_closed/short_gapsを持つ。H0Mの取得後短期候補・警戒・幅適用・実注文/返済はActor監査に分かれる。旧P100の3分狭幅と新H0Mの1分警戒を同じ観測値と呼ばない。

基準S0四費用はSource側四基準の全金融JSONへ照合する。さらに正式112の同Source全文とS0/W100/P100×四費用の12冊を毎場照合する。説明scope、保護監査の版名、実定義の許可差はActorのCompareLegacy112が明示し、額・全Stateを除外しない。初期54場の原文166再実行81手法場の保存Event参照を再用する。当時の全Signal JSONや全tick監査との同体を過大に主張しない。

`Fixed` はtrial117、source_trial111を本名で使う。実20宣言、五policy_definitions、二つのh0_definitions、short_definition/short_declaration、旧Source/Chart/Core112/高速112と新Actor/Pure/Shortwaveの7停止、実Go閉包、親子実行物のSHAを本文前に認証する。基礎の高速コピー自然2場証拠は旧112部品の由来であり、新H0の成績証明ではない。旧112のcondition/market/native_catalogと同43戦略・70場・54oracle参照を固定する。

CLIは新実行物で次の形を使う。市場はRootの新F1固定後だけRootが実行する。現時点では人工・宣言素材段階で、金融・自然Native・Raw・CSV本文・11月09を読まない。

```powershell
.\117連続比較.exe --fixed ABS --fixed-sha SHA --stage metadata-only
.\117連続比較.exe --fixed ABS --fixed-sha SHA --stage first2 --out NEW --workers 2
.\117連続比較.exe --fixed ABS --fixed-sha SHA --stage base54 --out NEW --workers 16
.\117連続比較.exe --fixed ABS --fixed-sha SHA --stage full70 --out NEW --workers 16 --prior54 ABS_BASE54_COMPLETION --prior54-sha SHA
```

各セッションは独立process、場内原行は直列。Windows workerは非表示、子GOMAXPROCS=1。親・子とも同じ固定exeを本文前に再認証する。子失敗・終了欠落・Native位置差では全体成功にしない。結果は予定場順に集約する。同F1のbase54成功が必要で、full70はその54NativeをSHA再認証して参照再用し、追加16だけ再生する。全70を再生で再証明したとは書かない。出力は新規先のみ。

人工はSource通知を手製した買売40冊と旧112対照48冊を保存できる。FAR自然生成の有効性とは別である。実1分bankの取得後波で足途中警戒→次原行返済を確認し、源非干渉・未来追記非干渉・同秒別行・cold・欠足/ClosedNow一回・末尾未確定・固定の改竄拒否・並列I/Oを検査する。

`検査して停止する.py --proof-only --output 新規先` は市場前の検査とfixed=false素材だけを作る。依存3停止未受領ならその欄を未確定に残す。Rootレビュー後だけ `--reviewed` と新3停止/宣言Refを明示して正式停止・実行物/条件素材を確定する。旧停止と旧試行は書き換えない。
