package shortcomparison117

import (
	"encoding/json"
	"reflect"
	"testing"

	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	protect "github.com/masayoshi4649/SessionTradeExecuter/miniprotect"
	legacy "github.com/masayoshi4649/SessionTradeExecuter/supportcomparison112"
)

// handShortReplayPair は取得後の谷・突破・足途中失速を同じSource原行へ結びます。
//
// 引数: t(*testing.T)/side(int)は検査器と売買符号。返り値: ReplayResult/legacy.ReplayResultは新20と旧24の人工完結です。
func handShortReplayPair(t *testing.T, side int) (ReplayResult, legacy.ReplayResult) {
	t.Helper()
	session := session94()
	scene := source.SourceCase{Session: session, Contract: "人工限月117"}
	current, previous := New(), legacy.New()
	if err := current.Begin(scene); err != nil {
		t.Fatal(err)
	}
	if err := previous.Begin(scene); err != nil {
		t.Fatal(err)
	}
	base := map[string]*protect.ActualBook{}
	for _, cfg := range source.ActorConfigs() {
		b, e := protect.NewActualBook(session, cfg)
		if e != nil {
			t.Fatal(e)
		}
		base[b.Snapshot().Key] = b
	}
	fixture := newFixtureSource94()
	index := int64(0)
	feed := func(seconds, price float64, news []native.Signal) {
		t.Helper()
		o := observation94(session, side, index, seconds, price-1005, 0)
		batch := fixture.step(t, o, index+1000, news, nil)
		step := source.NativeStep{Observation: o, SourceLine: index + 1000, Mini: []source.NativeBatch{batch}}
		before, _ := json.Marshal(step)
		if err := current.Step(step); err != nil {
			t.Fatal(err)
		}
		if err := previous.Step(step); err != nil {
			t.Fatal(err)
		}
		for _, book := range base {
			if err := book.OnNativeStep(o, step.SourceLine, []protect.NativeBatch{batch}); err != nil {
				t.Fatal(err)
			}
		}
		after, _ := json.Marshal(step)
		if !reflect.DeepEqual(before, after) {
			t.Fatal("短期配送が源入力を書換え")
		}
		index++
	}
	feed(0, 995, []native.Signal{birth94("波", side, 2)})
	feed(.5, 995, nil)
	feed(1, 1000, nil)
	for minute := 0; minute < 34; minute++ {
		feed(float64(minute)*60+50, 1000+10*float64(minute), nil)
	}
	bars := [][4]float64{{1340, 1390, 1330, 1370}, {1430, 1440, 1410, 1430}, {1430, 1430, 1390, 1400}, {1400, 1430, 1400, 1420}, {1420, 1460, 1410, 1460}}
	for i, bar := range bars {
		for j, price := range bar {
			feed(float64(34+i)*60+[]float64{0, 10, 20, 50}[j], price, nil)
		}
	}
	feed(39*60, 1460, nil)
	feed(39*60+20, 1320, nil)
	feed(39*60+21, 1310, nil)
	feed(40*60, 1240, nil)
	feed(40*60+1, 1230, nil)
	feed(41*60, 1230, []native.Signal{close94("閉波", "波", side, 2)})
	feed(41*60+1, 1220, nil)
	feed(41*60+2, 1220, nil)
	end := source.SourceEnd{Session: session, Complete: true}
	if err := current.End(end); err != nil {
		t.Fatal(err)
	}
	if err := previous.End(end); err != nil {
		t.Fatal(err)
	}
	origin := source.ReplayResult{Version: 1, Trial: 111, Session: session, Contract: scene.Contract, Complete: true, Books: map[string]source.ActualResult{}}
	for key, b := range base {
		value, err := b.Finish()
		if err != nil {
			t.Fatal(err)
		}
		origin.Books[key] = value
	}
	result, err := ConnectResult(origin, current)
	if err != nil {
		t.Fatal(err)
	}
	prior, err := legacy.ConnectResult(copyValue(origin), previous)
	if err != nil {
		t.Fatal(err)
	}
	if err = CompareReference112Values(&result, prior, source.FileRef{Path: "人工旧112", SHA256: "人工"}); err != nil {
		t.Fatal(err)
	}
	return result, prior
}

// TestShortWaveCoreMirror はCore配送でも足途中警戒と後原行約定、旧12対照が成立するか検査します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。短期波形は市場由来ではありません。
func TestShortWaveCoreMirror(t *testing.T) {
	for _, side := range []int{1, -1} {
		result, _ := handShortReplayPair(t, side)
		a := result.Actual
		if result.Reference112.Comparisons != 12 || !result.Reference112.AllFinancialEqual || a.Counts.ShortDeliveryRows != a.Counts.Rows || a.Counts.ShortClosed != len(a.ShortClosed) {
			t.Fatal("対照又は短期配送数差")
		}
		p := a.Books["H0M_C0_D0"].Positions[0]
		if p.Shortwave117 == nil || p.Shortwave117.FirstWarning == nil || p.Protection117.FirstNarrowing == nil || p.Shortwave117.FinalOwnership == nil || p.Shortwave117.FinalOwnership.Remaining != 0 {
			t.Fatal("警戒/幅/返済所有が欠落")
		}
		warning := p.Shortwave117.FirstWarning
		if warning.Quote.Time != a.Scope.Session.Start+1800+39*60+20 || p.RealizedNet != 60846 {
			t.Fatal("足終待ち又は後原行実現額差")
		}
		if p.Shortwave117.FinalOwnership.Quote.Index <= warning.Quote.Index || p.Shortwave117.FinalOwnership.Quote.Time <= warning.Quote.Time {
			t.Fatal("同原行で架空約定")
		}
		if a.FinalShortBank.Prefix == nil || a.FinalShortBank.Prefix.Complete || a.FinalShortBank.Prefix.End <= a.FinalShortBank.Quote.Time {
			t.Fatal("EOFによる足の架空確定")
		}
		for _, policy := range []string{"S0", "W100", "P100", "H0E"} {
			for _, c := range []string{"C0_D0", "C0_D1", "C5_D0", "C5_D1"} {
				for _, position := range a.Books[policy+"_"+c].Positions {
					if position.Shortwave117 != nil {
						t.Fatal("H0M以外へ短期監視を混入")
					}
				}
			}
		}
	}
}

// TestShortGapAndClosedOnce は一分確定を一度だけ残し欠足を当原行の事実で記録します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。空足・EOF足を追加しません。
func TestShortGapAndClosedOnce(t *testing.T) {
	c := New()
	s := session94()
	if err := c.Begin(source.SourceCase{Session: s, Contract: "人工限月117"}); err != nil {
		t.Fatal(err)
	}
	for i, sec := range []float64{0, 10, 60, 61, 240, 241} {
		o := observation94(s, 1, int64(i), sec, 0, 0)
		if err := c.Step(source.NativeStep{Observation: o, SourceLine: int64(i + 1)}); err != nil {
			t.Fatal(err)
		}
	}
	if len(c.result.ShortClosed) != 2 || len(c.result.ShortGaps) != 1 || c.result.ShortGaps[0].MissingMinutes != 2 || c.result.ShortClosed[0].ID == c.result.ShortClosed[1].ID {
		t.Fatal("閉足の重複又は欠足数差")
	}
	if err := c.End(source.SourceEnd{Session: s, Complete: true}); err != nil {
		t.Fatal(err)
	}
	a, err := c.Result()
	if err != nil {
		t.Fatal(err)
	}
	if err = checkShortDelivery(a, a.ShortDefinition); err != nil {
		t.Fatal(err)
	}
	for _, mode := range []string{"配送欠落", "足重複", "未来足", "定義差"} {
		bad := copyValue(a)
		switch mode {
		case "配送欠落":
			bad.Counts.ShortDeliveryRows--
		case "足重複":
			bad.ShortClosed[1] = bad.ShortClosed[0]
		case "未来足":
			bad.ShortClosed[0].Published.Time = bad.ShortClosed[0].End - 1
		case "定義差":
			bad.ShortDefinition.MACDFast++
		}
		if checkShortDelivery(bad, a.ShortDefinition) == nil {
			t.Fatal("短期破壊を受理", mode)
		}
	}
}
