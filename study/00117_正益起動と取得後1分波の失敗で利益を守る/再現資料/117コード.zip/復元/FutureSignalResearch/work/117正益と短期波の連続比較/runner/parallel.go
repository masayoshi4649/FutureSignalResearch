// Package parallel117 は117接続Coreの場内直列処理を変えず、独立セッションだけを別プロセスへ配ります。
package parallel117

import (
	"compress/gzip"
	"context"
	"encoding/json"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"reflect"
	"sort"
	"strings"
	"sync"

	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	core "github.com/masayoshi4649/SessionTradeExecuter/shortcomparison117"
)

const Method = core.ParallelMethod

// Plan は公開Coreゲートを通過した計画と117の外側固定です。
type Plan struct {
	Core  core.RunPlan
	Fixed core.Fixed
}

// Job は一つの元順序と、親と競合しない子出力先を示します。
type Job struct {
	Index int
	Input source.InputCase
	Out   string
	Log   string
}

// WorkerCompletion は一子の完結・固定前後・Native参照を親へ返します。
type WorkerCompletion struct {
	Version         int               `json:"version"`
	Trial           int               `json:"trial"`
	Success         bool              `json:"success"`
	Stage           string            `json:"stage"`
	Session         string            `json:"session"`
	ConditionSHA256 string            `json:"condition_sha256"`
	Result          core.SceneResult  `json:"result"`
	Before          map[string]string `json:"before"`
	After           map[string]string `json:"after"`
	Unchanged       bool              `json:"unchanged"`
}

// Completion はCoreの完了schemaへI/O説明と子成功参照だけを加えます。
type Completion struct {
	core.Completion
	ParallelMethod    string           `json:"parallel_method"`
	ParallelWorkers   int              `json:"parallel_workers"`
	WorkerCompletions []source.FileRef `json:"worker_completions"`
}

// Callback は人工又は別プロセスの一子を呼ぶ接続です。
type Callback func(context.Context, Job) (WorkerCompletion, error)

type outcome struct {
	job   Job
	value WorkerCompletion
	err   error
}

// readRef はSHA認証後の小JSONを復元します。
//
// 引数: ref(source.FileRef)、value(any)は期待参照と復元先です。
// 返り値: errorは現物又はJSONの差です。
func readRef(ref source.FileRef, value any) error {
	if err := source.VerifyRef(ref); err != nil {
		return err
	}
	raw, err := os.ReadFile(ref.Path)
	if err != nil {
		return err
	}
	return json.Unmarshal(raw, value)
}

// Prepare はtrial117外ゲートを親子ともそのまま呼びます。
//
// 引数: condition(source.FileRef)、stage(string)、prior(*source.FileRef|nil)は117固定と段階です。
// 返り値: Plan/errorは本文未読の計画です。111へのtrial偽装は行いません。
func Prepare(condition source.FileRef, stage string, prior *source.FileRef) (Plan, error) {
	value, err := core.PrepareFixed(condition, stage, prior)
	if err != nil {
		return Plan{}, err
	}
	return Plan{Core: value, Fixed: value.Fixed}, nil
}

// saveNew は停止Coreと同じMarshalIndent・LF・gzipで新規保存します。
//
// 引数: path(string)、value(any)、compressed(bool)は新規先・保存値・gzip指定です。
// 返り値: source.FileRef/errorは同bytes用指紋又は保存差です。
func saveNew(path string, value any, compressed bool) (source.FileRef, error) {
	raw, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return source.FileRef{}, err
	}
	raw = append(raw, '\n')
	f, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if err != nil {
		return source.FileRef{}, err
	}
	if compressed {
		z := gzip.NewWriter(f)
		_, err = z.Write(raw)
		if e := z.Close(); err == nil {
			err = e
		}
	} else {
		_, err = f.Write(raw)
	}
	if e := f.Close(); err == nil {
		err = e
	}
	if err != nil {
		return source.FileRef{}, err
	}
	sha, err := source.Digest(path)
	return source.FileRef{Path: path, SHA256: sha}, err
}

// newDirectory は親だけを整え最終出力先を原子的な新規作成に限定します。
//
// 引数: path(string)は親又は一子の未使用先です。
// 返り値: string/errorは絶対新規先又は既存先です。
func newDirectory(path string) (string, error) {
	abs, err := filepath.Abs(path)
	if err != nil {
		return "", err
	}
	if err = os.MkdirAll(filepath.Dir(abs), 0755); err != nil {
		return "", err
	}
	if err = os.Mkdir(abs, 0755); err != nil {
		return "", fmt.Errorf("出力先は新規のみ:%w", err)
	}
	return abs, nil
}

// fingerprints は期待前指紋を実物へ再照合し、同じ集合を返します。
//
// 引数: expected(map[string]string)は117の本文前証拠です。
// 返り値: map[string]string/errorは実物前後又は改変です。
func fingerprints(expected map[string]string) (map[string]string, error) {
	after := map[string]string{}
	for path, sha := range expected {
		s, err := source.Digest(path)
		if err != nil {
			return nil, err
		}
		if s != sha {
			return nil, fmt.Errorf("固定入力/codeの実行前後差:%s", path)
		}
		after[path] = s
	}
	return after, nil
}

// Worker は一子の固定を再認証し、当場の原行内を停止Coreそのままで直列再生します。
//
// 引数: condition(source.FileRef)、stage/session/out(string)、prior(*source.FileRef|nil)は117固定・段階・場・新規先・先行成功です。
// 返り値: WorkerCompletion/errorは一場20口座と元Event照合の成功又は不完了です。
func Worker(condition source.FileRef, stage, session, out string, prior *source.FileRef) (result WorkerCompletion, err error) {
	result = WorkerCompletion{Version: 1, Trial: 117, Stage: stage, Session: session, ConditionSHA256: condition.SHA256}
	p, err := Prepare(condition, stage, prior)
	if err != nil {
		return result, err
	}
	index := -1
	for i, input := range p.Core.Source.Cases {
		if input.ID == session {
			index = i
			break
		}
	}
	if index < 0 || (stage == "full70" && index < 54) || stage == "metadata-only" {
		return result, fmt.Errorf("当段階で新しく再生する場ではない")
	}
	absolute, err := newDirectory(out)
	if err != nil {
		return result, err
	}
	defer func() {
		if err != nil {
			result.Success = false
			_, _ = saveNew(filepath.Join(absolute, "不完了.json"), map[string]any{"success": false, "session": session, "stage": stage, "condition_sha256": condition.SHA256, "error": err.Error()}, false)
		}
	}()
	result.Before = p.Core.Source.Before
	consumer := core.New()
	origin, err := source.ReplayWithConsumer(p.Core.Source.Manifest.Root, p.Core.Source.Cases[index], consumer)
	if err != nil {
		return result, err
	}
	combined, err := core.ConnectResult(origin, consumer)
	if err != nil {
		return result, err
	}
	if err = core.CheckReplay(combined, p.Core.Fixed); err != nil {
		return result, err
	}
	if err = core.CompareReference112(&combined, p.Core.LegacyNatives[session]); err != nil {
		return result, err
	}
	var proof *source.GoldenProof
	if index < 54 {
		var checked source.GoldenProof
		checked, err = source.CompareGolden(origin, p.Core.Fixed.Golden[session])
		if err != nil {
			return result, err
		}
		if !checked.EventsEqual || !checked.MiniEventsEqual || checked.ReferenceKind != "rerun_original166_pinned_code" || checked.HistoricalSavedEventsEqual || checked.AllSignalEqual {
			return result, fmt.Errorf("原文再実行の対照範囲差")
		}
		proof = &checked
	}
	ref, err := saveNew(filepath.Join(absolute, session+".Native.json.gz"), combined, true)
	if err != nil {
		return result, err
	}
	result.Result = core.SceneResult{Session: session, Native: ref, Golden: proof, Books: 20, S0Comparisons: 4, S0Equal: true, Complete: true, Reference112: p.Core.LegacyNatives[session], Reference112Comparisons: 12, Reference112Equal: true, Source111Equal: true}
	result.After, err = fingerprints(result.Before)
	if err != nil {
		return result, err
	}
	result.Unchanged = true
	result.Success = true
	_, err = saveNew(filepath.Join(absolute, "完了.json"), result, false)
	return result, err
}

// processCallback は同じ固定exeをworkerモードで起動し終了と子完了の両方を確認します。
//
// 引数: condition(source.FileRef)、stage(string)、prior(*source.FileRef|nil)、exe(string)は親と同じ117固定・段階・先行成功・実行物です。
// 返り値: Callbackは各子の独立プロセス接続です。子から更にspawnしません。
func processCallback(condition source.FileRef, stage string, prior *source.FileRef, exe string) Callback {
	return func(ctx context.Context, job Job) (WorkerCompletion, error) {
		value := WorkerCompletion{}
		log, err := os.OpenFile(job.Log, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
		if err != nil {
			return value, err
		}
		defer log.Close()
		args := []string{"--fixed", condition.Path, "--fixed-sha", condition.SHA256, "--stage", stage, "--out", job.Out, "--worker-session", job.Input.ID}
		if prior != nil {
			args = append(args, "--prior54", prior.Path, "--prior54-sha", prior.SHA256)
		}
		cmd := exec.CommandContext(ctx, exe, args...)
		configureProcess(cmd)
		cmd.Env = append(os.Environ(), "GOMAXPROCS=1")
		cmd.Stdout, cmd.Stderr = log, log
		if err = cmd.Run(); err != nil {
			return value, fmt.Errorf("子process不成功:%s:%w", job.Input.ID, err)
		}
		path := filepath.Join(job.Out, "完了.json")
		sha, err := source.Digest(path)
		if err != nil {
			return value, fmt.Errorf("子の完了欠落:%s:%w", job.Input.ID, err)
		}
		err = readRef(source.FileRef{Path: path, SHA256: sha}, &value)
		return value, err
	}
}

// validateWorker は一子の成功・期待前後・原文Event・出力所有を照合します。
//
// 引数: p(Plan)、job(Job)、value(WorkerCompletion)は認証済み計画・当場・子の返却です。
// 返り値: errorは別条件/欠落/残量/重複場/子出力根外等の差です。
func validateWorker(p Plan, job Job, value WorkerCompletion) error {
	r := value.Result
	if value.Version != 1 || value.Trial != 117 || !value.Success || value.Stage != p.Core.Stage || value.Session != job.Input.ID ||
		value.ConditionSHA256 != p.Core.Source.Condition.SHA256 || !value.Unchanged ||
		!reflect.DeepEqual(value.Before, p.Core.Source.Before) || !reflect.DeepEqual(value.After, p.Core.Source.Before) ||
		r.Session != job.Input.ID || r.Books != 20 || r.S0Comparisons != 4 || !r.S0Equal || !r.Complete || r.OpenQuantity != 0 || r.PendingQuantity != 0 || r.Reference112Comparisons != 12 || !r.Reference112Equal || !r.Source111Equal || r.Reference112 != p.Core.LegacyNatives[job.Input.ID] {
		return fmt.Errorf("子の成功/固定前後/20口座/場の差:%s", job.Input.ID)
	}
	expected := filepath.Join(job.Out, job.Input.ID+".Native.json.gz")
	if r.Native.Path != expected {
		return fmt.Errorf("子Nativeは当子の新規先だけ")
	}
	if err := source.VerifyRef(r.Native); err != nil {
		return err
	}
	if job.Index < 54 {
		methods := 1
		if strings.HasSuffix(job.Input.ID, "_Night") {
			methods = 2
		}
		if r.Golden == nil || !r.Golden.EventsEqual || !r.Golden.MiniEventsEqual || r.Golden.Session != job.Input.ID ||
			r.Golden.Methods != methods || r.Golden.Reference != p.Core.Fixed.Golden[job.Input.ID] ||
			r.Golden.ReferenceKind != "rerun_original166_pinned_code" || r.Golden.HistoricalSavedEventsEqual || r.Golden.AllSignalEqual {
			return fmt.Errorf("子の元Event対照不足")
		}
	} else if r.Golden != nil {
		return fmt.Errorf("追加16へ元54対照を偽装")
	}
	return nil
}

// assemble は認証済み計画を有限workerへ配り、全成功だけを予定順に集約します。
//
// 引数: p(Plan)、workers(int)、out(string)、callback(Callback)は認証計画・同時上限・新規先・子接続です。
// 返り値: Completion/errorは全件成功又は不完了です。市場CLI以外では人工callbackにだけ使用します。
func assemble(p Plan, workers int, out string, callback Callback) (complete Completion, err error) {
	stage := p.Core.Stage
	complete = Completion{Completion: core.Completion{Version: 1, Trial: 117, Stage: stage, ConditionSHA256: p.Core.Source.Condition.SHA256,
		Results: []core.SceneResult{}, Before: p.Core.Source.Before, Prior54: p.Core.Source.Prior54Ref}, ParallelMethod: Method, WorkerCompletions: []source.FileRef{}}
	expectedCount := map[string]int{"first2": 2, "base54": 54, "full70": 70}[stage]
	if workers < 1 || workers > 16 || expectedCount == 0 || len(p.Core.Source.Cases) != expectedCount || callback == nil {
		return complete, fmt.Errorf("場集合又はworker上限1..16が必要")
	}
	seen := map[string]bool{}
	for _, input := range p.Core.Source.Cases {
		if input.ID == "" || filepath.Base(input.ID) != input.ID || seen[input.ID] {
			return complete, fmt.Errorf("予定場の重複又は不正ID")
		}
		seen[input.ID] = true
	}
	if (stage == "full70") != (p.Core.Prior54 != nil) {
		return complete, fmt.Errorf("全70だけ同117条件 base54再用を要求")
	}
	absolute, err := newDirectory(out)
	if err != nil {
		return complete, err
	}
	defer func() {
		if err != nil {
			complete.Success = false
			_, _ = saveNew(filepath.Join(absolute, "不完了.json"), map[string]any{"success": false, "stage": stage, "condition_sha256": complete.ConditionSHA256, "error": err.Error(), "collected_sessions": len(complete.Results)}, false)
		}
	}()
	for _, dir := range []string{"worker", "log"} {
		if err = os.Mkdir(filepath.Join(absolute, dir), 0755); err != nil {
			return complete, err
		}
	}
	first := 0
	if p.Core.Prior54 != nil {
		first = 54
		old := p.Core.Prior54
		if old.Trial != 117 || !old.Success || old.Stage != "base54" || old.ConditionSHA256 != complete.ConditionSHA256 ||
			old.Sessions != 54 || old.Books != 1080 || old.OriginalMethods != 81 || old.ReusedSessions != 0 || old.ReplayedSessions != 54 ||
			!old.Unchanged || !reflect.DeepEqual(old.Before, old.After) || len(old.Results) != 54 {
			return complete, fmt.Errorf("認証済みbase54集合差")
		}
		for i, row := range p.Core.Prior54.Results {
			if row.Session != p.Core.Source.Cases[i].ID || row.Books != 20 || row.S0Comparisons != 4 || !row.S0Equal || !row.Complete ||
				row.OpenQuantity != 0 || row.PendingQuantity != 0 || row.Golden == nil || !row.Golden.EventsEqual || !row.Golden.MiniEventsEqual ||
				row.Golden.Session != row.Session || row.Golden.Reference != p.Core.Fixed.Golden[row.Session] {
				return complete, fmt.Errorf("再用54の場順差")
			}
			if err = source.VerifyRef(row.Native); err != nil {
				return complete, err
			}
			complete.Results = append(complete.Results, row)
			complete.Books += row.Books
			complete.OriginalMethods += row.Golden.Methods
			complete.ReusedSessions++
			complete.Reference112Comparisons += row.Reference112Comparisons
		}
	}
	jobs := []Job{}
	for i := first; i < expectedCount; i++ {
		input := p.Core.Source.Cases[i]
		jobs = append(jobs, Job{Index: i, Input: input, Out: filepath.Join(absolute, "worker", input.ID), Log: filepath.Join(absolute, "log", input.ID+".txt")})
	}
	if workers > len(jobs) {
		workers = len(jobs)
	}
	complete.ParallelWorkers = workers
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	queue := make(chan Job, len(jobs))
	results := make(chan outcome, len(jobs))
	for _, job := range jobs {
		queue <- job
	}
	close(queue)
	var running sync.WaitGroup
	for w := 0; w < workers; w++ {
		running.Add(1)
		go func() {
			defer running.Done()
			for {
				select {
				case <-ctx.Done():
					return
				case job, ok := <-queue:
					if !ok {
						return
					}
					value, e := callback(ctx, job)
					if e == nil {
						e = validateWorker(p, job, value)
					}
					results <- outcome{job: job, value: value, err: e}
					if e != nil {
						cancel()
						return
					}
				}
			}
		}()
	}
	running.Wait()
	close(results)
	ordered := map[int]outcome{}
	var failures []string
	for result := range results {
		if result.err != nil {
			failures = append(failures, result.err.Error())
			continue
		}
		if _, exists := ordered[result.job.Index]; exists {
			failures = append(failures, "子の順序重複")
			continue
		}
		ordered[result.job.Index] = result
	}
	if len(failures) > 0 || len(ordered) != len(jobs) {
		sort.Strings(failures)
		return complete, fmt.Errorf("子の失敗又は終了欠落:%d/%d:%s", len(ordered), len(jobs), strings.Join(failures, " / "))
	}
	for _, job := range jobs {
		item, ok := ordered[job.Index]
		if !ok {
			return complete, fmt.Errorf("予定子の欠落")
		}
		path := filepath.Join(job.Out, "完了.json")
		sha, e := source.Digest(path)
		if e != nil {
			return complete, fmt.Errorf("子成功の保存欠落:%w", e)
		}
		var stored WorkerCompletion
		if e = readRef(source.FileRef{Path: path, SHA256: sha}, &stored); e != nil {
			return complete, e
		}
		if !reflect.DeepEqual(item.value, stored) {
			return complete, fmt.Errorf("子の返却と保存完了の差")
		}
		complete.WorkerCompletions = append(complete.WorkerCompletions, source.FileRef{Path: path, SHA256: sha})
		complete.Results = append(complete.Results, item.value.Result)
		complete.Books += 20
		if item.value.Result.Golden != nil {
			complete.OriginalMethods += item.value.Result.Golden.Methods
		}
		complete.ReplayedSessions++
		complete.Reference112Comparisons += item.value.Result.Reference112Comparisons
		fmt.Printf("%d/%d %s 子20口座を元順序へ集約\n", job.Index+1, expectedCount, job.Input.ID)
	}
	complete.After, err = fingerprints(complete.Before)
	if err != nil {
		return complete, err
	}
	for _, row := range complete.Results {
		if err = source.VerifyRef(row.Native); err != nil {
			return complete, err
		}
	}
	methods := 81
	if stage == "first2" {
		methods = 3
	}
	if len(complete.Results) != expectedCount || complete.Books != 20*expectedCount || complete.OriginalMethods != methods || complete.Reference112Comparisons != expectedCount*12 ||
		(stage == "full70" && (complete.ReusedSessions != 54 || complete.ReplayedSessions != 16)) ||
		(stage != "full70" && (complete.ReusedSessions != 0 || complete.ReplayedSessions != expectedCount)) {
		return complete, fmt.Errorf("予定全場/全20/元81手法場の不足")
	}
	complete.Unchanged = true
	complete.Sessions = expectedCount
	complete.AllReferenceEventsEqual = true
	complete.AllReference112Equal = true
	complete.AllSource111Equal = true
	complete.Success = true
	_, err = saveNew(filepath.Join(absolute, "完了.json"), complete, false)
	return complete, err
}

// Run は親の117固定認証後に同じexeの独立workerだけを起動します。
//
// 引数: condition(source.FileRef)、stage/out(string)、prior(*source.FileRef|nil)、workers(int)は117固定・段階・新規先・先行成功・上限です。
// 返り値: Completion/errorは全子成功のCore互換完了又は不完了です。
func Run(condition source.FileRef, stage, out string, prior *source.FileRef, workers int) (Completion, error) {
	p, err := Prepare(condition, stage, prior)
	if err != nil {
		return Completion{}, err
	}
	return assemble(p, workers, out, processCallback(condition, stage, prior, p.Fixed.Executable.Path))
}
