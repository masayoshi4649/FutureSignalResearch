"""旧113のCore/並列骨格を、旧folder参照を壊さず新117へ一度だけ派生する。"""
from pathlib import Path
import hashlib
import json
import re

HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent / "113利益起動水準と構造失効の連続比較"
NAMES = ("runtime.go", "runtime_test.go", "source_fixture_test.go", "fixed.go", "fixed_test.go",
         "runner/parallel.go", "runner/parallel_test.go", "runner/process_windows.go",
         "runner/process_other.go", "cmd/run/main.go", "go.mod", "go.sum")


def main() -> None:
    """
    機能: 停止旧113を変更せず新117骨格を未作成先だけへ保存する。
    引数: なし。返り値: None。金融・市場ファイルは読まない。
    """
    refs = {}
    for name in NAMES:
        old, new = PRIOR / name, HERE / name
        raw = old.read_bytes()
        text = raw.decode("utf-8-sig")
        refs[name] = {"path": str(old.resolve()), "sha256": hashlib.sha256(raw).hexdigest()}
        for a, b in (("entrycomparison113", "shortcomparison117"), ("parallel113", "parallel117"),
                     ("continuousactor113\"", "continuousactor117\""), ("profitfloor113\"", "profitfloor117\""),
                     ("LegacyComparison113", "LegacyComparison117"), ("CORE113_ART_OUT", "CORE117_ART_OUT"),
                     ("PARALLEL113_ART_OUT", "PARALLEL117_ART_OUT")):
            text = text.replace(a, b)
        # ----------------------------------------
        # 相対folder・固定SHA・人工の価格行113は変えず、新版識別と口座数だけを変更する。
        text = re.sub(r"(Trial\s*[:!=]+\s*)113\b", r"\g<1>117", text)
        text = re.sub(r"(pure.Version\s*!=\s*)113\b", r"\g<1>117", text)
        text = re.sub(r"\b24\b", "20", text)
        text = text.replace("1296", "1080")
        text = "\n".join(line.replace("113", "117") if line.lstrip().startswith("//") else line for line in text.splitlines()) + "\n"
        if name == "runtime_test.go":
            text = text[:text.index("// TestChartEntryInvalidation")]
            text = text.replace('"試行": 113', '"試行": 117').replace('"会計数": 48', '"会計数": 40')
        if name == "runner/parallel_test.go":
            text = text.replace("result.Books != 1680", "result.Books != 1400")
        if name == "go.mod":
            # 旧113のreplace先自体は全て残し、新Actor/純/短期moduleを追加する。
            text = raw.decode("utf-8-sig").replace("module github.com/masayoshi4649/SessionTradeExecuter/entrycomparison113", "module github.com/masayoshi4649/SessionTradeExecuter/shortcomparison117")
            text += "\nrequire (\n github.com/masayoshi4649/SessionTradeExecuter/continuousactor117 v0.0.0\n github.com/masayoshi4649/SessionTradeExecuter/profitfloor117 v0.0.0\n github.com/masayoshi4649/SessionTradeExecuter/shortwave117 v0.0.0\n)\n"
            text += "replace github.com/masayoshi4649/SessionTradeExecuter/continuousactor117 => ../117正益と短期波を執行する会計\nreplace github.com/masayoshi4649/SessionTradeExecuter/profitfloor117 => ../117正益起動と費用回収床の純保護\nreplace github.com/masayoshi4649/SessionTradeExecuter/shortwave117 => ../117原行と暫定1分の複合保護\n"
        new.parent.mkdir(exist_ok=True, parents=True)
        with new.open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(text)
    with (HERE / "派生の参照.json").open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps({"試行": 117, "元コード": refs, "市場読取": False,
                                 "範囲": "骨格のみ。新しい短期配送・実宣言・人工は後続の明示差分で追加"}, ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    main()
