package shortwave117

import (
	"fmt"
	"math"
)

type Bank struct {
	scope   Scope
	numbers numeric
	current *Bar
	recent  []Bar
	epoch   uint64
	resets  int
	total   int
	last    BankSnapshot
}

// NewBank は前史seedを使わず当場coldの1分bankを作ります。
//
// 引数: scope(Scope)。返り値: *Bank/errorは原行受理器又は不正です。
func NewBank(scope Scope) (*Bank, error) {
	if !validScope(scope) {
		return nil, fmt.Errorf("117場/限月/startが不正")
	}
	return &Bank{scope: scope, numbers: newNumeric(), recent: []Bar{}, last: BankSnapshot{Version: 117, Scope: scope, Cold: true, ResetReason: "当場cold", RecentClosed: []Bar{}}}, nil
}

// Snapshot は現在bankを消費者から参照分離します。
//
// 引数: receiver(*Bank)。返り値: BankSnapshot。足を確定させません。
func (b *Bank) Snapshot() BankSnapshot { return cloneBank(b.last) }

// Step は一つの元Source受理原行で旧足確定と現在prefixを原順に更新します。
//
// 引数: q(Quote)はLast>0/clock採用済みNK原行。返り値: BankSnapshot/error。timer/EOF足は作りません。
func (b *Bank) Step(q Quote) (BankSnapshot, error) {
	if b == nil || !validQuote(q, b.scope) {
		return BankSnapshot{}, fmt.Errorf("117原行が不正")
	}
	if b.last.HaveQuote && (q.Index <= b.last.Quote.Index || q.SourceLine <= b.last.Quote.SourceLine || q.Time < b.last.Quote.Time) {
		return BankSnapshot{}, fmt.Errorf("117原行重複/逆行")
	}
	start := b.scope.Start + 60*math.Floor((q.Time-b.scope.Start)/60)
	var closed *Bar
	var gap *Gap
	reason := ""
	if b.current != nil && start > b.current.Start {
		v := *b.current
		v.Complete = true
		v.Published = q
		b.numbers.commit(&v)
		b.total++
		closed = &v
		b.recent = append(b.recent, v)
		if len(b.recent) > 4 {
			b.recent = append([]Bar{}, b.recent[len(b.recent)-4:]...)
		}
		if start > v.End {
			gap = &Gap{FromEnd: v.End, ToStart: start, MissingMinutes: int((start - v.End) / 60), At: q}
			b.epoch++
			b.resets++
			reason = "空1分あり:数値と局所波をcoldへreset"
			b.numbers = newNumeric()
			b.recent = []Bar{}
		}
		b.current = nil
	}
	if b.current == nil {
		if !b.numbers.origin.Known {
			b.numbers.origin = known(q.Last)
		}
		b.current = &Bar{ID: fmt.Sprintf("%s/%s/1m/%.9f/%d", b.scope.Session, b.scope.Contract, start, b.epoch), Start: start, End: start + 60, First: q, Last: q, Count: 1, Open: q.Last, High: q.Last, Low: q.Last, Close: q.Last}
	} else {
		b.current.Count++
		b.current.Last = q
		b.current.High = max(b.current.High, q.Last)
		b.current.Low = min(b.current.Low, q.Last)
		b.current.Close = q.Last
	}
	prefix := *b.current
	prefix.Published = q
	b.numbers.provisional(&prefix)
	s := BankSnapshot{Version: 117, Scope: b.scope, HaveQuote: true, Quote: q, Epoch: b.epoch, ResetCount: b.resets, Gap: gap, ResetReason: reason, ClosedBars: b.numbers.bars, TotalClosedBars: b.total, Cold: !b.numbers.committed.Histogram.Known || !b.numbers.committed.ATR.Known, Committed: b.numbers.committed, RecentClosed: append([]Bar{}, b.recent...), ClosedNow: closed, Prefix: &prefix}
	if len(b.recent) > 0 {
		v := b.recent[len(b.recent)-1]
		s.LatestClosed = &v
	}
	var err error
	s.SHA256, err = fingerprint(s)
	if err != nil {
		return BankSnapshot{}, err
	}
	b.last = s
	return cloneBank(s), nil
}
