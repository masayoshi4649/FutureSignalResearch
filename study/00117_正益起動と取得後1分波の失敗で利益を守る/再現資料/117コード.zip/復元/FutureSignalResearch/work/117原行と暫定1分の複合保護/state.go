package shortwave117

import (
	"fmt"
	"math"
)

type pendingArm struct {
	support  Support
	breakout Bar
}
type lastCall struct {
	quote     Quote
	bankSHA   string
	phase     Phase
	active    bool
	remaining int
}
type State struct {
	initialized bool
	view        Snapshot
	last        *lastCall
	decision    Decision
	pending     *pendingArm
}

// NewState は実Position単位の短期監視を作ります。
//
// 引数: e(Entry)は実取得/実初期数量/外部通常幅。返り値: State/error。金額や注文は生成しません。
func NewState(e Entry) (State, error) {
	if !validScope(e.Scope) || e.PositionID == "" || (e.Side != 1 && e.Side != -1) || !finite(e.Price, e.NormalWidthPoints) || e.Price <= 0 || e.Price > 1e9 || !validQuote(e.Fill, e.Scope) || e.InitialQuantity < 1 || e.InitialQuantity > 10 || e.NormalWidthPoints < 5 || e.NormalWidthPoints > 1e9 || math.Mod(e.NormalWidthPoints, 5) != 0 {
		return State{}, fmt.Errorf("117実取得/通常幅が不正")
	}
	return State{initialized: true, view: Snapshot{Version: 117, Entry: e}}, nil
}

// Snapshot は過去Witnessを含む監視状態を独立copyで返します。
//
// 引数: receiver(State)。返り値: Snapshot。外部の変更は私有状態へ影響しません。
func (s State) Snapshot() Snapshot { return cloneView(s.view) }

// postEntry は足全体が実fill原行以降に形成されたか確認します。
//
// 引数: b(Bar)、e(Entry)。返り値: bool。途中取得足の取得前高安は採用しません。
func postEntry(b Bar, e Entry) bool {
	return b.Complete && b.Start >= e.Fill.Time && b.First.Index >= e.Fill.Index && b.First.SourceLine >= e.Fill.SourceLine
}

// signed は買売に共通な価格差へ写します。
//
// 引数: price(float64)、e(Entry)。返り値: float64。
func signed(price float64, e Entry) float64 { return float64(e.Side) * (price - e.Price) }

// candidate は確認済み三本折返しを取得後の局所支持候補にします。
//
// 引数: bars([]Bar)、e(Entry)、now(Quote)。返り値: *Supportは未形成ならnilです。
func candidate(bars []Bar, e Entry, now Quote) *Support {
	if len(bars) < 3 {
		return nil
	}
	a, b, c := bars[len(bars)-3], bars[len(bars)-2], bars[len(bars)-1]
	if !postEntry(a, e) || !postEntry(b, e) || !postEntry(c, e) || a.End != b.Start || b.End != c.Start || c.Published != now {
		return nil
	}
	d := func(v Bar) float64 { return min(signed(v.High, e), signed(v.Low, e)) }
	u := func(v Bar) float64 { return max(signed(v.High, e), signed(v.Low, e)) }
	boundary := d(b)
	if !(boundary > 0 && boundary < d(a) && boundary <= d(c)) {
		return nil
	}
	return &Support{ID: b.ID + "/confirmed/" + c.ID, Center: b, Left: a, Right: c, Confirmed: now, Price: e.Price + float64(e.Side)*boundary, SignedBoundary: boundary, SignedCeiling: max(u(a), u(b), u(c))}
}

// armable は支持確認後の別確定closeが当原行で初めて利用可能か確認します。
//
// 引数: p(*Support)、b(*Bar)、e(Entry)、now(Quote)。返り値: bool。Activeは呼出側で別評価します。
func armable(p *Support, b *Bar, e Entry, now Quote) bool {
	return p != nil && b != nil && postEntry(*b, e) && b.Published == now && b.End > p.Right.End && b.Published.Index > p.Confirmed.Index && signed(b.Close, e) > p.SignedCeiling && b.Technical.Histogram.Known && float64(e.Side)*b.Technical.Histogram.Value > 0 && b.PreviousATR.Known && b.PreviousATR.Value > 0
}

// inspect は生のS/M/Vと不足・否定を分離して評価します。
//
// 引数: v(Snapshot)、in(Input)。返り値: Decision。未armでも観測可能なM/Vは保持します。
func inspect(v Snapshot, in Input) Decision {
	d := Decision{Armed: v.Armed, Narrowed: v.Narrowed, TargetWidthPoints: cloneFloat(v.TargetWidthPoints), Missing: []string{}, Denied: []string{}}
	p := in.Snapshot.Prefix
	e := v.Entry
	if v.Armed && v.ArmedSupport != nil {
		x := float64(e.Side) * (p.Close - v.ArmedSupport.Price)
		d.Values.SignedCloseMinusSupport = ptr(x)
		d.S = truth(x < 0)
		if d.S == False {
			d.Denied = append(d.Denied, "局所支持のstrict逆抜けなし")
		}
	} else {
		d.Missing = append(d.Missing, "有効な取得後支持なし")
	}
	if p.Technical.Histogram.Known {
		h := float64(e.Side) * p.Technical.Histogram.Value
		d.Values.SignedHistogram = ptr(h)
		d.M = truth(h <= 0)
		if d.M == False {
			d.Denied = append(d.Denied, "Hist順側を維持")
		}
	} else {
		d.Missing = append(d.Missing, "暫定Hist未知")
	}
	body := float64(e.Side) * (p.Close - p.Open)
	d.Values.SignedBody = ptr(body)
	d.Values.TR = p.TR
	d.Values.PreviousATR = p.PreviousATR
	bodyVote := truth(body < 0)
	rangeVote := Unknown
	scaleVote := Unknown
	if bodyVote == False {
		d.Denied = append(d.Denied, "反対bodyなし")
	}
	if p.PreviousATR.Known {
		scaleVote = truth(p.PreviousATR.Value > 0)
		if scaleVote == False {
			d.Denied = append(d.Denied, "前ATR尺度が非正")
		}
	} else {
		d.Missing = append(d.Missing, "前確定ATR未知")
	}
	if p.TR.Known && p.PreviousATR.Known {
		rangeVote = truth(p.TR.Value >= p.PreviousATR.Value)
		if rangeVote == False {
			d.Denied = append(d.Denied, "形成TRが前ATR未満")
		}
	} else if !p.TR.Known {
		d.Missing = append(d.Missing, "形成TR未知")
	}
	d.V = and(bodyVote, rangeVote, scaleVote)
	d.Warning = and(truth(v.Armed), d.S, d.M, d.V)
	return d
}

// witness は原行・prefix・使用支持・生票を初回根拠へ固定します。
//
// 引数: v(Snapshot)、in(Input)、d(Decision)、kind(string)。返り値: *Witnessは私有copyです。
func witness(v Snapshot, in Input, d Decision, kind string) *Witness {
	return &Witness{Kind: kind, At: in.Snapshot.Quote, Phase: in.Phase, BankSHA256: in.Snapshot.SHA256, BankEpoch: in.Snapshot.Epoch, Support: cloneSupport(v.ArmedSupport), Breakout: cloneBar(v.Breakout), Prefix: cloneBar(in.Snapshot.Prefix), Values: cloneValues(d.Values), S: d.S, M: d.M, V: d.V, Warning: d.Warning, AArm: v.AArm, TargetWidthPoints: cloneFloat(v.TargetWidthPoints), Active: in.Active, Remaining: in.Remaining}
}

// Advance は同Rawのpre/afterを区別して支持・arm・複合警戒を純計算します。
//
// 引数: state(State)、in(Input)は最新bank/外部Active/実n。返り値: State/Decision/error。
// n<=0は呼出禁止、同phase同inputは冪等、同Rawpre→afterだけActive/nの更新を許します。
func Advance(state State, in Input) (State, Decision, error) {
	empty := Decision{}
	if !state.initialized || in.Remaining < 1 || in.Remaining > state.view.Entry.InitialQuantity || (in.Phase != PreFill && in.Phase != AfterSource) || in.Snapshot.Scope != state.view.Entry.Scope {
		return state, empty, fmt.Errorf("117状態/数量/位相/場が不正")
	}
	if err := ValidateSnapshot(in.Snapshot); err != nil {
		return state, empty, err
	}
	q := in.Snapshot.Quote
	e := state.view.Entry
	if q.Index < e.Fill.Index || q.SourceLine < e.Fill.SourceLine || q.Time < e.Fill.Time {
		return state, empty, fmt.Errorf("117実取得前の入力")
	}
	if state.view.ExternalActive && !in.Active {
		return state, empty, fmt.Errorf("117外部Activeの撤回")
	}
	newRaw := state.last == nil || q.Index > state.last.quote.Index
	if state.last != nil {
		old := state.last
		if in.Remaining > old.remaining {
			return state, empty, fmt.Errorf("117実残量増加")
		}
		if newRaw {
			if q.SourceLine <= old.quote.SourceLine || q.Time < old.quote.Time || in.Snapshot.Epoch < state.view.BankEpoch {
				return state, empty, fmt.Errorf("117原行逆行")
			}
		} else {
			if q != old.quote || in.Snapshot.SHA256 != old.bankSHA {
				return state, empty, fmt.Errorf("117同原行の公表改変/逆行")
			}
			if in.Phase == old.phase {
				if in.Active != old.active || in.Remaining != old.remaining {
					return state, empty, fmt.Errorf("117同位相の入力改変")
				}
				d := cloneDecision(state.decision)
				d.Duplicate = true
				d.NewRaw = false
				d.CandidateNow = false
				d.ArmedNow = false
				d.ResetNow = false
				d.NarrowedNow = false
				return state, d, nil
			}
			if old.phase != PreFill || in.Phase != AfterSource {
				return state, empty, fmt.Errorf("117同原行の位相逆行")
			}
		}
	}
	next := state
	v := &next.view
	v.Sequence++
	v.At = &q
	v.Phase = in.Phase
	v.ExternalActive = in.Active
	resetNow, candidateNow, armedNow := false, false, false
	if newRaw {
		v.RawUpdates++
		next.pending = nil
		if state.last != nil && v.BankEpoch != in.Snapshot.Epoch {
			v.Candidate = nil
			v.Armed = false
			v.ArmedSupport = nil
			v.Breakout = nil
			v.AArm = Value{}
			resetNow = true
			v.LastReset = witness(*v, in, Decision{}, "短期bankのepoch reset。既狭幅は維持")
		}
		v.BankEpoch = in.Snapshot.Epoch
		if in.Snapshot.Gap == nil {
			if armable(v.Candidate, in.Snapshot.ClosedNow, e, q) {
				next.pending = &pendingArm{support: *cloneSupport(v.Candidate), breakout: *cloneBar(in.Snapshot.ClosedNow)}
			}
			if p := candidate(in.Snapshot.RecentClosed, e, q); p != nil && (v.Candidate == nil || p.SignedBoundary > v.Candidate.SignedBoundary) && (v.ArmedSupport == nil || p.SignedBoundary > v.ArmedSupport.SignedBoundary) {
				v.Candidate = p
				candidateNow = true
			}
		}
	}
	// ----------------------------------------
	// inactive中に観測した突破は同Rawのafterでだけarmへ進められ、次Rawには延命しません。
	if in.Active && next.pending != nil && (v.ArmedSupport == nil || next.pending.support.SignedBoundary > v.ArmedSupport.SignedBoundary) {
		p := next.pending
		v.Armed = true
		v.ArmedSupport = cloneSupport(&p.support)
		v.Breakout = cloneBar(&p.breakout)
		v.AArm = p.breakout.PreviousATR
		armedNow = true
	}
	d := inspect(*v, in)
	d.NewRaw = newRaw
	d.ResetNow = resetNow
	d.CandidateNow = candidateNow
	d.ArmedNow = armedNow
	if armedNow {
		w := witness(*v, in, d, "取得後の別確定closeで支持を有効化")
		v.LastArm = w
		if v.FirstArm == nil {
			v.FirstArm = w
		}
	}
	if !v.Narrowed && d.Warning == True {
		if !v.AArm.Known || v.AArm.Value <= 0 {
			return state, empty, fmt.Errorf("117有効化ATRが不正")
		}
		v.Narrowed = true
		v.TargetWidthPoints = ptr(5 * math.Ceil(max(5, min(e.NormalWidthPoints, v.AArm.Value))/5))
		d.NarrowedNow = true
		d.Narrowed = true
		d.TargetWidthPoints = cloneFloat(v.TargetWidthPoints)
		v.FirstWarning = witness(*v, in, d, "S AND M AND Vの最初の複合警戒")
	}
	d.Armed, d.Narrowed = v.Armed, v.Narrowed
	d.TargetWidthPoints = cloneFloat(v.TargetWidthPoints)
	next.last = &lastCall{quote: q, bankSHA: in.Snapshot.SHA256, phase: in.Phase, active: in.Active, remaining: in.Remaining}
	next.decision = cloneDecision(d)
	return next, cloneDecision(d), nil
}
