module github.com/masayoshi4649/SessionTradeExecuter/shortwave117

go 1.24.2
