package shortwave117

type ema struct {
	n     int
	count int
	sum   float64
	value Value
}

// add は確定足をEMAへ一度だけ累積します。
//
// 引数: x(float64)は確定入力。返り値: ValueはSMA初期化後のEMAです。
func (e *ema) add(x float64) Value {
	e.count++
	if !e.value.Known {
		e.sum += x
		if e.count == e.n {
			e.value = known(e.sum / float64(e.n))
		}
	} else {
		e.value.Value += 2 / float64(e.n+1) * (x - e.value.Value)
	}
	return e.value
}

type numeric struct {
	origin        Value
	fast          ema
	slow          ema
	signal        ema
	bars          int
	previousClose Value
	trCount       int
	trSum         float64
	atr           Value
	committed     Technical
}

// newNumeric は場/欠足直後の未知数値状態を作ります。
//
// 引数: なし。返り値: numericは当場coldです。
func newNumeric() numeric { return numeric{fast: ema{n: 12}, slow: ema{n: 26}, signal: ema{n: 9}} }

// trueRange は前の確定終値を必要とするTRを計算します。
//
// 引数: b(Bar)とprevious(Value)。返り値: Valueは前終値未知なら未知です。
func trueRange(b Bar, previous Value) Value {
	if !previous.Known {
		return Value{}
	}
	return known(max(b.High-b.Low, abs(b.High-previous.Value), abs(b.Low-previous.Value)))
}

// commit は一つの確定足でEMA/Signal/ATRを一度だけ進めます。
//
// 引数: b(*Bar)は確定する足。返り値: なし。足へ当時の出典付き数値を写します。
func (n *numeric) commit(b *Bar) {
	if !n.origin.Known {
		n.origin = known(b.Open)
	}
	b.PreviousATR = n.atr
	b.TR = trueRange(*b, n.previousClose)
	x := b.Close - n.origin.Value
	f, s := n.fast.add(x), n.slow.add(x)
	t := Technical{Origin: n.origin, CenteredEMA12: f, CenteredEMA26: s}
	if f.Known {
		t.EMA12 = known(n.origin.Value + f.Value)
	}
	if s.Known {
		t.EMA26 = known(n.origin.Value + s.Value)
	}
	if f.Known && s.Known {
		t.MACD = known(f.Value - s.Value)
		t.Signal = n.signal.add(t.MACD.Value)
		if t.Signal.Known {
			t.Histogram = known(t.MACD.Value - t.Signal.Value)
		}
	}
	// ----------------------------------------
	// ATRは初回14TRのSMA、その後Wilder平均。最初の足のTRは未知のままです。
	if b.TR.Known {
		n.trCount++
		if !n.atr.Known {
			n.trSum += b.TR.Value
			if n.trCount == 14 {
				n.atr = known(n.trSum / 14)
			}
		} else {
			n.atr.Value += (b.TR.Value - n.atr.Value) / 14
		}
	}
	t.ATR = n.atr
	b.Technical = t
	n.committed = t
	n.previousClose = known(b.Close)
	n.bars++
}

// provisional は前確定状態を変更せず現在prefixを一回だけ仮評価します。
//
// 引数: b(*Bar)は当原行までの未確定足。返り値: なし。初期化を足途中へ前倒ししません。
func (n numeric) provisional(b *Bar) {
	b.PreviousATR = n.atr
	b.TR = trueRange(*b, n.previousClose)
	t := Technical{Origin: n.origin}
	x := b.Close - n.origin.Value
	if n.fast.value.Known {
		t.CenteredEMA12 = known(n.fast.value.Value + 2.0/13*(x-n.fast.value.Value))
		t.EMA12 = known(n.origin.Value + t.CenteredEMA12.Value)
	}
	if n.slow.value.Known {
		t.CenteredEMA26 = known(n.slow.value.Value + 2.0/27*(x-n.slow.value.Value))
		t.EMA26 = known(n.origin.Value + t.CenteredEMA26.Value)
	}
	if t.CenteredEMA12.Known && t.CenteredEMA26.Known {
		t.MACD = known(t.CenteredEMA12.Value - t.CenteredEMA26.Value)
	}
	if t.MACD.Known && n.signal.value.Known {
		t.Signal = known(n.signal.value.Value + 0.2*(t.MACD.Value-n.signal.value.Value))
		t.Histogram = known(t.MACD.Value - t.Signal.Value)
	}
	if b.TR.Known && n.atr.Known {
		t.ATR = known(n.atr.Value + (b.TR.Value-n.atr.Value)/14)
	}
	b.Technical = t
}
