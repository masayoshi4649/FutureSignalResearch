package shortwave117

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

type artificialStep struct {
	Before   Snapshot `json:"before_snapshot"`
	Input    Input    `json:"input"`
	After    Snapshot `json:"after_snapshot"`
	Decision Decision `json:"decision"`
}
type artificialCase struct {
	ID      string           `json:"id"`
	Entry   Entry            `json:"entry"`
	Initial Snapshot         `json:"initial_snapshot"`
	Quotes  []Quote          `json:"quotes"`
	Steps   []artificialStep `json:"steps"`
}

// artificialSeries は買売ごとにbankと全監視位相を手製入力だけで再形成します。
//
// 引数: t(*testing.T)、side(int)。返り値: artificialCaseは初回after/同原行arm/警戒/gapを含みます。
func artificialSeries(t *testing.T, side int) artificialCase {
	s := newScenario(t, side)
	entry := s.state.view.Entry
	state, err := NewState(entry)
	if err != nil {
		t.Fatal(err)
	}
	c := artificialCase{ID: map[bool]string{true: "買い", false: "売り"}[side > 0], Entry: entry, Initial: state.Snapshot(), Steps: []artificialStep{}}
	record := func(snap BankSnapshot, phase Phase, active bool, n int) {
		in := Input{Snapshot: cloneBank(snap), Phase: phase, Active: active, Remaining: n}
		before := state.Snapshot()
		next, d, err := Advance(state, in)
		if err != nil {
			t.Fatal(err)
		}
		state = next
		c.Steps = append(c.Steps, artificialStep{Before: before, Input: in, After: state.Snapshot(), Decision: d})
	}
	both := func(snap BankSnapshot, active bool) {
		record(snap, PreFill, active, 2)
		record(snap, AfterSource, active, 2)
	}
	record(s.f.bank.Snapshot(), AfterSource, false, 2)
	s.f.bar(40, 1060, 1070, 1050, 1060, func(x BankSnapshot) { both(x, false) })
	s.f.bar(41, 1060, 1060, 1040, 1050, func(x BankSnapshot) { both(x, false) })
	s.f.bar(42, 1050, 1060, 1050, 1060, func(x BankSnapshot) { both(x, false) })
	s.f.bar(43, 1050, 1090, 1050, 1080, func(x BankSnapshot) { both(x, false) })
	pub := s.f.step(44, 0, 1070)
	record(pub, PreFill, false, 2)
	record(pub, AfterSource, true, 2)
	both(s.f.step(44, 1, 1080), true)
	both(s.f.step(44, 2, 1040), true)
	both(s.f.step(44, 3, 1030), true)
	both(s.f.step(44, 20, 1020), true)
	both(s.f.step(44, 30, 1090), true)
	both(s.f.step(48, 0, 1050), true)
	if !state.view.Narrowed || state.view.FirstWarning == nil || state.view.LastReset == nil {
		t.Fatal("exportの正例不足")
	}
	c.Quotes = append([]Quote{}, s.f.quotes...)
	return c
}

// writeArtificial は手製証拠をowned配下へ決定的に保存します。
//
// 引数: t(*testing.T)、path(string)、v(any)。返り値: map[string]stringはFileRefです。
func writeArtificial(t *testing.T, path string, v any) map[string]string {
	t.Helper()
	b, err := json.MarshalIndent(v, "", "  ")
	if err != nil {
		t.Fatal(err)
	}
	b = append(b, '\n')
	if old, err := os.ReadFile(path); err == nil && !bytes.Equal(old, b) {
		t.Fatal("既存人工証拠との差", path)
	}
	if err = os.WriteFile(path, b, 0600); err != nil {
		t.Fatal(err)
	}
	h := sha256.Sum256(b)
	return map[string]string{"path": path, "sha256": hex.EncodeToString(h[:])}
}

// TestExportArtificial は環境変数指定時だけ、自然入力なしの買売系列を保存します。
//
// 引数: t(*testing.T)、環境SHORTWAVE117_EXPORT_DIR(string)。返り値: なし。正式停止ではありません。
func TestExportArtificial(t *testing.T) {
	out := os.Getenv("SHORTWAVE117_EXPORT_DIR")
	if out == "" {
		t.Skip("人工exportの明示先なし")
	}
	wd, err := os.Getwd()
	if err != nil {
		t.Fatal(err)
	}
	out, err = filepath.Abs(out)
	if err != nil {
		t.Fatal(err)
	}
	rel, err := filepath.Rel(wd, out)
	if err != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(os.PathSeparator)) {
		t.Fatal("owned外への出力禁止")
	}
	if err = os.MkdirAll(out, 0700); err != nil {
		t.Fatal(err)
	}
	cases := []artificialCase{artificialSeries(t, 1), artificialSeries(t, -1)}
	ref := writeArtificial(t, filepath.Join(out, "系列.json"), map[string]any{"試行": 117, "人工": true, "市場": false, "FAR自然生成": false, "金額State": false, "注文": false, "definition": DeclaredDefinition(), "cases": cases})
	steps := 0
	for _, c := range cases {
		steps += len(c.Steps)
	}
	writeArtificial(t, filepath.Join(out, "人工の参照.json"), map[string]any{"成功": true, "試行": 117, "人工": true, "市場": false, "系列数": len(cases), "Advance数": steps, "系列": ref})
}
