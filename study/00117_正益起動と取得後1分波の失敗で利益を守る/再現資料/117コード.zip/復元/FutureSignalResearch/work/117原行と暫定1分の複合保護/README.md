# 原行と暫定1分の短期複合保護API

2026-11-10。moduleは`github.com/masayoshi4649/SessionTradeExecuter/shortwave117`。標準ライブラリだけを使う。金額State、W/f/L、予約、注文、約定、Source戦略は実装しない。市場/Native/Raw/価格CSV/11月09本文は読んでいない。正式停止はRootレビュー後に別途行い、今回の確認JSONを正式停止としない。

## 公開API

```go
NewBank(scope Scope) (*Bank, error)
(*Bank).Step(q Quote) (BankSnapshot, error)
(*Bank).Snapshot() BankSnapshot
ValidateSnapshot(s BankSnapshot) error

NewState(e Entry) (State, error)
Advance(state State, in Input) (State, Decision, error)
(State).Snapshot() Snapshot
DeclaredDefinition() Definition
```

`Scope={Session string,Contract string,Start float64}`。Startは価格時計のUNIX秒。`Quote={Time float64,Index int,SourceLine int,Last float64}`。Indexは元Source受理NK原行の識別子、SourceLineは物理行。両者はstrict増加、Timeは非減少で同秒別行を許す。未受理行の再採用や時計の補完はしない。指数/行の飛びは許すが、それだけで全原行配送を証明したことにしない。

安全な数値域はfinite、Start/Timeは0超かつ1e12秒以下、Last/取得価格は0超かつ1e9以下。通常幅は5pt以上1e9以下の5pt刻み。これはAPIの防御であり、取得候補の価格フィルタではない。Callerは場終了後にStepを供給せず、新場/限月へ新Bankを作る。Seal/EOF/timerで足を作るAPIはない。

`Entry`はScope/PositionID/Side(±1)/Price/Fill(Quote)/InitialQuantity(1〜10)/NormalWidthPoints。実Positionごとに一度作り、通常幅は外部の金額保護で取得時に固定した値を渡す。実fillとLastが同じ値であることは要求しない。Lastはチャート、取得価格は実約定という別の役割である。

`Input`は`Snapshot BankSnapshot,Phase pre_fill|after_source,Active bool,Remaining int`。n<=0はAdvance拒否で、Callerがflat監視をskipする。初回はafter_sourceから開始できる。これは同RawのfillOrdersで生まれた実Positionに対応する。

## Bankの数値と公表

- 当場cold、足幅60秒、セッションStart起点の半開区間。次区間の最初の実原行で旧足を閉じ、その原行は新足へ入れる。初回Quoteを含むprefixを毎原行返す。
- `ClosedNow`は当原行に実公表した旧足だけ。`RecentClosed`は同Epochの最新最大4足、`LatestClosed`はその末尾、`Prefix`は当原行までの未確定OHLC。公表時刻・Index・Lineは`Bar.Published`、足の最初/最後の入力はFirst/Lastで分ける。
- 受理行のない1分を飛ばすと、観測済み旧足をClosedNowへ保存してから数値/Recentをresetする。架空の空足は挿入しない。新Epochのprefixと、reset前のClosedNowを混ぜて監視しない。
- EMA12/26は最初の必要本数のSMA、Signal9はMACDが既知となる26本目から9値のSMA。34確定足でSignalまで既知となる。ATR14は前終値を必要とするTRの初回14値SMA→Wilder更新で、15確定足から既知。0とUnknownは別。
- 各Epochの最初の有効LastをOriginとする。内部EMAは`close−Origin`の差分を保持し、MACD/Signal/Histはその差分EMAから計算する。公開EMAだけOriginを足し戻す。`Technical.Origin/CenteredEMA12/CenteredEMA26`も保存する。絶対価格の相殺を減らす数値表現であり、epsilonによる判定変更はない。
- 仮値は前確定EMA/Signalから現在prefix closeを1回だけ入れた値。次tickへ仮EMAを累積しない。初期化を未確定足の途中へ前倒ししない。`Committed`とprefix Technical、TR、PreviousATRを分ける。
- `Cold`は確定Hist/ATRのどちらかが未知。ColdやATR0でも、外部H0の取得価格床を無効にする指示は出さない。

BankSnapshotのSHA256はSHA欄を空にした全公開JSONの指紋。ValidateSnapshotはこれと、場/現在原行/足の時計/出典/連続窓を照合する。Snapshot/Recent/Prefix/Gapの消費者変更はBankや以前返した値へ影響しない。

## 取得後の波とarm

取得後3本の符号付き安値をd、上値をuとし、中心が`d_i<d_left AND d_i<=d_right`なら右足公表で候補にする。全3足のStart>=Fill.Time、First.Index/Line>=Fill.Index/Lineを要求し、取得途中足を除外する。支持価格Bは取得価格より有利側、`z=max(u_left,u_center,u_right)`を保存する。

候補確認後の別確定足でcloseがzをstrictに越え、Histが取得方向に正、前ATRが既知かつ正で、その実配送原行のActiveが真ならarmする。A_armは突破足のPreviousATRを固定する。新しい支持は有効支持より有利なものだけ。

**Root確定補足：前closeからの再クロスは要求しない。** inactive中に古いClosedNowがzを越えても、それを後Rawに持ち越してarmしない。ただし、後で新しい別足が実公表され、再びclose>z/Hist順側/前ATR正/Active真なら、その新しいcloseでarmできる。候補の初回breakを消費して永久無効にする方式ではない。元の[仮説案](../117短期複合保護の仮説案/仮説案.md)の「初めて」を、この配送寿命として明確化した。

Active偽でも候補は形成する。同RawのpreではActive偽、afterで真になった場合、同原行の新ClosedNowでarm可能。旧Candidateのarm判定を先に準備し、その後に当原行の新3本候補を登録するので、新候補が同時に見つかっても有効だった旧候補の確認を消さない。

## S/M/Vと固定狭幅

有効支持B、当原行までのLast=C、現在足始値Oを用いる。

```
S = s(C−B)<0
M = s*provisional_Hist <= 0
V = s(C−O)<0 AND TR_prefix>=PreviousATR AND PreviousATR>0
Warning = Armed AND S AND M AND V
TargetWidth = ceil5(max(5,min(Entry.NormalWidthPoints,A_arm)))
```

Hist=0はM真、支持等号はS偽、body0はV偽。ATR0は既知の尺度偽、未知は情報不足。三値はUnknown=0/False=1/True=2、ANDでは既知偽が優先するが、他票のMissingは落とさない。M/Vは未armでも生観測を返し、Armed偽ならWarningは真にしない。

最初のWarning真でNarrowed/TargetWidthを不可逆に固定する。Unknown、Hist/価格回復、新支持、ATR変化、gapでも既幅を広げず、次のA_armへ付け替えない。幅上限と同じなら狭幅の追加効果0。Decisionは価格床や注文量を返さず、外部金額保護がこの幅と既存床を合成する。

QuoteにBBOを含めない。Lastが有効なら警戒の成立は計算できるが、金額保護の正常Mark、W起動、幅の価格床への適用、返済要求/約定は別APIの責務。`FirstWarning`には支持/別確定足/prefix/S/M/V/A_arm/幅/原行/phase/BankSHAをcopy固定する。

## 同原行と所有位相

- 新Rawでは足/候補を一度だけ更新。pre→afterの同Rawでは再形成しないが、外部Activeが変わればarm/警戒を再評価できる。
- 同じphase/同じBankSHA・Quote/同じActive・Remainingは冪等で、Sequenceや初回イベントを増やさない。返却Duplicate=true、イベントNowはfalse、既幅は返す。予約後の同phase再同期に使える。
- 同phaseの入力変更、after→pre、原行/Epoch逆行、Active真→偽、実残数量の増加、別Scope、取得前入力を拒否する。Remainingは位相差での部分返済減少を許す。予約rや実現Rは扱わない。
- 3分公表reset時のMarknil金額再同期やtimerのために監視を仮評価しない。現在のBankSnapshot原行時刻が一致するときだけCallerが供給する。
- gapではCandidate/Armed/A_armをresetし、既Narrowed/TargetWidth/初回Witnessを保持。外部Activeや金額床を消す指示はない。

## 人工と再現

```
go test -v -count=1 ./...
go vet ./...
go build ./...
```

主14テストとexport1を分ける。主人工にはcold本数、境界/同秒別行、仮評価非累積、欠足、価格平行移動/鏡像、500足収束、取得途中足、inactive候補、実配送原行限定/新別足再確認、初回after、同位相冪等、部分残量/n0、S/M/Vの未知/0/等号、支持同値規約、幅ceil/上限、gap/回復後固定、参照分離、未来追加不干渉がある。

`SHORTWAVE117_EXPORT_DIR`を本folder内へ明示してTestExportArtificialだけを実行すると、買売2系列/94Advanceを保存する。各caseは全手製quotes（cold助走を含む）、Entry/初期Snapshot、各Before/Input/After/Decisionを持つ。市場/FAR自然生成/金額State/注文はfalse。自然Rawの全行配送・最初性、金融効果の証明ではない。

[人工_独立用/人工の参照.json](人工_独立用/人工の参照.json)は独立検算用のFileRef。[検査/停止前の確認.json](検査/停止前の確認.json)へ主人工/vet/build/exportと所有SHA前後を記録する。正式停止・金融実行はRootの別固定まで行わない。
