package shortwave117

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
)

// finite は有限入力か検査します。
//
// 引数: values(...float64)。返り値: boolは全て有限なら真です。
func finite(values ...float64) bool {
	for _, x := range values {
		if math.IsNaN(x) || math.IsInf(x, 0) {
			return false
		}
	}
	return true
}

// abs は価格差の絶対値を返します。
//
// 引数: x(float64)。返り値: float64。
func abs(x float64) float64 { return math.Abs(x) }

// known は既知値を作ります。
//
// 引数: x(float64)。返り値: Value。
func known(x float64) Value { return Value{Known: true, Value: x} }

// ptr は独立した数値参照を作ります。
//
// 引数: x(float64)。返り値: *float64。
func ptr(x float64) *float64 { return &x }

// cloneFloat はnilも保持して参照分離します。
//
// 引数: x(*float64)。返り値: *float64。
func cloneFloat(x *float64) *float64 {
	if x == nil {
		return nil
	}
	return ptr(*x)
}

// cloneBar は足の参照を分離します。
//
// 引数: x(*Bar)。返り値: *Bar。Bar内部は値だけです。
func cloneBar(x *Bar) *Bar {
	if x == nil {
		return nil
	}
	v := *x
	return &v
}

// cloneBank は数値・足・gapを消費者から私有化します。
//
// 引数: x(BankSnapshot)。返り値: BankSnapshot。
func cloneBank(x BankSnapshot) BankSnapshot {
	x.LatestClosed = cloneBar(x.LatestClosed)
	x.ClosedNow = cloneBar(x.ClosedNow)
	x.Prefix = cloneBar(x.Prefix)
	if x.Gap != nil {
		g := *x.Gap
		x.Gap = &g
	}
	if x.RecentClosed != nil {
		x.RecentClosed = append([]Bar{}, x.RecentClosed...)
	}
	return x
}

// cloneSupport は支持の参照を分離します。
//
// 引数: x(*Support)。返り値: *Support。
func cloneSupport(x *Support) *Support {
	if x == nil {
		return nil
	}
	v := *x
	return &v
}

// cloneValues は警戒の任意数値を分離します。
//
// 引数: x(Values)。返り値: Values。
func cloneValues(x Values) Values {
	x.SignedCloseMinusSupport = cloneFloat(x.SignedCloseMinusSupport)
	x.SignedHistogram = cloneFloat(x.SignedHistogram)
	x.SignedBody = cloneFloat(x.SignedBody)
	return x
}

// cloneWitness は過去の初回根拠を独立copyで返します。
//
// 引数: x(*Witness)。返り値: *Witness。
func cloneWitness(x *Witness) *Witness {
	if x == nil {
		return nil
	}
	v := *x
	v.Support = cloneSupport(v.Support)
	v.Breakout = cloneBar(v.Breakout)
	v.Prefix = cloneBar(v.Prefix)
	v.Values = cloneValues(v.Values)
	v.TargetWidthPoints = cloneFloat(v.TargetWidthPoints)
	return &v
}

// cloneView は監視公開状態の全参照を分離します。
//
// 引数: x(Snapshot)。返り値: Snapshot。
func cloneView(x Snapshot) Snapshot {
	if x.At != nil {
		q := *x.At
		x.At = &q
	}
	x.Candidate = cloneSupport(x.Candidate)
	x.ArmedSupport = cloneSupport(x.ArmedSupport)
	x.Breakout = cloneBar(x.Breakout)
	x.TargetWidthPoints = cloneFloat(x.TargetWidthPoints)
	x.FirstArm = cloneWitness(x.FirstArm)
	x.LastArm = cloneWitness(x.LastArm)
	x.FirstWarning = cloneWitness(x.FirstWarning)
	x.LastReset = cloneWitness(x.LastReset)
	return x
}

// cloneDecision は冪等返却も参照分離します。
//
// 引数: x(Decision)。返り値: Decision。
func cloneDecision(x Decision) Decision {
	x.TargetWidthPoints = cloneFloat(x.TargetWidthPoints)
	x.Values = cloneValues(x.Values)
	if x.Missing != nil {
		x.Missing = append([]string{}, x.Missing...)
	}
	if x.Denied != nil {
		x.Denied = append([]string{}, x.Denied...)
	}
	return x
}

// validScope は独立bankの場と限月を検査します。
//
// 引数: s(Scope)。返り値: bool。
func validScope(s Scope) bool {
	return s.Session != "" && s.Contract != "" && finite(s.Start) && s.Start > 0 && s.Start <= 1e12
}

// validQuote はSource受理済みの原行識別子と有効Lastを検査します。
//
// 引数: q(Quote)、s(Scope)。返り値: bool。BBOの正常性はこの型の責務外です。
func validQuote(q Quote, s Scope) bool {
	return validScope(s) && finite(q.Time, q.Last) && q.Time >= s.Start && q.Time <= 1e12 && q.Last > 0 && q.Last <= 1e9 && q.Index >= 0 && q.SourceLine > 0
}

// validValue は未知/既知を保持して有限値か確認します。
//
// 引数: v(Value)。返り値: bool。未知はゼロ格納だけを許します。
func validValue(v Value) bool { return finite(v.Value) && (v.Known || v.Value == 0) }

// fingerprint は出典付きbankの全公開値を固定JSONで認証します。
//
// 引数: s(BankSnapshot)。返り値: string/error。SHA欄自身は除きます。
func fingerprint(s BankSnapshot) (string, error) {
	s.SHA256 = ""
	b, err := json.Marshal(s)
	if err != nil {
		return "", err
	}
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:]), nil
}

// ValidateSnapshot はbank公開物の場・現在原行・数値・内容指紋を検査します。
//
// 引数: s(BankSnapshot)。返り値: errorは改変又は不正です。金額は検査しません。
func ValidateSnapshot(s BankSnapshot) error {
	if s.Version != 117 || !s.HaveQuote || !validQuote(s.Quote, s.Scope) || s.Prefix == nil || s.Prefix.Complete || s.Prefix.Last != s.Quote || s.Prefix.Published != s.Quote || s.Quote.Time < s.Prefix.Start || s.Quote.Time >= s.Prefix.End || s.Prefix.Start < s.Scope.Start || len(s.RecentClosed) > 4 || s.ResetCount < 0 || s.Epoch != uint64(s.ResetCount) || s.ClosedBars < 0 || s.TotalClosedBars < s.ClosedBars {
		return fmt.Errorf("117現在prefix/場/時計が不正")
	}
	checkBar := func(b Bar) bool {
		if b.ID == "" || b.End-b.Start != 60 || b.Count < 1 || !validQuote(b.First, s.Scope) || !validQuote(b.Last, s.Scope) || !validQuote(b.Published, s.Scope) || b.First.Index > b.Last.Index || b.Last.Index > b.Published.Index || b.Published.Index > s.Quote.Index || b.First.SourceLine > b.Last.SourceLine || b.Last.SourceLine > b.Published.SourceLine || b.Published.SourceLine > s.Quote.SourceLine || b.First.Time < b.Start || b.First.Time > b.Last.Time || b.Last.Time >= b.End || b.Last.Time > b.Published.Time || b.Published.Time > s.Quote.Time || b.High < b.Low || b.High < max(b.Open, b.Close) || b.Low > min(b.Open, b.Close) || !finite(b.Open, b.High, b.Low, b.Close) || b.Low <= 0 {
			return false
		}
		for _, v := range []Value{b.TR, b.PreviousATR, b.Technical.Origin, b.Technical.CenteredEMA12, b.Technical.CenteredEMA26, b.Technical.EMA12, b.Technical.EMA26, b.Technical.MACD, b.Technical.Signal, b.Technical.Histogram, b.Technical.ATR} {
			if !validValue(v) {
				return false
			}
		}
		return !b.Complete || b.Published.Time >= b.End
	}
	if !checkBar(*s.Prefix) {
		return fmt.Errorf("117prefix値が不正")
	}
	for i, b := range s.RecentClosed {
		if !b.Complete || !checkBar(b) {
			return fmt.Errorf("117確定足が不正")
		}
		if i > 0 && s.RecentClosed[i-1].End != b.Start {
			return fmt.Errorf("117連続確定窓が不正")
		}
	}
	for _, b := range []*Bar{s.LatestClosed, s.ClosedNow} {
		if b != nil && (!b.Complete || !checkBar(*b)) {
			return fmt.Errorf("117最新確定足が不正")
		}
	}
	if (len(s.RecentClosed) == 0) != (s.LatestClosed == nil) || s.LatestClosed != nil && (*s.LatestClosed != s.RecentClosed[len(s.RecentClosed)-1] || s.LatestClosed.End != s.Prefix.Start || s.LatestClosed.Technical != s.Committed) {
		return fmt.Errorf("117最新確定/committedの結合差")
	}
	if s.ClosedNow != nil && s.ClosedNow.Published != s.Quote {
		return fmt.Errorf("117今回確定の配送原行差")
	}
	got, err := fingerprint(s)
	if err != nil || got != s.SHA256 {
		return fmt.Errorf("117公表内容SHA差")
	}
	return nil
}

// and は未知をゼロ扱いしない三値ANDを計算します。
//
// 引数: values(...Truth)。返り値: Truth。既知偽が優先します。
func and(values ...Truth) Truth {
	result := True
	for _, v := range values {
		if v == False {
			return False
		}
		if v == Unknown {
			result = Unknown
		}
	}
	return result
}

// truth は既知比較を三値へ写します。
//
// 引数: value(bool)。返り値: Truth。
func truth(value bool) Truth {
	if value {
		return True
	}
	return False
}
