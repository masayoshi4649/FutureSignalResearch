package shortwave117

import (
	"math"
	"reflect"
	"testing"
)

type scenario struct {
	f     *feed
	state State
	last  Decision
}

// newScenario は数値coldを実bankの手製行で暖機し、最後の実取得行から監視を始めます。
//
// 引数: t(*testing.T)、side(int)。返り値: *scenario。自然Source/市場を生成しません。
func newScenario(t *testing.T, side int) *scenario {
	var transform func(float64) float64
	if side < 0 {
		transform = func(x float64) float64 { return 2000 - x }
	}
	f := newFeed(t, transform)
	for i := 0; i < 39; i++ {
		f.bar(i, 1050, 1060, 1040, 1050, nil)
	}
	snap := f.bar(39, 1050, 1060, 1000, 1000, nil)
	state, err := NewState(Entry{Scope: testScope(), PositionID: "実取得の手製玉", Side: side, Price: 1000, Fill: snap.Quote, InitialQuantity: 2, NormalWidthPoints: 200})
	if err != nil {
		t.Fatal(err)
	}
	s := &scenario{f: f, state: state}
	s.advance(snap, AfterSource, false, 2)
	return s
}

// advance は人工監視を一位相だけ進めます。
//
// 引数: snap(BankSnapshot)、phase(Phase)、active(bool)、n(int)。返り値: Decision。
func (s *scenario) advance(snap BankSnapshot, phase Phase, active bool, n int) Decision {
	s.f.t.Helper()
	next, d, err := Advance(s.state, Input{Snapshot: snap, Phase: phase, Active: active, Remaining: n})
	if err != nil {
		s.f.t.Fatal(err)
	}
	s.state = next
	s.last = d
	return d
}

// both は同じ原行のpre/afterへ共通Activeを供給します。
//
// 引数: snap(BankSnapshot)、active(bool)。返り値: なし。
func (s *scenario) both(snap BankSnapshot, active bool) {
	s.advance(snap, PreFill, active, 2)
	s.advance(snap, AfterSource, active, 2)
}

// buildWave は取得後三本と別の突破足を形成します。
//
// 引数: active(bool)。返り値: BankSnapshotは突破足を実公表した原行です。
func (s *scenario) buildWave(active bool) BankSnapshot {
	visit := func(b BankSnapshot) { s.both(b, active) }
	s.f.bar(40, 1060, 1070, 1050, 1060, visit)
	s.f.bar(41, 1060, 1060, 1040, 1050, visit)
	s.f.bar(42, 1050, 1060, 1050, 1060, visit)
	s.f.bar(43, 1050, 1090, 1050, 1080, func(b BankSnapshot) {
		s.both(b, active)
		if s.state.view.Armed {
			s.f.t.Fatal("突破足の途中でarmした")
		}
	})
	if s.state.view.Candidate == nil || s.state.view.Candidate.SignedBoundary != 40 || s.state.view.Candidate.SignedCeiling != 70 {
		s.f.t.Fatal("3本支持", s.state.view.Candidate)
	}
	return s.f.step(44, 0, 1070)
}

// armAndWarn は同Raw Active切替と現在prefixの複合警戒を実bank経由で作ります。
//
// 引数: s(*scenario)。返り値: BankSnapshotは最初警戒原行です。
func armAndWarn(s *scenario) BankSnapshot {
	t := s.f.t
	t.Helper()
	published := s.buildWave(false)
	pre := s.advance(published, PreFill, false, 2)
	if pre.Armed || pre.ArmedNow {
		t.Fatal("inactiveでarm")
	}
	after := s.advance(published, AfterSource, true, 2)
	if !after.ArmedNow || !after.Armed {
		t.Fatal("同Raw afterでarmしない", after)
	}
	view := s.state.Snapshot()
	if view.ArmedSupport.Confirmed.Index >= view.Breakout.Published.Index || view.Breakout.End <= view.ArmedSupport.Right.End || view.FirstArm.At != published.Quote || view.FirstArm.Phase != AfterSource {
		t.Fatal("確認とarmのasof")
	}
	s.both(s.f.step(44, 1, 1080), true)
	equal := s.f.step(44, 2, 1040)
	s.both(equal, true)
	if s.last.S != False || s.last.Narrowed {
		t.Fatal("支持等号で狭幅")
	}
	weak := s.f.step(44, 3, 1030)
	s.both(weak, true)
	if s.last.S != True || s.last.M != False || s.last.Narrowed {
		t.Fatal("Hist順側の押戻しで狭幅", s.last)
	}
	warn := s.f.step(44, 20, 1020)
	s.both(warn, true)
	if !s.last.Narrowed || s.last.Warning != True || s.last.S != True || s.last.M != True || s.last.V != True || s.state.view.FirstWarning == nil {
		t.Fatal("複合警戒", s.last)
	}
	return warn
}

// TestIntegratedWaveArmingAndWarningMirror は実bank→支持→別足→同Raw Active→複合警戒の買売鏡像を検査します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestIntegratedWaveArmingAndWarningMirror(t *testing.T) {
	a, b := newScenario(t, 1), newScenario(t, -1)
	qa, qb := armAndWarn(a), armAndWarn(b)
	if qa.Quote.Index != qb.Quote.Index || a.last.Warning != b.last.Warning || *a.last.TargetWidthPoints != *b.last.TargetWidthPoints || a.last.Values.TR != b.last.Values.TR || *a.last.Values.SignedHistogram != *b.last.Values.SignedHistogram || *a.last.Values.SignedBody != *b.last.Values.SignedBody {
		t.Fatal("監視の鏡像")
	}
	want := 5 * math.Ceil(a.state.view.AArm.Value/5)
	if *a.last.TargetWidthPoints != want || *a.last.TargetWidthPoints > 200 {
		t.Fatal("狭幅ceil/上限")
	}
	if a.state.view.FirstWarning.Support.Price != 1040 || b.state.view.FirstWarning.Support.Price != 960 {
		t.Fatal("支持価格の鏡像")
	}
}

// TestNoArmingExtensionAndInactiveCandidate はinactive候補と過去突破延命禁止を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestNoArmingExtensionAndInactiveCandidate(t *testing.T) {
	s := newScenario(t, 1)
	pub := s.buildWave(false)
	s.both(pub, false)
	if s.state.view.Candidate == nil || s.state.view.Armed {
		t.Fatal("inactive候補")
	}
	later := s.f.step(44, 1, 1080)
	s.both(later, true)
	if s.state.view.Armed {
		t.Fatal("過去突破を後Rawへ延命")
	}
	// 現足を本当に確定した次の別公表なら、同支持の新closeでarmできます。
	s.f.step(44, 50, 1080)
	newPub := s.f.step(45, 0, 1080)
	s.both(newPub, true)
	if !s.state.view.Armed {
		t.Fatal("新しい確定closeでarmしない")
	}
}

// TestSameRowIdempotencePartialAndFlat は同位相再同期/部分返済/n0/Active撤回を区別します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestSameRowIdempotencePartialAndFlat(t *testing.T) {
	s := newScenario(t, 1)
	pub := s.buildWave(false)
	s.advance(pub, PreFill, false, 2)
	s.advance(pub, AfterSource, true, 1)
	before := jsonBytes(t, s.state.Snapshot())
	same := s.advance(pub, AfterSource, true, 1)
	if !same.Duplicate || same.ArmedNow || same.CandidateNow || same.NarrowedNow || !reflect.DeepEqual(before, jsonBytes(t, s.state.Snapshot())) {
		t.Fatal("同位相の二重更新")
	}
	for _, in := range []Input{{Snapshot: pub, Phase: PreFill, Active: true, Remaining: 1}, {Snapshot: pub, Phase: AfterSource, Active: true, Remaining: 0}, {Snapshot: pub, Phase: AfterSource, Active: false, Remaining: 1}, {Snapshot: pub, Phase: AfterSource, Active: true, Remaining: 2}} {
		if _, _, err := Advance(s.state, in); err == nil {
			t.Fatal("逆位相/flat/Active撤回/数量増加")
		}
	}
}

// TestEntryInsideBarExcluded は取得途中足を三本の左側として使わないことを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestEntryInsideBarExcluded(t *testing.T) {
	s := newScenario(t, 1)
	s.f.step(40, 0, 1060)
	fill := s.f.step(40, 10, 1070)
	e := s.state.view.Entry
	e.Fill = fill.Quote
	st, err := NewState(e)
	if err != nil {
		t.Fatal(err)
	}
	s.state = st
	s.advance(fill, AfterSource, true, 2)
	s.both(s.f.step(40, 20, 1050), true)
	s.both(s.f.step(40, 50, 1060), true)
	visit := func(b BankSnapshot) { s.both(b, true) }
	s.f.bar(41, 1060, 1060, 1040, 1050, visit)
	s.f.bar(42, 1050, 1060, 1050, 1060, visit)
	s.f.bar(43, 1050, 1090, 1050, 1080, visit)
	s.both(s.f.step(44, 0, 1070), true)
	if s.state.view.Candidate != nil || s.state.view.Armed {
		t.Fatal("取得前高安を含む足で支持を作った")
	}
}

// TestVotesUnknownZeroAndFalse は各役割の未知/ゼロ/既知偽を局所手計算で検査します。
//
// 引数: t(*testing.T)。返り値: なし。これは公開器生成の証明ではなく三値式の境界人工です。
func TestVotesUnknownZeroAndFalse(t *testing.T) {
	v := Snapshot{Entry: Entry{Side: 1, Price: 1000}, Armed: true, ArmedSupport: &Support{Price: 1040}}
	p := Bar{Open: 1070, Close: 1020, TR: known(60), PreviousATR: known(20), Technical: Technical{Histogram: known(0)}}
	in := Input{Snapshot: BankSnapshot{Prefix: &p}}
	d := inspect(v, in)
	if d.Warning != True || d.M != True {
		t.Fatal("Hist等号")
	}
	p.Technical.Histogram = Value{}
	d = inspect(v, in)
	if d.M != Unknown || d.Warning != Unknown || len(d.Missing) == 0 {
		t.Fatal("Hist未知")
	}
	p.Technical.Histogram = known(0)
	p.PreviousATR = Value{}
	d = inspect(v, in)
	if d.V != Unknown || d.Warning != Unknown {
		t.Fatal("ATR未知")
	}
	p.PreviousATR = known(0)
	d = inspect(v, in)
	if d.V != False || d.Warning != False || len(d.Denied) == 0 {
		t.Fatal("ATR0を未知にした")
	}
	p.PreviousATR = known(20)
	p.TR = known(19)
	if inspect(v, in).V != False {
		t.Fatal("TR閾値")
	}
	p.TR = known(20)
	if inspect(v, in).V != True {
		t.Fatal("TR等号")
	}
	p.Open = p.Close
	if inspect(v, in).V != False {
		t.Fatal("body0")
	}
	p.Open = 1070
	p.Close = 1040
	p.Technical.Histogram = Value{}
	d = inspect(v, in)
	if d.S != False || d.Warning != False || len(d.Missing) == 0 {
		t.Fatal("支持等号と欠測を分離しない")
	}
}

// TestNarrowLatchGapCopyAndFuture は警戒後の幅固定/gap/初回Witness不変を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestNarrowLatchGapCopyAndFuture(t *testing.T) {
	s := newScenario(t, 1)
	armAndWarn(s)
	oldView := s.state.Snapshot()
	old := jsonBytes(t, oldView)
	width := *oldView.TargetWidthPoints
	copy := s.state.Snapshot()
	copy.FirstWarning.Support.Price = 1
	copy.FirstWarning.Prefix.Technical.Histogram.Value = 99
	*copy.TargetWidthPoints = 5
	if !reflect.DeepEqual(old, jsonBytes(t, s.state.Snapshot())) {
		t.Fatal("公開Snapshot参照共有")
	}
	recovery := s.f.step(44, 30, 1090)
	s.both(recovery, true)
	if !s.last.Narrowed || *s.last.TargetWidthPoints != width {
		t.Fatal("回復で幅が緩んだ")
	}
	gapped := s.f.step(48, 0, 1050)
	s.both(gapped, true)
	if s.state.view.Armed || !s.state.view.Narrowed || *s.last.TargetWidthPoints != width || s.state.view.LastReset == nil {
		t.Fatal("gapで既ラッチを消した")
	}
	if !reflect.DeepEqual(jsonBytes(t, oldView.FirstWarning), jsonBytes(t, s.state.Snapshot().FirstWarning)) || !reflect.DeepEqual(old, jsonBytes(t, oldView)) {
		t.Fatal("未来で初回/過去を変更")
	}
}

// TestScopeFutureAndFirstAfter は初回after開始と場/時計/公表改変の拒否を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestScopeFutureAndFirstAfter(t *testing.T) {
	s := newScenario(t, 1)
	bank := s.f.bank.Snapshot()
	fresh, err := NewState(s.state.view.Entry)
	if err != nil {
		t.Fatal(err)
	}
	if _, _, err = Advance(fresh, Input{Snapshot: bank, Phase: AfterSource, Active: false, Remaining: 2}); err != nil {
		t.Fatal("初回after拒否", err)
	}
	x := cloneBank(bank)
	x.Scope.Contract = "別限月"
	x.SHA256, _ = fingerprint(x)
	if _, _, err = Advance(fresh, Input{Snapshot: x, Phase: AfterSource, Remaining: 2}); err == nil {
		t.Fatal("別場")
	}
	x = cloneBank(bank)
	x.Prefix.Published.Time += 120
	x.SHA256, _ = fingerprint(x)
	if _, _, err = Advance(fresh, Input{Snapshot: x, Phase: AfterSource, Remaining: 2}); err == nil {
		t.Fatal("未来公表")
	}
	x = cloneBank(bank)
	x.Prefix.Close += 5
	if _, _, err = Advance(fresh, Input{Snapshot: x, Phase: AfterSource, Remaining: 2}); err == nil {
		t.Fatal("内容SHA差")
	}
}

// TestPivotTiesAndEntryWidthCap は左厳密/右同値可と外部通常幅の上限を実bankで検査します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestPivotTiesAndEntryWidthCap(t *testing.T) {
	for _, leftEqual := range []bool{false, true} {
		s := newScenario(t, 1)
		leftLow := 1050.0
		if leftEqual {
			leftLow = 1040
		}
		visit := func(b BankSnapshot) { s.both(b, true) }
		s.f.bar(40, 1060, 1070, leftLow, 1060, visit)
		s.f.bar(41, 1060, 1060, 1040, 1050, visit)
		s.f.bar(42, 1050, 1060, 1040, 1060, visit)
		q := s.f.step(43, 0, 1050)
		s.both(q, true)
		if (s.state.view.Candidate == nil) != leftEqual {
			t.Fatal("左右同値規約", leftEqual)
		}
	}
	s := newScenario(t, 1)
	e := s.state.view.Entry
	e.NormalWidthPoints = 10
	st, err := NewState(e)
	if err != nil {
		t.Fatal(err)
	}
	s.state = st
	s.advance(s.f.bank.Snapshot(), AfterSource, false, 2)
	armAndWarn(s)
	if *s.last.TargetWidthPoints != 10 {
		t.Fatal("通常幅を超える短期幅")
	}
}

// TestArmingNeedsKnownPositiveATRAndHist はarmの既知性/ゼロを独立した境界人工で確認します。
//
// 引数: t(*testing.T)。返り値: なし。実bank正例の入力一点だけを変えます。
func TestArmingNeedsKnownPositiveATRAndHist(t *testing.T) {
	s := newScenario(t, 1)
	pub := s.buildWave(false)
	p := s.state.view.Candidate
	b := *pub.ClosedNow
	e := s.state.view.Entry
	if !armable(p, &b, e, pub.Quote) {
		t.Fatal("元の実bank正例")
	}
	for _, a := range []Value{{}, known(0), known(-1)} {
		x := b
		x.PreviousATR = a
		if armable(p, &x, e, pub.Quote) {
			t.Fatal("arm ATR不適格")
		}
	}
	for _, h := range []Value{{}, known(0), known(-1)} {
		x := b
		x.Technical.Histogram = h
		if armable(p, &x, e, pub.Quote) {
			t.Fatal("arm Hist不適格")
		}
	}
	x := b
	x.Published.Index--
	if armable(p, &x, e, pub.Quote) {
		t.Fatal("旧公表原行")
	}
}
