"""117短期moduleの人工だけを確認する。正式停止や金融を実行しない。"""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

BASE=Path(__file__).resolve().parent


def sha(path:Path)->str:
    """
    機能: 所有コードまたは手製証拠の指紋を計算する。
    引数: path(Path)。返り値: str。市場入力を渡さない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def owned()->dict:
    """
    機能: module直下のコード/仕様を収集する。
    引数: なし。返り値: dict[str,str]。人工出力やcacheをコードへ数えない。
    """
    return {str(p):sha(p) for p in sorted(BASE.iterdir()) if p.is_file() and p.suffix in ('.go','.py','.md','.mod')}


def run(args:list[str],env:dict|None=None)->dict:
    """
    機能: 自然入力を持たないGo検査を実行する。
    引数: args(list[str])、env(dict|None)。返り値: dictは成功コマンドとログ。不成功は例外。
    """
    p=subprocess.run(args,cwd=BASE,env=env,capture_output=True,text=True,encoding='utf-8')
    if p.returncode:raise ValueError(f'人工失敗:{args}:{p.stdout}:{p.stderr}')
    return {'command':args,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}


def main()->None:
    """
    機能: 主14/export1/vet/buildを確認して正式停止前proofへ保存する。
    引数: なし。返り値: None。Rootレビュー前のため停止フラグはfalseに固定。
    """
    before=owned();out=BASE/'検査';out.mkdir(exist_ok=True)
    fmt=run(['gofmt','-l',*[str(p) for p in sorted(BASE.glob('*.go'))]])
    if fmt['stdout'].strip():raise ValueError('gofmt未適用')
    tests=run(['go','test','-v','-count=1','./...'])
    if len(re.findall(r'^--- PASS:',tests['stdout'],re.M))!=14:raise ValueError('主人工数差')
    vet=run(['go','vet','./...']);build=run(['go','build','./...'])
    env=dict(os.environ);env['SHORTWAVE117_EXPORT_DIR']=str(BASE/'人工_独立用')
    export=run(['go','test','-run','^TestExportArtificial$','-count=1','-v','.'],env)
    deps=run(['go','list','-deps','-f','{{if not .Standard}}{{.ImportPath}}{{end}}','.'])
    if deps['stdout'].split()!=['github.com/masayoshi4649/SessionTradeExecuter/shortwave117']:raise ValueError('外部依存差')
    after=owned()
    if before!=after:raise ValueError('所有前後差')
    manifest=BASE/'人工_独立用/人工の参照.json';m=json.loads(manifest.read_text(encoding='utf-8'));series=Path(m['系列']['path'])
    if sha(series)!=m['系列']['sha256'] or (m['系列数'],m['Advance数'])!=(2,94):raise ValueError('人工export認証差')
    proof={'成功':True,'停止':False,'市場前':True,'試行':117,'trial':117,'Rootレビュー前':True,'主人工':14,'export人工':1,'買売系列':2,'監視Advance':94,'市場/Raw/Native/価格CSV/11月09本文読取':0,'金融実行':False,'既停止物変更':0,'所有コードSHA256':after,'所有前後不変':before==after,'外部module依存':0,'金額State':False,'注文':False,'検査':[fmt,tests,vet,build,export,deps,run(['go','version'])],'人工の参照':{'path':str(manifest),'sha256':sha(manifest)},'人工系列':m['系列'],'注意':'保存点の独立人工。自然Raw/金融/全tick最初性未検証。正式停止ではない。'}
    p=out/'停止前の確認.json';p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'停止':False,'確認':{'path':str(p),'sha256':sha(p)},'人工の参照':proof['人工の参照'],'人工系列':m['系列']},ensure_ascii=False))


if __name__=='__main__':main()
