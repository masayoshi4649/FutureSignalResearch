package shortwave117

import (
	"encoding/json"
	"math"
	"reflect"
	"testing"
)

// testScope は市場と無関係な固定時計を返します。
//
// 引数: なし。返り値: Scope。
func testScope() Scope { return Scope{Session: "手製場", Contract: "手製限月", Start: 10000} }

type feed struct {
	t         *testing.T
	bank      *Bank
	index     int
	transform func(float64) float64
	quotes    []Quote
}

// newFeed は単独bankと原行カウンタを作ります。
//
// 引数: t(*testing.T)、transform(func(float64)float64|nil)。返り値: *feed。
func newFeed(t *testing.T, transform func(float64) float64) *feed {
	t.Helper()
	b, err := NewBank(testScope())
	if err != nil {
		t.Fatal(err)
	}
	if transform == nil {
		transform = func(x float64) float64 { return x }
	}
	return &feed{t: t, bank: b, transform: transform}
}

// step は実受理行に似せた一つの有限Lastを供給します。
//
// 引数: minute(int)、offset/price(float64)。返り値: BankSnapshot。index/lineは別に単調化します。
func (f *feed) step(minute int, offset, price float64) BankSnapshot {
	f.t.Helper()
	q := Quote{Time: testScope().Start + float64(minute)*60 + offset, Index: f.index, SourceLine: 2*f.index + 1, Last: f.transform(price)}
	f.index++
	f.quotes = append(f.quotes, q)
	s, err := f.bank.Step(q)
	if err != nil {
		f.t.Fatal(err)
	}
	if err = ValidateSnapshot(s); err != nil {
		f.t.Fatal(err)
	}
	return s
}

// bar はOHLC順序を明示した四つの原行を供給します。
//
// 引数: minute(int)、o/h/l/c(float64)、visit(func(BankSnapshot)|nil)。返り値: BankSnapshot。
func (f *feed) bar(minute int, o, h, l, c float64, visit func(BankSnapshot)) BankSnapshot {
	var s BankSnapshot
	for i, x := range []float64{o, h, l, c} {
		offset := []float64{0, 10, 20, 50}[i]
		s = f.step(minute, offset, x)
		if visit != nil {
			visit(s)
		}
	}
	return s
}

// jsonBytes は独立値の同体比較にJSONを使います。
//
// 引数: t(*testing.T)、v(any)。返り値: []byte。
func jsonBytes(t *testing.T, v any) []byte {
	t.Helper()
	b, err := json.Marshal(v)
	if err != nil {
		t.Fatal(err)
	}
	return b
}

// TestBankWarmupAndProvisional は34/15の確定本数とtickを足に累積しない仮評価を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestBankWarmupAndProvisional(t *testing.T) {
	f := newFeed(t, nil)
	var s BankSnapshot
	for i := 0; i <= 34; i++ {
		s = f.step(i, 0, 70000)
		if s.ClosedBars != i {
			t.Fatal(i, s.ClosedBars)
		}
		if s.Committed.ATR.Known != (i >= 15) || s.Committed.Histogram.Known != (i >= 34) {
			t.Fatal("助走", i, s.Committed)
		}
	}
	if s.Prefix.Technical.Histogram.Value != 0 || s.Prefix.PreviousATR.Value != 0 || !s.Prefix.PreviousATR.Known {
		t.Fatal("平坦は既知0")
	}
	previous := s.Committed
	x := f.step(34, 1, 70020)
	if x.Committed != previous || x.ClosedBars != 34 {
		t.Fatal("tickでcommitした")
	}
	y := f.step(34, 2, 70000)
	if y.Committed != previous || y.Prefix.Technical.Histogram.Value != 0 {
		t.Fatal("仮EMAを次tickへ累積した")
	}
	if y.Prefix.High != 70020 || y.Prefix.Low != 70000 || y.Prefix.Count != 3 {
		t.Fatal("prefix高安")
	}
}

// TestBankBoundariesGapAndCopy は境界前後/同秒別行/欠足/参照分離を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestBankBoundariesGapAndCopy(t *testing.T) {
	f := newFeed(t, nil)
	a := f.step(0, 59, 1000)
	b := f.step(1, 0, 1010)
	if a.ClosedNow != nil || b.ClosedNow == nil || b.ClosedNow.Close != 1000 || b.Prefix.Open != 1010 || b.ClosedNow.Published != b.Quote {
		t.Fatal("境界の所属/配送")
	}
	c := f.step(1, 0, 1020)
	if c.Prefix.Count != 2 || c.ClosedNow != nil {
		t.Fatal("同秒後行")
	}
	before := f.bank.Snapshot()
	old := jsonBytes(t, before)
	c.Prefix.Close = 999
	c.RecentClosed[0].Close = 999
	c.LatestClosed.Close = 999
	if !reflect.DeepEqual(old, jsonBytes(t, f.bank.Snapshot())) {
		t.Fatal("消費者変更がbankを変更")
	}
	q := before.Quote
	if _, err := f.bank.Step(q); err == nil {
		t.Fatal("同Index再投入を許可")
	}
	q.Index++
	q.SourceLine++
	q.Time--
	if _, err := f.bank.Step(q); err == nil {
		t.Fatal("時刻逆行を許可")
	}
	g := f.step(4, 0, 1030)
	if g.Gap == nil || g.Gap.MissingMinutes != 2 || g.Epoch != 1 || g.ClosedBars != 0 || len(g.RecentClosed) != 0 || !g.Cold || g.Prefix.PreviousATR.Known {
		t.Fatal("欠足reset", g)
	}
	if g.Prefix.Technical.Origin.Value != 1030 {
		t.Fatal("新Epoch Origin")
	}
	if !reflect.DeepEqual(jsonBytes(t, g), jsonBytes(t, f.bank.Snapshot())) {
		t.Fatal("Snapshot/EOFが足を変えた")
	}
}

// TestBankCenteredMirrorAndTranslation は価格平行移動/買売鏡像でHist符号とTRが揃うことを確認します。
//
// 引数: t(*testing.T)。返り値: なし。epsilonで判定の符号を変えません。
func TestBankCenteredMirrorAndTranslation(t *testing.T) {
	f := newFeed(t, nil)
	m := newFeed(t, func(x float64) float64 { return 140000 - x })
	shift := newFeed(t, func(x float64) float64 { return x + 300000 })
	for i := 0; i < 100; i++ {
		price := 70000 + float64((i%11)*5-i/11)
		for k, p := range []float64{price, price + 5, price - 10, price + 2} {
			offset := []float64{0, 10, 20, 50}[k]
			a := f.step(i, offset, p)
			b := m.step(i, offset, p)
			c := shift.step(i, offset, p)
			for _, field := range [][3]Value{{a.Prefix.Technical.Histogram, b.Prefix.Technical.Histogram, c.Prefix.Technical.Histogram}, {a.Prefix.Technical.MACD, b.Prefix.Technical.MACD, c.Prefix.Technical.MACD}, {a.Prefix.Technical.Signal, b.Prefix.Technical.Signal, c.Prefix.Technical.Signal}} {
				if field[0].Known != field[1].Known || field[0].Known != field[2].Known || field[0].Value != -field[1].Value || field[0].Value != field[2].Value {
					t.Fatal("中心化鏡像/平行移動", i, k, field)
				}
			}
			if a.Prefix.TR != b.Prefix.TR || a.Prefix.TR != c.Prefix.TR || a.Prefix.PreviousATR != b.Prefix.PreviousATR || a.Prefix.PreviousATR != c.Prefix.PreviousATR {
				t.Fatal("TR/ATRの平行移動")
			}
		}
	}
}

// TestBankAlmostConvergedAndFutureIndependent は収束近傍の鏡像と未来追加による過去不変を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestBankAlmostConvergedAndFutureIndependent(t *testing.T) {
	a := newFeed(t, nil)
	b := newFeed(t, func(x float64) float64 { return 140000 - x })
	var saved BankSnapshot
	for i := 0; i < 500; i++ {
		p := 70000.0
		if i == 0 {
			p += 5
		}
		x := a.step(i, 0, p)
		y := b.step(i, 0, p)
		if x.Prefix.Technical.Histogram.Value != -y.Prefix.Technical.Histogram.Value {
			t.Fatal("収束の鏡像符号")
		}
		if i == 80 {
			saved = x
		}
	}
	old := jsonBytes(t, saved)
	a.step(500, 0, 69900)
	if !reflect.DeepEqual(old, jsonBytes(t, saved)) {
		t.Fatal("未来が過去Snapshotを変更")
	}
	if math.IsNaN(a.bank.Snapshot().Prefix.Technical.Histogram.Value) {
		t.Fatal("非有限")
	}
}

// TestBankRejectsFutureTamperAndInvalid は未知ゼロを守り未来公表/生値改変を拒否します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestBankRejectsFutureTamperAndInvalid(t *testing.T) {
	f := newFeed(t, nil)
	s := f.step(0, 0, 1000)
	s.Prefix.Close = 1001
	if ValidateSnapshot(s) == nil {
		t.Fatal("内容改変が通過")
	}
	s = f.bank.Snapshot()
	s.Prefix.Published.Time += 100
	s.SHA256, _ = fingerprint(s)
	if ValidateSnapshot(s) == nil {
		t.Fatal("未来公表が通過")
	}
	for _, q := range []Quote{{Time: 10000, Index: 1, SourceLine: 3, Last: 0}, {Time: 10000, Index: 1, SourceLine: 3, Last: math.NaN()}, {Time: 9999, Index: 1, SourceLine: 3, Last: 1000}} {
		if _, err := f.bank.Step(q); err == nil {
			t.Fatal("不正Quote")
		}
	}
}
