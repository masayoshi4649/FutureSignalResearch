// Package shortwave117 は原行から当場coldの1分値を形成し、実建玉の短期複合警戒だけを判定します。
package shortwave117

type Truth uint8

const (
	Unknown Truth = iota
	False
	True
)

type Phase string

const (
	PreFill     Phase = "pre_fill"
	AfterSource Phase = "after_source"
)

type Scope struct {
	Session  string  `json:"session"`
	Contract string  `json:"contract"`
	Start    float64 `json:"start"`
}

type Quote struct {
	Time       float64 `json:"time"`
	Index      int     `json:"index"`
	SourceLine int     `json:"source_line"`
	Last       float64 `json:"last"`
}

type Value struct {
	Known bool    `json:"known"`
	Value float64 `json:"value"`
}

type Technical struct {
	Origin        Value `json:"origin"`
	CenteredEMA12 Value `json:"centered_ema12"`
	CenteredEMA26 Value `json:"centered_ema26"`
	EMA12         Value `json:"ema12"`
	EMA26         Value `json:"ema26"`
	MACD          Value `json:"macd"`
	Signal        Value `json:"signal"`
	Histogram     Value `json:"histogram"`
	ATR           Value `json:"atr"`
}

type Bar struct {
	ID          string    `json:"id"`
	Start       float64   `json:"start"`
	End         float64   `json:"end"`
	Complete    bool      `json:"complete"`
	First       Quote     `json:"first"`
	Last        Quote     `json:"last"`
	Published   Quote     `json:"published"`
	Count       int       `json:"count"`
	Open        float64   `json:"open"`
	High        float64   `json:"high"`
	Low         float64   `json:"low"`
	Close       float64   `json:"close"`
	TR          Value     `json:"tr"`
	PreviousATR Value     `json:"previous_atr"`
	Technical   Technical `json:"technical"`
}

type Gap struct {
	FromEnd        float64 `json:"from_end"`
	ToStart        float64 `json:"to_start"`
	MissingMinutes int     `json:"missing_minutes"`
	At             Quote   `json:"at"`
}

type BankSnapshot struct {
	Version         int       `json:"version"`
	Scope           Scope     `json:"scope"`
	HaveQuote       bool      `json:"have_quote"`
	Quote           Quote     `json:"quote"`
	Epoch           uint64    `json:"epoch"`
	ResetCount      int       `json:"reset_count"`
	Gap             *Gap      `json:"gap,omitempty"`
	ResetReason     string    `json:"reset_reason"`
	ClosedBars      int       `json:"closed_bars"`
	TotalClosedBars int       `json:"total_closed_bars"`
	Cold            bool      `json:"cold"`
	Committed       Technical `json:"committed"`
	LatestClosed    *Bar      `json:"latest_closed,omitempty"`
	RecentClosed    []Bar     `json:"recent_closed"`
	ClosedNow       *Bar      `json:"closed_now,omitempty"`
	Prefix          *Bar      `json:"prefix,omitempty"`
	SHA256          string    `json:"sha256"`
}

type Entry struct {
	Scope             Scope   `json:"scope"`
	PositionID        string  `json:"position_id"`
	Side              int     `json:"side"`
	Price             float64 `json:"price"`
	Fill              Quote   `json:"fill_quote"`
	InitialQuantity   int     `json:"initial_quantity"`
	NormalWidthPoints float64 `json:"normal_width_points"`
}

type Input struct {
	Snapshot  BankSnapshot `json:"bank_snapshot"`
	Phase     Phase        `json:"phase"`
	Active    bool         `json:"active"`
	Remaining int          `json:"remaining"`
}

type Support struct {
	ID             string  `json:"id"`
	Center         Bar     `json:"center"`
	Left           Bar     `json:"left"`
	Right          Bar     `json:"right"`
	Confirmed      Quote   `json:"confirmed"`
	Price          float64 `json:"price"`
	SignedBoundary float64 `json:"signed_boundary"`
	SignedCeiling  float64 `json:"signed_ceiling"`
}

type Values struct {
	SignedCloseMinusSupport *float64 `json:"signed_close_minus_support,omitempty"`
	SignedHistogram         *float64 `json:"signed_histogram,omitempty"`
	SignedBody              *float64 `json:"signed_body,omitempty"`
	TR                      Value    `json:"tr"`
	PreviousATR             Value    `json:"previous_atr"`
}

type Witness struct {
	Kind              string   `json:"kind"`
	At                Quote    `json:"at"`
	Phase             Phase    `json:"phase"`
	BankSHA256        string   `json:"bank_sha256"`
	BankEpoch         uint64   `json:"bank_epoch"`
	Support           *Support `json:"support,omitempty"`
	Breakout          *Bar     `json:"breakout,omitempty"`
	Prefix            *Bar     `json:"prefix,omitempty"`
	Values            Values   `json:"values"`
	S                 Truth    `json:"s"`
	M                 Truth    `json:"m"`
	V                 Truth    `json:"v"`
	Warning           Truth    `json:"warning"`
	AArm              Value    `json:"a_arm"`
	TargetWidthPoints *float64 `json:"target_width_points,omitempty"`
	Active            bool     `json:"active"`
	Remaining         int      `json:"remaining"`
}

type Snapshot struct {
	Version           int      `json:"version"`
	Entry             Entry    `json:"entry"`
	Sequence          uint64   `json:"sequence"`
	RawUpdates        uint64   `json:"raw_updates"`
	At                *Quote   `json:"at,omitempty"`
	Phase             Phase    `json:"phase"`
	BankEpoch         uint64   `json:"bank_epoch"`
	ExternalActive    bool     `json:"external_active"`
	Candidate         *Support `json:"candidate,omitempty"`
	Armed             bool     `json:"armed"`
	ArmedSupport      *Support `json:"armed_support,omitempty"`
	Breakout          *Bar     `json:"breakout,omitempty"`
	AArm              Value    `json:"a_arm"`
	Narrowed          bool     `json:"narrowed"`
	TargetWidthPoints *float64 `json:"target_width_points,omitempty"`
	FirstArm          *Witness `json:"first_arm,omitempty"`
	LastArm           *Witness `json:"last_arm,omitempty"`
	FirstWarning      *Witness `json:"first_warning,omitempty"`
	LastReset         *Witness `json:"last_reset,omitempty"`
}

type Decision struct {
	Duplicate         bool     `json:"duplicate"`
	NewRaw            bool     `json:"new_raw"`
	CandidateNow      bool     `json:"candidate_now"`
	ArmedNow          bool     `json:"armed_now"`
	ResetNow          bool     `json:"reset_now"`
	NarrowedNow       bool     `json:"narrowed_now"`
	Armed             bool     `json:"armed"`
	Narrowed          bool     `json:"narrowed"`
	TargetWidthPoints *float64 `json:"target_width_points,omitempty"`
	S                 Truth    `json:"s"`
	M                 Truth    `json:"m"`
	V                 Truth    `json:"v"`
	Warning           Truth    `json:"warning"`
	Values            Values   `json:"values"`
	Missing           []string `json:"missing"`
	Denied            []string `json:"denied"`
}

type Definition struct {
	Version               int    `json:"version"`
	NumericStart          string `json:"numeric_start"`
	NumericRepresentation string `json:"numeric_representation"`
	MACDFast              int    `json:"macd_fast"`
	MACDSlow              int    `json:"macd_slow"`
	MACDSignal            int    `json:"macd_signal"`
	ATRPeriod             int    `json:"atr_period"`
	MACDClosedBars        int    `json:"macd_closed_bars"`
	ATRClosedBars         int    `json:"atr_closed_bars"`
	PivotLeft             int    `json:"pivot_left"`
	PivotRight            int    `json:"pivot_right"`
	Arming                string `json:"arming"`
	Warning               string `json:"warning"`
	Width                 string `json:"width"`
	MoneyState            bool   `json:"money_state"`
	Orders                bool   `json:"orders"`
}

// DeclaredDefinition は当場cold・構造・仮数値・幅の実定義を返します。
//
// 引数: ありません。返り値: Definitionは金額Stateや注文を含まない不変値です。
func DeclaredDefinition() Definition {
	return Definition{Version: 117, NumericStart: "当場cold。欠足/場/限月reset。未確定は前確定stateから1回だけ仮評価", NumericRepresentation: "Epoch最初のLastをOriginとする差分EMAでMACD/Signal/Histを計算。公開EMAはOriginを足す。epsilonなし", MACDFast: 12, MACDSlow: 26, MACDSignal: 9, ATRPeriod: 14, MACDClosedBars: 34, ATRClosedBars: 15, PivotLeft: 1, PivotRight: 1, Arming: "実取得後3本折返し→確認後の別確定closeがceiling超/Hist順側/前ATR正。Active真かつ実配送原行のみ。新しい別足の再確認可、前closeからの再cross/初回break消費なし", Warning: "S strict逆抜け AND M Hist非正 AND V 反対body/TR>=前ATR正", Width: "最初警戒のA_armをceil5(max5,min(normal,A_arm))で一度固定。金額床は外部", MoneyState: false, Orders: false}
}
