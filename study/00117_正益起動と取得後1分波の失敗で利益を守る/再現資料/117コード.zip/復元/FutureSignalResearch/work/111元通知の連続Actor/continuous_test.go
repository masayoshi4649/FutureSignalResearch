package miniprotect

import (
	"bytes"
	"encoding/json"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	legacy "github.com/masayoshi4649/SessionTradeExecuter/miniprotect"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor111"
)

// newContinuousActors111 は明示した政策又は24条件の人工口座を作ります。
//
// 引数: t(*testing.T)、configs([]ActorConfig)は試験器と任意の部分集合。返り値: map[string]*ActualBookは独立口座です。
func newContinuousActors111(t *testing.T, configs []ActorConfig) map[string]*ActualBook {
	t.Helper()
	if configs == nil {
		configs = DeclaredContinuousConfigurations()
	}
	out := map[string]*ActualBook{}
	for _, cfg := range configs {
		b, err := NewContinuousBook(session94(), "人工限月111", cfg)
		if err != nil {
			t.Fatal(err)
		}
		out[b.result.Key] = b
	}
	return out
}

// publication111 は確定済み3分足の手製片側公表を作ります。
//
// 引数: session(Session)、side(int)、end(float64)、ordinal(uint64)、warning(bool)は人工条件。
// 返り値: guard.Publicationは原板由来ではない公表型です。
func publication111(session Session, side int, end float64, ordinal uint64, warning bool) guard.Publication {
	c, m := guard.False, guard.False
	if warning {
		c, m = guard.True, guard.True
	}
	v, close := 20.0, 1100.0
	if side < 0 {
		close = 2000 - close
	}
	return guard.Publication{Scope: guard.Scope{Session: session.ID, Contract: "人工限月111", Start: session.Start}, ID: "人工公表111/" + fmtOrdinal111(ordinal), Ordinal: ordinal,
		Start: end - 180, End: end, AvailableAt: end, C: c, M: m, V: &v, Close: &close}
}

// fmtOrdinal111 は人工IDだけに使う整数字句を返します。
//
// 引数: value(uint64)は公表番号。返り値: stringは10進の番号です。
func fmtOrdinal111(value uint64) string { raw, _ := json.Marshal(value); return string(raw) }

// TestContinuous24AndReject は実宣言24と旧人工入口の分離を確認します。
//
// 引数: t(*testing.T)は試験器。返り値: なし。
func TestContinuous24AndReject(t *testing.T) {
	configs := DeclaredContinuousConfigurations()
	if len(configs) != 24 {
		t.Fatal("24宣言ではない")
	}
	seen := map[string]bool{}
	for _, b := range newContinuousActors111(t, nil) {
		seen[b.result.Key] = true
	}
	if len(seen) != 24 {
		t.Fatal("宣言重複")
	}
	for _, c := range []ActorConfig{{"P0", 0, 0}, {"P1", 0, 0}, {"U100", 1, 0}, {"B50", 0, 2}, {"不明", 0, 0}} {
		if _, err := NewContinuousBook(session94(), "人工限月111", c); err == nil {
			t.Fatal("不正条件を受付", c)
		}
	}
	if _, err := NewContinuousBook(session94(), "", configs[0]); err == nil {
		t.Fatal("限月未知を受付")
	}
}

// TestContinuousS0ExactLegacy はS0の全結果JSONを旧94へ各配送点で同体照合します。
//
// 引数: t(*testing.T)は試験器。返り値: なし。StreamScopeだけ新111の明示差です。
func TestContinuousS0ExactLegacy(t *testing.T) {
	for _, f := range []fixture94{wave94(t, 1, false), wave94(t, -1, true), capCancel94(t)} {
		for _, cfg := range DeclaredContinuousConfigurations() {
			if cfg.Policy != "S0" {
				continue
			}
			b, _ := NewContinuousBook(f.Session, "人工限月111", cfg)
			old, err := legacy.NewActualBook(f.Session, legacy.ActorConfig{Policy: cfg.Policy, SlipPts: cfg.SlipPts, DelaySeconds: cfg.DelaySeconds})
			if err != nil {
				t.Fatal(err)
			}
			for _, step := range f.Steps {
				batches := []legacy.NativeBatch{}
				for _, batch := range step.Batches {
					batches = append(batches, legacy.NativeBatch{Method: batch.Method, Delta: batch.Delta})
				}
				if err = b.OnNativeStep(step.Observation, step.SourceLine, step.Batches); err != nil {
					t.Fatal(err)
				}
				if err = old.OnNativeStep(step.Observation, step.SourceLine, batches); err != nil {
					t.Fatal(err)
				}
				current, prior := b.Snapshot(), old.Snapshot()
				if current.StreamScope != ContinuousScope111 {
					t.Fatal("111scopeがない")
				}
				current.StreamScope = prior.StreamScope
				got, _ := json.Marshal(current)
				want, _ := json.Marshal(prior)
				if !bytes.Equal(got, want) {
					t.Fatalf("S0全JSON差:%s,index%d", b.result.Key, step.Observation.Index)
				}
			}
			current, err := b.Finish()
			if err != nil {
				t.Fatal(err)
			}
			prior, err := old.Finish()
			if err != nil {
				t.Fatal(err)
			}
			current.StreamScope = prior.StreamScope
			got, _ := json.Marshal(current)
			want, _ := json.Marshal(prior)
			if !bytes.Equal(got, want) {
				t.Fatal("S0 Finish全JSON差")
			}
		}
	}
}

// fullWave111 は24条件の利益起動・実後原行返済・Source独立完結を作ります。
//
// 引数: t(*testing.T)、side(int)は試験器と鏡像。返り値: map[string]ActualResultは全24完結結果です。
func fullWave111(t *testing.T, side int) map[string]ActualResult {
	t.Helper()
	return selectedWave111(t, side, nil)
}

// selectedWave111 は候補集合を変えても同じ元通知列だけを配送します。
//
// 引数: t(*testing.T)、side(int)、configs([]ActorConfig)は試験器・鏡像・候補集合。
// 返り値: map[string]ActualResultは独立した完結口座です。
func selectedWave111(t *testing.T, side int, configs []ActorConfig) map[string]ActualResult {
	t.Helper()
	return continuousFixture111(t, side, configs).Actors
}

// continuousFixture111 は入力原行と24結果を同じ手製Sourceから保存します。
//
// 引数: t(*testing.T)、side(int)、configs([]ActorConfig)は試験器と人工条件。
// 返り値: fixture94は元戦略を動かさない入力と新24政策の結果です。
func continuousFixture111(t *testing.T, side int, configs []ActorConfig) fixture94 {
	t.Helper()
	actors := newContinuousActors111(t, configs)
	source := newFixtureSource94()
	session := session94()
	fixture := fixture94{Session: session, Scope: "111の手製API原行/Source通知。実FAR生成・市場価格・CSV・Rawなし。", Steps: []fixtureStep94{}, Timers: []fixtureTimer94{}}
	moves := []float64{0, 0, 130, 400, 50, 70, 70, 0, 0}
	for i, move := range moves {
		o := observation94(session, side, int64(i), float64(i), move, 20)
		news := []native.Signal{}
		if i == 0 {
			news = append(news, birth94("A", side, 5))
		}
		if i == 7 {
			news = append(news, close94("元全残A", "A", side, 5))
		}
		batch := source.step(t, o, int64(i+100), news, nil)
		fixture.Steps = append(fixture.Steps, feed94(t, actors, o, batch))
	}
	out := finish94(t, actors)
	for _, r := range out {
		if r.Config.Policy == "S0" {
			continue
		}
		p := r.Positions[0]
		if p.Protection111 == nil || !p.Protection111.FinalState.Finished || p.Protection111.FirstActivation == nil || p.Protection111.FirstFloorHit == nil {
			t.Fatal("純状態/完結/起動/初hit不足", r.Key)
		}
		if p.Protection111.Initial.NormalWidth != 200 || p.ATR == nil || p.ATR.Width != 200 || p.ATR.AfterEntry {
			t.Fatal("取得時幅の固定差", r.Key)
		}
		for _, o := range r.Orders {
			if o.ProtectionPoint == nil {
				continue
			}
			if o.ProtectionPoint.Phase != PhaseAfterSource || o.Quantity <= 0 {
				t.Fatal("前位相で新注文", r.Key)
			}
			for _, f := range r.Fills {
				if f.OrderID == o.ID && (f.Quote.Index <= o.RequestQuote.Index || f.Quote.Time < o.RequestTime+float64(r.Config.DelaySeconds)) {
					t.Fatal("架空同原行/遅延fill", r.Key)
				}
			}
		}
	}
	fixture.Actors = out
	return fixture
}

// TestContinuousAllMirrorAndRealFill は全24の鏡像と予定床を使わない実約定を確認します。
//
// 引数: t(*testing.T)は試験器。返り値: なし。
func TestContinuousAllMirrorAndRealFill(t *testing.T) {
	buy, sell := fullWave111(t, 1), fullWave111(t, -1)
	for key, b := range buy {
		if b.Totals != sell[key].Totals {
			t.Fatal("111鏡像の費用後額差", key)
		}
	}
}

// TestContinuousPartialWholeAndReserved はu正W負と予約優先・部分fill後の全玉床を検査します。
//
// 引数: t(*testing.T)は試験器。返り値: なし。
func TestContinuousPartialWholeAndReserved(t *testing.T) {
	actors := newContinuousActors111(t, []ActorConfig{{"U100", 0, 0}, {"W100", 0, 0}, {"B50", 0, 0}})
	source := newFixtureSource94()
	session := session94()
	moves := []float64{0, 0, -300, -300, 150, 150, 600, 10, 10, 0, 0}
	for i, move := range moves {
		o := observation94(session, 1, int64(i), float64(i), move, 20)
		news := []native.Signal{}
		if i == 0 {
			news = append(news, birth94("A", 1, 2))
		}
		if i == 2 {
			news = append(news, close94("半分", "A", 1, 1))
		}
		if i == 9 {
			news = append(news, close94("残り", "A", 1, 1))
		}
		batch := source.step(t, o, int64(i+200), news, nil)
		feed94(t, actors, o, batch)
		if i == 4 {
			u := actors["U100_C0_D0"].Snapshot().Positions[0]
			w := actors["W100_C0_D0"].Snapshot().Positions[0]
			if !u.ProtectionActive || w.ProtectionActive || u.Marks.Last.UnitNet <= 0 || u.Marks.Last.WholeNet >= 0 {
				t.Fatal("u正/W負の起動分離")
			}
		}
		if i == 6 {
			p := actors["W100_C0_D0"].Snapshot().Positions[0]
			if !p.ProtectionActive || p.Protection111.FinalState.WholeTargetYen < 0 || *p.FloorGain < 315 {
				t.Fatal("部分返済後の全玉床", p.FloorGain)
			}
		}
	}
	_ = finish94(t, actors)
}

// TestContinuousPublicationNarrowAndReset はside別公表・狭幅ラッチ・欠足失効を確認します。
//
// 引数: t(*testing.T)は試験器。返り値: なし。
func TestContinuousPublicationNarrowAndReset(t *testing.T) {
	actors := newContinuousActors111(t, []ActorConfig{{"T100", 0, 0}, {"W100", 0, 0}})
	source := newFixtureSource94()
	session := session94()
	for i, move := range []float64{0, 0, 130, 150, 150, 0, 0} {
		o := observation94(session, 1, int64(i), float64(i), move, 20)
		news := []native.Signal{}
		if i == 0 {
			news = append(news, birth94("A", 1, 2))
		}
		if i == 3 {
			pub := publication111(session, 1, session.Start+1800, 1, true)
			for _, b := range actors {
				if err := b.SetPublication(o.Time, 1, pub); err != nil {
					t.Fatal(err)
				}
			}
		}
		if i == 4 {
			for _, b := range actors {
				if err := b.ResetPublication(o.Time, "人工の欠足"); err != nil {
					t.Fatal(err)
				}
			}
		}
		if i == 5 {
			news = append(news, close94("元全残", "A", 1, 2))
		}
		batch := source.step(t, o, int64(i+300), news, nil)
		feed94(t, actors, o, batch)
		if i == 3 {
			a := actors["T100_C0_D0"].Snapshot().Positions[0]
			b := actors["W100_C0_D0"].Snapshot().Positions[0]
			if a.Protection111.FirstNarrowing == nil || a.Protection111.FinalState.WidthPoints != 20 || b.Protection111.FinalState.WidthPoints != 200 {
				t.Fatal("複合警戒の幅分離")
			}
		}
		if i == 4 {
			p := actors["T100_C0_D0"].Snapshot().Positions[0]
			if p.Protection111.FinalState.Latest != nil || !p.Protection111.FinalState.Narrowed || p.Protection111.Resets != 1 {
				t.Fatal("欠足失効/狭幅ラッチ")
			}
		}
	}
	_ = finish94(t, actors)
}

// TestContinuousFutureAndPublicationCopies は未来・別限月・同ID改変と公開参照の共有を拒否します。
//
// 引数: t(*testing.T)は試験器。返り値: なし。
func TestContinuousFutureAndPublicationCopies(t *testing.T) {
	s := session94()
	at := s.Start + 1800
	for _, kind := range []string{"未来", "別場", "別限月", "方向", "後退"} {
		b, _ := NewContinuousBook(s, "人工限月111", ActorConfig{"B100", 0, 0})
		p := publication111(s, 1, at, 1, true)
		switch kind {
		case "未来":
			p.AvailableAt = at + 1
		case "別場":
			p.Scope.Session = "別場"
		case "別限月":
			p.Scope.Contract = "別限月"
		case "方向":
			p.M = guard.Truth(7)
		case "後退":
			b.SetPublication(at, 1, p)
			p.ID = "後退"
			p.Ordinal = 2
			p.Start -= 180
			p.End -= 180
			p.AvailableAt -= 180
		}
		if err := b.SetPublication(at, 1, p); err == nil {
			t.Fatal("不正公表受理", kind)
		}
	}
	b, _ := NewContinuousBook(s, "人工限月111", ActorConfig{"B100", 0, 0})
	p := publication111(s, 1, at, 1, true)
	if err := b.SetPublication(at, 1, p); err != nil {
		t.Fatal(err)
	}
	*p.V = 999
	if *b.continuous.latest[1].V != 20 {
		t.Fatal("公表参照共有")
	}
	bad := valueCopy(*b.continuous.last[1])
	bad.M = guard.False
	if err := b.SetPublication(at, 1, bad); err == nil {
		t.Fatal("同ID改変受理")
	}
}

// TestContinuousUnknownATRNoReplacement は新規時未知を後から既知へ置き換えません。
//
// 引数: t(*testing.T)は試験器。返り値: なし。
func TestContinuousUnknownATRNoReplacement(t *testing.T) {
	actors := newContinuousActors111(t, []ActorConfig{{"W100", 0, 0}})
	source := newFixtureSource94()
	session := session94()
	for i, move := range []float64{0, 0, 200, 300, 0, 0} {
		atr := 0.0
		if i >= 2 {
			atr = 400
		}
		o := observation94(session, 1, int64(i), float64(i), move, atr)
		news := []native.Signal{}
		if i == 0 {
			news = append(news, birth94("A", 1, 1))
		}
		if i == 4 {
			news = append(news, close94("元全残", "A", 1, 1))
		}
		batch := source.step(t, o, int64(i+400), news, nil)
		feed94(t, actors, o, batch)
	}
	r := finish94(t, actors)["W100_C0_D0"]
	p := r.Positions[0]
	if p.ATR != nil || !p.Protection111.Initial.ATRUnknownFallback || p.Protection111.FinalState.NormalWidth != 200 || r.Metrics.ATRUnknownFallbackPositions != 1 || r.Metrics.ATRDeferredPositions != 0 {
		t.Fatal("取得後ATR付替え", p)
	}
}

// TestContinuousBadQuoteAndReservedHit は異常気配・全予約でも評価して新しい返済を重ねません。
//
// 引数: t(*testing.T)は試験器。返り値: なし。
func TestContinuousBadQuoteAndReservedHit(t *testing.T) {
	actors := newContinuousActors111(t, []ActorConfig{{"W100", 0, 0}, {"W100", 0, 1}})
	source := newFixtureSource94()
	session := session94()
	times := []float64{0, 1, 2, 2, 2, 2.5, 3, 4, 5, 6}
	moves := []float64{0, 0, 400, 0, 0, 0, 0, 0, 0, 0}
	for i := range times {
		o := observation94(session, 1, int64(i), times[i], moves[i], 20)
		news := []native.Signal{}
		if i == 0 {
			news = append(news, birth94("A", 1, 1))
		}
		if i == 8 {
			news = append(news, close94("元全残", "A", 1, 1))
		}
		if i == 5 {
			o.QuoteOK = false
		}
		batch := source.step(t, o, int64(i+500), news, nil)
		feed94(t, actors, o, batch)
		if i == 3 {
			p := actors["W100_C0_D1"].Snapshot().Positions[0]
			if p.Reserved != 1 {
				t.Fatal("保護予約不足")
			}
		}
		if i == 4 {
			a, b := actors["W100_C0_D0"].Snapshot().Positions[0], actors["W100_C0_D1"].Snapshot().Positions[0]
			if a.Quantity != 0 || b.Quantity != 1 || b.Reserved != 1 {
				t.Fatal("同秒の後原行と価格時計1秒の分離")
			}
		}
	}
	r := finish94(t, actors)["W100_C0_D1"]
	p := r.Positions[0]
	if p.Protection111.MissingQuote < 2 || p.Protection111.FirstAllReservedHit == nil || r.Metrics.ProtectionExitRequests != 1 {
		t.Fatal("欠測/全予約記録/二重要求", p.Protection111, r.Metrics)
	}
	if math.IsNaN(r.Totals.NetYen) || !reflect.DeepEqual(p.Protection111.FinalState.FloorPoints, p.FloorGain) {
		t.Fatal("最終床差")
	}
}

// TestContinuousSourcePriorityAndNonRelaxation はSource予約を先に割り当て床を緩めません。
//
// 引数: t(*testing.T)は試験器。返り値: なし。
func TestContinuousSourcePriorityAndNonRelaxation(t *testing.T) {
	actors := newContinuousActors111(t, []ActorConfig{{"W100", 0, 0}})
	source := newFixtureSource94()
	session := session94()
	lastFloor := math.Inf(-1)
	for i, move := range []float64{0, 0, 400, 0, 0, 0, 0} {
		o := observation94(session, 1, int64(i), float64(i), move, 20)
		news := []native.Signal{}
		if i == 0 {
			news = append(news, birth94("A", 1, 2))
		}
		if i == 3 {
			news = append(news, close94("先行部分", "A", 1, 1))
		}
		if i == 5 {
			news = append(news, close94("元全残", "A", 1, 1))
		}
		batch := source.step(t, o, int64(i+600), news, nil)
		feed94(t, actors, o, batch)
		r := actors["W100_C0_D0"].Snapshot()
		if len(r.Positions) > 0 {
			p := r.Positions[0]
			if p.FloorGain != nil {
				if *p.FloorGain < lastFloor {
					t.Fatal("保護床の緩和")
				}
				lastFloor = *p.FloorGain
			}
			if i == 3 {
				if len(r.Orders) != 3 || r.Orders[1].ProtectionPoint != nil || r.Orders[2].ProtectionPoint == nil || r.Orders[1].Quantity != 1 || r.Orders[2].Quantity != 1 || p.Reserved != 2 {
					t.Fatal("Source先行と未予約残の返済", r.Orders)
				}
			}
		}
	}
	r := finish94(t, actors)["W100_C0_D0"]
	if r.Metrics.SourceExitRequests != 1 || r.Metrics.ProtectionExitRequests != 1 || r.Positions[0].Protection111.FirstAllReservedHit == nil {
		t.Fatal("Source又は全予約の二重返済")
	}
}

// TestContinuousBBBranchAndSidePublication は純BB公表を接続してTとB政策を分離します。
//
// 引数: t(*testing.T)は試験器。返り値: なし。
func TestContinuousBBBranchAndSidePublication(t *testing.T) {
	session := session94()
	scope := guard.Scope{Session: session.ID, Contract: "人工限月111", Start: session.Start}
	window, err := guard.NewBBState(scope)
	if err != nil {
		t.Fatal(err)
	}
	var bb guard.BBResult
	for i := 1; i <= 22; i++ {
		price := 1000 + 5*float64(i-1)
		if i > 20 {
			price = 1050
		}
		bar := guard.ClosedBar{Scope: scope, ID: "人工公表111/" + fmtOrdinal111(uint64(i)), Ordinal: uint64(i), Start: scope.Start + float64((i-1)*180), End: scope.Start + float64(i*180), AvailableAt: scope.Start + float64(i*180), Known: true, Close: &price}
		window, bb, err = guard.AdvanceBB(window, bar, bar.AvailableAt)
		if err != nil {
			t.Fatal(err)
		}
	}
	if bb.Contraction != guard.True {
		t.Fatal("人工BB収縮なし")
	}
	actors := newContinuousActors111(t, []ActorConfig{{"T100", 0, 0}, {"B100", 0, 0}, {"B50", 0, 0}})
	source := newFixtureSource94()
	times := []float64{0, 1, 2, 2160, 2161, 2162}
	moves := []float64{0, 0, 130, 150, 150, 150}
	for i, seconds := range times {
		o := observation94(session, 1, int64(i), seconds, moves[i], 20)
		news := []native.Signal{}
		if i == 0 {
			news = append(news, birth94("A", 1, 1))
		}
		if i == 3 {
			pub := publication111(session, 1, bb.End, bb.Ordinal, false)
			pub.M = guard.True
			pub.BB = &bb
			for _, b := range actors {
				if err = b.SetPublication(o.Time, 1, pub); err != nil {
					t.Fatal(err)
				}
			}
		}
		if i == 4 {
			news = append(news, close94("元全残", "A", 1, 1))
		}
		batch := source.step(t, o, int64(i+700), news, nil)
		feed94(t, actors, o, batch)
		if i == 3 {
			for key, b := range actors {
				p := b.Snapshot().Positions[0]
				want := key != "T100_C0_D0"
				if p.Protection111.FinalState.Narrowed != want {
					t.Fatal("BB政策枝差", key)
				}
			}
		}
	}
	_ = finish94(t, actors)
	// ----------------------------------------
	// 買売Mを一つの値へ混ぜず、それぞれの純Latestへ受け渡す。
	b, _ := NewContinuousBook(session, "人工限月111", ActorConfig{"B100", 0, 0})
	pub := publication111(session, 1, session.Start+1800, 1, true)
	if err = b.SetPublication(pub.End, 1, pub); err != nil {
		t.Fatal(err)
	}
	sell := publication111(session, -1, pub.End, 1, false)
	if err = b.SetPublication(pub.End, -1, sell); err != nil {
		t.Fatal(err)
	}
	source = newFixtureSource94()
	for i := 0; i < 2; i++ {
		o := observation94(session, 1, int64(i), float64(i), 0, 20)
		news := []native.Signal{}
		if i == 0 {
			news = []native.Signal{birth94("買", 1, 1), birth94("売", -1, 1)}
		}
		batch := source.step(t, o, int64(i+800), news, nil)
		if err = b.OnNativeStep(o, int64(i+800), []NativeBatch{batch}); err != nil {
			t.Fatal(err)
		}
	}
	for _, p := range b.Snapshot().Positions {
		want := guard.True
		if p.Side < 0 {
			want = guard.False
		}
		if p.Protection111.FinalState.Latest.M != want {
			t.Fatal("買売Mの混合")
		}
	}
}

// TestContinuousResetDuplicateAndClock はreset後の古公表復活と未来配送の混入を拒否します。
//
// 引数: t(*testing.T)は試験器。返り値: なし。
func TestContinuousResetDuplicateAndClock(t *testing.T) {
	s := session94()
	at := s.Start + 1800
	b, _ := NewContinuousBook(s, "人工限月111", ActorConfig{"B100", 0, 0})
	pub := publication111(s, 1, at, 1, true)
	if err := b.SetPublication(at, 1, pub); err != nil {
		t.Fatal(err)
	}
	if err := b.ResetPublication(at, "空足"); err != nil {
		t.Fatal(err)
	}
	if err := b.SetPublication(at, 1, pub); err != nil {
		t.Fatal(err)
	}
	if b.continuous.latest[1] != nil {
		t.Fatal("reset後の同ID復活")
	}
	b, _ = NewContinuousBook(s, "人工限月111", ActorConfig{"B100", 0, 0})
	if err := b.SetPublication(at+10, 1, pub); err != nil {
		t.Fatal(err)
	}
	o := observation94(s, 1, 0, 0, 0, 20)
	if err := b.OnNativeStep(o, 900, nil); err == nil || b.result.Metrics.Rows != 0 {
		t.Fatal("未来配送より早い原行を処理")
	}
}

// TestContinuousCandidateAndSnapshotNoninterference は候補集合と公開copyが独立することを検査します。
//
// 引数: t(*testing.T)は試験器。返り値: なし。
func TestContinuousCandidateAndSnapshotNoninterference(t *testing.T) {
	all := selectedWave111(t, 1, nil)
	single := selectedWave111(t, 1, []ActorConfig{{"B50", 0, 0}})
	a, _ := json.Marshal(all["B50_C0_D0"])
	b, _ := json.Marshal(single["B50_C0_D0"])
	if !bytes.Equal(a, b) {
		t.Fatal("他候補の併存で結果が変化")
	}
	actor := newContinuousActors111(t, []ActorConfig{{"B50", 0, 0}})["B50_C0_D0"]
	source := newFixtureSource94()
	s := session94()
	for i := 0; i < 2; i++ {
		o := observation94(s, 1, int64(i), float64(i), 0, 20)
		news := []native.Signal{}
		if i == 0 {
			news = append(news, birth94("A", 1, 1))
		}
		batch := source.step(t, o, int64(i+950), news, nil)
		if err := actor.OnNativeStep(o, int64(i+950), []NativeBatch{batch}); err != nil {
			t.Fatal(err)
		}
	}
	copy := actor.Snapshot()
	copy.Positions[0].Protection111.Initial.Entry.ATR.Value = 999
	if actor.Snapshot().Positions[0].Protection111.Initial.Entry.ATR.Value != 20 {
		t.Fatal("公開Snapshotと私有純状態が参照共有")
	}
}

// TestContinuousTimerNoOldMark は元timerで予約だけを同期し古い気配を評価しません。
//
// 引数: t(*testing.T)は試験器。返り値: なし。
func TestContinuousTimerNoOldMark(t *testing.T) {
	s := session94()
	b, _ := NewContinuousBook(s, "人工限月111", ActorConfig{"W100", 5, 0})
	src := newFixtureSource94()
	for i := int64(0); i < 2; i++ {
		o := observation94(s, 1, i, float64(i), 0, 20)
		news := []native.Signal{}
		if i == 0 {
			news = append(news, birth94("timer玉", 1, 1))
		}
		d := src.step(t, o, i+1000, news, nil)
		if err := b.OnNativeStep(o, i+1000, []NativeBatch{d}); err != nil {
			t.Fatal(err)
		}
	}
	before := b.Snapshot()
	sig := close94("timer返済", "timer玉", 1, 1)
	sig.Time, sig.SourceIndex = s.ForceClose, src.last.Index
	src.orders[sig.ID] = sig
	src.pending = append(src.pending, sig)
	src.reserved["玉-timer玉"] = 1
	delta := native.StepResult{At: s.ForceClose, Origin: "timer", SourceLine: src.last.SourceLine, Signals: []native.SignalRecord{{Signal: sig, Origin: "timer", At: s.ForceClose, Quote: src.last}}, Closes: []native.CloseNotice{{ID: sig.ID + "|玉-timer玉", ReferenceID: "玉-timer玉", Before: 1, Quantity: 1, Reason: sig.Reason}}}
	if err := b.OnNativeForce(s.ForceClose, []NativeBatch{{Method: "D164_15", Delta: delta}}); err != nil {
		t.Fatal(err)
	}
	after := b.Snapshot()
	point := after.Positions[0].Protection111.Last
	if after.Account.Count != before.Account.Count || after.Positions[0].Marks.Last.Quote != before.Positions[0].Marks.Last.Quote || point.Quote != nil || point.Decision.GainPoints != nil || point.Snapshot.Reserved != 1 || len(after.Fills) != len(before.Fills) {
		t.Fatal("timerの架空価格評価又は予約同期差")
	}
	o := observation94(s, 1, 2, 0, 200, 20)
	o.Time, o.Received = s.ForceClose, s.ForceClose
	d := src.step(t, o, 1002, nil, nil)
	if err := b.OnNativeStep(o, 1002, []NativeBatch{d}); err != nil {
		t.Fatal(err)
	}
	r, err := b.Finish()
	if err != nil || r.Totals.NetYen != 17923 || r.Metrics.ProtectionExitRequests != 0 || r.Positions[0].Activation.Phase != PhasePreFill {
		t.Fatal("元timer優先/実後原行fill", r.Totals, err)
	}
}

// TestExportContinuousFixtures は停止準備が明示した新規先へ宣言と買売器具を保存します。
//
// 引数: CONTINUOUS111_EXPORT_DIR(string環境変数)は未使用先。返り値: なし。通常試験ではskipです。
func TestExportContinuousFixtures(t *testing.T) {
	dir := os.Getenv("CONTINUOUS111_EXPORT_DIR")
	if dir == "" {
		t.Skip("111人工exportは明示時だけ")
	}
	if _, err := os.Stat(dir); !os.IsNotExist(err) {
		t.Fatal("export先が既存")
	}
	if err := os.Mkdir(dir, 0755); err != nil {
		t.Fatal(err)
	}
	values := map[string]any{"宣言設定.json": DeclaredContinuousConfigurations(), "買い.json": continuousFixture111(t, 1, nil), "売り.json": continuousFixture111(t, -1, nil)}
	for name, value := range values {
		raw, err := json.MarshalIndent(value, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(filepath.Join(dir, name), append(raw, '\n'), 0644); err != nil {
			t.Fatal(err)
		}
	}
}
