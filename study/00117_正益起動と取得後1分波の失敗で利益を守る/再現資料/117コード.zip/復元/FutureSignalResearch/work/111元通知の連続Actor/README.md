# 111：元通知の連続Actor

市場未実行。旧94のactual.go・actual_types.go・actual_test.goを同バイト派生した状態から、6政策×費用0/5×価格時計遅延0/1＝24条件を接続した。旧93/94/109、元戦略、Source通知や板・価格CSV・11月09日入力を変更・読取しない。

moduleは `github.com/masayoshi4649/SessionTradeExecuter/continuousactor111`、packageは `miniprotect`。純保護は停止済み `profitfloor111`（停止SHA0042a6dc…）を再用する。市場条件全体の固定はRootの後段処理で行い、この停止だけで市場利益や元166再現を証明しない。

## 入口と原行内順序

- `DeclaredContinuousConfigurations() []ActorConfig`：S0/U100/W100/T100/B100/B50の実24宣言。
- `NewContinuousBook(session,contract,cfg)`：新市場入口。24条件だけを受け付け、研究側の5分等の新規時計や開始静観を追加しない。
- `OnNativeStep(o,line,batches)`：旧94と同じSource出典確認、pre_fillの評価、既予約の実fill、Source closeとnew受付、after_sourceの評価。新しい保護注文はafter_sourceでだけ作る。
- `OnNativeForce(at,batches)`：元timerのclose/取消を配送。古い気配を評価・約定せず、純状態の予約量だけnil価格で同期する。
- `Finish()`：ActualとSourceの残玉・予約・未約定が0でなければ完了しない。

旧人工用 `NewActualBook` のS0/P0/P1は保持した。S0の新Ctorは会計分岐を旧94から変えず、`StreamScope` だけ111の元連続通知と明示する。新型のoptionalな純監査fieldはS0でnil/0のためJSONへ出さない。手製の買い・売り/後判明ATR・上限/取消列で、S0四費用の各配送点とFinishの全JSONを旧94へ同体照合する。

`NativeBatch` はSource側の旧94aliasと異なるnamed型なので、Consumerでは `NativeBatch{Method:source.Method,Delta:source.Delta}` と外側を明示変換する。Deltaは変更せず、新旧とも同じ元Source通知を消費する。Actualの返済をSourceへ通知しない。

## 公開配送

`SetPublication(at,side,pure.Publication)` と `ResetPublication(at,reason)` はRootの公開器Eventsをその順に適用する。Mとpivot方向が異なるため買売を分け、片側の公表を反対側へ自動複写しない。scope・contract・確定3分境界・available≤at・BB配送時計等は純APIのdummy PreFill/Marknilでも検査する。

配送後より早い原行/timer、未来/別場/別限月、同ID改変、公表後退を拒否する。欠足resetは両側の技法窓を失効し、同じ古いIDの再配送で復活しない。resetと新公表が同原行にあれば順序を保持する。既存玉は次の原行位相でresetを先に同期し、新公表を評価する。確定床や狭幅ラッチはresetで緩めない。

## 実新規時の尺度と保護

各実new fillで純Stateを作る。A_entryはそのfill時点で同場公開済みのnative ATRだけ。未知は通常幅200ptを固定し、後でATRが判明しても付け替えない。既知はceil5(max(200,2A_entry))を固定する。純APIはATRのAvailableAt≥Session.Startも要求し、前場の公表を現在場へ偽装しない。

純Inputへ実残n、実予約、初期q0、返済済み純額Rを渡す。Rは各ActualPosition.RealizedNetで、返済片の往復手数料・追加滑りを含む。U100は残玉単位u、他は全玉清算Wで起動し、W政策の床は部分fill後のR/n/q0を反映する。峰は起動時から追跡する。

pre_fillでも予約全量でも純状態を進め、未予約分だけをafter_sourceの返済注文へ予約する。Fが現在方向幅以上でもFで約定したことにせず、旧94と同じ次正常原行かつD0/D1を満たすBBOで実fillする。同秒でも原行Indexが後でなければ約定しない。Source返済は保護より先に未予約量を取る。

異常BBOではMark=nilで時計・公表・実所有を同期し、架空MTMを作らない。全実返済時もnil価格でFinishedを記録し、退出後の価格を評価しない。新予約直後はnil価格の追加同期で純ReservedもActualへ一致させる。

## 保存する少数点

新政策のActualPosition.Protection111に初期State、初回起動、初狭幅、初/最終床更新、初hit、初全予約hit、最後と最終純Snapshotを残す。各点に純Decisionと配送時計・原行/位相を結び、予約直後はAfterRequestを別記する。Evaluationsは通常の各位相評価数で、reset・予約後同期の追加sequenceとは区別する。

既存のProtectionActive/FloorGain/Activation等も純Stateへ一致させる。新規時未知はATRUnknownFallbackPositionsへ記録し、旧ATRDeferredPositionsと混ぜない。未参加・退出後の仮想利益、機会損失、MFE回収率を計算しない。

## 人工と停止

手製Source APIを使い24宣言、S0旧94全JSON、売買鏡像、u正/W負、全予約、Source優先、同秒後原行/1価格秒、欠測、未来公表、BB有無、reset、取得時未知ATR、非緩和、候補/Source/Snapshot非干渉を検査する。元FARの自然発生や実市場の再現ではない。

```powershell
go test ./...
go vet ./...
go build ./...
python -B -X utf8 検査と停止を記録する.py
```

停止処理は新規の検査フォルダへテスト結果・実API・実24宣言・買売人工を保存する。人工は元Source/板と区別する。GoRoot/全依存閉包と市場CLIの固定、元166との実入力対照はRootの後段責務である。
