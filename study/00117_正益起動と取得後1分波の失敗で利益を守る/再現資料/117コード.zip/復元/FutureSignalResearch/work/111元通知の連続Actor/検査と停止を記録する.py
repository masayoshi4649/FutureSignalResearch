"""111連続Actorの非市場人工・旧S0同体・実24宣言を検査して所有物を停止する。"""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
PURE = ROOT / 'work/111全玉利益と収束BBの純保護'
PURE_STOP = '0042a6dc3f181150609deeca5b2c095c9f553d69fcaab1d833402ae31fdbc2c4'


def sha(path):
    """
    機能: 所有code・設計・停止・明示人工の全指紋を得る。

    引数: path(Path)は非市場の明示対象。
    返り値: strはSHA256。原板・CSV・SourceRecordは渡さない。
    """
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def run(argv, env):
    """
    機能: 非市場のGo検査だけを所有module内で実行する。

    引数: argv(list[str])、env(dict[str,str])は固定コマンドと明示環境。
    返り値: dictは終了コード・標準出力・標準エラー。不成功は停止にしない。
    """
    process = subprocess.run(argv, cwd=OWN, env=env, capture_output=True, text=True, encoding='utf-8')
    result = {'argv': argv, 'exit_code': process.returncode, 'stdout': process.stdout, 'stderr': process.stderr}
    if process.returncode != 0:
        raise ValueError(json.dumps(result, ensure_ascii=False))
    return result


def main():
    """
    機能: test/vet/buildと所有不変・純停止・旧94原本を認証して新規停止を残す。

    引数: なし。
    返り値: None。市場・Source戦略・実Raw/CSV・11月09日は読まない。
    """
    destination = OWN / '検査'
    assert not destination.exists() and not (OWN / '停止.json').exists()
    owned = sorted(OWN.glob('*.go')) + [OWN / name for name in ('go.mod', 'go.sum', 'README.md', '派生元.json', Path(__file__).name)]
    before = {str(path): sha(path) for path in owned}
    assert sha(PURE / '停止.json') == PURE_STOP
    stopped = json.loads((PURE / '停止.json').read_text(encoding='utf-8'))
    reused = {str(PURE / '停止.json'): PURE_STOP, **stopped['所有コードSHA256']}
    origin = json.loads((OWN / '派生元.json').read_text(encoding='utf-8'))
    for item in origin['入力']:
        assert sha(Path(item['source'])) == item['sha256']
        reused[item['source']] = item['sha256']
    assert sha(OWN / 'actual_test.go') == next(item['sha256'] for item in origin['入力'] if Path(item['source']).name == 'actual_test.go')
    for directory in (ROOT / 'scripts/FAR連続出生と個別利益追尾', ROOT / 'scripts/FAR元三手法のmini連続再現'):
        for path in sorted(directory.glob('*.go')) + [directory / 'go.mod', directory / 'go.sum']:
            reused[str(path)] = sha(path)
    assert all(sha(Path(name)) == expected for name, expected in reused.items())
    design = ROOT / 'study/00111_元の連続判断と必須追尾の再基準化/設計候補.json'
    design_sha = sha(design)
    value = json.loads(design.read_text(encoding='utf-8-sig'))
    assert value['試行'] == 111 and value['条件数'] == 24 and value['固定済み'] is False
    env = dict(os.environ)
    env.pop('MINIPROTECT_EXPORT_DIR', None)
    env.pop('CONTINUOUS111_EXPORT_DIR', None)
    commands = [run(['go', 'test', '-count=1', '-json', '-cover', './...'], env), run(['go', 'vet', './...'], env), run(['go', 'build', './...'], env)]
    destination.mkdir()
    export_env = dict(env, CONTINUOUS111_EXPORT_DIR=str(destination / '人工'))
    exported = run(['go', 'test', '-count=1', '-run', '^TestExportContinuousFixtures$', './...'], export_env)
    declaration_path = destination / '人工/宣言設定.json'
    declaration = json.loads(declaration_path.read_text(encoding='utf-8'))
    expected = [{'policy': row['policy'], 'slip_pts': row['追加片道滑りpt'], 'delay_seconds': row['価格時計遅延秒']} for row in value['比較条件']]
    assert declaration == expected and len(declaration) == 24
    api = run(['go', 'doc', '-all', '.'], env)
    (destination / 'API.txt').write_text(api['stdout'], encoding='utf-8', newline='\n')
    for signature in ('func NewContinuousBook(', 'func DeclaredContinuousConfigurations(', 'SetPublication(', 'ResetPublication('):
        assert signature in api['stdout']
    events = [json.loads(line) for line in commands[0]['stdout'].splitlines() if line.startswith('{')]
    passed = [row['Test'] for row in events if row.get('Action') == 'pass' and 'Test' in row]
    skipped = [row['Test'] for row in events if row.get('Action') == 'skip' and 'Test' in row]
    assert 'TestContinuousS0ExactLegacy' in passed and 'TestContinuousTimerNoOldMark' in passed and len(passed) >= 18
    artifacts = {str(path): sha(path) for path in sorted((destination / '人工').glob('*.json'))}
    after = {name: sha(Path(name)) for name in before}
    assert before == after and all(sha(Path(name)) == expected for name, expected in reused.items()) and sha(design) == design_sha
    proof = {'成功': True, 'scope': '手製Source APIのみ。元166/市場/CSV由来の再現成功ではない', 'test/vet/build': commands,
             '人工export': exported, '実宣言数': len(declaration), '成功test': passed, 'skip': skipped,
             '所有コードSHA256前': before, '所有コードSHA256後': after, '前後不変': True,
             '再用コードSHA256': reused, '実人工出力SHA256': artifacts,
             'race検査': {'実施': False, '理由': '現在CGO未有効。任意の-race試行は開始前にrequires cgoで終了。必須test/vet/buildは成功'},
             'S0対照': '旧94の買/売未知ATR/上限取消列の各配送点とFinishの全JSON同体。StreamScopeだけ111へ明示差',
             '市場/Source戦略/原板/CSV/11月09日実行読取': False}
    proof_path = destination / '人工確認.json'
    proof_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    version = run(['go', 'version'], env)['stdout'].strip()
    stop = {'成功': True, '停止': True, 'trial': 111, 'module': 'github.com/masayoshi4649/SessionTradeExecuter/continuousactor111',
            'scope': '111連続Actor所有の非市場停止。全市場CLI/全依存閉包の固定はRoot後段', '日時UTC': datetime.now(timezone.utc).isoformat(),
            'Go版': version, '所有コードSHA256': before, '再用コードSHA256': reused, '前後不変': True,
            '設計': {'path': str(design), 'sha256': design_sha}, '純保護停止': {'path': str(PURE / '停止.json'), 'sha256': PURE_STOP},
            '人工確認': {'path': str(proof_path), 'sha256': sha(proof_path)}, '実宣言': {'path': str(declaration_path), 'sha256': sha(declaration_path)},
            '実API': {'path': str(destination / 'API.txt'), 'sha256': sha(destination / 'API.txt')},
            '人工出力SHA256': artifacts, '成功test数': len(passed), '新Actor主test数': sum(name.startswith('TestContinuous') for name in passed),
            '市場/Source戦略/原板/CSV/11月09日実行読取': False}
    target = OWN / '停止.json'
    target.write_text(json.dumps(stop, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '停止': str(target), 'sha256': sha(target), '成功test数': len(passed), '実24宣言': sha(declaration_path)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
