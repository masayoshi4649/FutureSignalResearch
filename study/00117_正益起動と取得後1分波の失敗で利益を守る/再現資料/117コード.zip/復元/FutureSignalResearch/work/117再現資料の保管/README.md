# 117コードの恒久保管と再現CLI

このhelperはRootだけが実行する。新しい売買試行、金融再生、閾値変更は行わない。コード・停止metadataを保管し、CSV・Native・Raw・価格をZIPへ入れず読まない。

Core停止b35bの現物の全固定コードは1222件である。会計の9所有/6再用、全70保存1分検算の4所有/8依存、CSV・表・Native保管器の明示所有/再用を追加する。同じpathの同SHAは一意化し、同bytesの別pathはZIP payloadを一度だけ保存して復元索引に各元pathを残す。停止JSONは元bytesで格納する。Root補助コード2件と最終validator、結果結合前の校正表は追加Refで結ぶ。

GoRoot、外部Go module、全exeは索引だけとし、同梱しない。研究リポジトリのwork/scriptsと必要なSessionTradeExecuterコードを同梱する。外部moduleの元cache位置・版と個別SHA、Node24.22.1、Artifact Tool2.8.129等の停止時環境も索引へ残す。実行時はコード参照の全SHAを照合し、ZIP全entry集合/SHA/CRCと入力前後不変を確認する。

## Rootの保管

人工検査は手製bytesのZIP往復・重複排除・危険名/データ種別拒否だけ。新規先に実行して準備proofと未許可要求素材を作る。

```powershell
python 'work/117再現資料の保管/人工検査.py' --out 'work/117再現資料の保管/人工確認'
```

Rootが素材を新要求へ写し、`fixed=true, code_read_authorized=true`と新SHAを固定する。`extra_code_refs`はコード又は小metadataだけ。正式先の既存3成果物へは上書きできない。

```powershell
python 'work/117再現資料の保管/保管する.py' --request '<Root新要求>' --sha256 '<SHA>' --metadata-only
python 'work/117再現資料の保管/保管する.py' --request '<Root新要求>' --sha256 '<SHA>'
```

正式先は試行117の`再現資料/117コード.zip`、`コード復元索引.json`、`コード保管の確認.json`。metadata-onlyでは停止metadata・自己コードだけを認証し、全候補コードの本文SHAは実保管時に照合する。

## 復元後の再現

索引の`entries`に従ってZIP entryを各`restore_root/relative`へ復元する。同じentryを参照する複数元pathはそれぞれ復元する。環境参照は同Go1.24.2 windows/amd64・同module版/各SHAを別途用意する。F1は絶対pathを固定しているので、元pathを再現するか、新しい実行要求と復元pathの対応を明示する。元F1を黙って書き換えない。

金融Coreの停止時buildは`work/117正益と短期波の連続比較`で`GOWORK=off CGO_ENABLED=0 GOTOOLCHAIN=local`、`go build -o <新exe> ./cmd/run`。同じGo/ソース/元pathへ復元し、F1のexe SHAに一致するか確認する。一致しなければ同じ実行物として扱わず、環境差を残す。

**このZIP単独で全金融を再現できるとはしない。** F1が参照する旧112の正式Native対照、元166の原文oracle、Source111・旧部品の既正式再現資料、共有原板・分足も必要である。105で生成した3gzipはinputsへ恒久保存されているが、F1の元pathへ同bytesで復元する必要がある。

金融CLIは`--fixed <F1> --fixed-sha <F1SHA> --stage metadata-only|first2|base54|full70 --out <未作成先> --workers 16`、full70には同F1 base54成功の`--prior54/--prior54-sha`が必要。117で実行済みの金融・保存点・1分公表検算は既存の正式結果を参照し、今回の保管作業では再実行しない。

独立会計は同梱READMEに従い`保存する.py --fixed <Root保存要求> --sha256 <SHA> --output <新規先>`。1分公表の検算、CSV生成/再読、表結合、Native可逆保管も各停止済みREADMEとRoot要求を参照する。損益CSVはoutputsの唯一正本、Nativeは別の可逆保管が正本であり、本コードZIPには含まない。

Root確認済みのNative正本は試行117の`成果物_金融/Native可逆圧縮索引.json`と70個のzstd（合計16,934,635bytes）。元gzip計45,439,595bytesへの同bytes復元を確認済みで、正式`再現資料/gzipを再現する.exe`（SHA `a06c854ce4bfe6db22a3329e28a571a56454dfaaf11c90af1e33efc9a4e12c9c`）を使える。この既保存exeは本コードZIPのexe非同梱方針と別に維持される。

Viewerはwork依存を外した正式`成果物/一覧.resources.json`の1400資源と絶対市場参照を使う。保存再読の成功とHTTP確認は別で、今回の117ではHTTP未実施である。
