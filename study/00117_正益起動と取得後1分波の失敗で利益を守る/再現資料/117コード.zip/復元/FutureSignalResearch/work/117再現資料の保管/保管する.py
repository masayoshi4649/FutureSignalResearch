"""Root固定要求からコードと停止metadataだけを恒久ZIPへ保管する。"""

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import sys
import zipfile

sys.stdout.reconfigure(encoding="utf-8")
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
FORMAL = ROOT / "study/00117_正益起動と取得後1分波の失敗で利益を守る/再現資料"
F1 = {"path": str(ROOT / "work/117進行/F1_117金融条件.json"), "sha256": "522fe2343b914243fadc4f48d32128a79ecdafcabd84d5a58b5ca399af90d1b0"}
SOURCES = {
    "core": ("117正益と短期波の連続比較/停止.json", "b35b9185dd2285df392492208c8566abf7c4127bd74738d220b4aa3f27f53f73", ("全固定コードSHA256", "所有コードSHA256", "GoRootコードSHA256")),
    "accounting": ("117自然会計と保存点の独立検算/停止.json", "4e0697d5506ba13ac25c4b6af13187b36b708718de358d9c4d7125dad9735cf1", ("所有ファイルSHA256", "再用ファイルSHA256")),
    "short70": ("117全70保存1分公表の独立再計算/人工確認_01/準備の確認.json", "300608b3e84d74d0e2c126a5f7cbe202dc7865c431883320e09c6cf628c1c30d", ("所有コードSHA256", "依存SHA256")),
    "csv": ("117損益CSVの出力/停止.json", "fa261aa01a5db403472056d6147b01c13949c20027dd0d80bd2950a55337fbf6", ("所有ファイルSHA256", "再用コードSHA256")),
    "table": ("117設定表の結果結合/停止.json", "6b4ff762f5e519670b826390277d56b8763a1740ebc15ef6479fcdc6fe83d695", ("所有ファイルSHA256", "再用コードSHA256")),
    "native_keeper": ("117Nativeを可逆圧縮して保管する/停止.json", "b2e7a0e9cce67364b6fd4fdf92d4c9c6550836a5ffb6115b6eba33a577aeff3a", ("所有ファイルSHA256", "再用コードSHA256")),
}
OUTPUTS = ("117コード.zip", "コード復元索引.json", "コード保管の確認.json")


def digest(path):
    """
    機能: 明示されたコード又は小metadataをSHA256へ写す。
    引数: path(Path)は読取許可されたファイル。
    返り値: strはSHA256。
    """
    h = hashlib.sha256()
    with path.open("rb") as stream:
        while data := stream.read(1024 * 1024):
            h.update(data)
    return h.hexdigest()


def safe_source(path):
    """
    機能: Raw/Native/CSV等を指す入力を、本文やstatより前に拒否する。
    引数: path(Path)はコード台帳の絶対位置。
    返り値: None。不適格ならValueError。
    """
    forbidden = {".csv", ".tsv", ".gz", ".zst", ".zip", ".xlsx", ".xls", ".jsonl", ".parquet"}
    name = path.name.lower()
    if not path.is_absolute() or path.suffix.lower() in forbidden or ".native." in name or name.endswith(".resources.json"):
        raise ValueError("コード保管へ価格/金融本文を混入できない:" + str(path))


def ref_form(ref):
    """
    機能: metadata Refの表記と非データ種別を検査する。
    引数: ref(dict)はpath/sha256。
    返り値: Pathは絶対コード位置。
    """
    assert set(ref) == {"path", "sha256"} and re.fullmatch("[0-9a-f]{64}", ref["sha256"])
    path = Path(ref["path"])
    safe_source(path)
    return path


def read_ref(ref, before):
    """
    機能: 小metadataを期待SHAで認証する。
    引数: ref(dict)、before(dict[str,str])は参照と前指紋集合。
    返り値: dictはJSON。データ本文を再帰的には開かない。
    """
    path = ref_form(ref)
    assert digest(path) == ref["sha256"], "metadata SHA差"
    before[str(path)] = ref["sha256"]
    return json.loads(path.read_text(encoding="utf-8-sig"))


def merge(entries, path, expected, origin):
    """
    機能: 同じ絶対pathの期待SHAを一意化し由来を保持する。
    引数: entries(dict)、path(str)、expected(str)、origin(str)は集合と宣言。
    返り値: None。SHA衝突は拒否。
    """
    location = Path(path)
    safe_source(location)
    assert re.fullmatch("[0-9a-f]{64}", expected)
    key = str(location)
    if key in entries:
        assert entries[key]["sha256"] == expected, "同pathの期待SHA衝突"
        entries[key]["origins"].append(origin)
    else:
        entries[key] = {"original_path": key, "sha256": expected, "origins": [origin]}


def safe_entry(name):
    """
    機能: ZIP内の相対名が復元根を抜けないか確認する。
    引数: name(str)はZIP entry。
    返り値: None。絶対/後退/Windows区切りを拒否する。
    """
    p = PurePosixPath(name)
    if p.is_absolute() or not p.parts or any(part in ("", ".", "..") for part in p.parts) or "\\" in name or ":" in name:
        raise ValueError("安全でないZIP名:" + name)


# ----------------------------------------
def classify(entry, standards):
    """
    機能: 同梱コードと環境参照を区別し、復元pathを残す。
    引数: entry(dict)、standards(set[str])は一つのコード参照とGoRoot集合。
    返り値: dictは分類・復元根・entry候補を加えた台帳行。
    """
    result = dict(entry)
    path = Path(result["original_path"])
    safe_source(path)
    if str(path) in standards:
        result.update(kind="GoRoot環境参照", archive_entry=None, version="go1.24.2 windows/amd64")
    elif path.suffix.lower() == ".exe":
        result.update(kind="実行物再build参照", archive_entry=None)
    elif path.is_relative_to(ROOT):
        relative = path.relative_to(ROOT).as_posix()
        result.update(kind="同梱", restore_root="FutureSignalResearch", relative=relative, archive_entry="復元/FutureSignalResearch/" + relative)
    elif path.is_relative_to(ROOT.parent / "SessionTradeExecuter"):
        relative = path.relative_to(ROOT.parent / "SessionTradeExecuter").as_posix()
        result.update(kind="同梱", restore_root="SessionTradeExecuter", relative=relative, archive_entry="復元/SessionTradeExecuter/" + relative)
    else:
        parts = path.as_posix().lower()
        kind = "外部Go module環境参照" if "/pkg/mod/" in parts else "外部環境参照"
        result.update(kind=kind, archive_entry=None)
        # moduleの版は元cache位置の@v又は@versionから読み取れる形を保持する。
        result["module_cache_path"] = path.as_posix()
    if result["archive_entry"] is not None:
        safe_entry(result["archive_entry"])
    return result


def prepare(request_ref):
    """
    機能: Root許可・固定停止6件・F1と自己proofを認証し保管候補を収集する。
    引数: request_ref(dict)はRoot新固定要求。
    返り値: tupleは要求・候補行・metadata指紋・環境説明。
    """
    before = {}
    request = read_ref(request_ref, before)
    assert request["version"] == 1 and request["trial"] == 117 and request["fixed"] is True and request["code_read_authorized"] is True
    assert request["Raw_CSV_Native_read_authorized"] is False
    assert Path(request["output_dir"]) == FORMAL
    assert all(not (FORMAL / name).exists() for name in OUTPUTS), "既存保管成果は上書きしない"
    proof = read_ref(request["helper_proof"], before)
    own = {str(path): digest(path) for path in sorted(HERE.glob("*.py"))}
    assert proof["成功"] is True and proof["人工のみ"] is True and proof["所有コードSHA256"] == own
    entries, standards, environment = {}, set(), {}
    merge(entries, request_ref["path"], request_ref["sha256"], "Rootコード保管要求")
    merge(entries, request["helper_proof"]["path"], request["helper_proof"]["sha256"], "保管helperの人工準備")
    for path, expected in own.items():
        before[path] = expected
        merge(entries, path, expected, "保管helper")
    if (HERE / "README.md").exists():
        merge(entries, str(HERE / "README.md"), digest(HERE / "README.md"), "再現CLI説明")
    condition = read_ref(F1, before)
    assert condition["trial"] == 117 and condition["fixed"] is True
    merge(entries, F1["path"], F1["sha256"], "Root金融F1 metadata")
    for key, (relative, expected, fields) in SOURCES.items():
        ref = {"path": str(ROOT / "work" / relative), "sha256": expected}
        meta = read_ref(ref, before)
        assert meta["成功"] is True
        if key != "short70":
            assert meta["停止"] is True
        merge(entries, ref["path"], expected, key + "/停止又は準備metadata")
        for field in fields:
            table = meta[field]
            assert isinstance(table, dict)
            for path, wanted in table.items():
                merge(entries, path, wanted, key + "/" + field)
        if key == "core":
            standards.update(meta["GoRootコードSHA256"])
            environment["Core全固定コード数"] = len(meta["全固定コードSHA256"])
            environment["依頼文の1283件との差"] = "現停止b35bの全固定mapは1222件。推測で補完せず現物集合を使用"
        if "環境参照" in meta:
            environment[key] = meta["環境参照"]
            for label, item in meta["環境参照"].items():
                if isinstance(item, dict) and set(item) >= {"path", "sha256"}:
                    merge(entries, item["path"], item["sha256"], key + "/環境参照/" + label)
    for ref in request.get("extra_code_refs", []):
        path = ref_form(ref)
        merge(entries, str(path), ref["sha256"], "Root追加コード又はmetadata")
    # 金融exeは本文を複製せずF1にある期待SHAと再build条件を残す。
    environment.update({"金融実行物": condition["executable"], "金融実行物の本文読取": False, "Go版": "go1.24.2 windows/amd64", "GOWORK": "off", "CGO_ENABLED": "0", "GOTOOLCHAIN": "local", "金融build": "go build -o <復元後の新exe> ./cmd/run", "再現の限界": "GoRoot/外部module/実行物は索引参照。同版・同path・依存を復元してbuild後、exeの期待SHAへ別途照合する。F1を書換えて一致扱いしない"})
    rows = [classify(entry, standards) for _, entry in sorted(entries.items())]
    return request, rows, before, environment


# ----------------------------------------
def write_zip(path, rows):
    """
    機能: 同梱対象をSHAで一度だけ格納し、全entryのCRCとSHAを再読する。
    引数: path(Path)、rows(list[dict])は未作成ZIPと認証済みコード行。
    返り値: dictはentry SHA一覧。同bytes別pathは台帳で同じentryへ参照する。
    """
    assert not path.exists()
    by_sha, names = {}, set()
    with zipfile.ZipFile(path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for row in rows:
            if row["kind"] != "同梱":
                continue
            wanted = row["sha256"]
            if wanted in by_sha:
                row["archive_entry"] = by_sha[wanted]
                continue
            name = row["archive_entry"]
            safe_entry(name)
            assert name.casefold() not in names, "復元名の衝突"
            names.add(name.casefold())
            data = Path(row["original_path"]).read_bytes()
            assert hashlib.sha256(data).hexdigest() == wanted
            archive.writestr(name, data)
            by_sha[wanted] = name
    expected = {name: wanted for wanted, name in by_sha.items()}
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None, "ZIP CRC差"
        assert set(archive.namelist()) == set(expected) and len(archive.namelist()) == len(expected)
        for info in archive.infolist():
            safe_entry(info.filename)
            assert hashlib.sha256(archive.read(info)).hexdigest() == expected[info.filename], "ZIP entry SHA差"
    return expected


def save_json(path, value):
    """
    機能: 正式索引又は確認をUTF-8で新規保存する。
    引数: path(Path)、value(dict)は未作成先と値。
    返り値: None。上書きしない。
    """
    with path.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def main():
    """
    機能: metadata-only又はRoot専有の正式コード保管を行う。
    引数: CLI --request(Path)/--sha256(str)/--metadata-only(bool)。
    返り値: None。自然研究・金融・データ本文を実行しない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--metadata-only", action="store_true")
    args = parser.parse_args()
    request_ref = {"path": str(args.request.absolute()), "sha256": args.sha256}
    request, rows, before, environment = prepare(request_ref)
    if args.metadata_only:
        assert all(digest(Path(path)) == expected for path, expected in before.items())
        from collections import Counter
        print(json.dumps({"成功": True, "metadata_only": True, "候補path数": len(rows), "分類": dict(Counter(row["kind"] for row in rows)), "コード候補本文SHA照合": False, "Raw_CSV_Native本文読取": 0}, ensure_ascii=False))
        return
    for row in rows:
        path = Path(row["original_path"])
        assert digest(path) == row["sha256"], "停止宣言と現在コードのSHA差:" + str(path)
        row["bytes"] = path.stat().st_size
        before[str(path)] = row["sha256"]
    FORMAL.mkdir(parents=True, exist_ok=True)
    archive_path = FORMAL / OUTPUTS[0]
    entries = write_zip(archive_path, rows)
    index = {"試行": 117, "成功": True, "scope": "コードと停止metadataのみ", "entries": rows, "復元根": {"FutureSignalResearch": str(ROOT), "SessionTradeExecuter": str(ROOT.parent / "SessionTradeExecuter")}, "環境": environment, "ZIP": {"path": str(archive_path), "sha256": digest(archive_path)}, "ZIP全entrySHA256": entries, "Raw_CSV_Native格納": 0, "実行物の同梱": False}
    index_path = FORMAL / OUTPUTS[1]
    save_json(index_path, index)
    after = {path: digest(Path(path)) for path in before}
    assert before == after
    verification = {"試行": 117, "成功": True, "Root要求": request_ref, "前SHA256": before, "後SHA256": after, "前後不変": True, "コードpath数": len(rows), "ZIP格納数": len(entries), "ZIP全entry集合とSHA一致": True, "CRC全件": True, "索引": {"path": str(index_path), "sha256": digest(index_path)}, "ZIP": index["ZIP"], "金融実行": False, "Raw_CSV_Native読取": 0, "goal_achieved": False}
    save_json(FORMAL / OUTPUTS[2], verification)
    print(json.dumps({"成功": True, "確認": str(FORMAL / OUTPUTS[2]), "sha256": digest(FORMAL / OUTPUTS[2]), "コードpath数": len(rows), "ZIP格納数": len(entries)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
