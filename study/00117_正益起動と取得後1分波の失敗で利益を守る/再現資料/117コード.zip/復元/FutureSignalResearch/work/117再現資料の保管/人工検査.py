"""手製bytesだけでZIP往復と安全名の拒否を確認する。"""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import tempfile

sys.stdout.reconfigure(encoding="utf-8")
HERE = Path(__file__).resolve().parent


def main():
    """
    機能: 手製ZIPの全byte/SHA/CRCと拒否を検査し、Root素材を新規保存する。
    引数: CLI --out(Path)は自所有の新規先。
    返り値: None。正式保管・自然入力読取は行わない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    out = args.out.absolute()
    assert out.is_relative_to(HERE) and not out.exists()
    spec = importlib.util.spec_from_file_location("code_archive117", HERE / "保管する.py")
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    own = {str(path): helper.digest(path) for path in sorted(HERE.glob("*.py"))}
    tests = []
    with tempfile.TemporaryDirectory(prefix="117コード人工_", dir=HERE) as temporary:
        root = Path(temporary)
        payload = bytes(range(256)) + "日本語UTF-8\n".encode()
        rows = []
        for name in ("同値A.py", "同値B.py"):
            path = root / name
            path.write_bytes(payload)
            rows.append({"kind": "同梱", "original_path": str(path), "sha256": hashlib.sha256(payload).hexdigest(), "archive_entry": "復元/手製/" + name})
        archive = root / "手製.zip"
        entries = helper.write_zip(archive, rows)
        assert len(entries) == 1 and rows[0]["archive_entry"] == rows[1]["archive_entry"]
        tests.append("全256byteと日本語のSHA/CRC往復・同bytes1格納")
        try:
            helper.write_zip(archive, rows)
        except AssertionError:
            tests.append("既存ZIP拒否")
        else:
            raise AssertionError("既存ZIPを上書き")
        for name in ("../外部.py", "/絶対.py", "C:/絶対.py", "復元\\不適格.py"):
            try:
                helper.safe_entry(name)
            except ValueError:
                pass
            else:
                raise AssertionError("危険名を受理")
        tests.append("危険なZIP名4種拒否")
        for suffix in (".csv", ".Native.json.gz", ".jsonl", ".resources.json", ".zst"):
            try:
                helper.safe_source(root / ("未存在の金融本文" + suffix))
            except ValueError:
                pass
            else:
                raise AssertionError("データをコードとして受理")
        tests.append("Raw/CSV/Native等5種を存在照会前に拒否")
    assert own == {str(path): helper.digest(path) for path in sorted(HERE.glob("*.py"))}
    out.mkdir()
    proof = {"試行": 117, "成功": True, "人工のみ": True, "所有コードSHA256": own, "前後不変": True, "人工": tests, "正式保存": False, "金融実行": False, "Raw_CSV_Native読取": 0}
    proof_path = out / "準備の確認.json"
    helper.save_json(proof_path, proof)
    extras = []
    for name in ("出力用metadataを明示して結ぶ.py", "結果出力のRoot要求を固定する.py", "閉じる前の保存を確認する.py"):
        path = helper.ROOT / "work/117進行" / name
        if path.exists():
            extras.append({"path": str(path), "sha256": helper.digest(path)})
    table = helper.FORMAL / "結果結合前の設定表.md"
    if table.exists():
        extras.append({"path": str(table), "sha256": helper.digest(table)})
    template = {"version": 1, "trial": 117, "fixed": False, "code_read_authorized": False, "Raw_CSV_Native_read_authorized": False, "output_dir": str(helper.FORMAL), "helper_proof": {"path": str(proof_path), "sha256": helper.digest(proof_path)}, "extra_code_refs": extras}
    helper.save_json(out / "Root要求の素材.json", template)
    print(json.dumps({"成功": True, "proof": str(proof_path), "sha256": helper.digest(proof_path), "追加Ref数": len(extras)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
