package miniprotect

import (
	"bytes"
	"encoding/json"
	"fmt"
	"reflect"

	legacy "github.com/masayoshi4649/SessionTradeExecuter/continuousactor111"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor112"
)

// LegacyComparison112 は数値を隠さず許可した説明・監査型版差の件数を保存します。
type LegacyComparison112 struct {
	Policy              string `json:"policy"`
	StreamScopeChanged  bool   `json:"stream_scope_difference"`
	AuditFieldRenames   int    `json:"audit_field_renames"`
	DefinitionSnapshots int    `json:"definition_snapshots"`
	AllFinancialEqual   bool   `json:"all_financial_equal"`
}

// comparisonValue112 はGoの全JSONを数値字句を保つ比較値へ写します。
//
// 引数: value(any)は実公開結果又は宣言です。
// 返り値: any/errorはJSON全値又は保存不能です。金融項目を選別しません。
func comparisonValue112(value any) (any, error) {
	raw, err := json.Marshal(value)
	if err != nil {
		return nil, err
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	var out any
	if err = decoder.Decode(&out); err != nil {
		return nil, err
	}
	return out, nil
}

// declaredDefinition112 は本名の政策定義を宣言から一つだけ取得します。
//
// 引数: policy(string)はW100/B100などの本名です。
// 返り値: any/errorはJSON全定義又は宣言の欠落・重複です。
func declaredDefinition112(policy string) (any, error) {
	var found any
	count := 0
	for _, definition := range guard.DeclaredDefinitions() {
		if string(definition.Policy) == policy {
			value, err := comparisonValue112(definition)
			if err != nil {
				return nil, err
			}
			found, count = value, count+1
		}
	}
	if count != 1 {
		return nil, fmt.Errorf("112本名定義が一つでない:%s", policy)
	}
	return found, nil
}

// separateDefinition112 は純Snapshotの追加定義だけを全値照合後に分離します。
//
// 引数: value/definition(any)は実JSON部分木と当政策の正確な宣言です。
// 返り値: int/errorは分離Snapshot数又は定義改変です。C/M/P/Bや金額は変更しません。
func separateDefinition112(value any, definition any) (int, error) {
	count := 0
	switch node := value.(type) {
	case []any:
		for _, child := range node {
			n, err := separateDefinition112(child, definition)
			if err != nil {
				return count, err
			}
			count += n
		}
	case map[string]any:
		if metadata, exists := node["definition"]; exists {
			_, hasEntry := node["entry"]
			_, hasWidth := node["normal_width"]
			if !hasEntry || !hasWidth || !reflect.DeepEqual(metadata, definition) {
				return count, fmt.Errorf("112Snapshotの本名定義が宣言と異なる")
			}
			delete(node, "definition")
			count++
		}
		for _, child := range node {
			n, err := separateDefinition112(child, definition)
			if err != nil {
				return count, err
			}
			count += n
		}
	}
	return count, nil
}

// CompareLegacy111 は共通3政策の受理原行又は完結結果を金融全JSONで照合します。
//
// 引数: current(ActualResult)、prior(legacy.ActualResult)は同C/D・同政策の112/111公開値です。
// 返り値: LegacyComparison112/errorは説明Scope・監査field版名・正当な追加definitionだけの差、又は金融不一致です。
// 未Finishも受理し、金額・注文・約定・所有・床・時刻・DecisionのC/M/P/Bを削除しません。
func CompareLegacy111(current ActualResult, prior legacy.ActualResult) (LegacyComparison112, error) {
	result := LegacyComparison112{Policy: current.Config.Policy}
	if current.Config.Policy != "S0" && current.Config.Policy != "W100" && current.Config.Policy != "B100" {
		return result, fmt.Errorf("112新政策を111の旧名へ投影しない:%s", current.Config.Policy)
	}
	if current.Config.Policy != prior.Config.Policy || current.Config.SlipPts != prior.Config.SlipPts || current.Config.DelaySeconds != prior.Config.DelaySeconds || current.StreamScope != ContinuousScope112 || prior.StreamScope != legacy.ContinuousScope111 {
		return result, fmt.Errorf("112旧3対照の政策・費用・説明Scopeが不一致")
	}
	leftValue, err := comparisonValue112(current)
	if err != nil {
		return result, err
	}
	rightValue, err := comparisonValue112(prior)
	if err != nil {
		return result, err
	}
	left, right := leftValue.(map[string]any), rightValue.(map[string]any)
	result.StreamScopeChanged = left["stream_scope"] != right["stream_scope"]
	left["stream_scope"], right["stream_scope"] = "", ""
	definition, err := declaredDefinition112(current.Config.Policy)
	if err != nil {
		return result, err
	}
	if positions, ok := left["positions"].([]any); ok {
		for _, raw := range positions {
			position := raw.(map[string]any)
			if _, exists := position["protection111"]; exists {
				return result, fmt.Errorf("112実玉に旧監査fieldを混入")
			}
			if audit, exists := position["protection112"]; exists {
				delete(position, "protection112")
				position["protection111"] = audit
				result.AuditFieldRenames++
			}
		}
	}
	result.DefinitionSnapshots, err = separateDefinition112(left, definition)
	if err != nil {
		return result, err
	}
	if !reflect.DeepEqual(left, right) {
		return result, fmt.Errorf("112/111の旧3政策で全金融JSONに差:%s", current.Key)
	}
	result.AllFinancialEqual = true
	return result, nil
}
