module github.com/masayoshi4649/SessionTradeExecuter/continuousactor112

go 1.24.2

require (
	github.com/masayoshi4649/SessionTradeExecuter v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/mininative v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/miniprotect v0.0.0-00010101000000-000000000000
	github.com/masayoshi4649/SessionTradeExecuter/profitfloor112 v0.0.0
)

require (
	github.com/BurntSushi/toml v1.5.0 // indirect
	github.com/expr-lang/expr v1.17.8 // indirect
)

replace github.com/masayoshi4649/SessionTradeExecuter/mininative => ../../scripts/FAR元三手法のmini連続再現

replace github.com/masayoshi4649/SessionTradeExecuter/miniprotect => ../../scripts/FAR連続出生と個別利益追尾

replace github.com/masayoshi4649/SessionTradeExecuter => ../../../SessionTradeExecuter

replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor112 => ../112支持否定の必須確認と通常幅のみ

require github.com/masayoshi4649/SessionTradeExecuter/continuousactor111 v0.0.0

replace github.com/masayoshi4649/SessionTradeExecuter/continuousactor111 => ../111元通知の連続Actor

require github.com/masayoshi4649/SessionTradeExecuter/profitfloor111 v0.0.0

replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor111 => ../111全玉利益と収束BBの純保護
