package miniprotect

import (
	"fmt"
	"reflect"

	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor112"
)

const ContinuousScope112 = "112:FAR元の連続Source通知と元の取引時間。研究側の新規時計/開始静観なし。Last>0の元受理行。"

type ProtectionPoint112 struct {
	At           float64         `json:"at"`
	Quote        *QuoteStamp     `json:"quote"`
	Phase        string          `json:"phase"`
	Snapshot     guard.Snapshot  `json:"snapshot"`
	Decision     guard.Decision  `json:"decision"`
	ExitOrderID  string          `json:"exit_order_id"`
	AfterRequest *guard.Snapshot `json:"after_request,omitempty"`
}

type ProtectionAudit112 struct {
	Initial             guard.Snapshot      `json:"initial"`
	FirstActivation     *ProtectionPoint112 `json:"first_activation"`
	FirstNarrowing      *ProtectionPoint112 `json:"first_narrowing"`
	FirstFloorUpdate    *ProtectionPoint112 `json:"first_floor_update"`
	LastFloorUpdate     *ProtectionPoint112 `json:"last_floor_update"`
	FirstFloorHit       *ProtectionPoint112 `json:"first_floor_hit"`
	FirstAllReservedHit *ProtectionPoint112 `json:"first_all_reserved_hit"`
	Last                *ProtectionPoint112 `json:"last"`
	FinalState          guard.Snapshot      `json:"final_state"`
	Evaluations         uint64              `json:"evaluations"`
	MissingQuote        uint64              `json:"missing_quote"`
	Resets              uint64              `json:"resets"`
}

type continuousPosition112 struct {
	state     guard.State
	sequence  uint64
	resetSeen uint64
}

type continuousRuntime112 struct {
	contract    string
	lastAt      float64
	latest      map[int]*guard.Publication
	last        map[int]*guard.Publication
	reset       uint64
	resetReason string
	positions   map[string]*continuousPosition112
}

// DeclaredContinuousConfigurations は実市場入口に使う112の24条件を返します。
//
// 引数: なし。返り値: []ActorConfigはS0/W100/B100/W400/P100/P400×費用0/5×遅延0/1です。
func DeclaredContinuousConfigurations() []ActorConfig {
	out := []ActorConfig{}
	for _, c := range guard.DeclaredConfigurations() {
		out = append(out, ActorConfig{Policy: string(c.Policy), SlipPts: c.SlipPoints, DelaySeconds: c.DelaySeconds})
	}
	return out
}

// NewContinuousBook は元通知の時計を変えず24条件だけの独立実口座を作ります。
//
// 引数: session(Session)、contract(string)、cfg(ActorConfig)は場・限月・固定政策です。
// 返り値: *ActualBook/errorは112口座又は不正です。旧人工用NewActualBookは変更しません。
func NewContinuousBook(session Session, contract string, cfg ActorConfig) (*ActualBook, error) {
	valid := false
	for _, c := range DeclaredContinuousConfigurations() {
		valid = valid || c == cfg
	}
	if !valid || contract == "" || session.Start < 0 {
		return nil, fmt.Errorf("112の24条件又は限月/場が不正")
	}
	b, err := NewActualBook(session, ActorConfig{Policy: "S0", SlipPts: cfg.SlipPts, DelaySeconds: cfg.DelaySeconds})
	if err != nil {
		return nil, err
	}
	b.result.Config, b.result.Key, b.result.StreamScope = cfg, fmt.Sprintf("%s_C%.0f_D%d", cfg.Policy, cfg.SlipPts, cfg.DelaySeconds), ContinuousScope112
	b.continuous = &continuousRuntime112{contract: contract, latest: map[int]*guard.Publication{}, last: map[int]*guard.Publication{}, positions: map[string]*continuousPosition112{}}
	return b, nil
}

// hasPure112 はS0の完全対照を新保護の状態経路から分けます。
//
// 引数: receiver(*ActualBook)は口座。返り値: boolは新政策なら真です。
func (b *ActualBook) hasPure112() bool {
	return b != nil && b.continuous != nil && b.result.Config.Policy != "S0"
}

// continuousClock は配送済み公表を未来の原行へ持ち込むことを拒否します。
//
// 引数: at(float64)は現在原行又は元timer時計。返り値: errorは公表配送より早い評価です。
func (b *ActualBook) continuousClock(at float64) error {
	if b.continuous != nil && at < b.continuous.lastAt {
		return fmt.Errorf("112公表配送より前の原行/元timer")
	}
	return nil
}

// continuousScope は場と明示限月を純保護へ結びます。
//
// 引数: receiver(*ActualBook)は112口座。返り値: guard.Scopeは純APIの明示範囲です。
func (b *ActualBook) continuousScope() guard.Scope {
	return guard.Scope{Session: b.result.Session.ID, Contract: b.continuous.contract, Start: b.result.Session.Start}
}

// SetPublication は当時既知の片側3分公表を独立複写して配送します。
//
// 引数: at(float64)、side(int)、publication(guard.Publication)は配送時計・買売・確定公表です。
// 返り値: errorは未来/別場/改竄/後退です。配送自体は注文・保有評価を作りません。
func (b *ActualBook) SetPublication(at float64, side int, publication guard.Publication) error {
	if err := b.ready(); err != nil {
		return err
	}
	if b.continuous == nil || !finiteActual(at) || at < b.lastEventAt || at < b.continuous.lastAt || (side != 1 && side != -1) {
		return b.stop(fmt.Errorf("112公表の配送時計又は方向が不正"))
	}
	dummy, err := guard.NewState(guard.Entry{Scope: b.continuousScope(), Policy: guard.W100, Side: side, Price: 1000, At: b.result.Session.Start, InitialQuantity: 1})
	if err != nil {
		return b.stop(err)
	}
	if _, _, err = guard.Advance(dummy, guard.Input{At: at, Sequence: 1, Phase: guard.PreFill, Remaining: 1, Publication: &publication}); err != nil {
		return b.stop(err)
	}
	if previous := b.continuous.last[side]; previous != nil {
		if previous.ID == publication.ID {
			if !reflect.DeepEqual(*previous, publication) {
				return b.stop(fmt.Errorf("112同ID公表の改変"))
			}
			// reset後の同一公表は再有効化しない。
			b.continuous.lastAt = at
			return nil
		}
		if publication.End <= previous.End || publication.Ordinal <= previous.Ordinal {
			return b.stop(fmt.Errorf("112公表の後退"))
		}
	}
	copy := valueCopy(publication)
	b.continuous.latest[side], b.continuous.last[side], b.continuous.lastAt = &copy, &copy, at
	return nil
}

// ResetPublication は欠足等の元配送順で両側の技法窓だけを失効します。
//
// 引数: at(float64)、reason(string)は現在配送時計と明示理由。返り値: errorは時計/初期化不正です。
func (b *ActualBook) ResetPublication(at float64, reason string) error {
	if err := b.ready(); err != nil {
		return err
	}
	if b.continuous == nil || !finiteActual(at) || at < b.lastEventAt || at < b.continuous.lastAt || reason == "" {
		return b.stop(fmt.Errorf("112resetの時計/理由不正"))
	}
	b.continuous.latest = map[int]*guard.Publication{}
	b.continuous.reset++
	b.continuous.resetReason, b.continuous.lastAt = reason, at
	return nil
}

// initContinuousPosition は実new fill時の既知ATRだけで純状態を一度作ります。
//
// 引数: p(*ActualPosition)は実取得した新玉。返り値: errorは純初期化不正です。S0は旧経路です。
func (b *ActualBook) initContinuousPosition(p *ActualPosition) error {
	if !b.hasPure112() {
		return nil
	}
	entry := guard.Entry{Scope: b.continuousScope(), Policy: guard.Policy(b.result.Config.Policy), Side: p.Side, Price: p.EntryPrice, At: p.EntryQuote.Time, InitialQuantity: p.InitialQuantity, SlipPoints: b.result.Config.SlipPts}
	if p.ATR != nil {
		entry.ATR = &guard.Evidence{Value: p.ATR.Value, AvailableAt: p.ATR.Available, ID: fmt.Sprintf("native_ATR/%s/%s/%.17g", b.result.Session.ID, b.continuous.contract, p.ATR.Available)}
	}
	state, err := guard.NewState(entry)
	if err != nil {
		return err
	}
	snapshot := state.Snapshot()
	if p.ATR != nil {
		p.ATR.Width = snapshot.NormalWidth
	}
	p.Protection112 = &ProtectionAudit112{Initial: snapshot, FinalState: snapshot}
	b.continuous.positions[p.ID] = &continuousPosition112{state: state, resetSeen: b.continuous.reset}
	return nil
}

// continuousAdvance は1玉の単調sequenceと実返済額を純状態へ渡します。
//
// 引数: p(*ActualPosition)、at(float64)、phase(string)、mark(*float64)、reset(bool)は実玉・評価入力です。
// 返り値: guard.Snapshot/guard.Decision/errorは独立保存値と純判定です。
func (b *ActualBook) continuousAdvance(p *ActualPosition, at float64, phase string, mark *float64, reset bool) (guard.Snapshot, guard.Decision, error) {
	runtime := b.continuous.positions[p.ID]
	runtime.sequence++
	input := guard.Input{At: at, Sequence: runtime.sequence, Phase: guard.Phase(phase), Mark: mark, Remaining: p.Quantity, Reserved: p.Reserved, ClosedNetYen: p.RealizedNet}
	if reset {
		input.ResetReason = b.continuous.resetReason
	} else {
		input.Publication = b.continuous.latest[p.Side]
	}
	state, decision, err := guard.Advance(runtime.state, input)
	if err != nil {
		return guard.Snapshot{}, guard.Decision{}, err
	}
	runtime.state = state
	return state.Snapshot(), decision, nil
}

// markContinuous は予約中も実u/Wを評価しafter_sourceだけで未予約量を要求します。
//
// 引数: at(float64)、quote(*QuoteStamp)、phase(string)、issue(bool)は実時計・正常原行又はnil・位相・新要求可否です。
// 返り値: errorは純状態又は実所有不整合です。nil気配と元timerは架空MTMを作りません。
func (b *ActualBook) markContinuous(at float64, quote *QuoteStamp, phase string, issue bool) error {
	for i := range b.result.Positions {
		p := &b.result.Positions[i]
		runtime := b.continuous.positions[p.ID]
		if runtime == nil || p.Protection112 == nil {
			return fmt.Errorf("112実玉の純状態がない")
		}
		if p.Protection112.FinalState.Finished {
			continue
		}
		if runtime.resetSeen < b.continuous.reset && p.Quantity > 0 {
			if _, _, err := b.continuousAdvance(p, at, phase, nil, true); err != nil {
				return err
			}
			runtime.resetSeen = b.continuous.reset
			p.Protection112.Resets++
		}
		var mark *float64
		var point *MTMPoint
		if quote != nil && p.Quantity > 0 {
			value := quote.Bid
			if p.Side < 0 {
				value = quote.Ask
			}
			mark = &value
			gain := float64(p.Side) * (value - p.EntryPrice)
			unit := 100*gain - (77 + 200*b.result.Config.SlipPts)
			point = &MTMPoint{Quote: *quote, Phase: phase, Quantity: p.Quantity, Reserved: p.Reserved, MarkPrice: value, GainPoints: gain, UnitNet: unit, RealizedNet: p.RealizedNet, WholeNet: p.RealizedNet + float64(p.Quantity)*unit}
			updateMarks(&p.Marks, *point)
			p.HasMark = true
		}
		previousFloor := p.FloorGain
		snapshot, decision, err := b.continuousAdvance(p, at, phase, mark, false)
		if err != nil {
			return err
		}
		audit := p.Protection112
		trace := &ProtectionPoint112{At: at, Quote: quote, Phase: phase, Snapshot: snapshot, Decision: decision}
		audit.Evaluations++
		if quote == nil {
			audit.MissingQuote++
		}
		p.ProtectionActive, p.FloorGain = snapshot.Active, snapshot.FloorPoints
		if snapshot.PeakPoints != nil {
			p.PeakGain = *snapshot.PeakPoints
		}
		if decision.ActivatedNow {
			audit.FirstActivation = trace
			if point != nil {
				copy := *point
				p.Activation = &copy
			}
		}
		if decision.NarrowedNow {
			audit.FirstNarrowing = trace
		}
		if snapshot.FloorPoints != nil && (previousFloor == nil || *snapshot.FloorPoints > *previousFloor) {
			if audit.FirstFloorUpdate == nil {
				audit.FirstFloorUpdate = trace
			}
			audit.LastFloorUpdate = trace
			if point != nil {
				copy := *point
				p.FloorUpdated = &copy
			}
		}
		if decision.FloorHit && audit.FirstFloorHit == nil {
			audit.FirstFloorHit = trace
			if point != nil {
				copy := *point
				p.FirstFloorHit = &copy
			}
		}
		if decision.AllReservedHit && audit.FirstAllReservedHit == nil {
			audit.FirstAllReservedHit = trace
		}
		if issue && phase == PhaseAfterSource && decision.EligibleExitQuantity > 0 {
			if point == nil {
				return fmt.Errorf("112正常気配なしの純返済要求")
			}
			copy := *point
			reason := "112一定利益の必須追尾/" + b.result.Config.Policy
			if b.result.Config.Policy == "W100" || b.result.Config.Policy == "B100" {
				// 共通政策の説明字句も旧111固定対照と同体に保つ。
				reason = "111一定利益の必須追尾/" + b.result.Config.Policy
			}
			id, err := b.requestExit(p, decision.EligibleExitQuantity, at, *quote, reason, "", "", &copy)
			if err != nil {
				return err
			}
			trace.ExitOrderID = id
			// 実予約後の数量だけを再同期し、同原行で価格床の約定を作らない。
			snapshot, _, err = b.continuousAdvance(p, at, phase, nil, false)
			if err != nil {
				return err
			}
			trace.AfterRequest = &snapshot
		}
		audit.Last, audit.FinalState = trace, snapshot
	}
	return nil
}

// checkContinuous は原行完了後に純状態とActualの残/予約/実現/保護床を照合します。
//
// 引数: receiver(*ActualBook)は現在口座。返り値: errorは二つの状態の不整合です。
func (b *ActualBook) checkContinuous() error {
	if !b.hasPure112() {
		return nil
	}
	for _, p := range b.result.Positions {
		if p.Protection112 == nil {
			return fmt.Errorf("112純監査がない")
		}
		v := p.Protection112.FinalState
		if v.Remaining != p.Quantity || v.Reserved != p.Reserved || v.ClosedNetYen != p.RealizedNet || v.Active != p.ProtectionActive || !reflect.DeepEqual(v.FloorPoints, p.FloorGain) || v.Finished != (p.Quantity == 0) {
			return fmt.Errorf("112純保護と実所有の差:%s", p.ID)
		}
	}
	return nil
}
