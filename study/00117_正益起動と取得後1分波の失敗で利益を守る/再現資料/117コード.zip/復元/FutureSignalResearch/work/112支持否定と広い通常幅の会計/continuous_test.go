package miniprotect

import (
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	legacy "github.com/masayoshi4649/SessionTradeExecuter/continuousactor111"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor112"
)

// newActors112 は本名24条件と、共通3政策だけの旧111口座を作ります。
//
// 引数: t(*testing.T)は検査器です。
// 返り値: map二つは新24口座と旧12口座です。元Sourceへ値を返しません。
func newActors112(t *testing.T) (map[string]*ActualBook, map[string]*legacy.ActualBook) {
	t.Helper()
	current, previous := map[string]*ActualBook{}, map[string]*legacy.ActualBook{}
	for _, cfg := range DeclaredContinuousConfigurations() {
		book, err := NewContinuousBook(session94(), "人工限月112", cfg)
		if err != nil {
			t.Fatal(err)
		}
		current[book.Snapshot().Key] = book
		if cfg.Policy == "S0" || cfg.Policy == "W100" || cfg.Policy == "B100" {
			old, e := legacy.NewContinuousBook(session94(), "人工限月112", legacy.ActorConfig{Policy: cfg.Policy, SlipPts: cfg.SlipPts, DelaySeconds: cfg.DelaySeconds})
			if e != nil {
				t.Fatal(e)
			}
			previous[book.Snapshot().Key] = old
		}
	}
	return current, previous
}

// publication112 はCとPを独立に設定した片側の確定3分公表を手製作成します。
//
// 引数: side(int)、ordinal(uint64)、broken(bool)は方向・公表順・支持否定です。
// 返り値: guard.PublicationはCを隠さない、元戦略や市場を使わない公表です。
func publication112(side int, ordinal uint64, broken bool) guard.Publication {
	s := session94()
	close, pivot, kind := 1110.0, 1100.0, "low"
	if broken {
		close = 1090
	}
	if side < 0 {
		close, pivot, kind = 2000-close, 2000-pivot, "high"
	}
	v := 20.0
	end := s.Start + 1440 + float64(ordinal)*180
	scope := guard.Scope{Session: s.ID, Contract: "人工限月112", Start: s.Start}
	return guard.Publication{Scope: scope, ID: "手製支持公表/" + string(rune('0'+ordinal)), Ordinal: ordinal,
		Start: end - 180, End: end, AvailableAt: end, C: guard.True, M: guard.True, Close: &close, V: &v,
		PriorPivot: &guard.Pivot{Scope: scope, ID: "手製prior", Kind: kind, Price: pivot,
			CenterStart: s.Start + 180, CenterEnd: s.Start + 360, ConfirmEnd: s.Start + 540, PublishedAt: s.Start + 600}}
}

// compareEvery112 は受理原行又はFinish直後の12旧対照を全JSONで検査します。
//
// 引数: t(*testing.T)、current/previous(map)は新24と旧12口座です。
// 返り値: なし。定義の追加以外の数値やC/M/P/Bは隠しません。
func compareEvery112(t *testing.T, current map[string]*ActualBook, previous map[string]*legacy.ActualBook) {
	t.Helper()
	for key, old := range previous {
		proof, err := CompareLegacy111(current[key].Snapshot(), old.Snapshot())
		if err != nil || !proof.AllFinancialEqual || !proof.StreamScopeChanged {
			t.Fatalf("%s:旧3政策の原行全JSON差:%v %+v", key, err, proof)
		}
	}
}

// fixture112 は買売鏡像の全24へ同じSource通知・欠気配・部分返済を配送します。
//
// 引数: t(*testing.T)、side(int)、atr(float64)、unknown(bool)は人工方向・取得ATR・取得時未知です。
// 返り値: fixture94は全入力原行と実結果。旧94の通知型を使うAPI人工です。
func fixture112(t *testing.T, side int, atr float64, unknown bool) fixture94 {
	t.Helper()
	current, previous := newActors112(t)
	source, scene := newFixtureSource94(), session94()
	fixture := fixture94{Session: scene, Scope: "112手製API通知。市場・Raw・CSV・FAR自然生成なし。", Steps: []fixtureStep94{}, Timers: []fixtureTimer94{}}
	seconds := []float64{0, .5, 1, 1, 2, 3, 4, 5, 6, 7, 8, 9}
	moves := []float64{0, 0, 130, 450, 350, 400, 250, 50, 70, 0, 0, 0}
	for i, move := range moves {
		known := atr
		if unknown && i < 3 {
			known = 0
		}
		o := observation94(scene, side, int64(i), seconds[i], move, known)
		if i == 5 {
			o.QuoteOK = false
		}
		if i == 3 || i == 6 {
			ordinal := uint64(1)
			if i == 6 {
				ordinal = 2
			}
			for _, direction := range []int{1, -1} {
				pub := publication112(direction, ordinal, i == 6)
				for _, b := range current {
					if b.Snapshot().Config.Policy != "S0" {
						if err := b.SetPublication(o.Time, direction, pub); err != nil {
							t.Fatal(err)
						}
					}
				}
				for _, b := range previous {
					if b.Snapshot().Config.Policy != "S0" {
						if err := b.SetPublication(o.Time, direction, pub); err != nil {
							t.Fatal(err)
						}
					}
				}
			}
		}
		if i == 8 {
			for _, b := range current {
				if b.Snapshot().Config.Policy != "S0" {
					if err := b.ResetPublication(o.Time, "手製欠足"); err != nil {
						t.Fatal(err)
					}
				}
			}
			for _, b := range previous {
				if b.Snapshot().Config.Policy != "S0" {
					if err := b.ResetPublication(o.Time, "手製欠足"); err != nil {
						t.Fatal(err)
					}
				}
			}
		}
		news := []native.Signal{}
		if i == 0 {
			news = append(news, birth94("A", side, 5))
		}
		if i == 4 {
			news = append(news, close94("元部分A", "A", side, 2))
		}
		if i == 9 {
			news = append(news, close94("元全残A", "A", side, 3))
		}
		batch := source.step(t, o, int64(i+100), news, nil)
		fixture.Steps = append(fixture.Steps, feed94(t, current, o, batch))
		for _, b := range previous {
			if err := b.OnNativeStep(o, batch.Delta.SourceLine, []legacy.NativeBatch{{Method: batch.Method, Delta: batch.Delta}}); err != nil {
				t.Fatal(err)
			}
		}
		compareEvery112(t, current, previous)
		if i == 3 && !unknown {
			p := current["P100_C0_D0"].Snapshot().Positions[0].Protection112.Last
			if p.Decision.C != guard.True || p.Decision.P != guard.False || p.Decision.Warning != guard.False || p.Snapshot.Narrowed {
				t.Fatal("P必須条件又はC/Pの観測値をマスク", p)
			}
		}
	}
	fixture.Actors = finish94(t, current)
	for _, old := range previous {
		if _, err := old.Finish(); err != nil {
			t.Fatal(err)
		}
	}
	compareEvery112(t, current, previous)
	for _, book := range fixture.Actors {
		if book.Config.Policy == "S0" {
			continue
		}
		position := book.Positions[0]
		want := 200.0
		multiplier := 2.0
		if book.Config.Policy == "W400" || book.Config.Policy == "P400" {
			want, multiplier = 400, 4
		}
		if !unknown && multiplier*atr > want {
			want = multiplier * atr
		}
		if position.Protection112.Initial.NormalWidth != want || !position.Protection112.FinalState.Finished {
			t.Fatal("本名通常幅又は全玉完結", book.Key)
		}
		if unknown {
			if position.ATR != nil || !position.Protection112.Initial.ATRUnknownFallback {
				t.Fatal("取得後ATRで幅を付替え", book.Key)
			}
		} else if position.ATR == nil || position.ATR.Width != want {
			t.Fatal("実取得の幅と純通常幅差", book.Key)
		}
	}
	return fixture
}

// TestContinuous112DeclaredAndLegacy は本名24と買売・未知ATR・大きなATRの旧12対照を検査します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestContinuous112DeclaredAndLegacy(t *testing.T) {
	if len(DeclaredContinuousConfigurations()) != 24 {
		t.Fatal("24宣言でない")
	}
	for _, side := range []int{1, -1} {
		fixture112(t, side, 20, false)
		fixture112(t, side, 20, true)
		fixture112(t, side, 150, false)
	}
	for _, invalid := range []ActorConfig{{Policy: "U100"}, {Policy: "T100"}, {Policy: "P0"}, {Policy: "P400", SlipPts: 1}, {Policy: "P400", DelaySeconds: 2}} {
		if _, err := NewContinuousBook(session94(), "人工限月112", invalid); err == nil {
			t.Fatal("112の宣言外条件を受理", invalid)
		}
	}
}

// TestContinuous112LegacyCapAndPartial は旧94の上限・取消・部分返済器具も旧111と毎行照合します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。入力は実FAR生成ではありません。
func TestContinuous112LegacyCapAndPartial(t *testing.T) {
	fixtures := []fixture94{capCancel94(t), wave94(t, 1, false), wave94(t, -1, true)}
	for _, fixture := range fixtures {
		current, previous := newActors112(t)
		for _, step := range fixture.Steps {
			for _, b := range current {
				if err := b.OnNativeStep(step.Observation, step.SourceLine, step.Batches); err != nil {
					t.Fatal(err)
				}
			}
			for _, b := range previous {
				batch := []legacy.NativeBatch{}
				for _, value := range step.Batches {
					batch = append(batch, legacy.NativeBatch{Method: value.Method, Delta: value.Delta})
				}
				if err := b.OnNativeStep(step.Observation, step.SourceLine, batch); err != nil {
					t.Fatal(err)
				}
			}
			compareEvery112(t, current, previous)
		}
		for _, timer := range fixture.Timers {
			for _, b := range current {
				if err := b.OnNativeForce(timer.At, timer.Batches); err != nil {
					t.Fatal(err)
				}
			}
			for _, b := range previous {
				batch := []legacy.NativeBatch{}
				for _, value := range timer.Batches {
					batch = append(batch, legacy.NativeBatch{Method: value.Method, Delta: value.Delta})
				}
				if err := b.OnNativeForce(timer.At, batch); err != nil {
					t.Fatal(err)
				}
			}
			compareEvery112(t, current, previous)
		}
		finish94(t, current)
		for _, b := range previous {
			if _, err := b.Finish(); err != nil {
				t.Fatal(err)
			}
		}
		compareEvery112(t, current, previous)
	}
}

// TestContinuous112Mirror は新3政策を含む全24の買売鏡像会計を確認します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestContinuous112Mirror(t *testing.T) {
	buy, sell := fixture112(t, 1, 20, false), fixture112(t, -1, 20, false)
	for key, left := range buy.Actors {
		right := sell.Actors[key]
		if !reflect.DeepEqual(left.Totals, right.Totals) || len(left.Fills) != len(right.Fills) {
			t.Fatal("112買売鏡像の会計差", key)
		}
	}
}

// TestContinuous112ComparisonRejectsFinancialMutation は説明版差以外の隠蔽を拒否します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestContinuous112ComparisonRejectsFinancialMutation(t *testing.T) {
	current, previous := newActors112(t)
	source := newFixtureSource94()
	for index := int64(0); index < 2; index++ {
		o := observation94(session94(), 1, index, float64(index), 0, 20)
		news := []native.Signal{}
		if index == 0 {
			news = append(news, birth94("比較破壊A", 1, 1))
		}
		batch := source.step(t, o, index+200, news, nil)
		feed94(t, current, o, batch)
		for _, b := range previous {
			if err := b.OnNativeStep(o, index+200, []legacy.NativeBatch{{Method: batch.Method, Delta: batch.Delta}}); err != nil {
				t.Fatal(err)
			}
		}
	}
	compareEvery112(t, current, previous)
	for _, key := range []string{"S0_C0_D0", "W100_C0_D0", "B100_C0_D0"} {
		value := current[key].Snapshot()
		value.Totals.NetYen++
		if _, err := CompareLegacy111(value, previous[key].Snapshot()); err == nil {
			t.Fatal("純額破壊を隠した", key)
		}
	}
	if _, err := CompareLegacy111(current["P100_C0_D0"].Snapshot(), previous["W100_C0_D0"].Snapshot()); err == nil {
		t.Fatal("新政策を旧policyへ偽装")
	}
	definition := current["W100_C0_D0"].Snapshot()
	definition.Positions[0].Protection112.Initial.Definition.NormalWidthMinimum++
	if _, err := CompareLegacy111(definition, previous["W100_C0_D0"].Snapshot()); err == nil {
		t.Fatal("112の幅定義改変を隠した")
	}
	observation := current["B100_C0_D0"].Snapshot()
	observation.Positions[0].Protection112.Last.Decision.C = guard.True
	if _, err := CompareLegacy111(observation, previous["B100_C0_D0"].Snapshot()); err == nil {
		t.Fatal("生C観測値の差を隠した")
	}
}

// TestContinuous112FuturePublication は未来・別場・別限月の入力を拒否します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestContinuous112FuturePublication(t *testing.T) {
	for _, kind := range []string{"future", "session", "contract"} {
		b, err := NewContinuousBook(session94(), "人工限月112", ActorConfig{Policy: "P400"})
		if err != nil {
			t.Fatal(err)
		}
		pub := publication112(1, 1, false)
		at := session94().Start + 1800
		switch kind {
		case "future":
			pub.AvailableAt = at + 1
		case "session":
			pub.Scope.Session = "別場"
		case "contract":
			pub.Scope.Contract = "別限月"
		}
		if err := b.SetPublication(at, 1, pub); err == nil {
			t.Fatal("112未来又は別Scopeを受理", kind)
		}
	}
}

// TestExportContinuous112Fixtures は明示時だけ買売人工と実24宣言を保存します。
//
// 引数: CONTINUOUS112_EXPORT_DIR(string環境変数)は未使用先。返り値: なし。
func TestExportContinuous112Fixtures(t *testing.T) {
	directory := os.Getenv("CONTINUOUS112_EXPORT_DIR")
	if directory == "" {
		t.Skip("112手製人工exportは明示時だけ")
	}
	if err := os.Mkdir(directory, 0700); err != nil {
		t.Fatal(err)
	}
	values := map[string]any{"宣言設定.json": DeclaredContinuousConfigurations(), "保護定義.json": guard.DeclaredDefinitions(),
		"買い.json": fixture112(t, 1, 20, false), "売り.json": fixture112(t, -1, 20, false)}
	for name, value := range values {
		body, err := json.MarshalIndent(value, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(filepath.Join(directory, name), append(body, '\n'), 0600); err != nil {
			t.Fatal(err)
		}
	}
}
