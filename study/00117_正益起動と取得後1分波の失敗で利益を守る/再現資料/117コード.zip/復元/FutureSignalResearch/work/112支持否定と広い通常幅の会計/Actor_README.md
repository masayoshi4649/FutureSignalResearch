# 112の連続Actor（市場前）

moduleは `github.com/masayoshi4649/SessionTradeExecuter/continuousactor112`、packageは `miniprotect`。旧111 Actor停止6503を別フォルダへ派生し、純112を接続した。旧111・旧94の原本は変更しない。

`DeclaredContinuousConfigurations()` と `NewContinuousBook(session,contract,cfg)` はS0/W100/B100/W400/P100/P400×C0/C5×D0/D1の24だけを受理する。旧人工用 `NewActualBook` は残すが市場側は新constructorを使う。SetPublication/ResetPublication/OnNativeStep/Finishは111と同じ形で、公開型はpure112（Publication等はpure111 alias）を使う。Source.NativeBatchは別の名前付き型なので外側だけ明示変換する。

一定利益100ptの全玉W起動・全玉床・片側10mini・片道税込38.5円・費用C0/C5・原時計遅延D0/D1・元close優先・予約・部分返済・正常な後原行の実BBO約定を継承する。新規時計・開始静観・参加率条件を追加しない。取得時ATRだけを固定し、未知なら通常幅200又は400を使い、後知りATRで付け替えない。

W100は200/2A、W400は400/4Aの通常幅。B100は200/2AにM AND(C OR B OR P)の警戒による狭幅を加える。P100/P400は通常幅200/2A又は400/4AにM AND Pだけの狭幅を加える。真の政策IDと純Snapshot.definitionの版112・最小幅・ATR倍率・警戒式を保存し、CやBの観測値をマスクしない。

`CompareLegacy111(current,prior)` は未Finishの原行Snapshotも受理する。共通S0/W100/B100×4の12対照だけを受理し、説明StreamScope、positionsのprotection112→protection111という監査型版名、各Snapshotの追加definitionだけを分離する。definitionは当政策のDeclaredDefinitions全値へ厳密に照合する。その他の注文・約定・所有・費用・時刻・床・u/W・C/M/P/B・Decision・全監査値は全JSONで一致を要求する。共通W100/B100の保護reasonも111字句を固定対照として保持する。新W400/P100/P400は112字句を使う。新政策を旧policy名へ偽装しない。

純状態のBeforeSnapshot・全中間要求witnessは追加せず、少数保存点は112型として保存する。独立P監査では111と同じexact/boundedの限界を継承する。定義・政策を変更した値を旧金融へ等しいと主張しない。

人工は旧94のAPI通知器具を同bytesで再用する。新5主で全24の買売鏡像・取得時未知・大きなATR・部分返済・欠気配・支持否定必須・未来/別Scope拒否・旧12の毎原行/終了全JSON・上限取消器具の再配送・純額/definition/生C破壊拒否を確認する。旧94の6主も維持する。手製通知であり実市場・自然FAR生成の証明ではない。

Actorの停止は `Actor停止.json` とし、所有Go・module・派生元・Actor専用資料だけを固定する。今後のPython会計・保存は別名の所有集合と停止へ分ける。市場Native・Raw・価格CSV・11/09本文はRootの条件固定後まで読まない。
