"""停止111のActorを、純112・監査型の版名だけを明示して新規派生する。"""

import hashlib
import json
from pathlib import Path


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
OLD = ROOT / 'work/111元通知の連続Actor'
OLD_STOP = '6503962ebb7189213a182f8801916e99503ddfa88d0a99426107f3755535cbf2'


def digest(path: Path) -> str:
    """機能: 明示した停止原本の全bytesを指紋化する。

    引数: path(Path)はコード又は停止metadata。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """機能: 原本を変更せず4実装・旧94人工・module設定を新規派生する。

    引数: なし。
    返り値: None。既存派生先又は停止差はValueError。
    """
    if digest(OLD / '停止.json') != OLD_STOP:
        raise ValueError('旧111 Actor停止のSHA差')
    original = json.loads((OLD / '停止.json').read_text(encoding='utf-8'))
    inputs = []
    for name in ('actual.go', 'actual_types.go', 'actual_test.go', 'continuous.go', 'go.mod', 'go.sum'):
        source, target = OLD / name, OWN / name
        if target.exists():
            raise ValueError('派生先が既存: ' + name)
        body = source.read_bytes()
        if original['所有コードSHA256'][str(source)] != digest(source):
            raise ValueError('停止所有コード差: ' + name)
        text = body.decode('utf-8')
        if name in ('actual.go', 'actual_types.go', 'continuous.go'):
            text = text.replace('111', '112')
        if name == 'go.mod':
            text = text.replace('continuousactor111', 'continuousactor112').replace('profitfloor111', 'profitfloor112')
            text = text.replace('../111全玉利益と収束BBの純保護', '../112支持否定の必須確認と通常幅のみ')
            text += '\nrequire github.com/masayoshi4649/SessionTradeExecuter/continuousactor111 v0.0.0\n'
            text += '\nreplace github.com/masayoshi4649/SessionTradeExecuter/continuousactor111 => ../111元通知の連続Actor\n'
            text += '\nrequire github.com/masayoshi4649/SessionTradeExecuter/profitfloor111 v0.0.0\n'
            text += '\nreplace github.com/masayoshi4649/SessionTradeExecuter/profitfloor111 => ../111全玉利益と収束BBの純保護\n'
        with target.open('x', encoding='utf-8', newline='\n') as stream:
            stream.write(text)
        inputs.append({'path': str(source), 'sha256': digest(source), 'target': name,
                       '派生時SHA256': digest(target), '同bytes': body == target.read_bytes()})
    record = {'試行': 112, '元Actor停止': {'path': str(OLD / '停止.json'), 'sha256': OLD_STOP},
              '入力': inputs, '実装変更予定': '純112 import・版名・共通3対照・真の政策定義。注文/所有/費用/原行順を維持。',
              '元ファイル変更': False, '市場本文読取': 0}
    with (OWN / 'Actorの派生元.json').open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(record, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


if __name__ == '__main__':
    main()
