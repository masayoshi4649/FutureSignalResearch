"""111の実約定台帳を、停止94の政策非依存会計から独立に照合する。"""

import ast
import hashlib
import importlib.util
import inspect
import math
from pathlib import Path
import textwrap


ROOT = Path(__file__).resolve().parents[2]
BASE_PATH = ROOT / 'scripts/FAR連続出生と個別利益追尾/集計.py'
BASE_SHA = '7c0c1d1b365226c74027405589099cb72382c7850090627a83788e1e2066c381'
if hashlib.sha256(BASE_PATH.read_bytes()).hexdigest() != BASE_SHA:
    raise ValueError('停止94会計の実物SHA差')
SPEC = importlib.util.spec_from_file_location('停止94の純会計111', BASE_PATH)
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)
need, equal, number, money = BASE.require, BASE.equal, BASE.number, BASE.money
POLICIES = ('S0', 'U100', 'W100', 'T100', 'B100', 'B50')
CONFIGS = tuple({'policy': p, 'slip_pts': c, 'delay_seconds': d}
                for p in POLICIES for c in (0, 5) for d in (0, 1))


def key_for(config: dict) -> str:
    """機能: 本名の24設定だけを受理して口座識別子を返す。

    引数: config(dict)は政策・片道滑り・原時計遅延。
    返り値: strはActorの本名キー。不正ならValueError。
    """
    need(config in CONFIGS and set(config) == {'policy', 'slip_pts', 'delay_seconds'}, '111宣言外の設定')
    return f"{config['policy']}_C{config['slip_pts']}_D{config['delay_seconds']}"


BY_KEY = {key_for(c): c for c in CONFIGS}
KEYS = tuple(BY_KEY)


def verify_marks(position: dict, timeline, policy: str) -> None:
    """機能: 保存MTMの所有・u/W・符号・時系列・ATR取得時計を検算する。

    引数: position(dict)は実玉、timeline(BASE.Timeline)は全実約定、policy(str)は本名政策。
    返り値: None。純保護の起動・床・狭幅の式は別監査に委ねる。
    """
    if policy == 'S0':
        BASE.verify_marks(position, timeline, policy)
        need(position.get('protection111') is None, 'S0に新保護履歴なし')
        return
    marks = position['marks']
    names = {'first', 'last', 'first_unit_positive', 'first_whole_positive',
             'first_unit_nonpositive_after', 'first_unit_negative_after',
             'first_whole_nonpositive_after', 'first_whole_negative_after',
             'unit_max', 'unit_min', 'whole_max', 'whole_min'}
    equal(set(marks), names, '保存MTM集合')
    points = list(marks.values()) + [position[k] for k in ('activation', 'floor_updated', 'first_floor_hit')]
    for point in points:
        if point is not None:
            timeline.verify_position_point(position['id'], point)
    for prefix, amount in (('unit', 'unit_net'), ('whole', 'whole_net')):
        first = marks['first_' + prefix + '_positive']
        if first is not None:
            need(first[amount] > 0, '初正益の厳密符号')
        for suffix, strict in (('nonpositive_after', False), ('negative_after', True)):
            point = marks['first_' + prefix + '_' + suffix]
            if point is not None:
                need(first is not None and BASE.point_order(first) < BASE.point_order(point), '正益後の保存順序')
                need(point[amount] < 0 if strict else point[amount] <= 0, '正益後の符号')
        high, low = marks[prefix + '_max'], marks[prefix + '_min']
        if high is not None or low is not None:
            need(high is not None and low is not None and high[amount] >= low[amount], '保存極値対')
            need(all(low[amount] <= p[amount] <= high[amount] for p in marks.values() if p is not None), '保存点の極値内')
    if marks['first'] is None:
        need(position['has_mark'] is False and all(p is None for p in marks.values()), '未観測MTMのnullable')
    else:
        need(position['has_mark'] is True and marks['last'] is not None, '保存MTMの始終')
        need(all(BASE.point_order(marks['first']) <= BASE.point_order(p) <= BASE.point_order(marks['last'])
                 for p in points if p is not None), '保存点の観測範囲')
    if position['protection_active']:
        need(position['activation'] is not None and position['floor_gain'] is not None, '起動後の床必須')
    else:
        need(all(position[k] is None for k in ('activation', 'floor_gain', 'floor_updated', 'first_floor_hit')), '未起動床のnullable')
    atr = position['atr']
    if atr is not None:
        equal(set(atr), {'value', 'available', 'nominal', 'age_seconds', 'width', 'quote', 'after_entry'}, 'ATR型')
        BASE.quote(atr['quote'], '取得時ATR原行')
        need(atr['value'] > 0 and atr['quote']['time'] >= atr['available'] >= atr['nominal'] > 0, 'ATR公表時計')
        equal(atr['quote'], position['entry_quote'], 'ATRを実取得時だけ固定')
        need(atr['after_entry'] is False, '後取得ATR禁止')
        need(float(atr['age_seconds']) == float(atr['quote']['time']) - float(atr['available']), 'ATR ageの元IEEE64')
        equal(atr['width'], 5 * math.ceil(max(200, 2 * float(atr['value'])) / 5), '取得時通常幅')


def accounting_function():
    """機能: 停止94から政策prefix4文と旧ATR後取得metric1式だけを明示分離する。

    引数: なし。
    返り値: functionはbook/config/policyを受ける全台帳会計。不明な原文差は拒否する。
    """
    tree = ast.parse(textwrap.dedent(inspect.getsource(BASE.verify_book)))
    function = tree.body[0]
    expected = ["require(key in KEYS and book['key'] == key, 'Actor key')", "policy, cost, delay = key.split('_')",
                "config = {'policy': policy, 'slip_pts': int(cost[1:]), 'delay_seconds': int(delay[1:])}",
                "equal(book['config'], config, 'Actor config')"]
    equal([ast.unparse(n) for n in function.body[1:5]], expected, '分離する正確な4文')
    function.name = 'pure_accounting111'
    function.body = [function.body[0]] + function.body[5:]
    function.args.args = [ast.arg(arg=n) for n in ('book', 'config', 'policy')]
    changed = 0
    for node in ast.walk(function):
        if isinstance(node, ast.Dict):
            for index, key in enumerate(node.keys):
                if isinstance(key, ast.Constant) and key.value == 'atr_deferred_positions':
                    equal(ast.unparse(node.values[index]), "sum((p['atr'] is None or p['atr']['after_entry'] for p in saved.values()))", '旧ATRmetric原式')
                    node.values[index] = ast.parse("sum(p['atr'] is None or p['atr']['after_entry'] for p in saved.values()) if policy == 'S0' else 0", mode='eval').body
                    changed += 1
    equal(changed, 1, 'ATRmetricの限定変更数')
    space = {**vars(BASE), 'verify_marks': verify_marks}
    exec(compile(ast.fix_missing_locations(tree), str(Path(__file__).resolve()) + ':停止94純会計', 'exec'), space)
    return space[function.name]


PURE_ACCOUNTING = accounting_function()


def verify_source_reservations(book: dict, finance: dict) -> None:
    """機能: 元部分返済直前の実未予約量を全約定・先行要求から再構成する。

    引数: book/finance(dict)は実台帳と純会計の返り値。
    返り値: None。Sourceが記録したfreeをそのまま規範にしない。
    """
    by_hold = {(p['source']['method'], p['source_hold_id']): p for p in book['positions']}
    need(len(by_hold) == len(book['positions']), '元所有に複数の実玉なし')
    earlier_source_orders = set()
    for event in book['source_events']:
        if event['kind'] != 'close_notice':
            continue
        current = by_hold.get((event['method'], event['hold_id']))
        free = 0
        if current is not None:
            point = {'quote': event['quote'], 'phase': 'after_source'}
            state = finance['timeline'].state_at(current['id'], point)
            quantity = state['quantity'] if state is not None else 0
            reserved = 0
            index = event['quote']['index']
            for order in finance['orders'].values():
                if order['kind'] != 'exit' or order['position_id'] != current['id']:
                    continue
                request_index = order['request_quote']['index']
                accepted = request_index < index or (request_index == index and order['id'] in earlier_source_orders)
                fill = finance['timeline'].fill_by_order.get(order['id'])
                already_filled = fill is not None and fill['quote']['index'] <= index
                if accepted and not already_filled:
                    reserved += order['quantity']
            need(0 <= reserved <= quantity, 'Source返済前の実予約範囲')
            free = quantity - reserved
        equal(event['actual_free_before'], free, 'Source返済前の独立未予約量')
        equal(event['actual_free_after'], free - event['actual_exit_requested'], 'Source返済要求後の独立未予約量')
        if event['order_id']:
            earlier_source_orders.add(event['order_id'])


def verify_finance(book: dict, config: dict) -> dict:
    """機能: 全注文・約定・所有・費用・保存DDを本名設定で独立検算する。

    引数: book/config(dict)は原値の実Actorと111宣言設定。
    返り値: dictはtotals/counts/positions/orders/timeline/book。原値を変更しない。
    """
    equal(book['key'], key_for(config), '111本名key')
    equal(book['config'], config, '111本名設定')
    before = repr(book)
    result = PURE_ACCOUNTING(book, config, config['policy'])
    verify_source_reservations(book, result)
    for event in book['source_events']:
        need(type(event['side']) is int and event['side'] in (-1, 1), '源通知の方向型')
        if event['order_id']:
            equal(event['side'], result['orders'][event['order_id']]['side'], '源通知と実注文の方向')
    for fill in book['fills']:
        order = result['orders'][fill['order_id']]
        need(fill['quote']['source_line'] > order['request_quote']['source_line'], '物理行も要求より後')
    equal(book['metrics']['timer_calls'], 0, '研究側timerなし')
    if config['policy'] != 'S0':
        fallback = sum(p['atr'] is None for p in book['positions'])
        equal(book['metrics'].get('atr_unknown_fallback_positions', 0), fallback, '不明ATR固定200幅数')
        result['counts']['atr_unknown_fallback_positions'] = fallback
    equal(repr(book), before, '金融原値の非変更')
    return {**result, 'book': book}
