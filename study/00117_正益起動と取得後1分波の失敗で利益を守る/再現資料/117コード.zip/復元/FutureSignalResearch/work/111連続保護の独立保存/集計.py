"""111の保存Nativeを再読し、24会計・実現集計・Viewer資料を新規保存する。"""

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from decimal import Decimal
import gzip
import hashlib
import json
from pathlib import Path

import 会計の独立検算 as A


BASE, need, equal = A.BASE, A.need, A.equal
KEYS, BY_KEY = A.KEYS, A.BY_KEY
ZERO = Decimal(0)
SOURCE_FIELDS = ('at', 'phase', 'method', 'kind', 'signal_id', 'execution_id', 'hold_id',
                 'notice_id', 'quote', 'side', 'quantity', 'before')


def digest(path: Path) -> str:
    """機能: 明示ファイルの全bytes指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict:
    """機能: JSON又はgzipをDecimalで読み非有限値を拒む。

    引数: path(Path)は認証済みNative又はmetadata。
    返り値: dictは元数値の保存値。
    """
    opener = gzip.open if path.suffix == '.gz' else open
    with opener(path, 'rt', encoding='utf-8-sig') as stream:
        return json.load(stream, parse_float=Decimal, parse_constant=lambda s: BASE.fail('非標準数値' + s))


def source_projection(book: dict) -> list:
    """機能: Actorの参加量に依存しない元通知列を射影する。

    引数: book(dict)は実口座。
    返り値: listは原行・元ID・元量・方向を保持する全通知。
    """
    return [tuple(event[k] for k in SOURCE_FIELDS) for event in book['source_events']]


def verify_source(value: dict, artificial: bool) -> dict:
    """機能: Source四対照と全24冊の通知非干渉を独立に照合する。

    引数: value(dict)はCore Native、artificial(bool)は手製Source器具の区分。
    返り値: dictは全S0照合とD0源約定結合の件数。
    """
    source, actual = value['source'], value['actual']
    need(source['complete'] is True and actual['complete'] is True, '源と実口座の完結')
    equal(value['S0_comparisons'], 4, 'Core S0比較数')
    need(value['S0_equal'] is True, 'Core S0照合flag')
    equal(set(source['books']), set(KEYS[:4]), 'Source四費用集合')
    baseline = source_projection(source['books']['S0_C0_D0'])
    for key in KEYS:
        equal(source_projection(actual['books'][key]), baseline, '全24へ同じSource通知.' + key)
    for key in KEYS[:4]:
        before = source['books'][key]
        current = actual['books'][key]
        equal({k: v for k, v in current.items() if k != 'stream_scope'},
              {k: v for k, v in before.items() if k != 'stream_scope'}, 'S0全金融JSON.' + key)
        A.verify_finance(before, BY_KEY[key])
    bound, allocated = 0, 0
    if not artificial:
        equal(source['explicit_timer_calls'], 0, '源timerなし')
        need(source['mini_source_D0_fill_equal'] is True, '源D0鏡像flag')
        minis = {k.removeprefix('NK225mini_'): b for k, b in source['sources'].items() if k.startswith('NK225mini_')}
        expected = sorted((p for method, ledger in minis.items() for p in BASE.native_fill_projection(method, ledger['fills'])), key=repr)
        for cost in (0, 5):
            book = actual['books'][f'S0_C{cost}_D0']
            equal(sorted((BASE.normalized_actual_fill(f) for f in book['fills']), key=repr), expected, 'S0 D0全Source約定の物理行結合')
        new = {(method, rec['fill']['SignalID']): rec for method, ledger in minis.items()
               for rec in ledger['fills'] if rec['action'] == 'new'}
        for key in KEYS:
            if BY_KEY[key]['delay_seconds'] != 0:
                continue
            for fill in actual['books'][key]['fills']:
                if fill['action'] != 'new':
                    continue
                native = new[(BASE.SOURCE_METHODS[fill['source']['method']], fill['source']['signal_id'])]
                equal(fill['quote'], native['quote'], 'D0新規のSource初回fill原行')
                equal(fill['price'], native['fill']['Price'], 'D0新規のSource初回fill価格')
                need(fill['quantity'] <= native['fill']['Quantity'], 'D0新規のSource割当上限')
                bound += 1
                allocated += fill['quantity'] != native['fill']['Quantity']
    return {'S0全金融JSON': 4, '全24の元通知同体': True, 'D0源新規結合': bound,
            'D0源出生から割当減少': allocated, '手製Source器具': artificial,
            '当時保存166との同体': value['original_historical_events_equal']}


def inspect_scene(value: dict, artificial: bool = False) -> dict:
    """機能: 一場24冊の会計と独立純保護監査を結合する。

    引数: value(dict)はCore実型Native、artificial(bool)は市場でない手製API器具。
    返り値: dictはcheckedとsource。Raw別走による正常原行の初回性は証明しない。
    """
    import 新保護の独立監査 as P
    actual = value['actual']
    need(actual['version'] == 1 and actual['trial'] == 111 and actual['complete'] is True, '111 Core完結')
    equal(actual['configurations'], list(A.CONFIGS), '実24宣言と順序')
    equal(set(actual['books']), set(KEYS), '全24冊集合')
    equal(actual['entry_grid_seconds'], None, '研究側新規時計なし')
    equal(actual['extra_opening_quiet_seconds'], 0, '研究側開始静観なし')
    equal(actual['explicit_timers'], 0, '研究側timerなし')
    equal(actual['chart_seed_mode'], 'cold_each_session', '当場cold')
    equal(actual['scope']['session'], value['source']['session'], '源とActor場')
    equal(actual['scope']['contract'], value['source']['contract'], '源とActor限月')
    equal(actual['counts']['publications'], len(actual['publications'] or []), '公開件数')
    equal(actual['counts']['resets'], len(actual['resets'] or []), 'reset件数')
    context = {k: actual[k] for k in ('scope', 'publications', 'resets', 'counts', 'final_chart')}
    checked = {}
    for key, config in BY_KEY.items():
        book = actual['books'][key]
        equal(book['session'], actual['scope']['session'], '全24の同一場')
        equal(book['metrics']['rows'], actual['counts']['rows'], '全24の受理行数')
        equal(book['metrics']['bad_quote_rows'], actual['counts']['bad_quotes'], '全24の異常気配行数')
        finance = A.verify_finance(book, config)
        finance['protection_counts'] = P.verify_protection(book, config, finance, context)
        checked[key] = finance
    return {'checked': checked, 'source': verify_source(value, artificial)}


def profit_statistics(row: dict) -> dict:
    """機能: 完結実玉単位の勝率・平均損益・PFを定義付きで計算する。

    引数: row(dict)は正負金額と件数。
    返り値: dictはゼロ分母をNoneとする比率。引分を勝率分母へ含める。
    """
    positive, negative = row['positive_yen'], row['negative_yen']
    wins, losses, count = row['positive_positions'], row['negative_positions'], row['positions']
    average_win = positive / wins if wins else None
    average_loss = negative / losses if losses else None
    return {'PF': positive / -negative if negative < 0 else None,
            'win_rate': Decimal(wins) / count if count else None,
            'average_profit_yen': average_win, 'average_loss_yen': average_loss,
            'average_profit_loss_ratio': average_win / -average_loss if average_win is not None and average_loss is not None else None}


def holding_diagnostics(book: dict) -> dict:
    """機能: 実約定間の保有時間と数量秒を積分し、固定判断枠を作らず記録する。

    引数: book(dict)はflat完結の全約定。
    返り値: dictは実保有秒・買売秒・両建秒・数量秒・実玉時間合計と原行数。
    """
    quantities = {1: 0, -1: 0}
    held = buy = sell = both = quantity_seconds = ZERO
    previous = None
    for fill in book['fills']:
        at = A.number(fill['quote']['time'], '保有時計')
        if previous is not None:
            span = at - previous
            need(span >= 0, '約定時刻の非後退')
            held += span * bool(quantities[1] or quantities[-1])
            buy += span * bool(quantities[1])
            sell += span * bool(quantities[-1])
            both += span * bool(quantities[1] and quantities[-1])
            quantity_seconds += span * sum(quantities.values())
        direction = fill['side'] if fill['action'] == 'new' else -fill['side']
        quantities[direction] += fill['quantity'] * (1 if fill['action'] == 'new' else -1)
        need(0 <= quantities[direction] <= 10, '保有積分の片側量')
        previous = at
    equal(quantities, {1: 0, -1: 0}, '保有積分の最後flat')
    position_seconds = sum((p['closed_quote']['time'] - p['entry_quote']['time'] for p in book['positions']), ZERO)
    return {'source_rows': book['metrics']['rows'], 'bad_quote_rows': book['metrics']['bad_quote_rows'],
            'entry_fills': sum(f['action'] == 'new' for f in book['fills']), 'held_seconds': held,
            'buy_held_seconds': buy, 'sell_held_seconds': sell, 'both_held_seconds': both,
            'quantity_seconds': quantity_seconds, 'position_seconds_sum': position_seconds}


def summarize_book(book: dict, checked: dict) -> dict:
    """機能: 全0取引を残して場別実現正負と保存DD材料を作る。

    引数: book/checked(dict)は実台帳と独立検算。
    返り値: dictは旧金融互換列と111の実時間診断。固定枠参加率は含めない。
    """
    row = {**checked['totals'], **checked['counts']}
    row.update(positive_yen=ZERO, negative_yen=ZERO, positive_positions=0, negative_positions=0, zero_positions=0,
               unit_positive_closed_negative_yen=ZERO, whole_positive_closed_negative_yen=ZERO, activated_closed_negative_yen=ZERO)
    for position in checked['positions'].values():
        net = position['realized_net']
        row['positive_yen'] += max(ZERO, net)
        row['negative_yen'] += min(ZERO, net)
        row['positive_positions'] += net > 0
        row['negative_positions'] += net < 0
        row['zero_positions'] += net == 0
        for basis in ('unit', 'whole'):
            if net < 0 and position['marks']['first_' + basis + '_positive'] is not None:
                row[basis + '_positive_closed_negative_yen'] += net
        if net < 0 and position['protection_active']:
            row['activated_closed_negative_yen'] += net
    equal(row['positive_yen'] + row['negative_yen'], row['net_yen'], '実玉正負分解')
    equal(row['positive_positions'] + row['negative_positions'] + row['zero_positions'], row['positions'], '勝負引分の全件')
    account = book['account']
    row.update({'場内時価DD': account['max_drawdown'],
                '保存最大時価': account['max']['equity'] if account['max'] else ZERO,
                '保存最小時価': account['min']['equity'] if account['min'] else ZERO,
                '頻度診断': holding_diagnostics(book), '新保護保存検査': checked['protection_counts']})
    row['売買別'] = {str(s): {'玉': sum(p['side'] == s for p in book['positions']),
                              '枚': sum(p['initial_quantity'] for p in book['positions'] if p['side'] == s),
                              '純額': sum((p['realized_net'] for p in book['positions'] if p['side'] == s), ZERO)} for s in (1, -1)}
    row['注文別'] = {}
    for label, protection in (('Source', False), ('保護', True)):
        selected = {i: o for i, o in checked['orders'].items() if o['kind'] == 'exit' and (o['protection_point'] is not None) == protection}
        fills = [f for f in book['fills'] if f['order_id'] in selected]
        row['注文別'][label] = {'要求': len(selected), '要求枚': sum(o['quantity'] for o in selected.values()),
                               '約定': len(fills), '約定枚': sum(f['quantity'] for f in fills),
                               '返済片純額': sum((a['net_yen'] for f in fills for a in f['allocations']), ZERO)}
    equal(sum((g['返済片純額'] for g in row['注文別'].values()), ZERO), row['net_yen'], 'Source/保護全返済分解')
    return {**row, **profit_statistics(row)}


def combine(rows: list[dict]) -> dict:
    """機能: 連続場の金融統計と保存点DDを時系列連結する。

    引数: rows(list[dict])は同一設定の場別列。
    返り値: dictは合算実現収支。DDは少数保存点の連結に限定する。
    """
    sums = Counter()
    derived = {'PF', 'win_rate', 'average_profit_yen', 'average_loss_yen', 'average_profit_loss_ratio', '場内時価DD', '保存最大時価', '保存最小時価'}
    for row in rows:
        for name, amount in row.items():
            if type(amount) in (int, float, Decimal) and name not in derived:
                sums[name] += amount
    output = dict(sums)
    carry = peak = dd = ZERO
    for row in sorted(rows, key=lambda r: r['session']):
        dd = max(dd, row['場内時価DD'], peak - carry - row['保存最小時価'])
        peak = max(peak, carry + row['保存最大時価'])
        carry += row['net_yen']
    output.update({'場数': len(rows), '取引あり場': sum(r['positions'] > 0 for r in rows),
                   '赤字場': sum(r['net_yen'] < 0 for r in rows), '保存点連結時価DD': dd})
    for label in ('売買別', '注文別'):
        groups = defaultdict(Counter)
        for row in rows:
            for key, group in row[label].items():
                groups[key].update(group)
        output[label] = {k: dict(v) for k, v in groups.items()}
    output['頻度診断'] = dict(sum((Counter(r['頻度診断']) for r in rows), Counter()))
    return {**output, **profit_statistics(output)}


def save_viewer(value: dict, output: Path, market_path: str) -> list[dict]:
    """機能: 全24の実約定だけをViewer schema1へ新規保存する。

    引数: value(dict)、output(Path)、market_path(str)は検算済みCore・新規先・閲覧価格参照。
    返り値: list[dict]は0約定を含む24資源。価格本文を開かない。
    """
    resources = []
    sid = value['actual']['scope']['session']['id']
    for key in KEYS:
        name = f'111_{key}_{sid}.trades.jsonl'
        with (output / name).open('x', encoding='utf-8', newline='\n') as stream:
            for row in BASE.viewer_trades(value['actual']['books'][key]):
                stream.write(json.dumps(row, ensure_ascii=False, default=BASE.serial, allow_nan=False) + '\n')
        resources.append({'id': f'111_{key}_{sid}', 'title': f'元の連続判断と必須追尾 {key} {sid}',
                          'symbol': 'NK225', 'product': 'NK225mini', 'session': sid, 'method_id': key,
                          'point_value': 100, 'pnl_format': 'trades', 'pnl_basis': 'net', 'pnl_path': name, 'market_path': market_path})
    return resources


def verify_viewer(value: dict, output: Path, resources: list[dict]) -> dict:
    """機能: 書き出した約定行を別会計で読み直して全24の純額とflatを確認する。

    引数: value(dict)、output(Path)、resources(list[dict])はNative・保存先・当場資源。
    返り値: dictは再読行数と全残0。HTTPやチャート描画の確認とは別。
    """
    equal(len(resources), 24, '保存再読24資源')
    count = 0
    for resource in resources:
        book = value['actual']['books'][resource['method_id']]
        held, seen = {}, set()
        gross = costs = ZERO
        path = output / resource['pnl_path']
        with path.open(encoding='utf-8') as stream:
            rows = [json.loads(line, parse_float=Decimal) for line in stream if line.strip()]
        equal(len(rows), len(book['fills']), '保存約定行の全件数')
        for row, original in zip(rows, book['fills']):
            need(row['id'] not in seen, '保存約定ID一意')
            seen.add(row['id'])
            equal(row['id'], original['id'], '保存約定ID')
            equal(row['qty'], original['quantity'], '保存約定量')
            equal(row['price'], original['price'], '保存約定価格')
            equal(row['position_id'], original['position_id'], '保存所有ID')
            equal(row['fee_yen'], original['fee_yen'] + original['slip_yen'], '保存片道費用')
            equal(row['method_id'], book['key'], '保存手法')
            equal(row['source_line'], original['quote']['source_line'], '保存物理行')
            stamp = datetime.fromisoformat(row['timestamp'])
            need(stamp.utcoffset() == timedelta(hours=9), '保存時刻のJST明示')
            equal(stamp.timestamp(), float(original['quote']['time']), '保存約定時刻')
            costs += A.money(row['fee_yen'], 'Viewer費用')
            side = 1 if row['type'].startswith('Long') else -1
            pid = row['position_id']
            if row['type'] in ('LongN', 'ShortN'):
                need(pid not in held, 'Viewer新規所有一意')
                held[pid] = {'side': side, 'price': row['price'], 'qty': row['qty']}
            else:
                need(row['type'] in ('LongR', 'ShortR') and pid in held, 'Viewer返済所有')
                state = held[pid]
                equal(side, state['side'], 'Viewer返済方向')
                need(0 < row['qty'] <= state['qty'], 'Viewer返済量')
                gross += state['side'] * (row['price'] - state['price']) * 100 * row['qty']
                state['qty'] -= row['qty']
        need(all(p['qty'] == 0 for p in held.values()), 'Viewer全残0')
        equal(gross - costs, book['totals']['net_yen'], 'Viewer別会計とNative純額')
        count += len(rows)
    return {'資源': 24, '約定行': count, '全残0': True}


def run(fixed_path: Path, fixed_sha: str, output: Path) -> dict:
    """機能: Root固定の成功参照を認証後、Nativeだけを再読して正式保存する。

    引数: fixed_path(Path)、fixed_sha(str)、output(Path)はRoot要求・期待SHA・未作成先。
    返り値: dictは保存結果。既存先を変更せず失敗を完成扱いしない。
    """
    import 入力ゲート as G
    tasks, before, proofs = G.prepare(fixed_path, fixed_sha, output)
    output.mkdir(parents=True, exist_ok=False)
    rows, resources, controls, refs, viewer_checks = [], [], [], [], []
    for task in tasks:
        value = load(task['resolved_native'])
        inspected = inspect_scene(value)
        sid = value['actual']['scope']['session']['id']
        equal(sid, task['session'], 'Nativeと完了記録の場')
        for key in KEYS:
            rows.append({'session': sid, 'key': key, 'history_class': task['history_class'],
                         **summarize_book(value['actual']['books'][key], inspected['checked'][key])})
        controls.append({'session': sid, **inspected['source']})
        refs.append({'session': sid, 'path': str(task['resolved_native']), 'sha256': task['native']['sha256']})
        scene_resources = save_viewer(value, output, task['market_path'])
        viewer_checks.append({'session': sid, **verify_viewer(value, output, scene_resources)})
        resources.extend(scene_resources)
    stage = proofs['stage']
    summary = {key: combine([r for r in rows if r['key'] == key]) for key in KEYS}
    after = {p: digest(Path(p)) for p in before}
    equal(after, before, '全入力codeの前後不変')
    result = {'試行': 111, '成功': True, **proofs, '場数': len(tasks), '会計数': len(rows),
              '主key': list(KEYS), 'Actor設定': {k: {'candidate': c['policy'], 'entry_timing': '元Source連続時計', **c} for k, c in BY_KEY.items()},
              '集計': summary, '場別': rows, '元Source対照': controls, 'Native参照': refs,
              'Viewer形式資源': len(resources), 'Viewer保存再読': viewer_checks, '前後不変': True, '入力codeSHA256前': before, '入力codeSHA256後': after,
              '勝率定義': '費用後正益の完結実玉数/完結実玉数。引分を分母に含める。平均損失は負値。PFは正益総額/損失総額の絶対値。分母0はnull。',
              '頻度定義': '原行件数と実約定間の保有実時間・数量秒。新規5分/15分枠や最低参加率判定を作らない。',
              '独立検査範囲': 'Native全注文/約定/所有/費用/u/W保存点/保存点DD/源通知全24同体/S0四冊同体/D0源初回fill結合。',
              '限界': ['Raw別走査なし。最初の適格正常原行そのものの独立証明ではない。Index後/遅延/正常BBO/物理行後を照合し、源oracle/全Event対照とGo約定人工へ別途接続する。',
                       '初回正益と極値の全原行取り落とし、全3分指標の独立再形成は行わない。', 'ラージBBOによるmini模型。実mini板の流動性と注文応答は未実証。'],
              '未実施': {'Raw本文再読': 0, '価格CSV本文再読': 0, 'Source再生': 0, 'HTTP': 0, 'CSV生成': 0, '資本金ROI': None},
              '研究目標達成': False, '採用': False}
    BASE.write_json(output / '結果.json', result)
    BASE.write_json(output / '一覧.resources.json', {'schema_version': 1, 'path_base': 'catalog', 'resources': resources})
    files = {p.name: digest(p) for p in sorted(output.iterdir()) if p.is_file()}
    proof = {'試行': 111, '成功': True, **proofs, '場数': len(tasks), '会計数': len(rows), '資源': len(resources),
             'S0全金融比較': len(tasks) * 4, '全残玉予約0': True, '不一致数': 0, '前後不変': True,
             '入力codeSHA256前': before, '入力codeSHA256後': after, '出力SHA256': files, '研究目標達成': False, '採用': False}
    BASE.write_json(output / '保存会計の確認.json', proof)
    return {'成功': True, 'stage': stage, '場数': len(tasks), '会計数': len(rows), '資源': len(resources)}


def main() -> None:
    """機能: 固定要求のSHAと新規先を必須として保存を呼ぶ。

    引数: CLIのfixed/sha256/output(str)は認証済み要求と新規先。
    返り値: None。成功件数だけを標準出力へ表示する。
    """
    parser = argparse.ArgumentParser(description='111 Native台帳の独立保存')
    parser.add_argument('--fixed', required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    print(json.dumps(run(Path(args.fixed).resolve(), args.sha256, Path(args.output).resolve()), ensure_ascii=False))


if __name__ == '__main__':
    main()
