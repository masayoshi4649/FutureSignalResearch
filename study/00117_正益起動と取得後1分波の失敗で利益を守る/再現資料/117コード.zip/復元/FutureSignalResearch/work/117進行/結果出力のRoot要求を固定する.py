"""117の独立成功を固定し、CSVと設定表へ同じ結果を渡す。"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]


def reference(path: Path) -> dict:
    """
    機能: 明示JSONの絶対参照と指紋を作る。
    引数: path(Path)。返り値: dictはpath/sha256。
    """
    return {'path': str(path.resolve()), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 独立成功1400会計のCSV・表結合を新規Root要求へ固定する。
    引数: なし。返り値: None。Native・価格本文は読まない。
    """
    saved = ROOT / 'work/117進行/出力用metadata_期間区分'
    result = reference(saved / '結果.json')
    check = reference(saved / '保存会計の確認.json')
    proof = json.loads((saved / '結合の確認.json').read_text(encoding='utf-8'))
    assert proof['成功'] and proof['全既存結果項目同体'] and proof['原ファイル前後不変']
    assert result == proof['結果'] and check == proof['検算の出力用結合']
    for name, expected in (('117損益CSVの出力', 'fa261aa01a5db403472056d6147b01c13949c20027dd0d80bd2950a55337fbf6'), ('117設定表の結果結合', '6b4ff762f5e519670b826390277d56b8763a1740ebc15ef6479fcdc6fe83d695')):
        own = ROOT / 'work' / name
        value = json.loads((own / '要求テンプレ_未固定.json').read_text(encoding='utf-8'))
        stop = reference(own / '停止.json')
        assert stop['sha256'] == expected
        value.update(fixed=True, result_read_authorized=True, code_stop=stop, result=result, check=check)
        value['completion'] = reference(ROOT / 'work/117金融F1/全70場/完了.json')
        value['Root許可'] = '全70場の独立保存済み実現損益を二CSV又は固定表の結果欄へ出力する。新金融・価格・Nativeの読取はしない。'
        if name == '117設定表の結果結合':
            continue
        target = ROOT / 'work/117進行' / f'{name}_Root要求_出力metadata期間区分.json'
        with target.open('x', encoding='utf-8', newline='\n') as stream:
            stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
        print(json.dumps({**reference(target), 'output': value['output_dir']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
