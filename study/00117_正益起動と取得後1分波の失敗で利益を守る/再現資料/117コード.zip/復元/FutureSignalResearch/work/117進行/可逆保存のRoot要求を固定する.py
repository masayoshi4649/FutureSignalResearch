"""固定117Nativeの恒久保存要求をRootが別metadataへ作る。"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]


def main() -> None:
    """
    機能: レビュー済み保管器の停止を認証し、新規成果物先を固定する。
    引数: なし。返り値: None。Native本文は読まない。
    """
    own = ROOT / 'work/117Nativeを可逆圧縮して保管する'
    stop = own / '停止.json'
    sha = hashlib.sha256(stop.read_bytes()).hexdigest()
    assert sha == 'b2e7a0e9cce67364b6fd4fdf92d4c9c6550836a5ffb6115b6eba33a577aeff3a'
    value = json.loads((own / '要求テンプレ_未許可.json').read_text(encoding='utf-8'))
    value.update(fixed=True, native_read_authorized=True)
    value['code_stop'] = {'path': str(stop), 'sha256': sha}
    value['output_dir'] = str(own / '全70場_Root保存')
    value['Root許可'] = '117完了が列挙した70gzipを可逆保存する。原本は保持し、金融意味解析・新戦略は行わない。'
    target = ROOT / 'work/117進行/Native可逆保存のRoot要求_作業先.json'
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'path': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'output': value['output_dir']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
