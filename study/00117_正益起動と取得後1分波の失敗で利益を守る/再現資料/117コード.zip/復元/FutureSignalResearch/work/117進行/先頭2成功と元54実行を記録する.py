"""117の現在状態を実際の金融完了と分けて記録する。"""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


def main() -> None:
    """機能: 先頭2金融成功と実行中の元54を文書へ反映する。

    引数: なし。
    返り値: None。金融条件/固定原文/結果の数値は変更しない。
    """
    root=Path(__file__).resolve().parents[2]
    completed=root/'work/117金融F1/先頭2場/完了.json'
    if hashlib.sha256(completed.read_bytes()).hexdigest()!='e95b691c33da0e6ab0cf3e7e732849dabacd8d2dbb739eefd00a3f932109501f':raise ValueError('先頭2完了')
    d=json.loads(completed.read_text(encoding='utf-8'))
    if not (d['success'] and d['unchanged'] and d['all_reference112_equal'] and d['all_source111_equal']) or (d['books'],d['reference112_comparisons'])!=(40,24):raise ValueError('先頭2の範囲')
    path=root/'work/117進行/現在.json';state=json.loads(path.read_text(encoding='utf-8'))
    state['最終更新UTC']=datetime.now(timezone.utc).isoformat()
    state['現在'].update({'状態':'F1固定・先頭2金融40冊成功。元54金融実行中、自然独立保存準備中。','コード停止':True,'金融固定':True,'市場実行':True,
        '先頭2金融':{'path':str(completed),'sha256':'e95b691c33da0e6ab0cf3e7e732849dabacd8d2dbb739eefd00a3f932109501f'},
        '金融F1':{'path':str(root/'work/117進行/F1_117金融条件.json'),'sha256':'522fe2343b914243fadc4f48d32128a79ecdafcabd84d5a58b5ca399af90d1b0'},
        '実行中':[{'stage':'base54','session_id':68620}], '自然会計の独立検算':False,'全70成功':False,'研究目標達成':False,'採用':False})
    path.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    folder=root/'study/00117_正益起動と取得後1分波の失敗で利益を守る'
    p=folder/'README.md';text=p.read_text(encoding='utf-8');blocks=text.split('\n\n')
    blocks[1]='2026-11-10。コードと金融F1を停止・固定し、先頭2場の40口座・旧112対照24・Source全文同体・全残玉予約0が成功。元54場の金融を実行中。自然会計の独立検算・全70・CSV・Viewerは未完了。研究目標未達、採用なし。金融前の選択原文は金融前原文へ保持する。'
    text='\n\n'.join(blocks)
    text+='\n一次資料の再確認は[支持喪失と短期急変の市場構造](../../docs/議論/外部再調査/支持喪失と短期急変の市場構造.md)。注文集積の説明仮説とNK225で未識別の主体/ストップ配置を分け、1分/TR閾値を文献の実証値としない。\n'
    p.write_text(text,encoding='utf-8',newline='\n')
    p=folder/'設定と結果.md';text=p.read_text(encoding='utf-8');text+='\n段階追記：金融F1を固定し、先頭2場40会計と旧24対照の金融に成功。元54・全70・自然独立保存は未完了のため、R20表の全70結果は未実行のまま。人工の意味/会計検算と自然損益を混同しない。\n';p.write_text(text,encoding='utf-8',newline='\n')
    p=root/'docs/議論/外部再調査/README.md';text=p.read_text(encoding='utf-8');paragraph='[支持喪失と短期急変の市場構造](支持喪失と短期急変の市場構造.md)：NY連銀の既読2原文を再読し、注文集積による反発/通過の説明、因果未証明と事後分類を整理。117の1分/TR条件は独自仮説として区別する。'
    blocks=text.split('\n\n');blocks.insert(1,paragraph);p.write_text('\n\n'.join(blocks),encoding='utf-8',newline='\n')
    print(json.dumps({'成功':True,'先頭2金融':40,'旧対照':24,'元54実行中':68620,'全70結果':False},ensure_ascii=False))


if __name__=='__main__':main()
