"""人工・独立算術・レビュー後の117素材を新しい金融F1へ固定する。"""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path


def main() -> None:
    """機能: 実装で宣言した20条件を変えず、fixedだけを真にした新F1を作る。

    引数: なし。
    返り値: None。市場・Native・CSV・11月09本文を読まない。
    """
    root=Path(__file__).resolve().parents[2]
    source=root/'work/117正益と短期波の連続比較/Root停止_新三部品/条件の素材.json'
    raw=source.read_bytes()
    if hashlib.sha256(raw).hexdigest()!='2a4b59a706bdf1c69560704ca35c3865a5e9dbe1ff2f570aa5057c2386941dab':raise ValueError('Root停止の条件素材')
    value=json.loads(raw)
    if value['trial']!=117 or value['fixed'] is not False or len(value['actual_configurations'])!=20 or len(value['dependency_stops'])!=7:raise ValueError('117の実宣言')
    if value['entry_grid_seconds'] is not None or value['extra_opening_quiet_seconds']!=0:raise ValueError('元連続時計')
    stop=Path(value['runtime_stop']['path'])
    if hashlib.sha256(stop.read_bytes()).hexdigest()!='b35b9185dd2285df392492208c8566abf7c4127bd74738d220b4aa3f27f53f73':raise ValueError('Core正式停止')
    value['fixed']=True
    out=root/'work/117進行/F1_117金融条件.json'
    with out.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
    sha=hashlib.sha256(out.read_bytes()).hexdigest()
    archive=root/'study/00117_正益起動と取得後1分波の失敗で利益を守る/金融前原文'
    archive.mkdir(exist_ok=False)
    refs={}
    for name in ('README.md','選択した条件.md','設定と結果.md'):
        original=archive.parent/name;target=archive/name;body=original.read_bytes()
        with target.open('xb') as stream:stream.write(body)
        refs[name]={'path':str(target),'sha256':hashlib.sha256(body).hexdigest()}
    record={'試行':117,'成功':True,'金融F1':{'path':str(out),'sha256':sha},'固定時UTC':datetime.now(timezone.utc).isoformat(),
            '条件の改変':'元Root停止素材のfixedだけをtrue。新しい閾値/Entry/数量変更なし。','金融前文書':refs,
            '主な確認':'Pure126評価/拒否36、短期bank27,554とState56,228項目、Actor旧12全JSON/実bank足途中波、Core20+旧12/並列人工を確認。',
            '11月09読取':False,'金融市場実行':False,'採用':False,'研究目標達成':False}
    with (archive/'固定の記録.json').open('x',encoding='utf-8',newline='\n') as stream:json.dump(record,stream,ensure_ascii=False,indent=2);stream.write('\n')
    p=root/'work/117進行/現在.json';state=json.loads(p.read_text(encoding='utf-8'))
    state['現在'].update({'状態':'コード停止・金融F1固定。自然metadata確認前','金融固定':True,'コード停止':True,'金融F1':record['金融F1'],'市場実行':False,'独立検算':'人工算術のみ成功。自然会計は未実行','実行中':[]})
    p.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'F1':record['金融F1'],'市場実行':False},ensure_ascii=False))


if __name__=='__main__':main()
