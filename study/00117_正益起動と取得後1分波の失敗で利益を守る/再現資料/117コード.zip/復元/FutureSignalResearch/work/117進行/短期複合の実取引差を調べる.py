"""同じ取得のH0E/H0Mについて実際の返済差だけを残す。"""

import gzip
import hashlib
import json
from pathlib import Path


def main() -> None:
    """機能: 全70成功Nativeの同入口対照から、実現損益が変わった取引を抽出する。

    引数: なし。
    返り値: None。退出後の仮想利益・原板再生・新閾値選択を行わない。
    """
    root=Path(__file__).resolve().parents[2];completion=root/'work/117金融F1/全70場/完了.json'
    assert hashlib.sha256(completion.read_bytes()).hexdigest()=='f9d5dfc49bef7f9b2dcf6bba55fe264b689dc2e8312e0e26c4530e4b1d2872e0'
    data=json.loads(completion.read_text(encoding='utf-8'));changed=[];effects={};opportunities=set()
    for scene in data['results']:
        ref=scene['native'];path=Path(ref['path']);body=path.read_bytes();assert hashlib.sha256(body).hexdigest()==ref['sha256']
        books=json.loads(gzip.decompress(body))['actual']['books']
        for suffix in ('C0_D0','C0_D1','C5_D0','C5_D1'):
            ordinary,technical=books['H0E_'+suffix],books['H0M_'+suffix]
            def key(p:dict)->tuple:
                """機能: 同政策間で実取得を同定する。引数: p(dict)。返り値: tupleはSourceと実取得です。"""
                return (p['source']['method'],p['source']['signal_id'],p['side'],p['initial_quantity'],p['entry_price'],p['entry_quote']['index'],p['entry_quote']['source_line'])
            a={key(p):p for p in ordinary['positions']};b={key(p):p for p in technical['positions']}
            if a.keys()!=b.keys():raise ValueError('同入口集合の変化')
            for ident in a:
                left,right=a[ident],b[ident];difference=right['realized_net']-left['realized_net']
                if difference==0:continue
                warning=right['shortwave117']['first_warning'];assert warning is not None
                event=(scene['session'],left['source']['method'],left['source']['signal_id']);opportunities.add(event)
                def exits(book:dict,pid:str)->list:
                    """機能: 実返済割当を抽出。引数: book(dict)、pid(str)。返り値: listは実価格/時刻/数量です。"""
                    return [{'quote':f['quote'],'price':f['price'],'quantity':alloc['quantity'],'net_yen':alloc['net_yen'],'reason':f['reason']} for f in book['fills'] for alloc in f['allocations'] if alloc['position_id']==pid]
                changed.append({'session':scene['session'],'cost':suffix,'source':left['source'],'side':left['side'],'entry_quote':left['entry_quote'],'entry_price':left['entry_price'],'quantity':left['initial_quantity'],
                    'H0E_net':left['realized_net'],'H0M_net':right['realized_net'],'delta':difference,'warning':warning,'H0E_exits':exits(ordinary,left['id']),'H0M_exits':exits(technical,right['id'])})
                effects[suffix]=effects.get(suffix,0)+difference
        assert hashlib.sha256(path.read_bytes()).hexdigest()==ref['sha256']
    out={'試行':117,'成功':True,'速報の記述診断':True,'独立会計検算':False,'変化した延べ対照数':len(changed),'相場上の出生機会数':len(opportunities),'費用別実現差':effects,'対照':changed,
        '注意':'同じ出生を費用/遅延で重複比較。独立した成功例の数とはしない。両政策で実際に成立した取引の比較であり機会損失を算出しない。'}
    target=root/'work/117進行/短期複合の実取引差.json'
    with target.open('x',encoding='utf-8',newline='\n') as stream:json.dump(out,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps({k:v for k,v in out.items() if k!='対照'},ensure_ascii=False))


if __name__=='__main__':main()
