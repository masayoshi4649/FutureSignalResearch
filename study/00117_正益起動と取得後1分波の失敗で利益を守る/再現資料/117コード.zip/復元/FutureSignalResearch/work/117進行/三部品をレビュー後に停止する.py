"""117の人工/独立算術成功と実宣言を結び、Rootレビュー後に三部品を停止する。"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[2]
ACTOR = ROOT / 'work/117正益と短期波を執行する会計'


def reference(path: Path, expected: str | None = None) -> dict:
    """機能: 明示コード・人工・metadataの全bytesを認証する。

    引数: path(Path)、expected(str|None)は対象と既知SHA。
    返り値: dictは絶対path/SHA。価格・Nativeを渡さない。
    """
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    if expected is not None and sha != expected:
        raise ValueError('SHA不一致: ' + str(path))
    return {'path': str(path), 'sha256': sha}


def load(path: Path, sha: str | None = None) -> dict:
    """機能: 認証した小metadataを読む。

    引数: path(Path)、sha(str|None)は入力と指紋。
    返り値: dictはmetadata。
    """
    reference(path, sha)
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(path: Path, value: dict | list) -> dict:
    """機能: 日本語UTF-8 JSONを新規先だけに保存する。

    引数: path(Path)、value(dict|list)は保存先と内容。
    返り値: dictは保存Ref。上書きはしない。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    return reference(path)


def verify_map(mapping: dict) -> None:
    """機能: 宣言された人工前後コードが現物でも同体か確認する。

    引数: mapping(dict[str,str])はコード指紋。
    返り値: None。不一致なら例外。
    """
    for path, sha in mapping.items():
        reference(Path(path), sha)


def command(args: list[str]) -> dict:
    """機能: 明示した人工/実宣言だけを取得する。

    引数: args(list[str])はGoの非金融コマンド。
    返り値: dictは成功ログ。
    """
    env = dict(os.environ)
    env.pop('MINIPROTECT_EXPORT_DIR', None)
    result = subprocess.run(args, cwd=ACTOR, env=env, capture_output=True, encoding='utf-8')
    if result.returncode != 0:
        raise ValueError('人工/宣言失敗: ' + repr(args) + '\n' + result.stdout + result.stderr)
    return {'command': args, 'exit_code': 0, 'stdout': result.stdout, 'stderr': result.stderr}


def main() -> None:
    """機能: Root読取レビュー済み三部品を、人工成功・実宣言・独立算術へ固定する。

    引数: CLI output(Path)、reviewed(bool)は新規保存先とRootレビュー。
    返り値: None。金融条件や市場本文には到達しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--reviewed', action='store_true')
    args = parser.parse_args()
    out = args.output.resolve()
    if not args.reviewed or out.exists() or not out.is_relative_to(ROOT / 'work'):
        raise ValueError('レビュー後の新規work先が必要')
    pure_path = ROOT / 'work/117正益起動と費用回収床の純保護/接続前検査_全12主/接続前の確認.json'
    bank_path = ROOT / 'work/117原行と暫定1分の複合保護/検査/停止前の確認.json'
    pure = load(pure_path, '53db96d89489c06068804f0a4babc9d918449744a43fe57353dd7bf0212d3233')
    bank = load(bank_path, 'ff94d9c0775e9e6253af5fc0cd28f0cdff31f87f87a7eee08de74b89abbc21e5')
    independent = {
        'pure': reference(ROOT / 'work/117正益床の人工を独立検算する/検査/確認.json', 'e23fe3a50a89e69b1198430c454229c0faf3c591ceb1c9d471147bc1f8854616'),
        'short': reference(ROOT / 'work/117短期足と警戒を人工で独立検算する/bankと状態確認_最終/確認.json', '2134caf83c7e47bbcf06be2211f1481c3f1111f977be7ff1d668b3634e1189ac')}
    if not pure['成功'] or pure['停止'] or not bank['成功'] or bank['停止']:
        raise ValueError('成功した未停止の部品人工')
    verify_map(pure['全固定コードSHA256'])
    verify_map(bank['所有コードSHA256'])
    owned = {str(p): reference(p)['sha256'] for p in sorted(ACTOR.rglob('*')) if p.is_file() and p.suffix in ('.go', '.mod', '.sum', '.md', '.py')}
    logs = [command(['go', 'test', '-json', '-count=1', './...']), command(['go', 'vet', './...']), command(['go', 'build', './...']), command(['go', 'version'])]
    events = [json.loads(line) for line in logs[0]['stdout'].splitlines() if line.strip()]
    passed = {r['Test'] for r in events if r.get('Action') == 'pass' and 'Test' in r}
    required = {'TestTwentyPoliciesAndColdProfitFloor117', 'TestMissingShortBankAndFutureDelivery117', 'TestIntraminuteCompositeExit117'}
    if not required.issubset(passed):
        raise ValueError('117必須Actor人工が未成功')
    verify_map(owned)
    out.mkdir(parents=True, exist_ok=False)
    declaration = {}
    for kind in ('actor', 'pure', 'short'):
        result = command(['go', 'run', './cmd/declaration', kind])
        value = json.loads(result['stdout'])
        declaration[kind] = save(out / (kind + '_実宣言.json'), value)
    if len(load(Path(declaration['pure']['path']))['configurations']) != 20:
        raise ValueError('純20宣言')
    common = {'試行': 117, 'trial': 117, '成功': True, '停止': True, 'Rootレビュー後': True, 'UTC': datetime.now(timezone.utc).isoformat(),
              '市場前': True, '市場/Raw/Native/価格CSV/損益CSV/11月09本文読取': 0, '金融実行': False,
              'Root停止コード': reference(Path(__file__).resolve()), '採用': False, '研究目標達成': False}
    refs = {}
    for key, proof, proof_path in (('pure', pure, pure_path), ('short', bank, bank_path)):
        info = dict(common, 部品=key, 人工=reference(proof_path), 所有コードSHA256=proof['所有コードSHA256'], 独立人工検算=independent[key], 実宣言=declaration[key], 前後不変=True)
        if key == 'pure':
            info['全固定コードSHA256'] = pure['全固定コードSHA256']
        refs[key] = save(out / (key + '_停止.json'), info)
    info = dict(common, 部品='actor', 所有コードSHA256=owned, 前後不変=True, 実Actor宣言=declaration['actor'], 主人工成功=sorted(x for x in passed if '/' not in x), 検査ログ=logs,
                基礎派生=reference(ACTOR / '派生元.json'), 新部品停止=refs,
                レビュー='Rootと別担当が113との差分、二段Advanceの初回flag/実所有/予約/位相/当原行一致を確認。Opaque票はActorで実Position・三役・幅・原行・JSON Witnessへ再結合。')
    refs['actor'] = save(out / 'actor_停止.json', info)
    verify_map(owned)
    verify_map(pure['全固定コードSHA256'])
    verify_map(bank['所有コードSHA256'])
    save(out / '三部品の停止.json', dict(common, refs=refs, declarations=declaration, コード前後不変=True))
    print(json.dumps({'成功': True, '停止': True, 'refs': refs, 'declarations': declaration}, ensure_ascii=False))


if __name__ == '__main__':
    main()
