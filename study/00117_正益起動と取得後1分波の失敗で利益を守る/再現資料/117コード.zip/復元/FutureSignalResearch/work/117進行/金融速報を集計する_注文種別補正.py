"""117の保存済み金融Nativeから成立取引の速報だけを集計する。"""

import argparse
from decimal import Decimal
import gzip
import hashlib
import json
from pathlib import Path


def main() -> None:
    """機能: 成功完了の列挙Nativeを認証し、全政策の利益損失と保護件数を集計する。

    引数: CLI completion(Path)、sha(str)、output(Path)は成功完了と速報の新規先。
    返り値: None。金融再実行・原板読取・退出後仮利益の算出はしない。
    """
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--completion',type=Path,required=True);parser.add_argument('--sha',required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();data=args.completion.read_bytes()
    if hashlib.sha256(data).hexdigest()!=args.sha:raise ValueError('完了SHA')
    complete=json.loads(data)
    if complete['trial']!=117 or not complete['success'] or not complete['unchanged'] or not complete['all_reference112_equal'] or not complete['all_source111_equal']:raise ValueError('金融成功の範囲')
    totals={};refs=[]
    for scene in complete['results']:
        ref=scene['native'];path=Path(ref['path']);body=path.read_bytes()
        if hashlib.sha256(body).hexdigest()!=ref['sha256']:raise ValueError('Native SHA')
        native=json.loads(gzip.decompress(body),parse_float=Decimal)
        refs.append(ref)
        for key,book in native['actual']['books'].items():
            summary=totals.setdefault(key,{'利益総額':Decimal(0),'損失総額':Decimal(0),'純額':Decimal(0),'勝ち':0,'負け':0,'建玉数':0,'初期枚数':0,'正益後赤字':0,'起動':0,'短期arm':0,'短期警戒':0,'実幅適用':0,'返済要求':0})
            summary['純額']+=Decimal(book['totals']['net_yen'])
            for p in book['positions']:
                if p['quantity'] or p['reserved']:raise ValueError('残予約あり')
                net=Decimal(p['realized_net']);summary['建玉数']+=1;summary['初期枚数']+=p['initial_quantity']
                if net>0:summary['利益総額']+=net;summary['勝ち']+=1
                elif net<0:summary['損失総額']+=net;summary['負け']+=1
                if p['marks']['first_whole_positive'] is not None and net<0:summary['正益後赤字']+=1
                if p.get('protection117'):
                    a=p['protection117'];summary['起動']+=a['first_activation'] is not None
                    summary['実幅適用']+=a['first_narrowing'] is not None
                if p.get('shortwave117'):
                    s=p['shortwave117'];summary['短期arm']+=s.get('first_arm') is not None;summary['短期警戒']+=s.get('first_warning') is not None
            summary['返済要求']+=sum(o['kind']=='exit' and o['reason'].startswith('117一定利益') for o in book['orders'])
        if hashlib.sha256(path.read_bytes()).hexdigest()!=ref['sha256']:raise ValueError('Native前後差')
    for key,v in totals.items():
        if v['利益総額']+v['損失総額']!=v['純額']:raise ValueError('速報の金融総額差')
        v['PF']=None if v['損失総額']==0 else float(v['利益総額']/abs(v['損失総額']))
        for field,value in list(v.items()):
            if isinstance(value,Decimal):v[field]=int(value) if value==value.to_integral() else float(value)
    out={'試行':117,'成功':True,'速報':True,'独立会計検算':False,'stage':complete['stage'],'完了':{'path':str(args.completion.resolve()),'sha256':args.sha},'Native':refs,'集計':totals,
         '注意':'Go金融の保存値からの集計であり、自然会計/全Raw最初性の独立検算と区別する。既使用標本。','採用':False,'研究目標達成':False}
    with args.output.open('x',encoding='utf-8',newline='\n') as stream:json.dump(out,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps({'成功':True,'場数':complete['sessions'],'結果':{k:v for k,v in totals.items() if k.endswith('D0')}},ensure_ascii=False))


if __name__=='__main__':main()
