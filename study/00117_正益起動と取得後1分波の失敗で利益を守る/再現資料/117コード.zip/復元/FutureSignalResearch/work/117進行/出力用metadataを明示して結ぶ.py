"""117の元結果数値を保持し、出力器が要する採否・由来metadataだけを付ける。"""
from copy import deepcopy
from decimal import Decimal
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]


def reference(path: Path) -> dict:
    """
    機能: 明示JSONの絶対参照と全bytes指紋を作る。
    引数: path(Path)。返り値: dictはpath/sha256。
    """
    return {'path': str(path.resolve()), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def write_new(path: Path, value: dict) -> None:
    """
    機能: 元ファイルを上書きせず派生metadataを新規保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main() -> None:
    """
    機能: 成功検算との結合を維持し、原結果の全既存項目不変を検査する。
    引数: なし。返り値: None。新会計・Native・価格読取は行わない。
    """
    saved = ROOT / 'work/117独立保存F1/全70場'
    original_result = reference(saved / '結果.json')
    original_check = reference(saved / '保存会計の確認.json')
    assert original_result['sha256'] == '84452fae9393e4c01dfda3b4816f9c26faf9129ce030aea20db77eeacbbf2ba2'
    assert original_check['sha256'] == 'f96d6a8a4cc7681a7c4e2addfc4cdd065ff88e4664428f489a2bd6847b0a2ecf'
    result = json.loads(Path(original_result['path']).read_text(encoding='utf-8'))
    check = json.loads(Path(original_check['path']).read_text(encoding='utf-8'))
    assert check['成功'] and check['前後不変'] and check['不一致数'] == 0
    assert check['出力SHA256']['結果.json'] == original_result['sha256']
    metadata = {'採用': False, '研究目標達成': False, '前後不変': check['前後不変'], '独立再用場数': 0, 'Root保存要求SHA256': check['保存要求SHA256']}
    assert not set(metadata).intersection(result)
    base54 = ROOT / 'work/117金融F1/元54場/完了.json'
    assert reference(base54)['sha256'] == 'b3e5865e882faec7c45c70eeb75045df3132a37657ddf6d1f05342479a533876'
    original_sessions = {r['session'] for r in json.loads(base54.read_text(encoding='utf-8'))['results']}
    assert len(original_sessions) == 54
    output = ROOT / 'work/117進行/出力用metadata_期間区分'
    output.mkdir(exist_ok=False)
    new_result = deepcopy(result)
    new_result.update(metadata)
    assert {k: v for k, v in new_result.items() if k not in metadata} == result
    for row in new_result['場別']:
        assert 'history_class' not in row
        row['history_class'] = 'original54' if row['session'] in original_sessions else 'additional16'
    provenance = {'原結果': original_result, '原保存検算': original_check, '既存項目の全値不変': True, '追加metadata': metadata, '期間区分の根拠': reference(base54), '追加場別metadata': 'history_class。固定元54金融完了のsession集合との所属だけで付与。', '意味': '採用はRoot判断の未採用。前後不変は原検算の入力不変を転記。Root保存要求は原保存要求の明示別名。自然会計の再実行ではない。'}
    new_result['出力用metadataの由来'] = provenance
    write_new(output / '結果.json', new_result)
    exact_original = json.loads(Path(original_result['path']).read_text(encoding='utf-8'), parse_float=Decimal)
    exact_output = json.loads((output / '結果.json').read_text(encoding='utf-8'), parse_float=Decimal)
    for row in exact_output['場別']:
        row.pop('history_class')
    assert {k: v for k, v in exact_output.items() if k not in metadata and k != '出力用metadataの由来'} == exact_original
    new_ref = reference(output / '結果.json')
    new_check = deepcopy(check)
    new_check['Root保存要求SHA256'] = check['保存要求SHA256']
    new_check['出力SHA256']['結果.json'] = new_ref['sha256']
    new_check['出力用metadataの由来'] = provenance
    new_check['派生結果を除く検算項目不変'] = True
    write_new(output / '保存会計の確認.json', new_check)
    proof = {'成功': True, '原結果': original_result, '原保存検算': original_check, '結果': new_ref, '検算の出力用結合': reference(output / '保存会計の確認.json'), '金融再実行': False, '全既存結果項目同体': True, '原ファイル前後不変': original_result == reference(saved / '結果.json') and original_check == reference(saved / '保存会計の確認.json')}
    assert proof['原ファイル前後不変']
    write_new(output / '結合の確認.json', proof)
    print(json.dumps(proof, ensure_ascii=False))


if __name__ == '__main__':
    main()
