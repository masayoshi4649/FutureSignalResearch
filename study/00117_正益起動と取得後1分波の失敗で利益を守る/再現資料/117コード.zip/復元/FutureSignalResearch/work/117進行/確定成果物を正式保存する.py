"""117の成功済み結果を重複の少ない正式成果物へ保存する。"""
from pathlib import Path
import hashlib
import json
import shutil

ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / 'study/00117_正益起動と取得後1分波の失敗で利益を守る'


def digest(path: Path) -> str:
    """
    機能: 明示された成果物の全bytes指紋を得る。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy_exact(source: Path, target: Path, expected: str | None = None) -> dict:
    """
    機能: 上書きせず成果物を保存し、コピー前後の全bytes同体を照合する。
    引数: source/target(Path)、expected(str|None)。返り値: dictは保存台帳。
    """
    before = digest(source)
    assert expected is None or expected == before
    target.parent.mkdir(parents=True, exist_ok=True)
    if not target.exists():
        with source.open('rb') as src, target.open('xb') as dst:
            shutil.copyfileobj(src, dst)
    assert before == digest(target) == digest(source)
    return {'元': str(source), '正式相対path': target.relative_to(STUDY).as_posix(), 'sha256': before, 'bytes': target.stat().st_size}


def main() -> None:
    """
    機能: 独立成功・可逆保存・CSV・版6表を正式に結ぶ。
    引数: なし。返り値: None。原板・CSV本文の金融再計算や新探索をしない。
    """
    saved = ROOT / 'work/117独立保存F1/全70場'
    check = saved / '保存会計の確認.json'
    assert digest(check) == 'f96d6a8a4cc7681a7c4e2addfc4cdd065ff88e4664428f489a2bd6847b0a2ecf'
    validation = json.loads(check.read_text(encoding='utf-8'))
    assert validation['成功'] and validation['不一致数'] == 0 and validation['会計数'] == 1400
    copies = []
    for name, expected in validation['出力SHA256'].items():
        if name == '結果.json' or name == '一覧.resources.json' or name.endswith('.trades.jsonl'):
            copies.append(copy_exact(saved / name, STUDY / '成果物' / name, expected))
    assert len(copies) == 1402
    copies.append(copy_exact(check, STUDY / '検査/保存会計の確認.json'))
    fixed = {
        'work/117進行/F1_117金融条件.json': '検査/F1_117金融条件.json',
        'work/117金融F1/先頭2場/完了.json': '検査/先頭2金融.json',
        'work/117金融F1/元54場/完了.json': '検査/元54金融.json',
        'work/117金融F1/全70場/完了.json': '検査/全70金融.json',
        'work/117全70保存1分公表の独立再計算/全70場_実検算/確認.json': '検査/保存1分公表の独立検算.json',
        'work/117正益床の人工を独立検算する/検査/確認.json': '検査/正益床の独立人工.json',
        'work/117短期足と警戒を人工で独立検算する/bankと状態確認_最終/確認.json': '検査/短期足と警戒の独立人工.json',
        'work/117進行/全70CSVの独立再読.json': '検査/CSVの独立再読.json',
        'work/117設定表の結果結合/全70結果版/結合の確認.json': '検査/設定表結合の確認.json',
        'work/117進行/短期複合の実取引差.json': '診断/短期複合の実取引差.json',
        'work/117進行/出力用metadata_期間区分/結合の確認.json': '検査/出力用metadataの結合.json',
        'work/117進行/117損益CSVの出力_Root要求_出力metadata期間区分.json': '検査/CSVのRoot要求.json',
        'work/117進行/full70_独立保存のRoot要求.json': '検査/独立保存のRoot要求.json',
        'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/117損益CSV/CSVの確認.json': '検査/CSV出力の確認.json',
    }
    for source, target in fixed.items():
        copies.append(copy_exact(ROOT / source, STUDY / target))
    packed = ROOT / 'work/117Nativeを可逆圧縮して保管する/全70場_Root保存'
    index = json.loads((packed / 'Native可逆圧縮索引.json').read_text(encoding='utf-8'))
    assert index['success'] and index['sessions'] == 70 and index['all_json_bytes_equal'] and index['all_original_gzip_bytes_equal']
    for row in index['Native_zstd']:
        copies.append(copy_exact(packed / row['stored_relative'], STUDY / '成果物_金融' / row['stored_relative'], row['stored_zstd']['sha256']))
    copies.append(copy_exact(packed / 'Native可逆圧縮索引.json', STUDY / '成果物_金融/Native可逆圧縮索引.json'))
    copies.append(copy_exact(ROOT / 'work/117Nativeを可逆圧縮して保管する/gzipを再現する.exe', STUDY / '再現資料/gzipを再現する.exe', index['restore']['executable']['sha256']))
    table = ROOT / 'work/117設定表の結果結合/全70結果版/設定と結果_全70結果版.md'
    assert digest(table) == '7059764ea41a1319196faa70ffb0f04fba81f368f2e802c5a132d0815cb803d2'
    old_table = STUDY / '設定と結果.md'
    assert digest(old_table) == '94094f3012376f2c0fa60c444d6a3746f01a7ec281e2340cd396d86520424995'
    copies.append(copy_exact(old_table, STUDY / '再現資料/結果結合前の設定表.md'))
    old_table.write_bytes(table.read_bytes())
    assert digest(old_table) == digest(table)
    copies.append({'元': str(table), '正式相対path': '設定と結果.md', 'sha256': digest(table), 'bytes': table.stat().st_size})
    proof = {'試行': 117, '成功': True, '金融条件固定': True, '独立会計数': 1400, 'Viewer保存再読数': 1400, 'ViewerHTTP/画面確認': False, '原板再読': False, '新金融実行': False, '全Raw初回性確認': False, 'Native元gzip合計bytes': index['total_source_gzip_bytes'], 'Native正式zstd合計bytes': index['total_stored_zstd_bytes'], '保存': copies, '設定表の金融前原文を保持': True, 'CSV二点はoutputs唯一正本': True}
    target = STUDY / '検査/正式保存の確認.json'
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'成功': True, '保存数': len(copies), '確認SHA256': digest(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
