"""Rootが既固定metadataから117の独立保存要求だけを作る。"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]


def digest(path: Path) -> str:
    """
    機能: 明示metadataの全bytes指紋を得る。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 既固定台帳と恒久保存の対応から二段階要求を新規固定する。
    引数: なし。返り値: None。価格本文・Nativeは読まない。
    """
    own = ROOT / 'work/117自然会計と保存点の独立検算'
    manifest = ROOT / 'study/00106_収束失速で保護の起動と幅を切り替える/入力台帳_70場.json'
    reloc = ROOT / 'inputs/105生成原板/保存の確認.json'
    stop = own / '停止.json'
    assert digest(manifest) == '902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8'
    assert digest(reloc) == '7b4564fc7639afe4c831c3caa84789126a92ddfbdc84aeb6399ed0754c0bcec3'
    assert digest(stop) == '4e0697d5506ba13ac25c4b6af13187b36b708718de358d9c4d7125dad9735cf1'
    metadata = json.loads(manifest.read_text(encoding='utf-8'))
    paths = {s['id']: str((Path(metadata['source_root']) / s['files']['NK225_book']['path']).resolve()) for s in metadata['sessions']}
    paths.update({s['session']: s['canonical']['path'] for s in json.loads(reloc.read_text(encoding='utf-8'))['files']})
    for stage in ('first2', 'full70'):
        value = json.loads((own / f'検査/{stage}_未許可要求.json').read_text(encoding='utf-8'))
        value.update(fixed=True, native_read_authorized=True)
        value['verifier_stop'] = {'path': str(stop), 'sha256': digest(stop)}
        value['market_paths'] = {sid: paths[sid] for sid in value['sessions']}
        value['Root許可'] = '117既固定金融の全保存点を独立検算し、Viewerへ保存する。価格本文・旧Native・11月09は読まない。'
        target = ROOT / f'work/117進行/{stage}_独立保存のRoot要求.json'
        with target.open('x', encoding='utf-8', newline='\n') as stream:
            stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
        print(json.dumps({'stage': stage, 'path': str(target), 'sha256': digest(target), 'output': value['output_dir']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
