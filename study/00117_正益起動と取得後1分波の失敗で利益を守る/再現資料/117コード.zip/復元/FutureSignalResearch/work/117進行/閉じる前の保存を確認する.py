"""117の正式保存・CSV・文書リンクを確認し、探索を停止する状態を残す。"""
from pathlib import Path
from urllib.parse import unquote
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / 'study/00117_正益起動と取得後1分波の失敗で利益を守る'


def digest(path: Path) -> str:
    """
    機能: 明示成果物の全bytes指紋を得る。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 保存済み成果物の同体と参照を確認し、未達の停止記録を作る。
    引数: なし。返り値: None。新金融・原板・価格読取は行わない。
    """
    proof = json.loads((STUDY / '検査/正式保存の確認.json').read_text(encoding='utf-8'))
    for item in proof['保存']:
        p = STUDY / item['正式相対path']
        assert digest(p) == item['sha256'] and p.stat().st_size == item['bytes']
    csv = ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/117損益CSV'
    csv_check = json.loads((STUDY / '検査/CSV出力の確認.json').read_text(encoding='utf-8'))
    for name, item in csv_check['出力'].items():
        assert digest(csv / name) == item['sha256']
    independent = json.loads((STUDY / '検査/CSVの独立再読.json').read_text(encoding='utf-8'))
    assert independent['成功'] and independent['全セル比較数'] == 53900
    catalog = json.loads((STUDY / '成果物/一覧.resources.json').read_text(encoding='utf-8'))
    assert catalog['path_base'] == 'catalog' and len(catalog['resources']) == 1400
    for r in catalog['resources']:
        assert Path(r['market_path']).is_absolute() and (STUDY / '成果物' / r['pnl_path']).exists()
    files = list(STUDY.glob('*.md')) + [csv / 'README.md', ROOT / 'README.md', ROOT / 'docs/README.md', ROOT / 'study/README.md', ROOT / 'docs/議論/README.md', ROOT / 'docs/technical-analysis/README.md', ROOT / 'docs/議論/外部再調査/README.md', ROOT / 'docs/議論/増玉と短期保護を調べて分かったこと.md', STUDY / '再現資料/再現手順.md']
    links = 0
    for p in files:
        assert p.exists(), str(p)
        for match in re.findall(r'\]\(([^)]+)\)', p.read_text(encoding='utf-8')):
            target = unquote(match.strip('<>').split('#')[0])
            if not target or re.match(r'^[a-z]+://', target, re.I):
                continue
            assert (p.parent / target).resolve().exists(), f'{p}: {target}'
            links += 1
    result = json.loads((STUDY / '成果物/結果.json').read_text(encoding='utf-8'))
    increments = {}
    for cost in ('C0_D0', 'C0_D1', 'C5_D0', 'C5_D1'):
        a, b = (result['集計'][f'{policy}_{cost}'] for policy in ('H0E', 'H0M'))
        assert a['net_yen'] < 0 and b['net_yen'] < 0 and a['negative_yen'] == b['negative_yen']
        assert b['whole_positive_closed_negative'] == a['whole_positive_closed_negative']
        increments[cost] = b['net_yen'] - a['net_yen']
    assert increments == {'C0_D0': 14000, 'C0_D1': 23000, 'C5_D0': 21000, 'C5_D1': 8000}
    value = {'試行': 117, '記録作成成功': True, '状態': '限定的な良い結論を残してユーザー指示により一旦停止', '研究目標達成': False, '採用': False, '全70金融会計数': 1400, '金融再用54/再生16': [54, 16], '全70保存点独立検算': True, 'CSV全セル比較': 53900, '確認したローカルリンク数': links, 'Viewer資源保存再読数': 1400, 'ViewerHTTP/描画': False, 'H0Mの実現改善円': increments, 'H0全体は全4条件赤字': True, '差のある元出生機会': 4, '差のある延べ費用事例': 7, '差のある取引は全て売り': True, '全Raw初回性': False, '11月09本文読取': False, '次試行開始': False, '全体の再現資料': '再現資料/再現手順.md', '保存SHA確認数': len(proof['保存']), '保留と限界': '検算範囲と既知の境界.md参照。Source実保護fill非返送、既使用期間、全Raw初回性未検証。'}
    target = STUDY / '検査/117の完了と停止.json'
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'成功': True, 'path': str(target), 'sha256': digest(target), 'リンク': links}, ensure_ascii=False))


if __name__ == '__main__':
    main()
