"""117を一旦停止するため、再現コード保存のRoot要求を固定する。"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]


def reference(path: Path) -> dict:
    """
    機能: 明示コード又は小metadataの絶対参照を作る。
    引数: path(Path)。返り値: dictはpath/sha256。
    """
    return {'path': str(path.resolve()), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 人工成功とレビュー済み保管器を結び、金融以外の保存を許可する。
    引数: なし。返り値: None。Raw・Native・価格・損益CSV本文は読まない。
    """
    own = ROOT / 'work/117再現資料の保管'
    proof = own / '人工確認/準備の確認.json'
    assert reference(proof)['sha256'] == '744b0622268844080d951b9bb112fcbe701db93f98ce939951ec0bc4c0f0b7d2'
    value = json.loads((own / '人工確認/Root要求の素材.json').read_text(encoding='utf-8'))
    value.update(fixed=True, code_read_authorized=True)
    extra = {r['path']: r for r in value['extra_code_refs']}
    paths = list((ROOT / 'work/117進行').glob('*.py')) + list((ROOT / 'work/117進行/Root三部品停止').glob('*.json'))
    paths += [ROOT / p for p in (
        'work/117進行/full70_独立保存のRoot要求.json',
        'work/117進行/全70保存1分検算のRoot要求.json',
        'work/117進行/117損益CSVの出力_Root要求_出力metadata期間区分.json',
        'work/117進行/117設定表の結果結合_Root要求_出力metadata明示.json',
        'work/117進行/Native可逆保存のRoot要求_作業先.json',
        'work/117進行/出力用metadata_期間区分/結合の確認.json',
        'work/117金融F1/元54場/完了.json',
        'work/117金融F1/全70場/完了.json',
        'work/117進行/自然CSVの操作marker.json',
    )]
    for p in paths:
        r = reference(p)
        extra[r['path']] = r
    value['extra_code_refs'] = list(extra.values())
    value['Rootレビュー'] = 'safe_source、分類、ZIP全件SHA/CRC再読、前後不変と手製人工を確認。金融や次の研究は実行しない。'
    target = ROOT / 'work/117進行/コード保管のRoot要求.json'
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(reference(target), ensure_ascii=False))


if __name__ == '__main__':
    main()
