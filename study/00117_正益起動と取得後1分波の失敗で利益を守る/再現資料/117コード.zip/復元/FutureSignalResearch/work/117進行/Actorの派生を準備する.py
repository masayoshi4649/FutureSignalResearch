"""113の実口座から117の独立編集先を作る。"""

import hashlib
import json
from pathlib import Path


def main() -> None:
    """機能: 停止済み実口座を認証し、新117の編集先だけに複写する。

    引数: なし。
    返り値: None。市場/Raw/Native/CSVは読まず、旧コードを変更しない。
    """
    root = Path(__file__).resolve().parents[2]
    source = root / 'work/113起動前の構造失効を執行する会計'
    target = root / 'work/117正益と短期波を執行する会計'
    target.mkdir(exist_ok=False)
    names = ('actual.go', 'actual_types.go', 'continuous.go', 'legacy_comparison.go', 'actual_test.go', 'go.mod', 'go.sum')
    before = {str(source / name): hashlib.sha256((source / name).read_bytes()).hexdigest() for name in names}
    stop = source / 'Actor停止.json'
    fixed = json.loads(stop.read_text(encoding='utf-8'))
    maps = [value for value in fixed.values() if isinstance(value, dict)]
    for path, sha in before.items():
        if path.endswith('.go') and not any(value.get(path) == sha for value in maps):
            raise ValueError('113停止に結ばない入力: ' + path)
    for name in names:
        body = (source / name).read_bytes()
        if name.endswith('.go'):
            text = body.decode('utf-8').replace('113', '117')
            text = text.replace('24条件', '20条件').replace('24口座', '20口座')
            body = text.encode('utf-8')
        elif name == 'go.mod':
            text = body.decode('utf-8').replace('module github.com/masayoshi4649/SessionTradeExecuter/continuousactor113', 'module github.com/masayoshi4649/SessionTradeExecuter/continuousactor117')
            text += '\nrequire (\n github.com/masayoshi4649/SessionTradeExecuter/profitfloor117 v0.0.0\n github.com/masayoshi4649/SessionTradeExecuter/shortwave117 v0.0.0\n)\n'
            text += '\nreplace github.com/masayoshi4649/SessionTradeExecuter/profitfloor117 => ../117正益起動と費用回収床の純保護\n'
            text += 'replace github.com/masayoshi4649/SessionTradeExecuter/shortwave117 => ../117原行と暫定1分の複合保護\n'
            body = text.encode('utf-8')
        with (target / name).open('xb') as stream:
            stream.write(body)
    if any(hashlib.sha256(Path(path).read_bytes()).hexdigest() != sha for path, sha in before.items()):
        raise ValueError('旧コード不変')
    result = {'試行': 117, '成功': True, '元停止': {'path': str(stop), 'sha256': hashlib.sha256(stop.read_bytes()).hexdigest()},
              '元SHA256': before, '旧前後不変': True, '自然市場読取': 0, '金融実行': False,
              '編集': '113から別folderへ派生。共通実会計と旧対照を保持し、H0/1分接続を追加する。旧P50/E100/E50用の市場候補は117で宣言しない。'}
    (target / '派生元.json').write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '編集先': str(target), '元ファイル数': len(names)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
