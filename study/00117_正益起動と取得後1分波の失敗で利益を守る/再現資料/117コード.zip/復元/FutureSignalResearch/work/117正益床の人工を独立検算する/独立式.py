"""H0E/H0Mの人工保存点を、Goを呼ばずDecimalと半円整数で独立に計算する。"""
from copy import deepcopy
from decimal import Decimal,ROUND_CEILING,getcontext

getcontext().prec=60


def need(condition:bool,label:str)->None:
    """
    機能: 独立算術の不整合を拒否する。
    引数: condition(bool)、label(str)。返り値: None。不成立はValueError。
    """
    if not condition:raise ValueError(label)


def number(value)->Decimal:
    """
    機能: boolを実数扱いせず有限Decimalへ変換する。
    引数: value(数値)。返り値: Decimal。
    """
    need(not isinstance(value,bool) and isinstance(value,(int,float,Decimal)),'数値型')
    x=Decimal(str(value));need(x.is_finite(),'有限数');return x


def half(value)->int:
    """
    機能: 円を半円整数へ厳密変換する。
    引数: value(数値)。返り値: int。端数を丸めて補正しない。
    """
    x=number(value);need(abs(x)<=Decimal('1e12') and x*2==(x*2).to_integral_value(),'半円単位');return int(x*2)


def ceil5(value)->Decimal:
    """
    機能: 負数を含め数学的に5ptへ切り上げる。
    引数: value(数値)。返り値: Decimal。
    """
    return (number(value)/5).to_integral_value(rounding=ROUND_CEILING)*5


def whole_floor(target_half:int,realized_half:int,cost:int,n:int)->int:
    """
    機能: L/Rを有理数のまま全玉目標の価格床へ変換する。
    引数: target_half/realized_half(int)、cost(int円)、n(int)。返り値: int pt。
    """
    need(n>0,'床の実残量');a=2*n*cost+target_half-realized_half;b=1000*n
    return 5*(-((-a)//b))


def equal(expected,actual,label:str='値')->None:
    """
    機能: 保存された全JSON値を型とキーも含め独立期待値へ照合する。
    引数: expected/actual(JSON値)、label(str)。返り値: None。数値許容誤差を設けない。
    """
    if isinstance(expected,bool) or isinstance(actual,bool):need(type(expected) is bool and type(actual) is bool and expected==actual,label);return
    if isinstance(expected,(int,float,Decimal)) and isinstance(actual,(int,float,Decimal)):need(number(expected)==number(actual),f'{label}:{expected}!={actual}');return
    if isinstance(expected,dict):
        need(isinstance(actual,dict) and set(expected)==set(actual),label+'キー')
        for k in expected:equal(expected[k],actual[k],label+'.'+k)
    elif isinstance(expected,list):
        need(isinstance(actual,list) and len(expected)==len(actual),label+'配列')
        for i,(a,b) in enumerate(zip(expected,actual)):equal(a,b,f'{label}[{i}]')
    else:need(type(expected) is type(actual) and expected==actual,label)


def definitions(policy:str)->tuple[dict,dict]:
    """
    機能: 新二政策の実数設定と意味の固定値を作る。
    引数: policy(str)。返り値: tuple[dict,dict]。旧政策の演算は実装しない。
    """
    need(policy in ('H0E','H0M'),'独立対象はH0だけ');m=policy=='H0M'
    d={'version':117,'policy':policy,'enabled':True,'threshold_points':0,'normal_width_minimum':200,'atr_multiplier':2,'warning_formula':'別短期複合の最初の完成警戒のみ' if m else '技術狭幅なし。旧3分は診断のみ','technical_narrowing':m,'entry_invalidation_enabled':False}
    h={'version':117,'activation':'正常返済MarkのW=R+n*(100*gain-K)>0','initial_target':'未設定からL=R-n*K、K=77+200*S円','minimum_floor_points':0,'zero_promotion':'正常Markでmax(0,FW(0,R,n))<=gain-5ならL=max(L,0)。初回可','new_peak_required':False,'technical_narrowing':m,'narrowing':'最初の完成Narrowを不変ラッチ。正常Markでmin(通常幅,完成幅)を一度適用' if m else '技術狭幅なし','legacy_three_minute_effect':False}
    return d,h


class Model:
    """外部数値入力だけを使う新H0金額モデル。旧Go実装や期待値への呼出しを持たない。"""

    def __init__(self,entry:dict):
        """
        機能: 金額・幅・Target未設定をEntryから独立に初期化する。
        引数: entry(dict)。返り値: None。
        """
        e=deepcopy(entry);d,h=definitions(e['policy']);p=number(e['price']);s=e['side'];q=e['initial_quantity'];slip=number(e['slip_points']);a=e.get('atr')
        need(s in (-1,1) and type(s) is int and type(q) is int and 1<=q<=10 and p>0 and p<=Decimal('1e9') and p%5==0 and slip in (0,5),'実取得条件')
        need(number(e['at'])>=number(e['scope']['start']),'取得時計')
        width=Decimal(200)
        if a is not None:
            need(a['id'] and 0<number(a['value'])<=Decimal('1e6') and number(e['scope']['start'])<=number(a['available_at'])<=number(e['at']),'取得ATR')
            width=ceil5(max(Decimal(200),2*number(a['value'])))
        self.cost=int(77+200*slip);self.target=None;self.last_index=-1
        self.view={'definition':d,'entry':e,'threshold_points':0,'normal_width':width,'atr_unknown_fallback':a is None,'cost_per_unit_yen':self.cost,'minimum_floor':0,'active':False,'activated_at':None,'narrowed':False,'narrowed_at':None,'peak_points':None,'width_points':width,'floor_points':None,'whole_target_yen':0,'closed_net_yen':0,'remaining':q,'reserved':0,'latest':None,'at':e['at'],'sequence':0,'finished':False,'h0_117':{'definition':h,'source_index':0,'phase':'','target_set':False,'whole_target_half_yen':None,'zero_target_adopted':False,'zero_target_at':None,'narrow':None,'narrow_applied':False,'narrow_applied_at':None}}

    def snapshot(self)->dict:
        """
        機能: 独立Stateを呼出側から参照分離する。
        引数: self(Model)。返り値: dict。
        """
        return deepcopy(self.view)

    def advance(self,i:dict)->dict:
        """
        機能: H0/Target/幅/床/返済適格を入力から独立再計算する。
        引数: i(dict)。返り値: dictはDecision。実約定や短期技法の成立は計算しない。
        """
        before=self.snapshot();old_target=self.target;old_index=self.last_index
        try:return self._advance(deepcopy(i))
        except Exception:
            self.view=before;self.target=old_target;self.last_index=old_index;raise

    def _advance(self,i:dict)->dict:
        """
        機能: 不成功時の巻戻し対象となる独立一段演算を行う。
        引数: i(dict)。返り値: dictは完全なH0 Decision。
        """
        v=self.view;e=v['entry'];h=v['h0_117'];at=number(i['at']);seq=i['sequence'];phase=i['phase'];idx=i.get('source_index',0);n=i['remaining'];reserved=i['reserved'];r=number(i['closed_net_yen']);rh=half(r);mark=i['mark']
        need(not v['finished'] and at>=number(v['at']) and type(seq) is int and seq>v['sequence'] and phase in ('pre_fill','after_source') and type(idx) is int and idx>=max(0,self.last_index),'時計/位相/Index')
        need(type(n) is int and type(reserved) is int and 0<=reserved<=n<=v['remaining'],'実数量/予約')
        need(n!=v['remaining'] or r==number(v['closed_net_yen']),'実数量なしのR変更')
        need(i.get('publication') is None and not i.get('reset_reason'),'今回人工の3分公表は未対象')
        if mark is not None:mark=number(mark);need(0<mark<=Decimal('1e9'),'正常Mark')
        v.update(at=at,sequence=seq,remaining=n,reserved=reserved,closed_net_yen=r);h.update(source_index=idx,phase=phase);self.last_index=idx
        dh={'source_index':idx,'phase':phase,'target_initialized_now':False,'initial_target_half_yen':None,'target_before_half_yen':self.target,'target_after_half_yen':None,'zero_candidate_floor':None,'zero_room':None,'zero_target_adopted_now':False,'floor_implied_half_yen':None,'narrow_latched_now':False,'narrow_applied_now':False}
        d={'c':0,'m':0,'p':0,'b':0,'warning':0,'gain_points':None,'unit_net_yen':None,'whole_net_yen':None,'activated_now':False,'narrowed_now':False,'width_source':'','whole_floor':None,'peak_floor':None,'structural_floor':None,'protect_price':None,'protect_price_valid':False,'floor_hit':False,'all_reserved_hit':False,'free_quantity':n-reserved,'eligible_exit_quantity':0,'h0_117':dh}
        narrow=i.get('narrow')
        if n==0:
            need(narrow is None or narrow==h['narrow'],'flat新完成票');v['finished']=True
            if self.target is not None:dh['target_after_half_yen']=self.target
            return d
        gain=None
        if mark is not None:
            gain=e['side']*(mark-number(e['price']));u=100*gain-self.cost;uh=half(u);wh=rh+n*uh
            d.update(gain_points=gain,unit_net_yen=u,whole_net_yen=Decimal(wh)/2)
            if not v['active'] and wh>0:
                v.update(active=True,activated_at=at,peak_points=gain);self.target=rh-2*n*self.cost;h['target_set']=True
                d['activated_now']=True;dh.update(target_initialized_now=True,initial_target_half_yen=self.target)
        # ----------------------------------------
        # 完成票の意味は別監視器が担当。ここでは最初の票の所有・時点・固定を検査する。
        if narrow is not None:
            need(e['policy']=='H0M' and v['active'] and narrow['scope']==e['scope'] and bool(narrow['id']) and narrow['completed'] is True,'完成票の政策/場/状態')
            need(number(e['at'])<=number(narrow['at'])<=at and type(narrow['source_index']) is int and 0<=narrow['source_index']<=idx and type(narrow['source_line']) is int and narrow['source_line']>=1,'完成票の時計/原行')
            w=number(narrow['width_points']);need(5<=w<=Decimal('1e6') and w%5==0,'完成幅')
            if h['narrow'] is not None:equal(h['narrow'],narrow,'最初完成票の固定')
            else:h['narrow']=deepcopy(narrow);dh['narrow_latched_now']=True
        if h['narrow'] is not None:d['warning']=2
        if not v['active']:return d
        if mark is not None:
            v['peak_points']=max(number(v['peak_points']),gain)
            if h['narrow'] is not None and not h['narrow_applied']:
                v.update(width_points=min(number(v['normal_width']),number(h['narrow']['width_points'])),narrowed=True,narrowed_at=at);h.update(narrow_applied=True,narrow_applied_at=at);d['narrowed_now']=True;dh['narrow_applied_now']=True
            zero=max(0,whole_floor(0,rh,self.cost,n));room=number(zero)<=gain-5;dh.update(zero_candidate_floor=zero,zero_room=room)
            if not h['zero_target_adopted'] and room:
                self.target=max(self.target,0);h.update(zero_target_adopted=True,zero_target_at=at);dh['zero_target_adopted_now']=True
        d['width_source']='取得時固定通常幅'
        if h['narrow_applied']:d['width_source']='最初の短期完成幅と取得時通常幅のmin'
        elif h['narrow'] is not None:d['width_source']='完成警戒ラッチ・正常Mark待ち・通常幅保持'
        peak_floor=ceil5(number(v['peak_points'])-number(v['width_points']));fw=whole_floor(self.target,rh,self.cost,n)
        floor=max(Decimal(0),number(v['floor_points']) if v['floor_points'] is not None else Decimal(0),peak_floor,number(fw))
        implied=rh+n*(int(200*floor)-2*self.cost);self.target=max(self.target,implied)
        v.update(floor_points=floor,whole_target_yen=Decimal(self.target)/2);h['whole_target_half_yen']=self.target;dh.update(target_after_half_yen=self.target,floor_implied_half_yen=implied);d.update(whole_floor=fw,peak_floor=peak_floor)
        if mark is not None:
            price=number(e['price'])+e['side']*floor;hit=gain<=floor;d.update(protect_price=price,protect_price_valid=price.is_finite() and price>0,floor_hit=hit,all_reserved_hit=hit and reserved==n)
            if hit and phase=='after_source':d['eligible_exit_quantity']=n-reserved
        return d


def verify_export(value:dict)->dict:
    """
    機能: 別authorのH0人工系列の初期/Before/After/Decisionを全値照合する。
    引数: value(dict)。返り値: dictは照合数と範囲。旧政策や自然金融を証明しない。
    """
    need(value['version']==1 and value['trial']==117 and value['artificial'] is True,'人工117のみ')
    need(isinstance(value['series'],list),'系列');count=0;coverage={'pre_fill':0,'after_source':0,'R正':0,'R負':0,'R半円':0,'Mark未知':0,'W厳密ゼロ':0,'全予約hit':0,'flat':0,'狭幅ラッチ':0,'狭幅適用':0};names=set()
    for case in value['series']:
        need(case['name'] not in names,'系列重複');names.add(case['name']);model=Model(case['entry']);equal(model.snapshot(),case['initial'],case['name']+'.initial')
        for k,point in enumerate(case['steps']):
            label=f"{case['name']}[{k}]";equal(model.snapshot(),point['before'],label+'.before');i=point['input'];decision=model.advance(i);equal(model.snapshot(),point['after'],label+'.after');equal(decision,point['decision'],label+'.decision');count+=1
            coverage[i['phase']]+=1;r=number(i['closed_net_yen']);coverage['R正']+=r>0;coverage['R負']+=r<0;coverage['R半円']+=r!=r.to_integral_value();coverage['Mark未知']+=i['mark'] is None;coverage['W厳密ゼロ']+=decision['whole_net_yen']==0;coverage['全予約hit']+=decision['all_reserved_hit'];coverage['flat']+=i['remaining']==0;coverage['狭幅ラッチ']+=decision['h0_117']['narrow_latched_now'];coverage['狭幅適用']+=decision['h0_117']['narrow_applied_now']
    return {'成功':True,'系列数':len(names),'Advance数':count,'初期Snapshot一致':len(names),'Before_After_Decision全値一致':count,'coverage':coverage,'旧W100_P100独立数式検算':False,'短期票意味/公表asof検査':False,'Go呼出し':0,'金額誤差許容':0}
