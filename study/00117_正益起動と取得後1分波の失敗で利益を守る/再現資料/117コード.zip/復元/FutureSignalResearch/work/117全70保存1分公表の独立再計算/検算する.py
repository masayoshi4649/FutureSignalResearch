"""Rootが固定した全70場だけを許可する保存公表検算CLI。"""

import argparse
import gzip
import hashlib
import importlib.util
import json
from decimal import Decimal
from pathlib import Path
import sys

sys.stdout.reconfigure(encoding="utf-8")
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
F1_PATH = ROOT / "work/117進行/F1_117金融条件.json"
F1_SHA = "522fe2343b914243fadc4f48d32128a79ecdafcabd84d5a58b5ca399af90d1b0"
COMPLETION_PATH = ROOT / "work/117金融F1/全70場/完了.json"
COMPLETION_SHA = "f9d5dfc49bef7f9b2dcf6bba55fe264b689dc2e8312e0e26c4530e4b1d2872e0"
ORIGINAL_CODE = {'人工検査.py': 'eea3c96921bd769fe5ed3be78d37cb5344a7f6f0609f499e1b3d41cc9013e7dd', '保存値を照合する.py': '45b99c1a1824f9230a2f42c2dc3cf3177f9c0ee791067e5ff76419e0a31d11ee', '検算する.py': 'fd0c31290faa5b75048abda7389d6130ac05d4beb57ea0eb27913656450be5eb'}
SCENES = ('2026-09-21_Day', '2026-09-21_Night', '2026-09-22_Day', '2026-09-22_Night', '2026-09-23_Day', '2026-09-23_Night', '2026-09-24_Day', '2026-09-24_Night', '2026-09-25_Day', '2026-09-25_Night', '2026-09-28_Day', '2026-09-28_Night', '2026-09-29_Day', '2026-09-29_Night', '2026-09-30_Day', '2026-09-30_Night', '2026-10-01_Day', '2026-10-01_Night', '2026-10-02_Day', '2026-10-02_Night', '2026-10-05_Day', '2026-10-05_Night', '2026-10-06_Day', '2026-10-06_Night', '2026-10-07_Day', '2026-10-07_Night', '2026-10-08_Day', '2026-10-08_Night', '2026-10-09_Day', '2026-10-09_Night', '2026-10-12_Day', '2026-10-12_Night', '2026-10-13_Day', '2026-10-13_Night', '2026-10-14_Day', '2026-10-14_Night', '2026-10-15_Day', '2026-10-15_Night', '2026-10-16_Day', '2026-10-16_Night', '2026-10-19_Day', '2026-10-19_Night', '2026-10-20_Day', '2026-10-20_Night', '2026-10-21_Day', '2026-10-21_Night', '2026-10-22_Day', '2026-10-22_Night', '2026-10-23_Day', '2026-10-23_Night', '2026-10-26_Day', '2026-10-26_Night', '2026-10-27_Day', '2026-10-27_Night', '2026-10-28_Day', '2026-10-28_Night', '2026-10-29_Day', '2026-10-29_Night', '2026-10-30_Day', '2026-10-30_Night', '2026-11-02_Day', '2026-11-02_Night', '2026-11-03_Day', '2026-11-03_Night', '2026-11-04_Day', '2026-11-04_Night', '2026-11-05_Day', '2026-11-05_Night', '2026-11-06_Day', '2026-11-06_Night')


def sha(path):
    """
    機能: 許可済みファイルのbytesをSHA256へ写す。
    引数: path(Path)はコード・小metadata又は許可Native。
    返り値: strはSHA256。
    """
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            digest.update(block)
    return digest.hexdigest()


def load_code():
    """
    機能: 自所有の検査実装を読み込む。
    引数: なし。
    返り値: moduleは保存公表の算術検査器。
    """
    spec = importlib.util.spec_from_file_location("saved_ohlc117", HERE / "保存値を照合する.py")
    instance = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = instance
    spec.loader.exec_module(instance)
    return instance


def ref_form(ref):
    """
    機能: 参照の型・絶対path・SHA表記を本文を開かず検査する。
    引数: ref(dict)はpath/sha256。
    返り値: Pathは明示された絶対位置。
    """
    assert set(ref) == {"path", "sha256"} and isinstance(ref["path"], str)
    path = Path(ref["path"])
    assert path.is_absolute() and len(ref["sha256"]) == 64 and set(ref["sha256"]) <= set("0123456789abcdef")
    return path


def read_ref(ref, before):
    """
    機能: 小JSONを期待SHAで認証し、実入力集合へ登録する。
    引数: ref(dict)、before(dict[str,str])は参照と前指紋。
    返り値: dictはDecimalで復元したJSON。
    """
    path = ref_form(ref)
    assert sha(path) == ref["sha256"], "小JSONのSHA差"
    before[str(path)] = ref["sha256"]
    return json.loads(path.read_text(encoding="utf-8"), parse_float=Decimal)


def validate_metadata(condition, completion, f1_sha):
    """
    機能: 固定117と全70成功を、Nativeを開かず論理照合する。
    引数: condition/completion(dict)、f1_sha(str)は認証済みmetadataと条件指紋。
    返り値: list[dict]は全70のNative参照だけ。
    """
    assert condition["version"] == 1 and condition["trial"] == 117 and condition["fixed"] is True and condition["source_trial"] == 111
    assert condition["chart_seed_mode"] == "cold_each_session" and condition["entry_grid_seconds"] is None and condition["extra_opening_quiet_seconds"] == 0
    assert len(condition["actual_configurations"]) == 20
    expected = [{"policy": policy, "slip_pts": cost, "delay_seconds": delay} for policy in ("S0", "W100", "P100", "H0E", "H0M") for cost in (0, 5) for delay in (0, 1)]
    assert condition["actual_configurations"] == expected
    assert completion["version"] == 1 and completion["trial"] == 117 and completion["stage"] == "full70" and completion["success"] is True
    assert completion["condition_sha256"] == f1_sha and completion["sessions"] == 70 and completion["books"] == 1400
    assert completion["reused_sessions"] == 54 and completion["replayed_sessions"] == 16 and completion["original_methods"] == 81
    assert completion["reference112_comparisons"] == 840 and completion["all_reference112_equal"] is True and completion["all_source111_equal"] is True
    assert completion["unchanged"] is True and completion["before"] == completion["after"]
    assert len(completion["results"]) == 70
    refs = []
    for index, row in enumerate(completion["results"]):
        assert row["session"] == SCENES[index] and row["books"] == 20 and row["S0_comparisons"] == 4 and row["S0_equal"] is True
        assert row["complete"] is True and row["open_quantity"] == 0 and row["pending_quantity"] == 0
        assert row["reference112_comparisons"] == 12 and row["reference112_equal"] is True and row["source111_equal"] is True
        ref_form(row["native"])
        refs.append(row["native"])
    return refs


# ----------------------------------------
def required_dependencies(code):
    """
    機能: 既独立式に、先頭2原本3コードと成功準備Refを結ぶ。
    引数: code(module)は同byte保存公表検算器。
    返り値: dict[Path,str]は変更しない依存集合。
    """
    refs = code.dependencies()
    source = HERE.parent / "117保存1分公表の独立再計算"
    refs.update({source / name: expected for name, expected in ORIGINAL_CODE.items()})
    refs[source / "人工確認_02/準備の確認.json"] = "3151ba0e8b62112b051fd63e639223ed3ec2d79c79b31ba05e878e26679db478"
    return refs


def prepare(request_ref):
    """
    機能: Root要求・全70metadata・自コード/依存を本文前に認証する。
    引数: request_ref(dict)は新Root要求Ref。
    返り値: tupleは要求・条件・Native参照70件・全前指紋。
    """
    before = {}
    request = read_ref(request_ref, before)
    assert request["version"] == 1 and request["trial"] == 117 and request["fixed"] is True and request["authorized"] is True
    assert request["source"] == "saved_closed_ohlc_full70_only" and request["Raw読取許可"] is False and request["金融再実行"] is False
    refs = request["refs"]
    assert set(refs) == {"condition", "financial_completion", "checker"}
    assert refs["condition"] == {"path": str(F1_PATH), "sha256": F1_SHA}
    assert refs["financial_completion"] == {"path": str(COMPLETION_PATH), "sha256": COMPLETION_SHA}
    assert ref_form(refs["checker"]).is_relative_to(HERE), "検査器の証拠は自所有内だけ"
    checker = read_ref(refs["checker"], before)
    assert checker["成功"] is True and checker["人工のみ"] is True and checker["正式停止"] is False
    expected_owned = {str(path): sha(path) for path in sorted(HERE.glob("*.py"))}
    assert checker["所有コードSHA256"] == expected_owned
    before.update(expected_owned)
    assert sha(HERE / "保存値を照合する.py") == ORIGINAL_CODE["保存値を照合する.py"]
    code = load_code()
    expected_dependencies = {str(path): expected for path, expected in required_dependencies(code).items()}
    assert checker["依存SHA256"] == expected_dependencies
    for path, expected in expected_dependencies.items():
        assert sha(Path(path)) == expected
        before[path] = expected
    condition = read_ref(refs["condition"], before)
    completion = read_ref(refs["financial_completion"], before)
    native_refs = validate_metadata(condition, completion, F1_SHA)
    for index, (sid, ref) in enumerate(zip(SCENES, native_refs)):
        source_root = COMPLETION_PATH.parent.parent / "元54場" if index < 54 else COMPLETION_PATH.parent
        expected = source_root / "worker" / sid / (sid + ".Native.json.gz")
        assert ref_form(ref) == expected
    return request, condition, native_refs, before


def main():
    """
    機能: metadata-only又は明示全70の保存公表再計算を実行する。
    引数: CLI --request/--request-sha(str)、--out(Path)、--metadata-only(bool)。
    返り値: None。未認証・既存出力・不一致は終了失敗。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--request", type=Path, required=True)
    parser.add_argument("--request-sha", required=True)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--metadata-only", action="store_true")
    args = parser.parse_args()
    request_ref = {"path": str(args.request.absolute()), "sha256": args.request_sha}
    request, condition, native_refs, before = prepare(request_ref)
    if args.metadata_only:
        assert all(sha(Path(path)) == expected for path, expected in before.items())
        print(json.dumps({"metadata_verified": True, "Native本文読取": 0, "Native指紋走査": 0, "Raw読取": 0, "場数": 70, "実行": False}, ensure_ascii=False))
        return
    assert args.out is not None
    out = args.out.absolute()
    assert out.is_relative_to(HERE) and not out.exists(), "新規の自所有先だけを許可"
    code = load_code()
    results = []
    for sid, ref in zip(SCENES, native_refs):
        path = Path(ref["path"])
        assert sha(path) == ref["sha256"], "Native圧縮bytesのSHA差"
        before[str(path)] = ref["sha256"]
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            native = json.load(stream, parse_float=Decimal)
        assert native["actual"]["configurations"] == condition["actual_configurations"]
        assert native["actual"]["short_definition"] == condition["short_definition"]
        results.append(code.inspect_native(native, sid))
    after = {path: sha(Path(path)) for path in before}
    assert before == after
    result = {"試行": 117, "成功": True, "stage": "full70", "場数": 70, "Root要求SHA256": request_ref["sha256"], "金融条件SHA256": F1_SHA, "金融完了SHA256": COMPLETION_SHA, "結果": results, "入力SHA256": before, "後SHA256": after, "前後不変": True, "数値精度": 50, "指標絶対許容差": "1e-9", "真偽補正": False, "OHLCを原板から独立検証": False, "全Raw発生漏れ最初性": False, "損益再計算": False, "Raw読取": 0, "金融再実行": False, "限界": ["保存OHLCを所与とする指標再形成。OHLC全体の原板正確性・全Raw配送・最初性は別監査", "arm/warningの保存点と参照公表の整合を検査するが、未保存の全原行で最初の警戒だったとは証明しない", "冷間・欠足・arm・警戒・実幅・要求を分離。正益床の金額式・実損益を再検算しない"]}
    out.mkdir()
    target = out / "確認.json"
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "結果": str(target), "sha256": sha(target), "場数": 70}, ensure_ascii=False))


if __name__ == "__main__":
    main()
