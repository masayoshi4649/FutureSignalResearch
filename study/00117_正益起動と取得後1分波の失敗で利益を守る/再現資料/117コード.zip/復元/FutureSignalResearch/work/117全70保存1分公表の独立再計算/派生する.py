"""先頭2の停止済み検査器を変更せず、全70入力ゲートだけを派生する。"""

import hashlib
import json
from pathlib import Path
import sys

sys.stdout.reconfigure(encoding="utf-8")
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
SOURCE = HERE.parent / "117保存1分公表の独立再計算"
COMPLETION = ROOT / "work/117金融F1/全70場/完了.json"
COMPLETION_SHA = "f9d5dfc49bef7f9b2dcf6bba55fe264b689dc2e8312e0e26c4530e4b1d2872e0"
EXPECTED = {
    "人工検査.py": "eea3c96921bd769fe5ed3be78d37cb5344a7f6f0609f499e1b3d41cc9013e7dd",
    "保存値を照合する.py": "45b99c1a1824f9230a2f42c2dc3cf3177f9c0ee791067e5ff76419e0a31d11ee",
    "検算する.py": "fd0c31290faa5b75048abda7389d6130ac05d4beb57ea0eb27913656450be5eb",
}


def sha(path):
    """
    機能: 旧コードと許可済み小completionのSHAを認証する。
    引数: path(Path)は明示入力。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def replace_once(text, old, new):
    """
    機能: 明示された一箇所だけを薄いゲート差へ置き換える。
    引数: text/old/new(str)は原文と変更前後。
    返り値: strは派生本文。変更位置不一致は拒否する。
    """
    assert text.count(old) == 1, old
    return text.replace(old, new)


def main():
    """
    機能: 新所有へ計算器同bytesと全70のゲート/人工を作成する。
    引数: なし。Root許可済み全70completionの小metadataだけを使う。
    返り値: None。旧ファイルと自然Nativeは開かず、既存派生先も上書きしない。
    """
    before = {str(SOURCE / name): sha(SOURCE / name) for name in EXPECTED}
    assert all(before[str(SOURCE / name)] == expected for name, expected in EXPECTED.items())
    assert sha(COMPLETION) == COMPLETION_SHA
    completion = json.loads(COMPLETION.read_text(encoding="utf-8"))
    assert completion["trial"] == 117 and completion["stage"] == "full70" and completion["success"] is True
    scenes = tuple(row["session"] for row in completion["results"])
    assert len(scenes) == 70 and len(set(scenes)) == 70
    assert scenes[0] == "2026-09-21_Day" and scenes[53] == "2026-10-27_Night" and scenes[-1] == "2026-11-06_Night"
    calculator = (SOURCE / "保存値を照合する.py").read_bytes()
    cli = (SOURCE / "検算する.py").read_text(encoding="utf-8")
    cli = cli.replace("先頭2場", "全70場").replace("先頭2", "全70").replace("first2", "full70").replace("2Native", "70Native")
    cli = replace_once(cli, 'COMPLETION_SHA = "e95b691c33da0e6ab0cf3e7e732849dabacd8d2dbb739eefd00a3f932109501f"', f'COMPLETION_SHA = "{COMPLETION_SHA}"')
    cli = replace_once(cli, 'SCENES = ("2026-09-21_Day", "2026-09-21_Night")', "SCENES = " + repr(scenes))
    cli = replace_once(cli, 'completion["sessions"] == 2 and completion["books"] == 40', 'completion["sessions"] == 70 and completion["books"] == 1400')
    cli = replace_once(cli, 'completion["reused_sessions"] == 0 and completion["replayed_sessions"] == 2 and completion["original_methods"] == 3', 'completion["reused_sessions"] == 54 and completion["replayed_sessions"] == 16 and completion["original_methods"] == 81')
    cli = replace_once(cli, 'completion["reference112_comparisons"] == 24', 'completion["reference112_comparisons"] == 840')
    cli = replace_once(cli, 'len(completion["results"]) == 2', 'len(completion["results"]) == 70')
    cli = replace_once(cli, 'for sid, ref in zip(SCENES, native_refs):\n        expected = COMPLETION_PATH.parent / "worker" / sid / (sid + ".Native.json.gz")', 'for index, (sid, ref) in enumerate(zip(SCENES, native_refs)):\n        source_root = COMPLETION_PATH.parent.parent / "元54場" if index < 54 else COMPLETION_PATH.parent\n        expected = source_root / "worker" / sid / (sid + ".Native.json.gz")')
    cli = cli.replace('"場数": 2', '"場数": 70')
    cli = cli.replace("Native参照2件", "Native参照70件")
    # ----------------------------------------
    # 再用元そのものも実行前後へ結び、計算器同byteを単独のSHAで要求する。
    function = '''def required_dependencies(code):
    """
    機能: 既独立式に、先頭2原本3コードと成功準備Refを結ぶ。
    引数: code(module)は同byte保存公表検算器。
    返り値: dict[Path,str]は変更しない依存集合。
    """
    refs = code.dependencies()
    source = HERE.parent / "117保存1分公表の独立再計算"
    refs.update({source / name: expected for name, expected in ORIGINAL_CODE.items()})
    refs[source / "人工確認_02/準備の確認.json"] = "3151ba0e8b62112b051fd63e639223ed3ec2d79c79b31ba05e878e26679db478"
    return refs


'''
    cli = replace_once(cli, 'def prepare(request_ref):', function + 'def prepare(request_ref):')
    cli = replace_once(cli, 'expected_dependencies = {str(path): expected for path, expected in code.dependencies().items()}', 'expected_dependencies = {str(path): expected for path, expected in required_dependencies(code).items()}')
    cli = replace_once(cli, 'SCENES = ' + repr(scenes), 'ORIGINAL_CODE = ' + repr(EXPECTED) + '\nSCENES = ' + repr(scenes))
    cli = replace_once(cli, 'code = load_code()\n    expected_dependencies', 'assert sha(HERE / "保存値を照合する.py") == ORIGINAL_CODE["保存値を照合する.py"]\n    code = load_code()\n    expected_dependencies')
    artificial = (SOURCE / "人工検査.py").read_text(encoding="utf-8")
    artificial = artificial.replace("先頭2", "全70").replace("first2", "full70").replace("2Native", "70Native")
    artificial = replace_once(artificial, 'refs = code.dependencies()', 'refs = cli.required_dependencies(code)')
    artificial = replace_once(artificial, '"sessions": 2, "books": 40, "reused_sessions": 0, "replayed_sessions": 2, "original_methods": 3, "reference112_comparisons": 24', '"sessions": 70, "books": 1400, "reused_sessions": 54, "replayed_sessions": 16, "original_methods": 81, "reference112_comparisons": 840')
    artificial = replace_once(artificial, 'len(cli.validate_metadata(condition, completion, cli.F1_SHA)) == 2', 'len(cli.validate_metadata(condition, completion, cli.F1_SHA)) == 70')
    artificial = replace_once(artificial, '(("trial", 116), ("stage", "full70"), ("condition_sha256", "別F1"), ("books", 39), ("success", False))', '(("trial", 116), ("stage", "first2"), ("condition_sha256", "別F1"), ("books", 1399), ("success", False))')
    artificial = replace_once(artificial, '"依存SHA256": {str(path): expected for path, expected in code.dependencies().items()}', '"依存SHA256": {str(path): expected for path, expected in cli.required_dependencies(code).items()}')
    changes = {"保存値を照合する.py": calculator, "検算する.py": cli.encode("utf-8"), "人工検査.py": artificial.encode("utf-8")}
    for name, content in changes.items():
        with (HERE / name).open("xb") as stream:
            stream.write(content)
    assert before == {str(SOURCE / name): sha(SOURCE / name) for name in EXPECTED} and sha(COMPLETION) == COMPLETION_SHA
    record = {"試行": 117, "成功": True, "旧所有前後不変": True, "元3コードSHA256": before, "全70completion": {"path": str(COMPLETION), "sha256": COMPLETION_SHA}, "新3コードSHA256": {str(HERE / name): sha(HERE / name) for name in changes}, "計算器同bytes": (HERE / "保存値を照合する.py").read_bytes() == calculator, "変更範囲": "全70/F1/70Native・54再用16新規の入力ゲートと人工metadataのみ。保存公表の指標/支持/警戒演算は同byte", "自然Native読取": 0, "Raw読取": 0, "金融実行": False, "停止": False}
    target = HERE / "派生の確認.json"
    with target.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"成功": True, "派生": str(target), "sha256": sha(target), "計算器同bytes": True}, ensure_ascii=False))


if __name__ == "__main__":
    main()
