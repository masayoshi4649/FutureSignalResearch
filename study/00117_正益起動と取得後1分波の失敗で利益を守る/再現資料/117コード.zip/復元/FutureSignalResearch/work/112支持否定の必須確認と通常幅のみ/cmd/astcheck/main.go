package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"go/ast"
	"go/parser"
	"go/token"
	"os"
	"path/filepath"
	"reflect"
	"sort"
)

// normalized は位置・コメント・識別子の解決状態を除いて構文木を正規化します。
//
// 引数: node(any)は解析済みAST。返り値: string/errorは意味構造の表示又は不正です。
func normalized(node any) (string, error) {
	var out bytes.Buffer
	err := ast.Fprint(&out, nil, node, func(name string, value reflect.Value) bool {
		return name != "Doc" && name != "Comment" && value.Type() != reflect.TypeOf(token.Pos(0))
	})
	return out.String(), err
}

// declarations は純本体三ファイルの関数・型・定数だけを読み取ります。
//
// 引数: dir(string)は市場データでない純Goの位置。返り値: map[string]string/errorはAST又は解析差です。
func declarations(dir string) (map[string]string, error) {
	out := map[string]string{}
	for _, name := range []string{"state.go", "types.go", "bb.go"} {
		file, err := parser.ParseFile(token.NewFileSet(), filepath.Join(dir, name), nil, parser.SkipObjectResolution)
		if err != nil {
			return nil, err
		}
		for _, declaration := range file.Decls {
			switch node := declaration.(type) {
			case *ast.FuncDecl:
				key := name + "/func/" + node.Name.Name
				value, err := normalized(node)
				if err != nil {
					return nil, err
				}
				if _, exists := out[key]; exists {
					return nil, fmt.Errorf("同ファイル内の関数名重複")
				}
				out[key] = value
			case *ast.GenDecl:
				for _, spec := range node.Specs {
					var key string
					switch item := spec.(type) {
					case *ast.TypeSpec:
						key = name + "/type/" + item.Name.Name
					case *ast.ValueSpec:
						for _, id := range item.Names {
							key += id.Name + ","
						}
						key = name + "/" + node.Tok.String() + "/" + key
					default:
						continue
					}
					value, err := normalized(spec)
					if err != nil {
						return nil, err
					}
					out[key] = value
				}
			}
		}
	}
	return out, nil
}

// run は旧純保護からの関数差を四関数と新定義二関数に限定して記録します。
//
// 引数: CLIのold/current/out(string)は旧本体・新本体・新規metadata先です。
// 返り値: errorは予期しない構文差又は保存失敗です。旧コードを書きません。
func run() error {
	old := flag.String("old", "", "停止111純部品")
	current := flag.String("current", ".", "新112純部品")
	out := flag.String("out", "", "新規AST差分metadata")
	flag.Parse()
	if *old == "" || *out == "" {
		return fmt.Errorf("旧純部品と新規出力が必要")
	}
	a, err := declarations(*old)
	if err != nil {
		return err
	}
	b, err := declarations(*current)
	if err != nil {
		return err
	}
	allowed := map[string]bool{"state.go/func/NewState": true, "state.go/func/warningFor": true, "state.go/func/Advance": true, "types.go/func/DeclaredConfigurations": true}
	addedFunctions := map[string]bool{"types.go/func/DefinitionFor": true, "types.go/func/DeclaredDefinitions": true}
	changed, added, removed, same := []string{}, []string{}, []string{}, []string{}
	for key, before := range a {
		after, exists := b[key]
		if !exists {
			removed = append(removed, key)
		} else if before != after {
			changed = append(changed, key)
		} else {
			same = append(same, key)
		}
	}
	for key := range b {
		if _, exists := a[key]; !exists {
			added = append(added, key)
		}
	}
	for _, keys := range [][]string{changed, added, removed, same} {
		sort.Strings(keys)
	}
	functionChanged := []string{}
	for _, key := range changed {
		if bytes.Contains([]byte(key), []byte("/func/")) {
			if !allowed[key] {
				return fmt.Errorf("予定外の関数変更:%s", key)
			}
			functionChanged = append(functionChanged, key)
		}
	}
	if len(functionChanged) != len(allowed) {
		return fmt.Errorf("予定した四関数差と不一致")
	}
	for _, key := range added {
		if bytes.Contains([]byte(key), []byte("/func/")) && !addedFunctions[key] {
			return fmt.Errorf("予定外の追加関数:%s", key)
		}
	}
	for _, key := range removed {
		if bytes.Contains([]byte(key), []byte("/func/")) {
			return fmt.Errorf("旧関数を削除:%s", key)
		}
	}
	value := map[string]any{"成功": true, "AST位置コメント除外": true, "旧": *old, "新": *current, "関数変更": functionChanged,
		"許可された関数追加": addedFunctions, "全宣言変更": changed, "全宣言追加": added, "全宣言削除": removed, "同体宣言": same,
		"範囲": "ASTは関数構造の差分。新定義と公表型alias/追加Snapshot説明を全列挙。金融挙動同体は旧W100/B100の全Snapshot/Decision人工で別証明。"}
	raw, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	f, err := os.OpenFile(*out, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	_, err = f.Write(append(raw, '\n'))
	if closeErr := f.Close(); err == nil {
		err = closeErr
	}
	return err
}

// main はASTの予定外差を終了1へ反映します。
//
// 引数: なし。返り値: ありません。旧本体と新metadataだけを扱います。
func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
