module github.com/masayoshi4649/SessionTradeExecuter/profitfloor112

go 1.24.2

require github.com/masayoshi4649/SessionTradeExecuter/profitfloor111 v0.0.0

replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor111 => ../111全玉利益と収束BBの純保護
