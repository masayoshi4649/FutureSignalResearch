package profitfloor112

import (
	"encoding/json"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	prior "github.com/masayoshi4649/SessionTradeExecuter/profitfloor111"
)

// entryFixture は同じ実新規を真の政策IDと売買符号だけ変えて作ります。
//
// 引数: policy(Policy)、side/q(int)、atr(*float64)は手製値。返り値: Entryは市場を使わない取得です。
func entryFixture(policy Policy, side, q int, atr *float64) Entry {
	e := Entry{Scope: Scope{Session: "人工場", Contract: "人工限月", Start: 0}, Policy: policy, Side: side, Price: 1000, At: 3600, InitialQuantity: q}
	if atr != nil {
		e.ATR = &Evidence{Value: *atr, AvailableAt: 3600, ID: "取得時ATR"}
	}
	return e
}

// inputFixture は現在気配と同じ玉の実会計値を作ります。
//
// 引数: e(Entry)、seq(uint64)、gain(float64)、n/r(int)、realized(float64)は人工入力です。
// 返り値: Inputはafter_sourceの一原行です。
func inputFixture(e Entry, seq uint64, gain float64, n, r int, realized float64) Input {
	return Input{At: 5000 + float64(seq), Sequence: seq, Phase: AfterSource, Mark: pointer(e.Price + float64(e.Side)*gain), Remaining: n, Reserved: r, ClosedNetYen: realized}
}

// mustState は人工取得の正常初期化を確認します。
//
// 引数: t(*testing.T)、e(Entry)は人工。返り値: Stateは成功状態です。
func mustState(t *testing.T, e Entry) State {
	t.Helper()
	s, err := NewState(e)
	if err != nil {
		t.Fatal(err)
	}
	return s
}

// advanceOK は人工原行の成功と次状態を取得します。
//
// 引数: t(*testing.T)、s(State)、in(Input)は人工。返り値: State/Decisionは純結果です。
func advanceOK(t *testing.T, s State, in Input) (State, Decision) {
	t.Helper()
	next, d, err := Advance(s, in)
	if err != nil {
		t.Fatal(err)
	}
	return next, d
}

// publicationFixture はP三値を実際のClose/pivot関係で表します。
//
// 引数: e(Entry)、ordinal(int)、p/c/m(Truth)、v(*float64)は公表と既知性です。
// 返り値: Publicationは旧chart111と型が同じ確定3分値です。
func publicationFixture(e Entry, ordinal int, p, c, m Truth, v *float64) Publication {
	start := 3600 + float64(ordinal-21)*180
	out := Publication{Scope: e.Scope, ID: "人工公表" + string(rune('a'+ordinal)), Ordinal: uint64(ordinal), Start: start, End: start + 180, AvailableAt: start + 180, C: c, M: m, V: v, Close: pointer(e.Price + float64(e.Side)*100)}
	if p != Unknown {
		kind := "low"
		if e.Side == -1 {
			kind = "high"
		}
		out.PriorPivot = &Pivot{Scope: e.Scope, ID: "確認済pivot", Kind: kind, Price: e.Price + float64(e.Side)*50, CenterStart: e.At, CenterEnd: e.At + 180, ConfirmEnd: e.At + 180, PublishedAt: e.At + 180}
		if p == True {
			out.Close = pointer(e.Price + float64(e.Side)*45)
		}
	}
	return out
}

// legacyEntry は比較対照のW100/B100だけを111の同値取得型へ写します。
//
// 引数: e(Entry)は旧対照政策。返り値: prior.Entryは政策・ATR・数量を偽装しない同値です。
func legacyEntry(e Entry) prior.Entry {
	return prior.Entry{Scope: e.Scope, Policy: prior.Policy(e.Policy), Side: e.Side, Price: e.Price, At: e.At, InitialQuantity: e.InitialQuantity, SlipPoints: e.SlipPoints, ATR: copyValue(e.ATR)}
}

// legacyInput は同じ原行を旧対照へ渡します。
//
// 引数: in(Input)は生C/M/P/Bを含む人工原行。返り値: prior.Inputは値・尺度無変更です。
func legacyInput(in Input) prior.Input {
	return prior.Input{At: in.At, Sequence: in.Sequence, Phase: in.Phase, Mark: copyValue(in.Mark), Remaining: in.Remaining, Reserved: in.Reserved, ClosedNetYen: in.ClosedNetYen, Publication: copyValue(in.Publication), ResetReason: in.ResetReason}
}

// sameLegacyJSON は追加definitionの説明だけを除き全State公開値と全Decisionを比較します。
//
// 引数: t(*testing.T)、current/old(any)、snapshot(bool)は比較値と状態指定です。
// 返り値: ありません。政策・ATR・C/M/P/B・数式fieldを除外しません。
func sameLegacyJSON(t *testing.T, current, old any, snapshot bool) {
	t.Helper()
	a, err := json.Marshal(current)
	if err != nil {
		t.Fatal(err)
	}
	b, err := json.Marshal(old)
	if err != nil {
		t.Fatal(err)
	}
	var x, y map[string]any
	if err = json.Unmarshal(a, &x); err != nil {
		t.Fatal(err)
	}
	if err = json.Unmarshal(b, &y); err != nil {
		t.Fatal(err)
	}
	if snapshot {
		delete(x, "definition")
	}
	if !reflect.DeepEqual(x, y) {
		t.Fatalf("旧対照の全JSON差\n新:%s\n旧:%s", a, b)
	}
}

// TestDeclarationsRealPolicyAndWidth は六真ID・幅定義・24費用遅延を確認し実宣言を保存します。
//
// 引数: t(*testing.T)は検査器。返り値: ありません。市場・Actor・Sourceを実行しません。
func TestDeclarationsRealPolicyAndWidth(t *testing.T) {
	want := []Policy{S0, W100, B100, W400, P100, P400}
	configs, defs := DeclaredConfigurations(), DeclaredDefinitions()
	if len(configs) != 24 || len(defs) != 6 {
		t.Fatal("宣言数")
	}
	for i, p := range want {
		if defs[i].Policy != p || defs[i].Version != 112 {
			t.Fatal("真の政策順と版")
		}
		for j, pair := range [][2]float64{{0, 0}, {0, 1}, {5, 0}, {5, 1}} {
			if configs[i*4+j] != (Configuration{Policy: p, SlipPoints: pair[0], DelaySeconds: int(pair[1])}) {
				t.Fatal("費用/遅延の固定順")
			}
		}
		if p == S0 {
			if defs[i].Enabled {
				t.Fatal("S0追加保護")
			}
			continue
		}
		for _, a := range []*float64{nil, pointer(80), pointer(125.5)} {
			e := entryFixture(p, 1, 1, a)
			v := mustState(t, e).Snapshot()
			minimum, multiple := 200.0, 2.0
			if p == W400 || p == P400 {
				minimum, multiple = 400, 4
			}
			width := minimum
			if a != nil {
				width = 5 * math.Ceil(math.Max(minimum, multiple**a)/5)
			}
			if v.Entry.Policy != p || v.Definition != defs[i] || v.Definition.NormalWidthMinimum != minimum || v.Definition.ATRMultiplier != multiple || v.ThresholdPoints != 100 || v.NormalWidth != width || v.ATRUnknownFallback != (a == nil) {
				t.Fatal("政策又はATR尺度の偽装/後補完/幅定義差")
			}
			if a != nil && v.Entry.ATR.Value != *a {
				t.Fatal("ATRの倍化偽装")
			}
		}
	}
	for _, p := range []Policy{S0, "U100", "T100", "B50", "未定義"} {
		if _, err := NewState(entryFixture(p, 1, 1, nil)); err == nil {
			t.Fatal("S0/旧未宣言政策を受理")
		}
	}
	if path := os.Getenv("PROFIT112_DECLARATION"); path != "" {
		value := map[string]any{"version": 112, "module": "profitfloor112", "configurations": configs, "definitions": defs, "publication_type": "profitfloor111.Publicationへの型alias。C/M/P/Bをマスクしない", "S0": "Actor側で扱い純状態を作らない", "scope": "市場前の純演算宣言"}
		raw, err := json.MarshalIndent(value, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		if err = os.MkdirAll(filepath.Dir(path), 0700); err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(path, append(raw, '\n'), 0600); err != nil {
			t.Fatal(err)
		}
	}
}

// TestLegacyWholeStateAndDecision は旧W100/B100の全段階を価格/ATR/数量を変えず比較します。
//
// 引数: t(*testing.T)は検査器。返り値: ありません。除外は新definition説明のみです。
func TestLegacyWholeStateAndDecision(t *testing.T) {
	for _, p := range []Policy{W100, B100} {
		for _, side := range []int{1, -1} {
			for _, slip := range []float64{0, 5} {
				for _, atr := range []*float64{nil, pointer(80), pointer(125.5)} {
					for _, quantity := range []int{1, 2, 10} {
						e := entryFixture(p, side, quantity, atr)
						e.SlipPoints = slip
						s := mustState(t, e)
						old, err := prior.NewState(legacyEntry(e))
						if err != nil {
							t.Fatal(err)
						}
						sameLegacyJSON(t, s.Snapshot(), old.Snapshot(), true)
						pub := publicationFixture(e, 21, False, True, False, pointer(10))
						inputs := []Input{}
						in := inputFixture(e, 1, 0, quantity, 0, 0)
						in.Mark = nil
						inputs = append(inputs, in, inputFixture(e, 2, 100, quantity, 0, 0))
						in = inputFixture(e, 3, 115, quantity, 0, 0)
						in.Publication = copyValue(&pub)
						inputs = append(inputs, in)
						pub = publicationFixture(e, 22, False, True, True, pointer(20))
						in = inputFixture(e, 4, 600, quantity, 0, 0)
						in.Publication = copyValue(&pub)
						inputs = append(inputs, in)
						in = inputFixture(e, 5, 0, quantity, quantity, 0)
						in.Mark = nil
						inputs = append(inputs, in)
						in = inputFixture(e, 6, 0, quantity, quantity, 0)
						in.Mark, in.ResetReason = nil, "欠足"
						inputs = append(inputs, in)
						in = inputFixture(e, 7, 450, quantity, quantity, 0)
						in.Publication = copyValue(&pub)
						inputs = append(inputs, in)
						pub = publicationFixture(e, 23, True, Unknown, True, pointer(60))
						in = inputFixture(e, 8, 450, quantity, quantity, 0)
						in.Publication = copyValue(&pub)
						inputs = append(inputs, in)
						if quantity > 1 {
							inputs = append(inputs, inputFixture(e, 9, 20, quantity-1, quantity-1, -.5))
						}
						in = inputFixture(e, 10, 0, 0, 0, -154)
						in.Mark = nil
						inputs = append(inputs, in)
						for _, in := range inputs {
							var d Decision
							var priorD prior.Decision
							s, d = advanceOK(t, s, in)
							old, priorD, err = prior.Advance(old, legacyInput(in))
							if err != nil {
								t.Fatal(err)
							}
							sameLegacyJSON(t, s.Snapshot(), old.Snapshot(), true)
							sameLegacyJSON(t, d, priorD, false)
						}
					}
				}
			}
		}
	}
}

// TestWidthOnlyAndMandatoryThreshold は通常幅だけを広げHと生ATRを変えません。
//
// 引数: t(*testing.T)は検査器。返り値: ありません。未知ATRでも必須起動します。
func TestWidthOnlyAndMandatoryThreshold(t *testing.T) {
	for _, p := range []Policy{W100, B100, W400, P100, P400} {
		for _, slip := range []float64{0, 5} {
			e := entryFixture(p, 1, 2, nil)
			e.SlipPoints = slip
			s := mustState(t, e)
			s, d := advanceOK(t, s, inputFixture(e, 1, 100, 2, 0, 0))
			if d.ActivatedNow || s.Snapshot().PeakPoints != nil {
				t.Fatal("費用控除前の100ptで起動")
			}
			s, d = advanceOK(t, s, inputFixture(e, 2, 115, 2, 0, 0))
			if !d.ActivatedNow || *s.Snapshot().PeakPoints != 115 || s.Snapshot().ThresholdPoints != 100 {
				t.Fatal("全玉一定利益の必須起動/起動前峰")
			}
			pub := publicationFixture(e, 21, False, False, False, pointer(5))
			in := inputFixture(e, 3, 600, 2, 0, 0)
			in.Publication = &pub
			s, _ = advanceOK(t, s, in)
			wide := p == W400 || p == P400
			wantWidth, wantFloor := 200.0, 400.0
			if wide {
				wantWidth, wantFloor = 400, 200
			}
			if s.Snapshot().WidthPoints != wantWidth || *s.Snapshot().FloorPoints != wantFloor || s.Snapshot().Entry.ATR != nil {
				t.Fatal("Vによる通常幅の自動縮小/未知ATRの後付け")
			}
		}
	}
}

// TestSupportRequiredRawTruthAndMirror はP必須とB旧対照の違いを生の三値で検査します。
//
// 引数: t(*testing.T)は検査器。返り値: ありません。C/Bを偽にマスクしません。
func TestSupportRequiredRawTruthAndMirror(t *testing.T) {
	and := [][]Truth{{Unknown, False, Unknown}, {False, False, False}, {Unknown, False, True}}
	for _, policy := range []Policy{W100, W400, B100, P100, P400} {
		for _, side := range []int{1, -1} {
			for p := Unknown; p <= True; p++ {
				for m := Unknown; m <= True; m++ {
					e := entryFixture(policy, side, 1, pointer(100))
					s := mustState(t, e)
					pub := publicationFixture(e, 21, p, True, m, pointer(20))
					in := inputFixture(e, 1, 300, 1, 0, 0)
					in.Publication = &pub
					s, d := advanceOK(t, s, in)
					warn := and[m][p]
					if policy != P100 && policy != P400 {
						warn = m
					}
					wantNarrow := policy == B100 && m == True || (policy == P100 || policy == P400) && m == True && p == True
					if d.C != True || d.M != m || d.P != p || d.Warning != warn || d.NarrowedNow != wantNarrow || s.Snapshot().Narrowed != wantNarrow {
						t.Fatalf("生三値の隠蔽/警戒式差:%s %+v", policy, d)
					}
					if !s.Snapshot().Active || wantNarrow && s.Snapshot().WidthPoints != 20 {
						t.Fatal("P否定/未知で通常の必須保護まで無効化")
					}
				}
			}
		}
	}
}

// TestPartialWholeFloorHalfYenAndImmediateHit は先行損失・q0・予約・床等号を保持します。
//
// 引数: t(*testing.T)は検査器。返り値: ありません。床での架空約定は作りません。
func TestPartialWholeFloorHalfYenAndImmediateHit(t *testing.T) {
	for _, p := range []Policy{W100, B100, W400, P100, P400} {
		for _, side := range []int{1, -1} {
			e := entryFixture(p, side, 2, nil)
			s := mustState(t, e)
			s, d := advanceOK(t, s, inputFixture(e, 1, 105, 1, 0, -9077))
			if d.ActivatedNow || *d.WholeNetYen != 1346 || *d.UnitNetYen != 10423 {
				t.Fatal("残1枚でq0や先行損失を捨てた")
			}
			s, d = advanceOK(t, s, inputFixture(e, 2, 300, 1, 0, -9077))
			if !d.ActivatedNow || s.Snapshot().Entry.InitialQuantity != 2 {
				t.Fatal("全玉H100未起動又はq0縮小")
			}
			base := mustState(t, e)
			base, _ = advanceOK(t, base, inputFixture(e, 1, 105, 2, 0, 0))
			for _, reserved := range []int{0, 1} {
				next, d := advanceOK(t, base, inputFixture(e, 2, 20, 1, reserved, -.5))
				if *d.WholeFloor != 20 || *next.Snapshot().FloorPoints != 20 || next.Snapshot().WholeTargetYen != 1922.5 || !d.FloorHit || d.AllReservedHit != (reserved == 1) || d.EligibleExitQuantity != 1-reserved {
					t.Fatal("半円ceil/全予約/床等号/全玉目標")
				}
			}
			in := inputFixture(e, 2, 0, 1, 0, -.5)
			in.Phase = PreFill
			_, d = advanceOK(t, base, in)
			if !d.FloorHit || d.EligibleExitQuantity != 0 || *d.GainPoints != 0 {
				t.Fatal("pre_fill即要求/床約定の捏造")
			}
			in = inputFixture(e, 3, 0, 0, 0, -154)
			in.Mark = nil
			next, d := advanceOK(t, base, in)
			if !next.Snapshot().Finished || d.WholeFloor != nil || d.WholeNetYen != nil || d.EligibleExitQuantity != 0 {
				t.Fatal("残0での除算/架空評価")
			}
		}
	}
	if ceil5(-5.01) != -5 || ceilDiv(-523, 500) != -1 || ceilDiv(1001, 500) != 3 {
		t.Fatal("負数ceil")
	}
}

// TestLatchStructureAndNoRelaxation は初P警戒後の幅・床・全玉Lの非緩和を確認します。
//
// 引数: t(*testing.T)は検査器。返り値: ありません。構造床は現在のP警戒と取得後中心だけです。
func TestLatchStructureAndNoRelaxation(t *testing.T) {
	for _, policy := range []Policy{P100, P400} {
		for _, side := range []int{1, -1} {
			e := entryFixture(policy, side, 1, nil)
			s := mustState(t, e)
			pub := publicationFixture(e, 21, True, False, True, pointer(20))
			in := inputFixture(e, 1, 115, 1, 0, 0)
			in.Publication = &pub
			s, d := advanceOK(t, s, in)
			if !d.NarrowedNow || *d.StructuralFloor != 45 || s.Snapshot().WidthPoints != 20 || *s.Snapshot().FloorPoints != 95 {
				t.Fatal("初P警戒/構造床/峰床")
			}
			floor, target := *s.Snapshot().FloorPoints, s.Snapshot().WholeTargetYen
			firstState := s
			old := s.Snapshot()
			pub = publicationFixture(e, 22, False, True, True, pointer(80))
			in = inputFixture(e, 2, 110, 1, 0, 0)
			in.Publication = &pub
			s, d = advanceOK(t, s, in)
			if d.Warning != False || !s.Snapshot().Narrowed || d.NarrowedNow || s.Snapshot().WidthPoints != 80 || *s.Snapshot().FloorPoints < floor || s.Snapshot().WholeTargetYen < target || d.StructuralFloor != nil {
				t.Fatal("ラッチ/現在警戒/幅再拡大と床非緩和を混同")
			}
			in = inputFixture(e, 3, 0, 1, 0, 0)
			in.Mark, in.ResetReason = nil, "欠足"
			next, d := advanceOK(t, s, in)
			if d.Warning != Unknown || d.GainPoints != nil || *next.Snapshot().FloorPoints < floor || !reflect.DeepEqual(old, firstState.Snapshot()) {
				t.Fatal("未知価格を補完")
			}
			copy := next.Snapshot()
			copy.Definition.ATRMultiplier = 999
			if next.Snapshot().Definition.ATRMultiplier == 999 {
				t.Fatal("定義の参照共有")
			}
			beforeEntryPivot := publicationFixture(e, 21, True, True, True, pointer(20))
			beforeEntryPivot.PriorPivot.CenterStart = e.At - 180
			beforeEntryPivot.PriorPivot.CenterEnd = e.At
			beforeEntryPivot.PriorPivot.ConfirmEnd = e.At + 180
			beforeEntryPivot.PriorPivot.PublishedAt = e.At + 180
			in = inputFixture(e, 1, 115, 1, 0, 0)
			in.Publication = &beforeEntryPivot
			_, d = advanceOK(t, mustState(t, e), in)
			if d.StructuralFloor != nil {
				t.Fatal("取得前中心のpivotを構造床へ遡及")
			}
		}
	}
}

// TestRejectionsAndPublicationIdentity は旧同ID復活禁止と不正会計拒否を保持します。
//
// 引数: t(*testing.T)は検査器。返り値: ありません。拒否で過去Stateを変更しません。
func TestRejectionsAndPublicationIdentity(t *testing.T) {
	e := entryFixture(P100, 1, 1, nil)
	s := mustState(t, e)
	pub := publicationFixture(e, 21, True, True, True, pointer(20))
	in := inputFixture(e, 1, 115, 1, 0, 0)
	in.Publication = &pub
	s, _ = advanceOK(t, s, in)
	in = inputFixture(e, 2, 0, 1, 0, 0)
	in.Mark, in.ResetReason = nil, "欠足"
	s, _ = advanceOK(t, s, in)
	in = inputFixture(e, 3, 115, 1, 0, 0)
	in.Publication = &pub
	s, d := advanceOK(t, s, in)
	if s.Snapshot().Latest != nil || d.Warning != Unknown {
		t.Fatal("reset後の同ID公表復活")
	}
	for _, change := range []func(*Input){func(x *Input) { x.Sequence = 3 }, func(x *Input) { x.At = 1 }, func(x *Input) { x.Remaining = 2 }, func(x *Input) { x.Reserved = 2 }, func(x *Input) { x.ClosedNetYen = .5 }, func(x *Input) { x.Mark = pointer(math.NaN()) }, func(x *Input) { x.ClosedNetYen = .1 }, func(x *Input) {
		p := copyValue(pub)
		p.C = False
		x.Publication = &p
	}, func(x *Input) {
		p := publicationFixture(e, 40, True, True, True, nil)
		x.Publication = &p
	}} {
		x := inputFixture(e, 4, 115, 1, 0, 0)
		change(&x)
		before := s.Snapshot()
		if _, _, err := Advance(s, x); err == nil || !reflect.DeepEqual(before, s.Snapshot()) {
			t.Fatal("不正受理又は過去改変")
		}
	}
}
