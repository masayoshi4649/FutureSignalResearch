package profitfloor112

import (
	"fmt"
	"math"
	"reflect"
	"testing"

	prior "github.com/masayoshi4649/SessionTradeExecuter/profitfloor111"
)

// barFixture は同じ場の確定3分足を一つ作ります。
//
// 引数: index(int)、price(float64)は人工ordinalと終値。返り値: ClosedBarは正常公表です。
func barFixture(index int, price float64) ClosedBar {
	return ClosedBar{Scope: Scope{Session: "人工場", Contract: "限月", Start: 0}, ID: fmt.Sprintf("足%d", index), Ordinal: uint64(index), Start: float64((index - 1) * 180), End: float64(index * 180), AvailableAt: float64(index * 180), Known: true, Close: pointer(price)}
}

// TestSharedPublicationBBAndRawContraction はchart111型を無変換で受け全BB値を旧と照合します。
//
// 引数: t(*testing.T)は検査器。返り値: ありません。BB/CをP必須のためにマスクしません。
func TestSharedPublicationBBAndRawContraction(t *testing.T) {
	s, err := NewBBState(Scope{Session: "人工場", Contract: "人工限月", Start: 0})
	if err != nil {
		t.Fatal(err)
	}
	old, err := prior.NewBBState(Scope{Session: "人工場", Contract: "人工限月", Start: 0})
	if err != nil {
		t.Fatal(err)
	}
	var bb BBResult
	for i, price := range contractingFixture() {
		bar := barFixture(i+1, price)
		bar.Scope.Contract = "人工限月"
		var oldResult prior.BBResult
		s, bb, err = AdvanceBB(s, bar, bar.AvailableAt)
		if err != nil {
			t.Fatal(err)
		}
		old, oldResult, err = prior.AdvanceBB(old, prior.ClosedBar{Scope: bar.Scope, ID: bar.ID, Ordinal: bar.Ordinal, Start: bar.Start, End: bar.End, AvailableAt: bar.AvailableAt, Known: bar.Known, Close: copyValue(bar.Close)}, bar.AvailableAt)
		if err != nil || !reflect.DeepEqual(bb, oldResult) {
			t.Fatal("BB全公表値又は母σの旧同体差", err)
		}
	}
	for _, policy := range []Policy{W100, W400, B100, P100, P400} {
		e := entryFixture(policy, 1, 1, nil)
		var pub prior.Publication = Publication{Scope: e.Scope, ID: bb.ID, Ordinal: bb.Ordinal, Start: bb.End - 180, End: bb.End, AvailableAt: bb.AvailableAt, C: False, M: True, V: pointer(30), Close: pointer(1050), BB: &bb}
		in := inputFixture(e, 1, 115, 1, 0, 0)
		in.Publication = &pub
		s, d := advanceOK(t, mustState(t, e), in)
		if d.B != True || d.C != False || d.P != Unknown || s.Snapshot().Latest.BB != nil && s.Snapshot().Latest.BB.Contraction != True || d.NarrowedNow != (policy == B100) {
			t.Fatal("共有型又は生C/B/Pの偽装")
		}
	}
}

// bbPrefix は指定した手製価格だけで純BB窓を進めます。
//
// 引数: t(*testing.T)、prices([]float64)は人工列。返り値: BBState/[]BBResultは各当時結果です。
func bbPrefix(t *testing.T, prices []float64) (BBState, []BBResult) {
	t.Helper()
	s, err := NewBBState(Scope{Session: "人工場", Contract: "限月", Start: 0})
	if err != nil {
		t.Fatal(err)
	}
	out := []BBResult{}
	for i, p := range prices {
		b := barFixture(i+1, p)
		next, r, e := AdvanceBB(s, b, b.AvailableAt)
		if e != nil {
			t.Fatal(e)
		}
		s = next
		out = append(out, r)
	}
	return s, out
}

// contractingFixture は低端の古い値が抜けて幅が連続縮小する人工列を作ります。
//
// 引数: なし。返り値: []float64は22本の手製終値です。
func contractingFixture() []float64 {
	p := []float64{}
	for i := 0; i < 20; i++ {
		p = append(p, 1000+5*float64(i))
	}
	return append(p, 1050, 1050)
}

// TestBBPopulationAndWarmup は20母分散と3幅の成立時点を確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestBBPopulationAndWarmup(t *testing.T) {
	_, out := bbPrefix(t, contractingFixture())
	for i := 0; i < 19; i++ {
		if out[i].Known || out[i].Contraction != Unknown {
			t.Fatal("20本未満を既知化")
		}
	}
	r := out[19]
	if !r.Known || r.WindowBars != 20 || math.Abs(*r.SMA-1047.5) > 1e-9 || math.Abs(*r.Sigma**r.Sigma-831.25) > 1e-8 || r.Contraction != Unknown {
		t.Fatalf("母分散又は助走差:%+v", r)
	}
	if out[20].Contraction != Unknown || out[21].Contraction != True {
		t.Fatal("幅3公表のstrict縮小差")
	}
	constant := []float64{}
	for i := 0; i < 22; i++ {
		constant = append(constant, 1000)
	}
	_, flat := bbPrefix(t, constant)
	if *flat[21].Width != 0 || flat[21].PercentB != nil || flat[21].Contraction != False {
		t.Fatal("ゼロ幅又は等号を収縮と誤認")
	}
}

// TestBBMirrorAndFutureNoninterference は幅の買売鏡像と過去不変を確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestBBMirrorAndFutureNoninterference(t *testing.T) {
	prices := contractingFixture()
	mirrored := make([]float64, len(prices))
	for i, x := range prices {
		mirrored[i] = 3000 - x
	}
	s, a := bbPrefix(t, prices)
	_, b := bbPrefix(t, mirrored)
	for i := range a {
		if a[i].Known != b[i].Known || a[i].Contraction != b[i].Contraction || a[i].Known && (*a[i].Sigma != *b[i].Sigma || *a[i].Width != *b[i].Width) {
			t.Fatal("BB幅の鏡像差")
		}
	}
	before := s.Snapshot()
	bar := barFixture(23, 2000)
	next, r, err := AdvanceBB(s, bar, bar.AvailableAt)
	if err != nil {
		t.Fatal(err)
	}
	r.Width = pointer(999)
	copy := next.Snapshot()
	copy.Width = pointer(888)
	if !reflect.DeepEqual(s.Snapshot(), before) || next.Snapshot().Width == copy.Width {
		t.Fatal("未来追加又はSnapshotで過去が変化")
	}
}

// TestBBCausalityGapsAndIdentity は未来・欠足・未知・同ID変更を分けます。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestBBCausalityGapsAndIdentity(t *testing.T) {
	s, out := bbPrefix(t, contractingFixture())
	last := barFixture(22, 1050)
	same, r, err := AdvanceBB(s, last, last.AvailableAt+1)
	if err != nil || !reflect.DeepEqual(r, out[21]) || !reflect.DeepEqual(same.Snapshot(), s.Snapshot()) {
		t.Fatal("同体再送の冪等性")
	}
	for _, alter := range []func(*ClosedBar, *float64){func(b *ClosedBar, a *float64) { *b.Close += 5 }, func(b *ClosedBar, a *float64) { b.Scope.Contract = "別限月" }, func(b *ClosedBar, a *float64) { *a = b.AvailableAt - 1 }, func(b *ClosedBar, a *float64) { b.AvailableAt = b.End - 1 }, func(b *ClosedBar, a *float64) { b.Known = false }, func(b *ClosedBar, a *float64) { b.Start += 1 }} {
		b := barFixture(23, 1050)
		at := b.AvailableAt
		alter(&b, &at)
		if b.ID == "足23" && b.Close != nil && *b.Close == 1055 {
			b.ID = "足22"
			b.Ordinal = 22
			b.Start = 3780
			b.End = 3960
			b.AvailableAt = 3960
			at = 3960
		}
		before := s.Snapshot()
		_, _, err = AdvanceBB(s, b, at)
		if err == nil || !reflect.DeepEqual(before, s.Snapshot()) {
			t.Fatal("不正BB入力受理又は過去変更")
		}
	}
	gap := barFixture(24, 1050)
	g, r, err := AdvanceBB(s, gap, gap.AvailableAt)
	if err != nil || r.Known || r.WindowBars != 1 || r.ResetReason != "欠足" || r.Contraction != Unknown {
		t.Fatal("欠足に過去BBを継承")
	}
	bad := barFixture(25, 0)
	bad.Known = false
	bad.Close = nil
	_, r, err = AdvanceBB(g, bad, bad.AvailableAt)
	if err != nil || r.WindowBars != 0 || r.Known || r.Width != nil {
		t.Fatal("未知足をゼロ価格へ補完")
	}
}
