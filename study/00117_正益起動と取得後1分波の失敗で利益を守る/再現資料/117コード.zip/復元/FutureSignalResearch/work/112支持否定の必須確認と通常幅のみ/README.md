# 支持否定必須と通常幅拡大を分ける純保護

module：`github.com/masayoshi4649/SessionTradeExecuter/profitfloor112`、Go1.24.2。111純部品から明示派生し、旧停止・Source・Actor・chart111を変更しない。[六政策の設計](初回24条件の設計.md)を実装する。

`NewState(Entry)`、`Advance(State,Input)`、`State.Snapshot()`のAPI形は111と共通。真のPolicyはS0/W100/B100/W400/P100/P400。S0純Stateは作らない。`DeclaredConfigurations()`は六政策×C0/C5×D0/D1の24条件、`DeclaredDefinitions()`は幅・警戒の説明六件。

Snapshotへ追加する`definition`は、version/policy/enabled/threshold_points/normal_width_minimum/atr_multiplier/warning_formula/technical_narrowing。旧W100/B100は、この説明追加だけを除いて全Snapshot/Decisionを旧111と照合する。

Scope/Evidence/Pivot/Publication/BBResult/Truth/Phaseは111公開型へのalias。旧chart111が公表した値をそのまま渡せる。BBの純API NewBBState/AdvanceBB/ClosedBar/BBStateも公開するが、市場側のチャート作成は旧chart111を使い続ける。

実APIと24宣言は停止時の`検査/API.txt`、`検査/宣言設定.json`を参照。新policyを旧policyへ変換したり、C/Bを偽にして警戒を変更したり、ATRを倍にして広幅を偽装しない。

```powershell
python .\検査と停止を記録する.py
```

gofmt/test/vet/build、旧対照の全状態、真の幅/H100、P三値と売買、部分返済・半円ceil・予約・nil価格・残0・床/L非緩和・現在警戒の構造床・BB因果性を人工で確認する。AST差分も実Goパーサーで保存する。市場・Raw・Source/Actor運転・11月09日・未参加仮想利益は使用しない。市場全条件の固定は別途Rootが行う。
