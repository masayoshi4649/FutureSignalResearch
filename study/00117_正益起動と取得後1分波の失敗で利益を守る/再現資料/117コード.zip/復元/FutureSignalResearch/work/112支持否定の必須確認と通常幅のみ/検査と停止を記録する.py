"""112純保護を人工・AST差・旧全状態・実API/宣言で市場前停止する。"""

import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OLD = ROOT / 'work/111全玉利益と収束BBの純保護'
OLD_STOP_SHA = '0042a6dc3f181150609deeca5b2c095c9f553d69fcaab1d833402ae31fdbc2c4'


def digest(path: Path) -> str:
    """機能: 純コードとmetadataだけのSHA256を計算する。

    引数: path(Path)は既存の非市場ファイル。返り値: strは小文字SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reference(path: Path) -> dict:
    """機能: 保存metadataの絶対参照を作る。

    引数: path(Path)は既存ファイル。返り値: dictはpath/sha256/bytes。
    """
    return {'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size}


def execute(command: list[str], environment: dict) -> subprocess.CompletedProcess:
    """機能: 市場を呼ばないGo人工・構文解析・API抽出を実行する。

    引数: command(list[str])とenvironment(dict)は実行条件。
    返り値: CompletedProcessは成功結果。不成功ならRuntimeError。
    """
    result = subprocess.run(command, cwd=HERE, env=environment, capture_output=True, text=True, encoding='utf-8')
    if result.returncode:
        raise RuntimeError(json.dumps({'command': command, 'stdout': result.stdout, 'stderr': result.stderr}, ensure_ascii=False))
    return result


def main() -> None:
    """機能: 旧コードを不変に保ち112純APIと人工を停止する。

    引数: なし。返り値: None。停止/検査が既存の場合は上書きしない。
    """
    target, check = HERE / '停止.json', HERE / '検査'
    assert not target.exists() and not check.exists(), '停止先は新規のみ'
    old_stop = OLD / '停止.json'
    assert digest(old_stop) == OLD_STOP_SHA
    stopped = json.loads(old_stop.read_text(encoding='utf-8'))
    inherited = {**stopped['所有コードSHA256'], str(old_stop): OLD_STOP_SHA}
    assert all(digest(Path(p)) == sha for p, sha in inherited.items()), '旧111現物差'
    code = sorted(list(HERE.rglob('*.go')) + [HERE / 'go.mod', HERE / 'README.md', HERE / '初回24条件の設計.md', Path(__file__).resolve()])
    before = {str(p): digest(p) for p in code}
    comments = 0
    for path in HERE.rglob('*.go'):
        lines = path.read_text(encoding='utf-8').splitlines()
        for i, line in enumerate(lines):
            if not line.startswith('func '):
                continue
            j, docs = i-1, []
            while j >= 0 and lines[j].startswith('//'):
                docs.append(lines[j])
                j -= 1
            text = '\n'.join(docs)
            assert len(docs) >= 3 and '引数:' in text and '返り値:' in text, (path, line)
            comments += 1
    for node in ast.walk(ast.parse(Path(__file__).read_text(encoding='utf-8'))):
        if isinstance(node, ast.FunctionDef):
            doc = ast.get_docstring(node) or ''
            assert '\n' in doc and all(t in doc for t in ('機能', '引数', '返り値')), node.name
    check.mkdir()
    env = dict(os.environ, CGO_ENABLED='0', GOWORK='off', PROFIT112_DECLARATION=str(check / '宣言設定.json'))
    version = execute(['go', 'version'], env).stdout.strip()
    formatted = execute(['gofmt', '-l'] + [str(p) for p in HERE.rglob('*.go')], env)
    assert not formatted.stdout.strip(), '未整形'
    test = execute(['go', 'test', '-json', '-count=1', '-cover', './...'], env)
    (check / '人工テスト.jsonl').write_text(test.stdout, encoding='utf-8', newline='\n')
    parsed = [json.loads(s) for s in test.stdout.splitlines() if s.strip()]
    passed = [p['Test'] for p in parsed if p.get('Action') == 'pass' and p.get('Test') and '/' not in p['Test']]
    assert len(passed) == len(set(passed)) == 11, '主人工数'
    vet = execute(['go', 'vet', './...'], env)
    build = execute(['go', 'build', './...'], env)
    execute(['go', 'run', './cmd/astcheck', '--old', str(OLD), '--current', str(HERE), '--out', str(check / 'AST差分.json')], env)
    ast_result = json.loads((check / 'AST差分.json').read_text(encoding='utf-8'))
    assert ast_result['成功'] and len(ast_result['関数変更']) == 4
    api = execute(['go', 'doc', '-all', '.'], env)
    (check / 'API.txt').write_text(api.stdout, encoding='utf-8', newline='\n')
    declaration = json.loads((check / '宣言設定.json').read_text(encoding='utf-8'))
    policies = ['S0', 'W100', 'B100', 'W400', 'P100', 'P400']
    assert [c['policy'] for c in declaration['configurations'][::4]] == policies
    assert [d['policy'] for d in declaration['definitions']] == policies
    assert all(d['threshold_points'] == 100 for d in declaration['definitions'][1:])
    assert before == {p: digest(Path(p)) for p in before}, '所有前後差'
    assert all(digest(Path(p)) == sha for p, sha in inherited.items()), '旧111前後差'
    artificial = {'成功': True, '市場実行': False, 'Source又はActor実行': False, '所有前': before,
                  '所有後': before, '自己コード前後不変': True, '主人工': len(passed), '人工名': passed,
                  '関数コメント確認数': comments, 'Go版': version, 'gofmt未整形': 0,
                  'test': {'終了': 0, 'ログ': reference(check / '人工テスト.jsonl')},
                  'vet': {'終了': vet.returncode, 'stderr': vet.stderr}, 'build': {'終了': build.returncode, 'stderr': build.stderr},
                  '旧全State同体': 'W100/B100×売買×C0/C5×ATR未知/80/125.5×初期1/2/10の72人工系列。追加definitionだけ除外。全段階SnapshotとDecisionを比較。',
                  '旧全State例外': ['Snapshot.definitionという新しい説明メタのみ。政策/ATR/C/M/P/B/R/n/q0/床/利益を除外しない。'],
                  'AST': reference(check / 'AST差分.json'), 'API': reference(check / 'API.txt'), '実宣言': reference(check / '宣言設定.json')}
    (check / '人工確認.json').write_text(json.dumps(artificial, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    stop = {'成功': True, '停止': True, 'trial': 112, 'module': 'github.com/masayoshi4649/SessionTradeExecuter/profitfloor112',
            'package': 'profitfloor112', 'UTC': datetime.now(timezone.utc).isoformat(), 'Go版': version,
            '所有コードSHA256': before, '再用コードSHA256': inherited, '自己コード前後不変': True,
            '旧111変更': False, '旧111全所有前後不変': True, '主人工': len(passed),
            '人工確認': reference(check / '人工確認.json'), '仕様': reference(HERE / '初回24条件の設計.md'),
            '実API': reference(check / 'API.txt'), '実宣言': reference(check / '宣言設定.json'),
            'AST差分': reference(check / 'AST差分.json'), '派生元': reference(old_stop),
            '公表型互換': 'Scope/Evidence/Pivot/Publication/BBResult/Truth/Phaseはprofitfloor111型alias。生C/M/P/Bは無変換。',
            '市場実行': False, 'Source実行': False, 'Actor実行': False, 'Raw/価格/11月09日本文読取': False,
            '未参加/退出後仮想利益評価': False, '範囲': '112の純演算・API停止。全金融条件のRoot固定前であり、市場成績ではない。'}
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(stop, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'成功': True, '停止': reference(target), '主人工': len(passed), 'API': stop['実API'], '宣言': stop['実宣言']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
