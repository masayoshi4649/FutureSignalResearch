package profitfloor112

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"reflect"
)

type ClosedBar struct {
	Scope       Scope    `json:"scope"`
	ID          string   `json:"id"`
	Ordinal     uint64   `json:"ordinal"`
	Start       float64  `json:"start"`
	End         float64  `json:"end"`
	AvailableAt float64  `json:"available_at"`
	Known       bool     `json:"known"`
	Close       *float64 `json:"close"`
}

type BBState struct {
	scope       Scope
	initialized bool
	last        *ClosedBar
	result      BBResult
	bars        []ClosedBar
	widths      []float64
}

// NewBBState は当場の確定3分BB窓を空から始めます。
//
// 引数: scope(Scope)は場・限月・開始。返り値: BBState/errorは純窓又は不正です。
func NewBBState(scope Scope) (BBState, error) {
	if !validScope(scope) {
		return BBState{}, fmt.Errorf("BB場が不正")
	}
	return BBState{scope: scope, initialized: true, bars: []ClosedBar{}, widths: []float64{}}, nil
}

// Snapshot は最後の公表結果を独立した値で返します。
//
// 引数: receiver(BBState)は純窓。返り値: BBResultは参照共有のない保存値です。
func (s BBState) Snapshot() BBResult { return copyValue(s.result) }

// validateBBResult は公開BB値と既知性の結合を確認します。
//
// 引数: r(BBResult)は純公開値。返り値: errorは欠損・非有限・計算の不整合です。
func validateBBResult(r BBResult) error {
	if !validScope(r.Scope) || r.ID == "" || r.Ordinal < 1 || !finite(r.End, r.AvailableAt, r.DeliveredAt) || r.End <= r.Scope.Start || r.AvailableAt < r.End || r.DeliveredAt < r.AvailableAt || r.WindowBars < 0 || r.WindowBars > 20 || r.Contraction > True {
		return fmt.Errorf("BB公表の境界又は三値が不正")
	}
	if !r.Known {
		if r.SMA != nil || r.Sigma != nil || r.Upper != nil || r.Lower != nil || r.Width != nil || r.BandWidth != nil || r.PercentB != nil || r.Contraction != Unknown {
			return fmt.Errorf("BB未知へ数値又は支持を補完")
		}
		return nil
	}
	if r.WindowBars != 20 || r.SMA == nil || r.Sigma == nil || r.Upper == nil || r.Lower == nil || r.Width == nil || r.BandWidth == nil || !finite(*r.SMA, *r.Sigma, *r.Upper, *r.Lower, *r.Width, *r.BandWidth) || *r.SMA <= 0 || *r.Sigma < 0 || *r.Width < 0 {
		return fmt.Errorf("BB20の既知値が不正")
	}
	if *r.Width != 4**r.Sigma || *r.Upper != *r.SMA+2**r.Sigma || *r.Lower != *r.SMA-2**r.Sigma || *r.BandWidth != *r.Width / *r.SMA {
		return fmt.Errorf("BB母標準偏差と上下幅の算術差")
	}
	if *r.Width == 0 && r.PercentB != nil || r.PercentB != nil && !finite(*r.PercentB) {
		return fmt.Errorf("BBゼロ幅の除算又は非有限の帯内位置")
	}
	decoded, err := hex.DecodeString(r.WindowSHA)
	if err != nil || len(decoded) != 32 {
		return fmt.Errorf("BB窓の出典SHAが不正")
	}
	return nil
}

// AdvanceBB は当時可用の確定3分足だけでBB20と幅3本収縮を公表します。
//
// 引数: state(BBState)、bar(ClosedBar)、asOf(float64)は旧窓・新確定足・利用時計。
// 返り値: BBState/BBResult/errorは新窓・公表又は不正です。未来追加は過去窓を変更しません。
func AdvanceBB(state BBState, bar ClosedBar, asOf float64) (BBState, BBResult, error) {
	if !state.initialized || bar.Scope != state.scope || bar.ID == "" || bar.Ordinal < 1 || !finite(bar.Start, bar.End, bar.AvailableAt, asOf) || bar.Start < state.scope.Start || bar.End != bar.Start+180 || math.Mod(bar.Start-state.scope.Start, 180) != 0 || bar.AvailableAt < bar.End || bar.AvailableAt > asOf {
		return state, BBResult{}, fmt.Errorf("BB足の場・3分確定・可用時計が不正")
	}
	if state.last != nil && asOf < state.result.DeliveredAt {
		return state, BBResult{}, fmt.Errorf("BB利用時計の後退")
	}
	if bar.Known && (bar.Close == nil || !finite(*bar.Close) || *bar.Close <= 0 || *bar.Close > 1e9) || !bar.Known && bar.Close != nil {
		return state, BBResult{}, fmt.Errorf("BB終値と既知性が不正")
	}
	if state.last != nil && bar.ID == state.last.ID {
		if !reflect.DeepEqual(bar, *state.last) {
			return state, BBResult{}, fmt.Errorf("BB同ID確定足の値変更")
		}
		return state, copyValue(state.result), nil
	}
	if state.last != nil && (bar.End <= state.last.End || bar.Ordinal <= state.last.Ordinal || bar.End == state.last.End+180 && bar.Ordinal != state.last.Ordinal+1) {
		return state, BBResult{}, fmt.Errorf("BB足の後退又は連続ordinal差")
	}
	s := state
	s.bars = copyValue(state.bars)
	s.widths = append([]float64{}, state.widths...)
	s.last = copyValue(state.last)
	r := BBResult{Scope: bar.Scope, ID: bar.ID, Ordinal: bar.Ordinal, End: bar.End, AvailableAt: bar.AvailableAt, DeliveredAt: asOf}
	if s.last != nil && bar.End != s.last.End+180 {
		s.bars = []ClosedBar{}
		s.widths = []float64{}
		r.ResetReason = "欠足"
	}
	s.last = copyValue(&bar)
	if !bar.Known {
		s.bars = []ClosedBar{}
		s.widths = []float64{}
		r.ResetReason = "不良又は未知の確定足"
	} else {
		s.bars = append(s.bars, copyValue(bar))
		if len(s.bars) > 20 {
			s.bars = append([]ClosedBar{}, s.bars[len(s.bars)-20:]...)
		}
	}
	r.WindowBars = len(s.bars)
	if len(s.bars) == 20 {
		mean, pairs := 0.0, 0.0
		for _, b := range s.bars {
			mean += *b.Close / 20
		}
		for i := 0; i < 20; i++ {
			for j := i + 1; j < 20; j++ {
				d := *s.bars[i].Close - *s.bars[j].Close
				pairs += d * d
			}
		}
		variance := pairs / 400
		sigma := math.Sqrt(variance)
		width := 4 * sigma
		if !finite(mean, variance, sigma, width) || mean <= 0 {
			return state, BBResult{}, fmt.Errorf("BB母分散が非有限")
		}
		r.Known = true
		r.SMA = pointer(mean)
		r.Sigma = pointer(sigma)
		r.Upper = pointer(mean + 2*sigma)
		r.Lower = pointer(mean - 2*sigma)
		r.Width = pointer(width)
		r.BandWidth = pointer(width / mean)
		if width > 0 {
			r.PercentB = pointer((*bar.Close - *r.Lower) / width)
		}
		s.widths = append(s.widths, width)
		if len(s.widths) > 3 {
			s.widths = append([]float64{}, s.widths[len(s.widths)-3:]...)
		}
		if len(s.widths) == 3 {
			r.Contraction = False
			if s.widths[2] < s.widths[1] && s.widths[1] < s.widths[0] {
				r.Contraction = True
			}
		}
		raw, err := json.Marshal(s.bars)
		if err != nil {
			return state, BBResult{}, err
		}
		sum := sha256.Sum256(raw)
		r.WindowSHA = hex.EncodeToString(sum[:])
	}
	if err := validateBBResult(r); err != nil {
		return state, BBResult{}, err
	}
	s.result = copyValue(r)
	return s, copyValue(r), nil
}
