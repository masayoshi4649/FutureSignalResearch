"""保存済みOHLCを所与として、指標と参照足の整合だけを検算する。"""

from copy import deepcopy
from decimal import Decimal, localcontext
import importlib.util
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
PRIOR = HERE.parent / "117短期足と警戒を人工で独立検算する"


def module(name, path):
    """
    機能: SHA認証済みのPython純実装を読む。
    引数: name(str)、path(Path)は独立Pythonの識別と位置。
    返り値: moduleはGoを呼ばない計算部品。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    instance = importlib.util.module_from_spec(spec)
    sys.modules[name] = instance
    spec.loader.exec_module(instance)
    return instance


def dependencies():
    """
    機能: 再用する人工検算のコードと成功証拠の期待SHAを返す。
    引数: なし。
    返り値: dict[Path,str]は変更しない依存4件。
    """
    return {
        PRIOR / "bankを再形成する.py": "2a0a454cbce16f9137d68dbacac4625af3199f5885827bdefb025550c2c12209",
        PRIOR / "警戒を再形成する.py": "69d533e6400902456896b87af65f45b271de192f13d371a706d24b3a26fcb3ab",
        PRIOR / "検算する.py": "561f97417b00e8a0d7f1465d2c4e9070bc0c63face18b711a4d5deae58425337",
        PRIOR / "bankと状態確認_最終/確認.json": "2134caf83c7e47bbcf06be2211f1481c3f1111f977be7ff1d668b3634e1189ac",
    }


def parts():
    """
    機能: 指標・三値・比較器を既検算Pythonから取得する。
    引数: なし。
    返り値: tuple[module,module,type]はNumbers/inspect/Comparisonの所在。
    """
    bank = module("saved_bank117", PRIOR / "bankを再形成する.py")
    state = module("saved_state117", PRIOR / "警戒を再形成する.py")
    checker = module("saved_comparison117", PRIOR / "検算する.py")
    return bank, state, checker.Comparison


def minimal_quote(quote):
    """
    機能: Actual側BBO付きquoteから短期bankの共通4fieldを選ぶ。
    引数: quote(dict)は実際に保存された原行。
    返り値: dictは時刻/Index/物理行/Last。
    """
    return {key: quote[key] for key in ("time", "index", "source_line", "last")}


def bar_epoch(bar):
    """
    機能: bankが保存したIDの末尾Epochを整数として読む。
    引数: bar(dict)は保存1分足。
    返り値: intは明示Epoch。不明なIDを推測しない。
    """
    result = int(bar["id"].rsplit("/", 1)[1])
    assert result >= 0
    return result


def numeric_copy(bar, numbers):
    """
    機能: 保存OHLCを固定したまま数値fieldだけ独立再形成する。
    引数: bar(dict)、numbers(Numbers)は足と直前確定状態。
    返り値: dictは独立のTR/前ATR/technicalを含む足。
    """
    expected = deepcopy(bar)
    if numbers.origin is None:
        numbers.origin = Decimal(str(bar["open"]))
    numbers.calculate(expected, bar["complete"])
    return expected


def same_numeric(comparison, expected, saved, location):
    """
    機能: 指標3fieldを固定許容差1e-9で照合する。
    引数: comparison(Comparison)、expected/saved(dict)、location(str)は比較器・足・所在。
    返り値: None。Knownは厳密、演算値のみ絶対差を許容する。
    """
    for key in ("tr", "previous_atr", "technical"):
        comparison.compare(expected[key], saved[key], location + "." + key)


# ----------------------------------------
def inspect_native(native, expected_session):
    """
    機能: 一つの保存Nativeで確定OHLC所与の数値とH0M参照を照合する。
    引数: native(dict)、expected_session(str)は許可済み保存値と対象場。
    返り値: dictは指標・公表参照・冷間/欠足/arm/警戒/幅/実要求の小集計。
    """
    implementation, state_module, comparison_type = parts()
    with localcontext() as context:
        context.prec = 50
        actual = native["actual"]
        assert native["trial"] == 117 and actual["trial"] == 117 and actual["complete"] is True
        assert actual["scope"]["session"]["id"] == expected_session
        scope = actual["final_short_bank"]["scope"]
        assert scope["session"] == expected_session and scope["contract"] == actual["scope"]["contract"]
        assert scope["start"] == actual["scope"]["session"]["start"]
        comparison = comparison_type()
        numbers, epoch, continuous, longest = implementation.Numbers(), 0, 0, 0
        bars, calculated, checkpoints = {}, {}, [(-1, deepcopy(numbers))]
        gaps = actual["short_gaps"]
        gap_by_index = {gap["at"]["index"]: gap for gap in gaps}
        assert len(gap_by_index) == len(gaps)
        consumed_gaps, known_first = set(), {}
        previous = None
        recent = []
        for index, bar in enumerate(actual["short_closed"]):
            assert bar["id"] not in bars and bar["complete"] is True and bar["end"] - bar["start"] == 60
            assert bar_epoch(bar) == epoch
            q = bar["published"]
            assert bar["open"] == bar["first"]["last"] and bar["close"] == bar["last"]["last"]
            assert bar["low"] <= min(bar["open"], bar["close"]) <= max(bar["open"], bar["close"]) <= bar["high"]
            assert bar["first"]["time"] >= bar["start"] and bar["last"]["time"] < bar["end"]
            assert q["time"] >= bar["end"] and q["index"] > bar["last"]["index"] and q["source_line"] > bar["last"]["source_line"]
            if previous is not None:
                assert q["index"] > previous["published"]["index"]
                assert bar["start"] >= previous["end"]
            if recent:
                assert bar["start"] == recent[-1]["end"]
            expected = numeric_copy(bar, numbers)
            same_numeric(comparison, expected, bar, f"closed[{index}]")
            bars[bar["id"]], calculated[bar["id"]] = bar, expected
            recent = (recent + [expected])[-4:]
            continuous += 1
            longest = max(longest, continuous)
            for key in ("centered_ema12", "centered_ema26", "signal", "histogram", "atr"):
                if expected["technical"][key]["known"] and (epoch, key) not in known_first:
                    known_first[(epoch, key)] = {"epoch": epoch, "指標": key, "確定本数": numbers.bars, "公開原行": q}
            if q["index"] in gap_by_index:
                gap = gap_by_index[q["index"]]
                assert gap["at"] == q and gap["from_end"] == bar["end"] and gap["to_start"] > bar["end"]
                assert gap["missing_minutes"] == (gap["to_start"] - bar["end"]) / 60
                consumed_gaps.add(q["index"])
                numbers, recent = implementation.Numbers(), []
                continuous, epoch = 0, epoch + 1
            checkpoints.append((q["index"], deepcopy(numbers)))
            previous = bar
        assert consumed_gaps == set(gap_by_index), "足確定に結合しないgap"
        final = actual["final_short_bank"]
        assert final["epoch"] == epoch and final["reset_count"] == len(gaps)
        assert final["total_closed_bars"] == len(bars) and final["closed_bars"] == numbers.bars
        assert actual["counts"]["short_closed"] == len(bars) and actual["counts"]["short_gaps"] == len(gaps)
        assert actual["counts"]["short_delivery_rows"] == actual["counts"]["rows"]
        comparison.compare(numbers.committed, final["committed"], "final.committed")
        comparison.compare(recent, final["recent_closed"], "final.recent_closed")
        assert final["cold"] == (not (numbers.committed["histogram"]["known"] and numbers.committed["atr"]["known"]))
        if recent:
            comparison.compare(recent[-1], final["latest_closed"], "final.latest_closed")
        else:
            assert "latest_closed" not in final
        if final["have_quote"]:
            prefix = final["prefix"]
            assert not prefix["complete"] and prefix["last"] == final["quote"] and prefix["published"] == final["quote"]
            assert prefix["start"] <= final["quote"]["time"] < prefix["end"] and bar_epoch(prefix) == epoch
            prefix_expected = numeric_copy(prefix, deepcopy(numbers))
            same_numeric(comparison, prefix_expected, prefix, "final.prefix")
        else:
            assert not bars and "prefix" not in final
        if "closed_now" in final:
            assert bars[final["closed_now"]["id"]] == final["closed_now"] and final["closed_now"]["published"] == final["quote"]
        books = []
        for config in actual["configurations"]:
            if config["policy"] != "H0M":
                continue
            key = f"H0M_C{config['slip_pts']}_D{config['delay_seconds']}"
            book = actual["books"][key]
            assert book["config"] == config
            stats = {"key": key, "実建玉数": len(book["positions"]), "arm保存玉数": 0, "警戒保存玉数": 0, "実幅適用玉数": 0, "保護実要求数": 0, "保護実約定数": 0, "参照確定足照合数": 0}
            for position in book["positions"]:
                audit = position["shortwave117"]
                entry = audit["initial"]["entry"]
                assert entry["position_id"] == position["id"] and entry["price"] == position["entry_price"] and entry["side"] == position["side"]
                assert entry["fill_quote"] == minimal_quote(position["entry_quote"])
                for name, witness_name in (("first_arm", "first_arm"), ("first_warning", "first_warning")):
                    point = audit.get(name)
                    if point is None:
                        continue
                    stats["arm保存玉数" if name == "first_arm" else "警戒保存玉数"] += 1
                    view = point["snapshot"]
                    w = view[witness_name]
                    assert minimal_quote(point["quote"]) == w["at"] and point["phase"] == w["phase"]
                    assert point["bank_sha256"] == w["bank_sha256"] and w["active"] is True and w["remaining"] > 0
                    support, breakout = w["support"], w["breakout"]
                    for candidate_bar in (support["left"], support["center"], support["right"], breakout):
                        assert candidate_bar == bars[candidate_bar["id"]], "Witness確定足と保存公表の全値差"
                        assert candidate_bar["published"]["index"] <= w["at"]["index"] and candidate_bar["published"]["time"] <= w["at"]["time"]
                        assert state_module.acquired_bar(candidate_bar, entry), "取得前足の支持使用"
                        stats["参照確定足照合数"] += 1
                    independently_supported = state_module.support_candidate([calculated[b["id"]] for b in (support["left"], support["center"], support["right"])], entry, support["confirmed"])
                    comparison.compare(independently_supported, support, key + "." + position["id"] + "." + name + ".support")
                    assert state_module.can_arm(independently_supported, calculated[breakout["id"]], entry, breakout["published"])
                    comparison.compare(calculated[breakout["id"]]["previous_atr"], w["a_arm"], key + "." + name + ".A_arm")
                    if name == "first_arm":
                        assert breakout["published"] == w["at"] and point["decision"]["armed_now"] is True
                    prefix_w = w["prefix"]
                    assert prefix_w["published"] == w["at"] and prefix_w["last"] == w["at"]
                    before = next(deepcopy(n) for i, n in reversed(checkpoints) if i <= w["at"]["index"])
                    independent_prefix = numeric_copy(prefix_w, before)
                    same_numeric(comparison, independent_prefix, prefix_w, key + "." + name + ".prefix")
                    if name == "first_warning":
                        vote_view = {"entry": entry, "armed": True, "armed_support": independently_supported, "narrowed": True, "target_width_points": w["target_width_points"]}
                        votes = state_module.inspect(vote_view, {"prefix": independent_prefix})
                        for vote in ("s", "m", "v", "warning"):
                            assert votes[vote] == w[vote]
                        assert w["warning"] == state_module.TRUE and point["decision"]["narrowed_now"] is True
                        comparison.compare(votes["values"], w["values"], key + ".first_warning.values")
                        from decimal import ROUND_CEILING
                        width = 5 * (max(Decimal(5), min(entry["normal_width_points"], calculated[breakout["id"]]["previous_atr"]["value"])) / 5).to_integral_value(rounding=ROUND_CEILING)
                        assert width == w["target_width_points"] == audit["final_state"]["target_width_points"]
                stats["実幅適用玉数"] += int(position["protection117"]["final_state"]["narrowed"])
            requests = {order["id"] for order in book["orders"] if order["kind"] == "exit" and order.get("protection_point") is not None}
            stats["保護実要求数"] = len(requests)
            stats["保護実約定数"] = sum(fill["order_id"] in requests for fill in book["fills"])
            books.append(stats)
        assert len(books) == 4 and len({item["key"] for item in books}) == 4
        return {"session": expected_session, "成功": True, "所与の確定OHLC数": len(bars), "gap数": len(gaps), "最長連続確定足数": longest, "最終cold": final["cold"], "最終Epoch": epoch, "Epoch別の初回既知": list(known_first.values()), "H0M四費用": books, "比較scalar数": comparison.count, "指標数値比較数": comparison.numeric, "指標最大絶対差": str(comparison.maximum), "最大差所在": comparison.maximum_path, "OHLCを原板から独立検証": False, "全Raw発生漏れ最初性": False, "損益再計算": False}
