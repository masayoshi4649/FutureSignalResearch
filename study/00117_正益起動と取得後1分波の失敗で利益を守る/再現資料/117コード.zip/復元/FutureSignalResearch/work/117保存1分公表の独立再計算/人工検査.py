"""自然Nativeを読まず、人工Native形と改変拒否を検査する。"""

import argparse
from copy import deepcopy
from decimal import Decimal
import json
from pathlib import Path
import sys

sys.stdout.reconfigure(encoding="utf-8")
HERE = Path(__file__).resolve().parent


def load_cli():
    """
    機能: 自所有CLIをGoなしで読み込む。
    引数: なし。
    返り値: moduleは入力ゲートとSHA関数を持つPython。
    """
    import importlib.util
    spec = importlib.util.spec_from_file_location("publication_cli117", HERE / "検算する.py")
    cli = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = cli
    spec.loader.exec_module(cli)
    return cli


def make_native(case, code):
    """
    機能: 既検算手製quote列から保存公表とWitnessを持つ人工Native形を作る。
    引数: case(dict)、code(module)は手製系列と自検査器。
    返り値: dictは市場falseの人工Native。
    """
    implementation, _, _ = code.parts()
    bank = implementation.Bank(case["entry"]["scope"])
    snapshots = [bank.step(q) for q in case["quotes"]]
    known_go_bars = {}
    for step in case["steps"]:
        b = step["input"]["bank_snapshot"]
        for bar in b["recent_closed"] + [b[k] for k in ("latest_closed", "closed_now") if k in b]:
            known_go_bars[bar["id"]] = deepcopy(bar)
    closed, gaps = [], []
    for snapshot in snapshots:
        if "closed_now" in snapshot:
            b = snapshot["closed_now"]
            closed.append(known_go_bars.get(b["id"], b))
        if "gap" in snapshot:
            gaps.append(snapshot["gap"])
    configurations = [{"policy": p, "slip_pts": c, "delay_seconds": d} for p in ("S0", "W100", "P100", "H0E", "H0M") for c in (0, 5) for d in (0, 1)]
    books = {}
    for cfg in configurations:
        key = f"{cfg['policy']}_C{cfg['slip_pts']}_D{cfg['delay_seconds']}"
        book = {"config": cfg, "positions": [], "orders": [], "fills": []}
        books[key] = book
        if cfg["policy"] != "H0M":
            continue
        final_state = deepcopy(case["steps"][-1]["after_snapshot"])
        audit = {"initial": deepcopy(case["initial_snapshot"]), "final_state": final_state}
        for source, target in (("armed_now", "first_arm"), ("narrowed_now", "first_warning")):
            s = next(s for s in case["steps"] if s["decision"][source])
            q = s["input"]["bank_snapshot"]["quote"]
            audit[target] = {"quote": deepcopy(q), "phase": s["input"]["phase"], "bank_sha256": s["input"]["bank_snapshot"]["sha256"], "snapshot": deepcopy(s["after_snapshot"]), "decision": deepcopy(s["decision"])}
        entry = case["entry"]
        book["positions"] = [{"id": entry["position_id"], "entry_price": entry["price"], "side": entry["side"], "entry_quote": entry["fill_quote"], "shortwave117": audit, "protection117": {"final_state": {"narrowed": True}}}]
        book["orders"] = [{"id": "手製予約", "kind": "exit", "protection_point": {"人工": True}}]
    return {"trial": 117, "人工": True, "市場": False, "actual": {"trial": 117, "complete": True, "scope": {"session": {"id": case["entry"]["scope"]["session"], "start": case["entry"]["scope"]["start"]}, "contract": case["entry"]["scope"]["contract"]}, "short_closed": closed, "short_gaps": gaps, "final_short_bank": deepcopy(case["steps"][-1]["input"]["bank_snapshot"]), "counts": {"rows": len(case["quotes"]), "short_delivery_rows": len(case["quotes"]), "short_closed": len(closed), "short_gaps": len(gaps)}, "configurations": configurations, "books": books}}


def main():
    """
    機能: 2人工正例と指標/時計/支持/条件の破壊拒否を証拠化する。
    引数: CLI --out(Path)は自所有の新規検査先。
    返り値: None。自然金融・Go・原板へ接続しない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    out = args.out.absolute()
    assert out.is_relative_to(HERE) and not out.exists()
    cli = load_cli()
    code = cli.load_code()
    refs = code.dependencies()
    series_path = code.PRIOR.parent / "117原行と暫定1分の複合保護/人工_独立用/系列.json"
    refs[series_path] = "923be91b1f7b2c3ea6eb3d3e58ded632c8f7846320ab98f64c36d7704c948b3c"
    for path, expected in refs.items():
        assert cli.sha(path) == expected
    own = {str(path): cli.sha(path) for path in sorted(HERE.glob("*.py"))}
    before = {str(path): cli.sha(path) for path in refs}
    series = json.loads(series_path.read_text(encoding="utf-8"), parse_float=Decimal)
    positives, natives = [], []
    for case in series["cases"]:
        native = make_native(case, code)
        positives.append(code.inspect_native(native, case["entry"]["scope"]["session"]))
        natives.append(native)
    refused = []
    for kind in ("EMA演算値", "既知旗", "前ATR", "欠足Epoch", "確定公表時刻", "arm出典足", "warning三値", "固定狭幅", "末尾暫定値"):
        damaged = deepcopy(natives[0])
        a = damaged["actual"]
        if kind == "EMA演算値":
            a["short_closed"][30]["technical"]["ema12"]["value"] += 1
        elif kind == "既知旗":
            a["short_closed"][10]["technical"]["centered_ema12"]["known"] = True
        elif kind == "前ATR":
            a["short_closed"][30]["previous_atr"]["value"] += 1
        elif kind == "欠足Epoch":
            a["final_short_bank"]["epoch"] += 1
        elif kind == "確定公表時刻":
            a["short_closed"][0]["published"]["time"] = a["short_closed"][0]["end"] - 1
        elif kind == "arm出典足":
            a["books"]["H0M_C0_D0"]["positions"][0]["shortwave117"]["first_arm"]["snapshot"]["first_arm"]["support"]["left"]["id"] = "存在しない確定足"
        elif kind == "warning三値":
            a["books"]["H0M_C0_D0"]["positions"][0]["shortwave117"]["first_warning"]["snapshot"]["first_warning"]["warning"] = 1
        elif kind == "固定狭幅":
            a["books"]["H0M_C0_D0"]["positions"][0]["shortwave117"]["final_state"]["target_width_points"] += 5
        elif kind == "末尾暫定値":
            a["final_short_bank"]["prefix"]["technical"]["origin"]["value"] += 1
        try:
            code.inspect_native(damaged, damaged["actual"]["scope"]["session"]["id"])
        except (AssertionError, KeyError, ValueError):
            refused.append(kind)
        else:
            raise AssertionError("破壊を受理:" + kind)
    configurations = natives[0]["actual"]["configurations"]
    condition = {"version": 1, "trial": 117, "fixed": True, "source_trial": 111, "chart_seed_mode": "cold_each_session", "entry_grid_seconds": None, "extra_opening_quiet_seconds": 0, "actual_configurations": configurations}
    completion = {"version": 1, "trial": 117, "stage": "first2", "success": True, "condition_sha256": cli.F1_SHA, "sessions": 2, "books": 40, "reused_sessions": 0, "replayed_sessions": 2, "original_methods": 3, "reference112_comparisons": 24, "all_reference112_equal": True, "all_source111_equal": True, "unchanged": True, "before": {"人工": "同条件"}, "after": {"人工": "同条件"}, "results": [{"session": sid, "books": 20, "S0_comparisons": 4, "S0_equal": True, "complete": True, "open_quantity": 0, "pending_quantity": 0, "reference112_comparisons": 12, "reference112_equal": True, "source111_equal": True, "native": {"path": str(out / (sid + ".Native.json.gz")), "sha256": "1" * 64}} for sid in cli.SCENES]}
    assert len(cli.validate_metadata(condition, completion, cli.F1_SHA)) == 2
    metadata_refused = []
    for key, wrong in (("trial", 116), ("stage", "full70"), ("condition_sha256", "別F1"), ("books", 39), ("success", False)):
        damaged = deepcopy(completion)
        damaged[key] = wrong
        try:
            cli.validate_metadata(condition, damaged, cli.F1_SHA)
        except AssertionError:
            metadata_refused.append(key)
        else:
            raise AssertionError("別metadataを受理:" + key)
    # ----------------------------------------
    # 不許可要求はRoot実metadataへ到達する前に拒否する。実先頭2の読取許可はここでは発行しない。
    out.mkdir()
    requests_refused = []
    valid_shape = {"version": 1, "trial": 117, "fixed": True, "authorized": True, "source": "saved_closed_ohlc_first2_only", "Raw読取許可": False, "金融再実行": False, "refs": {"condition": {"path": str(cli.F1_PATH), "sha256": cli.F1_SHA}, "financial_completion": {"path": str(cli.COMPLETION_PATH), "sha256": cli.COMPLETION_SHA}, "checker": {"path": str(out / "未生成検査.json"), "sha256": "1" * 64}}}
    old_read = cli.read_ref
    for key, wrong in (("fixed", False), ("authorized", False), ("source", "他期間"), ("Raw読取許可", True), ("金融再実行", True), ("別F1", True)):
        bad = deepcopy(valid_shape)
        if key == "別F1":
            bad["refs"]["condition"]["sha256"] = "0" * 64
        else:
            bad[key] = wrong
        path = out / ("拒否_" + key + ".json")
        path.write_text(json.dumps(bad, ensure_ascii=False), encoding="utf-8")
        opened = []

        def request_only(ref, before_map):
            """
            機能: 拒否人工で、自分が書いた不許可要求以外の読取を検出する。
            引数: ref(dict)、before_map(dict)は要求参照と指紋集合。
            返り値: dictは人工要求。別入力への到達はRuntimeError。
            """
            if ref["path"] != str(path):
                raise RuntimeError("不許可要求が実metadataへ到達")
            opened.append(ref["path"])
            return old_read(ref, before_map)

        cli.read_ref = request_only
        try:
            cli.prepare({"path": str(path), "sha256": cli.sha(path)})
        except AssertionError:
            assert opened == [str(path)]
            requests_refused.append(key)
        else:
            raise AssertionError("不許可要求を受理:" + key)
        finally:
            cli.read_ref = old_read
    after = {path: cli.sha(Path(path)) for path in before}
    assert before == after and own == {str(path): cli.sha(path) for path in sorted(HERE.glob("*.py"))}
    artificial = {"成功": True, "人工のみ": True, "自然Native読取": 0, "Go実行": False, "正例": positives, "破壊拒否": refused, "metadata拒否": metadata_refused, "実metadata前の不許可要求拒否": requests_refused, "入力SHA256": before, "後SHA256": after, "前後不変": True}
    artificial_path = out / "人工の確認.json"
    artificial_path.write_text(json.dumps(artificial, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    proof = {"成功": True, "試行": 117, "人工のみ": True, "正式停止": False, "所有コードSHA256": own, "依存SHA256": {str(path): expected for path, expected in code.dependencies().items()}, "人工": {"path": str(artificial_path), "sha256": cli.sha(artificial_path)}, "許可範囲": "Root固定first2の2Nativeのみ。metadata-onlyはNative指紋も走査しない。OHLC所与の指標整合であり原板検証/全Raw最初性ではない"}
    proof_path = out / "準備の確認.json"
    proof_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    template = {"version": 1, "trial": 117, "fixed": False, "authorized": False, "source": "saved_closed_ohlc_first2_only", "Raw読取許可": False, "金融再実行": False, "refs": {"condition": {"path": str(cli.F1_PATH), "sha256": cli.F1_SHA}, "financial_completion": {"path": str(cli.COMPLETION_PATH), "sha256": cli.COMPLETION_SHA}, "checker": {"path": str(proof_path), "sha256": cli.sha(proof_path)}}}
    (out / "Root要求の素材.json").write_text(json.dumps(template, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "準備": str(proof_path), "sha256": cli.sha(proof_path), "人工": cli.sha(artificial_path), "破壊拒否": len(refused), "metadata拒否": len(metadata_refused)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
