// 94の手製API通知器具だけの同体派生です。FAR自然生成や市場実績ではありません。
package supportcomparison112

import (
	"encoding/json"
	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	protect "github.com/masayoshi4649/SessionTradeExecuter/miniprotect"
	"math"
	"testing"
	"time"
)

type Observation = native.Observation
type Session = native.Session
type QuoteStamp = native.QuoteStamp
type NativeBatch = protect.NativeBatch
type sourceEvidence struct {
	Kind          string `json:"kind"`
	Parent        string `json:"parent"`
	SourceID      string `json:"source_id"`
	Method        string `json:"method"`
	QuantityMicro int    `json:"quantity_micro"`
}

type fixtureSource94 struct {
	orders     map[string]native.Signal
	pending    []native.Signal
	quantity   map[string]int
	reserved   map[string]int
	entry      map[string]float64
	entryQuote map[string]QuoteStamp
	side       map[string]int
	last       QuoteStamp
}

// newFixtureSource94 はSource戦略を動かさない手製API通知の器具です。
//
// 引数: ありません。
// 返り値: *fixtureSource94は予約/所有だけを持ち、FAR自然生成を主張しません。
func newFixtureSource94() *fixtureSource94 {
	return &fixtureSource94{orders: map[string]native.Signal{}, pending: []native.Signal{}, quantity: map[string]int{}, reserved: map[string]int{}, entry: map[string]float64{}, entryQuote: map[string]QuoteStamp{}, side: map[string]int{}, last: QuoteStamp{Index: -1}}
}

// session94 は原板を開かない人工の正しい場時計です。
//
// 引数: ありません。
// 返り値: Sessionは2026-09-21 DayのJST時計です。
func session94() Session {
	z := time.FixedZone("JST", 9*3600)
	start := float64(time.Date(2026, 9, 21, 8, 45, 0, 0, z).Unix())
	end := start + 7*3600
	return Session{ID: "2026-09-21_Day", Kind: "Day", Start: start, ForceClose: end - 600, End: end, ExtraAt: start + 13500}
}

// observation94 は鏡像の原行と手製公開ATRを作ります。
//
// 引数: session(Session)、side(int)、index(int64)、seconds/move/atr(float64)は人工条件です。
// 返り値: Observationは原板生成でないAPI人工入力です。
func observation94(session Session, side int, index int64, seconds, move, atr float64) Observation {
	bid, ask := 1000+move, 1010+move
	if side < 0 {
		bid, ask = 2000-ask, 2000-bid
	}
	at := session.Start + 1800 + seconds
	o := Observation{Reference: "NK225", Time: at, Received: at, Index: index, Last: (bid + ask) / 2, Bid: bid, Ask: ask, QuoteOK: true, ATR: atr}
	o.E01.ATR = atr
	if atr > 0 {
		o.E01.ATRNominal = session.Start + 1500
		o.E01.ATRAvailable = session.Start + 1560
	}
	return o
}

// birth94 は元kind等を型付きMarshalした手製mini出生です。
//
// 引数: id(string)、side/quantity(int)は出典IDと方向/枚数です。
// 返り値: native.Signalは時刻がstep時に固定される人工newです。
func birth94(id string, side, quantity int) native.Signal {
	e := sourceEvidence{Kind: "initial", Parent: "親-" + id, SourceID: "元-" + id, Method: "NK225_D164_15", QuantityMicro: quantity * 10}
	raw, _ := json.Marshal(e)
	return native.Signal{ID: id, Action: "new", Owner: "episode", Side: side, Quantity: quantity, Reason: "人工出生", Evidence: raw}
}

// close94 はSourceの実在HoldIDにだけ向けた手製返済です。
//
// 引数: id/birth(string)、side/quantity(int)は通知と元所有です。
// 返り値: native.SignalはSource所有の反対側への返済です。
func close94(id, birth string, side, quantity int) native.Signal {
	return native.Signal{ID: id, Action: "close", Owner: "episode", Side: -side, Quantity: quantity, Reason: "人工Source返済", Targets: []strategy.LotTarget{{ID: "玉-" + birth, Quantity: quantity}}}
}

// step は手製Source通知の後原行fillだけをpublic Go型で表します。
//
// 引数: t(*testing.T)、o(Observation)、line(int64)、news([]native.Signal)、cancels([]string)は人工原行です。
// 返り値: NativeBatchはFAR戦略生成ではない全量/所有接続の人工です。
func (s *fixtureSource94) step(t *testing.T, o Observation, line int64, news []native.Signal, cancels []string) NativeBatch {
	t.Helper()
	q := quoteActual(o, line)
	d := native.StepResult{At: o.Time, Origin: "quote", SourceLine: line, Signals: []native.SignalRecord{}, Fills: []native.FillRecord{}, Cancellations: []native.Cancellation{}, Closes: []native.CloseNotice{}}
	left := []native.Signal{}
	for _, sig := range s.pending {
		if !normalActual(q) || q.Index <= sig.SourceIndex || q.Time < sig.Time {
			left = append(left, sig)
			continue
		}
		price := q.Bid
		if sig.Side > 0 {
			price = q.Ask
		}
		f := native.Fill{SignalID: sig.ID, ExecutionID: "約定-" + sig.ID, Quantity: sig.Quantity, Price: price, Time: q.Time, Fee: 0}
		fr := native.FillRecord{Fill: f, Action: sig.Action, Side: sig.Side, Quote: q, FeeYen: float64(sig.Quantity) * 38.5, SlippageYen: float64(sig.Quantity) * 500, Allocations: []native.CloseAllocation{}}
		if sig.Action == "new" {
			h := "玉-" + sig.ID
			fr.Fill.HoldID = h
			s.quantity[h] = sig.Quantity
			s.entry[h] = price
			s.entryQuote[h] = q
			s.side[h] = sig.Side
		} else {
			fr.Fill.Closed = valueCopy(sig.Targets)
			for _, target := range sig.Targets {
				if target.Quantity > s.quantity[target.ID] || target.Quantity > s.reserved[target.ID] {
					t.Fatal("人工Source過剰返済")
				}
				gross := float64(s.side[target.ID]) * (price - s.entry[target.ID]) * float64(target.Quantity) * 100
				s.quantity[target.ID] -= target.Quantity
				s.reserved[target.ID] -= target.Quantity
				fr.GrossYen += gross
				pieceFee, pieceSlip := float64(target.Quantity)*38.5, float64(target.Quantity)*500
				fr.Allocations = append(fr.Allocations, native.CloseAllocation{HoldID: target.ID, Quantity: target.Quantity, EntryPrice: s.entry[target.ID], EntryQuote: s.entryQuote[target.ID], ExitPrice: price, ExitQuote: q, GrossYen: gross, EntryFeeYen: pieceFee, ExitFeeYen: pieceFee, EntrySlippageYen: pieceSlip, ExitSlippageYen: pieceSlip, NetYen: gross - 2*pieceFee - 2*pieceSlip})
			}
		}
		fr.NetContributionYen = fr.GrossYen - fr.FeeYen - fr.SlippageYen
		d.Fills = append(d.Fills, fr)
	}
	s.pending = left
	for _, sig := range news {
		sig.Time, sig.SourceIndex = o.Time, o.Index
		if _, exists := s.orders[sig.ID]; exists {
			t.Fatal("人工Source ID重複")
		}
		s.orders[sig.ID] = sig
		if sig.Action == "close" {
			for _, target := range sig.Targets {
				before := s.quantity[target.ID] - s.reserved[target.ID]
				if target.Quantity > before {
					t.Fatal("人工Source Before不足")
				}
				d.Closes = append(d.Closes, native.CloseNotice{ID: sig.ID + "|" + target.ID, ReferenceID: target.ID, Before: before, Quantity: target.Quantity, Reason: sig.Reason})
				s.reserved[target.ID] += target.Quantity
			}
		}
		d.Signals = append(d.Signals, native.SignalRecord{Signal: sig, Origin: "quote", At: o.Time, Quote: q})
		s.pending = append(s.pending, sig)
	}
	for _, id := range cancels {
		found := false
		left = []native.Signal{}
		for _, sig := range s.pending {
			if sig.ID == id {
				found = true
				d.Cancellations = append(d.Cancellations, native.Cancellation{SignalID: id, At: o.Time, Quote: q, Reason: "人工即取消"})
			} else {
				left = append(left, sig)
			}
		}
		if !found {
			t.Fatal("人工取消が未予約")
		}
		s.pending = left
	}
	s.last = q
	return NativeBatch{Method: "D164_15", Delta: d}
}

// finiteActual は金額・価格・時計の有限性を確認します。
//
// 引数: values(...float64)は検査値です。
// 返り値: boolはNaN/無限大がない場合に真です。
func finiteActual(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// quoteActual は当原行を値だけで保存します。
//
// 引数: o(Observation)、line(int64)は当時特徴と物理行です。
// 返り値: QuoteStampはSource Indexをraw連番と混ぜない抜粋です。
func quoteActual(o Observation, line int64) QuoteStamp {
	return QuoteStamp{Time: o.Time, Index: o.Index, SourceLine: line, Last: o.Last, Bid: o.Bid, Ask: o.Ask, QuoteOK: o.QuoteOK}
}

// normalActual は現在の実約定・評価に使うBBO条件です。
//
// 引数: q(QuoteStamp)は当原行です。
// 返り値: boolは正常な有限の正Bid<Askです。
func normalActual(q QuoteStamp) bool {
	return q.QuoteOK && finiteActual(q.Bid, q.Ask) && q.Bid > 0 && q.Ask > q.Bid
}
