"""112の一方向接続と独立場並列を人工・全閉包・exeで市場前停止する。"""

import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DEPENDENCIES = {
    'source': ('111元時計の連続再現/停止.json', '08b1331b372d5cd7e50d46d90c247a8fa9c6a9bf657105ff181928041f156946'),
    'chart': ('111連続保護のチャート公開/停止.json', '38c01e07d276310c6c1d803dca11e27979fc9286cf64d9a495e60485ea7264bd'),
    'core111': ('111連続Sourceと可変保護の接続/停止.json', '87104939274e592ec18cd621b048c5e690eb23336ef390e382f2f32a3a9b8dd5'),
    'parallel111': ('111独立セッションの並列接続/停止.json', '16aa63dfddb01f9425afb3bcbd72ba63fba74b52bd83f38f5327edc67b333e88'),
    'actor': ('112支持否定と広い通常幅の会計/Actor停止.json', '54dc421f0c35cbd5736725955a02fb6cd11f70f3c8a7b646b954722781264006'),
    'pure': ('112支持否定の必須確認と通常幅のみ/停止.json', 'b7748c29ae5c6bc44a66a112421809f888c85321652a0d9bfbb3c7f4022dd835'),
}
NAMES = ('runtime.go', 'runtime_test.go', 'source_fixture_test.go', 'fixed.go', 'fixed_test.go',
         'runner/parallel.go', 'runner/parallel_test.go', 'runner/process_windows.go',
         'runner/process_other.go', 'cmd/run/main.go', 'go.mod', 'go.sum', 'README.md',
         '検査して停止する.py')



def digest(path: Path) -> str:
    """機能: 明示コードと人工の全bytes指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def merge(target: dict, values: dict) -> None:
    """機能: Root相対位置を絶対化して停止mapを統合する。

    引数: target/values(dict)は統合先と固定値。
    返り値: None。現物差と衝突はValueError。
    """
    for name, sha in values.items():
        path = Path(name)
        path = (path if path.is_absolute() else ROOT / path).resolve()
        if digest(path) != sha or (str(path) in target and target[str(path)] != sha):
            raise ValueError('停止codeの現物差:' + str(path))
        target[str(path)] = sha


def execute(command: list[str], label: str, env: dict) -> dict:
    """機能: 市場を使わない人工・閉包・ビルドの終了を検査する。

    引数: command(list[str])、label(str)、env(dict)は起動と環境。
    返り値: dictは成功ログ。不成功はValueError。
    """
    result = subprocess.run(command, cwd=HERE, env=env, capture_output=True, text=True, encoding='utf-8')
    row = {'名': label, 'command': command, '終了コード': result.returncode, '標準出力': result.stdout, '標準エラー': result.stderr}
    if result.returncode:
        raise ValueError(json.dumps(row, ensure_ascii=False))
    return row


def go_closure(env: dict) -> tuple[dict, dict]:
    """機能: 実際の並列cmdの全選択ソースと標準ライブラリを固定する。

    引数: env(dict)はCGO0の環境。
    返り値: tuple[dict,dict]は非GoRootとGoRoot。
    """
    stream = execute(['go', 'list', '-deps', '-json', './cmd/run'], '実Go閉包', env)['標準出力']
    decoder, index, local, standard = json.JSONDecoder(), 0, {}, {}
    while index < len(stream):
        while index < len(stream) and stream[index].isspace():
            index += 1
        if index == len(stream):
            break
        package, index = decoder.raw_decode(stream, index)
        if not package.get('Dir'):
            continue
        target = standard if package.get('Goroot') else local
        for key in ('GoFiles', 'CgoFiles', 'SFiles', 'HFiles', 'SysoFiles', 'EmbedFiles'):
            for name in package.get(key, []):
                path = (Path(package['Dir']) / name).resolve()
                target[str(path)] = digest(path)
        module = package.get('Module', {})
        if module.get('GoMod'):
            path = Path(module['GoMod']).resolve()
            local[str(path)] = digest(path)
            if path.with_name('go.sum').exists():
                local[str(path.with_name('go.sum'))] = digest(path.with_name('go.sum'))
    return local, standard


def reference(path: Path) -> dict:
    """機能: 2キーの実FileRefを作る。

    引数: path(Path)は小metadata又は実行物。
    返り値: dictは絶対pathとSHA256。
    """
    return {'path': str(path.resolve()), 'sha256': digest(path)}


def save_new(path: Path, value: dict) -> None:
    """機能: 日本語UTF8とLFで小metadataを新規保存する。

    引数: path(Path)、value(dict)は未使用先と保存値。
    返り値: None。既存先は拒否する。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main() -> None:
    """機能: 112の接続/並列と依存を市場前に停止しRoot固定素材を返す。

    引数: なし。市場Raw/旧Native/価格CSVは読まない。
    返り値: None。人工/閉包/自己前後差や既存停止を拒否する。
    """
    if (HERE / '停止.json').exists() or (HERE / '条件の素材.json').exists():
        raise ValueError('停止と素材は新規のみ')
    inherited, deps, stops = {}, {}, {}
    for key, (name, sha) in DEPENDENCIES.items():
        path = (ROOT / 'work' / name).resolve()
        if digest(path) != sha:
            raise ValueError('固定依存停止の現物差:' + key)
        value = json.loads(path.read_text(encoding='utf-8-sig'))
        if not value.get('成功') or not value.get('停止'):
            raise ValueError('依存が未停止:' + key)
        deps[key] = reference(path)
        stops[key] = value
        for field in ('所有コードSHA256', '全固定コードSHA256', 'Go閉包SHA256',
                      'GoRootコードSHA256', '再用コードSHA256'):
            merge(inherited, value.get(field, {}))
        merge(inherited, {str(path): sha})
    actual_ref = stops['actor']['実24宣言']
    pure_ref = stops['pure']['実宣言']
    chart_ref = stops['chart']['実API宣言']
    for ref in (actual_ref, pure_ref, chart_ref):
        merge(inherited, {ref['path']: ref['sha256']})
    owned = {str((HERE / name).resolve()): digest(HERE / name) for name in NAMES}
    for name in NAMES:
        if name.endswith('.py'):
            for node in ast.walk(ast.parse((HERE / name).read_text(encoding='utf-8-sig'))):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    doc = ast.get_docstring(node) or ''
                    if '\n' not in doc or any(s not in doc for s in ('機能', '引数', '返り値')):
                        raise ValueError('関数コメント不足:' + node.name)
    env = dict(os.environ, CGO_ENABLED='0', GOWORK='off',
               CORE112_ART_OUT=str(HERE / '人工_停止版_金融'),
               PARALLEL112_ART_OUT=str(HERE / '人工_停止版_I_O'))
    local, standard = go_closure(env)
    allowed = (HERE, ROOT / 'work/112支持否定と広い通常幅の会計', ROOT / 'work/112支持否定の必須確認と通常幅のみ')
    for name in local:
        if name not in inherited and not any(Path(name).is_relative_to(base) for base in allowed):
            raise ValueError('旧閉包と新112部品以外の追加:' + name)
    full = dict(inherited)
    merge(full, local)
    merge(full, standard)
    merge(full, owned)
    directory = HERE / '検査'
    directory.mkdir(exist_ok=False)
    logs = [execute(['go', 'test', '-json', '-count=1', './...'], '全接続と並列人工', env),
            execute(['go', 'vet', './...'], 'vet', env),
            execute(['go', 'build', '-o', str(directory / '112連続比較.exe'), './cmd/run'], '112実行物', env),
            execute(['go', 'doc', '-all', '.'], '接続公開API', env),
            execute(['go', 'doc', '-all', './runner'], '並列公開API', env)]
    tests = [json.loads(line) for line in logs[0]['標準出力'].splitlines() if line.startswith('{')]
    passed = [r for r in tests if r.get('Action') == 'pass' and r.get('Test')]
    main_passed = [r for r in passed if '/' not in r['Test']]
    sub_passed = [r for r in passed if '/' in r['Test']]
    if len(main_passed) != 14 or len(sub_passed) != 19:
        raise ValueError('人工数の差:' + str((len(main_passed),len(sub_passed))))
    if owned != {name: digest(Path(name)) for name in owned} or any(digest(Path(name)) != sha for name, sha in full.items()):
        raise ValueError('自己又は全閉包の前後差')
    artificial = {str(p.resolve()): digest(p) for folder in ('人工_独立保存用','人工_停止版_金融','人工_停止版_I_O')
                  for p in sorted((HERE / folder).rglob('*')) if p.is_file()}
    if len(artificial) != 15:
        raise ValueError('手製金融2対とI/O2子の保存不足:' + str(len(artificial)))
    api = directory / 'API.txt'
    with api.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(logs[3]['標準出力'] + '\n' + logs[4]['標準出力'])
    exe = directory / '112連続比較.exe'
    stopped = {'成功': True, '停止': True, 'trial': 112, 'UTC': datetime.now(timezone.utc).isoformat(),
               '所有コードSHA256': owned, 'Go閉包SHA256': local, 'GoRootコードSHA256': standard,
               '依存コードSHA256': inherited, '全固定コードSHA256': full,
               '依存停止': deps, '実行物': reference(exe),
               '実Actor宣言': actual_ref, '実純保護宣言': pure_ref, '実チャート宣言': chart_ref,
               '実API': reference(api), '主test':len(main_passed), '副test':len(sub_passed),
               '人工SHA256':artificial, '検査ログ':logs, '自己コード全依存前後不変':True,
               'parallel_method':'isolated_session_process112_v1','parallel_max_workers':16,
               '旧111部品の変更':False, 'Source111とChart111への変更':False,
               '原文oracle54再用':True, '旧12人工毎受理原行対照':True,
               '市場で旧全tickState同体を証明':False,
               '市場Raw/旧Native/価格CSV読取':0,'11月09日本文読取':0,
               '採用':False,'研究目標達成':False}
    save_new(HERE / '停止.json', stopped)
    stop_ref = reference(HERE / '停止.json')
    code_map = dict(full)
    code_map[stop_ref['path']] = stop_ref['sha256']
    trial111 = ROOT / 'study/00111_元の連続判断と必須追尾の再基準化'
    old_condition_ref = reference(trial111 / '検査/condition.json')
    if old_condition_ref['sha256'] != 'a64326cd451a943030f569d7b278bf84d878d71ef67164cc566cfeff841d3a4a':
        raise ValueError('旧111正式条件差')
    old = json.loads(Path(old_condition_ref['path']).read_text(encoding='utf-8-sig'))
    actual = json.loads(Path(actual_ref['path']).read_text(encoding='utf-8-sig'))
    pure = json.loads(Path(pure_ref['path']).read_text(encoding='utf-8-sig'))
    material = {'version':1,'trial':112,'fixed':False,
                'policy':'original166_source111_support_pivot_comparison112','source_trial':111,
                'FAR_commit':old['FAR_commit'],'strategy_commit':old['strategy_commit'],
                'manifest':old['manifest'],'executable':reference(exe),'code_sha256':code_map,
                'runtime_stop':stop_ref,'dependency_stops':deps,
                'actual_policy':'support_pivot_normal_width112','chart_seed_mode':'cold_each_session',
                'entry_grid_seconds':None,'extra_opening_quiet_seconds':0,
                'actual_configurations':actual,'pure_configurations':pure['configurations'],
                'policy_definitions':pure['definitions'],
                'actual_declaration':{'path':actual_ref['path'],'sha256':actual_ref['sha256']},
                'pure_declaration':{'path':pure_ref['path'],'sha256':pure_ref['sha256']},
                'chart_declaration':{'path':chart_ref['path'],'sha256':chart_ref['sha256']},
                'original166_references':old['original166_references'],
                'reference111':{'condition':old_condition_ref,'market':reference(trial111 / '検査/market.json'),
                                'native_catalog':reference(trial111 / '成果物_金融/Native参照台帳.json')},
                'parallel_method':'isolated_session_process112_v1','parallel_max_workers':16}
    save_new(HERE / '条件の素材.json',material)
    print(json.dumps({'成功':True,'停止':stop_ref,'素材':reference(HERE / '条件の素材.json'),
                      '実行物':reference(exe),'主test':len(main_passed),'副test':len(sub_passed),
                      '全固定':len(full)},ensure_ascii=True))


if __name__ == '__main__':
    main()
