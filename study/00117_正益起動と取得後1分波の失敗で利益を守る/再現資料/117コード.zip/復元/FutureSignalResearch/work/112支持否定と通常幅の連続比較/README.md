# 112の連続Source・支持否定・通常幅比較の接続

このmoduleはSource111、Chart111を変更せず、Actor112の24冊へ一方向に接続する。市場実行はRootが条件を事前固定した後に行う。停止時点は人工とmetadataの確認だけであり、112の成績・採用・目標達成を示さない。

政策順は `S0,W100,B100,W400,P100,P400`、各政策の費用順は `C0D0,C0D1,C5D0,C5D1`。新規は元FAR166の連続時計のまま。5分/15分の新規gate、開始静観、実約定をSourceへ戻す統合は追加しない。

- S0/W100/B100は111固定対照。W100は200/2Aの通常幅、B100は同通常幅と旧BB複合警戒。
- W400は400/4Aの通常幅。P100は200/2A、P400は400/4Aで、P系の狭幅警戒はM AND P。Hはいずれも100、W起動と全玉床、非緩和はPure112実宣言に従う。
- Sourceは原文166/固定純戦略43、元54の81手法場oracle参照を111から再用する。追加16には元54oracleを偽装しない。
- Source自身のtrial111は固定ライブラリの由来を表す。外側Native、Actual、固定、完了は112。111ゲートへのtrial偽装はしない。

## 公開APIと保存形

`New() *Consumer` はSource111のSourceConsumerを実装し、Begin→Step→Endを受け取る。原行内の公表At、reset/observationの順序、Source通知、先行予約fillを維持する。`ConnectResult(source.ReplayWithConsumer(..., New()))` 相当の結合でS0四感度の全金融JSONを確認する。返り値は `ReplayResult{version:1,trial:112,source,actual,S0_comparisons:4,S0_equal:true,original_historical_events_equal:false,reference111}`。

`CompareReference111` は固定後の当場111正式Nativeだけを認証・復号し、Source全JSONと旧3政策×4費用の金融全値を照合する。Actorの公開比較で許す差は説明StreamScope、監査fieldの `protection111`→`protection112` 名、政策定義へ全値照合したSnapshot追加definitionだけ。reasonや金額を除外しない。旧保存Nativeには全tick履歴がないため、市場で全tickState同体を証明したとは書かない。人工では12冊を各受理原行と終了で比較する。

各Nativeの `reference111` は旧FileRef、比較12、Source同体、金融同体、読取前後SHA、政策別detailsを保持する。Actualはscope/publications/resets/counts/final_chartと24booksを持ち、独立監査へ渡す。SourceやActorの保存項目を削らない。

`PrepareFixed(FileRef,stage,*prior54)` は本文前の112独自外ゲート。70場台帳、純43、旧停止4、新Actor/Pure停止、実cmdのGo/asm/embed/module/GoRoot閉包、自己停止、実行中exe、実24宣言・6定義、111の指定済み条件a643/全70成功a88/正式Native索引、同SHA原文oracle54を認証する。metadata-onlyではRawも旧Nativeの本文・実ファイルSHAも読まない。台帳・コード・小metadataだけを認証し、当場workerでRawと旧Nativeを読む。

`Fixed` の正確なキーは次のとおり。`条件の素材.json` は停止後の実Refを持つ未固定素材であり、Rootが新規条件へ固定する。

```text
version, trial=112, fixed=true,
policy=original166_source111_support_pivot_comparison112, source_trial=111,
FAR_commit, strategy_commit, manifest, executable, code_sha256,
original166_references[54], runtime_stop,
dependency_stops{source,chart,core111,parallel111,actor,pure},
actual_policy=support_pivot_normal_width112,
chart_seed_mode=cold_each_session, entry_grid_seconds=null,
extra_opening_quiet_seconds=0, actual_configurations[24],
pure_configurations[24], policy_definitions[6],
actual_declaration, pure_declaration, chart_declaration,
reference111{condition,market,native_catalog},
parallel_method=isolated_session_process112_v1, parallel_max_workers=16
```

`code_sha256` は停止の全固定コードmapと所有mapのunionに、停止.json自身のFileRefを加えた集合と完全同体であることを要求する。後からBeforeへ固定codeを足して帳尻を合わせない。

## CLIと段階

```powershell
& '検査/112連続比較.exe' --fixed '<Root固定絶対path>' --fixed-sha '<SHA>' --stage metadata-only
& '検査/112連続比較.exe' --fixed '<Root固定絶対path>' --fixed-sha '<SHA>' --stage first2 --out '<新規絶対path>' --workers 2
& '検査/112連続比較.exe' --fixed '<同条件絶対path>' --fixed-sha '<同SHA>' --stage base54 --out '<新規絶対path>' --workers 16
& '検査/112連続比較.exe' --fixed '<同条件絶対path>' --fixed-sha '<同SHA>' --stage full70 --out '<新規絶対path>' --workers 16 --prior54 '<base54完了.json>' --prior54-sha '<SHA>'
```

各workerは同じ固定exeを `--worker-session` で起動し、同じ外ゲートを本文前に通る。Windows子窓は非表示、GOMAXPROCS=1、プロセス間の金融状態共有なし。原行内は直列、独立場だけを最大16並列にする。完了順によらず台帳順へ集約する。子失敗・保存完了欠落・重複・指紋差では不完了を残し、全体成功を作らない。親/子の出力先は新規作成だけ。

first2は2場48冊、base54は54場1296冊。full70は同じ112固定条件で成功したbase54を認証し、54Nativeを参照再用して追加16だけ再生する（70場1680冊）。これは54の再生による再証明ではなく認証済み成果物の再用で、全70保存は独立保存器が別に検算する。

完了は111互換基本fieldに112の旧対照fieldを加える。

```text
version=1,trial=112,stage,success,condition_sha256,sessions,
reused_sessions,replayed_sessions,books,original_methods,
all_original166_reference_events_equal=true,
historical_saved_events_equal=false,all_original_signal_full_json_equal=false,
reference111_comparisons=12N,all_reference111_equal=true,all_source111_equal=true,
results[{session,native,original166_reference?,books=24,S0_comparisons=4,
 S0_equal=true,complete=true,open_quantity=0,pending_quantity=0,
 reference111,reference111_comparisons=12,reference111_equal=true,source111_equal=true}],
before,after,unchanged=true,prior54?,parallel_method,parallel_workers,worker_completions
```

元81Eventsの再実行対照、当時保存Events、全Signal JSON同体は別の証明範囲である。存在しない歴史全Eventを自作しない。

## 検査と限界

`python -X utf8 検査して停止する.py` は旧4停止と新Actor/Pureを現物照合し、自己前後不変、実閉包、人工、vet/build、実行物を新規保存する。手製API通知の買い・売り各24冊はFAR自然生成・市場有効性の検証ではない。旧12毎受理原行、正常/異常気配、先行fill、源非干渉、将来追記非干渉、終了、親子固定、並列順序・失敗・54参照再用を確認する。

未参加・退出後の仮想利益、機会損失、MFE回収率、ROIを作らない。112市場段階が全部終わるまで、後段の成績を見て閾値を変えない。既存111の金融/Source/Actor/Chart/Pure/並列codeは変更しない。
