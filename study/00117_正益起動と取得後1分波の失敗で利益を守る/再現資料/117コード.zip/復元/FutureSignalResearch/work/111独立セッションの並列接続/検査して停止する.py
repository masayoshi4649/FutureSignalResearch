"""独立セッションのI/O接続だけを人工・全閉包・exeで市場前停止する。"""

import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CORE = ROOT / 'work/111連続Sourceと可変保護の接続/停止.json'
CORE_SHA = '87104939274e592ec18cd621b048c5e690eb23336ef390e382f2f32a3a9b8dd5'
NAMES = ('parallel.go', 'parallel_test.go', 'process_windows.go', 'process_other.go',
         'cmd/run/main.go', 'go.mod', 'go.sum', 'README.md', '検査して停止する.py')


def digest(path: Path) -> str:
    """機能: 明示コードと人工の全bytes指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def merge(target: dict, values: dict) -> None:
    """機能: Root相対位置を絶対化して停止mapを統合する。

    引数: target/values(dict)は統合先と固定値。
    返り値: None。現物差と衝突はValueError。
    """
    for name, sha in values.items():
        path = Path(name)
        path = (path if path.is_absolute() else ROOT / path).resolve()
        if digest(path) != sha or (str(path) in target and target[str(path)] != sha):
            raise ValueError('停止codeの現物差:' + str(path))
        target[str(path)] = sha


def execute(command: list[str], label: str, env: dict) -> dict:
    """機能: 市場を使わない人工・閉包・ビルドの終了を検査する。

    引数: command(list[str])、label(str)、env(dict)は起動と環境。
    返り値: dictは成功ログ。不成功はValueError。
    """
    result = subprocess.run(command, cwd=HERE, env=env, capture_output=True, text=True, encoding='utf-8')
    row = {'名': label, 'command': command, '終了コード': result.returncode, '標準出力': result.stdout, '標準エラー': result.stderr}
    if result.returncode:
        raise ValueError(json.dumps(row, ensure_ascii=False))
    return row


def go_closure(env: dict) -> tuple[dict, dict]:
    """機能: 実際の並列cmdの全選択ソースと標準ライブラリを固定する。

    引数: env(dict)はCGO0の環境。
    返り値: tuple[dict,dict]は非GoRootとGoRoot。
    """
    stream = execute(['go', 'list', '-deps', '-json', './cmd/run'], '実Go閉包', env)['標準出力']
    decoder, index, local, standard = json.JSONDecoder(), 0, {}, {}
    while index < len(stream):
        while index < len(stream) and stream[index].isspace():
            index += 1
        if index == len(stream):
            break
        package, index = decoder.raw_decode(stream, index)
        if not package.get('Dir'):
            continue
        target = standard if package.get('Goroot') else local
        for key in ('GoFiles', 'CgoFiles', 'SFiles', 'HFiles', 'SysoFiles', 'EmbedFiles'):
            for name in package.get(key, []):
                path = (Path(package['Dir']) / name).resolve()
                target[str(path)] = digest(path)
        module = package.get('Module', {})
        if module.get('GoMod'):
            path = Path(module['GoMod']).resolve()
            local[str(path)] = digest(path)
            if path.with_name('go.sum').exists():
                local[str(path.with_name('go.sum'))] = digest(path.with_name('go.sum'))
    return local, standard


def main() -> None:
    """機能: 旧Coreを不変に保ちI/O人工後の新shimだけを停止する。

    引数: なし。市場Raw・Native・CSVを開かない。
    返り値: None。未成功又は既存停止は上書きしない。
    """
    if (HERE / '停止.json').exists():
        raise ValueError('停止は新規のみ')
    if digest(CORE) != CORE_SHA:
        raise ValueError('Root停止871の指紋差')
    old = json.loads(CORE.read_text(encoding='utf-8'))
    inherited = {}
    merge(inherited, old['全固定コードSHA256'])
    merge(inherited, old['所有コードSHA256'])
    if len(inherited) != 984:
        raise ValueError('停止Source/Root984項目の集合差')
    owned = {str((HERE / name).resolve()): digest(HERE / name) for name in NAMES}
    for name in NAMES:
        if name.endswith('.py'):
            for node in ast.walk(ast.parse((HERE / name).read_text(encoding='utf-8'))):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    doc = ast.get_docstring(node) or ''
                    if '\n' not in doc or any(s not in doc for s in ('機能', '引数', '返り値')):
                        raise ValueError('関数コメント不足:' + node.name)
    env = dict(os.environ, CGO_ENABLED='0', GOWORK='off', PARALLEL111_ART_OUT=str(HERE / '人工_停止版'))
    local, standard = go_closure(env)
    for name in local:
        if name not in inherited and not Path(name).is_relative_to(HERE):
            raise ValueError('Source/Root閉包と新shim以外の追加:' + name)
    full = dict(inherited)
    merge(full, local)
    merge(full, standard)
    merge(full, owned)
    merge(full, {str(CORE): CORE_SHA})
    directory = HERE / '検査'
    directory.mkdir(exist_ok=False)
    logs = [execute(['go', 'test', '-json', '-count=1', './...'], '全I/O人工', env),
            execute(['go', 'vet', './...'], 'vet', env),
            execute(['go', 'build', '-o', str(directory / '111独立並列.exe'), './cmd/run'], '並列exe', env)]
    tests = [json.loads(line) for line in logs[0]['標準出力'].splitlines() if line.startswith('{')]
    passed = [r for r in tests if r.get('Action') == 'pass' and r.get('Test')]
    main_passed = [r for r in passed if '/' not in r['Test']]
    sub_passed = [r for r in passed if '/' in r['Test']]
    if len(main_passed) != 6 or len(sub_passed) != 5:
        raise ValueError('I/O主人工不足')
    if owned != {name: digest(Path(name)) for name in owned} or any(digest(Path(name)) != sha for name, sha in full.items()):
        raise ValueError('自己又は全閉包の前後差')
    exe = directory / '111独立並列.exe'
    artificial = {str(p.resolve()): digest(p) for p in sorted((HERE / '人工_停止版').rglob('*')) if p.is_file()}
    if len(artificial) != 5:
        raise ValueError('I/O人工2子と親完了の保存不足')
    value = {'成功': True, '停止': True, 'trial': 111, 'UTC': datetime.now(timezone.utc).isoformat(),
             'parallel_method': 'isolated_session_process_v1', 'parallel_max_workers': 16,
             'Core停止': {'path': str(CORE), 'sha256': CORE_SHA},
             '所有コードSHA256': owned, 'Go閉包SHA256': local, 'GoRootコードSHA256': standard,
             'SourceRoot984SHA256': inherited, '全固定コードSHA256': full,
             '実行物': {'path': str(exe), 'sha256': digest(exe)}, '主test': len(main_passed), '副test': len(sub_passed),
             '人工SHA256': artificial, '検査ログ': logs,
             '自己コード全依存前後不変': True,
             '人工のCore金融模型': False, '手製callbackとmetadataのみ': True,
             '市場Raw/Native/CSV読取': 0, '11月09日本文読取': 0,
             '金融SourceActorChartPure変更': False, '市場同bytes確認': False, '採用': False, '研究目標達成': False}
    with (HERE / '停止.json').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'成功': True, '停止SHA256': digest(HERE / '停止.json'), '主test': len(main_passed), '副test': len(sub_passed),
                      '実行物': value['実行物'], 'SourceRoot': len(inherited), '全固定': len(full)}, ensure_ascii=True))


if __name__ == '__main__':
    main()
