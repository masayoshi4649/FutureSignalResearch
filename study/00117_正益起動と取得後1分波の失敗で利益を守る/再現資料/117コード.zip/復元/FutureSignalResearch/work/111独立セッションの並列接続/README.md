# 独立セッションだけを別プロセスへ配るI/O接続

停止Core871049…、Source、Actor、Chart、Pureの金融処理を変更しない。各セッションはcoldで独立しているため、一セッション一プロセスにする。親は最大16子を同時に起動する。既定16、必要場数とのminなので先頭2は同時2。子はGOMAXPROCS=1とし原行内を直列に処理する。WindowsではHideWindow/CREATE_NO_WINDOWにより子の表示窓を作らない。子から更にspawnする分岐はない。

各子も停止CoreのPrepareFixedを呼び、実行中exeのSHAがF3.executableと同じこと、同じ条件・全コード・43戦略・70場入力台帳metadata・元対照を本文前に認証する。PrepareはRawを開かない。Rawの認証と読取はReplayの当場6ファイルだけ。full70では先行54NativeのSHA認証は各子でも行うが、元54Rawを再読しない。

金融はsource.ReplayWithConsumer(root,input,core.New())→core.ConnectResult→core.CheckReplay→source.CompareGoldenの公開APIをそのまま使う。元54では全81手法場の100micro/10mini全Event対照、全24口座/S0四対照/全残0の条件を保つ。NativeはCoreと同じ型をMarshalIndent＋LF、同じgzipで保存する。金融payloadへ並列の説明を加えない。同bytesは市場でRootが直列先頭2と実物照合して確認する。

## F3の固定

元の金融条件を保ち、executableをこの新exeへ、code_sha256を停止の全固定コードmap＋Core停止JSON＋新parallel_stop JSONへ更新する。追加はparallel_method=isolated_session_process_v1、parallel_max_workers=16、parallel_stop=絶対FileRef。元54の対照Ref、手法・費用・足・原行順・cold・保護の閾値は変更しない。Source/Root閉包と新shim以外のコード追加は停止前に拒否する。

Coreのbase54→full70 gateはbefore集合も完全一致させる。そのため二つの停止JSONもF3.code_sha256へ記し、beforeへ後付けしない。base54のcondition SHAとfull70は同じF3。既存F2の途中成果を成功として再用しない。

    111独立並列.exe --fixed <F3絶対位置> --fixed-sha <SHA> --stage metadata-only
    111独立並列.exe --fixed <F3> --fixed-sha <SHA> --stage first2 --out <未使用先>
    111独立並列.exe --fixed <F3> --fixed-sha <SHA> --stage base54 --out <未使用先> --workers 16
    111独立並列.exe --fixed <同F3> --fixed-sha <同SHA> --stage full70 --prior54 <F3 base54完了> --prior54-sha <SHA> --out <未使用先>

## 保存と失敗

親出力のworker/場IDだけが当子の新規先。log/場ID.txtは親が独占新規作成する。親・子とも既存先を上書きしない。子は当場Nativeと完了を保存し、親は子の終了成功だけでなく完了記録・期待F3前後指紋・24完結・元Event対照・Native現物SHAと所有先を確認する。全子成功後だけ予定台帳順へ並べ、親の完了を新規保存する。失敗・途中終了・重複・欠落では不完了だけを残す。成功した他子があっても全体を成功扱いしない。

completionのCore互換項目はそのまま。parallel_method/parallel_workers/worker_completionsだけを追加する。全70は同F3のbase54で認証済みの54Native FileRefを元順序で参照再用し、追加16だけworkerへ配る。reused_sessions/replayed_sessions=54/16。金融の再生による再証明やRaw54再読とは扱わない。

## 人工と範囲

手製callbackで並行上限・完了順と元順序・全件集約・子の失敗/完了欠落/場重複/期待指紋差・既存先・54参照再用を確認する。手製metadataで公開Coreゲートの本文前成功と実行中exe SHA不一致も確認する。人工Nativeは金融模型ではなくI/Oだけの器具。市場Native・原板・CSV・11/09の本文は実行しない。閾値選別や市場結果の評価を行わない。
