module github.com/masayoshi4649/SessionTradeExecuter/parallel111

go 1.24.2

require (
	github.com/BurntSushi/toml v1.5.0 // indirect
	github.com/expr-lang/expr v1.17.8 // indirect
	github.com/masayoshi4649/SessionTradeExecuter v0.0.0 // indirect
	github.com/masayoshi4649/SessionTradeExecuter/mininative v0.0.0 // indirect
)

replace github.com/masayoshi4649/SessionTradeExecuter/mininative => ../../scripts/FAR元三手法のmini連続再現

replace github.com/masayoshi4649/SessionTradeExecuter => ../../../SessionTradeExecuter

replace github.com/masayoshi4649/SessionTradeExecuter/miniprotect => ../../scripts/FAR連続出生と個別利益追尾

require (
	github.com/masayoshi4649/SessionTradeExecuter/chartwarmup96 v0.0.0 // indirect
	github.com/masayoshi4649/SessionTradeExecuter/research80 v0.0.0 // indirect
	github.com/masayoshi4649/SessionTradeExecuter/research81 v0.0.0 // indirect
	github.com/masayoshi4649/SessionTradeExecuter/research82 v0.0.0 // indirect
)

replace github.com/masayoshi4649/SessionTradeExecuter/minigrid => ../../scripts/FAR5分判断と出生一回

replace github.com/masayoshi4649/SessionTradeExecuter/chartwarmup96 => ../../scripts/複数尺度チャートの助走

replace github.com/masayoshi4649/SessionTradeExecuter/research80 => ../../scripts/FAR後期15分移植

replace github.com/masayoshi4649/SessionTradeExecuter/research81 => ../../scripts/定時の現在根拠と部分利益保護

replace github.com/masayoshi4649/SessionTradeExecuter/research82 => ../../scripts/チャートの現在性と補助確認

require github.com/masayoshi4649/SessionTradeExecuter/minichart v0.0.0 // indirect

replace github.com/masayoshi4649/SessionTradeExecuter/minichart => ../../scripts/FAR5分枠の順行反転と数量

replace github.com/masayoshi4649/SessionTradeExecuter/miniharvest => ../../scripts/FAR初回利益確定

replace github.com/masayoshi4649/SessionTradeExecuter/minirisk98 => ../../scripts/FAR利益前ATR追尾

require github.com/masayoshi4649/SessionTradeExecuter/minie3 v0.0.0 // indirect

replace github.com/masayoshi4649/SessionTradeExecuter/minie3 => ../../scripts/FAR背景と勢いと数量の純判定

replace github.com/masayoshi4649/SessionTradeExecuter/minientry99 => ../../scripts/FAR背景と勢いと数量の入口

replace github.com/masayoshi4649/SessionTradeExecuter/minigrossguard100 => ../../scripts/FAR利益化前後の保護

require github.com/masayoshi4649/SessionTradeExecuter/minix5 v0.0.0 // indirect

replace github.com/masayoshi4649/SessionTradeExecuter/minix5 => ../../scripts/保有の3分複合失効の純式

require github.com/masayoshi4649/SessionTradeExecuter/minishortexit v0.0.0 // indirect

replace github.com/masayoshi4649/SessionTradeExecuter/minishortexit => ../../scripts/短秒進行と現在量の退出

replace github.com/masayoshi4649/SessionTradeExecuter/minishortfinance => ../../scripts/短秒の複合退出の会計

replace github.com/masayoshi4649/SessionTradeExecuter/minidelayed103 => ../103多玉の保護会計

require (
	github.com/masayoshi4649/SessionTradeExecuter/miniprotect v0.0.0 // indirect
	github.com/masayoshi4649/SessionTradeExecuter/minivariableguard v0.0.0 // indirect
	github.com/masayoshi4649/SessionTradeExecuter/profitfloor111 v0.0.0 // indirect
	github.com/masayoshi4649/SessionTradeExecuter/publicdelivery v0.0.0 // indirect
)

replace github.com/masayoshi4649/SessionTradeExecuter/minivariableguard => ../収束可変幅の保護会計案

require github.com/masayoshi4649/SessionTradeExecuter/publicchart v0.0.0

replace github.com/masayoshi4649/SessionTradeExecuter/publicchart => ../可変追尾向けの公開チャート

require (
	github.com/masayoshi4649/SessionTradeExecuter/chartprotection111 v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/continuous111 v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/continuousactor111 v0.0.0
)

replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor111 => ../111全玉利益と収束BBの純保護

replace github.com/masayoshi4649/SessionTradeExecuter/publicdelivery => ../収束可変幅の公開配送案

replace github.com/masayoshi4649/SessionTradeExecuter/continuous111 => ../111元時計の連続再現

replace github.com/masayoshi4649/SessionTradeExecuter/continuousactor111 => ../111元通知の連続Actor

replace github.com/masayoshi4649/SessionTradeExecuter/chartprotection111 => ../111連続保護のチャート公開

require github.com/masayoshi4649/SessionTradeExecuter/continuousruntime111 v0.0.0

replace github.com/masayoshi4649/SessionTradeExecuter/continuousruntime111 => ../111連続Sourceと可変保護の接続
