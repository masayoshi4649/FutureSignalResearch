"""旧W/Pは停止有理数式、新H0は独立126人工の数式で保存点を検査する。"""
from copy import deepcopy
from decimal import Decimal
from pathlib import Path
import ast
import hashlib
import importlib.util
import inspect
import textwrap
import 金融の独立検算 as A

ROOT=Path(__file__).resolve().parents[2]
OLD_PATH=ROOT/'work/113起動前の構造失効を執行する会計/新保護の独立監査.py';MODEL_PATH=ROOT/'work/117正益床の人工を独立検算する/独立式.py'
if hashlib.sha256(OLD_PATH.read_bytes()).hexdigest()!='fdd4182152e60a66b298e633a813c3496440f3aea684d1dc4fe950983d39115f':raise ValueError('停止113有理数SHA差')
if hashlib.sha256(MODEL_PATH.read_bytes()).hexdigest()!='a6c3f965bd89d0d758ab78227062c8ff4ff41647515e2ec65c6c35e12678db7a':raise ValueError('独立H0算術SHA差')
OLD=A.module(OLD_PATH,'117が再用する停止113有理数')
M=A.module(MODEL_PATH,'117で再用する独立H0金額算術')
need,equal=A.need,A.equal


def legacy_function():
    """
    機能: 旧W100/P100/S0数式を新監査フィールド名だけへ接続する。
    引数: なし。返り値: function。政策や版、数値を旧名へ偽装しない。
    """
    tree=ast.parse(textwrap.dedent(inspect.getsource(OLD.verify_protection)));count=0
    for n in ast.walk(tree):
        if isinstance(n,ast.Constant) and n.value=='protection113':n.value='protection117';count+=1
    equal(count,1,'旧保護フィールド名だけ一箇所派生');space=dict(vars(OLD));exec(compile(ast.fix_missing_locations(tree),__file__+':旧政策保存名だけ','exec'),space);return space['verify_protection']


LEGACY=legacy_function()
TRACE_NAMES=('first_activation','first_narrowing','first_floor_update','last_floor_update','first_floor_hit','first_all_reserved_hit','last')


def reserved_at(orders:dict,pid:str,index:int,phase:str)->int:
    """
    機能: Source後/自己要求前の保護点の実予約をIndexで再構成する。
    引数: orders(dict)、pid(str)、index(int)、phase(str)。返り値: int。
    """
    total=0
    for o in orders.values():
        if o['kind']!='exit' or o['position_id']!=pid:continue
        requested=o['request_quote']['index']<index or (phase=='after_source' and o['request_quote']['index']==index and o['protection_point'] is None)
        if not requested:continue
        fill=o.get('_fill_index')
        if fill is not None and (fill<index or phase=='after_source' and fill==index):continue
        total+=o['quantity']
    return total


def diagnostic(latest:dict|None,side:int)->dict:
    """
    機能: 旧3分の生票だけを抽出しH0の狭幅根拠にしない。
    引数: latest(dict|None)、side(int)。返り値: dictはC/M/P/B。
    """
    v=OLD.warnings(latest,'W100',side);return {k:v[k] for k in ('c','m','p','b')}


def check_bridge(p:dict,s:dict,context:dict)->None:
    """
    機能: opaque完成票を実短期の初回Witness/実Positionへ結合する。
    引数: p/s/context(dict)。返り値: None。短期数値/全Raw初回性はここで再形成しない。
    """
    n=s['h0_117']['narrow']
    if n is None:return
    short=p.get('shortwave117');need(short is not None,'H0M完成票の短期証拠');w=short['final_state']['first_warning'];need(w is not None,'完成票Witness')
    equal(n.get('witness'),w,'opaque票の実短期Witness全値');q=w['at'];equal(n['id'],f"117短期/{p['id']}/{q['index']}/{q['source_line']}",'完成票ID')
    equal((n['at'],n['source_index'],n['source_line']),(q['time'],q['index'],q['source_line']),'完成票原行');equal(n['scope'],s['entry']['scope'],'完成票Scope');equal(n['width_points'],w['target_width_points'],'完成幅')
    need(n['completed'] is True and w['active'] is True and all(w[x]==2 for x in ('s','m','v','warning')),'三役完成')
    need(q['index']>=p['entry_quote']['index'] and q['source_line']>=p['entry_quote']['source_line'] and q['time']>=p['entry_quote']['time'],'取得前完成票なし')
    need(w['prefix']['last']==q and w['prefix']['published']==q and len(w['bank_sha256'])==64,'prefix原行/出典')
    expected=M.ceil5(max(Decimal(5),min(M.number(s['normal_width']),M.number(w['a_arm']['value']))));equal(n['width_points'],expected,'最初A_armからの完成幅')


def local_point(p:dict,pt:dict,finance:dict,context:dict,previous:dict)->None:
    """
    機能: 保存された境界Target/峰を明示し、H0の局所金額式を独立計算する。
    引数: p/pt/finance/context/previous(dict)。返り値: None。未保存の峰・Target履歴を再走したとはしない。
    """
    s,d=pt['snapshot'],pt['decision'];h=s['h0_117'];dh=d['h0_117'];e=s['entry'];n=s['remaining'];r=M.number(s['closed_net_yen']);rh=M.half(r);k=int(s['cost_per_unit_yen']);idx=h['source_index'];phase=pt['phase'];q=pt['quote']
    equal((s['at'],h['phase'],dh['phase'],dh['source_index']),(pt['at'],phase,phase,idx),'点の時計/位相/Index')
    model=M.Model(e);fixed=model.snapshot()
    for name in ('definition','entry','normal_width','atr_unknown_fallback','cost_per_unit_yen','minimum_floor','threshold_points'):equal(s[name],fixed[name],'H0取得固定/'+name)
    equal(h['definition'],fixed['h0_117']['definition'],'H0意味定義');equal(d['free_quantity'],n-s['reserved'],'実free')
    owner=finance['timeline'].state_at(p['id'],{'quote':{'index':idx},'phase':phase});need(owner is not None,'取得前点なし');equal(n,owner['quantity'],'実n');equal(r,owner['realized'],'実R')
    orders={oid:{**o,'_fill_index':finance['timeline'].fill_by_order[oid]['quote']['index'] if oid in finance['timeline'].fill_by_order else None} for oid,o in finance['orders'].items()};equal(s['reserved'],reserved_at(orders,p['id'],idx,phase),'Source後/自己要求前の実予約')
    for name,v in diagnostic(s['latest'],p['side']).items():equal(d[name],v,'旧生票/'+name)
    latest=s['latest']
    if latest is not None:
        equal(latest['scope'],e['scope'],'旧3分Scope');need(latest['end']<=latest['available_at']<=s['at'],'旧3分公表時計');side='buy' if p['side']==1 else 'sell';matches=[row for row in context['publications'] or [] if row[side]==latest];need(any(latest['available_at']<=row['at']<=s['at'] for row in matches),'公表正本の実値/配送時計')
    check_bridge(p,s,context)
    equal(s['active'],h['target_set'],'ActiveとTarget初期化');equal(s['narrowed'],h['narrow_applied'],'幅適用flag');equal(s['width_points'],min(M.number(s['normal_width']),M.number(h['narrow']['width_points'])) if h['narrow_applied'] else s['normal_width'],'固定幅')
    if n==0:
        need(s['finished'],'n0完結');need(all(d[x] is None for x in ('gain_points','unit_net_yen','whole_net_yen','protect_price','whole_floor','peak_floor')),'flat新価格評価なし');equal(d['eligible_exit_quantity'],0,'flat要求なし');equal(dh['target_before_half_yen'],dh['target_after_half_yen'],'flatTarget更新なし');equal(dh['target_after_half_yen'],h['whole_target_half_yen'],'flatTarget保持');need(not d['activated_now'] and not d['narrowed_now'] and not dh['target_initialized_now'] and not dh['narrow_latched_now'] and not dh['narrow_applied_now'],'flat新イベントなし')
        if h['target_set']:equal(M.number(s['whole_target_yen'])*2,h['whole_target_half_yen'],'flat半円Target')
        return
    equal(s['finished'],False,'保有中完結なし');mark=None
    if q is not None:
        need(q['quote_ok'] and q['index']==idx and q['time']==pt['at'],'正常原行点');mark=M.number(q['bid' if p['side']==1 else 'ask'])
        gain=p['side']*(mark-M.number(p['entry_price']));unit=100*gain-k;equal(d['gain_points'],gain,'gain');equal(d['unit_net_yen'],unit,'u');equal(d['whole_net_yen'],r+n*unit,'W')
    else:need(all(d[x] is None for x in ('gain_points','unit_net_yen','whole_net_yen','protect_price')),'nil Markを補完しない')
    if not s['active']:
        need(s['floor_points'] is None and s['peak_points'] is None and h['whole_target_half_yen'] is None,'未起動Target未設定')
        if mark is not None:need(r+n*unit<=0,'W正なら必須起動')
        return
    need(s['peak_points'] is not None and (mark is None or M.number(s['peak_points'])>=gain),'峰の現在値包含')
    before=dh['target_before_half_yen']
    if d['activated_now']:
        need(mark is not None and r+n*unit>0 and before is None and dh['target_initialized_now'],'起動厳密符号/未設定');equal(dh['initial_target_half_yen'],rh-2*n*k,'初期L=R-nK');old_floor=Decimal(0);target=rh-2*n*k
    else:
        need(before is not None and not dh['target_initialized_now'],'起動後の旧Target');target=before
        prior=owner if phase=='pre_fill' else finance['timeline'].state_at(p['id'],{'quote':{'index':idx},'phase':'pre_fill'});need(prior is not None and prior['quantity']>0,'旧Targetの直前所有')
        old_floor=(M.number(before)-M.half(prior['realized'])+2*prior['quantity']*k)/(200*prior['quantity']);need(old_floor>=0 and old_floor%5==0,'旧境界Targetが含意する価格床')
    room=False
    if mark is not None:
        zero=max(0,M.whole_floor(0,rh,k,n));room=M.number(zero)<=gain-5;equal((dh['zero_candidate_floor'],dh['zero_room']),(zero,room),'ゼロ候補と1呼値余地')
        if room:target=max(target,0)
    else:equal((dh['zero_candidate_floor'],dh['zero_room']),(None,None),'未知Markで目標追加なし')
    double=h['narrow'] is not None
    first_width=s['normal_width'] if dh['narrow_latched_now'] else s['width_points']
    first_floor=max(Decimal(0),old_floor,M.ceil5(M.number(s['peak_points'])-M.number(first_width)),M.number(M.whole_floor(target,rh,k,n)))
    if double:
        first_target=rh+n*(int(200*first_floor)-2*k);expected_fw=M.whole_floor(first_target,rh,k,n)
    else:expected_fw=M.whole_floor(target,rh,k,n)
    peak_floor=M.ceil5(M.number(s['peak_points'])-M.number(s['width_points']));floor=max(first_floor,peak_floor)
    equal(d['whole_floor'],expected_fw,'H0一段/短期二段のFW');equal(d['peak_floor'],peak_floor,'峰床');equal(s['floor_points'],floor,'最低/既床/FW/峰のmax')
    implied=rh+n*(int(200*floor)-2*k);equal((h['whole_target_half_yen'],dh['target_after_half_yen'],dh['floor_implied_half_yen']),(implied,implied,implied),'半円Target更新');equal(s['whole_target_yen'],Decimal(implied)/2,'円Target')
    if before is not None:need(implied>=before,'Target非緩和')
    if previous.get('floor_points') is not None:need(floor>=M.number(previous['floor_points']),'保存床非緩和')
    if mark is not None:
        protect=M.number(p['entry_price'])+p['side']*floor;hit=gain<=floor;equal((d['protect_price'],d['protect_price_valid'],d['floor_hit'],d['all_reserved_hit'],d['eligible_exit_quantity']),(protect,protect>0,hit,hit and n==s['reserved'],n-s['reserved'] if hit and phase=='after_source' else 0),'価格床/hit/未予約量')
    else:need(not d['floor_hit'] and d['eligible_exit_quantity']==0,'nil Mark hit/要求なし')
    equal(d['structural_floor'],None,'H0に旧3分構造床なし');equal(d['warning'],2 if h['narrow'] is not None else 0,'H0完成警戒だけ')


def verify_protection(book:dict,config:dict,finance:dict,context:dict)->dict:
    """
    機能: 本名20の旧保護又は新H0保存点を分離検算する。
    引数: book/config/finance/context(dict)。返り値: dictは保存点件数と限界。
    """
    if config['policy'] in ('S0','W100','P100'):return LEGACY(book,config,finance,context)
    counts={'positions':0,'saved_points':0,'h0_activation_equal_first_whole':0,'local_formula_points':0,'short_bridge_positions':0,'request_points_unstored':0}
    for p in book['positions']:
        counts['positions']+=1;a=p['protection117'];e=a['initial']['entry'];equal(M.Model(e).snapshot(),a['initial'],'H0初期全状態');equal((e['price'],e['side'],e['initial_quantity'],e['at'],e['policy']),(p['entry_price'],p['side'],p['initial_quantity'],p['entry_quote']['time'],config['policy']),'H0実取得')
        equal(p['activation'],p['marks']['first_whole_positive'],'H0起動MTM=初Whole正益');equal(p['protection_active'],p['marks']['first_whole_positive'] is not None,'H0必須起動対応');counts['h0_activation_equal_first_whole']+=p['protection_active']
        unique={}
        for name in TRACE_NAMES:
            t=a.get(name)
            if t is None:continue
            seq=t['snapshot']['sequence']
            if seq in unique:equal(t,unique[seq],'同sequence保存点同体')
            unique[seq]=t
        previous=a['initial']
        bound_orders=set()
        for seq,t in sorted(unique.items()):
            need(seq>previous['sequence'] and t['at']>=previous['at'],'保存sequence時計')
            if previous['active']:need(t['snapshot']['active'] and t['snapshot']['activated_at']==previous['activated_at'],'Active非撤回')
            local_point(p,t,finance,context,previous);previous=t.get('after_request') or t['snapshot'];counts['saved_points']+=1;counts['local_formula_points']+=1
            if t['exit_order_id']:
                oid=t['exit_order_id'];need(oid in finance['orders'],'保存要求の実注文');o=finance['orders'][oid];equal(o['position_id'],p['id'],'要求実所有');equal(o['quantity'],t['decision']['eligible_exit_quantity'],'保存点からの未予約要求');need(t['phase']=='after_source' and o['protection_point'] is not None,'自己保護要求位相')
                after=deepcopy(t['snapshot']);after['reserved']+=o['quantity'];after['sequence']+=2 if after['h0_117']['narrow'] is not None else 1;equal(t.get('after_request'),after,'H0予約後のnilMark一段/短期二段同期');bound_orders.add(oid)
        final=a['final_state'];equal((final['remaining'],final['reserved'],final['closed_net_yen'],final['finished'],final['active'],final['floor_points']),(0,0,p['realized_net'],True,p['protection_active'],p['floor_gain']),'最終実所有/床')
        equal(final,a['last'].get('after_request') or a['last']['snapshot'],'最終純状態とLast保存点')
        own=[o for o in finance['orders'].values() if o['position_id']==p['id'] and o['protection_point'] is not None]
        counts['request_points_unstored']+=sum(o['id'] not in bound_orders for o in own)
        extra=0
        if p.get('shortwave117') is not None and p['shortwave117'].get('first_warning') is not None:
            counts['short_bridge_positions']+=1;w=p['shortwave117']['first_warning'];gap=p['closed_quote']['index']-w['quote']['index'];extra=2*gap+(1 if w['phase']=='pre_fill' else 0)+len(own)
        equal(final['sequence'],a['evaluations']+a['resets']+len(own)+extra,'正常評価/reset/自己予約/短期二段のsequence保存則')
        equal(a['evaluations'],2*(p['closed_quote']['index']-p['entry_quote']['index'])+1,'記録Indexとpre/after呼出保存則')
        if p['protection_active']:equal(a['first_activation']['snapshot']['h0_117']['source_index'],p['activation']['quote']['index'],'初起動原行')
    return {'complete':True,'method':'Decimal/半円整数によるH0保存点の局所式と実所有結合','counts':counts,'limits':['未保存のTarget境界と峰は保存値を境界入力に用い、全Rawの峰/初回性を再形成しない。','sequenceは記録IndexとActor位相の保存則でありRaw配送漏れ独立証明ではない。','旧3分公表の同秒配送Indexや全追尾床Raw最初性は未証明。']}
