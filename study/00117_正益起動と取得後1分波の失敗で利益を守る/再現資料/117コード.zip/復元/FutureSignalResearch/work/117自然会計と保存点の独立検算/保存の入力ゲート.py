"""Rootの固定要求と117金融成功metadataを、Native本文の前に結合する。"""
import hashlib
import json
from pathlib import Path
import 金融の独立検算 as A

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent.parent
CONDITION_SHA='522fe2343b914243fadc4f48d32128a79ecdafcabd84d5a58b5ca399af90d1b0'
SIZES={'first2':2,'base54':54,'full70':70}


def digest(path:Path)->str:
    """
    機能: 許可済みmetadata/コードのSHAを求める。
    引数: path(Path)。返り値: str。metadata-onlyではNativeへ使わない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(ref:dict,before:dict)->dict:
    """
    機能: 明示Refの小metadataを認証する。
    引数: ref(dict)、before(dict)。返り値: dict。
    """
    p=Path(ref['path']).resolve();A.need(p.is_absolute() and digest(p)==ref['sha256'],'metadata Ref SHA');before[str(p)]=ref['sha256'];return json.loads(p.read_text(encoding='utf-8-sig'))


def validate(request:dict,output:Path,metadata_only:bool)->dict:
    """
    機能: Root承認/同F1/stage/場/20冊/旧12/不変を本文前認証する。
    引数: request(dict)、output(Path)、metadata_only(bool)。返り値: dictは準備済みmetadata。
    """
    A.need(request['version']==1 and request['trial']==117 and request['fixed'] is True,'Root固定117要求');stage=request['stage'];A.need(stage in SIZES,'stage');A.need(request['native_read_authorized'] is True and request['legacy_native_read_authorized'] is False,'新NativeのみRoot許可/旧自然本文は禁止')
    A.equal(Path(request['output_dir']).resolve(),output.resolve(),'固定出力先');A.need(not output.exists(),'既存成果上書き禁止')
    before={};condition=read(request['condition'],before);complete=read(request['completion'],before);stop=read(request['verifier_stop'],before)
    A.need(condition['fixed'] is True and condition['trial']==117 and request['condition']['sha256']==CONDITION_SHA,'Root117F1同体');A.equal(condition['actual_configurations'],list(A.CONFIGS),'F1実20宣言')
    n=SIZES[stage];A.need(complete['success'] is True and complete['trial']==117 and complete['stage']==stage and complete['condition_sha256']==CONDITION_SHA,'同F1金融成功');A.equal((complete['sessions'],complete['books']),(n,20*n),'金融場数/会計数')
    A.need(complete['unchanged'] is True and complete['before']==complete['after'],'金融コード前後不変');A.need(complete['all_reference112_equal'] is True and complete['all_source111_equal'] is True and complete['reference112_comparisons']==12*n,'旧112全12とSource全文のGo成功')
    rows=complete['results'];sessions=[r['session'] for r in rows];A.equal(sessions,request['sessions'],'Root要求の場順');A.need(len(rows)==n and len(set(sessions))==n,'場の欠落/重複');A.equal(set(request['market_paths']),set(sessions),'価格は文字列参照のみ')
    if stage=='first2':A.equal(sessions,['2026-09-21_Day','2026-09-21_Night'],'先頭2固定')
    A.need(all(not s.startswith('2026-11-09') for s in sessions),'11月09禁止')
    for r in rows:A.need(r['complete'] is True and r['books']==20 and r['open_quantity']==r['pending_quantity']==0 and r['reference112_equal'] is True and r['reference112_comparisons']==12 and r['source111_equal'] is True,'各場完結/旧比較')
    A.need(stop['成功'] is True and stop['停止'] is True and stop['市場前'] is True and stop['試行']==117,'独立検算停止')
    expected={str(p.resolve()) for p in BASE.iterdir() if p.is_file() and p.suffix in ('.py','.md')};A.equal(set(stop['所有ファイルSHA256']),expected,'独立停止所有の全集合')
    for p,sha in stop['所有ファイルSHA256'].items():A.need(Path(p).resolve().is_relative_to(BASE) and digest(Path(p))==sha,'停止所有コード');before[str(Path(p).resolve())]=sha
    for p,sha in stop['再用ファイルSHA256'].items():A.need(digest(Path(p))==sha,'停止再用コード');before[str(Path(p).resolve())]=sha
    return {'request':request,'condition':condition,'completion':complete,'rows':rows,'stage':stage,'before':before,'metadata_only':metadata_only}
