"""人工成功・所有/再用コードの前後同体を保存し、Rootレビュー後だけ停止する。"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from types import ModuleType
import 金融の独立検算 as A
import 保存集計の共通部 as S
import 保存の入力ゲート as G

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent.parent


def maps()->tuple[dict,dict]:
    """
    機能: 所有一式と実際に読込まれた再用Python数式の閉包を求める。
    引数: なし。返り値: tuple[dict,dict]は絶対path/SHA。自然入力には触れない。
    """
    own={str(p.resolve()):G.digest(p) for p in BASE.iterdir() if p.is_file() and p.suffix in ('.py','.md')};reused={};seen=set();queue=[A,S]
    while queue:
        m=queue.pop()
        if id(m) in seen:continue
        seen.add(id(m));p=getattr(m,'__file__',None)
        if p:
            p=Path(p).resolve()
            if p.suffix=='.py' and p.is_relative_to(ROOT) and str(p) not in own:reused[str(p)]=G.digest(p)
        for v in vars(m).values():
            if isinstance(v,ModuleType):
                f=getattr(v,'__file__',None)
                if f and Path(f).resolve().is_relative_to(ROOT):queue.append(v)
    A.need(reused and str(A.PRIOR.resolve()) in reused,'停止113会計を含む実再用閉包');return dict(sorted(own.items())),dict(sorted(reused.items()))


def write(path:Path,value)->None:
    """
    機能: 小さな新規証拠だけをUTF8で保存する。
    引数: path(Path)、value(JSON値)。返り値: None。
    """
    with path.open('x',encoding='utf-8') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


def prove(folder:Path)->dict:
    """
    機能: 手製だけの6主人工とコード閉包前後同体を停止前proofへ保存する。
    引数: folder(Path)。返り値: dict。停止は行わず自然会計成功も主張しない。
    """
    A.need(not folder.exists(),'proof新出力先');before=maps();folder.mkdir(parents=True);r=subprocess.run([sys.executable,'-X','utf8',str(BASE/'人工検査.py')],capture_output=True,text=True,encoding='utf-8');(folder/'人工検査.log').write_text(r.stdout+r.stderr,encoding='utf-8');A.equal(r.returncode,0,'6主人工');A.need('Ran 6 tests' in r.stderr and r.stderr.rstrip().endswith('OK'),'人工件数と成功');A.equal(maps(),before,'所有/再用code前後同体')
    art=ROOT/'work/117正益と短期波の連続比較/Root停止_新三部品/人工_金融/人工.json';math=ROOT/'work/117正益床の人工を独立検算する/検査/確認.json'
    refs={str(p.resolve()):G.digest(p) for p in (art,math)}
    proof={'成功':True,'停止':False,'市場前':True,'試行':117,'人工主検査数':6,'手製Core会計数':40,'Viewer保存再読資源数':40,'零取引会計数':20,'破壊拒否種数':9,'自然Native本文読取':0,'原板/価格CSV/11月09読取':0,'金融再実行':False,'CSV生成':False,'所有ファイルSHA256':before[0],'再用ファイルSHA256':before[1],'前後不変':True,'人工入力/数式証拠SHA256':refs,'人工ログSHA256':G.digest(folder/'人工検査.log'),'全Raw初回性':False,'限界':'保存点の未保存Target/峰は境界値。全Raw初回性/全床hit/1分bank数値再形成を証明しない。'}
    write(folder/'停止前の確認.json',proof);return proof


def stop(path:Path,sha:str)->dict:
    """
    機能: Rootがレビューした成功proofのコード/人工証拠が同体のときだけ停止する。
    引数: path(Path)、sha(str)。返り値: dictは停止metadata。自然入力は読まない。
    """
    A.equal(G.digest(path),sha,'Rootレビューproof SHA');p=json.loads(path.read_text(encoding='utf-8'));A.need(p['成功'] is True and p['停止'] is False and p['市場前'] is True and p['試行']==117,'停止前proof成功');A.equal(maps(),(p['所有ファイルSHA256'],p['再用ファイルSHA256']),'Rootレビュー後code同体')
    for name,expected in p['人工入力/数式証拠SHA256'].items():A.equal(G.digest(Path(name)),expected,'人工証拠同体')
    A.equal(G.digest(path.parent/'人工検査.log'),p['人工ログSHA256'],'人工ログ同体');out={**p,'停止':True,'停止前確認':{'path':str(path.resolve()),'sha256':sha}};write(BASE/'停止.json',out);return out


def main()->None:
    """
    機能: 停止前人工生成又はRoot専用のレビュー済停止を実行する。
    引数: CLI proof-dir(Path)/stop(bool)/proof(Path)/sha256(str)。返り値: None。
    """
    p=argparse.ArgumentParser();p.add_argument('--proof-dir',type=Path);p.add_argument('--stop',action='store_true');p.add_argument('--proof',type=Path);p.add_argument('--sha256');a=p.parse_args()
    if a.stop:A.need(a.proof is not None and a.sha256 is not None,'RootレビューRef必須');r=stop(a.proof,a.sha256);path=BASE/'停止.json'
    else:A.need(a.proof_dir is not None,'proof出力必須');r=prove(a.proof_dir);path=a.proof_dir/'停止前の確認.json'
    print(json.dumps({'成功':r['成功'],'停止':r['停止'],'試行':117,'path':str(path.resolve()),'sha256':G.digest(path),'所有数':len(r['所有ファイルSHA256']),'再用数':len(r['再用ファイルSHA256'])},ensure_ascii=False))


if __name__=='__main__':main()
