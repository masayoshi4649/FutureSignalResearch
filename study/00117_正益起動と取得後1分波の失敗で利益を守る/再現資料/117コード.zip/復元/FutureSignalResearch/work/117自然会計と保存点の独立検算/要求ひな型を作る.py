"""金融成功の小metadataだけからRoot用の未許可要求ひな型を作る。"""
import argparse
import json
from pathlib import Path
import 金融の独立検算 as A
import 保存の入力ゲート as G

BASE=Path(__file__).resolve().parent
ROOT=BASE.parent.parent
COMPLETIONS={
    'first2':('先頭2場','e95b691c33da0e6ab0cf3e7e732849dabacd8d2dbb739eefd00a3f932109501f'),
    'base54':('元54場','b3e5865e882faec7c45c70eeb75045df3132a37657ddf6d1f05342479a533876'),
    'full70':('全70場','f9d5dfc49bef7f9b2dcf6bba55fe264b689dc2e8312e0e26c4530e4b1d2872e0'),
}


def template(stage:str,output:Path)->dict:
    """
    機能: 指定stageの成功metadataから未固定/未許可ひな型を作る。
    引数: stage(str)、output(Path)。返り値: dict。Native/Raw/CSV本文と実物SHAは読まない。
    """
    label,sha=COMPLETIONS[stage];p=ROOT/'work/117金融F1'/label/'完了.json';A.equal(G.digest(p),sha,'Root金融完了metadata SHA');c=json.loads(p.read_text(encoding='utf-8'));A.need(c['success'] is True and c['condition_sha256']==G.CONDITION_SHA and c['trial']==117 and c['stage']==stage,'同F1成功');A.equal(c['sessions'],G.SIZES[stage],'stage場数');sessions=[r['session'] for r in c['results']]
    stop=BASE/'停止.json';stopref={'path':str(stop),'sha256':G.digest(stop) if stop.exists() else 'Root停止後に設定'}
    return {'version':1,'trial':117,'fixed':False,'stage':stage,'native_read_authorized':False,'legacy_native_read_authorized':False,'condition':{'path':str(ROOT/'work/117進行/F1_117金融条件.json'),'sha256':G.CONDITION_SHA},'completion':{'path':str(p.resolve()),'sha256':sha},'verifier_stop':stopref,'sessions':sessions,'market_paths':{s:'Rootが既存価格metadataから設定/'+s for s in sessions},'output_dir':str(output.resolve()),'independent_execution':'verify_all70_saved_points' if stage=='full70' else 'verify_all_listed_saved_points','原板/価格CSV/11月09読取':False,'注意':'Rootがmarket_paths/停止Refを設定し、別要求へ固定と新Native読取許可を明記する。旧自然Nativeは読まない。'}


def main()->None:
    """
    機能: 上書きせず未許可要求を一つだけ保存する。
    引数: CLI stage(str)/output-dir(Path)/template(Path)。返り値: None。
    """
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=tuple(COMPLETIONS),required=True);p.add_argument('--output-dir',type=Path,required=True);p.add_argument('--template',type=Path,required=True);a=p.parse_args();v=template(a.stage,a.output_dir)
    with a.template.open('x',encoding='utf-8') as f:f.write(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'固定/本文許可':False,'path':str(a.template.resolve()),'sha256':G.digest(a.template)},ensure_ascii=False))


if __name__=='__main__':main()
