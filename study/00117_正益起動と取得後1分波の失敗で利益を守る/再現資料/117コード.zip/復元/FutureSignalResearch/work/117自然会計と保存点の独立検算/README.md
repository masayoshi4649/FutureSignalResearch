# 117の独立会計・保存点とViewer保存

20政策費用条件（S0/W100/P100/H0E/H0M × C0/C5 × D0/D1）を、Rootの同一F1成功要求に列挙された新Nativeだけから検査する。原入口と元Sourceは固定し、金融の元54場Native参照再用と、今回の全N場の独立保存点検査を区別する。新しい金融計算や売買条件変更は行わない。

`金融の独立検算.py` は停止済み113/94の独立数式を本名20設定へ接続し、実注文・要求後原行fill・全配賦・片道38.5円・滑り・実残量/予約・全玉W・保存点DD・flatを確認する。古い政策名へ偽装しない。`保護保存点の独立検算.py` はS0/W100/P100の旧数式再用を、H0E/H0Mの新しい半円整数/Decimalによる独立算術と区別する。

H0では正常返済BBOの費用後W>0による起動、保存firstWholePositiveとの同体、初期L=R−nK、取得価格床、1呼値余地によるゼロ目標昇格、部分返済R/n、floor/target非緩和、峰/通常幅/固定短期幅、nilMark、要求後予約再同期、n0完結を照合する。短期ラッチはActorのID/時刻/Index/Line/出典と完成Witnessへ結ぶ。H0Mの幅ラッチと正常Markでの幅実適用は別に数える。

保存されなかった中間のTarget/峰は境界入力として使う局所検査であり、全Rawの最初起動・全tickの床hit最初性・1分bankの全数値再形成の証明ではない。旧3分公表は保存列へ全値照合するが同秒の物理配送Indexは保存範囲の限界を残す。独立の旧112Native再読は行わず、Root金融成功metadataと新Nativeの旧12比較成功を認証する。Source自然出生照合は自然入力でのみ行い、手製器具では自然FAR生成を証明しない。

`保存集計の共通部.py` は停止111の利益/損失/利益後赤字/DD/時間診断とViewer数式を再用する。Viewerの資源数だけを24から20へ明示変更し、全約定と資源を保存再読する。結果は20条件集計と全20N場別を含む。CSVは別担当の器で生成し、ここでは生成しない。

## 人工とRoot停止

```powershell
python -X utf8 .\work\117自然会計と保存点の独立検算\人工検査.py
python -X utf8 .\work\117自然会計と保存点の独立検算\停止を準備する.py --proof-dir .\work\117自然会計と保存点の独立検算\検査
```

6主人工は手製買売40冊、Viewer40、同器保存再読20、0取引20、金額/配賦/原行/起動/Target/短期ID等の破壊拒否、実first2小metadataの本文未読ゲートを含む。Rootは停止前proofと現物SHAをレビュー後、次を実行する。停止前proofは停止成功や自然会計成功を先取りしない。

```powershell
python -X utf8 .\work\117自然会計と保存点の独立検算\停止を準備する.py --stop --proof <停止前の確認.json絶対path> --sha256 <同SHA>
```

## Root要求と実CLI

```powershell
python -X utf8 .\work\117自然会計と保存点の独立検算\要求ひな型を作る.py --stage first2 --output-dir <新出力先> --template <未許可要求.json>
```

ひな型は `fixed:false/native_read_authorized:false`、旧自然Native読取許可falseで作る。Rootが停止Ref、Viewerの `market_paths` 文字列を確認し、固定・新Native読取許可を明示した別要求へ保存する。価格パスを記録しても価格本文を読まない。完了metadataに含まれるNative以外は受け付けない。

```powershell
python -X utf8 .\work\117自然会計と保存点の独立検算\保存する.py --fixed <Root固定要求> --sha256 <要求SHA> --output <固定新出力先> --metadata-only
python -X utf8 .\work\117自然会計と保存点の独立検算\保存する.py --fixed <Root固定要求> --sha256 <要求SHA> --output <固定新出力先>
```

metadata-onlyは条件/完了/独立停止/コードだけを認証し、Native本文もNative実物SHAも読まない。実行は新Nativeだけを圧縮SHA認証後に開く。結果/一覧/約定を保存再読し、すべての入力とコードの前後SHAが同じ場合だけ保存会計の確認を成功とする。失敗時は不完了を保存し、完成扱いにしない。

原板、価格CSV、11月09、許可外Native、退出後仮想利益、機会損失、次試行探索は対象外。
