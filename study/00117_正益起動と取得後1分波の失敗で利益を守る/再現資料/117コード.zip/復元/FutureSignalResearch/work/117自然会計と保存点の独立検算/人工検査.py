"""117の会計/保存点/Viewer/本文前ゲートを手製Coreと破壊点で検査する。"""
from copy import deepcopy
from decimal import Decimal
import gzip
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
import 金融の独立検算 as A
import 保存集計の共通部 as S
import 保存の入力ゲート as G
import 保存する as R

BASE=Path(__file__).resolve().parent;ROOT=BASE.parent.parent
ART=ROOT/'work/117正益と短期波の連続比較/Root停止_新三部品/人工_金融/人工.json'


def fixture(label:str)->dict:
    """
    機能: Rootの明示手製Coreの当該側だけをSHA認証して読む。
    引数: label(str)。返り値: dict。自然Nativeを読まない。
    """
    manifest=json.loads(ART.read_text(encoding='utf-8'));A.need(manifest['人工'] is True and manifest['市場'] is False,'手製header');ref=manifest['Native'][label];raw=Path(ref['path']).read_bytes();A.equal(hashlib.sha256(raw).hexdigest(),ref['sha256'],'手製Native SHA');return json.loads(gzip.decompress(raw),parse_float=Decimal)


def owned()->dict:
    """
    機能: 人工metadataのstopに使う現所有code集合を求める。
    引数: なし。返り値: dict。
    """
    return {str(p.resolve()):G.digest(p) for p in BASE.iterdir() if p.is_file() and p.suffix in ('.py','.md')}


class Tests(unittest.TestCase):
    """元の手製40冊と0取引/破壊/ゲートを区別する。"""

    def test_core40(self):
        """
        機能: 買売各20の全会計と新旧保存点を確認する。
        引数: self(Tests)。返り値: None。
        """
        for side in ('買い','売り'):
            value=fixture(side);before=repr(value);r=S.inspect_scene(value,artificial=True);self.assertEqual(len(r['checked']),20);self.assertEqual(repr(value),before)

    def test_viewer40_and_statistics(self):
        """
        機能: Viewer40を独立再読し、20条件の金融互換集計を確認する。
        引数: self(Tests)。返り値: None。
        """
        rows={k:[] for k in A.KEYS}
        for side in ('買い','売り'):
            v=fixture(side);r=S.inspect_scene(v,artificial=True)
            with tempfile.TemporaryDirectory(dir=BASE) as t:
                resources=S.save_viewer(v,Path(t),'手製参照/価格本文なし');checked=S.verify_viewer(v,Path(t),resources);self.assertEqual(checked['資源'],20)
                for k in A.KEYS:
                    row=S.summarize_book(v['actual']['books'][k],r['checked'][k]);row['session']=side;rows[k].append(row)
        for k in A.KEYS:
            c=S.combine(rows[k]);self.assertEqual(c['場数'],2);self.assertEqual(c['net_yen'],sum(r['net_yen'] for r in rows[k]));self.assertIn('held_seconds',c['頻度診断']);self.assertIn('quantity_seconds',c['頻度診断'])

    def test_saved_roundtrip(self):
        """
        機能: 手製1場20の結果/catalog/tradesを実保存と同じ器で生成し再読する。
        引数: self(Tests)。返り値: None。自然CLIゲートを飛ばすのはこの人工呼出しだけ。
        """
        m=json.loads(ART.read_text(encoding='utf-8'));ref=m['Native']['買い'];v=fixture('買い');sid=v['actual']['scope']['session']['id']
        with tempfile.TemporaryDirectory(dir=BASE) as d:
            out=Path(d)/'新規';p={'metadata_only':False,'before':{},'request':{'market_paths':{sid:'手製価格の文字列'},'condition':{'sha256':'手製条件'},'completion':{'sha256':'手製完了'},'verifier_stop':{'sha256':'手製停止'}},'rows':[{'session':sid,'native':ref}],'stage':'artificial','request_sha256':'手製要求'}
            c=R.execute(p,out,artificial=True);self.assertEqual(c['会計数'],20);self.assertEqual(len(json.loads((out/'一覧.resources.json').read_text(encoding='utf-8'))['resources']),20)

    def test_zero20(self):
        """
        機能: 空取引全20を金融分母とViewer資源へ残す。
        引数: self(Tests)。返り値: None。Source自然生成/旧12実対照を新証明しない器具。
        """
        v=fixture('買い');a=v['actual'];a['publications']=[];a['resets']=[]
        for k in a['counts']:a['counts'][k]=0
        for b in a['books'].values():
            for key in ('orders','fills','positions','source_events'):b[key]=[]
            for key in b['metrics']:b['metrics'][key]=0
            for key in b['totals']:b['totals'][key]=0
            for key in b['account']:b['account'][key]=0 if key in ('max_drawdown','count','max_gap_seconds') else None
        v['source']['books']={k:deepcopy(a['books'][k]) for k in A.KEYS[:4]};r=S.inspect_scene(v,artificial=True)
        with tempfile.TemporaryDirectory(dir=BASE) as d:
            resources=S.save_viewer(v,Path(d),'空取引価格未読');self.assertEqual(S.verify_viewer(v,Path(d),resources),{'資源':20,'約定行':0,'全残0':True})
        self.assertTrue(all(r['checked'][k]['totals']['net_yen']==0 for k in A.KEYS))

    def test_finance_and_h0_corruptions(self):
        """
        機能: 金額/配賦/取得/原行/予約/H0Target/flag/bridgeの破壊を拒否する。
        引数: self(Tests)。返り値: None。
        """
        original=fixture('買い')
        changes=[lambda b:b['fills'][0].__setitem__('fee_yen',0),lambda b:b['fills'][1]['allocations'][0].__setitem__('net_yen',0),lambda b:b['positions'][0].__setitem__('entry_price',999),lambda b:b['fills'][1]['quote'].__setitem__('index',0),lambda b:b['positions'][0]['marks']['first_whole_positive'].__setitem__('whole_net',0),lambda b:b['positions'][0]['protection117']['initial'].__setitem__('minimum_floor',10),lambda b:b['positions'][0]['protection117']['first_activation']['decision']['h0_117'].__setitem__('initial_target_half_yen',0),lambda b:b['positions'][0]['protection117']['first_narrowing']['snapshot']['h0_117']['narrow'].__setitem__('id','偽完成'),lambda b:b['positions'][0]['protection117']['final_state'].__setitem__('sequence',1)]
        for change in changes:
            v=deepcopy(original);change(v['actual']['books']['H0M_C0_D0'])
            with self.assertRaises(ValueError):S.inspect_scene(v,artificial=True)

    def test_metadata_body_guard(self):
        """
        機能: 実first2小metadataの正例/型差/未許可を本文前に確認する。
        引数: self(Tests)。返り値: None。Nativeのopen/hashは禁止して呼び出す。
        """
        condition=ROOT/'work/117進行/F1_117金融条件.json';complete=ROOT/'work/117金融F1/先頭2場/完了.json'
        with tempfile.TemporaryDirectory(dir=BASE) as d:
            d=Path(d);stop=d/'手製stop.json';stop.write_text(json.dumps({'成功':True,'停止':True,'市場前':True,'試行':117,'所有ファイルSHA256':owned(),'再用ファイルSHA256':{}},ensure_ascii=False),encoding='utf-8')
            q={'version':1,'trial':117,'fixed':True,'stage':'first2','native_read_authorized':True,'legacy_native_read_authorized':False,'condition':{'path':str(condition),'sha256':G.CONDITION_SHA},'completion':{'path':str(complete),'sha256':'e95b691c33da0e6ab0cf3e7e732849dabacd8d2dbb739eefd00a3f932109501f'},'verifier_stop':{'path':str(stop),'sha256':G.digest(stop)},'sessions':['2026-09-21_Day','2026-09-21_Night'],'market_paths':{s:'文字列だけ' for s in ('2026-09-21_Day','2026-09-21_Night')},'output_dir':str(d/'out')}
            original=Path.read_bytes
            def guarded(path):
                """
                機能: metadata検査がNative実物を開いたら人工を失敗させる。
                引数: path(Path)。返り値: bytes。
                """
                if str(path).endswith('.Native.json.gz'):raise AssertionError('本文前ゲートのNative読取')
                return original(path)
            from unittest.mock import patch
            with patch.object(Path,'read_bytes',guarded):
                self.assertEqual(len(G.validate(q,d/'out',True)['rows']),2)
                for key,value in (('fixed',False),('native_read_authorized',False),('native_read_authorized',1),('legacy_native_read_authorized',True),('stage','full70')):
                    bad=deepcopy(q);bad[key]=value
                    with self.assertRaises(ValueError):G.validate(bad,d/'out',True)


if __name__=='__main__':unittest.main(verbosity=2)
