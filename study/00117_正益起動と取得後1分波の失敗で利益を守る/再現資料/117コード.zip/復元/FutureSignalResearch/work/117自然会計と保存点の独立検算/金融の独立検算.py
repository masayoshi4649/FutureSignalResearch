"""117本名20会計を、停止113/94の価格・費用・配賦・所有数式へ接続する。"""
from pathlib import Path
import hashlib
import importlib.util

ROOT=Path(__file__).resolve().parents[2]
PRIOR=ROOT/'work/113起動前の構造失効を執行する会計/金融の独立検算.py'
PRIOR_SHA='52e0e640e27209faa65894289309bdfE525b09ea050cbd9544d47eda1a89ef2f'.lower()


def module(path:Path,name:str):
    """
    機能: 読取専用のPython数式を明示ファイルから参照する。
    引数: path(Path)、name(str)。返り値: module。Goや金融CLIは実行しない。
    """
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m


if hashlib.sha256(PRIOR.read_bytes()).hexdigest()!=PRIOR_SHA:raise ValueError('停止113会計SHA差')
OLD=module(PRIOR,'117が再用する停止113会計')
BASE,need,equal,number,money=OLD.BASE,OLD.need,OLD.equal,OLD.number,OLD.money
CONFIGS=tuple({'policy':p,'slip_pts':c,'delay_seconds':d} for p in ('S0','W100','P100','H0E','H0M') for c in (0,5) for d in (0,1))


def key_for(config:dict)->str:
    """
    機能: 117の本名20だけを受理する。
    引数: config(dict)。返り値: str。H0を旧政策へ偽装しない。
    """
    need(config in CONFIGS and set(config)=={'policy','slip_pts','delay_seconds'},'117本名20条件');return f"{config['policy']}_C{config['slip_pts']}_D{config['delay_seconds']}"


BY_KEY={key_for(c):c for c in CONFIGS};KEYS=tuple(BY_KEY)


def verify_finance(book:dict,config:dict)->dict:
    """
    機能: 実注文/fill/全配賦/費用/保存MTM/実残予約/flatを旧独立数式で検算する。
    引数: book/config(dict)。返り値: dictはtotals/counts/positions/orders/timeline/book。
    """
    equal(book['key'],key_for(config),'117実key');equal(book['config'],config,'117実Config');before=repr(book)
    result=OLD.PURE_ACCOUNTING(book,config,config['policy']);OLD.OLD.verify_source_reservations(book,result)
    need(all(o.get('entry_invalidation_point') is None for o in book['orders']),'117に旧E失効なし')
    need(all(not f.get('entry_invalidation',False) for f in book['fills']),'117に旧E実fillなし')
    for f in book['fills']:need(f['quote']['source_line']>result['orders'][f['order_id']]['request_quote']['source_line'],'要求後の物理行')
    for p in book['positions']:
        need((p.get('protection117') is None)==(config['policy']=='S0'),'S0のみ純保護なし')
        need((p.get('shortwave117') is not None)==(config['policy']=='H0M'),'H0Mのみ短期監視')
    for name in ('entry_invalidated_positions','entry_invalidation_exit_requests','entry_invalidation_exit_fills'):equal(book['metrics'].get(name,0),0,'旧E対象外/'+name)
    equal(book['metrics']['timer_calls'],0,'117架空timerなし')
    if config['policy']!='S0':
        count=sum(p['atr'] is None for p in book['positions']);equal(book['metrics'].get('atr_unknown_fallback_positions',0),count,'取得時ATR未知固定');result['counts']['atr_unknown_fallback_positions']=count
    equal(repr(book),before,'会計原値不変');return {**result,'book':book}
