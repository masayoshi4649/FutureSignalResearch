"""117Root要求に固定したN場20冊を独立会計と保存点へ照合し、Viewerを保存再読する。"""
import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path
import 金融の独立検算 as A
import 保存集計の共通部 as S
import 保存の入力ゲート as G


def write(path:Path,value)->None:
    """
    機能: 新しい成果JSONをUTF8で一度だけ保存する。
    引数: path(Path)、value(JSON値)。返り値: None。
    """
    with path.open('x',encoding='utf-8') as f:f.write(json.dumps(value,ensure_ascii=False,indent=2,default=A.BASE.serial,allow_nan=False)+'\n')


def execute(prepared:dict,output:Path,artificial:bool=False)->dict:
    """
    機能: 許可された新Nativeだけを認証し、全会計・Viewerを新規保存する。
    引数: prepared(dict)、output(Path)、artificial(bool)。返り値: dictは保存確認。Raw/旧Native/CSVは読まない。
    """
    A.need(not prepared['metadata_only'],'metadataから本文実行しない');before=dict(prepared['before']);request=prepared['request'];rows=[];resources=[];proofs=[];viewer_rows=0;counts=Counter();output.mkdir(parents=True)
    try:
        for row in prepared['rows']:
            ref=row['native'];path=Path(ref['path']);raw=path.read_bytes();A.equal(hashlib.sha256(raw).hexdigest(),ref['sha256'],'Root明示Native SHA');before[str(path.resolve())]=ref['sha256'];value=json.loads(gzip.decompress(raw),parse_float=A.BASE.Decimal)
            A.equal(value['actual']['scope']['session']['id'],row['session'],'CompletionとNative場');checked=S.inspect_scene(value,artificial=artificial)
            current=S.save_viewer(value,output,request['market_paths'][row['session']]);v=S.verify_viewer(value,output,current);viewer_rows+=v['約定行'];resources.extend(current)
            for key,c in A.BY_KEY.items():
                f=checked['checked'][key];r=S.summarize_book(value['actual']['books'][key],f);r.update(session=row['session'],key=key,policy=c['policy'],slip_pts=c['slip_pts'],delay_seconds=c['delay_seconds']);rows.append(r);counts.update(f['protection_counts']['counts'])
            proofs.append({'session':row['session'],'native':ref,'Source':checked['source'],'旧112比較':checked['reference112'],'Viewer':v})
        result={'試行':117,'成功':True,'stage':prepared['stage'],'場数':len(prepared['rows']),'会計数':len(rows),'主key':list(A.KEYS),'Actor設定':A.BY_KEY,'金融条件SHA256':request['condition']['sha256'],'金融完了SHA256':request['completion']['sha256'],'集計':{k:S.combine([r for r in rows if r['key']==k]) for k in A.KEYS},'場別':rows,'入力Ref':{'金融条件':request['condition'],'金融完了':request['completion']},'限界':['独立会計と少数保存点。原板未読。','H0の未保存Target/峰は境界値として用いる局所監査。全Raw初回性は別。','旧112全12と旧Source全文はGo成功を認証。旧自然Nativeは読まない。']}
        write(output/'結果.json',result);write(output/'一覧.resources.json',{'schema_version':1,'path_base':'catalog','resources':resources})
        A.equal(json.loads((output/'結果.json').read_text(encoding='utf-8'),parse_float=A.BASE.Decimal),json.loads(json.dumps(result,default=A.BASE.serial),parse_float=A.BASE.Decimal),'結果保存再読')
        after={p:G.digest(Path(p)) for p in before};A.equal(before,after,'入力コード/Native前後不変')
        outputs={p.name:G.digest(p) for p in output.iterdir() if p.is_file()}
        check={'成功':True,'試行':117,'stage':prepared['stage'],'場数':len(prepared['rows']),'会計数':len(rows),'金融条件SHA256':request['condition']['sha256'],'金融完了SHA256':request['completion']['sha256'],'独立停止SHA256':request['verifier_stop']['sha256'],'保存要求SHA256':prepared['request_sha256'],'出力SHA256':outputs,'全残玉予約0':True,'不一致数':0,'旧112全金融比較':12*len(prepared['rows']),'全Source111同体':True,'資源':len(resources),'Viewer約定行':viewer_rows,'前後不変':True,'前':before,'後':after,'保護保存点件数':dict(counts),'場別検査':proofs,'原板再走':False,'全Raw初回性':False,'CSV生成':False,'11月09読取':False}
        write(output/'保存会計の確認.json',check);return check
    except Exception as exc:
        write(output/'不完了.json',{'成功':False,'試行':117,'stage':prepared['stage'],'理由':str(exc),'完成扱い禁止':True});raise


def main()->None:
    """
    機能: Root固定要求だけを受け、metadata-only又は新規保存を実行する。
    引数: CLI fixed(Path)/sha256(str)/output(Path)/metadata-only(bool)。返り値: None。
    """
    p=argparse.ArgumentParser();p.add_argument('--fixed',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--metadata-only',action='store_true');a=p.parse_args();raw=a.fixed.read_bytes();A.equal(hashlib.sha256(raw).hexdigest(),a.sha256,'Root要求SHA');request=json.loads(raw);prepared=G.validate(request,a.output,a.metadata_only);prepared['request_sha256']=a.sha256;prepared['before'][str(a.fixed.resolve())]=a.sha256
    if a.metadata_only:print(json.dumps({'成功':True,'metadata_only':True,'試行':117,'stage':prepared['stage'],'場数':len(prepared['rows']),'会計数':20*len(prepared['rows']),'Native本文/実物SHA読取':0},ensure_ascii=False));return
    r=execute(prepared,a.output);print(json.dumps({'成功':True,'試行':117,'場数':r['場数'],'会計数':r['会計数'],'検算SHA256':G.digest(a.output/'保存会計の確認.json'),'結果SHA256':r['出力SHA256']['結果.json']},ensure_ascii=False))


if __name__=='__main__':main()
