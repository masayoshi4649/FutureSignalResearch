"""停止111の集計/Source/Viewer式を117本名20へ接続する。価格は参照文字列だけ。"""
import ast
import hashlib
import importlib.util
import inspect
import json
from pathlib import Path
import sys
import textwrap
from types import FunctionType
import 金融の独立検算 as A
import 保護保存点の独立検算 as P

ROOT=Path(__file__).resolve().parents[2]
PRIOR=ROOT/'work/111連続保護の独立保存/集計.py'
if hashlib.sha256(PRIOR.read_bytes()).hexdigest()!='c6e6df9067da9452a978881325f3e96a677d946e3e5643eb3614d41684d0dbc0':raise ValueError('停止111保存SHA差')
sys.path.insert(0,str(PRIOR.parent))
try:OLD=A.module(PRIOR,'117が再用する停止111保存')
finally:sys.path.pop(0)
SPACE={**vars(OLD),'A':A,'KEYS':A.KEYS,'BY_KEY':A.BY_KEY};BASE=A.BASE


def borrow(name:str):
    """
    機能: 旧codeそのものを新20設定のグローバルへ接続する。
    引数: name(str)。返り値: function。数式と本名を変えない。
    """
    o=getattr(OLD,name);f=FunctionType(o.__code__,SPACE,name,o.__defaults__,o.__closure__);SPACE[name]=f;return f


profit_statistics=borrow('profit_statistics');holding_diagnostics=borrow('holding_diagnostics');summarize_book=borrow('summarize_book');combine=borrow('combine');source_projection=borrow('source_projection');SOURCE=borrow('verify_source')


def viewer_reader():
    """
    機能: 保存再読の金融数式は保持し資源分母だけ24から20へ派生する。
    引数: なし。返り値: function。
    """
    tree=ast.parse(textwrap.dedent(inspect.getsource(OLD.verify_viewer)));changes=0
    for n in ast.walk(tree):
        if isinstance(n,ast.Call) and ast.unparse(n)=="equal(len(resources), 24, '保存再読24資源')":n.args[1]=ast.Constant(20);n.args[2]=ast.Constant('117保存再読20資源');changes+=1
        if isinstance(n,ast.Dict):
            for i,k in enumerate(n.keys):
                if isinstance(k,ast.Constant) and k.value=='資源':A.equal(ast.literal_eval(n.values[i]),24,'旧Viewer資源数');n.values[i]=ast.Constant(20);changes+=1
    A.equal(changes,2,'Viewer資源数二箇所だけ');space=dict(SPACE);exec(compile(ast.fix_missing_locations(tree),__file__+':Viewer20','exec'),space);return space['verify_viewer']


verify_viewer=viewer_reader()


def inspect_scene(value:dict,artificial:bool=False)->dict:
    """
    機能: 117の実20冊を会計/保存点/Sourceへ独立照合する。
    引数: value(dict)、artificial(bool)。返り値: dictはchecked/source/旧12のGo認証。
    """
    a=value['actual'];A.need(value['version']==a['version']==1 and value['trial']==a['trial']==117 and a['complete'],'117完結Native');A.equal(a['configurations'],list(A.CONFIGS),'実20宣言');A.equal(set(a['books']),set(A.KEYS),'20集合')
    A.equal(a['scope']['session'],value['source']['session'],'Source同場');A.equal(a['scope']['contract'],value['source']['contract'],'Source同限月');A.equal(a['entry_grid_seconds'],None,'元の連続時計');A.equal(a['extra_opening_quiet_seconds'],0,'追加静観なし');A.equal(a['explicit_timers'],0,'新timerなし')
    A.equal(a['counts']['publications'],len(a['publications'] or []),'旧3分公表数');A.equal(a['counts']['resets'],len(a['resets'] or []),'旧3分reset数')
    checked={};ctx={k:v for k,v in a.items() if k!='books'}
    for k,c in A.BY_KEY.items():
        b=a['books'][k];A.equal(b['metrics']['rows'],a['counts']['rows'],'全20受理行数');A.equal(b['metrics']['bad_quote_rows'],a['counts']['bad_quotes'],'全20異常気配行数');f=A.verify_finance(b,c);f['protection_counts']=P.verify_protection(b,c,f,ctx);checked[k]=f
    source=SOURCE(value,artificial);source['全20の元通知同体']=source.pop('全24の元通知同体')
    ref=value['reference112'];A.need(ref['comparisons']==12 and ref['all_financial_equal'] is True and ref['source_equal'] is True,'旧112全12のGo成功認証')
    return {'checked':checked,'source':source,'reference112':{'comparisons':12,'all_financial_equal':True,'source_equal':True,'独立旧Native再読':False,'証拠範囲':'認証済みRoot金融完了とNative内のGo比較成功。許可外の旧自然Nativeは読まない。'}}


def save_viewer(value:dict,output:Path,market_path:str)->list:
    """
    機能: 全20条件の実約定をViewer JSONLへ保存する。
    引数: value(dict)、output(Path)、market_path(str)。返り値: listは資源metadata。価格本文は読まない。
    """
    resources=[];sid=value['actual']['scope']['session']['id']
    for key in A.KEYS:
        name=f'117_{key}_{sid}.trades.jsonl'
        with (output/name).open('x',encoding='utf-8',newline='\n') as f:
            for row in BASE.viewer_trades(value['actual']['books'][key]):f.write(json.dumps(row,ensure_ascii=False,default=BASE.serial,allow_nan=False)+'\n')
        resources.append({'id':f'117_{key}_{sid}','title':f'正益と短期複合保護 {key} {sid}','symbol':'NK225','product':'NK225mini','session':sid,'method_id':key,'point_value':100,'pnl_format':'trades','pnl_basis':'net','pnl_path':name,'market_path':market_path})
    return resources
