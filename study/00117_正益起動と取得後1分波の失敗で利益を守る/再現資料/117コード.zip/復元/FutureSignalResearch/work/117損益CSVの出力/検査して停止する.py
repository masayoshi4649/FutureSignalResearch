"""Rootレビュー後だけ117CSVの準備を新規停止する。金融結果は読まない。"""
from pathlib import Path
import argparse
import hashlib
import json

OWN=Path(__file__).resolve().parent
OWNED=('入力と候補.mjs','出力する.mjs','CSVを独立再読する.py','人工検査.py','README.md',Path(__file__).name)


def digest(path: Path) -> str:
    """
    機能: 明示コードと人工metadataのSHAを得る。
    引数: path(Path)。返り値: strは全bytes指紋。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: Rootレビュー・既成功人工と所有現物を認証して停止する。
    引数: CLI reviewed(bool)、artificial-proof(Path)、sha256(str)。返り値: None。
    """
    parser=argparse.ArgumentParser();parser.add_argument('--reviewed',action='store_true',required=True)
    parser.add_argument('--artificial-proof',type=Path,required=True);parser.add_argument('--sha256',required=True);args=parser.parse_args()
    target=OWN/'停止.json'
    if target.exists() or digest(args.artificial_proof)!=args.sha256:raise ValueError('未作成停止と成功人工Refが必要')
    proof=json.loads(args.artificial_proof.read_text(encoding='utf-8'))
    if proof['試行']!=117 or proof['成功'] is not True or proof['市場前'] is not True or proof['停止'] is not False:raise ValueError('人工準備の成功が必要')
    codes={str((OWN/name).resolve()):digest(OWN/name) for name in OWNED}
    if codes!=proof['所有ファイルSHA256']:raise ValueError('人工後の所有code差')
    for name,expected in proof['再用コードSHA256'].items():
        if digest(Path(name))!=expected:raise ValueError('人工の旧依存code差')
    if digest(Path(proof['操作marker']['path']))!=proof['操作marker']['sha256']:raise ValueError('操作marker差')
    for key in ('node','artifact_package'):
        reference=proof['環境参照'][key]
        if digest(Path(reference['path']))!=reference['sha256']:raise ValueError('環境参照差:'+key)
    value={'再用コードSHA256':proof['再用コードSHA256'],'操作marker':proof['操作marker'],'試行':117,'成功':True,'停止':True,'市場前':True,'所有ファイルSHA256':codes,
           '人工':{'path':str(args.artificial_proof.resolve()),'sha256':args.sha256},'前後不変':True,
           '自然Raw/Native/価格CSV/損益CSV本文読取':False,'金融再実行':False,'Rootレビュー後':True}
    value['環境参照']=proof['環境参照']
    with target.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'停止':{'path':str(target),'sha256':digest(target)}},ensure_ascii=False))


if __name__=='__main__':main()
