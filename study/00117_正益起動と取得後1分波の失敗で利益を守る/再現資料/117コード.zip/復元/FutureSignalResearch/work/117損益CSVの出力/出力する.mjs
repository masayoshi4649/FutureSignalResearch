/**
 * 独立保存済みの117損益を、候補別集計と全セッションのCSVへ出力する。
 * @param {string[]} process.argv - 結果JSON、期待SHA256、新規出力先の順。
 * @returns {Promise<void>} 再計算・検算したCSV二点と確認JSONを保存する。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {Workbook} from '@oai/artifact-tool';
import {openInput,KEYS,keyFor} from './入力と候補.mjs';

/**
 * 明示した入力・出力の指紋を計算する。
 * @param {Uint8Array|string} value - 対象バイト列又はUTF-8文字列。
 * @returns {string} SHA256。
 */
function sha(value) { return crypto.createHash('sha256').update(value).digest('hex'); }

/**
 * 保存された有限数値と計算値を比較する。
 * @param {number} actual - 計算値。
 * @param {number} expected - 保存値。
 * @param {string} label - 照合する項目。
 * @returns {void} 不一致は例外にする。
 */
function equalNumber(actual, expected, label) {
  assert.ok(Number.isFinite(actual) && Number.isFinite(expected), label);
  assert.ok(Math.abs(actual - expected) <= 0.000001, `${label}: ${actual} / ${expected}`);
}

/**
 * 分母が0の比率を空欄として、数値0と区別して検査する。
 * @param {number|null} actual - 計算値又は未定義。
 * @param {number|null} expected - 保存値又は未定義。
 * @param {string} label - 検査する項目。
 * @returns {void} 型又は値の差は例外にする。
 */
function equalNullable(actual, expected, label) {
  if (actual === null || expected === null) assert.equal(actual, expected, label);
  else equalNumber(actual, expected, label);
}

/**
 * 取引単位の利益と損失から比率の意味を検査する。
 * @param {Object} row - 場別又は候補別の独立集計。
 * @param {string} label - 対象ID。
 * @returns {void} 利益・損失の符号、件数、比率が違えば例外。
 */
function inspectMetrics(row, label) {
  assert.ok(row.positive_yen >= 0 && row.negative_yen <= 0, label);
  equalNumber(row.positive_yen + row.negative_yen, row.net_yen, `${label}/利益損失と純額`);
  assert.equal(row.positive_positions + row.negative_positions + row.zero_positions, row.positions, label);
  equalNullable(row.negative_yen === 0 ? null : row.positive_yen / -row.negative_yen, row.PF, `${label}/PF`);
  equalNullable(row.positions === 0 ? null : row.positive_positions / row.positions, row.win_rate, `${label}/勝率`);
  const gain = row.positive_positions === 0 ? null : row.positive_yen / row.positive_positions;
  const loss = row.negative_positions === 0 ? null : row.negative_yen / row.negative_positions;
  equalNullable(gain, row.average_profit_yen, `${label}/平均利益`);
  equalNullable(loss, row.average_loss_yen, `${label}/平均損失`);
  equalNullable(gain === null || loss === null ? null : gain / -loss, row.average_profit_loss_ratio, `${label}/平均損益比`);
}

/**
 * 正益経験の分母・赤字件数を検査して表示用の期待比率を返す。
 * @param {Object} row - 原本の場別又は集計。
 * @param {string} label - 検査対象。
 * @returns {number|null} 正益経験建玉を分母とした百分率。分母0はnull。
 */
function experiencedRate(row, label) {
  assert.ok(Number.isSafeInteger(row.whole_positive_positions) && row.whole_positive_positions >= 0 && row.whole_positive_positions <= row.positions, label + '/正益経験分母');
  assert.ok(Number.isSafeInteger(row.whole_positive_closed_negative) && row.whole_positive_closed_negative >= 0 && row.whole_positive_closed_negative <= row.whole_positive_positions, label + '/正益経験後赤字の包含');
  return row.whole_positive_positions === 0 ? null : row.whole_positive_closed_negative / row.whole_positive_positions * 100;
}

/**
 * CSVの文字列フィールドに必要な引用符だけを加える。
 * @param {string|number|null} value - 表の値。nullは未定義の空欄。
 * @returns {string} RFC4180のフィールド。
 */
function field(value) {
  const text = value == null ? '' : String(value);
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

/**
 * 計算済みの表をUTF-8 BOM付きCSVにする。
 * @param {Object} sheet - artifact-toolの表。
 * @param {number} rows - ヘッダ込み行数。
 * @param {number} columns - 列数。
 * @returns {string} 改行CRLFのCSV。
 */
function csv(sheet, rows, columns) {
  return '\uFEFF' + sheet.getRangeByIndexes(0, 0, rows, columns).values.map(row => row.map(field).join(',')).join('\r\n') + '\r\n';
}

// ----------------------------------------
// 元Source連続時計の五政策を本名keyで結合し、独立保存の成立実績だけを表へ渡す。
const {input,expectedSHA,output,data,artificial,beforeRefs,rootRequest,rawStatus,execution}=await openInput(process.argv.slice(2));
const keys=data['主key'],sessions=data['場数'];assert.deepEqual(keys,KEYS);assert.equal(data['場別'].length,20*sessions);
const common=['新規件数','新規枚数','勝ち件数','負け件数','同値件数','勝率パーセント','利益総額円','損失総額円','PF','平均利益円','平均損失円','平均利益損失比','粗損益円','手数料円','追加滑り円','純損益円'];
const protection=['費用後正益を経験した建玉数','建玉全体の正益後赤字件数','正益経験建玉の最終赤字率パーセント','建玉全体の正益後赤字額円','追尾起動件数','追尾起動後赤字件数','追尾起動後赤字額円'];
const summaryHeader=['試行','保護政策','条件ID','セッション数','片道追加滑りpt','仮定遅延秒',...common,'保存点連結時価DD円',...protection,'保有時間秒','数量秒','判断時計','Raw初回性監査範囲','独立検算の実行区分'];
const detailHeader=['試行','保護政策','条件ID','開始日JST','セッション','期間区分','片道追加滑りpt','仮定遅延秒',...common,'累計収支円','場内時価DD円',...protection,'保有時間秒','数量秒','判断時計','Raw初回性監査範囲','独立検算の実行区分'];
const additive=['positions','entry_quantity','close_quantity','positive_positions','negative_positions','zero_positions','positive_yen','negative_yen','gross_yen','fee_yen','slip_yen','net_yen','whole_positive_positions','whole_positive_closed_negative','whole_positive_closed_negative_yen','protection_activated_positions','activated_closed_negative','activated_closed_negative_yen'];
const summaryObjects=[],detailObjects=[],checks=[];

/**
 * 金融集計を同じ意味のCSV列へ一度写す。
 * @param {Object} row - 場別又は候補集計。
 * @returns {Object} 基礎金融と正益経験の表示値。
 */
function financial(row){return {'新規件数':row.positions,'新規枚数':row.entry_quantity,'勝ち件数':row.positive_positions,'負け件数':row.negative_positions,'同値件数':row.zero_positions,'勝率パーセント':row.win_rate===null?null:row.win_rate*100,'利益総額円':row.positive_yen,'損失総額円':row.negative_yen,'PF':row.PF,'平均利益円':row.average_profit_yen,'平均損失円':row.average_loss_yen,'平均利益損失比':row.average_profit_loss_ratio,'粗損益円':row.gross_yen,'手数料円':row.fee_yen,'追加滑り円':row.slip_yen,'純損益円':row.net_yen,'費用後正益を経験した建玉数':row.whole_positive_positions,'建玉全体の正益後赤字件数':row.whole_positive_closed_negative,'正益経験建玉の最終赤字率パーセント':experiencedRate(row,'正益経験'),'建玉全体の正益後赤字額円':row.whole_positive_closed_negative_yen,'追尾起動件数':row.protection_activated_positions,'追尾起動後赤字件数':row.activated_closed_negative,'追尾起動後赤字額円':row.activated_closed_negative_yen};}

for(const key of keys){
  const config=data['Actor設定'][key],aggregate=data['集計'][key];assert.equal(keyFor(config),key);assert.ok(['S0','W100','P100','H0E','H0M'].includes(config.policy));
  const rows=data['場別'].filter(r=>r.key===key).sort((a,b)=>a.session.localeCompare(b.session));assert.equal(rows.length,sessions);assert.equal(new Set(rows.map(r=>r.session)).size,sessions);
  const sums=Object.fromEntries(additive.map(k=>[k,0]));let cumulative=0,held=0,quantitySeconds=0;
  for(const row of rows){
    assert.match(row.session,/^2026-\d{2}-\d{2}_(Day|Night)$/);assert.ok(['original54','additional16'].includes(row.history_class));inspectMetrics(row,key+'/'+row.session);
    equalNumber(row.gross_yen-row.fee_yen-row.slip_yen,row.net_yen,'費用控除');equalNumber(row.closed_net_yen,row.net_yen,'場内完結');assert.equal(row.close_quantity,row.entry_quantity);
    equalNumber(row.fee_yen,77*row.entry_quantity,'mini往復77円');equalNumber(row.slip_yen,200*config.slip_pts*row.entry_quantity,'両道滑り円');
    for(const name of ['open_buy','open_sell','pending_buy','pending_sell'])assert.equal(row[name],0);
    for(const name of additive){assert.ok(Number.isFinite(row[name]),key+'/'+name);sums[name]+=row[name];}
    if(config.policy==='S0')assert.equal(row.protection_activated_positions,0,'S0に追加保護起動を混入');
    const duration=row['頻度診断'];assert.ok(duration&&typeof duration==='object');const h=duration.held_seconds??0,q=duration.quantity_seconds??0;assert.ok(Number.isFinite(h)&&h>=0&&Number.isFinite(q)&&q>=0);held+=h;quantitySeconds+=q;cumulative+=row.net_yen;
    const [date,kind]=row.session.split('_');
    detailObjects.push({'試行':117,'保護政策':config.policy,'条件ID':key,'開始日JST':date+' JST','セッション':kind==='Day'?'デイ':'ナイト','期間区分':row.history_class==='original54'?'元54場':'追加16場','片道追加滑りpt':config.slip_pts,'仮定遅延秒':config.delay_seconds,...financial(row),'累計収支円':cumulative,'場内時価DD円':row['場内時価DD'],'保有時間秒':h,'数量秒':q,'判断時計':'元Source連続','Raw初回性監査範囲':rawStatus,'独立検算の実行区分':execution});
  }
  if(!artificial){assert.equal(rows.filter(r=>r.history_class==='original54').length,54);assert.equal(rows.filter(r=>r.history_class==='additional16').length,16);}
  for(const name of additive)equalNumber(sums[name],aggregate[name],key+'/'+name);inspectMetrics(aggregate,key);equalNumber(held,aggregate['頻度診断'].held_seconds??0,'保有時間');equalNumber(quantitySeconds,aggregate['頻度診断'].quantity_seconds??0,'数量秒');
  summaryObjects.push({'試行':117,'保護政策':config.policy,'条件ID':key,'セッション数':sessions,'片道追加滑りpt':config.slip_pts,'仮定遅延秒':config.delay_seconds,...financial(aggregate),'保存点連結時価DD円':aggregate['保存点連結時価DD'],'保有時間秒':held,'数量秒':quantitySeconds,'判断時計':'元Source連続','Raw初回性監査範囲':rawStatus,'独立検算の実行区分':execution});
  checks.push({条件ID:key,場数:sessions,件数:sums.positions,枚数:sums.entry_quantity,純額:sums.net_yen});
}
for(const [name,expected] of Object.entries(beforeRefs))assert.equal(sha(await fs.readFile(name)),expected,'本文前後認証');
const workbook=Workbook.create(),summarySheet=workbook.worksheets.add('候補別集計'),detailSheet=workbook.worksheets.add('全セッション');
const summaryRows=summaryObjects.map(r=>summaryHeader.map(h=>r[h])),detailRows=detailObjects.map(r=>detailHeader.map(h=>r[h]));
detailSheet.getRangeByIndexes(1,detailHeader.indexOf('開始日JST'),detailRows.length,1).setNumberFormat('@');
summarySheet.getRangeByIndexes(0,0,summaryRows.length+1,summaryHeader.length).values=[summaryHeader,...summaryRows];detailSheet.getRangeByIndexes(0,0,detailRows.length+1,detailHeader.length).values=[detailHeader,...detailRows];

/**
 * 0始まり列番号をA1列表記へ変換する。
 * @param {number} index - 非負列番号。
 * @returns {string} Excelの列記号。
 */
function column(index){let n=index+1,out='';while(n>0){n--;out=String.fromCharCode(65+n%26)+out;n=Math.floor(n/26);}return out;}
for(const [sheet,objects,headers] of [[summarySheet,summaryObjects,summaryHeader],[detailSheet,detailObjects,detailHeader]]){
  const col=Object.fromEntries(headers.map((h,i)=>[h,column(i)]));
  sheet.getRangeByIndexes(1,headers.indexOf('純損益円'),objects.length,1).formulas=objects.map((_,i)=>[`=${col['粗損益円']}${i+2}-${col['手数料円']}${i+2}-${col['追加滑り円']}${i+2}`]);
  sheet.getRangeByIndexes(1,headers.indexOf('正益経験建玉の最終赤字率パーセント'),objects.length,1).formulas=objects.map((_,i)=>[`=IF(${col['費用後正益を経験した建玉数']}${i+2}=0,"",${col['建玉全体の正益後赤字件数']}${i+2}/${col['費用後正益を経験した建玉数']}${i+2}*100)`]);
  sheet.showGridLines=false;sheet.freezePanes.freezeRows(1);sheet.getRangeByIndexes(0,0,objects.length+1,headers.length).format.font={name:'Arial',size:10};sheet.getRangeByIndexes(0,0,1,headers.length).format={font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},fill:'#334155',wrapText:true,horizontalAlignment:'center',verticalAlignment:'center'};sheet.getRangeByIndexes(0,0,objects.length+1,headers.length).format.autofitColumns();
  sheet.getRangeByIndexes(0,0,1,headers.length).format.rowHeight=34;
  for(let j=0;j<headers.length;j++){const width=[...headers[j]].reduce((n,c)=>n+(c.codePointAt(0)>127?14:7),20);sheet.getRangeByIndexes(0,j,objects.length+1,1).format.columnWidthPx=Math.max(headers[j]==='条件ID'?128:headers[j]==='開始日JST'?164:92,width);}
}
const dcols=Object.fromEntries(detailHeader.map((h,i)=>[h,column(i)]));
detailSheet.getRangeByIndexes(1,detailHeader.indexOf('累計収支円'),detailRows.length,1).formulas=detailObjects.map((r,i)=>[i===0||detailObjects[i-1]['条件ID']!==r['条件ID']?`=${dcols['純損益円']}${i+2}`:`=${dcols['累計収支円']}${i+1}+${dcols['純損益円']}${i+2}`]);
workbook.recalculate();
for(const [sheet,objects,headers] of [[summarySheet,summaryObjects,summaryHeader],[detailSheet,detailObjects,detailHeader]]){
  const actual=sheet.getRangeByIndexes(1,0,objects.length,headers.length).values;
  for(let i=0;i<objects.length;i++)for(let j=0;j<headers.length;j++){const expected=objects[i][headers[j]],found=actual[i][j];if(expected===null)assert.ok(found===null||found==='','未定義は空欄');else if(typeof expected==='number')equalNumber(found,expected,'再計算/'+i+'/'+headers[j]);else assert.equal(found,expected);}
}
const sample=await workbook.inspect({kind:'table',range:'候補別集計!A1:H4',include:'values,formulas',tableMaxRows:4,tableMaxCols:8,maxChars:2500});
const errors=await workbook.inspect({kind:'match',searchTerm:'#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#NULL!|#SPILL!|#CALC!',options:{useRegex:true,maxResults:10},maxChars:1500});
await fs.mkdir(output,{recursive:false});const outputs={};
for(const [name,sheet,rows,headers] of [['候補別集計.csv',summarySheet,summaryRows,summaryHeader],['全セッション.csv',detailSheet,detailRows,detailHeader]]){const body=csv(sheet,rows.length+1,headers.length);await fs.writeFile(path.join(output,name),body,{encoding:'utf8',flag:'wx'});outputs[name]={sha256:sha(body),データ行数:rows.length,列数:headers.length};}
if(artificial)for(const name of ['候補別集計','全セッション']){const image=await workbook.render({sheetName:name,range:'A1:H4',scale:1.3,format:'png'});await fs.writeFile(path.join(output,name+'の人工プレビュー.png'),new Uint8Array(await image.arrayBuffer()),{flag:'wx'});}
for(const [name,expected] of Object.entries(beforeRefs))assert.equal(sha(await fs.readFile(name)),expected,'実出力後の不変');
await fs.writeFile(path.join(output,'CSVの確認.json'),JSON.stringify({成功:true,試行:117,人工:artificial,入力:input,入力SHA256:expectedSHA,出力:outputs,全条件:checks,入力前後不変:true,固定枠参加率生成:false,正益経験分母合算:true,正益経験後赤字率:'whole_positive_closed_negative / whole_positive_positions × 100、0分母は空欄',金融再実行:false,表の確認:sample.ndjson,エラー走査:errors.ndjson,Root要求:rootRequest,Raw初回性監査範囲:rawStatus,独立検算の実行区分:execution,認証済み入力:beforeRefs,実行環境:{node:process.version,artifact_tool:'2.8.129'},追加H0短期列:'保存点Counter未確定のため未追加'},null,2),{flag:'wx'});
console.log(JSON.stringify({成功:true,人工:artificial,出力先:output,出力:outputs}));

