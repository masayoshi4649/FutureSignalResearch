"""117二CSVを標準csv/Decimalで全セル再読し、金額・率・累計・0取引を独立照合する。"""
import argparse
from collections import defaultdict
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path

OWN = Path(__file__).resolve().parent
F1_SHA = '522fe2343b914243fadc4f48d32128a79ecdafcabd84d5a58b5ca399af90d1b0'
KEYS = [f'{p}_C{c}_D{d}' for p in ('S0','W100','P100','H0E','H0M') for c in (0,5) for d in (0,1)]
RAW_STATUS = '保存点の独立検算済み・全Rawの発生漏れ/初回性は未確認'
EXECUTION = '全70Nativeの保存点を独立検算。金融の元54参照再用と別'
MAPPED = {'新規件数':'positions','新規枚数':'entry_quantity','勝ち件数':'positive_positions','負け件数':'negative_positions','同値件数':'zero_positions','利益総額円':'positive_yen','損失総額円':'negative_yen','PF':'PF','平均利益円':'average_profit_yen','平均損失円':'average_loss_yen','平均利益損失比':'average_profit_loss_ratio','粗損益円':'gross_yen','手数料円':'fee_yen','追加滑り円':'slip_yen','純損益円':'net_yen','費用後正益を経験した建玉数':'whole_positive_positions','建玉全体の正益後赤字件数':'whole_positive_closed_negative','建玉全体の正益後赤字額円':'whole_positive_closed_negative_yen','追尾起動件数':'protection_activated_positions','追尾起動後赤字件数':'activated_closed_negative','追尾起動後赤字額円':'activated_closed_negative_yen'}
ADDITIVE = tuple(v for v in MAPPED.values() if v not in ('PF','average_profit_yen','average_loss_yen','average_profit_loss_ratio'))
RATIO_COLUMNS = {'PF','平均利益円','平均損失円','平均利益損失比','勝率パーセント','正益経験建玉の最終赤字率パーセント','保有時間秒','数量秒'}
COMMON = ['新規件数','新規枚数','勝ち件数','負け件数','同値件数','勝率パーセント','利益総額円','損失総額円','PF','平均利益円','平均損失円','平均利益損失比','粗損益円','手数料円','追加滑り円','純損益円']
PROTECTION = ['費用後正益を経験した建玉数','建玉全体の正益後赤字件数','正益経験建玉の最終赤字率パーセント','建玉全体の正益後赤字額円','追尾起動件数','追尾起動後赤字件数','追尾起動後赤字額円']
SUFFIX = ['保有時間秒','数量秒','判断時計','Raw初回性監査範囲','独立検算の実行区分']
SUMMARY = ['試行','保護政策','条件ID','セッション数','片道追加滑りpt','仮定遅延秒']+COMMON+['保存点連結時価DD円']+PROTECTION+SUFFIX
DETAIL = ['試行','保護政策','条件ID','開始日JST','セッション','期間区分','片道追加滑りpt','仮定遅延秒']+COMMON+['累計収支円','場内時価DD円']+PROTECTION+SUFFIX


def need(ok: bool, label: str) -> None:
    """
    機能: 不整合を成功や空欄へ隠さず拒否する。
    引数: ok(bool)/label(str)は条件と説明。返り値: None。
    """
    if not ok:
        raise ValueError(label)


def digest(path: Path) -> str:
    """
    機能: 明示ファイルの全bytes指紋を計算する。
    引数: path(Path)は対象。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(reference: dict) -> object:
    """
    機能: 小JSON参照を認証し金銭をDecimalで復元する。
    引数: reference(dict)はpath/sha256。返り値: objectはJSON値。
    """
    p=Path(reference['path']);need(p.is_absolute() and p.suffix=='.json','JSON絶対Refだけ');need(digest(p)==reference['sha256'],'Ref指紋差')
    return json.loads(p.read_text(encoding='utf-8-sig'),parse_float=Decimal)


def metrics(row: dict) -> dict:
    """
    機能: 元金額と全完結玉から比率を別計算する。
    引数: row(dict)は場又は集計。返り値: dictは正しい率と平均。
    """
    p,n=Decimal(row['positive_yen']),Decimal(row['negative_yen']);w,l,q=(row[k] for k in ('positive_positions','negative_positions','positions'))
    need(p>=0 and n<=0 and p+n==row['net_yen'] and w+l+row['zero_positions']==q,'正負符号/純額/勝負同値')
    need(0<=row['whole_positive_closed_negative']<=row['whole_positive_positions']<=q,'全玉正益経験の分母')
    a=p/w if w else None;b=n/l if l else None
    values={'PF':p/-n if n else None,'win_rate':Decimal(w)/q if q else None,'average_profit_yen':a,'average_loss_yen':b,'average_profit_loss_ratio':a/-b if a is not None and b is not None else None}
    for name,value in values.items():
        known=row[name];need((known is None)==(value is None),'比率null差:'+name)
        if value is not None:need(abs(Decimal(known)-value)<=Decimal('.000001'),'元比率の式差:'+name)
    return values


def read_csv(path: Path, headers: list[str]) -> list:
    """
    機能: ヘッダ順/全列/空欄を保ってCSVを独立復元する。
    引数: path(Path)/headers(list[str])はCSVと期待列。返り値: list[dict]は全行。
    """
    with path.open(encoding='utf-8-sig',newline='') as stream:
        reader=csv.DictReader(stream);need(reader.fieldnames==headers,'全ヘッダ順差');rows=list(reader)
    need(all(None not in row and all(v is not None for v in row.values()) for row in rows),'不揃い列')
    return rows


def verify(result_path: Path, expected_sha: str, folder: Path, output: Path, artificial: bool, root_ref: dict|None=None) -> dict:
    """
    機能: 二CSVの全金銭/件数/文字列/率/累計と全0場を再読する。
    引数: result_path/folder/output(Path)、expected_sha(str)、artificial(bool)、root_ref(dict|None)は認証と出力。
    返り値: dictは全セル比較数と前後不変。金融Go/Rawは実行しない。
    """
    if not artificial:
        need(root_ref is not None,'Root要求必須');request=load(root_ref)
        need(request['version']==1 and request['trial']==117 and request['fixed'] is True and request['result_read_authorized'] is True,'結果本文前のRoot解禁')
        need(request['independent_execution']=='verify_all70_saved_points' and request['condition']['sha256']==F1_SHA,'同F1保存点検算')
        stopped=load(request['code_stop']);need(stopped['試行']==117 and all(stopped.get(k) is True for k in ('成功','停止','市場前')),'停止認証')
        for name,sha in stopped['所有ファイルSHA256'].items():need(digest(Path(name))==sha,'停止code差')
        need(Path(request['result']['path']).resolve()==result_path and request['result']['sha256']==expected_sha and Path(request['output_dir']).resolve()==folder,'同Root入力/出力')
    need(digest(result_path)==expected_sha,'結果SHA');data=load({'path':str(result_path),'sha256':expected_sha})
    need(data['試行']==117 and data['成功'] is True and data['前後不変'] is True,'独立成功')
    if artificial:need(data.get('人工') is True and data['stage']=='artificial' and 0<data['場数']<=8,'人工ラベル')
    else:need(data.get('人工',False) is False and data['stage']=='full70' and data['場数']==70,'全70限定')
    count=data['場数'];need(data['主key']==KEYS and data['会計数']==20*count,'20本名/全会計')
    source={(r['key'],r['session']):r for r in data['場別']};need(len(source)==len(data['場別'])==20*count,'全場/重複')
    proof_path=folder/'CSVの確認.json';proof=json.loads(proof_path.read_text(encoding='utf-8'))
    need(proof['成功'] is True and proof['試行']==117 and proof['人工']==artificial and proof['入力SHA256']==expected_sha,'生成と正本結合')
    need(proof['Root要求']==root_ref,'同Root要求');need(set(proof['出力'])=={'候補別集計.csv','全セッション.csv'},'CSV二点だけ')
    paths=[result_path,proof_path,folder/'候補別集計.csv',folder/'全セッション.csv',Path(__file__).resolve()];before={str(p):digest(p) for p in paths}
    for name,value in proof['出力'].items():need(digest(folder/name)==value['sha256'],'CSV保存後SHA差')
    detail,summary=read_csv(folder/'全セッション.csv',DETAIL),read_csv(folder/'候補別集計.csv',SUMMARY)
    need(len(detail)==20*count and len(summary)==20 and [r['条件ID'] for r in summary]==KEYS,'全行/政策順')
    numeric=blanks=texts=0

    def compare(row: dict, expected: dict) -> None:
        """
        機能: 各列を漏らさず、金額件数はexact、率時間は百万分の一で照合する。
        引数: row/expected(dict)はCSVと別計算値。返り値: None。
        """
        nonlocal numeric,blanks,texts
        need(set(row)==set(expected),'全列の期待値不足')
        for name,value in expected.items():
            actual=row[name]
            if value is None:need(actual=='','null空欄差:'+name);blanks+=1
            elif isinstance(value,str):need(actual==value,'文字列差:'+name);texts+=1
            else:
                number=Decimal(actual);want=Decimal(value);need(number.is_finite(),'非有限CSV')
                need(abs(number-want)<=Decimal('.000001') if name in RATIO_COLUMNS else number==want,'数値差:'+name);numeric+=1

    def expected_financial(row: dict) -> dict:
        """
        機能: 共通金融列を正本と独立分母計算から得る。
        引数: row(dict)は正本。返り値: dictは全金融/保護列。
        """
        values={h:row[k] for h,k in MAPPED.items()};calculated=metrics(row)
        for h,k in (('PF','PF'),('平均利益円','average_profit_yen'),('平均損失円','average_loss_yen'),('平均利益損失比','average_profit_loss_ratio')):values[h]=calculated[k]
        values['勝率パーセント']=None if calculated['win_rate'] is None else 100*calculated['win_rate']
        values['正益経験建玉の最終赤字率パーセント']=None if row['whole_positive_positions']==0 else Decimal(row['whole_positive_closed_negative'])*100/row['whole_positive_positions']
        return values

    cumulative=defaultdict(lambda:Decimal(0));seen=set();session_lists=defaultdict(list);zero_rows=0
    execution='手製人工のみ' if artificial else EXECUTION
    for row in detail:
        key=row['条件ID'];sid=row['開始日JST'].removesuffix(' JST')+'_'+('Day' if row['セッション']=='デイ' else 'Night' if row['セッション']=='ナイト' else '?');identity=(key,sid)
        need(identity in source and identity not in seen,'未知/重複場');seen.add(identity);session_lists[key].append(sid);original=source[identity];cfg=data['Actor設定'][key];cumulative[key]+=original['net_yen']
        need(original['gross_yen']-original['fee_yen']-original['slip_yen']==original['net_yen']==original['closed_net_yen'],'費用/完結額')
        need(original['fee_yen']==77*original['entry_quantity'] and original['slip_yen']==200*cfg['slip_pts']*original['entry_quantity'],'費用単位')
        expected={'試行':117,'保護政策':cfg['policy'],'条件ID':key,'開始日JST':sid.split('_')[0]+' JST','セッション':'デイ' if sid.endswith('Day') else 'ナイト','期間区分':'元54場' if original['history_class']=='original54' else '追加16場','片道追加滑りpt':cfg['slip_pts'],'仮定遅延秒':cfg['delay_seconds'],**expected_financial(original),'累計収支円':cumulative[key],'場内時価DD円':original['場内時価DD'],'保有時間秒':original['頻度診断'].get('held_seconds',0),'数量秒':original['頻度診断'].get('quantity_seconds',0),'判断時計':'元Source連続','Raw初回性監査範囲':RAW_STATUS,'独立検算の実行区分':execution};compare(row,expected);zero_rows+=original['positions']==0
    need(seen==set(source),'全0場を含む全場保持')
    for key,sids in session_lists.items():need(len(sids)==count and sids==sorted(sids),'場順/累計順')
    for row in summary:
        key=row['条件ID'];value=data['集計'][key];cfg=data['Actor設定'][key];group=[r for r in data['場別'] if r['key']==key]
        for name in ADDITIVE:need(sum(r[name] for r in group)==value[name],'全場からの合算:'+name)
        expected={'試行':117,'保護政策':cfg['policy'],'条件ID':key,'セッション数':count,'片道追加滑りpt':cfg['slip_pts'],'仮定遅延秒':cfg['delay_seconds'],**expected_financial(value),'保存点連結時価DD円':value['保存点連結時価DD'],'保有時間秒':sum(r['頻度診断'].get('held_seconds',0) for r in group),'数量秒':sum(r['頻度診断'].get('quantity_seconds',0) for r in group),'判断時計':'元Source連続','Raw初回性監査範囲':RAW_STATUS,'独立検算の実行区分':execution};compare(row,expected);need(Decimal(row['純損益円'])==cumulative[key],'累計末尾と集計純額')
    after={str(p):digest(p) for p in paths};need(before==after,'前後指紋差')
    report={'成功':True,'試行':117,'人工':artificial,'候補数':20,'場別行数':len(detail),'候補列数':len(SUMMARY),'場別列数':len(DETAIL),'数値比較数':numeric,'空欄比率確認数':blanks,'文字列比較数':texts,'全セル比較数':numeric+blanks+texts,'0取引行数':zero_rows,'全場累計再計算':True,'正益経験分母合算':True,'未定義比率は空欄':True,'前後不変':True,'入力SHA256':before,'後SHA256':after,'Raw読取':0,'金融再実行':False,'H0追加列未確定':True}
    with output.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    return report


def main() -> None:
    """
    機能: Root成功固定要求又は手製人工の明示からだけ独立再読する。
    引数: CLI result/sha256/folder/output、artificial又はroot-authorizedとrequest/request-sha。
    返り値: None。自然解禁のない結果本文を開かない。
    """
    parser=argparse.ArgumentParser()
    for name in ('result','sha256','folder','output'):parser.add_argument('--'+name,required=True)
    parser.add_argument('--request');parser.add_argument('--request-sha');mode=parser.add_mutually_exclusive_group(required=True);mode.add_argument('--artificial',action='store_true');mode.add_argument('--root-authorized',action='store_true');args=parser.parse_args()
    if not args.artificial:need(args.request and args.request_sha,'Root要求とSHAが必要')
    root_ref=None if args.artificial else {'path':str(Path(args.request).resolve()),'sha256':args.request_sha}
    report=verify(Path(args.result).resolve(),args.sha256,Path(args.folder).resolve(),Path(args.output).resolve(),args.artificial,root_ref)
    print(json.dumps({k:report[k] for k in ('成功','全セル比較数','数値比較数','空欄比率確認数','0取引行数')},ensure_ascii=False))


if __name__=='__main__':main()
