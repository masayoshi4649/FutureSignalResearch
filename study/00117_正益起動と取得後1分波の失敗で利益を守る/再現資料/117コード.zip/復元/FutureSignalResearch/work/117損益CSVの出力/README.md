# 117損益CSVの出力準備

旧116のArtifact Toolと独立再読の実用部分を五政策20条件へ派生する。S0/W100/P100/H0E/H0M×C0D0/C0D1/C5D0/C5D1を本名keyで結合し、候補別20行35列、全70セッション1400行38列を予定する。全0取引行を残す。現在は手製20候補×二場だけで、新しい自然結果・Raw・Native・価格CSV・損益CSV本文は読まない。新xlsxは生成しない。

利益/損失は完結実Positionの費用後実現額で、損失総額/平均損失は負で保持する。勝率は勝ち÷勝負同値の全玉、PFは利益総額÷損失総額絶対値、平均損益比は平均利益÷平均損失絶対値。0分母は空欄で0と混同しない。正益後赤字率はwhole_positive_closed_negative÷whole_positive_positions。場別率を平均しない。累計は候補別のセッション順に費用後純実現額だけを加算する。DDは保存点の時価DDであり全Rawの最大DDとは呼ばない。

mini片道38.5円、1pt100円、片道追加滑り0/5pt・追加遅延0/1秒を表示する。Sourceは元の連続時計で、固定枠参加率を追加しない。S0は追加保護なし、P100とH0を同じ保護名へ偽装しない。旧116のlife列・入口gate列は外す。ゼロ目標/短期arm/警戒/幅適用等の追加Counterは保存側の定義未確定なので今回は列に加えない。共通の追尾起動件数とその後の実赤字は保持する。

全70の独立保存点検算を前提とし、金融Coreの元54Native参照再用と区別する。全Rawの発生漏れ/初回性をこの出力で証明しない。未参加/退出後の仮想利益、MFE回収率、ROIは作らない。

Node24.22.1とloader由来のartifact-tool2.8.129を使用する。人工Workbookの最初の作成直前にcreate/2/csv操作markerを一回記録し、操作markerの記録.jsonへ残す。人工は `python -X utf8 人工検査.py 新規先`。再計算・人工二面描画・標準csv/Decimalによる全セル再読と、未解禁・候補順・平均損失符号・欠落・既存先の拒否を検査する。人工は金融の有効性を意味しない。

**このmarker一回は人工authoringの操作だけ**に対応する。人工の修正・再検査では重ねて記録しない。今後の自然CSV二点の作成には流用せず、Rootがその別operationの最初の作成直前に同じcreate/2/csv markerを一回だけ実行し、Rootの新しい進行metadataへ記録する。本builder・人工helper・停止helperはmarkerを自動実行しない。したがって自然作成はRoot側だけが記録し、二重に実行しない。CSVの独立再読は読取専用なので追加markerは不要。停止済み人工の操作markerの記録.jsonは自然作成時も変更しない。

Rootレビュー後だけ停止helperへ成功人工Refを渡す。自然出力は新しいRoot固定要求と同F1全70金融・独立成功を本文前認証し、outputsの新規先だけへ二CSVを作る。

```text
node 出力する.mjs --request ABS --sha256 SHA --output NEW --root-authorized
python -X utf8 CSVを独立再読する.py --request ABS --request-sha SHA --result ABS_RESULT --sha256 RESULT_SHA --folder NEW --output NEW_CHECK.json --root-authorized
```

CSVはoutputs二点を唯一の閲覧正本とし、試行へのコピーや全件MD転記を行わない。正式停止・実自然出力はRoot担当。
