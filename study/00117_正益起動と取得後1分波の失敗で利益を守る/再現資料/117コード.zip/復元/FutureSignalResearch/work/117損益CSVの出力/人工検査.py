"""117の20候補・二場・正負/半円/0取引/率nullを手製し、Artifact Toolと別言語で検査する。"""
from copy import deepcopy
from pathlib import Path
import hashlib
import json
import subprocess
import sys

OWN=Path(__file__).resolve().parent
ROOT=OWN.parents[1]
NODE=Path('C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe')
PACKAGE=NODE.parent.parent/'node_modules/@oai/artifact-tool/package.json'
FILES=('入力と候補.mjs','出力する.mjs','CSVを独立再読する.py','人工検査.py','README.md','検査して停止する.py')
CONFIGS=[{'policy':p,'slip_pts':c,'delay_seconds':d} for p in ('S0','W100','P100','H0E','H0M') for c in (0,5) for d in (0,1)]


def digest(path: Path) -> str:
    """
    機能: 明示コード/人工の全bytes指紋を得る。
    引数: path(Path)は対象。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def put(path: Path,value: dict) -> dict:
    """
    機能: 未作成先だけへUTF-8 JSONを置く。
    引数: path(Path)/value(dict)は新規先と手製値。返り値: dictはRef。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    return {'path':str(path.resolve()),'sha256':digest(path)}


def metrics(row: dict) -> dict:
    """
    機能: 手製の正負金銭と件数から率を定義する。
    引数: row(dict)は手製金銭。返り値: dictは率と平均。
    """
    p,n=row['positive_yen'],row['negative_yen'];w,l,q=(row[k] for k in ('positive_positions','negative_positions','positions'))
    a=p/w if w else None;b=n/l if l else None
    return {'PF':p/-n if n else None,'win_rate':w/q if q else None,'average_profit_yen':a,'average_loss_yen':b,'average_profit_loss_ratio':a/-b if a is not None and b is not None else None}


def fixture() -> dict:
    """
    機能: 実結果/CSVを読まず20候補×二場・0取引12行を手製する。
    引数: なし。返り値: dictは40会計の明示人工で、市場利益を意味しない。
    """
    data={'試行':117,'成功':True,'人工':True,'stage':'artificial','場数':2,'会計数':40,'前後不変':True,'主key':[],'Actor設定':{},'場別':[],'集計':{},'研究目標達成':False,'採用':False}
    for i,cfg in enumerate(CONFIGS):
        key=f"{cfg['policy']}_C{cfg['slip_pts']}_D{cfg['delay_seconds']}";data['主key'].append(key);data['Actor設定'][key]=deepcopy(cfg);group=[]
        for j,sid in enumerate(('2026-09-21_Day','2026-11-06_Day')):
            zero=cfg['policy']=='W100' or (cfg['policy']=='H0E' and j==1)
            if zero:pos=qty=w=l=0;p=n=0
            elif j==0:pos=2;qty=3;w=l=1;p=1923+i*500-200*cfg['slip_pts'];n=-1154-i*1000-400*cfg['slip_pts']
            elif cfg['policy']=='S0':pos=qty=l=1;w=0;p=0;n=-77-200*cfg['slip_pts']
            else:pos=qty=w=1;l=0;p=423+i*500-200*cfg['slip_pts'];n=0
            # ----------------------------------------
            # 利益側を正額のまま保ち、費用と純額を実枚数で整合させる。約定生成の試験ではない。
            if p<0:n=p;p=0;w,l=0,1
            fee=77*qty;slip=200*cfg['slip_pts']*qty;net=p+n;active=0 if cfg['policy']=='S0' else pos
            whole=pos if j==0 else w;red=l if j==0 else 0
            row={'session':sid,'key':key,'history_class':'original54' if j==0 else 'additional16','positions':pos,'entry_quantity':qty,'close_quantity':qty,'positive_positions':w,'negative_positions':l,'zero_positions':0,'positive_yen':p,'negative_yen':n,'net_yen':net,'closed_net_yen':net,'gross_yen':net+fee+slip,'fee_yen':fee,'slip_yen':slip,'whole_positive_positions':whole,'whole_positive_closed_negative':red,'whole_positive_closed_negative_yen':n if red else 0,'protection_activated_positions':active,'activated_closed_negative':l if active else 0,'activated_closed_negative_yen':n if active and l else 0,'open_buy':0,'open_sell':0,'pending_buy':0,'pending_sell':0,'場内時価DD':max(0,-n)+i,'頻度診断':{'held_seconds':(10.5+i) if pos else 0,'quantity_seconds':(15.5+i)*qty}}
            row.update(metrics(row));group.append(row);data['場別'].append(row)
        summed={name:sum(r[name] for r in group) for name in ('positions','entry_quantity','close_quantity','positive_positions','negative_positions','zero_positions','positive_yen','negative_yen','gross_yen','fee_yen','slip_yen','net_yen','closed_net_yen','whole_positive_positions','whole_positive_closed_negative','whole_positive_closed_negative_yen','protection_activated_positions','activated_closed_negative','activated_closed_negative_yen')}
        summed.update(metrics(summed));summed['保存点連結時価DD']=max(r['場内時価DD'] for r in group);summed['頻度診断']={name:sum(r['頻度診断'][name] for r in group) for name in ('held_seconds','quantity_seconds')};data['集計'][key]=summed
    return data


def run(command: list, success: bool=True) -> dict:
    """
    機能: 明示手製CLIだけを起動し成功/拒否を確認する。
    引数: command(list)/success(bool)は実行列と期待。返り値: dictはログ。
    """
    r=subprocess.run([str(v) for v in command],cwd=OWN,capture_output=True,text=True,encoding='utf-8',timeout=90)
    value={'command':[str(v) for v in command],'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
    if (r.returncode==0)!=success:raise ValueError(json.dumps(value,ensure_ascii=False))
    return value


def inspect(output: Path) -> dict:
    """
    機能: 手製二CSVと独立全セル再読、未許可/不正schema/既存先の拒否を検査する。
    引数: output(Path)は未作成先。返り値: dictは停止前人工Ref。
    """
    before={str((OWN/name).resolve()):digest(OWN/name) for name in FILES}
    environment={'node':{'path':str(NODE),'sha256':digest(NODE)},'artifact_package':{'path':str(PACKAGE),'sha256':digest(PACKAGE)},'node版':'24.22.1','artifact_tool版':'2.8.129','Python版':sys.version}
    output.mkdir();commands=[];source=put(output/'手製の独立結果.json',fixture())
    commands.append(run([NODE,OWN/'出力する.mjs','開かない.json','0'*64,output/'未許可'],False))
    if 'ENOENT' in commands[-1]['stderr']:raise ValueError('未許可で結果本文へ進んだ')
    commands.append(run([NODE,OWN/'出力する.mjs',source['path'],source['sha256'],output/'CSV','--artificial']))
    commands.append(run([sys.executable,'-X','utf8',OWN/'CSVを独立再読する.py','--result',source['path'],'--sha256',source['sha256'],'--folder',output/'CSV','--output',output/'CSVの独立再読.json','--artificial']))
    reread=json.loads((output/'CSVの独立再読.json').read_text(encoding='utf-8'))
    if (reread['候補数'],reread['場別行数'],reread['候補列数'],reread['場別列数'],reread['0取引行数'])!=(20,40,35,38,12):raise ValueError('手製20/40/35/38/0取引12差')
    commands.append(run([NODE,OWN/'出力する.mjs',source['path'],source['sha256'],output/'CSV','--artificial'],False))
    for name in ('候補順','平均損失符号','全場欠落'):
        value=fixture()
        if name=='候補順':value['主key'].reverse()
        elif name=='平均損失符号':value['場別'][0]['average_loss_yen']*= -1
        else:value['場別'].pop()
        bad=put(output/(name+'.json'),value);commands.append(run([NODE,OWN/'出力する.mjs',bad['path'],bad['sha256'],output/(name+'拒否'),'--artificial'],False))
        if (output/(name+'拒否')).exists():raise ValueError('破壊値で出力先作成')
    unfixed=put(output/'未固定要求.json',{'version':1,'trial':117,'fixed':False,'result_read_authorized':False})
    commands.append(run([NODE,OWN/'出力する.mjs','--request',unfixed['path'],'--sha256',unfixed['sha256'],'--output',output/'未固定拒否','--root-authorized'],False))
    if before!={str((OWN/name).resolve()):digest(OWN/name) for name in FILES}:raise ValueError('所有前後差')
    for label in ('node','artifact_package'):
        if digest(Path(environment[label]['path']))!=environment[label]['sha256']:raise ValueError('実行環境前後差')
    marker=OWN/'操作markerの記録.json';m=json.loads(marker.read_text(encoding='utf-8'))
    if m['成功'] is not True or m['回数']!=1:raise ValueError('操作marker一回だけ')
    old=ROOT/'work/116損益CSVの出力/出力する.mjs'
    proof={'試行':117,'成功':True,'市場前':True,'停止':False,'所有ファイルSHA256':before,'前後不変':True,'人工20候補':True,'人工40会計':True,'0取引行数':12,'操作marker':{'path':str(marker),'sha256':digest(marker)},'再用コードSHA256':{str(old):digest(old)},'環境参照':environment,'環境前後不変':True,'入力':source,'commands':commands,'独立再読':reread,'原板/市場Native/自然CSV本文':0,'xlsx生成':False}
    return put(output/'人工の確認.json',proof)


if __name__=='__main__':
    if len(sys.argv)!=2:raise ValueError('新規の人工先だけを指定')
    print(json.dumps(inspect(Path(sys.argv[1]).resolve()),ensure_ascii=False))
