import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';

export const F1_SHA='522fe2343b914243fadc4f48d32128a79ecdafcabd84d5a58b5ca399af90d1b0';
export const POLICIES=['S0','W100','P100','H0E','H0M'];
export const CONFIGS=POLICIES.flatMap(policy=>[0,5].flatMap(slip=>[0,1].map(delay=>({policy,slip_pts:slip,delay_seconds:delay}))));
export const RAW_STATUS='保存点の独立検算済み・全Rawの発生漏れ/初回性は未確認';
export const EXECUTION='全70Nativeの保存点を独立検算。金融の元54参照再用と別';

/**
 * 本名政策と費用から候補keyを返す。
 * @param {Object} c - policy/slip_pts/delay_secondsを持つ設定。
 * @returns {string} 一意な候補key。
 */
export function keyFor(c){return `${c.policy}_C${c.slip_pts}_D${c.delay_seconds}`;}
export const KEYS=CONFIGS.map(keyFor);

/**
 * 明示bytesのSHA256を求める。
 * @param {Uint8Array|string} value - 明示された全bytes。
 * @returns {string} 小文字SHA256。
 */
export function sha(value){return crypto.createHash('sha256').update(value).digest('hex');}

/**
 * 小JSON絶対参照を認証し前後台帳へ加える。
 * @param {Object} ref - path/sha256の明示参照。
 * @param {Object} before - 認証済みSHA台帳。
 * @returns {Promise<Object>} 認証したJSON。
 */
async function readRef(ref,before){assert.deepEqual(Object.keys(ref).sort(),['path','sha256']);assert.ok(path.isAbsolute(ref.path)&&path.extname(ref.path)==='.json');const raw=await fs.readFile(ref.path);assert.equal(sha(raw),ref.sha256);assert.ok(!Object.hasOwn(before,ref.path)||before[ref.path]===ref.sha256);before[ref.path]=ref.sha256;return JSON.parse(raw.toString('utf8').replace(/^\uFEFF/,''));}

/**
 * Root全70成功の解禁又は小さな手製だけを結果本文へ通す。
 * @param {string[]} args - --request/SHA/output/--root-authorized又は手製位置列。
 * @returns {Promise<Object>} 認証範囲・結果と新規出力先。
 */
export async function openInput(args){
  assert.equal(process.version,'v24.22.1');
  const packagePath=import.meta.resolve('@oai/artifact-tool').replace(/dist[\\/]artifact_tool\.mjs$/,'package.json');
  assert.equal(JSON.parse(await fs.readFile(new URL(packagePath),'utf8')).version,'2.8.129');
  const artificial=args.includes('--artificial'),beforeRefs={};let input,expectedSHA,output,data,rootRequest=null;
  if(artificial){assert.equal(args.length,4);[input,expectedSHA,output]=args;input=path.resolve(input);output=path.resolve(output);data=await readRef({path:input,sha256:expectedSHA},beforeRefs);assert.equal(data['人工'],true);assert.equal(data.stage,'artificial');assert.ok(data['場数']>0&&data['場数']<=8);}
  else{
    assert.equal(args.length,7,'Root固定要求と明示許可が必要');assert.equal(args[0],'--request');assert.equal(args[2],'--sha256');assert.equal(args[4],'--output');assert.equal(args[6],'--root-authorized');
    rootRequest={path:path.resolve(args[1]),sha256:args[3]};output=path.resolve(args[5]);const request=await readRef(rootRequest,beforeRefs);
    assert.equal(request.version,1);assert.equal(request.trial,117);assert.equal(request.fixed,true);assert.equal(request.result_read_authorized,true,'本文前のRoot全70解禁');assert.equal(request.independent_execution,'verify_all70_saved_points');assert.equal(path.resolve(request.output_dir),output);
    const stopped=await readRef(request.code_stop,beforeRefs);for(const [name,value] of Object.entries({'試行':117,'成功':true,'市場前':true,'停止':true}))assert.equal(stopped[name],value);
    const here=path.dirname(fileURLToPath(import.meta.url));const names=['入力と候補.mjs','出力する.mjs','CSVを独立再読する.py','人工検査.py','README.md','検査して停止する.py'].map(name=>path.join(here,name));assert.deepEqual(Object.keys(stopped['所有ファイルSHA256']).sort(),names.sort());
    for(const [name,expected] of Object.entries(stopped['所有ファイルSHA256'])){assert.equal(sha(await fs.readFile(name)),expected);beforeRefs[name]=expected;}
    assert.equal(request.condition.sha256,F1_SHA);
    const condition=await readRef(request.condition,beforeRefs),completion=await readRef(request.completion,beforeRefs),check=await readRef(request.check,beforeRefs);
    assert.equal(condition.trial,117);assert.equal(condition.fixed,true);assert.deepEqual(condition.actual_configurations,CONFIGS);assert.equal(condition.source_trial,111);assert.equal(condition.entry_grid_seconds,null);assert.equal(condition.extra_opening_quiet_seconds,0);
    for(const [name,value] of Object.entries({trial:117,success:true,stage:'full70',sessions:70,books:1400,condition_sha256:F1_SHA,unchanged:true,reference112_comparisons:840,all_reference112_equal:true,all_source111_equal:true}))assert.equal(completion[name],value);
    assert.deepEqual(completion.before,completion.after);assert.equal(completion.results.length,70);assert.equal(new Set(completion.results.map(r=>r.session)).size,70);
    for(const row of completion.results){assert.equal(row.books,20);assert.equal(row.S0_comparisons,4);assert.equal(row.S0_equal,true);assert.equal(row.reference112_comparisons,12);assert.equal(row.reference112_equal,true);assert.equal(row.source111_equal,true);assert.equal(row.complete,true);assert.equal(row.open_quantity,0);assert.equal(row.pending_quantity,0);}
    for(const [name,value] of Object.entries({'試行':117,'成功':true,stage:'full70','場数':70,'会計数':1400,'前後不変':true,'全残玉予約0':true,'不一致数':0,'旧112全金融比較':840,'全Source111同体':true,'金融条件SHA256':F1_SHA,'金融完了SHA256':request.completion.sha256}))assert.equal(check[name],value);
    assert.equal(check['出力SHA256']['結果.json'],request.result.sha256);
    data=await readRef(request.result,beforeRefs);input=request.result.path;expectedSHA=request.result.sha256;
    assert.equal(data['金融条件SHA256'],F1_SHA);assert.equal(data['金融完了SHA256'],request.completion.sha256);assert.equal(data['Root保存要求SHA256'],check['Root保存要求SHA256']);assert.equal(data['場数'],70);assert.equal(data.stage,'full70');assert.equal(data['採用'],false);assert.equal(data['研究目標達成'],false);assert.equal(data['独立再用場数']??0,0,'旧54独立再用はこの版で未対応');
    assert.deepEqual([...new Set(data['場別'].map(r=>r.session))].sort(),completion.results.map(r=>r.session).sort());
  }
  assert.equal(data['試行'],117);assert.equal(data['成功'],true);assert.equal(data['前後不変'],true);assert.deepEqual(data['主key'],KEYS);assert.equal(data['会計数'],20*data['場数']);
  await assert.rejects(fs.stat(output),{code:'ENOENT'},'出力先は未作成のみ');
  return {input,expectedSHA,output,data,artificial,beforeRefs,rootRequest,rawStatus:RAW_STATUS,execution:artificial?'手製人工のみ':EXECUTION};
}
