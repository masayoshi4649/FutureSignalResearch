"""手製quoteから、Goを呼ばずDecimalで1分bankを再形成する。"""

from copy import deepcopy
from decimal import Decimal, ROUND_FLOOR, localcontext


TECHNICAL = (
    "origin", "centered_ema12", "centered_ema26", "ema12", "ema26",
    "macd", "signal", "histogram", "atr",
)


def decimal_value(value):
    """
    機能: JSON数値を十進文字列表現から独立数値へ写す。
    引数: value(int|float|Decimal)は入力値。
    返り値: Decimalは二進floatを経由しない数値。
    """
    return value if isinstance(value, Decimal) else Decimal(str(value))


def value(number=None):
    """
    機能: 未知を0補完した既知値と混同せず公開Valueを作る。
    引数: number(Decimal|None)は数値又は未知。
    返り値: dictはknown/value。
    """
    return {"known": number is not None, "value": Decimal(0) if number is None else decimal_value(number)}


def technical():
    """
    機能: 全成分が未知の指標票を作る。
    引数: なし。
    返り値: dictは9成分の独立Value。
    """
    return {key: value() for key in TECHNICAL}


# ----------------------------------------
class EMA:
    """SMA初期値を持つEMAの独立実装。"""

    def __init__(self, period):
        """
        機能: 期間と確定入力の蓄積を初期化する。
        引数: period(int)は期間。
        返り値: None。
        """
        self.period, self.inputs, self.current = period, [], None

    def add(self, number):
        """
        機能: 確定入力1個を加え、最初の期間個はSMAで初期化する。
        引数: number(Decimal)は確定入力。
        返り値: dictは新しいValue。
        """
        if self.current is None:
            self.inputs.append(number)
            if len(self.inputs) == self.period:
                self.current = sum(self.inputs) / self.period
        else:
            self.current += Decimal(2) / (self.period + 1) * (number - self.current)
        return value(self.current)

    def prefix(self, number):
        """
        機能: 確定状態を変更せず未確定入力を1回だけ仮評価する。
        引数: number(Decimal)は現在足の暫定入力。
        返り値: dictは既に初期化済みの場合だけ既知のValue。
        """
        return value(None if self.current is None else self.current + Decimal(2) / (self.period + 1) * (number - self.current))


class Numbers:
    """確定EMA/MACD/ATRと、非破壊の暫定評価を分離する。"""

    def __init__(self):
        """
        機能: 当場又は欠足後のcold指標状態を初期化する。
        引数: なし。
        返り値: None。
        """
        self.origin = None
        self.fast, self.slow, self.signal = EMA(12), EMA(26), EMA(9)
        self.previous_close, self.atr = None, None
        self.ranges, self.bars = [], 0
        self.committed = technical()

    def calculate(self, bar, commit):
        """
        機能: 足のOHLCから指標を計算し、確定時だけ内部履歴を進める。
        引数: bar(dict)は1分足、commit(bool)は確定の有無。
        返り値: None。barのTR/前ATR/technicalへ独立計算値を設定する。
        """
        bar["previous_atr"] = value(self.atr)
        tr = None
        if self.previous_close is not None:
            tr = max(bar["high"] - bar["low"], abs(bar["high"] - self.previous_close), abs(bar["low"] - self.previous_close))
        bar["tr"] = value(tr)
        result = technical()
        result["origin"] = value(self.origin)
        centered = bar["close"] - self.origin
        result["centered_ema12"] = self.fast.add(centered) if commit else self.fast.prefix(centered)
        result["centered_ema26"] = self.slow.add(centered) if commit else self.slow.prefix(centered)
        for period in (12, 26):
            item = result[f"centered_ema{period}"]
            if item["known"]:
                result[f"ema{period}"] = value(self.origin + item["value"])
        if result["centered_ema12"]["known"] and result["centered_ema26"]["known"]:
            macd = result["centered_ema12"]["value"] - result["centered_ema26"]["value"]
            result["macd"] = value(macd)
            result["signal"] = self.signal.add(macd) if commit else self.signal.prefix(macd)
            if result["signal"]["known"]:
                result["histogram"] = value(macd - result["signal"]["value"])
        if tr is not None:
            if commit:
                if self.atr is None:
                    self.ranges.append(tr)
                    if len(self.ranges) == 14:
                        self.atr = sum(self.ranges) / 14
                else:
                    self.atr += (tr - self.atr) / 14
                result["atr"] = value(self.atr)
            elif self.atr is not None:
                result["atr"] = value(self.atr + (tr - self.atr) / 14)
        bar["technical"] = result
        if commit:
            self.committed = deepcopy(result)
            self.previous_close = bar["close"]
            self.bars += 1


# ----------------------------------------
class Bank:
    """自然ファイルを開かず、与えられたquoteだけを処理するbank。"""

    def __init__(self, scope):
        """
        機能: 当場coldの足と数値状態を初期化する。
        引数: scope(dict)は手製場/限月/start。
        返り値: None。
        """
        self.scope = deepcopy(scope)
        self.numbers, self.current, self.recent = Numbers(), None, []
        self.epoch, self.total, self.last = 0, 0, None

    def step(self, quote):
        """
        機能: 現在原行で旧足を確定し、当足の暫定値まで再形成する。
        引数: quote(dict)は手製Last>0の原行。
        返り値: dictは指紋を除く独立BankSnapshot。
        """
        with localcontext() as context:
            context.prec = 50
            q = deepcopy(quote)
            if self.last is not None:
                assert q["index"] > self.last["index"] and q["source_line"] > self.last["source_line"] and q["time"] >= self.last["time"]
            start = decimal_value(self.scope["start"]) + 60 * ((decimal_value(q["time"]) - decimal_value(self.scope["start"])) / 60).to_integral_value(rounding=ROUND_FLOOR)
            closed, gap, reason = None, None, ""
            if self.current is not None and start > self.current["start"]:
                closed = deepcopy(self.current)
                closed["complete"], closed["published"] = True, deepcopy(q)
                self.numbers.calculate(closed, True)
                self.total += 1
                self.recent = (self.recent + [deepcopy(closed)])[-4:]
                if start > closed["end"]:
                    gap = {"from_end": closed["end"], "to_start": start, "missing_minutes": int((start - closed["end"]) / 60), "at": deepcopy(q)}
                    self.epoch += 1
                    reason = "空1分あり:数値と局所波をcoldへreset"
                    self.numbers, self.recent = Numbers(), []
                self.current = None
            if self.current is None:
                if self.numbers.origin is None:
                    self.numbers.origin = decimal_value(q["last"])
                price = decimal_value(q["last"])
                self.current = {"id": f"{self.scope['session']}/{self.scope['contract']}/1m/{start:.9f}/{self.epoch}", "start": start, "end": start + 60, "complete": False, "first": deepcopy(q), "last": deepcopy(q), "count": 1, "open": price, "high": price, "low": price, "close": price}
            else:
                self.current["count"] += 1
                self.current["last"] = deepcopy(q)
                self.current["high"] = max(self.current["high"], decimal_value(q["last"]))
                self.current["low"] = min(self.current["low"], decimal_value(q["last"]))
                self.current["close"] = decimal_value(q["last"])
            prefix = deepcopy(self.current)
            prefix["published"] = deepcopy(q)
            self.numbers.calculate(prefix, False)
            result = {"version": 117, "scope": deepcopy(self.scope), "have_quote": True, "quote": q, "epoch": self.epoch, "reset_count": self.epoch, "reset_reason": reason, "closed_bars": self.numbers.bars, "total_closed_bars": self.total, "cold": not (self.numbers.committed["histogram"]["known"] and self.numbers.committed["atr"]["known"]), "committed": deepcopy(self.numbers.committed), "recent_closed": deepcopy(self.recent), "prefix": prefix}
            if gap is not None:
                result["gap"] = gap
            if closed is not None:
                result["closed_now"] = closed
            if self.recent:
                result["latest_closed"] = deepcopy(self.recent[-1])
            self.last = deepcopy(q)
            return result
