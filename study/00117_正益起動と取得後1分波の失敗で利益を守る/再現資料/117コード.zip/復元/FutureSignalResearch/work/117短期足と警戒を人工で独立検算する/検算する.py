"""手製系列のSHAを認証し、独立bankと保存値を照合するCLI。"""

import argparse
import hashlib
import importlib.util
import json
from decimal import Decimal
from pathlib import Path
import sys

sys.stdout.reconfigure(encoding="utf-8")
HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
SERIES = ROOT / "work/117原行と暫定1分の複合保護/人工_独立用/系列.json"
EXPECTED = "923be91b1f7b2c3ea6eb3d3e58ded632c8f7846320ab98f64c36d7704c948b3c"
TOLERANCE = Decimal("1e-9")
REFERENCE_GO = ROOT / "work/117原行と暫定1分の複合保護"


def load_module(name, path):
    """
    機能: 自分が所有するPython実装だけを読み込む。
    引数: name(str)はモジュール名、path(Path)は自所有ファイル。
    返り値: moduleは読み込まれたPython。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def sha(path):
    """
    機能: 指定コード又は人工証拠のbytesを認証する。
    引数: path(Path)は許可済み小ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


class Comparison:
    """数値誤差と厳密な型・旗・時計の照合件数を記録する。"""

    def __init__(self):
        """
        機能: 比較カウンタを初期化する。
        引数: なし。
        返り値: None。
        """
        self.count, self.numeric, self.maximum, self.maximum_path = 0, 0, Decimal(0), ""

    def compare(self, actual, expected, path="", numeric=False):
        """
        機能: 再形成値と保存値を、指標Valueだけ許容差付きで照合する。
        引数: actual/expected(any)は両値、path(str)は所在、numeric(bool)は指標演算値か。
        返り値: None。不一致はAssertionError。
        """
        if isinstance(actual, dict):
            assert isinstance(expected, dict) and set(actual) == set(expected), (path, "キー差", set(actual), set(expected))
            for key in actual:
                is_value = key == "value" and set(actual) == {"known", "value"}
                is_calculated = path.endswith(".values") and key not in ("signed_close_minus_support", "signed_body")
                self.compare(actual[key], expected[key], path + "." + key, is_value or is_calculated)
        elif isinstance(actual, list):
            assert isinstance(expected, list) and len(actual) == len(expected), (path, "配列長差")
            for index, pair in enumerate(zip(actual, expected)):
                self.compare(*pair, path=f"{path}[{index}]", numeric=numeric)
        else:
            self.count += 1
            if numeric and isinstance(actual, (int, float, Decimal)) and not isinstance(actual, bool):
                self.numeric += 1
                difference = abs(Decimal(str(actual)) - Decimal(str(expected)))
                if difference > self.maximum:
                    self.maximum, self.maximum_path = difference, path
                assert difference <= TOLERANCE, (path, actual, expected, difference)
            else:
                assert actual == expected and isinstance(actual, bool) == isinstance(expected, bool), (path, actual, expected)


# ----------------------------------------
def bank_check(series):
    """
    機能: 全quoteを再形成し、各Advanceのbank入力を独立照合する。
    引数: series(dict)はSHA認証済み手製系列。
    返り値: tuple[dict,dict]は検査要約とcase/index別の独立bank。
    """
    implementation = load_module("independent_bank117", HERE / "bankを再形成する.py")
    comparison, banks, summaries = Comparison(), {}, []
    for case in series["cases"]:
        bank = implementation.Bank(case["entry"]["scope"])
        snapshots = {quote["index"]: bank.step(quote) for quote in case["quotes"]}
        references = 0
        for index, step in enumerate(case["steps"]):
            saved = dict(step["input"]["bank_snapshot"])
            fingerprint = saved.pop("sha256")
            assert len(fingerprint) == 64
            quote_index = saved["quote"]["index"]
            comparison.compare(snapshots[quote_index], saved, f"{case['id']}.step[{index}].bank")
            references += 1
        banks[case["id"]] = snapshots
        first_known = {}
        for key in ("centered_ema12", "centered_ema26", "signal", "histogram", "atr"):
            first_known[key] = next(({"index": s["quote"]["index"], "closed_bars": s["closed_bars"], "time": s["quote"]["time"]} for s in snapshots.values() if s["committed"][key]["known"]), None)
        summaries.append({"case": case["id"], "quotes": len(case["quotes"]), "保存bank照合数": references, "最終Epoch": bank.epoch, "最終確定総数": bank.total, "確定指標の初回既知": first_known})
    return {"成功": True, "case数": len(summaries), "case": summaries, "比較scalar数": comparison.count, "許容対象の指標数値比較数": comparison.numeric, "指標最大絶対差": str(comparison.maximum), "最大差所在": comparison.maximum_path, "許容絶対差": str(TOLERANCE), "Decimal精度": 50, "SHA再形成": False, "SHAの扱い": "入力人工bytesを認証。Go JSON float字句によるSnapshot指紋の再計算は範囲外"}, banks


def main():
    """
    機能: 許可済み人工だけを検算し、新規結果先へ証拠を保存する。
    引数: CLI --out(Path)は自所有内の未作成フォルダ。
    返り値: None。既存先又は不一致は失敗。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--state", action="store_true")
    args = parser.parse_args()
    out = args.out.resolve()
    assert out.is_relative_to(HERE) and not out.exists(), "新規自所有先が必要"
    code = sorted(HERE.glob("*.py"))
    references = [REFERENCE_GO / name for name in ("bank.go", "numeric.go", "state.go", "types.go", "helpers.go", "export_test.go")]
    documents = [HERE / "README.md"] if (HERE / "README.md").exists() else []
    inputs = [SERIES] + code + references + documents
    before = {str(path): sha(path) for path in inputs}
    assert before[str(SERIES)] == EXPECTED
    series = json.loads(SERIES.read_text(encoding="utf-8"), parse_float=Decimal)
    assert series["人工"] is True and series["市場"] is False and series["FAR自然生成"] is False
    result, banks = bank_check(series)
    payload = {"試行": 117, "成功": True, "人工のみ": True, "bank": result, "state": {"実行": False}, "Go参照の扱い": "一次コードの所在とSHAだけを固定。Goコードのimport/実行、Go計算期待値の呼出しは行わない", "Go実行": False, "金額保護検算": False, "注文検算": False, "自然データ読取": False, "正式停止": False}
    if args.state:
        state = load_module("independent_state117", HERE / "警戒を再形成する.py")
        payload["state"] = state.state_check(series, banks, Comparison)
    after = {str(path): sha(path) for path in inputs}
    assert before == after
    payload.update({"入力SHA256": before, "後SHA256": after, "前後不変": True})
    out.mkdir()
    (out / "確認.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "結果": str(out / "確認.json"), "SHA256": sha(out / "確認.json"), "bank比較数": result["比較scalar数"], "state実行": args.state}, ensure_ascii=False))


if __name__ == "__main__":
    main()
