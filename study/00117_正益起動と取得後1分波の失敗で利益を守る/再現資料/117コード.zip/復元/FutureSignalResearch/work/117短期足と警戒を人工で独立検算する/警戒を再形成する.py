"""独立bankから取得後支持と短期S/M/V警戒を再形成する。"""

from copy import deepcopy
from decimal import Decimal, ROUND_CEILING, localcontext

UNKNOWN, FALSE, TRUE = 0, 1, 2


def truth(flag):
    """
    機能: 既知boolを三値票へ写す。
    引数: flag(bool)は独立に計算した真偽。
    返り値: intはTRUE又はFALSE。
    """
    return TRUE if flag else FALSE


def conjunction(*votes):
    """
    機能: 未知を0補完せず、既知偽を優先するANDを計算する。
    引数: votes(tuple[int])は三値票。
    返り値: intはFALSE/UNKNOWN/TRUE。
    """
    return FALSE if FALSE in votes else UNKNOWN if UNKNOWN in votes else TRUE


def signed(price, entry):
    """
    機能: 売買を同一符号の取得価格差へ写す。
    引数: price(Decimal)、entry(dict)は価格と実取得。
    返り値: Decimalは順側が正の差。
    """
    return entry["side"] * (price - entry["price"])


def acquired_bar(bar, entry):
    """
    機能: 足全体が実取得以後の原行から成るか判定する。
    引数: bar(dict)、entry(dict)は足と実取得。
    返り値: boolは確定かつ時刻/Index/物理行の条件成立。
    """
    fill = entry["fill_quote"]
    return bar["complete"] and bar["start"] >= fill["time"] and bar["first"]["index"] >= fill["index"] and bar["first"]["source_line"] >= fill["source_line"]


def support_candidate(bars, entry, quote):
    """
    機能: 取得後の確定3本から正の局所支持を抽出する。
    引数: bars(list[dict])、entry(dict)、quote(dict)は確定窓・取得・配送原行。
    返り値: dict|Noneは中心谷と確認足を含む支持候補。
    """
    if len(bars) < 3:
        return None
    left, center, right = bars[-3:]
    if not all(acquired_bar(bar, entry) for bar in (left, center, right)) or left["end"] != center["start"] or center["end"] != right["start"] or right["published"] != quote:
        return None
    lows = [min(signed(bar["high"], entry), signed(bar["low"], entry)) for bar in (left, center, right)]
    boundary = lows[1]
    if not (boundary > 0 and boundary < lows[0] and boundary <= lows[2]):
        return None
    ceiling = max(max(signed(bar["high"], entry), signed(bar["low"], entry)) for bar in (left, center, right))
    return {"id": center["id"] + "/confirmed/" + right["id"], "center": deepcopy(center), "left": deepcopy(left), "right": deepcopy(right), "confirmed": deepcopy(quote), "price": entry["price"] + entry["side"] * boundary, "signed_boundary": boundary, "signed_ceiling": ceiling}


def can_arm(support, bar, entry, quote):
    """
    機能: 支持確認後の別確定足が現在原行で支持を有効化できるか判定する。
    引数: support(dict|None)、bar(dict|None)、entry/quote(dict)は当時入力。
    返り値: boolはClose突破/Hist順側/前ATR正の全条件成立。
    """
    if support is None or bar is None:
        return False
    histogram, atr = bar["technical"]["histogram"], bar["previous_atr"]
    return acquired_bar(bar, entry) and bar["published"] == quote and bar["end"] > support["right"]["end"] and quote["index"] > support["confirmed"]["index"] and signed(bar["close"], entry) > support["signed_ceiling"] and histogram["known"] and entry["side"] * histogram["value"] > 0 and atr["known"] and atr["value"] > 0


# ----------------------------------------
def inspect(view, bank):
    """
    機能: 現在prefixの生S/M/Vと不足・否定理由を独立に再計算する。
    引数: view(dict)は監視状態、bank(dict)は独立bank。
    返り値: dictは未ラッチ時点のDecision。
    """
    d = {"duplicate": False, "new_raw": False, "candidate_now": False, "armed_now": False, "reset_now": False, "narrowed_now": False, "armed": view["armed"], "narrowed": view["narrowed"], "s": UNKNOWN, "m": UNKNOWN, "v": UNKNOWN, "warning": UNKNOWN, "values": {}, "missing": [], "denied": []}
    if "target_width_points" in view:
        d["target_width_points"] = view["target_width_points"]
    prefix, entry = bank["prefix"], view["entry"]
    if view["armed"] and "armed_support" in view:
        distance = entry["side"] * (prefix["close"] - view["armed_support"]["price"])
        d["values"]["signed_close_minus_support"] = distance
        d["s"] = truth(distance < 0)
        if d["s"] == FALSE:
            d["denied"].append("局所支持のstrict逆抜けなし")
    else:
        d["missing"].append("有効な取得後支持なし")
    histogram = prefix["technical"]["histogram"]
    if histogram["known"]:
        h = entry["side"] * histogram["value"]
        d["values"]["signed_histogram"] = h
        d["m"] = truth(h <= 0)
        if d["m"] == FALSE:
            d["denied"].append("Hist順側を維持")
    else:
        d["missing"].append("暫定Hist未知")
    body = entry["side"] * (prefix["close"] - prefix["open"])
    d["values"].update({"signed_body": body, "tr": deepcopy(prefix["tr"]), "previous_atr": deepcopy(prefix["previous_atr"])})
    body_vote, range_vote, scale_vote = truth(body < 0), UNKNOWN, UNKNOWN
    if body_vote == FALSE:
        d["denied"].append("反対bodyなし")
    atr, tr = prefix["previous_atr"], prefix["tr"]
    if atr["known"]:
        scale_vote = truth(atr["value"] > 0)
        if scale_vote == FALSE:
            d["denied"].append("前ATR尺度が非正")
    else:
        d["missing"].append("前確定ATR未知")
    if tr["known"] and atr["known"]:
        range_vote = truth(tr["value"] >= atr["value"])
        if range_vote == FALSE:
            d["denied"].append("形成TRが前ATR未満")
    elif not tr["known"]:
        d["missing"].append("形成TR未知")
    d["v"] = conjunction(body_vote, range_vote, scale_vote)
    d["warning"] = conjunction(truth(view["armed"]), d["s"], d["m"], d["v"])
    return d


def witness(view, bank, phase, active, remaining, decision, kind):
    """
    機能: 当時の入力と独立計算票を初回根拠として固定する。
    引数: view/bank/decision(dict)、phase/kind(str)、active(bool)、remaining(int)。
    返り値: dictは取得後支持・breakout・prefixを含む独立Witness。
    """
    result = {"kind": kind, "at": deepcopy(bank["quote"]), "phase": phase, "bank_sha256": bank["sha256"], "bank_epoch": bank["epoch"], "prefix": deepcopy(bank["prefix"]), "values": deepcopy(decision.get("values", {"tr": {"known": False, "value": 0}, "previous_atr": {"known": False, "value": 0}})), "s": decision.get("s", UNKNOWN), "m": decision.get("m", UNKNOWN), "v": decision.get("v", UNKNOWN), "warning": decision.get("warning", UNKNOWN), "a_arm": deepcopy(view["a_arm"]), "active": active, "remaining": remaining}
    for source, destination in (("armed_support", "support"), ("breakout", "breakout"), ("target_width_points", "target_width_points")):
        if source in view:
            result[destination] = deepcopy(view[source])
    return result


class State:
    """取得後の支持と不可逆な短期警戒を持つ独立状態。"""

    def __init__(self, entry):
        """
        機能: 実取得条件から、初期の非armed状態を作る。
        引数: entry(dict)は手製実取得。
        返り値: None。
        """
        self.view = {"version": 117, "entry": deepcopy(entry), "sequence": 0, "raw_updates": 0, "phase": "", "bank_epoch": 0, "external_active": False, "armed": False, "a_arm": {"known": False, "value": 0}, "narrowed": False}
        self.last, self.pending, self.decision = None, None, None

    def advance(self, bank, phase, active, remaining):
        """
        機能: 新Rawを一度進め、同Rawpre→afterだけ位相更新する。
        引数: bank(dict)、phase(str)、active(bool)、remaining(int)は当時入力。
        返り値: dictはDecision。n0/同位相変更/逆行はAssertionError。
        """
        with localcontext() as context:
            context.prec = 50
            return self._advance(bank, phase, active, remaining)

    def _advance(self, bank, phase, active, remaining):
        """
        機能: Decimal50文脈内で一つの状態遷移を処理する。
        引数: bank(dict)、phase(str)、active(bool)、remaining(int)は検査入力。
        返り値: dictは独立Decision。
        """
        entry, quote = self.view["entry"], bank["quote"]
        assert 1 <= remaining <= entry["initial_quantity"] and phase in ("pre_fill", "after_source") and bank["scope"] == entry["scope"]
        fill = entry["fill_quote"]
        assert quote["index"] >= fill["index"] and quote["source_line"] >= fill["source_line"] and quote["time"] >= fill["time"]
        assert not self.view["external_active"] or active
        new_raw = self.last is None or quote["index"] > self.last["quote"]["index"]
        if self.last is not None:
            old = self.last
            assert remaining <= old["remaining"]
            if new_raw:
                assert quote["source_line"] > old["quote"]["source_line"] and quote["time"] >= old["quote"]["time"] and bank["epoch"] >= self.view["bank_epoch"]
            else:
                assert quote == old["quote"] and bank["sha256"] == old["sha"]
                if phase == old["phase"]:
                    assert active == old["active"] and remaining == old["remaining"]
                    d = deepcopy(self.decision)
                    d.update({"duplicate": True, "new_raw": False, "candidate_now": False, "armed_now": False, "reset_now": False, "narrowed_now": False})
                    return d
                assert old["phase"] == "pre_fill" and phase == "after_source"
        view = deepcopy(self.view)
        view["sequence"] += 1
        view.update({"at": deepcopy(quote), "phase": phase, "external_active": active})
        reset_now, candidate_now, armed_now = False, False, False
        if new_raw:
            view["raw_updates"] += 1
            self.pending = None
            if self.last is not None and view["bank_epoch"] != bank["epoch"]:
                for key in ("candidate", "armed_support", "breakout"):
                    view.pop(key, None)
                view["armed"], view["a_arm"], reset_now = False, {"known": False, "value": 0}, True
                view["last_reset"] = witness(view, bank, phase, active, remaining, {}, "短期bankのepoch reset。既狭幅は維持")
            view["bank_epoch"] = bank["epoch"]
            if bank.get("gap") is None:
                if can_arm(view.get("candidate"), bank.get("closed_now"), entry, quote):
                    self.pending = {"support": deepcopy(view["candidate"]), "breakout": deepcopy(bank["closed_now"])}
                proposed = support_candidate(bank["recent_closed"], entry, quote)
                if proposed is not None and (view.get("candidate") is None or proposed["signed_boundary"] > view["candidate"]["signed_boundary"]) and (view.get("armed_support") is None or proposed["signed_boundary"] > view["armed_support"]["signed_boundary"]):
                    view["candidate"], candidate_now = proposed, True
        if active and self.pending is not None and (view.get("armed_support") is None or self.pending["support"]["signed_boundary"] > view["armed_support"]["signed_boundary"]):
            view["armed"], view["armed_support"], view["breakout"] = True, deepcopy(self.pending["support"]), deepcopy(self.pending["breakout"])
            view["a_arm"] = deepcopy(view["breakout"]["previous_atr"])
            armed_now = True
        d = inspect(view, bank)
        d.update({"new_raw": new_raw, "reset_now": reset_now, "candidate_now": candidate_now, "armed_now": armed_now})
        if armed_now:
            view["last_arm"] = witness(view, bank, phase, active, remaining, d, "取得後の別確定closeで支持を有効化")
            if "first_arm" not in view:
                view["first_arm"] = deepcopy(view["last_arm"])
        if not view["narrowed"] and d["warning"] == TRUE:
            assert view["a_arm"]["known"] and view["a_arm"]["value"] > 0
            view["narrowed"] = True
            raw_width = max(Decimal(5), min(entry["normal_width_points"], view["a_arm"]["value"]))
            view["target_width_points"] = 5 * (raw_width / 5).to_integral_value(rounding=ROUND_CEILING)
            d.update({"narrowed_now": True, "narrowed": True, "target_width_points": view["target_width_points"]})
            view["first_warning"] = witness(view, bank, phase, active, remaining, d, "S AND M AND Vの最初の複合警戒")
        d["armed"], d["narrowed"] = view["armed"], view["narrowed"]
        if "target_width_points" in view:
            d["target_width_points"] = view["target_width_points"]
        self.last = {"quote": deepcopy(quote), "sha": bank["sha256"], "phase": phase, "active": active, "remaining": remaining}
        self.view, self.decision = view, deepcopy(d)
        return deepcopy(d)


# ----------------------------------------
def state_check(series, banks, comparison_type):
    """
    機能: 保存前後StateとDecisionを独立bank/独立状態から照合する。
    引数: series(dict)、banks(dict)、comparison_type(type)は手製入力・独立足・比較器。
    返り値: dictは正例94Advanceと重複/n0/未来/破壊反例の検査結果。
    """
    comparison, summaries, extra = comparison_type(), [], []
    boundaries = {"Hist": [], "TRと前ATRの差": []}
    for case in series["cases"]:
        state = State(case["entry"])
        comparison.compare(state.view, case["initial_snapshot"], case["id"] + ".initial")
        events = {key: 0 for key in ("candidate_now", "armed_now", "reset_now", "narrowed_now")}
        for index, step in enumerate(case["steps"]):
            prefix = f"{case['id']}.step[{index}]"
            comparison.compare(state.view, step["before_snapshot"], prefix + ".before")
            saved_input = step["input"]
            bank = deepcopy(banks[case["id"]][saved_input["bank_snapshot"]["quote"]["index"]])
            # 内容はbank検算済み。SHAはGoのfloat字句が表す同じ入力の識別子としてだけ受け継ぐ。
            bank["sha256"] = saved_input["bank_snapshot"]["sha256"]
            histogram = bank["prefix"]["technical"]["histogram"]
            if histogram["known"]:
                boundaries["Hist"].append(abs(histogram["value"]))
            tr, atr = bank["prefix"]["tr"], bank["prefix"]["previous_atr"]
            if tr["known"] and atr["known"]:
                boundaries["TRと前ATRの差"].append(abs(tr["value"] - atr["value"]))
            d = state.advance(bank, saved_input["phase"], saved_input["active"], saved_input["remaining"])
            comparison.compare(state.view, step["after_snapshot"], prefix + ".after")
            comparison.compare(d, step["decision"], prefix + ".decision")
            for key in events:
                events[key] += int(d[key])
            # 同じ位相・入力の再送は状態も初回旗も増やさない。
            before = deepcopy(state.view)
            repeat = state.advance(bank, saved_input["phase"], saved_input["active"], saved_input["remaining"])
            assert state.view == before and repeat["duplicate"]
            assert not any(repeat[key] for key in events) and not repeat["new_raw"]
            # 残0と同位相の数量変更は拒否し、状態を壊さない。
            for quantity in (0, saved_input["remaining"] - 1):
                try:
                    state.advance(bank, saved_input["phase"], saved_input["active"], quantity)
                except AssertionError:
                    pass
                else:
                    raise AssertionError((prefix, "n0又は同phase変更を受理"))
                assert state.view == before
        assert events["armed_now"] >= 1 and events["narrowed_now"] == 1 and events["reset_now"] >= 1
        assert state.view["narrowed"] and not state.view["armed"]
        summaries.append({"case": case["id"], "Advance数": len(case["steps"]), "事象数": events, "最終Sequence": state.view["sequence"], "最終RawUpdates": state.view["raw_updates"], "固定狭幅": str(state.view["target_width_points"]), "同phase冪等検査数": len(case["steps"]), "n0拒否と同phase変更拒否数": 2 * len(case["steps"])})
    # 比較器が三値/幅/公表原行の破壊を数値許容で握り潰さないことを確認する。
    for original, damaged, label in (({"warning": TRUE}, {"warning": FALSE}, "三値"), ({"target_width_points": 20}, {"target_width_points": 25}, "狭幅"), ({"quote": {"index": 4}}, {"quote": {"index": 5}}, "公表原行")):
        try:
            comparison_type().compare(original, damaged)
        except AssertionError:
            extra.append(label)
        else:
            raise AssertionError("破壊を検出できない:" + label)
    threshold_summary = {key: {"判定数": len(values), "最小絶対距離": str(min(values)), "厳密等号数": sum(item == 0 for item in values), "非ゼロで絶対1e-9以下": sum(0 < item <= Decimal("1e-9") for item in values)} for key, values in boundaries.items()}
    return {"実行": True, "成功": True, "Advance数": sum(item["Advance数"] for item in summaries), "case": summaries, "比較scalar数": comparison.count, "指標数値比較数": comparison.numeric, "指標最大絶対差": str(comparison.maximum), "最大差所在": comparison.maximum_path, "破壊検出": extra, "指標閾値との距離": threshold_summary, "許容差による真偽修正数": 0, "支持価格と幅と三値とboolと公表原行": "厳密一致。指標演算値だけbankと同じ絶対許容差", "限界": ["手製2系列の正例と明示した追加拒否のみ。自然相場全Rawの最初性を証明しない", "同phase再送とn0/同phase変更拒否はPython側の追加手製検査。入力94AdvanceのGoとの全値対照とは分ける", "入力のGo Snapshot SHAは内容再形成照合後の識別子として使用し、Go float JSON指紋をDecimalから再生成しない", "金額State・予約・注文・約定は対象外"]}
