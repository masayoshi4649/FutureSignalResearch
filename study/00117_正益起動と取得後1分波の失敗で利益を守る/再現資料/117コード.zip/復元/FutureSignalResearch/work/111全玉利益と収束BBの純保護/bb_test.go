package profitfloor111

import (
	"fmt"
	"math"
	"reflect"
	"testing"
)

// barFixture は同じ場の確定3分足を一つ作ります。
//
// 引数: index(int)、price(float64)は人工ordinalと終値。返り値: ClosedBarは正常公表です。
func barFixture(index int, price float64) ClosedBar {
	return ClosedBar{Scope: Scope{"人工場", "限月", 0}, ID: fmt.Sprintf("足%d", index), Ordinal: uint64(index), Start: float64((index - 1) * 180), End: float64(index * 180), AvailableAt: float64(index * 180), Known: true, Close: pointer(price)}
}

// bbPrefix は指定した手製価格だけで純BB窓を進めます。
//
// 引数: t(*testing.T)、prices([]float64)は人工列。返り値: BBState/[]BBResultは各当時結果です。
func bbPrefix(t *testing.T, prices []float64) (BBState, []BBResult) {
	t.Helper()
	s, err := NewBBState(Scope{"人工場", "限月", 0})
	if err != nil {
		t.Fatal(err)
	}
	out := []BBResult{}
	for i, p := range prices {
		b := barFixture(i+1, p)
		next, r, e := AdvanceBB(s, b, b.AvailableAt)
		if e != nil {
			t.Fatal(e)
		}
		s = next
		out = append(out, r)
	}
	return s, out
}

// contractingFixture は低端の古い値が抜けて幅が連続縮小する人工列を作ります。
//
// 引数: なし。返り値: []float64は22本の手製終値です。
func contractingFixture() []float64 {
	p := []float64{}
	for i := 0; i < 20; i++ {
		p = append(p, 1000+5*float64(i))
	}
	return append(p, 1050, 1050)
}

// TestBBPopulationAndWarmup は20母分散と3幅の成立時点を確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestBBPopulationAndWarmup(t *testing.T) {
	_, out := bbPrefix(t, contractingFixture())
	for i := 0; i < 19; i++ {
		if out[i].Known || out[i].Contraction != Unknown {
			t.Fatal("20本未満を既知化")
		}
	}
	r := out[19]
	if !r.Known || r.WindowBars != 20 || math.Abs(*r.SMA-1047.5) > 1e-9 || math.Abs(*r.Sigma**r.Sigma-831.25) > 1e-8 || r.Contraction != Unknown {
		t.Fatalf("母分散又は助走差:%+v", r)
	}
	if out[20].Contraction != Unknown || out[21].Contraction != True {
		t.Fatal("幅3公表のstrict縮小差")
	}
	constant := []float64{}
	for i := 0; i < 22; i++ {
		constant = append(constant, 1000)
	}
	_, flat := bbPrefix(t, constant)
	if *flat[21].Width != 0 || flat[21].PercentB != nil || flat[21].Contraction != False {
		t.Fatal("ゼロ幅又は等号を収縮と誤認")
	}
}

// TestBBMirrorAndFutureNoninterference は幅の買売鏡像と過去不変を確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestBBMirrorAndFutureNoninterference(t *testing.T) {
	prices := contractingFixture()
	mirrored := make([]float64, len(prices))
	for i, x := range prices {
		mirrored[i] = 3000 - x
	}
	s, a := bbPrefix(t, prices)
	_, b := bbPrefix(t, mirrored)
	for i := range a {
		if a[i].Known != b[i].Known || a[i].Contraction != b[i].Contraction || a[i].Known && (*a[i].Sigma != *b[i].Sigma || *a[i].Width != *b[i].Width) {
			t.Fatal("BB幅の鏡像差")
		}
	}
	before := s.Snapshot()
	bar := barFixture(23, 2000)
	next, r, err := AdvanceBB(s, bar, bar.AvailableAt)
	if err != nil {
		t.Fatal(err)
	}
	r.Width = pointer(999)
	copy := next.Snapshot()
	copy.Width = pointer(888)
	if !reflect.DeepEqual(s.Snapshot(), before) || next.Snapshot().Width == copy.Width {
		t.Fatal("未来追加又はSnapshotで過去が変化")
	}
}

// TestBBCausalityGapsAndIdentity は未来・欠足・未知・同ID変更を分けます。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestBBCausalityGapsAndIdentity(t *testing.T) {
	s, out := bbPrefix(t, contractingFixture())
	last := barFixture(22, 1050)
	same, r, err := AdvanceBB(s, last, last.AvailableAt+1)
	if err != nil || !reflect.DeepEqual(r, out[21]) || !reflect.DeepEqual(same.Snapshot(), s.Snapshot()) {
		t.Fatal("同体再送の冪等性")
	}
	for _, alter := range []func(*ClosedBar, *float64){func(b *ClosedBar, a *float64) { *b.Close += 5 }, func(b *ClosedBar, a *float64) { b.Scope.Contract = "別限月" }, func(b *ClosedBar, a *float64) { *a = b.AvailableAt - 1 }, func(b *ClosedBar, a *float64) { b.AvailableAt = b.End - 1 }, func(b *ClosedBar, a *float64) { b.Known = false }, func(b *ClosedBar, a *float64) { b.Start += 1 }} {
		b := barFixture(23, 1050)
		at := b.AvailableAt
		alter(&b, &at)
		if b.ID == "足23" && b.Close != nil && *b.Close == 1055 {
			b.ID = "足22"
			b.Ordinal = 22
			b.Start = 3780
			b.End = 3960
			b.AvailableAt = 3960
			at = 3960
		}
		before := s.Snapshot()
		_, _, err = AdvanceBB(s, b, at)
		if err == nil || !reflect.DeepEqual(before, s.Snapshot()) {
			t.Fatal("不正BB入力受理又は過去変更")
		}
	}
	gap := barFixture(24, 1050)
	g, r, err := AdvanceBB(s, gap, gap.AvailableAt)
	if err != nil || r.Known || r.WindowBars != 1 || r.ResetReason != "欠足" || r.Contraction != Unknown {
		t.Fatal("欠足に過去BBを継承")
	}
	bad := barFixture(25, 0)
	bad.Known = false
	bad.Close = nil
	_, r, err = AdvanceBB(g, bad, bad.AvailableAt)
	if err != nil || r.WindowBars != 0 || r.Known || r.Width != nil {
		t.Fatal("未知足をゼロ価格へ補完")
	}
}

// TestBBAddsContractionRoleWithoutDoubleVote はC偽でもBBとMの複合を確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestBBAddsContractionRoleWithoutDoubleVote(t *testing.T) {
	_, out := bbPrefix(t, contractingFixture())
	bb := out[21]
	for _, policy := range []Policy{W100, T100, B100, B50} {
		e := entryFixture(policy, 1, 1, nil)
		s := mustState(t, e)
		pub := Publication{Scope: e.Scope, ID: bb.ID, Ordinal: bb.Ordinal, Start: bb.End - 180, End: bb.End, AvailableAt: bb.AvailableAt, C: False, M: True, V: pointer(30), Close: pointer(1050), BB: &bb}
		in := inputFixture(e, 1, 105, 1, 0, 0)
		in.Publication = &pub
		s, d := advanceOK(t, s, in)
		want := policy == B100 || policy == B50
		if d.B != True || d.NarrowedNow != want || s.Snapshot().Narrowed != want {
			t.Fatal("BB追加の政策差")
		}
	}
	e := entryFixture(B100, 1, 1, nil)
	s := mustState(t, e)
	pub := Publication{Scope: e.Scope, ID: bb.ID, Ordinal: bb.Ordinal, Start: bb.End - 180, End: bb.End, AvailableAt: bb.AvailableAt, C: False, M: False, V: pointer(30), Close: pointer(1050), BB: &bb}
	in := inputFixture(e, 1, 105, 1, 0, 0)
	in.Publication = &pub
	s, d := advanceOK(t, s, in)
	if d.Warning != False || s.Snapshot().Narrowed {
		t.Fatal("BB縮小単独を警戒に変換")
	}
	pub.BB = copyValue(&bb)
	pub.BB.DeliveredAt = 5000
	in.Publication = &pub
	if _, _, err := Advance(mustState(t, e), in); err == nil {
		t.Fatal("未来BBを受理")
	}
}
