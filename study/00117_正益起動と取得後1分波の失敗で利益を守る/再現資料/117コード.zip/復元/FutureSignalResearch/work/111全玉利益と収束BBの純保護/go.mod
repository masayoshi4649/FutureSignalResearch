module github.com/masayoshi4649/SessionTradeExecuter/profitfloor111

go 1.24.2
