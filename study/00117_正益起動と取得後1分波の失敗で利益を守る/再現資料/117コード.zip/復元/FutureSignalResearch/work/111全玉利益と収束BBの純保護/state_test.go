package profitfloor111

import (
	"encoding/json"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"testing"
)

// entryFixture は政策と方向だけを変えた同じ実取得を作ります。
//
// 引数: p(Policy)、side(int)、q(int)、atr(*float64)は人工条件。返り値: Entryは市場を使わない正常値です。
func entryFixture(p Policy, side, q int, atr *float64) Entry {
	e := Entry{Scope: Scope{"人工場", "限月", 0}, Policy: p, Side: side, Price: 1000, At: 3600, InitialQuantity: q}
	if atr != nil {
		e.ATR = &Evidence{*atr, 3600, "取得ATR"}
	}
	return e
}

// mustState は人工取得から正常な純状態を作ります。
//
// 引数: t(*testing.T)、e(Entry)は人工。返り値: Stateは成功状態です。
func mustState(t *testing.T, e Entry) State {
	t.Helper()
	s, err := NewState(e)
	if err != nil {
		t.Fatal(err)
	}
	return s
}

// inputFixture は一つの正常原行と実会計値を作ります。
//
// 引数: e(Entry)、seq(uint64)、gain(float64)、n/r(int)、realized(float64)は人工値。返り値: Inputは現在気配です。
func inputFixture(e Entry, seq uint64, gain float64, n, r int, realized float64) Input {
	return Input{At: 4000 + float64(seq), Sequence: seq, Phase: AfterSource, Mark: pointer(e.Price + float64(e.Side)*gain), Remaining: n, Reserved: r, ClosedNetYen: realized}
}

// advanceOK は人工入力の成功だけを受け取ります。
//
// 引数: t(*testing.T)、s(State)、in(Input)は人工。返り値: State/Decisionは純結果です。
func advanceOK(t *testing.T, s State, in Input) (State, Decision) {
	t.Helper()
	n, d, err := Advance(s, in)
	if err != nil {
		t.Fatal(err)
	}
	return n, d
}

// publicationFixture は確定3分の既知C/M/Vを作ります。
//
// 引数: e(Entry)、c/m(Truth)、v(*float64)は人工条件。返り値: Publicationは4000以前に可用です。
func publicationFixture(e Entry, c, m Truth, v *float64) Publication {
	return Publication{Scope: e.Scope, ID: "公表21", Ordinal: 21, Start: 3600, End: 3780, AvailableAt: 3780, C: c, M: m, V: v, Close: pointer(1100)}
}

// TestDeclarationsAndLockedWidth は実宣言24とH感度の幅同体を確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestDeclarationsAndLockedWidth(t *testing.T) {
	configs := DeclaredConfigurations()
	if len(configs) != 24 {
		t.Fatal("24宣言不足")
	}
	seen := map[Configuration]bool{}
	for _, c := range configs {
		if seen[c] {
			t.Fatal("宣言重複")
		}
		seen[c] = true
	}
	for _, a := range []*float64{nil, pointer(80), pointer(123)} {
		var width float64
		for _, p := range []Policy{U100, W100, T100, B100, B50} {
			e := entryFixture(p, 1, 2, a)
			s := mustState(t, e)
			v := s.Snapshot()
			if width == 0 {
				width = v.NormalWidth
			}
			if width != v.NormalWidth {
				t.Fatal("Hで通常幅が変化")
			}
			if p == B50 && v.ThresholdPoints != 50 || p != B50 && v.ThresholdPoints != 100 {
				t.Fatal("H宣言差")
			}
			if a == nil && (!v.ATRUnknownFallback || width != 200) {
				t.Fatal("未知ATRを待機に変換")
			}
		}
	}
	if _, err := NewState(entryFixture(S0, 1, 1, nil)); err == nil {
		t.Fatal("S0はActorの元保護対照")
	}
	if path := os.Getenv("PROFIT111_DECLARATION"); path != "" {
		raw, err := json.MarshalIndent(map[string]any{"module": "profitfloor111", "configurations": DeclaredConfigurations(), "S0": "Actor側で扱い純状態は生成しない", "guard_policies": []Policy{U100, W100, T100, B100, B50}, "通常幅": "ceil5(max(200,2*A_entry))、未知200", "入力の会計": "同PositionのR/n/r/q0"}, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		if err = os.MkdirAll(filepath.Dir(path), 0700); err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(path, append(raw, '\n'), 0600); err != nil {
			t.Fatal(err)
		}
	}
}

// TestMandatoryActivationNoRetroPeak は利益直後と一定利益を分け、起動前峰を持ち込みません。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestMandatoryActivationNoRetroPeak(t *testing.T) {
	for _, p := range []Policy{U100, W100, T100, B100, B50} {
		for _, slip := range []float64{0, 5} {
			e := entryFixture(p, 1, 1, nil)
			e.SlipPoints = slip
			s := mustState(t, e)
			h := s.Snapshot().ThresholdPoints
			s, d := advanceOK(t, s, inputFixture(e, 1, h, 1, 0, 0))
			if d.ActivatedNow || s.Snapshot().PeakPoints != nil {
				t.Fatal("費用控除前値幅又は起動前峰を使用")
			}
			s, d = advanceOK(t, s, inputFixture(e, 2, h+15, 1, 0, 0))
			if !d.ActivatedNow || !s.Snapshot().Active || *s.Snapshot().PeakPoints != h+15 {
				t.Fatal("一定利益で必須起動なし")
			}
		}
	}
	e := entryFixture(W100, 1, 2, nil)
	s := mustState(t, e)
	s, d := advanceOK(t, s, inputFixture(e, 1, 150, 2, 0, 0))
	if !d.ActivatedNow {
		t.Fatal("起動不足")
	}
	s, d = advanceOK(t, s, inputFixture(e, 2, 20, 2, 0, 0))
	if d.ActivatedNow || !s.Snapshot().Active {
		t.Fatal("必須保護の解除")
	}
}

// TestPartialLossWholeAccounting は先行部分損失とu/Wの違いを確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestPartialLossWholeAccounting(t *testing.T) {
	for _, p := range []Policy{U100, W100, B50} {
		e := entryFixture(p, 1, 2, nil)
		s := mustState(t, e)
		s, d := advanceOK(t, s, inputFixture(e, 1, 105, 1, 0, -9077))
		if p == U100 && !d.ActivatedNow || p != U100 && d.ActivatedNow {
			t.Fatal("uとWの起動単位を混同")
		}
		if *d.UnitNetYen != 10423 || *d.WholeNetYen != 1346 {
			t.Fatal("Rの費用を二重控除")
		}
		if p == B50 {
			s, d = advanceOK(t, s, inputFixture(e, 2, 200, 1, 0, -9077))
			if !d.ActivatedNow || d.WholeFloor == nil || *d.WholeFloor != 95 || *s.Snapshot().FloorPoints != 95 || s.Snapshot().WholeTargetYen != 346 {
				t.Fatalf("全玉価格床差:%+v %+v", s.Snapshot(), d)
			}
		}
	}
	e := entryFixture(W100, 1, 2, nil)
	s := mustState(t, e)
	s, _ = advanceOK(t, s, inputFixture(e, 1, 105, 2, 0, 0))
	oldL := s.Snapshot().WholeTargetYen
	s, d := advanceOK(t, s, inputFixture(e, 2, 20, 1, 0, -.5))
	if d.WholeFloor == nil || *d.WholeFloor != 20 || !d.FloorHit || d.EligibleExitQuantity != 1 || s.Snapshot().WholeTargetYen < oldL || s.Snapshot().WholeTargetYen != 1922.5 {
		t.Fatal("半円/部分返済/床等号の式差")
	}
}

// TestReservationsImmediateExitAndCompletion は既予約を二重化せず、床fillを作りません。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestReservationsImmediateExitAndCompletion(t *testing.T) {
	e := entryFixture(W100, 1, 2, nil)
	s := mustState(t, e)
	s, _ = advanceOK(t, s, inputFixture(e, 1, 250, 2, 0, 0))
	floor, l := *s.Snapshot().FloorPoints, s.Snapshot().WholeTargetYen
	for _, reserved := range []int{0, 1} {
		copyS, d := advanceOK(t, s, inputFixture(e, 2, 0, 1, reserved, -77))
		if !d.FloorHit || d.EligibleExitQuantity != 1-reserved || d.AllReservedHit != (reserved == 1) || *copyS.Snapshot().FloorPoints < floor || copyS.Snapshot().WholeTargetYen < l {
			t.Fatal("全玉目標を下げるか過剰要求")
		}
		if d.GainPoints == nil || *d.GainPoints != 0 {
			t.Fatal("床価格での架空成立")
		}
	}
	in := inputFixture(e, 2, 0, 1, 0, -77)
	in.Phase = PreFill
	_, d := advanceOK(t, s, in)
	if !d.FloorHit || d.EligibleExitQuantity != 0 {
		t.Fatal("fill前の即約定要求")
	}
	s, d = advanceOK(t, s, inputFixture(e, 3, 0, 0, 0, -154))
	if !s.Snapshot().Finished || d.EligibleExitQuantity != 0 {
		t.Fatal("残0又は除算処理")
	}
	if _, _, err := Advance(s, inputFixture(e, 4, 0, 0, 0, -154)); err == nil {
		t.Fatal("完了後更新")
	}
}

// TestNormalContractionAndTechnicalLatch はVだけの縮小を抑え複合失速だけをラッチします。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestNormalContractionAndTechnicalLatch(t *testing.T) {
	for _, p := range []Policy{U100, W100, T100, B100} {
		e := entryFixture(p, 1, 1, pointer(100))
		s := mustState(t, e)
		s, _ = advanceOK(t, s, inputFixture(e, 1, 300, 1, 0, 0))
		pub := publicationFixture(e, True, False, pointer(10))
		in := inputFixture(e, 2, 290, 1, 0, 0)
		in.Publication = &pub
		s, d := advanceOK(t, s, in)
		if s.Snapshot().WidthPoints != 200 || d.NarrowedNow {
			t.Fatal("収束又はVだけで狭幅")
		}
		pub.ID = "公表22"
		pub.Ordinal++
		pub.Start += 180
		pub.End += 180
		pub.AvailableAt += 180
		pub.M = True
		in = inputFixture(e, 3, 290, 1, 0, 0)
		in.Publication = &pub
		s, d = advanceOK(t, s, in)
		tech := p == T100 || p == B100
		if d.NarrowedNow != tech || s.Snapshot().Narrowed != tech {
			t.Fatal("政策別狭幅差")
		}
		if tech && s.Snapshot().WidthPoints != 10 {
			t.Fatal("技法狭幅値差")
		}
		oldFloor := *s.Snapshot().FloorPoints
		in = inputFixture(e, 4, 280, 1, 0, 0)
		in.ResetReason = "欠足"
		s, _ = advanceOK(t, s, in)
		if *s.Snapshot().FloorPoints < oldFloor || tech && !s.Snapshot().Narrowed {
			t.Fatal("未知化で保護緩和")
		}
	}
}

// TestMirrorAndInputCopies は買売の符号対称と可変参照の独立を確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestMirrorAndInputCopies(t *testing.T) {
	for _, p := range []Policy{U100, W100, T100, B100, B50} {
		for _, slip := range []float64{0, 5} {
			var reference []Decision
			for _, side := range []int{1, -1} {
				e := entryFixture(p, side, 2, pointer(123))
				e.SlipPoints = slip
				s := mustState(t, e)
				snapshot := s.Snapshot()
				snapshot.Entry.ATR.Value = 1
				if s.Snapshot().Entry.ATR.Value != 123 {
					t.Fatal("Snapshot参照共有")
				}
				got := []Decision{}
				for i, g := range []float64{50, 120, 350, 100} {
					in := inputFixture(e, uint64(i+1), g, 2, 0, 0)
					var d Decision
					s, d = advanceOK(t, s, in)
					d.ProtectPrice = nil
					got = append(got, d)
				}
				if reference == nil {
					reference = got
				} else if !reflect.DeepEqual(reference, got) {
					t.Fatalf("売買対称性差:%s", p)
				}
			}
		}
	}
}

// TestStructuralFloorAndWholePositiveResidualLoss は構造床と全玉正益の反例を確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestStructuralFloorAndWholePositiveResidualLoss(t *testing.T) {
	for _, side := range []int{1, -1} {
		e := entryFixture(T100, side, 1, nil)
		s := mustState(t, e)
		p := Publication{Scope: e.Scope, ID: "構造公表", Ordinal: 24, Start: 4140, End: 4320, AvailableAt: 4320, C: True, M: True, Close: pointer(1000 + float64(side)*100), PriorPivot: &Pivot{Scope: e.Scope, ID: "確定pivot", Kind: "low", Price: 1000 + float64(side)*50, CenterStart: 3600, CenterEnd: 3780, ConfirmEnd: 4140, PublishedAt: 4140}}
		if side == -1 {
			p.PriorPivot.Kind = "high"
		}
		in := inputFixture(e, 1, 105, 1, 0, 0)
		in.At = 5000
		in.Publication = &p
		s, d := advanceOK(t, s, in)
		if d.StructuralFloor == nil || *d.StructuralFloor != 45 || *s.Snapshot().FloorPoints != 45 {
			t.Fatal("因果的構造床差")
		}
		old := s.Snapshot()
		in = inputFixture(e, 2, 200, 1, 0, 0)
		in.At = 5001
		next, _ := advanceOK(t, s, in)
		if !reflect.DeepEqual(old, s.Snapshot()) || *next.Snapshot().PeakPoints != 200 {
			t.Fatal("未来追加が過去を変更")
		}
	}
	e := entryFixture(W100, 1, 2, nil)
	s := mustState(t, e)
	s, d := advanceOK(t, s, inputFixture(e, 1, -5, 1, 0, 30077))
	if !d.ActivatedNow || *d.UnitNetYen >= 0 || *d.WholeNetYen < 20000 || !d.FloorHit || d.EligibleExitQuantity != 1 || *s.Snapshot().PeakPoints != -5 {
		t.Fatal("全玉正・残玉負の即要求差")
	}
	e = entryFixture(B100, 1, 1, nil)
	s = mustState(t, e)
	p := publicationFixture(e, True, True, nil)
	in := inputFixture(e, 1, 105, 1, 0, 0)
	in.Publication = &p
	s, d = advanceOK(t, s, in)
	if !d.NarrowedNow || s.Snapshot().WidthPoints != 200 {
		t.Fatal("尺度両未知で幅保持なし")
	}
	in = inputFixture(e, 2, 105, 1, 0, 0)
	in.Mark = nil
	in.ResetReason = "未知"
	next, d := advanceOK(t, s, in)
	if d.GainPoints != nil || *next.Snapshot().FloorPoints != *s.Snapshot().FloorPoints {
		t.Fatal("正常気配なしの市場評価")
	}
}

// TestTruthAndRejections は三値・未来・改竄・会計不整合の拒否を確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestTruthAndRejections(t *testing.T) {
	and := [][]Truth{{Unknown, False, Unknown}, {False, False, False}, {Unknown, False, True}}
	or := [][]Truth{{Unknown, Unknown, True}, {Unknown, False, True}, {True, True, True}}
	for a := Truth(0); a <= True; a++ {
		for b := Truth(0); b <= True; b++ {
			x, e := And(a, b)
			y, f := Or(a, b)
			if e != nil || f != nil || x != and[a][b] || y != or[a][b] {
				t.Fatal("三値真理表差")
			}
		}
	}
	e := entryFixture(T100, 1, 1, nil)
	s := mustState(t, e)
	pub := publicationFixture(e, True, True, pointer(50))
	in := inputFixture(e, 1, 120, 1, 0, 0)
	in.Publication = &pub
	s, _ = advanceOK(t, s, in)
	for _, alter := range []func(*Input){func(x *Input) { x.At = 0 }, func(x *Input) { x.Sequence = 1 }, func(x *Input) { x.Remaining = 2 }, func(x *Input) { x.Reserved = 2 }, func(x *Input) { x.ClosedNetYen = .5 }, func(x *Input) { x.Mark = pointer(math.NaN()) }, func(x *Input) { p := copyValue(pub); p.C = False; x.Publication = &p }, func(x *Input) {
		p := copyValue(pub)
		p.ID = "未来"
		p.Ordinal++
		p.Start = 4500
		p.End = 4680
		p.AvailableAt = 4680
		x.Publication = &p
	}, func(x *Input) { x.ClosedNetYen = .1 }} {
		x := inputFixture(e, 2, 100, 1, 0, 0)
		alter(&x)
		before := s.Snapshot()
		_, _, err := Advance(s, x)
		if err == nil || !reflect.DeepEqual(before, s.Snapshot()) {
			t.Fatal("不正受理又は入力状態変更")
		}
	}
	if _, err := And(Truth(3), False); err == nil {
		t.Fatal("不正三値")
	}
}
