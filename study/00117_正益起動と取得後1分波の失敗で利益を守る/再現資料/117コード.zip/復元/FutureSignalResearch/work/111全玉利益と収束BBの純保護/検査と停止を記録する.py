"""純Go部品の人工・vet・build・実APIを市場実行前に固定する。"""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]


def digest(path: Path) -> str:
    """所有コード又は生成metadataの全指紋を取る。

    引数: path(Path)は非価格ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reference(path: Path) -> dict:
    """非価格ファイルの絶対参照を作る。

    引数: path(Path)は現存ファイル。
    返り値: dictはpath・SHA256・容量。
    """
    return {"path": str(path), "sha256": digest(path), "bytes": path.stat().st_size}


def execute(arguments: list[str], environment: dict) -> subprocess.CompletedProcess:
    """明示したGo検査を順番に実行する。

    引数: arguments(list[str])はGo引数、environment(dict)は環境。
    返り値: CompletedProcessは終了0の結果。失敗時はRuntimeError。
    """
    result = subprocess.run(arguments, cwd=OWN, env=environment, capture_output=True, text=True, encoding="utf-8", check=False)
    if result.returncode != 0:
        raise RuntimeError(result.stdout + result.stderr)
    return result


def main() -> None:
    """全所有の前後同体と実Go宣言を保存し純部品を停止する。

    引数: なし。
    返り値: None。Actor・Source・市場入力・損益を実行しない。
    """
    target, check = OWN / "停止.json", OWN / "検査"
    assert not target.exists() and not check.exists()
    code = sorted(list(OWN.glob("*.go")) + [OWN / "go.mod", Path(__file__).resolve()])
    before = {str(path): digest(path) for path in code}
    old_stop = ROOT / "work/110利益保護の純状態/停止.json"
    old_sha = "4172d88abd3e7250228bc3f30c1457b83a95f589a925d264991d8650de70474c"
    assert digest(old_stop) == old_sha
    comments = 0
    for path in OWN.glob("*.go"):
        lines = path.read_text(encoding="utf-8").splitlines()
        for index, line in enumerate(lines):
            if line.startswith("func "):
                previous, docs = index - 1, []
                while previous >= 0 and lines[previous].startswith("//"):
                    docs.append(lines[previous])
                    previous -= 1
                text = "\n".join(docs)
                assert len(docs) >= 3 and "引数:" in text and "返り値:" in text, (path, line)
                comments += 1
    check.mkdir()
    env = dict(os.environ)
    env["PROFIT111_DECLARATION"] = str(check / "宣言設定.json")
    version = execute(["go", "version"], env).stdout.strip()
    formatted = execute(["gofmt", "-l"] + [path.name for path in OWN.glob("*.go")], env)
    assert not formatted.stdout.strip()
    test = execute(["go", "test", "-json", "-count=1", "-cover", "./..."], env)
    (check / "人工テスト.jsonl").write_text(test.stdout, encoding="utf-8", newline="\n")
    tests = [json.loads(line) for line in test.stdout.splitlines() if line.strip()]
    passed = [item["Test"] for item in tests if item.get("Action") == "pass" and "Test" in item]
    assert len(passed) == 12 and len(set(passed)) == 12
    vet = execute(["go", "vet", "./..."], env)
    build = execute(["go", "build", "./..."], env)
    api = execute(["go", "doc", "-all", "."], env)
    (check / "API.txt").write_text(api.stdout, encoding="utf-8", newline="\n")
    declaration = json.loads((check / "宣言設定.json").read_text(encoding="utf-8"))
    configs = declaration["configurations"]
    assert len(configs) == 24 and [row["policy"] for row in configs[::4]] == ["S0", "U100", "W100", "T100", "B100", "B50"]
    assert all([(row["slip_points"], row["delay_seconds"]) for row in configs[offset:offset+4]] == [(0, 0), (0, 1), (5, 0), (5, 1)] for offset in range(0, 24, 4))
    after = {str(path): digest(path) for path in code}
    assert before == after and digest(old_stop) == old_sha
    artificial = {"成功": True, "市場実行": False, "Source又はActor実行": False, "所有前": before, "所有後": after, "自己コード前後不変": True, "主人工": len(passed), "人工名": passed, "関数コメント確認数": comments, "Go版": version, "gofmt": {"終了": 0, "未整形": 0}, "test": {"終了": 0, "ログ": reference(check / "人工テスト.jsonl")}, "vet": {"終了": vet.returncode, "標準出力": vet.stdout, "標準エラー": vet.stderr}, "build": {"終了": build.returncode, "対象": "純ライブラリ。市場exeは生成しない", "標準出力": build.stdout, "標準エラー": build.stderr}, "API": reference(check / "API.txt"), "実宣言": reference(check / "宣言設定.json"), "範囲": "手製の価格・公表・数量・Rだけ。純StateとBB窓、24宣言、買売鏡像、未来追加非干渉、半円、未知・欠足・同ID、予約と全玉床"}
    proof = check / "人工確認.json"
    with proof.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(artificial, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    stop = {"成功": True, "停止": True, "範囲": "111純保護・純BB窓。Actor/Source/Raw/市場損益の実行なし。市場全条件の固定ではない", "module": "github.com/masayoshi4649/SessionTradeExecuter/profitfloor111", "package": "profitfloor111", "作成UTC": datetime.now(timezone.utc).isoformat(), "Go版": version, "所有コードSHA256": before, "自己コード前後不変": True, "人工確認": reference(proof), "主人工": len(passed), "仕様": reference(OWN / "初回24条件の設計.md"), "実API": reference(check / "API.txt"), "実宣言": reference(check / "宣言設定.json"), "派生設計元": {"path": str(old_stop), "sha256": old_sha}, "旧コード変更": False, "市場実行": False, "Source実行": False, "Actor実行": False, "11月09日読取": False, "未実施": ["111 Actor/Sourceとの接続", "全市場条件のRoot固定", "初回2場・全70場の金融と独立保存", "実注文"]}
    with target.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(stop, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "停止": reference(target), "主人工": len(passed), "所有コード": len(code), "実API": reference(check / "API.txt"), "実宣言": reference(check / "宣言設定.json")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
