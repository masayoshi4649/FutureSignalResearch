// Package profitfloor111 は連続判断の実口座へ接続する、注文を作らない必須保護の純部品です。
package profitfloor111

type Policy string

const (
	S0   Policy = "S0"
	U100 Policy = "U100"
	W100 Policy = "W100"
	T100 Policy = "T100"
	B100 Policy = "B100"
	B50  Policy = "B50"
)

type Truth uint8

const (
	Unknown Truth = iota
	False
	True
)

type Phase string

const (
	PreFill     Phase = "pre_fill"
	AfterSource Phase = "after_source"
)

type Scope struct {
	Session  string  `json:"session"`
	Contract string  `json:"contract"`
	Start    float64 `json:"start"`
}

type Evidence struct {
	Value       float64 `json:"value"`
	AvailableAt float64 `json:"available_at"`
	ID          string  `json:"id"`
}

type Pivot struct {
	Scope       Scope   `json:"scope"`
	ID          string  `json:"id"`
	Kind        string  `json:"kind"`
	Price       float64 `json:"price"`
	CenterStart float64 `json:"center_start"`
	CenterEnd   float64 `json:"center_end"`
	ConfirmEnd  float64 `json:"confirm_end"`
	PublishedAt float64 `json:"published_at"`
}

type Publication struct {
	Scope       Scope     `json:"scope"`
	ID          string    `json:"id"`
	Ordinal     uint64    `json:"ordinal"`
	Start       float64   `json:"start"`
	End         float64   `json:"end"`
	AvailableAt float64   `json:"available_at"`
	C           Truth     `json:"c"`
	M           Truth     `json:"m"`
	V           *float64  `json:"v"`
	Close       *float64  `json:"close"`
	PriorPivot  *Pivot    `json:"prior_pivot"`
	BB          *BBResult `json:"bb"`
}

type Entry struct {
	Scope           Scope     `json:"scope"`
	Policy          Policy    `json:"policy"`
	Side            int       `json:"side"`
	Price           float64   `json:"price"`
	At              float64   `json:"at"`
	InitialQuantity int       `json:"initial_quantity"`
	SlipPoints      float64   `json:"slip_points"`
	ATR             *Evidence `json:"atr"`
}

type Input struct {
	At           float64      `json:"at"`
	Sequence     uint64       `json:"sequence"`
	Phase        Phase        `json:"phase"`
	Mark         *float64     `json:"mark"`
	Remaining    int          `json:"remaining"`
	Reserved     int          `json:"reserved"`
	ClosedNetYen float64      `json:"closed_net_yen"`
	Publication  *Publication `json:"publication"`
	ResetReason  string       `json:"reset_reason"`
}

type Snapshot struct {
	Entry              Entry        `json:"entry"`
	ThresholdPoints    float64      `json:"threshold_points"`
	NormalWidth        float64      `json:"normal_width"`
	ATRUnknownFallback bool         `json:"atr_unknown_fallback"`
	CostPerUnitYen     float64      `json:"cost_per_unit_yen"`
	MinimumFloor       float64      `json:"minimum_floor"`
	Active             bool         `json:"active"`
	ActivatedAt        *float64     `json:"activated_at"`
	Narrowed           bool         `json:"narrowed"`
	NarrowedAt         *float64     `json:"narrowed_at"`
	PeakPoints         *float64     `json:"peak_points"`
	WidthPoints        float64      `json:"width_points"`
	FloorPoints        *float64     `json:"floor_points"`
	WholeTargetYen     float64      `json:"whole_target_yen"`
	ClosedNetYen       float64      `json:"closed_net_yen"`
	Remaining          int          `json:"remaining"`
	Reserved           int          `json:"reserved"`
	Latest             *Publication `json:"latest"`
	At                 float64      `json:"at"`
	Sequence           uint64       `json:"sequence"`
	Finished           bool         `json:"finished"`
}

type Decision struct {
	C                    Truth    `json:"c"`
	M                    Truth    `json:"m"`
	P                    Truth    `json:"p"`
	B                    Truth    `json:"b"`
	Warning              Truth    `json:"warning"`
	GainPoints           *float64 `json:"gain_points"`
	UnitNetYen           *float64 `json:"unit_net_yen"`
	WholeNetYen          *float64 `json:"whole_net_yen"`
	ActivatedNow         bool     `json:"activated_now"`
	NarrowedNow          bool     `json:"narrowed_now"`
	WidthSource          string   `json:"width_source"`
	WholeFloor           *float64 `json:"whole_floor"`
	PeakFloor            *float64 `json:"peak_floor"`
	StructuralFloor      *float64 `json:"structural_floor"`
	ProtectPrice         *float64 `json:"protect_price"`
	ProtectPriceValid    bool     `json:"protect_price_valid"`
	FloorHit             bool     `json:"floor_hit"`
	AllReservedHit       bool     `json:"all_reserved_hit"`
	FreeQuantity         int      `json:"free_quantity"`
	EligibleExitQuantity int      `json:"eligible_exit_quantity"`
}

type State struct {
	initialized     bool
	view            Snapshot
	wholeTargetHalf int64
	lastPublication *Publication
}

type Configuration struct {
	Policy       Policy  `json:"policy"`
	SlipPoints   float64 `json:"slip_points"`
	DelaySeconds int     `json:"delay_seconds"`
}

// DeclaredConfigurations はActor用の6政策・費用・遅延を宣言します。
//
// 引数: なし。返り値: []Configurationは24条件。S0の保護はActor側で扱います。
func DeclaredConfigurations() []Configuration {
	out := []Configuration{}
	for _, p := range []Policy{S0, U100, W100, T100, B100, B50} {
		for _, s := range []float64{0, 5} {
			for _, d := range []int{0, 1} {
				out = append(out, Configuration{p, s, d})
			}
		}
	}
	return out
}
