// Package chartprotection111 は停止済み3分公開器を、現在原行の純保護入力へ結びます。
package chartprotection111

import (
	"encoding/json"
	"fmt"
	"math"
	"sort"

	pure "github.com/masayoshi4649/SessionTradeExecuter/profitfloor111"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
	delivery "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery"
)

type Scene = chart.Scene
type Quote = chart.Quote

type Observation struct {
	At        float64          `json:"at"`
	Buy       pure.Publication `json:"buy"`
	Sell      pure.Publication `json:"sell"`
	FrameSHA  string           `json:"frame_sha256"`
	ResultSHA string           `json:"result_sha256"`
	Frame     delivery.Frame   `json:"frame"`
	Result    delivery.Result  `json:"result"`
}

type Reset struct {
	At     float64 `json:"at"`
	Reason string  `json:"reason"`
}

type Event struct {
	Kind  string `json:"kind"`
	Index int    `json:"index"`
}

type Counts struct {
	Steps          int `json:"steps"`
	Publications   int `json:"publications"`
	Three          int `json:"three"`
	Resets         int `json:"resets"`
	PriceKnown     int `json:"price_known"`
	EMA8Known      int `json:"ema8_known"`
	EMA21Known     int `json:"ema21_known"`
	HistogramKnown int `json:"histogram_known"`
	CKnown         int `json:"C_known"`
	CPass          int `json:"C_pass"`
	BuyMKnown      int `json:"buy_M_known"`
	BuyMPass       int `json:"buy_M_pass"`
	SellMKnown     int `json:"sell_M_known"`
	SellMPass      int `json:"sell_M_pass"`
	VKnown         int `json:"V_known"`
	BBKnown        int `json:"BB_known"`
	BKnown         int `json:"B_known"`
	BPass          int `json:"B_pass"`
}

type Snapshot struct {
	Scene              chart.Scene    `json:"scene"`
	Chart              chart.Snapshot `json:"chart"`
	Last               *Observation   `json:"last"`
	Counts             Counts         `json:"counts"`
	BBCold             bool           `json:"BB_cold"`
	CarriedNumericSeed bool           `json:"carried_numeric_seed"`
}

type Batch struct {
	At           float64       `json:"at"`
	Observations []Observation `json:"observations"`
	Resets       []Reset       `json:"resets"`
	Events       []Event       `json:"events"`
	EntryGrids   []float64     `json:"entry_grids"`
	Last         *Observation  `json:"last"`
	After        Snapshot      `json:"after"`
}

type Seed struct {
	old chart.Seed
}

type rangeBar struct {
	end         float64
	rangePoints float64
}

type Bank struct {
	chart   *chart.Bank
	pipe    *delivery.Pipeline
	bb      pure.BBState
	scene   chart.Scene
	ranges  []rangeBar
	last    *Observation
	counts  Counts
	sealed  bool
	failure error
}

// copyValue は消費者による公開値書換えを内部へ戻しません。
//
// 引数: value(T)は有限の公開値。返り値: Tは参照共有のないcopyです。
func copyValue[T any](value T) T {
	var out T
	raw, err := json.Marshal(value)
	if err != nil {
		panic(err)
	}
	if err = json.Unmarshal(raw, &out); err != nil {
		panic(err)
	}
	return out
}

// finite は数値をJSONへ保存できるか確認します。
//
// 引数: values(...float64)は当時数値。返り値: boolは全値が有限のとき真です。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// New は旧数値seedだけを同限月へ繋ぎ、CMP/V/BBは当場空から始めます。
//
// 引数: scene(chart.Scene)、seed(*Seed又はnil)は当場とsealed済み前場種。
// 返り値: *Bank/errorは公開器又は旧seed境界の不正です。
func New(scene chart.Scene, seed *Seed) (*Bank, error) {
	var previous *chart.Seed
	if seed != nil {
		previous = &seed.old
	}
	old, err := chart.New(scene, previous)
	if err != nil {
		return nil, err
	}
	bb, err := pure.NewBBState(pure.Scope{Session: scene.ID, Contract: scene.Contract, Start: scene.Start})
	if err != nil {
		return nil, err
	}
	return &Bank{chart: old, pipe: delivery.NewPipeline(), bb: bb, scene: scene, ranges: []rangeBar{}}, nil
}

// ready は未初期化・停止・sealed後の更新を拒否します。
//
// 引数: receiver(*Bank)は公開器。返り値: errorは利用不能な理由です。
func (b *Bank) ready() error {
	if b == nil || b.chart == nil {
		return fmt.Errorf("公開器未初期化")
	}
	if b.failure != nil {
		return b.failure
	}
	if b.sealed {
		return fmt.Errorf("seal後の更新")
	}
	return nil
}

// fail は部分状態を再利用せず失敗を永久に保持します。
//
// 引数: receiver(*Bank)、err(error)は公開器と原因。返り値: errorは同じ原因です。
func (b *Bank) fail(err error) error { b.failure = err; return err }

// reset は公開窓と消費者への失効順を同時に記録します。
//
// 引数: out(*Batch)、at(float64)、reason(string)、pipeline(bool)は出力・現在時計・理由・旧pipeリセット要否。
// 返り値: errorは純窓又は旧pipeの失効失敗です。
func (b *Bank) reset(out *Batch, at float64, reason string, pipeline bool) error {
	if pipeline {
		if err := b.pipe.Reset(at, reason); err != nil {
			return err
		}
	}
	bb, err := pure.NewBBState(pure.Scope{Session: b.scene.ID, Contract: b.scene.Contract, Start: b.scene.Start})
	if err != nil {
		return err
	}
	b.bb = bb
	b.ranges = nil
	b.last = nil
	out.Events = append(out.Events, Event{"reset", len(out.Resets)})
	out.Resets = append(out.Resets, Reset{at, reason})
	b.counts.Resets++
	return nil
}

// truth は旧公開Known/Passedを三値のまま写します。
//
// 引数: known(bool)、passed(*bool)は公開値。返り値: pure.Truth/errorは三値又は不整合です。
func truth(known bool, passed *bool) (pure.Truth, error) {
	if !known {
		if passed != nil {
			return pure.Unknown, fmt.Errorf("未知にpassedあり")
		}
		return pure.Unknown, nil
	}
	if passed == nil {
		return pure.Unknown, fmt.Errorf("既知のpassed欠落")
	}
	if *passed {
		return pure.True, nil
	}
	return pure.False, nil
}

// value は数値を独立した参照として保存します。
//
// 引数: v(float64)は有限の数値。返り値: *float64は新しい参照です。
func value(v float64) *float64 { return &v }

// rangeMedian は当場の連続した既知3分足5本だけからVを返します。
//
// 引数: f(delivery.Frame)は当時公表。返り値: *float64は5pt以上の中央値、又は未知nilです。
func (b *Bank) rangeMedian(f delivery.Frame) *float64 {
	if !f.DataKnown || f.OHLC == nil {
		b.ranges = nil
		return nil
	}
	if len(b.ranges) > 0 && b.ranges[len(b.ranges)-1].end+180 != f.End {
		b.ranges = nil
	}
	b.ranges = append(b.ranges, rangeBar{f.End, f.OHLC.High - f.OHLC.Low})
	if len(b.ranges) > 5 {
		b.ranges = append([]rangeBar{}, b.ranges[len(b.ranges)-5:]...)
	}
	if len(b.ranges) != 5 {
		return nil
	}
	xs := []float64{}
	for _, x := range b.ranges {
		xs = append(xs, x.rangePoints)
	}
	sort.Float64s(xs)
	return value(math.Max(5, xs[2]))
}

// convert は当時のFrame/Resultだけを両方向の純公表へ写します。
//
// 引数: d(delivery.Delivery)、at(float64)は旧公開結果と現在原行時計。
// 返り値: Observation/errorはV/BB/C/M/Pを結んだ結果又は不正です。
func (b *Bank) convert(d delivery.Delivery, at float64) (Observation, error) {
	f := d.Frame
	scope := pure.Scope{Session: f.Session, Contract: f.Contract, Start: f.Start}
	v := b.rangeMedian(f)
	bar := pure.ClosedBar{Scope: scope, ID: f.ID, Ordinal: uint64(f.Ordinal), Start: f.End - 180, End: f.End, AvailableAt: f.AvailableAt, Known: f.DataKnown && f.OHLC != nil}
	if bar.Known {
		bar.Close = value(f.OHLC.Close)
	}
	next, bb, err := pure.AdvanceBB(b.bb, bar, at)
	if err != nil {
		return Observation{}, err
	}
	b.bb = next
	c, err := truth(d.Result.C.Known, d.Result.C.Passed)
	if err != nil {
		return Observation{}, err
	}
	makeSide := func(role delivery.Role) (pure.Publication, error) {
		m, e := truth(role.M.Known, role.M.Passed)
		if e != nil {
			return pure.Publication{}, e
		}
		p := pure.Publication{Scope: scope, ID: f.ID, Ordinal: uint64(f.Ordinal), Start: f.End - 180, End: f.End, AvailableAt: f.AvailableAt, C: c, M: m, V: copyValue(v), BB: copyValue(&bb)}
		if f.DataKnown && f.Known.Close && f.OHLC != nil {
			p.Close = value(f.Close)
		}
		if x := role.PriorPivot; x != nil {
			p.PriorPivot = &pure.Pivot{Scope: scope, ID: x.CenterID, Kind: x.Kind, Price: x.Price, CenterStart: x.CenterEnd - 180, CenterEnd: x.CenterEnd, ConfirmEnd: x.ConfirmEnd, PublishedAt: x.PublishedAt}
		}
		return p, nil
	}
	buy, err := makeSide(d.Result.Buy)
	if err != nil {
		return Observation{}, err
	}
	sell, err := makeSide(d.Result.Sell)
	if err != nil {
		return Observation{}, err
	}
	fh, err := delivery.CanonicalSHA(f)
	if err != nil {
		return Observation{}, err
	}
	rh, err := delivery.CanonicalSHA(d.Result.Values())
	if err != nil {
		return Observation{}, err
	}
	return Observation{At: at, Buy: buy, Sell: sell, FrameSHA: fh, ResultSHA: rh, Frame: copyValue(f), Result: copyValue(d.Result)}, nil
}

// countObservation は既知/未知を分け、取引の参加率へ読み替えません。
//
// 引数: o(Observation)は新3分公表。返り値: ありません。累積計数だけを更新します。
func (b *Bank) countObservation(o Observation) {
	c := &b.counts
	c.Three++
	if o.Frame.DataKnown {
		c.PriceKnown++
	}
	if o.Frame.Known.EMA8 {
		c.EMA8Known++
	}
	if o.Frame.Known.EMA21 {
		c.EMA21Known++
	}
	if o.Frame.Known.Hist {
		c.HistogramKnown++
	}
	if o.Buy.C != pure.Unknown {
		c.CKnown++
	}
	if o.Buy.C == pure.True {
		c.CPass++
	}
	if o.Buy.M != pure.Unknown {
		c.BuyMKnown++
	}
	if o.Buy.M == pure.True {
		c.BuyMPass++
	}
	if o.Sell.M != pure.Unknown {
		c.SellMKnown++
	}
	if o.Sell.M == pure.True {
		c.SellMPass++
	}
	if o.Buy.V != nil {
		c.VKnown++
	}
	if o.Buy.BB.Known {
		c.BBKnown++
	}
	if o.Buy.BB.Contraction != pure.Unknown {
		c.BKnown++
	}
	if o.Buy.BB.Contraction == pure.True {
		c.BPass++
	}
}

// snapshot は旧公開値と追加監査を独立値へまとめます。
//
// 引数: view(chart.Snapshot)は現在旧値。返り値: Snapshotは観測後の当場値です。
func (b *Bank) snapshot(view chart.Snapshot) Snapshot {
	return Snapshot{Scene: b.scene, Chart: copyValue(view), Last: copyValue(b.last), Counts: b.counts, BBCold: true, CarriedNumericSeed: view.Legacy.CarriedNumericSeed}
}

// Step は当原行で初めて見えた公表を、同原行の金融評価前へ配送します。
//
// 引数: q(chart.Quote)は元Sourceが受理したNK原行。返り値: Batch/errorは順序付き公表/reset又は失敗です。
func (b *Bank) Step(q chart.Quote) (Batch, error) {
	if err := b.ready(); err != nil {
		return Batch{}, err
	}
	if !finite(q.Time, q.Last, q.Bid, q.Ask) {
		return Batch{}, b.fail(fmt.Errorf("非有限原行"))
	}
	q.Valid = q.Last > 0
	raw, err := b.chart.Step(q, nil)
	if err != nil {
		return Batch{}, b.fail(err)
	}
	if len(raw.Grids) != 0 {
		return Batch{}, b.fail(fmt.Errorf("新規判断gridの混入"))
	}
	out := Batch{At: q.Time, Observations: []Observation{}, Resets: []Reset{}, Events: []Event{}, EntryGrids: nil}
	b.counts.Steps++
	for _, p := range raw.Publications {
		b.counts.Publications++
		if !p.Three {
			continue
		}
		d, e := b.pipe.Feed(p, q.Time)
		if e != nil {
			return Batch{}, b.fail(e)
		}
		if !d.Result.New {
			continue
		}
		if d.Result.ResetReason != "" {
			if e = b.reset(&out, q.Time, d.Result.ResetReason, false); e != nil {
				return Batch{}, b.fail(e)
			}
		}
		o, e := b.convert(d, q.Time)
		if e != nil {
			return Batch{}, b.fail(e)
		}
		b.last = copyValue(&o)
		b.countObservation(o)
		out.Events = append(out.Events, Event{"observation", len(out.Observations)})
		out.Observations = append(out.Observations, copyValue(o))
	}
	if !q.Valid {
		if err = b.reset(&out, q.Time, "不良Lastの当原行失効", true); err != nil {
			return Batch{}, b.fail(err)
		}
	}
	out.Last = copyValue(b.last)
	out.After = b.snapshot(raw.After)
	return out, nil
}

// Snapshot は価格時計を進めず、現在値だけを返します。
//
// 引数: receiver(*Bank)は公開器。返り値: Snapshot/errorは現値又は失敗です。
func (b *Bank) Snapshot() (Snapshot, error) {
	if b == nil || b.chart == nil {
		return Snapshot{}, fmt.Errorf("公開器未初期化")
	}
	if b.failure != nil {
		return Snapshot{}, b.failure
	}
	s, err := b.chart.Snapshot()
	if err != nil {
		return Snapshot{}, err
	}
	return b.snapshot(s), nil
}

// Seal は旧器を先締めせず、旧数値seedだけを次場へ返します。
//
// 引数: receiver(*Bank)は当場公開器。返り値: Seed/Snapshot/errorは数値種・終値又は失敗です。
func (b *Bank) Seal() (Seed, Snapshot, error) {
	if err := b.ready(); err != nil {
		return Seed{}, Snapshot{}, err
	}
	seed, s, err := b.chart.Seal()
	if err != nil {
		return Seed{}, Snapshot{}, b.fail(err)
	}
	b.sealed = true
	return Seed{old: seed}, b.snapshot(s), nil
}
