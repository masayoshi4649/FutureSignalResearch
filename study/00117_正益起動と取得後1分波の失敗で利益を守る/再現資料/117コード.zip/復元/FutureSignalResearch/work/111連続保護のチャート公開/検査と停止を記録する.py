"""確定チャート配送の人工・依存停止・実Go閉包を市場実行前に保存する。"""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
STOPS = {
    ROOT / "work/可変追尾向けの公開チャート/停止.json": "f534631e19d8c04fa6f7beefe295178cd432ae1f099d1b9ef69781b5e4fccad6",
    ROOT / "work/収束可変幅の公開配送案/停止.json": "8c426b5791df0c3d327d0224ecfe48baac7c319a6d1fb776672cecdf79733015",
    ROOT / "work/111全玉利益と収束BBの純保護/停止.json": "0042a6dc3f181150609deeca5b2c095c9f553d69fcaab1d833402ae31fdbc2c4",
}


def digest(path: Path) -> str:
    """所有コード・停止・コンパイル依存の全バイト指紋を取る。

    引数: path(Path)は非市場入力。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reference(path: Path) -> dict:
    """明示した非市場ファイルを絶対参照にまとめる。

    引数: path(Path)は現存ファイル。
    返り値: dictはpath・SHA256・容量。
    """
    return {"path": str(path), "sha256": digest(path), "bytes": path.stat().st_size}


def execute(arguments: list[str], environment: dict) -> subprocess.CompletedProcess:
    """明示したGo検査だけを実行する。

    引数: arguments(list[str])は引数列、environment(dict)は環境。
    返り値: CompletedProcessは終了0。不成功ならRuntimeError。
    """
    result = subprocess.run(arguments, cwd=OWN, env=environment, capture_output=True, text=True, encoding="utf-8", check=False)
    if result.returncode != 0:
        raise RuntimeError(result.stdout + result.stderr)
    return result


def dependency_hashes(raw: str) -> tuple[dict, list]:
    """実Go listの非標準packageから実コンパイル依存を列挙する。

    引数: raw(str)はgo list -deps -jsonの実出力。
    返り値: tuple[dict,list]は全指紋とpackage対応。市場ファイルを探索しない。
    """
    decoder, offset, hashes, packages = json.JSONDecoder(), 0, {}, []
    while offset < len(raw):
        if raw[offset].isspace():
            offset += 1
            continue
        value, offset = decoder.raw_decode(raw, offset)
        module = value.get("Module")
        if module is None:
            continue
        directory = Path(value["Dir"])
        paths = []
        for key in ("GoFiles", "CgoFiles", "EmbedFiles", "CFiles", "CXXFiles", "MFiles", "HFiles", "FFiles", "SFiles", "SwigFiles", "SwigCXXFiles"):
            paths.extend(directory / name for name in value.get(key, []))
        original_module = module.get("Replace", module)
        if original_module.get("GoMod"):
            gomod = Path(original_module["GoMod"])
            paths.append(gomod)
            if gomod.with_name("go.sum").exists():
                paths.append(gomod.with_name("go.sum"))
        files = sorted(set(path.resolve() for path in paths))
        for path in files:
            actual = digest(path)
            assert str(path) not in hashes or hashes[str(path)] == actual
            hashes[str(path)] = actual
        packages.append({"import_path": value["ImportPath"], "directory": str(directory), "module": module["Path"], "version": module.get("Version", ""), "files": [str(path) for path in files]})
    return hashes, packages


def main() -> None:
    """全所有・旧停止・実依存の前後同体と人工10主を記録する。

    引数: なし。
    返り値: None。Source/Actor/Rawの市場実行を行わない。
    """
    destination, check = OWN / "停止.json", OWN / "検査"
    assert not destination.exists() and not check.exists()
    code = sorted(list(OWN.glob("*.go")) + [OWN / "go.mod", OWN / "go.sum", Path(__file__).resolve()])
    before = {str(path): digest(path) for path in code}
    old = {}
    for path, expected in STOPS.items():
        assert digest(path) == expected
        old[str(path)] = expected
        source = json.loads(path.read_text(encoding="utf-8"))
        assert source["成功"]
        for field in ("所有コードSHA256", "参照コードSHA256"):
            for name, wanted in source.get(field, {}).items():
                actual_path = Path(name)
                if not actual_path.is_absolute():
                    actual_path = ROOT / actual_path
                actual_path = actual_path.resolve()
                assert digest(actual_path) == wanted
                assert str(actual_path) not in old or old[str(actual_path)] == wanted
                old[str(actual_path)] = wanted
    comments = 0
    for path in OWN.glob("*.go"):
        lines = path.read_text(encoding="utf-8").splitlines()
        for index, line in enumerate(lines):
            if line.startswith("func "):
                previous, docs = index - 1, []
                while previous >= 0 and lines[previous].startswith("//"):
                    docs.append(lines[previous])
                    previous -= 1
                text = "\n".join(docs)
                assert len(docs) >= 3 and "引数:" in text and "返り値:" in text
                comments += 1
    check.mkdir()
    env = dict(os.environ)
    env["CHARTPROTECTION111_DECLARATION"] = str(check / "API宣言.json")
    version = execute(["go", "version"], env).stdout.strip()
    assert not execute(["gofmt", "-l"] + [path.name for path in OWN.glob("*.go")], env).stdout.strip()
    actual_list = execute(["go", "list", "-deps", "-json", "./..."], env).stdout
    dependencies, packages = dependency_hashes(actual_list)
    test = execute(["go", "test", "-json", "-count=1", "-cover", "./..."], env)
    (check / "人工テスト.jsonl").write_text(test.stdout, encoding="utf-8", newline="\n")
    records = [json.loads(line) for line in test.stdout.splitlines() if line.strip()]
    passed = [row["Test"] for row in records if row.get("Action") == "pass" and "Test" in row]
    assert len(passed) == len(set(passed)) == 10
    vet = execute(["go", "vet", "./..."], env)
    build = execute(["go", "build", "./..."], env)
    api = execute(["go", "doc", "-all", "."], env)
    (check / "API.txt").write_text(api.stdout, encoding="utf-8", newline="\n")
    declaration = json.loads((check / "API宣言.json").read_text(encoding="utf-8"))
    assert declaration["entry_grids"] is None and declaration["event_kinds"] == ["reset", "observation"]
    assert declaration["人工counts"]["three"] == 5 and declaration["人工counts"]["V_known"] == 1
    after = {str(path): digest(path) for path in code}
    assert before == after
    assert all(digest(Path(path)) == wanted for path, wanted in old.items())
    assert all(digest(Path(path)) == wanted for path, wanted in dependencies.items())
    manifest = check / "Go依存.json"
    with manifest.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump({"成功": True, "標準ライブラリ": "外部Go環境参照・Go版を停止へ記録", "実go_list": True, "依存コードSHA256": dependencies, "packages": packages, "前後不変": True}, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    proof = check / "人工確認.json"
    with proof.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump({"成功": True, "主人工": len(passed), "人工名": passed, "関数コメント確認数": comments, "所有前": before, "所有後": after, "旧停止と所有参照SHA256": old, "自己と依存前後不変": True, "test": {"終了": 0, "log": reference(check / "人工テスト.jsonl")}, "vet": {"終了": vet.returncode, "出力": vet.stdout + vet.stderr}, "build": {"終了": build.returncode, "出力": build.stdout + build.stderr}, "実Go依存": reference(manifest), "市場実行": False, "Source又はActor金融実行": False, "Raw読取": False}, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    stop = {"成功": True, "停止": True, "module": "github.com/masayoshi4649/SessionTradeExecuter/chartprotection111", "作成UTC": datetime.now(timezone.utc).isoformat(), "Go版": version, "範囲": "停止publicchart/publicdeliveryの確定3分→純111公表。元Raw/Source/Actor金融は未実行。初回市場はcold予定", "所有コードSHA256": before, "自己コード前後不変": True, "依存停止": [{"path": str(path), "sha256": wanted} for path, wanted in STOPS.items()], "実Go依存": reference(manifest), "人工確認": reference(proof), "主人工": len(passed), "実API": reference(check / "API.txt"), "実API宣言": reference(check / "API宣言.json"), "README": reference(OWN / "README.md"), "entryGrids": None, "初回市場でEMAcarry使用": False, "BBとVの開始": "当場cold", "市場実行": False, "Source又はActor実行": False, "11月09日読取": False, "未実施": ["111 SourceConsumer/Actorとの接続人工", "Rootの全市場条件固定", "実市場損益と独立保存", "実注文"]}
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(stop, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "停止": reference(destination), "主人工": len(passed), "所有コード": len(code), "実依存ファイル": len(dependencies), "旧停止所有参照": len(old), "実API": reference(check / "API.txt"), "実宣言": reference(check / "API宣言.json")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
