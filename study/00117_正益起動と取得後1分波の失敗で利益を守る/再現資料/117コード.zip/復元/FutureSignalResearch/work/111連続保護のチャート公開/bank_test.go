package chartprotection111

import (
	"encoding/json"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	pure "github.com/masayoshi4649/SessionTradeExecuter/profitfloor111"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
	delivery "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery"
)

// mustNew は市場入力なしの人工公開器を作ります。
//
// 引数: t(*testing.T)、scene(Scene)、seed(*Seed)は人工。返り値: *Bankは正常状態です。
func mustNew(t *testing.T, scene Scene, seed *Seed) *Bank {
	t.Helper()
	b, e := New(scene, seed)
	if e != nil {
		t.Fatal(e)
	}
	return b
}

// quoteFixture は有限Lastと正常又は無効BBOを持つ人工原行を作ります。
//
// 引数: at/last(float64)、i(int64)、bad(bool)は人工値。返り値: Quoteは原行識別付き値です。
func quoteFixture(at, last float64, i int64, bad bool) Quote {
	q := Quote{Time: at, Index: i, Line: i + 1, Last: last, Bid: last - 5, Ask: last + 5, Valid: !bad}
	if bad {
		q.Bid, q.Ask = 0, 0
	}
	return q
}

// stepOK は当原行の純公開成功を確認します。
//
// 引数: t(*testing.T)、b(*Bank)、q(Quote)は人工。返り値: Batchは独立公開値です。
func stepOK(t *testing.T, b *Bank, q Quote) Batch {
	t.Helper()
	out, e := b.Step(q)
	if e != nil {
		t.Fatal(e)
	}
	if out.EntryGrids != nil {
		t.Fatal("新規判断gridがnilでない")
	}
	for _, o := range out.Observations {
		if o.At != q.Time || o.Buy.AvailableAt > o.At || o.Sell.AvailableAt > o.At || o.Buy.BB.DeliveredAt != q.Time {
			t.Fatal("過去名目時計又は未来で金融評価")
		}
		fh, _ := delivery.CanonicalSHA(o.Frame)
		rh, _ := delivery.CanonicalSHA(o.Result.Values())
		if fh != o.FrameSHA || rh != o.ResultSHA {
			t.Fatal("実Frame/Result出典差")
		}
		for _, side := range []int{1, -1} {
			pub := o.Buy
			if side < 0 {
				pub = o.Sell
			}
			s, e := pure.NewState(pure.Entry{Scope: pub.Scope, Policy: pure.B100, Side: side, Price: 1000, At: o.At, InitialQuantity: 1})
			if e != nil {
				t.Fatal(e)
			}
			if _, _, e = pure.Advance(s, pure.Input{At: o.At, Sequence: 1, Phase: pure.PreFill, Remaining: 1, Publication: &pub}); e != nil {
				t.Fatal("実純APIへ配送不可", e)
			}
		}
	}
	return out
}

// feedCloses は確定足の形成を旧器へ任せて手製終値を流します。
//
// 引数: t(*testing.T)、b(*Bank)、closes([]float64)は人工系列。返り値: []Observationは実旧公表に由来します。
func feedCloses(t *testing.T, b *Bank, closes []float64) []Observation {
	t.Helper()
	out := []Observation{}
	index := int64(0)
	for i, c := range closes {
		at := b.scene.Start + float64(i)*180 + 1
		x := stepOK(t, b, quoteFixture(at, c, index, false))
		index++
		out = append(out, x.Observations...)
		x = stepOK(t, b, quoteFixture(at+178, c, index, false))
		index++
		out = append(out, x.Observations...)
	}
	if len(closes) > 0 {
		x := stepOK(t, b, quoteFixture(b.scene.Start+float64(len(closes))*180, closes[len(closes)-1], index, false))
		out = append(out, x.Observations...)
	}
	return out
}

// TestBoundarySameSecondAndBadBBO は3分境界と同秒後行の因果を確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestBoundarySameSecondAndBadBBO(t *testing.T) {
	b := mustNew(t, Scene{ID: "人工Day", Contract: "限月", Start: 1000}, nil)
	stepOK(t, b, quoteFixture(1001, 1000, 0, true))
	stepOK(t, b, quoteFixture(1179, 1010, 1, true))
	out := stepOK(t, b, quoteFixture(1180, 9990, 2, true))
	if len(out.Observations) != 1 {
		t.Fatal("境界公表不足")
	}
	o := out.Observations[0]
	if !o.Frame.DataKnown || o.Frame.OHLC.Close != 1010 || o.Frame.OHLC.High != 1010 || o.Frame.LastSource.Time != 1179 || o.At != 1180 || o.Buy.End != 1180 {
		t.Fatal("同秒当raw混入又は無BBOでLast失効")
	}
	again := stepOK(t, b, quoteFixture(1180, 8880, 3, false))
	if len(again.Observations) != 0 {
		t.Fatal("同秒後行で重複公表")
	}
	if len(out.Events) < 2 || out.Events[0].Kind != "reset" || out.Events[1].Kind != "observation" {
		t.Fatal("場頭失効と公表順の不足")
	}
}

// TestSparseObservationUsesCurrentClock は遅れて見えた公表の金融時計を現在原行へ揃えます。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestSparseObservationUsesCurrentClock(t *testing.T) {
	b := mustNew(t, Scene{ID: "人工Day", Contract: "限月", Start: 1000}, nil)
	stepOK(t, b, quoteFixture(1001, 1000, 0, false))
	out := stepOK(t, b, quoteFixture(2000, 1020, 1, false))
	if len(out.Observations) != 5 {
		t.Fatalf("旧器の実空足公表差:%d", len(out.Observations))
	}
	for _, o := range out.Observations {
		if o.At != 2000 || o.Buy.End > 2000 {
			t.Fatal("過去注文判断を作成")
		}
	}
	if !out.Observations[0].Frame.DataKnown {
		t.Fatal("最初の観測足を未知化")
	}
	for _, o := range out.Observations[1:] {
		if o.Frame.DataKnown || o.Buy.Close != nil || o.Buy.V != nil || o.Buy.BB.Known {
			t.Fatal("空足の価格又はV/BB補完")
		}
	}
	if out.After.Counts.Resets < 4 {
		t.Fatal("空足reset不足")
	}
}

// TestVAndBBAreActualClosedBars は5本値幅中央値とBB20/3幅を同じ確定足へ結びます。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestVAndBBAreActualClosedBars(t *testing.T) {
	b := mustNew(t, Scene{ID: "人工Day", Contract: "限月", Start: 1000}, nil)
	ranges := []float64{10, 50, 20, 40, 30}
	observations := []Observation{}
	i := int64(0)
	for k, r := range ranges {
		out := stepOK(t, b, quoteFixture(1000+float64(k*180+1), 1000, i, false))
		i++
		observations = append(observations, out.Observations...)
		out = stepOK(t, b, quoteFixture(1000+float64(k*180+179), 1000+r, i, false))
		i++
		observations = append(observations, out.Observations...)
	}
	out := stepOK(t, b, quoteFixture(1900, 1030, i, false))
	observations = append(observations, out.Observations...)
	for j, o := range observations {
		if j < 4 && o.Buy.V != nil {
			t.Fatal("Vが5本前に既知")
		}
	}
	v := observations[len(observations)-1].Buy.V
	if v == nil || *v != 30 {
		t.Fatal("当場5本H-Lの中央値差")
	}
	b = mustNew(t, Scene{ID: "人工Day", Contract: "限月", Start: 1000}, nil)
	closes := []float64{}
	for j := 0; j < 20; j++ {
		closes = append(closes, 1000+5*float64(j))
	}
	closes = append(closes, 1050, 1050)
	observations = feedCloses(t, b, closes)
	if observations[18].Buy.BB.Known || !observations[19].Buy.BB.Known || observations[20].Buy.BB.Contraction != pure.Unknown || observations[21].Buy.BB.Contraction != pure.True {
		t.Fatal("BB20/3幅を別足又は未来へ結合")
	}
	if math.Abs(*observations[19].Buy.BB.Sigma**observations[19].Buy.BB.Sigma-831.25) > 1e-8 {
		t.Fatal("BB母σ差")
	}
}

// TestSmoothTrendDoesNotWarnFromHighLevel は滑らかなMAとMACD増分0を分けます。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestSmoothTrendDoesNotWarnFromHighLevel(t *testing.T) {
	b := mustNew(t, Scene{ID: "人工Day", Contract: "限月", Start: 1000}, nil)
	prices := []float64{}
	for i := 0; i < 90; i++ {
		prices = append(prices, 1000+10*float64(i))
	}
	obs := feedCloses(t, b, prices)
	last := obs[len(obs)-1]
	if !last.Frame.Known.EMA8 || !last.Frame.Known.EMA21 || last.Frame.EMA8 <= last.Frame.EMA21 || !last.Frame.Known.Hist {
		t.Fatal("滑らかな順行の暖機不足")
	}
	if last.Buy.C != pure.False || last.Buy.M != pure.False || last.Sell.M != pure.False {
		t.Fatalf("MA同方向/高値を失速票に誤変換:C%d M%d/%d H%g", last.Buy.C, last.Buy.M, last.Sell.M, last.Frame.Hist)
	}
}

// TestGapLastResetAndSealNoExtraBar は空足失効とsealの先締め禁止を確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestGapLastResetAndSealNoExtraBar(t *testing.T) {
	b := mustNew(t, Scene{ID: "人工Day", Contract: "限月", Start: 1000}, nil)
	closes := []float64{}
	for j := 0; j < 22; j++ {
		closes = append(closes, 1000+5*float64(j))
	}
	feedCloses(t, b, closes)
	out := stepOK(t, b, quoteFixture(5700, 1100, 45, false))
	if out.Last.Buy.BB.Known || out.Last.Buy.V != nil || len(out.Resets) == 0 {
		t.Fatal("欠足でBB/V窓が失効しない")
	}
	out = stepOK(t, b, quoteFixture(5701, 0, 46, true))
	if len(out.Events) == 0 || out.Events[len(out.Events)-1].Kind != "reset" || out.Last != nil {
		t.Fatal("不良Lastの当raw失効順差")
	}
	empty := mustNew(t, Scene{ID: "空場", Contract: "限月", Start: 10000}, nil)
	stepOK(t, empty, quoteFixture(10179, 1000, 0, false))
	before, _ := empty.Snapshot()
	_, after, err := empty.Seal()
	if err != nil || after.Counts != before.Counts || after.Chart.Three.BarEnd != 0 || after.Last != nil {
		t.Fatal("Sealで架空の終了足")
	}
	if _, err = empty.Step(quoteFixture(10180, 1000, 1, false)); err == nil {
		t.Fatal("seal後更新")
	}
	if _, _, err = empty.Seal(); err == nil {
		t.Fatal("二重seal")
	}
}

// TestSameContractNumericCarryAndBBCool は旧EMA種だけをcarryしBB/Vは当場coldにします。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestSameContractNumericCarryAndBBCool(t *testing.T) {
	b := mustNew(t, Scene{ID: "前場", Contract: "限月", Start: 1000}, nil)
	prices := []float64{}
	for i := 0; i < 90; i++ {
		prices = append(prices, 1000+5*float64(i))
	}
	feedCloses(t, b, prices)
	seed, _, err := b.Seal()
	if err != nil {
		t.Fatal(err)
	}
	for _, contract := range []string{"限月", "別限月"} {
		next := mustNew(t, Scene{ID: "次場" + contract, Contract: contract, Start: 20000}, &seed)
		s, _ := next.Snapshot()
		if s.CarriedNumericSeed != (contract == "限月") || s.Last != nil || !s.BBCold {
			t.Fatal("carry/cold表示差")
		}
		obs := feedCloses(t, next, []float64{1500})
		if len(obs) != 1 || obs[0].Buy.BB.Known || obs[0].Buy.BB.WindowBars != 1 || obs[0].Buy.V != nil || obs[0].Frame.Known.EMA21 != (contract == "限月") {
			t.Fatal("BB又はVまで前場carry")
		}
	}
	if _, err = New(Scene{ID: "不正種", Contract: "限月", Start: 20000}, &Seed{}); err == nil {
		t.Fatal("未sealed種を受理")
	}
}

// TestPivotBeforeConfirmationNotRetroactive は新pivotを当足Pへ遡及しません。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestPivotBeforeConfirmationNotRetroactive(t *testing.T) {
	b := mustNew(t, Scene{ID: "人工Day", Contract: "限月", Start: 1000}, nil)
	obs := feedCloses(t, b, []float64{1030, 1020, 1000, 1020, 1030, 1010})
	if obs[3].Buy.PriorPivot != nil || obs[4].Buy.PriorPivot != nil {
		t.Fatal("確認前又は新pivotの当足遡及")
	}
	p := obs[5].Buy.PriorPivot
	if p == nil || p.Price != 1000 || p.CenterStart != 1360 || p.CenterEnd != 1540 || p.ConfirmEnd != 1900 || p.PublishedAt != 1900 {
		t.Fatal("中心/確認/公開の結合差")
	}
	if len(obs[4].Result.NewPivots) == 0 {
		t.Fatal("実確認pivotなし")
	}
}

// TestMirrorFutureAndConsumerCopies は公開状態の鏡像・過去不変・消費者copyを確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestMirrorFutureAndConsumerCopies(t *testing.T) {
	prices := []float64{}
	reverse := []float64{}
	for i := 0; i < 60; i++ {
		p := 1500 + 5*float64(i) + 20*math.Sin(float64(i)/3)
		prices = append(prices, p)
		reverse = append(reverse, 4000-p)
	}
	a := mustNew(t, Scene{ID: "人工Day", Contract: "限月", Start: 1000}, nil)
	b := mustNew(t, Scene{ID: "人工Day", Contract: "限月", Start: 1000}, nil)
	x, y := feedCloses(t, a, prices), feedCloses(t, b, reverse)
	for i := range x {
		if x[i].Buy.C != y[i].Sell.C || x[i].Buy.M != y[i].Sell.M || x[i].Buy.BB.Contraction != y[i].Sell.BB.Contraction || x[i].Buy.V != nil && math.Abs(*x[i].Buy.V-*y[i].Sell.V) > 1e-8 {
			t.Fatal("買売鏡像の役割差")
		}
	}
	before, _ := a.Snapshot()
	stable := copyValue(before)
	if before.Last.Buy.V != nil {
		*before.Last.Buy.V = 999
	}
	if before.Last.Buy.BB.Width != nil {
		*before.Last.Buy.BB.Width = 999
	}
	after, _ := a.Snapshot()
	if !reflect.DeepEqual(after, stable) {
		t.Fatal("Snapshotの消費者書換えが内部へ反映")
	}
	out := stepOK(t, a, quoteFixture(11980, 1800, 121, false))
	if len(out.Observations) != 1 {
		t.Fatal("消費者copyを検査する新公表不足")
	}
	for i := range out.Observations {
		out.Observations[i].Frame.EMA8 = 999
		if out.Observations[i].Buy.V != nil {
			*out.Observations[i].Buy.V = 999
			if out.Observations[i].Sell.V != nil && *out.Observations[i].Sell.V == 999 {
				t.Fatal("売買公表の参照共有")
			}
		}
	}
	internal, _ := a.Snapshot()
	if internal.Last.Frame.EMA8 == 999 || internal.Last.Buy.V != nil && *internal.Last.Buy.V == 999 {
		t.Fatal("Observationの消費者書換えが内部へ反映")
	}
	if !reflect.DeepEqual(x[len(x)-1].Buy, stable.Last.Buy) {
		t.Fatal("未来追加が過去公表を変更")
	}
	if out.Last != nil && out.Last.Buy.V != nil {
		*out.Last.Buy.V = 123
	}
	again, _ := a.Snapshot()
	if again.Last != nil && again.Last.Buy.V != nil && *again.Last.Buy.V == 123 {
		t.Fatal("Batch.Lastの参照共有")
	}
}

// TestRuntimeAPIDeclaration は実型と実公表から接続契約を出力します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。環境指定時だけ非市場JSONを保存します。
func TestRuntimeAPIDeclaration(t *testing.T) {
	b := mustNew(t, Scene{ID: "API人工", Contract: "限月", Start: 1000}, nil)
	obs := feedCloses(t, b, []float64{1000, 1010, 1020, 1030, 1040})
	s, err := b.Snapshot()
	if err != nil {
		t.Fatal(err)
	}
	if len(obs) != 5 || s.Counts.Steps != 11 || s.Counts.VKnown != 1 {
		t.Fatal("実APIの人工計数差")
	}
	fields := []string{}
	typ := reflect.TypeOf(Batch{})
	for i := 0; i < typ.NumField(); i++ {
		fields = append(fields, typ.Field(i).Name)
	}
	if path := os.Getenv("CHARTPROTECTION111_DECLARATION"); path != "" {
		raw, err := json.MarshalIndent(map[string]any{"module": "chartprotection111", "batch_fields": fields, "event_kinds": []string{"reset", "observation"}, "observation_at": "原行q.Time。End/AvailableAtは純Publicationに維持", "entry_grids": nil, "BB": "当場cold、純profitfloor111 BB20母σ、3幅strict縮小", "V": "当場連続既知3分5本H-L中央値、最低5pt", "carry": "同限月の旧数値seedのみ、初回市場はNew(scene,nil)を予定", "人工の最後": s.Last, "人工counts": s.Counts}, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		if err = os.MkdirAll(filepath.Dir(path), 0700); err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(path, append(raw, '\n'), 0600); err != nil {
			t.Fatal(err)
		}
	}
}

// TestInvalidRawFailsClosed は逆行原行を拒否した後に再利用しません。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestInvalidRawFailsClosed(t *testing.T) {
	b := mustNew(t, chart.Scene{ID: "人工Day", Contract: "限月", Start: 1000}, nil)
	stepOK(t, b, quoteFixture(1001, 1000, 0, false))
	if _, e := b.Step(quoteFixture(1002, 1000, 0, false)); e == nil {
		t.Fatal("同indexを受理")
	}
	if _, e := b.Step(quoteFixture(1003, 1000, 1, false)); e == nil {
		t.Fatal("失敗後の再利用")
	}
}
