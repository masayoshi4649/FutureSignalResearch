package main

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
)

// run はstdinの展開bytesをGo1.24.2の標準gzipへ一括Writeします。
//
// 引数: out(string)は未作成先です。入力はJSONとして解析しません。
// 返り値: errorは読取/書込/終了の失敗です。元Nativeは開きません。
func run(out string) error {
	if out == "" {
		return fmt.Errorf("未作成出力先が必要")
	}
	raw, err := io.ReadAll(os.Stdin)
	if err != nil {
		return err
	}
	f, err := os.OpenFile(out, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		return err
	}
	z := gzip.NewWriter(f)
	n, err := z.Write(raw)
	if closeErr := z.Close(); err == nil {
		err = closeErr
	}
	if closeErr := f.Close(); err == nil {
		err = closeErr
	}
	if err != nil {
		return err
	}
	if n != len(raw) {
		return fmt.Errorf("一括Writeのbytes不足")
	}
	compressed, err := os.ReadFile(out)
	if err != nil {
		return err
	}
	sum := sha256.Sum256(compressed)
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"成功": true, "展開bytes": len(raw), "gzip_bytes": len(compressed), "gzip_SHA256": hex.EncodeToString(sum[:]), "一括Write回数": 1})
}

// main はbytesだけの再圧縮を行い、内容の金融解析をしません。
//
// 引数: CLI --out(string)は未作成gzipです。
// 返り値: なし。失敗は終了1、成功は小metadataだけを返します。
func main() {
	out := flag.String("out", "", "元gzip復元の未作成先")
	flag.Parse()
	if err := run(*out); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
