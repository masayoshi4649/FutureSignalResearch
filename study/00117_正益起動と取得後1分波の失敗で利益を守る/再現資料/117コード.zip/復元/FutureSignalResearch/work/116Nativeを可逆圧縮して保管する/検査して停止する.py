"""Rootレビュー後に純bytes保管コードと保存Go実exeを新規固定する。"""
from pathlib import Path
import argparse
import json
import subprocess
import sys
import 保管する as M

ONE_SHA='6e550abead9975cf51ad913e0d0c5dc3d2dcd19684d76c5529f4c8c73c0eb117'
GO_INFO_SHA='42c67270bb7ad42dbf1ceabce64e1737f3a6689d5dd7695313fc4140f0306ac8'


def inspect(reviewed: bool,stop: bool) -> dict:
    """
    機能: 手製6主・旧一場metadata・保存exeを確認し、任意でレビュー後停止する。
    引数: reviewed/stop(bool)はRootレビューと正式停止の区分。
    返り値: dictは新規確認又は停止Ref。自然Native本文は読まない。
    """
    target=M.HERE/('停止.json' if stop else '停止前の確認.json')
    M.need(not target.exists() and (not stop or reviewed),'未作成先とRootレビュー後だけ停止')
    before={str((M.HERE/name).resolve()):M.digest((M.HERE/name).read_bytes()) for name in M.OWNED}
    prior=M.ROOT/'work/116Native一場の可逆圧縮確認'
    one={'path':str(prior/'最大一場の試験_同場再実行/一場の圧縮確認.json'),'sha256':ONE_SHA}
    info={'path':str(prior/'実験の実行物と指紋.json'),'sha256':GO_INFO_SHA}
    refs={};old=M.read_json(one,refs);go=M.read_json(info,refs)
    M.need(old['成功'] is True and old['Go1.24.2gzip復元']['元gzip全bytes完全一致'] is True and old['入力']['sha256']=='fd89bbd4ac1a92bf67fb18d9075c1ec9933bf084e688148b61dd8fc2a93df838','既一場の実測metadata')
    M.need('go1.24.2' in go['Go版metadata'] and go['Go実行物']['sha256']==M.RESTORER_SHA,'保存実exeのGo版')
    result=subprocess.run([sys.executable,'-X','utf8','人工検査.py'],cwd=M.HERE,capture_output=True,text=True,encoding='utf-8',timeout=90)
    M.need(result.returncode==0,result.stdout+result.stderr)
    M.need(before=={path:M.digest(Path(path).read_bytes()) for path in before},'所有code/exe前後差')
    value={'試行':116,'成功':True,'停止':stop,'市場前':True,'Rootレビュー後':reviewed,'所有ファイルSHA256':before,
           '実Go復元物':M.file_ref(M.HERE/'gzipを再現する.exe'),'Gosource':M.file_ref(M.HERE/'gzipを再現する.go'),'既一場試験':one,'Go版指紋証拠':info,
           'compression':M.OPTIONS,'人工6主':True,'人工ログ':result.stdout+result.stderr,'前後不変':True,
           '自然Native70追加読取':0,'Raw/CSV/11月09読取':0,'金融計算/JSON意味解析':False,'既存Native削除/上書き':False}
    M.save_new(target,(json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'));return M.file_ref(target)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--reviewed',action='store_true');parser.add_argument('--stop',action='store_true');args=parser.parse_args()
    print(json.dumps(inspect(args.reviewed,args.stop),ensure_ascii=False))
