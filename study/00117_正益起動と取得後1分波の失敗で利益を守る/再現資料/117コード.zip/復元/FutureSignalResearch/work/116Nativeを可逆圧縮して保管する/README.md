# 116Nativeの可逆bytes保管

Rootレビュー前。Nativeの金融JSONは解析せず、元gzipから一回展開した全bytesをzstdへ保管する。level3/window_log29（最大512MiB window）/long_distance_matching=1/checksum=1を固定。辞書は使わない。圧縮器はPython3.14.3標準compression.zstd、zstd1.5.7。金融ロジック・Raw・価格CSV・損益CSVには触れない。

Rootの同F1・全70金融成功・36会計/場・全Source同体・840旧対照・全flatを小metadataで認証し、許可された70Nativeだけを逐次読む。metadata-onlyはNativeをopen/stat/hashしない。未固定/未解禁要求は他Ref参照前に拒否する。

各場は元gzipを一回だけread/decompressし、zstdメモリ展開と保存ファイル再展開を全bytes/SHAで照合する。保存実exeのGo1.24.2 gzip.NewWriter defaultへ復元payloadを一括Writeし、元gzipの全bytes・SHA・sizeを確認する。照合用に新規作成した一時gzipだけを一場ごとに削除する。元Native・旧正式物は削除/上書きしない。失敗時は不完了を残し、成功索引を作らない。

出力は`Native_zstd/*.Native.json.zst`と`Native可逆圧縮索引.json`。索引へ元gzip Ref/size・展開JSON SHA/size・実zstd SHA/size・復元方法・実exe/sourceのRefを保持する。存在しない通常Native.json.gzを指すcatalogは生成しない。正式先への書込みは後段Rootが行う。

```text
python -X utf8 保管する.py --request <新Root要求JSON> --sha256 <SHA> --output <要求と同じ未作成work先> --metadata-only
python -X utf8 保管する.py --request <同要求> --sha256 <SHA> --output <同じ未作成先>
python -X utf8 保管する.py --restore-index <成功索引JSON> --sha256 <索引SHA> --session <場ID> --restore-out <既存work親配下の未作成gzip> --restorer <保存した実exe>
```

必要時は成功索引の保存相対zstdを使い、workへ元gzipと同SHAで復元して既存コードから参照する。将来のGo更新に依存せず、保存した実使用exeを使う。sourceから別Go版で再ビルドしたexeを同じ復元物と扱わない。

`python -X utf8 人工検査.py`は一時手製bytesだけを使う。旧最大一場の試験はmetadataの参照に限り、ここで自然70場の追加読取・出力は行わない。停止はRootレビュー後のみ。全70への実行はRootが新要求を固定して所有する。
