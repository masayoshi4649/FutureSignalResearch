package main

import (
	"encoding/json"
	"fmt"
	"os"

	actor "github.com/masayoshi4649/SessionTradeExecuter/continuousactor117"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor117"
	short "github.com/masayoshi4649/SessionTradeExecuter/shortwave117"
)

// main は実APIの宣言だけをJSONへ公開します。
//
// 引数: CLI第1引数(string)はactor/pure/short。返り値: なし。市場入力を受け付けません。
func main() {
	if len(os.Args) != 2 {
		panic("宣言種別が必要")
	}
	var value any
	switch os.Args[1] {
	case "actor":
		value = actor.DeclaredContinuousConfigurations()
	case "pure":
		e, err := guard.H0DefinitionFor(guard.H0E)
		if err != nil {
			panic(err)
		}
		m, err := guard.H0DefinitionFor(guard.H0M)
		if err != nil {
			panic(err)
		}
		value = struct {
			Version        int                   `json:"version"`
			Definitions    []guard.Definition    `json:"definitions"`
			H0Definitions  []guard.H0Definition  `json:"h0_definitions"`
			Configurations []guard.Configuration `json:"configurations"`
		}{117, guard.DeclaredDefinitions(), []guard.H0Definition{e, m}, guard.DeclaredConfigurations()}
	case "short":
		value = short.DeclaredDefinition()
	default:
		panic("未宣言の宣言種別")
	}
	if err := json.NewEncoder(os.Stdout).Encode(value); err != nil {
		panic(fmt.Sprintf("宣言出力:%v", err))
	}
}
