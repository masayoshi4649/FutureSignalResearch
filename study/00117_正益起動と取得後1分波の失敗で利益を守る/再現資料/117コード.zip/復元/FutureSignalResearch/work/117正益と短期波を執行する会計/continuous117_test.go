package miniprotect

import (
	"fmt"
	"testing"

	legacy "github.com/masayoshi4649/SessionTradeExecuter/continuousactor112"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	short "github.com/masayoshi4649/SessionTradeExecuter/shortwave117"
)

// shortBank117 は原板を読まない手製場の1分bankを作ります。
//
// 引数: t(*testing.T)は検査器。返り値: *short.Bankは当場coldの状態です。
func shortBank117(t *testing.T) *short.Bank {
	t.Helper()
	s := session94()
	b, err := short.NewBank(short.Scope{Session: s.ID, Contract: "人工限月117", Start: s.Start})
	if err != nil {
		t.Fatal(err)
	}
	return b
}

// books117 は20政策費用と旧12対照を別の実在庫で初期化します。
//
// 引数: t(*testing.T)は検査器。返り値: map二つは新20と旧12です。
func books117(t *testing.T) (map[string]*ActualBook, map[string]*legacy.ActualBook) {
	t.Helper()
	current, previous := map[string]*ActualBook{}, map[string]*legacy.ActualBook{}
	for _, cfg := range DeclaredContinuousConfigurations() {
		book, err := NewContinuousBook(session94(), "人工限月117", cfg)
		if err != nil {
			t.Fatal(err)
		}
		current[book.Snapshot().Key] = book
		if cfg.Policy == "S0" || cfg.Policy == "W100" || cfg.Policy == "P100" {
			old, err := legacy.NewContinuousBook(session94(), "人工限月117", legacy.ActorConfig{Policy: cfg.Policy, SlipPts: cfg.SlipPts, DelaySeconds: cfg.DelaySeconds})
			if err != nil {
				t.Fatal(err)
			}
			previous[book.Snapshot().Key] = old
		}
	}
	return current, previous
}

// feed117 は一つの人工bankを先に進め、全口座へ同じSource通知を配送します。
//
// 引数: t/bank/current/previous/o/batchは検査器・共有bank・各口座・原行・通知です。
// 返り値: なし。旧12対照の全金融JSONは各原行で照合します。
func feed117(t *testing.T, bank *short.Bank, current map[string]*ActualBook, previous map[string]*legacy.ActualBook, o Observation, batch NativeBatch) {
	t.Helper()
	snapshot, err := bank.Step(short.Quote{Time: o.Time, Index: int(o.Index), SourceLine: int(batch.Delta.SourceLine), Last: o.Last})
	if err != nil {
		t.Fatal(err)
	}
	for _, book := range current {
		if book.result.Config.Policy == "H0M" {
			if err := book.SetShortwaveSnapshot(snapshot); err != nil {
				t.Fatal(err)
			}
		}
		if err := book.OnNativeStep(o, batch.Delta.SourceLine, []NativeBatch{batch}); err != nil {
			t.Fatalf("%s:%v", book.result.Key, err)
		}
	}
	for key, book := range previous {
		if err := book.OnNativeStep(o, batch.Delta.SourceLine, []legacy.NativeBatch{{Method: batch.Method, Delta: batch.Delta}}); err != nil {
			t.Fatal(err)
		}
		proof, err := CompareLegacy112(current[key].Snapshot(), book.Snapshot())
		if err != nil || !proof.AllFinancialEqual {
			t.Fatalf("旧12対照%s:%v", key, err)
		}
	}
}

// finish117 は人工Sourceが返済済みの全口座の残/予約0を検査します。
//
// 引数: t/current/previousは検査器と新旧口座。返り値: なし。
func finish117(t *testing.T, current map[string]*ActualBook, previous map[string]*legacy.ActualBook) {
	t.Helper()
	for key, book := range current {
		result, err := book.Finish()
		if err != nil || result.Totals.OpenBuy != 0 || result.Totals.OpenSell != 0 || result.Totals.PendingBuy != 0 || result.Totals.PendingSell != 0 {
			t.Fatalf("完結%s:%v %+v", key, err, result.Totals)
		}
	}
	for key, book := range previous {
		if _, err := book.Finish(); err != nil {
			t.Fatal(err)
		}
		if _, err := CompareLegacy112(current[key].Snapshot(), book.Snapshot()); err != nil {
			t.Fatal(err)
		}
	}
}

// TestTwentyPoliciesAndColdProfitFloor117 は短期cold中の正益起動と旧12全JSONを照合します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。半円費用と後原行約定を含みます。
func TestTwentyPoliciesAndColdProfitFloor117(t *testing.T) {
	if len(DeclaredContinuousConfigurations()) != 20 {
		t.Fatal("20条件でない")
	}
	for _, side := range []int{1, -1} {
		t.Run(fmt.Sprint(side), func(t *testing.T) {
			current, previous := books117(t)
			bank, source := shortBank117(t), newFixtureSource94()
			moves := []float64{0, 0, 30, 40, 20, 0, 0, 0, 0}
			for i, move := range moves {
				o := observation94(session94(), side, int64(i), float64(i), move, 0)
				news := []native.Signal{}
				if i == 0 {
					news = append(news, birth94("A", side, 2))
				}
				if i == 6 {
					news = append(news, close94("閉A", "A", side, 2))
				}
				batch := source.step(t, o, int64(i+100), news, nil)
				feed117(t, bank, current, previous, o, batch)
				if i == 3 {
					for _, policy := range []string{"H0E", "H0M"} {
						position := current[policy+"_C0_D0"].Snapshot().Positions[0]
						v := position.Protection117.FinalState
						if !v.Active || v.FloorPoints == nil || *v.FloorPoints < 5 || v.H0 == nil || !v.H0.ZeroTargetAdopted {
							t.Fatalf("cold中の起動/費用床:%s %+v", policy, v)
						}
						if policy == "H0M" && (position.Shortwave117 == nil || position.Shortwave117.FinalState.Armed) {
							t.Fatal("助走中に短期arm")
						}
					}
				}
			}
			finish117(t, current, previous)
		})
	}
}

// TestMissingShortBankAndFutureDelivery117 は新1分の未配送と未来を受理しません。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestMissingShortBankAndFutureDelivery117(t *testing.T) {
	book, err := NewContinuousBook(session94(), "人工限月117", ActorConfig{Policy: "H0M"})
	if err != nil {
		t.Fatal(err)
	}
	o := observation94(session94(), 1, 0, 0, 0, 0)
	source := newFixtureSource94()
	batch := source.step(t, o, 100, []native.Signal{birth94("A", 1, 1)}, nil)
	if err := book.OnNativeStep(o, 100, []NativeBatch{batch}); err == nil {
		t.Fatal("短期bank未配送の原行を受理")
	}
	book, err = NewContinuousBook(session94(), "人工限月117", ActorConfig{Policy: "H0M"})
	if err != nil {
		t.Fatal(err)
	}
	bank := shortBank117(t)
	snapshot, err := bank.Step(short.Quote{Time: o.Time + 1, Index: 1, SourceLine: 101, Last: o.Last})
	if err != nil {
		t.Fatal(err)
	}
	if err = book.SetShortwaveSnapshot(snapshot); err != nil {
		t.Fatal(err)
	}
	if err = book.OnNativeStep(o, 100, []NativeBatch{batch}); err == nil {
		t.Fatal("未来の短期原行を受理")
	}
	if _, err := NewContinuousBook(session94(), "人工限月117", ActorConfig{Policy: "E50"}); err == nil {
		t.Fatal("旧E50を新政策へ偽装")
	}
}

// TestIntraminuteCompositeExit117 は実1分bankから生じた警戒が後原行返済へ届くことを検査します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。列は市場由来ではない手製の順行・波・反対進行です。
func TestIntraminuteCompositeExit117(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, badWarning := range []bool{false, true} {
			t.Run(fmt.Sprintf("方向%d_警戒時異常%v", side, badWarning), func(t *testing.T) {
				current, previous := books117(t)
				bank, source := shortBank117(t), newFixtureSource94()
				index := int64(0)
				feed := func(seconds, price float64, news []native.Signal) {
					t.Helper()
					o := observation94(session94(), side, index, seconds, price-1005, 0)
					if badWarning && seconds == 39*60+20 {
						o.QuoteOK = false
					}
					batch := source.step(t, o, index+1000, news, nil)
					feed117(t, bank, current, previous, o, batch)
					index++
				}
				feed(0, 995, []native.Signal{birth94("波", side, 2)})
				feed(.5, 995, nil)
				feed(1, 1000, nil)
				for minute := 0; minute < 34; minute++ {
					feed(float64(minute)*60+50, 1000+10*float64(minute), nil)
				}
				// ----------------------------------------
				// 初期の単調進行後に、取得後の谷と別足の終値更新を手製で形成する。
				bars := [][4]float64{{1340, 1390, 1330, 1370}, {1430, 1440, 1410, 1430}, {1430, 1430, 1390, 1400}, {1400, 1430, 1400, 1420}, {1420, 1460, 1410, 1460}}
				for i, bar := range bars {
					minute := 34 + i
					for j, price := range bar {
						feed(float64(minute)*60+[]float64{0, 10, 20, 50}[j], price, nil)
					}
				}
				feed(39*60, 1460, nil)
				before := current["H0M_C0_D0"].Snapshot().Positions[0]
				if before.Shortwave117 == nil || !before.Shortwave117.FinalState.Armed {
					t.Fatal("取得後の谷/終値更新でarmしない")
				}
				feed(39*60+20, 1320, nil)
				warn := current["H0M_C0_D0"].Snapshot().Positions[0]
				if warn.Shortwave117.FirstWarning == nil || warn.Quantity == 0 {
					t.Fatalf("足途中警戒/当行非約定/全量予約:%+v", warn)
				}
				if badWarning {
					if warn.Protection117.FirstNarrowing != nil || warn.Reserved != 0 || warn.Protection117.FinalState.H0.Narrow == nil || warn.Protection117.FinalState.H0.NarrowApplied {
						t.Fatal("異常BBOで幅適用/注文した")
					}
				} else if warn.Protection117.FirstNarrowing == nil || warn.Reserved != 2 {
					t.Fatal("正常BBOで幅適用/予約しない")
				}
				if warn.Shortwave117.FirstWarning.Quote.Time != session94().Start+1800+39*60+20 {
					t.Fatal("足終まで待っている")
				}
				feed(39*60+21, 1310, nil)
				if badWarning {
					waiting := current["H0M_C0_D0"].Snapshot().Positions[0]
					if waiting.Quantity != 2 || waiting.Reserved != 2 || waiting.Protection117.FirstNarrowing == nil || waiting.Protection117.FirstNarrowing.At != session94().Start+1800+39*60+21 {
						t.Fatal("正常化原行の幅適用/後原行待ちを失った")
					}
				}
				feed(39*60+22, 1310, nil)
				after := current["H0M_C0_D0"].Snapshot().Positions[0]
				ordinary := current["H0E_C0_D0"].Snapshot().Positions[0]
				if after.Quantity != 0 || after.Reserved != 0 || after.RealizedNet != 60846 || ordinary.Quantity != 2 {
					t.Fatalf("後原行の実返済と通常対照:%+v / %+v", after, ordinary)
				}
				if after.Shortwave117.FinalOwnership == nil || after.Shortwave117.FinalOwnership.Remaining != 0 {
					t.Fatal("短期監視停止と実残0の所有記録")
				}
				feed(40*60, 1240, nil)
				feed(40*60+1, 1230, nil)
				feed(41*60, 1230, []native.Signal{close94("閉波", "波", side, 2)})
				feed(41*60+1, 1220, nil)
				feed(41*60+2, 1220, nil)
				finish117(t, current, previous)
			})
		}
	}
}
