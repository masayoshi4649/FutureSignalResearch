package miniprotect

import (
	"bytes"
	"encoding/json"
	"fmt"
	"math"

	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor117"
	short "github.com/masayoshi4649/SessionTradeExecuter/shortwave117"
)

// ShortwavePoint117 は短期判定の実原行と実所有を結びます。
type ShortwavePoint117 struct {
	Quote       QuoteStamp     `json:"quote"`
	Phase       string         `json:"phase"`
	BankSHA256  string         `json:"bank_sha256"`
	Snapshot    short.Snapshot `json:"snapshot"`
	Decision    short.Decision `json:"decision"`
	Remaining   int            `json:"remaining"`
	Reserved    int            `json:"reserved"`
	RealizedNet float64        `json:"realized_net"`
}

// ShortwaveOwnership117 は短期状態の停止後にも実返済完結を記録します。
type ShortwaveOwnership117 struct {
	Quote       QuoteStamp `json:"quote"`
	Remaining   int        `json:"remaining"`
	Reserved    int        `json:"reserved"`
	RealizedNet float64    `json:"realized_net"`
}

// ShortwaveAudit117 は毎原行を複写せず初回・遷移・最終を保持します。
type ShortwaveAudit117 struct {
	Initial                     short.Snapshot         `json:"initial"`
	First                       *ShortwavePoint117     `json:"first,omitempty"`
	FirstCandidate              *ShortwavePoint117     `json:"first_candidate,omitempty"`
	LastCandidate               *ShortwavePoint117     `json:"last_candidate,omitempty"`
	FirstArm                    *ShortwavePoint117     `json:"first_arm,omitempty"`
	LastArm                     *ShortwavePoint117     `json:"last_arm,omitempty"`
	FirstWarning                *ShortwavePoint117     `json:"first_warning,omitempty"`
	FirstReset                  *ShortwavePoint117     `json:"first_reset,omitempty"`
	LastReset                   *ShortwavePoint117     `json:"last_reset,omitempty"`
	Last                        *ShortwavePoint117     `json:"last,omitempty"`
	FinalState                  short.Snapshot         `json:"final_state"`
	FinalOwnership              *ShortwaveOwnership117 `json:"final_ownership,omitempty"`
	Evaluations                 uint64                 `json:"evaluations"`
	BadQuoteEvaluations         uint64                 `json:"bad_quote_evaluations"`
	MissingIndicatorEvaluations uint64                 `json:"missing_indicator_evaluations"`
	Candidates                  uint64                 `json:"candidates"`
	Armings                     uint64                 `json:"armings"`
	Resets                      uint64                 `json:"resets"`
}

type shortwavePosition117 struct {
	state  short.State
	narrow *guard.NarrowInput
}

type shortwaveRuntime117 struct {
	latest    *short.BankSnapshot
	positions map[string]*shortwavePosition117
}

// SetShortwaveSnapshot は共有1分bankの当原行をH0M口座だけへ配送します。
//
// 引数: snapshot(short.BankSnapshot)は原行までの確定値とprefixです。
// 返り値: errorは別場・後退・未来・二重配送です。配送だけでは注文しません。
func (b *ActualBook) SetShortwaveSnapshot(snapshot short.BankSnapshot) error {
	if err := b.ready(); err != nil {
		return err
	}
	if b.shortwave == nil || b.continuous == nil || !snapshot.HaveQuote || snapshot.Scope != (short.Scope{Session: b.result.Session.ID, Contract: b.continuous.contract, Start: b.result.Session.Start}) {
		return b.stop(fmt.Errorf("117短期公表の口座/場不整合"))
	}
	q := snapshot.Quote
	if q.Index < 0 || q.SourceLine <= 0 || !finiteActual(q.Time, q.Last) || q.Last <= 0 || q.Time < b.lastEventAt || len(snapshot.SHA256) != 64 {
		return b.stop(fmt.Errorf("117短期公表の原行/時計不整合"))
	}
	if old := b.shortwave.latest; old != nil && (q.Index <= old.Quote.Index || q.Time < old.Quote.Time) {
		return b.stop(fmt.Errorf("117短期公表の後退/二重配送"))
	}
	// Bank.Stepの独立Snapshotを値で受け、Actor自身は変更しない。
	b.shortwave.latest = &snapshot
	return nil
}

// validateShortwaveRow117 は無保有時も最新1分とSourceの原行を照合します。
//
// 引数: quote(QuoteStamp)は今から処理する実原行です。
// 返り値: errorは未配送/未来/別行です。旧政策の経路は変更しません。
func (b *ActualBook) validateShortwaveRow117(quote QuoteStamp) error {
	if b.shortwave == nil {
		return nil
	}
	if b.shortwave.latest == nil {
		return fmt.Errorf("117短期bankの当原行未配送")
	}
	q := b.shortwave.latest.Quote
	if q.Time != quote.Time || int64(q.Index) != quote.Index || int64(q.SourceLine) != quote.SourceLine || q.Last != quote.Last {
		return fmt.Errorf("117短期bankとSourceの原行差")
	}
	return nil
}

// initShortwave117 は実fillの価格/原行だけで取得後波の監視を作ります。
//
// 引数: p(*ActualPosition)、width(float64)は実新玉と固定通常幅です。
// 返り値: errorは当原行未配送又は初期化不正です。
func (b *ActualBook) initShortwave117(p *ActualPosition, width float64) error {
	if b.shortwave == nil {
		return nil
	}
	bank := b.shortwave.latest
	if bank == nil || int64(bank.Quote.Index) != p.EntryQuote.Index || int64(bank.Quote.SourceLine) != p.EntryQuote.SourceLine || bank.Quote.Time != p.EntryQuote.Time {
		return fmt.Errorf("117実fillに対応する短期原行がない")
	}
	entry := short.Entry{Scope: bank.Scope, PositionID: p.ID, Side: p.Side, Price: p.EntryPrice, Fill: bank.Quote, InitialQuantity: p.InitialQuantity, NormalWidthPoints: width}
	state, err := short.NewState(entry)
	if err != nil {
		return err
	}
	view := state.Snapshot()
	b.shortwave.positions[p.ID] = &shortwavePosition117{state: state}
	p.Shortwave117 = &ShortwaveAudit117{Initial: view, FinalState: view}
	return nil
}

// advanceShortwave117 は当原行の新Activeを受け、短期警戒を金額保護へ渡します。
//
// 引数: p(*ActualPosition)、at(float64)、phase(string)、active(bool)は当位相の実所有です。
// 返り値: *guard.NarrowInput/errorは不変の警戒票又は不正です。実残0では新監視しません。
func (b *ActualBook) advanceShortwave117(p *ActualPosition, at float64, phase string, active bool) (*guard.NarrowInput, error) {
	if b.shortwave == nil {
		return nil, nil
	}
	position, bank := b.shortwave.positions[p.ID], b.shortwave.latest
	if position == nil || p.Shortwave117 == nil {
		return nil, fmt.Errorf("117実玉の短期状態がない")
	}
	if p.Quantity == 0 {
		if p.Shortwave117.FinalOwnership == nil && b.continuous.current != nil {
			p.Shortwave117.FinalOwnership = &ShortwaveOwnership117{Quote: *b.continuous.current, RealizedNet: p.RealizedNet}
		}
		return nil, nil
	}
	if bank == nil || bank.Quote.Time != at {
		return nil, nil
	}
	current := b.continuous.current
	if current == nil || current.Index != int64(bank.Quote.Index) || current.SourceLine != int64(bank.Quote.SourceLine) || current.Time != at {
		return nil, fmt.Errorf("117短期評価と実原行の不一致")
	}
	state, decision, err := short.Advance(position.state, short.Input{Snapshot: *bank, Phase: short.Phase(phase), Active: active, Remaining: p.Quantity})
	if err != nil {
		return nil, err
	}
	position.state = state
	view := state.Snapshot()
	if !decision.Duplicate {
		point := &ShortwavePoint117{Quote: *current, Phase: phase, BankSHA256: bank.SHA256, Snapshot: view, Decision: decision, Remaining: p.Quantity, Reserved: p.Reserved, RealizedNet: p.RealizedNet}
		audit := p.Shortwave117
		audit.Evaluations++
		if !normalActual(*current) {
			audit.BadQuoteEvaluations++
		}
		if len(decision.Missing) != 0 {
			audit.MissingIndicatorEvaluations++
		}
		if audit.First == nil {
			audit.First = point
		}
		if decision.CandidateNow {
			audit.Candidates++
			if audit.FirstCandidate == nil {
				audit.FirstCandidate = point
			}
			audit.LastCandidate = point
		}
		if decision.ArmedNow {
			audit.Armings++
			if audit.FirstArm == nil {
				audit.FirstArm = point
			}
			audit.LastArm = point
		}
		if decision.ResetNow {
			audit.Resets++
			if audit.FirstReset == nil {
				audit.FirstReset = point
			}
			audit.LastReset = point
		}
		if decision.NarrowedNow {
			audit.FirstWarning = point
		}
		audit.Last, audit.FinalState = point, view
	}
	if view.Narrowed && position.narrow == nil {
		if view.FirstWarning == nil || view.TargetWidthPoints == nil {
			return nil, fmt.Errorf("117警戒の根拠/幅欠落")
		}
		witness := view.FirstWarning
		body, marshalErr := json.Marshal(witness)
		if marshalErr != nil {
			return nil, marshalErr
		}
		position.narrow = &guard.NarrowInput{Scope: b.continuousScope(), ID: fmt.Sprintf("117短期/%s/%d/%d", p.ID, witness.At.Index, witness.At.SourceLine), At: witness.At.Time, SourceIndex: int64(witness.At.Index), SourceLine: int64(witness.At.SourceLine), WidthPoints: *view.TargetWidthPoints, Completed: true, Witness: body}
	}
	if position.narrow != nil {
		if err := b.validateNarrowBridge117(p, view, position.narrow); err != nil {
			return nil, err
		}
	}
	return position.narrow, nil
}

// validateNarrowBridge117 は不透明な純床票を実短期Witnessと現在原行へ厳密結合します。
//
// 引数: p(*ActualPosition)、view(short.Snapshot)、n(*guard.NarrowInput)は実所有と完成票です。
// 返り値: errorは票/幅/原行/実Positionの意味不整合です。自然価格を追加取得しません。
func (b *ActualBook) validateNarrowBridge117(p *ActualPosition, view short.Snapshot, n *guard.NarrowInput) error {
	w, q := view.FirstWarning, b.continuous.current
	if w == nil || q == nil || n == nil || !view.Narrowed || view.TargetWidthPoints == nil || w.TargetWidthPoints == nil || !n.Completed || n.Scope != b.continuousScope() || view.Entry.PositionID != p.ID || view.Entry.Price != p.EntryPrice || view.Entry.Side != p.Side || w.Warning != short.True || w.S != short.True || w.M != short.True || w.V != short.True || !w.Active || w.Remaining < 1 || w.Remaining > p.InitialQuantity {
		return fmt.Errorf("117短期完成票と実所有/三役の結合差")
	}
	if int64(w.At.Index) < p.EntryQuote.Index || int64(w.At.Index) > q.Index || int64(w.At.SourceLine) < p.EntryQuote.SourceLine || int64(w.At.SourceLine) > q.SourceLine || w.At.Time < p.EntryQuote.Time || w.At.Time > q.Time || n.At != w.At.Time || n.SourceIndex != int64(w.At.Index) || n.SourceLine != int64(w.At.SourceLine) || len(w.BankSHA256) != 64 || w.Prefix == nil || w.Prefix.Last != w.At || w.Prefix.Published != w.At || (w.Phase != short.PreFill && w.Phase != short.AfterSource) {
		return fmt.Errorf("117短期完成票の実原行/時計/出典差")
	}
	wantID := fmt.Sprintf("117短期/%s/%d/%d", p.ID, w.At.Index, w.At.SourceLine)
	if !w.AArm.Known || w.AArm.Value <= 0 || p.Protection117 == nil {
		return fmt.Errorf("117完成幅の有効化尺度欠落")
	}
	wantWidth := 5 * math.Ceil(math.Max(5, math.Min(p.Protection117.Initial.NormalWidth, w.AArm.Value))/5)
	body, err := json.Marshal(w)
	if err != nil || n.ID != wantID || n.WidthPoints != wantWidth || *view.TargetWidthPoints != wantWidth || *w.TargetWidthPoints != wantWidth || !bytes.Equal(n.Witness, body) {
		return fmt.Errorf("117短期完成票のID/固定幅/Witness差")
	}
	return nil
}
