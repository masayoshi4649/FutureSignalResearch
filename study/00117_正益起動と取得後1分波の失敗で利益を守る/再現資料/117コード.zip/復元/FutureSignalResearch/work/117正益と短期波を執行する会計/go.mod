module github.com/masayoshi4649/SessionTradeExecuter/continuousactor117

go 1.24.2

require (
	github.com/BurntSushi/toml v1.5.0 // indirect
	github.com/expr-lang/expr v1.17.8 // indirect
	github.com/masayoshi4649/SessionTradeExecuter v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/continuousactor111 v0.0.0 // indirect
	github.com/masayoshi4649/SessionTradeExecuter/continuousactor112 v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/mininative v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/miniprotect v0.0.0 // indirect
	github.com/masayoshi4649/SessionTradeExecuter/profitfloor111 v0.0.0 // indirect
	github.com/masayoshi4649/SessionTradeExecuter/profitfloor112 v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/profitfloor113 v0.0.0 // indirect
)

replace github.com/masayoshi4649/SessionTradeExecuter => ../../../SessionTradeExecuter

replace github.com/masayoshi4649/SessionTradeExecuter/mininative => ../../scripts/FAR元三手法のmini連続再現

replace github.com/masayoshi4649/SessionTradeExecuter/miniprotect => ../../scripts/FAR連続出生と個別利益追尾

replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor113 => ../113起動前の支持否定と利益保護の純演算

replace github.com/masayoshi4649/SessionTradeExecuter/continuousactor112 => ../112支持否定と広い通常幅の会計

replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor112 => ../112支持否定の必須確認と通常幅のみ

replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor111 => ../111全玉利益と収束BBの純保護

replace github.com/masayoshi4649/SessionTradeExecuter/continuousactor111 => ../111元通知の連続Actor

require (
	github.com/masayoshi4649/SessionTradeExecuter/profitfloor117 v0.0.0
	github.com/masayoshi4649/SessionTradeExecuter/shortwave117 v0.0.0
)

replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor117 => ../117正益起動と費用回収床の純保護

replace github.com/masayoshi4649/SessionTradeExecuter/shortwave117 => ../117原行と暫定1分の複合保護

replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor112fast => ../112純状態コピー高速化の試作
