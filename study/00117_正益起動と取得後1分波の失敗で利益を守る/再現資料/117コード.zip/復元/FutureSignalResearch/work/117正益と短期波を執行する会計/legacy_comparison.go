package miniprotect

import (
	"bytes"
	"encoding/json"
	"fmt"
	"reflect"

	legacy "github.com/masayoshi4649/SessionTradeExecuter/continuousactor112"
	oldguard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor112"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor117"
)

// LegacyComparison117 は許可した説明・定義版差と無効fieldの件数を明記します。
type LegacyComparison117 struct {
	Policy              string `json:"policy"`
	StreamScopeChanged  bool   `json:"stream_scope_difference"`
	AuditFieldRenames   int    `json:"audit_field_renames"`
	DefinitionSnapshots int    `json:"definition_snapshots"`
	DisabledFields      int    `json:"disabled_fields"`
	AllFinancialEqual   bool   `json:"all_financial_equal"`
}

// comparisonValue117 は公開結果の全JSONを数値字句を保って写します。
//
// 引数: value(any)は実公開結果又は政策定義です。
// 返り値: any/errorは全JSON値又は符号化差です。金融値を選別しません。
func comparisonValue117(value any) (any, error) {
	raw, err := json.Marshal(value)
	if err != nil {
		return nil, err
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.UseNumber()
	var result any
	err = decoder.Decode(&result)
	return result, err
}

// normalizeControls117 は厳密な定義と無効な新fieldだけを検査して対照版へ写します。
//
// 引数: value/definition/prior(any)は全JSON部分木と117/112の同政策宣言、result(*LegacyComparison117)は件数です。
// 返り値: errorは定義不整合又はControlでの新機能の有効化です。生C/M/P/Bは触りません。
func normalizeControls117(value, definition, prior any, result *LegacyComparison117) error {
	switch node := value.(type) {
	case []any:
		for _, child := range node {
			if err := normalizeControls117(child, definition, prior, result); err != nil {
				return err
			}
		}
	case map[string]any:
		if actual, exists := node["definition"]; exists {
			if _, ok := node["entry"]; !ok || !reflect.DeepEqual(actual, definition) {
				return fmt.Errorf("117Controlの定義差")
			}
			node["definition"] = prior
			result.DefinitionSnapshots++
		}
		disabled := map[string]any{
			"entry_support": nil, "entry_support_eligible": false, "entry_invalidated": false,
			"entry_invalidated_at": nil, "entry_invalidation_witness": nil,
			"entry_support_break": json.Number("0"), "entry_invalidated_now": false, "entry_exit_quantity": json.Number("0"),
			"first_entry_invalidation": nil, "entry_exit_requests": nil,
			"entry_invalidated_positions": json.Number("0"), "entry_invalidation_exit_requests": json.Number("0"),
			"entry_invalidation_exit_fills": json.Number("0"), "entry_invalidation_point": nil, "entry_invalidation": false,
		}
		for name, expected := range disabled {
			if actual, exists := node[name]; exists {
				if !reflect.DeepEqual(actual, expected) {
					return fmt.Errorf("117Controlの新fieldが無効でない:%s", name)
				}
				delete(node, name)
				result.DisabledFields++
			}
		}
		for _, child := range node {
			if err := normalizeControls117(child, definition, prior, result); err != nil {
				return err
			}
		}
	}
	return nil
}

// CompareLegacy112 は共通3政策を受理原行ごと又は完結後に全金融JSONで比較します。
//
// 引数: current(ActualResult)、prior(legacy.ActualResult)は同じ政策・C/Dの117と固定112です。
// 返り値: LegacyComparison117/errorは許可版差の件数又は全金融/全Stateの差です。
func CompareLegacy112(current ActualResult, prior legacy.ActualResult) (LegacyComparison117, error) {
	proof := LegacyComparison117{Policy: current.Config.Policy}
	if current.Config.Policy != "S0" && current.Config.Policy != "W100" && current.Config.Policy != "P100" {
		return proof, fmt.Errorf("117新政策を旧名へ投影しない")
	}
	if current.Config.Policy != prior.Config.Policy || current.Config.SlipPts != prior.Config.SlipPts || current.Config.DelaySeconds != prior.Config.DelaySeconds || current.StreamScope != ContinuousScope117 || prior.StreamScope != legacy.ContinuousScope112 {
		return proof, fmt.Errorf("117/112のControl条件差")
	}
	lv, err := comparisonValue117(current)
	if err != nil {
		return proof, err
	}
	rv, err := comparisonValue117(prior)
	if err != nil {
		return proof, err
	}
	left, right := lv.(map[string]any), rv.(map[string]any)
	proof.StreamScopeChanged = left["stream_scope"] != right["stream_scope"]
	left["stream_scope"], right["stream_scope"] = "", ""
	var definition, oldDefinition any
	for _, item := range guard.DeclaredDefinitions() {
		if string(item.Policy) == current.Config.Policy {
			definition, err = comparisonValue117(item)
		}
	}
	if err != nil {
		return proof, err
	}
	for _, item := range oldguard.DeclaredDefinitions() {
		if string(item.Policy) == current.Config.Policy {
			oldDefinition, err = comparisonValue117(item)
		}
	}
	if err != nil || definition == nil || oldDefinition == nil {
		return proof, fmt.Errorf("117/112のControl定義欠落")
	}
	if positions, ok := left["positions"].([]any); ok {
		for _, raw := range positions {
			position := raw.(map[string]any)
			if _, exists := position["protection112"]; exists {
				return proof, fmt.Errorf("117に旧監査名を混入")
			}
			if audit, exists := position["protection117"]; exists {
				delete(position, "protection117")
				position["protection112"] = audit
				proof.AuditFieldRenames++
			}
		}
	}
	if err = normalizeControls117(left, definition, oldDefinition, &proof); err != nil {
		return proof, err
	}
	if !reflect.DeepEqual(left, right) {
		return proof, fmt.Errorf("117/112Controlの全金融JSONに差:%s", current.Key)
	}
	proof.AllFinancialEqual = true
	return proof, nil
}
