# 117純保護API

moduleは `github.com/masayoshi4649/SessionTradeExecuter/profitfloor117`。旧113を変更せず依存する。市場・原板・Native・CSVを開くAPIはない。注文・実約定・仮損益を作らない。

`Policy/Definition/Entry/Scope/Evidence/Pivot/Publication/BBResult/Truth/Phase/Configuration` は旧113の型alias。`NewState(Entry) (State,error)`、`Advance(State,Input) (State,Decision,error)`、`State.Snapshot() Snapshot` を公開する。S0のNewState拒否も旧113と同じであり、ActorのS0経路を維持する。W100/P100は旧113へ直接委譲する。五政策以外は受理しない。

`Input` は旧九項目と同名・同型を持ち、`SourceIndex int64`、`Narrow *NarrowInput` を追加する。SourceIndexはH0の当原行Indexで、同原行再同期時も直前Indexを使う。SequenceはAdvanceごとに増加し、同時刻・同Indexのpre/afterや予約再同期を区別する。既返済Rは同Positionの実費用後円額で、半円単位。Markは正常返済側BBOだけを渡し、異常・未取得ならnilとする。正常性判定と実所有の抽出はActorが担う。

```go
type NarrowInput struct {
    Scope Scope
    ID string
    At float64
    SourceIndex int64
    SourceLine int64
    WidthPoints float64
    Completed bool
    Witness json.RawMessage
}
```

H0MはActive後のCompleted=trueを初票として固定する。Scope同体、Atが取得以降かつ当入力以下、Indexが非負かつ当Index以下、Lineが正、幅が有限5pt刻みかつ5～1,000,000ptを要求する。Witnessは任意の正常JSONであり、意味を床部品で再判定しない。同票再送は全値同体だけを受理し、別IDや同ID改竄で置換しない。H0E・旧政策へNarrowを渡すことは不正。

`Snapshot` と `Decision` は旧113の同名型を匿名埋込し、追加 `H0 *H0Snapshot/Decision` を `h0_117,omitempty` として持つ。旧政策はnilなので旧JSONと全値・並びを保つ。新H0の共通Definition.Versionは117、ThresholdPoints/MinimumFloorは0。取得時通常幅・価格床・全玉目標は共通欄に保持する。起動前のWholeTargetYen=0は値未設定の便宜値で、**H0.TargetSet=false** と必ず組で読む。

H0SnapshotはSourceIndex/Phase、TargetSet、WholeTargetHalfYen、ZeroTargetAdopted/At、Narrow、NarrowApplied/Atを持つ。H0Decisionの一回だけのflagは次の四つ。

- `TargetInitializedNow`：strict W>0によって未設定Lを初期化した。
- `ZeroTargetAdoptedNow`：一呼値余地があり、費用後全玉ゼロ目標を明示採用した。初回・同峰でも可。
- `NarrowLatchedNow`：短期完成票を初めて固定した。bad Markでも成立する。
- `NarrowAppliedNow`：正常Markで完成幅を初めて適用した。

共通Narrowed/NarrowedAt/NarrowedNowは幅の実適用を示す。警戒固定だけでは立てない。H0.Warningは完成票の有無であり、旧C/M/P/Bは診断だけ。完成票があっても幅が通常幅以上なら数値幅は同じで、適用の事実だけは記録する。

Rootの二段Advanceは、先のActivatedNowと上記四flagを後段判定へOR合成してよい。一方、額・床・現在のStateは後段値を採用し、TargetBefore/InitialTarget/ZeroCandidateなどの証拠を単一位相へ誤結合しない。Narrowの完成時刻と受領・幅適用時刻は別である。

残n=0で新起動・新床・新Narrowを作らずFinishedとする。既固定Narrowの同値再送は終了時も受理する。Mark=nilの保有中入力でも既存Lを守るFWと含意額の更新は行うが、新起動・新ゼロ昇格・新幅適用・架空hitは作らない。

各Advanceは元Stateを変更せず、公開Snapshot・完成Witness・Entry/公表の参照を分離する。全RawでのJSON roundtripは使わない。旧3分公表の妥当性だけを旧W100のMark=nil経路で確認し、その公表をH0の床・幅へ使わない。
