// Package profitfloor117 は旧113を保ち、正益起動と価格同値からの費用回収床を純演算します。
package profitfloor117

import (
	"encoding/json"
	"fmt"

	legacy "github.com/masayoshi4649/SessionTradeExecuter/profitfloor113"
)

type Policy = legacy.Policy
type Definition = legacy.Definition
type Entry = legacy.Entry
type Scope = legacy.Scope
type Evidence = legacy.Evidence
type Pivot = legacy.Pivot
type Publication = legacy.Publication
type BBResult = legacy.BBResult
type Truth = legacy.Truth
type Phase = legacy.Phase
type Configuration = legacy.Configuration
type EntryInvalidationWitness = legacy.EntryInvalidationWitness

const (
	S0                 = legacy.S0
	W100               = legacy.W100
	P100               = legacy.P100
	H0E         Policy = "H0E"
	H0M         Policy = "H0M"
	Unknown            = legacy.Unknown
	False              = legacy.False
	True               = legacy.True
	PreFill            = legacy.PreFill
	AfterSource        = legacy.AfterSource
)

// NarrowInput は別の短期複合部品が既に完成した最初の警戒です。純床はWitnessの意味を再判定しません。
type NarrowInput struct {
	Scope       Scope           `json:"scope"`
	ID          string          `json:"id"`
	At          float64         `json:"at"`
	SourceIndex int64           `json:"source_index"`
	SourceLine  int64           `json:"source_line"`
	WidthPoints float64         `json:"width_points"`
	Completed   bool            `json:"completed"`
	Witness     json.RawMessage `json:"witness,omitempty"`
}

// Input は旧入力を同名で保ち、H0だけへ原行番号と短期完成警戒を追加します。nil Markは未知です。
type Input struct {
	At           float64      `json:"at"`
	Sequence     uint64       `json:"sequence"`
	Phase        Phase        `json:"phase"`
	Mark         *float64     `json:"mark"`
	Remaining    int          `json:"remaining"`
	Reserved     int          `json:"reserved"`
	ClosedNetYen float64      `json:"closed_net_yen"`
	Publication  *Publication `json:"publication"`
	ResetReason  string       `json:"reset_reason"`
	SourceIndex  int64        `json:"source_index,omitempty"`
	Narrow       *NarrowInput `json:"narrow,omitempty"`
}

type H0Definition struct {
	Version                 int     `json:"version"`
	Activation              string  `json:"activation"`
	InitialTarget           string  `json:"initial_target"`
	MinimumFloorPoints      float64 `json:"minimum_floor_points"`
	ZeroPromotion           string  `json:"zero_promotion"`
	NewPeakRequired         bool    `json:"new_peak_required"`
	TechnicalNarrowing      bool    `json:"technical_narrowing"`
	Narrowing               string  `json:"narrowing"`
	LegacyThreeMinuteEffect bool    `json:"legacy_three_minute_effect"`
}

type H0Snapshot struct {
	Definition         H0Definition `json:"definition"`
	SourceIndex        int64        `json:"source_index"`
	Phase              Phase        `json:"phase"`
	TargetSet          bool         `json:"target_set"`
	WholeTargetHalfYen *int64       `json:"whole_target_half_yen"`
	ZeroTargetAdopted  bool         `json:"zero_target_adopted"`
	ZeroTargetAt       *float64     `json:"zero_target_at"`
	Narrow             *NarrowInput `json:"narrow"`
	NarrowApplied      bool         `json:"narrow_applied"`
	NarrowAppliedAt    *float64     `json:"narrow_applied_at"`
}

type H0Decision struct {
	SourceIndex          int64    `json:"source_index"`
	Phase                Phase    `json:"phase"`
	TargetInitializedNow bool     `json:"target_initialized_now"`
	InitialTargetHalfYen *int64   `json:"initial_target_half_yen"`
	TargetBeforeHalfYen  *int64   `json:"target_before_half_yen"`
	TargetAfterHalfYen   *int64   `json:"target_after_half_yen"`
	ZeroCandidateFloor   *float64 `json:"zero_candidate_floor"`
	ZeroRoom             *bool    `json:"zero_room"`
	ZeroTargetAdoptedNow bool     `json:"zero_target_adopted_now"`
	FloorImpliedHalfYen  *int64   `json:"floor_implied_half_yen"`
	NarrowLatchedNow     bool     `json:"narrow_latched_now"`
	NarrowAppliedNow     bool     `json:"narrow_applied_now"`
}

type Snapshot struct {
	legacy.Snapshot
	H0 *H0Snapshot `json:"h0_117,omitempty"`
}

type Decision struct {
	legacy.Decision
	H0 *H0Decision `json:"h0_117,omitempty"`
}

type State struct {
	initialized bool
	legacyMode  bool
	prior       legacy.State
	diagnostic  legacy.State
	view        Snapshot
	targetHalf  int64
	lastIndex   int64
}

// DefinitionFor は旧三政策を改変せず、新H0の本名と通常幅を返します。
//
// 引数: policy(Policy)は五政策のID。返り値: Definition/errorは実定義又は未宣言です。
func DefinitionFor(policy Policy) (Definition, error) {
	switch policy {
	case S0, W100, P100:
		return legacy.DefinitionFor(policy)
	case H0E, H0M:
		formula := "技術狭幅なし。旧3分は診断のみ"
		if policy == H0M {
			formula = "別短期複合の最初の完成警戒のみ"
		}
		return Definition{Version: 117, Policy: policy, Enabled: true, ThresholdPoints: 0, NormalWidthMinimum: 200, ATRMultiplier: 2, WarningFormula: formula, TechnicalNarrowing: policy == H0M}, nil
	default:
		return Definition{}, fmt.Errorf("117の政策IDではない")
	}
}

// H0DefinitionFor は正益起動と床昇格の意味を数値定義と分けて返します。
//
// 引数: policy(Policy)はH0E/H0M。返り値: H0Definition/errorは新政策の意味又は未宣言です。
func H0DefinitionFor(policy Policy) (H0Definition, error) {
	if policy != H0E && policy != H0M {
		return H0Definition{}, fmt.Errorf("H0の政策ではない")
	}
	narrowing := "技術狭幅なし"
	if policy == H0M {
		narrowing = "最初の完成Narrowを不変ラッチ。正常Markでmin(通常幅,完成幅)を一度適用"
	}
	return H0Definition{Version: 117, Activation: "正常返済MarkのW=R+n*(100*gain-K)>0", InitialTarget: "未設定からL=R-n*K、K=77+200*S円", MinimumFloorPoints: 0, ZeroPromotion: "正常Markでmax(0,FW(0,R,n))<=gain-5ならL=max(L,0)。初回可", NewPeakRequired: false, TechnicalNarrowing: policy == H0M, Narrowing: narrowing, LegacyThreeMinuteEffect: false}, nil
}

// DeclaredDefinitions は比較対象五政策を固定順で返します。
//
// 引数: なし。返り値: []DefinitionはS0/W100/P100/H0E/H0Mです。
func DeclaredDefinitions() []Definition {
	out := make([]Definition, 0, 5)
	for _, p := range []Policy{S0, W100, P100, H0E, H0M} {
		d, _ := DefinitionFor(p)
		out = append(out, d)
	}
	return out
}

// DeclaredConfigurations は五政策と四費用の20条件を返します。
//
// 引数: なし。返り値: []Configurationは政策外・C/D内の固定順です。
func DeclaredConfigurations() []Configuration {
	out := make([]Configuration, 0, 20)
	for _, p := range []Policy{S0, W100, P100, H0E, H0M} {
		for _, c := range []float64{0, 5} {
			for _, d := range []int{0, 1} {
				out = append(out, Configuration{Policy: p, SlipPoints: c, DelaySeconds: d})
			}
		}
	}
	return out
}

// And は旧三値ANDをそのまま使います。
//
// 引数: a/b(Truth)は三値。返り値: Truth/errorは旧113と同じ結果です。
func And(a, b Truth) (Truth, error) { return legacy.And(a, b) }

// Or は旧三値ORをそのまま使います。
//
// 引数: a/b(Truth)は三値。返り値: Truth/errorは旧113と同じ結果です。
func Or(a, b Truth) (Truth, error) { return legacy.Or(a, b) }
