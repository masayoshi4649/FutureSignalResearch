package main

import (
	"encoding/json"
	"os"

	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor117"
)

// main は実関数から五政策と二H0の意味・20条件を出力します。
//
// 引数: なし。返り値: なし。実入力や市場ファイルは開きません。
func main() {
	h0 := make([]guard.H0Definition, 0, 2)
	for _, policy := range []guard.Policy{guard.H0E, guard.H0M} {
		d, err := guard.H0DefinitionFor(policy)
		if err != nil {
			panic(err)
		}
		h0 = append(h0, d)
	}
	out := map[string]any{"version": 117, "policies": []guard.Policy{guard.S0, guard.W100, guard.P100, guard.H0E, guard.H0M}, "definitions": guard.DeclaredDefinitions(), "h0_definitions": h0, "configurations": guard.DeclaredConfigurations()}
	e := json.NewEncoder(os.Stdout)
	e.SetIndent("", "  ")
	e.SetEscapeHTML(false)
	if err := e.Encode(out); err != nil {
		panic(err)
	}
}
