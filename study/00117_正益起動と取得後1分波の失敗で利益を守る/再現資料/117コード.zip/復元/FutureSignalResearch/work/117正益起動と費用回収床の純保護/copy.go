package profitfloor117

import legacy "github.com/masayoshi4649/SessionTradeExecuter/profitfloor113"

// ptr は値の独立した参照を作ります。
//
// 引数: value(T)は値型。返り値: *Tは私有参照です。
func ptr[T any](value T) *T { return &value }

// copyPtr はnilを保ち、数値等の参照を切ります。
//
// 引数: value(*T)は値型参照。返り値: *Tは独立した写しです。
func copyPtr[T any](value *T) *T {
	if value == nil {
		return nil
	}
	return ptr(*value)
}

// copyEntry は取得時のATRと任意支持を私有化します。
//
// 引数: e(Entry)は実取得。返り値: Entryは可変参照を共有しません。
func copyEntry(e Entry) Entry {
	e.ATR = copyPtr(e.ATR)
	e.EntrySupport = copyPtr(e.EntrySupport)
	return e
}

// copyPublication は公表の数値参照とBBを私有化します。
//
// 引数: p(*Publication)は旧3分公表。返り値: *Publicationは未知を保つ独立値です。
func copyPublication(p *Publication) *Publication {
	if p == nil {
		return nil
	}
	out := *p
	out.V = copyPtr(p.V)
	out.Close = copyPtr(p.Close)
	out.PriorPivot = copyPtr(p.PriorPivot)
	if p.BB != nil {
		b := *p.BB
		b.SMA = copyPtr(b.SMA)
		b.Sigma = copyPtr(b.Sigma)
		b.Upper = copyPtr(b.Upper)
		b.Lower = copyPtr(b.Lower)
		b.Width = copyPtr(b.Width)
		b.BandWidth = copyPtr(b.BandWidth)
		b.PercentB = copyPtr(b.PercentB)
		out.BB = &b
	}
	return &out
}

// copyNarrow は短期完成証拠の任意JSONをbytesのまま独立させます。
//
// 引数: n(*NarrowInput)は完成票。返り値: *NarrowInputは意味を変更しない写しです。
func copyNarrow(n *NarrowInput) *NarrowInput {
	if n == nil {
		return nil
	}
	out := *n
	out.Witness = append(out.Witness[:0:0], n.Witness...)
	return &out
}

// copySnapshot は公開Snapshotの全可変参照を分離します。
//
// 引数: v(Snapshot)は私有状態。返り値: Snapshotは呼出元から変更可能な独立値です。
func copySnapshot(v Snapshot) Snapshot {
	v.Entry = copyEntry(v.Entry)
	v.ActivatedAt = copyPtr(v.ActivatedAt)
	v.NarrowedAt = copyPtr(v.NarrowedAt)
	v.PeakPoints = copyPtr(v.PeakPoints)
	v.FloorPoints = copyPtr(v.FloorPoints)
	v.Latest = copyPublication(v.Latest)
	v.EntryInvalidatedAt = copyPtr(v.EntryInvalidatedAt)
	if v.EntryInvalidationWitness != nil {
		w := *v.EntryInvalidationWitness
		w.Publication = *copyPublication(&w.Publication)
		v.EntryInvalidationWitness = &w
	}
	if v.H0 != nil {
		h := *v.H0
		h.WholeTargetHalfYen = copyPtr(h.WholeTargetHalfYen)
		h.ZeroTargetAt = copyPtr(h.ZeroTargetAt)
		h.Narrow = copyNarrow(h.Narrow)
		h.NarrowAppliedAt = copyPtr(h.NarrowAppliedAt)
		v.H0 = &h
	}
	return v
}

// legacyInput は追加欄を旧部品へ流さず従来の入力だけを返します。
//
// 引数: in(Input)は117入力。返り値: legacy.Inputは旧九項目の同値です。
func legacyInput(in Input) legacy.Input {
	return legacy.Input{At: in.At, Sequence: in.Sequence, Phase: in.Phase, Mark: in.Mark, Remaining: in.Remaining, Reserved: in.Reserved, ClosedNetYen: in.ClosedNetYen, Publication: in.Publication, ResetReason: in.ResetReason}
}
