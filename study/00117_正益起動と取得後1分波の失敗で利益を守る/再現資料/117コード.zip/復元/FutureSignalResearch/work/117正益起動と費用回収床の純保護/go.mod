module github.com/masayoshi4649/SessionTradeExecuter/profitfloor117

go 1.24.2

require (
 github.com/masayoshi4649/SessionTradeExecuter/profitfloor113 v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/profitfloor111 v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/profitfloor112fast v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/profitfloor112 v0.0.0
)

replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor113 => ../113起動前の支持否定と利益保護の純演算
replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor111 => ../111全玉利益と収束BBの純保護
replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor112fast => ../112純状態コピー高速化の試作
replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor112 => ../112支持否定の必須確認と通常幅のみ
