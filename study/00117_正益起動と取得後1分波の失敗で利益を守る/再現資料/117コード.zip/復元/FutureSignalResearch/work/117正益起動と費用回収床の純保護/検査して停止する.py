"""117純保護の人工・実依存を検査し、Rootレビュー後だけ停止する。"""
from datetime import datetime, timezone
from pathlib import Path
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OWNED = ("types.go", "state.go", "copy.go", "state_test.go", "cmd/definition/main.go",
         "go.mod", "README.md", "API案.md", Path(__file__).name)
PRIOR = ROOT / "work/113起動前の支持否定と利益保護の純演算/停止.json"
PRIOR_SHA = "81f54d965ef8d81c65a7b58f4d376374b79c765e1ad4ada5cc6270159e4ed312"
CODE_FIELDS = ("所有コードSHA256", "再用コードSHA256", "実Go依存SHA256", "全固定コードSHA256",
               "所有ファイルSHA256", "コードSHA256前", "実Go依存コードSHA256")


def digest(path: Path) -> str:
    """
    機能: 明示されたコード又は人工の全bytes指紋を計算する。
    引数: path(Path)は対象。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ref(path: Path) -> dict:
    """
    機能: 明示ファイルを絶対Refにする。
    引数: path(Path)は実在ファイル。返り値: dictはpath/sha256。
    """
    return {"path": str(path.resolve()), "sha256": digest(path)}


def run(command: list[str], env: dict) -> dict:
    """
    機能: Go依存・人工・API・定義・vet/buildだけを実行する。
    引数: command(list[str])/env(dict)は引数と環境。返り値: dictは成功ログ。
    """
    done = subprocess.run(command, cwd=HERE, env=env, capture_output=True,
                          encoding="utf-8", text=True, timeout=60)
    value = {"command": command, "exit_code": done.returncode,
             "stdout": done.stdout, "stderr": done.stderr}
    if done.returncode:
        raise ValueError(json.dumps(value, ensure_ascii=False))
    return value


def generated_testmain(package: dict, cache: Path) -> list[dict]:
    """
    機能: 主moduleのGo自動testmain一件だけを生成環境参照へ分離する。
    引数: package(dict)/cache(Path)はgo listとGo自身のcache位置。
    返り値: list[dict]はSHA/由来/再生成を残す生成参照。実ソースなら空。
    """
    if package.get("Name") != "main" or not package.get("ImportPath", "").endswith(".test"):
        return []
    module = package.get("Module") or {}
    files = package.get("GoFiles", [])
    if (module.get("Main") is not True or package["ImportPath"] != module.get("Path", "") + ".test"
            or Path(package["Dir"]).resolve() != HERE or len(files) != 1
            or any(package.get(field) for field in ("CgoFiles", "SFiles", "HFiles", "SysoFiles", "EmbedFiles"))):
        raise ValueError("Go自動testmainの識別・主module・構成差")
    source = Path(files[0])
    if not source.is_absolute():
        raise ValueError("識別した生成mainの位置が絶対pathではない")
    source = source.resolve()
    if not source.is_relative_to(cache) or not re.fullmatch(r"[0-9a-f]{64}-d", source.name):
        raise ValueError("識別した生成mainがGo生成位置ではない")
    return [{**ref(source), "kind": "Go自動testmain", "package": package["ImportPath"],
             "由来": "go list -deps -testの主module生成main一件。実test本体とは別",
             "再生成": ["go", "test", "-count=1", module["Path"]],
             "金融固定コード": False, "正式復元対象": False}]


def closure(env: dict) -> tuple[dict, list[dict]]:
    """
    機能: 実Goソース・人工ソース・Go実行物と生成mainを区別して認証する。
    引数: env(dict)は固定環境。返り値: tuple[dict,list[dict]]は固定mapと生成参照。
    """
    raw = run(["go", "list", "-deps", "-test", "-json", "./..."], env)["stdout"]
    cache = Path(run(["go", "env", "GOCACHE"], env)["stdout"].strip()).resolve()
    decoder, position, paths, generated = json.JSONDecoder(), 0, set(), []
    while raw[position:].strip():
        position += len(raw[position:]) - len(raw[position:].lstrip())
        package, position = decoder.raw_decode(raw, position)
        classified = generated_testmain(package, cache)
        if classified:
            generated.extend(classified)
            continue
        folder = Path(package["Dir"])
        for field in ("GoFiles", "CgoFiles", "SFiles", "HFiles", "SysoFiles", "EmbedFiles"):
            for name in package.get(field, []):
                source = (folder / name).resolve()
                if source.is_relative_to(cache):
                    raise ValueError("自動testmainと識別されないcache入力:" + str(source))
                paths.add(source)
        module = package.get("Module") or {}
        for item in (module, module.get("Replace") or {}):
            if item.get("GoMod"):
                paths.add(Path(item["GoMod"]).resolve())
    paths.add(Path(shutil.which("go")).resolve())
    return {str(p): digest(p) for p in sorted(paths, key=str)}, generated


def prior_before() -> dict:
    """
    機能: 固定113停止とその明示コードmapを市場読取なしで認証する。
    引数: なし。返り値: dictは旧停止とコードの前指紋。
    """
    if digest(PRIOR) != PRIOR_SHA:
        raise ValueError("旧113停止SHA差")
    old = json.loads(PRIOR.read_text(encoding="utf-8-sig"))
    if any(old.get(key) is not True for key in ("成功", "停止", "市場前")):
        raise ValueError("旧113市場前停止が不正")
    before = {str(PRIOR.resolve()): PRIOR_SHA}
    for field in CODE_FIELDS:
        for source, expected in old.get(field, {}).items():
            p = Path(source)
            p = (p if p.is_absolute() else ROOT / p).resolve()
            if digest(p) != expected:
                raise ValueError("旧固定コードの現物差:" + str(p))
            if str(p) in before and before[str(p)] != expected:
                raise ValueError("同pathの指紋衝突")
            before[str(p)] = expected
    return before


def write_new(path: Path, value: dict) -> None:
    """
    機能: 未作成先だけへ日本語UTF-8/LFのJSONを保存する。
    引数: path(Path)/value(dict)は保存先と値。返り値: None。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def main() -> None:
    """
    機能: 人工検査の証拠だけ、又はRootレビュー後の純停止を新規保存する。
    引数: CLI --proof-only又は--reviewed、--outputは未作成先。返り値: None。
    """
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--proof-only", action="store_true")
    mode.add_argument("--reviewed", action="store_true")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    target, output = HERE / "停止.json", args.output.resolve()
    if output.exists() or (args.reviewed and target.exists()):
        raise ValueError("検査先/停止先は未作成だけを許可")
    env = dict(os.environ, CGO_ENABLED="0", GOWORK="off", GOTOOLCHAIN="local")
    version = run(["go", "version"], env)["stdout"].strip()
    if version != "go version go1.24.2 windows/amd64":
        raise ValueError("Go1.24.2 windows/amd64だけを認証")
    before = prior_before()
    owned = {str((HERE / name).resolve()): digest(HERE / name) for name in OWNED}
    compiled, generated = closure(env)
    fixed = dict(before)
    for values in (owned, compiled):
        for source, expected in values.items():
            if source in fixed and fixed[source] != expected:
                raise ValueError("固定mapの同path指紋衝突")
            fixed[source] = expected
    output.mkdir(parents=True)
    art = output / "人工系列.json"
    logs = [run(["go", "test", "-count=1", "-json", "./..."],
                dict(env, PROFITFLOOR117_ART_OUT=str(art))),
            run(["go", "vet", "./..."], env), run(["go", "build", "./..."], env),
            run(["go", "run", "./cmd/definition"], env), run(["go", "doc", "-all", "."], env)]
    events = [json.loads(row) for row in logs[0]["stdout"].splitlines() if row.startswith("{")]
    passed = [v["Test"] for v in events if v.get("Action") == "pass" and "Test" in v and "/" not in v["Test"]]
    if len(passed) != 12 or "TestExportArtificial" not in passed:
        raise ValueError("11主人工とexport一件が不足")
    definition = json.loads(logs[3]["stdout"])
    if (definition["version"] != 117 or definition["policies"] != ["S0", "W100", "P100", "H0E", "H0M"]
            or len(definition["configurations"]) != 20):
        raise ValueError("五政策20条件の実定義差")
    series = json.loads(art.read_text(encoding="utf-8"))
    if len(series["series"]) != 8 or sum(len(v["steps"]) for v in series["series"]) != 64:
        raise ValueError("8系列64Advance差")
    write_new(output / "実定義.json", definition)
    with (output / "API.txt").open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(logs[4]["stdout"])
    after = {source: digest(Path(source)) for source in fixed}
    if fixed != after:
        raise ValueError("所有/依存/旧コードの前後差")
    if any(digest(Path(item["path"])) != item["sha256"] for item in generated):
        raise ValueError("生成環境参照の前後SHA差")
    value = {"試行": 117, "trial": 117, "成功": True, "停止": args.reviewed,
             "市場前": True, "UTC": datetime.now(timezone.utc).isoformat(),
             "module": "github.com/masayoshi4649/SessionTradeExecuter/profitfloor117",
             "所有コードSHA256": owned, "再用コードSHA256": before,
             "実Go依存SHA256": compiled, "全固定コードSHA256": fixed,
             "コードSHA256前": fixed, "コードSHA256後": after, "前後不変": True,
             "生成環境参照": generated, "生成環境参照前後不変": True,
             "依存停止": {"pure113": ref(PRIOR)}, "旧純停止": ref(PRIOR),
             "主人工": 11, "export人工": 1, "成功test": passed,
             "実定義": ref(output / "実定義.json"), "実API": ref(output / "API.txt"),
             "Go人工": ref(art), "人工系列数": 8, "人工評価数": 64,
             "Go版": version, "検査ログ": logs, "Rootレビュー後": args.reviewed,
             "市場/Raw/Native/価格CSV/損益CSV/11月09本文読取": 0,
             "金融市場実行": False, "旧113/Source/Chart/Actor変更": False}
    result = target if args.reviewed else output / "接続前の確認.json"
    write_new(result, value)
    print(json.dumps({"成功": True, "停止": args.reviewed, "確認": ref(result),
                      "実定義": value["実定義"], "Go人工": value["Go人工"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
