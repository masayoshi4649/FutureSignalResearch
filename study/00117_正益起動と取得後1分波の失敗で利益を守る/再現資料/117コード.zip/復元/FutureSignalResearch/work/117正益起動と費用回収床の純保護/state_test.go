package profitfloor117

import (
	"bytes"
	"encoding/json"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	legacy "github.com/masayoshi4649/SessionTradeExecuter/profitfloor113"
)

// testEntry は市場を使わず実取得条件を手製します。
//
// 引数: p(Policy)/side(int)/slip(float64)/q(int)は政策・方向・費用・初枚数。返り値: Entryは人工取得です。
func testEntry(p Policy, side int, slip float64, q int) Entry {
	return Entry{Scope: Scope{Session: "人工場", Contract: "人工限月", Start: 0}, Policy: p, Side: side, Price: 1000, At: 10, InitialQuantity: q, SlipPoints: slip}
}

// mustState は人工取得の正常な初期化を要求します。
//
// 引数: t(*testing.T)/e(Entry)は検査器と取得。返り値: Stateは正常な純状態です。
func mustState(t *testing.T, e Entry) State {
	t.Helper()
	s, err := NewState(e)
	if err != nil {
		t.Fatal(err)
	}
	return s
}

// testInput は順行幅から正常Markを作り原行を付けます。
//
// 引数: e(Entry)/seq(uint64)/gain(float64)/n/r(int)/R(float64)/phase(Phase)は人工入力。返り値: Inputは旧API互換の値です。
func testInput(e Entry, seq uint64, gain float64, n, r int, R float64, phase Phase) Input {
	mark := e.Price + float64(e.Side)*gain
	return Input{At: 10 + float64(seq), Sequence: seq, SourceIndex: int64(seq), Phase: phase, Mark: &mark, Remaining: n, Reserved: r, ClosedNetYen: R}
}

// mustAdvance は人工入力の正常な前進だけを返します。
//
// 引数: t(*testing.T)/s(State)/in(Input)は検査器・前状態・入力。返り値: State/Decisionは正常結果です。
func mustAdvance(t *testing.T, s State, in Input) (State, Decision) {
	t.Helper()
	next, d, err := Advance(s, in)
	if err != nil {
		t.Fatal(err)
	}
	return next, d
}

// jsonBytes は型の公開JSONを比較可能なbytesへ写します。
//
// 引数: t(*testing.T)/v(any)は検査器と公開値。返り値: []byteはJSONです。
func jsonBytes(t *testing.T, v any) []byte {
	t.Helper()
	b, err := json.Marshal(v)
	if err != nil {
		t.Fatal(err)
	}
	return b
}

// expectFloor は床と全玉目標の具体的な円額を確認します。
//
// 引数: t(*testing.T)/s(State)/f/L(float64)は検査器・状態・期待床/円額。返り値: なし。
func expectFloor(t *testing.T, s State, f, L float64) {
	t.Helper()
	v := s.Snapshot()
	if v.FloorPoints == nil || *v.FloorPoints != f || v.WholeTargetYen != L {
		t.Fatalf("床/目標差: %+v、期待f=%v L=%v", v, f, L)
	}
}

// TestLegacyDelegation は旧二政策の全公開JSONとS0拒否を直接旧113へ照合します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestLegacyDelegation(t *testing.T) {
	for _, p := range []Policy{W100, P100} {
		for _, side := range []int{1, -1} {
			for _, slip := range []float64{0, 5} {
				e := testEntry(p, side, slip, 2)
				s := mustState(t, e)
				old, err := legacy.NewState(e)
				if err != nil {
					t.Fatal(err)
				}
				if !bytes.Equal(jsonBytes(t, s.Snapshot()), jsonBytes(t, old.Snapshot())) {
					t.Fatal("旧初期JSON差")
				}
				for i, g := range []float64{0, 120, 300, 100, 0} {
					in := testInput(e, uint64(i+1), g, 2, 0, 0, AfterSource)
					ns, d := mustAdvance(t, s, in)
					no, od, err := legacy.Advance(old, legacyInput(in))
					if err != nil {
						t.Fatal(err)
					}
					if !bytes.Equal(jsonBytes(t, ns.Snapshot()), jsonBytes(t, no.Snapshot())) || !bytes.Equal(jsonBytes(t, d), jsonBytes(t, od)) {
						t.Fatal("旧全値JSON差")
					}
					s, old = ns, no
				}
			}
		}
	}
	_, a := NewState(testEntry(S0, 1, 0, 1))
	_, b := legacy.NewState(testEntry(S0, 1, 0, 1))
	if a == nil || b == nil || a.Error() != b.Error() {
		t.Fatal("S0拒否差")
	}
	if len(DeclaredConfigurations()) != 20 || len(DeclaredDefinitions()) != 5 {
		t.Fatal("宣言件数差")
	}
}

// TestLegacyPublicationDelegation は旧狭幅・構造床・reset・部分返済も全JSON同体に保ちます。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestLegacyPublicationDelegation(t *testing.T) {
	for _, p := range []Policy{W100, P100} {
		for _, side := range []int{1, -1} {
			for _, c := range []float64{0, 5} {
				e := testEntry(p, side, c, 2)
				e.ATR = &Evidence{ID: "旧取得ATR", Value: 115, AvailableAt: 10}
				s := mustState(t, e)
				old, err := legacy.NewState(e)
				if err != nil {
					t.Fatal(err)
				}
				kind := "low"
				if side < 0 {
					kind = "high"
				}
				pub := &Publication{Scope: e.Scope, ID: "旧公表1", Ordinal: 2, Start: 180, End: 360, AvailableAt: 420, C: True, M: True, V: ptr(10.0), Close: ptr(1000.0 + float64(side)*90), PriorPivot: &Pivot{Scope: e.Scope, ID: "旧支持", Kind: kind, Price: 1000 + float64(side)*100, CenterStart: 180, CenterEnd: 360, ConfirmEnd: 360, PublishedAt: 420}}
				for j := 0; j < 4; j++ {
					in := testInput(e, uint64(j+1), 120, 2, 0, 0, AfterSource)
					in.At = 420 + float64(j)
					in.Publication = pub
					if j == 1 {
						in.Reserved = 2
					}
					if j == 2 {
						in.Publication = nil
						in.ResetReason = "人工欠足"
						in.Mark = nil
					}
					if j == 3 {
						in.Publication = nil
						in.Remaining = 1
						in.ClosedNetYen = -2077 - 200*c
					}
					next, d := mustAdvance(t, s, in)
					prior, dd, err := legacy.Advance(old, legacyInput(in))
					if err != nil {
						t.Fatal(err)
					}
					if !bytes.Equal(jsonBytes(t, next.Snapshot()), jsonBytes(t, prior.Snapshot())) || !bytes.Equal(jsonBytes(t, d), jsonBytes(t, dd)) {
						t.Fatal("旧公表・狭幅・reset・部分返済JSON差")
					}
					s, old = next, prior
				}
			}
		}
	}
}

// TestStrictActivationAndNoPeakPromotion は初小益・等号・同峰での費用回収を分けます。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestStrictActivationAndNoPeakPromotion(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, c := range []float64{0, 5} {
			e := testEntry(H0E, side, c, 2)
			s := mustState(t, e)
			g := 5.0 + 2*c
			z := testInput(e, 1, g-5, 2, 0, 0, PreFill)
			s, d := mustAdvance(t, s, z)
			if s.Snapshot().Active || d.ActivatedNow {
				t.Fatal("非正益起動")
			}
			s, d = mustAdvance(t, s, testInput(e, 2, g, 2, 0, 0, PreFill))
			if !d.ActivatedNow || d.FloorHit || d.H0.ZeroTargetAdoptedNow {
				t.Fatal("初小益と即床の混同")
			}
			expectFloor(t, s, 0, -2*(77+200*c))
			s, d = mustAdvance(t, s, testInput(e, 3, g, 2, 0, 0, AfterSource))
			if d.ActivatedNow || d.H0.ZeroTargetAdoptedNow {
				t.Fatal("同原峰の不要更新")
			}
			s, d = mustAdvance(t, s, testInput(e, 4, g, 1, 0, 423, AfterSource))
			if !d.H0.ZeroTargetAdoptedNow || *s.Snapshot().PeakPoints != g {
				t.Fatal("部分返済後の同峰昇格を拒否")
			}
			expectFloor(t, s, 2*c, 346)
		}
	}
	// 既返済が負の半円で、残gain5ならWが厳密0。次の半円正益だけで起動する。
	e := testEntry(H0E, 1, 0, 2)
	s := mustState(t, e)
	s, d := mustAdvance(t, s, testInput(e, 1, 5, 1, 0, -423, AfterSource))
	if s.Snapshot().Active || *d.WholeNetYen != 0 {
		t.Fatal("W等号起動")
	}
	e2 := testEntry(H0E, 1, 0, 2)
	s2 := mustState(t, e2)
	s2, d = mustAdvance(t, s2, testInput(e2, 1, 5, 1, 0, -422.5, AfterSource))
	if !s2.Snapshot().Active || *d.WholeNetYen != 0.5 {
		t.Fatal("半円正益未起動")
	}
}

// TestFirstJumpPromotion は初回に一呼値余地があれば新峰条件なしで昇格します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestFirstJumpPromotion(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, c := range []float64{0, 5} {
			e := testEntry(H0E, side, c, 1)
			s, d := mustAdvance(t, mustState(t, e), testInput(e, 1, 10+2*c, 1, 0, 0, PreFill))
			if !d.ActivatedNow || !d.H0.ZeroTargetAdoptedNow || d.FloorHit {
				t.Fatal("初回余地昇格差")
			}
			expectFloor(t, s, 5+2*c, 423)
		}
	}
}

// TestPartialTargetsAndUnknown は負返済と半円Rでも既存L/fを緩めません。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestPartialTargetsAndUnknown(t *testing.T) {
	for _, side := range []int{1, -1} {
		e := testEntry(H0E, side, 0, 3)
		s, _ := mustAdvance(t, mustState(t, e), testInput(e, 1, 10, 3, 0, 0, PreFill))
		expectFloor(t, s, 5, 1269)
		in := testInput(e, 2, 0, 2, 0, -2077, AfterSource)
		in.Mark = nil
		s, d := mustAdvance(t, s, in)
		expectFloor(t, s, 20, 1769)
		if d.FloorHit || d.EligibleExitQuantity != 0 {
			t.Fatal("未知価格の架空hit")
		}
		in = testInput(e, 3, 0, 1, 0, -5000.5, AfterSource)
		in.Mark = nil
		s, _ = mustAdvance(t, s, in)
		expectFloor(t, s, 70, 1922.5)
		s, d = mustAdvance(t, s, testInput(e, 4, 5, 1, 0, -5000.5, AfterSource))
		if !d.FloorHit || d.EligibleExitQuantity != 1 {
			t.Fatal("既存床割れ未要求")
		}
		expectFloor(t, s, 70, 1922.5)
	}
}

// TestFWCeiling は負数・半円境界の数学的ceilを具体値で確認します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestFWCeiling(t *testing.T) {
	for _, x := range []struct {
		L, R int64
		n    int
		want float64
	}{{0, 0, 1, 5}, {0, 4000, 1, -15}, {846, 0, 1, 5}, {845, 0, 1, 5}, {847, 0, 1, 10}, {-308, 0, 2, 0}} {
		if got := wholeFloor(x.L, x.R, 154, x.n); got != x.want {
			t.Fatalf("FW差 %+v got %v", x, got)
		}
	}
}

// TestPhaseReservationAndZero は起動・hit・要求・終了を別に扱います。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestPhaseReservationAndZero(t *testing.T) {
	e := testEntry(H0E, 1, 0, 2)
	s, _ := mustAdvance(t, mustState(t, e), testInput(e, 1, 5, 2, 0, 0, PreFill))
	in := testInput(e, 2, 0, 2, 1, 0, PreFill)
	in.At = 11
	in.SourceIndex = 1
	s, d := mustAdvance(t, s, in)
	if !d.FloorHit || d.EligibleExitQuantity != 0 {
		t.Fatal("pre_fillの返済要求")
	}
	in.Sequence = 3
	in.Phase = AfterSource
	s, d = mustAdvance(t, s, in)
	if d.EligibleExitQuantity != 1 {
		t.Fatal("未予約量差")
	}
	in.Sequence = 4
	in.Reserved = 2
	s, d = mustAdvance(t, s, in)
	if !d.AllReservedHit || d.EligibleExitQuantity != 0 {
		t.Fatal("全予約量差")
	}
	in.Sequence = 5
	in.Remaining = 0
	in.Reserved = 0
	in.ClosedNetYen = -154
	s, d = mustAdvance(t, s, in)
	if !s.Snapshot().Finished || d.ActivatedNow || d.FloorHit {
		t.Fatal("n0再判定")
	}
	e = testEntry(H0E, 1, 0, 1)
	s = mustState(t, e)
	in = testInput(e, 1, 200, 0, 0, 19923, AfterSource)
	s, d = mustAdvance(t, s, in)
	if s.Snapshot().Active || d.ActivatedNow {
		t.Fatal("全返済後の正実現だけで起動")
	}
}

// testNarrow は短期警戒を計算せず完成票だけを手製します。
//
// 引数: e(Entry)/in(Input)/width(float64)は取得・当入力・完成幅。返り値: *NarrowInputは人工完成票です。
func testNarrow(e Entry, in Input, width float64) *NarrowInput {
	return &NarrowInput{Scope: e.Scope, ID: "人工完成", At: in.At, SourceIndex: in.SourceIndex, SourceLine: in.SourceIndex + 1, WidthPoints: width, Completed: true, Witness: json.RawMessage(`{"人工":true}`)}
}

// TestNarrowWaitAndImmutable は異常BBO時ラッチと正常価格時適用を分けます。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestNarrowWaitAndImmutable(t *testing.T) {
	for _, side := range []int{1, -1} {
		e := testEntry(H0M, side, 0, 2)
		s, _ := mustAdvance(t, mustState(t, e), testInput(e, 1, 50, 2, 0, 0, PreFill))
		in := testInput(e, 2, 0, 2, 0, 0, AfterSource)
		in.Mark = nil
		in.Narrow = testNarrow(e, in, 20)
		s, d := mustAdvance(t, s, in)
		if d.NarrowedNow || s.Snapshot().Narrowed || !d.H0.NarrowLatchedNow || s.Snapshot().H0.NarrowApplied || s.Snapshot().WidthPoints != 200 {
			t.Fatal("異常価格で幅適用")
		}
		n := copyNarrow(in.Narrow)
		in = testInput(e, 3, 50, 2, 0, 0, AfterSource)
		in.Narrow = n
		s, d = mustAdvance(t, s, in)
		if !d.NarrowedNow || !d.H0.NarrowAppliedNow || d.H0.NarrowLatchedNow {
			t.Fatal("再送/適用差")
		}
		expectFloor(t, s, 30, 5846)
		in = testInput(e, 4, 25, 2, 0, 0, AfterSource)
		in.Narrow = n
		s, d = mustAdvance(t, s, in)
		if !d.FloorHit || d.EligibleExitQuantity != 2 || d.H0.NarrowAppliedNow {
			t.Fatal("狭幅ラッチ持続差")
		}
		before := jsonBytes(t, s.Snapshot())
		n.WidthPoints = 25
		in = testInput(e, 5, 25, 2, 0, 0, AfterSource)
		in.Narrow = n
		if _, _, err := Advance(s, in); err == nil || !bytes.Equal(before, jsonBytes(t, s.Snapshot())) {
			t.Fatal("同ID完成票改竄を受理")
		}
	}
}

// TestNarrowRejections は未来・別場・不正幅・偽完成・別票を拒否します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestNarrowRejections(t *testing.T) {
	e := testEntry(H0M, 1, 0, 1)
	s, _ := mustAdvance(t, mustState(t, e), testInput(e, 1, 10, 1, 0, 0, PreFill))
	in := testInput(e, 2, 10, 1, 0, 0, AfterSource)
	changes := []func(*NarrowInput){func(n *NarrowInput) { n.At = in.At + 1 }, func(n *NarrowInput) { n.SourceIndex = in.SourceIndex + 1 }, func(n *NarrowInput) { n.Scope.Session = "別場" }, func(n *NarrowInput) { n.WidthPoints = 12 }, func(n *NarrowInput) { n.WidthPoints = math.NaN() }, func(n *NarrowInput) { n.SourceLine = 0 }, func(n *NarrowInput) { n.Completed = false }, func(n *NarrowInput) { n.Witness = json.RawMessage("{") }}
	for i, change := range changes {
		bad := in
		bad.Narrow = testNarrow(e, in, 20)
		change(bad.Narrow)
		if _, _, err := Advance(s, bad); err == nil {
			t.Fatalf("不正完成票受理 %d", i)
		}
	}
	e.Policy = H0E
	s = mustState(t, e)
	in.Narrow = testNarrow(e, in, 20)
	if _, _, err := Advance(s, in); err == nil {
		t.Fatal("H0Eへの技術狭幅")
	}
}

// TestATRAndDiagnosticOnly は取得時ATR固定と旧3分票の診断限定を確認します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestATRAndDiagnosticOnly(t *testing.T) {
	e := testEntry(H0E, 1, 0, 1)
	e.ATR = &Evidence{ID: "元ATR12", Value: 102.5, AvailableAt: 10}
	s := mustState(t, e)
	if s.Snapshot().NormalWidth != 205 || s.Snapshot().ATRUnknownFallback {
		t.Fatal("取得ATR通常幅差")
	}
	e.ATR.Value = 10000
	if s.Snapshot().NormalWidth != 205 || s.Snapshot().Entry.ATR.Value != 102.5 {
		t.Fatal("ATR外部参照")
	}
	in := testInput(e, 1, 50, 1, 0, 0, AfterSource)
	in.At = 420
	in.Publication = &Publication{Scope: e.Scope, ID: "旧3分", Ordinal: 2, Start: 180, End: 360, AvailableAt: 420, C: True, M: True, V: ptr(10.0), Close: ptr(1020.0), PriorPivot: &Pivot{Scope: e.Scope, ID: "旧pivot", Kind: "low", Price: 1030, CenterStart: 180, CenterEnd: 360, ConfirmEnd: 360, PublishedAt: 420}}
	s, d := mustAdvance(t, s, in)
	if d.C != True || d.M != True || d.P != True || d.Warning != Unknown || d.NarrowedNow || d.StructuralFloor != nil || s.Snapshot().WidthPoints != 205 {
		t.Fatal("旧票をH0判断へ使用")
	}
	expectFloor(t, s, 5, 423)
	in.Publication.PriorPivot.Price = 9999
	if s.Snapshot().Latest.PriorPivot.Price != 1030 {
		t.Fatal("公表参照共有")
	}
	v := s.Snapshot()
	v.Latest.PriorPivot.Price = 1
	*v.FloorPoints = 999
	v.Entry.ATR.Value = 1
	if s.Snapshot().Latest.PriorPivot.Price != 1030 || *s.Snapshot().FloorPoints != 5 || s.Snapshot().Entry.ATR.Value != 102.5 {
		t.Fatal("Snapshot参照共有")
	}
}

// TestValidationAndNoMutation は時計後退・不正会計・未来ATRを状態変更前に拒否します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。
func TestValidationAndNoMutation(t *testing.T) {
	e := testEntry(H0E, 1, 0, 2)
	s, _ := mustAdvance(t, mustState(t, e), testInput(e, 1, 5, 2, 0, 0, PreFill))
	base := testInput(e, 2, 5, 2, 0, 0, AfterSource)
	bad := []Input{base, base, base, base, base, base, base}
	bad[0].At = 10
	bad[1].SourceIndex = 0
	bad[2].Remaining = 3
	bad[3].ClosedNetYen = .25
	bad[4].ClosedNetYen = .5
	bad[5].Phase = "別位相"
	bad[6].Mark = ptr(math.Inf(1))
	before := jsonBytes(t, s.Snapshot())
	for i, in := range bad {
		if _, _, err := Advance(s, in); err == nil || !bytes.Equal(before, jsonBytes(t, s.Snapshot())) {
			t.Fatalf("拒否又は不変性差 %d", i)
		}
	}
	e.ATR = &Evidence{ID: "未来", Value: 1, AvailableAt: 11}
	if _, err := NewState(e); err == nil {
		t.Fatal("未来ATR受理")
	}
	if _, _, err := Advance(State{}, base); err == nil {
		t.Fatal("未初期化受理")
	}
}

type artificialStep struct {
	Before   Snapshot `json:"before"`
	Input    Input    `json:"input"`
	After    Snapshot `json:"after"`
	Decision Decision `json:"decision"`
}
type artificialSeries struct {
	Name    string           `json:"name"`
	Entry   Entry            `json:"entry"`
	Initial Snapshot         `json:"initial"`
	Steps   []artificialStep `json:"steps"`
}

// TestExportArtificial は同じ手製系列を独立言語検算用へ任意の新規先だけに出します。
//
// 引数: t(*testing.T)は検査器。返り値: なし。PROFITFLOOR117_ART_OUT未設定時はファイルを作りません。
func TestExportArtificial(t *testing.T) {
	out := struct {
		Version        int                `json:"version"`
		Trial          int                `json:"trial"`
		Artificial     bool               `json:"artificial"`
		Definitions    []Definition       `json:"definitions"`
		H0Definitions  []H0Definition     `json:"h0_definitions"`
		Configurations []Configuration    `json:"configurations"`
		Series         []artificialSeries `json:"series"`
	}{Version: 1, Trial: 117, Artificial: true, Definitions: DeclaredDefinitions(), Configurations: DeclaredConfigurations()}
	for _, p := range []Policy{H0E, H0M} {
		def, _ := H0DefinitionFor(p)
		out.H0Definitions = append(out.H0Definitions, def)
		for _, side := range []int{1, -1} {
			for _, c := range []float64{0, 5} {
				e := testEntry(p, side, c, 3)
				s := mustState(t, e)
				a := artificialSeries{Name: string(p) + "/" + string(rune('1'+side)) + "/" + string(rune('0'+int(c))), Entry: e, Initial: s.Snapshot()}
				var narrow *NarrowInput
				for j, g := range []float64{5 + 2*c, 10 + 2*c, 50 + 2*c, 0, 50 + 2*c, 25 + 2*c, 0, 0} {
					seq := uint64(j + 1)
					in := testInput(e, seq, g, 3, 0, 0, AfterSource)
					if j == 3 {
						in.Mark = nil
					}
					if p == H0M && j >= 3 {
						if narrow == nil {
							narrow = testNarrow(e, in, 20)
						}
						in.Narrow = copyNarrow(narrow)
					}
					if j == 5 {
						in.Remaining = 2
						in.ClosedNetYen = -1000.5
					}
					if j == 6 {
						in.Remaining = 2
						in.Reserved = 2
						in.ClosedNetYen = -1000.5
					}
					if j == 7 {
						in.Remaining = 0
						in.ClosedNetYen = -5000.5
						in.Narrow = nil
					}
					before := s.Snapshot()
					next, d := mustAdvance(t, s, in)
					a.Steps = append(a.Steps, artificialStep{Before: before, Input: in, After: next.Snapshot(), Decision: d})
					s = next
				}
				out.Series = append(out.Series, a)
			}
		}
	}
	if len(out.Series) != 8 {
		t.Fatal("人工系列数差")
	}
	if !reflect.DeepEqual(out.Configurations, DeclaredConfigurations()) {
		t.Fatal("宣言順差")
	}
	if path := os.Getenv("PROFITFLOOR117_ART_OUT"); path != "" {
		b, err := json.MarshalIndent(out, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		if err = os.MkdirAll(filepath.Dir(path), 0755); err != nil {
			t.Fatal(err)
		}
		f, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
		if err != nil {
			t.Fatal(err)
		}
		if _, err = f.Write(append(b, '\n')); err != nil {
			f.Close()
			t.Fatal(err)
		}
		if err = f.Close(); err != nil {
			t.Fatal(err)
		}
	}
}
