package profitfloor117

import (
	"encoding/json"
	"fmt"
	"math"
	"reflect"

	legacy "github.com/masayoshi4649/SessionTradeExecuter/profitfloor113"
)

// finite は数値がすべて有限か確認します。
//
// 引数: values(...float64)は数値。返り値: boolは全件有限なら真です。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// half は円を半円整数へ厳密変換します。
//
// 引数: yen(float64)は円額。返り値: int64/errorは半円額又は拒否です。
func half(yen float64) (int64, error) {
	if !finite(yen) || math.Abs(yen) > 1e12 || yen*2 != math.Trunc(yen*2) {
		return 0, fmt.Errorf("金額は有限な半円単位が必要")
	}
	return int64(yen * 2), nil
}

// ceilDiv は負数でも数学的切上げを計算します。
//
// 引数: a/b(int64)は分子/正分母。返り値: int64はceil(a/b)です。
func ceilDiv(a, b int64) int64 {
	q, r := a/b, a%b
	if r > 0 {
		q++
	}
	return q
}

// wholeFloor は全玉目標を守る価格幅を半円整数から5pt刻みで返します。
//
// 引数: target/realized/cost(int64)は半円額、n(int)は正の残枚数。返り値: float64は数学的ceil5床です。
func wholeFloor(target, realized, cost int64, n int) float64 {
	return float64(5 * ceilDiv(int64(n)*cost+target-realized, int64(1000*n)))
}

// NewState は旧三政策へ委譲し、H0だけを未起動・全玉目標未設定で作ります。
//
// 引数: e(Entry)は実新規約定。返り値: State/errorは純状態又は不正です。旧S0の拒否も旧113と同じです。
func NewState(e Entry) (State, error) {
	d, err := DefinitionFor(e.Policy)
	if err != nil {
		return State{}, err
	}
	if e.Policy == S0 || e.Policy == W100 || e.Policy == P100 {
		p, err := legacy.NewState(e)
		if err != nil {
			return State{}, err
		}
		return State{initialized: true, legacyMode: true, prior: p}, nil
	}
	validation := copyEntry(e)
	validation.Policy = W100
	base, err := legacy.NewState(validation)
	if err != nil {
		return State{}, err
	}
	v := base.Snapshot()
	v.Definition = d
	v.Entry = copyEntry(e)
	v.ThresholdPoints = d.ThresholdPoints
	v.MinimumFloor = 0
	h, _ := H0DefinitionFor(e.Policy)
	return State{initialized: true, diagnostic: base, view: Snapshot{Snapshot: v, H0: &H0Snapshot{Definition: h}}, lastIndex: -1}, nil
}

// Snapshot は旧値又は新H0値を参照共有なく返します。
//
// 引数: receiver(State)は純状態。返り値: Snapshotは旧JSONを変えない公開値です。
func (s State) Snapshot() Snapshot {
	if s.legacyMode {
		return Snapshot{Snapshot: s.prior.Snapshot()}
	}
	return copySnapshot(s.view)
}

// validateInput は時計・会計・原行の後退と不正価格を拒否します。
//
// 引数: s(State)/in(Input)は前状態と当入力。返り値: int64/errorは既返済半円額又は拒否です。
func validateInput(s State, in Input) (int64, error) {
	if !s.initialized || s.view.Finished || !finite(in.At) || in.At < s.view.At || in.Sequence <= s.view.Sequence || (in.Phase != PreFill && in.Phase != AfterSource) || in.SourceIndex < 0 || in.SourceIndex < s.lastIndex || in.Remaining < 0 || in.Remaining > s.view.Remaining || in.Reserved < 0 || in.Reserved > in.Remaining || (in.Publication != nil && in.ResetReason != "") {
		return 0, fmt.Errorf("状態・時計・原行・数量・位相又はresetが不正")
	}
	r, err := half(in.ClosedNetYen)
	if err != nil {
		return 0, err
	}
	if in.Remaining == s.view.Remaining && in.ClosedNetYen != s.view.ClosedNetYen {
		return 0, fmt.Errorf("実数量減少なしの既返済額変更")
	}
	if in.Mark != nil && (!finite(*in.Mark) || *in.Mark <= 0 || *in.Mark > 1e9) {
		return 0, fmt.Errorf("正常返済Markが不正")
	}
	return r, nil
}

// advanceDiagnostic は旧3分公表を検証して保存し、新H0の幅や床には使いません。
//
// 引数: s(*State)/in(Input)は私有状態と当入力。返り値: errorは公表改竄・未来・後退です。
func advanceDiagnostic(s *State, in Input) error {
	if in.ResetReason == "" && (in.Publication == nil || reflect.DeepEqual(in.Publication, s.view.Latest)) {
		return nil
	}
	q := s.view.Entry.InitialQuantity
	next, _, err := legacy.Advance(s.diagnostic, legacy.Input{At: in.At, Sequence: in.Sequence, Phase: in.Phase, Remaining: q, Publication: in.Publication, ResetReason: in.ResetReason})
	if err != nil {
		return err
	}
	s.diagnostic = next
	s.view.Latest = next.Snapshot().Latest
	return nil
}

// diagnosticVotes は旧公表の生C/M/P/Bを監査用にだけ返します。
//
// 引数: v(Snapshot)は公表を含む状態。返り値: Decisionは警戒・構造床を追加しない票です。
func diagnosticVotes(v Snapshot) Decision {
	d := Decision{}
	if p := v.Latest; p != nil {
		d.C, d.M = p.C, p.M
		if p.Close != nil && p.PriorPivot != nil {
			d.P = False
			if float64(v.Entry.Side)*(*p.Close-p.PriorPivot.Price) < 0 {
				d.P = True
			}
		}
		if p.BB != nil {
			d.B = p.BB.Contraction
		}
	}
	return d
}

// acceptNarrow は最初の完成票だけを固定し、再送の全値同体を確認します。
//
// 引数: s(*State)/in(Input)/d(*Decision)は私有状態・当入力・判定。返り値: errorは不正又は完成票の変更です。
func acceptNarrow(s *State, in Input, d *Decision) error {
	n := in.Narrow
	if n == nil {
		return nil
	}
	if s.view.Entry.Policy != H0M || !s.view.Active || in.Remaining == 0 || n.Scope != s.view.Entry.Scope || n.ID == "" || !n.Completed || !finite(n.At, n.WidthPoints) || n.At < s.view.Entry.At || n.At > in.At || n.SourceIndex < 0 || n.SourceIndex > in.SourceIndex || n.SourceLine < 1 || n.WidthPoints < 5 || n.WidthPoints > 1e6 || math.Mod(n.WidthPoints, 5) != 0 || (len(n.Witness) > 0 && !json.Valid(n.Witness)) {
		return fmt.Errorf("短期完成票の政策・場・時計・原行・幅・証拠が不正")
	}
	if old := s.view.H0.Narrow; old != nil {
		if !reflect.DeepEqual(old, n) {
			return fmt.Errorf("最初の完成票の変更又は別票への置換")
		}
		return nil
	}
	s.view.H0.Narrow = copyNarrow(n)
	d.H0.NarrowLatchedNow = true
	return nil
}

// Advance は正益起動、非緩和床、余地を持つ費用回収と完成狭幅を純評価します。
//
// 引数: state(State)/in(Input)は以前の状態と実会計値。返り値: State/Decision/errorは次状態・未予約返済適格量又は拒否です。
func Advance(state State, in Input) (State, Decision, error) {
	if state.legacyMode {
		if in.Narrow != nil {
			return state, Decision{}, fmt.Errorf("旧政策へ新短期票は渡せない")
		}
		s, d, err := legacy.Advance(state.prior, legacyInput(in))
		if err != nil {
			return state, Decision{}, err
		}
		state.prior = s
		return state, Decision{Decision: d}, nil
	}
	rhalf, err := validateInput(state, in)
	if err != nil {
		return state, Decision{}, err
	}
	s := state
	h := *state.view.H0
	s.view.H0 = &h
	if err = advanceDiagnostic(&s, in); err != nil {
		return state, Decision{}, err
	}
	v := &s.view
	v.At, v.Sequence, v.Remaining, v.Reserved, v.ClosedNetYen = in.At, in.Sequence, in.Remaining, in.Reserved, in.ClosedNetYen
	s.lastIndex = in.SourceIndex
	v.H0.SourceIndex, v.H0.Phase = in.SourceIndex, in.Phase
	d := diagnosticVotes(*v)
	d.FreeQuantity = in.Remaining - in.Reserved
	d.H0 = &H0Decision{SourceIndex: in.SourceIndex, Phase: in.Phase}
	if v.H0.TargetSet {
		d.H0.TargetBeforeHalfYen = ptr(s.targetHalf)
	}
	if in.Remaining == 0 {
		if in.Narrow != nil && !reflect.DeepEqual(in.Narrow, v.H0.Narrow) {
			return state, Decision{}, fmt.Errorf("全返済後の新完成票は不可")
		}
		v.Finished = true
		if v.H0.TargetSet {
			d.H0.TargetAfterHalfYen = ptr(s.targetHalf)
		}
		return s, d, nil
	}
	costHalf := int64(2 * v.CostPerUnitYen)
	gain := 0.0
	if in.Mark != nil {
		gain = float64(v.Entry.Side) * (*in.Mark - v.Entry.Price)
		unit := 100*gain - v.CostPerUnitYen
		uhalf, e := half(unit)
		if e != nil {
			return state, Decision{}, e
		}
		whalf := rhalf + int64(in.Remaining)*uhalf
		d.GainPoints, d.UnitNetYen, d.WholeNetYen = ptr(gain), ptr(unit), ptr(float64(whalf)/2)
		if !v.Active && whalf > 0 {
			v.Active = true
			v.ActivatedAt = ptr(in.At)
			v.PeakPoints = ptr(gain)
			s.targetHalf = rhalf - int64(in.Remaining)*costHalf
			v.H0.TargetSet = true
			d.ActivatedNow = true
			d.H0.TargetInitializedNow = true
			d.H0.InitialTargetHalfYen = ptr(s.targetHalf)
		}
	}
	if err = acceptNarrow(&s, in, &d); err != nil {
		return state, Decision{}, err
	}
	if v.H0.Narrow != nil {
		d.Warning = True
	}
	if !v.Active {
		return s, d, nil
	}
	// ----------------------------------------
	// 完成票のラッチと正常価格での幅適用を分ける。部分返済時は未知価格でも既存目標を守る。
	if in.Mark != nil {
		if gain > *v.PeakPoints {
			v.PeakPoints = ptr(gain)
		}
		if v.H0.Narrow != nil && !v.H0.NarrowApplied {
			v.WidthPoints = math.Min(v.NormalWidth, v.H0.Narrow.WidthPoints)
			v.H0.NarrowApplied = true
			v.H0.NarrowAppliedAt = ptr(in.At)
			v.Narrowed = true
			v.NarrowedAt = ptr(in.At)
			d.NarrowedNow = true
			d.H0.NarrowAppliedNow = true
		}
		zero := math.Max(0, wholeFloor(0, rhalf, costHalf, in.Remaining))
		room := zero <= gain-5
		d.H0.ZeroCandidateFloor, d.H0.ZeroRoom = ptr(zero), ptr(room)
		if !v.H0.ZeroTargetAdopted && room {
			if s.targetHalf < 0 {
				s.targetHalf = 0
			}
			v.H0.ZeroTargetAdopted = true
			v.H0.ZeroTargetAt = ptr(in.At)
			d.H0.ZeroTargetAdoptedNow = true
		}
	}
	d.WidthSource = "取得時固定通常幅"
	if v.H0.NarrowApplied {
		d.WidthSource = "最初の短期完成幅と取得時通常幅のmin"
	} else if v.H0.Narrow != nil {
		d.WidthSource = "完成警戒ラッチ・正常Mark待ち・通常幅保持"
	}
	floor := 0.0
	if v.FloorPoints != nil {
		floor = *v.FloorPoints
	}
	peakFloor := 5 * math.Ceil((*v.PeakPoints-v.WidthPoints)/5)
	d.PeakFloor = ptr(peakFloor)
	floor = math.Max(floor, peakFloor)
	fw := wholeFloor(s.targetHalf, rhalf, costHalf, in.Remaining)
	d.WholeFloor = ptr(fw)
	floor = math.Max(floor, fw)
	v.FloorPoints = ptr(floor)
	implied := rhalf + int64(in.Remaining)*(int64(200*floor)-costHalf)
	if implied > s.targetHalf {
		s.targetHalf = implied
	}
	v.WholeTargetYen = float64(s.targetHalf) / 2
	v.H0.WholeTargetHalfYen = ptr(s.targetHalf)
	d.H0.TargetAfterHalfYen = ptr(s.targetHalf)
	d.H0.FloorImpliedHalfYen = ptr(implied)
	if in.Mark != nil {
		protect := v.Entry.Price + float64(v.Entry.Side)*floor
		d.ProtectPrice = ptr(protect)
		d.ProtectPriceValid = finite(protect) && protect > 0
		d.FloorHit = gain <= floor
		d.AllReservedHit = d.FloorHit && in.Reserved == in.Remaining
		if d.FloorHit && in.Phase == AfterSource {
			d.EligibleExitQuantity = d.FreeQuantity
		}
	}
	return s, d, nil
}
