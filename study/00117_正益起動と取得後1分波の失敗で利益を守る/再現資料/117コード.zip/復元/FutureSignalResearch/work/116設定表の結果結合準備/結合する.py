"""116の固定設定表を保持し、成功全70の36評価行へ独立結果を結ぶ。"""

import argparse
from copy import deepcopy
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re

OWN=Path(__file__).resolve().parent
ROOT=OWN.parents[1]
TABLE_PATH=OWN/'入力表.md'
TABLE_SHA='baad89d6cec9164e5f76c206e00b392222e97caf5879b0b852a1eca00684a9cd'
F1_SHA='4c76a5f7cd8a59962e885cadf6885cfc75cbc590675955cb8e72ae2d0b8bb372'
CONFIGS=tuple({'policy':'P100','entry_mode':entry,'life_mode':life,'slip_pts':cost,'delay_seconds':delay} for life in ('X0','XC','XQ') for entry in ('A0','T','TR') for cost in (0,5) for delay in (0,1))
def key_for(c: dict) -> str:
    """
    機能: X0旧名とXC/XQ本名を変換する。
    引数: c(dict)は本名設定。返り値: strは一意key。
    """
    return c['entry_mode']+('' if c['life_mode']=='X0' else '_'+c['life_mode'])+f"_C{c['slip_pts']}_D{c['delay_seconds']}"
KEYS=tuple(map(key_for,CONFIGS))
TABLE_KEYS=tuple(key_for(c) for entry in ('A0','T','TR') for life in ('X0','XC','XQ') for c in CONFIGS if c['entry_mode']==entry and c['life_mode']==life)

GATE=('source_new','allowed','selected_true','selected_false','selected_unknown','accepted_requests','accepted_quantity','actual_new_fills','actual_quantity','input_missing','known_denial')


def need(value: bool,label: str) -> None:
    """機能: 根拠・設定・分母の不一致を拒否する。

    引数: value(bool)、label(str)は条件と項目。
    返り値: None。不成立はValueError。
    """
    if not value:raise ValueError(label)


def sha(path: Path) -> str:
    """機能: 明示ファイルの全bytes指紋を得る。

    引数: path(Path)は入力又は生成物。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_ref(reference: dict,before: dict,text: bool=False):
    """機能: FileRefを認証し数値をDecimalのまま又は文書文字列で読む。

    引数: reference/before(dict)、text(bool)は明示参照・不変台帳・文書区分。
    返り値: dict又はstrは認証済み本文。Raw・Native・CSVは受理しない。
    """
    need(set(reference)=={'path','sha256'},'FileRefの集合')
    path=Path(reference['path']).resolve()
    need(Path(reference['path']).is_absolute() and path.suffix in ('.json','.md'),'JSON/MDの絶対参照だけ')
    need(sha(path)==reference['sha256'],'FileRef現物SHA差:'+str(path))
    need(str(path) not in before or before[str(path)]==reference['sha256'],'同pathのSHA衝突')
    before[str(path)]=reference['sha256']
    value=path.read_text(encoding='utf-8-sig')
    return value if text else json.loads(value,parse_float=Decimal)


def parse_table(text: str) -> dict:
    """機能: 56×9の教材行とS28/R36の固定行を厳密に識別する。

    引数: text(str)は設定表。
    返り値: dictは原行とセル。未知・重複・欠落の行を推測で埋めない。
    """
    features=[];settings={};results={}
    for line in text.splitlines():
        if re.match(r'^\| [ICPVBXME]\d{2} \|',line):features.append(line)
        match=re.match(r'^\| ([SR]\d{2}) \|',line)
        if match:
            identity=match[1];target=settings if identity.startswith('S') else results
            need(identity not in target,'ID重複:'+identity)
            target[identity]={'line':line,'cells':[cell.strip() for cell in line.strip().strip('|').split('|')]}
    need(len(features)==56 and all(len(line.strip().strip('|').split('|'))==11 for line in features),'56手法×9尺度の集合')
    need(list(settings)==[f'S{n:02}' for n in range(1,29)] and all(len(row['cells'])==7 for row in settings.values()),'S01-28の7列と順序')
    need(list(results)==[f'R{n:02}' for n in range(1,37)] and all(len(row['cells'])==4 for row in results.values()),'R01-36の4列と順序')
    need([row['cells'][1] for row in results.values()]==list(TABLE_KEYS),'R01-36と36本名候補の対応')
    return {'features':features,'settings':settings,'results':results}


def validate_result(data: dict,artificial: bool=False) -> dict:
    """機能: 成功全70/36条件と入口分母・会計の原名を検査する。

    引数: data(dict)、artificial(bool)は独立結果と内部人工区分。
    返り値: dictは36候補の確認済み入口counts。採否を自動判定しない。
    """
    need(data['試行']==116 and data['成功'] is True and data['前後不変'] is True,'116の独立成功')
    if artificial:need(data.get('人工') is True and data['stage']=='artificial' and 0<data['場数']<=8,'人工ラベル')
    else:
        need(data.get('人工',False) is False and data['stage']=='full70' and data['場数']==70 and data['会計数']==2520,'成功全70/2520だけ')
        need(data['独立再用場数']==54 and data['独立新規検算場数']==16 and data['全70の金融Native再検算'] is False,'元54継承と追加16の新規照合を区別')
        need(data['研究目標達成'] is False and data['採用'] is False,'結果記録と採否を分離')
    need(data['主key']==list(KEYS) and len(data['場別'])==data['場数']*36,'36候補と全場保持')
    need(all(set(data[name])==set(KEYS) for name in ('Actor設定','集計','入口票集計')),'旧12/24条件を混ぜず36集合だけ')
    checked={}
    for key,config in zip(KEYS,CONFIGS):
        saved=data['Actor設定'][key]
        need(all(saved[name]==value for name,value in config.items()) and saved['candidate']==key,'入口Modeと共通P100を区別')
        rows=[row for row in data['場別'] if row['key']==key]
        need(len(rows)==data['場数'] and len({row['session'] for row in rows})==len(rows),'全場/0取引/重複')
        aggregate=data['集計'][key]
        need(aggregate['positive_yen']+aggregate['negative_yen']==aggregate['net_yen'],'集計の正負純額')
        need(aggregate['positive_positions']+aggregate['negative_positions']+aggregate['zero_positions']==aggregate['positions'],'勝負同値分母')
        sums={name:0 for name in GATE}
        for row in rows:
            need(row['入口票検査']['成功'] is True,'場別の独立入口票成功')
            counts=row['入口票検査']['counts']
            need(counts['selected_true']+counts['selected_false']+counts['selected_unknown']==counts['source_new'] and counts['allowed']==counts['selected_true'],'入口三値の全分母')
            need(counts['actual_new_fills']==row['positions'] and counts['actual_quantity']==row['entry_quantity'],'実取得の分母')
            for name in GATE:
                need(type(counts[name]) is int and counts[name]>=0,'入口件数/枚数の整数')
                sums[name]+=counts[name]
        for name,total in sums.items():
            need(data['入口票集計'][key].get(name,0)==total,'入口集計の0省略又は合算差')
        for name in ('net_yen','positions','entry_quantity','whole_positive_positions','whole_positive_closed_negative','whole_positive_closed_negative_yen','protection_activated_positions','activated_closed_negative','activated_closed_negative_yen'):
            need(sum(row[name] for row in rows)==aggregate[name],'全場からの合算:'+key+'/'+name)
        for name,label in (('exit_requests','要求'),('exit_fills','約定')):
            total=sum(row['注文別']['保有根拠失効'][label] for row in rows)
            need(total==data['保有根拠検査集計'][key].get(name,0),'life実績合算:'+key+'/'+name)
            if config['life_mode']=='X0':need(total==0,'X0へlife要求を混入しない')
        need(0<=aggregate['whole_positive_closed_negative']<=aggregate['whole_positive_positions']<=aggregate['positions'],'W正益経験分母')
        checked[key]=sums
    return checked


def amount(value,places: int=0,signed: bool=False) -> str:
    """機能: 原数値を未定義と区別し日本語の結果欄向けに表示する。

    引数: value(int/Decimal/None)、places(int)、signed(bool)は値・表示桁・符号指定。
    返り値: strは桁区切り値又は未定義。半円の金額を消さない。
    """
    if value is None:return '未定義'
    numeric=Decimal(value)
    need(numeric.is_finite(),'結果の有限数値')
    digits=places if places else (0 if numeric==numeric.to_integral_value() else 1)
    result=format(numeric,f',.{digits}f')
    return ('＋' if numeric>0 else '−' if numeric<0 else '')+result.lstrip('-') if signed else result.replace('-','−')


def render(source: str,data: dict,artificial: bool=False) -> tuple:
    """機能: 固定の教材/閾値を保持して36結果欄と進捗だけを更新する。

    引数: source(str)、data(dict)、artificial(bool)は入力表・独立結果・内部人工区分。
    返り値: tuple[str,dict]は別保存する文書と変更証拠。正式表は編集しない。
    """
    original=parse_table(source);counts=validate_result(data,artificial)
    n=data['場数'];phase=f'人工{n}場・{36*n}会計の結合検査（市場の成功ではない）' if artificial else '全70場・36条件・2520会計の金融成功、独立は元54検算継承＋追加16新規照合'
    lines=source.splitlines();need(len(lines)>3 and lines[0]=='# 00116：設定と結果','116設定表の表題')
    lines[2]='2026-11-10。版6・56手法×9尺度。'+('人工値の結果欄検査。' if artificial else '金融F1固定。')+phase+'。採否は自動判定せず、未知期間の安定性は未確認。'
    for index,line in enumerate(lines):
        if line.startswith('使用セルは下記の設定IDへ対応。'):
            lines[index]='使用セルは下記の設定IDへ対応。'+phase+'。足の時間尺度と計算期間・間引き間隔・VWAPの起算点を区別する。複合成績を指標単独の効果にしない。'
    replacements={}
    for identity in ('S17','S22','S23'):
        cells=deepcopy(original['settings'][identity]['cells'])
        if identity=='S17':cells[5]='全R、'+phase+'。正益経験玉を分母にした最終赤字率も記録'
        elif identity=='S22':cells[5]='全R、'+('内部人工で独立検算済み' if artificial else '入口票は元54成功検算継承＋追加16新規照合')
        else:
            cells[5]='全R。'+phase+'・未知安定性未確認'
        replacements[original['settings'][identity]['line']]='| '+' | '.join(cells)+' |'
    for identity,key in zip(original['results'],TABLE_KEYS):
        config=data['Actor設定'][key];value=data['集計'][key];entry=counts[key]
        rate=None if value['win_rate'] is None else Decimal(value['win_rate'])*100
        text=f"{n}場。純額{amount(value['net_yen'],signed=True)}円、PF {amount(value['PF'],3)}、勝率{amount(rate,2)}"+('' if rate is None else '%')
        text+=f"。新規{value['positions']:,}玉/{value['entry_quantity']:,}枚、全玉正益後赤字{value['whole_positive_closed_negative']:,}玉（{amount(value['whole_positive_closed_negative_yen'],signed=True)}円）、起動{value['protection_activated_positions']:,}玉、起動後赤字{value['activated_closed_negative']:,}玉（{amount(value['activated_closed_negative_yen'],signed=True)}円）"
        text+=f"。元要求{entry['source_new']:,}、許可{entry['allowed']:,}、採用票の真/偽/未知={entry['selected_true']:,}/{entry['selected_false']:,}/{entry['selected_unknown']:,}、受付{entry['accepted_requests']:,}件/{entry['accepted_quantity']:,}枚、実取得{entry['actual_new_fills']:,}件/{entry['actual_quantity']:,}枚"
        text+=f"。保存点DD {amount(value['保存点連結時価DD'])}円、全玉正益経験{value['whole_positive_positions']:,}玉"
        redrate=None if value['whole_positive_positions']==0 else Decimal(value['whole_positive_closed_negative'])*100/Decimal(value['whole_positive_positions'])
        text+=f"、同最終赤字率{amount(redrate,2)}"+('' if redrate is None else '%')
        life=[r['注文別']['保有根拠失効'] for r in data['場別'] if r['key']==key]
        text+=f"。追加{config['life_mode']}要求{sum(r['要求'] for r in life):,}件/約定{sum(r['約定'] for r in life):,}件（返済片純額{amount(sum(r['返済片純額'] for r in life),signed=True)}円）"
        if artificial:text='人工値：'+text
        cells=deepcopy(original['results'][identity]['cells']);cells[3]=text
        replacements[original['results'][identity]['line']]='| '+' | '.join(cells)+' |'
    lines=[replacements.get(line,line) for line in lines]
    source_heading='## 設定明細'
    need(lines.count(source_heading)==1,'設定明細の元見出し')
    lines[lines.index(source_heading)]='## 設定明細（金融F1の固定条件）' if not artificial else '## 設定明細（原固定条件・結果欄の人工検査）'
    lines+=['','## 結果の出典と区分','','この表は入口A0/T/TR、追加保有根拠X0/XC/XQ、全条件共通の保護P100を分けて記録する。真/偽/未知は採用モード票の件数で、A0は全許可、TはT、TRはT OR R。費用4条件の反復件数を独立した機会数として合算しない。C/BBは旧3分保護bankの診断のみ、5/15/30分は新入口で使用するという役割を維持する。','','採否はC0の純額だけから自動決定しない。全費用・元54/追加16・未知期間の安定性は別に検討する。根拠は'+('結合人工の手製JSON（市場結果ではない）。' if artificial else '[全70の独立結果](成果物/結果.json)と[固定条件](検査/condition.json)。')]
    lines+=['','Raw初回性：'+('独立保存結果で全Raw監査済み。' if data.get('全Rawライフ発生漏れ/初回性監査') is True else '保存点の独立検算済み。全Raw発生漏れ/初回性は別監査で未結合。')+'保存点exactを全原行の初回性へ広げない。'+('' if artificial else '独立保存は同F1元54成功検算の認証継承と追加16新規照合で、全70新規再検算ではない。')]
    result='\n'.join(lines)+'\n';updated=parse_table(result)
    need(updated['features']==original['features'],'56×9の教材セル不変')
    allowed={'S17':{5},'S22':{5},'S23':{5}}
    for identity,row in original['settings'].items():
        for index,cell in enumerate(row['cells']):
            if index not in allowed.get(identity,set()):need(updated['settings'][identity]['cells'][index]==cell,'設定セル不変:'+identity+'/'+str(index))
    for identity,row in original['results'].items():need(updated['results'][identity]['cells'][:3]==row['cells'][:3],'評価ID/候補/条件不変:'+identity)
    return result,{'56手法':56,'尺度':9,'設定数':28,'結果行数':36,'教材全セル不変':True,'設定の定義セル不変':True,'更新設定の状態欄':{key:sorted(value) for key,value in allowed.items()},
                   '正式表の編集':False,'C0だけの自動採否':False,'人工':artificial}


def execute(request_ref: dict,output: Path) -> dict:
    """機能: Root固定/成功全70のRefを認証して別先へ結果版を生成する。

    引数: request_ref(dict)、output(Path)はRoot新要求と未作成先。
    返り値: dictは生成Markdownと確認Ref。正式studyや旧停止を書換えない。
    """
    need(not output.exists() and output.resolve().is_relative_to(OWN.resolve()),'未作成の本owned内出力だけ')
    before={};request=load_ref(request_ref,before)
    need(request['version']==1 and request['trial']==116 and request['fixed'] is True and request['result_read_authorized'] is True,'Root全70結果の新固定解禁')
    need(Path(request['output_dir']).resolve()==output.resolve(),'Root指定新規出力先')
    need(request['source_table']['sha256']==TABLE_SHA,'校正済み入力表の固定Ref')
    stopped=load_ref(request['code_stop'],before)
    need(stopped['試行']==116 and stopped['成功'] is True and stopped['市場前'] is True and stopped.get('停止') is True,'この結合器の市場前停止')
    expected={str(OWN/name) for name in ('結合する.py','人工検査.py','README.md','検査して停止する.py')}
    need(set(stopped['所有ファイルSHA256'])==expected,'結合器の所有4ファイル')
    for path,digest in stopped['所有ファイルSHA256'].items():
        need(sha(Path(path))==digest,'結合コードの現物SHA差')
        before[path]=digest
    source=load_ref(request['source_table'],before,True)
    need(request['independent_execution']=='inherit_base54_verify_additional16','独立検算の継承方式')
    base54=load_ref(request['base54_check'],before)
    need(base54['試行']==116 and base54['成功'] is True and base54['stage']=='base54' and base54['場数']==54 and base54['会計数']==1944 and base54['前後不変'] is True and base54['金融条件SHA256']==F1_SHA and base54['全残玉予約0'] is True and base54['不一致数']==0,'継承元54の独立成功')
    condition=load_ref(request['condition'],before);completion=load_ref(request['completion'],before);check=load_ref(request['check'],before)
    need(request['condition']['sha256']==F1_SHA and completion['trial']==116 and completion['success'] is True and completion['stage']=='full70' and completion['sessions']==70 and completion['books']==2520 and completion['condition_sha256']==F1_SHA and completion['unchanged'] is True and completion['before']==completion['after'],'同F1全70金融成功')
    need(check['試行']==116 and check['成功'] is True and check['stage']=='full70' and check['場数']==70 and check['会計数']==2520 and check['前後不変'] is True and check['不一致数']==0 and check['全残玉予約0'] is True and check['金融条件SHA256']==F1_SHA and check['金融完了SHA256']==request['completion']['sha256'] and check['出力SHA256']['結果.json']==request['result']['sha256'],'全70独立確認と正本SHA')
    data=load_ref(request['result'],before)
    need(data['金融完了SHA256']==request['completion']['sha256'] and data['Root保存要求SHA256']==check['Root保存要求SHA256'],'同じ金融完了と保存要求')
    need(condition['trial']==116 and condition['fixed'] is True and condition['actual_configurations']==list(CONFIGS),'116本名36金融固定')
    need(data['金融条件SHA256']==request['condition']['sha256'],'結果とRoot金融条件の結合')
    rendered,checks=render(source,data)
    output.mkdir()
    target=output/'設定と結果_全70結果版.md';target.write_text(rendered,encoding='utf-8',newline='\n')
    after={path:sha(Path(path)) for path in before};need(after==before,'入力表/結果/条件の前後不変')
    proof={'試行':116,'成功':True,'Root要求':request_ref,'入力SHA256':before,'後SHA256':after,'前後不変':True,'検査':checks,
           '出力':{'path':str(target),'sha256':sha(target)},'研究目標達成':False,'採用自動判定':False,'Raw/Native/CSV読取':False}
    proof_path=output/'結合の確認.json'
    with proof_path.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    return {'成功':True,'出力':proof['出力'],'確認':{'path':str(proof_path),'sha256':sha(proof_path)}}


def main() -> None:
    """機能: Root新要求だけから設定表の結果版を別保存する。

    引数: CLI request/request-sha/output(str)は固定要求・期待SHA・owned内新規先。
    返り値: None。小さい出力Refだけ表示する。
    """
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request',type=Path,required=True);parser.add_argument('--request-sha',required=True);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    print(json.dumps(execute({'path':str(args.request.resolve()),'sha256':args.request_sha},args.output.resolve()),ensure_ascii=False))


if __name__=='__main__':main()
