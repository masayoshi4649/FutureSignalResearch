"""117の版6/56×9/S31を保持し、20本名keyへ保存成功結果を別先で結ぶ。"""
import argparse
from copy import deepcopy
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re

OWN=Path(__file__).resolve().parent
ROOT=OWN.parents[1]
TABLE_PATH=OWN/'入力表.md'
TABLE_SHA='94094f3012376f2c0fa60c444d6a3746f01a7ec281e2340cd396d86520424995'
F1_SHA='522fe2343b914243fadc4f48d32128a79ecdafcabd84d5a58b5ca399af90d1b0'
CONFIGS=tuple({'policy':p,'slip_pts':c,'delay_seconds':d} for p in ('S0','W100','P100','H0E','H0M') for c in (0,5) for d in (0,1))
KEYS=tuple(f"{c['policy']}_C{c['slip_pts']}_D{c['delay_seconds']}" for c in CONFIGS)
RAW_STATUS='保存点の独立検算済み・全Rawの発生漏れ/初回性は未確認'


def need(value: bool,label: str) -> None:
    """
    機能: 固定表・候補・結果の不整合を拒否する。
    引数: value(bool)/label(str)は条件と説明。返り値: None。
    """
    if not value:raise ValueError(label)


def sha(path: Path) -> str:
    """
    機能: 明示ファイルの全bytes指紋を得る。
    引数: path(Path)は対象。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_ref(reference: dict,before: dict,text: bool=False):
    """
    機能: 小JSON又は固定MDの絶対Refを認証する。
    引数: reference/before(dict)、text(bool)はRef・台帳・文字列区分。返り値: dict又はstr。
    """
    need(set(reference)=={'path','sha256'},'FileRefの集合');p=Path(reference['path']);need(p.is_absolute() and p.suffix in ('.json','.md'),'JSON/MDだけ');p=p.resolve();need(sha(p)==reference['sha256'],'FileRef差');before[str(p)]=reference['sha256'];raw=p.read_text(encoding='utf-8-sig');return raw if text else json.loads(raw,parse_float=Decimal)


def parse_table(text: str) -> dict:
    """
    機能: 教材56×9、設定S31、説明を含む6列R20を識別する。
    引数: text(str)は表。返り値: dictは原行・全セル・Rの本名key。
    """
    features=[];settings={};results={}
    for line in text.splitlines():
        if re.match(r'^\| [ICPVBXME]\d{2} \|',line):features.append(line)
        match=re.match(r'^\| ([SR]\d{2}) \|',line)
        if match:
            identity=match[1];target=settings if identity.startswith('S') else results;need(identity not in target,'ID重複');cells=[x.strip() for x in line.strip().strip('|').split('|')];target[identity]={'line':line,'cells':cells}
            if identity.startswith('R'):
                key=re.match(r'^(S0|W100|P100|H0E|H0M)_C[05]_D[01](?:、|$)',cells[1]);need(key is not None,'R候補key欠落');target[identity]['key']=key[0].removesuffix('、')
    need(len(features)==56 and all(len(r.strip().strip('|').split('|'))==11 for r in features),'56×9の教材集合')
    need(list(settings)==[f'S{i:02}' for i in range(1,32)] and all(len(r['cells'])==7 for r in settings.values()),'S31の順序/7列')
    need(list(results)==[f'R{i:02}' for i in range(1,21)] and all(len(r['cells'])==6 for r in results.values()),'R20の順序/6列');need(tuple(r['key'] for r in results.values())==KEYS,'R20と20本名')
    return {'features':features,'settings':settings,'results':results}


def validate_result(data: dict,artificial: bool=False) -> None:
    """
    機能: 候補・全場・金融分母・純額・費用と0場を検査する。
    引数: data(dict)/artificial(bool)は保存結果と内部区分。返り値: None。
    """
    need(data['試行']==117 and data['成功'] is True and data['前後不変'] is True,'117独立成功')
    if artificial:need(data.get('人工') is True and data['stage']=='artificial' and 0<data['場数']<=8,'小人工')
    else:need(data.get('人工',False) is False and data['stage']=='full70' and data['場数']==70 and data['採用'] is False and data['研究目標達成'] is False,'全70実績と採否分離');need(data.get('独立再用場数',0)==0,'本版は全70保存点の新規検算だけ')
    need(tuple(data['主key'])==KEYS and data['会計数']==20*data['場数'] and len(data['場別'])==20*data['場数'],'20/全場集合')
    for key,cfg in zip(KEYS,CONFIGS):
        actual=data['Actor設定'][key];need(all(actual[k]==v for k,v in cfg.items()),'本名政策/費用差')
        rows=[r for r in data['場別'] if r['key']==key];need(len(rows)==data['場数'] and len({r['session'] for r in rows})==len(rows),'全0場/重複')
        for row in rows+[data['集計'][key]]:
            need(row['positive_yen']>=0 and row['negative_yen']<=0 and row['positive_yen']+row['negative_yen']==row['net_yen'],'正負/純額')
            need(row['positive_positions']+row['negative_positions']+row['zero_positions']==row['positions'],'勝負同値分母');need(0<=row['whole_positive_closed_negative']<=row['whole_positive_positions']<=row['positions'],'W正益経験分母')
            need(row['gross_yen']-row['fee_yen']-row['slip_yen']==row['net_yen'],'費用控除')
        for name in ('positions','entry_quantity','net_yen','positive_yen','negative_yen','whole_positive_positions','whole_positive_closed_negative','whole_positive_closed_negative_yen','protection_activated_positions','activated_closed_negative','activated_closed_negative_yen'):
            need(sum(r[name] for r in rows)==data['集計'][key][name],'全場合算:'+name)


def amount(value,places: int=0,signed: bool=False) -> str:
    """
    機能: 半円とnullを消さず日本語の結果欄へ表示する。
    引数: value(int/float/Decimal/None)、places(int)、signed(bool)は数値・桁・符号指定。
    返り値: strは桁区切り又は未定義。
    """
    if value is None:return '未定義'
    n=Decimal(str(value));need(n.is_finite(),'有限の結果値');digits=places if places else (0 if n==n.to_integral_value() else 1);out=format(n,f',.{digits}f');return ('＋' if n>0 else '−' if n<0 else '')+out.lstrip('-') if signed else out.replace('-','−')


def render(source: str,data: dict,artificial: bool=False) -> tuple:
    """
    機能: 教材/閾値/候補説明を保持し、R20の実績と明示進捗だけを結ぶ。
    引数: source(str)/data(dict)/artificial(bool)は固定表・結果・内部人工。
    返り値: tuple[str,dict]は別先文書と変更範囲証拠。
    """
    original=parse_table(source);validate_result(data,artificial);n=data['場数'];phase=f'人工{n}場・{20*n}会計の結合検査（市場の成績ではない）' if artificial else '同F1全70場・20条件・1400会計の金融成功と全70Native保存点の独立検算成功'
    lines=source.splitlines();need(lines[0]=='# 00117：設定と結果','117表題');need('。2026-11-10' in lines[2],'固定原文の状態段落')
    lines[2]=lines[2].split('。2026-11-10')[0]+'。2026-11-10。'+phase+'。全Raw初回性・未見期間の安定性は未確認。採否は自動判定しない。'
    updates={}
    for identity in ('S01','S04','S29','S30'):
        cells=deepcopy(original['settings'][identity]['cells'])
        if identity=='S01':cells[6]=phase+'。Source内部の全504対応未監査という限界は維持'
        elif identity=='S04':cells[6]='新1分ATR14/115入口ATR14と別。'+phase
        elif identity=='S29':cells[6]=phase+'。実保護fill非返送、新在庫controller未採用'
        else:cells[5]='R01〜20・'+phase
        updates[original['settings'][identity]['line']]='| '+' | '.join(cells)+' |'
    for identity,row in original['results'].items():
        key=row['key'];v=data['集計'][key];rate=None if v['win_rate'] is None else Decimal(str(v['win_rate']))*100;red=None if v['whole_positive_positions']==0 else Decimal(v['whole_positive_closed_negative'])*100/v['whole_positive_positions']
        text=f"{n}場。純額{amount(v['net_yen'],signed=True)}円、利益{amount(v['positive_yen'],signed=True)}円/損失{amount(v['negative_yen'],signed=True)}円、PF {amount(v['PF'],3)}、勝率{amount(rate,2)}"+('' if rate is None else '%')
        text+=f"。新規{v['positions']:,}玉/{v['entry_quantity']:,}枚。正益経験{v['whole_positive_positions']:,}玉、同最終赤字{v['whole_positive_closed_negative']:,}玉（{amount(v['whole_positive_closed_negative_yen'],signed=True)}円）、同率{amount(red,2)}"+('' if red is None else '%')
        text+=f"。起動{v['protection_activated_positions']:,}玉、起動後赤字{v['activated_closed_negative']:,}玉（{amount(v['activated_closed_negative_yen'],signed=True)}円）。保存点連結DD {amount(v['保存点連結時価DD'])}円"
        cells=deepcopy(row['cells']);cells[2]='既使用'+str(n)+'場'+('（手製）' if artificial else '（元54＋追加16）、11/09未読');cells[3]=('人工値：' if artificial else '')+text;cells[4]=cells[4].replace('市場未実行。',phase+'。');cells[5]=RAW_STATUS+'。費用/執行仮定を含み、未見期間の安定性と採用は未確認。H0/短期追加Counterは未確定で未転記。';updates[row['line']]='| '+' | '.join(cells)+' |'
    lines=[updates.get(line,line) for line in lines]
    lines=[line.replace('## 設定明細（選択済・金融固定前）','## 設定明細（固定条件・結果を結合）').replace('## 複合条件と結果（20条件・市場未実行）','## 複合条件と結果（20条件・保存結果を結合）') for line in lines]
    for i,line in enumerate(lines):
        if line.startswith('金融固定要求・実コード停止/版・入力指紋・成功段階・再現CLI・CSV正本とViewer参照は後段未作成。'):
            lines[i]='入力原文の固定前進捗から結果欄を別先へ結合した。'+phase+'。CSV正本・正式保存・Viewerの現在状態はREADMEで別に確認する。固定条件とRoot要求の参照は結合の確認へ記録する。'
        elif line.startswith('段階追記：金融F1を固定し、先頭2場40会計と旧24対照の金融に成功。'):
            lines[i]='入力原文の段階履歴：金融F1固定・先頭2場40会計/旧24対照成功の時点を残した。本結果欄は'+phase+'に対応し、その古い進捗を全70未実行という現在状態へ読み替えない。'
    lines+=['','## 結果の正本と検査範囲','','元Source連続時計の五政策をkeyで結合した。S0は元退出で追加保護なし、W100/P100は固定旧対照、H0EとH0Mは本名を維持する。利益と損失の総額・回数・正益経験分母を分け、取引減少を保護改善と呼ばない。H0のゼロ目標/短期arm/警戒/幅適用等の未確定Counterは推測で加えない。','',RAW_STATUS+'。保存点DDは全Raw最大DDの証明ではない。'+('人工の結果欄試験であり金融成功ではない。' if artificial else '金融は同条件の元54Native参照再用＋追加16再生、独立保存は全70Nativeの保存点を検算する。両者を全70の金融再生と混同しない。'),'','費用後累計と全場の閲覧正本はCSV二点。未参加・退出後仮想利益、機会損失、ROIは評価しない。従来70%/125・250先着/固定参加率を本比較の自動合否には使わない。']
    result='\n'.join(lines)+'\n';after=parse_table(result);need(after['features']==original['features'],'教材全504セル不変')
    allowed={'S01':{6},'S04':{6},'S29':{6},'S30':{5}}
    for identity,row in original['settings'].items():
        for i,cell in enumerate(row['cells']):
            if i not in allowed.get(identity,set()):need(after['settings'][identity]['cells'][i]==cell,'設定閾値/説明不変')
    for identity,row in original['results'].items():need(after['results'][identity]['cells'][:2]==row['cells'][:2],'R名/構成不変');need(after['results'][identity]['cells'][4].endswith(row['cells'][4].removeprefix('市場未実行。')),'費用/遅延/執行仮定不変')
    return result,{'56手法':56,'尺度':9,'設定数':31,'結果行数':20,'教材全セル不変':True,'設定の閾値セル不変':True,'更新設定の状態欄':{k:sorted(v) for k,v in allowed.items()},'Rのkeyと構成不変':True,'費用執行条件不変':True,'正式表編集':False,'人工':artificial}


def execute(request_ref: dict,output: Path) -> dict:
    """
    機能: Root全70固定成功と停止を本文前に結び、新規結果版を作る。
    引数: request_ref(dict)/output(Path)はRoot新要求と未作成先。返り値: dictは文書/確認Ref。
    """
    need(not output.exists() and output.resolve().is_relative_to(OWN),'新規owned出力だけ');before={};request=load_ref(request_ref,before)
    need(request['version']==1 and request['trial']==117 and request['fixed'] is True and request['result_read_authorized'] is True,'本文前のRoot解禁')
    need(Path(request['output_dir']).resolve()==output and request['independent_execution']=='verify_all70_saved_points','指定先/全70保存点方式')
    stopped=load_ref(request['code_stop'],before);need(stopped['試行']==117 and all(stopped.get(k) is True for k in ('成功','市場前','停止')),'本結合器の停止必須')
    need(set(stopped['所有ファイルSHA256'])=={str(OWN/name) for name in ('結合する.py','人工検査.py','README.md','検査して停止する.py')},'所有4')
    for path,digest in stopped['所有ファイルSHA256'].items():need(sha(Path(path))==digest,'結合コードSHA');before[path]=digest
    need(request['source_table']['sha256']==TABLE_SHA and request['condition']['sha256']==F1_SHA,'固定表/同F1')
    source=load_ref(request['source_table'],before,True);condition=load_ref(request['condition'],before);complete=load_ref(request['completion'],before);check=load_ref(request['check'],before)
    need(condition['trial']==117 and condition['fixed'] is True and condition['actual_configurations']==list(CONFIGS),'20条件')
    need(complete['trial']==117 and complete['success'] is True and complete['stage']=='full70' and complete['sessions']==70 and complete['books']==1400 and complete['condition_sha256']==F1_SHA and complete['unchanged'] is True and complete['before']==complete['after'] and complete['reference112_comparisons']==840 and complete['all_reference112_equal'] is True and complete['all_source111_equal'] is True,'同F1全70金融成功')
    need(check['試行']==117 and check['成功'] is True and check['stage']=='full70' and check['場数']==70 and check['会計数']==1400 and check['前後不変'] is True and check['不一致数']==0 and check['全残玉予約0'] is True and check['旧112全金融比較']==840 and check['全Source111同体'] is True and check['金融条件SHA256']==F1_SHA and check['金融完了SHA256']==request['completion']['sha256'] and check['出力SHA256']['結果.json']==request['result']['sha256'],'全70独立確認')
    data=load_ref(request['result'],before);need(data['金融条件SHA256']==F1_SHA and data['金融完了SHA256']==request['completion']['sha256'] and data['Root保存要求SHA256']==check['Root保存要求SHA256'],'結果の同要求/金融')
    rendered,checked=render(source,data);after={p:sha(Path(p)) for p in before};need(after==before,'入力/所有の前後不変');output.mkdir();target=output/'設定と結果_全70結果版.md';target.write_text(rendered,encoding='utf-8',newline='\n')
    proof={'試行':117,'成功':True,'Root要求':request_ref,'入力SHA256':before,'後SHA256':after,'前後不変':True,'検査':checked,'出力':{'path':str(target),'sha256':sha(target)},'採用自動判定':False,'自然Raw/Native/CSV本文読取':False};p=output/'結合の確認.json'
    with p.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    return {'path':str(p),'sha256':sha(p)}


def main() -> None:
    """
    機能: Root新要求とSHAからだけ別結果版を作る。
    引数: CLI --request/--sha256/--output。返り値: None。
    """
    parser=argparse.ArgumentParser()
    for name in ('request','sha256','output'):parser.add_argument('--'+name,required=True)
    args=parser.parse_args();print(json.dumps(execute({'path':str(Path(args.request).resolve()),'sha256':args.sha256},Path(args.output).resolve()),ensure_ascii=False))


if __name__=='__main__':main()
