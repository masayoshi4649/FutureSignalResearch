"""117結果表の人工証拠を新規保存し、Rootレビュー後だけコードを停止する。"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys

OWN=Path(__file__).resolve().parent
FILES=('結合する.py','人工検査.py','README.md',Path(__file__).name)


def digest(path: Path) -> str:
    """
    機能: コード/固定表/人工の全bytes指紋を計算する。
    引数: path(Path)は明示対象。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 人工5主と自己前後を確認し証拠又はRoot停止を作る。
    引数: CLI --proof-only又は--reviewed、--outputは未作成先。返り値: None。
    """
    parser=argparse.ArgumentParser();mode=parser.add_mutually_exclusive_group(required=True);mode.add_argument('--proof-only',action='store_true');mode.add_argument('--reviewed',action='store_true');parser.add_argument('--output',type=Path,required=True);args=parser.parse_args();out=args.output.resolve();target=OWN/'停止.json'
    if out.exists() or (args.reviewed and target.exists()):raise ValueError('新規先だけ')
    before={str((OWN/name).resolve()):digest(OWN/name) for name in FILES};root=OWN.parents[1];dependencies={str(p):digest(p) for p in (root/'work/117損益CSVの出力/人工検査.py',root/'work/116設定表の結果結合準備/結合する.py')};table=OWN/'入力表.md';source={'path':str(table),'sha256':digest(table)}
    result=subprocess.run([sys.executable,'-X','utf8','人工検査.py'],cwd=OWN,capture_output=True,text=True,encoding='utf-8',timeout=60)
    if result.returncode:raise ValueError(result.stdout+result.stderr)
    import 結合する as M
    spec=importlib.util.spec_from_file_location('table117_artificial',OWN/'人工検査.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);text,data=module.inputs();rendered,checks=M.render(text,data,True)
    after={p:digest(Path(p)) for p in before}
    if before!=after or any(digest(Path(p))!=s for p,s in dependencies.items()) or digest(table)!=source['sha256']:raise ValueError('自己/再用/表の前後差')
    out.mkdir(parents=True);md=out/'人工の結果欄.md';md.write_text(rendered,encoding='utf-8',newline='\n')
    value={'試行':117,'成功':True,'停止':args.reviewed,'市場前':True,'所有ファイルSHA256':before,'再用コードSHA256':dependencies,'入力表':source,'前後不変':True,'後SHA256':after,'人工5主':True,'人工ログ':result.stdout+result.stderr,'検査':checks,'人工MD':{'path':str(md),'sha256':digest(md)},'Python版':sys.version,'自然Raw/Native/CSV本文読取':False,'正式表編集':False,'金融再実行':False,'Rootレビュー後':args.reviewed}
    p=target if args.reviewed else out/'停止前の確認.json'
    with p.open('x',encoding='utf-8',newline='\n') as stream:stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'停止':args.reviewed,'確認':{'path':str(p),'sha256':digest(p)}},ensure_ascii=False))


if __name__=='__main__':main()
