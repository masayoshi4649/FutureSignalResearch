"""117の56×9/S31/6列R20を、同じkeyの手製結果へ結合する検査。"""
from copy import deepcopy
from pathlib import Path
import importlib.util
import json
import tempfile
import unittest
import 結合する as M


def inputs() -> tuple[str,dict]:
    """
    機能: 固定入力表と自然データを読まない40会計を得る。
    引数: なし。返り値: tuple[str,dict]は表と手製集計。
    """
    source=M.load_ref({'path':str(M.TABLE_PATH),'sha256':M.TABLE_SHA},{},True)
    p=M.ROOT/'work/117損益CSVの出力/人工検査.py';spec=importlib.util.spec_from_file_location('fixture117_for_table',p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return source,module.fixture()


class Table117Tests(unittest.TestCase):
    def test_all_cells_and_definitions_preserved(self):
        """
        機能: 教材504セルと31設定の閾値を保持しR20だけ実績へ結ぶ。
        引数: self(Table117Tests)。返り値: None。
        """
        source,data=inputs();out,proof=M.render(source,data,True);a,b=M.parse_table(source),M.parse_table(out)
        self.assertEqual(a['features'],b['features']);self.assertEqual(proof['設定数'],31);self.assertEqual(proof['結果行数'],20)
        for identity,row in a['settings'].items():self.assertEqual(row['cells'][1:5],b['settings'][identity]['cells'][1:5])
        self.assertIn(M.RAW_STATUS,out);self.assertNotIn('保有根拠失効要求',out)

    def test_key_join_and_zero_ratios(self):
        """
        機能: 場別や集計の順序が逆でもS0/W/H0各Rをkeyで結合する。
        引数: self(Table117Tests)。返り値: None。
        """
        source,data=inputs();data['場別'].reverse();data['集計']=dict(reversed(list(data['集計'].items())));out,_=M.render(source,data,True);rows=M.parse_table(out)['results']
        for identity,key in (('R01','S0_C0_D0'),('R05','W100_C0_D0'),('R13','H0E_C0_D0'),('R20','H0M_C5_D1')):
            self.assertEqual(rows[identity]['key'],key);self.assertIn('純額'+M.amount(data['集計'][key]['net_yen'],signed=True)+'円',rows[identity]['cells'][3])
        self.assertIn('PF 未定義、勝率未定義',rows['R05']['cells'][3])

    def test_invalid_keys_costs_and_denominators(self):
        """
        機能: 候補欠落/政策偽装/正益分母/費用不整合とR重複を拒否する。
        引数: self(Table117Tests)。返り値: None。
        """
        source,data=inputs()
        for name in ('欠落','政策','分母','費用'):
            bad=deepcopy(data)
            if name=='欠落':bad['主key'].pop()
            elif name=='政策':bad['Actor設定']['H0M_C0_D0']['policy']='P100'
            elif name=='分母':bad['場別'][0]['whole_positive_closed_negative']=99
            else:bad['場別'][0]['fee_yen']+=1
            with self.assertRaises(ValueError):M.render(source,bad,True)
        with self.assertRaises(ValueError):M.parse_table(source.replace('| R20 |','| R19 |'))

    def test_unfixed_before_result_read(self):
        """
        機能: 未固定Root要求を結果・表・出力作成前に拒否する。
        引数: self(Table117Tests)。返り値: None。
        """
        with tempfile.TemporaryDirectory(dir=M.OWN) as folder:
            p=Path(folder)/'要求.json';out=Path(folder)/'出力';p.write_text(json.dumps({'version':1,'trial':117,'fixed':False,'result_read_authorized':False}),encoding='utf-8')
            with self.assertRaisesRegex(ValueError,'Root解禁'):M.execute({'path':str(p),'sha256':M.sha(p)},out)
            self.assertFalse(out.exists())

    def test_false_or_missing_stop_before_result_read(self):
        """
        機能: 停止falseと停止未記録を実結果や表参照の前に拒否する。
        引数: self(Table117Tests)。返り値: None。
        """
        for stopped in ({'試行':117,'成功':True,'市場前':True,'停止':False},{'試行':117,'成功':True,'市場前':True}):
            with tempfile.TemporaryDirectory(dir=M.OWN) as folder:
                base=Path(folder);stop=base/'未停止.json';stop.write_text(json.dumps(stopped),encoding='utf-8');out=base/'未作成'
                req={'version':1,'trial':117,'fixed':True,'result_read_authorized':True,'output_dir':str(out),'independent_execution':'verify_all70_saved_points','code_stop':{'path':str(stop),'sha256':M.sha(stop)}}
                p=base/'要求.json';p.write_text(json.dumps(req),encoding='utf-8')
                with self.assertRaisesRegex(ValueError,'停止必須'):M.execute({'path':str(p),'sha256':M.sha(p)},out)
                self.assertFalse(out.exists())


if __name__=='__main__':unittest.main(verbosity=2)
