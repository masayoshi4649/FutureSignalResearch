"""正益を経験して最終赤字になった実建玉だけを、同じ固定Native70から抽出する。"""

import gzip
import json
from pathlib import Path

from 抽出する import EXPECTED_COMPLETION, detail, sha256
from 要点をまとめる import thin


def main() -> None:
    """
    機能: 全20候補でW最大>0かつ最終実現<0の最大減少建玉を各1件抽出する。
    引数: なし。固定完了台帳に列挙されたNative70だけを認証して読む。
    返り値: None。Raw・価格CSV・退出後価格を開かず、新規JSONへ保存する。
    """
    folder = Path(__file__).resolve().parent
    completion_path = Path("work/117金融F1/全70場/完了.json")
    payload = completion_path.read_bytes()
    assert sha256(payload) == EXPECTED_COMPLETION
    completion = json.loads(payload)
    assert completion["success"] and completion["sessions"] == 70 and completion["books"] == 1400
    maxima = {}
    counts = {}
    refs = []
    for row in completion["results"]:
        ref = row["native"]
        path = Path(ref["path"])
        if not path.is_absolute():
            path = completion_path.parent / path
        raw = path.read_bytes()
        assert sha256(raw) == ref["sha256"]
        native = json.loads(gzip.decompress(raw))
        refs.append({"session": row["session"], **ref})
        for key, book in native["actual"]["books"].items():
            count = counts.setdefault(key, 0)
            for position in book["positions"]:
                peak = position.get("marks", {}).get("whole_max")
                if peak is None or peak["whole_net"] <= 0 or position["realized_net"] >= 0:
                    continue
                count += 1
                difference = peak["whole_net"] - position["realized_net"]
                if key in maxima and difference <= maxima[key]["decrease_yen"]:
                    continue
                maxima[key] = thin(detail(book, position, ref, row["session"]))
            counts[key] = count
        assert sha256(path.read_bytes()) == ref["sha256"]
    assert len(refs) == 70 and len(maxima) == 20
    largest = max(row["decrease_yen"] for row in maxima.values())
    result = {"試行": 117, "成功": True,
              "定義": "marks.whole_max.whole_net>0かつ最終realized_net<0の実Positionだけ。減少=最大W-最終実現。",
              "完了Ref": {"path": str(completion_path.resolve()), "sha256": EXPECTED_COMPLETION},
              "Native70": refs, "条件成立件数": counts, "候補別最大": maxima,
              "全20最大同額": [v for v in maxima.values() if v["decrease_yen"] == largest],
              "原板読取": False, "金融再実行": False, "退出後価格読取": False, "11月09読取": False,
              "限界": "元Actorの保存最大点から抽出。Rawから最大点や初回性を独立再形成しない。",
              "コード": [{"path": str((folder / name).resolve()), "sha256": sha256((folder / name).read_bytes())}
                         for name in ("抽出する.py", "要点をまとめる.py", "赤字限定を抽出する.py")]}
    output = folder / "正益から最終赤字に限った最大減少.json"
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    selected = {k: {f: v[f] for f in ("session", "position_id", "side", "initial_quantity", "entry_price", "entry_jst", "decrease_yen", "final_realized_net", "closed_jst")}
                | {"peak_yen": v["whole_peak"]["whole_net"], "peak_jst": v["whole_peak"]["jst"]}
                for k, v in maxima.items() if k in ("S0_C5_D0", "P100_C5_D0", "H0M_C5_D0") or v["decrease_yen"] == largest}
    print(json.dumps({"output": str(output), "sha256": sha256(output.read_bytes()), "最大減少": largest,
                      "選択": selected}, ensure_ascii=False))


if __name__ == "__main__":
    main()
