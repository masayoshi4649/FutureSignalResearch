"""実行中の既要求を変更せず、生成3入力の同bytes移設を追補認証する。"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 固定台帳と恒久保存と既要求の全70原板参照をmetadataだけで照合する。
    引数: なし。返り値: None。Raw本文や実行中の要求へ触れない。
    """
    mf = ROOT / 'study/00106_収束失速で保護の起動と幅を切り替える/入力台帳_70場.json'
    reloc = ROOT / 'inputs/105生成原板/保存の確認.json'
    req = OWN / '要求.json'
    assert hashlib.sha256(mf.read_bytes()).hexdigest() == '902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8'
    assert hashlib.sha256(reloc.read_bytes()).hexdigest() == '7b4564fc7639afe4c831c3caa84789126a92ddfbdc84aeb6399ed0754c0bcec3'
    assert hashlib.sha256(req.read_bytes()).hexdigest() == '6ca26bfe41b616c1b39191260eb1c2422c6dc4efeda66bf5bd1e697b98acfbbc'
    manifest = json.loads(mf.read_text(encoding='utf-8'))
    references = {s['id']: s['files']['NK225_book'] for s in manifest['sessions']}
    moved = {s['session']: s['canonical'] for s in json.loads(reloc.read_text(encoding='utf-8'))['files']}
    request = json.loads(req.read_text(encoding='utf-8'))
    for s in request['scenes']:
        sid = s['session']
        assert s['raw']['sha256'] == references[sid]['sha256']
        path = Path(manifest['source_root']) / references[sid]['path']
        if sid in moved:
            assert moved[sid]['sha256'] == references[sid]['sha256']
            path = Path(moved[sid]['path'])
        assert Path(s['raw']['path']).resolve() == path.resolve()
    value = {'成功': True, '元固定台帳と全70要求SHA同体': True, '移設3場は同SHAでpathだけ変更': True, '要求SHA256': hashlib.sha256(req.read_bytes()).hexdigest(), 'Raw本文読取': False, '要求変更': False}
    with (OWN / '入力来歴の追補.json').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(value, ensure_ascii=False))


if __name__ == '__main__':
    main()
