"""117の説明診断だけを追補保存し、固定条件・研究停止状態は変更しない。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
OTHER = ROOT / 'work/117追加診断_利益消失'
TARGET = ROOT / 'study/00117_正益起動と取得後1分波の失敗で利益を守る/診断/入口と利益消失'


def digest(path: Path) -> str:
    """
    機能: 明示成果物の全bytes指紋を計算する。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def copy_new(source: Path, target: Path) -> dict:
    """
    機能: 診断を新規保存し同bytesを確認する。
    引数: source/target(Path)。返り値: dictは元位置・保存相対位置とSHA。
    """
    before = digest(source)
    with target.open('xb') as stream:
        stream.write(source.read_bytes())
    assert digest(source) == digest(target) == before
    return {'元': str(source), '正式相対path': target.relative_to(TARGET).as_posix(), 'sha256': before}


def main() -> None:
    """
    機能: 二診断の正本・Raw結果の可逆gzip・コードを重複少なく保存する。
    引数: なし。返り値: None。新金融・原板・11月09の読取はしない。
    """
    assert not TARGET.exists()
    validation = json.loads((OWN / '独立集計の確認.json').read_text(encoding='utf-8'))
    assert validation['成功']
    TARGET.mkdir(parents=True)
    entries = []
    files = {
        OWN / '入口診断.md': '入口診断.md',
        OWN / '集計.json': '入口の集計.json',
        OWN / '要求.json': '入口の入力要求.json',
        OWN / '入力来歴の追補.json': '入力来歴の追補.json',
        OWN / '独立集計の確認.json': '入口の独立集計.json',
        OTHER / '保有中最大評価益から決済までの減少.md': '利益消失.md',
        OTHER / '政策別上位3の表.md': '政策別上位3の表.md',
        OTHER / '診断の要点.json': '診断の要点.json',
        OTHER / '正益から最終赤字に限った最大減少.json': '正益から最終赤字に限った最大減少.json',
        OTHER / '追加診断の確認.json': '利益消失の確認.json',
        OTHER / '抽出する.py': '抽出する.py',
        OTHER / '要点をまとめる.py': '要点をまとめる.py',
    }
    for source, name in files.items():
        entries.append(copy_new(source, TARGET / name))
    source = OWN / '原板結果.json'
    raw = source.read_bytes()
    compressed = gzip.compress(raw, compresslevel=6, mtime=0)
    target = TARGET / '入口の原板走査結果.json.gz'
    with target.open('xb') as stream:
        stream.write(compressed)
    assert gzip.decompress(target.read_bytes()) == raw
    entries.append({'元': str(source), '元SHA256': hashlib.sha256(raw).hexdigest(), '正式相対path': target.name, 'sha256': digest(target), '展開全bytes一致': True})
    archive_path = TARGET / '診断コード.zip'
    code_entries = {}
    with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        paths = list(OWN.glob('*.py')) + list(OWN.glob('*.go')) + [OWN / 'go.mod', OWN / 'cmd/run/main.go'] + list(OTHER.glob('*.py'))
        for p in sorted(paths):
            relative = p.relative_to(ROOT).as_posix()
            data = p.read_bytes()
            archive.writestr(relative, data)
            code_entries[relative] = hashlib.sha256(data).hexdigest()
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None and set(archive.namelist()) == set(code_entries)
        for name, expected in code_entries.items():
            assert hashlib.sha256(archive.read(name)).hexdigest() == expected
    proof = {'試行': 117, '成功': True, '用途': 'ユーザーが求めた入口方向と保有中利益消失の追加説明。新試行・PDCA再開ではない。', '入口原板の走査': '全70場・558実新規。取得Rawを除外、最終決済Rawまで。', '利益消失': '既固定Native70の保存最大Wから同実建玉の最終費用後実現額を引く。', '保存': entries, 'コードZIP': {'path': archive_path.name, 'sha256': digest(archive_path), 'entries': code_entries}, '既存117条件変更': False, '金融再実行': False, '原板複写': False, '11月09読取': False, '決済後仮想利益': False, '研究停止を維持': True}
    target = TARGET / '保存と再現.json'
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'成功': True, '正式先': str(TARGET), 'SHA256': digest(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
