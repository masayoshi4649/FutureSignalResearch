"""117の実保有中の対称先着を、入口と価格基準を混ぜず集計する。"""
from collections import Counter
from pathlib import Path
import hashlib
import json

OWN = Path(__file__).resolve().parent
BASIS = {'last_from_entry': '実建値→Last', 'chart': '取得原行Last→Last', 'executable': '実建値→正常返済BBO'}


def summarize(rows: list, basis: str, width: float) -> dict:
    """
    機能: 同じ幅の順逆先着と両方未到達を建玉1件ずつ数える。
    引数: rows(list)、basis(str)、width(float)。返り値: dictは件数・分母・率。
    """
    counts = Counter()
    for r in rows:
        t = next(t for t in r[basis] if t['width'] == width)
        counts[t['first']] += 1
    resolved = counts[1] + counts[-1]
    return {'幅pt': width, '母集団': len(rows), '順行先着': counts[1], '逆行先着': counts[-1], '両方未到達': counts[0], '到達判定数': resolved, '順行先着率': counts[1] / resolved if resolved else None, '全建玉中の順行先着率': counts[1] / len(rows) if rows else None}


def validate(rows: list, widths: list) -> int:
    """
    機能: 保存された到達の方向・幾何・時計・順序・幅の単調性を別算術で検査する。
    引数: rows(list)、widths(list)。返り値: intは確認した到達数。全Raw初回性を別再走査したとはしない。
    """
    checked = 0
    for r in rows:
        p = r['position']
        assert r['entry_matched'] and r['exit_matched'] and r['rows'] == p['exit']['index'] - p['entry']['index']
        for basis in BASIS:
            assert [t['width'] for t in r[basis]] == widths
            prior = {'favorable': None, 'adverse': None}
            for t in r[basis]:
                touched = []
                for direction, sign in (('favorable', 1), ('adverse', -1)):
                    q = t[direction]
                    if q is None:
                        prior[direction] = 'missing'
                        continue
                    assert p['entry']['index'] < q['index'] <= p['exit']['index']
                    assert p['entry']['source_line'] < q['source_line'] <= p['exit']['source_line']
                    assert p['entry']['time'] <= q['time'] <= p['exit']['time']
                    base = p['entry']['last'] if basis == 'chart' else p['entry_price']
                    mark = q['last']
                    if basis == 'executable':
                        assert q['quote_ok'] and 0 < q['bid'] < q['ask']
                        mark = q['bid'] if p['side'] == 1 else q['ask']
                    assert sign * p['side'] * (mark - base) >= t['width']
                    assert prior[direction] != 'missing'
                    if prior[direction] is not None:
                        assert prior[direction] <= q['index']
                    prior[direction] = q['index']
                    touched.append((q['index'], sign))
                    checked += 1
                assert not (len(touched) == 2 and touched[0][0] == touched[1][0])
                assert t['first'] == (min(touched)[1] if touched else 0)
    return checked


def main() -> None:
    """
    機能: 原板結果を検査し全体・売買・元手法・通知種別の説明表を作る。
    引数: なし。返り値: None。新しい取引・費用後仮利益は作らない。
    """
    path = OWN / '原板結果.json'
    value = json.loads(path.read_text(encoding='utf-8'))
    assert value['成功'] and len(value['scenes']) == 70
    rows = [r for s in value['scenes'] for r in s['positions']]
    assert len(rows) == 558 and len({r['position']['id'] for r in rows}) == 558
    widths = value['widths']
    checked = validate(rows, widths)
    totals = {basis: [summarize(rows, basis, w) for w in widths] for basis in BASIS}
    groups = {}
    for field in ('side', 'method', 'kind', 'quantity'):
        groups[field] = {}
        for category in sorted({r['position'][field] for r in rows}, key=str):
            subset = [r for r in rows if r['position'][field] == category]
            groups[field][str(category)] = {basis: [summarize(subset, basis, w) for w in widths] for basis in BASIS}
    output = {'成功': True, '試行': 117, '元結果SHA256': hashlib.sha256(path.read_bytes()).hexdigest(), '場数': 70, '建玉数': 558, '個別到達検査数': checked, '全体': totals, '群別': groups, '意味': 'S0_C0D0の実保有中の価格方向。費用控除前の同幅先着であり最終勝率ではない。新規原行は照合のみ・最終返済原行を含む。', '入口比較の同体範囲': 'C0D0のS0/W100/P100/H0E/H0M 5政策。全20費用の同体ではない。', '独立集計検査': True, '全Raw初着の別実装再走査': False, '決済後観測': False, '原板再走査回数': 1, '研究再開': False}
    with (OWN / '集計.json').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(output, ensure_ascii=False, indent=2) + '\n')
    lines = ['# 117：エントリーの同幅先着診断', '', '2026-11-10。元手法S0、追加滑りC0・遅延D0の実新規558件（既使用70場）を1件ずつ数える。観測は実新規の次の採用Rawから、S0の最終返済Rawまで。部分返済後も実Positionが残る間を含む。決済後は延長しない。', '', '主表は実際の建値EからLastが順逆同じ幅へどちらが先に到達したか。等号も到達。同秒は物理行/採用Index順。手数料や枚数を価格差へ混ぜない。両方未到達を負けへ置き換えない。', '', '## 実建値からLastの主表', '', '|順逆それぞれの幅pt|順行先着|逆行先着|両方未到達|到達判定できた玉の順行率|', '|---:|---:|---:|---:|---:|']
    for row in totals['last_from_entry']:
        rate = '未定義' if row['順行先着率'] is None else f"{row['順行先着率'] * 100:.1f}%"
        lines.append(f"|{row['幅pt']:g}|{row['順行先着']}|{row['逆行先着']}|{row['両方未到達']}|{rate}|")
    for basis in ('chart', 'executable'):
        lines += ['', f'## 参照：{BASIS[basis]}', '', '|幅pt|順行先着|逆行先着|両方未到達|順行率|', '|---:|---:|---:|---:|---:|']
        for row in totals[basis]:
            rate = '未定義' if row['順行先着率'] is None else f"{row['順行先着率'] * 100:.1f}%"
            lines.append(f"|{row['幅pt']:g}|{row['順行先着']}|{row['逆行先着']}|{row['両方未到達']}|{rate}|")
    lines += ['', '## 解釈上の限界', '', '入口の条件を変えていないC0D0の5政策の実新規は同じ取得方向・枚数・価格・原行だった。早い追尾で観測を打ち切る差を避けるため、全て元S0の実保有区間で比較している。ただしS0の決済時刻自体にも影響される診断で、全玉を固定時間・場末まで観測した純粋な入口予測力ではない。', '', '5〜20pt等の小幅では建値とLast/返済BBOのスプレッド・ずれが結果を左右するため、取得原行Last基準も併記した。返済BBOは買いBid/売りAsk、異常時は評価しない。価格方向の先着率は、手数料・滑り・可変枚数・部分返済を含む最終損益の勝率とは異なる。', '', '全70原板は元固定台帳と同SHA。取得・最終返済の原行全値、区間行数、全採用数、限月、圧縮SHA、前後statを照合した。到達の幾何・時計・方向・幅単調性・集計はPythonで別計算し、Raw初着を第二のRaw走査で再証明したとはしない。Source通知のkindは保存値で、source_addをcampaign全体の真の追加・数量を確信度と推定しない。', '']
    (OWN / '入口診断.md').write_text('\n'.join(lines), encoding='utf-8')
    print(json.dumps({'成功': True, '到達検査': checked, '主表': totals['last_from_entry'], '参照Last基準': totals['chart']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
