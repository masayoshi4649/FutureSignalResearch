package holdingohlc113

import "testing"

// TestTouches は同幅・等号・同秒後Index・逆順・範囲外・ミラーを確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestTouches(t *testing.T) {
	for _, side := range []int{1, -1} {
		p := EntryPosition{Side: side, EntryPrice: 100, Entry: Quote{Index: 1, Last: 100}, Exit: Quote{Index: 3}}
		r := newEntry(p, []float64{5, 10})
		for _, item := range []struct {
			index int64
			gain  float64
			ok    bool
		}{{1, -100, true}, {2, 5, true}, {3, -10, true}, {4, 100, true}} {
			last := 100 + float64(side)*item.gain
			observe(r, Quote{Index: item.index, Time: 1, Last: last, Bid: last, Ask: last, QuoteOK: item.ok})
		}
		if r.Chart[0].First != 1 || r.Chart[1].First != -1 || r.Executable[0].First != 1 || r.Executable[1].First != -1 || r.Rows != 2 {
			t.Fatalf("順逆又は境界 %d %+v", side, r)
		}
		if r.Chart[0].Favorable.Index != 2 || r.Chart[0].Adverse.Index != 3 {
			t.Fatal("同時計の物理順")
		}
	}
}

// TestBadBBO はLast方向と返済側気配の不明を分離します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestBadBBO(t *testing.T) {
	r := newEntry(EntryPosition{Side: 1, EntryPrice: 100, Entry: Quote{Index: 0, Last: 100}, Exit: Quote{Index: 2}}, []float64{10})
	observe(r, Quote{Index: 1, Last: 110, QuoteOK: false})
	if r.Chart[0].First != 1 || r.Executable[0].First != 0 || r.GoodRows != 0 {
		t.Fatal("異常BBO補完")
	}
}

// TestSpreadBasis は実建値と取得時Lastを基準にする価格方向を分離します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestSpreadBasis(t *testing.T) {
	r := newEntry(EntryPosition{Side: 1, EntryPrice: 110, Entry: Quote{Index: 0, Last: 100}, Exit: Quote{Index: 2}}, []float64{10})
	observe(r, Quote{Index: 1, Last: 100, QuoteOK: false})
	observe(r, Quote{Index: 2, Last: 110, QuoteOK: false})
	if r.LastFromEntry[0].First != -1 || r.Chart[0].First != 1 || r.Executable[0].First != 0 {
		t.Fatal("価格基準の混同")
	}
}
