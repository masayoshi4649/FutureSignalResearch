"""117の共通入口と元手法の実保有区間を診断用に抽出する。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 明示入力の全bytes指紋を得る。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identity(p: dict) -> tuple:
    """
    機能: 出口政策を除いた実新規の同体キーを作る。
    引数: p(dict)は実建玉。返り値: tupleはSource・実方向・数量・取得原行。
    """
    q = p['entry_quote']
    return (p['source']['signal_id'], p['side'], p['initial_quantity'], p['entry_price'], q['time'], q['index'], q['source_line'])


def main() -> None:
    """
    機能: 既固定Nativeと台帳から70場558新規を抽出し新規要求を作る。
    引数: なし。返り値: None。売買条件や金融を変更・再実行しない。
    """
    completion = ROOT / 'work/117金融F1/全70場/完了.json'
    manifest = ROOT / 'study/00106_収束失速で保護の起動と幅を切り替える/入力台帳_70場.json'
    reloc = ROOT / 'inputs/105生成原板/保存の確認.json'
    assert sha(completion) == 'f9d5dfc49bef7f9b2dcf6bba55fe264b689dc2e8312e0e26c4530e4b1d2872e0'
    assert sha(manifest) == '902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8'
    assert sha(reloc) == '7b4564fc7639afe4c831c3caa84789126a92ddfbdc84aeb6399ed0754c0bcec3'
    cm = json.loads(completion.read_text(encoding='utf-8'))
    mf = json.loads(manifest.read_text(encoding='utf-8'))
    paths = {s['id']: {'path': str((Path(mf['source_root']) / s['files']['NK225_book']['path']).resolve()), 'sha256': s['files']['NK225_book']['sha256']} for s in mf['sessions']}
    for s in json.loads(reloc.read_text(encoding='utf-8'))['files']:
        assert paths[s['session']]['sha256'] == s['canonical']['sha256']
        paths[s['session']]['path'] = s['canonical']['path']
    scenes, refs = [], []
    for row in cm['results']:
        ref = row['native']
        p = Path(ref['path'])
        data = p.read_bytes()
        assert hashlib.sha256(data).hexdigest() == ref['sha256']
        native = json.loads(gzip.decompress(data))
        books = native['actual']['books']
        source = books['S0_C0_D0']['positions']
        for key in ('W100_C0_D0', 'P100_C0_D0', 'H0E_C0_D0', 'H0M_C0_D0'):
            assert [identity(p) for p in source] == [identity(p) for p in books[key]['positions']]
        session = native['actual']['scope']['session']
        positions = [{'id': p['id'], 'method': p['source']['method'], 'kind': p['source']['kind'], 'side': p['side'], 'quantity': p['initial_quantity'], 'entry_price': p['entry_price'], 'entry': p['entry_quote'], 'exit': p['closed_quote']} for p in source]
        scenes.append({'session': row['session'], 'contract': native['actual']['scope']['contract'], 'start': session['start'], 'end': session['end'], 'raw': paths[row['session']], 'expected_accepted': native['actual']['counts']['rows'], 'positions': positions})
        assert sha(p) == ref['sha256']
        refs.append(ref)
    assert len(scenes) == 70 and sum(len(s['positions']) for s in scenes) == 558
    value = {'version': 1, 'trial': 117, 'kind': '既実績の説明診断・新PDCAではない', 'widths': [5, 10, 20, 25, 50, 75, 100, 125, 150, 200, 250, 300, 400, 500], 'scenes': scenes, 'native_refs': refs, 'entry_all_policies_equal': True, 'chart_basis': '実取得原行のLastを基準に、その後のLastが順逆同幅に先着。実取得原行は照合のみ、最終決済原行は含む。', 'executable_basis': '実取得Eを基準に、その後の正常返済BBOが順逆同幅に先着。手数料なし・C0。', 'observation': 'S0_C0_D0の実新規後〜最終決済Rawまで。途中の部分返済後も元Positionが残る間を含む。決済後は観測しない。', 'research_goal_resumed': False, '11月09読取': False}
    target = OWN / '要求.json'
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'成功': True, '場数': 70, '新規': 558, '要求SHA256': sha(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
