package main

import (
	diagnostic "entrydiagnostic117"
	"flag"
	"fmt"
	"os"
)

// main はRootが選んだ既使用70場の説明診断だけを実行します。
//
// 引数: CLI input/sha256/output(string)、workers(int)。返り値: ありません。失敗は終了値1です。
func main() {
	input := flag.String("input", "", "要求")
	sha := flag.String("sha256", "", "要求SHA")
	output := flag.String("output", "", "新規結果")
	workers := flag.Int("workers", 8, "場並列")
	flag.Parse()
	if err := diagnostic.RunEntries(*input, *sha, *output, *workers); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
