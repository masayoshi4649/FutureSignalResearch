package holdingohlc113

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"reflect"
	"sort"
	"sync"
)

type EntryPosition struct {
	ID         string  `json:"id"`
	Method     string  `json:"method"`
	Kind       string  `json:"kind"`
	Side       int     `json:"side"`
	Quantity   int     `json:"quantity"`
	EntryPrice float64 `json:"entry_price"`
	Entry      Quote   `json:"entry"`
	Exit       Quote   `json:"exit"`
}

type EntryScene struct {
	Session          string          `json:"session"`
	Contract         string          `json:"contract"`
	Start            float64         `json:"start"`
	End              float64         `json:"end"`
	Raw              FileRef         `json:"raw"`
	ExpectedAccepted int64           `json:"expected_accepted"`
	Positions        []EntryPosition `json:"positions"`
}

type EntryRequest struct {
	Widths []float64    `json:"widths"`
	Scenes []EntryScene `json:"scenes"`
}

type Touch struct {
	Width     float64 `json:"width"`
	Favorable *Quote  `json:"favorable"`
	Adverse   *Quote  `json:"adverse"`
	First     int     `json:"first"`
}

type EntryResult struct {
	Position      EntryPosition `json:"position"`
	Chart         []Touch       `json:"chart"`
	LastFromEntry []Touch       `json:"last_from_entry"`
	Executable    []Touch       `json:"executable"`
	EntryMatched  bool          `json:"entry_matched"`
	ExitMatched   bool          `json:"exit_matched"`
	Rows          int64         `json:"rows"`
	GoodRows      int64         `json:"good_rows"`
}

type EntrySceneResult struct {
	Session   string         `json:"session"`
	Success   bool           `json:"success"`
	Raw       FileRef        `json:"raw"`
	Quality   Counts         `json:"quality"`
	Positions []*EntryResult `json:"positions"`
	ActualSHA string         `json:"actual_sha256"`
	Error     string         `json:"error,omitempty"`
}

// newEntry は順逆同じ正幅を持つ一つの実新規の集計器を作ります。
//
// 引数: p(EntryPosition)、widths([]float64)。返り値: *EntryResultは未到達状態です。
func newEntry(p EntryPosition, widths []float64) *EntryResult {
	r := &EntryResult{Position: p, Chart: []Touch{}, Executable: []Touch{}}
	for _, w := range widths {
		r.Chart = append(r.Chart, Touch{Width: w})
		r.LastFromEntry = append(r.LastFromEntry, Touch{Width: w})
		r.Executable = append(r.Executable, Touch{Width: w})
	}
	return r
}

// touch は等号を到達とし、物理配送順の最初の順逆を保存します。
//
// 引数: values([]Touch)、gain(float64)、q(Quote)。返り値: ありません。
func touch(values []Touch, gain float64, q Quote) {
	for i := range values {
		t := &values[i]
		if gain >= t.Width && t.Favorable == nil {
			x := q
			t.Favorable = &x
			if t.First == 0 {
				t.First = 1
			}
		}
		if gain <= -t.Width && t.Adverse == nil {
			x := q
			t.Adverse = &x
			if t.First == 0 {
				t.First = -1
			}
		}
	}
}

// observe は新規原行を基準値だけに使い、最終返済までの当時価格を集計します。
//
// 引数: r(*EntryResult)、q(Quote)。返り値: ありません。範囲外・異常BBOを補完しません。
func observe(r *EntryResult, q Quote) {
	p := r.Position
	if q.Index <= p.Entry.Index || q.Index > p.Exit.Index {
		return
	}
	r.Rows++
	touch(r.Chart, float64(p.Side)*(q.Last-p.Entry.Last), q)
	touch(r.LastFromEntry, float64(p.Side)*(q.Last-p.EntryPrice), q)
	if q.QuoteOK {
		r.GoodRows++
		mark := q.Bid
		if p.Side < 0 {
			mark = q.Ask
		}
		touch(r.Executable, float64(p.Side)*(mark-p.EntryPrice), q)
	}
}

// ScanEntries は停止済み113の原板parserで実保有窓の順逆先着だけを求めます。
//
// 引数: s(EntryScene)、widths([]float64)。返り値: EntrySceneResult/errorは全境界と圧縮SHAの検証結果です。
func ScanEntries(s EntryScene, widths []float64) (out EntrySceneResult, err error) {
	out = EntrySceneResult{Session: s.Session, Raw: s.Raw, Positions: []*EntryResult{}}
	for _, w := range widths {
		if !finite(w) || w <= 0 {
			return out, fmt.Errorf("幅不正")
		}
	}
	for _, p := range s.Positions {
		if p.ID == "" || (p.Side != 1 && p.Side != -1) || p.Exit.Index < p.Entry.Index || p.Exit.SourceLine < p.Entry.SourceLine {
			return out, fmt.Errorf("区間不正")
		}
		out.Positions = append(out.Positions, newEntry(p, widths))
	}
	sort.Slice(out.Positions, func(i, j int) bool {
		return out.Positions[i].Position.Entry.SourceLine < out.Positions[j].Position.Entry.SourceLine
	})
	f, e := os.Open(s.Raw.Path)
	if e != nil {
		return out, e
	}
	defer f.Close()
	before, e := f.Stat()
	if e != nil {
		return out, e
	}
	h := sha256.New()
	tee := io.TeeReader(f, h)
	z, e := gzip.NewReader(tee)
	if e != nil {
		return out, e
	}
	defer z.Close()
	scan := bufio.NewScanner(z)
	scan.Buffer(make([]byte, 65536), 8*1024*1024)
	scene := Scene{Session: s.Session, Contract: s.Contract, Start: s.Start, End: s.End, Raw: s.Raw}
	previous := s.Start
	var index int64
	contracts := map[string]bool{}
	cursor := 0
	active := []*EntryResult{}
	for scan.Scan() {
		out.Quality.Lines++
		line := out.Quality.Lines
		q, reason, next, e := decodeRow(scan.Bytes(), line, index, scene, previous, &out.Quality, contracts)
		if e != nil {
			return out, e
		}
		previous = next
		if q != nil {
			index++
		}
		for cursor < len(out.Positions) && out.Positions[cursor].Position.Entry.SourceLine <= line {
			active = append(active, out.Positions[cursor])
			cursor++
		}
		keep := active[:0]
		for _, r := range active {
			p := r.Position
			if line == p.Entry.SourceLine {
				if q == nil || !equalQuote(p.Entry, *q) {
					return out, fmt.Errorf("取得原行不一致 %s %s", p.ID, reason)
				}
				r.EntryMatched = true
			}
			if line == p.Exit.SourceLine {
				if q == nil || !equalQuote(p.Exit, *q) {
					return out, fmt.Errorf("返済原行不一致 %s %s", p.ID, reason)
				}
				r.ExitMatched = true
			}
			if q != nil {
				observe(r, *q)
			}
			if line < p.Exit.SourceLine {
				keep = append(keep, r)
			}
		}
		active = keep
	}
	if e = scan.Err(); e != nil {
		return out, e
	}
	if _, e = io.Copy(io.Discard, tee); e != nil {
		return out, e
	}
	out.ActualSHA = hex.EncodeToString(h.Sum(nil))
	after, e := f.Stat()
	if e != nil {
		return out, e
	}
	if before.Size() != after.Size() || before.ModTime() != after.ModTime() || out.ActualSHA != s.Raw.SHA256 {
		return out, fmt.Errorf("圧縮SHA/前後stat差")
	}
	if len(contracts) != 1 || !contracts[s.Contract] || out.Quality.Delivered != s.ExpectedAccepted || index != s.ExpectedAccepted || cursor != len(out.Positions) || len(active) != 0 {
		return out, fmt.Errorf("限月/全受理数/区間未完結")
	}
	for _, r := range out.Positions {
		if !r.EntryMatched || !r.ExitMatched || r.Rows != r.Position.Exit.Index-r.Position.Entry.Index {
			return out, fmt.Errorf("境界/区間行数差 %s", r.Position.ID)
		}
	}
	out.Success = true
	return out, nil
}

// RunEntries は独立した場だけを並列走査し、実戦略や金融を再実行しません。
//
// 引数: input(string)、expected(string)、output(string)、workers(int)。返り値: errorは入力指紋・走査・保存の不整合です。
func RunEntries(input, expected, output string, workers int) error {
	data, err := os.ReadFile(input)
	if err != nil {
		return err
	}
	sum := sha256.Sum256(data)
	if hex.EncodeToString(sum[:]) != expected {
		return fmt.Errorf("要求SHA差")
	}
	var request EntryRequest
	if err = json.Unmarshal(data, &request); err != nil {
		return err
	}
	if len(request.Scenes) != 70 || workers < 1 || workers > 16 {
		return fmt.Errorf("場数/並列不正")
	}
	if _, err = os.Stat(output); !os.IsNotExist(err) {
		return fmt.Errorf("未作成出力が必要")
	}
	results := make([]EntrySceneResult, len(request.Scenes))
	jobs := make(chan int)
	var wg sync.WaitGroup
	for w := 0; w < workers; w++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range jobs {
				r, e := ScanEntries(request.Scenes[i], request.Widths)
				if e != nil {
					r.Error = e.Error()
				}
				results[i] = r
				fmt.Printf("%s 成功=%t\n", r.Session, r.Success)
			}
		}()
	}
	for i := range request.Scenes {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	for _, r := range results {
		if !r.Success {
			return fmt.Errorf("%s: %s", r.Session, r.Error)
		}
	}
	after, err := os.ReadFile(input)
	if err != nil {
		return err
	}
	if !reflect.DeepEqual(data, after) {
		return fmt.Errorf("要求前後差")
	}
	value := map[string]any{"試行": 117, "成功": true, "要求SHA256": expected, "widths": request.Widths, "scenes": results, "raw_passes_per_session": 1, "金融再実行": false, "決済後観測": false}
	encoded, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return err
	}
	f, err := os.OpenFile(output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return err
	}
	defer f.Close()
	_, err = f.Write(append(encoded, '\n'))
	return err
}
