package main

import (
	"encoding/json"
	"fmt"
	"math"
	"reflect"
	"strings"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// known は人工の既知指標を作ります。
//
// 引数: v(float64)。返り値: rules.Valueです。
func known(v float64) rules.Value { return rules.Value{Known: true, Value: v} }

// fixture は最新足を含めない価格域と、同足量/勢いが成立する人工照会を作ります。
//
// 引数: なし。返り値: Input/Queryです。自然ファイルは読みません。
func fixture() (Input, Query) {
	s := Scene{Session: "A", Contract: "K", Start: 0, End: 5000}
	for i := 1; i <= 4; i++ {
		end := float64(i * 300)
		o := rules.OHLC{Open: 100, High: 110, Low: 90, Close: 105}
		vol := 10.0
		hist := 2.0
		if i == 4 {
			o = rules.OHLC{Open: 115, High: 130, Low: 95, Close: 100}
			vol = 10
			hist = 1
		}
		p := rules.Publication{Stamp: rules.Stamp{Time: end + 65, Index: i * 10, Line: i*10 + 1}, Frame: rules.Frame{Frame: rules.ChartFrame{ID: fmt.Sprintf("A/300/%d", i), SessionID: "A", Contract: "K", Width: 300, Start: end - 300, End: end, AvailableAt: end + 60, DeliveryAt: end + 65, PriceKnown: true, VolumeKnown: true, OHLC: o, Volume: vol, Technical: rules.Technical{Histogram: known(hist), PreviousHistogram: known(2), ATR: known(20)}}}}
		s.Publications = append(s.Publications, p)
	}
	q := Query{ID: "origin", Session: "A", Contract: "K", Side: 1, BirthQuote: rules.Quote{Time: 1265, Index: 40, Line: 41, Last: 101}}
	return Input{Scenes: []Scene{s}}, q
}

// clone は人工検査用の独立入力を作ります。
//
// 引数: input(Input)。返り値: Inputです。
func clone(input Input) Input {
	data, _ := json.Marshal(input)
	var x Input
	_ = json.Unmarshal(data, &x)
	return x
}

// single は一つの人工queryの結果を返します。
//
// 引数: t(*testing.T)、input(Input)、query(Query)。返り値: Rowです。
func single(t *testing.T, input Input, query Query) Row {
	t.Helper()
	r, err := Replay(input, []Query{query})
	if err != nil || len(r) != 1 {
		t.Fatal(err)
	}
	return r[0]
}

// TestFixedRangeSameBarAndDiagnostics はb除外・同足束縛・診断条件の非必須性を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestFixedRangeSameBarAndDiagnostics(t *testing.T) {
	in, q := fixture()
	saved := clone(in)
	r := single(t, in, q)
	if !r.PatternKnown || !r.PatternPass || *r.Values["range_high"].Value != 110 || *r.Values["range_low"].Value != 90 || *r.Values["volume_ratio"].Value != 1 || len(r.Feet) != 4 {
		t.Fatalf("抽出差 %+v", r)
	}
	if r.Gates["last_not_reaccelerating_diagnostic"].Pass || !reflect.DeepEqual(in, saved) {
		t.Fatal("Last診断を必須化又は入力を改変")
	}
	if r.Feet[0].Ref.ID != in.Scenes[0].Publications[3].Frame.Frame.ID || *r.Values["previous_histogram"].Value != 2 {
		t.Fatal("同足束縛差")
	}
	in.Scenes[0].Publications[3].Frame.Frame.Technical.PreviousHistogram = known(999)
	r = single(t, in, q)
	if !r.PatternPass || r.Gates["previous_histogram_declared_equal_diagnostic"].Pass || *r.Values["histogram_delta_to_side"].Value != -1 {
		t.Fatal("別のPreviousHistogramを前足実値へ代入")
	}
}

// TestBoundaries は包含域と極値/実体/Histの厳密境界、量0/量同値を区別します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestBoundaries(t *testing.T) {
	for _, test := range []struct {
		name   string
		mutate func(*Input, *Query)
		pass   bool
	}{
		{"Close上端", func(in *Input, q *Query) {
			in.Scenes[0].Publications[3].Frame.Frame.OHLC.Close = 110
			q.BirthQuote.Last = 110
		}, true},
		{"Close下端", func(in *Input, q *Query) {
			f := &in.Scenes[0].Publications[3].Frame.Frame
			f.OHLC.Low = 89
			f.OHLC.Close = 90
			q.BirthQuote.Last = 90
		}, true},
		{"極値等号", func(in *Input, q *Query) {
			f := &in.Scenes[0].Publications[3].Frame.Frame
			f.OHLC.Open = 105
			f.OHLC.High = 110
		}, false},
		{"実体0", func(in *Input, q *Query) { in.Scenes[0].Publications[3].Frame.Frame.OHLC.Open = 100 }, false},
		{"Hist差0", func(in *Input, q *Query) { in.Scenes[0].Publications[3].Frame.Frame.Technical.Histogram = known(2) }, false},
		{"前量0", func(in *Input, q *Query) { in.Scenes[0].Publications[2].Frame.Frame.Volume = 0 }, false},
		{"量減少", func(in *Input, q *Query) { in.Scenes[0].Publications[3].Frame.Frame.Volume = 9 }, false},
		{"Last域外", func(in *Input, q *Query) { q.BirthQuote.Last = 111 }, false},
	} {
		t.Run(test.name, func(t *testing.T) {
			in, q := fixture()
			test.mutate(&in, &q)
			r := single(t, in, q)
			if !r.PatternKnown || r.PatternPass != test.pass {
				t.Fatalf("境界差 %+v", r.Gates)
			}
		})
	}
}

// TestUnknownAndNoSkipping は未知を0や前の既知足で埋めないことを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestUnknownAndNoSkipping(t *testing.T) {
	for _, test := range []struct {
		name   string
		mutate func(*Input)
	}{
		{"最新価格未知", func(in *Input) { in.Scenes[0].Publications[3].Frame.Frame.PriceKnown = false }},
		{"前レンジ価格未知", func(in *Input) { in.Scenes[0].Publications[0].Frame.Frame.PriceKnown = false }},
		{"前量未知", func(in *Input) { in.Scenes[0].Publications[2].Frame.Frame.VolumeKnown = false }},
		{"同足量未知", func(in *Input) { in.Scenes[0].Publications[3].Frame.Frame.VolumeKnown = false }},
		{"Hist未知", func(in *Input) { in.Scenes[0].Publications[3].Frame.Frame.Technical.Histogram = rules.Value{} }},
	} {
		t.Run(test.name, func(t *testing.T) {
			in, q := fixture()
			test.mutate(&in)
			r := single(t, in, q)
			if r.PatternKnown || r.PatternPass || r.Feet[0].Ref.ID != "A/300/4" {
				t.Fatal("未知補完又は最新足を飛ばした")
			}
			data, _ := json.Marshal(Value{})
			if string(data) != "{\"known\":false,\"value\":null}" {
				t.Fatal("未知null差")
			}
		})
	}
}

// TestContinuityFreshAndSceneReset は欠足・足幅・鮮度等号・場跨ぎ構造を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestContinuityFreshAndSceneReset(t *testing.T) {
	in, q := fixture()
	in.Scenes[0].Publications[1].Frame.Frame.Start = 301
	r := single(t, in, q)
	if r.Gates["four_consecutive"].Pass || r.PatternPass {
		t.Fatal("非連続足を成立")
	}
	in, q = fixture()
	q.BirthQuote.Time = 1560
	q.BirthQuote.Index = 41
	q.BirthQuote.Line = 42
	r = single(t, in, q)
	if r.Gates["latest_5_fresh"].Pass {
		t.Fatal("鮮度等号を成立")
	}
	q.BirthQuote.Time = 1559
	r = single(t, in, q)
	if !r.PatternPass {
		t.Fatal("鮮度内を拒否")
	}
	in, q = fixture()
	b := Scene{Session: "B", Contract: "K", Start: 2000, End: 4000}
	p := in.Scenes[0].Publications[3]
	p.Frame.Frame.ID = "B/300/1"
	p.Frame.Frame.SessionID = "B"
	p.Frame.Frame.Start = 2100
	p.Frame.Frame.End = 2400
	p.Frame.Frame.AvailableAt = 2460
	p.Frame.Frame.DeliveryAt = 2465
	p.Stamp = rules.Stamp{Time: 2465, Index: 10, Line: 11}
	b.Publications = []rules.Publication{p}
	in.Scenes = append(in.Scenes, b)
	q.Session = "B"
	q.BirthQuote = rules.Quote{Time: 2465, Index: 10, Line: 11, Last: 101}
	r = single(t, in, q)
	if len(r.Feet) != 1 || r.Gates["four_consecutive"].Pass || r.PatternPass {
		t.Fatal("場跨ぎ構造carry")
	}
}

// TestMirror は売買価格鏡像の条件と方向付き量が同値であることを確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestMirror(t *testing.T) {
	in, q := fixture()
	a := single(t, in, q)
	for i := range in.Scenes[0].Publications {
		f := &in.Scenes[0].Publications[i].Frame.Frame
		o := f.OHLC
		f.OHLC = rules.OHLC{Open: 300 - o.Open, High: 300 - o.Low, Low: 300 - o.High, Close: 300 - o.Close}
		f.Technical.Histogram.Value *= -1
		f.Technical.PreviousHistogram.Value *= -1
	}
	q.Side = -1
	q.BirthQuote.Last = 300 - q.BirthQuote.Last
	b := single(t, in, q)
	if !b.PatternPass || !reflect.DeepEqual(a.Gates, b.Gates) {
		t.Fatal("売買鏡像差")
	}
	for _, key := range []string{"b_body_to_side", "histogram_delta_to_side", "birth_last_minus_close_to_side", "birth_last_range_position_to_side", "native_extreme_outside", "b_range_atr", "volume_ratio"} {
		if *a.Values[key].Value != *b.Values[key].Value {
			t.Fatalf("鏡像値差 %s", key)
		}
	}
}

// TestCausalDeliveryAndImmutability は同Raw全配送・未来非依存・不正原行の拒否を確認します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestCausalDeliveryAndImmutability(t *testing.T) {
	in, q := fixture()
	p := in.Scenes[0].Publications[3]
	p.Frame.Frame.ID = "A/900/1"
	p.Frame.Frame.Width = 900
	p.Frame.Frame.Start = 300
	in.Scenes[0].Publications = append(in.Scenes[0].Publications, p)
	a := single(t, in, q)
	if len(a.Refs) != 5 {
		t.Fatal("同Raw他足を未配送")
	}
	future := p
	future.Frame.Frame.ID = "A/900/2"
	future.Frame.Frame.Start = 1200
	future.Frame.Frame.End = 2100
	future.Frame.Frame.AvailableAt = 2160
	future.Frame.Frame.DeliveryAt = 2165
	future.Stamp = rules.Stamp{Time: 2165, Index: 80, Line: 81}
	in.Scenes[0].Publications = append(in.Scenes[0].Publications, future)
	b := single(t, in, q)
	if !reflect.DeepEqual(a, b) {
		t.Fatal("未来公表混入")
	}
	in.Scenes[0].Publications[5].Frame.Frame.Technical.Histogram = known(9999)
	c := single(t, in, q)
	if !reflect.DeepEqual(a, c) {
		t.Fatal("未来値へ依存")
	}
	for _, mode := range []string{"time", "line", "非有限"} {
		bad, _ := fixture()
		if mode == "time" {
			bad.Scenes[0].Publications[3].Stamp.Time++
		}
		if mode == "line" {
			bad.Scenes[0].Publications[3].Stamp.Line++
		}
		if mode == "非有限" {
			bad.Scenes[0].Publications[3].Frame.Frame.Technical.Histogram = known(math.Inf(1))
		}
		if _, err := Replay(bad, []Query{q}); err == nil {
			t.Fatal("不正公表を許可", mode)
		}
	}
	q2 := q
	q2.ID = "別origin"
	q2.BirthQuote.Last++
	if _, err := Replay(in, []Query{q, q2}); err == nil {
		t.Fatal("同原行改変を許可")
	}
}

// TestQuerySchema は旧照会原本を受け、取得/金融字段を拒否します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestQuerySchema(t *testing.T) {
	_, q := fixture()
	data, _ := json.Marshal(Queries{Queries: []Query{q}, Relations: []Relation{{EntryID: "P0/人工", QueryID: q.ID, Model: "P0", Side: 1, SelectedSide: 1}}})
	if _, err := decodeQueries(data); err != nil {
		t.Fatal(err)
	}
	for _, key := range []string{"entry", "label", "outcomes"} {
		bad := strings.Replace(string(data), "\"birthQuote\":", "\""+key+"\":123,\"birthQuote\":", 1)
		if _, err := decodeQueries([]byte(bad)); err == nil {
			t.Fatal("取得又は金融の混入を許可")
		}
	}
}

// TestPointRange は包含域の一点状態を値幅正規化と区別して保存します。
//
// 引数: t(*testing.T)。返り値: なし。現抽出条件にU>Lを暗黙追加しません。
func TestPointRange(t *testing.T) {
	in, q := fixture()
	for i := 0; i < 3; i++ {
		in.Scenes[0].Publications[i].Frame.Frame.OHLC = rules.OHLC{Open: 100, High: 100, Low: 100, Close: 100}
	}
	q.BirthQuote.Last = 100
	r := single(t, in, q)
	if !r.PatternPass || r.RangeZero == nil || !*r.RangeZero || r.Gates["range_positive_diagnostic"].Pass || r.Values["birth_last_range_position_to_side"].Known {
		t.Fatal("一点域の条件と比率を混同")
	}
}
