package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
)

const csv122SHA = "6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec"
const originQuerySHA = "81442c3ebaa3065213d0844417bb0462cfa3e5d0a05c4f44edfb3fb14191e75c"

// digest は入力bytesのSHA256を返します。
//
// 引数: data([]byte)。返り値: stringは小文字の指紋です。
func digest(data []byte) string { h := sha256.Sum256(data); return hex.EncodeToString(h[:]) }

// decodeQueries は既存origin照会だけを許し、Entryや金融ラベルを拒否します。
//
// 引数: data([]byte)。返り値: Queries/errorです。
func decodeQueries(data []byte) (Queries, error) {
	var result Queries
	d := json.NewDecoder(bytes.NewReader(data))
	d.DisallowUnknownFields()
	if err := d.Decode(&result); err != nil {
		return result, err
	}
	var extra any
	if err := d.Decode(&extra); err != io.EOF {
		return result, fmt.Errorf("query JSONの後続値又は末尾が不正")
	}
	return result, nil
}

// run はF0後の明示指示・固定2入力のSHA/statを検査し、新規出力だけを作ります。
//
// 引数: なし（flag指定）。返り値: errorです。金融計算と方向票作成は行いません。
func run() error {
	inputPath := flag.String("input", "", "固定122CSV公表JSON")
	inputSHA := flag.String("sha256", "", "固定122のSHA256")
	queryPath := flag.String("queries", "", "既存769origin照会JSON原本")
	querySHA := flag.String("queries-sha256", "", "固定origin照会SHA256")
	output := flag.String("output", "", "未作成の出力JSON")
	authorized := flag.Bool("execute-after-f0", false, "RootのF0固定後だけ自然抽出を許可")
	flag.Parse()
	if !*authorized || *inputPath == "" || *queryPath == "" || *output == "" || *inputSHA != csv122SHA || *querySHA != originQuerySHA {
		return fmt.Errorf("F0後の明示実行・固定2入力・各SHA・未作成出力が必要")
	}
	if _, err := os.Stat(*output); !os.IsNotExist(err) {
		return fmt.Errorf("出力は未作成先だけ")
	}
	before, err := os.Stat(*inputPath)
	if err != nil {
		return err
	}
	qb, err := os.Stat(*queryPath)
	if err != nil {
		return err
	}
	data, err := os.ReadFile(*inputPath)
	if err != nil {
		return err
	}
	qdata, err := os.ReadFile(*queryPath)
	if err != nil {
		return err
	}
	if digest(data) != *inputSHA || digest(qdata) != *querySHA {
		return fmt.Errorf("入力又はqueryのSHA差")
	}
	var input Input
	if err = json.Unmarshal(data, &input); err != nil {
		return err
	}
	queries, err := decodeQueries(qdata)
	if err != nil {
		return err
	}
	publications := 0
	for _, s := range input.Scenes {
		publications += len(s.Publications)
	}
	if len(input.Scenes) != 73 || publications != 12794 || len(queries.Queries) != 769 || len(queries.Relations) != 850 {
		return fmt.Errorf("固定73場/12794公表/769照会/850由来関係と不一致")
	}
	rows, err := Replay(input, queries.Queries)
	if err != nil {
		return err
	}
	dataAfter, err := os.ReadFile(*inputPath)
	if err != nil {
		return err
	}
	qdataAfter, err := os.ReadFile(*queryPath)
	if err != nil {
		return err
	}
	after, err := os.Stat(*inputPath)
	if err != nil {
		return err
	}
	qa, err := os.Stat(*queryPath)
	if err != nil {
		return err
	}
	if digest(dataAfter) != *inputSHA || digest(qdataAfter) != *querySHA || before.Size() != after.Size() || before.ModTime() != after.ModTime() || qb.Size() != qa.Size() || qb.ModTime() != qa.ModTime() {
		return fmt.Errorf("入力又は照会の前後SHA/stat差")
	}
	counts := map[string]int{"rows": len(rows), "pattern_known": 0, "pattern_pass": 0}
	for _, r := range rows {
		if r.PatternKnown {
			counts["pattern_known"]++
		}
		if r.PatternPass {
			counts["pattern_pass"]++
		}
	}
	result := struct {
		Success          bool           `json:"success"`
		Version          string         `json:"version"`
		InputSHA         string         `json:"input_sha256"`
		QuerySHA         string         `json:"queries_sha256"`
		SceneCount       int            `json:"source_scene_count"`
		PublicationCount int            `json:"source_publication_count"`
		RelationCount    int            `json:"source_relation_count"`
		Counts           map[string]int `json:"counts"`
		Required         []string       `json:"required_gates"`
		Rows             []Row          `json:"rows"`
		Labels           bool           `json:"financial_labels_used"`
		Entry            bool           `json:"entry_prices_used"`
		Choices          bool           `json:"entry_direction_choices_created"`
	}{true, "失敗突破の非金融抽出部品1", *inputSHA, *querySHA, 73, publications, len(queries.Relations), counts, requiredGates, rows, false, false, false}
	encoded, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		return err
	}
	encoded = append(encoded, '\n')
	if err = os.MkdirAll(filepath.Dir(*output), 0755); err != nil {
		return err
	}
	f, err := os.OpenFile(*output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
	if err != nil {
		return err
	}
	_, writeErr := f.Write(encoded)
	closeErr := f.Close()
	if writeErr != nil {
		return writeErr
	}
	if closeErr != nil {
		return closeErr
	}
	fmt.Printf("非金融抽出%d件・SHA256=%s\n", len(rows), digest(encoded))
	return nil
}

// main は明示CLIだけを起動します。
//
// 引数: なし。返り値: なし。不正な入力では非0終了します。
func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
