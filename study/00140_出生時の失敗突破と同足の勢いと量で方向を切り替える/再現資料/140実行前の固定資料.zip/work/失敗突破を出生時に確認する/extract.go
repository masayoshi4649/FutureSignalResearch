package main

import (
	"fmt"
	"math"
	"sort"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

var valueKeys = []string{"range_low", "range_high", "range_width", "b_open", "b_high", "b_low", "b_close", "b_volume", "previous_volume", "volume_ratio", "b_histogram", "previous_histogram", "declared_previous_histogram", "histogram_delta_to_side", "b_body_to_side", "b_atr", "b_range_atr", "native_extreme_outside", "birth_last_minus_close_to_side", "birth_last_range_position_to_side"}
var requiredGates = []string{"latest_5_fresh", "four_consecutive", "four_prices_known", "native_extreme_outside", "close_inside", "opposite_body", "histogram_weakening", "same_bar_volume", "birth_last_inside"}

// finite は有限な数値だけを認めます。
//
// 引数: values(...float64)は検査する値。返り値: boolは全値が有限かです。
func finite(values ...float64) bool {
	for _, value := range values {
		if math.IsNaN(value) || math.IsInf(value, 0) {
			return false
		}
	}
	return true
}

// value は非有限の派生値も未知として保持します。
//
// 引数: known(bool)、v(float64)。返り値: Valueは既知値又はnullです。
func value(known bool, v float64) Value {
	if !known || !finite(v) {
		return Value{}
	}
	x := v
	return Value{Known: true, Value: &x}
}

// ref は元公表の因果参照を作ります。
//
// 引数: p(rules.Publication)。返り値: rules.RefはID・足幅・終端・配送です。
func ref(p rules.Publication) rules.Ref {
	f := p.Frame.Frame
	return rules.Ref{ID: f.ID, Width: f.Width, End: f.End, Delivered: p.Stamp}
}

// foot は最新/前足の値を同じ公表IDへ束縛し、未知価格を補完しません。
//
// 引数: p(rules.Publication)、role(string)。返り値: Footは独立した保存値です。
func foot(p rules.Publication, role string) Foot {
	f := p.Frame.Frame
	r := Foot{Role: role, Ref: ref(p), Start: f.Start, AvailableAt: f.AvailableAt, DeliveryAt: f.DeliveryAt, PriceKnown: f.PriceKnown, VolumeKnown: f.VolumeKnown,
		Volume: value(f.VolumeKnown, f.Volume), Histogram: value(f.PriceKnown && f.Technical.Histogram.Known, f.Technical.Histogram.Value),
		DeclaredPreviousHistogram: value(f.PriceKnown && f.Technical.PreviousHistogram.Known, f.Technical.PreviousHistogram.Value), ATR: value(f.PriceKnown && f.Technical.ATR.Known, f.Technical.ATR.Value)}
	if f.PriceKnown {
		o := f.OHLC
		r.OHLC = &o
	}
	return r
}

// extract は出生時点の最新足を除く直前3本から価格域を固定します。
//
// 引数: query(Query)、snapshot(rules.Snapshot)、history([]rules.Publication)は当場の実配送済み5分最大4本。
// 返り値: Rowは値・既知性・個別条件です。全origin/旧81の最終方向票は作りません。
func extract(query Query, snapshot rules.Snapshot, history []rules.Publication) Row {
	q := query.BirthQuote
	r := Row{ID: query.ID, Session: query.Session, Contract: query.Contract, Side: query.Side, BirthStamp: rules.Stamp{Time: q.Time, Index: q.Index, Line: q.Line}, BirthLast: q.Last,
		Refs: append([]rules.Ref{}, snapshot.Refs...), Feet: []Foot{}, Values: map[string]Value{}, Gates: map[string]Gate{}, Missing: []string{}}
	for _, key := range valueKeys {
		r.Values[key] = Value{}
	}
	for _, key := range requiredGates {
		r.Gates[key] = Gate{}
	}
	// ----------------------------------------
	// Lastと終値の相対変化は診断だけで、今回の必須条件には加えません。
	r.Gates["last_not_reaccelerating_diagnostic"] = Gate{}
	r.Gates["previous_histogram_declared_equal_diagnostic"] = Gate{}
	r.Gates["range_positive_diagnostic"] = Gate{}
	latest, has := snapshot.Frames[300]
	fresh := has && len(history) > 0 && latest == history[len(history)-1]
	r.Gates["latest_5_fresh"] = Gate{Known: true, Pass: fresh}
	for i := len(history) - 1; i >= 0; i-- {
		p := history[i]
		r.Feet = append(r.Feet, foot(p, fmt.Sprintf("b_minus_%d", len(history)-1-i)))
		if len(history)-1-i > 0 {
			r.Refs = append(r.Refs, ref(p))
		}
	}
	if !fresh {
		r.Missing = append(r.Missing, "最新5分公表が不足又は既存Bank鮮度外")
		return r
	}
	b := latest.Frame.Frame
	t := b.Technical
	for key, v := range map[string]float64{"b_open": b.OHLC.Open, "b_high": b.OHLC.High, "b_low": b.OHLC.Low, "b_close": b.OHLC.Close} {
		r.Values[key] = value(b.PriceKnown, v)
	}
	r.Values["b_volume"] = value(b.VolumeKnown, b.Volume)
	r.Values["b_histogram"] = value(b.PriceKnown && t.Histogram.Known, t.Histogram.Value)
	r.Values["declared_previous_histogram"] = value(b.PriceKnown && t.PreviousHistogram.Known, t.PreviousHistogram.Value)
	r.Values["b_atr"] = value(b.PriceKnown && t.ATR.Known, t.ATR.Value)
	s := float64(query.Side)
	if b.PriceKnown {
		body := s * (b.OHLC.Close - b.OHLC.Open)
		r.Values["b_body_to_side"] = value(true, body)
		r.Gates["opposite_body"] = Gate{Known: true, Pass: body < 0}
		d := s * (q.Last - b.OHLC.Close)
		r.Values["birth_last_minus_close_to_side"] = value(true, d)
		r.Gates["last_not_reaccelerating_diagnostic"] = Gate{Known: true, Pass: d <= 0}
		if t.ATR.Known && t.ATR.Value > 0 {
			r.Values["b_range_atr"] = value(true, (b.OHLC.High-b.OHLC.Low)/t.ATR.Value)
		}
	}
	consecutive := len(history) == 4
	for i, p := range history {
		f := p.Frame.Frame
		if f.Width != 300 || f.End-f.Start != 300 {
			consecutive = false
		}
		if i > 0 && history[i-1].Frame.Frame.End != f.Start {
			consecutive = false
		}
	}
	r.Gates["four_consecutive"] = Gate{Known: true, Pass: consecutive}
	if !consecutive {
		r.Missing = append(r.Missing, "当場の連続確定5分が4本不足")
		return r
	}
	previous := history[2].Frame.Frame
	priceKnown := true
	for _, p := range history {
		priceKnown = priceKnown && p.Frame.Frame.PriceKnown
	}
	r.Gates["four_prices_known"] = Gate{Known: true, Pass: priceKnown}
	// ----------------------------------------
	// 勢いと量は必ずb/直前連続bの組で比較し、Technical.PreviousHistogramの値へ置換しません。
	r.Values["previous_volume"] = value(previous.VolumeKnown, previous.Volume)
	r.Values["previous_histogram"] = value(previous.PriceKnown && previous.Technical.Histogram.Known, previous.Technical.Histogram.Value)
	if b.VolumeKnown && previous.VolumeKnown {
		r.Gates["same_bar_volume"] = Gate{Known: true, Pass: previous.Volume > 0 && b.Volume >= previous.Volume}
		if previous.Volume > 0 {
			r.Values["volume_ratio"] = value(true, b.Volume/previous.Volume)
		}
	}
	if b.PriceKnown && previous.PriceKnown && t.Histogram.Known && previous.Technical.Histogram.Known {
		d := s * (t.Histogram.Value - previous.Technical.Histogram.Value)
		r.Values["histogram_delta_to_side"] = value(true, d)
		r.Gates["histogram_weakening"] = Gate{Known: finite(d), Pass: finite(d) && d < 0}
		if t.PreviousHistogram.Known {
			r.Gates["previous_histogram_declared_equal_diagnostic"] = Gate{Known: true, Pass: t.PreviousHistogram.Value == previous.Technical.Histogram.Value}
		}
	}
	if priceKnown {
		low := history[0].Frame.Frame.OHLC.Low
		high := history[0].Frame.Frame.OHLC.High
		for _, p := range history[1:3] {
			low = math.Min(low, p.Frame.Frame.OHLC.Low)
			high = math.Max(high, p.Frame.Frame.OHLC.High)
		}
		r.Values["range_low"], r.Values["range_high"], r.Values["range_width"] = value(true, low), value(true, high), value(true, high-low)
		r.Gates["range_positive_diagnostic"] = Gate{Known: true, Pass: high > low}
		zero := high == low
		r.RangeZero = &zero
		excess := b.OHLC.High - high
		if query.Side < 0 {
			excess = low - b.OHLC.Low
		}
		r.Values["native_extreme_outside"] = value(true, excess)
		r.Gates["native_extreme_outside"] = Gate{Known: true, Pass: excess > 0}
		r.Gates["close_inside"] = Gate{Known: true, Pass: low <= b.OHLC.Close && b.OHLC.Close <= high}
		r.Gates["birth_last_inside"] = Gate{Known: true, Pass: low <= q.Last && q.Last <= high}
		if high > low {
			position := (q.Last - low) / (high - low)
			if query.Side < 0 {
				position = 1 - position
			}
			r.Values["birth_last_range_position_to_side"] = value(true, position)
		}
	}
	r.PatternKnown = true
	r.PatternPass = true
	for _, key := range requiredGates {
		g := r.Gates[key]
		r.PatternKnown = r.PatternKnown && g.Known
		r.PatternPass = r.PatternPass && g.Known && g.Pass
		if !g.Known {
			r.Missing = append(r.Missing, key+"が未知")
		}
	}
	if !priceKnown {
		r.Missing = append(r.Missing, "連続4本の価格に未知あり")
	}
	return r
}

// validQuery は既存origin出生の識別/方向/原行時計を検査します。
//
// 引数: query(Query)。返り値: errorは不正入力です。
func validQuery(query Query) error {
	q := query.BirthQuote
	if query.ID == "" || query.Session == "" || query.Contract == "" || (query.Side != 1 && query.Side != -1) || !finite(q.Time, q.Last) || q.Last <= 0 || q.Index < 0 || q.Line < q.Index+1 {
		return fmt.Errorf("出生queryの識別/方向/価格/原行が不正")
	}
	return nil
}

// deliver は全公表を同じ順序でBankへ渡し、当場5分だけを最大4本保存します。
//
// 引数: bank(*rules.Bank)、scene(Scene)、index(int)、history(*[]rules.Publication)。返り値: errorです。
func deliver(bank *rules.Bank, scene Scene, index int, history *[]rules.Publication) error {
	p := scene.Publications[index]
	f := p.Frame.Frame
	if f.SessionID != scene.Session || f.Contract != scene.Contract {
		return fmt.Errorf("公表の場/限月が不一致")
	}
	if index > 0 {
		old := scene.Publications[index-1].Stamp
		if p.Stamp.Time < old.Time || p.Stamp.Index < old.Index || p.Stamp.Line < old.Line || (p.Stamp.Index == old.Index && p.Stamp != old) {
			return fmt.Errorf("公表配送順又は同原行Stampが不正")
		}
	}
	if err := bank.Add(p); err != nil {
		return err
	}
	if f.Width == 300 {
		for _, old := range *history {
			if old.Frame.Frame.ID == f.ID {
				return nil
			}
		}
		*history = append(*history, p)
		if len(*history) > 4 {
			*history = append([]rules.Publication(nil), (*history)[len(*history)-4:]...)
		}
	}
	return nil
}

// Replay は同出生Rawの公表を全配送してから非金融パターンを抽出します。
//
// 引数: input(Input)、queries([]Query)。返り値: []Row/errorです。Raw・取得価格・ラベルは読みません。
func Replay(input Input, queries []Query) ([]Row, error) {
	bySession := map[string][]int{}
	seenQuery := map[string]bool{}
	for i, query := range queries {
		if err := validQuery(query); err != nil {
			return nil, err
		}
		key := query.Session + "\x00" + query.ID
		if seenQuery[key] {
			return nil, fmt.Errorf("同場queryが重複")
		}
		seenQuery[key] = true
		bySession[query.Session] = append(bySession[query.Session], i)
	}
	rows := make([]Row, len(queries))
	bank := rules.NewBank()
	seenScene := map[string]bool{}
	previousSession := ""
	for _, scene := range input.Scenes {
		if scene.Session == "" || seenScene[scene.Session] || scene.Session <= previousSession || scene.Contract == "" || !finite(scene.Start, scene.End) || scene.End <= scene.Start {
			return nil, fmt.Errorf("場識別/順序/時計が不正")
		}
		seenScene[scene.Session] = true
		previousSession = scene.Session
		if err := bank.StartSession(scene.Session, scene.Contract); err != nil {
			return nil, err
		}
		history := []rules.Publication{} // 価格構造は場を跨いで継承しません。
		indices := append([]int(nil), bySession[scene.Session]...)
		sort.SliceStable(indices, func(i, j int) bool {
			return queries[indices[i]].BirthQuote.Index < queries[indices[j]].BirthQuote.Index
		})
		pi := 0
		var previous *rules.Quote
		for _, i := range indices {
			query := queries[i]
			q := query.BirthQuote
			if query.Contract != scene.Contract || q.Time < scene.Start || q.Time > scene.End {
				return nil, fmt.Errorf("出生の限月/場時計差")
			}
			if previous != nil && ((q.Index == previous.Index && q != *previous) || q.Time < previous.Time || q.Line < previous.Line) {
				return nil, fmt.Errorf("同原行出生改変又は出生時計逆転")
			}
			for pi < len(scene.Publications) && scene.Publications[pi].Stamp.Index <= q.Index {
				p := scene.Publications[pi]
				if p.Stamp.Time > q.Time || p.Stamp.Line > q.Line || (p.Stamp.Index == q.Index && (p.Stamp.Time != q.Time || p.Stamp.Line != q.Line)) {
					return nil, fmt.Errorf("出生と公表の因果時計差")
				}
				if err := deliver(bank, scene, pi, &history); err != nil {
					return nil, err
				}
				pi++
			}
			snapshot, err := bank.Current(q)
			if err != nil {
				return nil, err
			}
			rows[i] = extract(query, snapshot, history)
			z := q
			previous = &z
		}
		// ----------------------------------------
		// 余った公表も従来Bank数値窓へ入れます。構造履歴だけは次場で必ず空にします。
		for pi < len(scene.Publications) {
			if err := deliver(bank, scene, pi, &history); err != nil {
				return nil, err
			}
			pi++
		}
	}
	for scene := range bySession {
		if !seenScene[scene] {
			return nil, fmt.Errorf("出生場が入力に存在しない")
		}
	}
	return rows, nil
}
