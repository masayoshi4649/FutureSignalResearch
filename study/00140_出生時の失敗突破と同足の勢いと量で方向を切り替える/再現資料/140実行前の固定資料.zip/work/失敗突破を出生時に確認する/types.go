package main

import rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"

// Query は取得後情報を含まない既存origin出生です。
type Query struct {
	ID         string      `json:"id"`
	Session    string      `json:"session"`
	Contract   string      `json:"contract"`
	Side       int         `json:"side"`
	BirthQuote rules.Quote `json:"birthQuote"`
}

type Relation struct {
	EntryID       string `json:"entry_id"`
	QueryID       string `json:"query_id"`
	Model         string `json:"model"`
	ManifestIndex int    `json:"manifest_index"`
	OriginIndex   int    `json:"origin_index"`
	Family        string `json:"family"`
	Side          int    `json:"side"`
	SelectedSide  int    `json:"selected_side"`
}

type Queries struct {
	Success     *bool      `json:"success,omitempty"`
	Trial       *int       `json:"trial,omitempty"`
	ManifestSHA string     `json:"manifest_sha256,omitempty"`
	Queries     []Query    `json:"queries"`
	Relations   []Relation `json:"relations,omitempty"`
}

type Scene struct {
	Session      string              `json:"session"`
	Contract     string              `json:"contract"`
	Start        float64             `json:"start"`
	End          float64             `json:"end"`
	Publications []rules.Publication `json:"publications"`
}

type Input struct {
	Scenes []Scene `json:"scenes"`
}

// Value は未知をnull、既知0を数値0として保存します。
type Value struct {
	Known bool     `json:"known"`
	Value *float64 `json:"value"`
}

// Gate は判定可能性と成立を別々に保持します。
type Gate struct {
	Known bool `json:"known"`
	Pass  bool `json:"pass"`
}

// Foot は価格・量・勢いを同じ足IDと配送原行へ束縛します。
type Foot struct {
	Role                      string      `json:"role"`
	Ref                       rules.Ref   `json:"ref"`
	Start                     float64     `json:"start"`
	AvailableAt               float64     `json:"available_at"`
	DeliveryAt                float64     `json:"delivery_at"`
	PriceKnown                bool        `json:"price_known"`
	VolumeKnown               bool        `json:"volume_known"`
	OHLC                      *rules.OHLC `json:"ohlc"`
	Volume                    Value       `json:"volume"`
	Histogram                 Value       `json:"histogram"`
	DeclaredPreviousHistogram Value       `json:"declared_previous_histogram"`
	ATR                       Value       `json:"atr"`
}

// Row は一つの出生の抽出値で、入口の選択方向や金融結果を含みません。
type Row struct {
	ID           string           `json:"id"`
	Session      string           `json:"session"`
	Contract     string           `json:"contract"`
	Side         int              `json:"side"`
	BirthStamp   rules.Stamp      `json:"birth_stamp"`
	BirthLast    float64          `json:"birth_last"`
	Refs         []rules.Ref      `json:"refs"`
	Feet         []Foot           `json:"feet"`
	Values       map[string]Value `json:"values"`
	Gates        map[string]Gate  `json:"gates"`
	PatternKnown bool             `json:"pattern_known"`
	PatternPass  bool             `json:"pattern_pass"`
	RangeZero    *bool            `json:"range_zero"`
	Missing      []string         `json:"missing"`
}
