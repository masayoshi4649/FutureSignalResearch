"""140の失敗突破抽出、非金融方向票、保存観測の金融評価を分離する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT / 'work/140失敗突破の評価'
EXTRACTOR = ROOT / 'work/失敗突破を出生時に確認する'
LOGIC = ROOT / 'work/140失敗突破の方向票と集計'
FORMAL = ROOT / 'study/00140_出生時の失敗突破と同足の勢いと量で方向を切り替える'
INPUT = ROOT / 'work/122全場入力/入力.json'
QUERIES = ROOT / 'work/138全成立入口の評価/固定入力_版2/特徴照会.json'
MANIFEST = ROOT / 'work/全成立poolの非金融manifest/manifest.json'
MODEL = LOGIC / '固定条件.json'
PATTERNS = OWN / '全出生の失敗突破構造.json'
CHOICES = OWN / '方向票/全752の方向.json'
INPUT_SHA = '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
QUERIES_SHA = '81442c3ebaa3065213d0844417bb0462cfa3e5d0a05c4f44edfb3fb14191e75c'
PREP_SHA = '27d4cbefaeb66a8a4e34430c8f9d3adebd6cb5e85332966211941a584483bfe3'


def sha(path: Path) -> str:
    """
    機能: ファイル全体の指紋を求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def load(path: Path, name: str) -> object:
    """
    機能: 同フォルダの純部品を参照できる私有モジュールとして読む。
    引数: path(Path)、name(str)は位置と私有名。
    返り値: objectはモジュール。mainは呼ばない。
    """
    old_path = list(sys.path)
    try:
        sys.path.insert(0, str(path.parent))
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module
    finally:
        sys.path[:] = old_path


# ----------------------------------------
def main() -> None:
    """
    機能: F0固定、抽出、方向票、F1固定、金融集計を明示的に実行する。
    引数: CLI --mode(str)は固定、抽出、方向、金融前、集計。
    返り値: None。旧観測を再走査せず、保存済み出力を上書きしない。
    """
    p = argparse.ArgumentParser(description='140の非金融と金融の境界を固定する')
    p.add_argument('--mode', choices=('固定', '抽出', '方向', '金融前', '集計'), required=True)
    args = p.parse_args()
    OWN.mkdir(parents=True, exist_ok=True)
    helper = load(ROOT / 'work/133金融前を固定して実行する.py', '140の固定照合')
    f0, f1 = OWN / 'F0抽出前.json', OWN / 'F1金融前.json'
    if args.mode == '固定':
        assert sha(INPUT) == INPUT_SHA and sha(QUERIES) == QUERIES_SHA
        assert sha(MANIFEST) == 'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35'
        assert sha(EXTRACTOR / '準備の最終確認.json') == PREP_SHA
        assert all((FORMAL / n).exists() for n in ('README.md', '条件.md', '設定と結果.md'))
        assert (LOGIC / '準備の確認.json').exists() and MODEL.exists()
        proof = json.loads((EXTRACTOR / '準備の最終確認.json').read_bytes())
        files = {INPUT, QUERIES, MANIFEST, Path(__file__).resolve(), ROOT / 'work/133金融前を固定して実行する.py'}
        for name, info in proof['固定ファイル'].items():
            path = ROOT / name
            assert sha(path) == info['sha256'], path
            files.add(path)
        for folder in (EXTRACTOR, LOGIC, FORMAL):
            files.update(q for q in folder.rglob('*') if q.is_file() and q.suffix in ('.go', '.mod', '.py', '.md', '.json', '.exe'))
        helper.save(f0, {'成功': True, '試行': 140, '段階': '自然抽出前F0', 'UTC': datetime.now(timezone.utc).isoformat(),
            '固定ルール': '9gateと全origins既知成立だけ追加分反転、旧81保護、全752保持',
            '学習なし': True, '追加2場未読': True, 'ファイル': {str(q): sha(q) for q in sorted(files)}})
        print(json.dumps({'F0_SHA256': sha(f0), '固定源数': len(files)}, ensure_ascii=False))
        return
    frozen = json.loads(f0.read_bytes())
    helper.verify(frozen)
    if args.mode == '抽出':
        assert not PATTERNS.exists()
        command = [str(EXTRACTOR / '失敗突破の抽出.exe'), '--input', str(INPUT), '--sha256', INPUT_SHA,
            '--queries', str(QUERIES), '--queries-sha256', QUERIES_SHA, '--output', str(PATTERNS), '--execute-after-f0']
    elif args.mode == '方向':
        assert not CHOICES.exists()
        command = [sys.executable, '-X', 'utf8', str(LOGIC / '方向票を作る.py'), '--f0', str(f0),
            '--f0-sha256', sha(f0), '--extracted', str(PATTERNS), '--extracted-sha256', sha(PATTERNS),
            '--output-dir', str(CHOICES.parent), '--execute-after-f0']
    elif args.mode == '金融前':
        choices = json.loads(CHOICES.read_bytes())
        assert choices['success'] and choices['trial'] == 140 and len(choices['rows']) == 752
        assert choices['model_sha256'] == sha(MODEL) and choices['extracted_sha256'] == sha(PATTERNS)
        declared = load(LOGIC / '集計する.py', '140金融前の依存宣言')
        files = {Path(name) for name in frozen['ファイル']} | {f0, PATTERNS, CHOICES, MODEL}
        for path, expected in declared.SOURCES.items():
            assert sha(path) == expected, path
            files.add(path)
        inherited = load(ROOT / 'work/138全成立入口と頻度の集計/集計する.py', '140の共通算術依存')
        for path, expected in inherited.SOURCES.items():
            assert sha(path) == expected, path
            files.add(path)
        files.update(q for q in CHOICES.parent.rglob('*') if q.is_file() and q.suffix in ('.json', '.md'))
        helper.save(f1, {'成功': True, '試行': 140, '段階': '金融前F1', 'UTC': datetime.now(timezone.utc).isoformat(),
            'F0_SHA256': sha(f0), 'モデルSHA256': sha(MODEL), '方向SHA256': sha(CHOICES),
            '主': 'T0/全752/実BBO/H60±125、旧81保護・全場min1・平均1.043h',
            '学習なし': True, 'ファイル': {str(q): sha(q) for q in sorted(files)}})
        print(json.dumps({'F1_SHA256': sha(f1), '固定源数': len(files)}, ensure_ascii=False))
        return
    else:
        fixed_finance = json.loads(f1.read_bytes())
        helper.verify(fixed_finance)
        command = [sys.executable, '-X', 'utf8', str(LOGIC / '集計する.py'), '--f1', str(f1), '--f1-sha256', sha(f1),
            '--model', str(MODEL), '--model-sha256', sha(MODEL), '--choices', str(CHOICES), '--choices-sha256', sha(CHOICES),
            '--output-dir', str(OWN / '金融評価')]
    subprocess.run(command, cwd=ROOT, check=True)
    helper.verify(frozen)
    if args.mode == '集計':
        helper.verify(fixed_finance)
    helper.save(OWN / (args.mode + 'の完了.json'), {'成功': True, '試行': 140, '段階': args.mode,
        'F0_SHA256': sha(f0), '全固定源前後同体': True, '実行列': command})


if __name__ == '__main__':
    main()
