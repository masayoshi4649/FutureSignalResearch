"""140の明示入力だけをSHA確認する。暗黙の金融読取をしない。"""
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
MANIFEST=ROOT/'work/全成立poolの非金融manifest/manifest.json'
QUERIES=ROOT/'work/138全成立入口の評価/固定入力_版2/特徴照会.json'
EXTRACTOR=ROOT/'work/失敗突破を出生時に確認する'
NONFINANCIAL={MANIFEST:'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35',
 QUERIES:'81442c3ebaa3065213d0844417bb0462cfa3e5d0a05c4f44edfb3fb14191e75c',
 EXTRACTOR/'条件.md':'c1f4b69b5c7a8c07917760f3383b32442b08764b44f25b1551ad1b0e583c69c3',
 EXTRACTOR/'準備の最終確認.json':'27d4cbefaeb66a8a4e34430c8f9d3adebd6cb5e85332966211941a584483bfe3'}


def sha(path: Path) -> str:
    """
    機能: 明示ファイルのSHA256を返す。
    引数: path(Path)は対象。
    返り値: strは指紋。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path, expected: str) -> dict:
    """
    機能: SHA照合後に明示JSONだけを読む。
    引数: path(Path)、expected(str)は対象と期待指紋。
    返り値: dictはJSON。
    """
    assert len(expected)==64 and all(c in '0123456789abcdef' for c in expected)
    data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==expected
    return json.loads(data)


def save(path: Path, data: dict) -> str:
    """
    機能: 未作成先だけへUTF-8 JSONを保存する。
    引数: path(Path)、data(dict)は保存先と内容。
    返り値: strは保存SHA256。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8',newline='\n') as f:json.dump(data,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
    return sha(path)


def module(path: Path, name: str) -> object:
    """
    機能: 元源を変更しない私有importを行う。
    引数: path(Path)、name(str)はコードと私有名。
    返り値: objectはモジュール。
    """
    spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m


def verify_freeze(path: Path, expected: str, required: dict) -> tuple[dict,dict]:
    """
    機能: Rootの固定JSONと必要範囲の全ファイルを照合する。
    引数: path(Path)、expected(str)、required(dict[Path,str])は固定証跡と範囲。
    返り値: tuple[dict,dict]は固定JSON・照合パス表。無関係の金融本文を開かない。
    """
    freeze=load(path,expected);assert freeze['試行']==140
    declared={Path(p).resolve():h for p,h in freeze['ファイル'].items()}
    for p,h in required.items():assert declared[p.resolve()]==h and sha(p)==h,p
    return freeze,declared


def local_sources() -> dict:
    """
    機能: 140の自身と固定条件を必要指紋へ含める。
    引数: なし。
    返り値: dict[Path,str]はF0/F1への照合項目。
    """
    names=('logic140.py','io140.py','方向票を作る.py','集計する.py','人工検査.py','条件.md','固定条件.json')
    return {HERE/n:sha(HERE/n) for n in names}
