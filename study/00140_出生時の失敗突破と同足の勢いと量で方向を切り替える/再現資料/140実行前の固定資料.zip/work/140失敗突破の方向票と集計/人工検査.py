"""140の人工だけを検査する。自然query・抽出・金融本文は開かない。"""
import copy
import importlib.util
import json
from pathlib import Path
import unittest
from unittest.mock import patch

import logic140 as L
import io140 as IO

S=importlib.util.spec_from_file_location('金融140',Path(__file__).with_name('集計する.py'));F=importlib.util.module_from_spec(S);S.loader.exec_module(F)
S=importlib.util.spec_from_file_location('人工138',IO.ROOT/'work/138全成立入口と頻度の集計/人工検査.py');A=importlib.util.module_from_spec(S);S.loader.exec_module(A)


def fixture() -> tuple:
    """
    機能: 833入口/850由来/769照会を持つ人工だけの完全資料を作る。
    引数: なし。
    返り値: tupleはmanifest/query/抽出/人工金融と固定入力等。
    """
    observed,fixed,meta,manifest=A.fixture()
    manifest.update({'success':True,'financial_labels_used':False,'frequency':{'P0':{'scenes':[{'session':s['session']} for s in fixed['scenes']]}}})
    extras=17;queries={};relations=[]
    for model in ('C0','P0'):
        for ci,c in enumerate(manifest[model]):
            origin=c['origins'][0];origin.update({'source_file_sha':'b'*64,'source_locator':{'id':c['id'],'copy':0},'side':c['side'],'birthQuote':copy.deepcopy(c['entryQuote'])})
            if model=='P0' and not c['baseline'] and extras:
                other=copy.deepcopy(origin);other['source_locator']['copy']=1;c['origins'].append(other);extras-=1
            for oi,o in enumerate(c['origins']):
                q=L.origin_query(o,c);assert q['id'] not in queries or q==queries[q['id']];queries[q['id']]=q
                relations.append({'entry_id':model+'/'+c['id'],'query_id':q['id'],'model':model,'manifest_index':ci,'origin_index':oi,
                    'family':o['family'],'side':o['side'],'selected_side':c['side']})
    assert extras==0 and len(queries)==769 and len(relations)==850
    qdata={'success':True,'trial':138,'manifest_sha256':L.MANIFEST_SHA,'queries':list(queries.values()),'relations':relations}
    rows=[]
    for q in queries.values():
        at=L.stamp(q['birthQuote']);refs=[];feet=[]
        for i in range(4):
            end=at[0]-65-i*300;stamp={'time':at[0]-i*300,'index':at[1]-i,'source_line':at[2]-i}
            ref={'id':q['id']+'/'+str(i),'width_seconds':300,'end':end,'delivered':stamp};refs.append(ref)
            feet.append({'role':'b_minus_'+str(i),'ref':ref,'start':end-300,'available_at':end+60,'delivery_at':end+65})
        rows.append({'id':q['id'],'session':q['session'],'contract':q['contract'],'side':q['side'],'birth_stamp':dict(zip(('time','index','source_line'),at)),
            'birth_last':q['birthQuote']['last'],'refs':refs,'feet':feet,'values':{'birth_last_range_position_to_side':{'known':True,'value':.5}},
            'gates':{g:{'known':True,'pass':True} for g in L.GATES},'pattern_known':True,'pattern_pass':True,'range_zero':False,'missing':[]})
    extracted={'success':True,'input_sha256':L.INPUT_SHA,'queries_sha256':L.QUERY_SHA,'source_scene_count':73,'source_publication_count':12794,'source_relation_count':850,
        'required_gates':list(L.GATES),'rows':rows,'financial_labels_used':False,'entry_prices_used':False,'entry_direction_choices_created':False}
    # ----------------------------------------
    # 金融fixtureの参照数だけを上記人工originsへ合わせます。金融結果の値には触りません。
    for m in meta['entries']:
        c=manifest[m['model']][m['manifest_index']];m['origin_count']=len(c['origins'])
    return manifest,qdata,extracted,observed,fixed,meta


class Tests(unittest.TestCase):
    """結合・固定条件・stream選択・元算術を人工資料だけで検査する。"""
    def test_complete_join_and_protection(self) -> None:
        """
        機能: 全由来・別名・752全件・81保護・73場を検査する。
        引数: self(Tests)。返り値: None。
        """
        m,q,x,*_=fixture();saved=copy.deepcopy((m,q,x));c=L.choose(m,q,x)
        self.assertEqual(c['counts'],{'keep':81,'flip':671});self.assertEqual(c['join_proof']['reused_query_relations'],81)
        self.assertEqual((m,q,x),saved);self.assertEqual(len(c['entry_origins']),833)
        self.assertTrue(all(r['native_side']==r['selected_side'] for r in c['rows'] if r['baseline']))
        self.assertEqual(len(L.fixed_spec()['required_gates']),9);self.assertFalse(L.fixed_spec()['learned'])
        self.assertEqual(json.loads((IO.HERE/'固定条件.json').read_text(encoding='utf-8')),L.fixed_spec())

    def test_all_origins_unknown_and_other(self) -> None:
        """
        機能: 2originのうち片方不成立/未知ならkeep、診断gateは必須外と確認する。
        引数: self(Tests)。返り値: None。
        """
        m,q,x,*_=fixture();first=next(c for c in m['P0'] if not c['baseline'] and len(c['origins'])==2)
        qid=L.origin_query(first['origins'][1],first)['id'];row=next(r for r in x['rows'] if r['id']==qid)
        row['gates']['histogram_weakening']['pass']=False;row['pattern_pass']=False
        c=L.choose(m,q,x);self.assertEqual(next(r for r in c['rows'] if r['id']=='P0/'+first['id'])['action'],'keep')
        row['gates']['histogram_weakening']['known']=False;row['pattern_known']=False
        c=L.choose(m,q,x);self.assertEqual(c['counts'],{'keep':82,'flip':670})
        row['gates']['histogram_weakening']={'known':True,'pass':True};row['pattern_known']=row['pattern_pass']=True
        row['gates']['last_not_reaccelerating_diagnostic']={'known':True,'pass':False}
        self.assertEqual(L.choose(m,q,x)['counts'],{'keep':81,'flip':671})

    def test_join_and_future_tampering_rejected(self) -> None:
        """
        機能: side/由来/出生時計の改変と未知0補完、9gate集約改変を拒否する。
        引数: self(Tests)。返り値: None。
        """
        for mode in ('relation','birth','summary','unknown_zero','future'):
            m,q,x,*_=fixture()
            if mode=='relation':q['relations'][0]['selected_side']*=-1
            if mode=='birth':x['rows'][0]['birth_last']+=1
            if mode=='summary':x['rows'][0]['pattern_pass']=False
            if mode=='unknown_zero':x['rows'][0]['values']['不明']={'known':False,'value':0}
            if mode=='future':x['rows'][0]['refs'][0]['delivered']['index']+=10000
            with self.assertRaises(AssertionError,msg=mode):L.choose(m,q,x)

    def test_point_range_and_mirror(self) -> None:
        """
        機能: 一点域は比率nullのまま保持し、side鏡像で選択を対称にする。
        引数: self(Tests)。返り値: None。
        """
        m,q,x,*_=fixture();r=x['rows'][0];r['range_zero']=True;r['values']['birth_last_range_position_to_side']={'known':False,'value':None}
        a=L.choose(m,q,x);self.assertEqual(sum(a['range_classes'].values()),752)
        # 元入力由来も全て反転した人工mirrorを再構築します。
        for model in ('C0','P0'):
            for c in m[model]:
                c['side']*=-1
                for o in c['origins']:o['side']*=-1
        newq={};newrels=[];newx=[];old_by_key={(r['session'],r['birth_last'],r['side'],r['id']):r for r in x['rows']}
        for model in ('C0','P0'):
            for ci,c in enumerate(m[model]):
                for oi,o in enumerate(c['origins']):
                    oq=copy.deepcopy(o);oq['side']*=-1;oldid=L.origin_query(oq,c)['id'];nq=L.origin_query(o,c)
                    newq[nq['id']]=nq
                    if not any(r['id']==nq['id'] for r in newx):
                        nr=copy.deepcopy(next(r for r in x['rows'] if r['id']==oldid));nr['id']=nq['id'];nr['side']=nq['side'];newx.append(nr)
                    newrels.append({'entry_id':model+'/'+c['id'],'query_id':nq['id'],'model':model,'manifest_index':ci,'origin_index':oi,'family':o['family'],'side':o['side'],'selected_side':c['side']})
        q['queries']=list(newq.values());q['relations']=newrels;x['rows']=newx;b=L.choose(m,q,x)
        self.assertEqual(a['counts'],b['counts'])
        self.assertTrue(all(ra['selected_side']==-rb['selected_side'] for ra,rb in zip(a['rows'],b['rows'])))

    def test_financial_tables_controls_and_last(self) -> None:
        """
        機能: 180/833/73の表、旧native120条件、phaseとLast金額nullを人工で検査する。
        引数: self(Tests)。返り値: None。
        """
        manifest,q,x,result,fixed,meta=fixture();chosen=L.choose(manifest,q,x);choices={r['id']:r for r in chosen['rows']}
        old=IO.module(F.BASE,'人工140旧138');rs,sessions,_=old.prepare(result,fixed,meta,manifest);arith=old.load_arithmetic()
        before,_,_,_=old.calculate(rs,sessions,fixed['scenes'],arith)
        base=IO.module(F.BASE,'人工140新138');F.configure(base,choices);records,sessions,phase=base.prepare(result,fixed,meta,manifest)
        arith=base.load_arithmetic();v,p,f,_=base.calculate(records,sessions,fixed['scenes'],arith);tables=base.tables(records,sessions,v,p,f,arith)
        self.assertEqual([(len(t['rows']),len(t['headers'])) for t in tables],[(180,34),(833,36),(73,49)])
        self.assertEqual(F.native_check(v,{'集計':before})['合計'],120)
        self.assertEqual(v['all']['T0']['BBO']['3600']['125']['flips'],671);self.assertEqual(phase['stream検査'],3332)
        self.assertIsNone(v['all']['T0']['Last']['3600']['125']['ifd_net5_sum']);self.assertTrue(p['all']['P0']['全場最低1取得'])
        broken=copy.deepcopy(result);broken['scenes'][0]['cases'][0]['original']['outcomes'][0]['endpoint']['time']=14700
        with self.assertRaises(AssertionError):base.prepare(broken,fixed,meta,manifest)

    def test_touch_unknown_cost_and_stream_side(self) -> None:
        """
        機能: H不足既知touchの優先・未知・往復77/1077円と実逆streamを確認する。
        引数: self(Tests)。返り値: None。
        """
        base=IO.module(F.BASE,'人工140費用');arith=base.load_arithmetic();q=A.quote(100,1000);c=A.candidate('人工',1,q);o=c['outcomes'][1]
        o['status']='gap_censored';o['endpoint']=None
        self.assertFalse(arith.ifd(c,o,125,'BBO')['known'])
        o['touches'][3]={'width':125,'direction':1,'quote':A.quote(110,1010,230)};out=arith.ifd(c,o,125,'BBO')
        self.assertEqual((out['net0'],out['net5']),(12723,11723));self.assertIsNone(arith.ifd(c,o,125,'Last')['net5'])
        record={'model':'P0','case':{'id':'P0/人工','original_side':1,'original':{'名前':'原'},'reverse':{'名前':'逆'},'chart_original':{'名前':'原Last'},'chart_reverse':{'名前':'逆Last'}}}
        choices={'P0/人工':{'selected_side':-1}}
        self.assertEqual(L.stream(record,'T0','BBO',choices)['名前'],'逆');self.assertEqual(L.stream(record,'T0','Last',choices)['名前'],'逆Last')
        self.assertEqual(L.stream(record,'P0','BBO',choices)['名前'],'原')

    def test_fixed_sha_cli_before_natural_io(self) -> None:
        """
        機能: F1未知SHAを自然入力読取へ進む前に拒否する。
        引数: self(Tests)。返り値: None。
        """
        args=['集計する.py']
        for n in ('f1','model','choices'):args+=['--'+n,'存在しない人工.json','--'+n+'-sha256','unknown']
        args+=['--output-dir','未作成の人工出力']
        with patch('sys.argv',args),patch.object(F,'local_sources',return_value={}),patch.object(IO.Path,'read_bytes',side_effect=RuntimeError('自然へ進んだ')):
            with self.assertRaises(AssertionError):F.main()


if __name__=='__main__':unittest.main(verbosity=2)
