"""Root F0後だけ、金融を読まず769originを752方向票へ結合する。"""
import argparse
import json
from pathlib import Path
from logic140 import choose,fixed_spec
from io140 import HERE,MANIFEST,QUERIES,NONFINANCIAL,sha,load,save,verify_freeze,local_sources


def main() -> None:
    """
    機能: 固定抽出と全由来を結び、全752方向票と小型証跡を新規保存する。
    引数: CLIのF0/抽出のpathとSHA、output-dir、execute-after-f0。
    返り値: None。モデル学習・金融本文読取・入口削減はしない。
    """
    p=argparse.ArgumentParser(description='140の非金融方向票')
    for name in ('f0','extracted'):
        p.add_argument('--'+name,type=Path,required=True);p.add_argument('--'+name+'-sha256',required=True)
    p.add_argument('--output-dir',type=Path,required=True);p.add_argument('--execute-after-f0',action='store_true')
    args=p.parse_args();assert args.execute_after_f0
    assert not any((args.output_dir/n).exists() for n in ('全752の方向.json','方向票の確認.json'))
    checks={**NONFINANCIAL,**local_sources()}
    verify_freeze(args.f0,args.f0_sha256,checks)
    model_path=HERE/'固定条件.json';model_sha=sha(model_path);assert load(model_path,model_sha)==fixed_spec()
    manifest=load(MANIFEST,NONFINANCIAL[MANIFEST]);queries=load(QUERIES,NONFINANCIAL[QUERIES]);extracted=load(args.extracted,args.extracted_sha256)
    out=choose(manifest,queries,extracted)
    out.update({'model_sha256':model_sha,'extracted_sha256':args.extracted_sha256,'queries_sha256':NONFINANCIAL[QUERIES],
        'manifest_sha256':NONFINANCIAL[MANIFEST],'F0_SHA256':args.f0_sha256,
        'sources':{str(p.resolve()):h for p,h in {MANIFEST:NONFINANCIAL[MANIFEST],QUERIES:NONFINANCIAL[QUERIES],args.extracted:args.extracted_sha256,model_path:model_sha}.items()}})
    checks[args.extracted]=args.extracted_sha256
    verify_freeze(args.f0,args.f0_sha256,{p:h for p,h in checks.items() if p!=args.extracted})
    assert all(sha(p)==h for p,h in checks.items())
    h=save(args.output_dir/'全752の方向.json',out)
    proof={'成功':True,'試行':140,'方向SHA256':h,'モデルSHA256':model_sha,'抽出SHA256':args.extracted_sha256,
        'F0_SHA256':args.f0_sha256,'全件保持':True,'固定81保護':True,'全73場保持':True,'9必須gate':True,
        '結合':out['join_proof'],'方向件数':out['counts'],'理由件数':out['reasons'],'価格域区分':out['range_classes'],
        '前後不変':True,'前後SHA256':{str(p.resolve()):h for p,h in checks.items()},'金融本文読取':False,'学習':False}
    save(args.output_dir/'方向票の確認.json',proof)
    print(json.dumps({'成功':True,'方向SHA256':h,'方向件数':out['counts'],'結合':out['join_proof']},ensure_ascii=False))


if __name__=='__main__':main()
