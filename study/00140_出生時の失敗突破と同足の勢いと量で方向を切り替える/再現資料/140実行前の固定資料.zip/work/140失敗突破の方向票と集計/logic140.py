"""140の固定9条件とorigin結合。ファイル・金融結果を読み込まない純部品。"""
import copy
import hashlib
import json
import math
from collections import Counter

INPUT_SHA='6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
QUERY_SHA='81442c3ebaa3065213d0844417bb0462cfa3e5d0a05c4f44edfb3fb14191e75c'
MANIFEST_SHA='e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35'
GATES=('latest_5_fresh','four_consecutive','four_prices_known','native_extreme_outside','close_inside','opposite_body','histogram_weakening','same_bar_volume','birth_last_inside')


def fixed_spec() -> dict:
    """
    機能: 学習しない140の仕様をmodel相当の固定辞書へまとめる。
    引数: なし。
    返り値: dictは事前固定条件。データ件数や損益で更新しない。
    """
    return {'success':True,'trial':140,'learned':False,'main_policy':'T0','controls':['P0','C0'],
        'entries':752,'sessions':73,'protected_baseline':81,'additional':671,'queries':769,'relations':850,
        'required_gates':list(GATES),'all_origins':'全originが既知かつ9条件成立した追加候補だけ実逆',
        'unknown':'keep','other':'keep','baseline':'native保護','range':'当場bを除く直前連続5分3本',
        'close_and_birth_last':'L<=価格<=U','extreme':'native買いHigh>U/売りLow<L','body':'s*(C-O)<0',
        'momentum':'s*(Hist_b-Hist_actual_previous)<0','volume':'volume_b>=volume_actual_previous>0',
        'point_range':'許容、range_zeroを保存、位置比は未知','last_vs_close':'診断のみ',
        'entry_time_and_population':'138の全752取得を保持。出生時情報のみで向きを選択',
        'financial_selection':'同取得時計の保存実BBO原側/逆側。1-p推定なし',
        'input_sha256':INPUT_SHA,'queries_sha256':QUERY_SHA,'manifest_sha256':MANIFEST_SHA,
        'extractor_condition_sha256':'c1f4b69b5c7a8c07917760f3383b32442b08764b44f25b1551ad1b0e583c69c3'}


def finite(v: object) -> bool:
    """
    機能: boolを除く有限の価格値を確認する。
    引数: v(object)は検査値。
    返り値: boolは有限数値か。
    """
    return type(v) in (int,float) and math.isfinite(v)


def stamp(q: dict) -> tuple:
    """
    機能: 場内の因果原行を固定キーへする。
    引数: q(dict)は出生又は取得Quote。
    返り値: tupleは価格時計/採用順/物理行。
    """
    assert finite(q['time']) and type(q['index']) is int and q['index']>=0
    assert type(q['source_line']) is int and q['source_line']>0
    return tuple(q[k] for k in ('time','index','source_line'))


def origin_query(origin: dict, candidate: dict) -> dict:
    """
    機能: 元138と同じ由来キーからquery IDと出生を再構築する。
    引数: origin/candidate(dict)はmanifestの元通知とcanonical候補。
    返り値: dictは同じorigin出生。代表出生を選ばない。
    """
    birth=origin['birthQuote'];bs=stamp(birth)
    assert finite(birth['last']) and birth['last']>0 and type(origin['side']) is int and origin['side'] in (-1,1)
    raw_key=json.dumps([origin['source_file_sha'],origin['source_locator'],origin['side'],bs],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
    identity='origin/'+hashlib.sha256(raw_key).hexdigest()[:32]
    return {'id':identity,'session':candidate['session'],'contract':candidate['contract'],'side':origin['side'],
        'birthQuote':{k:birth[k] for k in ('time','index','source_line','last')}}


def validate_row(row: dict, query: dict) -> None:
    """
    機能: 抽出行を元queryと固定9gateへ照合する。
    引数: row/query(dict)は非金融抽出と出生原本。
    返り値: None。未知/null・同足参照・未来原行を検査する。
    """
    assert all(row[k]==query[k] for k in ('id','session','contract','side'))
    birth=query['birthQuote'];at=stamp(birth)
    assert stamp(row['birth_stamp'])==at and row['birth_last']==birth['last']
    for item in row['values'].values():
        assert type(item['known']) is bool
        assert finite(item['value']) if item['known'] else item['value'] is None
    assert set(GATES)<=set(row['gates'])
    for gate in row['gates'].values():
        assert type(gate['known']) is bool and type(gate['pass']) is bool
        assert gate['known'] or not gate['pass']
    assert type(row['pattern_known']) is bool and type(row['pattern_pass']) is bool
    assert row['pattern_known']==all(row['gates'][k]['known'] for k in GATES)
    assert row['pattern_pass']==all(row['gates'][k]['known'] and row['gates'][k]['pass'] for k in GATES)
    assert row['range_zero'] is None or type(row['range_zero']) is bool
    for ref in row['refs']:
        assert ref['end']<=at[0] and all(x<=y for x,y in zip(stamp(ref['delivered']),at))
    assert len(row['feet'])<=4
    for index,foot in enumerate(row['feet']):
        ref=foot['ref'];assert foot['role']=='b_minus_'+str(index) and ref['width_seconds']==300
        assert ref in row['refs'] or not row['gates']['latest_5_fresh']['pass']
        assert foot['start']<=ref['end']<=foot['available_at']<=foot['delivery_at']<=ref['delivered']['time']<=at[0]
        assert all(x<=y for x,y in zip(stamp(ref['delivered']),at))
    if row['range_zero'] is True:
        position=row['values']['birth_last_range_position_to_side']
        assert position=={'known':False,'value':None}


def choose(manifest: dict, queries: dict, extracted: dict) -> dict:
    """
    機能: 全由来を完全結合し旧81を保護、追加の全origin成立時だけ反転する。
    引数: manifest/queries/extracted(dict)は金融を含まない固定3資料。
    返り値: dictは全752方向票と833入口/850由来/769照会の対応証跡。
    """
    assert manifest['success'] and not manifest['financial_labels_used']
    assert queries['success'] and queries['trial']==138 and queries['manifest_sha256']==MANIFEST_SHA
    assert extracted['success'] and extracted['input_sha256']==INPUT_SHA and extracted['queries_sha256']==QUERY_SHA
    assert extracted['source_scene_count']==73 and extracted['source_publication_count']==12794 and extracted['source_relation_count']==850
    assert extracted['financial_labels_used'] is False and extracted['entry_prices_used'] is False and extracted['entry_direction_choices_created'] is False
    assert extracted['required_gates']==list(GATES)
    qmap={q['id']:q for q in queries['queries']};xmap={r['id']:r for r in extracted['rows']}
    assert len(qmap)==len(queries['queries'])==len(xmap)==len(extracted['rows'])==769 and set(qmap)==set(xmap)
    for identity,q in qmap.items():validate_row(xmap[identity],q)
    rels={(r['model'],r['manifest_index'],r['origin_index']):r for r in queries['relations']}
    assert len(rels)==len(queries['relations'])==850
    assert [len(manifest[k]) for k in ('C0','P0')]==[81,752]
    sessions=[r['session'] for r in manifest['frequency']['P0']['scenes']]
    assert len(sessions)==len(set(sessions))==73
    assert sum(c['baseline'] is True for c in manifest['P0'])==81
    controls={c['id']:c for c in manifest['C0']};assert len(controls)==81
    used=set();seen_rel=set();rows=[];entry_origins=[];reason_counts=Counter();point_counts=Counter()
    for model in ('C0','P0'):
        ids=set()
        for index,c in enumerate(manifest[model]):
            assert c['id'] not in ids and c['session'] in sessions and type(c['baseline']) is bool
            ids.add(c['id']);side=c['side'];assert type(side) is int and side in (-1,1) and c['origins']
            if model=='C0' or c['baseline']:
                assert c['baseline'] is True and c['id'] in controls
                for k in ('session','contract','side','entryQuote'):assert c[k]==controls[c['id']][k]
            query_ids=[]
            for oi,origin in enumerate(c['origins']):
                expected=origin_query(origin,c);qid=expected['id'];assert qmap[qid]==expected
                key=(model,index,oi);r=rels[key]
                assert r=={'entry_id':model+'/'+c['id'],'query_id':qid,'model':model,'manifest_index':index,'origin_index':oi,
                    'family':origin['family'],'side':origin['side'],'selected_side':side}
                assert all(a<=b for a,b in zip(stamp(origin['birthQuote']),stamp(c['entryQuote'])))
                assert all(origin['entryQuote'][k]==c['entryQuote'][k] for k in ('time','index','source_line','last','bid','ask','quote_ok'))
                if not c['baseline']:assert origin['side']==side
                seen_rel.add(key);used.add(qid);query_ids.append(qid)
            entry_origins.append({'id':model+'/'+c['id'],'session':c['session'],'model':model,'origin_query_ids':query_ids})
            if model=='C0':continue
            known=all(xmap[q]['pattern_known'] for q in query_ids);passed=all(xmap[q]['pattern_pass'] for q in query_ids)
            flip=not c['baseline'] and known and passed
            reason='固定81native保護' if c['baseline'] else '全origin既知かつ固定9gate成立' if flip else 'originに未知あり・native維持' if not known else '9gate不成立・native維持'
            points=[xmap[q]['range_zero'] for q in query_ids]
            point='全origin正幅' if all(v is False for v in points) else '一点域を含む' if any(v is True for v in points) else '幅未知を含む'
            point_counts[point]+=1;reason_counts[reason]+=1
            rows.append({'id':'P0/'+c['id'],'session':c['session'],'native_side':side,'selected_side':-side if flip else side,'baseline':c['baseline'],
                'action':'flip' if flip else 'keep','reason':reason,'all_origins_known':known,'all_origins_pass':passed,
                'origin_query_ids':query_ids,'origin_count':len(query_ids),'unique_query_count':len(set(query_ids)),'range_class':point})
    assert used==set(qmap) and seen_rel==set(rels) and len(entry_origins)==833 and len(rows)==752
    assert len({r['id'] for r in rows})==752 and set(r['session'] for r in rows)==set(sessions)
    assert all(r['selected_side']==r['native_side'] for r in rows if r['baseline'])
    return {'success':True,'trial':140,'sessions':sessions,'rows':rows,'entry_origins':entry_origins,
        'counts':dict(Counter(r['action'] for r in rows)),'reasons':dict(reason_counts),'range_classes':dict(point_counts),
        'join_proof':{'entries':833,'P0':752,'C0':81,'relations':850,'unique_queries':769,'reused_query_relations':850-769,'all_relations_joined':True,'all_queries_used':True},
        'all_752_kept':True,'protected_81_kept':True,'all_73_sessions':True,'labels_read':False,'learned':False}


def stream(record: dict, policy: str, axis: str, choices: dict) -> dict:
    """
    機能: 固定方向票に合う保存実正逆streamを選ぶ。
    引数: record(dict)、policy/axis(str)、choices(dict)は保存ケース等。
    返り値: dictは実観測。反転率を1-pで作らない。
    """
    assert policy in ('T0','P0','C0') and axis in ('BBO','Last')
    assert record['model']==('C0' if policy=='C0' else 'P0')
    native=record['case']['original_side'];side=choices[record['case']['id']]['selected_side'] if policy=='T0' else native
    return record['case'][('chart_' if axis=='Last' else '')+('original' if side==native else 'reverse')]
