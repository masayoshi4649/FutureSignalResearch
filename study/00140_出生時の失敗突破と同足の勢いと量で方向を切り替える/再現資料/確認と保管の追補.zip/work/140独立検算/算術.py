"""140の独立金融算術。138独立式を同体再用しRoot/124/140金融関数をimportしない。"""
import datetime
import hashlib
import math
from collections import Counter
from fractions import Fraction
from pathlib import Path
from statistics import median

POLICIES=('T0','P0','C0')
MODELS=('P0','C0')
MODEL={'T0':'P0','P0':'P0','C0':'C0'}
WIDTHS=(25,50,100,125,200)
HORIZONS=(1800,3600)
AXES=('BBO','Last')

def sha(path: Path) -> str:
    """
    機能: ファイルのSHA256を求める。
    引数: path(Path)は対象。
    返り値: strは小文字16進SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()

# ----------------------------------------
def equal(actual: object, expected: object, location: str='') -> int:
    """
    機能: 型・未知・有限数値を区別して再帰照合する。
    引数: actual/expected(object)、location(str)は実値・期待値・位置。
    返り値: intは一致した末端値の数。不一致はAssertionError。
    """
    if isinstance(expected,dict):
        assert isinstance(actual,dict) and actual.keys()==expected.keys(),(location,'keys')
        return sum(equal(actual[k],v,location+'/'+str(k)) for k,v in expected.items())
    if isinstance(expected,list):
        assert isinstance(actual,list) and len(actual)==len(expected),(location,'length')
        return sum(equal(a,b,location+'/'+str(i)) for i,(a,b) in enumerate(zip(actual,expected)))
    if expected is None or type(expected) is bool:
        assert type(actual) is type(expected) and actual==expected,(location,actual,expected)
    elif type(expected) in (int,float):
        assert type(actual) in (int,float) and math.isfinite(actual) and math.isclose(actual,expected,rel_tol=1e-12,abs_tol=1e-8),(location,actual,expected)
    else:assert actual==expected,(location,actual,expected)
    return 1

# ----------------------------------------
def observation(candidate: dict, horizon: int) -> dict:
    """
    機能: 指定期限の観測を一意に取り出す。
    引数: candidate(dict)、horizon(int)は候補と秒数。
    返り値: dictは観測。
    """
    matches=[o for o in candidate['outcomes'] if o['seconds']==horizon];assert len(matches)==1
    return matches[0]

# ----------------------------------------
def touch(outcome: dict, width: int) -> dict:
    """
    機能: 同幅の保存先着を一意に取り出す。
    引数: outcome(dict)、width(int)は観測とpt。
    返り値: dictは先着票。
    """
    matches=[t for t in outcome['touches'] if t['width']==width];assert len(matches)==1
    return matches[0]

# ----------------------------------------
def side_for(record: dict, policy: str) -> int:
    """
    機能: native又は固定方向票の向きを選ぶ。
    引数: record(dict)、policy(str)。
    返り値: intは±1。金融ラベルを方向選択に使わない。
    """
    native=record['case']['original_side']
    return record['direction']['selected_side'] if policy=='T0' else native


# ----------------------------------------
def choose(record: dict, policy: str, axis: str) -> dict:
    """
    機能: 固定票の方向に対応する保存実正逆/Last streamを選ぶ。
    引数: record(dict)、policy/axis(str)。
    返り値: dictは保存候補。反転を1−pにしない。
    """
    assert record['meta']['model']==MODEL[policy]
    native=record['case']['original_side']
    return record['case'][('chart_' if axis=='Last' else '')+('original' if side_for(record,policy)==native else 'reverse')]


# ----------------------------------------
def points(candidate: dict, quote: dict, axis: str) -> int | float:
    """
    機能: 保存清算Quoteから実側の符号付き値幅を計算する。
    引数: candidate/quote(dict)、axis(str)は取得・清算・軸。
    返り値: int|floatはpt。
    """
    side=candidate['birth']['side'];mark=quote['last'] if axis=='Last' else quote['bid'] if side>0 else quote['ask']
    return side*(mark-candidate['entry_price'])

# ----------------------------------------
def ifd(candidate: dict, horizon: int, width: int, axis: str) -> dict:
    """
    機能: 既知touch優先でIFD代用を算出し、H不足の未到達は未知にする。
    引数: candidate(dict)、horizon/width(int)、axis(str)は方向と観測条件。
    返り値: dictは既知/理由/pt/C0/C5。Lastの金額はNone。
    """
    o=observation(candidate,horizon);t=touch(o,width)
    if t['direction']:
        quote=t['quote'];reason='順行到達' if t['direction']>0 else '逆行到達'
    elif o['status']=='complete':quote=o['endpoint'];reason='期限清算'
    else:return {'known':False,'reason':'観測不足','points':None,'net0':None,'net5':None}
    assert quote is not None
    p=points(candidate,quote,axis)
    return {'known':True,'reason':reason,'points':p,
            'net0':p*100-77 if axis=='BBO' else None,'net5':p*100-1077 if axis=='BBO' else None}

# ----------------------------------------
def stats(records: list[dict], policy: str, axis: str, horizon: int, width: int) -> dict:
    """
    機能: 保存QuoteとFractionから全率/分母/利益/損失/PFを独立集計する。
    引数: records(list[dict])、policy/axis(str)、horizon/width(int)は取得集合と条件。
    返り値: dictは主算術集計。Root集計/124算術を呼ばない。
    """
    selected=[choose(r,policy,axis) for r in records]
    complete=[observation(c,horizon) for c in selected if observation(c,horizon)['status']=='complete']
    counts=Counter(touch(o,width)['direction'] for o in complete);forward=counts[1];adverse=counts[-1];resolved=forward+adverse
    exits=[ifd(c,horizon,width,axis) for c in selected];known=[e for e in exits if e['known']]
    money=[e['net5'] for e in known] if axis=='BBO' else []
    profit=sum(x for x in money if x>0);loss=-sum(x for x in money if x<0)
    return {'entries':len(records),'sessions':len({r['session'] for r in records}),
            'complete':len(complete),'censored':len(selected)-len(complete),
            'forward':forward,'adverse':adverse,'neither':counts[0],'resolved':resolved,
            'resolved_rate':float(Fraction(forward,resolved)) if resolved else None,
            'complete_rate':float(Fraction(forward,len(complete))) if complete else None,
            'target70':Fraction(forward,resolved)>=Fraction(7,10) if resolved else None,
            'target70_all':Fraction(forward,len(complete))>=Fraction(7,10) if complete else None,
            'ifd_known':len(known),'ifd_unknown':len(exits)-len(known),
            'ifd_exits':dict(Counter(e['reason'] for e in exits)),
            'ifd_net0_sum':sum(e['net0'] for e in known) if axis=='BBO' and known else None,
            'ifd_net5_sum':sum(money) if money else None,
            'ifd_net5_mean':float(Fraction(sum(money))/len(money)) if money else None,
            'ifd_net5_profit':profit if money else None,'ifd_net5_loss':loss if money else None,
            'ifd_net5_pf':float(Fraction(profit)/Fraction(loss)) if loss else None,
            'ifd_net5_positive':sum(x>0 for x in money) if axis=='BBO' else None,
            'ifd_points_mean':float(Fraction(sum(e['points'] for e in known))/len(known)) if known else None,
            'flips':sum(c['birth']['side']!=r['case']['original_side'] for c,r in zip(selected,records))}

# ----------------------------------------
def subset(records: list[dict], policy: str, sessions: list[str]) -> list[dict]:
    """
    機能: 政策が属する取得集合と場だけを選ぶ。
    引数: records(list[dict])、policy(str)、sessions(list[str])は全票・政策・場順。
    返り値: list[dict]は母集団を混ぜない部分集合。
    """
    return [r for r in records if r['meta']['model']==MODEL[policy] and r['session'] in sessions]

# ----------------------------------------
def jst(at: float) -> str:
    """
    機能: Unix秒を閲覧表の日本時間書式へ変換する。
    引数: at(float)は時刻。
    返り値: strは秒精度のJST。
    """
    return datetime.datetime.fromtimestamp(at,datetime.timezone(datetime.timedelta(hours=9))).isoformat(sep=' ')

# ----------------------------------------
def frequency(records: list[dict],sessions: list[str],scenes: list[dict]) -> dict:
    """
    機能: 全場時計の加重頻度と別の場別分布をFractionで独立計算する。
    引数: records/sessions/scenes(list)は固定取得と場時計。
    返り値: dictは勝敗を使わない頻度。
    """
    clocks={s['session']:s for s in scenes};counts=Counter((r['meta']['model'],r['session']) for r in records)
    full={sid:Fraction(clocks[sid]['end']-300-clocks[sid]['start'])/3600 for sid in sessions}
    eligible={sid:Fraction(min(clocks[sid]['force_close'],clocks[sid]['end']-3900)-clocks[sid]['start'])/3600 for sid in sessions}
    result={'定義':'全時間=sum(end-300-start)/3600。全場を残す。名目新規可時間=sum(min(force_close,end-3900)-start)/3600は副評価',
            '場別':{},'各場回数cap':False,'毎時強制':False}
    for sid in sessions:
        assert full[sid]>0 and eligible[sid]>0
        result['場別'][sid]={'全時間h':float(full[sid]),'名目新規可時間h':float(eligible[sid]),
            'models':{m:{'取得数':counts[m,sid],'全時間頻度':float(counts[m,sid]/full[sid]),'名目新規可時間頻度':float(counts[m,sid]/eligible[sid])} for m in MODELS}}
    for part,ids in (('all',sessions),('train',sessions[:48]),('validation',sessions[48:])):
        result[part]={};hours=sum(full[s] for s in ids);ehours=sum(eligible[s] for s in ids)
        for model in MODELS:
            n=sum(counts[model,s] for s in ids);rates=[counts[model,s]/full[s] for s in ids]
            result[part][model]={'対象場数':len(ids),'取得数':n,'全時間h':float(hours),'名目新規可時間h':float(ehours),
                '全時間平均件数毎時':float(n/hours),'名目新規可時間平均件数毎時':float(n/ehours),'全時間平均1件毎時以上':n/hours>=1,
                '場別頻度分布':{'最小':float(min(rates)),'中央値':float(median(rates)),'最大':float(max(rates)),
                    '単純平均_主平均ではない':float(sum(rates)/len(rates)),'0取得場数':sum(r==0 for r in rates),'1件毎時以上場数':sum(r>=1 for r in rates)}}
    return result
