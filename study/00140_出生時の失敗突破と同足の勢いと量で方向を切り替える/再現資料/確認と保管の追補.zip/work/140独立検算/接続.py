"""140の9gateと全origin方向選択を、抽出器/Root選択器をimportせず確認する純関数。"""
import math

REQUIRED=('latest_5_fresh','four_consecutive','four_prices_known','native_extreme_outside','close_inside',
          'opposite_body','histogram_weakening','same_bar_volume','birth_last_inside')


def finite(value: object) -> bool:
    """
    機能: boolを除いた有限数値を判定する。
    引数: value(object)。
    返り値: bool。
    """
    return type(value) in (int,float) and math.isfinite(value)


# ----------------------------------------
def known_value(value: dict) -> tuple:
    """
    機能: 既知0と未知nullを分ける。
    引数: value(dict)はknown/valueの保存票。
    返り値: tuple[bool,float|None]。
    """
    assert type(value['known']) is bool
    if value['known']:assert finite(value['value'])
    else:assert value['value'] is None
    return value['known'],value['value']


# ----------------------------------------
def expected_gates(row: dict) -> dict:
    """
    機能: 保存された同足/直前足・出生Lastから必須9gateだけを独立再計算する。
    引数: row(dict)は非金融の一出生抽出票。
    返り値: dictは9条件のknown/pass。Rawから履歴全体を再生成しない。
    """
    feet=row['feet'];birth=row['birth_stamp'];side=row['side'];assert side in (-1,1) and finite(row['birth_last'])
    assert 0<=len(feet)<=4
    for i,foot in enumerate(feet):
        assert foot['role']=='b_minus_'+str(i)
        ref=foot['ref'];delivered=ref['delivered']
        assert ref['end']<=foot['available_at']<=foot['delivery_at']<=delivered['time']<=birth['time']
        assert all(delivered[k]<=birth[k] for k in ('index','source_line'))
        assert type(foot['price_known']) is bool and type(foot['volume_known']) is bool
        if foot['price_known']:
            q=foot['ohlc'];assert q is not None and all(finite(q[k]) for k in ('open','high','low','close'))
            assert q['low']<=min(q['open'],q['close'])<=max(q['open'],q['close'])<=q['high']
        else:assert foot['ohlc'] is None
        known_value(foot['volume']);known_value(foot['histogram'])
    fresh=bool(feet) and any(ref==feet[0]['ref'] for ref in row['refs']) and birth['time']<feet[0]['ref']['end']+360
    gates={k:{'known':False,'pass':False} for k in REQUIRED}
    gates['latest_5_fresh']={'known':True,'pass':fresh}
    if not fresh:return gates
    b=feet[0]
    if b['price_known']:
        q=b['ohlc'];gates['opposite_body']={'known':True,'pass':side*(q['close']-q['open'])<0}
    contiguous=len(feet)==4 and all(f['ref']['width_seconds']==300 and f['ref']['end']-f['start']==300 for f in feet)
    contiguous=contiguous and all(feet[i]['start']==feet[i+1]['ref']['end'] for i in range(len(feet)-1))
    gates['four_consecutive']={'known':True,'pass':contiguous}
    if not contiguous:return gates
    prev=feet[1];price=all(f['price_known'] for f in feet)
    gates['four_prices_known']={'known':True,'pass':price}
    bk,bv=known_value(b['volume']);pk,pv=known_value(prev['volume'])
    if bk and pk:gates['same_bar_volume']={'known':True,'pass':pv>0 and bv>=pv}
    bk,bh=known_value(b['histogram']);pk,ph=known_value(prev['histogram'])
    if bk and pk:gates['histogram_weakening']={'known':True,'pass':side*(bh-ph)<0}
    if price:
        low=min(f['ohlc']['low'] for f in feet[1:]);high=max(f['ohlc']['high'] for f in feet[1:]);q=b['ohlc']
        gates['native_extreme_outside']={'known':True,'pass':q['high']>high if side>0 else q['low']<low}
        gates['close_inside']={'known':True,'pass':low<=q['close']<=high}
        gates['birth_last_inside']={'known':True,'pass':low<=row['birth_last']<=high}
    return gates


# ----------------------------------------
def pattern(row: dict) -> tuple:
    """
    機能: 保存known/passと独立9gate、summaryの一致を確認する。
    引数: row(dict)は非金融抽出票。
    返り値: tuple[bool,bool]は全gate既知/全gate成立。
    """
    expected=expected_gates(row)
    for key,value in expected.items():
        actual=row['gates'][key]
        assert type(actual['known']) is bool and type(actual['pass']) is bool and actual==value,(row.get('id'),key,actual,value)
    known=all(g['known'] for g in expected.values());passed=all(g['known'] and g['pass'] for g in expected.values())
    assert type(row['pattern_known']) is bool and row['pattern_known']==known
    assert type(row['pattern_pass']) is bool and row['pattern_pass']==passed
    return known,passed


# ----------------------------------------
def vote(native: int,baseline: bool,origins: list) -> tuple:
    """
    機能: 全originの9gate既知成立だけ反転し、旧81/未知/不成立は保持する。
    引数: native(int)、baseline(bool)、origins(list[dict])。
    返り値: tuple[int,bool,bool]は選択方向・全origin既知・全origin成立。
    """
    assert native in (-1,1) and type(baseline) is bool and origins
    statuses=[pattern(row) for row in origins]
    known=all(k for k,p in statuses);passed=all(k and p for k,p in statuses)
    return (-native if passed and not baseline else native),known,passed
