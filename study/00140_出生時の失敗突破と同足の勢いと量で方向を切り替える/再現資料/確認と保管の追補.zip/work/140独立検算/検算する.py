"""140の固定9gate接続と保存実正逆を独立確認する。Root/124/140金融関数はimportしない。"""
from pathlib import Path
from collections import Counter
import argparse
import hashlib
import importlib.util
import json

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent

def own(name: str, filename: str) -> object:
    """
    機能: 同folderの独立部品だけを読み込む。
    引数: name/filename(str)。返り値: objectは独立module。
    """
    spec=importlib.util.spec_from_file_location(name,HERE/filename);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

M=own('140独立金融算術','算術.py')
LINK=own('140独立9gate','接続.py')
BOUND=own('140抽象算術','上限を検証する.py')
FIXED=('work/138全成立入口の評価/固定入力_版2/固定取得入力.json','0c83e525dec3079ce188d942069c0d137c94f39009339752ec8227ec9ecb4ce7')
META=('work/138全成立入口の評価/固定入力_版2/入口参照.json','75e4993571bdef17839aad3324acc6ee9ce09b3cb1f4ecad70637a1e01ccefd0')
MANIFEST=('work/全成立poolの非金融manifest/manifest.json','e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35')
QUERIES=('work/138全成立入口の評価/固定入力_版2/特徴照会.json','81442c3ebaa3065213d0844417bb0462cfa3e5d0a05c4f44edfb3fb14191e75c')
OBSERVED=('work/138全成立入口の評価/固定取得の正逆観測.json','d272fc6f6768342ff67e1a9ec58b0b7307a0a5b07cc215ba5ff7bcb50865b742')
OLD138=('work/138全成立入口と頻度の集計/集計.json','6ef283db667603884b42260affce732ba5c9b31731d24b1bb18f9e96ee4b3486')
MODEL_SHA='6199368c51ff7e158e71b3bcd2b518137d7a40825f8a827625d3ccd235b92f7e'

def validate_stream(stream: dict, entry: dict, side: int, axis: str, boundary: float) -> dict:
    """
    機能: 保存Quoteの価格・方向・H・ザラバ境界と金額を独立式で確認する。
    引数: stream/entry(dict)、side(int)、axis(str)、boundary(float)。
    返り値: dictはstream/entry/endpoint/touch検査数。Rawの初回touchを再走査しない。
    """
    assert stream['status'] == 'filled' and stream['birth']['side'] == side and stream['entry'] == entry
    assert entry['quote_ok'] and 0 < entry['bid'] < entry['ask'] and entry['last'] > 0
    assert stream['entry_price'] == (entry['last'] if axis == 'Last' else entry['ask'] if side > 0 else entry['bid'])
    assert tuple(o['seconds'] for o in stream['outcomes']) == M.HORIZONS
    count = Counter({'stream検査': 1, 'entry検査': 1})
    for o in stream['outcomes']:
        assert o['deadline'] == entry['time'] + o['seconds']
        assert tuple(t['width'] for t in o['touches']) == M.WIDTHS
        assert (o['endpoint'] is not None) == (o['status'] == 'complete')
        q = o['endpoint']
        if q is not None:
            assert o['deadline'] <= q['time'] <= o['deadline'] + 30 and q['time'] < boundary
            assert q['index'] > entry['index'] and q['source_line'] > entry['source_line']
            assert q['quote_ok'] and 0 < q['bid'] < q['ask'] and q['last'] > 0
            value = M.points(stream, q, axis)
            M.equal(o['points'], value)
            M.equal(o['net0'], value * 100 - 77 if axis == 'BBO' else None)
            M.equal(o['net5'], value * 100 - 1077 if axis == 'BBO' else None)
            count['endpoint検査'] += 1
        else:
            assert o['points'] is None and o['net0'] is None and o['net5'] is None
        for t in o['touches']:
            assert type(t['direction']) is int and t['direction'] in (-1, 0, 1)
            q = t['quote']; assert (q is None) == (t['direction'] == 0)
            if q is None:
                continue
            assert entry['time'] <= q['time'] <= o['deadline'] and q['time'] < boundary
            assert q['index'] > entry['index'] and q['source_line'] > entry['source_line']
            assert q['quote_ok'] and 0 < q['bid'] < q['ask'] and q['last'] > 0
            value = M.points(stream, q, axis)
            assert value >= t['width'] if t['direction'] > 0 else value <= -t['width']
            count['touch検査'] += 1
    return dict(count)

# ----------------------------------------
def join(result: dict, fixed: dict, meta: dict, manifest: dict) -> tuple:
    """
    機能: 833取得とnative方向・由来・4価格streamを結合し、区間を点検する。
    引数: result/fixed/meta/manifest(dict)は固定済み票。
    返り値: tupleは全records・場順・phase件数。
    """
    assert result['success'] and result['trial'] == 133 and result['source_entry_count'] == 833
    assert fixed['expected_entry_count'] == 833 and meta['trial'] == 138 and meta['success']
    assert meta['fixed_input_sha256'] == result['input_sha256'] == FIXED[1]
    assert meta['manifest_sha256'] == MANIFEST[1]
    mmap = {(e['session'], e['id']): e for e in meta['entries']}
    assert len(mmap) == 833 and Counter(e['model'] for e in meta['entries']) == {'C0': 81, 'P0': 752}
    records = []; sessions = []; seen = set(); counts = Counter()
    assert len(result['scenes']) == len(fixed['scenes']) == 73
    for scene, source in zip(result['scenes'], fixed['scenes']):
        sid = scene['session']; sessions.append(sid)
        assert sid == source['session'] and scene['success']
        boundary = source['end'] - 300; limit = min(source['force_close'], boundary - 3600)
        assert scene['execution_end'] == boundary and scene['effective_entry_limit'] == limit
        assert scene['source_force_close'] == source['force_close']
        assert scene['quality'] == scene['expected_quality'] == source['expected_quality']
        assert scene['actual_sha256'] == source['raw']['sha256']
        assert scene['stat_before'] == scene['stat_after']
        inputs = {e['id']: e for e in source['entries']}; assert len(inputs) == len(scene['cases'])
        for case in scene['cases']:
            key = sid, case['id']; assert key in mmap and key not in seen; seen.add(key)
            m = mmap[key]; original = inputs[case['id']]; entry = original['entry']
            assert m['model'] in M.MODELS and m['contract'] == source['contract']
            assert case['original_side'] == original['side'] == m['selected_side']
            assert source['start'] <= entry['time'] < limit and entry['clock']
            origin = manifest[m['model']][m['manifest_index']]
            assert origin['id'] == m['candidate_id'] and origin['session'] == sid and origin['contract'] == source['contract']
            assert origin['side'] == m['selected_side'] and origin['baseline'] == m['baseline']
            assert m['origin_count'] == len(origin['origins'])
            assert sorted(m['origin_families']) == sorted({o['family'] for o in origin['origins']})
            for field in ('time', 'index', 'source_line', 'last', 'bid', 'ask', 'quote_ok'):
                assert entry[field] == origin['entryQuote'][field]
            clocks = {o['entryQuote']['clock'] for o in origin['origins']}
            assert clocks == {entry['clock']}
            for name in ('original', 'reverse', 'chart_original', 'chart_reverse'):
                side = case['original_side'] * (1 if name.endswith('original') else -1)
                counts.update(validate_stream(case[name], entry, side, 'Last' if name.startswith('chart_') else 'BBO', boundary))
            records.append({'session': sid, 'case': case, 'meta': m, 'canonical': origin, 'scene': source})
    assert len(sessions) == len(set(sessions)) == 73 and seen == set(mmap)
    for model in M.MODELS:
        stamps = [(r['session'], tuple(r['case']['original']['entry'][k] for k in ('time', 'index', 'source_line'))) for r in records if r['meta']['model'] == model]
        assert len(stamps) == len(set(stamps))
    return records, sessions, dict(counts)

# ----------------------------------------
def calculate(records: list, sessions: list, scenes: list) -> tuple:
    """
    機能: 独自式で全180条件・参加・頻度・主評価を計算する。
    引数: records/sessions/scenes(list)は固定票・全場順・時計。
    返り値: tupleは集計/参加/頻度/主評価。
    """
    parts = {'all': sessions, 'train': sessions[:48], 'validation': sessions[48:]}
    values = {}; participation = {}
    for part, ids in parts.items():
        participation[part] = {}; values[part] = {}
        for model in M.MODELS:
            rows = [r for r in records if r['meta']['model'] == model and r['session'] in ids]
            missing = [sid for sid in ids if not any(r['session'] == sid for r in rows)]
            participation[part][model] = {'対象場数': len(ids), '取得数': len(rows), '取得場数': len(ids) - len(missing),
                '未取得場数': len(missing), '未取得場': missing, '全場最低1取得': not missing and bool(ids)}
        for policy in M.POLICIES:
            values[part][policy] = {axis: {str(h): {str(w): M.stats(M.subset(records, policy, ids), policy, axis, h, w)
                for w in M.WIDTHS} for h in M.HORIZONS} for axis in M.AXES}
    freq = M.frequency(records, sessions, scenes)
    freq['定義'] = '全時間=sum(end-300-start)/3600。名目新規可時間=sum(min(force_close,end-3900)-start)/3600は副評価'
    s = values['all']['P0']['BBO']['3600']['125']; p = participation['all']['P0']
    rate = s['target70'] is True; hourly = freq['all']['P0']['全時間平均1件毎時以上']
    goal = {'主': 'P0/native/全73場/実BBO/H60/±125pt', '全73場最低1取得': p['全場最低1取得'],
        '到達済み先着70%以上': rate, '入口品質の両条件達成': bool(p['全場最低1取得'] and rate),
        '全時間平均1件毎時以上': hourly, '三項目すべて達成': bool(p['全場最低1取得'] and rate and hourly),
        '順': s['forward'], '逆': s['adverse'], '未到達': s['neither'], '全H不足': s['censored'],
        '到達済み率': s['resolved_rate'], '完了分母率': s['complete_rate'],
        '全件分母率': s['forward'] / s['entries'] if s['entries'] else None,
        '全時間平均件数毎時': freq['all']['P0']['全時間平均件数毎時'], '参加': p}
    return values, participation, freq, goal

# ----------------------------------------
def tables_check(tables: list, records: list, sessions: list, values: dict, participation: dict, freq: dict) -> dict:
    """
    機能: 金融前に合意した三表の独立期待値を照合する。
    引数: tables/records/sessions(list)、values/participation/freq(dict)。
    返り値: dictは三表39685セルの確認。実CSVの再読・描画は別検査。
    """
    expected_headers = [
        ['試行','区分','政策','取得集合','価格軸','評価分','同幅pt','対象場数','取得場数','取得数',
         'native向きからの反転数','全場最低1取得','全H完了','観測不足','順行先着','逆行先着','両方未到達',
         '到達済み順行率','完了分母順行率','全取得分母順行率','到達済み70%達成','参加と70%両達成',
         '全時間平均件数毎時','名目新規可時間平均件数毎時','全時間平均1件毎時以上','参加と70%と頻度すべて達成',
         'IFD代用既知','IFD代用未知','C0代用差引円','C5代用利益円','C5代用損失絶対円','C5代用差引円','C5代用平均円','C5代用PF'],
        ['試行','参考区分','セッション','取得集合','固定取得ID','候補ID','native方向','固定対照由来','origin数',
         'origin系統','origin版','初期親数','親種別','取得JST','元取得価格','逆取得価格','H60新規限界JST','原板SHA256'],
        ['試行','セッション','参考区分','ザラバ時間h','名目新規可時間h'],
    ]
    for policy in M.POLICIES:
        expected_headers[1] += [policy + s for s in ('方向','125全H','125先着','IFD既知','清算','125C5代用円')]
    for suffix in ('取得数','最低1取得','全時間頻度','名目新規可時間頻度'):
        expected_headers[2] += [m + suffix for m in ('P0','C0')]
    for policy in M.POLICIES:
        expected_headers[2] += [policy + s for s in ('反転数','125順','125逆','125未到達','全H不足','IFD既知','IFD未知',
            'C5利益円','C5損失絶対円','C5既知差引円','C5既知累計円_口座収支ではない','累計IFD未知')]
    assert [(t['name'], len(t['rows']), len(t['headers'])) for t in tables] == [('正逆比較',180,34),('入口別診断',833,36),('全セッション',73,49)]
    assert [t['headers'] for t in tables] == expected_headers
    count = 0; seen = set()
    for row in tables[0]['rows']:
        actual = dict(zip(tables[0]['headers'], row)); part = actual['区分']; policy = actual['政策']
        axis = actual['価格軸']; h = int(actual['評価分'] * 60); w = actual['同幅pt']
        key = part, policy, axis, h, w; assert key not in seen; seen.add(key)
        s = values[part][policy][axis][str(h)][str(w)]
        p = participation[part][M.MODEL[policy]]; f = freq[part][M.MODEL[policy]]
        quality = bool(p['全場最低1取得'] and s['target70'] is True)
        expected = {'試行':140,'区分':part,'政策':policy,'取得集合':M.MODEL[policy],'価格軸':axis,'評価分':h/60,'同幅pt':w,
            '対象場数':p['対象場数'],'取得場数':s['sessions'],'取得数':s['entries'],'native向きからの反転数':s['flips'],
            '全場最低1取得':p['全場最低1取得'],'全H完了':s['complete'],'観測不足':s['censored'],
            '順行先着':s['forward'],'逆行先着':s['adverse'],'両方未到達':s['neither'],'到達済み順行率':s['resolved_rate'],
            '完了分母順行率':s['complete_rate'],'全取得分母順行率':s['forward']/s['entries'] if s['entries'] else None,
            '到達済み70%達成':s['target70'],'参加と70%両達成':quality,'全時間平均件数毎時':f['全時間平均件数毎時'],
            '名目新規可時間平均件数毎時':f['名目新規可時間平均件数毎時'],'全時間平均1件毎時以上':f['全時間平均1件毎時以上'],
            '参加と70%と頻度すべて達成':quality and f['全時間平均1件毎時以上'], 'IFD代用既知':s['ifd_known'],
            'IFD代用未知':s['ifd_unknown'],'C0代用差引円':s['ifd_net0_sum'],'C5代用利益円':s['ifd_net5_profit'],
            'C5代用損失絶対円':s['ifd_net5_loss'],'C5代用差引円':s['ifd_net5_sum'],'C5代用平均円':s['ifd_net5_mean'],'C5代用PF':s['ifd_net5_pf']}
        count += M.equal(actual, expected, '比較表/' + str(key))
    assert seen == {(part,p,a,h,w) for part in ('all','train','validation') for p in M.POLICIES for a in M.AXES for h in M.HORIZONS for w in M.WIDTHS}
    assert [r[tables[1]['headers'].index('固定取得ID')] for r in tables[1]['rows']] == [r['case']['id'] for r in records]
    for raw_row, record in zip(tables[1]['rows'], records):
        m = record['meta']; c = record['case']; origin = record['canonical']; scene = record['scene']
        parents = {tuple(o['position_origin']['parent_key']) for o in origin['origins'] if 'parent_key' in o['position_origin']}
        kinds = sorted({o['position_origin']['initial_or_add'] for o in origin['origins'] if o['position_origin'].get('initial_or_add') is not None})
        expected = {'試行':140,'参考区分':'train' if record['session'] in sessions[:48] else 'validation',
            'セッション':record['session'],'取得集合':m['model'],'固定取得ID':c['id'],'候補ID':m['candidate_id'],
            'native方向':c['original_side'],'固定対照由来':m['baseline'],'origin数':m['origin_count'],
            'origin系統':'|'.join(sorted({o['family'] for o in origin['origins']})),
            'origin版':'|'.join(sorted({o['variant'] for o in origin['origins']})), '初期親数':len(parents),'親種別':'|'.join(kinds),
            '取得JST':M.jst(c['original']['entry']['time']),'元取得価格':c['original']['entry_price'],'逆取得価格':c['reverse']['entry_price'],
            'H60新規限界JST':M.jst(min(scene['force_close'],scene['end']-3900)),'原板SHA256':scene['raw']['sha256']}
        for policy in M.POLICIES:
            names = [policy + s for s in ('方向','125全H','125先着','IFD既知','清算','125C5代用円')]
            if m['model'] != M.MODEL[policy]:
                expected.update(dict.fromkeys(names, None)); continue
            chosen = M.choose(record, policy, 'BBO'); o = M.observation(chosen, 3600); exit = M.ifd(chosen,3600,125,'BBO')
            expected.update(zip(names, [chosen['birth']['side'],o['status'],M.touch(o,125)['direction'],exit['known'],exit['reason'],exit['net5']]))
        count += M.equal(dict(zip(tables[1]['headers'],raw_row)),expected,'入口表/'+c['id'])
    assert [r[tables[2]['headers'].index('セッション')] for r in tables[2]['rows']] == sessions
    cumulative = Counter(); unknown = Counter()
    for i, (raw_row, sid) in enumerate(zip(tables[2]['rows'], sessions)):
        f = freq['場別'][sid]
        expected = {'試行':140,'セッション':sid,'参考区分':'train' if i<48 else 'validation',
            'ザラバ時間h':f['全時間h'],'名目新規可時間h':f['名目新規可時間h']}
        for model in M.MODELS:
            v = f['models'][model]
            expected.update({model+'取得数':v['取得数'],model+'最低1取得':bool(v['取得数']),
                model+'全時間頻度':v['全時間頻度'],model+'名目新規可時間頻度':v['名目新規可時間頻度']})
        for policy in M.POLICIES:
            s = M.stats(M.subset(records,policy,[sid]),policy,'BBO',3600,125)
            cumulative[policy] += s['ifd_net5_sum'] or 0; unknown[policy] += s['ifd_unknown']
            expected.update({policy+'反転数':s['flips'],policy+'125順':s['forward'],policy+'125逆':s['adverse'],
                policy+'125未到達':s['neither'],policy+'全H不足':s['censored'],policy+'IFD既知':s['ifd_known'],
                policy+'IFD未知':s['ifd_unknown'],policy+'C5利益円':s['ifd_net5_profit'],policy+'C5損失絶対円':s['ifd_net5_loss'],
                policy+'C5既知差引円':s['ifd_net5_sum'],policy+'C5既知累計円_口座収支ではない':cumulative[policy],policy+'累計IFD未知':unknown[policy]})
        count += M.equal(dict(zip(tables[2]['headers'],raw_row)),expected,'場表/'+sid)
    assert count == 39685
    return {'success':True,'table_dimensions':[[180,34],[833,36],[73,49]],'all_data_cells_equal':count,'actual_csv_reread_or_render':False}


# ----------------------------------------
def nonfinancial(manifest: dict, queries: dict, extracted: dict, choices: dict, model: dict) -> dict:
    """
    機能: 769出生の9gateと850由来を別実装で結び全752方向/81保護を照合する。
    引数: manifest/queries/extracted/choices/model(dict)は非金融固定票。
    返り値: dictは接続検査数とMによる楽観上限。個別金融ラベルは使わない。
    """
    assert model['learned'] is False and model['required_gates']==list(LINK.REQUIRED)
    assert model['entries']==752 and model['protected_baseline']==81 and model['unknown']=='keep'
    assert extracted['success'] and extracted['required_gates']==list(LINK.REQUIRED)
    assert extracted['financial_labels_used'] is False and extracted['entry_prices_used'] is False and extracted['entry_direction_choices_created'] is False
    assert extracted['queries_sha256']==QUERIES[1] and extracted['source_scene_count']==73 and extracted['source_publication_count']==12794 and extracted['source_relation_count']==850
    qmap={q['id']:q for q in queries['queries']};xmap={r['id']:r for r in extracted['rows']}
    assert len(qmap)==len(xmap)==769 and set(qmap)==set(xmap)
    for qid,q in qmap.items():
        r=xmap[qid];assert all(r[k]==q[k] for k in ('id','session','contract','side'))
        assert r['birth_stamp']=={k:q['birthQuote'][k] for k in ('time','index','source_line')} and r['birth_last']==q['birthQuote']['last']
        LINK.pattern(r)
    relations={(r['model'],r['manifest_index'],r['origin_index']):r for r in queries['relations']}
    assert len(relations)==850
    actual={r['id']:r for r in choices['rows']};assert len(actual)==len(choices['rows'])==752
    seen=set();used=set();origins=[];changes=0;range_counts=Counter();reason_counts=Counter()
    for kind in ('C0','P0'):
        for index,c in enumerate(manifest[kind]):
            ids=[]
            for oi,o in enumerate(c['origins']):
                birth=o['birthQuote'];stamp=tuple(birth[k] for k in ('time','index','source_line'))
                encoded=json.dumps([o['source_file_sha'],o['source_locator'],o['side'],stamp],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
                qid='origin/'+hashlib.sha256(encoded).hexdigest()[:32];q=qmap[qid]
                assert q=={'id':qid,'session':c['session'],'contract':c['contract'],'side':o['side'],'birthQuote':{k:birth[k] for k in ('time','index','source_line','last')}}
                relkey=kind,index,oi
                assert relations[relkey]=={'entry_id':kind+'/'+c['id'],'query_id':qid,'model':kind,'manifest_index':index,'origin_index':oi,
                    'family':o['family'],'side':o['side'],'selected_side':c['side']}
                assert all(birth[k]<=c['entryQuote'][k] for k in ('time','index','source_line'))
                assert all(o['entryQuote'][k]==c['entryQuote'][k] for k in ('time','index','source_line','last','bid','ask','quote_ok'))
                if not c['baseline']:assert o['side']==c['side']
                ids.append(qid);seen.add(relkey);used.add(qid)
            origins.append({'id':kind+'/'+c['id'],'session':c['session'],'model':kind,'origin_query_ids':ids})
            if kind=='C0':continue
            selected,known,passed=LINK.vote(c['side'],c['baseline'],[xmap[q] for q in ids]);flip=selected!=c['side'];changes+=flip
            zero=[xmap[q]['range_zero'] for q in ids]
            range_class='全origin正幅' if all(v is False for v in zero) else '一点域を含む' if any(v is True for v in zero) else '幅未知を含む'
            reason='固定81native保護' if c['baseline'] else '全origin既知かつ固定9gate成立' if flip else 'originに未知あり・native維持' if not known else '9gate不成立・native維持'
            expected={'id':'P0/'+c['id'],'session':c['session'],'native_side':c['side'],'selected_side':selected,'baseline':c['baseline'],
                'action':'flip' if flip else 'keep','reason':reason,'all_origins_known':known,'all_origins_pass':passed,'origin_query_ids':ids,
                'origin_count':len(ids),'unique_query_count':len(set(ids)),'range_class':range_class}
            M.equal(actual[expected['id']],expected,'非金融方向/'+expected['id']);range_counts[range_class]+=1;reason_counts[reason]+=1
    assert seen==set(relations) and used==set(qmap) and choices['entry_origins']==origins
    assert choices['all_752_kept'] and choices['protected_81_kept'] and choices['all_73_sessions'] and choices['labels_read'] is False and choices['learned'] is False
    assert choices['counts']==dict(Counter(r['action'] for r in actual.values()))
    M.equal(choices['range_classes'],dict(range_counts));M.equal(choices['reasons'],dict(reason_counts))
    assert sum(r['baseline'] for r in actual.values())==81 and all(r['selected_side']==r['native_side'] for r in actual.values() if r['baseline'])
    return {'成功':True,'独立9gate出生':769,'由来結合':850,'入口結合':833,'P0方向':752,'旧81保護':True,
        '実変更canonical数M':changes,'M変更の楽観上限':float(BOUND.upper_rate(326,297,changes)),'70へ必要な楽観最小M':BOUND.lower_changes(326,297),
        '変更規模だけで70に届く余地':BOUND.upper_rate(326,297,changes)>=BOUND.Fraction(7,10),
        '個別counterfactualの順位付け':False,'判定で使う必須gate':list(LINK.REQUIRED)}


# ----------------------------------------
def main() -> None:
    """
    機能: Root通知のSHA確認後に非金融票と全180条件/三表を独立照合する。
    引数: CLI f1/extracted/choices/model/aggregate/tablesと各SHA。
    返り値: None。新Raw/Source/金融観測/CSVやモデル学習はしない。
    """
    parser=argparse.ArgumentParser()
    for name in ('f1','extracted','choices','model','aggregate','tables'):
        parser.add_argument('--'+name,type=Path,required=True);parser.add_argument('--'+name+'-sha256',required=True)
    args=parser.parse_args();paths={n:(getattr(args,n).resolve(),getattr(args,n+'_sha256')) for n in ('f1','extracted','choices','model','aggregate','tables')}
    paths.update({k:(ROOT/p,h) for k,(p,h) in {'fixed':FIXED,'metadata':META,'manifest':MANIFEST,'queries':QUERIES,'observed':OBSERVED,'old138':OLD138}.items()})
    assert paths['model'][1]==MODEL_SHA and all(M.sha(p)==h for p,h in paths.values())
    load=lambda name:json.loads(paths[name][0].read_text('utf-8-sig'))
    f1=load('f1');declared={Path(p).resolve():h for p,h in f1['ファイル'].items()}
    for key in ('fixed','metadata','manifest','queries','observed','old138','model','choices','extracted'):
        p,h=paths[key];assert declared[p]==h
    selected=load('choices');assert selected['model_sha256']==MODEL_SHA and selected['extracted_sha256']==paths['extracted'][1]
    assert selected['queries_sha256']==QUERIES[1] and selected['manifest_sha256']==MANIFEST[1]
    manifest,queries,extracted=load('manifest'),load('queries'),load('extracted')
    bridge=nonfinancial(manifest,queries,extracted,selected,load('model'))
    # ----------------------------------------
    # 非金融9gate/全由来/方向票を確認した後にだけ、Root通知済み金融本文を開きます。
    fixed,metadata,observed=load('fixed'),load('metadata'),load('observed')
    records,sessions,phase=join(observed,fixed,metadata,manifest)
    choices={r['id']:r for r in selected['rows']}
    for r in records:
        if r['meta']['model']=='P0':r['direction']=choices[r['case']['id']]
    values,participation,freq,_=calculate(records,sessions,fixed['scenes'])
    aggregate=load('aggregate');assert aggregate['成功'] and aggregate['試行']==140 and aggregate['主政策']=='T0'
    assert aggregate['F1_SHA256']==paths['f1'][1] and aggregate['モデルSHA256']==MODEL_SHA and aggregate['方向SHA256']==paths['choices'][1] and aggregate['抽出SHA256']==paths['extracted'][1]
    leaves=M.equal(aggregate['集計'],values,'全180条件');M.equal(aggregate['参加'],participation);M.equal(aggregate['頻度'],freq);M.equal(aggregate['全4streamのphase検査'],phase)
    s=values['all']['T0']['BBO']['3600']['125'];p=participation['all']['P0'];f=freq['all']['P0']
    goal={'政策':'T0','順':s['forward'],'逆':s['adverse'],'未到達':s['neither'],'観測不足':s['censored'],
        '到達済み率':s['resolved_rate'],'70%以上':s['target70'],'取得数':752,'全73場最低1':p['全場最低1取得'],
        '全時間平均件数毎時':f['全時間平均件数毎時'],'参加と70%と頻度すべて達成':p['全場最低1取得'] and s['target70'] is True and f['全時間平均1件毎時以上']}
    M.equal(aggregate['主評価'],goal);M.equal(aggregate['方向件数'],selected['counts']);M.equal(aggregate['価格域区分'],selected['range_classes']);M.equal(aggregate['非金融結合'],selected['join_proof'])
    assert aggregate['学習'] is False and aggregate['未知期検証'] is False and aggregate['新Raw走査'] is False and aggregate['口座損益'] is False
    old=load('old138');native_conditions=0
    for part in ('all','train','validation'):
        for policy in ('P0','C0'):
            M.equal(values[part][policy],old['集計'][part][policy],'旧138native');native_conditions+=20
    assert native_conditions==120
    M.equal(aggregate['旧138native同体'],{'成功':True,'P0旧60条件':60,'C0旧60条件':60,'合計':120})
    M.equal(aggregate['旧C0同体'],old['旧C0同体'])
    table_proof=tables_check(load('tables')['tables'],records,sessions,values,participation,freq)
    assert all(M.sha(p)==h for p,h in paths.values())
    proof={'success':True,'trial':140,'nonfinancial':bridge,'condition_count':180,'aggregate_leaf_values_checked':leaves,
        'table_checks':table_proof,'native_conditions_identical':120,'phase_checks':phase,'main':s,
        'main_policies':{p:values['all'][p]['BBO']['3600']['125'] for p in M.POLICIES},'front48':values['train']['T0']['BBO']['3600']['125'],
        'back25':values['validation']['T0']['BBO']['3600']['125'],'source_hashes_before_after_equal':True,'sources':{str(p):h for p,h in paths.values()},
        'Root_124_140_arithmetic_or_choice_imported':False,'raw_CSV_additional2_read':False,'individual_labels_ranked':False,'actual_csv_reread_or_render':False,
        '抽象算術と9gate/金融式は結果通知前に準備':True,'CLI/schema接続は全体結果通知後かつ個別金融本文読取前に完成':True,
        'Root金融/抽出/方向票作者':False,'Source条件/固定/正式を変更':False,
        'own_code_sha256':{p.name:M.sha(p) for p in (HERE/'算術.py',HERE/'接続.py',HERE/'検算する.py',HERE/'人工検査.py')}}
    out=HERE/'独立確認.json';assert not out.exists();out.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'proof_SHA256':M.sha(out),'非金融':bridge,'主':s,'表':table_proof},ensure_ascii=False))


if __name__=='__main__':main()
