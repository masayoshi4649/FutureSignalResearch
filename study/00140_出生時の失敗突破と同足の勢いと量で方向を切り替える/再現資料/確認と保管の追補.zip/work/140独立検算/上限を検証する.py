"""個別の金融ラベルを開かず、固定752取得で70%へ届く方向変更数の楽観下限を検証する。"""
from pathlib import Path
from fractions import Fraction
from math import ceil
import itertools
import hashlib
import json

HERE=Path(__file__).resolve().parent


def upper_rate(forward: int, adverse: int, changes: int) -> Fraction:
    """
    機能: M変更が全て逆→順になる楽観的な到達済み率上限を求める。
    引数: forward/adverse/changes(int)は元H完了先着数と変更canonical数。
    返り値: Fractionはmin(1,(forward+changes)/(forward+adverse))。
    """
    assert min(forward,adverse,changes)>=0 and forward+adverse>0
    return min(Fraction(1),Fraction(forward+changes,forward+adverse))


# ----------------------------------------
def lower_changes(forward: int, adverse: int, target: Fraction=Fraction(7,10)) -> int:
    """
    機能: 方向だけの変更で目標率へ届くための楽観的な必要最小件数を求める。
    引数: forward/adverse(int)、target(Fraction)。
    返り値: intはceil(target*(forward+adverse)-forward)の非負値。
    """
    assert 0<target<=1 and min(forward,adverse)>=0 and forward+adverse>0
    return max(0,ceil(target*(forward+adverse)-forward))


# ----------------------------------------
def artificial() -> int:
    """
    機能: 未到達への変化も含む小型全列挙で、分母変化時にも上限が安全か確認する。
    引数: なし。
    返り値: intは検査した変更ラベル列の数。自然結果を読まない。
    """
    checks=0
    for f,a,n in itertools.product(range(4),range(1,4),range(3)):
        original=(1,)*f+(-1,)*a+(0,)*n
        for m in range(min(a,3)+1):
            best=Fraction(0)
            for indices in itertools.combinations(range(len(original)),m):
                options=[tuple(x for x in (-1,0,1) if x!=original[i]) for i in indices]
                for labels in itertools.product(*options):
                    changed=list(original)
                    for i,v in zip(indices,labels):changed[i]=v
                    ff=changed.count(1);aa=changed.count(-1);checks+=1
                    if ff+aa:
                        rate=Fraction(ff,ff+aa);assert rate<=upper_rate(f,a,m);best=max(best,rate)
            assert best==upper_rate(f,a,m)
    assert lower_changes(326,297)==111
    assert upper_rate(326,297,110)<Fraction(7,10)<=upper_rate(326,297,111)
    return checks


# ----------------------------------------
def main() -> None:
    """
    機能: 既存総数326/297/76/53だけを使い、111変更下限とM別上限を保存する。
    引数: なし。
    返り値: None。個別counterfactual/新金融/原板/CSV/追加2場を読まない。
    """
    checks=artificial();forward,adverse,neither,censored=326,297,76,53
    assert forward+adverse+neither+censored==752
    needed=lower_changes(forward,adverse)
    table=[{'M':m,'楽観的到達済み率':float(upper_rate(forward,adverse,m)),
        '率の分子':upper_rate(forward,adverse,m).numerator,'率の分母':upper_rate(forward,adverse,m).denominator,
        '70%へ理論上到達可能':upper_rate(forward,adverse,m)>=Fraction(7,10)} for m in (0,1,5,10,25,50,75,100,110,111)]
    proof={'成功':True,'段階':'140金融前の抽象算術','元取得':752,'順':forward,'逆':adverse,'未到達':neither,'H不足':censored,
        '元H完了到達済み分母':forward+adverse,'目標':'.7','楽観的必要最小方向変更':needed,'M別上限':table,
        '証明':'任意の目標qについてF-qRの不足はq*623-326=110.1。一件のラベル変更の増分は最大1（逆→順）。従って整数M>=111。逆→未による分母減も増分q<=1なので111未満を救えない。',
        '分母変化も含む小型人工全列挙':checks,'旧81保護/実BBO制約を無視した楽観上限':True,
        'Mの単位':'sideが実際に変更された非baseline canonical取得。origin/query成立数や保護81のpattern成立数とは異なる',
        'Hcomplete双方同一と固定752を前提':True,'個別ラベルをrank付け':False,'個別金融/Raw/CSV/追加2場読取':False,
        '70%の目標又は対象を縮小':False,'111で実際に達成できる保証':False,
        'コードSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    out=HERE/'方向変更数の上限確認.json';assert not out.exists();out.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'必要最小変更':needed,'人工全列挙':checks,'SHA256':hashlib.sha256(out.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__=='__main__':
    main()
