"""140独立部品の9gate・全origin・BBO費用・未知・変更数上限を人工確認する。"""
from pathlib import Path
from fractions import Fraction
import copy
import importlib.util
import unittest


def load(name: str,filename: str) -> object:
    """
    機能: 同folderの独立部品だけを読み込む。
    引数: name/filename(str)。
    返り値: objectは独立module。
    """
    spec=importlib.util.spec_from_file_location(name,Path(__file__).with_name(filename));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module


LINK=load('140独立接続','接続.py');M=load('140独立算術','算術.py');BOUND=load('140抽象上限','上限を検証する.py')


def row(side: int=1) -> dict:
    """
    機能: 四本の連続足と出生を持つ売買鏡像の人工票を作る。
    引数: side(int)はnative±1。
    返り値: dictは必須9gateが全成立する非金融票。
    """
    feet=[]
    for i in range(4):
        end=1000-300*i;q={'open':110,'high':115,'low':92,'close':95} if i==0 else {'open':95,'high':100,'low':90,'close':97}
        if side<0:q={'open':200-q['open'],'high':200-q['low'],'low':200-q['high'],'close':200-q['close']}
        feet.append({'role':'b_minus_'+str(i),'ref':{'id':'人工'+str(i),'width_seconds':300,'end':end,'delivered':{'time':end+1,'index':20-i,'source_line':30-i}},
            'start':end-300,'available_at':end,'delivery_at':end+1,'price_known':True,'volume_known':True,'ohlc':q,
            'volume':{'known':True,'value':20 if i==0 else 10},'histogram':{'known':True,'value':side*(1 if i==0 else 2)},
            'declared_previous_histogram':{'known':True,'value':999}})
    r={'id':'人工出生','side':side,'birth_stamp':{'time':1003,'index':25,'source_line':35},'birth_last':95 if side>0 else 105,
        'refs':[feet[0]['ref']],'feet':feet}
    return refresh(r)


# ----------------------------------------
def refresh(r: dict) -> dict:
    """
    機能: 人工票へ独立期待gateを付ける。
    引数: r(dict)。
    返り値: dictは検査用票。
    """
    r['gates']=LINK.expected_gates(r)
    r['pattern_known']=all(g['known'] for g in r['gates'].values());r['pattern_pass']=all(g['known'] and g['pass'] for g in r['gates'].values());return r


# ----------------------------------------
def candidate(side: int=1,axis: str='BBO',status: str='complete',direction: int=0) -> dict:
    """
    機能: 一つの清算Quoteだけを持つ人工金融票を作る。
    引数: side(int)、axis/status(str)、direction(int)。
    返り値: dictは自然結果を使わない候補。
    """
    entry={'time':0,'index':1,'source_line':1,'last':1005,'bid':1000,'ask':1010,'quote_ok':True}
    q={'time':3600,'index':2,'source_line':2,'last':1010,'bid':1005,'ask':1015,'quote_ok':True}
    return {'birth':{'side':side},'entry':entry,'entry_price':entry['last'] if axis=='Last' else entry['ask'] if side>0 else entry['bid'],
        'outcomes':[{'seconds':3600,'status':status,'deadline':3600,'endpoint':q if status=='complete' else None,
        'touches':[{'width':5,'direction':direction,'quote':q if direction else None}]}]}


class IndependentTests(unittest.TestCase):
    """Root/extractor/124金融関数をimportせず人工だけで確認する。"""

    def test_normal_and_mirror(self) -> None:
        """
        機能: 同じ9条件が売買鏡像で成立することを確認する。
        引数: self(IndependentTests)。返り値: None。
        """
        for side in (-1,1):
            r=row(side);self.assertEqual(LINK.pattern(r),(True,True));self.assertEqual(LINK.vote(side,False,[r]),(-side,True,True))

    def test_inclusive_zero_range_and_ignored_diagnostic(self) -> None:
        """
        機能: 一点域/Close・Last境界を許し、診断のLast対Closeを必須にしない。
        引数: self(IndependentTests)。返り値: None。
        """
        r=row();r['birth_last']=99;refresh(r);self.assertTrue(LINK.pattern(r)[1])
        for f in r['feet'][1:]:f['ohlc']={'open':100,'high':100,'low':100,'close':100}
        r['feet'][0]['ohlc']['close']=100;r['birth_last']=100;refresh(r)
        self.assertEqual(LINK.pattern(r),(True,True))

    def test_fresh_strict_and_history(self) -> None:
        """
        機能: fresh等号失効と履歴不足を未知/不成立として保持する。
        引数: self(IndependentTests)。返り値: None。
        """
        r=row();r['birth_stamp']['time']=1360;refresh(r);self.assertEqual(LINK.pattern(r),(False,False))
        r=row();r['feet']=r['feet'][:3];refresh(r);self.assertFalse(r['gates']['four_consecutive']['pass']);self.assertFalse(LINK.pattern(r)[1])

    def test_same_bar_histogram_not_declared_previous(self) -> None:
        """
        機能: 実際の直前足とHistを比べ、宣言Previousを代用しない。
        引数: self(IndependentTests)。返り値: None。
        """
        r=row();r['feet'][1]['histogram']['value']=1;refresh(r)
        self.assertEqual(r['gates']['histogram_weakening'],{'known':True,'pass':False})
        r['feet'][1]['histogram']={'known':False,'value':None};refresh(r)
        self.assertEqual(r['gates']['histogram_weakening'],{'known':False,'pass':False})

    def test_volume_zero_unknown_and_equality(self) -> None:
        """
        機能: 同足量の等号・前量0・量未知を区別する。
        引数: self(IndependentTests)。返り値: None。
        """
        r=row();r['feet'][0]['volume']['value']=10;refresh(r);self.assertTrue(LINK.pattern(r)[1])
        r['feet'][1]['volume']['value']=0;refresh(r);self.assertEqual(r['gates']['same_bar_volume'],{'known':True,'pass':False})
        r['feet'][1]['volume_known']=False;r['feet'][1]['volume']={'known':False,'value':None};refresh(r)
        self.assertEqual(r['gates']['same_bar_volume'],{'known':False,'pass':False})

    def test_all_origins_and_protection(self) -> None:
        """
        機能: 全origin成立だけflip、未知/否定/旧81はkeepとする。
        引数: self(IndependentTests)。返り値: None。
        """
        a=row();b=row();self.assertEqual(LINK.vote(1,True,[a,b]),(1,True,True))
        b['feet'][1]['histogram']={'known':False,'value':None};refresh(b)
        for origins in ([a,b],[b,a]):self.assertEqual(LINK.vote(1,False,origins),(1,False,False))
        b=row();b['feet'][0]['ohlc'].update({'high':100,'open':99});refresh(b);self.assertEqual(LINK.vote(1,False,[a,b]),(1,True,False))

    def test_future_ref_rejected(self) -> None:
        """
        機能: 公表原行が出生より後なら保存票を拒否する。
        引数: self(IndependentTests)。返り値: None。
        """
        r=row();r['feet'][0]['ref']['delivered']['index']=1000
        with self.assertRaises(AssertionError):LINK.expected_gates(r)

    def test_costs_and_actual_both_sides(self) -> None:
        """
        機能: 実正逆双方損失と77/1077円、Last金額nullを確認する。
        引数: self(IndependentTests)。返り値: None。
        """
        a=M.ifd(candidate(),3600,5,'BBO');b=M.ifd(candidate(-1),3600,5,'BBO')
        self.assertEqual((a['points'],b['points']),(-5,-15));self.assertEqual((a['net0'],a['net5']),(-577,-1577))
        self.assertIsNone(M.ifd(candidate(axis='Last'),3600,5,'Last')['net5'])

    def test_censored_touch_and_direction_selection(self) -> None:
        """
        機能: H不足でも既知touchを保持しT0だけ固定票の向きへ選ぶ。
        引数: self(IndependentTests)。返り値: None。
        """
        a=candidate(status='phase_censored',direction=-1);b=candidate(-1)
        self.assertTrue(M.ifd(a,3600,5,'BBO')['known']);self.assertFalse(M.ifd(candidate(status='gap_censored'),3600,5,'BBO')['known'])
        r={'session':'人工','meta':{'model':'P0'},'case':{'original_side':1,'original':a,'reverse':b},'direction':{'selected_side':-1}}
        self.assertIs(M.choose(r,'T0','BBO'),b);self.assertIs(M.choose(r,'P0','BBO'),a)
        self.assertEqual(M.stats([r],'T0','BBO',3600,5)['flips'],1)

    def test_111_lower_bound(self) -> None:
        """
        機能: 110変更では70未満、111でも楽観仮定にすぎないことを確認する。
        引数: self(IndependentTests)。返り値: None。
        """
        self.assertEqual(BOUND.lower_changes(326,297),111)
        self.assertLess(BOUND.upper_rate(326,297,110),Fraction(7,10))
        self.assertGreaterEqual(BOUND.upper_rate(326,297,111),Fraction(7,10))


if __name__=='__main__':unittest.main(verbosity=2)
