"""140のF0/F1原文を結果編集前に保管し、必要資料だけ恒久保存する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00140_*'))
OWN=ROOT/'work/140失敗突破の評価'


def sha(body: bytes) -> str:
    """
    機能: 原文の指紋を求める。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def save(source: Path,target: Path,packed: bool=False) -> dict:
    """
    機能: 未作成先へ原文を保存する。
    引数: source/target(Path)、packed(bool)はgzip指定。
    返り値: dictは復元先・サイズ・指紋。
    """
    raw=source.read_bytes();body=gzip.compress(raw,mtime=0) if packed else raw
    target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as f:f.write(body)
    return {'保存元':target.relative_to(ROOT).as_posix(),'復元先':source.relative_to(ROOT).as_posix(),'形式':'gzip' if packed else '同体',
        '保存bytes':len(body),'保存SHA256':sha(body),'解凍bytes':len(raw),'解凍SHA256':sha(raw)}


# ----------------------------------------
def main() -> None:
    """
    機能: F0/F1の直接源を新規保存・共有参照・非複製に分けて退避する。
    引数: なし。
    返り値: None。Raw・巨大入力・実行体・追加2場を読まず複写しない。
    """
    freezes={};docs={};declared={}
    for n,expected in [('F0抽出前.json','0bce35f861c38df93ac5c8c30ca2bd8f6dbaf6bd72e66f45ab11b96563c1305a'),
        ('F1金融前.json','87cc4d9b6e3febec12f23819b9ceee605eaf53dc50fbe326765283e21c29bfb3')]:
        raw=(OWN/n).read_bytes();assert sha(raw)==expected
        freezes[n]=json.loads(raw);save(OWN/n,FORMAL/'検査'/n)
        for p,h in freezes[n]['ファイル'].items():
            path=Path(p);rel=path.relative_to(ROOT).as_posix()
            if rel in declared:assert declared[rel]==h
            declared[rel]=h
            if path.suffix=='.md':
                body=path.read_bytes();assert sha(body)==h
                docs[rel]={'path':rel,'sha256':h,'bytes':len(body),'本文':body.decode('utf-8')}
    snap={'試行':140,'段階':'金融後の正式編集前退避。元F0/F1の原文を保存','F0_SHA256':sha((OWN/'F0抽出前.json').read_bytes()),
        'F1_SHA256':sha((OWN/'F1金融前.json').read_bytes()),'文書数':len(docs),'正式文書数':sum(x.startswith('study/') for x in docs),
        '文書':list(docs.values()),'事前固定の後造り':False}
    p=FORMAL/'検査/実行前文書.json.gz'
    with p.open('xb') as f:f.write(gzip.compress((json.dumps(snap,ensure_ascii=False,indent=2)+'\n').encode('utf-8'),mtime=0))
    assert snap['正式文書数']==3
    m138=json.loads(next((ROOT/'study').glob('00138_*/保管索引.json')).read_bytes())
    all_inputs=m138['共有入力']+m138['新共用入力']+[m138['保存済み正逆観測'],m138['集計正本']]
    by_restore={x['復元先']:x for x in all_inputs}
    shared=[];newinputs=[]
    for source,name in [(OWN/'全出生の失敗突破構造.json','全出生の失敗突破構造.json.gz'),
        (OWN/'方向票/全752の方向.json','全752の方向.json.gz'),
        (ROOT/'work/140失敗突破の方向票と集計/固定条件.json','固定条件.json.gz')]:
        newinputs.append(save(source,ROOT/'inputs/00140_出生時の失敗突破'/name,True))
    inputmap={x['復元先']:x for x in newinputs}
    groups=[];registry={}
    for number,key in [(133,'固定コード'),(138,'追加固定資料')]:
        folder=next((ROOT/'study').glob(f'{number:05d}_*'));m=json.loads((folder/'保管索引.json').read_bytes());item=m[key]
        path=folder/'再現資料'/item['ZIP'];assert sha(path.read_bytes())==item['ZIP_SHA256'];at=len(groups)
        groups.append({'保存元ZIP':path.relative_to(ROOT).as_posix(),'ZIP_SHA256':item['ZIP_SHA256'],'格納源':[]})
        for x in item['格納源']:registry.setdefault(x['sha256'],(at,x['path']))
    excluded=[];new=[];bodies={}
    for rel,h in declared.items():
        p=ROOT/rel
        if rel=='work/122全場入力/入力.json' or p.suffix=='.exe':
            excluded.append({'path':rel,'bytes':p.stat().st_size,'sha256':h,'理由':'巨大共用入力/実行体を複写せず、入力由来とビルド源を参照。元指紋はRootの全源照合証跡に従う'})
            continue
        if rel in inputmap:assert inputmap[rel]['解凍SHA256']==h;continue
        if rel in by_restore:
            x=by_restore[rel];assert x['解凍SHA256']==h;shared.append(x);continue
        body=p.read_bytes();assert sha(body)==h and len(body)<2_000_000
        if h in registry:
            at,entry=registry[h];groups[at]['格納源'].append({'復元先':rel,'ZIP内path':entry,'sha256':h,'bytes':len(body)})
        else:new.append({'path':rel,'sha256':h,'bytes':len(body)});bodies[rel]=body
    assert len(excluded)==2
    assert len(new)+len(shared)+len(newinputs)+len(excluded)+sum(len(x['格納源']) for x in groups)==len(declared)
    archive=FORMAL/'再現資料/140実行前の固定資料.zip';archive.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for x in new:z.writestr(x['path'],bodies[x['path']])
    for g in groups:g['格納源数']=len(g['格納源'])
    aggregate=save(OWN/'金融評価/集計.json',FORMAL/'成果物/集計.json')
    proofsources=[(OWN/n,n) for n in ('Rootの金融とCSVの確定.json','CSV再読の確認.json','抽出の完了.json','方向の完了.json','集計の完了.json')]
    proofsources += [(ROOT/'work/140独立検算'/n,'独立/'+n) for n in ('準備の確認.json','独立確認.json','完了.json','方向変更数の上限確認.json')]
    proofsources += [(ROOT/'work/140反転6件の原因診断/診断の確認.json','作者診断の確認.json')]
    for source,target in proofsources:save(source,FORMAL/'検査'/target)
    cause=save(ROOT/'work/140反転6件の原因診断/6件の当時票と実正逆.json',FORMAL/'根拠/6件の当時票と実正逆.json.gz',True)
    # ----------------------------------------
    m={'試行':140,'段階':'F0/F1原文と正本を結果編集前に退避','F0_SHA256':snap['F0_SHA256'],'F1_SHA256':snap['F1_SHA256'],
        'F0直接源':len(freezes['F0抽出前.json']['ファイル']),'F1直接源':len(freezes['F1金融前.json']['ファイル']),'両固定の異なり源数':len(declared),
        '追加固定資料':{'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(new),'格納源':new},
        '共有固定コード群':groups,'共有入力':shared,'新共用入力':newinputs,'意図して複製しない固定源':excluded,'集計正本':aggregate,'作者の原因票':cause,
        'CSV正本':'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/140失敗突破CSV','新Raw/大入力/実行体複製':False,'139以前変更/追加2場読取':False,
        '共有入力の生成元':'study/00138_全成立の独立入口を統合して頻度と先着を診断する/再現手順.md',
        '後段再現用継承源':m138['後段再現用の継承源']}
    (FORMAL/'保管索引.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'原文MD':len(docs),'正式MD':3,'F0源':m['F0直接源'],'F1源':m['F1直接源'],'固定ZIP源':len(new),'新入力gzip':3,'非複製':len(excluded),'ZIP_SHA256':m['追加固定資料']['ZIP_SHA256']},ensure_ascii=False))


if __name__=='__main__':main()
