"""140の追補と最小停止証跡を保存する。新しい自然検証は行わない。"""
from pathlib import Path
import gzip
import hashlib
import json
import re
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00140_*'))


def sha(body: bytes) -> str:
    """
    機能: 原文の指紋を求める。
    引数: body(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def cells(body: str) -> list:
    """
    機能: 56手法×9尺度の設定だけを抽出する。
    引数: body(str)は設定と結果の本文。
    返り値: listはID/9尺度の504セル。
    """
    values=[]
    for line in body.splitlines():
        if re.match(r'^\| [A-Z]+\d{2} \|',line):
            row=[x.strip() for x in line.strip('|').split('|')]
            if len(row)==11:values.append([row[0],row[2:]])
    assert len(values)==56 and sum(len(x[1]) for x in values)==504
    return values


# ----------------------------------------
def main() -> None:
    """
    機能: 既存原文/独立/再現/CSV証跡を照合して正式保存を閉じる。
    引数: なし。
    返り値: None。Raw/CSV生成/新金融/追加2場/139以前は変更しない。
    """
    files=list((ROOT/'work/140正式保存').glob('*.py'))+list((FORMAL/'再現資料').glob('*.py'))
    files += list((ROOT/'work/140独立検算').glob('*.py'))+[ROOT/'work/140独立検算'/n for n in ('README.md','条件.md')]
    files += [ROOT/'work/140反転6件の原因診断'/n for n in ('結果と当時の証拠.md','診断する.py')]
    files += [ROOT/'work/確定三表のCSV出力'/n for n in ('出力する.mjs','CSVを独立再読する.py','由来.json')]
    archive=FORMAL/'再現資料/確認と保管の追補.zip';entries=[]
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(set(files)):
            raw=p.read_bytes();name=p.relative_to(ROOT).as_posix();z.writestr(name,raw)
            entries.append({'path':name,'sha256':sha(raw),'bytes':len(raw),'区分':'金融後の独立/作者診断/CSV出力/保管。F0/F1事前源と区別'})
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes())
    m['後発資料']={'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(entries),'格納源':entries}
    m['段階']='自然抽出/方向固定/金融/独立検算/再現/正式保存完了。51.36%で70未達、編集停止'
    m['独立確認SHA256']='b3ca4ffb46601500d8aa7c35d9bf93a5c72cd9e26cb44e28ee406acde60e9102'
    m['独立停止SHA256']='28e3e912bbbc9fbb94f348876eb98fa5ca20e1d3c309e3a30f581c3c3b5b41cc'
    m['保存再現SHA256']='9927fb0de12a150a57500ef6cdb82eb489f91f336ac2958b254254963831edea'
    m['Python版']='3.14.3'
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    # ----------------------------------------
    snap=json.loads(gzip.decompress((FORMAL/'検査/実行前文書.json.gz').read_bytes()))
    assert snap['文書数']==6 and snap['正式文書数']==3
    for x in snap['文書']:assert sha(x['本文'].encode('utf-8'))==x['sha256']
    old={Path(x['path']).name:x['本文'] for x in snap['文書'] if x['path'].startswith('study/')}
    assert cells(old['設定と結果.md'])==cells((FORMAL/'設定と結果.md').read_text('utf-8'))
    assert old['条件.md'].encode('utf-8')==(FORMAL/'条件.md').read_bytes()
    for n,key in [('F0抽出前.json','F0_SHA256'),('F1金融前.json','F1_SHA256')]:assert sha((FORMAL/'検査'/n).read_bytes())==m[key]
    bodies={}
    for item in [m['追加固定資料']]+m['共有固定コード群']+[m['後段再現用継承源'],m['後発資料']]:
        path=ROOT/item['保存元ZIP'] if '保存元ZIP' in item else FORMAL/'再現資料'/item['ZIP'];assert sha(path.read_bytes())==item['ZIP_SHA256']
        with zipfile.ZipFile(path) as z:
            assert z.testzip() is None
            for x in item['格納源']:
                raw=z.read(x.get('ZIP内path',x.get('path')));assert sha(raw)==x['sha256']
                name=x.get('復元先',x.get('path'));bodies[name]=sha(raw)
    for x in m['共有入力']+m['新共用入力']+[m['集計正本'],m['作者の原因票']]:
        raw=(ROOT/x['保存元']).read_bytes();assert sha(raw)==x['保存SHA256']
        decoded=gzip.decompress(raw) if x['形式']=='gzip' else raw;assert sha(decoded)==x['解凍SHA256'];bodies[x['復元先']]=sha(decoded)
    omitted={x['path'] for x in m['意図して複製しない固定源']};source_counts=[]
    for n in ('F0抽出前.json','F1金融前.json'):
        f=json.loads((FORMAL/'検査'/n).read_bytes());count=0
        for name,h in f['ファイル'].items():
            rel=Path(name).relative_to(ROOT).as_posix()
            if rel in omitted:continue
            assert bodies[rel]==h;count+=1
        source_counts.append(count)
    assert source_counts==[28,40]
    assert len(m['新共用入力'])==3
    assert sha((FORMAL/'検査/独立/独立確認.json').read_bytes())==m['独立確認SHA256']
    assert sha((FORMAL/'検査/独立/完了.json').read_bytes())==m['独立停止SHA256']
    assert sha((FORMAL/'検査/保存観測の再現確認.json').read_bytes())==m['保存再現SHA256']
    certbody=(FORMAL/'検査/Rootの金融とCSVの確定.json').read_bytes()
    assert sha(certbody)=='75d72f0891af674a43a09b83f768a6cfb8cf018878ee5745e55d8f74c98d8086'
    cert=json.loads(certbody);assert cert['F0_F1全源前後同体'] and cert['CSV全39685セル16946数値一致'] and cert['CSV三preview確認']
    for name,h in cert['参照CSV'].items():assert sha((ROOT/m['CSV正本']/name).read_bytes())==h
    assert sha((FORMAL/'検査/作者診断の確認.json').read_bytes())=='e04c74a6f4ebacc949f351afca9f054f541dbfd7cc4ea1e8a093013a8c88638d'
    data=json.loads((FORMAL/'成果物/集計.json').read_bytes());main=data['集計']['all']['T0']['BBO']['3600']['125']
    assert [main[k] for k in ('entries','forward','adverse','neither','censored','ifd_net5_profit','ifd_net5_loss','ifd_net5_sum')]==[752,320,303,76,53,4145587,4715951,-570364]
    assert data['方向件数']=={'keep':746,'flip':6}
    # ----------------------------------------
    indices=[ROOT/x for x in ('README.md','study/README.md','docs/README.md','docs/議論/README.md')];links=0
    paths=list(FORMAL.rglob('*.md'))+[ROOT/m['CSV正本']/'README.md']+indices
    for p in paths:
        body=p.read_text('utf-8')
        if p in indices:assert '[140：' in body;body=body.split('\n\n',2)[1]
        for target in re.findall(r'\]\(([^)]+)\)',body):
            if target.startswith(('https:','http:','#')):continue
            assert (p.parent/target.strip('<>').split('#',1)[0]).resolve().exists(),(p,target);links+=1
    proof={'成功':True,'試行':140,'正式保存完了':True,'編集停止':True,'F0全30/F1全42源原文指紋':True,'全6MD/正式3MD原文先退避':True,
        '28/30源と40/42源同体復元':True,'非複製は177MB入力と抽出exe':True,'固定条件/56手法504セル不変':True,
        '769x9gate/850関係/752方向/81保護独立一致':True,'独立180条件/39685表セル/旧120対照/phase一致':True,'独立人工':10,
        '変更6に対し抽象111下限を個票順位なしで検証':True,'全6反転が悪化':True,'保存観測から全金融数値/三表JSONbytes再現':True,
        'CSV39685セル16946数値再読/三preview':True,'作者原因と独立検算を分離':True,'新入力各1gzip':3,'新Raw/金融観測/CSV重複出力/追加2場読取/139以前変更':False,
        '4索引更新':True,'ローカルリンク':links,'重大不足':[],'主T0':main,'F0_SHA256':m['F0_SHA256'],'F1_SHA256':m['F1_SHA256'],
        '保管索引SHA256':sha(mpath.read_bytes()),'固定ZIP_SHA256':m['追加固定資料']['ZIP_SHA256'],'追補ZIP_SHA256':m['後発資料']['ZIP_SHA256'],
        '独立確認SHA256':m['独立確認SHA256'],'再現SHA256':m['保存再現SHA256'],'Root確定SHA256':sha(certbody),'コードSHA256':sha(Path(__file__).read_bytes())}
    out=FORMAL/'検査/正式保存の最終確認.json';assert not out.exists();out.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'最終確認SHA256':sha(out.read_bytes()),'保管索引SHA256':sha(mpath.read_bytes()),'追補ZIP_SHA256':m['後発資料']['ZIP_SHA256'],'重大不足':[]},ensure_ascii=False))


if __name__=='__main__':main()
