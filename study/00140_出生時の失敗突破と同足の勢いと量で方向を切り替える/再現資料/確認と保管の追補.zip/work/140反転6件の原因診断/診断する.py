"""140固定結果の反転6件だけを保存情報から診断する。Rawや旧成果は変更しない。"""
from collections import Counter
from datetime import datetime,timezone,timedelta
import hashlib
import json
import math
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
FILES={
 ROOT/'work/140失敗突破の評価/全出生の失敗突破構造.json':'800b34316a3ed510a187ddafb25669a0d3b1c1318ad926c16dea5613788ace6b',
 ROOT/'work/140失敗突破の評価/方向票/全752の方向.json':'743dcfec1541b5c36de4ab5c7172221678ab426ac12aaf60c424cc7c1e79a28c',
 ROOT/'work/140失敗突破の評価/金融評価/集計.json':'8870c3f768df743827d4692b1b798c6d1a2edc03ba659c80e38c5fdbef1569e4',
 ROOT/'work/全成立poolの非金融manifest/manifest.json':'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35',
 ROOT/'work/138全成立入口の評価/固定取得の正逆観測.json':'d272fc6f6768342ff67e1a9ec58b0b7307a0a5b07cc215ba5ff7bcb50865b742',
}


def sha(path: Path) -> str:
    """
    機能: 明示資料のSHA256を求める。
    引数: path(Path)は対象。
    返り値: strは指紋。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def jst(at: float) -> str:
    """
    機能: 保存Unix価格時計をJST表記へする。
    引数: at(float)は保存時刻。
    返り値: strはISO形式。受信時計の復元はしない。
    """
    return datetime.fromtimestamp(at,timezone(timedelta(hours=9))).isoformat()


def stamp(q: dict) -> tuple:
    """
    機能: 保存原行の因果比較キーを返す。
    引数: q(dict)はQuote又はStamp。
    返り値: tupleは価格時計/採用順/物理行。
    """
    return tuple(q[k] for k in ('time','index','source_line'))


def observed_ifd(case: dict,side: int) -> dict:
    """
    機能: 保存H60±125の実側touchを優先してIFD代用を算出する。
    引数: case(dict)、side(int)は保存streamと実側方向。
    返り値: dictは先着quote・清算mark・mini1枚の77/1077円後金額。
    """
    assert case['status']=='filled' and case['birth']['side']==side
    entry=case['entry'];price=entry['ask'] if side>0 else entry['bid'];assert price==case['entry_price']
    h=next(o for o in case['outcomes'] if o['seconds']==3600)
    touch=next(t for t in h['touches'] if t['width']==125)
    exit_quote=touch['quote'] if touch['direction'] else h['endpoint'] if h['status']=='complete' else None
    if exit_quote is None:return {'known':False,'h_status':h['status'],'touch':touch,'entry_price':price,'net0':None,'net5':None}
    mark=exit_quote['bid'] if side>0 else exit_quote['ask'];points=side*(mark-price)
    if touch['direction']:assert points>=125 if touch['direction']>0 else points<=-125
    return {'known':True,'side':side,'entry_quote':entry,'entry_jst':jst(entry['time']),'entry_price':price,'h_status':h['status'],
        'touch_direction':touch['direction'],'touch_quote':touch['quote'],'touch_jst':jst(touch['quote']['time']) if touch['quote'] else None,
        'exit_quote':exit_quote,'exit_jst':jst(exit_quote['time']),'exit_mark':mark,'points':points,'net0':points*100-77,'net5':points*100-1077,
        'reason':'保存実側先着touch' if touch['direction'] else '全H完了の保存清算'}


def origin_diagnostic(row: dict,origin: dict,entry: dict,side: int) -> dict:
    """
    機能: 各originの足束縛・符号と出生当時/取得当時の位置を再計算する。
    引数: row/origin/entry(dict)、side(int)は抽出・由来・実取得・native方向。
    返り値: dictは当時の証拠とR型比較用K。旧R再生結果は推測しない。
    """
    assert row['side']==origin['side']==side and row['pattern_known'] and row['pattern_pass']
    birth=row['birth_stamp'];last=row['birth_last'];feet=row['feet'];assert len(feet)==4
    b,previous=feet[:2];o=b['ohlc'];prior=feet[1:]
    low=min(f['ohlc']['low'] for f in prior);high=max(f['ohlc']['high'] for f in prior)
    for i,f in enumerate(feet):
        assert f['role']=='b_minus_'+str(i) and f['price_known'] and f['ref']['width_seconds']==300
        assert f['ref']['end']-f['start']==300 and all(x<=y for x,y in zip(stamp(f['ref']['delivered']),stamp(birth)))
        assert f['ref'] in row['refs'] and f['ref']['end']<=f['available_at']<=f['delivery_at']<=f['ref']['delivered']['time']<=birth['time']
        if i:assert feet[i-1]['start']==f['ref']['end']
    assert b['volume_known'] and previous['volume_known'] and b['histogram']['known'] and previous['histogram']['known']
    body=side*(o['close']-o['open']);delta=side*(b['histogram']['value']-previous['histogram']['value'])
    extreme=o['high']-high if side>0 else low-o['low'];volume=b['volume']['value'];previous_volume=previous['volume']['value']
    checks={'latest_5_fresh':birth['time']<b['ref']['end']+360,'four_consecutive':True,'four_prices_known':True,
        'native_extreme_outside':extreme>0,'close_inside':low<=o['close']<=high,'opposite_body':body<0,
        'histogram_weakening':delta<0,'same_bar_volume':volume>=previous_volume>0,'birth_last_inside':low<=last<=high}
    assert len(checks)==9 and all(checks.values())
    assert all(row['gates'][k]=={'known':True,'pass':v} for k,v in checks.items())
    for k,v in {'range_low':low,'range_high':high,'b_body_to_side':body,'histogram_delta_to_side':delta,'native_extreme_outside':extreme,'b_volume':volume,'previous_volume':previous_volume}.items():
        assert row['values'][k]['known'] and math.isclose(row['values'][k]['value'],v,abs_tol=1e-9)
    last_close=side*(last-o['close']);diagnostic=last_close<=0
    assert row['gates']['last_not_reaccelerating_diagnostic']=={'known':True,'pass':diagnostic}
    assert all(a<=z for a,z in zip(stamp(birth),stamp(entry)))
    t=-side;k=o['high']+5 if t>0 else o['low']-5
    actual_reverse_entry=entry['ask'] if t>0 else entry['bid']
    room=high-actual_reverse_entry if t>0 else actual_reverse_entry-low
    positive=high>low
    return {'query_id':row['id'],'origin_family':origin['family'],'origin_variant':origin['variant'],'source_file_sha':origin['source_file_sha'],
        'source_locator':origin['source_locator'],'position_origin':origin['position_origin'],
        'native_side':side,'reverse_side':t,'birth_quote':origin['birthQuote'],'entry_quote':entry,
        'b_start':b['start'],'b_start_jst':jst(b['start']),'b_end':b['ref']['end'],'b_end_jst':jst(b['ref']['end']),
        'b_available_at':b['available_at'],'b_delivery_at':b['delivery_at'],'b_delivered_stamp':b['ref']['delivered'],'b_delivered_jst':jst(b['ref']['delivered']['time']),
        'birth_jst':jst(birth['time']),'entry_jst':jst(entry['time']),
        'ages_seconds':{'end_to_delivery':b['ref']['delivered']['time']-b['ref']['end'],'end_to_birth':birth['time']-b['ref']['end'],
            'delivery_to_birth':birth['time']-b['ref']['delivered']['time'],'end_to_entry':entry['time']-b['ref']['end'],
            'delivery_to_entry':entry['time']-b['ref']['delivered']['time'],'birth_to_entry':entry['time']-birth['time']},
        'range_low':low,'range_high':high,'range_width':high-low,'range_zero':not positive,'b_ohlc':o,
        'b_body_to_native':body,'b_histogram':b['histogram']['value'],'previous_actual_histogram':previous['histogram']['value'],
        'histogram_to_native':side*b['histogram']['value'],'histogram_delta_to_native':delta,
        'b_volume':volume,'previous_actual_volume':previous_volume,'volume_ratio':volume/previous_volume,'b_atr':b['atr'],
        'birth_last_minus_b_close_to_native':last_close,'entry_last_minus_b_close_to_native':side*(entry['last']-o['close']),
        'birth_native_range_position':(last-low)/(high-low) if positive and side>0 else (high-last)/(high-low) if positive else None,
        'entry_reverse_range_position':(actual_reverse_entry-low)/(high-low) if positive and t>0 else (high-actual_reverse_entry)/(high-low) if positive else None,
        'last_close_native_nonpositive':diagnostic,'extractor_gate_name':'last_not_reaccelerating_diagnostic','9gates_recomputed':checks,
        'K':None,'K_note':'140はKを持たない。以下は同じbから作った旧R型の比較用仮水準で、元Source Kや旧R再生結果ではない',
        'R_type_reference_K':k,'R_birth_last_to_K':t*(last-k),'R_entry_last_to_K':t*(entry['last']-k),
        'R_reference_K_reached_at_birth':t*(last-k)>=0,'reverse_entry_to_opposite_range_edge':room,
        'next_delivered_5_after_b_in_birth_snapshot':False,'closed_5_confirmation_note':'抽出の最新5分がbであり、b後の別5分終値確認は当時の保存票にはない',
        'feet':feet,'refs':row['refs']}


def main() -> None:
    """
    機能: 指紋固定された6反転ケースだけを診断JSONへ保存する。
    引数: なし。
    返り値: None。全752の条件再選択・原板走査・旧成果変更はしない。
    """
    data={}
    for p,h in FILES.items():assert sha(p)==h;data[p.name if p.name not in data else str(p)]=json.loads(p.read_bytes())
    features=data['全出生の失敗突破構造.json'];choices=data['全752の方向.json'];aggregate=data['集計.json'];manifest=data['manifest.json'];pairs=data['固定取得の正逆観測.json']
    xmap={r['id']:r for r in features['rows']};mmap={'P0/'+c['id']:c for c in manifest['P0']}
    cases={c['id']:(s,c) for s in pairs['scenes'] for c in s['cases']}
    flips=[r for r in choices['rows'] if r['action']=='flip'];assert len(flips)==6
    rows=[]
    for selected in flips:
        scene,case=cases[selected['id']];candidate=mmap[selected['id']];side=selected['native_side']
        assert scene['session']==selected['session']==candidate['session'] and case['original_side']==candidate['side']==side and selected['selected_side']==-side
        entry=case['original']['entry'];assert entry==case['reverse']['entry']
        native=observed_ifd(case['original'],side);reverse=observed_ifd(case['reverse'],-side)
        for stream in (native,reverse):
            assert stream['known'] and stream['h_status']=='complete' and stream['exit_quote']['time']<scene['execution_end']
        assert native['touch_direction']==1 and reverse['touch_direction']==-1
        assert len(candidate['origins'])==len(selected['origin_query_ids'])==1
        details=[origin_diagnostic(xmap[q],origin,entry,side) for q,origin in zip(selected['origin_query_ids'],candidate['origins'])]
        rows.append({'id':selected['id'],'session':selected['session'],'native_side':side,'selected_side':-side,'origins':details,
            'native':native,'reverse':reverse,'net5_pair_difference':reverse['net5']-native['net5']})
    origins=[o for r in rows for o in r['origins']]
    summary={'cases':6,'sessions':len({r['session'] for r in rows}),'unique_b_frames':len({o['feet'][0]['ref']['id'] for o in origins}),
        'families':dict(Counter(o['origin_family'] for o in origins)),'native_sides':dict(Counter(r['native_side'] for r in rows)),
        'end_to_birth_seconds':[min(o['ages_seconds']['end_to_birth'] for o in origins),max(o['ages_seconds']['end_to_birth'] for o in origins)],
        'delivery_to_birth_seconds':[min(o['ages_seconds']['delivery_to_birth'] for o in origins),max(o['ages_seconds']['delivery_to_birth'] for o in origins)],
        'native_recovery_from_b_close_at_birth':sum(o['birth_last_minus_b_close_to_native']>0 for o in origins),
        'last_close_native_nonpositive_true':sum(o['last_close_native_nonpositive'] for o in origins),
        'all_histogram_still_native_sign':all(o['histogram_to_native']>0 for o in origins),
        'R_reference_K_not_reached_at_birth':sum(not o['R_reference_K_reached_at_birth'] for o in origins),
        'native_net5_profit':sum(r['native']['net5'] for r in rows),'reverse_net5_loss':-sum(r['reverse']['net5'] for r in rows),
        'net5_pair_difference':sum(r['net5_pair_difference'] for r in rows),'sign_and_foot_binding_mismatch':0}
    assert summary['net5_pair_difference']==-156000 and summary['native_recovery_from_b_close_at_birth']==3
    current=aggregate['集計']['all'];assert current['T0']['BBO']['3600']['125']['ifd_net5_sum']-current['P0']['BBO']['3600']['125']['ifd_net5_sum']==summary['net5_pair_difference']
    result={'成功':True,'試行':140,'範囲':'固定140の反転6件の事後診断。140抽出/方向/金融作者本人であり独立金融検算とは別',
        'summary':summary,'rows':rows,'sources':{str(p):h for p,h in FILES.items()},'new_parameters_or_reselection':False,'new_Raw_or_CSV_or_additional2_read':False,
        'future_quotes_used_as_features':False,'later_touch_quotes':'結果の確認だけに使用、出生条件へ戻さない','old_R_confirmation_replayed':False}
    target=HERE/'6件の当時票と実正逆.json'
    with target.open('x',encoding='utf-8') as f:json.dump(result,f,ensure_ascii=False,indent=2,allow_nan=False);f.write('\n')
    assert all(sha(p)==h for p,h in FILES.items())
    print(json.dumps({'成功':True,'summary':summary,'診断SHA256':sha(target)},ensure_ascii=False))


if __name__=='__main__':main()
