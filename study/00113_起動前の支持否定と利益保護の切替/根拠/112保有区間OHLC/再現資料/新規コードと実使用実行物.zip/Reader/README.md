# 112の実保有区間OHLCと到達原行

このReaderはSourceや売買戦略を実行せず、台帳で確定した実新規→最終返済、各allocationの実新規→当該返済、およびR/n一定片だけを原板へ照合する。同じ開始/終了pairはprice_interval_idを共有する。各場NK225_bookの圧縮bytesを一度だけ読み、gzip復号とSHA256を同時に計算する。Raw値全件は新保存しない。

## 時計・採用・価格の区別

Source111 input.goのreadBoardsとstrategy/features.goのOnBoardを読取確認し、独立Goコードで同じ採用境界を実装した。Symbolの型、CurrentPriceTimeの有無/型/RFC3339Nano、場内、直前に採用した正Last行より時計が逆行しないこと、正の有限Lastを確認する。Buy/Sell各10深度は旧parserと同じJSON型を検査し、最良値以外は保存しない。壊れたJSONや数値型/範囲エラーは旧Source同様に成功扱いせず停止する。

Indexは配送採用NK225行だけの0始まり、source_lineはgzip内物理行の1始まり。同時計の別物理行を落とさず、開始/終了quoteのTime/Index/Line/Last/Bid/Ask/QuoteOKを全値照合して両端inclusiveとする。時計逆行・不正・場外・非正Last・cutoff除外を別計数する。正常BBOは有限Bid>0、Ask>Bidで、表示数量を新条件に加えない。

到達時計はモデルと同じCurrentPriceTimeであり、実受信時刻は不明。原clock文字列とfloat64(UnixNano)/1e9、Index/Lineをwitnessに持つ。payloadのHighPrice/LowPriceとそれらの時刻はセッション累積なので使用しない。正常Last＋異常BBO行はLast OHLCへ含め、BBO/費用後評価からは除く。

## 入力と出力

`PriceInterval={price_interval_id,session,start_quote,end_quote,start_inclusive:true,end_inclusive:true}`。`StateSlice={query_id,price_interval_id,side,entry_price,n,R,K,q0,thresholds}`。n>0の保有片だけを扱い、R/Kは円、entry_priceは指数pt。閾値はstrict W>0、H50=W>=q0×5000円、H100=W>=q0×10000円。H50到達を記録しても、未実行P50の損益を計算したことにはならない。

scene.price_intervals[id]はinterval、境界照合、raw_rows/accepted_rows/excluded/bad_bbo_rows、およびlast/bid/askを持つ。各seriesは `count,open:{value,quote},high:{value,first,last},low:{value,first,last},close:{value,quote}`。未知系列はpointがnull。LastとBBOは別の観測で、返済側はlong Bid/short Askから選ぶ。

state_queries[id]はquery、bad_bbo_rows、whole_yen（同series）、thresholds（各thresholdとfirst Point/null）、whole_returns/unit_returnsを持つ。W=R+n×(100×side×(mark−entry_price)−K)。returnsはfirst_positive/first_nonpositive/first_negative/first_nonpositive_after_positive/first_negative_after_positiveのPoint/nullだけを保存する。各片のLast OHLCはquery.price_interval_idから参照できる。

partial原行は前片endと後片startの両方へ含める。前後のW同体と位相は台帳側で検証し、統合時の親価格行数や同値到達数はunique親区間から取り、片の件数を単純加算しない。片間の正益経験carryは、無条件firstと当片正益後firstから統合側が判断する。

保存marks/request quoteの原値確認は別Refの `witnesses=[{witness_id,session,index,source_line}]` を使い、同じ走査内でRawのQuoteを返す。価格や金融期待値をReaderへ渡さない。要求行未採用・Index差・EOF欠落は成功にしない。

## 固定要求・実行

```text
version=1,trial=113,source_trial=112,fixed=true,raw_read_authorized=true,
policy=holding_interval_ohlc112_v1,
manifest:{path,sha256},queries:{path,sha256},witness_requests:{path,sha256},
ledger_stop:{path,sha256},reader_stop:{path,sha256},executable:{path,sha256},
code_sha256:{絶対path:sha256},sessions:[明示した固定70場内の場ID]
```

ReaderはRaw pathをqueryから採用せず、固定902c…台帳のNK225_bookだけから解決し、queryのRaw参照との同体も検査する。Reader停止/全コード/実行中exe、台帳停止、query・witness素材を本文前に認証する。台帳準備5e4…には停止fieldがないため、旧記録を改変せずRootの認証済み停止接続wrapperをledger_stopへ指定する。

```powershell
& '検査/保有中OHLC.exe' --fixed '<Root固定要求絶対path>' --fixed-sha '<SHA>' --metadata-only
& '検査/保有中OHLC.exe' --fixed '<同要求>' --fixed-sha '<同SHA>' --out '<未使用絶対先>' --workers 8
```

metadata-onlyはRawを開かない。通常実行は独立場を最大8並列、当場内は原行順。各sceneを `<session>.ohlc.json`、全成功だけを `完了.json` へ予定順保存する。失敗時は `不完了.json` を残し、部分結果を全体成功にしない。Rawの前後はsize/mtimeを記録し、実SHAは一走査中に期待SHAへ照合する。再hashやRaw複写はしない。

## 検査範囲

人工で同時計ns・inclusive・逆行/欠測時計・Last0・異常BBOのLast採用・H/L初回/最後・partial前後W・閾値・正益後の戻り・買売鏡像・保有後追記非干渉・任意witness・誤境界/SHA拒否を検査する。実70場/1952価格区間/3887状態query/7521保存点のmetadataもRaw未読で検査する。独立監査は別担当が同じ人工とRoot指定の実2場で行う。

11/09と指定外商品、退出後仮想利益、機会損失、MFE回収率、ROI、新金融候補の再生は対象外。Reader停止時点では実70場のOHLCをまだ算出していない。
