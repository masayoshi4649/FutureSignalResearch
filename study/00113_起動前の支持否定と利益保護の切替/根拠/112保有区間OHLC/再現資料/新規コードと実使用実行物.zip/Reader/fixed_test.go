package holdingohlc113

import (
	"encoding/json"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
)

// fixtureRef は人工又は許可された小metadataの期待参照を作ります。
//
// 引数: t(*testing.T)、path(string)は試験器と対象。返り値: FileRefは実指紋です。
func fixtureRef(t *testing.T, path string) FileRef {
	t.Helper()
	sha, err := Digest(path)
	if err != nil {
		t.Fatal(err)
	}
	return FileRef{Path: path, SHA256: sha}
}

// metadataFixture は実台帳metadataと人工停止を結び、Raw未読ゲートを確認します。
//
// 引数: t(*testing.T)は試験器。返り値: FileRef/Fixedは人工固定です。実Rawを開きません。
func metadataFixture(t *testing.T) (FileRef, Fixed) {
	t.Helper()
	_, file, _, _ := runtime.Caller(0)
	here := filepath.Dir(file)
	root := filepath.Clean(filepath.Join(here, "../.."))
	exe, _ := os.Executable()
	exeRef := fixtureRef(t, exe)
	code := fixtureRef(t, filepath.Join(here, "reader.go"))
	all := map[string]string{code.Path: code.SHA256}
	stop, err := SaveNew(filepath.Join(t.TempDir(), "人工停止.json"), Stop{Success: true, Stopped: true, Trial: 113, AllCode: all, Owned: map[string]string{}, Executable: exeRef})
	if err != nil {
		t.Fatal(err)
	}
	codes := map[string]string{code.Path: code.SHA256, stop.Path: stop.SHA256}
	oldLedger := FileRef{Path: filepath.Join(root, "work/113保有区間の建玉台帳と費用後曲線/台帳準備の停止.json"), SHA256: "5e4ab13fc5e82b018d3681f4499aafc54b67b36ea0589dcda18ae0248072f7a4"}
	if err = readRef(oldLedger, nil, map[string]string{}); err != nil {
		t.Fatal(err)
	}
	ledgerStop, err := SaveNew(filepath.Join(t.TempDir(), "人工の台帳停止接続.json"), map[string]any{"成功": true, "停止": true, "台帳準備停止": oldLedger})
	if err != nil {
		t.Fatal(err)
	}
	f := Fixed{Version: 1, Trial: 113, SourceTrial: 112, Fixed: true, RawReadAuthorized: true, Policy: Policy,
		Manifest:        FileRef{Path: filepath.Join(root, "study/00106_収束失速で保護の起動と幅を切り替える/入力台帳_70場.json"), SHA256: ManifestSHA},
		Queries:         FileRef{Path: filepath.Join(root, "work/113保有区間の建玉台帳と費用後曲線/112全24と全70の区間/Reader入力の素材.json"), SHA256: "551a1dfcf94615545e74be79e4191c0e93d1bc3794f6bb252f52bd1b111d92aa"},
		WitnessRequests: FileRef{Path: filepath.Join(root, "work/113保有区間の建玉台帳と費用後曲線/保存点witnessのReader要求素材.json"), SHA256: "fe7bcb3acc652a7ef4ec2dadfaeee86c4e145611e8c3f41eb856d96360ac2734"},
		LedgerStop:      ledgerStop,
		ReaderStop:      stop, Executable: exeRef, CodeSHA256: codes, Sessions: []string{"2026-09-21_Day", "2026-09-21_Night"}}
	ref, err := SaveNew(filepath.Join(t.TempDir(), "人工固定要求.json"), f)
	if err != nil {
		t.Fatal(err)
	}
	return ref, f
}

// TestMetadataOnlyMatchesManifestSchema はidタグ・70場素材・任意witnessをRaw未読で認証します。
//
// 引数: t(*testing.T)は試験器。返り値: ありません。前指紋にRawが混ざらないことを確認します。
func TestMetadataOnlyMatchesManifestSchema(t *testing.T) {
	ref, f := metadataFixture(t)
	p, err := Prepare(ref)
	if err != nil {
		t.Fatal(err)
	}
	if len(p.Scenes) != 2 || len(p.Scenes[0].PriceIntervals) == 0 || len(p.Scenes[0].WitnessRequests) == 0 {
		t.Fatal("実metadataのschema不整合")
	}
	for name := range p.Before {
		if strings.Contains(name, "JP_OSE_Data") {
			t.Fatal("metadata段階のRaw指紋計算")
		}
	}
	var all struct {
		Rows []struct {
			Session string `json:"session"`
		} `json:"raw_inputs"`
	}
	data, err := os.ReadFile(f.Queries.Path)
	if err != nil {
		t.Fatal(err)
	}
	if err = json.Unmarshal(data, &all); err != nil {
		t.Fatal(err)
	}
	full := f
	full.Sessions = nil
	for _, row := range all.Rows {
		full.Sessions = append(full.Sessions, row.Session)
	}
	allRef, err := SaveNew(filepath.Join(t.TempDir(), "全70metadata.json"), full)
	if err != nil {
		t.Fatal(err)
	}
	allPlan, err := Prepare(allRef)
	if err != nil {
		t.Fatal(err)
	}
	prices, states, witnesses := 0, 0, 0
	for _, scene := range allPlan.Scenes {
		prices += len(scene.PriceIntervals)
		states += len(scene.StateSlices)
		witnesses += len(scene.WitnessRequests)
	}
	if len(allPlan.Scenes) != 70 || prices != 1952 || states != 3887 || witnesses != 7521 {
		t.Fatal("全70metadataのquery数", prices, states, witnesses)
	}
	for _, mode := range []string{"未固定", "許可なし", "別期間", "別台帳SHA", "別exe", "閉包差"} {
		t.Run(mode, func(t *testing.T) {
			data, _ := json.Marshal(f)
			var bad Fixed
			_ = json.Unmarshal(data, &bad)
			switch mode {
			case "未固定":
				bad.Fixed = false
			case "許可なし":
				bad.RawReadAuthorized = false
			case "別期間":
				bad.Sessions = []string{"2026-11-09_Day"}
			case "別台帳SHA":
				bad.Manifest.SHA256 = strings.Repeat("0", 64)
			case "別exe":
				bad.Executable.SHA256 = strings.Repeat("0", 64)
			case "閉包差":
				delete(bad.CodeSHA256, bad.ReaderStop.Path)
			}
			b, err := SaveNew(filepath.Join(t.TempDir(), "破壊.json"), bad)
			if err != nil {
				t.Fatal(err)
			}
			if _, err = Prepare(b); err == nil {
				t.Fatal("破壊を受理")
			}
		})
	}
	if _, err := Run(ref, t.TempDir(), 2); err == nil {
		t.Fatal("既存出力先を受理")
	}
}
