"""保有区間Readerを人工とmetadataだけで検査し市場Raw未読で停止する。"""
import ast
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
NAMES=('types.go','reader.go','reader_test.go','fixed.go','fixed_test.go','run.go','cmd/run/main.go','go.mod','README.md','検査して停止する.py')
def digest(path: Path) -> str:
    """機能: 明示コードと人工の全bytes指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def merge(target: dict, values: dict) -> None:
    """機能: Root相対位置を絶対化して停止mapを統合する。

    引数: target/values(dict)は統合先と固定値。
    返り値: None。現物差と衝突はValueError。
    """
    for name, sha in values.items():
        path = Path(name)
        path = (path if path.is_absolute() else ROOT / path).resolve()
        if digest(path) != sha or (str(path) in target and target[str(path)] != sha):
            raise ValueError('停止codeの現物差:' + str(path))
        target[str(path)] = sha


def execute(command: list[str], label: str, env: dict) -> dict:
    """機能: 市場を使わない人工・閉包・ビルドの終了を検査する。

    引数: command(list[str])、label(str)、env(dict)は起動と環境。
    返り値: dictは成功ログ。不成功はValueError。
    """
    result = subprocess.run(command, cwd=HERE, env=env, capture_output=True, text=True, encoding='utf-8')
    row = {'名': label, 'command': command, '終了コード': result.returncode, '標準出力': result.stdout, '標準エラー': result.stderr}
    if result.returncode:
        raise ValueError(json.dumps(row, ensure_ascii=False))
    return row


def go_closure(env: dict) -> tuple[dict, dict]:
    """機能: 実際の並列cmdの全選択ソースと標準ライブラリを固定する。

    引数: env(dict)はCGO0の環境。
    返り値: tuple[dict,dict]は非GoRootとGoRoot。
    """
    stream = execute(['go', 'list', '-deps', '-json', './cmd/run'], '実Go閉包', env)['標準出力']
    decoder, index, local, standard = json.JSONDecoder(), 0, {}, {}
    while index < len(stream):
        while index < len(stream) and stream[index].isspace():
            index += 1
        if index == len(stream):
            break
        package, index = decoder.raw_decode(stream, index)
        if not package.get('Dir'):
            continue
        target = standard if package.get('Goroot') else local
        for key in ('GoFiles', 'CgoFiles', 'SFiles', 'HFiles', 'SysoFiles', 'EmbedFiles'):
            for name in package.get(key, []):
                path = (Path(package['Dir']) / name).resolve()
                target[str(path)] = digest(path)
        module = package.get('Module', {})
        if module.get('GoMod'):
            path = Path(module['GoMod']).resolve()
            local[str(path)] = digest(path)
            if path.with_name('go.sum').exists():
                local[str(path.with_name('go.sum'))] = digest(path.with_name('go.sum'))
    return local, standard


def reference(path: Path) -> dict:
    """機能: 2キーの実FileRefを作る。

    引数: path(Path)は小metadata又は実行物。
    返り値: dictは絶対pathとSHA256。
    """
    return {'path': str(path.resolve()), 'sha256': digest(path)}


def save_new(path: Path, value: dict) -> None:
    """機能: 日本語UTF8とLFで小metadataを新規保存する。

    引数: path(Path)、value(dict)は未使用先と保存値。
    返り値: None。既存先は拒否する。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + '\n')


def main() -> None:
    """機能: 人工/70場metadata/閉包/実行物を記録しRaw未読で停止する。

    引数: なし。市場Raw/Native/価格CSVを開かない。
    返り値: None。停止と出力先が既存なら拒否する。
    """
    if (HERE/'停止.json').exists():
        raise ValueError('停止は新規のみ')
    owned={str((HERE/name).resolve()):digest(HERE/name) for name in NAMES}
    for name in NAMES:
        if name.endswith('.py'):
            for node in ast.walk(ast.parse((HERE/name).read_text(encoding='utf-8'))):
                if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                    doc=ast.get_docstring(node) or ''
                    if '\n' not in doc or any(k not in doc for k in ('機能','引数','返り値')):
                        raise ValueError('関数コメント不足:'+node.name)
    env=dict(os.environ,CGO_ENABLED='0',GOWORK='off',OHLC113_ART_OUT=str(HERE/'人工_停止版'))
    local,standard=go_closure(env)
    full={};merge(full,local);merge(full,standard);merge(full,owned)
    directory=HERE/'検査';directory.mkdir(exist_ok=False)
    exe=directory/'保有中OHLC.exe'
    logs=[execute(['go','test','-json','-count=1','./...'],'人工とmetadata',env),
          execute(['go','vet','./...'],'vet',env),
          execute(['go','build','-o',str(exe),'./cmd/run'],'Reader実行物',env),
          execute(['go','doc','-all','.'],'API',env)]
    events=[json.loads(line) for line in logs[0]['標準出力'].splitlines() if line.startswith('{')]
    passed=[r for r in events if r.get('Action')=='pass' and r.get('Test')]
    mains=[r for r in passed if '/' not in r['Test']];subs=[r for r in passed if '/' in r['Test']]
    if len(mains)!=5 or len(subs)!=15:
        raise ValueError('人工不足:'+str((len(mains),len(subs))))
    for path,sha in full.items():
        if digest(Path(path))!=sha:
            raise ValueError('自己又は閉包の前後差:'+path)
    api=directory/'API.txt';api.write_text(logs[-1]['標準出力'],encoding='utf-8',newline='\n')
    artifact={str(p.resolve()):digest(p) for folder in ('人工_独立監査用','人工_停止版') for p in sorted((HERE/folder).rglob('*')) if p.is_file()}
    stop={'成功':True,'停止':True,'trial':113,'UTC':datetime.now(timezone.utc).isoformat(),
          '所有コードSHA256':owned,'Go閉包SHA256':local,'GoRootコードSHA256':standard,'全固定コードSHA256':full,
          '実行物':reference(exe),'実API':reference(api),'主人工':len(mains),'副人工':len(subs),
          '人工出力SHA256':artifact,'ログ':logs,'自己コード全依存前後不変':True,
          '市場Raw/Native/11月09日読取':0,'金融再実行':False,'実70OHLC算出':False}
    save_new(HERE/'停止.json',stop)
    stopref=reference(HERE/'停止.json');codemap=dict(full);codemap[stopref['path']]=stopref['sha256']
    manifest=ROOT/'study/00106_収束失速で保護の起動と幅を切り替える/入力台帳_70場.json'
    inputs=ROOT/'work/113保有区間の建玉台帳と費用後曲線'
    query=inputs/'112全24と全70の区間/Reader入力の素材.json'
    witness=inputs/'保存点witnessのReader要求素材.json'
    m=json.loads(manifest.read_text(encoding='utf-8-sig'))
    material={'version':1,'trial':113,'source_trial':112,'fixed':False,'raw_read_authorized':False,
              'policy':'holding_interval_ohlc112_v1','manifest':reference(manifest),'queries':reference(query),
              'witness_requests':reference(witness),'ledger_stop':None,'reader_stop':stopref,
              'executable':reference(exe),'code_sha256':codemap,'sessions':[row['id'] for row in m['sessions']],
              'ledger_preparation':reference(inputs/'台帳準備の停止.json'),
              'ledger_stop_note':'Rootが5e4の成功/成果物/所有前後不変を認証した新しい停止接続wrapperを指定する'}
    save_new(HERE/'条件の素材.json',material)
    print(json.dumps({'成功':True,'停止':stopref,'素材':reference(HERE/'条件の素材.json'),'実行物':reference(exe),'主人工':len(mains),'副人工':len(subs),'固定code':len(full)},ensure_ascii=True))

if __name__=='__main__':
    main()
