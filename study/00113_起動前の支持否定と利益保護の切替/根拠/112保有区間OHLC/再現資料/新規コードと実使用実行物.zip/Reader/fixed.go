package holdingohlc113

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"time"
)

const Policy = "holding_interval_ohlc112_v1"
const ManifestSHA = "902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8"

type Fixed struct {
	Version           int               `json:"version"`
	Trial             int               `json:"trial"`
	SourceTrial       int               `json:"source_trial"`
	Fixed             bool              `json:"fixed"`
	RawReadAuthorized bool              `json:"raw_read_authorized"`
	Policy            string            `json:"policy"`
	Manifest          FileRef           `json:"manifest"`
	Queries           FileRef           `json:"queries"`
	WitnessRequests   FileRef           `json:"witness_requests"`
	LedgerStop        FileRef           `json:"ledger_stop"`
	ReaderStop        FileRef           `json:"reader_stop"`
	Executable        FileRef           `json:"executable"`
	CodeSHA256        map[string]string `json:"code_sha256"`
	Sessions          []string          `json:"sessions"`
}

type Stop struct {
	Success    bool              `json:"成功"`
	Stopped    bool              `json:"停止"`
	Trial      int               `json:"trial"`
	Owned      map[string]string `json:"所有コードSHA256"`
	AllCode    map[string]string `json:"全固定コードSHA256"`
	Executable FileRef           `json:"実行物"`
}

type Plan struct {
	Condition FileRef
	Fixed     Fixed
	Scenes    []Scene
	Before    map[string]string
}

type manifest struct {
	Root     string `json:"source_root"`
	Sessions []struct {
		ID       string  `json:"id"`
		Contract string  `json:"contract"`
		Cutoff   float64 `json:"cutoff"`
		Files    map[string]struct {
			Path   string `json:"path"`
			SHA256 string `json:"sha256"`
			Size   int64  `json:"size"`
		} `json:"files"`
	} `json:"sessions"`
}

// Digest は小metadata又はコードの実指紋を計算します。RawはScanFileの一走査で別計算します。
//
// 引数: path(string)は対象。返り値: string/errorはSHA256又は読取失敗です。
func Digest(path string) (string, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:]), nil
}

// readRef はRoot指定の小metadataを期待指紋へ照合して復元します。
//
// 引数: ref(FileRef)、target(any)、before(map[string]string)は参照・復元先・記録先。返り値: errorは差です。
func readRef(ref FileRef, target any, before map[string]string) error {
	if !filepath.IsAbs(ref.Path) || len(ref.SHA256) != 64 {
		return fmt.Errorf("絶対metadata参照とSHAが必要")
	}
	sha, err := Digest(ref.Path)
	if err != nil || sha != ref.SHA256 {
		return fmt.Errorf("metadata指紋差:%s:%v", ref.Path, err)
	}
	data, err := os.ReadFile(ref.Path)
	if err != nil {
		return err
	}
	if target != nil {
		if err = json.Unmarshal(data, target); err != nil {
			return err
		}
	}
	before[ref.Path] = ref.SHA256
	return nil
}

// sessionTimes は固定台帳のDay/Nightに対応するJST境界だけを作ります。
//
// 引数: id(string)は場ID。返り値: start/end(float64)/errorは時計又は不正です。
func sessionTimes(id string) (float64, float64, error) {
	parts := strings.Split(id, "_")
	if len(parts) != 2 {
		return 0, 0, fmt.Errorf("場ID不正")
	}
	day, err := time.ParseInLocation("2006-01-02", parts[0], time.FixedZone("JST", 9*3600))
	if err != nil {
		return 0, 0, err
	}
	start, end := day.Add(8*time.Hour+45*time.Minute), day.Add(15*time.Hour+45*time.Minute)
	if parts[1] == "Night" {
		start = day.Add(17 * time.Hour)
		end = day.AddDate(0, 0, 1).Add(6 * time.Hour)
	} else if parts[1] != "Day" {
		return 0, 0, fmt.Errorf("場種不正")
	}
	return float64(start.Unix()), float64(end.Unix()), nil
}

// Prepare は固定Reader/台帳/70場metadataだけを認証し、Rawを開かず当場計画を作ります。
//
// 引数: condition(FileRef)はRootの新固定OHLC要求。返り値: Plan/errorは本文未読の計画です。
func Prepare(condition FileRef) (Plan, error) {
	p := Plan{Condition: condition, Before: map[string]string{}}
	if err := readRef(condition, &p.Fixed, p.Before); err != nil {
		return p, err
	}
	f := p.Fixed
	if f.Version != 1 || f.Trial != 113 || f.SourceTrial != 112 || !f.Fixed || !f.RawReadAuthorized || f.Policy != Policy || f.Manifest.SHA256 != ManifestSHA || len(f.Sessions) == 0 {
		return p, fmt.Errorf("Rootの113保有中OHLC固定要求が必要")
	}
	var stop Stop
	if err := readRef(f.ReaderStop, &stop, p.Before); err != nil {
		return p, err
	}
	if !stop.Success || !stop.Stopped || stop.Trial != 113 || stop.Executable != f.Executable {
		return p, fmt.Errorf("Reader停止/実行物差")
	}
	expected := map[string]string{}
	for _, codes := range []map[string]string{stop.AllCode, stop.Owned} {
		for path, sha := range codes {
			if old, ok := expected[path]; ok && old != sha {
				return p, fmt.Errorf("停止code衝突")
			}
			expected[path] = sha
		}
	}
	expected[f.ReaderStop.Path] = f.ReaderStop.SHA256
	if !reflect.DeepEqual(expected, f.CodeSHA256) {
		return p, fmt.Errorf("Root固定と停止全閉包差")
	}
	for path, sha := range expected {
		if err := readRef(FileRef{Path: path, SHA256: sha}, nil, p.Before); err != nil {
			return p, err
		}
	}
	exe, err := os.Executable()
	if err != nil {
		return p, err
	}
	actual, err := Digest(exe)
	if err != nil || actual != f.Executable.SHA256 {
		return p, fmt.Errorf("実行中exeの指紋差")
	}
	if err = readRef(f.Executable, nil, p.Before); err != nil {
		return p, err
	}
	var ledgerStop map[string]json.RawMessage
	if err = readRef(f.LedgerStop, &ledgerStop, p.Before); err != nil {
		return p, err
	}
	var success, stopped bool
	if json.Unmarshal(ledgerStop["成功"], &success) != nil || json.Unmarshal(ledgerStop["停止"], &stopped) != nil || !success || !stopped {
		return p, fmt.Errorf("台帳の停止が必要")
	}
	var m manifest
	var queries Ledger
	if err = readRef(f.Manifest, &m, p.Before); err != nil {
		return p, err
	}
	if err = readRef(f.Queries, &queries, p.Before); err != nil {
		return p, err
	}
	var witnesses struct {
		Version     int              `json:"version"`
		Trial       int              `json:"trial"`
		SourceTrial int              `json:"source_trial"`
		Rows        []WitnessRequest `json:"witnesses"`
	}
	if err = readRef(f.WitnessRequests, &witnesses, p.Before); err != nil {
		return p, err
	}
	if witnesses.Version != 1 || witnesses.Trial != 113 || witnesses.SourceTrial != 112 {
		return p, fmt.Errorf("保存原行witness要求の版差")
	}
	if len(m.Sessions) != 70 || !filepath.IsAbs(m.Root) || m.Sessions[0].ID != "2026-09-21_Day" || m.Sessions[69].ID != "2026-11-06_Night" {
		return p, fmt.Errorf("固定70場の入力台帳が必要")
	}
	wanted := map[string]bool{}
	for _, sid := range f.Sessions {
		if wanted[sid] {
			return p, fmt.Errorf("要求場重複")
		}
		wanted[sid] = true
	}
	bySession := map[string]*Scene{}
	allRaw := map[string]FileRef{}
	allContracts := map[string]string{}
	for _, input := range m.Sessions {
		file, ok := input.Files["NK225_book"]
		if !ok {
			return p, fmt.Errorf("NK225_bookが必要")
		}
		clean := filepath.Clean(filepath.FromSlash(file.Path))
		if filepath.IsAbs(clean) || clean == ".." || strings.HasPrefix(clean, ".."+string(filepath.Separator)) {
			return p, fmt.Errorf("原板の根外参照")
		}
		raw := FileRef{Path: filepath.Join(m.Root, clean), SHA256: file.SHA256}
		allRaw[input.ID] = raw
		allContracts[input.ID] = input.Contract
		if !wanted[input.ID] {
			continue
		}
		start, end, e := sessionTimes(input.ID)
		if e != nil {
			return p, e
		}
		p.Scenes = append(p.Scenes, Scene{Session: input.ID, Contract: input.Contract, Start: start, End: end, Cutoff: input.Cutoff, Raw: raw, RawBytes: file.Size})
	}
	if len(p.Scenes) != len(wanted) {
		return p, fmt.Errorf("固定70場以外の要求を拒否")
	}
	for i := range p.Scenes {
		bySession[p.Scenes[i].Session] = &p.Scenes[i]
	}
	// ----------------------------------------
	// 原板pathをquery側から受け取らず、停止済み70台帳のNK225_bookだけから解決します。
	var rawRows struct {
		Raw []struct {
			Session  string  `json:"session"`
			Contract string  `json:"contract"`
			Raw      FileRef `json:"raw"`
		} `json:"raw_inputs"`
	}
	if err = readRef(f.Queries, &rawRows, p.Before); err != nil {
		return p, err
	}
	if len(rawRows.Raw) != 70 {
		return p, fmt.Errorf("query素材の70場Raw参照不足")
	}
	rawSeen := map[string]bool{}
	for _, row := range rawRows.Raw {
		if rawSeen[row.Session] || allRaw[row.Session] != row.Raw || allContracts[row.Session] != row.Contract {
			return p, fmt.Errorf("query素材と70台帳Rawの指紋差")
		}
		rawSeen[row.Session] = true
	}
	intervalSession := map[string]string{}
	allIDs := map[string]bool{}
	for _, interval := range queries.PriceIntervals {
		if allIDs[interval.ID] {
			return p, fmt.Errorf("台帳の価格ID重複")
		}
		allIDs[interval.ID] = true
		intervalSession[interval.ID] = interval.Session
		if _, ok := allRaw[interval.Session]; !ok {
			return p, fmt.Errorf("台帳に未使用期間")
		}
		if scene := bySession[interval.Session]; scene != nil {
			scene.PriceIntervals = append(scene.PriceIntervals, interval)
		}
	}
	for _, state := range queries.StateSlices {
		sid, ok := intervalSession[state.IntervalID]
		if !ok {
			return p, fmt.Errorf("queryの価格ID参照不在")
		}
		if scene := bySession[sid]; scene != nil {
			scene.StateSlices = append(scene.StateSlices, state)
		}
	}
	for _, w := range witnesses.Rows {
		if _, ok := allRaw[w.Session]; !ok {
			return p, fmt.Errorf("保存原行witnessが未使用期間")
		}
		if scene := bySession[w.Session]; scene != nil {
			scene.WitnessRequests = append(scene.WitnessRequests, w)
		}
	}
	for _, scene := range p.Scenes {
		if err = validateScene(scene); err != nil {
			return p, err
		}
	}
	return p, nil
}

// SaveNew は結果をUTF8/LFで新規保存し指紋を返します。
//
// 引数: path(string)、value(any)は未使用先と値。返り値: FileRef/errorは保存指紋又は既存先等です。
func SaveNew(path string, value any) (FileRef, error) {
	data, err := json.MarshalIndent(value, "", "  ")
	if err != nil {
		return FileRef{}, err
	}
	data = append(data, '\n')
	f, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0644)
	if err != nil {
		return FileRef{}, err
	}
	_, err = f.Write(data)
	closeErr := f.Close()
	if err == nil {
		err = closeErr
	}
	if err != nil {
		return FileRef{}, err
	}
	sha, err := Digest(path)
	return FileRef{Path: path, SHA256: sha}, err
}
