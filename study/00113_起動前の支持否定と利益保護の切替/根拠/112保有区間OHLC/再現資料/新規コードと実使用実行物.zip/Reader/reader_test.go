package holdingohlc113

import (
	"compress/gzip"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"
)

// rawRow はSourceと同じfield型の人工原板1行だけを作ります。
//
// 引数: at(string)、last/bid/ask(float64)は時計と価格。返り値: map[string]anyは市場でない人工です。
func rawRow(at string, last, bid, ask float64) map[string]any {
	r := map[string]any{"Symbol": "人工限月", "CurrentPriceTime": at, "CurrentPrice": last, "HighPrice": 99999, "LowPrice": 1, "HighPriceTime": at, "LowPriceTime": at}
	for _, side := range []string{"Buy", "Sell"} {
		for i := 1; i <= 10; i++ {
			price := bid
			if side == "Sell" {
				price = ask
			}
			r[fmt.Sprintf("%s%d", side, i)] = map[string]float64{"Price": price, "Qty": 1}
		}
	}
	return r
}

// makeFixture は同時計・逆行時計・無効Last・無効BBOを含む手計算用gzipを作ります。
//
// 引数: t(*testing.T)、side(int)、future(bool)は試験器・鏡像・保有後追記。返り値: Sceneは当人工のqueryです。
func makeFixture(t *testing.T, side int, future bool) Scene {
	t.Helper()
	start, _, err := sessionTimes("2026-09-21_Day")
	if err != nil {
		t.Fatal(err)
	}
	base := time.Unix(int64(start), 0).In(time.FixedZone("JST", 9*3600))
	clock := func(seconds int64, nano int) string {
		return base.Add(time.Duration(seconds)*time.Second + time.Duration(nano)).Format(time.RFC3339Nano)
	}
	rows := []map[string]any{rawRow(clock(1, 0), 102, 100, 105), rawRow(clock(2, 1), 157, 156, 158), rawRow(clock(2, 1), 500, 160, 160), rawRow(clock(1, 500000000), 601, 600, 602), rawRow("不正時計", 777, 776, 778), rawRow(clock(3, 0), 0, 201, 203), rawRow(clock(3, 0), 100, 99, 101), rawRow(clock(4, 0), 207, 206, 208), rawRow(clock(4, 1), 500, 206, 208)}
	if future {
		rows = append(rows, rawRow(clock(5, 0), 9000, 8999, 9001))
	}
	if side < 0 {
		for _, r := range rows {
			if r["CurrentPrice"].(float64) > 0 {
				r["CurrentPrice"] = 1000 - r["CurrentPrice"].(float64)
			}
			for i := 1; i <= 10; i++ {
				b := r[fmt.Sprintf("Buy%d", i)].(map[string]float64)
				a := r[fmt.Sprintf("Sell%d", i)].(map[string]float64)
				bid, ask := 1000-a["Price"], 1000-b["Price"]
				b["Price"], a["Price"] = bid, ask
			}
		}
	}
	path := filepath.Join(t.TempDir(), "人工.jsonl.gz")
	f, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	z := gzip.NewWriter(f)
	for _, r := range rows {
		data, _ := json.Marshal(r)
		if _, err = z.Write(append(data, '\n')); err != nil {
			t.Fatal(err)
		}
	}
	if err = z.Close(); err != nil {
		t.Fatal(err)
	}
	if err = f.Close(); err != nil {
		t.Fatal(err)
	}
	sha, err := Digest(path)
	if err != nil {
		t.Fatal(err)
	}
	quote := func(line int64, index int64) Quote {
		r := rows[line-1]
		at, _ := time.Parse(time.RFC3339Nano, r["CurrentPriceTime"].(string))
		q := Quote{Time: float64(at.UnixNano()) / 1e9, Index: index, SourceLine: line, Last: r["CurrentPrice"].(float64), Bid: r["Buy1"].(map[string]float64)["Price"], Ask: r["Sell1"].(map[string]float64)["Price"]}
		q.QuoteOK = normal(q)
		return q
	}
	q1, q7, q9 := quote(1, 0), quote(7, 3), quote(9, 5)
	intervals := []PriceInterval{{ID: "whole", Session: "2026-09-21_Day", Start: q1, End: q9, StartInclusive: true, EndInclusive: true}, {ID: "before", Session: "2026-09-21_Day", Start: q1, End: q7, StartInclusive: true, EndInclusive: true}, {ID: "after", Session: "2026-09-21_Day", Start: q7, End: q9, StartInclusive: true, EndInclusive: true}}
	entry := 105.0
	if side < 0 {
		entry = 895
	}
	thresholds := []Threshold{{ID: "positive", Strict: true}, {ID: "H50", WholeYen: 10000}, {ID: "H100", WholeYen: 20000}}
	return Scene{Session: "2026-09-21_Day", Contract: "人工限月", Start: start, End: start + 3600, Raw: FileRef{Path: path, SHA256: sha}, PriceIntervals: intervals,
		StateSlices:     []StateSlice{{ID: "R0n2", IntervalID: "before", Side: side, EntryPrice: entry, N: 2, R: 0, K: 77, Q0: 2, Thresholds: thresholds}, {ID: "Rminus677n1", IntervalID: "after", Side: side, EntryPrice: entry, N: 1, R: -677, K: 77, Q0: 2, Thresholds: thresholds}},
		WitnessRequests: []WitnessRequest{{ID: "same_clock_first", Session: "2026-09-21_Day", Index: 1, SourceLine: 2}, {ID: "bad_bbo", Session: "2026-09-21_Day", Index: 2, SourceLine: 3}}}
}

// TestOHLCAndStateSlices は手計算の価格/費用後W・inclusive境界・初回/最後を照合します。
//
// 引数: t(*testing.T)は試験器。返り値: ありません。累積payload高安を使わないことも確認します。
func TestOHLCAndStateSlices(t *testing.T) {
	s := makeFixture(t, 1, false)
	v, err := ScanFile(s)
	if err != nil {
		t.Fatal(err)
	}
	p := v.PriceIntervals["whole"]
	if !v.Success || v.RawPasses != 1 || v.Quality.Lines != 9 || v.Quality.Delivered != 6 || v.Quality.Backward != 1 || v.Quality.ClockInvalid != 1 || v.Quality.LastNonPositive != 1 || v.Quality.BadBBO != 1 {
		t.Fatal(v.Quality)
	}
	if p.RawRows != 9 || p.AcceptedRows != 6 || p.Last.Open.Value != 102 || p.Last.High.Value != 500 || p.Last.High.First.SourceLine != 3 || p.Last.High.Last.SourceLine != 9 || p.Last.Low.Value != 100 || p.Last.Close.Value != 500 {
		t.Fatal(p.Last)
	}
	if p.Bid.Count != 5 || p.Bid.High.Value != 206 || p.Bid.High.First.SourceLine != 8 || p.Bid.High.Last.SourceLine != 9 || p.Ask.High.Value != 208 || p.BadBBORows != 1 {
		t.Fatal(p)
	}
	a, b := v.StateQueries["R0n2"], v.StateQueries["Rminus677n1"]
	if a.WholeYen.Open.Value != -1154 || a.WholeYen.High.Value != 10046 || a.WholeYen.Low.Value != -1354 || b.WholeYen.Open.Value != -1354 || b.WholeYen.High.Value != 9346 {
		t.Fatal(a, b)
	}
	if a.Thresholds[0].First.Quote.SourceLine != 2 || a.Thresholds[1].First.Quote.SourceLine != 2 || a.Thresholds[2].First != nil || b.Thresholds[1].First != nil {
		t.Fatal("初回閾値とpartial後会計")
	}
	if a.WholeReturns.FirstNonpositiveAfterPositive.Quote.SourceLine != 7 || a.WholeReturns.FirstNegativeAfterPositive.Quote.SourceLine != 7 || b.WholeReturns.FirstNonpositive.Quote.SourceLine != 7 || b.WholeReturns.FirstNegativeAfterPositive != nil {
		t.Fatal("符号戻り")
	}
	if v.Witnesses["same_clock_first"].Quote.Clock == "" || v.Witnesses["bad_bbo"].Quote.QuoteOK || v.Witnesses["bad_bbo"].Quote.Index != 2 {
		t.Fatal("任意保存原行とnanosecond元時計")
	}
}

// TestMirrorsAndNoPostExitValues は買売鏡像と保有後追記の非干渉を検査します。
//
// 引数: t(*testing.T)は試験器。返り値: ありません。退出後の仮想利益は計算しません。
func TestMirrorsAndNoPostExitValues(t *testing.T) {
	a, e := ScanFile(makeFixture(t, 1, false))
	if e != nil {
		t.Fatal(e)
	}
	b, e := ScanFile(makeFixture(t, -1, false))
	if e != nil {
		t.Fatal(e)
	}
	c, e := ScanFile(makeFixture(t, 1, true))
	if e != nil {
		t.Fatal(e)
	}
	for key, x := range a.StateQueries {
		y := b.StateQueries[key]
		if x.WholeYen.High.Value != y.WholeYen.High.Value || x.WholeYen.Low.Value != y.WholeYen.Low.Value || x.WholeYen.Open.Value != y.WholeYen.Open.Value {
			t.Fatal("鏡像W")
		}
	}
	if !reflect.DeepEqual(a.PriceIntervals, c.PriceIntervals) || !reflect.DeepEqual(a.StateQueries, c.StateQueries) || !reflect.DeepEqual(a.Witnesses, c.Witnesses) {
		t.Fatal("保有後の価格が結果を変更")
	}
}

// TestRejectedBoundariesAndReferences は誤った原行・Index・閾値・参照SHAを成功へ補いません。
//
// 引数: t(*testing.T)は試験器。返り値: ありません。全て一時人工です。
func TestRejectedBoundariesAndReferences(t *testing.T) {
	for _, mode := range []string{"開始価格差", "終了Index差", "EOF欠行", "SHA差", "非inclusive", "重複価格区間", "閾値差", "witnessIndex差", "witness未採用行"} {
		t.Run(mode, func(t *testing.T) {
			s := makeFixture(t, 1, false)
			switch mode {
			case "開始価格差":
				s.PriceIntervals[0].Start.Bid++
			case "終了Index差":
				s.PriceIntervals[0].End.Index++
			case "EOF欠行":
				s.PriceIntervals[0].End.SourceLine = 100
			case "SHA差":
				s.Raw.SHA256 = strings.Repeat("0", 64)
			case "非inclusive":
				s.PriceIntervals[0].StartInclusive = false
			case "重複価格区間":
				x := s.PriceIntervals[0]
				x.ID = "重複"
				s.PriceIntervals = append(s.PriceIntervals, x)
			case "閾値差":
				s.StateSlices[0].Thresholds[1].WholeYen = 1
			case "witnessIndex差":
				s.WitnessRequests[0].Index++
			case "witness未採用行":
				s.WitnessRequests[0].SourceLine = 4
			}
			v, err := ScanFile(s)
			if err == nil || v.Success {
				t.Fatal("破壊を受理")
			}
		})
	}
}

// TestExportArtificial は指定時だけ独立監査用の一時人工結果とqueryを保存します。
//
// 引数: t(*testing.T)、環境変数OHLC113_ART_OUT(string)は試験器と新規先。返り値: ありません。
func TestExportArtificial(t *testing.T) {
	out := os.Getenv("OHLC113_ART_OUT")
	if out == "" {
		t.Skip("人工保存先なし")
	}
	if err := os.Mkdir(out, 0755); err != nil {
		t.Fatal(err)
	}
	refs := map[string]FileRef{}
	for _, item := range []struct {
		Name string
		Side int
	}{{"買い", 1}, {"売り", -1}} {
		scene := makeFixture(t, item.Side, false)
		raw := filepath.Join(out, item.Name+".jsonl.gz")
		data, err := os.ReadFile(scene.Raw.Path)
		if err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(raw, data, 0644); err != nil {
			t.Fatal(err)
		}
		scene.Raw.Path = raw
		value, err := ScanFile(scene)
		if err != nil {
			t.Fatal(err)
		}
		refs[item.Name], err = SaveNew(filepath.Join(out, item.Name+".json"), value)
		if err != nil {
			t.Fatal(err)
		}
		refs[item.Name+"入力"], err = SaveNew(filepath.Join(out, item.Name+"入力.json"), scene)
		if err != nil {
			t.Fatal(err)
		}
	}
	if _, err := SaveNew(filepath.Join(out, "人工.json"), map[string]any{"成功": true, "試行": 113, "人工": true, "市場Raw": false, "資料": refs}); err != nil {
		t.Fatal(err)
	}
}
