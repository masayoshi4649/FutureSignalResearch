package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"

	reader "github.com/masayoshi4649/SessionTradeExecuter/holdingohlc113"
)

// run はRoot固定のmetadata確認又は保有区間走査だけを行います。
//
// 引数: なし。CLIのfixed/fixed-sha/out/workers/metadata-onlyを使います。返り値: errorは不正又は不完了です。
func run() error {
	fixed := flag.String("fixed", "", "RootのOHLC固定要求")
	sha := flag.String("fixed-sha", "", "要求SHA256")
	out := flag.String("out", "", "未使用出力先")
	workers := flag.Int("workers", 8, "独立場の並列1..8")
	metadata := flag.Bool("metadata-only", false, "原板未読の認証のみ")
	flag.Parse()
	if *fixed == "" || *sha == "" || (!*metadata && *out == "") {
		return fmt.Errorf("固定要求とSHA、新規先が必要")
	}
	ref := reader.FileRef{Path: *fixed, SHA256: *sha}
	if *metadata {
		p, err := reader.Prepare(ref)
		if err != nil {
			return err
		}
		return json.NewEncoder(os.Stdout).Encode(map[string]any{"metadata_verified": true, "raw_read": false, "sessions": len(p.Scenes)})
	}
	value, err := reader.Run(ref, *out, *workers)
	if err != nil {
		return err
	}
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"success": value.Success, "sessions": value.Sessions, "raw_passes": value.RawPasses})
}

// main は不成功を終了1へ反映します。
//
// 引数: なし。返り値: ありません。金融戦略や新注文を実行しません。
func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
