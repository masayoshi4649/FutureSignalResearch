module github.com/masayoshi4649/SessionTradeExecuter/holdingohlc113

go 1.24.2
