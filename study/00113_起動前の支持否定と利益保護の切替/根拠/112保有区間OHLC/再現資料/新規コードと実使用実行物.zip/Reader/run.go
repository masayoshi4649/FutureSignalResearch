package holdingohlc113

import (
	"fmt"
	"os"
	"path/filepath"
	"sync"
)

type SceneRef struct {
	Session        string  `json:"session"`
	Result         FileRef `json:"result"`
	PriceIntervals int     `json:"price_intervals"`
	StateQueries   int     `json:"state_queries"`
	Witnesses      int     `json:"witnesses"`
}

type Completion struct {
	Version         int               `json:"version"`
	Trial           int               `json:"trial"`
	SourceTrial     int               `json:"source_trial"`
	Success         bool              `json:"success"`
	Condition       FileRef           `json:"condition"`
	Queries         FileRef           `json:"queries"`
	WitnessRequests FileRef           `json:"witness_requests"`
	Manifest        FileRef           `json:"manifest"`
	Sessions        int               `json:"sessions"`
	RawPasses       int               `json:"raw_passes"`
	Results         []SceneRef        `json:"results"`
	Before          map[string]string `json:"before"`
	After           map[string]string `json:"after"`
	Unchanged       bool              `json:"unchanged"`
	FinancialReplay bool              `json:"financial_replay"`
}

// Run は独立場だけを最大8並列で走査し、全成功時だけ予定順の完了を保存します。
//
// 引数: condition(FileRef)、out(string)、workers(int)はRoot要求・新規先・上限。返り値: Completion/errorは全成功又は不完了です。
func Run(condition FileRef, out string, workers int) (complete Completion, err error) {
	if workers < 1 || workers > 8 {
		return complete, fmt.Errorf("workerは1..8")
	}
	p, err := Prepare(condition)
	if err != nil {
		return complete, err
	}
	abs, err := filepath.Abs(out)
	if err != nil {
		return complete, err
	}
	if err = os.MkdirAll(filepath.Dir(abs), 0755); err != nil {
		return complete, err
	}
	if err = os.Mkdir(abs, 0755); err != nil {
		return complete, fmt.Errorf("出力は新規のみ:%w", err)
	}
	complete = Completion{Version: 1, Trial: 113, SourceTrial: 112, Condition: condition, Queries: p.Fixed.Queries, WitnessRequests: p.Fixed.WitnessRequests, Manifest: p.Fixed.Manifest, Before: p.Before, Results: []SceneRef{}}
	defer func() {
		if err != nil {
			_, _ = SaveNew(filepath.Join(abs, "不完了.json"), map[string]any{"success": false, "condition": condition, "error": err.Error()})
		}
	}()
	type outcome struct {
		index int
		ref   SceneRef
		err   error
	}
	queue := make(chan int, len(p.Scenes))
	results := make(chan outcome, len(p.Scenes))
	for i := range p.Scenes {
		queue <- i
	}
	close(queue)
	if workers > len(p.Scenes) {
		workers = len(p.Scenes)
	}
	var wg sync.WaitGroup
	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for index := range queue {
				value, e := ScanFile(p.Scenes[index])
				var ref FileRef
				if e == nil {
					ref, e = SaveNew(filepath.Join(abs, value.Session+".ohlc.json"), value)
				}
				results <- outcome{index: index, ref: SceneRef{Session: p.Scenes[index].Session, Result: ref, PriceIntervals: len(value.PriceIntervals), StateQueries: len(value.StateQueries), Witnesses: len(value.Witnesses)}, err: e}
			}
		}()
	}
	wg.Wait()
	close(results)
	ordered := make([]SceneRef, len(p.Scenes))
	var failures []string
	for row := range results {
		if row.err != nil {
			failures = append(failures, row.err.Error())
		} else {
			ordered[row.index] = row.ref
		}
	}
	if len(failures) > 0 {
		return complete, fmt.Errorf("原板/境界走査不成功:%v", failures)
	}
	complete.After = map[string]string{}
	for path, sha := range p.Before {
		actual, e := Digest(path)
		if e != nil || actual != sha {
			return complete, fmt.Errorf("固定metadata/code前後差:%s", path)
		}
		complete.After[path] = actual
	}
	complete.Results = ordered
	complete.Sessions = len(ordered)
	complete.RawPasses = len(ordered)
	complete.Unchanged = true
	complete.Success = true
	_, err = SaveNew(filepath.Join(abs, "完了.json"), complete)
	return complete, err
}
