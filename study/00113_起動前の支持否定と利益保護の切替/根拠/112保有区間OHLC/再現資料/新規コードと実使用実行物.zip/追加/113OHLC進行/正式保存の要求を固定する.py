"""成功済み原板集計・全件検算・二場独立監査とCSV三点を正式保存へ結ぶ。"""
import hashlib
import json
import sys
from pathlib import Path


def ref(path: Path) -> dict:
    """現物の参照を得る。

    引数: path(Path)は小さい検査資料又はコード。
    返り値: dictは絶対Path/SHA。
    """
    return {'path':str(path.resolve()),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """停止済み保存器へ渡す新規要求を固定する。

    引数: sys.argv(list[str])は成功した独立監査JSONと期待SHA。
    返り値: None。原板本文・金融Native・中間全件表の複写は行わない。
    """
    root=Path(__file__).resolve().parents[2]
    template=root/'work/113保有区間OHLCの正式保存/固定要求のひな形.json'
    assert ref(template)['sha256']=='acd3f157633c062d72ae9b7f1fd2dd50165a60da029d898103d2a6f8f59b87f4'
    d=json.loads(template.read_bytes())
    metadata=[r for r in d['code_refs'] if Path(r['ref']['path']).suffix.lower()=='.json']
    d['code_refs']=[r for r in d['code_refs'] if Path(r['ref']['path']).suffix.lower()!='.json']
    for row in metadata:
        if Path(row['ref']['path']).name=='CSV入力の列契約.json':
            d['extra_refs'].append({'target':'検査/追加/CSV入力の列契約.json','ref':row['ref']})
        # 保存点witness要求はReader固定要求から保存器が同byteで別途収録する。
    if len(sys.argv) == 5:
        saver=Path(sys.argv[3]).resolve()
        saver_ref=ref(saver)
        assert saver_ref['sha256']==sys.argv[4]
        stopped=json.loads(saver.read_bytes())
        assert stopped['成功'] and stopped['停止']
        d['saver_stop']=saver_ref
    audit=Path(sys.argv[1]).resolve()
    audit_ref=ref(audit)
    assert audit_ref['sha256']==sys.argv[2]
    a=json.loads(audit.read_bytes())
    assert a['success'] and a['unchanged'] and a['source_trial']==112 and not a['financial_replay']
    # ----------------------------------------
    # CSVと既存Nativeの単なる全件転記になる大きい中間二点は正式複写しない。
    omitted=['集計/CSV用の統合結果.json.gz','診断/保存点差と曲線の検査.json.gz']
    d['extra_refs']=[r for r in d['extra_refs'] if r['target'] not in omitted]
    additions=[
        ('検査/追加/二場独立監査.json',audit),
        ('検査/追加/二場独立監査のRoot要求.json',root/'work/113OHLC進行/11月06二場の独立監査要求_参照同体.json'),
        ('検査/追加/独立監査の参照接合修正版停止.json',root/'work/113保有区間OHLCの独立監査_参照同体/停止.json'),
        ('検査/追加/全件表の独立検算.json',root/'work/113OHLC進行/全件表の独立検算.json'),
        ('検査/追加/CSVの確認.json',root/'work/113OHLC進行/CSVの確認.json'),
        ('検査/追加/CSVの独立再読.json',root/'work/113OHLC進行/CSVの独立再読.json'),
    ]
    for target,p in additions:
        d['extra_refs'].append({'target':target,'ref':ref(p)})
    # ----------------------------------------
    # 新しい依存だけを明示する。使用していない作業helperを一括収録しない。
    new_codes=[root/'work/113入口枝と保護起動前損失の診断/診断する.py']
    audit_stop=json.loads((root/'work/113保有区間OHLCの独立監査_参照同体/停止.json').read_bytes())
    new_codes += [Path(p) for p in audit_stop['所有コードSHA256']]
    new_codes += [root/'work/113OHLCのCSV出力'/n for n in ['出力する.mjs','CSVを独立再読する.py']]
    new_codes += [root/'work/113OHLC進行'/n for n in ['原板照合の要求を固定する.py','統合表を検算する.py','OHLCの所見を作る.py','正式保存の要求を固定する.py']]
    for p in new_codes:
        d['code_refs'].append({'archive_path':p.relative_to(root/'work').as_posix(),'ref':ref(p)})
    csv=root/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/112保有区間OHLC'
    d['csv_refs']={name:ref(csv/name) for name in ['候補別損失診断.csv','建玉全体OHLC.csv','返済片OHLC.csv']}
    d['fixed']=True
    d['reader_result_read_authorized']=True
    d['中間全件表の扱い']={'正式複写しない':omitted,'理由':'正本CSV/既存Nativeの全件転記を重複保存しない。元RefとSHAは統合の確認に残し、保存コード・Reader結果・既存Nativeから再生成できる。'}
    filename='112保有区間OHLCの正式保存要求_成果物参照整理.json' if len(sys.argv)==5 else '112保有区間OHLCの正式保存要求.json'
    p=root/'work/113OHLC進行'/filename
    raw=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    p.open('xb').write(raw)
    print(json.dumps({'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'コード追加数':len(new_codes)},ensure_ascii=False))


if __name__=='__main__':
    main()
