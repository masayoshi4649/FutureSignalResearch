"""既存112と停止済みReader/台帳だけを束ね、70NK原板の区間集計を固定する。"""
import hashlib
import json
import sys
from pathlib import Path


def read_ref(path: Path, expected: str) -> tuple[dict, dict]:
    """期待指紋で小さい参照を認証する。

    引数: path(Path)、expected(str)は入力と期待SHA。
    返り値: tuple[dict,dict]は復元値と絶対参照。
    """
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == expected, path
    return json.loads(raw.decode('utf-8-sig')), {'path': str(path.resolve()), 'sha256': expected}


def save(path: Path, value: dict) -> dict:
    """新規JSONを保存し指紋を返す。

    引数: path(Path)、value(dict)は出力先と内容。
    返り値: dictはFileRef。既存は上書きしない。
    """
    raw = (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
    with path.open('xb') as handle:
        handle.write(raw)
    return {'path': str(path.resolve()), 'sha256': hashlib.sha256(raw).hexdigest()}


def main() -> None:
    """Reader停止を認証し、原板実走査の新要求を保存する。

    引数: sys.argv(list[str])はReader停止pathとSHA。
    返り値: None。Rawのopen/stat/hashと金融再生は行わない。
    """
    root = Path(__file__).resolve().parents[2]
    reader, reader_ref = read_ref(Path(sys.argv[1]), sys.argv[2])
    assert reader['成功'] and reader['停止'] and reader['trial'] == 113
    codes = {}
    for name in ['全固定コードSHA256', '所有コードSHA256']:
        for p, h in reader[name].items():
            assert p not in codes or codes[p] == h
            assert hashlib.sha256(Path(p).read_bytes()).hexdigest() == h, p
            codes[p] = h
    codes[reader_ref['path']] = reader_ref['sha256']
    exe = reader['実行物']
    assert hashlib.sha256(Path(exe['path']).read_bytes()).hexdigest() == exe['sha256']
    ledger_path = root / 'work/113保有区間の建玉台帳と費用後曲線/台帳準備の停止.json'
    ledger, ledger_ref = read_ref(ledger_path, '5e4ab13fc5e82b018d3681f4499aafc54b67b36ea0589dcda18ae0248072f7a4')
    assert ledger['成功'] and ledger['建玉行数'] == 13332 and ledger['返済片行数'] == 14908
    assert ledger['Raw開封'] == 0 and not ledger['市場再生']
    for p, h in ledger['所有ファイルSHA256'].items():
        assert hashlib.sha256(Path(p).read_bytes()).hexdigest() == h, p
    for ref in [ledger['台帳確認'], *ledger['成果物'].values()]:
        assert hashlib.sha256(Path(ref['path']).read_bytes()).hexdigest() == ref['sha256']
    gate = save(Path(__file__).with_name('台帳停止のRoot認証.json'), {'成功':True,'停止':True,'trial':113,'台帳準備停止':ledger_ref,'所有と成果物不変':True,'金融再生':False,'原板未読':True})
    query = ledger['成果物']['Reader入力の素材.json']
    _, witness = read_ref(root / 'work/113保有区間の建玉台帳と費用後曲線/保存点witnessのReader要求素材.json', 'fe7bcb3acc652a7ef4ec2dadfaeee86c4e145611e8c3f41eb856d96360ac2734')
    manifest, manifest_ref = read_ref(root / 'study/00106_収束失速で保護の起動と幅を切り替える/入力台帳_70場.json', '902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8')
    _, completion = read_ref(root / 'study/00112_支持否定の確認と通常追尾幅の比較/検査/完了記録.json', '432fbbaf445a9d00916d927a4b87cb5992500ad585507189a71d499e498e672c')
    sessions = [s['id'] for s in manifest['sessions']]
    assert len(sessions) == len(set(sessions)) == 70 and sessions[-1] == '2026-11-06_Night'
    condition = {'version':1,'trial':113,'source_trial':112,'fixed':True,'raw_read_authorized':True,'policy':'holding_interval_ohlc112_v1','manifest':manifest_ref,'queries':query,'witness_requests':witness,'ledger_stop':gate,'reader_stop':reader_ref,'executable':exe,'code_sha256':codes,'sessions':sessions,'Root根拠':{'固定112完了':completion,'台帳準備停止':ledger_ref},'許可':'70 NK225_bookの区間OHLC・到達原行と費用後評価の一走査。独立監査2場を別許可。','禁止':['11月09の価格・損益・入力指紋','113金融再生','退出後価格の仮想損益','原板本文の複写','機会損失の採点']}
    ref = save(Path(__file__).with_name('112保有区間OHLCの固定要求.json'), condition)
    print(json.dumps({'成功':True,'条件':ref,'実行物':exe,'場数':70,'Raw未読':True}, ensure_ascii=False))


if __name__ == '__main__':
    main()
