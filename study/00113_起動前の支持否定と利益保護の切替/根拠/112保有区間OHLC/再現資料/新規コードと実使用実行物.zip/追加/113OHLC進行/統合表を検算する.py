"""統合後の全件表を、OHLC境界・配賦会計・保存台帳により検算する。"""
import gzip
import hashlib
import json
import sys
from collections import defaultdict
from decimal import Decimal
from pathlib import Path


def load(path: Path):
    """gz又はJSONを十進数で復元する。

    引数: path(Path)は入力。
    返り値: objectは復元値。
    """
    raw = path.read_bytes()
    return json.loads((gzip.decompress(raw) if path.suffix == '.gz' else raw).decode('utf-8-sig'), parse_float=Decimal)


def main() -> None:
    """全CSV入力の範囲・実会計と原台帳不変を確認する。

    引数: sys.argv(list[str])は集計gz・SHA・新規検査JSON先。
    返り値: None。
    """
    source, expected, target = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
    assert hashlib.sha256(source.read_bytes()).hexdigest() == expected
    data = load(source)
    assert data['成功']
    positions, allocations, summaries = data['建玉全体'], data['返済片'], data['候補別集計']
    assert [len(positions),len(allocations),len(summaries)] == [13332,14908,24]
    parent = {(r['口座'],r['建玉ID']): r for r in positions}
    assert len(parent) == len(positions)
    total = defaultdict(lambda:defaultdict(Decimal))
    position_net, position_qty = defaultdict(Decimal), defaultdict(Decimal)
    counts = defaultdict(int)
    for r in positions + allocations:
        start, end = r['取得物理行'], r.get('最終返済物理行',r.get('返済物理行'))
        assert r['Raw境界一致'] and end >= start
        for kind in ['Last','Bid','Ask']:
            o,h,l,c = (r[kind+s] for s in ['始値','高値','安値','終値'])
            assert h >= max(o,c) >= min(o,c) >= l, r['建玉ID']
            assert r[kind+'始値物理行'] == start and r[kind+'終値物理行'] == end
            for level in ['高値','安値']:
                a,b = r[kind+level+'初回物理行'],r[kind+level+'最終物理行']
                assert start <= a <= b <= end
            counts['OHLC系列'] += 1
        assert r['全玉最大W円'] >= r['実現純利益円'] >= r['全玉最小W円']
        for prefix in ['全玉最大W','全玉最小W','1枚最大費用後益','1枚最小費用後益']:
            assert start <= r[prefix+'初回物理行'] <= r[prefix+'最終物理行'] <= end
        if r['H50初到達時刻'] is not None:
            assert r['H50初到達円'] >= r['曲線基準枚数'] * 5000
        if r['H100初到達時刻'] is not None:
            assert r['H100初到達円'] >= r['曲線基準枚数'] * 10000
    # ----------------------------------------
    # 実返済片から親の実現額を作り、初期枚数を最後まで保有したと仮定しない。
    for r in allocations:
        k=(r['口座'],r['建玉ID'])
        assert k in parent
        p=parent[k]
        assert p['取得価格'] == r['取得価格'] and p['取得物理行'] == r['取得物理行']
        sign = 1 if r['売買']=='買い' else -1
        gross = sign*(r['返済価格']-r['取得価格'])*100*r['返済枚数']
        fee = Decimal(77)*r['返済枚数']
        slip = Decimal(200)*r['滑りpt']*r['返済枚数']
        assert [gross,fee,slip,gross-fee-slip] == [r[c] for c in ['実現粗利益円','往復手数料円','往復滑り円','実現純利益円']]
        assert r['返済前n']-r['返済後n'] == r['返済枚数']
        assert r['返済前W円'] == r['返済後W円']
        assert r['返済後R円']-r['返済前R円'] == r['実現純利益円']
        position_net[k] += r['実現純利益円']
        position_qty[k] += r['返済枚数']
        total[r['口座']]['返済片数'] += 1
        for name in ['往復手数料円','往復滑り円']:
            total[r['口座']][name] += r[name]
        counts['返済片会計'] += 1
    for r in positions:
        k=(r['口座'],r['建玉ID'])
        assert position_net[k] == r['実現純利益円'] and position_qty[k] == r['初期枚数']
        positive_then_red = r['全玉最大W円']>0 and r['実現純利益円']<0
        assert positive_then_red == r['実正益後赤字']
        t=total[r['口座']]
        t['建玉数'] += 1
        t['新規枚数'] += r['初期枚数']
        for name in ['実現粗利益円','実現純利益円']:
            t[name] += r[name]
        t['実正益後赤字玉数'] += int(positive_then_red)
        t['実正益後赤字円'] += r['実現純利益円'] if positive_then_red else 0
        counts['親配賦検算'] += 1
    for r in summaries:
        assert r['場数'] == 70
        for name,value in total[r['口座']].items():
            assert value == r[name], (r['口座'],name,value,r[name])
    root=Path(__file__).resolve().parents[2]
    ledger=root/'work/113保有区間の建玉台帳と費用後曲線/112全24と全70の区間/建玉全体の台帳.jsonl.gz'
    with gzip.open(ledger,'rt',encoding='utf-8') as handle:
        for line in handle:
            r=json.loads(line,parse_float=Decimal)
            p=parent[(r['key'],r['position_id'])]
            assert r['final_net_yen']==p['実現純利益円']
            assert r['marks']['whole_max']['whole_net']==p['全玉最大W円']
            assert r['marks']['whole_min']['whole_net']==p['全玉最小W円']
            counts['保存台帳数値照合'] += 3
    assert hashlib.sha256(source.read_bytes()).hexdigest() == expected
    result={'成功':True,'入力SHA256':expected,'件数':dict(counts),'全件境界一致':True,'全返済配賦保存':True,'全24口座70場':True,'入力前後不変':True,'原板再走査':False,'金融再生':False}
    with target.open('x',encoding='utf-8') as handle:
        json.dump(result,handle,ensure_ascii=False,indent=2)
    print(json.dumps(result,ensure_ascii=False))


if __name__ == '__main__':
    main()
