"""自然Rawを開かず参照表記の同体と指紋・対象差の拒否を検査する。"""
from pathlib import Path
import importlib.util
import sys
import unittest

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("ref_gate_artificial", HERE / "独立走査を実行する.py")
M = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = M
spec.loader.exec_module(M)


class RefTests(unittest.TestCase):
    """既存の絶対コードPathだけを使う小metadata参照の人工。"""

    def test_bytes(self):
        """
        機能: bytes等の付加metadataだけの差を許容する。
        引数: self(RefTests)。返り値: None。
        """
        ref = {"path": str(HERE / "README.md"), "sha256": "a"*64}
        self.assertTrue(M.same_ref(ref, dict(ref, bytes=100)))

    def test_slash(self):
        """
        機能: 同じ解決絶対Pathのslash表記差を許容する。
        引数: self(RefTests)。返り値: None。
        """
        ref = {"path": str(HERE / "README.md"), "sha256": "a"*64}
        self.assertTrue(M.same_ref(ref, dict(ref, path=ref["path"].replace("\\", "/"))))

    def test_sha(self):
        """
        機能: 同PathでもSHA差を拒否する。
        引数: self(RefTests)。返り値: None。
        """
        ref = {"path": str(HERE / "README.md"), "sha256": "a"*64}
        self.assertFalse(M.same_ref(ref, dict(ref, sha256="b"*64)))

    def test_path(self):
        """
        機能: 同SHAでも別Pathを拒否する。
        引数: self(RefTests)。返り値: None。
        """
        ref = {"path": str(HERE / "README.md"), "sha256": "a"*64}
        self.assertFalse(M.same_ref(ref, dict(ref, path=str(HERE / "別.json"))))

    def test_invalid(self):
        """
        機能: 相対Path・欠落値・非参照値を拒否する。
        引数: self(RefTests)。返り値: None。
        """
        ref = {"path": str(HERE / "README.md"), "sha256": "a"*64}
        for value in (None, {}, dict(ref, path="README.md"), dict(ref, sha256=None)):
            self.assertFalse(M.same_ref(ref, value))


if __name__ == "__main__":
    unittest.main(verbosity=2)
