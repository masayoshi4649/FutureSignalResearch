"""独立二場監査の人工とCLIを自然Raw前に固定する。"""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import os
import subprocess

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / "113保有区間OHLCの独立監査"
OLD_STOP_SHA = "ce7cbb5cda0c3c195d3e792de85f3cd8b10ba25250e8a95fb96fb25175ede94a"


def digest(p: Path) -> str:
    """
    機能: 所有コード又は人工metadataの指紋を計算する。
    引数: p(Path)。返り値: strはSHA256。自然Rawを渡さない。
    """
    return hashlib.sha256(p.read_bytes()).hexdigest()


def execute(command: list[str]) -> dict:
    """
    機能: 自然Rawを開かない人工だけを実行する。
    引数: command(list[str])。返り値: dictは成功ログ。不成功なら例外。
    """
    r = subprocess.run(command, cwd=HERE, env=dict(os.environ, PYTHONIOENCODING="utf-8"), capture_output=True, text=True, encoding="utf-8", timeout=60)
    row = {"command": command, "exit_code": r.returncode, "stdout": r.stdout, "stderr": r.stderr}
    if r.returncode:
        raise ValueError(json.dumps(row, ensure_ascii=False))
    return row


def main() -> None:
    """
    機能: 所有code・8人工・主Reader手製買売対照と実CLIを市場前停止する。
    引数: なし。返り値: None。実Raw・市場Nativeの追加読取はない。
    """
    if (HERE / "停止.json").exists() or (HERE / "検査").exists():
        raise ValueError("停止は新規先だけ")
    if digest(OLD / "停止.json") != OLD_STOP_SHA:
        raise ValueError("旧停止差")
    old = json.loads((OLD / "停止.json").read_text(encoding="utf-8"))
    if any(digest(Path(p)) != sha for p,sha in old["所有コードSHA256"].items()):
        raise ValueError("旧停止code差")
    for name in ("区間の独立算術.py", "Reader対照の算術.py", "区間監査の人工検査.py", "Reader人工の独立検査.py"):
        if digest(HERE / name) != digest(OLD / name):
            raise ValueError("非参照部分の差:"+name)
    restored = (HERE / "独立走査を実行する.py").read_text(encoding="utf-8")
    replacements = {
        'not same_ref(complete.get("condition"), req["main_condition"])': 'complete.get("condition") != req["main_condition"]',
        'not same_ref(complete.get("queries"), main["queries"])': 'complete.get("queries") != main["queries"]',
        'not same_ref(result["raw"], rawref)': 'result["raw"] != rawref',
    }
    for new, previous in replacements.items():
        if restored.count(new) != 1:
            raise ValueError("限定参照差の式不足")
        restored = restored.replace(new, previous)
    tree = ast.parse(restored)
    tree.body = [node for node in tree.body if not isinstance(node, ast.FunctionDef) or node.name != "same_ref"]
    if ast.dump(tree) != ast.dump(ast.parse((OLD / "独立走査を実行する.py").read_text(encoding="utf-8"))):
        raise ValueError("参照比較以外のCLI AST差")
    names = ["区間の独立算術.py", "Reader対照の算術.py", "独立走査を実行する.py", "区間監査の人工検査.py", "Reader人工の独立検査.py", "参照比較の人工検査.py", "README.md", Path(__file__).name]
    owned = {str((HERE / name).resolve()): digest(HERE / name) for name in names}
    for name in names:
        if name.endswith(".py"):
            for node in ast.walk(ast.parse((HERE / name).read_text(encoding="utf-8"))):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    text = ast.get_docstring(node) or ""
                    if "\n" not in text or not all(x in text for x in ("機能", "引数", "返り値")):
                        raise ValueError("関数コメント不足:"+node.name)
    out = HERE / "検査"
    out.mkdir()
    logs = [execute(["python", "区間監査の人工検査.py"]), execute(["python", "Reader人工の独立検査.py", "--out", str(out / "主Reader人工対照.json")]), execute(["python", "独立走査を実行する.py", "--help"]), execute(["python", "参照比較の人工検査.py"])]
    if "Ran 8 tests" not in logs[0]["stderr"] or "OK" not in logs[0]["stderr"]:
        raise ValueError("8主人工の完了不足")
    if "Ran 5 tests" not in logs[3]["stderr"] or "OK" not in logs[3]["stderr"]:
        raise ValueError("5参照人工の完了不足")
    if any(digest(Path(p)) != sha for p,sha in owned.items()):
        raise ValueError("自己code前後差")
    if digest(OLD / "停止.json") != OLD_STOP_SHA or any(digest(Path(p)) != sha for p,sha in old["所有コードSHA256"].items()):
        raise ValueError("旧停止の前後差")
    stop = {"成功": True, "停止": True, "市場前": True, "module": "holding_ohlc_independent_audit113", "UTC": datetime.now(timezone.utc).isoformat(),
            "所有コードSHA256": owned, "前後不変": True, "人工主": 8, "主Reader買売人工": 2, "phase_n_R破壊": 3, "参照metadata人工": 5,
            "旧停止": {"path": str(OLD / "停止.json"), "sha256": OLD_STOP_SHA}, "旧停止code前後不変": True,
            "限定変更": {"参照比較": "解決絶対Path＋SHA256。bytes付加とslash差は許容、別Path/SHA差/相対Pathは拒否", "比較箇所": ["complete.condition", "complete.queries", "scene.raw"], "比較以外CLI_AST同体": True, "算術と既存人工4file同byte": True},
            "人工証拠": {"path": str(out / "主Reader人工対照.json"), "sha256": digest(out / "主Reader人工対照.json")},
            "実CLI": "python 独立走査を実行する.py --request ABS --request-sha SHA", "metadata_cli": "同CLI + --metadata-only",
            "自然Raw独立走査の許可範囲": ["2026-11-06_Day", "2026-11-06_Night"], "自然Raw走査済み": False,
            "market_native_replay": False, "marks_reserved_checked": False, "検査ログ": logs}
    (HERE / "停止.json").write_text(json.dumps(stop, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"成功": True, "停止": {"path": str(HERE / "停止.json"), "sha256": digest(HERE / "停止.json")}}, ensure_ascii=False))


if __name__ == "__main__":
    main()
