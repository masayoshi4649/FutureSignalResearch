"""112の正式保存値だけから、成立玉の入口タグと保護起動の関係を診断する。"""

import argparse
import collections
import gzip
import hashlib
import json
from decimal import Decimal
from pathlib import Path


BASE = Path(__file__).resolve().parents[2]
STUDY = BASE / "study/00112_支持否定の確認と通常追尾幅の比較"
CLOSURE = STUDY / "検査/完了記録.json"
CLOSURE_SHA = "432fbbaf445a9d00916d927a4b87cb5992500ad585507189a71d499e498e672c"
UNKNOWN = "不明"
KEYS = [f"{p}_C{c}_D{d}" for p in ["S0", "W100", "P100"] for c in [0, 5] for d in [0, 1]]
METHODS = ["NK225_D164_15", "NK225_P164_06", "NK225_U165_03", UNKNOWN]
OWNERS = ["core", "addon", "episode", UNKNOWN]
KINDS = ["initial", "delayed_initial", "source_add", UNKNOWN]
PERIODS = ["全70", "元54", "追加16", "11月06日", "11月06日_Day", "11月06日_Night"]
FIELDS = [
    "実建玉数", "新規mini枚", "返済mini枚", "費用後実現純額円", "正実現額円", "負実現額円",
    "勝ち玉数", "負け玉数", "同値玉数", "全玉正益観測玉数", "保護起動玉数",
    "全玉正益後赤字玉数", "全玉正益後赤字額円", "未起動完結赤字玉数", "未起動完結赤字額円",
    "起動後赤字玉数", "起動後赤字額円",
] + [f"赤字_{w}_{a}_{u}" for w in ["全玉正益なし", "全玉正益あり"]
     for a in ["未起動", "起動あり"] for u in ["玉数", "額円"]]
MATCH = {
    "positions": "実建玉数", "entry_quantity": "新規mini枚", "close_quantity": "返済mini枚",
    "net_yen": "費用後実現純額円", "positive_yen": "正実現額円", "negative_yen": "負実現額円",
    "positive_positions": "勝ち玉数", "negative_positions": "負け玉数", "zero_positions": "同値玉数",
    "whole_positive_positions": "全玉正益観測玉数", "protection_activated_positions": "保護起動玉数",
    "whole_positive_closed_negative": "全玉正益後赤字玉数",
    "whole_positive_closed_negative_yen": "全玉正益後赤字額円",
    "activated_closed_negative": "起動後赤字玉数", "activated_closed_negative_yen": "起動後赤字額円",
}


def need(ok, message):
    """条件を検査する。

    引数: ok(bool)は成立条件、message(str)は不成立の理由。
    返り値: None。条件不成立時はValueErrorを送出する。
    """
    if not ok:
        raise ValueError(message)


def sha(path):
    """ファイルの指紋を計算する。

    引数: path(Path)は対象ファイル。
    返り値: strはSHA256の小文字16進表記。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    """JSONを十進数のまま読む。

    引数: path(Path)は入力JSON。
    返り値: dict又はlistは復号した保存値。
    """
    return json.loads(path.read_bytes(), parse_float=Decimal)


def encode(value):
    """十進数を含む診断値をJSONへ符号化する。

    引数: value(dict又はlist)は診断値。
    返り値: strはUTF-8で保存するJSON文字列。
    """
    return json.dumps(value, ensure_ascii=False, indent=2,
                      default=lambda x: int(x) if x == x.to_integral_value() else float(x)) + "\n"


def bind(ref, before):
    """固定Refを現物へ照合して入力台帳へ登録する。

    引数: ref(dict)はpath/sha256、before(dict)は入力指紋台帳。
    返り値: Pathは認証済みの絶対ファイルパス。
    """
    p = Path(ref["path"])
    need(p.is_absolute() and p.is_file(), f"入力不在:{p}")
    need("2026-11-09" not in str(p), "11月09日は対象外")
    h = sha(p)
    need(h == ref["sha256"], f"入力SHA差:{p}")
    before[str(p)] = h
    return p


def zero():
    """全0の集計行を作る。

    引数: なし。
    返り値: dict[str,int]は全指標を持つ空群。
    """
    return dict.fromkeys(FIELDS, 0)


def add(total, value):
    """排他的な成立玉の指標を加算する。

    引数: total(dict)は加算先、value(dict)は同じ指標群。
    返り値: None。totalを更新する。
    """
    for k in FIELDS:
        total[k] += value[k]


def entry_tags(native):
    """miniの実入口Signalを場・商品・手法・IDの複合キーへ索引する。

    引数: native(dict)は認証済み112 Native。
    返り値: dict[tuple,dict]は価格の未来値を使わない入口タグ索引。
    """
    found = {}
    sid = native["source"]["session"]["id"]
    for src in native["source"]["sources"].values():
        if src["config"]["product"] != "NK225mini":
            continue
        need(src["session"]["id"] == sid, "Source場の混入")
        holds = {h["hold_id"]: h for h in src["holds"]}
        need(len(holds) == len(src["holds"]), "Source所有ID重複")
        for rec in src["signals"]:
            s = rec["signal"]
            if s["action"] != "new":
                continue
            key = (sid, "NK225mini", src["method"], s["id"])
            need(key not in found, f"Source入口重複:{key}")
            found[key] = {"signal": s, "record": rec, "holds": holds}
    return found


def classify(position, book, index, sid):
    """一つの成立玉を保存入口タグへ結び、実返済額と起動有無を検査する。

    引数: position(dict)は実玉、book(dict)は口座、index(dict)はSource入口索引、sid(str)は場。
    返り値: tuple[dict,dict]は分類台帳1行と加算指標。重複・不整合は拒否する。
    """
    p = position
    source = p["source"]
    key = (sid, "NK225mini", source["method"], source["signal_id"])
    need(key in index, f"Source入口結合欠落:{key}")
    item = index[key]
    s, rec = item["signal"], item["record"]
    e = s.get("evidence") or {}
    need(p["side"] == s["side"], "Source売買方向差")
    need(source["birth_time"] == rec["at"] == s["time"] and source["birth_quote"] == rec["quote"], "Source出生時計差")
    for field in ["method", "kind", "parent", "source_id", "quantity_micro"]:
        need(source.get(field) == e.get(field), f"Source入口保存値差:{field}")
    need(p["source_hold_id"] in item["holds"], "Source実所有が存在しない")
    h = item["holds"][p["source_hold_id"]]
    need(h["entry_id"] == s["id"] and h["side"] == p["side"], "Source所有入口差")
    for field in ["kind", "parent", "source_id"]:
        need(h.get(field) == e.get(field), f"Source所有タグ差:{field}")
    entries = [o for o in book["orders"] if o["id"] == p["entry_order_id"]]
    need(len(entries) == 1 and entries[0]["kind"] == "entry" and entries[0]["source"] == source, "実入口注文結合差")
    newfills = [f for f in book["fills"] if f["action"] == "new" and f["position_id"] == p["id"]]
    need(len(newfills) == 1 and newfills[0]["source"] == source and newfills[0]["source_hold_id"] == p["source_hold_id"], "実新規約定結合差")
    need(newfills[0]["quantity"] == p["initial_quantity"] and newfills[0]["quote"] == p["entry_quote"], "実新規数量時計差")
    need(p["quantity"] == p["reserved"] == 0 and p["closed_quantity"] == p["initial_quantity"], "未完結玉")
    parts = [a for f in book["fills"] if f["action"] == "close" for a in f["allocations"] if a["position_id"] == p["id"]]
    need(sum(a["quantity"] for a in parts) == p["initial_quantity"], "実返済枚数差")
    need(sum(Decimal(str(a["net_yen"])) for a in parts) == p["realized_net"], "実返済片の純額差")
    net = Decimal(str(p["realized_net"]))
    active = p["protection_active"]
    need(type(active) is bool and active == (p["activation"] is not None), "実起動フラグと保存点の差")
    if active:
        aq, cq = p["activation"]["quote"], p["closed_quote"]
        need((aq["time"], aq["index"]) <= (cq["time"], cq["index"]), "返済後起動")
    whole = p["marks"]["first_whole_positive"] is not None
    if whole:
        need(p["marks"]["first_whole_positive"]["whole_net"] > 0, "全玉正益保存点が非正")
    owner, kind = s.get("owner") or UNKNOWN, e.get("kind") or UNKNOWN
    method = source.get("method") or UNKNOWN
    stat = zero()
    stat.update({"実建玉数": 1, "新規mini枚": p["initial_quantity"], "返済mini枚": p["closed_quantity"],
                 "費用後実現純額円": net, "全玉正益観測玉数": int(whole), "保護起動玉数": int(active)})
    stat["勝ち玉数" if net > 0 else "負け玉数" if net < 0 else "同値玉数"] = 1
    stat["正実現額円" if net > 0 else "負実現額円"] = net
    if net < 0:
        if whole:
            stat["全玉正益後赤字玉数"], stat["全玉正益後赤字額円"] = 1, net
        name = "起動後赤字" if active else "未起動完結赤字"
        stat[name + "玉数"], stat[name + "額円"] = 1, net
        matrix = f"赤字_{'全玉正益あり' if whole else '全玉正益なし'}_{'起動あり' if active else '未起動'}_"
        stat[matrix + "玉数"], stat[matrix + "額円"] = 1, net
    row = {"session": sid, "key": book["key"], "position_id": p["id"], "product": "NK225mini",
           "method": method, "owner": owner, "kind": kind, "parent": e.get("parent") or UNKNOWN,
           "campaign": s.get("campaign"), "signal_id": s["id"], "source_id": e.get("source_id"),
           "source_hold_id": p["source_hold_id"], "source_reason": s.get("reason"),
           "入口方向型": UNKNOWN, "入口方向型の理由": "入口evidenceにmode等の方向型保存なし",
           "birth_quote": source["birth_quote"], "entry_quote": p["entry_quote"], "side": p["side"],
           "quantity": p["initial_quantity"], "net_yen": net, "whole_positive": whole, "protection_active": active}
    return row, stat


def compare(stat, expected, label):
    """実玉の加法と独立正本の同一定義を照合する。

    引数: stat(dict)は新集計、expected(dict)は112独立正本、label(str)は照合名。
    返り値: intは一致した数値項目数。不一致はValueErrorを送出する。
    """
    for original, current in MATCH.items():
        need(stat[current] == expected[original], f"独立正本との差:{label}/{original}:{stat[current]} != {expected[original]}")
    need(stat["負け玉数"] == stat["未起動完結赤字玉数"] + stat["起動後赤字玉数"], "赤字起動分類の非加法")
    need(stat["負実現額円"] == stat["未起動完結赤字額円"] + stat["起動後赤字額円"], "赤字起動額の非加法")
    for unit, target in [("玉数", "負け玉数"), ("額円", "負実現額円")]:
        need(sum(stat[f"赤字_{w}_{a}_{unit}"] for w in ["全玉正益なし", "全玉正益あり"]
                 for a in ["未起動", "起動あり"]) == stat[target], "赤字2×2の非加法")
    return len(MATCH)


def selected_periods(sid, history):
    """重なりを明示した診断対象群を選ぶ。

    引数: sid(str)は場ID、history(str)は独立正本の元54/追加16区分。
    返り値: list[str]は当場を含む診断対象群。
    """
    need(history in ["original54", "additional16"], "履歴区分不明")
    out = ["全70", "元54" if history == "original54" else "追加16"]
    if sid.startswith("2026-11-06_"):
        out += ["11月06日", "11月06日_" + sid.split("_")[1]]
    return out


# ----------------------------------------


def run(out):
    """固定112の正本を認証し、保存値だけで113用診断を作る。

    引数: out(Path)は未作成の診断先。
    返り値: dictは入力不変と独立正本一致を含む成功記録。
    """
    need(not out.exists(), "新規出力先が必要")
    before = {}
    bind({"path": str(CLOSURE), "sha256": CLOSURE_SHA}, before)
    closure = load(CLOSURE)
    need(closure["成功"] and closure["試行完了"] and closure["試行"] == 112, "112未完了")
    refs = closure["正本"]
    # 完了記録の全正本・CSVは指紋のみを先行認証し、CSV本文は復号しない。
    for ref in list(refs.values()) + list(closure["CSV"].values()) + [closure["旧111不変"], closure["CSVの見方"]]:
        bind(ref, before)
    result = load(Path(refs["独立1680"]["path"]))
    formal = load(Path(refs["正式保存"]["path"]))
    ledger = load(bind(formal["Native台帳"], before))
    need(result["成功"] and result["場数"] == 70 and result["会計数"] == 1680 and result["前後不変"], "独立正本不成立")
    need(formal["成功"] and formal["前後不変"] and len(ledger["Native"]) == 70, "正式台帳不成立")
    original = {(r["session"], r["key"]): r for r in result["場別"]}
    native_refs = {r["session"]: r for r in result["Native参照"]}
    paths = []
    for row in ledger["Native"]:
        need("2026-11-09" not in row["session"], "11月09日は対象外")
        p = (STUDY / row["relative"]).resolve()
        need(p.is_relative_to((STUDY / "成果物_金融/Native").resolve()), "正式Native範囲外")
        need(row["sha256"] == native_refs[row["session"]]["sha256"], "正本Native指紋の結合差")
        bind({"path": str(p), "sha256": row["sha256"]}, before)
        paths.append((row["session"], p))
    totals = {(period, key): zero() for period in PERIODS for key in KEYS}
    grouped = {}
    for period in PERIODS:
        for key in KEYS:
            for method in METHODS:
                for owner in OWNERS:
                    for kind in KINDS:
                        grouped[(period, key, method, owner, kind)] = zero()
    records, per_scene, tags_seen = [], [], collections.Counter()
    checks = 0
    for sid, p in paths:
        x = json.loads(gzip.decompress(p.read_bytes()), parse_float=Decimal)
        need(x["trial"] == 112 and x["source"]["session"]["id"] == sid, "Native版/場差")
        index = entry_tags(x)
        for key in KEYS:
            book = x["actual"]["books"][key]
            need(book["key"] == key and book["finished"] and book["complete"], "口座未完了")
            scene_stat = zero()
            need(len({z["id"] for z in book["positions"]}) == len(book["positions"]), "実玉ID重複")
            expected = original[(sid, key)]
            periods = selected_periods(sid, expected["history_class"])
            for pos in book["positions"]:
                record, stat = classify(pos, book, index, sid)
                record["history_class"] = expected["history_class"]
                need(record["method"] in METHODS and record["owner"] in OWNERS and record["kind"] in KINDS, "未宣言タグ値:明示追加が必要")
                records.append(record)
                add(scene_stat, stat)
                tags_seen[(record["method"], record["owner"], record["kind"], record["parent"])] += 1
                for period in periods:
                    add(totals[(period, key)], stat)
                    add(grouped[(period, key, record["method"], record["owner"], record["kind"])], stat)
            checks += compare(scene_stat, expected, sid + "/" + key)
            need(scene_stat["費用後実現純額円"] == book["totals"]["net_yen"], "Native口座純額差")
            per_scene.append({"session": sid, "key": key, "history_class": expected["history_class"], **scene_stat})
    for key in KEYS:
        checks += compare(totals[("全70", key)], result["集計"][key], "全70/" + key)
        for period in PERIODS:
            summed = zero()
            for method in METHODS:
                for owner in OWNERS:
                    for kind in KINDS:
                        add(summed, grouped[(period, key, method, owner, kind)])
            need(summed == totals[(period, key)], "枝別の全加法差")
        merged = zero()
        add(merged, totals[("元54", key)])
        add(merged, totals[("追加16", key)])
        need(merged == totals[("全70", key)], "元54+追加16の差")
    after = {p: sha(Path(p)) for p in before}
    need(before == after, "入力の前後差")
    value = {
        "試行": 113, "入力試行": 112, "成功": True, "対象政策": ["S0", "W100", "P100"], "費用条件数": 4,
        "場数": 70, "口座場数": 840, "実玉台帳行数": len(records), "正本数値比較数": checks,
        "完了記録": {"path": str(CLOSURE), "sha256": CLOSURE_SHA},
        "定義": {
            "一玉": "実新規fill1回のPosition。部分返済片を合計し、全返済後の実現純額で勝敗を定義。",
            "枝": "miniの場/商品/method/signal_idを厳密結合した入口Signal.owner。D/P/Uとは別軸。",
            "段階": "入口Signal.evidence.kind。parent/campaignは台帳に原値保持し、枝型を推定しない。",
            "全玉正益後赤字": "marks.first_whole_positiveが保存され、最終実現純額が負。",
            "未起動完結赤字": "実protection_active=falseかつactivation=nullで完結した赤字。S0は追加保護なし。",
            "起動後赤字": "実protection_active=trueかつactivation保存ありで完結した赤字。",
            "負実現額": "損失を負数で表示。正額+負額=純額。各率の分母は実建玉数。",
            "全0群": "各対象群×12口座×4手法値×4枝値×4段階値を全て保持。不明を0でも残す。",
        },
        "総計": [{"対象群": p, "key": k, **totals[(p, k)]} for p in PERIODS for k in KEYS],
        "枝と段階": [{"対象群": p, "key": k, "method": m, "owner": o, "kind": t, **v}
                    for (p, k, m, o, t), v in grouped.items()],
        "場別": per_scene,
        "保存された親タグ": [{"method": m, "owner": o, "kind": k, "parent": p, "実玉の延べ数": n}
                          for (m, o, k, p), n in sorted(tags_seen.items())],
        "不明": {"入口枝不明玉数": sum(r["owner"] == UNKNOWN for r in records),
                 "段階不明玉数": sum(r["kind"] == UNKNOWN for r in records),
                 "手法不明玉数": sum(r["method"] == UNKNOWN for r in records),
                 "addon内の方向型": "入口evidenceにmode等が保存されていないため不明。突破/往復等を推定しない。",
                 "leg": "独立したlegフィールドなし。owner/kind/parentを使用し、legという分類は補完しない。"},
        "入力SHA256前": before, "入力SHA256後": after, "前後不変": True,
        "限界": ["成立した実玉だけの記述的診断。枝単独の因果効果、採用条件、将来利益を意味しない。",
                  "保存された少数点と実約定台帳を再読した。全Raw原行や未保存の起動前後値を独立再走していない。",
                  "対象群は重複する。全70=元54+追加16、11月06日は追加16の内数。政策・費用口座同士を合算しない。",
                  "未起動は正益未観測と同義ではない。S0はH100の未達判定をしていない。"],
        "市場再生": False, "Raw読取": 0, "11月09本文読取": 0, "機会損失評価": False,
        "新金融条件実行": False, "採用": False, "研究目標達成": False,
    }
    out.mkdir()
    (out / "結果.json").write_text(encode(value), encoding="utf-8")
    with (out / "成立玉の分類.jsonl").open("x", encoding="utf-8", newline="\n") as f:
        for r in records:
            f.write(json.dumps(r, ensure_ascii=False, default=lambda v: int(v) if v == v.to_integral_value() else float(v)) + "\n")
    confirmation = {"試行": 113, "成功": True, "結果": {"path": str(out / "結果.json"), "sha256": sha(out / "結果.json")},
                    "成立玉台帳": {"path": str(out / "成立玉の分類.jsonl"), "sha256": sha(out / "成立玉の分類.jsonl")},
                    "正本数値比較数": checks, "実玉台帳行数": len(records), "前後不変": True,
                    "市場再生": False, "Raw読取": 0, "11月09本文読取": 0,
                    "診断コード": {"path": str(Path(__file__).resolve()), "sha256": sha(Path(__file__))}}
    (out / "確認.json").write_text(encode(confirmation), encoding="utf-8")
    return confirmation


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="112保存値から113入口枝診断を作成する")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    print(encode(run(Path(args.output).resolve())))
