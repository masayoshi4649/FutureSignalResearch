"""Rawファイルを開かない、保有物理区間と費用後曲線の独立算術。"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from fractions import Fraction
import calendar
import copy
import math
import re
from typing import Iterable


@dataclass(frozen=True)
class Row:
    line: int
    clock: str | None
    at: float | None
    index: int | None
    last: float
    bid: float
    ask: float
    accepted: bool
    bbo_valid: bool
    rejected: str | None


def clock_value(value: object) -> float | None:
    """
    機能: RFC3339時刻を整数nsからGoと同じfloat64(ns)/1e9へ写す。
    引数: value(object)は原時計。返り値: float又はNone。microsecondへ切り落とさない。
    """
    if not isinstance(value, str):
        return None
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:[.,](\d+))?(Z|[+-]\d{2}:\d{2})", value)
    if not m:
        return None
    try:
        parts = [int(m.group(i)) for i in range(1, 7)]
        zone = m.group(8)
        if zone == "Z":
            offset = 0
        else:
            hour, minute = int(zone[1:3]), int(zone[4:6])
            if hour > 23 or minute > 59:
                return None
            offset = (hour * 3600 + minute * 60) * (1 if zone[0] == "+" else -1)
        stamp = datetime(*parts, tzinfo=timezone(timedelta(seconds=offset)))
        seconds = calendar.timegm(stamp.astimezone(timezone.utc).timetuple())
        fraction = int(((m.group(7) or "") + "000000000")[:9])
        return float(seconds * 1_000_000_000 + fraction) / 1_000_000_000
    except (ValueError, OverflowError):
        return None


def number(value: object) -> float:
    """
    機能: JSON数値又はnullのGo型付き数値相当を返す。
    引数: value(object)。返り値: float。型が異なる場合はValueError。
    """
    if value is None:
        return 0.0
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError("数値のJSON型が異なる")
    return float(value)


def best(raw: dict, key: str) -> float:
    """
    機能: 最良側の価格だけを取得する。
    引数: raw(dict)、key(str)はBuy1/Sell1。返り値: floatは価格、nullは0。
    """
    item = raw.get(key)
    if item is None:
        return 0.0
    if not isinstance(item, dict):
        raise ValueError("最良気配のJSON型が異なる")
    return number(item.get("Price"))


def classify_rows(raws: Iterable[dict], start: float, end: float, cutoff: float = 0) -> Iterable[Row]:
    """
    機能: 全先行行から採用NK連番を求め、同値・同秒を省略せず独立に分類する。
    引数: raws(Iterable[dict])、start/end/cutoff(float)は場境界と元入力の打切り。返り値: Iterable[Row]。
    """
    previous, index = start, 0
    for line, raw in enumerate(raws, 1):
        clock = raw.get("CurrentPriceTime")
        at = clock_value(clock)
        rejected = None
        last, bid, ask = 0.0, 0.0, 0.0
        if "CurrentPriceTime" not in raw:
            rejected = "clock_missing"
        elif at is None:
            rejected = "clock_invalid"
        elif at < start or at > end:
            rejected = "outside_session"
        elif at < previous:
            rejected = "backward_clock"
        else:
            last = number(raw.get("CurrentPrice"))
            if not math.isfinite(last):
                rejected = "last_non_finite"
            elif last <= 0:
                rejected = "last_non_positive"
            else:
                bid, ask = best(raw, "Buy1"), best(raw, "Sell1")
        source_accepted = rejected is None
        if source_accepted and cutoff > 0 and at >= cutoff:
            rejected = "cutoff_excluded"
        accepted = rejected is None
        bbo = accepted and math.isfinite(bid) and math.isfinite(ask) and bid > 0 and ask > bid
        yield Row(line, clock if isinstance(clock, str) else None, at, index if accepted else None, last, bid, ask, accepted, bbo, rejected)
        if source_accepted:
            previous = at
        if accepted:
            index += 1


def point(row: Row, value: float | Fraction, **extra: object) -> dict:
    """
    機能: 極値又は端値の小さな証拠を作る。
    引数: row(Row)、value(float/Fraction)、extra(dict)。返り値: dictは物理行と原時計を含む。
    """
    quote = {"clock": row.clock, "time": row.at, "index": row.index, "source_line": row.line,
             "last": row.last, "bid": row.bid, "ask": row.ask, "quote_ok": row.bbo_valid}
    return {"line": row.line, "clock": row.clock, "at": row.at, "index": row.index, "value": value, "quote": quote, **extra}


def update_ohlc(value: dict | None, p: dict) -> dict:
    """
    機能: 同値の初回と最後を別に保持するOHLCへ一観測だけ反映する。
    引数: value(dict又はNone)、p(dict)。返り値: dictは全行を転記しない集約。
    """
    if value is None:
        return {"count": 1, "open": dict(p), "close": dict(p), "high": p["value"], "low": p["value"],
                "high_first": dict(p), "high_last": dict(p), "low_first": dict(p), "low_last": dict(p)}
    value["count"] += 1
    value["close"] = dict(p)
    for name, better in (("high", p["value"] > value["high"]), ("low", p["value"] < value["low"])):
        if better:
            value[name] = p["value"]
            value[name + "_first"] = dict(p)
            value[name + "_last"] = dict(p)
        elif p["value"] == value[name]:
            value[name + "_last"] = dict(p)
    return value


def money(value: object) -> Fraction:
    """
    機能: 保存された有限の円額を十進字句から有理数へ写す。
    引数: value(object)はint/float/str/Fraction。返り値: Fractionは厳密金額。
    """
    if isinstance(value, Fraction):
        return value
    if isinstance(value, bool):
        raise ValueError("真偽値を金額へ変換")
    result = Fraction(str(value))
    return result


def bounded_rows(rows: Iterable[Row], last: int) -> Iterable[Row]:
    """
    機能: 終端物理行を渡した後、退出後の次行を要求せず走査を終える。
    引数: rows(Iterable[Row])、last(int)。返り値: Iterable[Row]は終端以下。
    """
    for row in rows:
        if row.line > last:
            raise ValueError("終端物理行の欠落")
        yield row
        if row.line == last:
            return


def update_marks(marks: dict, row: Row, side: int, entry: Fraction, cost: Fraction,
                 remaining: int, realized: Fraction, phase: str) -> None:
    """
    機能: Rawと実R/nから既存保存点の期待値を位相別に求める。
    引数: marks(dict)、row(Row)、side/remaining(int)、entry/cost/realized(Fraction)、phase(str)。
    返り値: None。予約数は入力がないため検査対象へ含めず、価格値を旧marksへ合わせない。
    """
    if remaining <= 0 or not row.bbo_valid:
        return
    mark = row.bid if side == 1 else row.ask
    gain = side * (money(mark) - entry)
    unit = 100 * gain - cost
    whole = realized + remaining * unit
    p = {"clock": row.clock, "quote": {"time": row.at, "index": row.index, "source_line": row.line,
         "last": row.last, "bid": row.bid, "ask": row.ask, "quote_ok": True}, "phase": phase,
         "quantity": remaining, "mark_price": mark, "gain_points": gain,
         "unit_net": unit, "realized_net": realized, "whole_net": whole}
    if "first" not in marks:
        marks["first"] = copy.deepcopy(p)
    marks["last"] = copy.deepcopy(p)
    for label, field, better in (("unit_max", "unit_net", "max"), ("unit_min", "unit_net", "min"),
                                 ("whole_max", "whole_net", "max"), ("whole_min", "whole_net", "min")):
        if label not in marks or (p[field] > marks[label][field] if better == "max" else p[field] < marks[label][field]):
            marks[label] = copy.deepcopy(p)
    for category, field in (("unit", "unit_net"), ("whole", "whole_net")):
        first = "first_" + category + "_positive"
        if first not in marks and p[field] > 0:
            marks[first] = copy.deepcopy(p)
        for suffix, condition in (("nonpositive", p[field] <= 0), ("negative", p[field] < 0)):
            label = "first_" + category + "_" + suffix + "_after"
            if first in marks and label not in marks and condition:
                marks[label] = copy.deepcopy(p)


def summarize_interval(rows: Iterable[Row], first: int, last: int, side: int, entry_price: object,
                       quantity: int, slip_points: object, closes: list[dict]) -> dict:
    """
    機能: entry〜指定返済物理行inclusiveのLast/BBO/実R,nによるW曲線だけを集約する。
    引数: rows(Iterable[Row])、first/last/side/quantity(int)、entry_price/slip_points(数値)、closes(list[dict])。
    返り値: dictはOHLC/初回最後極値/除外数/費用後W極値。退出後価格は使用しない。
    """
    if first < 1 or last < first or side not in (1, -1) or quantity < 1:
        raise ValueError("区間・売買又は実数量が不正")
    entry, slip = money(entry_price), money(slip_points)
    cost = Fraction(77) + 200 * slip
    pending = sorted(closes, key=lambda x: (x["line"], x.get("order", 0)))
    if any(c["line"] < first or c["line"] > last or c["quantity"] < 1 for c in pending):
        raise ValueError("返済片が実寿命の外")
    n, realized, cursor = quantity, Fraction(0), 0
    counts = {"physical": 0, "accepted": 0, "clock_missing": 0, "clock_invalid": 0, "outside_session": 0,
              "backward_clock": 0, "last_non_finite": 0, "last_non_positive": 0, "cutoff_excluded": 0,
              "accepted_bad_bbo": 0, "whole_unknown": 0}
    last_prices = bbo_prices = whole = None
    marks = {}
    previous_line = 0
    for row in bounded_rows(rows, last):
        if row.line <= previous_line:
            raise ValueError("物理行の後退又は重複")
        previous_line = row.line
        if row.line < first:
            continue
        counts["physical"] += 1
        if not row.accepted:
            counts[row.rejected] += 1
            if cursor < len(pending) and pending[cursor]["line"] == row.line:
                raise ValueError("除外原行に実返済を接合")
            continue
        counts["accepted"] += 1
        last_prices = update_ohlc(last_prices, point(row, row.last))
        if row.line > first:
            update_marks(marks, row, side, entry, cost, n, realized, "pre_fill")
        # ----------------------------------------
        # 同物理行の実返済だけをR,nへ反映する。予約や他Positionは損益相殺しない。
        while cursor < len(pending) and pending[cursor]["line"] == row.line:
            c = pending[cursor]
            if not row.bbo_valid:
                raise ValueError("異常BBO行に実返済を接合")
            mark = row.bid if side == 1 else row.ask
            if money(c["price"]) != money(mark) or c["quantity"] > n:
                raise ValueError("実返済側価格又は所有量の不一致")
            expected = c["quantity"] * (side * (money(mark) - entry) * 100 - cost)
            if expected != money(c["net_yen"]):
                raise ValueError("返済片の実数量・往復費用差")
            realized += expected
            n -= c["quantity"]
            cursor += 1
        update_marks(marks, row, side, entry, cost, n, realized, "after_source")
        if not row.bbo_valid:
            counts["accepted_bad_bbo"] += 1
            counts["whole_unknown"] += 1
            continue
        mark = row.bid if side == 1 else row.ask
        bbo_prices = update_ohlc(bbo_prices, point(row, mark))
        w = realized + n * (side * (money(mark) - entry) * 100 - cost)
        whole = update_ohlc(whole, point(row, w, remaining=n, realized_net_yen=realized))
    if counts["physical"] != last - first + 1 or cursor != len(pending):
        raise ValueError("区間の物理行又は実返済の欠落")
    return {"first_line": first, "last_line": last, "side": side, "entry_price": entry, "initial_quantity": quantity,
            "last": last_prices, "repayment_bbo": bbo_prices, "whole_net_yen": whole,
            "remaining": n, "realized_net_yen": realized, "counts": counts,
            "saved_marks_expected": marks, "saved_marks_reserved_checked": False}


def verify_quote(row: Row, quote: dict, side: int, price: object, action: str) -> None:
    """
    機能: 実fillの物理行・採用連番・時計・BBOと実側価格をRaw一行へ接合する。
    引数: row(Row)、quote(dict)、side(int)、price(数値)、action(str)はnew/close。
    返り値: None。不一致はValueError。滑りは価格へ足さず費用として扱う。
    """
    if not row.accepted or not row.bbo_valid or action not in ("new", "close") or side not in (1, -1):
        raise ValueError("実約定を正常な採用行へ接合できない")
    expected = {"source_line": row.line, "index": row.index, "time": row.at, "last": row.last, "bid": row.bid, "ask": row.ask, "quote_ok": True}
    supplied = dict(quote)
    raw_clock = supplied.pop("clock", None)
    if supplied != expected or raw_clock not in (None, "", row.clock):
        raise ValueError("実fillquoteとRawの全保存値差")
    mark = row.ask if (side == 1) == (action == "new") else row.bid
    if money(price) != money(mark):
        raise ValueError("実fill側の価格差")
