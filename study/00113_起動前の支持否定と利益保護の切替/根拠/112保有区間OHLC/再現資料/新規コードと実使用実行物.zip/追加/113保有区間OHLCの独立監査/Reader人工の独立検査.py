"""主Readerの手製買売出力と独立CLIの一回走査を照合する。自然Rawは開かない。"""
from pathlib import Path
import argparse
import copy
import hashlib
import importlib.util
import json
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
spec = importlib.util.spec_from_file_location("independent_scan_artificial", HERE / "独立走査を実行する.py")
M = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = M
spec.loader.exec_module(M)


def run() -> dict:
    """
    機能: 認証済みの人工gzipだけを買売各一回走査し、実玉位相の破壊も検査する。
    引数: なし。返り値: dictは小証跡。自然市場の成績ではない。
    """
    ref = {"path": str(ROOT / "work/113保有中OHLCの原板照合/人工_独立監査用/人工.json"), "sha256": "0c0d0ce4efbf0e248fb7b4d6a932bd6c938f6e5de68100bc998b588a1b9016f4"}
    before = {}
    manifest = M.load_ref(ref, before)
    assert manifest["人工"] is True and manifest["市場Raw"] is False
    results = []
    for name in ("買い", "売り"):
        scene, result = [M.load_ref(manifest["資料"][k], before) for k in (name+"入力", name)]
        results.append(M.scan_scene(scene, scene["price_intervals"], scene["state_slices"], [], [], result))
    # ----------------------------------------
    # 同じ人工全体経路をCLIのPositionAccumulatorでも確認する。
    art_spec = importlib.util.spec_from_file_location("independent_hand_tests", HERE / "区間監査の人工検査.py")
    art = importlib.util.module_from_spec(art_spec)
    sys.modules[art_spec.name] = art
    art_spec.loader.exec_module(art)
    rows = art.interval_rows()
    closes = [{"line": 2, "quantity": 1, "price": 1015, "net_yen": 923}, {"line": 4, "quantity": 1, "price": 995, "net_yen": -1077}]
    expected = M.A.summarize_interval(iter(rows), 1, 4, 1, 1005, 2, 0, closes)
    marks = M.R.scalar(expected["saved_marks_expected"])
    for value in marks.values():
        value.pop("clock")
        value["reserved"] = 0
    all_names = ["first", "last", "unit_max", "unit_min", "whole_max", "whole_min", "first_unit_positive", "first_whole_positive",
                 "first_unit_nonpositive_after", "first_unit_negative_after", "first_whole_nonpositive_after", "first_whole_negative_after"]
    marks = {k: marks.get(k) for k in all_names}
    quote = lambda row: {k:v for k,v in M.R.quote(row).items() if k != "clock"}
    p = {"side": 1, "entry_price": 1005, "q0": 2, "K": 77, "entry_quote": quote(rows[0]), "final_close_quote": quote(rows[-1]), "final_net_yen": -154, "marks": marks}
    als = [{"ordinal": 0, "exit_quote": quote(rows[1]), "exit_price": 1015, "quantity": 1, "net_yen": 923, "n_before": 2, "n_after": 1, "R_before": 0, "R_after": 923},
           {"ordinal": 1, "exit_quote": quote(rows[3]), "exit_price": 995, "quantity": 1, "net_yen": -1077, "n_before": 1, "n_after": 0, "R_before": 923, "R_after": -154}]
    acc = M.R.PositionAccumulator(p, als)
    for row in rows:
        acc.feed(row)
    checked = acc.finish()
    for field in ("phase", "quantity", "realized_net"):
        bad = copy.deepcopy(p)
        bad["marks"]["last"][field] = "after_source" if field == "phase" else bad["marks"]["last"][field] + 1
        try:
            acc.finish(bad)
        except ValueError:
            pass
        else:
            raise AssertionError("値が同じでもphase/n/Rを補正しない:"+field)
    assert all(M.digest(Path(k)) == v for k,v in before.items())
    return {"成功": True, "自然Raw読取": 0, "主Reader人工": ref, "人工gzip一走査": results, "CLI位相確認": checked,
            "phase_n_R破壊拒否": 3, "入力前後不変": True, "入力SHA256": before}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out")
    args = parser.parse_args()
    value = run()
    if args.out:
        with Path(args.out).open("x", encoding="utf-8", newline="\n") as f:
            f.write(json.dumps(value, ensure_ascii=False, indent=2)+"\n")
    print(json.dumps({"成功": True, "買売人工": 2, "phase_n_R破壊拒否": 3}, ensure_ascii=False))
