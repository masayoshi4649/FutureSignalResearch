"""保有区間の端点・採用規則・費用後曲線を手計算で検査する。Rawは開かない。"""
from pathlib import Path
from fractions import Fraction
import importlib.util
import sys
import unittest

場所 = Path(__file__).resolve().parent
仕様 = importlib.util.spec_from_file_location("interval_audit_independent", 場所 / "区間の独立算術.py")
A = importlib.util.module_from_spec(仕様)
sys.modules[仕様.name] = A
仕様.loader.exec_module(A)


def raw(clock: object, last: object, bid: object, ask: object, **extra: object) -> dict:
    """
    機能: 実ファイルを参照しない手製一原行を作る。
    引数: clock/last/bid/ask(object)、extra(dict)。返り値: dictは人工JSON相当。
    """
    return {"CurrentPriceTime": clock, "CurrentPrice": last, "Buy1": {"Price": bid}, "Sell1": {"Price": ask}, **extra}


def interval_rows() -> list:
    """
    機能: entry/partial/finalと同秒の原行を作る。
    引数: なし。返り値: list[Row]は全て同時計で異なる価格の人工。
    """
    clock = "2026-09-21T08:45:00.123456789+09:00"
    return list(A.classify_rows([raw(clock, 1000, 995, 1005), raw(clock, 1020, 1015, 1025),
                                 raw(clock, 1030, 1025, 1035), raw(clock, 1000, 995, 1005)], 0, 2e9))


class ArtificialTests(unittest.TestCase):
    """市場を使わない独立手計算と破壊反例。"""

    def test_clock_nanoseconds_and_accepted_previous(self) -> None:
        """
        機能: ns・時差・採用正Last行だけのprevious更新を検査する。
        引数: self(ArtificialTests)。返り値: None。
        """
        clock = "2026-09-21T08:45:00.123456789+09:00"
        self.assertEqual(A.clock_value(clock), A.clock_value("2026-09-20T23:45:00.123456789Z"))
        self.assertNotEqual(A.clock_value(clock), A.clock_value("2026-09-21T08:45:00.123456+09:00"))
        rows = list(A.classify_rows([
            raw(None, 99999, 1, 2), raw(clock, 1000, 995, 1005),
            raw("2026-09-21T08:45:02+09:00", 0, 995, 1005),
            raw("2026-09-21T08:45:01+09:00", 1001, 996, 1006),
            raw("2026-09-21T08:45:00+09:00", 99999, 1, 2),
            raw("2026-09-21T08:45:01+09:00", 1002, 1010, 1000),
            raw("2026-09-21T08:44:49+09:00", 99999, 1, 2),
        ], A.clock_value("2026-09-21T08:44:50+09:00"), A.clock_value("2026-09-21T15:45:00+09:00")))
        self.assertEqual([x.rejected for x in rows], ["clock_invalid", None, "last_non_positive", None, "backward_clock", None, "outside_session"])
        self.assertEqual([x.index for x in rows], [None, 0, None, 1, None, 2, None])
        self.assertFalse(rows[5].bbo_valid)
        self.assertTrue(rows[5].accepted)

    def test_inclusive_rows_ties_and_no_post_exit_request(self) -> None:
        """
        機能: 同秒別行・初回最後の同値極値・退出後未取得を検査する。
        引数: self(ArtificialTests)。返り値: None。
        """
        seen = []
        clock = "2026-09-21T08:45:00+09:00"

        def rows():
            """
            機能: 取得された行番号を記録する人工iterator。
            引数: なし。返り値: Iterable[Row]。
            """
            for x in A.classify_rows([raw(clock, v, v-5, v+5) for v in [99999, 1000, 1010, 1010, 990, 1010, 99999]], 0, 2e9):
                seen.append(x.line)
                yield x

        r = A.summarize_interval(rows(), 2, 6, 1, 1005, 1, 0, [])
        self.assertEqual(seen, [1, 2, 3, 4, 5, 6])
        self.assertEqual(r["last"]["high"], 1010)
        self.assertEqual((r["last"]["high_first"]["line"], r["last"]["high_last"]["line"]), (3, 6))
        self.assertEqual((r["last"]["open"]["line"], r["last"]["close"]["line"]), (2, 6))
        self.assertEqual(r["last"]["low_first"]["line"], 5)
        self.assertEqual(r["counts"]["physical"], 5)

    def test_last_and_bbo_validity_are_independent(self) -> None:
        """
        機能: 正Last異常BBOをLastだけへ含め累積HighPriceを使わない。
        引数: self(ArtificialTests)。返り値: None。
        """
        clock = "2026-09-21T08:45:00+09:00"
        rows = A.classify_rows([raw(clock, 1000, 995, 1005, HighPrice=999999), raw(clock, 1500, 1510, 1500), raw(clock, 1010, 1005, 1015)], 0, 2e9)
        r = A.summarize_interval(rows, 1, 3, 1, 1005, 1, 0, [])
        self.assertEqual(r["last"]["high"], 1500)
        self.assertEqual(r["repayment_bbo"]["high"], 1005)
        self.assertEqual(r["last"]["count"], 3)
        self.assertEqual(r["repayment_bbo"]["count"], 2)
        self.assertEqual(r["counts"]["accepted_bad_bbo"], 1)
        self.assertEqual(r["counts"]["whole_unknown"], 1)

    def test_entry_equals_exit_and_empty_unknown(self) -> None:
        """
        機能: 同一物理行の区間は一点とし、未知を0価格へ補完しない。
        引数: self(ArtificialTests)。返り値: None。
        """
        r = A.summarize_interval(iter(interval_rows()), 2, 2, 1, 1025, 1, 0, [])
        self.assertEqual(r["last"]["count"], 1)
        self.assertEqual(r["last"]["open"], r["last"]["close"])
        bad = list(A.classify_rows([raw(None, 99999, 995, 1005)], 0, 2e9))
        r = A.summarize_interval(iter(bad), 1, 1, 1, 1005, 1, 0, [])
        self.assertIsNone(r["last"])
        self.assertIsNone(r["whole_net_yen"])
        self.assertEqual(r["counts"]["clock_invalid"], 1)

    def test_partial_whole_and_allocation_lifetimes(self) -> None:
        """
        機能: 部分返済後のR/nと各返済片の異なる寿命を手計算照合する。
        引数: self(ArtificialTests)。返り値: None。
        """
        closes = [{"line": 2, "quantity": 1, "price": 1015, "net_yen": 923}, {"line": 4, "quantity": 1, "price": 995, "net_yen": -1077}]
        r = A.summarize_interval(iter(interval_rows()), 1, 4, 1, 1005, 2, 0, closes)
        self.assertEqual(r["whole_net_yen"]["open"]["value"], -2154)
        self.assertEqual(r["whole_net_yen"]["high"], 2846)
        self.assertEqual(r["whole_net_yen"]["high_first"]["line"], 3)
        self.assertEqual(r["realized_net_yen"], -154)
        self.assertEqual(r["whole_net_yen"]["close"]["value"], -154)
        self.assertEqual(r["remaining"], 0)
        first = A.summarize_interval(iter(interval_rows()), 1, 2, 1, 1005, 1, 0, closes[:1])
        second = A.summarize_interval(iter(interval_rows()), 1, 4, 1, 1005, 1, 0, closes[1:])
        self.assertEqual(first["last_line"], 2)
        self.assertEqual(second["last_line"], 4)
        self.assertEqual((first["realized_net_yen"], second["realized_net_yen"]), (923, -1077))
        self.assertEqual(first["whole_net_yen"]["high"], 923)
        self.assertEqual(second["whole_net_yen"]["high"], 1923)

    def test_saved_mark_phase_is_separate_from_raw_extrema(self) -> None:
        """
        機能: Raw極値を保存点へ寄せずpre/afterの実数量とRを別に照合する。
        引数: self(ArtificialTests)。返り値: None。
        """
        closes = [{"line": 2, "quantity": 1, "price": 1015, "net_yen": 923}, {"line": 4, "quantity": 1, "price": 995, "net_yen": -1077}]
        r = A.summarize_interval(iter(interval_rows()), 1, 4, 1, 1005, 2, 0, closes)
        m = r["saved_marks_expected"]
        self.assertEqual((m["first"]["phase"], m["first"]["quantity"], m["first"]["realized_net"]), ("after_source", 2, 0))
        self.assertEqual((m["first_whole_positive"]["quote"]["source_line"], m["first_whole_positive"]["phase"], m["first_whole_positive"]["quantity"], m["first_whole_positive"]["realized_net"]), (2, "pre_fill", 2, 0))
        self.assertEqual((m["last"]["phase"], m["last"]["quantity"], m["last"]["realized_net"], m["last"]["whole_net"]), ("pre_fill", 1, 923, -154))
        self.assertEqual((r["whole_net_yen"]["close"]["remaining"], r["whole_net_yen"]["close"]["realized_net_yen"]), (0, -154))
        self.assertEqual(m["first_whole_negative_after"]["quote"]["source_line"], 4)
        self.assertFalse(r["saved_marks_reserved_checked"])

    def test_hedge_and_fee_sensitivity_are_not_offset(self) -> None:
        """
        機能: 買売を別Positionとして扱い片道38.5円と滑りを両側へ課す。
        引数: self(ArtificialTests)。返り値: None。
        """
        sell = A.summarize_interval(iter(interval_rows()), 1, 4, -1, 995, 1, 5, [{"line": 4, "quantity": 1, "price": 1005, "net_yen": -2077}])
        self.assertEqual(sell["whole_net_yen"]["high"], -2077)
        self.assertEqual(sell["whole_net_yen"]["low"], -5077)
        self.assertEqual((sell["whole_net_yen"]["high_first"]["line"], sell["whole_net_yen"]["high_last"]["line"]), (1, 4))
        buy = A.summarize_interval(iter(interval_rows()), 1, 4, 1, 1005, 2, 5, [{"line": 2, "quantity": 1, "price": 1015, "net_yen": -77}, {"line": 4, "quantity": 1, "price": 995, "net_yen": -2077}])
        self.assertEqual(buy["whole_net_yen"]["high"], 846)
        self.assertEqual(buy["realized_net_yen"], -2154)
        self.assertEqual(A.money(38.5) * 2, Fraction(77))

    def test_fill_quote_join_and_mutations(self) -> None:
        """
        機能: 原行全quote・採用連番・実約定側価格の改変を拒否する。
        引数: self(ArtificialTests)。返り値: None。
        """
        row = interval_rows()[1]
        q = {"source_line": row.line, "index": row.index, "time": row.at, "last": row.last, "bid": row.bid, "ask": row.ask, "quote_ok": True}
        A.verify_quote(row, q, 1, 1025, "new")
        A.verify_quote(row, q, 1, 1015, "close")
        for key in ("source_line", "index", "time", "last", "bid", "ask", "quote_ok"):
            broken = dict(q)
            broken[key] = False if key == "quote_ok" else q[key] + 1
            with self.assertRaises(ValueError):
                A.verify_quote(row, broken, 1, 1025, "new")
        with self.assertRaises(ValueError):
            A.verify_quote(row, q, 1, 1020, "new")
        with self.assertRaises(ValueError):
            A.summarize_interval(iter(interval_rows()), 1, 4, 1, 1005, 2, 0, [{"line": 2, "quantity": 1, "price": 1015, "net_yen": 923.5}])
        with self.assertRaises(ValueError):
            A.summarize_interval(iter(interval_rows()), 1, 4, 1, 1005, 2, 0, [{"line": 2, "quantity": 1, "price": 1025, "net_yen": 923}])


if __name__ == "__main__":
    unittest.main(verbosity=2)
