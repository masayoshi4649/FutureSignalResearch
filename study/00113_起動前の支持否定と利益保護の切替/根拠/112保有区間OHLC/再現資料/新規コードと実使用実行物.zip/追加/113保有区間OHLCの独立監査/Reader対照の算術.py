"""主Readerをimportせず、その公開schemaへ独立算術の小結果を写す。"""
from pathlib import Path
from fractions import Fraction
import importlib.util
import sys

spec = importlib.util.spec_from_file_location("ohlc_audit_arithmetic", Path(__file__).with_name("区間の独立算術.py"))
A = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = A
spec.loader.exec_module(A)


def quote(row) -> dict:
    """
    機能: 独立分類行の原時計と8保存値を主Reader型へ写す。
    引数: row(A.Row)。返り値: dictは価格時計を含むquote。
    """
    return {"clock": row.clock, "time": row.at, "index": row.index, "source_line": row.line,
            "last": row.last, "bid": row.bid, "ask": row.ask, "quote_ok": row.bbo_valid}


def matches(row, expected: dict) -> bool:
    """
    機能: 元保存quoteに原時計文字列が無い場合だけ文字列比較を分離する。
    引数: row(A.Row)、expected(dict)。返り値: boolは全保存値一致。
    """
    actual, value = quote(row), dict(expected)
    clock = value.pop("clock", "")
    actual_clock = actual.pop("clock")
    return row.accepted and value == actual and (clock == "" or clock == actual_clock)


def scalar(value):
    """
    機能: 厳密金額をJSONで保存可能な数へ写す。
    引数: value(object)。返り値: objectはdict/listの内部も変換した値。
    """
    if isinstance(value, Fraction):
        return value.numerator if value.denominator == 1 else float(value)
    if isinstance(value, dict):
        return {k: scalar(v) for k, v in value.items()}
    if isinstance(value, list):
        return [scalar(v) for v in value]
    return value


def series(value: dict | None) -> dict:
    """
    機能: 独立OHLCを主Readerの小schemaへ写す。
    引数: value(dict又はNone)。返り値: dictはcount/open/high/low/close。
    """
    if value is None:
        return {"count": 0, "open": None, "high": None, "low": None, "close": None}
    return scalar({"count": value["count"],
        "open": {"value": value["open"]["value"], "quote": value["open"]["quote"]},
        "close": {"value": value["close"]["value"], "quote": value["close"]["quote"]},
        "high": {"value": value["high"], "first": value["high_first"]["quote"], "last": value["high_last"]["quote"]},
        "low": {"value": value["low"], "first": value["low_first"]["quote"], "last": value["low_last"]["quote"]}})


def add_returns(saved: dict, value: Fraction, row) -> None:
    """
    機能: 同じ状態片内の正益/非正/赤字の初回だけを独立に保存する。
    引数: saved(dict)、value(Fraction)、row(A.Row)。返り値: None。
    """
    p = scalar({"value": value, "quote": quote(row)})
    if value > 0 and saved["first_positive"] is None:
        saved["first_positive"] = p
    for category, condition in (("nonpositive", value <= 0), ("negative", value < 0)):
        if condition and saved["first_" + category] is None:
            saved["first_" + category] = p
        if condition and saved["first_positive"] is not None and saved["first_" + category + "_after_positive"] is None:
            saved["first_" + category + "_after_positive"] = p


def empty_returns() -> dict:
    """
    機能: 何も観測していない戻り証拠を作る。
    引数: なし。返り値: dictは全値None。
    """
    return {"first_positive": None, "first_nonpositive": None, "first_negative": None,
            "first_nonpositive_after_positive": None, "first_negative_after_positive": None}


class PriceAccumulator:
    """物理端点内のLastと両側BBOを小さな証拠だけへ集約する。"""

    def __init__(self, interval: dict):
        """
        機能: 両端inclusiveの価格区間を初期化する。
        引数: interval(dict)。返り値: None。
        """
        if interval["start_inclusive"] is not True or interval["end_inclusive"] is not True:
            raise ValueError("閉区間以外の定義")
        self.interval = interval
        self.first, self.last = interval["start_quote"]["source_line"], interval["end_quote"]["source_line"]
        if self.first < 1 or self.last < self.first:
            raise ValueError("価格区間の物理端点")
        self.raw = self.accepted = self.bad = 0
        self.excluded = {}
        self.start_matched = self.end_matched = False
        self.values = {"last": None, "bid": None, "ask": None}

    def feed(self, row) -> None:
        """
        機能: 一原行だけを反映し、全tickは保持しない。
        引数: row(A.Row)。返り値: None。
        """
        if not self.first <= row.line <= self.last:
            return
        self.raw += 1
        if row.line == self.first:
            self.start_matched = matches(row, self.interval["start_quote"])
        if row.line == self.last:
            self.end_matched = matches(row, self.interval["end_quote"])
        if not row.accepted:
            self.excluded[row.rejected] = self.excluded.get(row.rejected, 0) + 1
            return
        self.accepted += 1
        self.values["last"] = A.update_ohlc(self.values["last"], A.point(row, row.last))
        if not row.bbo_valid:
            self.bad += 1
            return
        for key in ("bid", "ask"):
            self.values[key] = A.update_ohlc(self.values[key], A.point(row, getattr(row, key)))

    def finish(self) -> dict:
        """
        機能: 端点接合と物理行数を検査して主Reader型を返す。
        引数: なし。返り値: dictは集約。
        """
        if self.raw != self.last - self.first + 1 or not self.start_matched or not self.end_matched:
            raise ValueError("価格区間の全端点又は物理行が不一致")
        return {"interval": self.interval, "start_matched": self.start_matched, "end_matched": self.end_matched,
                "raw_rows": self.raw, "accepted_rows": self.accepted, "excluded": self.excluded, "bad_bbo_rows": self.bad,
                **{k: series(v) for k, v in self.values.items()}}


class StateAccumulator:
    """一つの実R/n状態片と閾値の初回到達を有理数で検査する。"""

    def __init__(self, query: dict, interval: dict):
        """
        機能: 固定状態片と閾値を初期化する。
        引数: query/interval(dict)。返り値: None。
        """
        self.query = query
        self.first, self.last = interval["start_quote"]["source_line"], interval["end_quote"]["source_line"]
        if query["side"] not in (1, -1) or not 0 < query["n"] <= query["q0"] <= 10 or query["K"] not in (77, 1077):
            raise ValueError("状態片の実数量・符号・費用")
        self.whole = None
        self.bad = 0
        self.thresholds = [{"threshold": t, "first": None} for t in query["thresholds"]]
        self.whole_returns, self.unit_returns = empty_returns(), empty_returns()

    def feed(self, row) -> None:
        """
        機能: 正常な返済側BBOだけを評価し、未知値を補完しない。
        引数: row(A.Row)。返り値: None。
        """
        if not self.first <= row.line <= self.last or not row.accepted:
            return
        if not row.bbo_valid:
            self.bad += 1
            return
        q = self.query
        mark = row.bid if q["side"] == 1 else row.ask
        unit = q["side"] * (A.money(mark) - A.money(q["entry_price"])) * 100 - A.money(q["K"])
        w = A.money(q["R"]) + q["n"] * unit
        self.whole = A.update_ohlc(self.whole, A.point(row, w))
        for item in self.thresholds:
            threshold = item["threshold"]
            hit = w > A.money(threshold["whole_yen"]) if threshold["strict"] else w >= A.money(threshold["whole_yen"])
            if item["first"] is None and hit:
                item["first"] = scalar({"value": w, "quote": quote(row)})
        add_returns(self.whole_returns, w, row)
        add_returns(self.unit_returns, unit, row)

    def finish(self) -> dict:
        """
        機能: 全体損益極値と初回閾値/戻り証拠を返す。
        引数: なし。返り値: dictは主Readerと比較できる小結果。
        """
        return {"query": self.query, "bad_bbo_rows": self.bad, "whole_yen": series(self.whole),
                "thresholds": self.thresholds, "whole_returns": self.whole_returns, "unit_returns": self.unit_returns}


class PositionAccumulator:
    """実返済列から全体曲線と既存marksの位相を独立に再構成する。"""

    def __init__(self, position: dict, allocations: list[dict]):
        """
        機能: 一つの実新規の寿命・実返済列を初期化する。
        引数: position(dict)、allocations(list[dict])。返り値: None。
        """
        self.position = position
        self.first, self.last = position["entry_quote"]["source_line"], position["final_close_quote"]["source_line"]
        self.events = sorted(allocations, key=lambda x: x["ordinal"])
        if [a["ordinal"] for a in self.events] != list(range(len(self.events))):
            raise ValueError("返済片の順序欠落")
        self.n, self.realized, self.cursor = position["q0"], Fraction(0), 0
        self.whole, self.marks = None, {}
        self.joined = 0
        self.entry_joined = False

    def feed(self, row) -> None:
        """
        機能: pre評価→実close→after評価を処理して保存値を別に検査する。
        引数: row(A.Row)。返り値: None。予約数を推測しない。
        """
        if not self.first <= row.line <= self.last:
            return
        p = self.position
        if row.line == self.first:
            A.verify_quote(row, p["entry_quote"], p["side"], p["entry_price"], "new")
            self.entry_joined = True
        if row.accepted and row.line > self.first:
            A.update_marks(self.marks, row, p["side"], A.money(p["entry_price"]), A.money(p["K"]), self.n, self.realized, "pre_fill")
        while self.cursor < len(self.events) and self.events[self.cursor]["exit_quote"]["source_line"] == row.line:
            a = self.events[self.cursor]
            A.verify_quote(row, a["exit_quote"], p["side"], a["exit_price"], "close")
            expected = a["quantity"] * (100 * p["side"] * (A.money(a["exit_price"]) - A.money(p["entry_price"])) - A.money(p["K"]))
            if not 0 < a["quantity"] <= self.n or expected != A.money(a["net_yen"]):
                raise ValueError("実返済の量又は純額が不一致")
            if a["n_before"] != self.n or A.money(a["R_before"]) != self.realized:
                raise ValueError("返済前の実R/nが不一致")
            self.realized += expected
            self.n -= a["quantity"]
            if a["n_after"] != self.n or A.money(a["R_after"]) != self.realized:
                raise ValueError("返済後の実R/nが不一致")
            self.cursor += 1
            self.joined += 1
        if not row.accepted or not row.bbo_valid:
            return
        A.update_marks(self.marks, row, p["side"], A.money(p["entry_price"]), A.money(p["K"]), self.n, self.realized, "after_source")
        mark = row.bid if p["side"] == 1 else row.ask
        w = self.realized + self.n * (100 * p["side"] * (A.money(mark) - A.money(p["entry_price"])) - A.money(p["K"]))
        self.whole = A.update_ohlc(self.whole, A.point(row, w, remaining=self.n, realized_net_yen=self.realized))

    def finish(self, position: dict | None = None) -> dict:
        """
        機能: 終了実額と12種marksを量/R/phaseまで独立照合する。
        引数: position(dict又はNone)は同じ実金融経路の別保存玉。返り値: dictは照合範囲。reservedは明示未検査。
        """
        p = self.position if position is None else position
        if not self.entry_joined or self.n != 0 or self.cursor != len(self.events) or self.realized != A.money(p["final_net_yen"]):
            raise ValueError("全体寿命の初回又は終了会計が不一致")
        names = {"first", "last", "unit_max", "unit_min", "whole_max", "whole_min", "first_unit_positive", "first_whole_positive",
                 "first_unit_nonpositive_after", "first_unit_negative_after", "first_whole_nonpositive_after", "first_whole_negative_after"}
        if set(p["marks"]) != names:
            raise ValueError("保存marksの12項目の欠落又は追加")
        checked = 0
        fields = ("quantity", "mark_price", "gain_points", "unit_net", "realized_net", "whole_net")
        for name, actual in p["marks"].items():
            expected = self.marks.get(name)
            if (actual is None) != (expected is None):
                raise ValueError("保存marksの存在差:" + name)
            if actual is None:
                continue
            if actual["phase"] != expected["phase"] or actual["quote"] != expected["quote"]:
                raise ValueError("保存marksのquote/phase差:" + name)
            for field in fields:
                if A.money(actual[field]) != A.money(expected[field]):
                    raise ValueError("保存marksの量/R/評価値差:" + name + ":" + field)
            checked += 1
        return {"whole_yen": series(self.whole), "mark_points_checked": checked, "marks_phase_quantity_R_checked": True,
                "marks_reserved_checked": False, "entry_fill_quote_checked": True, "close_allocations_checked": self.joined,
                "raw_whole_close": scalar(self.whole["close"]), "saved_last": scalar(self.marks.get("last"))}
