# 112保有区間OHLCの独立二場監査

対象は事前選択された `2026-11-06_Day` と `2026-11-06_Night` の全24口座・全実玉/返済片・保存marks。結果を見て場を選び直さない。新条件・金融再生・退出後仮想利益・MFE回収は扱わない。

主Readerはimportせず、Python標準ライブラリのgzip/JSONと独立の原行分類・有理数算術を使う。同秒でも物理行inclusive。CurrentPriceTimeが価格時計であり実受信時刻は未証明。正常なLastと異常BBOを分ける。payloadのセッション累積HighPrice/LowPrice/Timeを使わない。時計previousは採用正Last行でだけ更新する。元Source ClockMissingと比較する場合は、新Readerのclock_missing+clock_invalidを合算する。

価格OHLCは全体寿命/各partial寿命、状態片Wは実R/n/K、実Positionの全体Wは全allocationから再構成する。高安の初回・最後、strict0/H50/H100到達、正益後戻りを主Readerへ照合する。全entry/closeの保存quoteと返済量/費用をRawへ接合し、marks12のquote/phase/n/R/u/Wを独立照合する。予約数はこの独立走査では検査しない。最終close行でRaw Wのpost n=0/R=finalと、保存marksのpre n>0/R=beforeが同値でも同じ状態へ補正しない。

一場につきgzipを一度だけ開く。価格JSON復元は最後の対象物理行までとし、残り圧縮byteだけを同一streamでSHAへ反映する。全Raw値を保存せず、極値・必要点・件数だけを保持する。主Readerの全70完了・queries・manifestとRootの別監査要求を認証するまで自然Rawを開かない。

CLI：`python 独立走査を実行する.py --request ABS --request-sha SHA`。`--metadata-only`では小metadataと台帳だけを確認しRawを開かない。出力先はRoot要求のoutput_dirで新規のみ。

Root要求schema：version=1、fixed=true、raw_read_authorized=true、policy=`112_holding_ohlc_independent_1106_v1`、sessions=`["2026-11-06_Day","2026-11-06_Night"]`、audit_stop=停止Ref、code_sha256=停止の所有map＋停止自身、main_condition=主固定OHLC要求Ref、reader_completion=主全70完了Ref、positions=建玉gzipJSONL Ref、allocations=返済片gzipJSONL Ref、output_dir=新規絶対先。Refはpath/sha256。

人工は8主、主Readerの認証済み手製買売gzipの価格6区間/金融4状態片、およびCLIのpartial/marks.phase/n/R破壊3種。自然市場は停止時点で未読。Rootの新監査要求後だけ二場を走査する。
