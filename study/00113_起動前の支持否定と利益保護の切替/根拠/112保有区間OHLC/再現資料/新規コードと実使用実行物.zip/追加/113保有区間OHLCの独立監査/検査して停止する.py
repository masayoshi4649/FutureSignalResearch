"""独立二場監査の人工とCLIを自然Raw前に固定する。"""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import os
import subprocess

HERE = Path(__file__).resolve().parent


def digest(p: Path) -> str:
    """
    機能: 所有コード又は人工metadataの指紋を計算する。
    引数: p(Path)。返り値: strはSHA256。自然Rawを渡さない。
    """
    return hashlib.sha256(p.read_bytes()).hexdigest()


def execute(command: list[str]) -> dict:
    """
    機能: 自然Rawを開かない人工だけを実行する。
    引数: command(list[str])。返り値: dictは成功ログ。不成功なら例外。
    """
    r = subprocess.run(command, cwd=HERE, env=dict(os.environ, PYTHONIOENCODING="utf-8"), capture_output=True, text=True, encoding="utf-8", timeout=60)
    row = {"command": command, "exit_code": r.returncode, "stdout": r.stdout, "stderr": r.stderr}
    if r.returncode:
        raise ValueError(json.dumps(row, ensure_ascii=False))
    return row


def main() -> None:
    """
    機能: 所有code・8人工・主Reader手製買売対照と実CLIを市場前停止する。
    引数: なし。返り値: None。実Raw・市場Nativeの追加読取はない。
    """
    if (HERE / "停止.json").exists() or (HERE / "検査").exists():
        raise ValueError("停止は新規先だけ")
    names = ["区間の独立算術.py", "Reader対照の算術.py", "独立走査を実行する.py", "区間監査の人工検査.py", "Reader人工の独立検査.py", "README.md", Path(__file__).name]
    owned = {str((HERE / name).resolve()): digest(HERE / name) for name in names}
    for name in names:
        if name.endswith(".py"):
            for node in ast.walk(ast.parse((HERE / name).read_text(encoding="utf-8"))):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    text = ast.get_docstring(node) or ""
                    if "\n" not in text or not all(x in text for x in ("機能", "引数", "返り値")):
                        raise ValueError("関数コメント不足:"+node.name)
    out = HERE / "検査"
    out.mkdir()
    logs = [execute(["python", "区間監査の人工検査.py"]), execute(["python", "Reader人工の独立検査.py", "--out", str(out / "主Reader人工対照.json")]), execute(["python", "独立走査を実行する.py", "--help"])]
    if "Ran 8 tests" not in logs[0]["stderr"] or "OK" not in logs[0]["stderr"]:
        raise ValueError("8主人工の完了不足")
    if any(digest(Path(p)) != sha for p,sha in owned.items()):
        raise ValueError("自己code前後差")
    stop = {"成功": True, "停止": True, "市場前": True, "module": "holding_ohlc_independent_audit113", "UTC": datetime.now(timezone.utc).isoformat(),
            "所有コードSHA256": owned, "前後不変": True, "人工主": 8, "主Reader買売人工": 2, "phase_n_R破壊": 3,
            "人工証拠": {"path": str(out / "主Reader人工対照.json"), "sha256": digest(out / "主Reader人工対照.json")},
            "実CLI": "python 独立走査を実行する.py --request ABS --request-sha SHA", "metadata_cli": "同CLI + --metadata-only",
            "自然Raw独立走査の許可範囲": ["2026-11-06_Day", "2026-11-06_Night"], "自然Raw走査済み": False,
            "market_native_replay": False, "marks_reserved_checked": False, "検査ログ": logs}
    (HERE / "停止.json").write_text(json.dumps(stop, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"成功": True, "停止": {"path": str(HERE / "停止.json"), "sha256": digest(HERE / "停止.json")}}, ensure_ascii=False))


if __name__ == "__main__":
    main()
