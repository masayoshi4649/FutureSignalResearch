"""Rootの別固定要求で許可した11/06二場だけを一回ずつ独立走査する。"""
from pathlib import Path
from datetime import datetime, timedelta
import argparse
import gzip
import hashlib
import importlib.util
import json
import os
import sys

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("ohlc_reader_audit", HERE / "Reader対照の算術.py")
R = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = R
spec.loader.exec_module(R)
A = R.A
SESSIONS = ["2026-11-06_Day", "2026-11-06_Night"]
POLICY = "112_holding_ohlc_independent_1106_v1"


def digest(path: Path) -> str:
    """
    機能: 小metadata又はコードのSHA256を計算する。
    引数: path(Path)。返り値: strは指紋。自然Rawはこの関数へ渡さない。
    """
    h = hashlib.sha256()
    with path.open("rb") as f:
        for data in iter(lambda: f.read(8*1024*1024), b""):
            h.update(data)
    return h.hexdigest()


def load_ref(ref: dict, before: dict) -> dict:
    """
    機能: Root明示の小JSONを認証して復元する。
    引数: ref/before(dict)。返り値: dictは認証済み値。
    """
    p = Path(ref["path"])
    if not p.is_absolute() or digest(p) != ref["sha256"]:
        raise ValueError("小metadata指紋差:"+str(p))
    before[str(p)] = ref["sha256"]
    return json.loads(p.read_text(encoding="utf-8-sig"))


def load_lines(ref: dict, sessions: set[str], before: dict) -> list[dict]:
    """
    機能: 台帳gzipJSONLを認証し対象二場の行だけを保持する。
    引数: ref(dict)、sessions(set[str])、before(dict)。返り値: list[dict]。
    """
    p = Path(ref["path"])
    if not p.is_absolute() or digest(p) != ref["sha256"]:
        raise ValueError("台帳指紋差")
    before[str(p)] = ref["sha256"]
    rows = []
    with gzip.open(p, "rt", encoding="utf-8") as f:
        for s in f:
            row = json.loads(s)
            if row["session"] in sessions:
                rows.append(row)
    return rows


class HashedReader:
    """圧縮ファイルの物理readを一回だけSHAへ反映する。"""

    def __init__(self, raw):
        """
        機能: 読取済みbyte数とSHAを初期化する。
        引数: raw(binary stream)。返り値: None。
        """
        self.raw, self.hash, self.size = raw, hashlib.sha256(), 0

    def read(self, size=-1):
        """
        機能: 圧縮byteを一度だけ取得しハッシュ化する。
        引数: size(int)。返り値: bytes。
        """
        data = self.raw.read(size)
        self.hash.update(data)
        self.size += len(data)
        return data


def scan_scene(scene: dict, price_defs: list[dict], query_defs: list[dict], positions: list[dict], allocations: list[dict], expected: dict) -> dict:
    """
    機能: 一つのgzipだけを開き価格/状態片/全実玉の小証拠を独立集約する。
    引数: scene/expected(dict)、price_defs/query_defs/positions/allocations(list[dict])。
    返り値: dictは除外0での対照件数と参照。価格全件や退出後の評価は保存しない。
    """
    prices = {p["price_interval_id"]: R.PriceAccumulator(p) for p in price_defs}
    queries = {q["query_id"]: R.StateAccumulator(q, prices[q["price_interval_id"]].interval) for q in query_defs}
    children = {}
    for a in allocations:
        children.setdefault(a["position_record_id"], []).append(a)
    groups = {}
    for p in positions:
        parts = sorted(children.get(p["position_record_id"], []), key=lambda a: a["ordinal"])
        key = (p["price_interval_id"], p["side"], p["entry_price"], p["q0"], p["K"],
               tuple((a["exit_quote"]["source_line"], a["quantity"], a["exit_price"], a["net_yen"]) for a in parts))
        if key not in groups:
            groups[key] = {"acc": R.PositionAccumulator(p, parts), "positions": []}
        groups[key]["positions"].append(p)
    tasks = list(prices.values()) + list(queries.values()) + [g["acc"] for g in groups.values()]
    if not tasks:
        raise ValueError("選択場の区間が空")
    last = max(t.last for t in tasks)
    starts = sorted(tasks, key=lambda t: t.first)
    cursor, active, decoded = 0, [], 0
    raw_path = Path(scene["raw"]["path"])
    initial = raw_path.stat()
    if scene.get("raw_bytes") and initial.st_size != scene["raw_bytes"]:
        raise ValueError("Rawサイズ差")
    with raw_path.open("rb") as f:
        hashed = HashedReader(f)
        z = gzip.GzipFile(fileobj=hashed, mode="rb")

        def raw_rows():
            """
            機能: gzipの原行を順番に一度だけJSON復元する。
            引数: なし。返り値: Iterable[dict]。累積HighPrice等は使用しない。
            """
            for line in z:
                value = json.loads(line)
                if not isinstance(value, dict):
                    raise ValueError("原行がobjectでない")
                yield value

        for row in A.bounded_rows(A.classify_rows(raw_rows(), scene["start"], scene["end"], scene.get("cutoff", 0)), last):
            decoded = row.line
            while cursor < len(starts) and starts[cursor].first <= row.line:
                active.append(starts[cursor])
                cursor += 1
            active = [t for t in active if t.last >= row.line]
            for task in active:
                task.feed(row)
            if decoded % 100000 == 0:
                print(json.dumps({"session": scene["session"], "decoded_lines": decoded}, ensure_ascii=False), flush=True)
        z.close()
        # ----------------------------------------
        # 終端以後の価格を復元せず、残り圧縮byteだけで全入力SHAを完了する。
        while hashed.read(8*1024*1024):
            pass
        actual_sha, compressed = hashed.hash.hexdigest(), hashed.size
    after = raw_path.stat()
    if actual_sha != scene["raw"]["sha256"] or (initial.st_size, initial.st_mtime_ns) != (after.st_size, after.st_mtime_ns):
        raise ValueError("RawのSHA又は前後属性差")
    checked_prices = checked_queries = marks = fills = 0
    for key, acc in prices.items():
        value = acc.finish()
        if value != expected["price_intervals"][key]:
            raise ValueError("独立価格OHLC/初回最後/原行差:"+key)
        checked_prices += 1
    for key, acc in queries.items():
        if acc.finish() != expected["state_queries"][key]:
            raise ValueError("独立W/閾値/戻り原行差:"+key)
        checked_queries += 1
    for group in groups.values():
        for p in group["positions"]:
            value = group["acc"].finish(p)
            marks += value["mark_points_checked"]
            fills += value["close_allocations_checked"] + 1
    return {"session": scene["session"], "success": True, "raw": scene["raw"], "actual_sha256": actual_sha,
            "compressed_bytes": compressed, "decoded_passes": 1, "decoded_lines": decoded, "last_requested_line": last,
            "price_intervals_checked": checked_prices, "state_queries_checked": checked_queries,
            "positions_checked": len(positions), "financial_paths_checked": len(groups), "fill_allocations_and_entry_quotes_checked": fills,
            "saved_mark_points_checked": marks, "marks_phase_quantity_R_checked": True, "marks_reserved_checked": False,
            "stat_before": {"bytes": initial.st_size, "mtime_ns": initial.st_mtime_ns},
            "stat_after": {"bytes": after.st_size, "mtime_ns": after.st_mtime_ns}, "raw_rows_copied": False,
            "post_exit_price_evaluated": False, "clock_basis": "CurrentPriceTime。実受信時刻は未証明、同秒は物理行"}


def prepare(ref: dict) -> dict:
    """
    機能: Root新要求・全体Reader成功・自分の停止と二場だけをRaw本文前に認証する。
    引数: ref(dict)。返り値: dictは小metadataと対象台帳だけの計画。
    """
    before = {}
    req = load_ref(ref, before)
    if req.get("version") != 1 or req.get("fixed") is not True or req.get("raw_read_authorized") is not True or req.get("policy") != POLICY or req.get("sessions") != SESSIONS:
        raise ValueError("Rootの11/06二場の別固定許可が必要")
    stop = load_ref(req["audit_stop"], before)
    if stop.get("成功") is not True or stop.get("停止") is not True or stop.get("module") != "holding_ohlc_independent_audit113":
        raise ValueError("独立監査の停止不足")
    codes = dict(stop["所有コードSHA256"])
    codes[req["audit_stop"]["path"]] = req["audit_stop"]["sha256"]
    if req["code_sha256"] != codes:
        raise ValueError("独立監査code固定差")
    for path, sha in codes.items():
        if digest(Path(path)) != sha:
            raise ValueError("独立監査code現物差")
        before[path] = sha
    main = load_ref(req["main_condition"], before)
    complete = load_ref(req["reader_completion"], before)
    if main.get("fixed") is not True or main.get("raw_read_authorized") is not True or main.get("source_trial") != 112 or main.get("policy") != "holding_interval_ohlc112_v1":
        raise ValueError("主OHLCの条件差")
    if complete.get("success") is not True or complete.get("sessions") != 70 or complete.get("source_trial") != 112 or complete.get("condition") != req["main_condition"] or complete.get("queries") != main["queries"] or complete.get("unchanged") is not True or complete.get("financial_replay") is not False:
        raise ValueError("主OHLC全70の成功/前後/非再生差")
    manifest, ledger = load_ref(main["manifest"], before), load_ref(main["queries"], before)
    positions = load_lines(req["positions"], set(SESSIONS), before)
    allocations = load_lines(req["allocations"], set(SESSIONS), before)
    cases = {s["id"]: s for s in manifest["sessions"]}
    result_refs = {s["session"]: s["result"] for s in complete["results"]}
    scenes = []
    for sid in SESSIONS:
        case = cases[sid]
        day, kind = sid.split("_")
        start = A.clock_value(day + ("T08:45:00+09:00" if kind == "Day" else "T17:00:00+09:00"))
        next_day = (datetime.strptime(day, "%Y-%m-%d") + timedelta(days=1)).strftime("%Y-%m-%d")
        end = A.clock_value(day+"T15:45:00+09:00") if kind == "Day" else A.clock_value(next_day+"T06:00:00+09:00")
        raw = case["files"]["NK225_book"]
        path = Path(raw["path"])
        if not path.is_absolute():
            path = Path(manifest["source_root"]) / path
        result = load_ref(result_refs[sid], before)
        rawref = {"path": str(path.resolve()), "sha256": raw["sha256"]}
        if result.get("success") is not True or result["raw"] != rawref or result["actual_sha256"] != rawref["sha256"]:
            raise ValueError("主OHLCの当場Raw参照差")
        prices = [p for p in ledger["price_intervals"] if p["session"] == sid]
        ids = {p["price_interval_id"] for p in prices}
        queries = [q for q in ledger["state_slices"] if q["price_interval_id"] in ids]
        ps, als = [p for p in positions if p["session"] == sid], [a for a in allocations if a["session"] == sid]
        if not ps or not als or set(ids) != set(result["price_intervals"]) or {q["query_id"] for q in queries} != set(result["state_queries"]):
            raise ValueError("二場の全区間/実玉/状態片の欠落")
        scenes.append({"scene": {"session": sid, "contract": case["contract"], "start": start, "end": end,
                       "cutoff": case.get("cutoff", 0), "raw": rawref, "raw_bytes": raw["size"]},
                       "prices": prices, "queries": queries, "positions": ps, "allocations": als, "expected": result})
    return {"request": req, "before": before, "scenes": scenes}


def main() -> None:
    """
    機能: 明示Root要求だけから独立二場を新規先へ保存する。
    引数: CLI request/request-sha(str)、metadata-only(bool)。返り値: None。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request", required=True)
    parser.add_argument("--request-sha", required=True)
    parser.add_argument("--metadata-only", action="store_true")
    args = parser.parse_args()
    plan = prepare({"path": str(Path(args.request).resolve()), "sha256": args.request_sha})
    if args.metadata_only:
        print(json.dumps({"success": True, "raw_opened": False, "sessions": SESSIONS}, ensure_ascii=False))
        return
    out = Path(plan["request"]["output_dir"]).resolve()
    out.mkdir(parents=False, exist_ok=False)
    results = []
    try:
        for s in plan["scenes"]:
            results.append(scan_scene(s["scene"], s["prices"], s["queries"], s["positions"], s["allocations"], s["expected"]))
        if any(digest(Path(p)) != sha for p, sha in plan["before"].items()):
            raise ValueError("固定code/小metadataの前後差")
        result = {"success": True, "source_trial": 112, "kind": "OHLC独立二場監査", "sessions": results,
                  "request": {"path": str(Path(args.request).resolve()), "sha256": args.request_sha},
                  "before": plan["before"], "after": plan["before"], "unchanged": True, "financial_replay": False,
                  "post_exit_virtual_profit": False, "native_fields_ignored": ["marks.reserved（注文取消の物理行が未保存のため別監査）"]}
        (out / "結果.json").write_text(json.dumps(result, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        print(json.dumps({"success": True, "result": {"path": str(out / "結果.json"), "sha256": digest(out / "結果.json")}}, ensure_ascii=False))
    except Exception as e:
        (out / "不完了.json").write_text(json.dumps({"success": False, "error": str(e)}, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        raise


if __name__ == "__main__":
    main()
