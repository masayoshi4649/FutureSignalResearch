/**
 * 独立照合を終えた保有区間の集計を、三つのCSVへ保存する。
 * @param {string[]} process.argv - 集計JSON、期待SHA256、新規出力先。
 * @returns {Promise<void>} 全セルを表へ往復して確認し、CSVと出力指紋を保存する。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {gunzipSync} from 'node:zlib';
import {Workbook} from '@oai/artifact-tool';

/**
 * バイト列の指紋を得る。
 * @param {Uint8Array|string} value - 入力。
 * @returns {string} SHA256。
 */
function sha(value) {return crypto.createHash('sha256').update(value).digest('hex');}

/**
 * CSVの一セルを引用する。
 * @param {string|number|boolean|null} value - セル。nullは空欄とする。
 * @returns {string} RFC4180のフィールド。
 */
function field(value) {
  const text = value == null ? '' : String(value);
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

// ----------------------------------------
// 数値を再最適化せず、認証した台帳・原板照合結果を表へ格納する。

const [inputArg, expectedSHA, outputArg] = process.argv.slice(2);
assert.ok(inputArg && /^[0-9a-f]{64}$/.test(expectedSHA) && outputArg, '入力・SHA・新規出力先が必要');
const input = path.resolve(inputArg), output = path.resolve(outputArg);
const bytes = await fs.readFile(input);
assert.equal(sha(bytes), expectedSHA, '統合結果指紋');
const data = JSON.parse((input.endsWith('.gz') ? gunzipSync(bytes) : bytes).toString('utf8').replace(/^\uFEFF/, ''));
assert.equal(data['成功'], true, '統合成功');
const tables = [
  ['建玉全体', '建玉全体OHLC.csv', 13332],
  ['返済片', '返済片OHLC.csv', 14908],
  ['候補別集計', '候補別損失診断.csv', 24],
];
await fs.mkdir(output, {recursive: false});
const results = {};
for (const [key, filename, count] of tables) {
  global.gc?.();
  const rows = data[key];
  assert.ok(Array.isArray(rows), key);
  assert.equal(rows.length, count, `${key}/全件`);
  const header = Object.keys(rows[0]);
  assert.ok(header.length > 1);
  const values = rows.map((row, i) => {
    assert.deepEqual(Object.keys(row), header, `${key}/${i}/列順`);
    return header.map(name => {
      const v = row[name];
      assert.ok(v === null || ['string', 'number', 'boolean'].includes(typeof v), `${key}/${i}/${name}/平坦な型`);
      if (typeof v === 'number') assert.ok(Number.isFinite(v));
      return v;
    });
  });
  const workbook = Workbook.create();
  const sheet = workbook.worksheets.add(key);
  for (let c = 0; c < header.length; c++) {
    if (header[c].endsWith('時刻')) sheet.getRangeByIndexes(1, c, count, 1).setNumberFormat('@');
  }
  sheet.getRangeByIndexes(0, 0, 1, header.length).values = [header];
  for (let i = 0; i < values.length; i += 500) {
    sheet.getRangeByIndexes(i + 1, 0, Math.min(500, values.length - i), header.length).values = values.slice(i, i + 500);
  }
  workbook.recalculate();
  const body = ['\uFEFF' + header.map(field).join(',')];
  let checked = 0;
  for (let i = 0; i < values.length; i += 500) {
    const actual = sheet.getRangeByIndexes(i + 1, 0, Math.min(500, values.length - i), header.length).values;
    for (let j = 0; j < actual.length; j++) {
      for (let c = 0; c < header.length; c++) {
        assert.deepEqual(actual[j][c] ?? null, values[i + j][c], `${key}/${i+j}/${header[c]}/表往復`);
        checked++;
      }
      body.push(actual[j].map(field).join(','));
    }
  }
  const text = body.join('\r\n') + '\r\n';
  await fs.writeFile(path.join(output, filename), text, {encoding: 'utf8', flag: 'wx'});
  results[filename] = {sha256: sha(text), データ行数: count, 列数: header.length, セル確認数: checked};
}
assert.equal(sha(await fs.readFile(input)), expectedSHA, '統合結果前後不変');
await fs.writeFile(path.join(output, 'CSVの確認.json'), JSON.stringify({成功: true, 対象試行: 112, 入力: {path:input,sha256:expectedSHA}, 出力:results, 金融再実行:false, 退出後評価:false, 原板再走査:false, 入力前後不変:true}, null, 2), {flag:'wx'});
console.log(JSON.stringify({成功:true,出力先:output,出力:results}));
