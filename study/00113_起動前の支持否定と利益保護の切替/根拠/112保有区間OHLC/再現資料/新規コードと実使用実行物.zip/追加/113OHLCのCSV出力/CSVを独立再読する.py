"""CSV三点を別処理系で再読し、全セル・全型を統合結果へ照合する。"""
import csv
import gzip
import hashlib
import json
import sys
from decimal import Decimal
from pathlib import Path


def digest(path: Path) -> str:
    """指紋を求める。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """統合結果とCSVを全件照合する。

    引数: sys.argv(list[str])は集計JSON・期待SHA・CSVフォルダ。
    返り値: None。失敗は例外にする。
    """
    source, expected, out = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
    assert digest(source) == expected
    source_bytes = gzip.decompress(source.read_bytes()) if source.suffix == '.gz' else source.read_bytes()
    data = json.loads(source_bytes.decode('utf-8-sig'), parse_float=Decimal)
    result = {'成功': True, '対象試行': 112, '入力SHA256': expected, '出力': {}}
    tables = [('建玉全体', '建玉全体OHLC.csv', 13332), ('返済片', '返済片OHLC.csv', 14908), ('候補別集計', '候補別損失診断.csv', 24)]
    for key, name, count in tables:
        source_rows = data[key]
        header = list(source_rows[0])
        cells = 0
        with (out / name).open(encoding='utf-8-sig', newline='') as handle:
            reader = csv.reader(handle)
            assert next(reader) == header
            for i, actual in enumerate(reader):
                assert i < len(source_rows) and len(actual) == len(header)
                for column, text in zip(header, actual):
                    original = source_rows[i][column]
                    if original is None:
                        assert text == '', (key, i, column)
                    elif isinstance(original, bool):
                        assert text == str(original).lower(), (key, i, column)
                    elif isinstance(original, (int, Decimal)):
                        assert Decimal(text) == Decimal(original), (key, i, column)
                    else:
                        assert text == original, (key, i, column)
                    cells += 1
            assert i + 1 == count == len(source_rows)
        result['出力'][name] = {'sha256': digest(out / name), '行数': count, '列数': len(header), '全セル照合数': cells}
    assert digest(source) == expected
    result['入力前後不変'] = True
    (out / 'CSVの独立再読.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
