"""112正式Nativeの実建玉・返済片を、Raw未読で保有区間と曲線queryへ分解する。"""

import argparse
import gzip
import hashlib
import importlib.util
import json
from decimal import Decimal
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
DIAG = ROOT / 'work/113入口枝と保護起動前損失の診断/診断する.py'
DIAG_SHA = '6251a1c826cc0e03980a5684d3bf2ac22a973c311db1eb0abb181e1fb01984c7'
if hashlib.sha256(DIAG.read_bytes()).hexdigest() != DIAG_SHA:
    raise ValueError('固定入口結合codeのSHA差')
SPEC = importlib.util.spec_from_file_location('区間113が再用する固定入口診断', DIAG)
D = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(D)
QFIELDS = ('time', 'index', 'source_line', 'last', 'bid', 'ask', 'quote_ok')


def serial(value):
    """十進数をJSON数値へ変換する。

    引数: value(Decimal)は半円又は保存時計。
    返り値: int又はfloatは保存用の数値。
    """
    if isinstance(value, Decimal):
        return int(value) if value == value.to_integral_value() else float(value)
    raise TypeError(type(value).__name__)


def canonical(value):
    """同じ意味のqueryを同じ指紋へ写す。

    引数: value(dict)はキー順に依存しないJSON値。
    返り値: bytesはUTF-8の正規化JSON。
    """
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), default=serial, allow_nan=False).encode('utf-8')


def quote(value):
    """実原行の必要fieldを厳密に残す。

    引数: value(dict)はNative QuoteStamp。
    返り値: dictはtime/index/物理行/Last/Bid/Ask/正常flag。
    """
    D.need(set(value) == set(QFIELDS), 'QuoteStampの明示schema')
    return {k: value[k] for k in QFIELDS}


def register(store, prefix, value):
    """同一内容を指紋IDで一度だけ登録する。

    引数: store(dict)は登録先、prefix(str)は種別、value(dict)は内容。
    返り値: strは完全SHAを含むID。衝突又は意味の差は拒否する。
    """
    identity = prefix + hashlib.sha256(canonical(value)).hexdigest()
    D.need(identity not in store or store[identity] == value, 'queryの指紋衝突')
    store[identity] = value
    return identity


def price_interval(intervals, sid, start, end):
    """原行inclusiveの価格寿命を重複排除して登録する。

    引数: intervals(dict)は共有索引、sid(str)は場、start/end(dict)は実原行。
    返り値: strは価格区間ID。退出後の原行を追加しない。
    """
    start, end = quote(start), quote(end)
    D.need(start['time'] <= end['time'] and start['index'] <= end['index'] and start['source_line'] <= end['source_line'], '区間境界の非後退')
    return register(intervals, 'price_', {'session': sid, 'start_quote': start, 'end_quote': end,
                                         'start_inclusive': True, 'end_inclusive': True})


def state_slice(queries, price_id, side, entry, n, R, K, q0):
    """実残量と既返済額が一定の費用後曲線を登録する。

    引数: queries(dict)、price_id(str)、side(int)、entry/n/R/K/q0(数値)は固定金融入力。
    返り値: strはquery ID。n=0や仮想的な初期枚数維持は許さない。
    """
    D.need(side in (-1, 1) and 0 < n <= q0 <= 10 and K in (77, 1077), '曲線の符号/実残量/費用')
    return register(queries, 'state_', {'price_interval_id': price_id, 'side': side, 'entry_price': entry,
                                       'n': n, 'R': R, 'K': K, 'q0': q0,
                                       'thresholds': [{'id': 'positive', 'whole_yen': 0, 'strict': True},
                                                      {'id': 'H50', 'whole_yen': q0*5000, 'strict': False},
                                                      {'id': 'H100', 'whole_yen': q0*10000, 'strict': False}]})


def amount(value):
    """保存金額を厳密な十進数へ変換する。

    引数: value(int又はDecimal)は価格又は金額。
    返り値: Decimalは独立算術で使う値。
    """
    return Decimal(str(value))


def make_position(sid, key, p, book, tags, intervals, queries):
    """一つの実建玉を全体寿命・各返済片寿命・実残量曲線に分解する。

    引数: sid/key(str)、p/book/tags(dict)、intervals/queries(dict)は認証済み実台帳と共有索引。
    返り値: tuple[dict,list[dict],dict]は建玉行、返済片行、既存独立正本との加算指標。
    """
    joined, stat = D.classify(p, book, tags, sid)
    entry = p['entry_quote']
    q0, side, K = p['initial_quantity'], p['side'], 77+200*book['config']['slip_pts']
    position_id = register({}, 'position_', {'session': sid, 'key': key, 'position_id': p['id']})
    whole_id = price_interval(intervals, sid, entry, p['closed_quote'])
    parts = [(f, a, i) for f in book['fills'] if f['action'] == 'close' for i,a in enumerate(f['allocations']) if a['position_id'] == p['id']]
    orders = {o['id']: o for o in book['orders']}
    n, R, start = q0, Decimal(0), entry
    children, slice_ids = [], []
    for ordinal, (fill, a, allocation_index) in enumerate(parts):
        exit = fill['quote']
        D.need(fill['price'] == exit['bid' if side == 1 else 'ask'] and exit['quote_ok'] and exit['ask'] > exit['bid'] > 0, '実返済は正常な返済側BBO')
        qty = a['quantity']
        unit = 100*side*(amount(fill['price'])-amount(p['entry_price']))-K
        net = amount(a['net_yen'])
        D.need(net == qty*unit and 0 < qty <= n, '返済片純額と実減少枚数')
        pre = R+n*unit
        after_R, after_n = R+net, n-qty
        post = after_R+after_n*unit
        D.need(pre == post, '返済原行の前後Wは実配賦費用込みで同体')
        price_id = price_interval(intervals, sid, start, exit)
        query_id = state_slice(queries, price_id, side, p['entry_price'], n, R, K, q0)
        slice_ids.append(query_id)
        life = price_interval(intervals, sid, entry, exit)
        allocation_id = register({}, 'allocation_', {'position_record_id': position_id, 'fill_id': fill['id'], 'allocation_index': allocation_index})
        # 返済片の枚数は実際に当返済まで保有された量であり、返済後へ延長しない。
        allocation_query = state_slice(queries, life, side, p['entry_price'], qty, 0, K, qty)
        order = orders[fill['order_id']]
        children.append({'allocation_id': allocation_id, 'kind': 'allocation', 'position_record_id': position_id,
                         'session': sid, 'key': key, 'position_id': p['id'], 'method': joined['method'],
                         'side': side, 'quantity': qty, 'ordinal': ordinal, 'fill_id': fill['id'], 'order_id': order['id'],
                         'entry_quote': quote(entry), 'exit_quote': quote(exit), 'entry_price': p['entry_price'], 'exit_price': fill['price'],
                         'price_interval_id': life, 'state_query_id': allocation_query,
                         'gross_yen': a['gross_yen'], 'entry_fee_yen': a['entry_fee_yen'], 'exit_fee_yen': a['exit_fee_yen'],
                         'entry_slip_yen': a['entry_slip_yen'], 'exit_slip_yen': a['exit_slip_yen'], 'net_yen': net,
                         'n_before': n, 'n_after': after_n, 'R_before': R, 'R_after': after_R,
                         'W_before_close': pre, 'W_after_close': post, 'position_slice_query_id': query_id,
                         'request_time': order['request_time'], 'request_quote': quote(order['request_quote']),
                         'request_to_fill_seconds': exit['time']-order['request_time'],
                         'request_to_fill_index': exit['index']-order['request_quote']['index'],
                         'request_to_fill_lines': exit['source_line']-order['request_quote']['source_line'],
                         'reason': fill['reason'], 'native_close_signal_id': fill['native_close_signal_id'],
                         'native_close_notice_id': fill['native_close_notice_id'], 'protection_point': order['protection_point']})
        n, R, start = after_n, after_R, exit
    D.need(n == 0 and R == p['realized_net'] and sum(c['quantity'] for c in children) == q0, '返済片加法の全残0と純額')
    actual_orders = [{k:o[k] for k in ['id','kind','side','quantity','request_time','request_quote','reason','status','fill_id',
                                      'native_close_signal_id','native_close_notice_id','cancel_time','cancel_reason','protection_point']}
                     for o in book['orders'] if o['position_id'] == p['id']]
    source_exits = [{k:e[k] for k in ['at','phase','method','signal_id','hold_id','notice_id','quote','quantity','before',
                                    'actual_free_before','actual_exit_requested','actual_free_after','order_id','reason']}
                    for e in book['source_events'] if e['kind'] == 'close_notice' and e['method'] == p['source']['method'] and e['hold_id'] == p['source_hold_id']]
    row = {'position_record_id': position_id, 'kind': 'position', 'session': sid, 'key': key, 'position_id': p['id'],
           'policy': book['config']['policy'], 'slip_pts': book['config']['slip_pts'], 'delay_seconds': book['config']['delay_seconds'],
           'method': joined['method'], 'owner': joined['owner'], 'source_kind': joined['kind'], 'parent': joined['parent'],
           'campaign': joined['campaign'], 'source': p['source'], 'source_hold_id': p['source_hold_id'], 'source_signal_id': joined['signal_id'],
           'side': side, 'q0': q0, 'K': K, 'entry_order_id': p['entry_order_id'], 'entry_price': p['entry_price'],
           'entry_quote': quote(entry), 'final_close_quote': quote(p['closed_quote']), 'gross_yen': p['gross_yen'], 'final_net_yen': R,
           'price_interval_id': whole_id, 'allocation_ids': [c['allocation_id'] for c in children], 'state_query_ids': slice_ids,
           'marks': p['marks'], 'protection_active': p['protection_active'], 'activation': p['activation'],
           'floor_updated': p['floor_updated'], 'first_floor_hit': p['first_floor_hit'], 'floor_gain': p['floor_gain'],
           'orders': actual_orders, 'source_exit_notices': source_exits,
           'SourceHold': {k: tags[(sid,'NK225mini',p['source']['method'],p['source']['signal_id'])]['holds'][p['source_hold_id']][k]
                          for k in ['hold_id','entry_id','initial_quantity','quantity','closed_quantity','entry_price','entry_quote','kind','parent','source_id']}}
    return row, children, stat


# ----------------------------------------


def write_lines(path, rows):
    """少数の保存台帳を圧縮JSONLへ新規保存する。

    引数: path(Path)は未作成先、rows(list[dict])は台帳行。
    返り値: None。Raw原文や全tickは保存しない。
    """
    with path.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as stream:
            for row in rows:
                stream.write(canonical(row)+b'\n')


def run(out):
    """112全24の成立玉を、Raw未読のままReader要求素材へ変換する。

    引数: out(Path)は未作成の出力先。
    返り値: dictは台帳/query件数、Ref、独立正本一致と入力不変の確認。
    """
    D.need(not out.exists(), '台帳は新規出力先')
    before = {str(DIAG): DIAG_SHA}
    D.bind({'path':str(D.CLOSURE),'sha256':D.CLOSURE_SHA}, before)
    closure = D.load(D.CLOSURE)
    for ref in list(closure['正本'].values()) + [closure['旧111不変']]:
        D.bind(ref, before)
    result = D.load(Path(closure['正本']['独立1680']['path']))
    formal = D.load(Path(closure['正本']['正式保存']['path']))
    ledger = D.load(D.bind(formal['Native台帳'], before))
    condition = D.load(Path(closure['正本']['金融条件']['path']))
    manifest = D.load(D.bind(condition['manifest'], before))
    raw_inputs = []
    for s in manifest['sessions']:
        D.need('2026-11-09' not in s['id'], '11月09日は対象外')
        ref = s['files']['NK225_book']
        # Raw位置と既指紋はmetadataから写すだけ。stat/hash/openを実行しない。
        raw_inputs.append({'session': s['id'], 'contract': s['contract'], 'raw': {'path':str((Path(manifest['source_root'])/ref['path']).resolve()), 'sha256':ref['sha256'], 'bytes':ref['size']}})
    D.need(len(raw_inputs) == 70, '予定NK225 Raw参照70')
    rows = {(r['session'],r['key']):r for r in result['場別']}
    native_map = {r['session']:r for r in result['Native参照']}
    positions, allocations, intervals, queries = [], [], {}, {}
    summaries = {k:D.zero() for k in result['主key']}
    checks = 0
    for item in ledger['Native']:
        sid = item['session']
        D.need(item['sha256'] == native_map[sid]['sha256'], '正式と独立のNative指紋一致')
        path = D.bind({'path':str(D.STUDY/item['relative']),'sha256':item['sha256']}, before)
        value = json.loads(gzip.decompress(path.read_bytes()), parse_float=Decimal)
        tags = D.entry_tags(value)
        for key in result['主key']:
            book = value['actual']['books'][key]
            stat = D.zero()
            for p in book['positions']:
                row, children, addition = make_position(sid,key,p,book,tags,intervals,queries)
                row['history_class'] = rows[(sid,key)]['history_class']
                row['native_ref'] = {'path':str(path),'sha256':item['sha256']}
                positions.append(row)
                allocations.extend(children)
                D.add(stat,addition)
                D.add(summaries[key],addition)
            checks += D.compare(stat,rows[(sid,key)],sid+'/'+key)
    for key,stat in summaries.items():
        checks += D.compare(stat,result['集計'][key],'全70/'+key)
    D.need(len({r['position_record_id'] for r in positions}) == len(positions), '建玉IDの一意性')
    D.need(len({r['allocation_id'] for r in allocations}) == len(allocations), '返済片IDの一意性')
    after = {p:D.sha(Path(p)) for p in before}
    D.need(before == after, '全Nativeと旧正本/codeの前後不変')
    out.mkdir()
    write_lines(out/'建玉全体の台帳.jsonl.gz',positions)
    write_lines(out/'返済片の台帳.jsonl.gz',allocations)
    reader = {'version':1,'trial':113,'source_trial':112,'fixed':False,'raw_read_authorized':False,
              'raw_inputs':raw_inputs,
              'price_intervals':[{'price_interval_id':k,**v} for k,v in intervals.items()],
              'state_slices':[{'query_id':k,**v} for k,v in queries.items()],
              'phase_rule':'実new fill直後からfinal close直前を含む原行inclusive。各close原行は前片/後片の両側で含め、同BBOのW同体を台帳で検査済み。n=0 queryなし。',
              'curve':'W=R+n*(100*side*(正常返済側BBO-entry_price)-K)。Last曲線と混ぜない。',
              'allocation_curve':'返済片の寿命はentry→当該fill。n=実返済枚、R=0、q0=実返済枚の独立曲線。H50/H100もこの実返済枚が基準。',
              'scope':'112全24×70の実保有寿命だけ。退出後価格/機会損失/MFE回収/ROIなし。'}
    (out/'Reader入力の素材.json').write_text(json.dumps(reader,ensure_ascii=False,indent=2,default=serial,allow_nan=False)+'\n',encoding='utf-8')
    files = {p.name:{'path':str(p),'sha256':D.sha(p),'bytes':p.stat().st_size} for p in sorted(out.iterdir())}
    proof = {'試行':113,'入力試行':112,'成功':True,'112完了記録':{'path':str(D.CLOSURE),'sha256':D.CLOSURE_SHA},
             '場数':70,'口座場数':1680,'建玉行数':len(positions),'返済片行数':len(allocations),
             '価格区間数':len(intervals),'金融state query数':len(queries),'返済前後W同体確認数':len(allocations),
             '独立正本数値比較数':checks,'全残玉予約0':True,'全0口座場を正本照合':True,
             '全24集計':summaries,'成果物':files,'入力SHA256前':before,'入力SHA256後':after,'前後不変':True,
             '作成コード':{'path':str(Path(__file__).resolve()),'sha256':D.sha(Path(__file__))},
             'Raw開封':0,'Raw指紋再計算':0,'Raw stat':0,'市場再生':False,'11月09本文':0,'CSV生成':False,
             '研究目標達成':False,'採用':False}
    (out/'台帳の確認.json').write_text(D.encode(proof),encoding='utf-8')
    return {k:proof[k] for k in ['成功','建玉行数','返済片行数','価格区間数','金融state query数','独立正本数値比較数']} | {'確認':{'path':str(out/'台帳の確認.json'),'sha256':D.sha(out/'台帳の確認.json')}}


if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    print(D.encode(run(Path(args.output).resolve())))
