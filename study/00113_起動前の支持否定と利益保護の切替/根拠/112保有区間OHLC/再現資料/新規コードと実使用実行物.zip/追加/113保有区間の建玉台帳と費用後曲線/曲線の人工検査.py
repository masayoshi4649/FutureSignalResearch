"""状態片の境界・初回返し・同値極値・保存phase差を手製値で確認する。"""

from copy import deepcopy
from decimal import Decimal
import unittest

import 曲線の純集計 as C


def q(index,bid):
    """小さな正常Raw原行を手製で作る。

    引数: index/bid(int)は原行と買気配。
    返り値: dictはReader Quote型。
    """
    return {'clock':str(index),'time':index,'index':index,'source_line':index+1,'last':bid+5,'bid':bid,'ask':bid+10,'quote_ok':True}


def series(points):
    """手製点からReader同形のOHLCを作る。

    引数: points(list[dict])はvalue/quote群。
    返り値: dictは同値のfirst/lastを持つSeries。
    """
    out={'count':len(points),'open':points[0],'close':points[-1]}
    for label,fn in [('high',max),('low',min)]:
        value=fn(p['value'] for p in points)
        selected=[p for p in points if p['value']==value]
        out[label]={'value':value,'first':selected[0]['quote'],'last':selected[-1]['quote']}
    return out


def returns(points):
    """初回と正益後の返しを手製点から作る。

    引数: points(list[dict])は順序付きPoint。
    返り値: dictはReader Returns型。
    """
    out=dict.fromkeys(['first_positive','first_nonpositive','first_negative','first_nonpositive_after_positive','first_negative_after_positive'])
    for p in points:
        positive=out['first_positive'] is not None
        for name,ok in [('first_positive',p['value']>0),('first_nonpositive',p['value']<=0),('first_negative',p['value']<0),
                        ('first_nonpositive_after_positive',positive and p['value']<=0),('first_negative_after_positive',positive and p['value']<0)]:
            if ok and out[name] is None: out[name]=p
    return out


def fixture():
    """2→1→0枚とR=0→923→-154円の実寿命を作る。

    引数: なし。
    返り値: tupleは価格結果、状態片、対応Raw原行。
    """
    quotes=[q(2,990),q(3,1010),q(4,990)]
    price={name:series([{'value':v[name],'quote':v} for v in quotes]) for name in ['last','bid','ask']}
    states=[]
    for selected,n,R in [(quotes[:2],2,0),(quotes[1:],1,923)]:
        unit=[{'value':100*(v['bid']-1000)-77,'quote':v} for v in selected]
        whole=[{'value':R+n*p['value'],'quote':p['quote']} for p in unit]
        states.append({'whole_yen':series(whole),'whole_returns':returns(whole),'unit_returns':returns(unit),
                       'thresholds':[{'threshold':{'id':name},'first':next((p for p in whole if p['value']>0),None) if name=='positive' else None} for name in ['positive','H50','H100']]})
    return price,states,quotes


class CurveTests(unittest.TestCase):
    """全tickを使わない境界とRaw集約の統合人工。"""

    def test_dynamic_quantity_and_returns(self):
        """残量減少とRを反映し、正益後非正/負を片の境界越しに検出する。

        引数: self(CurveTests)は検査器。
        返り値: None。
        """
        price,slices,quotes=fixture()
        curve=C.curves(price,slices,1,1000,77)
        self.assertEqual(curve['whole']['high']['value'],1846)
        self.assertEqual(curve['whole']['low']['value'],-2154)
        self.assertEqual(curve['last']['value'],-154)
        self.assertEqual(curve['whole_returns']['positive']['quote']['index'],3)
        self.assertEqual(curve['whole_returns']['negative_after']['quote']['index'],4)
        self.assertEqual(curve['unit']['low']['first']['index'],2)
        self.assertEqual(curve['unit']['low']['last']['index'],4)
        self.assertNotEqual(curve['last']['value'],2*(-1077))

    def test_close_phase_distinction(self):
        """最終close同原行の値同体とn/R/予約の位相差を保持する。

        引数: self(CurveTests)は検査器。
        返り値: None。
        """
        _,_,quotes=fixture()
        position={'q0':2,'side':1,'entry_price':1000,'K':77,'orders':[
            {'id':'a','kind':'exit','quantity':1,'request_quote':q(2,990),'protection_point':None},
            {'id':'b','kind':'exit','quantity':1,'request_quote':q(3,1010),'protection_point':None}]}
        parts=[{'order_id':'a','quantity':1,'exit_quote':quotes[1],'net_yen':923},{'order_id':'b','quantity':1,'exit_quote':quotes[2],'net_yen':-1077}]
        pre=C.native_mtm(position,parts,{'phase':'pre_fill'},quotes[-1])
        post=C.native_mtm(position,parts,{'phase':'after_source'},quotes[-1])
        self.assertEqual(pre['whole_net'],post['whole_net'])
        self.assertEqual((pre['quantity'],pre['realized_net'],pre['reserved']),(1,923,1))
        self.assertEqual((post['quantity'],post['realized_net'],post['reserved']),(0,-154,0))

    def test_tie_and_raw_value_difference_not_corrected(self):
        """同値の別到達と保存値改変を別の差として残す。

        引数: self(CurveTests)は検査器。
        返り値: None。
        """
        price,slices,quotes=fixture()
        curve=C.curves(price,slices,1,1000,77)
        position={'q0':2,'side':1,'entry_price':1000,'K':77,'entry_quote':quotes[0],'final_close_quote':quotes[-1],
                  'orders':[],'marks':{}}
        parts=[{'order_id':'a','quantity':1,'exit_quote':quotes[1],'net_yen':923},{'order_id':'b','quantity':1,'exit_quote':quotes[-1],'net_yen':-1077}]
        saved={'quote':{k:v for k,v in quotes[-1].items() if k!='clock'},'phase':'pre_fill',**C.native_mtm(position,parts,{'phase':'pre_fill'},quotes[-1])}
        position['marks']={'unit_min':saved}
        witness={(v['index'],v['source_line']):v for v in quotes}
        result=C.compare_marks(position,parts,curve,witness)
        self.assertEqual(result['counts']['同値到達差'],1)
        self.assertEqual(result['counts']['数値差'],0)
        position['marks']['unit_min']['whole_net']+=1
        changed=C.compare_marks(position,parts,curve,witness)
        self.assertEqual(changed['counts']['数値差'],1)
        self.assertEqual(position['marks']['unit_min']['whole_net'],-153)


if __name__=='__main__':
    unittest.main(verbosity=2)
