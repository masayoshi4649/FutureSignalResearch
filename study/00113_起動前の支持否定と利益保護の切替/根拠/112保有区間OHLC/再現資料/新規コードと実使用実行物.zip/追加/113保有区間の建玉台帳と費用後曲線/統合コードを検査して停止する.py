"""実Reader場結果を読む前に統合コード・人工・列契約を固定する。"""

import json
import subprocess
import sys
from pathlib import Path

import Raw結果を統合する as M


HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]


def main():
    """所有コードと非市場人工を停止し、Root固定要求の素材を作る。

    引数: なし。
    返り値: dictは停止と要求素材Ref。実Reader場結果・Rawは読まない。
    """
    target=HERE/'統合コードの停止.json'
    output=HERE/'統合コードの検査'
    M.C.need(not target.exists() and not output.exists(),'統合停止先は新規')
    names=['Raw結果を統合する.py','曲線の純集計.py','曲線の人工検査.py','統合の人工検査.py','CSV列の契約を作る.py',
           'CSV入力の列契約.json','保存点の原行要求を作る.py','保存点witnessのReader要求素材.json','統合_README.md','統合コードを検査して停止する.py']
    own={str(HERE/n):M.sha(HERE/n) for n in names}
    before={}
    refs={
        'ledger_stop':{'path':str(HERE/'台帳準備の停止.json'),'sha256':'5e4ab13fc5e82b018d3681f4499aafc54b67b36ea0589dcda18ae0248072f7a4'},
        'ledger_check':{'path':str(HERE/'112全24と全70の区間/台帳の確認.json'),'sha256':'783495d570779c9fd34b0d1a76e9d4045faf683a491c10e7f6f8e123990e3744'},
        'reader_stop':{'path':str(ROOT/'work/113保有中OHLCの原板照合/停止.json'),'sha256':'6502a505ca8962393c44135c7bcd7be357c08ec1fe11e405aea9213bc068b440'},
        'reader_condition':{'path':str(ROOT/'work/113OHLC進行/112保有区間OHLCの固定要求.json'),'sha256':'feaeece8f75a0775988d03a93c1ea8facdc0a18f259c5ae538cc2f00019073c8'},
        'reader_completion':{'path':str(ROOT/'work/113OHLC原板結果_全70/完了.json'),'sha256':'52d2df742092f91e9cb369b2c9c510e69864d790b2b6ff28fa003a92991bb0a7'},
        'csv_schema':{'path':str(HERE/'CSV入力の列契約.json'),'sha256':'2da45caa79a6f6b621142c771c71953d97ad4bee82e2c99f3cf8f7f01d6b22b4'},
        'witness_input':{'path':str(HERE/'保存点witnessのReader要求素材.json'),'sha256':'fe7bcb3acc652a7ef4ec2dadfaeee86c4e145611e8c3f41eb856d96360ac2734'},
    }
    values={n:M.load(M.bind(ref,before)) for n,ref in refs.items()}
    M.C.need(values['reader_completion']['success'] and values['reader_completion']['sessions']==70,'Reader完了metadata成功')
    M.C.need(M.same_ref(values['reader_completion']['condition'],refs['reader_condition']) and M.same_ref(values['reader_condition']['witness_requests'],refs['witness_input']),'固定入力のschema接合')
    M.C.need(values['csv_schema']['列順']==M.COLUMNS,'固定列順のschema')
    for ref in values['ledger_check']['成果物'].values():
        M.bind(ref,before)
    output.mkdir()
    tests=[]
    for name in ['曲線の人工検査.py','統合の人工検査.py']:
        p=subprocess.run([sys.executable,'-X','utf8',str(HERE/name)],cwd=HERE,capture_output=True,text=True,encoding='utf-8',timeout=60)
        M.C.need(p.returncode==0 and 'Ran 3 tests' in p.stderr,'人工成功:'+name)
        log=output/(name+'.txt')
        log.write_text(p.stdout+p.stderr,encoding='utf-8')
        tests.append({'path':str(log),'sha256':M.sha(log)})
    M.C.need(own=={p:M.sha(Path(p)) for p in own} and before=={p:M.sha(Path(p)) for p in before},'統合所有/接合metadata前後不変')
    stop={'試行':113,'成功':True,'Raw結果読取前停止':True,'所有ファイルSHA256':own,'人工主数':6,'人工':tests,
          '入力接合':refs,'metadata前後不変':True,'Reader場結果本文読取':0,'Raw開封':0,'CSV生成':False,'旧固定編集':0,
          '限界':['Raw計算は停止済み独立Readerの一走査結果。統合は保存marksへ値を補正しない。','Actor位相はRaw自体にないため実約定境界とモデル評価順の候補として明記。'],
          '研究目標達成':False,'採用':False}
    M.save(target,stop)
    refs['integration_stop']={'path':str(target),'sha256':M.sha(target)}
    request={'version':1,'trial':113,'fixed':False,'reader_result_read_authorized':False,'refs':refs,'code_sha256':own}
    request_path=HERE/'統合要求の素材.json'
    M.save(request_path,request)
    return {'成功':True,'停止':refs['integration_stop'],'要求素材':{'path':str(request_path),'sha256':M.sha(request_path)}}


if __name__=='__main__':
    print(json.dumps(main(),ensure_ascii=False))
