"""Raw未実行を明示した3配列の日本語flat列契約を作る。"""

import gzip
import hashlib
import json
from pathlib import Path


HERE=Path(__file__).resolve().parent


def columns():
    """3種類のCSV入力列を一定順に定義する。

    引数: なし。
    返り値: dict[str,list[str]]は配列名と日本語の固定列順。
    """
    common=['セッション','口座','政策','滑りpt','遅延秒','手法','入口枝','取得段階','建玉ID','売買','初期枚数','曲線基準枚数','取得価格','取得時刻','取得Index','取得物理行']
    raw=[]
    for name in ['Last','Bid','Ask']:
        for field in ['始値','高値','安値','終値']:
            raw.append(name+field)
            for phase in ['初回','最終'] if field in ['高値','安値'] else ['']:
                raw.extend(name+field+phase+part for part in ['時刻','Index','物理行'])
    curve=[]
    for name in ['全玉最大W','全玉最小W','1枚最大費用後益','1枚最小費用後益']:
        curve.append(name+'円')
        for phase in ['初回','最終']:
            curve.extend(name+phase+part for part in ['時刻','Index','物理行','Last','Bid','Ask'])
    for name in ['全玉初正益','1枚初正益','全玉正益後初非正','全玉正益後初負','1枚正益後初非正','1枚正益後初負','H50初到達','H100初到達']:
        curve.extend(name+part for part in ['円','時刻','Index','物理行','Last','Bid','Ask'])
    facts=['正常BBO観測数','異常BBO行数','Raw境界一致','実正益後赤字','保護起動前完結赤字','起動後赤字','価格同値の費用赤字片数','価格同値の費用赤字円',
           '要求から約定の最大秒','要求後の最大不利BBO移動pt','要求時返済気配不明数','保存marks数値差数','保存marks原行差数','保存marks同値到達差数','保存marks位相候補差数','保存marks返し初回性未検証数']
    position=common+['最終返済時刻','最終返済Index','最終返済物理行','実現粗利益円','実現純利益円','返済片数','利益保護起動','利益保護起動時刻','Source返済理由','保護返済理由']+raw+curve+facts
    allocation=common+['返済片ID','返済枚数','返済価格','返済時刻','返済Index','返済物理行','実現粗利益円','実現純利益円','往復手数料円','往復滑り円',
                       '返済理由','返済種別','要求時刻','要求Index','要求物理行','約定遅延秒','約定遅延原行数','約定遅延物理行数','要求時返済気配','実返済気配','要求後不利BBO移動pt',
                       '返済前n','返済後n','返済前R円','返済後R円','返済前W円','返済後W円','価格同値の費用赤字']+raw+curve+['正常BBO観測数','異常BBO行数','Raw境界一致']
    summary=['口座','政策','滑りpt','遅延秒','場数','建玉数','新規枚数','返済片数','実現粗利益円','往復手数料円','往復滑り円','実現純利益円','利益総額円','損失総額円','勝ち玉数','負け玉数','同値玉数',
             '実正益後赤字玉数','実正益後赤字円','保護起動前完結赤字玉数','保護起動前完結赤字円','起動後赤字玉数','起動後赤字円',
             '価格同値の費用赤字片数','価格同値の費用赤字円','取得後逆行で完結した赤字玉数','取得後逆行で完結した赤字円',
             '保存marks数値差数','保存marks原行差数','保存marks同値到達差数','保存marks位相候補差数','保存marks返し初回性未検証数',
             'Raw境界不一致数','実保有時間秒','実数量秒','勝率','PF','平均利益円','平均損失円']
    return {'建玉全体':position,'返済片':allocation,'候補別集計':summary}


def run():
    """契約と未実行の例を新規保存する。

    引数: なし。112成立台帳の先頭行だけを例にする。
    返り値: dictは列契約Ref。Raw値を仮生成しない。
    """
    out=HERE/'CSV入力の列契約.json'
    if out.exists():
        raise ValueError('列契約は新規保存')
    expected=columns()
    for key,cols in expected.items():
        if len(cols)!=len(set(cols)):
            raise ValueError('列重複:'+key)
    proof=json.loads((HERE/'112全24と全70の区間/台帳の確認.json').read_bytes())
    ref=proof['成果物']['建玉全体の台帳.jsonl.gz']
    path=Path(ref['path'])
    if hashlib.sha256(path.read_bytes()).hexdigest()!=ref['sha256']:
        raise ValueError('例の台帳SHA差')
    with gzip.open(path,'rt',encoding='utf-8') as f:
        first=json.loads(next(f))
    example=dict.fromkeys(expected['建玉全体'])
    example.update({'セッション':first['session'],'口座':first['key'],'政策':first['policy'],'滑りpt':first['slip_pts'],'遅延秒':first['delay_seconds'],
                    '手法':first['method'],'入口枝':first['owner'],'取得段階':first['source_kind'],'建玉ID':first['position_id'],'売買':'買い' if first['side']==1 else '売り',
                    '初期枚数':first['q0'],'曲線基準枚数':first['q0'],'取得価格':first['entry_price'],'取得Index':first['entry_quote']['index'],'取得物理行':first['entry_quote']['source_line'],
                    '最終返済Index':first['final_close_quote']['index'],'最終返済物理行':first['final_close_quote']['source_line'],
                    '実現粗利益円':first['gross_yen'],'実現純利益円':first['final_net_yen'],'返済片数':len(first['allocation_ids']),'利益保護起動':first['protection_active']})
    value={'試行':113,'入力試行':112,'状態':'列契約の準備。Raw未実行であり数値結果ではない。','トップ配列':['建玉全体','返済片','候補別集計'],
           '列順':expected,'セル型':'日本語列名のstring/number/bool/nullのみ。全行同一列順。時刻はJST ISO文字列。',
           '先頭行の例_未実行Raw列はnull':example,
           '別検査JSON':'Native/Reader Ref、全marks原値と差の分類、各query/witness、検査詳細。CSVへ全構造を複写しない。',
           '禁止':'退出後仮利益、機会損失、MFE回収率、ROI、高値で取れたはずの仮PnL列なし。'}
    out.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return {'Ref':{'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},'列数':{k:len(v) for k,v in expected.items()}}


if __name__=='__main__':
    print(json.dumps(run(),ensure_ascii=False))
