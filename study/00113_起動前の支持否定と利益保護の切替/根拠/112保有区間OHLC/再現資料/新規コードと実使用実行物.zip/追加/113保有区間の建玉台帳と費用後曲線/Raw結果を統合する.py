"""Root固定のReader成功結果を実寿命へ結び、CSV用3配列と差の検査資料を作る。"""

import argparse
from collections import defaultdict
from decimal import Decimal
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path

import 曲線の純集計 as C


HERE=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('csv_columns113',HERE/'CSV列の契約を作る.py')
SC=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SC)
COLUMNS=SC.columns()


def sha(p):
    """保存結果の指紋を計算する。

    引数: p(Path)はmetadata/台帳/Reader結果。Rawは渡さない。
    返り値: strはSHA256。
    """
    return hashlib.sha256(p.read_bytes()).hexdigest()


def load(p):
    """保存JSONを十進数で読む。

    引数: p(Path)は通常又はgzip JSON。
    返り値: dictは保存値。
    """
    body=p.read_bytes()
    return json.loads(gzip.decompress(body) if p.suffix=='.gz' else body,parse_float=Decimal)


def serial(v):
    """金融値をscalar JSONへ写す。

    引数: v(Decimal)は十進数。
    返り値: int又はfloatは出力数値。
    """
    if isinstance(v,Decimal):
        return int(v) if v==v.to_integral_value() else float(v)
    raise TypeError(type(v).__name__)


def bind(ref,before):
    """Rootが固定した参照を現物へ認証する。

    引数: ref(dict)、before(dict)はpath/SHAと指紋台帳。
    返り値: Pathは認証済み位置。
    """
    p=Path(ref['path'])
    C.need(p.is_absolute() and '2026-11-09' not in str(p),'明示絶対参照/11月09対象外')
    C.need(sha(p)==ref['sha256'],'保存参照SHA差:'+str(p))
    before[str(p)]=ref['sha256']
    return p


def same_ref(left,right):
    """同一実ファイルへの区切り文字の表記差だけを許して参照を照合する。

    引数: left/right(dict)はRootのpath/SHA参照。
    返り値: boolはSHAと解決絶対パスが一致する場合に真。
    """
    return left['sha256']==right['sha256'] and Path(left['path']).resolve()==Path(right['path']).resolve()


def lines(path):
    """圧縮実寿命台帳を逐次復号する。

    引数: path(Path)はgzip JSONL。
    返り値: iterator[dict]は実玉又は返済片の保存値。
    """
    with gzip.open(path,'rt',encoding='utf-8') as stream:
        for row in stream:
            yield json.loads(row,parse_float=Decimal)


def save(path,value):
    """JSONを新規先へ保存する。

    引数: path(Path)、value(dict)は保存先と結果。
    返り値: None。gzipは時刻を固定し、全tickを保存しない。
    """
    data=json.dumps(value,ensure_ascii=False,separators=(',',':'),default=serial,allow_nan=False).encode('utf-8')
    with path.open('xb') as stream:
        if path.suffix=='.gz':
            with gzip.GzipFile(filename='',mode='wb',mtime=0,fileobj=stream) as compressed:
                compressed.write(data)
        else:
            stream.write(data+b'\n')


def base(position,array_name):
    """日本語flat行を固定順で初期化する。

    引数: position(dict)、array_name(str)は実建玉と配列種別。
    返り値: dictは全列を持つ行。
    """
    row=dict.fromkeys(COLUMNS[array_name])
    row.update({'セッション':position['session'],'口座':position['key'],'政策':position['policy'],'滑りpt':position['slip_pts'],'遅延秒':position['delay_seconds'],
                '手法':position['method'],'入口枝':position['owner'],'取得段階':position['source_kind'],'建玉ID':position['position_id'],
                '売買':'買い' if position['side']==1 else '売り','初期枚数':position['q0'],'曲線基準枚数':position['q0'],'取得価格':position['entry_price']})
    C.put_quote(row,'取得',position['entry_quote'])
    return row


def request_fact(part,position,witnesses):
    """実要求時BBO評価と実返済の価格移動を記録する。

    引数: part/position(dict)、witnesses(dict)は実配賦・建玉・原行索引。
    返り値: dictは評価可否と事実。退出後の仮利益ではない。
    """
    key=(part['request_quote']['index'],part['request_quote']['source_line'])
    C.need(key in witnesses,'要求原行witness欠落')
    q=witnesses[key]
    known=C.normal(q)
    mark=q['bid' if position['side']==1 else 'ask'] if known else None
    value=part['quantity']*(100*position['side']*(C.dec(mark)-C.dec(position['entry_price']))-position['K']) if known else None
    adverse=position['side']*(C.dec(mark)-C.dec(part['exit_price'])) if known else None
    same=part['exit_price']==position['entry_price'] and part['net_yen']<0
    return {'normal_request_BBO':known,'request_mark':mark,'request_net_yen':value,'adverse_points':adverse,
            'request_positive_fill_negative':known and value>0 and part['net_yen']<0,
            'same_price_cost_negative':same,
            'type':'保護' if part['protection_point'] is not None else 'Source'}


def held_seconds(positions):
    """同口座の保有区間の和集合秒を計算する。

    引数: positions(list[dict])は同口座の実玉。
    返り値: Decimalは両建て/重複建玉を二重計数しない実保有秒。
    """
    intervals=sorted((C.dec(p['entry_quote']['time']),C.dec(p['final_close_quote']['time'])) for p in positions)
    end=None
    value=Decimal(0)
    for start,finish in intervals:
        value+=max(Decimal(0),finish-max(start,end)) if end is not None else finish-start
        end=max(end,finish) if end is not None else finish
    return value


def integrate_position(position,parts,scene):
    """一建玉と実返済片をReaderの保有中集約へ結ぶ。

    引数: position(dict)、parts(list[dict])、scene(dict)は寿命台帳・実配賦・認証済みReader場結果。
    返り値: tupleはflat建玉、flat返済片、nested検査、追加原因事実。
    """
    prices=scene['price_intervals']
    states=scene['state_queries']
    price=prices[position['price_interval_id']]
    C.need(price['start_matched'] and price['end_matched'],'実寿命境界がRawにない')
    sequence=[states[qid] for qid in position['state_query_ids']]
    curve=C.curves(price,sequence,position['side'],position['entry_price'],position['K'],prices)
    C.need(curve['last'] is not None and C.dec(curve['last']['value'])==C.dec(position['final_net_yen']),'Raw最終Wと実現額差')
    witnesses={}
    for w in scene['witnesses'].values():
        C.need(w['found'] and w['index_matched'],'Reader witness不成功')
        witnesses[(w['request']['index'],w['request']['source_line'])]=w['quote']
    mark_check=C.compare_marks(position,parts,curve,witnesses)
    facts=[request_fact(p,position,witnesses) for p in parts]
    row=base(position,'建玉全体')
    C.put_quote(row,'最終返済',position['final_close_quote'])
    row.update({'実現粗利益円':position['gross_yen'],'実現純利益円':position['final_net_yen'],'返済片数':len(parts),
                '利益保護起動':position['protection_active'],'利益保護起動時刻':C.clock(position['activation']['quote']) if position['activation'] else None,
                'Source返済理由':' | '.join(dict.fromkeys(p['reason'] for p,f in zip(parts,facts) if f['type']=='Source')),
                '保護返済理由':' | '.join(dict.fromkeys(p['reason'] for p,f in zip(parts,facts) if f['type']=='保護'))})
    for name in ['last','bid','ask']:
        C.put_series(row,{'last':'Last','bid':'Bid','ask':'Ask'}[name],price[name])
    C.put_curves(row,curve)
    loss=position['final_net_yen']<0
    row.update({'正常BBO観測数':price['bid']['count'],'異常BBO行数':price['bad_bbo_rows'],'Raw境界一致':True,
                '実正益後赤字':curve['whole_returns']['positive'] is not None and loss,
                '保護起動前完結赤字':None if position['policy']=='S0' else loss and not position['protection_active'],
                '起動後赤字':None if position['policy']=='S0' else loss and position['protection_active'],
                '価格同値の費用赤字片数':sum(f['same_price_cost_negative'] for f in facts),
                '価格同値の費用赤字円':sum((p['net_yen'] for p,f in zip(parts,facts) if f['same_price_cost_negative']),Decimal(0)),
                '要求から約定の最大秒':max((p['request_to_fill_seconds'] for p in parts),default=None),
                '要求後の最大不利BBO移動pt':max((f['adverse_points'] for f in facts if f['adverse_points'] is not None),default=None),
                '要求時返済気配不明数':sum(not f['normal_request_BBO'] for f in facts),
                **{'保存marks'+name+'数':count for name,count in mark_check['counts'].items()}})
    allocation_rows=[]
    for part,fact in zip(parts,facts):
        pr=prices[part['price_interval_id']]
        st=states[part['state_query_id']]
        cc=C.curves(pr,[st],position['side'],position['entry_price'],position['K'],prices)
        C.need(cc['last'] is not None and C.dec(cc['last']['value'])==C.dec(part['net_yen']),'返済片Raw最終評価と実配賦差')
        ar=base(position,'返済片')
        ar.update({'返済片ID':part['allocation_id'],'曲線基準枚数':part['quantity'],'返済枚数':part['quantity'],'返済価格':part['exit_price'],
                   '実現粗利益円':part['gross_yen'],'実現純利益円':part['net_yen'],
                   '往復手数料円':part['entry_fee_yen']+part['exit_fee_yen'],'往復滑り円':part['entry_slip_yen']+part['exit_slip_yen'],
                   '返済理由':part['reason'],'返済種別':fact['type'],
                   '約定遅延秒':part['request_to_fill_seconds'],'約定遅延原行数':part['request_to_fill_index'],'約定遅延物理行数':part['request_to_fill_lines'],
                   '要求時返済気配':fact['request_mark'],'実返済気配':part['exit_price'],'要求後不利BBO移動pt':fact['adverse_points'],
                   '返済前n':part['n_before'],'返済後n':part['n_after'],'返済前R円':part['R_before'],'返済後R円':part['R_after'],
                   '返済前W円':part['W_before_close'],'返済後W円':part['W_after_close'],'価格同値の費用赤字':fact['same_price_cost_negative'],
                   '正常BBO観測数':pr['bid']['count'],'異常BBO行数':pr['bad_bbo_rows'],'Raw境界一致':pr['start_matched'] and pr['end_matched']})
        C.put_quote(ar,'返済',part['exit_quote'])
        C.put_quote(ar,'要求',part['request_quote'])
        for name in ['last','bid','ask']:
            C.put_series(ar,{'last':'Last','bid':'Bid','ask':'Ask'}[name],pr[name])
        C.put_curves(ar,cc)
        allocation_rows.append(ar)
    additional={'position_id':position['position_id'],'key':position['key'],'session':position['session'],
                'last_apparent_max':curve['last_apparent_max'],'normal_BBO_max':curve['whole']['high'],
                'Lastだけ正益':curve['last_apparent_max'] is not None and curve['whole']['high'] is not None and curve['last_apparent_max']['value']>0 and curve['whole']['high']['value']<=0,
                '実現純額円':position['final_net_yen'],
                '要求BBO正益から実返済赤字':[{'allocation_id':p['allocation_id'],'返済種別':f['type'],'実現純額円':p['net_yen'],
                                            '要求時点費用後評価円':f['request_net_yen'],'要求後不利移動pt':f['adverse_points']}
                                           for p,f in zip(parts,facts) if f['request_positive_fill_negative']]}
    detail={'position_record_id':position['position_record_id'],'position_id':position['position_id'],'key':position['key'],'session':position['session'],
            '曲線':curve,'保存marksの検査':mark_check,'要求と実約定の事実':facts}
    return row,allocation_rows,detail,additional


# ----------------------------------------


def summarize(key,positions,parts,rows,extra):
    """同口座の実損益と損失事実を加算する。

    引数: key(str)、positions/parts/rows/extra(list)は同口座の実台帳と統合行。
    返り値: dictは固定39列の候補別集計。
    """
    row=dict.fromkeys(COLUMNS['候補別集計'])
    sample=positions[0] if positions else None
    policy,cost,delay=key.split('_')
    positive=sum((max(Decimal(0),C.dec(p['final_net_yen'])) for p in positions),Decimal(0))
    negative=sum((min(Decimal(0),C.dec(p['final_net_yen'])) for p in positions),Decimal(0))
    wins=sum(p['final_net_yen']>0 for p in positions)
    losses=sum(p['final_net_yen']<0 for p in positions)
    net=positive+negative
    qty=sum(p['q0'] for p in positions)
    row.update({'口座':key,'政策':policy,'滑りpt':int(cost[1:]),'遅延秒':int(delay[1:]),'場数':70,'建玉数':len(positions),'新規枚数':qty,'返済片数':len(parts),
                '実現粗利益円':sum((p['gross_yen'] for p in positions),Decimal(0)),
                '往復手数料円':77*qty,'往復滑り円':200*int(cost[1:])*qty,'実現純利益円':net,
                '利益総額円':positive,'損失総額円':negative,'勝ち玉数':wins,'負け玉数':losses,'同値玉数':len(positions)-wins-losses,
                '実正益後赤字玉数':sum(r['実正益後赤字'] for r in rows),
                '実正益後赤字円':sum((r['実現純利益円'] for r in rows if r['実正益後赤字']),Decimal(0)),
                '保護起動前完結赤字玉数':None if policy=='S0' else sum(r['保護起動前完結赤字'] for r in rows),
                '保護起動前完結赤字円':None if policy=='S0' else sum((r['実現純利益円'] for r in rows if r['保護起動前完結赤字']),Decimal(0)),
                '起動後赤字玉数':None if policy=='S0' else sum(r['起動後赤字'] for r in rows),
                '起動後赤字円':None if policy=='S0' else sum((r['実現純利益円'] for r in rows if r['起動後赤字']),Decimal(0)),
                '価格同値の費用赤字片数':sum(r['価格同値の費用赤字片数'] for r in rows),
                '価格同値の費用赤字円':sum((r['価格同値の費用赤字円'] for r in rows),Decimal(0)),
                '取得後逆行で完結した赤字玉数':sum(p['final_net_yen']<0 and p['gross_yen']<0 for p in positions),
                '取得後逆行で完結した赤字円':sum((p['final_net_yen'] for p in positions if p['final_net_yen']<0 and p['gross_yen']<0),Decimal(0)),
                'Raw境界不一致数':sum(not r['Raw境界一致'] for r in rows),
                '実保有時間秒':held_seconds(positions),'実数量秒':sum((p['quantity']*(C.dec(p['exit_quote']['time'])-C.dec(p['entry_quote']['time'])) for p in parts),Decimal(0)),
                '勝率':Decimal(wins)/len(positions) if positions else None,'PF':positive/-negative if negative else None,
                '平均利益円':positive/wins if wins else None,'平均損失円':negative/losses if losses else None})
    for name in ['数値差','原行差','同値到達差','位相候補差','返し初回性未検証']:
        row['保存marks'+name+'数']=sum(r['保存marks'+name+'数'] for r in rows)
    return row


def run(fixed,expected,out):
    """Root固定とReader全成功を認証して、3配列と別診断を新規保存する。

    引数: fixed/out(Path)、expected(str)は明示要求・新規先・要求SHA。
    返り値: dictは結果Refと件数。Rawを開かず、Readerを再実行しない。
    """
    C.need(not out.exists(),'統合先は新規')
    before={}
    bind({'path':str(fixed),'sha256':expected},before)
    request=load(fixed)
    C.need(request['version']==1 and request['trial']==113 and request['fixed'] is True and request['reader_result_read_authorized'] is True,'Root統合固定が必要')
    refs=request['refs']
    values={k:load(bind(refs[k],before)) for k in ['integration_stop','ledger_stop','ledger_check','reader_stop','reader_condition','reader_completion','csv_schema','witness_input']}
    C.need(values['integration_stop']['成功'] and values['integration_stop']['Raw結果読取前停止'],'統合コードの人工停止')
    for path,h in values['integration_stop']['所有ファイルSHA256'].items():
        C.need(request['code_sha256'].get(path)==h,'実統合停止codeとRoot固定の同体')
    for p,h in request['code_sha256'].items():
        bind({'path':p,'sha256':h},before)
    C.need(str(Path(__file__).resolve()) in request['code_sha256'] and str(HERE/'曲線の純集計.py') in request['code_sha256'],'実統合codeを事前固定')
    ledger=values['ledger_check']
    C.need(values['ledger_stop']['成功'] and values['ledger_stop']['台帳確認']==refs['ledger_check'],'台帳停止と成功正本')
    C.need(ledger['成功'] and ledger['前後不変'] and ledger['口座場数']==1680,'112全台帳成功')
    C.need(values['csv_schema']['列順']==COLUMNS,'固定CSV列契約')
    complete=values['reader_completion']
    condition=values['reader_condition']
    C.need(complete['version']==1 and complete['trial']==113 and complete['source_trial']==112 and complete['success'] and complete['sessions']==70 and complete['raw_passes']==70 and complete['unchanged'] and complete['before']==complete['after'] and not complete['financial_replay'],'Reader全70成功')
    C.need(values['reader_stop']['成功'] and same_ref(complete['condition'],refs['reader_condition']) and same_ref(condition['reader_stop'],refs['reader_stop']),'Reader実固定と停止')
    queries_ref=ledger['成果物']['Reader入力の素材.json']
    C.need(same_ref(complete['queries'],queries_ref),'Readerと固定query同体')
    C.need(same_ref(condition['witness_requests'],refs['witness_input']),'Readerと追加witness同体')
    query=load(bind(queries_ref,before))
    posref=ledger['成果物']['建玉全体の台帳.jsonl.gz']
    partref=ledger['成果物']['返済片の台帳.jsonl.gz']
    positions=list(lines(bind(posref,before)))
    parts=list(lines(bind(partref,before)))
    by_position=defaultdict(list)
    for p in parts:
        by_position[p['position_record_id']].append(p)
    by_session=defaultdict(list)
    for p in positions:
        by_session[p['session']].append(p)
    expected_sessions=[r['session'] for r in query['raw_inputs']]
    C.need([r['session'] for r in complete['results']]==expected_sessions,'全70場順')
    all_rows,allocation_rows,details,additional=[],[],[],[]
    for ref in complete['results']:
        scene=load(bind(ref['result'],before))
        C.need(scene['success'] and scene['session']==ref['session'] and scene['actual_sha256']==scene['raw']['sha256'] and scene['stat_before']==scene['stat_after'] and scene['raw_passes']==1,'場別Raw指紋/一走査/前後stat成功')
        for p in by_session[ref['session']]:
            r,a,d,x=integrate_position(p,by_position[p['position_record_id']],scene)
            all_rows.append(r);allocation_rows.extend(a);details.append(d);additional.append(x)
    summaries=[]
    for key,expected_summary in ledger['全24集計'].items():
        pp=[p for p in positions if p['key']==key]
        aa=[p for p in parts if p['key']==key]
        rr=[r for r in all_rows if r['口座']==key]
        s=summarize(key,pp,aa,rr,[r for r in additional if r['key']==key])
        for lhs,rhs in [('建玉数','実建玉数'),('新規枚数','新規mini枚'),('実現純利益円','費用後実現純額円'),('利益総額円','正実現額円'),('損失総額円','負実現額円'),('勝ち玉数','勝ち玉数'),('負け玉数','負け玉数'),('同値玉数','同値玉数')]:
            C.need(s[lhs]==expected_summary[rhs],'最終CSV集計と独立正本:'+key+'/'+lhs)
        summaries.append(s)
    for name,rows in [('建玉全体',all_rows),('返済片',allocation_rows),('候補別集計',summaries)]:
        C.need(all(list(r)==COLUMNS[name] and all(v is None or isinstance(v,(str,int,float,Decimal,bool)) for v in r.values()) for r in rows),'flat列順/scalar:'+name)
    after={p:sha(Path(p)) for p in before}
    C.need(before==after,'全入力前後不変')
    out.mkdir()
    result={'試行':113,'入力試行':112,'成功':True,'建玉全体':all_rows,'返済片':allocation_rows,'候補別集計':summaries}
    save(out/'CSV用の統合結果.json.gz',result)
    save(out/'保存点差と曲線の検査.json.gz',{'試行':113,'成功':True,'保存点検査':details,'全tick保存':False,'期待値への補正':False})
    cause=[]
    for key in ledger['全24集計']:
        group=[v for v in additional if v['key']==key]
        selected=[v for v in group if v['Lastだけ正益']]
        waiting=[a for v in group for a in v['要求BBO正益から実返済赤字']]
        cause.append({'口座':key,'Lastだけ正益玉数':len(selected),'Lastだけ正益の実現純額円':sum((v['実現純額円'] for v in selected),Decimal(0)),
                      'Lastだけ正益の実現損失円':sum((min(0,v['実現純額円']) for v in selected),Decimal(0)),
                      '要求BBO正益から実返済赤字片数':len(waiting),'要求BBO正益から実返済赤字の実現額円':sum((v['実現純額円'] for v in waiting),Decimal(0)),
                      'S0保護未起動は対象外':key.startswith('S0_')})
    save(out/'Lastと要求待ちの事実診断.json.gz',{'試行':113,'成功':True,'口座別':cause,'実玉別':additional,
                                              '定義':'Last見かけWも実n/Rの保有片内。要求評価は当実allocation枚数の正常BBO費用後評価で、退出後仮利益ではない。',
                                              'S0':'追加保護Stateなし。保護未起動/起動後赤字はCSVではnull。H50/H100は評価水準の観測だけ。',
                                              '取得後逆行の列定義':'実現粗額<0かつ実現純額<0の成立玉。原因の因果効果や全経路の形状を意味しない。'})
    files={p.name:{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.iterdir())}
    proof={'試行':113,'成功':True,'Root要求':{'path':str(fixed),'sha256':expected},'成果物':files,
           '建玉行数':len(all_rows),'返済片行数':len(allocation_rows),'候補数':len(summaries),
           '入力SHA256前':before,'入力SHA256後':after,'前後不変':True,'Raw再読':0,'Reader再実行':False,
           'CSV生成':False,'11月09本文':0,'旧固定編集':0,'採用':False,'研究目標達成':False}
    save(out/'統合の確認.json',proof)
    return {'成功':True,'確認':{'path':str(out/'統合の確認.json'),'sha256':sha(out/'統合の確認.json')},'建玉行数':len(all_rows),'返済片行数':len(allocation_rows)}


if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--fixed',required=True)
    p.add_argument('--sha256',required=True)
    p.add_argument('--output',required=True)
    args=p.parse_args()
    print(json.dumps(run(Path(args.fixed).resolve(),args.sha256,Path(args.output).resolve()),ensure_ascii=False))
