# Raw Reader結果と実台帳の統合

原板はReaderが一場一走査し、この統合器はその認証済み集約JSONとNative派生実寿命台帳だけを読む。原板を追加で開かない。112完了正本・台帳の指紋を維持し、113金融を実行しない。

結果は `CSV用の統合結果.json.gz` のトップ3配列「建玉全体」「返済片」「候補別集計」。日本語flat scalar、列順は `CSV入力の列契約.json` に固定した216/221/39列。時刻はJST ISO、欠損と対象外はnull。S0には追加保護Stateがないので保護起動前/起動後赤字はnull、H50/H100は費用後評価水準の到達観測だけである。

建玉Wは各実n/R一定片のRaw極値から統合し、部分返済でnが減りRが増える。返済片は実取得から当返済までの量だけを持つ。Rawの最終Wと実実現純額、返済片の最終評価と実allocationを照合する。Last/Bid/Askは別列。全返済前後Wの同体は台帳生成時にも確認済み。

同値極値のfirst/last、初回正益と正益後の非正/負への戻りはRaw一走査の少数witnessから統合する。元marksを期待してRawを加工しない。保存marksは原行witnessへ結び、全MTM値とn/R/予約を元の評価位相で独立再計算する。数値差・原行差・同値到達差・位相候補差を補正せず残す。RawにActor位相自体は無いため、取得/最終返済境界とモデル評価順の可能位相を明記する。

別 `Lastと要求待ちの事実診断.json.gz` は、実n/R準拠のLast見かけ最大Wが正、正常BBO最大Wが非正の玉数/実現損失、および正常要求BBOで当実allocation費用後評価が正だったのに実返済netが負の片数/実現額を記録する。要求後不利移動ptは符号付きで、負なら有利方向。価格同値の費用赤字は当返済価格=取得価格かつ実net<0。

「取得後逆行で完結」の候補別列は実現粗額<0かつ実現純額<0を数える事実列で、経路全体や原因の因果を主張しない。未参加、退出後価格、機会損失、MFE回収率、ROI、高値なら取れたはずの仮PnLを生成しない。

## Root固定要求

`version=1, trial=113, fixed=true, reader_result_read_authorized=true`、`refs` は integration_stop/ledger_stop/ledger_check/reader_stop/reader_condition/reader_completion/csv_schema/witness_input の絶対path/SHA。`code_sha256` は統合停止の所有集合を全て含む。

```powershell
python -X utf8 'work/113保有区間の建玉台帳と費用後曲線/Raw結果を統合する.py' --fixed '<Root絶対要求>' --sha256 '<要求SHA>' --output '<未作成先>'
```

全70Reader成功、固定条件、query551a、witness fe7b、各場compressed SHA成功、metadata/code前後不変、全区間境界一致の後に統合する。CSV3点の生成と独立再読はRootが担当する。大きいnested marks/Raw/Native参照は別検査JSONへ残しCSVには複写しない。
