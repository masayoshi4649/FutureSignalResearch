"""Reader同形の手製集約で、CSV行・実残量・損失事実の接合を検査する。"""

from copy import deepcopy
from decimal import Decimal
import importlib.util
from pathlib import Path
import unittest

import Raw結果を統合する as M
import 曲線の人工検査 as T
import 人工検査 as L


def fixture():
    """手製実寿命とReader型を一致した原行集合から作る。

    引数: なし。
    返り値: tupleは建玉、返済片、scene。
    """
    sid,book,p,tags=L.fixture()
    intervals,queries={},{}
    position,parts,_=L.B.make_position(sid,book['key'],p,book,tags,intervals,queries)
    quotes={i['quote']['index']:i['quote'] for i in book['fills'] if i['action']=='new'}
    quotes.update({i['quote']['index']:i['quote'] for i in book['fills'] if i['action']=='close'})
    quotes[1]=p['source']['birth_quote']
    prices={}
    for iid,v in intervals.items():
        selected=[q for i,q in sorted(quotes.items()) if v['start_quote']['index']<=i<=v['end_quote']['index']]
        prices[iid]={'interval':{'price_interval_id':iid,**v},'start_matched':True,'end_matched':True,'bad_bbo_rows':0,
                     **{name:T.series([{'value':q[name],'quote':q} for q in selected]) for name in ['last','bid','ask']}}
    states={}
    for qid,v in queries.items():
        interval=intervals[v['price_interval_id']]
        selected=[q for i,q in sorted(quotes.items()) if interval['start_quote']['index']<=i<=interval['end_quote']['index']]
        unit=[{'value':100*v['side']*(Decimal(str(q['bid' if v['side']==1 else 'ask']))-Decimal(str(v['entry_price'])))-v['K'],'quote':q} for q in selected]
        whole=[{'value':Decimal(str(v['R']))+v['n']*p['value'],'quote':p['quote']} for p in unit]
        states[qid]={'query':{'query_id':qid,**v},'bad_bbo_rows':0,'whole_yen':T.series(whole),'whole_returns':T.returns(whole),'unit_returns':T.returns(unit),
                     'thresholds':[{'threshold':thr,'first':next((p for p in whole if p['value']>thr['whole_yen'] if thr['strict']),None) if thr['strict'] else next((p for p in whole if p['value']>=thr['whole_yen']),None)} for thr in v['thresholds']]}
    witnesses={str(i):{'request':{'index':q['index'],'source_line':q['source_line']},'found':True,'index_matched':True,'quote':q} for i,q in quotes.items()}
    return position,parts,{'price_intervals':prices,'state_queries':states,'witnesses':witnesses}


class IntegrationTests(unittest.TestCase):
    """市場を使わず構造接合と事実分類を検査する。"""

    def test_flat_rows_and_actual_loss_facts(self):
        """固定列順、実現額、要求BBO正益からの実赤字を維持する。

        引数: self(IntegrationTests)は検査器。
        返り値: None。
        """
        position,parts,scene=fixture()
        row,allocations,detail,extra=M.integrate_position(position,parts,scene)
        self.assertEqual(list(row),M.COLUMNS['建玉全体'])
        self.assertTrue(all(list(a)==M.COLUMNS['返済片'] for a in allocations))
        self.assertEqual(row['実現純利益円'],-154)
        self.assertEqual(row['全玉最大W円'],1846)
        self.assertEqual(row['全玉正益後初負円'],-154)
        self.assertEqual(len(extra['要求BBO正益から実返済赤字']),1)
        self.assertEqual(extra['要求BBO正益から実返済赤字'][0]['実現純額円'],-1077)
        summary=M.summarize(position['key'],[position],parts,[row],[extra])
        self.assertEqual(list(summary),M.COLUMNS['候補別集計'])
        self.assertEqual(summary['実数量秒'],3)
        self.assertEqual(summary['実保有時間秒'],2)

    def test_S0_protection_is_not_applicable(self):
        """S0の未起動赤字をH未達と解釈できないnullへ分ける。

        引数: self(IntegrationTests)は検査器。
        返り値: None。
        """
        position,parts,scene=fixture()
        position['policy']='S0'
        position['key']='S0_C0_D0'
        row,allocations,_,extra=M.integrate_position(position,parts,scene)
        self.assertIsNone(row['保護起動前完結赤字'])
        self.assertIsNone(row['起動後赤字'])
        summary=M.summarize(position['key'],[position],parts,[row],[extra])
        self.assertIsNone(summary['保護起動前完結赤字玉数'])
        self.assertIsNone(summary['起動後赤字円'])

    def test_missing_witness_and_wrong_final_value_rejected(self):
        """境界・原行・最終実現額が不整合の集約を拒否する。

        引数: self(IntegrationTests)は検査器。
        返り値: None。
        """
        position,parts,scene=fixture()
        broken=deepcopy(scene)
        broken['witnesses']={}
        with self.assertRaises(ValueError):M.integrate_position(position,parts,broken)
        position['final_net_yen']+=1
        with self.assertRaises(ValueError):M.integrate_position(position,parts,scene)


if __name__=='__main__':
    unittest.main(verbosity=2)
