"""Readerの保有中集約と実約定台帳を、価格未来を足さず純粋に結合する。"""

from copy import deepcopy
from datetime import datetime, timedelta, timezone
from decimal import Decimal


JST=timezone(timedelta(hours=9))


def need(value,label):
    """集約の必須条件を検査する。

    引数: value(bool)は成立条件、label(str)は不成立の理由。
    返り値: None。不成立はValueError。
    """
    if not value:
        raise ValueError(label)


def dec(value):
    """値を十進数の独立算術へ変換する。

    引数: value(number)は価格又は円。
    返り値: Decimalは計算値。
    """
    return Decimal(str(value))


def at(quote):
    """原行を安定順序へ写す。

    引数: quote(dict)はReader又はNativeの原行。
    返り値: tupleはIndex/物理行/時刻。
    """
    return quote['index'],quote['source_line'],dec(quote['time'])


def clock(quote):
    """時刻をCSV向けJST文字列へ変換する。

    引数: quote(dict又はNone)は原行。
    返り値: str又はNoneはJST ISO時刻。
    """
    return datetime.fromtimestamp(float(quote['time']),JST).isoformat() if quote is not None else None


def normal(q):
    """実返済可能な正常BBOを確認する。

    引数: q(dict)は原行。
    返り値: boolはquote_okかつ0<Bid<Ask。
    """
    return q['quote_ok'] and q['bid']>0 and q['ask']>q['bid']


def put_quote(row,prefix,q):
    """CSVの固定原行列へ時刻と価格を入れる。

    引数: row(dict)、prefix(str)、q(dict又はNone)は出力行・列頭・原行。
    返り値: None。列が宣言されたものだけを更新する。
    """
    values={'時刻':clock(q),'Index':q['index'] if q else None,'物理行':q['source_line'] if q else None,
            'Last':q['last'] if q else None,'Bid':q['bid'] if q else None,'Ask':q['ask'] if q else None}
    for suffix,value in values.items():
        if prefix+suffix in row:
            row[prefix+suffix]=value


def put_point(row,prefix,p):
    """到達点をCSVの円と原行列へ入れる。

    引数: row(dict)、prefix(str)、p(dict又はNone)は出力行・列頭・Point。
    返り値: None。
    """
    row[prefix+'円']=p['value'] if p else None
    put_quote(row,prefix,p['quote'] if p else None)


def put_series(row,name,series):
    """Last/Bid/AskのOHLCと同値極値の最初/最後を平坦化する。

    引数: row(dict)、name(str)、series(dict)はCSV行・系列名・Reader集約。
    返り値: None。
    """
    for key,label in [('open','始値'),('high','高値'),('low','安値'),('close','終値')]:
        p=series[key]
        row[name+label]=p['value'] if p else None
        if key in ('high','low'):
            for field,phase in [('first','初回'),('last','最終')]:
                put_quote(row,name+label+phase,p[field] if p else None)
        else:
            put_quote(row,name+label,p['quote'] if p else None)


def merge_extreme(items,high):
    """状態片の極値を、重なる返済原行も含め一つへする。

    引数: items(list[dict])はExtreme群、high(bool)は最大か最小。
    返り値: dict又はNoneは値と最初/最後の原行。未保有の価格を足さない。
    """
    values=[v for v in items if v is not None]
    if not values:
        return None
    value=(max if high else min)(dec(v['value']) for v in values)
    selected=[v for v in values if dec(v['value'])==value]
    return {'value':value,'first':min((v['first'] for v in selected),key=at),
            'last':max((v['last'] for v in selected),key=at)}


def first_point(points):
    """複数片の到達点から最初の実原行を選ぶ。

    引数: points(list[dict又はNone])は保存Point。
    返り値: dict又はNoneは最初のPoint。
    """
    found=[v for v in points if v is not None]
    return min(found,key=lambda v:at(v['quote'])) if found else None


def merge_returns(slices,field):
    """正益経験を次の実残量片へ引き継ぎ、返しの初回を統合する。

    引数: slices(list[dict])は寿命順のReader状態片、field(str)はwhole_returns/unit_returns。
    返り値: dictは初正益と正益後の初非正/負。価格点を全保存しない。
    """
    positive=nonpositive=negative=None
    for s in slices:
        v=s[field]
        seen=positive is not None
        nonpositive=first_point([nonpositive,v['first_nonpositive'] if seen else v['first_nonpositive_after_positive']])
        negative=first_point([negative,v['first_negative'] if seen else v['first_negative_after_positive']])
        positive=first_point([positive,v['first_positive']])
    return {'positive':positive,'nonpositive_after':nonpositive,'negative_after':negative}


def unit_curve(price,side,entry,K):
    """正常返済側の価格極値から1枚費用後益を独立算出する。

    引数: price(dict)、side(int)、entry/K(number)は価格区間・方向・取得価格・往復費用。
    返り値: dictは1枚益のhigh/low。
    """
    series=price['bid' if side==1 else 'ask']
    result={}
    for which,source in [('high','high' if side==1 else 'low'),('low','low' if side==1 else 'high')]:
        point=series[source]
        result[which]=None if point is None else {'value':100*side*(dec(point['value'])-dec(entry))-dec(K),'first':point['first'],'last':point['last']}
    return result


def curves(price,slices,side,entry,K,price_map=None):
    """実保有片だけから全玉W・1枚益・初回到達を統合する。

    引数: price(dict)、slices(list[dict])、side/entry/KはReader価格と状態片・固定金融値、price_map(dict又はNone)は各状態片の価格結果。
    返り値: dictは極値と初回点。利益回収率や退出後値を作らない。
    """
    need(bool(slices),'状態片が必要')
    whole={'high':merge_extreme([s['whole_yen']['high'] for s in slices],True),
           'low':merge_extreme([s['whole_yen']['low'] for s in slices],False)}
    unit=unit_curve(price,side,entry,K)
    thresholds={name:first_point([v['first'] for s in slices for v in s['thresholds'] if v['threshold']['id']==name]) for name in ['positive','H50','H100']}
    last_extremes=[]
    if price_map is not None:
        for state in slices:
            query=state['query']
            value=price_map[query['price_interval_id']]['last']['high' if side==1 else 'low']
            if value is not None:
                last_extremes.append({'value':dec(query['R'])+query['n']*(100*side*(dec(value['value'])-dec(entry))-dec(K)),
                                      'first':value['first'],'last':value['last']})
    return {'whole':whole,'unit':unit,'whole_returns':merge_returns(slices,'whole_returns'),
            'unit_returns':merge_returns(slices,'unit_returns'),'thresholds':thresholds,
            'first':slices[0]['whole_yen']['open'],'last':slices[-1]['whole_yen']['close'],
            'last_apparent_max':merge_extreme(last_extremes,True)}


def put_curves(row,c):
    """極値と初回到達を日本語flat列へ入れる。

    引数: row(dict)、c(dict)は出力行と純集計。
    返り値: None。
    """
    for prefix,point in [('全玉最大W',c['whole']['high']),('全玉最小W',c['whole']['low']),
                         ('1枚最大費用後益',c['unit']['high']),('1枚最小費用後益',c['unit']['low'])]:
        row[prefix+'円']=point['value'] if point else None
        for field,phase in [('first','初回'),('last','最終')]:
            put_quote(row,prefix+phase,point[field] if point else None)
    for prefix,p in [('全玉初正益',c['whole_returns']['positive']),('1枚初正益',c['unit_returns']['positive']),
                     ('全玉正益後初非正',c['whole_returns']['nonpositive_after']),('全玉正益後初負',c['whole_returns']['negative_after']),
                     ('1枚正益後初非正',c['unit_returns']['nonpositive_after']),('1枚正益後初負',c['unit_returns']['negative_after']),
                     ('H50初到達',c['thresholds']['H50']),('H100初到達',c['thresholds']['H100'])]:
        put_point(row,prefix,p)


def native_mtm(position,parts,saved,raw):
    """実返済と位相から、保存点のn/R/u/W/予約を再構成する。

    引数: position(dict)、parts(list[dict])、saved(dict)、raw(dict)は実寿命・返済片・Native点・Raw原行。
    返り値: dictは期待する保存MTM値。Rawの値をNativeへ合わせない。
    """
    phase=saved['phase']
    idx=raw['index']
    done=[p for p in parts if p['exit_quote']['index']<idx or p['exit_quote']['index']==idx and phase=='after_source']
    n=position['q0']-sum(p['quantity'] for p in done)
    R=sum((dec(p['net_yen']) for p in done),Decimal(0))
    fill_by_order={p['order_id']:p for p in parts}
    reserved=0
    for order in position['orders']:
        if order['kind']!='exit':
            continue
        oi=order['request_quote']['index']
        accepted=oi<idx or oi==idx and phase=='after_source' and order['protection_point'] is None
        close=fill_by_order.get(order['id'])
        filled=close is not None and (close['exit_quote']['index']<idx or close['exit_quote']['index']==idx and phase=='after_source')
        if accepted and not filled:
            reserved+=order['quantity']
    mark=raw['bid' if position['side']==1 else 'ask']
    gain=position['side']*(dec(mark)-dec(position['entry_price']))
    unit=100*gain-position['K']
    return {'quantity':n,'reserved':reserved,'mark_price':mark,'gain_points':gain,'unit_net':unit,'realized_net':R,'whole_net':R+n*unit}


def compare_marks(position,parts,c,witnesses):
    """保存marksの原行・値・極値・初回・位相の差を補正せず分類する。

    引数: position/parts/c(dict又はlist)、witnesses(dict)は実台帳・純曲線・Reader原行索引。
    返り値: dictは差件数と各保存点の検査詳細。
    """
    counts={'数値差':0,'原行差':0,'同値到達差':0,'位相候補差':0,'返し初回性未検証':0}
    rows=[]
    expected={'first':c['first'],'last':c['last'],
              'first_whole_positive':c['whole_returns']['positive'],'first_whole_nonpositive_after':c['whole_returns']['nonpositive_after'],
              'first_whole_negative_after':c['whole_returns']['negative_after'],'first_unit_positive':c['unit_returns']['positive'],
              'first_unit_nonpositive_after':c['unit_returns']['nonpositive_after'],'first_unit_negative_after':c['unit_returns']['negative_after']}
    for name,saved in position['marks'].items():
        if name.endswith('_max') or name.endswith('_min'):
            extreme=c['whole' if name.startswith('whole') else 'unit']['high' if name.endswith('max') else 'low']
            target=None if extreme is None else {'value':extreme['value'],'quote':extreme['first']}
        else:
            target=expected.get(name)
        flags=[]
        detail={'mark':name,'saved':saved,'raw_target':target}
        if saved is None or target is None:
            if (saved is None)!=(target is None):
                flags.append('数値差')
                detail['nullable_difference']=True
        if saved is not None:
            key=(saved['quote']['index'],saved['quote']['source_line'])
            need(key in witnesses,'保存markのRaw witness欠落')
            raw=witnesses[key]
            detail['raw_witness']=raw
            quote_differences=[k for k in ['time','index','source_line','last','bid','ask','quote_ok'] if saved['quote'][k]!=raw[k]]
            if quote_differences:
                flags.append('原行差')
                detail['quote_difference_fields']=quote_differences
            if normal(raw):
                mtm=native_mtm(position,parts,saved,raw)
                detail['independent_mtm']=mtm
                differences=[k for k,v in mtm.items() if dec(saved[k])!=dec(v)]
                if differences:
                    flags.append('数値差')
                    detail['mtm_difference_fields']=differences
            else:
                flags.append('数値差')
                detail['invalid_BBO_at_saved_mark']=True
            if target is not None:
                field='unit_net' if name.startswith('unit_') or name.startswith('first_unit') else 'whole_net'
                if dec(saved[field])!=dec(target['value']):
                    flags.append('数値差')
                    detail['curve_value_difference']=True
                elif at(saved['quote'])!=at(target['quote']):
                    flags.append('同値到達差')
                    detail['same_value_different_reach_quote']=True
            possible=['after_source'] if raw['index']==position['entry_quote']['index'] else ['pre_fill'] if raw['index']==position['final_close_quote']['index'] else ['pre_fill','after_source']
            detail['phase_candidates_from_execution_order']=possible
            if saved['phase'] not in possible:
                flags.append('位相候補差')
        detail['differences']=sorted(set(flags))
        for f in set(flags):
            counts[f]+=1
        rows.append(detail)
    return {'counts':counts,'marks':rows,'phase_note':'Raw自体にActor位相はない。実取得/最終返済境界と元の評価順から可能位相を併記し、同じ値でもn/R/phaseを潰さない。'}
