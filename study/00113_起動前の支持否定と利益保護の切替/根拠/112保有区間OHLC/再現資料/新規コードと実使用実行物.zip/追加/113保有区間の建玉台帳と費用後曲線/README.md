# 112実保有区間の台帳と費用後曲線

確認日: 2026-11-10。112完了記録SHA `432fbbaf445a9d00916d927a4b87cb5992500ad585507189a71d499e498e672c` と正本Ref、正式Native70を認証し、24政策費用の成立取引だけを分解する。113の新金融条件は実行しない。

## 成果物

- `112全24と全70の区間/建玉全体の台帳.jsonl.gz`：全13,332玉。実q0・Entry/FinalClose・全partialへの参照・実注文・Source通知理由・既存marks/activationを保持する。
- `返済片の台帳.jsonl.gz`：全14,908 allocation。実数量が取得から当返済まで保有された寿命、実現額、R/n前後、要求から約定までの秒・Index・物理行、費用を保持する。
- `Reader入力の素材.json`：重複排除した価格1,952区間と金融3,887 query。Root固定前なので `fixed=false, raw_read_authorized=false`。Raw位置/既指紋はmanifest metadataから写すだけで、Rawのstat/hash/openを行わない。
- `台帳の確認.json`：独立正本25,560値の一致、全返済前後W保存則、全入力前後不変と成果物Ref。

## Readerとの契約

`price_intervals[]` は `{price_interval_id,session,start_quote,end_quote,start_inclusive:true,end_inclusive:true}`。QuoteはNativeのtime/index/source_line/last/bid/ask/quote_okを原値で保持する。Entry/Closeの原行を含み、返済後へ区間を延長しない。

`state_slices[]` は `{query_id,price_interval_id,side,entry_price,n,R,K,q0,thresholds}`。各sliceの実n/Rは一定、`n>0`、K=77+200×片道滑りpt。費用後全玉曲線は `W=R+n*(100*side*(返済側BBO-entry_price)-K)`。買いはBid、売りはAsk、正常条件はquote_okかつ有限の0<Bid<Ask。Last OHLCとは別に扱う。

閾値は正益 `W>0`、H50 `W>=q0*5000`、H100 `W>=q0*10000`。建玉sliceのq0は実初期枚数で固定し、nだけが返済で減る。返済片の寿命queryはn=q0=実返済枚、R=0とし、その実在部分の値動きを評価する。返済片Hと建玉全体Hは分けて表示する。

Partial close原行を前後のsliceに含む。実配賦は `ΔR=返済枚数×(100g-K)` なので、同BBOの `R+n*u` は返済前後で等しい。全14,908片で検査した。n=0のRaw queryは不要で、最終close前Wが実現純額に一致する。初期q0を最終返済まで仮想維持しない。

## 保存marksとの比較

RawReaderは保存marksを期待値として読まない。別途、whole/unitのmax/min、first/last、first_positive、正益後nonpositive/negativeの保存点を、数値・Time/Index/Line・phaseに分けて照合する。値差、原行差、phase差、同値極値のfirst/last差、初回の定義差は補正せず差分類を残す。全Raw点を保存せず、極値・初回閾値・必要witnessだけを受ける。

SourceHold、実要求、部分返済と最終返済、要求から約定のGapは台帳に残す。未参加・退出後価格・機会損失・MFE回収率・ROIは対象外。Last高値の見かけ利益を正常BBOでの返済可能利益と混ぜない。

## 再現

Python標準ライブラリのみ。固定入口結合code `113入口枝と保護起動前損失の診断/診断する.py` をSHA認証して再用する。

```powershell
python -X utf8 'work/113保有区間の建玉台帳と費用後曲線/人工検査.py'
python -X utf8 'work/113保有区間の建玉台帳と費用後曲線/台帳を作る.py' --output '<未作成の絶対出力先>'
```

CSV3点（建玉全体OHLC・返済片OHLC・候補別の損失原因/整合集計）はRootが生成する。ReaderのRaw実走査はRoot固定要求を待つ。現段階の台帳生成ではRaw開封/stat/hash、11/09本文、市場再生、CSV生成は全て0。
