"""Raw未読の台帳生成コードと実台帳Refを固定する。"""

import hashlib
import importlib.util
import json
import subprocess
import sys
from pathlib import Path


HERE=Path(__file__).resolve().parent
SPEC=importlib.util.spec_from_file_location('interval113',HERE/'台帳を作る.py')
B=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(B)


def main():
    """手製人工と112全台帳の入力不変を認証して停止する。

    引数: なし。
    返り値: dictは台帳準備の停止Ref。Raw Readerは実行しない。
    """
    target=HERE/'台帳準備の停止.json'
    B.D.need(not target.exists(),'停止は新規保存')
    names=['台帳を作る.py','人工検査.py','README.md','台帳を検査して停止する.py']
    owned={str(HERE/n):B.D.sha(HERE/n) for n in names}
    proof_path=HERE/'112全24と全70の区間/台帳の確認.json'
    B.D.need(B.D.sha(proof_path)=='783495d570779c9fd34b0d1a76e9d4045faf683a491c10e7f6f8e123990e3744','全台帳確認の指紋')
    proof=B.D.load(proof_path)
    B.D.need(proof['作成コード']['sha256']==owned[str(HERE/'台帳を作る.py')],'実使用台帳code一致')
    B.D.need(proof['入力SHA256前']==proof['入力SHA256後']=={p:B.D.sha(Path(p)) for p in proof['入力SHA256前']},'全正本/Native/code不変')
    for ref in proof['成果物'].values():
        B.D.bind(ref,{})
    p=subprocess.run([sys.executable,'-X','utf8',str(HERE/'人工検査.py')],cwd=HERE,capture_output=True,text=True,encoding='utf-8',timeout=60)
    B.D.need(p.returncode==0 and 'Ran 3 tests' in p.stderr,'手製人工成功')
    (HERE/'人工検査.txt').write_text(p.stdout+p.stderr,encoding='utf-8')
    B.D.need(owned=={p:B.D.sha(Path(p)) for p in owned},'所有前後不変')
    stop={'試行':113,'成功':True,'準備':'112保存台帳からの実寿命生成。Raw実走査前。','所有ファイルSHA256':owned,
          '台帳確認':{'path':str(proof_path),'sha256':B.D.sha(proof_path)},'成果物':proof['成果物'],
          '人工主数':3,'建玉行数':proof['建玉行数'],'返済片行数':proof['返済片行数'],
          '価格区間数':proof['価格区間数'],'金融state query数':proof['金融state query数'],
          '独立正本数値比較数':proof['独立正本数値比較数'],'全返済前後W同体':True,'入力と所有前後不変':True,
          'Raw開封':0,'Raw hash':0,'Raw stat':0,'市場再生':False,'11月09本文':0,'CSV生成':False,
          '旧固定編集':0,'研究目標達成':False,'採用':False}
    target.write_text(B.D.encode(stop),encoding='utf-8')
    return {'停止':{'path':str(target),'sha256':B.D.sha(target)},'成功':True}


if __name__=='__main__':
    print(B.D.encode(main()))
