"""保存marksと要求の原行キーだけを重複排除し、Raw値の期待を含まないwitness素材を作る。"""

import gzip
import hashlib
import json
from pathlib import Path


HERE=Path(__file__).resolve().parent
LEDGER=HERE/'112全24と全70の区間/台帳の確認.json'
SHA='783495d570779c9fd34b0d1a76e9d4045faf683a491c10e7f6f8e123990e3744'


def digest(path):
    """小台帳の指紋を計算する。

    引数: path(Path)は台帳又はコード。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run():
    """112実保存点の原行キーをReaderの補助素材へする。

    引数: なし。認証済みNative派生台帳を入力とする。
    返り値: dictは原行要求数と新規Ref。Rawは開かない。
    """
    if digest(LEDGER)!=SHA:
        raise ValueError('台帳確認SHA差')
    proof=json.loads(LEDGER.read_bytes())
    target=HERE/'保存点witnessのReader要求素材.json'
    if target.exists():
        raise ValueError('原行要求は新規保存')
    rows={}
    def add(session,quote,role):
        """原行キーだけを重複排除する。

        引数: session(str)、quote(dict又はNone)、role(str)は保存点の出典。
        返り値: None。価格や利益をReader期待値へ渡さない。
        """
        if quote is None:
            return
        key={'session':session,**{k:quote[k] for k in ['time','index','source_line']}}
        raw=json.dumps(key,sort_keys=True,separators=(',',':')).encode('utf-8')
        wid='witness_'+hashlib.sha256(raw).hexdigest()
        if wid not in rows:
            rows[wid]={'witness_id':wid,**key,'roles':{}}
        rows[wid]['roles'][role]=rows[wid]['roles'].get(role,0)+1
    inputs={str(LEDGER):SHA}
    for name in ['建玉全体の台帳.jsonl.gz','返済片の台帳.jsonl.gz']:
        ref=proof['成果物'][name]
        p=Path(ref['path'])
        if digest(p)!=ref['sha256']:
            raise ValueError('圧縮台帳SHA差')
        inputs[str(p)]=ref['sha256']
        with gzip.open(p,'rt',encoding='utf-8') as stream:
            for line in stream:
                v=json.loads(line)
                add(v['session'],v['entry_quote'],'entry')
                if v['kind']=='position':
                    add(v['session'],v['final_close_quote'],'final_close')
                    add(v['session'],v['source']['birth_quote'],'source_birth')
                    for label,point in v['marks'].items():
                        if point is not None:
                            add(v['session'],point['quote'],'mark/'+label)
                    for label in ['activation','floor_updated','first_floor_hit']:
                        if v[label] is not None:
                            add(v['session'],v[label]['quote'],label)
                    for order in v['orders']:
                        add(v['session'],order['request_quote'],'request/'+order['kind'])
                    for event in v['source_exit_notices']:
                        add(v['session'],event['quote'],'source_close_notice')
                else:
                    add(v['session'],v['exit_quote'],'allocation_close')
    if inputs!={p:digest(Path(p)) for p in inputs}:
        raise ValueError('入力前後差')
    value={'version':1,'trial':113,'source_trial':112,'fixed':False,'raw_read_authorized':False,
           'witnesses':[{k:v[k] for k in ['witness_id','session','index','source_line']} for v in sorted(rows.values(),key=lambda v:(v['session'],v['index'],v['source_line']))],
           'ledger_check':{'path':str(LEDGER),'sha256':SHA},'input_sha256':inputs,
           'expectation':'index/source_lineの原行キーだけ。time/価格/損益/正常判定の期待値は渡さない。',
           'Raw開封':0,'11月09本文':0,'コード':{'path':str(Path(__file__).resolve()),'sha256':digest(Path(__file__))}}
    target.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return {'成功':True,'原行要求数':len(rows),'Ref':{'path':str(target),'sha256':digest(target)}}


if __name__=='__main__':
    print(json.dumps(run(),ensure_ascii=False))
