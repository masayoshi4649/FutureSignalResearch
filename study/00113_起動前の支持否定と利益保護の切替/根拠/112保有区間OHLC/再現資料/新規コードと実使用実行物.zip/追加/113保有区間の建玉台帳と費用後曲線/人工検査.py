"""部分返済のW保存則と寿命/曲線queryの重複排除を手製値で検査する。"""

from copy import deepcopy
from decimal import Decimal
import importlib.util
from pathlib import Path
import unittest


SPEC=importlib.util.spec_from_file_location('interval113',Path(__file__).with_name('台帳を作る.py'))
B=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(B)


def fixture(side=1, slip=0):
    """2枚を1枚ずつ返す実型の小さな台帳を組み立てる。

    引数: side(int)は方向、slip(int)は0/5pt。
    返り値: tupleは場、口座、Position、Sourceタグ索引。
    """
    def q(index, bid):
        """手製の正常原行を作る。

        引数: index(int)は時刻兼原行、bid(int)は買気配。
        返り値: dictはQuoteStamp。
        """
        return {'time':index,'index':index,'source_line':index+1,'last':bid+5,'bid':bid,'ask':bid+10,'quote_ok':True}
    sid='2026-10-01_Day'
    birth,entry=q(1,990),q(2,990)
    source={'method':'NK225_D164_15','signal_id':'s1','kind':'initial','parent':'core/0','source_id':'源1','quantity_micro':20,'birth_quantity':2,'birth_time':1,'birth_quote':birth}
    evidence={k:source[k] for k in ['method','kind','parent','source_id','quantity_micro']}
    signal={'id':'s1','action':'new','side':side,'owner':'core','time':1,'campaign':0,'evidence':evidence}
    hold={'hold_id':'h1','entry_id':'s1','initial_quantity':2,'quantity':0,'closed_quantity':2,'entry_price':1000,'entry_quote':entry,'kind':'initial','parent':'core/0','source_id':'源1','side':side}
    native={'source':{'session':{'id':sid},'sources':{'mini':{'method':'NK225_D164_15','session':{'id':sid},'config':{'product':'NK225mini'},'holds':[hold],'signals':[{'signal':signal,'at':1,'quote':birth}]}}}}
    orders=[]
    for i in range(3):
        orders.append({'id':f'o{i}','kind':'entry' if i==0 else 'exit','side':side if i==0 else -side,'quantity':2 if i==0 else 1,
                       'position_id':'p1','source':source,'request_time':1 if i==0 else i+1,'request_quote':birth if i==0 else q(i+1,990),
                       'reason':'手製実返済','status':'filled','fill_id':f'f{i}','native_close_signal_id':'','native_close_notice_id':'',
                       'cancel_time':None,'cancel_reason':'','protection_point':None})
    fills=[{'id':'f0','order_id':'o0','position_id':'p1','action':'new','side':side,'quantity':2,'quote':entry,'source':source,'source_hold_id':'h1'}]
    total=Decimal(0)
    for i,price in enumerate([1010,990],1):
        if side<0: price=2000-price
        exit=q(i+2,price if side==1 else price-10)
        net=100*side*(price-1000)-77-200*slip
        a={'position_id':'p1','source_hold_id':'h1','quantity':1,'net_yen':net,'gross_yen':100*side*(price-1000),
           'entry_fee_yen':Decimal('38.5'),'exit_fee_yen':Decimal('38.5'),'entry_slip_yen':100*slip,'exit_slip_yen':100*slip}
        fills.append({'id':f'f{i}','order_id':f'o{i}','position_id':'p1','action':'close','side':-side,'quantity':1,'price':price,'quote':exit,'source':source,'source_hold_id':'h1',
                      'native_close_signal_id':'','native_close_notice_id':'','reason':'手製実返済','allocations':[a]})
        total+=net
    p={'id':'p1','entry_order_id':'o0','source':source,'source_hold_id':'h1','side':side,'initial_quantity':2,'quantity':0,'reserved':0,'closed_quantity':2,
       'entry_price':1000,'entry_quote':entry,'closed_quote':fills[-1]['quote'],'realized_net':total,'gross_yen':0,'protection_active':False,'activation':None,
       'floor_gain':None,'floor_updated':None,'first_floor_hit':None,'marks':{'first_whole_positive':None}}
    book={'key':f'P100_C{slip}_D0','config':{'policy':'P100','slip_pts':slip,'delay_seconds':0},'orders':orders,'fills':fills,'source_events':[]}
    return sid,book,p,B.D.entry_tags(native)


class IntervalTests(unittest.TestCase):
    """市場を使わない実数量と費用の境界検査。"""

    def test_partial_conservation_and_mirror(self):
        """買売と費用条件で部分返済前後Wと最終配賦額を照合する。

        引数: self(IntervalTests)は検査器。
        返り値: None。
        """
        for side in [1,-1]:
            for slip in [0,5]:
                sid,book,p,tags=fixture(side,slip)
                intervals,queries={},{}
                row,parts,stat=B.make_position(sid,book['key'],p,book,tags,intervals,queries)
                self.assertEqual(row['final_net_yen'],-154-400*slip)
                self.assertEqual(len(parts),2)
                self.assertEqual(len(intervals),3)
                self.assertEqual(len(queries),4)
                self.assertEqual([v['n_before'] for v in parts],[2,1])
                for part in parts: self.assertEqual(part['W_before_close'],part['W_after_close'])
                self.assertEqual(parts[-1]['R_after'],row['final_net_yen'])
                self.assertTrue(all(q['n']>0 for q in queries.values()))

    def test_duplicate_and_lifespan_boundary(self):
        """同じ原行価格区間と金融queryを重複計算させない。

        引数: self(IntervalTests)は検査器。
        返り値: None。
        """
        sid,book,p,tags=fixture()
        intervals,queries={},{}
        left,parts,_=B.make_position(sid,book['key'],p,book,tags,intervals,queries)
        B.make_position(sid,book['key'],p,book,tags,intervals,queries)
        self.assertEqual((len(intervals),len(queries)),(3,4))
        self.assertEqual(intervals[parts[0]['price_interval_id']]['end_quote'],parts[0]['exit_quote'])
        self.assertLess(parts[0]['exit_quote']['index'],left['final_close_quote']['index'])

    def test_net_corruption_rejected(self):
        """初期枚数の仮想維持や費用配賦の不整合を拒否する。

        引数: self(IntervalTests)は検査器。
        返り値: None。
        """
        sid,book,p,tags=fixture()
        book['fills'][-1]['allocations'][0]['net_yen']+=1
        with self.assertRaises(ValueError): B.make_position(sid,book['key'],p,book,tags,{}, {})
        with self.assertRaises(ValueError): B.state_slice({},'dummy',1,1000,3,0,77,2)


if __name__=='__main__':
    unittest.main(verbosity=2)
