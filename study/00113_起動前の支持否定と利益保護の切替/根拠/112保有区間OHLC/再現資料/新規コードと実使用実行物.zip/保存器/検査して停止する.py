"""手製検査と所有コード前後不変を確認し、正式保存器だけを停止する。"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys


HERE = Path(__file__).resolve().parent
OWNED = ("保存する.py", "人工検査.py", "検査して停止する.py", "README.md")


def hashes() -> dict[str, str]:
    """
    機能: 所有4ファイルの現物SHA256を作る。
    引数: なし。
    返り値: dict[str,str]の絶対パスからSHAへの対応。
    """
    return {str(HERE / name): hashlib.sha256((HERE / name).read_bytes()).hexdigest() for name in OWNED}


def main() -> None:
    """
    機能: 手製だけの検査を起動し新規停止JSONとログを保存する。
    引数: CLI引数なし。
    返り値: None。失敗時は非0終了。
    """
    stop_path = HERE / "停止.json"
    if stop_path.exists():
        raise ValueError("停止は新規only")
    before = hashes()
    run = subprocess.run([sys.executable, "-X", "utf8", str(HERE / "人工検査.py")], cwd=HERE, capture_output=True, text=True, encoding="utf-8")
    log = run.stdout + run.stderr
    log_path = HERE / "人工検査.log"
    with log_path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(log)
    if run.returncode != 0:
        raise RuntimeError(log)
    after = hashes()
    if before != after:
        raise ValueError("所有コードが検査前後で変化")
    match = re.search(r"Ran (\d+) tests", log)
    if not match or int(match[1]) != 6:
        raise ValueError("主人工6件の成功記録がない")
    result = {"成功": True, "停止": True, "trial": 113, "source_trial": 112, "所有コードSHA256": before, "前SHA256": before, "後SHA256": after, "前後不変": True, "主人工": 6, "副人工": 12, "人工ログ": {"path": str(log_path), "sha256": hashlib.sha256(log_path.read_bytes()).hexdigest()}, "Raw本文読取": 0, "市場Native本文読取": 0, "実Reader結果本文読取": 0, "旧正式本文変更": False, "正式保存実行": False, "113金融再実行": False}
    with stop_path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"停止": {"path": str(stop_path), "sha256": hashlib.sha256(stop_path.read_bytes()).hexdigest()}, "主人工": 6}, ensure_ascii=False))


if __name__ == "__main__":
    main()
