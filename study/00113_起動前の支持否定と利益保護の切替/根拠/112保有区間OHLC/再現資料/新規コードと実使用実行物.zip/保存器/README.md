# 112の実保有区間OHLCを113の根拠として保存する

この派生版は旧停止 `7d620cc03437f16f91c4af5aeb469884b9d5dd8a17c0e1044e8221c8b4097e71` を保持し、FileRefのoptional `bytes` を非負整数として受ける変更だけを保存本体へ加えた。参照の同体は解決済み絶対パスとSHA256で判定し、付加bytesは同体のキーにしない。未定義キー・bool/負数/小数/文字列/nullのbytesは拒否する。対象範囲・CSV/Raw/金融・容量方針は変えない。

Rootが固定した新規要求だけから、`study/00113_起動前の支持否定と利益保護の切替/根拠/112保有区間OHLC` を新規作成する。旧112・111は編集せず、Raw・市場Native・価格CSV本文を読まない。RootのReader全70場成功の結果は保存するが、113金融の実行完了・研究目標達成・採用を表さない。

## 保存するもの

- `Reader結果.tar.gz`：70場のReader JSONを再直列化せず元bytesで格納。`Reader元JSON索引.json` に場順、元FileRef・SHA・bytes・entry名を残し、展開再読で全entryを照合する。Raw本文は格納しない。
- `再現資料/新規コードと実使用実行物.zip`：停止済みReaderの所有10ファイルと実exe、保存器の所有4ファイル、およびRootの `code_refs` で明示した新113のownedだけ。旧Source672ファイル・GoRoot・既正式ZIPを再複写しない。
- `再現資料/コード所在索引.json`：新ZIPのentryと元FileRef、既正式111/112の所在索引・ZIP参照。旧ZIP本文の再hashはせず、既正式の成功した小さい所在索引をSHA認証して参照する。
- `検査/`：保存のRoot要求、保存器停止、Reader完了・固定要求・停止、台帳停止接続、query・保存点要求・入力台帳。Rootの `extra_refs` で指定した統合gz・診断・独立監査も同bytes保存できる。
- `CSV正本の所在.json`：Rootの3点のCSVをSHA認証し参照する。CSV内容を解釈・複写・再生成しない。
- `検査/正式保存の確認.json`：出力Ref、全Reader元SHA・ZIP CRC/集合/元SHAの照合、読み取った入力/codeの前後SHA一致。失敗時は `正式保存の不完了.json` を残し成功化しない。

到達時計はCurrentPriceTimeで実受信時計は不明、Lastと正常返済側BBOは別、同時計でも物理原行を境界とする。保有後の仮想値・機会損失は作らない。H50到達は実保有中の観測であり、未実行P50の収益ではない。これらはReaderの根拠を保存する範囲であり、ここで金融計算を追加しない。

## Root固定要求

`固定要求のひな形.json` はfixed=falseの素材。Rootが全Refと出力先を検査し、別名の新要求をfixed=trueで固定してから実行する。

```text
version=1,trial=113,source_trial=112,
fixed=true,reader_result_read_authorized=true,
policy=holding_ohlc112_evidence_save_v1,
target_directory=上記の正式先絶対パス,
saver_stop:FileRef,reader_completion:FileRef,
prior_formal_indexes:{"111":FileRef,"112":FileRef},
code_refs:[{archive_path:安全な相対名,ref:FileRef}],
extra_refs:[{target:安全な相対先,ref:FileRef}],
csv_refs:{任意の名:FileRef, ...3点}
```

追加資料のtargetは `集計/`・`診断/`・`検査/追加/` のいずれかとし、`.json/.gz/.md/.txt`だけを受ける。追加元は本リポジトリwork/113…内だけ、Native/Raw/CSVを指定しない。追加codeはwork/113…の明示ファイルと実exeだけ。追加したい停止/診断のmetadataはextra_refsへ置く。Root所見はRootが正式保存後に別途置くためpack器へ指定しない。

```powershell
python -X utf8 'work/113保有区間OHLCの正式保存_参照同体/保存する.py' --fixed '<Root新固定要求の絶対パス>' --sha256 '<SHA>' --metadata-only
python -X utf8 'work/113保有区間OHLCの正式保存_参照同体/保存する.py' --fixed '<同じ絶対パス>' --sha256 '<同じSHA>'
```

metadata-onlyもReader結果と保存予定資料のSHA/JSON認証を行うが、出力を作らない。原板や市場Nativeの読取は行わない。実保存は新規先だけで、途中先への再開・上書きをしない。

## 手製検査と停止

`python -X utf8 work/113保有区間OHLCの正式保存_参照同体/人工検査.py` は一時ディレクトリの手製70場を使う。Rawと旧ZIPを存在させず、元bytes・決定的bundle・前後不変・新規先拒否・不正SHA/未固定/場重複/名前遡及/旧code混入・後変化の不完了を確認する。実市場結果・実Rawは読まない。追加人工でbytes付き/無しおよびslash表記の同体、bytes型の反例、条件側だけbytesを付けた全70保存計画を確認する。

`検査して停止する.py` は所有4ファイルの前後SHAと主人工6件・副人工12件を記録する。停止後は同4ファイルを変更しない。Rootが正式保存を実行する。
