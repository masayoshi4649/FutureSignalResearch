"""手製の70場metadataだけで正式保存器を検査する。Raw/実結果は読まない。"""

from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import tempfile
import unittest


HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("ohlc_save", HERE / "保存する.py")
assert SPEC and SPEC.loader
SAVER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SAVER)


def fixture(root: Path) -> tuple[dict, Path]:
    """
    機能: Rawが存在しない手製70場の認証可能な保存要求を作る。
    引数: root(Path)は一時リポジトリ根。
    返り値: tuple[dict,Path]の要求FileRefと出力先。
    """
    work = root / "work/113人工"
    work.mkdir(parents=True)
    own = root / "work/113人工保存器"
    own.mkdir()
    SAVER.SELF = own.resolve()
    own_map = {}
    for name in SAVER.OWNED:
        path = own / name
        path.write_text("手製の所有コード\n", encoding="utf-8")
        own_map[str(path.resolve())] = SAVER.file_sha(path)
    saver_stop = work / "保存器停止.json"
    SAVER.write_json(saver_stop, {"成功": True, "停止": True, "所有コードSHA256": own_map})
    reader = root / "work/113人工Reader"
    reader.mkdir()
    reader_code = reader / "reader.go"
    reader_code.write_text("package 手製\n", encoding="utf-8")
    executable = reader / "手製.exe"
    executable.write_bytes(b"artificial-only")
    reader_stop = reader / "停止.json"
    SAVER.write_json(reader_stop, {"成功": True, "停止": True, "所有コードSHA256": {str(reader_code.resolve()): SAVER.file_sha(reader_code)}, "実行物": SAVER.reference(executable)})
    ledger_stop = work / "台帳停止.json"
    SAVER.write_json(ledger_stop, {"成功": True, "停止": True})
    sessions = [f"2026-{9 + i // 28:02}-{i % 28 + 1:02}_Day" for i in range(70)]
    intervals = [{"price_interval_id": "p" + str(i), "session": s} for i, s in enumerate(sessions)]
    state_slices = [{"query_id": "q" + str(i), "price_interval_id": "p" + str(i)} for i in range(70)]
    queries = work / "queries.json"
    SAVER.write_json(queries, {"price_intervals": intervals, "state_slices": state_slices})
    witnesses = work / "witnesses.json"
    SAVER.write_json(witnesses, {"witnesses": [{"witness_id": "w" + str(i), "session": s} for i, s in enumerate(sessions)]})
    manifest = work / "manifest.json"
    SAVER.write_json(manifest, {"sessions": [{"id": s} for s in sessions], "raw_body_not_available": True})
    condition = work / "condition.json"
    SAVER.write_json(condition, {"version": 1, "trial": 113, "source_trial": 112, "fixed": True, "raw_read_authorized": True, "policy": "holding_interval_ohlc112_v1", "sessions": sessions, "reader_stop": SAVER.reference(reader_stop), "ledger_stop": SAVER.reference(ledger_stop), "executable": SAVER.reference(executable), "queries": SAVER.reference(queries), "witness_requests": SAVER.reference(witnesses), "manifest": SAVER.reference(manifest)})
    results = []
    for i, session in enumerate(sessions):
        path = work / (session + ".ohlc.json")
        SAVER.write_json(path, {"version": 1, "trial": 113, "source_trial": 112, "success": True, "session": session, "raw": {"path": str(root / "DOES_NOT_EXIST/book.jsonl.gz"), "sha256": "0" * 64}, "actual_sha256": "0" * 64, "stat_before": {"bytes": 1}, "stat_after": {"bytes": 1}, "raw_passes": 1, "payload_cumulative_high_low_used": False, "price_intervals": {"p" + str(i): {"start_matched": True, "end_matched": True}}, "state_queries": {"q" + str(i): {}}, "witnesses": {"w" + str(i): {"found": True, "index_matched": True}}})
        results.append({"session": session, "result": SAVER.reference(path), "price_intervals": 1, "state_queries": 1, "witnesses": 1})
    complete = work / "complete.json"
    SAVER.write_json(complete, {"version": 1, "trial": 113, "source_trial": 112, "success": True, "sessions": 70, "raw_passes": 70, "financial_replay": False, "unchanged": True, "before": {"手製": "a"}, "after": {"手製": "a"}, "condition": SAVER.reference(condition), "queries": SAVER.reference(queries), "witness_requests": SAVER.reference(witnesses), "manifest": SAVER.reference(manifest), "results": results})
    prior = {}
    for trial in (111, 112):
        index = work / f"prior{trial}.json"
        SAVER.write_json(index, {"成功": True, "試行": trial, "ZIP": {"path": str(root / f"DOES_NOT_EXIST/{trial}.zip"), "sha256": "1" * 64}})
        prior[str(trial)] = SAVER.reference(index)
    csvs = {}
    for i in range(3):
        csv = work / f"手製{i}.csv"
        csv.write_bytes(b"not parsed or copied\n")
        csvs[str(i)] = SAVER.reference(csv)
    extra = work / "統合集計.json.gz"
    extra.write_bytes(b"artificial-compressed-metadata")
    request = work / "fixed.json"
    target = root / SAVER.TARGET
    SAVER.write_json(request, {"version": 1, "trial": 113, "source_trial": 112, "fixed": True, "reader_result_read_authorized": True, "policy": SAVER.POLICY, "target_directory": str(target.resolve()), "saver_stop": SAVER.reference(saver_stop), "reader_completion": SAVER.reference(complete), "prior_formal_indexes": prior, "code_refs": [], "extra_refs": [{"target": "集計/手製.json.gz", "ref": SAVER.reference(extra)}], "csv_refs": csvs})
    return SAVER.reference(request), target


def edit_json(ref: dict, change) -> dict:
    """
    機能: 人工JSONを変更し新SHAへ揃える。
    引数: ref(dict)は参照、change(Callable)は手製変更関数。
    返り値: dictの変更後FileRef。
    """
    path = Path(ref["path"])
    value = json.loads(path.read_text(encoding="utf-8"))
    change(value)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return SAVER.reference(path)


class 保存人工(unittest.TestCase):
    """新規only、前後不変、元bytes、参照だけの旧資料を手製で確認する。"""

    def setUp(self) -> None:
        """
        機能: 各人工で独立一時根を作る。
        引数: self(保存人工)は人工状態。
        返り値: None。
        """
        self.original_self = SAVER.SELF
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.request, self.target = fixture(self.root)

    def tearDown(self) -> None:
        """
        機能: 一時人工だけを片付け実保存器定数を返す。
        引数: self(保存人工)は人工状態。
        返り値: None。
        """
        SAVER.SELF = self.original_self
        self.temp.cleanup()

    def test_保存と元bytes参照(self) -> None:
        """
        機能: Raw/旧ZIP無しで全70元bytesと小ZIP/CSV参照を保存する。
        引数: self(保存人工)は人工状態。
        返り値: None。
        """
        plan = SAVER.prepare(self.request, self.root)
        self.assertFalse(self.target.exists())
        result = SAVER.save(plan)
        self.assertTrue(result["success"])
        self.assertEqual(result["reader_sessions"], 70)
        self.assertEqual(result["before"], result["after"])
        self.assertFalse(result["trial113_financial_complete"])
        self.assertFalse(any(p.suffix == ".csv" for p in self.target.rglob("*")))
        self.assertFalse(any(p.name == "book.jsonl.gz" for p in self.target.rglob("*")))
        with self.assertRaisesRegex(ValueError, "新規only"):
            SAVER.prepare(self.request, self.root)

    def test_二つのbundle決定性(self) -> None:
        """
        機能: 同じ元bytesからtar.gz/ZIPが同じbytesになることを確認する。
        引数: self(保存人工)は人工状態。
        返り値: None。
        """
        plan = SAVER.prepare(self.request, self.root)
        for i in range(2):
            SAVER.write_reader_bundle(self.root / f"r{i}.tar.gz", plan["scenes"])
            SAVER.write_code_bundle(self.root / f"c{i}.zip", plan["codes"])
        self.assertEqual((self.root / "r0.tar.gz").read_bytes(), (self.root / "r1.tar.gz").read_bytes())
        self.assertEqual((self.root / "c0.zip").read_bytes(), (self.root / "c1.zip").read_bytes())

    def test_不正要求を拒否(self) -> None:
        """
        機能: SHA、場重複、未完了、名前遡及、旧code、CSV複写を拒否する。
        引数: self(保存人工)は人工状態。
        返り値: None。
        """
        original = Path(self.request["path"]).read_bytes()
        old_code = self.root / "work/111旧/旧.py"
        old_code.parent.mkdir()
        old_code.write_bytes(b"old-code-must-not-be-copied")
        changes = [lambda v: v.update(fixed=False), lambda v: v.update(target_directory=str(self.root / "別先")), lambda v: v["extra_refs"][0].update(target="集計/../遡及.json"), lambda v: v.update(csv_refs={}), lambda v: v.update(code_refs=[{"archive_path": "禁止.json", "ref": v["reader_completion"]}]), lambda v: v.update(code_refs=[{"archive_path": "旧.py", "ref": SAVER.reference(old_code)}]), lambda v: v.update(extra_refs=[{"target": "診断/CSV.json", "ref": v["csv_refs"]["0"]}])]
        for i, change in enumerate(changes):
            with self.subTest(case=i):
                Path(self.request["path"]).write_bytes(original)
                changed = edit_json(self.request, change)
                with self.assertRaises(ValueError):
                    SAVER.prepare(changed, self.root)
        Path(self.request["path"]).write_bytes(original)
        with self.assertRaisesRegex(ValueError, "SHA不一致"):
            SAVER.prepare(dict(self.request, sha256="f" * 64), self.root)

    def test_未成功と場重複を拒否(self) -> None:
        """
        機能: 成功偽と70行の重複を拒否し、出力を作らない。
        引数: self(保存人工)は人工状態。
        返り値: None。
        """
        value = json.loads(Path(self.request["path"]).read_text(encoding="utf-8"))
        cref = value["reader_completion"]
        initial = Path(cref["path"]).read_bytes()
        for change in (lambda v: v.update(success=False), lambda v: v["results"][1].update(session=v["results"][0]["session"])):
            Path(cref["path"]).write_bytes(initial)
            edited = edit_json(cref, change)
            current = edit_json(self.request, lambda v: v.update(reader_completion=edited))
            with self.assertRaises(ValueError):
                SAVER.prepare(current, self.root)
            self.assertFalse(self.target.exists())

    def test_後変化は不完了(self) -> None:
        """
        機能: 認証後の入力変化を成功にせず不完了を残す。
        引数: self(保存人工)は人工状態。
        返り値: None。
        """
        plan = SAVER.prepare(self.request, self.root)
        first = Path(plan["scenes"][0]["source"]["path"])
        first.write_bytes(first.read_bytes() + b" ")
        with self.assertRaises(ValueError):
            SAVER.save(plan)
        self.assertTrue((self.target / "検査/正式保存の不完了.json").exists())
        self.assertFalse((self.target / "検査/正式保存の確認.json").exists())

    def test_付加bytesと参照同体(self) -> None:
        """
        機能: optional bytesを型検査し、bytes有無とslash表記によらず同じ絶対パス/SHAを照合する。
        引数: self(保存人工)は人工状態。
        返り値: None。
        """
        with_bytes = dict(self.request, bytes=Path(self.request["path"]).stat().st_size)
        self.assertEqual(SAVER.normalize_ref(self.request), SAVER.normalize_ref(with_bytes))
        self.assertTrue(SAVER.same_ref(self.request, dict(with_bytes, path=Path(self.request["path"]).as_posix())))
        for bad in (True, -1, 1.5, "1", None):
            with self.subTest(bytes=bad):
                with self.assertRaises(ValueError):
                    SAVER.normalize_ref(dict(self.request, bytes=bad))
        with self.assertRaises(ValueError):
            SAVER.normalize_ref(dict(with_bytes, 未定義=True))
        request = json.loads(Path(self.request["path"]).read_text(encoding="utf-8"))
        complete = json.loads(Path(request["reader_completion"]["path"]).read_text(encoding="utf-8"))
        condition_ref = complete["condition"]
        condition = json.loads(Path(condition_ref["path"]).read_text(encoding="utf-8"))
        size = Path(condition["queries"]["path"]).stat().st_size
        changed_condition = edit_json(condition_ref, lambda v: v["queries"].update(bytes=size))
        changed_complete = edit_json(request["reader_completion"], lambda v: v.update(condition=changed_condition))
        changed_request = edit_json(self.request, lambda v: v.update(reader_completion=changed_complete))
        plan = SAVER.prepare(changed_request, self.root)
        self.assertEqual(len(plan["scenes"]), 70)


if __name__ == "__main__":
    unittest.main(verbosity=2)
