"""112の実保有区間OHLCの根拠だけを、新規の正式保存先へ保存する。"""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import tarfile
from typing import Any
import zipfile


POLICY = "holding_ohlc112_evidence_save_v1"
TARGET = Path("study/00113_起動前の支持否定と利益保護の切替/根拠/112保有区間OHLC")
SELF = Path(__file__).resolve().parent
OWNED = ("保存する.py", "人工検査.py", "検査して停止する.py", "README.md")
CODE_SUFFIXES = {".go", ".mod", ".sum", ".py", ".ps1", ".mjs", ".js", ".md", ".txt", ".exe"}


def require(ok: bool, message: str) -> None:
    """
    機能: 条件が偽なら保存を停止する。
    引数: ok(bool)は検査結果、message(str)は失敗理由。
    返り値: None。失敗時はValueError。
    """
    if not ok:
        raise ValueError(message)


def sha_bytes(data: bytes) -> str:
    """
    機能: bytesのSHA256を計算する。
    引数: data(bytes)は対象bytes。
    返り値: strの小文字SHA256。
    """
    return hashlib.sha256(data).hexdigest()


def file_sha(path: Path) -> str:
    """
    機能: ファイルを小さい塊で読みSHA256を計算する。
    引数: path(Path)は対象ファイル。
    返り値: strの小文字SHA256。
    """
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def reference(path: Path) -> dict[str, str]:
    """
    機能: 現物ファイルの絶対パスとSHA256を作る。
    引数: path(Path)は現物ファイル。
    返り値: dict[str,str]のFileRef。
    """
    return {"path": str(path.resolve()), "sha256": file_sha(path)}


def normalize_ref(ref: dict[str, str]) -> dict[str, str]:
    """
    機能: FileRefの形式を検査し絶対パスへ揃える。
    引数: ref(dict[str,str])は外部参照。
    返り値: dict[str,str]の正規化FileRef。
    """
    require(isinstance(ref, dict) and set(ref) in ({"path", "sha256"}, {"path", "sha256", "bytes"}), "FileRefのキーが不正")
    require("bytes" not in ref or (type(ref["bytes"]) is int and ref["bytes"] >= 0), "FileRefのbytesは非負整数が必要")
    require(isinstance(ref["path"], str) and Path(ref["path"]).is_absolute(), "絶対パスが必要")
    require(isinstance(ref["sha256"], str) and re.fullmatch(r"[0-9a-f]{64}", ref["sha256"]) is not None, "SHA256が不正")
    return {"path": str(Path(ref["path"]).resolve()), "sha256": ref["sha256"]}


def load_ref(ref: dict[str, str], before: dict[str, str]) -> bytes:
    """
    機能: FileRefをSHA認証し前証拠へ登録する。
    引数: ref(dict[str,str])は参照、before(dict[str,str])は前証拠。
    返り値: bytesの認証済み本文。
    """
    item = normalize_ref(ref)
    data = Path(item["path"]).read_bytes()
    require(sha_bytes(data) == item["sha256"], "入力SHA不一致: " + item["path"])
    require(item["path"] not in before or before[item["path"]] == item["sha256"], "同じパスのSHAが競合")
    before[item["path"]] = item["sha256"]
    return data


def load_json(ref: dict[str, str], before: dict[str, str]) -> dict[str, Any]:
    """
    機能: SHA認証済みJSONオブジェクトを読む。
    引数: ref(dict[str,str])は参照、before(dict[str,str])は前証拠。
    返り値: dict[str,Any]のJSON本文。
    """
    value = json.loads(load_ref(ref, before).decode("utf-8-sig"))
    require(isinstance(value, dict), "JSONのルートはオブジェクトが必要")
    return value


def same_ref(a: dict[str, str], b: dict[str, str]) -> bool:
    """
    機能: FileRefを絶対パスとSHAで照合する。
    引数: a,b(dict[str,str])は比較対象。
    返り値: boolの一致結果。
    """
    return normalize_ref(a) == normalize_ref(b)


def safe_name(name: str) -> str:
    """
    機能: 保存先とarchive内の相対名を検査する。
    引数: name(str)はスラッシュ区切り名。
    返り値: strの安全な相対名。
    """
    require(isinstance(name, str) and name != "" and "\\" not in name and ":" not in name, "相対名が不正")
    path = PurePosixPath(name)
    require(not path.is_absolute() and all(part not in ("", ".", "..") for part in name.split("/")), "相対名の遡及を拒否")
    return name


def add_copy(copies: dict[str, dict[str, str]], name: str, ref: dict[str, str]) -> None:
    """
    機能: 重複しない保存予定を登録する。
    引数: copies(dict)は予定、name(str)は相対先、ref(dict)はFileRef。
    返り値: None。
    """
    name = safe_name(name)
    require(name not in copies, "保存名が重複: " + name)
    copies[name] = normalize_ref(ref)


def add_code(codes: dict[str, dict[str, str]], name: str, ref: dict[str, str], before: dict[str, str], repository: Path) -> None:
    """
    機能: 新規ownedのcodeまたは実exeをarchive予定へ登録する。
    引数: codes(dict)は予定、name(str)はentry名、ref(dict)は参照、before(dict)は前証拠、repository(Path)は根。
    返り値: None。
    """
    name = safe_name(name)
    item = normalize_ref(ref)
    path = Path(item["path"])
    require(path.is_relative_to((repository / "work").resolve()), "codeは今回work内の明示新規ownedだけを指定")
    require(path.relative_to((repository / "work").resolve()).parts[0].startswith("113"), "旧111/112のcode本文は参照のみ")
    require(path.suffix.lower() in CODE_SUFFIXES, "codeの拡張子が不正")
    require(name not in codes, "code entry名が重複")
    require(all(existing["path"] != item["path"] for existing in codes.values()), "code現物を二重同梱しない")
    load_ref(item, before)
    codes[name] = item


# ----------------------------------------


def prepare(request_ref: dict[str, str], repository: Path | None = None) -> dict[str, Any]:
    """
    機能: Root要求、停止、70場完了、既正式参照と全保存予定を認証する。Rawは開かない。
    引数: request_ref(dict)はRoot固定要求、repository(Path|None)はCLIでは本リポジトリ、人工では一時根。
    返り値: dict[str,Any]の認証済み保存計画。
    """
    repository = (repository or SELF.parent.parent).resolve()
    before: dict[str, str] = {}
    req = load_json(request_ref, before)
    require(req.get("version") == 1 and req.get("trial") == 113 and req.get("source_trial") == 112, "試行または版が不正")
    require(req.get("fixed") is True and req.get("reader_result_read_authorized") is True and req.get("policy") == POLICY, "Root固定またはReader結果許可がない")
    target = Path(req["target_directory"]).resolve()
    require(target == (repository / TARGET).resolve(), "正式保存先が違う")
    require(not target.exists(), "保存先は新規only")
    stop = load_json(req["saver_stop"], before)
    require(stop.get("成功") is True and stop.get("停止") is True, "保存器停止が未成功")
    own_map = stop.get("所有コードSHA256", {})
    require(all(str(SELF / name) in own_map for name in OWNED), "保存器の所有コードが不足")
    codes: dict[str, dict[str, str]] = {}
    for path, digest in own_map.items():
        require(Path(path).parent.resolve() == SELF, "保存器の所有範囲が違う")
        add_code(codes, "保存器/" + Path(path).name, {"path": path, "sha256": digest}, before, repository)
    copies: dict[str, dict[str, str]] = {}
    add_copy(copies, "検査/保存のRoot要求.json", request_ref)
    add_copy(copies, "検査/保存器停止.json", req["saver_stop"])
    complete = load_json(req["reader_completion"], before)
    require(complete.get("success") is True and complete.get("version") == 1 and complete.get("trial") == 113 and complete.get("source_trial") == 112, "Reader完了が不正")
    require(complete.get("sessions") == 70 and complete.get("raw_passes") == 70 and complete.get("financial_replay") is False, "70場一走査の成功が必要")
    require(complete.get("unchanged") is True and complete.get("before") == complete.get("after"), "Reader前後不変の証拠がない")
    add_copy(copies, "検査/Reader完了.json", req["reader_completion"])
    condition = load_json(complete["condition"], before)
    require(condition.get("fixed") is True and condition.get("raw_read_authorized") is True and condition.get("policy") == "holding_interval_ohlc112_v1", "Reader固定要求が違う")
    require(condition.get("version") == 1 and condition.get("trial") == 113 and condition.get("source_trial") == 112, "Reader条件の試行が違う")
    add_copy(copies, "検査/Reader固定要求.json", complete["condition"])
    for key, name in (("queries", "Reader入力.json"), ("witness_requests", "保存点witnessの要求.json"), ("manifest", "入力台帳70場.json")):
        require(same_ref(complete[key], condition[key]), "Reader入力参照不一致: " + key)
        load_json(condition[key], before)
        add_copy(copies, "検査/" + name, condition[key])
    reader_stop = load_json(condition["reader_stop"], before)
    require(reader_stop.get("成功") is True and reader_stop.get("停止") is True, "Reader停止が未成功")
    add_copy(copies, "検査/Reader停止.json", condition["reader_stop"])
    ledger_stop = load_json(condition["ledger_stop"], before)
    require(ledger_stop.get("成功") is True and ledger_stop.get("停止") is True, "台帳停止のRoot接続が不正")
    add_copy(copies, "検査/台帳停止のRoot接続.json", condition["ledger_stop"])
    require(same_ref(condition["executable"], reader_stop["実行物"]), "Reader実使用exeの不一致")
    for path, digest in reader_stop["所有コードSHA256"].items():
        add_code(codes, "Reader/" + Path(path).relative_to(Path(condition["reader_stop"]["path"]).parent).as_posix(), {"path": path, "sha256": digest}, before, repository)
    add_code(codes, "Reader/実使用実行物.exe", condition["executable"], before, repository)
    for row in req.get("code_refs", []):
        add_code(codes, "追加/" + safe_name(row["archive_path"]), row["ref"], before, repository)
    queries = load_json(condition["queries"], before)
    witnesses = load_json(condition["witness_requests"], before)
    sessions = condition["sessions"]
    require(isinstance(sessions, list) and len(sessions) == 70 and len(set(sessions)) == 70, "Reader70場の重複または欠落")
    require([row["session"] for row in complete["results"]] == sessions, "Reader完了の場順が不一致")
    expected_counts = {s: [0, 0, 0] for s in sessions}
    interval_sessions = {row["price_interval_id"]: row["session"] for row in queries["price_intervals"]}
    for row in queries["price_intervals"]:
        expected_counts[row["session"]][0] += 1
    for row in queries["state_slices"]:
        expected_counts[interval_sessions[row["price_interval_id"]]][1] += 1
    for row in witnesses["witnesses"]:
        expected_counts[row["session"]][2] += 1
    scenes = []
    for row in complete["results"]:
        session = row["session"]
        require(re.fullmatch(r"\d{4}-\d{2}-\d{2}_(Day|Night)", session) is not None, "場IDの形式不正")
        require([row["price_intervals"], row["state_queries"], row["witnesses"]] == expected_counts[session], "Reader場別件数が要求と不一致")
        result_path = Path(normalize_ref(row["result"])["path"])
        require(result_path.parent == Path(req["reader_completion"]["path"]).resolve().parent and result_path.name == session + ".ohlc.json", "Reader結果は完了と同folderの当場OHLCだけを読む")
        data = load_ref(row["result"], before)
        scene = json.loads(data.decode("utf-8-sig"))
        require(scene.get("success") is True and scene.get("version") == 1 and scene.get("session") == session and scene.get("trial") == 113 and scene.get("source_trial") == 112, "Reader場別成功が不正")
        require(scene.get("raw_passes") == 1 and scene.get("payload_cumulative_high_low_used") is False, "Reader一走査/区間価格の証拠不正")
        require(scene.get("stat_before") == scene.get("stat_after") and scene["actual_sha256"] == scene["raw"]["sha256"], "Raw照合時の前後/SHA証拠不正")
        require([len(scene["price_intervals"]), len(scene["state_queries"]), len(scene["witnesses"])] == expected_counts[session], "Reader場本文の件数が不一致")
        require(all(item.get("start_matched") is True and item.get("end_matched") is True for item in scene["price_intervals"].values()), "区間両端未照合")
        require(all(item.get("found") is True and item.get("index_matched") is True for item in scene["witnesses"].values()), "保存点原行未照合")
        scenes.append({"session": session, "source": normalize_ref(row["result"]), "archive_path": "Reader/" + session + ".ohlc.json", "bytes": len(data)})
    priors = []
    require(set(req["prior_formal_indexes"]) == {"111", "112"}, "既正式111/112の所在索引が必要")
    for trial in ("111", "112"):
        ref = req["prior_formal_indexes"][trial]
        index = load_json(ref, before)
        require(index.get("成功") is True and index.get("試行") == int(trial), "既正式所在索引の成功/版が不正")
        priors.append({"trial": int(trial), "index": normalize_ref(ref), "archive": normalize_ref(index["ZIP"]), "archive_body_copied": False, "archive_body_rehashed": False})
    for row in req.get("extra_refs", []):
        name = safe_name(row["target"])
        require(name.startswith("診断/") or name.startswith("集計/") or name.startswith("検査/追加/"), "追加資料の保存域が違う")
        require(Path(name).suffix.lower() in {".json", ".gz", ".md", ".txt"}, "追加資料にRaw/Native/CSVは保存不可")
        source_path = Path(normalize_ref(row["ref"])["path"])
        require(source_path.is_relative_to((repository / "work").resolve()), "追加資料は今回workの明示成果物だけを指定")
        require(source_path.relative_to((repository / "work").resolve()).parts[0].startswith("113"), "旧112/111本文を追加資料に複写しない")
        require(not source_path.name.lower().endswith((".native.json.gz", ".jsonl.gz", ".trades.jsonl", ".csv")), "Raw/Native/CSVを追加資料へ複写しない")
        load_ref(row["ref"], before)
        add_copy(copies, name, row["ref"])
    csvs = req.get("csv_refs", {})
    require(len(csvs) == 3, "CSV正本3点の参照が必要")
    for name, ref in csvs.items():
        require(isinstance(name, str) and Path(ref["path"]).suffix.lower() == ".csv", "CSV参照形式不正")
        load_ref(ref, before)
    return {"request": req, "request_ref": normalize_ref(request_ref), "target": target, "before": before, "copies": copies, "codes": codes, "scenes": scenes, "priors": priors, "csvs": csvs}


# ----------------------------------------


def write_json(path: Path, value: Any) -> None:
    """
    機能: UTF-8/LFのJSONを新規ファイルへ書く。
    引数: path(Path)は保存先、value(Any)はJSON値。
    返り値: None。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def write_reader_bundle(path: Path, scenes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """
    機能: Reader元JSONを再直列化せず決定的tar.gzへ束ね、再読検証する。
    引数: path(Path)は新規bundle先、scenes(list[dict])は認証済み予定。
    返り値: list[dict]の元SHA/bytes索引。
    """
    entries = []
    with path.open("xb") as raw:
        with gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0, compresslevel=9) as compressed:
            with tarfile.open(fileobj=compressed, mode="w|", format=tarfile.PAX_FORMAT) as archive:
                for row in scenes:
                    data = Path(row["source"]["path"]).read_bytes()
                    require(sha_bytes(data) == row["source"]["sha256"], "bundle作成前にReader結果が変化")
                    item = tarfile.TarInfo(safe_name(row["archive_path"]))
                    item.size = len(data)
                    item.mode = 0o644
                    item.mtime = 0
                    archive.addfile(item, io.BytesIO(data))
                    entries.append(dict(row, sha256=sha_bytes(data)))
    with tarfile.open(path, "r:gz") as archive:
        members = archive.getmembers()
        require([m.name for m in members] == [r["archive_path"] for r in entries], "Reader bundleの集合/順序が違う")
        for member, row in zip(members, entries):
            require(member.isfile() and member.size == row["bytes"], "Reader bundleの型/bytesが違う")
            stream = archive.extractfile(member)
            require(stream is not None and sha_bytes(stream.read()) == row["sha256"], "Reader bundle元SHA不一致")
    return entries


def write_code_bundle(path: Path, codes: dict[str, dict[str, str]]) -> list[dict[str, Any]]:
    """
    機能: 明示された新ownedと実exeだけを決定的ZIPへ保存し再読検証する。
    引数: path(Path)は新規ZIP、codes(dict)は安全名からFileRefへの対応。
    返り値: list[dict]のコード所在索引。
    """
    entries = []
    with zipfile.ZipFile(path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, ref in sorted(codes.items()):
            data = Path(ref["path"]).read_bytes()
            require(sha_bytes(data) == ref["sha256"], "code bundle作成前に現物が変化")
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
            entries.append({"archive_path": name, "source": ref, "bytes": len(data)})
    with zipfile.ZipFile(path) as archive:
        require(archive.namelist() == [r["archive_path"] for r in entries] and archive.testzip() is None, "code ZIP集合/CRC不正")
        for row in entries:
            require(sha_bytes(archive.read(row["archive_path"])) == row["source"]["sha256"], "code ZIP元SHA不一致")
    return entries


def save(plan: dict[str, Any]) -> dict[str, Any]:
    """
    機能: 認証済み計画を新規onlyで保存し、入力前後不変と全entryを記録する。
    引数: plan(dict[str,Any])はprepareの返り値。
    返り値: dict[str,Any]の保存成功記録。失敗時は不完了記録を残す。
    """
    target = plan["target"]
    target.mkdir(parents=True, exist_ok=False)
    try:
        copied = []
        for name, ref in sorted(plan["copies"].items()):
            destination = target / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open("xb") as output, Path(ref["path"]).open("rb") as source:
                shutil.copyfileobj(source, output)
            require(file_sha(destination) == ref["sha256"], "同bytes保存に失敗: " + name)
            copied.append({"source": ref, "saved": reference(destination)})
        reader_path = target / "Reader結果.tar.gz"
        reader_entries = write_reader_bundle(reader_path, plan["scenes"])
        reader_ref = reference(reader_path)
        write_json(target / "Reader元JSON索引.json", {"version": 1, "trial": 113, "source_trial": 112, "archive": reader_ref, "entries": reader_entries, "all_original_bytes_equal": True, "raw_body_saved": False, "financial_replay": False})
        code_path = target / "再現資料/新規コードと実使用実行物.zip"
        code_path.parent.mkdir(parents=True, exist_ok=True)
        code_entries = write_code_bundle(code_path, plan["codes"])
        code_ref = reference(code_path)
        write_json(target / "再現資料/コード所在索引.json", {"version": 1, "trial": 113, "archive": code_ref, "entries": code_entries, "prior_formal_references": plan["priors"], "old_source_closure_body_copied": False, "all_original_bytes_equal": True})
        write_json(target / "CSV正本の所在.json", {"trial": 113, "source_trial": 112, "csvs": plan["csvs"], "body_copied": False, "content_interpreted": False})
        after = {name: file_sha(Path(name)) for name in plan["before"]}
        require(after == plan["before"], "保存の入力/コードが前後で変化")
        output_refs = {str(p.relative_to(target).as_posix()): reference(p) for p in sorted(target.rglob("*")) if p.is_file()}
        result = {"version": 1, "trial": 113, "source_trial": 112, "success": True, "request": plan["request_ref"], "target_directory": str(target), "reader_sessions": len(reader_entries), "reader_bundle": reader_ref, "reader_original_sha_index": reference(target / "Reader元JSON索引.json"), "code_bundle": code_ref, "code_entries": len(code_entries), "prior_formal_references": plan["priors"], "same_bytes_copies": copied, "outputs": output_refs, "before": plan["before"], "after": after, "unchanged": True, "raw_body_saved": False, "native_body_read": False, "financial_replay": False, "trial113_financial_complete": False, "adopted": False}
        write_json(target / "検査/正式保存の確認.json", result)
        return result
    except Exception as error:
        write_json(target / "検査/正式保存の不完了.json", {"trial": 113, "source_trial": 112, "success": False, "request": plan["request_ref"], "error": str(error), "financial_replay": False})
        raise


def main() -> None:
    """
    機能: Root固定要求だけから認証または正式保存を起動する。
    引数: CLIの--fixed(str)、--sha256(str)、任意--metadata-only(bool)。
    返り値: None。失敗時は非0終了。
    """
    parser = argparse.ArgumentParser(description="112保有区間OHLCの根拠を新規保存")
    parser.add_argument("--fixed", required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--metadata-only", action="store_true")
    args = parser.parse_args()
    plan = prepare({"path": str(Path(args.fixed).resolve()), "sha256": args.sha256})
    if args.metadata_only:
        require({name: file_sha(Path(name)) for name in plan["before"]} == plan["before"], "認証の前後で入力が変化")
        print(json.dumps({"success": True, "reader_sessions": len(plan["scenes"]), "code_entries": len(plan["codes"]), "copies": len(plan["copies"]), "write": False, "raw_read": False, "native_read": False}, ensure_ascii=False))
    else:
        result = save(plan)
        print(json.dumps({"success": result["success"], "confirmation": reference(plan["target"] / "検査/正式保存の確認.json")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
