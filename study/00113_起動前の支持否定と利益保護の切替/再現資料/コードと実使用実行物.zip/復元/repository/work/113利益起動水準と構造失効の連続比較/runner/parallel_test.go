package parallel113

import (
	"context"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"sync/atomic"
	"testing"
	"time"

	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	core "github.com/masayoshi4649/SessionTradeExecuter/entrycomparison113"
)

// clone は人工の可変参照を分離します。
//
// 引数: value(T)はJSON保存可能な人工値です。
// 返り値: Tは独立した複写です。
func clone[T any](value T) T {
	raw, _ := json.Marshal(value)
	var out T
	if err := json.Unmarshal(raw, &out); err != nil {
		panic(err)
	}
	return out
}

// handPlan はRawを作らない70場metadataから段階別の手製計画を作ります。
//
// 引数: t(*testing.T)、stage(string)は試験器と段階です。
// 返り値: Planはcallback専用で市場金融の認証済み計画ではありません。
func handPlan(t *testing.T, stage string) Plan {
	t.Helper()
	base := t.TempDir()
	file, err := saveNew(filepath.Join(base, "固定metadata.json"), map[string]any{"人工": true}, false)
	if err != nil {
		t.Fatal(err)
	}
	cases := []source.InputCase{}
	day, _ := time.Parse("2006-01-02", "2026-09-21")
	for len(cases) < 70 {
		if day.Weekday() != time.Saturday && day.Weekday() != time.Sunday {
			for _, kind := range []string{"Day", "Night"} {
				cases = append(cases, source.InputCase{ID: day.Format("2006-01-02") + "_" + kind})
			}
		}
		day = day.AddDate(0, 0, 1)
	}
	n := map[string]int{"first2": 2, "base54": 54, "full70": 70}[stage]
	p := Plan{Core: core.RunPlan{Stage: stage, Source: source.RunPlan{Stage: stage, Condition: file, Cases: cases[:n], Before: map[string]string{file.Path: file.SHA256}},
		Fixed: core.Fixed{Golden: map[string]source.FileRef{}}, LegacyNatives: map[string]source.FileRef{}}}
	for _, input := range cases[:54] {
		p.Core.Fixed.Golden[input.ID] = file
	}
	for _, input := range cases {
		p.Core.LegacyNatives[input.ID] = file
	}
	return p
}

// handWorker は金融を呼ばず一子のI/O完了だけを作ります。
//
// 引数: p(Plan)、job(Job)は手製計画と当子です。
// 返り値: WorkerCompletion/errorは人工Nativeと保存完了です。
func handWorker(p Plan, job Job) (WorkerCompletion, error) {
	if _, err := newDirectory(job.Out); err != nil {
		return WorkerCompletion{}, err
	}
	ref, err := saveNew(filepath.Join(job.Out, job.Input.ID+".Native.json.gz"), map[string]any{"人工": true, "金融": false, "session": job.Input.ID}, true)
	if err != nil {
		return WorkerCompletion{}, err
	}
	var proof *source.GoldenProof
	if job.Index < 54 {
		methods := 1
		if job.Index%2 == 1 {
			methods = 2
		}
		proof = &source.GoldenProof{ReferenceKind: "rerun_original166_pinned_code", MiniEventsEqual: true, Reference: p.Core.Fixed.Golden[job.Input.ID],
			Session: job.Input.ID, Methods: methods, EventsEqual: true}
	}
	value := WorkerCompletion{Version: 1, Trial: 113, Success: true, Stage: p.Core.Stage, Session: job.Input.ID, ConditionSHA256: p.Core.Source.Condition.SHA256,
		Result: core.SceneResult{Session: job.Input.ID, Native: ref, Golden: proof, Books: 24, S0Comparisons: 4, S0Equal: true, Complete: true, Reference112: p.Core.LegacyNatives[job.Input.ID], Reference112Comparisons: 12, Reference112Equal: true, Source111Equal: true},
		Before: clone(p.Core.Source.Before), After: clone(p.Core.Source.Before), Unchanged: true}
	_, err = saveNew(filepath.Join(job.Out, "完了.json"), value, false)
	return value, err
}

// TestPoolParallelismAndPlannedOrder は同時上限と完了順に依存しない予定順を検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。人工54場を金融として評価しません。
func TestPoolParallelismAndPlannedOrder(t *testing.T) {
	p := handPlan(t, "base54")
	var active, peak atomic.Int32
	cb := func(ctx context.Context, job Job) (WorkerCompletion, error) {
		now := active.Add(1)
		defer active.Add(-1)
		for old := peak.Load(); now > old; old = peak.Load() {
			if peak.CompareAndSwap(old, now) {
				break
			}
		}
		select {
		case <-ctx.Done():
			return WorkerCompletion{}, ctx.Err()
		case <-time.After(time.Duration(5-job.Index%5) * time.Millisecond):
		}
		return handWorker(p, job)
	}
	value, err := assemble(p, 8, filepath.Join(t.TempDir(), "親"), cb)
	if err != nil || !value.Success || value.Books != 1296 || value.OriginalMethods != 81 || value.ReplayedSessions != 54 {
		t.Fatal(err)
	}
	if peak.Load() < 2 || peak.Load() > 8 || value.ParallelWorkers != 8 {
		t.Fatal("同時上限", peak.Load())
	}
	for i, row := range value.Results {
		if row.Session != p.Core.Source.Cases[i].ID {
			t.Fatal("完了順を採用")
		}
	}
	first := handPlan(t, "first2")
	small, err := assemble(first, 16, filepath.Join(t.TempDir(), "先頭2"), func(_ context.Context, j Job) (WorkerCompletion, error) { return handWorker(first, j) })
	if err != nil || small.ParallelWorkers != 2 || small.Books != 48 {
		t.Fatal("先頭2のmin同時数", err)
	}
}

// TestPoolFailuresAndExistingPaths は子失敗・完了欠落・場/指紋差・既存先を成功へ補いません。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。全て手製callbackです。
func TestPoolFailuresAndExistingPaths(t *testing.T) {
	for _, mode := range []string{"子失敗", "保存完了欠落", "別場", "固定前後差", "残予約", "旧対照不足", "旧源差"} {
		t.Run(mode, func(t *testing.T) {
			p := handPlan(t, "first2")
			out := filepath.Join(t.TempDir(), "親")
			value, err := assemble(p, 2, out, func(_ context.Context, j Job) (WorkerCompletion, error) {
				if mode == "子失敗" {
					return WorkerCompletion{}, fmt.Errorf("人工の子失敗")
				}
				v, e := handWorker(p, j)
				if e != nil {
					return v, e
				}
				switch mode {
				case "保存完了欠落":
					_ = os.Remove(filepath.Join(j.Out, "完了.json"))
				case "別場":
					v.Session = "別の場"
				case "固定前後差":
					v.After = map[string]string{}
				case "残予約":
					v.Result.PendingQuantity = 1
				case "旧対照不足":
					v.Result.Reference112Comparisons = 11
				case "旧源差":
					v.Result.Source111Equal = false
				}
				return v, nil
			})
			if err == nil || value.Success {
				t.Fatal("不完了を全体成功へ補完")
			}
			if _, e := os.Stat(filepath.Join(out, "不完了.json")); e != nil {
				t.Fatal(e)
			}
			if _, e := os.Stat(filepath.Join(out, "完了.json")); !os.IsNotExist(e) {
				t.Fatal("失敗後の成功ファイル")
			}
		})
	}
	p := handPlan(t, "first2")
	cb := func(_ context.Context, j Job) (WorkerCompletion, error) { return handWorker(p, j) }
	out := t.TempDir()
	if _, err := assemble(p, 2, out, cb); err == nil {
		t.Fatal("既存親先を上書き")
	}
	p.Core.Source.Cases[1].ID = p.Core.Source.Cases[0].ID
	if _, err := assemble(p, 2, filepath.Join(t.TempDir(), "重複"), cb); err == nil {
		t.Fatal("場重複を受理")
	}
}

// TestPoolFull70Reuses54 は同条件の54参照を保ち追加16だけcallbackへ配ります。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。手製54Nativeは再生又は複写しません。
func TestPoolFull70Reuses54(t *testing.T) {
	p := handPlan(t, "full70")
	old := core.Completion{Version: 1, Trial: 113, Success: true, Stage: "base54", ConditionSHA256: p.Core.Source.Condition.SHA256, Sessions: 54,
		Books: 1296, OriginalMethods: 81, ReplayedSessions: 54, Reference112Comparisons: 648, AllReference112Equal: true, AllSource111Equal: true, Unchanged: true, Before: clone(p.Core.Source.Before), After: clone(p.Core.Source.Before)}
	root := t.TempDir()
	for i, input := range p.Core.Source.Cases[:54] {
		row, err := handWorker(p, Job{Index: i, Input: input, Out: filepath.Join(root, input.ID)})
		if err != nil {
			t.Fatal(err)
		}
		old.Results = append(old.Results, row.Result)
		p.Core.Source.Before[row.Result.Native.Path] = row.Result.Native.SHA256
	}
	p.Core.Prior54 = &old
	priorRef, e := saveNew(filepath.Join(root, "人工base54完了.json"), old, false)
	if e != nil {
		t.Fatal(e)
	}
	p.Core.Source.Prior54Ref = &priorRef
	p.Core.Source.Before[priorRef.Path] = priorRef.SHA256
	var called atomic.Int32
	out := filepath.Join(t.TempDir(), "全70")
	result, err := assemble(p, 16, out, func(_ context.Context, j Job) (WorkerCompletion, error) {
		if j.Index < 54 {
			t.Error("元54の再生")
		}
		called.Add(1)
		return handWorker(p, j)
	})
	if err != nil || !result.Success || result.ReusedSessions != 54 || result.ReplayedSessions != 16 || called.Load() != 16 || result.Books != 1680 {
		t.Fatal(err)
	}
	for i := 0; i < 54; i++ {
		if result.Results[i].Native != old.Results[i].Native {
			t.Fatal("54の参照を変更")
		}
	}
	entries, err := os.ReadDir(filepath.Join(out, "worker"))
	if err != nil || len(entries) != 16 {
		t.Fatal("元54Nativeを複写", err)
	}
	p.Core.Prior54.Results[0].Golden = nil
	if _, err = assemble(p, 16, filepath.Join(t.TempDir(), "無対照"), func(_ context.Context, j Job) (WorkerCompletion, error) { return handWorker(p, j) }); err == nil {
		t.Fatal("元対照nilを受理")
	}
}

// TestWorkerRejectsBadFixed は子も本文より前の同じ固定認証で拒否されます。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。子の再生やspawnは起動しません。
func TestWorkerRejectsBadFixed(t *testing.T) {
	file, err := saveNew(filepath.Join(t.TempDir(), "未固定.json"), map[string]any{"fixed": false}, false)
	if err != nil {
		t.Fatal(err)
	}
	out := filepath.Join(t.TempDir(), "子")
	value, err := Worker(file, "first2", "2026-09-21_Day", out, nil)
	if err == nil || value.Success {
		t.Fatal("未固定子を受理")
	}
	if _, e := os.Stat(out); !os.IsNotExist(e) {
		t.Fatal("固定不正で子出力作成")
	}
}

// TestExportArtificial は停止器指定時だけI/O人工の成功参照を保存します。
//
// 引数: t(*testing.T)、環境変数PARALLEL113_ART_OUTは試験器と新規先です。
// 返り値: なし。実金融Nativeを作りません。
func TestExportArtificial(t *testing.T) {
	out := os.Getenv("PARALLEL113_ART_OUT")
	if out == "" {
		t.Skip("人工の保存先未指定")
	}
	p := handPlan(t, "first2")
	value, err := assemble(p, 16, out, func(_ context.Context, j Job) (WorkerCompletion, error) { return handWorker(p, j) })
	if err != nil || !value.Success || !reflect.DeepEqual(value.Before, value.After) {
		t.Fatal(err)
	}
}
