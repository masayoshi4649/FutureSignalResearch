package entrycomparison113

import (
	"encoding/json"
	"fmt"
	bank "github.com/masayoshi4649/SessionTradeExecuter/chartprotection111"
	legacyActor "github.com/masayoshi4649/SessionTradeExecuter/continuousactor112"
	actor "github.com/masayoshi4649/SessionTradeExecuter/continuousactor113"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
	legacyCore "github.com/masayoshi4649/SessionTradeExecuter/supportcomparison112"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	protect "github.com/masayoshi4649/SessionTradeExecuter/miniprotect"
)

// valueCopy は元94の人工器具が使う独立複写名を現接続へ結びます。
//
// 引数: value(T)は保存可能な手製値。返り値: Tは参照を共有しない全値です。
func valueCopy[T any](value T) T { return copyValue(value) }

// handReplay は手製通知だけで24口座と旧S0四口座を同じ原行へ結びます。
//
// 引数: t(*testing.T)、side(int)、late(float64)は試験器・鏡像・将来追記。
// 返り値: ReplayResultは人工の完結結果で、FAR自然生成や実市場の成績ではありません。
func handReplayPair(t *testing.T, side int, late float64) (ReplayResult, legacyCore.ReplayResult) {
	return handReplayScenario(t, side, late, false)
}

// handReplayScenario は失効波形を選べる手製の原行列を作ります。
//
// 引数: t(*testing.T)、side(int)、late(float64)、invalidation(bool)は試験器・方向・追記・形状です。
// 返り値: ReplayResult/legacyCore.ReplayResultは新113と旧112の完結した人工です。
func handReplayScenario(t *testing.T, side int, late float64, invalidation bool) (ReplayResult, legacyCore.ReplayResult) {
	t.Helper()
	session := session94()
	consumer := New()
	if err := consumer.Begin(source.SourceCase{Session: session, Contract: "人工限月"}); err != nil {
		t.Fatal(err)
	}
	legacyFull := legacyCore.New()
	if err := legacyFull.Begin(source.SourceCase{Session: session, Contract: "人工限月"}); err != nil {
		t.Fatal(err)
	}
	old := map[string]*protect.ActualBook{}
	for _, config := range source.ActorConfigs() {
		book, err := protect.NewActualBook(session, config)
		if err != nil {
			t.Fatal(err)
		}
		old[book.Snapshot().Key] = book
	}
	legacy := map[string]*legacyActor.ActualBook{}
	for _, config := range legacyActor.DeclaredContinuousConfigurations() {
		if config.Policy != "S0" && config.Policy != "W100" && config.Policy != "P100" {
			continue
		}
		book, err := legacyActor.NewContinuousBook(session, "人工限月", config)
		if err != nil {
			t.Fatal(err)
		}
		legacy[book.Snapshot().Key] = book
	}
	legacyChart, err := bank.New(chart.Scene{ID: session.ID, Contract: "人工限月", Start: session.Start}, nil)
	if err != nil {
		t.Fatal(err)
	}
	fixture := newFixtureSource94()
	for i := 0; i <= 140; i++ {
		move := float64(5 * i)
		if i >= 112 {
			switch i {
			case 112:
				move = 620
			case 113:
				move = 690
			case 114:
				move = 790
			case 115:
				move = 650
			case 116, 117:
				move = 585
			default:
				move = 515
			}
		}
		if invalidation && i >= 99 && i <= 125 {
			moves := map[int]float64{99: 460, 100: 455, 101: 460, 102: 470, 103: 475, 104: 480, 105: 490, 106: 500, 107: 510, 108: 520, 109: 530, 110: 540, 111: 550, 112: 550, 113: 400, 114: 405, 115: 410, 116: 400, 117: 405, 118: 410, 119: 415, 120: 410, 121: 415, 122: 420, 123: 425, 124: 430, 125: 435}
			move = moves[i]
		}
		if i > 130 {
			move += late
		}
		o := observation94(session, side, int64(i), float64(i*60), move, 20)
		if invalidation && i == 114 {
			o.Ask = o.Bid
			o.QuoteOK = false
		}
		news := []native.Signal{}
		if i == 110 {
			news = append(news, birth94("人工入口", side, 2))
		}
		if invalidation && i == 114 {
			news = append(news, close94("人工源部分返済", "人工入口", side, 1))
		}
		if i == 125 {
			quantity := 2
			if invalidation {
				quantity = 1
			}
			news = append(news, close94("人工源返済", "人工入口", side, quantity))
		}
		batch := fixture.step(t, o, int64(i+1), news, nil)
		before, _ := json.Marshal(batch)
		for _, book := range old {
			if err := book.OnNativeStep(o, int64(i+1), []protect.NativeBatch{batch}); err != nil {
				t.Fatal(err)
			}
		}
		if err := consumer.Step(source.NativeStep{Observation: o, SourceLine: int64(i + 1), Mini: []source.NativeBatch{batch}}); err != nil {
			t.Fatal(i, err)
		}
		if err := legacyFull.Step(source.NativeStep{Observation: o, SourceLine: int64(i + 1), Mini: []source.NativeBatch{batch}}); err != nil {
			t.Fatal(err)
		}
		publication, err := legacyChart.Step(chart.Quote{Time: o.Time, Index: o.Index, Line: int64(i + 1), Last: o.Last, Bid: o.Bid, Ask: o.Ask, Valid: true})
		if err != nil {
			t.Fatal(err)
		}
		for _, event := range publication.Events {
			for _, book := range legacy {
				if book.Snapshot().Config.Policy == "S0" {
					continue
				}
				switch event.Kind {
				case "reset":
					r := publication.Resets[event.Index]
					if err := book.ResetPublication(r.At, r.Reason); err != nil {
						t.Fatal(err)
					}
				case "observation":
					p := publication.Observations[event.Index]
					if err := book.SetPublication(p.At, 1, p.Buy); err != nil {
						t.Fatal(err)
					}
					if err := book.SetPublication(p.At, -1, p.Sell); err != nil {
						t.Fatal(err)
					}
				default:
					t.Fatal("未宣言公表")
				}
			}
		}
		for _, book := range legacy {
			if err := book.OnNativeStep(o, int64(i+1), []legacyActor.NativeBatch{{Method: batch.Method, Delta: batch.Delta}}); err != nil {
				t.Fatal(err)
			}
		}
		for _, book := range consumer.books {
			current := book.Snapshot()
			if prior, ok := legacy[current.Key]; ok {
				if check, err := actor.CompareLegacy112(current, prior.Snapshot()); err != nil || !check.AllFinancialEqual {
					t.Fatal("旧12毎原行", i, current.Key, err)
				}
			}
		}
		after, _ := json.Marshal(batch)
		if !reflect.DeepEqual(before, after) {
			t.Fatal("接続が手製源を変更")
		}
	}
	if err := consumer.End(source.SourceEnd{Session: session, Complete: true}); err != nil {
		t.Fatal(err)
	}
	if err := legacyFull.End(source.SourceEnd{Session: session, Complete: true}); err != nil {
		t.Fatal(err)
	}
	origin := source.ReplayResult{Version: 1, Trial: 111, Session: session, Contract: "人工限月", Complete: true, Books: map[string]source.ActualResult{}}
	for key, book := range old {
		value, err := book.Finish()
		if err != nil {
			t.Fatal(key, err)
		}
		origin.Books[key] = value
	}
	result, err := ConnectResult(origin, consumer)
	if err != nil {
		t.Fatal(err)
	}
	prior, err := legacyCore.ConnectResult(copyValue(origin), legacyFull)
	if err != nil {
		t.Fatal(err)
	}
	for key, book := range legacy {
		value, err := book.Finish()
		if err != nil {
			t.Fatal(err)
		}
		if check, err := actor.CompareLegacy112(result.Actual.Books[key], value); err != nil || !check.AllFinancialEqual {
			t.Fatal(err)
		}
	}
	if err := CompareReference112Values(&result, prior, source.FileRef{Path: "人工参照", SHA256: "人工"}); err != nil {
		t.Fatal(err)
	}
	if result.Reference112.Comparisons != 12 || !result.Reference112.SourceEqual {
		t.Fatal("旧12終了対照")
	}
	broken := copyValue(prior)
	broken.Source.Contract = "別限月"
	if CompareReference112Values(&result, broken, source.FileRef{}) == nil {
		t.Fatal("源差を受理")
	}
	broken = copyValue(prior)
	bad := broken.Actual.Books["W100_C0_D0"]
	bad.Totals.NetYen++
	broken.Actual.Books[bad.Key] = bad
	if CompareReference112Values(&result, broken, source.FileRef{}) == nil {
		t.Fatal("旧金融差を受理")
	}
	for key, book := range origin.Books {
		before := result.Source.Books[key].Totals.NetYen
		book.Totals.NetYen++
		origin.Books[key] = book
		if result.Source.Books[key].Totals.NetYen != before {
			t.Fatal("結合したSource結果と呼出元が参照を共有")
		}
	}
	return result, prior
}

// handReplay は手製買売24冊を単独検査へ渡します。
//
// 引数: t(*testing.T)、side(int)、late(float64)は試験器・方向・将来追記です。
// 返り値: ReplayResultは113の手製結果です。
func handReplay(t *testing.T, side int, late float64) ReplayResult {
	value, _ := handReplayPair(t, side, late)
	return value
}

// TestHandNonzeroAndMirrors は新規/返済が実際にある人工で全24とS0四対照を確認します。
//
// 引数: t(*testing.T)は試験器。返り値: ありません。元FARの有効性は検証しません。
func TestHandNonzeroAndMirrors(t *testing.T) {
	buy, sell := handReplay(t, 1, 0), handReplay(t, -1, 0)
	for _, result := range []ReplayResult{buy, sell} {
		if result.S0Comparisons != 4 || !result.S0Equal || result.OriginalHistoricalEventsEqual || len(result.Actual.Books) != 24 {
			t.Fatal("対照又は歴史同体の区別")
		}
		if result.Actual.Counts.Publications < 30 || result.Actual.FinalChart.Counts.BBKnown == 0 || result.Actual.EntryGridSeconds != nil || result.Actual.ExtraOpeningQuietSeconds != 0 || result.Actual.FinalChart.CarriedNumericSeed {
			t.Fatal("公表/BB/cold/時計")
		}
		for key, book := range result.Actual.Books {
			if len(book.Positions) != 1 || book.Positions[0].Quantity != 0 || book.Positions[0].Reserved != 0 || book.Totals.NetYen != book.Totals.ClosedNetYen {
				t.Fatal(key, "非ゼロ新規と完結")
			}
		}
	}
	for key, book := range buy.Actual.Books {
		if book.Totals.NetYen != sell.Actual.Books[key].Totals.NetYen {
			t.Fatal(key, "鏡像の純額")
		}
	}
	if buy.Actual.Books["S0_C0_D0"].Totals.NetYen >= 0 || buy.Actual.Books["W100_C0_D0"].Totals.NetYen <= 0 {
		t.Fatal("手計算のSource赤字と全玉保護正額の区別")
	}
}

// TestLaterPricesDoNotRewriteTrades は全返済後の将来追記が約定と純額を変えないことを確認します。
//
// 引数: t(*testing.T)は試験器。返り値: ありません。将来の仮想損益は計算しません。
func TestLaterPricesDoNotRewriteTrades(t *testing.T) {
	a, b := handReplay(t, 1, 0), handReplay(t, 1, 400)
	for key, book := range a.Actual.Books {
		other := b.Actual.Books[key]
		if !reflect.DeepEqual(book.Orders, other.Orders) || !reflect.DeepEqual(book.Fills, other.Fills) || !reflect.DeepEqual(book.Positions, other.Positions) || book.Totals.NetYen != other.Totals.NetYen {
			t.Fatal(key, "将来が成立取引を変更")
		}
	}
}

// TestNaturalSourceEmptyHandshake は原Source公開APIからも接続とS0全値比較が動くことを確認します。
//
// 引数: t(*testing.T)は試験器。返り値: ありません。通知なしの人工であることを明示します。
func TestNaturalSourceEmptyHandshake(t *testing.T) {
	session := session94()
	rows := []source.BoardEvent{}
	for i := 0; i < 4; i++ {
		at := session.Start + float64(i)
		ask := 40010.0
		if i == 2 {
			ask = 39990
		}
		rows = append(rows, source.BoardEvent{Board: strategy.Board{Reference: "TOPIX", Time: at, Received: at, Last: 2500, Bid: 2499.5, Ask: 2500.5}, Line: int64(i + 1)})
		rows = append(rows, source.BoardEvent{Board: strategy.Board{Reference: "NK225", Time: at, Received: at, Last: 40000, Bid: 39990, Ask: ask}, Line: int64(i + 1)})
	}
	consumer := New()
	with, err := source.ReplayEvents(session, "人工限月", rows, nil, consumer)
	if err != nil {
		t.Fatal(err)
	}
	without, err := source.ReplayEvents(session, "人工限月", rows, nil, nil)
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(with, without) {
		t.Fatal("追加保護が元Sourceへ干渉")
	}
	result, err := ConnectResult(with, consumer)
	if err != nil || result.S0Comparisons != 4 {
		t.Fatal("元API接続", err)
	}
	if result.Actual.Counts.BadQuotes != 1 {
		t.Fatal("同値気配を正常fill用に数えた")
	}
	for key, book := range result.Actual.Books {
		if book.Metrics.BadQuoteRows != result.Actual.Counts.BadQuotes {
			t.Fatal(key, "正常気配の分母差")
		}
	}
	if consumer.Step(source.NativeStep{}) == nil || consumer.End(source.SourceEnd{Session: session, Complete: true}) == nil {
		t.Fatal("終了後の原行又は二重終了を許可")
	}
}

// TestStopBeforeAndAfterEnd は未開始/二重開始/終了後の追記を拒否します。
//
// 引数: t(*testing.T)は試験器。返り値: ありません。
func TestStopBeforeAndAfterEnd(t *testing.T) {
	c := New()
	if c.Step(source.NativeStep{}) == nil {
		t.Fatal("未開始を許可")
	}
	s := session94()
	if err := c.Begin(source.SourceCase{Session: s, Contract: "人工限月"}); err != nil {
		t.Fatal(err)
	}
	if c.Begin(source.SourceCase{Session: s, Contract: "人工限月"}) == nil {
		t.Fatal("二重開始を許可")
	}
	if _, err := New().Result(); err == nil {
		t.Fatal("未完了を成功化")
	}
}

// TestExportArtificial は公表出典を含む手製買売48冊だけを保存します。
//
// 引数: t(*testing.T)、環境変数CORE113_ART_OUT(string)は試験器と未使用先です。
// 返り値: ありません。市場データを読みません。
func TestExportArtificial(t *testing.T) {
	out := os.Getenv("CORE113_ART_OUT")
	if out == "" {
		t.Skip("人工保存先なし")
	}
	if err := os.Mkdir(out, 0755); err != nil {
		t.Fatal(err)
	}
	refs := map[string]source.FileRef{}
	for _, item := range []struct {
		Name string
		Side int
	}{{"買い", 1}, {"売り", -1}} {
		value, prior := handReplayScenario(t, item.Side, 0, true)
		oldref, err := SaveNew(filepath.Join(out, item.Name+"_112.json.gz"), prior, true)
		if err != nil {
			t.Fatal(err)
		}
		if err := CompareReference112Values(&value, prior, oldref); err != nil {
			t.Fatal(err)
		}
		value.Reference112.BeforeSHA256, value.Reference112.AfterSHA256 = oldref.SHA256, oldref.SHA256
		refs[item.Name+"_112"] = oldref
		ref, err := SaveNew(filepath.Join(out, item.Name+".json.gz"), value, true)
		if err != nil {
			t.Fatal(err)
		}
		refs[item.Name] = ref
	}
	_, err := SaveNew(filepath.Join(out, "人工.json"), map[string]any{"試行": 113, "成功": true, "人工": true, "市場": false, "会計数": 48, "旧毎行対照": 12, "Native": refs}, false)
	if err != nil {
		t.Fatal(err)
	}
}

// TestChartEntryInvalidation は実公表経路で固定支持の失効と買売鏡像を確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。Source生成は手製で、市場の有効性を示しません。
func TestChartEntryInvalidation(t *testing.T) {
	buy, _ := handReplayScenario(t, 1, 0, true)
	sell, _ := handReplayScenario(t, -1, 0, true)
	for _, policy := range []string{"E100", "E50"} {
		for _, cost := range []int{0, 5} {
			for _, delay := range []int{0, 1} {
				key := fmt.Sprintf("%s_C%d_D%d", policy, cost, delay)
				b, s := buy.Actual.Books[key], sell.Actual.Books[key]
				if b.Metrics.EntryInvalidatedPositions != 1 || b.Metrics.EntryInvalidationExitRequests != 1 || b.Metrics.EntryInvalidationExitFills != 1 || b.Metrics.ProtectionActivatedPositions != 0 {
					t.Fatal(key, "固定支持の未起動離脱経路", b.Metrics)
				}
				if b.Totals.NetYen != s.Totals.NetYen || s.Metrics.EntryInvalidationExitFills != 1 {
					t.Fatal(key, "固定支持失効の鏡像差")
				}
				found := 0
				for _, order := range b.Orders {
					if point := order.EntryInvalidationPoint; point != nil {
						if order.Quantity != 1 || order.RequestQuote.QuoteOK || point.Snapshot.Remaining != 2 || point.Snapshot.Reserved != 1 || point.Decision.GainPoints != nil || point.Decision.EntryExitQuantity != 1 {
							t.Fatal(key, "nilMarkとSource部分予約後のfree量", order)
						}
						found++
					}
				}
				if found != 1 {
					t.Fatal(key, "技術失効要求点の欠落")
				}
			}
		}
	}
}
