# 113の利益起動水準と構造失効の連続比較

Source111とChart111を変更せず、Actor113の24冊へ一方向に渡す。112金融の高速F2コピーが自然2場で全Native/gzip同体だった証拠を基礎にするが、その証拠を新政策の市場成績や全tick独立監査へ広げない。市場はRootが113として新規条件を固定した後だけ実行する。

政策順はS0/W100/P100/P50/E100/E50、各政策はC0D0/C0D1/C5D0/C5D1。S0/W100/P100は正式112と同体の対照。P50はP100の起動水準Hだけを50pt相当に変更する。E100/E50は各P系列へ、起動前の固定支持否定と生MACD失速による技術離脱を追加する。Source入口や源へ実約定を返さない構成は共通である。

Eの支持anchorは実取得時に知る方向対応のPriorPivotを一度だけ固定する。将来の確定足でEnd>Entry.At、固定支持の厳密逆抜けとMが真なら失効する。現在の動的P、C、BBを偽装しない。未知や不適格支持では新失効を作らず、基礎Pの追尾を続ける。起動・失効の優先、予約・部分返済・要求点は実Pure/Actor宣言と人工で固定する。

## 公開接続と比較

`New() *Consumer` はSource111の公開Begin/Step/Endを実装する。原行の公表Atとreset/observationの順、先行fill、Source通知、厳密後原行fillを維持し、研究側の新規時計や開始静観を加えない。`ConnectResult` はSourceのS0四感度と新S0の全金融JSONを照合する。

Nativeの外側とActualはtrial113、Sourceのtrial111はライブラリの由来として保持する。Nativeには `reference112` の旧正式FileRef/読取前後SHA/12対照/detailsを保存する。`CompareReference112` は当場の正式112 NativeからSource全JSONとS0/W100/P100×4費用の金融全値を比較する。許容差はActor公開比較が検査した説明scope、監査field版名、正しいdefinition版と新しい無効fieldだけ。金融額・C/M/P/B・有効Stateを除外しない。

旧112には全tick保存Stateがないため、市場の全tick同体とは呼ばない。手製では旧12を毎受理原行と終了で照合する。追加保護・失効の実約定をSourceへ返して後続入口まで変える統合は、この比較には追加しない。

## 固定schemaと本文前ゲート

```text
version=1,trial=113,fixed=true,
policy=original166_source111_profit_threshold_and_entry_invalidation113,
source_trial=111,FAR_commit,strategy_commit,manifest,executable,code_sha256,
runtime_stop,copy_basis,dependency_stops{source,chart,core112,fast112,actor,pure},
actual_policy=profit_threshold_entry_invalidation113,
chart_seed_mode=cold_each_session,entry_grid_seconds=null,extra_opening_quiet_seconds=0,
actual_configurations[24],pure_configurations[24],policy_definitions[6],
actual_declaration,pure_declaration,chart_declaration,
original166_references[54],reference112{condition,market,native_catalog},
parallel_method=isolated_session_process113_v1,parallel_max_workers=16
```

`copy_basis` はRootの高速自然2場証拠6ea49…、`reference112.condition` は正式112 F1の893fa…、marketは0bf84…を要求する。停止・全選択Go/asm/embed/module/GoRoot閉包・実行中exe・実宣言・43戦略・70台帳・元oracle54参照・旧112小metadataをSHA認証する。Source111へtrialを偽装してその旧ゲートを呼ばない。

metadata-onlyはRawと旧Native本文・実Native指紋を読まない。worker当場でRawと対応する旧Nativeだけを認証・復号する。元54の原文oracleは同Source/同43/同入力で検証済みの参照を再用し、原文runは再走しない。

## CLIと独立場の並列

```powershell
& '検査/113連続比較.exe' --fixed '<Root新固定絶対path>' --fixed-sha '<SHA>' --stage metadata-only
& '検査/113連続比較.exe' --fixed '<同条件>' --fixed-sha '<同SHA>' --stage first2 --out '<新規絶対先>' --workers 2
& '検査/113連続比較.exe' --fixed '<同条件>' --fixed-sha '<同SHA>' --stage base54 --out '<新規絶対先>' --workers 16
& '検査/113連続比較.exe' --fixed '<同条件>' --fixed-sha '<同SHA>' --stage full70 --out '<新規絶対先>' --workers 16 --prior54 '<同113base54完了.json>' --prior54-sha '<SHA>'
```

初めから元54を実行することもでき、first2は任意の接続確認段階。full70は同じ113条件で成功した54Nativeの指紋・24冊・残0・旧12・元81対照を認証して参照再用し、追加16だけを再生する。54をRaw再生で再証明したとは書かない。

各workerは同一固定exeで外ゲートを再認証する別process。Windows窓は非表示、子GOMAXPROCS=1、最大16。原行内直列と場ごとのcoldを保ち、結果は予定順へ集約する。子失敗・完了欠落・場重複・固定差は全体成功へ補わない。親子とも新規出力だけ。

完了は112同形のtrial113で、旧対照fieldを `reference112_comparisons=12N/all_reference112_equal/all_source111_equal`、場別を `reference112/reference112_comparisons=12/reference112_equal/source111_equal` とする。全24N、S0四対照、原文元54の81手法場、全残玉予約0、Before=Afterを要求し、historical_saved_events_equalと全Signal全文同体はfalseのまま保持する。

## 検査と停止

手製の正常経路と、取得前anchor→取得後逆抜け+M、不正BBO/nilMark、Source部分予約後のfree量、買売鏡像、未来不参照、Source非干渉、旧12毎原行、並列順序/失敗/54参照再用を確認する。独立保存用買売48冊と旧112対は、scope/publications/resets/counts/final_chartと当場全金融値を持つ。FAR自然生成や実市場の成績ではない。

`検査して停止する.py` が自己と依存の前後不変、人工、vet/buildと実行物を記録し、`条件の素材.json` をfixed:falseでRootへ返す。Rootが別の固定条件を作り実市場を実行する。未参加・退出後仮想利益、機会損失、MFE回収率、ROIは作らず、市場結果を見て閾値を変更しない。
