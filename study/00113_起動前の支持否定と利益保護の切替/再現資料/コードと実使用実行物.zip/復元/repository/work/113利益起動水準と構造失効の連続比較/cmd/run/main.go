package main

import (
	"encoding/json"
	"flag"
	"fmt"
	"os"

	source "github.com/masayoshi4649/SessionTradeExecuter/continuous111"
	shim "github.com/masayoshi4649/SessionTradeExecuter/entrycomparison113/runner"
)

// run は親とworkerのモードを分け、workerからの再帰spawnを作りません。
//
// 引数: なし。CLIは固定Ref・段階・新規先・先行成功・最大16workerです。
// 返り値: errorは固定又は子完了の不整合です。
func run() error {
	fixed := flag.String("fixed", "", "Rootの113固定")
	sha := flag.String("fixed-sha", "", "固定SHA256")
	stage := flag.String("stage", "", "metadata-only/first2/base54/full70")
	out := flag.String("out", "", "新規出力先")
	prior := flag.String("prior54", "", "同じ113固定条件のbase54完了")
	priorSHA := flag.String("prior54-sha", "", "base54完了SHA256")
	workers := flag.Int("workers", 16, "独立processの上限1..16")
	workerSession := flag.String("worker-session", "", "一子専用の場ID")
	flag.Parse()
	if *fixed == "" || *sha == "" || *stage == "" || (*out == "" && *stage != "metadata-only") || *workers < 1 || *workers > 16 {
		return fmt.Errorf("固定Ref/段階/新規先/worker上限1..16が必要")
	}
	ref := source.FileRef{Path: *fixed, SHA256: *sha}
	var old *source.FileRef
	if *prior != "" || *priorSHA != "" {
		old = &source.FileRef{Path: *prior, SHA256: *priorSHA}
	}
	if *workerSession != "" {
		result, err := shim.Worker(ref, *stage, *workerSession, *out, old)
		if err != nil {
			return err
		}
		return json.NewEncoder(os.Stdout).Encode(map[string]any{"success": result.Success, "session": result.Session})
	}
	if *stage == "metadata-only" {
		p, err := shim.Prepare(ref, *stage, old)
		if err != nil {
			return err
		}
		return json.NewEncoder(os.Stdout).Encode(map[string]any{"metadata_verified": true, "financial_executed": false, "cases": len(p.Core.Source.Cases), "parallel_method": shim.Method})
	}
	result, err := shim.Run(ref, *stage, *out, old, *workers)
	if err != nil {
		return err
	}
	return json.NewEncoder(os.Stdout).Encode(map[string]any{"success": result.Success, "sessions": result.Sessions, "books": result.Books, "parallel_workers": result.ParallelWorkers})
}

// main は親又は一子の不完了を終了1へ反映します。
//
// 引数: なし。
// 返り値: なし。成功0、不整合1です。
func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
