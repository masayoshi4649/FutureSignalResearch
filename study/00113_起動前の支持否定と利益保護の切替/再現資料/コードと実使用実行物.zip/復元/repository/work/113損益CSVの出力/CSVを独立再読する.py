"""113のCSVを再読し、独立集計の正本と全行・全対象数値を照合する。"""

import argparse
from collections import defaultdict
import csv
from decimal import Decimal
import hashlib
import json
from pathlib import Path

ZERO = Decimal(0)
TOLERANCE = Decimal("0.000001")


def digest(path: Path) -> str:
    """機能: 明示したファイルの全バイト指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def number(value: str, expected: int | Decimal | None, label: str) -> None:
    """機能: CSVの空欄・実数を正本と照合する。

    引数: value(str)、expected(int|Decimal|None)、label(str)はCSV・正本・項目。
    返り値: None。nullは空欄だけ、数値差は円の百万分の一まで認める。
    """
    if expected is None:
        if value != "":
            raise ValueError("未定義を0へ変えている: " + label)
        return
    actual = Decimal(value)
    if not actual.is_finite() or abs(actual - Decimal(expected)) > TOLERANCE:
        raise ValueError("CSV数値差: " + label)


def records(path: Path) -> list[dict]:
    """機能: UTF-8 CSVをヘッダ付きの全行へ復元する。

    引数: path(Path)はCSV。
    返り値: list[dict]は空欄も保った全行。
    """
    with path.open(encoding="utf-8-sig", newline="") as stream:
        reader = csv.DictReader(stream)
        if len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ValueError("ヘッダ重複")
        return list(reader)


def main() -> None:
    """機能: 候補24・全場1680のCSVと費用後純額・累計・率を再検算する。

    引数: CLIはresult/sha256、folder、outputの絶対又は明示位置。
    返り値: None。市場Rawは読まず、確認JSONを新規保存する。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--result", required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--folder", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    result_path, folder, output = Path(args.result).resolve(), Path(args.folder).resolve(), Path(args.output).resolve()
    if digest(result_path) != args.sha256:
        raise ValueError("独立結果の期待指紋差")
    data = json.loads(result_path.read_text(encoding="utf-8"), parse_float=Decimal)
    if not data["成功"] or not data["前後不変"] or data["試行"] != 113 or data["場数"] != 70 or data["会計数"] != 1680:
        raise ValueError("全70の独立成功ではない")
    expected_keys = [f"{policy}_C{slip}_D{delay}" for policy in ("S0", "W100", "P100", "P50", "E100", "E50")
                     for slip in (0, 5) for delay in (0, 1)]
    if data["主key"] != expected_keys:
        raise ValueError("113の政策・費用・遅延の予定順差")
    source = {(r["key"], r["session"]): r for r in data["場別"]}
    if len(source) != 1680:
        raise ValueError("正本の場別重複")
    proof_path = folder / "CSVの確認.json"
    proof = json.loads(proof_path.read_text(encoding="utf-8"))
    if not proof["成功"] or proof["入力SHA256"] != args.sha256:
        raise ValueError("CSV生成の正本差")
    paths = [result_path, proof_path, folder / "候補別集計.csv", folder / "全セッション.csv", Path(__file__).resolve()]
    before = {str(p): digest(p) for p in paths}
    for name, ref in proof["出力"].items():
        if digest(folder / name) != ref["sha256"]:
            raise ValueError("CSVの生成後改変")
    detail = records(folder / "全セッション.csv")
    totals = records(folder / "候補別集計.csv")
    if len(detail) != 1680 or len(totals) != 24:
        raise ValueError("CSVの予定行不足")
    mapped = {
        "新規件数": "positions", "新規枚数": "entry_quantity",
        "粗損益円": "gross_yen", "手数料円": "fee_yen", "追加滑り円": "slip_yen", "純損益円": "net_yen",
        "利益総額円": "positive_yen", "損失総額円": "negative_yen",
        "勝ち件数": "positive_positions", "負け件数": "negative_positions", "同値件数": "zero_positions",
        "建玉全体の正益後赤字件数": "whole_positive_closed_negative",
        "追尾起動件数": "protection_activated_positions", "追尾起動後赤字件数": "activated_closed_negative",
        "起動前失効玉数": "entry_invalidated_positions", "起動前失効返済要求数": "entry_invalidation_exit_requests",
        "起動前失効返済約定数": "entry_invalidation_exit_fills",
    }
    seen, cumulative, count, zero_rows = set(), defaultdict(lambda: ZERO), 0, 0
    sessions = defaultdict(list)
    for row in detail:
        key = row["条件ID"]
        sid = row["開始日"] + ("_Day" if row["セッション"] == "デイ" else "_Night" if row["セッション"] == "ナイト" else "_不明")
        identity = key, sid
        if identity not in source or identity in seen:
            raise ValueError("未知又は重複の場別行")
        seen.add(identity)
        sessions[key].append(sid)
        original, config = source[identity], data["Actor設定"][key]
        if row["候補"] != config["candidate"] or row["期間区分"] != ("元54場" if original["history_class"] == "original54" else "追加16場"):
            raise ValueError("候補又は期間区分差")
        for header, expected in (("試行", 113), ("片道追加滑りpt", config["slip_pts"]), ("仮定遅延秒", config["delay_seconds"])):
            number(row[header], expected, key + "/" + header)
            count += 1
        for header, source_name in mapped.items():
            number(row[header], original[source_name], key + "/" + sid + "/" + header)
            count += 1
        cumulative[key] += original["net_yen"]
        number(row["累計収支円"], cumulative[key], "累計" + key)
        number(row["場内時価DD円"], original["場内時価DD"], "場内DD" + key)
        number(row["保有時間秒"], original["頻度診断"]["held_seconds"], "保有秒" + key)
        number(row["数量秒"], original["頻度診断"]["quantity_seconds"], "数量秒" + key)
        count += 4
        number(row['起動前失効返済純額円'], original['注文別']['起動前失効']['返済片純額'], '起動前失効実純額' + key)
        count += 1
        zero_rows += original["positions"] == 0
        number(str(Decimal(row["粗損益円"]) - Decimal(row["手数料円"]) - Decimal(row["追加滑り円"])), original["net_yen"], "CSVの費用控除" + key)
    if seen != set(source) or set(sessions) != set(data["主key"]):
        raise ValueError("全予定場・設定集合の差")
    for key, values in sessions.items():
        if len(values) != 70 or values != sorted(values):
            raise ValueError("候補内の予定70場・時系列順序差")
    extra = {
        "PF": "PF", "平均利益円": "average_profit_yen", "平均損失円": "average_loss_yen",
        "平均利益損失比": "average_profit_loss_ratio", "保存点連結時価DD円": "保存点連結時価DD",
        "建玉全体の正益後赤字額円": "whole_positive_closed_negative_yen", "追尾起動後赤字額円": "activated_closed_negative_yen",
    }
    total_seen = set()
    for row in totals:
        key = row["条件ID"]
        if key in total_seen or key not in data["主key"]:
            raise ValueError("候補別集計の重複又は未知")
        total_seen.add(key)
        aggregate, config = data["集計"][key], data["Actor設定"][key]
        if row["候補"] != config["candidate"]:
            raise ValueError("候補名差")
        for header, source_name in {**mapped, **extra}.items():
            number(row[header], aggregate[source_name], key + "/" + header)
            count += 1
        number(row['起動前失効返済純額円'], aggregate['注文別']['起動前失効']['返済片純額'], '起動前失効実純額' + key)
        count += 1
        number(row["勝率パーセント"], None if aggregate["win_rate"] is None else aggregate["win_rate"] * 100, "勝率" + key)
        number(row["セッション数"], 70, "全場数" + key)
        number(row["片道追加滑りpt"], config["slip_pts"], "滑り" + key)
        number(row["仮定遅延秒"], config["delay_seconds"], "遅延" + key)
        number(row["保有時間秒"], sum((r["頻度診断"]["held_seconds"] for r in data["場別"] if r["key"] == key), ZERO), "保有合計" + key)
        number(row["数量秒"], sum((r["頻度診断"]["quantity_seconds"] for r in data["場別"] if r["key"] == key), ZERO), "数量秒合計" + key)
        number(row["純損益円"], cumulative[key], "累計終端" + key)
        count += 7
    after = {str(p): digest(p) for p in paths}
    if before != after:
        raise ValueError("正本・CSV・検算codeの前後差")
    report = {"成功": True, "試行": 113, "場別行数": len(detail), "候補数": len(totals), "数値比較数": count,
              "0取引行数": zero_rows, "全場累計再計算": True, "未定義比率は空欄": True,
              "前後不変": True, "入力SHA256": before, "後SHA256": after, "Raw読取": 0, "金融再実行": False}
    with output.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"成功": True, "確認SHA256": digest(output), "比較数": count, "0取引行数": zero_rows}, ensure_ascii=False))


if __name__ == "__main__":
    main()
