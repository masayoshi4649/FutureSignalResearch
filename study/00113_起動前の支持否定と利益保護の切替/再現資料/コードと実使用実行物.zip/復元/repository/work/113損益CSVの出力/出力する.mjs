/**
 * 独立保存済みの113損益を、候補別集計と全セッションのCSVへ出力する。
 * @param {string[]} process.argv - 結果JSON、期待SHA256、新規出力先の順。
 * @returns {Promise<void>} 再計算・検算したCSV二点と確認JSONを保存する。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {Workbook} from '@oai/artifact-tool';

/**
 * 明示した入力・出力の指紋を計算する。
 * @param {Uint8Array|string} value - 対象バイト列又はUTF-8文字列。
 * @returns {string} SHA256。
 */
function sha(value) { return crypto.createHash('sha256').update(value).digest('hex'); }

/**
 * 保存された有限数値と計算値を比較する。
 * @param {number} actual - 計算値。
 * @param {number} expected - 保存値。
 * @param {string} label - 照合する項目。
 * @returns {void} 不一致は例外にする。
 */
function equalNumber(actual, expected, label) {
  assert.ok(Number.isFinite(actual) && Number.isFinite(expected), label);
  assert.ok(Math.abs(actual - expected) <= 0.000001, `${label}: ${actual} / ${expected}`);
}

/**
 * 分母が0の比率を空欄として、数値0と区別して検査する。
 * @param {number|null} actual - 計算値又は未定義。
 * @param {number|null} expected - 保存値又は未定義。
 * @param {string} label - 検査する項目。
 * @returns {void} 型又は値の差は例外にする。
 */
function equalNullable(actual, expected, label) {
  if (actual === null || expected === null) assert.equal(actual, expected, label);
  else equalNumber(actual, expected, label);
}

/**
 * 取引単位の利益と損失から比率の意味を検査する。
 * @param {Object} row - 場別又は候補別の独立集計。
 * @param {string} label - 対象ID。
 * @returns {void} 利益・損失の符号、件数、比率が違えば例外。
 */
function inspectMetrics(row, label) {
  assert.ok(row.positive_yen >= 0 && row.negative_yen <= 0, label);
  equalNumber(row.positive_yen + row.negative_yen, row.net_yen, `${label}/利益損失と純額`);
  assert.equal(row.positive_positions + row.negative_positions + row.zero_positions, row.positions, label);
  equalNullable(row.negative_yen === 0 ? null : row.positive_yen / -row.negative_yen, row.PF, `${label}/PF`);
  equalNullable(row.positions === 0 ? null : row.positive_positions / row.positions, row.win_rate, `${label}/勝率`);
  const gain = row.positive_positions === 0 ? null : row.positive_yen / row.positive_positions;
  const loss = row.negative_positions === 0 ? null : row.negative_yen / row.negative_positions;
  equalNullable(gain, row.average_profit_yen, `${label}/平均利益`);
  equalNullable(loss, row.average_loss_yen, `${label}/平均損失`);
  equalNullable(gain === null || loss === null ? null : gain / -loss, row.average_profit_loss_ratio, `${label}/平均損益比`);
}

/**
 * CSVの文字列フィールドに必要な引用符だけを加える。
 * @param {string|number|null} value - 表の値。nullは未定義の空欄。
 * @returns {string} RFC4180のフィールド。
 */
function field(value) {
  const text = value == null ? '' : String(value);
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

/**
 * 計算済みの表をUTF-8 BOM付きCSVにする。
 * @param {Object} sheet - artifact-toolの表。
 * @param {number} rows - ヘッダ込み行数。
 * @param {number} columns - 列数。
 * @returns {string} 改行CRLFのCSV。
 */
function csv(sheet, rows, columns) {
  return '\uFEFF' + sheet.getRangeByIndexes(0, 0, rows, columns).values.map(row => row.map(field).join(',')).join('\r\n') + '\r\n';
}

// ----------------------------------------
// 固定済み独立結果を認証し、取引0のセッションも含む24×70を検査する。

const [inputArg, expectedSHA, outputArg] = process.argv.slice(2);
assert.ok(inputArg && /^[a-f0-9]{64}$/.test(expectedSHA) && outputArg, '入力JSON・期待SHA・新規出力先が必要');
const input = path.resolve(inputArg), output = path.resolve(outputArg);
const original = await fs.readFile(input);
assert.equal(sha(original), expectedSHA, '独立結果のSHA256');
const data = JSON.parse(original.toString('utf8').replace(/^\uFEFF/, ''));
assert.equal(data['成功'], true);
assert.equal(data['試行'], 113);
assert.equal(data.stage, 'full70');
assert.equal(data['場数'], 70);
assert.equal(data['前後不変'], true);
assert.equal(data['会計数'], 1680);
const keys = data['主key'];
assert.equal(keys.length, 24);
assert.equal(new Set(keys).size, 24);
const expectedKeys = ['S0', 'W100', 'P100', 'P50', 'E100', 'E50'].flatMap(policy => [0, 5].flatMap(slip => [0, 1].map(delay => `${policy}_C${slip}_D${delay}`)));
assert.deepEqual(keys, expectedKeys, '113の固定した六政策と費用・遅延順');
assert.equal(data['場別'].length, 1680);
const workbook = Workbook.create();
const summarySheet = workbook.worksheets.add('候補別集計');
const detailSheet = workbook.worksheets.add('全セッション');
const summaryHeader = ['試行', '候補', '条件ID', 'セッション数', '片道追加滑りpt', '仮定遅延秒', '新規件数', '新規枚数', '勝ち件数', '負け件数', '同値件数', '勝率パーセント', '利益総額円', '損失総額円', 'PF', '平均利益円', '平均損失円', '平均利益損失比', '粗損益円', '手数料円', '追加滑り円', '純損益円', '保存点連結時価DD円', '建玉全体の正益後赤字件数', '建玉全体の正益後赤字額円', '追尾起動件数', '追尾起動後赤字件数', '追尾起動後赤字額円', '保有時間秒', '数量秒', '起動前失効玉数', '起動前失効返済要求数', '起動前失効返済約定数', '起動前失効返済純額円'];
const detailHeader = ['試行', '候補', '条件ID', '開始日', 'セッション', '期間区分', '片道追加滑りpt', '仮定遅延秒', '新規件数', '新規枚数', '粗損益円', '手数料円', '追加滑り円', '純損益円', '累計収支円', '利益総額円', '損失総額円', '勝ち件数', '負け件数', '同値件数', '場内時価DD円', '建玉全体の正益後赤字件数', '追尾起動件数', '追尾起動後赤字件数', '保有時間秒', '数量秒', '起動前失効玉数', '起動前失効返済要求数', '起動前失効返済約定数', '起動前失効返済純額円'];
const summaryRows = [], detailRows = [], checks = [];
const additive = ['positions', 'entry_quantity', 'close_quantity', 'gross_yen', 'fee_yen', 'slip_yen', 'net_yen', 'positive_yen', 'negative_yen', 'positive_positions', 'negative_positions', 'zero_positions', 'whole_positive_closed_negative', 'whole_positive_closed_negative_yen', 'protection_activated_positions', 'activated_closed_negative', 'activated_closed_negative_yen', 'entry_invalidated_positions', 'entry_invalidation_exit_requests', 'entry_invalidation_exit_fills'];
for (const key of keys) {
  const config = data['Actor設定'][key], aggregate = data['集計'][key];
  assert.equal(config.entry_timing, '元Source連続時計');
  const rows = data['場別'].filter(row => row.key === key).sort((a, b) => a.session.localeCompare(b.session));
  assert.equal(rows.length, 70, key);
  assert.equal(new Set(rows.map(row => row.session)).size, 70, key);
  const sums = Object.fromEntries(additive.map(name => [name, 0]));
  let cumulative = 0, held = 0, quantitySeconds = 0;
  for (const row of rows) {
    assert.match(row.session, /^2026-\d{2}-\d{2}_(Day|Night)$/);
    assert.ok(['original54', 'additional16'].includes(row.history_class));
    equalNumber(row.gross_yen - row.fee_yen - row.slip_yen, row.net_yen, `${key}/${row.session}/純額`);
    equalNumber(row.closed_net_yen, row.net_yen, `${key}/${row.session}/場内完結`);
    for (const name of ['open_buy', 'open_sell', 'pending_buy', 'pending_sell']) assert.equal(row[name], 0, name);
    inspectMetrics(row, `${key}/${row.session}`);
    for (const name of additive) sums[name] += row[name];
    const duration = row['頻度診断'];
    assert.ok(duration.held_seconds >= 0 && duration.quantity_seconds >= 0);
    held += duration.held_seconds;
    quantitySeconds += duration.quantity_seconds;
    cumulative += row.net_yen;
    const [date, kind] = row.session.split('_');
    detailRows.push([113, config.candidate, key, date, kind === 'Day' ? 'デイ' : 'ナイト', row.history_class === 'original54' ? '元54場' : '追加16場', config.slip_pts, config.delay_seconds, row.positions, row.entry_quantity, row.gross_yen, row.fee_yen, row.slip_yen, row.net_yen, cumulative, row.positive_yen, row.negative_yen, row.positive_positions, row.negative_positions, row.zero_positions, row['場内時価DD'], row.whole_positive_closed_negative, row.protection_activated_positions, row.activated_closed_negative, duration.held_seconds, duration.quantity_seconds, row.entry_invalidated_positions, row.entry_invalidation_exit_requests, row.entry_invalidation_exit_fills, row['注文別']['起動前失効']['返済片純額']]);
  }
  assert.equal(rows.filter(row => row.history_class === 'original54').length, 54);
  for (const name of additive) equalNumber(sums[name], aggregate[name], `${key}/${name}`);
  inspectMetrics(aggregate, key);
  equalNumber(rows.reduce((sum, row) => sum + row['注文別']['起動前失効']['返済片純額'], 0), aggregate['注文別']['起動前失効']['返済片純額'], key + '/起動前失効の実返済片純額');
  // Counter加算が省略する0値キーだけを補う。全70場の実値合計が0でなければ一致しない。
  const durations = aggregate['頻度診断'];
  const storedHeld = Object.hasOwn(durations, 'held_seconds') ? durations.held_seconds : 0;
  const storedQuantity = Object.hasOwn(durations, 'quantity_seconds') ? durations.quantity_seconds : 0;
  equalNumber(held, storedHeld, `${key}/保有秒`);
  equalNumber(quantitySeconds, storedQuantity, `${key}/数量秒`);
  summaryRows.push([113, config.candidate, key, 70, config.slip_pts, config.delay_seconds, sums.positions, sums.entry_quantity, sums.positive_positions, sums.negative_positions, sums.zero_positions, aggregate.win_rate === null ? null : aggregate.win_rate * 100, sums.positive_yen, sums.negative_yen, aggregate.PF, aggregate.average_profit_yen, aggregate.average_loss_yen, aggregate.average_profit_loss_ratio, sums.gross_yen, sums.fee_yen, sums.slip_yen, sums.net_yen, aggregate['保存点連結時価DD'], sums.whole_positive_closed_negative, sums.whole_positive_closed_negative_yen, sums.protection_activated_positions, sums.activated_closed_negative, sums.activated_closed_negative_yen, held, quantitySeconds, sums.entry_invalidated_positions, sums.entry_invalidation_exit_requests, sums.entry_invalidation_exit_fills, aggregate['注文別']['起動前失効']['返済片純額']]);
  checks.push({条件ID: key, 場数: 70, 純損益円: sums.net_yen, 保有時間秒: held, 数量秒: quantitySeconds});
}
detailSheet.getRange('D2:D1681').setNumberFormat('@');
summarySheet.getRangeByIndexes(0, 0, summaryRows.length + 1, summaryHeader.length).values = [summaryHeader, ...summaryRows];
detailSheet.getRangeByIndexes(0, 0, detailRows.length + 1, detailHeader.length).values = [detailHeader, ...detailRows];

// ----------------------------------------
// 純額と累計を表上で再計算し、値だけをCSVへ出す。固定枠参加率は作らない。

detailSheet.getRange('N2:N1681').formulas = detailRows.map((row, i) => [`=K${i + 2}-L${i + 2}-M${i + 2}`]);
detailSheet.getRange('O2:O1681').formulas = detailRows.map((row, i) => [i === 0 || detailRows[i - 1][2] !== row[2] ? `=N${i + 2}` : `=O${i + 1}+N${i + 2}`]);
workbook.recalculate();
const computed = detailSheet.getRangeByIndexes(1, 0, 1680, detailHeader.length).values;
for (let i = 0; i < computed.length; i++) for (const column of [13, 14]) equalNumber(computed[i][column], detailRows[i][column], `再計算/${i}/${column}`);
const sample = await workbook.inspect({kind: 'table', range: '候補別集計!A1:J4', include: 'values,formulas', tableMaxRows: 4, tableMaxCols: 10, maxChars: 3000});
const errors = await workbook.inspect({kind: 'match', searchTerm: '#REF!|#DIV/0!|#VALUE!|#NAME\\?|#NUM!|#NULL!|#SPILL!|#CALC!', options: {useRegex: true, maxResults: 10}, maxChars: 1500});
await fs.mkdir(output, {recursive: false});
const outputs = {};
for (const [name, sheet, count, columns] of [['候補別集計.csv', summarySheet, 25, summaryHeader.length], ['全セッション.csv', detailSheet, 1681, detailHeader.length]]) {
  const body = csv(sheet, count, columns);
  await fs.writeFile(path.join(output, name), body, {encoding: 'utf8', flag: 'wx'});
  outputs[name] = {sha256: sha(body), データ行数: count - 1, 列数: columns};
}
assert.equal(sha(await fs.readFile(input)), expectedSHA, '入力の前後不変');
await fs.writeFile(path.join(output, 'CSVの確認.json'), JSON.stringify({成功: true, 試行: 113, 入力: input, 入力SHA256: expectedSHA, 出力: outputs, 全条件: checks, 入力前後不変: true, 固定枠参加率生成: false, 金融再実行: false, 表の確認: sample.ndjson, エラー走査: errors.ndjson}, null, 2), {flag: 'wx'});
console.log(JSON.stringify({成功: true, 出力先: output, 出力: outputs}));
