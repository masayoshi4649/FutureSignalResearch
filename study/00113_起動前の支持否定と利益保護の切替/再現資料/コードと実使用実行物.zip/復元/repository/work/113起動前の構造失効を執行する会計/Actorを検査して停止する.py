"""純113停止を認証し、Actorの非市場人工と所有指紋を固定する。"""

import hashlib
import json
import os
import subprocess
from pathlib import Path


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PURE = ROOT / 'work/113起動前の支持否定と利益保護の純演算/停止.json'
PURE_SHA = '81f54d965ef8d81c65a7b58f4d376374b79c765e1ad4ada5cc6270159e4ed312'


def sha(path):
    """ファイルの指紋を得る。

    引数: path(Path)は明示コード又は証拠。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(argv, environment):
    """市場を読まないGo検査を行う。

    引数: argv(list[str])はコマンド、environment(dict)は環境。
    返り値: dictは標準出力と終了値。不成功はValueError。
    """
    p = subprocess.run(argv, cwd=HERE, env=environment, capture_output=True, text=True, encoding='utf-8', timeout=60)
    value = {'argv': argv, 'exit_code': p.returncode, 'stdout': p.stdout, 'stderr': p.stderr}
    if p.returncode:
        raise ValueError(json.dumps(value, ensure_ascii=False))
    return value


def main():
    """純停止後に人工・宣言・APIと元112不変を固定する。

    引数: なし。
    返り値: dictはActor停止Ref。
    """
    stop = HERE / 'Actor停止.json'
    output = HERE / 'Actor検査'
    if stop.exists() or output.exists() or sha(PURE) != PURE_SHA:
        raise ValueError('純停止差又は既存停止先')
    pure = json.loads(PURE.read_bytes())
    if not pure['成功']:
        raise ValueError('純停止成功が必要')
    own = sorted(HERE.glob('*.go')) + [HERE / n for n in ['go.mod', 'go.sum', 'cmd/puredeclaration/main.go', 'Actor_README.md', 'Actorの派生元.json', Path(__file__).name]]
    before = {str(p): sha(p) for p in own}
    origin = json.loads((HERE / 'Actorの派生元.json').read_bytes())
    deps = {str(PURE): PURE_SHA, origin['元高速Actor停止']['path']: origin['元高速Actor停止']['sha256']}
    deps.update({r['path']: r['sha256'] for r in origin['入力']})
    for key in ['所有コードSHA256', '所有ファイルSHA256', '依存SHA256']:
        deps.update(pure.get(key, {}))
    prior = ROOT / 'work/112支持否定と広い通常幅の会計/Actor停止.json'
    if sha(prior) != '54dc421f0c35cbd5736725955a02fb6cd11f70f3c8a7b646b954722781264006':
        raise ValueError('旧112停止差')
    deps[str(prior)] = sha(prior)
    deps.update(json.loads(prior.read_bytes())['所有コードSHA256'])
    if any(sha(Path(p)) != h for p, h in deps.items()):
        raise ValueError('依存の事前差')
    env = dict(os.environ, GOWORK='off', CGO_ENABLED='0')
    for k in ['MINIPROTECT_EXPORT_DIR', 'CONTINUOUS113_EXPORT_DIR']:
        env.pop(k, None)
    commands = [run(['go', 'test', '-count=1', '-json', './...'], env), run(['go', 'vet', './...'], env), run(['go', 'build', './...'], env)]
    events = [json.loads(s) for s in commands[0]['stdout'].splitlines() if s.startswith('{')]
    tests = [e['Test'] for e in events if e.get('Action') == 'pass' and 'Test' in e]
    if len(tests) != 12:
        raise ValueError('旧6/新6の人工件数差:' + str(tests))
    output.mkdir()
    exported = run(['go', 'test', '-count=1', '-run', '^TestExportContinuous113Fixtures$', './...'], dict(env, CONTINUOUS113_EXPORT_DIR=str(output/'人工')))
    api = run(['go', 'doc', '-all', '.'], env)
    (output/'API.txt').write_text(api['stdout'], encoding='utf-8')
    declared = json.loads((output/'人工/宣言設定.json').read_bytes())
    expected = [{'policy': p, 'slip_pts': c, 'delay_seconds': d} for p in ['S0','W100','P100','P50','E100','E50'] for c in [0,5] for d in [0,1]]
    if declared != expected or 'func CompareLegacy112(' not in api['stdout']:
        raise ValueError('実24宣言又は対照API差')
    if before != {p: sha(Path(p)) for p in before} or any(sha(Path(p)) != h for p,h in deps.items()):
        raise ValueError('所有/依存の前後差')
    proof = {'試行':113,'成功':True,'市場前':True,'人工主数':12,'成功test':tests,'test/vet/build':commands,'人工export':exported,
             '所有コードSHA256':before,'依存SHA256':deps,'前後不変':True,'旧対照':'S0/W100/P100×4、全受理行と終了の全金融/全State。版/Scope/無効新fieldだけ検査後に分離。',
             '市場/Raw/11月09本文':False}
    (output/'人工確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    value = {'試行':113,'成功':True,'市場前':True,'停止':True,'module':'github.com/masayoshi4649/SessionTradeExecuter/continuousactor113',
             '所有コードSHA256':before,'再用コードSHA256':deps,'前後不変':True,'純保護停止':{'path':str(PURE),'sha256':PURE_SHA},
             '人工確認':{'path':str(output/'人工確認.json'),'sha256':sha(output/'人工確認.json')},
             '実API':{'path':str(output/'API.txt'),'sha256':sha(output/'API.txt')},
             '実24宣言':{'path':str(output/'人工/宣言設定.json'),'sha256':sha(output/'人工/宣言設定.json')},
             '人工出力SHA256':{str(p):sha(p) for p in sorted((output/'人工').glob('*.json'))},'市場/Raw/11月09本文':False,'採用':False,'研究目標達成':False}
    stop.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return {'成功':True,'停止':{'path':str(stop),'sha256':sha(stop)}}


if __name__ == '__main__':
    print(json.dumps(main(),ensure_ascii=False))
