"""113の手製Core48冊と旧112対照を純Python会計で検査する。"""

from copy import deepcopy
from decimal import Decimal
import importlib.util
from pathlib import Path
import tempfile
import unittest

import 保存集計の共通部 as S
import 保存の入力ゲート as G


MANIFEST = S.ROOT / 'work/113利益起動水準と構造失効の連続比較/人工_独立保存用/人工.json'
MANIFEST_SHA = '67648f3e5b1661bde72067f21532e23b4a23e4494a6f88948e7df0941de56ed1'
P_PATH = Path(__file__).resolve().with_name('新保護の独立監査.py')


def fixtures() -> dict:
    """機能: Rootの手製113/112対だけを明示SHA認証して読む。

    引数: なし。
    返り値: dictは買売の113/112 Native。実市場のFAR生成ではない。
    """
    S.equal(S.digest(MANIFEST), MANIFEST_SHA, '113 Root手製manifest')
    metadata = S.load(MANIFEST)
    S.need(metadata['人工'] is True and metadata['市場'] is False and metadata['会計数'] == 48, '113人工の範囲')
    values = {}
    for name, ref in metadata['Native'].items():
        path = Path(ref['path'])
        S.equal(S.digest(path), ref['sha256'], '113/112手製Nativeの現物SHA')
        values[name] = S.load(path)
    return values


def protection():
    """機能: 独立Pの実Python実装を明示位置から読む。

    引数: なし。停止helperがこの位置と期待SHAを先に認証する。
    返り値: moduleはGoを呼ばないP監査。
    """
    spec = importlib.util.spec_from_file_location('113会計人工の独立P', P_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def empty_book(book: dict) -> dict:
    """機能: 実型と本名政策を保つ0取引の手製口座を作る。

    引数: book(dict)は113手製Go exportの雛形。
    返り値: dictは全金融・観測数0の独立copy。
    """
    result = deepcopy(book)
    for name in ('orders', 'fills', 'positions', 'source_events'):
        result[name] = []
    result['totals'] = {key: 0 for key in result['totals']}
    result['metrics'] = {key: 0 for key in result['metrics']}
    result['account'] = {key: 0 if key in ('count', 'max_drawdown', 'max_gap_seconds') else None for key in result['account']}
    return result


class Accounting113Tests(unittest.TestCase):
    """手製48冊と破壊例だけで113保存の会計境界を確認する。"""

    @classmethod
    def setUpClass(cls) -> None:
        """機能: SHA認証済み手製対とP実装を準備する。

        引数: cls(type)は検査クラス。
        返り値: None。
        """
        cls.values, cls.p = fixtures(), protection()

    def test_core48_and_legacy24(self) -> None:
        """機能: 買売48会計・P・旧12ずつ・Source全値を原値不変で照合する。

        引数: self(Accounting113Tests)は検査器。
        返り値: None。
        """
        for side in ('買い', '売り'):
            value, prior = self.values[side], self.values[side + '_112']
            before = repr((value, prior))
            result = S.inspect_scene(value, prior, self.p, artificial=True)
            self.assertEqual(len(result['checked']), 24)
            self.assertEqual(result['reference112']['comparisons'], 12)
            self.assertTrue(result['reference112']['source_equal'])
            S.equal(repr((value, prior)), before, '113/112手製原値不変')

    def test_financial_and_width_corruption(self) -> None:
        """機能: 費用・配賦・通常幅・所有・予約・同原行・DDの破壊を拒む。

        引数: self(Accounting113Tests)は検査器。
        返り値: None。
        """
        source = self.values['買い']['actual']['books']['E100_C0_D0']
        for kind in ('fee', 'allocation', 'width', 'owner', 'reserved', 'same_row', 'DD'):
            book = deepcopy(source)
            if kind == 'fee':
                book['fills'][0]['fee_yen'] += Decimal('0.5')
            elif kind == 'allocation':
                book['fills'][-1]['allocations'][0]['net_yen'] += 1
            elif kind == 'width':
                book['positions'][0]['atr']['width'] += 5
            elif kind == 'owner':
                book['fills'][-1]['source_hold_id'] = '他の所有'
            elif kind == 'reserved':
                book['positions'][0]['reserved'] = 1
            elif kind == 'same_row':
                book['fills'][0]['quote']['index'] = book['orders'][0]['request_quote']['index']
            else:
                book['account']['max_drawdown'] += 1
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                S.A.verify_finance(book, S.BY_KEY['E100_C0_D0'])

    def test_legacy_projection_rejects_masking(self) -> None:
        """機能: 旧12照合で純額・C観測・幅定義・Sourceの偽装を拒否する。

        引数: self(Accounting113Tests)は検査器。
        返り値: None。
        """
        for kind in ('net', 'C', 'definition', 'source'):
            value = deepcopy(self.values['買い'])
            book = value['actual']['books']['P100_C0_D0']
            if kind == 'net':
                book['totals']['net_yen'] += 1
            elif kind == 'C':
                trace = book['positions'][0]['protection113']['last']
                trace['decision']['c'] = 2 if trace['decision']['c'] != 2 else 1
            elif kind == 'definition':
                book['positions'][0]['protection113']['initial']['definition']['normal_width_minimum'] = 400
            else:
                value['source']['books']['S0_C0_D0']['totals']['net_yen'] += 1
            with self.subTest(kind=kind), self.assertRaises(ValueError):
                S.compare_reference112(value, self.values['買い_112'])

    def test_zero_trade24_and_ratios(self) -> None:
        """機能: 0取引24行・null比率・利益損失の明示列を維持する。

        引数: self(Accounting113Tests)は検査器。
        返り値: None。
        """
        for key in S.KEYS:
            book = empty_book(self.values['買い']['actual']['books'][key])
            checked = S.A.verify_finance(book, S.BY_KEY[key])
            checked['protection_counts'] = {}
            row = S.summarize_book(book, checked)
            total = S.combine([{'session': '手製0', **row}])
            self.assertEqual(total['positions'], 0)
            self.assertEqual(total['positive_yen'], 0)
            self.assertEqual(total['negative_yen'], 0)
            self.assertIsNone(total['PF'])
            self.assertIsNone(total['win_rate'])
        stats = S.profit_statistics({'positions': 4, 'positive_yen': Decimal(300), 'negative_yen': Decimal(-100), 'positive_positions': 2, 'negative_positions': 1})
        self.assertEqual(stats['PF'], 3)
        self.assertEqual(stats['win_rate'], Decimal('0.5'))
        self.assertEqual(stats['average_profit_yen'], 150)
        self.assertEqual(stats['average_loss_yen'], -100)

    def test_viewer48_and_existing_rejection(self) -> None:
        """機能: 113の48資源を別会計で保存再読し、旧112へ命名偽装しない。

        引数: self(Accounting113Tests)は検査器。
        返り値: None。一時人工だけを標準管理で削除する。
        """
        for side in ('買い', '売り'):
            with tempfile.TemporaryDirectory(prefix='113人工Viewer_') as tmp:
                output = Path(tmp)
                resources = S.save_viewer(self.values[side], output, '手製価格参照')
                self.assertTrue(all(r['id'].startswith('113_') for r in resources))
                result = S.verify_viewer(self.values[side], output, resources)
                self.assertEqual(result['資源'], 24)
                self.assertTrue(result['全残0'])
                with self.assertRaises(FileExistsError):
                    S.save_viewer(self.values[side], output, '手製価格参照')

    def test_scope_and_delay_are_preserved(self) -> None:
        """機能: 70予定場と旧54境界を保持し、相対Ref・既存先・遅延前fillを拒否する。

        引数: self(Accounting113Tests)は検査器。
        返り値: None。市場を開かない。
        """
        self.assertEqual(len(G.planned_sessions('full70')), 70)
        self.assertEqual(G.planned_sessions('full70')[:54], G.planned_sessions('base54'))
        with self.assertRaises(ValueError):
            G.planned_sessions('11/09')
        with self.assertRaises(ValueError):
            G.reference({'path': '相対.json', 'sha256': 'a' * 64}, {})
        book = deepcopy(self.values['買い']['actual']['books']['P50_C0_D1'])
        book['orders'][0]['request_time'] = book['fills'][0]['quote']['time']
        with self.assertRaises(ValueError):
            S.A.verify_finance(book, S.BY_KEY['P50_C0_D1'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
