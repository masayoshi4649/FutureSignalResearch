package main

import (
	"encoding/json"
	"os"

	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor113"
)

// main は実際に接続する純113の本名24宣言を出力します。
//
// 引数: なし。返り値: ありません。標準出力は宣言だけで、市場を読みません。
func main() {
	if err := json.NewEncoder(os.Stdout).Encode(map[string]any{"version": 113, "module": "profitfloor113", "configurations": guard.DeclaredConfigurations(), "definitions": guard.DeclaredDefinitions()}); err != nil {
		panic(err)
	}
}
