# 113の起動前構造失効を執行するActor

高速F2の固定Actor112から、新規module `continuousactor113` として派生する。旧停止・正式試行を変更しない。Source111の原行順、片側10mini、38.5円/枚片道、C0/C5、D0/D1、次正常後原行の約定、場内完結を維持する。市場前の人工のみを用いる。

政策順は S0/W100/P100/P50/E100/E50 ×C0/C5×D0/D1。S0/W100/P100の共通12冊は各受理原行と終了で固定112の全金融JSONと全純Stateを比較する。許可差は説明Scope、protection113→112、宣言と照合済みのDefinition版、新fieldが無効であることを確認した後の分離だけ。C/M/P/B、生Signal、注文・約定・所有・費用・床・時計は分離しない。

Eだけ、実new fill時の現在side公表にある既知PriorPivotをEntrySupportへ固定する。純部品は取得価格との適格距離と出典を検査する。不適格な既知支持をnilや別pivotへ付替えない。取得後の確定足終値が固定支持を厳密逆抜けし、生Mが真、Active=falseなら不可逆失効する。Hの必須起動は同じ評価内で先に計算する。既失効は後の回復・H到達でも消さない。

早期離脱は利益保護Activeと独立。`first_entry_invalidation` に初回失効、`entry_exit_requests` に実要求時の純点と予約後状態を保存する。注文 `entry_invalidation_point` とfill `entry_invalidation` により、Source返済・通常利益保護とは分ける。3つの新metricsは失効玉数/早期要求数/早期実fill数を別計数し、0ならJSONへ出さない。

nilMarkでも公表が既知なら失効できる。注文はafter_sourceで現在原行のQuoteStampを用い、Source予約後のfree量だけを予約する。異常気配の要求を正常価格で約定したことにはせず、次の正常な後原行とC/Dを待つ。既予約は取消さず、通常追尾と早期要求が同時に同free量を示す場合も一要求だけにする。

人工は買売×24、旧12の毎行全値、欠気配、Source部分/全予約優先、固定支持と動的Pの違い、H先到達、1価格秒の次原行/D1遅延、未知ATRの固定fallback、取消・上限・原行順を含む。全要求witnessやBeforeSnapshotを旧部へ追加して全Raw証明に拡張したとはしない。
