"""113の実会計を、固定94/111会計と起動前離脱の明示分類で独立検算する。"""

import ast
import hashlib
import importlib.util
import inspect
import math
import textwrap
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PREVIOUS_PATH = ROOT / 'work/111連続保護の独立保存/会計の独立検算.py'
PREVIOUS_SHA = '4c5f72dbbb31209c673b77f5171b73129a9a684951fc8c75361c601f7cc14e08'
if hashlib.sha256(PREVIOUS_PATH.read_bytes()).hexdigest() != PREVIOUS_SHA:
    raise ValueError('固定111会計のSHA差')
SPEC = importlib.util.spec_from_file_location('113が再用する固定111会計', PREVIOUS_PATH)
OLD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)
BASE, need, equal, number, money = OLD.BASE, OLD.need, OLD.equal, OLD.number, OLD.money
CONFIGS = tuple({'policy': p, 'slip_pts': c, 'delay_seconds': d}
                for p in ('S0', 'W100', 'P100', 'P50', 'E100', 'E50') for c in (0, 5) for d in (0, 1))


def key_for(config: dict) -> str:
    """本名24設定から口座IDを作る。

    引数: config(dict)は政策/片道滑り/遅延。
    返り値: strは113の口座識別子。不正設定はValueError。
    """
    need(config in CONFIGS and set(config) == {'policy', 'slip_pts', 'delay_seconds'}, '113の宣言外設定')
    return f"{config['policy']}_C{config['slip_pts']}_D{config['delay_seconds']}"


BY_KEY = {key_for(c): c for c in CONFIGS}
KEYS = tuple(BY_KEY)


def make_timeline():
    """Source先行予約と早期自己予約を別分類する時点会計を作る。

    引数: なし。
    返り値: typeは固定Timelineから予約の同原行位相条件だけを限定派生したクラス。
    """
    parsed = ast.parse(OLD.BASE_PATH.read_text(encoding='utf-8'))
    classes = [n for n in parsed.body if isinstance(n, ast.ClassDef) and n.name == 'Timeline']
    equal(len(classes), 1, '固定94 Timelineは一つ')
    tree = ast.Module(body=classes, type_ignores=[])
    changed = 0
    class Transform(ast.NodeTransformer):
        """早期自己要求をSource要求とみなす旧述語だけを変更する。"""

        def visit_Compare(self, node):
            """旧比較式一つを厳密に識別する。

            引数: node(ast.Compare)は比較式。
            返り値: ast.exprは元式又は早期要求除外を加えた式。
            """
            nonlocal changed
            if ast.unparse(node) == "order['protection_point'] is None":
                changed += 1
                return ast.parse("order['protection_point'] is None and order.get('entry_invalidation_point') is None", mode='eval').body
            return self.generic_visit(node)
    tree = Transform().visit(tree)
    equal(changed, 1, 'Timelineの同原行予約分類の限定変更数')
    space = dict(vars(BASE))
    exec(compile(ast.fix_missing_locations(tree), __file__ + ':固定94時点会計', 'exec'), space)
    return space['Timeline']


TIMELINE = make_timeline()


def accounting_function():
    """固定94の台帳会計へ本名政策と新要求分類だけを接続する。

    引数: なし。
    返り値: functionはbook/config/policyを受ける独立会計。価格やGo期待値を生成しない。
    """
    tree = ast.parse(textwrap.dedent(inspect.getsource(BASE.verify_book)))
    function = tree.body[0]
    expected = ["require(key in KEYS and book['key'] == key, 'Actor key')", "policy, cost, delay = key.split('_')",
                "config = {'policy': policy, 'slip_pts': int(cost[1:]), 'delay_seconds': int(delay[1:])}",
                "equal(book['config'], config, 'Actor config')"]
    equal([ast.unparse(n) for n in function.body[1:5]], expected, '固定94の設定4文')
    function.name = 'pure_accounting113'
    function.body = [function.body[0]] + function.body[5:]
    function.args.args = [ast.arg(arg=n) for n in ('book', 'config', 'policy')]
    changed = {'atr': 0, 'source': 0}
    for node in ast.walk(function):
        if not isinstance(node, ast.Dict):
            continue
        for i, k in enumerate(node.keys):
            if isinstance(k, ast.Constant) and k.value == 'atr_deferred_positions':
                node.values[i] = ast.parse("sum(p['atr'] is None or p['atr']['after_entry'] for p in saved.values()) if policy == 'S0' else 0", mode='eval').body
                changed['atr'] += 1
            if isinstance(k, ast.Constant) and k.value == 'source_exit_requests':
                equal(ast.unparse(node.values[i]), "sum((o['kind'] == 'exit' and o['protection_point'] is None for o in orders.values()))", 'Source要求の元式')
                node.values[i] = ast.parse("sum(o['kind'] == 'exit' and o['protection_point'] is None and o.get('entry_invalidation_point') is None for o in orders.values())", mode='eval').body
                changed['source'] += 1
    equal(changed, {'atr': 1, 'source': 1}, '限定派生2式')
    space = {**vars(BASE), 'Timeline': TIMELINE, 'verify_marks': OLD.verify_marks}
    exec(compile(ast.fix_missing_locations(tree), __file__ + ':固定94台帳会計', 'exec'), space)
    return space[function.name]


PURE_ACCOUNTING = accounting_function()


def verify_finance(book: dict, config: dict) -> dict:
    """全約定と所有を純算術で再読し、新失効の要求/実fillを別検算する。

    引数: book/config(dict)は保存された113の実口座と設定。
    返り値: dictはtotals/counts/positions/orders/timeline/book。原値を変えない。
    """
    equal(book['key'], key_for(config), '113本名key')
    equal(book['config'], config, '113本名設定')
    original = repr(book)
    result = PURE_ACCOUNTING(book, config, config['policy'])
    OLD.verify_source_reservations(book, result)
    early = [o for o in book['orders'] if o.get('entry_invalidation_point') is not None]
    need(config['policy'] in ('E100', 'E50') or not early, 'E以外に起動前自己返済なし')
    for order in early:
        need(order['kind'] == 'exit' and order['protection_point'] is None and not order['native_close_signal_id'] and not order['native_close_notice_id'], '早期/Source/必須追尾の区別')
        equal(order['reason'], '113取得時支持の否定とMACD失速/' + config['policy'], '早期離脱の本名理由')
        point = order['entry_invalidation_point']
        equal(point['exit_order_id'], order['id'], '早期純点と注文ID')
        equal(point['at'], order['request_time'], '早期要求時計')
        equal(point['phase'], 'after_source', 'Source処理後だけ早期要求')
        equal(order['request_quote']['time'], order['request_time'], '欠気配時も現在要求原行')
        equal(order['quantity'], point['snapshot']['remaining']-point['snapshot']['reserved'], '早期未予約全残')
    for fill in book['fills']:
        order = result['orders'][fill['order_id']]
        need(fill['quote']['source_line'] > order['request_quote']['source_line'], '要求後物理行')
        equal(fill.get('entry_invalidation', False), order.get('entry_invalidation_point') is not None, '早期実fillの識別子')
    latched = sum(bool(p.get('protection113', {}).get('final_state', {}).get('entry_invalidated', False)) for p in book['positions'])
    counts = {'entry_invalidated_positions': latched, 'entry_invalidation_exit_requests': len(early),
              'entry_invalidation_exit_fills': sum(f.get('entry_invalidation', False) for f in book['fills'])}
    for k, count in counts.items():
        equal(book['metrics'].get(k, 0), count, '113新metric/' + k)
    result['counts'].update(counts)
    equal(book['metrics']['timer_calls'], 0, '113の研究側timerなし')
    if config['policy'] != 'S0':
        fallback = sum(p['atr'] is None for p in book['positions'])
        equal(book['metrics'].get('atr_unknown_fallback_positions', 0), fallback, '113未知ATR固定幅')
        result['counts']['atr_unknown_fallback_positions'] = fallback
    equal(repr(book), original, '113金融原値不変')
    return {**result, 'book': book}
