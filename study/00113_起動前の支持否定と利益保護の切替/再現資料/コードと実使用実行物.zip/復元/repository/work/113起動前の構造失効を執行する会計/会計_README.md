# 113の独立会計・保存

ActorはActor停止.json、独立PはP停止.json、会計保存は会計停止.jsonで所有を分離する。旧112・高速F2・旧111を変更しない。現時点は手製人工のみで113市場は未実行。

24政策順はS0/W100/P100/P50/E100/E50×C0/C5×D0/D1。全注文・fill・返済allocation・Source所有・上限10mini・費用・遅延・物理行後fill・u/W少数点・残玉予約0・保存点DDをPythonの独立算術で照合する。早期失効注文はSource/通常保護と別分類し、要求と実fillも別計数する。既保護と旧12対照は生C/M/P/Bや金融値を隠さない。

固定94会計の設定4文とATR後取得metric分離を固定111から継承し、新しいSource要求数の述語1式とTimelineの同原行予約位相1式へ「早期自己要求をSource扱いしない」限定変更を加える。価格・利益をGoに問い合わせず、政策名を偽装しない。通常幅は全新政策で200/2A。

Root要求は `version=1,trial=113,fixed=true,market_native_read_authorized=true,stage`、FileRefはcondition/completion/code_stop/P_stop/actor_stop/protection_code。scenesは全予定順にsession/native/reference112/history_class/market_path。stageはfirst2/base54/full70。全70は元54認証再用+追加16再生、11/09は対象外。新しい市場固定はRootが所有し、113市場実行は後回しとする。

```powershell
python -X utf8 '保存する.py' --fixed '<絶対要求>' --sha256 '<SHA256>' --output '<未作成先>'
```

出力は結果.json/保存会計の確認.json/一覧.resources.jsonと全24×場数のtrades。全0行・null比率も残す。結果のActor設定/集計/場別/会計数/前後不変、正負実現額/勝負/平均利益損失/PF/全玉正益後赤字/起動後赤字/実保有秒/数量秒/保存点連結DDは112互換。新しい3metricと注文別「起動前失効」を追加する。CSV生成はRootが担当する。

人工6主はCore手製48/P/旧24全金融、7金融破壊、旧対照の純額/C/定義/Source偽装、0取引24/null、Viewer48再読、予定集合/遅延を扱う。Pは別3主。Raw再走・11/09本文・新金融Go実行・CSV生成は0。少数保存点と全原行証明の限界を区別する。
