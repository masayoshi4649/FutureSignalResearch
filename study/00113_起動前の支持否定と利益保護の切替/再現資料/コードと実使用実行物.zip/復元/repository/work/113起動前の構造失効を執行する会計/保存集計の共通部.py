"""113の金融集計と旧112全金融対照を、Goを呼ばない保存台帳の算術で扱う。"""

from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from types import FunctionType

import 金融の独立検算 as A


ROOT = Path(__file__).resolve().parents[2]
PREVIOUS_PATH = ROOT / 'work/111連続保護の独立保存/集計.py'
PREVIOUS_SHA = 'c6e6df9067da9452a978881325f3e96a677d946e3e5643eb3614d41684d0dbc0'
if hashlib.sha256(PREVIOUS_PATH.read_bytes()).hexdigest() != PREVIOUS_SHA:
    raise ValueError('停止111保存集計の実物SHA差')
SPEC = importlib.util.spec_from_file_location('113が再用する停止111保存集計', PREVIOUS_PATH)
OLD = importlib.util.module_from_spec(SPEC)
sys.path.insert(0, str(PREVIOUS_PATH.parent))
try:
    SPEC.loader.exec_module(OLD)
finally:
    sys.path.pop(0)
BASE, need, equal = A.BASE, A.need, A.equal
KEYS, BY_KEY = A.KEYS, A.BY_KEY
SPACE = {**vars(OLD), 'A': A, 'KEYS': KEYS, 'BY_KEY': BY_KEY}


def borrow(name: str):
    """機能: 固定111の政策非依存関数をcode同体で新しい本名環境へ結ぶ。

    引数: name(str)は事前に指定する金融集計又は保存再読関数名。
    返り値: functionは元codeと返り値仕様を維持した関数。
    """
    original = getattr(OLD, name)
    result = FunctionType(original.__code__, SPACE, name, original.__defaults__, original.__closure__)
    result.__kwdefaults__ = original.__kwdefaults__
    SPACE[name] = result
    return result


digest, load = OLD.digest, OLD.load
profit_statistics = borrow('profit_statistics')
holding_diagnostics = borrow('holding_diagnostics')
BASE_SUMMARIZE = borrow('summarize_book')
combine = borrow('combine')
source_projection = borrow('source_projection')
verify_source = borrow('verify_source')
verify_viewer = borrow('verify_viewer')


def summarize_book(book: dict, checked: dict) -> dict:
    """従来の実現損益統計を維持し、早期離脱の返済片を別分類する。

    引数: book/checked(dict)は113実口座と独立検算。
    返り値: dictはSource/利益保護/起動前失効を区別した場別統計。
    """
    row = BASE_SUMMARIZE(book, checked)
    groups = {}
    for label in ('Source', '保護', '起動前失効'):
        selected = {}
        for oid, order in checked['orders'].items():
            if order['kind'] != 'exit':
                continue
            actual = '起動前失効' if order.get('entry_invalidation_point') is not None else '保護' if order['protection_point'] is not None else 'Source'
            if actual == label:
                selected[oid] = order
        fills = [f for f in book['fills'] if f['order_id'] in selected]
        groups[label] = {'要求': len(selected), '要求枚': sum(o['quantity'] for o in selected.values()),
                         '約定': len(fills), '約定枚': sum(f['quantity'] for f in fills),
                         '返済片純額': sum((a['net_yen'] for f in fills for a in f['allocations']), OLD.ZERO)}
    row['注文別'] = groups
    equal(sum((v['返済片純額'] for v in groups.values()), OLD.ZERO), row['net_yen'], 'Source/利益保護/起動前失効の全返済純額')
    return row


def definition(policy: str) -> dict:
    """113の正確な政策定義を独立構成する。

    引数: policy(str)は本名政策。返り値: dictは起動/幅/警戒/早期離脱の全定義。
    """
    need(policy in ('S0', 'W100', 'P100', 'P50', 'E100', 'E50'), '113の本名政策')
    enabled = policy != 'S0'
    return {'version': 113, 'policy': policy, 'enabled': enabled,
            'threshold_points': (50 if policy in ('P50', 'E50') else 100) if enabled else 0,
            'normal_width_minimum': 200 if enabled else 0, 'atr_multiplier': 2 if enabled else 0,
            'warning_formula': '追加保護なし' if not enabled else 'M AND(C OR P)' if policy == 'W100' else 'M AND P',
            'technical_narrowing': policy in ('P100', 'P50', 'E100', 'E50'),
            'entry_invalidation_enabled': policy in ('E100', 'E50')}


def separate_definition(value, expected: dict) -> tuple:
    """Controlの定義と新fieldの無効を検査して112へ正規化する。

    引数: value(any)は全JSON部分木、expected(dict)は113定義。
    返り値: tuple[int,int]は定義版差と検査済み無効fieldの数。
    """
    count = disabled_count = 0
    disabled = {'entry_support': None, 'entry_support_eligible': False, 'entry_invalidated': False,
                'entry_invalidated_at': None, 'entry_invalidation_witness': None,
                'entry_support_break': 0, 'entry_invalidated_now': False, 'entry_exit_quantity': 0,
                'first_entry_invalidation': None, 'entry_exit_requests': None,
                'entry_invalidated_positions': 0, 'entry_invalidation_exit_requests': 0,
                'entry_invalidation_exit_fills': 0, 'entry_invalidation_point': None, 'entry_invalidation': False}
    if isinstance(value, list):
        children = value
    elif isinstance(value, dict):
        if 'definition' in value:
            need('entry' in value and 'normal_width' in value, '純Snapshotの正当な定義')
            equal(value['definition'], expected, '113本名定義の全値')
            prior = {k: v for k, v in expected.items() if k != 'entry_invalidation_enabled'}
            prior['version'] = 112
            value['definition'] = prior
            count += 1
        for name, empty in disabled.items():
            if name in value:
                equal(value.pop(name), empty, 'Controlの新field無効/' + name)
                disabled_count += 1
        children = list(value.values())
    else:
        children = []
    for child in children:
        a, b = separate_definition(child, expected)
        count += a
        disabled_count += b
    return count, disabled_count


def compare_reference112(value: dict, prior: dict) -> dict:
    """機能: 113の共通12冊とSource全値を旧112保存Nativeへ独立照合する。

    引数: value/prior(dict)は113 Nativeと認証済み旧112 Native。
    返り値: dictは12全金融JSON対照と許可版差の件数。完結性は別検査。
    """
    need(value['trial'] == 113 and prior['actual']['trial'] == 112, '113/112の明示版')
    equal(value['source'], prior['source'], '元Source111の全JSON同体')
    equal(value['actual']['scope'], prior['actual']['scope'], '113/112の場・限月・設定')
    details = {}
    for key in (k for k in KEYS if BY_KEY[k]['policy'] in ('S0', 'W100', 'P100')):
        left = deepcopy(value['actual']['books'][key])
        right = deepcopy(prior['actual']['books'][key])
        policy = BY_KEY[key]['policy']
        equal(left['config'], BY_KEY[key], '共通12の新本名設定')
        equal(right['config'], BY_KEY[key], '共通12の旧本名設定')
        need(left['stream_scope'].startswith('113:') and right['stream_scope'].startswith('112:'), '版付き説明Scope')
        changed = left['stream_scope'] != right['stream_scope']
        left['stream_scope'] = right['stream_scope'] = ''
        renamed = 0
        for position in left['positions']:
            need('protection112' not in position, '113へ旧監査field混入なし')
            if 'protection113' in position:
                position['protection112'] = position.pop('protection113')
                renamed += 1
        separated, disabled = separate_definition(left, definition(policy))
        equal(left, right, '113/112の旧3政策全金融JSON.' + key)
        details[key] = {'policy': policy, 'stream_scope_difference': changed, 'audit_field_renames': renamed,
                        'definition_snapshots': separated, 'disabled_fields': disabled, 'all_financial_equal': True}
    need(len(details) == 12, '旧3政策×4対照')
    trace = value['reference112']
    need(trace['comparisons'] == 12 and trace['all_financial_equal'] is True and trace['source_equal'] is True, 'Core旧112対照成功')
    equal(trace['details'], details, 'Goの対照版差件数とPython全値照合')
    return {'comparisons': 12, 'all_financial_equal': True, 'source_equal': True, 'details': details}


def inspect_scene(value: dict, prior: dict, protection, artificial: bool = False) -> dict:
    """機能: 113全24金融と独立P監査・元Source・旧12対照を結合する。

    引数: value/prior(dict)、protection(module)、artificial(bool)は113/112 Native・停止P・手製Source区分。
    返り値: dictはchecked/source/reference112。金融再生・原板再走査はしない。
    """
    actual = value['actual']
    need(value['version'] == 1 and value['trial'] == 113 and actual['version'] == 1 and actual['trial'] == 113
         and actual['complete'] is True, '113全24の完結Native')
    equal(actual['configurations'], list(A.CONFIGS), '113本名24設定と順序')
    equal(set(actual['books']), set(KEYS), '113全24冊集合')
    equal(actual['entry_grid_seconds'], None, '113の研究側新規時計なし')
    equal(actual['extra_opening_quiet_seconds'], 0, '113の研究側開始静観なし')
    equal(actual['explicit_timers'], 0, '113研究側timerなし')
    equal(actual['chart_seed_mode'], 'cold_each_session', '113当場cold')
    equal(actual['scope']['session'], value['source']['session'], '113のSource場')
    equal(actual['scope']['contract'], value['source']['contract'], '113のSource限月')
    equal(actual['counts']['publications'], len(actual['publications'] or []), '113公開数')
    equal(actual['counts']['resets'], len(actual['resets'] or []), '113reset数')
    context = {k: actual[k] for k in ('scope', 'publications', 'resets', 'counts', 'final_chart')}
    checked = {}
    for key, config in BY_KEY.items():
        book = actual['books'][key]
        equal(book['session'], actual['scope']['session'], '113全24の同場')
        equal(book['metrics']['rows'], actual['counts']['rows'], '113全24の原行数')
        equal(book['metrics']['bad_quote_rows'], actual['counts']['bad_quotes'], '113全24の欠気配数')
        finance = A.verify_finance(book, config)
        finance['protection_counts'] = protection.verify_protection(book, config, finance, context)
        checked[key] = finance
    return {'checked': checked, 'source': verify_source(value, artificial=artificial), 'reference112': compare_reference112(value, prior)}


def save_viewer(value: dict, output: Path, market_path: str) -> list[dict]:
    """機能: 本名113の全24実約定をViewer schema1へ新規保存する。

    引数: value(dict)、output(Path)、market_path(str)は検算済み113・新規先・価格参照。
    返り値: list[dict]は0約定を含む24資源。価格本文やHTTPを読まない。
    """
    resources = []
    sid = value['actual']['scope']['session']['id']
    for key in KEYS:
        name = f'113_{key}_{sid}.trades.jsonl'
        with (output / name).open('x', encoding='utf-8', newline='\n') as stream:
            for row in BASE.viewer_trades(value['actual']['books'][key]):
                stream.write(json.dumps(row, ensure_ascii=False, default=BASE.serial, allow_nan=False) + '\n')
        resources.append({'id': f'113_{key}_{sid}', 'title': f'起動水準と取得支持失効 {key} {sid}',
                          'symbol': 'NK225', 'product': 'NK225mini', 'session': sid, 'method_id': key,
                          'point_value': 100, 'pnl_format': 'trades', 'pnl_basis': 'net', 'pnl_path': name, 'market_path': market_path})
    return resources
