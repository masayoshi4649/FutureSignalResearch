"""113の独立P所有物と人工をActor/会計とは別に固定する。"""

import hashlib
import json
import subprocess
import sys
from pathlib import Path

import 会計の人工検査 as T


HERE = Path(__file__).resolve().parent


def sha(p):
    """指紋を計算する。

    引数: p(Path)はコード又は人工資料。
    返り値: strはSHA256。
    """
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    """独立Pの人工と全前後不変を停止記録へ保存する。

    引数: なし。
    返り値: dictは新P停止Ref。
    """
    target = HERE/'P停止.json'
    output = HERE/'P検査'
    if target.exists() or output.exists():
        raise ValueError('P停止は新規先')
    owned = {str(HERE/n):sha(HERE/n) for n in ['新保護の独立監査.py','保護監査の人工検査.py','Pを検査して停止する.py','P_README.md']}
    deps = {str(HERE/'金融の独立検算.py'):sha(HERE/'金融の独立検算.py'),str(HERE/'保存集計の共通部.py'):sha(HERE/'保存集計の共通部.py'),
            str(HERE/'会計の人工検査.py'):sha(HERE/'会計の人工検査.py'),str(T.MANIFEST):T.MANIFEST_SHA,
            str(HERE/'Actor停止.json'):'9f261c911946082c20b0bfc259a991cb045a533456187ec611732ec72a34133b',
            str(T.S.ROOT/'work/112支持否定と通常幅の独立P監査/P停止.json'):'c873e82630e647b9731e013e8be2786424818248503ec6765e797e49ef430048',
            str(T.S.ROOT/'work/112支持否定と通常幅の独立P監査/新保護の独立監査.py'):'7c43fe01133e028476ad5946b620cd566270eddbf76055fc8fdc18f8f8942a37'}
    deps.update({r['path']:r['sha256'] for r in T.S.load(T.MANIFEST)['Native'].values()})
    if any(sha(Path(p)) != h for p,h in deps.items()):
        raise ValueError('依存事前指紋差')
    p = subprocess.run([sys.executable,'-X','utf8',str(HERE/'保護監査の人工検査.py')],cwd=HERE,capture_output=True,text=True,encoding='utf-8',timeout=60)
    if p.returncode or 'Ran 3 tests' not in p.stderr:
        raise ValueError(p.stdout+p.stderr)
    output.mkdir()
    (output/'人工検査.txt').write_text(p.stdout+p.stderr,encoding='utf-8')
    if owned != {n:sha(Path(n)) for n in owned} or any(sha(Path(n)) != h for n,h in deps.items()):
        raise ValueError('P所有/依存の前後差')
    record = {'試行':113,'成功':True,'市場前':True,'所有ファイルSHA256':owned,'依存':deps,'所有前後同体':True,
              'API':'verify_protection(book:dict,config:dict,finance:dict,context:dict)->dict; 差はValueError',
              '主人工数':3,'Core手製会計数':48,'保存点':72,'exact':32,'bounded':40,'早期実要求':16,
              '人工確認':{'path':str(output/'人工検査.txt'),'sha256':sha(output/'人工検査.txt')},
              '限界':['少数保存点のexact/bounded。全Rawを別走しない。','同秒公開の原行Indexとreset統合順が未保存の場合、完全因果を証明しない。'],
              '市場/Raw/11月09本文':False,'金融Go再実行':False,'採用':False,'研究目標達成':False}
    target.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return {'成功':True,'停止':{'path':str(target),'sha256':sha(target)}}


if __name__ == '__main__':
    print(json.dumps(main(),ensure_ascii=False))
