"""113の独立Pを手計算とRoot手製48冊で検査する。"""

from copy import deepcopy
from collections import Counter
import unittest

import 会計の人工検査 as T


class Protection113Tests(unittest.TestCase):
    """市場を使わない早期失効・H・原値破壊の独立検査。"""

    @classmethod
    def setUpClass(cls):
        """固定人工と独立Pythonを準備する。

        引数: cls(type)は検査クラス。
        返り値: None。
        """
        cls.values, cls.p = T.fixtures(), T.protection()

    def test_48_with_nil_mark_and_source_priority(self):
        """Core48冊を会計とPで照合し、早期要求を通常保護と分ける。

        引数: self(Protection113Tests)は検査器。
        返り値: None。根拠は手製Sourceであり自然FAR生成ではない。
        """
        counts = Counter()
        for side in ('買い', '売り'):
            native = self.values[side]
            for key, book in native['actual']['books'].items():
                finance = self.p.FINANCE.verify_finance(book, book['config'])
                value = self.p.verify_protection(book, book['config'], finance, native['actual'])
                counts.update(value['counts'])
        self.assertEqual(counts['positions'], 48)
        self.assertEqual(counts['saved_points'], 72)
        self.assertEqual(counts['exact_points'], 32)
        self.assertEqual(counts['bounded_points'], 40)
        self.assertEqual(counts['entry_exit_orders'], 16)
        self.assertEqual(counts['entry_invalidation_points'], 16)
        self.assertEqual(counts['request_points_unstored'], 0)

    def test_hand_threshold_and_nil_invalidation(self):
        """H50の固定値と、nil価格での失効・H先更新を手計算する。

        引数: self(Protection113Tests)は検査器。
        返り値: None。期待値をGoへ問い合わせない。
        """
        for side in ('買い', '売り'):
            book = self.values[side]['actual']['books']['E100_C0_D0']
            audit = book['positions'][0]['protection113']
            before = deepcopy(audit['initial'])
            trace = deepcopy(audit['first_entry_invalidation'])
            trace['quote'] = None
            out, decision = self.p.expected_point(before, trace)
            self.assertTrue(out['entry_invalidated'])
            self.assertFalse(out['active'])
            self.assertIsNone(decision['whole_net_yen'])
            self.assertEqual(decision.get('entry_exit_quantity', 0), 0)
            trace['phase'] = 'after_source'
            trace['snapshot']['sequence'] += 1
            trace['quote'] = {'bid': before['entry']['price']+130, 'ask': before['entry']['price']+140}
            if before['entry']['side'] < 0:
                trace['quote'] = {'bid': before['entry']['price']-140, 'ask': before['entry']['price']-130}
            active, decision = self.p.expected_point(before, trace)
            self.assertTrue(active['active'])
            self.assertFalse(active.get('entry_invalidated', False))
            self.assertEqual(decision.get('entry_exit_quantity', 0), 0)
            # 先に失効済みなら後のH到達でもラッチは存続する。
            latched, decision = self.p.expected_point(out, trace)
            self.assertTrue(latched['active'] and latched['entry_invalidated'])
            self.assertEqual(decision['entry_exit_quantity'], latched['remaining']-latched['reserved'])
        self.assertEqual(self.p.fixed_parameters(self.values['買い']['actual']['books']['P50_C0_D0']['positions'][0]['protection113']['initial']['entry'])['threshold_points'], 50)

    def test_witness_and_disabled_field_corruptions(self):
        """固定支持・生M・距離・未来・原値・要求分類の破壊を拒否する。

        引数: self(Protection113Tests)は検査器。
        返り値: None。
        """
        native = self.values['買い']
        for name in ('M', 'distance', 'support', 'future', 'flag', 'quantity'):
            book = deepcopy(native['actual']['books']['E100_C0_D0'])
            p = book['positions'][0]
            if name == 'M':
                p['protection113']['final_state']['entry_invalidation_witness']['m'] = 1
            elif name == 'distance':
                p['protection113']['final_state']['entry_invalidation_witness']['signed_distance'] = 0
            elif name == 'support':
                p['protection113']['initial']['entry']['entry_support']['price'] += 5
            elif name == 'future':
                p['protection113']['initial']['entry']['entry_support']['published_at'] = p['entry_quote']['time']+1
            elif name == 'flag':
                [f for f in book['fills'] if f.get('entry_invalidation')][0]['entry_invalidation'] = False
            else:
                [o for o in book['orders'] if o.get('entry_invalidation_point')][0]['quantity'] += 1
            with self.subTest(name=name), self.assertRaises(ValueError):
                finance = self.p.FINANCE.verify_finance(book, book['config'])
                self.p.verify_protection(book, book['config'], finance, native['actual'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
