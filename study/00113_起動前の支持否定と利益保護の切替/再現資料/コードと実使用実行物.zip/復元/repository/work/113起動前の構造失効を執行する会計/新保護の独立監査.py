"""113の真の政策と幅・P必須を、Go未使用の有理数・三値演算で独立検算する。"""

from copy import deepcopy
from decimal import Decimal
from fractions import Fraction
import importlib.util
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
FINANCE_PATH = ROOT / 'work/113起動前の構造失効を執行する会計/金融の独立検算.py'
FINANCE_SPEC = importlib.util.spec_from_file_location('113純Pの独立会計', FINANCE_PATH)
FINANCE = importlib.util.module_from_spec(FINANCE_SPEC)
FINANCE_SPEC.loader.exec_module(FINANCE)
need, equal, number, money, BASE = FINANCE.need, FINANCE.equal, FINANCE.number, FINANCE.money, FINANCE.BASE


POLICIES = ('S0', 'W100', 'P100', 'P50', 'E100', 'E50')
TECH = ('P100', 'P50', 'E100', 'E50')
TRACE_NAMES = ('first_activation', 'first_narrowing', 'first_floor_update',
               'last_floor_update', 'first_floor_hit', 'first_all_reserved_hit', 'last')
PRICE_KEYS = ('gain_points', 'unit_net_yen', 'whole_net_yen', 'whole_floor',
              'peak_floor', 'structural_floor', 'protect_price')


def rational(value) -> Fraction:
    """機能: 有限数値を十進表現から有理数へ写す。

    引数: value(int/float/Fraction)は価格又は金額。
    返り値: Fractionは独立算術用の厳密値。不正ならValueError。
    """
    if isinstance(value, Fraction):
        return value
    need(isinstance(value, (int, float, Decimal)) and not isinstance(value, bool)
         and math.isfinite(value), '独立保護の有限数値')
    return Fraction(str(value))


def ceil_multiple(value, unit=5) -> int:
    """機能: 負値を含む数学的ceilで整数単位へ切り上げる。

    引数: value(数値)は対象、unit(int)は正の単位。
    返り値: intは切り上げ結果。
    """
    need(isinstance(unit, int) and unit > 0, '切上げ単位')
    scaled = rational(value) / unit
    return unit * (-((-scaled.numerator) // scaled.denominator))


def same_amount(actual, expected, label: str) -> None:
    """機能: 価格・半円金額を有理数として一致照合する。

    引数: actual/expected(数値又はNone)、label(str)は対象名。
    返り値: None。不一致ならValueError。
    """
    if actual is None or expected is None:
        equal(actual, expected, label)
    else:
        need(rational(actual) == rational(expected), label)


def truth_and(a: int, b: int) -> int:
    """機能: 未知0・偽1・真2のANDを独立評価する。

    引数: a/b(int)は三値。
    返り値: intは三値結果。
    """
    need(type(a) is int and type(b) is int and a in (0, 1, 2) and b in (0, 1, 2), '三値ANDの範囲')
    return 1 if 1 in (a, b) else 0 if 0 in (a, b) else 2


def truth_or(a: int, b: int) -> int:
    """機能: 未知0・偽1・真2のORを独立評価する。

    引数: a/b(int)は三値。
    返り値: intは三値結果。
    """
    need(type(a) is int and type(b) is int and a in (0, 1, 2) and b in (0, 1, 2), '三値ORの範囲')
    return 2 if 2 in (a, b) else 0 if 0 in (a, b) else 1


def warnings(latest: dict | None, policy: str, side: int) -> dict:
    """機能: 現在公表だけからMと収縮・構造の複合警戒を検算する。

    引数: latest(dict/None)は確定公表、policy(str)は政策、side(int)は売買符号。
    返り値: dictはc/m/p/b/warningの独立値。
    """
    c = m = p = b = 0
    if latest is not None:
        c, m = latest['c'], latest['m']
        if latest['close'] is not None and latest['prior_pivot'] is not None:
            p = 2 if side * (rational(latest['close']) - rational(latest['prior_pivot']['price'])) < 0 else 1
        if latest['bb'] is not None:
            b = latest['bb']['contraction']
    if policy in TECH:
        warning = truth_and(m, p)
    else:
        x = truth_or(c, p)
        if policy == 'B100':
            x = truth_or(x, b)
        warning = truth_and(m, x)
    return {'c': c, 'm': m, 'p': p, 'b': b, 'warning': warning}


def check_publication(publication: dict | None, entry: dict, at, context: dict) -> None:
    """機能: 公表の境界・未来なし・原値出典とBBの保存算術を検査する。

    引数: publication(dict/None)、entry(dict)、at(数値)、context(dict)は保存公表群。
    返り値: None。BB20終値窓の再形成や同秒原行順の証明は行わない。
    """
    observations = context.get('publications', [])
    prior_observations = [o for o in observations if o['at'] < at]
    resets = [r for r in context.get('resets', []) if r['at'] <= at]
    if publication is None:
        if prior_observations:
            newest = max(prior_observations, key=lambda o: o['at'])
            need(any(r['at'] >= newest['at'] for r in resets),
                 '既に届いた公表をresetなしで消さない')
        return
    p = publication
    equal(p['scope'], entry['scope'], '公表の同じ場限月')
    need(p['id'] and p['ordinal'] >= 1, '公表識別子')
    same_amount(p['end'], rational(p['start']) + 180, '確定3分幅')
    need(p['start'] >= entry['scope']['start'] and
         (rational(p['start']) - rational(entry['scope']['start'])) % 180 == 0,
         '場開始整合の確定3分足')
    need(p['end'] <= p['available_at'] <= at, '公表を利用可能になってから参照')
    need(p['c'] in (0, 1, 2) and p['m'] in (0, 1, 2), '公表三値')
    if p['v'] is not None:
        need(5 <= number(p['v'], '当場V') <= 1e6, '当場Vの範囲')
    if p['close'] is not None:
        need(number(p['close'], '公表終値') > 0, '公表終値の範囲')
    pivot = p['prior_pivot']
    if pivot is not None:
        equal(pivot['scope'], entry['scope'], 'pivot同場限月')
        equal(pivot['kind'], 'low' if entry['side'] == 1 else 'high', '買売対称pivot')
        need(pivot['id'] and pivot['price'] > 0 and
             pivot['center_start'] >= entry['scope']['start'] and
             pivot['center_end'] == pivot['center_start'] + 180 and
             pivot['center_end'] <= pivot['confirm_end'] <= pivot['published_at'] <= p['available_at'],
             'pivot中心と確認公表時計')
    bb = p['bb']
    if bb is not None:
        for key in ('scope', 'id', 'end', 'available_at'):
            equal(bb[key], p[key], 'BBの同一公表/' + key)
        need(bb['available_at'] <= bb['delivered_at'] <= at and bb['contraction'] in (0, 1, 2), 'BB配送時計と三値')
        need(0 <= bb['window_bars'] <= 20, 'BB当場窓数')
        if not bb['known']:
            need(all(bb[k] is None for k in ('sma', 'sigma', 'upper', 'lower', 'width', 'band_width', 'percent_b'))
                 and bb['contraction'] == 0, '未知BBの数値補完なし')
        else:
            need(bb['window_bars'] == 20 and bb['sma'] > 0 and bb['sigma'] >= 0, 'BB20の既知性')
            for actual, expected, name in ((bb['width'], 4 * bb['sigma'], 'BB幅'),
                                           (bb['upper'], bb['sma'] + 2 * bb['sigma'], 'BB上帯'),
                                           (bb['lower'], bb['sma'] - 2 * bb['sigma'], 'BB下帯'),
                                           (bb['band_width'], bb['width'] / bb['sma'], 'BB比率')):
                need(math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-9), name)
            need(bb['width'] != 0 or bb['percent_b'] is None, 'BBゼロ幅の除算なし')
    matches = [o for o in observations if o['at'] <= at and
               o['buy' if entry['side'] == 1 else 'sell'] == p]
    need(bool(matches), 'latestはRootActual当時公表原値の一つ')
    need(all(o['buy' if entry['side'] == 1 else 'sell']['ordinal'] <= p['ordinal']
             for o in prior_observations), '厳密に以前の新公表を古い値へ戻さない')
    observed_at = min(o['at'] for o in matches)
    need(not any(observed_at < r['at'] < at for r in resets),
         '厳密に後のresetで失効した古い公表を復活させない')


def definition_for(policy: str) -> dict:
    """113の本名政策定義をGo未使用で構築する。

    引数: policy(str)は政策ID。
    返り値: dictはH、幅、複合警戒、早期離脱の正確な定義。
    """
    need(policy in POLICIES, '113の本名政策')
    enabled = policy != 'S0'
    return {'version': 113, 'policy': policy, 'enabled': enabled,
            'threshold_points': (50 if policy in ('P50', 'E50') else 100) if enabled else 0,
            'normal_width_minimum': 200 if enabled else 0, 'atr_multiplier': 2 if enabled else 0,
            'warning_formula': '追加保護なし' if not enabled else 'M AND P' if policy in TECH else 'M AND(C OR P)',
            'technical_narrowing': policy in TECH, 'entry_invalidation_enabled': policy in ('E100', 'E50')}


def fixed_parameters(entry: dict) -> dict:
    """機能: 新規時のH・費用・通常幅・最低床を独立算出する。

    引数: entry(dict)は実新規時固定入力。
    返り値: dictは政策共通固定値。
    """
    need(entry['policy'] in POLICIES[1:] and entry['side'] in (-1, 1), '新保護政策と符号')
    need(1 <= entry['initial_quantity'] <= 10 and entry['slip_points'] in (0, 5), '初期枚数と費用')
    cost = 77 + 200 * entry['slip_points']
    atr = entry['atr']
    if atr is not None:
        need(atr['id'] and 0 < atr['value'] <= 1e6 and
             entry['scope']['start'] <= atr['available_at'] <= entry['at'], '取得時既知ATR')
    definition = definition_for(entry['policy'])
    minimum, multiplier = definition['normal_width_minimum'], definition['atr_multiplier']
    normal = minimum if atr is None else ceil_multiple(max(minimum, multiplier * rational(atr['value'])))
    return {'definition': definition, 'threshold_points': definition['threshold_points'],
            'normal_width': normal, 'atr_unknown_fallback': atr is None,
            'cost_per_unit_yen': cost, 'minimum_floor': ceil_multiple(rational(cost) / 100 + 5)}


def check_state_fixed(snapshot: dict, entry: dict) -> None:
    """機能: 保存状態の固定部分と数量・半円・基本不変条件を照合する。

    引数: snapshot/entry(dict)は状態と実取得入力。
    返り値: None。不整合ならValueError。
    """
    equal(snapshot['entry'], entry, '実取得固定入力の不変')
    for key, value in fixed_parameters(entry).items():
        if key == 'definition':
            compare_tree(snapshot[key], value, '本名政策の独立定義')
        else:
            equal(snapshot[key], value, '固定値/' + key)
    need(0 <= snapshot['reserved'] <= snapshot['remaining'] <= entry['initial_quantity'], '実残と予約とq0')
    need(rational(snapshot['closed_net_yen']) * 2 % 1 == 0 and
         rational(snapshot['whole_target_yen']) * 2 % 1 == 0, 'RとLの半円単位')
    need(snapshot['whole_target_yen'] >= 0 and snapshot['at'] >= entry['at'], 'L非負と取得以後')
    need(0 < snapshot['width_points'] <= snapshot['normal_width'], '幅の通常上限')
    equal(snapshot['finished'], snapshot['remaining'] == 0, '最終残0のFinished')
    if snapshot['active']:
        need(snapshot['activated_at'] is not None and snapshot['peak_points'] is not None and snapshot['floor_points'] is not None,
             '起動後の時計と峰と床')
        need(entry['at'] <= snapshot['activated_at'] <= snapshot['at'] and
             snapshot['floor_points'] >= snapshot['minimum_floor'], '起動時計と最低費用床')
    else:
        need(all(snapshot[k] is None for k in ('activated_at', 'peak_points', 'floor_points', 'narrowed_at'))
             and not snapshot['narrowed'] and snapshot['whole_target_yen'] == 0, '未起動の状態')
    if snapshot['narrowed']:
        need(entry['policy'] in TECH and snapshot['narrowed_at'] is not None and
             snapshot['activated_at'] <= snapshot['narrowed_at'] <= snapshot['at'], '狭幅ラッチ時計')
    else:
        equal(snapshot['narrowed_at'], None, '未狭幅時計')
    check_entry_snapshot(snapshot, entry)


def base_expected_point(before: dict, point: dict) -> tuple[dict, dict]:
    """機能: 保存点の直前状態から価格・会計・三値の式だけを独立再計算する。

    引数: before(dict)は当Advance直前、point(dict)は公表後の保存点原値。
    返り値: tuple[dict,dict]は期待Snapshot/Decision。Go期待値を呼ばない。
    """
    post = point['snapshot']
    entry = before['entry']
    need(not before['finished'] and post['sequence'] > before['sequence'] and post['at'] >= before['at'], 'Advanceの単調時計')
    need(post['remaining'] <= before['remaining'], '追加玉によるq0拡大なし')
    if post['remaining'] == before['remaining']:
        same_amount(post['closed_net_yen'], before['closed_net_yen'], '実残不変ならR不変')
    out = deepcopy(before)
    for key in ('at', 'sequence', 'remaining', 'reserved', 'closed_net_yen', 'latest'):
        out[key] = deepcopy(post[key])
    d = {**warnings(out['latest'], entry['policy'], entry['side']),
         **{key: None for key in PRICE_KEYS}, 'activated_now': False, 'narrowed_now': False,
         'width_source': '', 'protect_price_valid': False, 'floor_hit': False,
         'all_reserved_hit': False, 'free_quantity': out['remaining'] - out['reserved'],
         'eligible_exit_quantity': 0}
    n, r, R = out['remaining'], out['reserved'], rational(out['closed_net_yen'])
    if n == 0:
        out['finished'] = True
        return out, d
    if point['quote'] is None:
        return out, d
    q = point['quote']
    mark = q['bid'] if entry['side'] == 1 else q['ask']
    gain = entry['side'] * (rational(mark) - rational(entry['price']))
    unit = 100 * gain - rational(out['cost_per_unit_yen'])
    whole = R + n * unit
    d.update(gain_points=gain, unit_net_yen=unit, whole_net_yen=whole)
    eligible = whole >= entry['initial_quantity'] * 100 * out['threshold_points']
    if not out['active'] and eligible:
        out.update(active=True, activated_at=out['at'], peak_points=gain)
        d['activated_now'] = True
    if not out['active']:
        return out, d
    out['peak_points'] = max(rational(out['peak_points']), gain)
    if entry['policy'] in TECH and d['warning'] == 2 and not out['narrowed']:
        out.update(narrowed=True, narrowed_at=out['at'])
        d['narrowed_now'] = True
    if not out['narrowed']:
        width, label = out['normal_width'], '取得時固定通常幅'
    else:
        a = entry['atr']['value'] if entry['atr'] is not None else None
        v = out['latest']['v'] if out['latest'] is not None else None
        if a is None and v is None:
            width, label = before['width_points'], '狭幅尺度未知・既存幅保持'
        else:
            value = min(a, v) if a is not None and v is not None else a if a is not None else v
            label = '狭幅min取得時ATRと現V' if a is not None and v is not None else '狭幅取得時ATR' if a is not None else '狭幅現V'
            width = min(out['normal_width'], ceil_multiple(max(10, rational(value))))
    out['width_points'], d['width_source'] = width, label
    peak_floor = ceil_multiple(out['peak_points'] - rational(width))
    d['peak_floor'] = peak_floor
    floors = [out['minimum_floor'], peak_floor]
    if before['floor_points'] is not None:
        floors.append(before['floor_points'])
    target = rational(before['whole_target_yen'])
    fw = ceil_multiple((n * rational(out['cost_per_unit_yen']) + target - R) / (100 * n))
    d['whole_floor'] = fw
    floors.append(fw)
    pivot = out['latest']['prior_pivot'] if out['latest'] is not None else None
    if entry['policy'] in TECH and d['warning'] == 2 and pivot is not None and pivot['center_start'] >= entry['at']:
        structural = ceil_multiple(entry['side'] * (rational(pivot['price']) - entry['side'] * 5 - rational(entry['price'])))
        if structural > out['minimum_floor']:
            d['structural_floor'] = structural
            floors.append(structural)
    floor = max(floors)
    out['floor_points'] = floor
    out['whole_target_yen'] = max(rational(before['whole_target_yen']), R + n * (100 * floor - out['cost_per_unit_yen']))
    protect = rational(entry['price']) + entry['side'] * floor
    d.update(protect_price=protect, protect_price_valid=protect > 0,
             floor_hit=gain <= floor, all_reserved_hit=gain <= floor and r == n)
    if d['floor_hit'] and point['phase'] == 'after_source':
        d['eligible_exit_quantity'] = n - r
    return out, d


def compare_tree(actual, expected, label: str) -> None:
    """機能: 入れ子の独立計算値を有理数と厳密型で照合する。

    引数: actual/expected(任意のJSON値)、label(str)は経路。
    返り値: None。不一致ならValueError。
    """
    if isinstance(expected, dict):
        equal(set(actual), set(expected), label + '/キー')
        for key, value in expected.items():
            compare_tree(actual[key], value, label + '/' + key)
    elif isinstance(expected, bool):
        need(type(actual) is bool and actual is expected, label)
    elif isinstance(expected, (int, float, Fraction)):
        same_amount(actual, expected, label)
    else:
        equal(actual, expected, label)


def verify_exact_point(before: dict, point: dict) -> None:
    """機能: 直前値が判明する一点の保護式を全フィールド独立照合する。

    引数: before(dict)は直前純状態、point(dict)は当保存点。
    返り値: None。不一致ならValueError。
    """
    snapshot, decision = expected_point(before, point)
    compare_tree(point['snapshot'], snapshot, '独立Snapshot')
    compare_tree(point['decision'], decision, '独立Decision')


def base_verify_bounded_point(point: dict, previous: dict) -> None:
    """機能: 未保存区間を跨ぐ点を式の必要条件と旧Lの可解区間で監査する。

    引数: point(dict)は当保存点、previous(dict)は直前に保存された既知状態。
    返り値: None。区間全体の極値や初回性の証明とは扱わない。
    """
    s, d = point['snapshot'], point['decision']
    e, n, R, C = s['entry'], s['remaining'], rational(s['closed_net_yen']), rational(s['cost_per_unit_yen'])
    for k, value in warnings(s['latest'], e['policy'], e['side']).items():
        equal(d[k], value, '区間点の警戒/' + k)
    equal(d['free_quantity'], n - s['reserved'], '区間点の未予約数')
    if n == 0 or point['quote'] is None:
        need(all(d[k] is None for k in PRICE_KEYS) and not d['floor_hit'] and not d['all_reserved_hit']
             and not d['activated_now'] and not d['narrowed_now'] and d['eligible_exit_quantity'] == 0 and d['width_source'] == '',
             '価格なし又は残0の架空判断なし')
        return
    q = point['quote']
    g = e['side'] * (rational(q['bid'] if e['side'] == 1 else q['ask']) - rational(e['price']))
    u, w = 100 * g - C, R + n * (100 * g - C)
    for k, value in (('gain_points', g), ('unit_net_yen', u), ('whole_net_yen', w)):
        same_amount(d[k], value, '区間点の実評価/' + k)
    eligible = w >= e['initial_quantity'] * 100 * s['threshold_points']
    need(s['active'] or not eligible, '既知固定Hの必須起動漏れなし')
    if not s['active']:
        need(all(d[k] is None for k in ('whole_floor', 'peak_floor', 'structural_floor', 'protect_price'))
             and not d['floor_hit'] and not d['all_reserved_hit'] and not d['protect_price_valid']
             and not d['activated_now'] and not d['narrowed_now'] and d['eligible_exit_quantity'] == 0
             and d['width_source'] == '', '未起動価格床なし')
        return
    need(s['peak_points'] >= g and (previous['peak_points'] is None or s['peak_points'] >= previous['peak_points']), '起動以後の峰下限')
    same_amount(d['peak_floor'], ceil_multiple(rational(s['peak_points']) - rational(s['width_points'])), '峰と幅の床')
    if e['policy'] in TECH and d['warning'] == 2:
        need(s['narrowed'], '既知警戒で狭幅ラッチ必須')
    if not s['narrowed']:
        equal(s['width_points'], s['normal_width'], '通常幅の固定維持')
        equal(d['width_source'], '取得時固定通常幅', '通常幅の由来')
    else:
        # ----------------------------------------
        # 旧幅未知のまま現在尺度も未知なら、通常上限と床非緩和までを検査する。
        a = e['atr']['value'] if e['atr'] is not None else None
        v = s['latest']['v'] if s['latest'] is not None else None
        if a is not None or v is not None:
            expected = min(s['normal_width'], ceil_multiple(max(10, min(a, v) if a is not None and v is not None else a if a is not None else v)))
            equal(s['width_points'], expected, '既知尺度の狭幅')
            label = '狭幅min取得時ATRと現V' if a is not None and v is not None else '狭幅取得時ATR' if a is not None else '狭幅現V'
            equal(d['width_source'], label, '既知狭幅の由来')
        else:
            equal(d['width_source'], '狭幅尺度未知・既存幅保持', '未知狭幅の由来')
    sf = None
    pivot = s['latest']['prior_pivot'] if s['latest'] is not None else None
    if e['policy'] in TECH and d['warning'] == 2 and pivot is not None and pivot['center_start'] >= e['at']:
        value = ceil_multiple(e['side'] * (rational(pivot['price']) - e['side'] * 5 - rational(e['price'])))
        if value > s['minimum_floor']:
            sf = value
    same_amount(d['structural_floor'], sf, '区間点の適格構造床')
    candidates = [s['minimum_floor'], d['peak_floor']]
    if sf is not None:
        candidates.append(sf)
    fw = rational(d['whole_floor'])
    need(fw % 5 == 0, '全玉床5pt単位')
    low = R - n * C + 100 * n * (fw - 5)
    high = R - n * C + 100 * n * fw
    prior_low = max(Fraction(0), rational(previous['whole_target_yen']))
    upper = min(high, rational(s['whole_target_yen']))
    need(upper >= prior_low and upper > low, '旧Lが存在する有理数ceil区間')
    same_amount(s['whole_target_yen'], R + n * (100 * rational(s['floor_points']) - C), '価格更新後の全玉L厳密式')
    candidates.append(fw)
    if previous['floor_points'] is not None:
        candidates.append(previous['floor_points'])
    need(s['floor_points'] >= max(candidates), '区間床の既知候補と非緩和')
    same_amount(d['protect_price'], rational(e['price']) + e['side'] * rational(s['floor_points']), '区間保護価格')
    equal(d['protect_price_valid'], d['protect_price'] > 0, '保護価格の正値判定')
    equal(d['floor_hit'], g <= rational(s['floor_points']), '床等号を含むhit')
    equal(d['all_reserved_hit'], d['floor_hit'] and s['reserved'] == n, '全予約hit')
    equal(d['eligible_exit_quantity'], n - s['reserved'] if d['floor_hit'] and point['phase'] == 'after_source' else 0,
          '位相と予約を反映した要求量')


def entry_break(snapshot: dict) -> int:
    """固定取得支持を終値が厳密に逆抜けした三値を独立計算する。

    引数: snapshot(dict)は現在の保存状態。
    返り値: intは未知0・偽1・真2。動的Pを流用しない。
    """
    e, pub = snapshot['entry'], snapshot['latest']
    anchor = e.get('entry_support')
    if e['policy'] not in ('E100', 'E50') or not snapshot.get('entry_support_eligible', False) or anchor is None or pub is None or pub['close'] is None or pub['end'] <= e['at'] or pub['available_at'] > snapshot['at']:
        return 0
    return 2 if e['side'] * (rational(pub['close']) - rational(anchor['price'])) < 0 else 1


def check_entry_snapshot(snapshot: dict, entry: dict) -> None:
    """固定支持・失効ラッチ・初回witnessの保存値を独立検査する。

    引数: snapshot/entry(dict)は純状態と実取得入力。
    返り値: None。未来出典・動的P流用・ラッチ改変はValueError。
    """
    early = entry['policy'] in ('E100', 'E50')
    anchor = entry.get('entry_support')
    if anchor is not None:
        need(early, 'E以外へ取得時支持を混入しない')
        equal(anchor['scope'], entry['scope'], '取得時支持の場限月')
        equal(anchor['kind'], 'low' if entry['side'] == 1 else 'high', '取得時支持の方向')
        need(anchor['id'] and anchor['price'] > 0 and anchor['center_start'] >= entry['scope']['start']
             and anchor['center_end'] == anchor['center_start']+180
             and anchor['center_end'] <= anchor['confirm_end'] <= anchor['published_at'] <= entry['at'], '取得時既知の確定支持')
    eligible = early and anchor is not None and entry['side']*(rational(entry['price'])-rational(anchor['price'])) > 0
    equal(snapshot.get('entry_support_eligible', False), eligible, '取得時支持の適格距離')
    invalid = snapshot.get('entry_invalidated', False)
    witness, at = snapshot.get('entry_invalidation_witness'), snapshot.get('entry_invalidated_at')
    if not invalid:
        need(witness is None and at is None, '未失効のwitnessなし')
        return
    need(eligible and witness is not None and entry['at'] <= at <= snapshot['at'], '失効の適格支持と時計')
    equal(witness['at'], at, '初回witness時計')
    equal(witness['support'], anchor, '初回witnessは固定取得支持')
    need(witness['sequence'] <= snapshot['sequence'] and witness['phase'] in ('pre_fill', 'after_source'), '失効witnessの順序位相')
    pub = witness['publication']
    need(pub['close'] is not None and pub['end'] > entry['at'] and pub['available_at'] <= at, '取得後終了足と既知終値')
    signed = entry['side']*(rational(pub['close'])-rational(anchor['price']))
    need(signed < 0, '固定取得支持の厳密逆抜け')
    same_amount(witness['signed_distance'], signed, '固定支持からの符号付き距離')
    observed = warnings(pub, entry['policy'], entry['side'])
    for name in ('c', 'm', 'p', 'b'):
        equal(witness[name], observed[name], '失効witnessの生観測/' + name)
    equal(witness['m'], 2, '失効には生M真が必要')
    if snapshot['active']:
        need(at <= snapshot['activated_at'], '必須起動後の新失効を認めない')


def expected_point(before: dict, point: dict) -> tuple[dict, dict]:
    """旧保護の独立式へH先更新・固定支持失効の純算術を追加する。

    引数: before/point(dict)は直前状態と当保存点。
    返り値: tuple[dict,dict]は期待Snapshot/Decision。Goの計算結果を期待値にしない。
    """
    out, decision = base_expected_point(before, point)
    if out['remaining'] == 0:
        return out, decision
    broken = entry_break(out)
    if broken:
        decision['entry_support_break'] = broken
    if not out.get('entry_invalidated', False) and not out['active'] and broken == 2 and decision['m'] == 2:
        e, p = out['entry'], out['latest']
        out['entry_invalidated'], out['entry_invalidated_at'] = True, out['at']
        out['entry_invalidation_witness'] = {
            'at': out['at'], 'sequence': out['sequence'], 'phase': point['phase'],
            'support': deepcopy(e['entry_support']), 'publication': deepcopy(p),
            'signed_distance': e['side']*(rational(p['close'])-rational(e['entry_support']['price'])),
            **{k: decision[k] for k in ('c', 'm', 'p', 'b')},
        }
        decision['entry_invalidated_now'] = True
    if out.get('entry_invalidated', False) and point['phase'] == 'after_source' and decision['free_quantity']:
        decision['entry_exit_quantity'] = decision['free_quantity']
    return out, decision


def verify_bounded_point(point: dict, previous: dict) -> None:
    """旧床の有界監査と、新失効の観測可能な必要条件を分けて検査する。

    引数: point/previous(dict)は当点と直前保存値。
    返り値: None。未保存原行の初回性まで証明したとは扱わない。
    """
    base_verify_bounded_point(point, previous)
    s, d = point['snapshot'], point['decision']
    broken = entry_break(s) if s['remaining'] else 0
    equal(d.get('entry_support_break', 0), broken, '区間点の固定支持逆抜け')
    now = bool(s.get('entry_invalidated', False)) and s['entry_invalidation_witness']['sequence'] == s['sequence']
    equal(d.get('entry_invalidated_now', False), now, '失効の初回sequence')
    if previous.get('entry_invalidated', False):
        equal(s.get('entry_invalidation_witness'), previous['entry_invalidation_witness'], '失効witnessの非解除・非付替え')
        need(s.get('entry_invalidated', False), '失効ラッチを解除しない')
    if s['remaining'] and not s['active'] and broken == 2 and d['m'] == 2:
        need(s.get('entry_invalidated', False), '未起動の既知失効を放置しない')
    quantity = s['remaining']-s['reserved'] if s.get('entry_invalidated', False) and s['remaining'] and point['phase'] == 'after_source' else 0
    equal(d.get('entry_exit_quantity', 0), quantity, '失効ラッチと位相とfreeからの要求量')


def verify_entry_source(entry: dict, context: dict) -> None:
    """取得時支持を、当時までのside公表原値へ結合する。

    引数: entry/context(dict)は固定実取得とRoot公表保存値。
    返り値: None。同秒内配送原行が未保存の場合は候補範囲を超えた断定をしない。
    """
    if entry['policy'] not in ('E100', 'E50'):
        need(entry.get('entry_support') is None, 'Controlの固定支持なし')
        return
    side = 'buy' if entry['side'] == 1 else 'sell'
    observations = [o for o in context.get('publications', []) if o['at'] <= entry['at']]
    candidates = [o for o in observations if o[side]['available_at'] <= entry['at'] and o[side]['end'] <= entry['at']]
    anchor = entry.get('entry_support')
    if anchor is not None:
        matches = [o for o in candidates if o[side]['prior_pivot'] == anchor]
        need(matches, '取得支持は当時のside公表原値に存在する')
        need(all(o[side]['ordinal'] <= max(m[side]['ordinal'] for m in matches) for o in candidates if o['at'] < entry['at']), '取得支持を古いpivotへ戻さない')
        need(not any(r['at'] < entry['at'] and r['at'] > max(o['at'] for o in matches) for r in context.get('resets', [])), '取得前resetで支持を後付けしない')
    elif candidates:
        definite = [o for o in candidates if o['at'] < entry['at']]
        if definite:
            last = max(definite, key=lambda o: o['at'])
            reset = any(last['at'] <= r['at'] <= entry['at'] for r in context.get('resets', []))
            need(last[side]['prior_pivot'] is None or reset or any(o['at'] == entry['at'] and o[side]['prior_pivot'] is None for o in candidates), '既知適格出典を理由なく欠落させない')


def verify_saved_ownership(pid: str, trace: dict, finance: dict) -> None:
    """機能: 価格なし・最終残0を含め、保存点の実残/R/予約を実約定へ結合する。

    引数: pid(str)は実玉ID、trace(dict)は純保存点、finance(dict)は独立会計。
    返り値: None。気配nilでは同秒内原行順を特定せず可解範囲で照合する。
    """
    s, q = trace['snapshot'], trace['quote']
    timeline = finance['timeline']
    if q is not None:
        state = timeline.state_at(pid, {'quote': q, 'phase': trace['phase']})
        need(state is not None, '取得前の純保護点なし')
        equal(s['remaining'], state['quantity'], '純保存点の実残')
        same_amount(s['closed_net_yen'], state['realized'], '純保存点の実R')
        return
    fills = [f for f in finance['book']['fills'] if f['position_id'] == pid]
    by_index = {f['quote']['index']: f for f in fills}
    possible = [state for index, state in timeline.histories[pid]
                if by_index[index]['quote']['time'] <= trace['at']]
    need(any(state['quantity'] == s['remaining'] and
             rational(state['realized']) == rational(s['closed_net_yen']) for state in possible),
         'nil価格点の実残/Rは既発生約定のいずれか')
    lower = upper = 0
    for o in finance['orders'].values():
        if o['kind'] != 'exit' or o['position_id'] != pid:
            continue
        fill = timeline.fill_by_order.get(o['id'])
        end = fill['quote']['time'] if fill is not None else math.inf
        if o.get('cancel_time') is not None:
            end = min(end, o['cancel_time'])
        if o['request_time'] < trace['at'] < end:
            lower += o['quantity']
        if o['request_time'] <= trace['at'] <= end:
            upper += o['quantity']
    need(lower <= s['reserved'] <= min(s['remaining'], upper), 'nil価格点の予約は実要求/完了時刻の範囲内')


def verify_protection(book: dict, config: dict, finance: dict, context: dict) -> dict:
    """機能: 実会計と確定公表を結合して113の少数保護保存点を独立監査する。

    引数: book/config(dict)は実口座と本名設定、finance(dict)は独立会計結果、context(dict)はRootActual原値。
    返り値: dictは検査件数と証拠限界。不一致ならValueError。原値を変更しない。
    """
    original = repr((book, config, context))
    policy = config['policy']
    need(policy in POLICIES and config['slip_pts'] in (0, 5) and config['delay_seconds'] in (0, 1), '新保護宣言設定')
    equal(book['config'], config, 'Pの実設定')
    counts = {k: 0 for k in ('positions', 'saved_points', 'exact_points', 'bounded_points', 'nil_quote_points',
                            'finished_points', 'all_reserved_points', 'request_points', 'request_orders', 'request_points_unstored',
                            'before_snapshots', 'entry_invalidation_points', 'entry_exit_orders', 'entry_exit_points')}
    limits = ['保存された少数点の監査であり、全原行を独立再走する別エンジンではない。',
              'Raw未読のため、実要求後の次正常原行が最初だったことは自己記録だけでは証明しない。',
              '公表の出典・利用時刻を検査する。同秒内の配送原行Indexとreset統合順は保存されない場合、完全因果を証明しない。']
    orders = finance['orders']
    bound_requests = set()
    for p in book['positions']:
        counts['positions'] += 1
        need(p.get('protection111') is None, '113監査を旧111名へ隠さない')
        audit = p.get('protection113')
        own_orders = [o for o in orders.values() if o['position_id'] == p['id'] and (o['protection_point'] is not None or o.get('entry_invalidation_point') is not None)]
        if policy == 'S0':
            need(audit is None and not p['protection_active'] and not own_orders, 'S0追加保護なし')
            continue
        need(audit is not None, '新政策の純保護履歴必須')
        initial = audit['initial']
        e = initial['entry']
        equal(e['policy'], policy, '玉の政策')
        equal(e['side'], p['side'], '玉の買売符号')
        equal(e['initial_quantity'], p['initial_quantity'], '初期q0を部分返済後も維持')
        equal(e['price'], p['entry_price'], '実新規価格')
        equal(e['at'], p['entry_quote']['time'], '実新規時計')
        equal(e['slip_points'], config['slip_pts'], '玉の費用条件')
        equal(e['scope'], {'session': book['session']['id'], 'contract': context['scope']['contract'], 'start': book['session']['start']}, '玉の場限月')
        verify_entry_source(e, context)
        if p['atr'] is None:
            equal(e['atr'], None, '取得時ATR未知を後補完しない')
        else:
            equal(e['atr']['value'], p['atr']['value'], '取得時ATR原値')
            equal(e['atr']['available_at'], p['atr']['available'], '取得時ATR公表時刻')
        check_state_fixed(initial, e)
        need(initial['sequence'] == 0 and initial['at'] == e['at'] and not initial['active']
             and initial['remaining'] == e['initial_quantity'] and initial['reserved'] == 0
             and initial['closed_net_yen'] == 0 and initial['latest'] is None, '初期純状態')
        traces = [audit[name] for name in TRACE_NAMES if audit.get(name) is not None]
        traces += audit.get('requests', []) or []
        traces += audit.get('entry_exit_requests', []) or []
        if audit.get('first_entry_invalidation') is not None:
            traces.append(audit['first_entry_invalidation'])
        unique = {}
        for trace in traces:
            seq = trace['snapshot']['sequence']
            if seq in unique:
                equal(trace, unique[seq], '同sequence保存点同体')
            unique[seq] = trace
        previous = initial
        activation_seq = audit['first_activation']['snapshot']['sequence'] if audit['first_activation'] is not None else None
        narrowing_seq = audit['first_narrowing']['snapshot']['sequence'] if audit['first_narrowing'] is not None else None
        invalidation = audit.get('first_entry_invalidation')
        invalidation_seq = invalidation['snapshot']['sequence'] if invalidation is not None else None
        for seq, trace in sorted(unique.items()):
            counts['saved_points'] += 1
            s, d = trace['snapshot'], trace['decision']
            equal(d['activated_now'], seq == activation_seq, '初回起動フラグは保存した一点だけ')
            equal(d['narrowed_now'], seq == narrowing_seq, '初回狭幅フラグは保存した一点だけ')
            equal(d.get('entry_invalidated_now', False), seq == invalidation_seq, '初回失効フラグは保存した一点だけ')
            counts['entry_invalidation_points'] += bool(d.get('entry_invalidated_now', False))
            equal(trace['at'], s['at'], '点と純状態の時計')
            need(trace['phase'] in ('pre_fill', 'after_source'), '純評価の二段位相')
            check_state_fixed(s, e)
            check_publication(s['latest'], e, s['at'], context)
            if s.get('entry_invalidation_witness') is not None:
                witness = s['entry_invalidation_witness']
                check_publication(witness['publication'], e, witness['at'], context)
            verify_saved_ownership(p['id'], trace, finance)
            need(s['sequence'] > previous['sequence'] and s['at'] >= previous['at']
                 and s['remaining'] <= previous['remaining'] and s['whole_target_yen'] >= previous['whole_target_yen'],
                 '保存点のsequence/数量/L単調性')
            if previous['floor_points'] is not None:
                need(s['floor_points'] >= previous['floor_points'], '床を不利に緩めない')
            if previous['active']:
                need(s['active'] and s['activated_at'] == previous['activated_at'], '起動を取消さない')
            if previous['narrowed']:
                need(s['narrowed'] and s['narrowed_at'] == previous['narrowed_at'], '狭幅の初回警戒ラッチ')
            if trace['quote'] is not None and s['remaining'] > 0:
                q = trace['quote']
                equal(q['time'], trace['at'], '現在原行の価格時計')
                mark = q['bid'] if e['side'] == 1 else q['ask']
                mtm = {'quote': q, 'phase': trace['phase'], 'quantity': s['remaining'], 'reserved': s['reserved'],
                       'mark_price': mark, 'gain_points': d['gain_points'], 'unit_net': d['unit_net_yen'],
                       'realized_net': s['closed_net_yen'], 'whole_net': d['whole_net_yen']}
                finance['timeline'].verify_position_point(p['id'], mtm)
            else:
                counts['nil_quote_points'] += trace['quote'] is None
                counts['finished_points'] += s['remaining'] == 0
            before = trace.get('before_snapshot', trace.get('before'))
            if before is not None:
                counts['before_snapshots'] += 1
                check_state_fixed(before, e)
                need(before['sequence'] + 1 == s['sequence'], '直前Snapshotの隣接sequence')
                verify_exact_point(before, trace)
                counts['exact_points'] += 1
            elif seq == previous['sequence'] + 1:
                verify_exact_point(previous, trace)
                counts['exact_points'] += 1
            elif d['activated_now'] or d.get('entry_invalidated_now', False):
                # ----------------------------------------
                # 初回起動まではL/峰/床/狭幅が存在せず、起動直前の価格状態を一意に定められる。
                synthetic = deepcopy(initial)
                synthetic.update(at=trace['at'], sequence=seq-1, remaining=s['remaining'], reserved=s['reserved'], closed_net_yen=s['closed_net_yen'])
                for name in ('entry_invalidated', 'entry_invalidated_at', 'entry_invalidation_witness'):
                    if name in previous:
                        synthetic[name] = deepcopy(previous[name])
                verify_exact_point(synthetic, trace)
                counts['exact_points'] += 1
            else:
                verify_bounded_point(trace, previous)
                counts['bounded_points'] += 1
            if d['all_reserved_hit']:
                counts['all_reserved_points'] += 1
            order_id = trace['exit_order_id']
            after = trace.get('after_request')
            if order_id:
                need(order_id in orders and trace['phase'] == 'after_source' and d['eligible_exit_quantity'] + d.get('entry_exit_quantity', 0) > 0, '実保護要求との一意結合')
                o = orders[order_id]
                need(o['position_id'] == p['id'] and o['quantity'] == (d.get('entry_exit_quantity', 0) or d['eligible_exit_quantity']), '実要求所有と枚数')
                equal(o['request_time'], trace['at'], '実要求時計')
                if d.get('entry_exit_quantity', 0):
                    equal(o.get('entry_invalidation_point'), trace, '早期要求の全純点')
                    equal(o['request_quote']['time'], trace['at'], '早期要求の現在原行時計')
                else:
                    equal(o['request_quote'], trace['quote'], '床hitと同じ現在原行要求')
                need(after is not None, '予約後再同期保存')
                expected_after = deepcopy(s)
                expected_after.update(sequence=s['sequence']+1, reserved=s['reserved']+o['quantity'])
                equal(after, expected_after, 'nil価格の実予約後はsequenceと予約だけ変更')
                bound_requests.add(order_id)
                counts['request_points'] += 1
                counts['entry_exit_points'] += bool(d.get('entry_exit_quantity', 0))
            else:
                equal(after, None, '要求なしの再同期なし')
                need(d['eligible_exit_quantity'] == 0 and d.get('entry_exit_quantity', 0) == 0, '要求可能量を放置しない')
            previous = after if after is not None else s
        last = audit['last']
        need(last is not None, '最終純評価保存')
        final = last.get('after_request') or last['snapshot']
        equal(audit['final_state'], final, 'FinalStateは実最終Advance')
        equal(invalidation is not None, bool(final.get('entry_invalidated', False)), '失効ラッチと初回保存の有無')
        for field, actual in (('remaining', p['quantity']), ('reserved', p['reserved']), ('closed_net_yen', p['realized_net']),
                              ('active', p['protection_active']), ('floor_points', p['floor_gain'])):
            equal(final[field], actual, '実最終所有と純状態/' + field)
        need(final['finished'] and p['quantity'] == 0, 'セッション末にFinished')
        equal(final['sequence'], audit['evaluations'] + audit['resets'] + len(own_orders), '評価/reset/実予約再同期のsequence保存則')
        need(0 <= audit['missing_quote'] <= audit['evaluations'] and audit['resets'] >= 0, '欠気配とreset件数')
        need(audit['evaluations'] >= len(unique) and audit['missing_quote'] >= sum(t['quote'] is None for t in unique.values())
             and audit['resets'] <= len(context.get('resets', [])), '保存点数と評価/欠気配/reset数の整合')
        activation = audit['first_activation']
        equal(activation is not None, final['active'], '起動保存の有無')
        if activation is not None:
            need(activation['decision']['activated_now'], '初起動のDecision')
            equal(activation['snapshot']['activated_at'], activation['at'], '初起動時計')
            equal(audit['first_floor_update'], activation, '初起動点が最初の床設定')
            need(audit['last_floor_update'] is not None, '起動後の最後の床設定')
            equal(audit['last_floor_update']['snapshot']['floor_points'], final['floor_points'], '最終床は最後に保存した床更新')
        else:
            equal(audit['first_floor_update'], None, '未起動の床更新なし')
            equal(audit['last_floor_update'], None, '未起動の最後の床更新なし')
        narrowing = audit['first_narrowing']
        equal(narrowing is not None, final['narrowed'], '狭幅保存の有無')
        if narrowing is not None:
            need(narrowing['decision']['narrowed_now'] and narrowing['decision']['warning'] == 2, '初狭幅は複合警戒')
        if audit['first_floor_hit'] is not None:
            need(audit['first_floor_hit']['decision']['floor_hit'], '初hitのDecision')
            equal(audit['first_floor_hit']['snapshot']['sequence'],
                  min(t['snapshot']['sequence'] for t in unique.values() if t['decision']['floor_hit']), '保存点内の初hit')
        if audit['first_all_reserved_hit'] is not None:
            need(audit['first_all_reserved_hit']['decision']['all_reserved_hit'], '初全予約hitのDecision')
        for o in own_orders:
            counts['request_orders'] += 1
            counts['entry_exit_orders'] += o.get('entry_invalidation_point') is not None
            if o['id'] not in bound_requests:
                counts['request_points_unstored'] += 1
            expected_reason = ('111' if policy == 'W100' else '112' if policy == 'P100' else '113') + '一定利益の必須追尾/' + policy
            if o.get('entry_invalidation_point') is not None:
                expected_reason = '113取得時支持の否定とMACD失速/' + policy
            need(o['reason'] == expected_reason, '本名政策の自己保護要求理由')
            if o['status'] == 'filled':
                fills = [f for f in book['fills'] if f['order_id'] == o['id']]
                need(len(fills) == 1, '保護要求に実約定一つ')
                q = fills[0]['quote']
                need(q['index'] > o['request_quote']['index'] and q['source_line'] > o['request_quote']['source_line']
                     and q['time'] >= o['request_time'] + config['delay_seconds'], '後続の実原行と遅延条件')
                need(fills[0]['price'] == (q['bid'] if p['side'] == 1 else q['ask']), '実BBO約定を床価格へ置換しない')
    if counts['bounded_points']:
        limits.append('BeforeSnapshotの無い非隣接点は旧Lの可解区間・床下限・非緩和を検査し、旧LからのF_W完全一致や区間極値の初回性は未証明。')
    if counts['request_points_unstored']:
        limits.append('純Snapshotを保存しない中間要求は独立会計と要求MTMまで。全純保護式を証明した要求と別計数。')
    equal(repr((book, config, context)), original, 'P監査は原値非変更')
    return {'complete': True, 'method': 'Go未使用の有理数・三値による少数保存点監査', 'counts': counts, 'limits': limits}
