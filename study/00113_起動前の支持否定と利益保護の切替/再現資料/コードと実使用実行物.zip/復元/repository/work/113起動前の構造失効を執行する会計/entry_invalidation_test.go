package miniprotect

import (
	"testing"

	legacy "github.com/masayoshi4649/SessionTradeExecuter/continuousactor112"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor113"
)

// entryPublication113 は取得前の固定支持と取得後の逆抜けを別公表に保存します。
//
// 引数: side(int)、ordinal(uint64)、broken(bool)は売買・公表順・固定支持否定です。
// 返り値: guard.Publicationは未来価格を参照しない手製の確定3分公表です。
func entryPublication113(side int, ordinal uint64, broken bool) guard.Publication {
	p := publication113(side, ordinal, false)
	anchor, close := 950.0, 960.0
	if broken {
		close = 940
	}
	if side < 0 {
		anchor, close = 2000-anchor, 2000-close
	}
	p.PriorPivot.Price, p.Close = anchor, &close
	// 失効時には動的Pを偽にする別pivotを公表し、固定anchorとの混同を検出する。
	if broken {
		dynamic := 930.0
		if side < 0 {
			dynamic = 2000 - dynamic
		}
		p.PriorPivot.Price = dynamic
	}
	return p
}

// earlyFixture113 は買売・欠気配・Source先行予約・H先到達を全24で執行します。
//
// 引数: t(*testing.T)、side(int)、sourceClose(int)、bad/activate(bool)は人工条件です。
// 返り値: fixture94は手製原行と全24の実金融結果。Rawや自然FAR信号を用いません。
func earlyFixture113(t *testing.T, side, sourceClose int, bad, activate bool) fixture94 {
	t.Helper()
	actors, old := newActors113(t)
	source, s := newFixtureSource94(), session94()
	f := fixture94{Session: s, Scope: "113取得支持の手製API。Raw・自然FAR信号なし。", Steps: []fixtureStep94{}, Timers: []fixtureTimer94{}}
	seconds := []float64{0, 1, 180, 180, 181, 360, 361}
	moves := []float64{0, 0, -100, -90, -80, -70, -60}
	if activate {
		moves[2], moves[3], moves[4] = 130, 0, 0
	}
	for i, sec := range seconds {
		o := observation94(s, side, int64(i), sec, moves[i], 20)
		if i == 2 && bad {
			o.QuoteOK = false
		}
		if i == 0 || i == 2 || i == 5 {
			ordinal := uint64(1)
			if i == 2 {
				ordinal = 3
			}
			if i == 5 {
				ordinal = 4
			}
			for _, dir := range []int{1, -1} {
				p := entryPublication113(dir, ordinal, i == 2)
				for _, b := range actors {
					if err := b.SetPublication(o.Time, dir, p); err != nil {
						t.Fatal(err)
					}
				}
				for _, b := range old {
					if err := b.SetPublication(o.Time, dir, p); err != nil {
						t.Fatal(err)
					}
				}
			}
		}
		news := []native.Signal{}
		if i == 0 {
			news = append(news, birth94("早期A", side, 5))
		}
		if i == 2 && sourceClose > 0 {
			news = append(news, close94("早期元部分", "早期A", side, sourceClose))
		}
		if i == 5 && sourceClose < 5 {
			news = append(news, close94("早期元残", "早期A", side, 5-sourceClose))
		}
		batch := source.step(t, o, int64(i+300), news, nil)
		f.Steps = append(f.Steps, feed94(t, actors, o, batch))
		for _, b := range old {
			if err := b.OnNativeStep(o, batch.Delta.SourceLine, []legacy.NativeBatch{{Method: batch.Method, Delta: batch.Delta}}); err != nil {
				t.Fatal(err)
			}
		}
		compareEvery113(t, actors, old)
		if i == 2 {
			for _, b := range actors {
				if b.result.Config.Policy != "E100" && b.result.Config.Policy != "E50" {
					continue
				}
				p := b.Snapshot().Positions[0]
				if activate {
					if !p.ProtectionActive || p.Protection113.FinalState.EntryInvalidated {
						t.Fatal("H先到達より先に失効した")
					}
				} else {
					if p.ProtectionActive || !p.Protection113.FinalState.EntryInvalidated || p.Protection113.FirstEntryInvalidation == nil {
						t.Fatal("起動前失効と保護起動の混同")
					}
					if p.Protection113.FinalState.Entry.EntrySupport.Price == p.Protection113.FinalState.Latest.PriorPivot.Price {
						t.Fatal("固定支持を動的pivotで付替え")
					}
					want := 5 - sourceClose
					if len(p.Protection113.EntryExitRequests) != 0 && want == 0 {
						t.Fatal("Source全予約後に追加予約")
					}
					if want > 0 && (len(p.Protection113.EntryExitRequests) != 1 || p.Protection113.EntryExitRequests[0].Decision.EntryExitQuantity != want) {
						t.Fatal("Source部分予約後のfreeが違う")
					}
				}
			}
		}
	}
	f.Actors = finish94(t, actors)
	for _, b := range old {
		if _, err := b.Finish(); err != nil {
			t.Fatal(err)
		}
	}
	compareEvery113(t, actors, old)
	for _, b := range f.Actors {
		if b.Config.Policy != "E100" && b.Config.Policy != "E50" {
			continue
		}
		p := b.Positions[0]
		if !activate && (!p.Protection113.FinalState.EntryInvalidated || p.ProtectionActive) {
			t.Fatal("回復公表で失効解除又は偽の保護起動")
		}
		if sourceClose < 5 && !activate {
			if b.Metrics.EntryInvalidationExitRequests != 1 || b.Metrics.EntryInvalidationExitFills != 1 || b.Metrics.ProtectionExitRequests != 0 {
				t.Fatal("早期要求・実fillと必須保護metricを混同")
			}
			for _, fill := range b.Fills {
				if fill.EntryInvalidation && (fill.Quantity != 5-sourceClose || fill.Quote.Index <= 2 || fill.Quote.Time < s.Start+1980+float64(b.Config.DelaySeconds)) {
					t.Fatal("早期fill数量/原行/遅延")
				}
			}
		}
	}
	return f
}

// TestContinuous113EntryInvalidation は買売鏡像・nilMark・Source部分と全予約を検査します。
//
// 引数: t(*testing.T)は検査器。
// 返り値: なし。全24の旧12対照も各受理原行とFinishで比較します。
func TestContinuous113EntryInvalidation(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, qty := range []int{0, 2, 5} {
			earlyFixture113(t, side, qty, true, false)
		}
		earlyFixture113(t, side, 2, false, false)
		earlyFixture113(t, side, 2, false, true)
	}
}
