"""Source出生で同じ11/06実玉を結び、固定支持失効が成立しなかった保存票を確認する。"""

import importlib.util
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("saved_context113", HERE / "当時値を抽出する.py")
assert SPEC and SPEC.loader
CONTEXT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CONTEXT)
SIGNAL = "2026-11-06_Day-NK225mini-D164_15-000030"


def build() -> dict:
    """
    機能: Rootが指定した売7枚実玉をP/EのSource出生で結び、失効未成立の原保存票を返す。
    引数: なし。許可済み全70正本と11/06Day Nativeだけを参照。
    返り値: dictの時刻・支持・公表・予約・実返済の根拠。P/E収益差は計算しない。
    """
    result = CONTEXT.read_json(CONTEXT.BASE / "結果.json", CONTEXT.RESULT_SHA)
    market = CONTEXT.read_json(CONTEXT.MARKET, CONTEXT.MARKET_SHA)
    ref = next(row for row in result["Native参照"] if row["session"] == "2026-11-06_Day")
    market_ref = next(row["native"] for row in market["results"] if row["session"] == ref["session"])
    if market_ref != {"path": ref["path"], "sha256": ref["sha256"]}:
        raise ValueError("当場Nativeの完了参照差")
    native = CONTEXT.read_json(Path(ref["path"]), ref["sha256"], True)
    p_positions = [p for p in native["actual"]["books"]["P100_C0_D0"]["positions"] if p["source"]["signal_id"] == SIGNAL]
    e_book = native["actual"]["books"]["E100_C0_D0"]
    e_positions = [p for p in e_book["positions"] if p["source"]["signal_id"] == SIGNAL]
    if len(p_positions) != 1 or len(e_positions) != 1:
        raise ValueError("同Source出生のP/E結合が一意でない")
    p, e = p_positions[0], e_positions[0]
    if p["source"] != e["source"] or p["source_hold_id"] != e["source_hold_id"] or p["entry_quote"] != e["entry_quote"] or e["entry_price"] != 57420 or e["side"] != -1 or e["initial_quantity"] != 7:
        raise ValueError("指定された同じ実入口でない")
    audit = e["protection113"]
    entry = audit["initial"]["entry"]
    support = entry["entry_support"]
    final = audit["final_state"]
    if support["price"] != 57570 or not final["entry_support_eligible"] or final.get("entry_invalidated", False) or final["active"] or audit.get("first_entry_invalidation") is not None:
        raise ValueError("対象の支持/失効/未起動事実と差")
    close_orders = [row for row in e_book["orders"] if row["position_id"] == e["id"] and row["kind"] == "exit"]
    close_fills = [row for row in e_book["fills"] if row["position_id"] == e["id"] and row["action"] == "close"]
    notices = [row for row in e_book["source_events"] if row["hold_id"] == e["source_hold_id"] and row["kind"] == "close_notice"]
    if len(close_orders) != 1 or len(close_fills) != 1 or len(notices) != 1:
        raise ValueError("対象の単一Source返済と差")
    order, fill, notice = close_orders[0], close_fills[0], notices[0]
    if order["quantity"] != 7 or fill["quantity"] != 7 or notice["actual_pending_before"] != 0 or notice["actual_free_before"] != 7 or notice["actual_exit_requested"] != 7 or order["reason"] != "source_end/D164_15":
        raise ValueError("Source予約前後の保存値と差")
    publications = native["actual"]["publications"]
    held = []
    for i, row in enumerate(publications):
        if entry["at"] < row["at"] <= fill["quote"]["time"]:
            direction = row["sell"]
            if direction["end"] > entry["at"]:
                signed_distance = -(direction["close"] - support["price"])
                held.append({"publication_id": direction["id"], "at": row["at"], "at_jst": CONTEXT.clock(row["at"]), "end": direction["end"], "end_jst": CONTEXT.clock(direction["end"]), "close": direction["close"], "m": CONTEXT.TRUTH[direction["m"]], "signed_fixed_support_distance": signed_distance, "fixed_support_break": signed_distance < 0, "technical": CONTEXT.technical(publications, i, -1)})
    if len(held) != 3 or any(row["fixed_support_break"] for row in held) or held[-1]["publication_id"] != final["latest"]["id"]:
        raise ValueError("保有中3公表と最終既知支持否定falseの証拠差")
    entry_index, same_clock = CONTEXT.prior_entry_index(publications, entry["at"])
    native_after = hashlib.sha256(Path(ref["path"]).read_bytes()).hexdigest()
    if native_after != ref["sha256"]:
        raise ValueError("当場Nativeが前後で変化")
    atr = entry["atr"]["value"]
    return {"試行": 113, "成功": True, "対象": "11月06日Dayの13:52:13売7枚、P100 p29とSource出生同体のE100", "Native": market_ref, "金融完了": {"path": str(CONTEXT.MARKET), "sha256": CONTEXT.MARKET_SHA}, "独立結果": {"path": str(CONTEXT.BASE / "結果.json"), "sha256": CONTEXT.RESULT_SHA}, "Pの比較用途": "Source出生/実入口の同体だけ。収益差の比較は他担当。", "P_position_id": p["id"], "E_position_id": e["id"], "source": e["source"], "source_hold_id": e["source_hold_id"], "entry_quote": e["entry_quote"], "entry_jst": CONTEXT.clock(entry["at"]), "entry_price": e["entry_price"], "initial_quantity": 7, "anchor": support, "anchor_distance_points": 150, "atr_entry": atr, "anchor_distance_atr": 150 / atr, "anchor_age_at_entry_seconds": entry["at"] - support["published_at"], "entry_technical": CONTEXT.technical(publications, entry_index, -1), "entry_same_clock_publications": same_clock, "held_publications": held, "last_publication": final["latest"], "first_activation": audit["first_activation"], "first_invalidation": audit.get("first_entry_invalidation"), "entry_exit_requests": audit.get("entry_exit_requests", []), "source_close_notice": notice, "exit_order": order, "exit_fill": fill, "exit_request_jst": CONTEXT.clock(order["request_time"]), "exit_fill_jst": CONTEXT.clock(fill["quote"]["time"]), "entry_to_close_seconds": fill["quote"]["time"] - entry["at"], "final_realized_net_yen": e["realized_net"], "observed_factors": {"anchor_eligible": True, "all_published_fixed_support_break_false": True, "last_m_true": held[-1]["m"] == "true", "preexisting_exit_reservation_at_source_notice": False, "quote_at_source_request_already_above_anchor": order["request_quote"]["ask"] > support["price"], "next_three_minute_end_known_schedule": CONTEXT.clock(held[-1]["end"] + 180)}, "Native前後不変": True, "Raw本文読取": 0, "価格CSV読取": 0, "11月09本文読取": 0, "金融再実行": False, "閾値変更": False, "限界": ["支持まで150ptあることと、その距離が最適かは別。最適閾値やモデル損切り額を決定しない。", "現在BBOが最後の確定Closeより先に支持外へ動いたことはSource要求quoteで確認できるが、最初のBBO支持越え時計はこの保存値だけでは未確定。", "14:03の足は保有後なので実値を読まず、既知の3分時計の終端予定だけを示す。", "15分の当時snapshotは未保存。保有後の回復や仮想利益は扱わない。"]}


def main() -> None:
    """
    機能: 指定無作用例の小さい根拠JSONを新規保存する。
    引数: CLI引数なし。
    返り値: None。原保存値と差があれば非0終了。
    """
    value = build()
    path = HERE / "11月06日の無作用.json"
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "distance_atr": value["anchor_distance_atr"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
