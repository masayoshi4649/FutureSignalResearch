"""当時公表の時間境界と符号・未知伝播を手製で確認する。市場本文は読まない。"""

import importlib.util
from pathlib import Path
import unittest


HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("context113_test", HERE / "当時値を抽出する.py")
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def publication(end: int, hist: float, ema8: float, ema21: float, close: float, delivered: int | None = None) -> dict:
    """
    機能: frame.startが場開始、Publication.startが当足開始の手製公表を作る。
    引数: end(int)は足終端、hist/ema8/ema21/close(float)は指標、delivered(int|None)は公表時計。
    返り値: dictの手製買売公表。
    """
    at = end if delivered is None else delivered
    base = {"scope": {"session": "人工", "contract": "人工", "start": 0}, "id": str(end), "ordinal": end // 180, "start": end - 180, "end": end, "available_at": at, "c": 1, "v": 10, "prior_pivot": None, "bb": {"known": False, "contraction": 0}}
    return {"at": at, "frame_sha256": "a" * 64, "result_sha256": "b" * 64, "buy": dict(base, m=2), "sell": dict(base, m=1), "frame": {"id": str(end), "ordinal": end // 180, "start": 0, "end": end, "available_at": end, "known": {"ema8": True, "ema21": True, "hist": True, "close": True}, "ema8": ema8, "ema21": ema21, "hist": hist, "close": close}}


class 当時値人工(unittest.TestCase):
    """公表の同時計を推定せず、原保存の既知値だけで診断する人工。"""

    def test_厳密前公表と将来追記(self) -> None:
        """
        機能: 同時計公表を取得前へ遡及せず未来追記が過去選択を変えないことを確認する。
        引数: self(当時値人工)は人工状態。
        返り値: None。
        """
        pubs = [publication(180, 2, 100, 98, 101, 181), publication(360, 1, 101, 99, 100)]
        self.assertEqual(MODULE.prior_entry_index(pubs, 181), (None, 1))
        self.assertEqual(MODULE.prior_entry_index(pubs, 360), (0, 1))
        old = MODULE.technical(pubs, 0, 1)
        pubs.append(publication(540, 10000, 99999, 1, 99999))
        self.assertEqual(MODULE.prior_entry_index(pubs, 360), (0, 1))
        self.assertEqual(MODULE.technical(pubs, 0, 1), old)

    def test_足境界と売買符号(self) -> None:
        """
        機能: 場開始frame.startと足境界を混同せず、一公表差の買売鏡像を確認する。
        引数: self(当時値人工)は人工状態。
        返り値: None。
        """
        pubs = [publication(180, 2, 100, 98, 101), publication(360, 1, 101, 99, 100, 366)]
        buy = MODULE.technical(pubs, 1, 1)
        sell = MODULE.technical(pubs, 1, -1)
        self.assertTrue(buy["previous_continuous"])
        self.assertEqual(buy["start"], 180)
        self.assertEqual(buy["available_at"], 366)
        self.assertEqual(buy["signed_slopes_one_publication"]["hist"], -1)
        for key in ("signed_gap_ema8_21", "signed_close_minus_ema21"):
            self.assertEqual(buy[key], -sell[key])
        for key in ("ema8", "ema21", "hist"):
            self.assertEqual(buy["signed_slopes_one_publication"][key], -sell["signed_slopes_one_publication"][key])

    def test_未知と欠公表(self) -> None:
        """
        機能: 未知の指標や連続しない公表をゼロ/傾きへ補完しないことを確認する。
        引数: self(当時値人工)は人工状態。
        返り値: None。
        """
        pubs = [publication(180, 2, 100, 98, 101), publication(360, 0, 101, 99, 100)]
        self.assertEqual(MODULE.technical(pubs, 1, 1)["values"]["hist"], 0)
        pubs[1]["frame"]["known"]["hist"] = False
        self.assertIsNone(MODULE.technical(pubs, 1, 1)["values"]["hist"])
        self.assertIsNone(MODULE.technical(pubs, 1, 1)["signed_slopes_one_publication"]["hist"])
        pubs[1]["buy"]["ordinal"] = 42
        self.assertFalse(MODULE.technical(pubs, 1, 1)["previous_continuous"])
        self.assertTrue(all(value is None for value in MODULE.technical(pubs, 1, 1)["signed_slopes_one_publication"].values()))


if __name__ == "__main__":
    unittest.main(verbosity=2)
