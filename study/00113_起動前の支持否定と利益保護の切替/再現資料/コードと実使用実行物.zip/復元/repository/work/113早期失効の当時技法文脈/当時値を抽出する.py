"""認証済み全70場の主Eで失効した実玉について、事前に定義した同じ当時列を取り出す。"""

from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone, timedelta
import gzip
import hashlib
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / "work/113独立保存F1/全70場"
RESULT_SHA = "6492ae50b8fbf5b3dbe61d4295147119619e7ecbfd7cb09cbe39bc267663852b"
CHECK_SHA = "aaa203a0afc7c7c08f9faa049cbddbf6636242ffa9a1356bb2bdb754dd2daafa"
MARKET = ROOT / "work/113金融F1/全70場/完了.json"
MARKET_SHA = "3d8160b4374091d0d31b14b68d177aa116081e44acc5f3fc055b66f8a8fb6d5f"
KEYS = ("E100_C0_D0", "E50_C0_D0")
TRUTH = {0: "unknown", 1: "false", 2: "true"}


def read_json(path: Path, sha: str, compressed: bool = False) -> dict[str, Any]:
    """
    機能: 指定SHAを認証してJSONだけを読む。
    引数: path(Path)は許可済みファイル、sha(str)は期待SHA、compressed(bool)はgzip指定。
    返り値: dict[str,Any]の認証済みJSON。
    """
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != sha:
        raise ValueError("入力SHA差: " + str(path))
    return json.loads(gzip.decompress(raw) if compressed else raw.decode("utf-8-sig"))


def clock(at: float) -> str:
    """
    機能: 保存価格時計をJST表示へ変換する。
    引数: at(float)は保存Unix秒。
    返り値: strのJST日時。受信日時ではない。
    """
    return datetime.fromtimestamp(at, timezone(timedelta(hours=9))).isoformat()


def known_frame_value(observation: dict, key: str) -> float | None:
    """
    機能: 公表frameが既知と記録した指標だけを返す。
    引数: observation(dict)は保存公表、key(str)は指標名。
    返り値: float|Noneの既知値または未知。
    """
    frame = observation["frame"]
    return frame.get(key) if frame.get("known", {}).get(key) is True else None


def prior_entry_index(publications: list[dict], entry_at: float) -> tuple[int | None, int]:
    """
    機能: 取得時計より厳密に前に公表された最後のframeを選ぶ。
    引数: publications(list[dict])は保存公表列、entry_at(float)は実取得時計。
    返り値: tuple[int|None,int]の選択indexと同時計公表数。
    """
    earlier = [i for i, row in enumerate(publications) if row["at"] < entry_at and row["frame"]["available_at"] < entry_at]
    return (earlier[-1] if earlier else None, sum(row["at"] == entry_at for row in publications))


def technical(publications: list[dict], index: int | None, side: int) -> dict[str, Any] | None:
    """
    機能: 指定公表と直前連続公表だけから方向符号付きの診断値を取り出す。
    引数: publications(list[dict])は当場公表、index(int|None)は対象、side(int)は買1/売-1。
    返り値: dict[str,Any]|Noneの当時技法値。未来公表は参照しない。
    """
    if index is None:
        return None
    current = publications[index]
    frame = current["frame"]
    direction = current["buy" if side == 1 else "sell"]
    previous = publications[index - 1] if index > 0 else None
    previous_direction = previous["buy" if side == 1 else "sell"] if previous is not None else None
    continuous = previous_direction is not None and direction["start"] == previous_direction["end"] and direction["ordinal"] == previous_direction["ordinal"] + 1 and direction["scope"] == previous_direction["scope"]
    values = {key: known_frame_value(current, key) for key in ("ema8", "ema21", "hist", "close")}
    previous_values = {key: known_frame_value(previous, key) if continuous else None for key in ("ema8", "ema21", "hist")}
    signed_slopes = {key: side * (values[key] - previous_values[key]) if values[key] is not None and previous_values[key] is not None else None for key in ("ema8", "ema21", "hist")}
    close = values["close"]
    gap = side * (values["ema8"] - values["ema21"]) if values["ema8"] is not None and values["ema21"] is not None else None
    bb = direction["bb"]
    selected_bb = {key: bb.get(key) for key in ("known", "window_bars", "sma", "upper", "lower", "width", "band_width", "percent_b", "contraction", "window_sha256")}
    c = TRUTH[direction["c"]]
    m = TRUTH[direction["m"]]
    b = TRUTH[bb["contraction"]]
    return {"publication_id": frame["id"], "publications_index": index, "at": current["at"], "at_jst": clock(current["at"]), "start": direction["start"], "end": direction["end"], "available_at": direction["available_at"], "frame_sha256": current["frame_sha256"], "result_sha256": current["result_sha256"], "previous_continuous": continuous, "previous_publication_id": previous["frame"]["id"] if continuous else None, "values": values, "previous_values": previous_values, "signed_gap_ema8_21": gap, "signed_slopes_one_publication": signed_slopes, "signed_close_minus_ema8": side * (close - values["ema8"]) if close is not None and values["ema8"] is not None else None, "signed_close_minus_ema21": side * (close - values["ema21"]) if close is not None and values["ema21"] is not None else None, "c": c, "m": m, "v": direction["v"], "ohlc": frame.get("ohlc"), "dynamic_prior_pivot": direction.get("prior_pivot"), "bb": selected_bb, "b": b, "fifteen_minute": {"status": "当時公表snapshot未保存", "value": None}}


def build() -> dict[str, Any]:
    """
    機能: 独立正本と全70完了を認証し、主Eの31実玉の当時値だけを抽出する。
    引数: なし。対象はRootが解禁した固定全70のE100/E50主条件。
    返り値: dict[str,Any]の観測31件と入力認証。Raw/価格CSVを読まない。
    """
    result = read_json(BASE / "結果.json", RESULT_SHA)
    checked = read_json(BASE / "保存会計の確認.json", CHECK_SHA)
    market = read_json(MARKET, MARKET_SHA)
    if not (result["成功"] and checked["成功"] and market["success"] and result["場数"] == 70 and checked["場数"] == 70 and market["sessions"] == 70 and result["会計数"] == 1680 and result["金融完了SHA256"] == MARKET_SHA and result["前後不変"] and checked["前後不変"]):
        raise ValueError("全70の独立成功不足")
    if [row["session"] for row in result["Native参照"]] != [row["session"] for row in market["results"]]:
        raise ValueError("全70の場順差")
    for saved, actual in zip(result["Native参照"], market["results"]):
        if saved["path"] != actual["native"]["path"] or saved["sha256"] != actual["native"]["sha256"]:
            raise ValueError("全70のNative参照差")
    original54 = {row["session"] for row in market["results"][:54]}
    selected = {row["session"] for row in result["場別"] if row["key"] in KEYS and row.get("entry_invalidated_positions", 0) > 0}
    input_refs = []
    observations = []
    for ref in result["Native参照"]:
        if ref["session"] not in selected:
            continue
        native = read_json(Path(ref["path"]), ref["sha256"], True)
        if native["trial"] != 113 or not native["actual"]["complete"]:
            raise ValueError("113当場の金融成功不足")
        input_refs.append({key: ref[key] for key in ("session", "path", "sha256")})
        publications = native["actual"]["publications"]
        id_indexes = {row["frame"]["id"]: i for i, row in enumerate(publications)}
        for key in KEYS:
            book = native["actual"]["books"][key]
            for position in book["positions"]:
                audit = position.get("protection113", {})
                first = audit.get("first_entry_invalidation")
                if not first:
                    continue
                snapshot = first["snapshot"]
                witness = snapshot["entry_invalidation_witness"]
                entry = audit["initial"]["entry"]
                support = entry["entry_support"]
                side = position["side"]
                if snapshot["active"] or first["decision"]["entry_support_break"] != 2 or first["decision"]["m"] != 2 or support != witness["support"]:
                    raise ValueError("固定支持失効witness差")
                invalid_index = id_indexes[witness["publication"]["id"]]
                direction = publications[invalid_index]["buy" if side == 1 else "sell"]
                if direction != witness["publication"] or direction != snapshot["latest"] or publications[invalid_index]["at"] > first["at"] or direction["end"] <= entry["at"]:
                    raise ValueError("初失効時の実公表結合差")
                entry_index, same_clock = prior_entry_index(publications, entry["at"])
                at_entry = technical(publications, entry_index, side)
                at_invalid = technical(publications, invalid_index, side)
                if at_invalid["signed_slopes_one_publication"]["hist"] is None or at_invalid["signed_slopes_one_publication"]["hist"] >= 0:
                    raise ValueError("保存生MとMACD-H差の符号不一致")
                atr = (entry.get("atr") or {}).get("value")
                distance = side * (entry["price"] - support["price"])
                penetration = side * (direction["close"] - support["price"])
                net = position["realized_net"]
                source_key = json.dumps([ref["session"], position["source"]["signal_id"], position["source"]["source_id"], position["source_hold_id"], side, entry["price"], entry["at"]], separators=(",", ":"), ensure_ascii=False)
                observations.append({"session": ref["session"], "history_class": "original54" if ref["session"] in original54 else "additional16", "key": key, "position_id": position["id"], "source_key": source_key, "source": position["source"], "source_hold_id": position["source_hold_id"], "side": side, "initial_quantity": entry["initial_quantity"], "entry_price": entry["price"], "entry_at": entry["at"], "entry_jst": clock(entry["at"]), "entry_quote": position["entry_quote"], "anchor": support, "anchor_distance_points": distance, "anchor_distance_atr": distance / atr if atr is not None and atr > 0 else None, "atr_entry": atr, "anchor_age_at_entry_seconds": entry["at"] - support["published_at"], "entry_to_invalidation_seconds": first["at"] - entry["at"], "invalidation_at": first["at"], "invalidation_jst": clock(first["at"]), "invalidation_phase": first["phase"], "invalidation_quote": first["quote"], "close_minus_fixed_support_signed": penetration, "close_minus_fixed_support_atr": penetration / atr if atr is not None and atr > 0 else None, "unit_net_at_invalidation_yen": first["decision"].get("unit_net_yen"), "whole_net_at_invalidation_yen": first["decision"].get("whole_net_yen"), "dynamic_p_at_invalidation": TRUTH[first["decision"]["p"]], "free_quantity_at_invalidation": first["decision"]["free_quantity"], "entry_technical_selection": "取得時計より厳密に前に公表された最後の既知frame。同時計原行の前後は推定しない。", "same_clock_publications_at_entry": same_clock, "entry_technical": at_entry, "invalidation_technical": at_invalid, "after_the_fact": {"final_realized_net_yen": net, "label": "利益" if net > 0 else "損失" if net < 0 else "同値", "used_as_order_condition": False}, "native": {"path": ref["path"], "sha256": ref["sha256"]}})
    counts = dict(Counter(row["key"] for row in observations))
    if counts != {"E100_C0_D0": 16, "E50_C0_D0": 15}:
        raise ValueError("主早期失効の16/15件と差")
    base_counts = dict(Counter(row["key"] for row in observations if row["history_class"] == "original54"))
    if base_counts != {"E100_C0_D0": 11, "E50_C0_D0": 10}:
        raise ValueError("事前の元54主11/10と差")
    for ref in input_refs:
        if hashlib.sha256(Path(ref["path"]).read_bytes()).hexdigest() != ref["sha256"]:
            raise ValueError("Nativeが抽出前後で変化")
    return {"試行": 113, "成功": True, "範囲": "全70場の主E100/E50に実際に成立した初回固定支持失効だけ", "独立結果": {"path": str(BASE / "結果.json"), "sha256": RESULT_SHA}, "独立確認": {"path": str(BASE / "保存会計の確認.json"), "sha256": CHECK_SHA}, "金融完了": {"path": str(MARKET), "sha256": MARKET_SHA}, "Native参照": input_refs, "Native読取場数": len(input_refs), "件数": counts, "元54件数": base_counts, "追加16件数": dict(Counter(row["key"] for row in observations if row["history_class"] == "additional16")), "実Source出生の重複除去件数": len({row["source_key"] for row in observations}), "observations": observations, "公表と取得の同時計原行順の推測": False, "当時15分snapshot未保存": True, "Raw読取": 0, "価格CSV読取": 0, "11月09本文読取": 0, "金融再実行": False, "固定F1変更": False, "新しい発注条件の適用": False, "PとEの実現差比較": False, "Native前後不変": True, "限界": ["失効例に条件付けた少数標本であり、全取引を分類する精度・利益効果・最適閾値は測っていない。", "取得側は厳密前clockの公表値。取得と同時計の後行を混ぜないため、実際の直前状態から保守的に一公表古い場合がある。", "15分は場末snapshotしか保存されないため、取得/失効当時の背景を場末値から推測しない。", "損益ラベルは実玉最終値の事後評価だけ。未来の回復・未参加/退出後仮想利益を判断条件へ使わない。"]}


def main() -> None:
    """
    機能: 当時値の小さいJSONを新規保存する。
    引数: CLI引数なし。
    返り値: None。入力差は非0終了。
    """
    value = build()
    path = Path(__file__).resolve().parent / "当時値.json"
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "counts": value["件数"], "unique": value["実Source出生の重複除去件数"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
