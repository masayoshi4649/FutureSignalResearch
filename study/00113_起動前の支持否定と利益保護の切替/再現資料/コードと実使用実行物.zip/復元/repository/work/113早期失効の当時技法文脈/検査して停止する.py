"""診断codeと当時値・指定無作用例の認証を保存し、閾値不変更を記録する。"""

from pathlib import Path
import hashlib
import json
import subprocess
import sys


HERE = Path(__file__).resolve().parent
OWNED = ["当時値を抽出する.py", "11月06日の無作用を確認する.py", "人工検査.py", "調査.md", "検査して停止する.py"]


def hashes() -> dict[str, str]:
    """
    機能: 診断所有5ファイルのSHA256を計算する。
    引数: なし。
    返り値: dict[str,str]の絶対パスとSHA。
    """
    return {str(HERE / name): hashlib.sha256((HERE / name).read_bytes()).hexdigest() for name in OWNED}


def main() -> None:
    """
    機能: 手製人工と保存済み診断metadataを認証し新規停止を作る。
    引数: CLI引数なし。
    返り値: None。原板・Native本文・金融再生は起動しない。
    """
    stop_path = HERE / "停止.json"
    if stop_path.exists():
        raise ValueError("停止は新規only")
    before = hashes()
    process = subprocess.run([sys.executable, "-X", "utf8", str(HERE / "人工検査.py")], cwd=HERE, capture_output=True, text=True, encoding="utf-8")
    log_path = HERE / "人工検査.log"
    with log_path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(process.stdout + process.stderr)
    if process.returncode != 0:
        raise ValueError(process.stdout + process.stderr)
    data = json.loads((HERE / "当時値.json").read_text(encoding="utf-8"))
    special = json.loads((HERE / "11月06日の無作用.json").read_text(encoding="utf-8"))
    if data["件数"] != {"E100_C0_D0": 16, "E50_C0_D0": 15} or not special["成功"] or len(data["observations"]) != 31:
        raise ValueError("診断の認証件数が違う")
    fixed_path = HERE.parents[1] / "work/113進行/F1_113金融条件.json"
    fixed_bytes = fixed_path.read_bytes()
    if hashlib.sha256(fixed_bytes).hexdigest() != "065cb5ebc894627cb70cf6f3d8f0add7698532af269cb92c2dd3decf4051a138":
        raise ValueError("F1が変化")
    fixed = json.loads(fixed_bytes.decode("utf-8-sig"))
    for path, sha in fixed["code_sha256"].items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != sha:
            raise ValueError("F1コードが変化: " + path)
    after = hashes()
    if before != after:
        raise ValueError("診断所有コードが前後で変化")
    refs = [{"path": str(HERE / name), "sha256": hashlib.sha256((HERE / name).read_bytes()).hexdigest()} for name in ("当時値.json", "11月06日の無作用.json", "調査.md", "人工検査.log")]
    value = {"成功": True, "停止": True, "試行": 113, "所有コードSHA256": before, "前SHA256": before, "後SHA256": after, "前後不変": True, "主人工": 3, "成果物": refs, "全主失効の保存公表全値結合": 31, "全主失効の生MとHist差符号照合": 31, "取得前同時計行の推定": False, "元54と追加16の同列定義": True, "指定11月06例のSource出生同体": True, "F1コード現物一致": len(fixed["code_sha256"]), "Raw本文読取": 0, "価格CSV読取": 0, "11月09本文読取": 0, "金融再実行": False, "閾値変更": False, "PとEの実現差再集計": False, "15分当時値": "保存なし・不使用", "研究目標達成": False, "採用": False}
    with stop_path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"path": str(stop_path), "sha256": hashlib.sha256(stop_path.read_bytes()).hexdigest()}, ensure_ascii=False))


if __name__ == "__main__":
    main()
