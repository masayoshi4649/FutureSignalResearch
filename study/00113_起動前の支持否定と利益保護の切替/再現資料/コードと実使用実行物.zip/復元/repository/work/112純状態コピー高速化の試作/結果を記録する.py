"""人工で確認した同体・局所性能・旧停止不変だけを作業領域へ保存する。"""
from pathlib import Path
import hashlib
import json
import re
import statistics
import subprocess

作業 = Path(__file__).resolve().parent
元 = 作業.parent / "112支持否定の必須確認と通常幅のみ"


def 指紋(位置: Path) -> str:
    """
    機能: コード又はメタデータのSHA256を返す。
    引数: 位置(Path)。返り値: strは小文字16進の指紋。
    """
    return hashlib.sha256(位置.read_bytes()).hexdigest()


def 実行する() -> None:
    """
    機能: 旧停止前後の同体と演算本文の不変を確認し、性能中央値を保存する。
    引数: なし。返り値: None。市場コード・入力・結果は参照しない。
    """
    参照 = json.loads((作業 / "派生の参照.json").read_text(encoding="utf-8"))
    for k, v in 参照["元と再用の前指紋"].items():
        assert 指紋(Path(k)) == v, k
    assert 指紋(元 / "停止.json") == 参照["元停止SHA256"]
    比較 = {}
    for 名前 in ["types.go", "state.go", "bb.go", "state_test.go", "bb_test.go"]:
        本文 = (元 / 名前).read_text(encoding="utf-8-sig")
        本文 = 本文.replace("package profitfloor112", "package profitfloor112fast", 1)
        if 名前 == "types.go":
            本文 = 本文.replace("// Package profitfloor112 ", "// Package profitfloor112fast ", 1)
        if 名前 == "state.go":
            始 = 本文.index("// copyValue ")
            終 = 本文.index("// finite ", 始)
            本文 = 本文[:始] + 本文[終:]
            本文 = 本文.replace('\t"encoding/json"\n', "", 1)
        期待 = subprocess.run(["gofmt"], input=本文.encode("utf-8"), check=True, capture_output=True).stdout
        assert (作業 / 名前).read_bytes() == 期待, 名前
        比較[名前] = "package名/Packageコメント・state.goのcopyValueと未使用import以外はgofmt後の全bytes一致"
    # ----------------------------------------
    # 出力文字列をUTF-8へ統一し、同じ測定5回の中央値だけをまとめる。
    ログ先 = 作業 / "ベンチマーク.txt"
    生 = ログ先.read_bytes()
    本文 = 生.decode("utf-16") if 生.startswith(b"\xff\xfe") else 生.decode("utf-8-sig")
    ログ先.write_text(本文, encoding="utf-8")
    行 = re.findall(r"^(Benchmark\w+)\s+\d+\s+(\d+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op", 本文, re.M)
    集計 = {}
    for 名前 in sorted({x[0] for x in 行}):
        数値 = [list(map(int, x[1:])) for x in 行 if x[0] == 名前]
        assert len(数値) == 5, 名前
        集計[名前] = {"回数": 5, "ns/op中央値": statistics.median(x[0] for x in 数値),
                    "B/op中央値": statistics.median(x[1] for x in 数値), "allocs/op中央値": statistics.median(x[2] for x in 数値)}
    比率 = {}
    for 名前 in ["Sequences", "BB"]:
        前, 後 = 集計["Benchmark" + 名前 + "JSON112"], 集計["Benchmark" + 名前 + "Fast112"]
        比率[名前] = {"速度倍率": 前["ns/op中央値"] / 後["ns/op中央値"],
                    "割当byte削減率": 1 - 後["B/op中央値"] / 前["B/op中央値"],
                    "割当回数削減率": 1 - 後["allocs/op中央値"] / 前["allocs/op中央値"]}
    説明 = f'''# 112純状態コピーの人工試作

固定112と別名の `profitfloor112fast`。市場F1・金融結果・正式レポートへは適用していない。

変更はJSONの `copyValue` を型別の明示的な深いコピーへ置き換えたことだけ。政策・definition112・価格・公表三値・床・丸め・式は同じ。元types/state/bbの演算本文と既存人工は、package名等の許容差以外すべてgofmt後のbytes一致。旧停止とその所有/再用ファイルは前後SHA一致。

人工は元72系列の696判断・768状態を**field除外なし、JSON bytes同体**で確認。さらに5政策180系列/1740遷移を生BB付きで照合。全16主test・vet・build成功。全ポインタ/入れ子/足窓の破壊、前状態不変、同一入力参照の分離、nil/非nil空、不正UTF-8の旧JSONと同じ置換も確認した。独立静的レビューで実害候補なし。

| 同じ人工処理を1回 | 旧JSON中央値 | 明示copy中央値 | 速度比 | byte割当 | 割当回数 |
|---|---:|---:|---:|---:|---:|
| 72系列/696遷移、各Snapshot保存 | {集計['BenchmarkSequencesJSON112']['ns/op中央値']/1e6:.3f}ms | {集計['BenchmarkSequencesFast112']['ns/op中央値']/1e6:.3f}ms | {比率['Sequences']['速度倍率']:.2f}倍 | 4,852,222→829,761 | 60,923→15,448 |
| 48確定足BB、各Snapshot保存 | {集計['BenchmarkBBJSON112']['ns/op中央値']/1e6:.3f}ms | {集計['BenchmarkBBFast112']['ns/op中央値']/1e6:.3f}ms | {比率['BB']['速度倍率']:.2f}倍 | 899,562→478,738 | 8,621→2,247 |

Windows/amd64、Ryzen 9 7950X3D、Go 1.24.2、GOMAXPROCS=1、250ms×5回。fixture/型変換は測定外、両側同じ遷移・保存範囲。これは局所部品の人工測定で、市場全体・I/O・Source・Actorの速度比ではない。同時に別処理が動くPC上の測定である。

`copyValue`の入力は旧コメントと同じ「検証済み有限値」。未列挙型はpanicし、将来の型を浅いコピーへ落とさない。BBの窓SHA用JSON計算は元のまま残る。State/BBStateの同ID再公表・エラー時の値返却規則も元のままで、次の成功Advanceが参照を切る。文字列はGoで不変なので有効文字列のbyte列複製は行わず、不正UTF-8だけ正規化する。

再現：本folderで `go test ./...`、`go vet ./...`、`go build ./...`。性能は `GOMAXPROCS=1` を設定して `go test -run '^$' -bench 'Benchmark(Sequences|BB)' -benchmem -benchtime=250ms -count=5`。生の5回は [ベンチマーク.txt](ベンチマーク.txt)、指紋・差・集計は [結果.json](結果.json)。市場/Raw/Native/価格CSV/11月9日本文の追加読取0、ネット取得0。
'''
    (作業 / "README.md").write_text(説明, encoding="utf-8")
    所有 = ["types.go", "state.go", "bb.go", "state_test.go", "bb_test.go", "fastcopy.go", "fastcopy_test.go", "go.mod", "派生する.py", "結果を記録する.py", "README.md", "ベンチマーク.txt", "派生の参照.json"]
    結果 = {"成功": True, "人工専用": True, "市場採用": False, "元停止SHA256": 参照["元停止SHA256"],
            "旧所有と再用の前後同体": True, "旧同体件数": len(参照["元と再用の前指紋"]) + 1,
            "演算本文の差検査": 比較, "元系列": 72, "元判断": 696, "元状態": 768, "全五政策系列": 180, "全五政策遷移": 1740,
            "JSON比較除外field": [], "主test": 16, "vet": True, "build": True,
            "独立レビュー": "全可変参照・nil/空・UTF8・測定対称性に実害候補なし。検証済み有限値契約内。",
            "測定": 集計, "比率": 比率, "測定条件": "GOMAXPROCS=1、benchtime=250ms、count=5、準備は測定外",
            "追加市場RawNative価格CSV11月9日本文読取": 0, "ネット取得": 0, "停止済みcode条件変更": 0,
            "所有SHA256": {str((作業 / k).resolve()): 指紋(作業 / k) for k in 所有}}
    (作業 / "結果.json").write_text(json.dumps(結果, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "旧同体件数": 結果["旧同体件数"], "比率": 比率, "結果SHA256": 指紋(作業 / "結果.json")}, ensure_ascii=False))


if __name__ == "__main__":
    実行する()
