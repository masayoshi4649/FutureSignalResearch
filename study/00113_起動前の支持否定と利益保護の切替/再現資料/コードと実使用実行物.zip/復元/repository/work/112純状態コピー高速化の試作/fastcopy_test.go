package profitfloor112fast

import (
	"bytes"
	"encoding/json"
	"reflect"
	"strings"
	"testing"

	old "github.com/masayoshi4649/SessionTradeExecuter/profitfloor112"
)

// jsonCopy は停止112と同じ型付きJSON往復を人工の独立対照にします。
//
// 引数: value(T)は有限の人工。返り値: TはJSONで深く写した値です。
func jsonCopy[T any](value T) T {
	var out T
	raw, err := json.Marshal(value)
	if err != nil {
		panic(err)
	}
	if err = json.Unmarshal(raw, &out); err != nil {
		panic(err)
	}
	return out
}

// oldEntry は同じ生値を停止112の型へ渡します。
//
// 引数: e(Entry)。返り値: old.Entryは政策名やATRを変えない取得です。
func oldEntry(e Entry) old.Entry {
	return old.Entry{Scope: e.Scope, Policy: old.Policy(e.Policy), Side: e.Side, Price: e.Price, At: e.At, InitialQuantity: e.InitialQuantity, SlipPoints: e.SlipPoints, ATR: e.ATR}
}

// oldInput は同じ公表と会計を停止112の型へ渡します。
//
// 引数: in(Input)。返り値: old.Inputは原値の人工遷移です。
func oldInput(in Input) old.Input {
	return old.Input{At: in.At, Sequence: in.Sequence, Phase: in.Phase, Mark: in.Mark, Remaining: in.Remaining, Reserved: in.Reserved, ClosedNetYen: in.ClosedNetYen, Publication: in.Publication, ResetReason: in.ResetReason}
}

// exactJSON は一切のfield除外なしでJSON bytesを比較します。
//
// 引数: t(*testing.T)、a/b(any)は同じ公開型の結果。返り値: ありません。
func exactJSON(t *testing.T, a, b any) {
	t.Helper()
	x, e := json.Marshal(a)
	if e != nil {
		t.Fatal(e)
	}
	y, e := json.Marshal(b)
	if e != nil {
		t.Fatal(e)
	}
	if !bytes.Equal(x, y) {
		t.Fatalf("全JSON差\n%s\n%s", x, y)
	}
}

// sequenceFixture は元72系列と同じnil/予約/reset/再公表/部分返済を作ります。
//
// 引数: e(Entry)、withBB(bool)は生BBを付ける追加比較。返り値: []Inputは同じ人工原行です。
func sequenceFixture(e Entry, withBB bool) []Input {
	quantity := e.InitialQuantity
	pub := publicationFixture(e, 21, False, True, False, pointer(10))
	inputs := []Input{}
	in := inputFixture(e, 1, 0, quantity, 0, 0)
	in.Mark = nil
	inputs = append(inputs, in, inputFixture(e, 2, 100, quantity, 0, 0))
	in = inputFixture(e, 3, 115, quantity, 0, 0)
	in.Publication = copyValue(&pub)
	inputs = append(inputs, in)
	pub = publicationFixture(e, 22, False, True, True, pointer(20))
	in = inputFixture(e, 4, 600, quantity, 0, 0)
	in.Publication = copyValue(&pub)
	inputs = append(inputs, in)
	in = inputFixture(e, 5, 0, quantity, quantity, 0)
	in.Mark = nil
	inputs = append(inputs, in)
	in = inputFixture(e, 6, 0, quantity, quantity, 0)
	in.Mark = nil
	in.ResetReason = "欠足"
	inputs = append(inputs, in)
	in = inputFixture(e, 7, 450, quantity, quantity, 0)
	in.Publication = copyValue(&pub)
	inputs = append(inputs, in)
	pub = publicationFixture(e, 23, True, Unknown, True, pointer(60))
	in = inputFixture(e, 8, 450, quantity, quantity, 0)
	in.Publication = copyValue(&pub)
	inputs = append(inputs, in)
	if quantity > 1 {
		inputs = append(inputs, inputFixture(e, 9, 20, quantity-1, quantity-1, -.5))
	}
	in = inputFixture(e, 10, 0, 0, 0, -154)
	in.Mark = nil
	inputs = append(inputs, in)
	if withBB {
		for i := range inputs {
			if p := inputs[i].Publication; p != nil {
				p.BB = &BBResult{Scope: p.Scope, ID: p.ID, Ordinal: p.Ordinal, End: p.End, AvailableAt: p.AvailableAt, DeliveredAt: p.AvailableAt, Known: true, WindowBars: 20, SMA: pointer(1000), Sigma: pointer(20), Upper: pointer(1040), Lower: pointer(960), Width: pointer(80), BandWidth: pointer(.08), PercentB: pointer(.7), Contraction: True, WindowSHA: strings.Repeat("0", 64)}
			}
		}
	}
	return inputs
}

// compareSequence は同じ全状態と全判断を停止112へ照合します。
//
// 引数: t(*testing.T)、e(Entry)、bb(bool)。返り値: intは照合した遷移数です。
func compareSequence(t *testing.T, e Entry, bb bool) int {
	t.Helper()
	s, err := NewState(e)
	if err != nil {
		t.Fatal(err)
	}
	b, err := old.NewState(oldEntry(e))
	if err != nil {
		t.Fatal(err)
	}
	exactJSON(t, s.Snapshot(), b.Snapshot())
	for _, in := range sequenceFixture(e, bb) {
		before := s.Snapshot()
		next, d, er := Advance(s, in)
		nextOld, od, oe := old.Advance(b, oldInput(in))
		if er != nil || oe != nil {
			t.Fatal(er, oe)
		}
		exactJSON(t, next.Snapshot(), nextOld.Snapshot())
		exactJSON(t, d, od)
		exactJSON(t, before, s.Snapshot())
		assertDisjoint(t, s, next)
		s, b = next, nextOld
	}
	return len(sequenceFixture(e, bb))
}

// TestOriginal72Exact は元72系列の全Snapshot/Decisionを112へ完全一致させます。
//
// 引数: t(*testing.T)。返り値: ありません。definition等の除外はありません。
func TestOriginal72Exact(t *testing.T) {
	count, steps := 0, 0
	for _, p := range []Policy{W100, B100} {
		for _, side := range []int{1, -1} {
			for _, slip := range []float64{0, 5} {
				for _, atr := range []*float64{nil, pointer(80), pointer(125.5)} {
					for _, q := range []int{1, 2, 10} {
						e := entryFixture(p, side, q, atr)
						e.SlipPoints = slip
						steps += compareSequence(t, e, false)
						count++
					}
				}
			}
		}
	}
	if count != 72 {
		t.Fatal(count)
	}
	t.Logf("元系列=%d、遷移=%d、初期を含む状態=%d、判断=%d", count, steps, count+steps, steps)
}

// TestAllPoliciesAndNestedBBExact は新五政策も生BB付き同体へ広げます。
//
// 引数: t(*testing.T)。返り値: ありません。市場は使用しません。
func TestAllPoliciesAndNestedBBExact(t *testing.T) {
	count, steps := 0, 0
	for _, p := range []Policy{W100, B100, W400, P100, P400} {
		for _, side := range []int{1, -1} {
			for _, slip := range []float64{0, 5} {
				for _, atr := range []*float64{nil, pointer(80), pointer(125.5)} {
					for _, q := range []int{1, 2, 10} {
						e := entryFixture(p, side, q, atr)
						e.SlipPoints = slip
						steps += compareSequence(t, e, true)
						count++
					}
				}
			}
		}
	}
	if _, err := NewState(entryFixture(S0, 1, 1, nil)); err == nil {
		t.Fatal("S0を追加保護へ生成")
	}
	exactJSON(t, DeclaredDefinitions(), old.DeclaredDefinitions())
	exactJSON(t, DeclaredConfigurations(), old.DeclaredConfigurations())
	t.Logf("五政策系列=%d、遷移=%d", count, steps)
}

// addresses はポインタと有要素スライスの参照先を列挙します。
//
// 引数: v(reflect.Value)、out(map[uintptr]bool)。返り値: ありません。
func addresses(v reflect.Value, out map[uintptr]bool) {
	switch v.Kind() {
	case reflect.Pointer:
		if !v.IsNil() {
			out[v.Pointer()] = true
			addresses(v.Elem(), out)
		}
	case reflect.Struct:
		for i := 0; i < v.NumField(); i++ {
			addresses(v.Field(i), out)
		}
	case reflect.Slice:
		if v.Len() > 0 {
			out[v.Pointer()] = true
			for i := 0; i < v.Len(); i++ {
				addresses(v.Index(i), out)
			}
		}
	}
}

// assertDisjoint は前後又は入力/出力に可変参照の共有がないことを検査します。
//
// 引数: t(*testing.T)、a/b(any)。返り値: ありません。空スライスの共有不能な要素は数えません。
func assertDisjoint(t *testing.T, a, b any) {
	t.Helper()
	x, y := map[uintptr]bool{}, map[uintptr]bool{}
	addresses(reflect.ValueOf(a), x)
	addresses(reflect.ValueOf(b), y)
	for p := range x {
		if y[p] {
			t.Fatal("可変参照を共有", p)
		}
	}
}

// destroy は参照先とスライス要素を破壊し、別名経由の漏れを検査する器具です。
//
// 引数: v(reflect.Value)、inside(bool)は可変参照の内側。返り値: ありません。
func destroy(v reflect.Value, inside bool) {
	switch v.Kind() {
	case reflect.Pointer:
		if !v.IsNil() {
			destroy(v.Elem(), true)
		}
	case reflect.Struct:
		for i := 0; i < v.NumField(); i++ {
			destroy(v.Field(i), inside)
		}
	case reflect.Slice:
		for i := 0; i < v.Len(); i++ {
			destroy(v.Index(i), true)
		}
	case reflect.Float64:
		if inside && v.CanSet() {
			v.SetFloat(v.Float() + .125)
		}
	case reflect.String:
		if inside && v.CanSet() {
			v.SetString("破壊" + v.String())
		}
	}
}

// aliasFixture は同じ数値参照を全階層へ意図的に共有した人工を作ります。
//
// 引数: なし。返り値: Snapshot/Decisionは参照破壊用で注文判断には使用しません。
func aliasFixture() (Snapshot, Decision) {
	p := pointer(100)
	bb := &BBResult{SMA: p, Sigma: p, Upper: p, Lower: p, Width: p, BandWidth: p, PercentB: p}
	pub := &Publication{V: p, Close: p, PriorPivot: &Pivot{Price: 100}, BB: bb}
	e := entryFixture(B100, 1, 10, p)
	return Snapshot{Entry: e, ActivatedAt: p, NarrowedAt: p, PeakPoints: p, FloorPoints: p, Latest: pub}, Decision{GainPoints: p, UnitNetYen: p, WholeNetYen: p, WholeFloor: p, PeakFloor: p, StructuralFloor: p, ProtectPrice: p}
}

// TestPointersNilEmptyAndDestruction は全階層の参照分離とnil/空を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。数式を再実装する検査ではありません。
func TestPointersNilEmptyAndDestruction(t *testing.T) {
	s, d := aliasFixture()
	for _, x := range []any{s, d, s.Entry, s.Latest, *s.Latest, s.Latest.BB, *s.Latest.BB, s.Entry.ATR, s.Latest.PriorPivot, ClosedBar{Close: pointer(100)}, []ClosedBar{{Close: pointer(100)}}, []float64{1, 2}} {
		var c any
		switch v := x.(type) {
		case Snapshot:
			c = copyValue(v)
		case Decision:
			c = copyValue(v)
		case Entry:
			c = copyValue(v)
		case *Publication:
			c = copyValue(v)
		case Publication:
			c = copyValue(v)
		case *BBResult:
			c = copyValue(v)
		case BBResult:
			c = copyValue(v)
		case *Evidence:
			c = copyValue(v)
		case *Pivot:
			c = copyValue(v)
		case ClosedBar:
			c = copyValue(v)
		case []ClosedBar:
			c = copyValue(v)
		case []float64:
			c = copyValue(v)
		}
		exactJSON(t, x, c)
		assertDisjoint(t, x, c)
		before, _ := json.Marshal(x)
		destroy(reflect.ValueOf(c), false)
		after, _ := json.Marshal(x)
		if !bytes.Equal(before, after) {
			t.Fatal("出力破壊が入力へ漏れた")
		}
	}
	for _, x := range [][]ClosedBar{nil, {}, {{Close: nil}}} {
		c := copyValue(x)
		if (x == nil) != (c == nil) || !reflect.DeepEqual(x, c) {
			t.Fatal("足nil/空差")
		}
	}
	for _, x := range [][]float64{nil, {}, {1, 2}} {
		c := copyValue(x)
		if (x == nil) != (c == nil) || !reflect.DeepEqual(x, c) {
			t.Fatal("幅nil/空差")
		}
	}
	if copyValue((*Publication)(nil)) != nil || copyValue((*Evidence)(nil)) != nil || copyValue((*Pivot)(nil)) != nil || copyValue((*BBResult)(nil)) != nil || copyValue((*ClosedBar)(nil)) != nil || copyValue((*float64)(nil)) != nil {
		t.Fatal("nil参照差")
	}
	c := copyValue(s)
	if c.ActivatedAt == c.NarrowedAt || c.Latest.V == c.Latest.Close || c.Latest.BB.SMA == c.Latest.BB.Sigma {
		t.Fatal("入力内別名をJSON同様に分離できない")
	}
	before, _ := json.Marshal(c)
	destroy(reflect.ValueOf(s), false)
	after, _ := json.Marshal(c)
	if !bytes.Equal(before, after) {
		t.Fatal("入力破壊が出力へ漏れた")
	}
}

// TestUTF8JSONNormalization は明示copyでも旧JSONの不正文字置換を保持します。
//
// 引数: t(*testing.T)。返り値: ありません。文字列の連続不正byteも検査します。
func TestUTF8JSONNormalization(t *testing.T) {
	s, d := aliasFixture()
	bad := string([]byte{'a', 0xff, 0xfe, 0xed, 0xa0, 0x80, 'b'})
	s.Entry.Scope = Scope{Session: bad, Contract: bad}
	s.Entry.ATR.ID = bad
	s.Entry.Policy = Policy(bad)
	s.Definition.Policy = Policy(bad)
	s.Definition.WarningFormula = bad
	s.Latest.Scope = s.Entry.Scope
	s.Latest.ID = bad
	s.Latest.PriorPivot.Scope = s.Entry.Scope
	s.Latest.PriorPivot.ID = bad
	s.Latest.PriorPivot.Kind = bad
	s.Latest.BB.Scope = s.Entry.Scope
	s.Latest.BB.ID = bad
	s.Latest.BB.WindowSHA = bad
	s.Latest.BB.ResetReason = bad
	d.WidthSource = bad
	if !reflect.DeepEqual(copyValue(s), jsonCopy(s)) || !reflect.DeepEqual(copyValue(d), jsonCopy(d)) {
		t.Fatal("不正UTF-8の旧JSON正規化差")
	}
	in := Input{Phase: Phase(bad), ResetReason: bad, Publication: s.Latest, Mark: pointer(1)}
	if !reflect.DeepEqual(copyValue(in), jsonCopy(in)) {
		t.Fatal("入力文字列差")
	}
}

// TestBBStateDeepCopyAndExact は足窓・終値・幅・全公表の私有化を停止112へ照合します。
//
// 引数: t(*testing.T)。返り値: ありません。欠足と未知足も同じ順序で与えます。
func TestBBStateDeepCopyAndExact(t *testing.T) {
	s, _ := NewBBState(Scope{Session: "人工場", Contract: "限月", Start: 0})
	o, _ := old.NewBBState(s.scope)
	for i := 1; i <= 48; i++ {
		bar := barFixture(i, 1000+float64(i%7))
		if i == 26 {
			bar.Known = false
			bar.Close = nil
		}
		if i == 35 {
			continue
		}
		before := s.Snapshot()
		next, r, e := AdvanceBB(s, bar, bar.AvailableAt)
		onext, or, oe := old.AdvanceBB(o, old.ClosedBar{Scope: bar.Scope, ID: bar.ID, Ordinal: bar.Ordinal, Start: bar.Start, End: bar.End, AvailableAt: bar.AvailableAt, Known: bar.Known, Close: bar.Close}, bar.AvailableAt)
		if e != nil || oe != nil {
			t.Fatal(e, oe)
		}
		exactJSON(t, r, or)
		exactJSON(t, next.Snapshot(), onext.Snapshot())
		exactJSON(t, before, s.Snapshot())
		assertDisjoint(t, s, next)
		assertDisjoint(t, bar, next)
		assertDisjoint(t, r, next)
		saved := next.Snapshot()
		destroy(reflect.ValueOf(bar), false)
		destroy(reflect.ValueOf(r), false)
		exactJSON(t, saved, next.Snapshot())
		s, o = next, onext
	}
	if s.bars == nil || s.widths == nil {
		t.Fatal("元の非nil空規則を変更")
	}
}

var sinkSnapshot any
var sinkDecision any
var sinkBB any

// benchmarkSequences は同じ72系列の状態遷移と各Snapshot保存を測定します。
//
// 引数: b(*testing.B)、fast(bool)はcopy実装選択。返り値: ありません。
func benchmarkSequences(b *testing.B, fast bool) {
	type pair struct {
		e      Entry
		inputs []Input
		oe     old.Entry
		oi     []old.Input
	}
	all := []pair{}
	for _, p := range []Policy{W100, B100} {
		for _, side := range []int{1, -1} {
			for _, slip := range []float64{0, 5} {
				for _, atr := range []*float64{nil, pointer(80), pointer(125.5)} {
					for _, q := range []int{1, 2, 10} {
						e := entryFixture(p, side, q, atr)
						e.SlipPoints = slip
						inputs := sequenceFixture(e, false)
						oi := make([]old.Input, len(inputs))
						for i := range inputs {
							oi[i] = oldInput(inputs[i])
						}
						all = append(all, pair{e, inputs, oldEntry(e), oi})
					}
				}
			}
		}
	}
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		for _, c := range all {
			if fast {
				s, _ := NewState(c.e)
				for _, in := range c.inputs {
					var d Decision
					var e error
					s, d, e = Advance(s, in)
					if e != nil {
						b.Fatal(e)
					}
					sinkSnapshot, sinkDecision = s.Snapshot(), d
				}
			} else {
				s, _ := old.NewState(c.oe)
				for _, in := range c.oi {
					var d old.Decision
					var e error
					s, d, e = old.Advance(s, in)
					if e != nil {
						b.Fatal(e)
					}
					sinkSnapshot, sinkDecision = s.Snapshot(), d
				}
			}
		}
	}
}

// BenchmarkSequencesJSON112 は旧JSONコピーで同じ72系列を測定します。
//
// 引数: b(*testing.B)。返り値: ありません。
func BenchmarkSequencesJSON112(b *testing.B) { benchmarkSequences(b, false) }

// BenchmarkSequencesFast112 は明示コピーで同じ72系列を測定します。
//
// 引数: b(*testing.B)。返り値: ありません。
func BenchmarkSequencesFast112(b *testing.B) { benchmarkSequences(b, true) }

// benchmarkBB は同じ48確定足と各公開Snapshotのコピーを測定します。
//
// 引数: b(*testing.B)、fast(bool)。返り値: ありません。
func benchmarkBB(b *testing.B, fast bool) {
	bars := make([]ClosedBar, 48)
	oldbars := make([]old.ClosedBar, 48)
	for i := range bars {
		bars[i] = barFixture(i+1, 1000+float64(i%7))
		v := bars[i]
		oldbars[i] = old.ClosedBar{Scope: v.Scope, ID: v.ID, Ordinal: v.Ordinal, Start: v.Start, End: v.End, AvailableAt: v.AvailableAt, Known: v.Known, Close: v.Close}
	}
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if fast {
			s, _ := NewBBState(bars[0].Scope)
			for _, bar := range bars {
				var r BBResult
				var e error
				s, r, e = AdvanceBB(s, bar, bar.AvailableAt)
				if e != nil {
					b.Fatal(e)
				}
				sinkBB = r
				sinkSnapshot = s.Snapshot()
			}
		} else {
			s, _ := old.NewBBState(bars[0].Scope)
			for _, bar := range oldbars {
				var r old.BBResult
				var e error
				s, r, e = old.AdvanceBB(s, bar, bar.AvailableAt)
				if e != nil {
					b.Fatal(e)
				}
				sinkBB = r
				sinkSnapshot = s.Snapshot()
			}
		}
	}
}

// BenchmarkBBJSON112 は旧コピーで48足を測定します。
//
// 引数: b(*testing.B)。返り値: ありません。
func BenchmarkBBJSON112(b *testing.B) { benchmarkBB(b, false) }

// BenchmarkBBFast112 は明示コピーで48足を測定します。
//
// 引数: b(*testing.B)。返り値: ありません。
func BenchmarkBBFast112(b *testing.B) { benchmarkBB(b, true) }
