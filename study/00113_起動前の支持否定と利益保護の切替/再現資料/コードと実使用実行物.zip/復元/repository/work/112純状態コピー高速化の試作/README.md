# 112純状態コピーの人工試作

固定112と別名の `profitfloor112fast`。市場F1・金融結果・正式レポートへは適用していない。

変更はJSONの `copyValue` を型別の明示的な深いコピーへ置き換えたことだけ。政策・definition112・価格・公表三値・床・丸め・式は同じ。元types/state/bbの演算本文と既存人工は、package名等の許容差以外すべてgofmt後のbytes一致。旧停止とその所有/再用ファイルは前後SHA一致。

人工は元72系列の696判断・768状態を**field除外なし、JSON bytes同体**で確認。さらに5政策180系列/1740遷移を生BB付きで照合。全16主test・vet・build成功。全ポインタ/入れ子/足窓の破壊、前状態不変、同一入力参照の分離、nil/非nil空、不正UTF-8の旧JSONと同じ置換も確認した。独立静的レビューで実害候補なし。

| 同じ人工処理を1回 | 旧JSON中央値 | 明示copy中央値 | 速度比 | byte割当 | 割当回数 |
|---|---:|---:|---:|---:|---:|
| 72系列/696遷移、各Snapshot保存 | 24.482ms | 0.775ms | 31.58倍 | 4,852,222→829,761 | 60,923→15,448 |
| 48確定足BB、各Snapshot保存 | 3.637ms | 0.447ms | 8.13倍 | 899,562→478,738 | 8,621→2,247 |

Windows/amd64、Ryzen 9 7950X3D、Go 1.24.2、GOMAXPROCS=1、250ms×5回。fixture/型変換は測定外、両側同じ遷移・保存範囲。これは局所部品の人工測定で、市場全体・I/O・Source・Actorの速度比ではない。同時に別処理が動くPC上の測定である。

`copyValue`の入力は旧コメントと同じ「検証済み有限値」。未列挙型はpanicし、将来の型を浅いコピーへ落とさない。BBの窓SHA用JSON計算は元のまま残る。State/BBStateの同ID再公表・エラー時の値返却規則も元のままで、次の成功Advanceが参照を切る。文字列はGoで不変なので有効文字列のbyte列複製は行わず、不正UTF-8だけ正規化する。

再現：本folderで `go test ./...`、`go vet ./...`、`go build ./...`。性能は `GOMAXPROCS=1` を設定して `go test -run '^$' -bench 'Benchmark(Sequences|BB)' -benchmem -benchtime=250ms -count=5`。生の5回は [ベンチマーク.txt](ベンチマーク.txt)、指紋・差・集計は [結果.json](結果.json)。市場/Raw/Native/価格CSV/11月9日本文の追加読取0、ネット取得0。
