package profitfloor112fast

import "unicode/utf8"

// copyText は旧JSONコピーの不正UTF-8置換だけを保持します。
//
// 引数: value(string)は公開識別子等。返り値: stringは有効文字列又は各不正byteを置換した文字列です。
func copyText(value string) string {
	if utf8.ValidString(value) {
		return value
	}
	return string([]rune(value))
}

// copyPointer は値だけの参照を毎回別の領域へ写します。
//
// 引数: value(*T)は値型への参照。返り値: *Tはnilを保持した独立参照です。
func copyPointer[T any](value *T) *T {
	if value == nil {
		return nil
	}
	out := *value
	return &out
}

// copyScope は場の値とJSONと同じ識別子を写します。
//
// 引数: value(Scope)。返り値: Scopeは数値を変えない写しです。
func copyScope(value Scope) Scope {
	value.Session, value.Contract = copyText(value.Session), copyText(value.Contract)
	return value
}

// copyEvidence はATRの出典を独立した参照へ写します。
//
// 引数: value(*Evidence)。返り値: *Evidenceはnilを保持した写しです。
func copyEvidence(value *Evidence) *Evidence {
	out := copyPointer(value)
	if out != nil {
		out.ID = copyText(out.ID)
	}
	return out
}

// copyPivot は構造値を無変換で独立参照へ写します。
//
// 引数: value(*Pivot)。返り値: *Pivotはnilを保持した写しです。
func copyPivot(value *Pivot) *Pivot {
	out := copyPointer(value)
	if out != nil {
		out.Scope, out.ID, out.Kind = copyScope(out.Scope), copyText(out.ID), copyText(out.Kind)
	}
	return out
}

// copyBB は7本の数値参照を個別に私有化します。
//
// 引数: value(BBResult)。返り値: BBResultは生値と未知を保持した深い写しです。
func copyBB(value BBResult) BBResult {
	value.Scope, value.ID = copyScope(value.Scope), copyText(value.ID)
	value.WindowSHA, value.ResetReason = copyText(value.WindowSHA), copyText(value.ResetReason)
	value.SMA, value.Sigma = copyPointer(value.SMA), copyPointer(value.Sigma)
	value.Upper, value.Lower = copyPointer(value.Upper), copyPointer(value.Lower)
	value.Width, value.BandWidth, value.PercentB = copyPointer(value.Width), copyPointer(value.BandWidth), copyPointer(value.PercentB)
	return value
}

// copyPublication はV/Close/pivot/BBの入れ子をすべて私有化します。
//
// 引数: value(*Publication)。返り値: *Publicationはnilと生C/M/P/Bを保持した写しです。
func copyPublication(value *Publication) *Publication {
	if value == nil {
		return nil
	}
	out := *value
	out.Scope, out.ID = copyScope(out.Scope), copyText(out.ID)
	out.V, out.Close = copyPointer(out.V), copyPointer(out.Close)
	out.PriorPivot = copyPivot(out.PriorPivot)
	if value.BB != nil {
		bb := copyBB(*value.BB)
		out.BB = &bb
	}
	return &out
}

// copyEntry は実取得とATRを私有化します。
//
// 引数: value(Entry)。返り値: Entryは政策や価格を変えない写しです。
func copyEntry(value Entry) Entry {
	value.Scope, value.Policy = copyScope(value.Scope), Policy(copyText(string(value.Policy)))
	value.ATR = copyEvidence(value.ATR)
	return value
}

// copySnapshot は取得・起動時刻・峰・床・最新公表を私有化します。
//
// 引数: value(Snapshot)。返り値: Snapshotは全fieldの値とnilを保持する写しです。
func copySnapshot(value Snapshot) Snapshot {
	value.Definition.Policy = Policy(copyText(string(value.Definition.Policy)))
	value.Definition.WarningFormula = copyText(value.Definition.WarningFormula)
	value.Entry = copyEntry(value.Entry)
	value.ActivatedAt, value.NarrowedAt = copyPointer(value.ActivatedAt), copyPointer(value.NarrowedAt)
	value.PeakPoints, value.FloorPoints = copyPointer(value.PeakPoints), copyPointer(value.FloorPoints)
	value.Latest = copyPublication(value.Latest)
	return value
}

// copyDecision は純判断の7本の数値参照を個別に切ります。
//
// 引数: value(Decision)。返り値: Decisionは数式結果を変えない写しです。
func copyDecision(value Decision) Decision {
	value.WidthSource = copyText(value.WidthSource)
	value.GainPoints, value.UnitNetYen, value.WholeNetYen = copyPointer(value.GainPoints), copyPointer(value.UnitNetYen), copyPointer(value.WholeNetYen)
	value.WholeFloor, value.PeakFloor = copyPointer(value.WholeFloor), copyPointer(value.PeakFloor)
	value.StructuralFloor, value.ProtectPrice = copyPointer(value.StructuralFloor), copyPointer(value.ProtectPrice)
	return value
}

// copyInput は人工比較用に正常値と公表を私有化します。
//
// 引数: value(Input)。返り値: Inputは段階とreset文字列を保持する写しです。
func copyInput(value Input) Input {
	value.Phase, value.ResetReason = Phase(copyText(string(value.Phase))), copyText(value.ResetReason)
	value.Mark, value.Publication = copyPointer(value.Mark), copyPublication(value.Publication)
	return value
}

// copyBar は確定足の終値参照を私有化します。
//
// 引数: value(ClosedBar)。返り値: ClosedBarは足時計・ID・既知性を保持する写しです。
func copyBar(value ClosedBar) ClosedBar {
	value.Scope, value.ID = copyScope(value.Scope), copyText(value.ID)
	value.Close = copyPointer(value.Close)
	return value
}

// copyValue は停止112で実際に使用する型だけを明示的に深く写します。
//
// 引数: value(T)は旧契約と同じ検証済み有限値です。
// 返り値: Tはnil/非nil空を保持し、各可変参照を個別に切った写しです。
// 未列挙型はpanicし、将来の型追加を暗黙の浅いコピーへ流しません。
func copyValue[T any](value T) T {
	var out any
	switch v := any(value).(type) {
	case Entry:
		out = copyEntry(v)
	case Snapshot:
		out = copySnapshot(v)
	case Publication:
		out = *copyPublication(&v)
	case *Publication:
		out = copyPublication(v)
	case BBResult:
		out = copyBB(v)
	case *BBResult:
		if v == nil {
			out = (*BBResult)(nil)
		} else {
			b := copyBB(*v)
			out = &b
		}
	case *Evidence:
		out = copyEvidence(v)
	case *Pivot:
		out = copyPivot(v)
	case *float64:
		out = copyPointer(v)
	case Decision:
		out = copyDecision(v)
	case Input:
		out = copyInput(v)
	case ClosedBar:
		out = copyBar(v)
	case *ClosedBar:
		if v == nil {
			out = (*ClosedBar)(nil)
		} else {
			b := copyBar(*v)
			out = &b
		}
	case []ClosedBar:
		if v == nil {
			out = ([]ClosedBar)(nil)
		} else {
			bars := make([]ClosedBar, len(v))
			for i := range v {
				bars[i] = copyBar(v[i])
			}
			out = bars
		}
	case []float64:
		if v == nil {
			out = ([]float64)(nil)
		} else {
			values := make([]float64, len(v))
			copy(values, v)
			out = values
		}
	default:
		panic("高速コピーの未列挙型")
	}
	return out.(T)
}
