// Package profitfloor112fast は111対照を維持し、通常幅と支持否定必須を分ける注文なしの純保護です。
package profitfloor112fast

import (
	"fmt"

	prior "github.com/masayoshi4649/SessionTradeExecuter/profitfloor111"
)

type Policy string

const (
	S0   Policy = "S0"
	W100 Policy = "W100"
	B100 Policy = "B100"
	W400 Policy = "W400"
	P100 Policy = "P100"
	P400 Policy = "P400"
)

// 公表型だけを111へaliasし、停止chart111が生成した生C/M/P/Bを無変換で受け取ります。
type Truth = prior.Truth
type Phase = prior.Phase
type Scope = prior.Scope
type Evidence = prior.Evidence
type Pivot = prior.Pivot
type Publication = prior.Publication
type BBResult = prior.BBResult

const (
	Unknown     = prior.Unknown
	False       = prior.False
	True        = prior.True
	PreFill     = prior.PreFill
	AfterSource = prior.AfterSource
)

type Definition struct {
	Version            int     `json:"version"`
	Policy             Policy  `json:"policy"`
	Enabled            bool    `json:"enabled"`
	ThresholdPoints    float64 `json:"threshold_points"`
	NormalWidthMinimum float64 `json:"normal_width_minimum"`
	ATRMultiplier      float64 `json:"atr_multiplier"`
	WarningFormula     string  `json:"warning_formula"`
	TechnicalNarrowing bool    `json:"technical_narrowing"`
}

type Entry struct {
	Scope           Scope     `json:"scope"`
	Policy          Policy    `json:"policy"`
	Side            int       `json:"side"`
	Price           float64   `json:"price"`
	At              float64   `json:"at"`
	InitialQuantity int       `json:"initial_quantity"`
	SlipPoints      float64   `json:"slip_points"`
	ATR             *Evidence `json:"atr"`
}

type Input struct {
	At           float64      `json:"at"`
	Sequence     uint64       `json:"sequence"`
	Phase        Phase        `json:"phase"`
	Mark         *float64     `json:"mark"`
	Remaining    int          `json:"remaining"`
	Reserved     int          `json:"reserved"`
	ClosedNetYen float64      `json:"closed_net_yen"`
	Publication  *Publication `json:"publication"`
	ResetReason  string       `json:"reset_reason"`
}

type Snapshot struct {
	Definition         Definition   `json:"definition"`
	Entry              Entry        `json:"entry"`
	ThresholdPoints    float64      `json:"threshold_points"`
	NormalWidth        float64      `json:"normal_width"`
	ATRUnknownFallback bool         `json:"atr_unknown_fallback"`
	CostPerUnitYen     float64      `json:"cost_per_unit_yen"`
	MinimumFloor       float64      `json:"minimum_floor"`
	Active             bool         `json:"active"`
	ActivatedAt        *float64     `json:"activated_at"`
	Narrowed           bool         `json:"narrowed"`
	NarrowedAt         *float64     `json:"narrowed_at"`
	PeakPoints         *float64     `json:"peak_points"`
	WidthPoints        float64      `json:"width_points"`
	FloorPoints        *float64     `json:"floor_points"`
	WholeTargetYen     float64      `json:"whole_target_yen"`
	ClosedNetYen       float64      `json:"closed_net_yen"`
	Remaining          int          `json:"remaining"`
	Reserved           int          `json:"reserved"`
	Latest             *Publication `json:"latest"`
	At                 float64      `json:"at"`
	Sequence           uint64       `json:"sequence"`
	Finished           bool         `json:"finished"`
}

type Decision struct {
	C                    Truth    `json:"c"`
	M                    Truth    `json:"m"`
	P                    Truth    `json:"p"`
	B                    Truth    `json:"b"`
	Warning              Truth    `json:"warning"`
	GainPoints           *float64 `json:"gain_points"`
	UnitNetYen           *float64 `json:"unit_net_yen"`
	WholeNetYen          *float64 `json:"whole_net_yen"`
	ActivatedNow         bool     `json:"activated_now"`
	NarrowedNow          bool     `json:"narrowed_now"`
	WidthSource          string   `json:"width_source"`
	WholeFloor           *float64 `json:"whole_floor"`
	PeakFloor            *float64 `json:"peak_floor"`
	StructuralFloor      *float64 `json:"structural_floor"`
	ProtectPrice         *float64 `json:"protect_price"`
	ProtectPriceValid    bool     `json:"protect_price_valid"`
	FloorHit             bool     `json:"floor_hit"`
	AllReservedHit       bool     `json:"all_reserved_hit"`
	FreeQuantity         int      `json:"free_quantity"`
	EligibleExitQuantity int      `json:"eligible_exit_quantity"`
}

type State struct {
	initialized     bool
	view            Snapshot
	wholeTargetHalf int64
	lastPublication *Publication
}

type Configuration struct {
	Policy       Policy  `json:"policy"`
	SlipPoints   float64 `json:"slip_points"`
	DelaySeconds int     `json:"delay_seconds"`
}

// DefinitionFor は真の政策IDに対応する幅・警戒・追加保護の有無を明示します。
//
// 引数: policy(Policy)は112の六政策。返り値: Definition/errorは定義又は未宣言です。
func DefinitionFor(policy Policy) (Definition, error) {
	d := Definition{Version: 112, Policy: policy, Enabled: true, ThresholdPoints: 100, NormalWidthMinimum: 200, ATRMultiplier: 2, WarningFormula: "M AND(C OR P)"}
	switch policy {
	case S0:
		d.Enabled, d.ThresholdPoints, d.NormalWidthMinimum, d.ATRMultiplier, d.WarningFormula = false, 0, 0, 0, "追加保護なし"
	case W100:
	case B100:
		d.WarningFormula, d.TechnicalNarrowing = "M AND(C OR B OR P)", true
	case W400:
		d.NormalWidthMinimum, d.ATRMultiplier = 400, 4
	case P100:
		d.WarningFormula, d.TechnicalNarrowing = "M AND P", true
	case P400:
		d.NormalWidthMinimum, d.ATRMultiplier, d.WarningFormula, d.TechnicalNarrowing = 400, 4, "M AND P", true
	default:
		return Definition{}, fmt.Errorf("112の政策IDではない")
	}
	return d, nil
}

// DeclaredDefinitions は政策順と本当の通常幅・警戒の定義を返します。
//
// 引数: なし。返り値: []Definitionは六政策の説明と固定演算定義です。
func DeclaredDefinitions() []Definition {
	out := []Definition{}
	for _, policy := range []Policy{S0, W100, B100, W400, P100, P400} {
		d, _ := DefinitionFor(policy)
		out = append(out, d)
	}
	return out
}

// DeclaredConfigurations は112の六政策・費用・遅延の24組を順に返します。
//
// 引数: なし。返り値: []ConfigurationはS0/W100/B100/W400/P100/P400×C0/C5×D0/D1です。
func DeclaredConfigurations() []Configuration {
	out := []Configuration{}
	for _, p := range []Policy{S0, W100, B100, W400, P100, P400} {
		for _, s := range []float64{0, 5} {
			for _, d := range []int{0, 1} {
				out = append(out, Configuration{p, s, d})
			}
		}
	}
	return out
}
