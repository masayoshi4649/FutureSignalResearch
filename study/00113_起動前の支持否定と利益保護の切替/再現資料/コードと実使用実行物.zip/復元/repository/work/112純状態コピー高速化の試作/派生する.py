"""停止済み112から、別名の人工専用コピー試作を作る。"""
from pathlib import Path
import hashlib
import json

出力 = Path(__file__).resolve().parent
元 = 出力.parent / "112支持否定の必須確認と通常幅のみ"


def 作成する() -> None:
    """
    機能: 停止正本を認証し、コピー処理以外の演算本文を保持して別名派生する。
    引数: なし。
    返り値: None。元ファイルの書換えは行わない。
    """
    停止 = 元 / "停止.json"
    assert hashlib.sha256(停止.read_bytes()).hexdigest() == "b7748c29ae5c6bc44a66a112421809f888c85321652a0d9bfbb3c7f4022dd835"
    台帳 = json.loads(停止.read_text(encoding="utf-8-sig"))
    全指紋 = {**台帳["所有コードSHA256"], **台帳["再用コードSHA256"]}
    for k, v in 全指紋.items():
        assert hashlib.sha256(Path(k).read_bytes()).hexdigest() == v, k
    正規化差 = {}
    for 名前 in ["types.go", "state.go", "bb.go", "state_test.go", "bb_test.go"]:
        本文 = (元 / 名前).read_text(encoding="utf-8-sig")
        派生 = 本文.replace("package profitfloor112", "package profitfloor112fast", 1)
        if 名前 == "types.go":
            派生 = 派生.replace("// Package profitfloor112 ", "// Package profitfloor112fast ", 1)
        if 名前 == "state.go":
            始 = 派生.index("// copyValue ")
            終 = 派生.index("// finite ", 始)
            派生 = 派生[:始] + 派生[終:]
            派生 = 派生.replace('\t"encoding/json"\n', "", 1)
        (出力 / 名前).write_text(派生, encoding="utf-8")
        正規化差[名前] = {"元SHA256": hashlib.sha256((元 / 名前).read_bytes()).hexdigest(), "許容差": "package名とPackageコメント。state.goのみcopyValue本文と未使用JSONimportを除去"}
    (出力 / "go.mod").write_text('''module github.com/masayoshi4649/SessionTradeExecuter/profitfloor112fast

go 1.24.2

require (
 github.com/masayoshi4649/SessionTradeExecuter/profitfloor111 v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/profitfloor112 v0.0.0
)

replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor111 => ../111全玉利益と収束BBの純保護
replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor112 => ../112支持否定の必須確認と通常幅のみ
''', encoding="utf-8")
    (出力 / "派生の参照.json").write_text(json.dumps({"人工専用": True, "市場実行": False, "元停止": str(停止), "元停止SHA256": hashlib.sha256(停止.read_bytes()).hexdigest(), "元と再用の前指紋": 全指紋, "派生差": 正規化差}, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")


if __name__ == "__main__":
    作成する()
