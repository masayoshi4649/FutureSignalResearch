package profitfloor112fast

import (
	"fmt"
	"math"
	"reflect"
)

// finite は非有限値を拒否します。
//
// 引数: values(...float64)は数値列。返り値: boolは全値が有限なら真です。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// pointer は保存する数値の新しい参照を返します。
//
// 引数: value(float64)は有限値。返り値: *float64は独立参照です。
func pointer(value float64) *float64 { return &value }

// validScope は場と限月の明示を確認します。
//
// 引数: s(Scope)は境界。返り値: boolは正常なとき真です。
func validScope(s Scope) bool {
	return s.Session != "" && s.Contract != "" && finite(s.Start) && s.Start >= 0
}

// ceil5 は保護値幅をminiの5pt単位へ切り上げます。
//
// 引数: x(float64)は有限値。返り値: float64は5pt単位です。
func ceil5(x float64) float64 { return 5 * math.Ceil(x/5) }

// ceilDiv は負数にも数学的ceilを適用します。
//
// 引数: numerator/denominator(int64)は分子と正分母。返り値: int64は切上げ商です。
func ceilDiv(numerator, denominator int64) int64 {
	q, r := numerator/denominator, numerator%denominator
	if r > 0 {
		q++
	}
	return q
}

// moneyHalf は円の半円単位を厳密整数へ写します。
//
// 引数: yen(float64)は有限な円額。返り値: int64/errorは半円整数又は拒否です。
func moneyHalf(yen float64) (int64, error) {
	if !finite(yen) || math.Abs(yen) > 1e12 || 2*yen != math.Trunc(2*yen) {
		return 0, fmt.Errorf("金額は有限の半円単位が必要")
	}
	return int64(2 * yen), nil
}

// And は三値ANDを評価します。
//
// 引数: a/b(Truth)は未知・偽・真。返り値: Truth/errorは三値結果又は不正です。
func And(a, b Truth) (Truth, error) {
	if a > True || b > True {
		return Unknown, fmt.Errorf("三値の定義域外")
	}
	if a == False || b == False {
		return False, nil
	}
	if a == Unknown || b == Unknown {
		return Unknown, nil
	}
	return True, nil
}

// Or は三値ORを評価します。
//
// 引数: a/b(Truth)は未知・偽・真。返り値: Truth/errorは三値結果又は不正です。
func Or(a, b Truth) (Truth, error) {
	if a > True || b > True {
		return Unknown, fmt.Errorf("三値の定義域外")
	}
	if a == True || b == True {
		return True, nil
	}
	if a == Unknown || b == Unknown {
		return Unknown, nil
	}
	return False, nil
}

// NewState は取得時尺度・H・通常幅を一度だけ固定します。
//
// 引数: e(Entry)は一つの実新規約定。返り値: State/errorは純状態又は不正です。S0は対象外です。
func NewState(e Entry) (State, error) {
	definition, err := DefinitionFor(e.Policy)
	if err != nil || !definition.Enabled || !validScope(e.Scope) || (e.Side != 1 && e.Side != -1) || !finite(e.Price, e.At, e.SlipPoints) || e.Price <= 0 || e.Price > 1e9 || math.Mod(e.Price, 5) != 0 || e.At < e.Scope.Start || e.InitialQuantity < 1 || e.InitialQuantity > 10 || (e.SlipPoints != 0 && e.SlipPoints != 5) {
		return State{}, fmt.Errorf("実取得・政策・費用又は場が不正")
	}
	h := definition.ThresholdPoints
	width := definition.NormalWidthMinimum
	if e.ATR != nil {
		a := e.ATR
		if a.ID == "" || !finite(a.Value, a.AvailableAt) || a.Value <= 0 || a.Value > 1e6 || a.AvailableAt < e.Scope.Start || a.AvailableAt > e.At {
			return State{}, fmt.Errorf("取得時ATRの出典・値・時計が不正")
		}
		width = ceil5(math.Max(definition.NormalWidthMinimum, definition.ATRMultiplier*a.Value))
	}
	cost := 77 + 200*e.SlipPoints
	v := Snapshot{Definition: definition, Entry: copyValue(e), ThresholdPoints: h, NormalWidth: width, ATRUnknownFallback: e.ATR == nil, CostPerUnitYen: cost, MinimumFloor: float64(5 * ceilDiv(int64(cost)+500, 500)), WidthPoints: width, Remaining: e.InitialQuantity, At: e.At}
	return State{initialized: true, view: v}, nil
}

// Snapshot は私有状態を独立した公開値で返します。
//
// 引数: receiver(State)は現在状態。返り値: Snapshotは参照共有のない保存値です。
func (s State) Snapshot() Snapshot { return copyValue(s.view) }

// validatePublication は3分公表とpivot/BBの未来・境界違いを拒否します。
//
// 引数: p(*Publication)、e(Entry)、at(float64)は公表・実取得・利用時計。返り値: errorは不正です。
func validatePublication(p *Publication, e Entry, at float64) error {
	if p.Scope != e.Scope || p.ID == "" || p.Ordinal < 1 || !finite(p.Start, p.End, p.AvailableAt) || p.Start < e.Scope.Start || p.End != p.Start+180 || math.Mod(p.Start-e.Scope.Start, 180) != 0 || p.AvailableAt < p.End || p.AvailableAt > at || p.C > True || p.M > True {
		return fmt.Errorf("3分公表の場・時計・三値が不正")
	}
	if p.V != nil && (!finite(*p.V) || *p.V < 5 || *p.V > 1e6) {
		return fmt.Errorf("公開Vが不正")
	}
	if p.Close != nil && (!finite(*p.Close) || *p.Close <= 0) {
		return fmt.Errorf("公開終値が不正")
	}
	if x := p.PriorPivot; x != nil {
		if x.Scope != e.Scope || x.ID == "" || (x.Kind != "low" && x.Kind != "high") || !finite(x.Price, x.CenterStart, x.CenterEnd, x.ConfirmEnd, x.PublishedAt) || x.Price <= 0 || x.CenterStart < e.Scope.Start || x.CenterEnd != x.CenterStart+180 || x.ConfirmEnd < x.CenterEnd || x.PublishedAt < x.ConfirmEnd || x.PublishedAt > p.AvailableAt {
			return fmt.Errorf("公開pivotの出典・確認時計が不正")
		}
		if e.Side == 1 && x.Kind != "low" || e.Side == -1 && x.Kind != "high" {
			return fmt.Errorf("pivotの方向が不正")
		}
	}
	if p.BB != nil {
		if err := validateBBResult(*p.BB); err != nil {
			return err
		}
		if p.BB.Scope != p.Scope || p.BB.ID != p.ID || p.BB.End != p.End || p.BB.AvailableAt != p.AvailableAt || p.BB.DeliveredAt > at {
			return fmt.Errorf("BB公表と3分公表の結合差")
		}
	}
	return nil
}

// warningFor は収縮役C/Bと勢いM・構造Pを混同せず結びます。
//
// 引数: v(Snapshot)は現在の公開状態。返り値: Decisionは三値の監査だけです。
func warningFor(v Snapshot) Decision {
	d := Decision{}
	if p := v.Latest; p != nil {
		d.C, d.M = p.C, p.M
		if p.Close != nil && p.PriorPivot != nil {
			d.P = False
			if float64(v.Entry.Side)*(*p.Close-p.PriorPivot.Price) < 0 {
				d.P = True
			}
		}
		if p.BB != nil {
			d.B = p.BB.Contraction
		}
	}
	if v.Entry.Policy == P100 || v.Entry.Policy == P400 {
		d.Warning, _ = And(d.M, d.P)
	} else {
		x, _ := Or(d.C, d.P)
		if v.Entry.Policy == B100 {
			x, _ = Or(x, d.B)
		}
		d.Warning, _ = And(d.M, x)
	}
	return d
}

// selectedWidth はラッチ後だけ現在の既知尺度で狭幅を選びます。
//
// 引数: v(Snapshot)は起動済み状態。返り値: float64/stringは幅と由来です。
func selectedWidth(v Snapshot) (float64, string) {
	if !v.Narrowed {
		return v.NormalWidth, "取得時固定通常幅"
	}
	var a, x *float64
	if v.Entry.ATR != nil {
		a = &v.Entry.ATR.Value
	}
	if v.Latest != nil {
		x = v.Latest.V
	}
	if a == nil && x == nil {
		return v.WidthPoints, "狭幅尺度未知・既存幅保持"
	}
	value := 0.0
	label := ""
	switch {
	case a != nil && x != nil:
		value = math.Min(*a, *x)
		label = "狭幅min取得時ATRと現V"
	case a != nil:
		value = *a
		label = "狭幅取得時ATR"
	default:
		value = *x
		label = "狭幅現V"
	}
	return math.Min(v.NormalWidth, ceil5(math.Max(10, value))), label
}

// Advance は原行の会計値から必須起動と非緩和床だけを純評価します。
//
// 引数: state(State)は以前の状態、in(Input)は単調な実会計入力。返り値: State/Decision/errorは新状態・要求可能量又は不正です。
func Advance(state State, in Input) (State, Decision, error) {
	empty := Decision{}
	if !state.initialized || state.view.Finished || !finite(in.At) || in.At < state.view.At || in.Sequence <= state.view.Sequence || (in.Phase != PreFill && in.Phase != AfterSource) || in.Remaining < 0 || in.Remaining > state.view.Remaining || in.Reserved < 0 || in.Reserved > in.Remaining || (in.Publication != nil && in.ResetReason != "") {
		return state, empty, fmt.Errorf("状態・時計・数量・段階又はresetが不正")
	}
	rhalf, err := moneyHalf(in.ClosedNetYen)
	if err != nil {
		return state, empty, err
	}
	if in.Remaining == state.view.Remaining && in.ClosedNetYen != state.view.ClosedNetYen {
		return state, empty, fmt.Errorf("実数量減少なしの既返済額変更")
	}
	if in.Mark != nil && (!finite(*in.Mark) || *in.Mark <= 0 || *in.Mark > 1e9) {
		return state, empty, fmt.Errorf("正常返済価格が不正")
	}
	if in.Publication != nil {
		if err = validatePublication(in.Publication, state.view.Entry, in.At); err != nil {
			return state, empty, err
		}
	}
	s := state
	s.view = copyValue(state.view)
	s.lastPublication = copyValue(state.lastPublication)
	if in.ResetReason != "" {
		s.view.Latest = nil
	}
	if p := in.Publication; p != nil {
		if s.lastPublication != nil && p.ID == s.lastPublication.ID {
			if !reflect.DeepEqual(p, s.lastPublication) {
				return state, empty, fmt.Errorf("同ID公表の値変更")
			}
		} else {
			if s.lastPublication != nil && (p.End <= s.lastPublication.End || p.Ordinal <= s.lastPublication.Ordinal) {
				return state, empty, fmt.Errorf("公表の後退")
			}
			s.view.Latest = copyValue(p)
			s.lastPublication = copyValue(p)
		}
	}
	v := &s.view
	v.At, v.Sequence, v.Remaining, v.Reserved, v.ClosedNetYen = in.At, in.Sequence, in.Remaining, in.Reserved, in.ClosedNetYen
	d := warningFor(*v)
	d.FreeQuantity = in.Remaining - in.Reserved
	if in.Remaining == 0 {
		v.Finished = true
		return s, d, nil
	}
	if in.Mark == nil {
		return s, d, nil
	}
	gain := float64(v.Entry.Side) * (*in.Mark - v.Entry.Price)
	unit := 100*gain - v.CostPerUnitYen
	whole := in.ClosedNetYen + float64(in.Remaining)*unit
	if !finite(gain, unit, whole) {
		return state, empty, fmt.Errorf("実評価が非有限")
	}
	d.GainPoints, d.UnitNetYen, d.WholeNetYen = pointer(gain), pointer(unit), pointer(whole)
	eligible := whole >= float64(v.Entry.InitialQuantity)*100*v.ThresholdPoints
	if !v.Active && eligible {
		v.Active = true
		v.ActivatedAt = pointer(in.At)
		v.PeakPoints = pointer(gain)
		d.ActivatedNow = true
	}
	if !v.Active {
		return s, d, nil
	}
	if gain > *v.PeakPoints {
		v.PeakPoints = pointer(gain)
	}
	tech := v.Definition.TechnicalNarrowing
	if tech && d.Warning == True && !v.Narrowed {
		v.Narrowed = true
		v.NarrowedAt = pointer(in.At)
		d.NarrowedNow = true
	}
	v.WidthPoints, d.WidthSource = selectedWidth(*v)
	floor := v.MinimumFloor
	if v.FloorPoints != nil {
		floor = math.Max(floor, *v.FloorPoints)
	}
	peakFloor := ceil5(*v.PeakPoints - v.WidthPoints)
	d.PeakFloor = pointer(peakFloor)
	floor = math.Max(floor, peakFloor)
	numerator := int64(in.Remaining)*int64(2*v.CostPerUnitYen) + s.wholeTargetHalf - rhalf
	fw := float64(5 * ceilDiv(numerator, int64(1000*in.Remaining)))
	d.WholeFloor = pointer(fw)
	floor = math.Max(floor, fw)
	if tech && d.Warning == True && v.Latest != nil && v.Latest.PriorPivot != nil {
		p := v.Latest.PriorPivot
		if p.CenterStart >= v.Entry.At {
			f := ceil5(float64(v.Entry.Side) * (p.Price - float64(v.Entry.Side)*5 - v.Entry.Price))
			if f > v.MinimumFloor {
				d.StructuralFloor = pointer(f)
				floor = math.Max(floor, f)
			}
		}
	}
	v.FloorPoints = pointer(floor)
	implied := rhalf + int64(in.Remaining)*(int64(200*floor)-int64(2*v.CostPerUnitYen))
	if implied > s.wholeTargetHalf {
		s.wholeTargetHalf = implied
	}
	v.WholeTargetYen = float64(s.wholeTargetHalf) / 2
	protect := v.Entry.Price + float64(v.Entry.Side)*floor
	d.ProtectPrice = pointer(protect)
	d.ProtectPriceValid = finite(protect) && protect > 0
	d.FloorHit = gain <= floor
	d.AllReservedHit = d.FloorHit && in.Reserved == in.Remaining
	if d.FloorHit && in.Phase == AfterSource {
		d.EligibleExitQuantity = d.FreeQuantity
	}
	return s, d, nil
}
