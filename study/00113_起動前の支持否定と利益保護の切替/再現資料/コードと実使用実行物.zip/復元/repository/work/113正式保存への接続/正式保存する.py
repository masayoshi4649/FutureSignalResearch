"""113正本を同bytes保存し、既正式111/112の同体コードは複製せず参照する。"""

import argparse
from copy import deepcopy
import importlib.util
from pathlib import Path
import json
import re
import shutil
import zipfile


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
TRIAL = ROOT / 'study/00113_起動前の支持否定と利益保護の切替'
OUTPUTS = ROOT / 'outputs'
PREVIOUS_PATH = ROOT / 'work/111正式保存への接続/正式保存する.py'
PREVIOUS_SHA = 'dd670dd308b79372b0010eca7e0e602fb9af77db5e95c4cbc95d7548d3c1c44e'
import hashlib
if hashlib.sha256(PREVIOUS_PATH.read_bytes()).hexdigest() != PREVIOUS_SHA:
    raise ValueError('停止111正式保存器のSHA差')
SPEC = importlib.util.spec_from_file_location('113が再用する111正式保存共通部', PREVIOUS_PATH)
C = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(C)
need, sha, bind, read, write_json, Z = C.need, C.sha, C.bind, C.read, C.write_json, C.Z
CONFIGS = tuple({'policy': p, 'slip_pts': c, 'delay_seconds': d}
                for p in ('S0', 'W100', 'P100', 'P50', 'E100', 'E50') for c in (0, 5) for d in (0, 1))
KEYS = tuple(f"{r['policy']}_C{r['slip_pts']}_D{r['delay_seconds']}" for r in CONFIGS)
REQUIRED = {'condition', 'market', 'result', 'saved_check', 'core_stop', 'actor_stop', 'pure_stop', 'save_stop', 'P_stop',
            'formal_stop', 'code_material', 'code_material_stop'}
METRICS = ('entry_invalidated_positions', 'entry_invalidation_exit_requests', 'entry_invalidation_exit_fills')



def ref(path: Path) -> dict:
    """機能: 明示成果物の絶対位置と全bytes指紋を返す。

    引数: path(Path)は対象。
    返り値: dictはpath/sha256のFileRef。
    """
    return {'path': str(path.resolve()), 'sha256': sha(path)}


def validate(values: dict, request: dict) -> list[str]:
    """機能: 113全70・独立1680・旧112対照840と既正式コード依存を結ぶ。

    引数: values/request(dict)は認証済みmetadataとRoot固定要求。
    返り値: list[str]は全70場。金融やCSVを再生成しない。
    """
    condition, market, result, saved = (values[k] for k in ('condition', 'market', 'result', 'saved_check'))
    refs, expected = request['refs'], C.sessions()
    need(condition['trial'] == 113 and condition['fixed'] is True and condition['actual_configurations'] == list(CONFIGS), '113本名条件と24宣言')
    need(condition['entry_grid_seconds'] is None and condition['extra_opening_quiet_seconds'] == 0 and condition['chart_seed_mode'] == 'cold_each_session', '113元連続時計')
    need(condition['runtime_stop'] == refs['core_stop'] and condition['dependency_stops']['actor'] == refs['actor_stop']
         and condition['dependency_stops']['pure'] == refs['pure_stop'], '113実Core/Actor/純Go停止')
    need(market['trial'] == 113 and market['success'] is True and market['stage'] == 'full70'
         and (market['sessions'], market['books'], market['reused_sessions'], market['replayed_sessions']) == (70, 1680, 54, 16), '113全70の成功と認証再用54/再生16')
    need(market['condition_sha256'] == refs['condition']['sha256'] and market['unchanged'] is True
         and market['before'] and market['before'] == market['after'], '113同条件と入力不変')
    need(market['reference112_comparisons'] == 840 and market['all_reference112_equal'] is True and market['all_source111_equal'] is True, '113旧112全12N/Source対照')
    need(market['all_original166_reference_events_equal'] is True and market['historical_saved_events_equal'] is False
         and market['all_original_signal_full_json_equal'] is False, '原文oracleと歴史同体の区別')
    need([r['session'] for r in market['results']] == expected, '113市場全70順序')
    need(all(r['books'] == 24 and r['S0_comparisons'] == 4 and r['S0_equal'] is True and r['complete'] is True
             and r['open_quantity'] == r['pending_quantity'] == 0 and r['reference112_comparisons'] == 12
             and r['reference112_equal'] is True and r['source111_equal'] is True for r in market['results']), '113全場の24冊/旧12/残予約0')
    need(result['試行'] == 113 and result['成功'] is True and result['stage'] == 'full70'
         and result['場数'] == 70 and result['会計数'] == 1680 and result['主key'] == list(KEYS), '113独立全1680')
    need(result['前後不変'] is True and result['入力codeSHA256前'] == result['入力codeSHA256後'] and result['採用'] is False
         and result['研究目標達成'] is False, '113独立不変/採用と区別')
    need(result['金融条件SHA256'] == saved['金融条件SHA256'] == refs['condition']['sha256']
         and result['金融完了SHA256'] == saved['金融完了SHA256'] == refs['market']['sha256'], '113独立から金融成功への結合')
    need(result['Actor停止SHA256'] == refs['actor_stop']['sha256'] and result['保存器停止SHA256'] == refs['save_stop']['sha256']
         and result['独立P停止SHA256'] == refs['P_stop']['sha256'], '113独立の全停止結合')
    need(saved['成功'] is True and saved['前後不変'] is True and saved['不一致数'] == 0 and saved['会計数'] == saved['資源'] == 1680
         and saved['旧112全金融比較'] == 840 and saved['全Source111同体'] is True and saved['全残玉予約0'] is True, '113保存全件検算')
    need(saved['出力SHA256']['結果.json'] == refs['result']['sha256'], '113結果と検算の結合')
    need(len(result['場別']) == 1680 and set(result['集計']) == set(KEYS) and len(result['旧112対照']) == 70, '113全0取引保持')
    for key in KEYS:
        need([r['session'] for r in result['場別'] if r['key'] == key] == expected, '113同条件の全70場.' + key)
    for name in ('core_stop', 'actor_stop', 'pure_stop', 'save_stop', 'P_stop', 'formal_stop'):
        need(values[name]['成功'] is True, '113成功した停止だけ.' + name)
    need(values['formal_stop']['市場前'] is True, '113正式保存器の市場前停止')
    need(values['save_stop']['Actor停止'] == refs['actor_stop'] and values['save_stop']['P停止'] == refs['P_stop'], '113会計停止のActor/P')
    definitions = {r['policy']: r for r in condition['policy_definitions']}
    need(result['保護定義'] == definitions and list(definitions) == [c['policy'] for c in CONFIGS[::4]], '113本名の全政策定義')
    for key in KEYS:
        rows = [row for row in result['場別'] if row['key'] == key]
        summary = result['集計'][key]
        for metric in METRICS:
            need(type(summary.get(metric)) is int and summary[metric] >= 0
                 and all(type(r.get(metric)) is int and r[metric] >= 0 for r in rows)
                 and sum(r[metric] for r in rows) == summary[metric], '失効玉/要求/fillを別々に保持.' + key + '.' + metric)
        for row in [summary, *rows]:
            need(set(row['注文別']) == {'Source', '保護', '起動前失効'}, 'Source/利益保護/起動前失効の別群')
            need(sum(g['返済片純額'] for g in row['注文別'].values()) == row['net_yen'], '三群の実現純額合算')
    return expected



CLASSIFIER_PATH = ROOT / 'work/113金融コードの正式化準備/分類する.py'
CLASSIFIER_SHA = '41b691a9ed72e427ae054015c67ea30075d55606e6237a4efb2dfa9f24bdf081'
need(sha(CLASSIFIER_PATH) == CLASSIFIER_SHA, '停止113コード分類器のSHA')
CLASSIFIER_SPEC = importlib.util.spec_from_file_location('113正式保存の停止分類共通部', CLASSIFIER_PATH)
K = importlib.util.module_from_spec(CLASSIFIER_SPEC)
CLASSIFIER_SPEC.loader.exec_module(K)
PROCEDURE = """# 113の再現資料

新しい113コードと実使用実行物をZIPへ保存し、同体のSource111・chart111・旧戦略はコード所在索引の既正式ZIP/metadata Refへ結んだ。既正式ZIPは全SHAと参照entryのSHA/bytes/CRCを認証し、複製していない。復元は各entryの現在のrestore先へ行う。旧同bytes別パス参照でも過去のパスへ置き換えない。GoRootは全選択SHAの索引のみとし、同体のGo1.24.2標準環境を別途用意する。

金融固定・成功・独立保存成功とNative台帳を参照する。全70のうち元54は同条件で認証したNativeの再用、追加16だけが再生である。共用原板・価格CSV本文は保存せず、共用台帳のSHAで結ぶ。旧112のS0/W100/P100各4条件、Source111、原文166 Eventの比較範囲と、当時保存全文の同体ではない限界を区別する。

起動前失効の実ラッチ玉数・要求数・実fill数は別の3指標であり、Source/利益保護/起動前失効の注文群を保持した。全玉の利益保護Activeと早期失効ラッチは別状態である。独立会計/Pは保存台帳の再読であり、Raw別走や金融再生を行わない。部分返済後の実R/nと既予約は独立検算を参照する。

CSVを接続した場合も二点の唯一正本はoutputsであり、CSV所在と確認.jsonのRoot全セル再読成功と現SHAに結ぶ。ここで第三のCSV算術再読を行わない。Root完了記録やViewer追加確認は後段の別記録となる。研究目標達成と採用はfalse。
"""


def verify_csv(values: dict, request: dict, before: dict) -> dict:
    """機能: 任意のCSV二点をRoot再読成功と現SHAへ結び、本文複写を避ける。

    引数: values/request/before(dict)はmetadata・固定要求・入力指紋。
    返り値: dictはCSVの外部所在。未接続時は空dict。
    """
    need(('csv_check' in values) == bool(request.get('csv_refs')), 'CSV二点とRoot再読成功は一緒に接続')
    if 'csv_check' not in values:
        return {}
    check = values['csv_check']
    need(check.get('成功') is True and check.get('試行') == 113 and check['場別行数'] == 1680
         and check['候補数'] == 24 and check['全場累計再計算'] is True and check['未定義比率は空欄'] is True
         and check['数値比較数'] > 0 and check['前後不変'] is True and check['入力SHA256'] == check['後SHA256']
         and check['Raw読取'] == 0 and check['金融再実行'] is False, 'Rootの113 CSV再読成功')
    result_ref = request['refs']['result']
    need(check['入力SHA256'].get(str(Path(result_ref['path']).resolve())) == result_ref['sha256'], 'CSVと独立結果の結合')
    need(set(request['csv_refs']) == {'候補別集計.csv', '全セッション.csv'}, 'CSVはRoot二点だけ')
    for name, value in request['csv_refs'].items():
        path = bind(value, before)
        need(path.is_relative_to(OUTPUTS.resolve()) and path.name == name
             and check['入力SHA256'].get(str(path)) == value['sha256'], 'outputs正本とRoot成功SHA')
    return deepcopy(request['csv_refs'])


def authenticate_location(row: dict, prior: dict, before: dict, archives: dict) -> None:
    """機能: 既正式所在を索引・現物ZIP全SHA・選択entryのSHA/CRCへ照合する。

    引数: row/prior/before/archives(dict)はコード行・旧索引・指紋・重複認証台帳。
    返り値: None。旧ZIP全体を新成果物へ複写しない。
    """
    location = row['location']
    index_ref = location['index']
    index = prior.get((str(Path(index_ref['path']).resolve()), index_ref['sha256']))
    need(index is not None, '素材で認証した既正式索引だけ')
    witnesses = []
    for (origin_path, origin_sha), origin_index in prior.items():
        origin_ref = {'path': origin_path, 'sha256': origin_sha}
        for previous in origin_index['entries']:
            if previous['original_path'] == location['prior_original_path'] and previous['sha256'] == row['sha256'] and previous['bytes'] == row['bytes']:
                if K.old_location(previous, origin_index, origin_ref) == location:
                    witnesses.append(previous)
    need(bool(witnesses), '旧索引の由来path/SHA/sizeと直接所在の機械的flatten同体')
    if location['kind'] == '既正式metadata参照':
        path = bind(location['ref'], before)
        need(path.stat().st_size == row['bytes'], '既正式metadataの全bytes')
        return
    archive_ref, entry = location['archive'], location['entry']
    need(Z.safe(entry), '既正式entryの安全名')
    identity = (str(Path(archive_ref['path']).resolve()), archive_ref['sha256'])
    if identity not in archives:
        path = bind(archive_ref, before)
        archives[identity] = {'path': path, 'entries': {}}
    cached = archives[identity]['entries']
    if entry not in cached:
        with zipfile.ZipFile(archives[identity]['path']) as archive:
            need(len(archive.namelist()) == len(set(archive.namelist())), '既正式ZIP内の重複名なし')
            info = archive.getinfo(entry)
            body = archive.read(entry)
            cached[entry] = {'sha256': hashlib.sha256(body).hexdigest(), 'bytes': len(body), 'CRC': info.CRC}
    need(cached[entry]['sha256'] == row['sha256'] and cached[entry]['bytes'] == row['bytes'], '既正式entry全bytes/CRC成功')


def code_rows(condition: dict, values: dict, request: dict, before: dict, copied: dict) -> tuple[list, list]:
    """機能: 停止113金融素材を保ち追加コードだけを統合して新規ZIPへ分離する。

    引数: condition/values/request/before/copied(dict)は条件・metadata・要求・指紋・正式コピー先。
    返り値: tuple[list,list]は全所在と新規ZIP行。GoRootと既正式コードは参照だけ。
    """
    material, refs = values['code_material'], request['refs']
    need(material['試行'] == 113 and material['成功'] is True and material['正式保存ではなく準備'] is True
         and material['前後不変'] is True and material['前SHA256'] == material['後SHA256'], '113金融素材成功と指紋同体')
    need(material['Root金融条件'] == refs['condition'] and material['停止'] == refs['core_stop']
         and material['実行物'] == condition['executable'], '素材の金融固定/Core/exeへの結合')
    expected = dict(condition['code_sha256'])
    need(condition['executable']['path'] not in expected, '金融exeは閉包へ一度だけ追加')
    expected[condition['executable']['path']] = condition['executable']['sha256']
    rows = deepcopy(material['entries'])
    need(len(rows) == len(expected) and {r['original_path']: r['sha256'] for r in rows} == expected
         and material['前SHA256'] == expected, '113金融閉包と実exeの全集合')
    need(material['go_environment']['version'] == 'go1.24.2' and material['restore_roots']['repository'] == str(ROOT), '環境版と復元repo')
    need(all(Path(p).is_absolute() for p in material['restore_roots'].values()), '復元根は全て絶対位置')
    prior_items = [(read(value, before), value) for value in material['旧正式索引']]
    need(prior_items and all(v.get('成功') is True for v, _ in prior_items), '既正式成功索引')
    prior = {(str(Path(value['path']).resolve()), value['sha256']): data for data, value in prior_items}
    goroot = values['core_stop'].get('GoRootコードSHA256', {})
    need({r['original_path']: r['sha256'] for r in rows if r['kind'] == 'GoRoot環境参照'} == goroot, '標準Goの全選択SHA索引')
    candidates = {str(Path(r['original_path']).resolve()).casefold(): r for r in rows}
    need(len(candidates) == len(rows), '金融素材の同path重複なし')

    def add(value: dict, role: str) -> None:
        """機能: 非金融追加コードを同pathとSHAで統合する。

        引数: value(dict)、role(str)はFileRefと実使用の役割。
        返り値: None。Native/Raw/CSV/巨大途中金融をコードへ混入させない。
        """
        path = Path(value['path']).resolve()
        need(path.is_absolute() and path.suffix.lower() not in ('.csv', '.gz', '.jsonl', '.zip')
             and '.Native.' not in path.name, '追加コードの種類と絶対path')
        ident = str(path).casefold()
        if ident in candidates:
            need(candidates[ident]['sha256'] == value['sha256'], '同pathコードSHA衝突なし')
            candidates[ident].setdefault('roles', []).append(role)
            return
        bind(value, before)
        row = K.classify({str(path): value['sha256']}, {}, prior_items)[0]
        row['restore'] = K.restore_target(str(path), material['restore_roots'])
        if row['location']['kind'] == '新規ZIP予定':
            row['location']['entry'] = '復元/' + row['restore']['root'] + '/' + row['restore']['relative']
        row['roles'] = [role]
        candidates[ident] = row
        rows.append(row)

    for name, stopped in values.items():
        if name.endswith('_stop'):
            for field in ('所有コードSHA256', '所有ファイルSHA256'):
                for path, digest in stopped.get(field, {}).items():
                    add({'path': path, 'sha256': digest}, name + 'の所有ファイル')
            for path, digest in stopped.get('再用ファイルSHA256', {}).items():
                if Path(path).suffix in ('.py', '.go', '.mjs', '.ps1'):
                    add({'path': path, 'sha256': digest}, name + 'の再用コード')
    for name in ('actual_declaration', 'pure_declaration', 'chart_declaration'):
        add(condition[name], name)
    for item in request.get('code_refs', []):
        need(set(item) == {'ref', 'role'} and type(item['role']) is str and item['role'], '明示追加コードの型')
        add(item['ref'], item['role'])
    for path, digest in ((PREVIOUS_PATH, PREVIOUS_SHA), (CLASSIFIER_PATH, CLASSIFIER_SHA),
                         (C.LEGACY_PATH, C.LEGACY_SHA), (C.ZIP_PATH, C.ZIP_SHA),
                         (ROOT / 'work/109再現コードの準備/ZIPを正式保存する.py', 'cb263d54b70bbb6ca94d227736fce98748a623d014924b960660039d8f98eae2')):
        add({'path': str(path), 'sha256': digest}, '改変しない共通コード')
    archived, archives, entries = [], {}, set()
    for row in rows:
        path = bind({'path': row['original_path'], 'sha256': row['sha256']}, before)
        need(path.stat().st_size == row['bytes'], 'コードsize不変')
        location = row['location']
        if row['kind'] == 'GoRoot環境参照':
            need(location == {'kind': '環境参照のみ', 'go_version': 'go1.24.2'}, '標準Goは環境参照のみ')
            continue
        need(row['restore'] == K.restore_target(row['original_path'], material['restore_roots']), '現113の復元先同体')
        need(location['kind'] in ('既正式ZIP参照', '既正式metadata参照', '新規ZIP予定'), '金融素材の所在種類')
        if location['kind'] in ('既正式ZIP参照', '既正式metadata参照'):
            authenticate_location(row, prior, before, archives)
            continue
        expected_entry = '復元/' + row['restore']['root'] + '/' + row['restore']['relative']
        need(location['entry'] == expected_entry and Z.safe(expected_entry) and expected_entry.casefold() not in entries, '新規復元entry安全名/一意')
        entries.add(expected_entry.casefold())
        row['material_location'] = location
        if str(path) in copied:
            row['location'] = {'kind': '正式同bytes成果物', 'relative': copied[str(path)]}
        else:
            row['location'] = {'kind': 'このZIP', 'entry': expected_entry}
            archived.append(row)
    return rows, archived



def prepare(request_ref: dict) -> dict:
    """機能: Root全成功Refと全保存先を、正式先作成前に一度で認証する。

    引数: request_ref(dict)はRootの113全70正式保存固定。
    返り値: dictは同bytesコピー・新コードZIP・CSV外部所在の全計画。
    """
    before = {}
    request = read(request_ref, before)
    need(request['version'] == 1 and request['trial'] == 113 and request['fixed'] is True and request['stage'] == 'full70'
         and request['market_native_read_authorized'] is True, 'Rootの113正式保存解禁')
    need(REQUIRED <= set(request['refs']), '113正式保存の必須参照')
    values = {}
    for name, value in request['refs'].items():
        need(re.fullmatch('[A-Za-z0-9_]+', name), '安全なRef名')
        if name.endswith('_code'):
            bind(value, before)
        else:
            values[name] = read(value, before)
    expected = validate(values, request)
    prior54 = read(values['market']['prior54'], before)
    need(prior54['trial'] == 113 and prior54['success'] is True and prior54['stage'] == 'base54'
         and prior54['sessions'] == 54 and prior54['books'] == 1296
         and prior54['condition_sha256'] == request['refs']['condition']['sha256']
         and prior54['unchanged'] is True and prior54['before'] == prior54['after'], '同条件の元54成功を認証')
    need(prior54['results'] == values['market']['results'][:54], '全70先頭54の成功参照を同体で再用')
    material_stop = values['code_material_stop']
    need(material_stop['試行'] == 113 and material_stop['成功'] is True and material_stop['前後不変'] is True,
         '113金融コード分類器の停止成功')
    formal = values['formal_stop']
    need(set(formal['所有ファイルSHA256']) == {str(OWN / n) for n in ('正式保存する.py', '人工検査.py', '検査して停止する.py', 'README.md')}, 'この113正式保存器だけ')
    for path, digest in formal['所有ファイルSHA256'].items():
        bind({'path': path, 'sha256': digest}, before)
    plans, targets, copied = [], set(), {}

    def add(value: dict, relative: str) -> None:
        """機能: 同じ元pathを二重複製せず安全な試行内の新規先へ予約する。

        引数: value(dict)、relative(str)はFileRefと試行内相対先。
        返り値: None。RootのCSV正本を複製しない。
        """
        source = bind(value, before)
        need(source.suffix != '.csv', 'CSV本文はoutputs唯一正本')
        need(Z.safe(relative), '安全な新規正式相対位置')
        target = (TRIAL / relative).resolve()
        need(target.is_relative_to(TRIAL.resolve()) and not target.exists() and str(target).casefold() not in targets, '試行内の新規先だけ')
        need(str(source) not in copied, '元pathの正式二重複写なし')
        targets.add(str(target).casefold())
        copied[str(source)] = relative
        plans.append({'source': str(source), 'target': str(target), 'relative': relative, 'sha256': value['sha256']})

    result, saved, market = (values[k] for k in ('result', 'saved_check', 'market'))
    saved_dir = Path(request['refs']['result']['path']).parent.resolve()
    need(Path(request['refs']['saved_check']['path']).parent.resolve() == saved_dir, '独立正本と検算の同じfolder')
    files = {'結果.json', '一覧.resources.json'} | {f'113_{key}_{sid}.trades.jsonl' for sid in expected for key in KEYS}
    need(set(saved['出力SHA256']) == files, '113全1682出力集合')
    for name in sorted(files):
        add({'path': str(saved_dir / name), 'sha256': saved['出力SHA256'][name]}, '成果物/' + name)
    add(request['refs']['saved_check'], '成果物/保存会計の確認.json')
    catalog = read({'path': str(saved_dir / '一覧.resources.json'), 'sha256': saved['出力SHA256']['一覧.resources.json']}, before)
    need(catalog['schema_version'] == 1 and catalog['path_base'] == 'catalog' and len(catalog['resources']) == 1680, '113 Viewer全1680')
    need({r['id'] for r in catalog['resources']} == {f'113_{key}_{sid}' for sid in expected for key in KEYS}
         and {r['pnl_path'] for r in catalog['resources']} == files - {'結果.json', '一覧.resources.json'}, '113 Viewer ID/約定集合')
    native = []
    need([r['session'] for r in result['Native参照']] == expected, '113独立Native全70順序')
    for row, completed in zip(result['Native参照'], market['results']):
        source = {'path': row['path'], 'sha256': row['sha256']}
        need(source == completed['native'] and row['reference112'] == completed['reference112'], '113金融/独立/正式112の参照同体')
        path, sid = Path(source['path']), row['session']
        need(path.name == sid + '.Native.json.gz', '113 Nativeの本名')
        relative = '成果物_金融/Native/' + path.name
        add(source, relative)
        bind(row['reference112'], before)
        native.append({'session': sid, 'relative': relative, 'history_class': '元54の同条件認証再用' if len(native) < 54 else '追加16の再生',
                       'sha256': source['sha256'], 'bytes': path.stat().st_size,
                       'origin': source, 'reference112': row['reference112'], '同bytes': True})
    for name, value in request['refs'].items():
        if name not in ('result', 'saved_check'):
            add(value, '検査/' + name + (Path(value['path']).suffix if name.endswith('_code') else '.json'))
    if 'prior54' in market:
        add(market['prior54'], '検査/元54成功.json')
    for item in request.get('extra_refs', []):
        need(set(item) == {'ref', 'target', 'role'} and item['target'].split('/')[0] in ('診断', '検査', '再現資料'), '明示後段extra')
        need((Path(item['ref']['path']).suffix in ('.json', '.md', '.py', '.mjs', '.ps1')
              or Path(item['ref']['path']).name.endswith('.json.gz')) and '.Native.' not in Path(item['ref']['path']).name,
             '後段は明示根拠/圧縮診断/文書。Native重複やCSV本体を複写しない')
        add(item['ref'], item['target'])
    add(request_ref, '検査/正式保存の要求.json')
    csv_external = verify_csv(values, request, before)
    index, archived = code_rows(values['condition'], values, request, before, copied)
    generated = ['成果物_金融/Native参照台帳.json', '再現資料/コードと実使用実行物.zip', '再現資料/コード所在索引.json',
                 '再現資料/入力と既正式コードの参照.json', '再現資料/CSV所在と確認.json', '再現資料/再現手順.md', '検査/正式保存の確認.json']
    need(all(not (TRIAL / p).exists() and str((TRIAL / p).resolve()).casefold() not in targets for p in generated), '生成先の全新規性')
    return {'request': request, 'before': before, 'plans': plans, 'native': native, 'index': index, 'archived': archived, 'csv': csv_external, 'roots': values['code_material']['restore_roots'],
            'environment': values['code_material']['go_environment'], 'prior_indexes': values['code_material']['旧正式索引']}


def execute(request_ref: dict) -> dict:
    """機能: 113の全計画を同bytes保存し、新規コードZIPだけを作成・全検査する。

    引数: request_ref(dict)はRoot固定要求。
    返り値: dictは正式確認・ZIP・索引Ref。CSV正本や旧112本文を増やさない。
    """
    plan = prepare(request_ref)
    copied = []
    for row in plan['plans']:
        source, target = Path(row['source']), Path(row['target'])
        need(sha(source) == row['sha256'] and not target.exists(), 'コピー直前の不変/未使用')
        target.parent.mkdir(parents=True, exist_ok=True)
        with source.open('rb') as src, target.open('xb') as dst:
            shutil.copyfileobj(src, dst)
        need(sha(source) == sha(target) == row['sha256'], '正式コピーの同bytes')
        copied.append({'relative': row['relative'], 'origin': {'path': row['source'], 'sha256': row['sha256']},
                       'sha256': row['sha256'], 'bytes': target.stat().st_size, '同bytes': True})
    native_path = TRIAL / '成果物_金融/Native参照台帳.json'
    write_json(native_path, {'試行': 113, '成功': True, '場数': 70, '会計数': 1680, 'Native': plan['native'], '旧112複写': False, '元54認証再用': 54, '追加16再生': 16})
    destination = TRIAL / '再現資料'
    destination.mkdir(parents=True, exist_ok=True)
    archive_path = destination / 'コードと実使用実行物.zip'
    Z.write_zip(archive_path, plan['archived'])
    checks = Z.verify_zip(archive_path, plan['archived'])
    for row in plan['index']:
        if row['location']['kind'] == 'このZIP':
            row['location'].update(checks[row['location']['entry']])
    index_path = destination / 'コード所在索引.json'
    legacy_count = sum(r['location']['kind'] in ('既正式ZIP参照', '既正式metadata参照') for r in plan['index'])
    index = {'試行': 113, '成功': True, 'Root要求': request_ref, 'ZIP': ref(archive_path), 'entries': plan['index'],
             'restore_roots': plan['roots'], 'go_environment': plan['environment'],
             '同梱数': len(plan['archived']), '既正式参照数': legacy_count,
             'GoRoot索引数': sum(r['kind'] == 'GoRoot環境参照' for r in plan['index']), '旧正式ZIP複写': False,
             '全entrySHA/CRC/安全名/集合': True, '研究目標達成': False, '採用': False}
    write_json(index_path, index)
    external_path = destination / '入力と既正式コードの参照.json'
    condition = read(plan['request']['refs']['condition'], {})
    write_json(external_path, {'試行': 113, '成功': True, '金融コード素材': plan['request']['refs']['code_material'],
                               '旧正式索引': plan['prior_indexes'], '旧ZIP参照の全SHAと選択entry認証': True,
                               '共用入力台帳': condition['manifest'], '原文oracle54': condition['original166_references'], '正式112金融基準': condition['reference112'],
                               '原板/価格CSV本文複写': False, '旧正式本文/ZIP全複写': False})
    csv_path = destination / 'CSV所在と確認.json'
    write_json(csv_path, {'試行': 113, '成功': True, 'CSV': plan['csv'], 'Root独立再読成功': plan['request']['refs'].get('csv_check'),
                         '現在SHA照合': True, 'CSV本文の正式側複写': False, '接続済み': bool(plan['csv']), '唯一正本': 'outputs'})
    procedure = destination / '再現手順.md'
    with procedure.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(PROCEDURE)
    need(all(sha(Path(r['source'])) == sha(Path(r['target'])) == r['sha256'] for r in plan['plans']), '全コピー最終同bytes')
    after = {path: sha(Path(path)) for path in plan['before']}
    need(after == plan['before'], '全入力code/既正式資料/CSVの前後不変')
    proof_path = TRIAL / '検査/正式保存の確認.json'
    write_json(proof_path, {'試行': 113, '成功': True, 'Root要求': request_ref, '同bytes成果物': copied,
                           'Native台帳': ref(native_path), 'Native数': 70, '会計数': 1680, 'Viewer資源': 1680,
                           'ZIP': ref(archive_path), 'コード所在索引': ref(index_path), 'CSV所在': ref(csv_path), '入力参照': ref(external_path),
                           '同梱entry数': len(plan['archived']), '既正式参照数': legacy_count, '全entrySHA/CRC/安全名/集合': True,
                           '入力SHA256前': plan['before'], '入力SHA256後': after, '前後不変': True,
                           '旧112/Raw/価格CSV本文/CSV二点の複写': False, '元54認証再用': 54, '追加16再生': 16,
                           '失効3指標と別注文群保持': True, '金融再実行': False, '11月09日本文読取': False,
                           '研究目標達成': False, '採用': False})
    return {'成功': True, '確認': ref(proof_path), 'ZIP': ref(archive_path), '索引': ref(index_path),
            'Native台帳': ref(native_path), 'CSV所在': ref(csv_path), '新同梱数': len(plan['archived']), '既正式参照数': legacy_count}


def main() -> None:
    """機能: 全70成功後のRoot要求と期待SHAだけから正式保存する。

    引数: CLI request/request-sha(str)はRoot要求絶対位置と指紋。
    返り値: None。小さな正式Refだけを表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--request-sha', required=True)
    args = parser.parse_args()
    print(json.dumps(execute({'path': str(args.request.resolve()), 'sha256': args.request_sha}), ensure_ascii=False))


if __name__ == '__main__':
    main()
