# 113の正式保存への接続

全70金融成功と独立1680会計成功のRoot固定要求から、Native70・結果・保存検算・Viewer1680資源と1680約定ファイルを同bytesで保存する。元54の同条件成功を認証した再用と追加16再生を区別する。起動前失効のラッチ玉・要求・fillの3指標とSource/利益保護/起動前失効の注文群を保持する。

金融条件・停止コード・金融結果は変更しない。Rawや価格CSVを開かず、113 Nativeも復号せず圧縮bytesだけ認証する。正式保存はRootが新要求のSHAを固定して実行する。研究目標達成・採用はfalse。

## 固定要求

JSONは `version:1, trial:113, fixed:true, stage:"full70", market_native_read_authorized:true` とする。`refs` の必須FileRefは以下。FileRefは絶対 `path` と `sha256`。

- `condition, market, result, saved_check`：Root金融条件、全70成功、独立結果、独立保存検算。
- `core_stop, actor_stop, pure_stop, save_stop, P_stop`：それぞれ実使用停止。
- `formal_stop`：このフォルダの市場前停止。
- `code_material, code_material_stop`：停止済み113金融コード分類素材と分類器停止。

`code_material` は113金融閉包1137＋実使用exeの1138件を環境参照・旧正式参照・新規同梱へ分けた素材である。各金融入力の全集合とSHAを条件へ照合し、追加コードは停止所有・再用コード・各宣言・共通ZIP器・明示`code_refs`から同pathで統合する。`code_refs` は `[{ref:FileRef,role:文字列}]`。実使用Root比較・CSV・検査helper等を明示する。

任意の `csv_refs` は `{"候補別集計.csv":FileRef,"全セッション.csv":FileRef}`。同時に `refs.csv_check` にRoot全件再読成功を渡す。結果・CSVの現在SHAをその成功台帳へ結ぶ。CSV本文の第三算術再読や複製はしない。未接続時の所在は空と明記する。

`extra_refs` は `[{ref:FileRef,target:"診断/明示名.json",role:文字列}]`。Root同入口比較・CSV生成確認・先頭2成功metadata・中断/移行記録等を接続できる。先頭2Native/Viewer全件は重複保存しない。圧縮診断は.json.gzも受理する。CSV/Rawや旧ZIPの丸ごと複写をextraで迂回できない。

## 正式先とコード容量

正式先は `study/00113_起動前の支持否定と利益保護の切替`。`成果物/`、`成果物_金融/Native/`、ルート`再現資料/`と小`検査/`へ新規保存する。既存の`根拠/112保有区間OHLC`・README・設定表・旧試行へ書かない。全対象先の未作成を事前に確認し、再実行で上書きしない。

GoRoot716はGo1.24.2と全選択SHAの索引のみ。旧111/112参照は直接のZIP/索引/entryまたはmetadataRefへflattenし、現復元先を保持する。正式保存時は旧ZIP全SHAと選択entryのSHA/size/CRCを認証する。旧ZIPそのものは複製しない。新ZIPは必要な新コード・宣言・実exeに限り、同bytes正式metadataは同じ成果物への参照にする。新ZIPは全entry集合・安全名・SHA・size・CRCを再読検査する。

## 実行

```powershell
python -X utf8 work/113正式保存への接続/正式保存する.py --request <Root新要求の絶対path> --request-sha <SHA256>
```

市場前停止の生成は `検査して停止する.py --output <新規検査先>`。人工は停止111の手製70場・空約定1680を113schemaへ適応し、架空のNative/旧ZIP/CSV成功metadataだけを使う。市場結果への代用ではない。保存器は独立金融の再演算を増やさず、既成功の意味・指紋・同bytesコピー・所在を検査する。
