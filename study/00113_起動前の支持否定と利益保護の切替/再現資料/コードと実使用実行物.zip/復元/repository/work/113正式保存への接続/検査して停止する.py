"""113正式保存器を非市場人工と所有不変の証拠で停止する。"""

import argparse
from pathlib import Path
import subprocess
import sys
import json

import 正式保存する as F


def stop(output: Path) -> dict:
    """機能: 新正式保存器の人工と旧停止の前後不変を固定する。

    引数: output(Path)は新規証拠先。
    返り値: dictは停止Ref。実市場・Raw・CSVを読まない。
    """
    F.need(not output.exists(), '113正式停止の新規先')
    owned = {str(F.OWN / n): F.sha(F.OWN / n) for n in ('正式保存する.py', '人工検査.py', '検査して停止する.py', 'README.md')}
    reused = {str(F.PREVIOUS_PATH): F.PREVIOUS_SHA, str(F.CLASSIFIER_PATH): F.CLASSIFIER_SHA,
              str(F.C.LEGACY_PATH): F.C.LEGACY_SHA, str(F.C.ZIP_PATH): F.C.ZIP_SHA,
              str(F.ROOT / 'work/109再現コードの準備/ZIPを正式保存する.py'): 'cb263d54b70bbb6ca94d227736fce98748a623d014924b960660039d8f98eae2',
              str(F.ROOT / 'work/111正式保存への接続/人工検査.py'): 'ff8f68906fa8cabdc97a371095025bb7c2da95bc8fcc08365ba8def87bbcd78b',
              str(F.ROOT / 'work/112正式保存への接続/正式保存する.py'): 'd4dc9c79342709d596c876b8e2d9bd2516a6d86f9865022cd4a528f93c33340c'}
    protected = {
        'work/113起動前の構造失効を執行する会計/Actor停止.json': '9f261c911946082c20b0bfc259a991cb045a533456187ec611732ec72a34133b',
        'work/113起動前の構造失効を執行する会計/P停止.json': '25432cfb24561cd6beab9dbecffa64f20aad5afd8cf28beeeb01db725034f77b',
        'work/113起動前の構造失効を執行する会計/会計停止.json': '226985c20b65481e86db9ea92b5264fe608db987bfc0e8d368968451907ff065',
        'work/113金融コードの正式化準備/停止.json': '46c6090d03f2f01a5f36b2628812c203c9fcc51d52c307b57551297cc5c96ff5'}
    for relative, digest in protected.items():
        path = F.ROOT / relative
        F.need(F.sha(path) == digest, '既停止の現物不変')
        reused[str(path)] = digest
        data = F.read({'path': str(path), 'sha256': digest}, {})
        for field in ('所有コードSHA256', '所有ファイルSHA256'):
            reused.update(data.get(field, {}))
    F.need(all(F.sha(Path(p)) == h for p, h in reused.items()), '再用/旧所有の停止SHA')
    output.mkdir()
    test = subprocess.run([sys.executable, '-X', 'utf8', str(F.OWN / '人工検査.py')], cwd=F.OWN,
                          capture_output=True, text=True, encoding='utf-8', timeout=90)
    log = output / '人工検査.txt'
    log.write_text(test.stdout + test.stderr, encoding='utf-8', newline='\n')
    F.need(test.returncode == 0, '113正式保存人工の全成功')
    F.need(all(F.sha(Path(p)) == h for p, h in {**owned, **reused}.items()), '新所有/旧停止コード前後不変')
    proof = output / '人工確認.json'
    F.write_json(proof, {'試行': 113, '成功': True, '市場前': True, '主人工': 6,
                        '器具': '停止111の手製70場/空約定1680を113へ適応。仮Native/旧ZIP/CSV成功metadataだけ。',
                        '全Native70/Viewer1680': True, '旧ZIP全SHAと選択entrySHA/CRC': True, '新ZIP集合SHA/CRC/安全名': True,
                        '元54認証再用と追加16区別': True, '三失効指標と三注文群': True,
                        '旧成果物/GoRoot/CSVの本文複写なし': True, '前後不変': True, 'ログ': F.ref(log),
                        '実市場/Raw/価格CSV/実CSV/11月09日本文': False})
    record = {'試行': 113, '成功': True, '市場前': True, '所有ファイルSHA256': owned, '再用ファイルSHA256': reused,
              '人工確認': F.ref(proof), '前後不変': True, '実市場/Raw/価格CSV/実CSV/11月09日本文': False,
              '研究目標達成': False, '採用': False}
    path = output / '停止.json'
    F.write_json(path, record)
    return {'成功': True, '停止': F.ref(path)}


def main() -> None:
    """機能: 未作成先へ113正式保存の市場前停止を生成する。

    引数: CLI output(str)は新規先。
    返り値: None。停止Refのみ表示する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(stop(args.output.resolve()), ensure_ascii=False))


if __name__ == '__main__':
    main()
