# 金融版113の純保護

固定した高速112の深いコピーを継承する。市場・Raw・Native・11/09本文の追加読取と市場実行はない。Source/Chart/Actorは変更しない。

| 政策 | H（初期q0相当の費用後pt） | 通常幅 | 起動後狭幅 | 起動前離脱 |
|---|---:|---|---|---|
| S0 | 対象外 | 対象外 | なし | なし |
| W100 | 100 | ceil5(max(200,2×取得時ATR)) | なし | なし |
| P100 | 100 | 同上 | M AND P | なし |
| P50 | 50 | 同上 | M AND P | なし |
| E100 | 100 | 同上 | M AND P | 固定取得支持の逆抜け AND 生M |
| E50 | 50 | 同上 | M AND P | 同上 |

全政策×C0/C5×D0/D1の24宣言。ATR未知は200固定。H以外の通常幅・費用床・全玉L/F・部分返済R/n/q0・丸め・非緩和・起動後の構造床は112を継承する。S0はActor側で扱い純状態を作らない。

EだけEntry.EntrySupportへ取得行で既知の同場・当該売買側のPriorPivotを渡す。出典・確認・公表時刻を検査し、未来や異なるscope/側は拒否。価格位置だけ不適格な支持は原値を保持してEntrySupportEligible=falseとする。nil/不適格でも通常の利益保護は継続する。

現在公表のEndが取得Atより厳密に後、AvailableAtが現在以下、Closeが固定支持を厳密逆抜けしMが真なら、未Activeの場合にEntryInvalidatedを不可逆ラッチする。動的Pとは別のEntrySupportBreak三値に記録する。現在の損益が正というgateはない。nilMarkでも公表だけでラッチできる。

同一AdvanceではH判定を先に更新し、Activeなら新しい失効は発火しない。既ラッチは回復・reset・予約取消・後のActive化でも撤回しない。PreFillではラッチだけ、AfterSourceでEntryExitQuantity=n−rを要求する。既存EligibleExitQuantityとは別fieldであり、Actorが同じfree量を合算して二重返済しない。fillはActorの次正常後原行であり、純部品では価格を作らない。

最初のWitnessはAt/Sequence/Phase、固定Support、当時のPublication全値、符号付き支持差と生C/M/P/Bを保存し、不変とする。Entry/Latest/Witness/BB全入れ子を独立に深くコピーする。参照を露出するSnapshotWithoutCopyは追加しない。

共通W100/P100の72系列・696判断・768状態を112と照合。分離するのは検査済みDefinition.versionとfalseの新設定だけで、旧金融fieldは除外しない。S0を含む三対照の全Definitionも照合する。H50、売買鏡像、動的Pと固定支持の相違、三値/等号、nilMark、H優先、回復後ラッチ、部分返済/全予約/半円、出典拒否、Witness/BB別名、当場BB窓を人工で確認する。

再現は `go test ./...`、`go vet ./...`、`go build ./...`。実API・24宣言・AST限定差・前後指紋は検査と停止を記録する.pyが新しい検査フォルダへ保存する。新しい金融試行の成績は未実行。
