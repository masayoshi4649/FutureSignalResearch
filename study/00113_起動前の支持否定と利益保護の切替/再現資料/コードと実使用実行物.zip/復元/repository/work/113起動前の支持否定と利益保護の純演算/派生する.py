"""停止した高速112純部品を新金融113の所有領域へ派生する。"""
from pathlib import Path
import hashlib
import json

ここ = Path(__file__).resolve().parent
元 = ここ.parent / "112純状態コピー高速化の試作"


def 実行する() -> None:
    """
    機能: 認証済み高速純コードを別moduleへ写し、旧codeを保持する。
    引数: なし。返り値: None。市場/Raw/Nativeを参照しない。
    """
    結果 = 元 / "結果.json"
    assert hashlib.sha256(結果.read_bytes()).hexdigest() == "dd75dd865ff0d3f3ca5cc5d213f5720a7e90651d199f2e58a37c27df24f7ccaa"
    r = json.loads(結果.read_text(encoding="utf-8"))
    for k, v in r["所有SHA256"].items():
        assert hashlib.sha256(Path(k).read_bytes()).hexdigest() == v, k
    for name in ["types.go", "state.go", "bb.go", "fastcopy.go"]:
        text = (元 / name).read_text(encoding="utf-8")
        text = text.replace("package profitfloor112fast", "package profitfloor113", 1)
        text = text.replace("// Package profitfloor112fast ", "// Package profitfloor113 ", 1)
        with (ここ / name).open("x", encoding="utf-8", newline="\n") as f:
            f.write(text)
    (ここ / "go.mod").write_text('''module github.com/masayoshi4649/SessionTradeExecuter/profitfloor113

go 1.24.2

require (
 github.com/masayoshi4649/SessionTradeExecuter/profitfloor111 v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/profitfloor112fast v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/profitfloor112 v0.0.0
)

replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor111 => ../111全玉利益と収束BBの純保護
replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor112fast => ../112純状態コピー高速化の試作
replace github.com/masayoshi4649/SessionTradeExecuter/profitfloor112 => ../112支持否定の必須確認と通常幅のみ
''', encoding="utf-8")
    (ここ / "派生の参照.json").write_text(json.dumps({"金融版": 113, "元高速112結果": {"path": str(結果), "sha256": hashlib.sha256(結果.read_bytes()).hexdigest()},
        "元所有SHA256": r["所有SHA256"], "金融変更": "H50と起動前の取得時支持否定のみ。通常幅/起動後保護/深copyを保持。", "市場RawNative読取": 0}, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")


if __name__ == "__main__":
    実行する()
