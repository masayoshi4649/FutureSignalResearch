"""純113の人工・実API・限定AST差と旧停止不変を市場前に固定する。"""
from pathlib import Path
from datetime import datetime, timezone
import ast
import hashlib
import json
import os
import subprocess

ここ = Path(__file__).resolve().parent
根 = ここ.parents[1]


def 指紋(p: Path) -> str:
    """
    機能: 明示コードと小metadataの指紋を計算する。
    引数: p(Path)。返り値: strはSHA256。市場本文は対象外。
    """
    return hashlib.sha256(p.read_bytes()).hexdigest()


def ref(p: Path) -> dict:
    """
    機能: 絶対位置の小metadata参照を返す。
    引数: p(Path)。返り値: dictはpathとsha256。
    """
    return {"path": str(p.resolve()), "sha256": 指紋(p)}


def run(argv: list[str], env: dict) -> dict:
    """
    機能: 純Goの人工・宣言・構文比較・ビルドだけを実行する。
    引数: argv(list[str])、env(dict)。返り値: dictは成功ログ。不成功は例外。
    """
    p = subprocess.run(argv, cwd=ここ, env=env, capture_output=True, text=True, encoding="utf-8", timeout=60)
    record = {"command": argv, "exit_code": p.returncode, "stdout": p.stdout, "stderr": p.stderr}
    if p.returncode:
        raise ValueError(json.dumps(record, ensure_ascii=False))
    return record


def 実行する() -> None:
    """
    機能: 13主人工と実宣言を確認し、旧高速112に触れず新純113を停止する。
    引数: なし。返り値: None。市場・Raw・Nativeを読まない。
    """
    target = ここ / "停止.json"
    directory = ここ / "検査"
    assert not target.exists() and not directory.exists()
    depstop = 根 / "work/113高速コピーの自然対照準備/purefast停止.json"
    assert 指紋(depstop) == "d351ee940d8d21bb3199641c76b89a6d6dde8ff6f5239cdfcdf44824c30d938c"
    dep = json.loads(depstop.read_text(encoding="utf-8"))
    reused = {**dep["所有コードSHA256"], **dep["再用コードSHA256"], str(depstop): 指紋(depstop)}
    for name, sha in reused.items():
        assert 指紋(Path(name)) == sha, name
    names = ["types.go", "state.go", "entry_support.go", "fastcopy.go", "bb.go", "state_test.go", "bb_test.go", "go.mod", "cmd/astcheck/main.go", "README.md", "派生する.py", "派生の参照.json", Path(__file__).name]
    owned = {str((ここ / n).resolve()): 指紋(ここ / n) for n in names}
    for name in names:
        if name.endswith(".py"):
            for node in ast.walk(ast.parse((ここ / name).read_text(encoding="utf-8"))):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    doc = ast.get_docstring(node) or ""
                    assert "\n" in doc and all(k in doc for k in ("機能", "引数", "返り値")), node.name
    directory.mkdir()
    env = dict(os.environ, CGO_ENABLED="0", GOWORK="off", PROFIT113_DECLARATION=str(directory / "宣言設定.json"))
    logs = [run(["go", "test", "-count=1", "-json", "-cover", "./..."], env), run(["go", "vet", "./..."], env), run(["go", "build", "./..."], env),
            run(["go", "run", "./cmd/astcheck", "--old", str(根 / "work/112純状態コピー高速化の試作"), "--current", str(ここ), "--out", str(directory / "AST差分.json")], env), run(["go", "doc", "-all", "."], env)]
    passed = [json.loads(s)["Test"] for s in logs[0]["stdout"].splitlines() if s.startswith("{") and json.loads(s).get("Action") == "pass" and "Test" in json.loads(s)]
    assert len(passed) == 13, passed
    actual = json.loads((directory / "宣言設定.json").read_text(encoding="utf-8"))
    assert actual["version"] == 113 and len(actual["configurations"]) == 24 and len(actual["definitions"]) == 6
    assert [x["policy"] for x in actual["definitions"]] == ["S0", "W100", "P100", "P50", "E100", "E50"]
    (directory / "API.txt").write_text(logs[4]["stdout"], encoding="utf-8", newline="\n")
    assert all(指紋(Path(k)) == v for k, v in owned.items())
    assert all(指紋(Path(k)) == v for k, v in reused.items())
    record = {"成功": True, "停止": True, "市場前": True, "trial": 113, "module": "github.com/masayoshi4649/SessionTradeExecuter/profitfloor113", "UTC": datetime.now(timezone.utc).isoformat(),
              "所有コードSHA256": owned, "再用コードSHA256": reused, "全所有と依存の前後不変": True,
              "高速112停止": ref(depstop), "実宣言": ref(directory / "宣言設定.json"), "実API": ref(directory / "API.txt"), "AST差分": ref(directory / "AST差分.json"),
              "主test": len(passed), "成功test": passed, "検査ログ": logs, "Control112": "S0の全定義、W100/P100の72系列696判断768状態。検査済み定義版とfalse新設定だけを分離し旧金融field除外0。",
              "Snapshot参照分離": True, "取得時支持の失効と利益起動を分離": True, "市場RawNative価格CSV11月9日本文読取": 0, "市場実行": False, "SourceChartActor変更": False}
    with target.open("x", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(record, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"成功": True, "停止": ref(target), "実宣言": record["実宣言"], "実API": record["実API"], "主test": len(passed)}, ensure_ascii=False))


if __name__ == "__main__":
    実行する()
