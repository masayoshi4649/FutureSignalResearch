package profitfloor113

import (
	"bytes"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	old "github.com/masayoshi4649/SessionTradeExecuter/profitfloor112fast"
)

// fixtureEntry は基礎対照又は取得時支持付きの実新規人工を作ります。
//
// 引数: p(Policy)、side/q(int)、slip(float64)、atr(*float64)。返り値: Entryは未共有の人工です。
func fixtureEntry(p Policy, side, q int, slip float64, atr *float64) Entry {
	e := Entry{Scope: Scope{Session: "人工場", Contract: "人工限月", Start: 0}, Policy: p, Side: side, Price: 1000, At: 3600, InitialQuantity: q, SlipPoints: slip}
	if atr != nil {
		e.ATR = &Evidence{Value: *atr, AvailableAt: 3600, ID: "取得時ATR"}
	}
	if p == E100 || p == E50 {
		kind := "low"
		if side < 0 {
			kind = "high"
		}
		e.EntrySupport = &Pivot{Scope: e.Scope, ID: "取得時の固定支持", Kind: kind, Price: e.Price - float64(side)*50, CenterStart: 3240, CenterEnd: 3420, ConfirmEnd: 3600, PublishedAt: 3600}
	}
	return e
}

// fixtureInput は同じ玉の現在会計と評価気配を作ります。
//
// 引数: e(Entry)、seq(uint64)、gain(float64)、n/r(int)、closed(float64)。返り値: Inputは人工原行です。
func fixtureInput(e Entry, seq uint64, gain float64, n, r int, closed float64) Input {
	return Input{At: 5000 + float64(seq), Sequence: seq, Phase: AfterSource, Mark: pointer(e.Price + float64(e.Side)*gain), Remaining: n, Reserved: r, ClosedNetYen: closed}
}

// fixturePublication は生Mと動的pivotを持つ取得後3分公表を作ります。
//
// 引数: e(Entry)、ordinal(int)、closeGain(float64)、m(Truth)。返り値: Publicationは固定支持と異なる動的pivotを持ちます。
func fixturePublication(e Entry, ordinal int, closeGain float64, m Truth) Publication {
	start := 3600 + float64(ordinal-21)*180
	kind := "low"
	if e.Side < 0 {
		kind = "high"
	}
	return Publication{Scope: e.Scope, ID: fmt.Sprintf("人工公表%d", ordinal), Ordinal: uint64(ordinal), Start: start, End: start + 180, AvailableAt: start + 180, C: True, M: m, V: pointer(30), Close: pointer(e.Price + float64(e.Side)*closeGain), PriorPivot: &Pivot{Scope: e.Scope, ID: "動的な別支持", Kind: kind, Price: e.Price - float64(e.Side)*100, CenterStart: 3600, CenterEnd: 3780, ConfirmEnd: 3780, PublishedAt: 3780}}
}

// runState はNewStateの正常初期化を検査します。
//
// 引数: t(*testing.T)、e(Entry)。返り値: Stateは新しい純状態です。
func runState(t *testing.T, e Entry) State {
	t.Helper()
	s, err := NewState(e)
	if err != nil {
		t.Fatal(err)
	}
	return s
}

// runAdvance は一原行の成功と以前の公開状態不変を検査します。
//
// 引数: t(*testing.T)、s(State)、in(Input)。返り値: State/Decisionは純結果です。
func runAdvance(t *testing.T, s State, in Input) (State, Decision) {
	t.Helper()
	before, _ := json.Marshal(s.Snapshot())
	next, d, err := Advance(s, in)
	if err != nil {
		t.Fatal(err)
	}
	after, _ := json.Marshal(s.Snapshot())
	if !bytes.Equal(before, after) {
		t.Fatal("以前の状態を変更")
	}
	return next, d
}

// legacyEntry は固定112へ新任意fieldなしの同じ取得値を渡します。
//
// 引数: e(Entry)は対照政策。返り値: old.Entryは政策・数値を変えない値です。
func legacyEntry(e Entry) old.Entry {
	return old.Entry{Scope: e.Scope, Policy: old.Policy(e.Policy), Side: e.Side, Price: e.Price, At: e.At, InitialQuantity: e.InitialQuantity, SlipPoints: e.SlipPoints, ATR: e.ATR}
}

// legacyInput は固定112へ同じ公表・会計・段階を渡します。
//
// 引数: in(Input)。返り値: old.Inputは生値の同じ原行です。
func legacyInput(in Input) old.Input {
	return old.Input{At: in.At, Sequence: in.Sequence, Phase: in.Phase, Mark: in.Mark, Remaining: in.Remaining, Reserved: in.Reserved, ClosedNetYen: in.ClosedNetYen, Publication: in.Publication, ResetReason: in.ResetReason}
}

// compareControl は検査済みの定義版とfalse設定だけを分離し全金融JSONを照合します。
//
// 引数: t(*testing.T)、current/previous(any)、snapshot(bool)。返り値: ありません。
func compareControl(t *testing.T, current, previous any, snapshot bool) {
	t.Helper()
	a, err := json.Marshal(current)
	if err != nil {
		t.Fatal(err)
	}
	b, err := json.Marshal(previous)
	if err != nil {
		t.Fatal(err)
	}
	var x, y map[string]any
	if json.Unmarshal(a, &x) != nil || json.Unmarshal(b, &y) != nil {
		t.Fatal("JSON復元")
	}
	if snapshot {
		d := x["definition"].(map[string]any)
		if d["version"] != float64(113) || d["entry_invalidation_enabled"] != false {
			t.Fatal("対照定義の新値差")
		}
		d["version"] = float64(112)
		delete(d, "entry_invalidation_enabled")
		for _, k := range []string{"entry_support_eligible", "entry_invalidated", "entry_invalidated_at", "entry_invalidation_witness"} {
			if _, ok := x[k]; ok {
				t.Fatal("対照へ新失効状態が混入", k)
			}
		}
		if _, ok := x["entry"].(map[string]any)["entry_support"]; ok {
			t.Fatal("対照へ取得時支持を混入")
		}
	} else {
		for _, k := range []string{"entry_support_break", "entry_invalidated_now", "entry_exit_quantity"} {
			if _, ok := x[k]; ok {
				t.Fatal("対照へ新失効判断を混入", k)
			}
		}
	}
	if !reflect.DeepEqual(x, y) {
		t.Fatalf("金融全JSON差\n%s\n%s", a, b)
	}
}

// controlSequence は元72系列と同じ予約・再公表・reset・部分返済を組み立てます。
//
// 引数: e(Entry)。返り値: []Inputは生C/M/P/BBを保つ人工原行です。
func controlSequence(e Entry) []Input {
	q := e.InitialQuantity
	out := []Input{}
	in := fixtureInput(e, 1, 0, q, 0, 0)
	in.Mark = nil
	out = append(out, in, fixtureInput(e, 2, 100, q, 0, 0))
	pub := fixturePublication(e, 21, 100, False)
	in = fixtureInput(e, 3, 115, q, 0, 0)
	in.Publication = copyValue(&pub)
	out = append(out, in)
	pub = fixturePublication(e, 22, 100, True)
	in = fixtureInput(e, 4, 600, q, 0, 0)
	in.Publication = copyValue(&pub)
	out = append(out, in)
	in = fixtureInput(e, 5, 0, q, q, 0)
	in.Mark = nil
	out = append(out, in)
	in = fixtureInput(e, 6, 0, q, q, 0)
	in.Mark = nil
	in.ResetReason = "欠足"
	out = append(out, in)
	in = fixtureInput(e, 7, 450, q, q, 0)
	in.Publication = copyValue(&pub)
	out = append(out, in)
	pub = fixturePublication(e, 23, -110, True)
	pub.C = Unknown
	pub.BB = &BBResult{Scope: pub.Scope, ID: pub.ID, Ordinal: pub.Ordinal, End: pub.End, AvailableAt: pub.AvailableAt, DeliveredAt: pub.AvailableAt, Known: true, WindowBars: 20, SMA: pointer(1000), Sigma: pointer(20), Upper: pointer(1040), Lower: pointer(960), Width: pointer(80), BandWidth: pointer(.08), PercentB: pointer(.7), Contraction: True, WindowSHA: strings.Repeat("0", 64)}
	in = fixtureInput(e, 8, 450, q, q, 0)
	in.Publication = copyValue(&pub)
	out = append(out, in)
	if q > 1 {
		out = append(out, fixtureInput(e, 9, 20, q-1, q-1, -.5))
	}
	in = fixtureInput(e, 10, 0, 0, 0, -154)
	in.Mark = nil
	out = append(out, in)
	return out
}

// TestDeclarations113 は六政策・Hだけの感度・通常幅・24費用を確認して実宣言を保存します。
//
// 引数: t(*testing.T)。返り値: ありません。市場は使用しません。
func TestDeclarations113(t *testing.T) {
	want := []Policy{S0, W100, P100, P50, E100, E50}
	configs, defs := DeclaredConfigurations(), DeclaredDefinitions()
	if len(configs) != 24 || len(defs) != 6 {
		t.Fatal("宣言数")
	}
	for i, p := range want {
		d := defs[i]
		if d.Policy != p || d.Version != 113 || d.EntryInvalidationEnabled != (p == E100 || p == E50) {
			t.Fatal("定義ID/版/失効")
		}
		if p == S0 || p == W100 || p == P100 {
			previous, err := old.DefinitionFor(old.Policy(p))
			if err != nil {
				t.Fatal(err)
			}
			xraw, _ := json.Marshal(d)
			yraw, _ := json.Marshal(previous)
			var x, y map[string]any
			if json.Unmarshal(xraw, &x) != nil || json.Unmarshal(yraw, &y) != nil {
				t.Fatal("定義JSON")
			}
			if x["entry_invalidation_enabled"] != false {
				t.Fatal("対照の早期失効")
			}
			delete(x, "entry_invalidation_enabled")
			x["version"] = float64(112)
			if !reflect.DeepEqual(x, y) {
				t.Fatal("S0/W100/P100の定義対照差")
			}
		}
		for j, pair := range [][2]float64{{0, 0}, {0, 1}, {5, 0}, {5, 1}} {
			if configs[i*4+j] != (Configuration{p, pair[0], int(pair[1])}) {
				t.Fatal("24順序")
			}
		}
		if p == S0 {
			if d.Enabled {
				t.Fatal("S0追加保護")
			}
			continue
		}
		h := 100.0
		if p == P50 || p == E50 {
			h = 50
		}
		if d.ThresholdPoints != h || d.NormalWidthMinimum != 200 || d.ATRMultiplier != 2 || d.TechnicalNarrowing != (p != W100) {
			t.Fatal("Hと幅を混同")
		}
		for _, a := range []*float64{nil, pointer(125.5)} {
			s := runState(t, fixtureEntry(p, 1, 2, 0, a)).Snapshot()
			width := 200.0
			if a != nil {
				width = 255
			}
			if s.NormalWidth != width || s.ThresholdPoints != h || s.Entry.ATR != nil && s.Entry.ATR.Value != *a {
				t.Fatal("幅又はATRを偽装")
			}
		}
	}
	for _, p := range []Policy{S0, "B100", "W400", "P400", "B50", "未定義"} {
		if _, err := NewState(fixtureEntry(p, 1, 1, 0, nil)); err == nil {
			t.Fatal("未宣言純政策を受理")
		}
	}
	if path := os.Getenv("PROFIT113_DECLARATION"); path != "" {
		value := map[string]any{"version": 113, "module": "profitfloor113", "configurations": configs, "definitions": defs, "publication_type": "profitfloor111の型alias", "entry_invalidation": "固定取得時支持と生M、H更新後かつ未Activeで不可逆。AfterSource free量。", "S0": "Actor側で扱い追加純状態なし"}
		raw, err := json.MarshalIndent(value, "", "  ")
		if err != nil {
			t.Fatal(err)
		}
		if err = os.MkdirAll(filepath.Dir(path), 0700); err != nil {
			t.Fatal(err)
		}
		if err = os.WriteFile(path, append(raw, '\n'), 0600); err != nil {
			t.Fatal(err)
		}
	}
}

// TestControl112WholeState は共通W100/P100の72系列を全金融状態・判断で固定112へ照合します。
//
// 引数: t(*testing.T)。返り値: ありません。分離するのは検査済み定義版とfalse設定だけです。
func TestControl112WholeState(t *testing.T) {
	series, steps := 0, 0
	for _, p := range []Policy{W100, P100} {
		for _, side := range []int{1, -1} {
			for _, slip := range []float64{0, 5} {
				for _, a := range []*float64{nil, pointer(80), pointer(125.5)} {
					for _, q := range []int{1, 2, 10} {
						e := fixtureEntry(p, side, q, slip, a)
						s := runState(t, e)
						b, err := old.NewState(legacyEntry(e))
						if err != nil {
							t.Fatal(err)
						}
						compareControl(t, s.Snapshot(), b.Snapshot(), true)
						for _, in := range controlSequence(e) {
							var d Decision
							s, d = runAdvance(t, s, in)
							var od old.Decision
							b, od, err = old.Advance(b, legacyInput(in))
							if err != nil {
								t.Fatal(err)
							}
							compareControl(t, s.Snapshot(), b.Snapshot(), true)
							compareControl(t, d, od, false)
							steps++
						}
						series++
					}
				}
			}
		}
	}
	if series != 72 || steps != 696 {
		t.Fatal(series, steps)
	}
	t.Logf("112対照72系列/696判断/768状態、生C/M/P/B保持")
}

// TestH50DoesNotChangeWidth はHだけを50へ下げ、通常幅を同時に変えません。
//
// 引数: t(*testing.T)。返り値: ありません。費用を含む両側・二費用の感度です。
func TestH50DoesNotChangeWidth(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, slip := range []float64{0, 5} {
			for _, p := range []Policy{P50, E50} {
				e := fixtureEntry(p, side, 2, slip, nil)
				s := runState(t, e)
				gain := 60.0
				if slip == 5 {
					gain = 65
				}
				s, d := runAdvance(t, s, fixtureInput(e, 1, gain, 2, 0, 0))
				if !d.ActivatedNow || !s.Snapshot().Active || s.Snapshot().NormalWidth != 200 || s.Snapshot().Narrowed {
					t.Fatal("H50/未知ATR幅")
				}
				p100 := P100
				if p == E50 {
					p100 = E100
				}
				c := fixtureEntry(p100, side, 2, slip, nil)
				b, bd := runAdvance(t, runState(t, c), fixtureInput(c, 1, gain, 2, 0, 0))
				if b.Snapshot().Active || bd.ActivatedNow || b.Snapshot().NormalWidth != s.Snapshot().NormalWidth {
					t.Fatal("H感度以外の幅差")
				}
			}
		}
	}
}

// TestFixedSupportDifferentFromDynamicP は固定取得支持と当時の動的Pを混同しません。
//
// 引数: t(*testing.T)。返り値: ありません。赤字の現在価格にも利益gateを足しません。
func TestFixedSupportDifferentFromDynamicP(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, p := range []Policy{E100, E50} {
			e := fixtureEntry(p, side, 3, 0, nil)
			pub := fixturePublication(e, 21, -60, True)
			in := fixtureInput(e, 1, -80, 3, 1, 0)
			in.Publication = &pub
			s, d := runAdvance(t, runState(t, e), in)
			v := s.Snapshot()
			if !v.EntryInvalidated || v.Active || d.P != False || d.EntrySupportBreak != True || d.EntryExitQuantity != 2 || d.EligibleExitQuantity != 0 || d.UnitNetYen == nil || *d.UnitNetYen >= 0 {
				t.Fatal("固定支持/動的P又は損益gate")
			}
			w := v.EntryInvalidationWitness
			if w == nil || w.P != False || w.M != True || w.SignedDistance != -10 || w.Phase != AfterSource || w.Support.ID == w.Publication.PriorPivot.ID {
				t.Fatal("最初の証拠を分離できない")
			}
			e.EntrySupport.Price = e.Price - float64(side)*100
			pub.PriorPivot.Price = e.Price - float64(side)*50
			in.Publication = &pub
			b, bd := runAdvance(t, runState(t, e), in)
			if b.Snapshot().EntryInvalidated || bd.EntrySupportBreak != False || bd.P != True {
				t.Fatal("動的Pを固定支持へ流用")
			}
		}
	}
}

// TestEarlyTruthEqualityAndUnavailable はMとCloseの三値・等号・取得以前の足を区別します。
//
// 引数: t(*testing.T)。返り値: ありません。C/Bが真でも固定支持とMを置換しません。
func TestEarlyTruthEqualityAndUnavailable(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, m := range []Truth{Unknown, False, True} {
			for _, closeKind := range []string{"未知", "等号", "逆抜け"} {
				e := fixtureEntry(E100, side, 2, 0, nil)
				pub := fixturePublication(e, 21, -60, m)
				if closeKind == "未知" {
					pub.Close = nil
				}
				if closeKind == "等号" {
					pub.Close = pointer(e.EntrySupport.Price)
				}
				in := fixtureInput(e, 1, -80, 2, 0, 0)
				in.Mark = nil
				in.Publication = &pub
				s, d := runAdvance(t, runState(t, e), in)
				want := m == True && closeKind == "逆抜け"
				if s.Snapshot().EntryInvalidated != want || d.EntryInvalidatedNow != want || s.Snapshot().Active || d.GainPoints != nil {
					t.Fatal(m, closeKind, "三値又はnilMark誤り")
				}
				if closeKind == "等号" && d.EntrySupportBreak != False || closeKind == "未知" && d.EntrySupportBreak != Unknown {
					t.Fatal("厳密不等号/未知")
				}
			}
		}
		e := fixtureEntry(E100, side, 1, 0, nil)
		pub := fixturePublication(e, 21, -60, True)
		pub.Start, pub.End, pub.AvailableAt = 3420, 3600, 3600
		pub.PriorPivot = nil
		in := fixtureInput(e, 1, -80, 1, 0, 0)
		in.Publication = &pub
		s, d := runAdvance(t, runState(t, e), in)
		if s.Snapshot().EntryInvalidated || d.EntrySupportBreak != Unknown {
			t.Fatal("取得と同じ終了足を採用")
		}
	}
}

// TestUnknownAndIneligibleEntrySupport は未知や価格位置不適格でも基礎保護を継続します。
//
// 引数: t(*testing.T)。返り値: ありません。不適格な既知原値をnilへ変えません。
func TestUnknownAndIneligibleEntrySupport(t *testing.T) {
	for _, kind := range []string{"未知", "等号", "不利側"} {
		for _, side := range []int{1, -1} {
			e := fixtureEntry(E100, side, 2, 0, nil)
			if kind == "未知" {
				e.EntrySupport = nil
			} else if kind == "等号" {
				e.EntrySupport.Price = e.Price
			} else {
				e.EntrySupport.Price = e.Price + float64(side)*10
			}
			s := runState(t, e)
			if s.Snapshot().EntrySupportEligible || kind != "未知" && s.Snapshot().Entry.EntrySupport == nil {
				t.Fatal("不適格原値の保持")
			}
			pub := fixturePublication(e, 21, -100, True)
			in := fixtureInput(e, 1, -100, 2, 0, 0)
			in.Publication = &pub
			s, d := runAdvance(t, s, in)
			if s.Snapshot().EntryInvalidated || d.EntrySupportBreak != Unknown || d.EntryExitQuantity != 0 {
				t.Fatal("不適格を技術離脱")
			}
			s, d = runAdvance(t, s, fixtureInput(e, 2, 115, 2, 0, 0))
			if !s.Snapshot().Active || !d.ActivatedNow {
				t.Fatal("不適格で必須保護を停止")
			}
		}
	}
}

// TestPriorityAndIrreversibleLatch は同時H優先と既ラッチの非撤回を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。Source予約取消・回復・後のActive化も含みます。
func TestPriorityAndIrreversibleLatch(t *testing.T) {
	for _, p := range []Policy{E100, E50} {
		e := fixtureEntry(p, 1, 3, 0, nil)
		pub := fixturePublication(e, 21, -60, True)
		in := fixtureInput(e, 1, 115, 3, 0, 0)
		in.Publication = &pub
		s, d := runAdvance(t, runState(t, e), in)
		if !s.Snapshot().Active || s.Snapshot().EntryInvalidated || d.EntryInvalidatedNow || d.EntrySupportBreak != True || d.EntryExitQuantity != 0 {
			t.Fatal("同一行のH更新を後回し")
		}
		in = fixtureInput(e, 1, -80, 3, 3, 0)
		in.Mark = nil
		in.Phase = PreFill
		in.Publication = &pub
		s, d = runAdvance(t, runState(t, e), in)
		first := copyValue(s.Snapshot().EntryInvalidationWitness)
		if !d.EntryInvalidatedNow || d.EntryExitQuantity != 0 || first.Phase != PreFill {
			t.Fatal("prefillラッチ/要求")
		}
		in = fixtureInput(e, 2, -60, 3, 3, 0)
		in.ResetReason = "未知化"
		in.Mark = nil
		s, d = runAdvance(t, s, in)
		if !s.Snapshot().EntryInvalidated || d.EntryExitQuantity != 0 || d.EntrySupportBreak != Unknown {
			t.Fatal("全予約又はreset撤回")
		}
		pub = fixturePublication(e, 22, 100, False)
		in = fixtureInput(e, 3, 115, 3, 0, 0)
		in.Publication = &pub
		s, d = runAdvance(t, s, in)
		if !s.Snapshot().Active || !d.ActivatedNow || !s.Snapshot().EntryInvalidated || d.EntryInvalidatedNow || d.EntryExitQuantity != 3 || !reflect.DeepEqual(first, s.Snapshot().EntryInvalidationWitness) {
			t.Fatal("回復/予約取消/後のHで既ラッチ撤回")
		}
	}
}

// TestPartialReservedAndNilMark はq0/R/nと予約を保ったまま早期返済量を計算します。
//
// 引数: t(*testing.T)。返り値: ありません。利益保護Activeを偽装しません。
func TestPartialReservedAndNilMark(t *testing.T) {
	e := fixtureEntry(E100, -1, 10, 5, pointer(125.5))
	s := runState(t, e)
	pub := fixturePublication(e, 21, -60, True)
	in := fixtureInput(e, 1, -80, 10, 10, 0)
	in.Publication = &pub
	in.Mark = nil
	s, d := runAdvance(t, s, in)
	if !s.Snapshot().EntryInvalidated || s.Snapshot().Active || d.EntryExitQuantity != 0 || d.EligibleExitQuantity != 0 {
		t.Fatal("全予約nilMark")
	}
	in = fixtureInput(e, 2, -10, 5, 2, -.5)
	in.Mark = nil
	s, d = runAdvance(t, s, in)
	v := s.Snapshot()
	if d.EntryExitQuantity != 3 || v.Entry.InitialQuantity != 10 || v.Remaining != 5 || v.ClosedNetYen != -.5 || v.Active || v.WholeTargetYen != 0 {
		t.Fatal("部分返済/費用半円/初期量")
	}
	in = fixtureInput(e, 3, 0, 0, 0, -50.5)
	in.Mark = nil
	s, d = runAdvance(t, s, in)
	if !s.Snapshot().Finished || !s.Snapshot().EntryInvalidated || d.EntryExitQuantity != 0 {
		t.Fatal("完結後の新要求")
	}
}

// TestAnchorAndPublicationRejections は未来・別scope・方向違いを状態変更前に拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。等号価格の不適格とは区別します。
func TestAnchorAndPublicationRejections(t *testing.T) {
	e := fixtureEntry(E100, 1, 2, 0, nil)
	for _, change := range []func(*Entry){func(e *Entry) { e.EntrySupport.Scope.Contract = "別" }, func(e *Entry) { e.EntrySupport.PublishedAt = e.At + 1 }, func(e *Entry) { e.EntrySupport.Kind = "high" }, func(e *Entry) { e.EntrySupport.ConfirmEnd = e.EntrySupport.CenterEnd - 1 }, func(e *Entry) { e.EntrySupport.Price = math.NaN() }, func(e *Entry) { e.Policy = P100 }} {
		x := copyValue(e)
		change(&x)
		if _, err := NewState(x); err == nil {
			t.Fatal("不正取得時支持を受理")
		}
	}
	s := runState(t, e)
	pub := fixturePublication(e, 21, -60, True)
	for _, change := range []func(*Input){func(x *Input) { x.Publication.Scope.Contract = "別" }, func(x *Input) { x.Publication.AvailableAt = x.At + 1 }, func(x *Input) { x.Mark = pointer(math.NaN()) }, func(x *Input) { x.ClosedNetYen = .1 }, func(x *Input) { x.Sequence = 0 }, func(x *Input) { x.Phase = "未知" }} {
		x := fixtureInput(e, 1, -80, 2, 0, 0)
		x.Publication = copyValue(&pub)
		change(&x)
		before := s.Snapshot()
		if _, _, err := Advance(s, x); err == nil || !reflect.DeepEqual(before, s.Snapshot()) {
			t.Fatal("不正公表/会計又は以前の変更")
		}
	}
}

// TestAnchorWitnessDeepCopy は入力・過去・公開Snapshotから固定証拠への別名を切ります。
//
// 引数: t(*testing.T)。返り値: ありません。最初の証拠は回復後も値が不変です。
func TestAnchorWitnessDeepCopy(t *testing.T) {
	e := fixtureEntry(E100, 1, 2, 0, pointer(80))
	s := runState(t, e)
	e.EntrySupport.Price = 1
	e.ATR.Value = 999
	if s.Snapshot().Entry.EntrySupport.Price != 950 || s.Snapshot().Entry.ATR.Value != 80 {
		t.Fatal("取得入力共有")
	}
	e = s.Snapshot().Entry
	pub := fixturePublication(e, 21, -60, True)
	in := fixtureInput(e, 1, -80, 2, 0, 0)
	in.Publication = &pub
	s, _ = runAdvance(t, s, in)
	before := s.Snapshot()
	pub.PriorPivot.Price = 1
	*pub.Close = 2
	pub.ID = "破壊"
	if !reflect.DeepEqual(before, s.Snapshot()) {
		t.Fatal("公表入力共有")
	}
	out := s.Snapshot()
	out.Entry.EntrySupport.Price = 3
	*out.EntryInvalidatedAt = 4
	out.EntryInvalidationWitness.Support.Price = 5
	*out.EntryInvalidationWitness.Publication.Close = 6
	out.EntryInvalidationWitness.Publication.PriorPivot.Price = 7
	out.Latest.PriorPivot.Price = 8
	if !reflect.DeepEqual(before, s.Snapshot()) {
		t.Fatal("公開Snapshot共有")
	}
	pub = fixturePublication(e, 22, 100, False)
	in = fixtureInput(e, 2, 115, 2, 0, 0)
	in.Publication = &pub
	next, _ := runAdvance(t, s, in)
	if !reflect.DeepEqual(before.EntryInvalidationWitness, next.Snapshot().EntryInvalidationWitness) {
		t.Fatal("最初の証拠を再作成")
	}
	if next.view.EntrySupportEligible != true || next.view.Entry.EntrySupport == next.view.EntryInvalidationWitness.Publication.PriorPivot || next.view.EntryInvalidationWitness == s.view.EntryInvalidationWitness {
		t.Fatal("新状態の参照共有")
	}
}

// TestMirrorAndPostActivationProtection は鏡像と起動後の通常保護継続を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。早期失効と利益保護の要求を別fieldに残します。
func TestMirrorAndPostActivationProtection(t *testing.T) {
	for _, p := range []Policy{E100, E50} {
		var outputs []Decision
		for _, side := range []int{1, -1} {
			e := fixtureEntry(p, side, 2, 5, pointer(125.5))
			pub := fixturePublication(e, 21, -60, True)
			in := fixtureInput(e, 1, -80, 2, 1, 0)
			in.Publication = &pub
			s, d := runAdvance(t, runState(t, e), in)
			if s.Snapshot().Active || !d.EntryInvalidatedNow {
				t.Fatal("鏡像失効")
			}
			outputs = append(outputs, d)
			in = fixtureInput(e, 2, 600, 2, 0, 0)
			post := fixturePublication(e, 22, -110, True)
			in.Publication = &post
			s, d = runAdvance(t, s, in)
			if !s.Snapshot().Active || !s.Snapshot().Narrowed || d.EntryExitQuantity != 2 || s.Snapshot().FloorPoints == nil {
				t.Fatal("既ラッチと利益保護並立")
			}
			oldFloor := *s.Snapshot().FloorPoints
			s, d = runAdvance(t, s, fixtureInput(e, 3, 0, 2, 1, 0))
			if d.EntryExitQuantity != 1 || d.EligibleExitQuantity != 1 || !d.FloorHit || *s.Snapshot().FloorPoints < oldFloor {
				t.Fatal("返済要求の分離/非緩和")
			}
		}
		if !reflect.DeepEqual(outputs[0], outputs[1]) {
			t.Fatal("Decision鏡像差")
		}
	}
}
