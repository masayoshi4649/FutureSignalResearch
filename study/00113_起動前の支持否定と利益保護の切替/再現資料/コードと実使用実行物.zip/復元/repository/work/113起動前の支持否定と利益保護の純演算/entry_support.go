package profitfloor113

import "fmt"

// validateEntrySupport は取得時に知っていた同場・同方向の確定pivotだけを受け付けます。
//
// 引数: e(Entry)、definition(Definition)は実取得と政策。返り値: errorは出典又はE以外への混入です。
// 価格位置だけ不適格な既知pivotは拒否せず、そのまま保存して技術離脱だけを無効にします。
func validateEntrySupport(e Entry, definition Definition) error {
	p := e.EntrySupport
	if p == nil {
		return nil
	}
	if !definition.EntryInvalidationEnabled {
		return fmt.Errorf("取得時支持はE政策だけに指定")
	}
	if p.Scope != e.Scope || p.ID == "" || (p.Kind != "low" && p.Kind != "high") || !finite(p.Price, p.CenterStart, p.CenterEnd, p.ConfirmEnd, p.PublishedAt) || p.Price <= 0 || p.CenterStart < e.Scope.Start || p.CenterEnd != p.CenterStart+180 || p.ConfirmEnd < p.CenterEnd || p.PublishedAt < p.ConfirmEnd || p.PublishedAt > e.At {
		return fmt.Errorf("取得時支持の場・確定・可用時刻が不正")
	}
	if e.Side == 1 && p.Kind != "low" || e.Side == -1 && p.Kind != "high" {
		return fmt.Errorf("取得時支持の売買方向が不正")
	}
	return nil
}

// entrySupportBreak は動的Pと別に、固定取得時支持を厳密逆抜けした三値を返します。
//
// 引数: v(Snapshot)、at(float64)は当時状態と判断時計。返り値: Truthは未知/偽/真です。
// 取得前又は取得時刻と等しい終了足、未知終値、未知又は不適格支持を逆抜け票にしません。
func entrySupportBreak(v Snapshot, at float64) Truth {
	if !v.Definition.EntryInvalidationEnabled || !v.EntrySupportEligible || v.Entry.EntrySupport == nil || v.Latest == nil || v.Latest.Close == nil || v.Latest.End <= v.Entry.At || v.Latest.AvailableAt > at {
		return Unknown
	}
	if float64(v.Entry.Side)*(*v.Latest.Close-v.Entry.EntrySupport.Price) < 0 {
		return True
	}
	return False
}

// applyEntryInvalidation は未起動時の固定支持否定と生Mを不可逆ラッチへ反映します。
//
// 引数: v(*Snapshot)、d(*Decision)、in(Input)は私有次状態・生の判断・当原行です。
// 返り値: ありません。利益保護Activeを変更せず、AfterSourceだけ未予約量を別要求します。
func applyEntryInvalidation(v *Snapshot, d *Decision, in Input) {
	d.EntrySupportBreak = entrySupportBreak(*v, in.At)
	if !v.EntryInvalidated && !v.Active && d.EntrySupportBreak == True && d.M == True {
		v.EntryInvalidated = true
		v.EntryInvalidatedAt = pointer(in.At)
		v.EntryInvalidationWitness = &EntryInvalidationWitness{
			At: in.At, Sequence: in.Sequence, Phase: in.Phase,
			Support: *copyPivot(v.Entry.EntrySupport), Publication: *copyPublication(v.Latest),
			SignedDistance: float64(v.Entry.Side) * (*v.Latest.Close - v.Entry.EntrySupport.Price),
			C:              d.C, M: d.M, P: d.P, B: d.B,
		}
		d.EntryInvalidatedNow = true
	}
	if v.EntryInvalidated && in.Phase == AfterSource {
		d.EntryExitQuantity = in.Remaining - in.Reserved
	}
}
