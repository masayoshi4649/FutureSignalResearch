package profitfloor113

import (
	"encoding/json"
	"fmt"
	"reflect"
	"strings"
	"testing"

	old "github.com/masayoshi4649/SessionTradeExecuter/profitfloor112fast"
)

// TestBB112WholeResult は確定足の母σ・収縮・欠足・未知と入れ子参照を112へ照合します。
//
// 引数: t(*testing.T)。返り値: ありません。3分窓は当場coldで旧113へ影響しません。
func TestBB112WholeResult(t *testing.T) {
	scope := Scope{Session: "人工場", Contract: "限月", Start: 0}
	s, err := NewBBState(scope)
	if err != nil {
		t.Fatal(err)
	}
	b, err := old.NewBBState(scope)
	if err != nil {
		t.Fatal(err)
	}
	for i := 1; i <= 48; i++ {
		if i == 35 {
			continue
		}
		bar := ClosedBar{Scope: scope, ID: fmt.Sprintf("足%d", i), Ordinal: uint64(i), Start: float64((i - 1) * 180), End: float64(i * 180), AvailableAt: float64(i * 180), Known: true, Close: pointer(1000 + float64(i%7))}
		if i == 26 {
			bar.Known = false
			bar.Close = nil
		}
		before := s.Snapshot()
		next, r, e := AdvanceBB(s, bar, bar.AvailableAt)
		nextOld, or, oe := old.AdvanceBB(b, old.ClosedBar{Scope: bar.Scope, ID: bar.ID, Ordinal: bar.Ordinal, Start: bar.Start, End: bar.End, AvailableAt: bar.AvailableAt, Known: bar.Known, Close: bar.Close}, bar.AvailableAt)
		if e != nil || oe != nil || !reflect.DeepEqual(r, or) {
			t.Fatal("BB全値差", i, e, oe)
		}
		if !reflect.DeepEqual(before, s.Snapshot()) {
			t.Fatal("未来足で過去BB変更")
		}
		saved := next.Snapshot()
		if bar.Close != nil {
			*bar.Close = 1
		}
		if r.SMA != nil {
			*r.SMA = 1
		}
		if !reflect.DeepEqual(saved, next.Snapshot()) {
			t.Fatal("BB入出力の参照共有")
		}
		s, b = next, nextOld
	}
	bar := ClosedBar{Scope: scope, ID: "未来", Ordinal: 49, Start: 8640, End: 8820, AvailableAt: 8820, Known: true, Close: pointer(1000)}
	before := s.Snapshot()
	if _, _, e := AdvanceBB(s, bar, 8819); e == nil || !reflect.DeepEqual(before, s.Snapshot()) {
		t.Fatal("未来BB受理")
	}
}

// TestWitnessRawBBAndAliases は固定支持証拠にも生C/M/P/BとBB全値を別参照で保持します。
//
// 引数: t(*testing.T)。返り値: ありません。新機能のために公表値をマスクしません。
func TestWitnessRawBBAndAliases(t *testing.T) {
	e := fixtureEntry(E100, 1, 2, 0, nil)
	p := fixturePublication(e, 21, -60, True)
	p.C = False
	p.BB = &BBResult{Scope: p.Scope, ID: p.ID, Ordinal: p.Ordinal, End: p.End, AvailableAt: p.AvailableAt, DeliveredAt: p.AvailableAt, Known: true, WindowBars: 20, SMA: pointer(1000), Sigma: pointer(20), Upper: pointer(1040), Lower: pointer(960), Width: pointer(80), BandWidth: pointer(.08), PercentB: pointer(.7), Contraction: True, WindowSHA: strings.Repeat("0", 64)}
	in := fixtureInput(e, 1, -80, 2, 0, 0)
	in.Mark = nil
	in.Publication = &p
	s, d := runAdvance(t, runState(t, e), in)
	v := s.Snapshot()
	w := v.EntryInvalidationWitness
	if w == nil || d.C != False || d.M != True || d.P != False || d.B != True || w.C != d.C || w.M != d.M || w.P != d.P || w.B != d.B || !reflect.DeepEqual(w.Publication, p) {
		t.Fatal("生値又は固定/動的の混同")
	}
	if w.Publication.BB == v.Latest.BB || w.Publication.BB.SMA == v.Latest.BB.SMA || w.Publication.Close == v.Latest.Close {
		t.Fatal("証拠と最新公表の共有")
	}
	before, _ := json.Marshal(s.Snapshot())
	*w.Publication.BB.SMA = 1
	*p.BB.Sigma = 1
	after, _ := json.Marshal(s.Snapshot())
	if string(before) != string(after) {
		t.Fatal("証拠又は入力BB破壊が内部へ漏れた")
	}
}
