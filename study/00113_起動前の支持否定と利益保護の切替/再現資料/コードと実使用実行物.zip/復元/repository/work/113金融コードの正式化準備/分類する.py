"""停止済み113金融閉包を既正式111/112参照と新規同梱へ分類する。市場本文は読まない。"""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
BASE = ROOT / "work/113利益起動水準と構造失効の連続比較"
STOP_SHA = "dfd84dc9153abc5f80659a4604f677227ab58e27f64ef3df5ee3407c95e609f0"
PRIOR_INDEXES = [
    {"path": str(ROOT / "study/00111_元の連続判断と必須追尾の再基準化/再現資料/コード所在索引.json"), "sha256": "66093619c18ccf7d4d5adb7590ab6667d51f78e914c53210b0da4d57a7bb84a8"},
    {"path": str(ROOT / "study/00112_支持否定の確認と通常追尾幅の比較/再現資料/コード所在索引.json"), "sha256": "046ba4b20951e4663e6b435c46d1eca30a80e75fb3d060cc6c2a448d7c463172"},
]


def digest(path: Path) -> str:
    """
    機能: 現物ファイルのSHA256を計算する。
    引数: path(Path)は対象ファイル。
    返り値: strのSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_ref(ref: dict[str, str]) -> dict[str, Any]:
    """
    機能: metadataのFileRefを認証してJSONを読む。
    引数: ref(dict[str,str])はpathとsha256。
    返り値: dict[str,Any]のJSON本文。
    """
    path = Path(ref["path"])
    if digest(path) != ref["sha256"]:
        raise ValueError("現物SHA不一致: " + str(path))
    return json.loads(path.read_text(encoding="utf-8-sig"))


def old_location(entry: dict[str, Any], index: dict[str, Any], index_ref: dict[str, str]) -> dict[str, Any]:
    """
    機能: 既正式索引の所在を直接のZIP entryまたはmetadata参照へ解決する。
    引数: entry(dict)は旧entry、index(dict)は旧索引、index_ref(dict)は旧索引のRef。
    返り値: dict[str,Any]の既正式所在。未知のkindはValueError。
    """
    location = entry["location"]
    kind = location["kind"]
    if kind == "このZIP":
        return {"kind": "既正式ZIP参照", "archive": index["ZIP"], "index": index_ref, "entry": location["entry"], "prior_original_path": entry["original_path"]}
    if kind == "既正式111のZIP":
        return {"kind": "既正式ZIP参照", "archive": location["archive"], "index": location["index"], "entry": location["entry"], "prior_original_path": entry["original_path"]}
    if kind == "正式同bytes成果物":
        trial_root = Path(index_ref["path"]).parent.parent
        ref = {"path": str(trial_root / location["relative"]), "sha256": entry["sha256"]}
        return {"kind": "既正式metadata参照", "ref": ref, "index": index_ref, "prior_original_path": entry["original_path"]}
    if kind == "既正式111成果物":
        return {"kind": "既正式metadata参照", "ref": location["ref"], "index": index_ref, "prior_original_path": entry["original_path"]}
    raise ValueError("旧所在kindが未対応: " + str(kind))


def restore_target(path: str, roots: dict[str, str]) -> dict[str, str]:
    """
    機能: 現113の絶対パスを復元根と相対先へ変換する。
    引数: path(str)は現パス、roots(dict[str,str])は許可復元根。
    返り値: dict[str,str]のroot/relative。根外はValueError。
    """
    current = Path(path).resolve()
    for name, root in roots.items():
        resolved = Path(root).resolve()
        if current.is_relative_to(resolved):
            return {"root": name, "relative": current.relative_to(resolved).as_posix()}
    raise ValueError("復元根外: " + path)


def classify(code: dict[str, str], goroot: dict[str, str], prior_items: list[tuple[dict, dict]]) -> list[dict[str, Any]]:
    """
    機能: 同パス同SHAを優先し、同bytes別パスの参照と新同梱を分ける。
    引数: code(dict)は現閉包、goroot(dict)は環境閉包、prior_items(list[tuple])は認証済み索引とRef。
    返り値: list[dict]の分類結果。別パス参照でも復元対象は現在のパスを維持する。
    """
    exact: dict[tuple[str, str], tuple[dict, dict, dict]] = {}
    by_sha: dict[str, tuple[dict, dict, dict]] = {}
    for index, ref in prior_items:
        for row in index["entries"]:
            if row["kind"] == "GoRoot環境参照":
                continue
            candidate = (row, index, ref)
            exact[(str(Path(row["original_path"]).resolve()), row["sha256"])] = candidate
            by_sha[row["sha256"]] = candidate
    rows = []
    for path, sha in sorted(code.items()):
        row: dict[str, Any] = {"original_path": path, "sha256": sha, "bytes": Path(path).stat().st_size}
        if path in goroot:
            if goroot[path] != sha:
                raise ValueError("GoRootのSHA差")
            row.update(kind="GoRoot環境参照", location={"kind": "環境参照のみ", "go_version": "go1.24.2"})
        else:
            candidate = exact.get((str(Path(path).resolve()), sha))
            kind = "旧同パス同SHA参照"
            if candidate is None:
                candidate = by_sha.get(sha)
                kind = "旧同bytes別パス参照"
            if candidate is None:
                row.update(kind="新規同梱予定", location={"kind": "新規ZIP予定"})
            else:
                old_entry, index, ref = candidate
                row.update(kind=kind, location=old_location(old_entry, index, ref))
        rows.append(row)
    return rows


# ----------------------------------------


def build_plan(fixed_ref: dict[str, str]) -> dict[str, Any]:
    """
    機能: 固定113条件と現物閉包を認証し正式化のmetadata素材を作る。
    引数: fixed_ref(dict[str,str])はRoot新金融条件のRef。
    返り値: dict[str,Any]の分類素材。ZIPや正式物は作らない。
    """
    fixed = load_ref(fixed_ref)
    if fixed.get("trial") != 113 or fixed.get("fixed") is not True or fixed["runtime_stop"]["sha256"] != STOP_SHA:
        raise ValueError("停止済113金融のRoot固定が必要")
    stop = load_ref(fixed["runtime_stop"])
    expected = dict(stop["全固定コードSHA256"])
    expected[fixed["runtime_stop"]["path"]] = STOP_SHA
    if expected != fixed["code_sha256"]:
        raise ValueError("停止1137閉包とRoot条件が違う")
    code = dict(expected)
    code[fixed["executable"]["path"]] = fixed["executable"]["sha256"]
    before = {}
    for path, sha in code.items():
        if digest(Path(path)) != sha:
            raise ValueError("現物code不一致: " + path)
        before[path] = sha
    prior_items = [(load_ref(ref), ref) for ref in PRIOR_INDEXES]
    for index, _ in prior_items:
        if index.get("成功") is not True:
            raise ValueError("旧正式索引が未成功")
    roots = dict(prior_items[-1][0]["restore_roots"])
    rows = classify(code, stop["GoRootコードSHA256"], prior_items)
    for row in rows:
        if row["kind"] != "GoRoot環境参照":
            row["restore"] = restore_target(row["original_path"], roots)
        if row["kind"] == "新規同梱予定":
            row["location"]["entry"] = "復元/" + row["restore"]["root"] + "/" + row["restore"]["relative"]
    after = {path: digest(Path(path)) for path in before}
    if before != after:
        raise ValueError("分類前後でcodeが変化")
    counts = dict(Counter(row["kind"] for row in rows))
    return {"試行": 113, "成功": True, "正式保存ではなく準備": True, "Root金融条件": fixed_ref, "停止": fixed["runtime_stop"], "実行物": fixed["executable"], "restore_roots": roots, "go_environment": prior_items[-1][0]["go_environment"], "旧正式索引": PRIOR_INDEXES, "件数": counts, "新規同梱bytes": sum(row["bytes"] for row in rows if row["kind"] == "新規同梱予定"), "entries": rows, "前SHA256": before, "後SHA256": after, "前後不変": True, "旧ZIP本文読取": False, "ZIP作成": False, "正式書込み": False, "Raw本文読取": 0, "市場Native本文読取": 0, "金融実行": False, "研究目標達成": False, "採用": False, "注意": ["旧同bytes別パス参照は旧entryのbytesを現在のrestoreへ復元する。旧pathへの書換えやsymlink化はしない。", "新規ZIPを正式作成する段階で全新entryのSHA/CRC/集合を再読照合する。この素材は旧ZIP本文の再認証を主張しない。", "Rootの保存/CSV/診断/Viewerの追加codeは金融ランナー1137の外にあり、実使用が決まったら別途明示して追加する。", "GoRoot716はgo1.24.2環境参照。旧111/112ZIPを113へ再複写しない。"]}


def main() -> None:
    """
    機能: Root固定を指定して分類素材を新規保存する。
    引数: CLIの--fixed(str)、--sha256(str)、--output(str)。
    返り値: None。現物差があれば非0終了。
    """
    parser = argparse.ArgumentParser(description="113金融コード閉包の正式化分類")
    parser.add_argument("--fixed", required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    plan = build_plan({"path": str(Path(args.fixed).resolve()), "sha256": args.sha256})
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(plan, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"path": str(output), "sha256": digest(output), "件数": plan["件数"], "新規同梱bytes": plan["新規同梱bytes"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
