"""分類素材の手製人工と所有コード前後不変を記録する。"""

from pathlib import Path
import hashlib
import json
import subprocess
import sys


HERE = Path(__file__).resolve().parent
OWNED = ["分類する.py", "人工検査.py", "README.md", "検査して停止する.py"]


def hashes() -> dict[str, str]:
    """
    機能: 所有4ファイルのSHA256を計算する。
    引数: なし。
    返り値: dict[str,str]の絶対パスとSHA。
    """
    return {str(HERE / name): hashlib.sha256((HERE / name).read_bytes()).hexdigest() for name in OWNED}


def main() -> None:
    """
    機能: 手製検査を実行し、新規停止とログを保存する。
    引数: CLI引数なし。
    返り値: None。失敗は非0終了。
    """
    stop_path = HERE / "停止.json"
    if stop_path.exists():
        raise ValueError("停止は新規only")
    before = hashes()
    result = subprocess.run([sys.executable, "-X", "utf8", str(HERE / "人工検査.py")], cwd=HERE, text=True, encoding="utf-8", capture_output=True)
    log_path = HERE / "人工検査.log"
    with log_path.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(result.stdout + result.stderr)
    if result.returncode != 0:
        raise ValueError(result.stdout + result.stderr)
    after = hashes()
    if before != after:
        raise ValueError("所有code前後差")
    stop = {"成功": True, "停止": True, "試行": 113, "所有コードSHA256": before, "前SHA256": before, "後SHA256": after, "前後不変": True, "主人工": 3, "人工ログ": {"path": str(log_path), "sha256": hashlib.sha256(log_path.read_bytes()).hexdigest()}, "Raw本文読取": 0, "市場Native本文読取": 0, "旧ZIP本文読取": 0, "金融実行": False, "正式保存": False}
    with stop_path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(stop, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"path": str(stop_path), "sha256": hashlib.sha256(stop_path.read_bytes()).hexdigest()}, ensure_ascii=False))


if __name__ == "__main__":
    main()
