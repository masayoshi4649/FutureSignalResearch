"""コード所在の分類・別パス復元・旧所在の直接参照を手製だけで確認する。"""

import importlib.util
from pathlib import Path
import tempfile
import unittest


HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("code_plan113", HERE / "分類する.py")
assert SPEC and SPEC.loader
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


class 分類人工(unittest.TestCase):
    """市場と旧ZIPを開かない純分類の人工。"""

    def test_同パスと同bytes別パス(self) -> None:
        """
        機能: 同SHAの旧参照でも復元先は現113パスを維持する。
        引数: self(分類人工)は人工状態。
        返り値: None。
        """
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            a, b = root / "旧.py", root / "新.py"
            a.write_bytes(b"same-code")
            b.write_bytes(a.read_bytes())
            sha = MODULE.digest(a)
            old = {"original_path": str(a), "sha256": sha, "kind": "コードと宣言", "location": {"kind": "このZIP", "entry": "復元/旧.py"}}
            index = {"ZIP": {"path": str(root / "旧.zip"), "sha256": "a" * 64}, "entries": [old]}
            index_ref = {"path": str(root / "旧索引.json"), "sha256": "b" * 64}
            rows = MODULE.classify({str(a): sha, str(b): sha}, {}, [(index, index_ref)])
            by_path = {row["original_path"]: row for row in rows}
            self.assertEqual(by_path[str(a)]["kind"], "旧同パス同SHA参照")
            self.assertEqual(by_path[str(b)]["kind"], "旧同bytes別パス参照")
            self.assertEqual(MODULE.restore_target(str(b), {"repository": str(root)}), {"root": "repository", "relative": "新.py"})
            self.assertEqual(by_path[str(b)]["location"]["entry"], "復元/旧.py")

    def test_旧所在を直接解決(self) -> None:
        """
        機能: 旧ZIP・既正式111ZIP・正式metadataの各所在を直接の参照へ揃える。
        引数: self(分類人工)は人工状態。
        返り値: None。
        """
        root = Path(tempfile.gettempdir())
        index_ref = {"path": str(root / "study/再現資料/索引.json"), "sha256": "1" * 64}
        index = {"ZIP": {"path": str(root / "old.zip"), "sha256": "2" * 64}}
        old = {"original_path": "元.py", "sha256": "3" * 64, "location": {"kind": "正式同bytes成果物", "relative": "検査/旧停止.json"}}
        resolved = MODULE.old_location(old, index, index_ref)
        self.assertEqual(resolved["ref"]["path"], str(root / "study/検査/旧停止.json"))
        for kind in ("このZIP", "既正式111のZIP"):
            old["location"] = {"kind": kind, "entry": "元entry", "archive": index["ZIP"], "index": index_ref}
            resolved = MODULE.old_location(old, index, index_ref)
            self.assertEqual(resolved["kind"], "既正式ZIP参照")
            self.assertEqual(resolved["archive"], index["ZIP"])
        old["location"] = {"kind": "既正式111成果物", "ref": {"path": str(root / "formal.json"), "sha256": "3" * 64}}
        self.assertEqual(MODULE.old_location(old, index, index_ref)["ref"], old["location"]["ref"])

    def test_新同梱と環境と不正(self) -> None:
        """
        機能: 新codeとGoRootを分離し、SHA差・未知所在・復元根外を拒否する。
        引数: self(分類人工)は人工状態。
        返り値: None。
        """
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            env, new = root / "env.go", root / "new.go"
            env.write_bytes(b"environment")
            new.write_bytes(b"new-code")
            mapping = {str(env): MODULE.digest(env), str(new): MODULE.digest(new)}
            rows = MODULE.classify(mapping, {str(env): mapping[str(env)]}, [])
            self.assertEqual({row["kind"] for row in rows}, {"新規同梱予定", "GoRoot環境参照"})
            with self.assertRaises(ValueError):
                MODULE.classify(mapping, {str(env): "0" * 64}, [])
            with self.assertRaises(ValueError):
                MODULE.old_location({"location": {"kind": "未知"}}, {}, {})
            with self.assertRaises(ValueError):
                MODULE.restore_target(str(new), {"other": str(root / "other")})


if __name__ == "__main__":
    unittest.main(verbosity=2)
