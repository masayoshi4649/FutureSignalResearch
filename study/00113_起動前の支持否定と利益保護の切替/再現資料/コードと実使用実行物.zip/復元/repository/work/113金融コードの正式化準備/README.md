# 113金融のコード正式化に使う素材

113の停止済みランナーが実使用する固定閉包1137と実exe1を、既正式111/112の成功したコード所在索引へ照合する。Raw・市場Native・金融結果・旧ZIP本文を読まず、ZIPや正式成果物も作らない。

Root条件F1から `fixed=true`、停止dfd84…、コードmapが全1136＋停止自身の厳密unionであることを検査し、現在の全1138現物SHAを確認する。旧所在索引は111の660936…と112の046ba4…をSHA認証する。

`金融コードの正式化素材.json` は `entries`、`restore_roots`、`go_environment` と新旧の件数を持つ。各entryは `original_path/sha256/bytes/kind/location` を持ち、GoRoot以外は `restore={root,relative}` も持つ。

- `GoRoot環境参照`：go1.24.2環境参照。標準コード本文を同梱しない。
- `旧同パス同SHA参照`：現パスとSHAが既正式entryに一致。
- `旧同bytes別パス参照`：SHAが旧entryに一致。旧entryのbytesを現113のrestore先へ復元する。旧パスやsymlinkへ置き換えない。
- `新規同梱予定`：旧資料に同じbytesがない。`location.entry=復元/<root>/<relative>` へ新規保存する予定。

旧locationは再帰の索引探索へせず、直接の `{kind:既正式ZIP参照,archive:FileRef,index:FileRef,entry,prior_original_path}` または `{kind:既正式metadata参照,ref:FileRef,index:FileRef,prior_original_path}` へ揃える。旧ZIPを113へ再複写しない。新ZIPを正式作成する担当はこの素材を使い、必要な旧archive/entryと新entryの同bytesを保存手順で再認証する。この準備の成功はその検査を代替しない。

```powershell
python -X utf8 'work/113金融コードの正式化準備/分類する.py' --fixed '<Root金融条件abs>' --sha256 '<SHA>' --output '<新規素材JSONabs>'
```

Rootの独立保存・CSV・診断・Viewer・正式保存helperなど、実使用が後で決まるcodeは金融1137の外にある。最終要求で明示して追加する。市場結果を見て政策・閾値・宣言を変えない。

人工3主は一時的なcode bytesだけで、同パス参照、同bytes別パスでの現復元先維持、旧所在の直接解決、新codeと環境の分離、未知所在/根外/環境SHA差の拒否を確認する。停止後は所有4ファイルを変更しない。
