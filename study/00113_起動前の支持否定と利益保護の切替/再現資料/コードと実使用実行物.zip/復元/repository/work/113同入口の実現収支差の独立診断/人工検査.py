"""市場本文を読まず、同入口・Source結合・実fill現金列と全70ゲートを人工検査する。"""
from copy import deepcopy
from pathlib import Path
import tempfile
import unittest

import 診断する as D
import 実現差の演算 as C


def fixture(side: int = 1, owner: str = "core", early: bool = False) -> tuple:
    """
    機能: 新規2枚と部分返済2回の売買鏡像を手製で作る。
    引数: side(int)、owner(str)、early(bool)。返り値: tupleはNativeと一口座。
    """
    sid, method, price = "2026-09-21_Day", "NK225_D164_15", 1000
    quote = {"time":2,"index":0,"source_line":2,"bid":995,"ask":1000,"last":1000,"quote_ok":True}
    birth = {**quote,"time":1,"index":-1,"source_line":1}
    source = {"method":method,"signal_id":"s1","kind":"initial","parent":owner+"/0","source_id":"源1","quantity_micro":20,"birth_quantity":2,"birth_time":1,"birth_quote":birth}
    evidence = {k:source[k] for k in ("method","kind","parent","source_id","quantity_micro")}
    signal = {"id":"s1","action":"new","side":side,"time":1,"owner":owner,"campaign":0,"evidence":evidence}
    hold = {"hold_id":"h1","entry_id":"s1","side":side,**{k:evidence[k] for k in ("kind","parent","source_id")}}
    src = {"session":{"id":sid},"config":{"product":"NK225mini"},"method":method,"signals":[{"at":1,"quote":birth,"signal":signal}],"holds":[hold]}
    native = {"source":{"session":{"id":sid},"sources":{"mini":src}}}
    p = {"id":"p1","entry_order_id":"o0","source":source,"source_hold_id":"h1","side":side,"initial_quantity":2,"quantity":0,"reserved":0,"closed_quantity":2,"entry_price":price,"entry_quote":quote,"realized_net":-154,"protection_active":False,"marks":{"first_whole_positive":{},"first_unit_positive":{}},"protection113":{"final_state":{"entry_invalidated":early}}}
    common = {"source":source,"source_hold_id":"h1","position_id":"p1"}
    entry = {**common,"id":"o0","kind":"entry","status":"filled","fill_id":"f0","side":side,"quantity":2}
    fills = [{**common,"id":"f0","order_id":"o0","action":"new","side":side,"quantity":2,"quote":quote,"price":price,"net_contribution_yen":-77}]
    orders = [entry]
    for n,(gain,net,cash) in enumerate(((10,923,C.Decimal("961.5")),(-10,-1077,C.Decimal("-1038.5"))),1):
        q = {**quote,"time":n+2,"index":n,"source_line":n+2}
        exitprice = price+side*gain
        part = {"position_id":"p1","quantity":1,"net_yen":net}
        orders.append({"id":f"o{n}","position_id":"p1","kind":"exit","protection_point":None,"entry_invalidation_point":{} if early else None})
        fills.append({**common,"id":f"f{n}","order_id":f"o{n}","action":"close","side":-side,"quantity":1,"price":exitprice,"quote":q,"allocations":[part],"net_contribution_yen":cash,"entry_invalidation":early})
    book = {"session":{"id":sid},"key":"E100_C0_D0","config":{"policy":"E100","slip_pts":0,"delay_seconds":0},"complete":True,"finished":True,"failure":"","positions":[p],"orders":orders,"fills":fills,"totals":{"net_yen":-154,"open_buy":0,"open_sell":0,"pending_buy":0,"pending_sell":0}}
    return native,book


def small_row(signal: str, net: int, owner: str = "core", sid: str = "2026-09-21_Day") -> dict:
    """
    機能: 実現差分解だけの小さい人工玉を作る。
    引数: signal/owner/sid(str)、net(int)。返り値: dict。金融成績とは扱わない。
    """
    roles = {n:{"要求":0,"約定":0,"約定枚":0,"返済片純額円":C.ZERO} for n in ("Source","利益保護","起動前失効")}
    roles["Source"].update({"要求":1,"約定":1,"約定枚":1,"返済片純額円":C.amount(net)})
    return {"base":(sid,"NK225mini","NK225_D164_15",1,signal),"entry":{"Source出生":{"id":signal},"SourceHold":signal,"実entry原行":{"time":1,"index":0,"source_line":1},"実entry価格":1000,"実entry枚":1},"owner":owner,"session":sid,"id":signal,"net":C.amount(net),"qty":1,"cash":[(sid,0,0,1,1,C.amount(net))],"role":roles,"whole_positive":True,"unit_positive":True,"active":False,"invalidated":False}


def gate_fixture(base: Path, partial: bool = False) -> dict:
    """
    機能: 全70成功の小metadataだけを作り、Native本文なしでゲートを試す。
    引数: base(Path)、partial(bool)。返り値: dictは手製Root要求Ref。
    """
    base.mkdir()
    condition = {"path":str((D.ROOT/"work/113進行/F1_113金融条件.json").resolve()),"sha256":D.F1_SHA}
    scenes, refs, financial = [], [], []
    for sid in D.sessions():
        ref = {"path":str((base/(sid+".Native.json.gz")).resolve()),"sha256":"a"*64}
        refs.append({"session":sid,**ref})
        scenes.append({"session":sid,"native":ref,"books":24,"complete":True,"S0_equal":True,"S0_comparisons":4,"open_quantity":0,"pending_quantity":0,"reference112_equal":True,"source111_equal":True,"reference112_comparisons":12})
        financial.extend({"session":sid,"key":k,"net_yen":0} for k in C.KEYS)
    completion = D.write(base/"完了.json",{"trial":113,"stage":"full70","success":True,"sessions":70,"books":1680,"reused_sessions":54,"replayed_sessions":16,"condition_sha256":D.F1_SHA,"unchanged":True,"before":{"code":"a"},"after":{"code":"a"},"all_reference112_equal":True,"all_source111_equal":True,"reference112_comparisons":840,"results":scenes[:-1] if partial else scenes})
    common = {"試行":113,"成功":True,"stage":"full70","場数":70,"会計数":1680,"前後不変":True,"金融条件SHA256":D.F1_SHA,"金融完了SHA256":completion["sha256"],"保存器停止SHA256":D.DEPS["会計"]["sha256"],"独立P停止SHA256":D.DEPS["P"]["sha256"]}
    saved = D.write(base/"保存.json",{**common,"入力codeSHA256前":{"code":"a"},"入力codeSHA256後":{"code":"a"},"主key":list(C.KEYS),"Native参照":refs,"場別":financial})
    check = D.write(base/"検算.json",{**common,"出力SHA256":{"結果.json":saved["sha256"]},"全残玉予約0":True,"全Source111同体":True,"旧112全金融比較":840,"不一致数":0})
    stop = D.write(base/"停止.json",{"試行":113,"成功":True,"市場前":True,"依存停止":D.DEPS,"所有ファイルSHA256":{str((D.HERE/n).resolve()):D.digest(D.HERE/n) for n in D.OWNED}})
    request = {"version":1,"trial":113,"fixed":True,"market_native_read_authorized":True,"stage":"full70","comparison_stop":stop,"condition":condition,"completion":completion,"saved_result":saved,"saved_check":check,"output_dir":str((D.HERE/"人工未作成先").resolve())}
    return D.write(base/"要求.json",request)


class ComparisonTests(unittest.TestCase):
    """市場を使わない意味のある分解と拒否の人工。"""

    def test_partial_cash_fee_and_mirror(self):
        """
        機能: 取得時費用・partial2回のcash DD1038.5円と鏡像を手計算する。
        引数: self(ComparisonTests)。返り値: None。
        """
        results=[]
        for side in (1,-1):
            native,book=fixture(side,early=True)
            rows=C.records(book,C.source_index(native))
            stat=C.statistics(rows)
            self.assertEqual(stat["実現円"],-154)
            self.assertEqual(stat["実約定cash列DD円"],C.Decimal("1038.5"))
            self.assertEqual(stat["正益後赤字玉"],1)
            self.assertEqual(stat["返済役割"]["起動前失効"]["要求"],2)
            self.assertEqual(stat["返済役割"]["起動前失効"]["返済片純額円"],-154)
            results.append(stat)
        self.assertEqual(*results)

    def test_same_changed_and_one_sided(self):
        """
        機能: 同入口・実原行差・量差・片側を全実現差72円へ結ぶ。
        引数: self(ComparisonTests)。返り値: None。
        """
        left=[small_row("same",10),small_row("changed",5),small_row("left",-30)]
        right=[small_row("same",10),small_row("changed",7),small_row("right",40)]
        right[1]["entry"]["実entry枚"]=2
        right[1]["entry"]["実entry原行"]["source_line"]=2
        groups,matched,diff=C.pair_records(left,right)
        row=C.summarize(groups,"全70","全枝")
        self.assertEqual(row["全体"]["実現差円"],72)
        self.assertEqual(len(matched),4)
        self.assertEqual(diff,{"実entry原行":1,"実entry枚":1})
        self.assertEqual(row["四群"]["同実入口"]["前"]["玉"],1)
        self.assertEqual(row["四群"]["前のみ"]["実現差円"],30)

    def test_key_scope_no_signal_only_join(self):
        """
        機能: 同Signalでも商品/場/手法/売買が違えば別出生とし重複を拒否する。
        引数: self(ComparisonTests)。返り値: None。
        """
        row=small_row("id",1)
        for i in range(4):
            other=deepcopy(row); key=list(other["base"]); key[i]=-1 if i==3 else "別"; other["base"]=tuple(key)
            groups,_,_=C.pair_records([row],[other])
            self.assertFalse(groups["同実入口"]["前"])
            self.assertEqual(len(groups["前のみ"]["前"]),1)
        with self.assertRaises(ValueError):
            C.pair_records([row,row],[])

    def test_owners_periods_and_hedge_order(self):
        """
        機能: 固定owner/期間・空群・同原行fill順と両建てcashを区別する。
        引数: self(ComparisonTests)。返り値: None。
        """
        a=small_row("a",100,"core","2026-11-06_Day")
        b=small_row("b",-50,"addon","2026-11-06_Day")
        a["cash"]=[("2026-11-06_Day",0,0,1,1,C.amount(-10)),("2026-11-06_Day",1,2,2,2,C.amount(110))]
        b["cash"]=[("2026-11-06_Day",0,1,1,1,C.amount(-10)),("2026-11-06_Day",1,3,2,2,C.amount(-40))]
        self.assertEqual(C.statistics([b,a])["実約定cash列DD円"],40)
        self.assertEqual(C.statistics([a])["実約定cash列DD円"],10)
        self.assertTrue(C.selected(a,"追加16","core"))
        self.assertFalse(C.selected(a,"元54","core"))
        self.assertFalse(C.selected(b,"11月06","core"))
        self.assertEqual(C.statistics([])["実約定cash列DD円"],0)

    def test_source_owner_and_fill_corruption(self):
        """
        機能: Source出生/owner/実new原行/返済量/cash/失効識別の改変を拒否する。
        引数: self(ComparisonTests)。返り値: None。
        """
        for field in ("source","owner","quote","qty","cash","flag"):
            native,book=fixture()
            if field=="source":book["positions"][0]["source"]["birth_time"]=2
            elif field=="owner":native["source"]["sources"]["mini"]["signals"][0]["signal"]["owner"]="未宣言"
            elif field=="quote":book["positions"][0]["entry_quote"]={"time":9}
            elif field=="qty":book["fills"][-1]["allocations"][0]["quantity"]=2
            elif field=="cash":book["fills"][0]["net_contribution_yen"]=-76
            else:book["fills"][-1]["entry_invalidation"]=True
            with self.subTest(field=field),self.assertRaises(ValueError):
                C.records(book,C.source_index(native))

    def test_dd_measure_and_zero_drawdown(self):
        """
        機能: 保存時価DDと現金列DDを別計算し、期間carryを手計算する。
        引数: self(ComparisonTests)。返り値: None。
        """
        rows=[{"session":"b","場内時価DD":10,"保存最小時価":-30,"保存最大時価":20,"net_yen":-20}, {"session":"a","場内時価DD":20,"保存最小時価":-10,"保存最大時価":100,"net_yen":40}]
        self.assertEqual(C.mtm_dd(rows),90)
        self.assertEqual(C.mtm_dd([]),0)

    def test_full70_gate_before_native(self):
        """
        機能: 全70成功の新解禁だけを許しNative不存在のままmetadata完了する。
        引数: self(ComparisonTests)。返り値: None。
        """
        with tempfile.TemporaryDirectory(dir=D.HERE) as folder:
            base=Path(folder)
            ref=gate_fixture(base/"成功")
            plan=D.prepare(Path(ref["path"]),ref["sha256"])
            self.assertEqual(len(plan["saved"]["Native参照"]),70)
            self.assertFalse(plan["output"].exists())
            self.assertTrue(all(not Path(r["path"]).exists() for r in plan["saved"]["Native参照"]))
            bad=D.load(Path(ref["path"])); bad["market_native_read_authorized"]=False
            denied=D.write(base/"解禁なし.json",bad)
            with self.assertRaises(ValueError):D.prepare(Path(denied["path"]),denied["sha256"])
            partial=gate_fixture(base/"部分",True)
            with self.assertRaises(ValueError):D.prepare(Path(partial["path"]),partial["sha256"])

    def test_ref_metadata_and_sha_denial(self):
        """
        機能: bytes/slash同体を受け入れ別SHAを拒否する。
        引数: self(ComparisonTests)。返り値: None。
        """
        a={"path":str((D.HERE/"README.md").resolve()),"sha256":"a"*64}
        self.assertTrue(D.same_ref(a,{**a,"path":a["path"].replace("\\","/"),"bytes":1}))
        self.assertFalse(D.same_ref(a,{**a,"sha256":"b"*64}))


if __name__ == "__main__":
    unittest.main(verbosity=2)
