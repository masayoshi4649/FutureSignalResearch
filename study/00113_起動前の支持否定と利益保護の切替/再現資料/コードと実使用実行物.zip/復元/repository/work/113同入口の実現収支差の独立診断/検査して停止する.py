"""実現差の新演算とゲートを人工だけで市場前停止する。"""
from pathlib import Path
from datetime import datetime, timezone
import ast
import subprocess
import sys

import 診断する as D


def main() -> None:
    """
    機能: 全所有code・元金融停止・8人工とCLIを市場前に固定する。
    引数: なし。返り値: None。市場本文やRawは読まない。
    """
    target=D.HERE/"停止.json"
    D.C.need(not target.exists(),"新規停止だけ")
    before={}
    D.dependencies(before)
    owned={str((D.HERE/n).resolve()):D.digest(D.HERE/n) for n in D.OWNED}
    for name in D.OWNED:
        if not name.endswith(".py"):continue
        for node in ast.walk(ast.parse((D.HERE/name).read_text(encoding="utf-8"))):
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                doc=ast.get_docstring(node) or ""
                D.C.need("\n" in doc and all(w in doc for w in ("機能","引数","返り値")),"関数コメント:"+node.name)
    logs=[]
    for command in ([sys.executable,"-X","utf8",str(D.HERE/"人工検査.py")],[sys.executable,"-X","utf8",str(D.HERE/"診断する.py"),"--help"]):
        p=subprocess.run(command,cwd=D.HERE,capture_output=True,text=True,encoding="utf-8",timeout=60)
        D.C.need(p.returncode==0,p.stdout+p.stderr)
        logs.append({"command":command,"exit":p.returncode,"stdout":p.stdout,"stderr":p.stderr})
    D.C.need("Ran 8 tests" in logs[0]["stderr"] and "OK" in logs[0]["stderr"],"8人工")
    D.C.need(before=={p:D.digest(Path(p)) for p in before} and owned=={p:D.digest(Path(p)) for p in owned},"全所有依存前後不変")
    proof={"試行":113,"成功":True,"市場前":True,"UTC":datetime.now(timezone.utc).isoformat(),"所有ファイルSHA256":owned,"依存停止":D.DEPS,"元停止codeSHA256":before,"前後不変":True,"主人工":8,"指定対照":list(D.C.PAIRS),"費用":4,"全対照":16,"期間":D.C.PERIODS,"owner":D.C.OWNERS,"検査ログ":logs,"市場Native本文/Raw/金融再実行/11月09":False,"閾値変更":False}
    ref=D.write(target,proof)
    print(__import__("json").dumps({"成功":True,"停止":ref},ensure_ascii=False))


if __name__ == "__main__":
    main()
