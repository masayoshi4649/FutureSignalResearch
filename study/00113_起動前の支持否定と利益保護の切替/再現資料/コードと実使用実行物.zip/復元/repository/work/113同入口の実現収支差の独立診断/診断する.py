"""Root全70成功と独立保存を新要求へ結合してから16対照を読む。"""
from collections import defaultdict
from datetime import date, timedelta
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import re

import 実現差の演算 as C

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
OWNED = ("実現差の演算.py", "診断する.py", "人工検査.py", "検査して停止する.py", "README.md")
F1_SHA = "065cb5ebc894627cb70cf6f3d8f0add7698532af269cb92c2dd3decf4051a138"
DEPS = {
    "純": {"path": str(ROOT / "work/113起動前の支持否定と利益保護の純演算/停止.json"), "sha256": "81f54d965ef8d81c65a7b58f4d376374b79c765e1ad4ada5cc6270159e4ed312"},
    "会計": {"path": str(ROOT / "work/113起動前の構造失効を執行する会計/会計停止.json"), "sha256": "226985c20b65481e86db9ea92b5264fe608db987bfc0e8d368968451907ff065"},
    "P": {"path": str(ROOT / "work/113起動前の構造失効を執行する会計/P停止.json"), "sha256": "25432cfb24561cd6beab9dbecffa64f20aad5afd8cf28beeeb01db725034f77b"},
    "Actor": {"path": str(ROOT / "work/113起動前の構造失効を執行する会計/Actor停止.json"), "sha256": "9f261c911946082c20b0bfc259a991cb045a533456187ec611732ec72a34133b"},
    "Core": {"path": str(ROOT / "work/113利益起動水準と構造失効の連続比較/停止.json"), "sha256": "dfd84dc9153abc5f80659a4604f677227ab58e27f64ef3df5ee3407c95e609f0"},
}


def digest(path: Path) -> str:
    """
    機能: 明示参照だけの全bytes指紋を求める。
    引数: path(Path)。返り値: strはSHA256。Rawへは使用しない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path) -> dict:
    """
    機能: 認証済みJSON/gzipJSONを有限十進数で読む。
    引数: path(Path)。返り値: dictは原保存値。
    """
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8-sig") as f:
        return json.load(f, parse_float=C.Decimal, parse_constant=reject_constant)


def reject_constant(value: str) -> None:
    """
    機能: JSON非標準の非有限値を拒否する。
    引数: value(str)。返り値: None。必ずValueError。
    """
    raise ValueError("非有限JSON:"+value)


def write(path: Path, value: dict) -> dict:
    """
    機能: 新規JSONだけをUTF-8で保存する。
    引数: path(Path)、value(dict)。返り値: dictはFileRef。
    """
    with path.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(value, f, ensure_ascii=False, indent=2, default=C.serial, allow_nan=False)
        f.write("\n")
    return {"path": str(path.resolve()), "sha256": digest(path)}


def same_ref(a: dict, b: dict) -> bool:
    """
    機能: 参照の解決絶対PathとSHAだけを比べる。
    引数: a/b(dict)。返り値: bool。付加bytesとslash表記差は同体性を変えない。
    """
    if not isinstance(a, dict) or not isinstance(b, dict) or not isinstance(a.get("path"), str) or not isinstance(b.get("path"), str):
        return False
    p, q = Path(a["path"]), Path(b["path"])
    return p.is_absolute() and q.is_absolute() and p.resolve() == q.resolve() and isinstance(a.get("sha256"), str) and a["sha256"] == b.get("sha256")


def reference(ref: dict, before: dict) -> Path:
    """
    機能: 明示絶対参照を認証して前後台帳へ束ねる。
    引数: ref/before(dict)。返り値: Pathは認証済み位置。
    """
    C.need(isinstance(ref, dict) and isinstance(ref.get("path"), str) and re.fullmatch("[a-f0-9]{64}", ref.get("sha256", "")) is not None, "FileRef型")
    path = Path(ref["path"])
    C.need(path.is_absolute(), "絶対参照")
    path = path.resolve()
    C.need(digest(path) == ref["sha256"], "SHA差:"+str(path))
    C.need(str(path) not in before or before[str(path)] == ref["sha256"], "同位置SHA衝突")
    before[str(path)] = ref["sha256"]
    return path


def sessions() -> list[str]:
    """
    機能: 既使用70場の固定日付順を列挙する。
    引数: なし。返り値: list[str]。11/09を含めない。
    """
    day, result = date(2026, 9, 21), []
    while day <= date(2026, 11, 6):
        if day.weekday() < 5:
            result.extend(f"{day.isoformat()}_{kind}" for kind in ("Day", "Night"))
        day += timedelta(days=1)
    C.need(len(result) == 70, "予定70")
    return result


def dependencies(before: dict) -> None:
    """
    機能: 元純/Actor/P/会計/Core停止と所有codeの現物を認証する。
    引数: before(dict)。返り値: None。市場Nativeの探索や実行は行わない。
    """
    for ref in DEPS.values():
        value = load(reference(ref, before))
        C.need(value["成功"] and value.get("市場前", value.get("停止")), "金融部品の停止")
        for name in ("所有ファイルSHA256", "所有コードSHA256"):
            for path, sha in value.get(name, {}).items():
                reference({"path": path, "sha256": sha}, before)


def prepare(path: Path, sha: str) -> dict:
    """
    機能: 新Root要求・自己停止・F1全70成功・独立保存の全予定集合を本文前に検査する。
    引数: path(Path)、sha(str)。返り値: dictは読取計画。Native本文/Rawは開かない。
    """
    before = {}
    req = load(reference({"path": str(path.resolve()), "sha256": sha}, before))
    C.need(req["version"] == 1 and req["trial"] == 113 and req["fixed"] is True and req["market_native_read_authorized"] is True and req["stage"] == "full70", "Rootの新全70解禁")
    stop = load(reference(req["comparison_stop"], before))
    C.need(stop["試行"] == 113 and stop["成功"] and stop["市場前"] and stop["依存停止"] == DEPS, "実診断器の停止")
    expected_codes = {str((HERE/n).resolve()): digest(HERE/n) for n in OWNED}
    C.need(stop["所有ファイルSHA256"] == expected_codes, "実使用codeと全所有停止")
    before.update(expected_codes)
    dependencies(before)
    condition = load(reference(req["condition"], before))
    C.need(req["condition"]["sha256"] == F1_SHA and condition["trial"] == 113 and condition["fixed"] and [c["policy"] for c in condition["actual_configurations"]] == [p for p in C.POLICIES for _ in range(4)], "凍結F1六政策")
    complete = load(reference(req["completion"], before))
    saved = load(reference(req["saved_result"], before))
    checked = load(reference(req["saved_check"], before))
    C.need(complete["trial"] == 113 and complete["stage"] == "full70" and complete["success"] is True and complete["sessions"] == 70 and complete["books"] == 1680 and complete["reused_sessions"] == 54 and complete["replayed_sessions"] == 16, "全70成功と54認証再用")
    C.need(complete["condition_sha256"] == F1_SHA and complete["unchanged"] and complete["before"] and complete["before"] == complete["after"], "同F1と全前後同体")
    C.need(complete["all_reference112_equal"] and complete["all_source111_equal"] and complete["reference112_comparisons"] == 840, "全旧12とSource")
    for value in (saved, checked):
        C.need(value["試行"] == 113 and value["成功"] is True and value["stage"] == "full70" and value["場数"] == 70 and value["会計数"] == 1680 and value["前後不変"], "全70独立保存")
        C.need(value["金融条件SHA256"] == F1_SHA and value["金融完了SHA256"] == req["completion"]["sha256"], "保存と金融同条件")
        C.need(value["保存器停止SHA256"] == DEPS["会計"]["sha256"] and value["独立P停止SHA256"] == DEPS["P"]["sha256"], "保存とP停止")
    C.need(checked["出力SHA256"]["結果.json"] == req["saved_result"]["sha256"] and checked["全残玉予約0"] and checked["全Source111同体"] and checked["旧112全金融比較"] == 840 and checked["不一致数"] == 0, "独立保存後再読")
    C.need(saved["入力codeSHA256前"] and saved["入力codeSHA256前"] == saved["入力codeSHA256後"] and tuple(saved["主key"]) == C.KEYS, "保存前後と全24")
    wanted = sessions()
    C.need([r["session"] for r in complete["results"]] == [r["session"] for r in saved["Native参照"]] == wanted, "全70順序・欠落・重複なし")
    for row, ref in zip(complete["results"], saved["Native参照"]):
        C.need(same_ref(row["native"], ref), "金融と保存のNative参照")
        C.need(row["books"] == 24 and row["complete"] and row["S0_equal"] and row["S0_comparisons"] == 4 and row["open_quantity"] == row["pending_quantity"] == 0 and row["reference112_equal"] and row["source111_equal"] and row["reference112_comparisons"] == 12, "全場の完結と対照")
    financial = {(r["session"], r["key"]): r for r in saved["場別"]}
    C.need(len(financial) == 1680 and set(financial) == {(s,k) for s in wanted for k in C.KEYS}, "0取引を含む全1680会計")
    output = Path(req["output_dir"])
    C.need(output.is_absolute() and not output.exists() and output.resolve().is_relative_to(HERE), "新規所有出力先")
    return {"request": req, "saved": saved, "before": before, "financial": financial, "output": output.resolve()}


def run(plan: dict, request_ref: dict) -> dict:
    """
    機能: 全70解禁後だけ新Nativeを順に読み16対照・固定期間/owner別実現差を保存する。
    引数: plan/request_ref(dict)。返り値: dictは小さい結果Ref。Raw/金融再実行なし。
    """
    all_groups = {f"{a}→{b}_C{c}_D{d}": {n: {s: [] for s in ("前", "後")} for n in C.GROUPS} for a,b in C.PAIRS for c in (0,5) for d in (0,1)}
    scene_rows, differences, membership, matched_rows = [], defaultdict(C.Counter), [], []
    for ref in plan["saved"]["Native参照"]:
        native = load(reference(ref, plan["before"]))
        actual, sid = native["actual"], ref["session"]
        C.need(native["trial"] == 113 and actual["trial"] == 113 and actual["complete"] and actual["scope"]["session"]["id"] == sid and set(actual["books"]) == set(C.KEYS), "当場全24Native")
        index = C.source_index(native)
        books = {}
        for key in C.KEYS:
            book = actual["books"][key]
            C.need(book["key"] == key and book["totals"]["net_yen"] == plan["financial"][(sid,key)]["net_yen"], "当場独立純額")
            books[key] = C.records(book, index)
        for a,b in C.PAIRS:
            for c in (0,5):
                for d in (0,1):
                    aid, bid = f"{a}_C{c}_D{d}", f"{b}_C{c}_D{d}"
                    name = f"{a}→{b}_C{c}_D{d}"
                    groups, matched, changed = C.pair_records(books[aid], books[bid])
                    matched_rows.extend({"session":sid,"対照":name,**r} for r in matched)
                    differences[name].update(changed)
                    for group in C.GROUPS:
                        for side in ("前", "後"):
                            all_groups[name][group][side].extend(groups[group][side])
                    counts = C.Counter(r["群"] for r in matched)
                    membership.append({"session": sid, "対照": name, "対応数": dict(counts), "変更属性": changed})
                    scene_rows.append({"session": sid, "対照": name, **C.summarize(groups,"全70","全枝")})
    aggregate = []
    for a,b in C.PAIRS:
        for c in (0,5):
            for d in (0,1):
                aid, bid = f"{a}_C{c}_D{d}", f"{b}_C{c}_D{d}"
                name = f"{a}→{b}_C{c}_D{d}"
                for period in C.PERIODS:
                    mtm = {side: C.mtm_dd([r for r in plan["saved"]["場別"] if r["key"] == key and C.selected(r, period, "全枝")]) for side,key in (("前",aid),("後",bid))}
                    for owner in C.OWNERS:
                        result = C.summarize(all_groups[name],period,owner)
                        if period == "全70" and owner == "全枝":
                            C.need(result["全体"]["前"]["実現円"] == plan["saved"]["集計"][aid]["net_yen"] and result["全体"]["後"]["実現円"] == plan["saved"]["集計"][bid]["net_yen"], "全70独立純額へ一致")
                            C.need(mtm["前"] == plan["saved"]["集計"][aid]["保存点連結時価DD"] and mtm["後"] == plan["saved"]["集計"][bid]["保存点連結時価DD"], "全口座保存時価DD")
                        aggregate.append({"対照": name, "期間": period, "owner": owner, **result, "全口座保存点連結時価DD円": mtm if owner == "全枝" else None})
    C.need(len(scene_rows) == 1120 and len(aggregate) == 320, "指定16対照と全固定群保持")
    after = {p: digest(Path(p)) for p in plan["before"]}
    C.need(after == plan["before"], "全code/金融正本前後不変")
    output = plan["output"]
    output.mkdir(parents=False, exist_ok=False)
    match_path = output/"実entryの対応台帳.jsonl.gz"
    with match_path.open("xb") as f:
        with gzip.GzipFile(fileobj=f, mode="wb", filename="", mtime=0) as z:
            for row in matched_rows:
                z.write((json.dumps(row,ensure_ascii=False,separators=(",",":"),default=C.serial,allow_nan=False)+"\n").encode("utf-8"))
    result = {"試行": 113, "成功": True, "場数": 70, "対照数": 16, "場別対照数": 1120, "Root要求": request_ref,
              "集計": aggregate, "場別": scene_rows, "対応件数": membership, "変更属性": {k:dict(v) for k,v in differences.items()},
              "実entryの対応台帳":{"path":str(match_path),"sha256":digest(match_path),"件数":len(matched_rows)},
              "定義": {"同入口": "session/product/method/side/Source signal_idを結びSource全文/SourceHold/実entry quote/price/qtyを全照合", "差方向": "後−前", "正益後赤字": "first_whole_positive保存あり、最終realized_net<0", "部分群DD": "実fill net_contribution_yenを新規費用から元fill順に連結。選択期間の期首0。時価DDではない", "全口座DD": "独立保存の場別最大DD/保存最大最小時価から連結。部分群DDと別列", "片側": "成立側の実現額だけ。未参加側へ仮想利益を作らない"},
              "入力SHA256前": plan["before"], "入力SHA256後": after, "前後不変": True,
              "未実施": {"Raw/価格CSV/11月09本文": 0, "金融再実行": 0, "退出後仮想利益/機会損失/MFE回収率": 0}, "閾値変更": False}
    return write(output/"結果.json", result)


def main() -> None:
    """
    機能: 明示Root新要求だけを受け付ける。
    引数: CLI fixed/sha256(str)、metadata-only(bool)。返り値: None。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixed", type=Path, required=True)
    parser.add_argument("--sha256", required=True)
    parser.add_argument("--metadata-only", action="store_true")
    args = parser.parse_args()
    plan = prepare(args.fixed,args.sha256)
    if args.metadata_only:
        print(json.dumps({"成功":True,"Native本文読取":False,"全70予定":True},ensure_ascii=False))
        return
    ref = run(plan,{"path":str(args.fixed.resolve()),"sha256":args.sha256})
    print(json.dumps({"成功":True,"結果":ref},ensure_ascii=False))


if __name__ == "__main__":
    main()
