"""実新規と全実約定だけを使い、同入口・入口差・片側の実現差を分ける。"""
from collections import Counter
from decimal import Decimal
import hashlib
import json

ZERO = Decimal(0)
POLICIES = ("S0", "W100", "P100", "P50", "E100", "E50")
KEYS = tuple(f"{p}_C{c}_D{d}" for p in POLICIES for c in (0, 5) for d in (0, 1))
PAIRS = (("P100", "P50"), ("P100", "E100"), ("P50", "E50"), ("E100", "E50"))
GROUPS = ("同実入口", "取得変更", "前のみ", "後のみ")
OWNERS = ("全枝", "core", "addon", "episode", "不明")
PERIODS = ("全70", "元54", "追加16", "11月06")


def need(value: bool, label: str) -> None:
    """
    機能: 不整合を推測で埋めず拒否する。
    引数: value(bool)、label(str)。返り値: None。不成立はValueError。
    """
    if not value:
        raise ValueError(label)


def amount(value) -> Decimal:
    """
    機能: 保存値を有限十進数へ写す。
    引数: value(int/float/Decimal)。返り値: Decimal。非数値・非有限値は拒否。
    """
    need(type(value) in (int, float, Decimal), "数値型")
    result = Decimal(str(value))
    need(result.is_finite(), "有限値")
    return result


def canon(value) -> str:
    """
    機能: 価格や原行の入れ子を型を隠さず同体比較へ写す。
    引数: value(JSON値)。返り値: strは正準表現。Decimalは数値として比較する。
    """
    return json.dumps(value, sort_keys=True, separators=(",", ":"), default=serial, allow_nan=False)


def serial(value):
    """
    機能: 有限DecimalだけをJSON数値へ直列化する。
    引数: value(object)。返り値: int/float。対応外はTypeError。
    """
    if isinstance(value, Decimal) and value.is_finite():
        return int(value) if value == value.to_integral_value() else float(value)
    raise TypeError(type(value).__name__)


def source_index(native: dict) -> dict:
    """
    機能: Source入口Signalを場・商品・手法・売買・Signalへ結ぶ。
    引数: native(dict)。返り値: dictは入口タグと元所有。未来価格は使わない。
    """
    sid, result = native["source"]["session"]["id"], {}
    for src in native["source"]["sources"].values():
        product = src["config"]["product"]
        if product != "NK225mini":
            continue
        need(src["session"]["id"] == sid, "Source同場")
        holds = {h["hold_id"]: h for h in src["holds"]}
        need(len(holds) == len(src["holds"]), "元所有重複")
        for rec in src["signals"]:
            signal = rec["signal"]
            if signal["action"] != "new":
                continue
            key = sid, product, src["method"], signal["side"], signal["id"]
            need(key not in result, "Source複合入口重複")
            result[key] = {"signal": signal, "record": rec, "holds": holds}
    return result


def records(book: dict, index: dict) -> list[dict]:
    """
    機能: 一口座の実玉と要求・fill・Sourceタグを結び、小さい比較台帳を作る。
    引数: book/index(dict)。返り値: list[dict]は実現統計と実fill現金列。原値は変更しない。
    """
    need(book["complete"] and book["finished"] and not book["failure"], "完結口座")
    sid, result, seen = book["session"]["id"], [], set()
    orders = {o["id"]: o for o in book["orders"]}
    need(len(orders) == len(book["orders"]), "注文重複")
    for p in book["positions"]:
        source = p["source"]
        key = sid, "NK225mini", source["method"], p["side"], source["signal_id"]
        need(key not in seen and key in index, "実玉Source結合・重複")
        seen.add(key)
        tag, e = index[key], index[key]["signal"].get("evidence") or {}
        signal = tag["signal"]
        need(source["birth_time"] == tag["record"]["at"] == signal["time"] and source["birth_quote"] == tag["record"]["quote"], "出生原行")
        for field in ("method", "kind", "parent", "source_id", "quantity_micro"):
            need(source.get(field) == e.get(field), "入口タグ:"+field)
        hold = tag["holds"].get(p["source_hold_id"])
        need(hold is not None and hold["entry_id"] == signal["id"] and hold["side"] == p["side"], "元所有入口")
        for field in ("kind", "parent", "source_id"):
            need(hold.get(field) == source.get(field), "元所有タグ:"+field)
        owner = signal.get("owner") or "不明"
        need(owner in OWNERS[1:], "未宣言owner")
        need(p["quantity"] == p["reserved"] == 0 and p["closed_quantity"] == p["initial_quantity"] > 0, "実玉完結")
        own_fills = [(i, f) for i, f in enumerate(book["fills"]) if f["position_id"] == p["id"]]
        new = [f for _, f in own_fills if f["action"] == "new"]
        need(len(new) == 1, "実玉へnew一つ")
        order = orders[p["entry_order_id"]]
        need(order["kind"] == "entry" and order["status"] == "filled" and order["fill_id"] == new[0]["id"], "実new注文")
        for field, actual in (("source", source), ("source_hold_id", p["source_hold_id"]), ("side", p["side"]), ("quantity", p["initial_quantity"])):
            need(order[field] == new[0][field] == actual, "実new所有:"+field)
        need(new[0]["quote"] == p["entry_quote"] and new[0]["price"] == p["entry_price"], "実取得原行価格")
        parts = [a for _, f in own_fills if f["action"] == "close" for a in f["allocations"]]
        need(all(a["position_id"] == p["id"] for a in parts), "返済片所有")
        need(sum(a["quantity"] for a in parts) == p["initial_quantity"], "実返済量")
        net = amount(p["realized_net"])
        need(sum((amount(a["net_yen"]) for a in parts), ZERO) == net, "返済片純額")
        cash = [(sid, f["quote"]["index"], ordinal, f["quote"]["time"], f["quote"]["source_line"], amount(f["net_contribution_yen"])) for ordinal, f in own_fills]
        need(sum((x[-1] for x in cash), ZERO) == net, "新規費用込みfill現金列")
        role = {name: {"要求": 0, "約定": 0, "約定枚": 0, "返済片純額円": ZERO} for name in ("Source", "利益保護", "起動前失効")}
        own_orders = [o for o in book["orders"] if o["kind"] == "exit" and o["position_id"] == p["id"]]
        for o in own_orders:
            name = "起動前失効" if o.get("entry_invalidation_point") is not None else "利益保護" if o["protection_point"] is not None else "Source"
            role[name]["要求"] += 1
        for _, f in own_fills:
            if f["action"] != "close":
                continue
            o = orders[f["order_id"]]
            name = "起動前失効" if o.get("entry_invalidation_point") is not None else "利益保護" if o["protection_point"] is not None else "Source"
            need(f.get("entry_invalidation", False) == (name == "起動前失効"), "失効fill識別")
            role[name]["約定"] += 1
            role[name]["約定枚"] += f["quantity"]
            role[name]["返済片純額円"] += sum((amount(a["net_yen"]) for a in f["allocations"]), ZERO)
        signature = {"Source出生": source, "SourceHold": p["source_hold_id"], "実entry原行": p["entry_quote"], "実entry価格": p["entry_price"], "実entry枚": p["initial_quantity"]}
        result.append({"base": key, "entry": signature, "owner": owner, "kind": e.get("kind") or "不明", "parent": e.get("parent"), "campaign": signal.get("campaign"),
                       "id": p["id"], "session": sid, "net": net, "qty": p["initial_quantity"], "cash": cash, "role": role,
                       "whole_positive": p["marks"]["first_whole_positive"] is not None, "unit_positive": p["marks"]["first_unit_positive"] is not None,
                       "active": p["protection_active"], "invalidated": bool(p.get("protection113", {}).get("final_state", {}).get("entry_invalidated", False))})
    need(sum((r["net"] for r in result), ZERO) == amount(book["totals"]["net_yen"]), "口座全実現額")
    need(all(book["totals"][k] == 0 for k in ("open_buy", "open_sell", "pending_buy", "pending_sell")), "口座残0")
    return result


def statistics(rows: list[dict]) -> dict:
    """
    機能: 成立した実玉だけの損益・利益後赤字・返済役割・実約定cash列DDを集計する。
    引数: rows(list[dict])。返り値: dict。部分群のDDを時価DDとは呼ばない。
    """
    stat = Counter({k: 0 for k in ("玉", "枚", "実現円", "利益総額円", "損失総額円", "正益後赤字玉", "正益後赤字額円", "単位正益後赤字玉", "起動後赤字玉", "起動後赤字額円", "失効玉")})
    roles = {n: Counter({k: 0 for k in ("要求", "約定", "約定枚", "返済片純額円")}) for n in ("Source", "利益保護", "起動前失効")}
    for row in rows:
        net = row["net"]
        stat["玉"] += 1
        stat["枚"] += row["qty"]
        stat["実現円"] += net
        stat["利益総額円"] += max(ZERO, net)
        stat["損失総額円"] += min(ZERO, net)
        stat["正益後赤字玉"] += row["whole_positive"] and net < 0
        stat["正益後赤字額円"] += net if row["whole_positive"] and net < 0 else 0
        stat["単位正益後赤字玉"] += row["unit_positive"] and net < 0
        stat["起動後赤字玉"] += row["active"] and net < 0
        stat["起動後赤字額円"] += net if row["active"] and net < 0 else 0
        stat["失効玉"] += row["invalidated"]
        for name in roles:
            roles[name].update(row["role"][name])
    cash = peak = dd = ZERO
    events = sorted((e for r in rows for e in r["cash"]), key=lambda e: e[:3])
    for event in events:
        cash += event[-1]
        peak = max(peak, cash)
        dd = max(dd, peak-cash)
    need(cash == stat["実現円"] and stat["実現円"] == stat["利益総額円"]+stat["損失総額円"], "統計正負とcash加法")
    need(sum((r["返済片純額円"] for r in roles.values()), ZERO) == stat["実現円"], "三返済役割加法")
    return {**stat, "実約定cash列DD円": dd, "返済役割": {n: dict(v) for n,v in roles.items()}}


def pair_records(left: list[dict], right: list[dict]) -> tuple[dict, list[dict], dict]:
    """
    機能: 指定複合キーで出生を結び実入口の同体を別に判定する。
    引数: left/right(list[dict])。返り値: tupleは四群の実玉・小対応表・差分属性件数。
    """
    a, b = {r["base"]: r for r in left}, {r["base"]: r for r in right}
    need(len(a) == len(left) and len(b) == len(right), "複合出生キー重複")
    groups, matched, differences = {n: {"前": [], "後": []} for n in GROUPS}, [], Counter()
    for key in sorted(a.keys() | b.keys()):
        l, r = a.get(key), b.get(key)
        changed = [] if l is None or r is None else [n for n in l["entry"] if canon(l["entry"][n]) != canon(r["entry"][n])]
        group = "後のみ" if l is None else "前のみ" if r is None else "取得変更" if changed else "同実入口"
        differences.update(changed)
        for side, row in (("前", l), ("後", r)):
            if row is not None:
                groups[group][side].append(row)
        matched.append({"base": key, "群": group, "前ID": l["id"] if l else None, "後ID": r["id"] if r else None, "差分属性": changed,
                        "前実entry": entry_evidence(l) if l else None, "後実entry": {"前と全値同体":True} if group == "同実入口" else entry_evidence(r) if r else None})
    return groups, matched, dict(differences)


def entry_evidence(row: dict) -> dict:
    """
    機能: 対応台帳へ必要な実entry原値とSource全文指紋だけを写す。
    引数: row(dict)。返り値: dict。退出後価格やSource全文の重複を保存しない。
    """
    e = row["entry"]
    return {"原行":e["実entry原行"],"価格":e["実entry価格"],"枚数":e["実entry枚"],"SourceHold":e["SourceHold"],
            "Source出生SHA256":hashlib.sha256(canon(e["Source出生"]).encode("utf-8")).hexdigest()}


def selected(row: dict, period: str, owner: str) -> bool:
    """
    機能: 事前固定した期間とSource ownerだけで実玉を選ぶ。
    引数: row(dict)、period/owner(str)。返り値: bool。結果から群を選び直さない。
    """
    sid = row["session"]
    return (owner == "全枝" or row["owner"] == owner) and (period == "全70" or period == "元54" and sid[:10] <= "2026-10-27" or period == "追加16" and sid[:10] >= "2026-10-28" or period == "11月06" and sid[:10] == "2026-11-06")


def summarize(groups: dict, period: str, owner: str) -> dict:
    """
    機能: 同じ固定四群の期間/owner別実績と全差の加法を検査する。
    引数: groups(dict)、period/owner(str)。返り値: dictは四群と全体。片側未取得の利益を補わない。
    """
    result = {}
    all_rows = {side: [] for side in ("前", "後")}
    for name in GROUPS:
        pairs = {side: [r for r in groups[name][side] if selected(r, period, owner)] for side in all_rows}
        a, b = statistics(pairs["前"]), statistics(pairs["後"])
        result[name] = {"前": a, "後": b, "実現差円": b["実現円"]-a["実現円"]}
        for side in all_rows:
            all_rows[side].extend(pairs[side])
    a, b = statistics(all_rows["前"]), statistics(all_rows["後"])
    delta = b["実現円"]-a["実現円"]
    need(delta == sum((r["実現差円"] for r in result.values()), ZERO), "全体差と四群差")
    return {"全体": {"前": a, "後": b, "実現差円": delta}, "四群": result}


def mtm_dd(rows: list[dict]) -> Decimal:
    """
    機能: 全口座だけの保存点連結時価DDを独立結果の場別値から連結する。
    引数: rows(list[dict])は同一口座の固定期間。返り値: Decimal。枝別へ転用しない。
    """
    carry = peak = dd = ZERO
    for row in sorted(rows, key=lambda r: r["session"]):
        dd = max(dd, amount(row["場内時価DD"]), peak-carry-amount(row["保存最小時価"]))
        peak = max(peak, carry+amount(row["保存最大時価"]))
        carry += amount(row["net_yen"])
    return dd
