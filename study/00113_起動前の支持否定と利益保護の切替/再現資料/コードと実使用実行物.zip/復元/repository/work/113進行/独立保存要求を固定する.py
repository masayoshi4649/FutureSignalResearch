"""113金融の成功段階だけを独立会計とViewer保存へ渡す。"""
import hashlib
import json
import sys
from pathlib import Path


def load(path: Path, expected: str) -> dict:
    """固定指紋でJSONを読む。

    引数: path(Path)、expected(str)は参照とSHA。
    返り値: dictは認証済み内容。
    """
    raw=path.read_bytes()
    assert hashlib.sha256(raw).hexdigest()==expected,path
    return json.loads(raw)


def main() -> None:
    """成功完了とNative参照を全予定順で接合し新要求へ保存する。

    引数: sys.argv(list[str])はstage・完了JSON・期待SHA。
    返り値: None。原板と市場Native本文は読まない。
    """
    root=Path(__file__).resolve().parents[2]
    stage,complete_path,complete_sha=sys.argv[1],Path(sys.argv[2]).resolve(),sys.argv[3]
    hashes={'first2':'5f515c9c4a2616981a7a42b5f324a08e9b008ddb398a3cc1a95742c145b04140','base54':'f5b23e1acd7473e6b8d803bcfe6cad7c2bf37d031d8befad6624fe94473cb424','full70':'d51def2d8e19a31d5b4dfb593614de296478026b1c3d322b6d6da899e259b406'}
    p=root/'work/113金融の消費前確認'/('独立保存の要求テンプレ_'+stage+'.json')
    req=load(p,hashes[stage])
    c=load(complete_path,complete_sha)
    assert c['success'] and c['trial']==113 and c['stage']==stage
    assert c['condition_sha256']==req['condition']['sha256']=='065cb5ebc894627cb70cf6f3d8f0add7698532af269cb92c2dd3decf4051a138'
    assert c['unchanged'] and c['before']==c['after'] and c['all_reference112_equal'] and c['all_source111_equal']
    assert c['books']==24*len(req['scenes']) and c['sessions']==len(req['scenes'])
    assert [r['session'] for r in req['scenes']]==[r['session'] for r in c['results']]
    for row,result in zip(req['scenes'],c['results']):
        assert result['reference112']==row['reference112'] and result['complete'] and result['open_quantity']==result['pending_quantity']==0
        row['native']=result['native']
    req['completion']={'path':str(complete_path),'sha256':complete_sha}
    req['fixed']=True
    req['market_native_read_authorized']=True
    q=root/'work/113進行'/(stage+'_独立保存要求.json')
    raw=(json.dumps(req,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    with q.open('xb') as handle:
        handle.write(raw)
    print(json.dumps({'成功':True,'要求':{'path':str(q),'sha256':hashlib.sha256(raw).hexdigest()},'場数':len(req['scenes'])},ensure_ascii=False))


if __name__=='__main__':
    main()
