"""113の成功正本・CSV・同入口と技法文脈の根拠を正式保存要求へ束ねる。"""
import gzip
import hashlib
import json
from pathlib import Path


def ref(path: Path) -> dict:
    """現物の絶対参照と指紋を作る。

    引数: path(Path)は小資料・コード・圧縮診断。
    返り値: dictはpath/sha256。
    """
    return {'path':str(path.resolve()),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def write_new(path: Path, data: bytes) -> dict:
    """新規ファイルだけを保存する。

    引数: path(Path)、data(bytes)は保存先と内容。
    返り値: dictは保存後の参照。
    """
    with path.open('xb') as handle:
        handle.write(data)
    return ref(path)


def main() -> None:
    """実使用コードと成功根拠を追加し、新しい正式保存要求を固定する。

    引数: なし。
    返り値: None。原板とNative本文は開かず、金融計算を再実行しない。
    """
    root=Path(__file__).resolve().parents[2]
    here=Path(__file__).resolve().parent
    template=root/'work/113正式保存への接続/正式保存の要求テンプレ.json'
    assert ref(template)['sha256']=='d3aa92a3de6663f19537c663b981daac9d08a52c36b87980ea1c2ad1af4a5b9f'
    d=json.loads(template.read_bytes())
    assert not d['fixed'] and not d['market_native_read_authorized']
    for r in [*d['refs'].values(),*d['csv_refs'].values()]:
        assert ref(Path(r['path']))['sha256']==r['sha256'],r['path']
    # ----------------------------------------
    # 全件診断は圧縮保存する。JSONLは行要素を保ったJSON配列へ包み、原参照も残す。
    comparison=root/'work/113同入口の実現収支差の独立診断/全70の実現差'
    source=comparison/'結果.json'
    assert ref(source)['sha256']=='cd8bb106ec942a559a9e02c5200eb235a4f5d12cbf22f7825c7bd5aef3803859'
    compressed=write_new(here/'同入口の実現収支差.json.gz',gzip.compress(source.read_bytes(),mtime=0))
    assert gzip.decompress(Path(compressed['path']).read_bytes())==source.read_bytes()
    pairs=comparison/'実entryの対応台帳.jsonl.gz'
    assert ref(pairs)['sha256']=='8ca8663158dd86c28e2d70003c8a3f6abb954af5793175d707fda9d8579b8557'
    pair_rows=[json.loads(line) for line in gzip.decompress(pairs.read_bytes()).decode('utf-8').splitlines()]
    assert len(pair_rows)==8891
    envelope={'version':1,'元JSONL圧縮参照':ref(pairs),'件数':len(pair_rows),'records':pair_rows}
    pair_ref=write_new(here/'実entryの対応台帳.json.gz',gzip.compress(json.dumps(envelope,ensure_ascii=False,separators=(',',':')).encode('utf-8'),mtime=0))
    assert json.loads(gzip.decompress(Path(pair_ref['path']).read_bytes()))['records']==pair_rows
    d['extra_refs']=[{'ref':compressed,'target':'診断/同入口の実現収支差.json.gz','role':'原結果JSONの全bytesをgzip圧縮。解凍後の原SHAはcd8bb106ec942a559a9e02c5200eb235a4f5d12cbf22f7825c7bd5aef3803859。'},
                     {'ref':pair_ref,'target':'診断/実entryの対応台帳.json.gz','role':'原JSONL全8891行をrecords配列へ同値で保存、元圧縮Refを同梱。金融値は変更しない。'}]
    # ----------------------------------------
    # 停止済み技法所見はリンクだけ正式先へ合わせた派生版とし、原本は不変に保つ。
    context=root/'work/113早期失効の当時技法文脈'
    stop=context/'停止.json'
    assert ref(stop)['sha256']=='6f09204f06b0cce862f94350cb5a9853477208987983d0c0211bc660c91502a4'
    stopped=json.loads(stop.read_bytes())
    assert stopped['成功'] and stopped['停止']
    for p,h in stopped['所有コードSHA256'].items():
        assert ref(Path(p))['sha256']==h
    original=context/'調査.md'
    text=original.read_text(encoding='utf-8')
    assert ref(original)['sha256']=='1ae8fd26083ceff282a8025de768866e3e5c5e99a53f3230373882820ac0ad76'
    text=text.replace('../../study/00112_','../../../00112_')
    rebased=write_new(here/'早期失効の技法文脈_正式リンク.md',text.encode('utf-8'))
    d['extra_refs'].append({'ref':rebased,'target':'診断/早期失効の技法文脈/調査.md','role':'停止済み所見の相対リンクだけ正式先へ変更。原本SHA1ae8fd…と停止で根拠を保持。'})
    additions=[
        ('診断/早期失効の技法文脈/当時値.json',context/'当時値.json'),
        ('診断/早期失効の技法文脈/11月06日の無作用.json',context/'11月06日の無作用.json'),
        ('検査/早期失効の技法文脈停止.json',stop),
        ('検査/同入口診断の停止.json',comparison.parent/'停止.json'),
        ('検査/同入口診断の要求.json',here/'全70同入口診断の要求.json'),
        ('検査/同入口診断のレビュー.json',root/'work/113全70同入口差のレビュー/確認.json'),
        ('診断/同入口診断のレビュー.md',root/'work/113全70同入口差のレビュー/レビュー.md'),
        ('検査/先頭2金融成功.json',root/'work/113金融F1/先頭2場/完了.json'),
        ('検査/先頭2独立保存確認.json',root/'work/113独立保存F1/先頭2場/保存会計の確認.json'),
        ('検査/元54金融成功.json',root/'work/113金融F1/元54場/完了.json'),
        ('検査/元54独立保存確認.json',root/'work/113独立保存F1/元54場/保存会計の確認.json'),
        ('検査/先頭2の発動範囲確認.json',root/'work/113初回2場の早期失効独立確認/確認.json'),
        ('検査/設定と結果の結合確認.json',here/'設定と結果の結合確認.json'),
        ('検査/CSVの生成確認.json',root/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/113損益CSV/CSVの確認.json'),
    ]
    for target,p in additions:
        d['extra_refs'].append({'ref':ref(p),'target':target,'role':'実行済み検査・診断の根拠'})
    codes=[here/n for n in ['金融条件を固定する.py','独立保存要求を固定する.py','設定表へ結果を結合する.py','結果の説明を作る.py','正式保存要求を作る.py']]
    codes += [root/'work/113損益CSVの出力'/n for n in ['出力する.mjs','CSVを独立再読する.py']]
    for owned_stop in [comparison.parent/'停止.json',stop]:
        values=json.loads(owned_stop.read_bytes())
        for name in ['所有コードSHA256','所有ファイルSHA256']:
            codes += [Path(p) for p in values.get(name,{}) if Path(p).suffix in ['.py','.mjs']]
    for p in dict.fromkeys(codes):
        d['code_refs'].append({'ref':ref(p),'role':'Rootの実使用検査/CSV/診断helper'})
    d['fixed']=True
    d['market_native_read_authorized']=True
    q=here/'113正式保存の固定要求.json'
    r=write_new(q,(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
    print(json.dumps({'成功':True,'要求':r,'明示追加コード':len(d['code_refs']),'追加根拠':len(d['extra_refs'])},ensure_ascii=False))


if __name__=='__main__':
    main()
