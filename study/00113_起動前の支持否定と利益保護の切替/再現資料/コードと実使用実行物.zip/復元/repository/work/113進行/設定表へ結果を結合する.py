"""固定F1の設定素材へ、全70場の独立結果だけを結合する。"""
import hashlib
import json
import re
from pathlib import Path


def main() -> None:
    """56手法と9尺度・22設定・24複合条件を検査して正式な表へ保存する。

    引数: なし。
    返り値: None。市場計算・閾値変更・旧112表の更新は行わない。
    """
    root=Path(__file__).resolve().parents[2]
    source=root/'work/113設定表の更新素材/設定と結果.md'
    raw=source.read_bytes()
    assert hashlib.sha256(raw).hexdigest()=='f2f0711168aa98017ee5087cb2a645c46390578a1b4137a34c1b9e2dad1bc402'
    p=root/'work/113独立保存F1/全70場/結果.json'
    assert hashlib.sha256(p.read_bytes()).hexdigest()=='6492ae50b8fbf5b3dbe61d4295147119619e7ecbfd7cb09cbe39bc267663852b'
    d=json.loads(p.read_bytes())
    assert d['成功'] and d['会計数']==1680 and d['場数']==70 and d['前後不変']
    text=raw.decode('utf-8')
    old='版6の56手法×9尺度を保持し、Root金融F1の24条件と設定ID・閾値を事前に記す。金融成績・独立検算・CSVは本素材へ未受領。112の数値を113の結果として転記しない。採用なし。'
    assert old in text
    text=text.replace(old,'版6の56手法×9尺度を保持し、固定F1の22設定・24条件と全70場1,680会計の独立結果を記す。金融・独立検算・CSV再読は完了。追加案の採用なし。')
    text=text.replace('../../work/113進行/F1_113金融条件.json','検査/condition.json')
    text=text.replace('本素材のリンクは正式先study113からの相対先である。','[独立正本](成果物/結果.json) / [CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/113損益CSV/README.md)。')
    text=text.replace('全R、結果は未受領','全R、独立全1,680会計')
    text=text.replace('## 複合条件と結果（金融F1・全70場の成績未受領）','## 複合条件と結果（金融F1・全70場1,680会計）')
    found=[]
    lines=[]
    for line in text.splitlines():
        match=re.match(r'^\| (R\d{2}) \| ([A-Z0-9_]+) \| (.*?) \| 結果未受領 \|$',line)
        if match:
            rid,key,settings=match.groups()
            r=d['集計'][key]
            sign='＋' if r['net_yen']>=0 else '−'
            result=f"純額{sign}{abs(r['net_yen']):,}円、PF {r['PF']:.3f}、勝率{100*r['win_rate']:.2f}%、正益後赤字{r['whole_positive_closed_negative']}玉、追加起動{r['protection_activated_positions']}玉、起動後赤字{r['activated_closed_negative']}玉、失効{r['entry_invalidated_positions']}玉/要求{r['entry_invalidation_exit_requests']}件/約定{r['entry_invalidation_exit_fills']}件"
            line=f'| {rid} | {key} | {settings} | {result} |'
            found.append(key)
        lines.append(line)
    text='\n'.join(lines)+'\n'
    assert found==d['主key']
    text=text.replace('金額・PF・勝率・利益後赤字・追加起動・起動後赤字はRootから成功正本が解禁された後に追記する。','金額・PF・勝率・利益後赤字・追加起動・起動後赤字・失効は113の独立正本から結合した。')
    text=text.replace('独立結果/CSV/正式保存の相対リンクはRoot成功Refが揃った後に確定する。','[独立結果](成果物/結果.json)・[保存検査](成果物/保存会計の確認.json)・[CSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/113損益CSV/README.md)を正本とする。')
    technique=[line for line in text.splitlines() if re.match(r'^\| (?:I|C|P|V|B|X|M)\d{2} \|',line) or re.match(r'^\| E0[12] \|',line)]
    assert len(technique)==56 and all(len(line.strip('|').split('|'))==11 for line in technique)
    assert len(re.findall(r'^\| S\d{2} \|',text,re.M))==22
    target=root/'study/00113_起動前の支持否定と利益保護の切替/設定と結果.md'
    target.write_text(text,encoding='utf-8')
    proof={'成功':True,'入力素材SHA256':'f2f0711168aa98017ee5087cb2a645c46390578a1b4137a34c1b9e2dad1bc402','独立結果SHA256':'6492ae50b8fbf5b3dbe61d4295147119619e7ecbfd7cb09cbe39bc267663852b','手法':56,'尺度':9,'設定数':22,'複合数':24,'出力SHA256':hashlib.sha256(target.read_bytes()).hexdigest(),'旧112更新':False}
    q=root/'work/113進行/設定と結果の結合確認.json'
    q.write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
