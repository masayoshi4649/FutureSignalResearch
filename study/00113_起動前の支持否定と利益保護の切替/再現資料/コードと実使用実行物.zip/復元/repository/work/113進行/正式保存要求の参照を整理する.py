"""保存器が自動保存する元54完了の重複指定だけを除く。"""
import hashlib
import json
from pathlib import Path


def main() -> None:
    """原要求を変更せず、同じ根拠を一度だけ保存する後継要求を作る。

    引数: なし。
    返り値: None。金融条件と結果・停止コードは変更しない。
    """
    here=Path(__file__).resolve().parent
    source=here/'113正式保存の固定要求.json'
    raw=source.read_bytes()
    assert hashlib.sha256(raw).hexdigest()=='c8bf1ee59a509d30d8cb25657757c6795878c2bfc67a71e4b1ba013a53a91414'
    d=json.loads(raw)
    market=json.loads(Path(d['refs']['market']['path']).read_bytes())
    automatic={str(Path(r['path']).resolve()):r['sha256'] for r in d['refs'].values()}
    prior=market['prior54']
    automatic[str(Path(prior['path']).resolve())]=prior['sha256']
    remaining,removed=[],[]
    for row in d['extra_refs']:
        path=str(Path(row['ref']['path']).resolve())
        if path in automatic:
            assert automatic[path]==row['ref']['sha256']
            removed.append(row['target'])
        else:
            remaining.append(row)
    assert removed==['検査/元54金融成功.json']
    d['extra_refs']=remaining
    p=Path(__file__).resolve()
    d['code_refs'].append({'ref':{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()},'role':'自動保存する元54参照の重複だけを除いたRoot helper'})
    d['参照整理']={'元要求SHA256':'c8bf1ee59a509d30d8cb25657757c6795878c2bfc67a71e4b1ba013a53a91414','理由':'正式保存器がmarket.prior54を検査/元54成功.jsonへ同bytes保存するため、同じ元pathの追加複写を除く。','除去した重複指定':removed,'金融条件変更':False,'先行要求の正式書込':0}
    out=here/'113正式保存の固定要求_参照整理.json'
    body=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    with out.open('xb') as handle:
        handle.write(body)
    print(json.dumps({'成功':True,'要求':{'path':str(out),'sha256':hashlib.sha256(body).hexdigest()}},ensure_ascii=False))


if __name__=='__main__':
    main()
