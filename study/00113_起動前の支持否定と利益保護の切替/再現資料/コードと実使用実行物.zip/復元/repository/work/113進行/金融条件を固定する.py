"""停止済み113の実宣言を変更せず、最初の金融条件を固定する。"""
import hashlib
import json
from pathlib import Path


def verified(path: Path, expected: str) -> dict:
    """期待指紋でJSON参照を認証する。

    引数: path(Path)、expected(str)は対象とSHA256。
    返り値: dictは復元したJSON。
    """
    raw=path.read_bytes()
    assert hashlib.sha256(raw).hexdigest()==expected,path
    return json.loads(raw.decode('utf-8-sig'))


def main() -> None:
    """宣言・全コード・実行物とOHLC根拠を認証して新規条件へ保存する。

    引数: なし。
    返り値: None。原板・旧Nativeの本文や指紋は読まず、金融計算も行わない。
    """
    root=Path(__file__).resolve().parents[2]
    p=root/'work/113利益起動水準と構造失効の連続比較/条件の素材.json'
    d=verified(p,'7ae4d589707511a39aa3adb7a0abb13f7fdebbb15c03149a8a9d641d167fbb9d')
    assert d['trial']==113 and not d['fixed'] and len(d['actual_configurations'])==24
    stop=verified(Path(d['runtime_stop']['path']),'dfd84dc9153abc5f80659a4604f677227ab58e27f64ef3df5ee3407c95e609f0')
    assert stop['成功'] and stop['停止'] and stop['trial']==113
    for path,expected in d['code_sha256'].items():
        assert hashlib.sha256(Path(path).read_bytes()).hexdigest()==expected,path
    for r in [d['executable'],d['copy_basis'],*d['dependency_stops'].values(),d['actual_declaration'],d['pure_declaration'],d['chart_declaration'],*d['reference112'].values(),d['manifest']]:
        assert hashlib.sha256(Path(r['path']).read_bytes()).hexdigest()==r['sha256'],r['path']
    assert [r['policy'] for r in d['policy_definitions']]==['S0','W100','P100','P50','E100','E50']
    assert d['entry_grid_seconds'] is None and d['extra_opening_quiet_seconds']==0
    basis=root/'study/00113_起動前の支持否定と利益保護の切替/根拠/112保有区間OHLC/検査/調査の完了確認.json'
    verified(basis,'83d8382dc89181645a8a2cd88dbc2e87b94195b99abffce5afda671e30c0f9b3')
    d['fixed']=True
    d['research_basis']={'holding_interval_ohlc112':{'path':str(basis),'sha256':'83d8382dc89181645a8a2cd88dbc2e87b94195b99abffce5afda671e30c0f9b3'},'選択':'H50と取得時支持失効＋MACDを分離。市場結果を見る前に停止済み六政策のまま固定。','旧合格基準':'125/250先着・70%・固定時計参加率は最新指示に従い今回の合否に課さない。費用後実現損益・利益後赤字・DD・因果と品質を比較。','11月09':'価格・損益・入力指紋を未読に保つ。'}
    raw=(json.dumps(d,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    out=root/'work/113進行/F1_113金融条件.json'
    with out.open('xb') as handle:
        handle.write(raw)
    print(json.dumps({'成功':True,'条件':{'path':str(out),'sha256':hashlib.sha256(raw).hexdigest()},'全コード':len(d['code_sha256']),'比較数':24,'Raw読取':0},ensure_ascii=False))


if __name__=='__main__':
    main()
