"""112金融の同体だけを確認する別実行物を新規派生する。市場は実行しない。"""
from pathlib import Path
import hashlib
import json
import os
import re

ここ = Path(__file__).resolve().parent
根 = ここ.parents[1]
旧Actor = 根 / "work/112支持否定と広い通常幅の会計"
旧Core = 根 / "work/112支持否定と通常幅の連続比較"
高速Pure = 根 / "work/112純状態コピー高速化の試作"
接頭 = "github.com/masayoshi4649/SessionTradeExecuter/"


def 指紋(位置: Path) -> str:
    """
    機能: 認証対象のコード又はメタデータのSHA256を計算する。
    引数: 位置(Path)。返り値: strは指紋。市場本文を渡さない。
    """
    return hashlib.sha256(位置.read_bytes()).hexdigest()


def 書く(位置: Path, 本文: str) -> None:
    """
    機能: 新owned配下だけへUTF-8で新規ファイルを書く。
    引数: 位置(Path)、本文(str)。返り値: None。既存先は拒否する。
    """
    位置.parent.mkdir(parents=True, exist_ok=True)
    with 位置.open("x", encoding="utf-8", newline="\n") as f:
        f.write(本文)


def moduleを作る(元: Path, 先: Path, 名前: str, 変更: dict[str, str], 比較用: dict[str, Path]) -> None:
    """
    機能: Goの依存名を明示変更し、全replaceを新階層から正しく参照する。
    引数: 元/先(Path)、名前(str)、変更(dict)、比較用(dict)はmodule情報。
    返り値: None。金融上の定数や型フィールドは書き換えない。
    """
    本文 = (元 / "go.mod").read_text(encoding="utf-8-sig")
    for a, b in 変更.items():
        本文 = 本文.replace(接頭 + a, 接頭 + b)
    本文 = re.sub(r"^module .+$", "module " + 接頭 + 名前, 本文, count=1, flags=re.M)
    行 = []
    for s in 本文.splitlines():
        m = re.match(r"(replace \S+ => )(.+)$", s)
        if m:
            key = m[1].split()[1].removeprefix(接頭)
            if key == "profitfloor112fast":
                target = 高速Pure
            elif key == "continuousactor112fast":
                target = ここ / "actor"
            else:
                target = (元 / m[2].strip('"')).resolve()
            rel = os.path.relpath(target, 先).replace("\\", "/")
            s = m[1] + rel
        行.append(s)
    本文 = "\n".join(行) + "\n"
    for name, path in 比較用.items():
        本文 += f"\nrequire {接頭 + name} v0.0.0\nreplace {接頭 + name} => {os.path.relpath(path, 先).replace(chr(92), '/')}\n"
    書く(先 / "go.mod", 本文)
    書く(先 / "go.sum", (元 / "go.sum").read_text(encoding="utf-8-sig"))


def 実行する() -> None:
    """
    機能: 旧Actor/Coreの所有コードを認証し、新moduleだけを作成する。
    引数: なし。返り値: None。既存停止・Source・Chart・F1を変更しない。
    """
    assert not (ここ / "actor").exists() and not (ここ / "core").exists()
    結果先 = 高速Pure / "結果.json"
    assert 指紋(結果先) == "dd75dd865ff0d3f3ca5cc5d213f5720a7e90651d199f2e58a37c27df24f7ccaa"
    高速結果 = json.loads(結果先.read_text(encoding="utf-8"))
    for k, v in 高速結果["所有SHA256"].items():
        assert 指紋(Path(k)) == v, k
    入力 = []
    for 先名, 元, stopname in [("actor", 旧Actor, "Actor停止.json"), ("core", 旧Core, "停止.json")]:
        停止先 = 元 / stopname
        停止 = json.loads(停止先.read_text(encoding="utf-8-sig"))
        assert 停止["成功"] and 停止["停止"]
        for k, v in 停止["所有コードSHA256"].items():
            assert 指紋(Path(k)) == v, k
        names = ["actual.go", "actual_types.go", "actual_test.go", "continuous.go", "continuous_test.go", "legacy_comparison.go"] if 先名 == "actor" else [
            "runtime.go", "runtime_test.go", "source_fixture_test.go", "fixed.go", "fixed_test.go", "runner/parallel.go", "runner/parallel_test.go", "runner/process_windows.go", "runner/process_other.go", "cmd/run/main.go"]
        先 = ここ / 先名
        変更 = {"profitfloor112": "profitfloor112fast"}
        if 先名 == "core":
            変更.update({"continuousactor112": "continuousactor112fast", "supportcomparison112": "supportcomparison112fast"})
        各入力 = [{"path": str(停止先), "sha256": 指紋(停止先), "target": "旧停止の由来"}]
        for name in names:
            source = 元 / name
            本文 = source.read_text(encoding="utf-8-sig")
            for a, b in 変更.items():
                本文 = 本文.replace('"' + 接頭 + a + '"', '"' + 接頭 + b + '"')
                本文 = 本文.replace('"' + 接頭 + a + '/runner"', '"' + 接頭 + b + '/runner"')
            if 先名 == "core" and name == "fixed.go":
                本文 = 本文.replace('filepath.Join(base, "..", pair[0], "停止.json")', 'filepath.Join(base, "..", "..", pair[0], "停止.json")')
            if 先名 == "core" and name == "fixed_test.go":
                本文 = 本文.replace('filepath.Join(here, "../..")', 'filepath.Join(here, "../../..")')
                本文 = 本文.replace('../112支持否定と広い通常幅の会計/', '../actor/')
                本文 = 本文.replace('../112支持否定の必須確認と通常幅のみ/停止.json', '../purefast停止.json')
                本文 = 本文.replace('../112支持否定の必須確認と通常幅のみ/検査/宣言設定.json', '../purefast宣言.json')
                本文 = 本文.replace('../111連続保護のチャート公開/', '../../111連続保護のチャート公開/')
            書く(先 / name, 本文)
            各入力.append({"path": str(source), "sha256": 指紋(source), "target": name})
        比較用 = {"profitfloor112": 根 / "work/112支持否定の必須確認と通常幅のみ"}
        if 先名 == "core":
            比較用.update({"continuousactor112": 旧Actor, "supportcomparison112": 旧Core})
        moduleを作る(元, 先, "continuousactor112fast" if 先名 == "actor" else "supportcomparison112fast", 変更, 比較用)
        for name in ("go.mod", "go.sum"):
            各入力.append({"path": str(元 / name), "sha256": 指紋(元 / name), "target": name})
        書く(先 / ("Actorの派生元.json" if 先名 == "actor" else "派生の参照.json"), json.dumps({"金融版": 112, "金融条件変更": False, "性能専用": True, "入力": 各入力}, ensure_ascii=False, indent=2) + "\n")
        入力.extend(各入力)
    # ----------------------------------------
    # 元helperの検査と固定手順を新位置へ薄く移す。期待人工数と金融仕様は保持する。
    h = (旧Actor / "Actorを検査して停止する.py").read_text(encoding="utf-8-sig")
    h = h.replace("ROOT = OWN.parents[1]", "ROOT = OWN.parents[2]")
    h = h.replace(接頭 + "continuousactor112'", 接頭 + "continuousactor112fast'")
    書く(ここ / "actor/Actorを検査して停止する.py", h)
    書く(ここ / "actor/Actorを派生する.py", '"""派生元は親の準備する.pyに固定する。"""\nfrom pathlib import Path\nimport runpy\n\nif __name__ == "__main__":\n    runpy.run_path(str(Path(__file__).resolve().parents[1] / "準備する.py"), run_name="__main__")\n')
    書く(ここ / "actor/Actor_README.md", "# 112金融同体の高速コピー接続Actor\n\n元112の金融型・scope・reason・24政策を保持し、guard importだけ別名purefastへ接続する。市場未実行。Source/Chartは元のまま。旧112Actorと新codeを同じ停止と偽装せず、新停止の所有code/依存で認証する。\n")
    # ----------------------------------------
    # 実際に接続されるpurefastの宣言を、別cmdから取り出す。
    書く(ここ / "actor/cmd/puredeclaration/main.go", '''package main

import (
 "encoding/json"
 "os"
 guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor112fast"
)

// main は実際に接続する高速純APIの金融宣言を出力します。
//
// 引数: なし。返り値: ありません。市場データは使いません。
func main() {
 if err := json.NewEncoder(os.Stdout).Encode(map[string]any{"version":112,"module":"profitfloor112fast","configurations":guard.DeclaredConfigurations(),"definitions":guard.DeclaredDefinitions()}); err != nil { panic(err) }
}
''')
    # Core helperの依存SHAは新部品停止後に最小置換して保存する。
    書く(ここ / "元Core停止helper.py.txt", (旧Core / "検査して停止する.py").read_text(encoding="utf-8-sig"))
    書く(ここ / "準備の入力.json", json.dumps({"金融版": 112, "新金融試行": False, "高速pure結果": {"path": str(結果先), "sha256": 指紋(結果先)}, "入力": 入力}, ensure_ascii=False, indent=2) + "\n")


if __name__ == "__main__":
    実行する()
