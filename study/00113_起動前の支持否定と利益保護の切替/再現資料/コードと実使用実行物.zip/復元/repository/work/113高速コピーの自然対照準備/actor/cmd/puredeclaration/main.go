package main

import (
	"encoding/json"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor112fast"
	"os"
)

// main は実際に接続する高速純APIの金融宣言を出力します。
//
// 引数: なし。返り値: ありません。市場データは使いません。
func main() {
	if err := json.NewEncoder(os.Stdout).Encode(map[string]any{"version": 112, "module": "profitfloor112fast", "configurations": guard.DeclaredConfigurations(), "definitions": guard.DeclaredDefinitions()}); err != nil {
		panic(err)
	}
}
