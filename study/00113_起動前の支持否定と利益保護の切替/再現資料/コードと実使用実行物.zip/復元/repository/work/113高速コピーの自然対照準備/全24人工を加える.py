"""元の手製原行を旧112全24口座/Coreにも同時配送する人工だけを追加する。"""
from pathlib import Path


def 実行する() -> None:
    """
    機能: 新Coreの既存人工へ全24の毎原行と全Core結果の同体対照を加える。
    引数: なし。返り値: None。production関数と元112は変更しない。
    """
    p = Path(__file__).resolve().parent / "core/runtime_test.go"
    s = p.read_text(encoding="utf-8")
    assert "fullOriginal" not in s
    replacements = [
        ('"encoding/json"', '"bytes"\n "encoding/json"\n originalActor "github.com/masayoshi4649/SessionTradeExecuter/continuousactor112"\n originalCore "github.com/masayoshi4649/SessionTradeExecuter/supportcomparison112"'),
        ('legacyFull := legacyCore.New()', '''fullOriginal := originalCore.New()
 if err := fullOriginal.Begin(source.SourceCase{Session: session, Contract: "人工限月"}); err != nil { t.Fatal(err) }
 originalBooks := map[string]*originalActor.ActualBook{}
 for _, cfg := range originalActor.DeclaredContinuousConfigurations() {
  book, err := originalActor.NewContinuousBook(session, "人工限月", cfg)
  if err != nil { t.Fatal(err) }
  originalBooks[book.Snapshot().Key] = book
 }
 if len(originalBooks) != 24 { t.Fatal("旧112全24の欠落") }
 legacyFull := legacyCore.New()'''),
        ('if err := legacyFull.Step(source.NativeStep{Observation: o, SourceLine: int64(i + 1), Mini: []source.NativeBatch{batch}}); err != nil {', '''if err := fullOriginal.Step(source.NativeStep{Observation: o, SourceLine: int64(i + 1), Mini: []source.NativeBatch{batch}}); err != nil { t.Fatal(err) }
 if err := legacyFull.Step(source.NativeStep{Observation: o, SourceLine: int64(i + 1), Mini: []source.NativeBatch{batch}}); err != nil {'''),
        ('for _, event := range publication.Events {', '''for _, event := range publication.Events {
  for _, book := range originalBooks {
   if book.Snapshot().Config.Policy == "S0" { continue }
   switch event.Kind {
   case "reset":
    r := publication.Resets[event.Index]
    if err := book.ResetPublication(r.At, r.Reason); err != nil { t.Fatal(err) }
   case "observation":
    p := publication.Observations[event.Index]
    if err := book.SetPublication(p.At, 1, p.Buy); err != nil { t.Fatal(err) }
    if err := book.SetPublication(p.At, -1, p.Sell); err != nil { t.Fatal(err) }
   default: t.Fatal("旧112へ未宣言公表")
   }
  }'''),
        ('for _, book := range consumer.books {\n\t\t\tcurrent := book.Snapshot()', '''for _, book := range originalBooks {
  if err := book.OnNativeStep(o, int64(i+1), []originalActor.NativeBatch{{Method:batch.Method, Delta:batch.Delta}}); err != nil { t.Fatal(err) }
 }
 for _, book := range consumer.books {
   current := book.Snapshot()
   x, err := json.Marshal(current); if err != nil { t.Fatal(err) }
   y, err := json.Marshal(originalBooks[current.Key].Snapshot()); if err != nil { t.Fatal(err) }
   if !bytes.Equal(x,y) { t.Fatal("高速copyの旧112毎原行全JSON差", i, current.Key) }'''),
        ('if err := legacyFull.End(source.SourceEnd{Session: session, Complete: true}); err != nil {', '''if err := fullOriginal.End(source.SourceEnd{Session:session,Complete:true}); err != nil { t.Fatal(err) }
 if err := legacyFull.End(source.SourceEnd{Session: session, Complete: true}); err != nil {'''),
        ('broken := copyValue(prior)', '''originalResult, err := originalCore.ConnectResult(copyValue(origin), fullOriginal)
 if err != nil { t.Fatal(err) }
 if err = originalCore.CompareReference111Values(&originalResult, prior, source.FileRef{Path:"人工参照",SHA256:"人工"}); err != nil { t.Fatal(err) }
 x, err := json.Marshal(result); if err != nil { t.Fatal(err) }
 y, err := json.Marshal(originalResult); if err != nil { t.Fatal(err) }
 if !bytes.Equal(x,y) { t.Fatal("高速copyの旧112全CoreJSON差") }
 t.Logf("高速対照: 売買符号=%d、受理141原行×24全口座と全CoreJSON、field除外0", side)
 broken := copyValue(prior)'''),
    ]
    for a, b in replacements:
        assert s.count(a) == 1, (a, s.count(a))
        s = s.replace(a, b)
    p.write_text(s, encoding="utf-8")


if __name__ == "__main__":
    実行する()
