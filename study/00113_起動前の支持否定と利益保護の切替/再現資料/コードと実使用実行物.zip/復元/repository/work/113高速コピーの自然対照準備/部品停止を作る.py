"""高速Pureと派生Actorを実体で停止し、既存Core停止器を新参照へ移す。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess

ここ = Path(__file__).resolve().parent
根 = ここ.parents[1]
高速 = 根 / "work/112純状態コピー高速化の試作"


def 指紋(p: Path) -> str:
    """
    機能: 所有コードと小metadataのSHA256を計算する。
    引数: p(Path)。返り値: strは指紋。市場本文は対象外。
    """
    return hashlib.sha256(p.read_bytes()).hexdigest()


def ref(p: Path) -> dict:
    """
    機能: 絶対位置の認証参照を作る。
    引数: p(Path)。返り値: dictはpathとsha256。
    """
    return {"path": str(p.resolve()), "sha256": 指紋(p)}


def 新規(p: Path, value: dict) -> None:
    """
    機能: 新owned内にUTF-8のJSONを一度だけ書く。
    引数: p(Path)、value(dict)。返り値: None。既存先は拒否する。
    """
    with p.open("x", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def 実行する() -> None:
    """
    機能: 実purefast APIを宣言し、新Actor停止とCore停止器の準備を完了する。
    引数: なし。返り値: None。市場CLIと自然Nativeは実行/読取しない。
    """
    rpath = 高速 / "結果.json"
    assert 指紋(rpath) == "dd75dd865ff0d3f3ca5cc5d213f5720a7e90651d199f2e58a37c27df24f7ccaa"
    r = json.loads(rpath.read_text(encoding="utf-8"))
    for k, v in r["所有SHA256"].items():
        assert 指紋(Path(k)) == v, k
    basepath = 根 / "work/112支持否定の必須確認と通常幅のみ/停止.json"
    assert 指紋(basepath) == r["元停止SHA256"]
    base = json.loads(basepath.read_text(encoding="utf-8"))
    inherited = {**base["所有コードSHA256"], **base["再用コードSHA256"], str(basepath): 指紋(basepath)}
    for k, v in inherited.items():
        assert 指紋(Path(k)) == v, k
    env = dict(os.environ, CGO_ENABLED="0", GOWORK="off")
    command = ["go", "run", "./cmd/puredeclaration"]
    api = subprocess.run(command, cwd=ここ / "actor", env=env, capture_output=True, text=True, encoding="utf-8", check=True)
    declared = json.loads(api.stdout)
    bref = base["実宣言"]
    assert 指紋(Path(bref["path"])) == bref["sha256"]
    olddecl = json.loads(Path(bref["path"]).read_text(encoding="utf-8"))
    for key in ("version", "configurations", "definitions"):
        assert declared[key] == olddecl[key], key
    assert declared["module"] == "profitfloor112fast"
    declpath = ここ / "purefast宣言.json"
    新規(declpath, declared)
    owned = {**r["所有SHA256"], str(rpath): 指紋(rpath)}
    for p in (ここ / "actor/cmd/puredeclaration/main.go", ここ / "準備する.py", Path(__file__).resolve(), declpath):
        owned[str(p)] = 指紋(p)
    purestop = ここ / "purefast停止.json"
    新規(purestop, {"成功": True, "停止": True, "市場前": True, "trial": 112, "金融版": 112, "新金融試行": False,
                  "module": "github.com/masayoshi4649/SessionTradeExecuter/profitfloor112fast", "UTC": datetime.now(timezone.utc).isoformat(),
                  "所有コードSHA256": owned, "再用コードSHA256": inherited, "性能人工結果": ref(rpath), "実宣言": ref(declpath),
                  "金融宣言同体": True, "実APIの取得command": command, "金融条件変更": False, "市場RawNative読取": 0,
                  "根拠": "実高速codeの指紋と人工全JSON同体で停止。旧pure112停止は基礎対照の由来であり高速実体の停止へ偽装しない。"})
    actorcmd = ["python", str(ここ / "actor/Actorを検査して停止する.py"), "--pure-stop", str(purestop), "--pure-sha256", 指紋(purestop)]
    result = subprocess.run(actorcmd, cwd=根, env=env, capture_output=True, text=True, encoding="utf-8", check=True)
    actorref = json.loads(result.stdout)["停止"]
    actorstop = json.loads(Path(actorref["path"]).read_text(encoding="utf-8"))
    assert actorstop["module"].endswith("continuousactor112fast")
    # ----------------------------------------
    # 旧Coreの6依存ゲートを保ち、実体Actor/Pureの二参照と新階層だけを替える。
    s = (ここ / "元Core停止helper.py.txt").read_text(encoding="utf-8")
    s = s.replace("ROOT = HERE.parents[1]", "ROOT = HERE.parents[2]")
    s = s.replace("112支持否定と広い通常幅の会計/Actor停止.json", "113高速コピーの自然対照準備/actor/Actor停止.json")
    s = s.replace("54dc421f0c35cbd5736725955a02fb6cd11f70f3c8a7b646b954722781264006", actorref["sha256"])
    s = s.replace("112支持否定の必須確認と通常幅のみ/停止.json", "113高速コピーの自然対照準備/purefast停止.json")
    s = s.replace("b7748c29ae5c6bc44a66a112421809f888c85321652a0d9bfbb3c7f4022dd835", 指紋(purestop))
    s = s.replace("ROOT / 'work/112支持否定と広い通常幅の会計'", "ROOT / 'work/113高速コピーの自然対照準備/actor'")
    s = s.replace("ROOT / 'work/112支持否定の必須確認と通常幅のみ'", "ROOT / 'work/112純状態コピー高速化の試作'")
    s = s.replace("'検査して停止する.py')", "'検査して停止する.py', '派生の参照.json', '../準備する.py', '../全24人工を加える.py', '../部品停止を作る.py')")
    s = s.replace("inherited, deps, stops = {}, {}, {}", "inherited, deps, stops = {}, {}, {}\n    origin = json.loads((HERE / '派生の参照.json').read_text(encoding='utf-8'))\n    for item in origin['入力']:\n        merge(inherited, {item['path']: item['sha256']})")
    s = s.replace("112連続比較.exe", "112金融同体高速コピー.exe")
    with (ここ / "core/検査して停止する.py").open("x", encoding="utf-8", newline="\n") as f:
        f.write(s)
    with (ここ / "core/README.md").open("x", encoding="utf-8", newline="\n") as f:
        f.write("# 112金融同体の高速コピー実行物\n\n新金融試行ではなく、purefastのコピーだけを派生Actor/Coreへ接続する準備。金融trial/version/24政策/定義112/理由/JSON/原行順は旧112のまま。Source111/Chart111と4基礎停止は不変。新Actor/Pureの実体と閉包/親子exeを新停止で認証する。\n\n人工は旧112全24を各原行で照合し、Core全JSONも除外0で比較する。旧111の12対照も元どおり保持。自然市場・旧112Nativeは未読。Rootが別F2を固定してからmetadata/first2へ進む。現F1と正式成果は変更しない。市場条件の追加・5/15/30分新規時計の再導入なし。\n")
    print(json.dumps({"成功": True, "purefast停止": ref(purestop), "actor停止": actorref, "Core停止器": str(ここ / "core/検査して停止する.py")}, ensure_ascii=False))


if __name__ == "__main__":
    実行する()
