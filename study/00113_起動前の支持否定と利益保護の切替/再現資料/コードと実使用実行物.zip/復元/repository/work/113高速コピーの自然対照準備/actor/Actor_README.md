# 112金融同体の高速コピー接続Actor

元112の金融型・scope・reason・24政策を保持し、guard importだけ別名purefastへ接続する。市場未実行。Source/Chartは元のまま。旧112Actorと新codeを同じ停止と偽装せず、新停止の所有code/依存で認証する。
