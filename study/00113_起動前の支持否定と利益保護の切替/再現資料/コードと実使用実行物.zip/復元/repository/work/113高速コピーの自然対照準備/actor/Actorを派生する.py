"""派生元は親の準備する.pyに固定する。"""
from pathlib import Path
import runpy

if __name__ == "__main__":
    runpy.run_path(str(Path(__file__).resolve().parents[1] / "準備する.py"), run_name="__main__")
