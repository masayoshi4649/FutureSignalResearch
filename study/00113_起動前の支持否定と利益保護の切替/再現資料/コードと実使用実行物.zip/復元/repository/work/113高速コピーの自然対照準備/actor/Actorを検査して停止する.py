"""112 Actorの市場前人工・宣言・APIと旧12の同体を固定する。"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[2]
PRIOR = ROOT / 'work/111元通知の連続Actor'
PRIOR_STOP = '6503962ebb7189213a182f8801916e99503ddfa88d0a99426107f3755535cbf2'


def sha(path: Path) -> str:
    """機能: 明示コードと人工metadataの全bytes指紋を得る。

    引数: path(Path)は停止・コード・手製人工。
    返り値: strはSHA256。原板や市場Nativeを渡さない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(argv: list[str], environment: dict) -> dict:
    """機能: Actor module内で非市場Go検査だけを実行する。

    引数: argv(list[str])、environment(dict)は明示コマンドと環境。
    返り値: dictは成功時の全出力。失敗ならValueError。
    """
    process = subprocess.run(argv, cwd=OWN, env=environment, capture_output=True, text=True, encoding='utf-8', timeout=60)
    record = {'argv': argv, 'exit_code': process.returncode, 'stdout': process.stdout, 'stderr': process.stderr}
    if process.returncode != 0:
        raise ValueError(json.dumps(record, ensure_ascii=False))
    return record


def stop(pure_path: Path, pure_sha: str) -> dict:
    """機能: 純112停止認証後にtest/vet/buildと旧原本不変を固定する。

    引数: pure_path(Path)、pure_sha(str)は純112の実停止参照。
    返り値: dictはActor停止Ref。市場実行と全市場閉包固定はRoot後段。
    """
    output = OWN / 'Actor検査'
    if output.exists() or (OWN / 'Actor停止.json').exists():
        raise ValueError('Actor停止先は新規')
    if sha(pure_path) != pure_sha or sha(PRIOR / '停止.json') != PRIOR_STOP:
        raise ValueError('純112又は旧111の停止SHA差')
    pure = json.loads(pure_path.read_text(encoding='utf-8-sig'))
    if pure['成功'] is not True:
        raise ValueError('純112成功が必要')
    own_paths = sorted(OWN.glob('*.go')) + [OWN / name for name in ('go.mod', 'go.sum', 'cmd/puredeclaration/main.go', 'Actor_README.md', 'Actorの派生元.json', 'Actorを派生する.py', Path(__file__).name)]
    before = {str(path): sha(path) for path in own_paths}
    dependencies = {str(pure_path): pure_sha, str(PRIOR / '停止.json'): PRIOR_STOP}
    dependencies.update(json.loads((PRIOR / '停止.json').read_text(encoding='utf-8'))['所有コードSHA256'])
    for name in ('所有コードSHA256', '所有ファイルSHA256'):
        dependencies.update(pure.get(name, {}))
    origin = json.loads((OWN / 'Actorの派生元.json').read_text(encoding='utf-8'))
    for item in origin['入力']:
        dependencies[item['path']] = item['sha256']
    if sha(OWN / 'actual_test.go') != sha(PRIOR / 'actual_test.go'):
        raise ValueError('旧94 API人工は同bytesのまま')
    if not all(sha(Path(path)) == expected for path, expected in dependencies.items()):
        raise ValueError('Actor依存の事前指紋差')
    environment = dict(os.environ, GOWORK='off', CGO_ENABLED='0')
    environment.pop('MINIPROTECT_EXPORT_DIR', None)
    environment.pop('CONTINUOUS112_EXPORT_DIR', None)
    commands = [run(['go', 'test', '-count=1', '-json', '-cover', './...'], environment),
                run(['go', 'vet', './...'], environment), run(['go', 'build', './...'], environment)]
    output.mkdir()
    exported = run(['go', 'test', '-count=1', '-run', '^TestExportContinuous112Fixtures$', './...'],
                   dict(environment, CONTINUOUS112_EXPORT_DIR=str(output / '人工')))
    api = run(['go', 'doc', '-all', '.'], environment)
    api_path = output / 'API.txt'
    api_path.write_text(api['stdout'], encoding='utf-8', newline='\n')
    for symbol in ('func CompareLegacy111(', 'func NewContinuousBook(', 'func DeclaredContinuousConfigurations(', 'SetPublication(', 'ResetPublication('):
        if symbol not in api['stdout']:
            raise ValueError('実API宣言の欠落:' + symbol)
    events = [json.loads(line) for line in commands[0]['stdout'].splitlines() if line.startswith('{')]
    passed = [e['Test'] for e in events if e.get('Action') == 'pass' and 'Test' in e]
    if len(passed) != 11 or sum(name.startswith('TestContinuous112') for name in passed) != 5:
        raise ValueError('Actorの旧6/新5の人工件数差')
    declaration = output / '人工/宣言設定.json'
    declared = json.loads(declaration.read_text(encoding='utf-8'))
    expected = [{'policy': p, 'slip_pts': c, 'delay_seconds': d} for p in ('S0', 'W100', 'B100', 'W400', 'P100', 'P400') for c in (0, 5) for d in (0, 1)]
    if declared != expected:
        raise ValueError('112実24宣言の順序又は本名差')
    after = {path: sha(Path(path)) for path in before}
    if before != after or not all(sha(Path(path)) == expected for path, expected in dependencies.items()):
        raise ValueError('Actor所有/旧111/純112の前後差')
    artifacts = {str(path): sha(path) for path in sorted((output / '人工').glob('*.json'))}
    evidence = {'試行': 112, '成功': True, '市場前': True, 'test/vet/build': commands, '人工export': exported,
                '主人工': 5, '旧94主人工': 6, '成功test': passed, '実宣言数': 24, '人工出力SHA256': artifacts,
                '旧12対照': 'S0/W100/B100×4。各受理原行とFinishedの全金融JSON。説明Scope/監査field版名/正確な追加definitionだけを分離。',
                '所有コードSHA256前': before, '所有コードSHA256後': after, '再用コードSHA256': dependencies,
                '前後不変': True, '実市場/Raw/価格CSV/11月09日本文': False}
    proof_path = output / '人工確認.json'
    proof_path.write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    record = {'試行': 112, '成功': True, '市場前': True, '停止': True, '作成UTC': datetime.now(timezone.utc).isoformat(),
              'module': 'github.com/masayoshi4649/SessionTradeExecuter/continuousactor112fast', '所有コードSHA256': before,
              '再用コードSHA256': dependencies, '前後不変': True, '純保護停止': {'path': str(pure_path), 'sha256': pure_sha},
              '旧111停止': {'path': str(PRIOR / '停止.json'), 'sha256': PRIOR_STOP},
              '人工確認': {'path': str(proof_path), 'sha256': sha(proof_path)}, '実API': {'path': str(api_path), 'sha256': sha(api_path)},
              '実24宣言': {'path': str(declaration), 'sha256': sha(declaration)}, '人工出力SHA256': artifacts,
              '実市場/Raw/価格CSV/11月09日本文': False, '研究目標達成': False, '採用': False}
    target = OWN / 'Actor停止.json'
    target.write_text(json.dumps(record, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return {'成功': True, '停止': {'path': str(target), 'sha256': sha(target)}}


def main() -> None:
    """機能: 純112の明示停止参照を必須としてActorを停止する。

    引数: CLI pure-stop/pure-sha256(str)は停止絶対位置と期待SHA。
    返り値: None。停止Refだけを標準出力へ出す。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pure-stop', required=True, type=Path)
    parser.add_argument('--pure-sha256', required=True)
    args = parser.parse_args()
    print(json.dumps(stop(args.pure_stop.resolve(), args.pure_sha256), ensure_ascii=False))


if __name__ == '__main__':
    main()
