"""固定複合入口へ買売各十枚の数量枠を追加する比較条件を固定する。"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00168_固定複合入口を片側十枚の数量枠で再生する'


def main() -> None:
    """
    機能: 旧73場の数量診断後、数量枠の因果的な再生方法を結果前に固定する。
    引数: なし。固定二案と取得済み独立一枚の同時数診断を入力する。
    返り値: None。168条件と未実行READMEを保存する。
    """
    assert not TRIAL.exists()
    assert max(int(p.name[:5]) for p in (ROOT/'study').iterdir() if p.is_dir() and p.name[:5].isdigit())==167
    parent=ROOT/'study/00167_固定した複合入口を追加七場へ適用する/条件.json'
    previous=json.loads(parent.read_text(encoding='utf-8'))
    diag=ROOT/'work/166数量診断/同時保有の診断.json'
    setting={'trial':168,'date':'2026-11-15','name':'固定複合入口を片側十枚の数量枠で再生する',
        'hypothesis':'独立入口合算で片側十枚を超えるため、当時の保有と未決予約に基づく上限で頻度と先着・損益が保たれるかを調べる。',
        'parent':{'path':parent.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(parent.read_bytes()).hexdigest()},
        'diagnosis':{'path':diag.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(diag.read_bytes()).hexdigest()},
        'candidates':previous['candidates'],'population':['旧73場','167追加七場'],
        'capacity':{'buy_contracts':10,'sell_contracts':10,'contracts_per_request':1,'pending_reserves_capacity':True},
        'entry':'主方向・初参加補完・局所階層・枝幅・期限は固定二案から変更しない。q0で空き枠がなければその要求を棄却し、後のq0は改めて同じ技術式で判断する。',
        'clock':'q0を原行のtime/index/line順で進め、既に観測したq1/取消/TTL/決済だけを反映する。同秒決済の原行情報が数値表にない場合はその秒全体を保有継続とする保守的な枠解放。',
        'pending':'取得待ち注文も片側枠を予約し、実取得で保有へ移す。取消/失効時だけ予約解除。数量枠で要求を棄却したなら未決注文として数えない。',
        'technical_first':'165/166と同じ、開始45分以後・その場の実取得ゼロ・主要求未決なしのときだけ技術補完。取消後再試行、最初の技術補完要求から取得までは同補完を重複させない。主新規は継続する。',
        'physical_q1':'既存研究と同じ同物理q1一取得。同じq1へ複数要求が到達した場合は最初要求q0、同時主優先。重複要求を約定枚数へ水増ししない。これは実注文マッチングを再現した意味ではない。',
        'unknown':'金融未知は損益0で決済したとせず、その場末まで枠を保守的に保持する。場末の返済価格が観測不能なら全収支は未知、既知損益と別計数。',
        'exit':'各取得の対称IFDと期限返済は元候補と同じ。数量対照の中でトレーリング等の別出口を混ぜない。',
        'control':'同じ再生器の無制限枠が旧166の全q0取得・方向・枝幅・技術補完と一致することを先に確認する。さらにcap1/cap2等の人工境界、未来損益毒、売買鏡像を確認する。',
        'report':'全対象場、実取得数、数量棄却、保有/未決同時数、F/A/N/C、費用後利益損失、前後/三帯/枝別を報告。各要求一枚なので固定10枚損益へ単純乗算しない。',
        'cost':previous['cost'],'selection':'本試行ではcap10を最適化しない。無制限対照/既存主案/前半選択を入れ替えない。追加七場の結果を見て入口閾値を変更しない。'}
    TRIAL.mkdir();(TRIAL/'検査').mkdir()
    path=TRIAL/'条件.json';path.write_text(json.dumps(setting,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (TRIAL/'README.md').write_text('# 00168 固定複合入口を片側十枚の数量枠で再生する\n\n2026-11-15。[条件](条件.json)を数量制約付き再生の実行前に固定。166の独立一枚合算は主案の既知決済だけでも同時買16/売21枚だった。買売各十枚の枠を未決要求にも予約する比較を行う。現在未実行。\n',encoding='utf-8')
    print(json.dumps({'成功':True,'条件SHA256':hashlib.sha256(path.read_bytes()).hexdigest()},ensure_ascii=False))


if __name__=='__main__':
    main()
