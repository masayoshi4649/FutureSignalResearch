"""同じ数量再生器を固定した二案の追加七場へ適用する。"""
from pathlib import Path
import json
import 再生する as replay

ROOT=replay.ROOT
HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 旧73と同体確認したSourceを変更せず追加七場のcap10を評価する。
    引数: なし。167の出生・金融数値表が完成済みであることを確認する。
    返り値: None。追加七場の数量比較・全取得参照・Source停止指紋を保存する。
    """
    assert replay.sha(replay.TRIAL/'条件.json')==replay.BOOK_SHA
    assert replay.read(HERE/'旧73比較/完了.json')['成功']
    artificial=replay.read(HERE/'人工検査結果.json')
    assert artificial['成功'] and artificial['engineSHA256']==replay.sha(HERE/'engine168.py')
    setting=replay.read(replay.TRIAL/'条件.json')
    base=ROOT/'work/167追加七場の入力';proof=base/'生成の完了.json';born=ROOT/'work/167固定入口の別期間/全出生/完了.json'
    assert replay.read(born)['金融数値表未入力']
    paths=[Path(__file__),HERE/'再生する.py',HERE/'engine168.py',HERE/'人工検査結果.json',
        ROOT/'work/167固定入口の別期間/適用基盤167.py',proof,born,
        ROOT/'work/167固定入口の別期間/比較/完了.json']
    before={p.relative_to(ROOT).as_posix():replay.sha(p) for p in paths}
    replay.save(replay.TRIAL/'検査/F1_追加七場の数量再生前.json',{'成功':True,'条件SHA256':replay.BOOK_SHA,'Sourceと入力':before})
    features,captures,_=replay.BASE.load_features(base/'入口母集団')
    adapter=replay.BASE.module(ROOT/'work/166可変場の数値化/arrays166.py','arrays166_for168')
    complete=replay.read(proof);assert complete['成功']
    table=adapter.load_table(base/'自然数値表',complete['cache'])
    context=replay.BASE.GenericContext(features,table,captures)
    result=replay.run_context(context,setting['candidates'],HERE/'追加7比較')
    assert all(replay.sha(ROOT/p)==v for p,v in before.items())
    replay.save(HERE/'追加7比較/完了.json',{'成功':True,'条件SHA256':replay.BOOK_SHA,'Sourceと入力':before,
        'files':{p.name:{'bytes':p.stat().st_size,'sha256':replay.sha(p)} for p in (HERE/'追加7比較').iterdir() if p.is_file()}})
    print(json.dumps({'成功':True,'rows':[{'id':r['id'],'cap10':r['cap10']['periods']['全期'],
        '数量棄却':r['cap10']['quantity_rejected_core']+r['cap10']['quantity_rejected_technical'],
        'peak':r['cap10']['peak_reserved_total']} for r in result['rows']]},ensure_ascii=False))


if __name__=='__main__':
    main()
