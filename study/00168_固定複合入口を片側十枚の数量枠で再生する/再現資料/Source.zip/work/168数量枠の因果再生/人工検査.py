"""数量枠の境界・因果・重複物理取得・技術補完を人工確認する。"""
from pathlib import Path
import hashlib
import json
import numpy as np
import engine168 as M

HERE=Path(__file__).resolve().parent


def inputs(times: list,core: list,technical: list|None=None) -> dict:
    """
    機能: 一場の人工時計と固定方向を組み立てる。
    引数: times(list)、core(list)、technical(list|None)。
    返り値: dictは純engineの入力辞書。
    """
    n=len(times);technical=technical or [0]*n
    return {'event_keys':[(t,2*i+1,2*i+1) for i,t in enumerate(times)],
        'event_scenes':np.zeros(n,dtype=int),'scene_starts':np.array([0.]),'scene_ends':np.array([10000.]),
        'captures':[{'status':'filled','case':i,'fill_key':(t+1,2*i+2,2*i+2),'finish_key':(t+1,2*i+2,2*i+2)} for i,t in enumerate(times)],
        'core':np.array(core,dtype=np.int8),'branches':np.where(np.array(core)!=0,0,-1).astype(np.int8),
        'technical':np.array(technical,dtype=np.int8),'tiers':np.where(np.array(technical)!=0,2,0).astype(np.int8),
        'momentum_width':200,'fade_width':400,'technical_width':150,'exit_lookup':lambda case,side,width:9000.}


def sha(path: Path) -> str:
    """
    機能: 検査Sourceの物理指紋を計算する。
    引数: path(Path)。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 自然値・金融を読まず数量engineを人工確認する。
    引数: なし。
    返り値: None。成功とSource指紋を保存する。
    """
    checks=[]
    a=inputs([0,2,5,6],[1,1,1,1]);a['exit_lookup']=lambda case,side,width:5. if case==0 else 9000.
    result=M.replay(**a,capacity=1)
    assert [r['event'] for r in result['records']]==[0,3]
    assert result['audits'][0]['quantity_rejected_core']==2
    checks.append('cap1と同秒exit秒末保持・次秒再要求')
    a=inputs([0,1,2,3,4],[1,1,1,-1,-1]);result=M.replay(**a,capacity=2)
    assert [r['event'] for r in result['records']]==[0,1,3,4]
    assert result['audits'][0]['peak_reserved_total']==[2,2]
    checks.append('cap2・買売別枠・pendingも予約')
    a=inputs([0,1,11],[1,1,1]);a['captures'][0]={'status':'cancelled','finish_key':(10,90,90)}
    result=M.replay(**a,capacity=1)
    assert [r['event'] for r in result['records']]==[2] and result['audits'][0]['cancelled']==1
    checks.append('取消までpending予約・棄却は未決にせず次q0再判断')
    a=inputs([2700,2701],[0,-1],[1,0]);a['captures'][0]['fill_key']=(2705,9,9)
    result=M.replay(**a,capacity=1)
    assert [(r['event'],r['origin']) for r in result['records']]==[(0,2),(1,0)]
    checks.append('補完予約後に主が先に取得しても補完の未来取消なし')
    a=inputs([2700,2701,2703],[0,0,0],[1,1,1]);a['captures'][0]={'status':'cancelled','finish_key':(2702,4,4)}
    result=M.replay(**a,capacity=1)
    assert [r['event'] for r in result['records']]==[2] and result['audits'][0]['accepted_technical']==2
    checks.append('補完pending重複禁止と取消後再試行')
    a=inputs([2700,2701,2711],[1,0,0],[0,-1,-1]);a['captures'][0]={'status':'cancelled','finish_key':(2710,50,50)}
    result=M.replay(**a,capacity=1)
    assert [r['event'] for r in result['records']]==[2] and result['audits'][0]['technical_wait_core_pending']==1
    checks.append('主未決は反対側補完も禁止・45分等号')
    a=inputs([0,1],[1,-1]);a['captures'][1]['case']=0
    a['captures'][0]['fill_key']=a['captures'][1]['fill_key']=(3,10,10)
    result=M.replay(**a,capacity=None)
    assert len(result['records'])==1 and result['records'][0]['event']==0
    assert result['audits'][0]['alias_fills_skipped']==1
    checks.append('同物理q1は最初q0だけ・alias予約は取得到来で解除')
    a=inputs([0,2,8000],[1,1,1]);a['exit_lookup']=lambda case,side,width:None
    result=M.replay(**a,capacity=1)
    assert len(result['records'])==1 and result['audits'][0]['unknown_held_to_end']==1
    assert result['audits'][0]['peak_held']==[1,0]
    checks.append('未知exitは場末保持・0円又は時刻0決済なし')
    # ----------------------------------------
    # 金額とlabelはAPIに渡らず、出口時計の未来変更も到来前の要求へ遡及しない。
    a=inputs([0,2,5,6],[1,1,1,1]);financial={'exit':100.,'net':1,'label':1}
    a['exit_lookup']=lambda case,side,width:financial['exit']
    first=M.replay(**a,capacity=1);financial.update(net=-10**30,label=-1)
    assert M.replay(**a,capacity=1)==first
    financial['exit']=50.;second=M.replay(**a,capacity=1)
    assert first['requests']==second['requests']
    checks.append('未来損益/label毒で全結果不変、未来exit到来前の要求は不変')
    # ----------------------------------------
    rng=np.random.default_rng(168);mirrors=0
    for case in range(120):
        n=60;times=np.arange(n)*3+2700;core=rng.choice((-1,0,1),n).tolist();tech=rng.choice((-1,0,1),n).tolist()
        a=inputs(times.tolist(),core,tech)
        for i,capture in enumerate(a['captures']):
            if rng.random()<.2:a['captures'][i]={'status':'cancelled','finish_key':(times[i]+4,2*i+2,2*i+2)}
        a['exit_lookup']=lambda case,side,width:float(times[case]+20)
        capacity=(1,2,None)[case%3];first=M.replay(**a,capacity=capacity)
        mirrored={**a,'core':-a['core'],'technical':-a['technical']};other=M.replay(**mirrored,capacity=capacity)
        assert len(first['records'])==len(other['records'])
        for left,right in zip(first['records'],other['records'],strict=True):
            assert all(left[k]==right[k] for k in left if k!='side') and left['side']==1-right['side']
        assert first['audits'][0]['peak_reserved_total']==other['audits'][0]['peak_reserved_total'][::-1]
        mirrors+=n
    checks.append('120乱数場の買売鏡像・cap1/2/無制限')
    proof={'成功':True,'自然値未入力':True,'検査群':checks,'鏡像q0行数':mirrors,
        'engineSHA256':sha(HERE/'engine168.py'),'検査SourceSHA256':sha(Path(__file__))}
    (HERE/'人工検査結果.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
