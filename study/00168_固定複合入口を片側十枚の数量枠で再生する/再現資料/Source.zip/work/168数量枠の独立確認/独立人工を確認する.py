"""168数量engineを一覧走査の独立oracleと小型人工で確認する。自然7場は読まない。"""
from pathlib import Path
import ast
import copy
import hashlib
import importlib.util
import json
import math
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
AUTHOR=ROOT/'work/168数量枠の因果再生'
BOOK=ROOT/'study/00168_固定複合入口を片側十枚の数量枠で再生する/条件.json'
BOOK_SHA='b8acd5daf5050b16a0d36c74d207db8e60d77a817b6fb62964f08b416c8b1f89'


def sha(path: Path) -> str:
    """
    機能: 検査対象ファイルのSHA256を計算する。
    引数: path(Path)。
    返り値: strは物理指紋。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def fixture(times: list,core: list,technical: list|None=None) -> dict:
    """
    機能: 一場の純時計・固定方向を人工的に作る。
    引数: times(list[float])、core(list[int])、technical(list[int]|None)。
    返り値: dictは金融値を含めないengine入力。
    """
    n=len(times);technical=[0]*n if technical is None else technical
    return {'event_keys':[(float(t),i*10+1,i*10+1) for i,t in enumerate(times)],
        'event_scenes':np.zeros(n,dtype=np.int64),'scene_starts':np.array([0.]),'scene_ends':np.array([10000.]),
        'captures':[{'status':'filled','case':i,'fill_key':(float(t+1),i*10+2,i*10+2),
            'finish_key':(float(t+1),i*10+2,i*10+2)} for i,t in enumerate(times)],
        'core':np.array(core),'branches':np.where(np.array(core)==0,-1,np.arange(n)%2),
        'technical':np.array(technical),'tiers':np.where(np.array(technical)==0,0,1+np.arange(n)%2),
        'momentum_width':200,'fade_width':400,'technical_width':150,
        'exit_lookup':lambda case,side,width:9000.,'after_seconds':2700}


def oracle(data: dict,capacity: int|None) -> dict:
    """
    機能: heapを使わず全未処理イベントを毎回一覧検索する数量oracle。
    引数: data(dict)は人工入力、capacity(int|None)は片側上限。
    返り値: dictは取得・要求・ピーク。作者engineの関数は呼ばない。
    """
    records=[];requests=[];peaks=[];serial=0
    for scene,end in enumerate(data['scene_ends']):
        held=[0,0];pending=[0,0];calendar=[];waiting={};seen=set();ever=False;peak=[0,0]
        for event in np.flatnonzero(data['event_scenes']==scene).tolist()+[None]:
            now=(float(end),math.inf,math.inf) if event is None else tuple(data['event_keys'][event])
            while calendar:
                next_index=min(range(len(calendar)),key=lambda i:calendar[i][:2])
                key,order,kind,row=calendar[next_index]
                if key>now:break
                calendar.pop(next_index);side=row['side']
                if kind=='release':held[side]-=1;continue
                pending[side]-=1;waiting.pop(order)
                if kind=='cancel':continue
                if row['case'] in seen:continue
                seen.add(row['case']);held[side]+=1;ever=True
                records.append({k:row[k] for k in ('event','case','side','width','origin','tier')})
                exit_time=data['exit_lookup'](row['case'],side,row['width'])
                release=end if exit_time is None else exit_time
                serial+=1;calendar.append(((float(release),math.inf,math.inf),serial,'release',row))
            if event is None:break
            core=int(data['core'][event]);tech=int(data['technical'][event])
            if core:
                side=0 if core>0 else 1;origin=0;tier=0
                width=data['momentum_width'] if data['branches'][event]==0 else data['fade_width']
            else:
                if now[0]<data['scene_starts'][scene]+data['after_seconds'] or ever or tech==0:continue
                if any(r['origin'] in (0,2) for r in waiting.values()):continue
                side=0 if tech>0 else 1;origin=2;tier=int(data['tiers'][event]);width=data['technical_width']
            request={'event':event,'scene_index':scene,'side':side,'width':width,'origin':origin,'tier':tier,
                'at':list(now),'held_before':held[side],'pending_before':pending[side],
                'accepted':capacity is None or held[side]+pending[side]<capacity}
            requests.append(request)
            if not request['accepted']:continue
            capture=data['captures'][event];kind='fill' if capture['status']=='filled' else 'cancel'
            key=tuple(capture['fill_key'] if kind=='fill' else capture['finish_key'])
            row={**request,'case':capture['case'] if kind=='fill' else -1}
            pending[side]+=1;serial+=1;calendar.append((key,serial,kind,row));waiting[serial]=row
            peak=[max(peak[s],held[s]+pending[s]) for s in (0,1)]
        assert held==[0,0]
        peaks.append(peak)
    records.sort(key=lambda r:(r['event'],r['origin']))
    return {'records':records,'requests':requests,'peaks':peaks}


def compare(module: object,data: dict,capacity: int|None) -> dict:
    """
    機能: engineとoracleの全要求・取得・片側ピークを照合する。
    引数: module(object)、data(dict)、capacity(int|None)。
    返り値: dictは作者engineの返り値。
    """
    actual=module.replay(**data,capacity=capacity);wanted=oracle(data,capacity)
    assert actual['records']==wanted['records'],('取得',actual,wanted)
    assert actual['requests']==wanted['requests'],('要求',actual,wanted)
    assert [a['peak_reserved_total'] for a in actual['audits']]==wanted['peaks']
    return actual


def main() -> None:
    """
    機能: 独立小型境界・乱数・鏡像・未来毒とSource静的確認を実行する。
    引数: なし。条件と3Source以外の作者結果や自然入力を読まない。
    返り値: None。独立確認票だけをworkへ保存する。
    """
    assert sha(BOOK)==BOOK_SHA
    paths=[BOOK,AUTHOR/'engine168.py',AUTHOR/'人工検査.py',AUTHOR/'再生する.py']
    before={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    spec=importlib.util.spec_from_file_location('数量168独立対象',AUTHOR/'engine168.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    groups=[];examples=[]
    a=fixture([0,1,6,7],[1,1,1,1]);a['captures'][0]['fill_key']=(2.,8,8)
    a['exit_lookup']=lambda case,side,width:6. if case==0 else 9000.
    examples.append(('未決予約・同秒exitの秒末解放',a,1,[0,3]))
    a=fixture([0,1,3],[1,1,1]);a['captures'][0]={'status':'cancelled','finish_key':(2.,8,8)}
    examples.append(('取消後の枠再利用',a,1,[2]))
    a=fixture([0,1,2,3],[1,1,-1,-1]);examples.append(('買売別cap2',a,2,[0,1,2,3]))
    a=fixture([0,2,9000],[1,1,1]);a['exit_lookup']=lambda case,side,width:None
    examples.append(('金融未知は場末まで保持',a,1,[0]))
    a=fixture([2699,2700,2701],[0,0,0],[1,1,1]);examples.append(('T45分等号・保有後T禁止',a,1,[1]))
    a=fixture([2700,2701,2704],[1,0,0],[0,-1,-1]);a['captures'][0]={'status':'cancelled','finish_key':(2703.,90,90)}
    examples.append(('主未決中は反対側Tも禁止',a,1,[2]))
    a=fixture([2700,2701,2704],[0,0,0],[1,1,1]);a['captures'][0]={'status':'cancelled','finish_key':(2703.,90,90)}
    examples.append(('T未取得再試行・T未決は重複しない',a,1,[2]))
    a=fixture([2700,2701],[0,-1],[1,0]);a['captures'][0]['fill_key']=(2704.,90,90)
    examples.append(('T予約後の主取得による未来取消し禁止',a,1,[0,1]))
    a=fixture([0,1,4],[1,-1,1]);a['captures'][0]['fill_key']=(3.,90,90)
    a['captures'][1]['fill_key']=(3.,90,90);a['captures'][1]['case']=0
    examples.append(('alias同物理q1は最初q0だけ',a,None,[0,2]))
    for title,data,capacity,expected in examples:
        actual=compare(module,data,capacity);assert [r['event'] for r in actual['records']]==expected,title
        groups.append(title)
    # ----------------------------------------
    rng=np.random.default_rng(20261115168);random_rows=0;mirror_rows=0
    for sample in range(360):
        n=40;times=(2700+np.arange(n)*2).tolist();core=rng.choice((-1,0,1),n).tolist()
        technical=rng.choice((-1,0,1),n).tolist();data=fixture(times,core,technical)
        exits={}
        for i in range(0,n,2):
            key=(float(times[i+1]+rng.integers(1,15)),i*10+7,i*10+7)
            cancel=rng.random()<.2
            for j in (i,i+1):
                data['captures'][j]=({'status':'cancelled','finish_key':key} if cancel else
                    {'status':'filled','case':i,'fill_key':key,'finish_key':key})
            exits[i]=None if rng.random()<.1 else key[0]+float(rng.integers(0,25))
        data['exit_lookup']=lambda case,side,width:exits[case]
        capacity=(1,2,None)[sample%3];first=compare(module,data,capacity);random_rows+=n
        mirrored={**data,'core':-data['core'],'technical':-data['technical']}
        other=compare(module,mirrored,capacity)
        assert len(first['records'])==len(other['records'])
        for left,right in zip(first['records'],other['records'],strict=True):
            assert all(left[k]==right[k] for k in left if k!='side') and left['side']==1-right['side']
        assert first['audits'][0]['peak_reserved_total']==other['audits'][0]['peak_reserved_total'][::-1]
        mirror_rows+=n
    groups.append('360乱数場・alias/取消/未知/同秒混在をcap1/2/無制限で一覧oracle照合')
    groups.append('売買鏡像の取得と予約枠反転')
    # ----------------------------------------
    a=fixture([0,2,3,4],[1,1,-1,1]);financial={'exit':100.,'net':1,'label':1}
    a['exit_lookup']=lambda case,side,width:financial['exit']
    first=compare(module,a,1)
    for capture in a['captures']:capture.update(net=-10**40,label=-1,profit=10**50)
    financial.update(net=-10**50,label=-1);second=compare(module,a,1);assert first==second
    financial['exit']=50.;third=compare(module,a,1);assert first['requests']==third['requests']
    groups.append('未来net/label毒で全返り値不変・未来exit到来前の要求不変')
    # ----------------------------------------
    source=(AUTHOR/'再生する.py').read_text(encoding='utf-8');tree=ast.parse(source)
    lookup=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='exit_lookup')
    text=ast.get_source_segment(source,lookup)
    assert "['known']" in text and "['exit_time']" in text
    assert not any(s in text for s in ("['net']","['label']","['F']","['A']"))
    assert 'Context165()' in source and '追加7場はこのmainから開かない' in source
    assert all(sha(ROOT/name)==digest for name,digest in before.items())
    proof={'成功':True,'範囲':'数量engineの独立人工・静的QA。自然損益の再計算又は注文マッチング保証ではない。',
        '検査群':groups,'固定境界例':len(examples),'乱数q0行':random_rows,'鏡像q0行':mirror_rows,
        '独立oracle':'heapを用いない未処理一覧の逐次最小イベント走査。全要求・取得・予約ピークを照合。',
        'Sourceと条件SHA256':before,'Source前後不変':True,'新七場ファイル読取':False,
        '欠陥指摘':[],'静的見解':'出口時計だけを取得時に登録し、到来まで解放しない。net/labelは数量入口へ渡さない。',
        '検査SourceSHA256':sha(Path(__file__))}
    (HERE/'数量engineの独立人工確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':main()
