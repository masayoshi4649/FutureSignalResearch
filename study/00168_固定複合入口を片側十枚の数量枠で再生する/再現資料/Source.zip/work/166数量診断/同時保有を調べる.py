"""固定入口を独立mini一枚とした場合の同時保有数を診断する。"""
from pathlib import Path
import sys
import heapq
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'work/167固定入口の別期間'))
from 適用基盤167 import Context165,GenericContext,births,selection,read,sha
from 共通163 import save


def main() -> None:
    """
    機能: q0要求から決済まで予約した独立一枚の同時数を上下限で数える。
    引数: なし。166の固定主案と前半選択を旧73場だけで診断する。
    返り値: None。未知決済を場末まで保有した上限と既知だけの下限を保存する。
            既存入口を数量で削らず、数量制約付き口座収支とは呼ばない。
    """
    out=Path(__file__).resolve().parent/'同時保有の診断.json';assert not out.exists()
    context0=Context165();context=GenericContext(context0.features,context0.table,context0.capture_rows)
    setting=read(ROOT/'study/00167_固定した複合入口を追加七場へ適用する/条件.json');reports=[]
    for candidate in setting['candidates']:
        born=births(context.features,candidate);selected,origins,widths,tiers,audits=selection(context,born,candidate)
        hi=context.table.horizons.index(candidate['horizon']);scene_rows=[]
        for scene in range(len(context.scenes)):
            mask=context.case_scene[selected.cases]==scene
            lower=[[],[]];upper=[[],[]];max_lower=[0,0];max_upper=[0,0]
            exceeded=[]
            for index in np.flatnonzero(mask):
                case=int(selected.cases[index]);side=int(selected.sides[index]);wi=int(widths[index])
                q0=context.event_keys[selected.events[index]][0]
                # 同秒の決済原行順を数値表が持たないため、その秒はまだ保有として上限を取る。
                for heap in (*lower,*upper):
                    while heap and heap[0]<q0:heapq.heappop(heap)
                known=bool(context.arrays['known'][case,side,wi,hi])
                exit_time=float(context.arrays['exit_time'][case,side,wi,hi]) if known else context.scenes[scene]['end']-300
                heapq.heappush(upper[side],exit_time)
                if known:heapq.heappush(lower[side],exit_time)
                max_upper=[max(a,len(h)) for a,h in zip(max_upper,upper,strict=True)]
                max_lower=[max(a,len(h)) for a,h in zip(max_lower,lower,strict=True)]
                if len(upper[side])>10:exceeded.append({'event':int(selected.events[index]),'q0':q0,'side':side,'同時数上限':len(upper[side])})
            scene_rows.append({'session':context.sessions[scene],'取得':int(mask.sum()),
                '既知決済だけの同時数':max_lower,'未知を場末保有する同時数':max_upper,
                '上限10超過取得':len(exceeded),'超過先頭':exceeded[:3]})
        reports.append({'candidate':candidate['id'],'場別':scene_rows,
            '同時数下限':np.max([r['既知決済だけの同時数'] for r in scene_rows],axis=0).tolist(),
            '同時数上限':np.max([r['未知を場末保有する同時数'] for r in scene_rows],axis=0).tolist(),
            '上限10超過場':[r['session'] for r in scene_rows if r['上限10超過取得']]})
    save(out,{'成功':True,'SourceSHA256':sha(Path(__file__)),'既存条件不変':True,
        '注意':'q0から予約した取得済み一枚の同時数。取消要求の一時予約を含まない。未知があるため口座実現収支ではない。','結果':reports})
    print(__import__('json').dumps({'成功':True,'結果':[{k:v for k,v in r.items() if k!='場別'} for r in reports]},ensure_ascii=False))


if __name__=='__main__':
    main()
