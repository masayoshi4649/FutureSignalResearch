"""168の数量再生を、共有Raw/金融を複製せず正式保存する。"""
from pathlib import Path
import importlib.util
import importlib.metadata
import json
import os
import platform
import re
import sys

ROOT=Path(__file__).resolve().parents[2];HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00168_固定複合入口を片側十枚の数量枠で再生する'
WORK=ROOT/'work/168数量枠の因果再生'
BOOK_SHA='b8acd5daf5050b16a0d36c74d207db8e60d77a817b6fb62964f08b416c8b1f89'
spec=importlib.util.spec_from_file_location('formal_common168',ROOT/'work/163_164正式保存/正式保存する.py')
B=importlib.util.module_from_spec(spec);spec.loader.exec_module(B)


def settings() -> None:
    """
    機能: 汎用表版8の全567セルに実際の固定入口・数量制御の参照を記す。
    引数: なし。
    返り値: None。設定と結果.mdを保存する。
    """
    source=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md'
    body=source.read_text(encoding='utf-8').split('## 手法×時間スケール',1)[1].split('## 設定明細',1)[0]
    body=body[body.index('### 指標'):];used={}
    for scale in (3,4,5):
        used['I01',scale]='旧TのEMA21方向票'+('・局所方向票' if scale==3 else '')
        used['I08',scale]='旧TのDI差'+('・局所方向票' if scale==3 else '・MPのADX水準25以上/増分非負' if scale==4 else '')
    for scale in (3,4):
        used['I03',scale]='Hist水準/増分'+('・ATR比' if scale==3 else '')
        used['I04',scale]='RSI中心/増分' if scale==3 else '旧TのRSI増分'
    for method,scale,note in [('I01',0,'EMA8距離/ATR5'),('I05',0,'旧Tの順側BB余地を150/200ptで正規化'),
        ('I05',4,'EX0076の反対端σ<=−2、旧Tのabsσ<=1'),('I09',0,'q0距離/ATR5。ATR幅最適化は本試行対象外'),
        ('I09',3,'Hist/ATR・TR/ATR・乖離の尺度'),('P01',3,'実体正/終値位置・反対ヒゲ>=0.2'),
        ('P05',0,'q0Last−m1Close/ATR5'),('V01',1,'相対観測量>=0.5/0.75/1。rvol5未使用'),
        ('B01',0,'正常BBO、spread10/20以内・absq0gap<=1'),('C01',0,'方向/動力/量/形状/値幅の複合'),
        ('C02',0,'BB端で元側回復条件を判定し、注文側を反転して実BBO取得'),('C04',0,'DI方向とADX強度/増分を区別'),
        ('C07',0,'旧Tの5/15/30分。局所は長期未公表時のみM5へ限定'),
        ('E01',0,'PRIMARY順行200/失速400/補完200 H60、FRONT48順行250/失速400/補完150 H120。IFD_FIRST')]:used[method,scale]=note
    count=0;lines=[]
    for line in body.splitlines():
        cells=[c.strip() for c in line.split('|')[1:-1]] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch('[A-Z][0-9]{2}',cells[0]):
            count+=1
            for scale in range(9):cells[scale+2]='S168-X/Q：'+used[cells[0],scale]+'。R168' if (cells[0],scale) in used else '未使用・未検証'
            line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert count==63
    def link(match: re.Match) -> str:
        """
        機能: 教材へのリンクを試行からの相対位置へ変える。
        引数: match(re.Match)はMarkdownリンク。
        返り値: strは有効なリンク。
        """
        target=match.group(2)
        return match.group(0) if '://' in target or target.startswith('#') else '['+match.group(1)+']('+os.path.relpath((source.parent/target).resolve(),TRIAL).replace('\\','/')+')'
    body=re.sub(r'\[([^\]]+)\]\(([^)]+)\)',link,'\n'.join(lines))
    text=f'''# 168 設定と結果

2026-11-15。[汎用表版8](../../docs/議論/手法と時間スケールの汎用表_版8.md)全63×9=567セルを複写。元SHA `{B.sha(source)}`。S168は複合R168で実際に参照する条件で、個別指標の効果ではない。

## 手法×時間スケール

{body}

## 設定明細

| 設定ID | 条件・役割 | 結果参照 |
| --- | --- | --- |
| S168-MP | MP0057/58：M5Hist/ATR>=0.1・M15Hist正・M5Hist増分非負・RSI中心0..25と増分正・ADX15>=25/増分非負・量>=0.75。spread10/20 | 主順行 |
| S168-EX | EX0076：BB15σ<=−2・反対ヒゲ>=0.2・RSI中心<=5/増分正・Hist増分正・実体非負・量>=0.5・spread20。元条件成立方向を反転 | 主失速 |
| S168-T | 165旧Tの17列全既知・8票中5以上・側差1以上と方向/動力/量/乖離gate。買売同式 | 旧技術初参加 |
| S168-L | 長期増分が当時まで一度も有限でない場に限定。M5方向/動力/実体/量6票中4以上。PRIMARY180分、FRONT48 120分 | 局所初参加 |
| S168-CTRL | 開始45分以後・その場の実取得0・主未決なしの場合だけT要求。同q0主優先、取消後再試行、同物理q1一取得 | 取得 |
| S168-CAP | 買10/売10・各要求1mini。保有と未決の合計で予約枠を判定。数量棄却は注文/取得として数えない | 数量 |
| S168-CLOCK | q0/q1のtime/index/line順。既知exitは到来時のみ解放、同秒exitは秒末、未知は場末保持 | 時計 |
| S168-E | 固定二案の枝幅/期限を維持。対称IFD、Nは期限BBO清算。追加追尾なし | 利益/損失 |

入力列が存在するだけの指標は使用としない。新規モデル学習、ATR幅の最適化、トレーリング、各帯強制取得は未実施。局所可用性や数量制御は指標単独の有効性を示さない。[主結果](README.md)、[条件](条件.json)を参照。
'''
    (TRIAL/'設定と結果.md').write_text(text,encoding='utf-8')


def docs(old: dict,new: dict) -> None:
    """
    機能: 固定二案の数量前後と不確実性を4文書へ明記する。
    引数: old/new(dict)は旧73場と追加7場の正本報告。
    返り値: None。README・心理限界・設定・再現手順を保存する。
    """
    rows=[];quant=[]
    for period,report in (('旧73',old),('追加7',new)):
        for entry in report['rows']:
            for mode in ('無制限','cap10'):
                d=entry[mode]['periods']['全期']
                rows.append([period,entry['id'],mode,d['count'],f"{d['F']}/{d['A']}/{d['N']}/{d['C']}",B.format_rate(d['rate']),
                             f"{d['profit']:,}",f"{d['loss']:,}",f"{d['net']:+,}",f"{d['pf']:.3f}",f"{d['scenes']}/{d['eligible_scenes']}",f"{d['per_hour']:.3f}"])
                quant.append([period,entry['id'],mode,str(entry[mode]['peak_reserved_total']),str(entry[mode]['peak_held']),
                              str(entry[mode]['peak_pending']),entry[mode]['quantity_rejected_core'],entry[mode]['quantity_rejected_technical']])
    summary=B.table(['期間','候補','数量','取得','F/A/N/C','到達済み先着率','利益円','損失円','既知差引円','PF','参加場','回/時'],rows)
    text=f'''# 168 固定複合入口の数量枠による再生

2026-11-15。片側10枚にすると、PRIMARYの到達済み先着率は旧73場69.40%、追加7場68.97%となり、無制限入口の70%超を維持しなかった。一方、全対象場最低1取得と既知差引黒字は維持した。FRONT48は追加7場cap10で既知差引−93,239円。固定幅・入口をこの場で交換せず、[次の数量枠探索](../00169_数量枠の下で技術近傍と任意幅を再探索する/README.md)へ原因と仮説を分ける。

## 仮説・入力・条件

独立入口合算のPRIMARYは旧73で買17/売21、FRONT48は買19/売29の予約ピークがあり、片側10枚の運用とは異なっていた。保有と未決注文を片側枠へ計上し、実際に受けられる取得集合でも方向優位・利益損失・頻度が維持できるかを検証した。

[条件](条件.json)SHA `{BOOK_SHA}`。PRIMARYは166事前主案、FRONT48は166前48場固定選択。主方向・旧T・局所補完と枝幅は変更しない。PRIMARYは順行±200/失速±400/補完±200・H60、FRONT48は±250/±400/±150・H120。各要求mini1枚、買10枚/売10枚を別枠とし、両側同時保有はあり得る。

旧73場は既使用。当時35,339q0・31,642物理caseの固定母集団を使う。追加7場は167の固定入力を共用し、3,608q0・3,250物理case。q0と取得q1を区別し、候補成立や注文要求だけでは取得へ加算しない。

## 費用・先着・未知

mini100円/pt、税込片道38.5円、往復77円＋追加滑り往復1,000円（C5）。実BBOスプレッドも価格へ含む。BUY Ask/SELL Bidで取得し、反対実側BBOで清算する。数量棄却した要求へ手数料は計上しない。取得した各1枚の金額であり、全損益を10倍しない。

IFD_FIRSTは打切り前の最初の既知touchでF/A、両未到達で期限完了ならN、他C。F/(F+A)はN/Cを分母に含めない先着率で、費用後決済勝率とは別物。Nは期限BBOの費用後損益へ算入する。Cは損益0で決済したことにせず、全件収支はnull、既知分の利益・損失と差引だけを示す。金融未知の数量はその場末まで保守的に保持し、価格0の決済を生成しない。

## 結果

{summary}

表の差引は既知分のみで、各行ともCがあるため全件収支は未確定。追加7場の率や金額を見て本試行の閾値を変更していない。

## 数量と要求

{B.table(['期間','候補','数量','予約合計peak 買/売','保有peak 買/売','未決peak 買/売','主要求棄却','補完棄却'],quant)}

同秒のexitには原行indexがないため、その秒の末尾まで枠を保持する。取消/TTLで未決を解放し、実取得で保有へ移す。後の利益額を見て受理する要求を選ばない。同物理q1のaliasは最初q0だけとし、別の枚数へ水増ししない。各帯の参加や取引回数を強制しない。

## 検査・限界・再現

純engineの独立人工は固定境界9例、乱数14,400q0・鏡像14,400q0と未来損益毒を確認。自然独立確認は旧73/追加7×二候補×無制限/cap10の8再生、全3,878要求・3,445取得、全11,232統計指標を一致確認した。167の固定出生545,258セル、全26幅対照13,520指標も同じ独立票に含む。168固有の数量確認と167の確認範囲を混同しない。

これは原板を第二parserで全再走査した検証ではなく、固定特徴・生金融NPZからの再計算。実mini板、待ち行列、通信遅延、複数実注文のマッチングは未再現。無制限・cap10・前半選択を同じ「最良」へ混ぜない。幅・保有時間と数量枠の相互作用は別試行へ分ける。

[心理と限界](条件心理と限界.md)、[設定と結果](設定と結果.md)、[再現手順](再現手順.md)、[保存索引](再現資料/保存索引.json)を参照。全セッション・帯・枝・買売・要求監査は統計正本に保持し、全件のMD転記やRaw複製、xlsx生成は行わない。
'''
    (TRIAL/'README.md').write_text(text,encoding='utf-8')
    (TRIAL/'条件心理と限界.md').write_text('''# 168 数量枠と判断条件を分ける

2026-11-15。市場心理は仮説、以下の件数・損益差は固定データでの確認事実として区別する。

## 技術入口の心理仮説

MPはMACDの水準・増分、RSIの方向と過熱上限、DMI/ADXの強度、量を重ね、動力が続いている価格変化へ順行する。EX反転はBB端にある元側回復の条件へ逆らい、回復の失敗を狙う。過熱だけで反転する一般則へ置き換えない。旧Tは5/15/30分の複数方向・動力・形状・量を確認し、局所は長期指標が当時未公表の場合だけ短期の別情報集合を使う。[親166](../00166_未公表の長期指標を捏造せず局所技術で参加を補う/条件心理と原因.md)を参照。

## 数量制約で変わったもの

同じ技術状態が長く続くと、独立入口の研究では同方向の要求を重ねる。同幅IFDの決済まで保有するため、静かな場や幅の大きい枝では枠を長く使い、後続の条件成立に空きがなくなる。この仕組みは自信度とは異なり、同じ指標の反復・価格変動・期限に依存する。枚数が多いことを高い確信度とは呼ばない。

固定cap10ではPRIMARYの旧73取得738→672、先着率71.75→69.40%。追加7は159→123、76.92→68.97%。FRONT48も追加7cap10で56%・既知差引赤字となった。この比較は未参加の仮想利益を機会損失として最適化したものではなく、同じ技術条件に数量制約を適用して成立した取引を評価した。

## 次へ残す問い

幅が相場の値幅に比べて大きすぎる場合、N返済までの保有と片側枠の占有が増える可能性がある。一方、単に幅を狭めるだけでは逆先着が増え得る。入口の複合技術、順行/回復失敗の枝、値幅と期限、枠受理を同じ取得時計で検証する必要がある。次は別試行で条件を固定して比較し、この168の数字を書き換えない。

金融未知を早く決済したとして枠を解放すれば成績を都合よく変え得るため、ここでは場末まで保持する。これは観測限界に対する保守的代用であり、本当に場末価格0で決済した実績ではない。未知を含む既知差引を全収支と称さない。追加7場の少数結果を統計保証とせず、実mini板や約定遅延は別の課題として残す。
''',encoding='utf-8')
    settings()
    (TRIAL/'再現手順.md').write_text('''# 168 再現手順

2026-11-15。Python3.14.3/NumPy2.5.4/ijson3.6.0/tzdata2026.6。版・SHA・サイズ・全ZIP memberは[保存索引](再現資料/保存索引.json)。

## 正式保存

[Source.zip](再現資料/Source.zip)は168純engine/runner/人工、独立人工oracle、数量原因診断、保存/再現Sourceを元byteで保持する。[数量再生の統計正本.zip](再現資料/数量再生の統計正本.zip)は旧73/追加7の全統計・全場・取得/要求・数量監査と完了票を保持する。gzipは元圧縮byteを無圧縮ZIP格納する。

生金融とRawは[inputs/00163](../../inputs/00163_任意幅の共用価格索引/README.md)、追加7の非金融母集団/索引/生金融/出生は[inputs/00167](../../inputs/00167_追加七場の入口と共用価格索引/README.md)の一組を参照する。追加7の固定比較と自然QAは[167](../00167_固定した複合入口を追加七場へ適用する/README.md)へ参照し、Source/票を再複製しない。

## 隔離再現

元workに168比較があるcheckoutへ上書きしない。別checkoutで162〜167の必要Source.zipと168Source.zipをROOTへ展開し、正式inputs/00148/00163/00167を保持する。固定workパスに同じ実体をJunctionで結ぶ。共有入力を試行ごとにコピーしない。

```powershell
New-Item -ItemType Junction -Path 'work/163任意幅の数値化/自然数値表' -Target (Resolve-Path -LiteralPath 'inputs/00163_任意幅の共用価格索引/数値表')
New-Item -ItemType Junction -Path 'work/167追加七場の入力' -Target (Resolve-Path -LiteralPath 'inputs/00167_追加七場の入口と共用価格索引')
New-Item -ItemType Junction -Path 'work/167固定入口の別期間/全出生' -Target (Resolve-Path -LiteralPath 'inputs/00167_追加七場の入口と共用価格索引/固定二案の出生')
New-Item -ItemType Junction -Path 'work/167固定入口の別期間/比較' -Target (Resolve-Path -LiteralPath 'study/00167_固定した複合入口を追加七場へ適用する/成果物')
& 'work/複合テクニカル学習環境/Scripts/python.exe' -X utf8 'work/168正式保存/正式入力から再現する.py'
```

再現wrapperは正式148特徴を実行時接続し、162の必要数値射影だけを親正本から復元する。元Source/条件は変更せず、検査票だけ隔離先へ出し、旧73/追加7の全統計・取得JSONを正本へ照合する。保存時にwrapperのcompileだけを確認し、wrapperによる全再走査を実施したとは称さない。自然engineと全統計の独立再計算は別途済み。

## 検査範囲

168独立人工は9境界、14,400乱数q0・14,400鏡像、net/label毒と未来exit到来前不変。自然は旧73/追加7×二候補×無制限/cap10の8再生、3,878要求・3,445取得・11,232指標。全場、旧前48/後25、q0/q1三帯、4枝、買売、未知・同秒exit・未決予約・各側10上限を確認。

自然QAのSourceと票は[167の正式検査](../00167_固定した複合入口を追加七場へ適用する/検査/自然独立確認/README.md)へ保持。Source依存の165/166独立helperと168一覧oracleのSHAも同票に記録している。原板を第二parserで全面再走査した確認ではなく、mini実約定を保証しない。費用後利益/損失はknown分のみで、Cがある全件収支はnullのまま。
''',encoding='utf-8')


def main() -> None:
    """
    機能: 固定168を正式ZIP化し、全member/文書/数値/リンクを検査して停止する。
    引数: なし。168以外の正式試行とCSV/globalは変更しない。
    返り値: None。保存索引・保存確認・停止を作る。
    """
    assert B.sha(TRIAL/'条件.json')==BOOK_SHA
    data=[p for folder in ('旧73比較','追加7比較') for p in (WORK/folder).iterdir() if p.is_file()]
    source=B.source_files('work/168数量枠の因果再生')+B.source_files('work/168数量枠の独立確認')+B.source_files('work/166数量診断')
    source+=[p for p in HERE.iterdir() if p.is_file() and p.suffix=='.py']
    source+=[TRIAL/'条件.json',*(TRIAL/'検査').glob('F*.json')]
    frozen={p:B.sha(p) for p in set(data+source)}
    old=B.read(WORK/'旧73比較/二案の数量比較.json');new=B.read(WORK/'追加7比較/二案の数量比較.json')
    assert B.read(ROOT/'work/167_168自然独立確認/自然の独立確認.json')['成功']
    docs(old,new);folder=TRIAL/'再現資料';folder.mkdir(exist_ok=True)
    source_members=B.archive(folder/'Source.zip',source)
    data_members=B.archive(folder/'数量再生の統計正本.zip',data)
    refs=[ROOT/'inputs/00163_任意幅の共用価格索引/保存索引.json',ROOT/'inputs/00167_追加七場の入口と共用価格索引/保存索引.json',
          ROOT/'study/00167_固定した複合入口を追加七場へ適用する/再現資料/Source.zip',
          ROOT/'study/00167_固定した複合入口を追加七場へ適用する/検査/自然独立確認/自然の独立確認.json',
          ROOT/'study/00167_固定した複合入口を追加七場へ適用する/検査/自然独立確認/自然確認の停止.json']
    for trial in (162,163,164,165,166):
        parent=next((ROOT/'study').glob(f'{trial:05d}_*'));refs.append(parent/'再現資料/Source.zip')
    refs.append(next((ROOT/'study').glob('00162_*'))/'再現資料/出生と探索.zip')
    B.save(folder/'保存索引.json',{'成功':True,'試行':168,'条件':B.reference(TRIAL/'条件.json'),
        '実行環境':{'Python':sys.version,'NumPy':importlib.metadata.version('numpy'),'tzdata':importlib.metadata.version('tzdata'),'OS':platform.platform()},
        '正本':[{'archive':B.reference(folder/'Source.zip'),'members':source_members},
                {'archive':B.reference(folder/'数量再生の統計正本.zip'),'members':data_members}],
        '共用入力と親参照':[B.reference(p) for p in refs],
        '非重複':'148/163/167のRaw/価格索引/特徴/金融/出生を再保存しない。自然QAは167正式検査へ参照。',
        '区別':'無制限と片側10枚、旧73と追加7、事前主案と前48選択、known差引と未確定全収支を分ける。',
        '再現wrapper':'compile確認のみ。元Source不変で隔離再現し全統計取得JSONを比較するための追加Source。'})
    assert all(B.sha(path)==digest for path,digest in frozen.items())
    # ----------------------------------------
    # 正式保存の確認を新しく行い、自然QAを保存QAと呼び替えない。
    docs_paths=[TRIAL/name for name in ('README.md','条件心理と限界.md','設定と結果.md','再現手順.md')]
    links=0;rows=0
    for path in docs_paths:
        text=path.read_text(encoding='utf-8');assert '\ufffd' not in text
        for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)',text):
            if '://' in target or target.startswith('#'):continue
            assert (path.parent/target.split('#')[0]).exists(),(path.name,target);links+=1
    for line in (TRIAL/'設定と結果.md').read_text(encoding='utf-8').splitlines():
        cells=[c.strip() for c in line.split('|')[1:-1]] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch('[A-Z][0-9]{2}',cells[0]):rows+=1;assert all(c!='未設定・未検証' for c in cells[2:])
    assert rows==63
    compile((HERE/'正式入力から再現する.py').read_text(encoding='utf-8'),str(HERE/'正式入力から再現する.py'),'exec')
    B.save(TRIAL/'検査/正式保存の確認.json',{'成功':True,'保存だけの検査':True,'文書数':4,'有効リンク':links,'V8セル':rows*9,
        'ZIP数':2,'全ZIPmember数':len(source_members)+len(data_members),'全CRC_SHA_サイズ_元byte同体':True,
        '元Source_結果_条件不変':len(frozen),'自然検査とは別':True,'CSV_global変更':False,
        '文書指紋':[B.reference(path) for path in docs_paths],'保存索引':B.reference(folder/'保存索引.json')})
    B.save(TRIAL/'検査/正式保存の停止.json',{'成功':True,'試行':168,'条件SHA256':BOOK_SHA,
        '保存確認SHA256':B.sha(TRIAL/'検査/正式保存の確認.json'),'保存索引SHA256':B.sha(folder/'保存索引.json'),
        '凍結元不変':True,'Source保存SHA256':B.sha(folder/'Source.zip'),'統計正本SHA256':B.sha(folder/'数量再生の統計正本.zip')})
    print(json.dumps({'成功':True,'停止':B.reference(TRIAL/'検査/正式保存の停止.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
