"""正式入力と固定Sourceから168を隔離再現する。"""
from pathlib import Path
import importlib.util
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def load(path: Path,name: str) -> object:
    """
    機能: 指定Sourceをmain未実行で読み込む。
    引数: path(Path)、name(str)はSourceと登録名。
    返り値: objectはmodule。
    """
    spec=importlib.util.spec_from_file_location(name,path);value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value;spec.loader.exec_module(value);return value


def main() -> None:
    """
    機能: 正式148特徴と共用金融を用い、旧73/追加7の数量再生を別checkoutで再現する。
    引数: なし。
    返り値: None。Source不変と全統計/取得の正本一致を保存する。
    """
    helper=load(ROOT/'work/163_164正式保存/正式入力から再現する.py','formal_restore168')
    engine=ROOT/'work/168数量枠の因果再生';trial=ROOT/'study/00168_固定複合入口を片側十枚の数量枠で再生する'
    assert not(engine/'旧73比較').exists() and not(engine/'追加7比較').exists(),'既存結果のあるcheckoutへ上書きしない'
    assert (ROOT/'work/167追加七場の入力/自然数値表/任意幅配列.npz').exists()
    assert (ROOT/'work/167固定入口の別期間/全出生/完了.json').exists()
    assert (ROOT/'work/167固定入口の別期間/比較/完了.json').exists()
    helper.restore(helper.T162/'再現資料/出生と探索.zip',('work/162可変幅評価/自然射影/',))
    sys.path.insert(0,str(ROOT/'work/162入口探索'))
    common=helper.module(ROOT/'work/162入口探索/共通.py','共通');factory=common.data_module
    features=factory().load_feature_from_formal()
    def formal_data() -> object:
        """
        機能: 作業cacheを複製せず正式148の当時特徴を既存Sourceへ接続する。
        引数: なし。
        返り値: objectは特徴loadだけを実行時接続したdata module。
        """
        value=factory();value.load_feature_dataset=lambda:features;return value
    common.data_module=formal_data
    sys.path.insert(0,str(engine));qa=HERE/'隔離再現の検査';assert not qa.exists();qa.mkdir()
    (qa/'条件.json').write_bytes((trial/'条件.json').read_bytes())
    paths=[engine/'engine168.py',engine/'再生する.py',engine/'追加七場を再生する.py']
    before={p.relative_to(ROOT).as_posix():helper.sha(p) for p in paths}
    runner=load(engine/'再生する.py','再生する');runner.TRIAL=qa;runner.main()
    load(engine/'追加七場を再生する.py','追加168の再現').main()
    import zipfile
    with zipfile.ZipFile(trial/'再現資料/数量再生の統計正本.zip') as source:
        checked=0
        for member in source.namelist():
            if member.endswith(('二案の数量比較.json','全取得参照.json','無制限取得参照.json')):
                expected=json.loads(source.read(member));actual=json.loads((ROOT/member).read_bytes())
                assert expected==actual,member;checked+=1
    assert all(helper.sha(ROOT/path)==digest for path,digest in before.items())
    (qa/'再現確認.json').write_text(json.dumps({'成功':True,'正式統計取得JSON照合':checked,'Source不変':before,
        '特徴':features.sources,'注意':'既使用と固定追加7場の再現であり、新しい未見評価ではない。'},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'統計と取得JSON照合':checked},ensure_ascii=False))


if __name__=='__main__':
    main()
