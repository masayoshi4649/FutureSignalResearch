"""
122の許可済み成果と生成差分を金融再実行なしで正式保存する。

73場入力、Raw、Native及びexe本文は読まない。CSVのbytesを変更しない。
"""

from pathlib import Path
import gzip
import hashlib
import json
import zipfile


ROOT = Path(__file__).resolve().parent.parent
STUDY = ROOT / "study/00122_E0固定条件を全セッションで検証する"
INPUTS = ROOT / "inputs/00122_新規3場公表"
EXPECTED_RESULT = "667193822462a71e1164db81aa2bed41ac31afd96ef6b8ddc141add321482c62"
EXPECTED_NEW = "34e6f08d1b6e3fa7e9066c3de0483bec77e8f409351e2f38b5fbfa9cec4d8e01"


# ----------------------------------------
def sha(data: bytes) -> str:
    """
    機能: 読取済みバイト列をSHA256へ変換する。
    引数: data(bytes)は対象。
    返り値: str型の小文字16進指紋。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def write_same(path: Path, data: bytes) -> None:
    """
    機能: 未作成先へ保存し、既存の場合は同bytesを要求する。
    引数: path(Path)は保存先、data(bytes)は保存内容。
    返り値: None。不一致時は例外。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, path
    else:
        with path.open("xb") as handle:
            handle.write(data)


# ----------------------------------------
def json_data(value: dict) -> bytes:
    """
    機能: 日本語JSONをUTF-8へ符号化する。
    引数: value(dict)は保存対象。
    返り値: bytes型のJSON。
    """
    return (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")


# ----------------------------------------
def main() -> None:
    """
    機能: 固定結果・公表差分・検査を保存し、独立検算用の最小追補ZIPを作る。
    引数: なし。Rootが許可した成果パスを使用する。
    返り値: None。金融実行・入力全体コピー・CSV変更を行わない。
    """
    stage_a = json.loads((STUDY / "検査/StageA.json").read_text(encoding="utf-8"))
    before = {p: sha(Path(p).read_bytes()) for p in stage_a["code_sha256"]}
    assert before == stage_a["code_sha256"]
    stored = []
    jobs = [
        (ROOT / "work/122全場入口比較/全73場の入口結果.json", STUDY / "成果物/全73場の入口結果.json.gz", EXPECTED_RESULT),
        (ROOT / "work/122全場入力/新規公表.json", INPUTS / "新規公表.json.gz", EXPECTED_NEW),
        (ROOT / "work/122全場入力/既知公表照合.json", STUDY / "検査/既知公表照合.json.gz", "a96ed8d83362ec792c8599b460a4a39336576f3a9d7daccc94b9d5a835189eee"),
    ]
    for source, target, expected in jobs:
        data = source.read_bytes()
        assert sha(data) == expected
        packed = gzip.compress(data, compresslevel=9, mtime=0)
        write_same(target, packed)
        assert gzip.decompress(target.read_bytes()) == data
        assert sha(source.read_bytes()) == expected
        stored.append({"source": str(source), "path": target.relative_to(ROOT).as_posix(),
                       "SHA256": sha(packed), "bytes": len(packed), "解凍SHA256": expected, "解凍bytes": len(data)})
    pairs = [
        ("work/122全場入口比較/集計.json", "成果物/集計.json"),
        ("work/122全場入口比較/StageB.json", "検査/StageB.json"),
        ("work/122全場入口比較/全73場の完了.json", "検査/全73場の完了.json"),
        ("work/122全場入口比較/既知70対照の確認.json", "検査/既知70対照の確認.json"),
        ("work/122全場入力/旧70原板同体.json", "検査/旧70原板同体.json"),
        ("work/122全場入力/入力結合の確認.json", "検査/入力結合の確認.json"),
        ("work/122独立検算/全73場の独立検算.json", "検査/全73場の独立検算.json"),
        ("work/122独立検算/完了.json", "検査/独立検算器の完了.json"),
        ("work/122独立検算/人工準備の確認.json", "検査/独立検算器の人工準備.json"),
        ("work/122独立検算/時計の人工確認.json", "検査/独立検算器の人工時計.json"),
        ("work/122独立検算/collectorレビュー.md", "検査/公表生成の独立レビュー.md"),
        ("outputs/01a1889f-f2af-7943-a047-543275ee9ed2/122全場検証CSV/CSVの確認.json", "検査/CSVの生成確認.json"),
        ("work/122全場CSV出力/全73独立再読.json", "検査/CSVの独立再読.json"),
    ]
    for source_name, relative in pairs:
        source = ROOT / source_name
        data = source.read_bytes()
        if source_name.endswith("全73場の独立検算.json"):
            assert sha(data) == "fa14f56f9e190659c81d4eb698606b9523a5cf2a2f58e81ac930cc51598e1b78"
        target = STUDY / relative
        write_same(target, data)
        stored.append({"source": str(source), "path": target.relative_to(ROOT).as_posix(), "SHA256": sha(data), "bytes": len(data)})
    for name in ("公表生成計画.json",):
        source = ROOT / "work/122全場入力" / name
        data = source.read_bytes()
        write_same(INPUTS / name, data)
        stored.append({"source": str(source), "path": (INPUTS / name).relative_to(ROOT).as_posix(), "SHA256": sha(data), "bytes": len(data)})
    inventory = ROOT / "work/122全セッション棚卸/全セッションmetadata.json"
    data = inventory.read_bytes()
    assert sha(data) == "9830820ff2c004119e61c316f31e9eb19588b32b97289bf975c21b3873e9c057"
    write_same(STUDY / "検査/全セッションmetadata.json", data)
    stored.append({"source": str(inventory), "path": (STUDY / "検査/全セッションmetadata.json").relative_to(ROOT).as_posix(), "SHA256": sha(data), "bytes": len(data)})
    inputs_index = {"試行": 122, "成功": True, "旧入力": {"path": "work/118入口比較/入力.json", "SHA256": "574771f654937036b48c78eceadb46a4c5ff3c10265f60b0ec7879efb0d862c3", "bytes": 77606890},
                    "新規公表": stored[1], "計画": next(item for item in stored if item["path"].endswith("公表生成計画.json")),
                    "結合出力": {"path": "work/122全場入力/入力.json", "SHA256": "6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec", "bytes": 177709174},
                    "全場": 73, "旧場": 70, "新場": 3, "公表": 12794, "旧公表": 12320, "新公表": 474,
                    "保存方針": "旧118入力と新規公表差分を結合して再現。73場入力全体・Raw・exeは恒久複写しない。", "前史anchor": "2026-09-21_Day"}
    write_same(INPUTS / "指紋.json", json_data(inputs_index))
    additions = ["work/122独立検算/独立検算する.py", "work/122独立検算/人工準備を検査する.py", "work/122独立検算/人工時計.go", "work/122独立検算/README.md", "work/122独立検算/collectorレビュー.md", "work/122完了成果を保存する.py"]
    archive_path = STUDY / "再現資料/検算と保存の追補コード.zip"
    assert not archive_path.exists()
    with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in additions:
            data = (ROOT / name).read_bytes()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 10, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
    entries = []
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        for info in archive.infolist():
            data = archive.read(info.filename)
            assert data == (ROOT / info.filename).read_bytes()
            entries.append({"entry": info.filename, "restore_root": "repository", "restore_relative": info.filename, "SHA256": sha(data), "bytes": len(data), "CRC32": f"{info.CRC:08x}"})
    extra_index = {"試行": 122, "zip": {"path": archive_path.name, "SHA256": sha(archive_path.read_bytes()), "bytes": archive_path.stat().st_size}, "entries": entries,
                   "備考": "StageA固定52コードと事前122ZIPは変更せず、独立検算器・保存器だけ追補する。"}
    write_same(STUDY / "再現資料/追補コード復元索引.json", json_data(extra_index))
    assert before == {p: sha(Path(p).read_bytes()) for p in before}
    proof = {"試行": 122, "成功": True, "保存": stored, "追補コード": extra_index["zip"], "固定52コード前後不変": True,
             "73場入力本文読取": False, "Raw読取": False, "Native読取": False, "exe読取": False, "CSV変更": False, "金融再実行": False, "金融再集計": False}
    write_same(STUDY / "検査/完了成果保管の確認.json", json_data(proof))
    print(json.dumps({"成功": True, "gzip": stored[:3], "追補": extra_index["zip"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
