package main

import (
	"encoding/json"
	"os"
	"time"
)

// main は、人工の価格時計を標準Go parserだけで数値化します。
//
// 引数: なし。返り値: なし。自然データを読みません。
func main() {
	values := []string{"2026-11-09T09:00:00+09:00", "2026-11-09T09:00:00.123456789+09:00", "2026-11-09T00:00:00.123456789876Z", "2026-11-09T09:00:00,123456789+09:00"}
	result := map[string]float64{}
	for _, value := range values {
		at, err := time.Parse(time.RFC3339Nano, value)
		if err != nil { panic(err) }
		result[value] = float64(at.UnixNano()) / 1e9
	}
	if err := json.NewEncoder(os.Stdout).Encode(result); err != nil { panic(err) }
}
