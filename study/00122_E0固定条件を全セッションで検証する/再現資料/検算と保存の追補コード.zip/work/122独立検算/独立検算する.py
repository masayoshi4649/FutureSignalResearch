"""
122のSHA指定3JSONだけを読み、保存証拠と全閲覧表を独立再計算する。

自然Raw・入力台帳・Native・CSVは開かない。条件の変更や市場実行は行わない。
最初の約定行・到達行だったこと、保存指標の自然Rawからの再形成は再証明しない。
"""

from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from fractions import Fraction
import hashlib
import json
import math
import re
from pathlib import Path
from typing import Any

POLICIES = ["C0", "E0", "V0", "EV", "B0", "B1"]
HORIZONS = [1800, 3600]
WIDTHS = [25, 50, 100, 125, 200]
JST = timezone(timedelta(hours=9))
COUNTS: Counter = Counter()


# ----------------------------------------
def need(ok: bool, message: str) -> None:
    """
    機能: 不成立の検算条件で中止する。
    引数: ok(bool)は判定、message(str)は理由。
    返り値: None。不成立時はValueErrorを送出する。
    """
    if not ok:
        raise ValueError(message)


# ----------------------------------------
def digest(data: bytes) -> str:
    """
    機能: バイト列のSHA256を求める。
    引数: data(bytes)。返り値: str型の小文字SHA256。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def compare(saved: Any, expected: Any, where: str) -> None:
    """
    機能: 全構造を照合し、平均・率は厳密分数の1回丸めと比較する。
    引数: saved/expected(Any)、where(str)。返り値: None。
    """
    if isinstance(expected, dict):
        need(isinstance(saved, dict) and saved.keys() == expected.keys(), f"{where}: キー差")
        for key, value in expected.items():
            compare(saved[key], value, f"{where}/{key}")
    elif isinstance(expected, list):
        need(isinstance(saved, list) and len(saved) == len(expected), f"{where}: 配列長差")
        for i, value in enumerate(expected):
            compare(saved[i], value, f"{where}/{i}")
    elif isinstance(expected, Fraction):
        need(saved is not None and Decimal(saved) == Decimal(str(float(expected))), f"{where}: 厳密分数の丸め差 {saved} != {expected}")
        COUNTS["平均率中央値"] += 1
    elif isinstance(expected, float):
        need(saved is not None and Decimal(saved) == Decimal(str(expected)), f"{where}: 参考区間の浮動小数差")
        COUNTS["参考区間"] += 1
    else:
        need(saved == expected, f"{where}: 値差 {saved!r} != {expected!r}")
        COUNTS["厳密照合"] += 1


# ----------------------------------------
def bounds(session: str) -> tuple[int, int]:
    """
    機能: 場名から日中・夜間の所定境界を求める。
    引数: session(str)。返り値: tuple[int,int]型のUnix秒。
    """
    date, kind = session.rsplit("_", 1)
    need(kind in ("Day", "Night"), "対象場外")
    day = datetime.strptime(date, "%Y-%m-%d").replace(tzinfo=JST)
    start = day + (timedelta(hours=8, minutes=45) if kind == "Day" else timedelta(hours=17))
    end = day + (timedelta(hours=15, minutes=45) if kind == "Day" else timedelta(days=1, hours=6))
    return int(start.timestamp()), int(end.timestamp())


# ----------------------------------------
def price_clock(value: str) -> Decimal:
    """
    機能: RFC3339Nanoを元parserと同じUnixNano→float64秒へ変換する。
    引数: value(str)は保存された価格時計文字列。返り値: Decimal型の保存表現。
    """
    match = re.fullmatch(r'(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:[.,](\d+))?(Z|[+-]\d{2}:\d{2})', value)
    need(match is not None, 'RFC3339Nano形式差')
    base, fraction, zone = match.groups()
    seconds = int(datetime.fromisoformat(base + zone).timestamp())
    nanoseconds = seconds * 1_000_000_000 + int((fraction or '')[:9].ljust(9, '0'))
    return Decimal(str(float(nanoseconds) / 1_000_000_000))


# ----------------------------------------
def quote(q: dict, scene: dict, normal: bool = False) -> None:
    """
    機能: 保存気配の場内境界・順序範囲・必要時の正常BBOを確認する。
    引数: q/scene(dict)、normal(bool)。返り値: None。
    """
    begin, end = bounds(scene["session"])
    need(begin <= q["time"] <= end, "気配時計の場外")
    need(0 <= q["index"] < scene["quality"]["source_delivered"], "気配Index範囲外")
    need(q["index"] + 1 <= q["source_line"] <= scene["quality"]["lines"], "物理行範囲外")
    need(Decimal(q["last"]).is_finite() and q["last"] > 0, "Last不正")
    if "clock" in q:
        need(price_clock(q['clock']) == q['time'], "Clock文字列とUnix秒差")
    if normal:
        need(q["quote_ok"] is True and 0 < q["bid"] < q["ask"], "正常BBOでない")
    COUNTS["保存気配"] += 1


# ----------------------------------------
def slim(q: dict) -> dict:
    """
    機能: BBO付き気配を技術票の4項目へ射影する。
    引数: q(dict)。返り値: dict型の時刻・Index・物理行・Last。
    """
    return {key: q[key] for key in ("time", "index", "source_line", "last")}


# ----------------------------------------
def later(q: dict, old: dict, seconds: int = 0) -> bool:
    """
    機能: 原行・物理行が後で、時計が指定秒以上後かを判定する。
    引数: q/old(dict)、seconds(int)。返り値: bool。
    """
    return q["index"] > old["index"] and q["source_line"] > old["source_line"] and q["time"] >= old["time"] + seconds


# ----------------------------------------
def field_mark(q: dict, side: int, entering: bool) -> Any:
    """
    機能: 新規又は返済に使う反対気配を選ぶ。
    引数: q(dict)、side(int)、entering(bool)。返り値: 数値型のBid又はAsk。
    """
    return q["ask"] if (side == 1) == entering else q["bid"]


# ----------------------------------------
def events_check(scene: dict) -> dict[str, int]:
    """
    機能: 全1分イベント、当時参照、構造・共通ゲートと検出器診断件数を検査する。
    引数: scene(dict)。返り値: dict型のイベントIDとIndex対応。
    """
    events, prior, cooldown = {}, None, {}
    cohorts: dict[str, list[dict]] = defaultdict(list)
    contract = scene["events"][0]["scope"]["contract"] if scene["events"] else None
    gate_births = Counter()
    for i, e in enumerate(scene["events"]):
        need(e["id"] not in events and e["policy"] in POLICIES and e["side"] in (-1, 1), "イベントID/政策/方向差")
        need(e["scope"] == {"session_id": scene["session"], "contract": contract} and bool(contract), "イベントScope差")
        at, b, side = e["at"], e["bar"], e["side"]
        quote(at, scene)
        if prior:
            need(at["time"] >= prior["time"] and at["index"] >= prior["index"] and at["source_line"] >= prior["source_line"], "イベント順序逆転")
        prior = at
        need(b["end"] == b["start"] + 60 and b["end"] <= at["time"] <= b["end"] + 30 and b["rows"] > 0, "1分閉鎖時計又は行数差")
        first, last, ohlc = b["first"], b["last"], b["ohlc"]
        quote(first, scene)
        quote(last, scene)
        need(b["start"] <= first["time"] <= last["time"] < b["end"] and first["index"] <= last["index"] < at["index"] and last["source_line"] < at["source_line"], "1分の形成範囲又は因果順序差")
        need(ohlc["open"] == first["last"] and ohlc["close"] == last["last"] and 0 < ohlc["low"] < ohlc["high"] and ohlc["low"] <= ohlc["open"] <= ohlc["high"] and ohlc["low"] <= ohlc["close"] <= ohlc["high"], "1分OHLC差")
        need(len(e["refs"]) in (3, 4), "公表参照数差")
        for j, ref in enumerate(e["refs"]):
            delivery = ref["delivered"]
            need(ref["width_seconds"] in (300, 900, 1800) and ref["end"] <= delivery["time"] <= at["time"] and delivery["index"] <= at["index"] and delivery["source_line"] <= at["source_line"], "未来の公表参照")
            if j < 3:
                need(ref["width_seconds"] == (300, 900, 1800)[j] and at["time"] < ref["end"] + ref["width_seconds"] + 60, "当場主参照の鮮度又は順序差")
            else:
                need(e["policy"].startswith("P3") and ref["width_seconds"] == 900 and ref["end"] < e["refs"][1]["end"], "過去BB参照差")
            COUNTS["公表参照"] += 1
        f = e["fields"]
        need(all(isinstance(v["known"], bool) and Decimal(v["value"]).is_finite() for v in f.values()), "技法値型又は有限性差")
        for key in ("atr5", "atr1_before14", "min1_tr", "min1_range", "min1_close_position", "min1_body_signed", "maximum_risk", "risk_at_last", "hold_boundary", "hold_minimum", "hold_strict", "hold_gap_at_birth"):
            need(f[key]["known"], "必須技法が未知")
        atr5, atr1 = f["atr5"]["value"], f["atr1_before14"]["value"]
        need(atr5 > 0 and atr1 > 0 and b["tr"]["known"] and b["tr"]["value"] == f["min1_tr"]["value"] <= 2 * atr1 and b["tr"]["value"] >= ohlc["high"] - ohlc["low"], "ATR/TR又はスパイクゲート差")
        maximum = Decimal(str(min(100, .5 * float(atr5))))
        extreme = ohlc["low"] if side == 1 else ohlc["high"]
        need(e["invalidation"] == extreme - side * 5 and f["maximum_risk"]["value"] == maximum, "否定境界又は最大リスク差")
        risk = side * (at["last"] - e["invalidation"])
        need(f["risk_at_last"]["value"] == risk and 0 < risk <= maximum, "出生時リスクゲート差")
        cap = Decimal(str(float(ohlc["close"]) + side * min(10, .15 * float(atr5))))
        need(e["entry_cap"] == cap and side * (at["last"] - cap) <= 0, "出生時capゲート差")
        location = (float(ohlc["close"]) - float(ohlc["low"])) / float(ohlc["high"] - ohlc["low"]) if side == 1 else (float(ohlc["high"]) - float(ohlc["close"])) / float(ohlc["high"] - ohlc["low"])
        need(f["min1_close_position"]["value"] == Decimal(str(location)) and location >= .7 and f["min1_body_signed"]["value"] == side * (ohlc["close"] - ohlc["open"]) > 0, "1分実体・終値位置ゲート差")
        hold, minimum, strict = [f[k]["value"] for k in ("hold_boundary", "hold_minimum", "hold_strict")]
        need(strict in (0, 1) and minimum == 5 and strict == 0, "構造維持条件差")
        gap = side * (at["last"] - hold)
        need(gap == f["hold_gap_at_birth"]["value"] and (gap > 0 if strict else gap >= minimum), "出生時構造維持差")
        need(bool(e["cohort_id"]), "基礎出生系列IDが空")
        cohorts[e["cohort_id"]].append(e)
        previous_range = e["previous5range"]
        need(previous_range["known"] and previous_range["count"] == 5 and previous_range["end"] == b["start"] and previous_range["start"] == b["start"] - 300 and 0 < previous_range["low"] <= previous_range["high"], "直前5本領域の範囲差")
        broken = previous_range["low"] if side == 1 else previous_range["high"]
        need(hold == broken and side * (extreme - broken) < 0 and side * (ohlc["close"] - broken) >= 5 and previous_range["low"] <= ohlc["close"] <= previous_range["high"], "1分の一時突破・5pt内回復差")
        adx, previous_adx, rvol, rsi15 = [f[k] for k in ("adx30", "previous_adx30", "rvol5", "rsi15")]
        falling = adx["known"] and previous_adx["known"] and adx["value"] < previous_adx["value"]
        volume = rvol["known"] and rvol["value"] >= 1
        hist, old_hist, rsi, old_rsi = [f[k] for k in ("hist5", "previous_hist5", "rsi5", "previous_rsi5")]
        momentum = hist["known"] and old_hist["known"] and rsi["known"] and old_rsi["known"] and side * (hist["value"] - old_hist["value"]) > 0 and side * (rsi["value"] - old_rsi["value"]) > 0
        strict_band = f["bb15_lower"] if side == 1 else f["bb15_upper"]
        tight_zone = strict_band["known"] and rsi15["known"] and side * (extreme - strict_band["value"]) <= 0 and side * (rsi15["value"] - 50) <= -15
        broad_zone = f["bb15_mean"]["known"] and rsi15["known"] and side * (extreme - f["bb15_mean"]["value"]) <= 0 and side * (rsi15["value"] - 50) <= 0
        tight_background = adx["known"] and (adx["value"] <= 25 or falling)
        expected = {"C0": tight_zone and tight_background, "E0": tight_zone and tight_background and falling, "V0": tight_zone and tight_background and volume, "EV": tight_zone and tight_background and falling and volume, "B1": broad_zone and falling and volume, "B0": broad_zone and falling and volume and momentum}
        need(expected[e["policy"]], "121の政策条件が保存値から成立しない")
        key = e["policy"] + "/" + str(side)
        if e["policy"] in ("C0", "B1"):
            need(key not in cooldown or at["time"] - cooldown[key] >= 300, "基礎系列5分クールダウン差")
            cooldown[key] = at["time"]
        gate_births[key] += 1
        events[e["id"]] = i
        COUNTS["イベント"] += 1
    for cohort_id, values in cohorts.items():
        by_policy = {e["policy"]: e for e in values}
        need(len(by_policy) == len(values), "同出生系列の政策重複")
        base = "C0" if "C0" in by_policy else "B1"
        need(base in by_policy, "派生だけの出生系列")
        e = by_policy[base]
        f, side = e["fields"], e["side"]
        falling = f["adx30"]["known"] and f["previous_adx30"]["known"] and f["adx30"]["value"] < f["previous_adx30"]["value"]
        volume = f["rvol5"]["known"] and f["rvol5"]["value"] >= 1
        momentum = all(f[k]["known"] for k in ("hist5", "previous_hist5", "rsi5", "previous_rsi5")) and side * (f["hist5"]["value"] - f["previous_hist5"]["value"]) > 0 and side * (f["rsi5"]["value"] - f["previous_rsi5"]["value"]) > 0
        policies = {base}
        if base == "C0":
            if falling:
                policies.add("E0")
            if volume:
                policies.add("V0")
            if falling and volume:
                policies.add("EV")
        elif momentum:
            policies.add("B0")
        need(by_policy.keys() == policies, "同出生系列の条件派生に過不足")
        for other in values:
            need(all(other[k] == e[k] for k in ("scope", "side", "at", "bar", "previous5range", "refs", "entry_cap", "invalidation")), "同出生系列の原行・構造・執行条件差")
            need(other["fields"]["cohort_base"]["known"] and other["fields"]["cohort_base"]["value"] == (0 if base == "C0" else 1), "出生系列の基礎番号差")
            need(other["fields"]["cohort_derived"]["known"] and other["fields"]["cohort_derived"]["value"] == (0 if other["policy"] == base else 1), "派生フラグ差")
        COUNTS["厳密な共有出生系列"] += 1
    stats = scene["detector_stats"]
    need(stats["raw_rows"] == scene["quality"]["source_delivered"] and stats["births"] == len(events), "検出器Raw又は出生件数差")
    need(sum(v["births"] for v in stats["policies"].values()) == len(events), "政策別出生件数差")
    considered = set()
    for key, item in stats["policies"].items():
        need(item["births"] == gate_births[key] and item["all_gates_pass"] == item["births"] + item["cooldown_rejected"], "全gate/クールダウン/出生算術差")
        need(all(0 <= item[k] <= item["considered"] for k in ("shape_pass", "risk_pass", "cap_pass", "hold_pass", "background_pass", "structure_pass", "extra_pass", "all_gates_pass", "cooldown_rejected", "births")), "独立gate件数範囲差")
        considered.add(item["considered"])
    need(len(considered) <= 1, "政策ごとの共通Considered差")
    allowed = next(iter(considered), 0)
    failures = sum(stats[k] for k in ("publication_missing", "atr1_unavailable", "atr5_unavailable", "current_tr_unavailable", "spike_rejected", "range_rejected"))
    need(stats["eligible_closures"] == failures + allowed, "共通品質ゲート分解差")
    COUNTS["検出器診断場数"] += 1
    return events


# ----------------------------------------
def candidate_check(c: dict, scene: dict, events: dict) -> None:
    """
    機能: 1分構造候補の当時参照・要求・初回評価・取得capとリスクを確認する。
    引数: c/scene/events(dict)。返り値: None。
    """
    event = scene["events"][c["event"]]
    birth, side = c["birth"], c["birth"]["side"]
    need(c["policy"] in POLICIES and c["policy"] == event["policy"] and birth["id"] == event["id"] and side == event["side"], "候補とイベント差")
    need(c["cohort_id"] == event["cohort_id"], "候補とイベントの出生系列ID差")
    need(events[event["id"]] == c["event"] and slim(birth["quote"]) == event["at"] and all(birth[k] == event["at"][k] for k in ("time", "index", "source_line")), "出生の原行差")
    quote(birth["quote"], scene)
    for key in ("entry_cap", "invalidation"):
        need(c[key] == event[key], "執行条件とイベント差")
    need(c["limit"] is None and c["atr5"] == event["fields"]["atr5"]["value"] and c["maximum_risk"] == Decimal(str(min(100, .5 * float(c["atr5"])))), "指値又は最大リスク差")
    need(c["hold_boundary"] == event["fields"]["hold_boundary"]["value"] and c["hold_minimum"] == event["fields"]["hold_minimum"]["value"] and c["hold_strict"] == (event["fields"]["hold_strict"]["value"] == 1), "構造維持条件の保存差")
    request, entry, evaluation = c["request"], c["entry"], c["evaluation"]
    need(c["expires"] <= birth["time"] + 30, "30秒を超えた新規期限")
    if c["expires"] <= birth["time"]:
        need(request is None and c["status"] == "force_close", "新規不可出生に要求")
        COUNTS["新規不可候補"] += 1
    else:
        need(request == birth["quote"], "パターン成立原行が要求でない")
    if evaluation:
        quote(evaluation, scene, True)
        need(request is not None and later(evaluation, request, 1) and evaluation["time"] < c["expires"], "初回評価の後原行1秒又は期限差")
        price = field_mark(evaluation, side, True)
        risk = side * (price - event["invalidation"])
        need(risk == c["risk_at_decision"], "保存評価リスク差")
        cap_bad = side * (price - event["entry_cap"]) > 0
        hold_gap = side * (evaluation["last"] - c["hold_boundary"])
        hold_bad = hold_gap <= 0 if c["hold_strict"] else hold_gap < c["hold_minimum"]
        risk_bad = risk <= 0 or risk > c["maximum_risk"]
        if cap_bad:
            need(c["status"] == "entry_cap_rejected" and entry is None, "cap拒否で取得又は優先順位差")
            COUNTS["cap即取消"] += 1
        elif hold_bad:
            need(c["status"] == "structure_lost" and entry is None, "構造維持崩壊で取得又は優先順位差")
            COUNTS["hold即取消"] += 1
        elif risk_bad:
            need(c["status"] == "risk_rejected" and entry is None, "リスク拒否で取得")
            COUNTS["risk即取消"] += 1
        else:
            need(c["status"] == "filled" and entry == evaluation and c["entry_price"] == price, "適格初回評価で取得しない")
    else:
        need(entry is None and c["risk_at_decision"] is None and c["status"] in ("force_close", "unfilled_expired", "eof_unfilled"), "評価証拠なしの取得又は拒否")
    need((c["status"] == "filled") == (entry is not None), "状態と取得証拠差")
    if entry is None:
        need(c["entry_price"] is None and c["outcomes"] == [], "未約定に期限損益")
        COUNTS["未約定nil"] += 1
        return
    quote(entry, scene, True)
    need([o["seconds"] for o in c["outcomes"]] == HORIZONS, "30/60期限差")
    for o in c["outcomes"]:
        need(o["deadline"] == Decimal(str(float(entry['time']) + float(o['seconds']))), "期限算術差")
        need([t["width"] for t in o["touches"]] == WIDTHS, "同幅先着の幅差")
        if o["status"] == "complete":
            end = o["endpoint"]
            quote(end, scene, True)
            need(later(end, entry) and o["deadline"] <= end["time"] <= o["deadline"] + 30, "期限評価原行又は30秒猶予差")
            gain = side * (field_mark(end, side, False) - c["entry_price"])
            need((o["points"], o["net0"], o["net5"]) == (gain, gain * 100 - 77, gain * 100 - 1077), "期限損益・費用差")
            COUNTS["完了期限算術"] += 1
        else:
            need(o["status"] in ("endpoint_missing", "eof_censored", "gap_censored", "bbo_gap_censored", "session_censored"), "観測状態不明")
            need(all(o[k] is None for k in ("endpoint", "points", "net0", "net5")), "打切り純額の補完")
            COUNTS["打切りnil"] += 1
        prior = None
        no_hit = False
        for t in o["touches"]:
            hit, direction = t["quote"], t["direction"]
            need(direction in (-1, 0, 1) and (hit is None) == (direction == 0), "方向と到達証拠差")
            if hit:
                quote(hit, scene, True)
                need(not no_hit and later(hit, entry) and hit["time"] <= o["deadline"], "小幅未到達又は取得・期限外の到達")
                need(direction * side * (field_mark(hit, side, False) - c["entry_price"]) >= t["width"], "同幅到達の幾何差")
                if prior:
                    need(hit["index"] >= prior["index"] and hit["source_line"] >= prior["source_line"] and hit["time"] >= prior["time"], "大幅先着が小幅より前")
                if o["endpoint"]:
                    need(hit["index"] <= o["endpoint"]["index"] and hit["source_line"] <= o["endpoint"]["source_line"], "評価後原行の混入")
                prior = hit
                COUNTS["先着幾何"] += 1
            else:
                no_hit = True
    short, long = c["outcomes"]
    for a, b in zip(short["touches"], long["touches"]):
        if a["direction"]:
            need(a == b, "30分先着と60分の差")
        elif b["direction"] and short["status"] == "complete" and b["quote"]["time"] <= short["deadline"]:
            need(b["quote"]["time"] == short["endpoint"]["time"] == short["deadline"] and later(b["quote"], short["endpoint"]), "短期未到達と長期先着の矛盾")
            COUNTS["期限同秒後行"] += 1
    COUNTS["取得証拠"] += 1


# ----------------------------------------
def average(values: list) -> Fraction | None:
    """
    機能: 数値列の平均を厳密分数で求める。
    引数: values(list)。返り値: Fraction|None。
    """
    return sum(map(Fraction, values), Fraction()) / len(values) if values else None


# ----------------------------------------
def middle(values: list) -> Fraction | None:
    """
    機能: 中央値を厳密分数で求める。
    引数: values(list)。返り値: Fraction|None。
    """
    if not values:
        return None
    ordered = sorted(map(Fraction, values))
    i = len(ordered) // 2
    return ordered[i] if len(ordered) % 2 else (ordered[i - 1] + ordered[i]) / 2


# ----------------------------------------
def summary(rows: list, policy: str, seconds: int, baselines: dict) -> dict:
    """
    機能: 件数・先着率・金額・同じ基礎出生系列入口対照を独立集計する。
    引数: rows(list)、policy(str)、seconds(int)、baselines(dict)。返り値: dict。
    """
    cases = [c for c in rows if c["policy"] == policy]
    entered = [c for c in cases if c["entry"]]
    observed = [(c, next(o for o in c["outcomes"] if o["seconds"] == seconds)) for c in entered]
    done = [(c, o) for c, o in observed if o["status"] == "complete"]
    totals = {}
    for width in WIDTHS:
        directions = Counter(next(t["direction"] for t in o["touches"] if t["width"] == width) for _, o in done)
        win, loss, neither = directions[1], directions[-1], directions[0]
        resolved = win + loss
        rate = Fraction(win, resolved) if resolved else None
        all_rate = Fraction(win, len(done)) if done else None
        lower = None
        if resolved:
            r = float(rate)
            z = 1.959963984540054
            lower = (r + z ** 2 / (2 * resolved) - z * math.sqrt(r * (1 - r) / resolved + z ** 2 / (4 * resolved ** 2))) / (1 + z ** 2 / resolved)
        totals[str(width)] = {"favorable": win, "adverse": loss, "neither": neither, "resolved": resolved, "resolved_rate": rate, "all_complete_favorable_rate": all_rate, "reference_binomial_lower95": lower, "target70_resolved": rate >= Fraction(7, 10) if rate is not None else None, "target70_all_complete": all_rate >= Fraction(7, 10) if all_rate is not None else None}
    pairs = []
    for c, o in done:
        base = baselines.get((c["session"], c["cohort_id"]))
        if base is None:
            continue
        original = next((x for x in base["outcomes"] if x["seconds"] == seconds and x["status"] == "complete"), None)
        if original:
            pairs.append((original["net5"], o["net5"], c["birth"]["side"] * (base["entry_price"] - c["entry_price"])))
    n0, n5 = [o["net0"] for _, o in done], [o["net5"] for _, o in done]
    return {"births": len(cases), "eligible_births": sum(c["expires"] > c["birth"]["time"] for c in cases), "requested": sum(c["request"] is not None for c in cases), "filled": len(entered), "complete": len(done), "censored": len(entered) - len(done), "filled_sessions": len({c["session"] for c in entered}), "complete_sessions": len({c["session"] for c, _ in done}), "states": dict(Counter(c["status"] for c in cases)), "observations": dict(Counter(o["status"] for _, o in observed)), "touches": totals, "mean_net0": average(n0), "mean_net5": average(n5), "median_net5": middle(n5), "positive_net5": sum(n > 0 for n in n5), "negative_net5": sum(n < 0 for n in n5), "pairs": len(pairs), "paired_base_mean_net5": average([p[0] for p in pairs]), "paired_candidate_mean_net5": average([p[1] for p in pairs]), "paired_mean_delta": average([p[1] - p[0] for p in pairs]), "paired_mean_price_improvement": average([p[2] for p in pairs])}


# ----------------------------------------
def as_jst(stamp: Any) -> str | None:
    """
    機能: 保存Unix秒を閲覧表と同じ秒単位JSTへ変換する。
    引数: stamp(数値|None)。返り値: str|None。
    """
    return datetime.fromtimestamp(float(stamp), JST).strftime("%Y-%m-%d %H:%M:%S") if stamp is not None else None


# ----------------------------------------
def label(o: dict | None, width: int) -> str:
    """
    機能: 観測状態と到達方向を日本語ラベルへ変換する。
    引数: o(dict|None)、width(int)。返り値: str。
    """
    if not o:
        return "対象外（未約定）"
    d = next(t["direction"] for t in o["touches"] if t["width"] == width)
    if o["status"] != "complete":
        return {1: "打切前順行", -1: "打切前逆行", 0: "観測不足"}[d]
    return {1: "順行先着", -1: "逆行先着", 0: "両方未到達"}[d]


# ----------------------------------------
def serial(value: Any) -> Any:
    """
    機能: 検算用分数をJSON保存用へ変換する。
    引数: value(Any)。返り値: Any。
    """
    if isinstance(value, (Fraction, Decimal)):
        return float(value)
    if isinstance(value, dict):
        return {k: serial(v) for k, v in value.items()}
    if isinstance(value, list):
        return [serial(v) for v in value]
    return value


# ----------------------------------------
def quality_check(scene: dict) -> None:
    """
    機能: 全行品質・期待品質と検出器品質分母の相互代数を確認する。
    引数: scene(dict)は保存された1場。返り値: None。入力本文は追加読取しない。
    """
    quality = scene['quality']
    keys = ('lines', 'clock_missing', 'clock_invalid', 'outside_session', 'backward_clock', 'last_non_positive', 'last_non_finite', 'bad_bbo', 'source_parser_accepted', 'cutoff_excluded', 'source_delivered')
    need(set(quality) == set(keys), '品質11項目差')
    need(all(isinstance(quality[k], int) and not isinstance(quality[k], bool) and quality[k] >= 0 for k in keys), '品質が非負整数でない')
    need(scene.get('expected_quality') is not None, '正式全場の期待品質が欠ける')
    compare(quality, scene['expected_quality'], scene['session'] + '/期待全行品質')
    rejected = sum(quality[k] for k in ('clock_missing', 'clock_invalid', 'outside_session', 'backward_clock', 'last_non_positive', 'last_non_finite'))
    need(quality['lines'] == rejected + quality['source_parser_accepted'], '原板全物理行の排他的分解差')
    need(quality['source_parser_accepted'] == quality['source_delivered'] + quality['cutoff_excluded'], '採用・配送・cutoff分解差')
    need(quality['cutoff_excluded'] == 0 and quality['bad_bbo'] <= quality['source_parser_accepted'], '入口全場走査のcutoff又はBBO分母差')
    need(scene['raw_encoding'] in ('gzip', 'plain'), '原板encoding差')
    ds = scene['detector_stats']
    need(ds.keys() == {'raw_rows', 'closed_minute_bars', 'gap_resets', 'raw_gap_resets', 'stale_closures', 'eligible_closures', 'publication_missing', 'atr1_unavailable', 'atr5_unavailable', 'current_tr_unavailable', 'spike_rejected', 'range_rejected', 'births', 'policies'}, '検出器診断キー差')
    need(all(isinstance(v, int) and not isinstance(v, bool) and v >= 0 for k, v in ds.items() if k != 'policies'), '検出器件数が非負整数でない')
    need(ds['closed_minute_bars'] == ds['stale_closures'] + ds['eligible_closures'], '閉鎖足の遅れ/評価可能分解差')
    need(ds['gap_resets'] <= ds['raw_gap_resets'] and ds['closed_minute_bars'] + ds['raw_gap_resets'] <= max(0, ds['raw_rows'] - 1), 'Raw欠測/閉鎖足の件数範囲差')
    need(set(ds['policies']) == {p + '/' + str(side) for p in POLICIES for side in (-1, 1)}, '政策side12診断キー差')
    for counts in ds['policies'].values():
        need(all(isinstance(v, int) and not isinstance(v, bool) and v >= 0 for v in counts.values()), '政策診断件数が非負整数でない')
        for gate in ('shape_pass', 'risk_pass', 'cap_pass', 'hold_pass', 'background_pass', 'structure_pass', 'extra_pass'):
            need(counts['all_gates_pass'] <= counts[gate], 'AND通過数が独立gateより大きい')
    COUNTS['全行品質分解場数'] += 1


# ----------------------------------------
def flags_check(scene: dict) -> None:
    """
    機能: 保存したBB境界・ADX増分・量/勢いの票と同出生連番を検算する。
    引数: scene(dict)。返り値: None。float差分はGoと同じ倍精度1回演算で比較する。
    """
    cohorts = {}
    for event in scene['events']:
        f, side = event['fields'], event['side']
        at, bar = event['at'], event['bar']
        extreme = bar['ohlc']['low'] if side == 1 else bar['ohlc']['high']
        for current, previous, target, sign in (('adx30', 'previous_adx30', 'adx30_delta', 1), ('hist5', 'previous_hist5', 'hist5_delta_signed', side), ('rsi5', 'previous_rsi5', 'rsi5_delta_signed', side)):
            is_known = f[current]['known'] and f[previous]['known']
            need(f[target]['known'] == is_known, '保存増分の既知性差')
            expected = Decimal(str(sign * (float(f[current]['value']) - float(f[previous]['value'])))) if is_known else Decimal(0)
            need(f[target]['value'] == expected, '保存増分の算術差')
        need(f['adx30_delta_known']['known'] and f['adx30_delta_known']['value'] == int(f['adx30_delta']['known']), 'ADX増分knownフラグ差')
        falling = f['adx30_delta']['known'] and f['adx30_delta']['value'] < 0
        momentum_known = f['hist5_delta_signed']['known'] and f['rsi5_delta_signed']['known']
        momentum = momentum_known and f['hist5_delta_signed']['value'] > 0 and f['rsi5_delta_signed']['value'] > 0
        tests = {'adx30_falling': (f['adx30_delta']['known'], falling), 'vol_ge1': (f['rvol5']['known'], f['rvol5']['known'] and f['rvol5']['value'] >= 1), 'hist5_improving': (f['hist5_delta_signed']['known'], f['hist5_delta_signed']['value'] > 0), 'rsi5_improving': (f['rsi5_delta_signed']['known'], f['rsi5_delta_signed']['value'] > 0), 'momentum_both': (momentum_known, momentum)}
        for name, (known, condition) in tests.items():
            need(f[name]['known'] == known and f[name]['value'] == int(condition), '条件票差:' + name)
        need(all(f[k]['known'] for k in ('bb15_lower', 'bb15_mean', 'bb15_upper')), '候補BB境界が未知')
        need(f['bb15_lower']['value'] <= f['bb15_mean']['value'] <= f['bb15_upper']['value'], 'BB境界順差')
        width = Decimal(str(float(f['bb15_upper']['value']) - float(f['bb15_lower']['value'])))
        need(f['bb15_width']['known'] and f['bb15_width']['value'] == width, 'BB幅の境界差')
        tight_band = f['bb15_lower' if side == 1 else 'bb15_upper']['value']
        tight = side * (extreme - tight_band) <= 0 and f['rsi15']['known'] and side * (f['rsi15']['value'] - 50) <= -15
        broad = side * (extreme - f['bb15_mean']['value']) <= 0 and f['rsi15']['known'] and side * (f['rsi15']['value'] - 50) <= 0
        for name, condition in (('tight_zone', tight), ('broad_zone', broad)):
            need(f[name]['known'] == f['rsi15']['known'] and f[name]['value'] == int(condition), '帯票差:' + name)
        for key in ('recovered_structure', 'risk_pass', 'cap_pass', 'shape_pass', 'hold_pass'):
            need(f[key]['known'] and f[key]['value'] == 1, '成立イベントの共通票差:' + key)
        seq = f['cohort_sequence']['value']
        need(f['cohort_sequence']['known'] and seq >= 1 and int(seq) == seq, '基礎出生連番差')
        need(event['id'] == f"{scene['session']}/{event['policy']}/{side}/{int(seq):06d}", '政策IDと出生連番差')
        key = event['cohort_id']
        if key in cohorts:
            need(cohorts[key] == seq, '同出生連番差')
        else:
            cohorts[key] = seq
        COUNTS['追加条件票イベント'] += 1
    need(set(cohorts.values()) == set(range(1, len(cohorts) + 1)), '基礎出生連番の欠落又は重複')


# ----------------------------------------
def tables_check122(tables: dict, rows: list, groups: dict, scenes: list) -> None:
    """
    機能: 73場の不成立とE0未取得を保持した二表の全セルを独立照合する。
    引数: tables/groups(dict)、rows/scenes(list)。返り値: None。
    """
    session_rows, detail_rows = [], []
    for index, scene in enumerate(scenes):
        name = scene['session']
        segment = '既知70場' if index < 70 else '追加3場'
        e0, c0 = (groups['session'][name][p]['3600'] for p in ('E0', 'C0'))
        diag = scene['detector_stats']
        common = diag['policies']['E0/1']['considered']
        need(common == diag['policies']['E0/-1']['considered'], '日夜一覧の共通品質分母差')
        hit = e0['touches']['100']
        if e0['births']:
            status = '成立・取得あり' if e0['filled'] else '成立・未取得'
        elif common == 0:
            status = '共通品質/履歴不足'
        elif c0['births'] == 0:
            status = '基本反転複合条件不成立'
        else:
            status = 'C0出生時ADX低下不成立/未知'
        marks = ['評価不能' if hit[k] is None else '達成' if hit[k] else '未達' for k in ('target70_resolved', 'target70_all_complete')]
        session_rows.append([122, name, segment, 'デイ' if name.endswith('_Day') else 'ナイト', common, c0['births'], e0['births'], e0['requested'], e0['filled'], e0['complete'], e0['censored'], hit['favorable'], hit['adverse'], hit['neither'], hit['resolved_rate'], hit['all_complete_favorable_rate'], *marks, status, e0['states'].get('entry_cap_rejected', 0), e0['states'].get('structure_lost', 0), e0['states'].get('risk_rejected', 0), e0['states'].get('unfilled_expired', 0), e0['states'].get('force_close', 0), diag['publication_missing'], diag['atr1_unavailable'], diag['spike_rejected']])
        for c in [c for c in rows if c['session'] == name and c['policy'] == 'E0']:
            event = scene['events'][c['event']]
            f = event['fields']
            for h in HORIZONS:
                o = next((x for x in c['outcomes'] if x['seconds'] == h), None)
                touch = next((x for x in o['touches'] if x['width'] == 100), None) if o else None
                first = touch['quote'] if touch else None
                detail_rows.append([122, name, segment, c['birth']['id'], '買' if c['birth']['side'] == 1 else '売', as_jst(c['birth']['time']), c['status'], as_jst(c['request']['time']) if c['request'] else None, as_jst(c['entry']['time']) if c['entry'] else None, c['entry_price'], h // 60, o['status'] if o else 'not_entered', as_jst(o['deadline']) if o else None, label(o, 100), as_jst(first['time']) if first else None, as_jst(o['endpoint']['time']) if o and o['endpoint'] else None, o['points'] if o else None, o['net0'] if o else None, o['net5'] if o else None, *[label(o, w) for w in WIDTHS], *[f[k]['value'] if f[k]['known'] else None for k in ('adx30', 'previous_adx30', 'rsi15', 'rvol5')], c['entry_cap'], c['invalidation'], c['atr5']])
    headers = ['試行','セッション','期間区分','日夜','共通品質通過1分数','C0基礎出生数','E0出生数','要求数','取得代用数','60分観測完了数','60分観測不足数','100pt順行先着','100pt逆行先着','100pt両方未到達','到達済み分母順行率','全観測完了分母順行率','到達済み70%','全観測完了70%','判定状況','価格cap取消数','回復構造崩壊取消数','構造距離取消数','注文期限切れ数','新規時間外数','公表不足1分数','前ATR1不足1分数','スパイク拒否1分数']
    details = ['試行','セッション','期間区分','出生ID','方向','出生JST','新規状態','要求JST','取得代用JST','取得価格','評価時間分','観測状態','評価期限JST','100pt先着','100pt初先着JST','期限評価JST','期限価格差pt','C0期限清算評価円','C5期限清算評価円','25pt先着','50pt先着','100pt先着再掲','125pt先着','200pt先着','ADX30','前ADX30','RSI15','RVOL5','新規価格cap','自然否定価格','ATR5']
    need([t['name'] for t in tables['tables']] == ['全セッション', 'E0入口明細'], '二閲覧表の順序差')
    compare(tables['tables'][0]['headers'], headers, '全セッション見出し')
    compare(tables['tables'][0]['rows'], session_rows, '全セッション全セル')
    compare(tables['tables'][1]['headers'], details, 'E0明細見出し')
    compare(tables['tables'][1]['rows'], detail_rows, 'E0明細全セル')
    need(len(session_rows) == 73 and len(detail_rows) == 2 * sum(c['policy'] == 'E0' for c in rows), '0場/未取得を落とした閲覧行数')
    COUNTS['全セッションCSV行数'] = len(session_rows)
    COUNTS['E0入口明細CSV行数'] = len(detail_rows)
    COUNTS['全セッションCSVデータセル数'] = len(session_rows) * len(headers)
    COUNTS['E0入口明細CSVデータセル数'] = len(detail_rows) * len(details)


# ----------------------------------------
def main() -> None:
    """
    機能: StageB後に許可された3JSONだけをSHA付きで再読し全保存算術を独立照合する。
    引数: CLI result/aggregate/tablesと各sha、input-sha、run-proof-sha、output。
    返り値: None。Raw/新Input/新CSVを追加読取せず新規確認JSONへ保存する。
    """
    parser = argparse.ArgumentParser()
    for kind in ('result', 'aggregate', 'tables'):
        parser.add_argument('--' + kind, required=True)
        parser.add_argument('--' + kind + '-sha', required=True)
    parser.add_argument('--input-sha', required=True)
    parser.add_argument('--run-proof-sha')
    parser.add_argument('--output', required=True)
    args = vars(parser.parse_args())
    output = Path(args['output']).absolute()
    need(not output.exists(), '確認先は未作成に限定')
    for key in ('input_sha', 'run_proof_sha'):
        if args[key] is not None:
            need(len(args[key]) == 64 and all(c in '0123456789abcdef' for c in args[key]), 'StageB/完了参照SHA形式差')
    before, values = {}, {}
    for kind in ('result', 'aggregate', 'tables'):
        path = Path(args[kind]).absolute()
        expected = args[kind + '_sha']
        need(len(expected) == 64 and all(c in '0123456789abcdef' for c in expected), 'SHA指定不正')
        data = path.read_bytes()
        need(digest(data) == expected, kind + ' SHA差')
        need(str(path) not in before, '許可ファイル重複')
        before[str(path)] = expected
        values[kind] = json.loads(data, parse_float=Decimal)
    self = Path(__file__).absolute()
    before[str(self)] = digest(self.read_bytes())
    result, saved, tables = values['result'], values['aggregate'], values['tables']
    need(result['trial'] == 122 and result['success'] and not result['source_signals_used'] and not result['portfolio_pnl'] and result['candidate_quantity'] == 1, '独立1mini範囲差')
    need(result['input_sha256'] == args['input_sha'], 'StageB固定入力SHA差')
    need(result['policies'] == POLICIES and result['horizons'] == HORIZONS and result['widths'] == WIDTHS, '固定比較条件差')
    need(saved['試行'] == tables['試行'] == 122 and saved['成功'] and tables['成功'] and saved['元結果SHA256'] == tables['result_sha256'] == args['result_sha'], '3JSON結合差')
    need(saved['口座収支'] is False and saved['IFD実約定'] is False and saved['主政策'] == 'E0' and saved['主幅pt'] == 100 and saved['主時間秒'] == 3600, 'E0主評価又は表示範囲差')
    need((saved['全場数'], saved['既知場数'], saved['追加場数']) == (73, 70, 3), '全場/区分件数差')
    scenes = result['scenes']
    names = [s['session'] for s in scenes]
    need(len(names) == result['scene_count'] == 73 and names == sorted(set(names)) and names[0] == '2026-09-21_Day' and names[69] == '2026-11-06_Night' and names[70:] == ['2026-11-09_Day', '2026-11-09_Night', '2026-11-10_Day'], '73場/既知70新3境界差')
    need(result['publication_count'] == sum(s['publications'] for s in scenes), '動的公表総数差')
    rows, event_counts = [], Counter()
    unavailable = {p: 0 for p in POLICIES}
    for index, scene in enumerate(scenes):
        need(scene['success'] and not scene['source_signals_used'] and scene['raw_passes'] == 1 and scene['raw']['sha256'] == scene['actual_sha256'] and scene['stat_before'] == scene['stat_after'], '場証拠又はRaw指紋保存差')
        quality_check(scene)
        events = events_check(scene)
        flags_check(scene)
        event_counts.update(e['policy'] for e in scene['events'])
        need(len(scene['events']) == len(scene['candidates']), '全イベント/候補数差')
        used = set()
        for c in scene['candidates']:
            need(c['event'] not in used, '同イベント候補重複')
            used.add(c['event'])
            candidate_check(c, scene, events)
            c['session'] = scene['session']
            c['history'] = '既知70場' if index < 70 else '追加3場'
            c['family'] = 'B1' if c['policy'] in ('B0', 'B1') else 'C0'
            c['mode'] = c['policy']
            c['role'] = '基礎候補' if c['policy'] in ('C0', 'B1') else '追加条件'
            c['bar_end'] = scene['events'][c['event']]['bar']['end']
            rows.append(c)
            unavailable[c['policy']] += c['expires'] <= c['birth']['time']
    need(saved['期限算術検査数'] == COUNTS['完了期限算術'], '完了期限検算件数差')
    baselines = {}
    for c in rows:
        if c['policy'] in ('C0', 'B1'):
            key = (c['session'], c['cohort_id'])
            need(key not in baselines, '基礎cohort重複')
            baselines[key] = c
    for c in rows:
        base = baselines[(c['session'], c['cohort_id'])]
        for key in ('request', 'expires', 'entry', 'entry_price', 'outcomes', 'evaluation', 'status', 'risk_at_decision', 'last_normal_time'):
            need(c[key] == base[key], '同cohort執行差:' + key)
        COUNTS['同出生系列執行同体'] += 1
    rebuilt = {p: {str(h): summary(rows, p, h, baselines) for h in HORIZONS} for p in POLICIES}
    compare(saved['集計'], rebuilt, '全6政策12期限全集計')
    groups = {}
    for kind, keys in (('side', ['-1', '1']), ('history', ['既知70場', '追加3場']), ('session', names)):
        groups[kind] = {}
        for key in keys:
            selected = [c for c in rows if str(c['birth']['side'] if kind == 'side' else c[kind]) == key]
            groups[kind][key] = {p: {str(h): summary(selected, p, h, baselines) for h in HORIZONS} for p in POLICIES}
    compare(saved['群別'], groups, '買売/既知新規/全73場全集計')
    tables_check122(tables, rows, groups, scenes)
    day_night = {kind: {str(h): summary([c for c in rows if c['session'].endswith(suffix)], 'E0', h, baselines) for h in HORIZONS} for kind, suffix in (('デイ', '_Day'), ('ナイト', '_Night'))}
    after = {path: digest(Path(path).read_bytes()) for path in before}
    need(before == after, '許可3JSON又は自身コードが検査中変化')
    proof = {'試行': 122, '成功': True, '場数': 73, '既知場数': 70, '追加場数': 3, 'E0主評価': serial(rebuilt['E0']['3600']['touches']['100']), '出生数': len(rows), 'イベント件数': dict(event_counts), '検査件数': dict(COUNTS), '候補別新規不可出生': unavailable, '集計': serial(rebuilt), 'E0日夜独立集計': serial(day_night), '不成立分類件数': dict(Counter(r[18] for r in tables['tables'][0]['rows'])), '原板encoding件数': dict(Counter(s['raw_encoding'] for s in scenes)), '入力SHA256': before, '後SHA256': after, '前後不変': True, 'StageB入力SHA参照': args['input_sha'], 'Root全73場完了証拠SHA参照': args['run_proof_sha'], '期待品質範囲': '3JSON内の全73scene.expected_qualityとactualquality全11項目同体。期待品質のInputとの結合はStageB入力SHA・Root完了証拠で別検査する。Input本文は読まない。', '数値照合': '件数・金額は完全一致。平均/率/中央値はFractionで独立再算出し倍精度1回丸め。許容差なし。参考二項下限のみ同定義の浮動小数式。', '確認範囲': ['保存全イベント/cohort/派生・当時技術票と因果/1分構造/前5range', '全候補のcap→hold→risk優先と取得/取消・未取得nil', '30/60分と全5幅の先着幾何/期限費用算術・全6政策/買売/既知70新3/73場の全率', '0候補場を含む73行とE0未取得を含む2期限全明細の全セル', '全行品質・期待品質・検出器共通分母・基礎cooldown代数'], '未証明': ['Rawを再走査せず、保存行が最初の約定/先着/期限正常行だったことや途中欠測は再証明しない', 'Input公表を追加読取せず、指標と1分OHLCの全Raw再形成は行わない', 'ForceClose原値と全限月集合の照合はRootのStageB入力と固定コード実行証拠に依存', 'CSV用二表JSONを照合したもので実CSV再読ではない。実CSV転記は別の再読器で照合', '独立1mini期限評価はIFD実約定・同時保有口座・片側10枚・利益追尾の運用実績ではない'], '自然Raw読取': 0, 'Input本文読取': 0, 'Native読取': 0, '実CSV読取': 0, '金融実行': False, '条件変更': False}
    output.parent.mkdir(parents=True, exist_ok=True)
    encoded = (json.dumps(proof, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')
    with output.open('xb') as handle:
        handle.write(encoded)
    print(json.dumps({'成功': True, '確認': str(output), 'sha256': digest(encoded), '検査件数': dict(COUNTS)}, ensure_ascii=False))


if __name__ == '__main__':
    main()


