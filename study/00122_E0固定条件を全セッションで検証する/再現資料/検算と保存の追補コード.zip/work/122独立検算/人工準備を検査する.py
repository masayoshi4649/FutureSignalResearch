"""
市場結果を使わず、0候補73場を保持する検算器と品質/空欄拒否を確認する。
"""

from __future__ import annotations

from copy import deepcopy
from datetime import date, timedelta
import hashlib
import json
from pathlib import Path
import subprocess
import sys
from typing import Any


OWN = Path(__file__).resolve().parent
FOLDER = OWN / '人工のみ'
POLICIES = ['C0', 'E0', 'V0', 'EV', 'B0', 'B1']


# ----------------------------------------
def write_json(name: str, data: Any) -> tuple[Path, str]:
    """
    機能: 人工fixtureを専用作業先へ新規保存する。
    引数: name(str)、data(Any)。返り値: tuple[Path,str]は所在とSHA。
    """
    encoded = (json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf-8')
    path = FOLDER / name
    with path.open('xb') as stream:
        stream.write(encoded)
    return path, hashlib.sha256(encoded).hexdigest()


# ----------------------------------------
def empty_summary() -> dict:
    """
    機能: 計算関数を使わず、仕様から0候補の集計値を明示する。
    引数: なし。返り値: dict型の独立fixture。
    """
    result = {key: 0 for key in ('births', 'eligible_births', 'requested', 'filled', 'complete', 'censored', 'filled_sessions', 'complete_sessions', 'positive_net5', 'negative_net5', 'pairs')}
    result.update({key: None for key in ('mean_net0', 'mean_net5', 'median_net5', 'paired_base_mean_net5', 'paired_candidate_mean_net5', 'paired_mean_delta', 'paired_mean_price_improvement')})
    result.update(states={}, observations={}, touches={})
    for width in (25, 50, 100, 125, 200):
        result['touches'][str(width)] = {'favorable': 0, 'adverse': 0, 'neither': 0, 'resolved': 0, 'resolved_rate': None, 'all_complete_favorable_rate': None, 'reference_binomial_lower95': None, 'target70_resolved': None, 'target70_all_complete': None}
    return result


# ----------------------------------------
def run_check(result: tuple[Path, str], aggregate: tuple[Path, str], tables: tuple[Path, str], name: str, success: bool) -> dict:
    """
    機能: 人工3JSONだけで検算器を起動し、成功/拒否と結果ファイル有無を検査する。
    引数: result/aggregate/tables(tuple[Path,str])、name(str)、success(bool)。返り値: dict型の実行記録。
    """
    output = FOLDER / (name + '確認.json')
    argv = [sys.executable, '-X', 'utf8', str(OWN / '独立検算する.py'), '--input-sha', 'b' * 64, '--output', str(output)]
    for kind, item in (('result', result), ('aggregate', aggregate), ('tables', tables)):
        argv.extend(['--' + kind, str(item[0]), '--' + kind + '-sha', item[1]])
    completed = subprocess.run(argv, capture_output=True, text=True, encoding='utf-8')
    assert (completed.returncode == 0) == success, completed.stdout + completed.stderr
    assert output.exists() == success
    return {'名前': name, '成功を期待': success, 'exit_code': completed.returncode, 'stdout': completed.stdout, 'stderr末尾': completed.stderr.splitlines()[-1] if completed.stderr else ''}


# ----------------------------------------
def main() -> None:
    """
    機能: 73場全0候補、欠落場、未定義率0化、期待品質差の4ケースを検査する。
    引数: なし。返り値: None。自然結果/Raw/Input/CSVは読まない。
    """
    FOLDER.mkdir(exist_ok=False)
    names = []
    current = date(2026, 9, 21)
    while current <= date(2026, 11, 6):
        if current.weekday() < 5:
            names += [current.isoformat() + '_Day', current.isoformat() + '_Night']
        current += timedelta(days=1)
    names += ['2026-11-09_Day', '2026-11-09_Night', '2026-11-10_Day']
    assert len(names) == 73
    quality = {key: 0 for key in ('lines', 'clock_missing', 'clock_invalid', 'outside_session', 'backward_clock', 'last_non_positive', 'last_non_finite', 'bad_bbo', 'source_parser_accepted', 'cutoff_excluded', 'source_delivered')}
    quality.update(lines=1, source_parser_accepted=1, source_delivered=1)
    stats = {key: 0 for key in ('raw_rows', 'closed_minute_bars', 'gap_resets', 'raw_gap_resets', 'stale_closures', 'eligible_closures', 'publication_missing', 'atr1_unavailable', 'atr5_unavailable', 'current_tr_unavailable', 'spike_rejected', 'range_rejected', 'births')}
    stats['raw_rows'] = 1
    stats['policies'] = {p + '/' + str(side): {k: 0 for k in ('considered', 'shape_pass', 'risk_pass', 'cap_pass', 'hold_pass', 'background_pass', 'structure_pass', 'extra_pass', 'all_gates_pass', 'cooldown_rejected', 'births')} for p in POLICIES for side in (-1, 1)}
    result = {'trial': 122, 'success': True, 'source_signals_used': False, 'portfolio_pnl': False, 'candidate_quantity': 1, 'input_sha256': 'b' * 64, 'policies': POLICIES, 'horizons': [1800, 3600], 'widths': [25, 50, 100, 125, 200], 'scene_count': 73, 'publication_count': 0, 'scenes': []}
    for i, name in enumerate(names):
        result['scenes'].append({'session': name, 'success': True, 'source_signals_used': False, 'raw_passes': 1, 'raw': {'path': '存在しない人工原板', 'sha256': 'a' * 64}, 'actual_sha256': 'a' * 64, 'stat_before': {'bytes': 100, 'mtime_ns': 42}, 'stat_after': {'bytes': 100, 'mtime_ns': 42}, 'raw_encoding': 'gzip' if i < 70 else 'plain', 'quality': deepcopy(quality), 'expected_quality': deepcopy(quality), 'publications': 0, 'events': [], 'candidates': [], 'detector_stats': deepcopy(stats)})
    result_ref = write_json('0候補73場結果.json', result)
    total = {p: {str(h): empty_summary() for h in (1800, 3600)} for p in POLICIES}
    aggregate = {'試行': 122, '成功': True, '元結果SHA256': result_ref[1], '口座収支': False, 'IFD実約定': False, '主政策': 'E0', '主幅pt': 100, '主時間秒': 3600, '全場数': 73, '既知場数': 70, '追加場数': 3, '期限算術検査数': 0, '集計': total, '群別': {'side': {str(s): deepcopy(total) for s in (-1, 1)}, 'history': {h: deepcopy(total) for h in ('既知70場', '追加3場')}, 'session': {n: deepcopy(total) for n in names}}}
    aggregate_ref = write_json('0候補全集計.json', aggregate)
    headers = ['試行','セッション','期間区分','日夜','共通品質通過1分数','C0基礎出生数','E0出生数','要求数','取得代用数','60分観測完了数','60分観測不足数','100pt順行先着','100pt逆行先着','100pt両方未到達','到達済み分母順行率','全観測完了分母順行率','到達済み70%','全観測完了70%','判定状況','価格cap取消数','回復構造崩壊取消数','構造距離取消数','注文期限切れ数','新規時間外数','公表不足1分数','前ATR1不足1分数','スパイク拒否1分数']
    detail_headers = ['試行','セッション','期間区分','出生ID','方向','出生JST','新規状態','要求JST','取得代用JST','取得価格','評価時間分','観測状態','評価期限JST','100pt先着','100pt初先着JST','期限評価JST','期限価格差pt','C0期限清算評価円','C5期限清算評価円','25pt先着','50pt先着','100pt先着再掲','125pt先着','200pt先着','ADX30','前ADX30','RSI15','RVOL5','新規価格cap','自然否定価格','ATR5']
    session_rows = [[122, name, '既知70場' if i < 70 else '追加3場', 'デイ' if name.endswith('_Day') else 'ナイト', *([0] * 10), None, None, '評価不能', '評価不能', '共通品質/履歴不足', *([0] * 8)] for i, name in enumerate(names)]
    assert all(len(r) == len(headers) for r in session_rows)
    tables = {'試行': 122, '成功': True, 'result_sha256': result_ref[1], 'tables': [{'name': '全セッション', 'headers': headers, 'rows': session_rows}, {'name': 'E0入口明細', 'headers': detail_headers, 'rows': []}]}
    tables_ref = write_json('0候補二表.json', tables)
    checks = [run_check(result_ref, aggregate_ref, tables_ref, '全73場保持', True)]
    missing = deepcopy(tables)
    missing['tables'][0]['rows'].pop()
    checks.append(run_check(result_ref, aggregate_ref, write_json('1場欠落二表.json', missing), '欠落拒否', False))
    zero = deepcopy(tables)
    zero['tables'][0]['rows'][0][14] = 0
    checks.append(run_check(result_ref, aggregate_ref, write_json('未定義率0二表.json', zero), '未定義率0拒否', False))
    mismatch = deepcopy(result)
    mismatch['scenes'][0]['expected_quality']['bad_bbo'] = 1
    bad_ref = write_json('期待品質差結果.json', mismatch)
    bad_aggregate, bad_tables = deepcopy(aggregate), deepcopy(tables)
    bad_aggregate['元結果SHA256'], bad_tables['result_sha256'] = bad_ref[1], bad_ref[1]
    checks.append(run_check(bad_ref, write_json('期待品質差集計.json', bad_aggregate), write_json('期待品質差二表.json', bad_tables), '期待品質差拒否', False))
    proof = {'成功': True, '人工のみ': True, 'ケース': checks, '自然Raw/Input/CSV/122結果読取': 0, 'Root集計関数利用': False}
    with (OWN / '人工準備の確認.json').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(proof, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(proof, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
