# 122全セッション検証のCSV出力

Rootが固定したJSONの`tables`二表を、値と型を照合してCSVへ転記する。表名は`全セッション`、`E0入口明細`。前者は候補0の場を含む全場、後者はE0候補の30分・60分評価を保持する。率・費用・到達判定・未成立理由は入力表のままとし、出力器では金融計算を行わない。独立1miniの期限評価を片側10枚の口座収支へ合算しない。

スキーマは`work/122全場入口比較/集計する.py`の定数ヘッダに合わせる。現在は全セッション27列、E0入口明細31列。行数は入力どおりで、並べ替えや候補0行の削除を行わない。列名・列順・値も変更しない。セルは文字列・有限数値・boolean・nullとし、安全整数範囲外は拒否する。率0.7は70%を意味し、100倍せず保存する。分母がない率は空欄となる。

Node 24.22.1、`@oai/artifact-tool` 2.8.129を固定する。`node_modules`は既存runtimeへのjunctionであり、依存自体は変更しない。xlsxは生成しない。

## Rootによる自然出力

自然の入力JSONとSHA256を固定した後、最初の作成直前にRootが`create/2/csv`の操作記録を一度実行する。二つの成果CSVが対象で、同じ操作の再試行では記録を重ねない。builderと独立再読器は記録を自動実行しない。人工データだけの試験では自然出力用の操作記録を実行しない。

```powershell
$nodeExe = 'C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
& $nodeExe 'C:/Users/masay/.codex/plugins/cache/openai-primary-runtime/spreadsheets/26.1104.22356/skills/spreadsheets/container_tools/mark_artifact_operation_started.mjs' --operation-kind create --expected-output-count 2 --output-format csv
& $nodeExe 'work/122全場CSV出力/出力する.mjs' --input 'Rootの確定表.json' --sha256 '64桁SHA256' --output 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/122全場検証CSV'
C:/Python314/python.exe -X utf8 'work/122全場CSV出力/CSVを独立再読する.py' --input 'Rootの確定表.json' --sha256 '64桁SHA256' --folder 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/122全場検証CSV' --output 'work/122全場CSV出力/全73独立再読.json'
```

出力先は未作成を要求し、既存成果へ上書きしない。CSVはUTF-8 BOM・CRLF。nullは空欄、数値0は`0`、booleanは小文字`true`/`false`。文字列の先頭零・改行・引用符は保持する。CSV単体ではnullと空文字を区別できないため、元JSONの型を基準に照合する。

## 検査と表示

二表のヘッダと全データを型付きでWorkbookへ投入し、再計算後の全セルを元JSONの型と値へ照合する。数式が0であることとエラー走査結果を記録してからCSVを保存する。所与の値を再集計する数式は作らない。元JSONに`#N/A`等の文字列があれば同じ文字として保持し、その件数を残す。

各表のA1:G5以内だけを固定幅で`支援画像/表名.png`へ描画する。全セッションは785px、E0入口明細は910pxの列幅合計、描画倍率1で右端の文字切れを避ける。プレビューはCSV全列・全行の代わりではない。`CSVの確認.json`には全セル比較数、入力前後SHA、出力SHA、行列数、runtime版を残す。

`CSVを独立再読する.py`は標準`csv`と`Decimal`だけで、指定JSONと二CSVを独立に再読する。数値は許容差なし、文字列も先頭零を含め完全一致とし、nullと数値0を分ける。入力とCSVの前後SHAも照合する。自然出力後はRootが二つの画像を視認する。

## 人工検査と編集停止

2026-11-10。121器から表名・表数・試行番号・プレビュー幅を適応した。`人工入力を作る.py`は集計コードを実行せずASTの定数ヘッダだけを読み、全セッション3行×27列、E0入口明細4行×31列の人工値を作った。205データセル、105数値、37数値零、23null、3空文字、2booleanの独立再読が成功した。Workbookでは58ヘッダを加え263セルを照合し、二つの画像を視認してヘッダの端切れがないことを確認した。

先頭零・改行・引用符・式に見える文字・意図したエラー文字列もCSVの元値と一致した。人工ID`007`は画像エンジンで`7`と表示されたが、CSVと型付き照合では文字列`007`を保持した。自然の画像・CSVの確認が完了したと先取りしない。

自然122の表・結果・市場入力・Raw・未知3場は未読、自然CSV未作成、操作marker未実行。`準備の確認.json`へ指紋と検査範囲を保存し、編集を停止する。
