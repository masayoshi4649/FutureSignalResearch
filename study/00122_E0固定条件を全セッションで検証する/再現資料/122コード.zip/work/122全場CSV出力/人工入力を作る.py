"""
122の集計コードを実行せず、定数ヘッダだけをASTから読み人工CSV試験を作る。

自然結果、原板、入力及び実際のCSVは読まない。各数値は転記試験用で金融的意味を持たない。
"""

import ast
import hashlib
import json
from pathlib import Path


# ----------------------------------------
folder = Path(__file__).resolve().parent
source = folder.parent / "122全場入口比較" / "集計する.py"
tree = ast.parse(source.read_text(encoding="utf-8-sig"))
headers = {}
for node in ast.walk(tree):
    if isinstance(node, ast.Assign):
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id in {"headers", "detail_headers"}:
                headers[target.id] = ast.literal_eval(node.value)
assert len(headers["headers"]) == 27 and len(headers["detail_headers"]) == 31

session = [
    [122, "人工セッション甲", "人工既知", "デイ", 120, 2, 1, 1, 1, 1, 0,
     1, 0, 0, 1.0, 1.0, "達成", "達成", "人工・取得あり", 0, 0, 0, 0, 0, 3, 4, 5],
    [122, "人工セッション乙", "人工追加", "ナイト", 0, 0, 0, 0, 0, 0, 0,
     0, 0, 0, None, None, "評価不能", "評価不能", "人工・未成立", 0, 0, 0, 0, 0, 1, 2, 3],
    [122, '人工,"改行\nセッション"', "人工", "デイ", 100, 10, 10, 10, 10, 10, 0,
     7, 2, 1, 0.7777777777777778, 0.7, "達成", "達成", "=文字列維持", 1, 2, 3, 4, 5, 6, 7, 8],
]
detail = [
    [122, "人工セッション甲", "人工既知", "007", "買", "2026-01-01 09:15:00", "人工取得",
     "2026-01-01 09:15:01", "2026-01-01 09:15:02", 40000, 60, "完了", "2026-01-01 10:15:02",
     "順", "2026-01-01 09:30:00", "2026-01-01 10:15:02", 125.5, 12473, 11473,
     "順", "順", "順", "順", "未到達", 22.5, 23.5, 45, 1.05, 40020, 39900, 75.25],
    [122, "人工セッション乙", "人工追加", "=式でない文字", "売", "2026-01-01 18:00:00", "人工未取得",
     None, None, None, 30, "未取得", None, None, None, None, None, None, None,
     None, None, None, None, None, None, None, None, None, 40020, 40100, 75.25],
    [122, "人工セッション丙", "人工", "'引用符先頭", "売", "2026-01-01 19:00:00", "人工取得",
     "2026-01-01 19:00:01", "2026-01-01 19:00:02", 40000, 60, "完了", "2026-01-01 20:00:02",
     "逆", "2026-01-01 19:30:00", "2026-01-01 20:00:02", -10.25, -1102, -2102,
     "逆", "逆", "逆", "未到達", "未到達", 0, 0.3333333333333333, 50, 1, 39980, 40100, 0],
    [122, "人工セッション丁", "人工", "引用,と\"二重引用\"\n改行", "買", "", "人工汎用型試験",
     "#N/A", "", 0, 30, "人工", None, True, False, None, 0, 0, 0,
     "#REF!", "#DIV/0!", "=1+1", "'文字", "", 0, 0, 0, 0, 0, 0, 0],
]
assert all(len(row) == 27 for row in session)
assert all(len(row) == 31 for row in detail)
root = {
    "試行": 122,
    "人工": True,
    "意味": "型と値の転記検査用。自然データ又は金融結果ではない。",
    "ヘッダ参照コードSHA256": hashlib.sha256(source.read_bytes()).hexdigest(),
    "tables": [
        {"name": "全セッション", "headers": headers["headers"], "rows": session},
        {"name": "E0入口明細", "headers": headers["detail_headers"], "rows": detail},
    ],
}
target = folder / "人工入力.json"
with target.open("x", encoding="utf-8", newline="\n") as handle:
    handle.write(json.dumps(root, ensure_ascii=False, allow_nan=False, indent=2) + "\n")
print(json.dumps({"人工入力": str(target), "SHA256": hashlib.sha256(target.read_bytes()).hexdigest()}, ensure_ascii=False))
