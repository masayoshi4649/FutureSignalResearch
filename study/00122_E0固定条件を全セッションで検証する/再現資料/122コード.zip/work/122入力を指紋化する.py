"""条件固定後に全場のデータ版を認証し、公表生成計画を保存する。"""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parent.parent
OWN=ROOT/'work/122全場入力'
JST=timezone(timedelta(hours=9))


def digest(path: Path, compressed: bool=False) -> str:
    """
    機能: 原板を複製せず、保存bytes又はgzip展開bytesの指紋を求める。
    引数: path(Path)、compressed(bool)はgzip展開指定。返り値: strはSHA256。
    """
    h=hashlib.sha256()
    with (gzip.open(path,'rb') if compressed else path.open('rb')) as stream:
        while chunk:=stream.read(1024*1024):
            h.update(chunk)
    return h.hexdigest()


def stat(path: Path) -> dict:
    """
    機能: 読取前後のファイル版を記録する。
    引数: path(Path)。返り値: dictはbytesとmtime_ns。
    """
    s=path.stat()
    return {'bytes':s.st_size,'mod_time_ns':s.st_mtime_ns}


def ref(path: Path, expected: str|None=None) -> dict:
    """
    機能: 全bytes指紋と前後statを認証した参照を作る。
    引数: path(Path)、expected(str|None)。返り値: dictは絶対pathとSHA・stat。
    """
    before=stat(path)
    value=digest(path)
    assert before==stat(path),str(path)
    assert expected is None or value==expected,str(path)
    return {'path':str(path.resolve()),'sha256':value,**before}


def pair(job: tuple) -> dict:
    """
    機能: 一つの旧場のcanonical圧縮版と現在非圧縮版の同体を確認する。
    引数: job(tuple[dict,dict,dict,dict])。返り値: dictは参照・展開同体の証跡。
    """
    scene,inventory,declared,quality=job
    raw=Path(scene['raw']['path'])
    plain=next(Path(f['絶対パス']) for f in inventory['ファイル'] if f['区分']=='原板・非圧縮')
    raw_before,plain_before=stat(raw),stat(plain)
    raw_ref=ref(raw,scene['raw']['sha256'])
    plain_ref=ref(plain)
    decoded=digest(raw,True)
    assert raw_before==stat(raw) and plain_before==stat(plain)
    same=decoded==plain_ref['sha256']
    csv=ROOT.parent/declared['files']['NK225_candle_300']['path']
    csv_ref=ref(csv,declared['files']['NK225_candle_300']['sha256'])
    assert csv_ref['bytes']==declared['files']['NK225_candle_300']['size']
    return {'session':scene['session'],'contract':scene['contract'],'start':scene['start'],'end':scene['end'],'force_close':scene['force_close'],'raw':raw_ref,'csv':csv_ref,'expected_accepted':scene['expected_accepted'],'expected_quality':quality,'plain':plain_ref,'decoded_sha256':decoded,'same':same}


def new_scene(inventory: dict) -> dict:
    """
    機能: 新規場の参照と予定時計・実Symbolを取得する。価格の判断はしない。
    引数: inventory(dict)。返り値: dictは指紋と未走査の場定義。
    """
    sid=inventory['場']
    files=inventory['ファイル']
    raw=next(Path(f['絶対パス']) for f in files if f['区分']=='原板・非圧縮')
    csv=next(Path(f['絶対パス']) for f in files if f['区分']=='分足・5分')
    raw_ref,csv_ref=ref(raw),ref(csv)
    symbol=None
    with raw.open('r',encoding='utf-8') as stream:
        for line in stream:
            row=json.loads(line)
            if isinstance(row.get('Symbol'),str) and row['Symbol']:
                symbol=row['Symbol']
                break
    assert symbol is not None and stat(raw)=={k:raw_ref[k] for k in ('bytes','mod_time_ns')}
    day=datetime.strptime(sid[:10],'%Y-%m-%d').replace(tzinfo=JST)
    if sid.endswith('_Day'):
        start=day+timedelta(hours=8,minutes=45)
        end=day+timedelta(hours=15,minutes=45)
    else:
        start=day+timedelta(hours=17)
        end=day+timedelta(days=1,hours=6)
    return {'session':sid,'contract':symbol,'start':start.timestamp(),'end':end.timestamp(),'force_close':end.timestamp()-600,'raw':raw_ref,'csv':csv_ref}


def main() -> None:
    """
    機能: StageA固定を認証し、旧70同体と全73の生成計画を新規保存する。
    引数: なし。返り値: None。候補・損益は計算せず、未知読取の段階を記録する。
    """
    stage_path=ROOT/'work/122全場入口比較/StageA.json'
    stage=json.loads(stage_path.read_text(encoding='utf-8'))
    assert stage['fixed'] and stage['trial']==122
    for path,value in stage['code_sha256'].items():
        assert digest(Path(path))==value,path
    inventory_path=ROOT/'work/122全セッション棚卸/全セッションmetadata.json'
    assert digest(inventory_path)=='9830820ff2c004119e61c316f31e9eb19588b32b97289bf975c21b3873e9c057'
    inventory=json.loads(inventory_path.read_text(encoding='utf-8'))
    old_path=ROOT/'work/118入口比較/入力.json'
    manifest_path=ROOT/'study/00106_収束失速で保護の起動と幅を切り替える/入力台帳_70場.json'
    old_ref=ref(old_path,'574771f654937036b48c78eceadb46a4c5ff3c10265f60b0ec7879efb0d862c3')
    manifest_ref=ref(manifest_path,'902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8')
    old=json.loads(old_path.read_text(encoding='utf-8'))
    manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
    old_result_path=ROOT/'study/00121_失速と量で反転の入口を切り替える/成果物/全70場の入口結果.json.gz'
    decoded=gzip.decompress(old_result_path.read_bytes())
    assert hashlib.sha256(decoded).hexdigest()=='57118383d3e69ce341db955d0c34873b77177e497c801f6093630f4f31dd83bd'
    qualities={s['session']:s['quality'] for s in json.loads(decoded)['scenes']}
    lookup={s['場']:s for s in inventory['場']}
    declared={s['id']:s for s in manifest['sessions']}
    jobs=[(s,lookup[s['session']],declared[s['session']],qualities[s['session']]) for s in old['scenes']]
    OWN.mkdir(exist_ok=True)
    with ThreadPoolExecutor(max_workers=4) as workers:
        pairs=list(workers.map(pair,jobs))
    pair_path=OWN/'旧70原板同体.json'
    with pair_path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps({'成功':all(p['same'] for p in pairs),'StageA_SHA256':digest(stage_path),'場数':70,'全場':pairs,'価格判断':False},ensure_ascii=False,indent=2)+'\n')
    assert all(p['same'] for p in pairs),'原板の版差があるため旧公表を黙って再用しない'
    history=[{k:v for k,v in p.items() if k not in ('plain','decoded_sha256','same')} for p in pairs]
    new_ids=[s['場'] for s in inventory['場'] if s['場'] not in qualities]
    assert new_ids==['2026-11-09_Day','2026-11-09_Night','2026-11-10_Day']
    history.extend(new_scene(lookup[sid]) for sid in new_ids)
    assert len(history)==73 and all(history[i]['end']<history[i+1]['start'] for i in range(72))
    plan={'version':122,'anchor':'2026-09-21_Day','stage_a_sha256':digest(stage_path),'legacy_input':old_ref,'legacy_manifest':manifest_ref,'raw_equivalence':ref(pair_path),'history':history,'known_checks':['2026-09-21_Day','2026-10-30_Night','2026-11-06_Night'],'new_sessions':new_ids,'新規価格からの勝敗読取':False,'11月09読取許可':'ユーザーの全セッション検証指定に基づきStageA後に解除'}
    with (OWN/'公表生成計画.json').open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(plan,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'旧70同体':True,'全場':73,'新規':new_ids,'計画SHA256':digest(OWN/'公表生成計画.json'),'結果計算':False},ensure_ascii=False))


if __name__=='__main__':
    main()
