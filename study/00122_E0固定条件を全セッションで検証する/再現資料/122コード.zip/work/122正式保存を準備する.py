"""
122の固定コード・実行前検査を正式保存し、旧正式ZIPの同bytes依存を参照する。

原板、市場入力、自然結果、新規公表及び実行物本文は読まず、金融を再計算しない。
"""

from pathlib import Path
import hashlib
import json
import zipfile


ROOT = Path(__file__).resolve().parent.parent
STUDY = ROOT / "study/00122_E0固定条件を全セッションで検証する"
REPRO = STUDY / "再現資料"
CHECKS = STUDY / "検査"
EXPECTED_A = "dc338f810f3426cb0bfa2dce455a4560da470f54915c1335b4b1656618b2d6a3"
BASELINES = [
    ROOT / "study/00121_失速と量で反転の入口を切り替える/再現資料/121コード.zip",
    ROOT / "study/00120_1分構造と無効化距離で入口を作る/再現資料/120コード.zip",
    ROOT / "study/00115_三時間軸の方向性と局所構造で入口を分ける/再現資料/コードと実使用実行物.zip",
]


# ----------------------------------------
def digest(data: bytes) -> str:
    """
    機能: 読取済みバイト列のSHA256を求める。
    引数: data(bytes)は対象。
    返り値: str型のSHA256。
    """
    return hashlib.sha256(data).hexdigest()


# ----------------------------------------
def save_same(path: Path, data: bytes) -> None:
    """
    機能: 未作成ファイルへ保存し、既存なら同bytesであることを要求する。
    引数: path(Path)は保存先、data(bytes)は内容。
    返り値: None。不一致なら例外。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, path
    else:
        with path.open("xb") as stream:
            stream.write(data)


# ----------------------------------------
def json_bytes(value: dict) -> bytes:
    """
    機能: 日本語JSONをUTF-8へ変換する。
    引数: value(dict)は保存対象。
    返り値: bytes型のJSON。
    """
    return (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")


# ----------------------------------------
def main() -> None:
    """
    機能: StageAの52コードを確認し、同体の旧依存と新規ZIPの復元索引を作る。
    引数: なし。固定済みのコード・検査・旧コードZIPだけを読む。
    返り値: None。自然データ・金融結果・原板・exeを読まない。
    """
    REPRO.mkdir(exist_ok=True)
    CHECKS.mkdir(exist_ok=True)
    stage_path = ROOT / "work/122全場入口比較/StageA.json"
    stage_bytes = stage_path.read_bytes()
    assert digest(stage_bytes) == EXPECTED_A
    stage = json.loads(stage_bytes)
    assert len(stage["code_sha256"]) == 52
    baseline_info = {}
    available = {}
    for baseline in BASELINES:
        archive_sha = digest(baseline.read_bytes())
        baseline_info[baseline] = {"path": baseline.relative_to(ROOT).as_posix(), "SHA256": archive_sha}
        with zipfile.ZipFile(baseline) as archive:
            for info in archive.infolist():
                if not (info.filename.endswith(".go") or info.filename.endswith("/go.mod")):
                    continue
                relative = info.filename.removeprefix("復元/repository/")
                if not relative.startswith("work/"):
                    continue
                available.setdefault(relative, []).append((baseline, info.filename, digest(archive.read(info.filename))))
    packed = {}
    external = []
    fixed_files = []
    for source_name, expected in stage["code_sha256"].items():
        source = Path(source_name)
        data = source.read_bytes()
        assert digest(data) == expected, source
        relative = source.relative_to(ROOT).as_posix()
        fixed_files.append({"restore_relative": relative, "SHA256": expected, "bytes": len(data)})
        same = next((item for item in available.get(relative, []) if item[2] == expected), None)
        if same:
            baseline, entry, _ = same
            external.append({"restore_root": "repository", "restore_relative": relative,
                             "SHA256": expected, "bytes": len(data), "archive": baseline_info[baseline], "entry": entry})
        else:
            packed[relative] = data
    additions = [
        ROOT / "work/122全場CSV出力/出力する.mjs",
        ROOT / "work/122全場CSV出力/CSVを独立再読する.py",
        ROOT / "work/122全場CSV出力/README.md",
        ROOT / "work/122全場CSV出力/人工入力を作る.py",
        ROOT / "work/122全場入口比較/README.md",
        ROOT / "work/122公表生成の検討/公表生成経路.md",
        Path(__file__).resolve(),
    ]
    for source in additions:
        packed[source.relative_to(ROOT).as_posix()] = source.read_bytes()
    target = REPRO / "122コード.zip"
    assert not target.exists(), target
    with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for relative, data in sorted(packed.items()):
            assert not relative.endswith((".exe", ".json", ".jsonl", ".gz")), relative
            info = zipfile.ZipInfo(relative, date_time=(2026, 11, 10, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data)
    entries = []
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None
        for info in archive.infolist():
            data = archive.read(info.filename)
            assert data == packed[info.filename]
            entries.append({"entry": info.filename, "restore_root": "repository", "restore_relative": info.filename,
                            "SHA256": digest(data), "bytes": len(data), "CRC32": f"{info.CRC:08x}"})
    index = {"試行": 122, "段階": "StageA後の事前pack", "StageA_SHA256": EXPECTED_A,
             "zip": {"path": target.name, "SHA256": digest(target.read_bytes()), "bytes": target.stat().st_size},
             "entries": entries, "external_entries": external, "StageAコード": fixed_files,
             "備考": "52の固定コードを全て復元可能。旧正式ZIPの同bytes依存を重複保存しない。自然結果・入力・Raw・Native・exeは含まない。"}
    save_same(REPRO / "コード復元索引.json", json_bytes(index))
    copies = [
        (stage_path, "StageA.json"),
        (ROOT / "work/122全場入口比較/検査/確認.json", "実行器の人工検査.json"),
        (ROOT / "work/122公表生成の検討/確認.json", "公表生成器の人工検査.json"),
        (ROOT / "work/122全場CSV出力/準備の確認.json", "CSV準備の確認.json"),
        (ROOT / "work/122全場CSV出力/人工独立再読.json", "CSV人工独立再読.json"),
    ]
    copy_proofs = []
    for source, name in copies:
        data = source.read_bytes()
        save_same(CHECKS / name, data)
        copy_proofs.append({"source": str(source), "保存先": name, "SHA256": digest(data), "bytes": len(data)})
    for source_name, expected in stage["code_sha256"].items():
        assert digest(Path(source_name).read_bytes()) == expected, source_name
    for source_name, expected in stage["premarket_documents"].items():
        assert digest(Path(source_name).read_bytes()) == expected, source_name
    proof = {"試行": 122, "成功": True, "段階": "StageA後・自然結果保存前", "StageA_SHA256": EXPECTED_A,
             "固定52コード前後不変": True, "実行前原文前後不変": True, "zip": index["zip"],
             "ZIP内件数": len(entries), "外部依存件数": len(external), "全ZIPentry_SHA_size_CRC": True,
             "検査保存": copy_proofs, "金融再実行": False, "自然結果読取": False,
             "新規公表読取": False, "Raw読取": False, "入力JSON本文読取": False, "exe保存": False}
    save_same(CHECKS / "事前コード保管の確認.json", json_bytes(proof))
    print(json.dumps({"成功": True, "ZIP": index["zip"], "entry": len(entries), "外部": len(external)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
