package holdingohlc113

import (
	"bufio"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"sync"

	birth "github.com/masayoshi4649/SessionTradeExecuter/entrybirth121"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

var Policies122 = []string{"C0", "E0", "V0", "EV", "B0", "B1"}
var Widths122 = []float64{25, 50, 100, 125, 200}
var Horizons122 = []float64{1800, 3600}

type Scene122 struct {
	Session          string              `json:"session"`
	Contract         string              `json:"contract"`
	Start            float64             `json:"start"`
	End              float64             `json:"end"`
	ForceClose       float64             `json:"force_close"`
	Raw              FileRef             `json:"raw"`
	ExpectedAccepted int64               `json:"expected_accepted"`
	ExpectedQuality  *Counts             `json:"expected_quality,omitempty"`
	Publications     []rules.Publication `json:"publications"`
}
type Input122 struct {
	Scenes []Scene122 `json:"scenes"`
}
type Signal122 struct {
	ID    string  `json:"id"`
	Side  int     `json:"side"`
	Time  float64 `json:"time"`
	Index int64   `json:"index"`
	Line  int64   `json:"source_line"`
	Quote Quote   `json:"quote"`
}
type First122 struct {
	Width     float64 `json:"width"`
	Direction int     `json:"direction"`
	Quote     *Quote  `json:"quote"`
}
type Outcome122 struct {
	Seconds  float64    `json:"seconds"`
	Deadline float64    `json:"deadline"`
	Status   string     `json:"status"`
	Touches  []First122 `json:"touches"`
	Endpoint *Quote     `json:"endpoint"`
	Points   *float64   `json:"points"`
	Net0     *float64   `json:"net0"`
	Net5     *float64   `json:"net5"`
}
type Candidate122 struct {
	Policy         string       `json:"policy"`
	CohortID       string       `json:"cohort_id"`
	Birth          Signal122    `json:"birth"`
	Event          int          `json:"event"`
	Request        *Quote       `json:"request"`
	Expires        float64      `json:"expires"`
	Limit          *float64     `json:"limit"`
	EntryCap       float64      `json:"entry_cap"`
	Invalidation   float64      `json:"invalidation"`
	ATR5           float64      `json:"atr5"`
	MaximumRisk    float64      `json:"maximum_risk"`
	HoldBoundary   float64      `json:"hold_boundary"`
	HoldMinimum    float64      `json:"hold_minimum"`
	HoldStrict     bool         `json:"hold_strict"`
	RiskAtDecision *float64     `json:"risk_at_decision"`
	Evaluation     *Quote       `json:"evaluation"`
	Status         string       `json:"status"`
	Entry          *Quote       `json:"entry"`
	EntryPrice     *float64     `json:"entry_price"`
	LastNormalTime float64      `json:"last_normal_time"`
	Outcomes       []Outcome122 `json:"outcomes"`
}
type Result122 struct {
	Session           string          `json:"session"`
	Success           bool            `json:"success"`
	Error             string          `json:"error,omitempty"`
	Raw               FileRef         `json:"raw"`
	ActualSHA         string          `json:"actual_sha256"`
	Before            FileStat        `json:"stat_before"`
	After             FileStat        `json:"stat_after"`
	Quality           Counts          `json:"quality"`
	ExpectedQuality   *Counts         `json:"expected_quality,omitempty"`
	RawEncoding       string          `json:"raw_encoding"`
	Publications      int             `json:"publications"`
	Events            []birth.Event   `json:"events"`
	DetectorStats     birth.Stats     `json:"detector_stats"`
	Candidates        []*Candidate122 `json:"candidates"`
	RawPasses         int             `json:"raw_passes"`
	SourceSignalsUsed bool            `json:"source_signals_used"`
}

// ----------------------------------------
// quote122 は原板気配を発生器の当時価格時計へ射影します。
//
// 引数: q(Quote)。返り値: rules.QuoteはTime/Index/物理行/Lastです。
func quote122(q Quote) rules.Quote {
	return rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last}
}

// ----------------------------------------
// policy122 は事前固定した6候補だけを認めます。
//
// 引数: policy(string)。返り値: boolは固定候補である場合です。
func policy122(policy string) bool {
	for _, p := range Policies122 {
		if policy == p {
			return true
		}
	}
	return false
}

// ----------------------------------------
// new122 は1分パターンの成立原行に独立1miniの成行要求を作ります。
//
// 引数: e(birth.Event)、q(Quote)、at(int)、s(Scene122)。返り値: *Candidate122/errorです。
func new122(e birth.Event, q Quote, at int, s Scene122) (*Candidate122, error) {
	if e.ID == "" || e.CohortID == "" || e.Scope.SessionID != s.Session || e.Scope.Contract != s.Contract || !policy122(string(e.Policy)) || (e.Side != 1 && e.Side != -1) || e.At != quote122(q) {
		return nil, fmt.Errorf("イベントの場/限月/候補/原行差")
	}
	atr, ok := e.Fields["atr5"]
	if !ok || !atr.Known || !finite(atr.Value, e.EntryCap, e.Invalidation) || atr.Value <= 0 || e.EntryCap <= 0 || e.Invalidation <= 0 {
		return nil, fmt.Errorf("イベントのATR/価格上限/否定境界が不明又は不正")
	}
	boundary, boundaryOK := e.Fields["hold_boundary"]
	minimum, minimumOK := e.Fields["hold_minimum"]
	strict, strictOK := e.Fields["hold_strict"]
	if !boundaryOK || !minimumOK || !strictOK || !boundary.Known || !minimum.Known || !strict.Known || !finite(boundary.Value, minimum.Value, strict.Value) || boundary.Value <= 0 || (strict.Value != 0 && strict.Value != 1) || (minimum.Value != 0 && minimum.Value != 5) || (strict.Value == 1 && minimum.Value != 0) {
		return nil, fmt.Errorf("イベントの取得時構造維持条件が不明又は不正")
	}
	x := q
	c := &Candidate122{Policy: string(e.Policy), CohortID: e.CohortID, Birth: Signal122{ID: e.ID, Side: e.Side, Time: q.Time, Index: q.Index, Line: q.SourceLine, Quote: q}, Event: at, Request: &x, Expires: math.Min(q.Time+30, s.ForceClose), EntryCap: e.EntryCap, Invalidation: e.Invalidation, ATR5: atr.Value, MaximumRisk: math.Min(100, .5*atr.Value), HoldBoundary: boundary.Value, HoldMinimum: minimum.Value, HoldStrict: strict.Value == 1, Status: "pending", Outcomes: []Outcome122{}}
	if q.Time >= s.ForceClose {
		c.Status = "force_close"
		c.Request = nil
	}
	return c, nil
}

// ----------------------------------------
// fill122 は独立1miniの記帳と固定30/60分観測だけを開始します。
//
// 引数: c(*Candidate122)、q(Quote)、price(float64)。返り値: ありません。
func fill122(c *Candidate122, q Quote, price float64) {
	x := q
	c.Entry = &x
	c.EntryPrice = &price
	c.Status = "filled"
	c.LastNormalTime = q.Time
	for _, h := range Horizons122 {
		o := Outcome122{Seconds: h, Deadline: q.Time + h, Status: "pending", Touches: []First122{}}
		for _, w := range Widths122 {
			o.Touches = append(o.Touches, First122{Width: w})
		}
		c.Outcomes = append(c.Outcomes, o)
	}
}

// ----------------------------------------
// pending122 は期限と後原行1秒を満たす最初の正常BBOだけで取得を決めます。
//
// 引数: c(*Candidate122)、q(Quote)、force(float64)。返り値: ありません。
// 価格上限・構造維持・否定境界までのリスクが不適なら即取消し、有利化まで待ちません。
func pending122(c *Candidate122, q Quote, force float64) {
	if c.Status != "pending" || c.Entry != nil {
		return
	}
	if q.Time >= force {
		c.Status = "force_close"
		return
	}
	if q.Time >= c.Expires {
		c.Status = "unfilled_expired"
		return
	}
	if c.Request == nil || q.Index <= c.Request.Index || q.SourceLine <= c.Request.SourceLine || q.Time < c.Request.Time+1 || !q.QuoteOK || !normal(q) {
		return
	}
	x := q
	c.Evaluation = &x
	price := q.Ask
	if c.Birth.Side < 0 {
		price = q.Bid
	}
	risk := float64(c.Birth.Side) * (price - c.Invalidation)
	c.RiskAtDecision = &risk
	if float64(c.Birth.Side)*(price-c.EntryCap) > 0 {
		c.Status = "entry_cap_rejected"
		return
	}
	hold := float64(c.Birth.Side) * (q.Last - c.HoldBoundary)
	if (c.HoldStrict && hold <= 0) || (!c.HoldStrict && hold < c.HoldMinimum) {
		c.Status = "structure_lost"
		return
	}
	if risk <= 0 || risk > c.MaximumRisk {
		c.Status = "risk_rejected"
		return
	}
	fill122(c, q, price)
}

// ----------------------------------------
// scan122 は当場Rawを一走査し、公表・1分パターン・新規要求・固定期限を配送します。
//
// 引数: all([]Scene122)、at(int)。返り値: Result122/error。Source新規と取消は入力型に含めません。
func scan122(all []Scene122, at int) (out Result122, err error) {
	s := all[at]
	out = Result122{Session: s.Session, Raw: s.Raw, Candidates: []*Candidate122{}, Events: []birth.Event{}, RawPasses: 1, ExpectedQuality: s.ExpectedQuality}
	bank := rules.NewBank()
	for i := 0; i < at; i++ {
		p := all[i]
		if err = bank.StartSession(p.Session, p.Contract); err != nil {
			return out, err
		}
		for _, pub := range p.Publications {
			if pub.Stamp.Time >= s.Start {
				return out, fmt.Errorf("前史が当場へ侵入")
			}
			if err = bank.Add(pub); err != nil {
				return out, err
			}
		}
	}
	if err = bank.StartSession(s.Session, s.Contract); err != nil {
		return out, err
	}
	detector := birth.NewDetector()
	if err = detector.StartSession(s.Session, s.Contract); err != nil {
		return out, err
	}
	f, e := os.Open(s.Raw.Path)
	if e != nil {
		return out, e
	}
	defer f.Close()
	before, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.Before = FileStat{Bytes: before.Size(), ModTimeNS: before.ModTime().UnixNano()}
	hash := sha256.New()
	tee := io.TeeReader(f, hash)
	z, encoding, e := rawStream122(tee)
	if e != nil {
		return out, e
	}
	defer z.Close()
	out.RawEncoding = encoding
	scan := bufio.NewScanner(z)
	scan.Buffer(make([]byte, 65536), 8*1024*1024)
	scene := Scene{Session: s.Session, Contract: s.Contract, Start: s.Start, End: s.End, Raw: s.Raw}
	previous := s.Start
	var index int64
	pi := 0
	contracts := map[string]bool{}
	seen := map[string]bool{}
	pending := []*Candidate122{}
	holding := []*Candidate122{}
	for scan.Scan() {
		out.Quality.Lines++
		q, _, next, e := decodeRow(scan.Bytes(), out.Quality.Lines, index, scene, previous, &out.Quality, contracts)
		oldTime := previous
		previous = next
		if e != nil {
			return out, e
		}
		if q == nil {
			continue
		}
		index++
		for pi < len(s.Publications) && int64(s.Publications[pi].Stamp.Index) <= q.Index {
			pub := s.Publications[pi]
			if int64(pub.Stamp.Index) != q.Index || int64(pub.Stamp.Line) != q.SourceLine || pub.Stamp.Time != q.Time {
				return out, fmt.Errorf("公表実配送行差")
			}
			if err = bank.Add(pub); err != nil {
				return out, err
			}
			pi++
		}
		events, e := detector.Observe(bank, quote122(*q))
		if e != nil {
			return out, e
		}
		for _, event := range events {
			if seen[event.ID] {
				return out, fmt.Errorf("イベントID重複")
			}
			seen[event.ID] = true
			c, e := new122(event, *q, len(out.Events), s)
			if e != nil {
				return out, e
			}
			out.Events = append(out.Events, event)
			out.Candidates = append(out.Candidates, c)
			if c.Status == "pending" {
				pending = append(pending, c)
			}
		}
		keep := pending[:0]
		for _, c := range pending {
			pending122(c, *q, s.ForceClose)
			if c.Entry != nil {
				holding = append(holding, c)
			} else if c.Status == "pending" {
				keep = append(keep, c)
			}
		}
		pending = keep
		active := holding[:0]
		for _, c := range holding {
			outcome122(c, *q, oldTime, s.End)
			alive := false
			for _, o := range c.Outcomes {
				if o.Status == "pending" {
					alive = true
				}
			}
			if alive {
				active = append(active, c)
			}
		}
		holding = active
	}
	if e = scan.Err(); e != nil {
		return out, e
	}
	if _, e = io.Copy(io.Discard, tee); e != nil {
		return out, e
	}
	after, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.After = FileStat{Bytes: after.Size(), ModTimeNS: after.ModTime().UnixNano()}
	out.ActualSHA = hex.EncodeToString(hash.Sum(nil))
	if out.ActualSHA != s.Raw.SHA256 || out.Before != out.After {
		return out, fmt.Errorf("Raw SHA/stat差")
	}
	if len(contracts) != 1 || !contracts[s.Contract] || index != s.ExpectedAccepted || pi != len(s.Publications) {
		return out, fmt.Errorf("限月/全採用数/公表配送数差")
	}
	if s.ExpectedQuality != nil && out.Quality != *s.ExpectedQuality {
		return out, fmt.Errorf("全行品質metadata差")
	}
	for _, c := range pending {
		c.Status = "eof_unfilled"
	}
	for _, c := range holding {
		for i := range c.Outcomes {
			if c.Outcomes[i].Status == "pending" {
				c.Outcomes[i].Status = "eof_censored"
			}
		}
	}
	if len(out.Candidates) != len(out.Events) {
		return out, fmt.Errorf("イベントと独立候補数差")
	}
	out.DetectorStats = detector.Stats()
	out.Publications = pi
	out.Success = true
	return out, nil
}

// ----------------------------------------
// Run122 はRoot固定済み入力を用い、最大8場並列で未作成結果へ保存します。
//
// 引数: input/expected/output(string)、workers(int)。返り値: errorは指紋・配送・保存の不整合です。
func Run122(input, expected, output string, workers int) error {
	if !validSHA122(expected) {
		return fmt.Errorf("StageB固定の入力SHA小文字64桁を指定してください")
	}
	data, err := os.ReadFile(input)
	if err != nil {
		return err
	}
	sum := sha256.Sum256(data)
	if hex.EncodeToString(sum[:]) != expected {
		return fmt.Errorf("入力SHA差")
	}
	var in Input122
	if err = json.Unmarshal(data, &in); err != nil {
		return err
	}
	pubs, err := validateInput122(in, workers)
	if err != nil {
		return err
	}
	if _, err = os.Stat(output); !os.IsNotExist(err) {
		return fmt.Errorf("新規先だけ")
	}
	results := make([]Result122, len(in.Scenes))
	jobs := make(chan int)
	var wg sync.WaitGroup
	for i := 0; i < workers; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for at := range jobs {
				r, e := scan122(in.Scenes, at)
				if e != nil {
					r.Error = e.Error()
				}
				results[at] = r
				fmt.Printf("%s 成功=%t %s\n", r.Session, r.Success, r.Error)
			}
		}()
	}
	for i := range in.Scenes {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	for _, r := range results {
		if !r.Success {
			return fmt.Errorf("%s: %s", r.Session, r.Error)
		}
	}
	encoded, err := json.MarshalIndent(map[string]any{"trial": 122, "success": true, "input_sha256": expected, "policies": Policies122, "horizons": Horizons122, "widths": Widths122, "scenes": results, "scene_count": len(in.Scenes), "publication_count": pubs, "portfolio_pnl": false, "candidate_quantity": 1, "source_signals_used": false, "endpoint_model": "期限に達した最初の正常原行まで。ラベルは元期限まで、純額は猶予30秒内の実endpointで評価"}, "", "  ")
	if err != nil {
		return err
	}
	after, err := os.ReadFile(input)
	if err != nil {
		return err
	}
	if sha256.Sum256(after) != sum {
		return fmt.Errorf("入力前後差")
	}
	f, err := os.OpenFile(output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return err
	}
	defer f.Close()
	_, err = f.Write(append(encoded, '\n'))
	return err
}
