package holdingohlc113

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"

	birth "github.com/masayoshi4649/SessionTradeExecuter/entrybirth121"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// testQuote122 は正常BBOを持つ手製原行を返します。
//
// 引数: at(float64)、index(int64)、bid/ask(float64)。返り値: Quoteです。
func testQuote122(at float64, index int64, bid, ask float64) Quote {
	return Quote{Time: at, Index: index, SourceLine: index + 1, Last: (bid + ask) / 2, Bid: bid, Ask: ask, QuoteOK: true}
}

// testEvent122 は市場データに依存しない手製1分パターン票を返します。
//
// 引数: q(Quote)、side(int)。返り値: birth.Eventです。
func testEvent122(q Quote, side int) birth.Event {
	cap, invalidation := 110.0, 90.0
	if side < 0 {
		cap, invalidation = 90, 110
	}
	return birth.Event{ID: fmt.Sprintf("s/C0/%d/000001", side), CohortID: fmt.Sprintf("s/C0/%d/000001", side), Scope: birth.Scope{SessionID: "s", Contract: "X"}, Policy: "C0", Side: side, At: quote122(q), EntryCap: cap, Invalidation: invalidation, Fields: map[string]rules.Value{"atr5": {Known: true, Value: 100}, "hold_boundary": {Known: true, Value: 100 - float64(side)*5}, "hold_minimum": {Known: true, Value: 0}, "hold_strict": {Known: true, Value: 1}}}
}

// TestDelayedEntryMirror122 は要求後原行1秒と買売鏡像の初回正常BBO取得を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestDelayedEntryMirror122(t *testing.T) {
	for _, side := range []int{1, -1} {
		q := testQuote122(100, 0, 95, 105)
		c, err := new122(testEvent122(q, side), q, 0, Scene122{Session: "s", Contract: "X", ForceClose: 5000})
		if err != nil || c.Expires != 130 || c.Limit != nil || c.CohortID != testEvent122(q, side).CohortID {
			t.Fatal("出生要求", err)
		}
		pending122(c, testQuote122(100, 1, 95, 105), 5000)
		pending122(c, testQuote122(101, 0, 95, 105), 5000)
		bad := testQuote122(101, 1, 95, 105)
		bad.QuoteOK = false
		pending122(c, bad, 5000)
		if c.Entry != nil || c.Evaluation != nil {
			t.Fatal("同秒・同原行・不正BBOで取得")
		}
		x := testQuote122(102, 2, 95, 105)
		pending122(c, x, 5000)
		want := x.Ask
		if side < 0 {
			want = x.Bid
		}
		if c.Entry == nil || *c.Entry != x || *c.EntryPrice != want || c.Status != "filled" || *c.RiskAtDecision != 15 || len(c.Outcomes) != 2 {
			t.Fatalf("初回正常BBO又は鏡像差 %+v", c)
		}
		pending122(c, testQuote122(103, 3, 85, 95), 5000)
		if *c.EntryPrice != want || c.Evaluation.Index != 2 {
			t.Fatal("既取得を改変")
		}
	}
}

// TestCapRiskRejectAndBoundary122 は価格上限・リスク否定の即時取消と境界を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。拒否後の有利化を待ちません。
func TestCapRiskRejectAndBoundary122(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, test := range []struct {
			name string
			risk float64
			cap  bool
			want string
		}{{"上限", 15, true, "entry_cap_rejected"}, {"ゼロ", 0, false, "risk_rejected"}, {"負", -1, false, "risk_rejected"}, {"過大", 51, false, "risk_rejected"}, {"等号", 50, false, "filled"}} {
			t.Run(fmt.Sprintf("%d%s", side, test.name), func(t *testing.T) {
				q := testQuote122(100, 0, 95, 105)
				e := testEvent122(q, side)
				price := 105.0
				if side < 0 {
					price = 95
				}
				e.Invalidation = price - float64(side)*test.risk
				if test.cap {
					e.EntryCap = price - float64(side)
					e.Fields["hold_boundary"] = rules.Value{Known: true, Value: 100}
				}
				c, err := new122(e, q, 0, Scene122{Session: "s", Contract: "X", ForceClose: 5000})
				if err != nil {
					t.Fatal(err)
				}
				pending122(c, testQuote122(101, 1, 95, 105), 5000)
				if c.Status != test.want || c.Evaluation == nil || *c.RiskAtDecision != test.risk {
					t.Fatalf("拒否又は境界差 %+v", c)
				}
				if test.want != "filled" {
					pending122(c, testQuote122(102, 2, 96, 104), 5000)
					if c.Entry != nil || c.Evaluation.Index != 1 || c.Status != test.want {
						t.Fatal("拒否後に改善を待って取得")
					}
				}
			})
		}
		for _, test := range []struct {
			strict   bool
			distance float64
			want     string
		}{{true, 1, "filled"}, {true, 0, "structure_lost"}, {true, -1, "structure_lost"}, {false, 5, "filled"}, {false, 4, "structure_lost"}} {
			q := testQuote122(100, 0, 95, 105)
			e := testEvent122(q, side)
			e.Fields["hold_boundary"] = rules.Value{Known: true, Value: 100 - float64(side)*test.distance}
			strict, minimum := 0.0, 5.0
			if test.strict {
				strict, minimum = 1, 0
			}
			e.Fields["hold_strict"] = rules.Value{Known: true, Value: strict}
			e.Fields["hold_minimum"] = rules.Value{Known: true, Value: minimum}
			if test.want == "structure_lost" {
				e.Invalidation = 105
				if side < 0 {
					e.Invalidation = 95
				}
			}
			c, err := new122(e, q, 0, Scene122{Session: "s", Contract: "X", ForceClose: 5000})
			if err != nil {
				t.Fatal(err)
			}
			pending122(c, testQuote122(101, 1, 95, 105), 5000)
			if c.Status != test.want {
				t.Fatalf("構造維持の鏡像/等号差 side=%d strict=%t distance=%g got=%s", side, test.strict, test.distance, c.Status)
			}
			if test.want == "structure_lost" {
				pending122(c, testQuote122(102, 2, 95, 105), 5000)
				if c.Entry != nil || c.Evaluation.Index != 1 {
					t.Fatal("構造崩壊後に待機")
				}
			}
		}
	}
	q := testQuote122(100, 0, 995, 1005)
	e := testEvent122(q, 1)
	e.EntryCap, e.Invalidation = 1010, 905
	e.Fields["atr5"] = rules.Value{Known: true, Value: 1000}
	c, _ := new122(e, q, 0, Scene122{Session: "s", Contract: "X", ForceClose: 5000})
	pending122(c, testQuote122(101, 1, 995, 1005), 5000)
	if c.Status != "filled" || c.MaximumRisk != 100 {
		t.Fatal("100pt上限の等号差")
	}
}

// TestIdentityExpiryAndForce122 はScope/当原行と期限等号・ForceClose後出生を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestIdentityExpiryAndForce122(t *testing.T) {
	q := testQuote122(100, 0, 95, 105)
	s := Scene122{Session: "s", Contract: "X", ForceClose: 5000}
	e := testEvent122(q, 1)
	wrong := e
	wrong.CohortID = ""
	if _, err := new122(wrong, q, 0, s); err == nil {
		t.Fatal("基礎出生系列IDなしを受理")
	}
	wrong = e
	wrong.Scope.Contract = "Y"
	if _, err := new122(wrong, q, 0, s); err == nil {
		t.Fatal("異限月受理")
	}
	wrong = e
	wrong.At.Last++
	if _, err := new122(wrong, q, 0, s); err == nil {
		t.Fatal("当原行差を受理")
	}
	wrong = e
	wrong.Fields = map[string]rules.Value{"atr5": {}}
	if _, err := new122(wrong, q, 0, s); err == nil {
		t.Fatal("未知ATR受理")
	}
	c, _ := new122(e, q, 0, s)
	pending122(c, testQuote122(130, 1, 95, 105), 5000)
	if c.Status != "unfilled_expired" || c.Evaluation != nil {
		t.Fatal("30秒等号で新規評価")
	}
	s.ForceClose = 100
	c, _ = new122(e, q, 0, s)
	if c.Request != nil || c.Status != "force_close" || c.Expires != 100 {
		t.Fatal("ForceClose後出生に要求")
	}
	s.ForceClose = 101
	c, _ = new122(e, q, 0, s)
	pending122(c, testQuote122(101, 1, 95, 105), 101)
	if c.Status != "force_close" || c.Entry != nil {
		t.Fatal("ForceClose等号に取得")
	}
}

// TestKernelAndArtificialRaw122 は固定期限の物理境界・欠測nil・人工Raw指紋を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。自然Raw又は入力JSONは読みません。
func TestKernelAndArtificialRaw122(t *testing.T) {
	c := &Candidate122{Birth: Signal122{Side: 1}}
	fill122(c, testQuote122(100, 0, 95, 100), 100)
	for at := 300.0; at < 1900; at += 200 {
		outcome122(c, testQuote122(at, int64(at), 100, 105), at-1, 5000)
	}
	outcome122(c, testQuote122(1900, 2000, 110, 115), 1899, 5000)
	outcome122(c, testQuote122(1900, 2001, 250, 255), 1900, 5000)
	if c.Outcomes[0].Status != "complete" || *c.Outcomes[0].Net0 != 923 || c.Outcomes[0].Touches[0].Direction != 0 {
		t.Fatal("期限同秒の評価後原行混入")
	}
	g := &Candidate122{Birth: Signal122{Side: 1}}
	fill122(g, testQuote122(100, 0, 95, 100), 100)
	outcome122(g, testQuote122(401, 1, 100, 105), 100, 5000)
	if g.Outcomes[0].Status != "gap_censored" || g.Outcomes[0].Net0 != nil {
		t.Fatal("gapの零補完")
	}
	b := &Candidate122{Birth: Signal122{Side: 1}}
	fill122(b, testQuote122(100, 0, 95, 100), 100)
	bad := testQuote122(401, 1, 100, 105)
	bad.QuoteOK = false
	outcome122(b, bad, 400, 5000)
	if b.Outcomes[0].Status != "bbo_gap_censored" {
		t.Fatal("正常BBO欠測の未検出")
	}
	path := filepath.Join(t.TempDir(), "人工.jsonl.gz")
	f, err := os.Create(path)
	if err != nil {
		t.Fatal(err)
	}
	z := gzip.NewWriter(f)
	for _, q := range []Quote{testQuote122(100, 0, 990, 1010), testQuote122(100, 1, 990, 1010), testQuote122(101, 2, 990, 1010)} {
		m := map[string]any{"Symbol": "X", "CurrentPrice": q.Last, "CurrentPriceTime": time.Unix(int64(q.Time), 0).UTC().Format(time.RFC3339)}
		for i := 1; i <= 10; i++ {
			m[fmt.Sprintf("Buy%d", i)] = map[string]float64{"Price": q.Bid, "Qty": 1}
			m[fmt.Sprintf("Sell%d", i)] = map[string]float64{"Price": q.Ask, "Qty": 1}
		}
		raw, _ := json.Marshal(m)
		if _, err = z.Write(append(raw, '\n')); err != nil {
			t.Fatal(err)
		}
	}
	if err = z.Close(); err != nil {
		t.Fatal(err)
	}
	if err = f.Close(); err != nil {
		t.Fatal(err)
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	hash := sha256.Sum256(raw)
	s := Scene122{Session: "s", Contract: "X", Start: 100, End: 5000, ForceClose: 4900, Raw: FileRef{Path: path, SHA256: hex.EncodeToString(hash[:])}, ExpectedAccepted: 3}
	got, err := scan122([]Scene122{s}, 0)
	if err != nil || !got.Success || got.Quality.Delivered != 3 || len(got.Candidates) != 0 || got.Before != got.After {
		t.Fatalf("人工Raw認証 %v %+v", err, got)
	}
	s.Raw.SHA256 = string(make([]byte, 64))
	if _, err = scan122([]Scene122{s}, 0); err == nil {
		t.Fatal("Raw SHA不一致を受理")
	}
}
