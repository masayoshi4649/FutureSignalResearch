"""1分構造から独立に生んだ入口の同幅先着を集計する。"""
from collections import Counter
from datetime import datetime, timedelta, timezone
from pathlib import Path
from statistics import mean, median
import hashlib
import json
import math

OWN = Path(__file__).resolve().parent
JST = timezone(timedelta(hours=9))
WIDTHS = (25, 50, 100, 125, 200)
HORIZONS = (1800, 3600)


def avg(values: list) -> float | None:
    """
    機能: 空集団を0で補わず平均する。
    引数: values(list[number])。返り値: float|None。
    """
    return mean(values) if values else None


def jst(value: float | None) -> str | None:
    """
    機能: 価格時計をJST表記にする。
    引数: value(float|None)。返り値: str|None。受信時計ではない。
    """
    return None if value is None else datetime.fromtimestamp(value, JST).strftime('%Y-%m-%d %H:%M:%S')


def validate(c: dict, scene: dict) -> int:
    """
    機能: 1分構造・公表参照・取得cap/無効化距離と期限算術を照合する。
    引数: c/scene(dict)。返り値: intは完了期限数。Raw再走査は行わない。
    """
    event = scene['events'][c['event']]
    assert event['id'] == c['birth']['id'] and event['policy'] == c['policy'] and event['side'] == c['birth']['side']
    assert event['bar']['end'] <= event['at']['time'] <= event['bar']['end'] + 30
    for ref in event['refs']:
        assert ref['end'] <= event['at']['time'] and ref['delivered']['time'] <= event['at']['time'] and ref['delivered']['index'] <= event['at']['index'] and ref['delivered']['source_line'] <= event['at']['source_line']
    fields, side = event['fields'], event['side']
    if c['policy'] in ('E0','EV','B0','B1'):
        assert fields['adx30']['known'] and fields['previous_adx30']['known'] and fields['adx30']['value'] < fields['previous_adx30']['value']
    if c['policy'] in ('V0','EV','B0','B1'):
        assert fields['rvol5']['known'] and fields['rvol5']['value'] >= 1
    if c['policy'] == 'B0':
        for current, previous in (('hist5','previous_hist5'),('rsi5','previous_rsi5')):
            assert fields[current]['known'] and fields[previous]['known'] and side*(fields[current]['value']-fields[previous]['value']) > 0
    if c['entry'] is None:
        assert c['entry_price'] is None and not c['outcomes'] and c['status'] != 'filled'
        return 0
    q, request, side = c['entry'], c['request'], c['birth']['side']
    assert c['status'] == 'filled' and q['quote_ok'] and 0 < q['bid'] < q['ask']
    assert q['index'] > request['index'] and q['source_line'] > request['source_line'] and q['time'] >= request['time'] + 1 and q['time'] < c['expires']
    assert c['entry_price'] == (q['ask'] if side == 1 else q['bid'])
    assert side * (c['entry_price'] - event['entry_cap']) <= 0
    hold = side * (q['last'] - event['fields']['hold_boundary']['value'])
    minimum = event['fields']['hold_minimum']['value']
    assert hold > minimum if event['fields']['hold_strict']['value'] == 1 else hold >= minimum
    risk = side * (c['entry_price'] - event['invalidation'])
    assert 0 < risk <= min(100, .5 * event['fields']['atr5']['value'])
    checked = 0
    assert [o['seconds'] for o in c['outcomes']] == list(HORIZONS)
    for o in c['outcomes']:
        assert o['deadline'] == q['time'] + o['seconds']
        for t in o['touches']:
            assert t['direction'] in (-1, 0, 1)
            if not t['direction']:
                assert t['quote'] is None
            else:
                p = t['quote']
                assert p['index'] > q['index'] and p['source_line'] > q['source_line'] and q['time'] <= p['time'] <= o['deadline']
                assert t['direction'] * side * ((p['bid'] if side == 1 else p['ask']) - c['entry_price']) >= t['width']
                if o['endpoint']:
                    assert p['index'] <= o['endpoint']['index']
        if o['status'] == 'complete':
            e = o['endpoint']
            assert o['deadline'] <= e['time'] <= o['deadline'] + 30 and e['quote_ok'] and 0 < e['bid'] < e['ask']
            points = side * ((e['bid'] if side == 1 else e['ask']) - c['entry_price'])
            assert (o['points'], o['net0'], o['net5']) == (points, points * 100 - 77, points * 100 - 1077)
            checked += 1
        else:
            assert all(o[k] is None for k in ('endpoint', 'points', 'net0', 'net5'))
    return checked


def stats(cases: list, seconds: int, baseline: dict) -> dict:
    """
    機能: 全出生・未約定・観測不足を残し、同幅先着と同出生対照を集計する。
    引数: cases(list[dict])、seconds(int)、baseline(dict)。返り値: dict。
    """
    entered = [c for c in cases if c['entry'] is not None]
    observed = [(c, next(o for o in c['outcomes'] if o['seconds'] == seconds)) for c in entered]
    complete = [(c, o) for c, o in observed if o['status'] == 'complete']
    n0, n5 = [o['net0'] for _, o in complete], [o['net5'] for _, o in complete]
    touches = {}
    for width in WIDTHS:
        counts = Counter(next(t['direction'] for t in o['touches'] if t['width'] == width) for _, o in complete)
        win, loss, neither = counts[1], counts[-1], counts[0]
        resolved = win + loss
        rate = win / resolved if resolved else None
        # ----------------------------------------
        # 同じ場・同じ波の依存があるため、二項区間は参考値としてのみ保存する。
        lower = None
        if resolved:
            z2 = 1.959963984540054 ** 2
            lower = (rate + z2 / (2 * resolved) - 1.959963984540054 * math.sqrt(rate * (1 - rate) / resolved + z2 / (4 * resolved ** 2))) / (1 + z2 / resolved)
        touches[str(width)] = {'favorable': win, 'adverse': loss, 'neither': neither, 'resolved': resolved, 'resolved_rate': rate, 'all_complete_favorable_rate': win / len(complete) if complete else None, 'reference_binomial_lower95': lower, 'target70_resolved': rate >= .7 if rate is not None else None, 'target70_all_complete': win / len(complete) >= .7 if complete else None}
    pairs = []
    for c, o in complete:
        b = baseline.get((c['session'], c['cohort_id']))
        if b is None:
            continue
        other = next((x for x in b['outcomes'] if x['seconds'] == seconds and x['status'] == 'complete'), None)
        if other is not None:
            pairs.append({'baseline': other['net5'], 'candidate': o['net5'], 'delta': o['net5'] - other['net5'], 'price_improvement': c['birth']['side'] * (b['entry_price'] - c['entry_price'])})
    return {'births': len(cases), 'eligible_births': sum(c['expires'] > c['birth']['time'] for c in cases), 'requested': sum(c['request'] is not None for c in cases), 'filled': len(entered), 'complete': len(complete), 'censored': len(entered) - len(complete), 'filled_sessions': len({c['session'] for c in entered}), 'complete_sessions': len({c['session'] for c, _ in complete}), 'states': dict(Counter(c['status'] for c in cases)), 'observations': dict(Counter(o['status'] for _, o in observed)), 'touches': touches, 'mean_net0': avg(n0), 'mean_net5': avg(n5), 'median_net5': median(n5) if n5 else None, 'positive_net5': sum(v > 0 for v in n5), 'negative_net5': sum(v < 0 for v in n5), 'pairs': len(pairs), 'paired_base_mean_net5': avg([p['baseline'] for p in pairs]), 'paired_candidate_mean_net5': avg([p['candidate'] for p in pairs]), 'paired_mean_delta': avg([p['delta'] for p in pairs]), 'paired_mean_price_improvement': avg([p['price_improvement'] for p in pairs])}


def label(o: dict | None, width: int) -> str:
    """
    機能: 未約定・観測不足と順逆の先着を区別して表示する。
    引数: o(dict|None)、width(int)。返り値: str。
    """
    if o is None:
        return '対象外（未約定）'
    direction = next(t['direction'] for t in o['touches'] if t['width'] == width)
    if o['status'] != 'complete':
        return '打切前順行' if direction == 1 else '打切前逆行' if direction == -1 else '観測不足'
    return '順行先着' if direction == 1 else '逆行先着' if direction == -1 else '両方未到達'


def main() -> None:
    """
    機能: 全73場の不成立も残し、固定E0の先着を既知・追加・全体で比較する。
    引数: なし。返り値: None。強制全場エントリーや閾値調整を行わない。
    """
    source=OWN/'全73場の入口結果.json'
    value=json.loads(source.read_text(encoding='utf-8'))
    assert value['success'] and value['trial']==122 and len(value['scenes'])==73
    assert not value['source_signals_used']
    rows=[]; checked=0
    for index,scene in enumerate(value['scenes']):
        assert scene['success'] and not scene['source_signals_used']
        for c in scene['candidates']:
            e=scene['events'][c['event']]
            c.update(session=scene['session'],history='既知70場' if index<70 else '追加3場',cohort_id=e['cohort_id'],family='B1' if c['policy'] in ('B0','B1') else 'C0',bar_end=e['bar']['end'],mode=c['policy'],role='基礎候補' if c['policy'] in ('C0','B1') else '追加条件',limit=None)
            checked+=validate(c,scene)
            rows.append(c)
    baseline={(c['session'],c['cohort_id']):c for c in rows if c['policy'] in ('C0','B1')}
    aggregate={p:{str(h):stats([c for c in rows if c['policy']==p],h,baseline) for h in HORIZONS} for p in value['policies']}
    groups={}
    for group,values in (('history',('既知70場','追加3場')),('side',(-1,1)),('session',[s['session'] for s in value['scenes']])):
        groups[group]={}
        for g in values:
            subset=[c for c in rows if (c['birth']['side'] if group=='side' else c[group])==g]
            groups[group][str(g)]={p:{str(h):stats([c for c in subset if c['policy']==p],h,baseline) for h in HORIZONS} for p in value['policies']}
    result={'試行':122,'成功':True,'主政策':'E0','主幅pt':100,'主時間秒':3600,'元結果SHA256':hashlib.sha256(source.read_bytes()).hexdigest(),'集計':aggregate,'群別':groups,'期限算術検査数':checked,'口座収支':False,'IFD実約定':False,'全場数':73,'既知場数':70,'追加場数':3,'数値条件':'順/(順+逆)>=.7。未到達含む順/全完了も併記。少数のみを理由に数値達成を未達としない。'}
    with (OWN/'集計.json').open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    session_rows=[]; detail_rows=[]
    for index,scene in enumerate(value['scenes']):
        sid=scene['session']; segment='既知70場' if index<70 else '追加3場'
        e0=groups['session'][sid]['E0']['3600']; c0=groups['session'][sid]['C0']['3600']
        ds=scene['detector_stats']; policies=ds['policies']
        common=policies['E0/1']['considered']
        assert common==policies['E0/-1']['considered']
        t=e0['touches']['100']
        if e0['births']:
            status='成立・取得あり' if e0['filled'] else '成立・未取得'
        elif not common:
            status='共通品質/履歴不足'
        elif not c0['births']:
            status='基本反転複合条件不成立'
        else:
            status='C0出生時ADX低下不成立/未知'
        rates=['達成' if t[k] else '未達' if t[k] is not None else '評価不能' for k in ('target70_resolved','target70_all_complete')]
        session_rows.append([122,sid,segment,'デイ' if sid.endswith('_Day') else 'ナイト',common,c0['births'],e0['births'],e0['requested'],e0['filled'],e0['complete'],e0['censored'],t['favorable'],t['adverse'],t['neither'],t['resolved_rate'],t['all_complete_favorable_rate'],*rates,status,e0['states'].get('entry_cap_rejected',0),e0['states'].get('structure_lost',0),e0['states'].get('risk_rejected',0),e0['states'].get('unfilled_expired',0),e0['states'].get('force_close',0),ds['publication_missing'],ds['atr1_unavailable'],ds['spike_rejected']])
        for c in scene['candidates']:
            if c['policy']!='E0':
                continue
            e=scene['events'][c['event']]; f=e['fields']
            for h in HORIZONS:
                o=next((o for o in c['outcomes'] if o['seconds']==h),None)
                touch=next((t for t in o['touches'] if t['width']==100),None) if o else None
                first=touch['quote'] if touch else None
                detail_rows.append([122,sid,segment,c['birth']['id'],'買' if c['birth']['side']==1 else '売',jst(c['birth']['time']),c['status'],jst(c['request']['time']) if c['request'] else None,jst(c['entry']['time']) if c['entry'] else None,c['entry_price'],h/60,o['status'] if o else 'not_entered',jst(o['deadline']) if o else None,label(o,100),jst(first['time']) if first else None,jst(o['endpoint']['time']) if o and o['endpoint'] else None,o['points'] if o else None,o['net0'] if o else None,o['net5'] if o else None,*[label(o,w) for w in WIDTHS],f['adx30']['value'] if f['adx30']['known'] else None,f['previous_adx30']['value'] if f['previous_adx30']['known'] else None,f['rsi15']['value'] if f['rsi15']['known'] else None,f['rvol5']['value'] if f['rvol5']['known'] else None,c['entry_cap'],c['invalidation'],c['atr5']])
    headers=['試行','セッション','期間区分','日夜','共通品質通過1分数','C0基礎出生数','E0出生数','要求数','取得代用数','60分観測完了数','60分観測不足数','100pt順行先着','100pt逆行先着','100pt両方未到達','到達済み分母順行率','全観測完了分母順行率','到達済み70%','全観測完了70%','判定状況','価格cap取消数','回復構造崩壊取消数','構造距離取消数','注文期限切れ数','新規時間外数','公表不足1分数','前ATR1不足1分数','スパイク拒否1分数']
    detail_headers=['試行','セッション','期間区分','出生ID','方向','出生JST','新規状態','要求JST','取得代用JST','取得価格','評価時間分','観測状態','評価期限JST','100pt先着','100pt初先着JST','期限評価JST','期限価格差pt','C0期限清算評価円','C5期限清算評価円','25pt先着','50pt先着','100pt先着再掲','125pt先着','200pt先着','ADX30','前ADX30','RSI15','RVOL5','新規価格cap','自然否定価格','ATR5']
    tables={'試行':122,'成功':True,'result_sha256':result['元結果SHA256'],'意味':'E0固定条件の全73場検証。全場への強制新規ではない。期限評価はIFD実約定・口座収支ではない。率0.7=70%。','tables':[{'name':'全セッション','headers':headers,'rows':session_rows},{'name':'E0入口明細','headers':detail_headers,'rows':detail_rows}]}
    assert len(session_rows)==73 and all(len(r)==len(headers) for r in session_rows) and all(len(r)==len(detail_headers) for r in detail_rows)
    with (OWN/'CSV用の表.json').open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(tables,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'全場73':aggregate['E0']['3600'],'既知70':groups['history']['既知70場']['E0']['3600'],'追加3':groups['history']['追加3場']['E0']['3600'],'CSV行数':[73,len(detail_rows)]},ensure_ascii=False))


if __name__=='__main__':
    main()
