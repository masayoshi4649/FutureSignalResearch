package main

import (
	entry "entryexperiment122"
	"flag"
	"fmt"
	"os"
)

// main はRoot固定後の122入口試験を未作成先へ実行します。
//
// 引数: CLI input/sha256/output(string)、workers(int)。返り値: ありません。
func main() {
	p := flag.String("input", "", "既固定入力")
	s := flag.String("sha256", "", "入力SHA")
	o := flag.String("output", "", "未作成結果")
	w := flag.Int("workers", 8, "場並列数")
	flag.Parse()
	if err := entry.Run122(*p, *s, *o, *w); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
