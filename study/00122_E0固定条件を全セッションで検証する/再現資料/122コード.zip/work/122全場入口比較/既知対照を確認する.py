"""全73再生の旧70部分が121の固定対照と変わっていないことを検査する。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 旧70場の全イベント・全政策・全取得/評価を保存結果で照合する。
    引数: なし。返り値: None。自然原板を再読せず、新規3場を検証から除外しない。
    """
    old_path=ROOT/'study/00121_失速と量で反転の入口を切り替える/成果物/全70場の入口結果.json.gz'
    old_bytes=gzip.decompress(old_path.read_bytes())
    assert hashlib.sha256(old_bytes).hexdigest()=='57118383d3e69ce341db955d0c34873b77177e497c801f6093630f4f31dd83bd'
    new_path=OWN/'全73場の入口結果.json'
    new_bytes=new_path.read_bytes()
    old,new=json.loads(old_bytes),json.loads(new_bytes)
    assert old['trial']==121 and new['trial']==122 and old['success'] and new['success']
    assert len(old['scenes'])==70 and len(new['scenes'])==73
    cases=0
    for a,b in zip(old['scenes'],new['scenes'][:70],strict=True):
        assert a['session']==b['session']
        for key,value in a.items():
            assert b[key]==value,(a['session'],key)
        cases+=len(a['candidates'])
    assert cases==81
    proof={'成功':True,'試行':122,'全既知場JSON同値':70,'全政策候補同値':81,'E0候補同値':7,'新3場は別集計':True,'旧結果展開SHA256':hashlib.sha256(old_bytes).hexdigest(),'新結果SHA256':hashlib.sha256(new_bytes).hexdigest(),'Raw再読':False}
    with (OWN/'既知70対照の確認.json').open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
