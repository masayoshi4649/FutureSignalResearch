"""未使用データ読取前の条件と、金融再生前の入力を段階固定する。"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib
import json
import sys

ROOT=Path(__file__).resolve().parents[2]
OWN=Path(__file__).resolve().parent
STUDY=ROOT/'study/00122_E0固定条件を全セッションで検証する'


def sha(path: Path) -> str:
    """
    機能: ファイル全bytesの指紋を求める。
    引数: path(Path)。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path: Path,value: dict) -> None:
    """
    機能: 既存条件を上書きせず日本語JSONを保存する。
    引数: path(Path)、value(dict)。返り値: None。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n')


def verify(stage: dict) -> None:
    """
    機能: 段階Aのコード・実行体・実行前文書の不変を照合する。
    引数: stage(dict)。返り値: None。
    """
    for path,expected in stage['code_sha256'].items():
        assert sha(Path(path))==expected,path
    for ref in stage['executables']:
        assert sha(Path(ref['path']))==ref['sha256']
    for path,expected in stage['premarket_documents'].items():
        assert sha(Path(path))==expected,path


def main() -> None:
    """
    機能: Aで不変条件を、Bで全73場入力を金融結果計算前に固定する。
    引数: sys.argv[1](str)=A又はB。返り値: None。
    """
    mode=sys.argv[1]
    assert mode in ('A','B')
    if mode=='A':
        assert not (OWN/'StageA.json').exists() and not (ROOT/'work/122全場入力/旧70原板同体.json').exists()
        folders=['122全場入口比較','122公表生成','121入口の反転切替','120入口の1分構造','118複数技法の入口条件','三時間軸の公開器','115三時間軸と方向性の公開','三時間軸の市場入力口']
        files=[]
        for folder in folders:
            directory=ROOT/'work'/folder
            files.extend(directory.rglob('*.go'))
            files.append(directory/'go.mod')
        files.extend(OWN.glob('*.py'))
        files.append(ROOT/'work/122入力を指紋化する.py')
        original=STUDY/'実行前原文'
        original.mkdir(exist_ok=False)
        docs={}
        for name in ('README.md','設定と結果.md'):
            target=original/name
            target.write_bytes((STUDY/name).read_bytes())
            docs[str(target)]=sha(target)
        proofs=[]
        for path,expected in [(OWN/'検査/確認.json','012b4dd2ea04e6e2f12427359509a8b18d965fd0ee259309bcd04f0f66453385'),(ROOT/'work/122公表生成の検討/確認.json','437b7c768281fb9a62f3f100ef5f039a90a0f331ebca5a2525861240b9bc1206')]:
            assert sha(path)==expected
            proofs.append({'path':str(path),'sha256':expected})
        stage={'trial':122,'fixed':True,'stage':'A','fixed_utc':datetime.now(timezone.utc).isoformat(),'main_policy':'E0','algorithm':'純121の固定E0。C0と基礎冷却/同出生派生、取得cap/hold/risk・費用・先着時計は変更しない。','horizons':[1800,3600],'widths':[25,50,100,125,200],'primary_horizon':3600,'primary_width':100,'target_rate':.7,'sessions':73,'known':70,'new':3,'quantity':1,'portfolio_pnl':False,'ifd_execution':False,'new_data_read_before_fixed':False,'data_policy':'旧70の展開bytesと現在plainを全件照合。同体なら旧70公表再用。新3は115の同じ公表モデル/予定End前史種で生成。版差は黙って混在させない。','permission':'全セッションで検証というユーザー指示により、StageA後に11/09含む新規3Raw/CSVを入力生成/検証へ読む。','source_clock':'Day08:45〜15:45/Night17:00〜翌06:00、ForceClose=End−600秒。価格時計は実受信時計でない。','fee_round':77,'stress_extra_round':1000,'code_sha256':{str(p):sha(p) for p in sorted(set(files))},'premarket_documents':docs,'artificial_proofs':proofs,'executables':[{'path':str(p),'sha256':sha(p)} for p in (OWN/'入口比較.exe',ROOT/'work/122公表生成/公表生成.exe')]}
        save(OWN/'StageA.json',stage)
        print(json.dumps({'固定':'A','SHA256':sha(OWN/'StageA.json'),'コード数':len(files)},ensure_ascii=False))
    else:
        stage=json.loads((OWN/'StageA.json').read_text(encoding='utf-8'))
        verify(stage)
        own_input=ROOT/'work/122全場入力'
        merged=json.loads((own_input/'入力結合の確認.json').read_text(encoding='utf-8'))
        assert merged['成功'] and merged['依存前後不変'] and merged['旧70公表JSON同体'] and merged['全場品質期待値あり']
        for path,expected in merged['依存前後SHA256'].items():
            assert sha(Path(path))==expected,path
        reference=merged['入力']
        assert sha(Path(reference['path']))==reference['sha256']
        value=json.loads(Path(reference['path']).read_text(encoding='utf-8'))
        assert len(value['scenes'])==73 and all('expected_quality' in s for s in value['scenes'])
        condition={'trial':122,'fixed':True,'stage':'B','fixed_utc':datetime.now(timezone.utc).isoformat(),'stage_a_sha256':sha(OWN/'StageA.json'),'input':reference,'plan_sha256':sha(own_input/'公表生成計画.json'),'new_publications_sha256':sha(own_input/'新規公表.json'),'known_publications_check_sha256':sha(own_input/'既知公表照合.json'),'publication_count':sum(len(s['publications']) for s in value['scenes']),'financial_result_read':False}
        save(OWN/'StageB.json',condition)
        print(json.dumps({'固定':'B','SHA256':sha(OWN/'StageB.json'),'入力SHA256':reference['sha256']},ensure_ascii=False))


if __name__=='__main__':
    main()
