package holdingohlc113

// outcome122 は同幅先着と期限清算評価を別に保存し、欠測を0円へ埋めません。
//
// 引数: c(*Candidate122)、q(Quote)、previous/force(float64)。返り値: ありません。
func outcome122(c *Candidate122, q Quote, previous, force float64) {
	if c.Entry == nil || q.Index <= c.Entry.Index {
		return
	}
	lastNormal := c.LastNormalTime
	if q.QuoteOK && normal(q) {
		defer func() { c.LastNormalTime = q.Time }()
	}
	for i := range c.Outcomes {
		o := &c.Outcomes[i]
		if o.Status != "pending" {
			continue
		}
		if previous >= c.Entry.Time && q.Time-previous > 300 && previous < o.Deadline {
			o.Status = "gap_censored"
			continue
		}
		if lastNormal >= c.Entry.Time && lastNormal < o.Deadline && q.Time-lastNormal > 300 {
			o.Status = "bbo_gap_censored"
			continue
		}
		if q.Time > force {
			o.Status = "session_censored"
			continue
		}
		if q.Time > o.Deadline+30 {
			o.Status = "endpoint_missing"
			continue
		}
		if !q.QuoteOK || !normal(q) {
			continue
		}
		mark := q.Bid
		if c.Birth.Side < 0 {
			mark = q.Ask
		}
		gain := float64(c.Birth.Side) * (mark - *c.EntryPrice)
		if q.Time <= o.Deadline {
			for j := range o.Touches {
				t := &o.Touches[j]
				if t.Direction != 0 {
					continue
				}
				if gain >= t.Width {
					t.Direction = 1
					x := q
					t.Quote = &x
				} else if gain <= -t.Width {
					t.Direction = -1
					x := q
					t.Quote = &x
				}
			}
		}
		if q.Time >= o.Deadline {
			x := q
			o.Endpoint = &x
			o.Points = &gain
			n0 := gain*100 - 77
			n5 := n0 - 1000
			o.Net0 = &n0
			o.Net5 = &n5
			o.Status = "complete"
		}
	}
}
