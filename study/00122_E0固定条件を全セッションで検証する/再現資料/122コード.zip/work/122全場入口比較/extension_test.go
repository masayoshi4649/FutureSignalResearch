package holdingohlc113

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"io"
	"math"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// artificialPayload122 は、自然Rawを使わず3行の有効な価格/板JSONLを作ります。
//
// 引数: t(*testing.T)。返り値: []byte型の人工非圧縮原行です。
func artificialPayload122(t *testing.T) []byte {
	t.Helper()
	var out bytes.Buffer
	for i := 0; i < 3; i++ {
		m := map[string]any{"Symbol": "X", "CurrentPrice": 1000, "CurrentPriceTime": time.Unix(100+int64(i), 0).UTC().Format(time.RFC3339)}
		for n := 1; n <= 10; n++ {
			m[fmt.Sprintf("Buy%d", n)] = map[string]int{"Price": 990, "Qty": 1}
			m[fmt.Sprintf("Sell%d", n)] = map[string]int{"Price": 1010, "Qty": 1}
		}
		line, err := json.Marshal(m)
		if err != nil {
			t.Fatal(err)
		}
		out.Write(line)
		out.WriteByte('\n')
	}
	return out.Bytes()
}

// ----------------------------------------
// TestPlainGzipMagicAndExpectedQuality122 は、形式が異なっても同じ原行/品質/出生になることを確認します。
//
// 引数: t(*testing.T)。返り値: なし。拡張子は意図的に逆にします。
func TestPlainGzipMagicAndExpectedQuality122(t *testing.T) {
	data := artificialPayload122(t)
	var compressed bytes.Buffer
	z := gzip.NewWriter(&compressed)
	if _, err := z.Write(data); err != nil {
		t.Fatal(err)
	}
	if err := z.Close(); err != nil {
		t.Fatal(err)
	}
	var baseline *Result122
	for _, item := range []struct {
		name, encoding string
		data           []byte
	}{{"plain.jsonl.gz", "plain", data}, {"gzip.jsonl", "gzip", compressed.Bytes()}} {
		path := filepath.Join(t.TempDir(), item.name)
		if err := os.WriteFile(path, item.data, 0600); err != nil {
			t.Fatal(err)
		}
		sum := sha256.Sum256(item.data)
		s := Scene122{Session: "s", Contract: "X", Start: 100, End: 5000, ForceClose: 4900, ExpectedAccepted: 3, Raw: FileRef{Path: path, SHA256: hex.EncodeToString(sum[:])}}
		r, err := scan122([]Scene122{s}, 0)
		if err != nil || !r.Success || r.RawEncoding != item.encoding || r.Quality.Delivered != 3 || r.Before != r.After || len(r.Candidates) != 0 {
			t.Fatalf("形式自動判定/品質 %s %v %+v", item.name, err, r)
		}
		if baseline == nil {
			baseline = &r
		} else if baseline.Quality != r.Quality || !reflect.DeepEqual(baseline.DetectorStats, r.DetectorStats) || !reflect.DeepEqual(baseline.Events, r.Events) {
			t.Fatal("gzip/plain原行配送差")
		}
		quality := r.Quality
		s.ExpectedQuality = &quality
		if _, err := scan122([]Scene122{s}, 0); err != nil {
			t.Fatal("品質metadata同体", err)
		}
		quality.BadBBO++
		if _, err := scan122([]Scene122{s}, 0); err == nil {
			t.Fatal("品質metadata差を無視")
		}
	}
	if _, _, err := rawStream122(bytes.NewReader([]byte{0x1f, 0x8b})); err == nil {
		t.Fatal("壊れたgzip header受理")
	}
	r, encoding, err := rawStream122(bytes.NewReader(nil))
	if err != nil || encoding != "plain" {
		t.Fatal("空stream判定")
	}
	b, err := io.ReadAll(r)
	_ = r.Close()
	if err != nil || len(b) != 0 {
		t.Fatal("空streamを補完")
	}
}

// ----------------------------------------
// artificialInput122 は、場数とScopeだけを検査する73場metadataを作ります。
//
// 引数: なし。返り値: Input122。パスは未存在の人工識別子で本文を読みません。
func artificialInput122() Input122 {
	in := Input122{}
	day := time.Date(2026, 9, 21, 0, 0, 0, 0, time.UTC)
	for i := 0; i < 73; i++ {
		kind := "Day"
		if i%2 == 1 {
			kind = "Night"
		}
		session := day.AddDate(0, 0, i/2).Format("2006-01-02") + "_" + kind
		if i == 70 {
			session = "2026-11-09_Day"
		}
		if i == 71 {
			session = "2026-11-09_Night"
		}
		if i == 72 {
			session = "2026-11-10_Day"
		}
		start := 100 + float64(i*6000)
		in.Scenes = append(in.Scenes, Scene122{Session: session, Contract: "X", Start: start, End: start + 5000, ForceClose: start + 4900, ExpectedAccepted: 3, Raw: FileRef{Path: "未存在の人工原板", SHA256: strings.Repeat("a", 64)}})
	}
	return in
}

// ----------------------------------------
// artificialPublication122 は、Scope/原行範囲/数値を検査する人工公表を作ります。
//
// 引数: s(Scene122)。返り値: rules.Publicationです。
func artificialPublication122(s Scene122) rules.Publication {
	return rules.Publication{Stamp: rules.Stamp{Time: 320, Index: 1, Line: 2}, Frame: rules.Frame{Frame: rules.ChartFrame{ID: "人工公表", SessionID: s.Session, Contract: s.Contract, Width: 300, Start: 0, End: 300, AvailableAt: 300, DeliveryAt: 320, PriceKnown: true, OHLC: rules.OHLC{Open: 1000, High: 1010, Low: 990, Close: 1000}}}}
}

// ----------------------------------------
// TestSeventyThreeMetadataAndPublicationValidation122 は、全73場と0公表・Scope/順序/有限値を確認します。
//
// 引数: t(*testing.T)。返り値: なし。11/09も検査母集団から除外しません。
func TestSeventyThreeMetadataAndPublicationValidation122(t *testing.T) {
	in := artificialInput122()
	if pubs, err := validateInput122(in, 8); err != nil || pubs != 0 {
		t.Fatal("73場/0公表/11月09", pubs, err)
	}
	if _, err := validateInput122(Input122{Scenes: in.Scenes[:72]}, 8); err == nil {
		t.Fatal("72場受理")
	}
	if _, err := validateInput122(in, 0); err == nil {
		t.Fatal("並列0受理")
	}
	in = artificialInput122()
	in.Scenes[72].Session = in.Scenes[71].Session
	if _, err := validateInput122(in, 8); err == nil {
		t.Fatal("場重複")
	}
	in = artificialInput122()
	in.Scenes[1].Start = in.Scenes[0].End
	if _, err := validateInput122(in, 8); err == nil {
		t.Fatal("場時計重複")
	}
	in = artificialInput122()
	in.Scenes[0].ForceClose = math.Inf(1)
	if _, err := validateInput122(in, 8); err == nil {
		t.Fatal("非有限場時計")
	}
	in = artificialInput122()
	pub := artificialPublication122(in.Scenes[0])
	in.Scenes[0].Publications = []rules.Publication{pub}
	if n, err := validateInput122(in, 8); err != nil || n != 1 {
		t.Fatal("動的公表数", n, err)
	}
	in.Scenes[0].Publications[0].Frame.Frame.Contract = "Y"
	if _, err := validateInput122(in, 8); err == nil {
		t.Fatal("公表異限月")
	}
	in = artificialInput122()
	pub = artificialPublication122(in.Scenes[0])
	pub.Frame.Frame.Technical.ATR = rules.Value{Known: true, Value: math.NaN()}
	in.Scenes[0].Publications = []rules.Publication{pub}
	if _, err := validateInput122(in, 8); err == nil {
		t.Fatal("非有限技術票")
	}
	in = artificialInput122()
	pub = artificialPublication122(in.Scenes[0])
	in.Scenes[0].Publications = []rules.Publication{pub, pub}
	if _, err := validateInput122(in, 8); err == nil {
		t.Fatal("公表重複")
	}
	in = artificialInput122()
	quality := Counts{Lines: 3, Accepted: 3, Delivered: 3}
	in.Scenes[0].ExpectedQuality = &quality
	if _, err := validateInput122(in, 8); err != nil {
		t.Fatal("任意品質metadata", err)
	}
	quality.BadBBO = -1
	if _, err := validateInput122(in, 8); err == nil {
		t.Fatal("負の品質metadata")
	}
}

// ----------------------------------------
// TestStageBInputSHAGuard122 は、空/未知形式/本文不一致SHAを金融実行前に拒否します。
//
// 引数: t(*testing.T)。返り値: なし。既固定旧SHAへ依存せずCLI期待SHAだけを使います。
func TestStageBInputSHAGuard122(t *testing.T) {
	for _, value := range []string{"", "未知", strings.Repeat("A", 64), strings.Repeat("a", 63), strings.Repeat("g", 64)} {
		if validSHA122(value) {
			t.Fatal("SHA形式受理", value)
		}
		if err := Run122("未存在の人工Input", value, "未存在の人工結果", 8); err == nil || !strings.Contains(err.Error(), "StageB") {
			t.Fatal("本文読取より前の形式拒否", err)
		}
	}
	in := filepath.Join(t.TempDir(), "人工入力.json")
	data := []byte(`{"scenes":[]}`)
	if err := os.WriteFile(in, data, 0600); err != nil {
		t.Fatal(err)
	}
	output := filepath.Join(t.TempDir(), "人工結果.json")
	if err := Run122(in, strings.Repeat("0", 64), output, 8); err == nil || !strings.Contains(err.Error(), "入力SHA差") {
		t.Fatal("期待SHA不一致", err)
	}
	sum := sha256.Sum256(data)
	expected := hex.EncodeToString(sum[:])
	if err := Run122(in, expected, output, 8); err == nil || !strings.Contains(err.Error(), "73場") {
		t.Fatal("新SHAの同体通過後の73場検査", err)
	}
	if _, err := os.Stat(output); !os.IsNotExist(err) {
		t.Fatal("拒否した入力で結果を作成")
	}
}

// ----------------------------------------
// functionBody122 は、関数宣言をコメント抜きASTで取り出して比較します。
//
// 引数: t(*testing.T)、path/name(string)。返り値: []byte型の正規化関数です。
func functionBody122(t *testing.T, path, name string) []byte {
	t.Helper()
	set := token.NewFileSet()
	file, err := parser.ParseFile(set, path, nil, 0)
	if err != nil {
		t.Fatal(err)
	}
	for _, decl := range file.Decls {
		if fn, ok := decl.(*ast.FuncDecl); ok && fn.Name.Name == name {
			var b bytes.Buffer
			if err := format.Node(&b, set, fn); err != nil {
				t.Fatal(err)
			}
			return b.Bytes()
		}
	}
	t.Fatal("関数なし", name)
	return nil
}

// ----------------------------------------
// TestFrozen121ReaderAndFinancialKernel122 は、decodeRow本体と新規/評価kernelの同体を確認します。
//
// 引数: t(*testing.T)。返り値: なし。固定ソースだけを読み自然入力を開きません。
func TestFrozen121ReaderAndFinancialKernel122(t *testing.T) {
	for _, name := range []string{"reader.go", "types.go"} {
		old, err := os.ReadFile(filepath.Join("../121入口比較", name))
		if err != nil {
			t.Fatal(err)
		}
		current, err := os.ReadFile(name)
		if err != nil {
			t.Fatal(err)
		}
		if !bytes.Equal(old, current) {
			t.Fatal("固定reader/types差", name)
		}
	}
	for _, name := range []string{"quote", "policy", "new", "fill", "pending"} {
		old := functionBody122(t, "../121入口比較/entry.go", name+"121")
		current := functionBody122(t, "entry.go", name+"122")
		if string(old) != strings.ReplaceAll(string(current), "122", "121") {
			t.Fatal("金融新規kernel差", name)
		}
	}
	old := functionBody122(t, "../121入口比較/outcome.go", "outcome121")
	current := functionBody122(t, "outcome.go", "outcome122")
	if string(old) != strings.ReplaceAll(string(current), "122", "121") {
		t.Fatal("固定期限kernel差")
	}
}
