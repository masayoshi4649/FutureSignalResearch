"""固定E0の全73場再生を、条件と入力の前後同体を守って実行する。"""
from pathlib import Path
import hashlib
import json
import subprocess
import sys

OWN=Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 全bytesのSHA256を計算する。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 二段階固定済みの入力から全73場を新規結果へ再生する。
    引数: なし。返り値: None。固定対照照合に失敗すれば完了を作らない。
    """
    a_path,b_path=OWN/'StageA.json',OWN/'StageB.json'
    a,b=json.loads(a_path.read_text(encoding='utf-8')),json.loads(b_path.read_text(encoding='utf-8'))
    assert a['fixed'] and b['fixed'] and a['trial']==b['trial']==122 and b['stage_a_sha256']==sha(a_path)
    expected=dict(a['code_sha256'])
    expected.update(a['premarket_documents'])
    expected.update({ref['path']:ref['sha256'] for ref in a['executables']})
    expected[b['input']['path']]=b['input']['sha256']
    assert all(sha(Path(p))==value for p,value in expected.items())
    output=OWN/'全73場の入口結果.json'
    assert not output.exists()
    executable=next(ref['path'] for ref in a['executables'] if Path(ref['path']).name=='入口比較.exe')
    command=[executable,'--input',b['input']['path'],'--sha256',b['input']['sha256'],'--output',str(output),'--workers','8']
    subprocess.run(command,cwd=OWN,check=True)
    assert all(sha(Path(p))==value for p,value in expected.items())
    result=json.loads(output.read_text(encoding='utf-8'))
    assert result['success'] and result['trial']==122 and len(result['scenes'])==73 and all(s['success'] for s in result['scenes'])
    subprocess.run([sys.executable,'-X','utf8',str(OWN/'既知対照を確認する.py')],cwd=OWN,check=True)
    proof={'成功':True,'試行':122,'StageA_SHA256':sha(a_path),'StageB_SHA256':sha(b_path),'入力SHA256':b['input']['sha256'],'場数':73,'既知場数':70,'追加場数':3,'全場同一固定条件':True,'コード入力前後不変':True,'コード入力SHA256':expected,'既知70固定対照成功':True,'結果':{'path':str(output),'sha256':sha(output)},'コマンド':command,'数値目標':'E0の60分±100pt先着率>=70%。再現性課題とは分けて判定。','11月09':'StageA後に全場指定に従って読取・検証','IFD実約定/運用口座':False}
    with (OWN/'全73場の完了.json').open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'成功':True,'結果SHA256':sha(output),'完了SHA256':sha(OWN/'全73場の完了.json')},ensure_ascii=False))


if __name__=='__main__':
    main()
