"""旧70の同じ公表と、新3場の同モデル公表を一つの入力へ結合する。"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
OWN=ROOT/'work/122全場入力'


def sha(path: Path) -> str:
    """
    機能: 全bytesのSHA256を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 既知公表全値照合と指紋を認証し、全73の市場入力を新規保存する。
    引数: なし。返り値: None。売買候補・勝敗は計算しない。
    """
    plan_path=OWN/'公表生成計画.json'
    old_path=ROOT/'work/118入口比較/入力.json'
    known_path=OWN/'既知公表照合.json'
    new_path=OWN/'新規公表.json'
    before={str(p):sha(p) for p in (plan_path,old_path,known_path,new_path)}
    assert before[str(old_path)]=='574771f654937036b48c78eceadb46a4c5ff3c10265f60b0ec7879efb0d862c3'
    plan=json.loads(plan_path.read_text(encoding='utf-8'))
    old=json.loads(old_path.read_text(encoding='utf-8'))
    known=json.loads(known_path.read_text(encoding='utf-8'))
    new=json.loads(new_path.read_text(encoding='utf-8'))
    for part,mode in ((known,'known'),(new,'new')):
        assert part['trial']==122 and part['success'] and part['mode']==mode and part['plan_sha256']==sha(plan_path)
        assert not part['financial_calculation'] and not part['raw_eof_seed_carried']
    assert len(known['scenes'])==len(plan['known_checks']) and all(s['golden_equal'] for s in known['scenes'])
    old_map={s['session']:s for s in old['scenes']}
    new_map={s['session']:s for s in new['scenes']}
    assert set(new_map)==set(plan['new_sessions']) and len(new_map)==3
    scenes=[]
    for i,declared in enumerate(plan['history']):
        sid=declared['session']
        if i<70:
            source=old_map[sid]
            scene={k:source[k] for k in ('session','contract','start','end','force_close','raw','expected_accepted','publications')}
            scene['expected_quality']=declared['expected_quality']
            assert all(scene[k]==declared[k] for k in ('session','contract','start','end','force_close'))
            assert scene['raw']['path']==declared['raw']['path'] and scene['raw']['sha256']==declared['raw']['sha256']
        else:
            source=new_map[sid]
            assert source['actual_sha256']==declared['raw']['sha256']
            assert source['stat_before']==source['stat_after']
            assert all(source[k]==declared[k] for k in ('session','contract','start','end','force_close'))
            quality=source['quality']
            assert quality['source_parser_accepted']==quality['source_delivered']>0
            scene={k:declared[k] for k in ('session','contract','start','end','force_close','raw')}
            scene.update(expected_accepted=quality['source_parser_accepted'],expected_quality=quality,publications=source.get('publications',[]))
            assert len(scene['publications'])==source['publication_count']
        scenes.append(scene)
    assert len(scenes)==73 and sum(len(s['publications']) for s in scenes[:70])==12320
    value={'trial':122,'purpose':'固定E0を全73場で検証・他5政策は固定対照','stage_a_sha256':plan['stage_a_sha256'],'plan_sha256':sha(plan_path),'legacy_input_sha256':sha(old_path),'scenes':scenes}
    output=OWN/'入力.json'
    with output.open('x',encoding='utf-8',newline='\n') as stream:
        json.dump(value,stream,ensure_ascii=False,indent=2)
        stream.write('\n')
    assert before=={p:sha(Path(p)) for p in before}
    proof={'成功':True,'試行':122,'入力':{'path':str(output),'sha256':sha(output),'bytes':output.stat().st_size},'場数':73,'旧場数':70,'新規場数':3,'公表数':sum(len(s['publications']) for s in scenes),'旧70公表JSON同体':True,'既知公表配送再生成照合':len(known['scenes']),'全場品質期待値あり':True,'依存前後SHA256':before,'依存前後不変':True,'金融結果読取/計算':False}
    with (OWN/'入力結合の確認.json').open('x',encoding='utf-8',newline='\n') as stream:
        stream.write(json.dumps(proof,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
