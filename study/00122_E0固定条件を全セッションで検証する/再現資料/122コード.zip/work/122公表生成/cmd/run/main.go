package main

import (
	"flag"
	"fmt"
	"os"
	pub "publicationexport122"
)

// main はRootがF1を固定した公表生成だけを開始します。
//
// 引数: plan/sha256/mode/output(string)、bytes(int64)。返り値: ありません。
func main() {
	p := flag.String("plan", "", "固定計画")
	s := flag.String("sha256", "", "計画SHA256")
	n := flag.Int64("bytes", 0, "計画bytes")
	m := flag.String("mode", "", "known/new")
	o := flag.String("output", "", "未作成出力")
	flag.Parse()
	if e := pub.Run(pub.FileRef{Path: *p, SHA256: *s, Bytes: *n}, *m, *o); e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
}
