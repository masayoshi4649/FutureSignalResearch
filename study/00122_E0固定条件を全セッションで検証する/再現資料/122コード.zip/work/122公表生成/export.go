package publicationexport122

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"reflect"
	"sort"

	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	bank "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
	input "github.com/masayoshi4649/SessionTradeExecuter/threeframeinput"
)

// csvChildren は115と同じ入力口で固定子足と前後証拠を作ります。
//
// 引数: s(Scene)。返り値: []frame.ChildBar/CSVProof/errorです。
func csvChildren(s Scene) ([]frame.ChildBar, CSVProof, error) {
	out := CSVProof{Ref: s.CSV}
	before, e := stat(s.CSV)
	if e != nil {
		return nil, out, e
	}
	out.Before = before
	loaded, e := input.LoadChildren(chartScene(s), frame.FileRef{Path: s.CSV.Path, SHA256: s.CSV.SHA256, Bytes: s.CSV.Bytes})
	if e != nil {
		return nil, out, e
	}
	after, e := stat(s.CSV)
	if e != nil {
		return nil, out, e
	}
	out.After = after
	if before != after {
		return nil, out, fmt.Errorf("CSV前後stat差")
	}
	raw, e := json.Marshal(loaded.Bars)
	if e != nil {
		return nil, out, e
	}
	out.Children = len(loaded.Bars)
	out.ChildrenSHA256 = sum(raw)
	return loaded.Bars, out, nil
}

// chartScene は115と同じ予定EOFを子ID・足計画に使います。
//
// 引数: s(Scene)。返り値: frame.Sessionです。実Raw末尾へEOFを縮めません。
func chartScene(s Scene) frame.Session {
	return frame.Session{ID: s.Session, Contract: s.Contract, Start: s.Start, End: s.End, EOF: s.End}
}

// seedInfo はnilのcold種とsealed種を区別します。
//
// 引数: seed(*bank.Seed)。返り値: *bank.SeedInfoは私有値です。
func seedInfo(seed *bank.Seed) *bank.SeedInfo {
	if seed == nil {
		return nil
	}
	x := seed.Info()
	return &x
}

// scheduledSeed は当場のRaw末尾によらず115の予定Endまでだけ前史を進めます。
//
// 引数: s(Scene)、children([]frame.ChildBar)、previous(*bank.Seed)。返り値: bank.Seed/errorです。
func scheduledSeed(s Scene, children []frame.ChildBar, previous *bank.Seed) (bank.Seed, error) {
	b, e := bank.BeginSession(chartScene(s), children, previous)
	if e != nil {
		return bank.Seed{}, e
	}
	if _, e = b.AdvanceObserved(s.End, 1); e != nil {
		return bank.Seed{}, e
	}
	next, _, e := b.Seal()
	return next, e
}

// canonical は未使用項目も含むJSON全値を共通のbytesへ符号化します。
//
// 引数: data([]byte)。返り値: []byte/errorです。元の空白やキー順だけを正規化します。
func canonical(data []byte) ([]byte, error) {
	var x any
	if e := json.Unmarshal(data, &x); e != nil {
		return nil, e
	}
	return json.Marshal(x)
}

// compareGolden は元配列の未知・未使用キーも落とさず完全JSON値を比較します。
//
// 引数: actual([]Publication)、golden(json.RawMessage)。返り値: actualSHA/goldenSHA(string)とerrorです。
func compareGolden(actual []Publication, golden json.RawMessage) (string, string, error) {
	a, e := json.Marshal(actual)
	if e != nil {
		return "", "", e
	}
	a, e = canonical(a)
	if e != nil {
		return "", "", e
	}
	b, e := canonical(golden)
	if e != nil {
		return "", "", e
	}
	if !reflect.DeepEqual(a, b) {
		return sum(a), sum(b), fmt.Errorf("115公表の全JSON値差")
	}
	return sum(a), sum(b), nil
}

// exportSession はRawを一度だけ走査し、受理原行へ5/15/30分公表を配送します。
//
// 引数: s(Scene)、children([]frame.ChildBar)、csv(CSVProof)、seed(*bank.Seed)。
// 返り値: ExportResult/errorです。金融Source・売買・Nativeは実行しません。
func exportSession(s Scene, children []frame.ChildBar, csv CSVProof, seed *bank.Seed) (out ExportResult, err error) {
	out = ExportResult{Session: s.Session, Contract: s.Contract, Start: s.Start, End: s.End, ForceClose: s.ForceClose, Raw: s.Raw, CSV: csv, InputSeed: seedInfo(seed), Publications: []Publication{}, RawPasses: 1}
	b, e := bank.BeginSession(chartScene(s), children, seed)
	if e != nil {
		return out, e
	}
	before, e := stat(s.Raw)
	if e != nil {
		return out, e
	}
	out.Before = before
	f, e := os.Open(s.Raw.Path)
	if e != nil {
		return out, e
	}
	defer f.Close()
	opened, e := f.Stat()
	if e != nil {
		return out, e
	}
	if (FileStat{opened.Size(), opened.ModTime().UnixNano()}) != before {
		return out, fmt.Errorf("Raw open直後stat差")
	}
	h := sha256.New()
	tee := io.TeeReader(f, h)
	compressed := bufio.NewReader(tee)
	magic, e := compressed.Peek(2)
	if e != nil {
		return out, e
	}
	var reader io.Reader = compressed
	if magic[0] == 0x1f && magic[1] == 0x8b {
		z, e := gzip.NewReader(compressed)
		if e != nil {
			return out, e
		}
		defer z.Close()
		reader = z
		out.Compression = "gzip"
	} else {
		out.Compression = "jsonl"
	}
	scan := bufio.NewScanner(reader)
	scan.Buffer(make([]byte, 65536), 8*1024*1024)
	previous := s.Start
	var index int64
	contracts := map[string]bool{}
	for scan.Scan() {
		out.Quality.Lines++
		q, _, next, e := decodeRow(scan.Bytes(), out.Quality.Lines, index, s, previous, &out.Quality, contracts)
		previous = next
		if e != nil {
			return out, e
		}
		if q == nil {
			continue
		}
		index++
		frames, e := b.AdvanceObserved(q.Time, uint64(q.Index)+1)
		if e != nil {
			return out, e
		}
		for _, p := range frames {
			out.Publications = append(out.Publications, Publication{Stamp: Stamp{q.Time, q.Index, q.SourceLine}, Frame: p})
		}
	}
	if e = scan.Err(); e != nil {
		return out, e
	}
	if _, e = io.Copy(io.Discard, compressed); e != nil {
		return out, e
	}
	if out.Quality.Delivered == 0 {
		return out, fmt.Errorf("受理原行がない")
	}
	info, e := f.Stat()
	if e != nil {
		return out, e
	}
	out.After = FileStat{info.Size(), info.ModTime().UnixNano()}
	pathAfter, e := stat(s.Raw)
	if e != nil {
		return out, e
	}
	out.ActualSHA = hex.EncodeToString(h.Sum(nil))
	if out.ActualSHA != s.Raw.SHA256 || out.Before != out.After || out.After != pathAfter {
		return out, fmt.Errorf("Raw指紋又は前後stat差")
	}
	if len(contracts) != 1 || !contracts[s.Contract] {
		names := []string{}
		for c := range contracts {
			names = append(names, c)
		}
		sort.Strings(names)
		return out, fmt.Errorf("Raw限月差:%v", names)
	}
	if s.ExpectedAccepted != nil && index != *s.ExpectedAccepted {
		return out, fmt.Errorf("期待受理数差")
	}
	if s.ExpectedQuality != nil && out.Quality != *s.ExpectedQuality {
		return out, fmt.Errorf("期待quality差")
	}
	endSeed, _, e := b.Seal()
	if e != nil {
		return out, e
	}
	out.RawEndSeed = endSeed.Info()
	data, e := json.Marshal(out.Publications)
	if e != nil {
		return out, e
	}
	data, e = canonical(data)
	if e != nil {
		return out, e
	}
	out.PublicationCount = len(out.Publications)
	out.PublicationSHA = sum(data)
	return out, nil
}

// Export は旧70のprefixを固定し、known検査又は新3場の公表だけを生成します。
//
// 引数: p(Plan)、old(LegacyInput)、mode(string)。返り値: Result/errorです。
// knownは新3場のCSV/Rawを開かず、次場へ渡すのは予定End種だけです。
func Export(p Plan, old LegacyInput, mode string) (out Result, err error) {
	if e := validate(p, old); e != nil {
		return out, e
	}
	if mode != "known" && mode != "new" {
		return out, fmt.Errorf("modeはknown/new")
	}
	out = Result{Trial: 122, Mode: mode, Model: Model, History: []HistoryProof{}, Scenes: []ExportResult{}, LegacyReused: mode == "new"}
	selected := map[string]bool{}
	golden := map[string]json.RawMessage{}
	for _, s := range old.Scenes {
		golden[s.Session] = s.RawPublications
	}
	ids := p.NewSessions
	last := len(p.History) - 1
	if mode == "known" {
		ids = p.KnownChecks
		last = -1
		for i, s := range p.History[:70] {
			for _, id := range ids {
				if s.Session == id && i > last {
					last = i
				}
			}
		}
	}
	for _, id := range ids {
		selected[id] = true
	}
	var previous *bank.Seed
	for i, s := range p.History {
		if i > last {
			break
		}
		children, csv, e := csvChildren(s)
		if e != nil {
			return out, fmt.Errorf("%s:%w", s.Session, e)
		}
		if selected[s.Session] {
			value, e := exportSession(s, children, csv, previous)
			if e != nil {
				return out, fmt.Errorf("%s:%w", s.Session, e)
			}
			if mode == "known" {
				a, b, e := compareGolden(value.Publications, golden[s.Session])
				if e != nil {
					return out, fmt.Errorf("%s:%w", s.Session, e)
				}
				yes := true
				value.PublicationSHA, value.GoldenSHA, value.GoldenEqual = a, b, &yes
			}
			out.Scenes = append(out.Scenes, value)
		}
		next, e := scheduledSeed(s, children, previous)
		if e != nil {
			return out, fmt.Errorf("%s:%w", s.Session, e)
		}
		out.History = append(out.History, HistoryProof{Session: s.Session, Contract: s.Contract, CSV: csv, InputSeed: seedInfo(previous), ScheduledEndSeed: next.Info()})
		previous = &next
	}
	if len(out.Scenes) != len(ids) {
		return out, fmt.Errorf("対象公表場の欠落")
	}
	out.Success = true
	return out, nil
}

// Run はRoot F1後にだけ呼ぶ入口で、固定planから未作成成果物へ保存します。
//
// 引数: plan(FileRef)、mode/output(string)。返り値: errorは入力/公表/保存不整合です。
func Run(plan FileRef, mode, output string) error {
	if _, e := os.Stat(output); !os.IsNotExist(e) {
		return fmt.Errorf("出力は未作成先だけ")
	}
	p, old, e := LoadPlan(plan)
	if e != nil {
		return e
	}
	out, e := Export(p, old, mode)
	if e != nil {
		return e
	}
	out.PlanSHA = plan.SHA256
	if _, _, e = LoadPlan(plan); e != nil {
		return e
	}
	data, e := json.MarshalIndent(out, "", "  ")
	if e != nil {
		return e
	}
	f, e := os.OpenFile(output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		return e
	}
	defer f.Close()
	_, e = f.Write(append(data, '\n'))
	return e
}
