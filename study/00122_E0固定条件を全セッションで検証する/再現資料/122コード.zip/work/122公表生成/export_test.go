package publicationexport122

import (
	"bytes"
	"compress/gzip"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// saveArtificial は人工bytesを未作成のtest専用ファイルへ保存します。
//
// 引数: t(*testing.T)、path(string)、data([]byte)。返り値: FileRefです。
func saveArtificial(t *testing.T, path string, data []byte) FileRef {
	t.Helper()
	if e := os.WriteFile(path, data, 0600); e != nil {
		t.Fatal(e)
	}
	return FileRef{Path: path, SHA256: sum(data), Bytes: int64(len(data))}
}

// artificialScene は全日CSVと3原行だけの人工場を作ります。
//
// 引数: t(*testing.T)、compressed(bool)。返り値: Sceneです。自然ファイルは読みません。
func artificialScene(t *testing.T, compressed bool) Scene {
	t.Helper()
	directory := t.TempDir()
	start, end, force, e := sessionClock("2026-09-21_Day")
	if e != nil {
		t.Fatal(e)
	}
	s := Scene{Session: "2026-09-21_Day", Contract: "X", Start: start, End: end, ForceClose: force}
	var csv bytes.Buffer
	csv.WriteString("time,open,high,low,close,volume,volume_complete,closed\n")
	for at := start; at < end; at += 300 {
		fmt.Fprintf(&csv, "%s,100,110,90,100,100,true,true\n", time.Unix(int64(at), 0).UTC().Format(time.RFC3339))
	}
	s.CSV = saveArtificial(t, filepath.Join(directory, "人工.csv"), csv.Bytes())
	var raw bytes.Buffer
	for i, at := range []float64{start, start + 360, start + 960} {
		x := map[string]any{"Symbol": "X", "CurrentPrice": 100 + i, "CurrentPriceTime": time.Unix(int64(at), 0).UTC().Format(time.RFC3339)}
		for d := 1; d <= 10; d++ {
			x[fmt.Sprintf("Buy%d", d)] = map[string]float64{"Price": 95, "Qty": 1}
			x[fmt.Sprintf("Sell%d", d)] = map[string]float64{"Price": 105, "Qty": 1}
		}
		data, e := json.Marshal(x)
		if e != nil {
			t.Fatal(e)
		}
		raw.Write(data)
		raw.WriteByte('\n')
	}
	data := raw.Bytes()
	name := "人工.jsonl"
	if compressed {
		var encoded bytes.Buffer
		z := gzip.NewWriter(&encoded)
		if _, e = z.Write(data); e != nil {
			t.Fatal(e)
		}
		if e = z.Close(); e != nil {
			t.Fatal(e)
		}
		data = encoded.Bytes()
		name += ".gz"
	}
	s.Raw = saveArtificial(t, filepath.Join(directory, name), data)
	n := int64(3)
	s.ExpectedAccepted = &n
	return s
}

// TestPlainGzipAndPublicationOrder122 は圧縮違いの同値公表と実配送順を検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestPlainGzipAndPublicationOrder122(t *testing.T) {
	s := artificialScene(t, false)
	children, csv, e := csvChildren(s)
	if e != nil {
		t.Fatal(e)
	}
	a, e := exportSession(s, children, csv, nil)
	if e != nil {
		t.Fatal(e)
	}
	if a.Quality.Lines != 3 || a.Quality.Delivered != 3 || a.PublicationCount != 4 || a.Compression != "jsonl" || a.Before != a.After {
		t.Fatal("人工counts/公表数/保存差")
	}
	widths := []int{300, 300, 300, 900}
	for i, p := range a.Publications {
		if p.Frame.Frame.WidthSeconds != widths[i] || p.Stamp.Index != []int64{1, 2, 2, 2}[i] || p.Stamp.Line != []int64{2, 3, 3, 3}[i] || p.Frame.Frame.DeliveryAt != p.Stamp.Time || p.Frame.Frame.RecordOrdinal != uint64(p.Stamp.Index)+1 {
			t.Fatal("公表の実配送順差")
		}
	}
	plain, e := os.ReadFile(s.Raw.Path)
	if e != nil {
		t.Fatal(e)
	}
	var encoded bytes.Buffer
	z := gzip.NewWriter(&encoded)
	z.Write(plain)
	z.Close()
	s.Raw = saveArtificial(t, filepath.Join(t.TempDir(), "人工.gz"), encoded.Bytes())
	b, e := exportSession(s, children, csv, nil)
	if e != nil {
		t.Fatal(e)
	}
	if b.Compression != "gzip" || a.Quality != b.Quality || a.PublicationSHA != b.PublicationSHA {
		t.Fatal("gzip/plain公表差")
	}
}

// TestScheduledSeedNotRawEOF122 は予定End種とRaw末尾種を取り違えないことを検査します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestScheduledSeedNotRawEOF122(t *testing.T) {
	s := artificialScene(t, false)
	children, csv, e := csvChildren(s)
	if e != nil {
		t.Fatal(e)
	}
	actual, e := exportSession(s, children, csv, nil)
	if e != nil {
		t.Fatal(e)
	}
	scheduled, e := scheduledSeed(s, children, nil)
	if e != nil {
		t.Fatal(e)
	}
	if actual.RawEndSeed.Old.HistoryBars != [3]uint64{3, 1, 0} || scheduled.Info().Old.HistoryBars != [3]uint64{83, 27, 13} || scheduled.Info().SHA256 == actual.RawEndSeed.SHA256 {
		t.Fatal("RawEOF種と予定End種の混同")
	}
	if actual.InputSeed != nil {
		t.Fatal("coldに前史")
	}
	if chartScene(s).EOF != s.End {
		t.Fatal("EOFをRaw末尾へ変更")
	}
}

// TestGoldenFullJSONAndInputFailures122 は未使用項目・SHA・限月・qualityの差を拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func TestGoldenFullJSONAndInputFailures122(t *testing.T) {
	s := artificialScene(t, true)
	children, csv, e := csvChildren(s)
	if e != nil {
		t.Fatal(e)
	}
	a, e := exportSession(s, children, csv, nil)
	if e != nil {
		t.Fatal(e)
	}
	gold, e := json.Marshal(a.Publications)
	if e != nil {
		t.Fatal(e)
	}
	if _, _, e = compareGolden(a.Publications, gold); e != nil {
		t.Fatal(e)
	}
	var changed []map[string]any
	json.Unmarshal(gold, &changed)
	changed[0]["未使用の追加キー"] = true
	bad, _ := json.Marshal(changed)
	if _, _, e = compareGolden(a.Publications, bad); e == nil {
		t.Fatal("原公表の未知キーを落として一致")
	}
	wrong := s
	wrong.Contract = "Y"
	if _, e = exportSession(wrong, children, csv, nil); e == nil {
		t.Fatal("異限月を受理")
	}
	wrong = s
	quality := a.Quality
	quality.BadBBO++
	wrong.ExpectedQuality = &quality
	if _, e = exportSession(wrong, children, csv, nil); e == nil {
		t.Fatal("quality差を受理")
	}
	wrong = s
	wrong.Raw.SHA256 = fmt.Sprintf("%064d", 0)
	if _, e = exportSession(wrong, children, csv, nil); e == nil {
		t.Fatal("RawSHA差を受理")
	}
	wrong = s
	wrong.CSV.SHA256 = fmt.Sprintf("%064d", 0)
	if _, _, e = csvChildren(wrong); e == nil {
		t.Fatal("CSV SHA差を受理")
	}
}

// TestKnownModeDoesNotOpenFuture122 はknownの前史上限と新3場を開かないことを検査します。
//
// 引数: t(*testing.T)。返り値: ありません。旧12320件の母数は人工ダミーで市場値ではありません。
func TestKnownModeDoesNotOpenFuture122(t *testing.T) {
	s := artificialScene(t, false)
	children, csv, e := csvChildren(s)
	if e != nil {
		t.Fatal(e)
	}
	current, e := exportSession(s, children, csv, nil)
	if e != nil {
		t.Fatal(e)
	}
	meta := FileRef{Path: filepath.Join(t.TempDir(), "存在しないmetadata"), SHA256: fmt.Sprintf("%064d", 0), Bytes: 1}
	p := Plan{Version: 122, Anchor: s.Session, LegacyInput: FileRef{SHA256: LegacyInputSHA}, LegacyManifest: meta, RawEquivalence: meta, KnownChecks: []string{s.Session}}
	old := LegacyInput{}
	day, e := time.Parse("2006-01-02", "2026-09-21")
	if e != nil {
		t.Fatal(e)
	}
	for i := 0; i < 73; i++ {
		kind := "Day"
		if i%2 == 1 {
			kind = "Night"
		}
		id := day.AddDate(0, 0, i/2).Format("2006-01-02") + "_" + kind
		begin, end, force, e := sessionClock(id)
		if e != nil {
			t.Fatal(e)
		}
		x := Scene{Session: id, Contract: "X", Start: begin, End: end, ForceClose: force, Raw: meta, CSV: meta}
		if i == 0 {
			x = s
		}
		p.History = append(p.History, x)
		if i < 70 {
			l := LegacyScene{Session: id, Contract: "X", Start: begin, End: end, ForceClose: force}
			if i == 0 {
				l.Publications = current.Publications
				l.RawPublications, _ = json.Marshal(current.Publications)
			}
			if i == 69 {
				l.Publications = make([]Publication, 12320-len(current.Publications))
			}
			old.Scenes = append(old.Scenes, l)
		} else {
			p.NewSessions = append(p.NewSessions, id)
		}
	}
	out, e := Export(p, old, "known")
	if e != nil {
		t.Fatal(e)
	}
	if !out.Success || len(out.History) != 1 || len(out.Scenes) != 1 || out.Scenes[0].GoldenEqual == nil || !*out.Scenes[0].GoldenEqual || out.RawEOFSeedCarried || out.FinancialCalculation {
		t.Fatal("known前史上限・金融非実行差")
	}
	_, _, force, e := sessionClock("2026-09-21_Night")
	if e != nil {
		t.Fatal(e)
	}
	end := float64(time.Date(2026, 9, 22, 6, 0, 0, 0, time.FixedZone("JST", 9*3600)).Unix())
	if force != end-600 {
		t.Fatal("Source ForceClose差")
	}
}
