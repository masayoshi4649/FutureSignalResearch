package publicationexport122

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"
)

// sum は同じ保存bytesをSHA256へ結びます。
//
// 引数: data([]byte)。返り値: string型の小文字SHA256です。
func sum(data []byte) string { x := sha256.Sum256(data); return hex.EncodeToString(x[:]) }

// UnmarshalJSON は旧公表の未使用項目も含む原JSONを私有保存します。
//
// 引数: data([]byte)。返り値: errorは旧入力の形式不正です。
func (s *LegacyScene) UnmarshalJSON(data []byte) error {
	type alias LegacyScene
	var a alias
	if e := json.Unmarshal(data, &a); e != nil {
		return e
	}
	var raw map[string]json.RawMessage
	if e := json.Unmarshal(data, &raw); e != nil {
		return e
	}
	*s = LegacyScene(a)
	s.RawPublications = append(json.RawMessage{}, raw["publications"]...)
	return nil
}

// validRef はRootが固定した絶対path・size・SHAだけを受けます。
//
// 引数: f(FileRef)。返り値: boolは正常な宣言です。本文は読みません。
func validRef(f FileRef) bool {
	if !filepath.IsAbs(f.Path) || f.Bytes <= 0 || len(f.SHA256) != 64 {
		return false
	}
	for _, c := range f.SHA256 {
		if !strings.ContainsRune("0123456789abcdef", c) {
			return false
		}
	}
	return true
}

// stat はファイルの内容を開かず固定参照と前後statを照合します。
//
// 引数: f(FileRef)。返り値: FileStat/errorは実size/更新時計又は不一致です。
func stat(f FileRef) (FileStat, error) {
	if !validRef(f) {
		return FileStat{}, fmt.Errorf("絶対path/size/SHA宣言が不正")
	}
	i, e := os.Stat(f.Path)
	if e != nil {
		return FileStat{}, e
	}
	s := FileStat{i.Size(), i.ModTime().UnixNano()}
	if s.Bytes != f.Bytes || (f.ModTimeNS != 0 && s.ModTimeNS != f.ModTimeNS) {
		return s, fmt.Errorf("固定size/stat差")
	}
	return s, nil
}

// readRef は固定済みmetadataだけを同bytesで認証します。
//
// 引数: f(FileRef)。返り値: []byte/errorは認証済み本文又は不整合です。
func readRef(f FileRef) ([]byte, error) {
	a, e := stat(f)
	if e != nil {
		return nil, e
	}
	data, e := os.ReadFile(f.Path)
	if e != nil {
		return nil, e
	}
	b, e := stat(f)
	if e != nil {
		return nil, e
	}
	if a != b || int64(len(data)) != f.Bytes || sum(data) != f.SHA256 {
		return nil, fmt.Errorf("metadata指紋又は前後差")
	}
	return data, nil
}

// sessionClock はSource111と同じJST場時計と終了10分前のForceCloseを返します。
//
// 引数: id(string)。返り値: 開始/終了/ForceClose(float64)とerrorです。
func sessionClock(id string) (float64, float64, float64, error) {
	p := strings.Split(id, "_")
	if len(p) != 2 {
		return 0, 0, 0, fmt.Errorf("場名形式差")
	}
	d, e := time.ParseInLocation("2006-01-02", p[0], time.FixedZone("JST", 9*3600))
	if e != nil {
		return 0, 0, 0, e
	}
	var begin, end time.Time
	if p[1] == "Day" {
		begin = d.Add(8*time.Hour + 45*time.Minute)
		end = d.Add(15*time.Hour + 45*time.Minute)
	} else if p[1] == "Night" {
		begin = d.Add(17 * time.Hour)
		end = d.Add(30 * time.Hour)
	} else {
		return 0, 0, 0, fmt.Errorf("Day/Night以外")
	}
	return float64(begin.Unix()), float64(end.Unix()), float64(end.Unix() - 600), nil
}

// validate は旧70のanchorと追加3場・固定参照をmetadataで照合します。
//
// 引数: p(Plan)、old(LegacyInput)。返り値: errorは無許可の前史変更又は入力不足です。
func validate(p Plan, old LegacyInput) error {
	if p.Version != 122 || p.Anchor != "2026-09-21_Day" || p.LegacyInput.SHA256 != LegacyInputSHA || len(old.Scenes) != 70 || len(p.History) != 73 || len(p.NewSessions) != 3 || len(p.KnownChecks) == 0 || !validRef(p.LegacyManifest) || !validRef(p.RawEquivalence) {
		return fmt.Errorf("122固定範囲/anchor/旧入力/追加3場差")
	}
	seen := map[string]bool{}
	previous := 0.0
	pubs := 0
	for i, s := range p.History {
		begin, end, force, e := sessionClock(s.Session)
		if e != nil {
			return e
		}
		if seen[s.Session] || s.Start != begin || s.End != end || s.ForceClose != force || s.Start <= previous || s.Contract == "" || !validRef(s.Raw) || !validRef(s.CSV) || s.Cutoff != 0 {
			return fmt.Errorf("場時計/順序/参照差:%s", s.Session)
		}
		seen[s.Session] = true
		previous = s.End
		if i < 70 {
			l := old.Scenes[i]
			if s.Session != l.Session || s.Contract != l.Contract || s.Start != l.Start || s.End != l.End || s.ForceClose != l.ForceClose {
				return fmt.Errorf("旧70前史差:%d", i)
			}
			pubs += len(l.Publications)
		} else if p.NewSessions[i-70] != s.Session {
			return fmt.Errorf("追加3場の末尾順差")
		}
	}
	if p.History[0].Session != p.Anchor || pubs != 12320 {
		return fmt.Errorf("旧12320公表/anchor差")
	}
	checks := map[string]bool{}
	for _, id := range p.KnownChecks {
		exists := false
		for _, s := range old.Scenes {
			if s.Session == id {
				exists = true
			}
		}
		if !exists || checks[id] {
			return fmt.Errorf("既知検査の場が不正")
		}
		checks[id] = true
	}
	return nil
}

// validateManifest は旧70のCSV参照を106の元path表現まで完全照合します。
//
// 引数: p(Plan)、data([]byte)は指紋認証済み106metadata。返り値: errorは宣言差です。
func validateManifest(p Plan, data []byte) error {
	var m struct {
		Root     string `json:"source_root"`
		Sessions []struct {
			ID       string `json:"id"`
			Contract string `json:"contract"`
			Files    map[string]struct {
				Path   string `json:"path"`
				SHA256 string `json:"sha256"`
				Size   int64  `json:"size"`
			} `json:"files"`
		} `json:"sessions"`
	}
	if e := json.Unmarshal(data, &m); e != nil {
		return e
	}
	if m.Root == "" || len(m.Sessions) != 70 || len(p.History) < 70 {
		return fmt.Errorf("106旧70metadata差")
	}
	for i, s := range m.Sessions {
		f, ok := s.Files["NK225_candle_300"]
		current := p.History[i]
		if !ok || s.ID != current.Session || s.Contract != current.Contract || current.CSV.Path != filepath.Join(m.Root, filepath.FromSlash(f.Path)) || current.CSV.SHA256 != f.SHA256 || current.CSV.Bytes != f.Size {
			return fmt.Errorf("106旧CSV参照差:%d", i)
		}
	}
	return nil
}

// LoadPlan は指紋固定された計画と旧入力・由来metadataを認証します。
//
// 引数: f(FileRef)。返り値: Plan/LegacyInput/errorです。RawとCSV本文は開きません。
func LoadPlan(f FileRef) (Plan, LegacyInput, error) {
	var p Plan
	var old LegacyInput
	data, e := readRef(f)
	if e != nil {
		return p, old, e
	}
	if e = json.Unmarshal(data, &p); e != nil {
		return p, old, e
	}
	data, e = readRef(p.LegacyInput)
	if e != nil {
		return p, old, e
	}
	if e = json.Unmarshal(data, &old); e != nil {
		return p, old, e
	}
	if e = validate(p, old); e != nil {
		return p, old, e
	}
	manifest, e := readRef(p.LegacyManifest)
	if e != nil {
		return p, old, e
	}
	if e = validateManifest(p, manifest); e != nil {
		return p, old, e
	}
	if _, e = readRef(p.RawEquivalence); e != nil {
		return p, old, e
	}
	return p, old, nil
}
