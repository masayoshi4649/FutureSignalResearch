package publicationexport122

import (
	"encoding/json"
	bank "github.com/masayoshi4649/SessionTradeExecuter/threeframe115"
)

const LegacyInputSHA = "574771f654937036b48c78eceadb46a4c5ff3c10265f60b0ec7879efb0d862c3"
const Model = "prior_csv_publications_through_scheduled_end_current_raw_delivery115"

type FileRef struct {
	Path      string `json:"path"`
	SHA256    string `json:"sha256"`
	Bytes     int64  `json:"bytes"`
	ModTimeNS int64  `json:"mod_time_ns,omitempty"`
}
type FileStat struct {
	Bytes     int64 `json:"bytes"`
	ModTimeNS int64 `json:"mod_time_ns"`
}
type Counts struct {
	Lines           int64 `json:"lines"`
	ClockMissing    int64 `json:"clock_missing"`
	ClockInvalid    int64 `json:"clock_invalid"`
	Outside         int64 `json:"outside_session"`
	Backward        int64 `json:"backward_clock"`
	LastNonPositive int64 `json:"last_non_positive"`
	LastNonFinite   int64 `json:"last_non_finite"`
	BadBBO          int64 `json:"bad_bbo"`
	Accepted        int64 `json:"source_parser_accepted"`
	CutoffExcluded  int64 `json:"cutoff_excluded"`
	Delivered       int64 `json:"source_delivered"`
}
type Quote struct {
	Clock      string  `json:"clock"`
	Time       float64 `json:"time"`
	Index      int64   `json:"index"`
	SourceLine int64   `json:"source_line"`
	Last       float64 `json:"last"`
	Bid        float64 `json:"bid"`
	Ask        float64 `json:"ask"`
	QuoteOK    bool    `json:"quote_ok"`
}
type Scene struct {
	Session          string  `json:"session"`
	Contract         string  `json:"contract"`
	Start            float64 `json:"start"`
	End              float64 `json:"end"`
	ForceClose       float64 `json:"force_close"`
	Cutoff           float64 `json:"-"`
	Raw              FileRef `json:"raw"`
	CSV              FileRef `json:"csv"`
	ExpectedAccepted *int64  `json:"expected_accepted,omitempty"`
	ExpectedQuality  *Counts `json:"expected_quality,omitempty"`
}
type Stamp struct {
	Time  float64 `json:"time"`
	Index int64   `json:"index"`
	Line  int64   `json:"source_line"`
}
type Publication struct {
	Stamp Stamp      `json:"stamp"`
	Frame bank.Frame `json:"frame"`
}
type LegacyScene struct {
	Session         string          `json:"session"`
	Contract        string          `json:"contract"`
	Start           float64         `json:"start"`
	End             float64         `json:"end"`
	ForceClose      float64         `json:"force_close"`
	Publications    []Publication   `json:"publications"`
	RawPublications json.RawMessage `json:"-"`
}
type LegacyInput struct {
	Scenes []LegacyScene `json:"scenes"`
}
type Plan struct {
	Version        int      `json:"version"`
	Anchor         string   `json:"anchor"`
	LegacyInput    FileRef  `json:"legacy_input"`
	LegacyManifest FileRef  `json:"legacy_manifest"`
	RawEquivalence FileRef  `json:"raw_equivalence"`
	History        []Scene  `json:"history"`
	KnownChecks    []string `json:"known_checks"`
	NewSessions    []string `json:"new_sessions"`
}
type CSVProof struct {
	Ref            FileRef  `json:"ref"`
	Before         FileStat `json:"stat_before"`
	After          FileStat `json:"stat_after"`
	Children       int      `json:"children"`
	ChildrenSHA256 string   `json:"children_sha256"`
}
type HistoryProof struct {
	Session          string         `json:"session"`
	Contract         string         `json:"contract"`
	CSV              CSVProof       `json:"csv"`
	InputSeed        *bank.SeedInfo `json:"input_seed"`
	ScheduledEndSeed bank.SeedInfo  `json:"scheduled_end_seed"`
}
type ExportResult struct {
	Session          string         `json:"session"`
	Contract         string         `json:"contract"`
	Start            float64        `json:"start"`
	End              float64        `json:"end"`
	ForceClose       float64        `json:"force_close"`
	Raw              FileRef        `json:"raw"`
	ActualSHA        string         `json:"actual_sha256"`
	Before           FileStat       `json:"stat_before"`
	After            FileStat       `json:"stat_after"`
	Compression      string         `json:"compression"`
	Quality          Counts         `json:"quality"`
	CSV              CSVProof       `json:"csv"`
	InputSeed        *bank.SeedInfo `json:"input_seed"`
	RawEndSeed       bank.SeedInfo  `json:"raw_end_seed"`
	Publications     []Publication  `json:"publications,omitempty"`
	PublicationCount int            `json:"publication_count"`
	PublicationSHA   string         `json:"publication_canonical_sha256"`
	GoldenSHA        string         `json:"golden_canonical_sha256,omitempty"`
	GoldenEqual      *bool          `json:"golden_equal,omitempty"`
	RawPasses        int            `json:"raw_passes"`
}
type Result struct {
	Trial                int            `json:"trial"`
	Success              bool           `json:"success"`
	Mode                 string         `json:"mode"`
	Model                string         `json:"model"`
	PlanSHA              string         `json:"plan_sha256"`
	History              []HistoryProof `json:"history"`
	Scenes               []ExportResult `json:"scenes"`
	FinancialCalculation bool           `json:"financial_calculation"`
	RawEOFSeedCarried    bool           `json:"raw_eof_seed_carried"`
	LegacyReused         bool           `json:"legacy_publications_reused"`
}
