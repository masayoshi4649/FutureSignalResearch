"""数量の公表時計・累積減少・未来改変・方向対称を検査する。"""
from pathlib import Path
import json
import numpy as np
import 数量188 as Q


def main():
    """
    機能: 期待値を手計算できる列から数量特徴と条件を検査する。
    引数: なし。
    返り値: None。検査数と成功をJSONへ残す。
    """
    t=np.arange(3600.,step=5);v=t*2
    d={'now':t,'line':np.arange(len(t))+1,'volume':v,'volume_time':t.copy()}
    base,qa=Q.quantities(d,0,3600);count=0
    for k in range(21,60):
        assert base[k]['amount']==120 and base[k]['relative']==1
        assert base[k]['endpoint_volume_age']==5
        count+=3
    # ----------------------------------------
    # 完成分を作った後の未来量を変更しても、過去の相対量へ遡及しない。
    for cut in (23*60,31*60,41*60):
        changed={k:v.copy() for k,v in d.items()};changed['volume'][t>=cut]*=777
        altered,_=Q.quantities(changed,0,3600)
        prefix={k:v[t<cut] for k,v in d.items()};old,_=Q.quantities(prefix,0,cut)
        for k in range(cut//60):
            assert base[k]==altered[k]==old[k];count+=1
    # ----------------------------------------
    # 未来の量時刻、量の欠測、累積リセットを既知0へ変えない。
    for mode in ('future','missing','reset','stale'):
        changed={k:v.copy() for k,v in d.items()};where=(t>=1800)&(t<1920)
        if mode=='future':changed['volume_time'][where]+=60
        elif mode=='missing':changed['volume'][where]=np.nan
        elif mode=='stale':changed['volume_time'][where]-=100
        else:changed['volume'][t>=1800]-=1800
        altered,_=Q.quantities(changed,0,3600)
        assert not altered[30]['known'];count+=1
    changed={k:v.copy() for k,v in d.items()};changed['volume'][t>=1800]=changed['volume'][t<1800][-1]
    zero,_=Q.quantities(changed,0,3600)
    assert zero[31]['amount']==0 and zero[31]['known'];count+=1
    # ----------------------------------------
    # 条件の方向対称、境界、未知保持。
    for r in (0,.25,.5,.8,1,3,3.01,10):
        for p in (None,.25,.5,.8,1,3,4):
            for known in (False,True):
                quantity={'known':known,'relative':r,'previous_relative':p}
                for mode in Q.MODES:
                    a=Q.allowed({'range':2,'side':1},quantity,mode)
                    b=Q.allowed({'range':2,'side':-1},quantity,mode)
                    assert a==b
                    if not known and mode!='Q0':assert not a
                    count+=1
    result={'成功':True,'検査数':count,'未来改変':True,'prefix同体':True,'累積リセット':True,
        '未来量時計と欠測は未知':True,'既知0を不明量と区別':True,'売買対称':True}
    path=Path(__file__).with_name('人工確認188.json')
    path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':main()
