"""同じ価格入口へ、当時観測できた累積量の差分と持続を重ねる。"""
from pathlib import Path
import gzip
import json
import math
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
MODES=('Q0','QK','QR','QP','QB','QC')
DESCRIPTIONS={
    'Q0':'数量なし。187と同じ方向・q0を完全再現する。',
    'QK':'当該1分と直前20分の量差分が既知で、平均が正のときだけ許可。量水準を問わない。',
    'QR':'QKかつ当該相対量0.8以上3以下。異常な一発量を除く。',
    'QP':'QKかつ当該/直前1分の相対量とも0.8以上3以下。2分持続を確認。',
    'QB':'QKかつ当該相対量0.5以上3以下、直前相対量0.25以上1以下、当該>直前。小量の後の回復。',
    'QC':'QKかつ相対量3超かつ足幅/ATR5が1.5超の同時スパイクだけ棄却。'}


def read(path):
    """
    機能: 日本語JSON又はgzip JSONを読む。
    引数: path(Path)。
    返り値: objectは解析値。
    """
    raw=path.read_bytes()
    return json.loads(gzip.decompress(raw) if path.suffix=='.gz' else raw)


def sources(product):
    """
    機能: 共用の恒久8列台帳を標準形へ揃える。
    引数: product(str)はNK225又はTOPIX。
    返り値: tuple[Path,list[dict]]は台帳と場別入力。
    """
    folder=ROOT/'inputs'/f'{product}原順8列_20260921_20261116'
    path=folder/('入力台帳.json.gz' if product=='NK225' else '台帳.json')
    raw=read(path)
    entries=raw['entries']
    return path,[{'session':r['session'],'path':r.get('cache_relative',r.get('path')),
                 'sha256':r.get('sha256_cache',r.get('sha256'))} for r in entries]


def quantities(data,start,end):
    """
    機能: 原行順・価格時計で既知だった累積量の差分を1分単位へ変換する。
    引数: data(dict[str,np.ndarray])は8列、start/end(float)は場の対象時計。
    返り値: tuple[dict[int,dict],dict]は完成分の量と品質。未来の量を過去へ配らない。
    """
    now=data['now'];volume=data['volume'];vt=data['volume_time'];line=data['line']
    finite=np.isfinite(now);prior=np.maximum.accumulate(np.where(finite,now,-np.inf))
    monotonic=finite&(now>=prior);inside=(now>=start)&(now<end)
    finite_v=np.isfinite(volume)&(volume>=0)&np.isfinite(vt)
    current=finite_v&(vt<=now)&(now-vt<=30)
    use=monotonic&inside&current
    t=now[use];v=volume[use];clock=vt[use];lines=line[use]
    # ----------------------------------------
    # 量時計が古い行は既知の0へ変えず、端点を確認できない分を未知とする。
    reset=np.r_[0,np.cumsum(np.diff(v)<0)] if len(v) else np.array([],dtype=int)
    values={};qa={'rows':len(now),'eligible_rows':int(use.sum()),'price_clock_backward':int((finite&~monotonic).sum()),
        'future_quantity_clock':int((monotonic&inside&finite_v&(vt>now)).sum()),
        'stale_quantity_clock':int((monotonic&inside&finite_v&(now-vt>30)).sum()),
        'quantity_missing':int((monotonic&inside&~finite_v).sum()),'resets':int((np.diff(v)<0).sum()),
        'known_minutes':0,'unknown_minutes':0,'known_zero_minutes':0}
    for minute in range(int((end-start)//60)):
        a=start+minute*60;b=a+60
        # 両端とも境界より前の最後の観測。同時刻の公表原行から遡及追加しない。
        ia=int(np.searchsorted(t,a,side='left'))-1;ib=int(np.searchsorted(t,b,side='left'))-1
        reason=None;amount=None;lastline=None
        if ia<0 or ib<=ia:reason='量端点不足'
        elif a-t[ia]>30 or b-t[ib]>30 or a-clock[ia]>30 or b-clock[ib]>30:reason='量端点30秒超'
        elif reset[ib]!=reset[ia]:reason='累積量減少'
        elif np.max(np.diff(t[ia:ib+1]),initial=0)>90:reason='量観測90秒超空白'
        else:amount=float(v[ib]-v[ia]);lastline=int(lines[ib])
        if amount is None:qa['unknown_minutes']+=1
        else:
            qa['known_minutes']+=1
            qa['known_zero_minutes']+=int(amount==0)
        history=[values[k]['amount'] for k in range(minute-20,minute) if k in values]
        avg=sum(history)/20 if len(history)==20 and all(x is not None for x in history) else None
        relative=amount/avg if amount is not None and avg is not None and avg>0 else None
        values[minute]={'minute':minute,'start':a,'end':b,'amount':amount,'reference_mean':avg,
            'relative':relative,'previous_relative':values.get(minute-1,{}).get('relative'),
            'known':relative is not None,'reason':reason if reason else '参照20分不足又は量平均0' if relative is None else None,
            'last_line':lastline,'endpoint_price_age':None if amount is None else float(b-t[ib]),
            'endpoint_volume_age':None if amount is None else float(b-clock[ib])}
    return values,qa


def allowed(row,quantity,mode):
    """
    機能: 純価格入口へ数量可用性・相対量・持続条件を付加する。
    引数: row(dict)は価格q0、quantity(dict)は当該完成分、mode(str)。
    返り値: boolは価格入口を許可するか。買売方向には依存しない。
    """
    assert mode in MODES
    if mode=='Q0':return True
    if not quantity['known']:return False
    r=quantity['relative'];p=quantity['previous_relative']
    if mode=='QK':return True
    if mode=='QR':return .8<=r<=3
    if mode=='QP':return .8<=r<=3 and p is not None and .8<=p<=3
    if mode=='QB':return .5<=r<=3 and p is not None and .25<=p<=1 and r>p
    return not (r>3 and row['range']>1.5)
