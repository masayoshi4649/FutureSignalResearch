"""未採用の量比較を最小正本・全セル表・再現Sourceとして固定する。"""
from pathlib import Path
import difflib
import gzip
import hashlib
import json
import re
import shutil
import zipfile
import 数量188 as Q

ROOT=Q.ROOT;HERE=Path(__file__).parent
TRIAL=ROOT/'study/00188_両指数の共通入口に数量の持続を重ねる'
DEST=ROOT/'inputs/00188_共通価格入口の純数量'


def ref(path):
    """
    機能: 正式資源の相対パスとSHA256を記録する。
    引数: path(Path)。
    返り値: dictは追跡情報。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,
        'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def write(path,text):
    """
    機能: UTF-8文書を保存する。
    引数: path(Path),text(str)。
    返り値: None。
    """
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text,encoding='utf-8')


def main():
    """
    機能: 量比較の結果と入力、Source、設定表を正式保存する。
    引数: なし。
    返り値: None。旧試行は変更しない。
    """
    DEST.mkdir(parents=True,exist_ok=True)
    for name in ('人工確認188.json','純数量短表.json','金融開始前固定.json','旧18対照同体.json',
                 '全108組安定性.json.gz','全108組短表.json','原因診断188.json.gz'):
        shutil.copy2(HERE/name,TRIAL/name)
    for p in (HERE/'純数量').glob('*.json.gz'):shutil.copy2(p,DEST/p.name)
    manifest={'用途':'187と同体の価格q0へ接続する当時量。新しいq0は作らない。',
        'entries':[ref(p) for p in sorted(DEST.glob('*.json.gz'))],
        '条件':ref(TRIAL/'条件.json'),'量時計':'完成分端点より前、量時刻<=価格時刻。端点誤差最大30秒の観測差分。'}
    write(DEST/'入力台帳.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    write(DEST/'README.md','# 共通価格入口の純数量\n\n[188正本](../../study/00188_両指数の共通入口に数量の持続を重ねる/README.md)で作成。'
        'NK225 25,881・TOPIX 31,818の既存q0へ量を接続した。価格の母集団は[187](../00187_共通価格特徴/入力台帳.json)と同じ。'
        '量不明を0にしない。json内のqualityは全81場、rowsは元q0全件を残す。[台帳](入力台帳.json)に内容指紋がある。\n')
    audit=ROOT/'work/187共通対照/188全108口座の独立確認.json'
    shutil.copy2(audit,TRIAL/'独立確認.json')
    # ----------------------------------------
    # 元Sourceを元の相対構造で保存。補修は経済条件ではなくパス照合2箇所だけ。
    sources=[ROOT/r['path'] for r in Q.read(TRIAL/'条件.json')['source']]
    sources += list(HERE.glob('*.py'))
    sources += list((ROOT/'work/187共通対照').glob('*.py'))
    sources += [ROOT/'work/183損失安定性/新候補の集計を独立検査する.py']
    sources=sorted(set(p for p in sources if p.exists()))
    with zipfile.ZipFile(TRIAL/'Source.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for path in sources:archive.write(path,path.relative_to(ROOT).as_posix())
    write(TRIAL/'Source索引.json',json.dumps([ref(p) for p in sources],ensure_ascii=False,indent=2)+'\n')
    revisions=[]
    with zipfile.ZipFile(TRIAL/'実装修正履歴.zip','w',zipfile.ZIP_DEFLATED) as archive:
        for folder in ('実装修正前','実装修正前2'):
            old=HERE/folder/'実行188.py';new=HERE/'実行188.py'
            revisions.append({'版':folder,'旧Source':ref(old),'新Source':ref(new),
                '差分':list(difflib.unified_diff(old.read_text(encoding='utf-8').splitlines(),new.read_text(encoding='utf-8').splitlines()))})
            for p in (HERE/folder).iterdir():archive.write(p,(Path(folder)/p.name).as_posix())
    write(TRIAL/'実装修正確認.json',json.dumps({'理由':'Path添字誤記ROOT[...]をROOT/...へ訂正。売買・量・集計数式は不変。',
        '最初':'金融開始前の純入力照合で停止。純数量全件bytes同体を再生成時に確認。',
        '二回目':'全108口座保存後の終了Source照合で停止。修正後に全108金融・指標・旧18同体記録を再計算し既存bytesとの完全一致をsaveで確認。',
        '最終':'Source全指紋一致、終了コード0。修正前の実装・条件・封印は履歴ZIPへ保存。','履歴':revisions},ensure_ascii=False,indent=2)+'\n')
    # ----------------------------------------
    # 版8全63行・9尺度を保持し、実際に使うセルだけを設定IDへ結び付ける。
    template=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md'
    body=template.read_text(encoding='utf-8').split('## 設定明細（コピー後に記入）')[0]
    body=body.replace('# 手法と時間スケールの汎用表・版8','# 188 設定と結果・汎用表版8のコピー')
    body=body.replace('全セルは未設定・未検証。','未使用セルは今回の比較で使わない。使用セルはS/Rへ接続する。')
    def link(match):
        """
        機能: 元テンプレートの相対参照を試行内へ解決する。
        引数: match(re.Match)はMarkdownリンク。
        返り値: strは新しいリンク表現。
        """
        import os
        value=match.group(1)
        if '://' in value or value.startswith('#'):return match.group(0)
        target=(template.parent/value).resolve()
        return ']('+Path(os.path.relpath(target,TRIAL)).as_posix()+')'
    body=re.sub(r'\]\(([^)]+)\)',link,body)
    settings={}
    for code,scales,label in (
        ('I01',(3,4,5),'S01 EMA8/21・傾き/R01'),('I02',(3,),'S02 EMA8距離/ATR/R01'),
        ('I03',(3,),'S03 MACD12/26/9増分/R01'),('I04',(3,),'S04 RSI14増分/R01'),
        ('I05',(3,),'S05 BB20・σ位置/R01'),('I08',(3,4,5),'S06 DI・ADX14/R01'),
        ('I09',(3,4,5),'S07 ATR14・幅/R01'),('C01',(3,),'S01/03/04複合/R01'),
        ('C02',(3,),'S04/05反転/R01'),('C04',(3,4,5),'S06方向と強さ/R01'),
        ('C07',(3,4,5),'S08 三足背景/R01'),('P01',(1,),'S09 1分実体・終値位置/R01'),
        ('P05',(0,1),'S09 直前終値比・進行/R01'),('V01',(0,1),'S10 観測端点量・相対量20分/R02'),
        ('B01',(0,),'S11 正常BBO・spread/R01'),('E01',(0,),'S12 対称IFD/R01'),
        ('E02',(0,),'S12 SL/期限のみ・追尾なし/R01')):
        settings[code]={n:label for n in scales}
    lines=[];rows=0
    for line in body.splitlines():
        cells=[x.strip() for x in line.split('|')[1:-1]] if line.startswith('|') else []
        if len(cells)==11 and re.fullmatch(r'[ICPVBE][0-9]{2}|X[0-9]{2}|M[0-9]{2}',cells[0]):
            rows+=1;cells[2:]=[settings.get(cells[0],{}).get(i,'未使用') for i in range(9)]
            line='| '+' | '.join(cells)+' |'
        lines.append(line)
    assert rows==63
    tail='''
## 設定明細

共通のS01〜S09/S11/S12は[187条件](../00187_両指数を同じ価格特徴とIFDで比較する/条件.json)を同体再用。EMAは有効足順更新で、欠足を補間せず、同限月だけ場をまたぐ。1分は連続3本が必要。5/15/30分の初期本数は35/21/21。足の公表時計・初値・式・方向鏡像はSourceに固定。

Tは三足のEMA傾き/DI整合、5分RSI45〜75、EMA8距離−0.25〜1ATR、1分動力とMACD/RSI改善。RはADX15<25、BB5の反対側0.5σ以上、RSI30〜60と回復、終値位置0.65以上。MはADX15の25でT/Rを選ぶ。名称上の押戻し/反転の履歴を確認した仕様ではなく、同時点の複合状態である。

S10は[188条件](条件.json)にある6量条件。Q0なし、QKは端点量と参照20分が既知、QRは0.8〜3、QPは2分とも0.8〜3、QBは直前0.25〜1から当該0.5〜3への増加、QCは相対量>3かつ1分値幅/ATR5>1.5だけを除く。数量の累積減少・未来時計・端点不足は未知。端点が境界より最大30秒ずれる観測差分で、真の全約定量ではない。

S12はq0公表済みATR15×1.5/2.5/4を呼値切上げ、取得時には再設定しない対称IFD。H60、予約/保有合計1、終了前15分まで、未知の枠は場末まで保持。mini1枚、NK片道38.5円+5pt、TOPIX41.8円+0.25pt。利確は指値接触、SL/期限は1秒後から30秒TTL。追尾は対象外。

## 複合評価と結果

R01は187と同体の18口座、R02は量を加えた90口座。全108口座、両商品各81場を[安定性正本](全108組安定性.json.gz)へ記録。両中央値正＋Day/Night各保有下限20%の共同適合は0。量水準の効果と可用性の選択を分け、複合損益を個別指標の優位としない。期間差・未知・0取引場は[原因診断](原因診断188.json.gz)に保持した。金融計算前に純数量を封印、旧18対照同体。独立監査は[確認記録](独立確認.json)を参照。

## 再現と版

[Source索引](Source索引.json)、[条件](条件.json)、[入力台帳](../../inputs/00188_共通価格入口の純数量/入力台帳.json)。汎用表版8の内容SHAは下記。63手法×9尺度=567セル。未使用は無効という判断ではない。

'''
    write(TRIAL/'設定と結果.md','\n'.join(lines)+'\n'+tail+hashlib.sha256(template.read_bytes()).hexdigest()+'\n')
    print(json.dumps({'正式保存':str(TRIAL),'表セル':rows*9,'Source数':len(sources)},ensure_ascii=False))


if __name__=='__main__':main()
