"""量条件による参加減少と、元取引の除外・新しい取得の寄与を分ける。"""
from pathlib import Path
from collections import Counter
import gzip
import json
import 数量188 as Q

HERE=Path(__file__).parent


def compact(group):
    """
    機能: 全分母・未知を維持した安定性指標を短くまとめる。
    引数: group(dict)は共通安定性集計。
    返り値: dictは取得・金額・参加・両中央値・損失経路。
    """
    t=group['trades'];s=group['sessions'];p=group['path']['known_contribution']
    return {'取得':t['all_count'],'未知':t['unknown_count'],'利益':t['known_profit'],'損失':t['known_loss'],'既知収支':t['known_net'],
        '参加場':s['participating_count'],'全場':s['eligible_count'],'赤字場':s['negative_rate']['negative_count'],
        '保有下限':group['holding']['held_lower_ratio'],'建玉中央値下限':t['net_median']['lower'],
        '場中央値下限':s['net_median']['lower'],'両中央値正':group['both_medians_positive'],
        '既知寄与DD':p['max_drawdown']['amount'],'最悪場既知寄与':p['worst_scene_net'],
        '赤字場連続上限':s['negative_streak']['upper']}


def ledger(pack):
    """
    機能: 取得の物理同体キーを使って台帳を行へ展開する。
    引数: pack(dict)は保存口座。
    返り値: dict[tuple,dict]は場/要求行/取得行/方向/幅をキーとする。
    """
    z=pack['ledger'];out={}
    for i in range(len(z['known'])):
        row={k:v[i] for k,v in z.items()};key=tuple(row[k] for k in ('scene','request_line','entry_line','side','width'))
        assert key not in out;out[key]=row
    return out


def totals(rows):
    """
    機能: 事後の共通/元だけ/新だけを、未知と実現値に分けて集計する。
    引数: rows(list[dict])は取得行。未取得の仮想利益は含めない。
    返り値: dictは件数・既知利益損失・既知寄与。
    """
    known=[r['net'] for r in rows if r['known']]
    return {'取得':len(rows),'未知':sum(not r['known'] for r in rows),'利益':sum(max(0,n) for n in known),
        '損失':sum(max(0,-n) for n in known),'既知収支':sum(known)}


def main():
    """
    機能: 全108条件の期間別短表とQ0との差分を保存する。
    引数: なし。
    返り値: None。診断群は事後説明であり新しい入口とはしない。
    """
    metrics=Q.read(HERE/'全108組安定性.json.gz')['metrics'];out=[];differences=[]
    for row in metrics:
        out.append({'id':row['id'],'groups':{k:compact(v) for k,v in row['groups'].items()},
            'periods':{p:{k:compact(v) for k,v in bands.items()} for p,bands in row['periods'].items()}})
        name=row['id'];mode=name.split('_')[-2]
        if mode=='Q0':continue
        baseline=name.replace('_'+mode+'_','_Q0_')
        old=ledger(Q.read(HERE/'金融正本'/(baseline+'.json.gz')));new=ledger(Q.read(HERE/'金融正本'/(name+'.json.gz')))
        common=old.keys()&new.keys()
        assert all(old[k]==new[k] for k in common)
        for band,phases in (('DAY',(0,)),('NIGHT',(1,2)),('PRE',(1,)),('POST',(2,))):
            differences.append({'id':name,'band':band,
                '共通':totals([new[k] for k in common if new[k]['phase'] in phases]),
                '元だけ':totals([old[k] for k in old.keys()-new.keys() if old[k]['phase'] in phases]),
                '新だけ':totals([new[k] for k in new.keys()-old.keys() if new[k]['phase'] in phases])})
    eligible=[r['id'] for r in metrics if all(r['groups'][b]['both_medians_positive'] and r['groups'][b]['holding']['held_lower_ratio']>=.2 for b in ('DAY','NIGHT'))]
    payload={'共同条件の適合数':len(eligible),'適合ID':eligible,'全108の短表':out,'同一取得と枠再配分':differences,
        '注意':'取得差分は二つの実現口座の事後比較。棄却された機会の仮想利益を最適化していない。未知は0円としない。'}
    (HERE/'原因診断188.json.gz').write_bytes(gzip.compress((json.dumps(payload,ensure_ascii=False,allow_nan=False)+'\n').encode(),mtime=0))
    print(json.dumps({'共同適合':eligible,'比較数':len(differences)},ensure_ascii=False))


if __name__=='__main__':main()
