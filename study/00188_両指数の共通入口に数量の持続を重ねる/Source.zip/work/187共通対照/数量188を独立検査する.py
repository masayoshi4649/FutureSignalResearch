"""188の量端点と条件を別計算し、108口座の金融・集計を独立照合する。"""
from bisect import bisect_left
from collections import Counter,defaultdict
from pathlib import Path
import importlib.util
import math
import numpy as np
import 入力187 as I
import 実行187 as R
import 固定口座を独立検査する as A

HERE=Path(__file__).parent;TARGET=I.ROOT/'work/188数量比較'
MODES=('Q0','QK','QR','QP','QB','QC')


def quantity_rows(data,start,end):
    """
    機能: 原順の累積量を独立に採否判定し、1分両端差と20分比を得る。
    引数: data(dict[str,np.ndarray]),start/end(float)。
    返り値: list[dict]は全対象分の量。境界と同時の行は使わない。
    """
    accepted=[];maximum=-math.inf
    for n,t in enumerate(data['now']):
        if not math.isfinite(t):continue
        maximum=max(maximum,t)
        if t<maximum or not start<=t<end:continue
        v=float(data['volume'][n]);vt=float(data['volume_time'][n])
        if not math.isfinite(v) or v<0 or not math.isfinite(vt) or not 0<=t-vt<=30:continue
        accepted.append((float(t),v,vt,int(data['line'][n])))
    times=[r[0] for r in accepted];out=[]
    for minute in range(int((end-start)//60)):
        x=start+minute*60;y=x+60;left=bisect_left(times,x)-1;right=bisect_left(times,y)-1
        amount=line=price_age=volume_age=None;reason=None
        if left<0 or right<=left:reason='量端点不足'
        else:
            a,b=accepted[left],accepted[right]
            if max(x-a[0],y-b[0],x-a[2],y-b[2])>30:reason='量端点30秒超'
            elif any(accepted[k][1]<accepted[k-1][1] for k in range(left+1,right+1)):reason='累積量減少'
            elif any(accepted[k][0]-accepted[k-1][0]>90 for k in range(left+1,right+1)):reason='量観測90秒超空白'
            else:amount=b[1]-a[1];line=b[3];price_age=y-b[0];volume_age=y-b[2]
        previous=out[max(0,minute-20):minute];average=None
        if len(previous)==20 and all(r['amount'] is not None for r in previous):average=sum(r['amount'] for r in previous)/20
        relative=amount/average if amount is not None and average is not None and average>0 else None
        out.append({'minute':minute,'start':x,'end':y,'amount':amount,'reference_mean':average,'relative':relative,
            'previous_relative':out[-1]['relative'] if out else None,'known':relative is not None,
            'reason':reason or ('参照20分不足又は量平均0' if relative is None else None),'last_line':line,
            'endpoint_price_age':price_age,'endpoint_volume_age':volume_age})
    return out


def flags(row,quantity):
    """
    機能: 6量条件を独立に評価する。
    引数: row(dict),quantity(dict)。
    返り値: dict[str,bool]は方向不変の許可旗。
    """
    v=quantity['relative'];p=quantity['previous_relative'];known=quantity['known']
    return {'Q0':True,'QK':known,'QR':known and .8<=v<=3,'QP':known and .8<=v<=3 and p is not None and .8<=p<=3,
        'QB':known and .5<=v<=3 and p is not None and .25<=p<=1 and v>p,'QC':known and not (v>3 and row['range']>1.5)}


def main():
    """
    機能: 全純q0の量公開と108口座の全取得・単一保有を独立確認する。
    引数: なし。
    返り値: None。188Sourceは変更せず監査票だけ専有187フォルダへ保存する。
    """
    spec=R.read(I.ROOT/'study/00188_両指数の共通入口に数量の持続を重ねる/条件.json')
    assert all(I.ref(I.ROOT/r['path'])==r for r in spec['source'])
    module=importlib.util.spec_from_file_location('stability_audit',I.ROOT/'work/183損失安定性/新候補の集計を独立検査する.py')
    S=importlib.util.module_from_spec(module);module.loader.exec_module(S)
    stats={s['id']:s for s in R.read(TARGET/'全108組安定性.json.gz')['metrics']};records=[];quantity_count=flag_count=0;identity=0
    for product,entries in I.sessions().items():
        prices=R.read(HERE/'純特徴'/(product+'.json.gz'))['rows'];qs=R.read(TARGET/'純数量'/(product+'.json.gz'))['rows']
        assert len(prices)==len(qs);by_scene=defaultdict(list)
        for row,qr in zip(prices,qs):
            assert all(row[k]==qr[k] for k in ('session','time','line'));by_scene[row['session']].append((row,qr))
        quantity_inputs={r['session']:r for r in spec['inputs'][product]['entries']};packs={};indices={};counts_attributes={}
        for family in ('T','R','M'):
            for multiple in (1.5,2.5,4.):
                for mode in MODES:
                    name=f'{product}188_{family}_ATR15x{multiple:g}_{mode}_H60';key=(family,multiple,mode)
                    packs[key]=R.read(TARGET/'金融正本'/(name+'.json.gz'));indices[key]=0;counts_attributes[key]=0
        for entry in entries:
            scene=entry['session'];a,b,force,_=I.bounds(scene);qentry=quantity_inputs[scene];path=I.ROOT/qentry['path']
            assert I.ref(path)['sha256']==qentry['sha256']
            with np.load(path,allow_pickle=False) as z:raw={k:z[k] for k in ('now','volume','volume_time','line')}
            quantities=quantity_rows(raw,a,b)
            for row,qr in by_scene[scene]:
                expected=quantities[row['minute']];assert expected['end']<=row['time']
                assert expected['last_line'] is None or expected['last_line']<row['line']
                for k,v in expected.items():quantity_count+=A.equal(qr['quantity'][k],v,(product,scene,row['line'],k))
                fs=flags(row,expected)
                for k,v in fs.items():flag_count+=A.equal(qr['allowed'][k],v,(product,scene,row['line'],k))
            data,_=I.load(entry);cache={}
            for key,pack in packs.items():
                family,multiple,mode=key;busy=-math.inf;state=None;counter=Counter()
                for row,qr in by_scene[scene]:
                    side=row['signals'][family]
                    if not side:continue
                    counter['price_signal']+=1
                    if not flags(row,quantities[row['minute']])[mode]:counter['quantity_rejected']+=1;continue
                    counter['signal']+=1
                    if row['time']<=busy:counter['pending_blocked' if state=='pending' else 'held_blocked']+=1;continue
                    ckey=(row['line'],side,multiple)
                    if ckey not in cache:cache[ckey]=A.independent(data,scene,row,side,multiple)
                    cell=cache[ckey]
                    if cell is None:counter['expired']+=1;busy=min(row['time']+30,force);state='pending';continue
                    n=indices[key];ledger=pack['ledger'];position=pack['positions'][n]
                    counts_attributes[key]+=A.equal(ledger['scene'][n],scene,(pack['id'],n,'scene'))
                    for k,v in cell.items():
                        actual=position[k] if k in ('confirmed_until','possible_until') else ledger[k][n]
                        counts_attributes[key]+=A.equal(actual,v,(pack['id'],n,k))
                    indices[key]+=1;counter['acquired']+=1;busy=cell['exit_time'] if cell['known'] else b;state='holding'
                expected={'scene':scene,**counter};actual=next(r for r in pack['diagnostics'] if r['scene']==scene);assert actual==expected,(pack['id'],scene,actual,expected)
        for key,pack in packs.items():
            assert indices[key]==len(pack['ledger']['known']);shadow={**pack,'evidence':None,'periods':{p:None for p in stats[pack['id']]['periods']}}
            aggregate=S.verify(shadow,stats[pack['id']]);records.append({'id':pack['id'],'trades':indices[key],'financial_attributes':counts_attributes[key],'aggregate_attributes':aggregate})
            if key[2]=='Q0':
                old=R.read(HERE/'金融正本'/f'{product}187_{key[0]}_ATR15x{key[1]:g}_H60.json.gz')
                assert all(old[k]==pack[k] for k in ('sessions','ledger','positions'));identity+=1
        print({'188独立検査':product,'完了口座':len(records)},flush=True)
    proof={'成功':True,'口座':len(records),'純q0':len(prices)+len(R.read(HERE/'純特徴/NK225.json.gz')['rows']),
        '数量属性':quantity_count,'許可属性':flag_count,'金融属性':sum(r['financial_attributes'] for r in records),
        '集計属性':sum(r['aggregate_attributes'] for r in records),'取得':sum(r['trades'] for r in records),'旧同体':identity,
        '方法':'量採否/端点/連続20分比/6条件を別実装し、全純q0で比較。金融は187独立線形走査を再用し量棄却後の枠を全再生。',
        'source同体':True,'records':records}
    R.save(HERE/'188全108口座の独立確認.json',proof);print({k:v for k,v in proof.items() if k!='records'},flush=True)


if __name__=='__main__':main()
