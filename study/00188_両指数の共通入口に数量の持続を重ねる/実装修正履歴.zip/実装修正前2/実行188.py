"""187の同じ純q0へ量条件だけを重ね、純生成と単純IFDを分離実行する。"""
from pathlib import Path
from collections import defaultdict,Counter
import argparse
import gzip
import importlib.util
import json
import math
import sys
import numpy as np
import 数量188 as Q

ROOT=Q.ROOT;HERE=Path(__file__).parent;BASE=ROOT/'work/187共通対照'
TRIAL=ROOT/'study/00188_両指数の共通入口に数量の持続を重ねる'
sys.path.insert(0,str(BASE))
import 入力187 as I
import 共通IFD187 as E
import 実行187 as B


def freeze():
    """
    機能: 量条件・入力指紋・純価格母集団と金融Sourceを固定する。
    引数: なし。
    返り値: dictは今回の金融前条件。
    """
    sources=[I.ref(HERE/n) for n in ('数量188.py','人工検査188.py','実行188.py')]
    sources += [I.ref(BASE/n) for n in ('入力187.py','共通IFD187.py','実行187.py')]
    sources += [I.ref(ROOT/'work/183損失安定性/安定性183.py')]
    inputs={}
    for product in ('NK225','TOPIX'):
        manifest,entries=Q.sources(product)
        assert len(entries)==81
        inputs[product]={'manifest':I.ref(manifest),'entries':entries,
            'pure_price':I.ref(BASE/'純特徴'/(product+'.json.gz'))}
    value={'trial':188,'基準':I.ref(ROOT/'study/00187_両指数を同じ価格特徴とIFDで比較する/条件.json'),
        'source':sources,'inputs':inputs,'modes':Q.DESCRIPTIONS,'families':['T','R','M'],
        'width_ATR15_multiples':list(E.MULTIPLES),'products':E.PRODUCTS,
        '数量時計':'量時刻<=価格時刻、遅れ30秒以内の原順観測だけ。完成分の両端より前の最終累積量差。原行番号もq0以前。',
        '数量品質':'各端点の価格/量時刻が境界30秒以内、間の量観測空白90秒以内、累積減少なし。端点差なので厳密な約定時刻の分量とは異なる。',
        '相対量':'直前20完成分が全て既知、平均正。当該差分/20平均。欠測は0にせず、既知0は保持。場越ししない。',
        '母集団':'187の純価格q0は数量が不明でも残す。QKは可用性だけ、他は水準条件。数量で新q0を生まない。',
        '口座':'187同体の単純IFD H60、総保有/予約1、終了15分前まで、未知枠保持。方向・幅・費用を変えない。',
        '評価':'全108口座。Q0同体必須。未知/未参加を保持し損失頻度・深度・連続・前後差を優先。全81は既使用。',
        '人工':Q.read(HERE/'人工確認188.json')}
    B.save(TRIAL/'条件.json',value)
    return value


def pure():
    """
    機能: 金融を参照せず当時量と6条件の許可旗を封印する。
    引数: なし。
    返り値: None。
    """
    spec=freeze();sealed=[];summary=[]
    for product,inputs in spec['inputs'].items():
        rows=Q.read(ROOT/inputs['pure_price']['path'])['rows'];by_scene=defaultdict(list)
        for row in rows:by_scene[row['session']].append(row)
        out=[];quality=[];counts=Counter()
        for entry in inputs['entries']:
            path=ROOT/entry['path'];assert I.ref(path)['sha256']==entry['sha256']
            with np.load(path,allow_pickle=False) as z:data={k:z[k] for k in z.files}
            start,end,_,_=I.bounds(entry['session']);values,qa=Q.quantities(data,start,end)
            for row in by_scene[entry['session']]:
                quantity=values[row['minute']]
                assert quantity['end']<=row['time'] and (quantity['last_line'] is None or quantity['last_line']<row['line'])
                allowed={m:Q.allowed(row,quantity,m) for m in Q.MODES}
                out.append({'session':row['session'],'time':row['time'],'line':row['line'],'quantity':quantity,'allowed':allowed})
                for mode,ok in allowed.items():counts[mode]+=int(ok)
            quality.append({'session':entry['session'],**qa})
        assert len(out)==len(rows)
        path=HERE/'純数量'/(product+'.json.gz')
        B.save(path,{'product':product,'rows':out,'quality':quality,'counts':dict(counts)})
        sealed.append(I.ref(path));summary.append({'product':product,'q0':len(out),'allowed':dict(counts)})
    B.save(HERE/'純数量の封印.json',{'金融前':True,'条件':I.ref(TRIAL/'条件.json'),'pure':sealed})
    B.save(HERE/'純数量短表.json',summary)
    print(json.dumps(summary,ensure_ascii=False),flush=True)


def finance():
    """
    機能: 数量条件ごとに保有枠を再生し、同じ取引結果を重複計算せず集計する。
    引数: なし。
    返り値: None。入口棄却に未来の金融成績を用いない。
    """
    spec=freeze();seal=Q.read(HERE/'純数量の封印.json')
    assert seal['条件']==I.ref(TRIAL/'条件.json') and seal['金融前']
    assert all(I.ref(ROOT/p['path'])==p for p in seal['pure'])
    marker=HERE/'金融開始前固定.json';assert not marker.exists()
    B.save(marker,{'source':spec['source'],'pure':seal['pure']})
    module=importlib.util.spec_from_file_location('安定性188',ROOT/'work/183損失安定性/安定性183.py')
    S=importlib.util.module_from_spec(module);module.loader.exec_module(S)
    metrics=[];short=[];identity=[]
    for product,entries in I.sessions().items():
        prices=Q.read(BASE/'純特徴'/(product+'.json.gz'))['rows']
        quantity=Q.read(HERE/'純数量'/(product+'.json.gz'))['rows'];assert len(prices)==len(quantity)
        by_scene=defaultdict(list)
        for row,volume in zip(prices,quantity):
            assert all(row[k]==volume[k] for k in ('session','time','line'))
            by_scene[row['session']].append((row,volume))
        keys=[(f,m,q) for f in ('T','R','M') for m in E.MULTIPLES for q in Q.MODES]
        cells={k:[] for k in keys};diagnostics={k:[] for k in keys}
        for entry in entries:
            data,_=I.load(entry);route=E.Route(data,entry);cache={}
            for family,multiple,mode in keys:
                key=(family,multiple,mode);busy=-math.inf;state=None;counts=Counter()
                for row,volume in by_scene[entry['session']]:
                    side=row['signals'][family]
                    if not side:continue
                    counts['price_signal']+=1
                    if not volume['allowed'][mode]:counts['quantity_rejected']+=1;continue
                    counts['signal']+=1
                    if row['time']<=busy:counts['pending_blocked' if state=='pending' else 'held_blocked']+=1;continue
                    ckey=(row['line'],side,multiple)
                    if ckey not in cache:cache[ckey]=route.cell(row,side,E.width(row,multiple))
                    cell=cache[ckey]
                    if cell is None:
                        counts['expired']+=1;busy=min(row['time']+30,route.force);state='pending';continue
                    counts['acquired']+=1;cells[key].append(cell)
                    busy=cell['exit_time'] if cell['known'] else route.end;state='holding'
                diagnostics[key].append({'scene':entry['session'],**counts})
        names=[e['session'] for e in entries];periods={'全80':names[:80],'前48':names[:48],'後25':names[48:73],'追加7':names[73:80],'本日1':names[80:]}
        for (family,multiple,mode),selected in cells.items():
            name=f'{product}188_{family}_ATR15x{multiple:g}_{mode}_H60';pack=E.pack(name,entries,selected)
            pack.update(product=product,family=family,multiple=multiple,quantity_mode=mode,diagnostics=diagnostics[(family,multiple,mode)])
            if mode=='Q0':
                old=Q.read(BASE/'金融正本'/f'{product}187_{family}_ATR15x{multiple:g}_H60.json.gz')
                assert all(pack[k]==old[k] for k in ('sessions','ledger','positions'))
                identity.append(name)
            B.save(HERE/'金融正本'/(name+'.json.gz'),pack);stat=S.evaluate_pack(pack,periods);metrics.append(stat)
            t=stat['groups']['ALL']['trades'];short.append({'id':name,'取得':t['all_count'],'未知':t['unknown_count'],
                '利益':t['known_profit'],'損失':t['known_loss'],'既知収支':t['known_net']})
        print(json.dumps({'商品':product,'口座数':len(keys),'完了':True},ensure_ascii=False),flush=True)
    B.save(HERE/'全108組安定性.json.gz',{'metrics':metrics});B.save(HERE/'全108組短表.json',short)
    B.save(HERE/'旧18対照同体.json',{'成功':len(identity)==18,'ids':identity})
    assert all(I.ref(ROOT[r['path']])==r for r in spec['source'])
    print(json.dumps({'口座数':len(metrics),'旧同体':len(identity)},ensure_ascii=False),flush=True)


def main():
    """
    機能: 純数量生成又は金融再生の片方を実行する。
    引数: CLI --pure/--financeは必須かつ排他。
    返り値: None。
    """
    parser=argparse.ArgumentParser();group=parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--pure',action='store_true');group.add_argument('--finance',action='store_true');args=parser.parse_args()
    if args.pure:pure()
    else:finance()


if __name__=='__main__':main()
