"""106全70保存後に既存Viewerへ一覧を登録し、事前指定20資源を照合する。"""

from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
import hashlib
import json
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00106_収束失速で保護の起動と幅を切り替える"
CATALOG = TRIAL / "成果物/一覧.resources.json"
RESULT = CATALOG.parent / "結果.json"
CHECK = CATALOG.parent / "保存会計の確認.json"
COMPLETE = ROOT / "work/106市場/全70場/完了.json"
BASE = "http://127.0.0.1:8092"
SCENES = [(0, 0, "2026-09-21_Day"), (0, 1, "2026-09-21_Night"),
          (5, 0, "2026-10-28_Day"), (5, 1, "2026-11-06_Night")]


def sha(path):
    """
    機能: 照合前後の小さい正本指紋を取得する。
    引数: path(Path)は台帳・結果・完了・コード。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def request(route, payload=None):
    """
    機能: 稼働済みViewerの情報/一覧読込/表示APIだけを呼ぶ。
    引数: route(str)、payload(dict|None)はAPIと一覧path。
    返り値: tuple[dict,str]は応答と本文SHA。
    """
    raw = None if payload is None else json.dumps(payload).encode("utf-8")
    req = Request(BASE + route, data=raw, headers={"Content-Type": "application/json"})
    with urlopen(req, timeout=60) as response:
        body = response.read()
        digest = hashlib.sha256(body).hexdigest()
        expected = response.headers.get("x-chart-data-sha256")
        assert expected is None or expected == digest
        return json.loads(body, parse_float=Decimal), digest


def main():
    """
    機能: 全1400一覧と事前固定20のAPI会計を検算する。
    引数: なし。全70金融/保存成功前はAPIへ進まない。
    返り値: None。全1400表示/ブラウザ描画検証とは呼ばない。
    """
    paths = [CATALOG, RESULT, CHECK, COMPLETE, Path(__file__).resolve()]
    before = {str(path): sha(path) for path in paths}
    complete, saved, checked = [json.loads(path.read_text(encoding="utf-8")) for path in [COMPLETE, RESULT, CHECK]]
    assert complete["success"] and complete["stage"] == "full70" and complete["sessions"] == 70 and complete["books"] == 1400
    assert complete["books_per_scene"] == 20 and complete["unchanged"] and complete["before"] == complete["after"]
    assert saved["成功"] and saved["stage"] == "full70" and saved["場数"] == 70 and saved["会計数"] == 1400
    assert checked["成功"] and checked["会計"] == checked["資源"] == 1400 and checked["不一致数"] == 0
    assert saved["前後不変"] and checked["前後不変"]
    assert saved["入力codeSHA256前"] == saved["入力codeSHA256後"]
    assert checked["入力codeSHA256前"] == checked["入力codeSHA256後"]
    assert saved["completionSHA256"] == checked["completionSHA256"] == sha(COMPLETE)
    assert saved["conditionSHA256"] == checked["conditionSHA256"] == complete["condition_sha256"]
    assert checked["出力SHA256"]["結果.json"] == sha(RESULT)
    assert checked["出力SHA256"]["一覧.resources.json"] == sha(CATALOG)
    resources = json.loads(CATALOG.read_text(encoding="utf-8"))["resources"]
    assert len(resources) == len({row["id"] for row in resources}) == 1400
    expected = {(row["session"], row["key"]): row["net_yen"] for row in saved["場別"]}
    info, _ = request("/api/info")
    assert Path(info["resource_root"]).resolve() == ROOT
    loaded, _ = request("/api/catalogs/load", {"path": CATALOG.relative_to(ROOT).as_posix()})
    assert len(loaded["resources"]) == 1400
    selected = [(f"{policy}_C{cost}_D{delay}", session) for policy in ["W0", "W1", "W2", "E1", "E2"]
                for cost, delay, session in SCENES]

    def check(item):
        """
        機能: 一つの表示APIの純額・実約定行・最終残0を保存実物へ結ぶ。
        引数: item(tuple[str,str])は政策費用Keyと場ID。
        返り値: dictは表示限定の照合証拠。
        """
        key, session = item
        identity = f"106_{key}_{session}"
        resource = next(row for row in resources if row["id"] == identity)
        trades = CATALOG.parent / resource["pnl_path"]
        original = trades.read_bytes()
        query = urlencode({"catalog": loaded["catalog_id"], "resource": identity, "width": 1,
                           "interval": "raw", "price": "last"})
        value, digest = request("/api/data?" + query)
        summary = value["summary"]
        assert value["resource"]["id"] == identity and summary["realized_pnl_yen"] == expected[(session, key)]
        assert summary["long_qty"] == summary["short_qty"] == summary["unrealized_pnl_yen"] == 0
        assert len(value["events"]) == len(original.splitlines()) and trades.read_bytes() == original
        return {"id": identity, "実約定行": len(value["events"]), "純額": expected[(session, key)], "本文SHA256": digest}

    with ThreadPoolExecutor(max_workers=4) as pool:
        details = list(pool.map(check, selected))
    assert before == {str(path): sha(path) for path in paths}
    proof = {"成功": True, "scope": "1400一覧読込と事前固定20の表示API。全資源/ブラウザ描画の照合ではない。",
             "一覧": 1400, "実GET": 20, "選択": selected, "details": details,
             "入力SHA256": before, "前後不変": True, "server停止再起動設定変更": 0, "金融再実行": 0}
    destination = TRIAL / "検査/Viewer代表20資源.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "一覧": 1400, "実GET": 20, "差": 0}, ensure_ascii=False))


if __name__ == "__main__":
    main()
