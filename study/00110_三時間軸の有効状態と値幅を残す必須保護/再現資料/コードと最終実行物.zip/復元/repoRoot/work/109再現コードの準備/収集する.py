"""109の固定コード・明示人工・最終exeだけを収集する計画を作る。"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import sys
import zlib


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
NEIGHBOR = ROOT.parent
SDK = Path('C:/Program Files/Go')
CACHE = Path('C:/Users/masay/go/pkg/mod')
CONDITION = ROOT / 'study/00109_三時間軸の取得確認と一定利益の必須保護/金融条件.json'
CONDITION_SHA = '44b26bb18f66a92c09be7110ce3f24bc81397a4a3322960cfabd3c0bd0909b9b'
SHA = re.compile('[0-9a-f]{64}')
SOURCE_SUFFIXES = {'.go', '.s', '.h', '.py', '.mod', '.sum', '.md', '.json', '.patch', '.ps1', '.mjs', '.txt', '.jsonl', '.toml'}


def need(condition, reason):
    """機能: 収集対象の逸脱や指紋差を拒否する。

    引数: condition(bool)、reason(str)は成立条件と説明。
    返り値: None。不成立ではValueError。
    """
    if not condition:
        raise ValueError(reason)


def sha(path):
    """機能: 明示されたcode・metadata・人工・実行物を同定する。

    引数: path(Path)は認可済み対象。
    返り値: strはSHA256。原板や実市場出力を渡さない。
    """
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def resolve(name):
    """機能: 固定台帳の相対名をrepo基準で解決する。

    引数: name(str)は既知のcode/停止名。
    返り値: Pathは絶対位置。
    """
    return (ROOT / name).resolve()


def ref(path):
    """機能: 明示した非市場入力の実物Refを作る。

    引数: path(Path)はcode又は小metadata。
    返り値: dictはpath/sha256/bytes。
    """
    return {'path': str(path.resolve()), 'sha256': sha(path), 'bytes': path.stat().st_size}


def read(path, expected=None):
    """機能: 指定した停止・条件・索引metadataだけを読む。

    引数: path(Path)、expected(str|None)は対象と期待SHA。
    返り値: dictはmetadata。
    """
    need(expected is None or sha(path) == expected, 'metadataの期待SHA差:' + str(path))
    return json.loads(path.read_text(encoding='utf-8-sig'))


def restoration(path):
    """機能: 元の相対配置を安全なarchive名へ写す。

    引数: path(Path)は実在対象。
    返り値: tuple[str,str]はroot識別と相対位置。
    """
    for name, root in (('repoRoot', ROOT), ('neighborRoot', NEIGHBOR), ('moduleCacheRoot', CACHE), ('goRoot', SDK)):
        if path.is_relative_to(root):
            relative = path.relative_to(root).as_posix()
            need(relative and not PurePosixPath(relative).is_absolute() and '..' not in PurePosixPath(relative).parts, '安全な相対path')
            return name, relative
    raise ValueError('復元rootの未定義:' + str(path))


class Registry:
    """固定codeと入力証拠を重複させず保持する。"""

    def __init__(self):
        """機能: 空の収集台帳を作る。

        引数: self(Registry)。返り値: None。
        """
        self.rows = {}
        self.external = {}

    def add(self, name, expected, role, kind='code'):
        """機能: 実物SHA・種別・復元位置を検査して一件登録する。

        引数: name/expected/role/kind(str)はpath・SHA・理由・code/metadata/人工/最終exe/環境。
        返り値: dictは重複統合後の行。
        """
        path = resolve(name)
        need(isinstance(expected, str) and SHA.fullmatch(expected), '明示SHAが必要')
        need(kind in ('code', 'metadata', '人工', '最終exe', '環境', 'LICENSE'), '対象種別')
        need(not path.is_relative_to(NEIGHBOR / 'JP_OSE_Data'), '原板/価格CSVは複製しない')
        if path.is_relative_to(SDK) and kind != 'LICENSE':
            kind = '環境'
        elif kind == '人工':
            need(any(x in path.as_posix() for x in ('/人工_停止版/', '/人工Reader/', '/109R保存監査の人工出典/正規R.json')), '人工は明示した専用prefixのみ')
        elif kind == '最終exe':
            need(path.suffix == '.exe', '最終exeの明示種別')
        else:
            need(path.suffix != '.exe' and path.suffix != '.csv' and '.Native.' not in path.name and not path.name.endswith('.gz'), '実Native/Record/価格CSV/途中exeの複製禁止')
            need(path.suffix in SOURCE_SUFFIXES or kind == 'LICENSE' or path.name in ('LICENSE', 'COPYING', 'NOTICE'), 'code/metadataの拡張子限定')
        need(path.is_file() and sha(path) == expected, '収集対象の全bytes差:' + str(path))
        key = str(path)
        if key in self.rows:
            row = self.rows[key]
            need(row['sha256'] == expected, '同pathのSHA衝突')
            if role not in row['roles']:
                row['roles'].append(role)
            return row
        root, relative = restoration(path)
        prefix = '人工' if kind == '人工' else '実行物' if kind == '最終exe' else '復元'
        row = {'original_path': key, 'sha256': expected, 'bytes': path.stat().st_size, 'kind': kind, 'roles': [role], 'restore': {'root': root, 'relative': relative}, 'location': {'kind': '環境版とSHAのみ' if kind == '環境' else '新archive予定', 'entry': None if kind == '環境' else f'{prefix}/{root}/{relative}'}}
        self.rows[key] = row
        return row

    def add_ref(self, value, role, kind='metadata'):
        """機能: FileRefを指紋の綴りに合わせて登録する。

        引数: value(dict)、role/kind(str)は参照と分類。
        返り値: dictは登録行。
        """
        expected = value.get('sha256', value.get('SHA256'))
        return self.add(value['path'], expected, role, kind)

    def file(self, path, role, kind='code'):
        """機能: 許可した追加codeを現在SHAで計画へ固定する。

        引数: path(Path)、role/kind(str)は明示対象と理由。
        返り値: dictは登録行。計画確定後の改変は後段で拒否する。
        """
        return self.add(str(path), sha(path), role, kind)


def inspection_refs(value):
    """機能: 停止の検査欄内にある小FileRefだけを抽出する。

    引数: value(any)は検査欄。
    返り値: list[dict]はpath/sha付きの検査Ref。
    """
    if isinstance(value, dict):
        if 'path' in value and ('sha256' in value or 'SHA256' in value):
            return [value]
        return [r for child in value.values() for r in inspection_refs(child)]
    if isinstance(value, list):
        return [r for child in value for r in inspection_refs(child)]
    return []


def collect_stop(registry, value, reason):
    """機能: 明示停止の所有code/仕様/検査を、型の違いを保って収集する。

    引数: registry(Registry)、value(dict)、reason(str)は台帳・停止Ref・理由。
    返り値: dictは停止metadata。
    """
    path = resolve(value['path'])
    registry.add_ref(value, reason)
    stopped = read(path, value['sha256'])
    field = next((name for name in ('所有コードSHA256', 'コードSHA256', 'コードSHA256後') if name in stopped), None)
    need(field is not None, '停止所有コードの未対応schema')
    for name, expected in stopped[field].items():
        registry.add(name, expected, reason + ':所有/再用code')
    for name in ('README.md', '仕様.md', '仕様.json'):
        candidate = path.parent / name
        if candidate.is_file():
            registry.file(candidate, reason + ':仕様', 'metadata')
    for name in ('仕様', '検査', '検査正本', '人工確認'):
        for evidence in inspection_refs(stopped.get(name)):
            registry.add_ref(evidence, reason + ':' + name)
    for field in ('Go確認SHA256', '人工確認SHA256'):
        if field in stopped:
            candidates = [path.parent / '検査/Go確認.json'] if field == 'Go確認SHA256' else [path.parent / '人工確認.json', path.parent / '検査/人工確認.json']
            matching = [p for p in candidates if p.is_file() and sha(p) == stopped[field]]
            need(len(matching) == 1, '停止検査指紋の実在位置')
            registry.file(matching[0], reason + ':' + field, 'metadata')
    return stopped


def add_licenses(registry):
    """機能: 同梱OSS2moduleのライセンスと元go.modを追加する。

    引数: registry(Registry)は選択済みコード台帳。
    返り値: list[dict]はmodule rootとLICENSE/COPYINGの実物Ref。
    """
    modules = {}
    for row in list(registry.rows.values()):
        path = Path(row['original_path'])
        if path.is_relative_to(CACHE) and '/cache/download/' not in path.as_posix():
            parts = path.parts
            index = next((i for i, part in enumerate(parts) if '@' in part), None)
            need(index is not None, 'OSS module rootの識別')
            module = Path(*parts[:index + 1])
            modules[str(module)] = module
    result = []
    for module in modules.values():
        licenses = [module / name for name in ('LICENSE', 'LICENSE.txt', 'LICENSE.md', 'COPYING', 'NOTICE') if (module / name).is_file()]
        need(bool(licenses), 'OSSソースにはLICENSEが必要')
        for path in licenses:
            registry.file(path, 'OSSの利用条件', 'LICENSE')
        registry.file(module / 'go.mod', 'OSS module版', 'code')
        result.append({'module_root': str(module), 'licenses': [ref(p) for p in licenses]})
    return result


def add_artificial(registry, stopped, fields, reason):
    """機能: 停止が明示した人工だけを固定SHAで追加する。

    引数: registry(Registry)、stopped(dict)、fields(tuple[str])、reason(str)は台帳・停止・人工map名・理由。
    返り値: None。通常dataから自動検出しない。
    """
    for field in fields:
        for name, expected in stopped.get(field, {}).items():
            registry.add(name, expected, reason, '人工')


def old_input_references():
    """機能: 106入力producerの正式archive群と再現手順を実SHAへ結ぶ。

    引数: なし。
    返り値: dictは旧索引/手順/archivesのRef。Source等の本文を複製しない。
    """
    parent = ROOT / 'study/00106_収束失速で保護の起動と幅を切り替える'
    index_path = parent / '再現コードの所在.json'
    index = read(index_path)
    archive_refs = []
    for value in [index['新ZIP']] + index['既存archive']:
        path = (parent / value['path']).resolve()
        need(sha(path) == value['sha256'], '旧正式archive実SHA')
        archive_refs.append(ref(path))
    return {'index': ref(index_path), 'instructions': ref(parent / '再現.md'), 'archives': archive_refs, 'producer_code_outside_109': [row for row in index['entries'] if '106不足12Sourceの再形成/' in row.get('original_path', '').replace('\\', '/')], 'scope': '106巨大Source/Tape/Record/Header保持又は再形成の入口。109 ZIPへ実入力本文を複製しない。'}


def environment():
    """機能: Go以外の外部環境も本体非同梱の実版/Refとして記録する。

    引数: なし。
    返り値: dictはPython/Node/Artifact環境の版・所在・指紋。
    """
    node_root = Path('C:/Users/masay/.cache/codex-runtimes/codex-primary-runtime/dependencies/node')
    package_path = node_root / 'node_modules/@oai/artifact-tool/package.json'
    package = read(package_path)
    need(package['name'] == '@oai/artifact-tool' and package['version'] == '2.8.129', '実CSV環境のpackage版差')
    return {'Go': 'go1.24.2 windows/amd64', 'Python': {'version': sys.version, 'binary': ref(Path(sys.executable))}, 'Node': {'version': 'v24.22.1', 'binary': ref(node_root / 'bin/node.exe')}, 'CSV': {'package': package['name'], 'version': package['version'], 'package_json': ref(package_path), 'node_modules_root': str(node_root / 'node_modules'), 'runtime_import': '同bytesの出力する.mjsを置くwork/損益CSVの出力/node_modulesから元node_modulesへのjunctionを使用', 'scope': '本体非同梱。CSV2コードを保存するがNode依存の単体環境復元は未検証。'}}


def build_plan():
    """機能: 金融条件の選択閉包と停止所有/人工/後段codeを結合する。

    引数: なし。
    返り値: dictは未出力のZIP計画。金融/頻度結果は読まない。
    """
    condition = read(CONDITION, CONDITION_SHA)
    registry = Registry()
    for name, expected in condition['code_sha256'].items():
        registry.add(name, expected, '金融条件の実選択閉包')
    technique = read(resolve(condition['technique_fixed']['path']), condition['technique_fixed']['sha256'])
    stops = {}
    for value in condition['stops'] + [condition['saving_stop']]:
        stopped = collect_stop(registry, value, '109停止:' + resolve(value['path']).parent.name)
        stops[resolve(value['path']).parent.name] = stopped
    collect_stop(registry, ref(ROOT / 'work/109頻度の集計準備/停止.json'), '109頻度の独立集計')
    for value in condition['specifications']:
        path = resolve(value['path'])
        if path.name == '停止.json' and str(path) not in registry.rows:
            collect_stop(registry, value, '金融固定器の停止')
        elif path.is_relative_to(ROOT / 'work') and '/109頻度/' not in path.as_posix() and '/109頻度要求/' not in path.as_posix():
            registry.add_ref(value, '金融固定器の仕様')
    for value in technique['go_closures'].values():
        registry.add_ref(value, 'Go実選択閉包の証拠')
    for path in [ROOT / 'work/109進行/技法条件を固定する.py', ROOT / 'work/109進行/頻度要求を作る.py', ROOT / 'work/109市場コードの閉包/収集する.py', ROOT / 'work/109頻度コードの閉包/収集する.py', ROOT / 'scripts/レポート/試行109の設定表を作る.py', ROOT / 'scripts/損益CSV/出力する.mjs', ROOT / 'scripts/損益CSV/再読で照合する.py']:
        registry.file(path, 'Root実行helper/CSV再用')
    for name in ('成果物を正式保存する.py', 'Viewer8093を確認する.py', '結果と知見を記す.py'):
        registry.file(ROOT / 'work/109進行' / name, 'Rootが実行した正式保存/Viewer/報告helper')
    for name in ('比較する.py', 'CSVを出力する.mjs', 'CSVを再読する.py', '比較の人工検査.py', '小さい要約を作る.py', 'README.md'):
        registry.file(ROOT / 'work/109出口の同入口比較' / name, '同入口の実現差と独立CSV再読')
    for name in ('work/108Viewer確認の準備/Viewerを確認する.py', 'work/107Viewer確認の準備/Viewerを確認する.py', 'work/106進行/Viewerの20資源を確認する.py'):
        registry.file(ROOT / name, '109Viewer helperのimport/指紋検査依存')
    for name in ('起動.json', 'conf/viewer.toml'):
        registry.file(ROOT / 'work/108専用Viewer8093' / name, 'Viewer専用8093の元設定/起動証拠', 'metadata')
    for name in ('work/109市場/先頭2場/完了.json', 'work/109市場/全70場/完了.json', 'work/109頻度/先頭2場/完成.json', 'work/109頻度/全70場/完成.json', 'work/109頻度要求/先頭2場.json', 'work/109頻度要求/全70場.json'):
        registry.file(ROOT / name, '成功実行を再結合する小metadata（実data本文なし）', 'metadata')
    registry.file(ROOT / 'study/00109_三時間軸の取得確認と一定利益の必須保護/検査/保存実行の固定.json', '保存実行のRoot固定metadata', 'metadata')
    for path in OWN.glob('*.py'):
        registry.file(path, '109再現collector')
    registry.file(OWN / 'README.md', '109再現collector仕様', 'metadata')
    add_artificial(registry, stops['三時間軸の市場接続準備'], ('人工型SHA256',), 'Coreの停止人工6')
    add_artificial(registry, stops['109入口の頻度前検査_参照正規化'], ('人工入力SHA256',), 'Observerの停止人工33')
    saved = read(resolve(stops['109保存会計の準備_R構造対応']['検査']['path']))
    for name, expected in saved['入力SHA256前'].items():
        path = resolve(name)
        registry.add(name, expected, 'R保存の明示人工/回帰入力', '人工' if path.suffix == '.json' and ('人工_停止版' in name or path.name == '正規R.json') else 'code' if path.suffix in ('.go', '.py', '.mod') else 'metadata')
    old108 = read(ROOT / 'work/108静観短縮の市場接続準備/停止.json')
    registry.file(ROOT / 'work/108静観短縮の市場接続準備/停止.json', '旧108人工の指紋出典', 'metadata')
    add_artificial(registry, old108, ('人工型SHA256',), 'Core testが読む旧108人工2')
    old106 = read(ROOT / 'work/106可変保護の市場接続準備/検査/人工確認.json')
    registry.file(ROOT / 'work/106可変保護の市場接続準備/検査/人工確認.json', '旧106人工の指紋出典', 'metadata')
    name = 'work/106可変保護の市場接続準備/人工_停止版/方向1_助走false.json'
    registry.add(name, old106['停止版人工SHA256'][name], 'Reader testが読む旧106人工1', '人工')
    registry.add_ref(stops['一定利益と三時間軸の保護会計']['継承した人工fixture'], 'Actor testが読む公開配送人工1', '人工')
    for label, value in (('最終market金融exe', condition['binary']), ('最終Observer純頻度exe', technique['observer_binary'])):
        registry.add_ref(value, label, '最終exe')
    licenses = add_licenses(registry)
    for name in ('LICENSE', 'PATENTS'):
        registry.file(SDK / name, '静的リンクしたGo標準ライブラリの利用条件', 'LICENSE')
    rows = sorted(registry.rows.values(), key=lambda x: x['original_path'])
    for row in rows:
        row['roles'].sort()
    archived = [row for row in rows if row['kind'] != '環境']
    estimate = sum(len(zlib.compress(Path(row['original_path']).read_bytes(), 9)) + 2 * len(row['location']['entry'].encode('utf-8')) + 120 for row in archived)
    return {'version': 1, 'trial': 109, 'scope': '計画のみ。金融/頻度の実結果未読、正式ZIP/closure未生成', 'condition': ref(CONDITION), 'roots': {'repoRoot': str(ROOT), 'neighborRoot': str(NEIGHBOR), 'moduleCacheRoot': str(CACHE), 'goRoot': str(SDK)}, 'files': rows, 'summary': {'全所在': len(rows), '同梱予定': len(archived), '環境参照': len(rows) - len(archived), '種別': dict(Counter(row['kind'] for row in rows)), '同梱元bytes': sum(row['bytes'] for row in archived), 'ZIP概算bytes': estimate}, 'licenses': licenses, 'input_dependencies': {key: condition[key] for key in ('source_manifest', 'source_corpus', 'source_completion', 'baseline_closure', 'baseline_completion', 'baseline_native_index')}, 'old106_producer': old_input_references(), 'environment': environment(), 'not_copied': ['原板', '価格CSV', '実Source/Tape/Header/Record/Native本文', 'GoRoot/Go5tools本文', '途中版exe', 'Node依存本体', '旧archive本文の再複製'], 'pending': ['金融と純頻度の全70成功後にRootが正式ZIP生成を指示', '後段のRoot保存/Viewer/CSV/閉鎖helperを明示Refで追加', '同停止exe2本を復元しても106入力が欠ければ現条件を実行できない', '絶対pathを移す条件変更や再buildによる同SHAを自動保証しない']}


def main():
    """機能: 正式保存を行わず、作業計画を新規JSONへ出す。

    引数: --plan(Path)はwork内の未使用ファイル。
    返り値: None。ZIP生成や実市場処理の口は持たない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    args = parser.parse_args()
    target = args.plan.resolve()
    need(target.is_relative_to(OWN) and not target.exists(), '作業計画は所有work内の未使用先のみ')
    plan = build_plan()
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(plan, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'成功': True, '計画': ref(target), '見積': plan['summary'], '正式ZIP生成': False, '金融/頻度結果読取': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
