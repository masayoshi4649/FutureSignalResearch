"""Root許可後に109成功metadataを認証し、コードと最終exeを正式保存する。"""

import argparse
import json
from pathlib import Path, PurePosixPath
import shutil
import zipfile
import zlib

import 収集する as C


TRIAL = C.ROOT / 'study/00109_三時間軸の取得確認と一定利益の必須保護'
EVIDENCE = {
    '金融': ('検査/金融全70場.json', '6274447512f129133012029d3c746969d4c5ebef0575dbf9b33cf326faad7c54'),
    '純頻度': ('検査/頻度全70場.json', 'ef9c12cc713aba984984ed79ef57974fd1aaaa62ccbbfca7cd3aa3be1002a1b6'),
    'Native台帳': ('成果物_金融/Native参照台帳.json', 'aa25bf5b2ae4e80583f11c6007b3102ce521b83684d5c3f6a0d6e3adcace1219'),
    'Viewer': ('検査/Viewer8093代表48資源.json', 'fb7e8bdf6258c32d8170dbeb13d95377e452312e137c95b7b9061e56f928faab'),
    '結果': ('成果物/結果.json', '9f413d384b7831f60e0a2a743c3f3017a16d466592c7438e8aca956cd1a54804'),
}


def write_json(path, value):
    """機能: JSONを新規ファイルへだけ保存する。

    引数: path(Path)、value(dict)は未使用先と値。返り値: None。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def gate():
    """機能: 金融/純頻度/保存/Viewerの成功を既知SHAの正式metadataで認証する。

    引数: なし。返り値: dictは成功証拠Ref。実Native/Raw/Recordは読まない。
    """
    refs = {}
    values = {}
    C.need(not (TRIAL / '完了記録.json').exists(), '最終閉鎖はRootだけが行う')
    for name, (relative, expected) in EVIDENCE.items():
        path = TRIAL / relative
        C.need(C.sha(path) == expected, '正式成功証拠のSHA差:' + name)
        refs[name] = C.ref(path)
        if name != '結果':
            values[name] = C.read(path, expected)
    financial, frequency = values['金融'], values['純頻度']
    C.need(financial['trial'] == 109 and financial['stage'] == 'full70' and financial['success'] and financial['sessions'] == 70 and financial['books'] == 1680 and financial['condition_sha256'] == C.CONDITION_SHA and financial['before'] == financial['after'] and financial['unchanged'], '同条件金融全70/1680成功')
    C.need(frequency['trial'] == 109 and frequency['stage'] == 'full70' and frequency['success'] and frequency['financial_executed'] is False and frequency['participation_calculated'] is False and frequency['unchanged'], '純頻度全70成功・金融と別scope')
    C.need(len(frequency['results']) == 70 and [r['session'] for r in frequency['results']] == [r['session'] for r in financial['results']], '金融と純頻度の同70集合')
    C.need(all(r['session'][:10] <= '2026-11-06' for r in financial['results']), '未使用11/09は対象外')
    C.need(values['Native台帳']['成功'] and values['Native台帳']['場数'] == 70 and values['Native台帳']['金融会計'] == 1680, '正式Native台帳')
    C.need(values['Viewer']['成功'] and values['Viewer']['一覧'] == 1680 and values['Viewer']['実GET'] == 48, '代表48API成功')
    return refs


def safe(entry):
    """機能: ZIP名の絶対位置/遡り/Windows driveを拒否する。

    引数: entry(str)はarchive内位置。返り値: boolは安全な相対名。
    """
    value = PurePosixPath(entry)
    return bool(entry) and not value.is_absolute() and '..' not in value.parts and '\\' not in entry and ':' not in entry


def write_zip(path, rows):
    """機能: 明示行の元bytesだけをUTF-8相対entryへ圧縮保存する。

    引数: path(Path)、rows(list[dict])は未使用先と同梱行。返り値: None。
    """
    names = [row['location']['entry'] for row in rows]
    C.need(all(safe(n) for n in names) and len(names) == len(set(n.casefold() for n in names)), 'ZIP名の安全性/正規化一意')
    with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as archive:
        for row in rows:
            source = Path(row['original_path'])
            C.need(C.sha(source) == row['sha256'] and source.stat().st_size == row['bytes'], 'ZIP作成直前の元値')
            archive.write(source, row['location']['entry'])


def verify_zip(path, rows):
    """機能: 全entryのSHA/CRC/サイズ/安全名と完全な集合を再読照合する。

    引数: path(Path)、rows(list[dict])はZIPと期待行。返り値: dictは全entry CRC等。
    """
    import hashlib
    expected = {row['location']['entry']: row for row in rows}
    checks = {}
    with zipfile.ZipFile(path, 'r') as archive:
        C.need(archive.testzip() is None, 'ZIP全CRC')
        C.need(set(archive.namelist()) == set(expected) and len(archive.namelist()) == len(expected), 'ZIP過不足/重複なし')
        for info in archive.infolist():
            row = expected[info.filename]
            C.need(safe(info.filename) and not info.is_dir(), 'ZIPの安全なファイルentry')
            body = archive.read(info)
            got = hashlib.sha256(body).hexdigest()
            crc = zlib.crc32(body) & 0xffffffff
            C.need(got == row['sha256'] and len(body) == row['bytes'] == info.file_size and crc == info.CRC, 'ZIP全entryのSHA/bytes/CRC')
            checks[info.filename] = {'sha256': got, 'bytes': len(body), 'crc32': f'{crc:08x}'}
    return checks


def write_reproduction(index, proof_ref):
    """機能: コード/同停止exe/共用入力の復元範囲を正式Markdownへ記す。

    引数: index/proof_ref(dict)は正式索引と保存検査Ref。返り値: Pathは新規再現.md。
    """
    zip_ref = index['ZIP']
    exes = {r['roles'][0]: r for r in index['最終exe']}
    financial = C.read(TRIAL / EVIDENCE['金融'][0])
    first = financial['first2']
    full_request = C.ref(C.ROOT / 'work/109頻度要求/全70場.json')
    lines = [
        '# 109の再現手順',
        '',
        '確認日：2026-11-09。既使用70場のMain24金融・純頻度・保存を完了した。計算/閲覧完了を安定利益や採用の証明とせず、研究目標達成・採用はfalseのまま。[全結果](README.md)、[条件表](設定と結果.md)、[金融条件](金融条件.json)を参照する。最終完了記録はRootが別に作成する。',
        '',
        '## 保存したコードと実行物',
        '',
        f'[コードと最終実行物](再現資料/コードと最終実行物.zip)は{zip_ref["bytes"]:,}bytes、{index["同梱entry数"]} entry。[所在索引](再現資料/コード所在索引.json)に元path・全SHA・サイズ・役割・復元root/relative・ZIP内位置を記録した。[保存の確認](再現資料/保存の確認.json)で全entryのSHA/CRC/安全な相対path、正規化重複0、元code/実行物/環境の前後不変を確認した。生成計画とZIP生成helper自身も同梱した。',
        '',
        f'ZIP SHA256：`{zip_ref["sha256"]}`。保存検査SHA256：`{proof_ref["sha256"]}`。',
        '',
        '金融条件の実選択1128件を含む。GoRoot717（標準側712＋Go/compile等5tools）はGo 1.24.2・元path・size・全SHAによる外部環境参照で、本文を同梱しない。静的リンクしたGoのLICENSE/PATENTSは添付した。OSS toml v1.5.0のCOPYINGとexpr v1.17.8のLICENSE、各go.modも同梱した。',
        '',
        '復元は索引の`restore.root`と`restore.relative`に従う。repoRootは本repo、neighborRootは共有親、moduleCacheRootはGo module cache、goRootはGo環境。ZIP名に絶対pathや`../`を使わない。復元先に同SHAがある場合は再利用し、異なる既存ファイルを自動上書きしない。',
        '',
        '最終market exe（SHA `3c01b3b05f730ab6e750ef1414b73f6bb4fe0826d08f484bd8c228e1f677813e`）と最終Observer exe（SHA `459e86ed05ea126917f0d8e9ab2843d0b489f79bfc2880915f5b7beeeae09686`）の2本を保存した。途中版exeやGo tools本体は入れない。コードからの再buildはVCS埋込情報・絶対path等で同じexe SHAにならない場合があるため、再build成功と同停止exeの復元を区別する。',
        '',
        '人工42件は`人工/` prefixへ、停止が明示したSHAで保存した。通常の市場入力ではない。Rootの3追加helper、同入口比較py4+mjs1、CSV生成/独立再読、頻度独立集計、Viewer純検算の旧helper依存を含めた。未知11月09日の次工程コードはこのZIPの対象外。',
        '',
        '## 共用入力の保持と復元',
        '',
        '109は106の保存Source/Tape/Header/Record、NK225の元価格CSV、旧108正式Nativeを入力にする。重い実入力を本ZIPへ複製していない。入力の正本と全SHAは金融条件のsource_manifest/source_corpus/source_completion、baseline_native_index等に固定している。元Raw・CSVは共有のまま利用する。',
        '',
        '106の巨大公表RecordやSource記録には現work参照がある。workを全削除すると、コードと同停止exeだけでは現条件を実行できない。削除前に入力を保持するか、旧正本・保存指紋・元producerから正確に復元する必要がある。元入力や元exeが失われたときに、再形成が自動的に同SHAになるとは保証しない。',
        '',
        '106 producer17コードは109実選択411の外にある。[旧106の再現.md](../00106_収束失速で保護の起動と幅を切り替える/再現.md)と[旧106の所在索引](../00106_収束失速で保護の起動と幅を切り替える/再現コードの所在.json)を参照する。その不足ZIPと既存archive7本の実物SHAを今回の索引へ結び、producer entryと復元位置を残した。旧106の成功完了metadataは旧106不足ZIPの`repoRoot/work/106市場/全70場/完了.json`に保存されている。巨大Record等が同ZIPに含まれるという意味ではない。',
        '',
        '旧108 Nativeは正式の[参照台帳](../00108_開始静観20分と30分の比較/成果物_金融/Native参照台帳.json)を共用する。新109 Nativeは[正式参照台帳](成果物_金融/Native参照台帳.json)の70本を別の正式成果物として保存済みで、コードZIPへ重複コピーしない。保存完了metadataが指すwork Nativeを再利用する場合は、対応する正式Nativeと同bytes/SHAで原位置へ復元する。',
        '',
        '金融条件の絶対pathとSHAを維持する。別PCへの移設・新しい出力先・再build等で条件を変える場合は、旧条件を上書きせず別条件・別指紋にする。',
        '',
        '## 実行形',
        '',
        '以下は元環境の実行形。全CLIは既存出力先を拒否するため、そのまま再実行しない。再現用の新規先にすると後段の成功Ref/保存固定も新しく結び直す。',
        '',
        '```powershell',
        "& 'work/三時間軸の市場入出力_停止型対応/検査/三時間軸研究.exe' `",
        "  --condition 'S:/GitHub/masayoshi4649/FutureSignalResearch/study/00109_三時間軸の取得確認と一定利益の必須保護/金融条件.json' `",
        f"  --condition-sha '{C.CONDITION_SHA}' `",
        "  --stage full70 --out 'S:/GitHub/masayoshi4649/FutureSignalResearch/work/109市場/全70場' `",
        f"  --first2 '{first['path']}' --first2-sha '{first['sha256']}'",
        '',
        "# 純頻度は金融と別口。停止Observerを固定要求で実行する。",
        "& 'work/109入口の頻度前検査_参照正規化/検査/109頻度前検査.exe' `",
        f"  --request '{full_request['path']}' --request-sha256 '{full_request['sha256']}'",
        '',
        "python -B -X utf8 'work/109保存会計の準備_R構造対応/集計.py' `",
        "  --fixed 'study/00109_三時間軸の取得確認と一定利益の必須保護/検査/保存実行の固定.json' `",
        "  --fixed-sha fbd9f5f5588b9161a5c2ee0b0c2c5c60328dd24816e21fe54ef82aac09f7c21c `",
        "  --out 'work/109保存/全70場'",
        '```',
        '',
        'Observerの実ファイル名・復元先は索引の最終exe行を正とする。純頻度要求/金融条件に開始20分・主7980/副7700・未観測保持を固定した。金融と全70純頻度は実行順序変更の記録に従い並行したが、技法/閾値/24条件を変更していない。',
        '',
        'CSVは`scripts/損益CSV/出力する.mjs`と`再読で照合する.py`を使用する。Node v24.22.1・Artifact Tool 2.8.129のpackage.json/実行物SHAを索引へ記録した。Node依存本体は非同梱で、workの実行folderのnode_modules junctionは元のCodex runtime依存へつなぐ必要がある。単体Node環境の復元は未検証。XLSXは生成しない。',
        '',
        '報告生成は`work/109進行/結果と知見を記す.py`、正式コピーは`成果物を正式保存する.py`、代表Viewer検査は`Viewer8093を確認する.py`。報告図は外部のMatplotlibとMeiryoフォントに依存する。生成後の設定と結果.mdでは、古い固定前案内2箇所を現在の全70結果版/旧CLI固定後拒否/本再現.md参照へ修正した。また生成後の2文書で、早期保護の主語をG2の一定利益後必須保護・可変幅と明記した。いずれも生成helper・市場前原本・数値表・PNGの算術を変更したものではない。READMEの閉鎖案内はRootが別途仕上げる。',
        '',
        'Viewerは1680一覧と11/06日夜の48資源GETを確認した範囲。全資源の描画やブラウザ視認ではない。元の8092/専用8093を停止・再起動・設定変更しない。Viewer server実行物は本ZIPの2本には含めず、元のSessionTradeViewerとSHAを維持する外部環境として扱う。元8093設定/起動metadataと検算コードは保存した。',
        '',
        '## 正式コード保存の再生',
        '',
        '```powershell',
        "python -B -X utf8 'work/109再現コードの準備/ZIPを正式保存する.py' `",
        f"  --plan 'work/109再現コードの準備/最終計画.json' --plan-sha '{index['計画SHA256']}'",
        '```',
        '',
        'この保存器も既存正式先と完了記録がある場合は拒否する。既存ZIPを上書きするためのコマンドではない。元code/停止/金融条件を変更せず、ZIP検査は再計算ではない。最終閉鎖はRootだけが担当する。Rootの独立QAは`work/109進行/閉鎖を確認する.py`で行い、自己SHAを最終記録へ残す。この後段QA自体は今回コードZIPの対象に含めず、金融/保存/報告の再現とは分ける。',
        '',
    ]
    path = TRIAL / '再現.md'
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write('\n'.join(lines))
    return path


def generate(plan_path, expected):
    """機能: 成功認証と元code同体確認の後だけ正式ZIP/索引/確認を新規保存する。

    引数: plan_path(Path)、expected(str)は最終計画とSHA。返り値: dictは正式Ref。
    """
    evidence = gate()
    plan = C.read(plan_path, expected)
    C.need(plan['trial'] == 109 and plan['condition']['sha256'] == C.CONDITION_SHA, '109の同条件コード計画')
    current = C.build_plan()
    C.need(plan['files'] == current['files'] and plan['environment'] == current['environment'], '最終計画と現在のコード/環境同体')
    before = {r['original_path']: r['sha256'] for r in plan['files']}
    before[str(plan_path)] = expected
    C.need(all(C.sha(Path(name)) == digest for name, digest in before.items()), '元code/実行物/環境の事前SHA')
    archived = [r for r in plan['files'] if r['kind'] != '環境']
    root, relative = C.restoration(plan_path)
    plan_row = {'original_path': str(plan_path), 'sha256': expected, 'bytes': plan_path.stat().st_size, 'kind': 'metadata', 'roles': ['このZIPの確定生成計画'], 'restore': {'root': root, 'relative': relative}, 'location': {'kind': '新archive予定', 'entry': '復元/' + root + '/' + relative}}
    archived = archived + [plan_row]
    stage = C.OWN / '正式保存候補'
    C.need(not stage.exists(), '候補を上書きしない')
    stage.mkdir()
    staged_zip = stage / 'コードと最終実行物.zip'
    write_zip(staged_zip, archived)
    entry_checks = verify_zip(staged_zip, archived)
    C.need(all(C.sha(Path(name)) == digest for name, digest in before.items()), '元code/実行物/環境の前後不変')
    destination = TRIAL / '再現資料'
    C.need(not destination.exists(), '正式再現資料を上書きしない')
    destination.mkdir()
    final_zip = destination / staged_zip.name
    with staged_zip.open('rb') as source, final_zip.open('xb') as target:
        shutil.copyfileobj(source, target)
    C.need(C.sha(final_zip) == C.sha(staged_zip), '正式ZIP同bytes')
    verify_zip(final_zip, archived)
    index_rows = []
    for row in plan['files'] + [plan_row]:
        value = json.loads(json.dumps(row))
        if row['kind'] != '環境':
            value['location']['kind'] = 'このZIP'
            value['location']['archive'] = 'コードと最終実行物.zip'
            value['location'].update(entry_checks[row['location']['entry']])
        index_rows.append(value)
    index = {'成功': True, '試行': 109, 'scope': '109実選択code/停止所有/後段helper/明示人工/最終exe2本の保存。金融結果の再計算ではない', '金融条件': plan['condition'], '実行成功証拠': evidence, '計画SHA256': expected, 'ZIP': C.ref(final_zip), 'roots': plan['roots'], 'entries': index_rows, 'Go環境717': {'件数': 717, '所在': 'entriesのkind=環境', '本文同梱': False}, '同梱entry数': len(archived), '環境参照数': sum(r['kind'] == '環境' for r in index_rows), '最終exe': [r for r in index_rows if r['kind'] == '最終exe'], 'LICENSE': plan['licenses'], 'environment': plan['environment'], '共用入力依存': plan['input_dependencies'], '旧106のproducer': plan['old106_producer'], '未同梱': plan['not_copied'], '閉鎖': False, '採用': False, '研究目標達成': False, '復元': 'entriesのrestore.root/relativeへ同SHAだけを戻す。Go環境と共用入力は別に保持/正確復元する。元の絶対path/条件を勝手に書き換えない。'}
    index_path = destination / 'コード所在索引.json'
    write_json(index_path, index)
    after = {name: C.sha(Path(name)) for name in before}
    C.need(after == before, '正式保存後も元code/実行物/環境は不変')
    proof = {'成功': True, '試行': 109, 'ZIP': C.ref(final_zip), '索引': C.ref(index_path), '計画': C.ref(plan_path), '自己code': C.ref(Path(__file__).resolve()), '同梱entry数': len(archived), 'GoRoot環境参照': sum(r['kind'] == '環境' for r in index_rows), '最終exe数': 2, '全entrySHA/CRC/安全path': True, '正規化重複': 0, '元codeSHA256前': before, '元codeSHA256後': after, '前後不変': True, '金融/Observer再実行': False, '実Raw/価格CSV/Record/Nativeの複製': False, '未知11月09本文/hash読取': False, '閉鎖': False, '採用': False, '研究目標達成': False}
    write_json(destination / '保存の確認.json', proof)
    reproduction = write_reproduction(index, C.ref(destination / '保存の確認.json'))
    return {'ZIP': C.ref(final_zip), '索引': C.ref(index_path), '確認': C.ref(destination / '保存の確認.json'), '再現MD': C.ref(reproduction), 'entry数': len(archived), 'Go環境': proof['GoRoot環境参照']}


def main():
    """機能: Rootの明示実行だけで正式再現資料を生成する。

    引数: --plan/--plan-shaは作業最終計画とSHA。返り値: None。最終閉鎖はしない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--plan-sha', required=True)
    args = parser.parse_args()
    print(json.dumps(generate(args.plan.resolve(), args.plan_sha), ensure_ascii=False))


if __name__ == '__main__':
    main()
