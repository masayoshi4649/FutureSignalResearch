"""既存の専用8093で109一覧と11/06日夜48資源の保存会計を確認する。"""

from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00109_三時間軸の取得確認と一定利益の必須保護"
BASE = "http://127.0.0.1:8093"


def sha(path: Path) -> str:
    """選択した成果物・コード・server参照の指紋を得る。

    引数: path(Path)は明示ファイル。Raw/CSV本文を渡さない。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def request(route: str, payload: dict | None = None) -> tuple[dict, str]:
    """専用8093のinfo・一覧load・選択dataだけを呼ぶ。

    引数: route(str)、payload(dict|None)は許可APIと一覧参照。
    返り値: tuple[dict,str]はDecimal保持の応答と本文SHA。
    """
    assert route in ("/api/info", "/api/catalogs/load") or route.startswith("/api/data?")
    raw = None if payload is None else json.dumps(payload).encode("utf-8")
    query = Request(BASE + route, data=raw, headers={"Content-Type": "application/json"})
    with urlopen(query, timeout=60) as response:
        body = response.read()
        digest = hashlib.sha256(body).hexdigest()
        assert response.headers.get("x-chart-data-sha256", digest) == digest
        return json.loads(body, parse_float=Decimal), digest


def main() -> None:
    """正式一覧1680と選択48GETを検算し、小さい証拠を保存する。

    引数: なし。8093既存専用serverと11/06 Day/Nightを固定選択。
    返り値: None。8092・server起動設定・金融は操作しない。
    """
    original = ROOT / "work/108Viewer確認の準備/Viewerを確認する.py"
    assert sha(original) == "94c01ad7a413fc54364c20bac8d51b7dbb6660d4aa2bc1db0b3fb8bfa1264b71"
    spec = importlib.util.spec_from_file_location("109のViewer純検算", original)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    old_base = helper.OLD.BASE
    assert old_base == "http://127.0.0.1:8092"
    catalog = TRIAL / "成果物/一覧.resources.json"
    result_path = TRIAL / "成果物/結果.json"
    result = json.loads(result_path.read_text(encoding="utf-8"))
    assert sha(result_path) == "9f413d384b7831f60e0a2a743c3f3017a16d466592c7438e8aca956cd1a54804"
    resources = json.loads(catalog.read_text(encoding="utf-8"))["resources"]
    assert len(resources) == 1680
    selected = [row for row in resources if row["session"] in ("2026-11-06_Day", "2026-11-06_Night")]
    assert len(selected) == 48
    rows = {(row["key"], row["session"]): row for row in result["場別"]}
    before = {str(p): sha(p) for p in (original, Path(__file__).resolve(), catalog, result_path,
              ROOT / "work/108専用Viewer8093/session-trade-viewer.exe", ROOT / "work/108専用Viewer8093/起動.json")}
    for resource in selected:
        path = catalog.parent / resource["pnl_path"]
        before[str(path)] = sha(path)
    # ----------------------------------------
    # 一覧全件を照合し、価格dataのGETは事前選択48資源だけに限定します。
    info, info_sha = request("/api/info")
    assert Path(info["resource_root"]).resolve() == ROOT
    assert Path(info["data_root"]).resolve() == (ROOT.parent / "JP_OSE_Data/future").resolve()
    loaded, catalog_sha = request("/api/catalogs/load", {"path": catalog.relative_to(ROOT).as_posix()})
    assert len(loaded["resources"]) == 1680
    assert {x["id"] for x in loaded["resources"]} == {x["id"] for x in resources}

    def check(resource: dict) -> dict:
        """選択一資源の実純額・約定行数・最終残0を照合する。

        引数: resource(dict)は事前に選択済みの一覧行。
        返り値: dictは限定APIの結果。描画/ブラウザ視認の証明ではない。
        """
        row = rows[(resource["method_id"], resource["session"])]
        path = catalog.parent / resource["pnl_path"]
        original_bytes = path.read_bytes()
        query = urlencode({"catalog": loaded["catalog_id"], "resource": resource["id"], "width": 1,
                           "interval": "raw", "price": "last"})
        value, digest = request("/api/data?" + query)
        helper.verify_response(value, resource["id"], Decimal(str(row["net_yen"])), len(original_bytes.splitlines()))
        assert path.read_bytes() == original_bytes
        return {"id": resource["id"], "純額": row["net_yen"], "実約定行": len(value["events"]), "応答SHA256": digest}

    with ThreadPoolExecutor(max_workers=4) as pool:
        details = list(pool.map(check, selected))
    after = {name: sha(Path(name)) for name in before}
    assert before == after and helper.OLD.BASE == old_base
    proof = {"成功": True, "試行": 109, "一覧": 1680, "実GET": 48, "選択場": ["2026-11-06_Day", "2026-11-06_Night"],
             "scope": "一覧の全IDと代表48資源のAPI純額/約定行/残0。全資源の描画・ブラウザ視認ではない",
             "server": BASE, "info応答SHA256": info_sha, "一覧応答SHA256": catalog_sha, "details": details,
             "入力SHA256前": before, "入力SHA256後": after, "前後不変": True,
             "旧8092操作": 0, "server停止再起動設定変更": 0, "金融再実行": 0, "未使用11月09アクセス": 0}
    destination = TRIAL / "検査/Viewer8093代表48資源.json"
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "一覧": 1680, "実GET": 48, "差": 0, "証拠SHA256": sha(destination)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
