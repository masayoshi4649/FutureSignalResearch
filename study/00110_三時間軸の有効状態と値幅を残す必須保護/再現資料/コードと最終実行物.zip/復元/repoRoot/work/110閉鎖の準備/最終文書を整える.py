"""110の固定報告表を保持し、確定頻度・正式診断・111方針を最終文書へ結ぶ。"""

import json
from pathlib import Path
import shutil

import 要求を作る as R

OUTPUT = R.ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/110損益CSV'
COMMON = R.ROOT / 'docs/議論/有効状態と通常値幅保護の比較結果.md'
SETTINGS_SHA = '2a39ec06f66be99380a7bde0a3e7f645fad24de9500866b47520bf6b0bfbe079'
REPORT_SHA = 'f41622256ca10eb6130d13845c95a05abe65bca73f157a7e472c7a663b803b17'


def copy_metadata(source, target, expected):
    """
    機能: 小型の実行履歴と検査だけを新規正式先へ同バイト保存する。

    引数: source/target(Path)、expected(str)は非市場metadataと期待SHA。
    返り値: dictは元/正式先/指紋。同名の正本を上書きしない。
    """
    assert source.suffix == target.suffix == '.json' and target.parent == R.TRIAL / '検査'
    assert R.sha(source) == expected and not target.exists()
    with source.open('rb') as src, target.open('xb') as dst:
        shutil.copyfileobj(src, dst)
    assert R.sha(target) == expected
    return {'source': str(source), 'target': str(target), 'sha256': expected, '同bytes': True}


def main():
    """
    機能: 許可された110文書だけを確定表から更新し生成確認を残す。

    引数: なし。
    返り値: None。Root目次/AGENTS/111・設定表・旧試行を変更しない。
    """
    report_path = R.ROOT / 'work/110報告案/README案.md'
    assert R.sha(report_path) == REPORT_SHA and R.sha(R.TRIAL / '設定と結果.md') == SETTINGS_SHA
    source = report_path.read_text(encoding='utf-8')
    result = R.read(R.reference(R.TRIAL / '成果物/結果.json', R.FIXED['result'][1]))
    assert result['成功'] and result['採用'] is False and result['研究目標達成'] is False
    metadata = []
    sources = [
        ('work/110停止形式の整合/形式整合の確認.json', '停止形式整合の確認.json', None),
        ('work/110停止形式の整合/初回金融起動の記録.json', '初回金融起動の記録.json', None),
        ('work/110再開の監査/中断と同条件再実行の記録.json', '中断と同条件再実行の記録.json', 'c328cfb0eeb48c811c93655e5676865f5fb28ace15162d4d5a7a16c7cfe6ac0d'),
        ('work/110報告案/報告案の確認.json', '報告の生成確認.json', 'da8972583426c47703aabda267cd4853371b884e9e3ba5b565fffe539958e593'),
        ('work/110閉鎖の準備/閉鎖前の確認.json', '保存と閲覧の結合確認.json', '3e2098cb415ef88ea72e8408502cc9e60af30e846e13c2c55173f7b2ddeee6d6'),
        ('work/110閉鎖の準備/Viewer実行の固定.json', 'Viewer実行の固定.json', '6c609c095eec414e76848ec97011af5ddb82d19856449b4a654124f7b95b150f'),
    ]
    for name, target, expected in sources:
        path = R.ROOT / name
        metadata.append(copy_metadata(path, R.TRIAL / '検査' / target, expected or R.sha(path)))
    new = source.replace('全70場・36条件・2,520会計の保存正本から作成した報告案。採用・目標達成をこの処理で宣言しない。全条件は同じ既使用期間の探索である。',
        '2026-11-09。既使用70場・9候補×4費用条件＝36設定・2,520会計の正式記録。金融、独立保存、純頻度独立集計、CSV再読、正式Native/Viewer資源保存、限定Viewer APIを完了した。新候補は参加率25%に届かず採用なし、研究目標未達。全条件は同じ既使用期間の探索であり、未見安定利益の証明ではない。\n\n[全36条件・全セッションのCSV](../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/110損益CSV/README.md) / [設定と結果](設定と結果.md) / [保存正本](成果物/結果.json) / [完了記録](完了記録.json) / [再現手順](再現.md)。前試行[109](../00109_三時間軸の取得確認と一定利益の必須保護/README.md)は固定したまま保持する。')
    new = new.replace('G3/G4は一定利益で必ず起動し、EMA収束・MACD失速・既知pivot否定で幅を狭め、保護床を不利に緩めない。',
        'G3/G4は一定利益で必ず起動し、警戒 `M AND (C OR P)` が真になったら狭幅へ移り、保護床を不利に緩めない。MA収束・MACD失速・構造否定の単純ORではない。')
    new = new.replace('一般説明と出典はdocs/議論/外部再調査/強さの持続とオシレーターの増分を分ける.mdを参照する。',
        '一般説明と出典は[持続と増分の再調査](../../docs/議論/外部再調査/強さの持続とオシレーターの増分を分ける.md)を参照する。')
    logic = '''### 起動・幅・警戒の固定仕様

買いをs=+1、売りをs=−1とする。費用K=.77+2S、最低床Fmin=ceil5(K+5)、起動Hλ=ceil5(max(20,2K,λA_lock,Fmin+V_entry−K))、G3のλ=.5、G4のλ=1。起動判定は残玉の費用後単位利益u≥100Hλ。Aは新規時又は初回既知時に一度固定し、V_entryは確定3分足5本のH−L中央値、未知時は未丸めAを代替する。未知Aの間はHも未知で、後判明時に過去の利益到達を遡及しない。[事前の設計選択](設計資料/設計の選択.json)を保持した。

通常幅はceil5(max(15,min(2A,2V_now)))、狭幅はceil5(max(10,min(A,V_now)))。A/Vの欠測枝は停止仕様に従い既存幅等を維持する。警戒は確定・公表済み3分足で評価する。

- C：EMA8とEMA21の絶対間隔が直近3本で厳密に連続縮小する。
- M：直近2本のMACDヒストグラム差が保有方向に不利、すなわちs×ΔH<0。
- P：最新確定終値が、事前確認・公表済みの支持/抵抗pivotを保有方向と逆へ厳密に越える。

警戒は **M AND (C OR P)** の三値論理で、警戒真以外では新たな狭幅化をしない。一度狭幅へ移った旗は解除しない。構造床の新規追加にはその時点でも警戒真が必要で、新規以前を中心とするpivot等は適格構造床から除く。床は既床・最低床・峰−幅・適格構造床の最大で、価格跳びや予約・実fillを予定床の約定へ置き換えない。通常幅も現Vに追随するため、警戒が偽でも値幅収縮により床が上がりうる。この経路を警戒狭幅の効果と混同しない。

'''
    new = new.replace('### 心理面の仮説\n', logic + '### 心理面の仮説\n', 1)
    ratio_lines = ['### PF・勝率・平均損益比は別の尺度', '', '| E0・C0D0 | PF | 勝率 | 平均利益÷平均損失絶対額 |', '| --- | ---: | ---: | ---: |']
    for guard, expected_pf, expected_win, expected_ratio in (('G0', 1.529, 43.56, 1.98), ('G4', 1.335, 49.57, 1.36)):
        a = result['集計'][f'entry_E0_{guard}_C0_D0']
        pf = a['positive_yen'] / abs(a['negative_yen'])
        win = 100 * a['positive_positions'] / a['positions']
        ratio = (a['positive_yen'] / a['positive_positions']) / (abs(a['negative_yen']) / a['negative_positions'])
        assert round(pf, 3) == expected_pf and round(win, 2) == expected_win and round(ratio, 2) == expected_ratio
        ratio_lines.append(f'| {guard} | {pf:.3f} | {win:.2f}% | {ratio:.2f} |')
    ratio_lines += ['', 'PFは実利益総額÷実損失総額の絶対額。平均損益比は1勝あたりの平均利益÷1敗あたりの平均損失絶対額。勝率は成立新規件数の費用後正益割合である。G4は勝率を上げても、PFは1.529→1.335、平均損益比は1.98→1.36へ下がった。勝率の改善を利益率全体の改善と呼ばない。', '']
    new = new.replace('## 技法・受付寿命・保護を分けた比較\n', '\n'.join(ratio_lines) + '\n## 技法・受付寿命・保護を分けた比較\n', 1)
    new = new.replace('保護の違いが保有時間・余力・後続L1受付まで変える場合があり、実入口の一致はこの集計だけでは主張しない。',
        '一般には保護の違いが保有時間・余力・後続L1受付まで変える場合がある。今回は別の[同入口比較24組](診断/同入口の保護比較/要約.json)で全70場の入口・数量・気配・Sourceの一致を確認した。')
    new = new.replace('正本は成果物/結果.json（SHA256 b748f75b9bea0e43a404b4ff52530cf7ea68d1ce30e59f7c8559a31df2dff10b）。候補別集計.csvは36条件、全セッション.csvは2,520行。CSV再読・Viewer・正式保存・再現コードの検査記録と接続してから正式報告とする。',
        '正本は[成果物/結果.json](成果物/結果.json)（SHA256 b748f75b9bea0e43a404b4ff52530cf7ea68d1ce30e59f7c8559a31df2dff10b）。候補別集計.csvは36条件、全セッション.csvは2,520行で、無取引行も保持した。[CSV閲覧案内](CSV閲覧案内.md)と[限定Viewer確認](検査/Viewer8094代表72資源.json)から確認できる。')
    new += '''
## 純技術頻度とSource時計・金融参加を分ける

[全70の純頻度独立集計](検査/頻度の独立集計.json)では主7,980枠をすべて観測し、技術許可338枠。買売合計15,960候補のKnownは12,928、Unknownは3,032だった。Source予定L0は558候補、Known475/Unknown83で、許可は12候補だった。全買売の代表はT継続237、T押戻し再開49、R局所転換52で、同時成立は優先順位を適用して重複計上しない。[頻度の5CSV](診断/入口頻度/場別の主副頻度.csv)に並列条件群やSource出生時計を残した。

338は保有や余力を無視した純技術状態の許可枠で、実新規数・参加率ではない。Source予定L0の12は元出生の一枠査定であり、L1の後続受付や新規＋保有を含む金融参加率に読み替えない。L1の実新規47件・主参加率5.40%（G0/C0D0）は金融結果として別に評価する。未知を待機や不成立へ黙って置き換えず、338や12だけから一つの指標が低参加の原因だと断定しない。

## 同入口と保護床の診断

[同入口の保護比較](診断/同入口の保護比較/要点.md)は24比較×70場で厳密同入口を確認した。E0のG3は両勝202玉の実現差−1,665,000円、負→勝43玉の＋522,000円等を加算すると全体差−1,190,000円になる。これは双方で実際に成立した取引の実現差で、退出後の仮想利益ではない。

[保存保護点からの床診断](診断/保護の失速判別/診断_確定.json)ではE0のG3/G4計932玉を検査した。両方で勝って後の実現額が小さかった45/33玉のうち、警戒狭幅が一度もないものは31/18玉だった。減益を警戒だけへ帰属できず、通常幅の現V追随も分ける。保存点の条件付き関連であり、全tickの因果経路を復元した結果ではない。

G3/G4の起動後赤字には、初hitの時点で既に最低床を下回っていた−77円の例と、先行部分返済の損失を残玉単位の保護が補償しない例がある。[診断の説明](診断/保護の失速判別/README.md)を参照する。後者ではuが正でも返済済み分込み全玉清算Wが負だった。すべてをトレーリングの追加滑りで説明しない。[追加診断の正式保存台帳](検査/追加診断の正式保存.json)に5件の同バイト保存を記録した。診断の生成コードは[コード所在索引](再現資料/コード所在索引.json)の元work配置から復元する。

## 完了した保存・閲覧と次方針

- [金融全70](検査/金融全70場.json)・[独立保存](成果物/保存会計の確認.json)：全2,520会計、旧280比較、全セッションの残玉・予約0を確認した。
- [純頻度全70](検査/頻度全70場.json)・[独立集計](検査/頻度の独立集計.json)：金融/参加率の計算とは別に完了した。
- [正式Native台帳](成果物_金融/Native参照台帳.json)・[正式保存の確認](検査/正式保存の確認.json)：Native70、Viewer2,520資源を含む2,606ファイルを同バイト保存した。
- [Viewer8094](検査/Viewer8094代表72資源.json)：全2,520一覧IDと11/06日夜72資源の純額・約定行・最終残0を確認した。全資源の描画やブラウザ視認ではない。
- [生成した報告の確認](検査/報告の生成確認.json)・[停止形式整合](検査/停止形式整合の確認.json)・[中断記録](検査/中断と同条件再実行の記録.json)：固定前後と同条件再実行の経緯を残した。

次はユーザー指定の[111：元の連続判断と必須追尾](../00111_元の連続判断と必須追尾の再基準化/README.md)へ移る。[最新方針](../../docs/議論/FAR本来の連続判断と必須利益保護へ戻す方針.md)に従い、5分等の新規時計と研究側の開始静観を外し、FAR後期選定三手法の元の判断・取引時間を基準にする。一定利益後の必須追尾、MA収束/BBを含む可変幅、部分返済込み会計と通常値幅/失速の分離を順に比較する。110の5分時計と条件は固定対照として保持し、111の市場成績をこの試行から先取りしない。
'''
    original_tables = [line for line in source.splitlines() if line.startswith('|')]
    final_tables = [line for line in new.splitlines() if line.startswith('|') and not line.startswith('| E0・C0D0') and not line.startswith('| G0 |') and not line.startswith('| G4 |')]
    assert all(line in final_tables for line in original_tables)
    (R.TRIAL / 'README.md').write_text(new, encoding='utf-8', newline='\n')
    common = COMMON.read_text(encoding='utf-8')
    base = '../../study/00110_三時間軸の有効状態と値幅を残す必須保護/'
    common = common.replace('../../work/110保存/全70場_中断後の同条件再実行/結果.json', base + '成果物/結果.json')
    common = common.replace('../../work/110保存/全70場_中断後の同条件再実行/保存会計の確認.json', base + '成果物/保存会計の確認.json')
    common = common.replace('../../work/110出口の同入口比較_要約/要約.json', base + '診断/同入口の保護比較/要約.json')
    common = common.replace('純頻度の全70処理は本稿作成時点で実行中で、成立頻度・並列条件群の数値は未確定。上表の低参加を特定の技術条件だけの原因と断定しない。',
        '純頻度の独立再読も全70場で完了した。主7,980枠の技術許可338、買売15,960候補のKnown12,928/Unknown3,032。Source予定L0は558候補のうちKnown475/Unknown83、許可12だった。これは純技術状態と元出生一枠の診断であり、L1の後続受付や金融の新規＋保有参加とは異なる。[確定した独立集計](' + base + '検査/頻度の独立集計.json)を参照する。低参加を特定の技術条件だけの原因と断定しない。')
    common = common.replace('正式成果物へのリンクは正式保存の完了時に接続する。', '正式Native70とViewer2,520資源の同バイト保存、限定72GETまで完了した。[正式保存](' + base + '検査/正式保存の確認.json) / [Viewer確認](' + base + '検査/Viewer8094代表72資源.json)。')
    common += '\n## 複合警戒と損益比から残した知見\n\n警戒は3分の **M AND (C OR P)**。Mは保有方向に不利なMACDヒストグラム増分、CはEMA8/21間隔の直近3本での厳密連続縮小、Pは事前確定pivotの方向に反する終値越えである。三値を保ち、警戒真で狭幅へ移る旗は解除しない。構造床の追加には現在警戒真も必要で、通常幅のV追随による床上昇は警戒狭幅と別経路である。\n\nE0/C0D0のG0→G4では勝率43.56%→49.57%となった一方、PFは1.529→1.335、平均利益÷平均損失絶対額は1.98→1.36だった。PF・勝率・平均損益比を同じ「利益率」と呼ばず、実利益総額と実損失総額も併記する。\n\n[保存床の診断](' + base + '診断/保護の失速判別/診断_確定.json)では、減益群G3/G4の45/33玉のうち31/18玉に警戒狭幅が一度もなかった。通常幅の値幅追随と、複合警戒による狭幅を分離する。起動後の−77円の床割れと、先行部分返済により全玉Wが負でも残玉uが正となる例も分ける。[追加診断5件の同バイト台帳](' + base + '検査/追加診断の正式保存.json)に正本を記録した。全tick原因や心理を実証したものではない。\n\n## 次は元の連続判断へ戻す\n\nユーザー指定の[最新方針](FAR本来の連続判断と必須利益保護へ戻す方針.md)に従い、[111](' + '../../study/00111_元の連続判断と必須追尾の再基準化/README.md' + ')は5分等の新規時計と研究側の開始静観を外し、FAR選定三手法の元ルールを基準にする。一定利益後必須追尾、MA収束/BBの可変幅、会計単位と通常値幅/失速の判別を順に比較する。110の固定条件と結果は保持し、時刻制限を外した効果を110から推定しない。\n'
    assert '../../work/' not in common
    COMMON.write_text(common, encoding='utf-8', newline='\n')
    csv_text = (OUTPUT / 'README.md').read_text(encoding='utf-8')
    csv_text = csv_text.replace('金融・独立保存は全70完了。純頻度の全70独立集計・Viewer・正式保存は別段階で、進行中の状態は研究報告へ記録する。採用なし、研究目標未達。',
        '金融・独立保存、純頻度全70独立集計、Native70/Viewer2,520資源の正式保存を完了した。[正式保存](../../../study/00110_三時間軸の有効状態と値幅を残す必須保護/検査/正式保存の確認.json)と[限定72資源のViewer確認](../../../study/00110_三時間軸の有効状態と値幅を残す必須保護/検査/Viewer8094代表72資源.json)を参照する。全描画の確認ではない。採用なし、研究目標未達。')
    csv_text += '\nPFは実利益総額÷実損失総額の絶対額、平均損益比は平均利益÷平均損失絶対額、勝率は費用後正益となった新規件数の割合として区別する。次の研究は[111](../../../study/00111_元の連続判断と必須追尾の再基準化/README.md)で元の連続判断へ戻す。110のCSV値・固定条件は更新しない。\n'
    (OUTPUT / 'README.md').write_text(csv_text, encoding='utf-8', newline='\n')
    trial_csv = csv_text.replace('(候補別集計.csv)', '(../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/110損益CSV/候補別集計.csv)').replace('(全セッション.csv)', '(../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/110損益CSV/全セッション.csv)').replace('(CSVの確認.json)', '(../../outputs/01a1889f-f2af-7943-a047-543275ee9ed2/110損益CSV/CSVの確認.json)')
    trial_csv = trial_csv.replace('../../../study/00110_三時間軸の有効状態と値幅を残す必須保護/', '').replace('../../../study/00111_元の連続判断と必須追尾の再基準化/', '../00111_元の連続判断と必須追尾の再基準化/')
    assert not (R.TRIAL / 'CSV閲覧案内.md').exists()
    (R.TRIAL / 'CSV閲覧案内.md').write_text(trial_csv, encoding='utf-8', newline='\n')
    assert R.sha(report_path) == REPORT_SHA and R.sha(R.TRIAL / '設定と結果.md') == SETTINGS_SHA
    docs = [R.TRIAL / 'README.md', COMMON, OUTPUT / 'README.md', R.TRIAL / 'CSV閲覧案内.md']
    proof = {'成功': True, '試行': 110, '元報告案': R.reference(report_path, REPORT_SHA), '固定設定表': R.reference(R.TRIAL / '設定と結果.md', SETTINGS_SHA),
             '全固定報告表行保持': True, '元報告表行数': len(original_tables), '更新文書': [R.reference(path) for path in docs],
             '追加metadata同bytes': metadata, '根拠': {'純頻度': '338主枠/SourceL0許可12/Known12928/Unknown3032', '警戒': 'M AND (C OR P)', 'PFと平均損益比の独立照合': True},
             'Root目次/AGENTS/111変更': False, '金融再実行': False, '原板Source読取': False, '採用': False, '研究目標達成': False}
    R.write_new(R.OWN / '最終文書の生成確認.json', proof)
    target = R.TRIAL / '検査/最終文書の生成確認.json'
    assert not target.exists()
    with (R.OWN / '最終文書の生成確認.json').open('rb') as src, target.open('xb') as dst:
        shutil.copyfileobj(src, dst)
    assert R.sha(target) == R.sha(R.OWN / '最終文書の生成確認.json')
    print(json.dumps({'成功': True, '文書': [R.reference(path) for path in docs], '確認': R.reference(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
