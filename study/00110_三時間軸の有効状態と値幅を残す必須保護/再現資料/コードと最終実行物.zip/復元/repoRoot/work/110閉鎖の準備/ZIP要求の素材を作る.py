"""最終文書をRootが確定する前に110の成功Refだけを未固定のZIP要求素材へまとめる。"""

import argparse
import json
from pathlib import Path

import 要求を作る as R


def main():
    """
    機能: 成功した正式保存/Viewer等のRefと後段codeをRoot用素材へ結ぶ。

    引数: --viewer-sha(str)は成功した代表72資源の期待SHA。
    返り値: None。fixed=falseで保存しRootの最終文書確定と正式ZIP実行を待つ。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--viewer-sha', required=True)
    args = parser.parse_args()
    refs = {
        'financial': R.reference(R.TRIAL / '検査/金融全70場.json', R.FIXED['financial'][1]),
        'frequency': R.reference(R.TRIAL / '検査/頻度全70場.json', R.FIXED['frequency'][1]),
        'result': R.reference(R.TRIAL / '成果物/結果.json', R.FIXED['result'][1]),
        'saved_check': R.reference(R.TRIAL / '成果物/保存会計の確認.json', R.FIXED['saved_check'][1]),
        'frequency_summary': R.reference(R.TRIAL / '検査/頻度の独立集計.json', '578f52ff153f7840011272a5e8fb89064978aaa0ef346db3205b4b7bf58129df'),
        'formal_save': R.reference(R.TRIAL / '検査/正式保存の確認.json', 'f5f5338b715df33514b5955e19ae06e049b3323fb6ca480cc76ad500f9ddd8a5'),
        'native_index': R.reference(R.TRIAL / '成果物_金融/Native参照台帳.json'),
        'csv_check': R.reference(R.ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/110損益CSV/CSVの確認.json', '0b5f8522f35b4f68cf08df745f75e10f4ab354fd74d988609f93e8b5e0dea697'),
        'report': R.reference(R.ROOT / 'work/110報告案/報告案の確認.json', 'da8972583426c47703aabda267cd4853371b884e9e3ba5b565fffe539958e593'),
        'same_entry': R.reference(R.TRIAL / '診断/同入口の保護比較/要約.json', 'cb541b53019fef37217d03393672bf19f4e02d440355c2611d1efdfd7e999d12'),
        'viewer': R.reference(R.TRIAL / '検査/Viewer8094代表72資源.json', args.viewer_sha),
    }
    csv = R.read(refs['csv_check'])
    csv_outputs = {name: R.reference(Path(refs['csv_check']['path']).parent / name, csv['出力'][name]['sha256'])
                   for name in ('候補別集計.csv', '全セッション.csv')}
    additions = [R.OWN / '要求を作る.py', Path(__file__).resolve(),
                 R.ROOT / 'work/110出口の同入口比較_要約/要点を作る.py']
    additions += [R.ROOT / 'work/110保護の失速判別の診断' / name for name in ('診断する.py', '診断の人工検査.py', '検査と証拠を固定する.py')]
    value = {'version': 1, 'trial': 110, 'fixed': False,
             'candidate_plan': R.reference(R.ROOT / 'work/110再現保存の最終準備/最終候補計画.json', '4b57e6c48b9d76728570fbe6db8e316bed49c9c9469f8c06db9ea65942952253'),
             'preparation_stop': R.reference(R.ROOT / 'work/110再現物の正式保存_準備/停止.json', '187c2003a84a523b3373c60ac8ee222f5ebb488530494adbd5ce243219b171a4'),
             'refs': refs, 'csv_outputs': csv_outputs, 'documents': [], 'additional_code': [R.reference(path) for path in additions],
             '追加診断の正式保存': R.reference(R.TRIAL / '検査/追加診断の正式保存.json', '44bb36cba72cb151d4cd46520edecd30360816ade6e7897b24d7b5bf61163ee3'),
             '未確定': ['Root所有の最終README/設定表/目次のdocumentsを追加', 'Rootが別の新規JSONへfixed=trueで要求を確定', '正式ZIP/索引/再現手順の保存後にRootが最終closureを作成'],
             '研究目標達成': False, '採用': False}
    ref = R.write_new(R.OWN / 'ZIP要求の素材.json', value)
    print(json.dumps({'成功': True, '素材': ref, 'fixed': False, '正式ZIP生成': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
