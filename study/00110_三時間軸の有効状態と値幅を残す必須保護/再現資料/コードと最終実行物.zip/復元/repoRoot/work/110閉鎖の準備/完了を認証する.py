"""110の全正式成果物とコードZIPを現物認証し試行だけを完了する。"""

from datetime import datetime, timezone
import importlib.util
import json
from pathlib import Path
import re

import 要求を作る as R


def verify_ref(ref):
    """
    機能: 完成成果物の明示Refを現物の全SHAへ結び直す。

    引数: ref(dict)は絶対path・SHA256・任意容量。
    返り値: dictは認証済みRef。原板やSourceを指定しない。
    """
    path = Path(ref['path']).resolve()
    assert path.is_relative_to(R.ROOT) and R.sha(path) == ref['sha256']
    if 'bytes' in ref:
        assert path.stat().st_size == ref['bytes']
    return {'path': str(path), 'sha256': ref['sha256'], 'bytes': path.stat().st_size}


def check_links(files):
    """
    機能: 所有する最終5文書のローカルリンクだけを現物確認する。

    引数: files(list[Path])は試行README/CSV案内/共通知見/出力案内/再現手順。
    返り値: intは確認数。完了記録だけは直後の新規作成を許す。
    """
    count = 0
    for path in files:
        for target in re.findall(r'\]\(([^)]+)\)', path.read_text(encoding='utf-8')):
            relative = target.split('#', 1)[0]
            if not relative or '://' in relative:
                continue
            value = (path.parent / relative).resolve()
            assert value.exists() or value == R.TRIAL / '完了記録.json', (path, target)
            count += 1
    return count


def main():
    """
    機能: 全成功metadata・70Native・2522保存物・ZIP全entryを認証して110を閉じる。

    引数: --request/--request-shaは正式ZIPに使ったRoot最終固定のpathと期待SHA。
    返り値: None。研究目標と採用はfalse、旧試行/111/原板Sourceは変更しない。
    """
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--request-sha', required=True)
    args = parser.parse_args()
    assert not (R.TRIAL / '完了記録.json').exists() and not (R.TRIAL / '検査/最終認証.json').exists()
    request_ref = R.reference(args.request.resolve(), args.request_sha)
    request = R.read(request_ref)
    assert request['trial'] == 110 and request['fixed'] is True
    values = {name: R.read(verify_ref(ref)) for name, ref in request['refs'].items()}
    helper = R.ROOT / 'work/110再現物の正式保存_準備/正式保存する.py'
    assert R.sha(helper) == '98a39f55e2f655ba4245c600496390dc710e0bd279cef3022795a6aa88ad1e9a'
    spec = importlib.util.spec_from_file_location('110最終認証の固定gateとZIP共通部', helper)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    sessions = module.validate_gate(values, request)
    for ref in request['csv_outputs'].values():
        verify_ref(ref)
    for item in request['documents']:
        verify_ref(item['ref'])
    for ref in request.get('additional_code', []):
        verify_ref(ref)
    for ref in request.get('外部最終文書', {}).values():
        verify_ref(ref)
    assert R.sha(R.TRIAL / '設定と結果.md') == '2a39ec06f66be99380a7bde0a3e7f645fad24de9500866b47520bf6b0bfbe079'
    saved = values['saved_check']
    assert len(saved['出力SHA256']) == 2522
    for name, expected in saved['出力SHA256'].items():
        path = (R.TRIAL / '成果物' / name).resolve()
        assert path.parent == R.TRIAL / '成果物' and R.sha(path) == expected
    native = values['native_index']
    for row in native['Native']:
        path = (R.TRIAL / row['path']).resolve()
        assert path.is_relative_to(R.TRIAL / '成果物_金融/Native') and R.sha(path) == row['sha256'] and row['同bytes']
    result = values['result']
    assert len(result['場別']) == 2520 and len(result['集計']) == 36
    for row in result['場別']:
        assert all(row[name] == 0 for name in ('open_buy', 'open_sell', 'pending_buy', 'pending_sell'))
        assert row['closed_net_yen'] == row['net_yen']
    for row in result['集計'].values():
        assert all(row[name] == 0 for name in ('open_buy', 'open_sell', 'pending_buy', 'pending_sell'))
        assert row['entry_quantity'] == row['close_quantity'] and row['closed_net_yen'] == row['net_yen']
        assert (row['活動主表']['denom'], row['活動副表']['denom']) == (7980, 7700)
    diagnosis_ref = R.reference(R.TRIAL / '検査/追加診断の正式保存.json', '44bb36cba72cb151d4cd46520edecd30360816ade6e7897b24d7b5bf61163ee3')
    diagnosis = R.read(diagnosis_ref)
    assert diagnosis['成功'] and len(diagnosis['入力と正式先']) == 5
    for row in diagnosis['入力と正式先']:
        assert row['同bytes'] and R.sha(Path(row['target'])) == row['sha256']
    assert R.sha(R.TRIAL / '診断/同入口の保護比較/要約.json') == 'cb541b53019fef37217d03393672bf19f4e02d440355c2611d1efdfd7e999d12'
    assert R.sha(R.TRIAL / '診断/保護の失速判別/診断_確定.json') == '4cd3d61e33a5d584ec5b17920a4d337e969332ca2a8688d5edce958dc89c462f'
    proof_path = R.TRIAL / '再現資料/保存の確認.json'
    zip_proof = R.read(R.reference(proof_path))
    assert zip_proof['成功'] and zip_proof['前後不変'] and zip_proof['Root要求']['sha256'] == request_ref['sha256']
    assert zip_proof['全entrySHA/CRC/安全path/集合'] and zip_proof['正規化重複'] == 0 and zip_proof['候補と正式ZIP同bytes']
    assert zip_proof['採用'] is False and zip_proof['研究目標達成'] is False and zip_proof['閉鎖'] is False
    index_ref = verify_ref(zip_proof['索引'])
    index = R.read(index_ref)
    archive_ref = verify_ref(zip_proof['ZIP'])
    assert index['ZIP']['sha256'] == archive_ref['sha256'] and index['試行'] == 110 and index['成功']
    entries = index['entries']
    assert sum(row['kind'] == '環境' for row in entries) == 717 and sum(row['kind'] == '最終exe' for row in entries) == 2
    for row in entries:
        assert R.sha(Path(row['original_path'])) == row['sha256']
    archived = [row for row in entries if row['kind'] != '環境']
    checks = module.COMMON.verify_zip(Path(archive_ref['path']), archived)
    assert len(checks) == index['同梱entry数'] == zip_proof['同梱entry数']
    assert zip_proof['入力SHA256前'] == zip_proof['入力SHA256後']
    assert all(R.sha(Path(name)) == expected for name, expected in zip_proof['入力SHA256前'].items())
    assert R.sha(R.ROOT / 'work/110再現保存の最終準備/最終候補計画.json') == '4b57e6c48b9d76728570fbe6db8e316bed49c9c9469f8c06db9ea65942952253'
    assert R.sha(R.ROOT / 'study/00109_三時間軸の取得確認と一定利益の必須保護/完了記録.json') == 'aaa19e81ec1dd7848e901254776776f36f5c78632feaa69d4440d4250dec143b'
    final_docs = [R.TRIAL / 'README.md', R.TRIAL / 'CSV閲覧案内.md', R.ROOT / 'docs/議論/有効状態と通常値幅保護の比較結果.md',
                  R.ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/110損益CSV/README.md', R.TRIAL / '再現.md']
    links = check_links(final_docs)
    refs = {**request['refs'], 'ZIP': archive_ref, 'コード所在索引': index_ref, 'コード保存の確認': R.reference(proof_path),
            'コード最終計画': verify_ref(zip_proof['計画']), 'Root最終要求': request_ref, '再現手順': R.reference(R.TRIAL / '再現.md'),
            '設定と結果': R.reference(R.TRIAL / '設定と結果.md'), '追加診断の正式保存': diagnosis_ref,
            '同入口比較の要点': R.reference(R.TRIAL / '診断/同入口の保護比較/要点.md'),
            '床診断': R.reference(R.TRIAL / '診断/保護の失速判別/診断_確定.json'),
            '床診断の停止確認': R.reference(R.TRIAL / '診断/保護の失速判別/停止と実診断の確認.json'),
            '最終文書生成確認': R.reference(R.TRIAL / '検査/最終文書の生成確認.json'),
            **{'最終文書' + str(i + 1): R.reference(path) for i, path in enumerate(final_docs)},
            **{'CSV_' + name: ref for name, ref in request['csv_outputs'].items()}}
    for name in ('停止形式整合の確認.json', '初回金融起動の記録.json', '中断と同条件再実行の記録.json', '保存と閲覧の結合確認.json', 'Viewer実行の固定.json'):
        refs[name] = R.reference(R.TRIAL / '検査' / name)
    for ref in refs.values():
        verify_ref(ref)
    counts = {'金融セッション': len(sessions), '設定': 36, '金融会計': 2520, '旧同体比較': 280,
              '独立頻度セッション': 70, '主判断枠': 7980, '副判断枠': 7700, '正式Native': 70,
              '正式保存物': len(values['formal_save']['成果物同bytes']), 'Viewer一覧': 2520, 'Viewer実GET': 72,
              'CSV全行': 2520, 'CSV集計行': 36, '同入口比較': 24, '同入口場別比較': 1680,
              '追加診断同bytes': 5, 'ZIPentry': len(archived), 'GoRoot環境参照': 717, '最終exe': 2, '所有5文書リンク': links}
    qa = {'成功': True, '試行': 110, 'scope': '全正式保存物のSHA、全残0、全ZIP集合SHA/CRC/安全名、全成功metadataの結合。金融/全tick/全指標の再走ではない',
          '数': counts, '全2520会計の残玉/予約0': True, '全36集計の新規枚数と返済枚数一致': True,
          '全2522保存出力の現SHA一致': True, '全70Nativeの現SHA一致': True, '全索引の現SHA一致': True,
          '全ZIPentrySHA/CRC/安全名/集合': True, 'コード保存入力前後不変': True, '固定表/旧候補/旧109完了原本不変': True,
          '自己code': R.reference(Path(__file__).resolve()), 'refs': refs,
          '未実施': ['mini実板/実注文', '全2520資源のGET/描画', '全tick/全指標の別engine再形成', '未見期間の安定収益確認'],
          '旧93/94/109への書込': 0, '11月09日本文/入力指紋読取': False, '本閉鎖処理による111市場実行': False,
          '研究目標達成': False, '採用': False}
    qa_path = R.TRIAL / '検査/最終認証.json'
    with qa_path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(qa, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    closure = {'version': 1, '試行': 110, '試行完了': True, '完了日時UTC': datetime.now(timezone.utc).isoformat(),
               'scope': '既使用70場の固定36比較・保存・CSV・限定Viewer・正式再現物を完了。研究目標の達成を意味しない',
               '数': counts, '全残玉/予約0': True, '全索引SHA/CRC/安全名/集合': True, '全入力前後不変': True,
               'refs': {**refs, '最終認証': R.reference(qa_path)}, '採用': False, '研究目標達成': False,
               '次方針': '111でFAR元の連続判断を基準に必須追尾/MA収束・BBの可変幅/全玉会計を比較',
               '次方針リンク': '../00111_元の連続判断と必須追尾の再基準化/README.md',
               '旧93/94/109への書込': 0, '11月09日本文/入力指紋読取': False, '本閉鎖処理による111市場実行': False}
    closure_path = R.TRIAL / '完了記録.json'
    with closure_path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(closure, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    assert all(R.sha(Path(ref['path'])) == ref['sha256'] for ref in closure['refs'].values())
    print(json.dumps({'成功': True, '試行完了': True, '完了記録': R.reference(closure_path), '最終認証': R.reference(qa_path), '数': counts, '研究目標達成': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
