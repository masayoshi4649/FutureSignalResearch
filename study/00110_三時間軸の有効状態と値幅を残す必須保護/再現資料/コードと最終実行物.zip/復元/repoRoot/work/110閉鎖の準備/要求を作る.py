"""解禁済み110の純頻度独立集計から正式保存・Viewerの要求を新規生成する。"""

import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
TRIAL = ROOT / 'study/00110_三時間軸の有効状態と値幅を残す必須保護'
SAVED = ROOT / 'work/110保存/全70場_中断後の同条件再実行'
FREQUENCY_SUMMARY = ROOT / 'work/110頻度集計/全70場_中断後の同条件再実行/独立集計.json'
FIXED = {
    'financial': ('work/110市場/全70場_中断後の同条件再実行/完了.json', 'bf95d74bc04953643606884c432c41ff14854792aee642bb15a75effd66f1539'),
    'frequency': ('work/110頻度/全70場_中断後の同条件再実行/完成.json', 'd10fe490552d511591aaf898bad0344e87979633c512d39e0c4b70025df5281a'),
    'result': ('work/110保存/全70場_中断後の同条件再実行/結果.json', 'b748f75b9bea0e43a404b4ff52530cf7ea68d1ce30e59f7c8559a31df2dff10b'),
    'saved_check': ('work/110保存/全70場_中断後の同条件再実行/保存会計の確認.json', 'a063226fc9b6b2d2f70b084eaaef18ba411baa0a0c2d3b9441ab87b91ae27913'),
    'saving_fixed': ('work/110保存要求/全70場_中断後の同条件再実行.json', '4e7741523e93faeb3e4d3e1f1f7e8951c458ecae1d2e5ef7477f4e71c1b4b842'),
    'saving_stop': ('work/110有効状態と値幅保護の保存/停止.json', '2cd0b49558e04ebad22a1dedeca99fd50dc4c77044b480786ffc67fe69b648f6'),
    'condition': ('study/00110_三時間軸の有効状態と値幅を残す必須保護/金融条件_停止形式整合.json', 'e0f84c5f836a3cb58b6d75c12f08c40e910b661043516e1e642143b6026b9fba'),
}
FREQUENCY_NAMES = ('場別の主副頻度.csv', '日夜と固定期の頻度.csv', '三経路の優先と重なり.csv', '並列条件群の頻度.csv', 'Source予定L0と技術状態.csv')


def sha(path):
    """
    機能: 明示したmetadata・停止code・頻度CSVの全バイト指紋を取る。

    引数: path(Path)は既知対象。
    返り値: strはSHA256。価格・Source・実Nativeを渡さない。
    """
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def reference(path, expected=None):
    """
    機能: 絶対位置と全指紋を確認してRefへまとめる。

    引数: path(Path)、expected(str|None)は対象と任意の期待指紋。
    返り値: dictはpath/sha256。期待と異なる場合は拒否する。
    """
    path = path.resolve()
    current = sha(path)
    assert expected is None or current == expected, str(path)
    return {'path': str(path), 'sha256': current}


def fixed(name):
    """
    機能: Rootが解禁した固定参照を認証する。

    引数: name(str)はFIXED内の役割名。
    返り値: dictは期待SHA一致のRef。
    """
    name, expected = FIXED[name]
    return reference(ROOT / name, expected)


def read(ref):
    """
    機能: 期待SHAを認証したmetadataを読む。

    引数: ref(dict)は明示位置と期待指紋。
    返り値: dictは元JSON。原板・実Native・損益CSVは指定しない。
    """
    path = Path(ref['path'])
    assert sha(path) == ref['sha256']
    return json.loads(path.read_text(encoding='utf-8-sig'))


def verify_stopped(relative, expected):
    """
    機能: 実行するhelperの停止と全所有codeを認証する。

    引数: relative/expected(str)は停止のrepo相対位置と期待SHA。
    返り値: None。停止・codeを変更しない。
    """
    stopped = read(reference(ROOT / relative, expected))
    assert stopped['成功'] and stopped['停止']
    for name, value in stopped['所有コードSHA256'].items():
        assert sha((ROOT / name).resolve()) == value
    for name, value in stopped.get('依存コードSHA256', {}).items():
        assert sha((ROOT / name).resolve()) == value


def validate_frequency(complete, summary, financial):
    """
    機能: 全70頻度と独立集計を同じ場集合・技法・分母へ結ぶ。

    引数: complete/summary/financial(dict)は成功metadata。
    返り値: None。金融損益や価格列を解釈しない。
    """
    assert complete['trial'] == 110 and complete['stage'] == 'full70' and complete['success'] and complete['unchanged']
    assert complete['financial_executed'] is False and complete['participation_calculated'] is False
    assert complete['before'] == complete['after']
    ids = [row['session'] for row in complete['results']]
    assert len(ids) == len(set(ids)) == 70 and ids == [row['session'] for row in financial['results']]
    assert summary['成功'] and summary['stage'] == 'full70' and summary['sessions'] == 70 and summary['unchanged']
    assert summary['completion']['sha256'] == FIXED['frequency'][1]
    assert summary['totals']['primary']['planned'] == 7980 and summary['totals']['secondary']['planned'] == 7700
    assert all(summary[name] is False for name in ('financial_executed', 'participation_calculated', 'l1_eligibility_calculated', 'opportunity_pnl_calculated', 'holdout_11_09_read'))


def write_new(path, value):
    """
    機能: 所有work内の未使用JSONへ要求だけを保存する。

    引数: path(Path)、value(dict)は新規先と要求値。
    返り値: dictは保存した要求Ref。
    """
    assert path.resolve().is_relative_to(OWN) and not path.exists()
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    return reference(path)


def formal_request(summary_sha):
    """
    機能: 成功独立頻度集計から全成果物の正式保存要求を作る。

    引数: summary_sha(str)は成功独立集計のRoot期待SHA。
    返り値: dictはRoot用要求Ref。正式コピー自体は既存helperが担当する。
    """
    verify_stopped('work/110正式保存の準備/停止.json', 'f8c752865901d5fb6bc02dbb19d3bc6d8341b0b28e09ed424119f0def9ed28e2')
    summary_ref = reference(FREQUENCY_SUMMARY, summary_sha)
    validate_frequency(read(fixed('frequency')), read(summary_ref), read(fixed('financial')))
    refs = {name: fixed(name) for name in ('result', 'saved_check', 'frequency')}
    refs.update({'market': fixed('financial'), 'frequency_summary': summary_ref})
    metadata = [
        {'name': '金融先頭2場.json', 'ref': reference(ROOT / 'work/110市場/先頭2場_停止形式整合/完了.json', '4bc6611cf3f8b6123c4da426f19be14d39f141b0355149b6ab778f8f922fa72d')},
        {'name': '頻度先頭2場.json', 'ref': reference(ROOT / 'work/110頻度/先頭2場/完成.json', '33c2c79851a49dea4cfbdf925a61ff196e8d76a64ac3c71e6f62503912c1370d')},
        {'name': '保存実行の固定.json', 'ref': fixed('saving_fixed')},
        {'name': '頻度実行の固定.json', 'ref': reference(ROOT / 'work/110再開の監査/純頻度要求_中断後の同条件再実行.json', 'cd586d20ba036bf372bf70bb0b8a4560d22211b656dd743ef94d2c115c345169')},
    ]
    request = {'version': 1, 'trial': 110, 'refs': refs,
               'frequency_csv': {name: reference(FREQUENCY_SUMMARY.parent / name) for name in FREQUENCY_NAMES}, 'metadata': metadata}
    return write_new(OWN / '正式成果物の要求.json', request)


def viewer_request(formal_sha):
    """
    機能: 正式全件コピー成功後に専用8094の限定確認要求を作る。

    引数: formal_sha(str)は正式保存の確認の期待SHA。
    返り値: dictはRoot用Viewer固定Ref。API・server操作は行わない。
    """
    verify_stopped('work/110Viewer確認の準備/停止.json', 'aeb7280f28792c29cbdd11bb719ce640acfa16dbbf10ef5ad679ce3fd4d1bcaf')
    proof = read(reference(TRIAL / '検査/正式保存の確認.json', formal_sha))
    assert proof['成功'] and proof['試行'] == 110 and (proof['Native数'], proof['Viewer資源'], proof['頻度CSV']) == (70, 2520, 5)
    assert all(row['同bytes'] for row in proof['成果物同bytes'])
    request = {'version': 1, 'trial': 110, 'fixed': True, 'stage': 'full70', 'saved_ready': True,
               'selected_sessions': ['2026-11-06_Day', '2026-11-06_Night'], 'condition': fixed('condition'), 'completion': fixed('financial'),
               'summary': reference(TRIAL / '成果物/結果.json', FIXED['result'][1]),
               'saved_check': reference(TRIAL / '成果物/保存会計の確認.json', FIXED['saved_check'][1]),
               'saving_fixed': fixed('saving_fixed'), 'saving_stop': fixed('saving_stop'),
               'catalog': reference(TRIAL / '成果物/一覧.resources.json'),
               'code': reference(ROOT / 'work/110Viewer確認の準備/Viewerを確認する.py', '5dde2197c4dc81f99b0cc05d08bcf217e0f12e6592fb5836970b941d09260809'),
               'server': {'base': 'http://127.0.0.1:8094',
                          'exe': reference(ROOT / 'work/110専用Viewer8094/session-trade-viewer.exe', '0ed329e06293f55a99ab1dc503e32cc104285319316ef41b81b59470dce9d0e8'),
                          'config': reference(ROOT / 'work/110専用Viewer8094/conf/viewer.toml', 'bfb8f6658aa80ed5991aec14de4418de435a8ab3803c83b06e788b49fc71b198'),
                          'startup': reference(ROOT / 'work/110専用Viewer8094/起動.json', '57b57e81068de2b486435f6885f93051ec945f53cc5ef57a81cd13bce7038f12')}}
    return write_new(OWN / 'Viewer実行の固定.json', request)


def main():
    """
    機能: 完了段階に合わせてRoot用の新規要求を生成する。

    引数: --step(formal|viewer)、--summary-sha/--formal-sha(str|None)は段階と期待指紋。
    返り値: None。docs・最終README・設定表・server・金融は変更しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--step', choices=('formal', 'viewer'), required=True)
    parser.add_argument('--summary-sha')
    parser.add_argument('--formal-sha')
    args = parser.parse_args()
    if args.step == 'formal':
        assert args.summary_sha and args.formal_sha is None
        ref = formal_request(args.summary_sha)
    else:
        assert args.formal_sha and args.summary_sha is None
        ref = viewer_request(args.formal_sha)
    print(json.dumps({'成功': True, '段階': args.step, '要求': ref, '金融再実行': False, '実API': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
