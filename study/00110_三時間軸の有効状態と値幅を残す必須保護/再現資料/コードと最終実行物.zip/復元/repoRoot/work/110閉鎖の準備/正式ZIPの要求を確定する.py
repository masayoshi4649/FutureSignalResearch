"""Rootから移管された110の最終文書を認証し別ファイルへZIP要求を固定する。"""

import json
from pathlib import Path

import 要求を作る as R


def main():
    """
    機能: 未固定素材を保持し最終文書と実使用codeを加えた新要求を作る。

    引数: なし。
    返り値: None。元素材・旧候補・停止code・Rootの目次/111を変更しない。
    """
    material_path = R.OWN / 'ZIP要求の素材.json'
    assert R.sha(material_path) == '2342c3df0cf5e4ebd91d8ccba9c12fff3b11b08984b0901c2894c8ec37006c30'
    value = R.read(R.reference(material_path))
    assert value['fixed'] is False and not value['documents']
    candidate = R.read(value['candidate_plan'])
    previous = {row['original_path']: row['sha256'] for row in candidate['files']}
    docs = [R.TRIAL / name for name in ('README.md', '設定と結果.md', 'CSV閲覧案内.md')]
    assert R.sha(docs[1]) == '2a39ec06f66be99380a7bde0a3e7f645fad24de9500866b47520bf6b0bfbe079'
    value['documents'] = [{'ref': R.reference(path), 'previous_sha256': previous.get(str(path.resolve()))} for path in docs]
    extra = [R.OWN / name for name in ('最終文書を整える.py', '完了を認証する.py', Path(__file__).name)]
    value['additional_code'] += [R.reference(path) for path in extra]
    value['refs']['report'] = R.reference(R.TRIAL / '検査/報告の生成確認.json', 'da8972583426c47703aabda267cd4853371b884e9e3ba5b565fffe539958e593')
    value['外部最終文書'] = {
        '共通知見': R.reference(R.ROOT / 'docs/議論/有効状態と通常値幅保護の比較結果.md', 'f888af8a23beb3cf1204a5cea9dae03d9916fa03655afb0738cb351d45fac14f'),
        'CSV出力案内': R.reference(R.ROOT / 'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/110損益CSV/README.md', '0c75e62cf262091ddb79e9060edcb811767d722019d23aa4c5d3e5ddc96fa848'),
        '最終文書生成確認': R.reference(R.TRIAL / '検査/最終文書の生成確認.json', 'a714a90004eea4064d5679a8d6b6b5bea6142f9a7210843883a5badb6d5f0fc1'),
    }
    value['fixed'] = True
    value['未確定'] = ['この新要求を停止187c版正式ZIP器へ渡す', '全索引とZIP/現物を認証して110試行だけを閉鎖']
    value['素材原本'] = R.reference(material_path)
    value['権限'] = 'Rootが110最終文書とZIP/試行閉鎖を委譲。global目次/AGENTS/111は変更しない'
    ref = R.write_new(R.OWN / '正式ZIPの要求.json', value)
    print(json.dumps({'成功': True, '要求': ref, '最終文書': value['documents'], '追加実使用code': len(value['additional_code'])}, ensure_ascii=False))


if __name__ == '__main__':
    main()
