package publicdelivery

import (
	"encoding/json"
	"fmt"
	"math"
	"reflect"

	warm "github.com/masayoshi4649/SessionTradeExecuter/chartwarmup96"
	finance "github.com/masayoshi4649/SessionTradeExecuter/minivariableguard"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
)

type Known struct {
	EMA8  bool `json:"ema8"`
	EMA21 bool `json:"ema21"`
	Hist  bool `json:"hist"`
	Close bool `json:"close"`
}
type OHLC struct {
	Open          float64 `json:"open"`
	High          float64 `json:"high"`
	Low           float64 `json:"low"`
	Close         float64 `json:"close"`
	PublicationID string  `json:"publication_id"`
}

// Frame は4a30の公開値型と同じ値だけを持ちます。指標を形成しません。
type Frame struct {
	ID                string            `json:"id"`
	Ordinal           int               `json:"ordinal"`
	Session           string            `json:"session"`
	Contract          string            `json:"contract"`
	Start             float64           `json:"start"`
	End               float64           `json:"end"`
	AvailableAt       float64           `json:"available_at"`
	ObservedClock     float64           `json:"observed_clock"`
	At                float64           `json:"at"`
	TechnicalEnd      float64           `json:"technical_end"`
	DataKnown         bool              `json:"data_known"`
	LastSource        *warm.SourceStamp `json:"last_source"`
	EMA8              float64           `json:"ema8"`
	EMA21             float64           `json:"ema21"`
	Hist              float64           `json:"hist"`
	Close             float64           `json:"close"`
	Known             Known             `json:"known"`
	OHLC              *OHLC             `json:"ohlc"`
	ExtensionSupplied bool              `json:"extension_supplied"`
}
type Pivot struct {
	Kind        string  `json:"kind"`
	Price       float64 `json:"price"`
	CenterID    string  `json:"center_id"`
	CenterEnd   float64 `json:"center_end"`
	ConfirmID   string  `json:"confirm_id"`
	ConfirmEnd  float64 `json:"confirm_end"`
	PublishedAt float64 `json:"published_at"`
}
type Role struct {
	M          finance.WidthTruth `json:"M"`
	P          finance.WidthTruth `json:"P"`
	PriorPivot *Pivot             `json:"prior_pivot"`
}

// Result は重複時だけnew/id二欄を保存する4a30同型の返り値です。
type Result struct {
	New         bool               `json:"new"`
	ID          string             `json:"id"`
	ResetReason string             `json:"reset_reason"`
	C           finance.WidthTruth `json:"C"`
	Buy         Role               `json:"buy"`
	Sell        Role               `json:"sell"`
	NewPivots   []Pivot            `json:"new_pivots"`
}

// Tracker は公表窓と公表済みpivotだけを持ち、価格列や金融を形成しません。
type Tracker struct {
	last            *Frame
	history, prices []Frame
	low, high       *Pivot
	reason          string
}

// clone は公開値のpointer/sliceを共有しないcopyを返します。
//
// 引数: v(T)は保存可能な型。返り値: Tは独立値です。型内部の不変条件違反はpanicです。
func clone[T any](v T) T {
	b, e := json.Marshal(v)
	if e != nil {
		panic(e)
	}
	var out T
	if e = json.Unmarshal(b, &out); e != nil {
		panic(e)
	}
	return out
}

// truth は必要未知をfalseへ変えず保存します。
//
// 引数: known/passed(bool)は既知性とstrict成立。返り値: WidthTruthは未知ならpassed=nilです。
func truth(known, passed bool) finance.WidthTruth {
	if !known {
		return finance.WidthTruth{}
	}
	return finance.WidthTruth{Known: true, Passed: &passed}
}

// finite は数値の有限性を確認します。
//
// 引数: values(...float64)は公開数値。返り値: boolは全て有限なら真です。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// FromPublication は停止publicchartの元値を4a30 Frameへ明示射影します。
//
// 引数: p(chart.Publication)、at(float64)は実Go公開値と配送評価時計です。
// 返り値: Frame/errorは追加OHLC/個別Knownを持つ公開値又は未来/出典不一致です。
func FromPublication(p chart.Publication, at float64) (Frame, error) {
	s, c := p.Snapshot.Legacy, p.Snapshot.Three
	t := s.Chart.Technical
	f := Frame{}
	if !p.Three || s.At != p.At || s.InvalidatedAt != 0 {
		return f, fmt.Errorf("新3分公表そのものが必要")
	}
	expected := chart.PublicationID{Session: s.Scene.ID, Contract: s.Scene.Contract, BarEnd: c.BarEnd}
	if p.ID != expected || c.ID != expected {
		return f, fmt.Errorf("公表IDの出典差")
	}
	f = Frame{ID: finance.WidthPublicationID(s.Scene.ID, s.Scene.Contract, s.Three.BarEnd), Ordinal: p.Ordinal, Session: s.Scene.ID, Contract: s.Scene.Contract, Start: s.Scene.Start, End: s.Three.BarEnd, AvailableAt: s.Three.AvailableAt, ObservedClock: s.Three.ObservedClock, At: p.At, TechnicalEnd: t.Bar3End, DataKnown: s.Three.DataKnown, EMA8: t.EMA8_3, EMA21: t.EMA21_3, Hist: t.Histogram3, Close: t.Close3, Known: Known{c.EMA8Known, c.EMA21Known, c.HistogramKnown, c.Known}, ExtensionSupplied: true}
	if s.Three.HasLastSource {
		v := s.Three.LastSource
		f.LastSource = &v
	}
	if c.Known {
		f.OHLC = &OHLC{c.OHLC.Open, c.OHLC.High, c.OHLC.Low, c.OHLC.Close, finance.WidthPublicationID(expected.Session, expected.Contract, c.BarEnd)}
	}
	if e := Validate(f); e != nil {
		return f, e
	}
	if !finite(at) || f.End > at || f.AvailableAt > at {
		return f, fmt.Errorf("評価時点より未来の公開値")
	}
	return f, nil
}

// Validate は停止4a30と同じ公開足/既知値/半開出典を検査します。
//
// 引数: f(Frame)は一公表。返り値: errorは破損です。正常なwarmup未知を不正にしません。
func Validate(f Frame) error {
	if f.Session == "" || f.Contract == "" || f.Ordinal < 1 || !finite(f.Start, f.End, f.At, f.AvailableAt, f.ObservedClock, f.TechnicalEnd, f.EMA8, f.EMA21, f.Hist, f.Close) {
		return fmt.Errorf("識別又は数値不正")
	}
	if f.End <= f.Start || math.Mod(f.End-f.Start, 180) != 0 || f.At != f.End || f.TechnicalEnd != f.End || f.AvailableAt != f.End || f.ObservedClock < f.AvailableAt || f.ID != finance.WidthPublicationID(f.Session, f.Contract, f.End) {
		return fmt.Errorf("足公表時計/ID不正")
	}
	if f.DataKnown {
		s := f.LastSource
		if s == nil || !s.Valid || !finite(s.Time, s.Last) || s.Time < f.End-180 || s.Time >= f.End || s.Line <= 0 || s.Index < 0 || s.Last <= 0 {
			return fmt.Errorf("当足より未来又は別足の出典")
		}
		if (f.Known.Close && f.Close <= 0) || (f.Known.EMA8 && f.EMA8 <= 0) || (f.Known.EMA21 && f.EMA21 <= 0) {
			return fmt.Errorf("既知価格不正")
		}
	}
	if o := f.OHLC; o != nil {
		if !f.DataKnown || !f.Known.Close || o.PublicationID != f.ID || !finite(o.Open, o.High, o.Low, o.Close) || o.Open <= 0 || o.High <= 0 || o.Low <= 0 || o.Close <= 0 || o.Close != f.Close || o.Low > math.Min(o.Open, o.Close) || math.Max(o.Open, o.Close) > o.High {
			return fmt.Errorf("OHLC出典/形状不正")
		}
	}
	return nil
}

// NewTracker は金融所有なしの読取器を初期化します。
//
// 引数: なし。返り値: *Trackerは窓/構造が空の状態です。
func NewTracker() *Tracker { t := &Tracker{}; t.Reset("初期化"); return t }

// Reset は技法窓/構造だけを失効し、重複/後退検査用lastを保持します。
//
// 引数: reason(string)は外部の明示失効理由。返り値: ありません。公表や値を合成しません。
func (t *Tracker) Reset(reason string) {
	t.history, t.prices = []Frame{}, []Frame{}
	t.low, t.high = nil, nil
	t.reason = reason
}

// Feed はPを先に評価し、その後に同足の左右2確認pivotを登録します。
//
// 引数: frame(Frame)は新公表又は完全同体の再送。返り値: Result/errorは全C/M/P又は破損です。
func (t *Tracker) Feed(frame Frame) (Result, error) {
	out := Result{ID: frame.ID, NewPivots: []Pivot{}}
	if e := Validate(frame); e != nil {
		return out, e
	}
	f := clone(frame)
	prior := t.last
	reset := ""
	same := prior != nil && f.Session == prior.Session && f.Contract == prior.Contract
	if same && f.End == prior.End {
		if !reflect.DeepEqual(f, *prior) {
			return out, fmt.Errorf("同公表の値変更")
		}
		return out, nil
	}
	if same && (f.End < prior.End || f.Ordinal <= prior.Ordinal) {
		return out, fmt.Errorf("公表後退")
	}
	if same && f.End == prior.End+180 && f.Ordinal != prior.Ordinal+1 {
		return out, fmt.Errorf("連続公表のordinal飛越")
	}
	if !same || f.End != prior.End+180 {
		reset = "場/限月変更又は欠足"
		t.Reset(reset)
	}
	t.last = &f
	if !f.DataKnown {
		reset = "不良/空の確定足"
		t.Reset(reset)
	} else {
		t.history = append(t.history, f)
		if len(t.history) > 3 {
			t.history = t.history[len(t.history)-3:]
		}
	}
	ck := len(t.history) == 3
	gaps := []float64{}
	for _, h := range t.history {
		ck = ck && h.Known.EMA8 && h.Known.EMA21
		gaps = append(gaps, math.Abs(h.EMA8-h.EMA21))
	}
	cp := false
	if ck {
		cp = gaps[2] < gaps[1] && gaps[1] < gaps[0]
	}
	mk := len(t.history) >= 2
	delta := 0.0
	if mk {
		a, b := t.history[len(t.history)-2], t.history[len(t.history)-1]
		mk = a.Known.Hist && b.Known.Hist
		if mk {
			delta = b.Hist - a.Hist
		}
	}
	if f.OHLC == nil {
		t.prices = []Frame{}
		t.low, t.high = nil, nil
	}
	out.New, out.ResetReason, out.C = true, reset, truth(ck, cp)
	out.Buy.M, out.Sell.M = truth(mk, delta < 0), truth(mk, delta > 0)
	for _, item := range []struct {
		role  *Role
		side  int
		pivot *Pivot
	}{{&out.Buy, 1, t.low}, {&out.Sell, -1, t.high}} {
		known := f.DataKnown && f.Known.Close && f.OHLC != nil && item.pivot != nil
		passed := false
		if known {
			passed = float64(item.side)*(f.Close-item.pivot.Price) < 0
		}
		item.role.P = truth(known, passed)
		item.role.PriorPivot = clone(item.pivot)
	}
	if f.DataKnown && f.OHLC != nil {
		t.prices = append(t.prices, f)
		if len(t.prices) > 5 {
			t.prices = t.prices[len(t.prices)-5:]
		}
		if len(t.prices) == 5 {
			center := t.prices[2]
			for _, kind := range []string{"low", "high"} {
				value := center.OHLC.Low
				sign := -1.0
				if kind == "high" {
					value = center.OHLC.High
					sign = 1
				}
				passed := true
				for i, h := range t.prices {
					if i == 2 {
						continue
					}
					x := h.OHLC.Low
					if kind == "high" {
						x = h.OHLC.High
					}
					if i < 2 {
						passed = passed && sign*value > sign*x
					} else {
						passed = passed && sign*value >= sign*x
					}
				}
				if passed {
					p := Pivot{kind, value, center.ID, center.End, f.ID, f.End, f.AvailableAt}
					if kind == "low" {
						t.low = &p
					} else {
						t.high = &p
					}
					out.NewPivots = append(out.NewPivots, p)
				}
			}
		}
	}
	return out, nil
}
