package publicdelivery

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"reflect"
	"sort"
	"strconv"
	"strings"

	finance "github.com/masayoshi4649/SessionTradeExecuter/minivariableguard"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
)

// Values は停止Pythonと同じnew/id又は全結果の辞書を作ります。
//
// 引数: なし。返り値: map[string]anyは数値型を保持した公開結果です。
func (r Result) Values() map[string]any {
	out := map[string]any{"new": r.New, "id": r.ID}
	if r.New {
		out["reset_reason"] = r.ResetReason
		out["C"] = r.C
		out["buy"] = r.Buy
		out["sell"] = r.Sell
		out["new_pivots"] = r.NewPivots
	}
	return out
}

// MarshalJSON は重複時を二欄だけとする停止4a30の保存型に従います。
//
// 引数: なし。返り値: []byte/errorは公開結果のJSONです。指標を変更しません。
func (r Result) MarshalJSON() ([]byte, error) { return json.Marshal(r.Values()) }

// pythonCanonical は固定型の整数/floatを分けPython canonical_shaと同じJSONへ写します。
//
// 引数: value(any)はFrame又はResult.Valuesの公開型だけです。
// 返り値: string/errorはsort_keys/UTF-8/有限数のJSONです。市場値を読取りません。
func pythonCanonical(value any) (string, error) {
	var encode func(reflect.Value) (string, error)
	quote := func(s string) string {
		var b bytes.Buffer
		e := json.NewEncoder(&b)
		e.SetEscapeHTML(false)
		_ = e.Encode(s)
		return strings.TrimSuffix(b.String(), "\n")
	}
	encode = func(v reflect.Value) (string, error) {
		if !v.IsValid() {
			return "null", nil
		}
		if v.Kind() == reflect.Interface || v.Kind() == reflect.Pointer {
			if v.IsNil() {
				return "null", nil
			}
			return encode(v.Elem())
		}
		if v.Type() == reflect.TypeOf(json.Number("")) {
			n := v.Interface().(json.Number)
			text := n.String()
			if !strings.ContainsAny(text, ".eE") {
				return text, nil
			}
			f, e := n.Float64()
			if e != nil {
				return "", e
			}
			return encode(reflect.ValueOf(f))
		}
		switch v.Kind() {
		case reflect.Bool:
			if v.Bool() {
				return "true", nil
			}
			return "false", nil
		case reflect.String:
			return quote(v.String()), nil
		case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
			return strconv.FormatInt(v.Int(), 10), nil
		case reflect.Float32, reflect.Float64:
			f := v.Float()
			if !finite(f) {
				return "", fmt.Errorf("canonical非有限")
			}
			a := f
			if a < 0 {
				a = -a
			}
			s := ""
			if a != 0 && (a < 1e-4 || a >= 1e16) {
				s = strconv.FormatFloat(f, 'g', -1, 64)
			} else {
				s = strconv.FormatFloat(f, 'f', -1, 64)
				if !strings.Contains(s, ".") {
					s += ".0"
				}
			}
			return s, nil
		case reflect.Slice, reflect.Array:
			if v.Kind() == reflect.Slice && v.IsNil() {
				return "null", nil
			}
			out := []string{}
			for i := 0; i < v.Len(); i++ {
				s, e := encode(v.Index(i))
				if e != nil {
					return "", e
				}
				out = append(out, s)
			}
			return "[" + strings.Join(out, ",") + "]", nil
		case reflect.Map:
			if v.IsNil() {
				return "null", nil
			}
			keys := v.MapKeys()
			sort.Slice(keys, func(i, j int) bool { return keys[i].String() < keys[j].String() })
			out := []string{}
			for _, k := range keys {
				if k.Kind() != reflect.String {
					return "", fmt.Errorf("canonical辞書キー型")
				}
				s, e := encode(v.MapIndex(k))
				if e != nil {
					return "", e
				}
				out = append(out, quote(k.String())+":"+s)
			}
			return "{" + strings.Join(out, ",") + "}", nil
		case reflect.Struct:
			fields := map[string]any{}
			typ := v.Type()
			for i := 0; i < v.NumField(); i++ {
				f := typ.Field(i)
				if !f.IsExported() {
					continue
				}
				name := strings.Split(f.Tag.Get("json"), ",")[0]
				if name == "-" {
					continue
				}
				if name == "" {
					name = f.Name
				}
				fields[name] = v.Field(i).Interface()
			}
			return encode(reflect.ValueOf(fields))
		}
		return "", fmt.Errorf("canonical未対応型:%s", v.Kind())
	}
	return encode(reflect.ValueOf(value))
}

// CanonicalSHA は停止ec8d canonical_shaと同じ型保存SHAを求めます。
//
// 引数: value(any)は公開Frame又は結果辞書です。
// 返り値: string/errorはSHA256又は非有限/型不正です。価格由来を捏造しません。
func CanonicalSHA(value any) (string, error) {
	// 停止PythonはGo JSONを読んだ型を正本にする。整数表記floatはJSON読取後のintへ合わせる。
	b, e := json.Marshal(value)
	if e != nil {
		return "", e
	}
	d := json.NewDecoder(bytes.NewReader(b))
	d.UseNumber()
	var normalized any
	if e = d.Decode(&normalized); e != nil {
		return "", e
	}
	s, e := pythonCanonical(normalized)
	if e != nil {
		return "", e
	}
	h := sha256.Sum256([]byte(s))
	return hex.EncodeToString(h[:]), nil
}

// AsObservation はC/M/P全値をBook用の一方向境界へ明示射影します。
//
// 引数: f(Frame)、r(Result)、side(int)は同じ公表と評価結果、方向です。
// 返り値: *WidthObservation/errorは新公表のみ。重複はnilで再消費しません。
func AsObservation(f Frame, r Result, side int) (*finance.WidthObservation, error) {
	if e := Validate(f); e != nil {
		return nil, e
	}
	if (side != 1 && side != -1) || r.ID != f.ID {
		return nil, fmt.Errorf("結果のID/方向差")
	}
	if !r.New {
		return nil, nil
	}
	role := r.Buy
	if side < 0 {
		role = r.Sell
	}
	fh, e := CanonicalSHA(f)
	if e != nil {
		return nil, e
	}
	rh, e := CanonicalSHA(r.Values())
	if e != nil {
		return nil, e
	}
	return &finance.WidthObservation{Session: f.Session, Contract: f.Contract, Side: side, PublicationID: f.ID, Ordinal: f.Ordinal, End: f.End, AvailableAt: f.AvailableAt, C: clone(r.C), M: clone(role.M), P: clone(role.P), FrameSHA: fh, ResultSHA: rh}, nil
}

// Delivery は全公開評価と両方向の型を保持し、Source/Scalarを持ちません。
type Delivery struct {
	At     float64                   `json:"at"`
	Frame  Frame                     `json:"frame"`
	Result Result                    `json:"result"`
	Buy    *finance.WidthObservation `json:"buy"`
	Sell   *finance.WidthObservation `json:"sell"`
}

// Receiver は停止c0bfの公表保管/reset APIだけです。金融Stepを呼べません。
type Receiver interface {
	OnWidthObservation(float64, finance.WidthObservation) error
	ResetWidthObservation(float64, string) error
}

// Pipeline は一つの公表系列の読取器です。暖機・指標形成・金融を行いません。
type Pipeline struct {
	tracker *Tracker
	at      float64
	have    bool
}

// NewPipeline は停止公開値からの配送器を作ります。
//
// 引数: なし。返り値: *Pipelineは所有なしの新系列です。
func NewPipeline() *Pipeline { return &Pipeline{tracker: NewTracker()} }

// Feed は新3分Go公表を一度だけC/M/Pへ評価して両方向型へ写します。
//
// 引数: p(chart.Publication)、at(float64)は公開値と配送時計。
// 返り値: Delivery/errorは全field付き結果又は出典/未来/逆行差です。
func (p *Pipeline) Feed(pub chart.Publication, at float64) (Delivery, error) {
	d := Delivery{At: at}
	if !finite(at) || (p.have && at < p.at) {
		return d, fmt.Errorf("配送時計の逆行")
	}
	f, e := FromPublication(pub, at)
	if e != nil {
		return d, e
	}
	r, e := p.tracker.Feed(f)
	if e != nil {
		return d, e
	}
	buy, e := AsObservation(f, r, 1)
	if e != nil {
		return d, e
	}
	sell, e := AsObservation(f, r, -1)
	if e != nil {
		return d, e
	}
	p.at, p.have = at, true
	d.Frame, d.Result, d.Buy, d.Sell = f, r, buy, sell
	return d, nil
}

// Send は公表/resetだけをBookへ渡し、Quote/MTM/起動/注文を作りません。
//
// 引数: d(Delivery)、book(Receiver)は同場/限月の新結果と受け皿。
// 返り値: errorは受け皿が拒否した出典/時計です。重複は何も送りません。
func Send(d Delivery, book Receiver) error {
	if !d.Result.New {
		return nil
	}
	if d.Buy == nil || d.Sell == nil {
		return fmt.Errorf("両方向型の不足")
	}
	if d.Result.ResetReason != "" {
		if e := book.ResetWidthObservation(d.At, d.Result.ResetReason); e != nil {
			return e
		}
	}
	for _, o := range []*finance.WidthObservation{d.Buy, d.Sell} {
		if e := book.OnWidthObservation(d.At, *o); e != nil {
			return e
		}
	}
	return nil
}

// Reset は明示Last0/欠測を窓とBookへ配送し、旧ID再送を復活させません。
//
// 引数: at(float64)、reason(string)、books(...Receiver)は制御時計・理由・受け皿。
// 返り値: errorは逆行/空理由/受け皿の出典差です。狭幅/床はBook側で保持します。
func (p *Pipeline) Reset(at float64, reason string, books ...Receiver) error {
	if !finite(at) || reason == "" || (p.have && at < p.at) {
		return fmt.Errorf("resetの時計/理由不正")
	}
	p.tracker.Reset(reason)
	p.at, p.have = at, true
	for _, b := range books {
		if e := b.ResetWidthObservation(at, reason); e != nil {
			return e
		}
	}
	return nil
}
