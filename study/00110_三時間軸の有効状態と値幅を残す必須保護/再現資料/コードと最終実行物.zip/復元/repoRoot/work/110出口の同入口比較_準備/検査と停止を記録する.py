"""比較器の人工検査と原本不変を一回だけmetadataへ記録する。"""

from pathlib import Path
import ast
import hashlib
import json
import subprocess
import sys


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
ORIGINS = {
    ROOT / "work/109出口の同入口比較/比較する.py": "2dfcb72f083e50bce5d2b3a751406959c768103103e5c78347474edaa23abc4b",
    ROOT / "work/109出口の同入口比較/比較の人工検査.py": "3bf4c89edd86457f440b8988931c631ccab814994340d7bdf ea57efb3adb1bf5".replace(" ", ""),
}


def digest(path: Path) -> str:
    """コード又は説明の全バイト指紋を取る。

    引数: path(Path)は明示した非価格ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """実入力なしで人工検査し、新規の停止記録を残す。

    引数: なし。
    返り値: None。実completion・保存結果・Nativeを読まない。
    """
    target = OWN / "停止.json"
    assert not target.exists()
    assert all(digest(path) == expected for path, expected in ORIGINS.items())
    paths = sorted(OWN.glob("*.py")) + [OWN / "README.md"]
    before = {str(path): digest(path) for path in paths}
    functions = 0
    for path in OWN.glob("*.py"):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                comment = ast.get_docstring(node)
                assert comment and "\n" in comment and "引数:" in comment and "返り値:" in comment
                functions += 1
    result = subprocess.run([sys.executable, "-B", "-X", "utf8", str(OWN / "比較の人工検査.py")], capture_output=True, text=True, encoding="utf-8", check=False)
    assert result.returncode == 0, result.stdout + result.stderr
    after = {str(path): digest(path) for path in paths}
    assert before == after and all(digest(path) == expected for path, expected in ORIGINS.items())
    proof = {"試行": 110, "成功": True, "市場実行": False, "実金融結果読取": False, "Raw又は価格又はSourceRecord読取": False, "11月09日読取": False, "原本変更": False, "原本SHA256": {str(path): expected for path, expected in ORIGINS.items()}, "所有SHA256": before, "前後不変": before == after, "関数コメント確認数": functions, "人工主検査": 6, "実行": {"終了コード": result.returncode, "標準出力": result.stdout, "標準エラー": result.stderr}, "範囲": "110同入口比較の準備。手製全70/36冊から24比較1680場別、同入口・取得変更・片側参加の分離と実現加法。実全70結果の比較成功ではない"}
    with target.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "停止": str(target), "sha256": digest(target), "人工主検査": 6, "実金融結果読取": False}, ensure_ascii=False))


if __name__ == "__main__":
    main()
