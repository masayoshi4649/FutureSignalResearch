"""110比較器を手製のSource・実注文・実fillだけで検査する。"""

from contextlib import redirect_stdout
from datetime import date, timedelta
from pathlib import Path
from unittest.mock import patch
import copy
import gzip
import io
import json
import tempfile
import unittest

import 比較する as A


def book(specifications: list[tuple]) -> dict:
    """Source・注文・fill・玉が一対一の完結人工口座を作る。

    引数: specifications(list[tuple])は識別子・実現純額・u/W正益・起動の指定。
    返り値: dictは手製口座。実市場や既存Nativeを参照しない。
    """
    positions, orders, fills = [], [], []
    for index, (identity, net, positive, active) in enumerate(specifications):
        quote = {"time": 100 + index, "index": index + 2, "source_line": index + 3, "bid": 100, "ask": 105}
        source = {"method": "人工手法", "signal_id": identity, "birth_quantity": 2, "birth_time": 90, "birth_quote": quote}
        pid, oid, fid, hold = "玉" + identity, "注文" + identity, "約定" + identity, "元玉" + identity
        position = {"id": pid, "entry_order_id": oid, "source": source, "source_hold_id": hold, "side": 1, "initial_quantity": 2, "quantity": 0, "reserved": 0, "closed_quantity": 2, "entry_price": 105, "entry_quote": quote, "realized_net": net, "marks": {"first_unit_positive": {"人工": True} if positive else None, "first_whole_positive": {"人工": True} if positive else None}, "protection_active": active, "activation": {"人工": True} if active else None}
        order = {"id": oid, "kind": "entry", "side": 1, "quantity": 2, "position_id": pid, "source": source, "source_hold_id": hold, "request_time": 99 + index, "request_quote": quote, "reason": "人工新規", "status": "filled", "fill_id": fid}
        fill = {"id": fid, "order_id": oid, "position_id": pid, "action": "new", "side": 1, "quantity": 2, "price": 105, "quote": quote, "source": source, "source_hold_id": hold, "reason": "人工新規", "fee_yen": 77, "slip_yen": 0, "gross_yen": 0, "net_contribution_yen": -77, "allocations": []}
        positions.append(copy.deepcopy(position))
        orders.append(copy.deepcopy(order))
        fills.append(copy.deepcopy(fill))
    return json.loads(json.dumps({"positions": positions, "orders": orders, "fills": fills, "totals": {"net_yen": sum(position["realized_net"] for position in positions)}}))


def rename_policy_ids(data: dict) -> dict:
    """政策名だけが違う注文・fill・玉のIDを手製に置換する。

    引数: data(dict)は人工口座。
    返り値: dictは経済的入口を変えない複製。
    """
    changed = copy.deepcopy(data)
    for position, order, fill in zip(changed["positions"], changed["orders"], changed["fills"]):
        position["id"] += "別政策"
        order["id"] += "別政策"
        fill["id"] += "別政策"
        position["entry_order_id"] = order["id"]
        order["position_id"] = fill["position_id"] = position["id"]
        fill["order_id"] = order["id"]
        order["fill_id"] = fill["id"]
    return changed


def write_json(path: Path, value: dict) -> str:
    """一時領域へ人工JSONを書き、人工指紋を返す。

    引数: path(Path)は一時先、value(dict)は手製値。
    返り値: strは生成した人工ファイルのSHA256。
    """
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "wt", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False)
    return A.sha(path)


class 比較検査(unittest.TestCase):
    """群分けの境界・負値保存・全70形の受付を検査する。"""

    def test_政策IDの違いだけは同入口(self) -> None:
        """政策由来IDを除き実経済入口を比較する。

        引数: self(比較検査)。返り値: None。
        """
        a = book([("A", 100, True, True)])
        result = A.compare(a, rename_policy_ids(a))
        self.assertTrue(result["全同実入口"])
        self.assertEqual(result["群"]["同実入口"]["前"]["玉"], 1)
        self.assertEqual(result["全体"]["実現差円"], 0)

    def test_省略しやすい入口差を取得変更へ分ける(self) -> None:
        """同Sourceでも時刻・価格・数量・Source全文・気配・費用の差を検出する。

        引数: self(比較検査)。返り値: None。
        """
        a = book([("A", 100, True, True)])
        cases = []
        changed = copy.deepcopy(a)
        changed["positions"][0]["entry_price"] = changed["fills"][0]["price"] = 110
        cases.append(changed)
        changed = copy.deepcopy(a)
        for obj, field in ((changed["positions"][0], "entry_quote"), (changed["fills"][0], "quote")):
            obj[field]["time"] += 1
            obj[field]["source_line"] += 1
        cases.append(changed)
        changed = copy.deepcopy(a)
        changed["orders"][0]["request_time"] -= 1
        cases.append(changed)
        changed = copy.deepcopy(a)
        changed["orders"][0]["request_quote"]["source_line"] += 1
        cases.append(changed)
        changed = copy.deepcopy(a)
        changed["positions"][0]["initial_quantity"] = changed["positions"][0]["closed_quantity"] = changed["orders"][0]["quantity"] = changed["fills"][0]["quantity"] = 1
        cases.append(changed)
        changed = copy.deepcopy(a)
        for obj in (changed["positions"][0], changed["orders"][0], changed["fills"][0]):
            obj["source"]["birth_quantity"] += 1
        cases.append(changed)
        changed = copy.deepcopy(a)
        for obj in (changed["positions"][0], changed["orders"][0], changed["fills"][0]):
            obj["source_hold_id"] = "別SourceHold"
        cases.append(changed)
        changed = copy.deepcopy(a)
        for obj in (changed["positions"][0], changed["orders"][0], changed["fills"][0]):
            obj["side"] = -1
        cases.append(changed)
        changed = copy.deepcopy(a)
        changed["fills"][0]["fee_yen"] += 1
        cases.append(changed)
        for changed in cases:
            result = A.compare(a, changed)
            self.assertFalse(result["全同実入口"])
            self.assertEqual(result["群"]["取得変更"]["前"]["玉"], 1)
            self.assertEqual(result["群"]["同実入口"]["前"]["玉"], 0)

    def test_四群の実現額と利益後赤字を加法分解する(self) -> None:
        """同入口・取得変更・両片側の実現額を分け、架空取引を作らない。

        引数: self(比較検査)。返り値: None。
        """
        a = book([("同", 10, True, True), ("変", -8, True, False), ("前", -5, False, False)])
        b = book([("同", -3, True, True), ("変", 20, True, True), ("後", 7, False, False)])
        b["positions"][1]["entry_price"] = b["fills"][1]["price"] = 110
        result = A.compare(a, b)
        self.assertEqual(result["全体"]["実現差円"], 27)
        self.assertEqual([result["群"][name]["実現差円"] for name in A.GROUPS], [-13, 28, 5, 7])
        self.assertEqual(result["群"]["前のみ"]["後"]["玉"], 0)
        self.assertEqual(result["群"]["後のみ"]["前"]["玉"], 0)
        self.assertEqual(result["群"]["同実入口"]["後"]["u正益後赤字玉"], 1)
        self.assertEqual(result["群"]["同実入口"]["後"]["起動後赤字額円"], -3)
        self.assertEqual(result["同実入口の勝敗遷移"]["勝→負"]["実現差円"], -13)

    def test_負値とゼロを期間加算で残す(self) -> None:
        """Counter加算による負値消失を防ぎゼロ取引場も含める。

        引数: self(比較検査)。返り値: None。
        """
        first = A.compare(book([("A", -10, True, True)]), book([("A", -20, True, True)]))
        second = A.compare(book([]), book([]))
        total = A.add_results([first, second])
        self.assertEqual(total["全体"]["前"]["損失総額円"], -10)
        self.assertEqual(total["全体"]["後"]["起動後赤字額円"], -20)
        self.assertEqual(total["全体"]["実現差円"], -10)
        self.assertEqual(total["群"]["前のみ"]["前"]["玉"], 0)
        self.assertEqual(total["同実入口の勝敗遷移"]["負→負"]["実現差円"], -10)

    def test_重複と所有不整合と非完結を拒否する(self) -> None:
        """同Source重複・注文fill所有・残量・純額の破損を拒否する。

        引数: self(比較検査)。返り値: None。
        """
        base = book([("A", 100, True, True)])
        cases = []
        for collection in ("positions", "orders", "fills"):
            changed = copy.deepcopy(base)
            changed[collection].append(copy.deepcopy(changed[collection][0]))
            cases.append(changed)
        for path, value in ((('positions', 'quantity'), 1), (('positions', 'reserved'), 1), (('positions', 'closed_quantity'), 1), (('fills', 'position_id'), '他玉'), (('fills', 'order_id'), '他注文'), (('fills', 'action'), 'close'), (('orders', 'status'), 'pending'), (('orders', 'side'), -1), (('positions', 'protection_active'), False)):
            changed = copy.deepcopy(base)
            changed[path[0]][0][path[1]] = value
            cases.append(changed)
        changed = copy.deepcopy(base)
        changed["totals"]["net_yen"] += 1
        cases.append(changed)
        for changed in cases:
            with self.assertRaises((ValueError, KeyError)):
                A.compare(base, changed)

    def test_手製全70から24比較1680行を生成する(self) -> None:
        """全70形のmetadata・36冊・独立保存純額への結合を人工だけで確認する。

        引数: self(比較検査)。返り値: None。
        """
        with tempfile.TemporaryDirectory(prefix="110同入口人工_") as directory:
            root = Path(directory)
            ids, day = [], date(2026, 9, 21)
            while len(ids) < 70:
                if day.weekday() < 5:
                    ids.extend([day.isoformat() + "_Day", day.isoformat() + "_Night"])
                day += timedelta(days=1)
            refs, summaries = [], {key: {"net_yen": 0} for key in A.keys()}
            for sid in ids:
                books = {}
                for key in A.keys():
                    net = -50 if "_G3_" in key else 150 if "_G4_" in key else 100
                    books[key] = book([("共通", net, True, True)])
                    summaries[key]["net_yen"] += net
                native = {"trial": 110, "complete": True, "session": {"id": sid}, "condition_sha256": A.CONDITION_SHA, "books": books}
                path = root / (sid + ".Native.json.gz")
                refs.append({"session": sid, "native": {"path": str(path), "sha256": write_json(path, native)}})
            complete = {"version": 1, "trial": 110, "stage": "full70", "success": True, "sessions": 70, "books_per_scene": 36, "books": 2520, "shadow_books": 0, "baseline_comparisons": 280, "condition_sha256": A.CONDITION_SHA, "unchanged": True, "before": {"人工": "同体"}, "after": {"人工": "同体"}, "results": refs}
            completion = root / "人工完了.json"
            csha = write_json(completion, complete)
            saved = {"試行": 110, "成功": True, "stage": "full70", "場数": 70, "会計数": 2520, "金融完了SHA256": csha, "金融条件SHA256": A.CONDITION_SHA, "前後不変": True, "入力codeSHA256前": {"人工": "同体"}, "入力codeSHA256後": {"人工": "同体"}, "Native参照": refs, "集計": summaries}
            source = root / "人工保存.json"
            ssha = write_json(source, saved)
            output = root / "人工解析.json"
            with patch.object(A, "OWN", root), redirect_stdout(io.StringIO()):
                result = A.run(source, ssha, completion, csha, output)
            self.assertTrue(result["成功"])
            analysis = json.loads(output.read_text(encoding="utf-8"))
            self.assertEqual((analysis["比較数"], analysis["場別比較数"]), (24, 1680))
            self.assertTrue(analysis["全比較で入口同体"])
            self.assertEqual(analysis["全条件"]["entry_E2_L1_G0対G3_C5_D1"]["全体"]["実現差円"], -10500)
            self.assertEqual(analysis["全条件"]["entry_E0_G0対G4_C0_D0"]["全体"]["後"]["実現円"], 10500)
            self.assertEqual(len(analysis["週別"]["entry_E0_G0対G3_C0_D0"]), 7)
            complete["success"] = False
            bad_sha = write_json(completion, complete)
            with patch.object(A, "OWN", root), self.assertRaises(ValueError):
                A.run(root / "存在しない保存.json", "未読", completion, bad_sha, root / "未作成.json")


if __name__ == "__main__":
    unittest.main(verbosity=2)
