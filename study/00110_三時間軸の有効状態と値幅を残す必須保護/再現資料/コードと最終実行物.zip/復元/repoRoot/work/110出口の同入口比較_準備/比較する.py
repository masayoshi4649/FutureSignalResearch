"""110の両実戦略を同入口・取得変更・片側のみへ分け、実現額だけを比較する。"""

from collections import Counter, defaultdict
from datetime import date
from decimal import Decimal
import argparse
import gzip
import hashlib
import json
from pathlib import Path


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
CONDITION_SHA = "e0f84c5f836a3cb58b6d75c12f08c40e910b661043516e1e642143b6026b9fba"
ENTRY_PREFIXES = ("entry_E0", "entry_E2_L0", "entry_E2_L1")
GUARD_PAIRS = (("G0", "G3"), ("G0", "G4"))
GROUPS = ("同実入口", "取得変更", "前のみ", "後のみ")
ZERO = Decimal(0)


def need(condition: bool, message: str) -> None:
    """指紋・比較母集団・会計の不整合を拒否する。

    引数: condition(bool)は成立条件、message(str)は拒否理由。
    返り値: None。不成立ならValueError。
    """
    if not condition:
        raise ValueError(message)


def sha(path: Path) -> str:
    """許可された保存結果・Native・コードの全バイトを同定する。

    引数: path(Path)はRootが明示した既使用70の保存参照。
    返り値: strはSHA256。Raw・価格CSV・SourceRecordを開かない。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path: Path, expected: str) -> dict:
    """先にSHA256を認証し、JSONをDecimalで読む。

    引数: path(Path)は許可済み保存参照、expected(str)はRootの期待指紋。
    返り値: dictは原数値の保存値。
    """
    need(sha(path) == expected, "入力SHA差:" + str(path))
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as stream:
        return json.load(stream, parse_float=Decimal)


def serial(value: object) -> int | float:
    """有限の十進数をJSON数値へ保存する。

    引数: value(object)はJSON標準型以外の値。
    返り値: int又はfloatは有限数値。不対応型ならTypeError。
    """
    if isinstance(value, Decimal):
        need(value.is_finite(), "非有限数値")
        return int(value) if value == value.to_integral_value() else float(value)
    raise TypeError(type(value).__name__)


def outcome(net: Decimal | int) -> str:
    """完結した玉の費用後実現額を勝・負・同値へ分ける。

    引数: net(Decimal又はint)は実現純額。
    返り値: strは勝・負・同値。
    """
    return "勝" if net > 0 else "負" if net < 0 else "同値"


def keyed(rows: list[dict], field: str) -> dict:
    """保存配列を識別子で結び、重複を拒否する。

    引数: rows(list[dict])は保存配列、field(str)は識別子field。
    返り値: dictは識別子から保存値への写像。
    """
    result = {row[field]: row for row in rows}
    need(len(result) == len(rows), "保存識別子の重複:" + field)
    return result


def mapping(book: dict) -> dict:
    """Sourceの明示method・signal_idで完結実玉を一意に結ぶ。

    引数: book(dict)は完結した実口座。
    返り値: dictはSource識別子から実玉への写像。ID文字列を分割しない。
    """
    result = {}
    for position in book["positions"]:
        source = position["source"]
        identity = source["method"], source["signal_id"]
        need(identity not in result, "同Source出生への重複取得")
        need(position["quantity"] == position["reserved"] == 0, "完結比較の残量・予約は0")
        need(position["closed_quantity"] == position["initial_quantity"] > 0, "完結数量と初期数量")
        result[identity] = position
    return result


def fingerprint(position: dict, orders: dict, fills: dict) -> dict:
    """実入口をSource全文・新規要求・実new fillへ厳密に結合する。

    引数: position(dict)は実玉、orders/fills(dict)はID写像。
    返り値: dictは政策別IDを除く入口の全値。時刻・気配・枚数・費用を省かない。
    """
    order = orders[position["entry_order_id"]]
    need(order["kind"] == "entry" and order["status"] == "filled", "実玉の新規要求は約定済み")
    fill = fills[order["fill_id"]]
    need(fill["action"] == "new", "実玉はnew fillへ結合")
    need(order["position_id"] == fill["position_id"] == position["id"], "注文・fill・玉の所有")
    need(fill["order_id"] == order["id"], "new fillの要求所有")
    for name, p_name in (("source", "source"), ("source_hold_id", "source_hold_id"), ("side", "side"), ("quantity", "initial_quantity")):
        need(order[name] == fill[name] == position[p_name], "注文・fill・玉の同体:" + name)
    need(fill["quote"] == position["entry_quote"] and fill["price"] == position["entry_price"], "new fillと実取得気配・価格")
    need(order["request_time"] <= fill["quote"]["time"], "新規要求から実fillへの時計順")
    order_value = {key: value for key, value in order.items() if key not in ("id", "position_id", "fill_id")}
    fill_value = {key: value for key, value in fill.items() if key not in ("id", "order_id", "position_id")}
    return {"source": position["source"], "source_hold_id": position["source_hold_id"], "side": position["side"], "quantity": position["initial_quantity"], "entry_price": position["entry_price"], "entry_quote": position["entry_quote"], "request": order_value, "fill": fill_value}


def validate_book(book: dict) -> tuple[dict, dict]:
    """完結実玉と新規fillの一対一性・口座純額を認証する。

    引数: book(dict)は一つの完結実口座。
    返り値: tuple[dict,dict]はSource別玉と厳密入口値。
    """
    positions = mapping(book)
    orders = keyed(book["orders"], "id")
    fills = keyed(book["fills"], "id")
    new_fills = [fill for fill in fills.values() if fill["action"] == "new"]
    need(len(new_fills) == len(positions), "各実玉へnew fillは一つ")
    need(len({fill["position_id"] for fill in new_fills}) == len(positions), "new fillの玉所有は一意")
    fingerprints = {key: fingerprint(position, orders, fills) for key, position in positions.items()}
    need({fill["position_id"] for fill in new_fills} == {position["id"] for position in positions.values()}, "new fillの玉集合")
    need(sum((position["realized_net"] for position in positions.values()), ZERO) == book["totals"]["net_yen"], "実玉と口座純額の加法")
    return positions, fingerprints


def statistics(positions: list[dict]) -> dict:
    """成立した実玉の損益・利益後赤字・起動後赤字を集計する。

    引数: positions(list[dict])は実際に成立し完結した玉だけ。
    返り値: dictは件数・枚数・実現純額。損失総額は負符号で保存する。
    """
    result = Counter({name: 0 for name in ("玉", "枚", "実現円", "利益総額円", "損失総額円", "勝玉", "負玉", "同値玉", "u正益玉", "u正益後赤字玉", "u正益後赤字額円", "W正益玉", "W正益後赤字玉", "W正益後赤字額円", "保護起動玉", "起動後赤字玉", "起動後赤字額円")})
    for position in positions:
        net = position["realized_net"]
        marks = position["marks"]
        active = position["protection_active"]
        need(active == (position["activation"] is not None), "起動旗と初回起動点")
        result["玉"] += 1
        result["枚"] += position["initial_quantity"]
        result["実現円"] += net
        result["利益総額円"] += max(ZERO, net)
        result["損失総額円"] += min(ZERO, net)
        result[outcome(net) + "玉"] += 1
        for prefix, name in (("u", "first_unit_positive"), ("W", "first_whole_positive")):
            positive = marks[name] is not None
            result[prefix + "正益玉"] += positive
            result[prefix + "正益後赤字玉"] += positive and net < 0
            result[prefix + "正益後赤字額円"] += net if positive and net < 0 else 0
        result["保護起動玉"] += active
        result["起動後赤字玉"] += active and net < 0
        result["起動後赤字額円"] += net if active and net < 0 else 0
    need(result["実現円"] == result["利益総額円"] + result["損失総額円"], "実現純額の正負分解")
    return dict(result)


def compare(book_a: dict, book_b: dict) -> dict:
    """同費用・同入口政策の二実戦略を四群へ分ける。

    引数: book_a/book_b(dict)は保護方法だけ異なる完結口座。
    返り値: dictは四群と同入口勝敗遷移。未取得側に仮想損益を付けない。
    """
    a, fa = validate_book(book_a)
    b, fb = validate_book(book_b)
    members = {name: {"前": [], "後": []} for name in GROUPS}
    transitions = defaultdict(lambda: {"前": [], "後": []})
    differences = Counter()
    for identity in sorted(a.keys() | b.keys()):
        before, after = a.get(identity), b.get(identity)
        if before is None:
            members["後のみ"]["後"].append(after)
        elif after is None:
            members["前のみ"]["前"].append(before)
        elif fa[identity] != fb[identity]:
            members["取得変更"]["前"].append(before)
            members["取得変更"]["後"].append(after)
            differences.update(name for name in fa[identity] if fa[identity][name] != fb[identity][name])
        else:
            members["同実入口"]["前"].append(before)
            members["同実入口"]["後"].append(after)
            transition = outcome(before["realized_net"]) + "→" + outcome(after["realized_net"])
            transitions[transition]["前"].append(before)
            transitions[transition]["後"].append(after)
    grouped = {}
    for name, values in members.items():
        before, after = statistics(values["前"]), statistics(values["後"])
        grouped[name] = {"前": before, "後": after, "実現差円": after["実現円"] - before["実現円"]}
    total_a, total_b = statistics(list(a.values())), statistics(list(b.values()))
    delta = total_b["実現円"] - total_a["実現円"]
    need(delta == sum((values["実現差円"] for values in grouped.values()), ZERO), "全体実現差と四群の加法")
    for side, total in (("前", total_a), ("後", total_b)):
        need(all(total[name] == sum(values[side][name] for values in grouped.values()) for name in total), "全体実績と群別実績の加法:" + side)
    transition_rows = {}
    for name, values in transitions.items():
        before, after = statistics(values["前"]), statistics(values["後"])
        transition_rows[name] = {"前": before, "後": after, "実現差円": after["実現円"] - before["実現円"]}
    need(sum((row["実現差円"] for row in transition_rows.values()), ZERO) == grouped["同実入口"]["実現差円"], "同入口遷移と同入口群の加法")
    return {"全体": {"前": total_a, "後": total_b, "実現差円": delta}, "群": grouped, "同実入口の勝敗遷移": transition_rows, "取得変更の差分属性": dict(differences), "全同実入口": not any(grouped[name][side]["玉"] for name in GROUPS[1:] for side in ("前", "後"))}


def add_results(rows: list[dict]) -> dict:
    """場別比較の全実績を同じ比較内で加算する。

    引数: rows(list[dict])は一つの入口・費用・遅延・保護対の結果。
    返り値: dictは金額・件数・遷移の期間集計。boolは数値加算しない。
    """
    need(bool(rows), "加算対象が空")
    result = {"全体": {}, "群": {}, "同実入口の勝敗遷移": {}, "取得変更の差分属性": dict(sum((Counter(row["取得変更の差分属性"]) for row in rows), Counter())), "全同実入口": all(row["全同実入口"] for row in rows)}
    for section in ("全体", "群", "同実入口の勝敗遷移"):
        groups = [None] if section == "全体" else sorted({key for row in rows for key in row[section]})
        for name in groups:
            entries = [row[section] if name is None else row[section][name] for row in rows if name is None or name in row[section]]
            summed = {side: {key: sum((entry[side][key] for entry in entries), ZERO) for key in entries[0][side]} for side in ("前", "後")}
            summed["実現差円"] = sum((entry["実現差円"] for entry in entries), ZERO)
            need(summed["後"]["実現円"] - summed["前"]["実現円"] == summed["実現差円"], "期間実現差の加法")
            if name is None:
                result[section] = summed
            else:
                result[section][name] = summed
    return result


def keys() -> list[str]:
    """110の入口三種・保護三種・費用四種の実口座名を列挙する。

    引数: なし。
    返り値: list[str]は36個の外部保存key。
    """
    return [f"{entry}_{guard}_C{cost}_D{delay}" for entry in ENTRY_PREFIXES for guard in ("G0", "G3", "G4") for cost in (0, 5) for delay in (0, 1)]


def run(saved_path: Path, saved_sha: str, completion_path: Path, completion_sha: str, output: Path) -> dict:
    """Rootが許可した全70成功Refだけから実現差を新規保存する。

    引数: saved_path/completion_path/output(Path)は保存正本・成功金融・未使用先、各sha(str)はRoot期待値。
    返り値: dictは保存比較結果。市場金融を再走せずNativeだけを再読する。
    """
    need(output.parent == OWN and not output.exists(), "解析先は所有work内の未使用ファイル")
    complete = load(completion_path, completion_sha)
    need(complete["version"] == 1 and complete["trial"] == 110 and complete["stage"] == "full70" and complete["success"] and not complete.get("error"), "Rootの110全70成功が必要")
    need((complete["sessions"], complete["books_per_scene"], complete["books"], complete["shadow_books"], complete["baseline_comparisons"]) == (70, 36, 2520, 0, 280), "金融の全70・36会計・旧280")
    need(complete["condition_sha256"] == CONDITION_SHA and complete["unchanged"] and complete["before"] and complete["before"] == complete["after"], "金融固定e0と入力前後不変")
    saved = load(saved_path, saved_sha)
    need(saved["試行"] == 110 and saved["成功"] and saved["stage"] == "full70" and saved["場数"] == 70 and saved["会計数"] == 2520, "独立保存の全70・36成功")
    need(saved["金融完了SHA256"] == completion_sha and saved["金融条件SHA256"] == CONDITION_SHA and saved["前後不変"], "保存と金融の固定結合")
    need(saved["入力codeSHA256前"] and saved["入力codeSHA256前"] == saved["入力codeSHA256後"], "独立保存の入力前後同体")
    refs = saved["Native参照"]
    ids = [row["session"] for row in refs]
    need(len(ids) == len(set(ids)) == 70 and ids == sorted(ids) and ids == [row["session"] for row in complete["results"]], "全70Nativeの同体と順序")
    need(all("2026-09-21" <= sid[:10] <= "2026-11-06" and sid.endswith(("_Day", "_Night")) for sid in ids), "既使用70だけ・11月09日禁止")
    need(set(saved["集計"]) == set(keys()), "保存36口座集合")
    inputs = {str(saved_path): saved_sha, str(completion_path): completion_sha, str(Path(__file__).resolve()): sha(Path(__file__).resolve())}
    comparisons, sessions = defaultdict(list), []
    for index, row in enumerate(refs):
        ref = row["native"]
        need(ref == complete["results"][index]["native"], "金融と保存のNative全参照同体")
        path = Path(ref["path"]).resolve()
        native = load(path, ref["sha256"])
        inputs[str(path)] = ref["sha256"]
        need(native["trial"] == 110 and native["complete"] and native["session"]["id"] == row["session"] and native["condition_sha256"] == CONDITION_SHA, "Nativeの試行・完結・場・固定")
        need(set(native["books"]) == set(keys()), "Native36口座集合")
        for entry in ENTRY_PREFIXES:
            for cost in (0, 5):
                for delay in (0, 1):
                    for before, after in GUARD_PAIRS:
                        ka, kb = f"{entry}_{before}_C{cost}_D{delay}", f"{entry}_{after}_C{cost}_D{delay}"
                        result = compare(native["books"][ka], native["books"][kb])
                        label = f"{entry}_{before}対{after}_C{cost}_D{delay}"
                        comparisons[label].append(result)
                        sessions.append({"比較": label, "session": row["session"], "前key": ka, "後key": kb, **result})
        print(row["session"], "同入口と四群の保存比較成功", flush=True)
    summaries = {label: add_results(rows) for label, rows in comparisons.items()}
    need(len(summaries) == 24 and len(sessions) == 1680, "全24比較・1680場別比較")
    for label, result in summaries.items():
        first = next(row for row in sessions if row["比較"] == label)
        need(result["全体"]["前"]["実現円"] == saved["集計"][first["前key"]]["net_yen"] and result["全体"]["後"]["実現円"] == saved["集計"][first["後key"]]["net_yen"], "全実現額と独立保存36集計の同体")
    need(all(sha(Path(path)) == expected for path, expected in inputs.items()), "明示入力とコードの前後不変")
    daynight = {label: {kind: add_results([row for row in sessions if row["比較"] == label and row["session"].endswith("_" + kind)]) for kind in ("Day", "Night")} for label in summaries}
    weeks = sorted({date.fromisoformat(sid[:10]).isocalendar()[:2] for sid in ids})
    weekly = {label: {f"{year}-W{week:02d}": add_results([row for row in sessions if row["比較"] == label and date.fromisoformat(row["session"][:10]).isocalendar()[:2] == (year, week)]) for year, week in weeks} for label in summaries}
    result = {"試行": 110, "成功": True, "scope": "E0L0・E2L0・E2L1各内、費用・遅延固定のG0対G3/G4。両実戦略の成立した入口と実現額だけを比較", "金融完了": {"path": str(completion_path), "sha256": completion_sha}, "独立保存": {"path": str(saved_path), "sha256": saved_sha}, "入力SHA256": inputs, "前後不変": True, "比較数": 24, "場別比較数": 1680, "全比較で入口同体": all(row["全同実入口"] for row in summaries.values()), "全条件": summaries, "日夜": daynight, "週別": weekly, "場別": sessions, "限界": ["保護が残玉・予約・上限・L1後枠取得を変えうるため、全体を同入口効果と断定しない", "同実入口群も両実戦略で成立した条件付き群でありランダム化因果効果ではない", "片側のみには実際に成立した側の実現額だけを計上。未取得側の0は加法の空集合で仮想取引ではない", "uは費用後単位含み益、Wは返済済み分込み全玉清算値。最終実現赤字と区別", "損失総額は負符号。費用設定違いの同Sourceを独立標本と数えない", "市場再走・全tick復元・未参加又は退出後の仮想利益・機会損失・MFE回収率なし", "既使用70探索であり未見期間の安定利益又は採用を証明しない"]}
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, default=serial, allow_nan=False)
        stream.write("\n")
    return {"成功": True, "解析": str(output), "sha256": sha(output), "全比較で入口同体": result["全比較で入口同体"], "場別比較数": 1680}


def main() -> None:
    """Rootから成功completionと独立保存の明示Refを受け取る。

    引数: CLIの--saved/--saved-sha/--completion/--completion-sha/--outは全て必須。
    返り値: None。既定実入力を持たず、Rootの許可前に実結果を開かない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--saved", type=Path, required=True)
    parser.add_argument("--saved-sha", required=True)
    parser.add_argument("--completion", type=Path, required=True)
    parser.add_argument("--completion-sha", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(run(args.saved.resolve(), args.saved_sha, args.completion.resolve(), args.completion_sha, args.out.resolve()), ensure_ascii=False))


if __name__ == "__main__":
    main()
