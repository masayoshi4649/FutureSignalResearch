package multientry110

import (
	"fmt"
	"reflect"
	"testing"

	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

// withBand は上位足の平均と勢いを因果的に一貫した人工系列へ変換します。
//
// 引数: s(frame.Snapshot)、mode(string)は元値と押戻し/旧方向推進/押戻しなしの指定です。
// 返り値: frame.Snapshotは同じ15分IDでは同値を保つ人工copyです。
func withBand(s frame.Snapshot, mode string) frame.Snapshot {
	f := &s.Scales[1].Current
	t := &f.Technical
	if mode == "押戻しなし" {
		f.OHLC = frame.OHLC{Open: 95, High: 110, Low: 90, Close: 105}
		t.EMA8 = value(80)
		t.EMA21 = value(70)
		t.PreviousEMA8 = value(79)
		t.PreviousEMA21 = value(69)
	} else {
		t.EMA8 = value(95)
		t.EMA21 = value(100)
		t.PreviousEMA8 = value(94)
		t.PreviousEMA21 = value(101)
		t.RSI = value(45)
		t.PreviousRSI = value(46)
		t.Histogram = value(-1)
		t.PreviousHistogram = value(-2)
		if mode == "逆推進" {
			t.Histogram = value(-2)
			t.PreviousHistogram = value(-1)
		}
	}
	t.Gap = value(t.EMA8.Value - t.EMA21.Value)
	t.GapATR = value(t.Gap.Value / t.ATR.Value)
	t.EMA8Delta = value(t.EMA8.Value - t.PreviousEMA8.Value)
	t.EMA21Delta = value(t.EMA21.Value - t.PreviousEMA21.Value)
	t.EMA8DeltaATR = value(t.EMA8Delta.Value / t.ATR.Value)
	t.EMA21DeltaATR = value(t.EMA21Delta.Value / t.ATR.Value)
	return s
}

// bandWarm は変換した人工系列を空候補で進めます。
//
// 引数: t(*testing.T)、mode(string)、held/mirror(bool)は形と鏡像です。
// 返り値: EntryStateは4500秒までの候補非依存な履歴です。
func bandWarm(t *testing.T, mode string, held, mirror bool) EntryState {
	t.Helper()
	state := NewEntryState()
	for _, end := range []float64{3600, 3900, 4200, 4500} {
		s := withBand(artificialSnapshot(end, false), mode)
		if held {
			s.Scales[0].Current.OHLC = frame.OHLC{Open: 101, High: 103, Low: 98, Close: 102}
		}
		state = feed(t, state, transform(s, mirror, false))
	}
	return state
}

// TestStandingSupportWithoutPullback はcrossが当足にない維持状態を認識します。
//
// 引数: t(*testing.T)は鏡像を含む人工検査です。
// 返り値: なし。支持線形成に押戻しを強制しません。
func TestStandingSupportWithoutPullback(t *testing.T) {
	for _, mirror := range []bool{false, true} {
		t.Run(fmt.Sprint(mirror), func(t *testing.T) {
			state := bandWarm(t, "押戻しなし", true, mirror)
			if state.View().Trend[map[bool]int{false: 0, true: 1}[mirror]].Event != "線外保持確認" {
				t.Fatal("前から線外の支持を確認しない")
			}
			s := withBand(artificialSnapshot(4800, false), "押戻しなし")
			s.Scales[0].Current.OHLC = frame.OHLC{Open: 102, High: 104, Low: 101, Close: 103}
			s = transform(s, mirror, false)
			c := buyCandidate(s, 103)
			if mirror {
				c.Side = -1
				c.EntryQuote = 197
			}
			_, a, err := AssessEntry(state, s, c, EntryE2)
			if err != nil || !a.Allowed || a.Route != Continuation || a.Structure.Event != "" || a.Structure.AnchorPullback {
				t.Fatalf("現在支持:%v route=%s reason=%s", err, a.Route, a.Reason)
			}
			if a.Structure.ConfirmedFrameID == s.Scales[0].Current.ID {
				t.Fatal("古い確認を当足イベントへ偽装")
			}
		})
	}
}

// TestPullbackRolesAndOpposingPush は15分整列と価格帯の役割を分けます。
//
// 引数: t(*testing.T)は回復と旧方向推進の反例です。
// 返り値: なし。平均単独では許可しません。
func TestPullbackRolesAndOpposingPush(t *testing.T) {
	for _, mode := range []string{"押戻し", "逆推進"} {
		for _, mirror := range []bool{false, true} {
			t.Run(fmt.Sprint(mode, mirror), func(t *testing.T) {
				state := bandWarm(t, mode, false, mirror)
				s := withBand(artificialSnapshot(4800, false), mode)
				f := &s.Scales[0].Current
				f.OHLC = frame.OHLC{Open: 99, High: 103, Low: 98, Close: 101}
				f.Technical.RSI = value(45)
				f.Technical.PreviousRSI = value(44)
				f.Technical.Histogram = value(-2)
				f.Technical.PreviousHistogram = value(-3)
				s = transform(s, mirror, false)
				c := buyCandidate(s, 101)
				if mirror {
					c.Side = -1
					c.EntryQuote = 199
				}
				_, a, err := AssessEntry(state, s, c, EntryE2)
				if err != nil {
					t.Fatal(err)
				}
				if mode == "押戻し" && (!a.Allowed || a.Route != PullbackResume || a.Continuation.Passed || a.Background[1].Direction != 0 || !a.Recovery.Passed) {
					t.Fatalf("再開: %s %s", a.Route, a.Reason)
				}
				if mode == "逆推進" && (!a.Known || a.Allowed || a.UpperNotOpposite.Passed) {
					t.Fatal("旧方向の推進を無視")
				}
			})
		}
	}
}

// reversalReady は旧方向試験から別足復帰・突破までを順に形成します。
//
// 引数: t(*testing.T)、mirror(bool)は人工検査と鏡像指定です。
// 返り値: EntryState/Assessmentは5400秒足で確認したRです。
func reversalReady(t *testing.T, mirror bool) (EntryState, Assessment) {
	t.Helper()
	state := warm(t, true, mirror, false)
	var a Assessment
	bars := []frame.OHLC{{Open: 92, High: 95, Low: 89, Close: 89.5}, {Open: 90, High: 95, Low: 89.5, Close: 93}, {Open: 94, High: 102, Low: 92, Close: 101}}
	for i, o := range bars {
		s := artificialSnapshot(4800+300*float64(i), true)
		s.Scales[0].Current.OHLC = o
		s = transform(s, mirror, false)
		c := buyCandidate(s, 101)
		if mirror {
			c.Side = -1
			c.EntryQuote = 199
		}
		var err error
		state, a, err = AssessEntry(state, s, c, EntryE2)
		if err != nil {
			t.Fatal(err)
		}
		if a.Allowed != (i == 2) {
			t.Fatalf("R順序%d %s", i, a.Reason)
		}
	}
	return state, a
}

// TestReversalStaysValidAndLosesLine は確認後も同じRを保持し、突破線喪失で失効します。
//
// 引数: t(*testing.T)はTと逆向きの背景も持つ鏡像人工です。
// 返り値: なし。確認直後の1足だけに限定しません。
func TestReversalStaysValidAndLosesLine(t *testing.T) {
	for _, mirror := range []bool{false, true} {
		t.Run(fmt.Sprint(mirror), func(t *testing.T) {
			state, first := reversalReady(t, mirror)
			if first.Route != LocalReversal || first.ReversalLabel != "長期逆行中の局所反転" {
				t.Fatalf("Rの背景:%s %s", first.Route, first.ReversalLabel)
			}
			for _, close := range []float64{102, 100} {
				s := artificialSnapshot(5700, true)
				s.Scales[0].Current.OHLC = frame.OHLC{Open: 101, High: 104, Low: 99, Close: close}
				s = transform(s, mirror, false)
				c := buyCandidate(s, 102)
				if mirror {
					c.Side = -1
					c.EntryQuote = 198
				}
				_, a, err := AssessEntry(state, s, c, EntryE2)
				if err != nil {
					t.Fatal(err)
				}
				if close == 102 && (!a.Allowed || a.Route != LocalReversal || a.Structure.Event != "" || a.Structure.ConfirmedAt != first.Structure.ConfirmedAt) {
					t.Fatal("Rを現在足イベントへ限定/確認延長")
				}
				if close == 100 && (!a.Known || a.Allowed) {
					t.Fatal("突破線同値を維持とみなした")
				}
			}
		})
	}
}

// TestStateLifetimeAndPriceBoundaries は形成時計からの寿命とstrict/inclusiveを確認します。
//
// 引数: t(*testing.T)は上限と失効の人工検査です。
// 返り値: なし。確認によって1800秒期限を延長しません。
func TestStateLifetimeAndPriceBoundaries(t *testing.T) {
	state := warm(t, false, false, false)
	s, c := trendReady(false, false)
	next, a, err := AssessEntry(state, s, c, EntryE2)
	if err != nil || !a.Allowed {
		t.Fatal(err, a.Reason)
	}
	if a.Structure.ExpiresAt != a.Structure.CreatedAt+1800 || a.Structure.ConfirmedAt <= a.Structure.CreatedAt {
		t.Fatal("形成期限の定義")
	}
	for _, item := range []struct {
		price   float64
		allowed bool
	}{{100, false}, {110, true}, {110.00001, false}} {
		c.EntryQuote = item.price
		_, b, e := AssessEntry(state, s, c, EntryE2)
		if e != nil || b.Allowed != item.allowed {
			t.Fatalf("距離%g %v", item.price, e)
		}
	}
	for _, delta := range []float64{-1, 0} {
		x := s
		x.AsOf = a.Structure.ExpiresAt + delta
		x.ReplayObservedAt = x.AsOf
		x.RecordOrdinal++
		n, _, e := AssessBatch(next, x, nil, EntryE2)
		if e != nil {
			t.Fatal(e)
		}
		if n.View().Trend[0].Active != (delta < 0) {
			t.Fatal("TTLの同値境界")
		}
	}
	for _, low := range []float64{90, 89.999} {
		x := artificialSnapshot(5100, false)
		x.Scales[0].Current.OHLC = frame.OHLC{Open: 101, High: 103, Low: low, Close: 102}
		_, b, e := AssessEntry(next, x, buyCandidate(x, 102), EntryE2)
		if e != nil || b.Allowed != (low == 90) {
			t.Fatalf("risk端%g %v %s", low, e, b.Reason)
		}
	}
}

// TestMomentumLevelsSpikeAndUnknown は水準維持・増分・異常・未知を混同しません。
//
// 引数: t(*testing.T)は保存利用値の反証人工です。
// 返り値: なし。Unknownをfalseへ埋めません。
func TestMomentumLevelsSpikeAndUnknown(t *testing.T) {
	state := warm(t, false, false, false)
	s, c := trendReady(false, false)
	for _, kind := range []string{"高位維持", "負H悪化", "複合spike", "15分未知", "5分未知", "量未知"} {
		t.Run(kind, func(t *testing.T) {
			local := state
			x := s
			tc := &x.Scales[0].Current.Technical
			switch kind {
			case "高位維持":
				local.PreviousFive.Technical.RSI = value(95)
				tc.RSI = value(95)
				tc.PreviousRSI = value(95)
				tc.Histogram = value(1)
				tc.PreviousHistogram = value(2)
			case "負H悪化":
				tc.Histogram = value(-2)
				tc.PreviousHistogram = value(-1)
				tc.RSI = value(45)
				tc.PreviousRSI = value(46)
			case "複合spike":
				tc.RSI = value(90)
				tc.PreviousRSI = value(60)
				tc.TR = value(21)
				tc.PreviousATR = value(10)
			case "15分未知":
				local.Last[1].Technical.PreviousHistogram.Known = false
				x.Scales[1].Current = local.Last[1]
			case "5分未知":
				tc.PreviousRSI.Known = false
			case "量未知":
				for i := range x.Scales {
					x.Scales[i].Current.VolumeKnown = false
					if local.HasLast[i] && local.Last[i].ID == x.Scales[i].Current.ID {
						local.Last[i].VolumeKnown = false
					}
				}
			}
			_, a, e := AssessEntry(local, x, c, EntryE2)
			if e != nil {
				t.Fatal(e)
			}
			want := kind == "高位維持" || kind == "量未知"
			if a.Allowed != want {
				t.Fatalf("%s:%s", kind, a.Reason)
			}
			if (kind == "15分未知" || kind == "5分未知") && (a.Known || a.Status != Unknown) {
				t.Fatal("必要履歴をKnown falseへ補完")
			}
			if kind == "複合spike" && a.Spike.Passed {
				t.Fatal("複合spikeを維持へ格上げ")
			}
		})
	}
}

// TestCandidateIndependentStateAndAuditCopy は集合・数量と状態を分離し監査aliasを防ぎます。
//
// 引数: t(*testing.T)は空/買/売/両方集合の比較です。
// 返り値: なし。Source同IDの後続時刻も新候補とせず原値をechoします。
func TestCandidateIndependentStateAndAuditCopy(t *testing.T) {
	state := warm(t, false, false, false)
	s, c := trendReady(false, false)
	other := c
	other.ID = "売"
	other.Side = -1
	var baseline EntryState
	for i, cs := range [][]Candidate{nil, {c}, {other}, {c, other}} {
		next, b, e := AssessBatch(state, s, cs, EntryE2)
		if e != nil {
			t.Fatal(e)
		}
		if i == 0 {
			baseline = next
		} else if baseline != next {
			t.Fatal("候補集合でsetupが変わる")
		}
		if len(cs) > 0 && b.Decisions[0].Candidate != cs[0] {
			t.Fatal("候補echoが変わる")
		}
	}
	n, a, e := AssessEntry(state, s, c, EntryE2)
	if e != nil {
		t.Fatal(e)
	}
	saved := n
	original := state
	a.Evidence[0].Technical.EMA8.Value = -9
	a.Structure.Pivot.Left[0].ID = "変更"
	a.Structure.Anchor.OHLC.Close = -9
	if n != saved || state != original {
		t.Fatal("監査copyから状態へalias")
	}
	x := artificialSnapshot(5100, false)
	x.Scales[0].Current.OHLC = frame.OHLC{Open: 101, High: 103, Low: 100, Close: 102}
	c.At = x.AsOf
	c.EntryQuote = 102
	_, b, e := AssessEntry(n, x, c, EntryE2)
	if e != nil || !b.Allowed || b.Candidate.ID != "出生1" {
		t.Fatal("同じSourceの後続査定を純Gateがlock")
	}
	if !reflect.DeepEqual(b.Evidence[0].Technical, x.Scales[0].Current.Technical) || b.Structure.Pivot.PublishedAt >= b.Structure.ConfirmedAt {
		t.Fatal("利用値と証拠の結合")
	}
}

// TestPriorLineAvailabilityAndReversalLifetime は線の出生時計とR失効を検査します。
//
// 引数: t(*testing.T)は同足pivot・形成TTL・旧方向極値の反例です。
// 返り値: なし。未知の線を事前支持として使いません。
func TestPriorLineAvailabilityAndReversalLifetime(t *testing.T) {
	for _, kind := range []string{"公表が足開始と同値", "Newのみ", "未来"} {
		t.Run(kind, func(t *testing.T) {
			state := warm(t, false, false, false)
			state.Sides = [2]sideState{}
			s, c := trendReady(false, false)
			p := s.Scales[0].Current.PriorHigh
			switch kind {
			case "公表が足開始と同値":
				p.PublishedAt = s.Scales[0].Current.Start
				s.Scales[0].Current.PriorHigh = p
			case "Newのみ":
				s.Scales[0].Current.NewHigh = p
				s.Scales[0].Current.PriorHigh = frame.Pivot{}
			case "未来":
				p.PublishedAt = s.AsOf + 1
				s.Scales[0].Current.PriorHigh = p
			}
			_, a, e := AssessEntry(state, s, c, EntryE2)
			if kind == "未来" {
				if e == nil {
					t.Fatal("未来pivotを受理")
				}
				return
			}
			if e != nil || !a.Known || a.Allowed {
				t.Fatalf("事前線扱い %v %s", e, a.Reason)
			}
		})
	}
	for _, mirror := range []bool{false, true} {
		state, a := reversalReady(t, mirror)
		i := 0
		if mirror {
			i = 1
		}
		if a.Structure.CreatedAt != epoch+4860 || a.Structure.ExpiresAt != epoch+6660 {
			t.Fatal("Rの最初試験公表からの期限")
		}
		s := artificialSnapshot(5700, true)
		s.Scales[0].Current.OHLC = frame.OHLC{Open: 101, High: 103, Low: 88, Close: 102}
		s = transform(s, mirror, false)
		c := buyCandidate(s, 102)
		if mirror {
			c.Side = -1
			c.EntryQuote = 198
		}
		n, b, e := AssessEntry(state, s, c, EntryE2)
		if e != nil || b.Allowed || n.View().Reversal[i].Active {
			t.Fatal("失敗極値更新を見逃す")
		}
		x := artificialSnapshot(5400, true)
		x.Scales[0].Current.OHLC = frame.OHLC{Open: 94, High: 102, Low: 92, Close: 101}
		x = transform(x, mirror, false)
		x.AsOf = a.Structure.ExpiresAt
		x.ReplayObservedAt = x.AsOf
		x.RecordOrdinal++
		n, _, e = AssessBatch(state, x, nil, EntryE2)
		if e != nil || n.View().Reversal[i].Active {
			t.Fatal("Rが期限同値で残る", e)
		}
	}
}
