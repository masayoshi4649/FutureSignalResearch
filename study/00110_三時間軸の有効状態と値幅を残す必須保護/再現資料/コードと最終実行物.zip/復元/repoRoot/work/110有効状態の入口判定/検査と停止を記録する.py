"""市場を読み取らず、純入口の人工Go確認とコード不変を記録する。"""

import hashlib
import json
import re
import subprocess
from pathlib import Path


def sha(path: Path) -> str:
    """機能: 小コード・仕様のSHA256を計算する。

    引数: path(Path)は既存ファイル。
    返り値: strは16進SHA256。原板や市場ファイルを対象としない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def refs(paths: list[Path]) -> dict[str, str]:
    """機能: 明示されたコード群の不変台帳を作る。

    引数: paths(list[Path])はGo/小仕様/停止などの既存参照。
    返り値: dict[str, str]は絶対パスからSHA256への対応。
    """
    return {str(path.resolve()): sha(path) for path in sorted(set(paths))}


def ref(path: Path) -> dict[str, str]:
    """機能: 一つの成果物の追跡参照を返す。

    引数: path(Path)は検査結果又は仕様。
    返り値: dict[str, str]はpath/sha256。
    """
    return {"path": str(path.resolve()), "sha256": sha(path)}


def main() -> None:
    """機能: 純Goのtest/vet/buildを実行し成功時だけ停止記録を作る。

    引数: なし。実装フォルダ、停止公開器、109派生元の小コードだけを読む。
    返り値: None。金融/原板/CSV/未使用入力は呼び出さない。
    """
    base = Path(__file__).resolve().parent
    root = base.parents[1]
    verify = base / "検査"
    verify.mkdir(exist_ok=True)
    owned = list(base.glob("*.go")) + [base / "go.mod", Path(__file__), base / "README.md", base / "仕様.md", base / "仕様.json"]
    publisher = base.parent / "三時間軸の公開器"
    design = base.parent / "110入口の設計"
    dependency = list(publisher.glob("*.go")) + [publisher / "go.mod", publisher / "停止.json", publisher / "仕様.md"]
    dependency += [design / "設計仕様.md", design / "保存済み頻度を読む.py", design / "既存109の頻度の要点.json"]
    prior = json.loads((base / "派生前指紋.json").read_text(encoding="utf-8"))
    before, dep_before = refs(owned), refs(dependency)
    assert all(sha(Path(path)) == value for path, value in prior.items()), "109派生元の不変不成立"

    # ----------------------------------------
    # 市場接続のない人工確認。失敗した状態を成功として固定しない。
    commands = [["go", "test", "-count=1", "-json", "-coverprofile=検査/coverage.out", "./..."], ["go", "vet", "./..."], ["go", "build", "./..."]]
    checks = []
    passed = []
    coverage = None
    for index, command in enumerate(commands):
        result = subprocess.run(command, cwd=base, text=True, encoding="utf-8", capture_output=True)
        log = verify / ["Go_test.jsonl", "Go_vet.txt", "Go_build.txt"][index]
        log.write_text(result.stdout + result.stderr, encoding="utf-8")
        checks.append({"argv": command, "exit_code": result.returncode, "log": ref(log)})
        if index == 0:
            for line in result.stdout.splitlines():
                event = json.loads(line)
                if event.get("Action") == "pass" and event.get("Test"):
                    passed.append(event["Test"])
                match = re.search(r"coverage:\s+([0-9.]+)%", event.get("Output", ""))
                if match:
                    coverage = float(match.group(1))
        if result.returncode:
            raise RuntimeError(f"Go確認失敗: {command}: {result.stderr}")
    after, dep_after = refs(owned), refs(dependency)
    assert before == after and dep_before == dep_after, "検査前後にコード/仕様が変更された"
    assert all(sha(Path(path)) == value for path, value in prior.items()), "109派生元が検査中に変更された"
    check_path = verify / "Go確認.json"
    result = {
        "成功": True, "試行": 110, "人工のみ": True,
        "親test数": sum("/" not in name for name in passed), "全test数": len(passed), "coverage_percent": coverage,
        "checks": checks, "検査前コード": before, "検査後コード": after, "依存前": dep_before, "依存後": dep_after,
        "依存差": 0, "109派生元差": 0, "test名": passed,
        "市場実行": False, "金融実行": False, "原板追加読取": False, "未使用11月09日本文又はhash": False,
        "未実証": ["実市場のE2成立頻度と参加率", "SourceLifetime L0/L1と金融Main36", "市場の費用後収支", "mini実板/実約定"],
    }
    check_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    stop = {
        "成功": True, "version": 1, "trial": 110,
        "module": "github.com/masayoshi4649/SessionTradeExecuter/multientry110",
        "所有コードSHA256": after, "依存コードと仕様SHA256": dep_after, "旧109派生元SHA256": prior,
        "仕様": ref(base / "仕様.md"), "機械仕様": ref(base / "仕様.json"), "検査": ref(check_path),
        "市場前で停止": True, "以後変更": "変更時は別版へ派生し、この停止物を改変しない",
        "金融又は新市場実行": False,
    }
    stop_path = base / "停止.json"
    if stop_path.exists():
        raise FileExistsError("既存停止を上書きしない")
    stop_path.write_text(json.dumps(stop, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "停止": ref(stop_path), "親test数": result["親test数"], "全test数": len(passed), "coverage_percent": coverage, "旧109差": 0, "市場金融実行": False}, ensure_ascii=False))


if __name__ == "__main__":
    main()
