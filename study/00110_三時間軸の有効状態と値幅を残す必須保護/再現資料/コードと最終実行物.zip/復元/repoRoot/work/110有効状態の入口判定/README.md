# 三時間軸の現在有効な複合入口110

純Go module/package `github.com/masayoshi4649/SessionTradeExecuter/multientry110` / `multientry110`。市場への注文、Source生成、Lifetime、金融、原板/CSVの読み取りを行わない。停止済み109の `threeentry` から別フォルダへ派生し、旧コードは変更しない。

[仕様](仕様.md) は [設計の原本](../110入口の設計/設計仕様.md) と同体の市場前仕様。小さい [仕様JSON](仕様.json) も参照する。109の保存済み8CSVからの出発点は [既存頻度の要点](../110入口の設計/既存109の頻度の要点.json)。そこにある共通可用12,994/Source479は最終Known12,928/475と違う段階であり、新E2の頻度ではない。

## API

```go
NewEntryState() EntryState
PolicySnapshot(threeframe.Snapshot) threeframe.Snapshot
SnapshotID(threeframe.Snapshot) (string, error)
AssessBatch(EntryState, threeframe.Snapshot, []Candidate, Policy) (EntryState, BatchAssessment, error)
AssessEntry(EntryState, threeframe.Snapshot, Candidate, Policy) (EntryState, Assessment, error)
```

候補は109と同形の `Candidate{ID,Side,At,EntryQuote,Quantity}` をechoする。Sideは買い1/売り−1、EntryQuoteは追加滑り前の金融適格な新規側BBO。Atはsnapshot.AsOf。新政策は `EntryE2="ENTRY_E2"`、対照は `EntryE0="ENTRY_E0"`。旧ENTRY_E1を新しい条件へ読み替えない。

RoleはT/R/E0を維持し、RouteにT継続/T押戻し再開/R局所転換を追加した。同方向の優先順もこの順。金融適格候補の両方向が成立した場合は両方を競合待機へ変更する。Source同IDが別Atで再査定されても純Gateはlockしない。L0/L1による受付寿命はActorの別条件で、実fill後の再参加は扱わない。

すべての5分枠で空候補も1回batch呼出しする。返り値stateは候補集合/順番/数量から独立。金融precheck→batch査定→Actor受理成功後state commitを守る。値型/固定配列と新規sliceで返し、可変aliasを持たない。

## 109から変えた点

- 当足Eventの一致を取得条件にせず、既知の線の外で確認した価格構造が現在も未否定かを見る。T継続の線形成に15分押戻しは必須にせず、既に前足も線外だった状態も現在確認できる。T再開は押戻しflagを使う。
- T継続は5/15/30の並び/両傾きを維持し、T再開は30分方向・15分価格帯・5分EMA8回復を分担する。Rは別足の試験→復帰→突破を維持し、30分の不一致を局所反転の背景として保存する。
- 正histogram水準とその減速、負histogramの改善を区別する。MACD本線/Signalの値は停止公開器にないため利用しない。
- 5/15の必要な勢い/値幅列を共通Knownとして先に確認する。量未知と価格未知は別。線未形成や期限切れはKnownの待機。
- 監査に利用FrameのOHLC/Technical/4clock/子SHA、直前5分、固定risk足とpivotの左右/確認時計、3経路と各論理群、線/EMAのATR乖離を追加する。短絡代表理由を単独効果にしない。

1800秒期限は形成開始から。Tはrisk足/pivotの公表最大、Rは最初試験足の公表。確認によって延長せず、新しい900秒TTLは加えない。支持否定はrisk極値のstrict悪化、突破線への終値同値/内側復帰。取得は線の外0超〜1ATR以下、spikeは直近2本のTR>2前ATRかつ方向RSI差>20を維持する。

## 人工確認

```powershell
go test -count=1 -cover ./...
go vet ./...
go build ./...
```

検査は [Go確認](検査/Go確認.json) と [停止](停止.json) へ保存する。実停止publisherに240本の手製助走＋12本の手製当場OHLCを通し、指標注入なしの両向きT再開/R局所転換を確認した。Rの買いは+50分、RSI約46.24486、H約2.32980、鏡像売りはRSI約53.75514、H約−2.32980。人工の価格・気配は条件を検査するための数学値であり、miniの全約定可能性や市場での利益の証拠ではない。

三経路/鏡像、当足Eventなしの支持維持、押戻し時15分混在、RSI高位維持/H正低下、H負改善/逆推進、同足でR多段進行不可、支持同値/極値/1ATR/形成TTL、必要履歴Unknown、量未知、場/限月/欠足、未来clock/pivot/未来末尾、EOF/Seal非干渉、候補独立/echo/競合/aliasを検査する。

Source寿命と金融接続はこの部品の人工確認の外。実70市場の新E2頻度、参加率、収支は未計算。11/09は本文もhashも読まず保持する。未参加・決済後の仮想利益を評価しない。
