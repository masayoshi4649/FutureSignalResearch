package multientry110

import frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"

// evidence は利用公表の数値と4時計を値copyへ射影します。
//
// 引数: f(frame.Frame)は公表前値を含まない確定足です。
// 返り値: FrameEvidenceは子足全値を複製せず出典SHAを保持します。
func evidence(f frame.Frame) FrameEvidence {
	return FrameEvidence{ID: f.ID, SessionID: f.SessionID, Contract: f.Contract, WidthSeconds: f.WidthSeconds, Start: f.Start, End: f.End, NominalAvailable: f.NominalAvailable, AvailableAt: f.AvailableAt, ObservedAt: f.ObservedAt, DeliveryAt: f.DeliveryAt, RecordOrdinal: f.RecordOrdinal, PublicationOrdinal: f.PublicationOrdinal, ChildrenSHA256: f.ChildrenSHA256, PriceKnown: f.PriceKnown, VolumeKnown: f.VolumeKnown, OHLC: f.OHLC, Technical: f.Technical}
}

// positionEvidence は実気配と支持線・速い平均のATR距離を記録します。
//
// 引数: c(Candidate)、setup(SetupView)、five(frame.Frame)は実気配と使用確定値です。
// 返り値: PositionAuditは正ATRがある場合の符号付き距離です。線未形成ならKnown=falseです。
func positionEvidence(c Candidate, setup SetupView, five frame.Frame) PositionAudit {
	t := five.Technical
	if setup.ID == "" || !t.ATR.Known || t.ATR.Value <= 0 || !t.EMA8.Known {
		return PositionAudit{}
	}
	s := float64(c.Side)
	line, ema := s*(c.EntryQuote-setup.Trigger), s*(c.EntryQuote-t.EMA8.Value)
	return PositionAudit{Known: true, ATR: t.ATR.Value, LineDistance: line, LineDistanceATR: line / t.ATR.Value, EMADistance: ema, EMADistanceATR: ema / t.ATR.Value}
}
