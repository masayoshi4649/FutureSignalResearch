package multientry110

import (
	"fmt"
	"math"

	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

// sideExtreme は取引向きのrisk側高安を返します。
//
// 引数: o(frame.OHLC)、side(int)は確定足と買い1/売り-1です。
// 返り値: float64は買いのLow又は売りのHighです。
func sideExtreme(o frame.OHLC, side int) float64 {
	if side == 1 {
		return o.Low
	}
	return o.High
}

// priorAnchor は試験5分足の開始前に公表済みの最新15分足だけを選びます。
//
// 引数: state(EntryState)、start(float64)は保持履歴と試験足の開始です。
// 返り値: frame.Frame/boolは固定risk区間と利用可能性です。
func priorAnchor(state EntryState, start float64) (frame.Frame, bool) {
	var chosen frame.Frame
	found := false
	for i, f := range [2]frame.Frame{state.Last[1], state.PreviousFifteen} {
		known := state.HasLast[1]
		if i == 1 {
			known = state.HasPreviousFifteen
		}
		if known && f.PriceKnown && published(f) < start && (!found || f.End > chosen.End) {
			chosen = f
			found = true
		}
	}
	return chosen, found
}

// pivotBefore は右2足までの証拠が試験足開始前に公開済みか確認します。
//
// 引数: p(frame.Pivot)、side(int)、start(float64)、scene(frame.Session)は固定線と試験時計です。
// 返り値: boolは5分の事前pivotとして利用できることです。
func pivotBefore(p frame.Pivot, side int, start float64, scene frame.Session) bool {
	kind := "high"
	if side == -1 {
		kind = "low"
	}
	if !p.Known || p.Kind != kind || !finite(p.Price) || p.Price <= 0 || p.CenterID == "" || p.ConfirmID == "" || !finite(p.PublishedAt) || p.PublishedAt >= start || p.CenterStart < scene.Start || p.CenterEnd-p.CenterStart != 300 || p.ConfirmEnd > p.PublishedAt {
		return false
	}
	refs := [5]frame.BarRef{p.Left[0], p.Left[1], {ID: p.CenterID, Start: p.CenterStart, End: p.CenterEnd, PublishedAt: p.PublishedAt}, p.Right[0], p.Right[1]}
	for i, ref := range refs {
		if ref.ID == "" || !finite(ref.Start) || !finite(ref.End) || ref.End-ref.Start != 300 || ref.Start < scene.Start || ref.End > p.PublishedAt || !finite(ref.PublishedAt) || ref.PublishedAt > p.PublishedAt {
			return false
		}
		if i > 0 && refs[i-1].End != ref.Start {
			return false
		}
	}
	return p.Right[1].ID == p.ConfirmID && p.Right[1].End == p.ConfirmEnd
}

// triggerPivot はSource方向の反対側へ突破する5分pivotを選びます。
//
// 引数: f(frame.Frame)、side(int)は現在5分公表とSource方向です。
// 返り値: frame.Pivotは買いの事前高値又は売りの事前安値です。Newは使いません。
func triggerPivot(f frame.Frame, side int) frame.Pivot {
	if side == 1 {
		return f.PriorHigh
	}
	return f.PriorLow
}

// pullback は公表済み15分の逆行実体又は速い平均への接触を確認します。
//
// 引数: f(frame.Frame)、side(int)は試験前の15分足とSource方向です。
// 返り値: boolは押戻し/停滞の価格証拠です。単独で入口許可にはしません。
func pullback(f frame.Frame, side int) bool {
	if float64(side)*(f.OHLC.Close-f.OHLC.Open) <= 0 {
		return true
	}
	return f.Technical.EMA8.Known && float64(side)*(sideExtreme(f.OHLC, side)-f.Technical.EMA8.Value) <= 0
}

// retireT は順行setupを失効させ、同じ固定線での即時作り直しを防ぎます。
//
// 引数: state(*sideState)、reason(string)は局所copyと失効理由です。
// 返り値: なし。外部EntryStateを直接変更するAPIではありません。
func retireT(state *sideState, reason string) {
	state.RetiredT = state.T.ID
	state.T.Active = false
	state.T.Phase = "失効"
	state.T.Event = ""
	state.T.EventBarID = ""
	state.T.Reason = reason
}

// retireR は反転setupを失効させます。
//
// 引数: state(*sideState)、reason(string)は局所copyと失効理由です。
// 返り値: なし。次の独立した固定線ができるまで同IDを復活させません。
func retireR(state *sideState, reason string) {
	state.RetiredR = state.R.ID
	state.R.Active = false
	state.R.Phase = "失効"
	state.R.Event = ""
	state.R.EventBarID = ""
	state.R.Reason = reason
}

// crossed は前の確定5分終値から固定線の外へのstrictな突破を確認します。
//
// 引数: state(EntryState)、f(frame.Frame)、side(int)、level(float64)は連続足と固定線です。
// 返り値: boolは前終値が線内/同値、今回終値が線外であることです。
func crossed(state EntryState, f frame.Frame, side int, level float64) bool {
	return state.HasPreviousFive && float64(side)*(state.PreviousFive.OHLC.Close-level) <= 0 && float64(side)*(f.OHLC.Close-level) > 0
}

// advanceSide は一つの新しい5分足でT/Rを一段ずつ進めます。
//
// 引数: local(*sideState)、state(EntryState)、f(frame.Frame)、side(int)、at(float64)は局所状態と同じ公開値です。
// 返り値: なし。失敗・復帰・突破を同一足で進めず、期限や支持喪失を記録します。
func advanceSide(local *sideState, state EntryState, f frame.Frame, side int, at float64) {
	local.T.Event, local.T.EventBarID = "", ""
	local.R.Event, local.R.EventBarID = "", ""
	s := float64(side)
	anchor, hasAnchor := priorAnchor(state, f.Start)
	pivot := triggerPivot(f, side)
	hasPivot := pivotBefore(pivot, side, f.Start, state.Session)
	boundary := 0.0
	key := ""
	if hasAnchor && hasPivot {
		boundary = sideExtreme(anchor.OHLC, side)
		key = fmt.Sprintf("%d|%s|%s|%s", side, anchor.ID, pivot.CenterID, pivot.ConfirmID)
		if s*(pivot.Price-boundary) <= 0 {
			hasPivot = false
		}
	}
	// ----------------------------------------
	// 順行は事前線の突破又は線外保持を確認し、以後は支持の現在有効性を維持します。
	tLost := false
	if local.T.Active && (s*(sideExtreme(f.OHLC, side)-local.T.Boundary) < 0 || local.T.Phase == "確認済み" && s*(f.OHLC.Close-local.T.Trigger) <= 0) {
		retireT(local, "risk境界又は突破線を失った")
		tLost = true
	}
	if !local.T.Active && !tLost && hasAnchor && hasPivot && key != local.RetiredT && s*(sideExtreme(f.OHLC, side)-boundary) >= 0 {
		created := math.Max(published(anchor), pivot.PublishedAt)
		if at < created+Rules().SetupSeconds {
			local.T = SetupView{ID: key, Active: true, Phase: "待突破", AnchorID: anchor.ID, PivotID: pivot.CenterID, Boundary: boundary, Trigger: pivot.Price, CreatedAt: created, ExpiresAt: created + Rules().SetupSeconds, AnchorPullback: pullback(anchor, side), Anchor: evidence(anchor), Pivot: pivot, Reason: "事前15分risk区間と5分pivotを固定"}
		}
	}
	if local.T.Active && local.T.Phase == "待突破" && s*(f.OHLC.Close-local.T.Trigger) > 0 {
		crossedNow := crossed(state, f, side, local.T.Trigger)
		held := state.HasPreviousFive && s*(state.PreviousFive.OHLC.Close-local.T.Trigger) > 0
		if crossedNow || held {
			local.T.Phase = "確認済み"
			local.T.BreakoutEnd = f.End
			local.T.ConfirmedAt = published(f)
			local.T.ConfirmedFrameID = f.ID
			local.T.Event = "線外保持確認"
			if crossedNow {
				local.T.Event = "突破確認"
			}
			local.T.EventBarID = f.ID
			local.T.Reason = "事前線の外で終値を確認し、以後は未否定状態を維持"
		}
	}
	// ----------------------------------------
	// 反転は旧方向の試行、後続足の復帰、さらに後続足の小構造突破です。
	rLost := false
	if local.R.Active {
		if s*(sideExtreme(f.OHLC, side)-local.FailureExtreme) < 0 {
			retireR(local, "旧方向への高安更新が継続")
			rLost = true
		} else if (local.R.Phase == "復帰済み" || local.R.Phase == "確認済み") && s*(f.OHLC.Close-local.R.Boundary) <= 0 {
			retireR(local, "復帰した境界を終値で失った")
			rLost = true
		} else if local.R.Phase == "確認済み" && s*(f.OHLC.Close-local.R.Trigger) <= 0 {
			retireR(local, "確認後の突破線を終値で失った")
			rLost = true
		}
	}
	if !local.R.Active && !rLost && hasAnchor && hasPivot && key != local.RetiredR && s*(sideExtreme(f.OHLC, side)-boundary) < 0 {
		created := published(f)
		local.R = SetupView{ID: key, Active: true, Phase: "更新失敗確認待ち", AnchorID: anchor.ID, PivotID: pivot.CenterID, Boundary: boundary, Trigger: pivot.Price, CreatedAt: created, ExpiresAt: created + Rules().SetupSeconds, FailureEnd: f.End, Anchor: evidence(anchor), Pivot: pivot, FailureExtreme: sideExtreme(f.OHLC, side), Reason: "旧方向へ固定15分区間を試した。復帰は別足を待つ"}
		local.FailureExtreme = sideExtreme(f.OHLC, side)
	} else if local.R.Active {
		if local.R.Phase == "更新失敗確認待ち" && f.Start >= local.R.FailureEnd && s*(f.OHLC.Close-local.R.Boundary) > 0 {
			local.R.Phase = "復帰済み"
			local.R.RecoveryEnd = f.End
			local.R.Reason = "後続5分終値で固定境界へ復帰"
		} else if local.R.Phase == "復帰済み" && f.Start >= local.R.RecoveryEnd && crossed(state, f, side, local.R.Trigger) {
			local.R.Phase = "確認済み"
			local.R.Active = true
			local.R.ConfirmedAt = published(f)
			local.R.ConfirmedFrameID = f.ID
			local.R.Event = "反対側突破"
			local.R.EventBarID = f.ID
			local.R.BreakoutEnd = f.End
			local.R.Reason = "復帰後のさらに別足で事前5分pivot突破"
			local.RetiredR = local.R.ID
		}
	}
}
