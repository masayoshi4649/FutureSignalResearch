// Package multientry110 は三時間軸の値copyと金融適格候補から、取得時の複合入口を純判定します。
package multientry110

import frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"

type Policy string
type Status string
type Role string

type Route string

const (
	EntryE0        Policy = "ENTRY_E0"
	EntryE2        Policy = "ENTRY_E2"
	Unknown        Status = "未知"
	Wait           Status = "待機"
	Allowed        Status = "許可"
	Conflict       Status = "競合"
	NoRole         Role   = ""
	Trend          Role   = "T"
	Reversal       Role   = "R"
	Control        Role   = "E0"
	Continuation   Route  = "T継続"
	PullbackResume Route  = "T押戻し再開"
	LocalReversal  Route  = "R局所転換"
)

// FrameEvidence は判断で使った値と公表時計を、子足の全複製をせず記録します。
type FrameEvidence struct {
	ID                 string          `json:"id"`
	SessionID          string          `json:"session_id"`
	Contract           string          `json:"contract"`
	WidthSeconds       int             `json:"width_seconds"`
	Start              float64         `json:"start"`
	End                float64         `json:"end"`
	NominalAvailable   float64         `json:"nominal_available"`
	AvailableAt        float64         `json:"available_at"`
	ObservedAt         float64         `json:"observed_at"`
	DeliveryAt         float64         `json:"delivery_at"`
	RecordOrdinal      uint64          `json:"record_ordinal"`
	PublicationOrdinal uint64          `json:"publication_ordinal"`
	ChildrenSHA256     string          `json:"children_sha256"`
	PriceKnown         bool            `json:"price_known"`
	VolumeKnown        bool            `json:"volume_known"`
	OHLC               frame.OHLC      `json:"ohlc"`
	Technical          frame.Technical `json:"technical"`
}

// PositionAudit は気配と支持線・平均の距離を、正ATRとともに記録します。
type PositionAudit struct {
	Known           bool    `json:"known"`
	ATR             float64 `json:"atr"`
	LineDistance    float64 `json:"line_distance"`
	LineDistanceATR float64 `json:"line_distance_atr"`
	EMADistance     float64 `json:"ema_distance"`
	EMADistanceATR  float64 `json:"ema_distance_atr"`
}

// Candidate はActorが金融適格性を確認した候補の変更禁止な値copyです。
type Candidate struct {
	ID         string  `json:"id"`
	Side       int     `json:"side"`
	At         float64 `json:"at"`
	EntryQuote float64 `json:"entry_quote"`
	Quantity   int     `json:"quantity"`
}

// Check は未知と条件不成立を区別する一つの論理群です。
type Check struct {
	Known  bool   `json:"known"`
	Passed bool   `json:"passed"`
	Reason string `json:"reason"`
}

// VolumeAudit は価格既知とは独立した量の状態です。入口のANDには使いません。
type VolumeAudit struct {
	WidthSeconds int     `json:"width_seconds"`
	Known        bool    `json:"known"`
	Value        float64 `json:"value"`
}

// Background は並び、速い傾き、遅い傾きの実値と三者整合の向きです。
type Background struct {
	WidthSeconds    int     `json:"width_seconds"`
	Known           bool    `json:"known"`
	Direction       int     `json:"direction"`
	Gap             float64 `json:"gap"`
	FastDelta       float64 `json:"fast_delta"`
	SlowDelta       float64 `json:"slow_delta"`
	NormalizedKnown bool    `json:"normalized_known"`
	GapATR          float64 `json:"gap_atr"`
	FastDeltaATR    float64 `json:"fast_delta_atr"`
	SlowDeltaATR    float64 `json:"slow_delta_atr"`
	PriorHighKnown  bool    `json:"prior_high_known"`
	PriorHigh       float64 `json:"prior_high"`
	PriorLowKnown   bool    `json:"prior_low_known"`
	PriorLow        float64 `json:"prior_low"`
}

// SetupView は固定線、順序、期限を金融へ公開する不変な監査値です。
type SetupView struct {
	ID               string        `json:"id"`
	Active           bool          `json:"active"`
	Phase            string        `json:"phase"`
	AnchorID         string        `json:"anchor_id"`
	PivotID          string        `json:"pivot_id"`
	Boundary         float64       `json:"boundary"`
	Trigger          float64       `json:"trigger"`
	CreatedAt        float64       `json:"created_at"`
	ExpiresAt        float64       `json:"expires_at"`
	FailureEnd       float64       `json:"failure_end"`
	RecoveryEnd      float64       `json:"recovery_end"`
	BreakoutEnd      float64       `json:"breakout_end"`
	EventBarID       string        `json:"event_bar_id"`
	Event            string        `json:"event"`
	Reason           string        `json:"reason"`
	ConfirmedAt      float64       `json:"confirmed_at"`
	ConfirmedFrameID string        `json:"confirmed_frame_id"`
	AnchorPullback   bool          `json:"anchor_pullback"`
	Anchor           FrameEvidence `json:"anchor"`
	Pivot            frame.Pivot   `json:"pivot"`
	FailureExtreme   float64       `json:"failure_extreme"`
}

// StateView は内部の数値履歴を複製せず、構造と現在性を示す値です。
type StateView struct {
	SessionID       string       `json:"session_id"`
	Contract        string       `json:"contract"`
	AsOf            float64      `json:"as_of"`
	LastFiveID      string       `json:"last_five_id"`
	HasPreviousFive bool         `json:"has_previous_five"`
	Trend           [2]SetupView `json:"trend"`
	Reversal        [2]SetupView `json:"reversal"`
	ResetReason     string       `json:"reset_reason"`
}

// Assessment は一候補の原値、各論理群、入口ラベルです。
type Assessment struct {
	Candidate             Candidate        `json:"candidate"`
	SnapshotID            string           `json:"snapshot_id"`
	Policy                Policy           `json:"policy"`
	Known                 bool             `json:"known"`
	Allowed               bool             `json:"allowed"`
	Status                Status           `json:"status"`
	Role                  Role             `json:"role"`
	Route                 Route            `json:"route"`
	Reason                string           `json:"reason"`
	Trend                 Check            `json:"trend"`
	Common                Check            `json:"common"`
	ContinuationDirection Check            `json:"continuation_direction"`
	ResumeDirection       Check            `json:"resume_direction"`
	RiskBand              Check            `json:"risk_band"`
	TrendValid            Check            `json:"trend_valid"`
	ReversalValid         Check            `json:"reversal_valid"`
	TrendDistance         Check            `json:"trend_distance"`
	ReversalDistance      Check            `json:"reversal_distance"`
	ContinuationUpper     Check            `json:"continuation_upper"`
	Continuation          Check            `json:"continuation"`
	Pullback              Check            `json:"pullback"`
	Reversal              Check            `json:"reversal"`
	Background            [3]Background    `json:"background"`
	Momentum              Check            `json:"momentum"`
	TrendMomentum         Check            `json:"trend_momentum"`
	ReversalMomentum      Check            `json:"reversal_momentum"`
	Spike                 Check            `json:"spike"`
	Structure             SetupView        `json:"structure"`
	ReversalLabel         string           `json:"reversal_label"`
	Volume                [3]VolumeAudit   `json:"volume"`
	Maintenance           Check            `json:"maintenance"`
	Recovery              Check            `json:"recovery"`
	UpperNotOpposite      Check            `json:"upper_not_opposite"`
	Evidence              [3]FrameEvidence `json:"evidence"`
	PreviousFive          FrameEvidence    `json:"previous_five"`
	Position              PositionAudit    `json:"position"`
	TrendPosition         PositionAudit    `json:"trend_position"`
	ReversalPosition      PositionAudit    `json:"reversal_position"`
}

// BatchAssessment は同一snapshotで先に全候補を判定した結果です。
type BatchAssessment struct {
	SnapshotID string         `json:"snapshot_id"`
	Policy     Policy         `json:"policy"`
	Conflict   bool           `json:"conflict"`
	Decisions  []Assessment   `json:"decisions"`
	State      StateView      `json:"state"`
	Volume     [3]VolumeAudit `json:"volume"`
}

// RuleConfig は市場結果を見る前に決めた閾値の値copyです。
type RuleConfig struct {
	Version              string  `json:"version"`
	SetupSeconds         float64 `json:"setup_seconds"`
	MaxDistanceATR       float64 `json:"max_distance_atr"`
	SpikeTRMultiple      float64 `json:"spike_tr_multiple"`
	SpikeRSIChange       float64 `json:"spike_rsi_change"`
	MomentumBars         int     `json:"momentum_bars"`
	ReversalRSIAllowance float64 `json:"reversal_rsi_allowance"`
}

// Rules は閾値を変更できない純仕様の値copyを返します。
//
// 引数: なし。
// 返り値: RuleConfigは期限1800秒、距離1ATR、スパイク2ATRかつ20RSI、連続2本です。
func Rules() RuleConfig {
	return RuleConfig{"三時間軸の有効状態入口110・純仕様1", 1800, 1, 2, 20, 2, 10}
}

type sideState struct {
	T              SetupView
	R              SetupView
	FailureExtreme float64
	RetiredT       string
	RetiredR       string
}

// EntryState は呼出側の値を変更せず返す、場内の固定構造状態です。
type EntryState struct {
	Session            frame.Session
	HasSession         bool
	HasAt              bool
	LastAt             float64
	Last               [3]frame.Frame
	HasLast            [3]bool
	PreviousFive       frame.Frame
	HasPreviousFive    bool
	PreviousFifteen    frame.Frame
	HasPreviousFifteen bool
	Sides              [2]sideState
	ResetReason        string
}

// NewEntryState は構造を継承しない空の状態を作ります。
//
// 引数: なし。
// 返り値: EntryStateは当場の公表をまだ持たない状態です。
func NewEntryState() EntryState { return EntryState{} }

// View は売買方向順（買い、売り）で現在の構造監査を返します。
//
// 引数: s(EntryState)は純更新後の値です。
// 返り値: StateViewは入力へaliasしない値copyです。
func (s EntryState) View() StateView {
	v := StateView{SessionID: s.Session.ID, Contract: s.Session.Contract, AsOf: s.LastAt, HasPreviousFive: s.HasPreviousFive, ResetReason: s.ResetReason}
	if s.HasLast[0] {
		v.LastFiveID = s.Last[0].ID
	}
	for i := range s.Sides {
		v.Trend[i] = s.Sides[i].T
		v.Reversal[i] = s.Sides[i].R
	}
	return v
}
