package multientry110

import (
	"fmt"
	"strings"

	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

// knownValues は指定した値が全て既知かを返します。
//
// 引数: values(...frame.Value)は必要な指標列です。
// 返り値: boolは未知をゼロとして補わず全列が既知であることです。
func knownValues(values ...frame.Value) bool {
	for _, v := range values {
		if !v.Known {
			return false
		}
	}
	return true
}

// background は平均値の並びと二つの傾きを別々に計算します。
//
// 引数: f(frame.Frame)は当場の一つの確定公表です。
// 返り値: Backgroundは方向整合とATR正規化、pivotの診断値です。
func background(f frame.Frame) Background {
	t := f.Technical
	b := Background{WidthSeconds: f.WidthSeconds, PriorHighKnown: f.PriorHigh.Known, PriorHigh: f.PriorHigh.Price, PriorLowKnown: f.PriorLow.Known, PriorLow: f.PriorLow.Price}
	if !f.PriceKnown || !knownValues(t.EMA8, t.EMA21, t.PreviousEMA8, t.PreviousEMA21, t.ATR) {
		return b
	}
	b.Known = true
	b.Gap = t.EMA8.Value - t.EMA21.Value
	b.FastDelta = t.EMA8.Value - t.PreviousEMA8.Value
	b.SlowDelta = t.EMA21.Value - t.PreviousEMA21.Value
	if b.Gap > 0 && b.FastDelta > 0 && b.SlowDelta > 0 {
		b.Direction = 1
	}
	if b.Gap < 0 && b.FastDelta < 0 && b.SlowDelta < 0 {
		b.Direction = -1
	}
	if t.ATR.Value > 0 {
		b.NormalizedKnown = true
		b.GapATR = b.Gap / t.ATR.Value
		b.FastDeltaATR = b.FastDelta / t.ATR.Value
		b.SlowDeltaATR = b.SlowDelta / t.ATR.Value
	}
	return b
}

// common は価格、公表、鮮度、数値種、当場履歴の基本可用性を分けます。
//
// 引数: state(EntryState)、snapshot(frame.Snapshot)は純更新後状態と判断copyです。
// 返り値: Checkは全経路共通の既知性です。量やpivot不成立は必須にしません。
func common(state EntryState, snapshot frame.Snapshot) Check {
	if !snapshot.HasObserved {
		return Check{Reason: "観測時計が未到達"}
	}
	for _, width := range widths {
		scale, _ := snapshot.Scale(width)
		if !scale.HasCurrent || scale.SeedOnly {
			return Check{Reason: fmt.Sprintf("%d秒の当場公表待ち（数値種を現在支持にしない）", width)}
		}
		if !scale.Current.PriceKnown {
			return Check{Reason: fmt.Sprintf("%d秒の価格が未知", width)}
		}
		if !scale.Fresh || snapshot.AsOf-scale.Current.AvailableAt >= float64(width) {
			return Check{Reason: fmt.Sprintf("%d秒公表が鮮度外", width)}
		}
		if !background(scale.Current).Known {
			return Check{Reason: fmt.Sprintf("%d秒EMA/前値/ATRの履歴不足", width)}
		}
		if scale.Current.Technical.ATR.Value <= 0 {
			return Check{Reason: fmt.Sprintf("%d秒ATRが正でない", width)}
		}
	}
	if !state.HasPreviousFive {
		return Check{Reason: "連続した当場5分の前公表が不足"}
	}
	for _, f := range [2]frame.Frame{state.Last[0], state.PreviousFive} {
		t := f.Technical
		if !knownValues(t.RSI, t.PreviousRSI, t.Histogram, t.PreviousHistogram, t.TR, t.PreviousATR) || t.PreviousATR.Value <= 0 {
			return Check{Reason: "5分の必要な勢い/値幅列が未知又は前ATRが正でない"}
		}
	}
	t := state.Last[1].Technical
	if !knownValues(t.RSI, t.PreviousRSI, t.Histogram, t.PreviousHistogram) {
		return Check{Reason: "15分の必要な勢い列が未知"}
	}
	return Check{Known: true, Passed: true, Reason: "三尺度の当場公表・時計・価格・平均値履歴が既知"}
}

// and は独立票数を作らず、経路の論理群を一つのANDとして評価します。
//
// 引数: checks(...Check)は同じ経路の必要条件です。
// 返り値: Checkは必要な未知を残し、全既知の場合だけ成立/不成立を示します。
func and(checks ...Check) Check {
	for _, check := range checks {
		if !check.Known {
			return Check{Reason: check.Reason}
		}
	}
	for _, check := range checks {
		if !check.Passed {
			return Check{Known: true, Reason: check.Reason}
		}
	}
	return Check{Known: true, Passed: true, Reason: "複合条件成立"}
}

// condition は既知な論理群の真偽と説明を作ります。
//
// 引数: pass(bool)、yes/no(string)は判定済み真偽と二つの説明です。
// 返り値: Checkは未知でない論理群です。
func condition(pass bool, yes, no string) Check {
	if pass {
		return Check{Known: true, Passed: true, Reason: yes}
	}
	return Check{Known: true, Reason: no}
}

// maintenance は加速差ではなく5分RSI方向側とhistogram水準を確認します。
//
// 引数: state(EntryState)、side(int)は共通可用性を通った確定履歴です。
// 返り値: Checkは直近2RSIが方向側かつ現在Hが非逆向きの維持状態です。
func maintenance(state EntryState, side int) Check {
	s := float64(side)
	t, p := state.Last[0].Technical, state.PreviousFive.Technical
	pass := s*(t.RSI.Value-50) > 0 && s*(p.RSI.Value-50) > 0 && s*t.Histogram.Value >= 0
	return condition(pass, "RSI方向側を維持しH水準が非逆向き", "5分のRSI方向側維持又はH水準が未達")
}

// recovery は負Hの改善も水準と区別して回復状態として確認します。
//
// 引数: five(frame.Frame)、side(int)は共通可用性を通った5分足です。
// 返り値: CheckはRSI40/60帯内かつRSIとHが取得方向へ改善したことです。
func recovery(five frame.Frame, side int) Check {
	s := float64(side)
	t := five.Technical
	pass := s*(t.RSI.Value-50) >= -Rules().ReversalRSIAllowance && s*(t.RSI.Value-t.PreviousRSI.Value) > 0 && s*(t.Histogram.Value-t.PreviousHistogram.Value) > 0
	return condition(pass, "RSI帯を回復しRSIとHが取得向きへ改善", "5分のRSI帯/RSI増分/H増分の回復が未達")
}

// upperNotOpposite は15分で旧方向の推進が同時に続いている場合だけ否定します。
//
// 引数: fifteen(frame.Frame)、side(int)は現在15分の既知勢い値です。
// 返り値: CheckはRSI逆側/H逆側/両増分逆向きが同時に成立していないことです。
func upperNotOpposite(fifteen frame.Frame, side int) Check {
	s := float64(side)
	t := fifteen.Technical
	push := s*(t.RSI.Value-50) < 0 && s*t.Histogram.Value < 0 && s*(t.Histogram.Value-t.PreviousHistogram.Value) < 0 && s*(t.RSI.Value-t.PreviousRSI.Value) < 0
	return condition(!push, "15分が旧方向の推進4条件を同時に満たさない", "15分のRSI/H水準と両増分が旧方向へ推進")
}

// spike は値幅とRSI順方向変化の同時異常を警戒します。
//
// 引数: state(EntryState)、side(int)は連続5分履歴とSource方向です。
// 返り値: Checkは直近2本に複合スパイクがないことです。
func spike(state EntryState, side int) Check {
	for _, f := range [2]frame.Frame{state.Last[0], state.PreviousFive} {
		t := f.Technical
		if !knownValues(t.TR, t.PreviousATR, t.RSI, t.PreviousRSI) {
			return Check{Reason: "5分スパイク判定の値幅/前ATR/RSIが未知"}
		}
		if t.TR.Value > Rules().SpikeTRMultiple*t.PreviousATR.Value && float64(side)*(t.RSI.Value-t.PreviousRSI.Value) > Rules().SpikeRSIChange {
			return Check{Known: true, Reason: "TRが前ATRの2倍超かつRSIが順方向20超の複合スパイク"}
		}
	}
	return Check{Known: true, Passed: true, Reason: "連続2本に値幅とRSIの複合スパイクなし"}
}

// distance は固定線の外側で最大1ATR以内の取得だけを認めます。
//
// 引数: candidate(Candidate)、setup(SetupView)、atr(float64)は新規側気配と確定5分ATRです。
// 返り値: Checkは同値線外を許さず、ATR上限の同値は許す位置判定です。
func distance(candidate Candidate, setup SetupView, atr float64) Check {
	d := float64(candidate.Side) * (candidate.EntryQuote - setup.Trigger)
	pass := atr > 0 && d > 0 && d <= Rules().MaxDistanceATR*atr && float64(candidate.Side)*(candidate.EntryQuote-setup.Boundary) > 0
	return Check{Known: true, Passed: pass, Reason: map[bool]string{true: "固定線の外かつ取得距離1ATR以内", false: "取得側気配が線内/同値、risk境界内又は1ATR超"}[pass]}
}

// assess は同じ更新後stateを一候補へ適用します。状態を消費しません。
//
// 引数: state(EntryState)、snapshot(frame.Snapshot)、candidate(Candidate)、policy(Policy)、identity(string)は共通公開値です。
// 返り値: AssessmentはSource方向・数量・IDをそのまま保持した判定です。
func assess(state EntryState, snapshot frame.Snapshot, candidate Candidate, policy Policy, identity string) Assessment {
	a := Assessment{Candidate: candidate, SnapshotID: identity, Policy: policy, Status: Unknown}
	for i, width := range widths {
		scale, _ := snapshot.Scale(width)
		a.Volume[i] = VolumeAudit{WidthSeconds: width, Known: scale.HasCurrent && scale.Current.VolumeKnown, Value: scale.Current.Volume}
		a.Background[i].WidthSeconds = width
		if scale.HasCurrent {
			a.Background[i] = background(scale.Current)
			a.Evidence[i] = evidence(scale.Current)
		}
	}
	if state.HasPreviousFive {
		a.PreviousFive = evidence(state.PreviousFive)
	}
	if policy == EntryE0 {
		a.Known = true
		a.Allowed = true
		a.Status = Allowed
		a.Role = Control
		a.Reason = "入口追加Gateなし対照"
		return a
	}
	ready := common(state, snapshot)
	a.Common = ready
	if !ready.Known {
		a.Reason = ready.Reason
		a.Trend = ready
		a.Reversal = ready
		a.Continuation = ready
		a.Pullback = ready
		return a
	}
	i := 0
	if candidate.Side == -1 {
		i = 1
	}
	local := state.Sides[i]
	five, fifteen := state.Last[0], state.Last[1]
	s := float64(candidate.Side)
	a.Maintenance = maintenance(state, candidate.Side)
	a.Recovery = recovery(five, candidate.Side)
	a.UpperNotOpposite = upperNotOpposite(fifteen, candidate.Side)
	a.Spike = spike(state, candidate.Side)
	aligned := true
	for _, b := range a.Background {
		aligned = aligned && b.Direction == candidate.Side
	}
	direction := condition(aligned, "三尺度の並びと両傾きがSource方向", "三尺度の並び又は両傾きが不一致/同値")
	tValid := condition(local.T.Active && local.T.Phase == "確認済み", "現在も有効なT支持", "T支持が未確認又は失効")
	rValid := condition(local.R.Active && local.R.Phase == "確認済み", "現在も有効なR支持", "R支持が未確認又は失効")
	ft := fifteen.Technical
	upperContinue := condition(s*(ft.RSI.Value-50) >= 0 && (s*ft.Histogram.Value >= 0 || s*(ft.Histogram.Value-ft.PreviousHistogram.Value) >= 0), "15分RSI方向側とH水準又は回復", "15分の方向側/継続勢いが未達")
	a.TrendMomentum = and(a.Maintenance, upperContinue)
	recoverOrMaintain := condition(a.Maintenance.Passed || a.Recovery.Passed, "5分は維持又は回復", "5分の維持/回復がともに未達")
	a.ReversalMomentum = and(recoverOrMaintain, a.UpperNotOpposite)
	resumeDirection := condition(a.Background[2].Direction == candidate.Side && a.Background[0].FastDelta*s > 0, "30分背景と5分EMA8回復", "30分背景又は5分EMA8回復が未達")
	riskBand := condition(local.T.AnchorPullback && s*(fifteen.OHLC.Close-local.T.Boundary) > 0, "固定15分押戻し帯を保持", "固定時押戻し又は15分risk帯保持が未達")
	a.ContinuationDirection, a.ResumeDirection, a.RiskBand = direction, resumeDirection, riskBand
	a.TrendValid, a.ReversalValid = tValid, rValid
	a.TrendDistance = distance(candidate, local.T, five.Technical.ATR.Value)
	a.ReversalDistance = distance(candidate, local.R, five.Technical.ATR.Value)
	a.ContinuationUpper = upperContinue
	a.TrendPosition = positionEvidence(candidate, local.T, five)
	a.ReversalPosition = positionEvidence(candidate, local.R, five)
	a.Continuation = and(direction, tValid, a.TrendMomentum, a.Spike, a.TrendDistance)
	a.Pullback = and(resumeDirection, riskBand, tValid, recoverOrMaintain, a.UpperNotOpposite, a.Spike, a.TrendDistance)
	a.Reversal = and(rValid, a.ReversalMomentum, a.Spike, a.ReversalDistance)
	a.Trend = condition(a.Continuation.Passed || a.Pullback.Passed, "T継続又は押戻し再開が成立", "T継続:"+a.Continuation.Reason+" / T再開:"+a.Pullback.Reason)
	a.Known = true
	a.Status = Wait
	if a.Continuation.Passed {
		a.Route = Continuation
		a.Role = Trend
		a.Structure = local.T
		a.Momentum = a.TrendMomentum
	}
	if a.Route == "" && a.Pullback.Passed {
		a.Route = PullbackResume
		a.Role = Trend
		a.Structure = local.T
		a.Momentum = a.ReversalMomentum
	}
	if a.Route == "" && a.Reversal.Passed {
		a.Route = LocalReversal
		a.Role = Reversal
		a.Structure = local.R
		a.Momentum = a.ReversalMomentum
		a.ReversalLabel = "長期混在の局所反転"
		if a.Background[2].Direction == candidate.Side {
			a.ReversalLabel = "長期背景内の局所反転"
		}
		if a.Background[2].Direction == -candidate.Side {
			a.ReversalLabel = "長期逆行中の局所反転"
		}
	}
	if a.Route != "" {
		a.Allowed = true
		a.Status = Allowed
		a.Reason = string(a.Route) + ":方向/帯・現在有効な支持・勢い・値幅/位置が成立"
		a.Position = positionEvidence(candidate, a.Structure, five)
		return a
	}
	a.Reason = strings.Join([]string{"T継続:" + a.Continuation.Reason, "T再開:" + a.Pullback.Reason, "R:" + a.Reversal.Reason}, " / ")
	if local.T.ID != "" {
		a.Position = positionEvidence(candidate, local.T, five)
	} else {
		a.Position = positionEvidence(candidate, local.R, five)
	}
	return a
}

// AssessBatch は金融適格集合だけを同じsnapshotで先に評価します。
//
// 引数: state(EntryState)、snapshot(frame.Snapshot)、candidates([]Candidate)、policy(Policy)は旧値と候補の値copyです。
// 返り値: EntryState/BatchAssessment/errorは純更新後値・全候補判定・入力違反です。原入力は変更しません。
func AssessBatch(state EntryState, snapshot frame.Snapshot, candidates []Candidate, policy Policy) (EntryState, BatchAssessment, error) {
	originalState := state
	snapshot = PolicySnapshot(snapshot)
	state.Session.EOF = 0
	if err := validate(state, snapshot, candidates, policy); err != nil {
		return originalState, BatchAssessment{}, err
	}
	identity, err := SnapshotID(snapshot)
	if err != nil {
		return originalState, BatchAssessment{}, err
	}
	next, err := advance(state, snapshot)
	if err != nil {
		return originalState, BatchAssessment{}, err
	}
	output := BatchAssessment{SnapshotID: identity, Policy: policy, State: next.View(), Decisions: make([]Assessment, 0, len(candidates))}
	for i, width := range widths {
		scale, _ := snapshot.Scale(width)
		output.Volume[i] = VolumeAudit{WidthSeconds: width, Known: scale.HasCurrent && scale.Current.VolumeKnown, Value: scale.Current.Volume}
	}
	for _, candidate := range candidates {
		a := assess(next, snapshot, candidate, policy, identity)
		output.Decisions = append(output.Decisions, a)
	}
	output.Conflict = resolveConflict(policy, output.Decisions)
	return next, output, nil
}

// resolveConflict は金融適格集合の成立結果だけを対象にした最後の安全判定です。
//
// 引数: policy(Policy)、decisions([]Assessment)は内部で新規確保した結果です。
// 返り値: boolは両方向成立の競合です。未知/不成立候補は変えません。
func resolveConflict(policy Policy, decisions []Assessment) bool {
	if policy != EntryE2 {
		return false
	}
	buy, sell := false, false
	for _, a := range decisions {
		if a.Allowed {
			buy = buy || a.Candidate.Side == 1
			sell = sell || a.Candidate.Side == -1
		}
	}
	if !buy || !sell {
		return false
	}
	for i := range decisions {
		a := &decisions[i]
		if a.Allowed {
			a.Known = true
			a.Allowed = false
			a.Status = Conflict
			a.Reason = "金融適格集合内で両方向の技法成立が競合"
		}
	}
	return true
}

// AssessEntry は純条件を単候補で確認する補助APIです。金融接続ではAssessBatchを使います。
//
// 引数: state(EntryState)、snapshot(frame.Snapshot)、candidate(Candidate)、policy(Policy)は単候補の値copyです。
// 返り値: EntryState/Assessment/errorは次状態・単候補結果・入力違反です。競合判定を代替しません。
func AssessEntry(state EntryState, snapshot frame.Snapshot, candidate Candidate, policy Policy) (EntryState, Assessment, error) {
	next, batch, err := AssessBatch(state, snapshot, []Candidate{candidate}, policy)
	if err != nil {
		return state, Assessment{}, err
	}
	return next, batch.Decisions[0], nil
}
