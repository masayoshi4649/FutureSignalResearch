"""109頻度要求をmetadataだけで認証し、Observerを起動せず照合結果を保存する。"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re

OWN = Path(__file__).resolve()
CLOCK = 'csv_end_plus60_at_record_scheduler'


def digest(path: Path) -> str:
    """
    機能: コード・exe・停止・小JSONだけを同定する。
    引数: path (Path) はCSV/Record/Raw以外の明示参照。
    返り値: str はSHA256。市場本文の拡張子なら拒否する。
    """
    lower = path.name.lower()
    if path.suffix.lower() in ('.csv', '.gz', '.jsonl', '.xlsx', '.png') or lower.endswith(('.native.json', '.trades.json', '.resources.json')):
        raise ValueError('metadata認証へ市場本文/成果物が混入:' + str(path))
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def absolute(text: str) -> Path:
    """
    機能: 明示参照を絶対pathとして解決する。
    引数: text (str) はCLI又はJSONのpath。
    返り値: Path は絶対path。不明な相対pathは拒否する。
    """
    path = Path(text)
    if not path.is_absolute():
        raise ValueError('絶対pathが必要:' + str(text))
    return path.resolve()


def reference(value: dict) -> tuple[Path, str]:
    """
    機能: 固定参照のpath/SHAを構文検査する。
    引数: value (dict) はpath/sha256。
    返り値: tuple[Path,str] は正規位置と小文字64桁SHA。
    """
    path = absolute(value['path'])
    expected = value['sha256']
    if not isinstance(expected, str) or re.fullmatch('[0-9a-f]{64}', expected) is None:
        raise ValueError('小文字SHA256が必要:' + str(path))
    return path, expected


def authenticate(value: dict, proof: dict[str, str], parse: bool = False) -> dict | None:
    """
    機能: 明示された非市場ファイルをSHA認証する。
    引数: value (dict)、proof (dict[str,str])、parse (bool) は参照・台帳・JSON投影の有無。
    返り値: dict|None はJSON値又は認証のみの結果。
    """
    path, expected = reference(value)
    got = digest(path)
    if got != expected:
        raise ValueError('固定参照SHA差:' + str(path))
    if str(path) in proof and proof[str(path)] != got:
        raise ValueError('同じpathの二重指紋差:' + str(path))
    proof[str(path)] = got
    return json.loads(path.read_text(encoding='utf-8-sig')) if parse else None


def same_reference(a: dict, b: dict) -> bool:
    """
    機能: path表記とSHAを固定参照として照合する。
    引数: a/b (dict) は二つの参照。
    返り値: bool は正規位置とSHAが一致したとき真。
    """
    return reference(a) == reference(b)


def config(value: dict) -> None:
    """
    機能: 主頻度の時計・静観・BBO年齢条件を検査する。
    引数: value (dict) は要求又は前段完成の設定。
    返り値: None。pure Rulesを条件で上書きする入口は持たない。
    """
    if value.get('clock_model') != CLOCK or value.get('quiet_seconds') != 1200 or value.get('quote_max_age_seconds') != 0:
        raise ValueError('主頻度のclock/quiet/quote0条件差')


def normalize_csv(source_root: str, name: str) -> Path:
    """
    機能: manifestの相対又は絶対CSV参照をsource_root内へ結ぶ。
    引数: source_root/name (str) は絶対baseとCSV参照。
    返り値: Path は絶対参照。親Traversal・別root・不明rootは拒否する。
    """
    base = absolute(source_root)
    path = Path(name)
    if not name or '..' in path.parts:
        raise ValueError('CSV参照の空欄/親Traversalを拒否')
    if not path.is_absolute():
        if path.drive or path.anchor:
            raise ValueError('CSV参照のドライブ相対/根付きpathを拒否')
        path = base / path
    path = path.resolve()
    if not path.is_relative_to(base):
        raise ValueError('CSV参照がsource_root外')
    return path


def stat_csv(value: dict, expected: dict, source_root: str) -> dict:
    """
    機能: CSVの参照metadataと実物のsizeだけを照合する。
    引数: value/expected (dict)、source_root (str) は要求CSV・manifest参照・絶対base。
    返り値: dict はpath/size/mtimeの診断。CSV本文/SHA計算は行わない。
    """
    path, want = reference(value)
    manifest_path = normalize_csv(source_root, expected['path'])
    if path != manifest_path or want != expected['sha256'] or value['bytes'] != expected['size']:
        raise ValueError('CSV参照とmanifestのpath/SHA/size差')
    info = path.stat()
    if not path.is_file() or info.st_size != value['bytes'] or info.st_size <= 0:
        raise ValueError('CSV stat size差:' + str(path))
    return {'path': str(path), 'bytes': info.st_size, 'mtime_ns': info.st_mtime_ns, 'declared_sha256': want, 'body_read': False, 'sha_recalculated': False}


def validate(request_ref: dict, output: Path, own_path: Path = OWN) -> dict:
    """
    機能: Observer要求を市場本文なしで照合し、成功metadataを組み立てる。
    引数: request_ref (dict)、output/own_path (Path) は固定要求・照合結果先・自己コード。
    返り値: dict は限定した認証証拠。市場outを作成せずObserverを起動しない。
    """
    output = absolute(str(output))
    if output.exists():
        raise ValueError('照合出力は新規pathだけを許す')
    proof = {}
    request = authenticate(request_ref, proof, True)
    if request.get('version') != 1 or request.get('trial') != 109 or request.get('fixed') is not True or request.get('stage') not in ('first2', 'full70'):
        raise ValueError('固定109頻度要求/段階が必要')
    config(request)
    market_output = absolute(request['output_dir'])
    if market_output.exists():
        raise ValueError('市場頻度outは未作成でなければならない')
    if output == market_output or output.is_relative_to(market_output):
        raise ValueError('照合結果を市場頻度out内へ保存しない')
    technique = authenticate(request['technique_fixed'], proof, True)
    if technique.get('version') != 1 or technique.get('trial') != 109 or technique.get('fixed') is not True:
        raise ValueError('技法固定109が必要')
    config(technique)
    # ----------------------------------------
    # 要求側で独立に認証された別の70入力へすり替わらないよう三参照を結びます。
    for requested, fixed in [('manifest', 'source_manifest'), ('corpus', 'source_corpus'), ('source_completion', 'source_completion')]:
        if not same_reference(request[requested], technique[fixed]):
            raise ValueError('技法固定と要求のSource三参照差:' + requested)
    code = technique.get('code_sha256')
    if not isinstance(code, dict) or not code:
        raise ValueError('技法のコード指紋が不足')
    own_path = own_path.resolve()
    normalized_code = {str(absolute(name)): expected for name, expected in code.items()}
    if normalized_code.get(str(own_path)) != digest(own_path):
        raise ValueError('照合器自身が技法固定のコードへ束縛されていない')
    for path, expected in normalized_code.items():
        authenticate({'path': path, 'sha256': expected}, proof)
    authenticate(technique['observer_binary'], proof)
    stop = authenticate(technique['observer_stop'], proof, True)
    if stop.get('成功') is not True:
        raise ValueError('Observer停止が未成功')
    if not same_reference(technique['observer_binary'], {'path': stop['実行物'], 'sha256': stop['実行物SHA256']}):
        raise ValueError('Observer実行物と人工停止のpath/SHA差')
    # ----------------------------------------
    # manifest/corpus/completionは小metadataを認証するだけで、Source/Recordは開きません。
    manifest = authenticate(request['manifest'], proof, True)
    corpus = authenticate(request['corpus'], proof, True)
    completion = authenticate(request['source_completion'], proof, True)
    if not same_reference(corpus['input_manifest'], request['manifest']):
        raise ValueError('Source台帳と入力manifestの参照差')
    if corpus.get('version') != 1 or corpus.get('trial') != 106 or corpus.get('fixed') is not True or len(corpus.get('scenes', [])) != 70:
        raise ValueError('固定106Source台帳70場が必要')
    if completion.get('version') != 1 or completion.get('trial') != 106 or completion.get('success') is not True or completion.get('sessions') != 70 or len(completion.get('results', [])) != 70:
        raise ValueError('成功106Source完成70場が必要')
    if len(manifest.get('sessions', [])) != 70:
        raise ValueError('入力manifest70場が必要')
    scenes = request.get('scenes', [])
    count = 2 if request['stage'] == 'first2' else 70
    if len(scenes) != count:
        raise ValueError('段階とscene数差')
    stats = []
    for ordinal, scene in enumerate(scenes):
        source = manifest['sessions'][ordinal]
        if scene['session'] != source['id'] or scene['session'] != corpus['scenes'][ordinal]['session'] or scene['session'] != completion['results'][ordinal]['session']:
            raise ValueError('manifest/Source台帳/完成と明示sceneの順差')
        if Path(scene['session']).name != scene['session']:
            raise ValueError('scene名がpathを含む')
        stats.append(stat_csv(scene['candle_csv'], source['files']['NK225_candle_300'], manifest['source_root']))
    first2 = request.get('first2_completion')
    if request['stage'] == 'first2':
        if first2 is not None:
            raise ValueError('first2の自己参照を拒否')
    else:
        if first2 is None:
            raise ValueError('全70には先頭2場成功が必要')
        prior = authenticate(first2, proof, True)
        if prior.get('version') != 1 or prior.get('trial') != 109 or prior.get('stage') != 'first2' or prior.get('success') is not True or prior.get('unchanged') is not True or len(prior.get('results', [])) != 2:
            raise ValueError('成功/入力不変first2完成が必要')
        if prior.get('financial_executed') is not False or prior.get('participation_calculated') is not False:
            raise ValueError('頻度に金融/参加率が混入')
        config(prior['config'])
        for field in ('technique_fixed', 'manifest', 'corpus', 'source_completion'):
            if not same_reference(prior[field], request[field]):
                raise ValueError('first2と全70の参照差:' + field)
        if [item['session'] for item in prior['results']] != [item['session'] for item in scenes[:2]]:
            raise ValueError('first2の場順差')
    after = {name: digest(Path(name)) for name in proof}
    if proof != after:
        raise ValueError('照合中にcode/metadataが変更された')
    for stat in stats:
        current = Path(stat['path']).stat()
        if (current.st_size, current.st_mtime_ns) != (stat['bytes'], stat['mtime_ns']):
            raise ValueError('照合中にCSV statが変更された')
    return {'成功': True, '範囲': 'Observer起動前のmetadata照合。Readerの全Source/Record検査やCSV本文指紋は本実行で行う',
            'UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'request': request_ref,
            'technique_fixed': request['technique_fixed'], 'stage': request['stage'], 'scenes': [item['session'] for item in scenes],
            'observer_binary': technique['observer_binary'], 'observer_stop': technique['observer_stop'],
            'before': proof, 'after': after, 'unchanged': True, 'csv_stat': stats,
            'CSV本文読込': 0, 'CSV本文SHA計算': 0, 'RecordRawSource本文読込': 0,
            'Observer起動': 0, '金融実行': 0, '市場out作成': False, '照合結果出力先': str(output)}


def main() -> None:
    """
    機能: 固定要求の照合結果を明示された新規pathへ保存する。
    引数: CLI --request/--request-sha256/--out は絶対要求path・SHA・新規結果path。
    返り値: None。不成立では成功JSONを保存しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', required=True, type=Path)
    parser.add_argument('--request-sha256', required=True)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    request_ref = {'path': str(absolute(str(args.request))), 'sha256': args.request_sha256}
    result = validate(request_ref, args.out)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'成功': True, '照合結果': {'path': str(args.out.resolve()), 'sha256': digest(args.out)}, 'Observer起動': 0}, ensure_ascii=False))


if __name__ == '__main__':
    main()
