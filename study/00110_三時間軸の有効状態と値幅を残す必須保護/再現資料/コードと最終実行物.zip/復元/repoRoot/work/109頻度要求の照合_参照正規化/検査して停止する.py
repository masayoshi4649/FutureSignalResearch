"""109頻度要求のmetadata照合器を人工検査して停止する。"""
from __future__ import annotations

import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]


def digest(path: Path) -> str:
    """
    機能: 所有コードと検査記録を同定する。
    引数: path (Path) はこのmodule内の小ファイル。
    返り値: str はSHA256。
    """
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_new(path: Path, value: dict) -> None:
    """
    機能: 確認又は停止JSONを新規保存する。
    引数: path (Path)、value (dict) は出力先と内容。
    返り値: None。既存停止を上書きしない。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def main() -> None:
    """
    機能: 人工のみを実行し、共通所有mapを持つ停止を保存する。
    引数: なし。実際の市場要求やCSV/Recordを参照しない。
    返り値: None。
    """
    assert not (OWN / '停止.json').exists()
    parents = {
        'work/109頻度要求の照合/停止.json': '00a3a4944d44097aa3ef4bfe11d82093f8ffe3d36c2b316494faac2175d25d6f',
        'work/109入口の頻度前検査/停止.json': '5939b05e58cd4925f96b86db07b3ead1549fd131f5c2718b8212462062f27b0f',
    }
    original = {}
    for name, expected in parents.items():
        path = ROOT / name
        assert digest(path) == expected
        original[name] = expected
        stopped = json.loads(path.read_text(encoding='utf-8'))
        for code, want in stopped['所有コードSHA256'].items():
            item = Path(code)
            item = item if item.is_absolute() else ROOT / item
            assert digest(item) == want
            original[str(item)] = want
    paths = [OWN / name for name in ('照合する.py', '照合の人工検査.py', '検査して停止する.py', 'README.md')]
    before = {path.relative_to(ROOT).as_posix(): digest(path) for path in paths}
    result = subprocess.run([sys.executable, str(OWN / '照合の人工検査.py')], cwd=OWN, capture_output=True, text=True, encoding='utf-8', check=False)
    assert result.returncode == 0, result.stderr
    assert before == {name: digest(ROOT / name) for name in before}
    for name, expected in original.items():
        path = Path(name)
        assert digest(path if path.is_absolute() else ROOT / path) == expected
    check = {'成功': True, 'argv': [sys.executable, str(OWN / '照合の人工検査.py')], 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr,
             '主テスト': 7, '市場本文読込': 0, 'Observer起動': 0, '金融実行': 0, 'Python': sys.version, 'Python実行物': sys.executable, 'Python実行物SHA256': digest(Path(sys.executable))}
    write_new(OWN / '人工確認.json', check)
    stopped = {'成功': True, '停止': True, 'UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(), '所有コードSHA256': before,
               '人工確認SHA256': digest(OWN / '人工確認.json'), '主テスト': 7, '自己コード前後不変': True,
               '派生元停止SHA256': parents, '元2停止と所有コード前後不変': True, '参照正規化だけの派生': True,
               '範囲': 'Observer起動前のmetadata限定照合。CSVはstatのみ', '市場要求未読': True,
               '市場本文読込': 0, 'CSV本文SHA計算': 0, 'Observer起動': 0, '金融実行': 0, '停止済みGoコード変更': 0,
               '未実施': ['実first2/full70要求のmetadata照合', 'CSV本文/Reader完全性', '市場頻度/参加率/損益']}
    write_new(OWN / '停止.json', stopped)
    print(json.dumps({'成功': True, '停止SHA256': digest(OWN / '停止.json'), '人工確認SHA256': digest(OWN / '人工確認.json'), '主テスト': 7}, ensure_ascii=False))


if __name__ == '__main__':
    main()
