# 頻度要求を市場本文なしで照合する

この版は停止00a3a494…から参照正規化だけを派生した。manifestの相対CSVを絶対source_root内へ結び、Traversal・ドライブ相対path・別rootを拒否する。旧照合器と旧Go Observerは変更しない。

停止済みObserverは条件を受理すると直ちに本実行へ入るため、事前の受理確認はこの外部照合器で行う。Observer・金融Actorを起動せず、市場出力folderも作成しない。

```powershell
python 照合する.py --request '<要求JSONの絶対path>' --request-sha256 '<SHA256>' --out '<新規の照合結果JSON絶対path>'
```

照合器自身のコードも技法固定の `code_sha256` に含まれている必要がある。技法固定内のObserver exeと停止のpath/SHA、コード全件、Source三参照との同体、70場metadataと場順、CSV参照のpath/SHA/size、未作成市場out、全70時の同条件first2成功を検査する。

CSVはstatのsizeとmtimeだけを確認し、本文や本文SHAを読まない。Source/Record/Rawや場別圧縮結果も開かない。CSVの本文指紋とReaderの完全消費は停止済みObserverの本実行が担当する。この照合成功を本実行成功・技法成立・参加率・損益とは呼ばない。

照合結果は `--out` の新規JSONへ保存し、市場outの内側を指定すると拒否する。条件・停止・コードを書き換える機能はない。

`python 照合の人工検査.py` は、CSV/Record系のopenを禁止して7つの人工テストを行う。三参照差替え・順序・既存out・参照size/stat size・自己コード・停止exe不一致・clock変更・first2条件差を拒否する。人工CSVの作成は検査用tempだけ。

`python 検査して停止する.py` で人工の成功と自己コード前後不変を新しい停止へ記録する。実市場要求はこの停止段階では読まない。
