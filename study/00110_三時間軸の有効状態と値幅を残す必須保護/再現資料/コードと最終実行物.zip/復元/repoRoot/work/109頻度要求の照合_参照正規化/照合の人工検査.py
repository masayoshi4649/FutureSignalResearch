"""CSV本文を開かない109要求照合器のmetadata人工を検査する。"""
from __future__ import annotations

import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

OWN = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('頻度要求の照合', OWN / '照合する.py')
VERIFY = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(VERIFY)


class MetadataTests(unittest.TestCase):
    """小metadataとCSV statだけを使う人工検査。"""

    def setUp(self) -> None:
        """
        機能: 70場の人工metadataとstat対象をtempへ作る。
        引数: self (MetadataTests) は検査器。
        返り値: None。市場データを使用しない。
        """
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.scenes = []
        manifest = {'source_root': str(self.root), 'sessions': []}
        for ordinal in range(70):
            scene = f'人工_{ordinal:02d}_Day'
            csv = self.root / (scene + '.csv')
            csv.write_bytes('人工stat'.encode('utf-8') * 4)
            row = {'session': scene, 'candle_csv': {'path': str(csv), 'sha256': 'a' * 64, 'bytes': csv.stat().st_size}}
            self.scenes.append(row)
            manifest['sessions'].append({'id': scene, 'contract': '人工限月', 'files': {'NK225_candle_300': {'path': str(csv), 'sha256': 'a' * 64, 'size': csv.stat().st_size}}})
        self.manifest = self.put('manifest.json', manifest)
        self.corpus = self.put('corpus.json', {'version': 1, 'trial': 106, 'fixed': True, 'input_manifest': self.manifest, 'scenes': [{'session': row['session']} for row in self.scenes]})
        self.completion = self.put('complete.json', {'version': 1, 'trial': 106, 'success': True, 'sessions': 70, 'results': [{'session': row['session']} for row in self.scenes]})
        exe = self.root / '人工.exe'
        exe.write_bytes('起動しない人工実行物'.encode('utf-8'))
        self.binary = {'path': str(exe), 'sha256': VERIFY.digest(exe)}
        self.stop = self.put('停止.json', {'成功': True, '実行物': str(exe), '実行物SHA256': self.binary['sha256']})
        self.technique = {'version': 1, 'trial': 109, 'fixed': True, 'clock_model': VERIFY.CLOCK, 'quiet_seconds': 1200, 'quote_max_age_seconds': 0,
                          'observer_binary': self.binary, 'observer_stop': self.stop,
                          'code_sha256': {str(VERIFY.OWN): VERIFY.digest(VERIFY.OWN)},
                          'source_manifest': self.manifest, 'source_corpus': self.corpus, 'source_completion': self.completion}
        technique_ref = self.put('技法固定.json', self.technique)
        self.request = {'version': 1, 'trial': 109, 'fixed': True, 'stage': 'first2', 'clock_model': VERIFY.CLOCK, 'quiet_seconds': 1200, 'quote_max_age_seconds': 0,
                        'technique_fixed': technique_ref, 'manifest': self.manifest, 'corpus': self.corpus, 'source_completion': self.completion,
                        'scenes': self.scenes[:2], 'output_dir': str(self.root / '市場out')}

    def put(self, name: str, value: dict) -> dict:
        """
        機能: 人工小JSONを保存して参照を返す。
        引数: self (MetadataTests)、name (str)、value (dict) は検査器・名前・値。
        返り値: dict は絶対path/SHA。
        """
        path = self.root / name
        path.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
        return {'path': str(path), 'sha256': VERIFY.digest(path)}

    def check(self) -> dict:
        """
        機能: CSV/Recordのopenを禁止して照合関数を呼ぶ。
        引数: self (MetadataTests) は人工条件の所有者。
        返り値: dict はmetadata照合結果。
        """
        ref = self.put('要求.json', self.request)
        original = Path.open

        def guard(path, *args, **kwargs):
            """
            機能: 市場本文相当の人工ファイルを開いた場合に検査を失敗させる。
            引数: path (Path)、args/kwargs は標準open引数。
            返り値: file は市場本文以外に限定したopen結果。
            """
            if path.suffix in ('.csv', '.gz', '.jsonl'):
                raise AssertionError('本文を開いた:' + str(path))
            return original(path, *args, **kwargs)

        with patch.object(Path, 'open', guard):
            return VERIFY.validate(ref, self.root / '照合結果.json')

    def test_success_without_market_body(self) -> None:
        """
        機能: 正しい先頭2場のmetadata認証と非起動を確認する。
        引数: self (MetadataTests) は人工検査器。
        返り値: None。
        """
        result = self.check()
        self.assertTrue(result['成功'])
        self.assertEqual(len(result['csv_stat']), 2)
        self.assertEqual(result['CSV本文読込'], 0)
        self.assertEqual(result['Observer起動'], 0)
        self.assertFalse(Path(self.request['output_dir']).exists())

    def test_three_ref_replacement(self) -> None:
        """
        機能: 個別に認証可能な別のSource三参照への差替えを拒否する。
        引数: self (MetadataTests) は人工検査器。
        返り値: None。
        """
        for field in ('manifest', 'corpus', 'source_completion'):
            with self.subTest(field=field):
                original = self.request[field]
                self.request[field] = self.put('差替え_' + field + '.json', {'別': True})
                with self.assertRaisesRegex(ValueError, '三参照差'):
                    self.check()
                self.request[field] = original

    def test_scene_order_and_size(self) -> None:
        """
        機能: 順序・CSV参照size・実物stat size差を拒否する。
        引数: self (MetadataTests) は人工検査器。
        返り値: None。
        """
        self.request['scenes'] = list(reversed(self.request['scenes']))
        with self.assertRaisesRegex(ValueError, '順差'):
            self.check()
        self.request['scenes'] = self.scenes[:2]
        self.request['scenes'][0]['candle_csv']['bytes'] += 1
        with self.assertRaisesRegex(ValueError, 'size差'):
            self.check()
        self.request['scenes'][0]['candle_csv']['bytes'] -= 1
        Path(self.scenes[0]['candle_csv']['path']).write_bytes('サイズ変更'.encode('utf-8'))
        with self.assertRaisesRegex(ValueError, 'stat size差'):
            self.check()

    def test_existing_or_nested_output(self) -> None:
        """
        機能: 市場outの既存と照合結果の市場out内作成を拒否する。
        引数: self (MetadataTests) は人工検査器。
        返り値: None。
        """
        Path(self.request['output_dir']).mkdir()
        with self.assertRaisesRegex(ValueError, '未作成'):
            self.check()
        Path(self.request['output_dir']).rmdir()
        ref = self.put('要求.json', self.request)
        with self.assertRaisesRegex(ValueError, '市場頻度out内'):
            VERIFY.validate(ref, Path(self.request['output_dir']) / '照合.json')

    def test_fixed_code_stop_and_binary(self) -> None:
        """
        機能: 自己コード欠落・stop/exe不一致・clock変更を拒否する。
        引数: self (MetadataTests) は人工検査器。
        返り値: None。
        """
        original = dict(self.technique)
        self.technique['code_sha256'] = {}
        self.request['technique_fixed'] = self.put('技法固定.json', self.technique)
        with self.assertRaisesRegex(ValueError, 'コード指紋'):
            self.check()
        self.technique = dict(original)
        self.technique['observer_stop'] = self.put('別停止.json', {'成功': True, '実行物': self.binary['path'], '実行物SHA256': 'b' * 64})
        self.request['technique_fixed'] = self.put('技法固定.json', self.technique)
        with self.assertRaisesRegex(ValueError, '実行物と人工停止'):
            self.check()
        self.technique = dict(original)
        self.request['technique_fixed'] = self.put('技法固定.json', self.technique)
        self.request['quote_max_age_seconds'] = 90
        with self.assertRaisesRegex(ValueError, 'quote0'):
            self.check()

    def test_full70_requires_same_first2(self) -> None:
        """
        機能: 全70には同じ技法固定・入力・clockの成功先頭2場を要求する。
        引数: self (MetadataTests) は人工検査器。
        返り値: None。
        """
        self.request['stage'] = 'full70'
        self.request['scenes'] = self.scenes
        with self.assertRaisesRegex(ValueError, '先頭2場成功'):
            self.check()
        prior = {'version': 1, 'trial': 109, 'stage': 'first2', 'success': True, 'unchanged': True,
                 'financial_executed': False, 'participation_calculated': False,
                 'technique_fixed': self.request['technique_fixed'], 'manifest': self.manifest, 'corpus': self.corpus, 'source_completion': self.completion,
                 'config': {'clock_model': VERIFY.CLOCK, 'quiet_seconds': 1200, 'quote_max_age_seconds': 0}, 'results': [{'session': row['session']} for row in self.scenes[:2]]}
        self.request['first2_completion'] = self.put('先頭2場完成.json', prior)
        self.assertEqual(len(self.check()['csv_stat']), 70)
        prior['manifest'] = self.put('別manifest.json', {'別': True})
        self.request['first2_completion'] = self.put('先頭2場完成.json', prior)
        with self.assertRaisesRegex(ValueError, 'first2と全70の参照差'):
            self.check()

    def test_relative_manifest_matches_root_builder(self) -> None:
        """
        機能: source_root＋相対CSVをRoot生成器と同じ絶対要求へ結ぶ。
        引数: self (MetadataTests) は本文を開かない人工検査器。
        返り値: None。不正相対参照/Traversal/別rootも拒否する。
        """
        manifest = json.loads(Path(self.manifest['path']).read_text(encoding='utf-8'))
        for scene in manifest['sessions']:
            file = scene['files']['NK225_candle_300']
            file['path'] = str(Path(file['path']).relative_to(self.root))
        self.manifest = self.put('manifest.json', manifest)
        corpus = json.loads(Path(self.corpus['path']).read_text(encoding='utf-8'))
        corpus['input_manifest'] = self.manifest
        self.corpus = self.put('corpus.json', corpus)
        self.technique['source_manifest'] = self.manifest
        self.technique['source_corpus'] = self.corpus
        self.request.update(manifest=self.manifest, corpus=self.corpus, technique_fixed=self.put('技法固定.json', self.technique))
        self.assertTrue(self.check()['成功'])
        for name in ('../別.csv', r'..\別.csv', '', r'C:別.csv', r'\別.csv', str(self.root.parent / '別root.csv')):
            with self.subTest(name=name), self.assertRaises(ValueError):
                VERIFY.normalize_csv(str(self.root), name)
        with self.assertRaises(ValueError):
            VERIFY.normalize_csv('相対root', '子.csv')


if __name__ == '__main__':
    unittest.main(verbosity=2)
