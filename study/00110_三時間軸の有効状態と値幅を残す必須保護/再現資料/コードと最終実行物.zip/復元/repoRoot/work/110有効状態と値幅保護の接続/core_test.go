package threeguardruntime110

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"testing"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	finance "github.com/masayoshi4649/SessionTradeExecuter/miniprofit110"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

type artificial108 struct {
	Scope   string          `json:"scope"`
	Tape    tape.Tape       `json:"tape"`
	Header  stream.Header   `json:"header"`
	Records []stream.Record `json:"records"`
	Output  struct {
		Contract string                     `json:"contract"`
		TapeSHA  string                     `json:"tape_canonical_sha256"`
		Books    map[string]json.RawMessage `json:"books"`
		Width    map[string]json.RawMessage `json:"width_audits"`
		Clock    map[string]json.RawMessage `json:"clock_audits"`
		Early    map[string]json.RawMessage `json:"early_audits"`
	} `json:"output"`
}

// loadArtificial は停止108の手製公表/Source/保存12冊だけを読みます。
//
// 引数: t(*testing.T)、side(int)は検査器と買売符号です。
// 返り値: artificial108/Control/PublicationInputは人工入力で、市場Bodyを読みません。
func loadArtificial(t *testing.T, side int) (artificial108, Control, PublicationInput) {
	t.Helper()
	path, err := filepath.Abs(filepath.Join("..", "108静観短縮の市場接続準備", "人工_停止版", fmt.Sprintf("方向%d.json", side)))
	if err != nil {
		t.Fatal(err)
	}
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	sum := sha256.Sum256(data)
	f := artificial108{}
	if err = json.Unmarshal(data, &f); err != nil {
		t.Fatal(err)
	}
	control := Control{Kind: "provided_old108_q20", HistoryClass: "artificial", ReferencePath: path, ReferenceSHA: hex.EncodeToString(sum[:]), Session: f.Tape.Session, Contract: f.Output.Contract, TapeSHA: f.Output.TapeSHA, QuietSeconds: 1200, Books: f.Output.Books, WidthAudits: f.Output.Width, ClockAudits: f.Output.Clock, EarlyAudits: f.Output.Early}
	children := []frame.ChildBar{}
	for start := f.Tape.Session.Start; start+300 <= f.Tape.Session.End; start += 300 {
		quotes := []tape.ScalarQuote{}
		for _, e := range f.Tape.Events {
			if e.Kind == "quote" && e.Quote != nil && e.At >= start && e.At < start+300 {
				quotes = append(quotes, *e.Quote)
			}
		}
		if len(quotes) == 0 {
			continue
		}
		o := frame.OHLC{Open: quotes[0].Last, High: quotes[0].Last, Low: quotes[0].Last, Close: quotes[len(quotes)-1].Last}
		for _, q := range quotes {
			if q.Last > o.High {
				o.High = q.Last
			}
			if q.Last < o.Low {
				o.Low = q.Last
			}
		}
		children = append(children, frame.ChildBar{Start: start, End: start + 300, OHLC: o, Volume: 100, Closed: true, VolumeKnown: true, Input: frame.FileRef{Path: "人工108足.csv", SHA256: strings.Repeat("a", 64), Bytes: 123}, Row: uint64(len(children) + 2)})
	}
	pub := PublicationInput{Session: SourceSession(f.Tape.Session, f.Output.Contract, f.Header.Ending.Legacy.ObservedClock), Children: children}
	return f, control, pub
}

// cloneJSON は破損検査だけの独立値を作ります。
//
// 引数: t(*testing.T)、value(T)は検査器と人工公開値です。
// 返り値: Tは元を変更しない独立値です。
func cloneJSON[T any](t *testing.T, value T) T {
	t.Helper()
	raw, e := json.Marshal(value)
	if e != nil {
		t.Fatal(e)
	}
	var out T
	if e = json.Unmarshal(raw, &out); e != nil {
		t.Fatal(e)
	}
	return out
}

// TestSavedAndFreshReference は両分岐のG0四対一致と新保護/入口の配送を確認します。
//
// 引数: t(*testing.T)は停止人工買売の検査器です。
// 返り値: ありません。この短いcold場ではE1未知を0成功へ読み替えません。
func TestSavedAndFreshReference(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, mode := range []string{"saved", "fresh"} {
			t.Run(fmt.Sprintf("%d_%s", side, mode), func(t *testing.T) {
				f, control, pub := loadArtificial(t, side)
				if mode == "fresh" {
					var e error
					control, e = FreshControl(f.Tape, f.Output.Contract)
					if e != nil {
						t.Fatal(e)
					}
				}
				c, e := NewCore(f.Tape, f.Output.Contract, "停止108人工36Mainと真EOF公開器", control, pub)
				if e != nil {
					t.Fatal(e)
				}
				if _, e = c.NextSeed(); e == nil {
					t.Fatal("完結前種取得")
				}
				r, e := Run(c, f.Records, f.Header)
				if e != nil {
					t.Fatal(e)
				}
				if !r.Complete || len(r.Books) != 36 || len(r.WidthAudits) != 12 || len(r.ClockAudits) != 36 || len(r.CompositeAudits) != 36 || len(r.EntryAudits) != 36 || !r.Baseline.All || r.Baseline.Comparisons != 4 || !r.TapeUnchanged || !r.PublicationAudit.InputsUnchanged || !r.PublicationAudit.PolicyEOFRedacted || r.ProtectionAudit.VKnown == 0 || r.ProtectionAudit.Resets != 1 {
					t.Fatal("Main/対照/公表/不変/保護窓の差")
				}
				if mode == "fresh" && len(r.ShadowBooks) != 4 || mode == "saved" && len(r.ShadowBooks) != 0 {
					t.Fatal("Mainへshadowを混入")
				}
				for _, cfg := range r.Configs {
					k := Key(cfg)
					b := r.Books[k]
					if !b.Complete || b.Totals.OpenBuy+b.Totals.OpenSell+b.Totals.PendingBuy+b.Totals.PendingSell != 0 {
						t.Fatal("完結/残量差")
					}
					if cfg.EntryPolicy == finance.EntryE0 && b.Totals.EntryQuantity == 0 {
						t.Fatal("人工E0が空疎")
					}
					if cfg.EntryPolicy == finance.EntryE2 && (r.EntryAudits[k].Calls != r.Counts.Grids || r.EntryAudits[k].Candidates == 0 || r.EntryAudits[k].Unknown == 0) {
						t.Fatal("E1の全枠・候補・未知が未配送")
					}
				}
				seed, e := c.NextSeed()
				if e != nil || seed.Info() != r.PublicationAudit.EndSeed {
					t.Fatal("完結種/監査差")
				}
				bank, e := frame.BeginSession(pub.Session, pub.Children, nil)
				if e != nil {
					t.Fatal(e)
				}
				if _, e = bank.AdvanceObserved(pub.Session.EOF, 1); e != nil {
					t.Fatal(e)
				}
				batchSeed, _, e := bank.Seal()
				if e != nil || batchSeed.Info() != seed.Info() {
					t.Fatal("一括EOFと逐次Recordで数値種が不一致")
				}
				if _, e = c.Finish(f.Header); e == nil {
					t.Fatal("重複Finishを許可")
				}
			})
		}
	}
}

// TestReferenceAndRecordRejections は旧Feedの出典・順序と保存対照を破損で検査します。
//
// 引数: t(*testing.T)は手製公開列の検査器です。
// 返り値: ありません。市場価格を使いません。
func TestReferenceAndRecordRejections(t *testing.T) {
	for _, name := range []string{"quiet", "contract", "missing", "clock", "fakefresh"} {
		t.Run(name, func(t *testing.T) {
			f, control, pub := loadArtificial(t, 1)
			switch name {
			case "quiet":
				control.QuietSeconds = 1800
			case "contract":
				control.Contract = "別"
			case "missing":
				delete(control.Books, "Q0_C0_D0")
			case "clock":
				control.ClockAudits["Q0_C0_D0"] = json.RawMessage(`{}`)
			case "fakefresh":
				control.Kind = "fresh_unseen"
			}
			if _, e := NewCore(f.Tape, f.Output.Contract, "不正対照", control, pub); e == nil {
				t.Fatal("不正対照を受理")
			}
		})
	}
	for _, name := range []string{"ordinal", "header", "scalar", "phase", "last0"} {
		t.Run(name, func(t *testing.T) {
			f, control, pub := loadArtificial(t, 1)
			records := cloneJSON(t, f.Records)
			header := f.Header
			switch name {
			case "ordinal":
				records[0].Ordinal++
			case "header":
				header.RawBoards++
			case "scalar":
				for i := range records {
					if records[i].Scalar != nil {
						records[i].Scalar.Last++
						break
					}
				}
			case "phase":
				records[0], records[1] = records[1], records[0]
			case "last0":
				for i := range records {
					if records[i].Kind == "reset" {
						records[i].Reset.Source.Last = 999
						break
					}
				}
			}
			c, e := NewCore(f.Tape, f.Output.Contract, "不正Record", control, pub)
			if e != nil {
				t.Fatal(e)
			}
			if _, e = Run(c, records, header); e == nil {
				t.Fatal("不正Record/Headerを受理")
			}
		})
	}
}

// TestUnknownFieldsAndMutation は非対照Rawの未知欄を保持し、参照/子の変更を拒否します。
//
// 引数: t(*testing.T)は人工入力の検査器です。
// 返り値: ありません。
func TestUnknownFieldsAndMutation(t *testing.T) {
	f, control, pub := loadArtificial(t, 1)
	var obj map[string]json.RawMessage
	if e := json.Unmarshal(control.Books["Q1_C0_D0"], &obj); e != nil {
		t.Fatal(e)
	}
	obj["将来の未知field"] = json.RawMessage(`{"値":123}`)
	control.Books["Q1_C0_D0"], _ = json.Marshal(obj)
	want, _ := digestValue(control.Books["Q1_C0_D0"])
	c, e := NewCore(f.Tape, f.Output.Contract, "未知欄保持", control, pub)
	if e != nil {
		t.Fatal(e)
	}
	r, e := Run(c, f.Records, f.Header)
	if e != nil || r.PriorReference.BookSHA["Q1_C0_D0"] != want {
		t.Fatal("未知欄の指紋保持失敗", e)
	}
	for _, name := range []string{"reference", "children"} {
		t.Run(name, func(t *testing.T) {
			f, control, pub := loadArtificial(t, 1)
			c, e := NewCore(f.Tape, f.Output.Contract, "実行中変更拒否", control, pub)
			if e != nil {
				t.Fatal(e)
			}
			if name == "reference" {
				control.Books["Q1_C0_D0"] = json.RawMessage(`{}`)
			} else {
				pub.Children[0].OHLC.Close++
			}
			if _, e = Run(c, f.Records, f.Header); e == nil {
				t.Fatal("実行中変更を成功へ補完")
			}
		})
	}
}
