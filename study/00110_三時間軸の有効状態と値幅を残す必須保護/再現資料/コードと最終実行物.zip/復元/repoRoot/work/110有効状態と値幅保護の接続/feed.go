package threeguardruntime110

import (
	"fmt"
	"math"
	"reflect"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	finance "github.com/masayoshi4649/SessionTradeExecuter/miniprofit110"
	oldfinance "github.com/masayoshi4649/SessionTradeExecuter/miniquietlength108"
	delivery "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
)

// finite は時計/価格の有限性を確認します。
//
// 引数: values(...float64)は公開値。返り値: boolは有限値だけなら真です。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// resetKey は同じ不良NK原行のresetとraw_clockを一意に結びます。
//
// 引数: r(stream.Record)はTrigger付き制御値。返り値: stringは市場/物理行/全連番/価格時計です。
func resetKey(r stream.Record) string {
	return fmt.Sprintf("%s/%d/%d/%.17g", r.Trigger.Market, r.Trigger.PhysicalLine, r.Trigger.AllIndex, r.Trigger.Time)
}

// raw はSourceに渡さないTOPIX/Last0と正NKの出典を区別します。
//
// 引数: r(stream.Record)は全board由来raw値。返り値: errorはIndex/Line/市場/Last0結合の不一致です。
func (c *Core) raw(r stream.Record) error {
	id := r.Trigger
	if id == nil || (id.Market != "NK225" && id.Market != "TOPIX") || id.Time != r.At || id.Time < c.input.Session.Start || id.Time >= c.input.Session.End || id.PhysicalLine <= 0 || id.AllIndex != c.rawAll[id.Market] || id.MergeOrdinal != c.counts.RawBoards+1 {
		return fmt.Errorf("全boardの原行/merge/AllIndex差")
	}
	if id.Market == "NK225" {
		q := r.RawQuote
		if q == nil || q.Time != id.Time || q.Line != id.PhysicalLine || q.Index != id.AllIndex || !finite(q.Time, q.Last, q.Bid, q.Ask) {
			return fmt.Errorf("Chart全NK原行出典差")
		}
		if r.Kind == "quote" {
			s := r.Scalar
			if s == nil || id.FeaturesIndex == nil || *id.FeaturesIndex != s.Index || !q.Valid || q.Last <= 0 || s.Time != r.At || s.SourceLine != id.PhysicalLine || s.Last != q.Last || s.Bid != q.Bid || s.Ask != q.Ask {
				return fmt.Errorf("ScalarとChart原行出典差")
			}
		} else {
			reset, ok := c.pendingReset[resetKey(r)]
			if r.Scalar != nil || q.Valid || q.Last > 0 || id.FeaturesIndex != nil || !ok || !reflect.DeepEqual(reset, *q) {
				return fmt.Errorf("Last0 reset欠落/偽Current")
			}
			delete(c.pendingReset, resetKey(r))
		}
	} else if r.Kind != "raw_clock" || r.Scalar != nil || r.RawQuote != nil {
		return fmt.Errorf("TOPIXへ金融Scalar混入")
	}
	c.rawAll[id.Market]++
	c.counts.RawBoards++
	return nil
}

// Feed は保存Streamの一件を再計算/出典検査後に同じSource位相へ配送します。
//
// 引数: r(stream.Record)は停止dd34 producerの逐次値。
// 返り値: errorは破損又は金融不成立です。全原行BookをJSON複写しません。
func (c *Core) Feed(r stream.Record) error {
	if c == nil || c.finished {
		return fmt.Errorf("Core未初期化/終了後")
	}
	if c.failed != nil {
		return c.failed
	}
	if r.Ordinal != c.counts.Records+1 || !finite(r.At) || r.At < c.input.Session.Start || (c.haveAt && r.At < c.lastAt) {
		return c.fail(fmt.Errorf("Stream ordinal/時計差"))
	}
	if c.eof && !(r.Kind == "force" && r.AfterEOF) {
		return c.fail(fmt.Errorf("EOF Force後に新公表/原行を補完"))
	}
	if c.haveAt && r.At == c.lastAt && c.rawAt && (r.Kind == "publication" || r.Kind == "force" || r.Kind == "grid") {
		return c.fail(fmt.Errorf("同時計raw後へtimer/gridを戻した"))
	}
	if !c.haveAt || r.At != c.lastAt {
		c.rawAt = false
		c.preRank = -1
	}
	pre := -1
	switch r.Kind {
	case "publication":
		pre = 0
	case "force":
		pre = 1
	case "grid":
		pre = 2
	}
	if pre >= 0 {
		if pre < c.preRank {
			return c.fail(fmt.Errorf("同時計pre-raw公表/Force/grid順差"))
		}
		c.preRank = pre
	}
	if c.cursor < len(c.input.Events) {
		next := c.input.Events[c.cursor]
		if r.At > next.At {
			return c.fail(fmt.Errorf("Source次eventを飛越:%d", next.Ordinal))
		}
		if r.At == next.At && (r.Kind == "raw_clock" || r.Kind == "reset") && (next.Kind == "grid" || next.Kind == "force") {
			return c.fail(fmt.Errorf("raw制御が元timer/gridへ先行"))
		}
	}
	if r.Kind != "publication" && (r.Publication != nil || r.Delivery != nil) || r.Kind != "grid" && r.Grid != nil || r.Kind != "force" && (r.Force != nil || r.AfterEOF) || r.Kind != "quote" && r.Scalar != nil || r.Kind != "reset" && r.Reset != nil || (r.Kind != "quote" && r.Kind != "raw_clock") && r.RawQuote != nil {
		return c.fail(fmt.Errorf("Stream役割へ別payload混入"))
	}
	if r.AfterEOF {
		if r.Trigger != nil || r.Force == nil {
			return c.fail(fmt.Errorf("EOF Forceの架空Trigger"))
		}
		c.eof = true
		c.afterEOF++
	} else if r.Trigger == nil || r.Trigger.Time < r.At || !finite(r.Trigger.Time) {
		return c.fail(fmt.Errorf("配送を進めた原行clockがない"))
	}
	if err := c.advancePublication(r); err != nil {
		return c.fail(err)
	}
	var err error
	switch r.Kind {
	case "publication":
		if r.Publication == nil || r.Publication.At != r.At || r.Publication.Snapshot.Legacy.Scene.ID != c.input.Session.ID || r.Publication.Snapshot.Legacy.Scene.Contract != c.contract || r.Publication.Snapshot.Legacy.Scene.Start != c.input.Session.Start {
			return c.fail(fmt.Errorf("公表の場/限月/時計差"))
		}
		if r.Publication.Three {
			if r.Delivery == nil {
				return c.fail(fmt.Errorf("新3分Delivery欠落"))
			}
			d, e := c.pipeline.Feed(*r.Publication, r.At)
			if e != nil {
				return c.fail(e)
			}
			if !sameJSON(d, *r.Delivery) {
				return c.fail(fmt.Errorf("公表C/M/P全field/出典SHA差"))
			}
			if e = c.deliverProtection(d); e != nil {
				return c.fail(e)
			}
			c.counts.Three++
			c.publicStats.New3++
			if d.Result.C.Known {
				c.publicStats.CKnown++
				if *d.Result.C.Passed {
					c.publicStats.CPass++
				}
			}
			for _, x := range []struct {
				role   delivery.Role
				counts *PublicRoleCounts
			}{{d.Result.Buy, &c.publicStats.Buy}, {d.Result.Sell, &c.publicStats.Sell}} {
				if x.role.M.Known {
					x.counts.MKnown++
					if *x.role.M.Passed {
						x.counts.MPass++
					}
				}
				if x.role.P.Known {
					x.counts.PKnown++
					if *x.role.P.Passed {
						x.counts.PPass++
					}
				}
			}
		} else if r.Delivery != nil {
			return c.fail(fmt.Errorf("15分だけの公表を新3分へ偽装"))
		}
		c.counts.Publications++
	case "reset":
		id := r.Trigger
		q := r.Reset
		_, duplicate := c.pendingReset[resetKey(r)]
		if q == nil || id.Market != "NK225" || id.FeaturesIndex != nil || q.Source.Valid || q.Source.Last > 0 || q.Source.Time != r.At || q.Source.Line != id.PhysicalLine || q.Source.Index != id.AllIndex || id.AllIndex != c.rawAll[id.Market] || id.MergeOrdinal != c.counts.RawBoards+1 || duplicate {
			return c.fail(fmt.Errorf("Last0 resetの原行出典差"))
		}
		if err = c.resetProtection(r.At, q.Reason); err != nil {
			return c.fail(err)
		}
		c.pendingReset[resetKey(r)] = q.Source
		c.counts.Resets++
		c.rawAt = true
	case "quote":
		if err = c.raw(r); err == nil {
			err = c.source(r)
		}
		c.rawAt = true
	case "raw_clock":
		err = c.raw(r)
		c.rawAt = true
	case "force", "grid":
		err = c.source(r)
	default:
		err = fmt.Errorf("未定義Stream種別:%s", r.Kind)
	}
	if err != nil {
		return c.fail(err)
	}
	c.counts.Records++
	c.lastAt, c.haveAt = r.At, true
	return nil
}

// Finish は全Source消費/Header整合、Main36完結と保存12参照又は独立shadow4を検査します。
//
// 引数: h(stream.Header)は逐次producerの成功後Header。
// 返り値: Result/errorは全金融と由来を区別した対照又は不成立です。新規I/Oは行いません。
func (c *Core) Finish(h stream.Header) (Result, error) {
	if c == nil {
		return Result{}, fmt.Errorf("Core未初期化")
	}
	out := Result{Version: 1, Trial: 110, Scope: c.scope, Session: c.input.Session, Contract: c.contract, Configs: c.configs, Books: map[string]finance.ActualResult{}, WidthAudits: map[string]finance.WidthBookAudit{}, ClockAudits: map[string]finance.ClockBookAudit{}, CompositeAudits: map[string]finance.CompositeAudit{}, EntryAudits: map[string]EntryAudit{}, ShadowBooks: map[string]oldfinance.ActualResult{}, ShadowWidthAudits: map[string]oldfinance.WidthBookAudit{}, ShadowClockAudits: map[string]oldfinance.ClockBookAudit{}, Counts: c.counts, GridTimes: append([]float64{}, c.grids...), SkippedGrids: append([]float64{}, h.SkippedGrids...), TapeSHA: c.tapeSHA, CMPRecomputed: true, EntryCandleRecomputed: true}
	out.PublicDiagnostics = c.publicStats
	out.PublicDiagnostics.NumericSeedCarried = h.Ending.Legacy.CarriedNumericSeed
	if c == nil || c.finished {
		return out, fmt.Errorf("Core未初期化/終了後")
	}
	c.finished = true
	if c.failed != nil {
		return out, c.failed
	}
	if !h.Success || h.Version != 1 || !h.LegacyAllStateMatch || !h.ForceClockOnly || h.SourceReexecuted || h.FinancialExecuted || h.MarketExecuted || h.Scene.ID != c.input.Session.ID || h.Scene.Contract != c.contract || h.Scene.Start != c.input.Session.Start || c.cursor != len(c.input.Events) || len(c.pendingReset) != 0 || h.Records != c.counts.Records || h.PositiveNK != c.counts.Quotes || h.Grids != c.counts.Grids || h.Forces != c.counts.Forces || h.Publications != c.counts.Publications || h.ThreePublications != c.counts.Three || h.RawBoards != c.counts.RawBoards || h.Resets != c.counts.Resets || h.AfterEOFForces != c.afterEOF {
		return out, fmt.Errorf("producer/Header/Source完全消費差")
	}
	for i, b := range c.actors {
		r, e := b.Finish()
		if e != nil {
			return out, e
		}
		if !r.Complete || !r.Finished || r.Failure != "" || r.Totals.OpenBuy+r.Totals.OpenSell+r.Totals.PendingBuy+r.Totals.PendingSell != 0 {
			return out, fmt.Errorf("Main36会計の完結/残量差")
		}
		k := Key(c.configs[i])
		out.Books[k] = r
		if c.configs[i].Policy == finance.ProtectG0 {
			out.WidthAudits[k] = b.WidthAudit()
		}
		out.ClockAudits[k] = b.ClockAudit()
		out.CompositeAudits[k] = b.CompositeAudit()
		out.EntryAudits[k] = c.entryAudits[i]

	}
	for i, b := range c.shadows {
		r, e := b.Finish()
		if e != nil {
			return out, e
		}
		if !r.Complete || !r.Finished || r.Failure != "" || r.Totals.OpenBuy+r.Totals.OpenSell+r.Totals.PendingBuy+r.Totals.PendingSell != 0 {
			return out, fmt.Errorf("検査shadow4の未完結/残量差")
		}
		base := fmt.Sprintf("Q0_C%d_D%d", []int{0, 5}[i/2], i%2)
		out.ShadowBooks[base] = r
		out.ShadowWidthAudits[base] = b.WidthAudit()
		out.ShadowClockAudits[base] = b.ClockAudit()
	}
	after, e := digestValue(c.input)
	if e != nil {
		return out, e
	}
	out.TapeUnchanged = after == c.tapeSHA
	if !out.TapeUnchanged || len(out.Books) != 36 || len(out.WidthAudits) != 12 || len(out.ClockAudits) != 36 || len(out.CompositeAudits) != 36 || len(out.EntryAudits) != 36 || c.control.Kind == "fresh_unseen" && len(out.ShadowBooks) != 4 || c.control.Kind != "fresh_unseen" && len(out.ShadowBooks) != 0 {
		return out, fmt.Errorf("固定Source入力変更/Main36/G0幅8/検査shadow差")
	}
	priorAfter, e := digestValue([]any{c.control.Books, c.control.WidthAudits, c.control.ClockAudits, c.control.EarlyAudits})
	if e != nil || priorAfter != c.priorDigest {
		return out, fmt.Errorf("旧108保存参照の入力が変更された")
	}
	out.PriorReference = c.priorProof
	// ----------------------------------------
	// 数値種は真の観測EOFと完成公表だけに結び、政策には未来EOFを渡しません。
	if h.Ending.Legacy.ObservedClock != c.pubInput.Session.EOF {
		return out, fmt.Errorf("新公開器EOFと旧Header観測末尾差")
	}
	seed, last, e := c.pubBank.Seal()
	if e != nil {
		return out, e
	}
	if last.ReplayObservedAt != c.pubInput.Session.EOF {
		return out, fmt.Errorf("新公開器が実EOFまで進んでいない")
	}
	c.pubAudit.EndSeed, c.pubAudit.LastSnapshot = seed.Info(), last
	childrenAfter, e := digestValue(c.pubInput.Children)
	if e != nil || childrenAfter != c.pubAudit.ChildrenSHA {
		return out, fmt.Errorf("新5分子入力が変更された")
	}
	if c.pubInput.Seed != nil && c.pubInput.Seed.Info() != *c.pubAudit.InputSeed {
		return out, fmt.Errorf("新公開器の入力数値種が変更された")
	}
	c.pubAudit.InputsUnchanged = true
	out.PublicationAudit = c.pubAudit
	out.ProtectionAudit = c.protectAudit
	if e = c.compareBaseline(&out); e != nil {
		return out, e
	}
	c.nextSeed, c.complete = seed, true
	out.Complete = true
	return out, nil
}

// Run は小型人工向けに既に固定されたRecord列を同じSinkへ流します。
//
// 引数: c(*Core)、records([]stream.Record)、h(Header)は新Coreと明示Stream。
// 返り値: Result/errorは逐次APIと同じ値です。市場ではFeedを直接Sinkへ接続します。
func Run(c *Core, records []stream.Record, h stream.Header) (Result, error) {
	for _, r := range records {
		if e := c.Feed(r); e != nil {
			return Result{}, e
		}
	}
	return c.Finish(h)
}

// SourceForces は通知を形成せず固定TapeのForce時計とordinalだけを射影します。
//
// 引数: input(tape.Tape)は固定Source列。返り値: []stream.Forceはproducerへ渡す元参照です。
func SourceForces(input tape.Tape) []stream.Force {
	out := []stream.Force{}
	for _, e := range input.Events {
		if e.Kind == "force" {
			out = append(out, stream.Force{At: e.At, TapeOrdinal: e.Ordinal})
		}
	}
	return out
}
