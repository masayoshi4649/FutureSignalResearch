package threeguardruntime110

import (
	"fmt"
	"math"
	"sort"
	"strings"
	"testing"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	oldtype "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	finance "github.com/masayoshi4649/SessionTradeExecuter/miniprofit110"
	entry "github.com/masayoshi4649/SessionTradeExecuter/multientry110"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

// reversalPublisher110 は停止純入口のpublisher_testと同じR手製OHLCから実指標を形成します。
//
// 引数: t(*testing.T)、side(int)は検査器と鏡像方向です。
// 返り値: PublicationInputは下降助走→失敗→復帰→突破の人工価格列です。
// 指標・Assessmentを直書きせず、停止公開器で前場種を実形成します。
func reversalPublisher110(t *testing.T, side int) PublicationInput {
	t.Helper()
	start := 1800000000.0
	prior := frame.Session{ID: "人工R助走", Contract: "人工限月", Start: start, End: start + 241*300, EOF: start + 240*300 + 60}
	children := make([]frame.ChildBar, 240)
	for i := range children {
		price := 10000 - float64(i)*2
		o := frame.OHLC{Open: price - .5, High: price + 2, Low: price - 2, Close: price}
		if side < 0 {
			o = frame.OHLC{Open: 30000 - o.Open, High: 30000 - o.Low, Low: 30000 - o.High, Close: 30000 - o.Close}
		}
		children[i] = frame.ChildBar{Start: start + float64(i)*300, End: start + float64(i+1)*300, OHLC: o, Volume: 100, Closed: true, VolumeKnown: true,
			Input: frame.FileRef{Path: "人工R助走.csv", SHA256: strings.Repeat("a", 64), Bytes: 12345}, Row: uint64(i + 2)}
	}
	bank, err := frame.BeginSession(prior, children, nil)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = bank.AdvanceObserved(prior.EOF, 1); err != nil {
		t.Fatal(err)
	}
	seed, _, err := bank.Seal()
	if err != nil {
		t.Fatal(err)
	}
	// ----------------------------------------
	// 110純入口publisherPricesVariant(reversal=true)の公開OHLCを再用します。
	base := 10000 - 239*2.0
	prices := []frame.OHLC{
		{Open: 5, High: 7, Low: -2, Close: 0}, {Open: 0, High: 1, Low: -7, Close: -5},
		{Open: -5, High: 9, Low: -5, Close: 0}, {Open: 0, High: 8, Low: -2, Close: -1},
		{Open: -1, High: 5, Low: -4, Close: -3}, {Open: -3, High: 3, Low: -4, Close: -2},
		{Open: -2, High: 0, Low: -8, Close: -7}, {Open: -7, High: 2, Low: -7, Close: 0},
		{Open: 0, High: 12, Low: -1, Close: 10}, {Open: 10, High: 13, Low: 10, Close: 11},
		{Open: 11, High: 14, Low: 10, Close: 12}, {Open: 12, High: 15, Low: 11, Close: 13},
	}
	scene := frame.Session{ID: "人工R取得_Day", Contract: prior.Contract, Start: prior.End + 3600, End: prior.End + 3600 + 13*300, EOF: prior.End + 3600 + 12*300 + 60}
	current := make([]frame.ChildBar, len(prices))
	for i, o := range prices {
		o.Open, o.High, o.Low, o.Close = o.Open+base, o.High+base, o.Low+base, o.Close+base
		if side < 0 {
			o = frame.OHLC{Open: 30000 - o.Open, High: 30000 - o.Low, Low: 30000 - o.High, Close: 30000 - o.Close}
		}
		current[i] = frame.ChildBar{Start: scene.Start + float64(i)*300, End: scene.Start + float64(i+1)*300, OHLC: o, Volume: 100, Closed: true, VolumeKnown: true,
			Input: frame.FileRef{Path: "人工R当場.csv", SHA256: strings.Repeat("b", 64), Bytes: 6789}, Row: uint64(i + 2)}
	}
	return PublicationInput{Session: scene, Children: current, Seed: &seed}
}

// reversalRequest110 は既存人工schedulerを再用し、R価格側の合法BBOと後続順行/戻りを作ります。
//
// 引数: t(*testing.T)、pub(*PublicationInput)、side(int)は人工入力です。
// 返り値: continuous.Requestは旧3/15公表も生産器が形成する二市場入力です。
func reversalRequest110(t *testing.T, pub *PublicationInput, side int) continuous.Request {
	t.Helper()
	child := pub.Children[10]
	r := syntheticRequest(t, pub, side)
	pub.Children[10] = child
	for i := range r.Rows {
		row := &r.Rows[i]
		if row.Board.Reference != "NK225" {
			continue
		}
		elapsed := row.Board.Time - r.Session.Start
		index := min(int(elapsed/300), len(pub.Children)-1)
		o := pub.Children[index].OHLC
		last := []float64{o.Open, o.High, o.Low, o.Close, o.Close}[int(elapsed/60)%5]
		last = 5 * math.Round(last/5)
		bid, ask := last-10, last
		if side < 0 {
			bid, ask = last, last+10
		}
		if elapsed >= 2999 && elapsed <= 3006 {
			bid, ask = 9525, 9535
			if side < 0 {
				bid, ask = 30000-ask, 30000-bid
			}
			move := 0.0
			if elapsed == 3002 {
				move = 70
			} else if elapsed == 3003 {
				move = 40
			} else if elapsed >= 3004 {
				move = 10
			}
			bid, ask = bid+float64(side)*move, ask+float64(side)*move
			last = ask
			if side < 0 {
				last = bid
			}
		}
		row.Board.Last, row.Board.Bid, row.Board.Ask = last, bid, ask
		if elapsed >= 3000 && elapsed < 3300 {
			p := &pub.Children[10].OHLC
			p.High, p.Low = math.Max(p.High, last), math.Min(p.Low, last)
		}
	}
	for i := range r.Candles {
		o := pub.Children[i].OHLC
		r.Candles[i].Candle.Open, r.Candles[i].Candle.High, r.Candles[i].Candle.Low, r.Candles[i].Candle.Close = o.Open, o.High, o.Low, o.Close
	}
	return r
}

// reversalTape110 は手製Sourceの出生だけをR確認前又は後の適格5分へ割り当てます。
//
// 引数: t(*testing.T)、r(continuous.Request)、side(int)、birthSecond(float64)は人工通知条件です。
// 返り値: tape.Tapeは一出生・次原行Source取得・Force返済を持ちます。自然Sourceの成功ではありません。
func reversalTape110(t *testing.T, r continuous.Request, side int, birthSecond float64) tape.Tape {
	t.Helper()
	events := []tape.TapeEvent{}
	_, _, err := continuous.BuildToSink(r, nil, func(record continuous.Record) error {
		if record.Kind == "row" {
			q := record.Row.Scalar
			events = append(events, tape.TapeEvent{Kind: "quote", At: q.Time, Quote: &q})
		} else if record.Kind == "control" && record.Control.Kind == "grid" {
			events = append(events, tape.TapeEvent{Kind: "grid", At: record.Control.At})
		}
		return nil
	})
	if err != nil {
		t.Fatal(err)
	}
	events = append(events, tape.TapeEvent{Kind: "force", At: r.Session.ForceClose})
	rank := map[string]int{"force": 0, "grid": 1, "quote": 2}
	sort.SliceStable(events, func(i, j int) bool {
		return events[i].At < events[j].At || events[i].At == events[j].At && rank[events[i].Kind] < rank[events[j].Kind]
	})
	source := newSource()
	for i := range events {
		event := &events[i]
		event.Ordinal = i + 1
		if event.Kind == "grid" {
			continue
		}
		var batch NativeBatch
		if event.Kind == "force" {
			batch = source.force(event.At)
			batch.Delta.SourceLine = source.last.SourceLine
		} else {
			news := []native.Signal{}
			if event.At == r.Session.Start+birthSecond {
				news = append(news, birth("人工R一出生", side, 6))
			}
			q := event.Quote
			batch = source.step(native.QuoteStamp{Time: q.Time, Index: q.Index, SourceLine: q.SourceLine, Last: q.Last, Bid: q.Bid, Ask: q.Ask, QuoteOK: q.QuoteOK}, news)
		}
		event.Methods, event.NonEmpty = []string{batch.Method}, []oldtype.NativeBatch{}
		if len(batch.Delta.Signals)+len(batch.Delta.Fills)+len(batch.Delta.Cancellations)+len(batch.Delta.Closes) > 0 {
			event.NonEmpty = append(event.NonEmpty, oldtype.NativeBatch{Method: batch.Method, Delta: batch.Delta})
		}
	}
	return tape.Tape{Version: 1, Scope: "実公開器R価格・手製Source。市場/自然Sourceなし", Session: r.Session, Capabilities: tape.Capabilities(), Events: events}
}

// TestReversal110FullPipeline は公開器→R局所転換→実fill/返済→Finishを両向きで通します。
//
// 引数: t(*testing.T)は市場未読の人工統合検査です。
// 返り値: ありません。入口の成功をモックで返さず、利益率の主張を行いません。
func TestReversal110FullPipeline(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, birthSecond := range []float64{2880, 1980} {
			t.Run(fmt.Sprintf("方向%d_出生%.0f", side, birthSecond), func(t *testing.T) {
				pub := reversalPublisher110(t, side)
				request := reversalRequest110(t, &pub, side)
				input := reversalTape110(t, request, side, birthSecond)
				records := []stream.Record{}
				header, _, err := stream.Build(request, nil, SourceForces(input), func(r stream.Record) error { records = append(records, r); return nil })
				if err != nil {
					t.Fatal(err)
				}
				control, err := FreshControl(input, pub.Session.Contract)
				if err != nil {
					t.Fatal(err)
				}
				core, err := NewCore(input, pub.Session.Contract, "R実公開器→純E2→実Actorの人工", control, pub)
				if err != nil {
					t.Fatal(err)
				}
				result, err := Run(core, records, header)
				if err != nil {
					t.Fatal(err)
				}
				if !result.Complete || !result.Baseline.All || result.Baseline.Comparisons != 4 || len(result.ShadowBooks) != 4 || !result.TapeUnchanged || !result.PublicationAudit.InputsUnchanged {
					t.Fatal("R人工の完結・旧四対照・入力不変が成立しない")
				}
				if result.PublicationAudit.Counts[300] == 0 || result.PublicationAudit.Counts[900] == 0 || result.PublicationAudit.Counts[1800] == 0 {
					t.Fatal("実5/15/30公開経路が空")
				}
				entered, reversalBooks := 0, 0
				for _, cfg := range result.Configs {
					key := Key(cfg)
					book := result.Books[key]
					if !book.Complete || book.Totals.OpenBuy+book.Totals.OpenSell+book.Totals.PendingBuy+book.Totals.PendingSell != 0 || book.Totals.EntryQuantity != book.Totals.CloseQuantity {
						t.Fatal("R人工に持越又は返済不足", key)
					}
					wantEntry := cfg.EntryPolicy == finance.EntryE0 || birthSecond == 2880 || cfg.EntryLifetime == finance.LifetimeL1
					if (book.Totals.EntryQuantity > 0) != wantEntry {
						t.Fatalf("R非ゼロ/初回失効の違い key=%s qty=%d assessments=%+v", key, book.Totals.EntryQuantity, result.EntryAudits[key].Assessments)
					}
					if !wantEntry {
						continue
					}
					entered++
					if len(book.Positions) != 1 || book.Totals.EntryQuantity != 6 || book.Positions[0].Side != side || book.Positions[0].Source.SignalID != "人工R一出生" {
						t.Fatal("一出生一取得/符号/量を変更", key)
					}
					if cfg.EntryPolicy != finance.EntryE2 {
						continue
					}
					reversalBooks++
					opportunity := book.EntryOpportunities[0]
					if opportunity.Status != "accepted" || opportunity.EvaluatedAt == nil || opportunity.Gate == nil || !opportunity.Gate.Allowed {
						t.Fatal("実R取得に純Gateが結合しない", key)
					}
					id := fmt.Sprintf("%d|%s|%s", opportunity.Ordinal, opportunity.Source.Method, opportunity.Source.SignalID)
					found := false
					for _, batch := range result.EntryAudits[key].Assessments {
						for _, assessment := range batch.Decisions {
							if assessment.Candidate.ID == id && assessment.Candidate.At == *opportunity.EvaluatedAt && assessment.Allowed && assessment.Route == entry.LocalReversal && assessment.Role == entry.Reversal && assessment.Reversal.Passed {
								found = true
								if assessment.SnapshotID != opportunity.Gate.SnapshotID || assessment.Candidate.Side != side || assessment.Candidate.Quantity != opportunity.Requested || assessment.Structure.ConfirmedAt <= 0 || assessment.Structure.ConfirmedAt > assessment.Candidate.At {
									t.Fatal("R公表構造と実受理の因果が不一致", key)
								}
							}
						}
					}
					if !found {
						t.Fatal("実取得をR局所転換へ結ぶ純評価なし", key)
					}
					if birthSecond == 1980 {
						audits := result.CompositeAudits[key].EntryAttempts
						if cfg.EntryLifetime != finance.LifetimeL1 || len(audits) < 2 || *opportunity.EvaluatedAt <= opportunity.AssignedAt || audits[0].Action == "accepted" || audits[len(audits)-1].Action != "accepted" {
							t.Fatal("R確認前の待機→後続枠維持が空", key)
						}
					}
					if cfg.Policy != finance.ProtectG0 {
						audits := result.CompositeAudits[key].Positions
						if len(audits) != 1 || !audits[0].Last.Finished || !audits[0].Last.ThresholdKnown || !audits[0].Last.Active {
							t.Fatal("R実取得からG3/G4必須保護/終了が通らない", key)
						}
					}
				}
				wantBooks, wantR := 36, 24
				if birthSecond == 1980 {
					wantBooks, wantR = 24, 12
				}
				if entered != wantBooks || reversalBooks != wantR {
					t.Fatal("R人工の非ゼロ冊数が不一致", entered, reversalBooks)
				}
				seed, err := core.NextSeed()
				if err != nil || seed.Info() != result.PublicationAudit.EndSeed {
					t.Fatal("R人工のFinish後数値種", err)
				}
				exportArtificial110(t, fmt.Sprintf("反転_方向%d_出生%.0f.json", side, birthSecond), struct {
					Scope   string          `json:"scope"`
					Tape    tape.Tape       `json:"tape"`
					Header  stream.Header   `json:"header"`
					Records []stream.Record `json:"records"`
					Output  Result          `json:"output"`
				}{"R実公開器・手製Source・市場実行なし", input, header, records, result})
				t.Logf("方向%d 出生%.0f秒: Main非ゼロ%d/R実取得%d、G0/G3/G4×4感度・旧4対照同体", side, birthSecond, entered, reversalBooks)
			})
		}
	}
}
