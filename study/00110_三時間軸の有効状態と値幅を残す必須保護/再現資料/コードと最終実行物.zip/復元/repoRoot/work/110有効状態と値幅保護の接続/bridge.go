package threeguardruntime110

import (
	"fmt"

	finance "github.com/masayoshi4649/SessionTradeExecuter/miniprofit110"
	oldfinance "github.com/masayoshi4649/SessionTradeExecuter/miniquietlength108"
	entry "github.com/masayoshi4649/SessionTradeExecuter/multientry110"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor110"
	delivery "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
)

// advancePublication は保存Recordの名目再生時計だけで新三尺度公開器を進めます。
//
// 引数: r(stream.Record)は旧validatorを通過した制御/原行です。
// 返り値: errorは新公開器の不成立です。AfterEOFForceは観測を進めません。
func (c *Core) advancePublication(r stream.Record) error {
	if r.AfterEOF {
		return nil
	}
	if r.Trigger != nil && r.Trigger.Time > r.At {
		c.pubAudit.TriggerLaterRecords++
		lead := r.Trigger.Time - r.At
		if lead > c.pubAudit.MaximumTriggerLeadSeconds {
			c.pubAudit.MaximumTriggerLeadSeconds = lead
		}
	}
	frames, err := c.pubBank.AdvanceObserved(r.At, uint64(r.Ordinal))
	if err != nil {
		return err
	}
	for _, f := range frames {
		c.pubAudit.Counts[f.WidthSeconds]++
		if f.PriceKnown {
			c.pubAudit.PriceKnown[f.WidthSeconds]++
		}
		if f.VolumeKnown {
			c.pubAudit.VolumeKnown[f.WidthSeconds]++
		}
		c.pubAudit.ChainSHA, err = digestValue([]any{c.pubAudit.ChainSHA, f})
		if err != nil {
			return err
		}
	}
	return nil
}

// entryGrid は当枠金融適格性の後にだけ同じ政策snapshotで候補を一括査定します。
//
// 引数: at(float64)は元5分gridです。
// 返り値: errorは純入口/Actor契約の不成立です。Actor成功後だけ純状態をcommitします。
func (c *Core) entryGrid(at float64) error {
	public, err := c.pubBank.SnapshotAt(at)
	if err != nil {
		return err
	}
	policySnapshot := entry.PolicySnapshot(public)
	if policySnapshot.Session.EOF != 0 {
		return fmt.Errorf("純入口へ未来EOFが露出")
	}
	snapshotID, err := entry.SnapshotID(policySnapshot)
	if err != nil {
		return err
	}
	for i, b := range c.actors {
		if c.configs[i].EntryPolicy == finance.EntryE0 {
			if err = b.OnCompositeEntryGrid(at, "", nil); err != nil {
				return err
			}
			continue
		}
		next := c.entryStates[i]
		var assessment entry.BatchAssessment
		called := false
		gate := func(input finance.EntryBatchInput) (finance.EntryBatchOutput, error) {
			if called || input.At != at || input.SnapshotID != snapshotID {
				return finance.EntryBatchOutput{}, fmt.Errorf("純入口callbackの重複/時計/snapshot差")
			}
			called = true
			candidates := make([]entry.Candidate, len(input.Candidates))
			for j, x := range input.Candidates {
				quote := x.Quote.Ask
				if x.Side < 0 {
					quote = x.Quote.Bid
				}
				candidates[j] = entry.Candidate{ID: fmt.Sprintf("%d|%s|%s", x.Ordinal, x.Source.Method, x.Source.SignalID), Side: x.Side, At: x.At, EntryQuote: quote, Quantity: x.Quantity}
			}
			var e error
			next, assessment, e = entry.AssessBatch(c.entryStates[i], policySnapshot, candidates, entry.EntryE2)
			if e != nil {
				return finance.EntryBatchOutput{}, e
			}
			if assessment.SnapshotID != snapshotID || len(assessment.Decisions) != len(candidates) {
				return finance.EntryBatchOutput{}, fmt.Errorf("純入口のsnapshot/候補数差")
			}
			out := finance.EntryBatchOutput{SnapshotID: snapshotID, Decisions: []finance.EntryBatchDecision{}}
			for j, a := range assessment.Decisions {
				if a.Candidate != candidates[j] {
					return out, fmt.Errorf("純入口候補のecho/順序差")
				}
				role := string(a.Role)
				if role == "" {
					role = string(a.Status)
				}
				out.Decisions = append(out.Decisions, finance.EntryBatchDecision{Candidate: input.Candidates[j], Decision: finance.GateDecision{Policy: finance.CompositeGatePolicy, SnapshotID: snapshotID, Known: a.Known, Allowed: a.Allowed, Role: role, Reason: a.Reason}})
			}
			return out, nil
		}
		if err = b.OnCompositeEntryGrid(at, snapshotID, gate); err != nil {
			return err
		}
		if !called {
			return fmt.Errorf("E1の空/quiet含む枠が純入口へ配送されない")
		}
		c.entryStates[i] = next
		a := &c.entryAudits[i]
		a.Calls++
		a.Candidates += len(assessment.Decisions)
		if assessment.Conflict {
			a.Conflicts++
		}
		for _, d := range assessment.Decisions {
			if d.Allowed {
				a.Allowed++
			}
			if !d.Known {
				a.Unknown++
			}
		}
		a.FinalState = assessment.State
		if len(assessment.Decisions) > 0 {
			a.Assessments = append(a.Assessments, assessment)
		}
	}
	return nil
}

// guardTruth は未知を偽へ補完せず旧幅三値を純保護三値へ写します。
//
// 引数: known(bool)、passed(*bool)は既存公開評価の二欄です。
// 返り値: guard.Truth/errorは正確な三値又は矛盾です。
func guardTruth(known bool, passed *bool) (guard.Truth, error) {
	if !known {
		if passed != nil {
			return guard.Unknown, fmt.Errorf("未知三値にpassedを付与")
		}
		return guard.Unknown, nil
	}
	if passed == nil {
		return guard.Unknown, fmt.Errorf("既知三値のpassedが欠落")
	}
	if *passed {
		return guard.True, nil
	}
	return guard.False, nil
}

// protectionObservation は旧3分公表から連続5足のVとprior pivotだけを形成します。
//
// 引数: d(delivery.Delivery)は既存pipeで照合した公表です。
// 返り値: finance.ProtectionObservation/errorは新G1/G2だけの根拠です。入口の5分値を流用しません。
func (c *Core) protectionObservation(d delivery.Delivery) (finance.ProtectionObservation, error) {
	f := d.Frame
	scope := guard.Scope{Session: f.Session, Contract: f.Contract, Start: f.Start}
	known := f.DataKnown && f.OHLC != nil
	if !known || len(c.guardBars) > 0 && c.guardBars[len(c.guardBars)-1].End+180 != f.End {
		c.guardBars = nil
	}
	bar := guard.Bar{Scope: scope, ID: f.ID, Start: f.End - 180, End: f.End, AvailableAt: f.AvailableAt, Known: known}
	if known {
		bar.High, bar.Low = f.OHLC.High, f.OHLC.Low
	}
	c.guardBars = append(c.guardBars, bar)
	if len(c.guardBars) > 5 {
		c.guardBars = append([]guard.Bar{}, c.guardBars[len(c.guardBars)-5:]...)
	}
	v, e := guard.MedianRange5(scope, c.guardBars, d.At)
	if e != nil {
		return finance.ProtectionObservation{}, e
	}
	ct, e := guardTruth(d.Result.C.Known, d.Result.C.Passed)
	if e != nil {
		return finance.ProtectionObservation{}, e
	}
	makeSide := func(role delivery.Role) (guard.Publication, error) {
		m, err := guardTruth(role.M.Known, role.M.Passed)
		if err != nil {
			return guard.Publication{}, err
		}
		p := guard.Publication{Scope: scope, ID: f.ID, Ordinal: uint64(f.Ordinal), End: f.End, AvailableAt: f.AvailableAt, C: ct, M: m}
		if v != nil {
			value := v.Value
			p.V = &value
		}
		if f.Known.Close {
			value := f.Close
			p.Close = &value
		}
		if x := role.PriorPivot; x != nil {
			p.PriorPivot = &guard.Pivot{Scope: scope, ID: x.CenterID, Kind: x.Kind, Price: x.Price, CenterEnd: x.CenterEnd, ConfirmEnd: x.ConfirmEnd, PublishedAt: x.PublishedAt}
		}
		return p, nil
	}
	buy, e := makeSide(d.Result.Buy)
	if e != nil {
		return finance.ProtectionObservation{}, e
	}
	sell, e := makeSide(d.Result.Sell)
	if e != nil {
		return finance.ProtectionObservation{}, e
	}
	fh, e := delivery.CanonicalSHA(f)
	if e != nil {
		return finance.ProtectionObservation{}, e
	}
	rh, e := delivery.CanonicalSHA(d.Result.Values())
	if e != nil {
		return finance.ProtectionObservation{}, e
	}
	return finance.ProtectionObservation{At: d.At, Buy: buy, Sell: sell, FrameSHA: fh, ResultSHA: rh}, nil
}

// deliverProtection は旧G0と新G1/G2へ重複なしの別境界で配送します。
//
// 引数: d(delivery.Delivery)は既存3分の新公表です。
// 返り値: errorは公表変換/Actor契約の不成立です。
func (c *Core) deliverProtection(d delivery.Delivery) error {
	obs, e := c.protectionObservation(d)
	if e != nil {
		return e
	}
	for i, b := range c.actors {
		if c.configs[i].Policy == finance.ProtectG0 {
			e = delivery.Send(d, finance.PublicReceiver{Book: b})
		} else {
			e = b.OnProtectionObservation(obs)
		}
		if e != nil {
			return e
		}
	}
	for _, b := range c.shadows {
		if e = delivery.Send(d, oldfinance.PublicReceiver{Book: b}); e != nil {
			return e
		}
	}
	c.protectAudit.Publications++
	if obs.Buy.V == nil {
		c.protectAudit.VUnknown++
	} else {
		c.protectAudit.VKnown++
	}
	c.protectAudit.Latest = &obs
	c.protectAudit.ChainSHA, e = digestValue([]any{c.protectAudit.ChainSHA, obs})
	return e
}

// resetProtection は床や実保有を緩めず、古い3分根拠とV窓だけを失効します。
//
// 引数: at(float64)、reason(string)は旧reset時計と理由です。
// 返り値: errorは旧pipe又は新Actorの不成立です。
func (c *Core) resetProtection(at float64, reason string) error {
	receivers := []delivery.Receiver{}
	for i, b := range c.actors {
		if c.configs[i].Policy == finance.ProtectG0 {
			receivers = append(receivers, finance.PublicReceiver{Book: b})
		} else {
			if e := b.ResetProtectionObservation(at, reason); e != nil {
				return e
			}
		}
	}
	for _, b := range c.shadows {
		receivers = append(receivers, oldfinance.PublicReceiver{Book: b})
	}
	if e := c.pipeline.Reset(at, reason, receivers...); e != nil {
		return e
	}
	c.guardBars = nil
	c.protectAudit.Resets++
	c.protectAudit.Latest = nil
	return nil
}
