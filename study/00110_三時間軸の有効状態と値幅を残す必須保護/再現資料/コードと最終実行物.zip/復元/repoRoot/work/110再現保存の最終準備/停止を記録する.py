"""最終候補collectorと既存ZIP共通部の人工確認を認証して停止する。"""

import json
from pathlib import Path

import 収集する as P


def main():
    """
    機能: 6主人工と元コードの不変を認証して停止metadataを新規保存する。

    引数: なし。
    返り値: None。市場/HTTP/正式ZIP保存は行わない。
    """
    path = P.OWN / '人工確認.json'
    proof = P.C.read(path)
    P.C.need(proof['成功'] and proof['主'] == 6 and proof['コード前後不変'], '最終候補の人工6主成功が必要')
    owned = proof['所有コードSHA256']
    P.C.need(all(P.C.sha(Path(name)) == expected for name, expected in owned.items()), '所有コード前後差')
    P.C.need(P.C.sha(P.PLAN) == P.PLAN_SHA and P.C.sha(P.Z.ORIGINAL) == P.Z.ORIGINAL_SHA, '旧計画/ZIP原本の不変')
    for name, expected in P.STOPS.items():
        P.C.need(P.C.sha(P.ROOT / name) == expected, '追加停止の原本不変')
    target = P.OWN / '停止.json'
    value = {'version': 1, 'trial': 110, '成功': True, '停止': True, '主': 6,
             'scope': '旧1398所在を保持した最終helper/知見/既存ZIP3関数の再用準備。実金融結果は未読',
             '所有コードSHA256': owned, '人工確認': P.C.ref(path), '旧計画': P.C.ref(P.PLAN),
             '追加helper停止': P.STOPS, 'ZIP原本': P.C.ref(P.Z.ORIGINAL), '前後不変': True,
             '正式ZIP生成': False, '実市場本文/実Native/実API/11月09日読取': False}
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'成功': True, '停止': P.C.ref(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
