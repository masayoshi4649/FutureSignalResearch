"""最終候補の保存境界と既存ZIP3関数の再用を非市場の人工だけで検査する。"""

import ast
import copy
import json
from pathlib import Path
import tempfile
import unittest

import 収集する as P


class 最終準備検査(unittest.TestCase):
    """旧計画の不変と手製ZIPの指紋/保存名を確認する。"""

    def test_旧1398所在と全準備停止を保持する(self):
        """
        機能: 旧全所在を変えず最終helper5停止と明示知見だけを追加する。

        引数: self(最終準備検査)は検査器。
        返り値: None。実市場結果の値は読み出さない。
        """
        previous = P.C.read(P.PLAN, P.PLAN_SHA)
        plan = P.build_plan()
        rows = {row['original_path']: row for row in plan['files']}
        for old in previous['files']:
            current = rows[old['original_path']]
            for key in ('sha256', 'bytes', 'kind', 'restore', 'location'):
                self.assertEqual(current[key], old[key])
            self.assertTrue(set(old['roles']).issubset(current['roles']))
        self.assertEqual(len(plan['final_helper_stops']), 5)
        self.assertEqual(plan['summary']['環境参照'], 717)
        self.assertEqual(plan['summary']['種別']['最終exe'], 2)
        self.assertEqual(plan['summary']['種別']['人工'], 52)
        self.assertFalse(plan['final_evidence'])
        self.assertEqual(set(plan['final_evidence_pending']), P.FINAL_NAMES)
        self.assertEqual(plan['history'], previous['history'])
        self.assertEqual(plan['input_dependencies'], previous['input_dependencies'])
        added = set(rows) - {row['original_path'] for row in previous['files']}
        for name in added:
            self.assertNotIn(Path(name).suffix, ('.gz', '.csv', '.xlsx', '.exe'))
            self.assertNotIn('.Native.', Path(name).name)
        for name in P.DOCUMENTS:
            self.assertIn(str(P.ROOT / name), rows)

    def test_既存ZIP3関数を手製だけで再用する(self):
        """
        機能: 原本同体の圧縮/再読を手製3ファイルの全SHA/CRCへ照合する。

        引数: self(最終準備検査)は検査器。
        返り値: None。生成ZIPは所有領域内の一時人工である。
        """
        common = P.Z.load_common(P.C)
        self.assertEqual(tuple(vars(common)), P.Z.FUNCTIONS)
        with tempfile.TemporaryDirectory(prefix='人工_', dir=P.OWN) as name:
            folder = Path(name).resolve()
            self.assertTrue(folder.is_relative_to(P.OWN))
            rows = []
            for index, body in enumerate(('値=1\n', '日本語の説明\n', '{}\n')):
                path = folder / f'手製{index}.txt'
                path.write_text(body, encoding='utf-8')
                rows.append({'original_path': str(path), 'sha256': P.C.sha(path), 'bytes': path.stat().st_size,
                             'location': {'entry': f'復元/repoRoot/手製{index}.txt'}})
            zip_path = folder / '手製.zip'
            common.write_zip(zip_path, rows)
            checks = common.verify_zip(zip_path, rows)
            self.assertEqual(set(checks), {row['location']['entry'] for row in rows})
            self.assertTrue(all(checks[row['location']['entry']]['sha256'] == row['sha256'] for row in rows))
            wrong = copy.deepcopy(rows)
            wrong[0]['sha256'] = '0' * 64
            with self.assertRaises(ValueError):
                common.verify_zip(zip_path, wrong)
            with self.assertRaises(FileExistsError):
                common.write_zip(zip_path, rows)

    def test_危険ZIP名とWindows同名を拒否する(self):
        """
        機能: 絶対/遡り/drive名と大小文字だけ異なるentryを拒否する。

        引数: self(最終準備検査)は検査器。
        返り値: None。
        """
        common = P.Z.load_common(P.C)
        for name in ('', '/絶対', '../遡り', 'a/../b', 'C:/drive', 'a\\b'):
            self.assertFalse(common.safe(name))
        with tempfile.TemporaryDirectory(prefix='人工_', dir=P.OWN) as name:
            folder = Path(name).resolve()
            self.assertTrue(folder.is_relative_to(P.OWN))
            source = folder / '手製.txt'
            source.write_text('手製', encoding='utf-8')
            base = {'original_path': str(source), 'sha256': P.C.sha(source), 'bytes': source.stat().st_size}
            rows = [{**base, 'location': {'entry': name}} for name in ('復元/A.txt', '復元/a.txt')]
            with self.assertRaises(ValueError):
                common.write_zip(folder / '未作成.zip', rows)
            self.assertFalse((folder / '未作成.zip').exists())

    def test_完成後補足も明示Refと型を限定する(self):
        """
        機能: 手製の完成後補足だけで認証し不明名/別型/誤指紋を拒否する。

        引数: self(最終準備検査)は検査器。
        返り値: None。実結果やCSVへはアクセスしない。
        """
        with tempfile.TemporaryDirectory(prefix='人工_', dir=P.OWN) as name:
            folder = Path(name).resolve()
            self.assertTrue(folder.is_relative_to(P.OWN))
            target = folder / '手製.md'
            target.write_text('手製の結果ではない説明\n', encoding='utf-8')
            value = {'version': 1, 'trial': 110, 'fixed': True, 'refs': {'最終README': P.C.ref(target)}}
            path = folder / '手製補足.json'
            path.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
            result = P.final_evidence(P.C.ref(path))
            self.assertEqual(result['最終README']['sha256'], P.C.sha(target))
            self.assertFalse(result['最終README']['コードZIPへ重複同梱'])
            bad = copy.deepcopy(value)
            bad['refs']['不明な成功'] = bad['refs'].pop('最終README')
            path.write_text(json.dumps(bad, ensure_ascii=False), encoding='utf-8')
            with self.assertRaises(ValueError):
                P.final_evidence(P.C.ref(path))
            bad = copy.deepcopy(value)
            bad['refs']['最終README']['sha256'] = '0' * 64
            path.write_text(json.dumps(bad, ensure_ascii=False), encoding='utf-8')
            with self.assertRaises(ValueError):
                P.final_evidence(P.C.ref(path))
            bad = copy.deepcopy(value)
            bad['refs']['最終README']['path'] = str(folder / '実Native.json.gz')
            path.write_text(json.dumps(bad, ensure_ascii=False), encoding='utf-8')
            with self.assertRaises(ValueError):
                P.final_evidence(P.C.ref(path))

    def test_旧計画の指紋と保存先差を拒否する(self):
        """
        機能: 既存所在の改竄や復元先差を実ファイル変更なしで拒否する。

        引数: self(最終準備検査)は検査器。
        返り値: None。
        """
        previous = P.C.read(P.PLAN, P.PLAN_SHA)
        for key, value in (('sha256', '0' * 64), ('location', {'entry': '../不明', 'kind': '新archive予定'})):
            bad = copy.deepcopy(previous)
            bad['files'][0][key] = value
            with self.subTest(key=key), self.assertRaises(ValueError):
                P.restore_registry(bad)

    def test_新規関数コメント規約(self):
        """
        機能: 全新Python関数の複数行と機能/引数/返り値を確認する。

        引数: self(最終準備検査)は検査器。
        返り値: None。
        """
        for path in P.OWN.glob('*.py'):
            for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    text = ast.get_docstring(node)
                    self.assertTrue(text and node.body[0].end_lineno > node.body[0].lineno, (path.name, node.name))
                    self.assertTrue(all(word in text for word in ('機能:', '引数:', '返り値:')), (path.name, node.name))


def main():
    """
    機能: 非市場の最終準備検査を実行しコード不変の証拠を新規保存する。

    引数: なし。
    返り値: None。実市場/実取引/HTTP/正式ZIPは使用しない。
    """
    owned = sorted(P.OWN.glob('*.py')) + [P.OWN / 'README.md']
    before = {str(path): P.C.sha(path) for path in owned}
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(最終準備検査))
    assert before == {str(path): P.C.sha(path) for path in owned}
    value = {'成功': result.wasSuccessful(), '主': result.testsRun, 'コード前後不変': True, '所有コードSHA256': before,
             '旧計画': {'path': str(P.PLAN), 'sha256': P.PLAN_SHA}, '追加helper停止': P.STOPS,
             '既存ZIP原本': {'path': str(P.Z.ORIGINAL), 'sha256': P.Z.ORIGINAL_SHA},
             '再用ZIP関数': list(P.Z.FUNCTIONS), '手製ZIPのみ': True, '正式ZIP生成': False,
             '実金融数値/実Native/価格/11月09日読取': False, '実API': False}
    with (P.OWN / '人工確認.json').open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    if not result.wasSuccessful():
        raise SystemExit(1)


if __name__ == '__main__':
    main()
