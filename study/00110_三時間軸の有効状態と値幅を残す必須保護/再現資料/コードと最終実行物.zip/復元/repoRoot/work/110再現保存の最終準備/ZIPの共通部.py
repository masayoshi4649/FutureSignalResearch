"""109固定原本からZIP処理3関数だけを変更せず読み出す。"""

import ast
import hashlib
from pathlib import Path, PurePosixPath
from types import SimpleNamespace
import zipfile
import zlib

ROOT = Path(__file__).resolve().parents[2]
ORIGINAL = ROOT / 'work/109再現コードの準備/ZIPを正式保存する.py'
ORIGINAL_SHA = 'cb263d54b70bbb6ca94d227736fce98748a623d014924b960660039d8f98eae2'
FUNCTIONS = ('safe', 'write_zip', 'verify_zip')


def load_common(collector):
    """
    機能: 認証済みの既存ZIP3関数をAST同体で読み出す。

    引数: collector(module)はneed/shaを提供する既存の収集共通部。
    返り値: SimpleNamespaceはsafe/write_zip/verify_zipのみ。109のgate/mainを持たない。
    """
    body = ORIGINAL.read_bytes()
    collector.need(hashlib.sha256(body).hexdigest() == ORIGINAL_SHA, '旧ZIP原本の指紋差')
    tree = ast.parse(body.decode('utf-8'))
    nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in FUNCTIONS]
    collector.need(tuple(node.name for node in nodes) == FUNCTIONS, '既存ZIP3関数の正確な抽出')
    selected = ast.Module(body=nodes, type_ignores=[])
    env = {'C': collector, 'Path': Path, 'PurePosixPath': PurePosixPath, 'zipfile': zipfile, 'zlib': zlib}
    exec(compile(selected, str(ORIGINAL), 'exec'), env)
    return SimpleNamespace(**{name: env[name] for name in FUNCTIONS})
