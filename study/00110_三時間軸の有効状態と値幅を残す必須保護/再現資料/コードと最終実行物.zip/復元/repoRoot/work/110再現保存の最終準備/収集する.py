"""110の中断記録追加計画を保持し最終helperと非市場証拠を追加する。"""

import argparse
from collections import Counter
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import zlib

import ZIPの共通部 as Z

OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
PREVIOUS = ROOT / 'work/110再現保存の準備_中断記録追加'
PLAN = PREVIOUS / '計画候補.json'
PLAN_SHA = '7a1f50a497c5ed864d93d5a39e8809fa125fdb160999cdd61bfc952c12af3699'
COLLECTOR_SHA = '2aa3ae6c469acb3cae42e147bb6c99f7ccd0beb72df66482e01b31cc3429fabf'
PREPARED_SHA = 'fc9f2d04ffd36b1ff9d00a467d110e68288df22aaaa2278e9c6337afa923d73d'
STOPS = {
    'work/110報告の準備/停止.json': '2736e41fb11443a24bfd07baff979a5b87e6737800a1ba05cbb828d7a72e35d8',
    'work/110正式保存の準備/停止.json': 'f8c752865901d5fb6bc02dbb19d3bc6d8341b0b28e09ed424119f0def9ed28e2',
    'work/110Viewer確認の準備/停止.json': 'aeb7280f28792c29cbdd11bb719ce640acfa16dbbf10ef5ad679ce3fd4d1bcaf',
    'work/110出口の同入口比較_準備/停止.json': '26ecd5d6812018b5172529646a638d04de93286b5f83b1228c34e9d930bfaf1b',
    'work/110頻度の集計準備/停止.json': '1ac1a581c03d2b97294a86fb2921373f5ca5a9bfd10e3dee15d239c8c77804f7',
}
DOCUMENTS = {
    'docs/議論/外部再調査/強さの持続とオシレーターの増分を分ける.md': 'd5451bf3067d5d39b4fdec3fbcd0403f7f7d43bf94c72374ade7308a3eb68d01',
    'docs/議論/外部再調査/時間軸の持続性と費用を分ける.md': 'd212b9c6184e25b073ebc343515de7ff899280179f37779ea4ae0dcfe3c5e4d6',
    'docs/議論/5分15分30分で入口の環境と確認を分ける.md': '08121b38bfdff471757a33ea809d74c9a8ee0f0d30bfbf6cbddb624d8b43dbb7',
}
FINAL_NAMES = {'金融全70場', '純頻度全70場', '独立保存', '頻度独立集計', 'CSV再読', 'Viewer代表72', '正式保存',
               '同入口比較', '最終README', '設定と結果', '候補別集計CSV', '全セッションCSV'}

if hashlib.sha256((PREVIOUS / '収集する.py').read_bytes()).hexdigest() != COLLECTOR_SHA:
    raise ValueError('中断記録追加collectorの指紋差')
SPEC = importlib.util.spec_from_file_location('110中断記録追加の共通部', PREVIOUS / '収集する.py')
P = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(P)
C = P.C


def restore_registry(previous):
    """
    機能: 中断記録追加計画1398所在を再認証し全元配置を保持する。

    引数: previous(dict)は期待全SHAで認証済みの旧計画。
    返り値: Registryは既存保存種別/位置/役割を保持した台帳。
    """
    C.need(previous['trial'] == 110 and previous['summary']['全所在'] == 1398, '旧1398所在が必要')
    rows = previous['files']
    registry = C.Registry([Path(row['original_path']) for row in rows if row['kind'] == '最終exe'],
                          [Path(row['original_path']) for row in rows if row['kind'] == '人工'])
    for row in rows:
        C.need(bool(row['roles']), '全所在に役割が必要')
        for role in row['roles']:
            current = registry.add(row['original_path'], row['sha256'], role, row['kind'])
        for key in ('original_path', 'sha256', 'bytes', 'kind', 'restore', 'location'):
            C.need(current[key] == row[key], '既存所在の内容/保存先変更を拒否')
    C.need(len(registry.rows) == 1398, '旧所在の重複を拒否')
    return registry


def add_stop(registry, name, expected):
    """
    機能: 最終helperの停止・所有/再用code・人工確認を認証して追加する。

    引数: registry(Registry)、name/expected(str)は台帳と停止path/SHA。
    返り値: dictは停止Ref。実結果・人工以外の市場入力を開かない。
    """
    path = ROOT / name
    stopped = C.read(path, expected)
    C.need(stopped['成功'], '成功した準備停止が必要')
    registry.add_ref({'path': str(path), 'sha256': expected}, '110最終helperの停止', 'metadata')
    owned = stopped.get('所有コードSHA256', stopped.get('所有SHA256'))
    C.need(bool(owned), '停止所有集合が必要')
    for field in (owned, stopped.get('依存コードSHA256', {}), stopped.get('再用コードSHA256', {}), stopped.get('原本SHA256', {})):
        for source, digest in field.items():
            kind = 'metadata' if Path(source).suffix in ('.md', '.json', '.toml') else 'code'
            registry.add(source, digest, '110最終helperの停止所有/実再用', kind)
    if '人工確認SHA256' in stopped:
        registry.add(str(path.parent / '人工確認.json'), stopped['人工確認SHA256'], '停止が認証する手製器具の確認', 'metadata')
    if '人工確認' in stopped:
        registry.add_ref(stopped['人工確認'], '停止が認証する手製器具の確認', 'metadata')
    return {'path': str(path), 'sha256': expected}


def final_evidence(supplement):
    """
    機能: Root成功後の明示証拠Refを重複同梱せず外部参照へ結ぶ。

    引数: supplement(dict|None)は補足metadataのpath/sha256。
    返り値: dictは認証Ref。先の金融/Viewer成功の代行認定は行わない。
    """
    if supplement is None:
        return {}
    path = C.resolve(supplement['path'])
    C.need(path.is_relative_to(ROOT) and path.suffix == '.json', '補足はrepo内の明示JSONだけ')
    value = C.read(path, supplement['sha256'])
    C.need(value['version'] == 1 and value['trial'] == 110 and value['fixed'] is True, 'Root固定した110補足だけ')
    C.need(bool(value['refs']) and set(value['refs']).issubset(FINAL_NAMES), '完成後の証拠名を限定')
    result = {}
    for name, ref in value['refs'].items():
        C.need(set(ref) in ({'path', 'sha256'}, {'path', 'sha256', 'bytes'}), '完成後証拠の明示Ref')
        target = C.resolve(ref['path'])
        C.need(target.is_relative_to(ROOT) and target.suffix in ('.json', '.md', '.csv') and '.Native.' not in target.name, '完成後metadata/CSVだけを認証')
        C.need(C.sha(target) == ref['sha256'], '完成後証拠の全SHA差')
        if 'bytes' in ref:
            C.need(target.stat().st_size == ref['bytes'], '完成後証拠の容量差')
        result[name] = {'path': str(target), 'sha256': ref['sha256'], 'bytes': target.stat().st_size, 'コードZIPへ重複同梱': False}
    return result


def build_plan(supplement=None):
    """
    機能: 最終helper5停止と外部知見を追加した110の候補計画を作る。

    引数: supplement(dict|None)はRoot完成後にだけ指定する追加証拠Ref。
    返り値: dictは正式ZIP未生成の候補。補足なしでは実市場結果を読まない。
    """
    previous = C.read(PLAN, PLAN_SHA)
    prepared = C.read(PREVIOUS / '準備確認.json', PREPARED_SHA)
    C.need(prepared['成功'] and prepared['主'] == 5 and prepared['コード前後不変'], '旧追加準備の成功')
    registry = restore_registry(previous)
    for path, expected, label in ((PLAN, PLAN_SHA, '中断記録追加計画の正本'),
                                  (PREVIOUS / '準備確認.json', PREPARED_SHA, '中断記録追加準備の確認')):
        registry.add_ref({'path': str(path), 'sha256': expected}, label, 'metadata')
    stops = [add_stop(registry, name, expected) for name, expected in STOPS.items()]
    for name, expected in DOCUMENTS.items():
        registry.add(str(ROOT / name), expected, '110の設計/固定後調査に用いた一次資料と解釈', 'metadata')
    registry.add(str(Z.ORIGINAL), Z.ORIGINAL_SHA, '再用する旧ZIP3関数の原本')
    for name, expected in (
        ('work/110専用Viewer8094/起動.json', '57b57e81068de2b486435f6885f93051ec945f53cc5ef57a81cd13bce7038f12'),
        ('work/110専用Viewer8094/conf/viewer.toml', 'bfb8f6658aa80ed5991aec14de4418de435a8ab3803c83b06e788b49fc71b198')):
        registry.add(str(ROOT / name), expected, '新専用8094の起動/設定の履歴', 'metadata')
    viewer = ROOT / 'work/110専用Viewer8094/session-trade-viewer.exe'
    viewer_ref = {'path': str(viewer), 'sha256': '0ed329e06293f55a99ab1dc503e32cc104285319316ef41b81b59470dce9d0e8', 'コードZIPへ同梱': False}
    C.need(C.sha(viewer) == viewer_ref['sha256'], 'Viewer環境実行物の同体')
    Z.load_common(C)
    for path in sorted(OWN.glob('*.py')):
        registry.file(path, '110最終候補collector/既存ZIP共通部の再用/人工検査')
    registry.file(OWN / 'README.md', '110最終候補収集と既存ZIP再用の仕様', 'metadata')
    for name in ('人工確認.json', '停止.json'):
        path = OWN / name
        if path.is_file():
            registry.file(path, '最終候補の人工検査と停止の証拠', 'metadata')
    rows = sorted(registry.rows.values(), key=lambda row: row['original_path'])
    for row in rows:
        row['roles'].sort()
    archived = [row for row in rows if row['kind'] != '環境']
    names = [row['location']['entry'] for row in archived]
    common = Z.load_common(C)
    C.need(all(common.safe(name) for name in names) and len({name.casefold() for name in names}) == len(names), '既存ZIP名規則と一意性')
    estimate = sum(len(zlib.compress(Path(row['original_path']).read_bytes(), 9)) + 2 * len(row['location']['entry'].encode('utf-8')) + 120 for row in archived)
    evidence = final_evidence(supplement)
    value = copy.deepcopy(previous)
    value.update({'version': 3, 'scope': '最終helper/知見/既存ZIP再用の候補計画。正式ZIP/最終closure未生成',
                  'previous_plan': {'path': str(PLAN), 'sha256': PLAN_SHA}, 'files': rows, 'final_helper_stops': stops,
                  'final_evidence': evidence, 'final_evidence_pending': sorted(FINAL_NAMES - evidence.keys()),
                  'zip_reuse': {'original': {'path': str(Z.ORIGINAL), 'sha256': Z.ORIGINAL_SHA}, 'functions': list(Z.FUNCTIONS), '109のgate/main実行': False},
                  'external_environment': [viewer_ref],
                  'summary': {'全所在': len(rows), '同梱予定': len(archived), '環境参照': sum(row['kind'] == '環境' for row in rows),
                              '種別': dict(Counter(row['kind'] for row in rows)), '同梱元bytes': sum(row['bytes'] for row in archived), 'ZIP概算bytes': estimate},
                  'pending': ['Root成功gateで全70金融/純頻度/独立保存/正式保存/CSV再読/Viewerを認証した証拠を追加',
                              '最終README/設定表とCSVの固定後に最終計画を別ファイルで確定', '110の成功gate/正式ZIP同バイト移設/所在索引/再現文書をRoot指示で生成',
                              '最終closureはZIP保存後Rootが作成し循環参照を避ける', 'Source106入力保持/正確復元はコード/exeの保存とは別要件']})
    C.need(value['summary']['環境参照'] == 717 and sum(row['kind'] == '最終exe' for row in rows) == 2, 'GoRoot717と最終exe2を維持')
    return value


def main():
    """
    機能: 新規候補計画を所有workへ保存する。

    引数: --plan(Path)は未使用先、--supplement/--supplement-shaは任意の完成後証拠Ref。
    返り値: None。市場/HTTP/正式ZIP生成を行わない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--supplement', type=Path)
    parser.add_argument('--supplement-sha')
    args = parser.parse_args()
    target = args.plan.resolve()
    C.need(target.is_relative_to(OWN) and not target.exists(), '候補計画は所有領域へ新規だけ')
    C.need((args.supplement is None) == (args.supplement_sha is None), '完成後証拠はpath/SHAの両方が必要')
    supplement = None if args.supplement is None else {'path': str(args.supplement.resolve()), 'sha256': args.supplement_sha}
    value = build_plan(supplement)
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'成功': True, '候補計画': C.ref(target), '見積': value['summary'], '正式ZIP生成': False, '実市場本文読取': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
