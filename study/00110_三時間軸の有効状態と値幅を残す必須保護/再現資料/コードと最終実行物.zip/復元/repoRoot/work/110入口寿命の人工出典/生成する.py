"""停止ActorのAPIと手製Source器具から寿命検査だけの人工JSONを作る。"""

import hashlib
import json
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
ACTOR=HERE.parent/'110有効入口と値幅保護の会計'


def main():
    """
    機能: 新規人工出典を生成し停止Actor前後同体を記録する。

    引数: なし。
    返り値: None。市場/Raw/実金融を読まない。
    """
    out=HERE/'寿命の人工.json'
    if out.exists(): raise RuntimeError('人工出典の上書き禁止')
    stop=ACTOR/'停止.json'
    if hashlib.sha256(stop.read_bytes()).hexdigest()!='4a164c503bb7e464bdeb901411dcf27a5266fe354776a4c15b0f8aa6089ef91a': raise RuntimeError('Actor停止差')
    owned=json.loads(stop.read_text(encoding='utf-8'))['所有コードSHA256']
    root=HERE.parent.parent
    before={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in owned}
    if before!=owned: raise RuntimeError('Actor所有差')
    mod=(ACTOR/'go.mod').read_text(encoding='utf-8').replace('/miniprofit110\n','/entrylifetimefixture110\n',1)
    mod+='\nrequire github.com/masayoshi4649/SessionTradeExecuter/miniprofit110 v0.0.0\nreplace github.com/masayoshi4649/SessionTradeExecuter/miniprofit110 => ../110有効入口と値幅保護の会計\n'
    (HERE/'go.mod').write_text(mod,encoding='utf-8')
    (HERE/'go.sum').write_bytes((ACTOR/'go.sum').read_bytes())
    fixture=(ACTOR/'source_fixture_test.go').read_text(encoding='utf-8').replace('package miniprofit110','package main',1)
    (HERE/'source_fixture.go').write_text(fixture,encoding='utf-8')
    subprocess.run(['gofmt','-w','main.go','source_fixture.go'],cwd=HERE,check=True)
    subprocess.run(['go','mod','tidy'],cwd=HERE,check=True)
    p=subprocess.run(['go','run','.'],cwd=HERE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    if p.returncode: raise RuntimeError(p.stderr.decode('utf-8'))
    json.loads(p.stdout)
    out.write_bytes(p.stdout)
    after={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in owned}
    if before!=after: raise RuntimeError('Actorコード変更')
    proof={'成功':True,'範囲':'人工Source通知と手製採否でL1保存監査の金融/寿命枝だけを検査','入力':{'path':str(stop),'sha256':hashlib.sha256(stop.read_bytes()).hexdigest()},
           '人工出力':{'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()},'器具':6,'Actor前後不変':True,'市場読取':False,'実技術成立を主張':False}
    (HERE/'確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__': main()
