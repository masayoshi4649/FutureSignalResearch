// Package main は手製Source通知だけでL1の保存監査用の端点を作ります。
package main

import (
	"encoding/json"
	"fmt"
	"os"

	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	finance "github.com/masayoshi4649/SessionTradeExecuter/miniprofit110"
)

type NativeBatch = finance.NativeBatch

type harness struct {
	b     *finance.ActualBook
	src   *source
	s     native.Session
	index int64
}

// create は固定L1/G3の人工口座を作ります。
//
// 引数: なし。
// 返り値: *harnessは手製Sourceと独立口座です。
func create() *harness {
	s := session()
	b, err := finance.NewCompositeBook(s, finance.CompositeConfig{EntryPolicy: finance.EntryE2, EntryLifetime: finance.LifetimeL1, Protection: finance.ProtectG3}, "人工寿命限月")
	if err != nil {
		panic(err)
	}
	return &harness{b: b, src: newSource(), s: s}
}

// feed は元通知を一度だけ形成して停止Actorへ渡します。
//
// 引数: at(float64),bad(bool),news(...native.Signal)は場開始からの時計/気配/通知です。
// 返り値: ありません。
func (h *harness) feed(at float64, bad bool, news ...native.Signal) {
	o := observation(h.s.Start+at, 0, 1, h.index, bad)
	o.ATR, o.E01.ATR = 200, 200
	line := h.index + 20
	h.index++
	batch := h.src.step(stamp(o, line), news)
	if err := h.b.OnNativeStep(o, line, []finance.NativeBatch{batch}); err != nil {
		panic(err)
	}
}

// grid は寿命枝を検査する人工採否を一括配送します。
//
// 引数: at(float64),known/allow(bool)は時計/未知/人工成立です。
// 返り値: ありません。実テクニカル成立とは主張しません。
func (h *harness) grid(at float64, known, allow bool) {
	id := fmt.Sprintf("%064x", int(at))
	err := h.b.OnCompositeEntryGrid(h.s.Start+at, id, func(in finance.EntryBatchInput) (finance.EntryBatchOutput, error) {
		out := finance.EntryBatchOutput{SnapshotID: in.SnapshotID, Decisions: []finance.EntryBatchDecision{}}
		for _, c := range in.Candidates {
			out.Decisions = append(out.Decisions, finance.EntryBatchDecision{Candidate: c, Decision: finance.GateDecision{Policy: finance.CompositeGatePolicy, SnapshotID: in.SnapshotID, Known: known, Allowed: allow, Role: "人工寿命採否", Reason: "寿命だけを分離する手製採否"}})
		}
		return out, nil
	})
	if err != nil {
		panic(err)
	}
}

// finish は元Force又はEOFだけで金融を完結させます。
//
// 引数: force(bool)はSource timerの有無です。
// 返り値: map[string]anyは会計/時計/外監査と検査専用の明示scopeです。
func (h *harness) finish(force bool) map[string]any {
	if force {
		batch := h.src.force(h.s.ForceClose)
		if err := h.b.OnNativeForce(h.s.ForceClose, []finance.NativeBatch{batch}); err != nil {
			panic(err)
		}
		h.feed(h.s.ForceClose-h.s.Start+1, false)
	}
	book, err := h.b.Finish()
	if err != nil {
		panic(err)
	}
	return map[string]any{"scope": "人工Source/気配/採否。L1金融適格と寿命だけの単体用。純テクニカル判定は別のCore288冊で検査する。", "book": book, "clock": h.b.ClockAudit(), "composite": h.b.CompositeAudit()}
}

// main は市場入力なしの六器具を標準出力へ保存可能なJSONとして返します。
//
// 引数: なし。
// 返り値: ありません。標準出力は人工だけです。
func main() {
	result := map[string]any{}
	h := create()
	h.feed(601, false, birth("予約解消", 1, 7))
	h.feed(602, false)
	h.grid(1200, true, false)
	h.feed(1201, false, closeSignal("部分予約", "玉-予約解消", 1, 2))
	h.feed(1202, false)
	h.grid(1500, true, true)
	result["予約解消後も失効"] = h.finish(true)
	h = create()
	h.feed(601, false, birth("未知Force", 1, 3))
	h.feed(602, false)
	h.grid(1200, false, false)
	result["未知からForce"] = h.finish(true)
	h = create()
	h.feed(601, false, birth("待機EOF", 1, 3))
	h.feed(602, false)
	h.grid(1200, true, false)
	h.feed(1201, false, closeSignal("EOF元完結", "玉-待機EOF", 1, 3))
	h.feed(1202, false)
	result["待機からEOF"] = h.finish(false)
	h = create()
	h.feed(601, false, birth("配賦A", 1, 6), birth("配賦B", 1, 6), birth("配賦C", 1, 2))
	h.feed(602, false)
	h.grid(1200, true, true)
	h.feed(1201, false)
	h.feed(1202, false, closeSignal("配賦A終了", "玉-配賦A", 1, 6))
	h.feed(1203, false)
	h.grid(1500, true, true)
	h.feed(1501, false)
	result["後配賦満杯から初回取得"] = h.finish(true)
	h = create()
	h.feed(601, false, birth("未取得気配", 1, 3))
	h.grid(1200, true, true)
	h.feed(1201, false)
	h.feed(1499, true)
	h.grid(1500, true, true)
	h.feed(1799, false)
	h.grid(1800, true, true)
	h.feed(1801, false)
	result["Source未取得と気配未知"] = h.finish(true)
	h = create()
	h.feed(601, false, birth("受理lock", 1, 4))
	h.feed(602, false)
	h.grid(1200, true, true)
	h.feed(1201, true, closeSignal("取消原因", "玉-受理lock", 1, 1))
	h.feed(1202, false)
	h.grid(1500, true, true)
	result["受理取消後も再参加禁止"] = h.finish(true)
	if err := json.NewEncoder(os.Stdout).Encode(result); err != nil {
		panic(err)
	}
}
