package minivariableguard

import (
	"encoding/json"
	"fmt"
	"math"
	"reflect"
	"strconv"
	"strings"
)

// WidthTruth は必要未知と既知不成立を区別する停止純式の型です。
type WidthTruth struct {
	Known  bool  `json:"known"`
	Passed *bool `json:"passed"`
}

// WidthObservation は外部で因果/品質検査済みのC/M/P一公表です。指標を作りません。
type WidthObservation struct {
	Session       string     `json:"session"`
	Contract      string     `json:"contract"`
	Side          int        `json:"side"`
	PublicationID string     `json:"publication_id"`
	Ordinal       int        `json:"ordinal"`
	End           float64    `json:"end"`
	AvailableAt   float64    `json:"available_at"`
	C             WidthTruth `json:"c"`
	M             WidthTruth `json:"m"`
	P             WidthTruth `json:"p"`
	FrameSHA      string     `json:"frame_sha256"`
	ResultSHA     string     `json:"result_sha256"`
}

// WidthState は一実玉の幅状態だけを持ち、ActualResultへ混入しません。
type WidthState struct {
	Policy          string            `json:"policy"`
	Session         string            `json:"session"`
	Contract        string            `json:"contract"`
	Side            int               `json:"side"`
	EntryPrice      float64           `json:"entry_price"`
	Active          bool              `json:"active"`
	ATRLock         *float64          `json:"atr_lock"`
	Peak            *float64          `json:"peak_points"`
	Floor           *float64          `json:"floor_points"`
	Narrowed        bool              `json:"narrowed"`
	NarrowedAt      *float64          `json:"narrowed_at"`
	NarrowedBy      *string           `json:"narrowed_by"`
	Latest          *WidthObservation `json:"latest"`
	LastObservation *WidthObservation `json:"last_observation"`
	Consumed        *string           `json:"consumed_publication"`
	LastAt          *float64          `json:"last_at"`
	Sequence        int               `json:"sequence"`
	Finished        bool              `json:"finished"`
}

// WidthMark は正常mark又は公表/resetの純入力で、Sourceや注文を含みません。
type WidthMark struct {
	At          float64           `json:"at"`
	Sequence    int               `json:"sequence"`
	Mark        *float64          `json:"mark_price"`
	LDActive    bool              `json:"ld10_active"`
	ATRLock     *float64          `json:"atr_lock"`
	Observation *WidthObservation `json:"observation"`
	ResetReason *string           `json:"reset_reason"`
}

// WidthUpdate は停止Python純stateと同型の返り値です。
type WidthUpdate struct {
	State     WidthState `json:"state"`
	Width     *float64   `json:"width_points"`
	Condition WidthTruth `json:"condition"`
	Used      *string    `json:"used_publication"`
	Reason    string     `json:"reason"`
}

// widthPointer は値を共有しない小さいpointerを作ります。
//
// 引数: value(T)は値型です。返り値: *Tは独立した値です。
func widthPointer[T any](value T) *T { return &value }

// WidthPublicationID は停止Python identityと同じUnix秒の公表識別を作ります。
//
// 引数: session/contract(string)、end(float64)は場・限月・終端です。
// 返り値: stringはUTF-8 JSON配列識別です。有限値確認は呼出元の責任です。
func WidthPublicationID(session, contract string, end float64) string {
	a, _ := json.Marshal(session)
	c, _ := json.Marshal(contract)
	v := strconv.FormatFloat(end, 'f', -1, 64)
	if !strings.Contains(v, ".") {
		v += ".0"
	}
	return "[" + string(a) + "," + string(c) + "," + v + "]"
}

// validateWidthObservation は公表境界型だけを検査します。
//
// 引数: o(WidthObservation)は既に外部品質検査済みの結果です。
// 返り値: errorは型/ID/未来公表を隠す値の破損です。C/M/Pを再計算しません。
func validateWidthObservation(o WidthObservation) error {
	if o.Session == "" || o.Contract == "" || (o.Side != 1 && o.Side != -1) || o.Ordinal < 1 || !finiteActual(o.End, o.AvailableAt) || o.End < 0 || o.AvailableAt != o.End || o.PublicationID != WidthPublicationID(o.Session, o.Contract, o.End) {
		return fmt.Errorf("公表ID/場/方向/時計が不正")
	}
	for _, v := range []WidthTruth{o.C, o.M, o.P} {
		if v.Known != (v.Passed != nil) {
			return fmt.Errorf("C/M/P三値型が不正")
		}
	}
	for _, h := range []string{o.FrameSHA, o.ResultSHA} {
		if len(h) != 64 || strings.Trim(h, "0123456789abcdef") != "" {
			return fmt.Errorf("公表出典SHAが不正")
		}
	}
	return nil
}

// NewWidthState は一玉の実建値と方向だけを束縛します。
//
// 引数: policy/session/contract(string)、side(int)、price(float64)はW0/W1/W2・場・限月・方向・実建値です。
// 返り値: WidthState/errorは未起動状態又は不正値です。
func NewWidthState(policy, session, contract string, side int, price float64) (WidthState, error) {
	s := WidthState{Policy: policy, Session: session, Contract: contract, Side: side, EntryPrice: price}
	if (policy != "W0" && policy != "W1" && policy != "W2") || session == "" || contract == "" || (side != 1 && side != -1) || !finiteActual(price) || price <= 0 {
		return s, fmt.Errorf("幅state初期条件が不正")
	}
	return s, nil
}

// Widths は固定native ATRから旧丸めの通常/狭幅を得ます。
//
// 引数: atr(*float64)は固定ATR値又は未知です。
// 返り値: *float64/*float64/errorは2ATR/1ATR幅（5pt切上げ）又は拒否です。
func Widths(atr *float64) (*float64, *float64, error) {
	if atr == nil {
		return nil, nil, nil
	}
	if !finiteActual(*atr, 2**atr) || *atr <= 0 {
		return nil, nil, fmt.Errorf("固定ATRが不正")
	}
	return widthPointer(math.Max(5, 5*math.Ceil(2**atr/5))), widthPointer(math.Max(5, 5*math.Ceil(*atr/5))), nil
}

// widthAnd は既知否定を優先する三値ANDを計算します。
//
// 引数: values([]WidthTruth)は必要なC/M又はC/M/Pです。
// 返り値: WidthTruthは既知否定/全成立/必要未知です。
func widthAnd(values ...WidthTruth) WidthTruth {
	all := true
	for _, v := range values {
		if v.Known && !*v.Passed {
			return WidthTruth{true, widthPointer(false)}
		}
		all = all && v.Known
	}
	if all {
		return WidthTruth{true, widthPointer(true)}
	}
	return WidthTruth{}
}

// AdvanceWidth は停止ec8dのPython規則を小Go状態で同じ順に純更新します。
//
// 引数: state(WidthState)、in(WidthMark)は旧状態と正常mark/外部公表です。
// 返り値: WidthUpdate/errorは次状態・選択幅・出典又は不正値です。注文/数量/費用は扱いません。
func AdvanceWidth(state WidthState, in WidthMark) (WidthUpdate, error) {
	out := WidthUpdate{}
	if state.Finished || !finiteActual(in.At) || in.At < 0 || in.Sequence <= state.Sequence || (state.LastAt != nil && in.At < *state.LastAt) || (state.Active && !in.LDActive) || (in.ResetReason != nil && *in.ResetReason == "") {
		return out, fmt.Errorf("幅stateの時計/終玉/起動逆転が不正")
	}
	s := valueCopy(state)
	if in.ATRLock != nil {
		if _, _, e := Widths(in.ATRLock); e != nil {
			return out, e
		}
		if s.ATRLock != nil && *in.ATRLock != *s.ATRLock {
			return out, fmt.Errorf("固定ATRの変更は禁止")
		}
		s.ATRLock = widthPointer(*in.ATRLock)
	}
	normal, narrow, e := Widths(s.ATRLock)
	if e != nil {
		return out, e
	}
	if in.ResetReason != nil {
		s.Latest = nil
	}
	if in.Observation != nil {
		o := valueCopy(*in.Observation)
		if e := validateWidthObservation(o); e != nil {
			return out, e
		}
		if o.Session != s.Session || o.Contract != s.Contract || o.Side != s.Side || o.End > in.At || o.AvailableAt > in.At {
			return out, fmt.Errorf("別場/限月/方向又は未来公表")
		}
		if s.LastObservation != nil && o.PublicationID == s.LastObservation.PublicationID {
			if !reflect.DeepEqual(o, *s.LastObservation) {
				return out, fmt.Errorf("同公表の値変更")
			}
		} else {
			if s.LastObservation != nil && (o.End <= s.LastObservation.End || o.Ordinal <= s.LastObservation.Ordinal) {
				return out, fmt.Errorf("既処理以前の公表")
			}
			s.Latest = widthPointer(o)
			s.LastObservation = widthPointer(o)
		}
	}
	if in.Mark != nil {
		if !finiteActual(*in.Mark) || *in.Mark <= 0 {
			return out, fmt.Errorf("正常markが不正")
		}
		gain := float64(s.Side) * (*in.Mark - s.EntryPrice)
		if !finiteActual(gain) {
			return out, fmt.Errorf("価格差が非有限")
		}
		if s.Peak == nil || gain > *s.Peak {
			s.Peak = widthPointer(gain)
		}
	} else if in.LDActive && !s.Active {
		return out, fmt.Errorf("初回起動に正常markがない")
	}
	s.Active = s.Active || in.LDActive
	reason := "起動前は観測を保管だけ"
	condition := WidthTruth{}
	var used *string
	if s.Active {
		reason = "新公表なし・直前幅を保持"
		if s.Policy == "W0" {
			condition = WidthTruth{true, widthPointer(false)}
			reason = "W0通常幅"
		} else if s.Latest != nil && (s.Consumed == nil || s.Latest.PublicationID != *s.Consumed) && in.Mark != nil {
			o := s.Latest
			condition = widthAnd(o.C, o.M)
			if s.Policy == "W2" {
				condition = widthAnd(o.C, o.M, o.P)
			}
			s.Consumed = widthPointer(o.PublicationID)
			used = widthPointer(o.PublicationID)
			reason = "複合不成立"
			if !condition.Known {
				reason = "必要未知"
			}
			if condition.Known && *condition.Passed {
				if narrow == nil {
					reason = "固定ATR未知・狭幅を作らない"
				} else if !s.Narrowed {
					s.Narrowed = true
					s.NarrowedAt = widthPointer(in.At)
					s.NarrowedBy = widthPointer(o.PublicationID)
					reason = "複合成立で初回狭幅化"
				} else {
					reason = "終玉まで狭幅を保持"
				}
			}
		}
	}
	width := normal
	if s.Narrowed {
		width = narrow
	}
	if s.Active {
		floor := 0.0
		if s.Floor != nil {
			floor = math.Max(floor, *s.Floor)
		}
		if s.Peak != nil && width != nil {
			floor = math.Max(floor, *s.Peak-*width)
		}
		s.Floor = widthPointer(floor)
	} else {
		width = nil
	}
	s.LastAt = widthPointer(in.At)
	s.Sequence = in.Sequence
	return WidthUpdate{s, width, condition, used, reason}, nil
}
