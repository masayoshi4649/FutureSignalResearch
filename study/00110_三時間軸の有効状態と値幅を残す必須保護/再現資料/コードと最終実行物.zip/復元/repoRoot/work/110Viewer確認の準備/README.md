# 110のViewer API確認準備

Rootが新規専用8094を起動し、全70の金融・独立保存・正式一覧の指紋を渡した後に実行する。8092と旧8093には接続せず、serverの起動・停止・設定変更を行うコードも持たない。

確認範囲は一覧2520資源の全ID照合、および事前に固定した2026-11-06 Day/Nightの72資源（36設定×2場）の実GETである。APIの費用後実現純額、実約定行数、最終買残・売残・未実現損益0を正式保存値と照合する。全2520資源のGETや、チャート描画・ブラウザ視認を確認したとは扱わない。

109の専用Viewer確認を設計参照し、108の固定helperから `verify_response` だけを再用する。108/106の旧API要求関数は呼ばず、旧BASEも書き換えない。新通信先はコード上 `http://127.0.0.1:8094` に固定する。

Root固定JSONは以下を持つ。Refは `path`・`sha256`（任意で `bytes`）である。

```json
{
  "version": 1,
  "trial": 110,
  "fixed": true,
  "stage": "full70",
  "saved_ready": true,
  "selected_sessions": ["2026-11-06_Day", "2026-11-06_Night"],
  "condition": {"path": "...", "sha256": "..."},
  "completion": {"path": "...", "sha256": "..."},
  "summary": {"path": ".../結果.json", "sha256": "..."},
  "saved_check": {"path": ".../保存会計の確認.json", "sha256": "..."},
  "saving_fixed": {"path": ".../全70場_中断後の同条件再実行.json", "sha256": "..."},
  "saving_stop": {"path": ".../停止.json", "sha256": "2cd0b49558e04ebad22a1dedeca99fd50dc4c77044b480786ffc67fe69b648f6"},
  "catalog": {"path": ".../一覧.resources.json", "sha256": "..."},
  "code": {"path": ".../Viewerを確認する.py", "sha256": "..."},
  "server": {
    "base": "http://127.0.0.1:8094",
    "exe": {"path": ".../session-trade-viewer.exe", "sha256": "..."},
    "config": {"path": ".../conf/viewer.toml", "sha256": "..."},
    "startup": {"path": ".../起動.json", "sha256": "..."}
  }
}
```

起動記録には `新規専用起動:true`、正整数の `PID`、`port:8094`、`元8092の停止再起動設定変更:0`、`exe`・`config` のSHA256を記す。PIDの過去値を現在の稼働証明としない。Rootが実プロセスを確認し、このhelperは固定済み起動記録の照合に加えて新8094の実API応答を確認する。

設定内容は旧108専用8093の設定から `server.listen` だけを8094へ変更した値に限る。exeは同じ固定実行物である。設定は読み取りのみで変更しない。

```powershell
python -B -X utf8 work/110Viewer確認の準備/人工検査.py
python -B -X utf8 work/110Viewer確認の準備/Viewerを確認する.py --run --fixed <Root固定JSON> --fixed-sha <期待SHA256> --out <未使用の確認JSON>
```

人工検査は手製2520一覧と手製API応答型だけで行う。実結果・実trades・実価格・Native・11月09日入力は読まず、HTTPも呼ばない。
