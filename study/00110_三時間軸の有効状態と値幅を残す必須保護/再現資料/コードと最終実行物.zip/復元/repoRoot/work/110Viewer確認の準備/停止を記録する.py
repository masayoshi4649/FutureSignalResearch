"""110Viewerの人工検査と再用純検算を認証して準備状態を停止する。"""

import ast
import json
from pathlib import Path

import Viewerを確認する as V


def main():
    """
    機能: 人工検査の成功と全code指紋を認証して停止metadataを新規保存する。

    引数: なし。
    返り値: None。実市場・HTTP・server操作を行わない。
    """
    path = V.OWN / '人工確認.json'
    proof = V.load(path)
    assert proof['成功'] and proof['主'] == 7 and proof['前後不変']
    assert (proof['metadata拒否'], proof['server拒否'], proof['応答拒否']) == (14, 6, 4)
    assert proof['実API/実取引/価格/Native/11月09日読取'] == proof['server起動停止設定変更'] == 0
    for name, expected in proof['所有コードSHA256'].items():
        assert V.sha(Path(name)) == expected
    files = sorted(V.OWN.glob('*.py')) + [V.OWN / 'README.md']
    owned = {str(name): V.sha(name) for name in files}
    for name in files:
        if name.suffix != '.py':
            continue
        for node in ast.walk(ast.parse(name.read_text(encoding='utf-8'))):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                text = ast.get_docstring(node)
                assert text and node.body[0].end_lineno > node.body[0].lineno
                assert all(word in text for word in ('機能:', '引数:', '返り値:'))
    reused = {str(V.ROOT / name): expected for name, expected in V.REUSED.items()}
    assert all(V.sha(Path(name)) == expected for name, expected in reused.items())
    assert V.sha(V.CONFIG_PATH) == V.CONFIG_SHA
    value = {'version': 1, 'trial': 110, '成功': True, '停止': True,
             'scope': '非市場の手製2520一覧と固定72選択/応答型。Root固定後の8094実GETは未実施',
             '所有コードSHA256': owned, '再用コードSHA256': reused,
             '設定参照': {'path': str(V.CONFIG_PATH), 'sha256': V.CONFIG_SHA},
             '人工確認': {'path': str(path), 'sha256': V.sha(path)},
             '前後不変': True, '主': 7, 'metadata拒否': 14, 'server拒否': 6, '応答拒否': 4,
             '一覧予定': 2520, '実GET予定': 72, '選択場': list(V.SESSIONS), '通信先': V.BASE,
             '実API/実取引/価格/Native/11月09日読取': 0, 'server起動停止設定変更': 0}
    target = V.OWN / '停止.json'
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    assert owned == {str(name): V.sha(name) for name in files}
    print(json.dumps({'成功': True, '停止': str(target), 'SHA256': V.sha(target), '実API': 0}, ensure_ascii=False))


if __name__ == '__main__':
    main()
