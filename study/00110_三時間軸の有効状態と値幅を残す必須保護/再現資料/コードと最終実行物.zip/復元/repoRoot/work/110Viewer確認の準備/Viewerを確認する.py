"""Root固定後だけ新専用8094で110の一覧2520と事前固定72GETを照合する。"""

import argparse
from concurrent.futures import ThreadPoolExecutor
import copy
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import tomllib
from urllib.parse import urlencode
from urllib.request import Request, urlopen

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
BASE = 'http://127.0.0.1:8094'
SESSIONS = ('2026-11-06_Day', '2026-11-06_Night')
KEYS = tuple(f'{entry}_{guard}_C{cost}_D{delay}' for entry in ('entry_E0', 'entry_E2_L0', 'entry_E2_L1')
             for guard in ('G0', 'G3', 'G4') for cost in (0, 5) for delay in (0, 1))
CONDITION_SHA = 'e0f84c5f836a3cb58b6d75c12f08c40e910b661043516e1e642143b6026b9fba'
SAVING_SHA = '2cd0b49558e04ebad22a1dedeca99fd50dc4c77044b480786ffc67fe69b648f6'
EXE_SHA = '0ed329e06293f55a99ab1dc503e32cc104285319316ef41b81b59470dce9d0e8'
CONFIG_PATH = ROOT / 'work/108専用Viewer8093/conf/viewer.toml'
CONFIG_SHA = 'b065b7b708474aaa6c68d03195d8635cfe53ba70c0122f1ff22def9535116815'
REUSED = {
    'work/109進行/Viewer8093を確認する.py': '10279fe2161634e730b546a5f4e0f9d5d1038a04bc54435e979ff6a8fa03ca85',
    'work/108Viewer確認の準備/Viewerを確認する.py': '94c01ad7a413fc54364c20bac8d51b7dbb6660d4aa2bc1db0b3fb8bfa1264b71',
    'work/107Viewer確認の準備/Viewerを確認する.py': 'b350b2f77f77fed5ab0c270078bd48bd1e04c67d096250c69bf745e1cc848570',
    'work/106進行/Viewerの20資源を確認する.py': 'b068ddffee9884109a1d5a18306700735327c2dd7e85fd3c4fe237107051f315',
}


def sha(path):
    """
    機能: 明示した固定metadata・code・選択tradesの全バイト指紋を取得する。

    引数: path(Path)はRoot許可済みの非原板ファイル。
    返り値: strはSHA256。Raw/価格CSV/Nativeを渡さない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    """
    機能: 金額の半円をDecimalで保持してJSONを読む。

    引数: path(Path)は認証済みJSON。
    返り値: dictは元値。
    """
    return json.loads(path.read_text(encoding='utf-8-sig'), parse_float=Decimal)


def bind(value, base, before, parse=True):
    """
    機能: 明示Refの全バイト指紋を認証し前指紋へ加える。

    引数: value(dict)、base(Path)、before(dict)、parse(bool)はRef・基準・台帳・JSON指定。
    返り値: tuple[Path,dict|None]は絶対pathと任意のJSON値。
    """
    assert set(value) in ({'path', 'sha256'}, {'path', 'sha256', 'bytes'})
    assert isinstance(value['sha256'], str) and re.fullmatch('[0-9a-f]{64}', value['sha256'])
    path = (base / value['path']).resolve()
    assert sha(path) == value['sha256']
    if 'bytes' in value:
        assert path.stat().st_size == value['bytes']
    assert str(path) not in before or before[str(path)] == value['sha256']
    before[str(path)] = value['sha256']
    return path, load(path) if parse else None


def load_verifier(before):
    """
    機能: 旧108の純応答検算だけを固定コードから取得する。

    引数: before(dict)は再用コードの指紋台帳。
    返り値: moduleはverify_responseの所有module。旧API要求は呼ばない。
    """
    for name, expected in REUSED.items():
        path = ROOT / name
        assert sha(path) == expected
        before[str(path)] = expected
    path = ROOT / 'work/108Viewer確認の準備/Viewerを確認する.py'
    spec = importlib.util.spec_from_file_location('110が使う旧Viewerの純検算', path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    assert helper.OLD.BASE == 'http://127.0.0.1:8092'
    return helper


def validate_values(values, fixed):
    """
    機能: 110全70金融・保存・36×70一覧をHTTP前に検査する。

    引数: values(dict)は各認証JSON、fixed(dict)はRoot固定metadata。
    返り値: tuple[list,list]は全資源と72件の資源/費用後純額。
    """
    condition, complete, summary, check, catalog, saving, stopped = (values[name] for name in
        ('condition', 'completion', 'summary', 'saved_check', 'catalog', 'saving_fixed', 'saving_stop'))
    assert fixed['condition']['sha256'] == CONDITION_SHA and fixed['saving_stop']['sha256'] == SAVING_SHA
    assert condition['version'] == 1 and condition['trial'] == 110 and condition['fixed'] is True and len(condition['configs']) == 36
    assert complete['version'] == 1 and complete['trial'] == 110 and complete['stage'] == 'full70' and complete['success'] is True
    assert (complete['sessions'], complete['books_per_scene'], complete['books'], complete['shadow_books'], complete['baseline_comparisons']) == (70, 36, 2520, 0, 280)
    assert complete['condition_sha256'] == CONDITION_SHA and complete['unchanged'] and complete['before'] and complete['before'] == complete['after']
    assert summary['試行'] == 110 and summary['成功'] and summary['stage'] == 'full70' and (summary['場数'], summary['会計数']) == (70, 2520)
    assert tuple(summary['主key']) == KEYS
    assert check['成功'] and (check['会計'], check['資源'], check['旧対照'], check['不一致数']) == (2520, 2520, 280, 0)
    assert stopped['trial'] == 110 and stopped['停止'] and len(stopped['コードSHA256']) == 20
    assert saving['version'] == 1 and saving['trial'] == 110 and saving['fixed'] is True and saving['stage'] == 'full70'
    assert saving['condition']['sha256'] == CONDITION_SHA and saving['completion']['sha256'] == fixed['completion']['sha256']
    assert saving['saving_stop']['sha256'] == SAVING_SHA and saving['code_sha256'] == stopped['コードSHA256']
    for value in (summary, check):
        assert value['前後不変'] and value['入力codeSHA256前'] and value['入力codeSHA256前'] == value['入力codeSHA256後']
        assert value['金融条件SHA256'] == CONDITION_SHA and value['金融完了SHA256'] == fixed['completion']['sha256']
        assert value['Root固定SHA256'] == fixed['saving_fixed']['sha256']
        assert all(value['入力codeSHA256前'].get(path) == expected for path, expected in stopped['コードSHA256'].items())
    assert check['出力SHA256']['結果.json'] == fixed['summary']['sha256'] and check['出力SHA256']['一覧.resources.json'] == fixed['catalog']['sha256']
    assert catalog['schema_version'] == 1 and catalog['path_base'] == 'catalog'
    rows = summary['場別']
    expected = {(row['session'], row['key']): row['net_yen'] for row in rows}
    assert len(expected) == len(rows) == 2520
    sessions = sorted({session for session, _ in expected})
    assert len(sessions) == 70 and sessions[0] == '2026-09-21_Day' and sessions[-1] == '2026-11-06_Night'
    assert set(expected) == {(session, key) for session in sessions for key in KEYS}
    assert set(SESSIONS).issubset(sessions)
    resources = catalog['resources']
    assert len(resources) == len({row['id'] for row in resources}) == 2520
    indexed = {}
    for resource in resources:
        session, key = resource['session'], resource['method_id']
        assert (session, key) in expected and (session, key) not in indexed
        identity = f'110_{key}_{session}'
        assert resource['id'] == identity and resource['title'] == f'三時間軸の有効状態と値幅保護 {key} {session}'
        assert resource['symbol'] == 'NK225' and resource['product'] == 'NK225mini' and resource['point_value'] == 100
        assert resource['pnl_format'] == 'trades' and resource['pnl_basis'] == 'net' and resource['pnl_path'] == identity + '.trades.jsonl'
        indexed[session, key] = resource
    return resources, [(indexed[session, key], expected[session, key]) for session in SESSIONS for key in KEYS]


def validate_server(startup, config, old_config, server):
    """
    機能: 新専用8094の起動記録とlistenだけ変更した設定を照合する。

    引数: startup/config/old_config/server(dict)は新起動・新旧TOML・固定Ref。
    返り値: None。起動PIDの過去記録を稼働証明としない。
    """
    assert server['base'] == BASE and server['exe']['sha256'] == EXE_SHA
    assert startup['新規専用起動'] is True and type(startup['PID']) is int and startup['PID'] > 0
    assert startup['port'] == 8094 and startup['元8092の停止再起動設定変更'] == 0
    assert startup['exe'] == server['exe']['sha256'] and startup['config'] == server['config']['sha256']
    expected = copy.deepcopy(old_config)
    assert expected['server']['listen'] == '127.0.0.1:8093'
    expected['server']['listen'] = '127.0.0.1:8094'
    assert config == expected
    assert Path(config['paths']['resource_root']).resolve() == ROOT
    assert Path(config['paths']['data_root']).resolve() == (ROOT.parent / 'JP_OSE_Data/future').resolve()


def prepare(fixed_path, fixed_sha, destination):
    """
    機能: Rootの成功後固定を全SHAで認証して初めてHTTP用計画を返す。

    引数: fixed_path/destination(Path)、fixed_sha(str)はRoot固定・新規先・期待指紋。
    返り値: dictは全一覧・固定72・前指紋と純検算module。HTTPはまだ呼ばない。
    """
    assert not destination.exists() and sha(fixed_path) == fixed_sha
    fixed = load(fixed_path)
    assert fixed['version'] == 1 and fixed['trial'] == 110 and fixed['fixed'] is True and fixed['stage'] == 'full70' and fixed['saved_ready'] is True
    assert tuple(fixed['selected_sessions']) == SESSIONS and fixed['server']['base'] == BASE
    before = {str(fixed_path): fixed_sha}
    parsed = {name: bind(fixed[name], fixed_path.parent, before, name != 'code') for name in
              ('condition', 'completion', 'summary', 'saved_check', 'saving_fixed', 'saving_stop', 'catalog', 'code')}
    assert parsed['code'][0] == Path(__file__).resolve()
    values = {name: item[1] for name, item in parsed.items()}
    resources, selected = validate_values(values, fixed)
    server = fixed['server']
    server_paths = {name: bind(server[name], fixed_path.parent, before, name == 'startup') for name in ('exe', 'config', 'startup')}
    assert sha(CONFIG_PATH) == CONFIG_SHA
    before[str(CONFIG_PATH)] = CONFIG_SHA
    config = tomllib.loads(server_paths['config'][0].read_text(encoding='utf-8-sig'))
    old_config = tomllib.loads(CONFIG_PATH.read_text(encoding='utf-8-sig'))
    validate_server(server_paths['startup'][1], config, old_config, server)
    helper = load_verifier(before)
    for name, expected in values['saving_stop']['コードSHA256'].items():
        assert sha(Path(name)) == expected
        before[name] = expected
    catalog = parsed['catalog'][0]
    catalog.relative_to(ROOT)
    for resource, _ in selected:
        path = (catalog.parent / resource['pnl_path']).resolve()
        assert path.parent == catalog.parent
        expected = values['saved_check']['出力SHA256'][resource['pnl_path']]
        assert sha(path) == expected
        before[str(path)] = expected
    return {'catalog': catalog, 'resources': resources, 'selected': selected, 'before': before, 'helper': helper, 'fixed_sha': fixed_sha}


def request(route, payload=None):
    """
    機能: 新専用8094のinfo・一覧load・固定資源dataだけを呼ぶ。

    引数: route(str)、payload(dict|None)は許可APIと正式一覧参照。
    返り値: tuple[dict,str]はDecimal保持の応答と本文SHA256。
    """
    assert route in ('/api/info', '/api/catalogs/load') or route.startswith('/api/data?')
    raw = None if payload is None else json.dumps(payload).encode('utf-8')
    query = Request(BASE + route, data=raw, headers={'Content-Type': 'application/json'})
    with urlopen(query, timeout=60) as response:
        body = response.read()
        digest = hashlib.sha256(body).hexdigest()
        assert response.headers.get('x-chart-data-sha256', digest) == digest
        return json.loads(body, parse_float=Decimal), digest


def run(fixed_path, fixed_sha, destination):
    """
    機能: 固定後に2520一覧IDと代表72資源のAPI純額・実約定行・残0を照合する。

    引数: fixed_path/destination(Path)、fixed_sha(str)はRoot固定・新規先・期待指紋。
    返り値: dictは限定範囲の確認。全資源描画やブラウザ視認ではない。
    """
    plan = prepare(fixed_path, fixed_sha, destination)
    info, info_sha = request('/api/info')
    assert Path(info['resource_root']).resolve() == ROOT
    assert Path(info['data_root']).resolve() == (ROOT.parent / 'JP_OSE_Data/future').resolve()
    loaded, catalog_sha = request('/api/catalogs/load', {'path': plan['catalog'].relative_to(ROOT).as_posix()})
    assert len(loaded['resources']) == 2520 and {row['id'] for row in loaded['resources']} == {row['id'] for row in plan['resources']}

    def check(item):
        """
        機能: 事前固定した一資源の実約定とAPI応答を照合する。

        引数: item(tuple[dict,Decimal])は資源と保存純額。
        返り値: dictはAPI限定証拠。価格の順行・描画を評価しない。
        """
        resource, net = item
        path = plan['catalog'].parent / resource['pnl_path']
        original = path.read_bytes()
        query = urlencode({'catalog': loaded['catalog_id'], 'resource': resource['id'], 'width': 1, 'interval': 'raw', 'price': 'last'})
        value, digest = request('/api/data?' + query)
        plan['helper'].verify_response(value, resource['id'], net, len(original.splitlines()))
        assert path.read_bytes() == original
        return {'id': resource['id'], '純額': net, '実約定行': len(value['events']), '応答SHA256': digest}

    with ThreadPoolExecutor(max_workers=4) as pool:
        details = list(pool.map(check, plan['selected']))
    after = {name: sha(Path(name)) for name in plan['before']}
    assert after == plan['before'] and plan['helper'].OLD.BASE == 'http://127.0.0.1:8092'
    proof = {'成功': True, '試行': 110, '一覧': 2520, '実GET': 72, '選択場': list(SESSIONS),
             'scope': '一覧全IDと11/06日夜72資源APIの純額/約定行/残0。全2520GET/描画/ブラウザ視認ではない',
             'server': BASE, 'info応答SHA256': info_sha, '一覧応答SHA256': catalog_sha, 'details': details,
             'Root固定SHA256': fixed_sha, '入力SHA256前': plan['before'], '入力SHA256後': after, '前後不変': True,
             '旧8092操作': 0, '旧8093操作': 0, 'server停止再起動設定変更': 0, '金融再実行': 0,
             'ローカルRaw_CSV_Tape_Native読取': 0, '未使用11月09アクセス': 0}
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2, default=float)
        stream.write('\n')
    return {'成功': True, '一覧': 2520, '実GET': 72, '差': 0, '証拠SHA256': sha(destination)}


def main():
    """
    機能: --runとRoot固定Refが揃ったときだけ専用8094の確認を実行する。

    引数: --fixed/--fixed-sha/--outはRoot固定path・期待SHA・未使用証拠先。
    返り値: None。引数なし・未固定はHTTP前に拒否する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true', required=True)
    parser.add_argument('--fixed', type=Path, required=True)
    parser.add_argument('--fixed-sha', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(run(args.fixed.resolve(), args.fixed_sha, args.out.resolve()), ensure_ascii=False))


if __name__ == '__main__':
    main()
