"""手製2520一覧・手製応答型だけで110Viewer確認の範囲を検査する。"""

import ast
import copy
from datetime import date, timedelta
from decimal import Decimal
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import Viewerを確認する as V


def fixture():
    """
    機能: 価格を含まない手製70場×36設定のmetadataを生成する。

    引数: なし。
    返り値: tuple[dict,dict]は純検査用の値と固定schema。
    """
    dates = []
    current = date(2026, 9, 21)
    while current <= date(2026, 11, 6):
        if current.weekday() < 5:
            dates.extend((current.isoformat() + '_Day', current.isoformat() + '_Night'))
        current += timedelta(days=1)
    code = {f'手製コード{i}': 'a' * 64 for i in range(20)}
    fixed = {name: {'path': '手製_' + name + '.json', 'sha256': letter * 64} for name, letter in
             (('condition', 'b'), ('completion', 'c'), ('summary', 'd'), ('saved_check', 'e'),
              ('saving_fixed', 'f'), ('saving_stop', 'a'), ('catalog', '0'))}
    fixed['condition']['sha256'] = V.CONDITION_SHA
    fixed['saving_stop']['sha256'] = V.SAVING_SHA
    complete = {'version': 1, 'trial': 110, 'stage': 'full70', 'success': True, 'sessions': 70, 'books_per_scene': 36,
                'books': 2520, 'shadow_books': 0, 'baseline_comparisons': 280, 'condition_sha256': V.CONDITION_SHA,
                'unchanged': True, 'before': dict(code), 'after': dict(code)}
    base = {'前後不変': True, '入力codeSHA256前': dict(code), '入力codeSHA256後': dict(code),
            '金融条件SHA256': V.CONDITION_SHA, '金融完了SHA256': fixed['completion']['sha256'], 'Root固定SHA256': fixed['saving_fixed']['sha256']}
    summary = {**base, '試行': 110, '成功': True, 'stage': 'full70', '場数': 70, '会計数': 2520, '主key': list(V.KEYS),
               '場別': [{'session': session, 'key': key, 'net_yen': Decimal('0.5')} for session in dates for key in V.KEYS]}
    check = {**base, '成功': True, '会計': 2520, '資源': 2520, '旧対照': 280, '不一致数': 0,
             '出力SHA256': {'結果.json': fixed['summary']['sha256'], '一覧.resources.json': fixed['catalog']['sha256']}}
    resources = []
    for session in dates:
        for key in V.KEYS:
            identity = f'110_{key}_{session}'
            resources.append({'id': identity, 'title': f'三時間軸の有効状態と値幅保護 {key} {session}',
                              'session': session, 'method_id': key, 'symbol': 'NK225', 'product': 'NK225mini',
                              'point_value': 100, 'pnl_format': 'trades', 'pnl_basis': 'net', 'pnl_path': identity + '.trades.jsonl'})
    saving = {'version': 1, 'trial': 110, 'fixed': True, 'stage': 'full70', 'condition': fixed['condition'],
              'completion': fixed['completion'], 'saving_stop': fixed['saving_stop'], 'code_sha256': code}
    values = {'condition': {'version': 1, 'trial': 110, 'fixed': True, 'configs': [{} for _ in V.KEYS]},
              'completion': complete, 'summary': summary, 'saved_check': check, 'catalog': {'schema_version': 1, 'path_base': 'catalog', 'resources': resources},
              'saving_fixed': saving, 'saving_stop': {'trial': 110, '停止': True, 'コードSHA256': code}}
    return values, fixed


class Viewer準備検査(unittest.TestCase):
    """実市場なしでスコープ・不正metadata・応答型を検査する。"""

    def test_全一覧と固定72を選択する(self):
        """
        機能: 全2520一覧を保ち11/06日夜の36ずつを選択する。

        引数: self(Viewer準備検査)は検査器。
        返り値: None。
        """
        values, fixed = fixture()
        resources, selected = V.validate_values(values, fixed)
        self.assertEqual(len(resources), 2520)
        self.assertEqual(len(selected), 72)
        self.assertEqual([row['id'] for row, _ in selected], [f'110_{key}_{session}' for session in V.SESSIONS for key in V.KEYS])
        self.assertEqual({net for _, net in selected}, {Decimal('0.5')})

    def test_破損metadataを拒否する(self):
        """
        機能: 部分成功・別条件・重複一覧・誤商品・危険path等を拒否する。

        引数: self(Viewer準備検査)は検査器。
        返り値: None。
        """
        values, fixed = fixture()
        mutations = {
            '金融未完': lambda v: v['completion'].update(success=False),
            '冊数欠落': lambda v: v['completion'].update(books=2519),
            '旧対照不足': lambda v: v['completion'].update(baseline_comparisons=279),
            '金融前後差': lambda v: v['completion'].update(after={}),
            '保存別条件': lambda v: v['saved_check'].update(金融条件SHA256='f' * 64),
            '別保存要求': lambda v: v['summary'].update(Root固定SHA256='0' * 64),
            '保存依存欠落': lambda v: v['saving_stop']['コードSHA256'].pop('手製コード0'),
            '別一覧指紋': lambda v: v['saved_check']['出力SHA256'].update({'一覧.resources.json': 'f' * 64}),
            '一覧重複': lambda v: v['catalog']['resources'].__setitem__(1, v['catalog']['resources'][0]),
            '別namespace': lambda v: v['catalog']['resources'][0].update(id='109_旧ID'),
            '枚数単価差': lambda v: v['catalog']['resources'][0].update(point_value=1000),
            '別商品': lambda v: v['catalog']['resources'][0].update(product='NK225'),
            '危険trades参照': lambda v: v['catalog']['resources'][0].update(pnl_path='../別.trades.jsonl'),
            '別候補集合': lambda v: v['summary']['主key'].__setitem__(0, 'entry_不明'),
        }
        for name, mutate in mutations.items():
            bad = copy.deepcopy(values)
            mutate(bad)
            with self.subTest(name=name), self.assertRaises(AssertionError):
                V.validate_values(bad, fixed)

    def test_新8094とlistenだけの設定差(self):
        """
        機能: 過去PID依存を避け専用8094と同一設定の範囲を検査する。

        引数: self(Viewer準備検査)は検査器。
        返り値: None。実起動Refや実serverへ接続しない。
        """
        old = {'server': {'listen': '127.0.0.1:8093'}, 'paths': {'data_root': str(V.ROOT.parent / 'JP_OSE_Data/future'), 'resource_root': str(V.ROOT)}, 'viewer': {'cache_mb': 64}}
        config = copy.deepcopy(old)
        config['server']['listen'] = '127.0.0.1:8094'
        server = {'base': V.BASE, 'exe': {'sha256': V.EXE_SHA}, 'config': {'sha256': 'a' * 64}}
        startup = {'新規専用起動': True, 'PID': 12345, 'port': 8094, '元8092の停止再起動設定変更': 0, 'exe': V.EXE_SHA, 'config': 'a' * 64}
        V.validate_server(startup, config, old, server)
        for key, value in (('PID', 0), ('PID', True), ('port', 8093), ('元8092の停止再起動設定変更', 1), ('exe', '0' * 64)):
            bad = dict(startup)
            bad[key] = value
            with self.subTest(key=key, value=value), self.assertRaises(AssertionError):
                V.validate_server(bad, config, old, server)
        bad = copy.deepcopy(config)
        bad['viewer']['cache_mb'] = 128
        with self.assertRaises(AssertionError):
            V.validate_server(startup, bad, old, server)

    def test_純応答検算は半円と残0を保つ(self):
        """
        機能: 固定旧helperの純検算だけを使い純額・約定行・残0を検査する。

        引数: self(Viewer準備検査)は検査器。
        返り値: None。旧API関数は呼ばない。
        """
        helper = V.load_verifier({})
        identity = f'110_{V.KEYS[0]}_{V.SESSIONS[0]}'
        response = {'resource': {'id': identity}, 'summary': {'realized_pnl_yen': Decimal('0.5'), 'long_qty': 0, 'short_qty': 0, 'unrealized_pnl_yen': 0}, 'events': [{}, {}]}
        with patch.object(helper.OLD, 'request', side_effect=AssertionError('旧APIを呼ばない')):
            helper.verify_response(response, identity, Decimal('0.5'), 2)
            for name, mutate in (
                ('半円差', lambda v: v['summary'].update(realized_pnl_yen=Decimal('1.0'))),
                ('最終残', lambda v: v['summary'].update(short_qty=1)),
                ('別資源', lambda v: v['resource'].update(id='別資源')),
                ('約定行不足', lambda v: v.update(events=[{}]))):
                bad = copy.deepcopy(response)
                mutate(bad)
                with self.subTest(name=name), self.assertRaises(AssertionError):
                    helper.verify_response(bad, identity, Decimal('0.5'), 2)
        self.assertEqual(helper.OLD.BASE, 'http://127.0.0.1:8092')

    def test_未固定は参照とHTTPの前に拒否する(self):
        """
        機能: 実結果Refを持たない未固定器具をHTTPより前に拒否する。

        引数: self(Viewer準備検査)は検査器。
        返り値: None。
        """
        with tempfile.TemporaryDirectory(prefix='人工_', dir=V.OWN) as name:
            path = Path(name) / '未固定.json'
            path.write_text(json.dumps({'version': 1, 'trial': 110, 'fixed': False, 'stage': 'full70', 'saved_ready': False}), encoding='utf-8')
            with patch.object(V, 'request', side_effect=AssertionError('実HTTP禁止')) as request:
                with self.assertRaises(AssertionError):
                    V.run(path, V.sha(path), Path(name) / '未作成の確認.json')
                request.assert_not_called()

    def test_要求は新8094へ固定する(self):
        """
        機能: 明示API以外を拒否し許可要求も新8094から出さない。

        引数: self(Viewer準備検査)は検査器。
        返り値: None。urlopenを人工応答へ置き換える。
        """
        with patch.object(V, 'urlopen') as opening:
            with self.assertRaises(AssertionError):
                V.request('/api/不明')
            opening.assert_not_called()
            response = opening.return_value.__enter__.return_value
            response.read.return_value = b'{"value":0.5}'
            response.headers = {}
            value, _ = V.request('/api/info')
            self.assertEqual(value['value'], Decimal('0.5'))
            self.assertEqual(opening.call_args.args[0].full_url, 'http://127.0.0.1:8094/api/info')

    def test_関数コメント規約(self):
        """
        機能: 新Python全関数に複数行の機能/引数/返り値を要求する。

        引数: self(Viewer準備検査)は検査器。
        返り値: None。
        """
        for path in V.OWN.glob('*.py'):
            for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    text = ast.get_docstring(node)
                    self.assertTrue(text and node.body[0].end_lineno > node.body[0].lineno, (path.name, node.name))
                    self.assertTrue(all(word in text for word in ('機能:', '引数:', '返り値:')), (path.name, node.name))


def main():
    """
    機能: 非市場の手製検査を実行して小型人工確認を保存する。

    引数: なし。
    返り値: None。実結果・実取引・価格・Native・HTTPを読まない。
    """
    files = sorted(V.OWN.glob('*.py')) + [V.OWN / 'README.md']
    before = {str(path): V.sha(path) for path in files}
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Viewer準備検査))
    assert before == {str(path): V.sha(path) for path in files}
    proof = {'成功': result.wasSuccessful(), '主': result.testsRun, 'scope': '手製2520一覧/72選択と応答型。実一覧・GET・価格ではない',
             '所有コードSHA256': before, '前後不変': True, '再用コードSHA256': V.REUSED,
             'metadata拒否': 14, 'server拒否': 6, '応答拒否': 4, '半円型': True,
             '実API/実取引/価格/Native/11月09日読取': 0, 'server起動停止設定変更': 0}
    with (V.OWN / '人工確認.json').open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    if not result.wasSuccessful():
        raise SystemExit(1)


if __name__ == '__main__':
    main()
