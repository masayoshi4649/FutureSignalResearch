"""105の新4場sym LD10四口座だけを固定104保存算術で整理する。"""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
BASE_PATH = ROOT / "work/104LD10の保存/集計.py"
BASE_SHA = "0409ae3f0f084bedac0196ca5bd62a356c074f7c27e464854f1d5dd5645c7900"
if hashlib.sha256(BASE_PATH.read_bytes()).hexdigest() != BASE_SHA:
    raise ValueError("固定104保存本体SHA差")
SPEC = importlib.util.spec_from_file_location("105が直接再用する固定104保存", BASE_PATH)
BASE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(BASE)
OLD = BASE.OLD
need, equal = OLD.need, OLD.equal
KEYS = BASE.INNER_KEYS
IDS = ("2026-11-05_Day", "2026-11-05_Night", "2026-11-06_Day", "2026-11-06_Night")


def expected_ids(stage):
    """
    機能: Root固定後の先頭2→同じ4場を選ぶ。
    引数: stage(str)はfirst2/full4。
    返り値: list[str]は新4場の順序。旧54を混ぜない。
    """
    need(stage in ("first2", "full4"), "105保存stage")
    return list(IDS[:2] if stage == "first2" else IDS)


def inspect_scene(value, full_clock=False):
    """
    機能: sym四冊と新時計証拠を確認し104経由の旧LD10金融保存検算を使う。
    引数: value(dict)、full_clock(bool)は実Go型Nativeと観測prefix検査。
    返り値: dictは内Key四の検算済み台帳。旧市場goldenを捏造しない。
    """
    need(value["version"] == 1 and value["trial"] == 105 and value["complete"] is True and value["source_mode"] == "symmetric", "105完結sym口座")
    need(value["old103_market_golden"] is False and value["legacy_books"] == value["default_books"] == 0 and value["source_formed_here"] is False and value["gate_executed"] is False, "105新接続と旧golden対象外")
    equal(set(value["books"]), set(KEYS), "105主LD10四だけ")
    equal(set(value["bindings"]), {"legacy", "default", "symmetric"}, "全3mode通知QA")
    scene = value["session"]
    need(scene["id"] in IDS, "105の4ID以外を拒否")
    checked, clocks = {}, None
    for key in KEYS:
        book = value["books"][key]
        equal(book["key"], key, "内LD10本名を維持")
        equal(book["session"], scene, "全四冊の場同一")
        checked[key] = OLD.verify_book(book, key, full_clock)
        current = [row["at"] for row in book["grid_traces"]]
        if clocks is None:
            clocks = current
        else:
            equal(current, clocks, "同一新時計を全四冊へ配送")
    clock = value["clock_proof"]
    need(clock["positive_nk_rows"] > 0 and clock["source_calls"] > 0, "新clock/Source記録なし")
    equal(clock["all_board_grids"], len(clocks), "新全board観測grid数")
    equal(clock["source_forces"], 1 if scene["kind"] == "Day" else 2, "旧Source Force時計の数")
    need(clock["old54_tape_used"] is False and clock["old103_market_golden"] is False, "旧市場入力を流用しない")
    for mode, proof in value["bindings"].items():
        need(proof["mode_declared"] == mode and proof["source_formed_here"] is False and proof["financial_executed_here"] is False, "新Source結合の範囲")
        need(BASE.valid_sha(proof["input_tape_canonical_sha256"]) and BASE.valid_sha(proof["records_canonical_sha256"]), "新時計/Source指紋")
        equal(proof["grids"], len(clocks), "Bindと全四冊grid")
        if mode != "symmetric":
            need(proof["notifications_equal_old"] is True, "新legacy基準とdefaultの通知QA")
    return checked


def scene_rows(value, checked):
    """
    機能: 実現/参加/初正益/LD起動/DD材料を既存関数から得る。
    引数: value/checked(dict)は四冊と検算済み台帳。
    返り値: list[dict]は小型場別値。費用感度を独立日としない。
    """
    return [{"session": value["session"]["id"], "key": key, "source_mode": "symmetric",
             **OLD.summarize_book(value["books"][key], checked[key])} for key in KEYS]


def aggregate(rows, full4=None):
    """
    機能: 旧保存算術のまま新4場の主448/副432を集約する。
    引数: rows(list[dict])、full4(bool|None)は場別値と実2/4場の分母指定。Noneは型人工だけ。
    返り値: tupleは集計と日夜/日別。金融式は追加しない。
    """
    summary, diagnosis = {}, {}
    for key in KEYS:
        chosen = [row for row in rows if row["key"] == key]
        need(bool(chosen), "sym四設定欠落")
        summary[key] = OLD.combine(chosen)
        if full4 is not None:
            equal(summary[key]["活動主表"]["denom"], 448 if full4 else 224, "105主分母")
            equal(summary[key]["活動副表"]["denom"], 432 if full4 else 216, "105副分母")
        dates = sorted({row["session"][:10] for row in chosen})
        diagnosis[key] = {"日夜": {kind: OLD.combine([row for row in chosen if row["session"].endswith("_" + kind)]) for kind in ("Day", "Night")},
                          "日別": [{"開始日": day, **OLD.combine([row for row in chosen if row["session"].startswith(day)])} for day in dates]}
    return summary, diagnosis


def save_viewer(value, output, market_path=None):
    """
    機能: sym四の実Fillだけを105専用Viewer資源へ保存する。
    引数: value(dict)、output(Path)、market_path(str|None)はNative/新規先/固定実使用gzip。Noneは型人工だけ。
    返り値: list[dict]は四資源。実HTTPは行わない。
    """
    resources = []
    session = value["session"]["id"]
    for key in KEYS:
        name = f"105_{key}_{session}.trades.jsonl"
        with (output / name).open("x", encoding="utf-8", newline="\n") as stream:
            for row in OLD.BASE.viewer_trades(value["books"][key]):
                stream.write(json.dumps(row, ensure_ascii=False, default=OLD.BASE.serial, allow_nan=False) + "\n")
        resources.append({"id": f"105_{key}_{session}", "title": f"固定SourceとLD10の四場追加確認 {key} {session}",
            "symbol": "NK225", "product": "NK225mini", "session": session, "method_id": key, "point_value": 100,
            "pnl_format": "trades", "pnl_basis": "net", "pnl_path": name, "market_path": market_path or f"NK225/{session}/book.jsonl.gz"})
    return resources


def validate_completion(condition, complete, stage, condition_sha):
    """
    機能: 新市場の2→4成功metadataを保存Native本文より先に検査する。
    引数: condition/complete(dict)、stage/condition_sha(str)は固定条件と完了。
    返り値: list[dict]は対象場のNative/二Tape FileRef。
    """
    ids = expected_ids(stage)
    need(condition["version"] == 1 and condition["trial"] == 105 and condition["fixed"] is True, "105固定条件が必要")
    need(complete["version"] == 1 and complete["trial"] == 105 and complete["stage"] == stage and complete["success"] is True and not complete.get("error"), "105金融未成功")
    equal(complete["condition_sha256"], condition_sha, "同じ105条件")
    need(complete["sessions"] == len(ids) and complete["books_per_scene"] == 4 and complete["books"] == 4 * len(ids), "sym四/全16予定数")
    need(complete["old103_market_golden"] is False and complete["legacy_books"] == complete["default_books"] == 0 and complete["source_formed_here"] is False, "旧市場golden対象外/QA非経済")
    need(complete["unchanged"] is True and bool(complete["before"]) and complete["before"] == complete["after"], "105金融入力不変")
    tasks = complete["results"]
    equal([row["session"] for row in tasks], ids, "新4場集合/順")
    for row in tasks:
        need(row["books"] == 4 and not row.get("error"), "四冊未完結")
        for name in ("native", "fresh_legacy_tape", "symmetric_tape"):
            ref = row[name]
            need(set(ref) == {"path", "sha256"} and bool(ref["path"]) and BASE.valid_sha(ref["sha256"]), "105出力FileRef不正")
    if stage == "full4":
        need(complete.get("first2") and BASE.valid_sha(complete["first2"]["sha256"]), "同条件first2の出典")
    return tasks


def prepare(fixed_path, fixed_sha, output):
    """
    機能: Root事後固定と市場/Source成功metadataを保存本文より先に結ぶ。
    引数: fixed_path/output(Path)、fixed_sha(str)は3FileRefと新規保存先。
    返り値: tupleは場task/全前指紋/証拠/完了。Raw/CSVを再読しない。
    """
    need(not output.exists() and BASE.valid_sha(fixed_sha) and OLD.digest(fixed_path) == fixed_sha, "Root保存固定/新規先")
    fixed = OLD.load(fixed_path)
    need(fixed["version"] == 1 and fixed["trial"] == 105 and fixed["phase"] == "StageB" and fixed["fixed"] is True, "105保存を事後固定する")
    before = {str(fixed_path): fixed_sha, str(BASE_PATH): BASE_SHA, str(BASE.LEGACY_PATH): BASE.LEGACY_SHA,
              str(OLD.GRID_PATH): OLD.GRID_SHA, str(OLD.GRID.BASE_PATH): OLD.GRID.BASE_SHA}
    paths = {name: BASE.bind_ref(fixed[name], fixed_path.parent, before) for name in ("condition", "completion", "code")}
    equal(paths["code"], Path(__file__).resolve(), "105保存の実code")
    condition, complete = OLD.load(paths["condition"]), OLD.load(paths["completion"])
    tasks = validate_completion(condition, complete, fixed["stage"], fixed["condition"]["sha256"])
    equal(complete["before"].get(str(paths["condition"])), fixed["condition"]["sha256"], "完了のRoot条件出典")
    for name, expected in condition["code_sha256"].items():
        path = (ROOT / name).resolve()
        equal(OLD.digest(path), expected, "105固定code")
        equal(complete["before"].get(str(path)), expected, "金融beforeの固定code")
        before[str(path)] = expected
    for name in ("input_manifest", "source_condition", "source_full", "source_stop", "clock_stop", "binder_stop", "binary"):
        path = BASE.bind_ref(condition[name], paths["condition"].parent, before)
        equal(complete["before"].get(str(path)), condition[name]["sha256"], "105固定参照のbefore")
    manifest_path = BASE.bind_ref(condition["input_manifest"], paths["condition"].parent, before)
    manifest = OLD.load(manifest_path)
    equal([s["id"] for s in manifest["sessions"]], list(IDS), "入力台帳の新4ID")
    data_root = (manifest_path.parent / manifest["source_root"]).resolve()
    market_paths = {}
    for scene in manifest["sessions"]:
        ref = scene["files"]["NK225_book"]
        p = (data_root / ref["path"]).resolve()
        # MarketPathのmetadataだけを結合し、Raw由来gzipのbytesは本保存器で再読しない。
        if scene["id"] in expected_ids(fixed["stage"]):
            equal(complete["before"].get(str(p)), ref["sha256"], "金融が使用したViewer市場入力")
            market_paths[scene["id"]] = str(p)
    source_path = BASE.bind_ref(condition["source_full"], paths["condition"].parent, before)
    source = OLD.load(source_path)
    need(source["version"] == 1 and source["trial"] == 105 and source["stage"] == "full4" and source["success"] is True and not source.get("error"), "上流Source全4成功")
    equal(source["condition_sha256"], condition["source_condition"]["sha256"], "105Source同条件")
    need(source["sessions"] == 4 and len(source["cases"]) == 12 and source["unchanged"] is True and source["before"] == source["after"] and source["source_reformed"] is True and source["financial105_executed"] is False, "Source生成と金融を分ける")
    cases = {(row["session"], row["mode"]): row for row in source["cases"]}
    equal(set(cases), {(sid, mode) for sid in IDS for mode in ("legacy", "default", "symmetric")}, "Source新4x3集合")
    resolved = []
    for task in tasks:
        references = {name: BASE.bind_ref(task[name], paths["completion"].parent, before) for name in ("native", "fresh_legacy_tape", "symmetric_tape")}
        for mode in ("legacy", "default", "symmetric"):
            case = cases[task["session"], mode]
            need(case["old93_full_match"] is False and not case.get("error"), "新4を旧golden成功にしない")
            for name in ("result", "records"):
                path = BASE.bind_ref(case[name], source_path.parent, before)
                equal(complete["before"].get(str(path)), case[name]["sha256"], "金融使用Source出典")
        resolved.append({**task, "resolved": references, "market_path": market_paths[task["session"]]})
    if fixed["stage"] == "full4":
        prior_path = BASE.bind_ref(complete["first2"], paths["completion"].parent, before)
        prior = OLD.load(prior_path)
        validate_completion(condition, prior, "first2", fixed["condition"]["sha256"])
    proofs = {"Root固定SHA256": fixed_sha, **{name + "SHA256": fixed[name]["sha256"] for name in paths}}
    return resolved, before, proofs, complete


def generate(fixed_path, fixed_sha, output):
    """
    機能: Root成功後のsym四会計だけを保存し、新資料を生成する。
    引数: fixed_path/output(Path)、fixed_sha(str)はRoot事後固定と新規先。
    返り値: dictは成功数。金融/Source/Raw/HTTPを実行しない。
    """
    tasks, before, proofs, complete = prepare(fixed_path, fixed_sha, output)
    rows, resources, refs = [], [], []
    output.mkdir(parents=True)
    for task in tasks:
        value = OLD.load(task["resolved"]["native"])
        equal(value["session"]["id"], task["session"], "Nativeの新場ID")
        checked = inspect_scene(value, True)
        # 新Tapeは保存済みgrid列だけ読む。Source/金融の再演をしない。
        tape_grids = None
        for name in ("fresh_legacy_tape", "symmetric_tape"):
            tape = OLD.load(task["resolved"][name])
            equal(tape["session"], value["session"], "保存Tape場")
            current = [e["at"] for e in tape["events"] if e["kind"] == "grid"]
            if tape_grids is None:
                tape_grids = current
            else:
                equal(current, tape_grids, "両新Tapeの同観測grid")
        equal(tape_grids, [t["at"] for t in value["books"][KEYS[0]]["grid_traces"]], "新観測時計と保存金融grid")
        rows.extend(scene_rows(value, checked))
        resources.extend(save_viewer(value, output, task["market_path"]))
        refs.append({"session": task["session"], **{name: task[name] for name in ("native", "fresh_legacy_tape", "symmetric_tape")}})
    summary, diagnosis = aggregate(rows, complete["stage"] == "full4")
    after = {name: OLD.digest(Path(name)) for name in before}
    equal(after, before, "105保存入力/固定code前後不変")
    result = {"試行": 105, "成功": True, "フェーズ": "StageB", "scope": "新4場sym LD10四だけ。固定104/103の保存算術・限定因果・保存点DD。全原行別engine独立金融再生ではない",
        **proofs, "stage": complete["stage"], "場数": len(tasks), "会計数": 4 * len(tasks), "主会計数": 4 * len(tasks), "診断会計数": 0,
        "主key": list(KEYS), "SourceMode": "symmetric", "旧市場golden": {"対象外": True, "対照会計": 0},
        "legacy/default金融会計": 0, "通知QAの基準": "新legacy基準Tape。旧54/旧103市場goldenではない",
        "Actor設定": {key: {"SourceMode": "symmetric", "入口": "Gate無しB5Q", "基本保護": "P0", "起動": "LD10", "slip_pts": int(key[-4]), "delay_seconds": int(key[-1])} for key in KEYS},
        "集計": summary, "実現診断": diagnosis, "場別": rows, "Native参照": refs,
        "Viewer形式資源": len(resources), "Viewer市場path": {t["session"]: t["market_path"] for t in tasks},
        "Viewer市場pathの検査範囲": "固定InputManifestと金融beforeへ結合。共有/work gzipを絶対参照、Raw由来gzip本体の再読/再hashはしない",
        "実Viewer通信": 0, "入力codeSHA256前": before, "入力codeSHA256後": after, "前後不変": True,
        "未評価": ["旧市場golden成功", "追加の全原行金融再生", "Source全体の対称性", "機会損失/退出後価格/MFE", "4場より先の期間"]}
    OLD.BASE.write_json(output / "結果.json", result)
    OLD.BASE.write_json(output / "一覧.resources.json", {"schema_version": 1, "path_base": "catalog", "resources": resources})
    lines = ["# 105 sym LD10の保存", "", result["scope"], "", "legacy/defaultは通知QAだけで金融0。旧市場goldenは対象外。", "", "|Key|純額|u正益後赤字額|起動後赤字額|主参加|副分母|保存点DD|", "|---|---:|---:|---:|---:|---:|---:|"]
    for key, row in summary.items():
        a = row["活動主表"]
        lines.append(f"|{key}|{row['net_yen']}|{row['unit_positive_closed_negative_yen']}|{row['activated_closed_negative_yen']}|{a['active']}/{a['denom']}|{row['活動副表']['denom']}|{row['保存点連結時価DD']}|")
    (output / "結果.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    outputs = {p.name: OLD.digest(p) for p in output.iterdir() if p.is_file()}
    OLD.BASE.write_json(output / "保存会計の確認.json", {"成功": True, **proofs, "stage": complete["stage"], "会計": 4 * len(tasks),
        "資源": len(resources), "不一致数": 0, "前後不変": True, "入力codeSHA256前": before, "入力codeSHA256後": after,
        "出力SHA256": outputs, "旧市場golden": "対象外", "Source/金融/Raw/CSV/HTTP再実行": 0})
    return {"成功": True, "場数": len(tasks), "会計": 4 * len(tasks), "Viewer形式資源": len(resources), "実Viewer通信": 0}


def main():
    """
    機能: Rootの成功後固定JSONだけを受ける保存CLI。
    引数: --fixed/--fixed-sha/--outはRoot事後固定と新規保存先。
    返り値: None。未固定/未成功はNative読取前拒否。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixed", type=Path, required=True)
    parser.add_argument("--fixed-sha", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(generate(args.fixed.resolve(), args.fixed_sha, args.out), ensure_ascii=False))


if __name__ == "__main__":
    main()
