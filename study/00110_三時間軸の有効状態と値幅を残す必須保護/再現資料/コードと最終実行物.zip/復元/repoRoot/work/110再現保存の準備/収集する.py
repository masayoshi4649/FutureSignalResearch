"""110の固定コード・停止物・明示人工・最終exeを市場本文なしで収集計画へ結ぶ。"""

from collections import Counter
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import zlib

OWN=Path(__file__).resolve().parent
ROOT=OWN.parents[1]
TRIAL=ROOT/'study/00110_三時間軸の有効状態と値幅を残す必須保護'
TECH=TRIAL/'技法条件固定.json'
TECH_SHA='7d4f0135f9ed1cda0d4298355e046db02461a2a02a6ee46f6b7d783489fb023a'
LEGACY=ROOT/'work/109再現コードの準備/収集する.py'
LEGACY_SHA='5888ebeafdff999cc3798cb79efab9aa8187f2fc95a1fce1787a5090c2b0c9a1'


def sha(path):
    """
    機能: 明示コード/metadata/人工/実行物のSHA256を返す。

    引数: path(Path)は許可済み対象。
    返り値: strは全bytesのSHA256。
    """
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


if sha(LEGACY)!=LEGACY_SHA:raise ValueError('停止109collector指紋差')
SPEC=importlib.util.spec_from_file_location('保存109の汎用部だけ',LEGACY)
OLD=importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)
need,read,ref,resolve=OLD.need,OLD.read,OLD.ref,OLD.resolve


class Registry(OLD.Registry):
    """110の明示人工/最終exeを限定し、元配置を重複なく保存する。"""

    def __init__(self, binaries=(), artificial=()):
        """
        機能: 対象を固定Refの集合で限定する。

        引数: self(Registry),binaries/artificial(iterable[Path])は最終実行物/人工の明示集合。
        返り値: None。
        """
        super().__init__()
        self.binaries={str(Path(p).resolve()) for p in binaries}
        self.artificial={str(Path(p).resolve()) for p in artificial}

    def add(self,name,expected,role,kind='code'):
        """
        機能: 全bytesと安全な元配置を確認し計画へ一件登録する。

        引数: self(Registry),name/expected/role/kind(str)はpath/SHA/役割/種別。
        返り値: dictは重複統合した所在。
        """
        path=resolve(name)
        need(isinstance(expected,str) and re.fullmatch('[0-9a-f]{64}',expected),'明示SHAが必要')
        need(kind in ('code','metadata','人工','最終exe','環境','LICENSE'),'保存対象種別')
        need(not path.is_relative_to(ROOT.parent/'JP_OSE_Data'),'共用原板を収集しない')
        root,relative=OLD.restoration(path)
        if kind=='環境':need(path.is_relative_to(OLD.SDK),'環境参照はGoRootだけ')
        if path.is_relative_to(OLD.SDK) and kind!='LICENSE':kind='環境'
        elif kind=='人工':
            need(str(path) in self.artificial,'人工は停止が明示した全SHA集合だけ')
            need('/人工_停止版/' in path.as_posix() or '/人工Reader/' in path.as_posix() or path==ROOT/'work/110入口寿命の人工出典/寿命の人工.json','人工専用prefix以外は不可')
        elif kind=='最終exe':need(str(path) in self.binaries and path.suffix=='.exe','停止した最終2exeだけ')
        else:
            need(path.suffix not in ('.exe','.csv','.gz','.xlsx','.png') and '.Native.' not in path.name,'市場data/途中exe/成果画像を収集しない')
            need(path.suffix in OLD.SOURCE_SUFFIXES or kind=='LICENSE' or path.name in ('LICENSE','COPYING','NOTICE'),'コード/小metadataの型限定')
        need(path.is_file() and sha(path)==expected,'収集対象の全bytes差:'+str(path))
        key=str(path)
        if key in self.rows:
            row=self.rows[key]
            need(row['sha256']==expected,'同path指紋衝突')
            if role not in row['roles']:row['roles'].append(role)
            return row
        prefix='人工' if kind=='人工' else '実行物' if kind=='最終exe' else '復元'
        row={'original_path':key,'sha256':expected,'bytes':path.stat().st_size,'kind':kind,'roles':[role],
             'restore':{'root':root,'relative':relative},'location':{'kind':'環境版とSHAのみ' if kind=='環境' else '新archive予定','entry':None if kind=='環境' else f'{prefix}/{root}/{relative}'}}
        self.rows[key]=row
        return row


def artificial_refs(stopped):
    """
    機能: 停止が明示する人工だけを一覧にする。

    引数: stopped(dict)は停止metadata。
    返り値: list[dict]はpath/sha256。実市場入力Refは走査しない。
    """
    refs=[]
    for field in ('人工型SHA256','人工入力SHA256'):
        refs.extend({'path':p,'sha256':h} for p,h in stopped.get(field,{}).items())
    refs.extend(stopped.get('人工出力',[]))
    if '継承した人工fixture' in stopped:refs.append(stopped['継承した人工fixture'])
    return refs


def collect_stop(registry,value,label):
    """
    機能: 現行停止の所有/再用code・仕様・検査を結ぶ。

    引数: registry(Registry),value(dict),label(str)は台帳/停止Ref/理由。
    返り値: dictは停止metadata。派生元は指紋のみ保持する。
    """
    stopped=OLD.collect_stop(registry,value,label)
    for field in (stopped.get('再用コードSHA256',{}),stopped.get('依存コードと仕様SHA256',{}),stopped.get('設計元SHA256',{})):
        for path,h in field.items():registry.add(path,h,label+':所有/実再用')
    for name in ('仕様','検査','README','検査正本','人工確認'):
        for evidence in OLD.inspection_refs(stopped.get(name)):registry.add_ref(evidence,label+':'+name)
    path=resolve(value['path'])
    for name in ('README.md','仕様.md','仕様.json'):
        p=path.parent/name
        if p.is_file():registry.file(p,label+':仕様','metadata')
    for evidence in artificial_refs(stopped):registry.add_ref(evidence,label+':明示人工','人工')
    if isinstance(stopped.get('派生元'),dict) and 'path' in stopped['派生元']:
        registry.add_ref(stopped['派生元'],label+':途中版は停止metadataだけ','metadata')
    return stopped


def build_plan():
    """
    機能: 技法固定とGo閉包から110の保存計画を作る。

    引数: なし。
    返り値: dictは正式ZIP未生成の収集計画。金融/市場本文は読まない。
    """
    technique=read(TECH,TECH_SHA)
    need(technique['fixed'] and technique['trial']==110 and len(technique['configs'])==36,'110固定36条件が必要')
    stoprefs=list(technique['stops'])+[technique['preparer_stop']]
    for name in ('停止.json','入口監査の停止.json','保護監査の停止.json'):
        path=ROOT/'work/110有効状態と値幅保護の保存'/name
        if path.is_file():stoprefs.append(ref(path))
    stopped=[(r,read(resolve(r['path']),r['sha256'])) for r in stoprefs]
    artifacts=[r for _,s in stopped for r in artificial_refs(s)]
    # ----------------------------------------
    # 旧testが明示して読む人工4点だけを補う。
    old108=ROOT/'work/108静観短縮の市場接続準備/停止.json'
    old106=ROOT/'work/106可変保護の市場接続準備/検査/人工確認.json'
    artifacts.extend(artificial_refs(read(old108)))
    name='work/106可変保護の市場接続準備/人工_停止版/方向1_助走false.json'
    artifacts.append({'path':name,'sha256':read(old106)['停止版人工SHA256'][name]})
    registry=Registry([resolve(technique[k]['path']) for k in ('market_binary','observer_binary')],[resolve(r['path']) for r in artifacts])
    registry.add_ref(ref(TECH),'110技法固定','metadata')
    for path,h in technique['code_sha256'].items():registry.add(path,h,'技法固定の実選択閉包')
    stops={}
    for r,s in stopped:
        collect_stop(registry,r,'110/継承停止:'+resolve(r['path']).parent.name)
        stops[str(resolve(r['path']))]=s
    for r in artifacts:registry.add_ref(r,'全SHAで指定した人工','人工')
    for value in technique['go_closures'].values():registry.add_ref(value,'実Go選択閉包の証拠','metadata')
    normalized={str(resolve(p)):h for p,h in technique['code_sha256'].items()}
    for value in technique['go_closures'].values():
        closure=read(resolve(value['path']),value['sha256'])
        need(closure['成功'] and closure['全選択code前後不変'],'Go閉包の成功と前後不変')
        for row in closure['files']:need(normalized.get(str(resolve(row['path'])))==row['sha256'],'Go閉包の実選択と技法固定codeの一致')
    for value in technique['specifications']+technique.get('design_specifications',[])+[technique['method_catalog']]:
        registry.add_ref(value,'市場前の固定仕様','metadata')
    for p in (old108,old106):registry.file(p,'継承人工の指紋出典','metadata')
    registry.file(LEGACY,'再用する109収集器の汎用関数')
    for name in ('main.go','source_fixture.go','go.mod','go.sum','生成する.py','確認.json'):
        registry.file(ROOT/'work/110入口寿命の人工出典'/name,'L1人工6端点の生成元と停止Actor API依存','metadata' if name.endswith('.json') else 'code')
    for name in ('事前定義を作る.py','接続とCLIを派生する.py','接続部品を検査して停止する.py','頻度を派生する.py','頻度要求を作る.py','人工の純会計を確認する.py'):
        registry.file(ROOT/'work/110進行'/name,'Rootの事前定義/派生/人工/実行helper')
    for name in ('scripts/レポート/試行110の設定表を作る.py','scripts/損益CSV/出力する.mjs','scripts/損益CSV/再読で照合する.py'):
        registry.file(ROOT/name,'表生成とCSVの再用コード')
    for name in ('カタログ版6.py','設定結果レポート.py','手法カタログ_版5.json','手法カタログ_版6.json'):
        registry.file(ROOT/'scripts/レポート'/name,'版6設定表の実描画/版差検査依存','metadata' if name.endswith('.json') else 'code')
    for p in sorted(OWN.glob('*.py')):registry.file(p,'110再現保存collector')
    registry.file(OWN/'README.md','110再現保存の仕様','metadata')
    for key in ('market_binary','observer_binary'):registry.add_ref(technique[key],'最終停止exe:'+key,'最終exe')
    licenses=OLD.add_licenses(registry)
    for name in ('LICENSE','PATENTS'):registry.file(OLD.SDK/name,'静的リンクしたGo標準ライブラリの利用条件','LICENSE')
    rows=sorted(registry.rows.values(),key=lambda x:x['original_path'])
    for row in rows:row['roles'].sort()
    archived=[r for r in rows if r['kind']!='環境']
    entries=[r['location']['entry'] for r in archived]
    need(len({e.casefold() for e in entries})==len(entries),'Windowsで同名になるarchive entry')
    estimate=sum(len(zlib.compress(Path(r['original_path']).read_bytes(),9))+2*len(r['location']['entry'].encode('utf-8'))+120 for r in archived)
    need(sum(r['kind']=='環境' for r in rows)==717,'GoRoot717参照の欠落/増加')
    old106=OLD.old_input_references()
    old106['producer_code_outside_110']=old106.pop('producer_code_outside_109')
    old106['scope']='106巨大Source/Tape/Record/Header保持又は再形成の入口。110 ZIPへ実入力本文を複製しない。'
    return {'version':1,'trial':110,'scope':'計画のみ。金融/頻度の市場本文未読、正式ZIP/closure未生成','technique':ref(TECH),
            'roots':{'repoRoot':str(ROOT),'neighborRoot':str(ROOT.parent),'moduleCacheRoot':str(OLD.CACHE),'goRoot':str(OLD.SDK)},'files':rows,
            'summary':{'全所在':len(rows),'同梱予定':len(archived),'環境参照':717,'種別':dict(Counter(r['kind'] for r in rows)),
                       '同梱元bytes':sum(r['bytes'] for r in archived),'ZIP概算bytes':estimate},'licenses':licenses,'environment':OLD.environment(),
            'input_dependencies':{k:technique[k] for k in ('source_manifest','source_corpus','source_completion','baseline_closure','baseline_completion','baseline_native_index')},
            'old106_producer':old106,
            'history':['Actor110の停止済生成補助Python2本に一行docstringが残る。Root判断で停止原本を保持し、次派生で修正する。'],
            'not_copied':['実Raw/価格CSV/Source/Tape/Header/Record/Native本文','GoRoot717の本文','途中版exe','旧prep2全コード','Node依存本体','旧正式archive本文の再複製'],
            'pending':['正式金融条件と最終結果/CSV/Viewer/レポートhelperをRoot確定後に追加','金融・純頻度全件成功後のRoot依頼まで正式ZIPを生成しない','Source106入力保持/正確復元はコードと同exeの復元とは別要件']}


def main():
    """
    機能: work内の新規JSONへ計画だけを保存する。

    引数: --plan(Path)は所有work内の未使用先。
    返り値: None。市場処理やZIP生成の口は持たない。
    """
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--plan',type=Path,required=True)
    args=parser.parse_args();target=args.plan.resolve()
    need(target.is_relative_to(OWN) and not target.exists(),'計画は所有work内へ新規だけ')
    value=build_plan()
    with target.open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps({'成功':True,'計画':ref(target),'見積':value['summary'],'正式ZIP生成':False,'市場本文読取':False},ensure_ascii=False))


if __name__=='__main__':main()
