"""110収集計画の範囲・SHA・安全な所在を市場本文なしで人工検査する。"""

import ast
import hashlib
import json
from pathlib import Path, PurePosixPath
import tempfile
import unittest

import 収集する as C


class 収集検査(unittest.TestCase):
    """コードと人工の保存境界を検査する。"""

    def test_重複と全bytes不一致(self):
        """
        機能: 同一コードの役割を統合し、後の改変を拒否する。

        引数: self(収集検査)は検査器。
        返り値: None。
        """
        with tempfile.TemporaryDirectory(prefix='人工_',dir=C.OWN) as name:
            folder=Path(name).resolve();self.assertTrue(folder.is_relative_to(C.OWN))
            p=folder/'人工.py';p.write_text('値=1\n',encoding='utf-8')
            registry=C.Registry();h=C.sha(p)
            a=registry.add(str(p),h,'一つ目');b=registry.add(str(p),h,'二つ目')
            self.assertIs(a,b);self.assertEqual(a['roles'],['一つ目','二つ目'])
            p.write_text('値=2\n',encoding='utf-8')
            with self.assertRaises(ValueError):registry.add(str(p),h,'改変')

    def test_本物dataと途中実行物を拒否する(self):
        """
        機能: 市場型のdataと途中exeが計画へ混入することを防ぐ。

        引数: self(収集検査)は検査器。
        返り値: None。
        """
        with tempfile.TemporaryDirectory(prefix='人工_',dir=C.OWN) as name:
            folder=Path(name).resolve();self.assertTrue(folder.is_relative_to(C.OWN))
            for filename in ('price.csv','scene.Native.json.gz','scene.Native.json','records.gz','old.exe','image.png','table.xlsx'):
                p=folder/filename;p.write_bytes(b'false')
                with self.subTest(file=filename),self.assertRaises(ValueError):C.Registry().file(p,'偶発入力','metadata')
            p=folder/'fake.json';p.write_bytes(b'{}')
            with self.assertRaises(ValueError):C.Registry().file(p,'人工と呼ぶだけでは不可','人工')
            with self.assertRaises(ValueError):C.Registry().file(p,'SDK以外の環境隠し','環境')

    def test_人工と最終実行物の明示集合(self):
        """
        機能: 名前の似た人工やexeを明示集合なしで収集しない。

        引数: self(収集検査)は検査器。
        返り値: None。
        """
        with tempfile.TemporaryDirectory(prefix='人工_',dir=C.OWN) as name:
            folder=Path(name).resolve();self.assertTrue(folder.is_relative_to(C.OWN))
            p=folder/'a.exe';p.write_bytes(b'artificial')
            with self.assertRaises(ValueError):C.Registry().file(p,'途中版','最終exe')
            p=folder/'fake.json';p.write_bytes(b'{}')
            with self.assertRaises(ValueError):C.Registry(artificial=[p]).file(p,'専用prefixでない','人工')

    def test_GoRootは参照と小ライセンスだけ(self):
        """
        機能: GoRootソース/5tools本体を同梱予定にしない。

        引数: self(収集検査)は検査器。
        返り値: None。
        """
        registry=C.Registry()
        code=registry.file(C.OLD.SDK/'src/runtime/runtime.go','SDK実選択')
        license_row=registry.file(C.OLD.SDK/'LICENSE','静的リンク条件','LICENSE')
        self.assertEqual(code['kind'],'環境');self.assertIsNone(code['location']['entry'])
        self.assertEqual(license_row['kind'],'LICENSE');self.assertEqual(license_row['restore']['root'],'goRoot')

    def test_実在閉包と停止と人工の前後不変(self):
        """
        機能: 計画全件の指紋/安全path/人工元依存を確認する。

        引数: self(収集検査)は検査器。
        返り値: None。実Raw/Native/市場CSVは渡さない。
        """
        plan=C.build_plan();rows=plan['files']
        self.assertEqual(plan['summary']['環境参照'],717)
        self.assertEqual(sum(r['kind']=='最終exe' for r in rows),2)
        inputs={str(C.resolve(v['path'])) for v in plan['input_dependencies'].values()}
        self.assertTrue(inputs.isdisjoint({r['original_path'] for r in rows}))
        names=[]
        for row in rows:
            self.assertEqual(C.sha(Path(row['original_path'])),row['sha256'])
            if row['location']['entry'] is not None:
                entry=PurePosixPath(row['location']['entry'])
                self.assertFalse(entry.is_absolute());self.assertNotIn('..',entry.parts)
                names.append(str(entry).casefold())
            if row['kind']=='人工':self.assertTrue(row['location']['entry'].startswith('人工/'))
        self.assertEqual(len(names),len(set(names)))
        suffixes={r['original_path'] for r in rows}
        self.assertIn(str(C.ROOT/'work/110入口寿命の人工出典/main.go'),suffixes)
        self.assertIn(str(C.ROOT/'work/110入口寿命の人工出典/生成する.py'),suffixes)
        self.assertIn(str(C.ROOT/'work/110有効入口と値幅保護の会計/停止.json'),suffixes)
        self.assertTrue(plan['old106_producer']['producer_code_outside_110'])

    def test_新規関数コメント規約(self):
        """
        機能: 新collectorの関数に複数行の機能/引数/返り値を要求する。

        引数: self(収集検査)は検査器。
        返り値: None。
        """
        for p in C.OWN.glob('*.py'):
            tree=ast.parse(p.read_text(encoding='utf-8'))
            for node in ast.walk(tree):
                if not isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):continue
                text=ast.get_docstring(node)
                self.assertTrue(text and node.body[0].end_lineno>node.body[0].lineno,(p.name,node.name))
                self.assertTrue(all(s in text for s in ('機能:','引数:','返り値:')),(p.name,node.name))


def main():
    """
    機能: 準備だけの検査結果をworkへ保存する。

    引数: なし。
    返り値: None。正式ZIPと市場処理の実行口はない。
    """
    files=list(C.OWN.glob('*.py'))+[C.OWN/'README.md']
    before={str(p):C.sha(p) for p in files}
    zip_before=list(C.OWN.glob('*.zip'))
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(収集検査))
    C.need(before=={str(p):C.sha(p) for p in files},'準備code前後差')
    C.need(zip_before==list(C.OWN.glob('*.zip')),'正式ZIPを作らない')
    value={'成功':result.wasSuccessful(),'主':result.testsRun,'コード前後不変':True,'コードSHA256':before,'正式ZIP生成':False,'市場本文読取':False,'金融/Observer再実行':False,'11月09日読取':False}
    (C.OWN/'準備確認.json').write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if not result.wasSuccessful():raise SystemExit(1)


if __name__=='__main__':main()
