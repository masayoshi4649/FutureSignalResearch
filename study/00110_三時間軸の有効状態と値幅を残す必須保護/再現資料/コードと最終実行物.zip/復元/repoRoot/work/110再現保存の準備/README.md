# 110再現保存の準備

正式ZIPはまだ生成しない。固定技法、実選択Go閉包、停止部品、独立保存監査、明示人工、最終2exeとライセンスの所在を計画へまとめる。実Raw・価格CSV・Source/Tape/Header/Record・市場Native本文は複製しない。11月09日の追加場本文/hashも読まない。

109の固定collectorから汎用の停止schema処理、環境版、OSSライセンスと旧106参照だけを再用する。110の対象は明示した固定Refから選び、旧collectorの109計画生成は呼ばない。旧prep2の途中コード一式は複製せず、実際に使う新固定器のコードと再用2本だけを束縛し、派生元停止指紋を保存する。

金融・純頻度exeは技法固定の最終2本だけを保存する予定。ソース再buildの成功と同SHAのexe復元を区別し、GoのVCS埋込・絶対pathにより同exeを再生成できない場合に備える。GoRoot717（標準ソースと5tools）は環境版/path/SHAのみで、LICENSE/PATENTSだけは同梱する。

コードの元配置はrepoRoot・neighborRoot・moduleCacheRootへ復元する。絶対pathを含む金融条件は書き換えず保持し、移設した条件は別版として扱う。Node/Artifact Tool環境本体は同梱せず、CSV生成と独立再読コード・環境版を保存する。CSV/Viewerの後段helperと金融条件・結果RefはRoot確定後に追加する。

Source106の巨大共用入力と旧108 Nativeは今回のZIPに入れない。旧106の正式所在索引・再現手順・producerコード所在とarchive全SHAを参照し、入力の保持又は正確な復元を別の要件とする。work全削除後にコード/exeだけで同SHAの実入力まで自動復元できるとは保証しない。

人工は通常データと区別した専用prefixへ入れ、元位置・全SHA・用途を明示する。110CoreのT/R8器具、旧対照2、Observerの明示Reader人工、新Eの6寿命端点と生成Go/Python・停止Actor APIを含める。寿命だけの6器具は手製採否であり、純E2成立は停止Coreの288口座で別に検査している。

Actorの旧生成補助Python2本には停止前の1行docstringが残る。Root判断で停止物を保存し、今回は金融コード/停止参照を連鎖変更しない。新110保存EのPython28関数は複数行・機能/引数/返り値の規約を確認している。

```powershell
python -B -X utf8 work/110再現保存の準備/収集する.py --plan work/110再現保存の準備/計画候補.json
python -B -X utf8 work/110再現保存の準備/収集の人工検査.py
```

計画はwork内の新規JSONだけに保存する。collectorは市場/金融/Observer/ZIP生成の実行口を持たない。金融条件・最終結果・CSV・レポートhelper・Viewer等は未確定項目として残し、Rootの正式生成依頼までZIPと最終閉鎖を書かない。
