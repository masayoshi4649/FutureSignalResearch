"""保存要求の生成器を原本のまま保ち、再実行の出力参照だけへ派生する。"""

import ast
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE_SHA = "1fbd017133d448ff081a756e9eba1733a137039baadfe1ee3d317e5224cc103a"
CONDITION_SHA = "e0f84c5f836a3cb58b6d75c12f08c40e910b661043516e1e642143b6026b9fba"
SAVING_SHA = "2cd0b49558e04ebad22a1dedeca99fd50dc4c77044b480786ffc67fe69b648f6"
REPLACEMENTS = (
    ('(label+"_停止形式整合")', '(label+("_停止形式整合" if args.stage == "first2" else "_中断後の同条件再実行"))'),
    ('(label+".json")', '(label+("" if args.stage == "first2" else "_中断後の同条件再実行")+".json")'),
    ('(ROOT / "work/110保存" / label).exists()', '(ROOT / "work/110保存" / (label+("" if args.stage == "first2" else "_中断後の同条件再実行"))).exists()'),
)


def digest(path: Path) -> str:
    """明示されたコード・metadataの全バイト指紋を求める。

    引数: path(Path)は市場本文を含まない非価格ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def reference(path: Path) -> dict:
    """非価格ファイルを再読できる出典参照にまとめる。

    引数: path(Path)は現存ファイル。
    返り値: dictは絶対path・SHA256・容量。
    """
    return {"path": str(path), "sha256": digest(path), "bytes": path.stat().st_size}


def selected_paths(source: str, stage: str) -> tuple[Path, Path, Path]:
    """生成器の三つのpath式だけを人工stageで評価する。

    引数: source(str)はPythonソース、stage(str)はfirst2又はfull70。
    返り値: tuple[Path,Path,Path]は完了台帳・要求先・保存先。ファイル読取はしない。
    """
    tree = ast.parse(source)
    body = next(node.body for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == "main")
    env = {"ROOT": ROOT, "args": SimpleNamespace(stage=stage), "label": "先頭2場" if stage == "first2" else "全70場"}
    assignments = {node.targets[0].id: node.value for node in body if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)}
    completion = eval(compile(ast.Expression(assignments["completion"]), "人工path式", "eval"), env)
    target = eval(compile(ast.Expression(assignments["target"]), "人工path式", "eval"), env)
    assertion = next(node for node in body if isinstance(node, ast.Assert) and any(isinstance(x, ast.Name) and x.id == "target" for x in ast.walk(node)))
    calls = [node for node in ast.walk(assertion) if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == "exists"]
    save = next(node.func.value for node in calls if not isinstance(node.func.value, ast.Name))
    output = eval(compile(ast.Expression(save), "人工path式", "eval"), env)
    return completion, target, output


def main() -> None:
    """三つのpathだけを派生し、元の全検査が同体である証拠を残す。

    引数: なし。
    返り値: None。実completion、Native、Raw、価格CSVは開かず、保存要求も作らない。
    """
    origin = ROOT / "work/110保存要求/作る.py"
    condition = ROOT / "study/00110_三時間軸の有効状態と値幅を残す必須保護/金融条件_停止形式整合.json"
    saving = ROOT / "work/110有効状態と値幅保護の保存/停止.json"
    assert digest(origin) == SOURCE_SHA and digest(condition) == CONDITION_SHA and digest(saving) == SAVING_SHA
    original = origin.read_text(encoding="utf-8")
    changed = original
    for before, after in REPLACEMENTS:
        assert changed.count(before) == 1
        changed = changed.replace(before, after)
    reverted = changed
    for before, after in reversed(REPLACEMENTS):
        assert reverted.count(after) == 1
        reverted = reverted.replace(after, before)
    assert reverted == original
    compile(changed, "派生生成器", "exec")
    old_first = selected_paths(original, "first2")
    new_first = selected_paths(changed, "first2")
    assert old_first == new_first
    new_full = selected_paths(changed, "full70")
    assert new_full == (
        ROOT / "work/110市場/全70場_中断後の同条件再実行/完了.json",
        ROOT / "work/110保存要求/全70場_中断後の同条件再実行.json",
        ROOT / "work/110保存/全70場_中断後の同条件再実行",
    )
    source = json.loads(saving.read_text(encoding="utf-8"))
    code = source["コードSHA256"]
    assert len(code) == 20 and all(digest(Path(path)) == expected for path, expected in code.items())
    target = HERE / "作る.py"
    with target.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(changed)
    metadata = {
        "試行": 110,
        "成功": True,
        "元生成器": reference(origin),
        "派生生成器": reference(target),
        "変更": [{"元": before, "派生": after} for before, after in REPLACEMENTS],
        "許容変更": "full70のcompletion参照、要求出力先、保存先の存在検査の三つのpath式だけ",
        "置換逆写像による元全コード同体": reverted == original,
        "先頭2場の三path同体": old_first == new_first,
        "全70の三path": [str(path) for path in new_full],
        "変更しない固定": {"金融条件": reference(condition), "保存停止": reference(saving), "保存Python依存": len(code)},
        "元全検査を保持": ["条件e0f84c5f...", "保存停止2cd0b495...", "保存器Python20の全指紋", "version1・trial110・stage", "成功full70・70場・36会計毎場・2520会計・Shadow0・旧対照280", "金融入力before==afterかつunchanged", "要求先と保存先の上書き拒否"],
        "完了metadata読取": False,
        "Native本文読取": False,
        "実保存要求生成": False,
        "市場再実行": False,
        "検査器": reference(Path(__file__).resolve()),
    }
    proof = HERE / "派生と全検査同体の確認.json"
    with proof.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(metadata, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    assert digest(origin) == SOURCE_SHA
    print(json.dumps({"生成器": reference(target), "確認": reference(proof), "実保存要求生成": False}, ensure_ascii=False))


if __name__ == "__main__":
    main()
