"""同じ停止形式整合条件で成功した金融だけを、独立保存の新規要求へ固定する。"""

import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00110_三時間軸の有効状態と値幅を残す必須保護"
CONDITION_SHA = "e0f84c5f836a3cb58b6d75c12f08c40e910b661043516e1e642143b6026b9fba"
SAVING_SHA = "2cd0b49558e04ebad22a1dedeca99fd50dc4c77044b480786ffc67fe69b648f6"


def digest(path: Path) -> str:
    """条件・完了metadata・コードの全バイト指紋を取る。

    引数: path(Path)は明示した非価格入力。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """成功completionの場数・指紋・同一条件を認証して保存要求を作る。

    引数: --stage(str)はfirst2/full70、--completion-sha(str)は成功完了の期待値。
    返り値: None。金融再走・Native本文の再読・既存出力の上書きはしない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["first2", "full70"], required=True)
    parser.add_argument("--completion-sha", required=True)
    args = parser.parse_args()
    label, count = ("先頭2場", 2) if args.stage == "first2" else ("全70場", 70)
    condition = TRIAL / "金融条件_停止形式整合.json"
    completion = ROOT / "work/110市場" / (label+"_停止形式整合") / "完了.json"
    saving = ROOT / "work/110有効状態と値幅保護の保存/停止.json"
    assert digest(condition) == CONDITION_SHA and digest(saving) == SAVING_SHA
    assert digest(completion) == args.completion_sha
    value = json.loads(completion.read_text(encoding="utf-8"))
    assert value["version"] == 1 and value["trial"] == 110 and value["stage"] == args.stage and value["success"]
    assert value["condition_sha256"] == CONDITION_SHA and value["before"] == value["after"] and value["unchanged"]
    assert (value["sessions"], value["books_per_scene"], value["books"], value["shadow_books"], value["baseline_comparisons"]) == (count, 36, count*36, 0, count*4)
    stopped = json.loads(saving.read_text(encoding="utf-8"))
    for path, expected in stopped["コードSHA256"].items():
        assert digest(Path(path)) == expected
    target = ROOT / "work/110保存要求" / (label+".json")
    assert not target.exists() and not (ROOT / "work/110保存" / label).exists()
    request = {"version": 1, "trial": 110, "fixed": True, "stage": args.stage,
               "condition": {"path": str(condition), "sha256": CONDITION_SHA},
               "completion": {"path": str(completion), "sha256": args.completion_sha},
               "code_sha256": stopped["コードSHA256"], "saving_stop": {"path": str(saving), "sha256": SAVING_SHA},
               "生成器": {"path": str(Path(__file__).resolve()), "sha256": digest(Path(__file__))}}
    with target.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(request, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"保存要求": str(target), "sha256": digest(target), "stage": args.stage, "Native本文読取": False}, ensure_ascii=False))


if __name__ == "__main__":
    main()
