"""StageBの旧/対称Source×LD10四感度を固定103保存算術で確認する。"""

import argparse
from collections import defaultdict
import hashlib
import importlib.util
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
LEGACY_PATH = ROOT / "work/103多玉の保存集計/集計.py"
LEGACY_SHA = "aa1f27f56a54db0288c6e48d83bd292f424af720a5573fa774349489b206bd57"
if hashlib.sha256(LEGACY_PATH.read_bytes()).hexdigest() != LEGACY_SHA:
    raise ValueError("固定103保存のSHA差")
SPEC = importlib.util.spec_from_file_location("StageBで再用する固定103", LEGACY_PATH)
OLD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)
need, equal = OLD.need, OLD.equal
MODES = ("legacy", "symmetric")
INNER_KEYS = tuple(f"LD10_B5Q_P0_C{c}_D{d}" for c in (0, 5) for d in (0, 1))
KEYS = tuple(f"{mode}_{key}" for mode in MODES for key in INNER_KEYS)
SOURCE_MODES = {f"{mode}_{key}": mode for mode in MODES for key in INNER_KEYS}


def outer_key(mode, inner):
    """
    機能: 所属Sourceを外側だけで区別する。
    引数: mode/inner(str)は旧/対称Sourceと旧LD10本名。
    返り値: strは8つの外key。内部Bookや注文IDは改名しない。
    """
    need(mode in MODES and inner in INNER_KEYS, "StageB本名の破損")
    return mode + "_" + inner


def inspect_scene(value, full_clock=False):
    """
    機能: 主8口座の所属と旧LD10保存全fieldを検査する。
    引数: value(dict)、full_clock(bool)は実Go型又はRoot成功後のNativeと時計範囲指定。
    返り値: dictは外keyごとの検算済み保存台帳。金融再生はしない。
    """
    equal(set(value["books"]), set(KEYS), "StageB旧/対称の全8book")
    equal(value["source_mode_by_book"], SOURCE_MODES, "SourceModeの所属")
    checked, clocks = {}, None
    for mode in MODES:
        for inner in INNER_KEYS:
            key = outer_key(mode, inner)
            book = value["books"][key]
            equal(book["key"], inner, "内部LD10本名を維持")
            if "session" in value:
                equal(book["session"], value["session"], "8bookと外側の場を維持")
            checked[key] = OLD.verify_book(book, inner, full_clock)
            current = [row["at"] for row in book["grid_traces"]]
            if clocks is None:
                clocks = current
            else:
                equal(current, clocks, "旧/対称の同じgrid列")
    if "grid_times" in value:
        equal(value["grid_times"], clocks, "配送済み8bookのgrid列")
    return checked


def compare_control(value, baseline):
    """
    機能: legacy LD10四を旧103の実保存全JSONへ結ぶ。
    引数: value/baseline(dict)は新Nativeと固定103又は明示型人工の旧保存。
    返り値: None。SourceMode以外のfieldを除外しない。
    """
    proof = value["control103"]
    need(proof["all"] is True and proof["books"] == 4, "旧103対照未成立")
    equal(proof["keys"], list(INNER_KEYS), "旧103対照四本名")
    equal(proof["excluded"], [], "旧103全JSONは除外0")
    need(isinstance(proof["baseline_sha256"], str) and len(proof["baseline_sha256"]) == 64, "旧103出典SHA欠落")
    for key in INNER_KEYS:
        equal(value["books"][outer_key("legacy", key)], baseline["books"][key], "旧103全field対照")


def scene_rows(value, checked):
    """
    機能: 旧103の実現/参加/初正益と起動別赤字を8主設定へ集約する。
    引数: value/checked(dict)は保存値と検算済み台帳。
    返り値: list[dict]は外key/SourceMode付きの小型場別値。
    """
    result = []
    for key in KEYS:
        book = value["books"][key]
        result.append({"session": book["session"]["id"], "key": key, "source_mode": SOURCE_MODES[key], **OLD.summarize_book(book, checked[key])})
    return result


def compare_modes(checked):
    """
    機能: 同実入口差/取得変更/片参加を既存の全Source指紋で分ける。
    引数: checked(dict)は8検算済み保存台帳。
    返り値: dictは4感度の加法分解。番号だけで玉を一致させない。
    """
    return {key: OLD.compare_positions(checked[outer_key("legacy", key)], checked[outer_key("symmetric", key)]) for key in INNER_KEYS}


def save_viewer(value, out):
    """
    機能: 主8の全実Fillを既存Viewer形式へ変換する。
    引数: value(dict)、out(Path)は保存Nativeと新規保存先。
    返り値: list[dict]は8resource。実Viewer通信やSourceA資料との混在はしない。
    """
    resources = []
    for key in KEYS:
        book = value["books"][key]
        session = book["session"]["id"]
        name = f"104B_{key}_{session}.trades.jsonl"
        with (out / name).open("x", encoding="utf-8", newline="\n") as stream:
            for row in OLD.BASE.viewer_trades(book):
                stream.write(json.dumps(row, ensure_ascii=False, default=OLD.BASE.serial, allow_nan=False) + "\n")
        resources.append({"id": f"104B_{key}_{session}", "title": f"Source方向裁定と同一LD10 {key} {session}", "symbol": "NK225", "product": "NK225mini", "session": session, "method_id": key, "point_value": 100, "pnl_format": "trades", "pnl_basis": "net", "pnl_path": name, "market_path": f"NK225/{session}/book.jsonl.gz"})
    return resources


def aggregate(rows, full54=False):
    """
    機能: 旧103の連結DD/日夜/日別を8主設定へ直接再用する。
    引数: rows(list[dict])、full54(bool)は場別保存値と予定分母指定。
    返り値: tupleは主集計と日夜/日別。費用感度を独立市場標本にしない。
    """
    summary, diagnostics = {}, {}
    for key in KEYS:
        selected = [r for r in rows if r["key"] == key]
        need(bool(selected), "集計対象8設定欠落")
        summary[key] = OLD.combine(selected)
        if full54:
            equal(summary[key]["活動主表"]["denom"], 6048, "主6048")
            equal(summary[key]["活動副表"]["denom"], 5832, "副5832")
        dates = sorted({r["session"][:10] for r in selected})
        diagnostics[key] = {"日夜": {kind: OLD.combine([r for r in selected if r["session"].endswith("_" + kind)]) for kind in ("Day", "Night") if any(r["session"].endswith("_" + kind) for r in selected)}, "日別": [{"開始日": day, **OLD.combine([r for r in selected if r["session"].startswith(day)])} for day in dates]}
    return summary, diagnostics


def configurations():
    """
    機能: StageBの8設定をruntimeと同じ順に明示する。
    引数: なし。
    返り値: list[dict]は旧/対称各LD10四。default経済口座はない。
    """
    return [{"source_mode": mode, "policy": "P0", "activation_policy": "LD10", "slip_pts": c, "delay_seconds": d} for mode in MODES for c in (0, 5) for d in (0, 1)]


def expected_sessions(stage):
    """
    機能: 同じ既使用54又は先頭2の集合を作る。
    引数: stage(str)はfirst2/full54。
    返り値: list[str]は旧103の許可日順。
    """
    need(stage in ("first2", "full54"), "保存stage不正")
    result, day = [], OLD.date(2026, 9, 21)
    while day <= OLD.date(2026, 10, 27):
        if day.weekday() < 5:
            result.extend(f"{day}_{kind}" for kind in ("Day", "Night"))
        day += OLD.timedelta(days=1)
    return result[:2] if stage == "first2" else result


def valid_sha(value):
    """
    機能: 未固定/不正なFileRef SHAを拒否する。
    引数: value(str)は期待SHA。
    返り値: boolは小文字64桁なら真。
    """
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def bind_ref(ref, base, before):
    """
    機能: 明示FileRefを現物SHAへ結ぶ。
    引数: ref(dict)、base(Path)、before(dict)は保存参照/基準/前指紋。
    返り値: Pathは照合済み保存物。Raw/CSV参照には使わない。
    """
    need(set(ref) == {"path", "sha256"} and bool(ref["path"]) and valid_sha(ref["sha256"]), "未固定FileRef")
    path = Path(ref["path"])
    path = (path if path.is_absolute() else base / path).resolve()
    equal(OLD.digest(path), ref["sha256"], "保存FileRef SHA")
    need(str(path) not in before or before[str(path)] == ref["sha256"], "同path別SHA")
    before[str(path)] = ref["sha256"]
    return path


def validate_completion(condition, done, stage, condition_sha):
    """
    機能: 完了metadataを8主口座/旧対照/前後不変へ結ぶ。
    引数: condition/done(dict)、stage/condition_sha(str)はRoot固定と成功完了。
    返り値: list[dict]は場別Native FileRef。本文はまだ読まない。
    """
    ids = expected_sessions(stage)
    need(condition["version"] == 1 and condition["trial"] == 104 and condition["fixed"] is True, "StageB条件固定")
    equal(condition["configs"], configurations(), "StageB条件8設定")
    need(done["version"] == 1 and done["trial"] == 104 and done["stage"] == stage and done["success"] is True and not done.get("error"), "StageB金融未成功")
    equal(done["condition_sha256"], condition_sha, "金融同条件")
    equal(done["configs"], configurations(), "金融完了8設定")
    need(done["sessions"] == len(ids) and done["books_per_scene"] == 8 and done["books"] == 8 * len(ids) and done["legacy_control_books"] == 4 * len(ids) and done["default_books"] == 0, "8主/旧対照/default0の予定数")
    need(done["unchanged"] is True and bool(done["before"]) and done["before"] == done["after"] and done["source_reexecuted"] is False and done["charts_recomputed"] is False and done["gate_executed"] is False and done["raw_csv_read"] == 0, "再用範囲/前後不変")
    tasks = done["results"]
    equal([row["session"] for row in tasks], ids, "金融の完全場集合")
    for row in tasks:
        need(row["books"] == 8 and row["legacy_control_books"] == 4 and not row.get("error"), "場別全8/旧4未成功")
        need(set(row["native"]) == {"path", "sha256"} and bool(row["native"]["path"]) and valid_sha(row["native"]["sha256"]), "場別Native未固定")
    return tasks


def validate_native(value, session):
    """
    機能: Nativeの経済8設定と通知QA defaultを別に検査する。
    引数: value(dict)、session(str)はruntime公開型と場ID。
    返り値: None。bindingを再計算した独立成功とは呼ばない。
    """
    need(value["version"] == 1 and value["trial"] == 104 and value["complete"] is True and value["input_unchanged"] is True, "StageB Native未完結")
    need(value["source_reexecuted"] is False and value["charts_recomputed"] is False and value["gate_executed"] is False, "Nativeの再用範囲")
    equal(value["session"]["id"], session, "Native場ID")
    for field in ("bindings", "input_source_records", "source_results"):
        equal(set(value[field]), {"legacy", "default", "symmetric"}, "3mode通知QAの出典集合")
    equal(set(value["tape_canonical_sha256"]), set(MODES), "経済運転は旧/対称の2modeのみ")
    need(all(valid_sha(h) for h in value["tape_canonical_sha256"].values()), "新Tape canonical未固定")
    for mode, proof in value["bindings"].items():
        need(proof["mode_declared"] == mode and proof["source_formed_here"] is False and proof["financial_executed_here"] is False, "binding scope/SourceMode")
        if mode in ("legacy", "default"):
            need(proof["notifications_equal_old"] is True, "旧/default通知不一致")
        need(valid_sha(proof["input_tape_canonical_sha256"]) and valid_sha(proof["records_canonical_sha256"]), "binding出典未固定")
        need(proof["grids"] == len(value["grid_times"]), "binding/grid時計集合")


def prepare(fixed_path, fixed_sha, out):
    """
    機能: Rootの保存用3FileRefを金融Native本文より先に検査する。
    引数: fixed_path/out(Path)、fixed_sha(str)はRoot事後固定と新規保存先。
    返り値: tupleは対象task/前指紋/固定証拠/条件/完了。Rawを開かない。
    """
    need(not out.exists() and valid_sha(fixed_sha), "新規保存先/Root固定SHA")
    equal(OLD.digest(fixed_path), fixed_sha, "保存Root固定SHA")
    fixed = OLD.load(fixed_path)
    need(fixed["version"] == 1 and fixed["trial"] == 104 and fixed["phase"] == "StageB" and fixed["fixed"] is True, "保存StageB固定が必要")
    before = {str(fixed_path): fixed_sha, str(LEGACY_PATH): LEGACY_SHA, str(OLD.GRID_PATH): OLD.GRID_SHA, str(OLD.GRID.BASE_PATH): OLD.GRID.BASE_SHA}
    paths = {name: bind_ref(fixed[name], fixed_path.parent, before) for name in ("condition", "completion", "code")}
    equal(paths["code"], Path(__file__).resolve(), "実保存code本名")
    condition, done = OLD.load(paths["condition"]), OLD.load(paths["completion"])
    tasks = validate_completion(condition, done, fixed["stage"], fixed["condition"]["sha256"])
    equal(done["before"].get(str(paths["condition"])), fixed["condition"]["sha256"], "完了の条件出典")
    for name, expected in condition["code_sha256"].items():
        path = (ROOT / name).resolve()
        equal(OLD.digest(path), expected, "固定実行code現物")
        equal(done["before"].get(str(path)), expected, "完了の固定code出典")
        before[str(path)] = expected
    for name in ("source_full", "old100_tape_index", "first2_bind", "binder_stop", "baseline103_index", "binary"):
        path = bind_ref(condition[name], paths["condition"].parent, before)
        equal(done["before"].get(str(path)), condition[name]["sha256"], "完了の固定入力出典")
    resolved = []
    for row in tasks:
        path = bind_ref(row["native"], paths["completion"].parent, before)
        need(path.name == row["session"] + ".json.gz", "金融Native本名")
        resolved.append({**row, "resolved_path": path})
    proofs = {"Root固定SHA256": fixed_sha, **{name + "SHA256": fixed[name]["sha256"] for name in paths}}
    return resolved, before, proofs, condition, done


def generate(fixed_path, fixed_sha, out):
    """
    機能: 成功したStageB保存だけを検算し主8の資料を生成する。
    引数: fixed_path/out(Path)、fixed_sha(str)はRootが事後固定する入口。
    返り値: dictは成功数。Source/金融/Raw/HTTPを実行しない。
    """
    tasks, before, proofs, condition, done = prepare(fixed_path, fixed_sha, out)
    rows, refs, resources = [], [], []
    comparisons = defaultdict(list)
    out.mkdir(parents=True, exist_ok=False)
    for task in tasks:
        value = OLD.load(task["resolved_path"])
        validate_native(value, task["session"])
        # 元Sourceは参照SHAだけを確認し、ここで形成/通知再生しない。
        base = task["resolved_path"].parent
        for field in ("old_tape", "baseline103"):
            path = bind_ref(value[field], base, before)
            equal(done["before"].get(str(path)), value[field]["sha256"], "Native参照は金融が使用した入力")
        for group in ("input_source_records", "source_results"):
            for ref in value[group].values():
                path = bind_ref(ref, base, before)
                equal(done["before"].get(str(path)), ref["sha256"], "SourceMode参照は金融使用入力")
        baseline_path = bind_ref(value["baseline103"], base, before)
        equal(value["control103"]["baseline_sha256"], value["baseline103"]["sha256"], "旧103出典SHA")
        compare_control(value, OLD.load(baseline_path))
        checked = inspect_scene(value, True)
        rows.extend(scene_rows(value, checked))
        for key, comparison in compare_modes(checked).items():
            comparisons[key].append({"session": task["session"], **comparison})
        resources.extend(save_viewer(value, out))
        refs.append({"session": task["session"], **task["native"]})
    summary, diagnostics = aggregate(rows, done["stage"] == "full54")
    after = {name: OLD.digest(Path(name)) for name in before}
    equal(after, before, "保存入力/code前後不変")
    result = {"試行": 104, "フェーズ": "StageB", "成功": True, "scope": "旧/対称Sourceへ同じLD10四感度。103保存算術と限定因果・保存点DD。全原行別engine金融再生ではない", **proofs, "場数": len(tasks), "会計数": 8 * len(tasks), "主会計数": 8 * len(tasks), "診断会計数": 0, "主key": list(KEYS), "Actor設定": {outer_key(mode, key): {"SourceMode": mode, "入口": "Gate無しB5Q", "基本保護": "P0", "起動": "LD10", "slip_pts": c, "delay_seconds": d} for mode in MODES for c in (0, 5) for d in (0, 1) for key in [f"LD10_B5Q_P0_C{c}_D{d}"]}, "集計": summary, "実現診断": diagnostics, "場別": rows, "旧対称の同実入口と実参加差": dict(comparisons), "旧103LD10全文対照": {"会計": 4 * len(tasks), "除外": [], "実保存再読": True}, "Native参照": refs, "SourceA元連続会計": "含めない。defaultは通知QAのみで経済会計0", "Viewer形式資源": len(resources), "実Viewer通信": 0, "入力codeSHA256前": before, "入力codeSHA256後": after, "前後不変": True, "未評価": ["未使用期間の成績", "全原行の別engine再生", "Source全体の完全鏡像", "機会損失/未参加・退出後仮想利益", "MFE/回収率"]}
    OLD.BASE.write_json(out / "結果.json", result)
    OLD.BASE.write_json(out / "一覧.resources.json", {"schema_version": 1, "path_base": "catalog", "resources": resources})
    lines = ["# StageB LD10保存結果", "", result["scope"], "", "SourceA連続会計とは別。主8のみ、default経済口座は0。", "", "|Key|純額|u正益後赤字額|起動後赤字額|参加|25%/50%|保存点DD|", "|---|---:|---:|---:|---:|---|---:|"]
    for key, row in summary.items():
        a = row["活動主表"]
        lines.append(f"|{key}|{row['net_yen']}|{row['unit_positive_closed_negative_yen']}|{row['activated_closed_negative_yen']}|{a['active']}/{a['denom']}|{a['最低25%']}/{a['目標50%']}|{row['保存点連結時価DD']}|")
    (out / "結果.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    outputs = {p.name: OLD.digest(p) for p in out.iterdir() if p.is_file()}
    OLD.BASE.write_json(out / "保存会計の確認.json", {"成功": True, **proofs, "フェーズ": "StageB", "会計": 8 * len(tasks), "資源": len(resources), "不一致数": 0, "入力codeSHA256前": before, "入力codeSHA256後": after, "前後不変": True, "出力SHA256": outputs, "Source/金融/Raw/CSV/HTTP再実行": 0})
    return {"成功": True, "場数": len(tasks), "会計": 8 * len(tasks), "Viewer形式資源": len(resources), "実Viewer通信": 0}


def main():
    """
    機能: Rootの成功通知後に保存用固定JSONを受けるCLI。
    引数: --fixed/--fixed-sha/--outは事後固定3FileRefと新規保存先。
    返り値: None。未固定/未成功はNative読取前に拒否する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixed", type=Path, required=True)
    parser.add_argument("--fixed-sha", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(generate(args.fixed.resolve(), args.fixed_sha, args.out), ensure_ascii=False))


if __name__ == "__main__":
    main()
