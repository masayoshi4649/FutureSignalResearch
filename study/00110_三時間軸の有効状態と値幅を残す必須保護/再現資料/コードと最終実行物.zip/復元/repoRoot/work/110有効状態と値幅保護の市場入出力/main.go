package main

import (
	"flag"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"sync"
	"sync/atomic"
)

type Completion struct {
	Version                  int               `json:"version"`
	Trial                    int               `json:"trial"`
	Stage                    string            `json:"stage"`
	Success                  bool              `json:"success"`
	ConditionSHA             string            `json:"condition_sha256"`
	Sessions                 int               `json:"sessions"`
	BooksPerScene            int               `json:"books_per_scene"`
	Books                    int               `json:"books"`
	ShadowBooks              int               `json:"shadow_books"`
	Comparisons              int               `json:"baseline_comparisons"`
	Results                  []SceneResult     `json:"results"`
	Before                   map[string]string `json:"before"`
	After                    map[string]string `json:"after"`
	Unchanged                bool              `json:"unchanged"`
	First2                   *FileRef          `json:"first2,omitempty"`
	InputMode                string            `json:"source_scope"`
	ClockModel               string            `json:"clock_model"`
	Workers                  int               `json:"workers"`
	Seeds                    []SeedNode        `json:"seed_plan"`
	SeedSHA                  string            `json:"seed_plan_sha256"`
	SeedScenes               int               `json:"seed_scenes"`
	CSVInputs                int               `json:"nk225_csv_inputs"`
	UnusedTOPIXCSV           int               `json:"unread_topix_csv_inputs"`
	SourceReexecuted         bool              `json:"source_reexecuted"`
	SourceFeaturesRecomputed bool              `json:"source_features_recomputed"`
	ChartsRecomputed         bool              `json:"charts_recomputed"`
	BankRecomputed           bool              `json:"bank_recomputed"`
	CMPRecomputed            bool              `json:"cmp_recomputed"`
	EntryCandleRecomputed    bool              `json:"entry_candle_recomputed"`
	NewSeriesBankFormed      bool              `json:"new_series_bank_formed"`
	ProtectionVFormed        bool              `json:"protection_v5_formed"`
	FinancialExecuted        bool              `json:"financial_executed"`
	RawRead                  bool              `json:"raw_market_read"`
	RawCopied                bool              `json:"raw_copied"`
	CSVCopied                bool              `json:"csv_copied"`
	CSVRegenerated           bool              `json:"csv_regenerated"`
	Error                    string            `json:"error,omitempty"`
}

// validateFirst2 は同一固定条件で成功した最初2場だけをfull70の前提にします。
//
// 引数: old(Completion)、p(Plan)は保存段階と今回固定。返り値: errorは部分成功/別条件/再形成範囲の差です。
func validateFirst2(old Completion, p Plan) error {
	if len(p.Manifest.Sessions) != 70 || len(p.ConditionSHA) != 64 || !old.Success || old.Error != "" || old.Stage != "first2" || old.Trial != 110 || old.ConditionSHA != p.ConditionSHA || old.Sessions != 2 || old.Books != 72 || old.BooksPerScene != 36 || old.ShadowBooks != 0 || old.Comparisons != 8 || old.InputMode != p.Condition.Mode || old.ClockModel != ClockModel || len(old.Before) == 0 || !old.Unchanged || !reflect.DeepEqual(old.Before, old.After) || len(old.Results) != 2 || old.SourceReexecuted || old.SourceFeaturesRecomputed || old.ChartsRecomputed || old.BankRecomputed || !old.CMPRecomputed || !old.EntryCandleRecomputed || !old.NewSeriesBankFormed || !old.ProtectionVFormed || !old.FinancialExecuted || old.RawRead || old.RawCopied || old.CSVCopied || old.CSVRegenerated || old.SeedScenes != 70 || old.CSVInputs != 70 || old.UnusedTOPIXCSV != 70 || len(old.Seeds) != 70 || len(old.SeedSHA) != 64 {
		return fmt.Errorf("同一条件first2全成功の固定不足")
	}
	for i, node := range old.Seeds {
		if node.Ordinal != i+1 || node.Session.ID != p.Manifest.Sessions[i].ID || !node.Output.Sealed || node.Output.Session != node.Session || node.Output.ObservedAt != node.Session.EOF || i == 0 && node.Input != nil || i > 0 && (node.Input == nil || !reflect.DeepEqual(*node.Input, old.Seeds[i-1].Output)) {
			return fmt.Errorf("first2の全70事前種の因果差")
		}
	}
	for i, r := range old.Results {
		if r.Session != p.Manifest.Sessions[i].ID || r.Error != "" || r.Books != 36 || r.ShadowBooks != 0 || r.Comparisons != 4 || !r.BaselineAll || r.PriorBooks != 12 || !r.PriorUnchanged || !r.SeedEqual || !r.Unchanged || !r.FinancialExecuted || r.FinancialDispatches <= 0 || !reflect.DeepEqual(r.Before, r.After) || !reflect.DeepEqual(r.SeedExpected, r.SeedActual) {
			return fmt.Errorf("first2の場/36Main/種/対照差")
		}
		if !reflect.DeepEqual(r.SeedExpected, old.Seeds[i].Output) {
			return fmt.Errorf("first2の場末尾種と事前計画差")
		}
	}
	h, err := valueSHA(old.Seeds)
	if err != nil || h != old.SeedSHA {
		return fmt.Errorf("first2の種計画SHA差")
	}
	return nil
}

// execute はRootが固定したrecorded70だけをfirst2→full70へ配送します。
//
// 引数: condition/conditionSHA/stage/first2/first2SHA/out(string)は絶対固定参照と新規先。
// 返り値: errorは固定・段階・入力・金融・前後指紋の不成立です。未固定案は拒否します。
func execute(condition, conditionSHA, stage, first2, first2SHA, out string) error {
	if !filepath.IsAbs(out) {
		return fmt.Errorf("出力先は絶対pathが必要")
	}
	if _, err := os.Stat(out); !os.IsNotExist(err) {
		return fmt.Errorf("出力先は未使用directoryが必要")
	}
	p, err := prepare(condition, conditionSHA)
	if err != nil {
		return err
	}
	if stage != "first2" && stage != "full70" {
		return fmt.Errorf("段階はfirst2/full70だけ")
	}
	var old Completion
	var firstRef *FileRef
	if stage == "full70" {
		if !filepath.IsAbs(first2) {
			return fmt.Errorf("first2は絶対pathが必要")
		}
		q, e := checkRef(FileRef{first2, first2SHA}, p.Base, p.Before)
		if e != nil {
			return e
		}
		if e = readJSON(q, false, &old); e != nil {
			return e
		}
		if e = validateFirst2(old, p); e != nil {
			return e
		}
		firstRef = &FileRef{q, first2SHA}
		for _, r := range old.Results {
			for _, ref := range []FileRef{r.Native, r.PriorNative, r.Header, r.Records, {r.CSV.Path, r.CSV.SHA256}} {
				if _, e = checkRef(ref, p.Base, p.Before); e != nil {
					return e
				}
			}
		}
	} else if first2 != "" || first2SHA != "" {
		return fmt.Errorf("first2段階に以前の段階を混入")
	}
	seeds, err := prepareSeeds(&p)
	if err != nil {
		return err
	}
	if len(seeds.Nodes) != 70 || len(seeds.Scenes) != 70 {
		return fmt.Errorf("並列前の全70因果Seed不足")
	}
	if firstRef != nil && (old.SeedSHA != seeds.SHA || !reflect.DeepEqual(old.Seeds, seeds.Nodes)) {
		return fmt.Errorf("first2/full70の事前種計画差")
	}
	if _, err = recheck(p.Before); err != nil {
		return err
	}
	ids := []string{}
	for _, s := range p.Manifest.Sessions {
		ids = append(ids, s.ID)
	}
	if stage == "first2" {
		ids = ids[:2]
	}
	if err = os.MkdirAll(out, 0755); err != nil {
		return err
	}
	done := Completion{Version: 1, Trial: 110, Stage: stage, ConditionSHA: conditionSHA, BooksPerScene: 36, Before: p.Before, First2: firstRef, InputMode: p.Condition.Mode, ClockModel: ClockModel, Workers: p.Condition.Workers,
		Seeds: seeds.Nodes, SeedSHA: seeds.SHA, SeedScenes: 70, CSVInputs: 70, UnusedTOPIXCSV: 70, CMPRecomputed: true, EntryCandleRecomputed: true, NewSeriesBankFormed: true, ProtectionVFormed: true}
	results := parallelScenes(p, ids, out, seeds)
	byID := map[string]SceneResult{}
	for _, r := range results {
		byID[r.Session] = r
	}
	for _, id := range ids {
		r, ok := byID[id]
		if !ok {
			r = SceneResult{Session: id, Error: "独立worker結果欠落"}
		}
		done.Results = append(done.Results, r)
		done.FinancialExecuted = done.FinancialExecuted || r.FinancialExecuted
		if r.Error != "" {
			done.Error += id + ":" + r.Error + "\n"
			continue
		}
		if err = mergeFingerprint(done.Before, r.Before); err != nil {
			done.Error += err.Error() + "\n"
		}
		done.Sessions++
		done.Books += r.Books
		done.ShadowBooks += r.ShadowBooks
		done.Comparisons += r.Comparisons
	}
	if firstRef != nil {
		for i, r := range old.Results {
			got := done.Results[i]
			if got.Error != "" || got.Native.SHA != r.Native.SHA || got.Header != r.Header || got.Records != r.Records || got.CSV != r.CSV || got.PriorNative != r.PriorNative || !reflect.DeepEqual(got.SeedActual, r.SeedActual) {
				done.Error += "先頭2場の同条件bytes/参照/Seed差:" + r.Session + "\n"
			}
		}
	}
	done.After, err = recheck(done.Before)
	if err != nil {
		done.Error += err.Error() + "\n"
	}
	done.Unchanged = err == nil && reflect.DeepEqual(done.Before, done.After)
	done.Success = done.Error == "" && done.Sessions == len(ids) && done.Books == 36*len(ids) && done.ShadowBooks == 0 && done.Comparisons == 4*len(ids) && done.Unchanged
	if _, err = writeJSON(filepath.Join(out, "完了.json"), done, false); err != nil {
		return err
	}
	if !done.Success {
		return fmt.Errorf("110 recorded金融失敗:%s", done.Error)
	}
	fmt.Printf("110 %s 成功 %d場/%dMain/Shadow0/比較%d\n", stage, done.Sessions, done.Books, done.Comparisons)
	return nil
}

// parallelScenes は事前種を共有不変値として最大4独立Coreへ渡します。
//
// 引数: p(Plan)、ids([]string)、out(string)、seeds(SeedPlan)は固定と順序。返り値: []SceneResultは完了順です。
func parallelScenes(p Plan, ids []string, out string, seeds SeedPlan) []SceneResult {
	jobs := make(chan string, len(ids))
	results := make(chan SceneResult, len(ids))
	for _, id := range ids {
		jobs <- id
	}
	close(jobs)
	var group sync.WaitGroup
	var failed atomic.Bool
	workers := min(p.Condition.Workers, len(ids))
	for i := 0; i < workers; i++ {
		group.Add(1)
		go func() {
			defer group.Done()
			for id := range jobs {
				if failed.Load() {
					results <- SceneResult{Session: id, Error: "他場失敗のため未実行"}
					continue
				}
				r := runScene(p, id, out, seeds.Scenes[id])
				if r.Error != "" {
					failed.Store(true)
				}
				results <- r
			}
		}()
	}
	go func() { group.Wait(); close(results) }()
	all := []SceneResult{}
	for r := range results {
		all = append(all, r)
		if r.Error == "" {
			fmt.Printf("110 %d/%d %s Main36/Shadow0/比較4\n", len(all), len(ids), r.Session)
		} else {
			fmt.Fprintf(os.Stderr, "110 %s 失敗:%s\n", r.Session, r.Error)
		}
	}
	return all
}

// main はRootの固定SHAを明示した実行だけを受け付けます。
//
// 引数: コマンドラインcondition/stage/first2/out。返り値: ありません。失敗は終了1です。
func main() {
	condition := flag.String("condition", "", "109固定条件")
	checksum := flag.String("condition-sha", "", "固定SHA256")
	stage := flag.String("stage", "", "first2/full70")
	first := flag.String("first2", "", "同条件の成功first2絶対path")
	firstSHA := flag.String("first2-sha", "", "first2 SHA")
	out := flag.String("out", "", "新規絶対保存先")
	flag.Parse()
	if *condition == "" || *checksum == "" || *out == "" {
		fmt.Fprintln(os.Stderr, "固定条件/SHA/新規先が必要")
		os.Exit(1)
	}
	if err := execute(*condition, *checksum, *stage, *first, *firstSHA, *out); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
