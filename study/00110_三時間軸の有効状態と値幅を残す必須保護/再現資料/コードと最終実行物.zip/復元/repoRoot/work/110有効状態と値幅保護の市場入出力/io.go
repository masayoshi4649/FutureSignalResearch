package main

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
)

type FileRef struct {
	Path string `json:"path"`
	SHA  string `json:"sha256"`
}

// fileSHA は実物の全bytesを指紋へ変換します。
//
// 引数: path(string)はコード、保存列、又は小さい固定JSONです。
// 返り値: string/errorはSHA256又は読取失敗です。原板は呼出側から渡しません。
func fileSHA(path string) (string, error) {
	f, err := os.Open(path)
	if err != nil {
		return "", err
	}
	defer f.Close()
	h := sha256.New()
	if _, err = io.Copy(h, f); err != nil {
		return "", err
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

// absolute は固定参照を条件JSONの親から解決します。
//
// 引数: base/path(string)は基準directoryと参照。
// 返り値: string/errorは絶対path又は解決失敗です。
func absolute(base, path string) (string, error) {
	if path == "" {
		return "", fmt.Errorf("空の参照pathです")
	}
	if !filepath.IsAbs(path) {
		path = filepath.Join(base, path)
	}
	return filepath.Abs(path)
}

// checkRef は同じ実参照の別宣言や変更を拒否します。
//
// 引数: ref(FileRef)、base(string)、before(map[string]string)は固定参照と記録先です。
// 返り値: string/errorは認証した絶対path又は不一致です。
func checkRef(ref FileRef, base string, before map[string]string) (string, error) {
	if !filepath.IsAbs(ref.Path) {
		return "", fmt.Errorf("FileRefは絶対pathが必要です:%s", ref.Path)
	}
	p, err := absolute(base, ref.Path)
	if err != nil {
		return "", err
	}
	if len(ref.SHA) != 64 {
		return "", fmt.Errorf("参照SHAの長さが不正です")
	}
	got, err := fileSHA(p)
	if err != nil {
		return "", err
	}
	if got != ref.SHA {
		return "", fmt.Errorf("参照SHA差:%s", p)
	}
	if old, ok := before[p]; ok && old != got {
		return "", fmt.Errorf("同pathへ異なる指紋:%s", p)
	}
	before[p] = got
	return p, nil
}

// readJSON は単一の保存JSON又はgzipを型へ読み込みます。
//
// 引数: path(string)、zipped(bool)、target(any)は実参照と型のpointer。
// 返り値: errorは読取・構文・末尾の余剰JSONです。
func readJSON(path string, zipped bool, target any) error {
	f, err := os.Open(path)
	if err != nil {
		return err
	}
	defer f.Close()
	var r io.Reader = f
	if zipped {
		gz, err := gzip.NewReader(f)
		if err != nil {
			return err
		}
		defer gz.Close()
		r = gz
	}
	d := json.NewDecoder(r)
	if err = d.Decode(target); err != nil {
		return err
	}
	var extra any
	if err = d.Decode(&extra); err != io.EOF {
		return fmt.Errorf("JSON末尾又は余剰値:%v", err)
	}
	return nil
}

// writeJSON は新規先だけへ決定的なJSONを保存します。
//
// 引数: path(string)、value(any)、zipped(bool)は新規先・全値・圧縮有無。
// 返り値: FileRef/errorは保存指紋又は書込失敗です。
func writeJSON(path string, value any, zipped bool) (FileRef, error) {
	f, err := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0644)
	if err != nil {
		return FileRef{}, err
	}
	var w io.Writer = f
	var gz *gzip.Writer
	if zipped {
		gz, err = gzip.NewWriterLevel(f, gzip.BestSpeed)
		if err != nil {
			f.Close()
			return FileRef{}, err
		}
		w = gz
	}
	e := json.NewEncoder(w)
	e.SetIndent("", "  ")
	err = e.Encode(value)
	if gz != nil {
		if closeErr := gz.Close(); err == nil {
			err = closeErr
		}
	}
	if closeErr := f.Close(); err == nil {
		err = closeErr
	}
	if err != nil {
		return FileRef{}, err
	}
	p, err := filepath.Abs(path)
	if err != nil {
		return FileRef{}, err
	}
	h, err := fileSHA(p)
	return FileRef{Path: p, SHA: h}, err
}

// recheck は条件・code・参照の前後を照合します。
//
// 引数: before(map[string]string)は読取前の実指紋です。
// 返り値: map[string]string/errorは後指紋又は変更です。
func recheck(before map[string]string) (map[string]string, error) {
	after := map[string]string{}
	for p, expected := range before {
		h, err := fileSHA(p)
		if err != nil {
			return after, err
		}
		after[p] = h
		if h != expected {
			return after, fmt.Errorf("実行中に参照変更:%s", p)
		}
	}
	return after, nil
}
