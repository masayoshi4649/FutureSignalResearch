package main

import (
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"regexp"

	finance "github.com/masayoshi4649/SessionTradeExecuter/miniprofit110"
	reader "github.com/masayoshi4649/SessionTradeExecuter/savedpublic107"
	core "github.com/masayoshi4649/SessionTradeExecuter/threeguardruntime110"
)

const ClockModel = "csv_end_plus60_at_record_scheduler"

const publisherStopSHA = "b6b1a326cc98f67e13ec1962a19bac001eda743880b74a13066a2307c5944895"

type StopDeclaration struct {
	Success   bool              `json:"成功"`
	Owned     map[string]string `json:"所有コードSHA256"`
	Before    map[string]string `json:"コードSHA256前"`
	After     map[string]string `json:"コードSHA256後"`
	Unchanged bool              `json:"前後不変"`
}

type DeclaredConfig struct {
	Candidate     string                       `json:"candidate"`
	EntryPolicy   finance.CompositeEntryPolicy `json:"entry_policy"`
	EntryLifetime finance.EntryLifetime        `json:"entry_lifetime,omitempty"`
	Policy        finance.CompositeProtection  `json:"protection_policy"`
	Timing        string                       `json:"entry_timing"`
	QuietSeconds  int                          `json:"quiet_seconds"`
	Slip          float64                      `json:"slip_pts"`
	Delay         int                          `json:"delay_seconds"`
}

type Condition struct {
	Version          int               `json:"version"`
	Trial            int               `json:"trial"`
	Fixed            bool              `json:"fixed"`
	Scope            string            `json:"scope"`
	Mode             string            `json:"source_scope"`
	ClockModel       string            `json:"clock_model"`
	Workers          int               `json:"workers"`
	OwnModuleDir     string            `json:"own_module_dir"`
	SourceManifest   FileRef           `json:"source_manifest"`
	SourceCorpus     FileRef           `json:"source_corpus"`
	SourceCompletion FileRef           `json:"source_completion"`
	PriorClosure     FileRef           `json:"baseline_closure"`
	PriorCompletion  FileRef           `json:"baseline_completion"`
	PriorNativeIndex FileRef           `json:"baseline_native_index"`
	Binary           FileRef           `json:"binary"`
	Stops            []FileRef         `json:"stops"`
	Specifications   []FileRef         `json:"specifications"`
	Code             map[string]string `json:"code_sha256"`
	Configs          []DeclaredConfig  `json:"configs"`
}

type SizedRef struct {
	Path string `json:"path"`
	SHA  string `json:"sha256"`
	Size int64  `json:"size"`
}
type InputScene struct {
	ID       string              `json:"id"`
	Contract string              `json:"contract"`
	Files    map[string]SizedRef `json:"files"`
}
type Manifest struct {
	Root     string       `json:"source_root"`
	Sessions []InputScene `json:"sessions"`
}
type PriorScene struct {
	Session        string  `json:"session"`
	Native         FileRef `json:"native"`
	Header         FileRef `json:"sidecar_header"`
	Records        FileRef `json:"sidecar_records"`
	Books          int     `json:"books"`
	PriorBooks     int     `json:"prior_reference_books"`
	PriorUnchanged bool    `json:"prior_reference_unchanged"`
	Error          string  `json:"error,omitempty"`
}
type PriorCompletion struct {
	Version           int               `json:"version"`
	Trial             int               `json:"trial"`
	Stage             string            `json:"stage"`
	Success           bool              `json:"success"`
	ConditionSHA      string            `json:"condition_sha256"`
	Sessions          int               `json:"sessions"`
	BooksPerScene     int               `json:"books_per_scene"`
	Books             int               `json:"books"`
	Results           []PriorScene      `json:"results"`
	Before            map[string]string `json:"before"`
	After             map[string]string `json:"after"`
	Unchanged         bool              `json:"unchanged"`
	Mode              string            `json:"source_scope"`
	SourceReexecuted  bool              `json:"source_reexecuted"`
	ChartsRecomputed  bool              `json:"charts_recomputed"`
	FinancialExecuted bool              `json:"financial_executed"`
	Error             string            `json:"error,omitempty"`
}
type PriorNativeRow struct {
	Session   string  `json:"session"`
	Path      string  `json:"path"`
	SHA       string  `json:"sha256"`
	Bytes     int64   `json:"bytes"`
	Books     int     `json:"会計"`
	Original  FileRef `json:"元"`
	SameBytes bool    `json:"同bytes"`
	Public    struct {
		Header  FileRef `json:"sidecar_header"`
		Records FileRef `json:"sidecar_records"`
	} `json:"公開sidecar"`
}
type PriorNativeIndex struct {
	Success    bool   `json:"成功"`
	Trial      int    `json:"試行"`
	Base       string `json:"基準"`
	Sessions   int    `json:"場数"`
	Books      int    `json:"金融会計"`
	Completion struct {
		Path  string `json:"path"`
		SHA   string `json:"sha256"`
		Bytes int64  `json:"bytes"`
	} `json:"元金融完了"`
	Condition FileRef          `json:"金融条件"`
	Native    []PriorNativeRow `json:"Native"`
}
type Plan struct {
	Condition      Condition
	ConditionSHA   string
	Base           string
	Before         map[string]string
	Manifest       Manifest
	Source         reader.Completion
	Prior          PriorCompletion
	PriorIndex     PriorNativeIndex
	PriorIndexRoot string
	PriorNative    []FileRef
}

// declaredConfigurations はCoreの36設定を条件JSONの明示欄へ射影します。
//
// 引数: なし。返り値: []DeclaredConfigはcandidate/時計を省略しない順序付き36設定です。
func declaredConfigurations() []DeclaredConfig {
	rows := []DeclaredConfig{}
	for _, c := range core.Configurations() {
		rows = append(rows, DeclaredConfig{Candidate: core.CandidateKey(c), EntryPolicy: c.EntryPolicy, EntryLifetime: c.EntryLifetime, Policy: c.Policy, Timing: "B5QD", QuietSeconds: c.QuietSeconds, Slip: c.Slip, Delay: c.Delay})
	}
	return rows
}

// validateCondition は実入力を開く前に109の固定済みrecorded70設定を限定します。
//
// 引数: c(Condition)は固定宣言。返り値: errorは未固定/別mode/36設定差です。
func validateCondition(c Condition) error {
	if c.Version != 1 || c.Trial != 110 || !c.Fixed || c.Scope == "" || c.Mode != "recorded_public_106" || c.ClockModel != ClockModel ||
		c.Workers < 1 || c.Workers > 4 || !filepath.IsAbs(c.OwnModuleDir) || !reflect.DeepEqual(c.Configs, declaredConfigurations()) || len(c.Stops) < 8 || len(c.Specifications) < 2 || len(c.Code) == 0 {
		return fmt.Errorf("109固定/recorded70専用mode/時計モデル/36設定/停止参照が不正")
	}
	return nil
}

// prepare は固定condition/コード/完成Sourceと旧108のmetadataだけを認証します。
//
// 引数: path/expected(string)はRoot固定JSONとSHA。返り値: Plan/errorは計画又は拒否です。市場本文は読みません。
func prepare(path, expected string) (Plan, error) {
	p := Plan{Before: map[string]string{}}
	if !filepath.IsAbs(path) {
		return p, fmt.Errorf("条件JSONは絶対pathが必要")
	}
	p.Base, p.ConditionSHA = filepath.Dir(path), expected
	if _, err := checkRef(FileRef{path, expected}, p.Base, p.Before); err != nil {
		return p, err
	}
	if err := readJSON(path, false, &p.Condition); err != nil {
		return p, err
	}
	c := p.Condition
	if err := validateCondition(c); err != nil {
		return p, err
	}
	refs := append([]FileRef{c.SourceManifest, c.SourceCorpus, c.SourceCompletion, c.PriorClosure, c.PriorCompletion, c.PriorNativeIndex, c.Binary}, c.Stops...)
	refs = append(refs, c.Specifications...)
	for _, ref := range refs {
		if _, err := checkRef(ref, p.Base, p.Before); err != nil {
			return p, err
		}
	}
	code := map[string]string{}
	for name, h := range c.Code {
		q, err := checkRef(FileRef{name, h}, p.Base, p.Before)
		if err != nil {
			return p, err
		}
		code[q] = h
	}
	if err := verifyCodeScope(c.OwnModuleDir, code, c.Stops); err != nil {
		return p, err
	}
	exe, err := os.Executable()
	if err != nil {
		return p, err
	}
	actual, err := fileSHA(exe)
	if err != nil || actual != c.Binary.SHA {
		return p, fmt.Errorf("実行binaryが固定物と異なる")
	}
	p.Before[exe] = actual
	var closed struct {
		Trial    int  `json:"試行"`
		Complete bool `json:"試行完了"`
	}
	if err := readJSON(c.PriorClosure.Path, false, &closed); err != nil {
		return p, err
	}
	if closed.Trial != 108 || !closed.Complete {
		return p, fmt.Errorf("旧108が未完了")
	}
	for _, item := range []struct {
		r      FileRef
		target any
	}{{c.SourceManifest, &p.Manifest}, {c.SourceCompletion, &p.Source}, {c.PriorCompletion, &p.Prior}, {c.PriorNativeIndex, &p.PriorIndex}} {
		if err := readJSON(item.r.Path, false, item.target); err != nil {
			return p, err
		}
	}
	p.PriorIndexRoot = filepath.Dir(filepath.Dir(c.PriorNativeIndex.Path))
	if err := validateSources(&p); err != nil {
		return p, err
	}
	return p, nil
}

// stopOwned は認証済み停止の明示型から所有コードを取り出します。
//
// 引数: stop(StopDeclaration)、publisher(bool)は宣言と固定公開器の認証結果です。
// 返り値: map[string]string/errorは包含対象又は型の不整合です。異なる型の混在を拒否します。
func stopOwned(stop StopDeclaration, publisher bool) (map[string]string, error) {
	if !stop.Success {
		return nil, fmt.Errorf("成功停止が必要")
	}
	if publisher {
		if len(stop.Owned) != 0 || !stop.Unchanged || len(stop.Before) == 0 || len(stop.After) == 0 || !reflect.DeepEqual(stop.Before, stop.After) {
			return nil, fmt.Errorf("固定公開器の前後不変/非空同体/停止型が必要")
		}
		return stop.After, nil
	}
	if len(stop.Owned) == 0 || len(stop.Before) != 0 || len(stop.After) != 0 {
		return nil, fmt.Errorf("通常停止の所有集合又は明示型が不正")
	}
	return stop.Owned, nil
}

// verifyCodeScope は自CLIと成功停止の所有コードの固定漏れを拒否します。
//
// 引数: ownRoot(string)、code(map)、stops([]FileRef)は絶対自己位置/指紋/停止。
// 返り値: errorは包含差です。全Go閉包はRootが別に固定します。
func verifyCodeScope(ownRoot string, code map[string]string, stops []FileRef) error {
	for _, name := range []string{"io.go", "metadata.go", "seed.go", "case.go", "main.go", "metadata_test.go", "seed_test.go", "case_test.go", "integration_test.go", "stop_type_test.go", "go.mod", "go.sum"} {
		if len(code[filepath.Join(ownRoot, name)]) != 64 {
			return fmt.Errorf("CLI自己包含不足:%s", name)
		}
	}
	repoRoot := filepath.Dir(filepath.Dir(ownRoot))
	seen := map[string]bool{}
	for _, ref := range stops {
		if seen[ref.Path] {
			return fmt.Errorf("停止参照重複")
		}
		seen[ref.Path] = true
		h, err := fileSHA(ref.Path)
		if err != nil || h != ref.SHA {
			return fmt.Errorf("停止参照の実物SHA差")
		}
		var stop StopDeclaration
		if err := readJSON(ref.Path, false, &stop); err != nil {
			return err
		}
		publisher := ref.SHA == publisherStopSHA && filepath.Clean(ref.Path) == filepath.Join(repoRoot, "work", "三時間軸の公開器", "停止.json")
		owned, err := stopOwned(stop, publisher)
		if err != nil {
			return err
		}
		for name, want := range owned {
			q, err := absolute(repoRoot, name)
			if err != nil || code[q] != want || len(want) != 64 {
				return fmt.Errorf("停止所有包含差:%s", name)
			}
		}
	}
	return nil
}

// validateSources は既使用manifest70と106/108/indexの同じ時系列集合をmetadataだけで結合します。
//
// 引数: p(*Plan)は参照読込済み計画。返り値: errorは部分集合/場順/指紋/経路の不一致です。
func validateSources(p *Plan) error {
	c, s, old, idx := p.Condition, p.Source, p.Prior, p.PriorIndex
	if c.SourceManifest.SHA != "902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8" || c.SourceCorpus.SHA != "ca6206d47d36772fff84d230073bd4346b1e785d5b0bb98c565bafe6c92fb441" || c.SourceCompletion.SHA != "c1370aac63c1905f132237becd5d5bb37c6bd06e20b061800c9d0caa02a1769f" ||
		c.PriorCompletion.SHA != "bf0278e332386701221313de8a215fe04adea7666c22bad54c0055303440aae4" || c.PriorNativeIndex.SHA != "1d2cc8e4256862dd00dfeb720a7c75b62fdde79f3e3ddc19d9b71ba7a9c7f040" ||
		c.PriorClosure.SHA != "d22a5c0a9bdad7b82dfa3afa2d9d100a2ebc834b9e97291099ada1db8093c30b" {
		return fmt.Errorf("既使用106入力又は108Q20固定参照のSHA差")
	}
	if !filepath.IsAbs(p.Manifest.Root) || len(p.Manifest.Sessions) != 70 || s.Version != 1 || s.Trial != 106 || !s.Success || s.Stage != "full70" || s.Sessions != 70 || s.BooksPerScene != 20 || s.Books != 1400 || s.Error != "" || !s.Unchanged || len(s.Before) == 0 || !reflect.DeepEqual(s.Before, s.After) || s.ConditionSHA != reader.Condition106 || len(s.Results) != 70 {
		return fmt.Errorf("106完成70入力metadata差")
	}
	if old.Version != 1 || old.Trial != 108 || !old.Success || old.Stage != "full70" || old.Sessions != 70 || old.BooksPerScene != 12 || old.Books != 840 || !old.Unchanged || len(old.Before) == 0 || !reflect.DeepEqual(old.Before, old.After) || old.ConditionSHA != "0a2a70a4658800060ab4c22a29cdcf21e29a9e2d87f916b0d1c327bb8cf88bd6" || old.Mode != "recorded_public_106" || old.SourceReexecuted || old.ChartsRecomputed || !old.FinancialExecuted || old.Error != "" || len(old.Results) != 70 {
		return fmt.Errorf("108全70保存参照metadata差")
	}
	completionPath, err := absolute(p.PriorIndexRoot, idx.Completion.Path)
	if err != nil || !idx.Success || idx.Trial != 108 || idx.Base != "trialdir" || idx.Sessions != 70 || idx.Books != 840 || len(idx.Native) != 70 || idx.Completion.SHA != c.PriorCompletion.SHA || filepath.Clean(completionPath) != filepath.Clean(c.PriorCompletion.Path) || idx.Condition.SHA != old.ConditionSHA {
		return fmt.Errorf("108正式台帳と完了参照の差")
	}
	seen := map[string]bool{}
	valid := regexp.MustCompile(`^\d{4}-\d{2}-\d{2}_(Day|Night)$`)
	p.PriorNative = nil
	for i, scene := range p.Manifest.Sessions {
		r, o, n := s.Results[i], old.Results[i], idx.Native[i]
		if !valid.MatchString(scene.ID) || seen[scene.ID] || r.Session != scene.ID || o.Session != scene.ID || n.Session != scene.ID || r.Books != 20 || r.W0Books != 4 || o.Books != 12 || o.PriorBooks != 12 || !o.PriorUnchanged || r.Error != "" || o.Error != "" || n.Books != 12 || !n.SameBytes || n.Bytes <= 0 || n.SHA != o.Native.SHA || n.Original.SHA != o.Native.SHA || r.Header.SHA != o.Header.SHA || r.Records.SHA != o.Records.SHA || n.Public.Header.SHA != r.Header.SHA || n.Public.Records.SHA != r.Records.SHA {
			return fmt.Errorf("106/108/indexの場集合/全SHA差:%s", scene.ID)
		}
		for _, ref := range []FileRef{{r.Native.Path, r.Native.SHA}, {r.Header.Path, r.Header.SHA}, {r.Records.Path, r.Records.SHA}, o.Native, o.Header, o.Records} {
			if !filepath.IsAbs(ref.Path) || len(ref.SHA) != 64 {
				return fmt.Errorf("場の絶対path/SHA差")
			}
		}
		original, e := absolute(p.PriorIndexRoot, n.Original.Path)
		if e != nil || filepath.Clean(original) != filepath.Clean(o.Native.Path) {
			return fmt.Errorf("108台帳元参照差")
		}
		for _, pair := range [][2]FileRef{{n.Public.Header, {r.Header.Path, r.Header.SHA}}, {n.Public.Records, {r.Records.Path, r.Records.SHA}}} {
			q, e := absolute(p.PriorIndexRoot, pair[0].Path)
			if e != nil || filepath.Clean(q) != filepath.Clean(pair[1].Path) {
				return fmt.Errorf("公開sidecarの正式台帳結合差")
			}
		}
		native, e := absolute(p.PriorIndexRoot, n.Path)
		if e != nil || !filepath.IsLocal(n.Path) || filepath.Base(native) != scene.ID+".Native.json.gz" {
			return fmt.Errorf("108正式Nativeの位置差")
		}
		csv, ok := scene.Files["NK225_candle_300"]
		expectedCSV := filepath.Join("JP_OSE_Data", "future", "NK225", scene.ID, "candle_5min.csv")
		peer, peerOK := scene.Files["TOPIX_candle_300"]
		if !ok || !filepath.IsLocal(csv.Path) || filepath.Clean(filepath.FromSlash(csv.Path)) != expectedCSV || csv.Size <= 0 || len(csv.SHA) != 64 || scene.Contract == "" || !peerOK || peer.Size <= 0 || len(peer.SHA) != 64 {
			return fmt.Errorf("NK225の固定5分CSV参照が必要")
		}
		p.PriorNative = append(p.PriorNative, FileRef{native, n.SHA})
		seen[scene.ID] = true
	}
	return nil
}

// readerRequest は106の固定3参照だけを停止readerへ渡します。
//
// 引数: p(Plan)、id(string)は固定計画と場。返り値: reader.Requestは絶対参照です。
func readerRequest(p Plan, id string) reader.Request {
	return reader.Request{Manifest: reader.FileRef{Path: p.Condition.SourceManifest.Path, SHA: p.Condition.SourceManifest.SHA}, Corpus: reader.FileRef{Path: p.Condition.SourceCorpus.Path, SHA: p.Condition.SourceCorpus.SHA}, Completion: reader.FileRef{Path: p.Condition.SourceCompletion.Path, SHA: p.Condition.SourceCompletion.SHA}, SceneID: id}
}
