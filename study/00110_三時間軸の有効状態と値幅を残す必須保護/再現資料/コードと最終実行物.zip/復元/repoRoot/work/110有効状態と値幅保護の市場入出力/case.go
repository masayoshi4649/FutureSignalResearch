package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"path/filepath"
	"reflect"

	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
	reader "github.com/masayoshi4649/SessionTradeExecuter/savedpublic107"
	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	core "github.com/masayoshi4649/SessionTradeExecuter/threeguardruntime110"
)

// rawObject は保存会計の未知fieldを保ちつつ、nullや配列を拒否します。
//
// 引数: raw(json.RawMessage)は保存値。返り値: boolは正常なJSON objectだけ真です。
func rawObject(raw json.RawMessage) bool {
	value := bytes.TrimSpace(raw)
	return len(value) > 1 && value[0] == '{' && json.Valid(value)
}

type SceneResult struct {
	Session             string            `json:"session"`
	Native              FileRef           `json:"native"`
	Header              FileRef           `json:"sidecar_header"`
	Records             FileRef           `json:"sidecar_records"`
	CSV                 frame.FileRef     `json:"csv"`
	Books               int               `json:"books"`
	ShadowBooks         int               `json:"shadow_books"`
	Comparisons         int               `json:"baseline_comparisons"`
	BaselineAll         bool              `json:"baseline_all"`
	PriorBooks          int               `json:"prior_reference_books"`
	PriorNative         FileRef           `json:"prior_native"`
	PriorUnchanged      bool              `json:"prior_reference_unchanged"`
	SeedExpected        frame.SeedInfo    `json:"expected_end_seed"`
	SeedActual          frame.SeedInfo    `json:"actual_end_seed"`
	SeedEqual           bool              `json:"end_seed_equal"`
	Before              map[string]string `json:"before"`
	After               map[string]string `json:"after"`
	Unchanged           bool              `json:"unchanged"`
	FinancialDispatches int               `json:"financial_dispatches"`
	FinancialExecuted   bool              `json:"financial_executed"`
	Error               string            `json:"error,omitempty"`
}
type Provenance struct {
	SourceScope              string `json:"source_scope"`
	ClockModel               string `json:"clock_model"`
	CMPRecomputed            bool   `json:"cmp_recomputed"`
	ChartsRecomputed         bool   `json:"charts_recomputed"`
	RawRead                  bool   `json:"raw_market_read"`
	SourceReexecuted         bool   `json:"source_reexecuted"`
	BankRecomputed           bool   `json:"bank_recomputed"`
	EntryCandleRecomputed    bool   `json:"entry_candle_recomputed"`
	FinancialExecuted        bool   `json:"financial_executed"`
	SourceFeaturesRecomputed bool   `json:"source_features_recomputed"`
	NewSeriesBankFormed      bool   `json:"new_series_bank_formed"`
	ProtectionVFormed        bool   `json:"protection_v5_formed"`
	CSVCopied                bool   `json:"csv_copied"`
	CSVRegenerated           bool   `json:"csv_regenerated"`
	RawCopied                bool   `json:"raw_copied"`
}
type NativeOutput struct {
	core.Result
	ConditionSHA string             `json:"condition_sha256"`
	Input        reader.Proof       `json:"input_proof"`
	Replay       reader.ReplayProof `json:"replay_proof"`
	CSV          frame.FileRef      `json:"csv_input"`
	SeedExpected frame.SeedInfo     `json:"expected_end_seed"`
	SeedEqual    bool               `json:"end_seed_equal"`
	Provenance   Provenance         `json:"provenance"`
}
type SavedConfig struct {
	Candidate string  `json:"candidate"`
	Timing    string  `json:"entry_timing"`
	Policy    string  `json:"protection_policy"`
	Slip      float64 `json:"slip_pts"`
	Delay     int     `json:"delay_seconds"`
	Quiet     int     `json:"quiet_seconds"`
}

// loadControl は正式旧108の12Bookと全auditを未知field込みRawMessageで保持します。
//
// 引数: ref(FileRef)は成功完了と正式台帳に結合した参照。返り値: core.Control/errorは保存全値又は不正です。
func loadControl(ref FileRef) (core.Control, error) {
	before := map[string]string{}
	p, err := checkRef(ref, ".", before)
	if err != nil {
		return core.Control{}, err
	}
	var old struct {
		Trial    int                        `json:"trial"`
		Complete bool                       `json:"complete"`
		Session  json.RawMessage            `json:"session"`
		Contract string                     `json:"contract"`
		TapeSHA  string                     `json:"tape_canonical_sha256"`
		Configs  []SavedConfig              `json:"configs"`
		Books    map[string]json.RawMessage `json:"books"`
		Width    map[string]json.RawMessage `json:"width_audits"`
		Clock    map[string]json.RawMessage `json:"clock_audits"`
		Early    map[string]json.RawMessage `json:"early_audits"`
	}
	if err = readJSON(p, true, &old); err != nil {
		return core.Control{}, err
	}
	if old.Trial != 108 || !old.Complete || len(old.Books) != 12 || len(old.Width) != 12 || len(old.Clock) != 12 || len(old.Early) != 4 || len(old.Configs) != 12 {
		return core.Control{}, fmt.Errorf("旧108Nativeの完了/全12設定/audit差")
	}
	c := core.Control{Kind: "provided_old108_q20", HistoryClass: "old_saved_70", ReferencePath: p, ReferenceSHA: ref.SHA, Contract: old.Contract, TapeSHA: old.TapeSHA, QuietSeconds: 1200,
		Books: map[string]json.RawMessage{}, WidthAudits: map[string]json.RawMessage{}, ClockAudits: map[string]json.RawMessage{}, EarlyAudits: map[string]json.RawMessage{}}
	if err = json.Unmarshal(old.Session, &c.Session); err != nil {
		return c, err
	}
	want := map[string]SavedConfig{}
	for _, name := range []string{"Q0", "Q1", "QE"} {
		for _, slip := range []float64{0, 5} {
			for _, delay := range []int{0, 1} {
				policy := "W0"
				if name == "Q1" {
					policy = "W1"
				}
				if name == "QE" {
					policy = "E1"
				}
				k := fmt.Sprintf("%s_C%.0f_D%d", name, slip, delay)
				want[k] = SavedConfig{name, "B5QD", policy, slip, delay, 1200}
			}
		}
	}
	seen := map[string]bool{}
	for _, cfg := range old.Configs {
		key := fmt.Sprintf("%s_C%.0f_D%d", cfg.Candidate, cfg.Slip, cfg.Delay)
		expected, exists := want[key]
		if !exists || seen[key] || !reflect.DeepEqual(cfg, expected) {
			return c, fmt.Errorf("旧108Config差:%s", key)
		}
		seen[key] = true
		if !rawObject(old.Books[key]) || !rawObject(old.Width[key]) || !rawObject(old.Clock[key]) {
			return c, fmt.Errorf("旧108の保存Book/幅/時計不足:%s", key)
		}
		c.Books[key], c.WidthAudits[key], c.ClockAudits[key] = old.Books[key], old.Width[key], old.Clock[key]
		if cfg.Policy == "E1" {
			if !rawObject(old.Early[key]) {
				return c, fmt.Errorf("旧108早期監査不足")
			}
			c.EarlyAudits[key] = old.Early[key]
		}
	}
	if len(seen) != 12 {
		return c, fmt.Errorf("旧108全12の集合差")
	}
	_, err = recheck(before)
	return c, err
}

// validateResult はrecorded70のMain36/Shadow0/四比較と新監査の完結を限定します。
//
// 引数: r(core.Result)は実配送の完了値。返り値: errorは旧参照・会計・再実行範囲の不成立です。
func validateResult(r core.Result) error {
	if !r.Complete || len(r.Books) != 36 || len(r.WidthAudits) != 12 || len(r.ClockAudits) != 36 || len(r.CompositeAudits) != 36 || len(r.EntryAudits) != 36 || len(r.ShadowBooks)+len(r.ShadowWidthAudits)+len(r.ShadowClockAudits) != 0 ||
		r.PriorReference.Kind != "provided_old108_q20" || r.PriorReference.QuietSeconds != 1200 || r.PriorReference.Books != 12 || r.PriorReference.WidthAudits != 12 || r.PriorReference.ClockAudits != 12 || r.PriorReference.EarlyAudits != 4 ||
		r.Baseline.Comparisons != 4 || !r.Baseline.All || !r.TapeUnchanged || r.SourceReexecuted || r.ChartRecomputed || r.BankRecomputed || !r.CMPRecomputed || !r.EntryCandleRecomputed || r.PublicationAudit.ClockModel != ClockModel || !r.PublicationAudit.PolicyEOFRedacted || !r.PublicationAudit.LastSnapshot.Sealed || r.PublicationAudit.LastSnapshot.ReplayObservedAt != r.PublicationAudit.Session.EOF {
		return fmt.Errorf("Main36/Shadow0/旧108参照/四対照/新公表監査の完了差")
	}
	return nil
}

// runScene は事前生成した固定種を使い、一場だけ独立にRecord schedulerで配送します。
//
// 引数: p(Plan)、id/out(string)、preparation(ScenePreparation)は固定・場・新規先・前史。
// 返り値: SceneResultは36会計のNative証拠又は失敗です。最新探索や未使用場分岐はありません。
func runScene(p Plan, id, out string, preparation ScenePreparation) (result SceneResult) {
	result.Session, result.CSV, result.Header, result.SeedExpected = id, preparation.CSV, preparation.Header, preparation.Expected
	result.Before = map[string]string{}
	loaded, err := reader.LoadTape(readerRequest(p, id))
	if err != nil {
		result.Error = err.Error()
		return
	}
	proof := loaded.Proof()
	if err = mergeFingerprint(result.Before, proof.InputSHA); err != nil {
		result.Error = err.Error()
		return
	}
	if _, err = checkRef(FileRef{preparation.CSV.Path, preparation.CSV.SHA256}, p.Base, result.Before); err != nil {
		result.Error = err.Error()
		return
	}
	priorRef := FileRef{}
	for i, s := range p.Manifest.Sessions {
		if s.ID == id {
			priorRef = p.PriorNative[i]
			break
		}
	}
	result.PriorNative = priorRef
	if _, err = checkRef(priorRef, p.Base, result.Before); err != nil {
		result.Error = err.Error()
		return
	}
	control, err := loadControl(priorRef)
	if err != nil {
		result.Error = err.Error()
		return
	}
	input, header := loaded.Tape(), loaded.Header()
	if core.SourceSession(input.Session, header.Scene.Contract, header.Ending.Legacy.ObservedClock) != preparation.Publication.Session {
		result.Error = "事前Headerの場時計とSourceTapeのSession差"
		return
	}
	childrenBefore, err := valueSHA(preparation.Publication.Children)
	if err != nil || childrenBefore != preparation.ChildrenSHA {
		result.Error = "事前子足の指紋差"
		return
	}
	runtime, err := core.NewCore(input, header.Scene.Contract, p.Condition.Scope, control, preparation.Publication)
	if err != nil {
		result.Error = err.Error()
		return
	}
	h, replay, err := reader.ReplayRecords(loaded, func(record stream.Record) error {
		if record.Kind == "quote" || record.Kind == "grid" || record.Kind == "force" {
			result.FinancialDispatches++
			result.FinancialExecuted = true
		}
		return runtime.Feed(record)
	})
	if err != nil {
		result.Error = err.Error()
		return
	}
	r, err := runtime.Finish(h)
	if err != nil {
		result.Error = err.Error()
		return
	}
	if err = validateResult(r); err != nil {
		result.Error = err.Error()
		return
	}
	next, err := runtime.NextSeed()
	if err != nil {
		result.Error = err.Error()
		return
	}
	if err = verifyEndSeed(preparation, r, next); err != nil {
		result.Error = err.Error()
		return
	}
	childrenAfter, e := valueSHA(preparation.Publication.Children)
	if e != nil || childrenAfter != childrenBefore || !replay.Unchanged {
		result.Error = "子足/SourceRecordの前後指紋差"
		return
	}
	if err = mergeFingerprint(result.Before, replay.Before); err != nil {
		result.Error = err.Error()
		return
	}
	result.After, err = recheck(result.Before)
	if err != nil {
		result.Error = err.Error()
		return
	}
	result.Unchanged = reflect.DeepEqual(result.Before, result.After)
	if !result.Unchanged {
		result.Error = "Scene入力前後不変でない"
		return
	}
	value := NativeOutput{Result: r, ConditionSHA: p.ConditionSHA, Input: proof, Replay: replay, CSV: preparation.CSV, SeedExpected: preparation.Expected, SeedEqual: true,
		Provenance: Provenance{SourceScope: p.Condition.Mode, ClockModel: ClockModel, CMPRecomputed: true, EntryCandleRecomputed: true, FinancialExecuted: true, NewSeriesBankFormed: true, ProtectionVFormed: true}}
	result.Native, err = writeJSON(filepath.Join(out, id+".Native.json.gz"), value, true)
	if err != nil {
		result.Error = err.Error()
		return
	}
	for _, s := range p.Source.Results {
		if s.Session == id {
			result.Records = FileRef{s.Records.Path, s.Records.SHA}
			break
		}
	}
	result.Books, result.PriorBooks, result.Comparisons, result.BaselineAll, result.SeedActual, result.SeedEqual = 36, 12, 4, true, next.Info(), true
	result.PriorUnchanged = result.After[priorRef.Path] == priorRef.SHA
	return
}
