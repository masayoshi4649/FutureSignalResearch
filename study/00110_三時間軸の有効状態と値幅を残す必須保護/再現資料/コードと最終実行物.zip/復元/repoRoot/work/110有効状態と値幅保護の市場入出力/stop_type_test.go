package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
)

// TestStopTypes は公開器の非空前後同体と通常停止の所有集合を明示的に区別します。
//
// 引数: t(*testing.T)は純metadataの人工検査です。
// 返り値: ありません。失敗/空/不一致/混在/別型偽装を拒否します。
func TestStopTypes(t *testing.T) {
	h := strings.Repeat("a", 64)
	publisher := StopDeclaration{Success: true, Before: map[string]string{"人工.go": h}, After: map[string]string{"人工.go": h}, Unchanged: true}
	ordinary := StopDeclaration{Success: true, Owned: map[string]string{"人工.go": h}}
	for _, c := range []struct {
		value StopDeclaration
		pub   bool
		want  map[string]string
	}{{publisher, true, publisher.After}, {ordinary, false, ordinary.Owned}} {
		got, err := stopOwned(c.value, c.pub)
		if err != nil || !reflect.DeepEqual(got, c.want) {
			t.Fatalf("明示した正常停止型を拒否:%v", err)
		}
	}
	for _, name := range []string{"公開器失敗", "不変偽", "前空", "後空", "前後差", "公開器に所有型を混在", "公開器型を別停止で偽装", "通常失敗", "通常所有空", "通常へ前後型を混在"} {
		t.Run(name, func(t *testing.T) {
			raw, _ := json.Marshal(publisher)
			var value StopDeclaration
			_ = json.Unmarshal(raw, &value)
			pub := true
			switch name {
			case "公開器失敗":
				value.Success = false
			case "不変偽":
				value.Unchanged = false
			case "前空":
				value.Before = map[string]string{}
			case "後空":
				value.After = map[string]string{}
			case "前後差":
				value.After["人工.go"] = strings.Repeat("b", 64)
			case "公開器に所有型を混在":
				value.Owned = map[string]string{"人工.go": h}
			case "公開器型を別停止で偽装":
				pub = false
			case "通常失敗":
				value, pub = ordinary, false
				value.Success = false
			case "通常所有空":
				value, pub = StopDeclaration{Success: true}, false
			case "通常へ前後型を混在":
				value.Owned, pub = map[string]string{"人工.go": h}, false
			}
			if _, err := stopOwned(value, pub); err == nil {
				t.Fatal("不正又は偽装停止型を受理")
			}
		})
	}
}

// scopeCodeFixture は検査対象CLIの実ソース指紋を用意します。
//
// 引数: t(*testing.T)はmetadata検査です。
// 返り値: string/map[string]stringは自己絶対位置と固定コード集合。市場ファイルを含みません。
func scopeCodeFixture(t *testing.T) (string, map[string]string) {
	t.Helper()
	own, err := filepath.Abs(".")
	if err != nil {
		t.Fatal(err)
	}
	code := map[string]string{}
	for _, name := range []string{"io.go", "metadata.go", "seed.go", "case.go", "main.go", "metadata_test.go", "seed_test.go", "case_test.go", "integration_test.go", "stop_type_test.go", "go.mod", "go.sum"} {
		path := filepath.Join(own, name)
		h, err := fileSHA(path)
		if err != nil {
			t.Fatal(err)
		}
		code[path] = h
	}
	return own, code
}

// TestFixedPublisherStop は実際の停止b6b1だけを明示受理し、改名copyやSHA偽装を拒否します。
//
// 引数: t(*testing.T)は停止metadataとコードだけの検査です。
// 返り値: ありません。固定公開器/元9a753のファイルへ書き込みません。
func TestFixedPublisherStop(t *testing.T) {
	own, code := scopeCodeFixture(t)
	root := filepath.Dir(filepath.Dir(own))
	path := filepath.Join(root, "work", "三時間軸の公開器", "停止.json")
	var stopped StopDeclaration
	if err := readJSON(path, false, &stopped); err != nil {
		t.Fatal(err)
	}
	for name, want := range stopped.After {
		q, err := absolute(root, name)
		if err != nil {
			t.Fatal(err)
		}
		h, err := fileSHA(q)
		if err != nil || h != want {
			t.Fatal("固定公開器コードの実物SHA差")
		}
		code[q] = want
	}
	ref := FileRef{path, publisherStopSHA}
	if err := verifyCodeScope(own, code, []FileRef{ref}); err != nil {
		t.Fatal(err)
	}
	for _, name := range []string{"停止SHA差", "型copyで別path", "所有包含漏れ", "停止重複"} {
		t.Run(name, func(t *testing.T) {
			copyCode := map[string]string{}
			for k, v := range code {
				copyCode[k] = v
			}
			refs := []FileRef{ref}
			switch name {
			case "停止SHA差":
				refs[0].SHA = strings.Repeat("f", 64)
			case "型copyで別path":
				body, err := os.ReadFile(path)
				if err != nil {
					t.Fatal(err)
				}
				q := filepath.Join(t.TempDir(), "別停止.json")
				if err = os.WriteFile(q, body, 0644); err != nil {
					t.Fatal(err)
				}
				refs[0].Path = q
			case "所有包含漏れ":
				for k := range stopped.After {
					q, _ := absolute(root, k)
					delete(copyCode, q)
					break
				}
			case "停止重複":
				refs = append(refs, ref)
			}
			if err := verifyCodeScope(own, copyCode, refs); err == nil {
				t.Fatal("固定公開器の不正認証を受理")
			}
		})
	}
}

// TestDeclaredStopSet は技法固定に使う既停止8部品と派生元CLIをまとめて認証します。
//
// 引数: t(*testing.T)は明示停止とコードだけの検査です。
// 返り値: ありません。新CLI自身の停止は生成前のため派生元9a753で通常型を確認します。
func TestDeclaredStopSet(t *testing.T) {
	own, code := scopeCodeFixture(t)
	root := filepath.Dir(filepath.Dir(own))
	refs := []FileRef{}
	for dir, expected := range map[string]string{
		"三時間軸の公開器":         publisherStopSHA,
		"三時間軸の入口判定":        "834aedc70a31d5f0d7e2bee9ae6fc9d22d7b3ea726924fed791b2dfec7b283f9",
		"三時間軸の市場入力口":       "820a819d284a58c5057150bb415ac3fd57c34473abda4b18467c42dba9e95782",
		"一定利益と費用床の純状態案":    "1d58cebc88a08011632a4ac1c036dcc71ae8d1bf8dc85938b3f2b344ad85a24c",
		"一定利益と三時間軸の保護会計":   "567b0bc6354b5d3d47d57f1cc3f91335a661d359ea4c81ae02f83653f3970687",
		"三時間軸の市場接続準備":      "62934599463b34def929302c810bd7da2f8abeccdbfa28dce0ade82518633d73",
		"107保存公表の再読口_埋込対応": "d47881a6381e88e0ef2121830c5015e9bbfaa580ed7aa865bd2c12aca767e892",
		"109入口の頻度前検査":      "5939b05e58cd4925f96b86db07b3ead1549fd131f5c2718b8212462062f27b0f",
		"三時間軸の市場入出力準備":     "9a753b92be452e1ced42614b1e7534fbd3be23483498caf5528677b81a26fffd",
	} {
		path := filepath.Join(root, "work", dir, "停止.json")
		var stopped StopDeclaration
		if err := readJSON(path, false, &stopped); err != nil {
			t.Fatal(err)
		}
		owned, err := stopOwned(stopped, dir == "三時間軸の公開器")
		if err != nil {
			t.Fatal(err)
		}
		for name, want := range owned {
			q, err := absolute(root, name)
			if err != nil {
				t.Fatal(err)
			}
			h, err := fileSHA(q)
			if err != nil || h != want {
				t.Fatalf("停止部品の実コードSHA差:%s", q)
			}
			code[q] = want
		}
		refs = append(refs, FileRef{path, expected})
	}
	if err := verifyCodeScope(own, code, refs); err != nil {
		t.Fatal(err)
	}
}
