package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"path/filepath"
	"reflect"
	"strings"

	reader "github.com/masayoshi4649/SessionTradeExecuter/savedpublic107"
	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	csvinput "github.com/masayoshi4649/SessionTradeExecuter/threeframeinput"
	core "github.com/masayoshi4649/SessionTradeExecuter/threeguardruntime110"
)

type SeedNode struct {
	Ordinal     int             `json:"ordinal"`
	Session     frame.Session   `json:"session"`
	CSV         frame.FileRef   `json:"csv"`
	Header      FileRef         `json:"header"`
	Input       *frame.SeedInfo `json:"input_seed"`
	Output      frame.SeedInfo  `json:"output_seed"`
	ChildrenSHA string          `json:"children_sha256"`
}
type ScenePreparation struct {
	Publication core.PublicationInput
	Expected    frame.SeedInfo
	CSV         frame.FileRef
	Header      FileRef
	ChildrenSHA string
}
type SeedPlan struct {
	Scenes map[string]ScenePreparation
	Nodes  []SeedNode
	SHA    string
}

// valueSHA は固定値の全JSONを除外なしで指紋化します。
//
// 引数: value(any)は有限JSON値。返り値: string/errorはSHA256又は符号化拒否です。
func valueSHA(value any) (string, error) {
	data, err := json.Marshal(value)
	if err != nil {
		return "", err
	}
	sum := sha256.Sum256(data)
	return hex.EncodeToString(sum[:]), nil
}

// advanceEOF は数値種の事前生成専用に真EOFまで一回だけ進めてSealします。
//
// 引数: scene(frame.Session)、children([]frame.ChildBar)、previous(*frame.Seed)は固定CSV値と直前のsealed種。
// 返り値: frame.Seed/errorは末尾数値種です。金融やRecord配送は行いません。
func advanceEOF(scene frame.Session, children []frame.ChildBar, previous *frame.Seed) (frame.Seed, error) {
	bank, err := frame.BeginSession(scene, children, previous)
	if err != nil {
		return frame.Seed{}, err
	}
	if _, err = bank.AdvanceObserved(scene.EOF, 1); err != nil {
		return frame.Seed{}, err
	}
	seed, snapshot, err := bank.Seal()
	if err != nil {
		return frame.Seed{}, err
	}
	if !snapshot.Sealed || snapshot.ReplayObservedAt != scene.EOF || !seed.Info().Sealed || seed.Info().ObservedAt != scene.EOF {
		return frame.Seed{}, fmt.Errorf("真EOF一回とSealの時計差")
	}
	return seed, nil
}

// prepareSeeds はmanifest70順で固定Header/CSVだけから先行数値種を作り、並列金融へ不変値を渡します。
//
// 引数: p(*Plan)はRoot固定済み計画。返り値: SeedPlan/errorは全70の前後Infoと私有種又は破損です。
func prepareSeeds(p *Plan) (SeedPlan, error) {
	out := SeedPlan{Scenes: map[string]ScenePreparation{}, Nodes: []SeedNode{}}
	var previous *frame.Seed
	for i, scene := range p.Manifest.Sessions {
		source := p.Source.Results[i]
		headerRef := FileRef{source.Header.Path, source.Header.SHA}
		if _, err := checkRef(headerRef, p.Base, p.Before); err != nil {
			return out, err
		}
		var header reader.PublicHeader
		if err := readJSON(headerRef.Path, false, &header); err != nil {
			return out, err
		}
		if header.Version != 1 || header.Header.Version != 1 || !header.Header.Success || header.Trial != 106 || header.ConditionSHA != reader.Condition106 || header.RecordsSHA != source.Records.SHA || header.Header.Scene.ID != scene.ID || header.Header.Scene.Contract != scene.Contract {
			return out, fmt.Errorf("Seed用Headerの場/限月/出典差")
		}
		clock := header.Header.Scene
		if header.Header.Ending.Legacy.Scene != header.Header.Scene || !header.Header.Ending.Legacy.Sealed || !header.Header.Ending.Legacy.HasObservedClock {
			return out, fmt.Errorf("Seed用Headerは真のsealed EOFが必要")
		}
		length := 25200.0
		if strings.HasSuffix(scene.ID, "_Night") {
			length = 46800
		}
		pubScene := frame.Session{ID: scene.ID, Contract: scene.Contract, Start: clock.Start, End: clock.Start + length, EOF: header.Header.Ending.Legacy.ObservedClock}
		csv := scene.Files["NK225_candle_300"]
		path, err := absolute(p.Manifest.Root, csv.Path)
		if err != nil {
			return out, err
		}
		if _, err = checkRef(FileRef{path, csv.SHA}, p.Base, p.Before); err != nil {
			return out, err
		}
		loaded, err := csvinput.LoadChildren(pubScene, frame.FileRef{Path: path, SHA256: csv.SHA, Bytes: csv.Size})
		if err != nil {
			return out, err
		}
		childrenSHA, err := valueSHA(loaded.Bars)
		if err != nil {
			return out, err
		}
		var before *frame.SeedInfo
		if previous != nil {
			x := previous.Info()
			before = &x
		}
		next, err := advanceEOF(pubScene, loaded.Bars, previous)
		if err != nil {
			return out, fmt.Errorf("%sの因果Seed:%w", scene.ID, err)
		}
		info := next.Info()
		out.Scenes[scene.ID] = ScenePreparation{Publication: core.PublicationInput{Session: pubScene, Children: loaded.Bars, Seed: previous}, Expected: info, CSV: loaded.Input, Header: headerRef, ChildrenSHA: childrenSHA}
		out.Nodes = append(out.Nodes, SeedNode{Ordinal: i + 1, Session: pubScene, CSV: loaded.Input, Header: headerRef, Input: before, Output: info, ChildrenSHA: childrenSHA})
		copy := next
		previous = &copy
	}
	var err error
	out.SHA, err = valueSHA(out.Nodes)
	if err != nil {
		return out, err
	}
	return out, nil
}

// verifyEndSeed は金融CoreのRecord逐次末尾とEOF一括数値種が全値同体か照合します。
//
// 引数: preparation(ScenePreparation)、result(core.Result)、next(frame.Seed)は事前種と実末尾。
// 返り値: errorは入力/EOF/数値SHAの差です。
func verifyEndSeed(preparation ScenePreparation, result core.Result, next frame.Seed) error {
	var input *frame.SeedInfo
	if preparation.Publication.Seed != nil {
		x := preparation.Publication.Seed.Info()
		input = &x
	}
	if !reflect.DeepEqual(input, result.PublicationAudit.InputSeed) || !reflect.DeepEqual(preparation.Expected, result.PublicationAudit.EndSeed) || !reflect.DeepEqual(preparation.Expected, next.Info()) || !result.PublicationAudit.InputsUnchanged || result.PublicationAudit.Session != preparation.Publication.Session {
		return fmt.Errorf("事前EOF種とCore Record末尾種の全Info/SHA差")
	}
	return nil
}

// mergeFingerprint は同じ参照への二指紋を拒否して入力前後証拠を統合します。
//
// 引数: target/source(map[string]string)は絶対参照とSHA。返り値: errorは衝突又は相対pathです。
func mergeFingerprint(target, source map[string]string) error {
	for path, h := range source {
		if !filepath.IsAbs(path) || len(h) != 64 {
			return fmt.Errorf("指紋集合の絶対path/SHAが不正")
		}
		if old, ok := target[path]; ok && old != h {
			return fmt.Errorf("入力指紋集合が衝突:%s", path)
		}
		target[path] = h
	}
	return nil
}
