package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
)

// TestDeclaredConfigurations110 は実CLIが使う36宣言を検査し、停止時だけ新規保存します。
//
// 引数: t(*testing.T)は人工検査器です。環境変数DECLARED110_EXPORTは任意の絶対出力先です。
// 返り値: ありません。金融・共有入力を実行せず、既存先を上書きしません。
func TestDeclaredConfigurations110(t *testing.T) {
	configs := declaredConfigurations()
	if len(configs) != 36 {
		t.Fatal("実CLIの宣言が36件でない")
	}
	path := os.Getenv("DECLARED110_EXPORT")
	if path == "" {
		return
	}
	if !filepath.IsAbs(path) {
		t.Fatal("宣言保存先は絶対pathが必要")
	}
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		t.Fatal(err)
	}
	raw, err := json.Marshal(struct {
		Trial   int              `json:"trial"`
		Configs []DeclaredConfig `json:"configs"`
	}{110, configs})
	if err != nil {
		t.Fatal(err)
	}
	file, err := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = file.Write(raw); err != nil {
		_ = file.Close()
		t.Fatal(err)
	}
	if err = file.Close(); err != nil {
		t.Fatal(err)
	}
}
