"""107の全1680一覧と先頭Day固定24資源のGETだけを確認する準備。"""
import argparse
from concurrent.futures import ThreadPoolExecutor
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path
from urllib.parse import urlencode

ROOT = Path(__file__).resolve().parents[2]
OLD_PATH = ROOT / "work/106進行/Viewerの20資源を確認する.py"
OLD_SHA = "b068ddffee9884109a1d5a18306700735327c2dd7e85fd3c4fe237107051f315"
if hashlib.sha256(OLD_PATH.read_bytes()).hexdigest() != OLD_SHA:
    raise ValueError("固定106のViewer確認方法SHA差")
SPEC = importlib.util.spec_from_file_location("107が再用する106ViewerAPI", OLD_PATH)
OLD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(OLD)
KEYS = tuple(f"{p}_C{c}_D{d}" for p in ("B0", "B1", "BE", "Q0", "Q1", "QE") for c in (0, 5) for d in (0, 1))
SESSION = "2026-09-21_Day"
SCOPE = "全1680一覧の整合と事前固定2026-09-21_Dayの24設定GET。全1680表示・24描画・ブラウザ視認ではない"


def sha(path):
    """
    機能: 小型固定入力又は選択24の実tradesの指紋を取得する。
    引数: path(Path)はRoot許可後の保存物又はコード。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    """
    機能: 半円をDecimalで保ち、小型のmetadata又は保存集計を読む。
    引数: path(Path)はRoot固定済み参照。
    返り値: dictは元JSON。Raw/Tape/Nativeを読まない。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"), parse_float=Decimal)


def ref(ref_value, base, before, parse=True):
    """
    機能: 明示基準FileRefを実SHAへ結合する。
    引数: ref_value(dict)、base(Path)、before(dict)、parse(bool)は固定値とJSON読取指定。
    返り値: tupleは絶対Pathと値。code参照は復号しない。
    """
    assert set(ref_value) == {"path", "sha256"}
    path = (base / ref_value["path"]).resolve()
    assert sha(path) == ref_value["sha256"]
    before[str(path)] = ref_value["sha256"]
    return path, load(path) if parse else None


def validate_values(complete, summary, check, catalog, condition_sha, complete_sha, summary_sha, catalog_sha):
    """
    機能: 107全70金融と保存成功、全24×70一覧をAPIより前に検査する。
    引数: complete/summary/check/catalog(dict)と各固定SHA(str)はRoot成功後保存物。
    返り値: tupleは全一覧と固定24選択。手製metadata試験以外はRoot固定からだけ呼ぶ。
    """
    assert complete["version"] == 1 and complete["trial"] == 107 and complete["stage"] == "full70" and complete["success"]
    assert complete["sessions"] == 70 and complete["books"] == 1680 and complete["books_per_scene"] == 24
    assert complete["unchanged"] and complete["before"] == complete["after"] and complete["condition_sha256"] == condition_sha
    assert summary["試行"] == 107 and summary["成功"] and summary["stage"] == "full70"
    assert summary["場数"] == 70 and summary["会計数"] == 1680
    assert check["成功"] and check["会計"] == check["資源"] == 1680 and check["不一致数"] == 0
    for value in (summary, check):
        assert value["前後不変"] and value["入力codeSHA256前"] == value["入力codeSHA256後"]
        assert value["completionSHA256"] == complete_sha and value["conditionSHA256"] == condition_sha
    assert check["出力SHA256"]["結果.json"] == summary_sha and check["出力SHA256"]["一覧.resources.json"] == catalog_sha
    assert catalog["schema_version"] == 1 and catalog["path_base"] == "catalog"
    rows = summary["場別"]
    expected = {(r["session"], r["key"]): r["net_yen"] for r in rows}
    assert len(expected) == len(rows) == 1680
    sessions = sorted({s for s, _ in expected})
    assert len(sessions) == 70 and sessions[0] == SESSION
    assert set(expected) == {(s, k) for s in sessions for k in KEYS}
    resources = catalog["resources"]
    assert len(resources) == len({r["id"] for r in resources}) == 1680
    indexed = {}
    for resource in resources:
        sid, key = resource["session"], resource["method_id"]
        assert (sid, key) in expected and (sid, key) not in indexed
        identity = f"107_{key}_{sid}"
        assert resource["id"] == identity and resource["title"] == f"見送り繰越と利益保護 {key} {sid}"
        assert resource["symbol"] == "NK225" and resource["product"] == "NK225mini" and resource["point_value"] == 100
        assert resource["pnl_format"] == "trades" and resource["pnl_basis"] == "net" and resource["pnl_path"] == identity + ".trades.jsonl"
        indexed[sid, key] = resource
    return resources, [(indexed[SESSION, key], expected[SESSION, key]) for key in KEYS]


def prepare(fixed_path, fixed_sha, destination):
    """
    機能: Root実成功後の固定参照だけをHTTP実行口へ渡す。
    引数: fixed_path/destination(Path)、fixed_sha(str)はRoot固定と新規証拠先。
    返り値: dictは認証済み全一覧・選択24と前指紋。APIはまだ呼ばない。
    """
    assert not destination.exists() and sha(fixed_path) == fixed_sha
    f = load(fixed_path)
    assert f["version"] == 1 and f["trial"] == 107 and f["fixed"] is True and f["stage"] == "full70" and f["saved_ready"] is True
    assert f["selected_session"] == SESSION
    before = {str(fixed_path): fixed_sha, str(OLD_PATH): OLD_SHA}
    parsed = {k: ref(f[k], fixed_path.parent, before, k != "code") for k in ("condition", "completion", "summary", "saved_check", "catalog", "code")}
    assert parsed["code"][0] == Path(__file__).resolve()
    condition = parsed["condition"][1]
    assert condition["version"] == 1 and condition["trial"] == 107 and condition["fixed"] is True
    resources, selected = validate_values(parsed["completion"][1], parsed["summary"][1], parsed["saved_check"][1], parsed["catalog"][1],
                                         f["condition"]["sha256"], f["completion"]["sha256"], f["summary"]["sha256"], f["catalog"]["sha256"])
    catalog = parsed["catalog"][0]
    catalog.relative_to(ROOT)
    for resource, _ in selected:
        path = (catalog.parent / resource["pnl_path"]).resolve()
        expected = parsed["saved_check"][1]["出力SHA256"][resource["pnl_path"]]
        assert sha(path) == expected
        before[str(path)] = expected
    return {"catalog": catalog, "resources": resources, "selected": selected, "before": before, "fixed_sha": fixed_sha}


def verify_response(value, identity, expected_net, fill_rows):
    """
    機能: 旧106と同じAPI純額・実約定行・最終残0の検算を行う。
    引数: value(dict)、identity(str)、expected_net(Decimal)、fill_rows(int)は応答と保存値。
    返り値: None。描画・価格ピーク・新金融再生へ読み替えない。
    """
    summary = value["summary"]
    assert value["resource"]["id"] == identity and summary["realized_pnl_yen"] == expected_net
    assert summary["long_qty"] == summary["short_qty"] == summary["unrealized_pnl_yen"] == 0
    assert len(value["events"]) == fill_rows


def run(fixed_path, fixed_sha, destination):
    """
    機能: Root実行指示後だけ一覧loadと固定24GETを既存8092へ送る。
    引数: fixed_path/destination(Path)、fixed_sha(str)は成功後固定と新規証拠先。
    返り値: dictはAPI限定証拠。PID19844の操作・設定・再起動は行わない。
    """
    plan = prepare(fixed_path, fixed_sha, destination)
    info, _ = OLD.request("/api/info")
    assert Path(info["resource_root"]).resolve() == ROOT
    loaded, _ = OLD.request("/api/catalogs/load", {"path": plan["catalog"].relative_to(ROOT).as_posix()})
    assert len(loaded["resources"]) == 1680
    assert {r["id"] for r in loaded["resources"]} == {r["id"] for r in plan["resources"]}

    def check(item):
        """
        機能: 事前固定した一資源だけのGETと実trades不変を確認する。
        引数: item(tuple)はResourceと保存純額。
        返り値: dictはAPIの限定照合結果。
        """
        resource, net = item
        identity = resource["id"]
        trades = plan["catalog"].parent / resource["pnl_path"]
        original = trades.read_bytes()
        query = urlencode({"catalog": loaded["catalog_id"], "resource": identity, "width": 1, "interval": "raw", "price": "last"})
        value, body_sha = OLD.request("/api/data?" + query)
        verify_response(value, identity, net, len(original.splitlines()))
        assert trades.read_bytes() == original
        return {"id": identity, "実約定行": len(value["events"]), "純額": net, "本文SHA256": body_sha}

    with ThreadPoolExecutor(max_workers=4) as pool:
        details = list(pool.map(check, plan["selected"]))
    after = {p: sha(Path(p)) for p in plan["before"]}
    assert plan["before"] == after
    proof = {"成功": True, "scope": SCOPE, "一覧": 1680, "実GET": 24, "選択場": SESSION, "選択": list(KEYS), "details": details,
             "Root固定SHA256": fixed_sha, "入力SHA256前": plan["before"], "入力SHA256後": after, "前後不変": True,
             "server停止再起動設定変更": 0, "金融再実行": 0, "ローカルRaw_Tape_Native読取": 0}
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2, default=lambda x: float(x) if isinstance(x, Decimal) else x)
        stream.write("\n")
    return {"成功": True, "一覧": 1680, "実GET": 24, "差": 0}


def main():
    """
    機能: 明示したRoot成功固定と--runがあるときだけHTTPを許可する。
    引数: --run/--fixed/--fixed-sha/--outは実行指定と固定metadata。
    返り値: なし。引数なしや未固定はAPI前に失敗する。
    """
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run", action="store_true", required=True)
    p.add_argument("--fixed", type=Path, required=True)
    p.add_argument("--fixed-sha", required=True)
    p.add_argument("--out", type=Path, required=True)
    a = p.parse_args()
    print(json.dumps(run(a.fixed.resolve(), a.fixed_sha, a.out.resolve()), ensure_ascii=False))


if __name__ == "__main__":
    main()
