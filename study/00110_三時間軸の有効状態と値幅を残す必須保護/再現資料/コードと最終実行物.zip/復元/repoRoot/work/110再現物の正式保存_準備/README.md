# 110再現物の正式保存準備

全70金融・独立保存・純頻度・頻度独立集計・正式成果物保存・CSV独立再読・報告・同入口比較・Viewerの成功Refが揃った後、Rootが新規要求JSONと期待SHA256を渡して実行する。準備時は手製metadataと手製コードだけで検査し、実金融結果や実Nativeを読まない。

圧縮処理は最終準備で認証した109の既存3関数をAST同体で再用する。新しいZIP算法や109の成功gateは使わない。新規の `study/00110_三時間軸の有効状態と値幅を残す必須保護/再現資料/` に、コードZIP、所在索引、保存確認を保存し、同試行の `再現.md` を作る。既存先や最終完了記録があれば拒否する。

## Root要求の型

全Refは絶対path・小文字SHA256（任意でbytes）とする。

```json
{
  "version": 1,
  "trial": 110,
  "fixed": true,
  "candidate_plan": {"path": ".../work/110再現保存の最終準備/最終候補計画.json", "sha256": "4b57e6c48b9d76728570fbe6db8e316bed49c9c9469f8c06db9ea65942952253"},
  "preparation_stop": {"path": ".../work/110再現物の正式保存_準備/停止.json", "sha256": "<今回の停止SHA>"},
  "refs": {
    "financial": {"path": "<成功金融全70metadata>", "sha256": "..."},
    "frequency": {"path": "<成功純頻度全70metadata>", "sha256": "..."},
    "result": {"path": "<正式の成果物/結果.json>", "sha256": "..."},
    "saved_check": {"path": "<正式の成果物/保存会計の確認.json>", "sha256": "..."},
    "frequency_summary": {"path": "<頻度の独立集計JSON>", "sha256": "..."},
    "formal_save": {"path": "<正式保存の確認JSON>", "sha256": "..."},
    "native_index": {"path": "<正式Native参照台帳JSON>", "sha256": "..."},
    "csv_check": {"path": "<CSVの確認.json>", "sha256": "..."},
    "report": {"path": "<報告案の確認.json>", "sha256": "..."},
    "same_entry": {"path": "<同入口比較の結果JSON>", "sha256": "..."},
    "viewer": {"path": "<Viewer8094代表72資源JSON>", "sha256": "..."}
  },
  "csv_outputs": {
    "候補別集計.csv": {"path": "...", "sha256": "..."},
    "全セッション.csv": {"path": "...", "sha256": "..."}
  },
  "documents": [
    {"ref": {"path": "<最終README/設定と結果/目次等>", "sha256": "..."}, "previous_sha256": null}
  ],
  "additional_code": []
}
```

`documents` は本repoのREADME、docs/README、docs/議論/README、docs/議論/外部再調査/README、study/README、試行110のREADME・設定と結果・CSV閲覧案内に限定する。旧候補に同じpathがあるときは、その旧SHAを `previous_sha256` に指定する。ないときはnull。変更を新版計画の差分へ記録し、旧計画のSHAを新文書が維持したとは主張しない。これ以外の旧所在は元SHAを厳守する。元の市場前仕様や停止コードを編集可能文書へ転用しない。

`additional_code` はRootが後段に実使用したコードの明示Refを必要に応じて指定する。repo内のpy/mjs/ps1だけを新規追加でき、旧候補のcode改変は許可しない。Raw、価格CSV、Source、実Native、実取引、CSV出力本体はコードZIPへ同梱しない。最終成功metadataとCSVは、所在・SHAの外部参照だけを索引へ保存する。

金融と保存を同一e0条件、70場・36設定・2520会計・旧280比較へ結び、頻度の主7980/副7700と金融/参加率を計算しない範囲を照合する。CSVは独立再読2520/36と出力SHA、Viewerは2520一覧/11月06日夜72GET/8094、報告と同入口比較は同じ保存結果SHAへ結ぶ。これらは成功metadataの結合であり、全金融・全指標・全価格経路を再計算する検査ではない。

Root要求・証拠metadata・CSVは全SHAを確認する。CSVはSHAだけを検査し値を再集計しない。既存コード全所在、明示文書・追加コード、環境参照を作成前後で確認し、ZIPの全entryをSHA/CRC/容量/集合/安全な名前で再読する。正式ZIPは候補ZIPと同バイトでコピーし再検査する。

```powershell
python -B -X utf8 -m unittest -v 人工検査
python -B -X utf8 work/110再現物の正式保存_準備/正式保存する.py --request <Root要求JSON> --request-sha <期待SHA256>
```

最終closureはZIP後にRootが作成する。保存が成功しても採用・研究目標達成はfalseを維持する。Source106の巨大入力保持/正確な復元、GoRoot717とNode環境の復元はコード保存とは別要件である。
