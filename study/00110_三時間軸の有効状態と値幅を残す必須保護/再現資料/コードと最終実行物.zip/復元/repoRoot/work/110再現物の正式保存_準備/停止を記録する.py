"""110正式再現保存器の非市場人工検査と既存ZIP依存を認証して停止する。"""

import json
from pathlib import Path

import 正式保存する as S


def main():
    """
    機能: 手製6主成功と全所有code不変を認証して停止metadataを保存する。

    引数: なし。
    返り値: None。実金融・Native・HTTP・正式ZIP保存を行わない。
    """
    path = S.OWN / '人工確認.json'
    proof = S.C.read(path)
    S.C.need(proof['成功'] and proof['主'] == 6 and proof['破壊反例'] == 18 and proof['前後不変'], '正式再現保存器の人工成功')
    owned = {str(name): S.sha(name) for name in sorted(S.OWN.glob('*.py')) + [S.OWN / 'README.md']}
    S.C.need(owned == proof['所有コードSHA256'], '人工停止後の全所有code同体')
    reused = {str(S.PREVIOUS / '収集する.py'): S.COLLECTOR_SHA, str(S.PREVIOUS / 'ZIPの共通部.py'): S.COMMON_SHA,
              str(S.P.Z.ORIGINAL): S.P.Z.ORIGINAL_SHA}
    S.C.need(all(S.sha(Path(name)) == expected for name, expected in reused.items()), '既存collector/ZIP3関数の原本同体')
    target = S.OWN / '停止.json'
    value = {'version': 1, 'trial': 110, '成功': True, '停止': True, '主': 6, '破壊反例': 18, '前後不変': True,
             '所有コードSHA256': owned, '再用コードSHA256': reused, '人工確認': S.C.ref(path),
             'scope': '手製全70成功gateと手製コードI/Oだけ。Root全成功Refによる実正式ZIP保存は未実施',
             'Root実行待ち': True, '実金融/実Native/原板/HTTP/11月09日読取': False, '実study正式保存': False}
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'成功': True, '停止': S.C.ref(target)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
