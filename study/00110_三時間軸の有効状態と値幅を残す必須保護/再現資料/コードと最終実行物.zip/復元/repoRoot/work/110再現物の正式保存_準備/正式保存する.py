"""110の全成功Refを結合してコードZIP・所在索引・再現手順を新規保存する。"""

import argparse
from collections import Counter
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil

OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
TRIAL = ROOT / 'study/00110_三時間軸の有効状態と値幅を残す必須保護'
PREVIOUS = ROOT / 'work/110再現保存の最終準備'
CANDIDATE_SHA = '4b57e6c48b9d76728570fbe6db8e316bed49c9c9469f8c06db9ea65942952253'
COLLECTOR_SHA = 'dc90056d8082d5c7944df9526199d33e3bfac6c4f2133607b18e07fae98abacc'
COMMON_SHA = '6fdc6ed6ba8d15fffe71bfecfcb516308cdfc14496a42ef70c0575a05b457f92'
CONDITION_SHA = 'e0f84c5f836a3cb58b6d75c12f08c40e910b661043516e1e642143b6026b9fba'
TECHNIQUE_SHA = '7d4f0135f9ed1cda0d4298355e046db02461a2a02a6ee46f6b7d783489fb023a'
REF_NAMES = {'financial', 'frequency', 'result', 'saved_check', 'frequency_summary', 'formal_save', 'native_index', 'csv_check', 'report', 'same_entry', 'viewer'}
KEYS = tuple(f'{entry}_{guard}_C{cost}_D{delay}' for entry in ('entry_E0', 'entry_E2_L0', 'entry_E2_L1')
             for guard in ('G0', 'G3', 'G4') for cost in (0, 5) for delay in (0, 1))
EDITABLE = {'README.md', 'docs/README.md', 'docs/議論/README.md', 'docs/議論/外部再調査/README.md', 'study/README.md'} | {
    (TRIAL / name).relative_to(ROOT).as_posix() for name in ('README.md', '設定と結果.md', 'CSV閲覧案内.md')}

if hashlib.sha256((PREVIOUS / '収集する.py').read_bytes()).hexdigest() != COLLECTOR_SHA:
    raise ValueError('停止済み最終候補collectorの指紋差')
if hashlib.sha256((PREVIOUS / 'ZIPの共通部.py').read_bytes()).hexdigest() != COMMON_SHA:
    raise ValueError('既存ZIP共通部の指紋差')
SPEC = importlib.util.spec_from_file_location('110正式保存が使う最終候補の共通部', PREVIOUS / '収集する.py')
P = importlib.util.module_from_spec(SPEC)
import sys
sys.path.insert(0, str(PREVIOUS))
try:
    SPEC.loader.exec_module(P)
finally:
    sys.path.pop(0)
C = P.C
COMMON = P.Z.load_common(C)


def sha(path):
    """
    機能: 明示したコード・metadata・CSVの全バイト指紋を取得する。

    引数: path(Path)はRoot要求で限定した対象。
    返り値: strはSHA256。原板・Source・実Nativeを渡さない。
    """
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def bind(ref, before, parse=True):
    """
    機能: 絶対Refの全SHAと任意の容量を認証し入力台帳へ結ぶ。

    引数: ref(dict)、before(dict)、parse(bool)は明示参照・台帳・JSON復号指定。
    返り値: tuple[Path,dict|None]は絶対位置と任意の値。
    """
    C.need(set(ref) in ({'path', 'sha256'}, {'path', 'sha256', 'bytes'}), '明示Refの型')
    path = Path(ref['path'])
    C.need(path.is_absolute() and path.resolve().is_relative_to(ROOT), 'repo内の絶対Refだけ')
    path = path.resolve()
    C.need(path.suffix in ('.json', '.md', '.csv', '.py', '.mjs', '.ps1') and '.Native.' not in path.name, '明示metadata/文書/後段codeだけ')
    C.need(isinstance(ref['sha256'], str) and re.fullmatch('[0-9a-f]{64}', ref['sha256']), '小文字SHA256が必要')
    C.need(sha(path) == ref['sha256'], 'Root要求のRef指紋差:' + str(path))
    if 'bytes' in ref:
        C.need(path.stat().st_size == ref['bytes'], 'Root要求のRef容量差')
    C.need(str(path) not in before or before[str(path)] == ref['sha256'], '同位置の別指紋を拒否')
    before[str(path)] = ref['sha256']
    return path, C.read(path) if parse else None


def validate_gate(values, request):
    """
    機能: 全70と保存・頻度・CSV・報告・比較・Viewerの成功metadataを結合する。

    引数: values/request(dict)は全SHA認証後の成功証拠とRoot要求。
    返り値: list[str]は同一70場。全金融や全指標を再計算しない。
    """
    f, q, result, saved, frequency, formal, native, csv, report, comparison, viewer = (values[name] for name in
        ('financial', 'frequency', 'result', 'saved_check', 'frequency_summary', 'formal_save', 'native_index', 'csv_check', 'report', 'same_entry', 'viewer'))
    refs = request['refs']
    C.need(f['version'] == 1 and f['trial'] == 110 and f['stage'] == 'full70' and f['success'] and not f.get('error'), '110金融全70成功')
    C.need((f['sessions'], f['books_per_scene'], f['books'], f['shadow_books'], f['baseline_comparisons']) == (70, 36, 2520, 0, 280), '金融の全70/36/旧280')
    C.need(f['condition_sha256'] == CONDITION_SHA and f['unchanged'] and f['before'] and f['before'] == f['after'], '金融の同条件と前後不変')
    sessions = [row['session'] for row in f['results']]
    C.need(len(sessions) == len(set(sessions)) == 70 and sessions == sorted(sessions) and sessions[0] == '2026-09-21_Day' and sessions[-1] == '2026-11-06_Night', '同じ既使用70場と順序')
    C.need(q['version'] == 1 and q['trial'] == 110 and q['stage'] == 'full70' and q['success'] and q['unchanged'] and q['before'] == q['after'], '純頻度全70成功/不変')
    C.need(q['financial_executed'] is False and q['participation_calculated'] is False, '純頻度と金融/参加率を区別')
    C.need([row['session'] for row in q['results']] == sessions, '純頻度と金融は同70集合')
    C.need(result['試行'] == 110 and result['成功'] and result['stage'] == 'full70' and (result['場数'], result['会計数']) == (70, 2520), '独立保存全70/2520')
    C.need(tuple(result['主key']) == KEYS and len(result['場別']) == 2520, '保存の固定36候補と全会計')
    C.need({(row['session'], row['key']) for row in result['場別']} == {(session, key) for session in sessions for key in result['主key']}, '保存全場と候補直積')
    C.need(saved['成功'] and saved['不一致数'] == 0 and (saved['会計'], saved['資源'], saved['旧対照']) == (2520, 2520, 280), '独立保存全件成功')
    for value in (result, saved):
        C.need(value['前後不変'] and value['入力codeSHA256前'] and value['入力codeSHA256前'] == value['入力codeSHA256後'], '保存入力/コードの前後不変')
        C.need(value['金融条件SHA256'] == CONDITION_SHA and value['金融完了SHA256'] == refs['financial']['sha256'], '保存と成功金融の結合')
    C.need(saved['出力SHA256']['結果.json'] == refs['result']['sha256'], '保存検算の結果SHA')
    C.need(result.get('採用') is False and result.get('研究目標達成') is False, '研究目標と採用は未達のまま')
    C.need(frequency['成功'] and frequency['unchanged'] and frequency['stage'] == 'full70' and frequency['sessions'] == 70, '純頻度独立集計の全70成功')
    C.need(frequency['completion']['sha256'] == refs['frequency']['sha256'] and frequency['technique_fixed']['sha256'] == TECHNIQUE_SHA, '頻度集計の同完成/技法')
    C.need(frequency['totals']['primary']['planned'] == 7980 and frequency['totals']['secondary']['planned'] == 7700, '頻度主副分母を維持')
    C.need(all(frequency[name] is False for name in ('financial_executed', 'participation_calculated', 'l1_eligibility_calculated', 'opportunity_pnl_calculated', 'holdout_11_09_read')), '頻度の責務と未見保留')
    C.need(formal['成功'] and formal['試行'] == 110 and (formal['Native数'], formal['Viewer資源'], formal['頻度CSV']) == (70, 2520, 5), '正式成果物保存の全件成功')
    C.need(formal['採用'] is False and formal['研究目標達成'] is False and all(row['同bytes'] for row in formal['成果物同bytes']), '正式成果物の同バイトと未採用')
    copied = {row['path']: row['sha256'] for row in formal['成果物同bytes']}
    expected_copies = {'成果物/結果.json', '成果物/一覧.resources.json', '成果物/保存会計の確認.json',
                       '検査/金融全70場.json', '検査/頻度全70場.json', '検査/頻度の独立集計.json', '検査/正式保存の要求.json'}
    expected_copies |= {f'成果物/110_{key}_{session}.trades.jsonl' for session in sessions for key in KEYS}
    expected_copies |= {f'成果物_金融/Native/{session}.Native.json.gz' for session in sessions}
    expected_copies |= {'診断/入口頻度/' + name for name in ('場別の主副頻度.csv', '日夜と固定期の頻度.csv', '三経路の優先と重なり.csv', '並列条件群の頻度.csv', 'Source予定L0と技術状態.csv')}
    C.need(len(copied) == len(formal['成果物同bytes']) and expected_copies.issubset(copied), '全2602正式成果物の明示集合と一意性')
    C.need(copied.get('成果物/結果.json') == refs['result']['sha256'] and copied.get('成果物/保存会計の確認.json') == refs['saved_check']['sha256'], '正式保存の結果と検算')
    C.need(formal['Native台帳']['sha256'] == refs['native_index']['sha256'], '正式Native台帳の指紋')
    C.need(native['成功'] and native['試行'] == 110 and (native['場数'], native['金融会計']) == (70, 2520), '正式Native台帳の全70')
    C.need(native['元金融完了']['sha256'] == refs['financial']['sha256'] and [row['session'] for row in native['Native']] == sessions, '正式Nativeと成功金融の同場結合')
    C.need(all(row['会計'] == 36 and row['元']['sha256'] == source['native']['sha256'] and row['同bytes'] for row, source in zip(native['Native'], f['results'])), '全70Native台帳の元指紋と同バイト証拠')
    C.need(csv['成功'] and csv['試行'] == 110 and csv['入力前後不変'] and csv['入力SHA256'] == refs['result']['sha256'], 'CSVと保存正本の結合')
    recheck = csv['CSV独立再読']
    C.need(recheck['成功'] and (recheck['全行'], recheck['集計行'], recheck['累計対照'], recheck['参加率対照']) == (2520, 36, 2520, 2520), 'CSV全行/集計/累計/参加率の独立再読')
    C.need(set(csv['出力']) == set(request['csv_outputs']) == {'候補別集計.csv', '全セッション.csv'}, 'CSV出力2件だけ')
    for name, count in (('候補別集計.csv', 36), ('全セッション.csv', 2520)):
        C.need(csv['出力'][name]['sha256'] == request['csv_outputs'][name]['sha256'] and csv['出力'][name]['データ行数'] == count, 'CSV実ファイルの指紋と行数')
    C.need(report['成功'] and report['試行'] == 110 and report['前後不変'] and (report['会計'], report['条件'], report['比較差分']) == (2520, 36, 48), '報告の保存正本検査')
    C.need(refs['result']['sha256'] in report['入力SHA256'].values() and refs['saved_check']['sha256'] in report['入力SHA256'].values(), '報告の同じ保存正本と検算')
    C.need(report['研究目標達成'] is False and report['採用'] is False, '報告で目標達成しない')
    C.need(comparison['成功'] and comparison['試行'] == 110, '同入口比較の成功')
    if '解析正本' in comparison:
        C.need(len(comparison['全条件']) == 24 and re.fullmatch('[0-9a-f]{64}', comparison['解析正本']['sha256']), '同入口小要約の24比較と解析正本Ref')
        C.need(refs['financial']['sha256'] in comparison['入力SHA256'].values() and refs['result']['sha256'] in comparison['入力SHA256'].values(), '同入口小要約の金融/保存入力指紋')
    else:
        C.need(comparison['前後不変'] and (comparison['比較数'], comparison['場別比較数']) == (24, 1680), '同入口比較正本の完了範囲')
    C.need(comparison['金融完了']['sha256'] == refs['financial']['sha256'] and comparison['独立保存']['sha256'] == refs['result']['sha256'], '同入口比較の同金融/保存')
    C.need(viewer['成功'] and viewer['試行'] == 110 and viewer['前後不変'] and (viewer['一覧'], viewer['実GET']) == (2520, 72) and viewer['server'] == 'http://127.0.0.1:8094', '専用Viewerの全一覧/限定72GET')
    C.need(viewer['選択場'] == ['2026-11-06_Day', '2026-11-06_Night'] and len(viewer['details']) == len({row['id'] for row in viewer['details']}) == 72, 'Viewer事前選択の72一意')
    C.need({row['id'] for row in viewer['details']} == {f'110_{key}_{session}' for session in viewer['選択場'] for key in KEYS}, 'Viewerの事前固定72ID')
    C.need(refs['result']['sha256'] in viewer['入力SHA256前'].values() and saved['出力SHA256']['一覧.resources.json'] in viewer['入力SHA256前'].values(), 'Viewerの同じ正式結果/一覧')
    C.need(viewer['入力SHA256前'] == viewer['入力SHA256後'], 'Viewer入力の前後不変')
    return sessions


def validate_documents(items, previous):
    """
    機能: 更新可能な正式文書だけを新旧指紋の宣言へ分ける。

    引数: items(list[dict])はRoot文書Ref、previous(dict)は旧候補計画。
    返り値: dict[str,dict]は絶対位置別の許可済み新旧宣言。
    """
    old = {row['original_path']: row for row in previous['files']}
    result = {}
    for item in items:
        C.need(set(item) == {'ref', 'previous_sha256'}, '文書改版の明示Refと旧指紋')
        path = Path(item['ref']['path']).resolve()
        C.need(path.is_relative_to(ROOT) and path.relative_to(ROOT).as_posix() in EDITABLE, '編集可能な正式文書/目次だけ')
        C.need(str(path) not in result, '文書改版の重複なし')
        prior = old.get(str(path))
        C.need(item['previous_sha256'] == (None if prior is None else prior['sha256']), '文書の旧SHAは旧計画の値又は未収録null')
        if prior is not None:
            C.need(prior['kind'] == 'metadata', '停止コード/市場前仕様を文書更新へ転用しない')
        result[str(path)] = item
    return result


def rebuild_files(previous, declarations, before):
    """
    機能: 旧所在の全code指紋を維持し宣言した正式文書だけ改版する。

    引数: previous/declarations/before(dict)は旧計画・許可済み文書宣言・入力台帳。
    返り値: tuple[Registry,list]は更新台帳と新旧SHAの明示差分。
    """
    registry = C.Registry([Path(row['original_path']) for row in previous['files'] if row['kind'] == '最終exe'],
                          [Path(row['original_path']) for row in previous['files'] if row['kind'] == '人工'])
    revisions = []
    for row in previous['files']:
        name, expected = row['original_path'], row['sha256']
        if name in declarations:
            item = declarations[name]
            bind(item['ref'], before, False)
            expected = item['ref']['sha256']
            if expected != row['sha256']:
                revisions.append({'path': name, 'previous_sha256': row['sha256'], 'sha256': expected, '理由': '全70結果後の正式報告/目次更新'})
        C.need(sha(Path(name)) == expected, '旧候補のcode/原仕様又は宣言文書の指紋差:' + name)
        before[name] = expected
        for role in row['roles']:
            current = registry.add(name, expected, role, row['kind'])
        C.need(current['kind'] == row['kind'] and current['restore'] == row['restore'] and current['location'] == row['location'], '旧候補の保存種別/位置を維持')
    for name, item in declarations.items():
        bind(item['ref'], before, False)
        if name not in registry.rows:
            revisions.append({'path': name, 'previous_sha256': None, 'sha256': item['ref']['sha256'], '理由': '全70結果後の正式文書を新規収録'})
        registry.add_ref(item['ref'], '全70結果後の正式報告/目次', 'metadata')
    return registry, revisions


def prepare(request_ref):
    """
    機能: 全成功・候補計画・文書改版・全codeを正式保存前に認証する。

    引数: request_ref(dict)はRootの期待SHA付き要求。
    返り値: dictは新計画・現在入力指紋・限定成功metadata。出力はまだ作らない。
    """
    C.need(not (TRIAL / '再現資料').exists() and not (TRIAL / '再現.md').exists() and not (TRIAL / '完了記録.json').exists(), '既存の再現資料/再現.md/閉鎖を上書きしない')
    C.need(not (OWN / '正式保存候補').exists(), '正式保存候補を上書きしない')
    before = {}
    request_path, request = bind(request_ref, before)
    C.need(request['version'] == 1 and request['trial'] == 110 and request['fixed'] is True and set(request['refs']) == REF_NAMES, 'Root固定の110必須成功Ref')
    C.need(request['candidate_plan']['sha256'] == CANDIDATE_SHA, '元の停止済み候補計画が必要')
    _, previous = bind(request['candidate_plan'], before)
    C.need(previous['trial'] == 110 and len(previous['files']) == 1449, '元候補の1449所在')
    stop_path, stop = bind(request['preparation_stop'], before)
    C.need(stop_path == OWN / '停止.json' and stop['成功'] and stop['停止'] and stop['trial'] == 110, '正式再現保存器の停止参照')
    own = {str(path): sha(path) for path in sorted(OWN.glob('*.py')) + [OWN / 'README.md']}
    C.need(stop['所有コードSHA256'] == own, '現在の正式再現保存器と停止全codeの同体')
    before.update(own)
    values = {name: bind(request['refs'][name], before)[1] for name in sorted(REF_NAMES)}
    for ref in request['csv_outputs'].values():
        bind(ref, before, False)
    sessions = validate_gate(values, request)
    declarations = validate_documents(request.get('documents', []), previous)
    C.need({str(TRIAL / name) for name in ('README.md', '設定と結果.md')}.issubset(declarations), '最終README/設定と結果を明示する')
    registry, revisions = rebuild_files(previous, declarations, before)
    comparison = values['same_entry']
    if '解析正本' in comparison:
        bind(comparison['解析正本'], before, False)
    for ref in request.get('additional_code', []):
        path, _ = bind(ref, before, False)
        C.need(path.suffix in ('.py', '.mjs', '.ps1') and str(path) not in {row['original_path'] for row in previous['files']}, '後段codeは新規の明示py/mjs/ps1だけ')
        registry.add_ref(ref, 'Rootが明示する最終後段code')
    for name, expected in own.items():
        registry.add(name, expected, '110成功gate/既存ZIP再用/索引/再現文書の正式保存器', 'metadata' if Path(name).suffix == '.md' else 'code')
    for ref, label in ((request['candidate_plan'], '変更しない旧候補計画'), (request['preparation_stop'], '正式再現保存器の停止'),
                       (stop['人工確認'], '正式再現保存器の手製検査'), (request_ref, 'Root最終要求の正本')):
        path, _ = bind(ref, before)
        registry.add_ref(ref, label, 'metadata')
    for environment in previous.get('external_environment', []):
        path = Path(environment['path'])
        C.need(sha(path) == environment['sha256'], '外部Viewer実行物の同体')
        before[str(path)] = environment['sha256']
    files = sorted(registry.rows.values(), key=lambda row: row['original_path'])
    for row in files:
        row['roles'].sort()
        before[row['original_path']] = row['sha256']
    common_names = [row['location']['entry'] for row in files if row['kind'] != '環境']
    C.need(all(COMMON.safe(name) for name in common_names) and len(common_names) == len({name.casefold() for name in common_names}), '最終ZIP名の安全性/Windows一意性')
    plan = copy.deepcopy(previous)
    plan.update({'version': 4, 'scope': 'Rootの全成功Refを結合した110正式再現保存計画。研究目標/採用は未達', 'previous_plan': request['candidate_plan'],
                 'files': files, 'mutable_document_revisions': revisions, 'success_evidence': request['refs'], 'csv_external': request['csv_outputs'],
                 'final_evidence': request['refs'], 'final_evidence_pending': [],
                 'final_documents': request.get('documents', []), 'root_request': request_ref, 'sessions': sessions,
                 'summary': {'全所在': len(files), '同梱予定': sum(row['kind'] != '環境' for row in files),
                             '環境参照': sum(row['kind'] == '環境' for row in files), '種別': dict(Counter(row['kind'] for row in files)),
                             '同梱元bytes': sum(row['bytes'] for row in files if row['kind'] != '環境')},
                 'pending': ['ZIP保存後の最終closureはRootが作成', 'Source106入力保持/正確復元はコード/exe保存とは別要件'],
                 '研究目標達成': False, '採用': False})
    C.need(sum(row['kind'] == '環境' for row in files) == 717 and sum(row['kind'] == '最終exe' for row in files) == 2, '環境717/停止exe2だけ')
    C.need(before == {name: sha(Path(name)) for name in before}, '正式保存直前の全入力同体')
    return {'plan': plan, 'before': before, 'request': request, 'request_path': request_path, 'values': values}


def write_json(path, value):
    """
    機能: 正式metadataを未使用の位置へだけ保存する。

    引数: path(Path)、value(dict)は新規先とJSON値。
    返り値: None。既存正本を上書きしない。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write('\n')


def reproduction(plan, archive_ref, proof_ref):
    """
    機能: 保存範囲と復元の限界を明記した110の再現手順を構成する。

    引数: plan/archive_ref/proof_ref(dict)は確定計画・正式ZIP・全entry検査Ref。
    返り値: strは日本語Markdown。成功利益や採用を宣言しない。
    """
    executable = [row for row in plan['files'] if row['kind'] == '最終exe']
    lines = ['# 110の再現手順', '', '全70・36設定・2,520会計の金融、独立保存、純頻度、CSV再読、報告、同入口比較、限定Viewer APIの成功metadataを結合して保存した。採用・研究目標達成はfalseのままであり、既使用期間の探索結果を将来の安定利益と扱わない。', '',
             '## コードと停止実行物', '', f'コードZIPは[再現資料/コードと最終実行物.zip](再現資料/コードと最終実行物.zip)、SHA256 `{archive_ref["sha256"]}`。[所在索引](再現資料/コード所在索引.json)に全元path・SHA・容量・復元root/relative・ZIP entryを残した。[保存の確認](再現資料/保存の確認.json)のSHA256は `{proof_ref["sha256"]}`。', '',
             'ZIPの全entryをSHA/CRC/容量/安全名/集合で再読し、正式コピーも同バイトで確認した。GoRoot717件はGo1.24.2の環境参照で本文を同梱せず、LICENSE/PATENTSを含む利用条件は同梱した。NodeとArtifact Tool環境も外部依存である。', '',
             '復元は索引のrestore.root/relativeを使う。repoRoot・neighborRoot・moduleCacheRoot・goRootを元配置へ対応させ、同SHAだけを再利用する。異なる既存ファイルを自動上書きしない。ソースからのbuild成功と同じexe SHAの復元は別であり、VCS埋込や絶対pathで再buildのSHAが変わる場合がある。', '']
    for row in executable:
        lines.append(f'- `{row["original_path"]}`：SHA256 `{row["sha256"]}`。')
    lines += ['', '手製人工52件と停止・人工検査・最終helperを含む。実Raw/価格CSV/Source/Tape/Header/Record/Native・実trades・閲覧CSV本体はコードZIPへ重複同梱しない。成功metadataと正式成果物は索引の外部Refを参照する。旧Actor補助2本に残る1行docstringは停止原本の履歴として保持し、コード停止を連鎖変更していない。', '',
              '## 入力と固定条件', '', '実使用条件は金融条件_停止形式整合.json、SHA256 `' + CONDITION_SHA + '`。元の金融条件.jsonは停止型のmetadata検査で市場本文前に拒否された履歴として残す。通常型viewへの射影はmetadataだけで、算法・36設定・費用・入力・時計・分母を変更していない。中断した全70部分出力は完成結果へ混ぜず、同条件の新規先で再実行した。', '',
              'Source106の巨大公表入力と旧108 Nativeを共用する。work全削除後にコード/exeだけで現在のSource入力まで自動復元できるとは保証しない。金融条件、旧106 producerの索引とarchive Ref、旧108正式Native台帳の全指紋を維持し、必要な入力を保持するか正確に復元する。新110 Nativeは成果物_金融/Native参照台帳.jsonで正式保存先へ結ぶ。', '',
              '## 実行形', '', 'CLIは既存出力を拒否する。以下は元条件の構造を示す。再現用の新規出力を選ぶ場合は、成功completion・保存要求・頻度要求・後段のRefを新しく結び直す。元条件/旧成功Refを直接書き換えない。', '',
              '```powershell', "& 'work/110有効状態と値幅保護の市場入出力/検査/110市場.exe' `", "  --condition 'study/00110_三時間軸の有効状態と値幅を残す必須保護/金融条件_停止形式整合.json' `", f"  --condition-sha {CONDITION_SHA} --stage full70 --out <未使用出力> `", '  --first2 <同条件の成功first2> --first2-sha <そのSHA256>', '',
              "& 'work/110入口の頻度前検査/検査/110頻度.exe' `", '  --request <Root固定の同条件純頻度要求> --request-sha256 <そのSHA256>', '', "python -B -X utf8 'work/110有効状態と値幅保護の保存/集計.py' `", '  --fixed <成功後の保存要求> --fixed-sha <そのSHA256> --out <未使用保存先>', '```', '',
              '純頻度の独立集計、CSV生成/独立再読、報告、正式保存、同入口比較、Viewer確認の各helperと停止は索引に含む。CSVはscripts/損益CSV/出力する.mjsと再読で照合する.pyで生成・検査し、XLSXは作らない。Node/Artifact Tool本体やnode_modules junctionは外部環境であり、その復元は別に必要になる。', '',
              'Viewerは新専用8094の2520一覧IDと11/06日夜72資源のAPI純額・約定行・残0を確認した範囲である。全2520のGET・描画やブラウザ視認の証明ではない。元8092/旧8093を操作しない。Viewer exeは外部環境Ref、設定/起動記録と純検算コードは保存する。', '',
              '## 文書改版と最終閉鎖', '', '正式README・設定表・目次は全70結果後の文書として扱う。旧候補から変更した文書は新版計画のmutable_document_revisionsへ旧/新SHAを明記した。旧候補や停止コード・市場前仕様のSHAを新文書が維持したとは主張しない。', '',
              '正式再現保存の要求Refは所在索引のRoot要求を参照する。保存処理の新規先制約により、同じ正式先への再実行は拒否される。最終closureはZIP保存後にRootが作成し、このZIPへ先に含めて循環参照を作らない。', '']
    return '\n'.join(lines)


def execute(request_ref):
    """
    機能: 全認証後だけ新版計画・ZIP・索引・検査・再現手順を正式保存する。

    引数: request_ref(dict)はRootの最終固定要求。
    返り値: dictは正式ZIP/索引/確認/再現MDのRef。最終closureは作らない。
    """
    prepared = prepare(request_ref)
    plan, before = prepared['plan'], prepared['before']
    stage = OWN / '正式保存候補'
    stage.mkdir()
    plan_path = stage / '最終計画.json'
    write_json(plan_path, plan)
    before[str(plan_path)] = sha(plan_path)
    registry = C.Registry()
    plan_row = registry.file(plan_path, '正式ZIPの確定生成計画', 'metadata')
    archived = [row for row in plan['files'] if row['kind'] != '環境'] + [plan_row]
    staged_zip = stage / 'コードと最終実行物.zip'
    COMMON.write_zip(staged_zip, archived)
    checks = COMMON.verify_zip(staged_zip, archived)
    C.need(before == {name: sha(Path(name)) for name in before}, 'ZIP作成後の全入力/現在文書の前後不変')
    # ----------------------------------------
    # 検査済み候補だけを新規の正式先へ同バイトで保存する。
    destination = TRIAL / '再現資料'
    C.need(not destination.exists(), '正式再現資料は未使用先だけ')
    destination.mkdir()
    final_zip = destination / staged_zip.name
    with staged_zip.open('rb') as source, final_zip.open('xb') as target:
        shutil.copyfileobj(source, target)
    C.need(sha(final_zip) == sha(staged_zip), '正式ZIPの同バイト')
    COMMON.verify_zip(final_zip, archived)
    index_rows = copy.deepcopy(plan['files'] + [plan_row])
    for row in index_rows:
        if row['kind'] != '環境':
            row['location'].update({'kind': 'このZIP', 'archive': 'コードと最終実行物.zip', **checks[row['location']['entry']]})
    index = {'成功': True, '試行': 110, 'scope': '110停止code/最終exe/明示人工/後段helperと文書の保存。金融結果の再計算ではない',
             'ZIP': C.ref(final_zip), '計画': C.ref(plan_path), 'Root要求': request_ref, '旧候補計画': plan['previous_plan'],
             'roots': plan['roots'], 'entries': index_rows, '同梱entry数': len(archived), 'GoRoot環境参照': 717, '最終exe数': 2,
             '実行成功証拠': plan['success_evidence'], 'CSV外部参照': plan['csv_external'], '文書改版': plan['mutable_document_revisions'],
             'LICENSE': plan['licenses'], 'environment': plan['environment'], '外部Viewer環境': plan.get('external_environment', []),
             '共用入力依存': plan['input_dependencies'], '旧106のproducer': plan['old106_producer'], '未同梱': plan['not_copied'],
             '研究目標達成': False, '採用': False, '閉鎖': False}
    index_path = destination / 'コード所在索引.json'
    write_json(index_path, index)
    after = {name: sha(Path(name)) for name in before}
    C.need(after == before, '正式コピー後の全入力/現在文書不変')
    proof = {'成功': True, '試行': 110, 'ZIP': C.ref(final_zip), '索引': C.ref(index_path), '計画': C.ref(plan_path),
             'Root要求': request_ref, '自己code': C.ref(Path(__file__).resolve()), '同梱entry数': len(archived), 'GoRoot環境参照': 717, '最終exe数': 2,
             '全entrySHA/CRC/安全path/集合': True, '正規化重複': 0, '候補と正式ZIP同bytes': True,
             '入力SHA256前': before, '入力SHA256後': after, '前後不変': True, '文書改版': plan['mutable_document_revisions'],
             '旧候補計画改変': False, '停止コード/市場前仕様改変': False, '金融/Observer/Viewer再実行': False,
             '実Raw/Source/Native読取複製': False, 'CSVはSHAのみ/非同梱': True, '11月09日入力読取': False,
             '研究目標達成': False, '採用': False, '閉鎖': False}
    proof_path = destination / '保存の確認.json'
    write_json(proof_path, proof)
    reproduction_path = TRIAL / '再現.md'
    with reproduction_path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(reproduction(plan, C.ref(final_zip), C.ref(proof_path)))
    return {'ZIP': C.ref(final_zip), '索引': C.ref(index_path), '確認': C.ref(proof_path), '再現MD': C.ref(reproduction_path),
            'entry数': len(archived), 'GoRoot環境': 717, '研究目標達成': False, '採用': False}


def main():
    """
    機能: Rootの全成功固定要求があるときだけ新規正式再現保存を実行する。

    引数: --request/--request-shaは最終要求の絶対pathと期待SHA256。
    返り値: None。標準出力へ小型の保存Refを出す。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--request', type=Path, required=True)
    parser.add_argument('--request-sha', required=True)
    args = parser.parse_args()
    print(json.dumps(execute({'path': str(args.request.resolve()), 'sha256': args.request_sha}), ensure_ascii=False))


if __name__ == '__main__':
    main()
