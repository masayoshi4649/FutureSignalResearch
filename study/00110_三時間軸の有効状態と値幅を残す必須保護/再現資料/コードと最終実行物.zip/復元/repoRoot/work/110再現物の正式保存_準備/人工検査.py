"""手製成功metadataと手製コードだけで110正式再現保存を検査する。"""

import ast
import copy
from datetime import date, timedelta
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import 正式保存する as S


def fixture():
    """
    機能: 金融価格や損益を含まない全70成功metadataの型を生成する。

    引数: なし。
    返り値: tuple[dict,dict]は純gate検査用の値とRoot要求型。
    """
    sessions = []
    current = date(2026, 9, 21)
    while current <= date(2026, 11, 6):
        if current.weekday() < 5:
            sessions.extend((current.isoformat() + '_Day', current.isoformat() + '_Night'))
        current += timedelta(days=1)
    refs = {name: {'path': str(S.OWN / ('手製_' + name + '.json')), 'sha256': f'{index:064x}'} for index, name in enumerate(sorted(S.REF_NAMES), 1)}
    request = {'refs': refs, 'csv_outputs': {name: {'path': str(S.OWN / name), 'sha256': letter * 64} for name, letter in (('候補別集計.csv', 'a'), ('全セッション.csv', 'b'))}}
    unchanged = {'手製入力': 'c' * 64}
    f = {'version': 1, 'trial': 110, 'stage': 'full70', 'success': True, 'sessions': 70, 'books_per_scene': 36, 'books': 2520,
         'shadow_books': 0, 'baseline_comparisons': 280, 'condition_sha256': S.CONDITION_SHA,
         'unchanged': True, 'before': dict(unchanged), 'after': dict(unchanged),
         'results': [{'session': session, 'native': {'sha256': f'{index + 100:064x}'}} for index, session in enumerate(sessions)]}
    q = {'version': 1, 'trial': 110, 'stage': 'full70', 'success': True, 'unchanged': True, 'before': dict(unchanged), 'after': dict(unchanged),
         'financial_executed': False, 'participation_calculated': False, 'results': [{'session': session} for session in sessions]}
    base = {'前後不変': True, '入力codeSHA256前': dict(unchanged), '入力codeSHA256後': dict(unchanged),
            '金融条件SHA256': S.CONDITION_SHA, '金融完了SHA256': refs['financial']['sha256']}
    result = {**base, '試行': 110, '成功': True, 'stage': 'full70', '場数': 70, '会計数': 2520, '主key': list(S.KEYS),
              '場別': [{'session': session, 'key': key} for session in sessions for key in S.KEYS], '採用': False, '研究目標達成': False}
    saved = {**base, '成功': True, '不一致数': 0, '会計': 2520, '資源': 2520, '旧対照': 280,
             '出力SHA256': {'結果.json': refs['result']['sha256'], '一覧.resources.json': 'd' * 64}}
    frequency = {'成功': True, 'unchanged': True, 'stage': 'full70', 'sessions': 70,
                 'completion': refs['frequency'], 'technique_fixed': {'sha256': S.TECHNIQUE_SHA},
                 'totals': {'primary': {'planned': 7980}, 'secondary': {'planned': 7700}},
                 'financial_executed': False, 'participation_calculated': False, 'l1_eligibility_calculated': False,
                 'opportunity_pnl_calculated': False, 'holdout_11_09_read': False}
    names = {'成果物/結果.json', '成果物/一覧.resources.json', '成果物/保存会計の確認.json', '検査/金融全70場.json', '検査/頻度全70場.json', '検査/頻度の独立集計.json', '検査/正式保存の要求.json'}
    names |= {f'成果物/110_{key}_{session}.trades.jsonl' for session in sessions for key in S.KEYS}
    names |= {f'成果物_金融/Native/{session}.Native.json.gz' for session in sessions}
    names |= {'診断/入口頻度/' + name for name in ('場別の主副頻度.csv', '日夜と固定期の頻度.csv', '三経路の優先と重なり.csv', '並列条件群の頻度.csv', 'Source予定L0と技術状態.csv')}
    copied = {name: {'path': name, 'sha256': 'e' * 64, '同bytes': True} for name in names}
    copied['成果物/結果.json']['sha256'] = refs['result']['sha256']
    copied['成果物/保存会計の確認.json']['sha256'] = refs['saved_check']['sha256']
    formal = {'成功': True, '試行': 110, 'Native数': 70, 'Viewer資源': 2520, '頻度CSV': 5, '採用': False, '研究目標達成': False,
              '成果物同bytes': list(copied.values()), 'Native台帳': refs['native_index']}
    native = {'成功': True, '試行': 110, '場数': 70, '金融会計': 2520, '元金融完了': refs['financial'],
              'Native': [{'session': row['session'], '会計': 36, '元': row['native'], '同bytes': True} for row in f['results']]}
    csv = {'成功': True, '試行': 110, '入力前後不変': True, '入力SHA256': refs['result']['sha256'],
           'CSV独立再読': {'成功': True, '全行': 2520, '集計行': 36, '累計対照': 2520, '参加率対照': 2520},
           '出力': {name: {'sha256': ref['sha256'], 'データ行数': 36 if name == '候補別集計.csv' else 2520} for name, ref in request['csv_outputs'].items()}}
    report = {'成功': True, '試行': 110, '前後不変': True, '会計': 2520, '条件': 36, '比較差分': 48,
              '入力SHA256': {refs[name]['path']: refs[name]['sha256'] for name in ('result', 'saved_check')}, '研究目標達成': False, '採用': False}
    comparison = {'成功': True, '試行': 110, '前後不変': True, '比較数': 24, '場別比較数': 1680,
                  '金融完了': refs['financial'], '独立保存': refs['result']}
    viewer_inputs = {'手製保存結果': refs['result']['sha256'], '手製一覧': saved['出力SHA256']['一覧.resources.json']}
    viewer = {'成功': True, '試行': 110, '前後不変': True, '一覧': 2520, '実GET': 72, 'server': 'http://127.0.0.1:8094',
              '選択場': ['2026-11-06_Day', '2026-11-06_Night'],
              'details': [{'id': f'110_{key}_{session}'} for session in ('2026-11-06_Day', '2026-11-06_Night') for key in S.KEYS],
              '入力SHA256前': dict(viewer_inputs), '入力SHA256後': dict(viewer_inputs)}
    values = dict(zip(('financial', 'frequency', 'result', 'saved_check', 'frequency_summary', 'formal_save', 'native_index', 'csv_check', 'report', 'same_entry', 'viewer'),
                      (f, q, result, saved, frequency, formal, native, csv, report, comparison, viewer)))
    return values, request


class 正式再現検査(unittest.TestCase):
    """手製の成功gateと限定したZIP I/Oを検査する。"""

    def test_全成功metadataの結合と小要約型(self):
        """
        機能: 大比較正本型と小要約型を分けて全成功Refを照合する。

        引数: self(正式再現検査)は検査器。
        返り値: None。実結果の値を読まない。
        """
        values, request = fixture()
        sessions = S.validate_gate(values, request)
        self.assertEqual(len(sessions), 70)
        small = {'成功': True, '試行': 110, '全条件': {str(i): {} for i in range(24)},
                 '解析正本': {'path': '手製解析.json', 'sha256': 'f' * 64},
                 '入力SHA256': {'金融': request['refs']['financial']['sha256'], '保存': request['refs']['result']['sha256']},
                 '金融完了': request['refs']['financial'], '独立保存': request['refs']['result']}
        values['same_entry'] = small
        self.assertEqual(S.validate_gate(values, request), sessions)

    def test_失敗欠落別結合を正式出力前に拒否する(self):
        """
        機能: 部分成功・別条件・別保存・不足資源・未再読等を拒否する。

        引数: self(正式再現検査)は検査器。
        返り値: None。
        """
        values, request = fixture()
        mutations = {
            '金融未完': lambda v: v['financial'].update(success=False),
            '金融不足': lambda v: v['financial'].update(books=2519),
            '別金融条件': lambda v: v['financial'].update(condition_sha256='f' * 64),
            '別頻度集合': lambda v: v['frequency']['results'].pop(),
            '頻度を金融扱い': lambda v: v['frequency'].update(financial_executed=True),
            '保存前後差': lambda v: v['saved_check'].update(入力codeSHA256後={}),
            '保存別金融': lambda v: v['saved_check'].update(金融完了SHA256='f' * 64),
            '頻度分母減': lambda v: v['frequency_summary']['totals']['primary'].update(planned=7979),
            '正式約定集合不足': lambda v: v['formal_save']['成果物同bytes'].pop(),
            'Native台帳別金融': lambda v: v['native_index'].update(元金融完了={'sha256': 'f' * 64}),
            'CSV未再読': lambda v: v['csv_check']['CSV独立再読'].update(成功=False),
            'CSV累計不足': lambda v: v['csv_check']['CSV独立再読'].update(累計対照=2519),
            '報告別保存': lambda v: v['report'].update(入力SHA256={}),
            '比較場数不足': lambda v: v['same_entry'].update(場別比較数=1679),
            'Viewer別server': lambda v: v['viewer'].update(server='http://127.0.0.1:8092'),
            'Viewer別代表ID': lambda v: v['viewer']['details'][0].update(id='別ID'),
            'Viewer入力差': lambda v: v['viewer'].update(入力SHA256後={}),
            '勝手に採用': lambda v: v['result'].update(採用=True),
        }
        for name, mutate in mutations.items():
            bad = copy.deepcopy(values)
            mutate(bad)
            with self.subTest(name=name), self.assertRaises(ValueError):
                S.validate_gate(bad, request)

    def test_文書改版を明記しコード改変は拒否する(self):
        """
        機能: 許可文書の旧/新SHA差を残し無宣言差とcode差を拒否する。

        引数: self(正式再現検査)は検査器。
        返り値: None。停止済み実ファイルは変更しない。
        """
        with tempfile.TemporaryDirectory(prefix='人工_', dir=S.OWN) as name:
            folder = Path(name).resolve()
            self.assertTrue(folder.is_relative_to(S.OWN))
            doc, code = folder / '手製.md', folder / '手製.py'
            doc.write_text('旧説明\n', encoding='utf-8')
            code.write_text('値=1\n', encoding='utf-8')
            registry = S.C.Registry()
            old_doc = copy.deepcopy(registry.file(doc, '手製の旧説明', 'metadata'))
            registry.file(code, '手製の旧code')
            previous = {'files': list(registry.rows.values())}
            doc.write_text('新説明\n', encoding='utf-8')
            item = {'ref': S.C.ref(doc), 'previous_sha256': old_doc['sha256']}
            relative = doc.relative_to(S.ROOT).as_posix()
            with patch.object(S, 'EDITABLE', {relative}):
                declaration = S.validate_documents([item], previous)
                current, changes = S.rebuild_files(previous, declaration, {})
                self.assertEqual(len(changes), 1)
                self.assertEqual(changes[0]['previous_sha256'], old_doc['sha256'])
                self.assertEqual(current.rows[str(doc)]['sha256'], S.sha(doc))
                bad = dict(item, previous_sha256='0' * 64)
                with self.assertRaises(ValueError):
                    S.validate_documents([bad], previous)
            with self.assertRaises(ValueError):
                S.rebuild_files(previous, {}, {})
            code.write_text('値=2\n', encoding='utf-8')
            with self.assertRaises(ValueError):
                S.rebuild_files(previous, declaration, {})
            with self.assertRaises(ValueError):
                S.validate_documents([{'ref': S.C.ref(code), 'previous_sha256': None}], previous)

    def test_手製ZIPの正式同bytesと全entryを再読する(self):
        """
        機能: gateと分離した手製3ファイルでZIP/索引/再現文書の新規保存を検査する。

        引数: self(正式再現検査)は検査器。
        返り値: None。実studyへは保存しない。
        """
        with tempfile.TemporaryDirectory(prefix='人工_', dir=S.OWN) as name:
            folder = Path(name).resolve()
            self.assertTrue(folder.is_relative_to(S.OWN))
            own, trial = folder / '保存器', folder / '手製試行'
            own.mkdir()
            trial.mkdir()
            registry = S.C.Registry()
            for index in range(3):
                source = folder / f'手製{index}.py'
                source.write_text(f'値={index}\n', encoding='utf-8')
                registry.file(source, '手製I/Oだけの器具')
            files = list(registry.rows.values())
            plan = {'files': files, 'previous_plan': {'path': '手製計画', 'sha256': 'a' * 64}, 'roots': {}, 'success_evidence': {},
                    'csv_external': {}, 'mutable_document_revisions': [], 'licenses': [], 'environment': {}, 'input_dependencies': {},
                    'old106_producer': {}, 'not_copied': [], 'external_environment': []}
            before = {row['original_path']: row['sha256'] for row in files}
            prepared = {'plan': plan, 'before': before, 'request': {}, 'values': {}}
            with patch.object(S, 'OWN', own), patch.object(S, 'TRIAL', trial), patch.object(S, 'prepare', return_value=prepared):
                output = S.execute({'path': str(folder / '手製要求.json'), 'sha256': 'b' * 64})
                proof = S.C.read(Path(output['確認']['path']))
                index = S.C.read(Path(output['索引']['path']))
                self.assertEqual(output['entry数'], 4)
                self.assertTrue(proof['前後不変'] and proof['候補と正式ZIP同bytes'])
                self.assertFalse(proof['採用'] or proof['研究目標達成'] or proof['閉鎖'])
                self.assertEqual(len(index['entries']), 4)
                self.assertEqual(S.sha(Path(output['ZIP']['path'])), S.sha(own / '正式保存候補/コードと最終実行物.zip'))
                self.assertIn('既使用期間の探索', Path(output['再現MD']['path']).read_text(encoding='utf-8'))
                with self.assertRaises(FileExistsError):
                    S.execute({'path': '手製', 'sha256': 'b' * 64})

    def test_未固定は全候補結果読取と保存の前に拒否する(self):
        """
        機能: Root成功Refを持たない要求で正式先を作成しない。

        引数: self(正式再現検査)は検査器。
        返り値: None。
        """
        with tempfile.TemporaryDirectory(prefix='人工_', dir=S.OWN) as name:
            folder = Path(name).resolve()
            own, trial = folder / '保存器', folder / '手製試行'
            own.mkdir()
            trial.mkdir()
            path = folder / '未固定.json'
            path.write_text(json.dumps({'version': 1, 'trial': 110, 'fixed': False}), encoding='utf-8')
            with patch.object(S, 'OWN', own), patch.object(S, 'TRIAL', trial):
                with self.assertRaises(ValueError):
                    S.prepare(S.C.ref(path))
            self.assertFalse((own / '正式保存候補').exists())
            self.assertFalse((trial / '再現資料').exists())

    def test_関数コメント規約(self):
        """
        機能: 新Python全関数の複数行と機能/引数/返り値を確認する。

        引数: self(正式再現検査)は検査器。
        返り値: None。
        """
        for path in S.OWN.glob('*.py'):
            for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    text = ast.get_docstring(node)
                    self.assertTrue(text and node.body[0].end_lineno > node.body[0].lineno, (path.name, node.name))
                    self.assertTrue(all(word in text for word in ('機能:', '引数:', '返り値:')), (path.name, node.name))


def main():
    """
    機能: 手製metadata/コードだけの検査を実行し小型確認へ保存する。

    引数: なし。
    返り値: None。実結果/Native/原板/HTTP/正式study保存は行わない。
    """
    files = sorted(S.OWN.glob('*.py')) + [S.OWN / 'README.md']
    before = {str(path): S.sha(path) for path in files}
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(正式再現検査))
    S.C.need(before == {str(path): S.sha(path) for path in files}, '正式再現保存の所有code前後不変')
    value = {'成功': result.wasSuccessful(), '主': result.testsRun, '破壊反例': 18, '所有コードSHA256': before, '前後不変': True,
             'scope': '手製70×36成功metadataと手製3コードのZIP/索引/再現I/O。実金融結果・実正式保存ではない',
             '大比較/小要約の別schema': True, '文書の旧新SHA明示': True, '無宣言code差拒否': True,
             '実金融結果/Native/原板/HTTP/11月09日読取': False, '実study正式保存': False}
    with (S.OWN / '人工確認.json').open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    if not result.wasSuccessful():
        raise SystemExit(1)


if __name__ == '__main__':
    main()
