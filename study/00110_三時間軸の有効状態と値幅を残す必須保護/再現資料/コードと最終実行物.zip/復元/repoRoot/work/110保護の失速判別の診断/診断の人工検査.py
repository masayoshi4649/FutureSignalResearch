"""三値警戒、床由来の証拠不足、生存期間と実約定の結合を手製で検査する。"""

import copy
import unittest

import 診断する as D


def step(at: int, index: int, sequence: int, phase: str, gain: int, floor: int = 10) -> dict:
    """最小の起動済み保護保存点を作る。

    引数: at/index/sequence/gain/floor(int)は時計・順序・値幅、phase(str)は段階。
    返り値: dictは手製保存点。
    """
    quote = {"time": at, "index": index, "bid": 100 + gain, "ask": 105 + gain}
    publication = {"available_at": at - 1, "c": 2, "m": 2, "v": 10, "close": 120, "prior_pivot": {"price": 90}}
    state = {"entry": {"side": 1, "price": 100, "entry_v": {"value": 15}}, "minimum_floor": 10, "active": True, "threshold_known": True, "threshold_points": 15, "threshold_lock": {"dominant_terms": ["人工支配"]}, "atr": {"value": 20}, "narrowed": True, "peak_points": 20, "floor_points": floor, "width_points": 10, "latest_publication": publication, "sequence": sequence}
    decision = {"warning": 2, "p": 1, "width_source": "人工狭幅", "structural_floor": None}
    point = {"quote": quote, "phase": phase, "quantity": 1, "reserved": 0, "mark_price": 100 + gain, "gain_points": gain, "unit_net": gain * 100 - 77, "whole_net": gain * 100 - 77}
    return {"state": state, "decision": decision, "point": point}


def fixture() -> tuple[dict, dict, dict]:
    """一玉の起動・警戒・hit・要求・不利な次行約定を作る。

    引数: なし。
    返り値: tuple[dict,dict,dict]は人工口座・実玉・保護監査。
    """
    source = {"method": "人工", "signal_id": "出生"}
    activation = step(20, 2, 1, "pre_fill", 20)
    hit = step(29, 3, 3, "pre_fill", 10)
    request = step(29, 3, 4, "after_source", 10)
    closed = {"time": 30, "index": 4, "bid": 105, "ask": 110}
    position = {"id": "玉", "source": source, "source_hold_id": "元玉", "side": 1, "initial_quantity": 1, "entry_quote": {"time": 10, "index": 1}, "entry_price": 100, "closed_quote": closed, "realized_net": 423, "protection_active": True}
    order = {"id": "返済注文", "kind": "exit", "status": "filled", "fill_id": "返済約定", "position_id": "玉", "quantity": 1, "protection_point": request["point"], "request_quote": request["point"]["quote"], "native_close_notice_id": "", "native_close_signal_id": ""}
    fill = {"id": "返済約定", "order_id": "返済注文", "position_id": "玉", "action": "close", "source": source, "source_hold_id": "元玉", "quantity": 1, "quote": closed, "price": 105, "reason": "G3人工追尾", "allocations": [{"position_id": "玉", "quantity": 1, "net_yen": 423}]}
    events = [{"kind": "close_notice", "method": "人工", "hold_id": "元玉", "quote": {"time": at, "index": index}} for at, index in ((25, 2), (40, 5))]
    book = {"orders": [order], "fills": [fill], "source_events": events}
    audit = {"position_id": "玉", "activation": activation, "first_narrow": activation, "first_floor_hit": hit, "last_floor_update": activation, "last_step": hit, "last": {"narrowed": True}, "requests": [{"order_id": "返済注文", "requested": 1, "step": request}]}
    return copy.deepcopy((book, position, audit))


class 診断検査(unittest.TestCase):
    """少数保存点から言える範囲を確認する。"""

    def test_三値の警戒を維持する(self) -> None:
        """未知を偽へ置き換えず偽ANDと真ORの確定だけを許す。

        引数: self(診断検査)。返り値: None。
        """
        self.assertEqual(D.truth_and(0, 1), 1)
        self.assertEqual(D.truth_and(0, 2), 0)
        self.assertEqual(D.truth_or(0, 2), 2)
        self.assertEqual(D.truth_or(0, 1), 0)
        value = step(20, 2, 1, "pre_fill", 20)
        self.assertEqual(D.warning(value), "M2/C2/P1/W2")
        value["state"]["latest_publication"] = None
        value["decision"].update(p=0, warning=0)
        self.assertEqual(D.warning(value), "M0/C0/P0/W0")
        value["decision"]["warning"] = 1
        with self.assertRaises(ValueError):
            D.warning(value)

    def test_床等値と過去由来の不明を分ける(self) -> None:
        """起動・実床更新の出典がなければ現候補を過去の原因としない。

        引数: self(診断検査)。返り値: None。
        """
        _, _, audit = fixture()
        hit = audit["first_floor_hit"]
        self.assertIn("最低床", D.floor_origin(audit, hit))
        self.assertIn("峰−幅", D.floor_origin(audit, hit))
        hit["state"].update(floor_points=60, peak_points=70, width_points=20)
        self.assertEqual(D.floor_origin(audit, hit), "既床保持・起点不明")
        future = step(30, 4, 5, "pre_fill", 80, 60)
        future["state"].update(peak_points=80, width_points=20)
        audit["last_floor_update"] = future
        self.assertEqual(D.floor_origin(audit, hit), "既床保持・起点不明")
        future["state"]["sequence"] = 2
        self.assertEqual(D.floor_origin(audit, hit), "峰−幅（保存最終床更新）")

    def test_Source退出後通知を除き実要求と約定差を残す(self) -> None:
        """実玉生存中の通知だけを選び、要求後の不利な実fillを隠さない。

        引数: self(診断検査)。返り値: None。
        """
        book, position, audit = fixture()
        exits, notices = D.exit_records(book, position, audit)
        self.assertEqual(len(notices), 1)
        self.assertEqual(notices[0]["quote"]["time"], 25)
        self.assertEqual(exits[0]["要求から約定秒"], 1)
        self.assertEqual(exits[0]["要求時から実約定の方向差pt"], -5)
        self.assertEqual(exits[0]["実現円"], 423)
        book["fills"][0]["allocations"][0]["net_yen"] += 1
        with self.assertRaises(ValueError):
            D.exit_records(book, position, audit)

    def test_同秒の最終約定後通知を除く(self) -> None:
        """秒が同じでも原行index又は段階が後なら生存中通知に入れない。

        引数: self(診断検査)。返り値: None。
        """
        book, position, audit = fixture()
        book["source_events"] = [{"kind": "close_notice", "method": "人工", "hold_id": "元玉", "quote": {"time": 30, "index": index}} for index in (3, 4, 5)]
        _, notices = D.exit_records(book, position, audit)
        self.assertEqual([row["quote"]["index"] for row in notices], [3])

    def test_経過と実現差を保存条件へ結合する(self) -> None:
        """警戒・床・実現差の関連を手製経過で確認し未保存tickを要求しない。

        引数: self(診断検査)。返り値: None。
        """
        book, position, audit = fixture()
        row = D.diagnose(book, position, {"realized_net": 1000}, audit, "人工場", "G3")
        self.assertTrue(row["両勝後減益"])
        self.assertEqual(row["差円"], -577)
        self.assertEqual(row["分布素材"]["起動から初hit秒"], 9)
        self.assertEqual(row["狭幅分類"], "起動時に警戒狭幅")
        self.assertEqual(row["初hitのV比較"], "現V<新規V")
        self.assertIn("起動＋警戒狭幅", row["経過"])
        self.assertIn("初実返済＋全実返済", row["経過"])
        summary = D.aggregate([row])
        self.assertEqual(summary["玉"], 1)
        self.assertEqual(summary["差円"], -577)


if __name__ == "__main__":
    unittest.main(verbosity=2)
