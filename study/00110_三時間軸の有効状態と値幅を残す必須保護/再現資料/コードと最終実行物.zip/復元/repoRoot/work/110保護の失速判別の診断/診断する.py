"""110の保存保護点と実返済を結び、失速判別の次の仮説を作る。"""

from collections import Counter, defaultdict
from decimal import Decimal
import importlib.util
import json
from pathlib import Path
import statistics


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
COMPARISON = ROOT / "work/110出口の同入口比較_準備/全70の解析.json"
COMPARISON_SHA = "399a1c5f8ab2fe4df4a5bf9776342e3adcc032c437b03fd980a90c2befb59dc3"
COMPLETE = ROOT / "work/110市場/全70場_中断後の同条件再実行/完了.json"
COMPLETE_SHA = "bf95d74bc04953643606884c432c41ff14854792aee642bb15a75effd66f1539"
SAVED = ROOT / "work/110保存/全70場_中断後の同条件再実行/結果.json"
SAVED_SHA = "b748f75b9bea0e43a404b4ff52530cf7ea68d1ce30e59f7c8559a31df2dff10b"
STOP = ROOT / "work/110出口の同入口比較_準備/停止.json"
STOP_SHA = "26ecd5d6812018b5172529646a638d04de93286b5f83b1228c34e9d930bfaf1b"
ZERO = Decimal(0)
TOLERANCE = Decimal("0.00000001")


def prepare_comparison():
    """停止済み同入口比較器だけを指紋認証して読み込む。

    引数: なし。
    返り値: moduleは実市場を既定実行しない比較器。
    """
    import hashlib
    assert hashlib.sha256(STOP.read_bytes()).hexdigest() == STOP_SHA
    stop = json.loads(STOP.read_text(encoding="utf-8"))
    path = ROOT / "work/110出口の同入口比較_準備/比較する.py"
    assert hashlib.sha256(path.read_bytes()).hexdigest() == stop["所有SHA256"][str(path)]
    specification = importlib.util.spec_from_file_location("同入口110", path)
    module = importlib.util.module_from_spec(specification)
    specification.loader.exec_module(module)
    return module


A = prepare_comparison()


def close(a: Decimal | int, b: Decimal | int) -> bool:
    """保存浮動小数点のごく小さい誤差だけを許容する。

    引数: a/b(Decimal又はint)は比較値。
    返り値: boolは絶対差が1e-8以下のとき真。
    """
    return abs(a - b) <= TOLERANCE


def truth_and(a: int, b: int) -> int:
    """未知0・偽1・真2のANDを独立に評価する。

    引数: a/b(int)は三値論理。
    返り値: intは三値結果。偽は未知より先に確定する。
    """
    A.need(a in (0, 1, 2) and b in (0, 1, 2), "三値の定義域")
    return 1 if 1 in (a, b) else 0 if 0 in (a, b) else 2


def truth_or(a: int, b: int) -> int:
    """未知0・偽1・真2のORを独立に評価する。

    引数: a/b(int)は三値論理。
    返り値: intは三値結果。真は未知より先に確定する。
    """
    A.need(a in (0, 1, 2) and b in (0, 1, 2), "三値の定義域")
    return 2 if 2 in (a, b) else 0 if 0 in (a, b) else 1


def stamp(quote: dict, phase: str = "") -> tuple:
    """保存時刻・原行index・明示段階を順序の根拠へまとめる。

    引数: quote(dict)は保存気配、phase(str)はpre_fill等。
    返り値: tupleは時計・index・段階の順序キー。
    """
    ranks = {"pre_fill": 0, "fill": 1, "source_close": 2, "after_source": 3, "request": 3}
    return quote["time"], quote["index"], ranks.get(phase, 0)


def warning(step: dict | None) -> str:
    """保存M・Cと現在支持Pを三値のまま独立に結ぶ。

    引数: step(dict又はNone)は保存された保護点。
    返り値: strはM/C/P/警戒の組。未知を偽へ置換しない。
    """
    if step is None:
        return "保存点なし"
    state, decision, point = step["state"], step["decision"], step["point"]
    publication = state["latest_publication"]
    if publication is None:
        c, m, p = 0, 0, 0
    else:
        A.need(publication["available_at"] <= point["quote"]["time"], "警戒点より未来の公表を使わない")
        c, m = publication["c"], publication["m"]
        if publication["close"] is None or publication["prior_pivot"] is None:
            p = 0
        else:
            p = 2 if state["entry"]["side"] * (publication["close"] - publication["prior_pivot"]["price"]) < 0 else 1
    w = truth_and(m, truth_or(c, p))
    A.need(decision["p"] == p and decision["warning"] == w, "M AND(C OR P)の保存判定")
    return f"M{m}/C{c}/P{p}/W{w}"


def floor_candidates(step: dict) -> dict:
    """保存点での床と最低床・峰幅・構造床の等値候補を示す。

    引数: step(dict)は起動済み保存点。
    返り値: dictは整合候補と値。過去に作られた床の由来を捏造しない。
    """
    state, decision = step["state"], step["decision"]
    floor = state["floor_points"]
    A.need(state["active"] and floor is not None, "床診断は起動済み点")
    candidates = {"最低床": state["minimum_floor"]}
    if state["width_points"] is not None:
        candidates["峰−幅"] = state["peak_points"] - state["width_points"]
    if decision["structural_floor"] is not None:
        candidates["構造床"] = decision["structural_floor"]
    A.need(floor + TOLERANCE >= max(candidates.values()), "床は現在候補以上")
    equal_names = sorted(name for name, value in candidates.items() if close(value, floor))
    return {"床pt": floor, "候補pt": candidates, "床と等値の候補": equal_names, "既床保持のみ": not equal_names}


def floor_origin(audit: dict, hit: dict | None) -> str:
    """初回床hitの由来を、同じ床の起動又は床更新保存点から識別する。

    引数: audit(dict)は玉別少数監査、hit(dict又はNone)は初回hit。
    返り値: strは識別済み由来又は証拠不足。現時点の等値だけを因果としない。
    """
    if hit is None:
        return "床hitなし"
    matches = []
    for name in ("activation", "last_floor_update"):
        step = audit[name]
        if step is not None and step["state"]["sequence"] <= hit["state"]["sequence"] and close(step["state"]["floor_points"], hit["state"]["floor_points"]):
            matches.append((step["state"]["sequence"], name, step))
    if matches:
        _, name, step = max(matches, key=lambda item: item[0])
        signature = floor_candidates(step)
        A.need(bool(signature["床と等値の候補"]), "起動又は実床更新には現在候補の起点が必要")
        return "+".join(signature["床と等値の候補"]) + ("（初回起動）" if name == "activation" else "（保存最終床更新）")
    signature = floor_candidates(hit)
    return "既床保持・起点不明" if signature["既床保持のみ"] else "現候補:" + "+".join(signature["床と等値の候補"]) + "・過去起点不明"


def summary_distribution(values: list) -> dict:
    """実際に保存された既知値だけの小さい分布を作る。

    引数: values(list)は既知数値。未知は事前に除いて別件数を記す。
    返り値: dictは件数・最小・中央値・最大。
    """
    return {"n": len(values), "min": min(values), "median": statistics.median(values), "max": max(values)} if values else {"n": 0}


def exit_records(book: dict, position: dict, audit: dict) -> tuple[list[dict], list[dict]]:
    """実玉の返済要求・実fill・返済配分を所有へ結合する。

    引数: book/position/audit(dict)は実口座・完結玉・保護監査。
    返り値: tuple[list,list]は実返済と実生存期間内のSource通知。
    """
    orders = A.keyed(book["orders"], "id")
    self_orders = {item["order_id"]: item for item in audit["requests"]}
    records, allocated = [], ZERO
    for fill in book["fills"]:
        if fill["action"] == "new" or fill["position_id"] != position["id"]:
            continue
        order = orders[fill["order_id"]]
        A.need(order["kind"] == "exit" and order["status"] == "filled" and order["fill_id"] == fill["id"], "返済の要求からfillへの結合")
        A.need(order["position_id"] == position["id"] and fill["source"] == position["source"] and fill["source_hold_id"] == position["source_hold_id"], "返済の元玉所有")
        allocations = [item for item in fill["allocations"] if item["position_id"] == position["id"]]
        A.need(sum(item["quantity"] for item in allocations) == fill["quantity"], "実返済枚数と所有配分")
        net = sum((item["net_yen"] for item in allocations), ZERO)
        allocated += net
        if order["id"] in self_orders:
            category = "自己保護"
            request = self_orders[order["id"]]
            A.need(request["requested"] == order["quantity"] and request["step"]["point"] == order["protection_point"], "自己保護の実予約結合")
            warning(request["step"])
        elif order["native_close_notice_id"] or order["native_close_signal_id"]:
            category = "Source返済"
        else:
            category = "その他"
        request_quote, fill_quote = order["request_quote"], fill["quote"]
        A.need(stamp(request_quote, "request") < stamp(fill_quote, "fill"), "実要求は後続原行で約定")
        request_mark = request_quote["bid"] if position["side"] > 0 else request_quote["ask"]
        records.append({"分類": category, "理由": fill["reason"], "要求気配": request_quote, "実約定気配": fill_quote, "枚数": fill["quantity"], "実現円": net, "要求から約定秒": fill_quote["time"] - request_quote["time"], "要求から約定原行差": fill_quote["index"] - request_quote["index"], "要求時から実約定の方向差pt": position["side"] * (fill["price"] - request_mark), "自己保護点": self_orders[order["id"]]["step"] if category == "自己保護" else None})
    records.sort(key=lambda item: stamp(item["実約定気配"], "fill"))
    A.need(sum(item["枚数"] for item in records) == position["initial_quantity"] and allocated == position["realized_net"], "全返済数量・費用後実現額の同体")
    alive_end = stamp(position["closed_quote"], "fill")
    notices = [event for event in book["source_events"] if event["kind"] == "close_notice" and event["method"] == position["source"]["method"] and event["hold_id"] == position["source_hold_id"] and stamp(event["quote"], "source_close") <= alive_end]
    notices.sort(key=lambda item: stamp(item["quote"], "source_close"))
    return records, notices


def point_view(step: dict | None) -> dict | None:
    """少数保存点から診断に必要な値だけを抜き出す。

    引数: step(dict又はNone)は保存点。
    返り値: dict又はNoneは時計・H/A/V・警戒・床・実評価。
    """
    if step is None:
        return None
    s, d, p = step["state"], step["decision"], step["point"]
    latest = s["latest_publication"]
    return {"時刻": p["quote"]["time"], "原行index": p["quote"]["index"], "段階": p["phase"], "sequence": s["sequence"], "Hpt": s["threshold_points"] if s["threshold_known"] else None, "Apt": s["atr"]["value"] if s["atr"] else None, "新規Vpt": s["entry"]["entry_v"]["value"] if s["entry"]["entry_v"] else None, "現Vpt": latest["v"] if latest else None, "警戒": warning(step), "狭幅化済み": s["narrowed"], "幅pt": s["width_points"], "幅由来": d["width_source"], "方向幅pt": p["gain_points"], "費用後単位円": p["unit_net"], "実玉清算円": p["whole_net"], "残枚数": p["quantity"], "予約枚数": p["reserved"], "床": floor_candidates(step) if s["active"] else None}


def diagnose(book: dict, position: dict, baseline: dict, audit: dict, session: str, policy: str) -> dict:
    """保存少数点と実約定だけで一玉の経過と条件を診断する。

    引数: book/position/baseline/audit(dict)は実口座・新保護玉・同入口G0玉・監査、session/policy(str)は識別。
    返り値: dictは小さい診断値。未保存tick又は15/30分を補完しない。
    """
    activation, narrow, hit = audit["activation"], audit["first_narrow"], audit["first_floor_hit"]
    for name in ("activation", "first_narrow", "first_floor_hit", "last_floor_update", "last_step"):
        if audit[name] is not None:
            warning(audit[name])
    A.need(position["protection_active"] == (activation is not None), "実玉と監査の起動同体")
    A.need(audit["last"]["narrowed"] == (narrow is not None), "初狭幅と最終旗")
    exits, notices = exit_records(book, position, audit)
    timeline = []
    for label, step in (("起動", activation), ("警戒狭幅", narrow), ("初床hit", hit)):
        if step is not None:
            timeline.append((stamp(step["point"]["quote"], step["point"]["phase"]), label))
    if notices:
        timeline.append((stamp(notices[0]["quote"], "source_close"), "Source返済通知"))
    for category in sorted({item["分類"] for item in exits}):
        item = next(item for item in exits if item["分類"] == category)
        timeline.append((stamp(item["要求気配"], "request"), category + "要求"))
    timeline.append((stamp(exits[0]["実約定気配"], "fill"), "初実返済"))
    timeline.append((stamp(exits[-1]["実約定気配"], "fill"), "全実返済"))
    simultaneous = defaultdict(list)
    for key, label in timeline:
        simultaneous[key].append(label)
    timeline_text = "→".join("＋".join(simultaneous[key]) for key in sorted(simultaneous))
    if activation is None:
        narrow_state = "未起動"
    elif narrow is None:
        narrow_state = "起動後の警戒狭幅なし"
    elif narrow["state"]["sequence"] == activation["state"]["sequence"]:
        narrow_state = "起動時に警戒狭幅"
    else:
        narrow_state = "起動後に警戒狭幅"
    old, new = baseline["realized_net"], position["realized_net"]
    state = activation["state"] if activation is not None else audit["last"]
    lock = state["threshold_lock"]
    fields = {"Hpt": state["threshold_points"] if state["threshold_known"] else None, "Apt": state["atr"]["value"] if state["atr"] else None, "新規Vpt": state["entry"]["entry_v"]["value"] if state["entry"]["entry_v"] else None, "起動時Vpt": activation["state"]["latest_publication"]["v"] if activation is not None and activation["state"]["latest_publication"] else None, "起動幅pt": activation["state"]["width_points"] if activation is not None else None, "起動から初hit秒": hit["point"]["quote"]["time"] - activation["point"]["quote"]["time"] if hit is not None and activation is not None else None, "起動から全返済秒": position["closed_quote"]["time"] - activation["point"]["quote"]["time"] if activation is not None else None}
    first_self = next((item for item in exits if item["分類"] == "自己保護"), None)
    hit_view = point_view(hit)
    result = {"session": session, "policy": policy, "Source手法": position["source"]["method"], "SourceSignalID": position["source"]["signal_id"], "方向": position["side"], "枚数": position["initial_quantity"], "新規時刻": position["entry_quote"]["time"], "新規価格": position["entry_price"], "実現G0円": old, "実現新保護円": new, "差円": new - old, "勝敗遷移": A.outcome(old) + "→" + A.outcome(new), "両勝後減益": old > 0 and new > 0 and new < old, "起動後赤字": activation is not None and new < 0, "起動": activation is not None, "狭幅分類": narrow_state, "起動警戒": warning(activation), "初hit警戒": warning(hit), "初hit床由来": floor_origin(audit, hit), "初hitで予約あり": hit is not None and hit["point"]["reserved"] > 0, "初hitで全予約": hit is not None and hit["point"]["reserved"] == hit["point"]["quantity"], "生存中Source通知": bool(notices), "実close分類": "+".join(sorted({item["分類"] for item in exits})), "実close理由": sorted({item["理由"] for item in exits}), "経過": timeline_text, "H支配項": "+".join(lock["dominant_terms"]) if lock else "H未確定", "分布素材": fields, "起動点": point_view(activation), "初狭幅点": point_view(narrow), "初hit点": hit_view, "初自己要求点": point_view(first_self["自己保護点"]) if first_self else None, "実要求から約定": [{key: value for key, value in item.items() if key not in ("自己保護点", "要求気配", "実約定気配")} | {"要求時刻": item["要求気配"]["time"], "要求index": item["要求気配"]["index"], "約定時刻": item["実約定気配"]["time"], "約定index": item["実約定気配"]["index"]} for item in exits]}
    if hit_view and hit_view["新規Vpt"] is not None and hit_view["現Vpt"] is not None:
        result["初hitのV比較"] = "現V<新規V" if hit_view["現Vpt"] < hit_view["新規Vpt"] else "現V>=新規V"
    else:
        result["初hitのV比較"] = "比較不明又はhitなし"
    result["起動時W区分"] = "未起動" if activation is None else "W正" if activation["point"]["whole_net"] > 0 else "W非正"
    result["狭幅と初hitの順"] = "hitなし" if hit is None else "狭幅なし" if narrow is None else "同step" if narrow["state"]["sequence"] == hit["state"]["sequence"] else "狭幅が先" if narrow["state"]["sequence"] < hit["state"]["sequence"] else "初hitが先"
    return result


def aggregate(rows: list[dict]) -> dict:
    """実現差と保存条件の分布だけを期間内で集計する。

    引数: rows(list[dict])は同政策又は明示した条件付き群。
    返り値: dictは件数・実額・少数分布。群の重複を独立標本としない。
    """
    numeric = {name: sum((row[name] for row in rows), ZERO) for name in ("枚数", "実現G0円", "実現新保護円", "差円")}
    numeric.update(玉=len(rows), 起動=sum(row["起動"] for row in rows), 起動後赤字=sum(row["起動後赤字"] for row in rows), 両勝後減益=sum(row["両勝後減益"] for row in rows), 新保護損失総額円=sum((min(ZERO, row["実現新保護円"]) for row in rows), ZERO), 初hit予約あり=sum(row["初hitで予約あり"] for row in rows), 初hit全予約=sum(row["初hitで全予約"] for row in rows))
    numeric.update(両勝後減益差円=sum((row["差円"] for row in rows if row["両勝後減益"]), ZERO), 起動後赤字実現円=sum((row["実現新保護円"] for row in rows if row["起動後赤字"]), ZERO), 起動時W非正玉=sum(row["起動時W区分"] == "W非正" for row in rows))
    numeric["分布"] = {name: summary_distribution([row["分布素材"][name] for row in rows if row["分布素材"][name] is not None]) for name in ("Hpt", "Apt", "新規Vpt", "起動時Vpt", "起動幅pt", "起動から初hit秒", "起動から全返済秒")}
    numeric["経過別玉数"] = dict(Counter(row["経過"] for row in rows))
    numeric["実close理由別玉数"] = dict(Counter(reason for row in rows for reason in row["実close理由"]))
    return numeric


def main() -> None:
    """解禁済み全70の保存点だけを再読して小型の実診断を作る。

    引数: なし。Rootの成功Refと期待SHAは定数で固定する。
    返り値: None。金融・公表器・全tickを再走せず、110条件を変更しない。
    """
    output = OWN / "診断_確定.json"
    A.need(not output.exists(), "診断は上書きしない")
    comparison, complete, saved = A.load(COMPARISON, COMPARISON_SHA), A.load(COMPLETE, COMPLETE_SHA), A.load(SAVED, SAVED_SHA)
    A.need(comparison["成功"] and comparison["全比較で入口同体"] and comparison["比較数"] == 24 and comparison["場別比較数"] == 1680, "同入口解析全体成功")
    A.need(complete["success"] and complete["stage"] == "full70" and complete["sessions"] == 70 and complete["books"] == 2520 and complete["baseline_comparisons"] == 280, "110金融全70成功")
    A.need(saved["成功"] and saved["場数"] == 70 and saved["会計数"] == 2520 and saved["金融完了SHA256"] == COMPLETE_SHA and saved["金融条件SHA256"] == A.CONDITION_SHA, "独立保存と同条件")
    inputs = {str(COMPARISON): COMPARISON_SHA, str(COMPLETE): COMPLETE_SHA, str(SAVED): SAVED_SHA, str(STOP): STOP_SHA, str(Path(A.__file__)): A.sha(Path(A.__file__)), str(Path(__file__).resolve()): A.sha(Path(__file__).resolve())}
    all_rows = []
    for index, task in enumerate(complete["results"]):
        sid, ref = task["session"], task["native"]
        A.need("2026-09-21" <= sid[:10] <= "2026-11-06" and ref == saved["Native参照"][index]["native"], "既使用70Nativeだけ")
        path = Path(ref["path"])
        native = A.load(path, ref["sha256"])
        inputs[str(path)] = ref["sha256"]
        baseline, fingerprints = A.validate_book(native["books"]["entry_E0_G0_C0_D0"])
        for policy in ("G3", "G4"):
            key = f"entry_E0_{policy}_C0_D0"
            book = native["books"][key]
            positions, current = A.validate_book(book)
            A.need(fingerprints == current, "E0の実入口全文同体")
            audits = A.keyed(native["composite_audits"][key]["positions"], "position_id")
            A.need(set(audits) == {position["id"] for position in positions.values()}, "実玉と保護監査の全所有")
            for identity, position in positions.items():
                all_rows.append(diagnose(book, position, baseline[identity], audits[position["id"]], sid, policy))
        print(sid, "保存保護と実返済を結合", flush=True)
    totals, conditions, outcomes = {}, {}, {}
    for policy in ("G3", "G4"):
        rows = [row for row in all_rows if row["policy"] == policy]
        totals[policy] = aggregate(rows)
        expected = comparison["全条件"][f"entry_E0_G0対{policy}_C0_D0"]["全体"]
        A.need(totals[policy]["玉"] == expected["前"]["玉"] and totals[policy]["実現G0円"] == expected["前"]["実現円"] and totals[policy]["実現新保護円"] == expected["後"]["実現円"] and totals[policy]["差円"] == expected["実現差円"], "診断全実現額と同入口解析の一致")
        outcomes[policy] = {name: aggregate([row for row in rows if condition(row)]) for name, condition in (("両勝で後減益", lambda row: row["両勝後減益"]), ("起動後赤字", lambda row: row["起動後赤字"]), ("起動した玉", lambda row: row["起動"]), ("未起動の玉", lambda row: not row["起動"]))}
        conditions[policy] = {}
        for field in ("狭幅分類", "起動警戒", "初hit警戒", "初hit床由来", "実close分類", "H支配項", "初hitのV比較", "起動時W区分", "狭幅と初hitの順"):
            conditions[policy][field] = {name: aggregate([row for row in rows if row[field] == name]) for name in sorted({row[field] for row in rows})}
    examples = [row for row in all_rows if row["起動後赤字"]]
    for policy in ("G3", "G4"):
        examples.extend(sorted([row for row in all_rows if row["policy"] == policy and row["両勝後減益"]], key=lambda row: (row["差円"], row["session"], row["SourceSignalID"]))[:3])
    A.need(all(A.sha(Path(path)) == expected for path, expected in inputs.items()), "診断入力とcodeの前後不変")
    result = {"試行": 110, "成功": True, "対象": "E0/L0・G0対G3/G4・C0D0、既使用全70。保存少数点と実返済の診断", "同入口解析": {"path": str(COMPARISON), "sha256": COMPARISON_SHA}, "金融完了": {"path": str(COMPLETE), "sha256": COMPLETE_SHA}, "独立保存": {"path": str(SAVED), "sha256": SAVED_SHA}, "入力SHA256": inputs, "前後不変": True, "全体": totals, "結果による条件付き群": outcomes, "観測条件別": conditions, "少数の実玉例": examples, "事実と仮説の区別": "観測条件別は事後診断であり切替規則の有効性ではない。未保存の足や新閾値を補完していない", "限界": ["監査は初回起動・初狭幅・初床hit・保存最終床更新・最終step・自己要求の少数点だけで全tick履歴ではない", "警戒が未起動中に初めて成立した時刻は復元できず、初狭幅は起動後に作用した最初の警戒である", "床hit時の床由来は、同じ床を生成した起動又は保存最終更新がhit以前にある場合だけ識別。現候補の等値だけで過去の由来を断定しない", "Source通知は実玉が生存していた最終実約定までだけを対象とする。退出後の通知・価格を評価しない", "H支配項や警戒状態の群別実現差は条件付き事後関連であり、技術的切替又は因果効果の実証ではない", "15/30分の未知情報を補完せず、値幅・警戒の全tick又は技法を再形成しない", "未参加又は退出後の仮想利益・機会損失・MFE回収率は計算しない", "全70は既使用探索。11月09日未読、未見安定性・採用・研究目標達成は未証明"]}
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, default=A.serial, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"成功": True, "診断": str(output), "sha256": A.sha(output), "bytes": output.stat().st_size, "全体": totals}, ensure_ascii=False, default=A.serial))


if __name__ == "__main__":
    main()
