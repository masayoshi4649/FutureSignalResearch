"""診断の人工検査・小型実証拠・表示修正の同体を固定する。"""

from pathlib import Path
import ast
import hashlib
import json
import subprocess
import sys


OWN = Path(__file__).resolve().parent
FINAL_SHA = "4cd3d61e33a5d584ec5b17920a4d337e969332ca2a8688d5edce958dc89c462f"


def digest(path: Path) -> str:
    """コード・診断JSON・説明の全バイトを同定する。

    引数: path(Path)は非価格ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def subset(old: object, new: object) -> bool:
    """表示とコード指紋以外の旧診断値が確定版へそのまま残ることを調べる。

    引数: old/new(object)はJSON値。
    返り値: boolは旧値の同体。新規の条件別診断列だけは追加を許す。
    """
    if isinstance(old, dict):
        return isinstance(new, dict) and all(key in new and subset(value, new[key]) for key, value in old.items() if key not in ("経過", "経過別玉数", "入力SHA256"))
    if isinstance(old, list):
        return isinstance(new, list) and len(old) == len(new) and all(subset(a, b) for a, b in zip(old, new))
    return old == new


def main() -> None:
    """人工5主と確定診断の指紋を確認し、既存金融を変更せず停止する。

    引数: なし。
    返り値: None。Native・市場・価格CSVを再読しない。
    """
    destination = OWN / "停止と実診断の確認.json"
    assert not destination.exists()
    final_path = OWN / "診断_確定.json"
    assert digest(final_path) == FINAL_SHA
    final = json.loads(final_path.read_text(encoding="utf-8"))
    assert final["成功"] and final["前後不変"]
    for policy, expected in (("G3", (466, 979, 202, 2, 983617)), ("G4", (466, 979, 177, 1, 1378617))):
        value = final["全体"][policy]
        assert tuple(value[name] for name in ("玉", "枚数", "起動", "起動後赤字", "実現新保護円")) == expected
    paths = sorted(OWN.glob("*.py")) + [OWN / "README.md"]
    before = {str(path): digest(path) for path in paths}
    functions = 0
    for path in OWN.glob("*.py"):
        for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                doc = ast.get_docstring(node)
                assert doc and "\n" in doc and "引数:" in doc and "返り値:" in doc
                functions += 1
    source_path = OWN / "診断する.py"
    assert final["入力SHA256"][str(source_path)] == digest(source_path)
    run = subprocess.run([sys.executable, "-B", "-X", "utf8", str(OWN / "診断の人工検査.py")], capture_output=True, text=True, encoding="utf-8", check=False)
    assert run.returncode == 0, run.stdout + run.stderr
    histories = []
    for old_name, old_sha, code_name in (("診断.json", "9bd8475e332db5b7fc43fa10c011440d5016356aff4384a0c081dfb0e7a4b8a3", "診断する_同時点を未結合.py"), ("診断_同時点を併記.json", "255f48ac551d88fb80ea637ed7fac13eaf4c62245e343779af691b553e556ef5", "診断する_同時点を併記.py")):
        old_path = OWN / old_name
        assert digest(old_path) == old_sha
        old = json.loads(old_path.read_text(encoding="utf-8"))
        historical_code = OWN / "履歴" / code_name
        assert old["入力SHA256"][str(source_path)] == digest(historical_code)
        assert subset(old, final)
        histories.append({"path": str(old_path), "sha256": old_sha, "実額と旧診断列の同体": True, "履歴コード": {"path": str(historical_code), "sha256": digest(historical_code)}})
    after = {str(path): digest(path) for path in paths}
    assert before == after and digest(final_path) == FINAL_SHA
    proof = {"試行": 110, "成功": True, "停止": True, "所有コードと説明SHA256": before, "関数コメント確認数": functions, "自己コード前後不変": before == after, "人工主検査": 5, "人工終了コード": run.returncode, "人工出力": run.stderr, "確定診断": {"path": str(final_path), "sha256": FINAL_SHA, "bytes": final_path.stat().st_size}, "元Ref": {name: final[name] for name in ("同入口解析", "金融完了", "独立保存")}, "過程の履歴": histories, "修正": "同保存点のラベルを文字順で前後へ分けず＋併記した。条件別の両勝減益額と起動時W区分も追加。旧実現額・玉数・床等の全数値は同体", "正式保存に必要な結果": ["診断_確定.json", "README.md", "停止と実診断の確認.json"], "途中履歴の正式重複保存": False, "金融条件又は算法の変更": False, "市場金融再実行": False, "全tick又は指標再形成": False, "検査器でのNative本文再読": False, "11月09日読取": False}
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(proof, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "確認": str(destination), "sha256": digest(destination), "確定診断SHA256": FINAL_SHA}, ensure_ascii=False))


if __name__ == "__main__":
    main()
