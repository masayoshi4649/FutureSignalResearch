"""固定済みの算法・入力を保ち、停止確認後の新規出力要求だけを作る。"""

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
ORIGINAL_SHA = "b86890523ea47fb2bcbf344eef20715d7437af6545a4417e296bb99f8962f848"
CONDITION_SHA = "e0f84c5f836a3cb58b6d75c12f08c40e910b661043516e1e642143b6026b9fba"


def digest(path: Path) -> str:
    """明示した非価格ファイルの全バイト指紋を算出する。

    引数: path(Path)はコード・metadata又は既生成の圧縮成果物。
    返り値: strはSHA256。市場・価格本文は開かない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path: Path, value: dict) -> None:
    """既存ファイルを上書きせずUTF-8のmetadataを作る。

    引数: path(Path)は未使用先、value(dict)は保存metadata。
    返り値: None。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def ref(path: Path) -> dict:
    """明示した非価格ファイルの出典参照を作る。

    引数: path(Path)は現存する非価格ファイル。
    返り値: dictは絶対path・SHA256・容量。
    """
    return {"path": str(path), "sha256": digest(path), "bytes": path.stat().st_size}


def main() -> None:
    """停止確認の履歴と、出力先だけを変えた純頻度要求を保存する。

    引数: なし。Rootが確認したhandle欠落・OSプロセス不在を履歴として記す。
    返り値: None。市場計算・既存出力変更・CLI起動は行わない。
    """
    original = ROOT / "work/110頻度要求/全70場.json"
    condition = ROOT / "study/00110_三時間軸の有効状態と値幅を残す必須保護/金融条件_停止形式整合.json"
    assert digest(original) == ORIGINAL_SHA and digest(condition) == CONDITION_SHA
    old_request = json.loads(original.read_text(encoding="utf-8"))
    changed = json.loads(original.read_text(encoding="utf-8"))
    old_frequency = ROOT / "work/110頻度/全70場"
    old_finance = ROOT / "work/110市場/全70場_停止形式整合"
    new_frequency = ROOT / "work/110頻度/全70場_中断後の同条件再実行"
    new_finance = ROOT / "work/110市場/全70場_中断後の同条件再実行"
    assert not (old_frequency / "完成.json").exists()
    assert not (old_finance / "完了.json").exists()
    assert not new_frequency.exists()
    changed["output_dir"] = str(new_frequency)
    assert old_request["output_dir"] == str(old_frequency)
    changed_keys = sorted(key for key in changed if changed[key] != old_request[key])
    assert changed_keys == ["output_dir"] and set(changed) == set(old_request)
    request_path = HERE / "純頻度要求_中断後の同条件再実行.json"
    write_new(request_path, changed)
    finance_files = sorted(old_finance.glob("*.Native.json.gz"))
    frequency_files = sorted(old_frequency.glob("*.json.gz"))
    record = {
        "試行": 110,
        "記録UTC": datetime.now(timezone.utc).isoformat(),
        "成功完了認定": False,
        "中断の確認": {
            "金融handle": 5394,
            "頻度handle": 88429,
            "Rootによる再poll結果": "両方Unknown process id",
            "RootによるOS確認": "Win32_Processで110市場.exe・110頻度.exeはいずれも不在",
            "成功完了metadata": "金融の完了.json・頻度の完成.jsonはいずれも不在",
            "終了コード": None,
            "原因": "未確定。観測だけで正常終了又は失敗終了を推定しない",
        },
        "未完了の旧出力": {
            "金融": {"path": str(old_finance), "ファイル数": len(finance_files), "一覧": [ref(p) for p in finance_files]},
            "頻度": {"path": str(old_frequency), "ファイル数": len(frequency_files), "一覧": [ref(p) for p in frequency_files]},
            "扱い": "部分成果物として保持。完成・全期間結果としない。新規実行へ混入しない",
        },
        "元頻度要求": ref(original),
        "新頻度要求": ref(request_path),
        "要求変更キー": changed_keys,
        "同一金融条件": ref(condition),
        "新金融出力": str(new_finance),
        "新金融出力の状態": "監査中にRootが同条件で再起動し作成済み" if new_finance.exists() else "未作成",
        "保全": {
            "算法変更": False,
            "固定条件変更": False,
            "入力又はfirst2変更": False,
            "旧ファイル変更": False,
            "Raw又は価格本文読取": False,
            "11月09日入力読取": False,
            "新規出力作成又は起動": False,
        },
        "再開可否": "両CLIは既存出力フォルダを拒否し、部分結果を再用する機能なし。未使用の新規出力へ同条件で全70再実行する",
        "コード根拠": {
            "金融main": ref(ROOT / "work/110有効状態と値幅保護の市場入出力/main.go"),
            "頻度main": ref(ROOT / "work/110入口の頻度前検査/cmd/observe/main.go"),
            "保存ゲート": ref(ROOT / "work/110有効状態と値幅保護の保存/固定ゲート.py"),
            "旧保存要求生成器": ref(ROOT / "work/110保存要求/作る.py"),
        },
        "後段注意": "旧保存要求生成器は旧金融completionパス固定。変更せず、新派生helper又は明示要求で新成功completionを参照する。保存ゲートはcompletionから各Native参照を解決するため出力フォルダ名の制約なし",
        "生成器": ref(Path(__file__).resolve()),
    }
    write_new(HERE / "中断と同条件再実行の記録.json", record)
    print(json.dumps({"新頻度要求": ref(request_path), "中断記録": ref(HERE / "中断と同条件再実行の記録.json"), "金融部分数": len(finance_files), "頻度部分数": len(frequency_files), "変更キー": changed_keys}, ensure_ascii=False))


if __name__ == "__main__":
    main()
