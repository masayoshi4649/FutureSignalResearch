"""Go型の手製公表だけを停止C/M/P純式へ明示射影する。"""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
PURE_PATH = ROOT / "work/収束可変幅の公開側データ準備/公開値の純評価.py"
PURE_SHA = "2fde62552667cf3e96016ce82ef7bd16d9f036ae8b26dce7f86efa2bec63e97a"
assert hashlib.sha256(PURE_PATH.read_bytes()).hexdigest() == PURE_SHA
spec = importlib.util.spec_from_file_location("fixed_cmp", PURE_PATH)
pure = importlib.util.module_from_spec(spec)
spec.loader.exec_module(pure)

def to_frame(p: dict) -> dict:
    """
    機能: 新Go公表型を固定C/M/PのFrameへ数値形成なしで写す。
    引数: p (dict) は実Go型の公表一件。
    返り値: dict は元値/出典を明示対応した独立Frame。
    """
    s, c = p["snapshot"]["legacy"], p["snapshot"]["closed_three"]
    normalized = deepcopy(s)
    if "Technical" not in normalized["chart"] or "technical" in normalized["chart"]:
        raise ValueError("元Go chart.Technical型ではない")
    normalized["chart"]["technical"] = normalized["chart"].pop("Technical")
    old = {"at": p["at"], "three": p["three"], "fifteen": p["fifteen"], "snapshot": normalized}
    known = {"ema8": c["ema8_known"], "ema21": c["ema21_known"], "hist": c["histogram_known"], "close": c["known"]}
    expected_id = {"session": s["scene"]["id"], "contract": s["scene"]["contract"], "bar_end": c["bar_end"]}
    if p["publication_id"] != expected_id or c["publication_id"] != expected_id:
        raise ValueError("公表IDの出典差")
    ohlc = {**c["ohlc"], "publication_id": pure.identity(expected_id["session"], expected_id["contract"], c["bar_end"])} if c["known"] else None
    frame = pure.from_publication(old, p["publication_ordinal"], known3=known, ohlc=ohlc)
    pure.validate(frame)
    return frame


def main() -> None:
    """
    機能: 手製Go型12公表の当足先取り禁止を検査する。
    引数: なし。
    返り値: None。市場ファイルを開かず新しい型確認receiptを保存する。
    """
    artifact = OWN / "人工_停止版/Go型の人工.json"
    value = json.loads(artifact.read_text(encoding="utf-8"))
    before = deepcopy(value)
    details = []
    for role, rows in value["scenes"].items():
        tracker = pure.Tracker()
        outputs = [tracker.feed(to_frame(p)) for p in rows]
        side_role = "buy" if role == "買い" else "sell"
        assert len(outputs) == 6
        assert outputs[4][side_role]["P"] == {"known": False, "passed": None}
        assert outputs[5][side_role]["P"] == {"known": True, "passed": True}
        assert outputs[5][side_role]["prior_pivot"]["center_end"] == rows[2]["at"]
        assert outputs[5][side_role]["prior_pivot"]["confirm_end"] == rows[4]["at"]
        details.append({"方向": role, "公表": len(outputs), "当足確認の先取り": False, "次足でP成立": True,
                        "最後の純評価": outputs[-1]})
    assert before == value
    receipt = {"成功": True, "scope": "Go型手製12公表→停止純式のC/M/P。市場値/Source/LD10金融なし。",
               "純式SHA256": PURE_SHA, "Go型人工SHA256": hashlib.sha256(artifact.read_bytes()).hexdigest(),
               "details": details, "入力不変": True, "型対応": "実Go chart.Technicalを4a30手製正規型chart.technicalへ1欄だけ値copy。元Go/4a30本文は不変。", "市場本文読取": 0, "金融変更": 0}
    (OWN / "純式の型接続確認.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"成功": True, "方向": len(details), "公表": sum(x["公表"] for x in details)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
