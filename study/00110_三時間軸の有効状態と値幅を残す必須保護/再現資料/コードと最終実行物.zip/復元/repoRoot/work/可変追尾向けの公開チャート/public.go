// Package publicchart は停止warm96を権威に、読取専用の3分公開欄を追加します。
package publicchart

import (
	"fmt"
	"reflect"

	warm "github.com/masayoshi4649/SessionTradeExecuter/chartwarmup96"
	far80 "github.com/masayoshi4649/SessionTradeExecuter/research80"
)

type Quote = far80.Quote
type TechnicalView far80.TechnicalView
type Scene = warm.Scene

// numericClosed は元formingBarから計算せず写した同じ閉足です。
type numericClosed struct {
	Start, End, Open, High, Low, Close float64
	Rows                               int
	Known                              bool
}

// OHLC は公表済みの既知足だけの値です。未知時の0を観測とは扱いません。
type OHLC struct {
	Open  float64 `json:"open"`
	High  float64 `json:"high"`
	Low   float64 `json:"low"`
	Close float64 `json:"close"`
}

// PublicationID は中心/確認/公表を混同せず結ぶ3要素の足識別です。
type PublicationID struct {
	Session  string  `json:"session"`
	Contract string  `json:"contract"`
	BarEnd   float64 `json:"bar_end"`
}

// ClosedThree は公表単位と既知性を個別に保存する追加欄です。
type ClosedThree struct {
	ID                PublicationID    `json:"publication_id"`
	BarStart          float64          `json:"bar_start"`
	BarEnd            float64          `json:"bar_end"`
	AvailableAt       float64          `json:"available_at"`
	ObservedClock     float64          `json:"observed_clock"`
	Known             bool             `json:"known"`
	EMA8Known         bool             `json:"ema8_known"`
	EMA21Known        bool             `json:"ema21_known"`
	HistogramKnown    bool             `json:"histogram_known"`
	PreviousHistKnown bool             `json:"previous_histogram_known"`
	OHLC              OHLC             `json:"ohlc"`
	RawRows           int              `json:"raw_rows"`
	ValidLastRows     int              `json:"valid_last_rows"`
	HasLastSource     bool             `json:"has_last_source"`
	LastSource        warm.SourceStamp `json:"last_source"`
	InvalidatedAt     float64          `json:"invalidated_at"`
}

// Snapshot は既存全fieldをLegacyへ同体で残し、追加欄を明示分離します。
type Snapshot struct {
	Legacy warm.Snapshot `json:"legacy"`
	Three  ClosedThree   `json:"closed_three"`
}

// Publication は旧公表順と新3分公表のordinalを保存します。
type Publication struct {
	ID       PublicationID `json:"publication_id"`
	At       float64       `json:"at"`
	Three    bool          `json:"three"`
	Fifteen  bool          `json:"fifteen"`
	Ordinal  int           `json:"publication_ordinal"`
	Snapshot Snapshot      `json:"snapshot"`
}

type Batch struct {
	Publications []Publication `json:"publications"`
	Grids        []Snapshot    `json:"grids"`
	After        Snapshot      `json:"after"`
}

// Seed は旧sealed種と同時点の派生数値種だけをメモリで継承します。
type Seed struct {
	legacy   warm.Seed
	numeric  TechnicalBank
	contract string
}

// Bank は旧時計器を直接使い、数値器の再実装でtimerを作りません。
type Bank struct {
	legacy  *warm.Bank
	numeric *TechnicalBank
	scene   Scene
	ordinal int
}

// New は旧Newの場/限月/seed検査を保ち、公開maskを同じ場頭へ戻します。
//
// 引数: scene(Scene)、seed(*Seed又はnil)は場と当部品でsealedした前場種です。
// 返り値: *Bank/errorは所有なしの読取器又は旧時計/種の不正です。
func New(scene Scene, seed *Seed) (*Bank, error) {
	var oldSeed *warm.Seed
	if seed != nil {
		oldSeed = &seed.legacy
	}
	old, err := warm.New(scene, oldSeed)
	if err != nil {
		return nil, err
	}
	numeric := NewTechnicalBank()
	if seed != nil && scene.Contract == seed.contract {
		copy := seed.numeric
		numeric = &copy
	}
	numeric.BeginSession(scene.Start)
	b := &Bank{legacy: old, numeric: numeric, scene: scene}
	if _, err = b.extend(old.Snapshot()); err != nil {
		return nil, err
	}
	return b, nil
}

// extend は旧TechnicalView全文一致を条件に、私有Knownと閉足証跡を追加します。
//
// 引数: old(warm.Snapshot)は同じ操作位相の旧値です。
// 返り値: Snapshot/errorは旧値同体と追加欄、又は数値差です。
func (b *Bank) extend(old warm.Snapshot) (Snapshot, error) {
	if !reflect.DeepEqual(far80.TechnicalView(b.numeric.View()), old.Chart.Technical) {
		return Snapshot{}, fmt.Errorf("旧TechnicalView全fieldと派生数値器が不一致")
	}
	a := b.numeric.series3
	closed := ClosedThree{BarEnd: old.Three.BarEnd, AvailableAt: old.Three.AvailableAt,
		ObservedClock: old.Three.ObservedClock, RawRows: old.Three.Rows,
		HasLastSource: old.Three.HasLastSource, LastSource: old.Three.LastSource,
		InvalidatedAt: old.InvalidatedAt}
	if a.published {
		closed.ID = PublicationID{b.scene.ID, b.scene.Contract, a.end}
		closed.BarStart = a.end - 180
		closed.Known = a.closed.Known
		closed.EMA8Known, closed.EMA21Known = a.ema8.known, a.ema21.known
		closed.HistogramKnown, closed.PreviousHistKnown = a.histKnown, a.previousHistKnown
		closed.OHLC = OHLC{a.closed.Open, a.closed.High, a.closed.Low, a.closed.Close}
		closed.ValidLastRows = a.closed.Rows
		if a.end != old.Three.BarEnd || closed.Known && (a.closed.End != a.end || a.closed.Close != old.Chart.Technical.Close3 || !old.Three.DataKnown) {
			return Snapshot{}, fmt.Errorf("追加OHLCと元公表足の出典差")
		}
	}
	return Snapshot{old, closed}, nil
}

// appendPublication は旧timerの一回の公表だけを派生数値器へ配送します。
//
// 引数: p(warm.Publication)は旧Batchの公表です。
// 返り値: Publication/errorは同じ公表と追加欄、又は不一致です。
func (b *Bank) appendPublication(p warm.Publication) (Publication, error) {
	if err := b.numeric.Advance(p.At); err != nil {
		return Publication{}, err
	}
	s, err := b.extend(p.Snapshot)
	if err != nil {
		return Publication{}, err
	}
	b.ordinal++
	return Publication{ID: s.Three.ID, At: p.At, Three: p.Three, Fifteen: p.Fifteen, Ordinal: b.ordinal, Snapshot: s}, nil
}

// convert は旧Batchの公表→同秒grid→当rawという位相だけを写します。
//
// 引数: raw(warm.Batch)、quote(*Quote又はnil)は旧出力と当行です。
// 返り値: Batch/errorは同じ全Snapshotと追加欄、又は不一致です。
func (b *Bank) convert(raw warm.Batch, quote *Quote) (Batch, error) {
	out := Batch{Publications: []Publication{}, Grids: []Snapshot{}}
	i := 0
	// appendTo は指定grid以前の旧公表だけを同じ順に写します。
	//
	// 引数: at(float64)は当grid又はAfter時計です。
	// 返り値: errorは派生数値器との不一致です。
	appendTo := func(at float64) error {
		for i < len(raw.Publications) && raw.Publications[i].At <= at {
			p, err := b.appendPublication(raw.Publications[i])
			if err != nil {
				return err
			}
			out.Publications = append(out.Publications, p)
			i++
		}
		return nil
	}
	for _, g := range raw.Grids {
		if err := appendTo(g.At); err != nil {
			return out, err
		}
		s, err := b.extend(g)
		if err != nil {
			return out, err
		}
		out.Grids = append(out.Grids, s)
	}
	if err := appendTo(raw.After.At); err != nil {
		return out, err
	}
	if i != len(raw.Publications) {
		return out, fmt.Errorf("旧公表を配送し残した")
	}
	if quote != nil {
		if err := b.numeric.Observe(*quote); err != nil {
			return out, err
		}
	}
	s, err := b.extend(raw.After)
	out.After = s
	return out, err
}

// AdvanceObserved は旧clock/grid検査を通し、公表の無い時刻に足を作りません。
//
// 引数: at(float64)、grids([]float64)は観測済み上限と判断時計です。
// 返り値: Batch/errorは旧Batch同体と追加欄です。
func (b *Bank) AdvanceObserved(at float64, grids []float64) (Batch, error) {
	raw, err := b.legacy.AdvanceObserved(at, grids)
	if err != nil {
		return Batch{}, err
	}
	return b.convert(raw, nil)
}

// Step は当rawを旧器と同位相で加え、不良Lastも同じresetへ渡します。
//
// 引数: quote(Quote)、grids([]float64)は当時原行と判断時計です。
// 返り値: Batch/errorは同じ公表/判断/当行後Snapshotです。
func (b *Bank) Step(quote Quote, grids []float64) (Batch, error) {
	raw, err := b.legacy.Step(quote, grids)
	if err != nil {
		return Batch{}, err
	}
	return b.convert(raw, &quote)
}

// Snapshot は未来へ進めず旧現値と追加欄を返します。
//
// 引数: なし。
// 返り値: Snapshot/errorは現値又は同値違反です。
func (b *Bank) Snapshot() (Snapshot, error) { return b.extend(b.legacy.Snapshot()) }

// Seal は形成足を先締めせず、旧種と同時点の数値だけを返します。
//
// 引数: なし。
// 返り値: Seed/Snapshot/errorは次場種と終値、又は旧seal拒否です。
func (b *Bank) Seal() (Seed, Snapshot, error) {
	seed, raw, err := b.legacy.Seal()
	if err != nil {
		return Seed{}, Snapshot{}, err
	}
	s, err := b.extend(raw)
	return Seed{seed, *b.numeric, b.scene.Contract}, s, err
}
