package miniprofit110

import "fmt"

// SourceClosing110 は後続枠までに予約が解消しても復活させない最初のSource返済通知です。
type SourceClosing110 struct {
	Ordinal  int            `json:"ordinal"`
	Source   SourceIdentity `json:"source"`
	At       float64        `json:"at"`
	Quote    QuoteStamp     `json:"quote"`
	HoldID   string         `json:"hold_id"`
	NoticeID string         `json:"notice_id"`
}

// EntryAttemptAudit110 は未取得の一出生を同一方向のまま再査定した各枠を記録します。
type EntryAttemptAudit110 struct {
	Ordinal     int                   `json:"ordinal"`
	Attempt     int                   `json:"attempt"`
	At          float64               `json:"at"`
	Action      string                `json:"action"`
	Terminal    bool                  `json:"terminal"`
	Opportunity EntryOpportunityTrace `json:"opportunity"`
}

// LifetimeTerminal110 はgrid外のForce/EOFでの永久失効を分けます。
type LifetimeTerminal110 struct {
	Ordinal     int                   `json:"ordinal"`
	At          float64               `json:"at"`
	Kind        string                `json:"kind"`
	Opportunity EntryOpportunityTrace `json:"opportunity"`
}

// extendedLifetime は初回取得前だけ継続するE2/L1を識別します。
//
// 引数: receiver(*ActualBook)は口座。返り値: boolはE2/L1だけ真です。
func (b *ActualBook) extendedLifetime() bool {
	return b.composite != nil && b.composite.Config.EntryPolicy == EntryE2 && b.composite.Config.EntryLifetime == LifetimeL1
}

// rememberSourceClosing は未取得Sourceへの返済予約を不可逆の失効根拠にします。
//
// 引数: key(string)、at(float64)、q(QuoteStamp)、hold/notice(string)は元Source通知。
// 返り値: ありません。実取引/元Sourceを変更しません。
func (b *ActualBook) rememberSourceClosing(key string, at float64, q QuoteStamp, hold, notice string) {
	if !b.extendedLifetime() {
		return
	}
	i, exists := b.opportunityBySource[key]
	if !exists || b.result.EntryOpportunities[i].Consumed {
		return
	}
	if _, exists = b.composite.firstClosings[key]; exists {
		return
	}
	p := b.result.EntryOpportunities[i]
	b.composite.firstClosings[key] = SourceClosing110{p.Ordinal, p.Source, at, q, hold, notice}
}

// lifetimeClosing は過去の一度でも発生したSource返済予約を確認します。
//
// 引数: p(EntryOpportunityTrace)は元出生。返り値: boolは永久失効根拠があれば真です。
func (b *ActualBook) lifetimeClosing(p EntryOpportunityTrace) bool {
	if !b.extendedLifetime() {
		return false
	}
	_, exists := b.composite.firstClosings[sourceKey(p.Source.Method, p.Source.SignalID)]
	return exists
}

// lifetimeRecord は一枠の未知/待機/永久消費を実保有と別に残します。
//
// 引数: p(*EntryOpportunityTrace)、at(float64)、trace(*EntryGridTrace)は機会・枠・実集計。
// 返り値: ありません。
func (b *ActualBook) lifetimeRecord(p *EntryOpportunityTrace, at float64, trace *EntryGridTrace) {
	w := b.composite
	w.attemptCounts[p.Ordinal]++
	action := "wait"
	if p.Status == "accepted" {
		action = "accepted"
	} else if p.Consumed {
		action = "expired"
	} else if p.RequiredUnknown {
		action = "unknown"
	}
	w.entryAttempts = append(w.entryAttempts, EntryAttemptAudit110{p.Ordinal, w.attemptCounts[p.Ordinal], at, action, p.Consumed, valueCopy(*p)})
	if p.Status == "expired" {
		trace.ExpiredCount++
		b.result.GridMetrics.Expired++
	}
	if p.RequiredUnknown {
		trace.UnknownCount++
		b.result.GridMetrics.RequiredUnknown++
	}
	if p.Consumed {
		b.entryBySource[sourceKey(p.Source.Method, p.Source.SignalID)] = p.EntryOrderID
	}
}

// evaluateLifetimeOpportunity はL1の未取得出生を当枠のSource/余力/技法で再査定します。
//
// 引数: i(int)、at(float64)、quiet(bool)、trace(*EntryGridTrace)、gate(EntryGate)は機会・枠・静観・集計・事前一括判定cache。
// 返り値: errorはSource/候補の不整合です。初回実要求受理後の再参加はしません。
func (b *ActualBook) evaluateLifetimeOpportunity(i int, at float64, quiet bool, trace *EntryGridTrace, gate EntryGate) error {
	p := &b.result.EntryOpportunities[i]
	key := sourceKey(p.Source.Method, p.Source.SignalID)
	s := b.sourceOrders[key]
	if s == nil || s.signal.Action != "new" || s.identity != p.Source || s.signal.Side != p.Side || p.Consumed || at < p.AssignedAt {
		return fmt.Errorf("L1の元出生/最短枠/未消費が不正")
	}
	if _, exists := b.entryBySource[key]; exists {
		return fmt.Errorf("永久消費したL1出生を再査定")
	}
	p.EvaluatedAt, p.Status, p.Reason, p.SourceState = &at, "waiting", "次の5分枠まで待機", s.state
	p.RequiredUnknown, p.Requested, p.EntryOrderID, p.Gate = false, 0, "", nil
	p.SourceHoldID, p.SourceQuantity, p.SourceReserved, p.Quote, p.QuoteAgeSeconds = "", nil, nil, nil, nil
	p.Available = b.available(p.Side)
	if b.haveQuote {
		q, age := b.last, at-b.last.Time
		p.Quote, p.QuoteAgeSeconds = &q, &age
	}
	var hold *sourceHold
	if s.hold != "" {
		hold = b.sourceHolds[sourceKey(p.Source.Method, s.hold)]
		if hold == nil || hold.orderKey != key || hold.side != p.Side || hold.quantity < 0 || hold.reserved < 0 || hold.reserved > hold.quantity {
			return fmt.Errorf("L1のSource所有が不正")
		}
		q, r := hold.quantity, hold.reserved
		p.SourceHoldID, p.SourceQuantity, p.SourceReserved = s.hold, &q, &r
	}
	expire := func(reason string) { p.Consumed, p.Status, p.Reason = true, "expired", reason }
	switch {
	case at >= b.entryDeadline(p.Source.Method):
		expire("L1元手法Force境界で永久失効")
	case b.lifetimeClosing(*p):
		expire("L1でSource返済予約を観測済み・永久失効")
	case s.state == "cancelled":
		expire("L1のSource取消・永久失効")
	case s.state == "filled" && hold == nil:
		return fmt.Errorf("L1取得済みSourceのHold欠落")
	case hold != nil && hold.quantity == 0:
		expire("L1のSource完結・永久失効")
	case hold != nil && hold.reserved > 0:
		expire("L1のSource返済予約・永久失効")
	case quiet:
		p.Reason = "L1静観中・未取得のまま待機"
	case s.state == "pending":
		p.Reason = "L1のSource未取得・後続枠まで待機"
	case s.state != "filled":
		return fmt.Errorf("L1の未知Source状態")
	case !trace.QuoteKnown:
		p.RequiredUnknown, p.Reason = true, "L1当枠の正常気配が必要未知"
	case p.Available == 0:
		p.Reason = "L1片側満杯・未取得のまま待機"
		b.result.Metrics.CapRejectedEntries++
	default:
		quantity := min(s.signal.Quantity, hold.quantity, p.Available)
		if quantity <= 0 || gate == nil {
			return fmt.Errorf("L1の正量/一括gateが必要")
		}
		decision, err := evaluateEntryGate(b.result.Config.GatePolicy, gate, EntryCandidate{Ordinal: p.Ordinal, At: at, Side: p.Side, Source: s.identity, Quote: b.last, Available: p.Available, Quantity: quantity})
		if err != nil {
			return err
		}
		p.Gate = &decision
		if !decision.Known || !decision.Allowed {
			p.RequiredUnknown, p.Reason = !decision.Known, decision.Reason
			break
		}
		p.Consumed, p.Status, p.Requested, p.EntryOrderID = true, "accepted", quantity, b.newID()
		p.Reason = "L1初回実要求を受理・同出生の再参加は永久禁止"
		if p.Available < min(s.signal.Quantity, hold.quantity) {
			b.result.Metrics.CapClippedEntries++
		}
		positionID := fmt.Sprintf("%s-%s-P%06d", b.result.Session.ID, b.result.Key, len(b.result.Orders)+1)
		order := ActualOrder{ID: p.EntryOrderID, Kind: "entry", Side: p.Side, Quantity: quantity, PositionID: positionID, Source: s.identity, SourceHoldID: s.hold, RequestTime: at, RequestQuote: b.last, Reason: s.signal.Reason, Status: "pending"}
		b.orders[order.ID] = len(b.result.Orders)
		b.result.Orders = append(b.result.Orders, order)
		b.result.Metrics.EntryRequests++
		b.result.Metrics.EntryAcceptedQuantity += quantity
		trace.AcceptedCount++
		trace.AcceptedQty += quantity
		b.result.GridMetrics.Accepted++
	}
	b.lifetimeRecord(p, at, trace)
	return nil
}

// expireLifetimeDeadline はtimer境界に達した未取得L1だけを永久失効させます。
//
// 引数: at(float64)は元timer。返り値: ありません。架空のgridやholdを作りません。
func (b *ActualBook) expireLifetimeDeadline(at float64) {
	if !b.extendedLifetime() {
		return
	}
	for i := range b.result.EntryOpportunities {
		p := &b.result.EntryOpportunities[i]
		if p.Consumed || at < b.entryDeadline(p.Source.Method) {
			continue
		}
		p.Consumed, p.EvaluatedAt, p.Status, p.Reason = true, &at, "expired", "L1元timerのForce境界で永久失効"
		p.RequiredUnknown, p.Gate, p.Requested, p.EntryOrderID = false, nil, 0, ""
		key := sourceKey(p.Source.Method, p.Source.SignalID)
		if s := b.sourceOrders[key]; s != nil {
			p.SourceState, p.SourceHoldID = s.state, s.hold
			if h := b.sourceHolds[sourceKey(p.Source.Method, s.hold)]; h != nil {
				q, r := h.quantity, h.reserved
				p.SourceQuantity, p.SourceReserved = &q, &r
			}
		}
		if b.haveQuote {
			q, age := b.last, at-b.last.Time
			p.Quote, p.QuoteAgeSeconds = &q, &age
		}
		p.Available = b.available(p.Side)
		b.entryBySource[key] = ""
		b.result.GridMetrics.Expired++
		b.composite.lifetimeTerminals = append(b.composite.lifetimeTerminals, LifetimeTerminal110{p.Ordinal, at, "force", valueCopy(*p)})
	}
}
