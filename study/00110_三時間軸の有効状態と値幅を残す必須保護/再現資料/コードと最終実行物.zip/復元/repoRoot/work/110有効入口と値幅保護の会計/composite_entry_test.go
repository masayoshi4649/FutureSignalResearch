package miniprofit110

import (
	"fmt"
	"testing"
)

// compositeDecisions は候補全値をechoする人工一括採否を作ります。
//
// 引数: in(EntryBatchInput)、allow(bool)は適格集合と人工採否。返り値: EntryBatchOutputは数量を変更しません。
func compositeDecisions(in EntryBatchInput, allow bool) EntryBatchOutput {
	out := EntryBatchOutput{SnapshotID: in.SnapshotID, Decisions: []EntryBatchDecision{}}
	for _, candidate := range in.Candidates {
		out.Decisions = append(out.Decisions, EntryBatchDecision{Candidate: candidate, Decision: GateDecision{Policy: CompositeGatePolicy, SnapshotID: in.SnapshotID, Known: true, Allowed: allow, Role: "人工", Reason: "人工の一括採否"}})
	}
	return out
}

// TestCompositeBatchClipping は全同枠候補を先に判定し、後の容量配賦だけ旧順で行うことを確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestCompositeBatchClipping(t *testing.T) {
	for _, protection := range []CompositeProtection{ProtectG0, ProtectG3, ProtectG4} {
		h := newCompositeHarness(t, EntryE2, protection, 1, 0, 0, false, false)
		h.feed(t, h.start+601, 0, false, birth("一括A", 1, 6), birth("一括B", 1, 6))
		h.feed(t, h.start+602, 0, false)
		calls := 0
		gate := func(in EntryBatchInput) (EntryBatchOutput, error) {
			calls++
			if calls == 1 && len(in.Candidates) != 0 {
				t.Fatal("静観内の空候補callbackが違う")
			}
			if calls == 2 {
				if len(in.Candidates) != 2 || in.Candidates[0].Quantity != 6 || in.Candidates[1].Quantity != 6 || in.Candidates[0].Available != 10 || in.Candidates[1].Available != 10 {
					t.Fatal("受付前の全候補集合ではない")
				}
			}
			return compositeDecisions(in, true), nil
		}
		h.grid(t, h.start+900, gate)
		h.feed(t, h.start+1199, 0, false)
		h.grid(t, h.start+1200, gate)
		if calls != 2 || h.b.result.EntryOpportunities[0].Requested != 6 || h.b.result.EntryOpportunities[1].Requested != 4 || h.b.result.Metrics.CapClippedEntries != 1 {
			t.Fatal("一括判定又は旧順の6+4容量配賦が違う")
		}
		h.feed(t, h.start+1201, 0, false)
		h.forceAndFinish(t, 0)
		a := h.b.CompositeAudit()
		if len(a.EntryBatches) != 2 || a.Key != fmt.Sprintf("entry_E2_L0_%s_C0_D0", protection) {
			t.Fatal("外key又は一括監査が違う")
		}
	}
}

// TestCompositeBatchEligibility は満杯方向を競合集合から除き、反対方向を誤って落とさないことを確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestCompositeBatchEligibility(t *testing.T) {
	h := newCompositeHarness(t, EntryE2, ProtectG3, 1, 0, 0, false, false)
	h.feed(t, h.start+601, 0, false, birth("先行10", 1, 10))
	h.feed(t, h.start+602, 0, false)
	h.feed(t, h.start+1199, 0, false)
	h.grid(t, h.start+1200, func(in EntryBatchInput) (EntryBatchOutput, error) { return compositeDecisions(in, true), nil })
	h.feed(t, h.start+1201, 0, false)
	h.feed(t, h.start+1202, 0, false, birth("満杯買い", 1, 5), birth("余力売り", -1, 4))
	h.feed(t, h.start+1203, 0, false)
	h.feed(t, h.start+1499, 0, false)
	h.grid(t, h.start+1500, func(in EntryBatchInput) (EntryBatchOutput, error) {
		if len(in.Candidates) != 1 || in.Candidates[0].Side != -1 || in.Candidates[0].Quantity != 4 || in.AvailableBuy != 0 || in.AvailableSell != 10 {
			t.Fatal("満杯方向を含めた誤競合集合")
		}
		return compositeDecisions(in, true), nil
	})
	h.feed(t, h.start+1501, 0, false)
	r := h.b.Snapshot()
	if r.Totals.OpenBuy != 10 || r.Totals.OpenSell != 4 || r.Metrics.CapRejectedEntries != 1 {
		t.Fatal("実適格な反対側取得又はcap失効が違う")
	}
	h.forceAndFinish(t, 0)
}

// TestCompositeBatchConflict は同集合の両方向成立を純入口で不成立へ返す契約を確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestCompositeBatchConflict(t *testing.T) {
	h := newCompositeHarness(t, EntryE2, ProtectG4, 1, 0, 0, false, false)
	h.feed(t, h.start+601, 0, false, birth("競合买い", 1, 4), birth("競合売り", -1, 4))
	h.feed(t, h.start+602, 0, false)
	h.feed(t, h.start+1199, 0, false)
	h.grid(t, h.start+1200, func(in EntryBatchInput) (EntryBatchOutput, error) {
		if len(in.Candidates) != 2 {
			t.Fatal("競合の集合が不足")
		}
		out := compositeDecisions(in, false)
		for i := range out.Decisions {
			out.Decisions[i].Decision.Role = "競合"
			out.Decisions[i].Decision.Reason = "同枠の両方向が成立した人工判定"
		}
		return out, nil
	})
	if len(h.b.result.Orders) != 0 || h.b.result.GridTraces[0].AcceptedCount != 0 || h.b.result.GridTraces[0].UnknownCount != 0 {
		t.Fatal("既知の競合を新規又は不明へ改変")
	}
	h.forceAndFinish(t, 0)
}

// TestCompositeBatchReject は個別APIの迂回・callback改竄・不明成立を拒否します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestCompositeBatchReject(t *testing.T) {
	for name, alter := range map[string]func(*EntryBatchOutput){
		"snapshot": func(o *EntryBatchOutput) { o.SnapshotID = "別snapshot" },
		"数量改変":     func(o *EntryBatchOutput) { o.Decisions[0].Candidate.Quantity++ },
		"方向改変":     func(o *EntryBatchOutput) { o.Decisions[0].Candidate.Side = -1 },
		"元信号改変":    func(o *EntryBatchOutput) { o.Decisions[0].Candidate.Source.SignalID = "別出生" },
		"不足":       func(o *EntryBatchOutput) { o.Decisions = o.Decisions[:0] },
		"重複":       func(o *EntryBatchOutput) { o.Decisions = append(o.Decisions, o.Decisions[0]) },
		"不明成立":     func(o *EntryBatchOutput) { o.Decisions[0].Decision.Known = false },
		"別政策":      func(o *EntryBatchOutput) { o.Decisions[0].Decision.Policy = "E3S" },
		"理由欠落":     func(o *EntryBatchOutput) { o.Decisions[0].Decision.Reason = "" },
	} {
		t.Run(name, func(t *testing.T) {
			h := newCompositeHarness(t, EntryE2, ProtectG3, 1, 0, 0, false, false)
			h.feed(t, h.start+601, 0, false, birth("改竄", 1, 4))
			h.feed(t, h.start+602, 0, false)
			h.feed(t, h.start+1199, 0, false)
			err := h.b.OnCompositeEntryGrid(h.start+1200, "人工snapshot", func(in EntryBatchInput) (EntryBatchOutput, error) {
				out := compositeDecisions(in, true)
				alter(&out)
				return out, nil
			})
			if err == nil || len(h.b.result.Orders) != 0 {
				t.Fatal("不正一括判定を実受付")
			}
		})
	}
	h := newCompositeHarness(t, EntryE2, ProtectG0, 1, 0, 0, false, false)
	if err := h.b.OnEntryGrid(h.start + 1200); err == nil {
		t.Fatal("E1個別APIへの迂回を受理")
	}
	h = newCompositeHarness(t, EntryE2, ProtectG3, 1, 0, 0, false, false)
	h.feed(t, h.start+601, 0, false, birth("再入", 1, 4))
	h.feed(t, h.start+602, 0, false)
	h.feed(t, h.start+1199, 0, false)
	h.grid(t, h.start+1200, func(in EntryBatchInput) (EntryBatchOutput, error) {
		if err := h.b.OnEntryGrid(h.start + 1200); err == nil {
			t.Fatal("callback中の金融再入")
		}
		return compositeDecisions(in, true), nil
	})
	h.feed(t, h.start+1201, 0, false)
	h.forceAndFinish(t, 0)
	h = newCompositeHarness(t, EntryE2, ProtectG3, 1, 0, 0, false, false)
	h.feed(t, h.start+601, 0, false, birth("不正両方向A", 1, 4), birth("不正両方向B", -1, 4))
	h.feed(t, h.start+602, 0, false)
	h.feed(t, h.start+1199, 0, false)
	if err := h.b.OnCompositeEntryGrid(h.start+1200, "両方成立", func(in EntryBatchInput) (EntryBatchOutput, error) { return compositeDecisions(in, true), nil }); err == nil {
		t.Fatal("未解決の両方向成立を受理")
	}
}

// TestCompositeFullSourceReservation は全量Source予約後に保護が重複予約しないことを確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestCompositeFullSourceReservation(t *testing.T) {
	for _, policy := range []CompositeProtection{ProtectG3, ProtectG4} {
		h := newCompositeHarness(t, EntryE0, policy, 1, 5, 1, false, false)
		h.feed(t, h.start+601, 0, false, birth("全予約", 1, 7))
		h.feed(t, h.start+602, 0, false)
		h.feed(t, h.start+1199, 0, false)
		h.grid(t, h.start+1200, nil)
		h.feed(t, h.start+1201, 0, false)
		h.feed(t, h.start+1202, 70, false)
		h.feed(t, h.start+1203, 15, false, closeSignal("全予約返済", "玉-全予約", 1, 7))
		a := h.b.CompositeAudit().Positions[0]
		if len(a.Requests) != 0 || a.FirstFullReservedHit == nil || h.b.result.Metrics.ProtectionExitRequests != 0 || len(h.b.result.Orders) != 2 {
			t.Fatal("Source全予約を保護が重複予約")
		}
		h.feed(t, h.start+1204, 15, false)
		h.forceAndFinish(t, 15)
	}
}
