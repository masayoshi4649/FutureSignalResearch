package miniprofit110

import (
	"fmt"
	"strings"
	"testing"

	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor110"
)

// lifetimeHarness は市場なしでE2の寿命差だけを指定した口座を作ります。
//
// 引数: t(*testing.T)、life(EntryLifetime)、side(int)は検査条件です。
// 返り値: *compositeHarnessはSource通知を一度だけ形成する人工器具です。
func lifetimeHarness(t *testing.T, life EntryLifetime, side int) *compositeHarness {
	t.Helper()
	h := newCompositeHarness(t, EntryE2, ProtectG3, side, 0, 0, false, false)
	var err error
	h.b, err = NewCompositeBook(h.s, CompositeConfig{EntryPolicy: EntryE2, EntryLifetime: life, Protection: ProtectG3}, "手製限月")
	if err != nil {
		t.Fatal(err)
	}
	return h
}

// allow110 は候補を変更しない既知成立の人工gateです。
//
// 引数: in(EntryBatchInput)は事前適格集合です。返り値: EntryBatchOutput/errorは全echoとnilです。
func allow110(in EntryBatchInput) (EntryBatchOutput, error) { return compositeDecisions(in, true), nil }

// wait110 は未知と既知待機を区別する人工gateを返します。
//
// 引数: unknown(bool)は必須値未知の指定です。返り値: EntryBatchGateは全echoを維持します。
func wait110(unknown bool) EntryBatchGate {
	return func(in EntryBatchInput) (EntryBatchOutput, error) {
		out := compositeDecisions(in, false)
		for i := range out.Decisions {
			out.Decisions[i].Decision.Known = !unknown
			out.Decisions[i].Decision.Reason = "人工の既知待機"
			if unknown {
				out.Decisions[i].Decision.Reason = "人工の必要値未知"
			}
		}
		return out, nil
	}
}

// Test110LifetimeWaitUnknown は同じSourceを再出生させず後続枠で初回取得する境界を確認します。
//
// 引数: t(*testing.T)は買売・L0/L1・未知/待機の人工です。返り値: ありません。
func Test110LifetimeWaitUnknown(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, unknown := range []bool{false, true} {
			for _, life := range []EntryLifetime{LifetimeL0, LifetimeL1} {
				t.Run(fmt.Sprintf("%d/%t/%s", side, unknown, life), func(t *testing.T) {
					h := lifetimeHarness(t, life, side)
					h.feed(t, h.start+601, 0, false, birth("同一出生", side, 4))
					h.feed(t, h.start+602, 0, false)
					h.grid(t, h.start+1200, wait110(unknown))
					first := h.b.Snapshot()
					wantAction := "待機"
					if unknown {
						wantAction = "判定不能"
					}
					if first.GridTraces[0].Action != wantAction || first.EntryOpportunities[0].Consumed != (life == LifetimeL0) || first.Totals.OpenBuy+first.Totals.OpenSell != 0 {
						t.Fatal("初回の未知/待機/消費が不正")
					}
					h.feed(t, h.start+1499, 0, false)
					h.grid(t, h.start+1500, allow110)
					if len(h.b.result.Fills) != 0 {
						t.Fatal("要求と同原行で新規約定")
					}
					h.feed(t, h.start+1501, 0, false)
					want := 0
					if life == LifetimeL1 {
						want = 4
					}
					if h.b.Snapshot().Totals.EntryQuantity != want || len(h.b.result.EntryOpportunities) != 1 {
						t.Fatal("再査定又は一出生識別が不正")
					}
					a := h.b.CompositeAudit()
					if life == LifetimeL1 {
						if len(a.EntryAttempts) != 2 || a.EntryAttempts[0].Terminal || a.EntryAttempts[1].Action != "accepted" || !a.EntryAttempts[1].Terminal || a.EntryAttempts[0].Opportunity.Gate == nil || a.EntryAttempts[1].Opportunity.Source != a.EntryAttempts[0].Opportunity.Source {
							t.Fatal("各枠の値copy/永久lockが不正")
						}
					}
					h.grid(t, h.start+1800, allow110)
					if len(h.b.CompositeAudit().EntryAttempts) != len(a.EntryAttempts) {
						t.Fatal("取得済み出生を再査定")
					}
					h.forceAndFinish(t, 0)
				})
			}
		}
	}
}

// Test110PendingQuoteCap は未取得・気配未知・満杯を保有へ水増しせず後続枠へ保留します。
//
// 引数: t(*testing.T)は人工検査です。返り値: ありません。
func Test110PendingQuoteCap(t *testing.T) {
	t.Run("Source未取得と正常気配", func(t *testing.T) {
		h := lifetimeHarness(t, LifetimeL1, 1)
		h.feed(t, h.start+601, 0, false, birth("未取得", 1, 3))
		h.grid(t, h.start+1200, allow110)
		if len(h.b.CompositeAudit().EntryBatches[0].Input.Candidates) != 0 || h.b.result.GridTraces[0].Action != "待機" || h.b.result.EntryOpportunities[0].Consumed {
			t.Fatal("Source未取得を消費/保有")
		}
		h.feed(t, h.start+1201, 0, false)
		h.feed(t, h.start+1499, 0, true)
		h.grid(t, h.start+1500, allow110)
		if h.b.result.GridTraces[1].Action != "判定不能" || h.b.result.EntryOpportunities[0].Consumed {
			t.Fatal("気配未知を成立/永久失効")
		}
		h.feed(t, h.start+1799, 0, false)
		h.grid(t, h.start+1800, allow110)
		h.feed(t, h.start+1801, 0, false)
		if h.b.Snapshot().Totals.EntryQuantity != 3 {
			t.Fatal("後続正常枠で取得しない")
		}
		h.forceAndFinish(t, 0)
	})
	t.Run("満杯後に空く", func(t *testing.T) {
		h := lifetimeHarness(t, LifetimeL1, 1)
		h.atr = 200
		h.feed(t, h.start+601, 0, false, birth("先行", 1, 10))
		h.feed(t, h.start+602, 0, false)
		h.grid(t, h.start+1200, allow110)
		h.feed(t, h.start+1201, 0, false)
		h.feed(t, h.start+1202, 0, false, birth("保留", 1, 3))
		h.feed(t, h.start+1203, 0, false)
		h.grid(t, h.start+1500, allow110)
		if len(h.b.CompositeAudit().EntryBatches[1].Input.Candidates) != 0 || h.b.result.EntryOpportunities[1].Consumed || h.b.result.GridTraces[1].Action != "保有" {
			t.Fatal("満杯保留が不正")
		}
		h.feed(t, h.start+1501, 0, false, closeSignal("先行終了", "玉-先行", 1, 10))
		h.feed(t, h.start+1502, 0, false)
		h.grid(t, h.start+1800, allow110)
		h.feed(t, h.start+1801, 0, false)
		if h.b.Snapshot().Totals.EntryQuantity != 13 || len(h.b.result.EntryOpportunities) != 2 || h.b.result.EntryOpportunities[1].Requested != 3 {
			t.Fatal("余力復活後の初回取得が不正")
		}
		h.forceAndFinish(t, 0)
	})
}

// Test110IrrevocableSourceClosing は枠間で解消した部分予約を永久失効の根拠として保持します。
//
// 引数: t(*testing.T)は買売の人工です。返り値: ありません。
func Test110IrrevocableSourceClosing(t *testing.T) {
	for _, side := range []int{1, -1} {
		h := lifetimeHarness(t, LifetimeL1, side)
		h.feed(t, h.start+601, 0, false, birth("予約失効", side, 7))
		h.feed(t, h.start+602, 0, false)
		h.grid(t, h.start+1200, wait110(false))
		h.feed(t, h.start+1201, 0, false, closeSignal("部分予約", "玉-予約失効", side, 2))
		h.feed(t, h.start+1202, 0, false)
		h.grid(t, h.start+1500, allow110)
		a := h.b.CompositeAudit()
		p := h.b.result.EntryOpportunities[0]
		if len(a.FirstSourceClosings) != 1 || a.FirstSourceClosings[0].At != h.start+1201 || a.FirstSourceClosings[0].NoticeID != "部分予約|玉-予約失効" || p.SourceQuantity == nil || *p.SourceQuantity != 5 || *p.SourceReserved != 0 || !p.Consumed || p.Status != "expired" || !strings.Contains(p.Reason, "観測済み") || len(a.EntryBatches[1].Input.Candidates) != 0 {
			t.Fatal("解消後のSource予約を忘れて復活")
		}
		h.grid(t, h.start+1800, allow110)
		if len(h.b.result.Orders) != 0 || len(h.b.CompositeAudit().EntryAttempts) != 2 {
			t.Fatal("永久失効を再参加")
		}
		h.forceAndFinish(t, 0)
	}
}

// Test110AcceptedLock は未約定取消と約定後の保護完結でも同一出生を再取得しません。
//
// 引数: t(*testing.T)は人工2経路です。返り値: ありません。
func Test110AcceptedLock(t *testing.T) {
	t.Run("受理後取消", func(t *testing.T) {
		h := lifetimeHarness(t, LifetimeL1, 1)
		h.feed(t, h.start+601, 0, false, birth("取消lock", 1, 4))
		h.feed(t, h.start+602, 0, false)
		h.grid(t, h.start+1200, allow110)
		h.feed(t, h.start+1201, 0, true, closeSignal("取消原因", "玉-取消lock", 1, 1))
		h.grid(t, h.start+1500, allow110)
		if h.b.result.Metrics.EntryRequests != 1 || h.b.result.Metrics.CancelledEntries != 1 || len(h.b.result.Fills) != 0 || !h.b.result.EntryOpportunities[0].Consumed {
			t.Fatal("受理lockがない")
		}
		h.forceAndFinish(t, 0)
	})
	t.Run("保護完結後", func(t *testing.T) {
		h := lifetimeHarness(t, LifetimeL1, 1)
		h.feed(t, h.start+601, 0, false, birth("保護lock", 1, 4))
		h.feed(t, h.start+602, 0, false)
		h.grid(t, h.start+1200, allow110)
		h.feed(t, h.start+1201, 0, false)
		h.feed(t, h.start+1202, 80, false)
		h.feed(t, h.start+1203, 15, false)
		h.feed(t, h.start+1204, 15, false)
		if h.b.Snapshot().Totals.CloseQuantity != 4 || h.src.qty["玉-保護lock"] != 4 {
			t.Fatal("Source保持のまま実保護完結を通らない")
		}
		h.grid(t, h.start+1500, allow110)
		if h.b.result.Metrics.EntryRequests != 1 || len(h.b.CompositeAudit().EntryAttempts) != 1 || h.b.result.GridTraces[1].Action != "待機" {
			t.Fatal("保護後の再参加又は保有水増し")
		}
		h.forceAndFinish(t, 15)
	})
}

// Test110LifetimeTerminals はgridのないForce/EOFと取消の永久失効を保存します。
//
// 引数: t(*testing.T)は人工境界です。返り値: ありません。
func Test110LifetimeTerminals(t *testing.T) {
	t.Run("Force", func(t *testing.T) {
		h := lifetimeHarness(t, LifetimeL1, 1)
		h.feed(t, h.start+601, 0, false, birth("Force待機", 1, 3))
		h.feed(t, h.start+602, 0, false)
		h.grid(t, h.start+1200, wait110(true))
		h.forceAndFinish(t, 0)
		a := h.b.CompositeAudit()
		if len(a.LifetimeTerminals) != 1 || a.LifetimeTerminals[0].Kind != "force" || a.LifetimeTerminals[0].At != h.s.ForceClose || a.LifetimeTerminals[0].Opportunity.SourceReserved == nil || *a.LifetimeTerminals[0].Opportunity.SourceReserved != 3 || h.b.result.GridMetrics.RequiredUnknown != 1 {
			t.Fatal("Force失効の当時Sourceと未知履歴が不正")
		}
	})
	t.Run("EOF", func(t *testing.T) {
		h := lifetimeHarness(t, LifetimeL1, 1)
		h.feed(t, h.start+601, 0, false, birth("EOF待機", 1, 3))
		h.feed(t, h.start+602, 0, false)
		h.grid(t, h.start+1200, wait110(false))
		h.feed(t, h.start+1201, 0, false, closeSignal("EOF元完結", "玉-EOF待機", 1, 3))
		h.feed(t, h.start+1202, 0, false)
		if _, err := h.b.Finish(); err != nil {
			t.Fatal(err)
		}
		a := h.b.CompositeAudit()
		if len(a.LifetimeTerminals) != 1 || a.LifetimeTerminals[0].Kind != "eof" || len(h.b.result.Fills) != 0 || len(h.b.result.GridTraces) != 1 {
			t.Fatal("EOFで架空枠/実保有を生成")
		}
	})
	t.Run("Source取消", func(t *testing.T) {
		h := lifetimeHarness(t, LifetimeL1, 1)
		h.feed(t, h.start+601, 0, false, birth("元取消", 1, 3))
		h.grid(t, h.start+1200, allow110)
		batch := h.src.force(h.start + 1201)
		if err := h.b.OnNativeForce(h.start+1201, []NativeBatch{batch}); err != nil {
			t.Fatal(err)
		}
		h.grid(t, h.start+1500, allow110)
		if !h.b.result.EntryOpportunities[0].Consumed || h.b.result.EntryOpportunities[0].SourceState != "cancelled" || len(h.b.result.Orders) != 0 {
			t.Fatal("元取消を保留/取得")
		}
		h.forceAndFinish(t, 0)
	})
}

// Test110ThresholdActor は新規A/V固定、H未確定と遅いA固定、現在益起動を実会計へ結びます。
//
// 引数: t(*testing.T)は買売・G3/G4・全費用/遅延の人工です。返り値: ありません。
func Test110ThresholdActor(t *testing.T) {
	for _, protect := range []CompositeProtection{ProtectG3, ProtectG4} {
		for _, side := range []int{1, -1} {
			for _, cost := range []float64{0, 5} {
				for _, delay := range []int{0, 1} {
					h := newCompositeHarness(t, EntryE0, protect, side, cost, delay, false, false)
					h.atr = 0
					h.feed(t, h.start+601, 0, false, birth("尺度後判明", side, 7))
					h.feed(t, h.start+602, 0, false)
					v := 20.0
					h.pub(t, h.start+1080, &v, guard.False, guard.False, nil)
					h.grid(t, h.start+1200, nil)
					h.feed(t, h.start+1201, 0, false)
					h.feed(t, h.start+1202, 500, false)
					a := h.b.CompositeAudit().Positions[0]
					if a.Initial.ThresholdKnown || a.Initial.ThresholdLock != nil || a.Last.Active || a.FirstThresholdLock != nil {
						t.Fatal("未知Aを20等で補って起動")
					}
					h.atr = 200
					h.feed(t, h.start+1203, 30, false)
					a = h.b.CompositeAudit().Positions[0]
					p := h.b.Snapshot().Positions[0]
					if a.FirstThresholdLock == nil || a.FirstThresholdLock.Point.Quote != p.ATR.Quote || a.FirstThresholdLock.State.ThresholdLock.At != h.start+1203 || !a.Last.ThresholdKnown || a.Last.Active || a.Activation != nil || a.Last.ThresholdLock.ATR.Value != 200 || a.Last.ThresholdLock.EntryV.Value != 20 || a.Last.ThresholdLock.Alpha != map[CompositeProtection]float64{ProtectG3: .5, ProtectG4: 1}[protect] {
						t.Fatal("A原行/現在益/H固定が不正")
					}
					locked := valueCopy(a.Last.ThresholdLock)
					h.atr = 400
					h.feed(t, h.start+1204, 600, false)
					a = h.b.CompositeAudit().Positions[0]
					compositeEqual(t, locked, a.Last.ThresholdLock, "H一度固定")
					if !a.Last.Active || a.Activation == nil || a.Activation.Point.Quote.Time != h.start+1204 {
						t.Fatal("現在益がH以上でも必須起動しない")
					}
					h.feed(t, h.start+1205, 20, false, closeSignal("部分優先", "玉-尺度後判明", side, 2))
					if len(h.b.result.Fills) != 1 {
						t.Fatal("返済要求と同原行fill")
					}
					a = h.b.CompositeAudit().Positions[0]
					if len(a.Requests) != 1 || a.Requests[0].Requested != 5 || a.Requests[0].Step.Point.Phase != PhaseAfterSource || a.Requests[0].ReservedBefore != 2 || a.Requests[0].ReservedAfter != 7 {
						t.Fatal("Source部分予約を新保護で二重計上")
					}
					h.feed(t, h.start+1206, 20, false)
					r := h.forceAndFinish(t, 20)
					if r.Totals.EntryQuantity != 7 || r.Totals.CloseQuantity != 7 || r.Totals.FeeYen != 14*38.5 || r.Totals.SlipYen != 14*100*cost {
						t.Fatal("mini費用/残量会計不一致")
					}
				}
			}
		}
	}
}

// Test110PolicyKeys は36設定の識別と旧内JSONへの余分な寿命field混入を防ぎます。
//
// 引数: t(*testing.T)は人工constructor検査です。返り値: ありません。
func Test110PolicyKeys(t *testing.T) {
	keys := map[string]bool{}
	s := session()
	for _, entry := range []CompositeEntryPolicy{EntryE0, EntryE2} {
		for _, life := range []EntryLifetime{LifetimeL0, LifetimeL1} {
			if entry == EntryE0 && life == LifetimeL1 {
				continue
			}
			for _, protect := range []CompositeProtection{ProtectG0, ProtectG3, ProtectG4} {
				for _, cost := range []float64{0, 5} {
					for _, delay := range []int{0, 1} {
						b, err := NewCompositeBook(s, CompositeConfig{EntryPolicy: entry, EntryLifetime: life, Protection: protect, SlipPts: cost, DelaySeconds: delay}, "手製限月")
						if err != nil {
							t.Fatal(err)
						}
						if keys[b.CompositeKey()] {
							t.Fatal("外key衝突")
						}
						keys[b.CompositeKey()] = true
						if entry == EntryE0 && b.Snapshot().Config.EntryLifetime != "" {
							t.Fatal("E0内JSONへ寿命を追加")
						}
						if entry == EntryE2 && (!strings.Contains(b.Snapshot().Key, "ENTRY_E2_"+string(life)) || b.Snapshot().Config.EntryLifetime != life) {
							t.Fatal("E2寿命の内key/設定混同")
						}
					}
				}
			}
		}
	}
	if len(keys) != 36 {
		t.Fatal(len(keys))
	}
	for _, c := range []CompositeConfig{{EntryPolicy: EntryE0, EntryLifetime: LifetimeL1, Protection: ProtectG0}, {EntryPolicy: EntryE2, Protection: ProtectG3}, {EntryPolicy: EntryE2, EntryLifetime: "L2", Protection: ProtectG4}, {EntryPolicy: "entry_E1", EntryLifetime: LifetimeL0, Protection: ProtectG3}, {EntryPolicy: EntryE2, EntryLifetime: LifetimeL1, Protection: "G2"}} {
		if _, err := NewCompositeBook(s, c, "手製限月"); err == nil {
			t.Fatal("旧/不正の政策・寿命を受理")
		}
	}
	if _, err := NewActualBook(s, ActorConfig{Policy: "P0", EntryLifetime: LifetimeL1}); err == nil {
		t.Fatal("旧constructorが110寿命を黙認")
	}
}

// Test110LifetimeGridAndAllocation は飛ばした枠、静観、配賦後の余力0を独立に扱います。
//
// 引数: t(*testing.T)は人工3経路です。返り値: ありません。
func Test110LifetimeGridAndAllocation(t *testing.T) {
	t.Run("未配送枠", func(t *testing.T) {
		for _, life := range []EntryLifetime{LifetimeL0, LifetimeL1} {
			h := lifetimeHarness(t, life, 1)
			h.feed(t, h.start+601, 0, false, birth("飛越", 1, 2))
			h.feed(t, h.start+602, 0, false)
			h.grid(t, h.start+1500, allow110)
			p := h.b.result.EntryOpportunities[0]
			if (p.Status == "accepted") != (life == LifetimeL1) || p.AssignedAt != h.start+1200 {
				t.Fatal("割当時計改変又はL0/L1混同")
			}
			h.feed(t, h.start+1501, 0, false)
			h.forceAndFinish(t, 0)
		}
	})
	t.Run("全候補後の余力0", func(t *testing.T) {
		h := lifetimeHarness(t, LifetimeL1, 1)
		h.atr = 200
		h.feed(t, h.start+601, 0, false, birth("配賦A", 1, 6), birth("配賦B", 1, 6), birth("配賦C", 1, 2))
		h.feed(t, h.start+602, 0, false)
		h.grid(t, h.start+1200, func(in EntryBatchInput) (EntryBatchOutput, error) {
			if len(in.Candidates) != 3 || in.Candidates[2].Available != 10 {
				t.Fatal("順次gate更新で候補を消した")
			}
			return compositeDecisions(in, true), nil
		})
		p := h.b.result.EntryOpportunities
		if p[0].Requested != 6 || p[1].Requested != 4 || p[2].Consumed || p[2].Gate != nil || p[2].Available != 0 {
			t.Fatal("後配賦の満杯を技法不成立/永久消費")
		}
		h.feed(t, h.start+1201, 0, false)
		h.feed(t, h.start+1202, 0, false, closeSignal("配賦A終了", "玉-配賦A", 1, 6))
		h.feed(t, h.start+1203, 0, false)
		h.grid(t, h.start+1500, allow110)
		h.feed(t, h.start+1501, 0, false)
		if h.b.Snapshot().Totals.EntryQuantity != 12 || len(h.b.CompositeAudit().EntryAttempts) != 4 {
			t.Fatal("未取得Cだけの後続査定が不正")
		}
		h.forceAndFinish(t, 0)
	})
	t.Run("米国静観とP期限", func(t *testing.T) {
		h := newCompositeHarness(t, EntryE2, ProtectG3, 1, 0, 0, true, false)
		var err error
		h.b, err = NewCompositeBook(h.s, CompositeConfig{EntryPolicy: EntryE2, EntryLifetime: LifetimeL1, Protection: ProtectG3, USOpen: h.s.USOpen}, "手製限月")
		if err != nil {
			t.Fatal(err)
		}
		h.feed(t, h.s.Start+601, 0, false, birth("米国静観", 1, 2))
		h.feed(t, h.s.Start+602, 0, false)
		h.grid(t, h.s.Start+1200, wait110(true))
		h.grid(t, h.s.USOpen, allow110)
		p := h.b.result.EntryOpportunities[0]
		if p.Consumed || p.RequiredUnknown || h.b.result.GridTraces[1].Action != "待機" || !h.b.result.GridTraces[1].Quiet {
			t.Fatal("静観で保有/未知を水増し")
		}
		h.grid(t, h.s.USOpen+1200, allow110)
		h.feed(t, h.s.USOpen+1201, 0, false)
		if h.b.Snapshot().Totals.EntryQuantity != 2 {
			t.Fatal("静観明け等号で取得しない")
		}
		h.forceAndFinish(t, 0)

		h = newCompositeHarness(t, EntryE2, ProtectG3, 1, 0, 0, true, false)
		h.method = "P164_06"
		h.b, err = NewCompositeBook(h.s, CompositeConfig{EntryPolicy: EntryE2, EntryLifetime: LifetimeL1, Protection: ProtectG3, USOpen: h.s.USOpen}, "手製限月")
		if err != nil {
			t.Fatal(err)
		}
		h.feed(t, h.s.Start+601, 0, false, birth("P期限", 1, 2))
		h.feed(t, h.s.Start+602, 0, false)
		h.grid(t, h.s.Start+1200, wait110(false))
		deadline := h.s.USOpen - 900
		batch := h.src.force(deadline)
		batch.Method = h.method
		if err := h.b.OnNativeForce(deadline, []NativeBatch{batch}); err != nil {
			t.Fatal(err)
		}
		h.grid(t, deadline, allow110)
		if !h.b.result.EntryOpportunities[0].Consumed || len(h.b.CompositeAudit().LifetimeTerminals) != 1 || h.b.CompositeAudit().LifetimeTerminals[0].At != deadline || len(h.b.result.Orders) != 0 {
			t.Fatal("P期限を場末まで延ばした")
		}
		h.feed(t, deadline+1, 0, false)
		h.forceAndFinish(t, 0)
	})
}
