"""停止109の人工器具から、110固有の検査入口だけを派生する。市場入力は読まない。"""
from pathlib import Path

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / '一定利益と三時間軸の保護会計'


def main() -> None:
    """機能: 人工器具の派生を保存する。引数: なし。返り値: None。"""
    if (HERE / '停止.json').exists():
        raise RuntimeError('停止版への人工器具の再生成は禁止')
    text = (OLD / 'composite_test.go').read_text(encoding='utf-8')
    text = text[:text.index('// TestCompositeProfitReservations')]
    text = text.replace('package miniprofitthreeproposal', 'package miniprofit110')
    text = text.replace('/profitfloorproposal"', '/profitfloor110"')
    text = text.replace('old108 "', 'old109 "github.com/masayoshi4649/SessionTradeExecuter/miniprofitthreeproposal"\n\told108 "', 1)
    text = text.replace('old                *old108.ActualBook', 'old                *old108.ActualBook\n\told109             *old109.ActualBook')
    text = text.replace('cfg := CompositeConfig{EntryPolicy: entry,', 'cfg := CompositeConfig{EntryPolicy: entry, EntryLifetime: LifetimeL0,')
    text = text.replace('if compare {\n', 'if compare {\n\t\th.old109, err = old109.NewCompositeBook(s, old109.CompositeConfig{EntryPolicy: old109.EntryE0, Protection: old109.ProtectG0, SlipPts: cost, DelaySeconds: delay, USOpen: s.USOpen}, "手製限月")\n\t\tif err != nil { t.Fatal(err) }\n', 1)
    text = text.replace('h.compared++', 'compositeEqual(t, h.b.Snapshot(), h.old109.Snapshot(), "109ActualResult")\n\tcompositeEqual(t, h.b.WidthAudit(), h.old109.WidthAudit(), "109WidthAudit")\n\tcompositeEqual(t, h.b.EarlyAudit(), h.old109.EarlyAudit(), "109EarlyAudit")\n\tcompositeEqual(t, h.b.ClockAudit(), h.old109.ClockAudit(), "109ClockAudit")\n\th.compared++')
    text = text.replace('if h.old != nil {\n\t\tif err := h.old.OnNativeStep', 'if h.old109 != nil {\n\t\tif err := h.old109.OnNativeStep(o, line, []old109.NativeBatch{{Method: batch.Method, Delta: batch.Delta}}); err != nil { t.Fatal(err) }\n\t}\n\tif h.old != nil {\n\t\tif err := h.old.OnNativeStep', 1)
    text = text.replace('if h.old != nil {\n\t\tif err := h.old.OnEntryGrid', 'if h.old109 != nil {\n\t\tif err := h.old109.OnCompositeEntryGrid(at, "", nil); err != nil { t.Fatal(err) }\n\t}\n\tif h.old != nil {\n\t\tif err := h.old.OnEntryGrid', 1)
    text = text.replace('if h.old != nil {\n\t\tfor _, item', 'if h.old109 != nil {\n\t\tvar converted old109.ProtectionObservation\n\t\tencoded, _ := json.Marshal(o)\n\t\tif err := json.Unmarshal(encoded, &converted); err != nil { t.Fatal(err) }\n\t\tif err := h.old109.OnProtectionObservation(converted); err != nil { t.Fatal(err) }\n\t}\n\tif h.old != nil {\n\t\tfor _, item', 1)
    text = text.replace('if h.old != nil {\n\t\tif err := h.old.OnNativeForce', 'if h.old109 != nil {\n\t\tif err := h.old109.OnNativeForce(h.s.ForceClose, []old109.NativeBatch{{Method: batch.Method, Delta: batch.Delta}}); err != nil { t.Fatal(err) }\n\t}\n\tif h.old != nil {\n\t\tif err := h.old.OnNativeForce', 1)
    text = text.replace('if h.old != nil {\n\t\tif _, err := h.old.Finish()', 'if h.old109 != nil {\n\t\tif _, err := h.old109.Finish(); err != nil { t.Fatal(err) }\n\t}\n\tif h.old != nil {\n\t\tif _, err := h.old.Finish()', 1)
    text = text.replace('EntryE1', 'EntryE2').replace('一括E1', '一括E2')
    (HERE / 'composite_test.go').write_text(text, encoding='utf-8')
    for name in ['composite_entry_test.go', 'composite_observation_test.go']:
        value = (OLD / name).read_text(encoding='utf-8')
        value = value.replace('package miniprofitthreeproposal', 'package miniprofit110')
        value = value.replace('/profitfloorproposal"', '/profitfloor110"')
        value = value.replace('EntryE1', 'EntryE2').replace('ProtectG1', 'ProtectG3').replace('ProtectG2', 'ProtectG4')
        value = value.replace('entry_E1_%s_C0_D0', 'entry_E2_L0_%s_C0_D0')
        if name == 'composite_observation_test.go':
            value = value.replace('h.start+1202, 100,', 'h.start+1202, 150,')
        (HERE / name).write_text(value, encoding='utf-8')


if __name__ == '__main__':
    main()
