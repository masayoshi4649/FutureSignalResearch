package miniprofit110

import (
	"encoding/hex"
	"fmt"
	"reflect"
	"strings"

	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor110"
)

type CompositeEntryPolicy string
type CompositeProtection string

const (
	EntryE0             CompositeEntryPolicy = "entry_E0"
	EntryE2             CompositeEntryPolicy = "entry_E2"
	ProtectG0           CompositeProtection  = "G0"
	ProtectG3           CompositeProtection  = "G3"
	ProtectG4           CompositeProtection  = "G4"
	CompositeGatePolicy                      = "ENTRY_E2"
)

// EntryLifetime は最初の取得を判断できる寿命を示し、実取得後の再参加を許しません。
type EntryLifetime string

const (
	LifetimeL0 EntryLifetime = "L0"
	LifetimeL1 EntryLifetime = "L1"
)

// CompositeConfig は入口・保護を外keyで識別する新constructor専用の設定です。
type CompositeConfig struct {
	EntryPolicy   CompositeEntryPolicy `json:"entry_policy"`
	EntryLifetime EntryLifetime        `json:"entry_lifetime,omitempty"`
	Protection    CompositeProtection  `json:"protection_policy"`
	SlipPts       float64              `json:"slip_pts"`
	DelaySeconds  int                  `json:"delay_seconds"`
	USOpen        float64              `json:"us_open"`
}

// ProtectionObservation は窓形成済みの確定3分根拠を両方向まとめて受け取ります。
type ProtectionObservation struct {
	At        float64           `json:"at"`
	Buy       guard.Publication `json:"buy"`
	Sell      guard.Publication `json:"sell"`
	FrameSHA  string            `json:"frame_sha256"`
	ResultSHA string            `json:"result_sha256"`
}

// ProtectionSource は公表値を元の配送と出典SHAへ結ぶ小さい証拠です。
type ProtectionSource struct {
	PublicationID string  `json:"publication_id"`
	DeliveredAt   float64 `json:"delivered_at"`
	FrameSHA      string  `json:"frame_sha256"`
	ResultSHA     string  `json:"result_sha256"`
}

// ProtectionStep は原行のMTMと停止純状態の因果を結びます。
type ProtectionStep struct {
	Point    MTMPoint          `json:"point"`
	State    guard.Snapshot    `json:"state"`
	Decision guard.Decision    `json:"decision"`
	Source   *ProtectionSource `json:"source"`
}

// ProtectionRequest は純判定の枚数が実予約へ変換された証拠です。
type ProtectionRequest struct {
	Step           ProtectionStep `json:"step"`
	OrderID        string         `json:"order_id"`
	Requested      int            `json:"requested"`
	ReservedBefore int            `json:"reserved_before"`
	ReservedAfter  int            `json:"reserved_after"`
}

// CompositePositionAudit は毎原行を複製せず、初回・最終・実予約の根拠を残します。
type CompositePositionAudit struct {
	PositionID           string              `json:"position_id"`
	Initial              guard.Snapshot      `json:"initial"`
	InitialSource        *ProtectionSource   `json:"initial_source"`
	Last                 guard.Snapshot      `json:"last"`
	LastStep             *ProtectionStep     `json:"last_step"`
	Activation           *ProtectionStep     `json:"activation"`
	FirstNarrow          *ProtectionStep     `json:"first_narrow"`
	FirstThresholdLock   *ProtectionStep     `json:"first_threshold_lock,omitempty"`
	FirstFloorHit        *ProtectionStep     `json:"first_floor_hit"`
	LastFloorUpdate      *ProtectionStep     `json:"last_floor_update"`
	FirstFullReservedHit *ProtectionStep     `json:"first_full_reserved_hit"`
	Requests             []ProtectionRequest `json:"requests"`
}

// CompositeAudit は旧ActualResultのJSONを増やさない外側の監査です。
type CompositeAudit struct {
	Key                 string                   `json:"key"`
	Config              CompositeConfig          `json:"config"`
	Contract            string                   `json:"contract"`
	QuietSeconds        int                      `json:"quiet_seconds"`
	Observations        int                      `json:"observations"`
	Resets              int                      `json:"resets"`
	Positions           []CompositePositionAudit `json:"positions"`
	EntryBatches        []EntryBatchAudit        `json:"entry_batches"`
	EntryAttempts       []EntryAttemptAudit110   `json:"entry_attempts,omitempty"`
	LifetimeTerminals   []LifetimeTerminal110    `json:"lifetime_terminals,omitempty"`
	FirstSourceClosings []SourceClosing110       `json:"first_source_closings,omitempty"`
	LatestSource        *ProtectionSource        `json:"latest_source"`
}

type compositePosition struct {
	state           guard.State
	sequence        uint64
	resetGeneration int
	audit           CompositePositionAudit
}

type compositeBook struct {
	Config            CompositeConfig
	Contract          string
	Latest, Last      map[int]*guard.Publication
	At                float64
	HaveClock         bool
	ResetGeneration   int
	ResetReason       string
	Observations      int
	LastFrameSHA      string
	LastResultSHA     string
	LatestSource      *ProtectionSource
	Positions         map[string]*compositePosition
	Batches           []EntryBatchAudit
	batchActive       bool
	attemptCounts     map[int]int
	entryAttempts     []EntryAttemptAudit110
	lifetimeTerminals []LifetimeTerminal110
	firstClosings     map[string]SourceClosing110
}

// NewCompositeBook は旧APIを拡張せず、新しい入口/保護の組合せだけを明示許可します。
//
// 引数: session(Session)、cfg(CompositeConfig)、contract(string)は場・入口/保護・限月です。
// 返り値: *ActualBook/errorは静観1200秒の独立口座又は不正です。G0/E0の旧JSONは保持します。
func NewCompositeBook(session Session, cfg CompositeConfig, contract string) (*ActualBook, error) {
	if cfg.EntryPolicy != EntryE0 && cfg.EntryPolicy != EntryE2 || cfg.Protection != ProtectG0 && cfg.Protection != ProtectG3 && cfg.Protection != ProtectG4 ||
		contract == "" || strings.TrimSpace(contract) != contract {
		return nil, fmt.Errorf("新入口/保護政策又は限月が不正です")
	}
	if cfg.EntryPolicy == EntryE0 {
		if cfg.EntryLifetime != "" && cfg.EntryLifetime != LifetimeL0 {
			return nil, fmt.Errorf("E0は元のL0だけです")
		}
		cfg.EntryLifetime = LifetimeL0
	} else if cfg.EntryLifetime != LifetimeL0 && cfg.EntryLifetime != LifetimeL1 {
		return nil, fmt.Errorf("E2はL0/L1を明示してください")
	}
	base := ActorConfig{Policy: "P0", SlipPts: cfg.SlipPts, DelaySeconds: cfg.DelaySeconds, EntryTiming: TimingQuietDeferred,
		USOpen: cfg.USOpen, ActivationPolicy: ActivationLD10}
	b, err := NewWidthBookWithQuiet(session, base, "W0", contract, 1200)
	if err != nil {
		return nil, err
	}
	b.composite = &compositeBook{Config: cfg, Contract: contract, Latest: map[int]*guard.Publication{}, Last: map[int]*guard.Publication{},
		Positions: map[string]*compositePosition{}, Batches: []EntryBatchAudit{}, attemptCounts: map[int]int{}, firstClosings: map[string]SourceClosing110{}}
	if cfg.Protection != ProtectG0 {
		b.widthBook = nil
		b.result.Config.ActivationPolicy = ActivationPolicy(cfg.Protection)
		b.result.Key = strings.Replace(b.result.Key, string(ActivationLD10)+"_", string(cfg.Protection)+"_", 1)
	}
	if cfg.EntryPolicy == EntryE2 {
		b.result.Config.GatePolicy = CompositeGatePolicy
		b.result.Config.EntryLifetime = cfg.EntryLifetime
		b.result.Key = CompositeGatePolicy + "_" + string(cfg.EntryLifetime) + "_" + b.result.Key
	}
	return b, nil
}

// CompositeKey は新入口/保護を内Keyと混同しない外keyを返します。
//
// 引数: receiver(*ActualBook)は新口座。返り値: stringは外key、旧constructorなら空です。
func (b *ActualBook) CompositeKey() string {
	if b == nil || b.composite == nil {
		return ""
	}
	c := b.composite.Config
	if c.EntryPolicy == EntryE2 {
		return fmt.Sprintf("%s_%s_%s_C%.0f_D%d", c.EntryPolicy, c.EntryLifetime, c.Protection, c.SlipPts, c.DelaySeconds)
	}
	return fmt.Sprintf("%s_%s_C%.0f_D%d", c.EntryPolicy, c.Protection, c.SlipPts, c.DelaySeconds)
}

// compositeProtection は停止純部品を使用するG3/G4だけを識別します。
//
// 引数: receiver(*ActualBook)は口座。返り値: boolはG3/G4なら真です。
func (b *ActualBook) compositeProtection() bool {
	return b.composite != nil && b.composite.Config.Protection != ProtectG0
}

// protectionScope は固定場・限月を純部品の名前付き境界へ写します。
//
// 引数: receiver(*ActualBook)は新口座。返り値: guard.Scopeは同じ場・限月・開始です。
func (b *ActualBook) protectionScope() guard.Scope {
	return guard.Scope{Session: b.result.Session.ID, Contract: b.composite.Contract, Start: b.result.Session.Start}
}

// validateProtectionPublication は純部品の公開APIで未来/場/pivotを原行なしに検査します。
//
// 引数: publication(guard.Publication)、side(int)、at(float64)は明示根拠・方向・配送時計。
// 返り値: errorは不正です。検査用純状態は注文/約定/実口座へ接続しません。
func (b *ActualBook) validateProtectionPublication(publication guard.Publication, side int, at float64) error {
	state, err := guard.NewState(guard.Entry{Scope: b.protectionScope(), Policy: guard.G3, Side: side, Price: 1000, At: at, InitialQuantity: 1})
	if err != nil {
		return err
	}
	_, _, err = guard.Advance(state, guard.Input{At: at, Sequence: 1, Phase: guard.PreFill, Remaining: 1, Publication: &publication})
	return err
}

// protectionP は公開終値とprior pivotの構造否定だけを三値へ写します。
//
// 引数: p(guard.Publication)、side(int)は公開根拠と方向。返り値: guard.TruthはPです。
func protectionP(p guard.Publication, side int) guard.Truth {
	if p.Close == nil || p.PriorPivot == nil {
		return guard.Unknown
	}
	if float64(side)*(*p.Close-p.PriorPivot.Price) < 0 {
		return guard.True
	}
	return guard.False
}

// widthTruth は三値を旧監査型へ写し、G0の公表監査を同体にします。
//
// 引数: value(guard.Truth)は検査済み三値。返り値: WidthTruthは未知ならnilを保持します。
func widthTruth(value guard.Truth) WidthTruth {
	if value == guard.Unknown {
		return WidthTruth{}
	}
	passed := value == guard.True
	return WidthTruth{Known: true, Passed: &passed}
}

// OnProtectionObservation は両方向の公表済みV/C/M/pivotだけを保管します。
//
// 引数: observation(ProtectionObservation)は外部で窓形成/出典確認済みの一公表。
// 返り値: errorは破損・未来・別場・改竄です。MTM・注文・指標の形成は行いません。
func (b *ActualBook) OnProtectionObservation(observation ProtectionObservation) error {
	if err := b.ready(); err != nil {
		return err
	}
	w := b.composite
	if w == nil || !finiteActual(observation.At) || observation.At < b.lastEventAt || w.HaveClock && observation.At < w.At {
		return b.stop(fmt.Errorf("新保護公表の口座又は時計が不正です"))
	}
	for _, checksum := range []string{observation.FrameSHA, observation.ResultSHA} {
		decoded, err := hex.DecodeString(checksum)
		if err != nil || len(decoded) != 32 {
			return b.stop(fmt.Errorf("新保護公表の出典SHAが不正です"))
		}
	}
	buy, sell := observation.Buy, observation.Sell
	if buy.ID != sell.ID || buy.Ordinal != sell.Ordinal || buy.End != sell.End || buy.AvailableAt != sell.AvailableAt || buy.C != sell.C || !reflect.DeepEqual(buy.V, sell.V) || !reflect.DeepEqual(buy.Close, sell.Close) {
		return b.stop(fmt.Errorf("両方向の共通公表値が不一致です"))
	}
	if (buy.M == guard.Unknown) != (sell.M == guard.Unknown) || buy.M == guard.True && sell.M == guard.True {
		return b.stop(fmt.Errorf("同じMACD増分の両方向Mが不整合です"))
	}
	for _, item := range []struct {
		side int
		p    guard.Publication
	}{{1, buy}, {-1, sell}} {
		if err := b.validateProtectionPublication(item.p, item.side, observation.At); err != nil {
			return b.stop(err)
		}
		if previous := w.Last[item.side]; previous != nil {
			if item.p.ID == previous.ID {
				if !reflect.DeepEqual(item.p, *previous) {
					return b.stop(fmt.Errorf("同ID新保護公表の内容変更"))
				}
			} else if item.p.End <= previous.End || item.p.Ordinal <= previous.Ordinal {
				return b.stop(fmt.Errorf("新保護公表の後退"))
			}
		}
	}
	duplicate := w.Last[1] != nil && buy.ID == w.Last[1].ID
	if duplicate && (w.LastFrameSHA != observation.FrameSHA || w.LastResultSHA != observation.ResultSHA) {
		return b.stop(fmt.Errorf("同ID新保護公表の出典SHA変更"))
	}
	if !duplicate {
		for _, item := range []struct {
			side int
			p    guard.Publication
		}{{1, buy}, {-1, sell}} {
			p := valueCopy(item.p)
			w.Latest[item.side], w.Last[item.side] = &p, &p
		}
		w.LastFrameSHA, w.LastResultSHA = observation.FrameSHA, observation.ResultSHA
		w.LatestSource = &ProtectionSource{PublicationID: buy.ID, DeliveredAt: observation.At, FrameSHA: observation.FrameSHA, ResultSHA: observation.ResultSHA}
	}
	if w.Config.Protection == ProtectG0 {
		for _, item := range []struct {
			side int
			p    guard.Publication
		}{{1, buy}, {-1, sell}} {
			p := item.p
			o := WidthObservation{Session: p.Scope.Session, Contract: p.Scope.Contract, Side: item.side, PublicationID: p.ID, Ordinal: int(p.Ordinal), End: p.End, AvailableAt: p.AvailableAt,
				C: widthTruth(p.C), M: widthTruth(p.M), P: widthTruth(protectionP(p, item.side)), FrameSHA: observation.FrameSHA, ResultSHA: observation.ResultSHA}
			if err := b.OnWidthObservation(observation.At, o); err != nil {
				return b.stop(err)
			}
		}
	}
	w.At, w.HaveClock = observation.At, true
	if !duplicate {
		w.Observations++
	}
	return nil
}

// ResetProtectionObservation は未知境界を保管し、実保護床を解除しません。
//
// 引数: at(float64)、reason(string)は配送時計と理由。返り値: errorは時計/空理由です。
func (b *ActualBook) ResetProtectionObservation(at float64, reason string) error {
	if err := b.ready(); err != nil {
		return err
	}
	w := b.composite
	if w == nil || reason == "" || !finiteActual(at) || at < b.lastEventAt || w.HaveClock && at < w.At {
		return b.stop(fmt.Errorf("新保護失効の設定/時計が不正です"))
	}
	w.Latest = map[int]*guard.Publication{}
	w.LatestSource = nil
	w.ResetGeneration++
	w.ResetReason = reason
	w.At, w.HaveClock = at, true
	if w.Config.Protection == ProtectG0 {
		return b.ResetWidthObservation(at, reason)
	}
	return nil
}

// compositeATR は実取得で一度固定されたnative尺度を証拠付きで渡します。
//
// 引数: p(*ActualPosition)は実建玉。返り値: *guard.Evidenceは公開ATR又は未知nilです。
func compositeATR(p *ActualPosition) *guard.Evidence {
	if p.ATR == nil {
		return nil
	}
	return &guard.Evidence{Value: p.ATR.Value, AvailableAt: p.ATR.Available, SourceID: fmt.Sprintf("nativeATR/%.9f/%.9f", p.ATR.Available, p.ATR.Nominal)}
}

// initializeCompositePosition は実新規約定の時点でだけV/Hを固定します。
//
// 引数: p(*ActualPosition)は今取得した実建玉。返り値: errorは純状態の出典/価格不正です。
func (b *ActualBook) initializeCompositePosition(p *ActualPosition) error {
	if !b.compositeProtection() {
		return nil
	}
	w := b.composite
	if w.HaveClock && w.At > p.EntryQuote.Time {
		return fmt.Errorf("新規約定より未来の新保護配送時計")
	}
	var entryV *guard.Evidence
	if latest := w.Latest[p.Side]; latest != nil && latest.V != nil {
		entryV = &guard.Evidence{Value: *latest.V, AvailableAt: latest.AvailableAt, SourceID: "V5/" + latest.ID}
	}
	state, err := guard.NewState(guard.Entry{Scope: b.protectionScope(), Policy: guard.Policy(w.Config.Protection), Side: p.Side, Price: p.EntryPrice, At: p.EntryQuote.Time,
		InitialQuantity: p.InitialQuantity, SlipPoints: b.result.Config.SlipPts, EntryV: entryV, ATR: compositeATR(p)})
	if err != nil {
		return err
	}
	snapshot := state.Snapshot()
	w.Positions[p.ID] = &compositePosition{state: state, resetGeneration: w.ResetGeneration, audit: CompositePositionAudit{PositionID: p.ID, Initial: snapshot, InitialSource: valueCopy(w.LatestSource), Last: snapshot, Requests: []ProtectionRequest{}}}
	return nil
}

// finishCompositePosition は実返済済みの残0を純状態へ反映します。
//
// 引数: p(*ActualPosition)、at(float64)は実終了と現在原行時計。返り値: errorは所有又は順序破損です。
func (b *ActualBook) finishCompositePosition(p *ActualPosition, at float64) error {
	if b.composite.HaveClock && b.composite.At > at {
		return fmt.Errorf("終了より未来の新保護配送時計")
	}
	ps := b.composite.Positions[p.ID]
	if ps == nil {
		return fmt.Errorf("新保護に実建玉の状態がありません")
	}
	if ps.audit.Last.Finished {
		return nil
	}
	ps.sequence++
	next, _, err := guard.Advance(ps.state, guard.Input{At: at, Sequence: ps.sequence, Phase: guard.AfterSource, Remaining: p.Quantity, Reserved: p.Reserved})
	if err != nil {
		return err
	}
	ps.state, ps.audit.Last = next, next.Snapshot()
	return nil
}

// observeCompositePosition は純判定と実所有を照合してから未予約分だけ実予約します。
//
// 引数: p(*ActualPosition)、point(MTMPoint)、issue(bool)は当原行・段階・新要求可否。
// 返り値: errorは純式/会計/因果差です。費用・Source・約定モデルを置換しません。
func (b *ActualBook) observeCompositePosition(p *ActualPosition, point MTMPoint, issue bool) error {
	w := b.composite
	if w.HaveClock && w.At > point.Quote.Time {
		return fmt.Errorf("MTMより未来の新保護配送時計")
	}
	ps := w.Positions[p.ID]
	if ps == nil {
		return fmt.Errorf("新保護に実建玉の状態がありません")
	}
	phase := guard.Phase(point.Phase)
	if issue != (phase == guard.AfterSource) {
		return fmt.Errorf("新保護の要求段階とissueが不一致")
	}
	if ps.resetGeneration != w.ResetGeneration {
		ps.sequence++
		next, _, err := guard.Advance(ps.state, guard.Input{At: point.Quote.Time, Sequence: ps.sequence, Phase: phase, Remaining: p.Quantity, Reserved: p.Reserved, ResetReason: w.ResetReason})
		if err != nil {
			return err
		}
		ps.state, ps.resetGeneration = next, w.ResetGeneration
	}
	ps.sequence++
	mark := point.MarkPrice
	in := guard.Input{At: point.Quote.Time, Sequence: ps.sequence, Phase: phase, Mark: &mark, Remaining: p.Quantity, Reserved: p.Reserved, ATR: compositeATR(p), Publication: w.Latest[p.Side]}
	next, decision, err := guard.Advance(ps.state, in)
	if err != nil {
		return err
	}
	snapshot := next.Snapshot()
	if decision.UnitNetYen == nil || *decision.UnitNetYen != point.UnitNet || decision.GainPoints == nil || *decision.GainPoints != point.GainPoints || snapshot.Peak == nil || *snapshot.Peak != p.PeakGain {
		return fmt.Errorf("新保護の純単位額/価格差/峰が実MTMと不一致")
	}
	step := ProtectionStep{Point: point, State: snapshot, Decision: decision, Source: valueCopy(w.LatestSource)}
	if decision.ThresholdLockedNow {
		if ps.audit.FirstThresholdLock != nil {
			return fmt.Errorf("H固定の重複")
		}
		ps.audit.FirstThresholdLock = widthPointer(valueCopy(step))
	}
	if decision.ActivatedNow {
		if p.ProtectionActive || p.Activation != nil {
			return fmt.Errorf("新保護の起動重複")
		}
		p.ProtectionActive = true
		p.Activation = widthPointer(valueCopy(point))
		p.ActivationReason = string(w.Config.Protection) + "一定の費用後単位利益で必須起動"
		ps.audit.Activation = widthPointer(valueCopy(step))
	}
	if p.ProtectionActive != snapshot.Active {
		return fmt.Errorf("新保護の起動旗が実所有と不一致")
	}
	if snapshot.Floor != nil {
		if p.FloorGain != nil && *snapshot.Floor < *p.FloorGain {
			return fmt.Errorf("新保護床の不利緩和")
		}
		if p.FloorGain == nil || *snapshot.Floor > *p.FloorGain {
			p.FloorGain = valueCopy(snapshot.Floor)
			p.FloorUpdated = widthPointer(valueCopy(point))
			ps.audit.LastFloorUpdate = widthPointer(valueCopy(step))
		}
	}
	if decision.NarrowedNow {
		ps.audit.FirstNarrow = widthPointer(valueCopy(step))
	}
	if decision.FloorHit && p.FirstFloorHit == nil {
		p.FirstFloorHit = widthPointer(valueCopy(point))
		ps.audit.FirstFloorHit = widthPointer(valueCopy(step))
	}
	if decision.FloorHit && p.Quantity == p.Reserved && ps.audit.FirstFullReservedHit == nil {
		ps.audit.FirstFullReservedHit = widthPointer(valueCopy(step))
	}
	if decision.EligibleExitQuantity > 0 {
		if !issue || decision.EligibleExitQuantity != p.Quantity-p.Reserved {
			return fmt.Errorf("新保護の返済可能量が実freeと不一致")
		}
		before := p.Reserved
		id, err := b.requestExit(p, decision.EligibleExitQuantity, point.Quote.Time, point.Quote, string(w.Config.Protection)+"一定利益後の費用床と非緩和追尾", "", "", &point)
		if err != nil {
			return err
		}
		if p.Reserved != before+decision.EligibleExitQuantity {
			return fmt.Errorf("純判定から実予約への量が不一致")
		}
		ps.audit.Requests = append(ps.audit.Requests, ProtectionRequest{step, id, decision.EligibleExitQuantity, before, p.Reserved})
	}
	ps.state, ps.audit.Last, ps.audit.LastStep = next, snapshot, widthPointer(valueCopy(step))
	return nil
}

// CompositeAudit は旧結果JSONとは別に新入口/保護の監査を独立複写します。
//
// 引数: receiver(*ActualBook)は口座。返り値: CompositeAuditは現在の外側監査です。
func (b *ActualBook) CompositeAudit() CompositeAudit {
	if b == nil || b.composite == nil {
		return CompositeAudit{}
	}
	w := b.composite
	audit := CompositeAudit{Key: b.CompositeKey(), Config: w.Config, Contract: w.Contract, QuietSeconds: b.quietDuration(), Observations: w.Observations, Resets: w.ResetGeneration,
		Positions: []CompositePositionAudit{}, EntryBatches: w.Batches, LatestSource: w.LatestSource, EntryAttempts: w.entryAttempts, LifetimeTerminals: w.lifetimeTerminals}
	for _, p := range b.result.EntryOpportunities {
		if closing, exists := w.firstClosings[sourceKey(p.Source.Method, p.Source.SignalID)]; exists {
			audit.FirstSourceClosings = append(audit.FirstSourceClosings, closing)
		}
	}
	for _, p := range b.result.Positions {
		if ps := w.Positions[p.ID]; ps != nil {
			audit.Positions = append(audit.Positions, ps.audit)
		}
	}
	return valueCopy(audit)
}
