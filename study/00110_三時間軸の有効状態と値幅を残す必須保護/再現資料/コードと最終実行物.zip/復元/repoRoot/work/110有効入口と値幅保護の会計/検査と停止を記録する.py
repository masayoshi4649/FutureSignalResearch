"""人工Go検査と旧停止物の前後不変を確認して110Actorを一度だけ停止する。"""
from __future__ import annotations

import datetime
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent.parent
OLD = HERE.parent / '一定利益と三時間軸の保護会計'
GUARD = HERE.parent / '110利益保護の純状態'
EXPECTED = {
    OLD / '停止.json': '567b0bc6354b5d3d47d57f1cc3f91335a661d359ea4c81ae02f83653f3970687',
    GUARD / '停止.json': '4172d88abd3e7250228bc3f30c1457b83a95f589a925d264991d8650de70474c',
}


def sha(path: Path) -> str:
    """機能: SHA256を計算する。引数: path(Path)は小さいコード。返り値: str。"""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ref(path: Path) -> dict:
    """機能: 正確な参照を作る。引数: path(Path)。返り値: dictはpath/sha256。"""
    return {'path': path.relative_to(ROOT).as_posix(), 'sha256': sha(path)}


def owned() -> dict:
    """機能: 所有コードと仕様を固定する。引数: なし。返り値: dictは相対path/SHA。"""
    files = [p for p in HERE.iterdir() if p.is_file() and
             (p.suffix in {'.go', '.py', '.md', '.patch'} or p.name in {'go.mod', 'go.sum', '由来.json'})]
    return {p.relative_to(ROOT).as_posix(): sha(p) for p in sorted(files)}


def verify_old() -> list[dict]:
    """機能: 旧Actor/停止guardの全所有を認証する。引数: なし。返り値: list[dict]。"""
    result = []
    for path, expected in EXPECTED.items():
        if sha(path) != expected:
            raise RuntimeError(f'停止指紋不一致: {path}')
        obj = json.loads(path.read_text(encoding='utf-8-sig'))
        codes = obj['所有コードSHA256']
        for name, digest in codes.items():
            code = Path(name)
            if not code.is_absolute():
                code = ROOT / code
            if sha(code) != digest:
                raise RuntimeError(f'旧停止所有不一致: {name}')
        result.append({**ref(path), '所有コード一致': len(codes), '全不変': True})
    return result


def run(argv: list[str], name: str) -> dict:
    """機能: 人工検査を実行保存する。引数: argv(list[str]),name(str)。返り値: dict。"""
    p = subprocess.run(argv, cwd=HERE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output = p.stdout.decode('utf-8', errors='strict')
    file = HERE / '検査' / name
    file.write_text(output, encoding='utf-8')
    if p.returncode:
        raise RuntimeError(f'{argv} が失敗: {output[-4000:]}')
    return {'argv': argv, 'exit_code': p.returncode, 'output': ref(file)}


def main() -> None:
    """機能: 人工検査/前後指紋/停止を保存する。引数: なし。返り値: None。"""
    if (HERE / '停止.json').exists():
        raise RuntimeError('既存停止への上書き禁止')
    (HERE / '検査').mkdir(exist_ok=True)
    differences = []
    for p in sorted(HERE.glob('*.go')):
        before = (OLD / p.name).read_text(encoding='utf-8').splitlines(True) if (OLD / p.name).exists() else []
        differences.extend(difflib.unified_diff(before, p.read_text(encoding='utf-8').splitlines(True),
                                               fromfile='停止109/' + p.name, tofile='会計110/' + p.name))
    (HERE / '機能差分.patch').write_text(''.join(differences), encoding='utf-8')
    old_before = verify_old()
    before = owned()
    steps = [run(['go', 'test', '-json', '-coverprofile=検査/coverage.out', '-count=1', './...'], 'Go試験.jsonl'),
             run(['go', 'vet', './...'], 'Go静的検査.txt'),
             run(['go', 'build', './...'], 'Goビルド.txt'),
             run(['go', 'tool', 'cover', '-func=検査/coverage.out'], 'Go網羅率.txt')]
    old_after = verify_old()
    if owned() != before or old_before != old_after:
        raise RuntimeError('検査前後にコード差')
    events = [json.loads(line) for line in (HERE / '検査' / 'Go試験.jsonl').read_text(encoding='utf-8').splitlines()]
    tests = [x for x in events if x.get('Action') == 'pass' and x.get('Test')]
    summary = {'成功': True, '実行': steps, '主テスト': sum('/' not in x['Test'] for x in tests),
               '全テスト': len(tests), '110主テスト': sum('/' not in x['Test'] and x['Test'].startswith('Test110') for x in tests),
               '旧対照': '人工16系列、各時点Actual/Width/Early/Clock全JSONを108と109へ無除外比較',
               '網羅率': (HERE / '検査' / 'Go網羅率.txt').read_text(encoding='utf-8').splitlines()[-1],
               'コード前後不変': True, '旧所有前後不変': True, '市場入力読取': False}
    check = HERE / '検査' / 'Go確認.json'
    check.write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    stop = {'成功': True, '停止': True, '範囲': 'E0/L0・E2/L0/L1、G0/G3/G4の別Actor。手製Source/気配/尺度による人工のみ',
            'module': 'github.com/masayoshi4649/SessionTradeExecuter/miniprofit110', 'package': 'miniprofit110',
            'UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'Go版': subprocess.check_output(['go', 'version'], cwd=HERE).decode().strip(),
            '所有コードSHA256': before, '仕様': ref(HERE / '仕様.md'), 'README': ref(HERE / 'README.md'),
            '元停止と純部品': old_after, '検査': ref(check), '人工テスト': {k: summary[k] for k in ['主テスト', '全テスト', '110主テスト', '網羅率']},
            '検査前後コード不変': True, '旧所有コード前後不変': True, '市場入力本文読取': False,
            '金融市場実行': False, '未使用11月09日読取': False,
            '未実施': ['純E2と実公表の36金融接続', '保存器独立検算との結合', '既使用70の金融と頻度', 'mini実板/実約定', '未使用場'],
            '研究目標達成': False, '採用': False}
    path = HERE / '停止.json'
    path.write_text(json.dumps(stop, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'停止': ref(path), '検査': ref(check), '人工テスト': stop['人工テスト'], '所有': len(before)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
