package miniprofit110

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strings"
	"testing"

	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	old109 "github.com/masayoshi4649/SessionTradeExecuter/miniprofitthreeproposal"
	old108 "github.com/masayoshi4649/SessionTradeExecuter/miniquietlength108"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloor110"
)

type compositeHarness struct {
	b                  *ActualBook
	old                *old108.ActualBook
	old109             *old109.ActualBook
	src                *source
	s                  Session
	start              float64
	method             string
	side               int
	index              int64
	atr                float64
	publicationOrdinal uint64
	compared           int
}

// newCompositeHarness は非市場のSource通知器具と新口座を作ります。
//
// 引数: t(*testing.T)、entry/保護政策、side/cost/delay/night/compareは人工条件。
// 返り値: *compositeHarnessは旧108との同体比較も可能な人工経路です。
func newCompositeHarness(t *testing.T, entry CompositeEntryPolicy, policy CompositeProtection, side int, cost float64, delay int, night, compare bool) *compositeHarness {
	t.Helper()
	s, start, method := lengthSession108(night)
	cfg := CompositeConfig{EntryPolicy: entry, EntryLifetime: LifetimeL0, Protection: policy, SlipPts: cost, DelaySeconds: delay, USOpen: s.USOpen}
	b, err := NewCompositeBook(s, cfg, "手製限月")
	if err != nil {
		t.Fatal(err)
	}
	h := &compositeHarness{b: b, src: newSource(), s: s, start: start, method: method, side: side, atr: 20}
	if compare {
		h.old109, err = old109.NewCompositeBook(s, old109.CompositeConfig{EntryPolicy: old109.EntryE0, Protection: old109.ProtectG0, SlipPts: cost, DelaySeconds: delay, USOpen: s.USOpen}, "手製限月")
		if err != nil {
			t.Fatal(err)
		}
		c := old108.ActorConfig{Policy: "P0", SlipPts: cost, DelaySeconds: delay, EntryTiming: old108.TimingQuietDeferred, USOpen: s.USOpen, ActivationPolicy: old108.ActivationLD10}
		h.old, err = old108.NewWidthBookWithQuiet(s, c, "W0", "手製限月", 1200)
		if err != nil {
			t.Fatal(err)
		}
	}
	return h
}

// compositeEqual は型名の違いに依存せず全JSONを無除外で比較します。
//
// 引数: t(*testing.T)、a/b(any)、label(string)は比較対象。返り値: ありません。
func compositeEqual(t *testing.T, a, b any, label string) {
	t.Helper()
	x, err := json.Marshal(a)
	if err != nil {
		t.Fatal(err)
	}
	y, err := json.Marshal(b)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(x, y) {
		t.Fatalf("%sの全JSONが不一致\n%s\n%s", label, x, y)
	}
}

// compare は旧108の実APIと四JSONを各時点で照合します。
//
// 引数: t(*testing.T)は検査。返り値: ありません。
func (h *compositeHarness) compare(t *testing.T) {
	t.Helper()
	if h.old == nil {
		return
	}
	compositeEqual(t, h.b.Snapshot(), h.old.Snapshot(), "ActualResult")
	compositeEqual(t, h.b.WidthAudit(), h.old.WidthAudit(), "WidthAudit")
	compositeEqual(t, h.b.EarlyAudit(), h.old.EarlyAudit(), "EarlyAudit")
	compositeEqual(t, h.b.ClockAudit(), h.old.ClockAudit(), "ClockAudit")
	compositeEqual(t, h.b.Snapshot(), h.old109.Snapshot(), "109ActualResult")
	compositeEqual(t, h.b.WidthAudit(), h.old109.WidthAudit(), "109WidthAudit")
	compositeEqual(t, h.b.EarlyAudit(), h.old109.EarlyAudit(), "109EarlyAudit")
	compositeEqual(t, h.b.ClockAudit(), h.old109.ClockAudit(), "109ClockAudit")
	h.compared++
}

// feed は同じ人工SourceDeltaを一度だけ形成して新旧へ配送します。
//
// 引数: t(*testing.T)、at/move(float64)、bad(bool)、news(...native.Signal)は人工原行。
// 返り値: ありません。市場や戦略を読まない手製入力です。
func (h *compositeHarness) feed(t *testing.T, at, move float64, bad bool, news ...native.Signal) {
	t.Helper()
	o := observation(at, move, h.side, h.index, bad)
	o.ATR, o.E01.ATR = h.atr, h.atr
	if h.atr == 0 {
		o.E01.ATRAvailable, o.E01.ATRNominal = 0, 0
	}
	line := h.index + 20
	h.index++
	for i := range news {
		if news[i].Action == "new" {
			var e sourceEvidence
			_ = json.Unmarshal(news[i].Evidence, &e)
			e.Method = "NK225_" + h.method
			news[i].Evidence, _ = json.Marshal(e)
		}
	}
	batch := h.src.step(stamp(o, line), news)
	batch.Method = h.method
	if err := h.b.OnNativeStep(o, line, []NativeBatch{batch}); err != nil {
		t.Fatal(err)
	}
	if h.old109 != nil {
		if err := h.old109.OnNativeStep(o, line, []old109.NativeBatch{{Method: batch.Method, Delta: batch.Delta}}); err != nil {
			t.Fatal(err)
		}
	}
	if h.old != nil {
		if err := h.old.OnNativeStep(o, line, []old108.NativeBatch{{Method: batch.Method, Delta: batch.Delta}}); err != nil {
			t.Fatal(err)
		}
	}
	h.compare(t)
}

// grid はE0又は一括E2の人工5分枠を配送します。
//
// 引数: t(*testing.T)、at(float64)、gate(EntryBatchGate)は検査と枠/callback。返り値: ありません。
func (h *compositeHarness) grid(t *testing.T, at float64, gate EntryBatchGate) {
	t.Helper()
	id := ""
	if h.b.composite.Config.EntryPolicy == EntryE2 {
		id = fmt.Sprintf("人工入口/%.0f", at)
	}
	if err := h.b.OnCompositeEntryGrid(at, id, gate); err != nil {
		t.Fatal(err)
	}
	if h.old109 != nil {
		if err := h.old109.OnCompositeEntryGrid(at, "", nil); err != nil {
			t.Fatal(err)
		}
	}
	if h.old != nil {
		if err := h.old.OnEntryGrid(at); err != nil {
			t.Fatal(err)
		}
	}
	h.compare(t)
}

// pub は形成済みという契約の人工3分V/C/Mを配送します。
//
// 引数: t(*testing.T)、end(float64)、v(*float64)、c/m(guard.Truth)、pivot(*guard.Pivot)は公表値。
// 返り値: ありません。G0対照へも同じ公表監査を配送します。
func (h *compositeHarness) pub(t *testing.T, end float64, v *float64, c, m guard.Truth, pivot *guard.Pivot) {
	t.Helper()
	h.publicationOrdinal++
	scope := guard.Scope{Session: h.s.ID, Contract: "手製限月", Start: h.s.Start}
	close := 1005.0
	p := guard.Publication{Scope: scope, ID: WidthPublicationID(h.s.ID, "手製限月", end), Ordinal: h.publicationOrdinal, End: end, AvailableAt: end, V: v, C: c, M: m, Close: &close}
	o := ProtectionObservation{At: end, Buy: p, Sell: p, FrameSHA: strings.Repeat("a", 64), ResultSHA: strings.Repeat("b", 64)}
	if m == guard.True {
		if h.side > 0 {
			o.Sell.M = guard.False
		} else {
			o.Buy.M = guard.False
		}
	}
	if pivot != nil {
		if h.side > 0 {
			o.Buy.PriorPivot = pivot
		} else {
			o.Sell.PriorPivot = pivot
		}
	}
	if err := h.b.OnProtectionObservation(o); err != nil {
		t.Fatal(err)
	}
	if h.old109 != nil {
		var converted old109.ProtectionObservation
		encoded, _ := json.Marshal(o)
		if err := json.Unmarshal(encoded, &converted); err != nil {
			t.Fatal(err)
		}
		if err := h.old109.OnProtectionObservation(converted); err != nil {
			t.Fatal(err)
		}
	}
	if h.old != nil {
		for _, item := range []struct {
			side int
			p    guard.Publication
		}{{1, o.Buy}, {-1, o.Sell}} {
			p := item.p
			ct, mt, pt := widthTruth(p.C), widthTruth(p.M), widthTruth(protectionP(p, item.side))
			old := old108.WidthObservation{Session: h.s.ID, Contract: "手製限月", Side: item.side, PublicationID: p.ID, Ordinal: int(p.Ordinal), End: p.End, AvailableAt: p.AvailableAt,
				C: old108.WidthTruth{Known: ct.Known, Passed: ct.Passed}, M: old108.WidthTruth{Known: mt.Known, Passed: mt.Passed}, P: old108.WidthTruth{Known: pt.Known, Passed: pt.Passed}, FrameSHA: o.FrameSHA, ResultSHA: o.ResultSHA}
			if err := h.old.OnWidthObservation(end, old); err != nil {
				t.Fatal(err)
			}
		}
	}
	h.compare(t)
}

// forceAndFinish は人工Sourceの残量を実後続行で閉じ、架空約定なしの完了を確認します。
//
// 引数: t(*testing.T)、move(float64)は検査と最終人工価格。返り値: ActualResultは終了実口座です。
func (h *compositeHarness) forceAndFinish(t *testing.T, move float64) ActualResult {
	t.Helper()
	batch := h.src.force(h.s.ForceClose)
	batch.Method = h.method
	if err := h.b.OnNativeForce(h.s.ForceClose, []NativeBatch{batch}); err != nil {
		t.Fatal(err)
	}
	if h.old109 != nil {
		if err := h.old109.OnNativeForce(h.s.ForceClose, []old109.NativeBatch{{Method: batch.Method, Delta: batch.Delta}}); err != nil {
			t.Fatal(err)
		}
	}
	if h.old != nil {
		if err := h.old.OnNativeForce(h.s.ForceClose, []old108.NativeBatch{{Method: batch.Method, Delta: batch.Delta}}); err != nil {
			t.Fatal(err)
		}
	}
	h.compare(t)
	h.feed(t, h.s.ForceClose+1, move, false)
	r, err := h.b.Finish()
	if err != nil {
		t.Fatal(err)
	}
	if h.old109 != nil {
		if _, err := h.old109.Finish(); err != nil {
			t.Fatal(err)
		}
	}
	if h.old != nil {
		if _, err := h.old.Finish(); err != nil {
			t.Fatal(err)
		}
	}
	h.compare(t)
	if !r.Complete || r.Totals.OpenBuy+r.Totals.OpenSell+r.Totals.PendingBuy+r.Totals.PendingSell != 0 {
		t.Fatal("残玉/予約が0でない")
	}
	return r
}

// TestCompositeG0Exact は非ゼロ実取引の全時点四JSONを旧108と同体比較します。
//
// 引数: t(*testing.T)はDay/US・買売・C0/C5・D0/D1人工検査。返り値: ありません。
func TestCompositeG0Exact(t *testing.T) {
	series, points := 0, 0
	for _, night := range []bool{false, true} {
		for _, side := range []int{1, -1} {
			for _, cost := range []float64{0, 5} {
				for _, delay := range []int{0, 1} {
					h := newCompositeHarness(t, EntryE0, ProtectG0, side, cost, delay, night, true)
					h.feed(t, h.start+601, 0, false, birth("G0-A", side, 6), birth("G0-B", side, 6))
					h.feed(t, h.start+602, 0, false)
					h.grid(t, h.start+900, nil)
					v := 80.0
					h.pub(t, h.start+1080, &v, guard.False, guard.False, nil)
					h.feed(t, h.start+1199, 0, false)
					h.grid(t, h.start+1200, nil)
					h.feed(t, h.start+1201, 0, false)
					h.feed(t, h.start+1202, 70, false)
					h.feed(t, h.start+1203, 30, false, closeSignal("G0-部分", "玉-G0-A", side, 2))
					if len(h.b.result.Fills) != 2 {
						t.Fatal("返済要求の同原行で約定した")
					}
					h.feed(t, h.start+1204, 25, false)
					h.feed(t, h.s.ForceClose-601, 25, false, birth("G0-取消", side, 4))
					h.feed(t, h.s.ForceClose-600, 25, false)
					h.grid(t, h.s.ForceClose-600, nil)
					r := h.forceAndFinish(t, 25)
					if r.Totals.EntryQuantity != 10 || len(r.Positions) != 2 || r.Totals.NetYen == 0 || r.Metrics.CapClippedEntries == 0 || r.Metrics.CancelledEntries == 0 || r.Metrics.ProtectionExitFills == 0 {
						t.Fatal("同体比較が必要な非ゼロ経路を通っていない")
					}
					series++
					points += h.compared
				}
			}
		}
	}
	t.Logf("非ゼロ系列%d、四JSON全時点%d", series, points)
}
