package miniprofit110

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strings"
	"testing"

	baseline "github.com/masayoshi4649/SessionTradeExecuter/miniearlyguard"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
)

// baselineBatches は停止68011へ全Deltaを順序・nilも含めて対応します。
//
// 引数: in([]NativeBatch)は独立生成した手製通知です。
// 返り値: []baseline.NativeBatchは外側named型だけを変換した値です。
func baselineBatches(in []NativeBatch) []baseline.NativeBatch {
	if in == nil {
		return nil
	}
	out := make([]baseline.NativeBatch, len(in))
	for i, b := range in {
		out[i] = baseline.NativeBatch{Method: b.Method, Delta: b.Delta}
	}
	return out
}

// baselineWidth は公表根拠の全欄を旧68011のnamed型へ明示対応します。
//
// 引数: o(WidthObservation)は手製の確定済C/M/Pです。
// 返り値: baseline.WidthObservationは時計・採否・SHAを変更しない値です。
func baselineWidth(o WidthObservation) baseline.WidthObservation {
	return baseline.WidthObservation{Session: o.Session, Contract: o.Contract, Side: o.Side, PublicationID: o.PublicationID, Ordinal: o.Ordinal, End: o.End, AvailableAt: o.AvailableAt, C: baseline.WidthTruth{Known: o.C.Known, Passed: valueCopy(o.C.Passed)}, M: baseline.WidthTruth{Known: o.M.Known, Passed: valueCopy(o.M.Passed)}, P: baseline.WidthTruth{Known: o.P.Known, Passed: valueCopy(o.P.Passed)}, FrameSHA: o.FrameSHA, ResultSHA: o.ResultSHA}
}

// quietBook は107対象W0/W1/E1の手製口座だけを作ります。
//
// 引数: s(Session)、policy/timing(string)、cost(float64)、delay(int)は人工場と比較条件です。
// 返り値: *ActualBook/errorは旧と同じ公開constructorの結果です。
func quietBook(s Session, policy, timing string, cost float64, delay int) (*ActualBook, error) {
	cfg := ActorConfig{Policy: "P0", EntryTiming: timing, ActivationPolicy: ActivationLD10, USOpen: s.USOpen, SlipPts: cost, DelaySeconds: delay}
	if policy == "E1" {
		cfg.ActivationPolicy = ActivationE1
		return NewEarlyBook(s, cfg, "手製限月")
	}
	return NewWidthBook(s, cfg, policy, "手製限月")
}

// Test107B5QAllJSON は旧68011の別namespace・独立BookへB5Q全欄を照合します。
//
// 引数: t(*testing.T)は買売・ATR既知未知・W0/W1/E1・C/Dの非市場試験器です。
// 返り値: なし。全時点と最終のResult/WidthAudit/EarlyAuditを除外0で比較します。
func Test107B5QAllJSON(t *testing.T) {
	points, finals := 0, 0
	for _, side := range []int{1, -1} {
		for _, unknown := range []bool{false, true} {
			f := earlyWave(side, unknown)
			original, _ := json.Marshal(f)
			for _, policy := range []string{"W0", "W1", "E1"} {
				for _, cost := range []float64{0, 5} {
					for _, delay := range []int{0, 1} {
						b, err := quietBook(f.Session, policy, "B5Q", cost, delay)
						if err != nil {
							t.Fatal(err)
						}
						cfg := baseline.ActorConfig{Policy: "P0", EntryTiming: "B5Q", ActivationPolicy: baseline.ActivationLD10, SlipPts: cost, DelaySeconds: delay}
						var old *baseline.ActualBook
						if policy == "E1" {
							cfg.ActivationPolicy = baseline.ActivationE1
							old, err = baseline.NewEarlyBook(f.Session, cfg, "手製限月")
						} else {
							old, err = baseline.NewWidthBook(f.Session, cfg, policy, "手製限月")
						}
						if err != nil {
							t.Fatal(err)
						}
						pub := widthObs(side, 1, f.Grids[0]-180, WidthTruth{})
						if err = b.OnWidthObservation(f.Grids[0]-3, pub); err != nil {
							t.Fatal(err)
						}
						if err = old.OnWidthObservation(f.Grids[0]-3, baselineWidth(pub)); err != nil {
							t.Fatal(err)
						}
						for _, ev := range f.Events {
							var a, z error
							switch ev.Kind {
							case "quote":
								s := f.Steps[ev.Index]
								a = b.OnNativeStep(s.Observation, s.SourceLine, s.Batches)
								z = old.OnNativeStep(s.Observation, s.SourceLine, baselineBatches(s.Batches))
							case "grid":
								a = b.OnEntryGrid(f.Grids[ev.Index])
								z = old.OnEntryGrid(f.Grids[ev.Index])
							case "timer":
								s := f.Timers[ev.Index]
								a = b.OnNativeForce(s.At, s.Batches)
								z = old.OnNativeForce(s.At, baselineBatches(s.Batches))
							}
							if a != nil || z != nil {
								t.Fatal(a, z)
							}
							equal103(t, b.Snapshot(), old.Snapshot(), "旧68011 B5Q全時点Result")
							equal103(t, b.WidthAudit(), old.WidthAudit(), "旧68011 B5Q全時点WidthAudit")
							equal103(t, b.EarlyAudit(), old.EarlyAudit(), "旧68011 B5Q全時点EarlyAudit")
							points++
						}
						r, err := b.Finish()
						if err != nil {
							t.Fatal(err)
						}
						control, err := old.Finish()
						if err != nil {
							t.Fatal(err)
						}
						equal103(t, r, control, "旧68011 B5Q最終Result")
						equal103(t, b.WidthAudit(), old.WidthAudit(), "旧68011 B5Q最終WidthAudit")
						equal103(t, b.EarlyAudit(), old.EarlyAudit(), "旧68011 B5Q最終EarlyAudit")
						if !r.Complete || r.Totals.EntryQuantity == 0 || len(b.ClockAudit().Opportunities) != 0 {
							t.Fatal("非0完結又はB5Q空時計audit")
						}
						finals++
					}
				}
			}
			after, _ := json.Marshal(f)
			if !bytes.Equal(original, after) {
				t.Fatal("手製入力を変更しました")
			}
		}
	}
	t.Logf("旧68011 B5Q: 全時点%d×Result/Width/Early、最終%d×3、除外0", points, finals)
}

type quietHarness struct {
	t      *testing.T
	book   *ActualBook
	src    *source
	side   int
	index  int64
	move   float64
	method string
}

// newQuietHarness は元Sourceを計算しない手製通知器具とB5QDを組にします。
//
// 引数: t(*testing.T)、s(Session)、policy(string)、side(int)、cost(float64)、delay(int)は人工条件です。
// 返り値: *quietHarnessは公開APIへの配送だけを行う試験補助です。
func newQuietHarness(t *testing.T, s Session, policy string, side int, cost float64, delay int) *quietHarness {
	t.Helper()
	b, err := quietBook(s, policy, TimingQuietDeferred, cost, delay)
	if err != nil {
		t.Fatal(err)
	}
	return &quietHarness{t: t, book: b, src: newSource(), side: side, method: "D164_15"}
}

// quote は手製SourceとActualへ同じ正常又は異常原行を配送します。
//
// 引数: at(float64)、bad(bool)、news(...native.Signal)は当行時計と明示通知です。
// 返り値: なし。全入力を新しく作り、indexと物理行は別値にします。
func (h *quietHarness) quote(at float64, bad bool, news ...native.Signal) {
	h.t.Helper()
	o := observation(at, h.move, h.side, h.index, bad)
	for i, n := range news {
		if n.Action == "new" {
			var evidence sourceEvidence
			if err := json.Unmarshal(n.Evidence, &evidence); err != nil {
				h.t.Fatal(err)
			}
			evidence.Method = "NK225_" + h.method
			news[i].Evidence, _ = json.Marshal(evidence)
		}
	}
	line := h.index + 20
	h.index++
	batch := h.src.step(stamp(o, line), news)
	batch.Method = h.method
	if err := h.book.OnNativeStep(o, line, []NativeBatch{batch}); err != nil {
		h.t.Fatal(err)
	}
}

// grid は既存公開APIへ実在の手製5分時計だけを配送します。
//
// 引数: at(float64)は手製場内の300秒格子です。
// 返り値: なし。QuoteやSource通知を追加しません。
func (h *quietHarness) grid(at float64) {
	h.t.Helper()
	if err := h.book.OnEntryGrid(at); err != nil {
		h.t.Fatal(err)
	}
}

// force は直前Source物理行を持つ手製Forceだけを配送します。
//
// 引数: at(float64)は手製timer時計です。
// 返り値: なし。同timerでMTM又はFillを作りません。
func (h *quietHarness) force(at float64) {
	h.t.Helper()
	batch := h.src.force(at)
	batch.Method = h.method
	batch.Delta.SourceLine = h.src.last.SourceLine
	if err := h.book.OnNativeForce(at, []NativeBatch{batch}); err != nil {
		h.t.Fatal(err)
	}
}

// finish は手製Forceと後続正常原行で全実残・Source残を返済します。
//
// 引数: at(float64)は場内の手製Force時計です。
// 返り値: ActualResultは新金融の人工最終であり市場実績ではありません。
func (h *quietHarness) finish(at float64) ActualResult {
	h.t.Helper()
	h.force(at)
	h.quote(at+1, false)
	h.quote(at+2, false)
	r, err := h.book.Finish()
	if err != nil || !r.Complete || r.Totals.OpenBuy+r.Totals.OpenSell+r.Totals.PendingBuy+r.Totals.PendingSell != 0 {
		h.t.Fatalf("人工完結差: %v, %+v", err, r.Totals)
	}
	return r
}

// Test107DeferredEntry は開始静観から終了へ一回だけ割り当て、実取得は後原行に限定します。
//
// 引数: t(*testing.T)は買売・三政策・全費用遅延の人工試験器です。
// 返り値: なし。新しい金融条件又はSource形成は評価しません。
func Test107DeferredEntry(t *testing.T) {
	finals := 0
	for _, side := range []int{1, -1} {
		for _, policy := range []string{"W0", "W1", "E1"} {
			for _, cost := range []float64{0, 5} {
				for _, delay := range []int{0, 1} {
					h := newQuietHarness(t, session(), policy, side, cost, delay)
					s, g := session().Start, session().Start+1800
					h.quote(s+1, false, birth("繰越", side, 6))
					h.quote(s+2, false)
					h.grid(s + 300)
					r := h.book.Snapshot()
					if r.EntryOpportunities[0].Consumed || r.GridTraces[0].CandidateCount != 0 || !r.GridTraces[0].QuietApplied {
						t.Fatal("静観中に消費又はquietガードを外しました")
					}
					h.grid(g)
					r = h.book.Snapshot()
					p, a := r.EntryOpportunities[0], h.book.ClockAudit().Opportunities[0]
					if p.Requested != 6 || !p.Consumed || len(r.Fills) != 0 || a.Source != p.Source || a.StrictAt != s+300 || a.AssignedAt != g || !a.Deferred || a.QuietStart != s || a.QuietEnd != g {
						t.Fatal("一回割当・audit・grid時未約定が不整合です")
					}
					copy := h.book.ClockAudit()
					copy.Opportunities[0].Source.Parent = "外部変更"
					if h.book.ClockAudit().Opportunities[0].Source.Parent == "外部変更" {
						t.Fatal("auditが共有されています")
					}
					h.quote(g, false)
					if (h.book.Snapshot().Totals.EntryQuantity == 6) != (delay == 0) {
						t.Fatal("同時刻の別原行D0/D1差を壊しました")
					}
					h.quote(g+1, false)
					h.move = 60
					h.quote(g+2, false)
					r = h.finish(g + 3)
					if r.Totals.EntryQuantity != 6 || len(h.book.ClockAudit().Opportunities) != 1 || !strings.Contains(r.Key, "B5QD") {
						t.Fatal("最終取得又は一回時計が不整合です")
					}
					for _, fill := range r.Fills {
						o := r.Orders[h.book.orders[fill.OrderID]]
						if fill.Quote.Index <= o.RequestQuote.Index || fill.Quote.SourceLine == o.RequestQuote.SourceLine || fill.Quote.Time < o.RequestTime+float64(delay) {
							t.Fatal("同原行又はD1以前にfillしました")
						}
					}
					finals++
				}
			}
		}
	}
	t.Logf("B5QD 非0完結%d、鏡像/三政策/全C-D", finals)
}

// Test107NoOtherRetry はquiet以外の失効と永久lockを後の枠へ救済しないことを確認します。
//
// 引数: t(*testing.T)は手製Source取消・完結・予約・未知・未取得・容量・締切の試験器です。
// 返り値: なし。各失効は保存結果の理由と一回Consumedを確認します。
func Test107NoOtherRetry(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, scenario := range []string{"取消", "完結", "予約", "未知", "未取得", "容量", "Force締切", "受理後0取得取消"} {
			t.Run(fmt.Sprintf("方向%d_%s", side, scenario), func(t *testing.T) {
				s := session()
				g := s.Start + 1800
				if scenario == "Force締切" {
					s.ForceClose = g
				}
				h := newQuietHarness(t, s, "W0", side, 0, 1)
				qty := 6
				if scenario == "容量" {
					qty = 10
				}
				h.quote(s.Start+1, false, birth("対象", side, qty))
				switch scenario {
				case "取消":
					h.force(s.Start + 2)
				case "未取得":
				default:
					if scenario == "容量" {
						h.quote(s.Start+2, false, birth("容量超過", side, 4))
						h.quote(s.Start+3, false)
					} else {
						h.quote(s.Start+2, false)
					}
				}
				if scenario == "完結" || scenario == "予約" {
					h.quote(s.Start+3, false, closeSignal("先行返済", "玉-対象", side, 6))
					if scenario == "完結" {
						h.quote(s.Start+4, false)
					}
				}
				if scenario == "未知" {
					h.quote(s.Start+3, true)
				}
				h.grid(g)
				r := h.book.Snapshot()
				i := 0
				want := map[string]string{"取消": "取消済み", "完結": "完結済み", "予約": "返済予約", "未知": "必要未知", "未取得": "未取得", "容量": "空きなし", "Force締切": "Force境界"}
				if scenario == "容量" {
					i = 1
				}
				p := r.EntryOpportunities[i]
				if !p.Consumed || p.AssignedAt != g {
					t.Fatal("一回消費ではありません")
				}
				if scenario == "受理後0取得取消" {
					if p.Requested != 6 || r.Totals.EntryQuantity != 0 {
						t.Fatal("未取得受理の器具不整合")
					}
					h.force(g)
					order := h.book.Snapshot().Orders[0]
					if order.Kind != "entry" || order.Status != "cancelled" || h.book.entryBySource[sourceKey(p.Source.Method, p.Source.SignalID)] == "" {
						t.Fatal("0取得取消で永久lockが消えました")
					}
				} else if p.Requested != 0 || !strings.Contains(p.Reason, want[scenario]) {
					t.Fatalf("失効理由差: %+v", p)
				}
				h.quote(g+1, false)
				h.grid(g + 300)
				r = h.book.Snapshot()
				if r.EntryOpportunities[i].EvaluatedAt == nil || *r.EntryOpportunities[i].EvaluatedAt != g || r.GridTraces[len(r.GridTraces)-1].CandidateCount != 0 || len(h.book.ClockAudit().Opportunities) != len(r.EntryOpportunities) {
					t.Fatal("消費済み出生を後の枠へ復活させました")
				}
				final := h.finish(g + 301)
				if scenario != "容量" && final.Totals.EntryQuantity != 0 {
					t.Fatal("失効した出生を取得しました")
				}
			})
		}
	}
}

// Test107DeferredEOFAndAlignment は未観測終端を作らず、非整列を場skipで救わないことを確認します。
//
// 引数: t(*testing.T)は場時計とEOFだけの手製試験器です。
// 返り値: なし。B5Qの旧非整列許可とB5QDの明示失敗を分けます。
func Test107DeferredEOFAndAlignment(t *testing.T) {
	s := session()
	h := newQuietHarness(t, s, "W0", 1, 0, 0)
	h.quote(s.Start+1, false, birth("EOF", 1, 2))
	h.quote(s.Start+2, false)
	r := h.finish(s.Start + 3)
	p := r.EntryOpportunities[0]
	if !p.Consumed || p.Requested != 0 || !strings.Contains(p.Reason, "EOF") || *p.EvaluatedAt >= p.AssignedAt || len(r.GridTraces) != 0 {
		t.Fatal("EOFで未来の割当枠を補いました")
	}
	for _, policy := range []string{"W0", "W1", "E1"} {
		bad := s
		bad.Start++
		if _, err := quietBook(bad, policy, TimingQuietDeferred, 0, 0); err == nil {
			t.Fatal("非整列Startを受理しました")
		}
		if _, err := quietBook(bad, policy, "B5Q", 0, 0); err != nil {
			t.Fatal("B5Q旧許可範囲を狭めました", err)
		}
		night := s
		night.Kind, night.USOpen = "Night", s.Start+3601
		if _, err := quietBook(night, policy, TimingQuietDeferred, 0, 0); err == nil {
			t.Fatal("非整列US時計を受理しました")
		}
		night.USOpen--
		if _, err := quietBook(night, policy, TimingQuietDeferred, 0, 0); err != nil {
			t.Fatal("整列US時計を拒否しました", err)
		}
	}
	if _, err := quietBook(s, "W2", TimingQuietDeferred, 0, 0); err == nil {
		t.Fatal("今回未対象のW2-B5QDを受理しました")
	}
	cfg := ActorConfig{Policy: "P0", EntryTiming: TimingQuietDeferred, ActivationPolicy: ActivationE2}
	if _, err := NewEarlyBook(s, cfg, "手製限月"); err == nil {
		t.Fatal("今回未対象のE2-B5QDを受理しました")
	}
	night := s
	night.Kind, night.USOpen = "Night", s.Start+3600
	cfg.ActivationPolicy, cfg.USOpen = ActivationE1, night.USOpen+300
	if _, err := NewEarlyBook(night, cfg, "手製限月"); err == nil {
		t.Fatal("Session/Actualの米国開始時計差を受理しました")
	}
}

// Test107NightUSAndPDeadline はU静観繰越とP締切・Force同時計の優先を分けます。
//
// 引数: t(*testing.T)は夏冬の既知米国開始時計と買売鏡像の人工試験器です。
// 返り値: なし。Source通知は手製で、自然P/U形成の証明ではありません。
func Test107NightUSAndPDeadline(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, usOffset := range []float64{19800, 23400} {
			for _, forceAtEnd := range []bool{false, true} {
				s := session()
				s.ID, s.Kind = "手製米国時計_Night", "Night"
				s.Start += 8*3600 + 15*60
				s.End, s.ForceClose = s.Start+46800, s.Start+46200
				s.USOpen = s.Start + usOffset
				g := s.USOpen + 1800
				if forceAtEnd {
					s.ForceClose = g
				}
				h := newQuietHarness(t, s, "W0", side, 5, 1)
				h.method = "U165_03"
				h.quote(s.USOpen+901, false, birth("米国繰越", side, 2))
				h.quote(s.USOpen+902, false)
				h.grid(s.USOpen + 1200)
				if h.book.Snapshot().EntryOpportunities[0].Consumed {
					t.Fatal("U静観中に機会を消費しました")
				}
				if forceAtEnd {
					h.force(g)
				}
				h.grid(g)
				p := h.book.Snapshot().EntryOpportunities[0]
				a := h.book.ClockAudit().Opportunities[0]
				if !p.Consumed || a.StrictAt != s.USOpen+1200 || a.AssignedAt != g || a.QuietStart != s.USOpen || a.QuietEnd != g || !a.Deferred {
					t.Fatal("Uの元出生・米国静観根拠差")
				}
				if forceAtEnd && (!strings.Contains(p.Reason, "Force境界") || p.Requested != 0) || !forceAtEnd && p.Requested != 2 {
					t.Fatalf("同時計Force優先又は通常受理差: %+v", p)
				}
				h.quote(g+1, false)
				r := h.finish(g + 2)
				if forceAtEnd && r.Totals.EntryQuantity != 0 || !forceAtEnd && r.Totals.EntryQuantity != 2 {
					t.Fatal("U取得の終端境界差")
				}
			}
		}
		// ----------------------------------------
		// PはUS-900の締切と同じ枠へ来ても、同時計Forceの後に受付を復活させません。
		s := session()
		s.ID, s.Kind, s.USOpen = "手製P締切_Night", "Night", s.Start+7200
		h := newQuietHarness(t, s, "W0", side, 0, 0)
		h.method = "P164_06"
		h.quote(s.USOpen-901, false, birth("P締切", side, 2))
		h.force(s.USOpen - 900)
		h.grid(s.USOpen - 900)
		p := h.book.Snapshot().EntryOpportunities[0]
		if !strings.Contains(p.Reason, "Force境界") || p.Requested != 0 || h.book.ClockAudit().Opportunities[0].Deferred {
			t.Fatal("Pの旧締切を救済しました")
		}
		h.finish(s.USOpen - 899)
	}
}
