package miniprofit110

import "fmt"

// quietDuration は互換constructorでは1800秒、明示constructorでは固定した秒数を返します。
//
// 引数: なし。返り値: intは1200又は1800秒です。Config/結果JSONを変更しません。
func (b *ActualBook) quietDuration() int {
	if b.quietSeconds == 0 {
		return 1800
	}
	return b.quietSeconds
}

// withQuiet は新規の空Bookにだけ明示durationを固定します。
//
// 引数: b(*ActualBook)、err(error)、seconds(int)は元constructor結果と静観秒数です。
// 返り値: *ActualBook/errorは未使用Book又は未比較の設定です。状態更新用APIではありません。
func withQuiet(b *ActualBook, err error, seconds int) (*ActualBook, error) {
	if err != nil {
		return nil, err
	}
	if seconds != 1200 && seconds != 1800 {
		return nil, fmt.Errorf("静観秒数は1200又は1800だけです")
	}
	c := b.result.Config
	if c.EntryTiming != TimingQuietDeferred || c.Policy != "P0" || c.GatePolicy != "" || c.HarvestPolicy != "" || c.RiskPolicy != "" || c.ExitPolicy != "" || (c.ActivationPolicy != ActivationLD10 && c.ActivationPolicy != ActivationE1) {
		return nil, fmt.Errorf("明示静観長はB5QD/P0・LD10又はE1専用です")
	}
	b.quietSeconds = seconds
	return b, nil
}

// NewActualBookWithQuiet は追加設定欄を作らずB5QDの静観長をconstructorで固定します。
//
// 引数: session(Session)、cfg(ActorConfig)、quietSeconds(int)は元設定と1200/1800秒です。
// 返り値: *ActualBook/errorは空の独立Book又は設定不正です。E1は専用constructorを使います。
func NewActualBookWithQuiet(session Session, cfg ActorConfig, quietSeconds int) (*ActualBook, error) {
	b, err := NewActualBook(session, cfg)
	return withQuiet(b, err, quietSeconds)
}

// NewWidthBookWithQuiet はW0/W1の元JSONを維持して静観長だけを私有状態へ固定します。
//
// 引数: session(Session)、cfg(ActorConfig)、policy/contract(string)、quietSeconds(int)はB5QDの元設定と1200/1800秒です。
// 返り値: *ActualBook/errorはW0/W1空口座又は設定不正です。金融量/価格/保護幅を変更しません。
func NewWidthBookWithQuiet(session Session, cfg ActorConfig, policy, contract string, quietSeconds int) (*ActualBook, error) {
	if policy != "W0" && policy != "W1" {
		return nil, fmt.Errorf("明示静観長の幅政策はW0/W1だけです")
	}
	b, err := NewWidthBook(session, cfg, policy, contract)
	return withQuiet(b, err, quietSeconds)
}

// NewEarlyBookWithQuiet はE1の元JSONを維持して静観長だけを私有状態へ固定します。
//
// 引数: session(Session)、cfg(ActorConfig)、contract(string)、quietSeconds(int)はB5QDの元設定と1200/1800秒です。
// 返り値: *ActualBook/errorはE1空口座又は設定不正です。通常/早期の数式を変更しません。
func NewEarlyBookWithQuiet(session Session, cfg ActorConfig, contract string, quietSeconds int) (*ActualBook, error) {
	if cfg.ActivationPolicy != ActivationE1 {
		return nil, fmt.Errorf("明示静観長の早期政策はE1だけです")
	}
	b, err := NewEarlyBook(session, cfg, contract)
	return withQuiet(b, err, quietSeconds)
}
