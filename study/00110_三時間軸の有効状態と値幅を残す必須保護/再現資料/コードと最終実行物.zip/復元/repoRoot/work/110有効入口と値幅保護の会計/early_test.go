package miniprofit110

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"strings"
	"testing"

	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	prior "github.com/masayoshi4649/SessionTradeExecuter/minivariableguard"
)

// priorBatches は元NativeDelta全値を停止c0bfの名前付き外型へ写します。
//
// 引数: in([]NativeBatch)は手製公開通知。返り値: []prior.NativeBatchは順序/nil/全Deltaを保持します。
func priorBatches(in []NativeBatch) []prior.NativeBatch {
	if in == nil {
		return nil
	}
	out := make([]prior.NativeBatch, len(in))
	for i, b := range in {
		out[i] = prior.NativeBatch{Method: b.Method, Delta: b.Delta}
	}
	return out
}

// priorObservation は全公開C/M/P欄を旧型へ明示対応します。
//
// 引数: o(WidthObservation)は同じ一件。返り値: prior.WidthObservationは採否や時計を付け替えません。
func priorObservation(o WidthObservation) prior.WidthObservation {
	return prior.WidthObservation{Session: o.Session, Contract: o.Contract, Side: o.Side, PublicationID: o.PublicationID, Ordinal: o.Ordinal, End: o.End, AvailableAt: o.AvailableAt, C: prior.WidthTruth{Known: o.C.Known, Passed: valueCopy(o.C.Passed)}, M: prior.WidthTruth{Known: o.M.Known, Passed: valueCopy(o.M.Passed)}, P: prior.WidthTruth{Known: o.P.Known, Passed: valueCopy(o.P.Passed)}, FrameSHA: o.FrameSHA, ResultSHA: o.ResultSHA}
}

// TestOldWidthAllJSON は旧W0/W1/W2を停止c0bfの独立Bookへ全時点/最終で照合します。
//
// 引数: t(*testing.T)は買売/既知未知ATR/全C/D試験器。
// 返り値: ありません。金融Bookと別WidthAuditの全JSONを除外しません。
func TestOldWidthAllJSON(t *testing.T) {
	points, finals := 0, 0
	for _, side := range []int{1, -1} {
		for _, unknown := range []bool{false, true} {
			for _, policy := range []string{"W0", "W1", "W2"} {
				f := widthWave(side, unknown)
				g := f.Session.Start + 1800
				ns := []*ActualBook{}
				ps := []*prior.ActualBook{}
				for _, c := range []float64{0, 5} {
					for _, d := range []int{0, 1} {
						n, e := NewWidthBook(f.Session, ActorConfig{Policy: "P0", ActivationPolicy: ActivationLD10, EntryTiming: "B5Q", SlipPts: c, DelaySeconds: d}, policy, "手製限月")
						if e != nil {
							t.Fatal(e)
						}
						p, e := prior.NewWidthBook(f.Session, prior.ActorConfig{Policy: "P0", ActivationPolicy: prior.ActivationLD10, EntryTiming: "B5Q", SlipPts: c, DelaySeconds: d}, policy, "手製限月")
						if e != nil {
							t.Fatal(e)
						}
						pub := widthObs(side, 1, g-180, WidthTruth{})
						if e = n.OnWidthObservation(g-3, pub); e != nil {
							t.Fatal(e)
						}
						if e = p.OnWidthObservation(g-3, priorObservation(pub)); e != nil {
							t.Fatal(e)
						}
						ns = append(ns, n)
						ps = append(ps, p)
					}
				}
				for _, ev := range f.Events {
					for i, n := range ns {
						p := ps[i]
						if ev.Kind == "quote" && f.Steps[ev.Index].Observation.Time == g+6 {
							if e := n.ResetWidthObservation(g+6, "手製Last0"); e != nil {
								t.Fatal(e)
							}
							if e := p.ResetWidthObservation(g+6, "手製Last0"); e != nil {
								t.Fatal(e)
							}
							pub := widthObs(side, 2, g, WidthTruth{true, widthPointer(true)})
							if e := n.OnWidthObservation(g+6, pub); e != nil {
								t.Fatal(e)
							}
							if e := p.OnWidthObservation(g+6, priorObservation(pub)); e != nil {
								t.Fatal(e)
							}
						}
						var ne, pe error
						switch ev.Kind {
						case "quote":
							s := f.Steps[ev.Index]
							ne = n.OnNativeStep(s.Observation, s.SourceLine, s.Batches)
							pe = p.OnNativeStep(s.Observation, s.SourceLine, priorBatches(s.Batches))
						case "grid":
							ne = n.OnEntryGrid(f.Grids[ev.Index])
							pe = p.OnEntryGrid(f.Grids[ev.Index])
						case "timer":
							s := f.Timers[ev.Index]
							ne = n.OnNativeForce(s.At, s.Batches)
							pe = p.OnNativeForce(s.At, priorBatches(s.Batches))
						}
						if ne != nil || pe != nil {
							t.Fatal(ne, pe)
						}
						equal103(t, n.Snapshot(), p.Snapshot(), "旧W金融全文")
						equal103(t, n.WidthAudit(), p.WidthAudit(), "旧W別audit全文")
						points++
					}
				}
				for i, n := range ns {
					nr, e := n.Finish()
					if e != nil {
						t.Fatal(e)
					}
					pr, e := ps[i].Finish()
					if e != nil {
						t.Fatal(e)
					}
					equal103(t, nr, pr, "旧W最終")
					equal103(t, n.WidthAudit(), ps[i].WidthAudit(), "旧W最終audit")
					finals++
				}
			}
		}
	}
	t.Logf("停止c0bf旧W0/W1/W2 全時点%d＋同数WidthAudit 最終%d、除外0", points, finals)
}

// earlyWave は固定Source器具だけから早期閾値付近の手製系列を作ります。
//
// 引数: side(int)、unknown(bool)は鏡像と取得ATR未知。
// 返り値: fixture103は価格/Sourceを公開型で明示した非市場器具です。
func earlyWave(side int, unknown bool, priority ...bool) fixture103 {
	// Source列を別に作り直す。保存したFill価格だけを書換えて偽装しない。
	s := session()
	g := s.Start + 1800
	f := fixture103{Session: s, Scope: "E1/E2の手製価格/Source/ATR公開型。指標形成・市場成績ではない"}
	src := newSource()
	index := int64(0)
	feed := func(at, move, atr float64, bad bool, news ...native.Signal) {
		o := observation(at, move, side, index, bad)
		o.ATR, o.E01.ATR = atr, atr
		if atr == 0 {
			o.E01.ATRAvailable, o.E01.ATRNominal = 0, 0
		}
		line := index + 20
		batch := src.step(stamp(o, line), news)
		f.Events = append(f.Events, event103{"quote", len(f.Steps)})
		f.Steps = append(f.Steps, step103{o, line, []NativeBatch{batch}})
		index++
	}
	grid := func(at float64) {
		f.Events = append(f.Events, event103{"grid", len(f.Grids)})
		f.Grids = append(f.Grids, at)
	}
	atr := 40.75
	if unknown {
		atr = 0
	}
	feed(g-2, 0, atr, false, birth("初回", side, 6))
	feed(g-1, 0, atr, false)
	grid(g)
	feed(g+1, 0, atr, false)
	feed(g+2, 0, atr, false)
	feed(g+3, 35, atr, false, closeSignal("部分", "玉-初回", side, 3))
	feed(g+4, 45, atr, false)
	feed(g+5, 70, 40.75, false)
	feed(g+6, 120, 300, false)
	if len(priority) > 0 && priority[0] {
		feed(g+7, 60, 1, false, closeSignal("全予約", "玉-初回", side, 3))
	} else {
		feed(g+7, 60, 1, false)
	}
	feed(g+8, 0, 40.75, false)
	feed(g+8, 0, 40.75, true)
	feed(g+9, -10, 40.75, false)
	feed(g+298, 0, 40.75, false, birth("親追加", side, 4))
	feed(g+299, 0, 40.75, false)
	grid(g + 300)
	feed(g+301, 0, 40.75, false)
	feed(g+302, 30, 40.75, false)
	batch := src.force(g + 302)
	batch.Delta.SourceLine = src.last.SourceLine
	f.Events = append(f.Events, event103{"timer", len(f.Timers)})
	f.Timers = append(f.Timers, timer103{g + 302, []NativeBatch{batch}})
	feed(g+302, 30, 40.75, true)
	feed(g+302, 20, 40.75, false)
	feed(g+303, 10, 40.75, false)
	return f
}

// TestEarlyAPI は警戒早期・P未知・ATR未知・通常LD10を明示enumで区別します。
//
// 引数: t(*testing.T)は買売/C0C5/D0D1/ATR既知未知の非市場試験器。
// 返り値: ありません。起動理由/幅/最低床/Source部分/Force/残0を検査します。
func TestEarlyAPI(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, unknown := range []bool{false, true} {
			f := earlyWave(side, unknown)
			g := f.Session.Start + 1800
			books := []*ActualBook{}
			for _, policy := range []ActivationPolicy{ActivationE1, ActivationE2} {
				for _, c := range []float64{0, 5} {
					for _, d := range []int{0, 1} {
						b, e := NewEarlyBook(f.Session, ActorConfig{Policy: "P0", ActivationPolicy: policy, EntryTiming: "B5Q", SlipPts: c, DelaySeconds: d}, "手製限月")
						if e != nil {
							t.Fatal(e)
						}
						if !strings.HasPrefix(b.Snapshot().Key, string(policy)+"_") {
							t.Fatal("E enum/Key不一致")
						}
						if e = b.OnWidthObservation(g-3, widthObs(side, 1, g-180, WidthTruth{})); e != nil {
							t.Fatal(e)
						}
						books = append(books, b)
					}
				}
			}
			for _, ev := range f.Events {
				at := 0.0
				if ev.Kind == "quote" {
					at = f.Steps[ev.Index].Observation.Time
				}
				if ev.Kind == "quote" && at == g+4 {
					for _, b := range books {
						if e := b.OnWidthObservation(at, widthObs(side, 2, g, WidthTruth{true, widthPointer(true)})); e != nil {
							t.Fatal(e)
						}
					}
				}
				for _, b := range books {
					var e error
					switch ev.Kind {
					case "quote":
						s := f.Steps[ev.Index]
						e = b.OnNativeStep(s.Observation, s.SourceLine, s.Batches)
					case "grid":
						e = b.OnEntryGrid(f.Grids[ev.Index])
					case "timer":
						s := f.Timers[ev.Index]
						e = b.OnNativeForce(s.At, s.Batches)
					}
					if e != nil {
						t.Fatal(e)
					}
					if ev.Kind == "quote" && at == g+3 {
						p := b.Snapshot().Positions[0]
						cfg := b.Snapshot().Config
						wanted := !unknown && cfg.ActivationPolicy == ActivationE1 && cfg.SlipPts == 0
						if p.ProtectionActive != wanted {
							t.Fatal("P未知/利益閾値/ATR未知", cfg, p)
						}
					}
				}
			}
			for _, b := range books {
				r, e := b.Finish()
				if e != nil {
					t.Fatal(e)
				}
				a := b.EarlyAudit()
				w := b.WidthAudit()
				if !r.Complete || r.Totals.EntryQuantity == 0 || len(a.Positions) == 0 || r.Positions[0].Activation == nil || w.Positions[0].State.Policy != string(r.Config.ActivationPolicy) {
					t.Fatal("非0/enum/起動出典")
				}
				expected := "early_warning"
				if unknown {
					expected = "normal_ld10"
				}
				if a.Positions[0].Trigger != expected || a.Positions[0].Point != *r.Positions[0].Activation || a.Positions[0].ATRValue != 40.75 || a.Positions[0].EarlyThresholdYen != 2037.5 || a.Positions[0].NormalThresholdYen != 4075 {
					t.Fatal("起動の帰属", a)
				}
				if !strings.HasPrefix(r.Positions[0].ActivationReason, string(r.Config.ActivationPolicy)) || *r.Positions[0].FloorGain < 0 {
					t.Fatal("理由/最低名目床")
				}
				if !unknown && (a.Positions[0].Point.UnitNet >= 4075 || a.Positions[0].Point.UnitNet < 2037.5 || a.Positions[0].Observation == nil) {
					t.Fatal("早期条件証拠")
				}
				if !w.Positions[0].State.Narrowed || w.Positions[0].FirstObservation == nil {
					t.Fatal("警戒時狭1ATR")
				}
				if dir := os.Getenv("EARLY_EXPORT"); dir != "" {
					data, _ := json.MarshalIndent(map[string]any{"scope": f.Scope, "fixture": f, "book": r, "width_audit": w, "early_audit": a}, "", "  ")
					path := filepath.Join(dir, fmt.Sprintf("方向%d_未知%t_%s_C%.0f_D%d.json", side, unknown, r.Config.ActivationPolicy, r.Config.SlipPts, r.Config.DelaySeconds))
					if e = os.WriteFile(path, data, 0600); e != nil {
						t.Fatal(e)
					}
				}
			}
		}
	}
}

// TestEarlyUnknownResetFallback は未知/既知否定/resetを早期支持にせず通常LD10を維持します。
//
// 引数: t(*testing.T)はE1/E2と狭い警戒境界の試験器。
// 返り値: ありません。未知をfalseに潰した成功や未来支持を補いません。
func TestEarlyUnknownResetFallback(t *testing.T) {
	for _, policy := range []ActivationPolicy{ActivationE1, ActivationE2} {
		for _, variant := range []string{"無公表", "勢い未知", "既知否定と未知", "P未知", "reset同ID", "未来拒否"} {
			if policy == ActivationE1 && variant == "P未知" {
				continue
			}
			f := earlyWave(1, false)
			g := f.Session.Start + 1800
			b, e := NewEarlyBook(f.Session, ActorConfig{Policy: "P0", ActivationPolicy: policy, EntryTiming: "B5Q"}, "手製限月")
			if e != nil {
				t.Fatal(e)
			}
			pub := widthObs(1, 1, g-180, WidthTruth{true, widthPointer(true)})
			switch variant {
			case "勢い未知":
				pub.M = WidthTruth{}
			case "既知否定と未知":
				pub.C.Passed = widthPointer(false)
				pub.M = WidthTruth{}
			case "P未知":
				pub.P = WidthTruth{}
			}
			if variant != "無公表" && variant != "未来拒否" {
				if e = b.OnWidthObservation(g-3, pub); e != nil {
					t.Fatal(e)
				}
			}
			for _, ev := range f.Events {
				if ev.Kind == "quote" && f.Steps[ev.Index].Observation.Time == g+3 {
					if variant == "reset同ID" {
						if e = b.ResetWidthObservation(g+3, "手製Last0"); e != nil {
							t.Fatal(e)
						}
						if e = b.OnWidthObservation(g+3, pub); e != nil {
							t.Fatal(e)
						}
					}
					if variant == "未来拒否" {
						bad := widthObs(1, 2, g+180, WidthTruth{true, widthPointer(true)})
						if e = b.OnWidthObservation(g+3, bad); e == nil {
							t.Fatal("未来を支持")
						}
					}
				}
				switch ev.Kind {
				case "quote":
					s := f.Steps[ev.Index]
					e = b.OnNativeStep(s.Observation, s.SourceLine, s.Batches)
				case "grid":
					e = b.OnEntryGrid(f.Grids[ev.Index])
				case "timer":
					s := f.Timers[ev.Index]
					e = b.OnNativeForce(s.At, s.Batches)
				}
				if e != nil {
					t.Fatal(policy, variant, e)
				}
			}
			r, e := b.Finish()
			if e != nil {
				t.Fatal(e)
			}
			a := b.EarlyAudit()
			w := b.WidthAudit()
			if len(a.Positions) == 0 || a.Positions[0].Trigger != "normal_ld10" || a.Positions[0].Point.Quote.Time != g+5 || w.Positions[0].State.Narrowed {
				t.Fatal("未知/resetから早期支持又は狭幅", policy, variant, a, w)
			}
			if r.Positions[0].ActivationReason == "" || !strings.Contains(r.Positions[0].ActivationReason, "通常LD10") {
				t.Fatal("通常理由")
			}
		}
	}
}

// TestEarlySourcePriority は警戒幅の新hitより同原行Source全予約を優先します。
//
// 引数: t(*testing.T)は買売×E1/E2×全C/Dの試験器。
// 返り値: ありません。保護要求0・Source/Forceによる全完結を検査します。
func TestEarlySourcePriority(t *testing.T) {
	for _, side := range []int{1, -1} {
		for _, policy := range []ActivationPolicy{ActivationE1, ActivationE2} {
			for _, c := range []float64{0, 5} {
				for _, d := range []int{0, 1} {
					f := earlyWave(side, false, true)
					g := f.Session.Start + 1800
					b, e := NewEarlyBook(f.Session, ActorConfig{Policy: "P0", ActivationPolicy: policy, EntryTiming: "B5Q", SlipPts: c, DelaySeconds: d}, "手製限月")
					if e != nil {
						t.Fatal(e)
					}
					pub := widthObs(side, 1, g-180, WidthTruth{true, widthPointer(true)})
					pub.C.Passed = widthPointer(false)
					if e = b.OnWidthObservation(g-3, pub); e != nil {
						t.Fatal(e)
					}
					for _, ev := range f.Events {
						if ev.Kind == "quote" && f.Steps[ev.Index].Observation.Time == g+7 {
							if e = b.OnWidthObservation(g+7, widthObs(side, 2, g, WidthTruth{true, widthPointer(true)})); e != nil {
								t.Fatal(e)
							}
						}
						switch ev.Kind {
						case "quote":
							s := f.Steps[ev.Index]
							e = b.OnNativeStep(s.Observation, s.SourceLine, s.Batches)
						case "grid":
							e = b.OnEntryGrid(f.Grids[ev.Index])
						case "timer":
							s := f.Timers[ev.Index]
							e = b.OnNativeForce(s.At, s.Batches)
						}
						if e != nil {
							t.Fatal(e)
						}
					}
					r, e := b.Finish()
					if e != nil {
						t.Fatal(e)
					}
					a := b.WidthAudit()
					if r.Metrics.ProtectionExitRequests != 0 || a.Positions[0].FirstNarrow == nil || a.Positions[0].FirstNarrow.Phase != PhasePreFill || r.Positions[0].FirstFloorHit == nil {
						t.Fatal("予約優先/初hit")
					}
				}
			}
		}
	}
}

// TestEarlyConstructor はEをLD10へ偽装した経路や未比較policyを拒否します。
//
// 引数: t(*testing.T)は公開設定の試験器。
// 返り値: ありません。既存JSON型に新fieldを足しません。
func TestEarlyConstructor(t *testing.T) {
	cfg := ActorConfig{Policy: "P0", ActivationPolicy: ActivationE1, EntryTiming: "B5Q"}
	if _, e := NewActualBook(session(), cfg); e == nil {
		t.Fatal("専用境界なしEを受理")
	}
	if _, e := NewWidthBook(session(), cfg, "W1", "手製限月"); e == nil {
		t.Fatal("Eを旧W/LDへ偽装")
	}
	cfg.ActivationPolicy = ActivationLD10
	if _, e := NewEarlyBook(session(), cfg, "手製限月"); e == nil {
		t.Fatal("LDをEへ偽装")
	}
}

// TestEarlyThresholdPureBoundary は単価引数の包括境界をIEEEの隣接値で検査します。
//
// 引数: t(*testing.T)は内部判定だけの試験器。
// 返り値: ありません。手製MTM点でありSource/約定/金額形成の証明とは分けます。
func TestEarlyThresholdPureBoundary(t *testing.T) {
	g := session().Start + 1800
	for _, policy := range []ActivationPolicy{ActivationE1, ActivationE2} {
		for _, u := range []float64{math.Nextafter(2037.5, math.Inf(-1)), 2037.5, math.Nextafter(2037.5, math.Inf(1)), 4075} {
			b, e := NewEarlyBook(session(), ActorConfig{Policy: "P0", ActivationPolicy: policy, EntryTiming: "B5Q"}, "手製限月")
			if e != nil {
				t.Fatal(e)
			}
			if e = b.OnWidthObservation(g-3, widthObs(1, 1, g-180, WidthTruth{true, widthPointer(true)})); e != nil {
				t.Fatal(e)
			}
			p := ActualPosition{ID: "閾値純判定", Side: 1, EntryPrice: 1000, Quantity: 1, ATR: &ATRLock{Value: 40.75, Width: 85}}
			point := MTMPoint{Quote: QuoteStamp{Time: g + 3, Index: 1, SourceLine: 2}, Phase: PhasePreFill, Quantity: 1, UnitNet: u}
			if e = b.activateProtection(&p, point); e != nil {
				t.Fatal(e)
			}
			if p.ProtectionActive != (u >= 2037.5) {
				t.Fatal(">=境界")
			}
			if p.ProtectionActive {
				expected := "early_warning"
				if u >= 4075 {
					expected = "normal_ld10"
				}
				if b.widthBook.Activations[p.ID].Trigger != expected {
					t.Fatal("同時成立の通常優先")
				}
			}
		}
	}
}
