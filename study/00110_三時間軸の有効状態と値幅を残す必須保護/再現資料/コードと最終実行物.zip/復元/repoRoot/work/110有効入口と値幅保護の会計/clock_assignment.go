package miniprofit110

import (
	"fmt"
	"math"

	clock "github.com/masayoshi4649/SessionTradeExecuter/quietlength108"
)

const TimingQuietDeferred = "B5QD"

// ClockOpportunityAudit は一出生を一度割り当てた根拠を金融本体の外で保存します。
// Ordinal/SourceはEntryOpportunitiesへ全文結合し、要求・実Fillは既存結果から追跡します。
type ClockOpportunityAudit struct {
	Ordinal    int            `json:"ordinal"`
	Source     SourceIdentity `json:"source"`
	StrictAt   float64        `json:"strict_at"`
	AssignedAt float64        `json:"assigned_at"`
	QuietStart float64        `json:"quiet_start,omitempty"`
	QuietEnd   float64        `json:"quiet_end,omitempty"`
	Reason     string         `json:"reason,omitempty"`
	Deferred   bool           `json:"deferred"`
}

// ClockBookAudit は既存ActualResult/WidthAudit/EarlyAuditへ欄を加えない別auditです。
type ClockBookAudit struct {
	Timing        string                  `json:"timing"`
	Opportunities []ClockOpportunityAudit `json:"opportunities"`
}

// quietEntryTiming は旧B5Qと新B5QDで同じ静観ガードを保ちます。
//
// 引数: timing(string)は公開Configの時計名です。
// 返り値: boolは半開静観を適用する時計だけtrueです。
func quietEntryTiming(timing string) bool {
	return timing == "B5Q" || timing == TimingQuietDeferred
}

// validateDeferredClock はB5QDだけに実時計の300秒整列と比較対象を要求します。
//
// 引数: session(Session)、cfg(ActorConfig)は旧検査後の場と設定です。
// 返り値: errorは非整列又はW0/W1/E1以外の組合せです。B5Qの旧許可範囲は変えません。
func validateDeferredClock(session Session, cfg ActorConfig) error {
	if cfg.EntryTiming != TimingQuietDeferred {
		return nil
	}
	if cfg.Policy != "P0" || cfg.GatePolicy != "" || cfg.HarvestPolicy != "" || cfg.RiskPolicy != "" || cfg.ExitPolicy != "" || (cfg.ActivationPolicy != ActivationLD10 && cfg.ActivationPolicy != ActivationE1) {
		return fmt.Errorf("B5QDはGate/Harvest/Risk/Exit空のLD10又はE1・P0専用です")
	}
	if session.Start <= 0 || math.Mod(session.Start, 300) != 0 || !finiteActual(session.USOpen) || session.USOpen < 0 || (session.USOpen > 0 && math.Mod(session.USOpen, 300) != 0) || (cfg.USOpen > 0 && math.Mod(cfg.USOpen, 300) != 0) {
		return fmt.Errorf("B5QDの場開始・米国開始は300秒格子への整列が必要です")
	}
	if session.Kind == "Night" && session.USOpen != cfg.USOpen {
		return fmt.Errorf("B5QDの場とActualで米国開始時計が異なります")
	}
	return nil
}

// assignDeferredClock は新しい出生の登録時にだけ停止純時計を一回呼びます。
//
// 引数: source(SourceIdentity)、ordinal(int)は元出生全文と登録順です。
// 返り値: *ClockOpportunityAudit/errorは独立値の割当根拠又は時計差です。
// Force/P締切/EOF/Source取消・完結/予約の判断及びConsumedは変更しません。
func (b *ActualBook) assignDeferredClock(source SourceIdentity, ordinal int) (*ClockOpportunityAudit, error) {
	session, cfg := b.result.Session, b.result.Config
	a, err := clock.AssignQuietOnceWithDuration(clock.SessionClock{Kind: session.Kind, Start: session.Start, USOpen: cfg.USOpen}, source.BirthTime, b.quietDuration())
	if err != nil {
		return nil, err
	}
	return &ClockOpportunityAudit{Ordinal: ordinal, Source: valueCopy(source), StrictAt: a.StrictAt, AssignedAt: a.AssignedAt, QuietStart: a.QuietStart, QuietEnd: a.QuietEnd, Reason: a.Reason, Deferred: a.Deferred}, nil
}

// ClockAudit はB5QDの割当出典を独立複写し、B5Qでは空の配列を返します。
//
// 引数: なし。
// 返り値: ClockBookAuditは元金融JSONへ追加しない読取専用の全出生根拠です。
func (b *ActualBook) ClockAudit() ClockBookAudit {
	out := ClockBookAudit{Timing: b.result.Config.EntryTiming, Opportunities: []ClockOpportunityAudit{}}
	for _, a := range b.clockAudit {
		out.Opportunities = append(out.Opportunities, valueCopy(a))
	}
	return out
}
