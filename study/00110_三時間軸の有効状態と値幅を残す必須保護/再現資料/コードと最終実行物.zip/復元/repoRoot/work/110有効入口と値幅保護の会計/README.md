# 有効入口と値幅保護の会計110

停止109のActorを別moduleへ派生した人工検査版。市場入力・損益結果・未使用11月09日の本文は読まない。正式な金融実行や試行完了の記録ではない。

`NewCompositeBook`でE0/L0、E2/L0、E2/L1とG0/G3/G4を組み合わせる。費用4感度を含め36構成。入口の技法は外の純E2へ委譲し、このActorはSource・元方向・元数量・当時気配・余力・時計・一度だけの実要求を管理する。[仕様](仕様.md)を参照。

E0/G0のActualResult・WidthAudit・EarlyAudit・ClockAuditは旧108と停止109の実APIへ同じ人工Source通知を配送し、非ゼロ取引の各時点で全JSONを比較する。E0の内ActorConfigへ寿命fieldを増やさない。E2の内設定は`ENTRY_E2`と`entry_lifetime=L0/L1`で区別する。

G3/G4は停止した`profitfloor110`を直接使う。新規時のV、最初に既知となるnativeATR、Hの成分と固定時計を保存する。A後判明は`first_threshold_lock`にその現在原行を保存し、過去の利益で遡及起動しない。約定・費用・Source部分返済・予約・mark順序は既存会計を継承する。

人工検査は `go test ./...`、`go vet ./...`、`go build ./...`。固定検査器 `python 検査と停止を記録する.py` は停止ファイルの既存出力を拒否する。停止後は編集せず、変更は別派生へ保存する。
