"""手製2520閲覧資源と70Nativeで正式保存の境界と同bytesを検査する。"""

import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import 正式保存する as S

TEST_PATH = S.ROOT / "work/110報告の準備/報告の人工検査.py"
if S.sha(TEST_PATH) != "1d9c4dcc1d89682f32bb48d33641141da86df1029afe6891d8a598a296098959":
    raise ValueError("停止報告人工のSHA差")
REPORT_FOLDER = TEST_PATH.parent
import sys
sys.path.insert(0, str(REPORT_FOLDER))
SPEC = importlib.util.spec_from_file_location("正式保存が使う手製値", TEST_PATH)
ART = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ART)


def write(path: Path, value) -> dict:
    """機能: 手製JSONを新規保存しFileRefを作る。

    引数: path(Path)、value(any)は保存先と手製値。
    返り値: dictは絶対pathとSHA256。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, default=ART.serial), encoding="utf-8")
    return {"path": str(path.resolve()), "sha256": S.sha(path)}


def fixture(base: Path, failure: str = "") -> tuple[dict, dict]:
    """機能: 全70成功metadataと空約定の人工保存集合を作る。

    引数: base(Path)、failure(str)は一時領域と破壊種別。
    返り値: tuple[dict,dict]は要求FileRefと元の要求。実市場は開かない。
    """
    result = ART.fixture()
    saved_dir, market_dir, frequency_dir, aggregate_dir = (base / n for n in ("saved", "market", "frequency", "aggregate"))
    for path in (saved_dir, market_dir, frequency_dir, aggregate_dir):
        path.mkdir()
    sessions = [r["session"] for r in result["場別"] if r["key"] == ART.R.KEYS[0]]
    native, market_rows = [], []
    for sid in sessions:
        path = market_dir / (sid + ".Native.json.gz")
        path.write_bytes(("手製 " + sid).encode("utf-8"))
        ref = {"path": str(path.resolve()), "sha256": S.sha(path)}
        row = {"session": sid, "native": ref, "books": 36, "baseline_comparisons": 4, "baseline_all": True,
               "unchanged": True, "before": {"手製": "固定"}, "after": {"手製": "固定"}}
        market_rows.append(row)
        native.append({"session": sid, "native": ref,
                       "sidecar_header": {"path": "開かないSource公表Header", "sha256": "0" * 64},
                       "sidecar_records": {"path": "開かないSource公表Record", "sha256": "1" * 64}})
    market = {"version": 1, "trial": 110, "stage": "full70", "success": failure != "金融失敗", "sessions": 70,
              "books_per_scene": 36, "books": 2520, "shadow_books": 0, "baseline_comparisons": 280, "results": market_rows,
              "condition_sha256": ART.R.ALIGNED_SHA, "unchanged": True, "before": {"手製": "固定"}, "after": {"手製": "固定"}}
    market_ref = write(market_dir / "完了.json", market)
    frequency = {"version": 1, "trial": 110, "stage": "first2" if failure == "頻度途中" else "full70", "success": True,
                 "results": [{"session": sid} for sid in sessions], "unchanged": True, "before": {"手製": "固定"}, "after": {"手製": "固定"},
                 "financial_executed": False, "participation_calculated": False,
                 "technique_fixed": {"path": "参照を開かない既停止技法", "sha256": S.TECHNIQUE_SHA}}
    frequency_ref = write(frequency_dir / "完成.json", frequency)
    summary = {"成功": True, "unchanged": True, "stage": "full70", "sessions": 70, "completion": frequency_ref,
               "technique_fixed": frequency["technique_fixed"],
               "totals": {"primary": {"planned": 7980}, "secondary": {"planned": 7700}},
               "financial_executed": False, "participation_calculated": False, "l1_eligibility_calculated": False,
               "opportunity_pnl_calculated": False, "holdout_11_09_read": False}
    if failure == "頻度誤結合":
        summary["completion"] = {"path": frequency_ref["path"], "sha256": "a" * 64}
    summary_ref = write(aggregate_dir / "独立集計.json", summary)
    result["Native参照"], result["金融完了SHA256"] = native, market_ref["sha256"]
    result_ref = write(saved_dir / "結果.json", result)
    resources = []
    for key in ART.R.KEYS:
        for sid in sessions:
            name = f"110_{key}_{sid}.trades.jsonl"
            (saved_dir / name).write_text("", encoding="utf-8")
            resources.append({"id": name.removesuffix(".trades.jsonl"), "pnl_path": name})
    if failure == "Viewer重複":
        resources[1]["id"] = resources[0]["id"]
    write(saved_dir / "一覧.resources.json", {"schema_version": 1, "path_base": "catalog", "resources": resources})
    output_sha = {path.name: S.sha(path) for path in saved_dir.iterdir()}
    if failure == "不明ファイル":
        output_sha["追加の途中.json"] = "0" * 64
    saved = {"成功": True, "前後不変": True, "不一致数": 0, "会計": 2520, "資源": 2520, "旧対照": 280,
             "出力SHA256": output_sha, "金融条件SHA256": ART.R.ALIGNED_SHA, "金融完了SHA256": market_ref["sha256"]}
    saved_ref = write(saved_dir / "保存会計の確認.json", saved)
    csvs = {}
    for name in S.FREQUENCY_NAMES:
        path = aggregate_dir / name
        path.write_text("手製,件数\n人工,1\n", encoding="utf-8")
        csvs[name] = {"path": str(path.resolve()), "sha256": S.sha(path)}
    if failure == "頻度CSV不足":
        csvs.pop(next(iter(csvs)))
    request = {"version": 1, "trial": 110, "refs": {"result": result_ref, "saved_check": saved_ref,
               "market": market_ref, "frequency": frequency_ref, "frequency_summary": summary_ref},
               "frequency_csv": csvs, "metadata": []}
    return write(base / "要求.json", request), request


class 正式保存検査(unittest.TestCase):
    """機能: 実市場を使わず正式保存の全件同bytesと拒否境界を確認する。"""

    def test_全件同バイトと上書き拒否(self):
        """機能: 2520閲覧資源、70Native、5CSVと小metadataだけを保存する。

        引数: self(正式保存検査)は検査器。
        返り値: None。
        """
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            ref, request = fixture(base)
            with patch.object(S, "TRIAL", base / "正式"):
                proof = S.execute(ref)
                self.assertTrue(proof["成功"])
                self.assertEqual(proof["同bytes"], 2602)
                receipt = json.loads((S.TRIAL / "検査/正式保存の確認.json").read_text(encoding="utf-8"))
                self.assertEqual((receipt["Native数"], receipt["Viewer資源"], receipt["頻度CSV"]), (70, 2520, 5))
                for row in receipt["成果物同bytes"]:
                    self.assertEqual(S.sha(S.TRIAL / row["path"]), row["sha256"])
                for forbidden in ("原板複写", "共有CSV複写", "Source公表複写", "市場頻度全行転記"):
                    self.assertFalse(receipt[forbidden])
                self.assertEqual(len(list((S.TRIAL / "成果物").glob("*.trades.jsonl"))), 2520)
                self.assertEqual(len(list((S.TRIAL / "成果物_金融/Native").glob("*"))), 70)
                with self.assertRaises(ValueError):
                    S.execute(ref)

    def test_失敗や不足はコピー前拒否(self):
        """機能: 金融/頻度失敗、不明ファイル、不完全頻度、Viewer重複を拒否する。

        引数: self(正式保存検査)は検査器。
        返り値: None。6破壊反例を確認する。
        """
        for failure in ("金融失敗", "頻度途中", "頻度誤結合", "不明ファイル", "頻度CSV不足", "Viewer重複"):
            with self.subTest(failure=failure), tempfile.TemporaryDirectory() as directory:
                base = Path(directory)
                ref, _ = fixture(base, failure)
                with patch.object(S, "TRIAL", base / "正式"):
                    with self.assertRaises(ValueError):
                        S.execute(ref)
                    self.assertFalse(S.TRIAL.exists())

    def test_誤指紋と不明metadataと既存先(self):
        """機能: 誤SHA、任意metadata、既存ファイルをコピー前拒否する。

        引数: self(正式保存検査)は検査器。
        返り値: None。
        """
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            ref, request = fixture(base)
            with patch.object(S, "TRIAL", base / "正式"):
                with self.assertRaises(ValueError):
                    S.execute({**ref, "sha256": "0" * 64})
                request["metadata"] = [{"name": "../自由.json", "ref": request["refs"]["market"]}]
                bad = write(base / "不正要求.json", request)
                with self.assertRaises(ValueError):
                    S.execute(bad)
                self.assertFalse(S.TRIAL.exists())
                (S.TRIAL / "成果物").mkdir(parents=True)
                with self.assertRaises(ValueError):
                    S.execute(ref)
                self.assertEqual(list((S.TRIAL / "成果物").iterdir()), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
