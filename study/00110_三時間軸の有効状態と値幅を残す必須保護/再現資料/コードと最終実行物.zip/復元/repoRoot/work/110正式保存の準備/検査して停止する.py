"""新規保存helperの人工検査を実行し、コードを一度だけ停止する。"""

import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
DEPENDENCIES = {
    "work/110報告の準備/報告を作る.py": "c8bda50ef83cfa12aea83d677027321a6492a804d42c4328926cec0dc8bc100f",
    "work/110報告の準備/報告の人工検査.py": "1d9c4dcc1d89682f32bb48d33641141da86df1029afe6891d8a598a296098959",
    "work/110報告の準備/停止.json": "2736e41fb11443a24bfd07baff979a5b87e6737800a1ba05cbb828d7a72e35d8"
}


def sha(path: Path) -> str:
    """機能: 停止ファイルの全バイト指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def owned() -> dict:
    """機能: 所有4ファイルの指紋を返す。

    引数: なし。
    返り値: dictはRoot相対pathとSHA256。
    """
    names = ("正式保存する.py", "正式保存の人工検査.py", "検査して停止する.py", "README.md")
    return {(HERE / n).relative_to(ROOT).as_posix(): sha(HERE / n) for n in names}


def main() -> None:
    """機能: 人工検査・コメント・依存不変を確認して停止記録を作る。

    引数: なし。実市場と正式成果物を読み書きしない。
    返り値: None。失敗時は成功記録を作らない。
    """
    if (HERE / "停止.json").exists() or (HERE / "人工確認.json").exists():
        raise ValueError("停止記録は新規だけ")
    before = owned()
    if any(sha(ROOT / n) != s for n, s in DEPENDENCIES.items()):
        raise ValueError("停止報告器の依存指紋差")
    functions = 0
    for name in before:
        path = ROOT / name
        if path.suffix != ".py":
            continue
        for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                doc = ast.get_docstring(node) or ""
                if not ("\n" in doc and all(w in doc for w in ("機能", "引数", "返り値"))):
                    raise ValueError("関数コメント不足: " + node.name)
                functions += 1
    run = subprocess.run([sys.executable, "-B", "-X", "utf8", str(HERE / "正式保存の人工検査.py")],
                         cwd=ROOT, capture_output=True, text=True, encoding="utf-8")
    if run.returncode or owned() != before or any(sha(ROOT / n) != s for n, s in DEPENDENCIES.items()):
        print(run.stdout + run.stderr)
        raise ValueError("人工失敗又はコード不変差")
    check = {"成功": True, "UTC": datetime.now(timezone.utc).isoformat(), "主test": 3, "破壊反例": 6, "関数コメント": functions,
             "終了コード": run.returncode, "標準出力": run.stdout, "標準エラー": run.stderr, "自己コード依存前後不変": True,
             "実金融結果読取": 0, "市場本文読取": 0, "正式文書変更": 0}
    (HERE / "人工確認.json").write_text(json.dumps(check, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    stop = {"成功": True, "停止": True, "UTC": datetime.now(timezone.utc).isoformat(), "所有コードSHA256": before,
            "依存コードSHA256": DEPENDENCIES, "人工確認SHA256": sha(HERE / "人工確認.json"),
            "主test": 3, "破壊反例": 6, "自己コード依存前後不変": True,
            "範囲": "手製2520Viewer資源/70金融Native/5頻度CSV/小metadataの新規同bytes正式保存",
            "実金融結果読取": 0, "市場本文読取": 0, "正式文書変更": 0, "採用": False, "研究目標達成": False}
    (HERE / "停止.json").write_text(json.dumps(stop, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "停止SHA256": sha(HERE / "停止.json"), "主test": 3, "関数": functions}, ensure_ascii=False))


if __name__ == "__main__":
    main()
