"""成功した110全70の閲覧資料と金融Nativeだけを同bytesで正式保存する。"""

from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00110_三時間軸の有効状態と値幅を残す必須保護"
REPORT_PATH = ROOT / "work/110報告の準備/報告を作る.py"
REPORT_SHA = "c8bda50ef83cfa12aea83d677027321a6492a804d42c4328926cec0dc8bc100f"
TECHNIQUE_SHA = "7d4f0135f9ed1cda0d4298355e046db02461a2a02a6ee46f6b7d783489fb023a"
FREQUENCY_NAMES = {"場別の主副頻度.csv", "日夜と固定期の頻度.csv", "三経路の優先と重なり.csv", "並列条件群の頻度.csv", "Source予定L0と技術状態.csv"}
OPTIONAL_TARGETS = {"金融先頭2場.json", "頻度先頭2場.json", "保存実行の固定.json", "頻度実行の固定.json"}


def need(condition: bool, reason: str) -> None:
    """機能: 不正な保存条件を拒否する。

    引数: condition(bool)、reason(str)は成立条件と理由。
    返り値: None。不成立時はValueError。
    """
    if not condition:
        raise ValueError(reason)


def sha(path: Path) -> str:
    """機能: 明示した成果物だけを全バイト指紋化する。

    引数: path(Path)は検算後の保存ファイル。
    返り値: strはSHA256。原板や共有価格CSVを渡さない。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def reference(ref: dict) -> Path:
    """機能: 絶対参照の実物指紋を認証する。

    引数: ref(dict)はpath/sha256。
    返り値: Pathは認証済み絶対位置。
    """
    need(set(ref) == {"path", "sha256"} and isinstance(ref["path"], str), "FileRefの明示型")
    path = Path(ref["path"])
    need(path.is_absolute() and bool(re.fullmatch(r"[a-f0-9]{64}", ref["sha256"])), "絶対pathとSHA")
    need(path.is_file() and sha(path) == ref["sha256"], "参照実物差: " + str(path))
    return path.resolve()


def read(ref: dict) -> dict:
    """機能: 認証済み小JSONだけを読む。

    引数: ref(dict)は明示FileRef。
    返り値: dictはmetadata。Nativeや原板をJSONとして読まない。
    """
    path = reference(ref)
    need(path.suffix == ".json", "小JSON拡張子")
    return json.loads(path.read_text(encoding="utf-8-sig"))


def report_module():
    """機能: 停止済み報告器の純集計検査だけを再用する。

    引数: なし。報告器の固定SHAを使う。
    返り値: moduleは変更しない検査関数群。
    """
    need(sha(REPORT_PATH) == REPORT_SHA, "停止報告器SHA")
    spec = importlib.util.spec_from_file_location("正式保存の純集計検査", REPORT_PATH)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def prepare(request_ref: dict) -> tuple[dict, list[dict], dict]:
    """機能: 全成功・全参照・全保存先を変更前に検査する。

    引数: request_ref(dict)はRootの成功後保存要求。
    返り値: tuple[dict,list[dict],dict]は要求、全コピー計画、金融Native台帳。
    """
    request = read(request_ref)
    need(request["version"] == 1 and request["trial"] == 110, "110要求")
    refs = request["refs"]
    need(set(refs) == {"result", "saved_check", "market", "frequency", "frequency_summary"}, "必須5成功参照")
    values = {name: read(ref) for name, ref in refs.items()}
    result, saved, market, frequency, summary = (values[n] for n in ("result", "saved_check", "market", "frequency", "frequency_summary"))
    module = report_module()
    # ----------------------------------------
    # 報告器と同じDecimal読取を使い、JSON小数の丸めだけで円検算を壊しません。
    result = module.load_ref(Path(refs["result"]["path"]), refs["result"]["sha256"])
    module.validate(result)
    need(saved["成功"] is True and saved["前後不変"] is True and saved["不一致数"] == 0, "保存検算成功")
    need(saved["会計"] == saved["資源"] == 2520 and saved["旧対照"] == 280, "保存全件数")
    need(saved["出力SHA256"]["結果.json"] == refs["result"]["sha256"], "結果と保存検算の結合")
    need(result["金融条件SHA256"] == saved["金融条件SHA256"] == market["condition_sha256"] == module.ALIGNED_SHA, "全金融条件同体")
    need(result["金融完了SHA256"] == saved["金融完了SHA256"] == refs["market"]["sha256"], "金融完了との結合")
    need(market["version"] == 1 and market["trial"] == 110 and market["stage"] == "full70" and market["success"], "金融全70成功")
    need((market["sessions"], market["books_per_scene"], market["books"], market["shadow_books"], market["baseline_comparisons"]) == (70, 36, 2520, 0, 280), "金融全件数")
    need(market["unchanged"] and market["before"] and market["before"] == market["after"], "金融入力不変")
    need(frequency["trial"] == 110 and frequency["stage"] == "full70" and frequency["success"], "頻度全70成功")
    need(frequency["unchanged"] and frequency["before"] and frequency["before"] == frequency["after"], "頻度入力不変")
    need(frequency["financial_executed"] is False and frequency["participation_calculated"] is False, "頻度と金融の責務")
    need(summary["成功"] is True and summary["unchanged"] and summary["stage"] == "full70" and summary["sessions"] == 70, "頻度独立集計成功")
    need(summary["completion"] == refs["frequency"], "独立頻度と完成参照")
    need(frequency["technique_fixed"] == summary["technique_fixed"] and frequency["technique_fixed"]["sha256"] == TECHNIQUE_SHA, "同じ停止110技法")
    need(summary["totals"]["primary"]["planned"] == 7980 and summary["totals"]["secondary"]["planned"] == 7700, "頻度主副分母")
    need(all(summary[n] is False for n in ("financial_executed", "participation_calculated", "l1_eligibility_calculated", "opportunity_pnl_calculated", "holdout_11_09_read")), "頻度範囲")
    expected_sessions = [r["session"] for r in result["場別"] if r["key"] == module.KEYS[0]]
    need([r["session"] for r in market["results"]] == expected_sessions and [r["session"] for r in frequency["results"]] == expected_sessions, "金融/頻度/保存の同じ場順")
    need(not (TRIAL / "成果物").exists() and not (TRIAL / "成果物_金融").exists(), "正式主保存先は新規")
    need(not (TRIAL / "検査/正式保存の確認.json").exists(), "正式確認は新規")
    plans, targets = [], set()

    def add(source_ref: dict, relative: str) -> None:
        """機能: 安全な新規先への同bytesコピーを予約する。

        引数: source_ref(dict)、relative(str)は成果物参照と試行内相対先。
        返り値: None。全予約完了まではコピーしない。
        """
        source = reference(source_ref)
        rel = Path(relative)
        target = (TRIAL / rel).resolve()
        need(not rel.is_absolute() and ".." not in rel.parts and target.is_relative_to(TRIAL.resolve()), "試行外保存を拒否")
        need(str(target).casefold() not in targets and not target.exists(), "同名/既存正本を拒否")
        targets.add(str(target).casefold())
        plans.append({"source": str(source), "target": str(target), "relative": rel.as_posix(), "sha256": source_ref["sha256"]})

    # ----------------------------------------
    # 保存検算の全出力集合を使い、隣の途中ファイルや原板を列挙コピーしません。
    saved_dir = Path(refs["result"]["path"]).resolve().parent
    need(Path(refs["saved_check"]["path"]).resolve().parent == saved_dir, "保存正本と確認は同じfolder")
    expected_files = {"結果.json", "一覧.resources.json"} | {f"110_{key}_{sid}.trades.jsonl" for key in module.KEYS for sid in expected_sessions}
    need(set(saved["出力SHA256"]) == expected_files and len(expected_files) == 2522, "保存出力2522の明示集合")
    for name in sorted(expected_files):
        add({"path": str(saved_dir / name), "sha256": saved["出力SHA256"][name]}, "成果物/" + name)
    add(refs["saved_check"], "成果物/保存会計の確認.json")
    catalog = read({"path": str(saved_dir / "一覧.resources.json"), "sha256": saved["出力SHA256"]["一覧.resources.json"]})
    need(catalog["schema_version"] == 1 and catalog["path_base"] == "catalog" and len(catalog["resources"]) == 2520, "Viewer一覧全件")
    need({r["pnl_path"] for r in catalog["resources"]} == expected_files - {"結果.json", "一覧.resources.json"}, "全資源と約定の対応")
    need(len({r["id"] for r in catalog["resources"]}) == 2520, "Viewer IDの一意性")
    native, by_session = [], {r["session"]: r for r in market["results"]}
    need(len(result["Native参照"]) == 70, "保存Native参照全70")
    for row in result["Native参照"]:
        sid, ref = row["session"], row["native"]
        need(ref == by_session[sid]["native"], "保存と金融のNative参照同体")
        path = Path(ref["path"]).resolve()
        need(path.parent == Path(refs["market"]["path"]).resolve().parent and path.name == sid + ".Native.json.gz", "金融Nativeの範囲")
        need(by_session[sid]["books"] == 36 and by_session[sid]["baseline_comparisons"] == 4 and by_session[sid]["baseline_all"], "場別の36/旧4成功")
        need(by_session[sid]["unchanged"] and by_session[sid]["before"] == by_session[sid]["after"], "場別入力不変")
        add(ref, "成果物_金融/Native/" + path.name)
        native.append({"session": sid, "path": "成果物_金融/Native/" + path.name, "sha256": ref["sha256"], "bytes": path.stat().st_size,
                       "元": ref, "同bytes": True, "会計": 36, "Source公表": {n: row[n] for n in ("sidecar_header", "sidecar_records")}})
    need([r["session"] for r in native] == expected_sessions, "Native全70順序")
    for name, target in (("market", "金融全70場.json"), ("frequency", "頻度全70場.json"), ("frequency_summary", "頻度の独立集計.json")):
        add(refs[name], "検査/" + target)
    need(set(request["frequency_csv"]) == FREQUENCY_NAMES, "頻度の5CSVだけ")
    for name, ref in request["frequency_csv"].items():
        need(Path(ref["path"]).resolve().parent == Path(refs["frequency_summary"]["path"]).resolve().parent, "頻度CSVの範囲")
        need(Path(ref["path"]).name == name, "頻度CSV本名")
        add(ref, "診断/入口頻度/" + name)
    for item in request.get("metadata", []):
        need(item["name"] in OPTIONAL_TARGETS, "小metadataの許可名")
        add(item["ref"], "検査/" + item["name"])
    add(request_ref, "検査/正式保存の要求.json")
    index = {"成功": True, "試行": 110, "場数": 70, "金融会計": 2520, "元金融完了": refs["market"], "Native": native,
             "基準": "Main36金融Nativeを同bytes保存。Source公表/原板/価格CSVは参照し複製しない"}
    return request, plans, index


def execute(request_ref: dict) -> dict:
    """機能: 全事前確認後に予約成果物を新規先へ同bytes保存する。

    引数: request_ref(dict)は成功後に固定したRoot要求。
    返り値: dictは全同bytes台帳。失敗時は途中を成功扱いしない。
    """
    request, plans, index = prepare(request_ref)
    copied = []
    for row in plans:
        source, target = Path(row["source"]), Path(row["target"])
        need(sha(source) == row["sha256"] and not target.exists(), "コピー直前の不変/新規")
        target.parent.mkdir(parents=True, exist_ok=True)
        with source.open("rb") as src, target.open("xb") as dst:
            shutil.copyfileobj(src, dst)
        need(sha(target) == sha(source) == row["sha256"], "保存直後の同bytes")
        copied.append({"path": row["relative"], "sha256": row["sha256"], "bytes": target.stat().st_size,
                       "元": {"path": row["source"], "sha256": row["sha256"]}, "同bytes": True})
    index_path = TRIAL / "成果物_金融/Native参照台帳.json"
    with index_path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(index, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    need(all(sha(Path(r["source"])) == sha(Path(r["target"])) == r["sha256"] for r in plans), "全入出力の最終同bytes")
    receipt = {"成功": True, "試行": 110, "成果物同bytes": copied, "Native台帳": {"path": "成果物_金融/Native参照台帳.json", "sha256": sha(index_path)},
               "Native数": 70, "Viewer資源": 2520, "頻度CSV": 5, "原板複写": False, "共有CSV複写": False, "Source公表複写": False,
               "市場頻度全行転記": False, "研究目標達成": False, "採用": False}
    receipt_path = TRIAL / "検査/正式保存の確認.json"
    with receipt_path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(receipt, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    return {"成功": True, "同bytes": len(copied), "Native": 70, "資源": 2520, "確認SHA256": sha(receipt_path)}


def main() -> None:
    """機能: 全70成功後の要求指紋を受け正式保存する。

    引数: --request/--request-shaはRootの要求JSONと期待SHA。
    返り値: None。小計だけを標準出力へ出す。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--request", required=True, type=Path)
    parser.add_argument("--request-sha", required=True)
    args = parser.parse_args()
    print(json.dumps(execute({"path": str(args.request.resolve()), "sha256": args.request_sha}), ensure_ascii=False))


if __name__ == "__main__":
    main()
