"""106の実P0共通会計とW/E専用保存auditを分けて検算する。"""

import argparse
from collections import Counter
import copy
from decimal import Decimal
import gzip
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import types


ROOT = Path(__file__).resolve().parents[2]
OLD_PATH = ROOT / "work/105LD10の保存準備/集計.py"
OLD_SHA = "5192dfd09bd22c3a9975273bcaedbc8778694b10635094effe7143c75fa549bd"
if hashlib.sha256(OLD_PATH.read_bytes()).hexdigest() != OLD_SHA:
    raise ValueError("固定105保存器の指紋差")
SPEC = importlib.util.spec_from_file_location("106が再用する固定105保存", OLD_PATH)
PREVIOUS = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PREVIOUS)
OLD = PREVIOUS.OLD
BASE, GRID = OLD.BASE, OLD.GRID
need, equal, number = OLD.need, OLD.equal, OLD.number
load, digest = OLD.load, OLD.digest
POLICIES = ("W0", "W1", "W2", "E1", "E2")
KEYS = tuple(f"{p}_C{c}_D{d}" for p in POLICIES for c in (0, 5) for d in (0, 1))
E_KEYS = tuple(k for k in KEYS if k.startswith("E"))
CORE_STOP_SHA = "c465bd1696fe1e5d2f4c9b299712866c96b73b4126bf4883245acc47fec154f3"
IO_STOP_PATH = ROOT / "work/106市場の入出力準備/停止.json"
IO_STOP_SHA = "f211f764db4914a294452e2e99118c60de3153348fe76f8490ddfab15a510f0e"
PUBLIC_PATH = ROOT / "work/可変追尾向けの公開チャート/純式への型接続.py"
PUBLIC_SHA = "39a6ff72e94bdcb25f6344f8bb19fdeed8454fa9f7710737d0207e8a0efba18c"
if digest(PUBLIC_PATH) != PUBLIC_SHA:
    raise ValueError("固定公開型射影の指紋差")
PUBLIC_SPEC = importlib.util.spec_from_file_location("106の固定公開型射影", PUBLIC_PATH)
PUBLIC = importlib.util.module_from_spec(PUBLIC_SPEC)
PUBLIC_SPEC.loader.exec_module(PUBLIC)


def config_for(key):
    """
    機能: 実在する金融内Keyを実政策へ分解する。EをLDに置換しない。
    引数: key(str)はLD10/E1/E2_B5Q_P0_Cx_Dy。
    返り値: tuple[str,str,int,int]は実P0、起動政策、滑り、遅延。
    """
    names = {f"{a}_B5Q_P0_C{c}_D{d}": ("P0", a, c, d)
             for a in ("LD10", "E1", "E2") for c in (0, 5) for d in (0, 1)}
    need(key in names, "106の金融内Key")
    return names[key]


def inner_key(key):
    """
    機能: 幅政策を金融内Keyと分けて扱う。
    引数: key(str)は外20Key。
    返り値: strはW系LD10又はE本名の内Key。
    """
    need(key in KEYS, "106の外Key")
    p, c, d = key.split("_")
    return f"{p if p.startswith('E') else 'LD10'}_B5Q_P0_{c}_{d}"


def grid_config(key):
    """
    機能: 実B5Q/P0の時計だけを固定95規範へ対応する。
    引数: key(str)は実金融内Key。
    返り値: tupleは時計・基本P0名・費用・遅延。
    """
    _, _, c, d = config_for(key)
    return "B5Q", f"P0_C{c}_D{d}", c, d


# ----------------------------------------
# 本文を変えず、実Key対応だけを独立した関数名前空間に置く。
GRID_SPACE = dict(vars(GRID))
for _name, _fn in vars(GRID).items():
    if isinstance(_fn, types.FunctionType) and _fn.__module__ == GRID.__name__:
        GRID_SPACE[_name] = types.FunctionType(_fn.__code__, GRID_SPACE, _name,
                                                _fn.__defaults__, _fn.__closure__)
GRID_SPACE["key_config"] = grid_config


def finite(value, label):
    """
    機能: 非金融幅の元IEEE64数値を検査する。未知を0にしない。
    引数: value(int|float|Decimal)、label(str)は値と診断名。
    返り値: floatは有限値。金額の許容幅を導入しない。
    """
    need(type(value) in (int, float, Decimal), label + "数値型")
    result = float(value)
    need(math.isfinite(result), label + "有限")
    return result


def truth(v):
    """
    機能: 既知性とnullable成立値の対応を検査する。
    引数: v(dict)はknown/passedの公開値。
    返り値: dictは変更しない検算済み値。
    """
    need(set(v) == {"known", "passed"} and type(v["known"]) is bool, "三値の型")
    need(type(v["passed"]) is bool if v["known"] else v["passed"] is None, "三値のnullable")
    return v


def and_truth(values):
    """
    機能: 既知否定を優先する三値ANDを評価する。
    引数: values(list[dict])は検査するC/M又はC/M/P。
    返り値: dictは既知否定・全成立・必要未知。
    """
    values = [truth(v) for v in values]
    if any(v["known"] and not v["passed"] for v in values):
        return {"known": True, "passed": False}
    return {"known": True, "passed": True} if all(v["known"] for v in values) else {"known": False, "passed": None}


def sha_valid(value):
    """
    機能: 小文字SHA256文字列を検査する。
    引数: value(any)は出典指紋。
    返り値: boolは64桁16進表記だけ真。
    """
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def observation(v, scene, contract, side, at, registry=None):
    """
    機能: 幅公表の実出典・場・限月・方向・公開時計を結合する。
    引数: v(dict|None)、scene/contract(str)、side(int)、at(数値)、registry(dict|None)。
    返り値: dict|Noneは検査済み公表。registryなし人工は指紋の出所再現まで主張しない。
    """
    if v is None:
        return None
    equal(set(v), {"session", "contract", "side", "publication_id", "ordinal", "end", "available_at", "c", "m", "p", "frame_sha256", "result_sha256"}, "公表境界型")
    equal((v["session"], v["contract"], v["side"]), (scene, contract, side), "公表の場/限月/方向")
    need(type(v["ordinal"]) is int and v["ordinal"] > 0, "公表ordinal")
    end = finite(v["end"], "公表end")
    need(end >= 0 and v["available_at"] == v["end"] <= at, "公表時計")
    identifier = json.dumps([scene, contract, float(end)], ensure_ascii=False, separators=(",", ":"))
    equal(v["publication_id"], identifier, "公表IDの実時計")
    for name in ("c", "m", "p"):
        truth(v[name])
    need(sha_valid(v["frame_sha256"]) and sha_valid(v["result_sha256"]), "公表出典SHA")
    if registry is not None:
        k = (identifier, side)
        need(k in registry, "公表根拠が保存sidecarにない")
        equal(float_values(v), registry[k], "公表全fieldとsidecar出典")
    return v


def condition(v, policy):
    """
    機能: 幅/早期起動の必要役割を政策に応じて選ぶ。
    引数: v(dict|None)は公表、policy(str)はW1/W2/E1/E2。
    返り値: dictはC/M又はC/M/Pの三値AND。
    """
    if v is None:
        return {"known": False, "passed": None}
    return and_truth([v[k] for k in (("c", "m", "p") if policy in ("W2", "E2") else ("c", "m"))])


def float_values(value):
    """
    機能: 金額用Decimal読取から公開型のJSON数値表現だけを戻す。
    引数: value(any)は公開Frame/結果の値。
    返り値: anyは整数表記を保持し小数だけIEEE64へ写す独立値。
    """
    if isinstance(value, dict):
        return {k: float_values(v) for k, v in value.items()}
    if isinstance(value, list):
        return [float_values(v) for v in value]
    return float(value) if isinstance(value, Decimal) else value


def canonical_sha(value):
    """
    機能: 停止配送のPython canonicalと同じ公開型SHAを得る。
    引数: value(dict)は公開Frame又はC/M/P結果。
    返り値: strは指紋。金融金額の丸めには使用しない。
    """
    body = json.dumps(float_values(value), ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(body.encode("utf-8")).hexdigest()


def quote_key(q):
    """
    機能: 特徴Indexと物理行を混同せず当原行を識別する。
    引数: q(dict)はActual Quote又はScalar。
    返り値: tupleは時刻・特徴Index・物理行。
    """
    return q["time"], q["index"], q["source_line"]


class PublicationRegistry(dict):
    """保存根拠を一度だけ持ち、必要な少数mark時点の公開状態を記録する。"""

    def __init__(self):
        """
        機能: 金融を再形成しない公開根拠台帳を初期化する。
        引数: なし。
        返り値: None。markごとに金融状態を生成しない。
        """
        super().__init__()
        self.live_by_quote = {}
        self.observations = self.resets = 0
        self.counts = {k: 0 for k in ("records", "quotes", "forces", "grids", "publications", "three_publications", "resets", "raw_boards")}
        self.diagnostics = {"new_three": 0, "C_known": 0, "C_pass": 0,
                            "buy": {"M_known": 0, "M_pass": 0, "P_known": 0, "P_pass": 0},
                            "sell": {"M_known": 0, "M_pass": 0, "P_known": 0, "P_pass": 0}}


def registry_from_records(records, value):
    """
    機能: 公表列のC/M/Pだけを固定純式で再評価し保存audit出典へ結ぶ。
    引数: records(iterable[dict])は保存sidecar、value(dict)はCore結果。
    返り値: PublicationRegistryは公表全値と少数mark時点の最新状態。OHLC/指標/Source/金融を再形成しない。
    """
    wanted = set()
    for book in value["books"].values():
        for p in book["positions"]:
            for point in list(p["marks"].values()) + [p["activation"], p["floor_updated"], p["first_floor_hit"]]:
                if point is not None:
                    wanted.add(quote_key(point["quote"]))
    for audit in value["width_audits"].values():
        for p in audit["positions"]:
            if p["first_narrow"] is not None:
                wanted.add(quote_key(p["first_narrow"]["quote"]))
    out, latest, previous = PublicationRegistry(), {1: None, -1: None}, {1: None, -1: None}
    tracker = PUBLIC.pure.Tracker()
    for r in records:
        r = float_values(r)
        out.counts["records"] += 1
        need(r["ordinal"] == out.counts["records"], "公開records連番")
        kind_to_count = {"quote": "quotes", "force": "forces", "grid": "grids", "publication": "publications", "reset": "resets", "raw_clock": "raw_boards"}
        need(r["kind"] in kind_to_count, "公開Record種別")
        out.counts[kind_to_count[r["kind"]]] += 1
        if r["kind"] == "quote":
            out.counts["raw_boards"] += 1
        if r["kind"] == "reset":
            tracker.reset(r["reset"]["reason"])
            latest = {1: None, -1: None}
            out.resets += 1
        elif r["kind"] == "publication" and r["publication"]["three"]:
            out.counts["three_publications"] += 1
            d = r["delivery"]
            frame = PUBLIC.to_frame(float_values(r["publication"]))
            equal(d["frame"], frame, "公表からの明示Frame全値")
            expected = tracker.feed(frame)
            equal(d["result"], expected, "保存C/M/Pと固定純式全値")
            if expected.get("reset_reason"):
                latest = {1: None, -1: None}
                out.resets += 1
            fh, rh = canonical_sha(d["frame"]), canonical_sha(d["result"])
            for side, role in ((1, "buy"), (-1, "sell")):
                o = d[role]
                if not expected["new"]:
                    need(o is None, "重複公表に新しい幅観測なし")
                    continue
                want = {"session": frame["session"], "contract": frame["contract"], "side": side,
                        "publication_id": frame["id"], "ordinal": frame["ordinal"], "end": frame["end"], "available_at": frame["available_at"],
                        "c": expected["C"], "m": expected[role]["M"], "p": expected[role]["P"], "frame_sha256": fh, "result_sha256": rh}
                equal(o, want, "公表から幅観測の全field/SHA")
                k = (o["publication_id"], side)
                if previous[side] == k:
                    equal(o, out[k], "同IDの内容不変")
                else:
                    need(k not in out, "過去公表の復活なし")
                    out[k] = o
                    latest[side], previous[side] = o, k
                    out.observations += 1
            out.diagnostics["new_three"] += 1
            for name in ("known", "pass"):
                out.diagnostics["C_" + name] += int(expected["C"]["known"] if name == "known" else expected["C"]["passed"] is True)
                for role in ("buy", "sell"):
                    for col in ("M", "P"):
                        out.diagnostics[role][col + "_" + name] += int(expected[role][col]["known"] if name == "known" else expected[role][col]["passed"] is True)
        elif r["kind"] == "quote":
            q = r["scalar"]
            if q["quote_ok"] and quote_key(q) in wanted:
                out.live_by_quote[quote_key(q)] = dict(latest)
    equal(set(out.live_by_quote), wanted, "全保存markの出典原行をsidecarへ結合")
    return out


def live_observation(registry, point, side):
    """
    機能: 同秒の原行順とresetを保持した当markの最新観測を得る。
    引数: registry(PublicationRegistry)、point(dict)、side(int)は保存markと実方向。
    返り値: dict|Noneは当時有効な観測。古い公表を復活しない。
    """
    k = quote_key(point["quote"])
    need(k in registry.live_by_quote, "markの最新観測結合欠落")
    return registry.live_by_quote[k][side]


def verify_activation(p, timeline, policy, activation, audit=None, contract=None, registry=None):
    """
    機能: LD10の旧閾値又はE本名の通常優先ORと実Activationを検査する。
    引数: p(dict)、timeline、policy/activation(str)、audit(dict|None)、contract(str)、registry(dict|None)。
    返り値: None。保存点の前後は検査するが全原行の最初の取り落とし再生ではない。
    """
    if activation == "LD10":
        OLD.verify_activation(p, timeline, policy, activation)
        return
    need(activation in ("E1", "E2"), "E起動本名")
    active = p["protection_active"]
    need(type(active) is bool, "起動型")
    if not active:
        need(audit is None and not p.get("activation_reason"), "未起動のE audit/理由")
    atr = p["atr"]
    normal = None if atr is None else 100.0 * max(10.0, finite(atr["value"], "ATR"))
    for point in p["marks"].values():
        if point is None or normal is None or point["quote"]["index"] < atr["quote"]["index"]:
            continue
        eligible = float(point["unit_net"]) >= normal
        if registry is not None:
            warning = condition(live_observation(registry, point, p["side"]), activation)
            eligible |= float(point["unit_net"]) >= 100.0 * max(10.0, 0.5 * float(atr["value"])) and warning == {"known": True, "passed": True}
        if eligible:
            need(active and BASE.point_order(p["activation"]) <= BASE.point_order(point), "保存通常LD10適格点より遅いE起動")
    if not active:
        return
    need(audit is not None and atr is not None, "E起動の専用audit/ATR")
    equal(set(audit), {"position_id", "policy", "trigger", "point", "atr_value", "early_threshold_yen", "normal_threshold_yen", "warning", "observation"}, "E audit型")
    equal((audit["position_id"], audit["policy"]), (p["id"], activation), "E audit所有/本名")
    point = p["activation"]
    equal(audit["point"], point, "E auditと実Activation全値")
    timeline.verify_position_point(p["id"], point)
    need(point["unit_net"] > 0 and atr["quote"]["index"] <= point["quote"]["index"], "E起動の実正益/公開ATR")
    first = p["marks"]["first_unit_positive"]
    need(first is not None and BASE.point_order(first) <= BASE.point_order(point), "初正益とE起動の別旗")
    raw = finite(atr["value"], "固定ATR")
    low = 100.0 * max(10.0, 0.5 * raw)
    equal(audit["atr_value"], atr["value"], "E生ATR値")
    need(float(audit["early_threshold_yen"]) == low and float(audit["normal_threshold_yen"]) == normal, "E二閾値IEEE64")
    o = observation(audit["observation"], p["source"]["session"] if "session" in p["source"] else timeline.session_id, contract, p["side"], point["quote"]["time"], registry)
    if registry is not None:
        equal(float_values(o), live_observation(registry, point, p["side"]), "E起動時の生存公表/reset")
    equal(truth(audit["warning"]), condition(o, activation), "E警戒の必要役割/未知")
    unit = float(point["unit_net"])
    trigger = "normal_ld10" if unit >= normal else "early_warning"
    equal(audit["trigger"], trigger, "通常LD10の優先")
    if trigger == "early_warning":
        need(unit >= low and audit["warning"] == {"known": True, "passed": True}, "LD05と既知警戒のAND")
        reason = activation + "LD05水準と既知収束失速警戒で早期保護起動"
    else:
        reason = activation + "通常LD10水準到達で保護起動"
    equal(p.get("activation_reason"), reason, "Eの起動理由")


def verify_marks(p, timeline, policy, activation, audit, contract, registry):
    """
    機能: 固定94の金額/所有/保存点規範を維持し、起動等式だけ実W/Eへ対応する。
    引数: p(dict)、timeline、policy/activation(str)、audit/registry(dict|None)、contract(str)。
    返り値: None。可変幅最終床は別WidthAuditで検査する。
    """
    def point_equal(actual, expected, label):
        """
        機能: 旧初正益即起動だけを実政策へ分離する。
        引数: actual/expected(any)、label(str)は固定94内の比較。
        返り値: None。金額・数量・価格・時計の比較許容は変えない。
        """
        if label == "起動と単価正益初回":
            return
        if label == "ATR age":
            a = p["atr"]
            equal(actual, GRID.clock_delta(a["quote"]["time"], a["available"]), "ATR ageの元IEEE64")
        elif label == "2ATR幅":
            need(float(actual) == 5.0 * math.ceil(2.0 * finite(p["atr"]["value"], "ATR") / 5.0), "2ATR元IEEE64")
        else:
            equal(actual, expected, label)
    namespace = {**vars(BASE), "equal": point_equal}
    types.FunctionType(BASE.verify_marks.__code__, namespace, "106の共通保存点")(p, timeline, policy)
    verify_activation(p, timeline, policy, activation, audit, contract, registry)


def verify_width(book, checked, policy, audit, early, contract, registry=None):
    """
    機能: 保存WidthStateと実玉の幅・峰・非緩和床・初狭幅出典を照合する。
    引数: book/checked/audit(dict)、policy/contract(str)、early/registry(dict|None)。
    返り値: None。少数保存点の整合であり全quoteの独立engineではない。
    """
    equal(set(audit), {"policy", "contract", "observations", "resets", "updates", "positions"}, "WidthAudit型")
    equal((audit["policy"], audit["contract"]), (policy, contract), "幅政策/限月")
    for k in ("observations", "resets", "updates"):
        need(type(audit[k]) is int and audit[k] >= 0, "幅counter型")
    positions = checked["positions"]
    by = {x["position_id"]: x for x in audit["positions"]}
    equal(len(by), len(audit["positions"]), "幅audit所有一意")
    equal(set(by), set() if policy == "W0" else {i for i, p in positions.items() if p["has_mark"]}, "幅auditの実観測玉集合")
    updates = 0
    for pid, p in positions.items():
        if policy == "W0":
            if p["protection_active"]:
                width = float(p["atr"]["width"]) if p["atr"] else None
                want = 0.0 if width is None else max(0.0, float(p["peak_gain"]) - width)
                need(float(p["floor_gain"]) == want, "W0元固定2ATR床")
            continue
        if not p["has_mark"]:
            continue
        x = by[pid]
        equal(set(x), {"position_id", "state", "last_update", "first_narrow", "first_narrow_observation", "first_narrow_condition"}, "玉別幅audit型")
        s, update = x["state"], x["last_update"]
        equal(set(s), {"policy", "session", "contract", "side", "entry_price", "active", "atr_lock", "peak_points", "floor_points", "narrowed", "narrowed_at", "narrowed_by", "latest", "last_observation", "consumed_publication", "last_at", "sequence", "finished"}, "幅state型")
        equal((s["policy"], s["session"], s["contract"], s["side"], s["entry_price"]), (policy, book["session"]["id"], contract, p["side"], p["entry_price"]), "幅state実所有/建値")
        equal((s["active"], s["peak_points"], s["floor_points"]), (p["protection_active"], p["peak_gain"], p["floor_gain"]), "幅stateと実起動/峰/床")
        equal(s["atr_lock"], p["atr"]["value"] if p["atr"] else None, "幅は取得時native生ATR")
        need(s["finished"] is True and p["quantity"] == p["reserved"] == 0, "幅stateの終玉")
        equal(s["last_at"], p["closed_quote"]["time"], "幅終玉時計")
        equal(set(update), {"state", "width_points", "condition", "used_publication", "reason"}, "幅update型")
        before_finish = copy.deepcopy(s)
        before_finish["finished"] = False
        before_finish["sequence"] -= 1
        before_finish["last_at"] = update["state"]["last_at"]
        equal(update["state"], before_finish, "終玉操作だけのstate差")
        need(type(s["sequence"]) is int and s["sequence"] >= 2 and s["last_at"] >= update["state"]["last_at"], "幅更新時計/sequence")
        equal(update["state"]["last_at"], p["marks"]["last"]["quote"]["time"], "最終幅更新は実保有の最終mark")
        updates += s["sequence"] - 1
        for name in ("latest", "last_observation"):
            observation(s[name], book["session"]["id"], contract, p["side"], update["state"]["last_at"], registry)
        if registry is not None:
            equal(float_values(s["latest"]), live_observation(registry, p["marks"]["last"], p["side"]), "最終markの最新公表/reset")
        if s["latest"] is not None:
            equal(s["latest"], s["last_observation"], "最新と最終公表")
        if s["consumed_publication"] is not None:
            need(s["last_observation"] is not None and s["consumed_publication"] == s["last_observation"]["publication_id"], "消費した公表ID")
        truth(update["condition"])
        if update["used_publication"] is not None:
            need(s["latest"] is not None and update["used_publication"] == s["latest"]["publication_id"], "幅update公表ID")
            equal(update["condition"], condition(s["latest"], policy), "幅update必要三値")
        need(type(s["narrowed"]) is bool, "狭幅型")
        if s["narrowed"]:
            point, o = x["first_narrow"], x["first_narrow_observation"]
            need(point is not None and o is not None and p["atr"] is not None and p["protection_active"], "初狭幅の実mark/ATR/起動")
            checked["timeline"].verify_position_point(pid, point)
            observation(o, book["session"]["id"], contract, p["side"], point["quote"]["time"], registry)
            if registry is not None:
                equal(float_values(o), live_observation(registry, point, p["side"]), "初狭幅時の最新公表/reset")
            equal(x["first_narrow_condition"], condition(o, policy), "初狭幅のC/M(/P)")
            equal(x["first_narrow_condition"], {"known": True, "passed": True}, "未知や否定で狭幅化しない")
            equal((s["narrowed_at"], s["narrowed_by"]), (point["quote"]["time"], o["publication_id"]), "初狭幅時計/根拠")
            need(BASE.point_order(p["activation"]) <= BASE.point_order(point), "起動後の初狭幅")
        else:
            need(all(s[k] is None for k in ("narrowed_at", "narrowed_by")) and x["first_narrow"] is None and x["first_narrow_observation"] is None, "未狭幅nullable")
            equal(x["first_narrow_condition"], {"known": False, "passed": None}, "未狭幅に偽支持なし")
        width = None if p["atr"] is None else max(5.0, 5.0 * math.ceil((1.0 if s["narrowed"] else 2.0) * float(p["atr"]["value"]) / 5.0))
        equal(float(update["width_points"]) if update["width_points"] is not None else None, width if p["protection_active"] else None, "固定1/2ATR選択幅")
        if p["protection_active"]:
            want = 0.0 if width is None else max(0.0, float(p["peak_gain"]) - width)
            need(float(p["floor_gain"]) == want, "狭幅後も非緩和の最終床")
        if p["first_floor_hit"] is not None:
            need(p["protection_active"] and p["first_floor_hit"]["gain_points"] <= p["floor_gain"], "保存床hitの方向と最終非緩和床")
            need(BASE.point_order(p["activation"]) <= BASE.point_order(p["first_floor_hit"]), "起動前に床hitを付けない")
    equal(audit["updates"], updates, "幅更新counterと玉sequence")
    if policy == "W0":
        equal(audit["updates"], 0, "W0に別state更新なし")


def verify_book(book, key, width_audit, early_audit, contract, registry=None, full_clock=False):
    """
    機能: 実Config/Keyを保持して旧所有/会計へ接続し新E/W出典を検査する。
    引数: book(dict)、key(str)、width_audit/early_audit、contract(str)、registry、full_clock(bool)。
    返り値: dictは検算済み共通台帳。E本名をLDへ偽装しない。
    """
    expected = inner_key(key)
    equal(book["key"], expected, "106外policyと金融内Key")
    policy = key.split("_")[0]
    ea = {}
    if policy.startswith("E"):
        equal(set(early_audit), {"policy", "positions"}, "E別audit型")
        equal(early_audit["policy"], policy, "E別audit政策")
        ea = {a["position_id"]: a for a in early_audit["positions"]}
        equal(len(ea), len(early_audit["positions"]), "E audit所有一意")
        equal(list(ea), [p["id"] for p in book["positions"] if p["protection_active"]], "全E起動の専用audit")
    else:
        need(early_audit is None, "W系にE起動auditを追加しない")
    def marks(p, timeline, intrinsic, activation):
        """
        機能: 共通会計の実玉を新起動保存点規範へ渡す。
        引数: p(dict)、timeline、intrinsic/activation(str)は実政策。
        返り値: None。private状態を作らない。
        """
        timeline.session_id = book["session"]["id"]
        verify_marks(p, timeline, intrinsic, activation, ea.get(p["id"]), contract, registry)
    namespace = {**vars(OLD), "config_for": config_for, "GRID_SPACE": GRID_SPACE, "verify_marks": marks}
    checked = types.FunctionType(OLD.verify_book.__code__, namespace, "106実P0共通会計")(book, expected, full_clock)
    verify_width(book, checked, policy, width_audit, early_audit, contract, registry)
    for o in book["orders"]:
        if o["protection_point"] is not None:
            p = checked["positions"][o["position_id"]]
            need(p["protection_active"] and p["first_floor_hit"] is not None and o["protection_point"]["gain_points"] <= p["floor_gain"], "保護返済と実起動/床hit")
            need(BASE.point_order(p["activation"]) <= BASE.point_order(o["protection_point"]), "保護要求は起動以後")
            if policy.startswith("E"):
                equal(o["reason"], policy + "一定利益と収束警戒による名目建値床と非緩和追尾", "E保護返済の専用理由")
    return checked


def inspect_scene(value, registry=None, full_clock=False, artificial=False):
    """
    機能: Core全20口座/別audit/同一grid/旧W0対照の範囲を検査する。
    引数: value(dict)はNative又はGo型Core結果、registry(dict|None)、full_clock/artificial(bool)。
    返り値: dictは外Keyごとの検算台帳。市場再生はしない。
    """
    need(value["version"] == 1 and value["trial"] == 106 and value["complete"] is True, "106完結")
    equal(set(value["books"]), set(KEYS), "20経済口座")
    equal(set(value["width_audits"]), set(KEYS), "幅audit20")
    equal(set(value["early_audits"]), set(E_KEYS), "E audit8だけ")
    need(value["tape_unchanged"] is True and value["source_reexecuted"] is False and value["charts_recomputed"] is False and value["cmp_recomputed"] is True, "Coreの形成責務")
    equal(value["configs"], [{"policy": p, "slip_pts": c, "delay_seconds": d} for p in POLICIES for c in (0, 5) for d in (0, 1)], "20設定順")
    checked, clocks = {}, None
    for key in KEYS:
        book = value["books"][key]
        equal(book["session"], value["session"], "20口座の同一場")
        checked[key] = verify_book(book, key, value["width_audits"][key], value["early_audits"].get(key), value["contract"], registry, full_clock)
        now = [r["at"] for r in book["grid_traces"]]
        if clocks is None:
            clocks = now
        else:
            equal(now, clocks, "20口座の同じ観測grid")
        equal((value["width_audits"][key]["observations"], value["width_audits"][key]["resets"]), (value["width_audits"][KEYS[0]]["observations"], value["width_audits"][KEYS[0]]["resets"]), "全口座の同じ公開/reset配送")
    equal(clocks, value["grid_times"], "実grid列")
    equal(len(clocks), value["counts"]["grids"], "Core実grid数")
    proof = value["w0_control"]
    need(proof["all"] is True and proof["books"] == 4 and proof["excluded"] == [], "W0四冊除外0対照")
    pairs = {"provided_old_book": "old_saved_58", "same_input_old103": "same_input_new12"}
    if artificial:
        need(proof["kind"] == "same_input_old103" and proof["history_class"] == "artificial", "手製旧Actor対照scope")
    else:
        need(proof["kind"] in pairs and proof["history_class"] == pairs[proof["kind"]], "既存58と新12同入力旧Actorの区分")
    if registry is not None:
        first = value["width_audits"][KEYS[0]]
        equal((first["observations"], first["resets"]), (registry.observations, registry.resets), "保存公開配送counter")
        equal(value["counts"], registry.counts, "全保存RecordのCore件数")
        equal({k: v for k, v in value["public_diagnostics"].items() if k != "numeric_seed_carried"}, registry.diagnostics, "一公表単位の役割診断")
    need(type(proof["all_point_comparisons"]) is int and proof["all_point_comparisons"] >= 0, "W0対照数型")
    return checked


def inspect_api(value):
    """
    機能: 停止68011の手製E起動非0型を本名のまま検査する。
    引数: value(dict)はbook/early_audit/width_auditを持つ実Go型。
    返り値: dictは共通会計。公表指紋は手製APIの宣言scope。
    """
    b = value["book"]
    activation = b["config"]["activation_policy"]
    key = f"{activation}_C{b['config']['slip_pts']}_D{b['config']['delay_seconds']}"
    return verify_book(b, key, value["width_audit"], value["early_audit"], value["width_audit"]["contract"])


def validate_completion(condition, complete, manifest, stage, condition_sha):
    """
    機能: 金融成功/同条件2→70/20設定をNativeより前に検査する。
    引数: condition/complete/manifest(dict)、stage/condition_sha(str)はRoot固定metadata。
    返り値: list[dict]は順序付き対象結果。市場本文を開かない。
    """
    need(stage in ("first2", "full70"), "106保存stage")
    n = 2 if stage == "first2" else 70
    need(condition["version"] == 1 and condition["trial"] == 106 and condition["fixed"] is True, "106市場前固定条件")
    equal(condition["core_stop"]["sha256"], CORE_STOP_SHA, "固定Core停止版")
    need(condition["seed_policy"] == "first_cold_then_contract_carry", "cold/carry方針")
    equal(condition["configs"], [{"policy": p, "slip_pts": c, "delay_seconds": d} for p in POLICIES for c in (0, 5) for d in (0, 1)], "Root全20設定")
    ids = [s["id"] for s in manifest["sessions"]]
    need(len(ids) == len(set(ids)) == 70 and ids == sorted(ids), "標準70時系列集合")
    need(complete["version"] == 1 and complete["trial"] == 106 and complete["stage"] == stage and complete["success"] is True and not complete.get("error"), "106金融成功が必要")
    equal(complete["condition_sha256"], condition_sha, "金融同条件")
    equal((complete["sessions"], complete["books_per_scene"], complete["books"]), (n, 20, n * 20), "予定40/1400経済口座")
    need(complete["unchanged"] is True and bool(complete["before"]) and complete["before"] == complete["after"], "金融前後不変")
    need(complete["source_reexecuted"] is False and complete["features_recomputed"] is True and complete["charts_recomputed"] is True and complete["financial_executed"] is True, "Source再形成と外周形成の区分")
    equal(complete["seed_policy"], condition["seed_policy"], "同助走方針")
    tasks = complete["results"]
    equal([t["session"] for t in tasks], ids[:n], "結果場集合/順序")
    for i, row in enumerate(tasks):
        need(row["books"] == 20 and row["w0_control_books"] == 4 and not row.get("error"), "場の20完結/対照4")
        equal(row["control_kind"], "same_input_old103" if 54 <= i < 66 else "provided_old_book", "58/12対照の意味")
        for k in ("native", "sidecar_header", "sidecar_records"):
            ref_shape(row[k])
    if stage == "full70":
        ref_shape(complete["first2"])
    return tasks


def ref_shape(ref):
    """
    機能: FileRefの欠落/空/未知指紋を本文より前に拒否する。
    引数: ref(dict)はpathとsha256。
    返り値: None。相対基準は呼出元が明示する。
    """
    need(set(ref) == {"path", "sha256"} and isinstance(ref["path"], str) and bool(ref["path"].strip()) and sha_valid(ref["sha256"]), "106固定FileRef")


def bind_ref(ref, base, before):
    """
    機能: 明示基準の小metadata又は保存出力だけを指紋へ結ぶ。
    引数: ref(dict)、base(Path)、before(dict)は参照・基準・前指紋。
    返り値: Pathは解決絶対path。Raw/CSV参照には呼ばない。
    """
    ref_shape(ref)
    path = (base / ref["path"]).resolve()
    got = digest(path)
    equal(got, ref["sha256"], "FileRef SHA:" + str(path))
    need(str(path) not in before or before[str(path)] == got, "同path二指紋")
    before[str(path)] = got
    return path


def normalize_scene(scene, base):
    """
    機能: SourceCorpusのFileRefだけを生成外周と同じ絶対表記へ直す。
    引数: scene(dict)、base(Path)は場metadataと台帳parent。
    返り値: dictは独立した値。参照本文を開かない。
    """
    out = copy.deepcopy(scene)
    for name in ("old_clock_tape", "legacy_tape", "symmetric_tape", "w0_native"):
        if name in out:
            ref_shape(out[name]); out[name]["path"] = str((base / out[name]["path"]).resolve())
    for ref in out.get("source_records", {}).values():
        ref_shape(ref); ref["path"] = str((base / ref["path"]).resolve())
    return out


def prepare(fixed_path, fixed_sha, output):
    """
    機能: Root事後固定/金融完了/全コード/標準入力metadataを市場Nativeより前に検査する。
    引数: fixed_path/output(Path)、fixed_sha(str)はRoot固定と新規先。
    返り値: tupleは場task/前指紋/証拠/完了/条件。Raw/CSVを再読しない。
    """
    need(not output.exists() and sha_valid(fixed_sha) and digest(fixed_path) == fixed_sha, "Root保存固定/新規先")
    fixed = load(fixed_path)
    need(fixed["version"] == 1 and fixed["trial"] == 106 and fixed["fixed"] is True, "106保存事後固定")
    before = {str(fixed_path): fixed_sha}
    paths = {k: bind_ref(fixed[k], fixed_path.parent, before) for k in ("condition", "completion", "code")}
    equal(paths["code"], Path(__file__).resolve(), "実保存コードを固定")
    condition, complete = load(paths["condition"]), load(paths["completion"])
    # 未固定又は失敗時には下流Native/sidecarのFileRefを開かない。
    need(condition["version"] == 1 and condition["trial"] == 106 and condition["fixed"] is True and complete["success"] is True, "市場固定/金融成功前の保存拒否")
    before[str(IO_STOP_PATH)] = digest(IO_STOP_PATH)
    equal(before[str(IO_STOP_PATH)], IO_STOP_SHA, "最終I/O停止の由来")
    refs = {k: bind_ref(condition[k], paths["condition"].parent, before) for k in
            ("input_manifest", "source_corpus", "metadata_stop", "sidecar_stop", "core_stop", "source12_completion", "binary")}
    manifest = load(refs["input_manifest"])
    tasks = validate_completion(condition, complete, manifest, fixed["stage"], fixed["condition"]["sha256"])
    for name, want in before.items():
        if name != str(fixed_path) and name != str(paths["completion"]) and name != str(paths["code"]):
            equal(complete["before"].get(name), want, "金融が使用した固定参照")
    for name, want in condition["code_sha256"].items():
        need(sha_valid(want), "条件code指紋")
        p = (ROOT / name).resolve()
        equal(digest(p), want, "市場前固定code")
        equal(complete["before"].get(str(p)), want, "金融使用code")
        before[str(p)] = want
    corpus = load(refs["source_corpus"])
    need(corpus["version"] == 1 and corpus["trial"] == 106 and corpus["fixed"] is True, "Source70固定Corpus")
    scenes = [normalize_scene(s, refs["source_corpus"].parent) for s in corpus["scenes"]]
    equal([s["session"] for s in scenes], [s["id"] for s in manifest["sessions"]], "Source70と入力70")
    data_root = (refs["input_manifest"].parent / manifest["source_root"]).resolve()
    resolved = []
    for i, row in enumerate(tasks):
        m, s = manifest["sessions"][i], scenes[i]
        r = {k: bind_ref(row[k], paths["completion"].parent, before) for k in ("native", "sidecar_header", "sidecar_records")}
        nk = m["files"]["NK225_book"]
        market = (data_root / nk["path"]).resolve()
        equal(complete["before"].get(str(market)), nk["sha256"], "金融使用NKのmetadata指紋")
        # 原板の現物hashは本保存器で再取得せず、Root固定と金融beforeへの結合だけを行う。
        resolved.append({**row, "resolved": r, "input": m, "scene_ref": s, "scene_index": i,
                         "market_path": str(market), "manifest_ref": condition["input_manifest"]})
    if fixed["stage"] == "full70":
        prior_path = bind_ref(complete["first2"], paths["completion"].parent, before)
        prior = load(prior_path)
        validate_completion(condition, prior, manifest, "first2", fixed["condition"]["sha256"])
        for i in range(2):
            for k in ("native", "sidecar_header", "sidecar_records"):
                equal(prior["results"][i][k]["sha256"], tasks[i][k]["sha256"], "同条件先頭2再処理bytes")
    for mod in (PREVIOUS, PREVIOUS.BASE, OLD, GRID, BASE, PUBLIC, PUBLIC.pure):
        p = Path(mod.__file__).resolve()
        before[str(p)] = digest(p)
    proofs = {"Root固定SHA256": fixed_sha, **{k + "SHA256": fixed[k]["sha256"] for k in paths}}
    return resolved, before, proofs, complete, condition


def read_records(path):
    """
    機能: 指紋済み公開sidecarを一巡し、公表/少数mark出典だけに利用する。
    引数: path(Path)は保存records gzip。
    返り値: generator[dict]。Raw/Sourceの再形成や約定再生をしない。
    """
    with gzip.open(path, "rt", encoding="utf-8") as stream:
        for line in stream:
            need(bool(line.strip()), "公開records空行")
            yield json.loads(line, parse_float=Decimal)


def save_viewer(value, output, market_path):
    """
    機能: 実Fillだけを旧Viewer変換へ渡し外20名で保存する。
    引数: value(dict)、output(Path)、market_path(str)はNative/新規先/NK固定原板参照。
    返り値: list[dict]は20形式資源。HTTP検査は行わない。
    """
    resources, sid = [], value["session"]["id"]
    for key in KEYS:
        name = f"106_{key}_{sid}.trades.jsonl"
        with (output / name).open("x", encoding="utf-8", newline="\n") as stream:
            for row in BASE.viewer_trades(value["books"][key]):
                stream.write(json.dumps(row, ensure_ascii=False, default=BASE.serial, allow_nan=False) + "\n")
        resources.append({"id": f"106_{key}_{sid}", "title": f"収束失速と可変保護 {key} {sid}",
                          "symbol": "NK225", "product": "NK225mini", "session": sid, "method_id": key,
                          "point_value": 100, "pnl_format": "trades", "pnl_basis": "net", "pnl_path": name,
                          "market_path": market_path})
    return resources


def aggregate(rows, stage=None):
    """
    機能: 旧会計の実現額/二旗/参加/DDを20本名・日夜・日別で集約する。
    引数: rows(list[dict])、stage(str|None)は場別値と正式予定分母指定。
    返り値: tupleは集計と実現診断。感度を独立標本としない。
    """
    summary, diagnosis = {}, {}
    for key in KEYS:
        selected = [r for r in rows if r["key"] == key]
        need(bool(selected), "全20集計")
        summary[key] = OLD.combine(selected)
        if stage is not None:
            equal(summary[key]["活動主表"]["denom"], 7840 if stage == "full70" else 224, "主70場分母")
            equal(summary[key]["活動副表"]["denom"], 7560 if stage == "full70" else 216, "副70場分母")
        dates = sorted({r["session"][:10] for r in selected})
        diagnosis[key] = {"日夜": {kind: OLD.combine([r for r in selected if r["session"].endswith("_" + kind)]) for kind in ("Day", "Night")},
                          "日別": [{"開始日": d, **OLD.combine([r for r in selected if r["session"].startswith(d)])} for d in dates],
                          "履歴区分": {kind: OLD.combine([r for r in selected if r["history_class"] == kind]) for kind in sorted({r["history_class"] for r in selected})}}
    return summary, diagnosis


def scene_rows(value, checked, history_class="artificial"):
    """
    機能: 既存保存統計と通常/早期/狭幅の別件数を外20本名へまとめる。
    引数: value/checked(dict)はCore結果と検算済み共通台帳、history_class(str)はI/Oの場区分。
    返り値: list[dict]は場別値。費用感度や同Sourceを独立事例にしない。
    """
    need(history_class in ("artificial", "old104_54", "fresh106_12", "saved105_4"), "保存履歴区分")
    rows = []
    for key in KEYS:
        activations = value["early_audits"].get(key, {}).get("positions", [])
        early = sum(a["trigger"] == "early_warning" for a in activations)
        active = sum(p["protection_active"] for p in value["books"][key]["positions"])
        rows.append({"session": value["session"]["id"], "key": key, "width_policy": key.split("_")[0], "history_class": history_class,
                     "normal_ld10_activations": active - early, "early_warning_activations": early,
                     "narrowed_positions": sum(a["state"]["narrowed"] for a in value["width_audits"][key]["positions"]),
                     **OLD.summarize_book(value["books"][key], checked[key])})
    return rows


def generate(fixed_path, fixed_sha, output):
    """
    機能: Root成功後固定した20会計と公開根拠を保存し形式資源を作る。
    引数: fixed_path/output(Path)、fixed_sha(str)は事後固定と新規保存先。
    返り値: dictは完了件数。全quote別engine金融再生/Raw再走査/実Viewerは0。
    """
    tasks, before, proofs, complete, condition_root = prepare(fixed_path, fixed_sha, output)
    rows, resources, refs, controls, comparisons, public_rows = [], [], [], [], {}, []
    output.mkdir(parents=True)
    for task in tasks:
        value, head = load(task["resolved"]["native"]), load(task["resolved"]["sidecar_header"])
        equal(value["session"]["id"], task["session"], "保存Native場")
        equal(value["contract"], task["input"]["contract"], "台帳の実限月コード")
        equal(value["condition_sha256"], complete["condition_sha256"], "Native条件")
        equal((head["version"], head["trial"], head["condition_sha256"], head["records_gzip_sha256"]), (1, 106, complete["condition_sha256"], task["sidecar_records"]["sha256"]), "公開Header固定")
        equal(head["pipeline_provenance"], value["pipeline_provenance"], "Native/Header同じ形成由来")
        p = value["pipeline_provenance"]
        h = head["header"]
        need(h["version"] == 1 and h["success"] is True and h["legacy_all_state_match"] is True and h["force_clock_only"] is True and h["source_reexecuted"] is False and h["financial_executed"] is False and h["market_executed"] is False, "公開producerと金融の責務")
        equal((h["scene"]["id"], h["scene"]["contract"], h["scene"]["start"]), (task["session"], value["contract"], value["session"]["start"]), "公開Headerの場/限月/開始")
        equal(p["scene_input"], task["scene_ref"], "Source時計/対照参照metadata")
        equal(p["raw_input"], task["input"], "使用入力70metadata")
        equal(p["manifest"], task["manifest_ref"], "同標準台帳")
        need(p["first_scene_cold"] is (task["scene_index"] == 0) and p["seed_policy"] == condition_root["seed_policy"] and p["features_recomputed"] is True and p["charts_recomputed"] is True and p["source_reexecuted"] is False, "外周のcold/carry/形成scope")
        registry = registry_from_records(read_records(task["resolved"]["sidecar_records"]), value)
        checked = inspect_scene(value, registry, True)
        equal(value["public_diagnostics"]["numeric_seed_carried"], head["header"]["ending"]["legacy"]["carried_numeric_seed"], "Seed値carryの証跡")
        proof = value["w0_control"]
        equal(proof["all_point_comparisons"], 0, "市場W0は最終四冊対照・全原行別engineではない")
        if task["control_kind"] == "provided_old_book":
            old_ref = task["scene_ref"]["w0_native"]
            old_path = bind_ref(old_ref, ROOT, before)
            old = load(old_path)
            for c in (0, 5):
                for d in (0, 1):
                    key = f"W0_C{c}_D{d}"
                    inner = inner_key(key)
                    old_key = "symmetric_" + inner if task["scene_ref"]["kind"] == "old104_54" else inner
                    equal(value["books"][key], old["books"][old_key], "既存58のW0旧保存最終全JSON除外0")
            equal((proof["reference_path"], proof["reference_sha256"]), (str(old_path), old_ref["sha256"]), "W0実物参照")
        else:
            need(proof["history_class"] == "same_input_new12" and not task["scene_ref"].get("w0_native"), "新12に市場goldenを付けない")
        controls.append({"session": task["session"], **proof, "保存器で旧保存実物全JSONを再照合": task["control_kind"] == "provided_old_book"})
        public_rows.append({"session": task["session"], **value["public_diagnostics"]})
        rows.extend(scene_rows(value, checked, task["scene_ref"]["kind"]))
        for policy in POLICIES[1:]:
            for c in (0, 5):
                for d in (0, 1):
                    a, b = f"W0_C{c}_D{d}", f"{policy}_C{c}_D{d}"
                    comparisons.setdefault(b + "対" + a, []).append({"session": task["session"], **OLD.compare_positions(checked[a], checked[b])})
        resources.extend(save_viewer(value, output, task["market_path"]))
        refs.append({k: task[k] for k in ("session", "native", "sidecar_header", "sidecar_records")})
    summary, diagnosis = aggregate(rows, complete["stage"])
    comparison_totals = {}
    for name, items in comparisons.items():
        total = Counter()
        for item in items:
            total.update({k: v for k, v in item.items() if k != "session"})
        comparison_totals[name] = {"合計": dict(total), "場別": items}
    after = {name: digest(Path(name)) for name in before}
    equal(after, before, "入力/コード前後不変")
    result = {"試行": 106, "成功": True, **proofs, "stage": complete["stage"], "場数": len(tasks), "会計数": len(tasks) * 20,
              "scope": "実P0共通保存会計/部分所有/費用/少数MTM・DDと専用W/E audit、公表C/M/Pの保存出典照合。全quote別engine独立金融再生ではない",
              "主key": list(KEYS), "Actor設定": {k: {"幅政策": k.split("_")[0], "内Key": inner_key(k), "入口": "Gate無しB5Q", "基本保護": "P0",
                                                "起動": k.split("_")[0] if k.startswith("E") else "LD10", "slip_pts": int(k[-4]), "delay_seconds": int(k[-1])} for k in KEYS},
              "集計": summary, "実現診断": diagnosis, "場別": rows, "同実入口と実現額差": comparison_totals, "W0対照": controls, "一公表単位の役割診断": public_rows,
              "既存58と新12": "既存58は旧保存最終4冊全文。新12はCoreの同入力旧103最終4冊対照。新12に過去市場goldenなし",
              "Native参照": refs, "Viewer形式資源": len(resources), "実Viewer通信": 0, "入力codeSHA256前": before, "入力codeSHA256後": after, "前後不変": True,
              "未実施": ["Raw/CSV再読", "Source/チャート指標再形成", "全quote別金融engine", "未参加/退出後仮想利益/機会損失", "実ViewerAPI"]}
    BASE.write_json(output / "結果.json", result)
    BASE.write_json(output / "一覧.resources.json", {"schema_version": 1, "path_base": "catalog", "resources": resources})
    outputs = {p.name: digest(p) for p in output.iterdir() if p.is_file()}
    BASE.write_json(output / "保存会計の確認.json", {"成功": True, **proofs, "会計": len(tasks) * 20, "資源": len(resources), "不一致数": 0,
                    "入力codeSHA256前": before, "入力codeSHA256後": after, "前後不変": True, "出力SHA256": outputs,
                    "scope": result["scope"], "Raw/CSV/Source/金融/HTTP再実行": 0})
    return {"成功": True, "場数": len(tasks), "会計": len(resources), "実Viewer通信": 0}


def main():
    """
    機能: Root成功後の保存固定だけを受けるCLI。
    引数: --fixed/--fixed-sha/--outはRoot事後固定と新規保存先。
    返り値: None。未固定/未成功はNativeより前に拒否する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixed", type=Path, required=True)
    parser.add_argument("--fixed-sha", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(generate(args.fixed.resolve(), args.fixed_sha, args.out), ensure_ascii=False))


if __name__ == "__main__":
    main()
