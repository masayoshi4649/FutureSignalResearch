"""市場未実行の純頻度集計器を人工検査で停止する。"""
from __future__ import annotations

import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

OWN=Path(__file__).resolve().parent
ROOT=OWN.parents[1]


def sha(path: Path) -> str:
    """
    機能: 所有コードと人工確認だけを同定する。
    引数: path (Path) は非市場の明示ファイル。
    返り値: str はSHA256。
    """
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def write_new(path: Path,value: dict) -> None:
    """
    機能: 新規の人工確認又は停止を保存する。
    引数: path (Path)、value (dict) は出力先とJSON。
    返り値: None。停止を上書きしない。
    """
    with path.open('x',encoding='utf-8',newline='\n') as stream:json.dump(value,stream,ensure_ascii=False,indent=2);stream.write('\n')


def main() -> None:
    """
    機能: 手製Reportだけで独立集計を確認しコードを停止する。
    引数: なし。実完成や市場Reportは開かない。
    返り値: None。
    """
    assert not (OWN/'停止.json').exists()
    owned={str((OWN/name).relative_to(ROOT)).replace('\\','/'):sha(OWN/name) for name in ('集計する.py','集計の人工検査.py','検査して停止する.py','README.md','派生元.json')}
    result=subprocess.run([sys.executable,str(OWN/'集計の人工検査.py')],cwd=OWN,capture_output=True,text=True,encoding='utf-8',check=False)
    assert result.returncode==0,result.stderr
    assert owned=={name:sha(ROOT/name) for name in owned}
    write_new(OWN/'人工確認.json',{'成功':True,'exit_code':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'主test':3,'市場本文読込':0,'実Report読込':0})
    write_new(OWN/'停止.json',{'成功':True,'停止':True,'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'所有コードSHA256':owned,'人工確認SHA256':sha(OWN/'人工確認.json'),'自己コード前後不変':True,'主test':3,'範囲':'手製110の70/first2頻度Report、3Route/並列群とL0出生時計の独立集計','市場実行':0,'実Report読込':0,'金融実行':0,'参加率計算':0,'未参加仮想利益計算':0,'未使用11月09本文未読':True,'未実施':['成功全70完成後の実Report独立再読']})
    print(json.dumps({'成功':True,'停止SHA256':sha(OWN/'停止.json'),'主test':3,'実Report読込':0},ensure_ascii=False))


if __name__=='__main__':main()
