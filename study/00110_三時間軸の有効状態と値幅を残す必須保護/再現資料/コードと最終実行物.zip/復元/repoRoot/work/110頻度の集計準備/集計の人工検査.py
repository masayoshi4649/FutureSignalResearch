"""手製の保存Check/予定出生だけで110頻度の独立集計を検査する。"""

from collections import Counter
import copy
import gzip
import json
from pathlib import Path
import tempfile
import unittest

import 集計する as A


def check(value: bool, known: bool = True) -> dict:
    """機能: 数値計算を含まない人工Checkを作る。

    引数: value/known(bool)は保存真偽と既知性。
    返り値: dictは人工Check。
    """
    return {'known': known, 'passed': value, 'reason': '人工並列群'}


def assessment(side: int, at: float, identity: str, snapshot: str, flags: str, conflict: bool = False, unknown: bool = False) -> dict:
    """機能: C/P重複・R・未知・競合を持つ保存候補を手製で作る。

    引数: side/at/identity/snapshot/flagsとbool指定は方向/時計/識別/経路mask。
    返り値: dictは人工候補。EMA等の有効性を示す器具ではない。
    """
    row = {'candidate': {'id': identity, 'side': side, 'at': at, 'entry_quote': 10000 if side > 0 else 9995, 'quantity': 1}, 'snapshot_id': snapshot, 'policy': 'ENTRY_E2'}
    row.update({name: check(False, not unknown) for name in A.GROUPS})
    if not unknown:
        for name in ('common', 'maintenance', 'recovery', 'upper_not_opposite', 'spike', 'continuation_upper', 'trend_momentum', 'reversal_momentum', 'trend_distance', 'reversal_distance'):
            row[name] = check(True)
        for name, flag in (('continuation_direction', 'C'), ('resume_direction', 'P'), ('risk_band', 'P'), ('continuation', 'C'), ('pullback', 'P'), ('reversal_valid', 'R'), ('reversal', 'R')):
            row[name] = check(flag in flags)
        row['trend_valid'] = check('C' in flags or 'P' in flags)
        row['trend'] = check('C' in flags or 'P' in flags)
    route = 'T継続' if 'C' in flags else 'T押戻し再開' if 'P' in flags else 'R局所転換' if 'R' in flags else ''
    status = '未知' if unknown else '競合' if route and conflict else '許可' if route else '待機'
    row.update(known=not unknown, allowed=status == '許可', status=status, role='R' if route == 'R局所転換' else 'T' if route else '', route=route, reason='人工' + status)
    return row


def fixture(index: int, seed=None) -> dict:
    """機能: 重複1・競合1batch・未知・気配不明・未観測出生の場を作る。

    引数: index(int)、seed(dict/None)はmanifest順と前場種。
    返り値: dictは5観測枠の人工Report。利益列や価格本文を持たない。
    """
    kind = 'Day' if index % 2 == 0 else 'Night'
    start = 1800000000 + index * 86400
    end = start + (25200 if kind == 'Day' else 46800)
    sid = f'人工_{index:02d}_{kind}'
    rows, births = [], []
    for i in range(5):
        at, snap = start + 1200 + 300 * i, f'snapshot{i}'
        flags = [('CP', ''), ('', 'R'), ('C', 'R'), ('', ''), ('', '')][i]
        unknown, conflict, quote_known = i == 3, i == 2, i != 4
        decisions = [assessment(side, at, f'tech{side}', snap, f, conflict, unknown) for side, f in zip((1, -1), flags)] if quote_known else []
        empty = {'active': False, 'phase': '', 'expires_at': 0}
        state = {'session_id': sid, 'contract': '人工限月', 'last_five_id': f'foot{i}', 'trend': [copy.deepcopy(empty), copy.deepcopy(empty)], 'reversal': [copy.deepcopy(empty), copy.deepcopy(empty)]}
        for j, f in enumerate(flags):
            if 'C' in f or 'P' in f:
                state['trend'][j] = {'active': True, 'phase': '確認済み', 'expires_at': at + 600}
            if 'R' in f:
                state['reversal'][j] = {'active': True, 'phase': '確認済み', 'expires_at': at + 600}
        side = 1 if i in (0, 2, 4) else -1
        birth = {'id': f'birth{i}', 'method': '人工Source', 'signal_id': f's{i}', 'side': side, 'quantity': 1, 'born_at': at - 20, 'observed_at': at - 10, 'assignment': {'assigned_at': at, 'strict_at': at, 'deferred': False}, 'filled_seen': True, 'cancellation_seen': False, 'due_observed': True}
        births.append(birth)
        chosen_flags = flags[0 if side == 1 else 1]
        source = [assessment(side, at, birth['id'], snap, chosen_flags, False, unknown)] if quote_known else []
        batch = lambda values, conflicted: {'snapshot_id': snap, 'policy': 'ENTRY_E2', 'conflict': conflicted, 'state': copy.deepcopy(state), 'decisions': values}
        rows.append({'at': at, 'primary': True, 'secondary': True, 'quiet': False, 'quote_known': quote_known, 'quote_reason': '人工気配不明' if not quote_known else '人工正常', 'quote': {'quote_ok': True, 'bid': 9995, 'ask': 10000, 'time': at - 1} if quote_known else None, 'snapshot_id': snap, 'state_independent': True, 'technical_batch': batch(decisions, conflict), 'source_planned_batch': batch(source, False), 'due_births': [birth]})
    late = copy.deepcopy(births[0])
    late.update(id='遅い出生', observed_at=rows[0]['at'], due_observed=False)
    future = copy.deepcopy(births[-1])
    future.update(id='予定枠未観測', born_at=start + 2400, observed_at=start + 2400, due_observed=False, assignment={'assigned_at': start + 2700, 'strict_at': start + 2700, 'deferred': False})
    births += [late, future]
    technical = {'candidates': 10, 'known': 6, 'unknown': 4, 'allowed': 2, 'wait': 2, 'conflicts': 2, 'trend_passed': 2, 'reversal_passed': 2, 'reasons': {'人工許可': 2, '人工待機': 2, '人工競合': 2, '人工未知': 2, '人工気配不明': 2}}
    source = {'candidates': 5, 'known': 3, 'unknown': 2, 'allowed': 3, 'wait': 0, 'conflicts': 0, 'trend_passed': 2, 'reversal_passed': 1, 'reasons': {'人工許可': 3, '人工未知': 1, '人工気配不明': 1}}
    report = {'version': 1, 'trial': 110, 'session': {'id': sid, 'start': start, 'end': end, 'eof': start + 2400}, 'config': A.CONFIG, 'grid_rows': rows, 'grids': 5, 'source_births': births, 'technical': technical, 'source_planned': source, 'technical_any_allowed_grids': 2, 'source_any_allowed_grids': 3, 'input_seed': seed, 'end_seed': {'人工末尾': sid}, 'complete': True, 'inputs_unchanged': True, 'state_independent': True, 'policy_eof_redacted': True, 'financial_executed': False, 'participation_calculated': False, 'source_reexecuted': False}
    for prefix, stop in (('primary', end - 600), ('secondary', end - 1800)):
        n = A.planned(start + 1200, stop)
        counts = copy.deepcopy(technical)
        counts['candidates'] += 2 * (n - 5)
        counts['unknown'] += 2 * (n - 5)
        counts['reasons']['EOF等により当枠未観測。未来値を補わない'] = 2 * (n - 5)
        report.update({prefix + '_planned_grids': n, prefix + '_observed_grids': 5, prefix + '_unobserved_grids': n - 5, prefix + '_technical': counts, prefix + '_source_observed': source, prefix + '_technical_allowed_grids': 2, prefix + '_source_allowed_grids': 3})
    return report


class Tests(unittest.TestCase):
    """保存E2論理・固定分母・参照SHAの人工検査。"""

    def test_counts_routes_common_and_source_clock(self):
        """機能: 重複・優先・競合・気配未知・未観測を別に数える。

        引数: self(Tests)は人工検査。
        返り値: None。
        """
        report = fixture(0)
        counts = A.scene_counts(report)
        self.assertEqual(counts['primary']['planned'], 78)
        self.assertEqual(counts['primary']['technical']['candidates'], 156)
        self.assertEqual(counts['primary']['technical']['unknown'], 150)
        buckets = {name: Counter() for name in ('routes', 'groups', 'source')}
        extra = A.diagnostics(report, 0, buckets)['primary']
        self.assertEqual(extra['全買売_競合batch'], 1)
        self.assertEqual(extra['全買売_複数経路成立候補'], 1)
        self.assertEqual(extra['全買売_T継続_代表候補'], 2)
        self.assertEqual(extra['全買売_T押戻し再開_成立候補'], 1)
        self.assertEqual(extra['全買売_T押戻し再開_代表候補'], 0)
        self.assertEqual(extra['全買売_Common既知候補'], 6)
        self.assertEqual(extra['全買売_Common未知候補'], 2)
        self.assertEqual(extra['Source予定L0_未観測割当出生'], 1)
        self.assertEqual(extra['Source予定L0_予定枠で出生未観測'], 1)
        self.assertTrue(any(k[-1] == '共通未知のため未評価' for k in buckets['groups']))

    def test_corrupt_saved_logic_and_future_rejected(self):
        """機能: Common・代表優先・競合・分母・先取りの改変を拒否する。

        引数: self(Tests)は人工検査。
        返り値: None。
        """
        for name in ('common', 'priority', 'and', 'conflict', 'count', 'future', 'bbo', 'activeR'):
            with self.subTest(name=name):
                report = fixture(0)
                v = report['grid_rows'][0]['technical_batch']['decisions'][0]
                if name == 'common':
                    v['common']['known'] = False
                elif name == 'priority':
                    v['route'] = 'T押戻し再開'
                elif name == 'and':
                    v['pullback']['passed'] = False
                elif name == 'conflict':
                    report['grid_rows'][2]['technical_batch']['conflict'] = False
                elif name == 'count':
                    report['primary_technical']['unknown'] += 1
                elif name == 'future':
                    report['grid_rows'][0]['due_births'][0]['observed_at'] = report['grid_rows'][0]['at']
                elif name == 'bbo':
                    v['candidate']['entry_quote'] = 10001
                else:
                    report['grid_rows'][1]['technical_batch']['state']['reversal'][1]['active'] = False
                with self.assertRaises(ValueError):
                    A.scene_counts(report)

    def test_full70_and_first2_gzip_only(self):
        """機能: 手製70Reportを認証し5CSV・主7980副7700とfirst2を検査する。

        引数: self(Tests)はtemp所有者。
        返り値: None。実Report/金融/Rawを開かない。
        """
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            inputs = root / '人工入力'
            inputs.mkdir()
            results, sessions, seed = [], [], None

            def put(path: Path, value: dict) -> dict:
                """機能: 人工JSONを保存してSHAを返す。

                引数: path(Path)、value(dict)は人工metadata。
                返り値: dictは小FileRef。
                """
                path.write_text(json.dumps(value, ensure_ascii=False), encoding='utf-8')
                return {'path': str(path), 'sha256': A.sha(path)}

            for i in range(70):
                report = fixture(i, seed)
                seed = report['end_seed']
                path = inputs / f'{i:05d}.json.gz'
                with gzip.open(path, 'wt', encoding='utf-8') as stream:
                    json.dump(report, stream, ensure_ascii=False)
                item = {key: report[key] for key in ('grids', 'technical', 'source_planned', 'end_seed', 'primary_technical', 'secondary_technical', 'primary_source_observed', 'secondary_source_observed', 'primary_technical_allowed_grids', 'secondary_technical_allowed_grids', 'primary_source_allowed_grids', 'secondary_source_allowed_grids')}
                for prefix in ('primary', 'secondary'):
                    for k in ('planned', 'observed', 'unobserved'):
                        item[prefix + '_' + k + '_grids'] = report[prefix + '_' + k + '_grids']
                item.update(session=report['session']['id'], report={'path': str(path), 'sha256': A.sha(path)})
                results.append(item)
                sessions.append({'id': report['session']['id']})
            manifest = put(inputs / 'manifest.json', {'sessions': sessions})
            tech = put(inputs / '技法.json', {'version': 1, 'trial': 110, 'fixed': True, **A.CONFIG, 'source_manifest': manifest, 'source_corpus': manifest, 'source_completion': manifest})
            completion = {'version': 1, 'trial': 110, 'stage': 'full70', 'success': True, 'unchanged': True, 'before': {'人工非空': 'a' * 64}, 'after': {'人工非空': 'a' * 64}, 'financial_executed': False, 'participation_calculated': False, 'config': A.CONFIG, 'technique_fixed': tech, 'manifest': manifest, 'corpus': manifest, 'source_completion': manifest, 'results': results}
            complete = put(inputs / '完成.json', completion)
            output = root / '集計'
            summary = A.aggregate(complete, tech, output)
            self.assertEqual(summary['totals']['primary']['planned'], 7980)
            self.assertEqual(summary['totals']['secondary']['planned'], 7700)
            self.assertEqual(len(list(output.glob('*.csv'))), 5)
            self.assertFalse(summary['l1_eligibility_calculated'])
            with self.assertRaises(ValueError):
                A.aggregate(complete, tech, output)
            completion['stage'], completion['results'] = 'first2', results[:2]
            first = put(inputs / 'first2完成.json', completion)
            summary = A.aggregate(first, tech, root / '先頭2集計')
            self.assertEqual(summary['totals']['primary']['planned'], 228)
            with self.assertRaises(ValueError):
                A.aggregate({**first, 'sha256': 'b' * 64}, tech, root / '拒否')


if __name__ == '__main__':
    unittest.main(verbosity=2)
