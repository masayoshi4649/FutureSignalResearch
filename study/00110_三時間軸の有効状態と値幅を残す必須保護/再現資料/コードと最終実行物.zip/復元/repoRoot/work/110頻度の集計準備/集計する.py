"""完成後の110純頻度Reportだけを独立再読し、条件とSource時計の重なりを集計する。"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import gzip
import hashlib
import json
import math
from pathlib import Path
import csv

CLOCK = 'csv_end_plus60_at_record_scheduler'
CONFIG = {'clock_model': CLOCK, 'quote_max_age_seconds': 0, 'quiet_seconds': 1200}
GROUPS = ('common', 'continuation_direction', 'resume_direction', 'risk_band', 'trend_valid', 'reversal_valid', 'trend_distance', 'reversal_distance', 'continuation_upper', 'maintenance', 'recovery', 'upper_not_opposite', 'spike', 'trend_momentum', 'reversal_momentum', 'continuation', 'pullback', 'reversal', 'trend')
ROUTES = (('continuation', 'T継続', 'C'), ('pullback', 'T押戻し再開', 'P'), ('reversal', 'R局所転換', 'R'))


def need(condition: bool, reason: str) -> None:
    """
    機能: 保存値と独立集計の不一致を拒否する。
    引数: condition (bool)、reason (str) は条件と根拠。
    返り値: None。不一致ではValueErrorを返す。
    """
    if not condition:
        raise ValueError(reason)


def sha(path: Path) -> str:
    """
    機能: 明示した完成metadata又は場別頻度Reportを同定する。
    引数: path (Path) はCSV/Raw/SourceRecord以外の明示入力。
    返り値: str はSHA256。
    """
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read_ref(ref: dict, proof: dict, compressed: bool = False) -> dict:
    """
    機能: SHA認証したmetadata又は純頻度ReportだけをJSON化する。
    引数: ref/proof (dict)、compressed (bool) は参照・指紋台帳・圧縮指定。
    返り値: dict は保存値。CSV/Raw/SourceRecordはこの関数へ渡さない。
    """
    path = Path(ref['path'])
    need(path.is_absolute(), '絶対参照が必要')
    need(sha(path) == ref['sha256'], '参照SHA差:' + str(path))
    proof[str(path)] = ref['sha256']
    if compressed:
        with gzip.open(path, 'rt', encoding='utf-8-sig') as stream:
            return json.load(stream)
    return json.loads(path.read_text(encoding='utf-8-sig'))


def empty_counts() -> dict:
    """
    機能: Observerと同じ候補計数の空値を返す。
    引数: なし。
    返り値: dict は理由別の独立Counterを持つ。
    """
    return {**{key: 0 for key in ('candidates', 'known', 'unknown', 'allowed', 'wait', 'conflicts', 'trend_passed', 'reversal_passed')}, 'reasons': Counter()}


def add_unknown(counts: dict, number: int, reason: str) -> None:
    """
    機能: 未観測/BBO不明を候補分母へ残す。
    引数: counts (dict)、number (int)、reason (str) は集計先・候補数・理由。
    返り値: None。
    """
    counts['candidates'] += number
    counts['unknown'] += number
    counts['reasons'][reason] += number


def add_batch(counts: dict, batch: dict) -> None:
    """
    機能: 候補ごとに既知/待機/成立/競合とT/Rを数える。
    引数: counts/batch (dict) は集計先と純Batch。
    返り値: None。枚数・利益で重み付けしない。
    """
    for value in batch['decisions']:
        need(value['status'] in ('未知', '待機', '許可', '競合'), '純状態名差')
        need(value['known'] == (value['status'] != '未知'), '既知/状態差')
        need(value['allowed'] == (value['status'] == '許可'), '許可/状態差')
        need(value['policy'] == 'ENTRY_E2' and value['snapshot_id'] == batch['snapshot_id'], '純政策/snapshot差')
        validate_assessment(value, batch)
        counts['candidates'] += 1
        counts['known' if value['known'] else 'unknown'] += 1
        counts['allowed'] += value['allowed']
        counts['wait'] += value['status'] == '待機'
        counts['conflicts'] += value['status'] == '競合'
        counts['reasons'][value['reason']] += 1
        for field in ('trend', 'reversal'):
            check = value[field]
            need(not check['passed'] or check['known'], '未知の経路を成立に補完')
            counts[field + '_passed'] += check['known'] and check['passed']


def any_allowed(batch: dict) -> bool:
    """
    機能: 一方向以上が許可された技術枠だけを数える。
    引数: batch (dict) は純Batch。
    返り値: bool は実際の新規や保有参加を示さない。
    """
    return any(value['allowed'] for value in batch['decisions'])


def planned(start: float, end: float) -> int:
    """
    機能: EOFで切らず既知の場時計から300秒格子数を数える。
    引数: start/end (float) は半開区間の両端。
    返り値: int は計画分母。
    """
    return max(0, math.ceil(end / 300) - math.ceil(start / 300))


def scene_counts(report: dict) -> dict:
    """
    機能: 全gridから主/副/全観測の計数を保存集計と独立に照合する。
    引数: report (dict) は一場の純頻度Report。
    返り値: dict は再集計結果。指標や金融を再形成しない。
    """
    for flag in ('complete', 'inputs_unchanged', 'state_independent', 'policy_eof_redacted'):
        need(report[flag] is True, 'Report成功/不変flag差:' + flag)
    for flag in ('financial_executed', 'participation_calculated', 'source_reexecuted'):
        need(report[flag] is False, 'Reportへ金融/参加率/Source再実行混入')
    need(report['version'] == 1 and report['trial'] == 110 and report['config'] == CONFIG, 'Report版/時計条件差')
    session, rows = report['session'], report['grid_rows']
    start, end, eof = session['start'], session['end'], session['eof']
    force = end - 600
    need(start <= eof <= end, 'Report EOF差')
    output = {prefix: {'technical': empty_counts(), 'source': empty_counts(), 'observed': 0, 'technical_allowed_grids': 0, 'source_allowed_grids': 0} for prefix in ('all', 'primary', 'secondary')}
    output['primary']['planned'] = planned(start + 1200, force)
    output['secondary']['planned'] = planned(start + 1200, end - 1800)
    previous = None
    due_seen = set()
    for row in rows:
        at = row['at']
        need(at % 300 == 0 and start <= at < end and at <= eof and (previous is None or previous < at), 'grid時計/重複/未来差')
        previous = at
        primary, secondary = start + 1200 <= at < force, start + 1200 <= at < end - 1800
        need((row['primary'], row['secondary']) == (primary, secondary), '主副の分母tag差')
        need(row['state_independent'] is True, '候補集合でsetup進行が変化')
        for batch_name in ('technical_batch', 'source_planned_batch'):
            batch = row[batch_name]
            need(batch['snapshot_id'] == row['snapshot_id'] and batch['policy'] == 'ENTRY_E2', 'Batch公開識別差')
            raw_sides = {v['candidate']['side'] for v in batch['decisions'] if any(passed(v, name) for name, _, _ in ROUTES)}
            need(type(batch['conflict']) is bool and batch['conflict'] == (raw_sides == {1, -1}), '候補集合の競合差')
            for v in batch['decisions']:
                need(v['candidate']['at'] == at and v['candidate']['entry_quote'] == row['quote']['ask' if v['candidate']['side'] == 1 else 'bid'], '純候補の判断時計/実BBO差')
        need(row['technical_batch']['state'] == row['source_planned_batch']['state'], '二集合の公開履歴差')
        for birth in row['due_births']:
            need(birth['id'] not in due_seen and birth['born_at'] < at and birth['observed_at'] < at and birth['assignment']['assigned_at'] == at and birth['due_observed'], '予定出生の重複/先取り/割当差')
            due_seen.add(birth['id'])
        if row['quote_known']:
            q = row['quote']
            need(q is not None and q['quote_ok'] and 0 < q['bid'] < q['ask'] and q['time'] <= at, '観測済み正常BBO差')
            need([value['candidate']['side'] for value in row['technical_batch']['decisions']] == [1, -1], '全技術の買売二候補差')
            need([value['candidate']['id'] for value in row['source_planned_batch']['decisions']] == [birth['id'] for birth in row['due_births']], 'Source予定候補の全件結合差')
        else:
            need(not row['technical_batch']['decisions'] and not row['source_planned_batch']['decisions'], 'BBO不明から架空候補')
        for prefix in ['all'] + (['primary'] if primary else []) + (['secondary'] if secondary else []):
            counts = output[prefix]
            counts['observed'] += 1
            if row['quote_known']:
                add_batch(counts['technical'], row['technical_batch'])
                add_batch(counts['source'], row['source_planned_batch'])
            else:
                add_unknown(counts['technical'], 2, row['quote_reason'])
                add_unknown(counts['source'], len(row['due_births']), row['quote_reason'])
            counts['technical_allowed_grids'] += any_allowed(row['technical_batch'])
            counts['source_allowed_grids'] += any_allowed(row['source_planned_batch'])
    for prefix in ('primary', 'secondary'):
        counts = output[prefix]
        counts['unobserved'] = counts['planned'] - counts['observed']
        need(counts['unobserved'] >= 0, '計画より観測枠が多い')
        add_unknown(counts['technical'], 2 * counts['unobserved'], 'EOF等により当枠未観測。未来値を補わない')
        need(counts['planned'] == report[prefix + '_planned_grids'] and counts['observed'] == report[prefix + '_observed_grids'] and counts['unobserved'] == report[prefix + '_unobserved_grids'], '独立主副分母差')
        need(counts['technical'] == report[prefix + '_technical'] and counts['source'] == report[prefix + '_source_observed'], '独立主副候補計数差')
        for kind in ('technical', 'source'):
            need(counts[kind + '_allowed_grids'] == report[prefix + '_' + kind + '_allowed_grids'], '独立主副許可枠差')
    need(len(rows) == report['grids'] and output['all']['technical'] == report['technical'] and output['all']['source'] == report['source_planned'], '独立全観測候補計数差')
    need(output['all']['technical_allowed_grids'] == report['technical_any_allowed_grids'] and output['all']['source_allowed_grids'] == report['source_any_allowed_grids'], '全観測許可枠差')
    need(len({value['id'] for value in report['source_births']}) == len(report['source_births']), '出生ID重複')
    need({value['id'] for value in report['source_births'] if value['due_observed']} == due_seen, '出生と観測済み予定枠の過不足')
    return output


def passed(value: dict, name: str) -> bool:
    """機能: 保存Checkの型と未知/成立整合を検査する。

    引数: value(dict)、name(str)は候補と並列群名。
    返り値: boolは既知の成立だけ。未知を待機へ変換する用途に使わない。
    """
    check = value[name]
    need(type(check['known']) is bool and type(check['passed']) is bool and (not check['passed'] or check['known']), 'Checkの既知/真偽差:' + name)
    return check['known'] and check['passed']


def validate_assessment(value: dict, batch: dict) -> None:
    """機能: E2保存論理の並列群・3経路・優先・競合の解釈を照合する。

    引数: value/batch(dict)は一候補と同一金融前集合。
    返り値: None。指標/市場を再形成せず、保存論理の矛盾を拒否する。
    """
    for name in GROUPS:
        passed(value, name)
    need(value['known'] == value['common']['known'], 'E2のCommonと最終Known差')
    need(value['common']['known'] == value['common']['passed'], 'E2共通可用のKnown/Passed差')
    if not value['known']:
        need(not value['allowed'] and value['status'] == '未知' and not value['route'] and not value['role'], '共通未知から経路成立へ補完')
        return
    need(all(value[name]['known'] for name in GROUPS), '共通可用後の並列Check未知差')
    p = lambda name: passed(value, name)
    need(p('trend_momentum') == (p('maintenance') and p('continuation_upper')), 'T継続勢いの保存論理差')
    need(p('reversal_momentum') == ((p('maintenance') or p('recovery')) and p('upper_not_opposite')), '回復勢いの保存論理差')
    c = p('continuation_direction') and p('trend_valid') and p('trend_momentum') and p('spike') and p('trend_distance')
    resume = p('resume_direction') and p('risk_band') and p('trend_valid') and (p('maintenance') or p('recovery')) and p('upper_not_opposite') and p('spike') and p('trend_distance')
    reversal = p('reversal_valid') and p('reversal_momentum') and p('spike') and p('reversal_distance')
    need([p('continuation'), p('pullback'), p('reversal'), p('trend')] == [c, resume, reversal, c or resume], 'C/P/Rの独立AND/OR差')
    route = 'T継続' if c else 'T押戻し再開' if resume else 'R局所転換' if reversal else ''
    need(value['route'] == route and value['role'] == ('R' if route == 'R局所転換' else 'T' if route else ''), 'E2の代表Route優先/Role差')
    expected = '競合' if route and batch['conflict'] else '許可' if route else '待機'
    need(value['status'] == expected and value['allowed'] == (expected == '許可'), '競合と代表Routeの保存差')
    i = 0 if value['candidate']['side'] == 1 else 1
    for check, state_name in (('trend_valid', 'trend'), ('reversal_valid', 'reversal')):
        setup = batch['state'][state_name][i]
        active = setup['active'] and setup['phase'] == '確認済み'
        need(p(check) == active, '現在支持のActive/確認済み差')
        if active:
            need(value['candidate']['at'] < setup['expires_at'], '確認支持が期限後に有効')


def route_mask(value: dict) -> str:
    """機能: 代表優先で隠れないC/P/Rの同時成立を識別する。

    引数: value(dict)は候補。
    返り値: strは未評価・なし・C/P/Rの結合。各経路の票数ではない。
    """
    if not value['common']['known']:
        return '共通未知'
    return '+'.join(symbol for name, _, symbol in ROUTES if passed(value, name)) or 'なし'


def scopes(ordinal: int, sid: str) -> tuple[str, str, str]:
    """機能: 結果を見ず固定した日夜/14場ごとの5期を返す。

    引数: ordinal(int)、sid(str)はmanifest順と場識別。
    返り値: tuple[str,str,str]は全体・日夜・固定期間。
    """
    return '全体', sid.rsplit('_', 1)[-1], f'第{ordinal // 14 + 1}期'


def group_state(value: dict, name: str) -> str:
    """機能: Common自身の未知と、後続群の未評価を区別する。

    引数: value(dict)、name(str)は候補と並列群。
    返り値: strは未評価/未知/不成立/成立。
    """
    if name != 'common' and not value['common']['known']:
        return '共通未知のため未評価'
    check = value[name]
    return '未知' if not check['known'] else '成立' if check['passed'] else '不成立'


def diagnostics(report: dict, ordinal: int, buckets: dict) -> dict:
    """機能: 保存3経路/並列群/Source L0時計を要約する。

    引数: report/buckets(dict)、ordinal(int)は場別値・集計先・固定場順。
    返り値: dictは主副の追加計数。L1適格性や参加率を計算しない。
    """
    sid = report['session']['id']
    split = scopes(ordinal, sid)
    output = {area: Counter() for area in ('primary', 'secondary')}
    for area in output:
        for label in ('全買売', 'Source予定L0'):
            for suffix in ('競合batch', '気配不明候補', 'Common既知候補', 'Common未知候補', '複数経路成立候補'):
                output[area][label + '_' + suffix] = 0
            for _, route, _ in ROUTES:
                for suffix in ('成立候補', '代表候補', '許可候補'):
                    output[area][label + '_' + route + '_' + suffix] = 0
        output[area]['Source予定L0_未観測割当出生'] = 0
        output[area]['Source予定L0_予定枠で出生未観測'] = 0
        output[area]['静観中観測枠'] = 0
    observed = {row['at'] for row in report['grid_rows']}
    for row in report['grid_rows']:
        for area in (['primary'] if row['primary'] else []) + (['secondary'] if row['secondary'] else []):
            output[area]['静観中観測枠'] += bool(row.get('quiet', False))
            for key, label in (('technical_batch', '全買売'), ('source_planned_batch', 'Source予定L0')):
                batch = row[key]
                raw_sides = {v['candidate']['side'] for v in batch['decisions'] if any(passed(v, name) for name, _, _ in ROUTES)}
                need(batch['conflict'] == (raw_sides == {1, -1}), '候補集合内の両方向競合flag差')
                output[area][label + '_競合batch'] += batch['conflict']
                output[area][label + '_気配不明候補'] += (2 if label == '全買売' else len(row['due_births'])) if not row['quote_known'] else 0
                for v in batch['decisions']:
                    mask = route_mask(v)
                    output[area][label + '_Common既知候補'] += v['common']['known']
                    output[area][label + '_Common未知候補'] += not v['common']['known']
                    output[area][label + '_複数経路成立候補'] += '+' in mask
                    for name, route, _ in ROUTES:
                        output[area][label + '_' + route + '_成立候補'] += passed(v, name)
                        output[area][label + '_' + route + '_代表候補'] += v['route'] == route
                        output[area][label + '_' + route + '_許可候補'] += v['allowed'] and v['route'] == route
                    for scope in split:
                        buckets['routes'][(scope, area, label, v['status'], mask, v['route'])] += 1
                        for name in GROUPS:
                            buckets['groups'][(scope, area, label, name, group_state(v, name))] += 1
            technical = {v['candidate']['side']: v for v in row['technical_batch']['decisions']}
            source = {v['candidate']['id']: v for v in row['source_planned_batch']['decisions']}
            for birth in row['due_births']:
                t, s = technical.get(birth['side']), source.get(birth['id'])
                age = row['at'] - birth['born_at']
                age_label = '60秒以下' if age <= 60 else '60秒超300秒以下' if age <= 300 else '300秒超'
                for scope in split:
                    buckets['source'][(scope, area, birth['method'], '予定枠を観測', age_label, birth['assignment']['deferred'], t['status'] if t else '気配不明', t['route'] if t else '', s['status'] if s else '気配不明', s['route'] if s else '', birth['filled_seen'], birth['cancellation_seen'])] += 1
    for birth in report['source_births']:
        at = birth['assignment']['assigned_at']
        if birth['due_observed']:
            continue
        age = at - birth['born_at']
        age_label = '60秒以下' if age <= 60 else '60秒超300秒以下' if age <= 300 else '300秒超'
        for area, end in (('primary', report['session']['end'] - 600), ('secondary', report['session']['end'] - 1800)):
            if report['session']['start'] + 1200 <= at < end:
                observed_but_late = at in observed
                if observed_but_late:
                    need(birth['observed_at'] >= at, '観測済み予定枠の出生未結合理由が不明')
                name = 'Source予定L0_予定枠で出生未観測' if observed_but_late else 'Source予定L0_未観測割当出生'
                output[area][name] += 1
                for scope in split:
                    tag = '枠観測時に出生未観測' if observed_but_late else '予定枠未観測'
                    buckets['source'][(scope, area, birth['method'], tag, age_label, birth['assignment']['deferred'], '当時未結合', '', '当時未結合', '', '', '')] += 1
    return output


def write_csv(path: Path, header: list[str], rows: list[list]) -> None:
    """機能: 小型研究集計を新規CSVへ保存する。

    引数: path(Path)、header/rows(list)は新規先と列/行。
    返り値: None。損益・機会損失列を持たない。
    """
    with path.open('x', encoding='utf-8', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(header)
        writer.writerows(rows)


def aggregate(completion_ref: dict, technique_ref: dict, output: Path) -> dict:
    """機能: 明示成功first2/full70だけを認証し独立頻度を保存する。

    引数: completion_ref/technique_ref(dict)、output(Path)は期待SHAと未作成先。
    返り値: dictは場/区分/経路/並列群/Source時計の集計。市場再走・金融は行わない。
    """
    output = output.resolve()
    need(not output.exists(), '集計outは未作成folderが必要')
    proof = {}
    completion, technique = read_ref(completion_ref, proof), read_ref(technique_ref, proof)
    stage = completion['stage']
    need(stage in ('first2', 'full70') and completion['success'] and completion['version'] == 1 and completion['trial'] == 110 and completion['config'] == CONFIG, '成功した110同条件完成が必要')
    need(completion['unchanged'] and completion['before'] and completion['before'] == completion['after'] and not completion['financial_executed'] and not completion['participation_calculated'], '純頻度の責務/入力不変差')
    need(completion['technique_fixed'] == technique_ref and technique['fixed'] and technique['version'] == 1 and technique['trial'] == 110, '110技法固定との結合差')
    need({key: technique[key] for key in CONFIG} == CONFIG, '技法時計条件差')
    need(completion['manifest'] == technique['source_manifest'] and completion['corpus'] == technique['source_corpus'] and completion['source_completion'] == technique['source_completion'], '固定Source三参照差')
    manifest = read_ref(technique['source_manifest'], proof)
    count = 2 if stage == 'first2' else 70
    need(len(manifest['sessions']) == 70 and len(completion['results']) == count, '明示段階の場数差')
    totals = {prefix: Counter() for prefix in ('primary', 'secondary')}
    split_counts = defaultdict(Counter)
    buckets = {key: Counter() for key in ('routes', 'groups', 'source')}
    scenes, previous_seed = [], None
    for ordinal, (scene, item) in enumerate(zip(manifest['sessions'][:count], completion['results'])):
        need(item['session'] == scene['id'], 'manifest順と完成の場順差')
        path = Path(item['report']['path'])
        need(path.resolve().parent == Path(completion_ref['path']).resolve().parent and path.name.endswith('.json.gz'), 'Report参照範囲差')
        report = read_ref(item['report'], proof, True)
        need(report['session']['id'] == scene['id'] and report['input_seed'] == previous_seed, 'Report場/数値種連鎖差')
        previous_seed = report['end_seed']
        need(item['end_seed'] == previous_seed, '完成と末尾種差')
        for field in ('grids', 'technical', 'source_planned', 'primary_technical', 'secondary_technical', 'primary_source_observed', 'secondary_source_observed', 'primary_technical_allowed_grids', 'secondary_technical_allowed_grids', 'primary_source_allowed_grids', 'secondary_source_allowed_grids'):
            need(item[field] == report[field], '完成/Report保存計数差:' + field)
        calculated = scene_counts(report)
        extra = diagnostics(report, ordinal, buckets)
        for area in ('primary', 'secondary'):
            values = calculated[area]
            fields = {k: values[k] for k in ('planned', 'observed', 'unobserved', 'technical_allowed_grids', 'source_allowed_grids')}
            for collection in ('technical', 'source'):
                fields.update({collection + '_' + k: v for k, v in values[collection].items() if k != 'reasons'})
            fields.update(extra[area])
            for k in ('planned', 'observed', 'unobserved'):
                need(values[k] == item[area + '_' + k + '_grids'], '完成の主副分母差')
            row = {'session': scene['id'], 'kind': scene['id'].rsplit('_', 1)[-1], 'period': scopes(ordinal, scene['id'])[2], 'area': area, **fields}
            scenes.append(row)
            totals[area].update(fields)
            for scope in scopes(ordinal, scene['id']):
                split_counts[(area, scope)].update(fields)
    primary, secondary = (228, 220) if stage == 'first2' else (7980, 7700)
    need(totals['primary']['planned'] == primary and totals['secondary']['planned'] == secondary, '段階ごとの主副予定分母差')
    need(totals['primary']['technical_candidates'] == 2 * primary and totals['secondary']['technical_candidates'] == 2 * secondary, '買売候補分母とgrid分母差')
    for path, expected in proof.items():
        need(sha(Path(path)) == expected, '集計中の入力変更:' + path)
    output.mkdir(parents=True)
    numeric_fields = sorted(set().union(*(set(row) - {'session', 'kind', 'period', 'area'} for row in scenes)))
    write_csv(output / '場別の主副頻度.csv', ['session', 'kind', 'period', 'area'] + numeric_fields, [[row.get(k, 0) for k in ['session', 'kind', 'period', 'area'] + numeric_fields] for row in scenes])
    write_csv(output / '日夜と固定期の頻度.csv', ['area', '区分'] + numeric_fields, [[area, scope] + [values[k] for k in numeric_fields] for (area, scope), values in sorted(split_counts.items())])
    headers = {'routes': ['区分', '分母', '候補集合', '最終状態', '成立mask', '代表Route'], 'groups': ['区分', '分母', '候補集合', '並列論理群', '状態'], 'source': ['区分', '分母', 'Source手法', '割当観測', '出生から割当秒', 'quiet繰越', '全買売の状態', '全買売のRoute', 'Source予定集合の状態', 'Source予定集合のRoute', '当時fill既観測', '当時取消既観測']}
    names = {'routes': '三経路の優先と重なり.csv', 'groups': '並列条件群の頻度.csv', 'source': 'Source予定L0と技術状態.csv'}
    for key in buckets:
        write_csv(output / names[key], headers[key] + ['候補数'], [list(k) + [v] for k, v in sorted(buckets[key].items(), key=lambda x: tuple(str(y) for y in x[0]))])
    result = {'成功': True, 'stage': stage, 'sessions': count, 'scope': '保存済みE2純頻度の独立再読。金融/参加率/L1適格性/仮想利益は計算しない', 'completion': completion_ref, 'technique_fixed': technique_ref, 'totals': totals, 'inputs_sha256': proof, 'unchanged': True, 'route_symbols': {'C': 'T継続', 'P': 'T押戻し再開', 'R': 'R局所転換'}, 'definitions': {'優先': 'C→P→R。maskの重複は経路成立候補、代表は候補1件、許可は競合後', '競合': 'batch数と候補数を別集計。全買売集合とSource予定集合でも別', 'Known': '明示E2候補ではCommon.Known=最終Knownを検査。BBO不明/未観測を候補Unknownへ別加算', 'Source': '出生済みL0の予定割当だけ。金融適格前、L1の後続受付・保有参加ではない', '未観測Source': '既に保存された出生の未観測予定枠を別記。Source observed候補計数へ勝手に加えない', '理由': '短絡Reasonを唯一原因/単独効果としない。保存された並列Checkを数える', '分母': '主は開始20分後〜末尾10分前、副は末尾30分前。未知/未観測を分母から除かない', '指標': '保存Check/Stateの整合確認まで。EMA等の実数値や公表器を再形成しない'}, 'financial_executed': False, 'participation_calculated': False, 'l1_eligibility_calculated': False, 'opportunity_pnl_calculated': False, 'holdout_11_09_read': False}
    with (output / '独立集計.json').open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    text = f"# 110純頻度の独立集計\n\n{stage}・{count}場。主{primary:,}枠（買売{2*primary:,}候補）、副{secondary:,}枠。\n\n主の技術許可{totals['primary']['technical_allowed_grids']:,}枠、Source予定L0許可{totals['primary']['source_allowed_grids']:,}枠。技術候補Known {totals['primary']['technical_known']:,}、Unknown {totals['primary']['technical_unknown']:,}。未観測{totals['primary']['unobserved']:,}枠を分母へ保持。\n\nC/P/Rの同時成立と代表優先、候補競合とbatch競合はCSVの別列。並列条件の不成立件数は単独の因果効果ではない。Source予定L0は金融適格性、L1受付、実参加率ではない。金融/損益/未参加仮想利益/11月09日を計算・読取しない。\n"
    (output / '要点.md').write_text(text, encoding='utf-8')
    return result


def main() -> None:
    """機能: Rootの完成SHA明示後だけfirst2/full70の頻度Reportを再読する。

    引数: --completion/sha256 --technique-fixed/sha256 --outは期待Refと新規先。
    返り値: None。Observerや市場exeを起動しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('completion', 'completion-sha256', 'technique-fixed', 'technique-sha256', 'out'):
        parser.add_argument('--' + name, required=True)
    args = parser.parse_args()
    result = aggregate({'path': args.completion, 'sha256': args.completion_sha256}, {'path': args.technique_fixed, 'sha256': args.technique_sha256}, Path(args.out))
    print(json.dumps({'成功': True, 'stage': result['stage'], '場数': result['sessions'], '主': result['totals']['primary'], '副': result['totals']['secondary']}, ensure_ascii=False))


if __name__ == '__main__':
    main()

