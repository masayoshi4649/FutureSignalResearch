"""金融なしObserverの人工・I/O・metadata検査を固定して停止する。"""
from __future__ import annotations

import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
CORE = ROOT / 'work/三時間軸の市場接続準備'
CORE_STOP = '62934599463b34def929302c810bd7da2f8abeccdbfa28dce0ade82518633d73'


def sha(path: Path) -> str:
    """
    機能: 明示したcode・停止・人工ファイルを同定する。
    引数: path (Path) は非市場の参照。
    返り値: str はSHA256。市場ディレクトリを列挙しない。
    """
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def write_new(path: Path, value: dict) -> None:
    """
    機能: 新しい確認・由来・停止を上書きなしで保存する。
    引数: path (Path)、value (dict) は出力先とJSON値。
    返り値: None。既存停止には書かない。
    """
    path.parent.mkdir(exist_ok=True, parents=True)
    with path.open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write('\n')


def run(argv: list[str]) -> dict:
    """
    機能: 非市場のGo人工又はビルドを実行する。
    引数: argv (list[str]) は固定したGo命令。
    返り値: dict は終了codeと出力。失敗を補完しない。
    """
    result = subprocess.run(argv, cwd=OWN, capture_output=True, text=True, encoding='utf-8', check=False)
    value = {'argv': argv, 'cwd': str(OWN), 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    assert result.returncode == 0, value
    return value


def protected() -> dict[str, str]:
    """
    機能: 停止Coreの非市場指紋収集器を確認してからObserverへ適用する。
    引数: なし。金融Coreのmainや検査は実行しない。
    返り値: dict[str,str] は停止・所有code・Go実選択code・人工入力の指紋。
    """
    assert sha(CORE / '停止.json') == CORE_STOP
    stopped = json.loads((CORE / '停止.json').read_text(encoding='utf-8'))
    helper = CORE / '検査と停止を記録する.py'
    assert sha(helper) == stopped['所有コードSHA256'][helper.relative_to(ROOT).as_posix()]
    spec = importlib.util.spec_from_file_location('停止Coreの指紋収集', helper)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.OWN = OWN
    module.STOPS = {
        **module.STOPS,
        'work/三時間軸の市場接続準備/停止.json': CORE_STOP,
        'work/三時間軸の市場入力口/停止.json': '820a819d284a58c5057150bb415ac3fd57c34473abda4b18467c42dba9e95782',
        'work/107保存公表の再読口_埋込対応/停止.json': 'd47881a6381e88e0ef2121830c5015e9bbfaa580ed7aa865bd2c12aca767e892',
        'work/109入口の頻度前検査/停止.json': '5939b05e58cd4925f96b86db07b3ead1549fd131f5c2718b8212462062f27b0f',
    }
    values = module.protected()
    for path in sorted((OWN / '人工Reader').rglob('*')):
        if path.is_file():
            values[path.relative_to(ROOT).as_posix()] = sha(path)
    for side in (1, -1):
        path = CORE / '人工_停止版' / f'方向{side}_fresh.json'
        values[path.relative_to(ROOT).as_posix()] = sha(path)
    return values


def main() -> None:
    """
    機能: Observer人工・Reader接続・metadata認証を確認し、exeと停止を固定する。
    引数: なし。市場CLIは起動せず、実70/11月09本文は読まない。
    返り値: None。新停止と確認JSONを保存する。
    """
    assert not (OWN / '停止.json').exists()
    before = protected()
    parent = ROOT / 'work/109入口の頻度前検査'
    for name in ('observer.go', 'observer_test.go', 'fixture_test.go', 'go.mod', 'go.sum'):
        assert sha(OWN / name) == sha(parent / name), name
    own_paths = [OWN / name for name in ('observer.go', 'observer_test.go', 'fixture_test.go', 'cmd/observe/main.go', 'cmd/observe/main_test.go', 'go.mod', 'go.sum', 'README.md', '条件の雛形.json', '検査と停止を記録する.py')]
    owned = {path.relative_to(ROOT).as_posix(): sha(path) for path in own_paths}
    binary = OWN / '検査/109頻度前検査.exe'
    assert not binary.exists()
    binary.parent.mkdir(exist_ok=True)
    checks = [run(['go', 'test', '-json', '-count=1', '-cover', './...']), run(['go', 'vet', './...']), run(['go', 'build', '-o', str(binary), './cmd/observe'])]
    actions = [json.loads(line) for line in checks[0]['stdout'].splitlines() if line.strip()]
    assert not any(item['Action'] == 'fail' for item in actions)
    passed = [item for item in actions if item['Action'] == 'pass' and 'Test' in item]
    coverage = [item['Output'].strip() for item in actions if 'Output' in item and 'coverage:' in item['Output']]
    after = {name: sha(ROOT / name) for name in before}
    assert before == after
    assert owned == {name: sha(ROOT / name) for name in owned}
    main_tests = sum('/' not in item['Test'] for item in passed)
    write_new(OWN / '検査/Go確認.json', {'成功': True, 'checks': checks, '主test': main_tests, '全test': len(passed), 'coverage': coverage, '市場実行': 0})
    write_new(OWN / '由来.json', {'成功': True, '非市場指紋収集の元': str(CORE / '検査と停止を記録する.py'), '元Core停止SHA256': CORE_STOP, '前SHA256': before, '後SHA256': after, '全不変': True, 'Reader人工': '停止ReaderのTestExportReaderFixtureを新workへ出力。単場I/O用のEOF明示はtempコピーだけ', '市場本文読込': 0, '金融実行': 0})
    owned[(OWN / '由来.json').relative_to(ROOT).as_posix()] = sha(OWN / '由来.json')
    artificial = {name: value for name, value in before.items() if name.startswith(OWN.relative_to(ROOT).as_posix() + '/人工Reader/') or name.startswith('work/三時間軸の市場接続準備/人工_停止版/方向')}
    stopped = {
        '成功': True, '停止': True, 'UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'module': 'github.com/masayoshi4649/SessionTradeExecuter/threeentryfrequency109',
        '所有コードSHA256': owned, 'Go確認SHA256': sha(OWN / '検査/Go確認.json'),
        '主test': main_tests, '全test': len(passed), 'coverage': coverage, 'vet_exit': 0, 'build_exit': 0,
        '実行物': str(binary), '実行物SHA256': sha(binary), '依存指紋件数': len(before), '依存前後不変': True,
        '人工入力SHA256': artificial, '金融Actor呼出': 0, '市場金融実行': 0, '実70本文読込': 0, '未使用11月09本文未読': True,
        '派生元停止SHA256': '5939b05e58cd4925f96b86db07b3ead1549fd131f5c2718b8212462062f27b0f',
        '参照正規化だけの派生': True, '三技法と分母と時計の実装同体': True,
        '主分母': '[Start+1200,ForceClose)の300秒格子。USquietとEOF未観測も残す',
        '副分母': '[Start+1200,End-1800)の300秒格子。EOF未観測も残す',
        '主BBO': '最新正Last Scalar、normal BBO、q.Time<=grid。年齢/Received/resetは追加除外にしない',
        '時計': 'csv_end_plus60_at_record_scheduler',
        '非干渉': '各gridの買売技法候補・Source予定候補・空候補でnextState全同体を実行時にも検査',
        '範囲': '技術成立頻度とSource予定枠の重なり。金融適格性・参加率・損益を算出しない',
        '未実施': ['固定技法/条件からの実first2/全70頻度', '金融参加率と損益', '未使用11/09保留確認', '採用判断'],
    }
    write_new(OWN / '停止.json', stopped)
    print(json.dumps({'成功': True, '停止SHA256': sha(OWN / '停止.json'), 'exe': str(binary), 'exeSHA256': sha(binary), '主test': main_tests, '全test': len(passed), 'coverage': coverage, '依存指紋': len(before)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
