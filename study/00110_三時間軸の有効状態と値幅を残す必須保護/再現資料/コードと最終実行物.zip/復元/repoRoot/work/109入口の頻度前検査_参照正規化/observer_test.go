package threeentryfrequency109

import (
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
)

type fixture struct {
	Tape    tape.Tape       `json:"tape"`
	Header  stream.Header   `json:"header"`
	Records []stream.Record `json:"records"`
}

// loadFixture は停止Coreの手製Sourceを持つ買売人工だけを読みます。
//
// 引数: t(*testing.T)、side(int)は検査器と鏡像方向です。
// 返り値: fixture/PublicationInputは人工Source/Recordと実publisher由来の数値種です。
func loadFixture(t *testing.T, side int) (fixture, PublicationInput) {
	t.Helper()
	raw, e := os.ReadFile(filepath.Join("..", "三時間軸の市場接続準備", "人工_停止版", fmt.Sprintf("方向%d_fresh.json", side)))
	if e != nil {
		t.Fatal(e)
	}
	var f fixture
	if e = json.Unmarshal(raw, &f); e != nil {
		t.Fatal(e)
	}
	return f, publisherInput(t, side)
}

// executeFixture は市場I/Oも金融も使わず全人工Recordを配送します。
//
// 引数: t(*testing.T)、f(fixture)、pub(PublicationInput)は検査器と人工入力です。
// 返り値: Reportは完結した頻度です。
func executeFixture(t *testing.T, f fixture, pub PublicationInput) Report {
	t.Helper()
	o, e := NewObserver(f.Tape, pub, DefaultConfig())
	if e != nil {
		t.Fatal(e)
	}
	if _, e = o.NextSeed(); e == nil {
		t.Fatal("完結前種が露出")
	}
	for _, r := range f.Records {
		if e = o.Feed(r); e != nil {
			t.Fatal(e)
		}
	}
	out, e := o.Finish(f.Header)
	if e != nil {
		t.Fatal(e)
	}
	seed, e := o.NextSeed()
	if e != nil || seed.Info() != out.EndSeed {
		t.Fatal("種返却差", e)
	}
	if _, e = o.Finish(f.Header); e == nil {
		t.Fatal("二重完結")
	}
	return out
}

// TestPureFrequencyAndSourceJoin は実公開器と純Entryの非ゼロ成立とSource予定枠を確認します。
//
// 引数: t(*testing.T)は買売の人工検査器です。
// 返り値: ありません。金融や実参加率を成立頻度へ混ぜません。
func TestPureFrequencyAndSourceJoin(t *testing.T) {
	for _, side := range []int{1, -1} {
		t.Run(fmt.Sprint(side), func(t *testing.T) {
			f, pub := loadFixture(t, side)
			out := executeFixture(t, f, pub)
			if !out.Complete || !out.InputsUnchanged || !out.StateIndependent || out.FinancialExecuted || out.ParticipationCalculated || out.SourceReexecuted || out.Technical.Candidates != 2*out.Grids || out.SourcePlanned.Candidates == 0 || out.SourcePlanned.Allowed == 0 || out.Technical.Allowed == 0 {
				t.Fatalf("純頻度非ゼロ/会計混入差:%+v", out.Technical)
			}
			found := false
			for _, row := range out.GridRows {
				if row.At == pub.Session.Start+3000 {
					found = true
					if len(row.Due) != 1 || row.Due[0].Side != side || !row.Source.Decisions[0].Allowed || !row.StateIndependent || row.Quote == nil {
						t.Fatalf("50分の予定join差:%+v", row)
					}
				}
			}
			if !found {
				t.Fatal("取得枠なし")
			}
			for _, b := range out.SourceBirths {
				if !b.DueObserved || b.ObservedAt >= b.Assignment.AssignedAt || b.BornAt >= b.Assignment.StrictAt {
					t.Fatal("未来出生join")
				}
			}
			t.Logf("side%d: grids%d technicalAllowed%d sourceAllowed%d Unknown%d", side, out.Grids, out.Technical.Allowed, out.SourcePlanned.Allowed, out.Technical.Unknown)
		})
	}
}

// TestQuoteUnknownAgeAndState は正常BBOの未知と年齢診断、候補非干渉を検査します。
//
// 引数: t(*testing.T)は人工状態の検査器です。
// 返り値: ありません。90秒超を主成立から除外しません。
func TestQuoteUnknownAgeAndState(t *testing.T) {
	f, pub := loadFixture(t, 1)
	o, e := NewObserver(f.Tape, pub, DefaultConfig())
	if e != nil {
		t.Fatal(e)
	}
	at := pub.Session.Start + 3000
	cases := []struct {
		name  string
		q     *tape.ScalarQuote
		known bool
	}{{"未観測", nil, false}, {"正常", &tape.ScalarQuote{Time: at - 1, Received: at - 1, Bid: 10480, Ask: 10490, QuoteOK: true}, true}, {"年齢90超", &tape.ScalarQuote{Time: at - 180, Received: at - 180, Bid: 10480, Ask: 10490, QuoteOK: true}, true}, {"未来時計", &tape.ScalarQuote{Time: at + 1, Received: at, Bid: 10480, Ask: 10490, QuoteOK: true}, false}, {"未来受信は診断", &tape.ScalarQuote{Time: at - 1, Received: at + 1, Bid: 10480, Ask: 10490, QuoteOK: true}, true}, {"不良", &tape.ScalarQuote{Time: at - 1, Received: at - 1, Bid: 10480, Ask: 10490, QuoteOK: false}, false}, {"逆転", &tape.ScalarQuote{Time: at - 1, Received: at - 1, Bid: 10490, Ask: 10480, QuoteOK: true}, false}}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			o.quote = c.q
			known, _, age := o.quoteAt(at)
			if known != c.known || known && age == nil {
				t.Fatal("BBO既知差")
			}
		})
	}
	o.quote = nil
	for _, r := range f.Records {
		if r.At > at {
			break
		}
		if e = o.Feed(r); e != nil {
			t.Fatal(e)
		}
	}
	before := o.state
	o.quote = nil
	if e = o.grid(at); e != nil {
		t.Fatal(e)
	}
	row := o.report.GridRows[len(o.report.GridRows)-1]
	if row.QuoteKnown || !reflect.DeepEqual(before, o.state) || o.report.Technical.Unknown < 2 {
		t.Fatal("BBO未知が分母/stateを破壊")
	}
}

// TestBoundaries はmetadata/順序/未来出生/入力変更の不成立を確認します。
//
// 引数: t(*testing.T)は人工破損の検査器です。
// 返り値: ありません。
func TestBoundaries(t *testing.T) {
	t.Run("設定", func(t *testing.T) {
		f, p := loadFixture(t, 1)
		c := DefaultConfig()
		c.QuoteMaxAgeSeconds = 90
		if _, e := NewObserver(f.Tape, p, c); e == nil {
			t.Fatal("主条件に90秒が混入")
		}
	})
	t.Run("順序", func(t *testing.T) {
		f, p := loadFixture(t, 1)
		o, _ := NewObserver(f.Tape, p, DefaultConfig())
		r := f.Records[0]
		r.Ordinal++
		if e := o.Feed(r); e == nil {
			t.Fatal("ordinal差を許可")
		}
		if e := o.Feed(f.Records[0]); e == nil {
			t.Fatal("失敗後継続")
		}
	})
	t.Run("Header", func(t *testing.T) {
		f, p := loadFixture(t, 1)
		o, _ := NewObserver(f.Tape, p, DefaultConfig())
		for _, r := range f.Records {
			if e := o.Feed(r); e != nil {
				t.Fatal(e)
			}
		}
		f.Header.Records++
		if _, e := o.Finish(f.Header); e == nil {
			t.Fatal("Header差を許可")
		}
	})
	t.Run("入力変更", func(t *testing.T) {
		f, p := loadFixture(t, 1)
		o, _ := NewObserver(f.Tape, p, DefaultConfig())
		for _, r := range f.Records {
			if e := o.Feed(r); e != nil {
				t.Fatal(e)
			}
		}
		p.Children[0].Volume++
		if _, e := o.Finish(f.Header); e == nil {
			t.Fatal("子入力変更を許可")
		}
	})
	t.Run("Last0", func(t *testing.T) {
		f, p := loadFixture(t, 1)
		o, _ := NewObserver(f.Tape, p, DefaultConfig())
		o.quote = &tape.ScalarQuote{Time: p.Session.Start, Bid: 10, Ask: 15, QuoteOK: true}
		r := stream.Record{Ordinal: 1, Kind: "reset", At: p.Session.Start}
		if e := o.Feed(r); e != nil || o.quote == nil || !o.resetSinceQuote {
			t.Fatal("Last0で旧Actorと異なるQuote消去", e)
		}
	})
}

// TestPlannedDenominatorKeepsUnobserved はEOF前未観測を主副分母の未知に残します。
//
// 引数: t(*testing.T)は20分で収録が終わる人工検査器です。
// 返り値: ありません。未来Sourceの出生を計数しません。
func TestPlannedDenominatorKeepsUnobserved(t *testing.T) {
	f, p := loadFixture(t, 1)
	cut := p.Session.Start + 1200
	p.Session.EOF = cut
	events := f.Tape.Events[:0]
	for _, event := range f.Tape.Events {
		if event.At <= cut {
			events = append(events, event)
		}
	}
	f.Tape.Events = events
	records := f.Records[:0]
	grids := 0
	for _, r := range f.Records {
		if r.At <= cut {
			records = append(records, r)
			if r.Kind == "grid" {
				grids++
			}
		}
	}
	f.Records = records
	f.Header.Records = len(records)
	f.Header.Grids = grids
	f.Header.Ending.Legacy.ObservedClock = cut
	out := executeFixture(t, f, p)
	if out.PrimaryPlanned != 8 || out.PrimaryObserved != 1 || out.PrimaryUnobserved != 7 || out.PrimaryTechnical.Candidates != 16 || out.PrimaryTechnical.Unknown < 14 || out.SecondaryPlanned != 3 || len(out.SourceBirths) != 0 {
		t.Fatalf("計画分母/未観測/未来Source差:main%d observed%d unseen%d secondary%d births%d", out.PrimaryPlanned, out.PrimaryObserved, out.PrimaryUnobserved, out.SecondaryPlanned, len(out.SourceBirths))
	}
}

// TestResetAndReceivedAreDiagnostics は旧ActorどおりのQuote保持と別診断を確認します。
//
// 引数: t(*testing.T)はSourcequote→reset→grid相当の人工検査器です。
// 返り値: ありません。Receivedやresetで主候補を減らしません。
func TestResetAndReceivedAreDiagnostics(t *testing.T) {
	f, p := loadFixture(t, 1)
	o, e := NewObserver(f.Tape, p, DefaultConfig())
	if e != nil {
		t.Fatal(e)
	}
	at := p.Session.Start + 3000
	o.quote = &tape.ScalarQuote{Time: at - 100, Received: at + 1, Bid: 10480, Ask: 10490, QuoteOK: true}
	if e = o.Feed(stream.Record{Ordinal: 1, Kind: "reset", At: at}); e != nil {
		t.Fatal(e)
	}
	if e = o.grid(at); e != nil {
		t.Fatal(e)
	}
	row := o.report.GridRows[0]
	if !row.QuoteKnown || !row.ResetSinceQuote || !row.ReceivedAfterGrid || !row.QuoteOver90 || len(row.Technical.Decisions) != 2 {
		t.Fatal("診断で候補を除外", row.QuoteReason)
	}
}
