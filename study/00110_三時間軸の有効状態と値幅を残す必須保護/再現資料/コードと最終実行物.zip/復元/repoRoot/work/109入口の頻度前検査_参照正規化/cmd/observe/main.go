package main

import (
	"compress/gzip"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"strconv"
	"strings"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	reader "github.com/masayoshi4649/SessionTradeExecuter/savedpublic107"
	observer "github.com/masayoshi4649/SessionTradeExecuter/threeentryfrequency109"
	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	csvinput "github.com/masayoshi4649/SessionTradeExecuter/threeframeinput"
)

type FileRef struct {
	Path string `json:"path"`
	SHA  string `json:"sha256"`
}
type SceneRequest struct {
	Session string        `json:"session"`
	CSV     frame.FileRef `json:"candle_csv"`
}
type Request struct {
	Version            int            `json:"version"`
	Trial              int            `json:"trial"`
	Fixed              bool           `json:"fixed"`
	Stage              string         `json:"stage"`
	Technique          FileRef        `json:"technique_fixed"`
	Manifest           FileRef        `json:"manifest"`
	Corpus             FileRef        `json:"corpus"`
	Completion         FileRef        `json:"source_completion"`
	Scenes             []SceneRequest `json:"scenes"`
	Output             string         `json:"output_dir"`
	First2             *FileRef       `json:"first2_completion,omitempty"`
	ClockModel         string         `json:"clock_model"`
	QuoteMaxAgeSeconds float64        `json:"quote_max_age_seconds"`
	QuietSeconds       float64        `json:"quiet_seconds"`
}
type Technique struct {
	Fixed          bool              `json:"fixed"`
	ObserverBinary FileRef           `json:"observer_binary"`
	ObserverStop   FileRef           `json:"observer_stop"`
	CodeSHA        map[string]string `json:"code_sha256"`
}
type SceneOutput struct {
	Session   string          `json:"session"`
	Report    FileRef         `json:"report"`
	Grids     int             `json:"grids"`
	Technical observer.Counts `json:"technical"`
	Source    observer.Counts `json:"source_planned"`
	EndSeed   frame.SeedInfo  `json:"end_seed"`

	PrimaryPlanned         int             `json:"primary_planned_grids"`
	PrimaryObserved        int             `json:"primary_observed_grids"`
	PrimaryUnobserved      int             `json:"primary_unobserved_grids"`
	SecondaryPlanned       int             `json:"secondary_planned_grids"`
	SecondaryObserved      int             `json:"secondary_observed_grids"`
	SecondaryUnobserved    int             `json:"secondary_unobserved_grids"`
	PrimaryTechnical       observer.Counts `json:"primary_technical"`
	SecondaryTechnical     observer.Counts `json:"secondary_technical"`
	PrimarySource          observer.Counts `json:"primary_source_observed"`
	SecondarySource        observer.Counts `json:"secondary_source_observed"`
	PrimaryAllowedGrids    int             `json:"primary_technical_allowed_grids"`
	SecondaryAllowedGrids  int             `json:"secondary_technical_allowed_grids"`
	PrimarySourceAllowed   int             `json:"primary_source_allowed_grids"`
	SecondarySourceAllowed int             `json:"secondary_source_allowed_grids"`
}
type Completion struct {
	Version                 int               `json:"version"`
	Trial                   int               `json:"trial"`
	Stage                   string            `json:"stage"`
	Success                 bool              `json:"success"`
	Request                 FileRef           `json:"request"`
	Technique               FileRef           `json:"technique_fixed"`
	Manifest                FileRef           `json:"manifest"`
	Corpus                  FileRef           `json:"corpus"`
	SourceCompletion        FileRef           `json:"source_completion"`
	Config                  observer.Config   `json:"config"`
	Results                 []SceneOutput     `json:"results"`
	SummaryCSV              FileRef           `json:"summary_csv"`
	Before                  map[string]string `json:"before"`
	After                   map[string]string `json:"after"`
	Unchanged               bool              `json:"unchanged"`
	FinancialExecuted       bool              `json:"financial_executed"`
	ParticipationCalculated bool              `json:"participation_calculated"`
	Scope                   string            `json:"scope"`
}
type Plan struct {
	Request   Request
	Ref       FileRef
	Manifest  continuous.InputManifest
	Protected map[string]string
}

// digest は明示したファイルの全byteを同定します。
//
// 引数: path(string)は絶対pathです。
// 返り値: string/errorはSHA256又はI/O不成立です。
func digest(path string) (string, error) {
	f, e := os.Open(path)
	if e != nil {
		return "", e
	}
	defer f.Close()
	h := sha256.New()
	if _, e = io.Copy(h, f); e != nil {
		return "", e
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

// readRef は固定指紋を認証してJSONを読みます。
//
// 引数: ref(FileRef)、out(any)、proof(map[string]string)は出典・投影先・指紋台帳です。
// 返り値: errorは絶対path/SHA/JSON不正です。
func readRef(ref FileRef, out any, proof map[string]string) error {
	if !filepath.IsAbs(ref.Path) || len(ref.SHA) != 64 {
		return fmt.Errorf("絶対参照/SHAが不足")
	}
	if _, e := hex.DecodeString(ref.SHA); e != nil {
		return e
	}
	h, e := digest(ref.Path)
	if e != nil {
		return e
	}
	if h != ref.SHA {
		return fmt.Errorf("固定参照SHA差:%s", ref.Path)
	}
	proof[ref.Path] = h
	if out != nil {
		raw, e := os.ReadFile(ref.Path)
		if e != nil {
			return e
		}
		if e = json.Unmarshal(raw, out); e != nil {
			return e
		}
	}
	return nil
}

// loadPlan は技法固定・自己exe・停止・code・70順を本文読込前に確認します。
//
// 引数: ref(FileRef)は固定した実行条件です。
// 返り値: Plan/errorは実行計画又はmetadata差です。
func loadPlan(ref FileRef) (Plan, error) {
	p := Plan{Ref: ref, Protected: map[string]string{}}
	if e := readRef(ref, &p.Request, p.Protected); e != nil {
		return p, e
	}
	r := p.Request
	if r.Version != 1 || r.Trial != 109 || !r.Fixed || (r.Stage != "first2" && r.Stage != "full70") || r.ClockModel != observer.ClockModel || r.QuietSeconds != 1200 || r.QuoteMaxAgeSeconds != 0 || !filepath.IsAbs(r.Output) {
		return p, fmt.Errorf("頻度固定条件/段階/時計差")
	}
	if _, e := os.Stat(r.Output); !os.IsNotExist(e) {
		return p, fmt.Errorf("出力先は未作成の絶対folderが必要")
	}
	var t Technique
	if e := readRef(r.Technique, &t, p.Protected); e != nil {
		return p, e
	}
	if !t.Fixed || len(t.CodeSHA) == 0 {
		return p, fmt.Errorf("技法固定/コード指紋が不足")
	}
	if e := readRef(t.ObserverBinary, nil, p.Protected); e != nil {
		return p, e
	}
	actual, e := os.Executable()
	if e != nil {
		return p, e
	}
	actual, e = filepath.Abs(actual)
	if e != nil {
		return p, e
	}
	want, e := filepath.Abs(t.ObserverBinary.Path)
	if e != nil {
		return p, e
	}
	if !samePath(actual, want) {
		return p, fmt.Errorf("固定Observerと実行exe差")
	}
	var stop struct {
		Success bool `json:"成功"`
	}
	if e = readRef(t.ObserverStop, &stop, p.Protected); e != nil {
		return p, e
	}
	if !stop.Success {
		return p, fmt.Errorf("Observer停止が未成功")
	}
	for path, h := range t.CodeSHA {
		if e = readRef(FileRef{path, h}, nil, p.Protected); e != nil {
			return p, e
		}
	}
	if e = readRef(r.Manifest, &p.Manifest, p.Protected); e != nil {
		return p, e
	}
	if e = readRef(r.Corpus, nil, p.Protected); e != nil {
		return p, e
	}
	if e = readRef(r.Completion, nil, p.Protected); e != nil {
		return p, e
	}
	if len(p.Manifest.Sessions) != 70 {
		return p, fmt.Errorf("固定manifestは70場が必要")
	}
	wantCount := 70
	if r.Stage == "first2" {
		wantCount = 2
	}
	if len(r.Scenes) != wantCount {
		return p, fmt.Errorf("段階と明示scene数差")
	}
	for i, scene := range r.Scenes {
		expected := p.Manifest.Sessions[i]
		file, ok := expected.Files["NK225_candle_300"]
		csvPath, pathErr := normalizeCSVPath(p.Manifest.Root, file.Path)
		if scene.Session != expected.ID || !ok || pathErr != nil || !filepath.IsAbs(scene.CSV.Path) || !samePath(scene.CSV.Path, csvPath) || scene.CSV.SHA256 != file.SHA256 || scene.CSV.Bytes != file.Size {
			return p, fmt.Errorf("manifest順/5分CSV指紋差:%d", i)
		}
		if filepath.Base(scene.Session) != scene.Session {
			return p, fmt.Errorf("scene名がpathを含む")
		}
	}
	if r.Stage == "first2" && r.First2 != nil {
		return p, fmt.Errorf("first2に自己参照")
	}
	if r.Stage == "full70" {
		if r.First2 == nil {
			return p, fmt.Errorf("全70には成功first2が必要")
		}
		var prior Completion
		if e = readRef(*r.First2, &prior, p.Protected); e != nil {
			return p, e
		}
		if !prior.Success || prior.Stage != "first2" || len(prior.Results) != 2 || prior.Technique != r.Technique || prior.Manifest != r.Manifest || prior.Corpus != r.Corpus || prior.SourceCompletion != r.Completion || prior.Config != observer.DefaultConfig() {
			return p, fmt.Errorf("first2と全70の固定条件差")
		}
		for i, x := range prior.Results {
			if x.Session != r.Scenes[i].Session {
				return p, fmt.Errorf("first2のmanifest順差")
			}
		}
	}
	return p, nil
}

// samePath はWindowsでも大小文字を揃えた正規pathを比較します。
//
// 引数: a/b(string)は二つの絶対pathです。
// 返り値: boolは同一pathのとき真です。
func samePath(a, b string) bool { return strings.EqualFold(filepath.Clean(a), filepath.Clean(b)) }

// normalizeCSVPath はmanifestのCSV参照をsource_root内の絶対pathへ結びます。
//
// 引数: base/name(string)はmanifestの絶対source_rootとCSV参照です。
// 返り値: string/errorは正規path又は相対root・親参照・別rootの拒否です。
func normalizeCSVPath(base, name string) (string, error) {
	if !filepath.IsAbs(base) || name == "" {
		return "", fmt.Errorf("source_rootの絶対pathとCSV参照が必要")
	}
	for _, part := range strings.FieldsFunc(name, func(r rune) bool { return r == '/' || r == '\\' }) {
		if part == ".." {
			return "", fmt.Errorf("CSV参照の親Traversalを拒否")
		}
	}
	path := name
	if !filepath.IsAbs(path) {
		if filepath.VolumeName(path) != "" || strings.HasPrefix(path, "/") || strings.HasPrefix(path, "\\") {
			return "", fmt.Errorf("CSV参照のドライブ相対/根付きpathを拒否")
		}
		path = filepath.Join(base, path)
	}
	path = filepath.Clean(path)
	rel, e := filepath.Rel(filepath.Clean(base), path)
	if e != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(filepath.Separator)) || filepath.IsAbs(rel) {
		return "", fmt.Errorf("CSV参照がsource_root外")
	}
	return path, nil
}

// saveJSON は新規folderにだけJSON又はgzipJSONを書きます。
//
// 引数: path(string)、value(any)、compressed(bool)は新規出力先・値・圧縮有無です。
// 返り値: FileRef/errorは本文指紋又は保存不成立です。
func saveJSON(path string, value any, compressed bool) (FileRef, error) {
	f, e := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return FileRef{}, e
	}
	var writer io.Writer = f
	var z *gzip.Writer
	if compressed {
		z = gzip.NewWriter(f)
		writer = z
	}
	e = json.NewEncoder(writer).Encode(value)
	if z != nil {
		if closeErr := z.Close(); e == nil {
			e = closeErr
		}
	}
	if closeErr := f.Close(); e == nil {
		e = closeErr
	}
	if e != nil {
		return FileRef{}, e
	}
	h, e := digest(path)
	return FileRef{path, h}, e
}

// execute はmanifest先頭coldから順に純公表と純Entryだけを実行します。
//
// 引数: p(Plan)は認証済み固定条件です。
// 返り値: Completion/errorは頻度集計又は完全性差です。Actorを生成しません。
func execute(p Plan) (Completion, error) {
	r := p.Request
	c := Completion{Version: 1, Trial: 109, Stage: r.Stage, Request: p.Ref, Technique: r.Technique, Manifest: r.Manifest, Corpus: r.Corpus, SourceCompletion: r.Completion, Config: observer.DefaultConfig(), Before: p.Protected, Results: []SceneOutput{}, Scope: "技法条件の成立頻度。Source予定取得枠との重なりであり、金融適格性/参加率/損益ではない"}
	if e := os.MkdirAll(r.Output, 0700); e != nil {
		return c, e
	}
	var previous *frame.Seed
	for i, scene := range r.Scenes {
		loaded, e := reader.LoadTape(reader.Request{Manifest: reader.FileRef{Path: r.Manifest.Path, SHA: r.Manifest.SHA}, Corpus: reader.FileRef{Path: r.Corpus.Path, SHA: r.Corpus.SHA}, Completion: reader.FileRef{Path: r.Completion.Path, SHA: r.Completion.SHA}, SceneID: scene.Session})
		if e != nil {
			return c, e
		}
		input := loaded.Tape()
		header := loaded.Header()
		session := frame.Session{ID: input.Session.ID, Contract: header.Scene.Contract, Start: input.Session.Start, End: input.Session.End, EOF: header.Ending.Legacy.ObservedClock}
		children, e := csvinput.LoadChildren(session, scene.CSV)
		if e != nil {
			return c, e
		}
		p.Protected[scene.CSV.Path] = scene.CSV.SHA256
		o, e := observer.NewObserver(input, observer.PublicationInput{Session: session, Children: children.Bars, Seed: previous}, observer.DefaultConfig())
		if e != nil {
			return c, e
		}
		_, proof, e := reader.ReplayRecords(loaded, o.Feed)
		if e != nil {
			return c, e
		}
		if !proof.Unchanged {
			return c, fmt.Errorf("Source Reader入力変更")
		}
		for path, h := range proof.Before {
			p.Protected[path] = h
		}
		report, e := o.Finish(header)
		if e != nil {
			return c, e
		}
		seed, e := o.NextSeed()
		if e != nil {
			return c, e
		}
		previous = &seed
		ref, e := saveJSON(filepath.Join(r.Output, fmt.Sprintf("%05d_%s.json.gz", i+1, scene.Session)), report, true)
		if e != nil {
			return c, e
		}
		c.Results = append(c.Results, SceneOutput{Session: scene.Session, Report: ref, Grids: report.Grids, Technical: report.Technical, Source: report.SourcePlanned, EndSeed: report.EndSeed, PrimaryPlanned: report.PrimaryPlanned, PrimaryObserved: report.PrimaryObserved, PrimaryUnobserved: report.PrimaryUnobserved, SecondaryPlanned: report.SecondaryPlanned, SecondaryObserved: report.SecondaryObserved, SecondaryUnobserved: report.SecondaryUnobserved, PrimaryTechnical: report.PrimaryTechnical, SecondaryTechnical: report.SecondaryTechnical, PrimarySource: report.PrimarySource, SecondarySource: report.SecondarySource, PrimaryAllowedGrids: report.PrimaryAllowedGrids, SecondaryAllowedGrids: report.SecondaryAllowedGrids, PrimarySourceAllowed: report.PrimarySourceAllowed, SecondarySourceAllowed: report.SecondarySourceAllowed})
	}
	// ----------------------------------------
	// 全入出力の成功後にだけ合計CSVと完成台帳を新規保存します。
	c.Before = p.Protected
	c.After = map[string]string{}
	for path, want := range p.Protected {
		h, e := digest(path)
		if e != nil {
			return c, e
		}
		c.After[path] = h
		if h != want {
			return c, fmt.Errorf("頻度入力の前後指紋差:%s", path)
		}
	}
	c.Unchanged = reflect.DeepEqual(c.Before, c.After)
	if !c.Unchanged {
		return c, fmt.Errorf("頻度入力不変差")
	}
	ref, e := writeSummary(filepath.Join(r.Output, "頻度集計.csv"), c.Results)
	if e != nil {
		return c, e
	}
	c.SummaryCSV = ref
	c.Success = true
	_, e = saveJSON(filepath.Join(r.Output, "完成.json"), c, false)
	return c, e
}

// writeSummary は各場の技法候補計数をCSVへ保存します。
//
// 引数: path(string)、rows([]SceneOutput)は出力先と場別計数です。
// 返り値: FileRef/errorはCSV指紋又は保存不成立です。金額を記載しません。
func writeSummary(path string, rows []SceneOutput) (FileRef, error) {
	f, e := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return FileRef{}, e
	}
	writer := csv.NewWriter(f)
	e = writer.Write([]string{"セッション", "全観測5分枠", "主計画枠", "主観測枠", "主未観測枠", "主技法候補", "主技法既知", "主技法未知", "主T成立", "主R成立", "主競合後許可候補", "主技法許可枠", "主Source予定候補", "主Source許可候補", "主Source許可枠", "副計画枠", "副観測枠", "副未観測枠", "副技法許可枠", "副Source許可枠", "全技法候補", "技法既知", "技法未知", "技法T成立", "技法R成立", "技法競合後許可", "Source予定候補", "Source既知", "Source未知", "SourceT成立", "SourceR成立", "Source競合後許可"})
	for _, row := range rows {
		if e != nil {
			break
		}
		values := []int{row.Grids, row.PrimaryPlanned, row.PrimaryObserved, row.PrimaryUnobserved, row.PrimaryTechnical.Candidates, row.PrimaryTechnical.Known, row.PrimaryTechnical.Unknown, row.PrimaryTechnical.TrendPassed, row.PrimaryTechnical.ReversalPassed, row.PrimaryTechnical.Allowed, row.PrimaryAllowedGrids, row.PrimarySource.Candidates, row.PrimarySource.Allowed, row.PrimarySourceAllowed, row.SecondaryPlanned, row.SecondaryObserved, row.SecondaryUnobserved, row.SecondaryAllowedGrids, row.SecondarySourceAllowed, row.Technical.Candidates, row.Technical.Known, row.Technical.Unknown, row.Technical.TrendPassed, row.Technical.ReversalPassed, row.Technical.Allowed, row.Source.Candidates, row.Source.Known, row.Source.Unknown, row.Source.TrendPassed, row.Source.ReversalPassed, row.Source.Allowed}
		record := []string{row.Session}
		for _, v := range values {
			record = append(record, strconv.Itoa(v))
		}
		e = writer.Write(record)
	}
	writer.Flush()
	if e == nil {
		e = writer.Error()
	}
	if closeErr := f.Close(); e == nil {
		e = closeErr
	}
	if e != nil {
		return FileRef{}, e
	}
	h, e := digest(path)
	return FileRef{path, h}, e
}

// main は明示された固定条件でのみ金融なしの前検査を開始します。
//
// 引数: CLIの--request/--request-sha256は絶対条件pathと指紋です。
// 返り値: ありません。不成立なら終了code1を返します。
func main() {
	path := flag.String("request", "", "固定条件の絶対path")
	sha := flag.String("request-sha256", "", "固定条件のSHA256")
	flag.Parse()
	p, e := loadPlan(FileRef{*path, *sha})
	if e == nil {
		_, e = execute(p)
	}
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
	fmt.Println("頻度前検査完了。金融適格性・参加率・損益は未計算")
}
