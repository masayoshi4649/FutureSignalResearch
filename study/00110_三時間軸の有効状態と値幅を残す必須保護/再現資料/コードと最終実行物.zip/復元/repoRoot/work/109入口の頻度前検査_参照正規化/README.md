# 109入口の成立頻度を金融前に確認する

この版は停止5939b05e…の参照正規化だけを派生した。manifestの相対CSVを絶対source_rootへ結び、Root生成器の絶対要求と照合する。親Traversal・ドライブ相対参照・別rootを拒否する。三技法・分母・公開時計・pure判定は旧版と同一。旧停止は変更しない。

固定106のSource/Record、停止threeframe/threeentry、指紋付き5分CSVを接続する独立Observer。Actorは作らず、金融Feed・約定・含み損益・決済後の仮想利益・参加率を計算しない。技法の成立頻度とSourceの**予定取得枠**がどれほど重なるかを確認する。

市場値の読込みはRootが技法条件と実行条件を固定した後に明示CLIで行う。現在の停止は人工段階。11/09の未使用本文も読まない。市場I/Oの口は固定ReaderとCSV loaderだけであり、新規Raw板や自然Sourceを生成しない。

## 固定API

```go
DefaultConfig() Config
NewObserver(input tape.Tape, publication PublicationInput, config Config) (*Observer, error)
(*Observer).Feed(record stream.Record) error
(*Observer).Finish(header stream.Header) (Report, error)
(*Observer).NextSeed() (threeframe.Seed, error)
```

Configは `clock_model=csv_end_plus60_at_record_scheduler`、`quote_max_age_seconds=0`、`quiet_seconds=1200` の照合値。pure EntryのRulesは変更できない。各Record.Atで公開器を進め、AfterEOFForceは観測時計を進めない。金融Coreと同じEOF射影を使う。

## 計数の意味

- 全配送gridで、同じEntryStateと同じ公開履歴から、観測BBOの買売各1候補と、当時出生済みSourceの予定取得枠候補を別々に純判定する。空集合でも判定し、三つのnextStateが完全同体であることを毎回確認して一つだけcommitする。
- Source newの到着時だけstrict次5分＋quiet一回繰越を計算する。未来の出生は先取りしない。due行のFilledSeen/CancellationSeenはその枠までの観測値。最終SourceBirthsのフラグは場末値であり、過去のdue採否へ戻さない。
- Sourceの金融適格性、実玉・予約・余力、Source hold残量、手法別締切は再現しない。取消済み/未約定等も予定枠の診断対象として残す。この集合と実金融のE1集合を同一視しない。
- T/R Check成立と両向き競合後の許可を別集計する。EMA/MACDの票数を増やさず、停止Entryの同じ構造・勢い・値幅条件を使う。量は既知/未知を監査するだけでANDへ追加しない。

主計画分母は `[Start+1200, ForceClose)`、副は `[Start+1200, End−1800)` の300秒格子。現行ForceCloseはEnd−600。Nightの米国quietも分母には残す。純状態は分母外gridでも更新する。EOF等で未観測の予定枠は主副の未観測件数と技法未知（買売2候補）へ残し、観測できた枠だけで割らない。Sourceの未観測未来出生数は推定できないため、観測済み出生との重なりと未観測gridを別記する。

これらは金融の「新規＋保有の参加率」ではない。主技法許可枠/主計画枠を算出しても、成立頻度という診断以上の意味を持たせない。

## BBOの主条件と診断

旧Actorと同じく、最新の**正Last NK Scalar**を保持し、QuoteOK、有限BBO、0＜bid＜ask、q.Time≦gridで既知とする。reset/Last0だけでは最新BBOを消さない。不良の正Last Scalarが届けば最新値を更新し、正常条件を満たすまで未知となる。未観測/未来原行BBOも未知のまま分母に残す。

経過年齢は制限なし。5秒以下/5～30秒/30～90秒/90秒超を診断する。Received＞grid、直前quote以後のresetも診断flagだけで、主成立を変更しない。Frame鮮度は停止Entryの既存仕様を用いる。

時計はCSVの足終+60秒をRecord.At schedulerで配送したモデル。実通信受信の検証とは呼ばない。

## CLI

ビルドは `go build -o 検査/109頻度前検査.exe ./cmd/observe`。実行は次の二つの引数のみ。

```powershell
& '検査/109頻度前検査.exe' --request '<固定条件の絶対path>' --request-sha256 '<SHA256>'
```

[条件の雛形.json](条件の雛形.json)のscenesはfirst2がmanifest先頭2、full70が全70。両段階とも先頭coldから数値種を連鎖させる。full70は同じ技法固定・入力・時計条件の成功first2完成を参照する。出力先は未作成の絶対folderでなければならない。

技法固定JSONの `observer_binary` を実行中exeのpath/SHAへ照合し、`observer_stop` の実物SHAと成功、`code_sha256` の各実物を認証する。その他の技法固定fieldはRootの台帳へ残す。Sourceのmanifest/corpus/completionは固定Readerが認証し、CSV参照はmanifestのNK225_candle_300と全値照合する。

出力は場別の圧縮JSON、`頻度集計.csv`、`完成.json`。CSVは候補数・既知性・主副計画枠・T/R成立の集計であり、損益CSVではない。場別JSONに理由・BBO診断・量状態・予定出生・純Batch・主副タグを残す。原板や全Source/Recordを再出力しない。

## 人工検査

買売の実publisher→純Entryの非ゼロT成立と予定Source join、候補集合によるstate非干渉、BBO未知、90秒超を除外しないこと、reset/Received診断、EOF未観測を主副分母へ保持、入力変更/metadata/自己exe/停止/code/順序拒否、CSV列と上書き拒否を検査する。

固定Readerの6Record人工codecも実I/Oへ接続する。元codecのEOF=0は人工コピーで観測末尾Start+2を明示してから使用し、未来足は公開しない。この単場I/O人工を全70成功とは呼ばない。依存元の停止物や原人工は変更しない。

`python 検査と停止を記録する.py` はGo test/vet/build、固定依存不変を確認し、共通の成功/所有コードSHA256を持つ停止.jsonとexeを新規保存する。市場実行・実参加率・損益・採用判断は未実施。
