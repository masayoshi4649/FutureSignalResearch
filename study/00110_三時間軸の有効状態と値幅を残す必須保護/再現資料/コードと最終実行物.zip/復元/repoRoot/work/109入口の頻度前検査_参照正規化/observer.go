// Package threeentryfrequency109 は金融を実行せず、確定公開とSource予定枠の重なりを計数します。
package threeentryfrequency109

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"reflect"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
	quiet "github.com/masayoshi4649/SessionTradeExecuter/quietlength108"
	entry "github.com/masayoshi4649/SessionTradeExecuter/threeentry"
	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

const ClockModel = "csv_end_plus60_at_record_scheduler"

type Config struct {
	ClockModel         string  `json:"clock_model"`
	QuoteMaxAgeSeconds float64 `json:"quote_max_age_seconds"`
	QuietSeconds       float64 `json:"quiet_seconds"`
}
type PublicationInput struct {
	Session  frame.Session    `json:"session"`
	Children []frame.ChildBar `json:"children"`
	Seed     *frame.Seed      `json:"-"`
}
type Birth struct {
	ID               string           `json:"id"`
	Method           string           `json:"method"`
	SignalID         string           `json:"signal_id"`
	Side             int              `json:"side"`
	Quantity         int              `json:"quantity"`
	BornAt           float64          `json:"born_at"`
	ObservedAt       float64          `json:"observed_at"`
	Assignment       quiet.Assignment `json:"assignment"`
	FilledSeen       bool             `json:"filled_seen"`
	CancellationSeen bool             `json:"cancellation_seen"`
	DueObserved      bool             `json:"due_observed"`
}
type Counts struct {
	Candidates     int            `json:"candidates"`
	Known          int            `json:"known"`
	Unknown        int            `json:"unknown"`
	Allowed        int            `json:"allowed"`
	Wait           int            `json:"wait"`
	Conflicts      int            `json:"conflicts"`
	TrendPassed    int            `json:"trend_passed"`
	ReversalPassed int            `json:"reversal_passed"`
	Reasons        map[string]int `json:"reasons"`
}
type Grid struct {
	At                float64               `json:"at"`
	Primary           bool                  `json:"primary"`
	Secondary         bool                  `json:"secondary"`
	Quiet             bool                  `json:"quiet"`
	AtOrAfterForce    bool                  `json:"at_or_after_force"`
	LastThirtyMinutes bool                  `json:"last_thirty_minutes"`
	QuoteKnown        bool                  `json:"quote_known"`
	QuoteReason       string                `json:"quote_reason"`
	Quote             *tape.ScalarQuote     `json:"quote"`
	QuoteAgeSeconds   *float64              `json:"quote_age_seconds"`
	QuoteOver90       bool                  `json:"quote_over_90_seconds"`
	ReceivedAfterGrid bool                  `json:"received_after_grid"`
	ResetSinceQuote   bool                  `json:"reset_since_quote"`
	SnapshotID        string                `json:"snapshot_id"`
	Technical         entry.BatchAssessment `json:"technical_batch"`
	Source            entry.BatchAssessment `json:"source_planned_batch"`
	Due               []Birth               `json:"due_births"`
	StateIndependent  bool                  `json:"state_independent"`
}
type Report struct {
	Version                  int             `json:"version"`
	Trial                    int             `json:"trial"`
	Scope                    string          `json:"scope"`
	Session                  frame.Session   `json:"session"`
	Config                   Config          `json:"config"`
	Records                  int             `json:"records"`
	SourceEvents             int             `json:"source_events"`
	Grids                    int             `json:"grids"`
	PrimaryPlanned           int             `json:"primary_planned_grids"`
	PrimaryObserved          int             `json:"primary_observed_grids"`
	PrimaryUnobserved        int             `json:"primary_unobserved_grids"`
	SecondaryPlanned         int             `json:"secondary_planned_grids"`
	SecondaryObserved        int             `json:"secondary_observed_grids"`
	SecondaryUnobserved      int             `json:"secondary_unobserved_grids"`
	QuoteUnknownGrids        int             `json:"quote_unknown_grids"`
	QuoteAgeBuckets          map[string]int  `json:"quote_age_buckets"`
	QuoteOver90              int             `json:"quote_over90_grids"`
	ReceivedFutureGrids      int             `json:"received_after_grid_grids"`
	ResetRecords             int             `json:"reset_records"`
	Technical                Counts          `json:"technical"`
	SourcePlanned            Counts          `json:"source_planned"`
	PrimaryTechnical         Counts          `json:"primary_technical"`
	SecondaryTechnical       Counts          `json:"secondary_technical"`
	PrimarySource            Counts          `json:"primary_source_observed"`
	SecondarySource          Counts          `json:"secondary_source_observed"`
	PrimaryAllowedGrids      int             `json:"primary_technical_allowed_grids"`
	SecondaryAllowedGrids    int             `json:"secondary_technical_allowed_grids"`
	PrimarySourceAllowed     int             `json:"primary_source_allowed_grids"`
	SecondarySourceAllowed   int             `json:"secondary_source_allowed_grids"`
	TechnicalAnyAllowedGrids int             `json:"technical_any_allowed_grids"`
	SourceAnyAllowedGrids    int             `json:"source_any_allowed_grids"`
	SourceBirths             []Birth         `json:"source_births"`
	GridRows                 []Grid          `json:"grid_rows"`
	Frames                   map[int]int     `json:"frames"`
	InputSeed                *frame.SeedInfo `json:"input_seed"`
	EndSeed                  frame.SeedInfo  `json:"end_seed"`
	TapeSHA                  string          `json:"tape_sha256"`
	ChildrenSHA              string          `json:"children_sha256"`
	InputsUnchanged          bool            `json:"inputs_unchanged"`
	StateIndependent         bool            `json:"state_independent"`
	PolicyEOFRedacted        bool            `json:"policy_eof_redacted"`
	FinancialExecuted        bool            `json:"financial_executed"`
	SourceReexecuted         bool            `json:"source_reexecuted"`
	ParticipationCalculated  bool            `json:"participation_calculated"`
	Complete                 bool            `json:"complete"`
}
type Observer struct {
	input           tape.Tape
	publication     PublicationInput
	bank            *frame.Bank
	state           entry.EntryState
	quote           *tape.ScalarQuote
	resetSinceQuote bool
	births          []Birth
	birthIndex      map[string]int
	report          Report
	cursor          int
	ordinal         int
	lastAt          float64
	finished        bool
	failed          error
	nextSeed        frame.Seed
}

// DefaultConfig は金融と同じ静観と年齢制限なしの主条件を返します。
//
// 引数: なし。
// 返り値: Configは変更可能な閾値ではなく照合用の固定値です。
func DefaultConfig() Config { return Config{ClockModel, 0, 1200} }

// valueSHA は公開入力の全値を同定します。
//
// 引数: value(any)は有限JSON値です。
// 返り値: string/errorは全値SHA256又は不正です。
func valueSHA(value any) (string, error) {
	raw, e := json.Marshal(value)
	if e != nil {
		return "", e
	}
	h := sha256.Sum256(raw)
	return hex.EncodeToString(h[:]), nil
}

// NewObserver はActorを作らず新公開器と一つの純EntryStateを初期化します。
//
// 引数: input(Tape)、publication(PublicationInput)、config(Config)は固定値です。
// 返り値: *Observer/errorは金融を持たないSink又は設定差です。
func NewObserver(input tape.Tape, publication PublicationInput, config Config) (*Observer, error) {
	if config != DefaultConfig() || input.Version != 1 || !reflect.DeepEqual(input.Capabilities, tape.Capabilities()) || publication.Session.ID != input.Session.ID || publication.Session.Start != input.Session.Start || publication.Session.End != input.Session.End {
		return nil, fmt.Errorf("頻度主条件/場/Source版差")
	}
	bank, e := frame.BeginSession(publication.Session, publication.Children, publication.Seed)
	if e != nil {
		return nil, e
	}
	h, e := valueSHA(input)
	if e != nil {
		return nil, e
	}
	ch, e := valueSHA(publication.Children)
	if e != nil {
		return nil, e
	}
	r := Report{Version: 1, Trial: 109, Scope: "技法成立頻度と出生済みSource予定取得枠の重なり。金融適格性・参加率・損益は未計算", Session: publication.Session, Config: config, QuoteAgeBuckets: map[string]int{}, Frames: map[int]int{}, Technical: Counts{Reasons: map[string]int{}}, SourcePlanned: Counts{Reasons: map[string]int{}}, TapeSHA: h, ChildrenSHA: ch, StateIndependent: true, PolicyEOFRedacted: true, GridRows: []Grid{}, SourceBirths: []Birth{}}
	r.PrimaryTechnical.Reasons = map[string]int{}
	r.SecondaryTechnical.Reasons = map[string]int{}
	r.PrimarySource.Reasons = map[string]int{}
	r.SecondarySource.Reasons = map[string]int{}
	for at := 300 * math.Ceil((input.Session.Start+1200)/300); at < input.Session.ForceClose; at += 300 {
		r.PrimaryPlanned++
	}
	for at := 300 * math.Ceil((input.Session.Start+1200)/300); at < input.Session.End-1800; at += 300 {
		r.SecondaryPlanned++
	}
	if publication.Seed != nil {
		v := publication.Seed.Info()
		r.InputSeed = &v
	}
	return &Observer{input: input, publication: publication, bank: bank, state: entry.NewEntryState(), birthIndex: map[string]int{}, report: r}, nil
}

// Feed は認証済み106Recordを同じ名目Atで一度だけ進めます。
//
// 引数: record(stream.Record)はReaderが検証する保存配送です。
// 返り値: errorは公表/Source結合の不成立です。金融Feedを呼びません。
func (o *Observer) Feed(record stream.Record) (err error) {
	if o == nil {
		return fmt.Errorf("頻度Observer未初期化")
	}
	if o.finished || o.failed != nil {
		return fmt.Errorf("終了又は失敗後の頻度配送")
	}
	defer func() {
		if err != nil {
			o.failed = err
		}
	}()
	if record.Ordinal != o.ordinal+1 || math.IsNaN(record.At) || math.IsInf(record.At, 0) || record.At < o.lastAt {
		return fmt.Errorf("頻度Recordのordinal/単調時計差")
	}
	if !record.AfterEOF {
		frames, e := o.bank.AdvanceObserved(record.At, uint64(record.Ordinal))
		if e != nil {
			return e
		}
		for _, f := range frames {
			o.report.Frames[f.WidthSeconds]++
		}
	}
	// ----------------------------------------
	// Quoteは金融と同じ最新の正Last Scalarを保持し、Last0/resetだけでは消しません。
	if record.Kind == "reset" {
		o.resetSinceQuote = true
		o.report.ResetRecords++
	}
	if record.Kind == "quote" || record.Kind == "grid" || record.Kind == "force" {
		if o.cursor >= len(o.input.Events) {
			return fmt.Errorf("Source余剰")
		}
		event := o.input.Events[o.cursor]
		if event.Kind != record.Kind || event.At != record.At || event.Ordinal != o.cursor+1 {
			return fmt.Errorf("Source予定枠のcursor/位相差")
		}
		if record.Kind == "quote" {
			if event.Quote == nil || record.Scalar == nil || !reflect.DeepEqual(*event.Quote, *record.Scalar) {
				return fmt.Errorf("Source Scalar差")
			}
			q := *record.Scalar
			o.quote = &q
			o.resetSinceQuote = false
		}
		if record.Kind == "grid" {
			if err = o.grid(record.At); err != nil {
				return err
			}
		} else {
			if err = o.observeBirths(event); err != nil {
				return err
			}
		}
		o.cursor++
	}
	o.ordinal = record.Ordinal
	o.lastAt = record.At
	o.report.Records++
	return nil
}

// observeBirths は到着済みnew通知だけを予定取得枠へ一度割り当てます。
//
// 引数: event(TapeEvent)は当時消費中のSource通知です。
// 返り値: errorは出生の重複・未来又はclock差です。予約・実玉を再現しません。
func (o *Observer) observeBirths(event tape.TapeEvent) error {
	for _, batch := range event.NonEmpty {
		for _, wrapped := range batch.Delta.Signals {
			signal := wrapped.Signal
			if signal.Action != "new" {
				continue
			}
			id := batch.Method + "|" + signal.ID
			if _, ok := o.birthIndex[id]; ok || signal.Time > event.At || signal.Time < o.input.Session.Start || (signal.Side != 1 && signal.Side != -1) || signal.Quantity <= 0 {
				return fmt.Errorf("出生重複/未来/数量差")
			}
			a, e := quiet.AssignQuietOnceWithDuration(quiet.SessionClock{Kind: o.input.Session.Kind, Start: o.input.Session.Start, USOpen: o.input.Session.USOpen}, signal.Time, 1200)
			if e != nil {
				return e
			}
			o.birthIndex[id] = len(o.births)
			o.births = append(o.births, Birth{ID: id, Method: batch.Method, SignalID: signal.ID, Side: signal.Side, Quantity: signal.Quantity, BornAt: signal.Time, ObservedAt: event.At, Assignment: a})
		}
		for _, fill := range batch.Delta.Fills {
			if index, ok := o.birthIndex[batch.Method+"|"+fill.Fill.SignalID]; ok {
				o.births[index].FilledSeen = true
			}
		}
		for _, cancel := range batch.Delta.Cancellations {
			if index, ok := o.birthIndex[batch.Method+"|"+cancel.SignalID]; ok {
				o.births[index].CancellationSeen = true
			}
		}
	}
	return nil
}

// quoteAt は正常BBOと未来なしを確認し、経過年齢を診断値だけとして返します。
//
// 引数: at(float64)は当時のgridです。
// 返り値: bool/string/*float64は既知性・理由・経過年齢で、90秒を除外条件にしません。
func (o *Observer) quoteAt(at float64) (bool, string, *float64) {
	if o.quote == nil {
		return false, "観測済み正LastのScalarなし", nil
	}
	q := *o.quote
	if q.Time > at {
		return false, "Quoteの原行時計が未来", nil
	}
	if !q.QuoteOK || math.IsNaN(q.Bid) || math.IsNaN(q.Ask) || math.IsInf(q.Bid, 0) || math.IsInf(q.Ask, 0) || q.Bid <= 0 || q.Ask <= q.Bid {
		return false, "観測済み正常BBOが不足", nil
	}
	age := at - q.Time
	return true, "観測済み正常BBO・年齢制限なし", &age
}

// grid は二つの候補集合を同じ旧状態で査定し、状態非干渉を確認します。
//
// 引数: at(float64)は元の5分判断枠です。
// 返り値: errorは値・政策・候補依存state更新の不成立です。
func (o *Observer) grid(at float64) error {
	public, e := o.bank.SnapshotAt(at)
	if e != nil {
		return e
	}
	snapshot := entry.PolicySnapshot(public)
	if snapshot.Session.EOF != 0 || snapshot.Sealed {
		return fmt.Errorf("政策EOF射影差")
	}
	id, e := entry.SnapshotID(snapshot)
	if e != nil {
		return e
	}
	known, reason, age := o.quoteAt(at)
	row := Grid{At: at, Quiet: o.isQuiet(at), AtOrAfterForce: at >= o.input.Session.ForceClose, LastThirtyMinutes: at >= o.input.Session.End-1800, QuoteKnown: known, QuoteReason: reason, QuoteAgeSeconds: age, SnapshotID: id, Due: []Birth{}}
	row.ResetSinceQuote = o.resetSinceQuote
	if o.quote != nil && o.quote.Received > at {
		row.ReceivedAfterGrid = true
		o.report.ReceivedFutureGrids++
	}
	row.Primary = at >= o.input.Session.Start+1200 && at < o.input.Session.ForceClose
	row.Secondary = at >= o.input.Session.Start+1200 && at < o.input.Session.End-1800
	if o.quote != nil {
		q := *o.quote
		row.Quote = &q
	}
	technical := []entry.Candidate{}
	planned := []entry.Candidate{}
	if known {
		technical = []entry.Candidate{{ID: "技法観察_買", Side: 1, At: at, EntryQuote: o.quote.Ask, Quantity: 1}, {ID: "技法観察_売", Side: -1, At: at, EntryQuote: o.quote.Bid, Quantity: 1}}
	}
	for i := range o.births {
		b := &o.births[i]
		if b.Assignment.AssignedAt != at {
			continue
		}
		if b.BornAt >= at || b.ObservedAt >= at {
			return fmt.Errorf("当枠以後の出生を先取り")
		}
		b.DueObserved = true
		row.Due = append(row.Due, *b)
		if known {
			price := o.quote.Ask
			if b.Side < 0 {
				price = o.quote.Bid
			}
			planned = append(planned, entry.Candidate{ID: b.ID, Side: b.Side, At: at, EntryQuote: price, Quantity: b.Quantity})
		}
	}
	next, a, e := entry.AssessBatch(o.state, snapshot, technical, entry.EntryE1)
	if e != nil {
		return e
	}
	nextSource, b, e := entry.AssessBatch(o.state, snapshot, planned, entry.EntryE1)
	if e != nil {
		return e
	}
	nextEmpty, _, e := entry.AssessBatch(o.state, snapshot, nil, entry.EntryE1)
	if e != nil {
		return e
	}
	if !reflect.DeepEqual(next, nextSource) || !reflect.DeepEqual(next, nextEmpty) {
		return fmt.Errorf("候補集合がsetup進行を変化")
	}
	o.state = next
	row.Technical = a
	row.Source = b
	row.StateIndependent = true
	if age != nil {
		bucket := "90秒超"
		if *age <= 5 {
			bucket = "5秒以下"
		} else if *age <= 30 {
			bucket = "5秒超30秒以下"
		} else if *age <= 90 {
			bucket = "30秒超90秒以下"
		}
		o.report.QuoteAgeBuckets[bucket]++
		if *age > 90 {
			row.QuoteOver90 = true
			o.report.QuoteOver90++
		}
	}
	if !known {
		o.report.QuoteUnknownGrids++
		addQuoteUnknown(&o.report.Technical, 2, reason)
		addQuoteUnknown(&o.report.SourcePlanned, len(row.Due), reason)
	} else {
		addBatch(&o.report.Technical, a)
		addBatch(&o.report.SourcePlanned, b)
	}
	if anyAllowed(a) {
		o.report.TechnicalAnyAllowedGrids++
	}
	if anyAllowed(b) {
		o.report.SourceAnyAllowedGrids++
	}
	o.report.Grids++
	if row.Primary {
		o.report.PrimaryObserved++
		addCohort(&o.report.PrimaryTechnical, &o.report.PrimarySource, row)
		if anyAllowed(a) {
			o.report.PrimaryAllowedGrids++
		}
		if anyAllowed(b) {
			o.report.PrimarySourceAllowed++
		}
	}
	if row.Secondary {
		o.report.SecondaryObserved++
		addCohort(&o.report.SecondaryTechnical, &o.report.SecondarySource, row)
		if anyAllowed(a) {
			o.report.SecondaryAllowedGrids++
		}
		if anyAllowed(b) {
			o.report.SecondarySourceAllowed++
		}
	}
	o.report.GridRows = append(o.report.GridRows, row)
	return nil
}

// isQuiet は事前に既知の場と米国開始時計だけから静観を判定します。
//
// 引数: at(float64)は判断枠です。
// 返り値: boolは開始1200秒又はNight米国開始1200秒の内側です。
func (o *Observer) isQuiet(at float64) bool {
	s := o.input.Session
	return at < s.Start+1200 || s.Kind == "Night" && at >= s.USOpen && at < s.USOpen+1200
}

// addQuoteUnknown はBBO未知を候補分母に残します。
//
// 引数: counts(*Counts)、quantity(int)、reason(string)は集計先・候補数・理由です。
// 返り値: ありません。
func addQuoteUnknown(counts *Counts, quantity int, reason string) {
	counts.Candidates += quantity
	counts.Unknown += quantity
	counts.Reasons[reason] += quantity
}

// addCohort は主/副の計画分母に属する観測済み枠を数えます。
//
// 引数: technical/source(*Counts)、row(Grid)は集計先と公表済み判断です。
// 返り値: ありません。米国静観も分母から除きません。
func addCohort(technical, source *Counts, row Grid) {
	if row.QuoteKnown {
		addBatch(technical, row.Technical)
		addBatch(source, row.Source)
	} else {
		addQuoteUnknown(technical, 2, row.QuoteReason)
		addQuoteUnknown(source, len(row.Due), row.QuoteReason)
	}
}

// addBatch は競合前のT/R成立と競合後の許可を別に数えます。
//
// 引数: counts(*Counts)、batch(entry.BatchAssessment)は集計先と純結果です。
// 返り値: ありません。
func addBatch(counts *Counts, batch entry.BatchAssessment) {
	for _, a := range batch.Decisions {
		counts.Candidates++
		counts.Reasons[a.Reason]++
		if a.Known {
			counts.Known++
		} else {
			counts.Unknown++
		}
		if a.Allowed {
			counts.Allowed++
		}
		if a.Status == entry.Wait {
			counts.Wait++
		}
		if a.Status == entry.Conflict {
			counts.Conflicts++
		}
		if a.Trend.Known && a.Trend.Passed {
			counts.TrendPassed++
		}
		if a.Reversal.Known && a.Reversal.Passed {
			counts.ReversalPassed++
		}
	}
}

// anyAllowed は当枠の一方向以上の技術成立だけを判定します。
//
// 引数: batch(entry.BatchAssessment)は純結果です。
// 返り値: boolは実参加率や発注可能性を示しません。
func anyAllowed(batch entry.BatchAssessment) bool {
	for _, a := range batch.Decisions {
		if a.Allowed {
			return true
		}
	}
	return false
}

// Finish はSource完全消費と公表EOF、入力不変を照合して計数を完結します。
//
// 引数: header(stream.Header)はReaderが全列消費後に返したものです。
// 返り値: Report/errorは金融のない成立頻度又は完全性差です。
func (o *Observer) Finish(header stream.Header) (Report, error) {
	if o == nil {
		return Report{}, fmt.Errorf("頻度Observer未初期化")
	}
	if o.finished || o.failed != nil {
		return Report{}, fmt.Errorf("失敗又は終了後の完結")
	}
	o.finished = true
	if !header.Success || header.Records != o.ordinal || header.Grids != o.report.Grids || o.cursor != len(o.input.Events) || header.Ending.Legacy.ObservedClock != o.publication.Session.EOF {
		return Report{}, fmt.Errorf("頻度Header/Source/EOF差")
	}
	seed, snapshot, e := o.bank.Seal()
	if e != nil {
		return Report{}, e
	}
	if snapshot.ReplayObservedAt != o.publication.Session.EOF {
		return Report{}, fmt.Errorf("頻度公表EOF差")
	}
	h, e := valueSHA(o.input)
	if e != nil {
		return Report{}, e
	}
	ch, e := valueSHA(o.publication.Children)
	if e != nil {
		return Report{}, e
	}
	if h != o.report.TapeSHA || ch != o.report.ChildrenSHA {
		return Report{}, fmt.Errorf("頻度入力が変更された")
	}
	o.nextSeed = seed
	o.report.EndSeed = seed.Info()
	o.report.SourceEvents = o.cursor
	o.report.SourceBirths = append([]Birth{}, o.births...)
	o.report.PrimaryUnobserved = o.report.PrimaryPlanned - o.report.PrimaryObserved
	o.report.SecondaryUnobserved = o.report.SecondaryPlanned - o.report.SecondaryObserved
	if o.report.PrimaryUnobserved < 0 || o.report.SecondaryUnobserved < 0 {
		return Report{}, fmt.Errorf("計画分母より観測gridが多い")
	}
	addQuoteUnknown(&o.report.PrimaryTechnical, 2*o.report.PrimaryUnobserved, "EOF等により当枠未観測。未来値を補わない")
	addQuoteUnknown(&o.report.SecondaryTechnical, 2*o.report.SecondaryUnobserved, "EOF等により当枠未観測。未来値を補わない")
	o.report.InputsUnchanged = true
	o.report.Complete = true
	return o.report, nil
}

// NextSeed は成功完結後だけ直後場用の私有数値種を返します。
//
// 引数: なし。
// 返り値: frame.Seed/errorは数値種又は未完結です。
func (o *Observer) NextSeed() (frame.Seed, error) {
	if o == nil || !o.report.Complete {
		return frame.Seed{}, fmt.Errorf("頻度完結前の数値種")
	}
	return o.nextSeed, nil
}
