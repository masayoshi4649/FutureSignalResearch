// Package minisymmetric104 は固定Sourceを変更せず完全式mapの生成時overrideを接続します。
package minisymmetric104

import native "github.com/masayoshi4649/SessionTradeExecuter/mininative"

type Observation = native.Observation
type Session = native.Session
type Signal = native.Signal
type Fill = native.Fill
type ProductConfig = native.ProductConfig
type QuoteStamp = native.QuoteStamp
type CloseNotice = native.CloseNotice
type SignalRecord = native.SignalRecord
type CloseAllocation = native.CloseAllocation
type FillRecord = native.FillRecord
type Cancellation = native.Cancellation
type HoldLedger = native.HoldLedger
type LedgerTotals = native.LedgerTotals
type StepResult = native.StepResult
type Ledger = native.Ledger

// MiniConfig は旧93の固定mini商品規格をそのまま返します。
//
// 引数: ありません。
// 返り値: ProductConfigは元の点価/量/費用です。
func MiniConfig() ProductConfig { return native.MiniConfig() }

// MicroControlConfig は旧93のmicro対照商品規格を返します。
//
// 引数: ありません。
// 返り値: ProductConfigは元の点価/量/費用です。
func MicroControlConfig() ProductConfig { return native.MicroControlConfig() }
