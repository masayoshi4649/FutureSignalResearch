package minisymmetric104

import (
	"fmt"
	"github.com/masayoshi4649/SessionTradeExecuter/internal/rules"
	"strings"
)

const RangeSideRuleID = "addon.entry.range_side"
const SymmetricRangeSideExpression = "efficiency <= 0.3 ? ((mid <= low + 0.1 * risk) == (mid >= high - 0.1 * risk) ? 0.0 : (mid <= low + 0.1 * risk ? 1.0 : -1.0)) : 0.0"

// DefaultRuleExpressions は対象profileの既定全式を独立複写します。
//
// 引数: method(string)、session(Session)は元三手法名と場種です。
// 返り値: map[string]string/errorは完全式map又は場種/手法不整合です。
func DefaultRuleExpressions(method string, session Session) (map[string]string, error) {
	short := strings.TrimPrefix(method, "NK225_")
	if short != "D164_15" && short != "P164_06" && short != "U165_03" {
		return nil, fmt.Errorf("対象は元の選定三手法だけです")
	}
	profile, err := rules.SelectProfile("NK225", session.Kind, short)
	if err != nil {
		return nil, err
	}
	set, err := rules.DefaultFor(profile)
	if err != nil {
		return nil, err
	}
	return set.Expressions(), nil
}

// SymmetricRuleExpressions は既定の全式copyの重複方向1式だけを置き換えます。
//
// 引数: method(string)、session(Session)は元手法と場種です。
// 返り値: map[string]string/errorは全式map又は手法不整合です。
func SymmetricRuleExpressions(method string, session Session) (map[string]string, error) {
	expressions, err := DefaultRuleExpressions(method, session)
	if err != nil {
		return nil, err
	}
	expressions[RangeSideRuleID] = SymmetricRangeSideExpression
	return expressions, nil
}

// prepareRuleExpressions は非空mapを型検査し所有を分離します。
//
// 引数: method(string)、session(Session)、expressions(map[string]string)は手法・場・完全overrideです。
// 返り値: map[string]string/errorは独立map又は欠落/型/式破損です。空overrideは旧nilを保持します。
func prepareRuleExpressions(method string, session Session, expressions map[string]string) (map[string]string, error) {
	if len(expressions) == 0 {
		return nil, nil
	}
	profile, err := rules.SelectProfile("NK225", session.Kind, method)
	if err != nil {
		return nil, err
	}
	set, err := rules.CompileFor(profile, expressions)
	if err != nil {
		return nil, err
	}
	return set.Expressions(), nil
}
