// Package sourceclock104 は新Source公開記録だけを旧Scalarと判断時計へ結びます。
package sourceclock104

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"reflect"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	actual "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
)

// SourceRecord は停止CLI record.goのJSON公開型をそのまま受けます。
// main packageはimportできないため、consumer側の型を明示します。
type SourceRecord struct {
	Ordinal        int               `json:"ordinal"`
	Session        string            `json:"session"`
	Kind           string            `json:"kind"`
	Method         string            `json:"method"`
	Product        string            `json:"product"`
	Scalar         *tape.ScalarQuote `json:"scalar,omitempty"`
	ObservationSHA string            `json:"observation_sha256,omitempty"`
	Delta          native.StepResult `json:"delta"`
	Error          string            `json:"error,omitempty"`
}

// Proof は結合範囲をSource形成・金融成功から分離します。
type Proof struct {
	ModeDeclared          string `json:"mode_declared"`
	InputTapeSHA          string `json:"input_tape_canonical_sha256"`
	RecordsSHA            string `json:"records_canonical_sha256"`
	Calls                 int    `json:"calls"`
	MiniCalls             int    `json:"mini_calls"`
	MicroCalls            int    `json:"micro_calls"`
	ScalarMatches         int    `json:"scalar_matches"`
	Grids                 int    `json:"grids"`
	NotificationsEqualOld bool   `json:"notifications_equal_old"`
	SourceFormedHere      bool   `json:"source_formed_here"`
	FinancialExecutedHere bool   `json:"financial_executed_here"`
}

// clone はnil/空・map・sliceを保って公開値を深く複写します。
//
// 引数: v(reflect.Value)は公開Tape/SourceRecordの一値です。
// 返り値: reflect.Value/errorは独立copy又は非公開/非対応型です。
func clone(v reflect.Value) (reflect.Value, error) {
	switch v.Kind() {
	case reflect.Pointer:
		if v.IsNil() {
			return reflect.Zero(v.Type()), nil
		}
		x, e := clone(v.Elem())
		if e != nil {
			return reflect.Value{}, e
		}
		out := reflect.New(v.Type().Elem())
		out.Elem().Set(x)
		return out, nil
	case reflect.Slice:
		if v.IsNil() {
			return reflect.Zero(v.Type()), nil
		}
		out := reflect.MakeSlice(v.Type(), v.Len(), v.Len())
		for i := 0; i < v.Len(); i++ {
			x, e := clone(v.Index(i))
			if e != nil {
				return reflect.Value{}, e
			}
			out.Index(i).Set(x)
		}
		return out, nil
	case reflect.Map:
		if v.IsNil() {
			return reflect.Zero(v.Type()), nil
		}
		out := reflect.MakeMapWithSize(v.Type(), v.Len())
		it := v.MapRange()
		for it.Next() {
			x, e := clone(it.Value())
			if e != nil {
				return reflect.Value{}, e
			}
			out.SetMapIndex(it.Key(), x)
		}
		return out, nil
	case reflect.Struct:
		out := reflect.New(v.Type()).Elem()
		for i := 0; i < v.NumField(); i++ {
			if !v.Field(i).CanInterface() {
				return reflect.Value{}, fmt.Errorf("非公開型のcopy不可")
			}
			x, e := clone(v.Field(i))
			if e != nil {
				return reflect.Value{}, e
			}
			out.Field(i).Set(x)
		}
		return out, nil
	case reflect.Array:
		out := reflect.New(v.Type()).Elem()
		for i := 0; i < v.Len(); i++ {
			x, e := clone(v.Index(i))
			if e != nil {
				return reflect.Value{}, e
			}
			out.Index(i).Set(x)
		}
		return out, nil
	case reflect.Bool, reflect.String, reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64, reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64, reflect.Float32, reflect.Float64:
		return v, nil
	default:
		return reflect.Value{}, fmt.Errorf("未対応の公開型:%s", v.Kind())
	}
}

// shaJSON は公開全値のcanonicalではなくGo JSON同順の指紋を得ます。
//
// 引数: v(any)は公開Tape又は全記録です。
// 返り値: string/errorはJSON SHA又は非有限値等です。
func shaJSON(v any) (string, error) {
	b, e := json.Marshal(v)
	if e != nil {
		return "", e
	}
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:]), nil
}

// Bind は全記録を順番に消費し、mini Deltaだけを新Tapeへ結びます。
//
// 引数: old(tape.Tape)、records([]SourceRecord)、mode(string)は固定旧時計・上流全記録・宣言modeです。
// 返り値: tape.Tape/Proof/errorは新入力と結合証拠です。Source/金融は実行しません。
func Bind(old tape.Tape, records []SourceRecord, mode string) (tape.Tape, Proof, error) {
	p := Proof{ModeDeclared: mode, NotificationsEqualOld: true}
	fail := func(e error) (tape.Tape, Proof, error) { return tape.Tape{}, p, e }
	if old.Version != 1 || old.Scope == "" || !reflect.DeepEqual(old.Capabilities, tape.Capabilities()) || (mode != "legacy" && mode != "default" && mode != "symmetric") {
		return fail(fmt.Errorf("入力版/mode不一致"))
	}
	var e error
	p.InputTapeSHA, e = shaJSON(old)
	if e != nil {
		return fail(e)
	}
	p.RecordsSHA, e = shaJSON(records)
	if e != nil {
		return fail(e)
	}
	v, e := clone(reflect.ValueOf(old))
	if e != nil {
		return fail(e)
	}
	out := v.Interface().(tape.Tape)
	last := map[string]int64{}
	oldLast := map[string]int64{}
	cursor := 0
	lastAt := 0.0
	lastPriority := -1
	for i, event := range old.Events {
		priority := 2
		if event.Kind == "force" {
			priority = 0
		} else if event.Kind == "grid" {
			priority = 1
		} else if event.Kind != "quote" {
			return fail(fmt.Errorf("未知Tape種別"))
		}
		if event.Ordinal != i+1 || event.At < lastAt || event.At == lastAt && priority < lastPriority {
			return fail(fmt.Errorf("Tapeのordinal/同時計位相不正"))
		}
		lastAt, lastPriority = event.At, priority
		if event.Kind == "grid" {
			if event.Quote != nil || len(event.Methods) > 0 || len(event.NonEmpty) > 0 {
				return fail(fmt.Errorf("gridへSource通知混入"))
			}
			p.Grids++
			continue
		}
		if len(event.Methods) == 0 {
			return fail(fmt.Errorf("active手法順欠落"))
		}
		if event.Kind == "quote" && (event.Quote == nil || event.Quote.Time != event.At) {
			return fail(fmt.Errorf("旧quote時計欠落"))
		}
		if event.Kind == "force" && event.Quote != nil {
			return fail(fmt.Errorf("Forceへ架空quote"))
		}
		baseline, e := tape.RestoreBatches(event, oldLast)
		if e != nil {
			return fail(e)
		}
		batches := []actual.NativeBatch{}
		seen := map[string]bool{}
		for _, method := range event.Methods {
			if seen[method] {
				return fail(fmt.Errorf("active手法重複"))
			}
			seen[method] = true
			for _, product := range []string{"NK225micro", "NK225mini"} {
				if cursor >= len(records) {
					return fail(fmt.Errorf("SourceRecord不足 event%d/%s/%s", event.Ordinal, method, product))
				}
				r := records[cursor]
				cursor++
				p.Calls++
				if r.Ordinal != cursor || r.Session != old.Session.ID || r.Method != method || r.Product != product || r.Kind != event.Kind || r.Error != "" {
					return fail(fmt.Errorf("全記録順/出典不一致 record%d", cursor))
				}
				origin := "timer"
				key := product + "/" + method
				if event.Kind == "quote" {
					origin = "quote"
					h, x := hex.DecodeString(r.ObservationSHA)
					if x != nil || len(h) != 32 || r.Scalar == nil || !reflect.DeepEqual(*r.Scalar, *event.Quote) {
						return fail(fmt.Errorf("fresh Scalar11/Observation出典不一致 record%d", cursor))
					}
					last[key] = r.Scalar.SourceLine
					p.ScalarMatches++
				} else if r.Scalar != nil || r.ObservationSHA != "" {
					return fail(fmt.Errorf("ForceへObservation/Scalar混入"))
				}
				if r.Delta.At != event.At || r.Delta.Origin != origin || r.Delta.SourceLine != last[key] {
					return fail(fmt.Errorf("Delta時計/位相/直前物理行不一致 record%d", cursor))
				}
				if product == "NK225micro" {
					p.MicroCalls++
					continue
				}
				p.MiniCalls++
				x, e := clone(reflect.ValueOf(r.Delta))
				if e != nil {
					return fail(e)
				}
				batches = append(batches, actual.NativeBatch{Method: method, Delta: x.Interface().(native.StepResult)})
			}
		}
		left, _ := json.Marshal(baseline)
		right, _ := json.Marshal(batches)
		if string(left) != string(right) {
			p.NotificationsEqualOld = false
			if mode != "symmetric" {
				return fail(fmt.Errorf("legacy/defaultの公開通知全文差 event%d", event.Ordinal))
			}
		}
		// ----------------------------------------
		// Closesだけの通知も非空へ残し、Targets/Beforeを一切再構成しない。
		out.Events[i].NonEmpty = []actual.NativeBatch{}
		for _, b := range batches {
			d := b.Delta
			if len(d.Signals)+len(d.Fills)+len(d.Cancellations)+len(d.Closes) > 0 {
				out.Events[i].NonEmpty = append(out.Events[i].NonEmpty, b)
			}
		}
		checkLast := map[string]int64{}
		for _, m := range event.Methods {
			checkLast[m] = last["NK225mini/"+m]
		}
		restored, e := tape.RestoreBatches(out.Events[i], checkLast)
		if e != nil {
			return fail(e)
		}
		a, _ := json.Marshal(restored)
		if string(a) != string(right) {
			return fail(fmt.Errorf("新Tapeの全通知往復差 event%d", event.Ordinal))
		}
	}
	if cursor != len(records) {
		return fail(fmt.Errorf("余剰SourceRecord:%d", len(records)-cursor))
	}
	out.Scope = "104の新Source公開記録を旧Scalar11/全board判断時計へ結合。Source形成は上流、金融103 Gate無し専用"
	out.Provenance = map[string]string{"input_tape_canonical_sha256": p.InputTapeSHA, "source_records_json_sha256": p.RecordsSHA, "source_mode_declared": mode, "scope": "旧Provenanceは再利用しない。上流成功/入力fileSHAは市場wrapperで別固定"}
	return out, p, nil
}
