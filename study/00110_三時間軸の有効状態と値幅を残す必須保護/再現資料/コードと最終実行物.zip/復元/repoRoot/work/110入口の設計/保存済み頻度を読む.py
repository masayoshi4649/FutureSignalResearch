"""109の固定済み頻度CSVだけから110設計の出発点を取り出す。"""

import csv
import hashlib
import json
from pathlib import Path


def 読む(path: Path) -> list[dict[str, str]]:
    """機能: CSVの列名とUTF-8を維持して読む。

    引数: path(Path)は既使用109の固定CSV。
    返り値: list[dict[str, str]]は全行の独立した辞書。
    """
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def 指紋(path: Path) -> dict[str, object]:
    """機能: 読み取る小集計資料の指紋を作る。

    引数: path(Path)は既使用の集計CSV又は小JSON。
    返り値: dict[str, object]は絶対参照・サイズ・SHA256。
    """
    data = path.read_bytes()
    return {"path": str(path.resolve()), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def 主行(rows: list[dict[str, str]]) -> list[dict[str, str]]:
    """機能: 全体・主分母の保存集計行だけを選ぶ。

    引数: rows(list[dict[str, str]])は既存CSVの全行。
    返り値: list[dict[str, str]]は全体の主枠に限定した行。
    """
    return [row for row in rows if row.get("区分") == "全体" and row.get("分母") == "主"]


def main() -> None:
    """機能: 既存の集計値を照合し、小JSONへ保存する。

    引数: なし。入力は固定済み109集計フォルダだけ。
    返り値: None。新E2の数値、金融、原板、11/09は読み取らない。
    """
    root = Path(__file__).resolve().parents[2]
    source = root / "work/109頻度集計/全70場"
    names = ["場別の技法成立頻度.csv", "日夜と時系列の頻度.csv", "理由別.csv", "論理群別.csv", "構造段階別.csv", "経路の累積条件別.csv", "Source予定枠の重なり.csv", "出生と予定取得時計.csv"]
    proof = [指紋(source / name) for name in names]
    summary_path = source / "独立集計.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    total = summary["totals"]["primary"]
    assert total["planned"] == 7980 and total["observed"] == 7980
    assert total["technical_candidates"] == 15960 and total["source_candidates"] == 558
    assert total["technical_known"] == 12928 and total["source_known"] == 475
    assert total["technical_allowed"] == 46 and total["source_allowed"] == 3

    # ----------------------------------------
    # 一段ずつの累積と、短絡順に依存しない保存済み論理群を分ける。
    funnels = [row for row in 主行(読む(source / "経路の累積条件別.csv")) if row["累積状態"] in {"累積成立", "保存された経路ANDまで成立", "距離条件が残る"}]
    groups = [row for row in 主行(読む(source / "論理群別.csv")) if row["論理群"] in {"trend_momentum", "reversal_momentum", "spike"}]
    structures = [row for row in 主行(読む(source / "構造段階別.csv")) if row["段階"] in {"確認済み", "突破済み"}]
    result = {
        "用途": "110の仕様設計用。109の保存集計を再掲するだけで、新しい技法成立や利益は計算しない",
        "新E2実装": False,
        "市場再走": False,
        "金融実行": False,
        "原板追加読取": False,
        "未使用11月09日読取又はhash": False,
        "分母": {"主grid": 7980, "全買売候補": 15960, "Source予定候補": 558, "技術成立と実参加率は別": True},
        "最終集計": total,
        "共通可用性と最終Knownの差": {
            "全買売": {"共通可用": 12994, "後段15分勢い未知": 66, "最終Known": 12928},
            "Source予定": {"共通可用": 479, "後段15分勢い未知": 4, "最終Known": 475},
            "定義": "common通過を最終Knownとは呼ばない。必要な15分勢い履歴が未知なら経路の不成立より未知を優先する109の保存値",
        },
        "保存済み経路の累積": funnels,
        "保存済み勢いとspikeの並列群": groups,
        "保存済み確認段階": structures,
        "限界": ["累積の代表理由は短絡順であり唯一の失敗原因ではない", "確認段階だけの件数は現在も有効なE2状態の件数ではない", "ATRなど保存されない指標の実値を逆算しない", "Source予定は金融適格前であり、未取得Sourceの後続枠保持は未検証", "新E2の成立数・参加率・収支は未算出"],
        "入力": proof + [指紋(summary_path)],
    }
    out = Path(__file__).with_name("既存109の頻度の要点.json")
    out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "出力": str(out), "参照CSV": len(names), "主枠": total["planned"], "金融実行": False}, ensure_ascii=False))


if __name__ == "__main__":
    main()
