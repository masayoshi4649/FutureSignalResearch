// Package followup は新4場の未固定接続口だけを準備し、市場CLIを持ちません。
package followup

import (
	"bytes"
	"encoding/json"
	"fmt"
	"math"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	replay "github.com/masayoshi4649/SessionTradeExecuter/minisourcereplay104"
	binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
)

// CandidateIDs は使用歴metadata監査に限定した未固定候補の4IDを返します。
//
// 引数: なし。
// 返り値: []stringは時系列順の候補で、市場使用の許可ではありません。
func CandidateIDs() []string {
	return []string{"2026-11-05_Day", "2026-11-05_Night", "2026-11-06_Day", "2026-11-06_Night"}
}

// ClockCarrier はRaw読取前の新規予定時計だけを持つcarrierを作ります。
//
// 引数: id(string)は候補4場のIDです。
// 返り値: tape.Tape/errorは予定全gridだけ又は対象外です。価格/Source/Capabilitiesは空です。
func ClockCarrier(id string) (tape.Tape, error) {
	allowed := false
	for _, candidate := range CandidateIDs() {
		allowed = allowed || candidate == id
	}
	if !allowed {
		return tape.Tape{}, fmt.Errorf("未固定候補4場の外")
	}
	s, err := SessionClock(id)
	if err != nil {
		return tape.Tape{}, err
	}
	t := tape.Tape{Version: 1, Session: s, Scope: "新4場の予定時計carrierのみ。Source通知/金融Tapeではなく旧54Tapeの流用でもない", Events: []tape.TapeEvent{}}
	for at := s.Start; at < s.End; at += 300 {
		t.Events = append(t.Events, tape.TapeEvent{Ordinal: len(t.Events) + 1, Kind: "grid", At: at})
	}
	return t, nil
}

// LoadFreshRequest は将来固定した新入力を既存readerへ渡す最小口です。
//
// 引数: input(continuous.InputSession)、root(string)は将来Rootが固定する6入力と根です。
// 返り値: Request/品質/errorは新規全board/candle/予定gridです。呼ぶとRaw/CSVを読むため今回は未実行です。
func LoadFreshRequest(input continuous.InputSession, root string) (continuous.Request, map[string]continuous.RawQuality, error) {
	carrier, err := ClockCarrier(input.ID)
	if err != nil {
		return continuous.Request{}, nil, err
	}
	return continuous.LoadRequest(input, root, carrier)
}

// ObservedGridPrefix は全boardの上限までに実在する予定枠だけを選びます。
//
// 引数: req(continuous.Request)はLoadFreshRequestの全両市場行であり、正NK行だけへ絞らない入力です。
// 返り値: []float64/errorはEOF以前のgrid又は時計不正です。Source/金融は呼びません。
func ObservedGridPrefix(req continuous.Request) ([]float64, error) {
	carrier, err := ClockCarrier(req.Session.ID)
	if err != nil || carrier.Session != req.Session {
		return nil, fmt.Errorf("新規場時計と全board requestが不一致")
	}
	limit := req.Session.Start - 1
	for _, row := range req.Rows {
		b := row.Board
		if (b.Reference != "NK225" && b.Reference != "TOPIX") || math.IsNaN(b.Time) || math.IsInf(b.Time, 0) || b.Time < req.Session.Start || b.Time >= req.Session.End || b.Received != b.Time || row.PhysicalLine <= 0 {
			return nil, fmt.Errorf("全boardの時計/市場/原行が不正")
		}
		limit = math.Max(limit, b.Time)
	}
	grids := []float64{}
	for _, g := range carrier.Events {
		if g.At <= limit {
			grids = append(grids, g.At)
		}
	}
	return grids, nil
}

// CompareLegacyDefault は新4場で得た2経路の全文相互同値だけを検査します。
//
// 引数: legacy/defaultResult(replay.ReplayResult)、legacy/defaultRecords([]binder.SourceRecord)は将来の全出力です。
// 返り値: errorは全field差です。旧93golden照合や技法・利益の妥当性の証明にはしません。
func CompareLegacyDefault(legacy, defaultResult replay.ReplayResult, legacyRecords, defaultRecords []binder.SourceRecord) error {
	if legacy.Session == "" || legacy.Session != defaultResult.Session || len(legacyRecords) == 0 || len(defaultRecords) == 0 {
		return fmt.Errorf("新場の全出力が必要")
	}
	left, err := json.Marshal(struct {
		Result  replay.ReplayResult
		Records []binder.SourceRecord
	}{legacy, legacyRecords})
	if err != nil {
		return err
	}
	right, err := json.Marshal(struct {
		Result  replay.ReplayResult
		Records []binder.SourceRecord
	}{defaultResult, defaultRecords})
	if err != nil {
		return err
	}
	if !bytes.Equal(left, right) {
		return fmt.Errorf("legacy/defaultの全Result/Recordが不一致")
	}
	return nil
}
