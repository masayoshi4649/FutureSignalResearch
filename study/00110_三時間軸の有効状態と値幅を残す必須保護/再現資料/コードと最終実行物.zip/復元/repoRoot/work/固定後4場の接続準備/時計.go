// SessionClockは停止104の汎用時計を名前/USOpen資格だけ変えた機械派生です。
package followup

import (
	"fmt"
	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	"strings"
	"time"
	_ "time/tzdata"
)

// SessionClockは場IDから同じ元セッション時計を作ります。
//
// 引数: id(string)は場IDです。
// 返り値: strategy.Session/errorは旧と同じForce/US時計又は不正です。
func SessionClock(id string) (strategy.Session, error) {
	parts := strings.Split(id, "_")
	if len(parts) != 2 {
		return strategy.Session{}, fmt.Errorf("場ID不正:%s", id)
	}
	zone, e := time.LoadLocation("Asia/Tokyo")
	if e != nil {
		return strategy.Session{}, e
	}
	day, e := time.ParseInLocation("2006-01-02", parts[0], zone)
	if e != nil {
		return strategy.Session{}, e
	}
	start, end := day.Add(8*time.Hour+45*time.Minute), day.Add(15*time.Hour+45*time.Minute)
	if parts[1] == "Night" {
		start = day.Add(17 * time.Hour)
		end = day.AddDate(0, 0, 1).Add(6 * time.Hour)
	} else if parts[1] != "Day" {
		return strategy.Session{}, fmt.Errorf("場種不正")
	}
	us, e := native.USOpen(parts[0])
	if e != nil {
		return strategy.Session{}, e
	}
	extraAt := float64(start.Add(225 * time.Minute).Unix())
	if parts[1] == "Night" {
		extraAt = us + 1800
	} else {
		us = 0
	}
	return strategy.Session{ID: id, Kind: parts[1], Start: float64(start.Unix()), End: float64(end.Unix()), ForceClose: float64(end.Add(-10 * time.Minute).Unix()), USOpen: us, ExtraAt: extraAt, NightCoreStart: 0}, nil
}
