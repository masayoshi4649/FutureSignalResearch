package profitfloor110

import (
	"fmt"
	"math"
	"sort"
)

// Bar は外部で確定・公表された1本の3分足です。中央値の小関数は足を形成しません。
type Bar struct {
	Scope       Scope   `json:"scope"`
	ID          string  `json:"id"`
	Start       float64 `json:"start"`
	End         float64 `json:"end"`
	AvailableAt float64 `json:"available_at"`
	Known       bool    `json:"known"`
	High        float64 `json:"high"`
	Low         float64 `json:"low"`
}

// MedianRange5 は5本の連続した既知3分足の足内値幅中央値を計算します。
//
// 引数: scope(Scope)、bars([]Bar)、at(float64)は対象場・最大5本・利用時計。
// 返り値: *Evidence/errorは公表済みV、不足/不良/跨場/欠足ならnil、未来又は破損ならerrorです。
func MedianRange5(scope Scope, bars []Bar, at float64) (*Evidence, error) {
	if !validScope(scope) || !finite(at) || at < scope.Start || len(bars) > 5 {
		return nil, fmt.Errorf("中央値の場・時計又は本数が不正")
	}
	known := len(bars) == 5
	values := make([]float64, 0, len(bars))
	ids := map[string]bool{}
	available := scope.Start
	for i, b := range bars {
		if !validScope(b.Scope) || b.ID == "" || ids[b.ID] || !finite(b.Start, b.End, b.AvailableAt, b.High, b.Low) ||
			b.Start < b.Scope.Start || b.End != b.Start+180 || math.Mod(b.End-b.Scope.Start, 180) != 0 ||
			b.AvailableAt < b.End || b.AvailableAt > at || b.High < 0 || b.Low < 0 || b.High < b.Low {
			return nil, fmt.Errorf("中央値足の識別・時計・価格が不正")
		}
		ids[b.ID] = true
		known = known && b.Known && b.Scope == scope
		if b.Known && (!validPrice(b.High) || !validPrice(b.Low)) {
			return nil, fmt.Errorf("既知足の価格が不正")
		}
		if i > 0 && b.End != bars[i-1].End+180 {
			known = false
		}
		available = math.Max(available, b.AvailableAt)
		values = append(values, b.High-b.Low)
	}
	if !known {
		return nil, nil
	}
	sort.Float64s(values)
	value := math.Max(5, values[2])
	if !finite(value, 2*value) {
		return nil, fmt.Errorf("中央値の導出値が非有限")
	}
	return &Evidence{Value: value, AvailableAt: available, SourceID: "V5/" + bars[4].ID}, nil
}
