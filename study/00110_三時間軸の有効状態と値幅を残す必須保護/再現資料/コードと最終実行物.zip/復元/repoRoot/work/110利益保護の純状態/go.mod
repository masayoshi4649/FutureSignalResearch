module github.com/masayoshi4649/SessionTradeExecuter/profitfloor110

go 1.24.2
