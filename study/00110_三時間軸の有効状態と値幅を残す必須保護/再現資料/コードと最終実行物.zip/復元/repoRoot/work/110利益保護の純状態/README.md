# 110：値幅を待つ必須保護の純状態

module/importは`github.com/masayoshi4649/SessionTradeExecuter/profitfloor110`、packageは`profitfloor110`。Root承認のoneV半A/G3、一A/G4を実装した。**金融Actor・Source・市場入力には未接続、未金融**。原板・CSV・SourceRecord・11/09は読まない。

109停止済み`work/一定利益と費用床の純状態案`から派生し、元ファイルを変更しない。G1/G2の数値・判定は従来どおり残すが、新Snapshotには既知性と固定根拠を追加した。旧G0の完全同体対照はこの部品で近似せず、Actorが旧分岐を通して別に確認する。

仕様は[設計](../110利益保護の設計/利益保護の仕様案.md)と[仕様](仕様.md)。Root案の36会計は外側のE0L0/E2L0/E2L1との組合せであり、この部品が入口や受付寿命を決めることはない。

## API

- `NewState(Entry) (State,error)`：新規時のVと既知ATRからG3/G4のHを一度固定。ATR不明は`ThresholdKnown=false`。
- `Advance(State,Input) (State,Decision,error)`：最初の既知ATRでHを一度固定し、現在の費用後利益だけで必須起動。予約量を控除した条件上の返済可能量を返す。
- `Snapshot() Snapshot`：独立複写。既存`ThresholdPoints float64`は`ThresholdKnown=false`の間だけ0。未知0を既知の起動額と読まない。
- `Snapshot.ThresholdLock *ThresholdLock110`：固定時計、α、A、V/代替、費用・最低床、式の各成分と支配成分、丸め前/後H。
- `Decision.ThresholdLockedNow bool`：この入力でHが確定したこと。起動とは別。
- 既存の`MedianRange5`、`Warning`、`ActivationEligible`のsignatureは維持する。

費用後円/枚は`100*(s*(返済側BBO−実新規価格)−K)`。K=0.77+2S、Fmin=ceil5(K+5)、H=ceil5(max(20,2K,αA_lock,Fmin+B−K))。αはG3=.5/G4=1、Bは既知ならV_entry、未知なら未丸めA_lock。部分残枚数でHを変えない。

A後判明で過去peakだけを使って起動しない。H確定以後の現在額で到達する必要がある。peak自体は109同様に保持するため、後で起動したとき既存peak又は構造床が現在値を超え、同原行で床hitとなる場合がある。純Decisionは注文ではなく、同原行約定を許可する意味でもない。

起動後の通常/狭幅、三値`M AND (C OR P)`、その時点で警戒真の適格構造床、非緩和は109G2と同じ。公表の形成や窓の配送、native ATRの出典と時刻を外部保存に照合すること、Source返済優先、実予約、D0/D1、Force/EOF・持越0は外側Actor/保存器が確認する。

## 人工検査

Goの標準ライブラリだけを用いる。`python -B -X utf8 検査と停止を記録する.py`がtest/vet/buildと入力/旧停止物の指紋不変を記録する。検査成功は式・状態の証明範囲であり、収益改善や実約定の確認ではない。

新規A・V・費用が各々支配する境界、5pt格子、売買鏡像、未知A/最初のA/H固定、未丸めA代替、価格未知、部分/全予約、非緩和、構造床と現在警戒、過去peakでの遡及起動禁止、Snapshotの独立複写を人工検査する。旧G1/G2と窓形成のテストも維持する。
