package profitfloor110

import (
	"math"
	"reflect"
	"testing"
)

// Test110ThresholdComponents は半A・一A・通常値幅・費用の独立した境界を検査します。
//
// 引数: t(*testing.T)は人工検査器。返り値: ありません。
func Test110ThresholdComponents(t *testing.T) {
	for _, row := range []struct {
		a, v, slip, half, full, budget float64
		unknownV                       bool
	}{
		{200, 20, 0, 100, 200, 20, false},
		{200, 20, 5, 100, 200, 20, false},
		{40, 80, 0, 90, 90, 80, false},
		{1, 5, 0, 20, 20, 5, false},
		{1, 5, 5, 25, 25, 5, false},
		{40.25, 0, 0, 50, 50, 40.25, true},
	} {
		for _, policy := range []Policy{G3, G4} {
			for _, side := range []int{-1, 1} {
				e := fixture(policy, side, row.slip)
				e.ATR.Value = row.a
				if row.unknownV {
					e.EntryV = nil
				} else {
					e.EntryV.Value = row.v
				}
				s := mustNew(t, e)
				x := s.Snapshot()
				want, alpha := row.half, .5
				if policy == G4 {
					want, alpha = row.full, 1
				}
				if !x.ThresholdKnown || x.ThresholdPoints != want || x.ThresholdLock == nil || x.ThresholdLock.At != e.At || x.ThresholdLock.Alpha != alpha || x.ThresholdLock.NoiseBudgetPoints != row.budget || x.ThresholdLock.VFallback != row.unknownV {
					t.Fatalf("H成分又は未知Vの未丸めA代替: %+v", x)
				}
				below := 5 * math.Floor((want+x.CostPoints)/5)
				if below >= want+x.CostPoints {
					below -= 5
				}
				s, d := advance(t, s, step(s, 1, 2801, below))
				if d.ActivatedNow || s.active {
					t.Fatal("費用後H直前の5pt格子で起動")
				}
				s, d = advance(t, s, step(s, 2, 2802, below+5))
				if !d.ActivatedNow || !s.active || *d.GainPoints-s.minimum < row.budget || *d.UnitNetYen < 100*want {
					t.Fatal("到達必須起動又は最低床に対する1V余裕")
				}
				if d.Warning != Unknown {
					t.Fatal("警戒不明を起動の条件へ変えた")
				}
			}
		}
	}
}

// Test110UnknownATRAndNoRetroactiveActivation は未知ATRと後判明の因果を検査します。
//
// 引数: t(*testing.T)は人工検査器。返り値: ありません。
func Test110UnknownATRAndNoRetroactiveActivation(t *testing.T) {
	for _, policy := range []Policy{G3, G4} {
		for _, side := range []int{-1, 1} {
			e := fixture(policy, side, 0)
			e.ATR = nil
			s := mustNew(t, e)
			if s.Snapshot().ThresholdKnown || s.threshold != 0 || s.thresholdLock != nil {
				t.Fatal("A未知をH20へ補完")
			}
			s, d := advance(t, s, step(s, 1, 2801, 400))
			if s.active || d.ActivatedNow || d.ThresholdLockedNow {
				t.Fatal("A未知で過去益により起動")
			}
			in := step(s, 2, 2802, 30)
			in.ATR = &Evidence{100, 2802, "人工初回既知A"}
			s, d = advance(t, s, in)
			if !d.ThresholdLockedNow || !s.thresholdKnown || s.active || s.thresholdLock.At != 2802 || s.entry.ATR != nil || s.thresholdLock.EntryV.Value != 80 {
				t.Fatal("初回Aで固定又は現在利益だけの判定に失敗")
			}
			if *s.peak != 400 {
				t.Fatal("既存peakを無断で切り捨て")
			}
			in = step(s, 3, 2803, 105)
			s, d = advance(t, s, in)
			if !s.active || !d.ActivatedNow || d.ThresholdLockedNow || s.thresholdLock.At != 2802 || !d.FloorHit {
				t.Fatal("後の現在到達又は既存peak床の同原行hit反例")
			}
			if d.EligibleExitQuantity != 7 || *s.floor <= 105 {
				t.Fatal("最低床余裕を実床余裕と誤同一視")
			}
			in = step(s, 4, 2804, 105)
			in.ATR = &Evidence{101, 2802, "人工初回既知A"}
			if _, _, err := Advance(s, in); err == nil {
				t.Fatal("確定AとHの変更を許した")
			}
		}
	}
}

// Test110FirstKnownWithoutMark は価格未知時のH固定と終了後の非固定を検査します。
//
// 引数: t(*testing.T)は人工検査器。返り値: ありません。
func Test110FirstKnownWithoutMark(t *testing.T) {
	e := fixture(G3, 1, 0)
	e.ATR, e.EntryV = nil, nil
	s := mustNew(t, e)
	in := step(s, 1, 2801, 100)
	in.Mark = nil
	in.ATR = &Evidence{40.25, 2801, "人工A"}
	s, d := advance(t, s, in)
	if !s.thresholdKnown || !d.ThresholdLockedNow || s.threshold != 50 || s.active || d.UnitNetYen != nil || s.thresholdLock.NoiseBudgetPoints != 40.25 {
		t.Fatal("Mark不明のH固定又はV代替が違う")
	}
	in = step(s, 2, 2980, 55)
	in.Publication = publication(s, 1, 2980, 500, False, False)
	s, d = advance(t, s, in)
	if !s.active || !d.ActivatedNow || s.threshold != 50 || s.thresholdLock.EntryV != nil || s.thresholdLock.NoiseBudgetPoints != 40.25 {
		t.Fatal("後判明VでH又は代替理由が変化")
	}
	e.ATR = nil
	closed := mustNew(t, e)
	in = step(closed, 1, 2801, 100)
	in.Remaining = 0
	closed, _ = advance(t, closed, in)
	if !closed.finished || closed.thresholdKnown || closed.thresholdLock != nil {
		t.Fatal("閉鎖済み未知A玉のHを捏造")
	}
}

// Test110WidthReservationAndMonotone は可変幅・Source予約・部分残玉の意味を検査します。
//
// 引数: t(*testing.T)は人工検査器。返り値: ありません。
func Test110WidthReservationAndMonotone(t *testing.T) {
	for _, policy := range []Policy{G3, G4} {
		for _, side := range []int{-1, 1} {
			s := mustNew(t, fixture(policy, side, 0))
			in := step(s, 1, 2980, 200)
			in.Publication = publication(s, 1, 2980, 80, False, False)
			s, _ = advance(t, s, in)
			if *s.width != 160 || *s.floor != 40 {
				t.Fatal("G2通常2V幅を継承していない")
			}
			in = step(s, 2, 3160, 200)
			in.Publication = publication(s, 2, 3160, 20, True, True)
			s, d := advance(t, s, in)
			if !s.narrowed || !d.NarrowedNow || *s.width != 20 || *s.floor != 180 {
				t.Fatal("複合収束/失速で狭幅化しない")
			}
			beforeH, beforeLock := s.threshold, *s.thresholdLock
			in = step(s, 3, 3340, 175)
			in.Remaining, in.Reserved = 3, 3
			in.Publication = publication(s, 3, 3340, 500, False, False)
			s, d = advance(t, s, in)
			if *s.floor < 180 || !s.narrowed || !d.FloorHit || d.EligibleExitQuantity != 0 || s.threshold != beforeH || !reflect.DeepEqual(*s.thresholdLock, beforeLock) {
				t.Fatal("不利床緩和・予約二重化・部分返済H変更")
			}
			in = step(s, 4, 3341, 175)
			in.Remaining, in.Reserved, in.Phase = 3, 1, PreFill
			s, d = advance(t, s, in)
			if d.FreeQuantity != 2 || d.EligibleExitQuantity != 0 {
				t.Fatal("pre_fill段階の新返済を許可")
			}
			in = step(s, 5, 3341, 175)
			in.Reserved = 1
			_, d = advance(t, s, in)
			if d.EligibleExitQuantity != 2 {
				t.Fatal("Source先行予約後の自由数量が違う")
			}
		}
	}
}

// Test110InvalidAndSnapshotIsolation は新APIの不正値と根拠の独立複写を検査します。
//
// 引数: t(*testing.T)は人工検査器。返り値: ありません。
func Test110InvalidAndSnapshotIsolation(t *testing.T) {
	for _, bad := range []float64{math.NaN(), math.Inf(1), 0, -1} {
		e := fixture(G3, 1, 0)
		e.ATR.Value = bad
		if _, err := NewState(e); err == nil {
			t.Fatal("不正Aを受理")
		}
	}
	e := fixture(G4, 1, 0)
	s := mustNew(t, e)
	x := s.Snapshot()
	x.ThresholdLock.EntryV.Value = 999
	x.ThresholdLock.DominantTerms[0] = "書換"
	x.ThresholdLock.ATR.Value = 999
	if reflect.DeepEqual(x, s.Snapshot()) || s.thresholdLock.EntryV.Value != 80 || s.thresholdLock.ATR.Value != 100 {
		t.Fatal("監査Snapshotから内部根拠を書換")
	}
	e.ATR = nil
	s = mustNew(t, e)
	in := step(s, 1, 2801, 500)
	in.ATR = &Evidence{40, 2802, "未来A"}
	before := s.Snapshot()
	if _, _, err := Advance(s, in); err == nil || !reflect.DeepEqual(before, s.Snapshot()) {
		t.Fatal("未来A又は失敗の状態変化")
	}
}

// Test110StructureAndCurrentWarning は新政策の構造床と売買鏡像を検査します。
//
// 引数: t(*testing.T)は人工検査器。返り値: ありません。
func Test110StructureAndCurrentWarning(t *testing.T) {
	for _, policy := range []Policy{G3, G4} {
		for _, side := range []int{-1, 1} {
			e := fixture(policy, side, 0)
			e.ATR.Value = 500
			s := mustNew(t, e)
			in := step(s, 1, 3520, 600)
			in.Publication = publication(s, 1, 3520, 500, Unknown, True)
			kind := "low"
			if side < 0 {
				kind = "high"
			}
			in.Publication.Close = ptr(e.Price + float64(side)*300)
			in.Publication.PriorPivot = &Pivot{e.Scope, "人工確定pivot", kind, e.Price + float64(side)*350, 2980, 3340, 3340}
			s, d := advance(t, s, in)
			if !s.active || !s.narrowed || d.Warning != True || !d.StructuralEligible || *s.floor != 345 || *s.width != 500 {
				t.Fatal("G3/G4の事前構造又は符号対称性")
			}
			in = step(s, 2, 3700, 600)
			in.Publication = publication(s, 2, 3700, 1000, False, False)
			in.Publication.Close = ptr(e.Price + float64(side)*800)
			in.Publication.PriorPivot = &Pivot{e.Scope, "人工追加pivot", kind, e.Price + float64(side)*700, 3160, 3520, 3520}
			s, d = advance(t, s, in)
			if !s.narrowed || d.Warning != False || d.StructuralEligible || *s.floor != 345 {
				t.Fatal("現在警戒偽なのにlatched旗だけで構造床を追加")
			}
		}
	}
}
