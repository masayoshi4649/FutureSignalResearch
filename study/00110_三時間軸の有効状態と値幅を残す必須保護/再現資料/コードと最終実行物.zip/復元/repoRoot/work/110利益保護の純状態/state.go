package profitfloor110

import (
	"fmt"
	"math"
	"reflect"
)

// finite は全引数の有限性を確認します。
//
// 引数: values(...float64)は検査値。返り値: boolは全て有限なら真です。
func finite(values ...float64) bool {
	for _, value := range values {
		if math.IsNaN(value) || math.IsInf(value, 0) {
			return false
		}
	}
	return true
}

// copyPtr は値の独立したポインタを返します。
//
// 引数: value(*T)は値又はnil。返り値: *Tは独立した複写又はnilです。
func copyPtr[T any](value *T) *T {
	if value == nil {
		return nil
	}
	copy := *value
	return &copy
}

// ptr は値を独立したポインタにします。
//
// 引数: value(T)は任意の値。返り値: *Tはその値を指します。
func ptr[T any](value T) *T { return &value }

// clonePublication は外部公表を参照共有せず複写します。
//
// 引数: value(*Publication)は公表又はnil。返り値: *Publicationは独立値です。
func clonePublication(value *Publication) *Publication {
	copy := copyPtr(value)
	if copy != nil {
		copy.V, copy.Close, copy.PriorPivot = copyPtr(value.V), copyPtr(value.Close), copyPtr(value.PriorPivot)
	}
	return copy
}

// cloneState は純更新前のポインタ共有を除去します。
//
// 引数: state(State)は以前の状態。返り値: Stateは独立した状態です。
func cloneState(state State) State {
	s := state
	s.entry.EntryV, s.entry.ATR = copyPtr(state.entry.EntryV), copyPtr(state.entry.ATR)
	s.atr = copyPtr(state.atr)
	s.activatedAt, s.narrowedAt = copyPtr(state.activatedAt), copyPtr(state.narrowedAt)
	s.peak, s.floor, s.width = copyPtr(state.peak), copyPtr(state.floor), copyPtr(state.width)
	s.latest, s.lastPublication = clonePublication(state.latest), clonePublication(state.lastPublication)
	s.thresholdLock = copyPtr(state.thresholdLock)
	if s.thresholdLock != nil {
		s.thresholdLock.EntryV = copyPtr(state.thresholdLock.EntryV)
		s.thresholdLock.DominantTerms = append([]string(nil), state.thresholdLock.DominantTerms...)
	}
	return s
}

// Snapshot は外部記録用の独立複写を返します。
//
// 引数: receiver(State)は純状態。返り値: Snapshotは変更しても元状態へ影響しません。
func (state State) Snapshot() Snapshot {
	s := cloneState(state)
	return Snapshot{s.entry, s.cost, s.threshold, s.fee, s.minimum, s.entry.EntryV == nil, s.atr,
		s.active, s.activatedAt, s.narrowed, s.narrowedAt, s.peak, s.floor, s.width, s.latest,
		s.remaining, s.reserved, s.at, s.sequence, s.finished, s.thresholdKnown, s.thresholdLock}
}

// validScope は識別と開始時計の最小条件を確認します。
//
// 引数: scope(Scope)は場と限月。返り値: boolは識別と正の有限時計があれば真です。
func validScope(scope Scope) bool {
	return scope.Session != "" && scope.Contract != "" && finite(scope.Start) && scope.Start > 0
}

// validPrice はminiの5pt格子上にある正の価格だけを認めます。
//
// 引数: price(float64)は価格。返り値: boolは正・有限・5pt格子なら真です。
func validPrice(price float64) bool {
	return finite(price) && price > 0 && math.Mod(price, 5) == 0
}

// ceil5 は5pt刻みの有利側価格差へ切り上げます。
//
// 引数: value(float64)は価格差。返り値: float64は5pt格子の値です。利用側で有限性を検査します。
func ceil5(value float64) float64 { return 5 * math.Ceil(value/5) }

// validateEvidence は公開済みのATR又は足内値幅尺度を確認します。
//
// 引数: value(*Evidence)、scope(Scope)、at(float64)、minimum(float64)は値・場・利用時計・下限。
// 返り値: errorは不正又は未来の根拠です。nilの未知は正常です。
func validateEvidence(value *Evidence, scope Scope, at, minimum float64) error {
	if value == nil {
		return nil
	}
	if value.SourceID == "" || !finite(value.Value, value.AvailableAt, 2*value.Value) || value.Value <= 0 || value.Value < minimum || value.AvailableAt < scope.Start || value.AvailableAt > at {
		return fmt.Errorf("尺度の識別・値・公開時計が不正")
	}
	return nil
}

// Warning はM AND (C OR P)を三値論理で評価します。
//
// 引数: c/m/p(Truth)は収束・失速・構造否定。返り値: Truth/errorは警戒又は未知enumの拒否です。
func Warning(c, m, p Truth) (Truth, error) {
	if c > True || m > True || p > True {
		return Unknown, fmt.Errorf("三値の範囲外")
	}
	or := Unknown
	if c == True || p == True {
		or = True
	} else if c == False && p == False {
		or = False
	}
	if m == False || or == False {
		return False, nil
	}
	if m == True && or == True {
		return True, nil
	}
	return Unknown, nil
}

// ActivationEligible は費用後単位額の一定利益到達を判定します。
//
// 引数: unitNetYen/thresholdPoints(float64)は円毎枚とpt。返り値: bool/errorは同値を含む到達又は不正です。
func ActivationEligible(unitNetYen, thresholdPoints float64) (bool, error) {
	if !finite(unitNetYen, thresholdPoints, 100*thresholdPoints) || thresholdPoints <= 0 {
		return false, fmt.Errorf("起動額又は単位利益が不正")
	}
	return unitNetYen >= 100*thresholdPoints, nil
}

// NewState は実新規時のV・H・費用床を一度だけ固定します。
//
// 引数: entry(Entry)は新規価格・方向・費用・公開尺度。返り値: State/errorは新しい純状態又は拒否です。
func NewState(entry Entry) (State, error) {
	if !validScope(entry.Scope) || (entry.Policy != G1 && entry.Policy != G2 && entry.Policy != G3 && entry.Policy != G4) || (entry.Side != 1 && entry.Side != -1) ||
		!validPrice(entry.Price) || !finite(entry.At, entry.SlipPoints) || entry.At < entry.Scope.Start || entry.SlipPoints < 0 ||
		entry.InitialQuantity < 1 || entry.InitialQuantity > 10 {
		return State{}, fmt.Errorf("新規の識別・政策・方向・価格・時計・数量・費用が不正")
	}
	if err := validateEvidence(entry.EntryV, entry.Scope, entry.At, 5); err != nil {
		return State{}, err
	}
	if err := validateEvidence(entry.ATR, entry.Scope, entry.At, 0); err != nil {
		return State{}, err
	}
	cost := .77 + 2*entry.SlipPoints
	threshold := math.Max(20, 2*cost)
	if entry.EntryV != nil {
		threshold = math.Max(threshold, .25*entry.EntryV.Value)
	}
	threshold, fee, minimum := ceil5(threshold), ceil5(cost), ceil5(cost+5)
	if !finite(cost, threshold, fee, minimum, 100*threshold) {
		return State{}, fmt.Errorf("費用又は導出額が非有限")
	}
	s := State{initialized: true, entry: entry, cost: cost, threshold: threshold, fee: fee, minimum: minimum,
		atr: entry.ATR, remaining: entry.InitialQuantity, at: entry.At, thresholdKnown: true}
	if entry.Policy == G3 || entry.Policy == G4 {
		s.threshold, s.thresholdKnown = 0, false
		if s.atr != nil {
			if err := lockThreshold110(&s, entry.At); err != nil {
				return State{}, err
			}
		}
	}
	return cloneState(s), nil
}

// lockThreshold110 は既知ATRと新規時Vから起動水準を一度だけ固定します。
//
// 引数: s(*State)はG3/G4状態、at(float64)はATR取得を確認した現在時計です。
// 返り値: errorは未知・再固定・算術破損の拒否です。外部状態を参照しません。
func lockThreshold110(s *State, at float64) error {
	if s == nil || s.thresholdKnown || s.atr == nil || (s.entry.Policy != G3 && s.entry.Policy != G4) {
		return fmt.Errorf("110起動水準の固定条件が不正")
	}
	alpha := .5
	if s.entry.Policy == G4 {
		alpha = 1
	}
	budget := s.atr.Value
	if s.entry.EntryV != nil {
		budget = s.entry.EntryV.Value
	}
	base, costTerm, atrTerm, noiseTerm := 20.0, 2*s.cost, alpha*s.atr.Value, s.minimum+budget-s.cost
	unrounded := math.Max(math.Max(base, costTerm), math.Max(atrTerm, noiseTerm))
	threshold := ceil5(unrounded)
	if !finite(budget, base, costTerm, atrTerm, noiseTerm, unrounded, threshold, 100*threshold) || budget <= 0 || threshold <= 0 {
		return fmt.Errorf("110起動水準の導出額が不正")
	}
	labels := []string{"固定20", "費用2K", "ATR倍率", "費用床と余裕"}
	values := []float64{base, costTerm, atrTerm, noiseTerm}
	dominant := []string{}
	for i, value := range values {
		if value == unrounded {
			dominant = append(dominant, labels[i])
		}
	}
	s.threshold, s.thresholdKnown = threshold, true
	s.thresholdLock = &ThresholdLock110{At: at, Alpha: alpha, ATR: *s.atr, EntryV: copyPtr(s.entry.EntryV), VFallback: s.entry.EntryV == nil,
		NoiseBudgetPoints: budget, CostPoints: s.cost, MinimumFloor: s.minimum, BaseTerm: base, CostTerm: costTerm, ATRTerm: atrTerm,
		NoiseTerm: noiseTerm, DominantTerms: dominant, UnroundedThreshold: unrounded, ThresholdPoints: threshold}
	return nil
}

// validatePublication は公表とprior pivotの未来・場違いを拒否します。
//
// 引数: p(*Publication)、entry(Entry)、at(float64)は確定根拠と利用時計。
// 返り値: errorは破損又は未来根拠です。中心足が新規以前のpivotは構造床の対象外として別判定します。
func validatePublication(p *Publication, entry Entry, at float64) error {
	if p.Scope != entry.Scope || p.ID == "" || p.Ordinal < 1 || !finite(p.End, p.AvailableAt) ||
		p.End <= entry.Scope.Start || math.Mod(p.End-entry.Scope.Start, 180) != 0 || p.AvailableAt < p.End || p.AvailableAt > at || p.C > True || p.M > True {
		return fmt.Errorf("公表の識別・場・3分時計・三値が不正")
	}
	if p.V != nil && (!finite(*p.V, 2**p.V) || *p.V < 5) {
		return fmt.Errorf("公表値幅が不正")
	}
	if p.Close != nil && !validPrice(*p.Close) {
		return fmt.Errorf("公表終値が不正")
	}
	if pivot := p.PriorPivot; pivot != nil {
		expected := "low"
		if entry.Side < 0 {
			expected = "high"
		}
		if pivot.Scope != entry.Scope || pivot.ID == "" || pivot.Kind != expected || !validPrice(pivot.Price) ||
			!finite(pivot.CenterEnd, pivot.ConfirmEnd, pivot.PublishedAt) || pivot.CenterEnd <= entry.Scope.Start ||
			math.Mod(pivot.CenterEnd-entry.Scope.Start, 180) != 0 || pivot.ConfirmEnd != pivot.CenterEnd+360 ||
			pivot.PublishedAt < pivot.ConfirmEnd || pivot.ConfirmEnd >= p.End || pivot.PublishedAt >= p.AvailableAt {
			return fmt.Errorf("prior pivotの場・方向・確認・公開時計が不正")
		}
	}
	return nil
}

// warningFor は最新の公開終値とprior pivotからPを計算します。
//
// 引数: s(State)は現在状態。返り値: Truth/Truth/errorは警戒・P又は破損です。
func warningFor(s State) (Truth, Truth, error) {
	if s.latest == nil {
		return Unknown, Unknown, nil
	}
	p := Unknown
	if s.latest.Close != nil && s.latest.PriorPivot != nil {
		p = False
		if float64(s.entry.Side)*(*s.latest.Close-s.latest.PriorPivot.Price) < 0 {
			p = True
		}
	}
	w, err := Warning(s.latest.C, s.latest.M, p)
	return w, p, err
}

// selectedWidth はG1旧幅又はG2の現在尺度と狭幅旗から幅を選びます。
//
// 引数: s(State)は起動済み状態。返り値: *float64/string/errorは幅・由来又は拒否です。
func selectedWidth(s State) (*float64, string, error) {
	var a, v *float64
	if s.atr != nil {
		a = &s.atr.Value
	}
	if s.latest != nil {
		v = s.latest.V
	}
	value, source := 0.0, ""
	if s.entry.Policy == G1 {
		if a == nil {
			return nil, "G1_ATR不明_費用床のみ", nil
		}
		value, source = 2**a, "G1_旧2ATR"
	} else if s.narrowed {
		switch {
		case a != nil && v != nil:
			value, source = math.Max(10, math.Min(*a, *v)), "G2_狭幅_minATR_V"
		case v != nil:
			value, source = math.Max(10, *v), "G2_狭幅_V"
		case a != nil:
			value, source = math.Max(10, *a), "G2_狭幅_ATR"
		default:
			return copyPtr(s.width), "G2_両不明_既存幅保持", nil
		}
	} else {
		switch {
		case a != nil && v != nil:
			value, source = math.Max(15, math.Min(2**a, 2**v)), "G2_通常_min2ATR_2V"
		case v != nil:
			value, source = math.Max(15, 2**v), "G2_通常_2V"
		case a != nil:
			value, source = 2**a, "G2_V不明_旧2ATR"
		default:
			return copyPtr(s.width), "G2_両不明_既存幅保持", nil
		}
	}
	value = ceil5(value)
	if !finite(value) || value <= 0 {
		return nil, "", fmt.Errorf("選択幅が不正")
	}
	return ptr(value), source, nil
}

// Advance は入力を変更せず、一定利益起動・幅・床・返済可能量だけを純評価します。
//
// 引数: state(State)は以前の状態、in(Input)は順序付きの原行評価値。
// 返り値: State/Decision/errorは次状態・純判定又は拒否です。注文・約定・損益集計は作りません。
func Advance(state State, in Input) (State, Decision, error) {
	decision := Decision{}
	if !state.initialized || state.finished || !finite(in.At) || in.At < state.at || in.Sequence <= state.sequence ||
		(in.Phase != PreFill && in.Phase != AfterSource) || in.Remaining < 0 || in.Remaining > state.remaining ||
		in.Reserved < 0 || in.Reserved > in.Remaining || (in.Publication != nil && in.ResetReason != "") {
		return state, decision, fmt.Errorf("状態・順序・段階・残玉・予約又はreset同時公表が不正")
	}
	if in.Mark != nil && !validPrice(*in.Mark) {
		return state, decision, fmt.Errorf("返済側価格が不正")
	}
	if err := validateEvidence(in.ATR, state.entry.Scope, in.At, 0); err != nil {
		return state, decision, err
	}
	if in.Publication != nil {
		if err := validatePublication(in.Publication, state.entry, in.At); err != nil {
			return state, decision, err
		}
	}
	s := cloneState(state)
	if in.ATR != nil {
		if s.atr != nil && !reflect.DeepEqual(s.atr, in.ATR) {
			return state, decision, fmt.Errorf("取得時又は最初の既知ATRの変更は禁止")
		}
		s.atr = copyPtr(in.ATR)
	}
	if in.ResetReason != "" {
		s.latest = nil
	}
	if p := in.Publication; p != nil {
		if last := s.lastPublication; last != nil && p.ID == last.ID {
			if !reflect.DeepEqual(p, last) {
				return state, decision, fmt.Errorf("同じ公表IDの内容が変化")
			}
			// 同体再送はresetで失効した公表を復活させません。
		} else {
			if last != nil && (p.End <= last.End || p.Ordinal <= last.Ordinal) {
				return state, decision, fmt.Errorf("公表の時計又はordinalが後退")
			}
			s.latest, s.lastPublication = clonePublication(p), clonePublication(p)
		}
	}
	s.at, s.sequence, s.remaining, s.reserved = in.At, in.Sequence, in.Remaining, in.Reserved
	decision.FreeQuantity = in.Remaining - in.Reserved
	if in.Remaining == 0 {
		s.finished = true
		return s, decision, nil
	}
	if !s.thresholdKnown && s.atr != nil {
		if err := lockThreshold110(&s, in.At); err != nil {
			return state, decision, err
		}
		decision.ThresholdLockedNow = true
	}
	warning, p, err := warningFor(s)
	if err != nil {
		return state, decision, err
	}
	decision.Warning, decision.P = warning, p
	if in.Mark == nil {
		return s, decision, nil
	}
	gain := float64(s.entry.Side) * (*in.Mark - s.entry.Price)
	unit := gain*100 - (77 + 2*s.entry.SlipPoints*100)
	if !finite(gain, unit) {
		return state, decision, fmt.Errorf("価格差又は単位純額が非有限")
	}
	decision.GainPoints, decision.UnitNetYen = ptr(gain), ptr(unit)
	if s.peak == nil || gain > *s.peak {
		s.peak = ptr(gain)
	}
	if !s.thresholdKnown {
		return s, decision, nil
	}
	eligible, err := ActivationEligible(unit, s.threshold)
	if err != nil {
		return state, decision, err
	}
	if !s.active && eligible {
		s.active, s.activatedAt, decision.ActivatedNow = true, ptr(in.At), true
	}
	if !s.active {
		return s, decision, nil
	}
	if s.entry.Policy != G1 && warning == True && !s.narrowed {
		s.narrowed, s.narrowedAt, decision.NarrowedNow = true, ptr(in.At), true
	}
	width, source, err := selectedWidth(s)
	if err != nil {
		return state, decision, err
	}
	s.width, decision.WidthSource = width, source
	floor := s.minimum
	if s.floor != nil {
		floor = math.Max(floor, *s.floor)
	}
	if width != nil {
		floor = math.Max(floor, *s.peak-*width)
	}
	if s.entry.Policy != G1 && warning == True && s.latest != nil && s.latest.PriorPivot != nil {
		pivot := s.latest.PriorPivot
		if pivot.CenterEnd-180 >= s.entry.At {
			stopPrice := pivot.Price - float64(s.entry.Side)*5
			structural := float64(s.entry.Side) * (stopPrice - s.entry.Price)
			if finite(stopPrice, structural) && stopPrice > 0 && structural > s.minimum {
				decision.StructuralEligible, decision.StructuralFloor = true, ptr(structural)
				floor = math.Max(floor, structural)
			}
		}
	}
	if !finite(floor, s.entry.Price+float64(s.entry.Side)*floor) || s.entry.Price+float64(s.entry.Side)*floor <= 0 {
		return state, decision, fmt.Errorf("保護床又は保護価格が不正")
	}
	s.floor = ptr(floor)
	decision.FloorHit = gain <= floor
	if decision.FloorHit && in.Phase == AfterSource {
		decision.EligibleExitQuantity = decision.FreeQuantity
	}
	return s, decision, nil
}
