"""純保護の人工検査と指紋停止を記録する。

引数はない。返り値はない。test/vet/build以外の金融・市場処理を呼ばない。
"""

from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
ANCESTOR = ROOT / "work/一定利益と費用床の純状態案/停止.json"
ACTOR = ROOT / "work/一定利益と三時間軸の保護会計/停止.json"
DESIGN = ROOT / "work/110利益保護の設計/利益保護の仕様案.md"
DESIGN_JSON = ROOT / "work/110利益保護の設計/案の条件.json"


def sha(path: Path) -> str:
    """明示されたコード・仕様・停止記録のSHA256を算出する。

    引数: path(Path)は対象ファイル。返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def ref(path: Path) -> dict:
    """コード・仕様の明示参照を返す。

    引数: path(Path)は対象ファイル。返り値: dictは絶対pathとsha256。
    """
    return {"path": str(path.resolve()), "sha256": sha(path)}


def run(args: list[str]) -> dict:
    """純部品の検査コマンドだけを実行する。

    引数: args(list[str])はGoコマンド。返り値: dictは実行引数・終了値・出力。
    """
    environment = dict(os.environ)
    environment["CGO_ENABLED"] = "0"
    completed = subprocess.run(args, cwd=OWN, env=environment, encoding="utf-8", capture_output=True, check=False)
    record = {"argv": args, "終了値": completed.returncode, "stdout": completed.stdout, "stderr": completed.stderr}
    if completed.returncode:
        raise RuntimeError(json.dumps(record, ensure_ascii=False))
    return record


def main() -> None:
    """人工検査を実行し、成功時だけ新規の停止記録を作る。

    引数: なし。返り値: None。既存停止の上書きを拒否する。
    """
    if (OWN / "停止.json").exists():
        raise RuntimeError("停止済み部品の再記録は拒否")
    assert sha(ANCESTOR) == "1d58cebc88a08011632a4ac1c036dcc71ae8d1bf8dc85938b3f2b344ad85a24c"
    assert sha(ACTOR) == "567b0bc6354b5d3d47d57f1cc3f91335a661d359ea4c81ae02f83653f3970687"
    owned = sorted(list(OWN.glob("*.go")) + [OWN / "go.mod", OWN / "検査と停止を記録する.py"])
    before_owned = {str(path.resolve()): sha(path) for path in owned}
    old = {}
    for stop in [ANCESTOR, ACTOR]:
        body = json.loads(stop.read_text(encoding="utf-8-sig"))
        old[str(stop)] = sha(stop)
        for key, value in body.get("所有コードSHA256", {}).items():
            source_path = Path(key)
            if not source_path.is_absolute():
                source_path = ROOT / source_path
            assert sha(source_path) == value
            old[str(source_path.resolve())] = value
    before_specs = {str(path.resolve()): sha(path) for path in [OWN / "README.md", OWN / "仕様.md", DESIGN, DESIGN_JSON]}
    checks = OWN / "検査"
    checks.mkdir(exist_ok=True)
    go_version = run(["go", "version"])
    tests = run(["go", "test", "-count=1", "-json", "-coverprofile=" + str(checks / "coverage.out"), "./..."])
    vet = run(["go", "vet", "./..."])
    build = run(["go", "build", "./..."])
    coverage = run(["go", "tool", "cover", "-func=" + str(checks / "coverage.out")])
    events = [json.loads(line) for line in tests["stdout"].splitlines() if line.strip()]
    passed = [value["Test"] for value in events if value.get("Action") == "pass" and value.get("Test")]
    after_owned = {key: sha(Path(key)) for key in before_owned}
    after_old = {key: sha(Path(key)) for key in old}
    after_specs = {key: sha(Path(key)) for key in before_specs}
    assert before_owned == after_owned and old == after_old and before_specs == after_specs
    report = {"成功": True, "範囲": "手製の価格・公表・ATR・数量だけの純状態検査。市場/金融/Source/Actor接続なし。", "検査": [go_version, tests, vet, build, coverage], "主テスト数": sum("/" not in name for name in passed), "全テスト数": len(passed), "G3G4追加主テスト数": sum(name.startswith("Test110") for name in passed), "coverage": coverage["stdout"].splitlines()[-1], "所有コードSHA256前": before_owned, "所有コードSHA256後": after_owned, "旧コード停止SHA256前": old, "旧コード停止SHA256後": after_old, "仕様SHA256前": before_specs, "仕様SHA256後": after_specs, "前後不変": True, "Raw読取": False, "CSV読取": False, "SourceRecord読取": False, "Native本文読取": False, "未使用11月09日本文読取": False, "金融実行": False}
    with (checks / "Go確認.json").open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    stop = {"成功": True, "停止": True, "範囲": report["範囲"], "module": "github.com/masayoshi4649/SessionTradeExecuter/profitfloor110", "package": "profitfloor110", "作成UTC": datetime.datetime.now(datetime.timezone.utc).isoformat(), "Go版": go_version["stdout"].strip(), "所有コードSHA256": before_owned, "仕様": ref(OWN / "仕様.md"), "README": ref(OWN / "README.md"), "設計元SHA256": before_specs, "旧停止": [ref(ANCESTOR), ref(ACTOR)], "検査": ref(checks / "Go確認.json"), "人工テスト": {"主": report["主テスト数"], "全": len(passed), "追加G3G4主": report["G3G4追加主テスト数"], "coverage": report["coverage"]}, "検査前後コード不変": True, "旧所有コード前後不変": True, "市場入力本文読取": False, "金融Actor接続": False, "Source接続": False, "市場実行": False, "金融再実行": False, "未使用11月09日読取": False, "未実施": ["Actorとの予約・要求・約定接続", "全市場金融と参加評価", "mini実板と実約定", "未使用場確認", "CGO無効のためrace detector"]}
    with (OWN / "停止.json").open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(stop, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"停止": ref(OWN / "停止.json"), "テスト": stop["人工テスト"], "所有コード数": len(before_owned), "旧不変台帳数": len(old)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
