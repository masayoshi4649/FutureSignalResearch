package threeentryfrequency110

import (
	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	"strings"
	"testing"
)

// 由来: 停止Core62934599463b34def929302c810bd7da2f8abeccdbfa28dce0ade82518633d73の人工helperだけ。
// publisherInput は実数値を注入せず240助走子と12押戻し子から新公開器の入力を作ります。
//
// 引数: t(*testing.T)、side(int)は検査器と鏡像方向です。
// 返り値: PublicationInputはSeriesBankが実計算する人工足列です。
func publisherInput(t *testing.T, side int) PublicationInput {
	t.Helper()
	start := 1800000000.0
	contract := "人工限月"
	prior := frame.Session{ID: "人工助走", Contract: contract, Start: start, End: start + 241*300, EOF: start + 240*300 + 60}
	children := make([]frame.ChildBar, 240)
	for i := range children {
		p := 10000 + float64(i)*2
		o := frame.OHLC{Open: p - .5, High: p + 2, Low: p - 2, Close: p}
		if side < 0 {
			o = frame.OHLC{Open: 30000 - o.Open, High: 30000 - o.Low, Low: 30000 - o.High, Close: 30000 - o.Close}
		}
		children[i] = frame.ChildBar{Start: start + float64(i)*300, End: start + float64(i+1)*300, OHLC: o, Volume: 100, Closed: true, VolumeKnown: true, Input: frame.FileRef{Path: "人工助走.csv", SHA256: strings.Repeat("a", 64), Bytes: 12345}, Row: uint64(i + 2)}
	}
	b, e := frame.BeginSession(prior, children, nil)
	if e != nil {
		t.Fatal(e)
	}
	if _, e = b.AdvanceObserved(prior.EOF, 1); e != nil {
		t.Fatal(e)
	}
	seed, _, e := b.Seal()
	if e != nil {
		t.Fatal(e)
	}
	base := 10478.0
	ohlc := []frame.OHLC{{Open: 5, High: 7, Low: -2, Close: 0}, {Open: 0, High: 1, Low: -7, Close: -5}, {Open: -5, High: 9, Low: -5, Close: 0}, {Open: 0, High: 8, Low: -2, Close: -1}, {Open: -1, High: 5, Low: -4, Close: -3}, {Open: -3, High: 3, Low: -4, Close: -2}, {Open: -2, High: 13, Low: -2, Close: 11}, {Open: 11, High: 14, Low: 8, Close: 12}, {Open: 12, High: 17, Low: 9, Close: 15}, {Open: 15, High: 18, Low: 10, Close: 16}, {Open: 16, High: 19, Low: 11, Close: 17}, {Open: 17, High: 20, Low: 12, Close: 18}}
	s := frame.Session{ID: "人工三軸取得_Day", Contract: contract, Start: prior.End + 3600, End: prior.End + 3600 + 13*300, EOF: prior.End + 3600 + 12*300 + 60}
	current := make([]frame.ChildBar, len(ohlc))
	for i, o := range ohlc {
		o.Open += base
		o.High += base
		o.Low += base
		o.Close += base
		if side < 0 {
			o = frame.OHLC{Open: 30000 - o.Open, High: 30000 - o.Low, Low: 30000 - o.High, Close: 30000 - o.Close}
		}
		current[i] = frame.ChildBar{Start: s.Start + float64(i)*300, End: s.Start + float64(i+1)*300, OHLC: o, Volume: 100, Closed: true, VolumeKnown: true, Input: frame.FileRef{Path: "人工取得.csv", SHA256: strings.Repeat("b", 64), Bytes: 6789}, Row: uint64(i + 2)}
	}
	return PublicationInput{Session: s, Children: current, Seed: &seed}
}
