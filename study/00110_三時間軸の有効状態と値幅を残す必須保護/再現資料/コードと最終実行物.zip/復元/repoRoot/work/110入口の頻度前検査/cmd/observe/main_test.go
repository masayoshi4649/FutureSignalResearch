package main

import (
	"encoding/csv"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"
	"time"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	reader "github.com/masayoshi4649/SessionTradeExecuter/savedpublic107"
	observer "github.com/masayoshi4649/SessionTradeExecuter/threeentryfrequency110"
	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

// put はmetadata人工だけをtempへ新規保存します。
//
// 引数: t(*testing.T)、path(string)、value(any)は検査器・保存先・JSON値です。
// 返り値: FileRefは人工本文のSHAを持ちます。
func put(t *testing.T, path string, value any) FileRef {
	t.Helper()
	raw, e := json.Marshal(value)
	if e != nil {
		t.Fatal(e)
	}
	if e = os.WriteFile(path, raw, 0600); e != nil {
		t.Fatal(e)
	}
	h, e := digest(path)
	if e != nil {
		t.Fatal(e)
	}
	return FileRef{path, h}
}

// artificialPlan は市場価格なしの70場metadataを作ります。
//
// 引数: t(*testing.T)はtempの所有者です。
// 返り値: Request/FileRefはfirst2条件と技法固定です。実CSVは開きません。
func artificialPlan(t *testing.T) (Request, FileRef) {
	t.Helper()
	dir := t.TempDir()
	exe, e := os.Executable()
	if e != nil {
		t.Fatal(e)
	}
	h, e := digest(exe)
	if e != nil {
		t.Fatal(e)
	}
	code := put(t, filepath.Join(dir, "人工code.json"), map[string]bool{"人工": true})
	stop := put(t, filepath.Join(dir, "停止.json"), map[string]bool{"成功": true})
	tech := put(t, filepath.Join(dir, "技法固定.json"), Technique{Fixed: true, ObserverBinary: FileRef{exe, h}, ObserverStop: stop, CodeSHA: map[string]string{code.Path: code.SHA}})
	m := continuous.InputManifest{Root: dir, Sessions: []continuous.InputSession{}}
	scenes := []SceneRequest{}
	for i := 0; i < 70; i++ {
		id := fmt.Sprintf("人工_%02d_Day", i)
		csv := frame.FileRef{Path: filepath.Join(dir, id+".csv"), SHA256: code.SHA, Bytes: 123}
		m.Sessions = append(m.Sessions, continuous.InputSession{ID: id, Contract: "人工限月", Files: map[string]continuous.InputFile{"NK225_candle_300": {Path: csv.Path, SHA256: csv.SHA256, Size: csv.Bytes}}})
		scenes = append(scenes, SceneRequest{Session: id, CSV: csv})
	}
	manifest := put(t, filepath.Join(dir, "入力manifest.json"), m)
	corpus := put(t, filepath.Join(dir, "Source台帳.json"), map[string]bool{"人工": true})
	completion := put(t, filepath.Join(dir, "Source完成.json"), map[string]bool{"人工": true})
	r := Request{Version: 1, Trial: 110, Fixed: true, Stage: "first2", Technique: tech, Manifest: manifest, Corpus: corpus, Completion: completion, Scenes: scenes[:2], Output: filepath.Join(dir, "出力"), ClockModel: observer.ClockModel, QuietSeconds: 1200}
	return r, tech
}

// checkPlan は変更した人工metadataを毎回新しい条件SHAへ結びます。
//
// 引数: t(*testing.T)、r(Request)は検査器と条件です。
// 返り値: Plan/errorはloadPlanの結果です。
func checkPlan(t *testing.T, r Request) (Plan, error) {
	t.Helper()
	ref := put(t, filepath.Join(t.TempDir(), "条件.json"), r)
	return loadPlan(ref)
}

// TestFixedPlanAuthentication は自己exe/停止/code/順序/主条件の固定を確認します。
//
// 引数: t(*testing.T)は市場なしのmetadata検査器です。
// 返り値: ありません。人工CSV本文は作成も読込もしません。
func TestFixedPlanAuthentication(t *testing.T) {
	r, _ := artificialPlan(t)
	if _, e := checkPlan(t, r); e != nil {
		t.Fatal(e)
	}
	for _, name := range []string{"quiet", "age", "clock", "fixed", "order", "csv", "count", "stage", "first2自己参照", "出力既存"} {
		t.Run(name, func(t *testing.T) {
			r, _ := artificialPlan(t)
			switch name {
			case "quiet":
				r.QuietSeconds = 1800
			case "age":
				r.QuoteMaxAgeSeconds = 90
			case "clock":
				r.ClockModel = "実受信時計との混同"
			case "fixed":
				r.Fixed = false
			case "order":
				r.Scenes[0], r.Scenes[1] = r.Scenes[1], r.Scenes[0]
			case "csv":
				r.Scenes[0].CSV.Bytes++
			case "count":
				r.Scenes = r.Scenes[:1]
			case "stage":
				r.Stage = "金融"
			case "first2自己参照":
				r.First2 = &r.Technique
			case "出力既存":
				if e := os.Mkdir(r.Output, 0700); e != nil {
					t.Fatal(e)
				}
			}
			if _, e := checkPlan(t, r); e == nil {
				t.Fatal("固定差を許可", name)
			}
		})
	}
	for _, name := range []string{"誤exe", "code変更", "停止不成功", "参照SHA"} {
		t.Run(name, func(t *testing.T) {
			r, _ := artificialPlan(t)
			var tech Technique
			raw, _ := os.ReadFile(r.Technique.Path)
			if e := json.Unmarshal(raw, &tech); e != nil {
				t.Fatal(e)
			}
			switch name {
			case "誤exe":
				tech.ObserverBinary = put(t, filepath.Join(t.TempDir(), "別exe.json"), map[string]bool{"別": true})
			case "code変更":
				for path := range tech.CodeSHA {
					if e := os.WriteFile(path, []byte("変更"), 0600); e != nil {
						t.Fatal(e)
					}
				}
			case "停止不成功":
				tech.ObserverStop = put(t, tech.ObserverStop.Path, map[string]bool{"成功": false})
			case "参照SHA":
				r.Manifest.SHA = tech.ObserverStop.SHA
			}
			r.Technique = put(t, r.Technique.Path, tech)
			if _, e := checkPlan(t, r); e == nil {
				t.Fatal("認証差を許可", name)
			}
		})
	}
}

// TestFullStageRequiresSameFirst2 は先頭coldと同じ技法固定を全70へ要求します。
//
// 引数: t(*testing.T)はmetadata人工検査器です。
// 返り値: ありません。金融は実行しません。
func TestFullStageRequiresSameFirst2(t *testing.T) {
	r, _ := artificialPlan(t)
	var manifest continuous.InputManifest
	raw, _ := os.ReadFile(r.Manifest.Path)
	if e := json.Unmarshal(raw, &manifest); e != nil {
		t.Fatal(e)
	}
	r.Stage = "full70"
	r.Scenes = nil
	for _, s := range manifest.Sessions {
		v := s.Files["NK225_candle_300"]
		r.Scenes = append(r.Scenes, SceneRequest{Session: s.ID, CSV: frame.FileRef{Path: v.Path, SHA256: v.SHA256, Bytes: v.Size}})
	}
	if _, e := checkPlan(t, r); e == nil {
		t.Fatal("first2省略を許可")
	}
	prior := Completion{Version: 1, Trial: 110, Stage: "first2", Success: true, Technique: r.Technique, Manifest: r.Manifest, Corpus: r.Corpus, SourceCompletion: r.Completion, Config: observer.DefaultConfig(), Results: []SceneOutput{{Session: r.Scenes[0].Session}, {Session: r.Scenes[1].Session}}}
	ref := put(t, filepath.Join(t.TempDir(), "先頭2完成.json"), prior)
	r.First2 = &ref
	if _, e := checkPlan(t, r); e != nil {
		t.Fatal(e)
	}
	prior.Config.QuoteMaxAgeSeconds = 90
	ref = put(t, ref.Path, prior)
	r.First2 = &ref
	if _, e := checkPlan(t, r); e == nil {
		t.Fatal("first2の異なる条件を許可")
	}
}

// TestSummaryAndNoOverwrite は日本語CSVの列数と新規保存制約を確認します。
//
// 引数: t(*testing.T)は金額を含まない人工CSVの検査器です。
// 返り値: ありません。CSVを損益資料とは呼びません。
func TestSummaryAndNoOverwrite(t *testing.T) {
	path := filepath.Join(t.TempDir(), "頻度.csv")
	ref, e := writeSummary(path, []SceneOutput{{Session: "人工", Grids: 10, PrimaryPlanned: 8, PrimaryObserved: 7, PrimaryUnobserved: 1}})
	if e != nil {
		t.Fatal(e)
	}
	f, e := os.Open(ref.Path)
	if e != nil {
		t.Fatal(e)
	}
	defer f.Close()
	rows, e := csv.NewReader(f).ReadAll()
	if e != nil || len(rows) != 2 || len(rows[0]) != len(rows[1]) || rows[1][2] != "8" {
		t.Fatal("CSV列/計画数差", e)
	}
	if _, e = writeSummary(path, nil); e == nil {
		t.Fatal("出力上書き")
	}
	if _, e = saveJSON(filepath.Join(t.TempDir(), "圧縮.json.gz"), map[string]bool{"人工": true}, true); e != nil {
		t.Fatal(e)
	}
}

// TestActualReaderToObserver は停止Readerの人工codecを実I/O経路へ接続します。
//
// 引数: t(*testing.T)は6Recordだけを持つ非市場型の検査器です。
// 返り値: ありません。場数metadata検査は別testであり、このI/O人工を全70成功と呼びません。
func TestActualReaderToObserver(t *testing.T) {
	path := filepath.Join("..", "..", "..", "109入口の頻度前検査_参照正規化", "人工Reader", "old104_54", "期待.json")
	raw, e := os.ReadFile(path)
	if e != nil {
		t.Fatal(e)
	}
	var fixture struct {
		Request reader.Request `json:"request"`
	}
	if e = json.Unmarshal(raw, &fixture); e != nil {
		t.Fatal(e)
	}
	d := t.TempDir()
	// ----------------------------------------
	// 元codec人工はEOF=0なので、人工コピーだけへ観測末尾のmetadataを明示します。
	var completion reader.Completion
	if raw, e = os.ReadFile(fixture.Request.Completion.Path); e != nil {
		t.Fatal(e)
	}
	if e = json.Unmarshal(raw, &completion); e != nil {
		t.Fatal(e)
	}
	for i := range completion.Results {
		if completion.Results[i].Session != fixture.Request.SceneID {
			continue
		}
		var header reader.PublicHeader
		if raw, e = os.ReadFile(completion.Results[i].Header.Path); e != nil {
			t.Fatal(e)
		}
		if e = json.Unmarshal(raw, &header); e != nil {
			t.Fatal(e)
		}
		header.Header.Ending.Legacy.HasObservedClock = true
		header.Header.Ending.Legacy.ObservedClock = header.Header.Scene.Start + 2
		ref := put(t, filepath.Join(d, "EOF付き人工Header.json"), header)
		completion.Results[i].Header = reader.FileRef{Path: ref.Path, SHA: ref.SHA}
	}
	newCompletion := put(t, filepath.Join(d, "EOF付き人工完成.json"), completion)
	fixture.Request.Completion = reader.FileRef{Path: newCompletion.Path, SHA: newCompletion.SHA}
	csvPath := filepath.Join(d, "人工足.csv")
	loaded, e := reader.LoadTape(fixture.Request)
	if e != nil {
		t.Fatal(e)
	}
	at := time.Unix(int64(loaded.Tape().Session.Start), 0).UTC().Format(time.RFC3339)
	body := []byte("time,open,high,low,close,volume,volume_complete,closed\n" + at + ",1000,1010,990,1005,100,true,true\n")
	if e = os.WriteFile(csvPath, body, 0600); e != nil {
		t.Fatal(e)
	}
	h, e := digest(csvPath)
	if e != nil {
		t.Fatal(e)
	}
	r := Request{Version: 1, Trial: 110, Fixed: true, Stage: "人工一場", Manifest: FileRef{fixture.Request.Manifest.Path, fixture.Request.Manifest.SHA}, Corpus: FileRef{fixture.Request.Corpus.Path, fixture.Request.Corpus.SHA}, Completion: FileRef{fixture.Request.Completion.Path, fixture.Request.Completion.SHA}, Scenes: []SceneRequest{{Session: fixture.Request.SceneID, CSV: frame.FileRef{Path: csvPath, SHA256: h, Bytes: int64(len(body))}}}, Output: filepath.Join(d, "新規出力"), ClockModel: observer.ClockModel, QuietSeconds: 1200}
	p := Plan{Request: r, Protected: map[string]string{}}
	for _, ref := range []FileRef{r.Manifest, r.Corpus, r.Completion} {
		if e = readRef(ref, nil, p.Protected); e != nil {
			t.Fatal(e)
		}
	}
	out, e := execute(p)
	if e != nil {
		t.Fatal(e)
	}
	if !out.Success || !out.Unchanged || out.FinancialExecuted || out.ParticipationCalculated || len(out.Results) != 1 || out.Results[0].PrimaryUnobserved != out.Results[0].PrimaryPlanned || out.Results[0].PrimaryTechnical.Unknown != 2*out.Results[0].PrimaryPlanned {
		t.Fatal("実Reader I/O/EOF不明保持差")
	}
	if _, e = os.Stat(filepath.Join(r.Output, "完成.json")); e != nil {
		t.Fatal(e)
	}
}

// TestManifestRelativeCSV はRoot生成器と同じsource_root結合を受理します。
//
// 引数: t(*testing.T)は相対manifestと絶対要求のmetadata人工です。
// 返り値: ありません。CSV本文を読みません。
func TestManifestRelativeCSV(t *testing.T) {
	r, _ := artificialPlan(t)
	var manifest continuous.InputManifest
	raw, e := os.ReadFile(r.Manifest.Path)
	if e != nil {
		t.Fatal(e)
	}
	if e = json.Unmarshal(raw, &manifest); e != nil {
		t.Fatal(e)
	}
	for i := range manifest.Sessions {
		file := manifest.Sessions[i].Files["NK225_candle_300"]
		relative, e := filepath.Rel(manifest.Root, file.Path)
		if e != nil {
			t.Fatal(e)
		}
		file.Path = relative
		manifest.Sessions[i].Files["NK225_candle_300"] = file
	}
	r.Manifest = put(t, r.Manifest.Path, manifest)
	if _, e = checkPlan(t, r); e != nil {
		t.Fatal("Root方式の相対→絶対参照を拒否", e)
	}
	for _, name := range []string{"../別.csv", `..\別.csv`, "", `C:別.csv`, `\別.csv`, filepath.Join(t.TempDir(), "別root.csv")} {
		t.Run(name, func(t *testing.T) {
			if _, e := normalizeCSVPath(manifest.Root, name); e == nil {
				t.Fatal("不正/別root参照を許可", name)
			}
		})
	}
	if _, e = normalizeCSVPath("相対root", "子.csv"); e == nil {
		t.Fatal("相対source_rootを許可")
	}
}
