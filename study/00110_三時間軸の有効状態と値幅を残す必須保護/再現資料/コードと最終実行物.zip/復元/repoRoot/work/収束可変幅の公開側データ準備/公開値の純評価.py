"""公開された異なる3分足だけからC/M/Pを評価する非金融の純部品。"""
from __future__ import annotations

from copy import deepcopy
import json
import math


def identity(session: str, contract: str, end: float) -> str:
    """
    機能: 公表足を衝突しない3要素で識別する。
    引数: session/contract (str)、end (float) は場・限月・足終端。
    返り値: str は正規のJSON配列文字列。
    """
    return json.dumps([session, contract, float(end)], ensure_ascii=False, separators=(",", ":"))


def truth(known: bool, passed: bool = False) -> dict:
    """
    機能: 必要未知を不成立と区別する。
    引数: known/passed (bool) は既知性とstrict条件の成立。
    返り値: dict は既知性と、未知ならNoneの成立値。
    """
    return {"known": known, "passed": passed if known else None}


def from_publication(publication: dict, ordinal: int, *, known3: dict | None = None, ohlc: dict | None = None) -> dict:
    """
    機能: chartwarmup96.Publicationを保守的な純式入力へ射影する。
    引数: publication (dict)、ordinal (int)、known3/ohlc (dict|None) は公開値と明示的な将来拡張。
    返り値: dict はFrame。現公開型にない個別Known/OHLCは自動補完しない。
    """
    if publication["three"] is not True:
        raise ValueError("3分の新公表だけを受け付ける")
    s, e = publication["snapshot"], publication["snapshot"]["three"]
    t = s["chart"]["technical"]
    if s["at"] != publication["at"] or s["invalidated_at"] != 0:
        raise ValueError("公表そのものではないsnapshot")
    k = known3 if known3 is not None else {"ema8": t["trend_known"], "ema21": t["trend_known"], "hist": t["exit_known"], "close": e["data_known"]}
    scene = s["scene"]
    return {"id": identity(scene["id"], scene["contract"], e["bar_end"]), "ordinal": ordinal,
            "session": scene["id"], "contract": scene["contract"], "start": scene["start"],
            "end": e["bar_end"], "available_at": e["available_at"], "observed_clock": e["observed_clock"],
            "at": publication["at"], "technical_end": t["bar3_end"], "data_known": e["data_known"],
            "last_source": deepcopy(e["last_source"]) if e["has_last_source"] else None,
            "ema8": t["ema8_3"], "ema21": t["ema21_3"], "hist": t["histogram3"], "close": t["close3"],
            "known": deepcopy(k), "ohlc": deepcopy(ohlc), "extension_supplied": known3 is not None or ohlc is not None}


def validate(f: dict) -> None:
    """
    機能: 公表・半開足出典と既知数値を検査する。
    引数: f (dict) は一つのFrame。
    返り値: None。不正値はValueErrorとし、正常なウォームアップ不足とは分ける。
    """
    if not f["session"] or not f["contract"] or type(f["ordinal"]) is not int or f["ordinal"] < 1:
        raise ValueError("識別不正")
    values = [f[x] for x in ("start", "end", "at", "available_at", "observed_clock", "technical_end", "ema8", "ema21", "hist", "close")]
    if any(type(v) not in (int, float) or not math.isfinite(v) for v in values):
        raise ValueError("非有限の数値")
    if f["end"] <= f["start"] or (f["end"]-f["start"]) % 180 or f["at"] != f["end"] or f["technical_end"] != f["end"] or f["available_at"] != f["end"] or f["observed_clock"] < f["available_at"]:
        raise ValueError("未来公表又は足時計不正")
    if f["id"] != identity(f["session"], f["contract"], f["end"]):
        raise ValueError("公表ID不一致")
    if type(f["data_known"]) is not bool or set(f["known"]) != {"ema8", "ema21", "hist", "close"} or any(type(x) is not bool for x in f["known"].values()):
        raise ValueError("Known型不正")
    if f["data_known"]:
        source = f["last_source"]
        if source is None or source["valid"] is not True or type(source["time"]) not in (int, float) or not math.isfinite(source["time"]) or not f["end"]-180 <= source["time"] < f["end"] or type(source["line"]) is not int or source["line"] <= 0 or type(source["index"]) is not int or source["index"] < 0 or type(source["last"]) not in (int, float) or not math.isfinite(source["last"]) or source["last"] <= 0:
            raise ValueError("当足より未来又は別足の出典")
        if f["known"]["close"] and f["close"] <= 0 or any(f["known"][key] and f[key] <= 0 for key in ("ema8", "ema21")):
            raise ValueError("既知価格不正")
    o = f["ohlc"]
    if o is not None:
        if not f["data_known"] or not f["known"]["close"] or o["publication_id"] != f["id"]:
            raise ValueError("OHLC出典不一致")
        v = [o[x] for x in ("open", "high", "low", "close")]
        if any(type(x) not in (int, float) or not math.isfinite(x) or x <= 0 for x in v) or o["close"] != f["close"] or not o["low"] <= min(o["open"], o["close"]) <= max(o["open"], o["close"]) <= o["high"]:
            raise ValueError("OHLC形状不正")


class Tracker:
    """数値指標を形成せず、公表済み値と最新確認構造だけを保持する。"""

    def __init__(self) -> None:
        """
        機能: 所有も場間状態もない読取器を作る。
        引数: なし。
        返り値: None。
        """
        self.last = None
        self.reset("初期化")

    def reset(self, reason: str) -> None:
        """
        機能: 欠測・Last0 control等で技法窓と構造を失効する。
        引数: reason (str) は呼出側が保存する失効理由。
        返り値: None。公表の重複/後退検査用lastは消さない。
        """
        self.history, self.prices = [], []
        self.low, self.high, self.reason = None, None, reason

    def feed(self, frame: dict) -> dict:
        """
        機能: P評価後に新pivotを登録し、当足確認を当足へ先取りしない。
        引数: frame (dict) は新公表又は同じ公表の完全反復。
        返り値: dict はnew/reset、両方向C/M/Pと当時利用したpivot出典。
        """
        validate(frame)
        f, prior = deepcopy(frame), self.last
        reset_reason = ""
        same_scene = prior is not None and (f["session"], f["contract"]) == (prior["session"], prior["contract"])
        if same_scene and f["end"] == prior["end"]:
            if f != prior:
                raise ValueError("同じ公表に異なる値")
            return {"new": False, "id": f["id"]}
        if same_scene and (f["end"] < prior["end"] or f["ordinal"] <= prior["ordinal"]):
            raise ValueError("公表後退")
        if same_scene and f["end"] == prior["end"]+180 and f["ordinal"] != prior["ordinal"]+1:
            raise ValueError("連続公表のordinal飛越")
        if not same_scene or f["end"] != prior["end"]+180:
            reset_reason = "場/限月変更又は欠足"
            self.reset(reset_reason)
        self.last = f
        if not f["data_known"]:
            reset_reason = "不良/空の確定足"
            self.reset(reset_reason)
        else:
            self.history = (self.history+[f])[-3:]
        cknown = len(self.history) == 3 and all(x["known"]["ema8"] and x["known"]["ema21"] for x in self.history)
        gaps = [abs(x["ema8"]-x["ema21"]) for x in self.history]
        c = truth(cknown, cknown and gaps[2] < gaps[1] < gaps[0])
        mknown = len(self.history) >= 2 and all(x["known"]["hist"] for x in self.history[-2:])
        delta = self.history[-1]["hist"]-self.history[-2]["hist"] if mknown else 0
        if f["ohlc"] is None:
            self.prices, self.low, self.high = [], None, None
        out = {"new": True, "id": f["id"], "reset_reason": reset_reason, "C": c, "buy": {"M": truth(mknown, delta < 0)}, "sell": {"M": truth(mknown, delta > 0)}, "new_pivots": []}
        for role, side, pivot in (("buy", 1, self.low), ("sell", -1, self.high)):
            known = f["data_known"] and f["known"]["close"] and f["ohlc"] is not None and pivot is not None
            out[role]["P"] = truth(known, known and side*(f["close"]-pivot["price"]) < 0)
            out[role]["prior_pivot"] = deepcopy(pivot)
        if f["data_known"] and f["ohlc"] is not None:
            self.prices = (self.prices+[f])[-5:]
            if len(self.prices) == 5:
                a, b, center, d, e = self.prices
                for key, attr, sign in (("low", "low", -1), ("high", "high", 1)):
                    value = sign*center["ohlc"][key]
                    if all(value > sign*x["ohlc"][key] for x in (a, b)) and all(value >= sign*x["ohlc"][key] for x in (d, e)):
                        pivot = {"kind": key, "price": center["ohlc"][key], "center_id": center["id"], "center_end": center["end"], "confirm_id": f["id"], "confirm_end": f["end"], "published_at": f["available_at"]}
                        setattr(self, attr, pivot)
                        out["new_pivots"].append(deepcopy(pivot))
        return out
