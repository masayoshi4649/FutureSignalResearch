"""Rootが技法・成功頻度・保存停止を認証し、109金融条件を一度だけ新規生成する。"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
from pathlib import Path
import re

OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
TRIAL = ROOT / 'study/00109_三時間軸の取得確認と一定利益の必須保護'
TARGET = TRIAL / '金融条件.json'
JOURNAL = ROOT / 'work/109進行/現在.json'
MARKET = ROOT / 'work/三時間軸の市場入出力_停止型対応'
CLOCK = 'csv_end_plus60_at_record_scheduler'
SOURCE_FIELDS = ('source_manifest', 'source_corpus', 'source_completion',
                 'baseline_closure', 'baseline_completion', 'baseline_native_index')
SHA_PATTERN = re.compile(r'[0-9a-f]{64}')


def require(condition: bool, message: str) -> None:
    """機能: 固定不足や不整合を最初の保存前に拒否する。

    引数: condition(bool)、message(str)は成立条件と説明。
    返り値: None。不成立ではValueErrorを送出する。
    """
    if not condition:
        raise ValueError(message)


def sha(path: Path) -> str:
    """機能: 明示されたcode・exe・小metadataを同定する。

    引数: path(Path)は許可した入力。価格CSV/Raw/Record/場別報告は渡さない。
    返り値: strはSHA256。市場の再検査や再計算を行わない。
    """
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path: Path) -> dict:
    """機能: 明示された小JSONをUTF-8で読む。

    引数: path(Path)は技法/要求/完成/停止/検査のmetadata。
    返り値: dictは元の全値。市場本文の口は持たない。
    """
    value = json.loads(path.read_text(encoding='utf-8-sig'))
    require(isinstance(value, dict), 'JSONのrootはobjectが必要')
    return value


def path_key(path: Path) -> str:
    """機能: 同じWindows絶対pathを一つの指紋キーへ正規化する。

    引数: path(Path)は明示入力位置。
    返り値: strは比較用キー。ディレクトリを探索しない。
    """
    return os.path.normcase(str(path.resolve()))


def valid_ref(value: dict) -> Path:
    """機能: FileRefの絶対位置と指紋の型を検査する。

    引数: value(dict)はpath/sha256の参照。
    返り値: Pathは絶対位置。ここでは本文を読まない。
    """
    require(isinstance(value, dict) and isinstance(value.get('path'), str), 'FileRefのpathが必要')
    path = Path(value['path'])
    require(path.is_absolute() and SHA_PATTERN.fullmatch(value.get('sha256', '')) is not None, '絶対FileRefとSHA256が必要')
    return path.resolve()


def bind(value: dict, before: dict) -> Path:
    """機能: 明示された非価格FileRefの実物を認証する。

    引数: value(dict)、before(dict)は参照と再確認用台帳。
    返り値: Pathは認証済み位置。価格を含む頻度beforeの全件再読はしない。
    """
    path = valid_ref(value)
    require(sha(path) == value['sha256'], '実物SHA差: ' + str(path))
    key = str(path)
    require(key not in before or before[key] == value['sha256'], '同pathの指紋衝突')
    before[key] = value['sha256']
    return path


def reference(path: Path) -> dict:
    """機能: 許可した非価格ファイルを絶対FileRefへ写す。

    引数: path(Path)はcode又は小metadata。
    返り値: dictはpath/sha256。
    """
    return {'path': str(path.resolve()), 'sha256': sha(path)}


def merge_code(code: dict, additions: dict, before: dict) -> None:
    """機能: codeの現物同体と二重宣言を検査して結合する。

    引数: code/additions/before(dict)は結合先・期待指紋・再確認台帳。
    返り値: None。元tech codeと違う指紋での置換を拒否する。
    """
    require(isinstance(additions, dict) and additions, '空でないcode集合が必要')
    normalized = {path_key(Path(k)): v for k, v in code.items()}
    for name, expected in additions.items():
        path = bind({'path': name, 'sha256': expected}, before)
        key = path_key(path)
        require(key not in normalized or normalized[key] == expected, 'codeの衝突: ' + str(path))
        code[str(path)] = expected
        normalized[key] = expected


def expected_configs() -> list[dict]:
    """機能: 停止Coreと同順の24金融設定を構成する。

    引数: なし。
    返り値: list[dict]はE0/E1×G0/G1/G2×C0/C5×D0/D1、quiet1200。
    """
    return [{'candidate': f'{entry}_{protect}', 'entry_policy': entry, 'protection_policy': protect,
             'entry_timing': 'B5QD', 'quiet_seconds': 1200, 'slip_pts': slip, 'delay_seconds': delay}
            for entry in ('entry_E0', 'entry_E1') for protect in ('G0', 'G1', 'G2')
            for slip in (0, 5) for delay in (0, 1)]


def verify_journal(value: dict) -> None:
    """機能: Root進行が未金融・handleなし・保留未読であることを確認する。

    引数: value(dict)はRoot進行のmetadata。
    返り値: None。金融を開始済み又は未読でない場合は拒否する。
    """
    require(value.get('試行') == 109 and value.get('市場金融実行') is False and
            'ライブ金融handle' in value and value['ライブ金融handle'] is None and
            value.get('保留価格と損益未読') is True, 'Root進行の未金融/handle/未読条件')
    require(value.get('研究目標達成') is False and value.get('採用') is False, '採用済み条件を新規金融へ使わない')


def verify_technique(value: dict) -> None:
    """機能: 市場前に固定された技法の政策・時計・未実行範囲を検査する。

    引数: value(dict)は技法固定JSON。
    返り値: None。金融条件そのものと取り違えない。
    """
    require(value.get('version') == 1 and value.get('trial') == 109 and value.get('fixed') is True, '109技法固定が必要')
    require(value.get('configs') == expected_configs() and value.get('clock_model') == CLOCK and
            value.get('quiet_seconds') == 1200 and value.get('quote_max_age_seconds') == 0, '技法の24設定/時計差')
    require(value.get('financial_executed') is False and value.get('frequency_executed') is False and
            value.get('holdout_price_unread') is True and value.get('adopted') is False and
            value.get('goal_achieved') is False, '市場前固定の未実行/保留範囲差')
    require(isinstance(value.get('code_sha256'), dict) and value['code_sha256'] and
            len(value.get('stops', [])) >= 9 and len(value.get('specifications', [])) >= 4, '技法code/stop/spec不足')
    require(path_key(valid_ref(value['market_binary'])) == path_key(MARKET / '検査/三時間軸研究.exe'), '停止型対応の市場exeだけ')


def fingerprint_map(value: dict) -> dict:
    """機能: 頻度が保存した前後宣言を本文再読なしで正規化する。

    引数: value(dict)は価格CSV等も含む既存指紋宣言。
    返り値: dictは比較用path→SHA。現物を再hashしたという意味ではない。
    """
    require(isinstance(value, dict) and value, '空でない前後指紋が必要')
    result = {}
    for name, expected in value.items():
        path = valid_ref({'path': name, 'sha256': expected})
        key = path_key(path)
        require(key not in result, '同体でない表記の指紋重複')
        result[key] = expected
    return result


def nonnegative(value: object) -> bool:
    """機能: 計数をboolと区別した非負整数として確認する。

    引数: value(object)はJSON計数。
    返り値: boolは正しい計数型であること。
    """
    return type(value) is int and value >= 0


def verify_frequency(value: dict, request: dict, tech: dict, tech_ref: dict,
                     request_ref: dict, manifest: dict, stage: str) -> None:
    """機能: 同技法の成功頻度metadataと固定分母を照合する。

    引数: value/request/tech/tech_ref/request_ref/manifest(dict)、stage(str)は完成・要求・固定・入力順。
    返り値: None。頻度を参加率/金融品質再検算/損益と扱わない。
    """
    count = 70 if stage == 'full70' else 2
    ids = [row['id'] for row in manifest['sessions']]
    require(len(ids) == len(set(ids)) == 70 and ids == sorted(ids), 'manifestは明示70場の時系列')
    require(value.get('version') == 1 and value.get('trial') == 109 and value.get('stage') == stage and
            value.get('success') is True and value.get('financial_executed') is False and
            value.get('participation_calculated') is False and value.get('unchanged') is True and not value.get('error'), '成功頻度と非金融/非参加')
    require(value.get('before') == value.get('after'), '頻度前後指紋の宣言差')
    fingerprints = fingerprint_map(value['before'])
    require(value.get('request') == request_ref and value.get('technique_fixed') == tech_ref, '頻度の要求/同技法SHA差')
    config = {'clock_model': CLOCK, 'quote_max_age_seconds': 0, 'quiet_seconds': 1200}
    require(value.get('config') == config, '頻度の時計/年齢/静観差')
    require(request.get('version') == 1 and request.get('trial') == 109 and request.get('fixed') is True and
            request.get('stage') == stage and request.get('technique_fixed') == tech_ref and
            all(request.get(k) == v for k, v in config.items()), '頻度要求の固定差')
    for src, freq in (('source_manifest', 'manifest'), ('source_corpus', 'corpus'), ('source_completion', 'source_completion')):
        require(value.get(freq) == request.get(freq) == tech[src], '頻度Source参照差: ' + src)
    expected_refs = [tech_ref, request_ref, tech['observer_binary'], tech['observer_stop']]
    expected_refs += [tech[k] for k in ('source_manifest', 'source_corpus', 'source_completion')]
    expected_refs += [{'path': p, 'sha256': h} for p, h in tech['code_sha256'].items()]
    for ref in expected_refs:
        require(fingerprints.get(path_key(valid_ref(ref))) == ref['sha256'], '頻度が実使用した固定指紋の包含不足')
    results, scenes = value.get('results', []), request.get('scenes', [])
    require([r['session'] for r in results] == [s['session'] for s in scenes] == ids[:count], '頻度70場順/要求場順差')
    require(Path(request.get('output_dir', '')).is_absolute(), '頻度の絶対出力先が必要')
    root = Path(manifest['source_root'])
    require(root.is_absolute(), 'manifestの絶対source_rootが必要')
    for i, (row, scene) in enumerate(zip(results, scenes)):
        csv = manifest['sessions'][i]['files']['NK225_candle_300']
        expected_csv = {'path': str((root / csv['path']).resolve()), 'sha256': csv['sha256'], 'bytes': csv['size']}
        require(scene.get('candle_csv') == expected_csv, '頻度要求のNK225 CSV宣言差')
        valid_ref(row['report'])  # 本文は公表値を含むので読まない。
        require(valid_ref(row['report']).parent == Path(request['output_dir']).resolve(), '頻度場別報告の出力位置差')
        day = row['session'].endswith('_Day')
        require(day or row['session'].endswith('_Night'), '日夜の場識別が必要')
        primary, secondary = (78, 74) if day else (150, 146)
        for prefix, planned in (('primary', primary), ('secondary', secondary)):
            vals = [row.get(prefix + suffix) for suffix in ('_planned_grids', '_observed_grids', '_unobserved_grids')]
            require(all(nonnegative(v) for v in vals) and vals[0] == planned and vals[1] + vals[2] == vals[0], '主副予定分母/未知保持差')
            for suffix in ('_technical_allowed_grids', '_source_allowed_grids'):
                n = row.get(prefix + suffix)
                require(nonnegative(n) and n <= vals[1], '成立枠は観測枠以下')
        seed = row.get('end_seed', {})
        require(seed.get('sealed') is True and seed.get('session', {}).get('id') == row['session'] and
                seed.get('session', {}).get('contract') == manifest['sessions'][i]['contract'] and
                seed.get('observed_at') == seed.get('session', {}).get('eof') and
                SHA_PATTERN.fullmatch(seed.get('sha256', '')) is not None, '頻度末尾種の封印/場/指紋差')
    if stage == 'full70':
        require(sum(r['primary_planned_grids'] for r in results) == 7980 and
                sum(r['secondary_planned_grids'] for r in results) == 7700, '正式70の主7980/副7700が必要')


def verify_saving(stop: dict, check: dict, saving_dir: Path) -> tuple[dict, dict]:
    """機能: 保存器の人工成功と所有7/再用10の一台帳を認証する。

    引数: stop/check(dict)、saving_dir(Path)は停止・確認・固定保存器位置。
    返り値: tuple[dict,dict]は所有と再用code。実市場結果の保証へ置換しない。
    """
    require(stop.get('version') == 1 and stop.get('trial') == 109 and stop.get('停止') is True and
            stop.get('入力前後不変') is True and stop.get('実市場読取') is False and
            stop.get('実金融') is False and stop.get('CSV/xlsx生成') is False, '保存器の人工停止範囲差')
    code = stop.get('コードSHA256')
    require(isinstance(code, dict) and code and check.get('成功') is True and check.get('exit_code') == 0 and check.get('前後不変') is True and
            check.get('コードSHA256前') == code == check.get('コードSHA256後') and
            check.get('入力SHA256前') and check.get('入力SHA256前') == check.get('入力SHA256後'), '保存器の成功/前後code/人工入力差')
    owned, reused = {}, {}
    for name, expected in code.items():
        path = valid_ref({'path': name, 'sha256': expected})
        require(path.suffix == '.py', '保存器codeは明示Pythonだけ')
        (owned if path.parent == saving_dir.resolve() else reused)[str(path)] = expected
    require(len(owned) == 7 and len(reused) == 10 and len(code) == 17, '停止保存器の所有7/再用10が必要')
    return owned, reused


def build_condition(tech: dict, tech_ref: dict, frequency_ref: dict, saving_ref: dict,
                    saving_spec: dict, saving_check: dict, code: dict) -> dict:
    """機能: 停止型対応CLI Conditionと追跡参照を同体に構成する。

    引数: techと各Ref/code(dict)は認証済み固定値。
    返り値: dictは未実行の金融条件。保存器stopをGo専用stopsへ混ぜない。
    """
    value = {'version': 1, 'trial': 109, 'fixed': True,
             'scope': '同技法の成功頻度70後のMain24金融。既使用探索、採用/安定性未証明',
             'source_scope': 'recorded_public_106', 'clock_model': CLOCK, 'workers': 4,
             'own_module_dir': str(MARKET.resolve()), 'binary': copy.deepcopy(tech['market_binary']),
             'configs': copy.deepcopy(tech['configs']), 'stops': copy.deepcopy(tech['stops']),
             'specifications': copy.deepcopy(tech['specifications']) + [tech_ref, frequency_ref, saving_ref, saving_spec, saving_check],
             'code_sha256': dict(code), 'technique_fixed': tech_ref, 'frequency_completion': frequency_ref,
             'saving_stop': saving_ref, 'financial_executed': False, 'frequency_executed': True,
             'participation_calculated': False, 'holdout_price_unread': True, 'goal_achieved': False, 'adopted': False,
             'frequency_evidence': '完成metadataの成功/前後宣言同体を認証。価格本文再読/金融前品質再計算ではない',
             'participation_denominator': {'primary': 7980, 'secondary': 7700, 'unknown_kept': True}}
    value.update({k: copy.deepcopy(tech[k]) for k in SOURCE_FIELDS})
    if 'method_catalog' in tech:
        value['method_catalog'] = copy.deepcopy(tech['method_catalog'])
    return value


def write_new(path: Path, value: dict) -> None:
    """機能: 検査済み金融条件を一度だけ保存する。

    引数: path(Path)、value(dict)は正式先と固定値。
    返り値: None。既存ファイルを開いて更新しない。
    """
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def prepare(tech_ref: dict, frequency_ref: dict, saving_ref: dict) -> tuple[dict, dict]:
    """機能: Rootが明示した3停止系列を市場本文なしで結合する。

    引数: tech_ref/frequency_ref/saving_ref(dict)は絶対FileRef。
    返り値: tuple[dict,dict]は金融条件と再確認する非価格指紋。
    """
    require(not TARGET.exists(), '金融条件は未生成の場合だけ作成できる')
    before = {}
    journal_ref = reference(JOURNAL)
    journal_path = bind(journal_ref, before)
    journal = read(journal_path)
    verify_journal(journal)
    tech_path = bind(tech_ref, before)
    require(tech_path == TRIAL / '技法条件固定.json', '正式109技法固定だけ')
    tech = read(tech_path)
    verify_technique(tech)
    require(journal.get('技法固定') == tech_ref, 'Root進行と技法固定の結合差')
    code = {}
    merge_code(code, tech['code_sha256'], before)
    for ref in [tech['market_binary'], tech['observer_binary'], tech['observer_stop']] + tech['stops'] + tech['specifications']:
        bind(ref, before)
    for ref in tech.get('go_closures', {}).values():
        bind(ref, before)
    for key in SOURCE_FIELDS:
        bind(tech[key], before)
    manifest = read(Path(tech['source_manifest']['path']))
    frequency_path = bind(frequency_ref, before)
    require(frequency_path.name == '完成.json', '頻度完成metadataが必要')
    frequency = read(frequency_path)
    request_ref = frequency['request']
    request = read(bind(request_ref, before))
    require(Path(request['output_dir']).resolve() == frequency_path.parent, '頻度完成の出力位置差')
    verify_frequency(frequency, request, tech, tech_ref, request_ref, manifest, 'full70')
    bind(frequency['summary_csv'], before)  # 数値は技術頻度のみ。価格CSVではない。
    first_ref = request.get('first2_completion')
    first = read(bind(first_ref, before))
    first_request_ref = first['request']
    first_request = read(bind(first_request_ref, before))
    verify_frequency(first, first_request, tech, tech_ref, first_request_ref, manifest, 'first2')
    require(fingerprint_map(frequency['before']).get(path_key(valid_ref(first_ref))) == first_ref['sha256'], '全70は認証済み先頭2を実使用する')
    for i in range(2):
        current, prior = frequency['results'][i], first['results'][i]
        require(current['end_seed'] == prior['end_seed'] and current['report']['sha256'] == prior['report']['sha256'], '同技法の先頭2/全70種又は報告SHA差')
    saving_path = bind(saving_ref, before)
    saving_dir = saving_path.parent
    saving = read(saving_path)
    saving_check_path = bind(saving['検査'], before)
    bind(saving['仕様'], before)
    owned, reused = verify_saving(saving, read(saving_check_path), saving_dir)
    merge_code(code, owned, before)
    merge_code(code, reused, before)
    own_code = {str(OWN / name): sha(OWN / name) for name in ('固定する.py', '人工検査.py', '検査と停止を記録する.py', 'README.md')}
    merge_code(code, own_code, before)
    value = build_condition(tech, tech_ref, frequency_ref, saving_ref, saving['仕様'], saving['検査'], code)
    value['saving_code_counts'] = {'owned': len(owned), 'reused': len(reused)}
    value['specifications'].append(reference(OWN / 'README.md'))
    return value, before


def main() -> None:
    """機能: Rootの明示実行でだけ正式金融条件を新規生成する。

    引数: --technique/--frequency-completion/--saving-stopと各SHAは認証元。
    返り値: None。金融exe、Observer、Raw/価格/場別報告本文は呼ばない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('technique', 'frequency-completion', 'saving-stop'):
        parser.add_argument('--' + name, type=Path, required=True)
    for name in ('technique-sha', 'frequency-sha', 'saving-stop-sha'):
        parser.add_argument('--' + name, required=True)
    args = parser.parse_args()
    value, before = prepare({'path': str(args.technique), 'sha256': args.technique_sha},
                            {'path': str(args.frequency_completion), 'sha256': args.frequency_sha},
                            {'path': str(args.saving_stop), 'sha256': args.saving_stop_sha})
    for path, expected in before.items():
        require(sha(Path(path)) == expected, '固定処理中の非価格入力差: ' + path)
    verify_journal(read(JOURNAL))
    require(not TARGET.exists(), '並行処理で金融条件が既に生成された')
    write_new(TARGET, value)
    print(json.dumps({'金融条件': reference(TARGET), 'code数': len(value['code_sha256']),
                      '市場金融実行': False, '価格本文読取': False, 'Root進行変更': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
