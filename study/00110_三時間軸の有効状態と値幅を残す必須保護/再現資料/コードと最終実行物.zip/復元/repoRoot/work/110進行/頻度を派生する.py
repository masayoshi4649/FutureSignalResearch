"""109の純頻度観察器を、E2の現在状態だけを観察する110へ派生する。"""

import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / "work/109入口の頻度前検査_参照正規化"
TARGET = ROOT / "work/110入口の頻度前検査"


def digest(path: Path) -> str:
    """対象コードの全バイト指紋を取る。

    引数: path(Path)は旧又は新コード。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """E2差替えと試行識別だけを行い、金融・共有市場を実行しない。

    引数: なし。
    返り値: None。Source予定枠は旧L0診断のまま残し、L1適格性と呼ばない。
    """
    assert not TARGET.exists()
    paths = [p for p in SOURCE.rglob("*.go") if "cmd" in p.relative_to(SOURCE).parts or p.parent == SOURCE]
    paths.extend([SOURCE / "go.mod", SOURCE / "go.sum"])
    before = {str(p): digest(p) for p in paths}
    for path in paths:
        text = path.read_text(encoding="utf-8")
        for old, new in {
            "threeentryfrequency109": "threeentryfrequency110",
            "entry.EntryE1": "entry.EntryE2", "Trial: 109": "Trial: 110", "Trial != 109": "Trial != 110",
            "../三時間軸の入口判定": "../110有効状態の入口判定",
        }.items():
            text = text.replace(old, new)
        text = re.sub(r"/threeentry\b", "/multientry110", text)
        text = text.replace("技法成立頻度と出生済みSource予定取得枠の重なり。金融適格性・参加率・損益は未計算", "E2の技法成立頻度と元L0の出生済みSource予定枠。L1金融適格性・参加率・損益は未計算")
        target = TARGET / path.relative_to(SOURCE)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
    assert all(digest(Path(p)) == h for p, h in before.items())
    (TARGET / "由来_初期派生.json").write_text(json.dumps({"元コード": before, "前後不変": True, "段階": "未停止・市場未実行", "Source予定枠": "旧L0のみの診断。L1はActorの実適格集合で評価する"}, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print("110の純頻度観察器を派生しました")


if __name__ == "__main__":
    main()
