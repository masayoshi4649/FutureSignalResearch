"""停止Coreの人工288冊について、技法判定と別に純会計と旧対照を検算する。"""

import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]


def digest(path: Path) -> str:
    """停止人工の全バイト指紋を取得する。

    引数: path(Path)はコード又は人工出力。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """全保存結合とは分けて純会計・旧対照の範囲だけを確認する。

    引数: なし。
    返り値: None。新保護P・入口Eの検査成功をこの段階で主張しない。
    """
    directory = ROOT / "work/110有効状態と値幅保護の保存"
    sys.path.insert(0, str(directory))
    spec = importlib.util.spec_from_file_location("人工110の純会計", directory / "集計.py")
    saved = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(saved)
    stop_path = ROOT / "work/110有効状態と値幅保護の接続/停止.json"
    assert digest(stop_path) == "80d6eeb5c9781fe831c55a95a5039b09f8b5849b6106781026377889ab1a88cb"
    stop = json.loads(stop_path.read_text(encoding="utf-8"))
    results = []
    for artifact in stop["人工出力"]:
        path = Path(artifact["path"])
        assert digest(path) == artifact["sha256"]
        raw = saved.read_text(path)
        members = saved.OLD.raw_members(raw)
        if "output" not in members:
            continue
        text = members["output"]
        value = json.loads(text, parse_float=saved.Decimal)
        saved.equal(value["configs"], saved.CONFIGS, "実36設定")
        saved.verify_public(value)
        count = 0
        for key, config in saved.BY_KEY.items():
            saved.A.verify_finance(value["books"][key], config)
            count += 1
        baseline = saved.verify_baseline(value, text, artificial=True, before={})
        results.append({"path": str(path), "sha256": artifact["sha256"], "会計数": count, "全JSON対照数": len(baseline)})
    assert len(results) == 8 and sum(row["会計数"] for row in results) == 288
    out = ROOT / "work/110進行/人工の純会計の確認.json"
    out.write_text(json.dumps({"成功": True, "範囲": "純会計A・公表時計・旧四対照のみ。新保護Pと入口Eの全保存結合ではない", "人工": results, "会計数": 288, "市場金融": False}, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print("人工8器具・288冊の純会計と32全JSON対照を確認しました")


if __name__ == "__main__":
    main()
