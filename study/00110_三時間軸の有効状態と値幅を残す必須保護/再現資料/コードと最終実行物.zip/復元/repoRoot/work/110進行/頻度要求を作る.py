"""固定した技法と106の明示70場から、頻度Observerの段階要求を作る。"""

import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00110_三時間軸の有効状態と値幅を残す必須保護"


def sha(path: Path) -> str:
    """明示した技法・要求・完了metadataを同定する。

    引数: path(Path)は小型JSON。市場の原板やCSVを指定しない。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict:
    """UTF-8 metadataを全値で読む。

    引数: path(Path)は固定済みJSON。
    返り値: dictは内容。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main() -> None:
    """市場本文を読まず、技法同体の先頭2又は全70要求を新規保存する。

    引数: --stage(str)、--technique-sha(str)、任意--first2-sha(str)は段階と期待指紋。
    返り値: None。Observer/exe/金融を実行せず、既存要求を上書きしない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--stage", choices=("first2", "full70"), required=True)
    parser.add_argument("--technique-sha", required=True)
    parser.add_argument("--first2-sha")
    args = parser.parse_args()
    technique = TRIAL / "技法条件固定.json"
    assert sha(technique) == args.technique_sha
    value = read(technique)
    assert value["fixed"] and value["trial"] == 110
    manifest_ref = value["source_manifest"]
    manifest_path = Path(manifest_ref["path"])
    assert sha(manifest_path) == manifest_ref["sha256"]
    manifest = read(manifest_path)
    assert len(manifest["sessions"]) == 70
    count, label = (2, "先頭2場") if args.stage == "first2" else (70, "全70場")
    target = ROOT / "work/110頻度要求" / (label+".json")
    output = ROOT / "work/110頻度" / label
    assert not target.exists() and not output.exists()
    scenes = []
    base = Path(manifest["source_root"])
    assert base.is_absolute()
    for scene in manifest["sessions"][:count]:
        candle = scene["files"]["NK225_candle_300"]
        scenes.append({"session": scene["id"], "candle_csv": {
            "path": str((base / candle["path"]).resolve()), "sha256": candle["sha256"], "bytes": candle["size"]}})
    request = {"version": 1, "trial": 110, "fixed": True, "stage": args.stage,
               "technique_fixed": {"path": str(technique), "sha256": args.technique_sha},
               "manifest": manifest_ref, "corpus": value["source_corpus"],
               "source_completion": value["source_completion"], "scenes": scenes,
               "output_dir": str(output), "clock_model": value["clock_model"],
               "quote_max_age_seconds": 0, "quiet_seconds": 1200}
    if args.stage == "full70":
        first2 = ROOT / "work/110頻度/先頭2場/完成.json"
        assert args.first2_sha and sha(first2) == args.first2_sha
        complete = read(first2)
        assert complete["success"] and complete["stage"] == "first2"
        assert complete["technique_fixed"] == request["technique_fixed"]
        assert not complete["financial_executed"] and not complete["participation_calculated"]
        request["first2_completion"] = {"path": str(first2), "sha256": args.first2_sha}
    else:
        assert args.first2_sha is None
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(request, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"要求": str(target), "SHA256": sha(target), "場数": count,
                      "本文読取": False, "金融実行": False}, ensure_ascii=False))


if __name__ == "__main__":
    main()
