"""110のCore・金融CLI・純頻度を人工だけで検査し、自己と依存の不変を残す。"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
MODULES = {
    "接続": ("work/110有効状態と値幅保護の接続", None, None),
    "金融CLI": ("work/110有効状態と値幅保護の市場入出力", "110市場.exe", "."),
    "純頻度": ("work/110入口の頻度前検査", "110頻度.exe", "./cmd/observe"),
}


def digest(path: Path) -> str:
    """明示されたコード・人工・実行物の指紋を取る。

    引数: path(Path)は非市場のファイル。
    返り値: strはSHA256。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def run(args: list[str], cwd: Path, env: dict) -> dict:
    """人工Go検査を実行し、出力と終了コードを保存する。

    引数: args(list[str])はコマンド、cwd(Path)は新module、env(dict)は人工専用環境。
    返り値: dictは検査記録。失敗時は例外で停止宣言を作らない。
    """
    result = subprocess.run(args, cwd=cwd, env=env, capture_output=True, text=True, encoding="utf-8")
    record = {"引数": args, "終了コード": result.returncode, "出力": result.stdout, "標準エラー": result.stderr}
    if result.returncode:
        raise RuntimeError(json.dumps(record, ensure_ascii=False))
    return record


def main() -> None:
    """依存停止を認証してから、選択した新部品を停止する。

    引数: CLIの部品(str)、--dependencies(Path)、--dependencies-sha256(str)を受け取る。
    返り値: None。旧コードや保留市場入力を変更・読取しない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("部品", choices=list(MODULES))
    parser.add_argument("--dependencies", type=Path, required=True)
    parser.add_argument("--dependencies-sha256", required=True)
    args = parser.parse_args()
    name, binary_name, build_target = MODULES[args.部品]
    module = ROOT / name
    stop = module / "停止.json"
    assert not stop.exists(), "停止物を上書きしない"
    assert digest(args.dependencies) == args.dependencies_sha256
    registry = json.loads(args.dependencies.read_text(encoding="utf-8"))
    pins = {str(args.dependencies.resolve()): args.dependencies_sha256}
    for ref in registry["stops"]:
        path = Path(ref["path"])
        assert digest(path) == ref["sha256"], str(path)
        declaration = json.loads(path.read_text(encoding="utf-8-sig"))
        assert declaration.get("成功") is True
        pins[str(path)] = ref["sha256"]
        code = declaration.get("所有コードSHA256", declaration.get("コードSHA256前", {}))
        assert code
        if "コードSHA256後" in declaration:
            assert declaration["コードSHA256前"] == declaration["コードSHA256後"]
        for source, expected in code.items():
            assert digest(Path(source)) == expected, source
            if source in pins:
                assert pins[source] == expected
            pins[source] = expected
    owned = {str(p): digest(p) for p in module.rglob("*.go")}
    owned.update({str(p): digest(p) for p in [module / "go.mod", module / "go.sum", Path(__file__)] if p.exists()})
    for doc in [module / "README.md", module / "仕様.md"]:
        if doc.exists():
            owned[str(doc)] = digest(doc)
    for path, expected in owned.items():
        if path in pins:
            assert pins[path] == expected
        pins[path] = expected
    env = dict(os.environ)
    env.pop("RUNTIME109_EXPORT", None)
    env.pop("RUNTIME110_EXPORT", None)
    env.pop("DECLARED110_EXPORT", None)
    if args.部品 == "接続":
        artificial = module / "人工_停止版"
        assert not artificial.exists()
        env["RUNTIME110_EXPORT"] = str(artificial)
    declared = None
    if args.部品 == "金融CLI":
        declared_path = module / "検査/宣言設定.json"
        assert not declared_path.exists()
        env["DECLARED110_EXPORT"] = str(declared_path)
    go = "C:/Program Files/Go/bin/go.exe"
    results = [run([go, "test", "./...", "-count=1", "-json"], module, env),
               run([go, "vet", "./..."], module, env)]
    events = [json.loads(line) for line in results[0]["出力"].splitlines() if line.startswith("{")]
    passed = [event for event in events if event.get("Action") == "pass" and event.get("Test")]
    assert passed
    binary = None
    if binary_name:
        target = module / "検査" / binary_name
        target.parent.mkdir(exist_ok=True)
        assert not target.exists()
        results.append(run([go, "build", "-o", str(target), build_target], module, env))
        binary = {"path": str(target), "sha256": digest(target), "bytes": target.stat().st_size}
    else:
        results.append(run([go, "build", "./..."], module, env))
    after = {path: digest(Path(path)) for path in pins}
    assert pins == after
    if args.部品 == "金融CLI":
        declared = {"path": str(declared_path), "sha256": digest(declared_path), "bytes": declared_path.stat().st_size}
    artifacts = []
    if args.部品 == "接続":
        for path in sorted(artificial.glob("*.json")):
            artifacts.append({"path": str(path), "sha256": digest(path), "bytes": path.stat().st_size})
        assert len(artifacts) >= 4
    record = {"成功": True, "停止": True, "試行": 110, "部品": args.部品,
              "範囲": "人工価格・手製Sourceのみ。市場金融/頻度・実旧70Record・11月09日の本文/hash読取なし",
              "時刻UTC": datetime.now(timezone.utc).isoformat(), "所有コードSHA256": owned,
              "コードSHA256前": pins, "コードSHA256後": after, "前後不変": True,
              "検査": results, "成功主検査数": sum("/" not in e["Test"] for e in passed), "成功全検査数": len(passed),
              "人工出力": artifacts, "実行物": binary, "宣言設定": declared}
    stop.write_text(json.dumps(record, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print(json.dumps({"停止": str(stop), "sha256": digest(stop), "主検査": record["成功主検査数"], "全検査": len(passed), "実行物": binary}, ensure_ascii=False))


if __name__ == "__main__":
    main()
