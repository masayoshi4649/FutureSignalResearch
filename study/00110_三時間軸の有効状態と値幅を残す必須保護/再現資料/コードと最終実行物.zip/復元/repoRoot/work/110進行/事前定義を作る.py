"""110の36候補と版6設定の設計案を、金融結果を読まずに生成する。"""

import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00110_三時間軸の有効状態と値幅を残す必須保護"


def setting(identifier: str, methods: list[str], scales: list[str], short: str, detail: str, scope: str) -> dict:
    """一つの技法設定を汎用表へ結び付ける。

    引数: identifier/short/detail/scope(str)はID・短記・定義・適用、methods/scales(list[str])は表のID。
    返り値: dictは未検証を明示する設定記録。
    """
    return {"設定ID": identifier, "手法ID": methods, "尺度ID": scales, "短記": short, "定義": detail, "結果短記": scope}


def main() -> None:
    """設計段階の設定だけを作り、市場前固定とは区別する。

    引数: なし。
    返り値: None。金融条件があれば上書きせず停止する。
    """
    assert not (TRIAL / "金融条件.json").exists()
    spec = importlib.util.spec_from_file_location("110が参照する109設定", ROOT / "scripts/レポート/試行109の設定表を作る.py")
    old = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(old)
    source_ids = {f"S{i:02d}" for i in range(1, 7)}
    source_ids.update(["S17", "S18", "S19", "S20", "S21", "S22", "S23", "S24", "S25", "K01", "K02", "K04"])
    rows = json.loads(json.dumps([row for row in old.settings() if row["設定ID"] in source_ids], ensure_ascii=False))
    for row in rows:
        row["結果短記"] = "R01〜36・未検証" if row["設定ID"] in {f"S{i:02d}" for i in range(1, 7)} | {"K01"} else "適用設定の詳細参照・未検証"
        row["定義"] = row["定義"].replace("G1/G2", "G3/G4").replace("G2", "G3/G4")
        if row["設定ID"] == "K02":
            row["結果短記"] = "R01〜04/R13〜16/R25〜28・未検証"
        if row["設定ID"] == "K04":
            row["短記"] = "G3/G4=109G2の可変追尾継承"
    entry_scope = "R13〜36・未検証"
    guard_scope = "R05〜12/R17〜24/R29〜36・未検証"
    rows.extend([
        setting("S10", ["I01"], ["m05", "m15", "m30"], "背景/押戻し/取得を分ける", "各足EMA8/21の並びと1足傾き。T継続は三軸整合、T押戻し再開は30方向・15risk帯・5回復を分担。Rは30逆整列も局所反転と記録。", entry_scope),
        setting("S11", ["I04", "I03"], ["m05", "m15"], "RSI/H水準維持と回復を分ける", "RSI14、H=MACD12/26/9のhistogram。維持は現在と前5分RSIが方向側strictかつ現在H>=0。回復はRSI40/60許容と方向ΔRSI/ΔH>0。T継続の15分はs*(RSI−50)>=0かつ(s*H>=0又はs*ΔH>=0)。T再開/Rの15分は逆推進4条件同時成立を拒否。詳細と等号は入口仕様へ結合。", entry_scope),
        setting("S12", ["P02", "P07"], ["m05", "m15"], "既知線の確認と未否定状態", "公表済15risk端と5pivotを固定。Tはcross又は前足も線外維持、Rは試験→別足復帰→更に別足突破。形成から1800秒、確認で延長しない。取得は線外かつ1ATR内、支持否定/欠足で失効。", entry_scope),
        setting("S13", ["I09", "I04"], ["m05"], "距離と複合spike", "取得側距離0<方向距離<=ATR14。直近2本のTR>2×前ATRかつ方向ΔRSI>20の同時急増を警戒。高位維持やTR単独では拒否しない。", entry_scope),
        setting("K03", ["C06", "E02", "I09", "I15"], ["tick", "m03", "m05"], "G3半A/G4一Aと1V余裕", "K=.77+2S、Fmin=ceil5(K+5)、Hλ=ceil5(max(20,2K,λA_lock,Fmin+V_entry−K))、λ=.5/1。V不明はA代替、A不明はH未確定。A初回既知で一度lockし現在費用後単位利益>=100Hで必須起動。最低床Fminと既存床を不利に緩めない。", guard_scope),
        setting("K05", ["C01", "C02", "P02"], ["m05"], "L0一枠/L1有効未取得の後続査定", "E0L0とE2L0は元のstrict次枠・静観明け一回。E2L1は未知/待機/余力不足を未取得SourceHold有効中に後続5分再査定。初回要求受理/Source返済予約/取消/残0/期限/Force/EOFで永久失効。実fill後再参加なし。", "L0:R01〜24/L1:R25〜36・未検証"),
    ])
    configs = []
    for entry, lifetime in [("entry_E0", "L0"), ("entry_E2", "L0"), ("entry_E2", "L1")]:
        for guard in ["G0", "G3", "G4"]:
            for slip in [0, 5]:
                for delay in [0, 1]:
                    candidate = f"{entry}_{guard}" if entry == "entry_E0" else f"{entry}_{lifetime}_{guard}"
                    configs.append({"candidate": candidate, "entry_policy": entry, "entry_lifetime": lifetime,
                                    "protection_policy": guard, "entry_timing": "B5QD", "quiet_seconds": 1200,
                                    "slip_pts": slip, "delay_seconds": delay,
                                    "settings": "S01〜06/K01＋該当入口・保護・寿命設定"})
    plan = {"version": 1, "trial": 110, "fixed": False, "scope": "実装前の設計。市場損益未計算。36候補は技法と未取得受付寿命を分離", "configs": configs,
            "holdout_price_unread": True, "financial_executed": False, "goal_achieved": False, "adopted": False}
    common = "NK225mini・各側上限10枚・100円/pt・38.5円/片道。主7980/副7700枠、未知/静観/欠測を分母に残す。足終+60秒をRecord.Atで公表、同限月数値carry/場mask reset/欠足reset。利益保護は連続。C5は追加5pt/片道、D1は価格時計1秒の仮定。L1は実fill後再参加ではない。未参加/退出後の仮想利益・機会損失を評価しない。"
    for name, value in [("研究条件案.json", plan), ("設定定義.json", {"trial": 110, "catalog_version": 6, "settings": rows, "common": common})]:
        (TRIAL / name).write_text(json.dumps(value, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    print("110の36候補と未検証の設定定義を保存しました")


if __name__ == "__main__":
    main()
