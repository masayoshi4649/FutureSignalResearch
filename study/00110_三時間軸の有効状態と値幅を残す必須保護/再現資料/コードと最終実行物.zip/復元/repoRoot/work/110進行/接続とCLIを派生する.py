"""109停止コードを変更せず、110の接続と市場CLIの初期派生を作る。"""

import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
REPLACEMENTS = {
    "threeguardruntime109": "threeguardruntime110",
    "/miniprofitthreeproposal": "/miniprofit110",
    "/profitfloorproposal": "/profitfloor110",
    "/threeentry": "/multientry110",
    '"../一定利益と三時間軸の保護会計"': '"../110有効入口と値幅保護の会計"',
    '"../一定利益と費用床の純状態案"': '"../110利益保護の純状態"',
    '"../三時間軸の入口判定"': '"../110有効状態の入口判定"',
    '"../三時間軸の市場接続準備"': '"../110有効状態と値幅保護の接続"',
    "finance.EntryE1": "finance.EntryE2", "entry.EntryE1": "entry.EntryE2",
    "finance.ProtectG1": "finance.ProtectG3", "finance.ProtectG2": "finance.ProtectG4",
}


def digest(path: Path) -> str:
    """コードのバイト指紋を取得する。

    引数: path(Path)は停止済みコード又は新しい派生コード。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def derive(source: Path, target: Path) -> None:
    """明示されたコードフォルダからGoとmodule宣言だけを派生する。

    引数: source/target(Path)は旧停止コードと新規先。
    返り値: None。既存先を拒否し、元ファイルの前後一致を残す。
    """
    assert not target.exists(), target
    names = sorted(p.name for p in source.iterdir() if p.suffix == ".go" or p.name in {"go.mod", "go.sum"})
    before = {str(source / name): digest(source / name) for name in names}
    target.mkdir(parents=True)
    for name in names:
        text = (source / name).read_text(encoding="utf-8")
        for old, new in REPLACEMENTS.items():
            text = text.replace(old, new)
        if name.endswith(".go"):
            text = re.sub(r"\b109\b", "110", text)
            text = text.replace("24Main", "36Main").replace("Main24", "Main36").replace("24設定", "36設定").replace("24会計", "36会計")
            text = re.sub(r"(len\([^\n]+?\) != )24\b", r"\g<1>36", text)
            text = text.replace("BooksPerScene: 24", "BooksPerScene: 36").replace("BooksPerScene != 24", "BooksPerScene != 36")
            text = text.replace("Books: 48", "Books: 72").replace("old.Books != 48", "old.Books != 72")
            text = text.replace("Books: 24", "Books: 36").replace("r.Books != 24", "r.Books != 36")
            text = text.replace("24*len(ids)", "36*len(ids)").replace("= 24, 12, 4", "= 36, 12, 4")
            text = text.replace("len(out.WidthAudits) != 8", "len(out.WidthAudits) != 12").replace("len(r.WidthAudits) != 8", "len(r.WidthAudits) != 12")
        (target / name).write_text(text, encoding="utf-8")
    after = {path: digest(Path(path)) for path in before}
    assert before == after
    provenance = {"段階": "未停止の初期派生・市場未実行", "元コード": before, "元コード後": after,
                  "前後不変": True, "派生先": str(target), "置換": REPLACEMENTS}
    (target / "由来_初期派生.json").write_text(json.dumps(provenance, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")


def main() -> None:
    """110のCoreとCLIを作り、共有入力の本文を開かずに終える。

    引数: なし。
    返り値: None。構成36と新Lifetimeの結合は後続編集で行う。
    """
    derive(ROOT / "work/三時間軸の市場接続準備", ROOT / "work/110有効状態と値幅保護の接続")
    derive(ROOT / "work/三時間軸の市場入出力_停止型対応", ROOT / "work/110有効状態と値幅保護の市場入出力")
    print("旧コード不変で110のCoreとCLIを初期派生しました")


if __name__ == "__main__":
    main()
