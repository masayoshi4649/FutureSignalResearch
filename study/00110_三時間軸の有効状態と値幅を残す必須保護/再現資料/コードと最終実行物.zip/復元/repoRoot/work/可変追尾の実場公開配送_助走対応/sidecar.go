// Package publicsidecar は停止producerの公開出力と追加3分公表を手製入力で結びます。
package publicsidecar

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"reflect"
	"sort"

	warm "github.com/masayoshi4649/SessionTradeExecuter/chartwarmup96"
	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
	delivery "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery"
)

// Seed は同入力でSealした二つの数値種です。公開Snapshotから組み立てません。
type Seed struct {
	legacy *warm.Seed
	public *chart.Seed
}

// Force は呼出側が固定するSourceTapeの時計と元ordinalだけです。通知を生成しません。
type Force struct {
	At          float64 `json:"at"`
	TapeOrdinal int     `json:"source_tape_ordinal"`
}

// Reset は不良Lastの原行を保持し、古い公表の再利用を止める制御です。
type Reset struct {
	Reason string      `json:"reason"`
	Source chart.Quote `json:"source"`
}

// Record は各原行へ届く前の公表順と金融Scalarの元値を分離して保持します。
type Record struct {
	Ordinal     int                  `json:"ordinal"`
	Kind        string               `json:"kind"`
	At          float64              `json:"at"`
	Trigger     *continuous.Identity `json:"trigger,omitempty"`
	Publication *chart.Publication   `json:"publication,omitempty"`
	Delivery    *delivery.Delivery   `json:"delivery,omitempty"`
	Grid        *chart.Snapshot      `json:"grid,omitempty"`
	Force       *Force               `json:"force_clock,omitempty"`
	AfterEOF    bool                 `json:"after_eof_force_clock,omitempty"`
	RawQuote    *chart.Quote         `json:"raw_quote,omitempty"`
	Scalar      *tape.ScalarQuote    `json:"scalar,omitempty"`
	Reset       *Reset               `json:"reset,omitempty"`
}

type Sink func(Record) error

// Header は公開配送の証拠だけを保持し、金融や自然Sourceの成功を主張しません。
type Header struct {
	Version             int            `json:"version"`
	Scope               string         `json:"scope"`
	Success             bool           `json:"success"`
	Scene               chart.Scene    `json:"scene"`
	Records             int            `json:"records"`
	RawBoards           int            `json:"raw_boards"`
	PositiveNK          int            `json:"positive_nk"`
	Grids               int            `json:"all_board_grids"`
	Publications        int            `json:"publications"`
	ThreePublications   int            `json:"three_publications"`
	Resets              int            `json:"resets"`
	Forces              int            `json:"force_clocks"`
	AfterEOFForces      int            `json:"after_eof_force_clocks"`
	Ending              chart.Snapshot `json:"ending"`
	SkippedGrids        []float64      `json:"skipped_grids"`
	LegacyAllStateMatch bool           `json:"legacy_all_state_match"`
	ForceClockOnly      bool           `json:"force_clock_only"`
	SourceReexecuted    bool           `json:"source_reexecuted"`
	FinancialExecuted   bool           `json:"financial_executed"`
	MarketExecuted      bool           `json:"market_executed"`
}

// stateMatches は停止producerの辞書射影を値から再構成し全Snapshot欄を照合します。
//
// 引数: s(warm.Snapshot)、state(continuous.State)は同位相の公開値と元辞書参照です。
// 返り値: errorは旧全値の不一致です。数値や時計を計算し直しません。
func stateMatches(s warm.Snapshot, state continuous.State) error {
	payload := continuous.Payload{Scene: s.Scene, Chart: s.Chart, Three: s.Three, Fifteen: s.Fifteen, Carried: s.CarriedNumericSeed}
	b, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	sum := sha256.Sum256(b)
	want := continuous.State{PayloadSHA: hex.EncodeToString(sum[:]), At: s.At,
		HasObserved: s.HasObservedClock, Observed: s.ObservedClock,
		HasLast: s.HasLastInput, Last: s.LastInput, Invalidated: s.InvalidatedAt, Sealed: s.Sealed}
	if !reflect.DeepEqual(want, state) {
		return fmt.Errorf("旧Snapshot全field差 at %.9f", s.At)
	}
	return nil
}

// checkForces は当場の予定Source時計だけを検査します。
//
// 引数: req(continuous.Request)、forces([]Force)は場と固定予定参照です。
// 返り値: errorは不足・別時計・重複です。実Source通知の出現証明は別の結合で行います。
func checkForces(req continuous.Request, forces []Force) error {
	expected := []float64{req.Session.ForceClose}
	if req.Session.Kind == "Night" {
		expected = []float64{req.Session.USOpen - 900, req.Session.ForceClose}
	}
	if len(forces) != len(expected) {
		return fmt.Errorf("Force時計集合不足")
	}
	seen := map[int]bool{}
	for i, f := range forces {
		if f.At != expected[i] || f.At < req.Session.Start || f.At >= req.Session.End || f.TapeOrdinal <= 0 || seen[f.TapeOrdinal] || i > 0 && f.TapeOrdinal <= forces[i-1].TapeOrdinal {
			return fmt.Errorf("Force時計/元ordinal不正")
		}
		seen[f.TapeOrdinal] = true
	}
	return nil
}

// Build は既存全board制御を使い、新3分公表とquoteを同じ順のsidecarへ渡します。
//
// 引数: req(continuous.Request)、seed(*Seed)、forces([]Force)、sink(Sink)は公開入力・組の種・Source時計・逐次受け皿です。
// 返り値: Header/*Seed/errorは公開出力の限定証拠・次場種・不正です。Source/金融/ファイルI/Oを呼びません。
func Build(req continuous.Request, seed *Seed, forces []Force, sink Sink) (Header, *Seed, error) {
	return build(req, seed, forces, sink, false)
}

// Warm はSourceTapeやForce元ordinalを要求せず、同じ原行から組の数値種だけを作ります。
//
// 引数: req(continuous.Request)、seed(*Seed)は固定前の公開入力型と前場の組の種です。
// 返り値: *Seed/errorは同じ全board/Lastを通してSealした次場種、又は不正です。成果物・Source・金融を作りません。
func Warm(req continuous.Request, seed *Seed) (*Seed, error) {
	_, next, err := build(req, seed, nil, func(Record) error { return nil }, true)
	return next, err
}

// build は通常配送と純助走を同じ旧pub照合・追加Bank loopへ通します。
//
// 引数: req/seed/forces/sinkはBuildと同型、warmOnly(bool)はSource時計0・出力破棄の助走です。
// 返り値: Header/*Seed/errorは同じ計算の証拠と次種又は不正です。通常BuildのForce検査は省略しません。
func build(req continuous.Request, seed *Seed, forces []Force, sink Sink, warmOnly bool) (Header, *Seed, error) {
	h := Header{Version: 1, Scene: req.Scene, Scope: "全board制御と公開3分値の非市場接続。自然Source/金融/実場の証明なし", ForceClockOnly: true}
	if sink == nil {
		return h, nil, fmt.Errorf("sink必須")
	}
	if warmOnly {
		h.Scope = "全board/Lastの純助走。Source時計/通知/金融成果物なし"
		h.ForceClockOnly = false
		if len(forces) != 0 {
			return h, nil, fmt.Errorf("純助走へSource Force参照を混入")
		}
	} else {
		if err := checkForces(req, forces); err != nil {
			return h, nil, err
		}
	}
	var oldSeed *warm.Seed
	var publicSeed *chart.Seed
	if seed != nil {
		if seed.legacy == nil || seed.public == nil {
			return h, nil, fmt.Errorf("組のSeedが不完全")
		}
		oldSeed, publicSeed = seed.legacy, seed.public
	}
	bank, err := chart.New(req.Scene, publicSeed)
	if err != nil {
		return h, nil, err
	}
	pipeline := delivery.NewPipeline()
	type rowKey struct {
		market string
		line   int64
	}
	rows := map[rowKey]int{}
	for i, row := range req.Rows {
		key := rowKey{row.Board.Reference, row.PhysicalLine}
		if _, exists := rows[key]; exists {
			return h, nil, fmt.Errorf("市場/原行重複")
		}
		rows[key] = i
	}
	all := map[string]int64{}
	pending := []continuous.Trace{}
	fi := 0
	lastAt := req.Session.Start
	emit := func(record Record) error {
		if record.At < lastAt {
			return fmt.Errorf("配送順逆行")
		}
		lastAt = record.At
		h.Records++
		record.Ordinal = h.Records
		return sink(record)
	}
	// ----------------------------------------
	// 全boardの次原行が判明してから、その前の旧timer/gridだけを追加bankへ渡す。
	onRaw := func(id continuous.Identity, state continuous.State, scalar *tape.ScalarQuote) error {
		pos, ok := rows[rowKey{id.Market, id.PhysicalLine}]
		if !ok {
			return fmt.Errorf("市場/物理行出典欠落")
		}
		row := req.Rows[pos]
		if id.Time != row.Board.Time || id.MergeOrdinal != h.RawBoards+1 || id.AllIndex != all[id.Market] {
			return fmt.Errorf("原行/merge/AllIndex出典差")
		}
		if scalar != nil && (id.Market != "NK225" || row.Board.Last <= 0 || id.FeaturesIndex == nil || *id.FeaturesIndex != scalar.Index || scalar.Time != id.Time || scalar.SourceLine != id.PhysicalLine || scalar.Last != row.Board.Last || scalar.Bid != row.Board.Bid || scalar.Ask != row.Board.Ask || scalar.Received != row.Board.Received) {
			return fmt.Errorf("正NK Scalar11出典差")
		}
		grids := []float64{}
		for _, p := range pending {
			if p.Kind == "grid" {
				grids = append(grids, p.At)
			}
		}
		batch, e := bank.AdvanceObserved(id.Time, grids)
		if e != nil {
			return e
		}
		events := []Record{}
		pi := 0
		for _, g := range batch.Grids {
			for pi < len(batch.Publications) && batch.Publications[pi].At <= g.Legacy.At {
				p := batch.Publications[pi]
				events = append(events, Record{Kind: "publication", At: p.At, Publication: &p})
				pi++
			}
			copy := g
			events = append(events, Record{Kind: "grid", At: g.Legacy.At, Grid: &copy})
		}
		for pi < len(batch.Publications) {
			p := batch.Publications[pi]
			events = append(events, Record{Kind: "publication", At: p.At, Publication: &p})
			pi++
		}
		if len(events) != len(pending) {
			return fmt.Errorf("旧全公表/grid集合差")
		}
		for i, event := range events {
			legacy := warm.Snapshot{}
			if event.Publication != nil {
				legacy = event.Publication.Snapshot.Legacy
			} else {
				legacy = event.Grid.Legacy
			}
			if event.Kind != pending[i].Kind || event.At != pending[i].At {
				return fmt.Errorf("旧公表/grid順差")
			}
			if e = stateMatches(legacy, pending[i].Chart); e != nil {
				return e
			}
		}
		pending = nil
		for fi < len(forces) && forces[fi].At <= id.Time {
			copy := forces[fi]
			events = append(events, Record{Kind: "force", At: copy.At, Force: &copy})
			fi++
		}
		rank := map[string]int{"publication": 0, "force": 1, "grid": 2}
		sort.SliceStable(events, func(i, j int) bool {
			return events[i].At < events[j].At || events[i].At == events[j].At && rank[events[i].Kind] < rank[events[j].Kind]
		})
		for _, event := range events {
			copy := id
			event.Trigger = &copy
			switch event.Kind {
			case "publication":
				h.Publications++
				if event.Publication.Three {
					d, er := pipeline.Feed(*event.Publication, event.At)
					if er != nil {
						return er
					}
					event.Delivery = &d
					h.ThreePublications++
				}
			case "grid":
				h.Grids++
			case "force":
				h.Forces++
			}
			if e = emit(event); e != nil {
				return e
			}
		}
		var raw *chart.Quote
		if id.Market == "NK225" {
			q := chart.Quote{Time: id.Time, Index: id.AllIndex, Line: id.PhysicalLine, Last: row.Board.Last, Bid: row.Board.Bid, Ask: row.Board.Ask, Valid: row.Board.Last > 0}
			raw = &q
			after, er := bank.Step(q, nil)
			if er != nil || len(after.Publications)+len(after.Grids) != 0 {
				return fmt.Errorf("同原行二重公表: %v", er)
			}
			if q.Last <= 0 {
				reason := "NK225の不良Last原行で公開窓を失効"
				if er = pipeline.Reset(id.Time, reason); er != nil {
					return er
				}
				if er = emit(Record{Kind: "reset", At: id.Time, Trigger: &id, Reset: &Reset{reason, q}}); er != nil {
					return er
				}
				h.Resets++
			}
		}
		current, e := bank.Snapshot()
		if e != nil {
			return e
		}
		if e = stateMatches(current.Legacy, state); e != nil {
			return e
		}
		kind := "raw_clock"
		if scalar != nil {
			kind = "quote"
			h.PositiveNK++
		}
		if e = emit(Record{Kind: kind, At: id.Time, Trigger: &id, Scalar: scalar, RawQuote: raw}); e != nil {
			return e
		}
		all[id.Market]++
		h.RawBoards++
		return nil
	}
	legacy, nextOld, err := continuous.BuildToSink(req, oldSeed, func(rec continuous.Record) error {
		if rec.Kind == "row" && rec.Row != nil && rec.Control == nil {
			copy := rec.Row.Scalar
			return onRaw(rec.Row.Identity, rec.Row.Chart, &copy)
		}
		if rec.Kind != "control" || rec.Control == nil || rec.Row != nil {
			return fmt.Errorf("停止producerの出力型差")
		}
		tr := *rec.Control
		if tr.Kind == "publication" || tr.Kind == "grid" {
			pending = append(pending, tr)
			return nil
		}
		if tr.Kind != "raw" || tr.Identity == nil {
			return fmt.Errorf("旧制御型不正")
		}
		return onRaw(*tr.Identity, tr.Chart, nil)
	})
	if err != nil {
		return h, nil, err
	}
	if len(pending) != 0 || h.RawBoards != len(req.Rows) || h.PositiveNK != legacy.RowCount || h.Grids != len(legacy.Grids) {
		return h, nil, fmt.Errorf("全board/quote/grid完全集合差")
	}
	// ----------------------------------------
	// EOF後はSource時計参照だけを残す。bankを進めて公表/MTMを作らない。
	for fi < len(forces) {
		copy := forces[fi]
		if err = emit(Record{Kind: "force", At: copy.At, Force: &copy, AfterEOF: true}); err != nil {
			return h, nil, err
		}
		h.Forces++
		h.AfterEOFForces++
		fi++
	}
	seedNew, ending, err := bank.Seal()
	if err != nil {
		return h, nil, err
	}
	if err = stateMatches(ending.Legacy, legacy.Ending); err != nil {
		return h, nil, err
	}
	h.Ending, h.SkippedGrids = ending, append([]float64{}, legacy.SkippedGrids...)
	h.Success, h.LegacyAllStateMatch = true, true
	return h, &Seed{nextOld, &seedNew}, nil
}
