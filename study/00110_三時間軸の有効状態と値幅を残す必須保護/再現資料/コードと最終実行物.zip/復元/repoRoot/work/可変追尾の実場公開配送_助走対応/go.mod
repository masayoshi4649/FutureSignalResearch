module github.com/masayoshi4649/SessionTradeExecuter/publicsidecar

go 1.24.0

require (
 github.com/masayoshi4649/SessionTradeExecuter/mininative v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/miniprotect v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter v0.0.0
 github.com/BurntSushi/toml v1.5.0
 github.com/expr-lang/expr v1.17.8
)

replace github.com/masayoshi4649/SessionTradeExecuter/mininative => ../../scripts/FAR元三手法のmini連続再現
replace github.com/masayoshi4649/SessionTradeExecuter => ../../../SessionTradeExecuter

replace github.com/masayoshi4649/SessionTradeExecuter/miniprotect => ../../scripts/FAR連続出生と個別利益追尾

require (
 github.com/masayoshi4649/SessionTradeExecuter/minigrid v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/chartwarmup96 v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/research80 v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/research81 v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/research82 v0.0.0
)
replace github.com/masayoshi4649/SessionTradeExecuter/minigrid => ../../scripts/FAR5分判断と出生一回
replace github.com/masayoshi4649/SessionTradeExecuter/chartwarmup96 => ../../scripts/複数尺度チャートの助走
replace github.com/masayoshi4649/SessionTradeExecuter/research80 => ../../scripts/FAR後期15分移植
replace github.com/masayoshi4649/SessionTradeExecuter/research81 => ../../scripts/定時の現在根拠と部分利益保護
replace github.com/masayoshi4649/SessionTradeExecuter/research82 => ../../scripts/チャートの現在性と補助確認

require github.com/masayoshi4649/SessionTradeExecuter/minichart v0.0.0
replace github.com/masayoshi4649/SessionTradeExecuter/minichart => ../../scripts/FAR5分枠の順行反転と数量

require github.com/masayoshi4649/SessionTradeExecuter/miniharvest v0.0.0
replace github.com/masayoshi4649/SessionTradeExecuter/miniharvest => ../../scripts/FAR初回利益確定

require github.com/masayoshi4649/SessionTradeExecuter/minirisk98 v0.0.0
replace github.com/masayoshi4649/SessionTradeExecuter/minirisk98 => ../../scripts/FAR利益前ATR追尾

require github.com/masayoshi4649/SessionTradeExecuter/minie3 v0.0.0
replace github.com/masayoshi4649/SessionTradeExecuter/minie3 => ../../scripts/FAR背景と勢いと数量の純判定

require github.com/masayoshi4649/SessionTradeExecuter/minientry99 v0.0.0
replace github.com/masayoshi4649/SessionTradeExecuter/minientry99 => ../../scripts/FAR背景と勢いと数量の入口

require github.com/masayoshi4649/SessionTradeExecuter/minigrossguard100 v0.0.0
replace github.com/masayoshi4649/SessionTradeExecuter/minigrossguard100 => ../../scripts/FAR利益化前後の保護

require github.com/masayoshi4649/SessionTradeExecuter/minix5 v0.0.0
replace github.com/masayoshi4649/SessionTradeExecuter/minix5 => ../../scripts/保有の3分複合失効の純式

require github.com/masayoshi4649/SessionTradeExecuter/minishortexit v0.0.0
replace github.com/masayoshi4649/SessionTradeExecuter/minishortexit => ../../scripts/短秒進行と現在量の退出

require github.com/masayoshi4649/SessionTradeExecuter/minishortfinance v0.0.0
replace github.com/masayoshi4649/SessionTradeExecuter/minishortfinance => ../../scripts/短秒の複合退出の会計

require github.com/masayoshi4649/SessionTradeExecuter/minidelayed103 v0.0.0
replace github.com/masayoshi4649/SessionTradeExecuter/minidelayed103 => ../103多玉の保護会計

require github.com/masayoshi4649/SessionTradeExecuter/minivariableguard v0.0.0
replace github.com/masayoshi4649/SessionTradeExecuter/minivariableguard => ../収束可変幅の保護会計案
require github.com/masayoshi4649/SessionTradeExecuter/publicchart v0.0.0
replace github.com/masayoshi4649/SessionTradeExecuter/publicchart => ../可変追尾向けの公開チャート

require (
 github.com/masayoshi4649/SessionTradeExecuter/publicdelivery v0.0.0
 github.com/masayoshi4649/SessionTradeExecuter/continuous101 v0.0.0
)
replace github.com/masayoshi4649/SessionTradeExecuter/publicdelivery => ../収束可変幅の公開配送案
replace github.com/masayoshi4649/SessionTradeExecuter/continuous101 => ../../scripts/保護判断の連続技法入力

require github.com/masayoshi4649/SessionTradeExecuter/lighttape97 v0.0.0
replace github.com/masayoshi4649/SessionTradeExecuter/lighttape97 => ../../scripts/固定通知と価格行の再生
