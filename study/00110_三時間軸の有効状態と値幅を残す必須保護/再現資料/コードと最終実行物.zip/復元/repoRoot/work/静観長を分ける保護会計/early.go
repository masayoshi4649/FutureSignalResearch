package miniquietlength108

import (
	"fmt"
	"math"
)

// EarlyActivationAudit は最初の実起動を通常LD10と警戒早期へ分ける別auditです。
type EarlyActivationAudit struct {
	PositionID         string            `json:"position_id"`
	Policy             ActivationPolicy  `json:"policy"`
	Trigger            string            `json:"trigger"`
	Point              MTMPoint          `json:"point"`
	ATRValue           float64           `json:"atr_value"`
	EarlyThresholdYen  float64           `json:"early_threshold_yen"`
	NormalThresholdYen float64           `json:"normal_threshold_yen"`
	Warning            WidthTruth        `json:"warning"`
	Observation        *WidthObservation `json:"observation"`
}

// EarlyBookAudit は旧WidthAuditを増減せず新政策だけの起動出典を返します。
type EarlyBookAudit struct {
	Policy    ActivationPolicy       `json:"policy"`
	Positions []EarlyActivationAudit `json:"positions"`
}

// isEarlyActivation は明示したE政策だけを認識します。
//
// 引数: policy(ActivationPolicy)は公開enum。返り値: boolはE1/E2だけ真です。
func isEarlyActivation(policy ActivationPolicy) bool {
	return policy == ActivationE1 || policy == ActivationE2
}

// NewEarlyBook はE1/E2をConfig/Keyへそのまま固定する専用constructorです。
//
// 引数: session(Session)、cfg(ActorConfig)、contract(string)は元B5Q/P0条件とE1/E2・外部限月。
// 返り値: *ActualBook/errorは新政策又は未比較の組合せです。LD10へ偽装しません。
func NewEarlyBook(session Session, cfg ActorConfig, contract string) (*ActualBook, error) {
	if !isEarlyActivation(cfg.ActivationPolicy) || contract == "" || cfg.Policy != "P0" || !quietEntryTiming(cfg.EntryTiming) || cfg.GatePolicy != "" || cfg.HarvestPolicy != "" || cfg.RiskPolicy != "" || cfg.ExitPolicy != "" {
		return nil, fmt.Errorf("E1/E2はGate/Risk/Harvest/Exit空のB5Q/P0専用")
	}
	b, e := newActualBook(session, cfg, "")
	if e != nil {
		return nil, e
	}
	b.widthBook = &widthBook{Policy: string(cfg.ActivationPolicy), Contract: contract, Latest: map[int]*WidthObservation{}, Last: map[int]*WidthObservation{}, Positions: map[string]*widthPosition{}, Activations: map[string]EarlyActivationAudit{}}
	return b, nil
}

// earlyExitReason は新enumと可変幅の意味を注文理由にも明示します。
//
// 引数: policy(ActivationPolicy)はE1/E2。返り値: stringは最低名目建値と非緩和の共通保護理由です。
func earlyExitReason(policy ActivationPolicy) string {
	return string(policy) + "一定利益と収束警戒による名目建値床と非緩和追尾"
}

// activateProtection は旧Wの全JSONを保ち、Eだけに警戒早期ORを加えます。
//
// 引数: p(*ActualPosition)、point(MTMPoint)は旧会計の同じ正常markです。
// 返り値: errorは設定/公表時計差です。Source/数量/費用/注文を操作しません。
func (b *ActualBook) activateProtection(p *ActualPosition, point MTMPoint) error {
	if p.ProtectionActive {
		return nil
	}
	policy := b.result.Config.ActivationPolicy
	if !isEarlyActivation(policy) {
		if activationEligible(policy, p.ATR, point.UnitNet) {
			p.ProtectionActive = true
			p.Activation = widthPointer(valueCopy(point))
			p.ActivationReason = activationReason(policy)
		}
		return nil
	}
	w := b.widthBook
	if w == nil || w.Policy != string(policy) || w.Activations == nil {
		return fmt.Errorf("E政策の専用公表境界がありません")
	}
	if w.HaveClock && w.At > point.Quote.Time {
		return fmt.Errorf("E起動より未来の配送時計")
	}
	o := w.Latest[p.Side]
	warning := WidthTruth{}
	if o != nil {
		if o.End > point.Quote.Time || o.AvailableAt > point.Quote.Time {
			return fmt.Errorf("E起動より未来の公表")
		}
		warning = widthAnd(o.C, o.M)
		if policy == ActivationE2 {
			warning = widthAnd(o.C, o.M, o.P)
		}
	}
	normal := activationEligible(ActivationLD10, p.ATR, point.UnitNet)
	early := !normal && activationEligible(ActivationLD05, p.ATR, point.UnitNet) && warning.Known && *warning.Passed
	if !normal && !early {
		return nil
	}
	p.ProtectionActive = true
	p.Activation = widthPointer(valueCopy(point))
	trigger := "normal_ld10"
	p.ActivationReason = string(policy) + "通常LD10水準到達で保護起動"
	if early {
		trigger = "early_warning"
		p.ActivationReason = string(policy) + "LD05水準と既知収束失速警戒で早期保護起動"
	}
	w.Activations[p.ID] = EarlyActivationAudit{PositionID: p.ID, Policy: policy, Trigger: trigger, Point: valueCopy(point), ATRValue: p.ATR.Value, EarlyThresholdYen: 100 * math.Max(10, .5*p.ATR.Value), NormalThresholdYen: 100 * math.Max(10, p.ATR.Value), Warning: valueCopy(warning), Observation: valueCopy(o)}
	return nil
}

// EarlyAudit は初回起動MTMと公表根拠を旧Book/WidthAuditの外で返します。
//
// 引数: ありません。返り値: EarlyBookAuditは全pointerを独立copyした出典です。
func (b *ActualBook) EarlyAudit() EarlyBookAudit {
	out := EarlyBookAudit{Policy: b.result.Config.ActivationPolicy, Positions: []EarlyActivationAudit{}}
	if !isEarlyActivation(out.Policy) || b.widthBook == nil {
		return out
	}
	for _, p := range b.result.Positions {
		if a, ok := b.widthBook.Activations[p.ID]; ok {
			out.Positions = append(out.Positions, valueCopy(a))
		}
	}
	return out
}
