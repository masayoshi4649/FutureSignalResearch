"""103の多玉・部分返済の保存算術を検算し、参加率とViewer資料を作る。"""

import argparse
from collections import Counter, defaultdict
import copy
from datetime import date, timedelta
from decimal import Decimal
import gzip
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import types


ROOT = Path(__file__).resolve().parents[2]
GRID_PATH = ROOT / "scripts/FAR5分判断と出生一回の監査/集計.py"
GRID_SHA = "193acf7f0ddcd6b532b52d7ac7a105e2a1f61905bb97368dfeb79c177c5f5395"
if hashlib.sha256(GRID_PATH.read_bytes()).hexdigest() != GRID_SHA:
    raise ValueError("固定95保存規範のSHA差")
SPEC = importlib.util.spec_from_file_location("103で再用する固定95", GRID_PATH)
GRID = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(GRID)
BASE = GRID.BASE
need, equal, number, integer = BASE.require, BASE.equal, BASE.number, BASE.integer
POINT, FEE, ZERO = BASE.POINT, BASE.FEE, BASE.ZERO
MAIN_KEYS = tuple(("" if a == "" else a + "_") + f"B5Q_P0_C{c}_D{d}"
                  for a in ("", "LD05", "LD10") for c in (0, 5) for d in (0, 1))
DIAGNOSTIC_KEYS = tuple(f"B5Q_S0_C{c}_D{d}" for c in (0, 5) for d in (0, 1))
KEYS = MAIN_KEYS + DIAGNOSTIC_KEYS
REASONS = {"LD05": "費用後残玉単価が10pt又は取得ATRの0.5倍以上で保護起動",
           "LD10": "費用後残玉単価が10pt又は取得ATRの1倍以上で保護起動"}


def digest(path):
    """
    機能: 通常ファイルの指紋を得る。
    引数: path(Path)は明示されたコード又は保存入力。
    返り値: strはSHA256。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    """
    機能: 半円をDecimalで保ちJSON又はgzipを読む。
    引数: path(Path)はRoot許可済み入力。
    返り値: dictはJSON値。金融を再運転しない。
    """
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8-sig") as stream:
        return json.load(stream, parse_float=Decimal)


def config_for(key):
    """
    機能: 16本名を基本政策・起動政策・費用・遅延に対応する。
    引数: key(str)は固定された口座名。
    返り値: tupleはpolicy/activation/cost/delay。
    """
    need(key in KEYS, "103口座名")
    activation = "LD05" if key.startswith("LD05_") else "LD10" if key.startswith("LD10_") else ""
    return ("S0" if key in DIAGNOSTIC_KEYS else "P0", activation,
            int(key[-4]), int(key[-1]))


def configurations():
    """
    機能: runtimeの主12・診断4の順に設定を作る。
    引数: なし。
    返り値: list[dict]は条件照合用の16設定。
    """
    return [{"policy": p, "activation_policy": a, "slip_pts": c, "delay_seconds": d}
            for key in KEYS for p, a, c, d in [config_for(key)]]


def grid_key_config(key):
    """
    機能: 旧95の時計規範へ103の本名を明示対応する。
    引数: key(str)は16口座名。
    返り値: tupleは旧関数が要求するtiming/base_key/cost/delay。
    """
    p, _, c, d = config_for(key)
    return "B5Q", f"{p}_C{c}_D{d}", c, d


# ----------------------------------------
# 旧関数の本文を保ち、名前空間の口座名対応だけを独立複写する。
GRID_SPACE = dict(vars(GRID))
for _name, _function in vars(GRID).items():
    if isinstance(_function, types.FunctionType) and _function.__module__ == GRID.__name__:
        GRID_SPACE[_name] = types.FunctionType(_function.__code__, GRID_SPACE, _name,
                                               _function.__defaults__, _function.__closure__)
GRID_SPACE["key_config"] = grid_key_config


def verify_activation(position, timeline, policy, activation):
    """
    機能: 保存した起動を旧初正益又はLD閾値へ結び、両旗を混ぜない。
    引数: position(dict)、timeline(Timeline)、policy/activation(str)は実玉と固定設定。
    返り値: None。初回の全原行取り落としを証明するものではない。
    """
    reason = position.get("activation_reason", "")
    if not activation:
        need(not reason, "旧政策にLD理由")
    elif position["protection_active"]:
        equal(reason, REASONS[activation], "LD起動理由")
    else:
        need(not reason, "未起動にLD理由")
    if policy == "S0":
        need(not position["protection_active"], "S0は診断用無保護")
        return
    atr = position["atr"]
    observed = list(position["marks"].values())
    factor = 0.5 if activation == "LD05" else 1.0
    threshold = 100.0 * max(10.0, factor * float(number(atr["value"], "ATR.Value"))) if activation and atr else None
    for saved in observed:
        if saved is None:
            continue
        eligible = saved["unit_net"] > 0 if not activation else (
            atr is not None and saved["quote"]["index"] >= atr["quote"]["index"]
            and float(number(saved["unit_net"], "保存単価円")) >= threshold)
        if eligible:
            need(position["protection_active"] and position["activation"] is not None, "保存適格点があるのに未起動")
            need(BASE.point_order(position["activation"]) <= BASE.point_order(saved), "保存された適格点より遅い起動")
    if not position["protection_active"]:
        return
    point = position["activation"]
    need(point is not None and point["unit_net"] > 0, "起動単価はstrict正")
    first = position["marks"]["first_unit_positive"]
    need(first is not None and BASE.point_order(first) <= BASE.point_order(point), "初正益と遅延起動の順")
    if not activation:
        equal(point, first, "旧P0の初正益即起動")
    else:
        need(atr is not None and atr["quote"]["index"] <= point["quote"]["index"], "LD起動までのATR固定")
        need(float(number(point["unit_net"], "起動単価円")) >= threshold, "LD起動閾値の元IEEE64")


def verify_marks(position, timeline, policy, activation):
    """
    機能: 固定94の保存点・符号・極値を再用し、起動仮定だけ103へ置換する。
    引数: position(dict)、timeline(Timeline)、policy/activation(str)は玉と政策。
    返り値: None。金額の許容を広げずATR/時計だけ元IEEE64へ対応する。
    """
    def point_equal(actual, expected, label):
        """
        機能: 旧起動等式をLD専用規範へ置換し、ATRだけ演算の由来を保つ。
        引数: actual/expected(any)、label(str)はSHA固定した旧関数内の照合。
        返り値: None。他の保存点・金額比較は旧厳密規範へ渡す。
        """
        if label == "起動と単価正益初回":
            verify_activation(position, timeline, policy, activation)
        elif label == "ATR age":
            atr = position["atr"]
            equal(actual, GRID.clock_delta(atr["quote"]["time"], atr["available"]), "ATR ageの元IEEE64")
        elif label == "2ATR幅":
            width = 5.0 * math.ceil(2.0 * float(position["atr"]["value"]) / 5.0)
            need(float(number(actual, "ATR幅")) == width, "ATR幅の元IEEE64")
        else:
            equal(actual, expected, label)
    namespace = {**vars(BASE), "equal": point_equal}
    types.FunctionType(BASE.verify_marks.__code__, namespace, "103の保存点規範")(position, timeline, policy)
    verify_activation(position, timeline, policy, activation)
    if position["protection_active"]:
        atr = position["atr"]
        expected = max(0.0, float(position["peak_gain"]) - float(atr["width"])) if atr else 0.0
        need(float(number(position["floor_gain"], "最終床")) == expected, "固定幅と観測peakの最終床")


def verify_book(book, key, full_clock=False):
    """
    機能: 旧部分所有・配賦・Source・gridを保ち103の設定と起動を照合する。
    引数: book(dict)、key(str)、full_clock(bool)は保存口座と予定prefix検査指定。
    返り値: dictは旧保存規範の検算済み台帳。元入力は書き換えない。
    """
    policy, activation, cost, delay = config_for(key)
    cfg = {"policy": policy, "slip_pts": cost, "delay_seconds": delay, "entry_timing": "B5Q", "us_open": book["session"]["us_open"]}
    if activation:
        cfg["activation_policy"] = activation
    equal(book["key"], key, "103 key")
    equal(book["config"], cfg, "103設定本名")
    need(not book.get("held_exit_grids") and not book.get("short_exit_events") and not book.get("short_exit_contract"), "未使用退出の証拠混入")
    for p in book["positions"] or []:
        need(not p.get("initial_risk") and not p.get("gross_guard"), "未使用Risk/HG状態")
    for o in book["orders"] or []:
        need(not any(o.get(k) for k in ("initial_risk_point", "gross_guard_point", "held_exit_point", "short_exit_point")), "未使用退出注文")
    previous_quote = None
    by_order = {o["id"]: o for o in book["orders"] or []}
    for f in book["fills"] or []:
        q, request = f["quote"], by_order[f["order_id"]]["request_quote"]
        need(q["source_line"] > request["source_line"], "要求と同じ/過去物理行のfill")
        if previous_quote is not None:
            need(all(q[k] >= previous_quote[k] for k in ("time", "index", "source_line")), "Fillの時計/特徴Index/物理行逆行")
            if q["index"] == previous_quote["index"]: equal(q, previous_quote, "同原行のFill quote")
        previous_quote = q
    original_positions = {p["id"]: p for p in book["positions"] or []}
    need(len(original_positions) == len(book["positions"] or []), "Position重複")
    proxy = copy.deepcopy(book)
    for field in ("entry_opportunities", "grid_traces", "grid_metrics"):
        proxy.pop(field)
    proxy["config"] = {"policy": policy, "slip_pts": cost, "delay_seconds": delay}
    proxy["key"] = f"{policy}_C{cost}_D{delay}"
    for p in proxy["positions"] or []:
        p.pop("activation_reason", None)
    def source_validator(projected, orders, timeline):
        """
        機能: 旧95のSource比例返済と出生一枠規範を元の保存通知へ適用する。
        引数: projected/ orders(dict)、timeline(Timeline)は固定94からの引数。
        返り値: None。受付や通知の偽イベントを生成しない。
        """
        GRID_SPACE["verify_source_b"](book, orders, timeline)
    def marks_validator(position, timeline, intrinsic):
        """
        機能: 旧金融共通検算から103の元玉の保存点検算へ接続する。
        引数: position(dict)、timeline(Timeline)、intrinsic(str)は旧関数の引数。
        返り値: None。optional出典は元玉に残したまま検査する。
        """
        verify_marks(original_positions[position["id"]], timeline, intrinsic, activation)
    namespace = {**vars(BASE), "verify_source_events": source_validator, "verify_marks": marks_validator}
    checked = types.FunctionType(BASE.verify_book.__code__, namespace, "103の共通部分会計")(proxy, proxy["key"])
    source_orders = {e["order_id"] for e in book["source_events"] if e["kind"] == "close_notice" and e["order_id"]}
    equal(source_orders, {o["id"] for o in book["orders"] if o["kind"] == "exit" and o["protection_point"] is None}, "全Source返済要求と保存noticeの結合")
    GRID_SPACE["verify_grid"](book, checked["orders"], checked["timeline"], full_clock)
    return {**checked, "book": book, "positions": original_positions}


def participation(book, checked, end_mode="force"):
    """
    機能: 全予定分母で同枠実取得＋当grid保有の保守的参加を数える。
    引数: book/checked(dict)、end_mode(str)はforce又はend30。
    返り値: dictは4分類と受理/遅い取得/実fill bucketの別列。
    """
    session = book["session"]
    end = session["force_close"] if end_mode == "force" else session["end"] - 1800
    clocks = list(range(int(session["start"]) + 1800, int(end), 300))
    traces = {t["at"]: t for t in book["grid_traces"]}
    orders = checked["orders"]
    entry_fill = {f["order_id"]: f for f in book["fills"] if f["action"] == "new"}
    accepted = defaultdict(list)
    for p in book["entry_opportunities"]:
        if p["status"] == "accepted":
            accepted[p["evaluated_at"]].append(p["entry_order_id"])
    count = Counter()
    for at in clocks:
        trace = traces.get(at)
        ids = accepted.get(at, [])
        count["受理new"] += bool(ids)
        count["後の取得を戻したnew"] += any(i in entry_fill for i in ids)
        count["実fill時刻bucket"] += any(at <= f["quote"]["time"] < at + 300 for f in entry_fill.values())
        count["遅い取得の要求枠"] += any(i in entry_fill and entry_fill[i]["quote"]["time"] >= at + 300 for i in ids)
        if trace is None:
            count["unknown"] += 1
            count["欠測"] += 1
            continue
        held = trace["open_buy"] + trace["open_sell"] > 0
        new = any(i in entry_fill and at <= entry_fill[i]["quote"]["time"] < at + 300 for i in ids)
        count["同枠取得new"] += new
        count["当時実保有"] += held
        action = "new" if new else "hold" if held else "unknown" if trace["unknown_count"] else "wait"
        count[action] += 1
        count["USquiet"] += trace["us_quiet"] is True
    count["denom"] = len(clocks)
    count["active"] = count["new"] + count["hold"]
    need(count["active"] + count["wait"] + count["unknown"] == count["denom"], "参加4分類の全予定分母")
    return {k: count[k] for k in ("denom", "active", "new", "hold", "wait", "unknown", "同枠取得new", "当時実保有", "受理new", "後の取得を戻したnew", "実fill時刻bucket", "遅い取得の要求枠", "欠測", "USquiet")}


def freeze(value):
    """
    機能: 公開Sourceやquoteの全値を衝突なく比較可能にする。
    引数: value(any)はJSON値。
    返り値: tuple又はscalar。IDの文字列分割をしない。
    """
    if isinstance(value, dict):
        return tuple((k, freeze(v)) for k, v in sorted(value.items()))
    if isinstance(value, list):
        return tuple(freeze(v) for v in value)
    return value


def entry_fingerprint(position, orders):
    """
    機能: 同Sourceの実要求と実取得の全公開属性を結ぶ。
    引数: position(dict)、orders(dict)は玉と注文写像。
    返り値: tupleは要求時計/quote・取得quote/価格/方向/量。
    """
    o = orders[position["entry_order_id"]]
    return (o["request_time"], freeze(o["request_quote"]), freeze(position["entry_quote"]),
            position["entry_price"], position["side"], position["initial_quantity"], position["source_hold_id"])


def compare_positions(before, after):
    """
    機能: Source全値一致から同実入口退出差・取得変更・片側実参加を分ける。
    引数: before/after(dict)は保存検算済み口座。
    返り値: dictは実現差の加法分解。未参加の仮想利益を作らない。
    """
    aa = {freeze(p["source"]): p for p in before["positions"].values()}
    bb = {freeze(p["source"]): p for p in after["positions"].values()}
    need(len(aa) == len(before["positions"]) and len(bb) == len(after["positions"]), "同Sourceの実参加一意")
    result = Counter()
    for source in aa.keys() | bb.keys():
        a, b = aa.get(source), bb.get(source)
        if a is None:
            result["後のみ玉"] += 1; result["後のみ実現額"] += b["realized_net"]
        elif b is None:
            result["前のみ玉"] += 1; result["前のみ実現額"] += a["realized_net"]
        else:
            kind = "同実入口" if entry_fingerprint(a, before["orders"]) == entry_fingerprint(b, after["orders"]) else "取得変更"
            result[kind + "玉"] += 1
            result[kind + "差額"] += b["realized_net"] - a["realized_net"]
    result["全差額"] = after["totals"]["net_yen"] - before["totals"]["net_yen"]
    equal(result["全差額"], result["同実入口差額"] + result["取得変更差額"] - result["前のみ実現額"] + result["後のみ実現額"], "実参加差の加法分解")
    return {k: result[k] for k in ("全差額", "同実入口玉", "同実入口差額", "取得変更玉", "取得変更差額", "前のみ玉", "前のみ実現額", "後のみ玉", "後のみ実現額")}


def summarize_book(book, checked):
    """
    機能: 完結玉だけから実現正負・起動別損失と保存DDの連結材料を作る。
    引数: book/checked(dict)は保存正本と検算結果。
    返り値: dictは小型場別集計。全Bookをレポートへ転記しない。
    """
    row = {**checked["totals"], **checked["counts"]}
    positions = checked["positions"].values()
    row.update(positive_yen=ZERO, negative_yen=ZERO, positive_positions=0, negative_positions=0, zero_positions=0,
               unit_positive_closed_negative_yen=ZERO, activated_closed_negative_yen=ZERO, unit_unobserved_closed_negative_yen=ZERO)
    for p in positions:
        net = p["realized_net"]
        row["positive_yen"] += max(ZERO, net); row["negative_yen"] += min(ZERO, net)
        row["positive_positions"] += net > 0; row["negative_positions"] += net < 0; row["zero_positions"] += net == 0
        if net < 0:
            row["unit_positive_closed_negative_yen" if p["marks"]["first_unit_positive"] is not None else "unit_unobserved_closed_negative_yen"] += net
            if p["protection_active"]: row["activated_closed_negative_yen"] += net
    account = book["account"]
    row["場内時価DD"] = account["max_drawdown"]
    row["保存最大時価"] = account["max"]["equity"] if account["max"] else ZERO
    row["保存最小時価"] = account["min"]["equity"] if account["min"] else ZERO
    row["活動主表"] = participation(book, checked)
    row["活動副表"] = participation(book, checked, "end30")
    row["売買別"] = {str(s): {"玉": sum(p["side"] == s for p in checked["positions"].values()),
                                "枚": sum(p["initial_quantity"] for p in checked["positions"].values() if p["side"] == s),
                                "純額": sum((p["realized_net"] for p in checked["positions"].values() if p["side"] == s), ZERO)} for s in (1, -1)}
    row["注文別"] = {}
    for name in ("Source", "保護"):
        selected = {i: o for i, o in checked["orders"].items() if o["kind"] == "exit" and (o["protection_point"] is not None) == (name == "保護")}
        fills = [f for f in book["fills"] if f["order_id"] in selected]
        row["注文別"][name] = {"要求": len(selected), "要求枚": sum(o["quantity"] for o in selected.values()), "約定": len(fills), "約定枚": sum(f["quantity"] for f in fills),
                                 "返済片純額": sum((a["net_yen"] for f in fills for a in f["allocations"]), ZERO)}
    equal(sum((r["返済片純額"] for r in row["注文別"].values()), ZERO), row["net_yen"], "Source/保護の全実現額分解")
    return row


def combine(rows):
    """
    機能: flatな場別保存統計を連結し、共通分母とPF/DDを集約する。
    引数: rows(list[dict])は時系列の小型場別集計。
    返り値: dictは実現集計。DDは保存極値の連結でありRaw再監査ではない。
    """
    result = Counter()
    for row in rows:
        for name, amount in row.items():
            if type(amount) in (int, float, Decimal) and name not in ("場内時価DD", "保存最大時価", "保存最小時価"):
                result[name] += amount
    output = dict(result)
    output["PF"] = result["positive_yen"] / -result["negative_yen"] if result["negative_yen"] < 0 else None
    carry = peak = dd = ZERO
    for row in rows:
        dd = max(dd, row["場内時価DD"], peak - (carry + row["保存最小時価"]))
        peak = max(peak, carry + row["保存最大時価"])
        carry += row["net_yen"]
    output["保存点連結時価DD"] = dd
    for label in ("活動主表", "活動副表"):
        active = Counter()
        for row in rows: active.update(row[label])
        d = dict(active)
        d["参加率"] = Decimal(d.get("active", 0)) / d["denom"] if d.get("denom") else None
        d["最低25%"] = bool(d.get("denom")) and 4 * d.get("active", 0) >= d["denom"]
        d["目標50%"] = bool(d.get("denom")) and 2 * d.get("active", 0) >= d["denom"]
        output[label] = d
    for label in ("売買別", "注文別"):
        groups = defaultdict(Counter)
        for row in rows:
            for k, r in row[label].items(): groups[k].update(r)
        output[label] = {k: dict(r) for k, r in groups.items()}
    return output


def inspect_scene(value, full_clock=False):
    """
    機能: 16口座の集合・全保存金融・同じgrid配送を検査する。
    引数: value(dict)はruntime又はGo型人工、full_clock(bool)は正式prefix指定。
    返り値: dictはkeyごとの検算済み台帳。
    """
    books = value.get("books", value.get("actors"))
    equal(set(books), set(KEYS), "103全16口座")
    checked = {}
    reference = None
    for key in KEYS:
        checked[key] = verify_book(books[key], key, full_clock)
        clocks = [t["at"] for t in books[key]["grid_traces"]]
        if reference is None: reference = clocks
        else: equal(clocks, reference, "同Replayの16grid列")
    if "grid_times" in value: equal(value["grid_times"], reference, "配送済みgrid列")
    return checked


def prepare(fixed_path, fixed_sha, out):
    """
    機能: Rootの3FileRef・同条件全54成功をNative読取前に確認する。
    引数: fixed_path/out(Path)、fixed_sha(str)はRoot固定と新規保存先。
    返り値: tupleは場task・前指紋・証拠。架空の別engine成功を要求しない。
    """
    need(not out.exists(), "保存先は新規")
    equal(digest(fixed_path), fixed_sha, "Root固定SHA")
    fixed = load(fixed_path)
    need(fixed["version"] == 1 and fixed["trial"] == 103 and fixed["fixed"] is True and fixed["stage"] == "full54", "Root固定が必要")
    paths, before = {}, {str(fixed_path): fixed_sha, str(GRID_PATH): GRID_SHA, str(GRID.BASE_PATH): GRID.BASE_SHA}
    for name in ("condition", "completion", "code"):
        ref = fixed[name]; p = Path(ref["path"])
        p = (p if p.is_absolute() else fixed_path.parent / p).resolve()
        need(len(ref["sha256"]) == 64 and digest(p) == ref["sha256"], name + "SHA")
        paths[name] = p; before[str(p)] = ref["sha256"]
    equal(paths["code"], Path(__file__).resolve(), "実保存code")
    condition, done = load(paths["condition"]), load(paths["completion"])
    need(condition["version"] == 1 and condition["trial"] == 103 and condition["fixed"] is True, "条件103固定")
    equal(condition["configs"], configurations(), "条件16設定")
    need(done["success"] is True and done["version"] == 1 and done["trial"] == 103 and done["stage"] == "full54"
         and done["scenes"] == 54 and done["books_per_scene"] == 16 and done["books"] == 864
         and done["main_books"] == 648 and done["diagnostic_books"] == 216 and not done.get("error"), "金融全54成功")
    equal(done["condition_sha256"], fixed["condition"]["sha256"], "同条件")
    equal(done["configs"], configurations(), "完了16設定")
    need(done["input_code_unchanged"] is True and done["input_code_sha256_before"] == done["input_code_sha256_after"]
         and done["source_reexecuted"] is False and done["charts_recomputed"] is False
         and done["gate_executed"] is False and done["raw_csv_read"] == 0, "入力code前後と再用範囲")
    sessions = []; day = date(2026, 9, 21)
    while day <= date(2026, 10, 27):
        if day.weekday() < 5: sessions.extend(f"{day.isoformat()}_{kind}" for kind in ("Day", "Night"))
        day += timedelta(days=1)
    tasks = copy.deepcopy(done["results"])
    equal([x["session"] for x in tasks], sessions, "完全54場")
    equal([x["session"] for x in condition["scenes"]], sessions, "条件54場")
    for name, h in condition["code_sha256"].items():
        p = (ROOT / name).resolve()
        need(digest(p) == h and done["input_code_sha256_before"].get(str(p)) == h, "固定実行code差")
        before[str(p)] = h
    for task in tasks:
        need(task["books"] == 16 and not task.get("error") and set(task["totals"]) == set(KEYS), "場別全16完了")
        p = Path(task["path"])
        p = (p if p.is_absolute() else paths["completion"].parent / p).resolve()
        need(p.name == task["session"] + ".json.gz" and digest(p) == task["sha256"], "新NativeSHA")
        task["resolved_path"] = p; before[str(p)] = task["sha256"]
    proofs = {"Root固定SHA256": fixed_sha, **{name + "SHA256": fixed[name]["sha256"] for name in paths}}
    return tasks, before, proofs


def main():
    """
    機能: 成功した保存金融だけから検算・集計・全実FillのViewer資料を作る。
    引数: CLI --fixed/--fixed-sha/--outはRoot固定と新規先。
    返り値: None。Source/金融/Raw/HTTPを実行しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixed", type=Path, required=True); parser.add_argument("--fixed-sha", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    tasks, before, proofs = prepare(args.fixed.resolve(), args.fixed_sha, args.out)
    by_key, resources, scene_rows, refs = {k: [] for k in KEYS}, [], [], []
    comparisons = defaultdict(list)
    args.out.mkdir(parents=True)
    for task in tasks:
        value = load(task["resolved_path"])
        need(value["version"] == 1 and value["trial"] == 103 and value["complete"] is True and value["input_unchanged"] is True
             and value["source_reexecuted"] is False and value["charts_recomputed"] is False and value["gate_executed"] is False, "新Native再用範囲")
        equal(value["session"]["id"], task["session"], "Native場")
        equal(value["main_keys"], list(MAIN_KEYS), "主12本名"); equal(value["diagnostic_keys"], list(DIAGNOSTIC_KEYS), "S0診断4")
        checked = inspect_scene(value, True)
        refs.append({"session": task["session"], "path": str(task["resolved_path"]), "sha256": task["sha256"]})
        for key, current in checked.items():
            book = value["books"][key]
            row = {"session": task["session"], "key": key, **summarize_book(book, current)}
            by_key[key].append(row); scene_rows.append(row)
            for a, b in (("gross", "gross_yen"), ("fee", "fee_yen"), ("slip", "slip_yen"), ("net", "net_yen"), ("positions", "positions"), ("entry_quantity", "entry_quantity")):
                equal(task["totals"][key][a], row[b], "金融完了の実額/量")
            name = f"103_{key}_{task['session']}.trades.jsonl"
            with (args.out / name).open("x", encoding="utf-8", newline="\n") as stream:
                for trade in BASE.viewer_trades(book):
                    stream.write(json.dumps(trade, ensure_ascii=False, default=BASE.serial, allow_nan=False) + "\n")
            resources.append({"id": f"103_{key}_{task['session']}", "title": f"多玉と一定利益後の保護 {key} {task['session']}",
                              "symbol": "NK225", "product": "NK225mini", "session": task["session"], "method_id": key, "point_value": 100,
                              "pnl_format": "trades", "pnl_basis": "net", "pnl_path": name, "market_path": f"NK225/{task['session']}/book.jsonl.gz"})
        for c in (0, 5):
            for d in (0, 1):
                control = f"B5Q_P0_C{c}_D{d}"
                for a in ("LD05", "LD10"):
                    target = a + "_" + control
                    comparisons[target + "対" + control].append({"session": task["session"], **compare_positions(checked[control], checked[target])})
    aggregate, diagnostics = {}, {}
    for key, rows in by_key.items():
        aggregate[key] = combine(rows)
        equal(aggregate[key]["活動主表"]["denom"], 6048, "主6048分母")
        equal(aggregate[key]["活動副表"]["denom"], 5832, "副5832分母")
        dates = sorted({r["session"][:10] for r in rows})
        diagnostics[key] = {"日夜": {kind: combine([r for r in rows if r["session"].endswith("_" + kind)]) for kind in ("Day", "Night")},
                            "日別": [{"開始日": day, **combine([r for r in rows if r["session"].startswith(day)])} for day in dates]}
    after = {p: digest(Path(p)) for p in before}; equal(after, before, "入力code前後不変")
    result = {"試行": 103, "成功": True, "scope": "保存部分約定算術/所有/限定因果/保存点DD。全原行の別engine独立再生ではない", **proofs,
              "場数": 54, "主会計数": 648, "診断会計数": 216, "会計数": 864, "主key": MAIN_KEYS, "診断key": DIAGNOSTIC_KEYS,
              "Actor設定": {key: {"入口": "Gate無しB5Q", "基本保護": p, "起動": a or ("即時u正益" if p == "P0" else "無保護診断"), "slip_pts": c, "delay_seconds": d, "採用候補": key in MAIN_KEYS} for key in KEYS for p, a, c, d in [config_for(key)]},
              "診断対照の位置付け": "S0は利益保護義務を満たさない診断専用。採用候補・合格数へ算入しない", "集計": aggregate, "実現診断": diagnostics, "場別": scene_rows,
              "P0対LDの同実入口と実参加差": dict(comparisons), "Native参照": refs, "旧95市場全文同値": "本保存器では未実施・Root別証拠",
              "入力codeSHA256前": before, "入力codeSHA256後": after, "前後不変": True,
              "未評価": ["機会損失", "未参加/退出後価格", "MFE/理想峰回収", "資本金不明ROI"]}
    BASE.write_json(args.out / "結果.json", result)
    BASE.write_json(args.out / "一覧.resources.json", {"schema_version": 1, "path_base": "catalog", "resources": resources})
    lines = ["# 103の保存実現額と参加", "", result["scope"], "", "S0は無保護の診断専用。旧95市場全文対照は別証拠。", "", "|Key|実現純額|PF|主参加/6048|25%/50%|保存点DD|", "|---|---:|---:|---:|---|---:|"]
    for key, row in aggregate.items():
        a = row["活動主表"]
        lines.append(f"|{key}|{row['net_yen']}|{row['PF'] if row['PF'] is not None else '未定義'}|{a['active']}/{a['denom']}|{a['最低25%']}/{a['目標50%']}|{row['保存点連結時価DD']}|")
    (args.out / "結果.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    outputs = {p.name: digest(p) for p in args.out.iterdir() if p.is_file()}
    BASE.write_json(args.out / "保存会計の確認.json", {"成功": True, "scope": result["scope"], **proofs, "会計": 864, "資源": len(resources), "不一致数": 0,
                    "入力codeSHA256前": before, "入力codeSHA256後": after, "前後不変": True, "出力SHA256": outputs, "Raw_Source_金融_特徴再生成_HTTP": 0})


if __name__ == "__main__":
    main()
