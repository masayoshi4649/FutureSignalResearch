"""停止形式射影の正常値と不正な証拠を、手製metadataだけで検査する。"""

import copy
import unittest

from 整合する import project


class 射影検査(unittest.TestCase):
    """形式を整える処理が不正な所有や前後差を受理しないことを確認する。"""

    def test_所有を保持して元証拠へ結ぶ(self) -> None:
        """正常な前後同体から、通常型と正本への参照を作る。

        引数: self(射影検査)は検査器。
        返り値: None。
        """
        value = {"成功": True, "停止": True, "前後不変": True, "所有コードSHA256": {"a": "a"*64}, "コードSHA256前": {"a": "a"*64, "b": "b"*64}, "コードSHA256後": {"a": "a"*64, "b": "b"*64}}
        result = project(value, {"path": "人工停止", "sha256": "c"*64})
        self.assertEqual(result["所有コードSHA256"], value["所有コードSHA256"])
        self.assertNotIn("コードSHA256前", result)
        self.assertNotIn("コードSHA256後", result)
        result["所有コードSHA256"]["a"] = "d"*64
        self.assertEqual(value["所有コードSHA256"]["a"], "a"*64)

    def test_失敗空欄差分と所有欠落を拒否(self) -> None:
        """不成功・空map・前後差・所有未包含を拒否する。

        引数: self(射影検査)は検査器。
        返り値: None。
        """
        value = {"成功": True, "停止": True, "前後不変": True, "所有コードSHA256": {"a": "a"*64}, "コードSHA256前": {"a": "a"*64}, "コードSHA256後": {"a": "a"*64}}
        for field, replacement in [("成功", False), ("停止", False), ("前後不変", False), ("所有コードSHA256", {}), ("コードSHA256前", {}), ("コードSHA256後", {"a": "b"*64}), ("所有コードSHA256", {"z": "z"*64})]:
            with self.subTest(field=field):
                broken = copy.deepcopy(value)
                broken[field] = replacement
                with self.assertRaises(ValueError):
                    project(broken, {})


if __name__ == "__main__":
    unittest.main(verbosity=2)
