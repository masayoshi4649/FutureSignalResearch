"""算法と実行物を変更せず、固定済み停止の所有mapをCLIの明示型へ射影する。"""

import copy
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
TRIAL = ROOT / "study/00110_三時間軸の有効状態と値幅を残す必須保護"
FINANCIAL_SHA = "232271e3884d8f2d40d26b63372a606e8fbab5b108f8b334cdb180d144b1648f"
TARGETS = {
    "110有効状態と値幅保護の接続": "80d6eeb5c9781fe831c55a95a5039b09f8b5849b6106781026377889ab1a88cb",
    "110有効状態と値幅保護の市場入出力": "a3f255ff6607dc47f215a0e12a3a432c846a442a9fb7f4af04b44250df931914",
    "110入口の頻度前検査": "223830420ab5a7b1e423a626e63bc57d371c36780d743938925c8fddc3069603",
}


def digest(path: Path) -> str:
    """固定metadata又はコードの全バイト指紋を取る。

    引数: path(Path)は停止記録・条件・自作コード。
    返り値: strはSHA256。価格入力を指定しない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict:
    """認証済みのUTF-8 JSONを読む。

    引数: path(Path)は小型metadata。
    返り値: dictは元値。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def reference(path: Path) -> dict:
    """元停止又は派生viewを完全な所在と指紋へ結ぶ。

    引数: path(Path)はmetadata・コード。
    返り値: dictは絶対pathとSHA256。
    """
    return {"path": str(path.resolve()), "sha256": digest(path)}


def project(value: dict, origin: dict) -> dict:
    """所有＋同体の前後mapを検査して、通常停止の所有mapだけへ射影する。

    引数: value(dict)は固定済み停止、origin(dict)はその認証参照。
    返り値: dictはGo CLIの明示型と元停止参照。不完全な前後証拠は拒否する。
    """
    if not (value.get("成功") is True and value.get("停止") is True and value.get("前後不変") is True):
        raise ValueError("成功・停止・不変の宣言が必要")
    owned, before, after = (value.get(key) for key in ["所有コードSHA256", "コードSHA256前", "コードSHA256後"])
    if not owned or not before or before != after or any(before.get(path) != sha for path, sha in owned.items()):
        raise ValueError("所有と非空同体の前後mapの結合が必要")
    return {"成功": True, "所有コードSHA256": copy.deepcopy(owned), "元停止": copy.deepcopy(origin),
            "用途": "CLI明示型へのmetadata射影のみ。元の検査/前後mapは元停止を正本とする", "trial": 110}


def write_new(path: Path, value: dict) -> None:
    """既存を上書きせず、派生metadataを保存する。

    引数: path(Path)、value(dict)は新規先と値。
    返り値: None。既存先があれば拒否する。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def main() -> None:
    """金融前の停止形式だけを整合し、別条件ファイルを新規保存する。

    引数: なし。
    返り値: None。元条件/停止/算法/実行物/技法を変更せず、市場を起動しない。
    """
    old_path = TRIAL / "金融条件.json"
    assert digest(old_path) == FINANCIAL_SHA
    old = read(old_path)
    assert old["trial"] == 110 and old["fixed"] and not old["financial_executed"]
    new_path = TRIAL / "金融条件_停止形式整合.json"
    assert not new_path.exists()
    changed, resolved = [], []
    before = {str(old_path): FINANCIAL_SHA}
    for ref in old["stops"]:
        path = Path(ref["path"])
        assert digest(path) == ref["sha256"]
        before[str(path)] = ref["sha256"]
        value = read(path)
        if path.parent.name not in TARGETS:
            resolved.append(copy.deepcopy(ref))
            continue
        assert TARGETS[path.parent.name] == ref["sha256"] and path.name == "停止.json"
        view = project(value, ref)
        for source, expected in value["コードSHA256前"].items():
            assert digest(Path(source)) == expected
            before[source] = expected
        for source, expected in view["所有コードSHA256"].items():
            assert old["code_sha256"][source] == expected
        target = OWN / (path.parent.name+"_通常型.json")
        write_new(target, view)
        resolved.append(reference(target))
        changed.append({"元": ref, "射影": reference(target), "所有数": len(view["所有コードSHA256"])})
    assert len(changed) == 3
    proof_path = OWN / "形式整合の確認.json"
    failure_path = OWN / "初回金融起動の記録.json"
    write_new(failure_path, {"trial": 110, "condition": reference(old_path), "stage": "first2", "exit_code": 1,
                             "observed_stderr": "通常停止の所有集合又は明示型が不正", "出力先作成": False,
                             "停止位置": "prepare内verifyCodeScope、種/CSV/Record本文を開く前", "金融実行": False})
    new = copy.deepcopy(old)
    new["stops"] = resolved
    new["specifications"] += [item["元"] for item in changed]+[reference(failure_path), reference(Path(__file__)), reference(OWN / "人工検査.py")]
    for path in [Path(__file__), OWN / "人工検査.py"]:
        new["code_sha256"][str(path.resolve())] = digest(path)
    new["scope"] += "。元停止と検査結果を残した通常型viewによるI/O整合。算法/実行物/36条件は同じ"
    allowed = {"stops", "specifications", "code_sha256", "scope"}
    assert all(new[key] == value for key, value in old.items() if key not in allowed)
    assert all(new["code_sha256"][key] == value for key, value in old["code_sha256"].items())
    assert before == {path: digest(Path(path)) for path in before}
    proof = {"成功": True, "trial": 110, "変換": changed, "元金融条件": reference(old_path),
             "算法/実行物/全36設定/入力/費用/時計/分母": "変更なし", "元固定ファイル前後不変": True,
             "追加コード": {str(path.resolve()): digest(path) for path in [Path(__file__), OWN / "人工検査.py"]},
             "市場起動": False, "保留11月09本文/hash読取": False}
    write_new(proof_path, proof)
    new["specifications"].append(reference(proof_path))
    write_new(new_path, new)
    print(json.dumps({"成功": True, "条件": reference(new_path), "変換数": 3}, ensure_ascii=False))


if __name__ == "__main__":
    main()
