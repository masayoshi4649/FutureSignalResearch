# 固定5分CSVの入力口

指紋を固定した一場のCSVだけを `threeframe.ChildBar` へ変換する。新旧市場金融、原板、Sourceを実行しない。子足の時系列と物理CSV行を保持し、欠けた足は補完せず公開器へ渡す。完全な数量0と、未知の数量を分ける。

`LoadChildren(scene, FileRef)` は絶対path・bytes・SHA256を照合してから解釈する。必須列はtime/open/high/low/close/volume/volume_complete/closed。同じ列数と一意の列名、有限かつ正整合のOHLC、厳密昇順の当場300秒格子、true/falseフラグを要求する。数量が未知の空欄だけは0という格納値とVolumeKnown=falseを組にし、既知0と区別する。指紋・構文・時刻の破損を無取引結果に置き換えない。

EOFや足終+60秒、公表順、carry、指標の計算は別のthreeframe公開器が担当する。この入力口から読めたことを、その価格が判断時点で利用可能だった証明にしない。ファイル全体のSHAとEOFは出典/入力制御であり、金融の予測特徴量ではない。

人工CSVだけのtest/vet/buildと停止指紋は `検査と停止を記録する.py` で生成する。新11/09・既使用70場の実値・Raw本文はこの段階では読まない。
