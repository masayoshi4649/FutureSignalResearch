// Package threeframeinput は固定CSVだけを三時間軸公開器の子足へ変換します。
package threeframeinput

import (
	"bytes"
	"crypto/sha256"
	"encoding/csv"
	"encoding/hex"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

// Loaded は同じ入力bytesから作った子足と行数の記録です。
type Loaded struct {
	Input frame.FileRef    `json:"input"`
	Scene frame.Session    `json:"scene"`
	Bars  []frame.ChildBar `json:"bars"`
}

// number は有限な数値だけを読みます。
//
// 引数: text(string)はCSVの数値セルです。
// 返り値: float64/errorは数値又は未定義・非有限の拒否です。
func number(text string) (float64, error) {
	v, err := strconv.ParseFloat(text, 64)
	if err != nil || math.IsNaN(v) || math.IsInf(v, 0) {
		return 0, fmt.Errorf("有限な数値が必要です")
	}
	return v, nil
}

// boolean は記録形式のtrue/falseを曖昧に補完せず読みます。
//
// 引数: text(string)は完全性又は確定フラグです。
// 返り値: bool/errorは真偽値又は形式拒否です。
func boolean(text string) (bool, error) {
	if text == "true" {
		return true, nil
	}
	if text == "false" {
		return false, nil
	}
	return false, fmt.Errorf("true又はfalseが必要です")
}

// LoadChildren は実物指紋を検査してから指定した一場の5分CSVを読みます。
//
// 引数: scene(frame.Session)、input(frame.FileRef)は固定場時計とCSV参照です。
// 返り値: Loaded/errorは行出典付き子足又は指紋・構文・時計の不一致です。
func LoadChildren(scene frame.Session, input frame.FileRef) (Loaded, error) {
	out := Loaded{Input: input, Scene: scene, Bars: []frame.ChildBar{}}
	if !filepath.IsAbs(input.Path) || input.Bytes <= 0 || len(input.SHA256) != 64 || scene.ID == "" || scene.Contract == "" || scene.Start <= 0 || scene.End <= scene.Start {
		return out, fmt.Errorf("絶対CSV参照と場時計が必要です")
	}
	body, err := os.ReadFile(input.Path)
	if err != nil {
		return out, err
	}
	digest := sha256.Sum256(body)
	if int64(len(body)) != input.Bytes || hex.EncodeToString(digest[:]) != input.SHA256 {
		return out, fmt.Errorf("固定CSVのsize/SHA256差")
	}
	// ----------------------------------------
	// 同じ固定bytesだけを解釈し、後の公表時刻の判断は公開器へ渡します。
	r := csv.NewReader(bytes.NewReader(bytes.TrimPrefix(body, []byte{0xef, 0xbb, 0xbf})))
	header, err := r.Read()
	if err != nil {
		return out, err
	}
	columns := map[string]int{}
	for i, name := range header {
		if _, duplicate := columns[name]; name == "" || duplicate {
			return out, fmt.Errorf("CSV列名の空欄又は重複")
		}
		columns[name] = i
	}
	for _, name := range []string{"time", "open", "high", "low", "close", "volume", "volume_complete", "closed"} {
		if _, exists := columns[name]; !exists {
			return out, fmt.Errorf("必要列なし:%s", name)
		}
	}
	r.FieldsPerRecord = len(header)
	last := scene.Start - 300
	for {
		row, e := r.Read()
		if e == io.EOF {
			break
		}
		if e != nil {
			return out, e
		}
		physical, _ := r.FieldPos(0)
		textTime := row[columns["time"]]
		if strings.TrimSpace(textTime) != textTime {
			return out, fmt.Errorf("足時刻の空白")
		}
		stamp, e := time.Parse(time.RFC3339Nano, textTime)
		if e != nil {
			return out, fmt.Errorf("足時刻形式:%w", e)
		}
		start := float64(stamp.Unix()) + float64(stamp.Nanosecond())/1e9
		if start < scene.Start || start+300 > scene.End || start <= last || math.Mod(start-scene.Start, 300) != 0 {
			return out, fmt.Errorf("足の範囲/順序/重複/格子差:%d", physical)
		}
		price := [4]float64{}
		for i, name := range []string{"open", "high", "low", "close"} {
			price[i], e = number(row[columns[name]])
			if e != nil {
				return out, fmt.Errorf("価格列:%s/%d", name, physical)
			}
		}
		if price[0] <= 0 || price[2] <= 0 || price[1] < math.Max(price[0], price[3]) || price[2] > math.Min(price[0], price[3]) || price[1] < price[2] {
			return out, fmt.Errorf("OHLC不正:%d", physical)
		}
		known, e := boolean(row[columns["volume_complete"]])
		if e != nil {
			return out, fmt.Errorf("数量完全性:%d", physical)
		}
		closed, e := boolean(row[columns["closed"]])
		if e != nil {
			return out, fmt.Errorf("確定フラグ:%d", physical)
		}
		volume := 0.0
		if row[columns["volume"]] != "" {
			volume, e = number(row[columns["volume"]])
			if e != nil || volume < 0 {
				return out, fmt.Errorf("数量不正:%d", physical)
			}
		} else if known {
			return out, fmt.Errorf("完全数量の空欄:%d", physical)
		}
		out.Bars = append(out.Bars, frame.ChildBar{Start: start, End: start + 300, OHLC: frame.OHLC{Open: price[0], High: price[1], Low: price[2], Close: price[3]}, Volume: volume, Closed: closed, VolumeKnown: known, Input: input, Row: uint64(physical)})
		last = start
	}
	if len(out.Bars) == 0 {
		return out, fmt.Errorf("子足なし")
	}
	return out, nil
}
