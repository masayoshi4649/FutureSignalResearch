"""人工CSV入力口と停止済み公開器への参照を検査して記録する。"""

import hashlib
import json
from pathlib import Path
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent


def sha(path: Path) -> str:
    """
    機能: 所有コード又は小さな停止記録の指紋を取得する。
    引数: path (Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 人工検査と前後のコード不変を結び、停止記録を作る。
    引数: なし。
    返り値: None。市場入力の読取と金融再計算は行わない。
    """
    owned = [WORK / name for name in ("go.mod", "candle.go", "candle_test.go", "README.md", Path(__file__).name)]
    before = {str(p.relative_to(ROOT)): sha(p) for p in owned}
    publisher_stop = ROOT / "work/三時間軸の公開器/停止.json"
    assert sha(publisher_stop) == "b6b1a326cc98f67e13ec1962a19bac001eda743880b74a13066a2307c5944895"
    publisher = json.loads(publisher_stop.read_text(encoding="utf-8-sig"))
    log_dir = WORK / "検査"
    log_dir.mkdir(exist_ok=True)
    results = []
    for label, command in (("人工検査", ["go", "test", "-json", "-count=1", "./..."]), ("静的検査", ["go", "vet", "./..."]), ("ビルド", ["go", "build", "./..."])):
        result = subprocess.run(command, cwd=WORK, capture_output=True)
        log = log_dir / (label + ".txt")
        log.write_bytes(result.stdout + result.stderr)
        results.append({"command": command, "exit_code": result.returncode, "path": str(log.relative_to(ROOT)), "sha256": sha(log)})
        assert result.returncode == 0, result.stderr.decode("utf-8", errors="replace")
    after = {str(p.relative_to(ROOT)): sha(p) for p in owned}
    assert before == after
    assert sha(publisher_stop) == "b6b1a326cc98f67e13ec1962a19bac001eda743880b74a13066a2307c5944895"
    proof = {"成功": True, "範囲": "人工CSVの解釈・入力指紋と欠足/未知の保持のみ", "所有コードSHA256": before, "前後不変": True, "公開器停止": {"path": str(publisher_stop.relative_to(ROOT)), "sha256": sha(publisher_stop)}, "検査": results, "Go版": subprocess.check_output(["go", "version"], text=True).strip(), "実市場値読取": 0, "新11月09日本文読取": 0, "金融実行": 0}
    (WORK / "停止.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "検査": [r["exit_code"] for r in results], "停止SHA256": sha(WORK / "停止.json")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
