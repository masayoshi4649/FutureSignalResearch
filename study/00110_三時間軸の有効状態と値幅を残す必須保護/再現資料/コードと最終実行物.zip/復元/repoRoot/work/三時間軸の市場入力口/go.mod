module github.com/masayoshi4649/SessionTradeExecuter/threeframeinput

go 1.24.0

require github.com/masayoshi4649/SessionTradeExecuter/threeframe v0.0.0

replace github.com/masayoshi4649/SessionTradeExecuter/threeframe => "../三時間軸の公開器"
