package threeframeinput

import (
	"crypto/sha256"
	"encoding/hex"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

// fixture は実市場を読まず人工CSVと固定参照を作ります。
//
// 引数: t(*testing.T)、text(string)は検査と人工表です。
// 返り値: frame.Session/frame.FileRefは場と実物指紋です。
func fixture(t *testing.T, text string) (frame.Session, frame.FileRef) {
	t.Helper()
	p := filepath.Join(t.TempDir(), "candle_5min.csv")
	if err := os.WriteFile(p, []byte(text), 0600); err != nil {
		t.Fatal(err)
	}
	digest := sha256.Sum256([]byte(text))
	at, _ := time.Parse(time.RFC3339, "2026-09-21T08:45:00+09:00")
	s := frame.Session{ID: "人工_Day", Contract: "人工限月", Start: float64(at.Unix()), End: float64(at.Unix()) + 3600, EOF: float64(at.Unix()) + 2400}
	return s, frame.FileRef{Path: p, SHA256: hex.EncodeToString(digest[:]), Bytes: int64(len(text))}
}

const data = "time,open,high,low,close,volume,volume_complete,closed\n2026-09-21T08:45:00+09:00,100,120,90,110,0,true,true\n2026-09-21T08:55:00+09:00,110,130,100,120,,false,true\n"

// TestLoad は欠足を補完せず、価格と数量の既知性を分けることを確かめます。
//
// 引数: t(*testing.T)は検査環境です。
// 返り値: ありません。
func TestLoad(t *testing.T) {
	s, f := fixture(t, "\ufeff"+data)
	got, err := LoadChildren(s, f)
	if err != nil {
		t.Fatal(err)
	}
	if len(got.Bars) != 2 || got.Bars[0].Row != 2 || got.Bars[1].Row != 3 || got.Bars[1].Start-got.Bars[0].Start != 600 || !got.Bars[0].VolumeKnown || got.Bars[1].VolumeKnown {
		t.Fatal(got)
	}
	if got.Bars[1].Volume != 0 || got.Bars[0].Volume != 0 {
		t.Fatal("未知と既知0の区別")
	}
	bank, err := frame.BeginSession(s, got.Bars, nil)
	if err != nil {
		t.Fatal(err)
	}
	frames, err := bank.AdvanceObserved(s.Start+960, 1)
	if err != nil {
		t.Fatal(err)
	}
	missing := false
	for _, p := range frames {
		if p.WidthSeconds == 300 && !p.PriceKnown {
			missing = true
		}
	}
	if !missing {
		t.Fatal("欠けた子足が価格既知へ変わった")
	}
}

// TestReject は実物不一致・時刻・価格・数量形式を拒否することを確認します。
//
// 引数: t(*testing.T)は検査環境です。
// 返り値: ありません。
func TestReject(t *testing.T) {
	variants := map[string]string{
		"重複時刻":   strings.Replace(data, "08:55:00", "08:45:00", 1),
		"非格子":    strings.Replace(data, "08:55:00", "08:56:00", 1),
		"逆順":     strings.Replace(data, "08:45:00", "09:00:00", 1),
		"高安":     strings.Replace(data, ",120,90,110,", ",95,90,110,", 1),
		"非有限":    strings.Replace(data, ",120,90,110,", ",NaN,90,110,", 1),
		"未知フラグ":  strings.Replace(data, ",true,true", ",,true", 1),
		"完全数量空欄": strings.Replace(data, ",0,true,true", ",,true,true", 1),
		"重複列":    strings.Replace(data, "volume_complete", "volume", 1),
		"列欠落":    strings.Replace(data, "volume_complete", "other", 1),
	}
	for name, text := range variants {
		t.Run(name, func(t *testing.T) {
			s, f := fixture(t, text)
			if _, err := LoadChildren(s, f); err == nil {
				t.Fatal("受理した")
			}
		})
	}
	s, f := fixture(t, data)
	f.Bytes++
	if _, err := LoadChildren(s, f); err == nil {
		t.Fatal("size差")
	}
	f.Bytes--
	f.SHA256 = strings.Repeat("0", 64)
	if _, err := LoadChildren(s, f); err == nil {
		t.Fatal("SHA差")
	}
}
