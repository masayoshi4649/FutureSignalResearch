"""110の旧保存計画へ金融条件・形式整合・確認metadataだけを追加する。"""

from collections import Counter
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import zlib

OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
PREVIOUS = ROOT / 'work/110再現保存の準備'
PLAN = PREVIOUS / '計画候補_現段階.json'
PLAN_SHA = '5f42608b462af8551d715b7a48f8380814374eacbbd09a3d63272e8e0bcac8ff'
PREPARED_SHA = 'a5c2b9d2d401d3110de4e2bc117d633111f8186d253d0d4286324a5ce5c3af09'
COLLECTOR_SHA = '37c2ad601d35e16446745ba998167a27d1b4cd628f75da618ebd70c17181d01e'
TRIAL = ROOT / 'study/00110_三時間軸の有効状態と値幅を残す必須保護'
FINANCIAL_SHA = '232271e3884d8f2d40d26b63372a606e8fbab5b108f8b334cdb180d144b1648f'
NORMALIZED_SHA = 'e0f84c5f836a3cb58b6d75c12f08c40e910b661043516e1e642143b6026b9fba'

if hashlib.sha256((PREVIOUS / '収集する.py').read_bytes()).hexdigest() != COLLECTOR_SHA:
    raise ValueError('旧collectorの指紋差')
SPEC = importlib.util.spec_from_file_location('旧110再現計画の共通処理', PREVIOUS / '収集する.py')
C = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(C)


def financial_difference(original, normalized):
    """
    機能: 元金融条件との差をmetadataの形式整合だけに限定する。

    引数: original/normalized(dict)は認証済みの元条件と実使用条件。
    返り値: dictは差の要約。不許可の差があればValueError。
    """
    allowed = {'scope', 'code_sha256', 'specifications', 'stops'}
    changed = {key for key in original.keys() | normalized.keys() if original.get(key) != normalized.get(key)}
    C.need(changed == allowed, '許可された形式整合4キーだけの差が必要')
    C.need(original['fixed'] and normalized['fixed'] and original['trial'] == normalized['trial'] == 110, '110の固定条件が必要')
    C.need(len(original['configs']) == len(normalized['configs']) == 36, '固定候補36を保持')
    C.need(all(normalized['code_sha256'].get(path) == value for path, value in original['code_sha256'].items()), '旧金融codeの削除/改変を拒否')
    added = {path: value for path, value in normalized['code_sha256'].items() if path not in original['code_sha256']}
    expected = {str(ROOT / 'work/110停止形式の整合' / name) for name in ('整合する.py', '人工検査.py')}
    C.need(set(added) == expected, '追加codeは形式整合2本だけ')
    return {'変更キー': sorted(changed), '変更しない範囲': '算法/実行物/36設定/入力/費用/時計/分母', '追加code': added}


def validate_previous(plan):
    """
    機能: 旧計画の全所在を再読し安全な保存先と指紋を再確認する。

    引数: plan(dict)は全バイト認証済みの旧計画。
    返り値: Registryは旧全件のrolesと種別を保持した台帳。
    """
    C.need(plan['trial'] == 110 and plan['summary']['全所在'] == 1370, '旧110計画の1370所在が必要')
    rows = plan['files']
    registry = C.Registry([Path(row['original_path']) for row in rows if row['kind'] == '最終exe'],
                          [Path(row['original_path']) for row in rows if row['kind'] == '人工'])
    for row in rows:
        C.need(row['roles'], '各所在に根拠となる役割が必要')
        for role in row['roles']:
            current = registry.add(row['original_path'], row['sha256'], role, row['kind'])
        for key in ('original_path', 'sha256', 'bytes', 'kind', 'restore', 'location'):
            C.need(current[key] == row[key], '旧所在/保存種別の差:' + row['original_path'])
    C.need(len(registry.rows) == len(rows), '旧計画の重複pathを拒否')
    return registry


def add_interruption(registry, evidence):
    """
    機能: Rootの中断監査metadataを市場本文へ進まず計画へ結ぶ。

    引数: registry(Registry)は台帳、evidence(dict|None)はpath/sha256。
    返り値: dict|Noneは認証済み監査Ref。新頻度要求と生成器以外の参照先を読まない。
    """
    if evidence is None:
        return None
    path = C.resolve(evidence['path'])
    C.need(path.is_relative_to(ROOT / 'work/110再開の監査') and path.suffix == '.json', 'Rootの監査専用prefix内のJSONだけ')
    value = C.read(path, evidence['sha256'])
    C.need(value['試行'] == 110 and value['成功完了認定'] is False, '中断を成功としない監査が必要')
    C.need(value['保全']['算法変更'] is False and value['保全']['固定条件変更'] is False, '中断対応で算法と固定条件は変更しない')
    C.need(value['同一金融条件']['sha256'] == NORMALIZED_SHA, '同一の実使用条件を維持')
    old_ref, new_ref = value['元頻度要求'], value['新頻度要求']
    C.need(old_ref['sha256'] == 'b86890523ea47fb2bcbf344eef20715d7437af6545a4417e296bb99f8962f848', '元全70頻度要求の認証')
    old_request = C.read(C.resolve(old_ref['path']), old_ref['sha256'])
    new_request = C.read(C.resolve(new_ref['path']), new_ref['sha256'])
    changed = {key for key in old_request.keys() | new_request.keys() if old_request.get(key) != new_request.get(key)}
    C.need(changed == {'output_dir'} and value['要求変更キー'] == ['output_dir'], '頻度要求は出力先だけ変更')
    for ref, role, kind in ((new_ref, '同条件で中断後再実行する純頻度要求', 'metadata'),
                            (value['生成器'], '中断記録と同条件頻度要求の履歴生成器', 'code')):
        C.need(C.resolve(ref['path']).is_relative_to(ROOT / 'work/110再開の監査'), '中断対応の明示補助だけを追加')
        registry.add_ref(ref, role, kind)
    registry.add_ref(evidence, 'Rootのプロセス不存在/完成記録不在の監査metadata', 'metadata')
    return {'path': str(path), 'sha256': evidence['sha256']}


def build_plan(interruption=None):
    """
    機能: 固定済み旧計画へ実使用条件と確認metadataを追加する。

    引数: interruption(dict|None)はRootの監査Ref。
    返り値: dictは正式ZIP未生成の派生計画。価格/Native本文は対象外。
    """
    previous = C.read(PLAN, PLAN_SHA)
    prepared = C.read(PREVIOUS / '準備確認.json', PREPARED_SHA)
    C.need(prepared['成功'] and prepared['コード前後不変'] and prepared['主'] == 6, '旧準備確認の成功が必要')
    registry = validate_previous(previous)
    original_path = TRIAL / '金融条件.json'
    normalized_path = TRIAL / '金融条件_停止形式整合.json'
    original = C.read(original_path, FINANCIAL_SHA)
    normalized = C.read(normalized_path, NORMALIZED_SHA)
    difference = financial_difference(original, normalized)
    registry.add_ref({'path': str(PLAN), 'sha256': PLAN_SHA}, '派生元計画の正本', 'metadata')
    registry.add_ref({'path': str(PREVIOUS / '準備確認.json'), 'sha256': PREPARED_SHA}, '旧保存準備の独立確認', 'metadata')
    registry.add_ref({'path': str(original_path), 'sha256': FINANCIAL_SHA}, '市場前に形式拒否された元金融条件', 'metadata')
    registry.add_ref({'path': str(normalized_path), 'sha256': NORMALIZED_SHA}, '実使用した同算法の別金融条件', 'metadata')
    for path, expected in difference['追加code'].items():
        registry.add(path, expected, '停止形式の射影とその人工検査')
    views = []
    for new in normalized['stops']:
        path = C.resolve(new['path'])
        if not path.is_relative_to(ROOT / 'work/110停止形式の整合'):
            continue
        value = C.read(path, new['sha256'])
        C.need(value['成功'] and value['trial'] == 110 and value['所有コードSHA256'], '通常型viewの成功/所有集合')
        C.need(value['元停止'] in original['stops'], '元停止との明示結合')
        stopped = C.read(C.resolve(value['元停止']['path']), value['元停止']['sha256'])
        C.need(value['所有コードSHA256'] == stopped['所有コードSHA256'], 'viewの所有集合は元停止と同体')
        C.need(stopped['コードSHA256前'] == stopped['コードSHA256後'], '元停止の前後不変')
        registry.add_ref(new, 'CLIの停止通常型viewと元停止の結合', 'metadata')
        views.append(new)
    C.need(len(views) == 3, '通常型view3本が必要')
    for name in ('形式整合の確認.json', '初回金融起動の記録.json'):
        path = ROOT / 'work/110停止形式の整合' / name
        matches = [value for value in normalized['specifications'] if C.resolve(value['path']) == path]
        C.need(len(matches) == 1, '実使用条件が形式整合証拠を一意に参照')
        registry.add_ref(matches[0], '形式整合と初回拒否の経緯', 'metadata')
    # ----------------------------------------
    # 市場結果の値を取り出さず、既に確定した確認metadataだけを全SHAへ結ぶ。
    refs = {
        'work/110保存要求/作る.py': ('1fbd017133d448ff081a756e9eba1733a137039baadfe1ee3d317e5224cc103a', 'code'),
        'work/110保存要求/先頭2場.json': ('abedd3945ec01cff05992650e807b88de40b07754902c5b8752ffb2037324ee3', 'metadata'),
        'work/110市場/先頭2場_停止形式整合/完了.json': ('4bc6611cf3f8b6123c4da426f19be14d39f141b0355149b6ab778f8f922fa72d', 'metadata'),
        'work/110頻度/先頭2場/完成.json': ('33c2c79851a49dea4cfbdf925a61ff196e8d76a64ac3c71e6f62503912c1370d', 'metadata'),
        'work/110保存/先頭2場/保存会計の確認.json': ('57ac7139c4b67d3522fe3b391e1b8304aed85212cd15c72f0ec6e7c0599d5bba', 'metadata'),
        'work/110頻度集計/先頭2場/独立集計.json': ('999cd9b7a4e15f2a73860a19ea181d46c3d6a6e28380ec3f9965913fe7b60a38', 'metadata'),
        'work/110頻度要求/先頭2場.json': ('61aca8c11f2025dabdd73e97af805f3748b455aee5c1194f7a5e9ea4922e95c3', 'metadata'),
        'work/110頻度要求/全70場.json': ('b86890523ea47fb2bcbf344eef20715d7437af6545a4417e296bb99f8962f848', 'metadata'),
        'work/110保存要求_再開対応/作る.py': ('30df58079b98cbeda0f74d2bcfcfd7c33f418831c15760920fb5310130dd40b4', 'code'),
        'work/110保存要求_再開対応/準備と同体を検査する.py': ('afbd7bb8bcef6a91aacd7ebc8eebc8f9d5267ae66bb6b2055cf5ca4a8d2d7b37', 'code'),
        'work/110保存要求_再開対応/派生と全検査同体の確認.json': ('0b44d283fc823e2507a459d96f82ed5261f620ac4db8dac1cf115619ca9d6b0f', 'metadata'),
    }
    for name, (expected, kind) in refs.items():
        registry.add(str(ROOT / name), expected, '先頭2場の確認又は要求生成の出典', kind)
    interruption_ref = add_interruption(registry, interruption)
    for path in sorted(OWN.glob('*.py')):
        registry.file(path, '110中断記録追加collectorと人工検査')
    registry.file(OWN / 'README.md', '110中断記録追加の仕様', 'metadata')
    rows = sorted(registry.rows.values(), key=lambda row: row['original_path'])
    for row in rows:
        row['roles'].sort()
    archived = [row for row in rows if row['kind'] != '環境']
    entries = [row['location']['entry'] for row in archived]
    C.need(len({value.casefold() for value in entries}) == len(entries), 'Windows同名entryを拒否')
    estimate = sum(len(zlib.compress(Path(row['original_path']).read_bytes(), 9)) + 2 * len(row['location']['entry'].encode('utf-8')) + 120 for row in archived)
    value = copy.deepcopy(previous)
    value.update({'version': 2, 'scope': '金融条件/形式整合/先頭2場確認/中断監査の追加計画のみ。正式ZIP/閉鎖未生成',
                  'previous_plan': {'path': str(PLAN), 'sha256': PLAN_SHA}, 'files': rows,
                  'financial_condition': {'original': {'path': str(original_path), 'sha256': FINANCIAL_SHA},
                                          'used': {'path': str(normalized_path), 'sha256': NORMALIZED_SHA}, 'difference': difference},
                  'interruption_evidence': interruption_ref,
                  'summary': {'全所在': len(rows), '同梱予定': len(archived), '環境参照': sum(row['kind'] == '環境' for row in rows),
                              '種別': dict(Counter(row['kind'] for row in rows)), '同梱元bytes': sum(row['bytes'] for row in archived), 'ZIP概算bytes': estimate},
                  'pending': ['全70金融/純頻度の成功と独立保存の確認metadataを追加', '最終CSV/レポートhelper/Viewer検査と正式移設の同バイト証拠を追加',
                              '全件成功後のRoot依頼まで正式ZIPと最終閉鎖を生成しない', 'Source106入力保持/正確復元はコード/exeの復元とは別要件']})
    C.need(value['summary']['環境参照'] == 717 and sum(row['kind'] == '最終exe' for row in rows) == 2, 'GoRoot717/最終exe2を維持')
    return value


def main():
    """
    機能: 明示したRoot監査Refとともに新規計画だけを保存する。

    引数: --plan(Path)は所有領域の未使用先、--interruption/--interruption-sha(str)は監査Ref。
    返り値: None。市場起動・ZIP生成・既存先上書きの口は持たない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True)
    parser.add_argument('--interruption', type=Path, required=True)
    parser.add_argument('--interruption-sha', required=True)
    args = parser.parse_args()
    target = args.plan.resolve()
    C.need(target.is_relative_to(OWN) and not target.exists(), '計画は新しい所有work内へ新規だけ')
    value = build_plan({'path': str(args.interruption.resolve()), 'sha256': args.interruption_sha})
    with target.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'成功': True, '計画': C.ref(target), '見積': value['summary'], '正式ZIP生成': False, '市場本文読取': False, '11月09日読取': False}, ensure_ascii=False))


if __name__ == '__main__':
    main()
