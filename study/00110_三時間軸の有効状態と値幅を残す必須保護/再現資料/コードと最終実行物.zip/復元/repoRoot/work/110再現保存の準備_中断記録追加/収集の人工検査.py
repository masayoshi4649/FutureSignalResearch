"""旧計画の不変と金融条件/中断監査の追加境界を人工検査する。"""

import ast
import copy
import json
from pathlib import Path
import unittest

import 収集する as P

AUDIT = {'path': str(P.ROOT / 'work/110再開の監査/中断と同条件再実行の記録.json'),
         'sha256': 'c328cfb0eeb48c811c93655e5676865f5fb28ace15162d4d5a7a16c7cfe6ac0d'}


class 追加計画検査(unittest.TestCase):
    """形式整合・参照認証・保存範囲を検査する。"""

    def test_条件差を算法変更へ広げない(self):
        """
        機能: 出力形式以外の条件変更を人工改変で拒否する。

        引数: self(追加計画検査)は検査器。
        返り値: None。
        """
        original = P.C.read(P.TRIAL / '金融条件.json', P.FINANCIAL_SHA)
        normalized = P.C.read(P.TRIAL / '金融条件_停止形式整合.json', P.NORMALIZED_SHA)
        self.assertEqual(P.financial_difference(original, normalized)['変更キー'], ['code_sha256', 'scope', 'specifications', 'stops'])
        for key, replacement in (('configs', []), ('workers', 1), ('participation_denominator', {}), ('binary', {})):
            changed = copy.deepcopy(normalized)
            changed[key] = replacement
            with self.subTest(key=key), self.assertRaises(ValueError):
                P.financial_difference(original, changed)
        changed = copy.deepcopy(normalized)
        key = next(iter(original['code_sha256']))
        changed['code_sha256'][key] = '0' * 64
        with self.assertRaises(ValueError):
            P.financial_difference(original, changed)

    def test_中断は明示監査Refだけを使う(self):
        """
        機能: 監査外pathと同pathの指紋改変を拒否する。

        引数: self(追加計画検査)は検査器。
        返り値: None。
        """
        registry = P.C.Registry()
        bad = {'path': str(P.OWN / 'README.md'), 'sha256': '0' * 64}
        with self.assertRaises(ValueError):
            P.add_interruption(registry, bad)
        bad = dict(AUDIT, sha256='0' * 64)
        with self.assertRaises(ValueError):
            P.add_interruption(registry, bad)
        ref = P.add_interruption(registry, AUDIT)
        self.assertEqual(ref, AUDIT)
        self.assertEqual(len(registry.rows), 3)

    def test_旧全所在と追加範囲を維持する(self):
        """
        機能: 旧1370所在を保持し実入力を追加せず金融metadataを結ぶ。

        引数: self(追加計画検査)は検査器。
        返り値: None。全70の部分Nativeは読み出さない。
        """
        previous = P.C.read(P.PLAN, P.PLAN_SHA)
        value = P.build_plan(AUDIT)
        rows = {row['original_path']: row for row in value['files']}
        for old in previous['files']:
            row = rows[old['original_path']]
            for key in ('original_path', 'sha256', 'bytes', 'kind', 'restore', 'location'):
                self.assertEqual(row[key], old[key])
            self.assertTrue(set(old['roles']).issubset(row['roles']))
        self.assertEqual(value['summary']['環境参照'], 717)
        self.assertEqual(value['summary']['種別']['最終exe'], 2)
        self.assertEqual(value['summary']['種別']['人工'], 52)
        added = set(rows) - {row['original_path'] for row in previous['files']}
        for name in added:
            path = Path(name)
            self.assertNotIn(path.suffix, ('.csv', '.gz', '.xlsx', '.exe'))
            self.assertNotIn('.Native.', path.name)
            self.assertFalse(path.is_relative_to(P.ROOT.parent / 'JP_OSE_Data'))
        self.assertIn(str(P.TRIAL / '金融条件.json'), added)
        self.assertIn(str(P.TRIAL / '金融条件_停止形式整合.json'), added)
        self.assertIn(AUDIT['path'], added)
        self.assertEqual(value['interruption_evidence'], AUDIT)
        self.assertEqual(value['history'], previous['history'])
        self.assertEqual(value['input_dependencies'], previous['input_dependencies'])
        self.assertTrue(any('全70' in text for text in value['pending']))

    def test_全所在の再認証で改変を拒否する(self):
        """
        機能: 旧台帳が指す全バイトの改変や保存先差を拒否する。

        引数: self(追加計画検査)は検査器。
        返り値: None。実ファイル自体は変更しない。
        """
        value = P.C.read(P.PLAN, P.PLAN_SHA)
        changed = copy.deepcopy(value)
        changed['files'][0]['sha256'] = '0' * 64
        with self.assertRaises(ValueError):
            P.validate_previous(changed)
        changed = copy.deepcopy(value)
        changed['files'][0]['location']['entry'] = '../unsafe'
        with self.assertRaises(ValueError):
            P.validate_previous(changed)

    def test_関数コメント規約(self):
        """
        機能: 新Python全関数の複数行と機能/引数/返り値を検査する。

        引数: self(追加計画検査)は検査器。
        返り値: None。
        """
        for path in P.OWN.glob('*.py'):
            for node in ast.walk(ast.parse(path.read_text(encoding='utf-8'))):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    text = ast.get_docstring(node)
                    self.assertTrue(text and node.body[0].end_lineno > node.body[0].lineno, (path.name, node.name))
                    self.assertTrue(all(word in text for word in ('機能:', '引数:', '返り値:')), (path.name, node.name))


def main():
    """
    機能: 同条件の追加計画だけを検査し所有領域へ確認を保存する。

    引数: なし。
    返り値: None。金融/頻度起動と正式ZIP生成は行わない。
    """
    owned = sorted(P.OWN.glob('*.py')) + [P.OWN / 'README.md']
    before = {str(path): P.C.sha(path) for path in owned}
    zip_before = list(P.OWN.glob('*.zip'))
    result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(追加計画検査))
    P.C.need(before == {str(path): P.C.sha(path) for path in owned}, '新collectorの前後不変')
    P.C.need(zip_before == list(P.OWN.glob('*.zip')), '正式ZIPを生成しない')
    evidence = {'成功': result.wasSuccessful(), '主': result.testsRun, 'コード前後不変': True, 'コードSHA256': before,
                '旧計画': {'path': str(P.PLAN), 'sha256': P.PLAN_SHA}, '中断監査': AUDIT, '正式ZIP生成': False,
                '金融/純頻度再実行': False, '市場本文読取': False, '11月09日本文と入力指紋読取': False}
    (P.OWN / '準備確認.json').write_text(json.dumps(evidence, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    if not result.wasSuccessful():
        raise SystemExit(1)


if __name__ == '__main__':
    main()
