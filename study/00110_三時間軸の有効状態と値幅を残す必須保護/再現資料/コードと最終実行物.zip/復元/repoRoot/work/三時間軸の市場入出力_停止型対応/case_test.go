package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

// savedNativeFixture は全12Rawと未知fieldを持つ形だけの人工Nativeを新規保存します。
//
// 引数: t(*testing.T)、alter(func(map[string]any))は人工破損操作又はnil。
// 返り値: FileRefは人工gzipです。実金融成功とは扱いません。
func savedNativeFixture(t *testing.T, alter func(map[string]any)) FileRef {
	t.Helper()
	rows := []SavedConfig{}
	books, width, clock, early := map[string]any{}, map[string]any{}, map[string]any{}, map[string]any{}
	for _, name := range []string{"Q0", "Q1", "QE"} {
		for _, slip := range []float64{0, 5} {
			for _, delay := range []int{0, 1} {
				policy := "W0"
				if name == "Q1" {
					policy = "W1"
				}
				if name == "QE" {
					policy = "E1"
				}
				key := name + "_C" + string(rune('0'+int(slip))) + "_D" + string(rune('0'+delay))
				rows = append(rows, SavedConfig{name, "B5QD", policy, slip, delay, 1200})
				books[key] = map[string]any{"unknown_extra": map[string]any{"保存": "未知fieldも保持"}}
				width[key] = map[string]any{"unknown_width": 1}
				clock[key] = map[string]any{"unknown_clock": 2}
				if name == "QE" {
					early[key] = map[string]any{"unknown_early": 3}
				}
			}
		}
	}
	doc := map[string]any{"trial": 108, "complete": true, "session": map[string]any{"id": "人工場", "kind": "Day", "start": 1800000000, "end": 1800025200, "force_close": 1800024600}, "contract": "人工限月", "tape_canonical_sha256": strings.Repeat("a", 64), "configs": rows, "books": books, "width_audits": width, "clock_audits": clock, "early_audits": early}
	if alter != nil {
		alter(doc)
	}
	ref, err := writeJSON(filepath.Join(t.TempDir(), "人工.Native.json.gz"), doc, true)
	if err != nil {
		t.Fatal(err)
	}
	return ref
}

// TestSavedControlRaw は未知field/全12保持と部分集合・null・旧30分混入の拒否を確認します。
//
// 引数: t(*testing.T)は人工Nativeだけの検査。返り値: ありません。
func TestSavedControlRaw(t *testing.T) {
	ref := savedNativeFixture(t, nil)
	c, err := loadControl(ref)
	if err != nil {
		t.Fatal(err)
	}
	if len(c.Books) != 12 || len(c.WidthAudits) != 12 || len(c.ClockAudits) != 12 || len(c.EarlyAudits) != 4 || !strings.Contains(string(c.Books["Q1_C0_D0"]), "unknown_extra") || c.ReferenceSHA != ref.SHA || c.QuietSeconds != 1200 {
		t.Fatal("未知field又は参照を失った")
	}
	for name, alter := range map[string]func(map[string]any){
		"旧trial": func(j map[string]any) { j["trial"] = 107 }, "未完了": func(j map[string]any) { j["complete"] = false },
		"Book不足":  func(j map[string]any) { delete(j["books"].(map[string]any), "Q0_C0_D0") },
		"Clock不足": func(j map[string]any) { delete(j["clock_audits"].(map[string]any), "Q0_C0_D0") },
		"null":    func(j map[string]any) { j["books"].(map[string]any)["Q0_C0_D0"] = nil },
		"旧quiet":  func(j map[string]any) { rows := j["configs"].([]SavedConfig); rows[0].Quiet = 1800 },
		"設定重複":    func(j map[string]any) { rows := j["configs"].([]SavedConfig); rows[0] = rows[1] },
	} {
		t.Run(name, func(t *testing.T) {
			if _, err := loadControl(savedNativeFixture(t, alter)); err == nil {
				t.Fatal("不正Native参照を受理")
			}
		})
	}
	ref.SHA = strings.Repeat("b", 64)
	if _, err := loadControl(ref); err == nil {
		t.Fatal("実物SHA差を受理")
	}
}

// firstCompletionFixture は実市場なしのSeed計画からfirst2完了metadataを構成します。
//
// 引数: t(*testing.T)は人工検査。返り値: Plan/Completionは段階検査用で、金融の実完了証拠ではありません。
func firstCompletionFixture(t *testing.T) (Plan, Completion) {
	t.Helper()
	p := metadataFixture(t)
	p.ConditionSHA = strings.Repeat("c", 64)
	materializeSeedFixture(t, &p)
	seeds, err := prepareSeeds(&p)
	if err != nil {
		t.Fatal(err)
	}
	input := map[string]string{filepath.Join(p.Base, "人工code"): strings.Repeat("d", 64)}
	c := Completion{Version: 1, Trial: 109, Stage: "first2", Success: true, ConditionSHA: p.ConditionSHA, Sessions: 2, BooksPerScene: 24, Books: 48, Comparisons: 8, Before: input, After: input, Unchanged: true, InputMode: p.Condition.Mode, ClockModel: ClockModel, SeedScenes: 70, CSVInputs: 70, UnusedTOPIXCSV: 70, Seeds: seeds.Nodes, SeedSHA: seeds.SHA, CMPRecomputed: true, EntryCandleRecomputed: true, NewSeriesBankFormed: true, ProtectionVFormed: true, FinancialExecuted: true}
	for i := 0; i < 2; i++ {
		c.Results = append(c.Results, SceneResult{Session: p.Manifest.Sessions[i].ID, Books: 24, Comparisons: 4, BaselineAll: true, PriorBooks: 12, PriorUnchanged: true, SeedExpected: seeds.Nodes[i].Output, SeedActual: seeds.Nodes[i].Output, SeedEqual: true, Before: input, After: input, Unchanged: true, FinancialExecuted: true, FinancialDispatches: 1})
	}
	return p, c
}

// TestFirst2Gate は全成功・同条件・全70Seedの因果をfull70の前提にします。
//
// 引数: t(*testing.T)は人工完了metadata。返り値: ありません。
func TestFirst2Gate(t *testing.T) {
	p, first := firstCompletionFixture(t)
	if err := validateFirst2(first, p); err != nil {
		t.Fatal(err)
	}
	for name, alter := range map[string]func(*Completion){
		"部分冊": func(c *Completion) { c.Books = 47 }, "Shadow混入": func(c *Completion) { c.ShadowBooks = 4 }, "条件差": func(c *Completion) { c.ConditionSHA = strings.Repeat("e", 64) },
		"場差": func(c *Completion) { c.Results[0].Session = "別場" }, "CSV再生成": func(c *Completion) { c.CSVRegenerated = true }, "旧Source形成": func(c *Completion) { c.SourceFeaturesRecomputed = true }, "新形成なし": func(c *Completion) { c.NewSeriesBankFormed = false },
		"Seed量不足": func(c *Completion) { c.Seeds = c.Seeds[:2] }, "Seed因果": func(c *Completion) { c.Seeds[1].Input = nil }, "SeedSHA": func(c *Completion) { c.SeedSHA = strings.Repeat("e", 64) }, "比較失敗": func(c *Completion) { c.Results[0].BaselineAll = false },
		"場金融未実行": func(c *Completion) { c.Results[0].FinancialExecuted = false }, "金融配送なし": func(c *Completion) { c.Results[0].FinancialDispatches = 0 },
	} {
		t.Run(name, func(t *testing.T) {
			raw, _ := json.Marshal(first)
			var copy Completion
			_ = json.Unmarshal(raw, &copy)
			alter(&copy)
			if err := validateFirst2(copy, p); err == nil {
				t.Fatal("不正first2を受理")
			}
		})
	}
}

// TestOutputAndUnfixedRefusal は絶対新規先と未固定拒否を金融以前に確認します。
//
// 引数: t(*testing.T)は一時人工ファイル。返り値: ありません。
func TestOutputAndUnfixedRefusal(t *testing.T) {
	dir := t.TempDir()
	path := filepath.Join(dir, "同名.json")
	ref, err := writeJSON(path, map[string]any{"人工": true}, false)
	if err != nil {
		t.Fatal(err)
	}
	if _, err = writeJSON(path, map[string]any{}, false); err == nil {
		t.Fatal("既存出力を上書き")
	}
	if err = execute("未参照", "未参照", "first2", "", "", dir); err == nil {
		t.Fatal("既存outを受理")
	}
	if err = execute("未参照", "未参照", "first2", "", "", "相対out"); err == nil {
		t.Fatal("相対outを受理")
	}
	plan := filepath.Join(dir, "未固定.json")
	if _, err = writeJSON(plan, map[string]any{"version": 1, "trial": 109, "fixed": false}, false); err != nil {
		t.Fatal(err)
	}
	h, _ := fileSHA(plan)
	if err = execute(plan, h, "first2", "", "", filepath.Join(dir, "未作成out")); err == nil {
		t.Fatal("fixedfalseを市場実行")
	}
	if _, err = os.Stat(filepath.Join(dir, "未作成out")); !os.IsNotExist(err) {
		t.Fatal("拒否前に金融出力を作成")
	}
	before := map[string]string{path: ref.SHA}
	if _, err = recheck(before); err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(path, []byte("変更"), 0644); err != nil {
		t.Fatal(err)
	}
	if _, err = recheck(before); err == nil {
		t.Fatal("前後変更を受理")
	}
}
