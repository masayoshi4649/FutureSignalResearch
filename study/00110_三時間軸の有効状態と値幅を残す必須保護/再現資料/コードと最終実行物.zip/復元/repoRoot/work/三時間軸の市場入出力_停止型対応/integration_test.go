package main

import (
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"strings"
	"testing"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	core "github.com/masayoshi4649/SessionTradeExecuter/threeguardruntime109"
)

// syntheticPublication は停止Coreのsynthetic_test.goと同じ人工OHLCから公開器入力を再現します。
//
// 引数: t(*testing.T)、side(int)、input(tape.Tape)、header(stream.Header)、contract(string)は人工envelope。
// 返り値: core.PublicationInputは指標を直書きしない240助走子と12当場子です。
func syntheticPublication(t *testing.T, side int, input tape.Tape, header stream.Header, contract string) core.PublicationInput {
	t.Helper()
	start := 1800000000.0
	prior := frame.Session{ID: "人工助走", Contract: contract, Start: start, End: start + 241*300, EOF: start + 240*300 + 60}
	children := []frame.ChildBar{}
	for i := 0; i < 240; i++ {
		p := 10000 + float64(i)*2
		o := frame.OHLC{Open: p - .5, High: p + 2, Low: p - 2, Close: p}
		if side < 0 {
			o = frame.OHLC{Open: 30000 - o.Open, High: 30000 - o.Low, Low: 30000 - o.High, Close: 30000 - o.Close}
		}
		children = append(children, frame.ChildBar{Start: start + float64(i)*300, End: start + float64(i+1)*300, OHLC: o, Volume: 100, Closed: true, VolumeKnown: true, Input: frame.FileRef{Path: "人工助走.csv", SHA256: strings.Repeat("a", 64), Bytes: 12345}, Row: uint64(i + 2)})
	}
	seed, err := advanceEOF(prior, children, nil)
	if err != nil {
		t.Fatal(err)
	}
	shapes := []frame.OHLC{{Open: 5, High: 7, Low: -2, Close: 0}, {Open: 0, High: 1, Low: -7, Close: -5}, {Open: -5, High: 9, Low: -5, Close: 0}, {Open: 0, High: 8, Low: -2, Close: -1}, {Open: -1, High: 5, Low: -4, Close: -3}, {Open: -3, High: 3, Low: -4, Close: -2}, {Open: -2, High: 13, Low: -2, Close: 11}, {Open: 11, High: 14, Low: 8, Close: 12}, {Open: 12, High: 17, Low: 9, Close: 15}, {Open: 15, High: 18, Low: 10, Close: 16}, {Open: 16, High: 19, Low: 11, Close: 17}, {Open: 17, High: 20, Low: 12, Close: 18}}
	s := core.SourceSession(input.Session, contract, header.Ending.Legacy.ObservedClock)
	current := []frame.ChildBar{}
	for i, o := range shapes {
		o.Open += 10478
		o.High += 10478
		o.Low += 10478
		o.Close += 10478
		if side < 0 {
			o = frame.OHLC{Open: 30000 - o.Open, High: 30000 - o.Low, Low: 30000 - o.High, Close: 30000 - o.Close}
		}
		current = append(current, frame.ChildBar{Start: s.Start + float64(i)*300, End: s.Start + float64(i+1)*300, OHLC: o, Volume: 100, Closed: true, VolumeKnown: true, Input: frame.FileRef{Path: "人工取得.csv", SHA256: strings.Repeat("b", 64), Bytes: 6789}, Row: uint64(i + 2)})
	}
	for _, event := range input.Events {
		if event.Quote != nil && event.At >= s.Start+3000 && event.At < s.Start+3300 {
			current[10].OHLC.High = math.Max(current[10].OHLC.High, event.Quote.Last)
			current[10].OHLC.Low = math.Min(current[10].OHLC.Low, event.Quote.Last)
		}
	}
	return core.PublicationInput{Session: s, Children: current, Seed: &seed}
}

// TestCoreBoundaryArtificial は停止Coreの買売人工だけで外周のControl/新公開/末尾種を結合検査します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。106市場reader・実CSV・新11/09は開きません。
func TestCoreBoundaryArtificial(t *testing.T) {
	for _, side := range []int{1, -1} {
		path, err := filepath.Abs(filepath.Join("..", "三時間軸の市場接続準備", "人工_停止版", fmt.Sprintf("方向%d_saved.json", side)))
		if err != nil {
			t.Fatal(err)
		}
		var envelope struct {
			Scope   string          `json:"scope"`
			Tape    tape.Tape       `json:"tape"`
			Header  stream.Header   `json:"header"`
			Records []stream.Record `json:"records"`
			Output  core.Result     `json:"output"`
		}
		if err = readJSON(path, false, &envelope); err != nil {
			t.Fatal(err)
		}
		if !strings.Contains(envelope.Tape.Session.ID, "人工") {
			t.Fatal("人工以外のenvelopeを拒否")
		}
		oldPath := envelope.Output.PriorReference.ReferencePath
		if filepath.Dir(oldPath) != filepath.Dir(path) || !strings.HasPrefix(filepath.Base(oldPath), "旧108_人工") {
			t.Fatal("人工以外の旧参照を拒否")
		}
		before := map[string]string{}
		if _, err = checkRef(FileRef{oldPath, envelope.Output.PriorReference.ReferenceSHA}, ".", before); err != nil {
			t.Fatal(err)
		}
		var raw struct{ Books, Widths, Clocks, Early map[string]json.RawMessage }
		if err = readJSON(oldPath, false, &raw); err != nil {
			t.Fatal(err)
		}
		configs := []SavedConfig{}
		for _, name := range []string{"Q0", "Q1", "QE"} {
			for _, slip := range []float64{0, 5} {
				for _, delay := range []int{0, 1} {
					policy := "W0"
					if name == "Q1" {
						policy = "W1"
					}
					if name == "QE" {
						policy = "E1"
					}
					configs = append(configs, SavedConfig{name, "B5QD", policy, slip, delay, 1200})
				}
			}
		}
		ref, err := writeJSON(filepath.Join(t.TempDir(), "人工のみ.Native.json.gz"), map[string]any{"trial": 108, "complete": true, "session": envelope.Tape.Session, "contract": envelope.Output.Contract, "tape_canonical_sha256": envelope.Output.TapeSHA, "configs": configs, "books": raw.Books, "width_audits": raw.Widths, "clock_audits": raw.Clocks, "early_audits": raw.Early}, true)
		if err != nil {
			t.Fatal(err)
		}
		control, err := loadControl(ref)
		if err != nil {
			t.Fatal(err)
		}
		control.HistoryClass = "artificial"
		pub := syntheticPublication(t, side, envelope.Tape, envelope.Header, envelope.Output.Contract)
		childrenSHA, _ := valueSHA(pub.Children)
		if childrenSHA != envelope.Output.PublicationAudit.ChildrenSHA {
			t.Fatal("停止Coreの人工子足と再現値が不一致")
		}
		expected, err := advanceEOF(pub.Session, pub.Children, pub.Seed)
		if err != nil {
			t.Fatal(err)
		}
		runtime, err := core.NewCore(envelope.Tape, envelope.Output.Contract, "109CLI人工結合", control, pub)
		if err != nil {
			t.Fatal(err)
		}
		for _, record := range envelope.Records {
			if err = runtime.Feed(record); err != nil {
				t.Fatal(err)
			}
		}
		result, err := runtime.Finish(envelope.Header)
		if err != nil {
			t.Fatal(err)
		}
		if err = validateResult(result); err != nil {
			t.Fatal(err)
		}
		next, err := runtime.NextSeed()
		if err != nil {
			t.Fatal(err)
		}
		if err = verifyEndSeed(ScenePreparation{Publication: pub, Expected: expected.Info()}, result, next); err != nil {
			t.Fatal(err)
		}
		for key, book := range result.Books {
			if !book.Complete || book.Totals.EntryQuantity == 0 {
				t.Fatalf("人工Mainが非ゼロでない:%s", key)
			}
		}
		if _, err = recheck(before); err != nil {
			t.Fatal(err)
		}
		if stat, err := os.Stat(path); err != nil || stat.Size() == 0 {
			t.Fatal("人工入力が消失")
		}
	}
}
