"""109外周CLIを人工だけで検査し、依存不変と実行物を停止記録へ結ぶ。"""
from __future__ import annotations

import datetime
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
OLD = ROOT / 'work/三時間軸の市場入出力準備'
STOPS = {
    'work/109入口の頻度前検査/停止.json': '5939b05e58cd4925f96b86db07b3ead1549fd131f5c2718b8212462062f27b0f',
    'work/三時間軸の市場入出力準備/停止.json': '9a753b92be452e1ced42614b1e7534fbd3be23483498caf5528677b81a26fffd',
    'work/108市場の入出力準備/停止.json': '1de300b09a79549b35cad34d68c02a1cf2e72f974c6c5ee2d555e16dc3702f42',
    'work/108静観短縮の市場接続準備/停止.json': '24bb58aabb761e85b7484511108cbb06b8d9feabd8588f1bab81ba717943040d',
    'work/静観長を分ける保護会計/停止.json': '1a17e2cf0e2229d8256a10c326acf0deba9d753b1317f405fa1b63ca0c700b3d',
    'work/107保存公表の再読口_埋込対応/停止.json': 'd47881a6381e88e0ef2121830c5015e9bbfaa580ed7aa865bd2c12aca767e892',
    'work/三時間軸の市場接続準備/停止.json': '62934599463b34def929302c810bd7da2f8abeccdbfa28dce0ade82518633d73',
    'work/一定利益と三時間軸の保護会計/停止.json': '567b0bc6354b5d3d47d57f1cc3f91335a661d359ea4c81ae02f83653f3970687',
    'work/一定利益と費用床の純状態案/停止.json': '1d58cebc88a08011632a4ac1c036dcc71ae8d1bf8dc85938b3f2b344ad85a24c',
    'work/三時間軸の公開器/停止.json': 'b6b1a326cc98f67e13ec1962a19bac001eda743880b74a13066a2307c5944895',
    'work/三時間軸の市場入力口/停止.json': '820a819d284a58c5057150bb415ac3fd57c34473abda4b18467c42dba9e95782',
    'work/三時間軸の入口判定/停止.json': '834aedc70a31d5f0d7e2bee9ae6fc9d22d7b3ea726924fed791b2dfec7b283f9',
}
OWN_NAMES = (
    'io.go', 'metadata.go', 'seed.go', 'case.go', 'main.go',
    'metadata_test.go', 'seed_test.go', 'case_test.go', 'integration_test.go', 'stop_type_test.go',
    'go.mod', 'go.sum', 'README.md', '仕様.md', '検査と停止を記録する.py', '差分.patch',
)


def sha(path: Path) -> str:
    """
    機能: 明示したコード又は人工入力のSHA256を計算する。
    引数: path (Path) は非市場ファイル。
    返り値: str は本文指紋。市場ディレクトリを探索しない。
    """
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def relative(path: Path) -> str:
    """
    機能: workspace内の指紋キーを統一する。
    引数: path (Path) は入力又はコードの絶対path。
    返り値: str はrootからの相対path。
    """
    return path.resolve().relative_to(ROOT).as_posix()


def write_new(path: Path, value: dict) -> None:
    """
    機能: 検査又は停止の新規JSONをUTF-8で保存する。
    引数: path (Path)、value (dict) は保存先と内容。
    返り値: None。既存成果物を上書きしない。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write('\n')


def run(argv: list[str]) -> dict:
    """
    機能: Goコード検査を実行し、終了codeと出力を保持する。
    引数: argv (list[str]) はtest/vet/build/list/versionだけ。
    返り値: dict は実行証拠。市場CLIを起動しない。
    """
    result = subprocess.run(argv, cwd=OWN, capture_output=True, text=True, encoding='utf-8', check=False)
    value = {'argv': argv, 'cwd': str(OWN), 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    assert result.returncode == 0, value
    return value


def module_codes() -> dict[str, str]:
    """
    機能: Goが参照するworkspace内のソースとmodule定義を同定する。
    引数: なし。go listのコードmetadataだけを使う。
    返り値: dict[str,str] は指紋。市場入力の本文を開かない。
    """
    raw = run(['go', 'list', '-deps', '-test', '-json', './...'])['stdout']
    decoder, position, paths = json.JSONDecoder(), 0, set()
    while position < len(raw):
        while position < len(raw) and raw[position].isspace():
            position += 1
        if position == len(raw):
            break
        package, position = decoder.raw_decode(raw, position)
        directory = Path(package.get('Dir', '.')).resolve()
        if not directory.is_relative_to(ROOT):
            continue
        for field in ('GoFiles', 'CgoFiles', 'TestGoFiles', 'XTestGoFiles'):
            for name in package.get(field, []):
                path = (directory / name).resolve()
                if path.is_file() and path.is_relative_to(ROOT):
                    paths.add(path)
        module = package.get('Module') or {}
        replacement = module.get('Replace') or module
        if replacement.get('Dir'):
            for name in ('go.mod', 'go.sum'):
                path = (Path(replacement['Dir']) / name).resolve()
                if path.is_relative_to(ROOT) and path.is_file():
                    paths.add(path)
    return {relative(path): sha(path) for path in sorted(paths)}


def protected() -> dict[str, str]:
    """
    機能: 明示した停止SHAと停止の所有コードを照合する。
    引数: なし。旧コード、新部品、停止済人工6件だけを読む。
    返り値: dict[str,str] は検査前後で同体を要求する台帳。
    """
    values = {}
    for name, expected in STOPS.items():
        path = ROOT / name
        assert sha(path) == expected, name
        values[name] = expected
        stopped = json.loads(path.read_text(encoding='utf-8-sig'))
        assert stopped['成功'] is True
        for field in ('所有コードSHA256', 'コードSHA256後'):
            for label, wanted in stopped.get(field, {}).items():
                if not isinstance(wanted, str) or len(wanted) != 64:
                    continue
                item = Path(label)
                if not item.is_absolute():
                    item = ROOT / item
                    if not item.is_file():
                        item = path.parent / label
                assert item.is_file() and item.resolve().is_relative_to(ROOT), label
                assert sha(item) == wanted, label
                values[relative(item)] = wanted
    core_stop = json.loads((ROOT / 'work/三時間軸の市場接続準備/停止.json').read_text(encoding='utf-8'))
    for label, wanted in core_stop['人工型SHA256'].items():
        path = ROOT / label
        assert '人工_停止版' in path.parts and sha(path) == wanted, label
        values[relative(path)] = wanted
    values.update(module_codes())
    return values


def patch() -> str:
    """
    機能: 元109外周CLI停止9a753からの所有コード差を保存する。
    引数: なし。旧ファイルは読み取りだけ。
    返り値: str はunified diff。市場データの差分を作らない。
    """
    output = []
    for name in OWN_NAMES:
        if name in ('差分.patch', '検査と停止を記録する.py'):
            continue
        old, new = OLD / name, OWN / name
        before = old.read_text(encoding='utf-8').splitlines(keepends=True) if old.is_file() else []
        after = new.read_text(encoding='utf-8').splitlines(keepends=True)
        output.extend(difflib.unified_diff(before, after, fromfile=relative(old), tofile=relative(new)))
    return ''.join(output)


def main() -> None:
    """
    機能: 人工70Seed/metadata/買売24Mainを確認してCLIを停止する。
    引数: なし。実first2/full70、Raw、未使用11/09を呼ばない。
    返り値: None。Go確認、由来、exe、停止JSONを新規保存する。
    """
    assert not (OWN / '停止.json').exists()
    assert not (OWN / '検査').exists()
    assert not (OWN / '由来.json').exists()
    before = protected()
    (OWN / '差分.patch').write_text(patch(), encoding='utf-8', newline='\n')
    owned_before = {relative(OWN / name): sha(OWN / name) for name in OWN_NAMES}
    (OWN / '検査').mkdir()
    binary = OWN / '検査/三時間軸研究.exe'
    checks = [run(['go', 'test', '-json', '-count=1', '-cover', './...']), run(['go', 'vet', './...']), run(['go', 'build', '-o', str(binary), '.'])]
    tests = [json.loads(line) for line in checks[0]['stdout'].splitlines() if line.strip()]
    assert not any(item['Action'] == 'fail' for item in tests)
    passed = [item['Test'] for item in tests if item['Action'] == 'pass' and 'Test' in item]
    coverage = [item['Output'].strip() for item in tests if 'Output' in item and 'coverage:' in item['Output']]
    after = {name: sha(ROOT / name) for name in before}
    assert before == after
    assert owned_before == {name: sha(ROOT / name) for name in owned_before}
    confirmation = {'成功': True, 'checks': checks, '主test': sum('/' not in name for name in passed), 'subtest含む全test': len(passed), 'coverage': coverage, '市場金融実行': 0, '人工金融実行': True}
    write_new(OWN / '検査/Go確認.json', confirmation)
    write_new(OWN / '由来.json', {
        '成功': True, '派生元109外周CLI': relative(OLD), '直接停止SHA256': STOPS,
        '照合コード等の前SHA256': before, '後SHA256': after, '依存前後不変': True,
        '人工OHLCの由来': '停止Core synthetic_test.goと同じ数式。指標値の直書きなし',
        '人工金融の由来': '停止Coreの買売 saved envelope。Main24/Shadow0/四対全JSONを外周境界で確認',
        '市場本文読込': 0, '市場金融実行': 0, '実first2/full70': 0,
        '入力metadataテスト': '一時dirの70人工Header/NKCSV。TOPIX本文ファイルは未作成',
    })
    owned_before[relative(OWN / '由来.json')] = sha(OWN / '由来.json')
    version = run(['go', 'version'])['stdout'].strip()
    stopped = {
        '成功': True, '停止': True, 'UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'module': 'github.com/masayoshi4649/SessionTradeExecuter/threeguardcli109', 'package': 'main',
        '範囲': 'recorded70専用外周CLI停止型対応。人工だけ。市場実行0',
        '所有コードSHA256': owned_before, '直接停止SHA256': STOPS,
        '依存前後不変': True, 'コード等の指紋件数': len(before),
        'Go版': version, '主test': confirmation['主test'], 'subtest含む全test': len(passed), 'coverage': coverage,
        'vet_exit': 0, 'build_exit': 0, 'Go確認SHA256': sha(OWN / '検査/Go確認.json'),
        '実行物': str(binary), '実行物SHA256': sha(binary), '実行物bytes': binary.stat().st_size,
        'ClockModel': 'csv_end_plus60_at_record_scheduler', '真の受信時計検証': False,
        '人工結合': {'買売Main全24非ゼロ': True, 'Shadow': 0, '旧Q0四対BookWidthClock全JSON': True, 'EOF一括とRecord逐次のSeedInfo同体': True},
        '人工70種': {'manifest順の前場種だけ': True, '並列前全70完備': True, 'CSV本文破損拒否': True, '未知と欠測を保持': True},
        '未固定拒否': True, '既存out拒否': True, 'first2全成功からfull70だけ': True,
        '停止型': {'公開器固定pathとb6b1実物SHA': True, '前後map非空全同体': True, '前後不変必須': True, '失敗空差混在偽装拒否': True, '元9a753前後不変': True},
        '市場本文読込': 0, 'Raw本文読込': 0, '実70CSV本文読込': 0, '市場金融実行': 0, '実first2/full70': 0,
        '人工金融実行': True, '未使用11月09本文未読': True, '旧107108変更': 0,
        '未実施': ['Rootによる全コードとexe結合の金融条件固定', '頻度前検査と保存器停止', '実first2→全70市場接続', '損益/参加率', '採用又は研究目標達成'],
    }
    write_new(OWN / '停止.json', stopped)
    print(json.dumps({'成功': True, '停止path': str(OWN / '停止.json'), '停止SHA256': sha(OWN / '停止.json'), '実行物': str(binary), '実行物SHA256': sha(binary), '主test': confirmation['主test'], '全test': len(passed), 'coverage': coverage, '依存指紋': len(before), '市場金融実行': 0}, ensure_ascii=False))


if __name__ == '__main__':
    main()
