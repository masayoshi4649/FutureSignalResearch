package main

import (
	"fmt"
	"path/filepath"
	"strings"
	"testing"
	"time"

	reader "github.com/masayoshi4649/SessionTradeExecuter/savedpublic107"
)

// metadataFixture は実市場ファイルを開かない70場の型だけを作ります。
//
// 引数: t(*testing.T)はテスト。返り値: Planは人工metadataで、実金融成功の証拠ではありません。
func metadataFixture(t *testing.T) Plan {
	t.Helper()
	root := t.TempDir()
	h := strings.Repeat("a", 64)
	p := Plan{Base: root, Before: map[string]string{}, PriorIndexRoot: filepath.Join(root, "study", "旧108")}
	p.Condition = Condition{Version: 1, Trial: 109, Fixed: true, Scope: "人工metadata", Mode: "recorded_public_106", ClockModel: ClockModel, Workers: 4, OwnModuleDir: root, Configs: declaredConfigurations(), Code: map[string]string{"人工": h}, Stops: make([]FileRef, 8), Specifications: make([]FileRef, 2)}
	p.Condition.SourceManifest = FileRef{filepath.Join(root, "manifest.json"), "902c6b5147763de172c0199f79b13cdc08f9a5636b05e0575f19bffd2da627e8"}
	p.Condition.SourceCorpus = FileRef{filepath.Join(root, "corpus.json"), "ca6206d47d36772fff84d230073bd4346b1e785d5b0bb98c565bafe6c92fb441"}
	p.Condition.SourceCompletion = FileRef{filepath.Join(root, "source.json"), "c1370aac63c1905f132237becd5d5bb37c6bd06e20b061800c9d0caa02a1769f"}
	p.Condition.PriorCompletion = FileRef{filepath.Join(root, "108", "完了.json"), "bf0278e332386701221313de8a215fe04adea7666c22bad54c0055303440aae4"}
	p.Condition.PriorNativeIndex = FileRef{filepath.Join(p.PriorIndexRoot, "成果物_金融", "Native参照台帳.json"), "1d2cc8e4256862dd00dfeb720a7c75b62fdde79f3e3ddc19d9b71ba7a9c7f040"}
	p.Condition.PriorClosure = FileRef{filepath.Join(p.PriorIndexRoot, "完了記録.json"), "d22a5c0a9bdad7b82dfa3afa2d9d100a2ebc834b9e97291099ada1db8093c30b"}
	p.Manifest.Root = root
	p.Source = reader.Completion{Version: 1, Trial: 106, Stage: "full70", Success: true, ConditionSHA: reader.Condition106, Sessions: 70, BooksPerScene: 20, Books: 1400, Before: map[string]string{"人工": h}, After: map[string]string{"人工": h}, Unchanged: true}
	p.Prior = PriorCompletion{Version: 1, Trial: 108, Stage: "full70", Success: true, ConditionSHA: "0a2a70a4658800060ab4c22a29cdcf21e29a9e2d87f916b0d1c327bb8cf88bd6", Sessions: 70, BooksPerScene: 12, Books: 840, Before: map[string]string{"人工": h}, After: map[string]string{"人工": h}, Unchanged: true, Mode: "recorded_public_106", FinancialExecuted: true}
	p.PriorIndex = PriorNativeIndex{Success: true, Trial: 108, Base: "trialdir", Sessions: 70, Books: 840}
	p.PriorIndex.Completion.Path = p.Condition.PriorCompletion.Path
	p.PriorIndex.Completion.SHA = p.Condition.PriorCompletion.SHA
	p.PriorIndex.Completion.Bytes = 100
	p.PriorIndex.Condition = FileRef{filepath.Join(p.PriorIndexRoot, "条件.json"), p.Prior.ConditionSHA}
	for i := 0; i < 70; i++ {
		date := time.Date(2026, 9, 21+i/2, 0, 0, 0, 0, time.UTC)
		kind := "Day"
		if i%2 == 1 {
			kind = "Night"
		}
		id := date.Format("2006-01-02") + "_" + kind
		files := map[string]SizedRef{"NK225_candle_300": {Path: filepath.Join("JP_OSE_Data", "future", "NK225", id, "candle_5min.csv"), SHA: h, Size: 100}, "TOPIX_candle_300": {Path: filepath.Join("JP_OSE_Data", "future", "TOPIX", id, "candle_5min.csv"), SHA: h, Size: 100}}
		p.Manifest.Sessions = append(p.Manifest.Sessions, InputScene{ID: id, Contract: "人工限月", Files: files})
		header := reader.FileRef{Path: filepath.Join(root, "106", id+".header.json"), SHA: h}
		records := reader.FileRef{Path: filepath.Join(root, "106", id+".records.jsonl.gz"), SHA: h}
		p.Source.Results = append(p.Source.Results, reader.SceneOutput{Session: id, Native: reader.FileRef{Path: filepath.Join(root, "106", id+".Native.json.gz"), SHA: h}, Header: header, Records: records, Books: 20, W0Books: 4})
		old := FileRef{filepath.Join(root, "108", id+".Native.json.gz"), h}
		p.Prior.Results = append(p.Prior.Results, PriorScene{Session: id, Native: old, Header: FileRef{header.Path, h}, Records: FileRef{records.Path, h}, Books: 12, PriorBooks: 12, PriorUnchanged: true})
		n := PriorNativeRow{Session: id, Path: filepath.Join("成果物_金融", "Native", id+".Native.json.gz"), SHA: h, Bytes: 100, Books: 12, Original: old, SameBytes: true}
		n.Public.Header, n.Public.Records = FileRef{header.Path, h}, FileRef{records.Path, h}
		p.PriorIndex.Native = append(p.PriorIndex.Native, n)
	}
	return p
}

// TestConditionAndMetadata は未固定・未使用分岐・設定差と参照の混同を拒否します。
//
// 引数: t(*testing.T)は人工metadata。返り値: ありません。
func TestConditionAndMetadata(t *testing.T) {
	p := metadataFixture(t)
	if err := validateCondition(p.Condition); err != nil {
		t.Fatal(err)
	}
	if err := validateSources(&p); err != nil {
		t.Fatal(err)
	}
	if len(p.PriorNative) != 70 {
		t.Fatal("正式Nativeの集合不足")
	}
	for name, alter := range map[string]func(*Plan){
		"未固定": func(p *Plan) { p.Condition.Fixed = false }, "未使用分岐": func(p *Plan) { p.Condition.Mode = "fresh_unseen" }, "時計混同": func(p *Plan) { p.Condition.ClockModel = "実測受信" },
		"候補省略": func(p *Plan) { p.Condition.Configs[0].Candidate = "" }, "15分混入": func(p *Plan) { p.Condition.Configs[0].Timing = "15分" }, "冊不足": func(p *Plan) { p.Condition.Configs = p.Condition.Configs[:23] },
	} {
		t.Run(name, func(t *testing.T) {
			p := metadataFixture(t)
			alter(&p)
			if err := validateCondition(p.Condition); err == nil {
				t.Fatal("不正固定を受理")
			}
		})
	}
	for _, name := range []string{"source_ref", "source_trial", "prior_trial", "partial", "index_sha", "records_sha", "sidecar_path", "original_path", "traversal", "duplicate", "csv_missing", "source_root", "quiet_prior", "csv_topix_alias"} {
		t.Run(name, func(t *testing.T) {
			p := metadataFixture(t)
			switch name {
			case "source_ref":
				p.Condition.SourceCompletion = p.Condition.PriorCompletion
			case "source_trial":
				p.Source.Trial = 109
			case "prior_trial":
				p.Prior.Trial = 107
			case "partial":
				p.PriorIndex.Native = p.PriorIndex.Native[:2]
			case "index_sha":
				p.PriorIndex.Native[0].SHA = strings.Repeat("b", 64)
			case "records_sha":
				p.Prior.Results[0].Records.SHA = strings.Repeat("b", 64)
			case "sidecar_path":
				p.PriorIndex.Native[0].Public.Header.Path = filepath.Join(p.Base, "別header")
			case "original_path":
				p.PriorIndex.Native[0].Original.Path = filepath.Join(p.Base, "別Native")
			case "traversal":
				p.PriorIndex.Native[0].Path = filepath.Join("..", "不正.Native.json.gz")
			case "duplicate":
				p.Manifest.Sessions[1].ID = p.Manifest.Sessions[0].ID
			case "csv_missing":
				delete(p.Manifest.Sessions[0].Files, "NK225_candle_300")
			case "csv_topix_alias":
				p.Manifest.Sessions[0].Files["NK225_candle_300"] = p.Manifest.Sessions[0].Files["TOPIX_candle_300"]
			case "source_root":
				p.Manifest.Root = "最新を探索"
			case "quiet_prior":
				p.Prior.ConditionSHA = "旧30分の条件"
			}
			if err := validateSources(&p); err == nil {
				t.Fatal(fmt.Sprintf("不正metadata受理:%s", name))
			}
		})
	}
}
