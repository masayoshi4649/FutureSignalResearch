package main

import (
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
	"time"

	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
	core "github.com/masayoshi4649/SessionTradeExecuter/threeguardruntime109"
)

// childFixture は市場本文を使わない指紋付き人工子足を作ります。
//
// 引数: s(frame.Session)は場時計。返り値: []frame.ChildBarは数値種検査用の6足です。
func childFixture(s frame.Session) []frame.ChildBar {
	rows := []frame.ChildBar{}
	for i := 0; i < 6; i++ {
		start := s.Start + float64(i*300)
		price := 1000 + float64(5*i)
		rows = append(rows, frame.ChildBar{Start: start, End: start + 300, OHLC: frame.OHLC{Open: price, High: price + 10, Low: price - 5, Close: price + 5}, Volume: 100, Closed: true, VolumeKnown: true, Input: frame.FileRef{Path: "人工.csv", SHA256: strings.Repeat("a", 64), Bytes: 100}, Row: uint64(i + 2)})
	}
	return rows
}

// TestSeedEOFAndSequential は真EOF一括と複数Record時計で数値種全Info/SHAが同体であることを確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestSeedEOFAndSequential(t *testing.T) {
	s := frame.Session{ID: "人工場1", Contract: "人工限月", Start: 1800000000, End: 1800003600, EOF: 1800002010}
	children := childFixture(s)
	expected, err := advanceEOF(s, children, nil)
	if err != nil {
		t.Fatal(err)
	}
	bank, err := frame.BeginSession(s, children, nil)
	if err != nil {
		t.Fatal(err)
	}
	for i, offset := range []float64{0, 359, 360, 700, 960, 1200, 1500, 1800, 2010} {
		if _, err := bank.AdvanceObserved(s.Start+offset, uint64(i+1)); err != nil {
			t.Fatal(err)
		}
	}
	actual, snapshot, err := bank.Seal()
	if err != nil {
		t.Fatal(err)
	}
	if !reflect.DeepEqual(expected.Info(), actual.Info()) || snapshot.ReplayObservedAt != s.EOF {
		t.Fatal("EOF一括とRecord逐次の全数値種差")
	}
	if _, _, err = bank.Seal(); err == nil {
		t.Fatal("二重Sealを受理")
	}
	next := s
	next.ID = "人工場2"
	next.Start = s.End + 300
	next.End = next.Start + 3600
	next.EOF = next.Start + 2010
	bank, err = frame.BeginSession(next, childFixture(next), &actual)
	if err != nil {
		t.Fatal(err)
	}
	initial, err := bank.SnapshotAt(next.Start)
	if err != nil {
		t.Fatal(err)
	}
	for _, scale := range initial.Scales {
		if scale.HasCurrent || !scale.SeedOnly {
			t.Fatal("数値種を当場公表へ読み替え")
		}
	}
	if _, err = frame.BeginSession(s, children, &actual); err == nil {
		t.Fatal("同場又は未来種を受理")
	}
	pre := ScenePreparation{Publication: core.PublicationInput{Session: s, Children: children}, Expected: expected.Info()}
	r := core.Result{PublicationAudit: core.PublicationAudit{Session: s, EndSeed: actual.Info(), InputsUnchanged: true}}
	if err = verifyEndSeed(pre, r, actual); err != nil {
		t.Fatal(err)
	}
	r.PublicationAudit.EndSeed.SHA256 = strings.Repeat("b", 64)
	if err = verifyEndSeed(pre, r, actual); err == nil {
		t.Fatal("Core末尾の種SHA差を受理")
	}
}

// materializeSeedFixture は既使用宣言とは別の人工70Header/CSVだけを一時領域に作ります。
//
// 引数: t(*testing.T)、p(*Plan)は人工metadata。返り値: ありません。原板/金融Nativeは作りません。
func materializeSeedFixture(t *testing.T, p *Plan) {
	t.Helper()
	for i, s := range p.Manifest.Sessions {
		date, err := time.Parse("2006-01-02", s.ID[:10])
		if err != nil {
			t.Fatal(err)
		}
		start := date.Add(8*time.Hour + 45*time.Minute)
		if strings.HasSuffix(s.ID, "_Night") {
			start = date.Add(17 * time.Hour)
		}
		csvRef := s.Files["NK225_candle_300"]
		path := filepath.Join(p.Manifest.Root, csvRef.Path)
		if err = os.MkdirAll(filepath.Dir(path), 0755); err != nil {
			t.Fatal(err)
		}
		body := "time,open,high,low,close,volume,volume_complete,closed\n"
		for j := 0; j < 6; j++ {
			body += fmt.Sprintf("%s,1000,1010,995,1005,100,true,true\n", start.Add(time.Duration(j)*5*time.Minute).Format(time.RFC3339))
		}
		if err = os.WriteFile(path, []byte(body), 0644); err != nil {
			t.Fatal(err)
		}
		checksum, err := fileSHA(path)
		if err != nil {
			t.Fatal(err)
		}
		csvRef.Size, csvRef.SHA = int64(len(body)), checksum
		p.Manifest.Sessions[i].Files["NK225_candle_300"] = csvRef
		row := &p.Source.Results[i]
		if err = os.MkdirAll(filepath.Dir(row.Header.Path), 0755); err != nil {
			t.Fatal(err)
		}
		scene := map[string]any{"id": s.ID, "contract": s.Contract, "start": start.Unix()}
		header := map[string]any{"version": 1, "trial": 106, "condition_sha256": p.Source.ConditionSHA, "records_gzip_sha256": row.Records.SHA, "header": map[string]any{"version": 1, "success": true, "scene": scene, "ending": map[string]any{"legacy": map[string]any{"scene": scene, "sealed": true, "has_observed_clock": true, "observed_clock": start.Unix() + 2010}}}}
		ref, err := writeJSON(row.Header.Path, header, false)
		if err != nil {
			t.Fatal(err)
		}
		row.Header.SHA = ref.SHA
	}
}

// TestPrepareAllSeeds は並列前に全70のNK CSV/真Headerだけを因果順で用意することを確認します。
//
// 引数: t(*testing.T)は人工fixture。返り値: ありません。金融実行はありません。
func TestPrepareAllSeeds(t *testing.T) {
	p := metadataFixture(t)
	materializeSeedFixture(t, &p)
	seeds, err := prepareSeeds(&p)
	if err != nil {
		t.Fatal(err)
	}
	if len(seeds.Nodes) != 70 || len(seeds.Scenes) != 70 || len(p.Before) != 140 || seeds.Nodes[0].Input != nil {
		t.Fatal("70Seed/70NK CSV/70Header又は先頭coldが違う")
	}
	for i, node := range seeds.Nodes {
		if node.Ordinal != i+1 || !node.Output.Sealed || node.Output.ObservedAt != node.Session.EOF || node.CSV.Path != filepath.Join(p.Manifest.Root, p.Manifest.Sessions[i].Files["NK225_candle_300"].Path) {
			t.Fatal("因果種の場/EOF/CSV差")
		}
		if i > 0 && !reflect.DeepEqual(*node.Input, seeds.Nodes[i-1].Output) {
			t.Fatal("前場の数値種連鎖が違う")
		}
	}
	again, err := prepareSeeds(&p)
	if err != nil || again.SHA != seeds.SHA || !reflect.DeepEqual(again.Nodes, seeds.Nodes) {
		t.Fatal("同じ固定入力から種が非決定的")
	}
	if _, err = recheck(p.Before); err != nil {
		t.Fatal(err)
	}
	first := seeds.Nodes[0].CSV.Path
	if err = os.WriteFile(first, []byte("破損"), 0644); err != nil {
		t.Fatal(err)
	}
	if _, err = prepareSeeds(&p); err == nil {
		t.Fatal("CSV変更を受理")
	}
}
