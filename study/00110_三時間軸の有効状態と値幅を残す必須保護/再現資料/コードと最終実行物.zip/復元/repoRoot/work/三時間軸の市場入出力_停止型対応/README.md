# 三時間軸の市場入出力：停止型対応

109のRoot固定条件を受け、既使用のmanifest70だけを `first2→full70` で処理する外周CLI。**人工・metadata検査済み、市場金融実行は0**。新11/09や最新フォルダの探索分岐は持たない。正式な固定と頻度前検査・保存器停止の後にRootが実行する。

module：`github.com/masayoshi4649/SessionTradeExecuter/threeguardcli109`。Go 1.24.2。元の109 CLI停止`9a753b92be452e1ced42614b1e7534fbd3be23483498caf5528677b81a26fffd`からの別保存先への派生。元109と旧108を変更しない。仕様は [仕様](仕様.md)、検査・実行物指紋は `停止.json`。

公開器b6b1の停止だけは、実物SHAと固定絶対位置を認証し、`コードSHA256前/後`が非空・全同体、`前後不変=true`である型を明示受理する。その他は従来の`所有コードSHA256`型を使い、型混在や別位置の公開器型copyを拒否する。停止の所有コードはどちらも条件のcode集合へ全包含する。売買・公表・会計の式は変更しない。

## 入力と範囲

- 106の固定Source manifest/corpus/completionを停止reader `savedpublic107`（埋込対応d478）へ渡し、Tape/Header/Recordを再読する。
- shared manifestの140本の5分CSVのうち、各場の `NK225_candle_300` 70本だけを明示選択する。TOPIX70本は本文未読。Rawの読取・複写、CSVの再生成・複写は行わない。
- 旧108の完了・正式Native参照台帳・全70成功metadataを結合し、各場の全12Book/幅12/時計12/早期4をRawMessageで保持する。未知fieldを削らず全Native SHAも保持する。
- 新CoreはMain24、Shadow0。E0/G0と旧Q0の4費用のBook/Width/Clockを全JSON比較する。旧QEのEarly4は保存参照であり、MainG0と比較したとは扱わない。

recorded70専用である。Coreが持つfresh_unseenの4Shadow分岐をこのCLIから選べない。

## 因果的なSeed

金融workerを始める前に、全70場をmanifest順で一度だけ準備する。指紋付きNK225 CSVと真Header EOFからBeginSessionし、EOFまでAdvanceObservedを一回、Sealで数値種を作る。これをCLI内のadvanceEOFと呼ぶ。数値種だけ次場へ継承し、当場の公表やpivotを継承しない。

Header.SceneはEndを持たないため、既定のDay25200秒・Night46800秒を使う。各Core開始時はSourceTape.Session由来の全時計と照合し、差があれば拒否する。EOFは推定せずHeader.Ending.Legacy.ObservedClockを使う。

並列処理は事前の不変値を受け取り、CoreがRecord.Atで逐次公表した末尾のSeed.Info、NextSeed.Infoと、事前の全Info/SHAを照合する。first2でもSeed前段は70場、Main金融は2場48冊である。全70は1680冊。first2/full70の事前Seed計画と先頭2Native bytesも一致させる。

## 時計と再形成の区別

モデル名は `csv_end_plus60_at_record_scheduler`。5分足終端+60秒の名目時刻を、保存Record.Atのschedulerで利用可能にする仮定で、Raw受信実測ではない。

旧Source/旧Features/旧Bank/旧チャートは再形成しない。既存3分CMPは再検算し、新5/15/30分のCSV由来指標・新SeriesBankと保護3分V5窓は形成する。Main金融は実行時に処理する。completionとprovenanceでそれぞれ別fieldへ記録する。

## 実行

Rootの正式金融条件は `fixed=true`、24configs、時計モデル、Source/旧108参照、成功停止、コード全閉包とbinaryの指紋を持つ必要がある。研究条件案の `fixed=false` では金融出力を作らない。

```powershell
三時間軸研究.exe --condition 絶対固定JSON --condition-sha SHA256 --stage first2 --out 未使用の絶対出力先
三時間軸研究.exe --condition 絶対固定JSON --condition-sha SHA256 --stage full70 --first2 絶対first2完了JSON --first2-sha SHA256 --out 別の未使用絶対出力先
```

全参照・出力は絶対path。既存outは拒否する。条件・コード・入力前後の指紋、各場のReader不変証拠、CSVとSeed、旧参照不変、Main/Shadow/比較数をcompletionへ保存する。候補ごとのCSVは後段の保存器の担当で、このCLIは金融Native JSONを出す。

## 人工検査

```powershell
Set-Location work/三時間軸の市場入出力_停止型対応
python -B -X utf8 検査と停止を記録する.py
```

人工70 Header/CSVだけでSeed前段を検査し、first2の部分成功、未知Raw保持、破損metadata、CSV指紋変更、固定/未使用mode/既存out拒否を確認する。停止Coreの買売saved人工envelopeから同じ240助走子・12当場子を再現し、実公開器→純入口→ActorのMain24全非ゼロ、Shadow0、4比較と末尾種一致を外周から確認する。停止型の失敗/空map/前後差/混在/別path偽装/実物SHA差/包含漏れも拒否する。市場のCSV/Source本文や保留11/09は検査で読まない。
