"""110の実選択Go閉包・36設定・停止を、頻度と金融の前に結合する。"""

import argparse
import copy
import json
from pathlib import Path

from 共通 import ROOT, OWN, TRIAL, MARKET, OBSERVER, JOURNAL, CLOCK, SOURCE_FIELDS, OLD_HELPER, require, sha, read, reference, bind, merge_code, stop_owned, verify_configs, verify_journal, write_new
from 閉包を収集する import legacy_metadata
from 共通 import normalize_stop_code

OLD_TECH = ROOT / "study/00109_三時間軸の取得確認と一定利益の必須保護/技法条件固定.json"
OLD_TECH_SHA = "072f0a669e3f347793a62aa06f32cd59c5cae55bf5e7daec627f6a6a26f111d7"
NEW_DIRS = ("110有効状態の入口判定", "110利益保護の純状態", "110有効入口と値幅保護の会計", "110有効状態と値幅保護の接続", "110有効状態と値幅保護の市場入出力", "110入口の頻度前検査")
PINNED = {"110有効状態の入口判定": "2174f45ac11fddbc139cc7d439258aab74b6a34f342a1141fb7b4b1fadba96fb", "110利益保護の純状態": "4172d88abd3e7250228bc3f30c1457b83a95f589a925d264991d8650de70474c"}


def design_refs(trial: Path, before: dict) -> list[dict]:
    """機能: 表の生成入力と設計選択・既使用分布を市場前の仕様へ結合する。

    引数: trial(Path)、before(dict)は正式110の位置と再確認台帳。
    返り値: list[dict]は同名copyせず元位置で固定する3Ref。保留入力を読まない。
    """
    paths = [trial / "設定定義.json", trial / "設計資料/設計の選択.json", trial / "設計資料/新規時尺度と起動候補の分布.json"]
    result = []
    for path in paths:
        item = reference(path)
        bind(item, before)
        result.append(item)
    return result


def verify_closure(value: dict, binary: dict, directory: Path, module: str, code: dict, before: dict) -> None:
    """機能: 新CLIの実選択閉包全件と5toolsを現物へ認証する。

    引数: value/binary/code/before(dict)、directory(Path)、module(str)は閉包・exe・結合先。
    返り値: None。旧109の閉包で新依存を省略した宣言を拒否する。
    """
    require(value.get("成功") is True and value.get("trial") == 110 and value.get("全選択code前後不変") is True, "110の成功した実選択閉包が必要")
    require(Path(value.get("target_dir", "")).resolve() == directory.resolve() and value.get("target_module") == "github.com/masayoshi4649/SessionTradeExecuter/" + module, "閉包対象module差")
    require(value.get("候補exe") == binary and value.get("旧Go5tool同体") is True, "閉包停止exe/Go5tool差")
    files, tools = value.get("files"), value.get("Go5tool")
    require(isinstance(files, list) and files and isinstance(tools, list) and len(tools) == 5, "実選択全件と5toolsが必要")
    tool_names = {Path(r["path"]).name.lower() for r in tools}
    require(tool_names == {"go.exe", "compile.exe", "link.exe", "asm.exe", "buildid.exe"}, "実Go5toolsの集合差")
    additions = {}
    require(len({str(Path(item["path"]).resolve()) for item in files}) == len(files), "閉包fileの重複")
    require(all(item.get("size") == Path(item["path"]).stat().st_size for item in files), "閉包fileのsize差")
    for item in files + tools:
        p = Path(item["path"])
        require(p.suffix.lower() not in (".csv", ".gz", ".jsonl", ".xlsx", ".png"), "閉包codeに市場/成果物が混入")
        require(str(p) not in additions or additions[str(p)] == item["sha256"], "閉包内の同path別SHA")
        additions[str(p)] = item["sha256"]
    require(all(any(Path(item["path"]).resolve() == Path(t["path"]).resolve() and item["sha256"] == t["sha256"] for item in files) for t in tools), "5toolsの実選択包含不足")
    metadata = value.get("選択metadata", {})
    require(set(metadata) == {"packages", "environment", "buildinfo"}, "実選択metadata出典不足")
    selected = legacy_metadata()
    packages = selected.objects(bind(metadata["packages"], before).read_bytes())
    environment = read(bind(metadata["environment"], before))
    info = bind(metadata["buildinfo"], before).read_text(encoding="utf-8")
    require(environment == value["Go環境"] and environment.get("GOVERSION") == "go1.24.2" and info == value["buildinfo"] and "github.com/masayoshi4649/SessionTradeExecuter/" + module in info, "実選択環境/buildinfo差")
    require(Path(environment["GOMOD"]).resolve() == (directory / "go.mod").resolve(), "実選択の主module位置差")
    expected_paths = {str(Path(t["path"]).resolve()) for t in tools}
    require(any(p.get("Module", {}).get("Main") and p["Module"]["Path"] == "github.com/masayoshi4649/SessionTradeExecuter/" + module for p in packages), "実選択に新主module不足")
    for package in packages:
        for field in selected.FIELDS:
            expected_paths.update(str((Path(package["Dir"]) / n).resolve()) for n in package.get(field, []))
        m = package.get("Module", {})
        for item in (m, m.get("Replace", {})):
            if item.get("GoMod"):
                expected_paths.add(str(Path(item["GoMod"]).resolve()))
            if item.get("Dir") and (Path(item["Dir"]) / "go.sum").exists():
                expected_paths.add(str((Path(item["Dir"]) / "go.sum").resolve()))
    expected_paths.update(str((directory / n).resolve()) for n in ("go.mod", "go.sum") if (directory / n).exists())
    if environment.get("GOWORK") and environment["GOWORK"] != "off":
        p = Path(environment["GOWORK"])
        expected_paths.add(str(p.resolve()))
        if Path(str(p) + ".sum").exists():
            expected_paths.add(str(Path(str(p) + ".sum").resolve()))
    require({str(Path(p["path"]).resolve()) for p in files} == expected_paths, "実Go選択metadataからのcode閉包に欠落/余分がある")
    merge_code(code, additions, before)


def snapshot(sources: list[Path], target: Path, write: bool) -> list[dict]:
    """機能: 市場前原本を同体で一度だけ保存する計画を作る。

    引数: sources(list[Path])、target(Path)、write(bool)は原本・新規保存先・保存可否。
    返り値: list[dict]は保存先Ref。validate-onlyでは作成しない。
    """
    pairs = [(p, target / p.name, sha(p)) for p in sources]
    require(all(not q.exists() for _, q, _ in pairs), "市場前snapshotは新規だけ")
    for source, dest, expected in pairs:
        if write:
            dest.parent.mkdir(parents=True, exist_ok=True)
            with dest.open("xb") as stream:
                stream.write(source.read_bytes())
            require(sha(source) == sha(dest) == expected, "snapshot前後差")
    return [{"path": str(q.resolve()), "sha256": h} for _, q, h in pairs]


def prepare(inputs: dict) -> tuple[dict, dict, list[Path]]:
    """機能: 実行前の技法固定値を本文なしで認証して組み立てる。

    引数: inputs(dict)はRootが明示する新market/observerの閉包・停止・宣言設定Ref。
    返り値: tupleは未保存固定値、再確認指紋、市場前原本一覧。市場/保留を開かない。
    """
    target = TRIAL / "技法条件固定.json"
    require(not target.exists() and not (TRIAL / "金融条件.json").exists(), "技法は初回市場前に一度だけ固定")
    require(not (ROOT / "work/110頻度/先頭2場").exists() and not (ROOT / "work/110市場/先頭2場").exists(), "first2実行前の固定が必要")
    before, code = {}, {}
    verify_journal(read(bind(reference(JOURNAL), before)))
    old = read(bind({"path": str(OLD_TECH), "sha256": OLD_TECH_SHA}, before))
    for key in SOURCE_FIELDS:
        bind(old[key], before)
    require(read(Path(old["baseline_closure"]["path"]))["試行完了"] is True, "旧108閉鎖の成功が必要")
    draft_path = TRIAL / "研究条件案.json"
    draft = read(bind(reference(draft_path), before))
    require(draft.get("fixed") is False and draft.get("financial_executed") is False and draft.get("holdout_price_unread") is True, "未固定/未金融の正式planが必要")
    declarations = read(bind(inputs["declared_configs"], before))
    configs = verify_configs(draft, declarations)
    binaries, closures, stop_refs = {}, {}, []
    for name, directory, module in (("market", MARKET, "threeguardcli110"), ("observer", OBSERVER, "threeentryfrequency110")):
        stop_ref = inputs[name + "_stop"]
        stop_path = bind(stop_ref, before)
        require(stop_path == (directory / "停止.json").resolve(), "新CLIの停止位置差")
        stopped = read(stop_path)
        require(stopped.get("成功") is True and stopped.get("停止") is True and stopped.get("試行") == 110 and stopped.get("前後不変") is True, "110CLIの人工停止が必要")
        binary = stopped.get("実行物")
        require(isinstance(binary, dict) and Path(binary["path"]).parent.resolve() == (directory / "検査").resolve(), "停止実行物Ref不足")
        bind(binary, before)
        require(binary.get("bytes") == Path(binary["path"]).stat().st_size, "停止exeのsize差")
        binaries[name] = {"path": str(Path(binary["path"]).resolve()), "sha256": binary["sha256"]}
        closure_path = bind(inputs[name + "_closure"], before)
        verify_closure(read(closure_path), binaries[name], directory, module, code, before)
        closures[name] = reference(closure_path)
        if name == "market":
            require(stopped.get("宣言設定") == {**inputs["declared_configs"], "bytes": Path(inputs["declared_configs"]["path"]).stat().st_size}, "実Go宣言とCLI停止の結合差")
    # ----------------------------------------
    # 旧停止の実体と新6部品を別の指紋で結合し、新閉包の省略には使わない。
    candidates = old["stops"] + [reference(ROOT / "work" / name / "停止.json") for name in NEW_DIRS]
    seen = set()
    for item in candidates:
        p = bind(item, before)
        if str(p) in seen:
            continue
        seen.add(str(p))
        if p.parent.name in PINNED:
            require(item["sha256"] == PINNED[p.parent.name], "既停止pureの指紋差")
        merge_code(code, normalize_stop_code(stop_owned(read(p), p.parent.name == "三時間軸の公開器")), before)
        stop_refs.append({"path": str(p), "sha256": item["sha256"]})
    own_stop = OWN / "停止.json"
    require(own_stop.exists(), "準備器の人工停止が必要")
    own_ref = reference(own_stop)
    merge_code(code, stop_owned(read(bind(own_ref, before))), before)
    for p in [OLD_HELPER, ROOT / "work/109頻度コードの閉包/収集する.py"] + sorted((ROOT / "work/110進行").glob("*.py")):
        merge_code(code, {str(p.resolve()): sha(p)}, before)
    specs = [TRIAL / "README.md", TRIAL / "設定と結果.md", draft_path]
    for p in specs:
        bind(reference(p), before)
    method = old.get("method_catalog")
    if method:
        bind(method, before)
    value = {"version": 1, "trial": 110, "fixed": True, "scope": "既使用70のE2現在有効状態/L0L1とG3G4。頻度・金融前固定、採用/有効性未証明", "clock_model": CLOCK, "quiet_seconds": 1200, "quote_max_age_seconds": 0, "configs": configs, "observer_binary": binaries["observer"], "market_binary": binaries["market"], "observer_stop": inputs["observer_stop"], "market_stop": inputs["market_stop"], "stops": stop_refs, "go_closures": closures, "code_sha256": code, "declared_configs": inputs["declared_configs"], "preparer_stop": own_ref, "financial_executed": False, "frequency_executed": False, "holdout_price_unread": True, "goal_achieved": False, "adopted": False, **{key: copy.deepcopy(old[key]) for key in SOURCE_FIELDS}}
    value["design_specifications"] = design_refs(TRIAL, before)
    if method:
        value["method_catalog"] = method
    return value, before, specs


def main() -> None:
    """機能: Root明示の初回実行でだけ技法と市場前snapshotを新規固定する。

    引数: CLIの5系列Ref(path/SHA)と任意--validate-only/--report。
    返り値: None。頻度/金融/原板/保留は呼ばず、Root進行も変更しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("market-closure", "observer-closure", "market-stop", "observer-stop", "declared-configs"):
        parser.add_argument("--" + name, type=Path, required=True)
        parser.add_argument("--" + name + "-sha", required=True)
    parser.add_argument("--validate-only", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    names = ("market_closure", "observer_closure", "market_stop", "observer_stop", "declared_configs")
    inputs = {name: {"path": str(getattr(args, name).resolve()), "sha256": getattr(args, name + "_sha")} for name in names}
    value, before, sources = prepare(inputs)
    require(all(sha(Path(p)) == h for p, h in before.items()), "技法準備中の非価格入力差")
    verify_journal(read(JOURNAL))
    target = TRIAL / "技法条件固定.json"
    value["specifications"] = snapshot(sources, TRIAL / "市場前仕様", not args.validate_only)
    value["specifications"] += value["design_specifications"]
    value["specifications"] += [reference(OWN / "README.md"), reference(OWN / "停止.json")]
    if not args.validate_only:
        write_new(target, value)
    report = {"成功": True, "保存実行": not args.validate_only, "固定先": str(target), "設定数": len(value["configs"]), "code数": len(value["code_sha256"]), "市場/金融/保留読取": False}
    if args.report:
        write_new(args.report, report)
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
