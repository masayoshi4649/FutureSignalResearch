# 110の市場前固定準備・設計資料対応

Root用の薄い固定器。旧停止物と金融算法を変更せず、metadata・実選択code・実行物を認証する。110 Mainは `(E0,L0)/(E2,L0)/(E2,L1) × G0/G3/G4 × C0/C5 × D0/D1` の36条件。正式planの `settings` だけを除き、Lifetimeを含む全欄・順序をCLIの実宣言36と比較する。

準備器の人工停止後、**Rootが技法固定を行う**。純頻度first2成功後、Rootが独立保存E/Pを含む保存停止を渡して金融条件を固定する。保存器はstage1の算法固定には混ぜず、stage2の金融前に追加束縛する。既使用探索であり採用/目標達成を宣言しない。11/09はmetadataの再取得・本文/hashとも扱わない。

## 1. 新Go閉包

`閉包を収集する.py --target market|observer --binary <停止exe絶対path> --binary-sha <SHA> --out <新規work先>`。

実行するのは `go env -json`、`go list -mod=readonly -deps -json ./...`、`go version -m <exe>` のmetadataだけ。金融/Observer exeを起動せず、test/buildもしない。新market/observerそれぞれの実選択Go/埋込/module/go.work/Go5toolsを全件hashし、前後不変を確認する。標準ライブラリやtoolのbodyは複製しない。旧109閉包で新依存を省略しない。

返り値の `選択metadata` は生のgo list/environment/buildinfoログのRef。技法固定器はその全選択を再度列挙して `files` の集合と一致させ、欠落/余分、5tools不足、code/size/実行物差を拒否する。旧109の再用はJSON連続object分解/whitelistなどの汎用補助だけで、元コードSHAを結合する。

## 2. 技法固定

```text
python 技法を固定する.py
  --market-closure <金融閉包JSON> --market-closure-sha <SHA>
  --observer-closure <純頻度閉包JSON> --observer-closure-sha <SHA>
  --market-stop <110市場CLI停止> --market-stop-sha <SHA>
  --observer-stop <110純頻度停止> --observer-stop-sha <SHA>
  --declared-configs <110市場CLI検査/宣言設定.json> --declared-configs-sha <SHA>
```

上は引数一覧。PowerShellでは1行又は適切な配列で渡す。`--validate-only --report <新規JSON>` はmetadata照合だけで、技法固定/snapshotを保存しない。

Sourceの正本は109技法固定 `072f0a66…f111d7` の106 manifest/corpus/completionと旧108 baseline closure/completion/native indexの**同じ6参照だけ**を継承する。市場本文は再読しない。新6算法停止に旧停止を加えて全所有codeを結合し、公開器だけの「コード前後map」特殊型も検査する。Go実選択閉包は新規必須。

Root進行は試行110・未金融・市場handleなし・11/09未読・未採用が必要。先頭2場の頻度/金融出力も未作成でなければ拒否する。正式研究条件案は未固定/未金融が必要。成功時だけ `study/00110_三時間軸の有効状態と値幅を残す必須保護/市場前仕様/` へREADME/設定表/planを同体で新規copyし、`技法条件固定.json` を新規作成する。保留入力ファイルをsnapshotしない。

## 3. 金融固定

```text
python 金融を固定する.py
  --technique <正式110技法固定> --technique-sha <SHA>
  --frequency-completion <work/110頻度/先頭2場/完成.json> --frequency-completion-sha <SHA>
  --saving-stop <work/110有効状態と値幅保護の保存/停止.json> --saving-stop-sha <SHA>
```

同じ `--validate-only/--report` を使える。Root進行の `技法固定` Refは正式技法と同体であること。先頭2場のSource参照/場順/時計/主228・副220、観測＋未観測＝予定分母、成功/前後指紋の包含、末尾種を認証する。報告gz/原板/CSV価格本文は読まない。純頻度はL0の予定枠診断であり、L1金融適格性・参加率ではない。

保存停止は明示110保存器だけ。人工確認/全Python依存の前後同体を金融codeへ追加する。成功時に `金融条件.json` を新規保存する。`frequency_stage=first2_verified`、`full70_frequency_verified=false` を明記し、全70の純頻度を確認済みとは書かない。金融exeの36条件/Source/baseline/clock/実行物は技法固定から値copyする。

どの処理も既存固定を上書きせず、Root進行を書き換えない。Rootは技法作成後にそのRefを進行へ記録する。途中失敗で新規snapshotが残った場合も、そのまま成功固定へ昇格しない。

## 人工検査と限界

`python -B -X utf8 人工検査.py`。手製の小metadataだけで正常/拒否を検査する。実Source・実Record/Raw/価格CSV・金融/純頻度実行は0。Go閉包収集の実施はRootが停止exeを渡した後の別metadata工程であり、最終技法/金融固定ではない。

人工は36/Lifetime/settings、通常/公開器停止型、実選択全包含・code/size/5tools/exe、snapshot非作成と新規同体copy、first2の参照/順序/分母/固定code包含、110保存停止と条件copyを確認する。`prepare()`全体の実metadata受理はRootが最終停止を揃えた後に `--validate-only` で確認する。最終固定は人工testが実行しない。

設定表の生成入力 `設定定義.json` と `設計資料/設計の選択.json`、`設計資料/新規時尺度と起動候補の分布.json` を元位置のspecRefとして市場前固定へ追加する。README/設定表/planの同体snapshot3件とは分け、同名copyの衝突を避ける。元準備停止d5ed0aaeと所有コードは不変。追加人工で3Refの包含・改変・欠落拒否を確認する。

旧公開器など停止mapのRoot相対code参照だけをRoot基準の絶対参照へ正規化する。drive相対/Traversal/正規化後の別SHA衝突は拒否する。実公開器停止の相対mapからcode現物同体までを追加人工で確認した。設計資料対応版0dbebad1と元準備d5ed0aaeは変更しない。
