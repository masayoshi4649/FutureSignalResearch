"""小さい手製metadataだけで110の固定準備を検査する。"""

import copy
from datetime import date, timedelta
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import 共通 as C
import 技法を固定する as T
import 金融を固定する as F
from 頻度の認証 import verify_frequency


def make(path: Path, value) -> dict:
    """機能: 人工metadata又は偽codeを新規作成する。

    引数: path(Path)、value(dict/str)はtemp内だけの内容。
    返り値: dictは小FileRef。市場CSV/Record/Rawは作らない。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False) if isinstance(value, dict) else value, encoding="utf-8")
    return C.reference(path)


def normal_stop(path: Path, code: Path) -> dict:
    """機能: 一ファイルの手製成功停止を作る。

    引数: path/code(Path)はtemp内の停止先と手製code。
    返り値: dictは停止Ref。実部品停止を偽装して正式保存しない。
    """
    return make(path, {"成功": True, "所有コードSHA256": {str(code): C.sha(code)}})


def fake_closure(directory: Path, module: str, output: Path) -> tuple[dict, dict]:
    """機能: 独立した手製Go metadataで閉包包含検査の器具を作る。

    引数: directory/output(Path)、module(str)はtempの対象と識別。
    返り値: tuple[dict,dict]はexeRefと閉包Ref。Go命令を呼ばない。
    """
    code = directory / "main.go"
    make(code, "package main\n")
    make(directory / "go.mod", "module github.com/masayoshi4649/SessionTradeExecuter/" + module)
    executable = make(directory / "検査/人工.exe", "実行しない人工exe")
    tool_dir = output / "人工Go"
    tools = [make(tool_dir / name, "実行しない手製tool" + name) for name in ("go.exe", "compile.exe", "link.exe", "asm.exe", "buildid.exe")]
    files = [C.reference(code), C.reference(directory / "go.mod")] + tools
    for item in files:
        item["size"] = Path(item["path"]).stat().st_size
    package = {"ImportPath": "github.com/masayoshi4649/SessionTradeExecuter/" + module, "Dir": str(directory), "GoFiles": ["main.go"], "Module": {"Main": True, "Path": "github.com/masayoshi4649/SessionTradeExecuter/" + module, "Dir": str(directory), "GoMod": str(directory / "go.mod")}}
    environment = {"GOVERSION": "go1.24.2", "GOMOD": str(directory / "go.mod"), "GOWORK": "off"}
    info = "go1.24.2 github.com/masayoshi4649/SessionTradeExecuter/" + module
    sources = {"packages": make(output / "packages.stdout", json.dumps(package)), "environment": make(output / "environment.stdout", environment), "buildinfo": make(output / "buildinfo.stdout", info)}
    value = {"成功": True, "trial": 110, "target_dir": str(directory), "target_module": package["ImportPath"], "全選択code前後不変": True, "候補exe": executable, "旧Go5tool同体": True, "files": files, "Go5tool": tools, "選択metadata": sources, "Go環境": environment, "buildinfo": info}
    return executable, make(output / "Go閉包候補.json", value)


class FixedPreparationTests(unittest.TestCase):
    """人工正常系と仕様を変えた拒否系を、市場なしで検査する。"""

    def test_relative_stop_paths(self):
        """機能: 旧公開器のRoot相対codeを正規化し逸脱と衝突を拒否する。

        引数: self(FixedPreparationTests)は手製と実停止codeだけの検査。
        返り値: None。実市場本文は開かない。
        """
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);p=root/"work/人工.go";make(p,"人工code")
            code={"work/人工.go":C.sha(p)}
            self.assertEqual(C.normalize_stop_code(code,root),{str(p):C.sha(p)})
            for broken in ({"../逸脱.go":"a"*64},{"C:相対.go":"a"*64},{**code,str(p):"b"*64}):
                with self.assertRaises(ValueError):C.normalize_stop_code(broken,root)
        actual=C.read(C.ROOT/"work/三時間軸の公開器/停止.json")
        normalized=C.normalize_stop_code(C.stop_owned(actual,True))
        self.assertTrue(all(Path(p).is_absolute() and C.sha(Path(p))==h for p,h in normalized.items()))

    def test_configs_lifetime_and_explanation(self):
        """機能: settingsだけを除外し、寿命/枚数/順序/未知欄を拒否する。

        引数: self(FixedPreparationTests)は人工検査。
        返り値: None。
        """
        rows = C.expected_configs()
        plan = {"trial": 110, "configs": [{**r, "settings": "説明"} for r in rows]}
        declared = {"trial": 110, "configs": rows}
        self.assertEqual(C.verify_configs(plan, declared), rows)
        for name in ("寿命省略", "寿命変更", "順序", "余分な欄", "旧24"):
            with self.subTest(name=name):
                broken = copy.deepcopy(declared)
                if name == "寿命省略":
                    del broken["configs"][0]["entry_lifetime"]
                elif name == "寿命変更":
                    broken["configs"][0]["entry_lifetime"] = "L1"
                elif name == "順序":
                    broken["configs"][0], broken["configs"][1] = broken["configs"][1], broken["configs"][0]
                elif name == "余分な欄":
                    broken["configs"][0]["extra"] = 1
                else:
                    broken["configs"] = broken["configs"][:24]
                with self.assertRaises(ValueError):
                    C.verify_configs(plan, broken)

    def test_stop_types_and_journal(self):
        """機能: 公開器特殊型の前後差/空code/実行開始を拒否する。

        引数: self(FixedPreparationTests)は人工検査。
        返り値: None。
        """
        value = {"成功": True, "前後不変": True, "コードSHA256前": {"人工": "a"}, "コードSHA256後": {"人工": "a"}}
        self.assertEqual(C.stop_owned(value, True), {"人工": "a"})
        for item, special in ((value, False), ({**value, "コードSHA256後": {}}, True), ({"成功": True, "所有コードSHA256": {}}, False)):
            with self.assertRaises(ValueError):
                C.stop_owned(item, special)
        journal = {"試行": 110, "市場金融実行": False, "実行中の市場handle": None, "11月09日の本文と入力指紋読取": False, "研究目標達成": False, "採用": False}
        C.verify_journal(journal)
        for name, changed in (("市場金融実行", True), ("実行中の市場handle", 1), ("11月09日の本文と入力指紋読取", True)):
            with self.assertRaises(ValueError):
                C.verify_journal({**journal, name: changed})

    def test_actual_selection_not_legacy_or_truncated(self):
        """機能: metadataの全選択包含とcode/size/tool/実行物差を拒否する。

        引数: self(FixedPreparationTests)は人工検査。
        返り値: None。Go/金融exeを一切起動しない。
        """
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            directory = root / "市場CLI"
            binary, ref = fake_closure(directory, "threeguardcli110", root / "閉包")
            value = C.read(Path(ref["path"]))
            T.verify_closure(value, binary, directory, "threeguardcli110", {}, {})
            for name in ("欠落", "余分", "size", "旧module", "tool不足", "code改変", "exe差"):
                with self.subTest(name=name):
                    v = copy.deepcopy(value)
                    if name == "欠落":
                        v["files"] = v["files"][1:]
                    elif name == "余分":
                        extra = make(root / "使われない.go", "未選択")
                        v["files"].append({**extra, "size": Path(extra["path"]).stat().st_size})
                    elif name == "size":
                        v["files"][0]["size"] += 1
                    elif name == "旧module":
                        v["target_module"] = "github.com/masayoshi4649/SessionTradeExecuter/threeguardcli109"
                    elif name == "tool不足":
                        v["Go5tool"] = v["Go5tool"][:4]
                    elif name == "code改変":
                        v["files"][0]["sha256"] = "b" * 64
                    else:
                        v["候補exe"]["sha256"] = "b" * 64
                    with self.assertRaises(ValueError):
                        T.verify_closure(v, binary, directory, "threeguardcli110", {}, {})

    def test_snapshot_is_copy_and_new_only(self):
        """機能: validate-only非作成と同体snapshot/再保存拒否を確認する。

        引数: self(FixedPreparationTests)は人工検査。
        返り値: None。tempの小MDだけを使用する。
        """
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "原本.md"
            make(source, "市場前の人工仕様\n")
            planned = T.snapshot([source], root / "snapshot", False)
            self.assertFalse((root / "snapshot").exists())
            result = T.snapshot([source], root / "snapshot", True)
            self.assertEqual(planned, result)
            self.assertEqual(source.read_bytes(), (root / "snapshot/原本.md").read_bytes())
            with self.assertRaises(ValueError):
                T.snapshot([source], root / "snapshot", True)

    def test_design_inputs_bound_without_name_collision(self):
        """機能: 設計入力3Refを元位置へ束縛し同名snapshotへ潰さない。

        引数: self(FixedPreparationTests)は人工小JSONの検査。
        返り値: None。正式分布や保留入力は開かない。
        """
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            names=["設定定義.json","設計資料/設計の選択.json","設計資料/新規時尺度と起動候補の分布.json"]
            for name in names:
                make(root/name,{"人工":name})
            before={};items=T.design_refs(root,before)
            self.assertEqual([Path(r["path"]) for r in items],[root/n for n in names])
            self.assertEqual(len(before),3)
            (root/names[0]).write_text("変更",encoding="utf-8")
            self.assertNotEqual(C.sha(root/names[0]),before[str(root/names[0])])
            (root/names[1]).unlink()
            with self.assertRaises(FileNotFoundError):
                T.design_refs(root,{})

    def test_first2_frequency_metadata(self):
        """機能: 同技法first2の認証と参照/分母/順序/指紋不足の拒否を確認する。

        引数: self(FixedPreparationTests)は人工検査。
        返り値: None。報告gz/CSVは存在すら作らず、本文非読取も確認する。
        """
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            h = "a" * 64
            ref = lambda name: {"path": str((root / name).resolve()), "sha256": h}
            ids = [f"{date(2026, 1, 1) + timedelta(days=i // 2)}_{'Day' if i % 2 == 0 else 'Night'}" for i in range(70)]
            manifest = {"source_root": str(root / "入力"), "sessions": [{"id": x, "contract": "人工限月", "files": {"NK225_candle_300": {"path": x + ".csv", "sha256": h, "size": 10}}} for x in ids]}
            tech = {"observer_binary": ref("人工.exe"), "observer_stop": ref("停止.json"), "source_manifest": ref("manifest.json"), "source_corpus": ref("corpus.json"), "source_completion": ref("source.json"), "code_sha256": {str(root / "人工.go"): h}}
            tech_ref, request_ref = ref("技法.json"), ref("要求.json")
            config = {"clock_model": C.CLOCK, "quote_max_age_seconds": 0, "quiet_seconds": 1200}
            request = {"version": 1, "trial": 110, "fixed": True, "stage": "first2", "technique_fixed": tech_ref, "output_dir": str(root / "出力"), "manifest": tech["source_manifest"], "corpus": tech["source_corpus"], "source_completion": tech["source_completion"], **config, "scenes": [{"session": x, "candle_csv": {"path": str(root / "入力" / (x + ".csv")), "sha256": h, "bytes": 10}} for x in ids[:2]]}
            before = {r["path"]: r["sha256"] for r in [tech_ref, request_ref, tech["observer_binary"], tech["observer_stop"], tech["source_manifest"], tech["source_corpus"], tech["source_completion"]]}
            before.update(tech["code_sha256"])
            results = []
            for i, x in enumerate(ids[:2]):
                primary, secondary = (78, 74) if i == 0 else (150, 146)
                row = {"session": x, "report": ref("出力/" + x + ".json.gz"), "end_seed": {"sealed": True, "session": {"id": x, "contract": "人工限月", "eof": 1}, "observed_at": 1, "sha256": h}}
                for prefix, count in (("primary", primary), ("secondary", secondary)):
                    row.update({prefix + "_planned_grids": count, prefix + "_observed_grids": count, prefix + "_unobserved_grids": 0, prefix + "_technical_allowed_grids": 0, prefix + "_source_allowed_grids": 0})
                results.append(row)
            value = {"version": 1, "trial": 110, "stage": "first2", "success": True, "financial_executed": False, "participation_calculated": False, "unchanged": True, "before": before, "after": copy.deepcopy(before), "request": request_ref, "technique_fixed": tech_ref, "config": config, "manifest": tech["source_manifest"], "corpus": tech["source_corpus"], "source_completion": tech["source_completion"], "results": results}
            verify_frequency(value, request, tech, tech_ref, request_ref, manifest, "first2")
            for name in ("別技法", "Source差", "順序", "分母", "入力指紋不足", "full70偽称", "参加率済み", "CSV宣言差"):
                with self.subTest(name=name):
                    v, q = copy.deepcopy(value), copy.deepcopy(request)
                    if name == "別技法":
                        v["technique_fixed"]["sha256"] = "b" * 64
                    elif name == "Source差":
                        q["corpus"] = ref("違うcorpus.json")
                    elif name == "順序":
                        v["results"].reverse()
                    elif name == "分母":
                        v["results"][0]["primary_planned_grids"] = 79
                    elif name == "入力指紋不足":
                        del v["before"][str(root / "人工.go")]
                        v["after"] = copy.deepcopy(v["before"])
                    elif name == "full70偽称":
                        v["stage"] = "full70"
                    elif name == "参加率済み":
                        v["participation_calculated"] = True
                    else:
                        q["scenes"][0]["candle_csv"]["bytes"] = 11
                    with self.assertRaises(ValueError):
                        verify_frequency(v, q, tech, tech_ref, request_ref, manifest, "first2")

    def test_saving_stage_and_projection(self):
        """機能: 110保存停止のみ認証し、金融へ36条件を値copyする。

        引数: self(FixedPreparationTests)は人工停止と射影の検査。
        返り値: None。市場会計は計算しない。
        """
        h = "a" * 64
        code = {str(F.SAVING / (str(i) + ".py")): h for i in range(7)}
        stop = {"version": 1, "trial": 110, "停止": True, "入力前後不変": True, "実市場読取": False, "実金融": False, "CSV/xlsx生成": False, "コードSHA256": code, "仕様": {"path": "仕様", "sha256": h}, "検査": {"path": "検査", "sha256": h}}
        check = {"成功": True, "exit_code": 0, "前後不変": True, "コードSHA256前": code, "コードSHA256後": code, "入力SHA256前": {"人工": h}, "入力SHA256後": {"人工": h}}
        self.assertEqual(F.verify_saving(stop, check), code)
        with self.assertRaises(ValueError):
            F.verify_saving({**stop, "trial": 109}, check)
        with self.assertRaises(ValueError):
            F.verify_saving(stop, {**check, "入力SHA256後": {}})
        tech = {"configs": C.expected_configs(), "market_binary": {}, "stops": [], "specifications": [], **{key: {"人工": key} for key in C.SOURCE_FIELDS}}
        result = F.build_condition(tech, {}, {}, {}, stop, code)
        self.assertEqual(result["configs"], C.expected_configs())
        self.assertEqual(result["frequency_stage"], "first2_verified")
        self.assertFalse(result["full70_frequency_verified"])
        self.assertFalse(result["financial_executed"])
        result["configs"][0]["entry_lifetime"] = "変更"
        self.assertEqual(tech["configs"][0]["entry_lifetime"], "L0")


if __name__ == "__main__":
    unittest.main(verbosity=2)
