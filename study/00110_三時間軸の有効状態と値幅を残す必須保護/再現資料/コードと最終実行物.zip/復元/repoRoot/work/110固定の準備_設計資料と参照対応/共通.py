"""110の市場前固定に使う、非市場metadataの共通検査。"""

import copy
import importlib.util
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
TRIAL = ROOT / "study/00110_三時間軸の有効状態と値幅を残す必須保護"
CLOCK = "csv_end_plus60_at_record_scheduler"
MARKET = ROOT / "work/110有効状態と値幅保護の市場入出力"
OBSERVER = ROOT / "work/110入口の頻度前検査"
JOURNAL = ROOT / "work/110進行/現在.json"
SOURCE_FIELDS = ("source_manifest", "source_corpus", "source_completion", "baseline_closure", "baseline_completion", "baseline_native_index")
OLD_HELPER = ROOT / "work/109金融条件の準備_保存派生対応/固定する.py"
OLD_SHA = "d5b381e04cb3ad14bf29231583955b053fffa345d66d8cb68abb52ec71b70e8b"


def load_generic():
    """機能: 停止109の汎用小関数だけを改変せず再用する。

    引数: なし。
    返り値: moduleはsha/read/bind/merge_code等の元実装。109政策の検査関数は呼ばない。
    """
    import hashlib
    if hashlib.sha256(OLD_HELPER.read_bytes()).hexdigest() != OLD_SHA:
        raise ValueError("再用109汎用helperの指紋差")
    spec = importlib.util.spec_from_file_location("固定109汎用関数", OLD_HELPER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


OLD = load_generic()
require, sha, read = OLD.require, OLD.sha, OLD.read
reference, bind, merge_code = OLD.reference, OLD.bind, OLD.merge_code
valid_ref, path_key, write_new = OLD.valid_ref, OLD.path_key, OLD.write_new
fingerprint_map, nonnegative = OLD.fingerprint_map, OLD.nonnegative


def expected_configs() -> list[dict]:
    """機能: 110の技法と寿命を分けた明示36設定を返す。

    引数: なし。
    返り値: list[dict]は正式plan/CLIと比較する同順の設定。settings欄は含めない。
    """
    rows = []
    for entry, lifetime in (("entry_E0", "L0"), ("entry_E2", "L0"), ("entry_E2", "L1")):
        for protection in ("G0", "G3", "G4"):
            candidate = f"{entry}_{protection}" if entry == "entry_E0" else f"{entry}_{lifetime}_{protection}"
            for slip in (0, 5):
                for delay in (0, 1):
                    rows.append({"candidate": candidate, "entry_policy": entry, "entry_lifetime": lifetime, "protection_policy": protection, "entry_timing": "B5QD", "quiet_seconds": 1200, "slip_pts": slip, "delay_seconds": delay})
    return rows


def verify_configs(plan: dict, declared: dict) -> list[dict]:
    """機能: 正式planから説明欄だけ除き、実Go宣言と36条件を照合する。

    引数: plan/declared(dict)は研究条件案と停止CLIがexportした実返り値。
    返り値: list[dict]は同体確認済み設定。寿命の省略や余分な欄は拒否する。
    """
    require(plan.get("trial") == declared.get("trial") == 110, "110のplan/実宣言が必要")
    rows = [{k: copy.deepcopy(v) for k, v in row.items() if k != "settings"} for row in plan.get("configs", [])]
    require(rows == declared.get("configs") == expected_configs(), "正式plan/実Go宣言/Main36差（Lifetime含む）")
    return rows


def verify_journal(value: dict) -> None:
    """機能: 実金融前と未使用入力の保持を確認する。

    引数: value(dict)はRootの進行metadata。
    返り値: None。市場handle/実行済み/未読解除では拒否する。
    """
    require(value.get("試行") == 110 and value.get("市場金融実行") is False and value.get("実行中の市場handle") is None and "実行中の市場handle" in value, "110進行の未金融/handle差")
    require(value.get("11月09日の本文と入力指紋読取") is False and value.get("研究目標達成") is False and value.get("採用") is False, "未使用保持/未採用の範囲差")


def stop_owned(value: dict, publisher: bool = False) -> dict:
    """機能: 通常型と公開器だけの前後map型を厳密に受理する。

    引数: value(dict)、publisher(bool)は停止metadataと明示された特殊型指定。
    返り値: dictは所有code。空mapや前後差、他dirでの特殊型使用を拒否する。
    """
    require(value.get("成功") is True, "成功停止が必要")
    if publisher:
        require(value.get("前後不変") is True and value.get("コードSHA256前") == value.get("コードSHA256後"), "公開器停止の前後差")
        code = value.get("コードSHA256後")
    else:
        code = value.get("所有コードSHA256")
    require(isinstance(code, dict) and bool(code), "空でない所有codeが必要")
    return code


def normalize_stop_code(code: dict, root: Path = ROOT) -> dict:
    """機能: 旧停止のRoot相対参照を絶対codeへ正規化する。

    引数: code(dict)、root(Path)は検証済み停止mapとリポジトリ基準。
    返り値: dictは絶対code。Traversal/drive相対/同path別SHAを拒否する。
    """
    result, seen = {}, {}
    for name, expected in code.items():
        p = Path(name)
        if not p.is_absolute():
            require(not p.drive and ".." not in p.parts, "停止codeのdrive相対/Traversalは禁止")
            p = (root / p).resolve()
            require(p.is_relative_to(root.resolve()), "相対codeがrepo外へ逸脱")
        else:
            p = p.resolve()
        key = path_key(p)
        require(key not in seen or seen[key] == expected, "正規化した停止codeの指紋衝突")
        seen[key] = expected
        result[str(p)] = expected
    return result


def verify_technique(value: dict) -> None:
    """機能: 頻度と金融が参照する110技法固定を認証する。

    引数: value(dict)は市場前の技法固定JSON。
    返り値: None。旧24条件・未固定・既実行のmetadataを拒否する。
    """
    require(value.get("version") == 1 and value.get("trial") == 110 and value.get("fixed") is True, "110技法固定が必要")
    require(value.get("configs") == expected_configs() and value.get("clock_model") == CLOCK and value.get("quiet_seconds") == 1200 and value.get("quote_max_age_seconds") == 0, "技法36/時計差")
    require(all(value.get(k) is False for k in ("financial_executed", "frequency_executed", "goal_achieved", "adopted")) and value.get("holdout_price_unread") is True, "市場前範囲差")
    require(isinstance(value.get("code_sha256"), dict) and value["code_sha256"] and len(value.get("stops", [])) >= 8 and len(value.get("specifications", [])) >= 4, "固定code/stop/spec不足")
