"""110の技法固定と成功first2純頻度・保存停止を金融条件へ結合する。"""

import argparse
import copy
import json
from pathlib import Path

from 共通 import ROOT, OWN, TRIAL, MARKET, JOURNAL, CLOCK, SOURCE_FIELDS, require, sha, read, reference, bind, merge_code, verify_journal, verify_technique, write_new
from 頻度の認証 import verify_frequency

SAVING = ROOT / "work/110有効状態と値幅保護の保存"


def verify_saving(stop: dict, check: dict) -> dict:
    """機能: Rootの110独立保存器の人工停止と全Python依存を認証する。

    引数: stop/check(dict)は明示停止と成功人工確認。
    返り値: dictは所有・再用を含む全コード。109のenum/key置換を受理しない。
    """
    require(stop.get("version") == 1 and stop.get("trial") == 110 and stop.get("停止") is True and stop.get("入力前後不変") is True and stop.get("実市場読取") is False and stop.get("実金融") is False and stop.get("CSV/xlsx生成") is False, "110保存器の人工停止範囲差")
    code = stop.get("コードSHA256")
    require(isinstance(code, dict) and code and check.get("成功") is True and check.get("exit_code") == 0 and check.get("前後不変") is True and check.get("コードSHA256前") == code == check.get("コードSHA256後"), "保存code前後/確認差")
    require(check.get("入力SHA256前") and check["入力SHA256前"] == check.get("入力SHA256後"), "保存器人工入力前後差")
    require(all(Path(p).suffix == ".py" for p in code) and sum(Path(p).parent.resolve() == SAVING.resolve() for p in code) >= 7, "保存器の所有/再用Python不足")
    return code


def build_condition(tech: dict, tech_ref: dict, frequency_ref: dict, saving_ref: dict, saving: dict, code: dict) -> dict:
    """機能: 同体の36条件を停止市場CLIのConditionへ射影する。

    引数: tech/各Ref/saving/code(dict)は認証済み非価格metadata。
    返り値: dictは未実行金融条件。first2成功をfull70成功と呼ばない。
    """
    result = {"version": 1, "trial": 110, "fixed": True, "scope": "同技法の先頭2純頻度成功後、Main36を金融で検証。既使用探索、採用/安定性未証明", "source_scope": "recorded_public_106", "clock_model": CLOCK, "workers": 4, "own_module_dir": str(MARKET.resolve()), "binary": copy.deepcopy(tech["market_binary"]), "configs": copy.deepcopy(tech["configs"]), "stops": copy.deepcopy(tech["stops"]), "specifications": copy.deepcopy(tech["specifications"]) + [tech_ref, frequency_ref, saving_ref, saving["仕様"], saving["検査"]], "code_sha256": dict(code), "technique_fixed": tech_ref, "frequency_completion": frequency_ref, "frequency_stage": "first2_verified", "saving_stop": saving_ref, "financial_executed": False, "frequency_executed": True, "full70_frequency_verified": False, "participation_calculated": False, "holdout_price_unread": True, "goal_achieved": False, "adopted": False, "frequency_evidence": "同技法のfirst2完成metadata/指紋宣言/主228副220を認証。価格本文/参加率/損益を再読計算しない。L0予定枠診断はL1の金融適格性でない", "participation_denominator": {"primary": 7980, "secondary": 7700, "unknown_kept": True}}
    result.update({k: copy.deepcopy(tech[k]) for k in SOURCE_FIELDS})
    if "method_catalog" in tech:
        result["method_catalog"] = copy.deepcopy(tech["method_catalog"])
    return result


def prepare(tech_ref: dict, frequency_ref: dict, saving_ref: dict) -> tuple[dict, dict]:
    """機能: 実金融前の技法・first2頻度・独立保存を認証する。

    引数: tech_ref/frequency_ref/saving_ref(dict)はRoot明示の小metadata参照。
    返り値: tuple[dict,dict]は未保存条件と再確認指紋。実行物や市場を起動しない。
    """
    require(not (TRIAL / "金融条件.json").exists(), "金融条件は新規だけ")
    require(not (ROOT / "work/110市場/先頭2場").exists(), "金融first2より前に固定")
    before, code = {}, {}
    journal = read(bind(reference(JOURNAL), before))
    verify_journal(journal)
    tech_path = bind(tech_ref, before)
    require(tech_path == (TRIAL / "技法条件固定.json").resolve(), "正式110技法固定だけ")
    tech = read(tech_path)
    verify_technique(tech)
    require(journal.get("技法固定") == tech_ref, "Root進行と正式技法固定の結合差")
    merge_code(code, tech["code_sha256"], before)
    for item in [tech["market_binary"], tech["observer_binary"], tech["observer_stop"]] + tech["stops"] + tech["specifications"] + list(tech["go_closures"].values()) + [tech[k] for k in SOURCE_FIELDS]:
        bind(item, before)
    frequency_path = bind(frequency_ref, before)
    require(frequency_path.resolve() == (ROOT / "work/110頻度/先頭2場/完成.json").resolve(), "正式first2頻度完成だけ")
    frequency = read(frequency_path)
    request_ref = frequency["request"]
    request = read(bind(request_ref, before))
    require(Path(request["output_dir"]).resolve() == frequency_path.parent, "完成と要求の出力位置差")
    manifest = read(Path(tech["source_manifest"]["path"]))
    verify_frequency(frequency, request, tech, tech_ref, request_ref, manifest, "first2")
    require(sum(r["primary_planned_grids"] for r in frequency["results"]) == 228 and sum(r["secondary_planned_grids"] for r in frequency["results"]) == 220, "first2主228/副220の保持")
    saving_path = bind(saving_ref, before)
    require(saving_path == (SAVING / "停止.json").resolve(), "明示110保存器の停止だけ")
    saving = read(saving_path)
    check_path = bind(saving["検査"], before)
    bind(saving["仕様"], before)
    merge_code(code, verify_saving(saving, read(check_path)), before)
    value = build_condition(tech, tech_ref, frequency_ref, saving_ref, saving, code)
    return value, before


def main() -> None:
    """機能: Rootが認証した成功first2の後にだけ金融条件を新規固定する。

    引数: --technique/--frequency-completion/--saving-stopと各--sha、任意--validate-only/--report。
    返り値: None。金融/頻度exeやCSV/原板/報告本文を呼ばない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("technique", "frequency-completion", "saving-stop"):
        parser.add_argument("--" + name, type=Path, required=True)
        parser.add_argument("--" + name + "-sha", required=True)
    parser.add_argument("--validate-only", action="store_true")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    inputs = [{"path": str(getattr(args, name).resolve()), "sha256": getattr(args, name + "_sha")} for name in ("technique", "frequency_completion", "saving_stop")]
    value, before = prepare(*inputs)
    require(all(sha(Path(p)) == h for p, h in before.items()), "金融固定中の非価格入力差")
    verify_journal(read(JOURNAL))
    target = TRIAL / "金融条件.json"
    if not args.validate_only:
        write_new(target, value)
    report = {"成功": True, "保存実行": not args.validate_only, "固定先": str(target), "条件数": len(value["configs"]), "frequency_stage": value["frequency_stage"], "市場/金融/保留読取": False}
    if args.report:
        write_new(args.report, report)
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
