"""110の成功first2純頻度metadataだけを検査する。価格本文を読まない。"""

from pathlib import Path
from 共通 import require, fingerprint_map, valid_ref, path_key, nonnegative, CLOCK, OLD
SHA_PATTERN=OLD.SHA_PATTERN

def verify_frequency(value: dict, request: dict, tech: dict, tech_ref: dict,
                     request_ref: dict, manifest: dict, stage: str) -> None:
    """機能: 同技法の成功頻度metadataと固定分母を照合する。

    引数: value/request/tech/tech_ref/request_ref/manifest(dict)、stage(str)は完成・要求・固定・入力順。
    返り値: None。頻度を参加率/金融品質再検算/損益と扱わない。
    """
    require(stage == 'first2', '金融前認証は成功first2だけ')
    count = 2
    ids = [row['id'] for row in manifest['sessions']]
    require(len(ids) == len(set(ids)) == 70 and ids == sorted(ids), 'manifestは明示70場の時系列')
    require(value.get('version') == 1 and value.get('trial') == 110 and value.get('stage') == stage and
            value.get('success') is True and value.get('financial_executed') is False and
            value.get('participation_calculated') is False and value.get('unchanged') is True and not value.get('error'), '成功頻度と非金融/非参加')
    require(value.get('before') == value.get('after'), '頻度前後指紋の宣言差')
    fingerprints = fingerprint_map(value['before'])
    require(value.get('request') == request_ref and value.get('technique_fixed') == tech_ref, '頻度の要求/同技法SHA差')
    config = {'clock_model': CLOCK, 'quote_max_age_seconds': 0, 'quiet_seconds': 1200}
    require(value.get('config') == config, '頻度の時計/年齢/静観差')
    require(request.get('version') == 1 and request.get('trial') == 110 and request.get('fixed') is True and
            request.get('stage') == stage and request.get('technique_fixed') == tech_ref and
            all(request.get(k) == v for k, v in config.items()), '頻度要求の固定差')
    for src, freq in (('source_manifest', 'manifest'), ('source_corpus', 'corpus'), ('source_completion', 'source_completion')):
        require(value.get(freq) == request.get(freq) == tech[src], '頻度Source参照差: ' + src)
    expected_refs = [tech_ref, request_ref, tech['observer_binary'], tech['observer_stop']]
    expected_refs += [tech[k] for k in ('source_manifest', 'source_corpus', 'source_completion')]
    expected_refs += [{'path': p, 'sha256': h} for p, h in tech['code_sha256'].items()]
    for ref in expected_refs:
        require(fingerprints.get(path_key(valid_ref(ref))) == ref['sha256'], '頻度が実使用した固定指紋の包含不足')
    results, scenes = value.get('results', []), request.get('scenes', [])
    require([r['session'] for r in results] == [s['session'] for s in scenes] == ids[:count], '頻度70場順/要求場順差')
    require(Path(request.get('output_dir', '')).is_absolute(), '頻度の絶対出力先が必要')
    root = Path(manifest['source_root'])
    require(root.is_absolute(), 'manifestの絶対source_rootが必要')
    for i, (row, scene) in enumerate(zip(results, scenes)):
        csv = manifest['sessions'][i]['files']['NK225_candle_300']
        expected_csv = {'path': str((root / csv['path']).resolve()), 'sha256': csv['sha256'], 'bytes': csv['size']}
        require(scene.get('candle_csv') == expected_csv, '頻度要求のNK225 CSV宣言差')
        valid_ref(row['report'])  # 本文は公表値を含むので読まない。
        require(valid_ref(row['report']).parent == Path(request['output_dir']).resolve(), '頻度場別報告の出力位置差')
        day = row['session'].endswith('_Day')
        require(day or row['session'].endswith('_Night'), '日夜の場識別が必要')
        primary, secondary = (78, 74) if day else (150, 146)
        for prefix, planned in (('primary', primary), ('secondary', secondary)):
            vals = [row.get(prefix + suffix) for suffix in ('_planned_grids', '_observed_grids', '_unobserved_grids')]
            require(all(nonnegative(v) for v in vals) and vals[0] == planned and vals[1] + vals[2] == vals[0], '主副予定分母/未知保持差')
            for suffix in ('_technical_allowed_grids', '_source_allowed_grids'):
                n = row.get(prefix + suffix)
                require(nonnegative(n) and n <= vals[1], '成立枠は観測枠以下')
        seed = row.get('end_seed', {})
        require(seed.get('sealed') is True and seed.get('session', {}).get('id') == row['session'] and
                seed.get('session', {}).get('contract') == manifest['sessions'][i]['contract'] and
                seed.get('observed_at') == seed.get('session', {}).get('eof') and
                SHA_PATTERN.fullmatch(seed.get('sha256', '')) is not None, '頻度末尾種の封印/場/指紋差')
    if stage == 'full70':
        require(sum(r['primary_planned_grids'] for r in results) == 7980 and
                sum(r['secondary_planned_grids'] for r in results) == 7700, '正式70の主7980/副7700が必要')

