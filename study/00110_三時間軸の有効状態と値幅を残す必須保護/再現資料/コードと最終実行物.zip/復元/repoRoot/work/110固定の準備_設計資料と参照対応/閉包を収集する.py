"""110の新Go実選択閉包をmetadataだけで収集する。"""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess

from 共通 import ROOT, MARKET, OBSERVER, require, sha, read, reference, write_new

LEGACY = ROOT / "work/109頻度コードの閉包/収集する.py"
LEGACY_SHA = "b22715e2ac33f4b12e0f5f2f18d6386b885b164ff0604a2192db028a78588928"
TARGETS = {"market": (MARKET, "threeguardcli110"), "observer": (OBSERVER, "threeentryfrequency110")}


def legacy_metadata():
    """機能: 旧収集器のJSON分割・選択欄・環境whitelistだけを再用する。

    引数: なし。
    返り値: moduleは未改変のmetadata補助。109のrun/mainは呼ばない。
    """
    require(sha(LEGACY) == LEGACY_SHA, "旧閉包補助の指紋差")
    spec = importlib.util.spec_from_file_location("閉包109補助", LEGACY)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def collect(target: str, binary_ref: dict, output: Path) -> dict:
    """機能: 新moduleの実選択codeと5toolsを新規の閉包候補へ結ぶ。

    引数: target(str)、binary_ref(dict)、output(Path)は明示対象/停止exe参照/新規証拠先。
    返り値: dictは閉包。市場exeを起動せずgo env/list/versionだけを呼ぶ。
    """
    require(target in TARGETS, "market/observerだけ")
    require(not output.exists(), "閉包出力は新規dirだけ")
    directory, module = TARGETS[target]
    binary = Path(binary_ref["path"]).resolve()
    require(binary.parent == (directory / "検査").resolve() and sha(binary) == binary_ref["sha256"], "明示停止exeの位置/SHA差")
    old = legacy_metadata()
    output.mkdir(parents=True)

    def command(argv: list[str], name: str) -> bytes:
        """機能: build/市場を呼ばないGo metadataを実CLI位置で取得する。

        引数: argv(list[str])、name(str)は許可命令とログ識別。
        返り値: bytesはstdout。非0終了では閉包成功を作らない。
        """
        run = subprocess.run(argv, cwd=directory, capture_output=True)
        (output / (name + ".stdout")).write_bytes(run.stdout)
        (output / (name + ".stderr")).write_bytes(run.stderr)
        write_new(output / (name + ".command.json"), {"argv": argv, "cwd": str(directory), "exit_code": run.returncode})
        require(run.returncode == 0, "metadata命令失敗:" + name)
        return run.stdout

    module_paths = [directory / name for name in ("go.mod", "go.sum") if (directory / name).exists()]
    before = {str(p): sha(p) for p in module_paths}
    env = json.loads(command(["go", "env", "-json", *old.ENV_KEYS], "Go環境"))
    require(env["GOVERSION"] == "go1.24.2" and env["GOOS"] == "windows" and env["GOARCH"] == "amd64", "停止対象Go1.24.2/windows/amd64が必要")
    packages = old.objects(command(["go", "list", "-mod=readonly", "-deps", "-json", "./..."], "Go実選択"))
    require(any(p.get("Module", {}).get("Main") and p["Module"]["Path"].endswith("/" + module) for p in packages), "新対象moduleが選択されていない")
    roots = [("goRoot", Path(env["GOROOT"]).resolve()), ("repoRoot", ROOT), ("neighborRoot", ROOT.parent), ("moduleCacheRoot", Path(env["GOMODCACHE"]).resolve())]
    entries = {}

    def add(path: Path, role: str) -> None:
        """機能: Goが実際に選択したcodeの元位置とSHAだけを記録する。

        引数: path(Path)、role(str)は実選択ファイルと根拠。
        返り値: None。市場系拡張子や未知rootをhash前に拒否する。
        """
        path = path.resolve()
        require(path.suffix.lower() not in (".csv", ".gz", ".jsonl", ".xlsx", ".png") and not path.name.endswith((".Native.json", ".resources.json")), "codeへ市場/成果物混入")
        group = next(((n, r) for n, r in roots if path.is_relative_to(r)), None)
        require(group is not None, "未定義code root")
        h = sha(path)
        key = str(path)
        if key in entries:
            require(entries[key]["sha256"] == h, "収集中code変更")
            if role not in entries[key]["roles"]:
                entries[key]["roles"].append(role)
            return
        entries[key] = {"path": key, "sha256": h, "size": path.stat().st_size, "root": group[0], "relative": path.relative_to(group[1]).as_posix(), "roles": [role], "body保存": False}

    for package in packages:
        for field in old.FIELDS:
            for filename in package.get(field, []):
                add(Path(package["Dir"]) / filename, field)
        module_info = package.get("Module", {})
        for item in (module_info, module_info.get("Replace", {})):
            if item.get("GoMod"):
                add(Path(item["GoMod"]), "module_go.mod")
            if item.get("Dir") and (Path(item["Dir"]) / "go.sum").exists():
                add(Path(item["Dir"]) / "go.sum", "module_go.sum")
    for path in module_paths:
        add(path, "main_module")
    if env.get("GOWORK") and env["GOWORK"] != "off":
        p = Path(env["GOWORK"])
        add(p, "go.work")
        if Path(str(p) + ".sum").exists():
            add(Path(str(p) + ".sum"), "go.work.sum")
    tools = [Path(env["GOROOT"]) / "bin/go.exe"] + [Path(env["GOTOOLDIR"]) / (name + ".exe") for name in ("compile", "link", "asm", "buildid")]
    for path in tools:
        add(path, "Go_toolchain_5exe")
    buildinfo = command(["go", "version", "-m", str(binary)], "停止exe_buildinfo").decode("utf-8")
    require("go1.24.2" in buildinfo and "github.com/masayoshi4649/SessionTradeExecuter/" + module in buildinfo, "停止exeのmodule/Go版差")
    old_tech = ROOT / "study/00109_三時間軸の取得確認と一定利益の必須保護/技法条件固定.json"
    require(sha(old_tech) == "072f0a669e3f347793a62aa06f32cd59c5cae55bf5e7daec627f6a6a26f111d7", "旧技法のGo tool証拠差")
    old_code = {str(Path(k).resolve()): h for k, h in read(old_tech)["code_sha256"].items()}
    require(all(old_code.get(str(p.resolve())) == sha(p) for p in tools), "固定済みGo5tool差")
    require(before == {str(p): sha(p) for p in module_paths}, "readonly中のmodule変更")
    require(all(sha(Path(p)) == value["sha256"] for p, value in entries.items()) and sha(binary) == binary_ref["sha256"], "閉包又はexeの前後差")
    result = {"成功": True, "trial": 110, "target_module": "github.com/masayoshi4649/SessionTradeExecuter/" + module, "target_dir": str(directory), "全選択code前後不変": True, "候補exe": reference(binary), "Go環境": env, "files": list(entries.values()), "Go5tool": [reference(p) for p in tools], "buildinfo": buildinfo, "packages": [{k: p[k] for k in ("ImportPath", "Dir", "Module") if k in p} for p in packages], "選択metadata": {"packages": reference(output / "Go実選択.stdout"), "environment": reference(output / "Go環境.stdout"), "buildinfo": reference(output / "停止exe_buildinfo.stdout")}, "旧Go5tool同体": True, "市場実行": False, "再用補助": reference(LEGACY)}
    write_new(output / "Go閉包候補.json", result)
    return result


def main() -> None:
    """機能: Rootが明示する新CLIのmetadata候補だけを収集する。

    引数: --target/--binary/--binary-sha/--outは対象と新規証拠先。
    返り値: None。最終固定は別段階で、ここでは行わない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--target", choices=TARGETS, required=True)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--binary-sha", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    result = collect(args.target, {"path": str(args.binary.resolve()), "sha256": args.binary_sha}, args.out.resolve())
    print(json.dumps({"成功": True, "選択数": len(result["files"]), "閉包": reference(args.out / "Go閉包候補.json")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
