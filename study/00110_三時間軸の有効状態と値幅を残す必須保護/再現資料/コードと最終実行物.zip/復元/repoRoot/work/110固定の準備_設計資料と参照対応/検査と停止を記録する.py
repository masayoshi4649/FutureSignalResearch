"""110固定準備の人工確認だけを実行して停止する。"""

import ast
import json
from pathlib import Path
import subprocess
import sys

from 共通 import OWN, OLD_HELPER, require, sha, reference, write_new


def main() -> None:
    """機能: 構文/人工/所有と再用codeの不変を停止へ記録する。

    引数: なし。正式固定、Go metadata収集、金融/市場を呼ばない。
    返り値: None。既存停止は上書きしない。
    """
    stop = OWN / "停止.json"
    require(not stop.exists(), "準備器停止は新規だけ")
    paths = sorted(OWN.glob("*.py")) + [OWN / "README.md", OWN / "派生元.json"]
    reused = [OLD_HELPER, OWN.parent / "109頻度コードの閉包/収集する.py"]
    before = {str(p): sha(p) for p in paths}
    prior = {str(p): sha(p) for p in reused}
    origin=json.loads((OWN/"派生元.json").read_text(encoding="utf-8"))
    require(sha(Path(origin["path"]))==origin["sha256"],"派生元の停止差")
    origin_code=json.loads(Path(origin["path"]).read_text(encoding="utf-8"))["所有コードSHA256"]
    require(all(sha(Path(p))==h for p,h in origin_code.items()),"元準備コードの改変")
    for p in OWN.glob("*.py"):
        ast.parse(p.read_text(encoding="utf-8"), filename=str(p))
    result = subprocess.run([sys.executable, "-B", "-X", "utf8", str(OWN / "人工検査.py")], capture_output=True, text=True, encoding="utf-8", cwd=OWN)
    require(result.returncode == 0, result.stdout + result.stderr)
    require(before == {str(p): sha(p) for p in paths} and prior == {str(p): sha(p) for p in reused}, "人工前後のコード差")
    check_dir = OWN / "検査"
    check_dir.mkdir(exist_ok=True)
    (check_dir / "人工検査.txt").write_text(result.stdout + result.stderr, encoding="utf-8")
    check = {"成功": True, "exit_code": result.returncode, "主人工": 8, "範囲": "手製metadataのみ。正式固定/市場/金融/未使用読取0", "所有前": before, "所有後": before, "再用前": prior, "再用後": prior, "log": reference(check_dir / "人工検査.txt"), "前後不変": True, "正式技法固定": False, "正式金融固定": False, "実Go収集の実行": False, "市場/金融/未使用読取": False}
    path = check_dir / "Python確認.json"
    write_new(path, check)
    write_new(stop, {"成功": True, "version": 1, "trial": 110, "準備のみ": True, "所有コードSHA256": before, "再用コードSHA256": prior, "検査": reference(path), "以後変更": "変更時は別版へ派生、旧停止は維持", "派生元": origin, "正式技法/金融固定": False, "市場/金融/未使用読取": False})
    print(json.dumps({"成功": True, "停止": reference(stop), "所有数": len(before), "再用数": len(prior), "人工主": 8, "正式固定": False}, ensure_ascii=False))


if __name__ == "__main__":
    main()
