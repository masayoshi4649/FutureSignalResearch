"""金融適格集合、複合入口の全値echo、一回割当と全予定分母を結合する。"""

from collections import Counter, defaultdict
import re

import 旧純算術 as A
from 入口純式110 import verify_pure


need, equal, BASE, H = A.need, A.equal, A.BASE, A.OLD.GRID_SPACE


def known_quote(q):
    """機能: 保存BBOの正常性を判定する。

    引数: q(dict|None)は最後の原行。
    返り値: boolは実約定可能な正常気配。
    """
    return q is not None and q['quote_ok'] and q['ask'] > q['bid'] > 0


def quiet_at(book, at):
    """機能: 20分静観と米国20分静観を半開区間で判定する。

    引数: book(dict)、at(number)は口座と枠時刻。
    返り値: tuple[bool,bool|None]は全静観と米国静観。
    """
    s = book['session']
    us = s['us_open'] <= at < s['us_open'] + 1200 if s['kind'] == 'Night' and s['us_open'] > 0 else None
    return s['start'] <= at < s['start'] + 1200 or us is True, us


def deadline(book, opportunity):
    """機能: 元手法の予定終了制限を返す。

    引数: book/opportunity(dict)は口座と出生。
    返り値: numberはSource手法ごとのForce時計。
    """
    s = book['session']
    return min(s['force_close'], s['us_open'] - 900) if opportunity['source']['method'] == 'NK225_P164_06' else s['force_close']


def pure_assessment(batch, actor, opportunity):
    """
    機能: 110の純式を独立検算する。

    引数: batch/actor/opportunity(dict)。

    返り値: None。
    """
    return verify_pure(batch, actor, opportunity)


def _verify_l0(book, config, clock, composite, audit, checked, full_clock):
    """機能: Source/一回割当/金融適格集合/全候補判定/実要求/活動列を照合する。

    引数: book/config/clock/composite/audit/checked(dict)、full_clock(bool)は保存値と連続枠要件。
    返り値: dictは時計/入口の件数。全予定参加集計の入力を検証する。
    """
    orders, timeline = checked['orders'], checked['timeline']
    opportunities, grids = book['entry_opportunities'], book['grid_traces']
    births = {(e['method'], e['signal_id']): e for e in book['source_events'] if e['kind'] == 'new_signal'}
    equal(len(opportunities), len(births), '全出生と機会数')
    equal(clock['timing'], 'B5QD', '本名の5分時計')
    equal(clock['opportunities'], [{'ordinal': p['ordinal'], 'source': p['source'], **A.OLD.assignment_for(book, p)} for p in opportunities], '固定strict次5分/静観1回繰越の全出生')
    equal(audit['policy'], config['entry_policy'], '入口監査の本名')
    batches, pure = composite['entry_batches'], audit['nonempty_batches']
    is_e1 = config['entry_policy'] == 'entry_E2'
    equal(len(batches), len(grids) if is_e1 else 0, 'E1は空候補枠も一回callback')
    equal(audit['calls'], len(grids) if is_e1 else 0, '純判定呼出数')
    if not is_e1:
        equal(pure, [], 'E0は公開器をgateへ接続しない')
    by_grid = defaultdict(list)
    seen, accepted = set(), set()
    for index, p in enumerate(opportunities, 1):
        equal(p['ordinal'], index, '出生Ordinal')
        identity = BASE.source_identity(p['source'])
        need(identity in births and identity not in seen, '出生の永久一回性')
        seen.add(identity)
        event = births[identity]
        equal((p['source']['birth_time'], p['source']['birth_quote'], p['side']), (event['at'], event['quote'], event['side']), '出生方向/時計/原行不変')
        equal(p['assigned_at'], A.OLD.assigned_at(book, p), '恣意的な再割当なし')
        need(p['consumed'] and p['status'] in ('accepted', 'expired') and p['evaluated_at'] >= event['at'], '終端機会状態')
        at, q = p['evaluated_at'], p['quote']
        if q is not None:
            BASE.quote(q, '新入口の原行', normal=False)
            need(q['time'] <= at, '取得時の未来BBO禁止')
            equal(p['available'], H['available_at'](book, orders, timeline, at, q, p['side'], accepted), '逐次配賦の片側余力')
            equal(p['quote_age_seconds'], H['clock_delta'](at, q['time']), '気配age')
        src = H['source_at'](book, at, q)[identity]
        equal((p['source_state'], p['source_hold_id'], p['source_quantity'], p['source_reserved']), (src['state'], src['hold'], src['q'], src['reserved']), '当時のSource状態')
        eof = p['reason'] == 'EOFで未消費出生機会を失効'
        eligible = not (eof or at != p['assigned_at'] or at >= deadline(book, p) or quiet_at(book, at)[0] or src['state'] in ('pending', 'cancelled') or src['q'] == 0 or (src['reserved'] or 0) > 0)
        unknown = eligible and not known_quote(q)
        eligible = eligible and known_quote(q) and p['available'] > 0
        gate = p.get('gate')
        if is_e1 and gate is not None:
            need(eligible, '金融不適格候補を純入口へ渡さない')
            unknown = not gate['known']
            eligible = gate['known'] and gate['allowed']
        else:
            need(not is_e1 or not eligible, '金融適格なのにE1判定なし')
            need(is_e1 or gate is None, 'E0へ技法gate混入')
        equal(p['required_unknown'], unknown, '未知を待機/許可へ変換しない')
        equal(p['status'], 'accepted' if eligible else 'expired', '独立した入口の採否')
        equal(p['requested'], min(p['source']['birth_quantity'], src['q'], p['available']) if eligible else 0, '実要求は出生/Source残/配賦余力のmin')
        if eligible:
            o = orders[p['entry_order_id']]
            for k, expected in (('source', p['source']), ('side', p['side']), ('quantity', p['requested']), ('request_time', at), ('request_quote', q), ('source_hold_id', p['source_hold_id'])):
                equal(o[k], expected, '入口と実注文.' + k)
            accepted.add(o['id'])
        else:
            need(not p['entry_order_id'] and p['requested'] == 0, '失効から架空注文を作らない')
        if not eof:
            by_grid[at].append(p)
        next_grid = next((x['at'] for x in grids if x['at'] >= p['assigned_at']), None)
        need(eof == (next_grid is None), 'EOF失効と観測枠の分離')
        if not eof:
            equal(at, next_grid, '割当後の再試行なし')
    equal(accepted, {o['id'] for o in book['orders'] if o['kind'] == 'entry'}, '全実新規要求の出生結合')
    if full_clock:
        H['verify_grid_prefix'](book['session'], [x['at'] for x in grids])
    counts = Counter()
    pure_by_id = {x['snapshot_id']: x for x in pure}
    need(len(pure_by_id) == len(pure), '非空純Batchの識別一意')
    equal(set(pure_by_id), {b['input']['snapshot_id'] for b in batches if b['input']['candidates']}, '非空純Batchを過不足なく結合')
    for index, trace in enumerate(grids):
        at, q = trace['at'], trace['quote']
        need(at % 300 == 0 and (index == 0 or grids[index - 1]['at'] < at), '枠の順序')
        quiet, us = quiet_at(book, at)
        equal((trace['quiet'], trace['quiet_applied'], trace['us_quiet'], trace['quote_known']), (quiet, quiet, us, known_quote(q)), '20分静観とBBO既知')
        points = by_grid[at]
        equal(trace['ordinals'], [p['ordinal'] for p in points], '枠候補の順序')
        for k, expected in (('candidate_count', len(points)), ('accepted_count', sum(p['status'] == 'accepted' for p in points)), ('accepted_quantity', sum(p['requested'] for p in points)), ('expired_count', sum(p['status'] == 'expired' for p in points)), ('unknown_count', sum(p['required_unknown'] for p in points))):
            equal(trace[k], expected, '枠の集計.' + k)
        allowed_before = {p['entry_order_id'] for p in opportunities if p['status'] == 'accepted' and p['evaluated_at'] < at}
        if q is not None:
            point = {'quote': q, 'phase': 'after_source'}
            for side, label in ((1, 'buy'), (-1, 'sell')):
                owned = sum(x['quantity'] for pid in timeline.histories if (x := timeline.state_at(pid, point)) is not None and x['side'] == side)
                equal(trace['open_' + label], owned, '枠開始時の実保有')
                allowed_after = allowed_before | {p['entry_order_id'] for p in points if p['status'] == 'accepted'}
                equal(trace['pending_' + label], H['pending_quantity'](book, orders, timeline, at, q, side, allowed_after), '枠後の新規予約')
        action = '新規' if trace['accepted_count'] else '保有' if trace['open_buy'] + trace['open_sell'] else '判定不能' if trace['unknown_count'] else '待機'
        equal(trace['action'], action, '受理と保有と未知を区別')
        if is_e1:
            b = batches[index]
            inp, out = b['input'], b['output']
            equal(inp['at'], at, '一括判定の枠')
            need(re.fullmatch('[0-9a-f]{64}', inp['snapshot_id']), '入口snapshot指紋')
            equal(out['snapshot_id'], inp['snapshot_id'], '一括採否snapshot不変')
            expected = []
            for side, name in ((1, 'buy'), (-1, 'sell')):
                free = H['available_at'](book, orders, timeline, at, q, side, allowed_before) if q is not None else 10
                equal(inp['available_' + name], free, '全候補を配賦前の同一余力で判定')
            for p in points:
                if at != p['assigned_at'] or at >= deadline(book, p) or quiet or p['source_state'] in ('pending', 'cancelled') or p['source_quantity'] == 0 or (p['source_reserved'] or 0) > 0 or not known_quote(q):
                    continue
                free = inp['available_buy' if p['side'] > 0 else 'available_sell']
                if free:
                    expected.append({'ordinal': p['ordinal'], 'at': at, 'side': p['side'], 'source': p['source'], 'quote': q, 'available': free, 'quantity': min(p['source']['birth_quantity'], p['source_quantity'], free)})
            equal(inp['candidates'], expected, '同枠の金融適格集合だけを全件査定')
            equal(len(out['decisions']), len(expected), '全候補に一回採否')
            equal([x['candidate'] for x in out['decisions']], expected, '全候補の順序と全値echo')
            directions = {x['candidate']['side'] for x in out['decisions'] if x['decision']['allowed']}
            need(len(directions) <= 1, '同枠の両方向成立を競合待機')
            if expected:
                pure_batch = pure_by_id[inp['snapshot_id']]
                equal(len(pure_batch['decisions']), len(expected), '純一括判定の候補数')
                for value in out['decisions']:
                    pure_assessment(pure_batch, value, opportunities[value['candidate']['ordinal'] - 1])
                    counts['candidates'] += 1
                    counts['allowed'] += value['decision']['allowed']
                    counts['unknown'] += not value['decision']['known']
                counts['conflicts'] += pure_batch['conflict']
    for k in ('candidates', 'allowed', 'unknown', 'conflicts'):
        equal(audit[k], counts[k], '純入口の全体計数.' + k)
    metrics = {'births': len(opportunities), 'grid_calls': len(grids), 'quiet_grids': sum(t['quiet'] for t in grids), 'unknown_us_grids': sum(not t['us_clock_known'] for t in grids), 'accepted': sum(p['status'] == 'accepted' for p in opportunities), 'expired': sum(p['status'] == 'expired' for p in opportunities), 'required_unknown': sum(p['required_unknown'] for p in opportunities), 'eof_expired': sum(p['reason'] == 'EOFで未消費出生機会を失効' for p in opportunities)}
    metrics.update({field: sum(t['action'] == label for t in grids) for label, field in (('新規', 'new_grids'), ('保有', 'holding_grids'), ('待機', 'waiting_grids'), ('判定不能', 'unknown_grids'))})
    equal(book['grid_metrics'], metrics, 'Actor全枠計数')
    return {'出生': len(opportunities), '一括候補': counts['candidates'], '一括許可': counts['allowed'], '一括未知': counts['unknown'], '一括競合': counts['conflicts']}


def verify_entry(book, config, clock, composite, audit, checked, full_clock):
    """
    機能: L0とL1を本名で独立検算する。

    引数: 保存各dict,full_clock(bool)。

    返り値: dictは計数。
    """
    if config['entry_policy'] != 'entry_E2' or config['entry_lifetime'] != 'L1':
        need(not composite.get('entry_attempts') and not composite.get('lifetime_terminals') and not composite.get('first_source_closings'), 'L0へL1監査を混ぜない')
        return _verify_l0(book, config, clock, composite, audit, checked, full_clock)
    return verify_l1(book, config, clock, composite, audit, checked, full_clock)


def verify_l1(book, config, clock, composite, audit, checked, full_clock):
    """
    機能: 各枠の全未取得出生と永久lockをSource通知から再読する。

    引数: 保存各dict,full_clock(bool)。

    返り値: dict。
    """
    orders, timeline = checked['orders'], checked['timeline']
    opportunities, grids = book['entry_opportunities'], book['grid_traces']
    births = {(e['method'], e['signal_id']): e for e in book['source_events'] if e['kind'] == 'new_signal'}
    equal(len(opportunities), len(births), 'L1でも一出生一機会')
    equal(clock['timing'], 'B5QD', '本名5分時計')
    equal(clock['opportunities'], [{'ordinal': p['ordinal'], 'source': p['source'], **A.OLD.assignment_for(book, p)} for p in opportunities], '出生/strict次5分/静観割当を変更しない')
    equal(audit['policy'], config['entry_policy'], '純入口の本名')
    for i, p in enumerate(opportunities, 1):
        equal(p['ordinal'], i, 'L1の元Ordinal')
        identity = BASE.source_identity(p['source'])
        need(identity in births, 'Sourceに存在する出生だけ')
        e = births[identity]
        equal((p['source']['birth_time'], p['source']['birth_quote'], p['side']), (e['at'], e['quote'], e['side']), '出生の方向/原行不変')
        equal(p['assigned_at'], A.OLD.assigned_at(book, p), 'L1は最短枠を再割当しない')
        need(p['consumed'] and p['status'] in ('accepted', 'expired'), 'L1終端の永久消費')
    equal(len({BASE.source_identity(p['source']) for p in opportunities}), len(opportunities), 'L1の重複出生禁止')
    origin = ('ordinal', 'source', 'side', 'batch_index', 'signal_index', 'assigned_at')
    attempts, terminals = composite.get('entry_attempts', []), composite.get('lifetime_terminals', [])
    by_grid, latest, counts, consumed_at = defaultdict(list), {}, Counter(), {}
    previous = None
    for item in attempts:
        ordinal, at, p = item['ordinal'], item['at'], item['opportunity']
        need(type(ordinal) is int and 1 <= ordinal <= len(opportunities) and ordinal not in consumed_at, 'L1永久消費後は再査定しない')
        key = at, ordinal
        need(previous is None or previous < key, 'L1の枠/出生順')
        previous = key
        counts[ordinal] += 1
        equal(item['attempt'], counts[ordinal], '出生ごとの査定連番')
        equal({k: p[k] for k in origin}, {k: opportunities[ordinal-1][k] for k in origin}, 'L1の元出生全値不変')
        equal((p['ordinal'], p['evaluated_at'], item['terminal']), (ordinal, at, p['consumed']), 'L1の査定時計と消費')
        action = 'accepted' if p['status'] == 'accepted' else 'expired' if p['consumed'] else 'unknown' if p['required_unknown'] else 'wait'
        equal(item['action'], action, 'L1の未知/待機/受理/失効')
        if p['consumed']: consumed_at[ordinal] = at
        latest[ordinal] = p
        by_grid[at].append(p)
    term_by = {}
    for item in terminals:
        ordinal, at, p = item['ordinal'], item['at'], item['opportunity']
        need(1 <= ordinal <= len(opportunities) and ordinal not in consumed_at and ordinal not in term_by, 'L1終端の二重消費禁止')
        need(item['kind'] in ('force', 'eof') and p['consumed'] and p['status'] == 'expired' and p['evaluated_at'] == at, 'L1のgrid外失効')
        equal({k: p[k] for k in origin}, {k: opportunities[ordinal-1][k] for k in origin}, '終端でも元出生不変')
        need(ordinal not in latest or latest[ordinal]['evaluated_at'] <= at, '終端の時計')
        if item['kind'] == 'force':
            need(at >= deadline(book, p) and not p['required_unknown'] and p.get('gate') is None, 'Forceは元期限以後で技法再判定なし')
        else:
            equal(p['reason'], 'EOFで未消費出生機会を失効', 'EOFの明示')
        term_by[ordinal] = item
        latest[ordinal] = p
    equal(set(latest), set(range(1, len(opportunities)+1)), '全出生に査定又は終端')
    for p in opportunities: equal(p, latest[p['ordinal']], '最終Opportunityは最後の保存copy')
    holds = {(e['method'], e['hold_id']): (e['method'], e['signal_id']) for e in book['source_events'] if e['kind'] == 'new_fill'}
    by_source = {BASE.source_identity(p['source']): p for p in opportunities}
    first = {}
    for e in book['source_events']:
        if e['kind'] != 'close_notice': continue
        identity = holds[e['method'], e['hold_id']]
        p = by_source[identity]
        if identity in first or not H['event_before'](e, p['evaluated_at'], p['quote']): continue
        first[identity] = {'ordinal': p['ordinal'], 'source': p['source'], 'at': e['at'], 'quote': e['quote'], 'hold_id': e['hold_id'], 'notice_id': e['notice_id']}
    equal(composite.get('first_source_closings', []), [first[BASE.source_identity(p['source'])] for p in opportunities if BASE.source_identity(p['source']) in first], '解消後も最初のSource返済予約を永久記憶')
    def closing_at(p):
        """
        機能: 既観測予約を当時の原行で判定する。

        引数: p(dict)。

        返り値: bool。
        """
        e = first.get(BASE.source_identity(p['source']))
        return e is not None and H['event_before']({'at': e['at'], 'quote': e['quote']}, p['evaluated_at'], p['quote'])
    accepted, consumed = set(), set()
    def inspect(p, terminal=None):
        """
        機能: 一査定の当時Source/余力/実要求を検算する。

        引数: p(dict),terminal(dict|None)。

        返り値: None。
        """
        at, q = p['evaluated_at'], p['quote']
        need(terminal is not None or at >= p['assigned_at'], '最短枠前の取得禁止')
        if q is not None:
            BASE.quote(q, 'L1の最後の原行', normal=False)
            need(q['time'] <= at, '未来BBO禁止')
            equal(p['quote_age_seconds'], H['clock_delta'](at, q['time']), 'L1気配age')
            equal(p['available'], H['available_at'](book, orders, timeline, at, q, p['side'], accepted), '当時実保有と実新規予約の余力')
        src = H['source_at'](book, at, q)[BASE.source_identity(p['source'])]
        equal((p['source_state'], p['source_hold_id'], p['source_quantity'], p['source_reserved']), (src['state'], src['hold'], src['q'], src['reserved']), '当時のSource残量と予約')
        if terminal is not None:
            need(not p['entry_order_id'] and p['requested'] == 0, '終端から実注文を作らない')
            return
        expired = at >= deadline(book, p) or closing_at(p) or src['state'] == 'cancelled' or src['q'] == 0 or (src['reserved'] or 0) > 0
        ready = not expired and not quiet_at(book, at)[0] and src['state'] == 'filled'
        unknown = ready and not known_quote(q)
        eligible = ready and known_quote(q) and p['available'] > 0
        gate = p.get('gate')
        if gate is not None:
            need(eligible, '金融不適格をgateへ渡さない')
            unknown, eligible = not gate['known'], gate['known'] and gate['allowed']
        else: need(not eligible, '金融適格なのにE2判定欠落')
        status = 'accepted' if eligible else 'expired' if expired else 'waiting'
        equal((p['status'], p['consumed'], p['required_unknown']), (status, status != 'waiting', unknown), 'L1の独立採否')
        equal(p['requested'], min(p['source']['birth_quantity'], src['q'], p['available']) if eligible else 0, 'L1出生/Source残/余力のmin')
        if eligible:
            o = orders[p['entry_order_id']]
            need(o['id'] not in accepted, '一出生一実受理のlock')
            for k, value in (('source', p['source']), ('side', p['side']), ('quantity', p['requested']), ('request_time', at), ('request_quote', q), ('source_hold_id', p['source_hold_id'])):
                equal(o[k], value, 'L1実要求.'+k)
            accepted.add(o['id'])
        else: need(not p['entry_order_id'] and p['requested'] == 0, '待機/失効から架空注文を作らない')
    pure, batches = audit['nonempty_batches'], composite['entry_batches']
    equal((audit['calls'], len(batches)), (len(grids), len(grids)), 'L1空枠含む一回batch')
    pure_by = {x['snapshot_id']: x for x in pure}
    equal(len(pure_by), len(pure), '純Batchの一意性')
    equal(set(pure_by), {x['input']['snapshot_id'] for x in batches if x['input']['candidates']}, '全非空batchの結合')
    need(set(by_grid) <= {t['at'] for t in grids}, '架空の判断枠を作らない')
    done = set()
    def terminal_before(at, final=False):
        """
        機能: grid外失効をForce→grid順で照合する。

        引数: at(number),final(bool)。

        返り値: None。
        """
        for ordinal, t in sorted(term_by.items(), key=lambda x: (x[1]['at'], x[0])):
            if ordinal in done or t['at'] > at or not final and t['kind'] == 'eof' and t['at'] == at: continue
            need(ordinal not in consumed, '消費後の終端再消費禁止')
            inspect(t['opportunity'], t)
            consumed.add(ordinal); done.add(ordinal)
    stats = Counter()
    if full_clock: H['verify_grid_prefix'](book['session'], [t['at'] for t in grids])
    for index, trace in enumerate(grids):
        at, q = trace['at'], trace['quote']
        need(at % 300 == 0 and (index == 0 or grids[index-1]['at'] < at), 'L1枠の順序')
        terminal_before(at)
        quiet, us = quiet_at(book, at)
        equal((trace['quiet'], trace['quiet_applied'], trace['us_quiet'], trace['quote_known']), (quiet, quiet, us, known_quote(q)), '20分静観と気配既知')
        points = by_grid[at]
        expected_ordinals = [p['ordinal'] for p in opportunities if p['ordinal'] not in consumed and p['assigned_at'] <= at]
        equal([p['ordinal'] for p in points], expected_ordinals, '全未取得出生を毎枠過不足なく再査定')
        equal(trace['ordinals'], expected_ordinals, '全査定順')
        before = set(accepted)
        for p in points:
            equal(p['quote'], q, '同枠は同じ気配')
            inspect(p)
            if p['consumed']: consumed.add(p['ordinal'])
        for k, value in (('candidate_count', len(points)), ('accepted_count', sum(p['status'] == 'accepted' for p in points)), ('accepted_quantity', sum(p['requested'] for p in points)), ('expired_count', sum(p['status'] == 'expired' for p in points)), ('unknown_count', sum(p['required_unknown'] for p in points))):
            equal(trace[k], value, 'L1全枠計数.'+k)
        if q is not None:
            point = {'quote': q, 'phase': 'after_source'}
            for side, label in ((1, 'buy'), (-1, 'sell')):
                owned = sum(x['quantity'] for pid in timeline.histories if (x := timeline.state_at(pid, point)) is not None and x['side'] == side)
                equal(trace['open_'+label], owned, 'Source待機を実保有へ水増ししない')
                equal(trace['pending_'+label], H['pending_quantity'](book, orders, timeline, at, q, side, accepted), 'L1当時の実新規予約')
        equal(trace['action'], '新規' if trace['accepted_count'] else '保有' if trace['open_buy']+trace['open_sell'] else '判定不能' if trace['unknown_count'] else '待機', 'L1の実活動分類')
        inp, out = batches[index]['input'], batches[index]['output']
        equal(inp['at'], at, 'L1batch枠時計')
        need(re.fullmatch('[0-9a-f]{64}', inp['snapshot_id']), 'L1snapshot SHA')
        equal(out['snapshot_id'], inp['snapshot_id'], 'L1全候補同一snapshot')
        for side, name in ((1, 'buy'), (-1, 'sell')):
            equal(inp['available_'+name], H['available_at'](book, orders, timeline, at, q, side, before) if q is not None else 10, '全候補配賦前の余力')
        expected = []
        for p in points:
            if at >= deadline(book, p) or quiet or closing_at(p) or p['source_state'] != 'filled' or p['source_quantity'] == 0 or (p['source_reserved'] or 0) > 0 or not known_quote(q): continue
            free = inp['available_buy' if p['side'] > 0 else 'available_sell']
            if free: expected.append({'ordinal': p['ordinal'], 'at': at, 'side': p['side'], 'source': p['source'], 'quote': q, 'available': free, 'quantity': min(p['source']['birth_quantity'], p['source_quantity'], free)})
        equal(inp['candidates'], expected, 'L1金融適格集合のみ先に全件査定')
        equal([x['candidate'] for x in out['decisions']], expected, 'L1全値echo')
        need(len({x['candidate']['side'] for x in out['decisions'] if x['decision']['allowed']}) <= 1, '未解決両方向成立は拒否')
        if expected:
            batch = pure_by[inp['snapshot_id']]
            equal(len(batch['decisions']), len(expected), '全純候補数')
            equal(batch['conflict'], len({x['candidate']['side'] for x in batch['decisions'] if x['known'] and x['route']}) == 2, '成立方向だけで競合判定')
            for value in out['decisions']:
                pure_assessment(batch, value, next(p for p in points if p['ordinal'] == value['candidate']['ordinal']))
                stats['candidates'] += 1; stats['allowed'] += value['decision']['allowed']; stats['unknown'] += not value['decision']['known']
            stats['conflicts'] += batch['conflict']
    terminal_before(float('inf'), True)
    equal(consumed, set(range(1, len(opportunities)+1)), '全出生の永久消費と終端')
    equal(accepted, {o['id'] for o in book['orders'] if o['kind'] == 'entry'}, '全新規注文を一度受理へ結合')
    for k in ('candidates', 'allowed', 'unknown', 'conflicts'): equal(audit[k], stats[k], 'L1純計数.'+k)
    points = [p for values in by_grid.values() for p in values]
    metrics = {'births': len(opportunities), 'grid_calls': len(grids), 'quiet_grids': sum(t['quiet'] for t in grids), 'unknown_us_grids': sum(not t['us_clock_known'] for t in grids), 'accepted': sum(p['status'] == 'accepted' for p in opportunities), 'expired': sum(p['status'] == 'expired' for p in points)+len(terminals), 'required_unknown': sum(p['required_unknown'] for p in points), 'eof_expired': sum(t['kind'] == 'eof' for t in terminals)}
    metrics.update({field: sum(t['action'] == label for t in grids) for label, field in (('新規', 'new_grids'), ('保有', 'holding_grids'), ('待機', 'waiting_grids'), ('判定不能', 'unknown_grids'))})
    equal(book['grid_metrics'], metrics, 'L1未知は出生数でなく査定回数')
    return {'出生': len(opportunities), '一括候補': stats['candidates'], '一括許可': stats['allowed'], '一括未知': stats['unknown'], '一括競合': stats['conflicts'], 'L1査定': len(attempts), 'L1終端': len(terminals)}
