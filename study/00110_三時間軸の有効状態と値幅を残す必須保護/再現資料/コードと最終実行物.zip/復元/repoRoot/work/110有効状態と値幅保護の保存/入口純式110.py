"""純E2の保存数値・4clock・現在支持・並列ANDをGo呼出なしで独立検算する。"""

import math
import re

import 旧純算術 as A

need, equal = A.need, A.equal
CLOCKS = ('nominal_available', 'available_at', 'observed_at', 'delivery_at')
CHECKS = ('common', 'continuation_direction', 'resume_direction', 'risk_band', 'trend_valid', 'reversal_valid',
          'trend_distance', 'reversal_distance', 'continuation_upper', 'continuation', 'pullback', 'reversal',
          'trend', 'momentum', 'trend_momentum', 'reversal_momentum', 'spike', 'maintenance', 'recovery', 'upper_not_opposite')


def ieee(actual, expected, label):
    """
    機能: 非会計の指標導出値をIEEE許容差で照合する。

    引数: actual/expected(number),label(str)。

    返り値: None。
    """
    need(math.isfinite(float(actual)) and math.isclose(float(actual), float(expected), rel_tol=1e-12, abs_tol=1e-12), label)


def frame(f, at, width, scene, required=False, contract=None):
    """
    機能: 使用公表の場・幅・4clock・子出典を検算する。

    引数: f(dict),at(number),width(int),scene(str),required(bool),contract(str|None)。

    返り値: None。
    """
    if not f['id']:
        need(not required, '必要な公表evidenceが欠落')
        return
    equal((f['session_id'], f['width_seconds'], f['end']-f['start']), (scene, width, width), '使用公表の場/尺度')
    need(f['contract'] and re.fullmatch('[0-9a-f]{64}', f['children_sha256']), '公表の限月/子出典SHA')
    if contract is not None: equal(f['contract'], contract, '使用公表の限月同体')
    need(all(f['end'] <= f[k] <= at for k in CLOCKS), '使用公表の4clockは当時まで')
    need(f['nominal_available'] <= f['available_at'] and f['nominal_available'] <= f['observed_at'] <= f['delivery_at'], '公表4clockの因果順')
    need(type(f['price_known']) is bool and type(f['volume_known']) is bool, '公表既知性はbool')
    if required: need(f['price_known'] and at-f['available_at'] < width, '現在公表の価格と鮮度')
    if f['price_known']:
        o = f['ohlc']
        need(0 < o['low'] <= o['high'] and all(o['low'] <= o[k] <= o['high'] for k in ('open', 'close')), '使用OHLCの帯')
    for name, value in f['technical'].items():
        if name == 'history_bars': continue
        need(type(value['known']) is bool, '指標既知性はbool')
        if value['known']: A.BASE.number(value['value'], '指標の有限値')


def setup(s, side, at, scene, role, five, contract):
    """
    機能: 固定支持・確認・期限と現在の局所否定を照合する。

    引数: s(dict),side(int),at(number),scene/role/contract(str),five(dict)。

    返り値: None。
    """
    need(s['id'] and s['anchor_id'] and s['pivot_id'] and s['active'] is True and s['phase'] == '確認済み', '成立は現在も有効な確認済み支持')
    need(s['created_at'] <= s['confirmed_at'] <= at < s['expires_at'] and s['expires_at']-s['created_at'] == 1800, '確認で延長しない固定期限')
    need(s['confirmed_frame_id'] and s['breakout_end'] <= s['confirmed_at'], '確認足の時計/ID')
    anchor, pivot = s['anchor'], s['pivot']
    frame(anchor, at, 900, scene, contract=contract)
    equal(anchor['id'], s['anchor_id'], 'risk足の固定ID')
    equal(s['boundary'], anchor['ohlc']['low' if side > 0 else 'high'], '固定risk端')
    need(pivot['known'] and pivot['kind'] == ('high' if side > 0 else 'low'), '方向対応の既知5分pivot')
    equal((pivot['price'], pivot['center_id']), (s['trigger'], s['pivot_id']), '固定線とpivot')
    refs = [*pivot['left'], {'id': pivot['center_id'], 'start': pivot['center_start'], 'end': pivot['center_end'], 'published_at': pivot['published_at']}, *pivot['right']]
    need(len(refs) == 5 and all(x['id'] and x['end']-x['start'] == 300 and x['end'] <= pivot['published_at'] and x['published_at'] <= pivot['published_at'] for x in refs), 'pivot左右2本の証拠')
    need(all(refs[i-1]['end'] == refs[i]['start'] for i in range(1, 5)), 'pivotの連続5本')
    equal((refs[-1]['id'], refs[-1]['end']), (pivot['confirm_id'], pivot['confirm_end']), '右2本目の確認')
    need(side*(s['trigger']-s['boundary']) > 0, '固定突破線はrisk端外側')
    initial_known_start = s['breakout_end']-300 if role == 'T' else s['failure_end']-300
    need(max(anchor[k] for k in CLOCKS) < initial_known_start and pivot['published_at'] < initial_known_start, '少なくとも確認試験開始前の固定根拠')
    extreme = five['ohlc']['low' if side > 0 else 'high']
    need(side*(five['ohlc']['close']-s['trigger']) > 0, '現在終値が支持線外')
    if role == 'T':
        equal(s['created_at'], max(max(anchor[k] for k in CLOCKS), pivot['published_at']), 'T期限開始は固定根拠の最遅公表')
        need(side*(extreme-s['boundary']) >= 0, '現在risk側の支持維持')
        t = anchor['technical']['ema8']
        pullback = side*(anchor['ohlc']['close']-anchor['ohlc']['open']) <= 0 or t['known'] and side*(anchor['ohlc']['low' if side > 0 else 'high']-t['value']) <= 0
        equal(s['anchor_pullback'], pullback, '固定時の押戻しflag')
    else:
        need(s['failure_end'] < s['recovery_end'] < s['breakout_end'] and s['failure_end'] <= s['created_at'], 'Rは別足の試行→復帰→突破')
        need(side*(extreme-s['failure_extreme']) >= 0 and side*(five['ohlc']['close']-s['boundary']) > 0, '現在のR失敗極値と復帰境界を維持')


def verify_pure(batch, actor, opportunity):
    """
    機能: 純E2の全値echo/現在支持/独立AND/経路優先を検算する。

    引数: batch/actor/opportunity(dict)。

    返り値: None。
    """
    c, d = actor['candidate'], actor['decision']
    identity = f"{c['ordinal']}|{c['source']['method']}|{c['source']['signal_id']}"
    values = [x for x in batch['decisions'] if x['candidate']['id'] == identity]
    equal(len(values), 1, '純候補とSourceの一意結合')
    p = values[0]
    equal((batch['policy'],p['snapshot_id']), ('ENTRY_E2',batch['snapshot_id']), '純Batch政策と判断snapshotを結合')
    equal(batch['conflict'],len({x['candidate']['side'] for x in batch['decisions'] if x['known'] and x['route']})==2,'成立方向集合だけで競合を判定')
    equal(p['candidate'], {'id': identity, 'side': c['side'], 'at': c['at'], 'entry_quote': c['quote']['ask' if c['side'] > 0 else 'bid'], 'quantity': c['quantity']}, '純候補へ方向/数量/生BBOを無改変')
    for name in ('snapshot_id', 'policy', 'known', 'allowed', 'reason'): equal(d[name], p[name], '純判定のecho.'+name)
    equal(d['role'], p['role'] or p['status'], '純役割/状態のecho')
    if opportunity.get('gate') is not None: equal(opportunity['gate'], d, '当枠の実出生gate')
    else: need(opportunity['available'] == 0 and opportunity['status'] in ('waiting', 'expired'), '後配賦で余力0の時だけgate省略')
    need(p['policy'] == 'ENTRY_E2' and p['status'] in ('未知', '待機', '許可', '競合'), '110純入口の政策/状態')
    need(type(p['known']) is bool and type(p['allowed']) is bool and (not p['allowed'] or p['known']), '未知を成立にしない')
    for name in CHECKS:
        group = p[name]
        need(type(group['known']) is bool and type(group['passed']) is bool and (not group['passed'] or group['known']), '群の既知性.'+name)
    equal(p['known'], p['common']['known'], '共通必要値未知は最終Knownへ')
    equal([x['width_seconds'] for x in p['background']], [300, 900, 1800], '背景3尺度')
    equal([x['width_seconds'] for x in p['volume']], [300, 900, 1800], '量3尺度')
    need(all(type(x['known']) is bool and (not x['known'] or x['value'] >= 0) for x in p['volume']), '量は未知/完全の診断値')
    for f, width in zip(p['evidence'], (300, 900, 1800)): frame(f, c['at'], width, batch['state']['session_id'], p['known'], batch['state']['contract'])
    previous = p['previous_five']
    frame(previous, c['at'], 300, batch['state']['session_id'], contract=batch['state']['contract'])
    background_values = ('ema8','ema21','previous_ema8','previous_ema21','atr')
    momentum_values = ('rsi','previous_rsi','histogram','previous_histogram')
    complete = all(f['id'] and f['price_known'] and c['at']-f['available_at'] < width
                   and all(f['technical'][k]['known'] for k in background_values) and f['technical']['atr']['value'] > 0
                   for f,width in zip(p['evidence'],(300,900,1800)))
    complete = complete and previous['id'] and previous['price_known'] and batch['state']['has_previous_five']
    if complete:
        complete = previous['end'] == p['evidence'][0]['start'] and all(
            all(f['technical'][k]['known'] for k in (*momentum_values,'tr','previous_atr')) and f['technical']['previous_atr']['value'] > 0
            for f in (p['evidence'][0],previous)) and all(p['evidence'][1]['technical'][k]['known'] for k in momentum_values)
    if complete: need(p['known'], '完全な可用evidenceを未知へ改変しない')
    if p['known']: need(complete, 'Known成立には保存evidenceから確認できる全共通必要値が必要')
    if not p['known']:
        need(not p['allowed'] and p['status'] == '未知' and not p['route'] and not p['role'], '必要値未知を待機/許可へ補完しない')
        return
    need(p['common']['passed'] and previous['id'] and batch['state']['has_previous_five'], '連続した当場前5分')
    five, fifteen, thirty = p['evidence']
    equal((batch['state']['as_of'],batch['state']['last_five_id']),(c['at'],five['id']),'当時の純状態と使用5分公表')
    equal(previous['end'], five['start'], '現在/前5分の連続')
    def v(f, name):
        """
        機能: 既知数値だけを取る。

        引数: f(dict),name(str)。

        返り値: float。
        """
        t = f['technical'][name]
        need(t['known'], '必要な指標の既知値')
        return float(t['value'])
    side, at = c['side'], c['at']
    for f, b in zip(p['evidence'], p['background']):
        gap, fast, slow = v(f, 'ema8')-v(f, 'ema21'), v(f, 'ema8')-v(f, 'previous_ema8'), v(f, 'ema21')-v(f, 'previous_ema21')
        direction = 1 if min(gap, fast, slow) > 0 else -1 if max(gap, fast, slow) < 0 else 0
        equal((b['known'], b['direction'], b['normalized_known']), (True, direction, True), 'EMA並び/両傾きstrict AND')
        atr = v(f, 'atr')
        need(atr > 0, '正ATR')
        for name, value in (('gap', gap), ('fast_delta', fast), ('slow_delta', slow), ('gap_atr', gap/atr), ('fast_delta_atr', fast/atr), ('slow_delta_atr', slow/atr)): ieee(b[name], value, '背景導出.'+name)
    maintenance = side*(v(five, 'rsi')-50) > 0 and side*(v(previous, 'rsi')-50) > 0 and side*v(five, 'histogram') >= 0
    recovery = side*(v(five, 'rsi')-50) >= -10 and side*(v(five, 'rsi')-v(five, 'previous_rsi')) > 0 and side*(v(five, 'histogram')-v(five, 'previous_histogram')) > 0
    upper = not (side*(v(fifteen, 'rsi')-50) < 0 and side*v(fifteen, 'histogram') < 0 and side*(v(fifteen, 'histogram')-v(fifteen, 'previous_histogram')) < 0 and side*(v(fifteen, 'rsi')-v(fifteen, 'previous_rsi')) < 0)
    cont_upper = side*(v(fifteen, 'rsi')-50) >= 0 and (side*v(fifteen, 'histogram') >= 0 or side*(v(fifteen, 'histogram')-v(fifteen, 'previous_histogram')) >= 0)
    spike = not any(v(f, 'tr') > 2*v(f, 'previous_atr') and side*(v(f, 'rsi')-v(f, 'previous_rsi')) > 20 for f in (five, previous))
    i = 0 if side > 0 else 1
    ts, rs = batch['state']['trend'][i], batch['state']['reversal'][i]
    atr, quote = v(five, 'atr'), float(p['candidate']['entry_quote'])
    def position(value, support):
        """
        機能: 各固定支持の位置監査を検算する。

        引数: value(dict)は位置記録、support(dict)はT又はRの固定支持。
        返り値: None。
        """
        equal(value['known'], bool(support['id']), '線の有無と位置既知性')
        if not support['id']:
            need(all(value[k] == 0 for k in ('atr','line_distance','line_distance_atr','ema_distance','ema_distance_atr')), '線未形成の位置ゼロ')
            return
        for name,number in (('atr',atr),('line_distance',side*(quote-float(support['trigger']))),('line_distance_atr',side*(quote-float(support['trigger']))/atr),('ema_distance',side*(quote-v(five,'ema8'))),('ema_distance_atr',side*(quote-v(five,'ema8'))/atr)):
            ieee(value[name],number,'各支持の位置.'+name)
    position(p['trend_position'],ts)
    position(p['reversal_position'],rs)
    def valid(s):
        """
        機能: 確認済みの現在支持を識別する。

        引数: s(dict)。

        返り値: bool。
        """
        result = s['active'] and s['phase'] == '確認済み'
        if result: need(at < s['expires_at'], '現在支持は期限前')
        return result
    def distance(s):
        """
        機能: 取得線外/最大1ATRを検算する。

        引数: s(dict)。

        返り値: bool。
        """
        delta = side*(quote-float(s['trigger']))
        return 0 < delta <= atr and side*(quote-float(s['boundary'])) > 0
    expected = {'maintenance': maintenance, 'recovery': recovery, 'upper_not_opposite': upper, 'spike': spike,
                'continuation_upper': cont_upper, 'continuation_direction': all(x['direction'] == side for x in p['background']),
                'resume_direction': p['background'][2]['direction'] == side and side*float(p['background'][0]['fast_delta']) > 0,
                'risk_band': ts['anchor_pullback'] and side*(float(fifteen['ohlc']['close'])-float(ts['boundary'])) > 0,
                'trend_valid': valid(ts), 'reversal_valid': valid(rs), 'trend_distance': distance(ts), 'reversal_distance': distance(rs),
                'trend_momentum': maintenance and cont_upper, 'reversal_momentum': (maintenance or recovery) and upper}
    expected['continuation'] = expected['continuation_direction'] and expected['trend_valid'] and expected['trend_momentum'] and spike and expected['trend_distance']
    expected['pullback'] = expected['resume_direction'] and expected['risk_band'] and expected['trend_valid'] and (maintenance or recovery) and upper and spike and expected['trend_distance']
    expected['reversal'] = expected['reversal_valid'] and expected['reversal_momentum'] and spike and expected['reversal_distance']
    expected['trend'] = expected['continuation'] or expected['pullback']
    for name, value in expected.items(): equal((p[name]['known'], p[name]['passed']), (True, value), '独立した複合群.'+name)
    route = next((label for name, label in (('continuation', 'T継続'), ('pullback', 'T押戻し再開'), ('reversal', 'R局所転換')) if expected[name]), '')
    equal((p['route'], p['role']), (route, 'R' if route == 'R局所転換' else 'T' if route else ''), '経路優先C→P→Rと役割')
    status = '競合' if route and batch['conflict'] else '許可' if route else '待機'
    equal((p['status'], p['allowed']), (status, status == '許可'), '競合込みの最終採否')
    if route:
        selected = rs if p['role'] == 'R' else ts
        equal(p['structure'], selected, '代表の現在支持を値copy')
        setup(selected, side, at, batch['state']['session_id'], p['role'], five, batch['state']['contract'])
        equal(p['momentum'], p['trend_momentum'] if route == 'T継続' else p['reversal_momentum'], '代表経路の勢い群')
        pos = p['position']
        need(pos['known'], '成立の取得位置監査')
        for name, value in (('atr', atr), ('line_distance', side*(quote-float(selected['trigger']))), ('line_distance_atr', side*(quote-float(selected['trigger']))/atr), ('ema_distance', side*(quote-v(five, 'ema8'))), ('ema_distance_atr', side*(quote-v(five, 'ema8'))/atr)): ieee(pos[name], value, '取得位置.'+name)
    else:
        position(p['position'],ts if ts['id'] else rs)
