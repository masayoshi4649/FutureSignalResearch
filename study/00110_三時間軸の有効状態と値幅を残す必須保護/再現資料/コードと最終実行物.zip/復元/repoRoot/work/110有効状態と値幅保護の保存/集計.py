"""109のMain36を本名で保存検算する。市場実行・指標再形成を行わない。"""

import argparse
from decimal import Decimal
import gzip
import hashlib
import json
from pathlib import Path

import 旧純算術 as A
import 新保護監査 as P
import 入口と活動の監査 as E


need, equal, BASE, OLD = A.need, A.equal, A.BASE, A.OLD
ROOT = Path(__file__).resolve().parents[2]
CONFIGS = A.configurations()
KEYS = tuple(A.key_for(c) for c in CONFIGS)
BY_KEY = dict(zip(KEYS, CONFIGS))


def digest(path):
    """機能: 入出力の全bytes指紋を計算する。

    引数: path(Path)は対象ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_text(path):
    """機能: JSON又はgzip JSONをUTF-8で読む。

    引数: path(Path)は認証済み入力。
    返り値: strは元数値字句を保つ本文。
    """
    opener = gzip.open if path.suffix == '.gz' else open
    with opener(path, 'rt', encoding='utf-8-sig') as stream:
        return stream.read()


def load(path):
    """機能: 金額をDecimalで読む。

    引数: path(Path)は認証済みJSON。
    返り値: dictは保存値。再計算前に丸めない。
    """
    return json.loads(read_text(path), parse_float=Decimal)


def raw_tables(text, names):
    """機能: 全JSONの元字句からGo互換SHAを取得する。

    引数: text(str)、names(dict[str,str])は本文と出力名→fieldの対応。
    返り値: dict[str,dict]は未知fieldも含む全値指紋。
    """
    top = OLD.raw_members(text)
    return {name: {k: OLD.raw_go_sha(v) for k, v in OLD.raw_members(top[field]).items()} for name, field in names.items()}


def verify_baseline(value, raw, artificial, before):
    """機能: E0/G0の四感度を旧108全JSONへ独立に照合する。

    引数: value(dict)、raw(str)、artificial(bool)、before(dict)はCore・元本文・人工区分・指紋台帳。
    返り値: dictはBook/Width/Clock各4照合。新20条件の同体は主張しない。
    """
    proof, baseline = value['prior_reference'], value['baseline']
    need(baseline['all'] and baseline['comparisons'] == 4, '四対照の完結')
    current = raw_tables(raw, {'books': 'books', 'width': 'width_audits', 'clock': 'clock_audits'})
    if proof['kind'] == 'provided_old108_q20':
        path = Path(proof['reference_path']).resolve()
        if artificial:
            need(path.parent == ROOT / 'work/110有効状態と値幅保護の接続/人工_停止版', '人工対照は停止人工フォルダだけ')
        equal(digest(path), proof['reference_sha256'], '旧108参照実物SHA')
        before[str(path)] = digest(path)
        prior_raw = read_text(path)
        top = OLD.raw_members(prior_raw)
        fields = {'books': 'Books', 'width': 'Widths', 'clock': 'Clocks', 'early': 'Early'} if 'Books' in top else {'books': 'books', 'width': 'width_audits', 'clock': 'clock_audits', 'early': 'early_audits'}
        prior = raw_tables(prior_raw, fields)
        for name, field in (('books', 'book_full_json_sha256'), ('width', 'width_full_json_sha256'), ('clock', 'clock_full_json_sha256'), ('early', 'early_full_json_sha256')):
            equal(proof[field], prior[name], '旧全JSON出典.' + field)
        equal((proof['books'], proof['width_audits'], proof['clock_audits'], proof['early_audits']), (12, 12, 12, 4), '旧保存参照の全件数')
        key_for_prior = lambda c: f"Q0_C{c['slip_pts']}_D{c['delay_seconds']}"
    else:
        need(artificial and proof['kind'] == 'fresh_unseen', '新規場shadowは別途許可した人工だけ')
        prior = raw_tables(raw, {'books': 'shadow_books', 'width': 'shadow_width_audits', 'clock': 'shadow_clock_audits'})
        key_for_prior = lambda c: f"Q0_C{c['slip_pts']}_D{c['delay_seconds']}"
    result = {}
    for config in CONFIGS[:4]:
        k, oldkey = A.key_for(config), key_for_prior(config)
        for label, flag in (('books', 'books_equal'), ('width', 'width_audits_equal'), ('clock', 'clock_audits_equal')):
            equal(current[label][k], prior[label][oldkey], '全JSON同体.' + label + '/' + k)
            need(baseline[flag][k] is True, 'Core対照flag')
        result[k] = {'旧key': oldkey, 'Book/Width/Clock全JSON': True}
    return result


def verify_public(value):
    """機能: 新入口公表と旧3分保護の形成範囲・最終時計を分けて確認する。

    引数: value(dict)はCore110結果。
    返り値: None。全5/15/30数値の独立再形成とは呼ばない。
    """
    need(value['tape_unchanged'] and value['complete'] and value['source_reexecuted'] is False and value['charts_recomputed'] is False and value['bank_recomputed'] is False and value['cmp_recomputed'] and value['entry_candle_recomputed'], 'Coreの責務範囲')
    pub, protection = value['publication_audit'], value['protection_audit']
    need(pub['inputs_unchanged'] and pub['policy_eof_redacted'] and pub['clock_model'] == 'csv_end_plus60_at_record_scheduler', '入口公表時計とEOF射影')
    s = pub['last_snapshot']
    equal(s['session']['id'], value['session']['id'], '最終公開場')
    for scale in s['scales']:
        if scale['has_current']:
            f = scale['current']
            need(all(f[k] <= s['as_of'] for k in ('nominal_available', 'available_at', 'observed_at', 'delivery_at')), '最終snapshotに未来公表なし')
            need(f['end'] <= f['nominal_available'] <= f['available_at'] <= f['observed_at'] <= f['delivery_at'], '4公表時計の順序')
    equal(protection['publications'], protection['V_known'] + protection['V_unknown'], 'Vは完全又は未知')


def inspect_scene(value, raw, artificial=False, full_clock=True, before=None):
    """機能: Main36の全会計と新保護/入口を別規範で検査する。

    引数: value(dict)、raw(str)、artificial/full_clock(bool)、before(dict|None)は入力と検査範囲。
    返り値: dictは検算済み台帳と四対照。
    """
    before = {} if before is None else before
    need(value['version'] == 1 and value['trial'] == 110 and value['complete'], '109完結')
    equal(value['configs'], CONFIGS, 'Main36の固定設定と順序')
    for field in ('books', 'clock_audits', 'composite_audits', 'entry_audits'):
        equal(set(value[field]), set(KEYS), '24集合.' + field)
    equal(set(value['width_audits']), {k for k in KEYS if BY_KEY[k]['protection_policy'] == 'G0'}, 'G0だけ旧幅監査8')
    verify_public(value)
    checked = {}
    birth_reference = None
    for key, config in BY_KEY.items():
        book = value['books'][key]
        equal(book['session'], value['session'], '36冊の場')
        equal([x['at'] for x in book['grid_traces']], value['grid_times'], '36冊の同じ判断時計')
        now = [(p['source'], p['side'], p['batch_index'], p['signal_index']) for p in book['entry_opportunities']]
        if birth_reference is None:
            birth_reference = now
        equal(now, birth_reference, '全36で元出生/方向/量/順序は同体')
        result = A.verify_finance(book, config)
        result['protection_counts'] = P.verify_protection(book, config, value['composite_audits'][key], result)
        result['entry_counts'] = E.verify_entry(book, config, value['clock_audits'][key], value['composite_audits'][key], value['entry_audits'][key], result, full_clock)
        if config['protection_policy'] == 'G0':
            for position in book['positions']:
                OLD.SAVED.verify_activation(position, result['timeline'], 'P0', 'LD10')
            OLD.SAVED.verify_width(book, result, 'W0', value['width_audits'][key], None, value['contract'])
        checked[key] = result
    equal(value['counts']['grids'], len(value['grid_times']), 'Core枠数')
    return {'checked': checked, 'baseline': verify_baseline(value, raw, artificial, before)}


def scene_rows(value, checked):
    """機能: CSV互換の本名場別統計を政策非依存算術で作る。

    引数: value/checked(dict)はCoreと検算済み台帳。
    返り値: list[dict]は24場別行。主分母はStart+1200からForce未満。
    """
    rows = []
    for key in KEYS:
        c = checked[key]
        row = OLD.summarize_book(value['books'][key], c)
        rows.append({'session': value['session']['id'], 'key': key, 'history_class': value['prior_reference']['history_class'], **row, '新保護保存検査': c['protection_counts'], '複合入口検査': c['entry_counts']})
    return rows


def aggregate(rows, stage):
    """機能: 24条件の実現収支と保存DDを時系列連結する。

    引数: rows(list[dict])、stage(str)は場別とfirst2/full70/artificial。
    返り値: dictは24集計。機会損失を評価しない。
    """
    result = {}
    for key in KEYS:
        selected = sorted((r for r in rows if r['key'] == key), key=lambda r: r['session'])
        result[key] = OLD.OLD.combine(selected)
        if stage != 'artificial':
            count = 2 if stage == 'first2' else 70
            equal(len(selected), count, '同条件の全場数')
            for label, n in (('活動主表', 228 if count == 2 else 7980), ('活動副表', 220 if count == 2 else 7700)):
                equal(result[key][label]['denom'], n, '全予定分母の固定.' + label)
    return result


def declared_configs():
    """機能: CSVと金融CLIが共有する明示36設定を生成する。

    引数: なし。
    返り値: dict[str,dict]はcandidateを含むActor設定。
    """
    return {k: {'candidate': A.candidate_for(c), 'entry_timing': 'B5QD', **c} for k, c in BY_KEY.items()}


def save_viewer(value, output, market_path):
    """機能: 実fillだけをViewer schema1の24資源へ保存する。

    引数: value(dict)、output(Path)、market_path(str)はCore・新規先・原板参照。
    返り値: list[dict]は24資源。HTTP・原板読取・xlsx生成は行わない。
    """
    resources, sid = [], value['session']['id']
    for key in KEYS:
        name = f'110_{key}_{sid}.trades.jsonl'
        with (output / name).open('x', encoding='utf-8', newline='\n') as stream:
            for row in BASE.viewer_trades(value['books'][key]):
                stream.write(json.dumps(row, ensure_ascii=False, default=BASE.serial, allow_nan=False) + '\n')
        resources.append({'id': f'110_{key}_{sid}', 'title': f'三時間軸の有効状態と値幅保護 {key} {sid}', 'symbol': 'NK225', 'product': 'NK225mini', 'session': sid, 'method_id': key, 'point_value': 100, 'pnl_format': 'trades', 'pnl_basis': 'net', 'pnl_path': name, 'market_path': market_path})
    return resources


def verify_envelope(value, task, completion):
    """機能: Nativeを成功金融・CSV・旧108・106保存由来と結合する。

    引数: value/task/completion(dict)は認証済みNative・場参照・完了。
    返り値: None。Source/Raw/Bankを再形成しない。
    """
    equal(value['condition_sha256'], completion['condition_sha256'], 'Nativeの金融条件')
    equal((value['session']['id'], value['contract']), (task['session'], task['input']['contract']), '場と限月')
    equal(value['csv_input'], task['csv'], '価格CSVの固定出典')
    equal(value['publication_audit']['end_seed'], task['actual_end_seed'], 'CSV公開の種終端')
    equal(value['expected_end_seed'], task['expected_end_seed'], '事前種との対応')
    need(value['end_seed_equal'] is True, '連鎖種の同体')
    proof = value['prior_reference']
    equal((Path(proof['reference_path']).resolve(), proof['reference_sha256']), (task['resolved']['prior_native'], task['prior_native']['sha256']), '旧108正式参照')
    equal(proof['tape_canonical_sha256'], value['tape_canonical_sha256'], '旧108と同じSourceTape')
    reader, replay = value['input_proof'], value['replay_proof']
    equal(reader['scene_id'], task['session'], '106入力の場')
    equal(reader['tape_canonical_sha256'], value['tape_canonical_sha256'], '106と109の固定Tape')
    need(reader['source_reexecuted'] is False and reader['bank_recomputed'] is False and reader['financial_executed'] is False, 'Readerの責務')
    need(replay['unchanged'] and replay['before'] and replay['before'] == replay['after'], '保存Record再読の前後不変')
    header = load(task['resolved']['sidecar_header'])
    need(header['version'] == 1 and header['trial'] == 106, '元106公表Header')
    equal(header['records_gzip_sha256'], task['sidecar_records']['sha256'], '元公表records指紋')
    provenance = {'source_scope': 'recorded_public_106', 'clock_model': 'csv_end_plus60_at_record_scheduler', 'cmp_recomputed': True, 'charts_recomputed': False, 'raw_market_read': False, 'source_reexecuted': False, 'bank_recomputed': False, 'entry_candle_recomputed': True, 'financial_executed': True, 'source_features_recomputed': False, 'new_series_bank_formed': True, 'protection_v5_formed': True, 'csv_copied': False, 'csv_regenerated': False, 'raw_copied': False}
    equal(value['provenance'], provenance, '新形成と旧非形成の範囲')


def generate(fixed_path, fixed_sha, output):
    """機能: Root固定と成功金融の後だけ36会計を検算して保存する。

    引数: fixed_path/output(Path)、fixed_sha(str)は事後固定・未使用先・期待SHA。
    返り値: dictは保存件数。金融再走/CSV再形成を行わない。
    """
    import 固定ゲート as gate
    tasks, before, proofs, completion = gate.prepare(fixed_path, fixed_sha, output)
    output.mkdir(parents=True)
    rows, resources, controls, refs = [], [], [], []
    for task in tasks:
        raw = read_text(task['resolved']['native'])
        value = json.loads(raw, parse_float=Decimal)
        verify_envelope(value, task, completion)
        inspected = inspect_scene(value, raw, before=before)
        rows.extend(scene_rows(value, inspected['checked']))
        resources.extend(save_viewer(value, output, task['market_path']))
        controls.append({'session': task['session'], '四対照': inspected['baseline']})
        refs.append({k: task[k] for k in ('session', 'native', 'sidecar_header', 'sidecar_records', 'prior_native', 'csv')})
    summary = aggregate(rows, completion['stage'])
    after = {name: digest(Path(name)) for name in before}
    equal(after, before, '入力とcodeの前後不変')
    scope = 'Main36の全fill/所有/fee/追加滑り/保存MTM-DD/全予定活動と保存保護点・入口候補の根拠結合。E0/G0四感度は旧108Q0のBook/Width/Clock全JSON同体。全指標又は全tickの別engine再走ではない'
    result = {'試行': 110, '成功': True, **proofs, 'stage': completion['stage'], 'scope': scope, '場数': len(tasks), '会計数': len(rows), '主key': list(KEYS), 'Actor設定': declared_configs(), '集計': summary, '場別': rows, '旧108同体対照': controls, 'Native参照': refs, 'Viewer形式資源': len(resources), '実Viewer通信': 0, '入力codeSHA256前': before, '入力codeSHA256後': after, '前後不変': True, '未実施': ['Raw/Source/旧Bank再形成', '全5/15/30指標の独立再形成', '全quoteの別engine金融再走', '未参加/退出後の仮想利益と機会損失', '実ViewerAPI', 'CSV出力と独立再読（別処理）'], '研究目標達成': False, '採用': False}
    BASE.write_json(output / '結果.json', result)
    BASE.write_json(output / '一覧.resources.json', {'schema_version': 1, 'path_base': 'catalog', 'resources': resources})
    files = {p.name: digest(p) for p in output.iterdir() if p.is_file()}
    BASE.write_json(output / '保存会計の確認.json', {'成功': True, **proofs, 'scope': scope, '会計': len(rows), '資源': len(resources), '旧対照': len(tasks) * 4, '不一致数': 0, '入力codeSHA256前': before, '入力codeSHA256後': after, '前後不変': True, '出力SHA256': files, 'Raw/CSV/Source/金融/HTTP再実行': 0})
    return {'成功': True, '場数': len(tasks), '会計': len(rows), '資源': len(resources)}


def main():
    """機能: 109事後固定FileRefを指定した保存CLIを起動する。

    引数: --fixed/--fixed-sha/--outはRoot固定JSON・期待SHA・新規先。
    返り値: None。未固定/金融失敗は本文前に拒否する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fixed', type=Path, required=True)
    parser.add_argument('--fixed-sha', required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(generate(args.fixed.resolve(), args.fixed_sha, args.out.resolve()), ensure_ascii=False))


if __name__ == '__main__':
    main()
