"""110保護監査だけを手製保存値で検査する。Goや市場Nativeを読まない。

この器具はP監査の型と式の検査であり、実Actor全会計の代用ではない。
"""

import copy
from decimal import Decimal
import importlib.util
import json
from pathlib import Path
import unittest


OWN = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('110保護の独立監査', OWN / '新保護監査.py')
P = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(P)


class 点算術:
    """人工点のID・符号・単位円だけを照合する限定timeline。"""

    def __init__(self, entry):
        """機能: 手製新規を保持する。

        引数: self(点算術)、entry(dict)。返り値: None。
        """
        self.entry = entry

    def verify_position_point(self, identity, point):
        """機能: 手製点の独立算術を検査する。

        引数: self(点算術)、identity(str)、point(dict)。返り値: None。
        """
        e = self.entry
        P.equal(identity, '人工玉', '人工ID')
        P.equal(point['gain_points'], e['side'] * (point['mark_price'] - e['price']), '人工符号')
        P.equal(point['unit_net'], 100 * point['gain_points'] - 77 - 200 * e['slip_points'], '人工単位円')
        P.require(0 <= point['reserved'] <= point['quantity'] <= 7, '人工数量')


def fixture(policy='G3', side=1, slip=0, delayed=False, fallback=False, narrow=False, structural=False):
    """機能: H・費用床・初回AとSource先行予約を含む手製の保存器具を作る。

    引数: policy(str)、side/slip(int)、delayed/fallback/narrow/structural(bool)は人工枝。
    返り値: tupleはbook/config/audit/checked。Goで期待値を作らない。
    """
    cost = Decimal('.77') + 2 * slip
    floor = 10 if slip == 0 else 20
    a = Decimal('40.25') if fallback else Decimal(40)
    alpha = Decimal('.5') if policy == 'G3' else Decimal(1)
    budget = a if fallback else Decimal(20)
    # ----------------------------------------
    # 器具のHは既知の手計算値。P側の導出関数を呼ばない。
    h = 50 if fallback else 30 if policy == 'G3' else 40
    noise = float(floor) + float(budget) - float(cost)
    largest = max(20., 2 * float(cost), float(alpha * a), noise)
    dominant = ['費用床と余裕'] if fallback or policy == 'G3' else ['ATR倍率']
    scope = {'session': '人工場', 'contract': '人工限月', 'start': 1000}
    entry_quote = {'time': 2800, 'index': 0}
    atr_quote = {'time': 2980, 'index': 2} if delayed else entry_quote
    available = 2980 if delayed else 2700
    atr = {'value': a, 'available': available, 'nominal': available, 'quote': atr_quote, 'after_entry': delayed}
    projected = {'value': a, 'available_at': available, 'source_id': f'nativeATR/{available:.9f}/{available:.9f}'}
    entry = {'scope': scope, 'policy': policy, 'side': side, 'price': 10000, 'at': 2800, 'initial_quantity': 7, 'slip_points': slip,
             'entry_v': None if fallback else {'value': 20, 'available_at': 2800, 'source_id': 'V5/人工公表'}, 'atr': None if delayed else projected}
    lock_at = 2980 if delayed else 2800
    lock = {'at': lock_at, 'alpha': alpha, 'atr': projected, 'entry_v': entry['entry_v'], 'v_fallback': fallback, 'noise_budget_points': budget,
            'cost_points': cost, 'minimum_floor': floor, 'base_term': 20, 'cost_term': 2 * float(cost), 'atr_term': float(alpha * a), 'noise_term': noise,
            'dominant_terms': dominant, 'unrounded_threshold': largest, 'threshold_points': h}
    source = {'publication_id': '人工公表', 'delivered_at': 2800, 'frame_sha256': 'a' * 64, 'result_sha256': 'b' * 64}
    publication = {'scope': scope, 'id': '人工公表', 'ordinal': 1, 'end': 2800, 'available_at': 2800, 'v': None if fallback else 20, 'c': 1, 'm': 1, 'close': 10000, 'prior_pivot': None}
    initial = {'entry': entry, 'cost_points': cost, 'threshold_points': 0 if delayed else h, 'fee_floor': 5 if slip == 0 else 15, 'minimum_floor': floor,
               'entry_v_fallback': fallback, 'atr': None if delayed else projected, 'active': False, 'activated_at': None, 'narrowed': False, 'narrowed_at': None,
               'peak_points': None, 'floor_points': None, 'width_points': None, 'latest_publication': None, 'remaining': 7, 'reserved': 0, 'at': 2800, 'sequence': 0,
               'finished': False, 'threshold_known': not delayed, 'threshold_lock': None if delayed else lock}

    def point(index, at, gain, phase='after_source', reserved=0):
        """機能: 手製の1枚単位点を作る。

        引数: index/at/gain(int)、phase(str)、reserved(int)。返り値: dictは最小点。
        """
        return {'quote': {'index': index, 'time': at}, 'phase': phase, 'quantity': 7, 'reserved': reserved, 'gain_points': gain,
                'unit_net': gain * 100 - 77 - 200 * slip, 'mark_price': 10000 + side * gain}

    before = point(1, 2801, 200 if delayed else 5)
    first_point = point(2, 2980, 5)
    activation = point(3, 3520, 100, 'pre_fill')
    exit_point = point(4, 3521, 0, reserved=3)
    peak = 200 if delayed else 100
    current_pub = copy.deepcopy(publication)
    if narrow or structural:
        current_pub.update(id='人工狭幅', ordinal=2, end=3520, available_at=3520, v=500 if structural else 10, c=2, m=2)
        if structural:
            current_pub['close'] = 10000 + side * 50
            current_pub['prior_pivot'] = {'scope': scope, 'id': '人工pivot', 'kind': 'low' if side == 1 else 'high', 'price': 10000 + side * 95,
                                        'center_end': 2980, 'confirm_end': 3340, 'published_at': 3340}
    width = 40 if structural else 10 if narrow else 85 if fallback else 40
    structural_floor = 90 if structural else None
    selected_floor = max(floor, peak - width, structural_floor or 0)
    origin = 'G2_狭幅_minATR_V' if narrow or structural else 'G2_V不明_旧2ATR' if fallback else 'G2_通常_min2ATR_2V'
    active_source = dict(source, publication_id=current_pub['id'], delivered_at=current_pub['available_at'])

    def saved_step(mt, sequence, active, first_lock=False):
        """機能: 実行engineを用いず手製状態とDecisionをまとめる。

        引数: mt(dict)、sequence(int)、active/first_lock(bool)。返り値: dictは保存step。
        """
        state = copy.deepcopy(initial)
        state.update(at=mt['quote']['time'], sequence=sequence, atr=projected, threshold_known=True, threshold_points=h, threshold_lock=lock,
                     remaining=7, reserved=mt['reserved'], peak_points=peak if active else 200 if delayed else 5, latest_publication=current_pub if active else publication)
        if active:
            state.update(active=True, activated_at=3520, narrowed=narrow or structural, narrowed_at=3520 if narrow or structural else None, floor_points=selected_floor, width_points=width)
        hit = active and mt['gain_points'] <= selected_floor
        decision = {'warning': 2 if active and (narrow or structural) else 1, 'p': 2 if active and structural else 0,
                    'gain_points': mt['gain_points'], 'unit_net_yen': mt['unit_net'], 'activated_now': active and sequence == 3,
                    'narrowed_now': active and sequence == 3 and (narrow or structural), 'width_source': origin if active else '',
                    'structural_floor': structural_floor if active else None, 'structural_eligible': active and structural,
                    'floor_hit': hit, 'free_quantity': 7 - mt['reserved'], 'eligible_exit_quantity': 7 - mt['reserved'] if hit and mt['phase'] == 'after_source' else 0,
                    'threshold_locked_now': first_lock}
        return {'point': mt, 'state': state, 'decision': decision, 'source': active_source if active else source}

    lock_step = saved_step(first_point, 2, False, True) if delayed else None
    act = saved_step(activation, 3, True)
    exiting = saved_step(exit_point, 4, True)
    last = copy.deepcopy(exiting['state'])
    last.update(at=3700, sequence=5, finished=True, remaining=0, reserved=0)
    position = {'id': '人工玉', 'side': side, 'entry_price': 10000, 'entry_quote': entry_quote, 'initial_quantity': 7, 'atr': atr,
                'protection_active': True, 'floor_gain': selected_floor, 'activation': activation, 'marks': {'first': before, 'last': exit_point, 'unit_max': before if delayed else activation}}
    request = {'step': exiting, 'order_id': '人工返済', 'requested': 4, 'reserved_before': 3, 'reserved_after': 7}
    audit_position = {'position_id': '人工玉', 'initial': initial, 'initial_source': source, 'last': last, 'last_step': exiting, 'activation': act,
                      'first_narrow': act if narrow or structural else None, 'first_threshold_lock': lock_step, 'first_floor_hit': act if delayed else exiting,
                      'last_floor_update': act, 'first_full_reserved_hit': None, 'requests': [request]}
    config = {'entry_policy': 'entry_E2', 'entry_lifetime': 'L1', 'protection_policy': policy, 'slip_pts': slip, 'delay_seconds': 1}
    composite = {'entry_policy': 'entry_E2', 'entry_lifetime': 'L1', 'protection_policy': policy, 'slip_pts': slip, 'delay_seconds': 1, 'us_open': 0}
    order = {'id': '人工返済', 'kind': 'exit', 'protection_point': exit_point, 'quantity': 4}
    book = {'session': dict(id='人工場', start=1000, us_open=0), 'positions': [position], 'orders': [order]}
    audit = {'config': composite, 'quiet_seconds': 1200, 'contract': '人工限月', 'positions': [audit_position]}
    # ----------------------------------------
    # 実保存と同じDecimal字句読取を通し、Python内のdict共有を取り除く。
    book, config, audit = json.loads(json.dumps([book, config, audit], default=float), parse_float=Decimal)
    checked = {'timeline': 点算術(audit['positions'][0]['initial']['entry']), 'orders': {'人工返済': book['orders'][0]}}
    return book, config, audit, checked


class 保護だけの検査(unittest.TestCase):
    """未接続P監査の正当値と改竄拒否を確認する。"""

    def test_二政策と売買と費用とA後判明(self):
        """機能: Hと初回Aを両向き・費用別に独立監査する。

        引数: self(保護だけの検査)。返り値: None。
        """
        for policy in ('G3', 'G4'):
            for side in (1, -1):
                for slip in (0, 5):
                    for delayed in (False, True):
                        with self.subTest(policy=policy, side=side, slip=slip, delayed=delayed):
                            values = fixture(policy, side, slip, delayed)
                            self.assertGreater(P.verify_protection(*values)['保存保護点'], 0)

    def test_V未知の未丸めA代替と後判明(self):
        """機能: V未知代替を丸めずH50で固定し、過去益を遡及しない。

        引数: self(保護だけの検査)。返り値: None。
        """
        for policy in ('G3', 'G4'):
            for delayed in (False, True):
                values = fixture(policy, delayed=delayed, fallback=True)
                P.verify_protection(*values)
                self.assertEqual(values[2]['positions'][0]['last']['threshold_lock']['noise_budget_points'], Decimal('40.25'))

    def test_両政策の収束狭幅と構造床(self):
        """機能: G3を旧G1幅に置換せずG4と同じ狭幅/構造を検査する。

        引数: self(保護だけの検査)。返り値: None。
        """
        for policy in ('G3', 'G4'):
            for side in (1, -1):
                for structural in (False, True):
                    P.verify_protection(*fixture(policy, side, narrow=True, structural=structural))

    def test_現在Hの同値と直前の独立境界(self):
        """機能: 現在利益でだけ起動し、u=100Hの等号を含むことを検査する。

        引数: self(保護だけの検査)。返り値: None。
        """
        values = fixture(delayed=True)
        book, config, audit, checked = values
        p = audit['positions'][0]
        self.assertGreater(book['positions'][0]['marks']['first']['unit_net'], 100 * p['last']['threshold_points'])
        self.assertFalse(p['first_threshold_lock']['state']['active'])
        P.verify_protection(*values)
        for current, allowed in ((Decimal('2999.99999999'), False), (Decimal(3000), True), (Decimal('3000.00000001'), True)):
            self.assertEqual(P.current_reached(current, True, p['last']['threshold_points']), allowed)
        self.assertFalse(P.current_reached(Decimal(999999), False, 0))
        with self.assertRaises(ValueError):
            P.current_reached(Decimal(3000), True, 0)

    def test_最後までA不明の実玉をH0起動しない(self):
        """機能: A未取得の終端玉と高い過去益を両立して監査する。

        引数: self(保護だけの検査)。返り値: None。
        """
        b, c, a, checked = fixture(delayed=True)
        actual, pure = b['positions'][0], a['positions'][0]
        actual.update(atr=None, protection_active=False, floor_gain=None, activation=None)
        b['orders'] = []
        checked['orders'] = {}
        pure['last'] = copy.deepcopy(pure['initial'])
        pure['last'].update(at=3700, sequence=5, remaining=0, reserved=0, finished=True, peak_points=200)
        for key in ('last_step', 'activation', 'first_narrow', 'first_threshold_lock', 'first_floor_hit', 'last_floor_update', 'first_full_reserved_hit'):
            pure[key] = None
        pure['requests'] = []
        self.assertEqual(P.verify_protection(b, c, a, checked), {'保存保護点': 0, '自己保護要求': 0})
        pure['last']['threshold_points'] = 20
        with self.assertRaises(ValueError):
            P.verify_protection(b, c, a, checked)

    def test_改竄拒否(self):
        """機能: H既知性/lock/現在起動/幅/予約の独立改変を拒否する。

        引数: self(保護だけの検査)。返り値: None。
        """
        mutations = {
            '旧H20': lambda b, c, a: a['positions'][0]['last'].__setitem__('threshold_points', 20),
            '未知0を既知化': lambda b, c, a: a['positions'][0]['initial'].__setitem__('threshold_known', True),
            '初回A記録削除': lambda b, c, a: a['positions'][0].__setitem__('first_threshold_lock', None),
            'Aより前へlock': lambda b, c, a: a['positions'][0]['first_threshold_lock']['state']['threshold_lock'].__setitem__('at', 2801),
            '別原行で初回A': lambda b, c, a: a['positions'][0]['first_threshold_lock']['point']['quote'].__setitem__('index', 1),
            '過去peakで起動': lambda b, c, a: a['positions'][0]['first_threshold_lock']['decision'].__setitem__('activated_now', True),
            'H固定Decision削除': lambda b, c, a: a['positions'][0]['first_threshold_lock']['decision'].__setitem__('threshold_locked_now', False),
            'H再固定': lambda b, c, a: a['positions'][0]['activation']['decision'].__setitem__('threshold_locked_now', True),
            'A出典': lambda b, c, a: a['positions'][0]['last']['threshold_lock']['atr'].__setitem__('source_id', '別A'),
            'ATR倍率': lambda b, c, a: a['positions'][0]['last']['threshold_lock'].__setitem__('alpha', 1),
            '費用丸め': lambda b, c, a: a['positions'][0]['last']['threshold_lock'].__setitem__('noise_term', 30),
            '支配根拠': lambda b, c, a: a['positions'][0]['last']['threshold_lock'].__setitem__('dominant_terms', ['ATR倍率']),
            '最低床緩和': lambda b, c, a: a['positions'][0]['last'].__setitem__('floor_points', 10),
            'G3を旧2A幅': lambda b, c, a: a['positions'][0]['activation']['state'].__setitem__('width_points', 80),
            'Source予約二重化': lambda b, c, a: a['positions'][0]['requests'][0].__setitem__('requested', 7),
            '同sequence別内容': lambda b, c, a: a['positions'][0]['first_floor_hit']['source'].__setitem__('publication_id', '別公表'),
        }
        for label, mutate in mutations.items():
            with self.subTest(label=label):
                b, c, a, checked = fixture(delayed=True)
                mutate(b, c, a)
                with self.assertRaises((ValueError, TypeError, KeyError)):
                    P.verify_protection(b, c, a, checked)
        b, c, a, checked = fixture(fallback=True)
        a['positions'][0]['last']['threshold_lock']['noise_budget_points'] = 45
        with self.assertRaises(ValueError):
            P.verify_protection(b, c, a, checked)

    def test_未来構造と非有限の拒否(self):
        """機能: 未確定構造と非有限尺度を両政策で拒否する。

        引数: self(保護だけの検査)。返り値: None。
        """
        for policy in ('G3', 'G4'):
            b, c, a, checked = fixture(policy, structural=True)
            a['positions'][0]['activation']['state']['latest_publication']['prior_pivot']['published_at'] = 3520
            with self.assertRaises(ValueError):
                P.verify_protection(b, c, a, checked)
            b, c, a, checked = fixture(policy)
            a['positions'][0]['last']['atr']['value'] = Decimal('NaN')
            with self.assertRaises(ValueError):
                P.verify_protection(b, c, a, checked)


if __name__ == '__main__':
    unittest.main()
