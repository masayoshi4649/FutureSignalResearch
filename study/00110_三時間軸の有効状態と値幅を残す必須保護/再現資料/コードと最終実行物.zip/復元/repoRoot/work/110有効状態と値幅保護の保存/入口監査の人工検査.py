"""停止Coreの人工144冊だけで入口と活動の独立監査を検査する。"""

import copy
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

import 旧純算術 as A
import 入口と活動の監査 as E

HERE = Path(__file__).resolve().parent
ART = HERE.parent / '110有効状態と値幅保護の接続' / '人工_停止版'
FILES = ([ART / f'方向{side}_{mode}.json' for side in (1,-1) for mode in ('saved','fresh')]
         + [ART / f'反転_方向{side}_出生{birth}.json' for side in (1,-1) for birth in (1980,2880)])


def load(path):
    """
    機能: 明示人工1件を読む。

    引数: path(Path)。

    返り値: dictはDecimal読込のCore出力。
    """
    return json.loads(path.read_text(encoding='utf-8'), parse_float=Decimal)['output']


def verify(data, key):
    """
    機能: 一冊の会計と入口監査を結合する。

    引数: data(dict),key(str)。

    返り値: dictは計数。
    """
    config = next(c for c in data['configs'] if A.key_for(c)==key)
    book = data['books'][key]
    checked = A.verify_finance(book,config)
    return E.verify_entry(book,config,data['clock_audits'][key],data['composite_audits'][key],data['entry_audits'][key],checked,False)


class 入口監査(unittest.TestCase):
    """L0/L1と複合入口の保存改変を検出する。"""

    def test_全方向全方式288冊(self):
        """
        機能: T4/R4器具の全36を検算する。

        引数: self(入口監査)。

        返り値: None。
        """
        total = 0
        for path in FILES:
            data = load(path)
            for key in data['books']:
                with self.subTest(file=path.name,key=key): verify(data,key)
                total += 1
        self.assertEqual(total,288)

    def test_L1査定と永久消費の破壊(self):
        """
        機能: 出生/枠/余力/Source予約/一度lockの改変を拒否する。

        引数: self(入口監査)。

        返り値: None。
        """
        data = load(FILES[0]); key='entry_E2_L1_G3_C0_D0'
        mutations = {
            '査定欠落':lambda d:d['composite_audits'][key]['entry_attempts'].pop(0),
            '査定連番':lambda d:d['composite_audits'][key]['entry_attempts'][0].__setitem__('attempt',2),
            '出生方向':lambda d:d['composite_audits'][key]['entry_attempts'][0]['opportunity'].__setitem__('side',-1),
            '最短枠':lambda d:d['composite_audits'][key]['entry_attempts'][0]['opportunity'].__setitem__('assigned_at',0),
            '現在Source残':lambda d:d['composite_audits'][key]['entry_attempts'][0]['opportunity'].__setitem__('source_quantity',999),
            '当時余力':lambda d:d['composite_audits'][key]['entry_attempts'][0]['opportunity'].__setitem__('available',999),
            '消費flag':lambda d:d['composite_audits'][key]['entry_attempts'][0].__setitem__('terminal',False),
            '偽保有':lambda d:d['books'][key]['grid_traces'][0].__setitem__('open_buy',999),
            '誤未知集計':lambda d:d['books'][key]['grid_metrics'].__setitem__('required_unknown',999),
            '一括候補欠落':lambda d:d['composite_audits'][key]['entry_batches'][-1]['input']['candidates'].append({}),
        }
        for label,change in mutations.items():
            with self.subTest(label=label):
                damaged=copy.deepcopy(data);change(damaged)
                with self.assertRaises((ValueError,KeyError,TypeError,IndexError)): verify(damaged,key)

    def test_L1寿命を純技法と分離した六端点(self):
        """
        機能: 実Actor APIの手製採否でL1金融/寿命の端点だけを単体検算する。

        引数: self(入口監査)は検査器。
        返り値: None。純技法は別の停止Core288冊で検算する。
        """
        path=HERE.parent/'110入口寿命の人工出典'/'寿命の人工.json'
        values=json.loads(path.read_text(encoding='utf-8'),parse_float=Decimal)
        for name,value in values.items():
            with self.subTest(name=name):
                book,comp=value['book'],value['composite']
                cfg=next(c for c in A.configurations() if A.key_for(c)=='entry_E2_L1_G3_C0_D0')
                audit=artificial_lifetime_audit(comp)
                checked=A.verify_finance(book,cfg)
                with patch.object(E,'pure_assessment',lambda *args:None):
                    E.verify_entry(book,cfg,value['clock'],comp,audit,checked,False)
        self.assertEqual(len(values),6)

    def test_純式の改変拒否(self):
        """
        機能: 数値/時計/現在支持/並列群/代表経路の改変を拒否する。

        引数: self(入口監査)は検査器。
        返り値: None。
        """
        original=load(FILES[0]);key='entry_E2_L1_G3_C0_D0'
        def first(d):
            """
            機能: 停止人工の最初の純候補を取得する。

            引数: d(dict)は人工Core出力。
            返り値: dictは純候補。
            """
            return d['entry_audits'][key]['nonempty_batches'][0]['decisions'][0]
        mutations={
            '限月':lambda d:first(d)['evidence'][0].__setitem__('contract','別限月'),
            '未来clock':lambda d:first(d)['evidence'][0].__setitem__('delivery_at',d['session']['end']),
            'EMA方向':lambda d:first(d)['evidence'][0]['technical']['ema8'].__setitem__('value',0),
            'RSI維持':lambda d:first(d)['evidence'][0]['technical']['rsi'].__setitem__('value',0),
            'H水準':lambda d:first(d)['evidence'][0]['technical']['histogram'].__setitem__('value',-999),
            '誤った群':lambda d:first(d)['continuation'].__setitem__('passed',not first(d)['continuation']['passed']),
            '別代表経路':lambda d:first(d).__setitem__('route','R局所転換'),
            '支持失効':lambda d:d['entry_audits'][key]['nonempty_batches'][0]['state']['trend'][0].__setitem__('active',False),
            '費用外距離':lambda d:first(d)['position'].__setitem__('line_distance',999),
            '代表勢い':lambda d:first(d)['momentum'].__setitem__('passed',False),
        }
        for label,change in mutations.items():
            with self.subTest(label=label):
                data=copy.deepcopy(original);change(data)
                with self.assertRaises((ValueError,KeyError,TypeError)): verify(data,key)
        from 入口純式110 import verify_pure
        data=copy.deepcopy(original)
        batch=data['entry_audits'][key]['nonempty_batches'][0]
        actor=data['composite_audits'][key]['entry_batches'][next(i for i,b in enumerate(data['composite_audits'][key]['entry_batches']) if b['input']['candidates'])]['output']['decisions'][0]
        p=batch['decisions'][0]
        p.update(known=False,allowed=False,status='未知',route='',role='')
        p['common'].update(known=False,passed=False)
        actor['decision'].update(known=False,allowed=False,role='未知')
        with self.assertRaises(ValueError):
            verify_pure(batch,actor,{'gate':actor['decision']})

    def test_寿命端点の破壊拒否(self):
        """
        機能: 枠間予約の忘却、Forceの早期化、受理後再査定を拒否する。

        引数: self(入口監査)は検査器。
        返り値: None。
        """
        path=HERE.parent/'110入口寿命の人工出典'/'寿命の人工.json'
        original=json.loads(path.read_text(encoding='utf-8'),parse_float=Decimal)
        cases=[('予約解消後も失効',lambda v:v['composite'].__setitem__('first_source_closings',[])),
               ('予約解消後も失効',lambda v:v['composite']['first_source_closings'][0].__setitem__('at',v['book']['session']['end'])),
               ('未知からForce',lambda v:v['composite']['lifetime_terminals'][0].__setitem__('at',v['book']['session']['start'])),
               ('待機からEOF',lambda v:v['composite'].__setitem__('lifetime_terminals',[])),
               ('後配賦満杯から初回取得',lambda v:v['composite']['entry_attempts'][2]['opportunity'].__setitem__('gate',v['composite']['entry_attempts'][0]['opportunity']['gate'])),
               ('受理取消後も再参加禁止',lambda v:v['composite']['entry_attempts'].append(copy.deepcopy(v['composite']['entry_attempts'][0])))]
        cfg=next(c for c in A.configurations() if A.key_for(c)=='entry_E2_L1_G3_C0_D0')
        for name,mutate in cases:
            with self.subTest(name=name):
                value=copy.deepcopy(original[name]);mutate(value)
                comp=value['composite'];audit=artificial_lifetime_audit(comp)
                checked=A.verify_finance(value['book'],cfg)
                with patch.object(E,'pure_assessment',lambda *args:None),self.assertRaises((ValueError,KeyError,TypeError)):
                    E.verify_entry(value['book'],cfg,value['clock'],comp,audit,checked,False)


def artificial_lifetime_audit(comp):
    """
    機能: 手製採否の寿命単体器具に計数境界を作る。

    引数: comp(dict)はActor外監査。技術指標を作らない。
    返り値: dictは寿命単体用の明示した人工入口監査。
    """
    batches=[];count=allowed=unknown=0
    for b in comp['entry_batches']:
        decisions=[]
        for item in b['output']['decisions']:
            c,d=item['candidate'],item['decision']
            decisions.append({'candidate':{'side':c['side']},'known':d['known'],'route':'人工寿命採否' if d['allowed'] else ''})
            count+=1;allowed+=d['allowed'];unknown+=not d['known']
        if decisions:batches.append({'snapshot_id':b['input']['snapshot_id'],'decisions':decisions,'conflict':False})
    return {'policy':'entry_E2','calls':len(comp['entry_batches']),'nonempty_batches':batches,'candidates':count,'allowed':allowed,'unknown':unknown,'conflicts':0}


def main():
    """
    機能: 人工入力前後同体と単体結果を保存する。

    引数: なし。

    返り値: None。
    """
    inputs=FILES+[HERE.parent/'110入口寿命の人工出典'/'寿命の人工.json']
    before={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
    code_files=[HERE/name for name in ('入口と活動の監査.py','入口純式110.py','入口監査の人工検査.py')]
    codes={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in code_files}
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(入口監査)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    after={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in inputs}
    if before!=after: raise RuntimeError('人工入力変更')
    if codes!={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in code_files}:raise RuntimeError('入口所有コード変更')
    report={'成功':result.wasSuccessful(),'主':result.testsRun,'人工冊数':288,'寿命のみの単体器具':6,'破壊反例':27,'入力SHA256前':before,'入力SHA256後':after,'所有コードSHA256':codes,
            '前後不変':True,'市場入力読取':False,'金融再実行':False,'未使用11月09日読取':False,
            '限界':'保存された現支持/数値/時計の局所式を検算。EMA全系列や各足の支持未否定は保存点だけから全再形成しない。T初回試験足ID/開始は未保存。'}
    (HERE/'入口監査の検査.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if not result.wasSuccessful(): raise SystemExit(1)
    if '--stop' in sys.argv:
        stop=HERE/'入口監査の停止.json'
        if stop.exists():raise RuntimeError('E小停止の上書き禁止')
        proof={'version':1,'trial':110,'停止':True,'成功':True,'範囲':'入口E2の独立式とL0/L1の金融適格/現在Source/活動監査のみ。全保存器の停止はRootが別に行う。',
               'コードSHA256':codes,'人工入力SHA256':before,'検査':{'path':str(HERE/'入口監査の検査.json'),'sha256':hashlib.sha256((HERE/'入口監査の検査.json').read_bytes()).hexdigest()},
               '前後不変':True,'市場本文読取':False,'実金融再実行':False,'未使用11月09日読取':False,
               '限界':report['限界'],'研究目標達成':False,'採用':False}
        stop.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')


if __name__=='__main__': main()
