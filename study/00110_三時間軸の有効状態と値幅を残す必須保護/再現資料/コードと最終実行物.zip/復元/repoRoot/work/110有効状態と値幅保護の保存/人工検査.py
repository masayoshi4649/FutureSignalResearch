"""停止済みのT/R・買売8器具288冊を独立保存器へ接続して検算する。"""

import copy
from decimal import Decimal
import json
from pathlib import Path
import tempfile
import unittest

import 集計 as S
import 固定ゲート as G
import 新保護監査 as P

ART = S.ROOT / "work/110有効状態と値幅保護の接続/人工_停止版"
CORE_STOP = ART.parent / "停止.json"
CORE_SHA = "80d6eeb5c9781fe831c55a95a5039b09f8b5849b6106781026377889ab1a88cb"
S.equal(S.digest(CORE_STOP), CORE_SHA, "停止Coreの実人工だけ")
DECLARATION = S.load(CORE_STOP)
PINS = {Path(row["path"]).name: row["sha256"] for row in DECLARATION["人工出力"]}
EXTRA_PINS = {str(CORE_STOP): CORE_SHA}
NAMES = [name for name in PINS if name.startswith("方向") or name.startswith("反転")]
S.equal(len(NAMES), 8, "T4とR4の全器具")
KEY = "entry_E2_L1_G4_C0_D0"


def fixture(name: str = "反転_方向1_出生2880.json") -> tuple[dict, str]:
    """機能: 停止Coreの人工Nativeを元字句とDecimalで読む。

    引数: name(str)は明示8器具の一つ。
    返り値: tuple[dict,str]はCore値と元JSON字句。
    """
    S.equal(S.digest(ART / name), PINS[name], "人工入力SHA")
    raw = S.OLD.raw_members(S.read_text(ART / name))["output"]
    return json.loads(raw, parse_float=Decimal), raw


def pure_decision(value: dict) -> dict:
    """機能: 実際のR受理と結合する最初の純判定を取得する。

    引数: value(dict)は人工Core値。
    返り値: dictは改竄反例に使うRの保存判定。
    """
    return next(d for b in value["entry_audits"][KEY]["nonempty_batches"] for d in b["decisions"] if d["allowed"])


class 保存検査(unittest.TestCase):
    """機能: 純会計・新保護・入口寿命と保存形式の結合を確認する。"""

    def test_全288冊とT反転買売(self) -> None:
        """機能: 全8器具36冊の会計・P/E・旧対照と場別集計を検算する。

        引数: self(保存検査)は検査器。
        返り値: None。実市場の利益や自然Sourceを主張しない。
        """
        count, controls, zero = 0, 0, 0
        for name in NAMES:
            with self.subTest(name=name):
                before = S.digest(ART / name)
                value, raw = fixture(name)
                checked = S.inspect_scene(value, raw, artificial=True)
                rows = S.scene_rows(value, checked["checked"])
                summary = S.aggregate(rows, "artificial")
                self.assertEqual((len(rows), len(summary)), (36, 36))
                self.assertEqual(S.digest(ART / name), before)
                self.assertTrue(all(row["open_buy"] + row["open_sell"] + row["pending_buy"] + row["pending_sell"] == 0 for row in rows))
                count += len(rows)
                controls += len(checked["baseline"])
                zero += sum(row["positions"] == 0 for row in rows)
        self.assertEqual((count, controls, zero), (288, 32, 24))

    def test_会計保護と純入口の破壊反例(self) -> None:
        """機能: 約定・費用・H・公表・現在支持を壊す反例を拒否する。

        引数: self(保存検査)は検査器。
        返り値: None。値を改変したコピーだけを監査し原本を保つ。
        """
        value, raw = fixture()
        mutations = {
            "手数料": lambda d: d["books"][KEY]["fills"][0].__setitem__("fee_yen", 0),
            "同原行約定": lambda d: d["books"][KEY]["fills"][0]["quote"].__setitem__("source_line", d["books"][KEY]["orders"][0]["request_quote"]["source_line"]),
            "Lifetime偽装": lambda d: d["books"][KEY]["config"].__setitem__("entry_lifetime", "L0"),
            "H改変": lambda d: d["composite_audits"][KEY]["positions"][0]["last"].__setitem__("threshold_points", 5),
            "H未確定を起動": lambda d: d["composite_audits"][KEY]["positions"][0]["activation"]["state"].__setitem__("threshold_known", False),
            "費用床0": lambda d: d["composite_audits"][KEY]["positions"][0]["activation"]["state"].__setitem__("minimum_floor", 0),
            "未来V": lambda d: d["composite_audits"][KEY]["positions"][0]["initial"]["entry"]["entry_v"].__setitem__("available_at", d["session"]["end"]),
            "未知を許可": lambda d: pure_decision(d).__setitem__("known", False),
            "R確認前": lambda d: pure_decision(d)["structure"].__setitem__("confirmed_at", d["session"]["end"]),
            "R未維持": lambda d: pure_decision(d)["structure"].__setitem__("active", False),
            "R経路偽装": lambda d: pure_decision(d).__setitem__("route", "T継続"),
            "R復帰を同足": lambda d: pure_decision(d)["structure"].__setitem__("recovery_end", pure_decision(d)["structure"]["failure_end"]),
        }
        for label, mutate in mutations.items():
            with self.subTest(label=label), self.assertRaises((ValueError, KeyError, TypeError)):
                broken = copy.deepcopy(value)
                mutate(broken)
                S.inspect_scene(broken, raw, artificial=True)

    def test_L1待機の永久lock反例(self) -> None:
        """機能: 未取得の待機と最初の受理を改竄した履歴を拒否する。

        引数: self(保存検査)は検査器。
        返り値: None。実fill後再参加と単なる後枠取得を混同しない。
        """
        value, raw = fixture("反転_方向1_出生1980.json")
        attempts = value["composite_audits"][KEY]["entry_attempts"]
        self.assertGreaterEqual(len(attempts), 2)
        self.assertEqual((attempts[0]["action"], attempts[-1]["action"]), ("wait", "accepted"))
        mutations = {
            "査定欠落": lambda a: a.pop(0),
            "待機を受理": lambda a: a[0].__setitem__("action", "accepted"),
            "待機で永久失効": lambda a: a[0].__setitem__("terminal", True),
            "受理lock欠落": lambda a: a[-1].__setitem__("terminal", False),
            "受理後再査定": lambda a: a.append(copy.deepcopy(a[-1])),
            "未来に割当戻し": lambda a: a[-1]["opportunity"].__setitem__("assigned_at", a[-1]["at"]+300),
        }
        for label, mutate in mutations.items():
            with self.subTest(label=label), self.assertRaises((ValueError, KeyError, TypeError)):
                broken = copy.deepcopy(value)
                mutate(broken["composite_audits"][KEY]["entry_attempts"])
                S.inspect_scene(broken, raw, artificial=True)

    def test_Viewer実約定の36資源(self) -> None:
        """機能: 実fillだけのViewer出力を再読し全36の件数を確認する。

        引数: self(保存検査)は検査器。
        返り値: None。HTTP通信や価格データの複製は行わない。
        """
        value, _ = fixture()
        with tempfile.TemporaryDirectory() as directory:
            out = Path(directory)
            resources = S.save_viewer(value, out, "人工価格参照")
            self.assertEqual(len(resources), 36)
            for resource in resources:
                lines = (out / resource["pnl_path"]).read_text(encoding="utf-8").splitlines()
                rows = [json.loads(line) for line in lines]
                self.assertTrue(rows)
                self.assertEqual(len(rows), len(value["books"][resource["method_id"]]["fills"]))

    def test_未固定失敗と分母(self) -> None:
        """機能: 金融成功前の保存拒否と未観測を含む予定分母を検査する。

        引数: self(保存検査)は検査器。
        返り値: None。未知や受理だけを参加へ水増ししない。
        """
        with self.assertRaises(ValueError):
            G.validate_completion({"version": 1, "trial": 110, "fixed": False}, {}, {}, "full70", "0"*64)
        value, _ = fixture("反転_方向1_出生1980.json")
        key = "entry_E2_L0_G4_C0_D0"
        book = value["books"][key]
        checked = S.A.verify_finance(book, S.BY_KEY[key])
        activity = S.OLD.PARTICIPATION20(book, checked)
        self.assertGreater(activity["denom"], 0)
        self.assertEqual(activity["active"], 0)
        copy_book = copy.deepcopy(book)
        copy_book["grid_traces"] = []
        after = S.OLD.PARTICIPATION20(copy_book, checked)
        self.assertEqual(activity["denom"], after["denom"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
