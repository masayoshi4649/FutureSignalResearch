"""110の独立保存器を停止Core人工288冊とP/Eの追加境界へ結んで停止する。"""

import ast
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys

import 集計 as S
import 固定ゲート as G
from 人工検査 import ART, PINS, EXTRA_PINS


def reference(path: Path) -> dict:
    """機能: 成功した小型検査を所在と指紋で参照する。

    引数: path(Path)は人工の停止・確認資料。
    返り値: dictは絶対pathとSHA256。
    """
    return {"path": str(path.resolve()), "sha256": S.digest(path)}


def main() -> None:
    """機能: 全Python依存と人工入力の不変を確認して新規停止する。

    引数: なし。
    返り値: None。原板・実Native・CSV・未読11/09は開かない。
    """
    own = Path(__file__).resolve().parent
    stop = own / "停止.json"
    S.need(not stop.exists(), "保存停止の上書き禁止")
    pins = {str(ART / name): h for name, h in PINS.items()}
    pins.update(EXTRA_PINS)
    unit_refs = {}
    for filename, expected in [
        ("保護監査の停止.json", "ce65aec153aa6f6d272c664196a5d795dd0abff4d64b7fb9468a3db7eaf70fb0"),
        ("入口監査の停止.json", "bb2c3bb7440ec2ff1de195ec8b71049b35a78d7f2f0b66422f4b34f6e9b0cf45"),
    ]:
        path = own / filename
        S.equal(S.digest(path), expected, "P/E単体停止")
        declaration = S.load(path)
        S.need(declaration["成功"] and declaration["停止"], "P/E人工成功")
        pins[str(path)] = expected
        code_map = declaration.get("コードSHA256", declaration.get("所有コードSHA256", {}))
        S.need(code_map, "P/E所有コードが必要")
        for source, h in code_map.items():
            S.equal(S.digest(Path(source)), h, "P/Eコード現物")
        for field in ("人工入力SHA256", "入力SHA256前"):
            for source, h in declaration.get(field, {}).items():
                if source in pins:
                    S.equal(pins[source], h, "人工出典の衝突なし")
                pins[source] = h
        check = declaration.get("検査")
        if isinstance(check, dict) and "path" in check:
            S.equal(S.digest(Path(check["path"])), check["sha256"], "P/E人工検査の現物")
            pins[check["path"]] = check["sha256"]
        unit_refs[filename] = reference(path)
    paths = G.dependency_paths()
    code = {str(path): S.digest(path) for path in paths}
    for path in paths:
        ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
    for path, expected in pins.items():
        S.equal(S.digest(Path(path)), expected, "停止人工入力の現物")
    command = [sys.executable, "-B", "-X", "utf8", str(own / "人工検査.py")]
    process = subprocess.run(command, cwd=S.ROOT, encoding="utf-8", capture_output=True)
    check_dir = own / "検査"
    check_dir.mkdir(exist_ok=True)
    (check_dir / "人工検査.txt").write_text(process.stdout+process.stderr, encoding="utf-8")
    S.equal(process.returncode, 0, "全保存結合の実exit code")
    after = {path: S.digest(Path(path)) for path in pins}
    code_after = {path: S.digest(Path(path)) for path in code}
    S.equal(after, pins, "全人工入力前後不変")
    S.equal(code_after, code, "全Pythonコード前後不変")
    report = {"成功": True, "検査argv": command, "exit_code": 0,
              "人工口座": 288, "人工Core器具": 8, "旧全JSON対照": 32,
              "主検査": 5, "全結合破壊反例": 18, "Viewer再読資源": 36,
              "P/E追加境界": unit_refs, "構文ファイル": len(paths),
              "入力SHA256前": pins, "入力SHA256後": after,
              "コードSHA256前": code, "コードSHA256後": code_after, "前後不変": True,
              "範囲": "全fill/費用/所有/保存点DD・時計・E2保存数式/出典/Source適格/受付寿命・G3/G4保存根拠。全指標や全tickを別engineで再計算したものではない",
              "実市場読取": False, "実金融": False, "CSV/xlsx生成": False,
              "HTTP通信": False, "Python版": sys.version}
    check_path = check_dir / "Python確認.json"
    S.BASE.write_json(check_path, report)
    S.BASE.write_json(stop, {"version": 1, "trial": 110, "停止": True,
                            "scope": "Root固定＋金融成功後の独立保存器。人工T/R・買売288冊とP/E追加境界のみ",
                            "日時UTC": datetime.now(timezone.utc).isoformat(), "コードSHA256": code,
                            "仕様": reference(own / "README.md"), "検査": reference(check_path),
                            "入力前後不変": True, "実市場読取": False, "実金融": False,
                            "CSV/xlsx生成": False, "研究目標達成": False, "採用": False})
    print(json.dumps({"成功": True, "停止": str(stop), "停止SHA256": S.digest(stop), "全依存": len(paths)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
