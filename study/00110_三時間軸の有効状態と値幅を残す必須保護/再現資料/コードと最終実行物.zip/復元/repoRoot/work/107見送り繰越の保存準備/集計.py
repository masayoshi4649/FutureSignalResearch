"""107の実名24口座を固定106保存算術と独立したquiet割当へ結ぶ。"""

import argparse
import ast
from collections import Counter
import hashlib
import importlib.util
import inspect
import json
import math
from pathlib import Path
import textwrap
import types


ROOT = Path(__file__).resolve().parents[2]
SAVED_PATH = ROOT / "work/106可変保護の保存準備/集計.py"
SAVED_SHA = "7451f6c6502ec7b5ca83d0ce296931f1abbb2b082d41003ccb8a907846736f47"
if hashlib.sha256(SAVED_PATH.read_bytes()).hexdigest() != SAVED_SHA:
    raise ValueError("固定106保存器SHA差")
SPEC = importlib.util.spec_from_file_location("107が直接再用する固定106保存", SAVED_PATH)
SAVED = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SAVED)
OLD, BASE, GRID = SAVED.OLD, SAVED.BASE, SAVED.GRID
need, equal, digest, load = SAVED.need, SAVED.equal, SAVED.digest, SAVED.load
GROUPS = (("B0", "B5Q", "W0"), ("B1", "B5Q", "W1"), ("BE", "B5Q", "E1"),
          ("Q0", "B5QD", "W0"), ("Q1", "B5QD", "W1"), ("QE", "B5QD", "E1"))
CONFIGS = [{"candidate": p, "entry_timing": t, "protection_policy": w, "slip_pts": c, "delay_seconds": d}
           for p, t, w in GROUPS for c in (0, 5) for d in (0, 1)]
KEYS = tuple(f"{r['candidate']}_C{r['slip_pts']}_D{r['delay_seconds']}" for r in CONFIGS)
BY_KEY = dict(zip(KEYS, CONFIGS))
E_KEYS = tuple(k for k in KEYS if k.startswith(("BE_", "QE_")))
INNER = {f"{a}_{t}_P0_C{c}_D{d}": ("P0", a, c, d, t)
         for a in ("LD10", "E1") for t in ("B5Q", "B5QD") for c in (0, 5) for d in (0, 1)}
CLOCK_SOURCE = {"path": "work/quietだけ繰り越す入口時計/assignment.go",
                "sha256": "531b32e7f74088a04d2903a0666b6db924578a095a38c1e209e42912274be337"}


def config_for(key):
    """
    機能: 実在する内Keyの本名から政策と費用を取得する。
    引数: key(str)はLD10/E1とB5Q/B5QDを含む実Key。
    返り値: tupleは基本P0、実起動政策、滑り、遅延。
    """
    need(key in INNER, "107の実金融内Key")
    return INNER[key][:4]


def grid_config(key):
    """
    機能: QDをB5Qへ置換せず実時計を旧grid規範へ渡す。
    引数: key(str)は実金融内Key。
    返り値: tupleは実timing、共通基本P0名、滑り、遅延。
    """
    p, _, c, d = config_for(key)
    return INNER[key][4], f"{p}_C{c}_D{d}", c, d


def inner_key(key):
    """
    機能: 外24keyを実時計・実起動政策の内Keyへ明示対応する。
    引数: key(str)はB0/B1/BE/Q0/Q1/QEの費用key。
    返り値: strは改名していない実Book.Key。
    """
    need(key in BY_KEY, "107外24key")
    c = BY_KEY[key]
    activation = "E1" if c["protection_policy"] == "E1" else "LD10"
    return f"{activation}_{c['entry_timing']}_P0_C{c['slip_pts']}_D{c['delay_seconds']}"


def assignment_for(book, opportunity):
    """
    機能: 停止531bのstrict格子とquiet一回割当を独立に再計算する。
    引数: book/opportunity(dict)は実timing・場時計・元Source出生。
    返り値: dictはstrict/assigned/deferredと任意の静観根拠。採否や金融を生成しない。
    """
    s, cfg = book["session"], book["config"]
    birth = SAVED.finite(opportunity["source"]["birth_time"], "出生時計")
    need(birth > 0, "出生正時計")
    strict = 300 * (math.floor(birth / 300) + 1)
    need(math.isfinite(strict) and strict > birth, "strict次枠の有限表現")
    out = {"strict_at": strict, "assigned_at": strict, "deferred": False}
    if cfg["entry_timing"] == "B5Q":
        return out
    equal(cfg["entry_timing"], "B5QD", "実時計本名")
    start, us = SAVED.finite(s["start"], "場開始"), SAVED.finite(cfg["us_open"], "Actual米国開始")
    for at in (start, SAVED.finite(s["us_open"], "場米国開始"), us):
        need(at >= 0 and at % 300 == 0, "B5QDの300秒整列")
    intervals = [[start, start + 1800, "セッション開始30分"]]
    if s["kind"] == "Night":
        need(us > start and us == s["us_open"], "Nightの既知同一米国時計")
        if us <= intervals[0][1]:
            intervals[0][1:] = [max(intervals[0][1], us + 1800), "開始・米国の連続静観"]
        else:
            intervals.append([us, us + 1800, "米国開始30分"])
    else:
        equal(s["kind"], "Day", "場種")
    for begin, end, reason in intervals:
        if begin <= strict < end:
            out.update(assigned_at=300 * math.ceil(end / 300), deferred=True,
                       quiet_start=begin, quiet_end=end, reason=reason)
            break
    return out


def assigned_at(book, opportunity):
    """
    機能: 実時計に基づく期待AssignedAtだけを共通grid規範へ返す。
    引数: book/opportunity(dict)は実Bookと出生。
    返り値: numberは独立再計算した割当時計。保存auditを期待値にしない。
    """
    return assignment_for(book, opportunity)["assigned_at"]


def adapted_code(function, kind):
    """
    機能: 固定関数の時計固有箇所だけを実名APIへパラメータ化する。
    引数: function(function)は固定103又は95、kind(str)はconfig又はgrid。
    返り値: codeは新関数。共通会計/Source/所有/費用/MTMの演算を変更しない。
    """
    tree = ast.parse(textwrap.dedent(inspect.getsource(function)))
    count = Counter()
    for node in ast.walk(tree):
        if kind == "config" and isinstance(node, ast.Dict):
            for i, key in enumerate(node.keys):
                if isinstance(key, ast.Constant) and key.value == "entry_timing" and isinstance(node.values[i], ast.Constant) and node.values[i].value == "B5Q":
                    node.values[i] = ast.parse('GRID_SPACE["key_config"](key)[0]', mode="eval").body
                    count["config"] += 1
        if kind == "grid" and isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name) and node.targets[0].id == "assigned":
            node.value = ast.parse("assigned_at(book, p)", mode="eval").body
            count["assigned"] += 1
        if kind == "grid" and isinstance(node, ast.Compare) and isinstance(node.left, ast.Name) and node.left.id == "timing" and len(node.ops) == 1 and isinstance(node.ops[0], ast.Eq) and isinstance(node.comparators[0], ast.Constant) and node.comparators[0].value == "B5Q":
            node.ops = [ast.In()]
            node.comparators = [ast.Tuple(elts=[ast.Constant("B5Q"), ast.Constant("B5QD")], ctx=ast.Load())]
            count["quiet"] += 1
    equal(dict(count), {"config": 1} if kind == "config" else {"assigned": 1, "quiet": 2}, "固定ASTの変更箇所数")
    space = {}
    exec(compile(ast.fix_missing_locations(tree), str(Path(__file__).resolve()) + ":時計hook", "exec"), space)
    return space[function.__name__].__code__


# ----------------------------------------
# 旧関数の本体を共用し、実Key対応と時計固有のhookだけを独立名前空間へ置く。
GRID_SPACE = dict(vars(GRID))
for _name, _fn in vars(GRID).items():
    if isinstance(_fn, types.FunctionType) and _fn.__module__ == GRID.__name__:
        GRID_SPACE[_name] = types.FunctionType(_fn.__code__, GRID_SPACE, _name, _fn.__defaults__, _fn.__closure__)
GRID_SPACE.update(key_config=grid_config, assigned_at=assigned_at)
GRID_SPACE["verify_grid"] = types.FunctionType(adapted_code(GRID.verify_grid, "grid"), GRID_SPACE)
COMMON = types.SimpleNamespace(**vars(OLD))
COMMON.verify_book = types.FunctionType(adapted_code(OLD.verify_book, "config"), vars(COMMON), argdefs=OLD.verify_book.__defaults__)


def verify_clock(book, audit):
    """
    機能: Source全文とOrdinalへ一対一結合し、quiet以外の時計変更・再採否を拒否する。
    引数: book/audit(dict)は実ActualResultと外部ClockBookAudit。
    返り値: dictは繰越・受理・実Fillを分けた保存件数。全quote再生ではない。
    """
    equal(set(audit), {"timing", "opportunities"}, "時計audit型")
    timing = grid_config(book["key"])[0]
    equal(audit["timing"], timing, "audit時計の本名")
    opportunities = book["entry_opportunities"]
    if timing == "B5Q":
        equal(audit["opportunities"], [], "B5Qへ新auditを混在しない")
    else:
        equal(len(audit["opportunities"]), len(opportunities), "QD全出生の時計audit")
        for p, a in zip(opportunities, audit["opportunities"]):
            expected = {"ordinal": p["ordinal"], "source": p["source"], **assignment_for(book, p)}
            equal(a, expected, "Source全文/Ordinal/元strict/quiet一回割当")
    traces = {g["at"]: g for g in book["grid_traces"]}
    grids = list(traces)
    for p in opportunities:
        equal(p["assigned_at"], assigned_at(book, p), "非quietの恣意的移動禁止")
        next_grid = next((at for at in grids if at >= p["assigned_at"]), None)
        eof = p["reason"] == "EOFで未消費出生機会を失効"
        need(eof == (next_grid is None), "観測枠とEOF失効の切分け")
        if not eof:
            equal(p["evaluated_at"], next_grid, "当該一回採否・後枠再試行なし")
            trace = traces[next_grid]
            equal((p["quote"], p["quote_age_seconds"]), (trace["quote"], trace["quote_age_seconds"]), "失効も含む当gridの実気配")
            at = p["evaluated_at"]
            deadline = min(book["session"]["force_close"], book["config"]["us_open"] - 900) if p["source"]["method"] == "NK225_P164_06" else book["session"]["force_close"]
            conditions = [(at != p["assigned_at"], "割当枠を通過・後の枠へ復活しない"),
                          (at >= deadline, "元手法Force境界以降"), (trace["quiet"], "割当枠が開始30分見送り"),
                          (p["source_state"] == "cancelled", "Native取消済みの出生"),
                          (p["source_state"] == "pending", "割当枠でSource未取得"),
                          (p["source_quantity"] == 0, "割当枠でSource完結済み"),
                          ((p["source_reserved"] or 0) > 0, "割当枠でSource返済予約あり"),
                          (not trace["quote_known"], "割当枠の最新原行の正常気配が必要未知"),
                          (p["available"] == 0, "片側上限に空きなし")]
            reason = next((reason for match, reason in conditions if match), "出生量・Source現在残量・片側余力のminを一度受理")
            equal(p["reason"], reason, "旧優先順の失効/受理理由")
        need(p["consumed"] is True, "最終一回Consumed")
        need(p.get("gate") is None, "107へ未使用技法gateを混在しない")
    entry_fills = {f["order_id"]: f for f in book["fills"] if f["action"] == "new"}
    orders = {o["id"]: o for o in book["orders"]}
    accepted = [p for p in opportunities if p["status"] == "accepted"]
    equal(len({BASE.source_identity(p["source"]) for p in accepted}), len(accepted), "同Source受理の永久lock")
    return {"出生": len(opportunities), "静観繰越": sum(assignment_for(book, p)["deferred"] for p in opportunities),
            "一回失効": sum(p["status"] == "expired" for p in opportunities), "受理出生": len(accepted),
            "受理枚": sum(p["requested"] for p in accepted), "実取得出生": sum(p["entry_order_id"] in entry_fills for p in accepted),
            "実取得枚": sum(f["quantity"] for f in entry_fills.values()),
            "受理後0取得取消": sum(p["entry_order_id"] not in entry_fills and orders[p["entry_order_id"]]["status"] == "cancelled" for p in accepted),
            "割当前の観測保留枠延べ": sum(at < p["assigned_at"] and at >= p["source"]["birth_time"] for p in opportunities for at in grids)}


def verify_book(book, key, width_audit, early_audit, clock_audit, contract, registry=None, full_clock=False):
    """
    機能: 実QD/E名のまま旧106の全所有・費用・Source・MTM・幅検算を呼ぶ。
    引数: book/audits(dict)、key/contract(str)、registry、full_clock(bool)は保存値と範囲。
    返り値: dictは固定共通台帳と時計件数。入力のKey/Config/イベントは書き換えない。
    """
    c = BY_KEY[key]
    fn_space = {**vars(SAVED), "OLD": COMMON, "config_for": config_for, "GRID_SPACE": GRID_SPACE,
                "inner_key": lambda unused: inner_key(key)}
    fn = types.FunctionType(SAVED.verify_book.__code__, fn_space, argdefs=SAVED.verify_book.__defaults__)
    old_policy_key = f"{c['protection_policy']}_C{c['slip_pts']}_D{c['delay_seconds']}"
    checked = fn(book, old_policy_key, width_audit, early_audit, contract, registry, full_clock)
    checked["clock_counts"] = verify_clock(book, clock_audit)
    return checked


def inspect_scene(value, registry=None, full_clock=False, artificial=False):
    """
    機能: 24実名口座と共有公表・時計・旧B12対照の保存範囲を検査する。
    引数: value(dict)はCore107結果、registryは106公表台帳、範囲bool二つ。
    返り値: dictは24keyの検算済み保存台帳。
    """
    need(value["version"] == 1 and value["trial"] == 107 and value["complete"] is True, "107完結")
    for name in ("books", "width_audits", "clock_audits"):
        equal(set(value[name]), set(KEYS), "全24集合:" + name)
    equal(set(value["early_audits"]), set(E_KEYS), "本名BE/QEのE audit8")
    equal(value["configs"], CONFIGS, "実名24設定順")
    need(value["tape_unchanged"] is True and value["source_reexecuted"] is False and value["bank_recomputed"] is False and value["charts_recomputed"] is False and value["cmp_recomputed"] is True, "保存入力再用の責務")
    checked = {}
    for key in KEYS:
        equal(value["books"][key]["session"], value["session"], "24同一場")
        checked[key] = verify_book(value["books"][key], key, value["width_audits"][key], value["early_audits"].get(key), value["clock_audits"][key], value["contract"], registry, full_clock)
        equal([g["at"] for g in value["books"][key]["grid_traces"]], value["grid_times"], "同じ全観測grid")
        a, b = value["width_audits"][key], value["width_audits"][KEYS[0]]
        equal((a["observations"], a["resets"]), (b["observations"], b["resets"]), "全口座の同公表配送")
    equal(len(value["grid_times"]), value["counts"]["grids"], "全grid数")
    proof = value["base_control"]
    equal((proof["kind"], proof["books"], proof["width_audits"], proof["early_audits"], proof["all"], proof["excluded"]),
          ("provided_old106", 12, 12, 4, True, []), "旧106 B側12全文対照")
    equal(proof["history_class"], "artificial" if artificial else "old_saved_70", "旧対照のscope")
    equal(proof["all_point_comparisons"], 0, "Coreの旧対照は最終値・全点対照を偽称しない")
    if registry is not None:
        a = value["width_audits"][KEYS[0]]
        equal((a["observations"], a["resets"]), (registry.observations, registry.resets), "保存公表件数")
        equal(value["counts"], registry.counts, "保存全record件数")
        equal({k: v for k, v in value["public_diagnostics"].items() if k != "numeric_seed_carried"}, registry.diagnostics, "一公表の役割診断")
    return checked


def comparison_pairs():
    """
    機能: 時計差12と同時計内三保護の全対24を明示する。
    引数: なし。
    返り値: list[tuple]は前key・後key・比較区分の36本。
    """
    pairs = []
    groups = [("B0", "Q0", "時計"), ("B1", "Q1", "時計"), ("BE", "QE", "時計"),
              ("B0", "B1", "同時計保護"), ("B0", "BE", "同時計保護"), ("B1", "BE", "同時計保護"),
              ("Q0", "Q1", "同時計保護"), ("Q0", "QE", "同時計保護"), ("Q1", "QE", "同時計保護")]
    for before, after, kind in groups:
        for c in (0, 5):
            for d in (0, 1):
                pairs.append((f"{before}_C{c}_D{d}", f"{after}_C{c}_D{d}", kind))
    return pairs


def compare_scene(checked):
    """
    機能: 同Source全文と実入口の全属性で36本を既存関数へ渡す。
    引数: checked(dict)は保存検算済み24台帳。
    返り値: dictは実現額だけの加法分解。仮想価格を補わない。
    """
    return {after + "対" + before: {"区分": kind, **OLD.compare_positions(checked[before], checked[after])}
            for before, after, kind in comparison_pairs()}


def scene_rows(value, checked, history_class="artificial"):
    """
    機能: 共通保存算術と時計件数を24実名で小型集計する。
    引数: value/checked(dict)、history_class(str)はCore値・検算台帳・履歴。
    返り値: list[dict]は全24場別値。SceneCountsに参加率という未定義欄を要求しない。
    """
    rows = []
    for key, c in BY_KEY.items():
        b = value["books"][key]
        active = sum(p["protection_active"] for p in b["positions"])
        early = sum(p["trigger"] == "early_warning" for p in value["early_audits"].get(key, {}).get("positions", []))
        rows.append({"session": value["session"]["id"], "key": key, "entry_timing": c["entry_timing"],
                     "width_policy": c["protection_policy"], "history_class": history_class,
                     "normal_ld10_activations": active - early, "early_warning_activations": early,
                     "narrowed_positions": sum(p["state"]["narrowed"] for p in value["width_audits"][key]["positions"]),
                     "時計割当": checked[key]["clock_counts"], **OLD.summarize_book(b, checked[key])})
    return rows


def combine(rows):
    """
    機能: 固定103のPF/DD/二旗/参加算術を保ち時計件数だけ追加する。
    引数: rows(list[dict])は場別保存統計。
    返り値: dictは共通集計と別時計件数。
    """
    value = OLD.combine(rows)
    count = Counter()
    for row in rows:
        count.update(row["時計割当"])
    value["時計割当"] = dict(count)
    return value


def aggregate(rows, stage=None):
    """
    機能: 日夜・日別・履歴区分を24冊のまま整理する。
    引数: rows(list[dict])、stage(str|None)は場別値と正式分母指定。
    返り値: tupleは集計と実現診断。USquietと欠測を分母に残す。
    """
    summary, diagnosis = {}, {}
    for key in KEYS:
        selected = [r for r in rows if r["key"] == key]
        need(bool(selected), "24集計の欠落")
        summary[key] = combine(selected)
        if stage is not None:
            equal(summary[key]["活動主表"]["denom"], 7840 if stage == "full70" else 224, "主予定分母")
            equal(summary[key]["活動副表"]["denom"], 7560 if stage == "full70" else 216, "副予定分母")
        dates = sorted({r["session"][:10] for r in selected})
        diagnosis[key] = {"日夜": {k: combine([r for r in selected if r["session"].endswith("_" + k)]) for k in ("Day", "Night")},
                          "日別": [{"開始日": d, **combine([r for r in selected if r["session"].startswith(d)])} for d in dates],
                          "履歴区分": {h: combine([r for r in selected if r["history_class"] == h]) for h in sorted({r["history_class"] for r in selected})}}
    return summary, diagnosis


def save_viewer(value, output, market_path):
    """
    機能: 旧Viewer算術で実Fillだけを107namespaceへ保存する。
    引数: value(dict)、output(Path)、market_path(str)は保存結果・新規先・元板参照。
    返り値: list[dict]はschema1の24資源。HTTP通信は行わない。
    """
    resources, sid = [], value["session"]["id"]
    for key in KEYS:
        name = f"107_{key}_{sid}.trades.jsonl"
        with (output / name).open("x", encoding="utf-8", newline="\n") as stream:
            for row in BASE.viewer_trades(value["books"][key]):
                stream.write(json.dumps(row, ensure_ascii=False, default=BASE.serial, allow_nan=False) + "\n")
        resources.append({"id": f"107_{key}_{sid}", "title": f"見送り繰越と利益保護 {key} {sid}",
                          "symbol": "NK225", "product": "NK225mini", "session": sid, "method_id": key,
                          "point_value": 100, "pnl_format": "trades", "pnl_basis": "net", "pnl_path": name,
                          "market_path": market_path})
    return resources


def validate_completion(condition, complete, manifest, stage, condition_sha):
    """
    機能: 金融成功・同条件24冊・完全場集合をNativeより前に検査する。
    引数: condition/complete/manifest(dict)、stage/condition_sha(str)はRoot固定metadata。
    返り値: list[dict]は対象場の出力参照。独立全quote再生の成功は要求しない。
    """
    need(stage in ("first2", "full70"), "107 stage")
    n = 2 if stage == "first2" else 70
    need(condition["version"] == 1 and condition["trial"] == 107 and condition["fixed"] is True, "107事前条件")
    equal(condition["input_mode"], "recorded_public_106", "既存公表の再読")
    equal(condition["configs"], CONFIGS, "実名24設定")
    ids = [s["id"] for s in manifest["sessions"]]
    need(len(ids) == len(set(ids)) == 70 and ids == sorted(ids), "同70場時系列")
    need(complete["version"] == 1 and complete["trial"] == 107 and complete["stage"] == stage and complete["success"] is True and not complete.get("error"), "107金融成功")
    equal(complete["condition_sha256"], condition_sha, "同条件金融")
    equal((complete["sessions"], complete["books_per_scene"], complete["books"]), (n, 24, n*24), "全24冊の金融完了")
    need(complete["unchanged"] is True and bool(complete["before"]) and complete["before"] == complete["after"], "金融入力code前後不変")
    equal(complete["input_mode"], condition["input_mode"], "同入力方式")
    for flag, expected in (("source_reexecuted", False), ("features_recomputed", False), ("charts_recomputed", False), ("cmp_recomputed", True), ("financial_executed", True)):
        need(complete[flag] is expected, "金融形成scope:" + flag)
    tasks = complete["results"]
    equal([r["session"] for r in tasks], ids[:n], "完全な場集合/順序")
    for row in tasks:
        need(row["books"] == 24 and row["base_control_books"] == 12 and not row.get("error"), "場24/旧B12")
        for name in ("native", "sidecar_header", "sidecar_records"):
            SAVED.ref_shape(row[name])
    return tasks


def prepare(fixed_path, fixed_sha, output):
    """
    機能: 最小固定3FileRefと金融成功を結び、保存出力だけを認証する。
    引数: fixed_path/output(Path)、fixed_sha(str)はRoot事後固定と新規先。
    返り値: tupleは対象task/前指紋/証拠/完了/条件。Raw/CSV/Source通知本文は読まない。
    """
    need(not output.exists() and SAVED.sha_valid(fixed_sha) and digest(fixed_path) == fixed_sha, "Root固定/新規保存先")
    fixed = load(fixed_path)
    need(set(fixed) == {"version", "trial", "fixed", "stage", "condition", "completion", "code"} and fixed["version"] == 1 and fixed["trial"] == 107 and fixed["fixed"] is True, "107最小事後固定")
    before = {str(fixed_path): fixed_sha}
    paths = {k: SAVED.bind_ref(fixed[k], fixed_path.parent, before) for k in ("condition", "completion", "code")}
    equal(paths["code"], Path(__file__).resolve(), "実保存器code固定")
    condition, complete = load(paths["condition"]), load(paths["completion"])
    need(condition["fixed"] is True and condition["trial"] == 107 and complete["success"] is True, "未成功金融をNative前に拒否")
    base = paths["condition"].parent
    refs = {k: SAVED.bind_ref(condition[k], base, before) for k in ("input_manifest", "source_corpus", "prior_completion", "binary", "prior_closure")}
    for ref in condition["stops"] + condition["specifications"]:
        SAVED.bind_ref(ref, base, before)
    manifest, prior = load(refs["input_manifest"]), load(refs["prior_completion"])
    tasks = validate_completion(condition, complete, manifest, fixed["stage"], fixed["condition"]["sha256"])
    need(prior["trial"] == 106 and prior["stage"] == "full70" and prior["success"] is True and prior["sessions"] == 70 and prior["unchanged"] is True and prior["before"] == prior["after"], "完成106の同70入力")
    equal([r["session"] for r in prior["results"]], [s["id"] for s in manifest["sessions"]], "旧公表と新70順序")
    for name, expected in before.items():
        if name not in (str(fixed_path), str(paths["completion"]), str(paths["code"])):
            equal(complete["before"].get(name), expected, "金融使用の固定入力")
    for name, expected in condition["code_sha256"].items():
        p = (base / name).resolve()
        equal(digest(p), expected, "金融固定code")
        equal(complete["before"].get(str(p)), expected, "金融使用code")
        before[str(p)] = expected
    corpus = load(refs["source_corpus"])
    equal([s["session"] for s in corpus["scenes"]], [s["id"] for s in manifest["sessions"]], "SourceCorpusの同70集合")
    data_root = (refs["input_manifest"].parent / manifest["source_root"]).resolve()
    resolved = []
    for i, row in enumerate(tasks):
        r = {k: SAVED.bind_ref(row[k], paths["completion"].parent, before) for k in ("native", "sidecar_header", "sidecar_records")}
        old = prior["results"][i]
        old_native = SAVED.bind_ref(old["native"], refs["prior_completion"].parent, before)
        for k in ("sidecar_header", "sidecar_records"):
            expected_path = (refs["prior_completion"].parent / old[k]["path"]).resolve()
            equal((r[k], row[k]["sha256"]), (expected_path, old[k]["sha256"]), "旧完成公表の原値再用")
        m = manifest["sessions"][i]
        market = (data_root / m["files"]["NK225_book"]["path"]).resolve()
        resolved.append({**row, "resolved": r, "old_native": old_native, "old_native_ref": old["native"], "input": m,
                         "history_class": corpus["scenes"][i]["kind"], "market_path": str(market)})
    if fixed["stage"] == "full70":
        first_path = SAVED.bind_ref(complete["first2"], paths["completion"].parent, before)
        first = load(first_path)
        validate_completion(condition, first, manifest, "first2", fixed["condition"]["sha256"])
        for i in range(2):
            for k in ("native", "sidecar_header", "sidecar_records"):
                equal(first["results"][i][k]["sha256"], tasks[i][k]["sha256"], "同条件first2からfull70の保存値一致")
    for module in (SAVED, SAVED.PREVIOUS, SAVED.PREVIOUS.BASE, OLD, GRID, BASE, SAVED.PUBLIC, SAVED.PUBLIC.pure):
        p = Path(module.__file__).resolve()
        before[str(p)] = digest(p)
    equal(digest(ROOT / CLOCK_SOURCE["path"]), CLOCK_SOURCE["sha256"], "独立再計算の参照時計コード")
    before[str((ROOT / CLOCK_SOURCE["path"]).resolve())] = CLOCK_SOURCE["sha256"]
    proofs = {"Root固定SHA256": fixed_sha, **{k + "SHA256": fixed[k]["sha256"] for k in paths}}
    return resolved, before, proofs, complete, condition


def verify_envelope(value, header, task, completion):
    """
    機能: 新Nativeの読戻し由来を旧完成公表と基準Nativeへ結ぶ。
    引数: value/header/task/completion(dict)は認証済み保存値とmetadata。
    返り値: None。Source/Bankを再形成したと読み替えない。
    """
    equal(value["condition_sha256"], completion["condition_sha256"], "Nativeの107条件")
    equal((value["session"]["id"], value["contract"]), (task["session"], task["input"]["contract"]), "Native場と限月")
    p, replay, provenance = value["input_proof"], value["replay_proof"], value["provenance"]
    equal(p["scene_id"], task["session"], "保存入力の場")
    equal(p["expected_native"]["sha256"], task["old_native_ref"]["sha256"], "旧106参照SHA")
    equal(Path(p["expected_native"]["path"]).resolve(), task["old_native"], "旧106参照path")
    equal(p["tape_canonical_sha256"], value["tape_canonical_sha256"], "同じ固定SourceTape")
    need(p["source_reexecuted"] is False and p["bank_recomputed"] is False and p["financial_executed"] is False, "入力readerの責務")
    need(replay["unchanged"] is True and replay["before"] == replay["after"] and bool(replay["before"]), "保存公表再読の前後不変")
    equal(provenance, {"input_mode": "recorded_public_106", "raw_market_read": False, "source_reexecuted": False, "bank_recomputed": False, "financial_executed": True}, "実金融と再形成なしの区分")
    need(header["version"] == 1 and header["trial"] == 106, "再用元公表Header")
    equal(header["records_gzip_sha256"], task["sidecar_records"]["sha256"], "同じrecords")
    equal((header["header"]["scene"]["id"], header["header"]["scene"]["contract"]), (task["session"], value["contract"]), "公開Headerの同場限月")


def generate(fixed_path, fixed_sha, output):
    """
    機能: Root成功後だけ24保存検算・比較・実Fill形式を新規保存する。
    引数: fixed_path/output(Path)、fixed_sha(str)はRootの事後固定と新規先。
    返り値: dictは完了件数。Raw/新金融/機会損失/HTTPは実行しない。
    """
    tasks, before, proofs, complete, condition = prepare(fixed_path, fixed_sha, output)
    output.mkdir(parents=True)
    rows, resources, controls, public_rows, refs, comparisons = [], [], [], [], [], {}
    for task in tasks:
        v, h = load(task["resolved"]["native"]), load(task["resolved"]["sidecar_header"])
        verify_envelope(v, h, task, complete)
        registry = SAVED.registry_from_records(SAVED.read_records(task["resolved"]["sidecar_records"]), v)
        checked = inspect_scene(v, registry, True)
        old = load(task["old_native"])
        for key, cfg in BY_KEY.items():
            if cfg["entry_timing"] == "B5Q":
                original = f"{cfg['protection_policy']}_C{cfg['slip_pts']}_D{cfg['delay_seconds']}"
                for field in ("books", "width_audits"):
                    equal(v[field][key], old[field][original], "旧106のB12・幅12全文除外0")
                if key in E_KEYS:
                    equal(v["early_audits"][key], old["early_audits"][original], "旧106のB早期4全文除外0")
        proof = v["base_control"]
        equal((Path(proof["reference_path"]).resolve(), proof["reference_sha256"]), (task["old_native"], task["old_native_ref"]["sha256"]), "旧対照実物の指紋")
        controls.append({"session": task["session"], **proof, "保存側で旧106実物を再照合": True})
        rows.extend(scene_rows(v, checked, task["history_class"]))
        resources.extend(save_viewer(v, output, task["market_path"]))
        for name, comp in compare_scene(checked).items():
            comparisons.setdefault(name, {"区分": comp["区分"], "場別": []})["場別"].append({"session": task["session"], **{k: x for k, x in comp.items() if k != "区分"}})
        refs.append({k: task[k] for k in ("session", "native", "sidecar_header", "sidecar_records")})
        public_rows.append({"session": task["session"], **v["public_diagnostics"]})
    summary, diagnosis = aggregate(rows, complete["stage"])
    for item in comparisons.values():
        total = Counter()
        for row in item["場別"]:
            total.update({k: x for k, x in row.items() if k != "session"})
        item["合計"] = dict(total)
        equal(total["全差額"], total["同実入口差額"] + total["取得変更差額"] - total["前のみ実現額"] + total["後のみ実現額"], "全実現差の加法式")
    after = {name: digest(Path(name)) for name in before}
    equal(after, before, "入力code前後不変")
    scope = "実名24の共通保存会計/所有/費用/保存MTM・DD、C/M/早期/幅とquiet一回割当。全quote別engine金融再生ではない"
    result = {"試行": 107, "成功": True, **proofs, "stage": complete["stage"], "scope": scope,
              "場数": len(tasks), "会計数": len(tasks)*24, "主key": list(KEYS),
              "Actor設定": {k: {**cfg, "内Key": inner_key(k), "入口": "Gate無し", "基本保護": "P0", "起動": "E1" if cfg["protection_policy"] == "E1" else "LD10"} for k, cfg in BY_KEY.items()},
              "集計": summary, "実現診断": diagnosis, "場別": rows, "同実入口と実現額差": comparisons,
              "比較数": 36, "時計差比較": 12, "同時計内保護比較": 24, "B側旧106全文対照": controls,
              "一公表単位の役割診断": public_rows, "Native参照": refs, "Viewer形式資源": len(resources), "実Viewer通信": 0,
              "入力codeSHA256前": before, "入力codeSHA256後": after, "前後不変": True,
              "未実施": ["Raw/CSV/Source/Bank再形成", "全quote別engine金融再生", "未参加/退出後価格/機会損失/MFE", "実ViewerAPI"]}
    BASE.write_json(output / "結果.json", result)
    BASE.write_json(output / "一覧.resources.json", {"schema_version": 1, "path_base": "catalog", "resources": resources})
    outputs = {p.name: digest(p) for p in output.iterdir() if p.is_file()}
    BASE.write_json(output / "保存会計の確認.json", {"成功": True, **proofs, "scope": scope, "会計": len(tasks)*24, "資源": len(resources), "不一致数": 0,
                    "入力codeSHA256前": before, "入力codeSHA256後": after, "前後不変": True, "出力SHA256": outputs,
                    "Raw/CSV/Source/金融/HTTP再実行": 0})
    return {"成功": True, "場数": len(tasks), "会計": len(tasks)*24, "実Viewer通信": 0}


def main():
    """
    機能: Root事後固定3参照からだけ107保存を実行する。
    引数: --fixed/--fixed-sha/--outは明示した固定JSON・SHA・新規先。
    返り値: なし。未固定又は金融未成功はNative本文より前に拒否する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixed", type=Path, required=True)
    parser.add_argument("--fixed-sha", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(generate(args.fixed.resolve(), args.fixed_sha, args.out.resolve()), ensure_ascii=False))


if __name__ == "__main__":
    main()
