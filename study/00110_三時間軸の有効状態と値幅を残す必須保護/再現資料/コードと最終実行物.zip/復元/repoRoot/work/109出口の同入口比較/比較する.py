"""109の保存実現取引を同一入口で結び、保護方法だけの差を集計する。"""

from collections import Counter, defaultdict
from datetime import date, datetime, timezone, timedelta
from decimal import Decimal
import argparse
import gzip
import hashlib
import json
from pathlib import Path
import statistics


OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
RESULT = ROOT / 'work/109保存/全70場/結果.json'
RESULT_SHA = '9f413d384b7831f60e0a2a743c3f3017a16d466592c7438e8aca956cd1a54804'
COMPLETE = ROOT / 'work/109市場/全70場/完了.json'
COMPLETE_SHA = '6274447512f129133012029d3c746969d4c5ebef0575dbf9b33cf326faad7c54'
JST = timezone(timedelta(hours=9))


def need(condition, message):
    """機能: 指紋や比較母集団の差を拒否する。

    引数: condition(bool)、message(str)は成立条件と説明。
    返り値: None。不成立ではValueError。
    """
    if not condition:
        raise ValueError(message)


def sha(path):
    """機能: 許可された保存結果/Native/codeの全bytesを同定する。

    引数: path(Path)は既使用70の明示参照。
    返り値: strはSHA256。11/09の本文もhashも読まない。
    """
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def load(path, expected):
    """機能: 先にSHAを認証し、保存JSONをDecimalで読む。

    引数: path(Path)、expected(str)は保存参照と期待SHA。
    返り値: dictは原値。Raw/価格CSV/SourceRecordは読まない。
    """
    need(sha(path) == expected, '入力SHA差:' + str(path))
    opener = gzip.open if path.suffix == '.gz' else open
    with opener(path, 'rt', encoding='utf-8') as stream:
        return json.load(stream, parse_float=Decimal)


def serial(value):
    """機能: 十進数を有限なJSON数値へ保存する。

    引数: value(any)は値。返り値: int/floatはJSON数値。
    """
    if isinstance(value, Decimal):
        need(value.is_finite(), '非有限金額')
        return int(value) if value == value.to_integral_value() else float(value)
    raise TypeError(type(value).__name__)


def outcome(net):
    """機能: 完結玉の実現額を勝/負/同値へ区分する。

    引数: net(number)は実現純額。返り値: strは勝/負/同値。
    """
    return '勝' if net > 0 else '負' if net < 0 else '同値'


def mapping(book):
    """機能: Sourceの明示method/SignalIDで実玉を一意に結ぶ。

    引数: book(dict)は完結保存口座。
    返り値: dictはSourceキー→実玉。文字列を分割しない。
    """
    result = {}
    for position in book['positions']:
        identity = position['source']['method'], position['source']['signal_id']
        need(identity not in result and position['quantity'] == position['reserved'] == 0, 'Source一回性/終端残0')
        result[identity] = position
    return result


def fingerprint(position, orders):
    """機能: 実入口をSource全文と新規要求/実fillの全気配へ結ぶ。

    引数: position/ orders(dict)は実玉と注文写像。
    返り値: dictは政策名を除く入口の厳密値。枚数も省略しない。
    """
    order = orders[position['entry_order_id']]
    return {'source': position['source'], 'source_hold_id': position['source_hold_id'], 'side': position['side'], 'entry_price': position['entry_price'], 'entry_quote': position['entry_quote'], 'quantity': position['initial_quantity'], 'request_time': order['request_time'], 'request_quote': order['request_quote'], 'order_source': order['source']}


def compare(book_a, book_b):
    """機能: 成立した両実戦略を同入口/取得変更/片側参加へ分ける。

    引数: book_a/book_b(dict)は同費用・同入口政策で保護だけ違う実口座。
    返り値: tuple[dict,list]は集計と同入口玉ペア。退出後仮想利益を使わない。
    """
    a, b = mapping(book_a), mapping(book_b)
    orders_a = {o['id']: o for o in book_a['orders']}
    orders_b = {o['id']: o for o in book_b['orders']}
    count = Counter()
    transitions = defaultdict(Counter)
    pairs = []
    for identity in sorted(a.keys() | b.keys()):
        before, after = a.get(identity), b.get(identity)
        if before is None:
            count['後のみ玉'] += 1
            count['後のみ実現円'] += after['realized_net']
            continue
        if after is None:
            count['前のみ玉'] += 1
            count['前のみ実現円'] += before['realized_net']
            continue
        if fingerprint(before, orders_a) != fingerprint(after, orders_b):
            count['取得変更玉'] += 1
            count['取得変更差円'] += after['realized_net'] - before['realized_net']
            continue
        count['同実入口玉'] += 1
        count['同実入口枚'] += before['initial_quantity']
        delta = after['realized_net'] - before['realized_net']
        count['同実入口差円'] += delta
        transition = outcome(before['realized_net']) + '→' + outcome(after['realized_net'])
        item = transitions[transition]
        item['玉'] += 1
        item['前実現円'] += before['realized_net']
        item['後実現円'] += after['realized_net']
        item['差円'] += delta
        if before['realized_net'] > 0 and after['realized_net'] > 0:
            count['両勝で後減益玉'] += delta < 0
            count['両勝で後減益差円'] += min(0, delta)
            count['両勝で後増益玉'] += delta > 0
            count['両勝で後増益差円'] += max(0, delta)
        pairs.append((before, after))
    net_a, net_b = book_a['totals']['net_yen'], book_b['totals']['net_yen']
    need(sum((p['realized_net'] for p in a.values()), Decimal(0)) == net_a and sum((p['realized_net'] for p in b.values()), Decimal(0)) == net_b, '実玉と口座実現額')
    need(net_b - net_a == count['同実入口差円'] + count['取得変更差円'] + count['後のみ実現円'] - count['前のみ実現円'], '両実戦略の実額加法分解')
    values = {k: count[k] for k in ('同実入口玉', '同実入口枚', '同実入口差円', '取得変更玉', '取得変更差円', '前のみ玉', '前のみ実現円', '後のみ玉', '後のみ実現円', '両勝で後減益玉', '両勝で後減益差円', '両勝で後増益玉', '両勝で後増益差円')}
    values.update(前実現円=net_a, 後実現円=net_b, 差円=net_b - net_a, 前勝玉=sum(p['realized_net'] > 0 for p in a.values()), 前負玉=sum(p['realized_net'] < 0 for p in a.values()), 後勝玉=sum(p['realized_net'] > 0 for p in b.values()), 後負玉=sum(p['realized_net'] < 0 for p in b.values()))
    values['勝敗遷移'] = {k: dict(v) for k, v in transitions.items()}
    values['全同実入口'] = not any(values[k] for k in ('取得変更玉', '前のみ玉', '後のみ玉'))
    return values, pairs


def floor_records(audit):
    """機能: 同じ保存stepを重複数えせず列挙する。

    引数: audit(dict)は玉別保護監査。返り値: list[dict]は保存されたstepだけ。
    """
    values = [audit[k] for k in ('activation', 'first_narrow', 'first_floor_hit', 'last_floor_update', 'last_step', 'first_full_reserved_hit') if audit[k] is not None]
    values += [r['step'] for r in audit['requests']]
    unique = {}
    for value in values:
        identity = value['state']['sequence'], value['point']['quote']['index'], value['point']['phase']
        if identity in unique:
            need(value == unique[identity], '同じ保護step識別の値差')
        unique[identity] = value
    return sorted(unique.values(), key=lambda x: x['state']['sequence'])


def floor_cause(step):
    """機能: 起動点の床を費用床/峰−幅/構造床へ独立に分解する。

    引数: step(dict)は初回起動の保存step。
    返り値: strは支配要因。等値は費用床との同率を区別する。
    """
    s, d = step['state'], step['decision']
    minimum, width = s['minimum_floor'], s['width_points']
    trail = s['peak_points'] - width if width is not None else None
    structural = d['structural_floor']
    candidates = [minimum] + ([trail] if trail is not None else []) + ([structural] if structural is not None else [])
    need(s['floor_points'] == max(candidates), '初回起動床は最低床/峰−幅/構造床のmax')
    if minimum == s['floor_points']:
        return '費用床と同率' if trail == minimum or structural == minimum else '費用床が単独支配'
    return '構造床が支配' if structural == s['floor_points'] and (trail is None or structural > trail) else '峰−幅が支配'


def floor_stats(book, audit):
    """機能: 全玉の保存された起動/床hit/要求から初期小益保護を数える。

    引数: book/audit(dict)は金融実玉と新保護監査。
    返り値: tuple[dict,dict]は計数と分布素材。未保存tickやMFEは生成しない。
    """
    positions = {p['id']: p for p in book['positions']}
    counts, samples = Counter(), defaultdict(list)
    counts['実玉'] = len(positions)
    for item in audit['positions']:
        p, initial = positions[item['position_id']], item['initial']
        counts['V_entry代替'] += initial['entry_v_fallback']
        samples['Hpt'].append(initial['threshold_points'])
        samples['最低費用床pt'].append(initial['minimum_floor'])
        activation = item['activation']
        if activation is None:
            counts['未起動玉'] += 1
            counts['未起動実現円'] += p['realized_net']
            continue
        counts['起動玉'] += 1
        counts['起動実現円'] += p['realized_net']
        counts['起動後赤字玉'] += p['realized_net'] < 0
        counts['起動床:' + floor_cause(activation)] += 1
        state = activation['state']
        samples['起動peakpt'].append(state['peak_points'])
        samples['起動床pt'].append(state['floor_points'])
        if state['width_points'] is not None:
            samples['起動幅pt'].append(state['width_points'])
            samples['起動峰−幅pt'].append(state['peak_points'] - state['width_points'])
        saved = [v for v in floor_records(item) if v['state']['active']]
        counts['起動保存点'] += len(saved)
        counts['保存点で床が最低床を上回った玉'] += any(v['state']['floor_points'] > v['state']['minimum_floor'] for v in saved)
        counts['保存点で峰−幅が最低床を上回った玉'] += any(v['state']['width_points'] is not None and v['state']['peak_points'] - v['state']['width_points'] > v['state']['minimum_floor'] for v in saved)
        counts['最終床が最低床の玉'] += item['last']['floor_points'] == item['last']['minimum_floor']
        counts['狭幅玉'] += item['last']['narrowed']
        if item['first_floor_hit'] is not None:
            hit = item['first_floor_hit']
            counts['床hit玉'] += 1
            counts['初回床hitが最低床の玉'] += hit['state']['floor_points'] == hit['state']['minimum_floor']
            counts['初回床hit時全予約玉'] += hit['point']['reserved'] == hit['point']['quantity']
            samples['起動から初回床hit秒'].append(hit['point']['quote']['time'] - activation['point']['quote']['time'])
        counts['自己保護要求数'] += len(item['requests'])
        if item['requests']:
            request = item['requests'][0]
            step = request['step']
            counts['自己保護要求玉'] += 1
            counts['初回自己要求が最低床の玉'] += step['state']['floor_points'] == step['state']['minimum_floor']
            counts['初回自己要求にSource等先行予約あり玉'] += request['reserved_before'] > 0
            samples['起動から初回自己要求秒'].append(step['point']['quote']['time'] - activation['point']['quote']['time'])
    return dict(counts), dict(samples)


def merge(rows):
    """機能: 実現差と勝敗遷移を重複なく加算する。

    引数: rows(list[dict])は同一比較の場別値。返り値: dictは期間集計。
    """
    numeric = Counter()
    transitions = defaultdict(Counter)
    for row in rows:
        for key, value in row.items():
            if type(value) in (int, float, Decimal) and key not in ('cost', 'delay'):
                numeric[key] += value
        for key, value in row['勝敗遷移'].items():
            transitions[key].update(value)
    result = dict(numeric)
    result['全同実入口'] = all(row['全同実入口'] for row in rows)
    result['勝敗遷移'] = {k: dict(v) for k, v in transitions.items()}
    return result


def main():
    """機能: SHA認証した既使用70だけから同入口差と床診断を新規保存する。

    引数: なし。返り値: None。入力/停止/技法を変更しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=OWN / '解析.json')
    args = parser.parse_args()
    output = args.out.resolve()
    need(output.parent == OWN, '解析先は所有workだけ')
    need(not output.exists(), '解析結果は上書きしない')
    saved = load(RESULT, RESULT_SHA)
    complete = load(COMPLETE, COMPLETE_SHA)
    need(saved['成功'] and saved['stage'] == 'full70' and saved['場数'] == 70 and saved['会計数'] == 1680 and saved['金融完了SHA256'] == COMPLETE_SHA, '109保存成功70/24')
    need(complete['success'] and complete['stage'] == 'full70' and complete['sessions'] == 70 and complete['books'] == 1680 and complete['condition_sha256'] == saved['金融条件SHA256'], '同条件金融成功')
    refs = saved['Native参照']
    need([r['session'] for r in refs] == [r['session'] for r in complete['results']] and len(refs) == 70, '全70参照の同体')
    need(all('2026-09-21' <= r['session'][:10] <= '2026-11-06' for r in refs), '既使用70だけ、11/09禁止')
    inputs = {str(RESULT): RESULT_SHA, str(COMPLETE): COMPLETE_SHA}
    comparisons, floors = defaultdict(list), defaultdict(Counter)
    floor_samples = defaultdict(lambda: defaultdict(list))
    november = []
    for index, refrow in enumerate(refs):
        ref = refrow['native']
        need(ref == complete['results'][index]['native'], '成功完了とのNative参照同体')
        path = Path(ref['path'])
        native = load(path, ref['sha256'])
        inputs[str(path)] = ref['sha256']
        need(native['trial'] == 109 and native['complete'] and native['session']['id'] == refrow['session'] and native['condition_sha256'] == saved['金融条件SHA256'], 'Nativeの場/条件/成功')
        for entry in ('entry_E0', 'entry_E1'):
            for cost in (0, 5):
                for delay in (0, 1):
                    for before, after in (('G0', 'G1'), ('G0', 'G2'), ('G1', 'G2')):
                        ka, kb = f'{entry}_{before}_C{cost}_D{delay}', f'{entry}_{after}_C{cost}_D{delay}'
                        values, pairs = compare(native['books'][ka], native['books'][kb])
                        label = f'{entry}_{before}対{after}_C{cost}_D{delay}'
                        comparisons[label].append({'session': refrow['session'], 'entry': entry, 'before': before, 'after': after, 'cost': cost, 'delay': delay, **values})
                        if refrow['session'].startswith('2026-11-06'):
                            for a, b in pairs:
                                november.append({'比較': label, 'session': refrow['session'], 'Source手法': a['source']['method'], 'SourceSignalID': a['source']['signal_id'], '方向': a['side'], '枚数': a['initial_quantity'], '新規時刻': datetime.fromtimestamp(float(a['entry_quote']['time']), JST).isoformat(), '新規価格': a['entry_price'], '前決済時刻': datetime.fromtimestamp(float(a['closed_quote']['time']), JST).isoformat(), '後決済時刻': datetime.fromtimestamp(float(b['closed_quote']['time']), JST).isoformat(), '前実現円': a['realized_net'], '後実現円': b['realized_net'], '差円': b['realized_net'] - a['realized_net'], '前後勝敗': outcome(a['realized_net']) + '→' + outcome(b['realized_net']), '前初正益': a['marks']['first_unit_positive'] is not None, '後初正益': b['marks']['first_unit_positive'] is not None, '前保護起動': a['protection_active'], '後保護起動': b['protection_active']})
                    for policy in ('G1', 'G2'):
                        key = f'{entry}_{policy}_C{cost}_D{delay}'
                        counts, samples = floor_stats(native['books'][key], native['composite_audits'][key])
                        floors[key].update(counts)
                        for name, vals in samples.items():
                            floor_samples[key][name].extend(vals)
        print(refrow['session'], '保存比較成功', flush=True)
    summaries, sessions, weekly, daynight = {}, [], {}, {}
    for label, rows in comparisons.items():
        summaries[label] = merge(rows)
        sessions.extend({'比較': label, **row} for row in rows)
        daynight[label] = {kind: merge([r for r in rows if r['session'].endswith('_' + kind)]) for kind in ('Day', 'Night')}
        weeks = sorted({date.fromisoformat(r['session'][:10]).isocalendar()[:2] for r in rows})
        weekly[label] = {f'{year}-W{week:02d}': merge([r for r in rows if date.fromisoformat(r['session'][:10]).isocalendar()[:2] == (year, week)]) for year, week in weeks}
    distributions = {key: {name: {'n': len(vals), 'min': min(vals), 'median': statistics.median(vals), 'max': max(vals)} for name, vals in groups.items() if vals} for key, groups in floor_samples.items()}
    need(all(sha(Path(path)) == expected for path, expected in inputs.items()), '結果/70Nativeの前後同体')
    for key, rows in comparisons.items():
        entry, before, after = rows[0]['entry'], rows[0]['before'], rows[0]['after']
        cost, delay = rows[0]['cost'], rows[0]['delay']
        need(summaries[key]['前実現円'] == saved['集計'][f'{entry}_{before}_C{cost}_D{delay}']['net_yen'] and summaries[key]['後実現円'] == saved['集計'][f'{entry}_{after}_C{cost}_D{delay}']['net_yen'], '保存24集計と全玉実現額の一致')
    result = {'成功': True, 'scope': '同費用の両実戦略で成立した入口の厳密比較と保存保護点の床診断。実市場再走/機会損失/退出後仮想利益/MFE回収率なし', '入力SHA256': inputs, '前後不変': True, '同入口比較数': len(summaries), '全比較で入口同体': all(v['全同実入口'] for v in summaries.values()), '全条件': summaries, '日夜': daynight, '週別': weekly, '場別': sessions, '保護床': {key: {'計数': dict(value), '保存値分布': distributions[key]} for key, value in floors.items()}, '11月06日の同実入口': november, '限界': ['同Source/費用感度を独立標本と扱わない', '保存された初回/極値/要求等のstepだけを数え、全tick経路を復元しない', '当初利益が保護後に減った額ではなく、成立した両戦略の実現差だけを比較', '幅や閾値を変更せず、次案を検証した結果とはしない', '既使用70の探索であり未見安定性/採用を証明しない']}
    with output.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, default=serial, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'成功': True, '解析': str(output), 'SHA256': sha(output), '全比較で入口同体': result['全比較で入口同体'], '場別比較': len(sessions), '11月06日比較玉': len(november)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
