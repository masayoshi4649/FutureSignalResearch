"""同入口判定の省略禁止と初回床の境界を人工値で確認する。"""

import copy
import unittest

import 比較する as A


def book():
    """機能: 実現会計が完結した最小人工玉を作る。

    引数: なし。返り値: dictはSourceと新規気配を持つ人工保存値。
    """
    source = {'method': '人工', 'signal_id': '出生1', 'birth_quantity': 2}
    quote = {'time': 100, 'index': 2, 'source_line': 3, 'bid': 100, 'ask': 105}
    position = {'id': '政策名付き玉', 'source': source, 'source_hold_id': '源玉', 'side': 1, 'entry_price': 105, 'entry_quote': quote, 'entry_order_id': '新規', 'initial_quantity': 2, 'quantity': 0, 'reserved': 0, 'realized_net': 100}
    return {'positions': [position], 'orders': [{'id': '新規', 'source': source, 'request_time': 99, 'request_quote': quote}], 'totals': {'net_yen': 100}}


class 比較検査(unittest.TestCase):
    """省略しやすい入口属性と床支配の境界を検査する。"""

    def test_政策名だけの玉ID差は許し実入口差は分ける(self):
        """機能: 政策名入りIDを比較根拠にせず気配/価格/枚数/Source変更を検出する。

        引数: self(比較検査)。返り値: None。
        """
        a, b = book(), book()
        b['positions'][0]['id'] = '別政策名付き玉'
        self.assertTrue(A.compare(a, b)[0]['全同実入口'])
        for field, value in (('initial_quantity', 1), ('entry_price', 110), ('source_hold_id', '別源玉'), ('side', -1)):
            changed = copy.deepcopy(b)
            changed['positions'][0][field] = value
            self.assertEqual(A.compare(a, changed)[0]['取得変更玉'], 1)
        changed = copy.deepcopy(b)
        changed['positions'][0]['entry_quote']['source_line'] += 1
        self.assertFalse(A.compare(a, changed)[0]['全同実入口'])

    def test_同Source重複を拒否する(self):
        """機能: 同じ出生へ複数玉が混入した比較を拒否する。

        引数: self(比較検査)。返り値: None。
        """
        data = book()
        data['positions'].append(copy.deepcopy(data['positions'][0]))
        with self.assertRaises(ValueError):
            A.mapping(data)

    def test_初回床の単独と同率を区別する(self):
        """機能: 最低費用床/峰−幅/構造床のmaxと同率を別に数える。

        引数: self(比較検査)。返り値: None。
        """
        step = {'state': {'minimum_floor': 10, 'width_points': 200, 'peak_points': 30, 'floor_points': 10}, 'decision': {'structural_floor': None}}
        self.assertEqual(A.floor_cause(step), '費用床が単独支配')
        step['state']['width_points'] = 20
        self.assertEqual(A.floor_cause(step), '費用床と同率')
        step['state']['peak_points'] = 60
        step['state']['floor_points'] = 40
        self.assertEqual(A.floor_cause(step), '峰−幅が支配')
        step['decision']['structural_floor'] = 50
        step['state']['floor_points'] = 50
        self.assertEqual(A.floor_cause(step), '構造床が支配')


if __name__ == '__main__':
    unittest.main(verbosity=2)
