"""三時間軸Coreの人工検査と依存不変を確認し、停止を新規保存する。"""
from __future__ import annotations

import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess

OWN = Path(__file__).resolve().parent
ROOT = OWN.parents[1]
OLD = ROOT / 'work/108静観短縮の市場接続準備'
STOPS = {
    'work/108静観短縮の市場接続準備/停止.json': '24bb58aabb761e85b7484511108cbb06b8d9feabd8588f1bab81ba717943040d',
    'work/一定利益と三時間軸の保護会計/停止.json': '567b0bc6354b5d3d47d57f1cc3f91335a661d359ea4c81ae02f83653f3970687',
    'work/一定利益と費用床の純状態案/停止.json': '1d58cebc88a08011632a4ac1c036dcc71ae8d1bf8dc85938b3f2b344ad85a24c',
    'work/三時間軸の公開器/停止.json': 'b6b1a326cc98f67e13ec1962a19bac001eda743880b74a13066a2307c5944895',
    'work/三時間軸の入口判定/停止.json': '834aedc70a31d5f0d7e2bee9ae6fc9d22d7b3ea726924fed791b2dfec7b283f9',
}


def sha(path: Path) -> str:
    """
    機能: 指定したコード又は人工成果物の本文を同定する。
    引数: path (Path) は明示された非市場ファイル。
    返り値: str はSHA256。市場ディレクトリは列挙しない。
    """
    with path.open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def relative(path: Path) -> str:
    """
    機能: 所有root内の出典を相対pathへ統一する。
    引数: path (Path) はworkspace内のファイル。
    返り値: str はスラッシュ区切りのpath。
    """
    return path.resolve().relative_to(ROOT).as_posix()


def write_new(path: Path, value: dict) -> None:
    """
    機能: 上書きせず新しい停止・確認資料を保存する。
    引数: path (Path)、value (dict) は出力先と内容。
    返り値: None。既存停止があれば失敗する。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(value, handle, ensure_ascii=False, indent=2)
        handle.write('\n')


def run(argv: list[str], env: dict | None = None) -> dict:
    """
    機能: 市場口を呼ばずGo検査又はコードmetadata取得を実行する。
    引数: argv (list[str])、env (dict|None) は命令と環境。
    返り値: dict は終了codeと出力。失敗を停止成功へ補わない。
    """
    result = subprocess.run(argv, cwd=OWN, env=env, capture_output=True, text=True, encoding='utf-8', check=False)
    value = {'argv': argv, 'cwd': str(OWN), 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}
    assert result.returncode == 0, value
    return value


def module_codes() -> dict[str, str]:
    """
    機能: Goが実際に参照するworkspace内のソース・module定義を同定する。
    引数: なし。go listのcode metadataだけを使う。
    返り値: dict[str,str] は各pathとSHA256。CSV/Raw/Nativeを開かない。
    """
    raw = run(['go', 'list', '-deps', '-test', '-json', './...'])['stdout']
    decoder = json.JSONDecoder()
    position = 0
    paths = set()
    while position < len(raw):
        while position < len(raw) and raw[position].isspace():
            position += 1
        if position == len(raw):
            break
        package, position = decoder.raw_decode(raw, position)
        directory = Path(package.get('Dir', '.')).resolve()
        if not directory.is_relative_to(ROOT):
            continue
        for field in ('GoFiles', 'CgoFiles', 'TestGoFiles', 'XTestGoFiles'):
            for name in package.get(field, []):
                path = (directory / name).resolve()
                if path.is_file() and path.is_relative_to(ROOT):
                    paths.add(path)
        module = package.get('Module') or {}
        replacement = module.get('Replace') or module
        directory_value = replacement.get('Dir')
        if directory_value:
            for name in ('go.mod', 'go.sum'):
                path = (Path(directory_value) / name).resolve()
                if path.is_relative_to(ROOT) and path.is_file():
                    paths.add(path)
    return {relative(path): sha(path) for path in sorted(paths)}


def protected() -> dict[str, str]:
    """
    機能: 停止指紋と各停止が宣言した所有コードを確認する。
    引数: なし。明示した停止と人工108の2件だけを参照する。
    返り値: dict[str,str] は前後不変確認する指紋台帳。
    """
    values = {}
    for name, expected in STOPS.items():
        path = ROOT / name
        assert sha(path) == expected, name
        values[name] = expected
        stopped = json.loads(path.read_text(encoding='utf-8-sig'))
        assert stopped['成功'] is True
        for field in ('所有コードSHA256', 'コードSHA256後', '直接依存SHA256'):
            for label, wanted in stopped.get(field, {}).items():
                if not isinstance(wanted, str) or len(wanted) != 64:
                    continue
                item = Path(label)
                if not item.is_absolute():
                    item = ROOT / item
                    if not item.is_file():
                        item = path.parent / label
                assert item.is_file() and item.resolve().is_relative_to(ROOT), label
                assert sha(item) == wanted, label
                values[relative(item)] = wanted
    for side in (1, -1):
        path = OLD / '人工_停止版' / f'方向{side}.json'
        values[relative(path)] = sha(path)
    values.update(module_codes())
    return values


def patch() -> str:
    """
    機能: 旧108からの派生差を監査用patchへまとめる。
    引数: なし。旧新のコードだけを読む。
    返り値: str はunified diff。旧ファイルへ書かない。
    """
    output = []
    for name in ('core.go', 'feed.go', 'reference.go', 'core_test.go', 'bridge.go', 'synthetic_test.go', 'source_fixture_test.go', 'go.mod', 'go.sum'):
        old = OLD / name
        new = OWN / name
        before = old.read_text(encoding='utf-8').splitlines(keepends=True) if old.is_file() else []
        after = new.read_text(encoding='utf-8').splitlines(keepends=True)
        output.extend(difflib.unified_diff(before, after, fromfile=relative(old), tofile=relative(new)))
    return ''.join(output)


def main() -> None:
    """
    機能: 買売24非ゼロ人工・保存/fresh対照・時計とEOFを確認して停止する。
    引数: なし。市場CLI・実70・未使用11/09の本文は呼ばない。
    返り値: None。確認JSON、人工6件、由来、停止を新規に保存する。
    """
    assert not (OWN / '停止.json').exists()
    assert not (OWN / '人工_停止版').exists()
    before = protected()
    (OWN / '差分.patch').write_text(patch(), encoding='utf-8', newline='\n')
    own_names = ['core.go', 'feed.go', 'reference.go', 'bridge.go', 'core_test.go', 'synthetic_test.go', 'source_fixture_test.go', 'go.mod', 'go.sum', 'README.md', '仕様.md', '検査と停止を記録する.py', '差分.patch']
    owned_before = {relative(OWN / name): sha(OWN / name) for name in own_names}
    environment = os.environ.copy()
    environment['RUNTIME109_EXPORT'] = str(OWN / '人工_停止版')
    checks = [run(['go', 'test', '-json', '-count=1', '-cover', './...'], environment), run(['go', 'vet', './...']), run(['go', 'build', './...'])]
    tests = [json.loads(line) for line in checks[0]['stdout'].splitlines() if line.strip()]
    assert not any(item['Action'] == 'fail' for item in tests)
    passed = [item['Test'] for item in tests if item['Action'] == 'pass' and 'Test' in item]
    coverage = [item['Output'].strip() for item in tests if 'Output' in item and 'coverage:' in item['Output']]
    after = {name: sha(ROOT / name) for name in before}
    assert before == after
    assert owned_before == {name: sha(ROOT / name) for name in owned_before}
    artificial = {relative(path): sha(path) for path in sorted((OWN / '人工_停止版').glob('*.json'))}
    assert len(artificial) == 6
    outputs = []
    for side in (1, -1):
        for mode in ('fresh', 'saved'):
            path = OWN / '人工_停止版' / f'方向{side}_{mode}.json'
            value = json.loads(path.read_text(encoding='utf-8'))['output']
            assert value['complete'] is True and len(value['books']) == 24
            assert value['baseline']['comparisons'] == 4 and value['baseline']['all'] is True
            assert len(value['shadow_books']) == (4 if mode == 'fresh' else 0)
            if mode == 'saved':
                reference = value['prior_reference']
                assert sha(Path(reference['reference_path'])) == reference['reference_sha256']
            outputs.append({'方向': side, '分岐': mode, 'path': relative(path), 'sha256': sha(path), 'Main': 24, '対照': 4, '全非ゼロと残量0': True})
    confirmation = {'成功': True, 'checks': checks, '主test': sum('/' not in name for name in passed), 'subtest含む全test': len(passed), 'coverage': coverage, '市場実行': 0}
    write_new(OWN / '検査/Go確認.json', confirmation)
    write_new(OWN / '由来.json', {'成功': True, '旧108派生': relative(OLD), 'Source通知': '人工手製。自然Source手法の成績ではない', '依存前後不変': True, '直接停止SHA256': STOPS, '照合コード等の前SHA256': before, '後SHA256': after, '人工出力': outputs, '市場本文読込と金融実行': 0})
    owned_before[relative(OWN / '由来.json')] = sha(OWN / '由来.json')
    version = run(['go', 'version'])['stdout'].strip()
    stopped = {
        '成功': True, '停止': True, 'UTC': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'module': 'github.com/masayoshi4649/SessionTradeExecuter/threeguardruntime109', 'package': 'threeguardruntime109',
        '範囲': '人工。Main24/保存参照/未使用分岐4shadow/時計/EOF。市場金融未実行',
        '所有コードSHA256': owned_before, '直接停止SHA256': STOPS, '依存前後不変': True, 'コード等の指紋件数': len(before),
        'Go版': version, '主test': confirmation['主test'], 'subtest含む全test': len(passed), 'coverage': coverage, 'vet_exit': 0, 'build_exit': 0,
        'Go確認SHA256': sha(OWN / '検査/Go確認.json'), '人工型SHA256': artificial,
        '全24非ゼロ': {'買': True, '売': True, '保存参照': True, '独立fresh四対照': True, '指標直書き': False, '純Entryモック許可': False, 'BBO': '5pt格子'},
        '旧Q0比較': '四費用のBook/Width/Clock全JSON。旧QE Early4は保存保持だけ',
        'ClockModel': 'csv_end_plus60_at_record_scheduler', '真の受信時計検証': False,
        '数値種': 'Record逐次とEOF一括のInfo同体。配送監査同体の意味ではない',
        '市場本文読込': 0, '市場金融実行': 0, '実70市場接続': 0, '未使用11月09本文未読': True,
        '旧107108変更': 0, 'Source再実行': 0, '旧30市場金融再実行': 0,
        '未実施': ['実70市場接続と損益/参加率', '11/09未使用場の保留確認', '採用又は研究目標達成'],
    }
    write_new(OWN / '停止.json', stopped)
    print(json.dumps({'成功': True, '停止SHA256': sha(OWN / '停止.json'), '主test': confirmation['主test'], '全test': len(passed), 'coverage': coverage, '依存指紋': len(before), '人工出力': outputs}, ensure_ascii=False))


if __name__ == '__main__':
    main()
