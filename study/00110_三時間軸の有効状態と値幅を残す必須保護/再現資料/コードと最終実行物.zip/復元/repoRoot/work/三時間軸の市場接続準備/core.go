// Package threeguardruntime109 は固定Source/Recordと新しい純公開器を24の独立会計へ結びます。
package threeguardruntime109

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"reflect"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	oldtype "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	finance "github.com/masayoshi4649/SessionTradeExecuter/miniprofitthreeproposal"
	oldfinance "github.com/masayoshi4649/SessionTradeExecuter/miniquietlength108"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloorproposal"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
	delivery "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
	entry "github.com/masayoshi4649/SessionTradeExecuter/threeentry"
	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

type Config struct {
	EntryPolicy  finance.CompositeEntryPolicy `json:"entry_policy"`
	Policy       finance.CompositeProtection  `json:"protection_policy"`
	Slip         float64                      `json:"slip_pts"`
	Delay        int                          `json:"delay_seconds"`
	QuietSeconds int                          `json:"quiet_seconds"`
}

// PublicationInput はCSV本文を開く外周から渡す指紋付き値と直前場の数値種です。
type PublicationInput struct {
	Session  frame.Session    `json:"session"`
	Children []frame.ChildBar `json:"children"`
	Seed     *frame.Seed      `json:"-"`
}

// Control は保存旧108又は未使用場の独立4対照という二つの事前分岐です。
type Control struct {
	Kind          string                     `json:"kind"`
	HistoryClass  string                     `json:"history_class"`
	ReferencePath string                     `json:"reference_path"`
	ReferenceSHA  string                     `json:"reference_sha256"`
	Session       finance.Session            `json:"session"`
	Contract      string                     `json:"contract"`
	TapeSHA       string                     `json:"tape_canonical_sha256"`
	QuietSeconds  int                        `json:"quiet_seconds"`
	Books         map[string]json.RawMessage `json:"-"`
	WidthAudits   map[string]json.RawMessage `json:"-"`
	ClockAudits   map[string]json.RawMessage `json:"-"`
	EarlyAudits   map[string]json.RawMessage `json:"-"`
}

type Counts struct {
	Records      int `json:"records"`
	Quotes       int `json:"quotes"`
	Forces       int `json:"forces"`
	Grids        int `json:"grids"`
	Publications int `json:"publications"`
	Three        int `json:"three_publications"`
	Resets       int `json:"resets"`
	RawBoards    int `json:"raw_boards"`
}
type PublicRoleCounts struct {
	MKnown int `json:"M_known"`
	MPass  int `json:"M_pass"`
	PKnown int `json:"P_known"`
	PPass  int `json:"P_pass"`
}
type PublicDiagnostics struct {
	New3               int              `json:"new_three"`
	CKnown             int              `json:"C_known"`
	CPass              int              `json:"C_pass"`
	Buy                PublicRoleCounts `json:"buy"`
	Sell               PublicRoleCounts `json:"sell"`
	NumericSeedCarried bool             `json:"numeric_seed_carried"`
}

type ReferenceProof struct {
	Kind          string            `json:"kind"`
	HistoryClass  string            `json:"history_class"`
	QuietSeconds  int               `json:"quiet_seconds"`
	Books         int               `json:"books"`
	WidthAudits   int               `json:"width_audits"`
	ClockAudits   int               `json:"clock_audits"`
	EarlyAudits   int               `json:"early_audits"`
	BookSHA       map[string]string `json:"book_full_json_sha256"`
	WidthSHA      map[string]string `json:"width_full_json_sha256"`
	ClockSHA      map[string]string `json:"clock_full_json_sha256"`
	EarlySHA      map[string]string `json:"early_full_json_sha256"`
	ReferencePath string            `json:"reference_path"`
	ReferenceSHA  string            `json:"reference_sha256"`
	TapeSHA       string            `json:"tape_canonical_sha256"`
	Scope         string            `json:"scope"`
}

type BaselineProof struct {
	Mode        string          `json:"mode"`
	Comparisons int             `json:"comparisons"`
	Books       map[string]bool `json:"books_equal"`
	Widths      map[string]bool `json:"width_audits_equal"`
	Clocks      map[string]bool `json:"clock_audits_equal"`
	All         bool            `json:"all"`
	Scope       string          `json:"scope"`
}

type EntryAudit struct {
	Policy      finance.CompositeEntryPolicy `json:"policy"`
	Calls       int                          `json:"calls"`
	Candidates  int                          `json:"candidates"`
	Allowed     int                          `json:"allowed"`
	Unknown     int                          `json:"unknown"`
	Conflicts   int                          `json:"conflicts"`
	FinalState  entry.StateView              `json:"final_state"`
	Assessments []entry.BatchAssessment      `json:"nonempty_batches"`
}

type PublicationAudit struct {
	ClockModel                string          `json:"clock_model"`
	TriggerLaterRecords       int             `json:"trigger_later_records"`
	MaximumTriggerLeadSeconds float64         `json:"maximum_trigger_lead_seconds"`
	Session                   frame.Session   `json:"session"`
	ChildrenSHA               string          `json:"children_sha256"`
	Children                  int             `json:"children"`
	InputSeed                 *frame.SeedInfo `json:"input_seed"`
	EndSeed                   frame.SeedInfo  `json:"end_seed"`
	Counts                    map[int]int     `json:"frames"`
	PriceKnown                map[int]int     `json:"price_known"`
	VolumeKnown               map[int]int     `json:"volume_known"`
	ChainSHA                  string          `json:"chain_sha256"`
	LastSnapshot              frame.Snapshot  `json:"last_snapshot"`
	InputsUnchanged           bool            `json:"inputs_unchanged"`
	PolicyEOFRedacted         bool            `json:"policy_eof_redacted"`
}

type ProtectionAudit struct {
	Publications int                            `json:"publications"`
	VKnown       int                            `json:"V_known"`
	VUnknown     int                            `json:"V_unknown"`
	Resets       int                            `json:"resets"`
	ChainSHA     string                         `json:"chain_sha256"`
	Latest       *finance.ProtectionObservation `json:"latest"`
}

// Result はMain24と未使用場でのみ使う検査shadow4を明確に分離します。
type Result struct {
	Version               int                                  `json:"version"`
	Trial                 int                                  `json:"trial"`
	Scope                 string                               `json:"scope"`
	Session               finance.Session                      `json:"session"`
	Contract              string                               `json:"contract"`
	Configs               []Config                             `json:"configs"`
	Books                 map[string]finance.ActualResult      `json:"books"`
	WidthAudits           map[string]finance.WidthBookAudit    `json:"width_audits"`
	ClockAudits           map[string]finance.ClockBookAudit    `json:"clock_audits"`
	CompositeAudits       map[string]finance.CompositeAudit    `json:"composite_audits"`
	EntryAudits           map[string]EntryAudit                `json:"entry_audits"`
	ShadowBooks           map[string]oldfinance.ActualResult   `json:"shadow_books"`
	ShadowWidthAudits     map[string]oldfinance.WidthBookAudit `json:"shadow_width_audits"`
	ShadowClockAudits     map[string]oldfinance.ClockBookAudit `json:"shadow_clock_audits"`
	Counts                Counts                               `json:"counts"`
	PublicDiagnostics     PublicDiagnostics                    `json:"public_diagnostics"`
	GridTimes             []float64                            `json:"grid_times"`
	SkippedGrids          []float64                            `json:"skipped_grids"`
	PriorReference        ReferenceProof                       `json:"prior_reference"`
	Baseline              BaselineProof                        `json:"baseline"`
	PublicationAudit      PublicationAudit                     `json:"publication_audit"`
	ProtectionAudit       ProtectionAudit                      `json:"protection_audit"`
	TapeSHA               string                               `json:"tape_canonical_sha256"`
	TapeUnchanged         bool                                 `json:"tape_unchanged"`
	SourceReexecuted      bool                                 `json:"source_reexecuted"`
	ChartRecomputed       bool                                 `json:"charts_recomputed"`
	BankRecomputed        bool                                 `json:"bank_recomputed"`
	CMPRecomputed         bool                                 `json:"cmp_recomputed"`
	EntryCandleRecomputed bool                                 `json:"entry_candle_recomputed"`
	Complete              bool                                 `json:"complete"`
}

type Core struct {
	input                    tape.Tape
	contract, scope, tapeSHA string
	control                  Control
	priorDigest              string
	priorProof               ReferenceProof
	configs                  []Config
	actors                   []*finance.ActualBook
	shadows                  []*oldfinance.ActualBook
	pipeline                 *delivery.Pipeline
	cursor                   int
	last                     map[string]int64
	counts                   Counts
	publicStats              PublicDiagnostics
	lastAt                   float64
	haveAt, rawAt            bool
	rawAll                   map[string]int64
	pendingReset             map[string]chart.Quote
	preRank                  int
	grids                    []float64
	afterEOF                 int
	eof                      bool
	failed                   error
	finished, complete       bool
	pubInput                 PublicationInput
	pubBank                  *frame.Bank
	pubAudit                 PublicationAudit
	nextSeed                 frame.Seed
	entryStates              []entry.EntryState
	entryAudits              []EntryAudit
	guardBars                []guard.Bar
	protectAudit             ProtectionAudit
}

// Configurations は入口2×保護3×費用2×遅延2のMain24だけを返します。
//
// 引数: なし。
// 返り値: []Configはquiet1200固定の順序です。検査shadowは含めません。
func Configurations() []Config {
	out := []Config{}
	for _, e := range []finance.CompositeEntryPolicy{finance.EntryE0, finance.EntryE1} {
		for _, g := range []finance.CompositeProtection{finance.ProtectG0, finance.ProtectG1, finance.ProtectG2} {
			for _, c := range []float64{0, 5} {
				for _, d := range []int{0, 1} {
					out = append(out, Config{e, g, c, d, 1200})
				}
			}
		}
	}
	return out
}

// Key はMainの入口・保護・費用・遅延を一意に表します。
//
// 引数: c(Config)は固定組合せです。
// 返り値: stringはentry_E0_G0_C0_D0等です。
func Key(c Config) string {
	return fmt.Sprintf("%s_%s_C%.0f_D%d", c.EntryPolicy, c.Policy, c.Slip, c.Delay)
}

// BaseKey は比較する旧108Q0四費用の保存名を返します。
//
// 引数: c(Config)は対応するMainです。
// 返り値: stringはQ0_C0_D0等です。
func BaseKey(c Config) string { return fmt.Sprintf("Q0_C%.0f_D%d", c.Slip, c.Delay) }

// digestValue は有限な保存値を全JSONのSHAへ結びます。
//
// 引数: value(any)は固定公開値です。
// 返り値: string/errorは全値指紋又はJSON不正です。
func digestValue(value any) (string, error) {
	b, e := json.Marshal(value)
	if e != nil {
		return "", e
	}
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:]), nil
}

// sameJSON はfield除外なしで全公開JSONを比較します。
//
// 引数: a/b(any)は比較値です。
// 返り値: boolは全JSON同体のとき真です。
func sameJSON(a, b any) bool {
	x, e := json.Marshal(a)
	if e != nil {
		return false
	}
	y, e := json.Marshal(b)
	return e == nil && bytes.Equal(x, y)
}

// NewCore は固定Source/Recordの検証器と24Main、条件に応じた旧4対照を作ります。
//
// 引数: input(Tape)、contract/scope(string)、control(Control)、publication(PublicationInput)は指紋固定済み値です。
// 返り値: *Core/errorは逐次Sink又は設定不整合です。CSV/原板/Native本文I/Oは行いません。
func NewCore(input tape.Tape, contract, scope string, control Control, publication PublicationInput) (*Core, error) {
	c := &Core{input: input, contract: contract, scope: scope, control: control, configs: Configurations(), pipeline: delivery.NewPipeline(), last: map[string]int64{}, rawAll: map[string]int64{}, pendingReset: map[string]chart.Quote{}, preRank: -1, grids: []float64{}, pubInput: publication}
	if input.Version != 1 || input.Scope == "" || scope == "" || contract == "" || !reflect.DeepEqual(input.Capabilities, tape.Capabilities()) {
		return nil, fmt.Errorf("固定Tape/明示scope/限月が必要")
	}
	previous := 0.0
	rank := map[string]int{"force": 0, "grid": 1, "quote": 2}
	previousRank := -1
	for i, e := range input.Events {
		r, ok := rank[e.Kind]
		if !ok || e.Ordinal != i+1 || !finite(e.At) || e.At < previous || e.At == previous && r < previousRank {
			return nil, fmt.Errorf("Source Tape ordinal/位相差")
		}
		if e.At != previous {
			previousRank = -1
		}
		previous, previousRank = e.At, r
	}
	var err error
	c.tapeSHA, err = digestValue(input)
	if err != nil {
		return nil, err
	}
	c.priorProof, err = c.validateReference()
	if err != nil {
		return nil, err
	}
	c.priorDigest, err = digestValue([]any{control.Books, control.WidthAudits, control.ClockAudits, control.EarlyAudits})
	if err != nil {
		return nil, err
	}
	// ----------------------------------------
	// 入口の新公開器はSource時計と同じ場/限月だけを受け、真のEOFは監査側に保ちます。
	ps := publication.Session
	if ps.ID != input.Session.ID || ps.Contract != contract || ps.Start != input.Session.Start || ps.End != input.Session.End {
		return nil, fmt.Errorf("入口5/15/30分の場/限月/時計差")
	}
	c.pubBank, err = frame.BeginSession(ps, publication.Children, publication.Seed)
	if err != nil {
		return nil, err
	}
	childSHA, err := digestValue(publication.Children)
	if err != nil {
		return nil, err
	}
	c.pubAudit = PublicationAudit{ClockModel: "csv_end_plus60_at_record_scheduler", Session: ps, ChildrenSHA: childSHA, Children: len(publication.Children), Counts: map[int]int{}, PriceKnown: map[int]int{}, VolumeKnown: map[int]int{}, PolicyEOFRedacted: true}
	if publication.Seed != nil {
		info := publication.Seed.Info()
		c.pubAudit.InputSeed = &info
	}
	// ----------------------------------------
	// Main24のほか、fresh_unseenだけ独立旧108Q0四冊を検査用に持ちます。
	for _, cfg := range c.configs {
		b, e := finance.NewCompositeBook(input.Session, finance.CompositeConfig{EntryPolicy: cfg.EntryPolicy, Protection: cfg.Policy, SlipPts: cfg.Slip, DelaySeconds: cfg.Delay, USOpen: input.Session.USOpen}, contract)
		if e != nil {
			return nil, e
		}
		c.actors = append(c.actors, b)
		c.entryStates = append(c.entryStates, entry.NewEntryState())
		c.entryAudits = append(c.entryAudits, EntryAudit{Policy: cfg.EntryPolicy, Assessments: []entry.BatchAssessment{}})
	}
	if control.Kind == "fresh_unseen" {
		for _, slip := range []float64{0, 5} {
			for _, delay := range []int{0, 1} {
				b, e := oldfinance.NewWidthBookWithQuiet(input.Session, oldfinance.ActorConfig{Policy: "P0", ActivationPolicy: oldfinance.ActivationLD10, EntryTiming: "B5QD", USOpen: input.Session.USOpen, SlipPts: slip, DelaySeconds: delay}, "W0", contract, 1200)
				if e != nil {
					return nil, e
				}
				c.shadows = append(c.shadows, b)
			}
		}
	}
	return c, nil
}

// fail は不成立を保持し、部分処理を成功に補いません。
//
// 引数: e(error)は原因です。
// 返り値: errorは同じ原因です。
func (c *Core) fail(e error) error { c.failed = e; return e }

// batches は元Source全Deltaの順序/nil/値を新Actor外型へ写します。
//
// 引数: in([]oldtype.NativeBatch)は固定復元列です。
// 返り値: []finance.NativeBatchは変更しない全通知です。
func batches(in []oldtype.NativeBatch) []finance.NativeBatch {
	if in == nil {
		return nil
	}
	n := make([]finance.NativeBatch, len(in))
	for i, b := range in {
		n[i] = finance.NativeBatch{Method: b.Method, Delta: b.Delta}
	}
	return n
}

// oldBatches は検査shadowだけに元Deltaを同じ順序で渡します。
//
// 引数: in([]oldtype.NativeBatch)は固定復元列です。
// 返り値: []oldfinance.NativeBatchは値を変更しない別外型です。
func oldBatches(in []oldtype.NativeBatch) []oldfinance.NativeBatch {
	if in == nil {
		return nil
	}
	n := make([]oldfinance.NativeBatch, len(in))
	for i, b := range in {
		n[i] = oldfinance.NativeBatch{Method: b.Method, Delta: b.Delta}
	}
	return n
}

// source は固定Tapeの次quote/Force/gridをMainと条件付きshadowへ同じ順で配送します。
//
// 引数: r(stream.Record)は出典検証済みの保存列です。
// 返り値: errorはSource結合/金融の不成立です。
func (c *Core) source(r stream.Record) error {
	if c.cursor >= len(c.input.Events) {
		return fmt.Errorf("Source Tapeより余剰配送")
	}
	event := c.input.Events[c.cursor]
	if event.Kind != r.Kind || event.At != r.At {
		return fmt.Errorf("Source Tape次ordinalとの種別/時計差:%d", event.Ordinal)
	}
	switch r.Kind {
	case "quote":
		if event.Quote == nil || r.Scalar == nil || !reflect.DeepEqual(*event.Quote, *r.Scalar) || event.Context != nil {
			return fmt.Errorf("固定Scalar11差")
		}
	case "force":
		if r.Force == nil || r.Force.TapeOrdinal != event.Ordinal || r.Force.At != event.At || event.Quote != nil || event.Context != nil {
			return fmt.Errorf("元Force ordinal/時計差")
		}
	case "grid":
		if r.Grid == nil || r.Grid.Legacy.At != event.At || r.Grid.Legacy.Scene.ID != c.input.Session.ID || r.Grid.Legacy.Scene.Contract != c.contract || r.Grid.Legacy.Scene.Start != c.input.Session.Start || event.Quote != nil || len(event.Methods)+len(event.NonEmpty) != 0 || event.Context != nil && event.Context.At != event.At {
			return fmt.Errorf("元5分grid差")
		}
	}
	if r.Kind == "grid" {
		if err := c.entryGrid(event.At); err != nil {
			return err
		}
		for _, b := range c.shadows {
			if err := b.OnEntryGrid(event.At); err != nil {
				return err
			}
		}
		c.grids = append(c.grids, event.At)
		c.counts.Grids++
	} else {
		full, err := tape.RestoreBatches(event, c.last)
		if err != nil {
			return err
		}
		before, err := digestValue(full)
		if err != nil {
			return err
		}
		n := batches(full)
		for _, b := range c.actors {
			if r.Kind == "quote" {
				err = b.OnNativeStep(event.Quote.Observation(), event.Quote.SourceLine, n)
			} else {
				err = b.OnNativeForce(event.At, n)
			}
			if err != nil {
				return err
			}
		}
		o := oldBatches(full)
		for _, b := range c.shadows {
			if r.Kind == "quote" {
				err = b.OnNativeStep(event.Quote.Observation(), event.Quote.SourceLine, o)
			} else {
				err = b.OnNativeForce(event.At, o)
			}
			if err != nil {
				return err
			}
		}
		after, e := digestValue(full)
		if e != nil || before != after {
			return fmt.Errorf("共有Source通知を変更")
		}
		if r.Kind == "quote" {
			c.counts.Quotes++
		} else {
			c.counts.Forces++
		}
	}
	c.cursor++
	return nil
}

// NextSeed は成功Finish後だけ同限月次場用の値種を返します。
//
// 引数: ありません。
// 返り値: frame.Seed/errorは完成種又は未完結です。JSON結果へ私有種を転記しません。
func (c *Core) NextSeed() (frame.Seed, error) {
	if c == nil || !c.complete {
		return frame.Seed{}, fmt.Errorf("成功Finish前の数値種取得")
	}
	return c.nextSeed, nil
}

// SourceSession は市場時計と公表時計を別の型へ同じ値で対応させます。
//
// 引数: s(finance.Session)、contract(string)、eof(float64)は場と真の観測終端です。
// 返り値: frame.SessionはCSV公開器専用の場時計です。
func SourceSession(s finance.Session, contract string, eof float64) frame.Session {
	return frame.Session{ID: s.ID, Contract: contract, Start: s.Start, End: s.End, EOF: eof}
}
