# 109の三時間軸と一定利益保護を結ぶ市場接続部

市場データを開く外周から固定106のSource Tape・Recordを受け、入口E0/E1、保護G0/G1/G2、滑り0/5pt、遅延0/1秒の24冊へ配送する。静観は1200秒。市場入力の読込み・Source再計算・CSV読込みはこのpackageでは行わない。

この段階の成功は人工の配送・数値・会計接続の検査であり、実市場の損益、実参加率、手法の有効性の確認ではない。11/09の未使用入力本文も読まない。

## API

```go
NewCore(input tape.Tape, contract, scope string, control Control, publication PublicationInput) (*Core, error)
(*Core).Feed(record stream.Record) error
(*Core).Finish(header stream.Header) (Result, error)
(*Core).NextSeed() (threeframe.Seed, error)
Run(core *Core, records []stream.Record, header stream.Header) (Result, error)
FreshControl(input tape.Tape, contract string) (Control, error)
SourceSession(session finance.Session, contract string, eof float64) threeframe.Session
Configurations() []Config
Key(config Config) string
BaseKey(config Config) string
SourceForces(input tape.Tape) []stream.Force
```

`PublicationInput` は `Session`、指紋付き子5分足 `Children`、直前場からの私有数値種 `Seed` を持つ。外周の `threeframeinput.LoadChildren` の値をそのまま渡す。`Seed` 自体はJSON化しない。`NextSeed` は成功Finish後だけ返る。前場の数値種を同限月で継ぎ、場・欠足・限月reset等の定義は停止済みthreeframeへ委ねる。

`Control.Kind` は事前に次のどちらかへ固定する。

|種類|入力|検査対照|
|---|---|---|
|`provided_old108_q20`|旧108全12冊のBook/Width/Clock、QEのEarly4をRawMessageで渡し、Nativeのpath/SHAを保持|Main E0/G0四費用と保存Q0のBook/Width/Clockを全JSON比較。旧金融は実行しない|
|`fresh_unseen`|保存参照を渡さず、`FreshControl` がSourceの場・限月・指紋を束縛|独立した旧108 Q0四費用を検査shadowへ再生し、E0/G0四冊と全JSON比較。Main24へ合算しない|

保存参照の未知fieldは破棄せず全RawのSHAで保持する。既知fieldを旧型へ投影するのは設定・完結・数量の検査だけで、Mainの予測値を参照値から転記しない。Native実物のSHA認証は外周の責任。

## 実行と結果

外周はSource/CSV/保存参照の指紋を認証してNewCoreへ渡し、固定Recordを一度Feedする。新三尺度公開器は各Record.Atで進み、政策へは当時snapshotのcopyを渡す。Headerの完全消費、全24冊の残建玉・残予約0、Source入力不変、CSV子入力不変、旧参照不変、四対照の一致をFinishで確認する。

`Result` はMain Book24、旧G0のWidth8、Clock24、Composite24、Entry24を持つ。fresh時だけ検査shadow4を別mapに置く。旧Early4は保存参照であり、新G0との比較対象にはしない。PublicationAudit、ProtectionAudit、EntryAuditを別に持ち、新規・保護・公表の因果を追える。空候補でもE1の全gridで純状態を更新するが、大きいBatch履歴は非空候補のときだけ残す。

## 時計と公開

`ClockModel = csv_end_plus60_at_record_scheduler`。CSVには実受信時計がないため、足終+60秒を名目利用可能時刻とし、保存StreamのRecord.Atという名目再生時計で配送したモデルである。原板のTrigger.TimeはRecord.Atより1～2秒後となる場合がある。差の件数・最大差は診断として保存し、実ネットワーク受信時計を検証したとは呼ばない。

真のEOFは入力・公表監査・Sealだけに保持する。Entry境界は `PolicySnapshot` でSession.EOF=0、Sealed=falseへ射影し、SnapshotIDも射影後から作る。AfterEOFForceでは新公開器を進めない。全Record配送後SealしたSeed.Infoは、同じ入力をEOF一回だけAdvanceしてSealした数値種と同体であることを人工検査する。数値種の同体を公表時計監査の同体とは呼ばない。

入口5/15/30分と保護用3分は独立する。G0は旧deliveryのPublicReceiverを維持し、G1/G2は同じ旧3分deliveryから `OnProtectionObservation` へ一度だけ配送する。Vは数量ではなく、連続した既公表3分足5本の高安差の中央値（最低5pt）である。reset時は古い根拠とV窓だけを失効させ、既存の保護床を緩めない。

## 検査

`python 検査と停止を記録する.py` は人工Go test、vet、build、旧停止と直接依存の指紋の前後不変を確認し、新しい停止.jsonを一度だけ作る。停止済み資料を上書きしない。

人工Source通知を使う検査は自然発生したSource手法の成績ではない。実publisherから数値seedを作り、当場の押戻し・突破・再試験、買売鏡像、合法5pt BBO、純Entry許可、24冊の新規・返済まで通す。指標値の直書きやモック許可は使わない。詳細は[仕様.md](仕様.md)と停止記録を参照する。
