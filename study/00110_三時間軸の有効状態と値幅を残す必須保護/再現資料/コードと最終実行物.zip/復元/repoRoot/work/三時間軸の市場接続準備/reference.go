package threeguardruntime109

import (
	"encoding/hex"
	"encoding/json"
	"fmt"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	finance "github.com/masayoshi4649/SessionTradeExecuter/miniprofitthreeproposal"
	oldfinance "github.com/masayoshi4649/SessionTradeExecuter/miniquietlength108"
)

// FreshControl は保存Nativeの存在しない場を、独立旧4冊検査へ明示します。
//
// 引数: input(tape.Tape)、contract(string)は新場の固定Sourceと限月です。
// 返り値: Control/errorは虚偽参照を含まないmetadata又はJSON不正です。
func FreshControl(input tape.Tape, contract string) (Control, error) {
	h, e := digestValue(input)
	if e != nil {
		return Control{}, e
	}
	return Control{Kind: "fresh_unseen", HistoryClass: "fresh_unseen", Session: input.Session, Contract: contract, TapeSHA: h, QuietSeconds: 1200}, nil
}

// validateReference は旧108全12保存又は未使用場旧4shadowの事前分岐を検査します。
//
// 引数: c(*Core)は未運転の固定入力です。
// 返り値: ReferenceProof/errorは全JSON指紋と由来又は場/設定/構造差です。実物SHA認証は外周です。
func (c *Core) validateReference() (ReferenceProof, error) {
	r := c.control
	if r.QuietSeconds != 1200 || r.Contract != c.contract || !sameJSON(r.Session, c.input.Session) || r.TapeSHA != c.tapeSHA {
		return ReferenceProof{}, fmt.Errorf("対照のquiet/場/限月/Tape差")
	}
	p := ReferenceProof{Kind: r.Kind, HistoryClass: r.HistoryClass, QuietSeconds: 1200, ReferencePath: r.ReferencePath, ReferenceSHA: r.ReferenceSHA, TapeSHA: r.TapeSHA, BookSHA: map[string]string{}, WidthSHA: map[string]string{}, ClockSHA: map[string]string{}, EarlySHA: map[string]string{}}
	if r.Kind == "fresh_unseen" {
		if (r.HistoryClass != "fresh_unseen" && r.HistoryClass != "artificial") || r.ReferencePath != "" || r.ReferenceSHA != "" || len(r.Books)+len(r.WidthAudits)+len(r.ClockAudits)+len(r.EarlyAudits) != 0 {
			return ReferenceProof{}, fmt.Errorf("未使用場に保存旧108参照やRawMessageを捏造")
		}
		p.Scope = "保存旧108なし。独立旧108Q0四費用を検査shadowへ再生しMainのE0/G0四冊を全JSON比較。Main24へ合算しない"
		return p, nil
	}
	if r.Kind != "provided_old108_q20" || (r.HistoryClass != "old_saved_70" && r.HistoryClass != "artificial") || r.ReferencePath == "" || len(r.ReferenceSHA) != 64 || len(r.Books) != 12 || len(r.WidthAudits) != 12 || len(r.ClockAudits) != 12 || len(r.EarlyAudits) != 4 {
		return ReferenceProof{}, fmt.Errorf("旧108保存参照の由来/12Book/12幅/12時計/4早期差")
	}
	if _, e := hex.DecodeString(r.ReferenceSHA); e != nil {
		return ReferenceProof{}, fmt.Errorf("旧108参照SHA不正")
	}
	p.Books, p.WidthAudits, p.ClockAudits, p.EarlyAudits = 12, 12, 12, 4
	p.Scope = "旧108Q20全12Book/幅12/時計12/早期4の未知field込み全JSON指紋とNative参照。実比較はMainE0/G0対Q0四費用のBook/Width/Clockだけ。旧30金融再実行なし"
	for _, name := range []string{"Q0", "Q1", "QE"} {
		for _, slip := range []float64{0, 5} {
			for _, delay := range []int{0, 1} {
				key := fmt.Sprintf("%s_C%.0f_D%d", name, slip, delay)
				activation, policy := oldfinance.ActivationLD10, "W0"
				if name == "Q1" {
					policy = "W1"
				}
				if name == "QE" {
					activation, policy = oldfinance.ActivationE1, "E1"
				}
				expected := oldfinance.ActorConfig{Policy: "P0", ActivationPolicy: activation, EntryTiming: "B5QD", USOpen: c.input.Session.USOpen, SlipPts: slip, DelaySeconds: delay}
				book := oldfinance.ActualResult{}
				width := oldfinance.WidthBookAudit{}
				clock := oldfinance.ClockBookAudit{}
				inner := fmt.Sprintf("%s_B5QD_P0_C%.0f_D%d", activation, slip, delay)
				if !json.Valid(r.Books[key]) || json.Unmarshal(r.Books[key], &book) != nil || book.Key != inner || !sameJSON(book.Session, c.input.Session) || !book.Complete || !book.Finished || book.Failure != "" || !sameJSON(book.Config, expected) || book.Totals.OpenBuy+book.Totals.OpenSell+book.Totals.PendingBuy+book.Totals.PendingSell != 0 || !json.Valid(r.WidthAudits[key]) || json.Unmarshal(r.WidthAudits[key], &width) != nil || width.Policy != policy || width.Contract != c.contract || !json.Valid(r.ClockAudits[key]) || json.Unmarshal(r.ClockAudits[key], &clock) != nil || clock.Timing != "B5QD" {
					return ReferenceProof{}, fmt.Errorf("旧108のKey/場/設定/完結/幅/時計差:%s", key)
				}
				var err error
				if p.BookSHA[key], err = digestValue(r.Books[key]); err != nil {
					return ReferenceProof{}, err
				}
				if p.WidthSHA[key], err = digestValue(r.WidthAudits[key]); err != nil {
					return ReferenceProof{}, err
				}
				if p.ClockSHA[key], err = digestValue(r.ClockAudits[key]); err != nil {
					return ReferenceProof{}, err
				}
				if name == "QE" {
					early := oldfinance.EarlyBookAudit{}
					if !json.Valid(r.EarlyAudits[key]) || json.Unmarshal(r.EarlyAudits[key], &early) != nil || early.Policy != oldfinance.ActivationE1 {
						return ReferenceProof{}, fmt.Errorf("旧108早期audit差:%s", key)
					}
					if p.EarlySHA[key], err = digestValue(r.EarlyAudits[key]); err != nil {
						return ReferenceProof{}, err
					}
				}
			}
		}
	}
	return p, nil
}

// compareBaseline はE0/G0だけを保存Q0又は独立旧4冊へ全JSON一致で結びます。
//
// 引数: out(*Result)は完結Main24と条件付きshadow4です。
// 返り値: errorは四対の値差です。成績を参照値から転記しません。
func (c *Core) compareBaseline(out *Result) error {
	p := BaselineProof{Mode: c.control.Kind, Books: map[string]bool{}, Widths: map[string]bool{}, Clocks: map[string]bool{}, All: true, Scope: "MainE0/G0四費用のBook/Width/Clock全JSON。全市場別engine照合又は他20Mainの同体ではない"}
	for _, cfg := range c.configs {
		if cfg.EntryPolicy != finance.EntryE0 || cfg.Policy != finance.ProtectG0 {
			continue
		}
		key, base := Key(cfg), BaseKey(cfg)
		if c.control.Kind == "provided_old108_q20" {
			p.Books[key] = sameJSON(out.Books[key], c.control.Books[base])
			p.Widths[key] = sameJSON(out.WidthAudits[key], c.control.WidthAudits[base])
			p.Clocks[key] = sameJSON(out.ClockAudits[key], c.control.ClockAudits[base])
		} else {
			p.Books[key] = sameJSON(out.Books[key], out.ShadowBooks[base])
			p.Widths[key] = sameJSON(out.WidthAudits[key], out.ShadowWidthAudits[base])
			p.Clocks[key] = sameJSON(out.ClockAudits[key], out.ShadowClockAudits[base])
		}
		p.Comparisons++
		p.All = p.All && p.Books[key] && p.Widths[key] && p.Clocks[key]
	}
	out.Baseline = p
	if p.Comparisons != 4 || !p.All {
		return fmt.Errorf("E0/G0と旧108Q0の四対全JSON差")
	}
	return nil
}
