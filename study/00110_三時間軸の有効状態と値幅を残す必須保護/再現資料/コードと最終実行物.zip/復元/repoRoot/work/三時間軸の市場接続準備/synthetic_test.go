package threeguardruntime109

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"testing"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	oldtype "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	finance "github.com/masayoshi4649/SessionTradeExecuter/miniprofitthreeproposal"
	oldfinance "github.com/masayoshi4649/SessionTradeExecuter/miniquietlength108"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
	delivery "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

type NativeBatch = finance.NativeBatch

// publisherInput は実数値を注入せず240助走子と12押戻し子から新公開器の入力を作ります。
//
// 引数: t(*testing.T)、side(int)は検査器と鏡像方向です。
// 返り値: PublicationInputはSeriesBankが実計算する人工足列です。
func publisherInput(t *testing.T, side int) PublicationInput {
	t.Helper()
	start := 1800000000.0
	contract := "人工限月"
	prior := frame.Session{ID: "人工助走", Contract: contract, Start: start, End: start + 241*300, EOF: start + 240*300 + 60}
	children := make([]frame.ChildBar, 240)
	for i := range children {
		p := 10000 + float64(i)*2
		o := frame.OHLC{Open: p - .5, High: p + 2, Low: p - 2, Close: p}
		if side < 0 {
			o = frame.OHLC{Open: 30000 - o.Open, High: 30000 - o.Low, Low: 30000 - o.High, Close: 30000 - o.Close}
		}
		children[i] = frame.ChildBar{Start: start + float64(i)*300, End: start + float64(i+1)*300, OHLC: o, Volume: 100, Closed: true, VolumeKnown: true, Input: frame.FileRef{Path: "人工助走.csv", SHA256: strings.Repeat("a", 64), Bytes: 12345}, Row: uint64(i + 2)}
	}
	b, e := frame.BeginSession(prior, children, nil)
	if e != nil {
		t.Fatal(e)
	}
	if _, e = b.AdvanceObserved(prior.EOF, 1); e != nil {
		t.Fatal(e)
	}
	seed, _, e := b.Seal()
	if e != nil {
		t.Fatal(e)
	}
	base := 10478.0
	ohlc := []frame.OHLC{{Open: 5, High: 7, Low: -2, Close: 0}, {Open: 0, High: 1, Low: -7, Close: -5}, {Open: -5, High: 9, Low: -5, Close: 0}, {Open: 0, High: 8, Low: -2, Close: -1}, {Open: -1, High: 5, Low: -4, Close: -3}, {Open: -3, High: 3, Low: -4, Close: -2}, {Open: -2, High: 13, Low: -2, Close: 11}, {Open: 11, High: 14, Low: 8, Close: 12}, {Open: 12, High: 17, Low: 9, Close: 15}, {Open: 15, High: 18, Low: 10, Close: 16}, {Open: 16, High: 19, Low: 11, Close: 17}, {Open: 17, High: 20, Low: 12, Close: 18}}
	s := frame.Session{ID: "人工三軸取得_Day", Contract: contract, Start: prior.End + 3600, End: prior.End + 3600 + 13*300, EOF: prior.End + 3600 + 12*300 + 60}
	current := make([]frame.ChildBar, len(ohlc))
	for i, o := range ohlc {
		o.Open += base
		o.High += base
		o.Low += base
		o.Close += base
		if side < 0 {
			o = frame.OHLC{Open: 30000 - o.Open, High: 30000 - o.Low, Low: 30000 - o.High, Close: 30000 - o.Close}
		}
		current[i] = frame.ChildBar{Start: s.Start + float64(i)*300, End: s.Start + float64(i+1)*300, OHLC: o, Volume: 100, Closed: true, VolumeKnown: true, Input: frame.FileRef{Path: "人工取得.csv", SHA256: strings.Repeat("b", 64), Bytes: 6789}, Row: uint64(i + 2)}
	}
	return PublicationInput{Session: s, Children: current, Seed: &seed}
}

// syntheticRequest はCSV型の人工OHLCと二市場の正常原行・合法BBOを作ります。
//
// 引数: t(*testing.T)、pub(*PublicationInput)、side(int)は値copyの人工足と方向です。
// 返り値: continuous.Requestは自然Sourceや市場本文を使わない生産器入力です。
func syntheticRequest(t *testing.T, pub *PublicationInput, side int) continuous.Request {
	t.Helper()
	ps := pub.Session
	s := native.Session{ID: ps.ID, Kind: "Day", Start: ps.Start, End: ps.End, ForceClose: ps.Start + 3600, ExtraAt: ps.Start + 13500}
	r := continuous.Request{Session: s, Scene: chart.Scene{ID: ps.ID, Contract: ps.Contract, Start: ps.Start}, Rows: []continuous.Row{}, Candles: []continuous.CandleEvent{}, Grids: []float64{}}
	for g := s.Start; g < s.End; g += 300 {
		r.Grids = append(r.Grids, g)
	}
	times := []float64{}
	for minute := 0; minute <= 61; minute++ {
		times = append(times, s.Start+float64(minute)*60)
	}
	for _, sec := range []float64{2999, 3001, 3002, 3003, 3004, 3005, 3006, 3601} {
		times = append(times, s.Start+sec)
	}
	sort.Float64s(times)
	nkLine := int64(0)
	peerLine := int64(0)
	for _, at := range times {
		elapsed := at - s.Start
		i := min(int(elapsed/300), len(pub.Children)-1)
		o := pub.Children[i].OHLC
		phase := int(elapsed/60) % 5
		last := []float64{o.Open, o.High, o.Low, o.Close, o.Close}[phase]
		last = 5 * math.Round(last/5)
		baseAsk := 5 * math.Floor(last/5)
		bid, ask := baseAsk-10, baseAsk
		if side < 0 {
			bid = 5 * math.Ceil(last/5)
			ask = bid + 10
		}
		if elapsed >= 2999 && elapsed <= 3006 {
			if side > 0 {
				bid, ask = 10480, 10490
			} else {
				bid, ask = 19510, 19520
			}
			move := 0.0
			if elapsed == 3002 {
				move = 70
			}
			if elapsed == 3003 {
				move = 40
			}
			if elapsed >= 3004 {
				move = 10
			}
			bid += float64(side) * move
			ask += float64(side) * move
			last = ask
		}
		nkLine++
		peerLine++
		r.Rows = append(r.Rows, continuous.Row{Board: strategy.Board{Reference: "NK225", Time: at, Received: at, Last: last, Bid: bid, Ask: ask, BidQuantity: 20, AskQuantity: 20}, PhysicalLine: nkLine})
		r.Rows = append(r.Rows, continuous.Row{Board: strategy.Board{Reference: "TOPIX", Time: at, Received: at, Last: 2500, Bid: 2499.5, Ask: 2500.5, BidQuantity: 20, AskQuantity: 20}, PhysicalLine: peerLine})
		if elapsed >= 3000 && elapsed < 3300 {
			p := &pub.Children[10].OHLC
			p.High = math.Max(p.High, last)
			p.Low = math.Min(p.Low, last)
		}
	}
	for _, b := range pub.Children {
		r.Candles = append(r.Candles, continuous.CandleEvent{Reference: "NK225", Interval: 300, At: b.End + 60, Candle: strategy.Candle{Time: b.Start, Open: b.OHLC.Open, High: b.OHLC.High, Low: b.OHLC.Low, Close: b.OHLC.Close, Closed: true}})
	}
	return r
}

// syntheticTape は停止生産器のScalar/5分clockへ非ゼロの手製Source通知を結びます。
//
// 引数: t(*testing.T)、r(continuous.Request)、side(int)は人工列です。
// 返り値: tape.Tapeは+50分割当の一出生・後続Source約定・Force返済です。
func syntheticTape(t *testing.T, r continuous.Request, side int) tape.Tape {
	t.Helper()
	events := []tape.TapeEvent{}
	_, _, e := continuous.BuildToSink(r, nil, func(x continuous.Record) error {
		if x.Kind == "row" {
			q := x.Row.Scalar
			events = append(events, tape.TapeEvent{Kind: "quote", At: q.Time, Quote: &q})
		}
		if x.Kind == "control" && x.Control.Kind == "grid" {
			events = append(events, tape.TapeEvent{Kind: "grid", At: x.Control.At})
		}
		return nil
	})
	if e != nil {
		t.Fatal(e)
	}
	events = append(events, tape.TapeEvent{Kind: "force", At: r.Session.ForceClose})
	rank := map[string]int{"force": 0, "grid": 1, "quote": 2}
	sort.SliceStable(events, func(i, j int) bool {
		return events[i].At < events[j].At || events[i].At == events[j].At && rank[events[i].Kind] < rank[events[j].Kind]
	})
	src := newSource()
	for i := range events {
		ev := &events[i]
		ev.Ordinal = i + 1
		if ev.Kind == "grid" {
			continue
		}
		var batch NativeBatch
		if ev.Kind == "force" {
			batch = src.force(ev.At)
			batch.Delta.SourceLine = src.last.SourceLine
		} else {
			news := []native.Signal{}
			if ev.At == r.Session.Start+2880 {
				news = append(news, birth("三軸初回", side, 6))
			}
			q := ev.Quote
			batch = src.step(native.QuoteStamp{Time: q.Time, Index: q.Index, SourceLine: q.SourceLine, Last: q.Last, Bid: q.Bid, Ask: q.Ask, QuoteOK: q.QuoteOK}, news)
		}
		ev.Methods = []string{batch.Method}
		ev.NonEmpty = []oldtype.NativeBatch{}
		if len(batch.Delta.Signals)+len(batch.Delta.Fills)+len(batch.Delta.Cancellations)+len(batch.Delta.Closes) > 0 {
			ev.NonEmpty = append(ev.NonEmpty, oldtype.NativeBatch{Method: batch.Method, Delta: batch.Delta})
		}
	}
	return tape.Tape{Version: 1, Scope: "人工CSV価格・手製Source通知。市場入力/自然Sourceなし", Session: r.Session, Capabilities: tape.Capabilities(), Events: events}
}

// TestAllTwentyFourNonzero は足合成→指標carry→純Entry→合法BBO実新規→保護→全返済を確認します。
//
// 引数: t(*testing.T)は市場未読の人工統合検査です。
// 返り値: ありません。モック許可や指標の直書きを使いません。
func TestAllTwentyFourNonzero(t *testing.T) {
	for _, side := range []int{1, -1} {
		t.Run(fmt.Sprint(side), func(t *testing.T) {
			pub := publisherInput(t, side)
			request := syntheticRequest(t, &pub, side)
			input := syntheticTape(t, request, side)
			records := []stream.Record{}
			header, _, e := stream.Build(request, nil, SourceForces(input), func(r stream.Record) error { records = append(records, r); return nil })
			if e != nil {
				t.Fatal(e)
			}
			if header.Ending.Legacy.ObservedClock != pub.Session.EOF {
				t.Fatal("人工EOF不一致")
			}
			control, e := FreshControl(input, pub.Session.Contract)
			if e != nil {
				t.Fatal(e)
			}
			c, e := NewCore(input, pub.Session.Contract, "実公開器/純Entry/手製Sourceの24非ゼロ人工", control, pub)
			if e != nil {
				t.Fatal(e)
			}
			result, e := Run(c, records, header)
			if e != nil {
				t.Fatal(e)
			}
			for _, cfg := range result.Configs {
				key := Key(cfg)
				b := result.Books[key]
				if b.Totals.EntryQuantity == 0 {
					t.Fatalf("Mainが非ゼロでない:%s 純入口=%+v", key, result.EntryAudits[key])
				}
				if !b.Complete || b.Totals.OpenBuy+b.Totals.OpenSell+b.Totals.PendingBuy+b.Totals.PendingSell != 0 {
					t.Fatal("全返済に失敗", key)
				}
				if cfg.EntryPolicy == finance.EntryE1 && result.EntryAudits[key].Allowed == 0 {
					t.Fatal("純Entry許可を経由していない", key)
				}
				if cfg.Policy != finance.ProtectG0 && len(result.CompositeAudits[key].Positions) == 0 {
					t.Fatal("G1/G2監査が空", key)
				}
			}
			if !result.Baseline.All || len(result.ShadowBooks) != 4 || result.ProtectionAudit.VKnown == 0 {
				t.Fatal("非ゼロ四対照/V検査が空")
			}
			// ----------------------------------------
			// 同じ人工Sourceを旧Q20の12政策へ一度配送し、保存分岐でもMain24を非ゼロ確認します。
			saved := oldSyntheticReference(t, input, pub.Session.Contract, records)
			savedCore, e := NewCore(input, pub.Session.Contract, "旧Q20人工保存対照と24非ゼロ", saved, pub)
			if e != nil {
				t.Fatal(e)
			}
			savedResult, e := Run(savedCore, records, header)
			if e != nil {
				t.Fatal(e)
			}
			if len(savedResult.ShadowBooks) != 0 || !savedResult.Baseline.All {
				t.Fatal("保存分岐が余分な旧会計を実行")
			}
			for key, b := range savedResult.Books {
				if b.Totals.EntryQuantity == 0 || !sameJSON(b, result.Books[key]) || !sameJSON(savedResult.CompositeAudits[key], result.CompositeAudits[key]) {
					t.Fatal("保存/freshでMainが同じ非ゼロ値にならない", key)
				}
			}
			for mode, output := range map[string]Result{"fresh": result, "saved": savedResult} {
				exportArtificial109(t, fmt.Sprintf("方向%d_%s.json", side, mode), struct {
					Scope   string          `json:"scope"`
					Tape    tape.Tape       `json:"tape"`
					Header  stream.Header   `json:"header"`
					Records []stream.Record `json:"records"`
					Output  Result          `json:"output"`
				}{"人工価格・手製Source・市場実行なし", input, header, records, output})
			}
			t.Logf("side%d:24Main非ゼロ・4旧shadow全JSON同体・V既知%d", side, result.ProtectionAudit.VKnown)
		})
	}
}

// oldSyntheticReference は新金融を使わず旧108Actor12へ同じ人工通知を配送して対照を作ります。
//
// 引数: t(*testing.T)、input(tape.Tape)、contract(string)、records([]stream.Record)は人工入力です。
// 返り値: Controlはtempに実保存したQ20の12冊。旧30や市場の金融再実行ではありません。
func oldSyntheticReference(t *testing.T, input tape.Tape, contract string, records []stream.Record) Control {
	t.Helper()
	actors := []*oldfinance.ActualBook{}
	keys := []string{}
	for _, name := range []string{"Q0", "Q1", "QE"} {
		for _, slip := range []float64{0, 5} {
			for _, delay := range []int{0, 1} {
				cfg := oldfinance.ActorConfig{Policy: "P0", ActivationPolicy: oldfinance.ActivationLD10, EntryTiming: "B5QD", USOpen: input.Session.USOpen, SlipPts: slip, DelaySeconds: delay}
				var b *oldfinance.ActualBook
				var e error
				if name == "QE" {
					cfg.ActivationPolicy = oldfinance.ActivationE1
					b, e = oldfinance.NewEarlyBookWithQuiet(input.Session, cfg, contract, 1200)
				} else {
					policy := "W0"
					if name == "Q1" {
						policy = "W1"
					}
					b, e = oldfinance.NewWidthBookWithQuiet(input.Session, cfg, policy, contract, 1200)
				}
				if e != nil {
					t.Fatal(e)
				}
				actors = append(actors, b)
				keys = append(keys, fmt.Sprintf("%s_C%.0f_D%d", name, slip, delay))
			}
		}
	}
	last := map[string]int64{}
	cursor := 0
	pipe := delivery.NewPipeline()
	for _, r := range records {
		switch r.Kind {
		case "publication":
			if r.Publication.Three {
				d, e := pipe.Feed(*r.Publication, r.At)
				if e != nil || !sameJSON(d, *r.Delivery) {
					t.Fatal("旧人工公開器の一致失敗", e)
				}
				for _, b := range actors {
					if e = delivery.Send(d, oldfinance.PublicReceiver{Book: b}); e != nil {
						t.Fatal(e)
					}
				}
			}
		case "reset":
			receivers := []delivery.Receiver{}
			for _, b := range actors {
				receivers = append(receivers, oldfinance.PublicReceiver{Book: b})
			}
			if e := pipe.Reset(r.At, r.Reset.Reason, receivers...); e != nil {
				t.Fatal(e)
			}
		case "grid", "quote", "force":
			ev := input.Events[cursor]
			if ev.Kind != r.Kind || ev.At != r.At {
				t.Fatal("旧対照Source cursor差")
			}
			if r.Kind == "grid" {
				for _, b := range actors {
					if e := b.OnEntryGrid(ev.At); e != nil {
						t.Fatal(e)
					}
				}
			} else {
				full, e := tape.RestoreBatches(ev, last)
				if e != nil {
					t.Fatal(e)
				}
				converted := oldBatches(full)
				for _, b := range actors {
					if r.Kind == "quote" {
						e = b.OnNativeStep(ev.Quote.Observation(), ev.Quote.SourceLine, converted)
					} else {
						e = b.OnNativeForce(ev.At, converted)
					}
					if e != nil {
						t.Fatal(e)
					}
				}
			}
			cursor++
		}
	}
	if cursor != len(input.Events) {
		t.Fatal("旧人工対照Source未消費")
	}
	h, _ := digestValue(input)
	c := Control{Kind: "provided_old108_q20", HistoryClass: "artificial", Session: input.Session, Contract: contract, TapeSHA: h, QuietSeconds: 1200, Books: map[string]json.RawMessage{}, WidthAudits: map[string]json.RawMessage{}, ClockAudits: map[string]json.RawMessage{}, EarlyAudits: map[string]json.RawMessage{}}
	for i, b := range actors {
		r, e := b.Finish()
		if e != nil {
			t.Fatal(e)
		}
		if r.Totals.EntryQuantity == 0 || !r.Complete {
			t.Fatal("旧人工12冊が非ゼロでない")
		}
		key := keys[i]
		c.Books[key], _ = json.Marshal(r)
		c.WidthAudits[key], _ = json.Marshal(b.WidthAudit())
		c.ClockAudits[key], _ = json.Marshal(b.ClockAudit())
		if i >= 8 {
			c.EarlyAudits[key], _ = json.Marshal(b.EarlyAudit())
		}
	}
	raw, e := json.Marshal(struct {
		Scope                        string
		Books, Widths, Clocks, Early map[string]json.RawMessage
	}{"人工旧108Q20保存・自然Sourceなし", c.Books, c.WidthAudits, c.ClockAudits, c.EarlyAudits})
	if e != nil {
		t.Fatal(e)
	}
	path := filepath.Join(t.TempDir(), "旧108人工Native.json")
	if directory := os.Getenv("RUNTIME109_EXPORT"); directory != "" {
		if e = os.MkdirAll(directory, 0700); e != nil {
			t.Fatal(e)
		}
		path = filepath.Join(directory, "旧108_"+input.Session.ID+"_"+h[:16]+".json")
	}
	if e = os.WriteFile(path, raw, 0600); e != nil {
		t.Fatal(e)
	}
	sum, e := digestBytes(raw)
	if e != nil {
		t.Fatal(e)
	}
	c.ReferencePath, c.ReferenceSHA = path, sum
	return c
}

// exportArtificial109 は停止検査が明示したwork内に人工成果物だけを書き出します。
//
// 引数: t(*testing.T)、name(string)、value(any)は検査器・ファイル名・人工値です。
// 返り値: ありません。環境変数が空ならI/Oを行いません。
func exportArtificial109(t *testing.T, name string, value any) {
	t.Helper()
	directory := os.Getenv("RUNTIME109_EXPORT")
	if directory == "" {
		return
	}
	if e := os.MkdirAll(directory, 0700); e != nil {
		t.Fatal(e)
	}
	raw, e := json.Marshal(value)
	if e != nil {
		t.Fatal(e)
	}
	if e = os.WriteFile(filepath.Join(directory, name), raw, 0600); e != nil {
		t.Fatal(e)
	}
}

// digestBytes は人工保存したNative本文をそのまま同定します。
//
// 引数: raw([]byte)は有限JSONです。
// 返り値: string/errorは本文SHA又は不正JSONです。
func digestBytes(raw []byte) (string, error) {
	if !json.Valid(raw) {
		return "", fmt.Errorf("人工Native JSON不正")
	}
	sum := sha256.Sum256(raw)
	return hex.EncodeToString(sum[:]), nil
}

// TestAfterEOFAndSchedulerModel は未観測枠を足さず、名目Record時計と駆動原行時計を分けます。
//
// 引数: t(*testing.T)は空SourceのEOF人工検査です。
// 返り値: ありません。0取引の本検査を利益成功と扱いません。
func TestAfterEOFAndSchedulerModel(t *testing.T) {
	pub := publisherInput(t, 1)
	request := syntheticRequest(t, &pub, 1)
	request.Rows = nil
	full := syntheticRequest(t, &pub, 1)
	for _, row := range full.Rows {
		if row.Board.Time <= request.Session.Start+1200 {
			request.Rows = append(request.Rows, row)
		}
	}
	request.Rows[0].Board.Time++
	request.Rows[0].Board.Received++
	request.Rows[1].Board.Time++
	request.Rows[1].Board.Received++
	pub.Session.EOF = request.Session.Start + 1200
	input := syntheticTape(t, request, 1)
	records := []stream.Record{}
	header, _, e := stream.Build(request, nil, SourceForces(input), func(r stream.Record) error { records = append(records, r); return nil })
	if e != nil {
		t.Fatal(e)
	}
	control, e := FreshControl(input, pub.Session.Contract)
	if e != nil {
		t.Fatal(e)
	}
	c, e := NewCore(input, pub.Session.Contract, "EOFとRecord.At scheduler人工", control, pub)
	if e != nil {
		t.Fatal(e)
	}
	r, e := Run(c, records, header)
	if e != nil {
		t.Fatal(e)
	}
	if header.AfterEOFForces != 1 || len(r.SkippedGrids) == 0 || r.Counts.Grids >= len(request.Grids) || r.PublicationAudit.LastSnapshot.ReplayObservedAt != pub.Session.EOF {
		t.Fatal("EOF後に枠/公開観測を補完")
	}
	if r.PublicationAudit.ClockModel != "csv_end_plus60_at_record_scheduler" || r.PublicationAudit.TriggerLaterRecords == 0 || r.PublicationAudit.MaximumTriggerLeadSeconds != 1 {
		t.Fatal("Record.AtとTrigger.Timeの分離が未確認")
	}
	for _, b := range r.Books {
		if b.Totals.EntryQuantity != 0 || !b.Complete {
			t.Fatal("空Sourceへ架空の参加を補完")
		}
	}
	if r.PublicationAudit.Counts[1800] != 0 {
		t.Fatal("未観測30分を未来EOFから公表")
	}
}
