// Package threeframe は指紋付き5分足を基礎に、因果的な5/15/30分公表を作ります。
package threeframe

const (
	FiveMinutes    = 300
	FifteenMinutes = 900
	ThirtyMinutes  = 1800
)

// Session は形成足・当場公表・数値種を区別する一場の時計です。
type Session struct {
	ID       string  `json:"id"`
	Contract string  `json:"contract"`
	Start    float64 `json:"start"`
	End      float64 `json:"end"`
	EOF      float64 `json:"eof"`
}

// FileRef は呼出側が本文照合を完了したCSVの固定参照です。
type FileRef struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
	Bytes  int64  `json:"bytes"`
}

// OHLC は正常価格と既知性を分けて公表される一足の値です。
type OHLC struct {
	Open  float64 `json:"open"`
	High  float64 `json:"high"`
	Low   float64 `json:"low"`
	Close float64 `json:"close"`
}

// ChildBar は一つの指紋付き5分足です。空IDはBeginSessionで決定的に補います。
type ChildBar struct {
	ID          string  `json:"id"`
	Start       float64 `json:"start"`
	End         float64 `json:"end"`
	OHLC        OHLC    `json:"ohlc"`
	Volume      float64 `json:"volume"`
	Closed      bool    `json:"closed"`
	VolumeKnown bool    `json:"volume_known"`
	Input       FileRef `json:"input"`
	Row         uint64  `json:"row"`
}

// ChildRef は親足が使用した子の値を複製せず、行と指紋を保持します。
type ChildRef struct {
	ID          string  `json:"id"`
	Start       float64 `json:"start"`
	End         float64 `json:"end"`
	Present     bool    `json:"present"`
	PriceKnown  bool    `json:"price_known"`
	VolumeKnown bool    `json:"volume_known"`
	Input       FileRef `json:"input"`
	Row         uint64  `json:"row"`
}

// Value は未知をゼロという支持に変えない数値です。
type Value struct {
	Known bool    `json:"known"`
	Value float64 `json:"value"`
}

// Technical は一公表だけで更新した指標・前値・傾きです。
type Technical struct {
	HistoryBars       uint64 `json:"history_bars"`
	EMA8              Value  `json:"ema8"`
	EMA21             Value  `json:"ema21"`
	PreviousEMA8      Value  `json:"previous_ema8"`
	PreviousEMA21     Value  `json:"previous_ema21"`
	EMA8Delta         Value  `json:"ema8_delta"`
	EMA21Delta        Value  `json:"ema21_delta"`
	Gap               Value  `json:"gap"`
	GapATR            Value  `json:"gap_atr"`
	EMA8DeltaATR      Value  `json:"ema8_delta_atr"`
	EMA21DeltaATR     Value  `json:"ema21_delta_atr"`
	ATR               Value  `json:"atr"`
	PreviousATR       Value  `json:"previous_atr"`
	TR                Value  `json:"tr"`
	RSI               Value  `json:"rsi"`
	PreviousRSI       Value  `json:"previous_rsi"`
	Histogram         Value  `json:"histogram"`
	PreviousHistogram Value  `json:"previous_histogram"`
	CrossSessionJump  Value  `json:"cross_session_jump"`
}

// BarRef はpivotの中心・左右足を時計と公表IDへ結びます。
type BarRef struct {
	ID          string  `json:"id"`
	Start       float64 `json:"start"`
	End         float64 `json:"end"`
	PublishedAt float64 `json:"published_at"`
}

// Pivot は左2足strict・右2足tiesの確認後だけ既知となります。
type Pivot struct {
	Known       bool      `json:"known"`
	Kind        string    `json:"kind"`
	Price       float64   `json:"price"`
	CenterID    string    `json:"center_id"`
	CenterStart float64   `json:"center_start"`
	CenterEnd   float64   `json:"center_end"`
	ConfirmID   string    `json:"confirm_id"`
	ConfirmEnd  float64   `json:"confirm_end"`
	PublishedAt float64   `json:"published_at"`
	Left        [2]BarRef `json:"left"`
	Right       [2]BarRef `json:"right"`
}

// Frame は指標・価格・量・pivotの既知性と公表時計を一度だけ凍結します。
type Frame struct {
	ID                 string      `json:"id"`
	SessionID          string      `json:"session_id"`
	Contract           string      `json:"contract"`
	WidthSeconds       int         `json:"width_seconds"`
	Start              float64     `json:"start"`
	End                float64     `json:"end"`
	NominalAvailable   float64     `json:"nominal_available"`
	AvailableAt        float64     `json:"available_at"`
	ObservedAt         float64     `json:"observed_at"`
	DeliveryAt         float64     `json:"delivery_at"`
	RecordOrdinal      uint64      `json:"record_ordinal"`
	PublicationOrdinal uint64      `json:"publication_ordinal"`
	PriceKnown         bool        `json:"price_known"`
	VolumeKnown        bool        `json:"volume_known"`
	Reason             string      `json:"reason"`
	OHLC               OHLC        `json:"ohlc"`
	Volume             float64     `json:"volume"`
	ChildCount         int         `json:"child_count"`
	Children           [6]ChildRef `json:"children"`
	ChildrenSHA256     string      `json:"children_sha256"`
	Technical          Technical   `json:"technical"`
	PriorHigh          Pivot       `json:"prior_high"`
	PriorLow           Pivot       `json:"prior_low"`
	NewHigh            Pivot       `json:"new_high"`
	NewLow             Pivot       `json:"new_low"`
}

// ScaleSnapshot は数値種だけ既知の場始めを、当場公表と分けます。
type ScaleSnapshot struct {
	WidthSeconds  int       `json:"width_seconds"`
	HasCurrent    bool      `json:"has_current"`
	Fresh         bool      `json:"fresh"`
	SeedOnly      bool      `json:"seed_only"`
	Current       Frame     `json:"current"`
	SeedTechnical Technical `json:"seed_technical"`
}

// Snapshot は指定時刻以前に配送された当場公表だけの値copyです。
type Snapshot struct {
	Session          Session          `json:"session"`
	AsOf             float64          `json:"as_of"`
	ReplayObservedAt float64          `json:"replay_observed_at"`
	HasObserved      bool             `json:"has_observed"`
	RecordOrdinal    uint64           `json:"record_ordinal"`
	Sealed           bool             `json:"sealed"`
	Scales           [3]ScaleSnapshot `json:"scales"`
}

// Scale は5/15/30分の値copyを指定幅で返します。
//
// 引数: widthSeconds(int)は300/900/1800秒です。
// 返り値: ScaleSnapshot/boolは対応値と、対応尺度があったことです。
func (s Snapshot) Scale(widthSeconds int) (ScaleSnapshot, bool) {
	for _, scale := range s.Scales {
		if scale.WidthSeconds == widthSeconds {
			return scale, true
		}
	}
	return ScaleSnapshot{}, false
}
