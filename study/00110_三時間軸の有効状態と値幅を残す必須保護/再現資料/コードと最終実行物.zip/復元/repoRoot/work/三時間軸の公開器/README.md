# 三時間軸の純公開器

Go module/package：`github.com/masayoshi4649/SessionTradeExecuter/threeframe` / `threeframe`。

指紋付き5分足から、同じセッション起点の5/15/30分OHLCV・EMA/RSI/MACD/ATR・確認済みpivotを公開する純部品。市場・原板・CSV本文・Source・金融・ネットワークへ接続しない。呼出側がCSV本文のsize/SHAを照合して子足を渡す。渡された足の行と値は、公開器自身も決定的な子IDへ結合する。

初期仕様は[版2](../複合入口を取得時に再確認する次案/設計案_5分15分30分.md) SHA `9ea8fede6123885e01b6eb60bc7a2c4146897c6f7cc69939a1ad4b91119e4dcb`、同JSON SHA `43bd0af8a132f7cf02d83787aa4d179c3d56e3c9060bd53a01f0266ca089bb89` と、[名目可用性](../複合入口を取得時に再確認する次案/5分15分30分の可用性.json) SHA `fe1e62508750d9a69bfb4db110ad98cd53c9b146e6a0c3e0e1b1812fa1561ccd`。ここで実装するのは公開器だけで、6,497という名目枠上限の実市場再測定ではない。

## API

- `BeginSession(Session, []ChildBar, *Seed) (*Bank, error)`：入力を独立コピーし、当場の公表を作る。空のChildBar.IDは子出典・行・値から決定的に作る。
- `AdvanceObserved(at float64, recordOrdinal uint64) ([]Frame, error)`：単調な観測時計までの新公表を返す。名目終了へ逆算配送しない。
- `SnapshotAt(at float64) (Snapshot, error)`：現在観測frontier以前で、指定時刻以前に配送された最後の当場公表を返す。最新が価格未知なら古い正常値へ逃げない。
- `Seal() (Seed, Snapshot, error)`：時計を進めず、完成公表済みの数値だけを種へ複写する。Seed.Infoで全数値を含む指紋と履歴本数を確認できる。
- `Snapshot.Scale(widthSeconds int)`：300/900/1800秒の値copyを取り出す。

構造・指標・子出典・pivotは全て値型と固定配列。入力sliceや返り値slice/Frame/Snapshotを変更しても内部へ波及しない。Bank自身の更新は一つの呼出順で行い、複数goroutineから同時に更新する用途は対象外。

細部は[仕様](仕様.md)。特に`Snapshot.ReplayObservedAt`は再生のfrontierで、過去時点の問い合わせより先である場合がある。売買に使えるかは各Frameの4公表時計とHasCurrent/Fresh/PriceKnownで判定する。SeedOnlyは現在の当場値があるという意味ではない。

## 人工確認

```powershell
Push-Location 'work/三時間軸の公開器'
go test -count=1 -cover ./...
go vet ./...
go build ./...
Pop-Location
```

線形240子から360公表を作り、全3尺度の解析解を検算する。別計算Decimal60桁の非線形EMA/ATR/RSI/非ゼロMACD、右足公表前pivot、左strict/右ties、鏡像売買、遅配/時間逆行/未来、入力/返り値alias、価格欠足、量だけ未知、carry/限月reset、EOF、数値途中和overflowの原子拒否を検査する。共有70場や新11/09の本文・実指標値・損益を読んでいない。

`検査と停止を記録する.py`は同じGo検査を証拠化し、コード/初期仕様のSHAと停止JSONを作る。ライブラリbuildであり実行CLIは作らない。停止後にコードを変更する場合は旧停止を正本として残し、新しい版の証拠を作る。
