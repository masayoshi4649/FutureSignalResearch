"""人工Go検査と仕様/コード指紋を結び、純公開器の停止を記録する。"""
import hashlib
import json
import re
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(path):
    """
    機能: コード・仕様・検査本文の指紋を読む。
    引数: path(Path)はこの部品又は固定済み仕様です。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    """
    機能: 現コードを人工Go検査し、指紋不変と停止を保存する。
    引数: なし。市場CSV/原板/Source/金融を読まない。
    返り値: なし。検査失敗なら停止成功を書かない。
    """
    refs = [
        (ROOT / "work/複合入口を取得時に再確認する次案/設計案_5分15分30分.md", "9ea8fede6123885e01b6eb60bc7a2c4146897c6f7cc69939a1ad4b91119e4dcb"),
        (ROOT / "work/複合入口を取得時に再確認する次案/設計案_5分15分30分.json", "43bd0af8a132f7cf02d83787aa4d179c3d56e3c9060bd53a01f0266ca089bb89"),
        (ROOT / "work/複合入口を取得時に再確認する次案/5分15分30分の可用性.json", "fe1e62508750d9a69bfb4db110ad98cd53c9b146e6a0c3e0e1b1812fa1561ccd"),
    ]
    assert all(sha(p) == h for p, h in refs)
    code = sorted([*HERE.glob("*.go"), HERE / "go.mod", HERE / "README.md", HERE / "仕様.md", Path(__file__).resolve()])
    before = {str(p): sha(p) for p in code}
    destination = HERE / "検査"
    destination.mkdir(exist_ok=True)
    records = []
    for name, command in [("Go_test", ["go", "test", "-json", "-count=1", "-cover", "./..."]), ("Go_vet", ["go", "vet", "./..."]), ("Go_build", ["go", "build", "./..."])]:
        run = subprocess.run(command, cwd=HERE, capture_output=True, text=True, encoding="utf-8")
        path = destination / f"{name}.txt"
        path.write_text(run.stdout + run.stderr, encoding="utf-8")
        records.append({"command": command, "exit_code": run.returncode, "path": str(path), "sha256": sha(path)})
        assert run.returncode == 0, run.stdout + run.stderr
    test_events = [json.loads(line) for line in (destination / "Go_test.txt").read_text(encoding="utf-8").splitlines() if line.startswith("{")]
    passed = [e["Test"] for e in test_events if e.get("Action") == "pass" and "Test" in e]
    assert len([x for x in passed if "/" not in x]) == 14 and len(passed) == 27
    assert not [e for e in test_events if e.get("Action") == "fail"]
    coverage_text = "".join(e.get("Output", "") for e in test_events)
    coverage = re.search(r"coverage: ([0-9.]+)%", coverage_text)
    assert coverage
    after = {str(p): sha(p) for p in code}
    assert before == after and all(sha(p) == h for p, h in refs)
    version = subprocess.run(["go", "version"], capture_output=True, text=True, encoding="utf-8", check=True).stdout.strip()
    go_path = Path(shutil.which("go"))
    result = {
        "成功": True, "停止": True, "停止UTC": datetime.now(timezone.utc).isoformat(),
        "module": "github.com/masayoshi4649/SessionTradeExecuter/threeframe", "package": "threeframe",
        "scope": "指紋付き人工5分足の純5/15/30公開器・数値・pivot。実70場値/新11月9日本文/金融の確認ではない",
        "市場金融実行": 0, "Source実行": 0, "原板Body読取": 0, "実70値読取": 0, "未使用本文読取": 0,
        "Go": version, "Go実行物": {"path": str(go_path), "sha256": sha(go_path)}, "検査": records,
        "主test成功": 14, "subtest含む成功": 27, "statement_coverage_percent": float(coverage.group(1)),
        "非空経路": ["線形240子360公表の3尺度解析解", "独立Decimal60桁非線形期待値・非ゼロMACD", "非線形鏡像・確認pivot", "13本30分seed→22本と別限月cold", "価格欠足resetと量だけ未知", "遅配非逆算・EOF・alias・数値overflow原子拒否"],
        "初期仕様": [{"path": str(p), "sha256": h} for p, h in refs],
        "コードSHA256前": before, "コードSHA256後": after, "前後不変": True,
        "限界": ["指紋CSV本文照合は呼出側の責務", "実公表配送/全70数値は未確認", "Entry採否/数量/損益を実装しない", "Go標準ライブラリ全閉包は市場固定前の別保存対象"],
    }
    (destination / "Go確認.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    stop = {**result, "検査正本": {"path": str(destination / "Go確認.json"), "sha256": sha(destination / "Go確認.json")}}
    (HERE / "停止.json").write_text(json.dumps(stop, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "主test": 14, "全test": 27, "coverage": float(coverage.group(1)), "停止SHA256": sha(HERE / "停止.json")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
