package threeframe

import (
	"encoding/json"
	"math"
	"reflect"
	"strings"
	"testing"
)

// fixture は共有市場を使わない線形の指紋付き人工5分足を作ります。
//
// 引数: count(int)は正常子足数です。
// 返り値: Session/[]ChildBarは人工時計と価格です。
func fixture(count int) (Session, []ChildBar) {
	start := 1800000000.0
	s := Session{"人工Day", "人工限月", start, start + float64(count+1)*300, start + float64(count)*300 + 60}
	children := make([]ChildBar, count)
	for i := range children {
		c := 1000 + float64(i)
		children[i] = ChildBar{Start: start + float64(i)*300, End: start + float64(i+1)*300, OHLC: OHLC{c - .5, c + 2, c - 2, c},
			Volume: 100 + float64(i), Closed: true, VolumeKnown: true, Input: FileRef{"人工.csv", strings.Repeat("a", 64), 12345}, Row: uint64(i + 2)}
	}
	return s, children
}

// mustBegin は人工の正常設定を開始します。
//
// 引数: t(*testing.T)、s(Session)、children([]ChildBar)、seed(*Seed)は人工入力です。
// 返り値: *Bankは検査用公開器です。
func mustBegin(t *testing.T, s Session, children []ChildBar, seed *Seed) *Bank {
	t.Helper()
	b, err := BeginSession(s, children, seed)
	if err != nil {
		t.Fatal(err)
	}
	return b
}

// regular は5分ごとの名目公表時計を観測して新公表を集めます。
//
// 引数: t(*testing.T)、b(*Bank)は人工検査器です。
// 返り値: []Frameは非ゼロの実公表です。
func regular(t *testing.T, b *Bank) []Frame {
	t.Helper()
	all := []Frame{}
	ordinal := uint64(0)
	for at := b.session.Start + 360; at <= b.session.EOF; at += 300 {
		ordinal++
		frames, err := b.AdvanceObserved(at, ordinal)
		if err != nil {
			t.Fatal(err)
		}
		all = append(all, frames...)
	}
	return all
}

// lastWidth は指定尺度の最後の公表を返します。
//
// 引数: t(*testing.T)、frames([]Frame)、width(int)は人工公表と尺度です。
// 返り値: Frameは一意な最新値です。
func lastWidth(t *testing.T, frames []Frame, width int) Frame {
	t.Helper()
	for i := len(frames) - 1; i >= 0; i-- {
		if frames[i].WidthSeconds == width {
			return frames[i]
		}
	}
	t.Fatalf("尺度%dの公表がありません", width)
	return Frame{}
}

// near は独立した期待値と浮動小数を比較します。
//
// 引数: t(*testing.T)、label(string)、got/want(float64)は検算項目です。
// 返り値: ありません。
func near(t *testing.T, label string, got, want float64) {
	t.Helper()
	if !finite(got, want) || math.Abs(got-want) > 1e-8 {
		t.Fatalf("%s: 取得=%g 期待=%g", label, got, want)
	}
}

// TestGoldenLinear は線形閉値の解析解で全3尺度の数値を検算します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。EMA/ATR/RSI/MACDを実際に既知にして確認します。
func TestGoldenLinear(t *testing.T) {
	s, children := fixture(240)
	b := mustBegin(t, s, children, nil)
	frames := regular(t, b)
	if len(frames) != 360 {
		t.Fatalf("公表数=%d", len(frames))
	}
	for _, width := range widths {
		f := lastWidth(t, frames, width)
		step := float64(width / 300)
		z := f.Technical
		if !f.PriceKnown || !f.VolumeKnown || z.HistoryBars != uint64(240/(width/300)) || !z.PreviousHistogram.Known || !z.EMA21DeltaATR.Known {
			t.Fatalf("非空の数値履歴が成立しません: %+v", f)
		}
		near(t, "EMA8", z.EMA8.Value, 1239-step*3.5)
		near(t, "EMA21", z.EMA21.Value, 1239-step*10)
		near(t, "EMA8傾き", z.EMA8Delta.Value, step)
		near(t, "EMA21傾き", z.EMA21Delta.Value, step)
		near(t, "ATR", z.ATR.Value, step+3)
		near(t, "間隔", z.Gap.Value, step*6.5)
		near(t, "間隔ATR", z.GapATR.Value, step*6.5/(step+3))
		near(t, "傾きATR", z.EMA21DeltaATR.Value, step/(step+3))
		near(t, "RSI", z.RSI.Value, 100)
		near(t, "hist", z.Histogram.Value, 0)
		near(t, "前hist", z.PreviousHistogram.Value, 0)
		if f.NominalAvailable != f.End+60 || f.AvailableAt != f.NominalAvailable || f.ObservedAt != f.NominalAvailable || f.DeliveryAt != f.NominalAvailable || f.ChildCount != width/300 {
			t.Fatal("公表時計又は子数の不一致")
		}
	}
}

// TestInitialKnownCounts は初期SMA・RSI差・MACDsignalの本数を独立に確認します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。
func TestInitialKnownCounts(t *testing.T) {
	s, children := fixture(40)
	frames := regular(t, mustBegin(t, s, children, nil))
	for _, f := range frames {
		if f.WidthSeconds != 300 {
			continue
		}
		n, z := f.Technical.HistoryBars, f.Technical
		checks := []struct {
			name      string
			got       bool
			threshold uint64
		}{
			{"EMA8", z.EMA8.Known, 8}, {"EMA21", z.EMA21.Known, 21}, {"EMA21差", z.EMA21Delta.Known, 22},
			{"ATR", z.ATR.Known, 14}, {"RSI", z.RSI.Known, 15}, {"前RSI", z.PreviousRSI.Known, 16},
			{"hist", z.Histogram.Known, 34}, {"前hist", z.PreviousHistogram.Known, 35},
		}
		for _, c := range checks {
			if c.got != (n >= c.threshold) {
				t.Fatalf("%sの既知本数%d", c.name, n)
			}
		}
	}
}

// TestCompositeAndVolume は3/6子足のOHLCと数量の合成を検算します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。
func TestCompositeAndVolume(t *testing.T) {
	s, children := fixture(6)
	frames := regular(t, mustBegin(t, s, children, nil))
	f := lastWidth(t, frames, 1800)
	if f.OHLC != (OHLC{999.5, 1007, 998, 1005}) || f.Volume != 615 || f.ChildCount != 6 || f.ChildrenSHA256 == "" {
		t.Fatalf("6子合成が不一致: %+v", f)
	}
	for i, ref := range f.Children {
		if !ref.Present || !ref.PriceKnown || !ref.VolumeKnown || ref.Start != s.Start+float64(i)*300 || ref.ID == "" {
			t.Fatal("子出典が欠落")
		}
	}
	children[2].VolumeKnown = false
	unknown := regular(t, mustBegin(t, s, children, nil))
	g := lastWidth(t, unknown, 1800)
	if !g.PriceKnown || g.VolumeKnown || g.Volume != 0 || g.Technical != f.Technical || g.Children[2].VolumeKnown {
		t.Fatal("量不明で価格数値が変化又は量を既知扱い")
	}
}

// TestMissingPriceResetsOnlyAffectedSeries は途中の1子欠足の伝播と再助走を確認します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。
func TestMissingPriceResetsOnlyAffectedSeries(t *testing.T) {
	s, children := fixture(240)
	children = append(children[:120:120], children[121:]...)
	frames := regular(t, mustBegin(t, s, children, nil))
	unknown := map[int]int{}
	for _, f := range frames {
		if !f.PriceKnown {
			unknown[f.WidthSeconds]++
			if f.Technical.HistoryBars != 0 || f.Technical.EMA8.Known || f.NewHigh.Known || f.PriorHigh.Known {
				t.Fatal("欠足公表が古い値を保持")
			}
		}
	}
	if !reflect.DeepEqual(unknown, map[int]int{300: 1, 900: 1, 1800: 1}) {
		t.Fatalf("欠足伝播=%v", unknown)
	}
	for width, want := range map[int]uint64{300: 119, 900: 39, 1800: 19} {
		f := lastWidth(t, frames, width)
		if f.Technical.HistoryBars != want || width == 1800 && f.Technical.EMA21.Known {
			t.Fatalf("尺度%dの再助走が不一致", width)
		}
	}
}

// TestPriceInvalidVolumeIndependent は有限だが不正な価格と正常な量を分離します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。
func TestPriceInvalidVolumeIndependent(t *testing.T) {
	s, children := fixture(6)
	children[2].OHLC.High = children[2].OHLC.Low - 1
	frames := regular(t, mustBegin(t, s, children, nil))
	f := lastWidth(t, frames, 1800)
	if f.PriceKnown || !f.VolumeKnown || f.Volume != 615 || f.OHLC != (OHLC{}) || f.Technical.HistoryBars != 0 {
		t.Fatal("価格不正と量既知を分離できません")
	}
}

// TestObservedClockAndNoBackdating は後からの配送を名目時刻へ戻さないことを確認します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。
func TestObservedClockAndNoBackdating(t *testing.T) {
	s, children := fixture(6)
	b := mustBegin(t, s, children, nil)
	before, err := b.SnapshotAt(s.Start)
	if err != nil || before.Scales[0].HasCurrent {
		t.Fatal("開始前公表")
	}
	if _, err = b.SnapshotAt(s.Start + 1); err == nil {
		t.Fatal("観測前の未来snapshotを許可")
	}
	due := s.Start + 360
	frames, err := b.AdvanceObserved(due-1, 1)
	if err != nil || len(frames) != 0 {
		t.Fatal("名目公開前の公表")
	}
	frames, err = b.AdvanceObserved(due+100, 2)
	if err != nil || len(frames) != 1 || frames[0].DeliveryAt != due+100 {
		t.Fatal("観測遅れを失った公表")
	}
	past, _ := b.SnapshotAt(due)
	if past.Scales[0].HasCurrent {
		t.Fatal("後から得た公表が過去snapshotへ混入")
	}
	now, _ := b.SnapshotAt(due + 100)
	if !now.Scales[0].HasCurrent || !now.Scales[0].Fresh {
		t.Fatal("現在公表が欠落")
	}
	frames, err = b.AdvanceObserved(due+100, 3)
	if err != nil || len(frames) != 0 {
		t.Fatal("同時計の別原行で重複公表")
	}
	stable, _ := b.SnapshotAt(due + 100)
	for _, c := range []struct {
		at      float64
		ordinal uint64
	}{{due + 99, 4}, {due + 100, 3}, {s.EOF + 1, 4}, {math.NaN(), 4}} {
		if _, err = b.AdvanceObserved(c.at, c.ordinal); err == nil {
			t.Fatal("後退/重複/未来EOF/NaNを許可")
		}
		got, _ := b.SnapshotAt(due + 100)
		if !reflect.DeepEqual(got, stable) {
			t.Fatal("拒否呼出しが公開器を変更")
		}
	}
}

// TestEOFDoesNotCloseFuture はEOFを越える完成予定足と未完成親を公表しません。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。
func TestEOFDoesNotCloseFuture(t *testing.T) {
	s, children := fixture(12)
	s.EOF = s.Start + 1800
	b := mustBegin(t, s, children, nil)
	frames, err := b.AdvanceObserved(s.EOF, 1)
	if err != nil {
		t.Fatal(err)
	}
	for _, f := range frames {
		if f.WidthSeconds == 1800 || f.NominalAvailable > s.EOF {
			t.Fatal("未来30分を公表")
		}
	}
	seed, snap, err := b.Seal()
	if err != nil || seed.Info().HistoryBars[2] != 0 || snap.Scales[2].HasCurrent || snap.ReplayObservedAt != s.EOF {
		t.Fatal("Sealが時計又は未完成数値を進めた")
	}
	if _, _, err = b.Seal(); err == nil {
		t.Fatal("重複sealを許可")
	}
	if _, err = b.AdvanceObserved(s.EOF, 2); err == nil {
		t.Fatal("seal後更新を許可")
	}
}

// TestCarryColdAndContractReset は13本からの30分助走、自己alias、限月resetを確認します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。
func TestCarryColdAndContractReset(t *testing.T) {
	a, children := fixture(78)
	b := mustBegin(t, a, children, nil)
	regular(t, b)
	seed, _, err := b.Seal()
	if err != nil || seed.Info().HistoryBars[2] != 13 {
		t.Fatal("13本seedが未形成")
	}
	info := seed.Info()
	next, c2 := fixture(54)
	shift := a.End + 3600 - next.Start
	next.ID = "人工Night"
	next.Start += shift
	next.End += shift
	next.EOF += shift
	for i := range c2 {
		c2[i].Start += shift
		c2[i].End += shift
		c2[i].OHLC.Open += 500
		c2[i].OHLC.High += 500
		c2[i].OHLC.Low += 500
		c2[i].OHLC.Close += 500
	}
	b2 := mustBegin(t, next, c2, &seed)
	start, _ := b2.SnapshotAt(next.Start)
	if !start.Scales[2].SeedOnly || start.Scales[2].HasCurrent || start.Scales[2].SeedTechnical.HistoryBars != 13 {
		t.Fatal("seedと当場公表を混同")
	}
	frames := regular(t, b2)
	f := lastWidth(t, frames, 1800)
	if f.Technical.HistoryBars != 22 || !f.Technical.EMA21Delta.Known {
		t.Fatal("carry再助走の数値不一致")
	}
	first := frames[0]
	near(t, "跨場jump", first.Technical.CrossSessionJump.Value, c2[0].OHLC.Open-children[len(children)-1].OHLC.Close)
	if first.PriorHigh.Known || first.PriorLow.Known {
		t.Fatal("前場pivotを当場構造として継承")
	}
	if seed.Info() != info {
		t.Fatal("次場更新が自己aliasで元種を変更")
	}
	other := mustBegin(t, next, c2, &seed)
	if !reflect.DeepEqual(regular(t, other), frames) {
		t.Fatal("同じ種の二利用が独立でない")
	}
	next.Contract = "別限月"
	rolled := mustBegin(t, next, c2, &seed)
	st, _ := rolled.SnapshotAt(next.Start)
	if st.Scales[0].SeedOnly || st.Scales[0].SeedTechnical.EMA21.Known {
		t.Fatal("別限月に数値を継承")
	}
	fr := regular(t, rolled)
	if lastWidth(t, fr, 1800).Technical.HistoryBars != 9 || lastWidth(t, fr, 1800).Technical.EMA21.Known {
		t.Fatal("別限月coldが成立しません")
	}
	bad := seed
	bad.sealed = false
	if _, err := BeginSession(next, c2, &bad); err == nil {
		t.Fatal("未sealed種を許可")
	}
	bad = seed
	bad.numeric[0].EMA8.Sum = math.Inf(1)
	if _, err := BeginSession(next, c2, &bad); err == nil {
		t.Fatal("非有限種を許可")
	}
	next.Start = a.Start
	if _, err := BeginSession(next, c2, &seed); err == nil {
		t.Fatal("種より過去/重複の場を許可")
	}
}

// TestNonlinearReference は別実装のDecimal60桁期待値で非ゼロMACDとWilder更新を検算します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。終値1000+i+7*(i%5-2)の40足を独立計算した定数と比較します。
func TestNonlinearReference(t *testing.T) {
	s, children := fixture(40)
	for i := range children {
		c := float64(1000 + i + 7*(i%5-2))
		children[i].OHLC = OHLC{c - .5, c + 2, c - 2, c}
	}
	f := lastWidth(t, regular(t, mustBegin(t, s, children, nil)), 300)
	z := f.Technical
	near(t, "非線形EMA8", z.EMA8.Value, 1038.9252271398021009820598560993046909)
	near(t, "非線形EMA21", z.EMA21.Value, 1030.2306490672379412105116275091867875)
	near(t, "非線形前EMA8", z.PreviousEMA8.Value, 1034.9038634654598441197912435562488883)
	near(t, "非線形前EMA21", z.PreviousEMA21.Value, 1027.9537139739617353315627902601054663)
	near(t, "非線形ATR", z.ATR.Value, 13.0804418859076732910167538480874639)
	near(t, "非線形前ATR", z.PreviousATR.Value, 13.3173989540544173903257349133249611)
	near(t, "非線形RSI", z.RSI.Value, 59.6415096689026821905653625180200227)
	near(t, "非線形前RSI", z.PreviousRSI.Value, 57.4662235496087358618597233105328461)
	near(t, "非線形hist", z.Histogram.Value, 1.0064589666854258210447286247118724)
	near(t, "非線形前hist", z.PreviousHistogram.Value, .1794827655179226197549476931947471)
	if !z.Histogram.Known || z.Histogram.Value == 0 || !z.PreviousRSI.Known {
		t.Fatal("非ゼロの独立数値検算が未成立")
	}
}

// TestCopyIsolation は入力・返り値・snapshotの変更が内部へ届かないことを確認します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。
func TestCopyIsolation(t *testing.T) {
	s, children := fixture(6)
	b := mustBegin(t, s, children, nil)
	children[0].OHLC.Close = 999999
	frames, err := b.AdvanceObserved(s.EOF, 1)
	if err != nil {
		t.Fatal(err)
	}
	stable, _ := b.SnapshotAt(s.EOF)
	frames[len(frames)-1].OHLC.Close = 111
	frames[len(frames)-1].Children[0].Input.Path = "外で変更"
	got, _ := b.SnapshotAt(s.EOF)
	if !reflect.DeepEqual(stable, got) || got.Scales[0].Current.OHLC.Close == 999999 {
		t.Fatal("返り値又は入力のalias")
	}
	got.Scales[2].Current.Technical.HistoryBars = 999
	got.Scales[2].Current.Children[0].Input.SHA256 = "外で変更"
	again, _ := b.SnapshotAt(s.EOF)
	if !reflect.DeepEqual(stable, again) {
		t.Fatal("snapshotのalias")
	}
	if _, ok := stable.Scale(60); ok {
		t.Fatal("未対応尺度を許可")
	}
	if _, ok := stable.Scale(1800); !ok {
		t.Fatal("尺度検索が失敗")
	}
	raw, err := json.Marshal(again)
	if err != nil || len(raw) == 0 {
		t.Fatal("有限なsnapshot JSONを返せません")
	}
}

// TestInputRejections は重複・不正出典・時間逆行等を市場読取前に拒否します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。
func TestInputRejections(t *testing.T) {
	s, children := fixture(3)
	cases := map[string]func([]ChildBar) []ChildBar{
		"重複時刻":   func(c []ChildBar) []ChildBar { c[1] = c[0]; return c },
		"逆順":     func(c []ChildBar) []ChildBar { c[0], c[1] = c[1], c[0]; return c },
		"重複行":    func(c []ChildBar) []ChildBar { c[1].Row = c[0].Row; return c },
		"ID不一致":  func(c []ChildBar) []ChildBar { c[0].ID = "偽ID"; return c },
		"SHA不正":  func(c []ChildBar) []ChildBar { c[0].Input.SHA256 = "不正"; return c },
		"size不正": func(c []ChildBar) []ChildBar { c[0].Input.Bytes = 0; return c },
		"行0":     func(c []ChildBar) []ChildBar { c[0].Row = 0; return c },
		"幅不正":    func(c []ChildBar) []ChildBar { c[0].End++; return c },
		"非格子":    func(c []ChildBar) []ChildBar { c[0].Start++; c[0].End++; return c },
		"非有限":    func(c []ChildBar) []ChildBar { c[0].OHLC.Close = math.NaN(); return c },
	}
	for name, change := range cases {
		t.Run(name, func(t *testing.T) {
			if _, err := BeginSession(s, change(append([]ChildBar{}, children...)), nil); err == nil {
				t.Fatal("不正子足を許可")
			}
		})
	}
	for name, scene := range map[string]Session{"開始0": {s.ID, s.Contract, 0, s.End, s.EOF}, "EOF未来": {s.ID, s.Contract, s.Start, s.End, s.End + 1}, "限月なし": {s.ID, "", s.Start, s.End, s.EOF}} {
		t.Run(name, func(t *testing.T) {
			if _, err := BeginSession(scene, children, nil); err == nil {
				t.Fatal("不正場を許可")
			}
		})
	}
}

// TestPivotStrictLeftTiesRight は右2足前の未知、strict/ties、prior/newを確認します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。
func TestPivotStrictLeftTiesRight(t *testing.T) {
	s, c := fixture(6)
	highs := []float64{1010, 1020, 1050, 1050, 1040, 1030}
	lows := []float64{990, 980, 950, 950, 960, 970}
	for i := range c {
		c[i].OHLC = OHLC{1000, highs[i], lows[i], 1000}
	}
	b := mustBegin(t, s, c, nil)
	var fifth Frame
	for i := 0; i < 6; i++ {
		frames, err := b.AdvanceObserved(s.Start+float64(i+1)*300+60, uint64(i+1))
		if err != nil {
			t.Fatal(err)
		}
		f := lastWidth(t, frames, 300)
		if i < 4 && (f.NewHigh.Known || f.NewLow.Known || f.PriorHigh.Known) {
			t.Fatal("右2足の公表前にpivotを確認")
		}
		if i == 4 {
			fifth = f
			if !f.NewHigh.Known || !f.NewLow.Known || f.PriorHigh.Known || f.NewHigh.CenterEnd != s.Start+900 || f.NewHigh.ConfirmEnd != f.End || f.NewHigh.PublishedAt != f.DeliveryAt {
				t.Fatal("右ties又は公表時刻の不一致")
			}
		}
		if i == 5 && (!f.PriorHigh.Known || f.PriorHigh.CenterID != fifth.NewHigh.CenterID || f.NewHigh.Known || f.NewLow.Known) {
			t.Fatal("prior/new又は左strict不一致")
		}
	}
	past, _ := b.SnapshotAt(fifth.DeliveryAt - 1)
	if past.Scales[0].Current.NewHigh.Known {
		t.Fatal("後のpivot確認が過去へ混入")
	}
	if fifth.NewHigh.Left[0].End != s.Start+300 || fifth.NewHigh.Right[1].ID != fifth.ID {
		t.Fatal("pivot左右出典が欠落")
	}
	c[1].OHLC.High = 1050
	frames := regular(t, mustBegin(t, s, c, nil))
	for _, f := range frames {
		if f.WidthSeconds == 300 && f.End == s.Start+1500 && f.NewHigh.Known {
			t.Fatal("左同値をstrict合格に変更")
		}
	}
}

// TestMirror は非線形人工価格の全数値とpivotを売買反転で照合します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。非ゼロMACDと確認pivotがあることも要求します。
func TestMirror(t *testing.T) {
	s, c := fixture(240)
	mirror := append([]ChildBar{}, c...)
	for i := range c {
		price := 1000 + 50*math.Sin(float64(i)*.4) + float64(i)*.2
		c[i].OHLC = OHLC{price - 1, price + 10, price - 10, price}
		mirror[i].OHLC = OHLC{5000 - c[i].OHLC.Open, 5000 - c[i].OHLC.Low, 5000 - c[i].OHLC.High, 5000 - c[i].OHLC.Close}
		mirror[i].Input.SHA256 = strings.Repeat("b", 64)
	}
	a := regular(t, mustBegin(t, s, c, nil))
	b := regular(t, mustBegin(t, s, mirror, nil))
	if len(a) != len(b) {
		t.Fatal("鏡像公表数が不一致")
	}
	nonzero, pivots := 0, 0
	for i, x := range a {
		y := b[i]
		if x.Technical.Histogram.Known && math.Abs(x.Technical.Histogram.Value) > 1e-8 {
			nonzero++
		}
		if x.NewHigh.Known || x.NewLow.Known {
			pivots++
		}
		pairs := []struct {
			name string
			x, y Value
			kind int
		}{
			{"EMA8", x.Technical.EMA8, y.Technical.EMA8, 1}, {"EMA21", x.Technical.EMA21, y.Technical.EMA21, 1},
			{"EMA8差", x.Technical.EMA8Delta, y.Technical.EMA8Delta, 0}, {"EMA21差", x.Technical.EMA21Delta, y.Technical.EMA21Delta, 0},
			{"Gap", x.Technical.Gap, y.Technical.Gap, 0}, {"GapATR", x.Technical.GapATR, y.Technical.GapATR, 0},
			{"ATR", x.Technical.ATR, y.Technical.ATR, 2}, {"TR", x.Technical.TR, y.Technical.TR, 2},
			{"RSI", x.Technical.RSI, y.Technical.RSI, 3}, {"前RSI", x.Technical.PreviousRSI, y.Technical.PreviousRSI, 3},
			{"hist", x.Technical.Histogram, y.Technical.Histogram, 0}, {"前hist", x.Technical.PreviousHistogram, y.Technical.PreviousHistogram, 0},
		}
		for _, p := range pairs {
			if p.x.Known != p.y.Known {
				t.Fatalf("鏡像既知%s", p.name)
			}
			if p.x.Known {
				want := -p.x.Value
				if p.kind == 1 {
					want = 5000 - p.x.Value
				}
				if p.kind == 2 {
					want = p.x.Value
				}
				if p.kind == 3 {
					want = 100 - p.x.Value
				}
				near(t, p.name, p.y.Value, want)
			}
		}
		if x.NewHigh.Known != y.NewLow.Known || x.NewLow.Known != y.NewHigh.Known {
			t.Fatal("鏡像pivot既知不一致")
		}
		if x.NewHigh.Known {
			near(t, "pivot反転", y.NewLow.Price, 5000-x.NewHigh.Price)
		}
		if x.NewLow.Known {
			near(t, "pivot反転", y.NewHigh.Price, 5000-x.NewLow.Price)
		}
	}
	if nonzero < 40 || pivots < 10 {
		t.Fatalf("鏡像検査が空疎: MACD=%d pivot=%d", nonzero, pivots)
	}
}

// TestFlatAndNumericOverflow はゼロATRの正規化未知と内部途中和の原子拒否を確認します。
//
// 引数: t(*testing.T)はGo検査器です。
// 返り値: ありません。
func TestFlatAndNumericOverflow(t *testing.T) {
	s, c := fixture(40)
	for i := range c {
		c[i].OHLC = OHLC{1000, 1000, 1000, 1000}
	}
	f := lastWidth(t, regular(t, mustBegin(t, s, c, nil)), 300)
	if !f.Technical.ATR.Known || f.Technical.ATR.Value != 0 || f.Technical.GapATR.Known || !f.Technical.RSI.Known || f.Technical.RSI.Value != 50 {
		t.Fatal("横ばい数値の扱い不一致")
	}
	s, c = fixture(3)
	for i := range c {
		c[i].OHLC = OHLC{1e308, 1.1e308, 9e307, 1e308}
	}
	b := mustBegin(t, s, c, nil)
	if _, err := b.AdvanceObserved(s.Start+360, 1); err != nil {
		t.Fatal(err)
	}
	before, _ := b.SnapshotAt(s.Start + 360)
	if _, err := b.AdvanceObserved(s.Start+660, 2); err == nil {
		t.Fatal("非有限の途中和を公開")
	}
	after, _ := b.SnapshotAt(s.Start + 360)
	if !reflect.DeepEqual(before, after) {
		t.Fatal("数値異常が部分更新を残した")
	}
}
