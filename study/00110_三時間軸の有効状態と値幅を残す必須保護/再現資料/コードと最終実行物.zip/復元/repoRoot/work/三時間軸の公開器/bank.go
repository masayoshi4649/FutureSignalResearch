package threeframe

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"
	"sort"
)

var widths = [3]int{FiveMinutes, FifteenMinutes, ThirtyMinutes}

// Seed はSealだけが作れる、同限月の数値種です。可変参照を持ちません。
type Seed struct {
	session  Session
	observed float64
	sealed   bool
	numeric  [3]numeric
}

// SeedInfo は数値を変更せず、継承の識別と指紋だけを確認する値です。
type SeedInfo struct {
	Session     Session   `json:"session"`
	ObservedAt  float64   `json:"observed_at"`
	Sealed      bool      `json:"sealed"`
	HistoryBars [3]uint64 `json:"history_bars"`
	SHA256      string    `json:"sha256"`
}

// Info は私有数値種の全数値を含む指紋とメタデータを返します。
//
// 引数: ありません。
// 返り値: SeedInfoは独立した値であり、種の変更には使えません。
func (s Seed) Info() SeedInfo {
	raw, err := json.Marshal(struct {
		Session  Session
		Observed float64
		Sealed   bool
		Numeric  [3]numeric
	}{s.session, s.observed, s.sealed, s.numeric})
	if err != nil {
		return SeedInfo{Session: s.session, ObservedAt: s.observed, Sealed: s.sealed}
	}
	h := sha256.Sum256(raw)
	return SeedInfo{s.session, s.observed, s.sealed, [3]uint64{s.numeric[0].Bars, s.numeric[1].Bars, s.numeric[2].Bars}, hex.EncodeToString(h[:])}
}

// Bank は前史と当場公表を分け、未来の子足を公開しない純公開器です。
type Bank struct {
	session      Session
	plans        []Frame
	cursor       int
	states       [3]scaleState
	seedView     [3]Technical
	carried      bool
	history      [3][]Frame
	observed     float64
	hasObserved  bool
	lastOrdinal  uint64
	publications uint64
	sealed       bool
}

// finite は時計・数値の非有限入力を拒否します。
//
// 引数: values(...float64)は検査値です。
// 返り値: boolは全て有限なら真です。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// digest は値だけの固定構造を決定的な識別子へ結びます。
//
// 引数: value(any)はこの公開器が作る有限な固定構造です。
// 返り値: stringはSHA256です。
func digest(value any) string {
	raw, err := json.Marshal(value)
	if err != nil {
		panic(err)
	}
	h := sha256.Sum256(raw)
	return hex.EncodeToString(h[:])
}

// validRef は本文を開かず、呼出側の指紋付き参照の形を検査します。
//
// 引数: ref(FileRef)は入力CSVの参照です。
// 返り値: boolはpath/size/lowercase SHA256が正常なら真です。
func validRef(ref FileRef) bool {
	if ref.Path == "" || ref.Bytes <= 0 || len(ref.SHA256) != 64 {
		return false
	}
	for _, c := range ref.SHA256 {
		if !(c >= '0' && c <= '9' || c >= 'a' && c <= 'f') {
			return false
		}
	}
	return true
}

// normalPrice は価格の妥当性と出来高を独立に判定します。
//
// 引数: child(ChildBar)は有限性を確認した一つの子足です。
// 返り値: boolは確定・正価格・高安整合があるとき真です。
func normalPrice(child ChildBar) bool {
	x := child.OHLC
	return child.Closed && x.Open > 0 && x.High > 0 && x.Low > 0 && x.Close > 0 && x.High >= math.Max(x.Open, x.Close) && x.Low <= math.Min(x.Open, x.Close) && x.High >= x.Low
}

// BeginSession は固定5分足と任意の前場sealed種を独立コピーして場を作ります。
//
// 引数: scene(Session)、children([]ChildBar)、seed(*Seed)は場時計・指紋付き子足・任意前史です。
// 返り値: *Bank/errorは純公開器又は時計/重複/指紋/種の不整合です。本文I/Oは行いません。
func BeginSession(scene Session, children []ChildBar, seed *Seed) (*Bank, error) {
	if scene.ID == "" || scene.Contract == "" || !finite(scene.Start, scene.End, scene.EOF) || scene.Start <= 0 || scene.End <= scene.Start || scene.EOF < scene.Start || scene.EOF > scene.End || math.Mod(scene.Start, 300) != 0 || math.Mod(scene.End-scene.Start, 300) != 0 {
		return nil, fmt.Errorf("場/限月/開始終了EOFの時計が不正です")
	}
	b := &Bank{session: scene, observed: scene.Start}
	for i := range b.states {
		b.states[i].Numeric = freshNumeric()
	}
	if seed != nil {
		if !seed.sealed || seed.session.ID == "" || seed.session.Contract == "" || scene.Start <= seed.session.Start || scene.Start < seed.observed || scene.Start < seed.session.End {
			return nil, fmt.Errorf("数値種が未sealed又は未来/重複場です")
		}
		for _, n := range seed.numeric {
			if !validNumeric(n) {
				return nil, fmt.Errorf("数値種の数値/期間が不正です")
			}
		}
		if scene.Contract == seed.session.Contract {
			b.carried = true
			for i := range b.states {
				b.states[i].Numeric = seed.numeric[i]
				b.seedView[i] = seed.numeric[i].Latest
			}
		}
	}
	// ----------------------------------------
	// 指紋付きの子足を先に全件検査し、外部sliceへの参照を保持しません。
	indexed := map[float64]ChildBar{}
	seenRows, seenIDs := map[string]bool{}, map[string]bool{}
	previous := math.Inf(-1)
	for _, child := range children {
		if !finite(child.Start, child.End, child.OHLC.Open, child.OHLC.High, child.OHLC.Low, child.OHLC.Close, child.Volume) || child.Start < scene.Start || child.End > scene.End || child.End != child.Start+300 || math.Mod(child.Start-scene.Start, 300) != 0 || child.Start <= previous || !validRef(child.Input) || child.Row == 0 {
			return nil, fmt.Errorf("子5分足の時計/順序/有限性/出典が不正です")
		}
		rowKey := fmt.Sprintf("%s:%d", child.Input.SHA256, child.Row)
		id := "child5:" + digest(struct {
			Session             Session
			Start, End          float64
			Input               FileRef
			Row                 uint64
			OHLC                OHLC
			Volume              float64
			Closed, VolumeKnown bool
		}{scene, child.Start, child.End, child.Input, child.Row, child.OHLC, child.Volume, child.Closed, child.VolumeKnown})
		if seenRows[rowKey] || child.ID != "" && child.ID != id || seenIDs[id] {
			return nil, fmt.Errorf("子5分足の出典行/IDが重複又は不一致です")
		}
		child.ID = id
		indexed[child.Start], seenRows[rowKey], seenIDs[id], previous = child, true, true, child.Start
	}
	// ----------------------------------------
	// 当場起点の完全な子区間だけから、名目公表予定を作ります。
	for _, width := range widths {
		for start := scene.Start; start+float64(width) <= scene.End; start += float64(width) {
			end := start + float64(width)
			if end+60 > scene.EOF {
				continue
			}
			f := Frame{SessionID: scene.ID, Contract: scene.Contract, WidthSeconds: width, Start: start, End: end, NominalAvailable: end + 60, AvailableAt: end + 60, ChildCount: width / 300, PriceKnown: true, VolumeKnown: true}
			for j := 0; j < f.ChildCount; j++ {
				childStart := start + float64(j*300)
				child, present := indexed[childStart]
				ref := ChildRef{Start: childStart, End: childStart + 300, Present: present}
				if !present {
					ref.ID = "missing5:" + digest(struct {
						Session Session
						Start   float64
					}{scene, childStart})
					f.PriceKnown, f.VolumeKnown, f.Reason = false, false, "子5分足が欠測"
				} else {
					ref.ID, ref.Input, ref.Row = child.ID, child.Input, child.Row
					ref.PriceKnown = normalPrice(child)
					ref.VolumeKnown = child.Closed && child.VolumeKnown && child.Volume >= 0
					f.PriceKnown = f.PriceKnown && ref.PriceKnown
					f.VolumeKnown = f.VolumeKnown && ref.VolumeKnown
					if j == 0 {
						f.OHLC = child.OHLC
					} else {
						f.OHLC.High = math.Max(f.OHLC.High, child.OHLC.High)
						f.OHLC.Low = math.Min(f.OHLC.Low, child.OHLC.Low)
						f.OHLC.Close = child.OHLC.Close
					}
					f.Volume += child.Volume
				}
				f.Children[j] = ref
			}
			if !f.PriceKnown {
				f.OHLC = OHLC{}
				if f.Reason == "" {
					f.Reason = "子5分足の価格が不正又は未確定"
				}
			} else if !f.VolumeKnown {
				f.Reason = "価格既知・量不完備"
			} else {
				f.Reason = "価格と量が既知"
			}
			if !f.VolumeKnown {
				f.Volume = 0
			}
			if !finite(f.Volume) {
				return nil, fmt.Errorf("子5分足の量合計が非有限です")
			}
			f.ChildrenSHA256 = digest(f.Children)
			f.ID = "frame:" + digest(struct {
				SessionID, Contract string
				Width               int
				Start, End          float64
				ChildrenSHA256      string
			}{scene.ID, scene.Contract, width, start, end, f.ChildrenSHA256})
			b.plans = append(b.plans, f)
		}
	}
	sort.Slice(b.plans, func(i, j int) bool {
		if b.plans[i].NominalAvailable == b.plans[j].NominalAvailable {
			return b.plans[i].WidthSeconds < b.plans[j].WidthSeconds
		}
		return b.plans[i].NominalAvailable < b.plans[j].NominalAvailable
	})
	return b, nil
}

// validTechnical は数値更新に非有限値が生じた場合を公開前に拒否します。
//
// 引数: t(Technical)は今回の値copyです。
// 返り値: boolは全既知値が有限なら真です。
func validTechnical(t Technical) bool {
	values := []Value{t.EMA8, t.EMA21, t.PreviousEMA8, t.PreviousEMA21, t.EMA8Delta, t.EMA21Delta, t.Gap, t.GapATR, t.EMA8DeltaATR, t.EMA21DeltaATR, t.ATR, t.PreviousATR, t.TR, t.RSI, t.PreviousRSI, t.Histogram, t.PreviousHistogram, t.CrossSessionJump}
	for _, v := range values {
		if v.Known && !finite(v.Value) {
			return false
		}
	}
	return true
}

// validNumeric は未知の途中和を含め、数値器全体を公開前に検査します。
//
// 引数: n(numeric)は内部数値の値copyです。
// 返り値: boolは全値と期間が有効なとき真です。
func validNumeric(n numeric) bool {
	means := []mean{n.EMA8, n.EMA21, n.EMA12, n.EMA26, n.Signal, n.Gain, n.Loss, n.ATR}
	periods := []int{8, 21, 12, 26, 9, 14, 14, 14}
	for i, m := range means {
		if m.Period != periods[i] || m.Count < 0 || m.Count > m.Period || m.Known != (m.Count == m.Period) || !finite(m.Sum, m.Value) {
			return false
		}
	}
	return finite(n.PreviousClose, n.RSI.Value, n.Histogram.Value) && validTechnical(n.Latest)
}

// AdvanceObserved は単調な実観測時計までの公表を一度だけ配送します。
//
// 引数: at(float64)、recordOrdinal(uint64)は実入力の観測時計と場内でstrict増加する識別番号です。
// 返り値: []Frame/errorは新公表の値copy又は時間/数値異常です。同時計の別原行は重複公表しません。
func (b *Bank) AdvanceObserved(at float64, recordOrdinal uint64) ([]Frame, error) {
	if b == nil || b.sealed {
		return nil, fmt.Errorf("公開器が未開始又はsealedです")
	}
	if !finite(at) || at < b.session.Start || at > b.session.EOF || b.hasObserved && at < b.observed || recordOrdinal == 0 || recordOrdinal <= b.lastOrdinal {
		return nil, fmt.Errorf("観測時計/原行番号が未来EOF/後退/重複です")
	}
	states := b.states
	cursor, publications := b.cursor, b.publications
	frames := []Frame{}
	for cursor < len(b.plans) && b.plans[cursor].NominalAvailable <= at {
		f := b.plans[cursor]
		f.ObservedAt, f.DeliveryAt, f.RecordOrdinal = at, at, recordOrdinal
		publications++
		f.PublicationOrdinal = publications
		index := 0
		for widths[index] != f.WidthSeconds {
			index++
		}
		f = states[index].apply(f)
		if !validTechnical(f.Technical) || !validNumeric(states[index].Numeric) {
			return nil, fmt.Errorf("指標値が非有限のため公表を拒否します")
		}
		frames = append(frames, f)
		cursor++
	}
	// ----------------------------------------
	// 数値を全て検査した後だけ、観測と公表を一括で確定します。
	b.states, b.cursor, b.publications = states, cursor, publications
	b.observed, b.hasObserved, b.lastOrdinal = at, true, recordOrdinal
	for _, f := range frames {
		for i, w := range widths {
			if f.WidthSeconds == w {
				b.history[i] = append(b.history[i], f)
			}
		}
	}
	return frames, nil
}

// SnapshotAt は指定時点までに実配送された最後の公表を尺度別に返します。
//
// 引数: at(float64)は当場開始以後・現在の観測frontier以下の名目判断時計です。
// 返り値: Snapshot/errorは不変値copy又は未来/場外時計です。後から得た公表は過去snapshotへ入りません。
func (b *Bank) SnapshotAt(at float64) (Snapshot, error) {
	if b == nil || !finite(at) || at < b.session.Start || at > b.observed {
		return Snapshot{}, fmt.Errorf("snapshot時計が未開始/過去場外/未来です")
	}
	s := Snapshot{Session: b.session, AsOf: at, ReplayObservedAt: b.observed, HasObserved: b.hasObserved, RecordOrdinal: b.lastOrdinal, Sealed: b.sealed}
	for i, w := range widths {
		x := ScaleSnapshot{WidthSeconds: w, SeedTechnical: b.seedView[i]}
		for j := len(b.history[i]) - 1; j >= 0; j-- {
			f := b.history[i][j]
			if f.NominalAvailable <= at && f.AvailableAt <= at && f.ObservedAt <= at && f.DeliveryAt <= at {
				x.HasCurrent, x.Current = true, f
				x.Fresh = at-f.AvailableAt < float64(w)
				break
			}
		}
		x.SeedOnly = b.carried && !x.HasCurrent
		s.Scales[i] = x
	}
	return s, nil
}

// Seal は現在観測までの完成数値だけを値copyし、時計を進めません。
//
// 引数: ありません。
// 返り値: Seed/Snapshot/errorは次場用の数値種・末尾公表・重複seal等の異常です。
func (b *Bank) Seal() (Seed, Snapshot, error) {
	if b == nil || b.sealed {
		return Seed{}, Snapshot{}, fmt.Errorf("公開器が未開始又は既にsealedです")
	}
	b.sealed = true
	s, err := b.SnapshotAt(b.observed)
	if err != nil {
		return Seed{}, Snapshot{}, err
	}
	seed := Seed{session: b.session, observed: b.observed, sealed: true}
	for i := range seed.numeric {
		seed.numeric[i] = b.states[i].Numeric
	}
	return seed, s, nil
}
