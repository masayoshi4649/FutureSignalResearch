"""実市場を開かず、手製36条件×70場で欠落・混同・指紋拒否を検査する。"""

from datetime import date, timedelta
from decimal import Decimal
import json
from pathlib import Path
import tempfile
import unittest

import 報告を作る as R


def serial(value):
    """機能: 保存正本と同じ数値型で人工JSONを作る。

    引数: value(any)はDecimal等の値。
    返り値: int又はfloat。非数値型は拒否する。
    """
    if isinstance(value, Decimal):
        return int(value) if value == value.to_integral_value() else float(value)
    raise TypeError(type(value).__name__)


def fixture() -> dict:
    """機能: 費用、遅延、0件候補を持つ全70の手製正本を作る。

    引数: なし。実市場やNativeを参照しない。
    返り値: dictは保存正本と同じ数値直列化を経た人工値。
    """
    dates, current = [], date(2026, 9, 21)
    while current <= date(2026, 11, 6):
        if current.weekday() < 5:
            dates.append(current.isoformat())
        current += timedelta(days=1)
    sessions = [f"{d}_{s}" for d in dates for s in ("Day", "Night")]
    value = {"試行": 110, "成功": True, "前後不変": True, "stage": "full70", "場数": 70, "会計数": 2520,
             "主key": list(R.KEYS), "Actor設定": {}, "集計": {}, "場別": [], "金融条件SHA256": R.ALIGNED_SHA}
    for index, key in enumerate(R.KEYS):
        candidate, cost, delay = key.rsplit("_", 2)
        c, d = int(cost[1:]), int(delay[1:])
        value["Actor設定"][key] = {"candidate": candidate, "slip_pts": c, "delay_seconds": d}
        selected, carry, peak, dd = [], 0, 0, 0
        for sid in sessions:
            zero = index == 35
            positive, negative = (0, 0) if zero else (1000 - d * 10, -500 - c * 600)
            net, fee, slip = positive + negative, 0 if zero else 231, 0 if zero else c * 600
            active = 0 if zero else 30 + index
            row = {"session": sid, "key": key, "positions": 0 if zero else 2, "entry_quantity": 0 if zero else 3,
                   "positive_positions": 0 if zero else 1, "negative_positions": 0 if zero else 1, "zero_positions": 0,
                   "gross_yen": net + fee + slip, "fee_yen": fee, "slip_yen": slip, "net_yen": net, "closed_net_yen": net,
                   "positive_yen": positive, "negative_yen": negative, "unit_positive_closed_negative": 0 if zero else 1,
                   "activated_closed_negative": 0 if zero or index % 2 else 1,
                   "open_buy": 0, "open_sell": 0, "pending_buy": 0, "pending_sell": 0,
                   "場内時価DD": abs(net) + 200, "保存最大時価": max(0, net) + 100, "保存最小時価": min(0, net) - 100,
                   "活動主表": {"active": active, "wait": 114 - active - 2, "unknown": 2, "denom": 114},
                   "活動副表": {"active": active, "wait": 110 - active - 2, "unknown": 2, "denom": 110}}
            selected.append(row)
            dd = max(dd, row["場内時価DD"], peak - carry - row["保存最小時価"])
            peak = max(peak, carry + row["保存最大時価"])
            carry += net
        a = {name: sum(row[name] for row in selected) for name in R.SUM_FIELDS}
        a["PF"] = Decimal(a["positive_yen"]) / -a["negative_yen"] if a["negative_yen"] else None
        a["保存点連結時価DD"] = dd
        for label in ("活動主表", "活動副表"):
            a[label] = {name: sum(row[label][name] for row in selected) for name in ("active", "wait", "unknown", "denom")}
        value["集計"][key] = a
        value["場別"].extend(selected)
    return json.loads(json.dumps(value, default=serial), parse_float=Decimal)


class 報告検査(unittest.TestCase):
    """機能: 集計表が不完全・混同した結果を正式らしく見せないことを検査する。"""

    def test_全件と別費用と十一月六日(self):
        """機能: 36×70・0件候補・11/06全72行を保持する。

        引数: self(報告検査)は検査器。
        返り値: None。
        """
        value = fixture()
        grouped = R.validate(value)
        self.assertEqual(sum(len(v) for v in grouped.values()), 2520)
        text, differences = R.comparisons(value)
        self.assertEqual(len(differences), 48)
        self.assertEqual(len({(r["区分"], r["基準"], r["比較"]) for r in differences}), 48)
        self.assertIn("実入口の一致はこの集計だけでは主張しない", text)
        output = R.documents(value, (R.TRIAL / "市場前仕様/設定と結果.md").read_text(encoding="utf-8-sig"), "f" * 64)
        self.assertEqual(set(output), {"README案.md", "設定と結果案.md", "CSV閲覧案内.md"})
        nov = output["README案.md"].split("### 11/06の実現額・全36条件")[1].split("## 全36費用条件")[0]
        self.assertEqual(nov.count("2026-11-06_Day"), 36)
        self.assertEqual(nov.count("2026-11-06_Night"), 36)
        self.assertEqual(output["設定と結果案.md"].count("70場／7,980枠"), 36)
        self.assertIn("entry_E2_L1_G4_C5_D1 | +0 | 0 | 0 | —", output["README案.md"])
        self.assertIn("実現純額", output["CSV閲覧案内.md"])

    def test_改竄と欠落を拒否(self):
        """機能: 途中結果、重複、会計差、分母除外、費用混同を拒否する。

        引数: self(報告検査)は検査器。
        返り値: None。12破壊反例を検査する。
        """
        mutations = {
            "first2": lambda v: v.__setitem__("stage", "first2"),
            "失敗": lambda v: v.__setitem__("成功", False),
            "場末建玉": lambda v: v["場別"][0].__setitem__("open_buy", 1),
            "欠落": lambda v: v["場別"].pop(),
            "重複場": lambda v: v["場別"][1].__setitem__("session", v["場別"][0]["session"]),
            "純額差": lambda v: v["場別"][0].__setitem__("net_yen", 0),
            "集計差": lambda v: v["集計"][R.KEYS[0]].__setitem__("positions", 0),
            "PF差": lambda v: v["集計"][R.KEYS[0]].__setitem__("PF", Decimal(9)),
            "DD差": lambda v: v["集計"][R.KEYS[0]].__setitem__("保存点連結時価DD", 0),
            "未知除外": lambda v: v["場別"][0]["活動主表"].__setitem__("denom", 112),
            "費用混同": lambda v: v["Actor設定"][R.KEYS[0]].__setitem__("slip_pts", 5),
            "並べ替え": lambda v: v["主key"].reverse()}
        for label, mutation in mutations.items():
            with self.subTest(label=label):
                value = fixture()
                mutation(value)
                with self.assertRaises(ValueError):
                    R.validate(value)

    def test_指紋拒否と生成の前後不変(self):
        """機能: 誤指紋・誤保存結合・既存先を拒否し成功案だけ新規保存する。

        引数: self(報告検査)は検査器。
        返り値: None。人工JSON以外の金融結果は読まない。
        """
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            result = base / "結果.json"
            result.write_text(json.dumps(fixture(), ensure_ascii=False, default=serial), encoding="utf-8")
            result_sha = R.sha(result)
            check = base / "保存会計の確認.json"
            value = {"成功": True, "前後不変": True, "不一致数": 0, "会計": 2520, "資源": 2520, "旧対照": 280,
                     "出力SHA256": {"結果.json": result_sha}, "金融条件SHA256": R.ALIGNED_SHA}
            check.write_text(json.dumps(value), encoding="utf-8")
            check_sha = R.sha(check)
            with self.assertRaises(ValueError):
                R.generate(result, "0" * 64, check, check_sha, base / "誤指紋")
            self.assertFalse((base / "誤指紋").exists())
            proof = R.generate(result, result_sha, check, check_sha, base / "成功案")
            self.assertEqual((proof["会計"], proof["条件"], proof["比較差分"]), (2520, 36, 48))
            self.assertEqual((R.sha(result), R.sha(check)), (result_sha, check_sha))
            with self.assertRaises(ValueError):
                R.generate(result, result_sha, check, check_sha, base / "成功案")
            value["出力SHA256"]["結果.json"] = "a" * 64
            check.write_text(json.dumps(value), encoding="utf-8")
            with self.assertRaises(ValueError):
                R.generate(result, result_sha, check, R.sha(check), base / "誤結合")
            self.assertFalse((base / "誤結合").exists())

    def test_市場前表の誤対応を拒否(self):
        """機能: R番号と費用の誤対応を更新せず拒否する。

        引数: self(報告検査)は検査器。
        返り値: None。
        """
        template = (R.TRIAL / "市場前仕様/設定と結果.md").read_text(encoding="utf-8-sig")
        for changed in (template.replace("| R36 |", "| R35 |"), template.replace("| R01 | entry_E0_G0 | C0/D0", "| R01 | entry_E0_G0 | C5/D0")):
            with self.assertRaises(ValueError):
                R.settings(fixture(), changed)


if __name__ == "__main__":
    unittest.main(verbosity=2)
