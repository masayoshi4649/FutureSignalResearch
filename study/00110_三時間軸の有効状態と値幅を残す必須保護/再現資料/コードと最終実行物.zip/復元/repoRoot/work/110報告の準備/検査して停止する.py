"""手製報告検査を実行し、成功した新helperを一度だけ停止する。"""

import ast
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def sha(path: Path) -> str:
    """機能: 所有ファイルの全バイト指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def owned() -> dict[str, str]:
    """機能: 明示した所有4ファイルの指紋を作る。

    引数: なし。
    返り値: dict[str,str]はRoot相対名とSHA256。
    """
    names = ("報告を作る.py", "報告の人工検査.py", "検査して停止する.py", "README.md")
    return {str((HERE / name).relative_to(ROOT)).replace("\\", "/"): sha(HERE / name) for name in names}


def main() -> None:
    """機能: 人工検査成功と関数コメントを確認して停止JSONを保存する。

    引数: なし。正式文書と金融結果は読み書きしない。
    返り値: None。失敗又は既停止時は成功記録を作らない。
    """
    if (HERE / "停止.json").exists() or (HERE / "人工確認.json").exists():
        raise ValueError("停止出力は既存。固定版を上書きしない")
    before = owned()
    functions = 0
    for name in before:
        path = ROOT / name
        if path.suffix != ".py":
            continue
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                doc = ast.get_docstring(node) or ""
                if not ("\n" in doc and all(label in doc for label in ("機能", "引数", "返り値"))):
                    raise ValueError("複数行の関数コメント不足: " + node.name)
                functions += 1
    execution = subprocess.run([sys.executable, "-B", "-X", "utf8", str(HERE / "報告の人工検査.py")],
                               cwd=ROOT, capture_output=True, text=True, encoding="utf-8")
    after = owned()
    if execution.returncode != 0 or before != after:
        print(execution.stdout + execution.stderr)
        raise ValueError("人工検査失敗又はコード差")
    proof = {"成功": True, "UTC": datetime.now(timezone.utc).isoformat(), "主test": 4, "破壊反例": 12,
             "関数コメント": functions, "終了コード": execution.returncode, "標準出力": execution.stdout,
             "標準エラー": execution.stderr, "コード前後不変": True, "市場本文読取": 0, "金融再実行": 0,
             "実金融結果読取": 0, "正式文書変更": 0, "未見11月09本文読取": 0}
    (HERE / "人工確認.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    stop = {"成功": True, "停止": True, "UTC": datetime.now(timezone.utc).isoformat(), "所有コードSHA256": before,
            "人工確認SHA256": sha(HERE / "人工確認.json"), "自己コード前後不変": True, "主test": 4, "破壊反例": 12,
            "範囲": "手製36×70場の保存集計から報告案・R36・CSV閲覧案内・48実現差を生成",
            "実金融結果読取": 0, "正式文書変更": 0, "金融実行": 0, "市場本文読取": 0, "採用": False, "研究目標達成": False}
    (HERE / "停止.json").write_text(json.dumps(stop, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "停止SHA256": sha(HERE / "停止.json"), "主test": 4, "関数": functions}, ensure_ascii=False))


if __name__ == "__main__":
    main()
