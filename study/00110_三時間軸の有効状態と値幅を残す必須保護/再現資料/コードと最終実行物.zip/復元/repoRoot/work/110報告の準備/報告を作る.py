"""試行110の全70場保存正本から正式保存前の報告案を作る。"""

from __future__ import annotations
import argparse
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / "study/00110_三時間軸の有効状態と値幅を残す必須保護"
ORIGINAL_SHA = "232271e3884d8f2d40d26b63372a606e8fbab5b108f8b334cdb180d144b1648f"
ALIGNED_SHA = "e0f84c5f836a3cb58b6d75c12f08c40e910b661043516e1e642143b6026b9fba"
TEMPLATE_SHA = "827a1895e946d9487cec4ba118ae13f1820cfeace09b0088f7c4cb1c569e7d83"
ARMS = ("entry_E0", "entry_E2_L0", "entry_E2_L1")
GUARDS = ("G0", "G3", "G4")
COSTS = ((0, 0), (0, 1), (5, 0), (5, 1))
KEYS = tuple(f"{arm}_{guard}_C{c}_D{d}" for arm in ARMS for guard in GUARDS for c, d in COSTS)
SUM_FIELDS = ("positions", "entry_quantity", "gross_yen", "fee_yen", "slip_yen", "net_yen", "closed_net_yen",
              "positive_yen", "negative_yen", "positive_positions", "negative_positions", "zero_positions",
              "unit_positive_closed_negative", "activated_closed_negative")
ZERO = Decimal(0)


def require(condition: bool, message: str) -> None:
    """機能: 不成立の保存条件を明示して拒否する。

    引数: condition(bool)、message(str)は成立条件と拒否理由。
    返り値: None。不成立時はValueErrorを送出する。
    """
    if not condition:
        raise ValueError(message)


def sha(path: Path) -> str:
    """機能: 全バイト指紋を計算する。

    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_ref(path: Path, expected: str) -> dict:
    """機能: 期待指紋と一致したJSONだけを読む。

    引数: path(Path)、expected(str)は対象と期待SHA256。
    返り値: dictは小数をDecimalで保持した値。
    """
    require(bool(re.fullmatch(r"[a-f0-9]{64}", expected)), "期待指紋の形式")
    require(sha(path) == expected, "入力指紋差: " + str(path))
    return json.loads(path.read_text(encoding="utf-8-sig"), parse_float=Decimal)


def validate(value: dict) -> dict[str, list[dict]]:
    """機能: 36条件の全70場、閉場残、集計と分母を再確認する。

    引数: value(dict)は独立保存後の結果。
    返り値: dict[str,list[dict]]は条件ごとの時系列。金融再走は行わない。
    """
    require(value["試行"] == 110 and value["成功"] is True and value["前後不変"] is True, "保存成功")
    require(value["stage"] == "full70" and value["場数"] == 70 and value["会計数"] == 2520, "全70の2520会計")
    require(tuple(value["主key"]) == KEYS and set(value["集計"]) == set(KEYS), "36条件の本名と順序")
    require(len(value["場別"]) == 2520 and set(value["Actor設定"]) == set(KEYS), "場別と設定の完全性")
    grouped = {key: sorted((r for r in value["場別"] if r["key"] == key), key=lambda r: r["session"]) for key in KEYS}
    reference = None
    for key, rows in grouped.items():
        sessions = tuple(r["session"] for r in rows)
        require(len(sessions) == len(set(sessions)) == 70, "同条件の全70場")
        require(all(re.fullmatch(r"2026-\d{2}-\d{2}_(Day|Night)", s) for s in sessions), "場名")
        require(len({s[:10] for s in sessions}) == 35 and sum(s.endswith("_Day") for s in sessions) == 35, "35日の日夜")
        require(sessions[0] == "2026-09-21_Day" and sessions[-1] == "2026-11-06_Night", "既使用期間")
        if reference is None:
            reference = sessions
        require(sessions == reference, "36候補の同一70場")
        c, a = value["Actor設定"][key], value["集計"][key]
        require(key == f"{c['candidate']}_C{c['slip_pts']}_D{c['delay_seconds']}", "設定と条件ID")
        carry = peak = dd = ZERO
        for r in rows:
            require(r["gross_yen"] - r["fee_yen"] - r["slip_yen"] == r["net_yen"] == r["closed_net_yen"], "場別純額・完結")
            require(all(r[n] == 0 for n in ("open_buy", "open_sell", "pending_buy", "pending_sell")), "場末残0")
            require(r["positive_yen"] + r["negative_yen"] == r["net_yen"], "実現正負の分解")
            require(sum(r[n] for n in ("positive_positions", "negative_positions", "zero_positions")) == r["positions"], "玉の正負件数")
            require(0 <= r["activated_closed_negative"] <= r["positions"] and 0 <= r["unit_positive_closed_negative"] <= r["positions"], "赤字件数の範囲")
            dd = max(dd, r["場内時価DD"], peak - (carry + r["保存最小時価"]))
            peak = max(peak, carry + r["保存最大時価"])
            carry += r["net_yen"]
        for name in SUM_FIELDS:
            require(sum(r[name] for r in rows) == a[name], "集計差: " + key + "/" + name)
        require(dd == a["保存点連結時価DD"], "保存点DD連結")
        pf = Decimal(a["positive_yen"]) / -Decimal(a["negative_yen"]) if a["negative_yen"] < 0 else None
        require((pf is None and a["PF"] is None) or
                (pf is not None and a["PF"] is not None and abs(pf - a["PF"]) <= Decimal("1e-12") * max(1, abs(pf))), "PFの実損失分母")
        for label, expected in (("活動主表", 7980), ("活動副表", 7700)):
            s = a[label]
            for r in rows:
                d = r[label]
                require(d["active"] + d["wait"] + d["unknown"] == d["denom"], "全予定枠の内訳")
            for name in ("active", "wait", "unknown", "denom"):
                require(sum(r[label][name] for r in rows) == s[name], "活動の集計差")
            require(s["denom"] == expected and 0 <= s["active"] <= expected, "固定主副分母")
    return grouped


def table(headers: list[str], rows: list[list[str]]) -> str:
    """機能: 同じ列数のMarkdown表を作る。

    引数: headers(list[str])、rows(list[list[str]])は見出しとデータ。
    返り値: strは前後空行を持つ表。
    """
    require(all(len(r) == len(headers) for r in rows), "表の列数")
    return "\n" + "\n".join("| " + " | ".join(r) + " |" for r in [headers, ["---"] * len(headers), *rows]) + "\n\n"


def money(number: Decimal | int) -> str:
    """機能: 円を符号と桁区切り付きで表示する。

    引数: number(Decimal|int)は実現又は保存値。
    返り値: strは端数を保持した表示。
    """
    return f"{number:+,}"


def percent(numerator: Decimal | int, denominator: Decimal | int) -> str:
    """機能: 分母0を成功率0とせずパーセント表示する。

    引数: numerator/denominator(Decimal|int)は件数。
    返り値: strは小数2桁又は未成立の記号。
    """
    return f"{100 * numerator / denominator:.2f}%" if denominator else "—"


def main_table(value: dict, all_costs: bool = False) -> str:
    """機能: 純額、勝率、PF、DD、活動と利益後赤字を表示する。

    引数: value(dict)、all_costs(bool)は正本と感度全表示指定。
    返り値: strは9又は36行の表。
    """
    rows = []
    for key in KEYS:
        if not all_costs and not key.endswith("_C0_D0"):
            continue
        a = value["集計"][key]
        pf = f"{a['PF']:.3f}" if a["PF"] is not None else ("—（実損失なし）" if a["positions"] else "—")
        rows.append([key, money(a["net_yen"]), str(a["positions"]), str(a["entry_quantity"]),
                     percent(a["positive_positions"], a["positions"]), pf, money(a["保存点連結時価DD"]),
                     percent(a["活動主表"]["active"], 7980), percent(a["活動副表"]["active"], 7700),
                     str(a["unit_positive_closed_negative"]), str(a["activated_closed_negative"])])
    return table(["条件ID", "費用後純額・円", "新規件数", "新規枚数", "費用後正益の割合", "PF", "保存点時価DD・円", "主参加率", "副参加率", "費用後正益→赤字・件", "起動後赤字・件"], rows)


def comparisons(value: dict) -> tuple[str, list[dict]]:
    """機能: 技法、受付寿命、保護の実現差を別表にする。

    引数: value(dict)は検査後の36集計。
    返り値: tuple[str,list[dict]]はMarkdownと差分48行。実入口一致は主張しない。
    """
    records, body = [], ""
    pairs = {"入口技法（E2L0−E0L0）": [(f"entry_E0_{g}", f"entry_E2_L0_{g}") for g in GUARDS],
             "受付寿命（E2L1−E2L0）": [(f"entry_E2_L0_{g}", f"entry_E2_L1_{g}") for g in GUARDS],
             "保護（G3/G4−G0）": [(f"{a}_G0", f"{a}_{g}") for a in ARMS for g in ("G3", "G4")]}
    for kind, candidates in pairs.items():
        rows = []
        for before, after in candidates:
            for c, d in COSTS:
                left, right = f"{before}_C{c}_D{d}", f"{after}_C{c}_D{d}"
                a, b = value["集計"][left], value["集計"][right]
                record = {"区分": kind, "基準": left, "比較": right, "実現純額差": b["net_yen"] - a["net_yen"],
                          "新規件数差": b["positions"] - a["positions"], "参加枠差": b["活動主表"]["active"] - a["活動主表"]["active"],
                          "利益後赤字差": b["unit_positive_closed_negative"] - a["unit_positive_closed_negative"],
                          "起動後赤字差": b["activated_closed_negative"] - a["activated_closed_negative"]}
                records.append(record)
                rows.append([left, right, money(record["実現純額差"]), f"{record['新規件数差']:+}", f"{record['参加枠差']:+}", f"{record['利益後赤字差']:+}", f"{record['起動後赤字差']:+}"])
        body += "### " + kind + "\n" + table(["基準", "比較", "実現純額差・円", "件数差", "主参加枠差", "利益後赤字差", "起動後赤字差"], rows)
    body += "差分は比較の実運用候補から基準を引いた値。保護の違いが保有時間・余力・後続L1受付まで変える場合があり、実入口の一致はこの集計だけでは主張しない。単独の因果効果、未参加又は退出後の仮想利益とは解釈しない。\n\n"
    return body, records


def periods(grouped: dict[str, list[dict]]) -> str:
    """機能: 主費用の5期・日夜と全36条件の11/06を実現額で並べる。

    引数: grouped(dict[str,list[dict]])は全70の時系列。
    返り値: strは固定14場×5期、日夜、11/06の表。
    """
    rows, details = [], []
    for key, source in grouped.items():
        if key.endswith("_C0_D0"):
            net = [sum(r["net_yen"] for r in source[i:i + 14]) for i in range(0, 70, 14)]
            day = [r for r in source if r["session"].endswith("_Day")]
            night = [r for r in source if r["session"].endswith("_Night")]
            rows.append([key, *[money(n) for n in net], money(sum(r["net_yen"] for r in day)), money(sum(r["net_yen"] for r in night)),
                         percent(sum(r["活動主表"]["active"] for r in day), sum(r["活動主表"]["denom"] for r in day)),
                         percent(sum(r["活動主表"]["active"] for r in night), sum(r["活動主表"]["denom"] for r in night))])
        for r in source:
            if r["session"].startswith("2026-11-06_"):
                details.append([key, r["session"], money(r["net_yen"]), str(r["positions"]), str(r["unit_positive_closed_negative"]),
                                str(r["activated_closed_negative"]), percent(r["活動主表"]["active"], r["活動主表"]["denom"])])
    text = table(["条件ID", "1〜14場・円", "15〜28場・円", "29〜42場・円", "43〜56場・円", "57〜70場・円", "デイ計・円", "ナイト計・円", "デイ参加率", "ナイト参加率"], rows)
    text += "5期は時系列14場ずつの記述集計で、固定後の未見テストではない。日夜の参加率も未知・静観を分母に残す。\n\n### 11/06の実現額・全36条件\n"
    return text + table(["条件ID", "セッション", "費用後純額・円", "新規件数", "利益後赤字・件", "起動後赤字・件", "主参加率"], details)


def settings(value: dict, template: str) -> str:
    """機能: 全56×9表を残し、R36の結果欄を埋める。

    引数: value(dict)、template(str)は正本と市場前snapshot。
    返り値: strは正式上書き前の表案。指標単独の効果を主張しない。
    """
    text = template.replace("設計・市場実行前の表。未実行を0円や成立としない。使用版6、全56手法×9尺度を保持する。",
                            "全70場・2,520会計の独立保存正本から結果欄を記入。使用版6、全56手法×9尺度を保持する。採用と目標達成は別に判定する。市場前原本は市場前仕様/設定と結果.mdに保持する。")
    text = re.sub(r"(R[0-9〜/]+)・未検証", r"\1・複合評価済", text)
    text = text.replace("適用設定の詳細参照・未検証", "適用設定の詳細参照・複合評価済")
    lines, seen = text.splitlines(), []
    for i, line in enumerate(lines):
        match = re.match(r"^\| R(\d{2}) \|", line)
        if not match:
            continue
        index = int(match.group(1)) - 1
        require(0 <= index < 36, "R評価IDの範囲")
        key, a = KEYS[index], value["集計"][KEYS[index]]
        cells = line.strip("| ").split(" | ")
        require(len(cells) == 8, "結果表の8列")
        require(cells[1] == value["Actor設定"][key]["candidate"] and cells[2] == f"C{value['Actor設定'][key]['slip_pts']}/D{value['Actor設定'][key]['delay_seconds']}", "R表と36設定の対応")
        cells[4:] = ["70場／7,980枠", money(a["net_yen"]) + "円", f"{a['unit_positive_closed_negative']}件／DD {a['保存点連結時価DD']:,}円",
                     percent(a["活動主表"]["active"], 7980) + f"（{a['活動主表']['active']}/7980）"]
        lines[i] = "| " + " | ".join(cells) + " |"
        seen.append(index)
    require(seen == list(range(36)), "全R36を一度ずつ更新")
    return "\n".join(lines) + "\n\n## 実行後の読み方\n\n複合評価済みは構成指標単独の有効性を分離検証した意味ではない。結果の正本は成果物/結果.json。主7,980・副7,700を保持し0取引場も落とさない。報告生成はwork/110報告の準備/報告を作る.py。旧市場前生成器で現在の結果表を上書きしない。\n"


def documents(value: dict, template: str, result_sha: str) -> dict[str, str]:
    """機能: 報告、設定表案、CSV案内を構成する。

    引数: value(dict)、template/result_sha(str)は正本、市場前本文、指紋。
    返り値: dict[str,str]は予定名と本文。正式docsを直接変更しない。
    """
    grouped = validate(value)
    comparison_text, _ = comparisons(value)
    report = "# 00110：三時間軸の有効状態と値幅を残す必須保護\n\n全70場・36条件・2,520会計の保存正本から作成した報告案。採用・目標達成をこの処理で宣言しない。全条件は同じ既使用期間の探索である。\n\n"
    report += "## 仮説と条件\n\n30分を背景、15分を押戻しと危険帯、5分を支持付き取得の確認に使う。三軸同方向の継続と上位に逆らう局所転換を別経路にする。MAの並び・傾きに加えRSI/MACDの維持と回復、支持抵抗、ATR・通常値幅を組み合わせた。出来高は既知性診断のみ。\n\n"
    report += "入口E0L0（固定対照）、E2L0（有効な状態の技法）、E2L1（有効な未取得Sourceを後続枠で査定）とG0/G3/G4の3保護を組み合わせた9候補。L1は実fill後の再参加ではない。売買は符号反転した同一条件。G3/G4は一定利益で必ず起動し、EMA収束・MACD失速・既知pivot否定で幅を狭め、保護床を不利に緩めない。閾値の実式は設定と結果.mdと純仕様を参照する。\n\n"
    report += "入力は106由来の2026-09-21〜11-06の日夜70場。mini各側上限10枚・可変、100円/pt、片道税込38.5円。開始/米国開始20分静観、5分新規、保護は定時外も連続。主判断枠は開始+20分〜予定末尾10分前の7,980、副は末尾30分前まで7,700。保有又は同枠実fillが参加で、未知・欠測・米国静観を分母から落とさない。\n\n"
    report += "C0はラージBBO代理＋手数料。C5はさらに5pt/片道の仮定追加滑り。D1は価格時計1秒仮定で実通信遅延ではない。CSV足終+60秒をRecord.Atで公表するモデル。各費用条件は別運用で合算しない。\n\n"
    report += "### 心理面の仮説\n\n長い時間軸の方向は参加者の保有方向と押戻しへの反応を推測する背景とする。15分の危険帯と5分の支持保持は、押戻しで従来の売り手・買い手が価格を否定できなかったことを確認する仮説である。高いRSIが続く状態は強い買いの継続も含むため、過熱値だけで逆張りせず、水準維持と異常な増分を分ける。局所反転は試験・復帰・後の突破を分け、長期方向が転換済みとは扱わない。いずれも参加者の心理を直接観測した事実ではなく、価格と技術状態に対応させた仮説である。一般説明と出典はdocs/議論/外部再調査/強さの持続とオシレーターの増分を分ける.mdを参照する。\n\n"
    report += "## C0D0の9候補\n\n正益の割合の分母は成立新規件数。0件の率は未成立表示。PFは実利益総額÷実損失絶対額。DDは保存点時価の連結値で全tick最大DDではない。\n" + main_table(value)
    report += "## 技法・受付寿命・保護を分けた比較\n\n" + comparison_text
    report += "## 期間と日夜\n\n" + periods(grouped)
    report += "## 全36費用条件\n" + main_table(value, True)
    report += "## 固定と実行の履歴\n\n元の金融条件.json（SHA256 " + ORIGINAL_SHA + "）を保持した。初回起動は停止記録の型不一致で市場本文読取前に拒否された。金融条件_停止形式整合.json（" + ALIGNED_SHA + "）は認証済み停止viewと整合器だけを追加し、売買算法、36設定、実行物、費用、時計、分母、入力は変更していない。中断後の再実行経路はRoot実行記録を参照し、未完成の途中出力を最終結果に混ぜない。\n\n"
    report += "## 限界と次の判断\n\n複合成績をMA・RSI・30分追加など一指標の効果とはしない。利益後赤字が減っても総額や参加率が悪化すれば採用根拠に不足する。安定性は日夜・固定期・費用感度も合わせて判断する。未参加又は退出後の仮想利益、機会損失、MFE回収率、元手不明のROIは算出しない。mini実板・実約定は未検証。保存検査は全fill/所有/費用/保存MTM-DD/入口保護の保存根拠までで、全指標や全tickの別エンジン再形成ではない。未見11/09の価格・損益はこの処理では開かない。\n\n"
    report += "正本は成果物/結果.json（SHA256 " + result_sha + "）。候補別集計.csvは36条件、全セッション.csvは2,520行。CSV再読・Viewer・正式保存・再現コードの検査記録と接続してから正式報告とする。\n"
    guide = "# 110の損益CSV\n\n[候補別集計](候補別集計.csv)で条件IDを選び、[全セッション](全セッション.csv)を同じIDで絞り込む。36条件・各70場の2,520行と0取引行を残す。各候補は独立で合算しない。\n\n"
    guide += table(["入口名", "意味"], [["entry_E0", "旧入口・L0一枠（固定対照）"], ["entry_E2_L0", "三時間軸の有効状態・L0一枠"], ["entry_E2_L1", "同じ入口技法・有効な未取得Sourceを後続枠で査定"]])
    guide += "G0は旧1A起動/2A幅、G3/G4は半A/一A起動と必須可変追尾。主比較はC0D0。C5/D1は別の費用・価格時計感度。円建て累計は条件IDごとの実現純額を70場の時系列で加算する。ナイトは開始日で11/06ナイトは翌早朝を含む。\n\n"
    guide += "参加は保有又は同枠実fill。主7,980枠は開始20分後〜末尾10分前、副7,700枠は末尾30分前。未知・欠測・米国静観も分母に残す。mini各側上限10枚・100円/pt・片道38.5円、ラージBBO代理。C5は追加5pt/片道、D1は価格時計1秒仮定。元手不明のROI、未参加/退出後の仮想利益・機会損失は作らない。\n\n正本SHA256 " + result_sha + "。CSVと独立再読の成功は別のCSVの確認.jsonで確認する。この案の生成だけではCSV生成成功を主張しない。\n"
    return {"README案.md": report, "設定と結果案.md": settings(value, template), "CSV閲覧案内.md": guide}


def generate(result_path: Path, result_sha: str, check_path: Path, check_sha: str, output: Path) -> dict:
    """機能: 正本と保存検算を結合し新規先へ報告案を作る。

    引数: result_path/check_path/output(Path)、result_sha/check_sha(str)は入力・出力と指紋。
    返り値: dictは入力前後不変と出力指紋。金融・市場読取は行わない。
    """
    require(not output.exists(), "出力先は未使用であること")
    value, check = load_ref(result_path, result_sha), load_ref(check_path, check_sha)
    require(check["成功"] is True and check["前後不変"] is True and check["不一致数"] == 0, "保存検算成功")
    require(check["会計"] == check["資源"] == 2520 and check["旧対照"] == 280, "全件保存検査")
    require(check["出力SHA256"]["結果.json"] == result_sha, "保存検算と結果の結合")
    require(value["金融条件SHA256"] == check["金融条件SHA256"] == ALIGNED_SHA, "実行金融条件")
    template_path = TRIAL / "市場前仕様/設定と結果.md"
    refs = {str(result_path): result_sha, str(check_path): check_sha, str(template_path): TEMPLATE_SHA,
            str(TRIAL / "金融条件.json"): ORIGINAL_SHA, str(TRIAL / "金融条件_停止形式整合.json"): ALIGNED_SHA}
    require(all(sha(Path(p)) == s for p, s in refs.items()), "報告入力の全現物SHA")
    files = documents(value, template_path.read_text(encoding="utf-8-sig"), result_sha)
    output.mkdir(parents=True)
    for name, body in files.items():
        (output / name).write_text(body, encoding="utf-8", newline="\n")
    _, differences = comparisons(value)
    (output / "実現差分.json").write_text(json.dumps(differences, ensure_ascii=False, indent=2, default=str) + "\n", encoding="utf-8")
    require(all(sha(Path(p)) == s for p, s in refs.items()), "入力の前後不変")
    proof = {"成功": True, "試行": 110, "正式文書変更": 0, "金融再実行": 0, "市場本文読取": 0, "入力SHA256": refs,
             "前後不変": True, "会計": 2520, "条件": 36, "比較差分": 48, "研究目標達成": False, "採用": False,
             "出力SHA256": {p.name: sha(p) for p in output.iterdir() if p.is_file()}}
    (output / "報告案の確認.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return proof


def main() -> None:
    """機能: 全70保存後の期待指紋を受けて報告案を生成する。

    引数: CLIの--result/--result-sha/--check/--check-sha/--outは正本、保存検算、新規先。
    返り値: None。標準出力へ完了小計を出す。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--result", required=True, type=Path)
    parser.add_argument("--result-sha", required=True)
    parser.add_argument("--check", required=True, type=Path)
    parser.add_argument("--check-sha", required=True)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    result = generate(args.result.resolve(), args.result_sha, args.check.resolve(), args.check_sha, args.out.resolve())
    print(json.dumps({k: result[k] for k in ("成功", "会計", "条件", "比較差分")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
