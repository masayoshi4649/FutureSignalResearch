"""認証した110同入口比較を小型JSONと日本語Markdownへまとめる。"""

from pathlib import Path
import hashlib
import json


ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
SOURCE = ROOT / "work/110出口の同入口比較_準備/全70の解析.json"
SOURCE_SHA = "399a1c5f8ab2fe4df4a5bf9776342e3adcc032c437b03fd980a90c2befb59dc3"


def digest(path: Path) -> str:
    """明示した解析と要約コードの指紋を求める。

    引数: path(Path)は非価格ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compact(value: dict) -> dict:
    """厳密比較の群別件数と実現統計を小さく残す。

    引数: value(dict)は認証済み解析の一比較。
    返り値: dictは全実績・群別件数と差・同入口の勝敗遷移。
    """
    result = {"全同実入口": value["全同実入口"], **value["全体"], "群": {name: {"前玉": group["前"]["玉"], "後玉": group["後"]["玉"], "実現差円": group["実現差円"]} for name, group in value["群"].items()}, "勝敗遷移": {name: {"玉": group["前"]["玉"], "前実現円": group["前"]["実現円"], "後実現円": group["後"]["実現円"], "差円": group["実現差円"]} for name, group in value["同実入口の勝敗遷移"].items()}}
    assert result["実現差円"] == result["後"]["実現円"] - result["前"]["実現円"]
    assert result["実現差円"] == sum(group["実現差円"] for group in result["群"].values())
    return result


def main() -> None:
    """解析正本を認証し、全件場別の複製を避けて要点だけを保存する。

    引数: なし。
    返り値: None。Native・市場・価格CSVを再読しない。
    """
    assert digest(SOURCE) == SOURCE_SHA
    result = json.loads(SOURCE.read_text(encoding="utf-8"))
    assert result["成功"] and result["試行"] == 110 and result["比較数"] == 24 and result["場別比較数"] == 1680 and result["前後不変"]
    assert result["全比較で入口同体"]
    for value in result["全条件"].values():
        assert value["全同実入口"]
        assert all(group[side]["玉"] == 0 for name, group in value["群"].items() if name != "同実入口" for side in ("前", "後"))
    totals = {key: compact(value) for key, value in result["全条件"].items()}
    selected = [key for key in totals if key.endswith("C0_D0")]
    summary = {"試行": 110, "成功": True, "解析正本": {"path": str(SOURCE), "sha256": SOURCE_SHA}, "金融完了": result["金融完了"], "独立保存": result["独立保存"], "scope": result["scope"], "全24比較で厳密同入口": True, "全24比較で取得変更又は片側参加": 0, "全条件": totals, "C0D0日夜": {key: {kind: compact(value) for kind, value in result["日夜"][key].items()} for key in selected}, "C0D0週別": {key: {week: compact(value) for week, value in result["週別"][key].items()} for key in selected}, "11月06日C0D0": [{"比較": row["比較"], "session": row["session"], **compact(row)} for row in result["場別"] if row["session"].startswith("2026-11-06") and row["比較"] in selected], "入力SHA256": result["入力SHA256"], "限界": result["限界"], "生成器": {"path": str(Path(__file__).resolve()), "sha256": digest(Path(__file__).resolve())}}
    output = OWN / "要約.json"
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(summary, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    lines = ["# 110の保護比較：全24比較で実入口は同じ", "", "既使用70場のNative全70本をSHA認証し、入口E0/L0・E2/L0・E2/L1各内で、費用と価格時計遅延を固定してG0対G3/G4を比較した。24比較×70場すべてでSource全文・新規要求・実new fill・時刻・全気配・価格・枚数が一致した。取得変更・片側のみの参加は0だった。今回は出口による実取得変化がなかったと確認できたが、今後も上限・予約・L1後枠が影響しないと一般化しない。", "", "## C0D0の実現額と赤字化", "", "C0はラージBBO代理と片道38.5円/枚の手数料、D0は追加の価格時計遅延なし。日経miniの実可変枚数で、毎回10枚へ換算しない。損失総額は負符号。", "", "|比較|同入口玉|G0実現円|後実現円|差円|u正益後赤字玉|起動後赤字玉|", "|---|---:|---:|---:|---:|---:|---:|"]
    for key in selected:
        value = totals[key]
        a, b = value["前"], value["後"]
        lines.append(f"|{key.removesuffix('_C0_D0')}|{a['玉']}|{a['実現円']:,}|{b['実現円']:,}|{value['実現差円']:,}|{a['u正益後赤字玉']}→{b['u正益後赤字玉']}|{a['起動後赤字玉']}→{b['起動後赤字玉']}|")
    lines.extend(["", "E0/G3は同入口の勝→勝202玉で実現差−1,665,000円、負→勝43玉で＋522,000円、勝→負1玉で−33,000円、負→負220玉で−14,000円。加法で全体差−1,190,000円になる。E0/G4は勝→勝203玉で−1,036,000円、負→勝28玉で＋255,000円、負→負235玉で−14,000円、計−795,000円だった。両勝群も両戦略が実際に成立して完結した純額の比較であり、取り逃がした利益や退出後の仮想利益を計算した値ではない。", "", "E0/G3の負額総額は−4,109,424円から−3,892,572円へ216,852円改善したが、正額総額も6,283,041円から4,876,189円へ減った。E0/G4は正益後赤字の件数が減った一方、負額総額は−4,112,113円で2,689円悪化した。件数・損失額・純額は別々に評価する必要がある。", "", "E2/L1も、G3では同入口の勝→勝20玉の実現差−622,000円と負→勝6玉の＋36,000円、G4では−511,000円と＋36,000円で、残る負→負群の差は0。起動後赤字6→0は確認できるが、総純額の改善を意味しない。入口は47玉しかなく、活動頻度や安定性は別の全36候補の正本で評価する。", "", "## 解釈の範囲", "", "u正益後赤字は費用後単位含み益の初回正益を観測した実玉が最終赤字になった件数。起動後赤字は実際の保護起動があり最終実現額が負の件数であり、起動価格の床がそのまま約定されたという意味ではない。G3/G4でもE0の起動後赤字は残った。約定遅延やgapの問題を件数から隠さない。", "", "同入口群は両戦略で成立した条件付き群で、ランダム化した因果効果ではない。C0/C5・D0/D1を独立標本として合算しない。新たな技法又は起動閾値を、この比較だけで有効としない。研究目標の達成や採用は示していない。", "", "[要約.json](要約.json)には全24比較、C0D0の日夜・週別・11月06日の場別、入力70本の指紋、解析正本への参照を保存した。大きい1680場別の解析正本はwork内で参照し、全件転記を増やさない。金融・価格・Raw・SourceRecordを再実行していない。11月09日は未読。", ""])
    with (OWN / "要点.md").open("x", encoding="utf-8", newline="\n") as stream:
        stream.write("\n".join(lines))
    assert digest(SOURCE) == SOURCE_SHA
    print(json.dumps({"要約": str(output), "sha256": digest(output), "bytes": output.stat().st_size, "要点": str(OWN / "要点.md"), "要点SHA256": digest(OWN / "要点.md")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
