"""匿名埋込対応readerの非市場人工と停止指紋を新規保存する。"""
from __future__ import annotations

import difflib
import hashlib
import json
from pathlib import Path
import subprocess

WORK = Path(__file__).resolve().parent
ROOT = WORK.parent.parent
OLD = WORK.parent / "107保存公表の再読口"
OLD_STOP_SHA = "7ac3099cf9434c4d1cf33df1cda7f887d9bc80ee4dbd7dc202792d7172783ef7"


def sha(path: Path) -> str:
    """機能: bytesのSHA256を計算する。引数path(Path)。返り値strは小文字指紋。"""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relative(path: Path) -> str:
    """機能: repo内の相対pathを返す。引数path(Path)。返り値strは保存参照。"""
    return path.relative_to(ROOT).as_posix()


def save(path: Path, value: object) -> None:
    """機能: 新規JSONだけ保存する。引数path(Path),value(object)。返り値なし。"""
    with path.open("x", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")


def old_hashes() -> dict[str, str]:
    """機能: 元停止と全所有を照合する。引数なし。返り値dict[str,str]は実指紋。"""
    stop = OLD / "停止.json"
    assert sha(stop) == OLD_STOP_SHA
    expected = json.loads(stop.read_text(encoding="utf-8"))["所有コードSHA256"]
    actual = {p: sha(ROOT / p) for p in expected}
    assert actual == expected
    actual[relative(stop)] = OLD_STOP_SHA
    return actual


def main() -> None:
    """機能: 元不変/人工/検査ログを結んで停止する。引数なし。返り値なし。"""
    if (WORK / "停止.json").exists() or (WORK / "検査").exists():
        raise RuntimeError("停止/検査の既存先は上書きしない")
    old_before = old_hashes()
    same = ["fresh_clock.go", "load.go", "reader_test.go", "replay.go", "types.go", "go.mod", "go.sum"]
    assert all((WORK / p).read_bytes() == (OLD / p).read_bytes() for p in same)
    origin = {
        "元停止": {"path": relative(OLD / "停止.json"), "sha256": OLD_STOP_SHA},
        "機能差": "requiredShapeの匿名struct field選択のみ。実値/Source/Tape/時計/金融変更なし",
        "元同体": {p: sha(WORK / p) for p in same},
        "修正": ["io.goのstruct必須loop", "embedded.goのJSON field選択"],
        "追加人工": "実far82.CurrentEvidenceを含むTechnicalGateInput/Tape平坦JSON、欠落/null/型/余剰/重複、tag/shadow/衝突",
        "市場失敗参照": "Root通知の0/2・金融0の必須CurrentEvidence.CurrentEvidence誤判定。失敗市場本文は本作業で未読",
        "市場本文/Raw/CSV/金融実行": 0,
    }
    save(WORK / "由来と再用.json", origin)
    before = (OLD / "io.go").read_text(encoding="utf-8").splitlines(keepends=True)
    after = (WORK / "io.go").read_text(encoding="utf-8").splitlines(keepends=True)
    patch = "".join(difflib.unified_diff(before, after, fromfile="旧停止/io.go", tofile="埋込対応/io.go"))
    for name in ["embedded.go", "embedded_test.go"]:
        patch += "".join(difflib.unified_diff([], (WORK / name).read_text(encoding="utf-8").splitlines(keepends=True), fromfile="/dev/null", tofile="埋込対応/" + name))
    (WORK / "派生差分.patch").write_text(patch, encoding="utf-8", newline="\n")
    owned = sorted(p for p in WORK.iterdir() if p.is_file())
    own_before = {relative(p): sha(p) for p in owned}
    logs = WORK / "検査"
    logs.mkdir()
    commands = {"test": ["go", "test", "-count=1", "-json", "./..."], "vet": ["go", "vet", "./..."], "build": ["go", "build", "./..."]}
    exits = {}
    for name, argv in commands.items():
        result = subprocess.run(argv, cwd=WORK, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=False)
        (logs / f"{name}.stdout.txt").write_bytes(result.stdout)
        (logs / f"{name}.stderr.txt").write_bytes(result.stderr)
        exits[name] = result.returncode
        if result.returncode != 0:
            raise RuntimeError(f"{name}不成立: {result.stderr.decode('utf-8', errors='replace')}")
    events = [json.loads(s) for s in (logs / "test.stdout.txt").read_text(encoding="utf-8").splitlines() if s.startswith("{")]
    passed = [e["Test"] for e in events if e.get("Action") == "pass" and "Test" in e]
    skipped = [e["Test"] for e in events if e.get("Action") == "skip" and "Test" in e]
    assert not any(e.get("Action") == "fail" for e in events)
    own_after = {relative(p): sha(p) for p in owned}
    old_after = old_hashes()
    assert own_before == own_after and old_before == old_after
    proof = {
        "成功": True, "test/vet/build終了": exits,
        "top成功": len([s for s in passed if "/" not in s]), "全成功": len(passed), "skip": skipped,
        "新人工成功": [s for s in passed if s.startswith("TestEmbedded")],
        "元所有前": old_before, "元所有後": old_after, "元停止不変": True,
        "所有前": own_before, "所有後": own_after, "前後不変": True,
        "ログSHA256": {relative(p): sha(p) for p in sorted(logs.iterdir())},
        "市場実物本文/Raw/CSV/新金融": 0,
    }
    save(logs / "人工確認.json", proof)
    stop = {
        "成功": True, "module": "github.com/masayoshi4649/SessionTradeExecuter/savedpublic107",
        "scope": "107保存readerの匿名struct平坦JSON必須検査だけを別版で修正。非市場人工",
        "所有コードSHA256": own_after, "元停止SHA256": {relative(OLD / "停止.json"): OLD_STOP_SHA},
        "人工確認": {"path": relative(logs / "人工確認.json"), "SHA256": sha(logs / "人工確認.json")},
        "test/vet/build終了": exits, "元停止不変": True, "前後不変": True,
        "API": ["LoadTape(Request)(*Loaded,error)", "Loaded.Tape/Header/Proof", "ReplayRecords(*Loaded,stream.Sink)(stream.Header,ReplayProof,error)"],
        "市場実物本文/Raw/CSV/新金融": 0,
        "未実施": ["Rootの市場口改版/Go閉包/条件固定", "実first2/70場の入力再読と金融"],
    }
    save(WORK / "停止.json", stop)
    print(json.dumps({"停止": relative(WORK / "停止.json"), "SHA256": sha(WORK / "停止.json"), "top成功": proof["top成功"], "全成功": len(passed), "skip": skipped, "終了": exits}, ensure_ascii=False))


if __name__ == "__main__":
    main()
