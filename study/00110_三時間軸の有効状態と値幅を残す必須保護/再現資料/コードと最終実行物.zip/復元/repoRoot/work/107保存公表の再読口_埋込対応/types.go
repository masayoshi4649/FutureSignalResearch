// Package savedpublic107 は106の完成公表と固定Sourceを金融なしで再読します。
package savedpublic107

import (
	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	actual "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
)

const Condition106 = "d9319e0f5757cd198329f8d4e272f1cc6af8b084ea8a8cd80bd10d77c39f809f"

type FileRef struct {
	Path string `json:"path"`
	SHA  string `json:"sha256"`
}
type Manifest = continuous.InputManifest
type SceneRef struct {
	Session string             `json:"session"`
	Kind    string             `json:"kind"`
	Clock   *FileRef           `json:"old_clock_tape,omitempty"`
	Legacy  *FileRef           `json:"legacy_tape,omitempty"`
	Sym     *FileRef           `json:"symmetric_tape,omitempty"`
	Records map[string]FileRef `json:"source_records,omitempty"`
	W0      *FileRef           `json:"w0_native,omitempty"`
}
type Corpus struct {
	Version  int        `json:"version"`
	Trial    int        `json:"trial"`
	Fixed    bool       `json:"fixed"`
	Manifest FileRef    `json:"input_manifest"`
	Source12 FileRef    `json:"source12_completion"`
	Scenes   []SceneRef `json:"scenes"`
}
type SceneOutput struct {
	Session     string  `json:"session"`
	Native      FileRef `json:"native"`
	Header      FileRef `json:"sidecar_header"`
	Records     FileRef `json:"sidecar_records"`
	Books       int     `json:"books"`
	W0Books     int     `json:"w0_control_books"`
	ControlKind string  `json:"control_kind"`
	Error       string  `json:"error,omitempty"`
}
type Completion struct {
	Version            int               `json:"version"`
	Trial              int               `json:"trial"`
	Stage              string            `json:"stage"`
	Success            bool              `json:"success"`
	ConditionSHA       string            `json:"condition_sha256"`
	Sessions           int               `json:"sessions"`
	BooksPerScene      int               `json:"books_per_scene"`
	Books              int               `json:"books"`
	Results            []SceneOutput     `json:"results"`
	Before             map[string]string `json:"before"`
	After              map[string]string `json:"after"`
	Unchanged          bool              `json:"unchanged"`
	First2             *FileRef          `json:"first2,omitempty"`
	SeedPolicy         string            `json:"seed_policy"`
	SourceReexecuted   bool              `json:"source_reexecuted"`
	FeaturesRecomputed bool              `json:"features_recomputed"`
	ChartsRecomputed   bool              `json:"charts_recomputed"`
	FinancialExecuted  bool              `json:"financial_executed"`
	Error              string            `json:"error,omitempty"`
}
type Provenance struct {
	Scene              SceneRef                `json:"scene_input"`
	Input              continuous.InputSession `json:"raw_input"`
	Manifest           FileRef                 `json:"manifest"`
	SeedPolicy         string                  `json:"seed_policy"`
	FirstSceneCold     bool                    `json:"first_scene_cold"`
	FeaturesRecomputed bool                    `json:"features_recomputed"`
	ChartsRecomputed   bool                    `json:"charts_recomputed"`
	SourceReexecuted   bool                    `json:"source_reexecuted"`
}
type PublicHeader struct {
	Version      int           `json:"version"`
	Trial        int           `json:"trial"`
	ConditionSHA string        `json:"condition_sha256"`
	Header       stream.Header `json:"header"`
	RecordsSHA   string        `json:"records_gzip_sha256"`
	Pipeline     Provenance    `json:"pipeline_provenance"`
}

// NativeMetadata は金融Bookを型へ含めず必要な元出典だけを投影します。
type NativeMetadata struct {
	Version          int            `json:"version"`
	Trial            int            `json:"trial"`
	Session          actual.Session `json:"session"`
	Contract         string         `json:"contract"`
	TapeSHA          string         `json:"tape_canonical_sha256"`
	TapeUnchanged    bool           `json:"tape_unchanged"`
	Complete         bool           `json:"complete"`
	SourceReexecuted bool           `json:"source_reexecuted"`
	ChartsRecomputed bool           `json:"charts_recomputed"`
	CMPRecomputed    bool           `json:"cmp_recomputed"`
	ConditionSHA     string         `json:"condition_sha256"`
	Pipeline         Provenance     `json:"pipeline_provenance"`
}
type Request struct {
	Manifest   FileRef
	Corpus     FileRef
	Completion FileRef
	SceneID    string
}
type Proof struct {
	SceneID           string            `json:"scene_id"`
	Kind              string            `json:"source_kind"`
	ExpectedNative    FileRef           `json:"expected_native"`
	TapeSHA           string            `json:"tape_canonical_sha256"`
	InputSHA          map[string]string `json:"input_sha256"`
	Frames            int               `json:"frames"`
	SourceModes       []string          `json:"source_modes"`
	SourceReexecuted  bool              `json:"source_reexecuted"`
	BankRecomputed    bool              `json:"bank_recomputed"`
	FinancialExecuted bool              `json:"financial_executed"`
}
type ReplayProof struct {
	Records      int               `json:"records"`
	SourceEvents int               `json:"source_events"`
	Before       map[string]string `json:"before"`
	After        map[string]string `json:"after"`
	Unchanged    bool              `json:"unchanged"`
}

// Loaded は認証後のprivate参照を保持します。呼出側はTapeの共有sliceを変更しません。
type Loaded struct {
	input   tape.Tape
	public  PublicHeader
	records FileRef
	proof   Proof
}

// Tape はRoot Coreへ不変の場別入力を渡します。
//
// 引数: なし。返り値: tape.Tapeは共有sliceを持つ値で、変更するとReplayRecordsが拒否します。
func (l *Loaded) Tape() tape.Tape { return l.input }

// Header は認証した元Headerを値copyで返します。
//
// 引数: なし。返り値: stream.Headerはprivate pointerを共有しない出典です。
func (l *Loaded) Header() stream.Header { return copyValue(l.public.Header) }

// Proof は型/Source結合の限定証拠を返します。
//
// 引数: なし。返り値: Proofはprivate mapを共有しない値です。
func (l *Loaded) Proof() Proof { return copyValue(l.proof) }
