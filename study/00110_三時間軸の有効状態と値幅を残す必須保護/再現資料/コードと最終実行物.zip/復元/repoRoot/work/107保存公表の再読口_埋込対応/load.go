package savedpublic107

import (
	"fmt"
	"path/filepath"
	"reflect"
	"strings"

	followup "github.com/masayoshi4649/SessionTradeExecuter/fixedfollowup"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
	binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
)

// normalizeScene はCorpusの参照基準だけを絶対化します。
//
// 引数: s(SceneRef)、base(string)は元値とCorpus parent。返り値: SceneRef/errorは元payloadを補完しない参照です。
func normalizeScene(s SceneRef, base string) (SceneRef, error) {
	s = copyValue(s)
	for _, r := range []*FileRef{s.Clock, s.Legacy, s.Sym, s.W0} {
		if r != nil {
			if !validSHA(r.SHA) {
				return s, fmt.Errorf("未固定Corpus参照")
			}
			p, e := absolute(base, r.Path)
			if e != nil {
				return s, e
			}
			r.Path = p
		}
	}
	for k, r := range s.Records {
		if !validSHA(r.SHA) {
			return s, fmt.Errorf("未固定Source記録")
		}
		p, e := absolute(base, r.Path)
		if e != nil {
			return s, e
		}
		r.Path = p
		s.Records[k] = r
	}
	return s, nil
}

// metadata は標準70/Corpus/成功完了を価格入力より先に結びます。
//
// 引数: r(Request)、before(map)は明示参照と前指紋。返り値: Manifest/Corpus/Completion/位置/元Ref/errorです。
func metadata(r Request, before map[string]string) (Manifest, Corpus, Completion, int, [3]FileRef, error) {
	var m Manifest
	var c Corpus
	var v Completion
	refs := [3]FileRef{}
	fail := func(e error) (Manifest, Corpus, Completion, int, [3]FileRef, error) { return m, c, v, -1, refs, e }
	for i, x := range []FileRef{r.Manifest, r.Corpus, r.Completion} {
		b, e := bind(x, ".", before)
		if e != nil {
			return fail(e)
		}
		refs[i] = b
	}
	if e := readJSON(refs[0].Path, &m, false, true); e != nil {
		return fail(e)
	}
	if e := readJSON(refs[1].Path, &c, false, true); e != nil {
		return fail(e)
	}
	if e := readJSON(refs[2].Path, &v, false, true); e != nil {
		return fail(e)
	}
	if len(m.Sessions) != 70 || c.Version != 1 || c.Trial != 106 || !c.Fixed || len(c.Scenes) != 70 || !validSHA(c.Source12.SHA) || c.Source12.Path == "" {
		return fail(fmt.Errorf("標準70/Corpus固定不正"))
	}
	cm, e := absolute(filepath.Dir(refs[1].Path), c.Manifest.Path)
	if e != nil || !strings.EqualFold(cm, refs[0].Path) || c.Manifest.SHA != refs[0].SHA {
		return fail(fmt.Errorf("Corpusと標準台帳差"))
	}
	n := 70
	if v.Stage == "first2" {
		n = 2
	} else if v.Stage != "full70" {
		return fail(fmt.Errorf("旧106 stage不正"))
	}
	if v.Version != 1 || v.Trial != 106 || !v.Success || v.ConditionSHA != Condition106 || v.Sessions != n || v.BooksPerScene != 20 || v.Books != 20*n || len(v.Results) != n || v.Error != "" || !v.Unchanged || len(v.Before) == 0 || !reflect.DeepEqual(v.Before, v.After) || v.SourceReexecuted || !v.FeaturesRecomputed || !v.ChartsRecomputed || !v.FinancialExecuted || v.SeedPolicy != "first_cold_then_contract_carry" {
		return fail(fmt.Errorf("旧106完了不正"))
	}
	if v.Before[refs[0].Path] != refs[0].SHA || v.Before[refs[1].Path] != refs[1].SHA {
		return fail(fmt.Errorf("完了が使用した入力metadata差"))
	}
	selected := -1
	seen := map[string]bool{}
	for i, s := range m.Sessions {
		if s.ID == "" || seen[s.ID] || s.Contract == "" || len(s.Files) != 6 || i > 0 && s.ID <= m.Sessions[i-1].ID || c.Scenes[i].Session != s.ID {
			return fail(fmt.Errorf("70場順/限月/6入力metadata不正"))
		}
		seen[s.ID] = true
		kind := "old104_54"
		if i >= 66 {
			kind = "saved105_4"
		} else if i >= 54 {
			kind = "fresh106_12"
		}
		if c.Scenes[i].Kind != kind {
			return fail(fmt.Errorf("70分類差"))
		}
		if i < n {
			row := v.Results[i]
			control := "provided_old_book"
			if i >= 54 && i < 66 {
				control = "same_input_old103"
			}
			if row.Session != s.ID || row.Books != 20 || row.W0Books != 4 || row.ControlKind != control || row.Error != "" {
				return fail(fmt.Errorf("旧106出力集合差"))
			}
		}
		if s.ID == r.SceneID {
			selected = i
		}
	}
	if selected < 0 || selected >= n {
		return fail(fmt.Errorf("指定場が完成対象にない"))
	}
	return m, c, v, selected, refs, nil
}

// readSource は固定全商品Source記録だけを読み、自然Sourceを呼びません。
//
// 引数: r(FileRef)、before(map)は明示参照。返り値: []SourceRecord/errorは全行の元型です。
func readSource(r FileRef, before map[string]string) ([]binder.SourceRecord, error) {
	p, e := bind(r, ".", before)
	if e != nil {
		return nil, e
	}
	out := []binder.SourceRecord{}
	e = readLines(p.Path, func(b []byte) error {
		var x binder.SourceRecord
		if e := strictBytes(b, &x); e != nil {
			return e
		}
		out = append(out, x)
		return nil
	})
	return out, e
}

// readTape は既存保存Tapeの全fieldを保持します。
//
// 引数: r(FileRef)、before(map)は固定参照。返り値: Tape/errorは元値です。
func readTape(r FileRef, before map[string]string) (tape.Tape, error) {
	var t tape.Tape
	p, e := bind(r, ".", before)
	if e != nil {
		return t, e
	}
	e = readJSON(p.Path, &t, true, true)
	return t, e
}

// LoadTape は価格原板/CSV/Bankなしで固定106の金融入力を結合します。
//
// 引数: r(Request)はRootが固定する3metadata FileRefと場IDです。
// 返り値: *Loaded/errorは認証済みTape/保存列参照又は欠落・破損です。金融を実行しません。
func LoadTape(r Request) (*Loaded, error) {
	before := map[string]string{}
	m, c, v, i, refs, e := metadata(r, before)
	if e != nil {
		return nil, e
	}
	scene, e := normalizeScene(c.Scenes[i], filepath.Dir(refs[1].Path))
	if e != nil {
		return nil, e
	}
	row := v.Results[i]
	nr, e := bind(row.Native, filepath.Dir(refs[2].Path), before)
	if e != nil {
		return nil, e
	}
	hr, e := bind(row.Header, filepath.Dir(refs[2].Path), before)
	if e != nil {
		return nil, e
	}
	rr, e := bind(row.Records, filepath.Dir(refs[2].Path), before)
	if e != nil {
		return nil, e
	}
	var native NativeMetadata
	var h PublicHeader
	// 金融Booksは型に入れず、106Nativeの認証済みtopだけを投影する。
	if e = readJSON(nr.Path, &native, true, false); e != nil {
		return nil, e
	}
	if e = readJSON(hr.Path, &h, false, true); e != nil {
		return nil, e
	}
	session, e := followup.SessionClock(r.SceneID)
	if e != nil {
		return nil, e
	}
	if native.Version != 1 || native.Trial != 106 || native.Session != session || native.Contract != m.Sessions[i].Contract || !validSHA(native.TapeSHA) || !native.TapeUnchanged || !native.Complete || native.SourceReexecuted || native.ChartsRecomputed || !native.CMPRecomputed || native.ConditionSHA != Condition106 {
		return nil, fmt.Errorf("旧Nativeの非金融出典差")
	}
	if h.Version != 1 || h.Trial != 106 || h.ConditionSHA != Condition106 || h.RecordsSHA != rr.SHA || !h.Header.Success || h.Header.Version != 1 || h.Header.Scene.ID != r.SceneID || h.Header.Scene.Contract != native.Contract || h.Header.Scene.Start != session.Start || !h.Header.LegacyAllStateMatch || !h.Header.ForceClockOnly || h.Header.SourceReexecuted || h.Header.FinancialExecuted || h.Header.MarketExecuted || !sameJSON(native.Pipeline, h.Pipeline) {
		return nil, fmt.Errorf("元Header/Native/records差")
	}
	p := h.Pipeline
	if !sameJSON(p.Scene, scene) || !sameJSON(p.Input, m.Sessions[i]) || p.Manifest.SHA != refs[0].SHA || p.SeedPolicy != v.SeedPolicy || p.FirstSceneCold != (i == 0) || !p.FeaturesRecomputed || !p.ChartsRecomputed || p.SourceReexecuted {
		return nil, fmt.Errorf("106生成由来差")
	}
	var input tape.Tape
	frames := 0
	modes := []string{}
	switch scene.Kind {
	case "old104_54":
		if scene.Clock == nil || len(scene.Records) != 1 {
			return nil, fmt.Errorf("旧54入力不足")
		}
		base, x := readTape(*scene.Clock, before)
		if x != nil {
			return nil, x
		}
		src, x := readSource(scene.Records["symmetric"], before)
		if x != nil {
			return nil, x
		}
		input, _, e = binder.Bind(base, src, "symmetric")
		modes = []string{"symmetric"}
	case "saved105_4":
		if scene.Sym == nil || scene.Legacy == nil {
			return nil, fmt.Errorf("105二Tape不足")
		}
		var legacy tape.Tape
		legacy, e = readTape(*scene.Legacy, before)
		if e != nil {
			return nil, e
		}
		input, e = readTape(*scene.Sym, before)
		if e == nil {
			e = sameClockTape(legacy, input)
		}
		modes = []string{"symmetric"}
	case "fresh106_12":
		if len(scene.Records) != 3 {
			return nil, fmt.Errorf("追加12の三mode不足")
		}
		fs := []ClockFrame{}
		e = readLines(rr.Path, func(b []byte) error {
			var x stream.Record
			if e := strictBytes(b, &x); e != nil {
				return e
			}
			if x.Kind == "quote" {
				if x.Scalar == nil {
					return fmt.Errorf("Frame Scalar欠落")
				}
				q := *x.Scalar
				fs = append(fs, ClockFrame{len(fs) + 1, "quote", x.At, &q})
			} else if x.Kind == "grid" {
				fs = append(fs, ClockFrame{len(fs) + 1, "grid", x.At, nil})
			}
			return nil
		})
		if e != nil {
			return nil, e
		}
		frames = len(fs)
		src, x := readSource(scene.Records["legacy"], before)
		if x != nil {
			return nil, x
		}
		base, _, x := BuildLegacyTape(session, fs, src)
		if x != nil {
			return nil, x
		}
		for _, mode := range []string{"legacy", "default", "symmetric"} {
			if mode != "legacy" {
				src, x = readSource(scene.Records[mode], before)
				if x != nil {
					return nil, x
				}
			}
			joined, _, x := binder.Bind(base, src, mode)
			if x != nil {
				return nil, x
			}
			if mode == "symmetric" {
				input = joined
			}
			modes = append(modes, mode)
		}
	default:
		return nil, fmt.Errorf("未定義Source種別")
	}
	if e != nil {
		return nil, e
	}
	if input.Session != session {
		return nil, fmt.Errorf("Tape場時計差")
	}
	if input.Version != 1 || input.Scope == "" || !reflect.DeepEqual(input.Capabilities, tape.Capabilities()) {
		return nil, fmt.Errorf("Tape版/能力差")
	}
	previous, rank := session.Start, -1
	for j, event := range input.Events {
		r, ok := map[string]int{"force": 0, "grid": 1, "quote": 2}[event.Kind]
		if !ok || event.Ordinal != j+1 || !finite(event.At) || event.At < previous || event.At == previous && r < rank {
			return nil, fmt.Errorf("元Tape連番/位相差")
		}
		if event.At != previous {
			rank = -1
		}
		previous, rank = event.At, r
	}
	hash, e := digestValue(input)
	if e != nil || hash != native.TapeSHA {
		return nil, fmt.Errorf("106期待Tape canonical SHA差")
	}
	for name, want := range before {
		got, x := fileSHA(name)
		if x != nil || got != want {
			return nil, fmt.Errorf("読込中の入力変更:%s", name)
		}
	}
	l := &Loaded{input: input, public: h, records: rr, proof: Proof{SceneID: r.SceneID, Kind: scene.Kind, ExpectedNative: nr, TapeSHA: hash, InputSHA: before, Frames: frames, SourceModes: modes}}
	return l, nil
}

// sameClockTape は105二TapeのScalarと制御時計だけを原値で比較します。
//
// 引数: a/b(Tape)はlegacy/symmetric。返り値: errorは時計又はScalar差です。
func sameClockTape(a, b tape.Tape) error {
	if a.Version != 1 || b.Version != 1 || a.Session != b.Session || !reflect.DeepEqual(a.Capabilities, b.Capabilities) || len(a.Events) != len(b.Events) {
		return fmt.Errorf("105二Tape場/集合差")
	}
	for i, x := range a.Events {
		y := b.Events[i]
		if x.Ordinal != y.Ordinal || x.Kind != y.Kind || x.At != y.At || !reflect.DeepEqual(x.Quote, y.Quote) {
			return fmt.Errorf("105二Tape時計差")
		}
	}
	return nil
}
