package savedpublic107

import (
	"fmt"
	"math"
	"reflect"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
)

type replayState struct {
	input          tape.Tape
	contract       string
	cursor         int
	count          stream.Header
	at             float64
	have, raw, eof bool
	rank           int
	afterEOF       int
	all            map[string]int64
	pending        map[string]chart.Quote
	lastSource     map[string]int64
}

// finite は時計/Scalarの非有限を拒否します。
//
// 引数: x(...float64)は保存値。返り値: boolは全有限だけ真です。
func finite(x ...float64) bool {
	for _, v := range x {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// resetKey はLast0のresetと同じ物理行raw_clockを結びます。
//
// 引数: r(Record)はTrigger付き値。返り値: stringは元4要素です。
func resetKey(r stream.Record) string {
	return fmt.Sprintf("%s/%d/%d/%.17g", r.Trigger.Market, r.Trigger.PhysicalLine, r.Trigger.AllIndex, r.Trigger.Time)
}

// raw はc465の全board/特徴Index/Last0出典検査だけを最小派生します。
//
// 引数: r(Record)は保存一件。返り値: errorは不正です。金融やBankは呼びません。
func (s *replayState) rawRecord(r stream.Record) error {
	id := r.Trigger
	if id == nil || (id.Market != "NK225" && id.Market != "TOPIX") || id.Time != r.At || id.Time < s.input.Session.Start || id.Time >= s.input.Session.End || id.PhysicalLine <= 0 || id.AllIndex != s.all[id.Market] || id.MergeOrdinal != s.count.RawBoards+1 {
		return fmt.Errorf("raw出典/全連番差")
	}
	if id.Market == "NK225" {
		q := r.RawQuote
		if q == nil || q.Time != id.Time || q.Line != id.PhysicalLine || q.Index != id.AllIndex || !finite(q.Time, q.Last, q.Bid, q.Ask) {
			return fmt.Errorf("Chart全Index/物理行差")
		}
		if r.Kind == "quote" {
			x := r.Scalar
			if x == nil || id.FeaturesIndex == nil || *id.FeaturesIndex != x.Index || !q.Valid || q.Last <= 0 || x.Time != r.At || x.SourceLine != id.PhysicalLine || x.Last != q.Last || x.Bid != q.Bid || x.Ask != q.Ask || !finite(x.Received, x.ATR, x.ATRAvailable, x.ATRNominal) {
				return fmt.Errorf("Scalar11出典差")
			}
		} else {
			q0, ok := s.pending[resetKey(r)]
			if r.Scalar != nil || q.Valid || q.Last > 0 || id.FeaturesIndex != nil || !ok || !reflect.DeepEqual(q0, *q) {
				return fmt.Errorf("Last0 reset対応差")
			}
			delete(s.pending, resetKey(r))
		}
	} else if r.Kind != "raw_clock" || r.Scalar != nil || r.RawQuote != nil {
		return fmt.Errorf("TOPIX金融値混入")
	}
	s.all[id.Market]++
	s.count.RawBoards++
	return nil
}

// feed は保存Recordの位相/型/固定Tape対応だけを検査します。
//
// 引数: r(Record)は元一件。返り値: errorは不正です。C/M/Pや金融の再計算はCoreへ分離します。
func (s *replayState) feed(r stream.Record) error {
	if r.Ordinal != s.count.Records+1 || !finite(r.At) || r.At < s.input.Session.Start || s.have && r.At < s.at {
		return fmt.Errorf("Record連番/時計差")
	}
	if s.eof && !(r.Kind == "force" && r.AfterEOF) {
		return fmt.Errorf("EOF Force後の余剰Record")
	}
	if s.have && r.At == s.at && s.raw && (r.Kind == "publication" || r.Kind == "force" || r.Kind == "grid") {
		return fmt.Errorf("同時計raw後へpre制御を戻した")
	}
	if !s.have || r.At != s.at {
		s.raw = false
		s.rank = -1
	}
	rank := -1
	switch r.Kind {
	case "publication":
		rank = 0
	case "force":
		rank = 1
	case "grid":
		rank = 2
	}
	if rank >= 0 {
		if rank < s.rank {
			return fmt.Errorf("公表/Force/grid順差")
		}
		s.rank = rank
	}
	if r.Kind != "publication" && (r.Publication != nil || r.Delivery != nil) || r.Kind != "grid" && r.Grid != nil || r.Kind != "force" && (r.Force != nil || r.AfterEOF) || r.Kind != "quote" && r.Scalar != nil || r.Kind != "reset" && r.Reset != nil || (r.Kind != "quote" && r.Kind != "raw_clock") && r.RawQuote != nil {
		return fmt.Errorf("Record役割へ別payload混入")
	}
	if r.AfterEOF {
		if r.Kind != "force" || r.Trigger != nil || r.Force == nil {
			return fmt.Errorf("EOF架空Trigger")
		}
		s.eof = true
		s.afterEOF++
	} else if r.Trigger == nil || !finite(r.Trigger.Time) || r.Trigger.Time < r.At {
		return fmt.Errorf("観測契機不正")
	}
	if s.cursor < len(s.input.Events) {
		e := s.input.Events[s.cursor]
		if r.At > e.At {
			return fmt.Errorf("元Tape event飛越")
		}
		if r.At == e.At && (r.Kind == "reset" || r.Kind == "raw_clock") && (e.Kind == "force" || e.Kind == "grid") {
			return fmt.Errorf("raw制御がSourceへ先行")
		}
	}
	switch r.Kind {
	case "publication":
		p := r.Publication
		if p == nil || p.At != r.At || p.Snapshot.Legacy.Scene.ID != s.input.Session.ID || p.Snapshot.Legacy.Scene.Contract != s.contract || p.Snapshot.Legacy.Scene.Start != s.input.Session.Start {
			return fmt.Errorf("公表場/時計差")
		}
		if p.Three {
			if r.Delivery == nil || r.Delivery.At != r.At {
				return fmt.Errorf("3分Delivery欠落/時計差")
			}
			s.count.ThreePublications++
		} else if r.Delivery != nil {
			return fmt.Errorf("15分だけへ3分Delivery")
		}
		s.count.Publications++
	case "reset":
		id, q := r.Trigger, r.Reset
		if id == nil || q == nil || id.Market != "NK225" || id.FeaturesIndex != nil || q.Source.Valid || q.Source.Last > 0 || q.Source.Time != r.At || q.Source.Line != id.PhysicalLine || q.Source.Index != id.AllIndex || id.AllIndex != s.all[id.Market] || id.MergeOrdinal != s.count.RawBoards+1 {
			return fmt.Errorf("reset元出典差")
		}
		key := resetKey(r)
		if _, ok := s.pending[key]; ok {
			return fmt.Errorf("reset重複")
		}
		s.pending[key] = q.Source
		s.count.Resets++
		s.raw = true
	case "raw_clock":
		if e := s.rawRecord(r); e != nil {
			return e
		}
		s.raw = true
	case "quote", "force", "grid":
		if r.Kind == "quote" {
			if e := s.rawRecord(r); e != nil {
				return e
			}
			s.raw = true
		}
		if s.cursor >= len(s.input.Events) {
			return fmt.Errorf("元Tapeより余剰")
		}
		e := s.input.Events[s.cursor]
		if e.Kind != r.Kind || e.At != r.At {
			return fmt.Errorf("元Tape種別/時計差")
		}
		switch r.Kind {
		case "quote":
			if e.Quote == nil || r.Scalar == nil || !reflect.DeepEqual(*e.Quote, *r.Scalar) || e.Context != nil {
				return fmt.Errorf("元Scalar11全文差")
			}
			s.count.PositiveNK++
		case "force":
			if r.Force == nil || r.Force.At != e.At || r.Force.TapeOrdinal != e.Ordinal || e.Quote != nil || e.Context != nil {
				return fmt.Errorf("Force元ordinal差")
			}
			s.count.Forces++
		case "grid":
			if r.Grid == nil || r.Grid.Legacy.At != e.At || r.Grid.Legacy.Scene.ID != s.input.Session.ID || r.Grid.Legacy.Scene.Contract != s.contract || r.Grid.Legacy.Scene.Start != s.input.Session.Start || e.Quote != nil || len(e.Methods)+len(e.NonEmpty) != 0 || e.Context != nil && e.Context.At != e.At {
				return fmt.Errorf("grid出典差")
			}
			s.count.Grids++
		}
		if r.Kind != "grid" {
			if _, err := tape.RestoreBatches(e, s.lastSource); err != nil {
				return err
			}
		}
		s.cursor++
	default:
		return fmt.Errorf("未知Record種別")
	}
	s.count.Records++
	s.have = true
	s.at = r.At
	return nil
}

// ReplayRecords は認証済み保存gzipを一巡し、元順/全値のままSinkへ渡します。
//
// 引数: l(*Loaded)、sink(stream.Sink)はLoadTape成功とCore等の受け皿です。
// 返り値: 元Header/ReplayProof/error。金融/Bank/Source/Rawを実行せず入力変更を拒否します。
func ReplayRecords(l *Loaded, sink stream.Sink) (stream.Header, ReplayProof, error) {
	proof := ReplayProof{Before: map[string]string{}, After: map[string]string{}}
	var zero stream.Header
	if l == nil || sink == nil {
		return zero, proof, fmt.Errorf("認証入力/Sink必須")
	}
	hash, e := digestValue(l.input)
	if e != nil || hash != l.proof.TapeSHA {
		return zero, proof, fmt.Errorf("Loaded Tape変更")
	}
	for name, want := range l.proof.InputSHA {
		got, x := fileSHA(name)
		if x != nil || got != want {
			return zero, proof, fmt.Errorf("入力変更:%s", name)
		}
		proof.Before[name] = got
	}
	state := replayState{input: l.input, contract: l.public.Header.Scene.Contract, rank: -1, all: map[string]int64{}, pending: map[string]chart.Quote{}, lastSource: map[string]int64{}}
	e = readLines(l.records.Path, func(b []byte) error {
		var r stream.Record
		if e := strictBytes(b, &r); e != nil {
			return e
		}
		if e := state.feed(r); e != nil {
			return e
		}
		before, e := digestValue(r)
		if e != nil {
			return e
		}
		if e = sink(r); e != nil {
			return e
		}
		after, e := digestValue(r)
		if e != nil || before != after {
			return fmt.Errorf("Sinkが保存Recordを変更")
		}
		return nil
	})
	if e != nil {
		return zero, proof, e
	}
	h := l.public.Header
	c := state.count
	if state.cursor != len(l.input.Events) || len(state.pending) != 0 || h.Records != c.Records || h.RawBoards != c.RawBoards || h.PositiveNK != c.PositiveNK || h.Grids != c.Grids || h.Publications != c.Publications || h.ThreePublications != c.ThreePublications || h.Resets != c.Resets || h.Forces != c.Forces || h.AfterEOFForces != state.afterEOF {
		return zero, proof, fmt.Errorf("Header/Source全消費件数差")
	}
	hash, e = digestValue(l.input)
	if e != nil || hash != l.proof.TapeSHA {
		return zero, proof, fmt.Errorf("Sinkが共有Tapeを変更")
	}
	for name, want := range proof.Before {
		got, x := fileSHA(name)
		if x != nil || got != want {
			return zero, proof, fmt.Errorf("再読中の入力変更:%s", name)
		}
		proof.After[name] = got
	}
	proof.Records = c.Records
	proof.SourceEvents = state.cursor
	proof.Unchanged = true
	return l.Header(), proof, nil
}
