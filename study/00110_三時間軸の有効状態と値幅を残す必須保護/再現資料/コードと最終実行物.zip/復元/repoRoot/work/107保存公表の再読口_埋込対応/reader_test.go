package savedpublic107

import (
	"compress/gzip"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"testing"
	"time"

	continuous "github.com/masayoshi4649/SessionTradeExecuter/continuous101"
	followup "github.com/masayoshi4649/SessionTradeExecuter/fixedfollowup"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	actual "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	chart "github.com/masayoshi4649/SessionTradeExecuter/publicchart"
	delivery "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery"
	stream "github.com/masayoshi4649/SessionTradeExecuter/publicsidecar"
	binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
)

type fixture struct {
	root                                              string
	req                                               Request
	records                                           []stream.Record
	wrapper                                           PublicHeader
	complete                                          Completion
	input                                             tape.Tape
	headerPath, nativePath, recordsPath, completePath string
}

// put は手製型だけを通常/gzipへ保存します。
//
// 引数: t(*testing.T)、p(string)、v(any)、gz(bool)は人工先です。返り値: FileRefは実bytes指紋です。
func put(t *testing.T, p string, v any, gz bool) FileRef {
	t.Helper()
	f, e := os.Create(p)
	if e != nil {
		t.Fatal(e)
	}
	if gz {
		z := gzip.NewWriter(f)
		e = json.NewEncoder(z).Encode(v)
		if x := z.Close(); e == nil {
			e = x
		}
	} else {
		e = json.NewEncoder(f).Encode(v)
	}
	if x := f.Close(); e == nil {
		e = x
	}
	if e != nil {
		t.Fatal(e)
	}
	h, e := fileSHA(p)
	if e != nil {
		t.Fatal(e)
	}
	return FileRef{p, h}
}

// lines は金融/Source形成をせず手製JSONLを保存します。
//
// 引数: t/p/vは試験・先・公開型配列です。返り値: FileRefは実gzip指紋です。
func lines[T any](t *testing.T, p string, v []T) FileRef {
	t.Helper()
	f, e := os.Create(p)
	if e != nil {
		t.Fatal(e)
	}
	z := gzip.NewWriter(f)
	for _, x := range v {
		if e = json.NewEncoder(z).Encode(x); e != nil {
			t.Fatal(e)
		}
	}
	if e = z.Close(); e != nil {
		t.Fatal(e)
	}
	if e = f.Close(); e != nil {
		t.Fatal(e)
	}
	h, e := fileSHA(p)
	if e != nil {
		t.Fatal(e)
	}
	return FileRef{p, h}
}

// emptyDelta は固定RestoreBatchesと同じ合法空配列を手製値へ用意します。
//
// 引数: at/line/originは元型の値です。返り値: StepResultは経済妥当性を主張しないcodec器具です。
func emptyDelta(at float64, line int64, origin string) native.StepResult {
	return native.StepResult{At: at, Origin: origin, SourceLine: line, Signals: []native.SignalRecord{}, Fills: []native.FillRecord{}, Cancellations: []native.Cancellation{}, Closes: []native.CloseNotice{}}
}

// makeFixture は実ファイルに見立てない手製6Recordとmetadataを作ります。
//
// 引数: t(*testing.T)、kind(string)は三分岐です。返り値: *fixtureはRaw不存在でも読める型人工です。
func makeFixture(t *testing.T, kind string, roots ...string) *fixture {
	t.Helper()
	root := t.TempDir()
	if len(roots) > 0 {
		root = roots[0]
		if e := os.Mkdir(root, 0700); e != nil {
			t.Fatal(e)
		}
	}
	mf := Manifest{Root: "Rawは存在しない", StrategyRoot: "未使用", StrategySHA256: map[string]string{}}
	d := time.Date(2026, 9, 21, 0, 0, 0, 0, time.UTC)
	for len(mf.Sessions) < 70 {
		if d.Weekday() != time.Saturday && d.Weekday() != time.Sunday {
			for _, k := range []string{"Day", "Night"} {
				files := map[string]continuous.InputFile{}
				for _, n := range []string{"NK225_book", "NK225_candle_60", "NK225_candle_300", "TOPIX_book", "TOPIX_candle_60", "TOPIX_candle_300"} {
					files[n] = continuous.InputFile{Path: "未存在Raw_" + n, SHA256: strings.Repeat("a", 64), Size: 1}
				}
				mf.Sessions = append(mf.Sessions, continuous.InputSession{ID: d.Format("2006-01-02") + "_" + k, Contract: "手製107", Files: files})
			}
		}
		d = d.AddDate(0, 0, 1)
	}
	index := 0
	if kind == "fresh106_12" {
		index = 54
	} else if kind == "saved105_4" {
		index = 66
	}
	sid := mf.Sessions[index].ID
	session, e := followup.SessionClock(sid)
	if e != nil {
		t.Fatal(e)
	}
	scene := chart.Scene{ID: sid, Contract: "手製107", Start: session.Start}
	snap := chart.Snapshot{}
	snap.Legacy.Scene = scene
	snap.Legacy.At = session.Start
	i0, i1 := int64(0), int64(1)
	q0 := tape.ScalarQuote{Time: session.Start + 1, Received: session.Start + 1, Index: 0, SourceLine: 1, Last: 1005, Bid: 1000, Ask: 1010, QuoteOK: true, ATR: 40.75, ATRAvailable: session.Start, ATRNominal: session.Start - 300}
	q1 := q0
	q1.Time = session.Start + 2
	q1.Received = q1.Time
	q1.Index = 1
	q1.SourceLine = 3
	q1.Last = 1015
	q1.Bid = 1010
	q1.Ask = 1020
	trigger := func(at float64, line, all, merge int64, features *int64) *continuous.Identity {
		return &continuous.Identity{Market: "NK225", Time: at, PhysicalLine: line, AllIndex: all, FeaturesIndex: features, MergeOrdinal: int(merge)}
	}
	raw0 := chart.Quote{Time: q0.Time, Index: 0, Line: 1, Last: q0.Last, Bid: q0.Bid, Ask: q0.Ask, Valid: true}
	bad := chart.Quote{Time: session.Start + 2, Index: 1, Line: 2, Last: 0, Bid: 1000, Ask: 1010, Valid: false}
	raw1 := chart.Quote{Time: q1.Time, Index: 2, Line: 3, Last: q1.Last, Bid: q1.Bid, Ask: q1.Ask, Valid: true}
	records := []stream.Record{{Kind: "grid", At: session.Start, Trigger: trigger(q0.Time, 1, 0, 1, &i0), Grid: &snap}, {Kind: "quote", At: q0.Time, Trigger: trigger(q0.Time, 1, 0, 1, &i0), RawQuote: &raw0, Scalar: &q0}, {Kind: "reset", At: bad.Time, Trigger: trigger(bad.Time, 2, 1, 2, nil), Reset: &stream.Reset{Reason: "手製Last0", Source: bad}}, {Kind: "raw_clock", At: bad.Time, Trigger: trigger(bad.Time, 2, 1, 2, nil), RawQuote: &bad}, {Kind: "quote", At: q1.Time, Trigger: trigger(q1.Time, 3, 2, 3, &i1), RawQuote: &raw1, Scalar: &q1}, {Kind: "force", At: session.ForceClose, AfterEOF: true, Force: &stream.Force{At: session.ForceClose, TapeOrdinal: 4}}}
	for i := range records {
		records[i].Ordinal = i + 1
	}
	src := []binder.SourceRecord{}
	for _, pair := range []struct {
		q            *tape.ScalarQuote
		at           float64
		origin, kind string
		line         int64
	}{{&q0, q0.Time, "quote", "quote", 1}, {&q1, q1.Time, "quote", "quote", 3}, {nil, session.ForceClose, "timer", "force", 3}} {
		for _, product := range []string{"NK225micro", "NK225mini"} {
			x := binder.SourceRecord{Ordinal: len(src) + 1, Session: sid, Kind: pair.kind, Method: "D164_15", Product: product, Scalar: pair.q, Delta: emptyDelta(pair.at, pair.line, pair.origin)}
			if pair.q != nil {
				x.ObservationSHA = strings.Repeat("a", 64)
			} else {
				x.Delta.Closes = []native.CloseNotice{{ID: "手製codec", ReferenceID: "未運転hold", Before: 3, Quantity: 1, Reason: "Closes-only型だけ"}}
			}
			src = append(src, x)
		}
	}
	frames := []ClockFrame{{1, "grid", session.Start, nil}, {2, "quote", q0.Time, &q0}, {3, "quote", q1.Time, &q1}}
	base, _, e := BuildLegacyTape(session, frames, src)
	if e != nil {
		t.Fatal(e)
	}
	joined, _, e := binder.Bind(base, src, "symmetric")
	if e != nil {
		t.Fatal(e)
	}
	legacyRef := put(t, filepath.Join(root, "legacy.gz"), base, true)
	symRef := put(t, filepath.Join(root, "sym.gz"), joined, true)
	srcRef := lines(t, filepath.Join(root, "source.gz"), src)
	scenes := make([]SceneRef, 70)
	for i, x := range mf.Sessions {
		k := "old104_54"
		if i >= 66 {
			k = "saved105_4"
		} else if i >= 54 {
			k = "fresh106_12"
		}
		scenes[i] = SceneRef{Session: x.ID, Kind: k}
	}
	selected := scenes[index]
	switch kind {
	case "old104_54":
		selected.Clock = &legacyRef
		selected.Records = map[string]FileRef{"symmetric": srcRef}
	case "saved105_4":
		selected.Legacy = &legacyRef
		selected.Sym = &symRef
	case "fresh106_12":
		selected.Records = map[string]FileRef{"legacy": srcRef, "default": srcRef, "symmetric": srcRef}
	}
	scenes[index] = selected
	mfRef := put(t, filepath.Join(root, "manifest.json"), mf, false)
	corpus := Corpus{Version: 1, Trial: 106, Fixed: true, Manifest: mfRef, Source12: FileRef{"未使用Source完了", strings.Repeat("b", 64)}, Scenes: scenes}
	cp := put(t, filepath.Join(root, "corpus.json"), corpus, false)
	pipeline := Provenance{Scene: selected, Input: mf.Sessions[index], Manifest: mfRef, SeedPolicy: "first_cold_then_contract_carry", FirstSceneCold: index == 0, FeaturesRecomputed: true, ChartsRecomputed: true}
	end := snap
	end.Legacy.At = session.End
	end.Legacy.Sealed = true
	h := stream.Header{Version: 1, Scope: "手製型のみ。自然producer成功ではない", Success: true, Scene: scene, Records: 6, RawBoards: 3, PositiveNK: 2, Grids: 1, Resets: 1, Forces: 1, AfterEOFForces: 1, Ending: end, SkippedGrids: []float64{}, LegacyAllStateMatch: true, ForceClockOnly: true}
	f := &fixture{root: root, records: records, input: joined, recordsPath: filepath.Join(root, "records.gz"), headerPath: filepath.Join(root, "header.json"), nativePath: filepath.Join(root, "native.gz"), completePath: filepath.Join(root, "complete.json")}
	rr := lines(t, f.recordsPath, records)
	f.wrapper = PublicHeader{Version: 1, Trial: 106, ConditionSHA: Condition106, Header: h, RecordsSHA: rr.SHA, Pipeline: pipeline}
	hr := put(t, f.headerPath, f.wrapper, false)
	hash, _ := digestValue(joined)
	nm := NativeMetadata{Version: 1, Trial: 106, Session: session, Contract: scene.Contract, TapeSHA: hash, TapeUnchanged: true, Complete: true, CMPRecomputed: true, ConditionSHA: Condition106, Pipeline: pipeline}
	nr := put(t, f.nativePath, nm, true)
	count := 70
	stage := "full70"
	if index == 0 {
		count = 2
		stage = "first2"
	}
	results := []SceneOutput{}
	for i := 0; i < count; i++ {
		control := "provided_old_book"
		if i >= 54 && i < 66 {
			control = "same_input_old103"
		}
		results = append(results, SceneOutput{Session: mf.Sessions[i].ID, Native: nr, Header: hr, Records: rr, Books: 20, W0Books: 4, ControlKind: control})
	}
	before := map[string]string{mfRef.Path: mfRef.SHA, cp.Path: cp.SHA}
	f.complete = Completion{Version: 1, Trial: 106, Stage: stage, Success: true, ConditionSHA: Condition106, Sessions: count, BooksPerScene: 20, Books: 20 * count, Results: results, Before: before, After: copyValue(before), Unchanged: true, SeedPolicy: pipeline.SeedPolicy, FeaturesRecomputed: true, ChartsRecomputed: true, FinancialExecuted: true}
	completeRef := put(t, f.completePath, f.complete, false)
	f.req = Request{mfRef, cp, completeRef, sid}
	return f
}

// refresh は手製records破損を新しい明示Refへ結びます。
//
// 引数: t/fは試験と器具。返り値: なし。期待Tapeは変更しません。
func (f *fixture) refresh(t *testing.T) {
	rr := lines(t, f.recordsPath, f.records)
	f.wrapper.RecordsSHA = rr.SHA
	hr := put(t, f.headerPath, f.wrapper, false)
	for i := range f.complete.Results {
		f.complete.Results[i].Records = rr
		f.complete.Results[i].Header = hr
	}
	f.req.Completion = put(t, f.completePath, f.complete, false)
}

// TestThreeRoutes はRaw不存在の手製三分岐/Closes-only/0Index/同秒別行を確認します。
//
// 引数: t(*testing.T)。返り値: なし。自然Source/金融/Bankは実行しません。
func TestThreeRoutes(t *testing.T) {
	for _, kind := range []string{"old104_54", "saved105_4", "fresh106_12"} {
		t.Run(kind, func(t *testing.T) {
			f := makeFixture(t, kind)
			l, e := LoadTape(f.req)
			if e != nil {
				t.Fatal(e)
			}
			if !sameJSON(l.Tape(), f.input) {
				t.Fatal("Tape全field差")
			}
			captured := []stream.Record{}
			h, p, e := ReplayRecords(l, func(r stream.Record) error { captured = append(captured, copyValue(r)); return nil })
			if e != nil || !p.Unchanged || p.Records != 6 || p.SourceEvents != 4 || !sameJSON(h, f.wrapper.Header) || !sameJSON(captured, f.records) {
				t.Fatal("再読全値/件数差", e)
			}
			last := map[string]int64{}
			found := false
			for _, event := range l.Tape().Events {
				if event.Kind == "grid" {
					continue
				}
				b, e := tape.RestoreBatches(event, last)
				if e != nil {
					t.Fatal(e)
				}
				for _, x := range b {
					if len(x.Delta.Closes) > 0 {
						found = true
						if x.Delta.Closes[0].Before != 3 {
							t.Fatal("Before改変")
						}
					}
				}
			}
			if !found {
				t.Fatal("Closes-only落ち")
			}
			if kind == "fresh106_12" && l.Proof().Frames != 3 {
				t.Fatal("Frame別連番")
			}
			if l.Proof().BankRecomputed || l.Proof().FinancialExecuted || l.Proof().SourceReexecuted {
				t.Fatal("形成の虚偽")
			}
		})
	}
}

// TestRecordRejections は固定Refを更新した破損もSource順/型として拒否します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestRecordRejections(t *testing.T) {
	cases := []struct {
		name string
		edit func(*fixture)
	}{{"Record連番", func(f *fixture) { f.records[1].Ordinal = 99 }}, {"Force元ordinal", func(f *fixture) { f.records[5].Force.TapeOrdinal = 3 }}, {"同秒順", func(f *fixture) {
		f.records[2], f.records[4] = f.records[4], f.records[2]
		for i := range f.records {
			f.records[i].Ordinal = i + 1
		}
	}}, {"特徴と全Index混同", func(f *fixture) { f.records[4].RawQuote.Index = 1 }}, {"物理行", func(f *fixture) { f.records[1].Scalar.SourceLine = 7 }}, {"ATR全値", func(f *fixture) { f.records[1].Scalar.ATR = 41 }}, {"Source前にForce", func(f *fixture) { f.records[5].At = f.records[1].At }}, {"grid改時刻", func(f *fixture) { f.records[0].Grid.Legacy.At++ }}, {"EOF後原行", func(f *fixture) {
		x := copyValue(f.records[1])
		x.Ordinal = 7
		x.At = f.records[5].At + 1
		f.records = append(f.records, x)
	}}, {"別payload", func(f *fixture) { f.records[0].Scalar = f.records[1].Scalar }}}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			f := makeFixture(t, "old104_54")
			c.edit(f)
			f.refresh(t)
			l, e := LoadTape(f.req)
			if e == nil {
				_, _, e = ReplayRecords(l, func(stream.Record) error { return nil })
			}
			if e == nil {
				t.Fatal("破損受理")
			}
		})
	}
}

// TestMutationAndHash はSink/private境界と読取中の変更を検査します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestMutationAndHash(t *testing.T) {
	t.Run("Sink変更", func(t *testing.T) {
		f := makeFixture(t, "old104_54")
		l, e := LoadTape(f.req)
		if e != nil {
			t.Fatal(e)
		}
		_, _, e = ReplayRecords(l, func(r stream.Record) error {
			if r.Scalar != nil {
				r.Scalar.Bid++
			}
			return nil
		})
		if e == nil {
			t.Fatal("Sink改変受理")
		}
	})
	t.Run("共有Tape変更", func(t *testing.T) {
		f := makeFixture(t, "old104_54")
		l, e := LoadTape(f.req)
		if e != nil {
			t.Fatal(e)
		}
		q := l.Tape()
		q.Events[1].Quote.ATR++
		if _, _, e = ReplayRecords(l, func(stream.Record) error { return nil }); e == nil {
			t.Fatal("Tape改変受理")
		}
	})
	t.Run("gzip変更", func(t *testing.T) {
		f := makeFixture(t, "old104_54")
		l, e := LoadTape(f.req)
		if e != nil {
			t.Fatal(e)
		}
		if e = os.WriteFile(f.recordsPath, []byte("破損"), 0600); e != nil {
			t.Fatal(e)
		}
		if _, _, e = ReplayRecords(l, func(stream.Record) error { return nil }); e == nil {
			t.Fatal("SHA改変受理")
		}
	})
	t.Run("Header外部copy", func(t *testing.T) {
		f := makeFixture(t, "old104_54")
		l, e := LoadTape(f.req)
		if e != nil {
			t.Fatal(e)
		}
		h := l.Header()
		h.Records = 0
		p := l.Proof()
		for k := range p.InputSHA {
			p.InputSHA[k] = ""
		}
		if _, _, e = ReplayRecords(l, func(stream.Record) error { return nil }); e != nil {
			t.Fatal(e)
		}
	})
}

// TestJSONTypeBoundary は数値null/欠落/重複/余剰を未知0へ補いません。
//
// 引数: t(*testing.T)。返り値: なし。
func TestJSONTypeBoundary(t *testing.T) {
	q := tape.ScalarQuote{}
	b, _ := json.Marshal(q)
	for _, body := range []string{strings.Replace(string(b), `"index":0`, `"index":null`, 1), strings.Replace(string(b), `"atr":0,`, "", 1), strings.Replace(string(b), `"last":0`, `"last":0,"last":1`, 1), strings.Replace(string(b), `"last":0`, `"last":0,"extra":1`, 1)} {
		var out tape.ScalarQuote
		if e := strictBytes([]byte(body), &out); e == nil {
			t.Fatal("型破損受理", body)
		}
	}
	var out tape.ScalarQuote
	if e := strictBytes(b, &out); e != nil {
		t.Fatal("0Index合法", e)
	}
}

// TestMetadataAndNativeHash は虚偽完了/期待Tape SHA/Source通知破損を拒否します。
//
// 引数: t(*testing.T)。返り値: なし。
func TestMetadataAndNativeHash(t *testing.T) {
	t.Run("未完了", func(t *testing.T) {
		f := makeFixture(t, "fresh106_12")
		f.complete.Success = false
		f.req.Completion = put(t, f.completePath, f.complete, false)
		if _, e := LoadTape(f.req); e == nil {
			t.Fatal("未完了受理")
		}
	})
	t.Run("期待TapeSHA", func(t *testing.T) {
		f := makeFixture(t, "old104_54")
		var nm NativeMetadata
		if e := readJSON(f.nativePath, &nm, true, false); e != nil {
			t.Fatal(e)
		}
		nm.TapeSHA = strings.Repeat("b", 64)
		n := put(t, f.nativePath, nm, true)
		for i := range f.complete.Results {
			f.complete.Results[i].Native = n
		}
		f.req.Completion = put(t, f.completePath, f.complete, false)
		if _, e := LoadTape(f.req); e == nil {
			t.Fatal("期待SHA改変受理")
		}
	})
	t.Run("SourceSHA", func(t *testing.T) {
		f := makeFixture(t, "fresh106_12")
		if e := os.WriteFile(filepath.Join(f.root, "source.gz"), []byte("破損"), 0600); e != nil {
			t.Fatal(e)
		}
		if _, e := LoadTape(f.req); e == nil {
			t.Fatal("Source改変受理")
		}
	})
	t.Run("sink error", func(t *testing.T) {
		f := makeFixture(t, "old104_54")
		l, e := LoadTape(f.req)
		if e != nil {
			t.Fatal(e)
		}
		if _, _, e = ReplayRecords(l, func(stream.Record) error { return fmt.Errorf("手製停止") }); e == nil {
			t.Fatal("部分配送を成功")
		}
	})
}

// TestStoppedArtificialPublicTypes は停止Go型公表の全fieldを読めることだけを確認します。
//
// 引数: t(*testing.T)。返り値: なし。市場値/金融/Bankは再実行しません。
func TestStoppedArtificialPublicTypes(t *testing.T) {
	_, file, _, _ := runtime.Caller(0)
	p := filepath.Join(filepath.Dir(file), "../106可変保護の市場接続準備/人工_停止版/方向1_助走false.json")
	h, e := fileSHA(p)
	if e != nil || h != "338053abd284a1dadf2051e3d31f67cb4125a82ad7b659320ef93ef617ae25c1" {
		t.Fatal("停止人工SHA", e)
	}
	var v struct {
		Header  stream.Header   `json:"header"`
		Records []stream.Record `json:"records"`
	}
	if e = readJSON(p, &v, false, false); e != nil {
		t.Fatal(e)
	}
	pubs := 0
	for _, r := range v.Records {
		b, _ := json.Marshal(r)
		var out stream.Record
		if e = strictBytes(b, &out); e != nil {
			t.Fatal("停止公表型", e)
		}
		if !sameJSON(r, out) {
			t.Fatal("型往復差")
		}
		if r.Kind == "publication" {
			pubs++
		}
	}
	if pubs == 0 {
		t.Fatal("公表人工なし")
	}
	b, _ := json.Marshal(v.Header)
	var head stream.Header
	if e = strictBytes(b, &head); e != nil {
		t.Fatal(e)
	}
	for _, b := range []string{`{"new":null,"id":"x"}`, `{"new":false,"id":null}`} {
		var x delivery.Result
		if strictBytes([]byte(b), &x) == nil {
			t.Fatal("nullable型破損")
		}
	}
}

var _ actual.Session

// TestExportReaderFixture は明示環境変数時だけcodec型人工を新規先へ保存します。
//
// 引数: t(*testing.T)、環境SAVEDPUBLIC107_EXPORTは新規dir。返り値: なし。市場/Source/金融を生成しません。
func TestExportReaderFixture(t *testing.T) {
	out := os.Getenv("SAVEDPUBLIC107_EXPORT")
	if out == "" {
		t.Skip("明示型exportなし")
	}
	if e := os.Mkdir(out, 0700); e != nil {
		t.Fatal(e)
	}
	requests := []Request{}
	for _, kind := range []string{"old104_54", "saved105_4", "fresh106_12"} {
		f := makeFixture(t, kind, filepath.Join(out, kind))
		l, e := LoadTape(f.req)
		if e != nil {
			t.Fatal(e)
		}
		h, p, e := ReplayRecords(l, func(stream.Record) error { return nil })
		if e != nil {
			t.Fatal(e)
		}
		put(t, filepath.Join(out, kind, "期待.json"), map[string]any{"scope": "手製codec型のみ。SourceのCloses-onlyは未運転holdへの通知で、金融成功器具ではない", "request": f.req, "tape": l.Tape(), "header": h, "input_proof": l.Proof(), "replay_proof": p}, false)
		requests = append(requests, f.req)
	}
	put(t, filepath.Join(out, "公開型.json"), map[string]any{"scope": "3分類の手製bytes/metadata/Source codec。Raw不存在、自然Source/Bank/金融実行0", "requests": requests}, false)
}
