# 107保存readerの匿名埋込対応版

元の停止 `../107保存公表の再読口/停止.json`（7ac3099c…）を変更せず、別ディレクトリへ派生した入力readerです。module/package名と公開APIは同じです。

`far82.CurrentEvidence` は `far81.CurrentEvidence` を匿名埋込し、JSONでは `reference/time/source_index` 等が平坦に並びます。元の必須検査は匿名型名 `CurrentEvidence` をネストfieldとして要求していました。本版は `encoding/json` の実field選択に合わせ、匿名structのpromotion、浅いfield優先、同じ深さのtag優先、同順位の衝突除外を適用します。tag付き匿名fieldはネストを維持します。型選択だけを不変cacheへ保存し、入力値はcacheしません。

実際に選択された非omitempty fieldの必須・非nullable値のnull拒否、型、余剰、重複の検査は維持します。nilの匿名pointerによって全promoted fieldが省略される場合だけ、そのpointer群を未存在として扱い、一部があれば他の必須fieldも要求します。実市場の今回対象は匿名値structです。

変更は `io.go` のstruct field選択と新規 `embedded.go`、必要な人工だけです。`load.go/replay.go/fresh_clock.go/types.go/reader_test.go/go.mod/go.sum` は元のbytesと同体です。Source/Tape復元、記録順、入力の指紋結合、Scalar11、公開時計、Sink配送は変更していません。

検査は次のコマンドをこのディレクトリで実行します。

```powershell
go test -count=1 -json ./...
go vet ./...
go build ./...
```

`検査と停止を記録する.py` は上記ログ・差分・前後指紋と停止を新規保存します。実型 `TechnicalGateInput` と `Tape.events.context.current` のGo Marshalを使用し、必須欠落/null/型/偽ネスト/重複の拒否を確認します。旧readerの手製3経路・公開型試験も同じtest内で検査します。

市場のRaw/CSV/Native/Tape/Record本文を独自に読みません。市場first2の成功・70場成功・金融の成功は未確認です。市場口はRootが本版停止とGo閉包を固定して別途実行します。
