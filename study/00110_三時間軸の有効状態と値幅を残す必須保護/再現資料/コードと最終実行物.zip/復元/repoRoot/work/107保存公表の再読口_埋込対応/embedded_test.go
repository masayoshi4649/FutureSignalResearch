package savedpublic107

import (
	"encoding/json"
	"strings"
	"testing"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	actual "github.com/masayoshi4649/SessionTradeExecuter/minichart"
)

// embeddedJSON は人工のGo実型だけを公開JSONへ変換します。
//
// 引数: t(*testing.T)、v(any)は試験と人工値。返り値: []byteは実Marshal結果です。
func embeddedJSON(t *testing.T, v any) []byte {
	t.Helper()
	b, err := json.Marshal(v)
	if err != nil {
		t.Fatal(err)
	}
	return b
}

// TestEmbeddedActualCurrent は失敗経路と同じ公開型を平坦JSONで検査します。
//
// 引数: t(*testing.T)は人工試験。返り値: なし。市場のInputは読みません。
func TestEmbeddedActualCurrent(t *testing.T) {
	in := actual.TechnicalGateInput{SnapshotID: "人工-G0001", At: 10, Kind: "Day"}
	in.Current.Reference = "人工"
	in.Current.Time = 10
	in.Current.Received = 10
	in.Current.SourceIndex = 0
	in.Current.SourceLine = 1
	in.Current.Last = 1000
	in.Current.Bid = 995
	in.Current.Ask = 1005
	b := embeddedJSON(t, in)
	var out actual.TechnicalGateInput
	if err := strictBytes(b, &out); err != nil || !sameJSON(in, out) {
		t.Fatalf("公開実型の平坦化差: %v", err)
	}
	var root map[string]json.RawMessage
	if err := json.Unmarshal(b, &root); err != nil {
		t.Fatal(err)
	}
	var current map[string]json.RawMessage
	if err := json.Unmarshal(root["current"], &current); err != nil {
		t.Fatal(err)
	}
	if _, nested := current["CurrentEvidence"]; nested || current["reference"] == nil {
		t.Fatal("実型のJSON平坦化を確認できない")
	}
	for _, name := range []string{"必須欠落", "null", "型", "偽ネスト", "重複"} {
		t.Run(name, func(t *testing.T) {
			var r map[string]json.RawMessage
			var c map[string]json.RawMessage
			_ = json.Unmarshal(b, &r)
			_ = json.Unmarshal(r["current"], &c)
			switch name {
			case "必須欠落":
				delete(c, "reference")
			case "null":
				c["source_index"] = json.RawMessage("null")
			case "型":
				c["time"] = json.RawMessage(`"10"`)
			case "偽ネスト":
				c["CurrentEvidence"] = json.RawMessage(`{}`)
			}
			r["current"] = embeddedJSON(t, c)
			bad := embeddedJSON(t, r)
			if name == "重複" {
				bad = []byte(strings.Replace(string(bad), `"reference":"人工"`, `"reference":"人工","reference":"人工"`, 1))
			}
			if err := strictBytes(bad, &out); err == nil {
				t.Fatal("破損を受理")
			}
		})
	}

	// ----------------------------------------
	// 元失敗と同じTape→event→context→current経路を実型Marshalで通します。
	x := tape.Tape{Events: []tape.TapeEvent{{Context: &in}}}
	var restored tape.Tape
	if err := strictBytes(embeddedJSON(t, x), &restored); err != nil || !sameJSON(x, restored) {
		t.Fatalf("Tape実型の平坦化差: %v", err)
	}
}

type EmbeddedBase struct {
	X      float64 `json:"x"`
	Shared int     `json:"shared"`
}
type EmbeddedFlat struct {
	EmbeddedBase
	Y bool `json:"y"`
}
type EmbeddedShallow struct {
	EmbeddedBase
	X string `json:"x"`
}
type EmbeddedNamed struct {
	EmbeddedBase `json:"base"`
}
type EmbeddedIgnored struct {
	EmbeddedBase `json:"-"`
	Y            bool `json:"y"`
}
type EmbeddedPointer struct {
	*EmbeddedBase
	Y bool `json:"y"`
}
type EmbeddedA struct{ Value int }
type EmbeddedB struct{ Value string }
type EmbeddedConflict struct {
	EmbeddedA
	EmbeddedB
	Y bool `json:"y"`
}
type EmbeddedTagged struct {
	Value string `json:"Value"`
}
type EmbeddedTagWins struct {
	EmbeddedA
	EmbeddedTagged
}

// TestEmbeddedSelection は匿名promotionの浅さ/tag/衝突と必須の厳密性を分けます。
//
// 引数: t(*testing.T)は型人工。返り値: なし。encoding/jsonの実Marshalを権威にします。
func TestEmbeddedSelection(t *testing.T) {
	for _, tc := range []struct {
		name  string
		value any
		out   any
	}{
		{"平坦", EmbeddedFlat{}, &EmbeddedFlat{}},
		{"浅いfield", EmbeddedShallow{X: "文字列"}, &EmbeddedShallow{}},
		{"tag付き匿名", EmbeddedNamed{}, &EmbeddedNamed{}},
		{"無視", EmbeddedIgnored{}, &EmbeddedIgnored{}},
		{"衝突除外", EmbeddedConflict{}, &EmbeddedConflict{}},
		{"tag優先", EmbeddedTagWins{EmbeddedTagged: EmbeddedTagged{"文字列"}}, &EmbeddedTagWins{}},
		{"nil匿名pointer", EmbeddedPointer{}, &EmbeddedPointer{}},
		{"値付き匿名pointer", EmbeddedPointer{EmbeddedBase: &EmbeddedBase{}}, &EmbeddedPointer{}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			if err := strictBytes(embeddedJSON(t, tc.value), tc.out); err != nil || !sameJSON(tc.value, tc.out) {
				t.Fatalf("Marshal選択と不一致: %v", err)
			}
		})
	}
	for _, tc := range []struct {
		name string
		data string
		out  any
	}{
		{"平坦実field欠落", `{"shared":0,"y":false}`, &EmbeddedFlat{}},
		{"平坦実fieldnull", `{"x":null,"shared":0,"y":false}`, &EmbeddedFlat{}},
		{"衝突field余剰", `{"Value":0,"y":false}`, &EmbeddedConflict{}},
		{"namedを平坦化", `{"x":0,"shared":0}`, &EmbeddedNamed{}},
		{"tag勝者の型", `{"Value":0}`, &EmbeddedTagWins{}},
		{"浅い勝者の型", `{"x":0,"shared":0}`, &EmbeddedShallow{}},
		{"部分pointer欠落", `{"x":0,"y":false}`, &EmbeddedPointer{}},
	} {
		t.Run(tc.name, func(t *testing.T) {
			if err := strictBytes([]byte(tc.data), tc.out); err == nil {
				t.Fatal("破損を受理")
			}
		})
	}
}
