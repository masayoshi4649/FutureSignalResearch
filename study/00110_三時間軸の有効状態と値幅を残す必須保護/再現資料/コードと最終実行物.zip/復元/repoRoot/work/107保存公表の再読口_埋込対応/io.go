package savedpublic107

import (
	"bufio"
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"strings"

	delivery "github.com/masayoshi4649/SessionTradeExecuter/publicdelivery"
)

// validSHA は省略/大文字を補完せず固定指紋を検査します。
//
// 引数: s(string)は指紋。返り値: boolは小文字64桁だけ真です。
func validSHA(s string) bool {
	b, e := hex.DecodeString(s)
	return e == nil && len(b) == 32 && strings.ToLower(s) == s
}

// fileSHA は明示入力だけをstreamで指紋化します。
//
// 引数: p(string)は元参照。返り値: string/errorは実SHA又はI/O不正です。
func fileSHA(p string) (string, error) {
	f, e := os.Open(p)
	if e != nil {
		return "", e
	}
	defer f.Close()
	h := sha256.New()
	if _, e = io.Copy(h, f); e != nil {
		return "", e
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

// absolute は参照元parent基準を一つに固定します。
//
// 引数: base/name(string)は基準とpath。返り値: string/errorは絶対path又は空参照です。
func absolute(base, name string) (string, error) {
	if strings.TrimSpace(name) == "" {
		return "", fmt.Errorf("空path")
	}
	if !filepath.IsAbs(name) {
		name = filepath.Join(base, name)
	}
	return filepath.Abs(name)
}

// bind は実SHAを確認し同pathの二重指紋を拒否します。
//
// 引数: r(FileRef)、base(string)、before(map)は固定参照と元根。返り値: FileRef/errorは絶対参照です。
func bind(r FileRef, base string, before map[string]string) (FileRef, error) {
	if !validSHA(r.SHA) {
		return r, fmt.Errorf("未固定SHA")
	}
	p, e := absolute(base, r.Path)
	if e != nil {
		return r, e
	}
	h, e := fileSHA(p)
	if e != nil || h != r.SHA {
		return r, fmt.Errorf("FileRef差:%s", p)
	}
	if old, ok := before[p]; ok && old != h {
		return r, fmt.Errorf("同path二指紋")
	}
	before[p] = h
	return FileRef{p, h}, nil
}

// sameJSON はfield除外や許容幅なしで全値を比較します。
//
// 引数: a/b(any)は保存値。返り値: boolは元JSON値が同体の場合だけ真です。
func sameJSON(a, b any) bool {
	x, e := json.Marshal(a)
	if e != nil {
		return false
	}
	y, e := json.Marshal(b)
	return e == nil && bytes.Equal(x, y)
}

// copyValue は小さい証拠/型の共有pointerを外します。
//
// 引数: v(T)はJSON公開型。返り値: Tは同じ全値の独立copyです。
func copyValue[T any](v T) T {
	b, e := json.Marshal(v)
	if e != nil {
		panic(e)
	}
	var o T
	if e = json.Unmarshal(b, &o); e != nil {
		panic(e)
	}
	return o
}

// digestValue は固定Tape/保存RecordのGo全JSON指紋です。
//
// 引数: v(any)は公開型。返り値: string/errorはcanonical Go JSON SHAです。
func digestValue(v any) (string, error) {
	b, e := json.Marshal(v)
	if e != nil {
		return "", e
	}
	h := sha256.Sum256(b)
	return hex.EncodeToString(h[:]), nil
}

// rejectDuplicate はJSON全階層の同名keyと末尾値を拒否します。
//
// 引数: b([]byte)は一JSON。返り値: errorは重複/構文/末尾です。値を形成しません。
func rejectDuplicate(b []byte) error {
	d := json.NewDecoder(bytes.NewReader(b))
	d.UseNumber()
	var walk func() error
	walk = func() error {
		t, e := d.Token()
		if e != nil {
			return e
		}
		if x, ok := t.(json.Delim); ok {
			switch x {
			case '{':
				seen := map[string]bool{}
				for d.More() {
					k, e := d.Token()
					if e != nil {
						return e
					}
					s, ok := k.(string)
					if !ok || seen[s] {
						return fmt.Errorf("重複JSON key:%v", k)
					}
					seen[s] = true
					if e = walk(); e != nil {
						return e
					}
				}
				_, e = d.Token()
				return e
			case '[':
				for d.More() {
					if e = walk(); e != nil {
						return e
					}
				}
				_, e = d.Token()
				return e
			default:
				return fmt.Errorf("JSON括弧不正")
			}
		}
		return nil
	}
	if e := walk(); e != nil {
		return e
	}
	if _, e := d.Token(); e != io.EOF {
		return fmt.Errorf("JSON末尾値")
	}
	return nil
}

// requiredShape はnullの0/false化と必須field欠落を防ぎます。
//
// 引数: b([]byte)、t(reflect.Type)は公開JSONとGo型。返り値: errorは不正型です。
func requiredShape(b []byte, t reflect.Type) error {
	if t == reflect.TypeOf(json.RawMessage{}) || t.Kind() == reflect.Interface {
		return nil
	}
	null := bytes.Equal(bytes.TrimSpace(b), []byte("null"))
	if null {
		switch t.Kind() {
		case reflect.Pointer, reflect.Map, reflect.Slice:
			return nil
		}
		return fmt.Errorf("非nullable型へnull:%s", t)
	}
	if t.Kind() == reflect.Pointer {
		return requiredShape(b, t.Elem())
	}
	switch t.Kind() {
	case reflect.Struct:
		var m map[string]json.RawMessage
		if e := json.Unmarshal(b, &m); e != nil {
			return e
		}
		if m == nil {
			return fmt.Errorf("object不正")
		}
		if t == reflect.TypeOf(delivery.Result{}) {
			if m["new"] == nil || bytes.Equal(bytes.TrimSpace(m["new"]), []byte("null")) || m["id"] == nil || bytes.Equal(bytes.TrimSpace(m["id"]), []byte("null")) {
				return fmt.Errorf("公表結果new/idのnull又は欠落")
			}
			var n bool
			if e := json.Unmarshal(m["new"], &n); e != nil {
				return e
			}
			if !n {
				if len(m) != 2 || m["id"] == nil {
					return fmt.Errorf("重複公表の省略型不正")
				}
				return nil
			}
		}
		allowed := map[string]bool{}
		fields := jsonShapeFields(t)
		activeGroups := map[string]bool{}
		for _, f := range fields {
			if _, present := m[f.name]; present {
				for _, group := range f.pointerGroups {
					activeGroups[group] = true
				}
			}
		}
		for _, f := range fields {
			allowed[f.name] = true
			raw, ok := m[f.name]
			if !ok {
				optional := f.optional
				for _, group := range f.pointerGroups {
					if !activeGroups[group] {
						optional = true
					}
				}
				if optional {
					continue
				}
				return fmt.Errorf("必須field欠落:%s.%s", t, f.name)
			}
			if e := requiredShape(raw, f.typ); e != nil {
				return fmt.Errorf("%s.%s:%w", t, f.name, e)
			}
		}
		for name := range m {
			if !allowed[name] {
				return fmt.Errorf("未定義JSON field:%s.%s", t, name)
			}
		}
	case reflect.Slice, reflect.Array:
		var a []json.RawMessage
		if e := json.Unmarshal(b, &a); e != nil {
			return e
		}
		for _, v := range a {
			if e := requiredShape(v, t.Elem()); e != nil {
				return e
			}
		}
	case reflect.Map:
		var m map[string]json.RawMessage
		if e := json.Unmarshal(b, &m); e != nil {
			return e
		}
		for _, v := range m {
			if e := requiredShape(v, t.Elem()); e != nil {
				return e
			}
		}
	}
	return nil
}

// strictBytes は元公開型の余剰/型/欠落/null/重複を検査します。
//
// 引数: b([]byte)、out(any)は保存JSONとpointer。返り値: errorは不正です。
func strictBytes(b []byte, out any) error {
	if e := rejectDuplicate(b); e != nil {
		return e
	}
	if e := requiredShape(b, reflect.TypeOf(out).Elem()); e != nil {
		return e
	}
	d := json.NewDecoder(bytes.NewReader(b))
	d.DisallowUnknownFields()
	if e := d.Decode(out); e != nil {
		return e
	}
	var tail any
	if e := d.Decode(&tail); e != io.EOF {
		return fmt.Errorf("JSON末尾")
	}
	return nil
}

// readJSON は明示した通常/gzip metadataを読みます。
//
// 引数: p(string)、out(any)、compressed/strict(bool)は位置・型・読取境界。返り値: errorです。
func readJSON(p string, out any, compressed, strict bool) error {
	f, e := os.Open(p)
	if e != nil {
		return e
	}
	defer f.Close()
	var rd io.Reader = f
	var gz *gzip.Reader
	if compressed {
		gz, e = gzip.NewReader(f)
		if e != nil {
			return e
		}
		defer gz.Close()
		rd = gz
	}
	if strict {
		b, e := io.ReadAll(rd)
		if e != nil {
			return e
		}
		return strictBytes(b, out)
	}
	d := json.NewDecoder(rd)
	if e = d.Decode(out); e != nil {
		return e
	}
	var tail any
	if e = d.Decode(&tail); e != io.EOF {
		return fmt.Errorf("JSON末尾")
	}
	return nil
}

// readLines は巨大gzip全体を複製せずJSONLの一行ずつを渡します。
//
// 引数: p(string)、sink(func([]byte)error)は明示gzipと受け皿。返り値: errorです。
func readLines(p string, sink func([]byte) error) error {
	f, e := os.Open(p)
	if e != nil {
		return e
	}
	defer f.Close()
	z, e := gzip.NewReader(f)
	if e != nil {
		return e
	}
	defer z.Close()
	rd := bufio.NewReader(z)
	for {
		b, e := rd.ReadBytes('\n')
		if len(b) > 0 {
			if len(bytes.TrimSpace(b)) == 0 {
				return fmt.Errorf("JSONL空行")
			}
			if x := sink(b); x != nil {
				return x
			}
		}
		if e == io.EOF {
			return nil
		}
		if e != nil {
			return e
		}
	}
}
