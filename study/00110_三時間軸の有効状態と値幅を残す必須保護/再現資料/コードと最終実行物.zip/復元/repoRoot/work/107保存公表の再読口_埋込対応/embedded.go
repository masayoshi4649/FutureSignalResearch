package savedpublic107

import (
	"reflect"
	"strings"
	"sync"
	"unicode"
)

// shapeField はencoding/jsonが選ぶ一つの実JSON fieldです。
type shapeField struct {
	name          string
	typ           reflect.Type
	optional      bool
	tagged        bool
	depth         int
	pointerGroups []string
}

// shapeFieldsCache は不変の型選択だけを共有し、入力JSON/値を保存しません。
var shapeFieldsCache sync.Map

// jsonTagName はencoding/jsonと同じtag名の有効文字だけを認めます。
//
// 引数: s(string)はjson tag名。返り値: boolは空でなく有効な名前です。
func jsonTagName(s string) bool {
	if s == "" {
		return false
	}
	for _, c := range s {
		if strings.ContainsRune("!#$%&()*+-./:;<=>?@[]^_{|}~ ", c) {
			continue
		}
		if !unicode.IsLetter(c) && !unicode.IsDigit(c) {
			return false
		}
	}
	return true
}

// jsonShapeFields は匿名structを平坦化し、深さ/tag/競合のGo選択規則を適用します。
//
// 引数: t(reflect.Type)はstruct型。返り値: []shapeFieldは実際のJSON名/型で、競合して無視されるfieldは含みません。
func jsonShapeFields(t reflect.Type) []shapeField {
	if cached, ok := shapeFieldsCache.Load(t); ok {
		return cached.([]shapeField)
	}
	byName := map[string][]shapeField{}
	order := []string{}
	var walk func(reflect.Type, int, string, []string, map[reflect.Type]bool)
	walk = func(current reflect.Type, depth int, path string, groups []string, ancestors map[reflect.Type]bool) {
		if ancestors[current] {
			return
		}
		next := map[reflect.Type]bool{}
		for k, v := range ancestors {
			next[k] = v
		}
		next[current] = true
		for i := 0; i < current.NumField(); i++ {
			f := current.Field(i)
			base := f.Type
			if base.Kind() == reflect.Pointer {
				base = base.Elem()
			}
			if f.PkgPath != "" && (!f.Anonymous || base.Kind() != reflect.Struct) {
				continue
			}
			parts := strings.Split(f.Tag.Get("json"), ",")
			name := parts[0]
			if name == "-" {
				continue
			}
			if !jsonTagName(name) {
				name = ""
			}
			childPath := path + "/" + f.Name
			if f.Anonymous && name == "" && base.Kind() == reflect.Struct {
				childGroups := append([]string{}, groups...)
				if f.Type.Kind() == reflect.Pointer {
					childGroups = append(childGroups, childPath)
				}
				walk(base, depth+1, childPath, childGroups, next)
				continue
			}
			tagged := name != ""
			if name == "" {
				name = f.Name
			}
			optional := false
			for _, option := range parts[1:] {
				if option == "omitempty" {
					optional = true
				}
			}
			if _, ok := byName[name]; !ok {
				order = append(order, name)
			}
			byName[name] = append(byName[name], shapeField{name, f.Type, optional, tagged, depth, append([]string{}, groups...)})
		}
	}
	walk(t, 0, "", nil, map[reflect.Type]bool{})
	selected := []shapeField{}
	for _, name := range order {
		all := byName[name]
		minimum := all[0].depth
		for _, f := range all {
			if f.depth < minimum {
				minimum = f.depth
			}
		}
		same := []shapeField{}
		tagged := []shapeField{}
		for _, f := range all {
			if f.depth == minimum {
				same = append(same, f)
				if f.tagged {
					tagged = append(tagged, f)
				}
			}
		}
		if len(tagged) == 1 {
			selected = append(selected, tagged[0])
		} else if len(tagged) == 0 && len(same) == 1 {
			selected = append(selected, same[0])
		}
	}
	stored, _ := shapeFieldsCache.LoadOrStore(t, selected)
	return stored.([]shapeField)
}
