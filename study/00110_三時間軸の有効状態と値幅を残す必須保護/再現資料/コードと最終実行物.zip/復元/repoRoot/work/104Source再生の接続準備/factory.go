package minisourcereplay104

import (
	"fmt"
	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	symmetric "github.com/masayoshi4649/SessionTradeExecuter/minisymmetric104"
	"reflect"
	"sort"
)

type Session = native.Session
type Observation = native.Observation
type Ledger = native.Ledger

// SourceAdapter は旧93と新生成口の同じ公開更新型だけを扱います。
type SourceAdapter interface {
	Step(Observation, int64) (native.StepResult, error)
	Force(float64) (native.StepResult, error)
	Snapshot() native.Ledger
	Finish() (native.Ledger, error)
}

// AdapterFactory は元手法/場/商品を受ける生成時だけの差替口です。
//
// 引数: method(string)、session(Session)、config(ProductConfig)は元93の値です。
// 返り値: SourceAdapter/errorは生成済み元Source又は不整合です。
type AdapterFactory func(string, Session, native.ProductConfig) (SourceAdapter, error)

type RuleMode string

const (
	RuleEmpty     RuleMode = ""
	RuleDefault   RuleMode = "default"
	RuleSymmetric RuleMode = "symmetric"
)

// RuleFactory は停止e519の完全式map生成口を選びます。
//
// 引数: mode(RuleMode)は空override/既定全式/重複待機1式候補です。
// 返り値: AdapterFactory/errorは新生成口又は未知modeです。市場の実行許可を意味しません。
func RuleFactory(mode RuleMode) (AdapterFactory, error) {
	if mode != RuleEmpty && mode != RuleDefault && mode != RuleSymmetric {
		return nil, fmt.Errorf("未定義のSource式mode")
	}
	return func(method string, session Session, config native.ProductConfig) (SourceAdapter, error) {
		var full map[string]string
		var err error
		if mode == RuleDefault {
			full, err = symmetric.DefaultRuleExpressions(method, session)
		}
		if mode == RuleSymmetric {
			full, err = symmetric.SymmetricRuleExpressions(method, session)
		}
		if err != nil {
			return nil, err
		}
		return symmetric.NewAdapterWithRules(method, session, config, full)
	}, nil
}

// createAdapter はnilだけを旧93の生成口へ対応します。
//
// 引数: factory(AdapterFactory)、method(string)、session(Session)、config(ProductConfig)は生成条件です。
// 返り値: SourceAdapter/errorは生成済みadapter又は設定不整合です。
func createAdapter(factory AdapterFactory, method string, session Session, config native.ProductConfig) (SourceAdapter, error) {
	if factory == nil {
		return native.NewAdapter(method, session, config)
	}
	return factory(method, session, config)
}

// MicroControlConfig は元93のmicro規格を返します。
//
// 引数: ありません。
// 返り値: native.ProductConfigは50+50/点価10の固定対照です。
func MicroControlConfig() native.ProductConfig { return native.MicroControlConfig() }

// MiniConfig は元93のmini規格を返します。
//
// 引数: ありません。
// 返り値: native.ProductConfigは5+5/点価100の規格です。
func MiniConfig() native.ProductConfig { return native.MiniConfig() }

// BoardRow/CandleEvent は準備済みの完全入力を渡す人工/将来hook用の公開型です。
type BoardRow = replayBoard
type CandleEvent = candleEvent

// ReplayPrepared はIOを行わず完全なBoard/Candleから旧特徴器を通します。
//
// 引数: session(Session)、boards([]BoardRow)、candles([]CandleEvent)、factory(AdapterFactory)は人工又は事前固定された完全入力です。
// 返り値: ReplayResult/errorは元Source運転の結果又は不整合です。入力価格/数量の欠落を補いません。
func ReplayPrepared(session Session, boards []BoardRow, candles []CandleEvent, factory AdapterFactory) (ReplayResult, error) {
	result := ReplayResult{Session: session.ID, Quality: map[string]RawQuality{}, SourceRows: map[string]int{}, Books: map[string]native.Ledger{}}
	method := "D164_15"
	if session.Kind == "Night" {
		method = "P164_06"
	}
	params, err := strategy.ParametersForMethod("NK225", session.Kind, method)
	if err != nil {
		return result, err
	}
	if session.Kind == "Night" {
		after, e := strategy.ParametersForMethod("NK225", "Night", "U165_03")
		if e != nil {
			return result, e
		}
		if !reflect.DeepEqual(params.Features, after.Features) {
			return result, fmt.Errorf("二夜手法の特徴条件が不一致です")
		}
	}
	features, err := strategy.NewFeatures(session, map[string]float64{"NK225": 10, "TOPIX": .5}, params.Features)
	if err != nil {
		return result, err
	}
	features.EnableResearch()
	rows := append([]replayBoard(nil), boards...)
	cs := append([]candleEvent(nil), candles...)
	sort.SliceStable(rows, func(i, j int) bool { return rows[i].Board.Time < rows[j].Board.Time })
	sort.SliceStable(cs, func(i, j int) bool { return cs[i].At < cs[j].At })
	return replayLoaded(result, session, method, features, rows, cs, factory)
}
