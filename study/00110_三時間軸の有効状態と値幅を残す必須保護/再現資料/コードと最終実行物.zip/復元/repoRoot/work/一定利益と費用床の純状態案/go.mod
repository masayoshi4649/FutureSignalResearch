module github.com/masayoshi4649/SessionTradeExecuter/profitfloorproposal

go 1.24.0
