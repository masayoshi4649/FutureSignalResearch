package profitfloorproposal

import (
	"fmt"
	"math"
	"reflect"
	"testing"
)

// fixture は市場入力に依存しない固定の人工新規を作ります。
//
// 引数: policy(Policy)、side(int)、slip(float64)は政策・方向・仮定費用。
// 返り値: Entryは人工価格10000・7枚の新規です。
func fixture(policy Policy, side int, slip float64) Entry {
	scope := Scope{"人工場", "人工限月", 1000}
	return Entry{Scope: scope, Policy: policy, Side: side, Price: 10000, At: 2800, InitialQuantity: 7, SlipPoints: slip,
		EntryV: &Evidence{80, 2800, "人工V"}, ATR: &Evidence{100, 2800, "人工ATR"}}
}

// mustNew は人工条件の生成失敗をテスト失敗にします。
//
// 引数: t(*testing.T)、entry(Entry)はテストと新規。返り値: Stateは純状態です。
func mustNew(t *testing.T, entry Entry) State {
	t.Helper()
	s, err := NewState(entry)
	if err != nil {
		t.Fatal(err)
	}
	return s
}

// step は符号付きの粗価格差で人工入力を作ります。
//
// 引数: s(State)、sequence(uint64)、at/gain(float64)は状態・順序・時刻・価格差。
// 返り値: Inputは全残玉を予約せずafter_sourceで評価する入力です。
func step(s State, sequence uint64, at, gain float64) Input {
	return Input{At: at, Sequence: sequence, Phase: AfterSource, Mark: ptr(s.entry.Price + float64(s.entry.Side)*gain), Remaining: s.remaining}
}

// publication は外部形成済みという契約の人工3分公表を作ります。
//
// 引数: s(State)、ordinal(uint64)、end/v(float64)、c/m(Truth)は状態・公表順・時計・値幅・三値。
// 返り値: *Publicationは価格窓の形成を行わない人工公表です。
func publication(s State, ordinal uint64, end, v float64, c, m Truth) *Publication {
	return &Publication{Scope: s.entry.Scope, ID: fmt.Sprintf("人工公表%d", ordinal), Ordinal: ordinal,
		End: end, AvailableAt: end, V: ptr(v), C: c, M: m, Close: ptr(s.entry.Price)}
}

// advance は純更新の失敗をテスト失敗にします。
//
// 引数: t(*testing.T)、s(State)、in(Input)はテスト・状態・入力。
// 返り値: State/Decisionは次状態と純判定です。
func advance(t *testing.T, s State, in Input) (State, Decision) {
	t.Helper()
	next, d, err := Advance(s, in)
	if err != nil {
		t.Fatal(err)
	}
	return next, d
}

// TestEntryCostsAndThreshold は費用・V固定・格子と到達境界を検証します。
//
// 引数: t(*testing.T)はテスト文脈。返り値: ありません。
func TestEntryCostsAndThreshold(t *testing.T) {
	for _, row := range []struct{ slip, cost, threshold, fee, floor, below, reached float64 }{
		{0, .77, 20, 5, 10, 20, 25}, {5, 10.77, 25, 15, 20, 35, 40},
	} {
		s := mustNew(t, fixture(G1, 1, row.slip))
		x := s.Snapshot()
		if x.CostPoints != row.cost || x.ThresholdPoints != row.threshold || x.FeeFloor != row.fee || x.MinimumFloor != row.floor {
			t.Fatalf("費用の単位又は丸めが違う: %+v", x)
		}
		s, d := advance(t, s, step(s, 1, 2801, row.below))
		if s.active || d.ActivatedNow {
			t.Fatal("費用控除後に未達なのに起動")
		}
		s, d = advance(t, s, step(s, 2, 2802, row.reached))
		if !s.active || !d.ActivatedNow || *s.floor != row.floor {
			t.Fatal("一定利益で必須起動しない")
		}
		wantUnit := row.reached*100 - (77 + 200*row.slip)
		if *d.UnitNetYen != wantUnit {
			t.Fatal("費用式の二重加算又は不足")
		}
	}
	for _, net := range []float64{math.Nextafter(2000, math.Inf(-1)), 2000, math.Nextafter(2000, math.Inf(1))} {
		got, err := ActivationEligible(net, 20)
		if err != nil || got != (net >= 2000) {
			t.Fatal("単位額の直前・同値・直後境界が違う")
		}
	}
	entry := fixture(G2, 1, 0)
	entry.EntryV.Value = 400
	s := mustNew(t, entry)
	entry.EntryV.Value = 800
	if s.threshold != 100 || s.entry.EntryV.Value != 400 {
		t.Fatal("入力ポインタ又はHが変更された")
	}
	in := step(s, 1, 2980, 50)
	in.Publication = publication(s, 1, 2980, 20, True, True)
	s, _ = advance(t, s, in)
	if s.active || s.threshold != 100 {
		t.Fatal("後のVで固定Hが低下")
	}
	s, _ = advance(t, s, step(s, 2, 2981, 105))
	if !s.active || s.threshold != 100 {
		t.Fatal("新規時H到達の必須起動に失敗")
	}
}

// TestUnknownAndFirstATR は不明を入口へ補完せず保護を起動し、最初のATRだけ固定します。
//
// 引数: t(*testing.T)はテスト文脈。返り値: ありません。
func TestUnknownAndFirstATR(t *testing.T) {
	entry := fixture(G2, 1, 0)
	entry.EntryV, entry.ATR = nil, nil
	s := mustNew(t, entry)
	in := step(s, 1, 2801, 25)
	s, d := advance(t, s, in)
	if !s.active || s.width != nil || *s.floor != 10 || s.threshold != 20 || !s.Snapshot().EntryVFallback || d.Warning != Unknown {
		t.Fatal("V/ATR不明で最低保護が止まった")
	}
	in = step(s, 2, 2980, 100)
	in.ATR = &Evidence{10, 2980, "後判明ATR"}
	in.Publication = publication(s, 1, 2980, 1000, False, False)
	s, _ = advance(t, s, in)
	if s.threshold != 20 || s.entry.EntryV != nil || s.atr.Value != 10 || *s.width != 20 || *s.floor != 80 {
		t.Fatal("後判明でH又は既知性を補完した、あるいはATR幅が違う")
	}
	in = step(s, 3, 2981, 100)
	in.ATR = &Evidence{20, 2980, "後判明ATR"}
	if _, _, err := Advance(s, in); err == nil {
		t.Fatal("ATR変更を受理")
	}
}

// possibilities は不明の独立した真偽解釈を列挙します。
//
// 引数: value(Truth)は三値。返り値: []boolは意味上可能な真偽です。
func possibilities(value Truth) []bool {
	if value == Unknown {
		return []bool{false, true}
	}
	return []bool{value == True}
}

// TestThreeValuedWarning は27通りを通常の真偽論理の全解釈と比較します。
//
// 引数: t(*testing.T)はテスト文脈。返り値: ありません。
func TestThreeValuedWarning(t *testing.T) {
	for c := Unknown; c <= True; c++ {
		for m := Unknown; m <= True; m++ {
			for p := Unknown; p <= True; p++ {
				hasFalse, hasTrue := false, false
				for _, cb := range possibilities(c) {
					for _, mb := range possibilities(m) {
						for _, pb := range possibilities(p) {
							if mb && (cb || pb) {
								hasTrue = true
							} else {
								hasFalse = true
							}
						}
					}
				}
				want := Unknown
				if !hasFalse {
					want = True
				} else if !hasTrue {
					want = False
				}
				got, err := Warning(c, m, p)
				if err != nil || got != want {
					t.Fatalf("C/M/P=%d/%d/%d: got %d want %d", c, m, p, got, want)
				}
			}
		}
	}
	if _, err := Warning(Truth(3), True, False); err == nil {
		t.Fatal("不正三値を受理")
	}
}

// TestPartialReservedAndPhase は部分残玉・全予約・pre_fillでの数量判定を検証します。
//
// 引数: t(*testing.T)はテスト文脈。返り値: ありません。
func TestPartialReservedAndPhase(t *testing.T) {
	s := mustNew(t, fixture(G1, 1, 0))
	s, _ = advance(t, s, step(s, 1, 2801, 25))
	for _, row := range []struct {
		phase    Phase
		reserved int
		want     int
	}{{PreFill, 1, 0}, {AfterSource, 3, 0}, {AfterSource, 1, 2}} {
		in := step(s, 2, 2802, 5)
		in.Phase, in.Remaining, in.Reserved = row.phase, 3, row.reserved
		next, d := advance(t, s, in)
		if !d.FloorHit || d.EligibleExitQuantity != row.want || next.threshold != s.threshold || *next.floor != *s.floor || !next.active {
			t.Fatal("部分残玉又は段階で閾値・床・返済量が変化")
		}
	}
	in := step(s, 2, 2802, 5)
	in.Remaining, in.Reserved = 0, 0
	s, d := advance(t, s, in)
	if !s.finished || d.EligibleExitQuantity != 0 {
		t.Fatal("実残0の完了処理が違う")
	}
	if _, _, err := Advance(s, in); err == nil {
		t.Fatal("終玉を再更新")
	}
}

// TestMonotoneFloorAndReset は幅増加・失効・再送でも床が不利へ戻らないことを確認します。
//
// 引数: t(*testing.T)はテスト文脈。返り値: ありません。
func TestMonotoneFloorAndReset(t *testing.T) {
	s := mustNew(t, fixture(G2, 1, 0))
	in := step(s, 1, 2980, 150)
	in.Publication = publication(s, 1, 2980, 20, False, False)
	s, _ = advance(t, s, in)
	if *s.width != 40 || *s.floor != 110 {
		t.Fatal("初回の幅又は床が違う")
	}
	in = step(s, 2, 3160, 100)
	in.Publication = publication(s, 2, 3160, 1000, False, False)
	s, d := advance(t, s, in)
	if *s.width != 200 || *s.floor != 110 || !d.FloorHit {
		t.Fatal("幅拡大で床を緩和した")
	}
	last := clonePublication(s.latest)
	in = step(s, 3, 3161, 100)
	in.ResetReason = "人工欠足"
	s, _ = advance(t, s, in)
	if s.latest != nil || *s.floor != 110 || !s.active {
		t.Fatal("失効で既存保護を解除")
	}
	in = step(s, 4, 3162, 100)
	in.Publication = last
	s, _ = advance(t, s, in)
	if s.latest != nil || *s.floor != 110 {
		t.Fatal("同公表の再送で失効値が復活")
	}
	entry := fixture(G2, 1, 0)
	entry.ATR = nil
	s = mustNew(t, entry)
	in = step(s, 1, 2980, 150)
	in.Publication = publication(s, 1, 2980, 40, True, True)
	s, _ = advance(t, s, in)
	in = step(s, 2, 2981, 100)
	in.ResetReason = "人工不良足"
	s, _ = advance(t, s, in)
	if !s.narrowed || *s.width != 40 || *s.floor != 110 {
		t.Fatal("両不明で既存狭幅又は床を失った")
	}
}

// TestSmallATRLimit はG2最低幅が旧幅より広くなる設計限界を隠さず確認します。
//
// 引数: t(*testing.T)はテスト文脈。返り値: ありません。
func TestSmallATRLimit(t *testing.T) {
	got := map[Policy]Snapshot{}
	for _, policy := range []Policy{G1, G2} {
		entry := fixture(policy, 1, 0)
		entry.ATR.Value = 2
		s := mustNew(t, entry)
		in := step(s, 1, 2980, 40)
		in.Publication = publication(s, 1, 2980, 5, False, False)
		s, _ = advance(t, s, in)
		got[policy] = s.Snapshot()
	}
	if *got[G1].Width != 5 || *got[G1].Floor != 35 || *got[G2].Width != 15 || *got[G2].Floor != 25 {
		t.Fatal("極小ATRでの幅の違いが仕様と違う")
	}
}

// TestStructureAndMirror は価格構造と売買反転の同額性を同じ人工列で検証します。
//
// 引数: t(*testing.T)はテスト文脈。返り値: ありません。
func TestStructureAndMirror(t *testing.T) {
	for _, policy := range []Policy{G1, G2} {
		for _, slip := range []float64{0, 5} {
			var snapshots []Snapshot
			var decisions []Decision
			for _, side := range []int{1, -1} {
				entry := fixture(policy, side, slip)
				entry.ATR.Value = 500
				s := mustNew(t, entry)
				in := step(s, 1, 3520, 150)
				p := publication(s, 1, 3520, 500, True, True)
				kind := "low"
				if side < 0 {
					kind = "high"
				}
				p.Close = ptr(entry.Price + float64(side)*50)
				p.PriorPivot = &Pivot{entry.Scope, "人工pivot", kind, entry.Price + float64(side)*100, 2980, 3340, 3340}
				in.Publication = p
				s, d := advance(t, s, in)
				if policy == G2 && (!d.StructuralEligible || *s.floor != 95 || !s.narrowed || *s.width != 500) {
					t.Fatal("確定構造床又は狭幅が違う")
				}
				if policy == G1 && (d.StructuralEligible || s.narrowed) {
					t.Fatal("G1へ技術的縮小が混入")
				}
				in = step(s, 2, 3521, 90)
				in.Remaining, in.Reserved = 3, 1
				s, d = advance(t, s, in)
				snapshots, decisions = append(snapshots, s.Snapshot()), append(decisions, d)
			}
			a, b := snapshots[0], snapshots[1]
			if !reflect.DeepEqual(decisions[0], decisions[1]) || !reflect.DeepEqual(a.Floor, b.Floor) || !reflect.DeepEqual(a.Width, b.Width) ||
				a.ThresholdPoints != b.ThresholdPoints || a.MinimumFloor != b.MinimumFloor || a.Active != b.Active || a.Narrowed != b.Narrowed {
				t.Fatal("売買反転で損益単位・床・判定が非対称")
			}
		}
	}
	s := mustNew(t, fixture(G2, 1, 0))
	in := step(s, 1, 3520, 50)
	in.Publication = publication(s, 1, 3520, 500, True, True)
	in.Publication.PriorPivot = &Pivot{s.entry.Scope, "新規以前pivot", "low", 10100, 2800, 3160, 3160}
	s, d := advance(t, s, in)
	if !s.narrowed || d.StructuralEligible {
		t.Fatal("新規以前の中心足を構造床に使用")
	}
}

// TestRejectAndImmutability は不正・未来・改竄公表を拒否し、元状態の不変を確認します。
//
// 引数: t(*testing.T)はテスト文脈。返り値: ありません。
func TestRejectAndImmutability(t *testing.T) {
	for _, alter := range []func(*Entry){
		func(e *Entry) { e.Policy = "G0" }, func(e *Entry) { e.Side = 0 }, func(e *Entry) { e.Price = 10001 },
		func(e *Entry) { e.At = math.NaN() }, func(e *Entry) { e.InitialQuantity = 11 }, func(e *Entry) { e.SlipPoints = -1 },
		func(e *Entry) { e.SlipPoints = math.Inf(1) }, func(e *Entry) { e.ATR.Value = 0 }, func(e *Entry) { e.EntryV.Value = 4 },
		func(e *Entry) { e.EntryV.AvailableAt = e.At + 1 }, func(e *Entry) { e.ATR.SourceID = "" },
	} {
		e := fixture(G2, 1, 0)
		alter(&e)
		if _, err := NewState(e); err == nil {
			t.Fatal("不正新規を受理")
		}
	}
	s := mustNew(t, fixture(G2, 1, 0))
	in := step(s, 1, 2980, 150)
	in.Publication = publication(s, 1, 2980, 20, False, False)
	s, _ = advance(t, s, in)
	before := s.Snapshot()
	for name, alter := range map[string]func(*Input){
		"時計後退": func(i *Input) { i.At = 2979 }, "順序重複": func(i *Input) { i.Sequence = 1 },
		"不正段階": func(i *Input) { i.Phase = "未定義" }, "数量増加": func(i *Input) { i.Remaining = 8 },
		"予約超過": func(i *Input) { i.Reserved = 8 }, "負残玉": func(i *Input) { i.Remaining = -1 },
		"不正価格": func(i *Input) { i.Mark = ptr(math.NaN()) }, "格子外価格": func(i *Input) { i.Mark = ptr(10001.0) },
		"ATR変更":  func(i *Input) { i.ATR = &Evidence{200, 2800, "人工ATR"} },
		"未来ATR":  func(i *Input) { i.ATR = &Evidence{100, 5000, "人工ATR"} },
		"未来公表":   func(i *Input) { i.Publication = publication(s, 2, 3340, 20, True, True) },
		"不正V":    func(i *Input) { i.Publication = publication(s, 2, 3160, -1, True, True) },
		"改竄公表":   func(i *Input) { i.Publication = clonePublication(s.latest); i.Publication.V = ptr(25.0) },
		"公表後退":   func(i *Input) { i.Publication = publication(s, 2, 2800, 20, True, True) },
		"失効同時公表": func(i *Input) { i.ResetReason = "欠足"; i.Publication = publication(s, 2, 3160, 20, True, True) },
		"未来pivot": func(i *Input) {
			i.Publication = publication(s, 2, 3160, 20, True, True)
			i.Publication.PriorPivot = &Pivot{s.entry.Scope, "pivot", "low", 10000, 2800, 3160, 3160}
		},
		"方向違いpivot": func(i *Input) {
			i.Publication = publication(s, 2, 3160, 20, True, True)
			i.Publication.PriorPivot = &Pivot{s.entry.Scope, "pivot", "high", 10000, 2620, 2980, 2980}
		},
	} {
		t.Run(name, func(t *testing.T) {
			i := step(s, 2, 3160, 100)
			alter(&i)
			if _, _, err := Advance(s, i); err == nil {
				t.Fatal("不正入力を受理")
			}
			if !reflect.DeepEqual(before, s.Snapshot()) {
				t.Fatal("拒否で元状態を書き換え")
			}
		})
	}
	in = step(s, 2, 3160, 150)
	in.Publication = publication(s, 2, 3160, 40, True, True)
	next, _ := advance(t, s, in)
	*in.Publication.V = 500
	snapshot := next.Snapshot()
	*snapshot.Latest.V = 1000
	*snapshot.Floor = 0
	if *next.latest.V != 40 || *next.floor == 0 || !reflect.DeepEqual(before, s.Snapshot()) {
		t.Fatal("入力・出力・前状態のポインタを共有")
	}
}
