"""人工入力の純状態検査だけを実行し、コードと仕様の停止指紋を保存する。"""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import subprocess
from pathlib import Path


DIR = Path(__file__).resolve().parent
ROOT = DIR.parents[1]
CHECK = DIR / "検査"
OWNED = ["go.mod", "types.go", "state.go", "range.go", "state_test.go", "range_test.go", "README.md", "仕様.md", "検査と停止を記録する.py"]
DESIGNS = {
    "work/利益床と入口複合の次案/保護候補.md": "c05c701195fddeec62235479aedff15b4adcd31f3fce49c29a815cc032276be3",
    "work/利益床と入口複合の次案/案の条件.json": "281a83298d7c7fe10bd47d40d92b624e556f92ed0533bdedb7b3078ecbb0af20",
}
OLD_STOPS = {
    "work/見送り繰越の保護会計/停止.json": "ed5e63ab27e1b9aaf4aa2c18f63cc0cd48f881ec9416a89002e90ce78651c2b9",
    "work/静観長を分ける保護会計/停止.json": "1a17e2cf0e2229d8256a10c326acf0deba9d753b1317f405fa1b63ca0c700b3d",
}


def sha(path: Path) -> str:
    """
    機能: 一つのコード又は仕様の指紋を取得する。
    引数: path (Path): 読取対象。
    返り値: str: SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def fingerprints() -> dict[str, str]:
    """
    機能: 所有コード・仕様の指紋を固定リストで取得する。
    引数: なし。
    返り値: dict[str,str]: リポジトリ相対パスとSHA256。
    """
    return {str((DIR / name).relative_to(ROOT)).replace("\\", "/"): sha(DIR / name) for name in OWNED}


def old_code_checks() -> list[dict]:
    """
    機能: 旧107/108の停止台帳と所有コードだけを指紋確認する。
    引数: なし。市場の入力本文を参照しない。
    返り値: list[dict]: 旧停止とコード不変の確認。
    """
    checks = []
    for relative, expected in OLD_STOPS.items():
        path = ROOT / relative
        assert sha(path) == expected, relative
        old = json.loads(path.read_text(encoding="utf-8-sig"))
        count = 0
        for code, checksum in old["所有コードSHA256"].items():
            target = Path(code)
            if not target.is_absolute():
                target = ROOT / target
            assert sha(target) == checksum, str(target)
            count += 1
        checks.append({"path": relative, "sha256": expected, "所有コード確認数": count, "全一致": True})
    return checks


def run(command: list[str], name: str) -> dict:
    """
    機能: 純Go部品の検査を実行し、その出力と終了コードを記録する。
    引数: command (list[str]): コマンド。name (str): 出力名。
    返り値: dict: コマンド・終了コード・出力指紋。
    """
    process = subprocess.run(command, cwd=DIR, text=True, encoding="utf-8", errors="strict", capture_output=True)
    data = process.stdout + process.stderr
    path = CHECK / name
    path.write_text(data, encoding="utf-8", newline="\n")
    return {"command": command, "exit_code": process.returncode, "path": str(path.relative_to(ROOT)).replace("\\", "/"), "sha256": sha(path)}


def main() -> None:
    """
    機能: コード不変とtest/vet/buildを確認し、未接続の停止記録を作る。
    引数: なし。
    返り値: None。検査失敗時は例外で停止する。
    """
    CHECK.mkdir(parents=True, exist_ok=True)
    for relative, expected in DESIGNS.items():
        assert sha(ROOT / relative) == expected, relative
    old_before = old_code_checks()
    before = fingerprints()
    version = subprocess.check_output(["go", "version"], cwd=DIR, text=True, encoding="utf-8").strip()
    results = [run(["go", "test", "-json", "-count=1", "./..."], "go-test.jsonl")]
    if results[-1]["exit_code"] == 0:
        results.append(run(["go", "vet", "./..."], "go-vet.txt"))
        results.append(run(["go", "build", "./..."], "go-build.txt"))
    actions = [json.loads(line) for line in (CHECK / "go-test.jsonl").read_text(encoding="utf-8").splitlines() if line.startswith("{")]
    passed = [a["Test"] for a in actions if a.get("Action") == "pass" and a.get("Test")]
    failed = [a.get("Test", "package") for a in actions if a.get("Action") == "fail"]
    after = fingerprints()
    old_after = old_code_checks()
    success = len(results) == 3 and all(r["exit_code"] == 0 for r in results) and before == after and not failed and bool(passed)
    result = {
        "成功": success,
        "範囲": "G1/G2の未接続純状態部品と人工入力の検査のみ",
        "module": "github.com/masayoshi4649/SessionTradeExecuter/profitfloorproposal",
        "package": "profitfloorproposal",
        "作成UTC": dt.datetime.now(dt.timezone.utc).isoformat(),
        "Go版": version,
        "所有コードSHA256": before,
        "仕様": {"path": str((DIR / "仕様.md").relative_to(ROOT)).replace("\\", "/"), "sha256": sha(DIR / "仕様.md")},
        "設計元SHA256": DESIGNS,
        "検査": results,
        "人工テスト": {"親テスト成功": len([x for x in passed if "/" not in x]), "子テスト成功": len([x for x in passed if "/" in x]), "失敗": failed, "成功名": passed},
        "検査前後コード不変": before == after,
        "旧107と108の停止確認": old_after,
        "旧所有コード前後不変": old_before == old_after,
        "市場入力本文読取": 0,
        "金融Actor接続": False,
        "Source接続": False,
        "市場実行": False,
        "金融再実行": False,
        "正式試行採番": None,
        "未実施": ["Actor/Source/公表形成器との結合", "固定入力の由来結合", "注文・約定・費用配賦", "市場損益と参加率", "正式条件の固定", "未使用セッションでの確認"],
    }
    (DIR / "停止.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": success, "親テスト": result["人工テスト"]["親テスト成功"], "子テスト": result["人工テスト"]["子テスト成功"], "旧コード一致": [x["所有コード確認数"] for x in old_after]}, ensure_ascii=False))
    assert success


if __name__ == "__main__":
    main()
