# 一定利益と費用床の純状態案

一定利益での必須起動と、G1/G2の費用床・幅・構造床をGoの純状態で評価する部品。**未接続・未金融**であり、Actor・Source・市場入力・注文・約定の処理は実装していない。試行109の採番や条件固定も行っていない。

設計元は `work/利益床と入口複合の次案/保護候補.md` と `案の条件.json`。細部のAPI契約は [仕様](仕様.md)、コード・仕様・検査の指紋は生成される `停止.json` を参照する。旧107/108のコードは変更しない。

## API

- `NewState(Entry) (State,error)`：新規時の公開V、一定利益H、費用K、最低床Fを固定。
- `Advance(State,Input) (State,Decision,error)`：入力を変更せず次状態と純判定を返す。
- `State.Snapshot() Snapshot`：記録用の独立複写。内部状態へ書き戻せない。
- `MedianRange5(Scope,[]Bar,at) (*Evidence,error)`：外で確定済みの最大5足を受け、5連続既知の足内値幅中央値だけを算出。
- `Warning(C,M,P) (Truth,error)`：三値の `M AND (C OR P)`。
- `ActivationEligible(unitNetYen,Hpt) (bool,error)`：費用後単位円とHptの同値を含む境界。

`Truth` は0=不明、1=偽、2=真。JSONでもこの値を使う。Pは公開終値と評価前から公開済みのprior pivotから計算する。C/Mや足の形成・窓・EMA/MACDをこの部品が作ることはない。

買いではmarkに現在bid、売りでは現在askを外側が渡す。価格はminiの5pt格子、時刻は正のエポック秒、方向は買い+1/売り-1。追加滑りは費用として単位額へ控除し、渡す価格へ二重に足さない。

`Decision.EligibleExitQuantity` は条件上の返済可能枚数であり、注文を出した枚数ではない。pre_fillは必ず0。after_sourceでも、床未到達や全予約なら0。所有・注文予約・Source優先・同原行約定禁止・D0/D1・手数料の配賦・終了清算は外側Actorが監査する。

## 検査

Go 1.24.2、標準ライブラリのみ。外部依存、隣接リポジトリへのimport、ネットワーク取得は不要。

```powershell
Set-Location work/一定利益と費用床の純状態案
go test -count=1 ./...
go vet ./...
go build ./...
python -B -X utf8 検査と停止を記録する.py
```

記録用Pythonは自分のフォルダでtest/vet/buildを実行し、旧107/108停止台帳の所有コード指紋と設計元の指紋も記録する。市場のNative・原板・保存公表列は読まない。

検査は人工値だけを使う。費用とHの境界、V/H固定と不明時代替、ATR初回既知、売買鏡像、三値27通り、G1/G2の既知性の枝、部分残玉と全予約、床の非緩和、未来pivot・公表改竄拒否、入力/出力のポインタ非共有を確認する。中央値は大きい開始足が1本ある場合、欠足・跨場・不明・未来・価格破損を区別する。

検査成功は研究案の状態式を確認したもので、収益・参加率・実約定の確認ではない。入口技術の不明を成立へ補完するAPIも持たない。
