// Package profitfloorproposal は未接続の一定利益・費用床案を純状態で表します。
package profitfloorproposal

// Policy は新しい保護案の識別子です。旧会計のP1等とは別名です。
type Policy string

const (
	G1 Policy = "G1"
	G2 Policy = "G2"
)

// Truth は不明・偽・真を0・1・2で表し、不明を偽へ補完しません。
type Truth uint8

const (
	Unknown Truth = iota
	False
	True
)

// Phase は評価だけの段階と、外側で返済要求が可能な段階を分けます。
type Phase string

const (
	PreFill     Phase = "pre_fill"
	AfterSource Phase = "after_source"
)

// Scope は建玉・根拠が属するセッションと限月です。
type Scope struct {
	Session  string  `json:"session"`
	Contract string  `json:"contract"`
	Start    float64 `json:"start"`
}

// Evidence は外部で既に公表された正の価格差尺度です。窓の形成は行いません。
type Evidence struct {
	Value       float64 `json:"value"`
	AvailableAt float64 `json:"available_at"`
	SourceID    string  `json:"source_id"`
}

// Entry は実新規時の固定条件です。EntryV不明は保護用の代替額だけを選びます。
type Entry struct {
	Scope           Scope     `json:"scope"`
	Policy          Policy    `json:"policy"`
	Side            int       `json:"side"`
	Price           float64   `json:"price"`
	At              float64   `json:"at"`
	InitialQuantity int       `json:"initial_quantity"`
	SlipPoints      float64   `json:"slip_points"`
	EntryV          *Evidence `json:"entry_v"`
	ATR             *Evidence `json:"atr"`
}

// Pivot は評価対象公表より前に確認・公開された不利側の高安です。
type Pivot struct {
	Scope       Scope   `json:"scope"`
	ID          string  `json:"id"`
	Kind        string  `json:"kind"`
	Price       float64 `json:"price"`
	CenterEnd   float64 `json:"center_end"`
	ConfirmEnd  float64 `json:"confirm_end"`
	PublishedAt float64 `json:"published_at"`
}

// Publication は窓形成後に受け取る確定3分公表です。PはClose/PriorPivotから純計算します。
type Publication struct {
	Scope       Scope    `json:"scope"`
	ID          string   `json:"id"`
	Ordinal     uint64   `json:"ordinal"`
	End         float64  `json:"end"`
	AvailableAt float64  `json:"available_at"`
	V           *float64 `json:"v"`
	C           Truth    `json:"c"`
	M           Truth    `json:"m"`
	Close       *float64 `json:"close"`
	PriorPivot  *Pivot   `json:"prior_pivot"`
}

// Input は現在原行の評価に必要な値です。注文・約定・Sourceの形成を行いません。
type Input struct {
	At          float64      `json:"at"`
	Sequence    uint64       `json:"sequence"`
	Phase       Phase        `json:"phase"`
	Mark        *float64     `json:"mark"`
	Remaining   int          `json:"remaining"`
	Reserved    int          `json:"reserved"`
	ATR         *Evidence    `json:"atr"`
	Publication *Publication `json:"publication"`
	ResetReason string       `json:"reset_reason"`
}

// Snapshot は外部記録用の独立複写です。この値から内部Stateを書き換えられません。
type Snapshot struct {
	Entry           Entry        `json:"entry"`
	CostPoints      float64      `json:"cost_points"`
	ThresholdPoints float64      `json:"threshold_points"`
	FeeFloor        float64      `json:"fee_floor"`
	MinimumFloor    float64      `json:"minimum_floor"`
	EntryVFallback  bool         `json:"entry_v_fallback"`
	ATR             *Evidence    `json:"atr"`
	Active          bool         `json:"active"`
	ActivatedAt     *float64     `json:"activated_at"`
	Narrowed        bool         `json:"narrowed"`
	NarrowedAt      *float64     `json:"narrowed_at"`
	Peak            *float64     `json:"peak_points"`
	Floor           *float64     `json:"floor_points"`
	Width           *float64     `json:"width_points"`
	Latest          *Publication `json:"latest_publication"`
	Remaining       int          `json:"remaining"`
	Reserved        int          `json:"reserved"`
	At              float64      `json:"at"`
	Sequence        uint64       `json:"sequence"`
	Finished        bool         `json:"finished"`
}

// Decision は純評価の結果です。EligibleExitQuantityは実注文ではありません。
type Decision struct {
	Warning              Truth    `json:"warning"`
	P                    Truth    `json:"p"`
	GainPoints           *float64 `json:"gain_points"`
	UnitNetYen           *float64 `json:"unit_net_yen"`
	ActivatedNow         bool     `json:"activated_now"`
	NarrowedNow          bool     `json:"narrowed_now"`
	WidthSource          string   `json:"width_source"`
	StructuralFloor      *float64 `json:"structural_floor"`
	StructuralEligible   bool     `json:"structural_eligible"`
	FloorHit             bool     `json:"floor_hit"`
	FreeQuantity         int      `json:"free_quantity"`
	EligibleExitQuantity int      `json:"eligible_exit_quantity"`
}

// State は不変に受け渡す内部状態です。公開関数の返り値を次の入力に使います。
type State struct {
	initialized                   bool
	entry                         Entry
	cost, threshold, fee, minimum float64
	atr                           *Evidence
	active, narrowed, finished    bool
	activatedAt, narrowedAt       *float64
	peak, floor, width            *float64
	latest, lastPublication       *Publication
	remaining, reserved           int
	at                            float64
	sequence                      uint64
}
