package profitfloorproposal

import (
	"fmt"
	"math"
	"reflect"
	"testing"
)

// rangeFixture は開始足の大値幅を含む5本の人工確定足を返します。
//
// 引数: なし。返り値: Scope/[]Barは窓を形成済みという契約の人工値です。
func rangeFixture() (Scope, []Bar) {
	scope := fixture(G2, 1, 0).Scope
	bars := []Bar{}
	for i, width := range []float64{1000, 20, 40, 30, 10} {
		start := scope.Start + float64(i)*180
		bars = append(bars, Bar{scope, fmt.Sprintf("人工足%d", i), start, start + 180, start + 180, true, 10000 + width, 10000})
	}
	return scope, bars
}

// TestMedianRange5 は単一大値幅への耐性・不明・欠足・未来を別々に確認します。
//
// 引数: t(*testing.T)はテスト文脈。返り値: ありません。
func TestMedianRange5(t *testing.T) {
	scope, bars := rangeFixture()
	before := append([]Bar{}, bars...)
	v, err := MedianRange5(scope, bars, 1900)
	if err != nil || v == nil || v.Value != 30 || v.AvailableAt != 1900 || !reflect.DeepEqual(before, bars) {
		t.Fatal("中央値・公開時刻又は入力不変が違う")
	}
	for _, n := range []int{0, 1, 4} {
		if got, err := MedianRange5(scope, bars[:n], 1900); err != nil || got != nil {
			t.Fatal("5本未満を既知へ補完")
		}
	}
	for _, alter := range []func([]Bar){
		func(b []Bar) { b[2].Known, b[2].High, b[2].Low = false, 0, 0 },
		func(b []Bar) { b[2].Scope.Contract = "別限月" },
		func(b []Bar) {
			for i := 3; i < 5; i++ {
				b[i].Start += 180
				b[i].End += 180
				b[i].AvailableAt += 180
			}
		},
	} {
		copy := append([]Bar{}, bars...)
		alter(copy)
		if got, err := MedianRange5(scope, copy, 2080); err != nil || got != nil {
			t.Fatal("不良・跨場・欠足を既知へ補完")
		}
	}
	for _, alter := range []func([]Bar){
		func(b []Bar) { b[0].AvailableAt = 2000 },
		func(b []Bar) { b[0].High = math.NaN() },
		func(b []Bar) { b[0].Low = b[0].High + 5 },
		func(b []Bar) { b[0].High = 10001 },
		func(b []Bar) { b[1].ID = b[0].ID },
		func(b []Bar) { b[0].End++ },
	} {
		copy := append([]Bar{}, bars...)
		alter(copy)
		if _, err := MedianRange5(scope, copy, 1900); err == nil {
			t.Fatal("未来又は破損した足を受理")
		}
	}
	for i := range bars {
		bars[i].High = bars[i].Low
	}
	v, err = MedianRange5(scope, bars, 1900)
	if err != nil || v.Value != 5 {
		t.Fatal("値幅0の最低1呼値が違う")
	}
}

// TestWidthBranches はG1/G2の既知性と狭幅の各枝を式の例で確認します。
//
// 引数: t(*testing.T)はテスト文脈。返り値: ありません。
func TestWidthBranches(t *testing.T) {
	for _, row := range []struct {
		name   string
		policy Policy
		a, v   *float64
		narrow bool
		want   *float64
	}{
		{"G1両既知", G1, ptr(40.25), ptr(20.0), false, ptr(85.0)},
		{"G1不明ATR", G1, nil, ptr(20.0), false, nil},
		{"G2両既知通常", G2, ptr(40.25), ptr(20.0), false, ptr(40.0)},
		{"G2Vのみ通常", G2, nil, ptr(20.0), false, ptr(40.0)},
		{"G2ATRのみ通常", G2, ptr(40.25), nil, false, ptr(85.0)},
		{"G2両不明通常", G2, nil, nil, false, nil},
		{"G2両既知狭幅", G2, ptr(40.25), ptr(20.0), true, ptr(20.0)},
		{"G2Vのみ狭幅", G2, nil, ptr(20.0), true, ptr(20.0)},
		{"G2ATRのみ狭幅", G2, ptr(40.25), nil, true, ptr(45.0)},
		{"G2両不明狭幅", G2, nil, nil, true, nil},
	} {
		t.Run(row.name, func(t *testing.T) {
			entry := fixture(row.policy, 1, 0)
			entry.ATR = nil
			if row.a != nil {
				entry.ATR = &Evidence{*row.a, entry.At, "人工ATR"}
			}
			s := mustNew(t, entry)
			in := step(s, 1, 2980, 150)
			c, m := False, False
			if row.narrow {
				c, m = True, True
			}
			in.Publication = publication(s, 1, 2980, 20, c, m)
			in.Publication.V = copyPtr(row.v)
			s, _ = advance(t, s, in)
			if !reflect.DeepEqual(s.width, row.want) || s.narrowed != (row.policy == G2 && row.narrow) {
				t.Fatalf("幅の枝が違う: %+v", s.Snapshot())
			}
		})
	}
}

// TestPivotWarningAlternative はC偽でもPとMが真なら幅を狭めることを確認します。
//
// 引数: t(*testing.T)はテスト文脈。返り値: ありません。
func TestPivotWarningAlternative(t *testing.T) {
	for _, row := range []struct {
		name     string
		close    *float64
		pivot    bool
		warning  Truth
		narrowed bool
	}{
		{"構造否定あり", ptr(9990.0), true, True, true},
		{"構造否定なし", ptr(10020.0), true, False, false},
		{"終値不明", nil, true, Unknown, false},
		{"構造不明", ptr(9990.0), false, Unknown, false},
	} {
		t.Run(row.name, func(t *testing.T) {
			s := mustNew(t, fixture(G2, 1, 0))
			in := step(s, 1, 3160, 25)
			in.Publication = publication(s, 1, 3160, 40, False, True)
			in.Publication.Close = copyPtr(row.close)
			if row.pivot {
				in.Publication.PriorPivot = &Pivot{s.entry.Scope, "人工古pivot", "low", 10010, 2620, 2980, 2980}
			}
			s, d := advance(t, s, in)
			if d.Warning != row.warning || s.narrowed != row.narrowed || d.StructuralEligible {
				t.Fatal("P代替の警戒又は新規以前の構造床除外が違う")
			}
		})
	}
}
