package miniprofitthreeproposal

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strings"
	"testing"

	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	old108 "github.com/masayoshi4649/SessionTradeExecuter/miniquietlength108"
	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloorproposal"
)

type compositeHarness struct {
	b                  *ActualBook
	old                *old108.ActualBook
	src                *source
	s                  Session
	start              float64
	method             string
	side               int
	index              int64
	atr                float64
	publicationOrdinal uint64
	compared           int
}

// newCompositeHarness は非市場のSource通知器具と新口座を作ります。
//
// 引数: t(*testing.T)、entry/保護政策、side/cost/delay/night/compareは人工条件。
// 返り値: *compositeHarnessは旧108との同体比較も可能な人工経路です。
func newCompositeHarness(t *testing.T, entry CompositeEntryPolicy, policy CompositeProtection, side int, cost float64, delay int, night, compare bool) *compositeHarness {
	t.Helper()
	s, start, method := lengthSession108(night)
	cfg := CompositeConfig{EntryPolicy: entry, Protection: policy, SlipPts: cost, DelaySeconds: delay, USOpen: s.USOpen}
	b, err := NewCompositeBook(s, cfg, "手製限月")
	if err != nil {
		t.Fatal(err)
	}
	h := &compositeHarness{b: b, src: newSource(), s: s, start: start, method: method, side: side, atr: 20}
	if compare {
		c := old108.ActorConfig{Policy: "P0", SlipPts: cost, DelaySeconds: delay, EntryTiming: old108.TimingQuietDeferred, USOpen: s.USOpen, ActivationPolicy: old108.ActivationLD10}
		h.old, err = old108.NewWidthBookWithQuiet(s, c, "W0", "手製限月", 1200)
		if err != nil {
			t.Fatal(err)
		}
	}
	return h
}

// compositeEqual は型名の違いに依存せず全JSONを無除外で比較します。
//
// 引数: t(*testing.T)、a/b(any)、label(string)は比較対象。返り値: ありません。
func compositeEqual(t *testing.T, a, b any, label string) {
	t.Helper()
	x, err := json.Marshal(a)
	if err != nil {
		t.Fatal(err)
	}
	y, err := json.Marshal(b)
	if err != nil {
		t.Fatal(err)
	}
	if !bytes.Equal(x, y) {
		t.Fatalf("%sの全JSONが不一致\n%s\n%s", label, x, y)
	}
}

// compare は旧108の実APIと四JSONを各時点で照合します。
//
// 引数: t(*testing.T)は検査。返り値: ありません。
func (h *compositeHarness) compare(t *testing.T) {
	t.Helper()
	if h.old == nil {
		return
	}
	compositeEqual(t, h.b.Snapshot(), h.old.Snapshot(), "ActualResult")
	compositeEqual(t, h.b.WidthAudit(), h.old.WidthAudit(), "WidthAudit")
	compositeEqual(t, h.b.EarlyAudit(), h.old.EarlyAudit(), "EarlyAudit")
	compositeEqual(t, h.b.ClockAudit(), h.old.ClockAudit(), "ClockAudit")
	h.compared++
}

// feed は同じ人工SourceDeltaを一度だけ形成して新旧へ配送します。
//
// 引数: t(*testing.T)、at/move(float64)、bad(bool)、news(...native.Signal)は人工原行。
// 返り値: ありません。市場や戦略を読まない手製入力です。
func (h *compositeHarness) feed(t *testing.T, at, move float64, bad bool, news ...native.Signal) {
	t.Helper()
	o := observation(at, move, h.side, h.index, bad)
	o.ATR, o.E01.ATR = h.atr, h.atr
	if h.atr == 0 {
		o.E01.ATRAvailable, o.E01.ATRNominal = 0, 0
	}
	line := h.index + 20
	h.index++
	for i := range news {
		if news[i].Action == "new" {
			var e sourceEvidence
			_ = json.Unmarshal(news[i].Evidence, &e)
			e.Method = "NK225_" + h.method
			news[i].Evidence, _ = json.Marshal(e)
		}
	}
	batch := h.src.step(stamp(o, line), news)
	batch.Method = h.method
	if err := h.b.OnNativeStep(o, line, []NativeBatch{batch}); err != nil {
		t.Fatal(err)
	}
	if h.old != nil {
		if err := h.old.OnNativeStep(o, line, []old108.NativeBatch{{Method: batch.Method, Delta: batch.Delta}}); err != nil {
			t.Fatal(err)
		}
	}
	h.compare(t)
}

// grid はE0又は一括E1の人工5分枠を配送します。
//
// 引数: t(*testing.T)、at(float64)、gate(EntryBatchGate)は検査と枠/callback。返り値: ありません。
func (h *compositeHarness) grid(t *testing.T, at float64, gate EntryBatchGate) {
	t.Helper()
	id := ""
	if h.b.composite.Config.EntryPolicy == EntryE1 {
		id = fmt.Sprintf("人工入口/%.0f", at)
	}
	if err := h.b.OnCompositeEntryGrid(at, id, gate); err != nil {
		t.Fatal(err)
	}
	if h.old != nil {
		if err := h.old.OnEntryGrid(at); err != nil {
			t.Fatal(err)
		}
	}
	h.compare(t)
}

// pub は形成済みという契約の人工3分V/C/Mを配送します。
//
// 引数: t(*testing.T)、end(float64)、v(*float64)、c/m(guard.Truth)、pivot(*guard.Pivot)は公表値。
// 返り値: ありません。G0対照へも同じ公表監査を配送します。
func (h *compositeHarness) pub(t *testing.T, end float64, v *float64, c, m guard.Truth, pivot *guard.Pivot) {
	t.Helper()
	h.publicationOrdinal++
	scope := guard.Scope{Session: h.s.ID, Contract: "手製限月", Start: h.s.Start}
	close := 1005.0
	p := guard.Publication{Scope: scope, ID: WidthPublicationID(h.s.ID, "手製限月", end), Ordinal: h.publicationOrdinal, End: end, AvailableAt: end, V: v, C: c, M: m, Close: &close}
	o := ProtectionObservation{At: end, Buy: p, Sell: p, FrameSHA: strings.Repeat("a", 64), ResultSHA: strings.Repeat("b", 64)}
	if m == guard.True {
		if h.side > 0 {
			o.Sell.M = guard.False
		} else {
			o.Buy.M = guard.False
		}
	}
	if pivot != nil {
		if h.side > 0 {
			o.Buy.PriorPivot = pivot
		} else {
			o.Sell.PriorPivot = pivot
		}
	}
	if err := h.b.OnProtectionObservation(o); err != nil {
		t.Fatal(err)
	}
	if h.old != nil {
		for _, item := range []struct {
			side int
			p    guard.Publication
		}{{1, o.Buy}, {-1, o.Sell}} {
			p := item.p
			ct, mt, pt := widthTruth(p.C), widthTruth(p.M), widthTruth(protectionP(p, item.side))
			old := old108.WidthObservation{Session: h.s.ID, Contract: "手製限月", Side: item.side, PublicationID: p.ID, Ordinal: int(p.Ordinal), End: p.End, AvailableAt: p.AvailableAt,
				C: old108.WidthTruth{Known: ct.Known, Passed: ct.Passed}, M: old108.WidthTruth{Known: mt.Known, Passed: mt.Passed}, P: old108.WidthTruth{Known: pt.Known, Passed: pt.Passed}, FrameSHA: o.FrameSHA, ResultSHA: o.ResultSHA}
			if err := h.old.OnWidthObservation(end, old); err != nil {
				t.Fatal(err)
			}
		}
	}
	h.compare(t)
}

// forceAndFinish は人工Sourceの残量を実後続行で閉じ、架空約定なしの完了を確認します。
//
// 引数: t(*testing.T)、move(float64)は検査と最終人工価格。返り値: ActualResultは終了実口座です。
func (h *compositeHarness) forceAndFinish(t *testing.T, move float64) ActualResult {
	t.Helper()
	batch := h.src.force(h.s.ForceClose)
	batch.Method = h.method
	if err := h.b.OnNativeForce(h.s.ForceClose, []NativeBatch{batch}); err != nil {
		t.Fatal(err)
	}
	if h.old != nil {
		if err := h.old.OnNativeForce(h.s.ForceClose, []old108.NativeBatch{{Method: batch.Method, Delta: batch.Delta}}); err != nil {
			t.Fatal(err)
		}
	}
	h.compare(t)
	h.feed(t, h.s.ForceClose+1, move, false)
	r, err := h.b.Finish()
	if err != nil {
		t.Fatal(err)
	}
	if h.old != nil {
		if _, err := h.old.Finish(); err != nil {
			t.Fatal(err)
		}
	}
	h.compare(t)
	if !r.Complete || r.Totals.OpenBuy+r.Totals.OpenSell+r.Totals.PendingBuy+r.Totals.PendingSell != 0 {
		t.Fatal("残玉/予約が0でない")
	}
	return r
}

// TestCompositeG0Exact は非ゼロ実取引の全時点四JSONを旧108と同体比較します。
//
// 引数: t(*testing.T)はDay/US・買売・C0/C5・D0/D1人工検査。返り値: ありません。
func TestCompositeG0Exact(t *testing.T) {
	series, points := 0, 0
	for _, night := range []bool{false, true} {
		for _, side := range []int{1, -1} {
			for _, cost := range []float64{0, 5} {
				for _, delay := range []int{0, 1} {
					h := newCompositeHarness(t, EntryE0, ProtectG0, side, cost, delay, night, true)
					h.feed(t, h.start+601, 0, false, birth("G0-A", side, 6), birth("G0-B", side, 6))
					h.feed(t, h.start+602, 0, false)
					h.grid(t, h.start+900, nil)
					v := 80.0
					h.pub(t, h.start+1080, &v, guard.False, guard.False, nil)
					h.feed(t, h.start+1199, 0, false)
					h.grid(t, h.start+1200, nil)
					h.feed(t, h.start+1201, 0, false)
					h.feed(t, h.start+1202, 70, false)
					h.feed(t, h.start+1203, 30, false, closeSignal("G0-部分", "玉-G0-A", side, 2))
					if len(h.b.result.Fills) != 2 {
						t.Fatal("返済要求の同原行で約定した")
					}
					h.feed(t, h.start+1204, 25, false)
					h.feed(t, h.s.ForceClose-601, 25, false, birth("G0-取消", side, 4))
					h.feed(t, h.s.ForceClose-600, 25, false)
					h.grid(t, h.s.ForceClose-600, nil)
					r := h.forceAndFinish(t, 25)
					if r.Totals.EntryQuantity != 10 || len(r.Positions) != 2 || r.Totals.NetYen == 0 || r.Metrics.CapClippedEntries == 0 || r.Metrics.CancelledEntries == 0 || r.Metrics.ProtectionExitFills == 0 {
						t.Fatal("同体比較が必要な非ゼロ経路を通っていない")
					}
					series++
					points += h.compared
				}
			}
		}
	}
	t.Logf("非ゼロ系列%d、四JSON全時点%d", series, points)
}

// TestCompositeProfitReservations は新G1/G2の費用・遅延・Source部分優先と実予約を確認します。
//
// 引数: t(*testing.T)は買売・全C/Dの人工。返り値: ありません。
func TestCompositeProfitReservations(t *testing.T) {
	for _, policy := range []CompositeProtection{ProtectG1, ProtectG2} {
		for _, side := range []int{1, -1} {
			for _, cost := range []float64{0, 5} {
				for _, delay := range []int{0, 1} {
					h := newCompositeHarness(t, EntryE0, policy, side, cost, delay, false, false)
					h.feed(t, h.start+601, 0, false, birth("利益A", side, 7))
					h.feed(t, h.start+602, 0, false)
					v := 80.0
					h.pub(t, h.start+1080, &v, guard.False, guard.False, nil)
					h.feed(t, h.start+1199, 0, false)
					h.grid(t, h.start+1200, nil)
					h.feed(t, h.start+1201, 0, false)
					h.feed(t, h.start+1202, 70, false)
					h.feed(t, h.start+1203, 15, false, closeSignal("利益部分", "玉-利益A", side, 2))
					p := h.b.result.Positions[0]
					if !p.ProtectionActive || p.Reserved != 7 || len(h.b.result.Fills) != 1 {
						t.Fatal("部分Source優先又は同原行fill禁止が違う")
					}
					a := h.b.CompositeAudit().Positions[0]
					if len(a.Requests) != 1 || a.Requests[0].Requested != 5 || a.Requests[0].ReservedBefore != 2 || a.Requests[0].ReservedAfter != 7 || a.Requests[0].Step.Decision.EligibleExitQuantity != 5 {
						t.Fatal("純判定からfree5枚の実予約が違う")
					}
					wantH := 20.0
					if cost == 5 {
						wantH = 25
					}
					if a.Initial.ThresholdPoints != wantH || a.Last.ThresholdPoints != wantH || a.Initial.Entry.EntryV.Value != 80 {
						t.Fatal("V/H固定又は残枚数単位が違う")
					}
					h.feed(t, h.start+1204, 15, false)
					h.grid(t, h.start+1500, nil)
					if h.b.result.Metrics.EntryRequests != 1 {
						t.Fatal("利益返済後に同じ出生へ再参加")
					}
					h.feed(t, h.s.ForceClose-601, 15, false, birth("利益後取消", side, 4))
					h.feed(t, h.s.ForceClose-600, 15, false)
					h.grid(t, h.s.ForceClose-600, nil)
					r := h.forceAndFinish(t, 15)
					if r.Totals.EntryQuantity != 7 || r.Totals.CloseQuantity != 7 || r.Metrics.ProtectionExitFills != 1 || !h.b.CompositeAudit().Positions[0].Last.Finished {
						t.Fatal("保護返済又は終了状態が違う")
					}
					if r.Totals.FeeYen != 7*77 || r.Totals.SlipYen != 14*cost*100 {
						t.Fatal("費用・追加滑りの一度計上が違う")
					}
					if r.Metrics.CancelledEntries != 1 {
						t.Fatal("Source終了前の実新規予約を取消しない")
					}
				}
			}
		}
	}
}

// TestCompositeUnknownAndFixedH は新規時不明・後判明・固定Hと構造否定の狭幅を確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestCompositeUnknownAndFixedH(t *testing.T) {
	for _, policy := range []CompositeProtection{ProtectG1, ProtectG2} {
		h := newCompositeHarness(t, EntryE0, policy, 1, 0, 0, false, false)
		h.atr = 0
		h.feed(t, h.start+601, 0, false, birth("不明", 1, 3))
		h.feed(t, h.start+602, 0, false)
		h.feed(t, h.start+1199, 0, false)
		h.grid(t, h.start+1200, nil)
		h.feed(t, h.start+1201, 0, false)
		h.feed(t, h.start+1202, 40, false)
		a := h.b.CompositeAudit().Positions[0]
		if !a.Last.Active || !a.Initial.EntryVFallback || a.Last.Width != nil || *a.Last.Floor != 10 {
			t.Fatal("未知で最低保護が延期された")
		}
		h.atr = 20
		h.feed(t, h.start+1203, 40, false)
		a = h.b.CompositeAudit().Positions[0]
		if a.Last.ThresholdPoints != 20 || a.Last.ATR.Value != 20 || !a.Last.EntryVFallback {
			t.Fatal("後判明でH又は不明記録が変更")
		}
		h.forceAndFinish(t, 40)
	}
	h := newCompositeHarness(t, EntryE0, ProtectG2, 1, 0, 0, false, false)
	h.atr = 500
	h.feed(t, h.start+601, 0, false, birth("固定H", 1, 2))
	h.feed(t, h.start+602, 0, false)
	v := 400.0
	h.pub(t, h.start+1080, &v, guard.False, guard.False, nil)
	h.feed(t, h.start+1199, 0, false)
	h.grid(t, h.start+1200, nil)
	h.feed(t, h.start+1201, 0, false)
	h.feed(t, h.start+1202, 60, false)
	v = 20
	h.pub(t, h.start+1260, &v, guard.False, guard.False, nil)
	h.feed(t, h.start+1261, 120, false)
	a := h.b.CompositeAudit().Positions[0]
	if a.Initial.ThresholdPoints != 100 || !a.Last.Active || a.Last.ThresholdPoints != 100 || *a.Last.Floor != 70 {
		t.Fatal("新規V/H固定が違う")
	}
	v = 500
	pivot := &guard.Pivot{Scope: guard.Scope{Session: h.s.ID, Contract: "手製限月", Start: h.s.Start}, ID: "公開済み安値", Kind: "low", Price: 1100,
		CenterEnd: h.start + 1440, ConfirmEnd: h.start + 1800, PublishedAt: h.start + 1800}
	h.pub(t, h.start+1980, &v, guard.False, guard.True, pivot)
	h.feed(t, h.start+1981, 110, false)
	a = h.b.CompositeAudit().Positions[0]
	if !a.Last.Narrowed || *a.Last.Floor != 85 || !a.LastStep.Decision.StructuralEligible || a.FirstNarrow == nil {
		t.Fatal("C偽でもM/Pの複合で構造床を使わない")
	}
	h.feed(t, h.start+1982, 90, false)
	h.feed(t, h.start+1983, 90, false)
	h.forceAndFinish(t, 90)
}
