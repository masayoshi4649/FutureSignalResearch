# 一定利益と三時間軸の保護会計

固定108のActorを別moduleへ派生し、停止済み `profitfloorproposal` のG1/G2を実所有・予約へ結合した人工検査用Actor。**人工会計検査済み、市場未実行**。市場本文・新Native・原板を読まず、正式試行の採番や実70場の損益再計算は行っていない。

module/package：`github.com/masayoshi4649/SessionTradeExecuter/miniprofitthreeproposal` / `miniprofitthreeproposal`。Go 1.24.2。元コードと停止純部品は変更しない。由来は `由来.json`、結合契約は [仕様](仕様.md)、コード・仕様・検査結果の指紋は `停止.json`。

## 新constructorと識別

```go
NewCompositeBook(session Session, cfg CompositeConfig, contract string) (*ActualBook, error)
```

CompositeConfigは `EntryPolicy=EntryE0/EntryE1`、`Protection=ProtectG0/ProtectG1/ProtectG2`、`SlipPts=0/5`、`DelaySeconds=0/1`、`USOpen`。入口定数の値は `entry_E0` / `entry_E1`、保護は `G0/G1/G2`。静観は1200秒、B5QD・P0・他の任意退出政策なしに限定する。

- `CompositeKey()`：入口と保護を区別した外key。例 `entry_E1_G2_C5_D1`。
- `Snapshot()`：実約定・所有・費用のActualResult。
- `WidthAudit()/EarlyAudit()/ClockAudit()`：既存の監査。G0/E0は旧108 W0/quiet1200と全JSON同体。
- `CompositeAudit()`：新規時のV/H、初回起動、狭幅、床到達、公表出典、純判定→実予約、一括入口を別JSONで記録。

G0/E0の内Config/Key/既存4JSONは変更しない。G1/G2の内Config.ActivationPolicyは実名 `G1/G2`。E1の内GatePolicyは `ENTRY_E1`。旧constructorが新政策を黙って受け付ける形にはしない。

## 入口の一括境界

`OnCompositeEntryGrid(at,snapshotID,EntryBatchGate)` を使う。E0は空snapshot/nilで旧Gridへ直行する。E1は同枠の金融適格候補だけを受付前に集め、一度だけcallbackへ渡す。

EntryBatchInputは `At, SnapshotID, Candidates []EntryCandidate, AvailableBuy, AvailableSell`。返り値EntryBatchOutputは同じSnapshotIDと `[]EntryBatchDecision{Candidate全値echo,Decision GateDecision}`。Decision.Policyは `ENTRY_E1`、Known/Allowed/Role/ReasonとSnapshotIDを結合検査する。候補OrdinalはActor内で一意。

適格集合は枠開始時のSource取得・未返済・未予約、P期限、静観、正常気配、片側余力等を反映する。全候補を判定後、数量配賦だけ旧順のminで行う。同側6+6を査定しても実受理は6+4となり得る。満杯方向を先に除くので、無効方向との誤競合を作らない。

入口の5/15/30分snapshotと純判定は外側の別部品が所有する。空候補・静観枠でもcallbackを1回呼び、構造の公開更新を止めない。両方向成立はその純判定で両方不成立へ変換する。Actorも両方向Allowed=trueの未解決返答を拒否する。E1から旧個別callbackへ迂回できない。

## 保護の公表境界

`OnProtectionObservation(ProtectionObservation)` は、確定3分のV/C/M/prior pivotを両方向まとめて受け取る。入口の5/15/30分とは別。

ProtectionObservationは `At, Buy/Sell guard.Publication, FrameSHA, ResultSHA`。guardは停止済み `profitfloorproposal`。PublicationはScope、ID、Ordinal、End、AvailableAt、V、C/M、Close、PriorPivot。三値は不明0/偽1/真2。Vは足内価格レンジの中央値ptであり数量ではない。窓形成はCoreが担当し、`guard.MedianRange5` を補助にできる。

旧 `PublicReceiver` はOnWidthObservationへ配送するのでG1/G2には使わない。G0だけ旧配送を維持するか、全G0を新OnProtectionObservationへ明示変換する。新APIのG0は同じ旧WidthObservationを両方向へ配送する。二重配送を前提に数を増やさない。

`ResetProtectionObservation(at,reason)` は観測を失効させ、固定H/ATR・起動・床を保持する。新規約定より後の値でHを作らず、同IDの内容/SHA改変、未来pivot、配送より古いRawによる評価を拒否する。

## 検査と範囲

```powershell
Set-Location work/一定利益と三時間軸の保護会計
python -B -X utf8 検査と停止を記録する.py
```

人工Sourceの公開型とscalarを使い、G0旧108の16非ゼロ系列・256時点の4JSONを無除外で比較する。G1/G2は費用/遅延/売買、Source部分/全予約優先、同原行約定禁止、一出生一回、Source終了による未取得新規取消、片側cap、残玉0、V/H固定、未知/後判明、構造床、出典と失効を確認する。E1は全同枠査定、容量配賦、満杯除外、既知競合、必要未知、改竄拒否を確認する。

旧APIの人工検査も継承する。そのうち旧PublicReceiver検査は既存の人工停止JSON `work/収束可変幅の公開配送案/人工_停止版/Go公開12の配送.json` を読む。市場のJSONやCSVではない。

Actorへ結合したという事実は収益性の確認ではない。市場入力との出典結合、入口純部品とのCore bridge、保存会計/CSV、固定条件と未使用データの確認は外側で完了させる必要がある。
