package miniprofitthreeproposal

import old "github.com/masayoshi4649/SessionTradeExecuter/minivariableguard"

// PublicReceiver は停止公開配送8c42の旧named型を明示対応するだけです。
type PublicReceiver struct{ Book *ActualBook }

// ConvertPublicObservation は旧公開型の全fieldを新named型へ写します。
//
// 引数: o(old.WidthObservation)は停止8c42が返す型。
// 返り値: WidthObservationはbool pointerも独立した全値対応です。数値/時計は変更しません。
func ConvertPublicObservation(o old.WidthObservation) WidthObservation {
	return WidthObservation{Session: o.Session, Contract: o.Contract, Side: o.Side, PublicationID: o.PublicationID, Ordinal: o.Ordinal, End: o.End, AvailableAt: o.AvailableAt, C: WidthTruth{Known: o.C.Known, Passed: valueCopy(o.C.Passed)}, M: WidthTruth{Known: o.M.Known, Passed: valueCopy(o.M.Passed)}, P: WidthTruth{Known: o.P.Known, Passed: valueCopy(o.P.Passed)}, FrameSHA: o.FrameSHA, ResultSHA: o.ResultSHA}
}

// OnWidthObservation は停止配送から受ける全fieldを新APIへ渡します。
//
// 引数: at(float64)、o(old.WidthObservation)は配送時計と公表。
// 返り値: errorは新Bookが拒否した出典/時計です。採否を付け替えません。
func (r PublicReceiver) OnWidthObservation(at float64, o old.WidthObservation) error {
	return r.Book.OnWidthObservation(at, ConvertPublicObservation(o))
}

// ResetWidthObservation は同じresetを新Bookへ渡します。
//
// 引数: at(float64)、reason(string)は停止配送の制御出典。
// 返り値: errorは新Bookが拒否した時計/理由です。
func (r PublicReceiver) ResetWidthObservation(at float64, reason string) error {
	return r.Book.ResetWidthObservation(at, reason)
}
