package miniprofitthreeproposal

import (
	"fmt"
	"math"
	"reflect"
)

// EntryBatchInput は同枠の金融適格候補を受付前の値copyとして一括提示します。
type EntryBatchInput struct {
	At            float64          `json:"at"`
	SnapshotID    string           `json:"snapshot_id"`
	Candidates    []EntryCandidate `json:"candidates"`
	AvailableBuy  int              `json:"available_buy"`
	AvailableSell int              `json:"available_sell"`
}

// EntryBatchDecision は元候補の全値echoと採否を結び、方向/数量の書換えを拒否します。
type EntryBatchDecision struct {
	Candidate EntryCandidate `json:"candidate"`
	Decision  GateDecision   `json:"decision"`
}

// EntryBatchOutput は全候補を一回で査定した結果です。
type EntryBatchOutput struct {
	SnapshotID string               `json:"snapshot_id"`
	Decisions  []EntryBatchDecision `json:"decisions"`
}

// EntryBatchGate は入口5/15/30分の外部snapshotを一度だけ評価する境界です。
//
// 引数: EntryBatchInputは同枠の金融適格候補。返り値: EntryBatchOutput/errorは全採否又は破損です。
type EntryBatchGate func(EntryBatchInput) (EntryBatchOutput, error)

// EntryBatchAudit は金融適格集合と一括判定を保存します。後の容量配賦は旧EntryOpportunityに残ります。
type EntryBatchAudit struct {
	Input  EntryBatchInput  `json:"input"`
	Output EntryBatchOutput `json:"output"`
}

// collectCompositeCandidates は旧受付と同じ適格性を枠開始時の余力で読取評価します。
//
// 引数: at(float64)、snapshotID(string)は枠と公開snapshot識別。返り値: EntryBatchInput/errorは集合又は出典破損です。
func (b *ActualBook) collectCompositeCandidates(at float64, snapshotID string) (EntryBatchInput, error) {
	input := EntryBatchInput{At: at, SnapshotID: snapshotID, Candidates: []EntryCandidate{}, AvailableBuy: b.available(1), AvailableSell: b.available(-1)}
	quiet, _, _ := b.gridQuiet(at)
	quoteKnown := b.haveQuote && normalActual(b.last)
	for _, p := range b.result.EntryOpportunities {
		if p.Consumed || p.AssignedAt > at {
			continue
		}
		s := b.sourceOrders[sourceKey(p.Source.Method, p.Source.SignalID)]
		if s == nil || s.signal.Action != "new" || s.identity != p.Source || s.signal.Side != p.Side {
			return input, fmt.Errorf("一括候補のSource出生が不整合")
		}
		var hold *sourceHold
		if s.hold != "" {
			hold = b.sourceHolds[sourceKey(p.Source.Method, s.hold)]
			if hold == nil || hold.orderKey != sourceKey(p.Source.Method, p.Source.SignalID) || hold.side != p.Side || hold.quantity < 0 || hold.reserved < 0 || hold.reserved > hold.quantity {
				return input, fmt.Errorf("一括候補のSource所有が不整合")
			}
		}
		if p.AssignedAt != at || at >= b.entryDeadline(p.Source.Method) || quiet || s.state == "cancelled" || s.state == "pending" {
			continue
		}
		if s.state != "filled" || hold == nil {
			return input, fmt.Errorf("一括候補の取得済みSourceにHoldがありません")
		}
		available := input.AvailableBuy
		if p.Side < 0 {
			available = input.AvailableSell
		}
		if hold.quantity == 0 || hold.reserved > 0 || !quoteKnown || available == 0 {
			continue
		}
		quantity := min(s.signal.Quantity, hold.quantity, available)
		if quantity <= 0 {
			return input, fmt.Errorf("一括候補の数量が非正")
		}
		input.Candidates = append(input.Candidates, EntryCandidate{Ordinal: p.Ordinal, At: at, Side: p.Side, Source: s.identity, Quote: b.last, Available: available, Quantity: quantity})
	}
	return input, nil
}

// OnCompositeEntryGrid は全適格候補を一括判定後、旧順の数量配賦と永久消費へ渡します。
//
// 引数: at(float64)、snapshotID(string)、gate(EntryBatchGate)は5分枠と外部snapshotの単発callback。
// 返り値: errorは金融適格性・出典・同枠競合・echo破損です。E0は空識別/nilで旧Gridへ直行します。
func (b *ActualBook) OnCompositeEntryGrid(at float64, snapshotID string, gate EntryBatchGate) error {
	if err := b.ready(); err != nil {
		return err
	}
	if b.composite == nil {
		return b.stop(fmt.Errorf("新入口のconstructorが必要です"))
	}
	if b.composite.Config.EntryPolicy == EntryE0 {
		if snapshotID != "" || gate != nil {
			return b.stop(fmt.Errorf("E0は空snapshotとnil一括callbackです"))
		}
		return b.OnEntryGrid(at)
	}
	if snapshotID == "" || gate == nil || !finiteActual(at) || at <= 0 || math.Mod(at, 300) != 0 || at < b.result.Session.Start || at >= b.result.Session.End || at < b.lastEventAt || b.haveGrid && at <= b.lastGridAt {
		return b.stop(fmt.Errorf("E1の一括callback・snapshot又は枠時計が不正です"))
	}
	if b.haveQuote && (!finiteActual(b.last.Time, b.last.Last, b.last.Bid, b.last.Ask) || b.last.Time > at || b.last.Index < 0 || b.last.SourceLine <= 0) {
		return b.stop(fmt.Errorf("一括枠の最後の原行出典が不正です"))
	}
	input, err := b.collectCompositeCandidates(at, snapshotID)
	if err != nil {
		return b.stop(err)
	}
	before := b.Snapshot()
	b.heldCallbackActive = true
	output, err := func() (EntryBatchOutput, error) {
		defer func() { b.heldCallbackActive = false }()
		return gate(valueCopy(input))
	}()
	if err != nil {
		return b.stop(fmt.Errorf("入口一括callback:%w", err))
	}
	if !sameCompositeJSON(before, b.Snapshot()) {
		return b.stop(fmt.Errorf("入口一括callbackで金融状態が変更されました"))
	}
	if output.SnapshotID != snapshotID || len(output.Decisions) != len(input.Candidates) {
		return b.stop(fmt.Errorf("入口一括のsnapshot又は候補数が不一致"))
	}
	expected := map[int]EntryCandidate{}
	for _, candidate := range input.Candidates {
		expected[candidate.Ordinal] = candidate
	}
	cache := map[int]EntryBatchDecision{}
	buyAllowed, sellAllowed := false, false
	for _, item := range output.Decisions {
		candidate, exists := expected[item.Candidate.Ordinal]
		if !exists || !reflect.DeepEqual(item.Candidate, candidate) {
			return b.stop(fmt.Errorf("入口一括の候補echoが不一致"))
		}
		if _, duplicate := cache[candidate.Ordinal]; duplicate {
			return b.stop(fmt.Errorf("入口一括の候補が重複"))
		}
		d := item.Decision
		if d.Policy != CompositeGatePolicy || d.SnapshotID != snapshotID || d.Allowed && !d.Known || d.Role == "" || d.Reason == "" {
			return b.stop(fmt.Errorf("入口一括の政策/既知採否/理由が不正"))
		}
		if d.Allowed {
			if candidate.Side > 0 {
				buyAllowed = true
			} else {
				sellAllowed = true
			}
		}
		cache[candidate.Ordinal] = valueCopy(item)
	}
	if buyAllowed && sellAllowed {
		return b.stop(fmt.Errorf("E1の同枠両方向成立は純入口で競合判定が必要です"))
	}
	wrapped := func(candidate EntryCandidate) (GateDecision, error) {
		item, exists := cache[candidate.Ordinal]
		if !exists {
			return GateDecision{}, fmt.Errorf("事前適格集合にない候補を受付")
		}
		echo := candidate
		echo.Quantity, echo.Available = item.Candidate.Quantity, item.Candidate.Available
		if !reflect.DeepEqual(echo, item.Candidate) || candidate.Quantity > item.Candidate.Quantity || candidate.Available > item.Candidate.Available {
			return GateDecision{}, fmt.Errorf("事前判定後にSource/方向/出典/量が変化")
		}
		return valueCopy(item.Decision), nil
	}
	b.composite.batchActive = true
	err = func() error {
		defer func() { b.composite.batchActive = false }()
		return b.OnEntryGridWithGate(at, wrapped)
	}()
	if err != nil {
		return err
	}
	b.composite.Batches = append(b.composite.Batches, valueCopy(EntryBatchAudit{input, output}))
	return nil
}

// sameCompositeJSON は名前付き型を含む旧金融JSONの完全同体を比較します。
//
// 引数: a/b(ActualResult)は同じ金融の前後。返り値: boolは全field同値なら真です。
func sameCompositeJSON(a, b ActualResult) bool { return reflect.DeepEqual(a, b) }
