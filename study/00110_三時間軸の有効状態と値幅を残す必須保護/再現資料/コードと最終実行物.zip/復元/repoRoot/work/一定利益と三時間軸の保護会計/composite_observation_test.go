package miniprofitthreeproposal

import (
	"math"
	"strings"
	"testing"

	guard "github.com/masayoshi4649/SessionTradeExecuter/profitfloorproposal"
)

// compositeObservation は出典SHA付きの非市場3分公表を作ります。
//
// 引数: h(*compositeHarness)、end(float64)は人工口座と公表時計。返り値: ProtectionObservationは形成済みの人工値です。
func compositeObservation(h *compositeHarness, end float64) ProtectionObservation {
	v, close := 80.0, 1005.0
	p := guard.Publication{Scope: guard.Scope{Session: h.s.ID, Contract: "手製限月", Start: h.s.Start}, ID: WidthPublicationID(h.s.ID, "手製限月", end), Ordinal: 1, End: end, AvailableAt: end, V: &v, C: guard.False, M: guard.False, Close: &close}
	return ProtectionObservation{At: end, Buy: p, Sell: p, FrameSHA: strings.Repeat("a", 64), ResultSHA: strings.Repeat("b", 64)}
}

// TestCompositeObservationBoundary は出典・両方向・未来pivotの不正を保有前にも拒否します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestCompositeObservationBoundary(t *testing.T) {
	for name, alter := range map[string]func(*ProtectionObservation){
		"SHA":  func(o *ProtectionObservation) { o.FrameSHA = "出典なし" },
		"共通ID": func(o *ProtectionObservation) { o.Sell.ID = "別ID" },
		"共通C":  func(o *ProtectionObservation) { o.Sell.C = guard.True },
		"両M真":  func(o *ProtectionObservation) { o.Buy.M, o.Sell.M = guard.True, guard.True },
		"未来値":  func(o *ProtectionObservation) { o.At-- },
		"別場":   func(o *ProtectionObservation) { o.Buy.Scope.Session = "別場" },
		"非有限V": func(o *ProtectionObservation) { v := math.NaN(); o.Buy.V, o.Sell.V = &v, &v },
		"未来pivot": func(o *ProtectionObservation) {
			o.Buy.PriorPivot = &guard.Pivot{Scope: o.Buy.Scope, ID: "未来", Kind: "low", Price: 1000, CenterEnd: o.Buy.End - 360, ConfirmEnd: o.Buy.End, PublishedAt: o.Buy.End}
		},
	} {
		t.Run(name, func(t *testing.T) {
			h := newCompositeHarness(t, EntryE0, ProtectG1, 1, 0, 0, false, false)
			o := compositeObservation(h, h.start+1080)
			alter(&o)
			if err := h.b.OnProtectionObservation(o); err == nil {
				t.Fatal("不正な明示公表を受理")
			}
		})
	}
	h := newCompositeHarness(t, EntryE0, ProtectG2, 1, 0, 0, false, false)
	o := compositeObservation(h, h.start+1080)
	if err := h.b.OnProtectionObservation(o); err != nil {
		t.Fatal(err)
	}
	*o.Buy.V = 500
	if *h.b.composite.Latest[1].V != 80 {
		t.Fatal("公表をポインタ共有")
	}
	o = compositeObservation(h, h.start+1080)
	o.ResultSHA = strings.Repeat("c", 64)
	if err := h.b.OnProtectionObservation(o); err == nil {
		t.Fatal("同IDの出典SHA変更を受理")
	}
}

// TestCompositeResetAndCausality は失効・再送・未来配送時計が保護へ逆流しないことを確認します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestCompositeResetAndCausality(t *testing.T) {
	h := newCompositeHarness(t, EntryE0, ProtectG2, 1, 0, 0, false, false)
	h.feed(t, h.start+601, 0, false, birth("失効", 1, 2))
	h.feed(t, h.start+602, 0, false)
	o := compositeObservation(h, h.start+1080)
	if err := h.b.OnProtectionObservation(o); err != nil {
		t.Fatal(err)
	}
	h.feed(t, h.start+1199, 0, false)
	h.grid(t, h.start+1200, nil)
	h.feed(t, h.start+1201, 0, false)
	h.feed(t, h.start+1202, 100, false)
	before := h.b.CompositeAudit().Positions[0]
	if before.InitialSource == nil || before.Activation.Source == nil || before.InitialSource.FrameSHA != strings.Repeat("a", 64) {
		t.Fatal("新規V/H又は起動の出典がない")
	}
	if err := h.b.ResetProtectionObservation(h.start+1260, "人工欠足"); err != nil {
		t.Fatal(err)
	}
	h.feed(t, h.start+1261, 70, false)
	o.At = h.start + 1262
	if err := h.b.OnProtectionObservation(o); err != nil {
		t.Fatal(err)
	}
	h.feed(t, h.start+1263, 70, false)
	a := h.b.CompositeAudit().Positions[0]
	if h.b.composite.Latest[1] != nil || a.Last.Latest != nil || a.LastStep.Source != nil || *a.Last.Floor < *before.Last.Floor || a.Last.ThresholdPoints != before.Initial.ThresholdPoints {
		t.Fatal("失効で床を緩和又は再送で観測を復活")
	}
	h.forceAndFinish(t, 70)
	h = newCompositeHarness(t, EntryE0, ProtectG1, 1, 0, 0, false, false)
	h.feed(t, h.start+601, 0, false, birth("未来配送", 1, 2))
	h.feed(t, h.start+602, 0, false)
	h.feed(t, h.start+1199, 0, false)
	h.grid(t, h.start+1200, nil)
	h.feed(t, h.start+1201, 0, false)
	if err := h.b.ResetProtectionObservation(h.start+1260, "未来側の配送時計"); err != nil {
		t.Fatal(err)
	}
	raw := observation(h.start+1202, 0, 1, h.index, false)
	batch := h.src.step(stamp(raw, h.index+20), nil)
	if err := h.b.OnNativeStep(raw, h.index+20, []NativeBatch{batch}); err == nil {
		t.Fatal("配送より古いRawで保護状態を更新")
	}
}

// TestCompositeUnknownEntry は技術不明を成立へ補完せず、明示した全不明を保存します。
//
// 引数: t(*testing.T)は人工検査。返り値: ありません。
func TestCompositeUnknownEntry(t *testing.T) {
	h := newCompositeHarness(t, EntryE1, ProtectG1, 1, 0, 0, false, false)
	h.feed(t, h.start+601, 0, false, birth("技術不明", 1, 2))
	h.feed(t, h.start+602, 0, false)
	h.feed(t, h.start+1199, 0, false)
	h.grid(t, h.start+1200, func(in EntryBatchInput) (EntryBatchOutput, error) {
		out := compositeDecisions(in, false)
		for i := range out.Decisions {
			out.Decisions[i].Decision.Known = false
			out.Decisions[i].Decision.Role = "不明"
			out.Decisions[i].Decision.Reason = "人工snapshotの必要値不明"
		}
		return out, nil
	})
	trace := h.b.result.GridTraces[0]
	if trace.Action != "判定不能" || trace.UnknownCount != 1 || trace.AcceptedCount != 0 || h.b.result.Metrics.EntryRequests != 0 {
		t.Fatal("入口不明を成立へ補完")
	}
	h.forceAndFinish(t, 0)
}
