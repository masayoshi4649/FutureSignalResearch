"""新Actorの人工検査と旧コード不変を記録する。市場本文を開かない。"""

import datetime as dt
import hashlib
import json
import re
import subprocess
from pathlib import Path


DIR = Path(__file__).resolve().parent
ROOT = DIR.parents[1]
CHECK = DIR / "検査"
SOURCES = {
    "work/見送り繰越の保護会計/停止.json": "ed5e63ab27e1b9aaf4aa2c18f63cc0cd48f881ec9416a89002e90ce78651c2b9",
    "work/静観長を分ける保護会計/停止.json": "1a17e2cf0e2229d8256a10c326acf0deba9d753b1317f405fa1b63ca0c700b3d",
    "work/一定利益と費用床の純状態案/停止.json": "1d58cebc88a08011632a4ac1c036dcc71ae8d1bf8dc85938b3f2b344ad85a24c",
}


def sha(path: Path) -> str:
    """
    機能: コード・仕様・人工fixtureの指紋を取得する。
    引数: path (Path): 対象ファイル。
    返り値: str: SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def relative(path: Path) -> str:
    """
    機能: リポジトリ相対パスに揃える。
    引数: path (Path): 対象パス。
    返り値: str: スラッシュ区切り相対パス。
    """
    return str(path.relative_to(ROOT)).replace("\\", "/")


def owned() -> dict:
    """
    機能: 新Actor所有コードと仕様の指紋を列挙する。
    引数: なし。
    返り値: dict: コード相対パスとSHA256。
    """
    files = sorted(DIR.glob("*.go"))
    files += [DIR / name for name in ("go.mod", "go.sum", "README.md", "仕様.md", "由来.json", "機能差分.patch", "検査と停止を記録する.py")]
    return {relative(path): sha(path) for path in files}


def verify_sources() -> list:
    """
    機能: 旧107/108と停止純部品の所有コードが不変であることを確認する。
    引数: なし。市場Native/原板/公表本文を読まない。
    返り値: list: 固定停止と一致件数。
    """
    records = []
    for name, checksum in SOURCES.items():
        path = ROOT / name
        assert sha(path) == checksum, name
        data = json.loads(path.read_text(encoding="utf-8-sig"))
        for code, expected in data["所有コードSHA256"].items():
            target = Path(code)
            if not target.is_absolute():
                target = ROOT / target
            assert sha(target) == expected, code
        records.append({"path": name, "sha256": checksum, "所有コード一致": len(data["所有コードSHA256"]), "全不変": True})
    return records


def run(command: list, name: str) -> dict:
    """
    機能: 新ActorのGo人工検査を実行して出力を保存する。
    引数: command (list): コマンド。name (str): 記録名。
    返り値: dict: 終了コード・出力指紋。
    """
    process = subprocess.run(command, cwd=DIR, capture_output=True, text=True, encoding="utf-8", errors="strict")
    path = CHECK / name
    path.write_text(process.stdout + process.stderr, encoding="utf-8", newline="\n")
    return {"command": command, "exit_code": process.returncode, "path": relative(path), "sha256": sha(path)}


def main() -> None:
    """
    機能: test/vet/build・不変確認を行い、人工Actorの停止記録を保存する。
    引数: なし。
    返り値: None。失敗時は例外で停止する。
    """
    CHECK.mkdir(parents=True, exist_ok=True)
    sources_before = verify_sources()
    before = owned()
    results = [run(["go", "test", "-json", "-count=1", "./..."], "go-test.jsonl")]
    if results[0]["exit_code"] == 0:
        results.append(run(["go", "vet", "./..."], "go-vet.txt"))
        results.append(run(["go", "build", "./..."], "go-build.txt"))
    text = (CHECK / "go-test.jsonl").read_text(encoding="utf-8")
    events = [json.loads(line) for line in text.splitlines() if line.startswith("{")]
    passed = [e["Test"] for e in events if e.get("Action") == "pass" and e.get("Test")]
    failed = [e.get("Test", "package") for e in events if e.get("Action") == "fail"]
    output = "".join(e.get("Output", "") for e in events)
    proof = re.search(r"非ゼロ系列(\d+)、四JSON全時点(\d+)", output)
    assert proof is not None
    series, points = map(int, proof.groups())
    assert series == 16 and points == 256
    sources_after = verify_sources()
    after = owned()
    fixture = ROOT / "work/収束可変幅の公開配送案/人工_停止版/Go公開12の配送.json"
    success = len(results) == 3 and all(r["exit_code"] == 0 for r in results) and before == after and not failed and bool(passed)
    record = {
        "成功": success,
        "範囲": "一定利益G1/G2と同枠一括E1を結合した別Actor。人工会計のみ、市場未実行",
        "module": "github.com/masayoshi4649/SessionTradeExecuter/miniprofitthreeproposal",
        "package": "miniprofitthreeproposal",
        "UTC": dt.datetime.now(dt.timezone.utc).isoformat(),
        "Go版": subprocess.check_output(["go", "version"], cwd=DIR, text=True, encoding="utf-8").strip(),
        "所有コードSHA256": before,
        "仕様": {"path": relative(DIR / "仕様.md"), "sha256": sha(DIR / "仕様.md")},
        "元停止と純部品": sources_after,
        "元コード前後不変": sources_before == sources_after,
        "検査前後コード不変": before == after,
        "検査": results,
        "人工テスト": {"親成功": len([x for x in passed if "/" not in x]), "子成功": len([x for x in passed if "/" in x]), "失敗": failed, "成功名": passed},
        "G0旧108同体": {"系列": series, "非ゼロ": True, "時点": points, "各時点JSON": ["ActualResult", "WidthAudit", "EarlyAudit", "ClockAudit"], "除外field": [], "quiet秒": 1200},
        "継承した人工fixture": {"path": relative(fixture), "sha256": sha(fixture)},
        "接続": {"金融Actor": True, "Source公開型": "人工通知だけ", "Source戦略実行": False, "入口純部品": "一括callback境界のみ。Core bridgeは別担当", "保護純状態": True},
        "市場入力本文読取": 0,
        "市場実行": False,
        "実70損益実行": False,
        "正式試行採番": None,
        "未実施": ["Coreでの入力指紋と3分保護公表/5分15分30分入口の結合", "実市場の金融損益", "保存会計とCSV", "固定後の未使用データ確認"],
    }
    (DIR / "停止.json").write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": success, "親": record["人工テスト"]["親成功"], "子": record["人工テスト"]["子成功"], "G0系列": series, "G0時点": points, "所有コード": len(before)}, ensure_ascii=False))
    assert success


if __name__ == "__main__":
    main()
