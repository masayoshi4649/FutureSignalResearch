package threeentry

import (
	"fmt"
	"math"
	"reflect"
	"strings"
	"testing"

	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

const epoch = 100000.0

// value は人工の既知指標を作ります。
//
// 引数: v(float64)は人工値です。
// 返り値: frame.Valueは既知値です。
func value(v float64) frame.Value { return frame.Value{Known: true, Value: v} }

// artificialPivot は連続5足の証拠を持つ確認済み5分pivotを作ります。
//
// 引数: kind(string)、price(float64)は高安の種類と人工価格です。
// 返り値: frame.Pivotは3900秒足で確認、3960秒公表の事前線です。
func artificialPivot(kind string, price float64) frame.Pivot {
	refs := [5]frame.BarRef{}
	for i := range refs {
		end := epoch + 2700 + float64(i)*300
		refs[i] = frame.BarRef{ID: fmt.Sprintf("人工pivot_%d", i), Start: end - 300, End: end, PublishedAt: end + 60}
	}
	return frame.Pivot{Known: true, Kind: kind, Price: price, CenterID: refs[2].ID, CenterStart: refs[2].Start, CenterEnd: refs[2].End, ConfirmID: refs[4].ID, ConfirmEnd: refs[4].End, PublishedAt: refs[4].PublishedAt, Left: [2]frame.BarRef{refs[0], refs[1]}, Right: [2]frame.BarRef{refs[3], refs[4]}}
}

// artificialSnapshot は価格・指標が未使用市場に依存しない公開値を作ります。
//
// 引数: end(float64)、reversal(bool)は場内の5分終了と上位逆向きの指定です。
// 返り値: frame.Snapshotは各足終了60秒後に利用する値copyです。
func artificialSnapshot(end float64, reversal bool) frame.Snapshot {
	s := frame.Snapshot{Session: frame.Session{ID: "人工場", Contract: "人工限月", Start: epoch, End: epoch + 86400, EOF: epoch + 86000}, AsOf: epoch + end + 60, ReplayObservedAt: epoch + end + 60, HasObserved: true, RecordOrdinal: uint64(end + 60)}
	for i, width := range widths {
		last := math.Floor(end/float64(width)) * float64(width)
		step := last / float64(width)
		tc := frame.Technical{HistoryBars: 100 + uint64(step), EMA8: value(102 + step*.2), EMA21: value(100 + step*.1), PreviousEMA8: value(102 + (step-1)*.2), PreviousEMA21: value(100 + (step-1)*.1), ATR: value(10), PreviousATR: value(10), TR: value(10), RSI: value(52 + step*.2), PreviousRSI: value(52 + (step-1)*.2), Histogram: value(step * .1), PreviousHistogram: value((step - 1) * .1)}
		if reversal && width != 300 {
			tc.EMA8 = value(98 - step*.2)
			tc.EMA21 = value(100 - step*.1)
			tc.PreviousEMA8 = value(98 - (step-1)*.2)
			tc.PreviousEMA21 = value(100 - (step-1)*.1)
			tc.RSI = value(42 + step*.2)
			tc.PreviousRSI = value(42 + (step-1)*.2)
			tc.Histogram = value(-5 + step*.1)
			tc.PreviousHistogram = value(-5 + (step-1)*.1)
		}
		tc.Gap = value(tc.EMA8.Value - tc.EMA21.Value)
		tc.EMA8Delta = value(tc.EMA8.Value - tc.PreviousEMA8.Value)
		tc.EMA21Delta = value(tc.EMA21.Value - tc.PreviousEMA21.Value)
		tc.GapATR = value(tc.Gap.Value / 10)
		tc.EMA8DeltaATR = value(tc.EMA8Delta.Value / 10)
		tc.EMA21DeltaATR = value(tc.EMA21Delta.Value / 10)
		ohlc := frame.OHLC{Open: 105, High: 110, Low: 90, Close: 100}
		if width == 300 {
			ohlc = frame.OHLC{Open: 99, High: 100, Low: 98, Close: 99}
		}
		f := frame.Frame{ID: fmt.Sprintf("人工_%d_%g", width, last), SessionID: s.Session.ID, Contract: s.Session.Contract, WidthSeconds: width, Start: epoch + last - float64(width), End: epoch + last, NominalAvailable: epoch + last + 60, AvailableAt: epoch + last + 60, ObservedAt: epoch + last + 60, DeliveryAt: epoch + last + 60, RecordOrdinal: uint64(last), PublicationOrdinal: uint64(last / float64(width)), PriceKnown: true, VolumeKnown: true, OHLC: ohlc, Volume: 100, Technical: tc}
		if width == 300 && last > 3900 {
			f.PriorHigh = artificialPivot("high", 100)
			f.PriorLow = artificialPivot("low", 80)
		}
		if width == 300 && last == 3900 {
			f.NewHigh = artificialPivot("high", 100)
			f.NewLow = artificialPivot("low", 80)
		}
		s.Scales[i] = frame.ScaleSnapshot{WidthSeconds: width, HasCurrent: true, Fresh: true, Current: f}
	}
	return s
}

// transform は人工鏡像と量未知を、全履歴へ一貫して適用します。
//
// 引数: s(frame.Snapshot)、mirror/unknownVolume(bool)は元値と変換指定です。
// 返り値: frame.Snapshotは原入力へaliasしない値です。
func transform(s frame.Snapshot, mirror, unknownVolume bool) frame.Snapshot {
	for i := range s.Scales {
		f := &s.Scales[i].Current
		if unknownVolume {
			f.VolumeKnown = false
		}
		if !mirror {
			continue
		}
		o := f.OHLC
		f.OHLC = frame.OHLC{Open: 300 - o.Open, High: 300 - o.Low, Low: 300 - o.High, Close: 300 - o.Close}
		tc := &f.Technical
		for _, v := range []*frame.Value{&tc.EMA8, &tc.EMA21, &tc.PreviousEMA8, &tc.PreviousEMA21} {
			if v.Known {
				v.Value = 300 - v.Value
			}
		}
		for _, v := range []*frame.Value{&tc.Gap, &tc.GapATR, &tc.EMA8Delta, &tc.EMA21Delta, &tc.EMA8DeltaATR, &tc.EMA21DeltaATR, &tc.Histogram, &tc.PreviousHistogram, &tc.CrossSessionJump} {
			if v.Known {
				v.Value = -v.Value
			}
		}
		for _, v := range []*frame.Value{&tc.RSI, &tc.PreviousRSI} {
			if v.Known {
				v.Value = 100 - v.Value
			}
		}
		flip := func(p frame.Pivot) frame.Pivot {
			if p.Known {
				p.Price = 300 - p.Price
				if p.Kind == "high" {
					p.Kind = "low"
				} else {
					p.Kind = "high"
				}
			}
			return p
		}
		f.PriorHigh, f.PriorLow = flip(f.PriorLow), flip(f.PriorHigh)
		f.NewHigh, f.NewLow = flip(f.NewLow), flip(f.NewHigh)
	}
	return s
}

// feed は候補なしの判断枠で純状態を進めます。
//
// 引数: t(*testing.T)、state(EntryState)、snapshot(frame.Snapshot)は人工検査の状態です。
// 返り値: EntryStateは空候補でも公表を保持した次状態です。
func feed(t *testing.T, state EntryState, snapshot frame.Snapshot) EntryState {
	t.Helper()
	next, out, err := AssessBatch(state, snapshot, nil, EntryE1)
	if err != nil {
		t.Fatal(err)
	}
	if len(out.Decisions) != 0 {
		t.Fatal("空候補を生成した")
	}
	return next
}

// warm は前15分risk区間と連続5分の人工履歴を保持します。
//
// 引数: t(*testing.T)、reversal/mirror/unknownVolume(bool)は人工経路です。
// 返り値: EntryStateは4500秒足まで候補なしで進めた状態です。
func warm(t *testing.T, reversal, mirror, unknownVolume bool) EntryState {
	t.Helper()
	state := NewEntryState()
	for _, end := range []float64{3600, 3900, 4200, 4500} {
		state = feed(t, state, transform(artificialSnapshot(end, reversal), mirror, unknownVolume))
	}
	return state
}

// buyCandidate は同じsnapshot時計の金融適格値copyを作ります。
//
// 引数: s(frame.Snapshot)、price(float64)は判断値と新規側気配です。
// 返り値: Candidateは数量3の人工買いです。
func buyCandidate(s frame.Snapshot, price float64) Candidate {
	return Candidate{ID: "出生1", Side: 1, At: s.AsOf, EntryQuote: price, Quantity: 3}
}

// trendReady は事前線100を終値101で突破する人工足を作ります。
//
// 引数: mirror/unknownVolume(bool)は鏡像と量の状態です。
// 返り値: frame.Snapshot/Candidateは4800秒足の順行確認です。
func trendReady(mirror, unknownVolume bool) (frame.Snapshot, Candidate) {
	s := artificialSnapshot(4800, false)
	s.Scales[0].Current.OHLC = frame.OHLC{Open: 99, High: 102, Low: 98, Close: 101}
	s = transform(s, mirror, unknownVolume)
	c := buyCandidate(s, 101)
	if mirror {
		c.Side = -1
		c.EntryQuote = 199
	}
	return s, c
}

// TestTrendCombinationAndSymmetry は三軸、構造、勢い、位置の組合せと鏡像を確認します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: なし。市場・ファイルは読みません。
func TestTrendCombinationAndSymmetry(t *testing.T) {
	for _, mirror := range []bool{false, true} {
		t.Run(fmt.Sprint(mirror), func(t *testing.T) {
			state := warm(t, false, mirror, false)
			s, c := trendReady(mirror, false)
			oldState, oldSnapshot := state, s
			next, a, err := AssessEntry(state, s, c, EntryE1)
			if err != nil {
				t.Fatal(err)
			}
			if !a.Known || !a.Allowed || a.Role != Trend || !a.Trend.Passed || a.Background[1].PriorLowKnown {
				t.Fatalf("複合順行/15pivot非必須:%+v", a)
			}
			if a.Candidate != c || state != oldState || s != oldSnapshot {
				t.Fatal("入力を変更した")
			}
			if next.View().Trend[map[bool]int{false: 0, true: 1}[mirror]].Event != "突破" {
				t.Fatal("突破eventなし")
			}
		})
	}
}

// TestANDRejectsOneMissingRole は平均の整列だけでは入らないことを確認します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: なし。
func TestANDRejectsOneMissingRole(t *testing.T) {
	tests := []struct {
		name   string
		change func(*frame.Snapshot, *Candidate)
	}{
		{"遅い平均だけ逆傾き", func(s *frame.Snapshot, _ *Candidate) {
			s.Scales[0].Current.Technical.PreviousEMA21 = value(s.Scales[0].Current.Technical.EMA21.Value + 1)
		}},
		{"5分MACDが逆", func(s *frame.Snapshot, _ *Candidate) { s.Scales[0].Current.Technical.Histogram = value(-2) }},
		{"5分RSIが逆変化", func(s *frame.Snapshot, _ *Candidate) {
			s.Scales[0].Current.Technical.RSI = value(s.Scales[0].Current.Technical.PreviousRSI.Value - 1)
		}},
		{"取得が1ATR超", func(_ *frame.Snapshot, c *Candidate) { c.EntryQuote = 110.00001 }},
		{"気配が線と同値", func(_ *frame.Snapshot, c *Candidate) { c.EntryQuote = 100 }},
		{"支持を失う", func(s *frame.Snapshot, _ *Candidate) { s.Scales[0].Current.OHLC.Low = 89 }},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			state := warm(t, false, false, false)
			s, c := trendReady(false, false)
			test.change(&s, &c)
			_, a, err := AssessEntry(state, s, c, EntryE1)
			if err != nil {
				t.Fatal(err)
			}
			if !a.Known || a.Allowed || a.Status != Wait {
				t.Fatalf("独立役割の不成立を通した:%+v", a)
			}
		})
	}
}

// TestStrictAndInclusiveBoundaries は並び/傾きのゼロと取得ATR上限を区別します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: なし。
func TestStrictAndInclusiveBoundaries(t *testing.T) {
	for _, name := range []string{"並び同値", "速い傾き同値", "遅い傾き同値", "RSI50同値", "ATR上限同値"} {
		t.Run(name, func(t *testing.T) {
			state := warm(t, false, false, false)
			s, c := trendReady(false, false)
			tc := &s.Scales[0].Current.Technical
			switch name {
			case "並び同値":
				tc.EMA8 = tc.EMA21
			case "速い傾き同値":
				tc.PreviousEMA8 = tc.EMA8
			case "遅い傾き同値":
				tc.PreviousEMA21 = tc.EMA21
			case "RSI50同値":
				tc.RSI = value(50)
			case "ATR上限同値":
				c.EntryQuote = 110
			}
			_, a, err := AssessEntry(state, s, c, EntryE1)
			if err != nil {
				t.Fatal(err)
			}
			if a.Allowed != (name == "ATR上限同値") {
				t.Fatalf("境界:%s %+v", name, a)
			}
		})
	}
}

// TestUnknownIsNotWait は未公表・数値種だけ・履歴不足・鮮度外を分けます。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: なし。
func TestUnknownIsNotWait(t *testing.T) {
	for _, name := range []string{"当場30分なし", "seedだけ", "価格未知", "MACD前値未知", "鮮度境界"} {
		t.Run(name, func(t *testing.T) {
			state := warm(t, false, false, false)
			s, c := trendReady(false, false)
			switch name {
			case "当場30分なし":
				s.Scales[2].HasCurrent = false
			case "seedだけ":
				s.Scales[2].HasCurrent = false
				s.Scales[2].SeedOnly = true
			case "価格未知":
				s.Scales[0].Current.PriceKnown = false
			case "MACD前値未知":
				s.Scales[0].Current.Technical.PreviousHistogram = frame.Value{}
			case "鮮度境界":
				s.Scales[0].Fresh = false
			}
			_, a, err := AssessEntry(state, s, c, EntryE1)
			if err != nil {
				t.Fatal(err)
			}
			if a.Known || a.Allowed || a.Status != Unknown {
				t.Fatalf("未知が支持になった:%+v", a)
			}
		})
	}
}

// TestVolumeUnknownAndQuantityDoNotGate は量未知と枚数変更を新条件にしません。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: なし。
func TestVolumeUnknownAndQuantityDoNotGate(t *testing.T) {
	for _, unknownVolume := range []bool{false, true} {
		state := warm(t, false, false, unknownVolume)
		s, c := trendReady(false, unknownVolume)
		c.Quantity = 17
		_, a, err := AssessEntry(state, s, c, EntryE1)
		if err != nil {
			t.Fatal(err)
		}
		if !a.Allowed || a.Candidate.Quantity != 17 || a.Volume[0].Known == unknownVolume {
			t.Fatalf("量/枚数でgate又は書換:%+v", a)
		}
	}
}

// TestSpikeAndPersistence は単発のRSI/値幅異常と継続を分けます。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: なし。
func TestSpikeAndPersistence(t *testing.T) {
	for _, name := range []string{"複合同時超過", "TRだけ上限同値", "RSIだけ上限同値", "前の5分が失速"} {
		t.Run(name, func(t *testing.T) {
			state := warm(t, false, false, false)
			s, c := trendReady(false, false)
			tc := &s.Scales[0].Current.Technical
			tc.TR = value(21)
			tc.RSI = value(tc.PreviousRSI.Value + 21)
			s.Scales[0].Current.OHLC = frame.OHLC{Open: 99, High: 119, Low: 98, Close: 115}
			if name == "TRだけ上限同値" {
				tc.TR = value(20)
			}
			if name == "RSIだけ上限同値" {
				tc.RSI = value(tc.PreviousRSI.Value + 20)
			}
			if name == "前の5分が失速" {
				tc.TR = value(10)
				tc.RSI = value(tc.PreviousRSI.Value + 1)
				state.Last[0].Technical.PreviousHistogram = state.Last[0].Technical.Histogram
			}
			_, a, err := AssessEntry(state, s, c, EntryE1)
			if err != nil {
				t.Fatal(err)
			}
			want := name == "TRだけ上限同値" || name == "RSIだけ上限同値"
			if a.Allowed != want {
				t.Fatalf("複合警戒/連続2本:%s %+v", name, a)
			}
		})
	}
}

// TestHighRSIMaintenanceVersusSpike は高値維持を失速へ変換せず、一時異常を別に警戒します。
//
// 引数: t(*testing.T)はRSI水準と変化の人工反例です。
// 返り値: なし。TのRSI同方向差0を許し、Rのstrict回復条件は変更しません。
func TestHighRSIMaintenanceVersusSpike(t *testing.T) {
	for _, name := range []string{"RSI100維持", "RSI95維持", "単発のRSI95到達"} {
		t.Run(name, func(t *testing.T) {
			state := warm(t, false, false, false)
			s, c := trendReady(false, false)
			level := 95.0
			if name == "RSI100維持" {
				level = 100
			}
			state.Last[0].Technical.RSI = value(level)
			state.Last[0].Technical.PreviousRSI = value(level)
			s.Scales[0].Current.Technical.RSI = value(level)
			s.Scales[0].Current.Technical.PreviousRSI = value(level)
			if name == "単発のRSI95到達" {
				state.Last[0].Technical.RSI = value(65)
				state.Last[0].Technical.PreviousRSI = value(64)
				s.Scales[0].Current.Technical.PreviousRSI = value(65)
				s.Scales[0].Current.Technical.TR = value(21)
				s.Scales[0].Current.OHLC = frame.OHLC{Open: 99, High: 119, Low: 98, Close: 115}
			}
			_, a, err := AssessEntry(state, s, c, EntryE1)
			if err != nil {
				t.Fatal(err)
			}
			if a.Allowed == (name == "単発のRSI95到達") {
				t.Fatalf("高水準維持と単発スパイクを混同:%s %+v", name, a)
			}
		})
	}
	s := artificialSnapshot(4800, true)
	s.Scales[0].Current.Technical.RSI = s.Scales[0].Current.Technical.PreviousRSI
	if fiveMomentum(s.Scales[0].Current, 1, Reversal).Passed {
		t.Fatal("Rのstrict回復まで緩めた")
	}
}

// TestPriorLevelAndFuturePivot は同じ足で得た新線や未来pivotを使いません。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: なし。
func TestPriorLevelAndFuturePivot(t *testing.T) {
	for _, name := range []string{"試験開始後のpivot", "当足Newだけ", "未来確認", "新15分の高安"} {
		t.Run(name, func(t *testing.T) {
			state := NewEntryState()
			for _, end := range []float64{3600, 3900, 4200} {
				state = feed(t, state, artificialSnapshot(end, false))
			}
			s := artificialSnapshot(4500, false)
			s.Scales[0].Current.OHLC = frame.OHLC{Open: 99, High: 102, Low: 98, Close: 101}
			c := buyCandidate(s, 101)
			switch name {
			case "試験開始後のpivot":
				s.Scales[0].Current.PriorHigh.PublishedAt = s.Scales[0].Current.Start + 1
			case "当足Newだけ":
				s.Scales[0].Current.NewHigh = s.Scales[0].Current.PriorHigh
				s.Scales[0].Current.PriorHigh = frame.Pivot{}
			case "未来確認":
				s.Scales[0].Current.PriorHigh.PublishedAt = s.AsOf + 1
			case "新15分の高安":
				s.Scales[1].Current.OHLC.Low = 80
				s.Scales[0].Current.OHLC.Low = 89
			}
			_, a, err := AssessEntry(state, s, c, EntryE1)
			if name == "未来確認" {
				if err == nil {
					t.Fatal("未来pivotをAPI違反にしない")
				}
				return
			}
			if err != nil {
				t.Fatal(err)
			}
			if a.Allowed {
				t.Fatalf("後得線を使用:%s %+v", name, a)
			}
		})
	}
}

// TestReversalSequenceAndSymmetry は上位と逆でも三段階の価格確認を要求します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: なし。
func TestReversalSequenceAndSymmetry(t *testing.T) {
	for _, mirror := range []bool{false, true} {
		t.Run(fmt.Sprint(mirror), func(t *testing.T) {
			state := warm(t, true, mirror, false)
			bars := []frame.OHLC{{Open: 92, High: 95, Low: 89, Close: 89.5}, {Open: 90, High: 95, Low: 89.5, Close: 93}, {Open: 94, High: 102, Low: 92, Close: 101}}
			for i, o := range bars {
				s := artificialSnapshot(4800+300*float64(i), true)
				s.Scales[0].Current.OHLC = o
				s = transform(s, mirror, false)
				c := buyCandidate(s, 101)
				if mirror {
					c.Side = -1
					c.EntryQuote = 199
				}
				next, a, err := AssessEntry(state, s, c, EntryE1)
				if err != nil {
					t.Fatal(err)
				}
				state = next
				if a.Allowed != (i == 2) {
					t.Fatalf("順序%d:%+v", i, a)
				}
				if i == 2 && (a.Role != Reversal || a.ReversalLabel != "局所反転") {
					t.Fatalf("長期不一致を反転否定又は格上げ:%+v", a)
				}
			}
		})
	}
}

// TestOneBarCannotRecoverAndBreak は一足内の失敗・復帰・突破をまとめません。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: なし。
func TestOneBarCannotRecoverAndBreak(t *testing.T) {
	state := warm(t, true, false, false)
	s := artificialSnapshot(4800, true)
	s.Scales[0].Current.OHLC = frame.OHLC{Open: 92, High: 105, Low: 89, Close: 103}
	next, a, err := AssessEntry(state, s, buyCandidate(s, 103), EntryE1)
	if err != nil {
		t.Fatal(err)
	}
	if a.Allowed || next.View().Reversal[0].Phase != "更新失敗確認待ち" {
		t.Fatalf("同足を多重利用:%+v %+v", a, next.View())
	}
	again, b, err := AssessEntry(next, s, buyCandidate(s, 103), EntryE1)
	if err != nil {
		t.Fatal(err)
	}
	if again != next || !reflect.DeepEqual(a, b) {
		t.Fatal("同じ公表の再評価で構造が進んだ")
	}
}

// TestRetestNeedsLaterBar は突破と再試験を別足として扱います。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: なし。
func TestRetestNeedsLaterBar(t *testing.T) {
	state := warm(t, false, false, false)
	s, c := trendReady(false, false)
	next, a, err := AssessEntry(state, s, c, EntryE1)
	if err != nil {
		t.Fatal(err)
	}
	if a.Structure.Event != "突破" {
		t.Fatal("同足を再試験へした")
	}
	r := artificialSnapshot(5100, false)
	r.Scales[0].Current.OHLC = frame.OHLC{Open: 101, High: 103, Low: 100, Close: 102}
	_, b, err := AssessEntry(next, r, buyCandidate(r, 102), EntryE1)
	if err != nil {
		t.Fatal(err)
	}
	if !b.Allowed || b.Structure.Event != "再試験" {
		t.Fatalf("別足再試験:%+v", b)
	}
}

// TestSupportLossAndExpiry は境界喪失と期限ちょうどで旧setupを失効させます。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: なし。
func TestSupportLossAndExpiry(t *testing.T) {
	state := warm(t, false, false, false)
	s, c := trendReady(false, false)
	next, _, err := AssessEntry(state, s, c, EntryE1)
	if err != nil {
		t.Fatal(err)
	}
	expiry := next.Sides[0].T.ExpiresAt
	oldID := next.Sides[0].T.ID
	late := s
	late.AsOf = expiry
	late.ReplayObservedAt = expiry
	late.RecordOrdinal = uint64(expiry)
	out := feed(t, next, late)
	if out.Sides[0].T.Active || out.Sides[0].RetiredT != oldID || out.Sides[0].T.Reason != "順行setup期限切れ" {
		t.Fatal("期限を同じ足で更新した")
	}
	loss := artificialSnapshot(5100, false)
	loss.Scales[0].Current.OHLC = frame.OHLC{Open: 101, High: 102, Low: 89, Close: 99}
	out = feed(t, next, loss)
	if out.Sides[0].T.Active || !strings.Contains(out.Sides[0].T.Reason, "失った") {
		t.Fatal("支持喪失後も順行setupを維持")
	}
}

// TestReversalInvalidation は旧方向の更新継続と復帰後の喪失を反転成立にしません。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: なし。
func TestReversalInvalidation(t *testing.T) {
	for _, loss := range []bool{false, true} {
		state := warm(t, true, false, false)
		s := artificialSnapshot(4800, true)
		s.Scales[0].Current.OHLC = frame.OHLC{Open: 92, High: 95, Low: 89, Close: 89.5}
		state = feed(t, state, s)
		r := artificialSnapshot(5100, true)
		r.Scales[0].Current.OHLC = frame.OHLC{Open: 90, High: 94, Low: 89.5, Close: 93}
		if !loss {
			r.Scales[0].Current.OHLC.Low = 88
			state = feed(t, state, r)
		} else {
			state = feed(t, state, r)
			r = artificialSnapshot(5400, true)
			r.Scales[0].Current.OHLC = frame.OHLC{Open: 93, High: 94, Low: 89.5, Close: 90}
			state = feed(t, state, r)
		}
		if state.Sides[0].R.Active || state.Sides[0].R.Phase != "失効" {
			t.Fatal("価格否定後も反転状態を維持")
		}
	}
}

// TestConflictGuardUsesOnlyAllowedSet は適格集合内の成立結果だけで競合を解消します。
//
// 引数: t(*testing.T)は安全規約の独立人工です。
// 返り値: なし。初期strict勢い条件では数学的に両向き同時成立しません。
func TestConflictGuardUsesOnlyAllowedSet(t *testing.T) {
	base := []Assessment{{Candidate: Candidate{ID: "買", Side: 1}, Known: true, Allowed: true, Status: Allowed, Role: Trend}, {Candidate: Candidate{ID: "売", Side: -1}, Known: true, Allowed: true, Status: Allowed, Role: Reversal}, {Candidate: Candidate{ID: "未知", Side: -1}, Status: Unknown}}
	for _, policy := range []Policy{EntryE0, EntryE1} {
		rows := append([]Assessment(nil), base...)
		got := resolveConflict(policy, rows)
		if got != (policy == EntryE1) {
			t.Fatal("政策別競合")
		}
		for i := 0; i < 2; i++ {
			if rows[i].Allowed == (policy == EntryE1) {
				t.Fatal("競合を片側だけ通した")
			}
		}
		if rows[2] != base[2] {
			t.Fatal("未知を競合成立へ昇格")
		}
	}
	rows := append([]Assessment(nil), base[:1]...)
	if resolveConflict(EntryE1, rows) || !rows[0].Allowed {
		t.Fatal("集合外の反対方向で落とした")
	}
	rows = append([]Assessment(nil), base...)
	rows[1].Allowed = false
	rows[1].Status = Wait
	if resolveConflict(EntryE1, rows) || !rows[0].Allowed {
		t.Fatal("不成立の反対側で落とした")
	}
}

// TestBatchEchoPermutationAndE0 は全候補の原値と順序依存しない純判定を確認します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: なし。
func TestBatchEchoPermutationAndE0(t *testing.T) {
	state := warm(t, false, false, false)
	s, c := trendReady(false, false)
	other := c
	other.ID = "出生2"
	other.Quantity = 2
	input := []Candidate{c, other}
	before := append([]Candidate(nil), input...)
	next, a, err := AssessBatch(state, s, input, EntryE1)
	if err != nil {
		t.Fatal(err)
	}
	next2, b, err := AssessBatch(state, s, []Candidate{other, c}, EntryE1)
	if err != nil {
		t.Fatal(err)
	}
	if next != next2 || !reflect.DeepEqual(input, before) || a.Decisions[0].Candidate != c || a.Decisions[1].Candidate != other || !reflect.DeepEqual(a.Decisions[0], b.Decisions[1]) {
		t.Fatal("候補を順次状態更新/変更した")
	}
	short := c
	short.ID = "反対側"
	short.Side = -1
	_, control, err := AssessBatch(state, s, []Candidate{c, short}, EntryE0)
	if err != nil {
		t.Fatal(err)
	}
	if control.Conflict || !control.Decisions[0].Allowed || !control.Decisions[1].Allowed {
		t.Fatal("E0へ追加gate/競合を混ぜた")
	}
}

// TestEOFAndSealNonInterference は将来の収録末尾やI/O完了を政策根拠にしません。
//
// 引数: t(*testing.T)はT/R両方の非干渉検査です。
// 返り値: なし。
func TestEOFAndSealNonInterference(t *testing.T) {
	for _, reversal := range []bool{false, true} {
		state := warm(t, reversal, false, false)
		var s frame.Snapshot
		var c Candidate
		if !reversal {
			s, c = trendReady(false, false)
		} else {
			f := artificialSnapshot(4800, true)
			f.Scales[0].Current.OHLC = frame.OHLC{Open: 92, High: 95, Low: 89, Close: 89.5}
			state = feed(t, state, f)
			f = artificialSnapshot(5100, true)
			f.Scales[0].Current.OHLC = frame.OHLC{Open: 90, High: 95, Low: 89.5, Close: 93}
			state = feed(t, state, f)
			s = artificialSnapshot(5400, true)
			s.Scales[0].Current.OHLC = frame.OHLC{Open: 94, High: 102, Low: 92, Close: 101}
			c = buyCandidate(s, 101)
		}
		altered := s
		altered.Session.EOF = s.AsOf + 1
		altered.Sealed = true
		original := altered
		n1, a, err := AssessEntry(state, s, c, EntryE1)
		if err != nil {
			t.Fatal(err)
		}
		n2, b, err := AssessEntry(state, altered, c, EntryE1)
		if err != nil {
			t.Fatal(err)
		}
		if !a.Allowed || !reflect.DeepEqual(a, b) || n1 != n2 || altered != original || n2.Session.EOF != 0 {
			t.Fatal("未来EOF/Sealが政策又は原入力へ干渉")
		}
	}
}

// TestScopeResetGapAndInputErrors は連続性やAPI違反を無視して再利用しません。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: なし。
func TestScopeResetGapAndInputErrors(t *testing.T) {
	state := warm(t, false, false, false)
	s, c := trendReady(false, false)
	for _, name := range []string{"候補ID重複", "方向0", "数量0", "未来公表", "気配NaN", "要求時計違い", "同ID改変"} {
		t.Run(name, func(t *testing.T) {
			x := s
			cs := []Candidate{c}
			switch name {
			case "候補ID重複":
				cs = append(cs, c)
			case "方向0":
				cs[0].Side = 0
			case "数量0":
				cs[0].Quantity = 0
			case "未来公表":
				x.Scales[0].Current.DeliveryAt = x.AsOf + 1
			case "気配NaN":
				cs[0].EntryQuote = math.NaN()
			case "要求時計違い":
				cs[0].At--
			case "同ID改変":
				x.Scales[2].Current.OHLC.High++
			}
			next, _, err := AssessBatch(state, x, cs, EntryE1)
			if err == nil || next != state {
				t.Fatal("入力違反を通す又は状態を変更")
			}
		})
	}
	gap := artificialSnapshot(5100, false)
	out := feed(t, state, gap)
	if out.HasPreviousFive || out.Sides[0].T.Active || !strings.Contains(out.ResetReason, "初期化") {
		t.Fatal("欠公表を補完した")
	}
	newScope := s
	newScope.Session.ID = "次場"
	newScope.Session.Contract = "次限月"
	for i := range newScope.Scales {
		newScope.Scales[i].HasCurrent = false
		newScope.Scales[i].SeedOnly = true
	}
	next, _, err := AssessBatch(state, newScope, nil, EntryE1)
	if err != nil {
		t.Fatal(err)
	}
	if next.HasPreviousFive || next.Sides[0].T.Active || next.Session.Contract != "次限月" {
		t.Fatal("場/限月を越えて構造を継承")
	}
}
