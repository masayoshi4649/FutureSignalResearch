package threeentry

import (
	"fmt"
	"strings"

	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

// knownValues は指定した値が全て既知かを返します。
//
// 引数: values(...frame.Value)は必要な指標列です。
// 返り値: boolは未知をゼロとして補わず全列が既知であることです。
func knownValues(values ...frame.Value) bool {
	for _, v := range values {
		if !v.Known {
			return false
		}
	}
	return true
}

// background は平均値の並びと二つの傾きを別々に計算します。
//
// 引数: f(frame.Frame)は当場の一つの確定公表です。
// 返り値: Backgroundは方向整合とATR正規化、pivotの診断値です。
func background(f frame.Frame) Background {
	t := f.Technical
	b := Background{WidthSeconds: f.WidthSeconds, PriorHighKnown: f.PriorHigh.Known, PriorHigh: f.PriorHigh.Price, PriorLowKnown: f.PriorLow.Known, PriorLow: f.PriorLow.Price}
	if !f.PriceKnown || !knownValues(t.EMA8, t.EMA21, t.PreviousEMA8, t.PreviousEMA21, t.ATR) {
		return b
	}
	b.Known = true
	b.Gap = t.EMA8.Value - t.EMA21.Value
	b.FastDelta = t.EMA8.Value - t.PreviousEMA8.Value
	b.SlowDelta = t.EMA21.Value - t.PreviousEMA21.Value
	if b.Gap > 0 && b.FastDelta > 0 && b.SlowDelta > 0 {
		b.Direction = 1
	}
	if b.Gap < 0 && b.FastDelta < 0 && b.SlowDelta < 0 {
		b.Direction = -1
	}
	if t.ATR.Value > 0 {
		b.NormalizedKnown = true
		b.GapATR = b.Gap / t.ATR.Value
		b.FastDeltaATR = b.FastDelta / t.ATR.Value
		b.SlowDeltaATR = b.SlowDelta / t.ATR.Value
	}
	return b
}

// common は価格、公表、鮮度、数値種、当場履歴の基本可用性を分けます。
//
// 引数: state(EntryState)、snapshot(frame.Snapshot)は純更新後状態と判断copyです。
// 返り値: Checkは全経路共通の既知性です。量やpivot不成立は必須にしません。
func common(state EntryState, snapshot frame.Snapshot) Check {
	if !snapshot.HasObserved {
		return Check{Reason: "観測時計が未到達"}
	}
	for _, width := range widths {
		scale, _ := snapshot.Scale(width)
		if !scale.HasCurrent || scale.SeedOnly {
			return Check{Reason: fmt.Sprintf("%d秒の当場公表待ち（数値種を現在支持にしない）", width)}
		}
		if !scale.Current.PriceKnown {
			return Check{Reason: fmt.Sprintf("%d秒の価格が未知", width)}
		}
		if !scale.Fresh || snapshot.AsOf-scale.Current.AvailableAt >= float64(width) {
			return Check{Reason: fmt.Sprintf("%d秒公表が鮮度外", width)}
		}
		if !background(scale.Current).Known {
			return Check{Reason: fmt.Sprintf("%d秒EMA/前値/ATRの履歴不足", width)}
		}
	}
	if !state.HasPreviousFive {
		return Check{Reason: "連続した当場5分の前公表が不足"}
	}
	return Check{Known: true, Passed: true, Reason: "三尺度の当場公表・時計・価格・平均値履歴が既知"}
}

// and は独立票数を作らず、経路の論理群を一つのANDとして評価します。
//
// 引数: checks(...Check)は同じ経路の必要条件です。
// 返り値: Checkは必要な未知を残し、全既知の場合だけ成立/不成立を示します。
func and(checks ...Check) Check {
	for _, check := range checks {
		if !check.Known {
			return Check{Reason: check.Reason}
		}
	}
	for _, check := range checks {
		if !check.Passed {
			return Check{Known: true, Reason: check.Reason}
		}
	}
	return Check{Known: true, Passed: true, Reason: "複合条件成立"}
}

// fiveMomentum はRSIの側と変化、MACD変化を一つの勢い群として確認します。
//
// 引数: f(frame.Frame)、side(int)、role(Role)は5分足・Source方向・順行/反転です。
// 返り値: Checkは単一票に分解しない勢い群です。
func fiveMomentum(f frame.Frame, side int, role Role) Check {
	t := f.Technical
	if !knownValues(t.RSI, t.PreviousRSI, t.Histogram, t.PreviousHistogram) {
		return Check{Reason: "5分RSI/MACDと前値が未知"}
	}
	s := float64(side)
	level := s*(t.RSI.Value-50) > 0
	if role == Reversal {
		level = s*(t.RSI.Value-50) >= -Rules().ReversalRSIAllowance
	}
	rsiChange := s*(t.RSI.Value-t.PreviousRSI.Value) > 0
	if role == Trend {
		rsiChange = s*(t.RSI.Value-t.PreviousRSI.Value) >= 0
	}
	pass := level && rsiChange && s*(t.Histogram.Value-t.PreviousHistogram.Value) > 0
	return Check{Known: true, Passed: pass, Reason: map[bool]string{true: "5分勢い一群が同方向", false: "5分RSIの側/変化/MACD変化が揃わない"}[pass]}
}

// momentum は5分の連続2本と、15分の逆推進でないことを確認します。
//
// 引数: state(EntryState)、fifteen(frame.Frame)、side(int)、role(Role)は当場履歴とSource方向です。
// 返り値: CheckはEMA/MACDを独立票へ増やさない勢い確認です。
func momentum(state EntryState, fifteen frame.Frame, side int, role Role) Check {
	current := fiveMomentum(state.Last[0], side, role)
	previous := fiveMomentum(state.PreviousFive, side, role)
	t := fifteen.Technical
	needed := knownValues(t.RSI, t.Histogram, t.PreviousHistogram)
	if role == Reversal {
		needed = needed && t.PreviousRSI.Known
	}
	if !needed {
		return Check{Reason: "15分の必要な勢い列が未知"}
	}
	s := float64(side)
	pass := s*(t.RSI.Value-50) >= 0 && s*(t.Histogram.Value-t.PreviousHistogram.Value) >= 0
	if role == Reversal {
		pass = s*(t.RSI.Value-t.PreviousRSI.Value) >= 0 && s*(t.Histogram.Value-t.PreviousHistogram.Value) >= 0
	}
	upper := Check{Known: true, Passed: pass, Reason: map[bool]string{true: "15分が取得側への回復を否定しない", false: "15分の勢いが逆方向を推進"}[pass]}
	return and(current, previous, upper)
}

// spike は値幅とRSI順方向変化の同時異常を警戒します。
//
// 引数: state(EntryState)、side(int)は連続5分履歴とSource方向です。
// 返り値: Checkは直近2本に複合スパイクがないことです。
func spike(state EntryState, side int) Check {
	for _, f := range [2]frame.Frame{state.Last[0], state.PreviousFive} {
		t := f.Technical
		if !knownValues(t.TR, t.PreviousATR, t.RSI, t.PreviousRSI) {
			return Check{Reason: "5分スパイク判定の値幅/前ATR/RSIが未知"}
		}
		if t.TR.Value > Rules().SpikeTRMultiple*t.PreviousATR.Value && float64(side)*(t.RSI.Value-t.PreviousRSI.Value) > Rules().SpikeRSIChange {
			return Check{Known: true, Reason: "TRが前ATRの2倍超かつRSIが順方向20超の複合スパイク"}
		}
	}
	return Check{Known: true, Passed: true, Reason: "連続2本に値幅とRSIの複合スパイクなし"}
}

// distance は固定線の外側で最大1ATR以内の取得だけを認めます。
//
// 引数: candidate(Candidate)、setup(SetupView)、atr(float64)は新規側気配と確定5分ATRです。
// 返り値: Checkは同値線外を許さず、ATR上限の同値は許す位置判定です。
func distance(candidate Candidate, setup SetupView, atr float64) Check {
	d := float64(candidate.Side) * (candidate.EntryQuote - setup.Trigger)
	pass := atr > 0 && d > 0 && d <= Rules().MaxDistanceATR*atr && float64(candidate.Side)*(candidate.EntryQuote-setup.Boundary) > 0
	return Check{Known: true, Passed: pass, Reason: map[bool]string{true: "固定線の外かつ取得距離1ATR以内", false: "取得側気配が線内/同値、risk境界内又は1ATR超"}[pass]}
}

// assess は同じ更新後stateを一候補へ適用します。状態を消費しません。
//
// 引数: state(EntryState)、snapshot(frame.Snapshot)、candidate(Candidate)、policy(Policy)、identity(string)は共通公開値です。
// 返り値: AssessmentはSource方向・数量・IDをそのまま保持した判定です。
func assess(state EntryState, snapshot frame.Snapshot, candidate Candidate, policy Policy, identity string) Assessment {
	a := Assessment{Candidate: candidate, SnapshotID: identity, Policy: policy, Status: Unknown}
	for i, width := range widths {
		scale, _ := snapshot.Scale(width)
		a.Volume[i] = VolumeAudit{WidthSeconds: width, Known: scale.HasCurrent && scale.Current.VolumeKnown, Value: scale.Current.Volume}
		if scale.HasCurrent {
			a.Background[i] = background(scale.Current)
		} else {
			a.Background[i].WidthSeconds = width
		}
	}
	if policy == EntryE0 {
		a.Known = true
		a.Allowed = true
		a.Status = Allowed
		a.Role = Control
		a.Reason = "入口追加Gateなし対照"
		return a
	}
	ready := common(state, snapshot)
	if !ready.Known {
		a.Reason = ready.Reason
		a.Trend = ready
		a.Reversal = ready
		return a
	}
	i := 0
	if candidate.Side == -1 {
		i = 1
	}
	local := state.Sides[i]
	five := state.Last[0]
	fifteen, _ := snapshot.Scale(900)
	a.TrendMomentum = momentum(state, fifteen.Current, candidate.Side, Trend)
	a.ReversalMomentum = momentum(state, fifteen.Current, candidate.Side, Reversal)
	a.Spike = spike(state, candidate.Side)
	aligned := true
	for _, b := range a.Background {
		aligned = aligned && b.Direction == candidate.Side
	}
	direction := Check{Known: true, Passed: aligned, Reason: map[bool]string{true: "三尺度の並びと両傾きがSource方向", false: "三尺度の並び/速い傾き/遅い傾きが不一致又は同値"}[aligned]}
	tEvent := Check{Known: true, Passed: local.T.EventBarID == five.ID && local.T.Event != "", Reason: local.T.Reason}
	if tEvent.Reason == "" {
		tEvent.Reason = "順行の事前固定構造が未形成"
	}
	rEvent := Check{Known: true, Passed: local.R.EventBarID == five.ID && local.R.Event == "反対側突破", Reason: local.R.Reason}
	if rEvent.Reason == "" {
		rEvent.Reason = "反転の失敗→復帰→別足突破が未形成"
	}
	a.Trend = and(direction, tEvent, a.TrendMomentum, a.Spike, distance(candidate, local.T, five.Technical.ATR.Value))
	a.Reversal = and(rEvent, a.ReversalMomentum, a.Spike, distance(candidate, local.R, five.Technical.ATR.Value))
	if a.Trend.Passed {
		a.Known = true
		a.Allowed = true
		a.Status = Allowed
		a.Role = Trend
		a.Structure = local.T
		a.Momentum = a.TrendMomentum
		a.Reason = "T:方向・押戻し構造・勢い一群・値幅/取得位置が成立"
		return a
	}
	if a.Reversal.Passed {
		a.Known = true
		a.Allowed = true
		a.Status = Allowed
		a.Role = Reversal
		a.Structure = local.R
		a.Momentum = a.ReversalMomentum
		a.Reason = "R:更新試行→復帰→別足突破・勢い一群・値幅/取得位置が成立"
		a.ReversalLabel = "局所反転"
		if a.Background[1].Direction == candidate.Side && a.Background[2].Direction == candidate.Side {
			a.ReversalLabel = "15/30分も整合した構造反転"
		}
		return a
	}
	a.Reason = strings.Join([]string{"T:" + a.Trend.Reason, "R:" + a.Reversal.Reason}, " / ")
	if a.Trend.Known && a.Reversal.Known {
		a.Known = true
		a.Status = Wait
	}
	return a
}

// AssessBatch は金融適格集合だけを同じsnapshotで先に評価します。
//
// 引数: state(EntryState)、snapshot(frame.Snapshot)、candidates([]Candidate)、policy(Policy)は旧値と候補の値copyです。
// 返り値: EntryState/BatchAssessment/errorは純更新後値・全候補判定・入力違反です。原入力は変更しません。
func AssessBatch(state EntryState, snapshot frame.Snapshot, candidates []Candidate, policy Policy) (EntryState, BatchAssessment, error) {
	originalState := state
	snapshot = PolicySnapshot(snapshot)
	state.Session.EOF = 0
	if err := validate(state, snapshot, candidates, policy); err != nil {
		return originalState, BatchAssessment{}, err
	}
	identity, err := SnapshotID(snapshot)
	if err != nil {
		return originalState, BatchAssessment{}, err
	}
	next, err := advance(state, snapshot)
	if err != nil {
		return originalState, BatchAssessment{}, err
	}
	output := BatchAssessment{SnapshotID: identity, Policy: policy, State: next.View(), Decisions: make([]Assessment, 0, len(candidates))}
	for i, width := range widths {
		scale, _ := snapshot.Scale(width)
		output.Volume[i] = VolumeAudit{WidthSeconds: width, Known: scale.HasCurrent && scale.Current.VolumeKnown, Value: scale.Current.Volume}
	}
	for _, candidate := range candidates {
		a := assess(next, snapshot, candidate, policy, identity)
		output.Decisions = append(output.Decisions, a)
	}
	output.Conflict = resolveConflict(policy, output.Decisions)
	return next, output, nil
}

// resolveConflict は金融適格集合の成立結果だけを対象にした最後の安全判定です。
//
// 引数: policy(Policy)、decisions([]Assessment)は内部で新規確保した結果です。
// 返り値: boolは両方向成立の競合です。未知/不成立候補は変えません。
func resolveConflict(policy Policy, decisions []Assessment) bool {
	if policy != EntryE1 {
		return false
	}
	buy, sell := false, false
	for _, a := range decisions {
		if a.Allowed {
			buy = buy || a.Candidate.Side == 1
			sell = sell || a.Candidate.Side == -1
		}
	}
	if !buy || !sell {
		return false
	}
	for i := range decisions {
		a := &decisions[i]
		if a.Allowed {
			a.Known = true
			a.Allowed = false
			a.Status = Conflict
			a.Reason = "金融適格集合内で両方向の技法成立が競合"
		}
	}
	return true
}

// AssessEntry は純条件を単候補で確認する補助APIです。金融接続ではAssessBatchを使います。
//
// 引数: state(EntryState)、snapshot(frame.Snapshot)、candidate(Candidate)、policy(Policy)は単候補の値copyです。
// 返り値: EntryState/Assessment/errorは次状態・単候補結果・入力違反です。競合判定を代替しません。
func AssessEntry(state EntryState, snapshot frame.Snapshot, candidate Candidate, policy Policy) (EntryState, Assessment, error) {
	next, batch, err := AssessBatch(state, snapshot, []Candidate{candidate}, policy)
	if err != nil {
		return state, Assessment{}, err
	}
	return next, batch.Decisions[0], nil
}
