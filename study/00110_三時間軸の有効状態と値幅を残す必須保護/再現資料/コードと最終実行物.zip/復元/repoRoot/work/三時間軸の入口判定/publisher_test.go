package threeentry

import (
	"strings"
	"testing"

	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

// realPublisherFixture は数式指標の注入なしに、前場の線形助走と当場の押戻しを作ります。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: *frame.Bank/float64は実公開器と当場の価格基準です。
func realPublisherFixture(t *testing.T) (*frame.Bank, float64) {
	return publisherVariant(t, false, false)
}

// publisherVariant は実公開器へ渡す人工価格の鏡像又は未来末尾だけの差を作ります。
//
// 引数: t(*testing.T)、mirror/futureTail(bool)は人工変換の指定です。
// 返り値: *frame.Bank/float64は未加工の指標を作る公開器と当場価格基準です。
func publisherVariant(t *testing.T, mirror, futureTail bool) (*frame.Bank, float64) {
	t.Helper()
	start := 1800000000.0
	prior := frame.Session{ID: "人工助走", Contract: "人工限月", Start: start, End: start + 241*300, EOF: start + 240*300 + 60}
	children := make([]frame.ChildBar, 240)
	for i := range children {
		price := 10000 + float64(i)*2
		children[i] = frame.ChildBar{Start: start + float64(i)*300, End: start + float64(i+1)*300, OHLC: frame.OHLC{Open: price - .5, High: price + 2, Low: price - 2, Close: price}, Volume: 100, Closed: true, VolumeKnown: true, Input: frame.FileRef{Path: "人工助走.csv", SHA256: strings.Repeat("a", 64), Bytes: 12345}, Row: uint64(i + 2)}
	}
	if mirror {
		for i := range children {
			o := children[i].OHLC
			children[i].OHLC = frame.OHLC{Open: 30000 - o.Open, High: 30000 - o.Low, Low: 30000 - o.High, Close: 30000 - o.Close}
		}
	}
	bank, err := frame.BeginSession(prior, children, nil)
	if err != nil {
		t.Fatal(err)
	}
	ordinal := uint64(0)
	for at := prior.Start + 360; at <= prior.EOF; at += 300 {
		ordinal++
		if _, err = bank.AdvanceObserved(at, ordinal); err != nil {
			t.Fatal(err)
		}
	}
	seed, _, err := bank.Seal()
	if err != nil {
		t.Fatal(err)
	}
	base := 10000 + 239*2.0
	ohlc := []frame.OHLC{{Open: 5, High: 7, Low: -2, Close: 0}, {Open: 0, High: 1, Low: -7, Close: -5}, {Open: -5, High: 9, Low: -5, Close: 0}, {Open: 0, High: 8, Low: -2, Close: -1}, {Open: -1, High: 5, Low: -4, Close: -3}, {Open: -3, High: 3, Low: -4, Close: -2}, {Open: -2, High: 13, Low: -2, Close: 11}, {Open: 11, High: 14, Low: 8, Close: 12}, {Open: 12, High: 17, Low: 9, Close: 15}, {Open: 15, High: 18, Low: 10, Close: 16}, {Open: 16, High: 19, Low: 11, Close: 17}, {Open: 17, High: 20, Low: 12, Close: 18}}
	scene := frame.Session{ID: "人工取得", Contract: prior.Contract, Start: prior.End + 3600, End: prior.End + 3600 + 13*300, EOF: prior.End + 3600 + 12*300 + 60}
	current := make([]frame.ChildBar, len(ohlc))
	for i, o := range ohlc {
		o.Open += base
		o.High += base
		o.Low += base
		o.Close += base
		current[i] = frame.ChildBar{Start: scene.Start + float64(i)*300, End: scene.Start + float64(i+1)*300, OHLC: o, Volume: 100, Closed: true, VolumeKnown: true, Input: frame.FileRef{Path: "人工取得.csv", SHA256: strings.Repeat("b", 64), Bytes: 6789}, Row: uint64(i + 2)}
	}
	if futureTail {
		for i := range current {
			current[i].Input.SHA256 = strings.Repeat("c", 64)
			if i >= 10 {
				current[i].OHLC = frame.OHLC{Open: base + 100, High: base + 5000, Low: base - 100, Close: base + 4000}
			}
		}
	}
	if mirror {
		for i := range current {
			o := current[i].OHLC
			current[i].OHLC = frame.OHLC{Open: 30000 - o.Open, High: 30000 - o.Low, Low: 30000 - o.High, Close: 30000 - o.Close}
		}
		base = 30000 - base
	}
	bank, err = frame.BeginSession(scene, current, &seed)
	if err != nil {
		t.Fatal(err)
	}
	return bank, base
}

// TestRealPublisherMirror は実指標計算を通した売買鏡像の非ゼロ成立を確認します。
//
// 引数: t(*testing.T)は人工検査です。
// 返り値: なし。EMA等の指標値は注入しません。
func TestRealPublisherMirror(t *testing.T) {
	bank, _ := publisherVariant(t, true, false)
	initial, err := bank.SnapshotAt(1800000000 + 241*300 + 3600)
	if err != nil {
		t.Fatal(err)
	}
	state := NewEntryState()
	count := 0
	for minute := 1; minute <= 50; minute++ {
		at := initial.Session.Start + float64(minute)*60
		if _, err := bank.AdvanceObserved(at, uint64(minute)); err != nil {
			t.Fatal(err)
		}
		if minute%5 != 0 {
			continue
		}
		s, err := bank.SnapshotAt(at)
		if err != nil {
			t.Fatal(err)
		}
		scale, _ := s.Scale(300)
		price := 19522.0
		if scale.HasCurrent {
			price = scale.Current.OHLC.Close
		}
		candidate := Candidate{ID: "人工売り", Side: -1, At: at, EntryQuote: price, Quantity: 3}
		next, a, err := AssessEntry(state, s, candidate, EntryE1)
		if err != nil {
			t.Fatal(err)
		}
		state = next
		if a.Allowed {
			count++
			if minute != 50 || a.Role != Trend {
				t.Fatalf("鏡像の時刻/経路:%d %+v", minute, a)
			}
		}
	}
	if count != 1 {
		t.Fatalf("売りの非ゼロ成立=%d", count)
	}
}

// TestFutureTailAndWholeFileHashNonInterference は未来子足と全体SHAを変えても過去の政策を変えません。
//
// 引数: t(*testing.T)は実公開器から入口までの人工非干渉検査です。
// 返り値: なし。比較は変更足の公表前50分までに限定します。
func TestFutureTailAndWholeFileHashNonInterference(t *testing.T) {
	banks := [2]*frame.Bank{}
	for i := range banks {
		banks[i], _ = publisherVariant(t, false, i == 1)
	}
	initial, err := banks[0].SnapshotAt(1800000000 + 241*300 + 3600)
	if err != nil {
		t.Fatal(err)
	}
	states := [2]EntryState{}
	changedID := false
	for minute := 1; minute <= 50; minute++ {
		results := [2]Assessment{}
		for i, bank := range banks {
			at := initial.Session.Start + float64(minute)*60
			if _, err := bank.AdvanceObserved(at, uint64(minute)); err != nil {
				t.Fatal(err)
			}
			if minute%5 != 0 {
				continue
			}
			s, err := bank.SnapshotAt(at)
			if err != nil {
				t.Fatal(err)
			}
			five, _ := s.Scale(300)
			price := 10478.0
			if five.HasCurrent {
				price = five.Current.OHLC.Close
			}
			next, a, err := AssessEntry(states[i], s, Candidate{ID: "同じ出生", Side: 1, At: at, EntryQuote: price, Quantity: 3}, EntryE1)
			if err != nil {
				t.Fatal(err)
			}
			states[i] = next
			results[i] = a
		}
		if minute%5 != 0 {
			continue
		}
		a, b := results[0], results[1]
		changedID = changedID || a.SnapshotID != b.SnapshotID
		if a.Known != b.Known || a.Allowed != b.Allowed || a.Status != b.Status || a.Role != b.Role || a.Reason != b.Reason || a.Trend != b.Trend || a.Reversal != b.Reversal {
			t.Fatalf("未来末尾が過去の政策へ干渉 minute=%d", minute)
		}
	}
	if !changedID {
		t.Fatal("出典差を監査指紋へ記録していない")
	}
}

// TestRealPublisherToEntry は子足・親足・数値carry・構造を通って非ゼロのE1許可を確認します。
//
// 引数: t(*testing.T)は市場未読の人工統合検査です。
// 返り値: なし。指標値を手書きせず、実SeriesBankの結果を使います。
func TestRealPublisherToEntry(t *testing.T) {
	bank, base := realPublisherFixture(t)
	seedSnapshot, err := bank.SnapshotAt(1800000000 + 241*300 + 3600)
	if err != nil {
		t.Fatal(err)
	}
	start := seedSnapshot.Session.Start
	state := NewEntryState()
	allowed := 0
	for minute := 1; minute <= 61; minute++ {
		at := start + float64(minute)*60
		if _, err := bank.AdvanceObserved(at, uint64(minute)); err != nil {
			t.Fatal(err)
		}
		if minute%5 != 0 {
			continue
		}
		snapshot, err := bank.SnapshotAt(at)
		if err != nil {
			t.Fatal(err)
		}
		five, _ := snapshot.Scale(300)
		price := base
		if five.HasCurrent && five.Current.PriceKnown {
			price = five.Current.OHLC.Close
		}
		candidate := Candidate{ID: "人工Source", Side: 1, At: at, EntryQuote: price, Quantity: 3}
		next, a, err := AssessEntry(state, snapshot, candidate, EntryE1)
		if err != nil {
			t.Fatal(err)
		}
		state = next
		if a.Allowed {
			allowed++
			t.Logf("非ゼロ許可 minute=%d price=%g role=%s event=%s level=%g atr5=%g", minute, price, a.Role, a.Structure.Event, a.Structure.Trigger, five.Current.Technical.ATR.Value)
		} else {
			t.Logf("minute=%d %s", minute, a.Reason)
		}
	}
	if allowed == 0 {
		t.Fatal("実公開器→純Entryの非ゼロ成立がない")
	}
}
