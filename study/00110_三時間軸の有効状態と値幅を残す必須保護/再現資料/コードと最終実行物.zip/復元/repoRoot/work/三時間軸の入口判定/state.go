package threeentry

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"math"

	frame "github.com/masayoshi4649/SessionTradeExecuter/threeframe"
)

var widths = [3]int{frame.FiveMinutes, frame.FifteenMinutes, frame.ThirtyMinutes}

// finite は公開値やAPI引数の有限性を確認します。
//
// 引数: value(float64)は検査値です。
// 返り値: boolはNaN/Infでないことです。
func finite(value float64) bool { return !math.IsNaN(value) && !math.IsInf(value, 0) }

// published は四つの公表時計の最大値を返します。
//
// 引数: f(frame.Frame)は確定公表の値copyです。
// 返り値: float64はその足を知り得た最も遅い時計です。
func published(f frame.Frame) float64 {
	return math.Max(math.Max(f.NominalAvailable, f.AvailableAt), math.Max(f.ObservedAt, f.DeliveryAt))
}

// PolicySnapshot は将来の収録終端とI/O完了状態を政策入力から除きます。
//
// 引数: snapshot(frame.Snapshot)は出典付きの元copyです。
// 返り値: frame.SnapshotはEOF=0/Sealed=falseの値copyで、元入力は変更しません。
func PolicySnapshot(snapshot frame.Snapshot) frame.Snapshot {
	snapshot.Session.EOF = 0
	snapshot.Sealed = false
	return snapshot
}

// SnapshotID は政策射影後の時計・既知性・公開値を含むsnapshotの指紋を作ります。
//
// 引数: snapshot(frame.Snapshot)は判断時点の不変copyです。
// 返り値: string/errorはSHA256、又は非有限値などのJSON不成立です。
func SnapshotID(snapshot frame.Snapshot) (string, error) {
	snapshot = PolicySnapshot(snapshot)
	data, err := json.Marshal(snapshot)
	if err != nil {
		return "", fmt.Errorf("snapshot指紋:%w", err)
	}
	h := sha256.Sum256(data)
	return hex.EncodeToString(h[:]), nil
}

// checkFrame はAPIへ露出した確定足の場・区間・公表時計を検査します。
//
// 引数: s(frame.Snapshot)、f(frame.Frame)、width(int)は判断copy・確定足・幅です。
// 返り値: errorは未来値、場違い、非有限、価格不正などです。
func checkFrame(s frame.Snapshot, f frame.Frame, width int) error {
	if f.ID == "" || f.SessionID != s.Session.ID || f.Contract != s.Session.Contract || f.WidthSeconds != width || !finite(f.Start) || !finite(f.End) || f.End-f.Start != float64(width) || f.Start < s.Session.Start || f.End > s.Session.End {
		return fmt.Errorf("%d秒公表の場/ID/足区間不正", width)
	}
	for _, clock := range []float64{f.NominalAvailable, f.AvailableAt, f.ObservedAt, f.DeliveryAt} {
		if !finite(clock) || clock < f.End || clock > s.AsOf {
			return fmt.Errorf("%d秒公表に未来又は不正時計", width)
		}
	}
	if f.AvailableAt < f.NominalAvailable || f.ObservedAt < f.NominalAvailable || f.DeliveryAt < f.ObservedAt || f.RecordOrdinal > s.RecordOrdinal {
		return fmt.Errorf("%d秒公表時計/出典順の不正", width)
	}
	if f.PriceKnown {
		o := f.OHLC
		if !finite(o.Open) || !finite(o.High) || !finite(o.Low) || !finite(o.Close) || o.Low <= 0 || o.High < o.Low || o.Open < o.Low || o.Open > o.High || o.Close < o.Low || o.Close > o.High {
			return fmt.Errorf("%d秒OHLC不正", width)
		}
	}
	if f.VolumeKnown && (!finite(f.Volume) || f.Volume < 0) {
		return fmt.Errorf("%d秒出来高不正", width)
	}
	t := f.Technical
	for _, value := range []frame.Value{t.EMA8, t.EMA21, t.PreviousEMA8, t.PreviousEMA21, t.EMA8Delta, t.EMA21Delta, t.Gap, t.GapATR, t.EMA8DeltaATR, t.EMA21DeltaATR, t.ATR, t.PreviousATR, t.TR, t.RSI, t.PreviousRSI, t.Histogram, t.PreviousHistogram, t.CrossSessionJump} {
		if value.Known && !finite(value.Value) {
			return fmt.Errorf("%d秒既知指標が非有限", width)
		}
	}
	for _, value := range []frame.Value{t.RSI, t.PreviousRSI} {
		if value.Known && (value.Value < 0 || value.Value > 100) {
			return fmt.Errorf("RSI範囲不正")
		}
	}
	for _, value := range []frame.Value{t.ATR, t.PreviousATR, t.TR} {
		if value.Known && value.Value < 0 {
			return fmt.Errorf("値幅が負")
		}
	}
	for _, p := range []frame.Pivot{f.PriorHigh, f.PriorLow, f.NewHigh, f.NewLow} {
		if p.Known && (!finite(p.PublishedAt) || p.PublishedAt > s.AsOf || p.ConfirmEnd > p.PublishedAt) {
			return fmt.Errorf("pivotの未来公表/確認時計")
		}
	}
	return nil
}

// validate は候補集合とsnapshotの呼出契約を検査します。
//
// 引数: state(EntryState)、s(frame.Snapshot)、candidates([]Candidate)、policy(Policy)は純判定入力です。
// 返り値: errorは入力違反です。未知の指標自体をエラーとはしません。
func validate(state EntryState, s frame.Snapshot, candidates []Candidate, policy Policy) error {
	if policy != EntryE0 && policy != EntryE1 {
		return fmt.Errorf("入口政策はENTRY_E0/ENTRY_E1のみ")
	}
	if s.Session.ID == "" || s.Session.Contract == "" || !finite(s.Session.Start) || !finite(s.Session.End) || s.Session.End <= s.Session.Start || !finite(s.AsOf) || s.AsOf < s.Session.Start || s.AsOf > s.Session.End {
		return fmt.Errorf("場時計不正")
	}
	if s.HasObserved && (!finite(s.ReplayObservedAt) || s.ReplayObservedAt < s.AsOf) {
		return fmt.Errorf("観測前の要求snapshot")
	}
	if state.HasAt && s.AsOf < state.LastAt {
		return fmt.Errorf("入口時計逆順")
	}
	if state.HasSession && state.Session.ID == s.Session.ID && state.Session.Contract == s.Session.Contract && state.Session != s.Session {
		return fmt.Errorf("同じ場IDの時計改変")
	}
	seenWidths := map[int]bool{}
	for _, scale := range s.Scales {
		if scale.WidthSeconds != 300 && scale.WidthSeconds != 900 && scale.WidthSeconds != 1800 || seenWidths[scale.WidthSeconds] {
			return fmt.Errorf("三尺度の欠落/重複")
		}
		seenWidths[scale.WidthSeconds] = true
		if scale.HasCurrent {
			if !s.HasObserved || scale.SeedOnly {
				return fmt.Errorf("当場公表と数値種/未観測の矛盾")
			}
			if err := checkFrame(s, scale.Current, scale.WidthSeconds); err != nil {
				return err
			}
		}
	}
	if len(seenWidths) != 3 {
		return fmt.Errorf("三尺度が不足")
	}
	ids := map[string]bool{}
	for _, candidate := range candidates {
		if candidate.ID == "" || ids[candidate.ID] || candidate.Side != 1 && candidate.Side != -1 || candidate.Quantity <= 0 || candidate.At != s.AsOf || !finite(candidate.EntryQuote) || candidate.EntryQuote <= 0 {
			return fmt.Errorf("金融適格候補のID/方向/数量/時計/気配不正")
		}
		ids[candidate.ID] = true
	}
	return nil
}

// advance は同じ公表を二重更新せず、値copy内の場内構造を進めます。
//
// 引数: state(EntryState)、snapshot(frame.Snapshot)は元状態と今回の公開値です。
// 返り値: EntryState/errorは新状態、又は公表の逆順/同ID改変です。
func advance(state EntryState, snapshot frame.Snapshot) (EntryState, error) {
	next := state
	if !next.HasSession || next.Session.ID != snapshot.Session.ID || next.Session.Contract != snapshot.Session.Contract {
		next = EntryState{Session: snapshot.Session, HasSession: true, ResetReason: "場/限月が変わり構造を初期化"}
	}
	next.HasAt, next.LastAt = true, snapshot.AsOf
	newFive := false
	priceReset := false
	for i, width := range widths {
		scale, _ := snapshot.Scale(width)
		if !scale.HasCurrent {
			continue
		}
		f := scale.Current
		if next.HasLast[i] {
			old := next.Last[i]
			if old.ID == f.ID {
				if old != f {
					return state, fmt.Errorf("同じ公表IDの値が改変された:%s", f.ID)
				}
				continue
			}
			if f.End <= old.End {
				return state, fmt.Errorf("公表足の逆順/同区間別ID")
			}
			if old.End != f.Start {
				priceReset = true
			}
			if i == 0 {
				next.HasPreviousFive = old.PriceKnown && f.PriceKnown && old.End == f.Start
				next.PreviousFive = old
				if old.End != f.Start {
					priceReset = true
				}
			}
			if i == 1 {
				next.HasPreviousFifteen = old.PriceKnown && f.PriceKnown && old.End == f.Start
				next.PreviousFifteen = old
			}
		}
		next.Last[i], next.HasLast[i] = f, true
		if i == 0 {
			newFive = true
		}
		if !f.PriceKnown {
			priceReset = true
			if i == 0 {
				next.HasPreviousFive = false
			}
			if i == 1 {
				next.HasPreviousFifteen = false
			}
		}
	}
	if priceReset {
		next.Sides = [2]sideState{}
		next.ResetReason = "価格欠足又は5分公表の飛びで構造を初期化"
	}
	for i := range next.Sides {
		if next.Sides[i].T.Active && snapshot.AsOf >= next.Sides[i].T.ExpiresAt {
			retireT(&next.Sides[i], "順行setup期限切れ")
		}
		if next.Sides[i].R.Active && snapshot.AsOf >= next.Sides[i].R.ExpiresAt {
			retireR(&next.Sides[i], "反転setup期限切れ")
		}
	}
	if newFive && !priceReset {
		f := next.Last[0]
		scale, _ := snapshot.Scale(300)
		if f.PriceKnown && scale.Fresh && snapshot.AsOf-f.AvailableAt < 300 {
			for i, side := range [2]int{1, -1} {
				advanceSide(&next.Sides[i], next, f, side, snapshot.AsOf)
			}
		}
	}
	return next, nil
}
