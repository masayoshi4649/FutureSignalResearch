"""108の20分静観12口座を検算し、107の30分保存対照と実額で比較する。"""

import argparse
import ast
from collections import Counter
import copy
import hashlib
import importlib.util
import inspect
import json
import gzip
from pathlib import Path
import re
import textwrap
import types


ROOT = Path(__file__).resolve().parents[2]
PREVIOUS_PATH = ROOT / "work/107見送り繰越の保存準備/集計.py"
PREVIOUS_SHA = "edbc322ba619d7c575f8c1baec66d1dfcb7f210dbf685fbae7a90f81a6eaea6d"
if hashlib.sha256(PREVIOUS_PATH.read_bytes()).hexdigest() != PREVIOUS_SHA:
    raise ValueError("固定107保存器SHA差")
SPEC = importlib.util.spec_from_file_location("108が直接再用する固定107保存", PREVIOUS_PATH)
PREVIOUS = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PREVIOUS)
SAVED, OLD, BASE = PREVIOUS.SAVED, PREVIOUS.OLD, PREVIOUS.BASE
need, equal, digest, load = PREVIOUS.need, PREVIOUS.equal, PREVIOUS.digest, PREVIOUS.load
GROUPS = (("Q0", "B5QD", "W0"), ("Q1", "B5QD", "W1"), ("QE", "B5QD", "E1"))
CONFIGS = [{"candidate": p, "entry_timing": t, "protection_policy": w, "slip_pts": c,
            "delay_seconds": d, "quiet_seconds": 1200}
           for p, t, w in GROUPS for c in (0, 5) for d in (0, 1)]
KEYS = tuple(f"{c['candidate']}_C{c['slip_pts']}_D{c['delay_seconds']}" for c in CONFIGS)
BY_KEY = dict(zip(KEYS, CONFIGS))
E_KEYS = tuple(k for k in KEYS if k.startswith("QE_"))
CLOCK_PATH = ROOT / "work/静観長を指定する入口時計/assignment.go"
CLOCK_SHA = "d077c01bfc7345fe4360afe5b3a832e0d6d90f76e8675eb294a756de185560ff"
ACTIVITY = ("活動主表", "活動副表", "活動共通30主表", "活動共通30副表")


def constants_code(function, replacements, expected):
    """
    機能: 固定関数の指定定数だけを別code objectで置換する。
    引数: function(function)、replacements(dict)、expected(int)は旧関数・置換表・一致数。
    返り値: codeは数式と呼出順を維持した別版。元moduleは変更しない。
    """
    code = function.__code__
    indexes = [i for i, value in enumerate(code.co_consts) if type(value) in (int, str, tuple) and value in replacements]
    equal(len(indexes), expected, "固定codeの局所定数数")
    return code.replace(co_consts=tuple(replacements.get(v, v) if type(v) in (int, str, tuple) else v for v in code.co_consts))


def isolated(function, namespace, code=None):
    """
    機能: 旧関数本体を独立した名前空間で再用する。
    引数: function(function)、namespace(dict)、code(code|None)は旧本体・接続先・局所変更。
    返り値: functionは元のglobalsを書き換えない別関数。
    """
    return types.FunctionType(code or function.__code__, namespace, function.__name__, function.__defaults__, function.__closure__)


def participation_code():
    """
    機能: 旧参加関数の開始下端だけ1800秒から1200秒へ変える。
    引数: なし。旧103の固定participationを使用する。
    返り値: codeは副表のEnd−1800を維持する。US静観や欠測を除外しない。
    """
    tree = ast.parse(textwrap.dedent(inspect.getsource(OLD.participation)))
    count = 0
    for node in ast.walk(tree):
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add) and isinstance(node.left, ast.Call) and isinstance(node.right, ast.Constant) and node.right.value == 1800:
            equal(ast.unparse(node.left), "int(session['start'])", "参加下端の唯一箇所")
            node.right.value = 1200
            count += 1
    equal(count, 1, "参加下端だけ1箇所")
    namespace = {}
    exec(compile(ast.fix_missing_locations(tree), str(Path(__file__).resolve()) + ":参加下端", "exec"), namespace)
    return namespace["participation"].__code__


# ----------------------------------------
# 107の独立時計/quiet/所有検査を別名前空間へ置き、金融値やKeyを置換しない。
CLOCK_SPACE = dict(vars(PREVIOUS))
assignment_for = isolated(PREVIOUS.assignment_for, CLOCK_SPACE,
    constants_code(PREVIOUS.assignment_for, {1800: 1200, "セッション開始30分": "セッション開始20分", "米国開始30分": "米国開始20分"}, 3))
CLOCK_SPACE["assignment_for"] = assignment_for
assigned_at = isolated(PREVIOUS.assigned_at, CLOCK_SPACE)
CLOCK_SPACE["assigned_at"] = assigned_at
verify_clock = isolated(PREVIOUS.verify_clock, CLOCK_SPACE,
    constants_code(PREVIOUS.verify_clock, {"割当枠が開始30分見送り": "割当枠が開始20分見送り"}, 1))
GRID_SPACE = dict(PREVIOUS.GRID_SPACE)
for _name, _fn in PREVIOUS.GRID_SPACE.items():
    if isinstance(_fn, types.FunctionType) and _fn.__globals__ is PREVIOUS.GRID_SPACE:
        GRID_SPACE[_name] = isolated(_fn, GRID_SPACE)
GRID_SPACE["assigned_at"] = assigned_at
GRID_SPACE["verify_grid"] = isolated(PREVIOUS.GRID_SPACE["verify_grid"], GRID_SPACE,
    constants_code(PREVIOUS.GRID_SPACE["verify_grid"], {1800: 1200}, 1))
COMMON = PREVIOUS.COMMON
VERIFY_SPACE = {**vars(PREVIOUS), "BY_KEY": BY_KEY, "GRID_SPACE": GRID_SPACE, "COMMON": COMMON, "verify_clock": verify_clock}
verify_book = isolated(PREVIOUS.verify_book, VERIFY_SPACE)
PARTICIPATION20 = isolated(OLD.participation, vars(OLD), participation_code())
SUMMARY20 = isolated(OLD.summarize_book, {**vars(OLD), "participation": PARTICIPATION20})


def summarize_book(book, checked):
    """
    機能: 20分主副と旧30分共通観測枠を同じ20分実取引から数える。
    引数: book/checked(dict)は新20分の保存台帳。
    返り値: dictは旧算術の場別値。共通枠を30分の再運転と呼ばない。
    """
    row = SUMMARY20(book, checked)
    row["活動共通30主表"] = OLD.participation(book, checked)
    row["活動共通30副表"] = OLD.participation(book, checked, "end30")
    return row


ROW_OLD = types.SimpleNamespace(**{**vars(OLD), "summarize_book": summarize_book})
scene_rows = isolated(PREVIOUS.scene_rows, {**vars(PREVIOUS), "BY_KEY": BY_KEY, "OLD": ROW_OLD})
COMBINE_ALL = isolated(OLD.combine, vars(OLD), constants_code(OLD.combine, {("活動主表", "活動副表"): ACTIVITY}, 1))
combine = isolated(PREVIOUS.combine, {**vars(PREVIOUS), "OLD": types.SimpleNamespace(combine=COMBINE_ALL)})


def aggregate(rows, stage=None):
    """
    機能: 新12設定の主副/共通30分母と日夜・日別・履歴を集約する。
    引数: rows(list[dict])、stage(str|None)は場別統計と正式集合指定。
    返り値: tuple[dict,dict]は集計と実現診断。場別counts-onlyを許容する。
    """
    summary, diagnosis = {}, {}
    for key in KEYS:
        selected = [r for r in rows if r["key"] == key]
        need(bool(selected), "12集計の欠落")
        summary[key] = combine(selected)
        if stage is not None:
            expected = (7980, 7700, 7840, 7560) if stage == "full70" else (228, 220, 224, 216)
            need(stage in ("first2", "full70"), "正式stage")
            for name, denom in zip(ACTIVITY, expected):
                equal(summary[key][name]["denom"], denom, "20分/共通30予定分母:" + name)
        dates = sorted({r["session"][:10] for r in selected})
        diagnosis[key] = {"日夜": {k: combine([r for r in selected if r["session"].endswith("_" + k)]) for k in ("Day", "Night")},
                          "日別": [{"開始日": d, **combine([r for r in selected if r["session"].startswith(d)])} for d in dates],
                          "履歴区分": {h: combine([r for r in selected if r["history_class"] == h]) for h in sorted({r["history_class"] for r in selected})}}
    return summary, diagnosis


def inspect_scene(value, registry=None, full_clock=False, artificial=False):
    """
    機能: 新20分12実名口座を共通保存会計と1200秒clockで検算する。
    引数: value(dict)、registry、full_clock/artificial(bool)はCore108と検査範囲。
    返り値: dictは12冊の検算済み台帳。旧30との同体は要求しない。
    """
    need(value["version"] == 1 and value["trial"] == 108 and value["complete"] is True, "108完結")
    for name in ("books", "width_audits", "clock_audits"):
        equal(set(value[name]), set(KEYS), "新12集合:" + name)
    equal(set(value["early_audits"]), set(E_KEYS), "新E audit4")
    equal(value["configs"], CONFIGS, "20分12設定")
    need(value["tape_unchanged"] is True and value["source_reexecuted"] is False and value["bank_recomputed"] is False and value["charts_recomputed"] is False and value["cmp_recomputed"] is True, "保存再用の責務")
    checked = {}
    for key in KEYS:
        equal(value["books"][key]["session"], value["session"], "同一場")
        checked[key] = verify_book(value["books"][key], key, value["width_audits"][key], value["early_audits"].get(key), value["clock_audits"][key], value["contract"], registry, full_clock)
        equal([g["at"] for g in value["books"][key]["grid_traces"]], value["grid_times"], "同じ観測grid")
        a, b = value["width_audits"][key], value["width_audits"][KEYS[0]]
        equal((a["observations"], a["resets"]), (b["observations"], b["resets"]), "同公表配送")
    equal(len(value["grid_times"]), value["counts"]["grids"], "全grid数")
    p = value["prior_reference"]
    equal((p["kind"], p["quiet_seconds"], p["books"], p["width_audits"], p["early_audits"]), ("provided_old107_q30", 1800, 12, 12, 4), "旧Q30は保存参照12/12/4")
    equal(p["history_class"], "artificial" if artificial else "old_saved_70", "旧参照scope")
    need("all" not in p, "新20と旧30の同体flag禁止")
    for field, keys in (("book_full_json_sha256", KEYS), ("width_full_json_sha256", KEYS), ("early_full_json_sha256", E_KEYS)):
        equal(set(p[field]), set(keys), "旧全JSON SHA集合")
        need(all(SAVED.sha_valid(x) for x in p[field].values()), "旧全JSON SHA型")
    equal(p["tape_canonical_sha256"], value["tape_canonical_sha256"], "同一固定Tape")
    if registry is not None:
        a = value["width_audits"][KEYS[0]]
        equal((a["observations"], a["resets"]), (registry.observations, registry.resets), "公表件数")
        equal(value["counts"], registry.counts, "全record件数")
        equal({k: v for k, v in value["public_diagnostics"].items() if k != "numeric_seed_carried"}, registry.diagnostics, "一公表役割診断")
    return checked


def inspect_prior(value, registry=None, full_clock=False):
    """
    機能: 旧107のQ30必要12冊だけを旧107規範へ原値のまま渡す。
    引数: value(dict)、registry、full_clock(bool)は固定旧Nativeと保存公表。
    返り値: dictは旧30分の独立した保存検算台帳。新20へ転記しない。
    """
    need(value["version"] == 1 and value["trial"] == 107 and value["complete"] is True, "旧107完結")
    return {k: PREVIOUS.verify_book(value["books"][k], k, value["width_audits"][k], value["early_audits"].get(k), value["clock_audits"][k], value["contract"], registry, full_clock) for k in KEYS}


def registry_for_pair(records, new, prior):
    """
    機能: 新旧それぞれの保存markに必要な公表状態を一回の読戻しで得る。
    引数: records(iterable)、new/prior(dict)は同じ公表列と別20/30分結果。
    返り値: PublicationRegistryは新旧両方の必要時計を保持する。金融値は変更しない。
    """
    combined = {**new, "books": {**{"20:" + k: new["books"][k] for k in KEYS}, **{"30:" + k: prior["books"][k] for k in KEYS}},
                "width_audits": {**{"20:" + k: new["width_audits"][k] for k in KEYS}, **{"30:" + k: prior["width_audits"][k] for k in KEYS}}}
    return SAVED.registry_from_records(records, combined)


def compare_scene(new, prior):
    """
    機能: 静観長差12と20分内保護差12を実入口の全属性で加法分解する。
    引数: new/prior(dict)は新20/旧30の別検算台帳。
    返り値: dictは24実額比較。片側未参加へ仮想損益を作らない。
    """
    result = {"20分_" + k + "対30分_" + k: {"区分": "静観長", **OLD.compare_positions(prior[k], new[k])} for k in KEYS}
    for a, b in (("Q0", "Q1"), ("Q0", "QE"), ("Q1", "QE")):
        for c in (0, 5):
            for d in (0, 1):
                before, after = f"{a}_C{c}_D{d}", f"{b}_C{c}_D{d}"
                result["20分_" + after + "対20分_" + before] = {"区分": "20分内保護", **OLD.compare_positions(new[before], new[after])}
    equal(len(result), 24, "全24比較")
    return result


def save_viewer(value, output, market_path):
    """
    機能: 旧Viewer算術の実Fillだけを108 namespaceへ保存する。
    引数: value(dict)、output(Path)、market_path(str)は新Native・新規先・原板参照名。
    返り値: list[dict]はschema1の12資源。HTTPや原板読取は行わない。
    """
    resources, sid = [], value["session"]["id"]
    for key in KEYS:
        name = f"108_{key}_{sid}.trades.jsonl"
        with (output / name).open("x", encoding="utf-8", newline="\n") as stream:
            for row in BASE.viewer_trades(value["books"][key]):
                stream.write(json.dumps(row, ensure_ascii=False, default=BASE.serial, allow_nan=False) + "\n")
        resources.append({"id": f"108_{key}_{sid}", "title": f"開始静観20分と利益保護 {key} {sid}", "symbol": "NK225", "product": "NK225mini", "session": sid, "method_id": key,
                          "point_value": 100, "pnl_format": "trades", "pnl_basis": "net", "pnl_path": name, "market_path": market_path})
    return resources


def raw_members(text):
    """
    機能: 標準JSON decoderの終端位置からobject各値の元字句範囲を得る。
    引数: text(str)は認証後の単一JSON object。
    返り値: dict[str,str]は数値lexeme/未知field/順序を保持する値部分。
    """
    decoder = json.JSONDecoder()
    at = len(text) - len(text.lstrip())
    need(text[at] == "{", "Raw object")
    at += 1
    result = {}
    while True:
        while text[at].isspace():
            at += 1
        if text[at] == "}":
            return result
        key, at = json.decoder.scanstring(text, at + 1, True)
        need(key not in result, "Raw key重複")
        while text[at].isspace():
            at += 1
        need(text[at] == ":", "Raw colon")
        at += 1
        while text[at].isspace():
            at += 1
        _, end = decoder.raw_decode(text, at)
        result[key] = text[at:end]
        at = end
        while text[at].isspace():
            at += 1
        if text[at] == "}":
            return result
        need(text[at] == ",", "Raw comma")
        at += 1


def raw_go_sha(text):
    """
    機能: 元JSON値をGo RawMessageのMarshal同様にcompact/HTMLescapeして指紋化する。
    引数: text(str)は構文確認済みの元値字句。数値を再表現しない。
    返り値: strは全fieldのSHA256。文字列内空白・既存escapeは保持する。
    """
    def token(match):
        """
        機能: 文字列tokenはGo標準escapeへ、文字列外空白は空文字へ写す。
        引数: match(re.Match)はJSON文字列又は字句間空白。
        返り値: strは意味値を再生成しないcompact token。
        """
        value = match.group()
        if not value.startswith('"'):
            return ""
        for char, escaped in (("&", "\\u0026"), ("<", "\\u003c"), (">", "\\u003e"), ("\u2028", "\\u2028"), ("\u2029", "\\u2029")):
            value = value.replace(char, escaped)
        return value
    compact = re.sub(r'"(?:[^"\\]|\\.)*"|[ \t\r\n]+', token, text)
    return hashlib.sha256(compact.encode("utf-8")).hexdigest()


def prior_sha_tables(path, artificial=False):
    """
    機能: 旧Nativeの必要Q30全JSON指紋を元字句から取得する。
    引数: path(Path)、artificial(bool)は固定旧Native又はtop.outputを持つ手製器具。
    返り値: dictはBook12/幅12/早期4のGo RawMessage同等SHA。
    """
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as stream:
        text = stream.read()
    if artificial:
        text = raw_members(text)["output"]
    top = raw_members(text)
    return {name: {k: raw_go_sha(v) for k, v in raw_members(top[field]).items() if k in keys}
            for field, name, keys in (("books", "book_full_json_sha256", KEYS), ("width_audits", "width_full_json_sha256", KEYS), ("early_audits", "early_full_json_sha256", E_KEYS))}


def verify_prior_reference(new, prior, path, expected_sha, artificial=False):
    """
    機能: 旧30分保存参照を実物・Session/Tape・元字句全JSON SHAへ結ぶ。
    引数: new/prior(dict)、path(Path)、expected_sha(str)、artificial(bool)は別新旧値と固定参照。
    返り値: dictは保存参照の検算記録。新20との同体flagを作らない。
    """
    p = new["prior_reference"]
    equal((Path(p["reference_path"]).resolve(), p["reference_sha256"]), (path.resolve(), expected_sha), "旧107正式参照")
    equal(digest(path), expected_sha, "旧参照実物SHA")
    equal((new["session"], new["contract"], new["tape_canonical_sha256"]), (prior["session"], prior["contract"], prior["tape_canonical_sha256"]), "同場/限月/固定Tape")
    for name, table in prior_sha_tables(path, artificial).items():
        equal(p[name], table, "旧全JSON SHA原値:" + name)
    return {"session": new["session"]["id"], "静観秒": 1800, "保存検算会計": 12,
            "reference_path": str(path.resolve()), "reference_sha256": expected_sha,
            "全JSON_SHA結合": True, "旧30の再金融": False, "新20との同体照合": False}


def validate_completion(condition, complete, manifest, stage, condition_sha):
    """
    機能: 同条件・完全70/先頭2集合と全12金融成功を本文前に確認する。
    引数: condition/complete/manifest(dict)、stage/condition_sha(str)はRoot固定metadata。
    返り値: list[dict]は新Native参照。架空の別engine監査を要求しない。
    """
    need(stage in ("first2", "full70"), "108 stage")
    n = 2 if stage == "first2" else 70
    need(condition["version"] == 1 and condition["trial"] == 108 and condition["fixed"] is True, "108事前条件")
    equal(condition["source_scope"], "recorded_public_106", "保存入力再用")
    equal(condition["configs"], CONFIGS, "108新12設定")
    ids = [s["id"] for s in manifest["sessions"]]
    need(len(ids) == len(set(ids)) == 70 and ids == sorted(ids), "同70時系列")
    need(complete["version"] == 1 and complete["trial"] == 108 and complete["stage"] == stage and complete["success"] is True and not complete.get("error"), "108金融成功")
    equal(complete["condition_sha256"], condition_sha, "同条件")
    equal((complete["sessions"], complete["books_per_scene"], complete["books"]), (n, 12, n*12), "新12金融数")
    need(complete["unchanged"] is True and bool(complete["before"]) and complete["before"] == complete["after"], "金融入力code不変")
    equal(complete["source_scope"], condition["source_scope"], "保存入力scope")
    for name, expected in (("source_reexecuted", False), ("features_recomputed", False), ("charts_recomputed", False), ("bank_recomputed", False), ("cmp_recomputed", True), ("financial_executed", True)):
        need(complete[name] is expected, "金融責務:" + name)
    tasks = complete["results"]
    equal([r["session"] for r in tasks], ids[:n], "対象場の完全集合/順序")
    for row in tasks:
        need(row["books"] == 12 and row["prior_reference_books"] == 12 and row["prior_reference_unchanged"] is True and not row.get("error"), "新12と旧保存参照12")
        for name in ("native", "sidecar_header", "sidecar_records", "prior_native"):
            SAVED.ref_shape(row[name])
    return tasks


def prepare(fixed_path, fixed_sha, output):
    """
    機能: 最小固定3参照と106保存入力/107保存対照を分離して認証する。
    引数: fixed_path/output(Path)、fixed_sha(str)はRoot事後固定と未使用出力先。
    返り値: tupleは対象task・前指紋・証拠・完了・条件。原板本文は開かない。
    """
    need(not output.exists() and SAVED.sha_valid(fixed_sha) and digest(fixed_path) == fixed_sha, "Root固定/新規先")
    fixed = load(fixed_path)
    need(set(fixed) == {"version", "trial", "fixed", "stage", "condition", "completion", "code"} and fixed["version"] == 1 and fixed["trial"] == 108 and fixed["fixed"] is True, "108最小固定")
    before = {str(fixed_path): fixed_sha}
    paths = {k: SAVED.bind_ref(fixed[k], fixed_path.parent, before) for k in ("condition", "completion", "code")}
    equal(paths["code"], Path(__file__).resolve(), "実保存器固定")
    condition, complete = load(paths["condition"]), load(paths["completion"])
    need(condition["fixed"] is True and condition["trial"] == 108 and complete["success"] is True, "未成功を本文前拒否")
    base = paths["condition"].parent
    refs = {k: SAVED.bind_ref(condition[k], base, before) for k in ("source_manifest", "source_corpus", "source_completion", "prior_closure", "prior_completion", "prior_native_index", "binary")}
    for ref in condition["stops"] + condition["specifications"]:
        SAVED.bind_ref(ref, base, before)
    manifest, source, prior, index = (load(refs[k]) for k in ("source_manifest", "source_completion", "prior_completion", "prior_native_index"))
    tasks = validate_completion(condition, complete, manifest, fixed["stage"], fixed["condition"]["sha256"])
    ids = [s["id"] for s in manifest["sessions"]]
    for value, trial in ((source, 106), (prior, 107)):
        need(value["trial"] == trial and value["stage"] == "full70" and value["success"] is True and value["sessions"] == 70 and value["unchanged"] is True and value["before"] == value["after"], "完成保存入力と旧参照の別責務")
        equal([r["session"] for r in value["results"]], ids, "同70順序")
    need(index["成功"] is True and index["試行"] == 107 and index["基準"] == "trialdir" and index["場数"] == 70 and index["金融会計"] == 1680, "正式107 Native参照台帳")
    equal([r["session"] for r in index["Native"]], ids, "正式旧70集合")
    equal(index["元金融完了"]["sha256"], condition["prior_completion"]["sha256"], "旧107完成80faf由来")
    for name, expected in list(before.items()):
        if name not in (str(fixed_path), str(paths["completion"]), str(paths["code"])):
            equal(complete["before"].get(name), expected, "金融使用の固定参照")
    for name, expected in condition["code_sha256"].items():
        p = (base / name).resolve()
        equal(digest(p), expected, "金融固定code")
        equal(complete["before"].get(str(p)), expected, "金融使用code")
        before[str(p)] = expected
    corpus = load(refs["source_corpus"])
    equal([s["session"] for s in corpus["scenes"]], ids, "SourceCorpus同70集合")
    data_root = (refs["source_manifest"].parent / manifest["source_root"]).resolve()
    index_root = refs["prior_native_index"].parent.parent
    resolved = []
    for i, row in enumerate(tasks):
        r = {k: SAVED.bind_ref(row[k], paths["completion"].parent, before) for k in ("native", "sidecar_header", "sidecar_records", "prior_native")}
        saved, old, old_ref = source["results"][i], prior["results"][i], index["Native"][i]
        need(old_ref["会計"] == 24 and old_ref["同bytes"] is True, "正式旧Native全文")
        p = (index_root / old_ref["path"]).resolve()
        equal((r["prior_native"], row["prior_native"]["sha256"]), (p, old_ref["sha256"]), "正式107参照原値")
        equal(old_ref["sha256"], old["native"]["sha256"], "完成107との同bytes")
        source_native = SAVED.bind_ref(saved["native"], refs["source_completion"].parent, before)
        for k in ("sidecar_header", "sidecar_records"):
            expected = (refs["source_completion"].parent / saved[k]["path"]).resolve()
            equal((r[k], row[k]["sha256"]), (expected, saved[k]["sha256"]), "106の公表原値")
            equal(saved[k]["sha256"], old[k]["sha256"], "107も同じ保存公表")
        m = manifest["sessions"][i]
        market = (data_root / m["files"]["NK225_book"]["path"]).resolve()
        resolved.append({**row, "resolved": r, "source_native": source_native, "source_native_ref": saved["native"],
                         "input": m, "history_class": corpus["scenes"][i]["kind"], "market_path": str(market)})
    if fixed["stage"] == "full70":
        first_path = SAVED.bind_ref(complete["first2"], paths["completion"].parent, before)
        first = load(first_path)
        validate_completion(condition, first, manifest, "first2", fixed["condition"]["sha256"])
        for i in range(2):
            for k in ("native", "sidecar_header", "sidecar_records", "prior_native"):
                equal(first["results"][i][k]["sha256"], tasks[i][k]["sha256"], "先頭2→同全70の指紋")
    for module in (PREVIOUS, SAVED, SAVED.PREVIOUS, SAVED.PREVIOUS.BASE, OLD, PREVIOUS.GRID, BASE, SAVED.PUBLIC, SAVED.PUBLIC.pure):
        p = Path(module.__file__).resolve()
        before[str(p)] = digest(p)
    equal(digest(CLOCK_PATH), CLOCK_SHA, "時計108の固定参照")
    before[str(CLOCK_PATH)] = CLOCK_SHA
    proofs = {"Root固定SHA256": fixed_sha, **{k + "SHA256": fixed[k]["sha256"] for k in paths}}
    return resolved, before, proofs, complete, condition


def verify_envelope(value, header, task, completion):
    """
    機能: 106公表の再読由来と107旧参照と108金融を混ぜず結ぶ。
    引数: value/header/task/completion(dict)は認証済み新保存値と各参照。
    返り値: None。Source/Bank再形成又は旧30再金融を主張しない。
    """
    equal(value["condition_sha256"], completion["condition_sha256"], "Native108条件")
    equal((value["session"]["id"], value["contract"]), (task["session"], task["input"]["contract"]), "場/限月")
    p, replay = value["input_proof"], value["replay_proof"]
    equal(p["scene_id"], task["session"], "保存入力場")
    equal((Path(p["expected_native"]["path"]).resolve(), p["expected_native"]["sha256"]), (task["source_native"], task["source_native_ref"]["sha256"]), "106保存入力の期待Native")
    equal(p["tape_canonical_sha256"], value["tape_canonical_sha256"], "元SourceTape")
    need(p["source_reexecuted"] is False and p["bank_recomputed"] is False and p["financial_executed"] is False, "reader範囲")
    need(replay["unchanged"] is True and replay["before"] == replay["after"] and bool(replay["before"]), "読戻し前後不変")
    equal(value["provenance"], {"source_scope": "recorded_public_106", "cmp_recomputed": True, "charts_recomputed": False, "raw_market_read": False, "source_reexecuted": False, "bank_recomputed": False, "financial_executed": True}, "108金融/形成範囲")
    need(header["version"] == 1 and header["trial"] == 106, "元106Header")
    equal(header["records_gzip_sha256"], task["sidecar_records"]["sha256"], "元records")
    equal((header["header"]["scene"]["id"], header["header"]["scene"]["contract"]), (task["session"], value["contract"]), "Header場限月")


def generate(fixed_path, fixed_sha, output):
    """
    機能: Root市場成功後だけ新12/旧参照12の保存検算と24実額比較を生成する。
    引数: fixed_path/output(Path)、fixed_sha(str)は固定3参照と新規保存先。
    返り値: dictは保存件数。市場の別engine再生や機会損失算出は行わない。
    """
    tasks, before, proofs, complete, condition = prepare(fixed_path, fixed_sha, output)
    output.mkdir(parents=True)
    rows, prior_rows, resources, controls, public_rows, refs, comparisons = [], [], [], [], [], [], {}
    prior_row_fn = isolated(PREVIOUS.scene_rows, {**vars(PREVIOUS), "BY_KEY": {k: PREVIOUS.BY_KEY[k] for k in KEYS}})
    prior_aggregate = isolated(PREVIOUS.aggregate, {**vars(PREVIOUS), "KEYS": KEYS})
    for task in tasks:
        v, h = load(task["resolved"]["native"]), load(task["resolved"]["sidecar_header"])
        verify_envelope(v, h, task, complete)
        old = load(task["resolved"]["prior_native"])
        registry = registry_for_pair(SAVED.read_records(task["resolved"]["sidecar_records"]), v, old)
        checked = inspect_scene(v, registry, True)
        prior_checked = inspect_prior(old, registry, True)
        controls.append(verify_prior_reference(v, old, task["resolved"]["prior_native"], task["prior_native"]["sha256"]))
        rows.extend(scene_rows(v, checked, task["history_class"]))
        prior_rows.extend(prior_row_fn(old, prior_checked, task["history_class"]))
        resources.extend(save_viewer(v, output, task["market_path"]))
        for name, comp in compare_scene(checked, prior_checked).items():
            comparisons.setdefault(name, {"区分": comp["区分"], "場別": []})["場別"].append({"session": task["session"], **{k: x for k, x in comp.items() if k != "区分"}})
        refs.append({k: task[k] for k in ("session", "native", "sidecar_header", "sidecar_records", "prior_native")})
        public_rows.append({"session": task["session"], **v["public_diagnostics"]})
    summary, diagnosis = aggregate(rows, complete["stage"])
    old_summary, old_diagnosis = prior_aggregate(prior_rows, complete["stage"])
    for item in comparisons.values():
        total = Counter()
        for row in item["場別"]:
            total.update({k: x for k, x in row.items() if k != "session"})
        item["合計"] = dict(total)
        equal(total["全差額"], total["同実入口差額"] + total["取得変更差額"] - total["前のみ実現額"] + total["後のみ実現額"], "実額加法分解")
    after = {name: digest(Path(name)) for name in before}
    equal(after, before, "入力code前後不変")
    scope = "新20分12の保存会計/所有/費用/MTM・DD/幅/起動/時計と旧30分Q12保存再検算。全quote別engine金融再生ではない"
    result = {"試行": 108, "成功": True, **proofs, "stage": complete["stage"], "scope": scope,
              "場数": len(tasks), "会計数": len(tasks)*12, "旧30保存検算会計数": len(tasks)*12, "主key": list(KEYS),
              "Actor設定": {k: {**c, "内Key": PREVIOUS.inner_key(k), "入口": "Gate無し", "基本保護": "P0", "起動": "E1" if c["protection_policy"] == "E1" else "LD10"} for k, c in BY_KEY.items()},
              "集計": summary, "実現診断": diagnosis, "場別": rows,
              "30分保存対照": {"集計": old_summary, "実現診断": old_diagnosis, "場別": prior_rows, "再金融": False},
              "同実入口と実現額差": comparisons, "比較数": 24, "静観長比較": 12, "20分内保護比較": 12,
              "旧107Q30保存参照": controls, "一公表単位の役割診断": public_rows, "Native参照": refs, "Viewer形式資源": len(resources), "実Viewer通信": 0,
              "入力codeSHA256前": before, "入力codeSHA256後": after, "前後不変": True,
              "未実施": ["Raw/CSV/Source/Bank再形成", "全quote別engine金融再生", "旧30再金融", "未参加/退出後価格/機会損失/MFE", "実ViewerAPI"]}
    BASE.write_json(output / "結果.json", result)
    BASE.write_json(output / "一覧.resources.json", {"schema_version": 1, "path_base": "catalog", "resources": resources})
    outputs = {p.name: digest(p) for p in output.iterdir() if p.is_file()}
    BASE.write_json(output / "保存会計の確認.json", {"成功": True, **proofs, "scope": scope, "会計": len(tasks)*12, "旧保存検算": len(tasks)*12, "資源": len(resources), "不一致数": 0,
                    "入力codeSHA256前": before, "入力codeSHA256後": after, "前後不変": True, "出力SHA256": outputs, "Raw/CSV/Source/金融/HTTP再実行": 0})
    return {"成功": True, "場数": len(tasks), "会計": len(tasks)*12, "旧保存検算": len(tasks)*12, "実Viewer通信": 0}


def main():
    """
    機能: Root固定3FileRefがある場合だけ108保存CLIを実行する。
    引数: --fixed/--fixed-sha/--outは固定JSON・SHAと新規保存先。
    返り値: None。未固定又は金融未成功はNative本文より前に拒否する。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixed", type=Path, required=True)
    parser.add_argument("--fixed-sha", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(generate(args.fixed.resolve(), args.fixed_sha, args.out.resolve()), ensure_ascii=False))


if __name__ == "__main__":
    main()
