"""166の固定主案を、まだ価格を読んでいない追加七場へ適用する条件を保存する。"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00167_固定した複合入口を追加七場へ適用する'


def reference(path: Path) -> dict:
    """
    機能: 固定済みSource又は検査票の位置と指紋を記録する。
    引数: path(Path)は既使用領域のファイル。
    返り値: dictは相対path/bytes/SHA256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,
        'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 二つの既固定候補・対照幅・対象期間を新価格参照前に固定する。
    引数: なし。166条件と既使用結果及び停止済み部品を読む。
    返り値: None。167条件、未実行README、価格未読宣言を保存する。
    """
    assert not TRIAL.exists()
    assert max(int(p.name[:5]) for p in (ROOT/'study').iterdir() if p.is_dir() and p.name[:5].isdigit())==166
    parent=ROOT/'study/00166_未公表の長期指標を捏造せず局所技術で参加を補う/条件.json'
    result=ROOT/'work/166可用指標の階層化/比較/主案と探索結果.json'
    report=json.loads(result.read_text(encoding='utf-8'))
    paths=[parent,result,ROOT/'work/166可用指標の階層化/local166.py',
        ROOT/'work/165順行と回復失敗の複合/出生を作る.py',
        ROOT/'work/165順行と回復失敗の複合/評価基盤165.py',ROOT/'work/162入口探索/評価基盤.py',
        ROOT/'work/162複合入口候補/rules162.py',
        ROOT/'work/未見入口の同体接続/接続器の停止.json',
        ROOT/'work/166可変場の観測/可変場観測の停止.json',
        ROOT/'work/166可変場の数値化/数値化の停止.json']
    scenes=['2026-11-10_Night','2026-11-11_Day','2026-11-11_Night','2026-11-12_Day',
        '2026-11-12_Night','2026-11-13_Day','2026-11-13_Night']
    candidates=[]
    for name,key in [('PRIMARY','事前固定主案'),('FRONT48','前48場だけで選択')]:
        choice=report[key];assert choice is not None
        candidates.append({'id':name,**{k:choice[k] for k in
            ('profile','hierarchy','momentum_width','fade_width','horizon','integration')},
            'scope':'PRIMARYは166実行前固定主案、FRONT48は前48場のみの固定選択。両者とも旧73場は既使用。'})
    setting={'trial':167,'date':'2026-11-15','name':'固定した複合入口を追加七場へ適用する',
        'hypothesis':'既使用73場で発見した複合入口を変えずに追加期間へ適用し、頻度・参加・先着・利益損失の持続を確認する。',
        'scenes':scenes,'input_root':'../JP_OSE_Data/future/NK225','candidates':candidates,
        'prices_unread_at_lock':True,'history_through':'2026-11-10_Day',
        'history':'旧73場の予定Endまで公開器とBB/RVOLを正規再生する。保存SeedInfoから私有数値種を捏造しない。',
        'source_references':{p.relative_to(ROOT).as_posix():reference(p) for p in paths},
        'population':'旧148の全1分知得q0/取得q1を未改変で使う。全対象場と未知/取消/取得0場を保持する。新C1参照が無いのでU/Fを名乗らない。',
        'entry':'MPの順行とEX反転を165と同じ式で合成。旧Tと局所階層、主未決なし/未取得時だけ初参加補完も同体。高得点側だけを採用し買売対称。',
        'timeband':'q0をDAY/NY09:30前/以後DST変換。q1分類も併記し、境界決済や各帯強制参加を加えない。',
        'exit':'取得枝の幅をq0で固定する対称IFD、期限未到達は期限BBO。欠測前の既知touchをIFD_FIRSTで保持する。',
        'width_controls':[125,150,175,200,225,250,300,350,400,500,750,1000],
        'width_control_interpretation':'主案と全く同じ取得集合で全枝を同一幅へした事前対照。結果を見て主案を交換しない。125/250固定の最適化ではない。',
        'cost':{'point_yen':100,'fee_round_trip':77,'additional_round_trip_slippage_yen':1000},
        'account':'各入口独立mini1枚の品質と金額。片側上限10枚の口座運用とは分ける。',
        'report':'全七場、q0/q1三帯、主枝/旧T/局所、買売、未知と未到達、全取得分母と到達済み率、費用後利益損失、前73場と追加七場を混同しない。',
        'adoption':'追加七場の結果を見て本試行内で閾値を調整しない。未達なら原因と次仮説を別試行へ。少数期間の高率を統計保証としない。',
        'unchanged':'153の一旦達成と旧固定試行、166事前主案/前半選択/全期探索の区別を保つ。'}
    TRIAL.mkdir();(TRIAL/'検査').mkdir()
    path=TRIAL/'条件.json';path.write_text(json.dumps(setting,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (TRIAL/'README.md').write_text('# 00167 固定した複合入口を追加七場へ適用する\n\n2026-11-15。[条件](条件.json)を追加七場の価格参照前に固定した。166事前主案と前48場選択を変更せず適用する。現在未実行。原板・CSVは本条件固定後に指紋と前後statを確認し、停止済み接続器で取得母集団を生成する。\n',encoding='utf-8')
    (TRIAL/'検査/F0_追加価格参照前.json').write_text(json.dumps({'成功':True,'条件':reference(path),
        '追加七場価格未読':True,'Source':reference(Path(__file__))},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'条件':reference(path)},ensure_ascii=False))


if __name__=='__main__':
    main()
