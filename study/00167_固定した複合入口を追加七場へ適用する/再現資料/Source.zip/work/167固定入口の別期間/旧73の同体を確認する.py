"""可変場適用基盤の旧73場での全方向・取得・金融同体を確認する。"""
from pathlib import Path
import numpy as np
from 適用基盤167 import ROOT,Context165,GenericContext,births,selection,statistics,read,sha
from 共通163 import save


def main() -> None:
    """
    機能: 追加価格を読まず二つの固定候補を旧166正本と同体比較する。
    引数: なし。既使用73場だけの特徴・取得・金融・出生を入力とする。
    返り値: None。Source固定と全方向・全取得・三期間金融指標の検査票を保存する。
    """
    here=Path(__file__).resolve().parent;out=here/'旧73の同体.json';assert not out.exists()
    setting=read(ROOT/'study/00167_固定した複合入口を追加七場へ適用する/条件.json')
    before={p.name:sha(p) for p in (here/'適用基盤167.py',Path(__file__))}
    old=Context165();context=GenericContext(old.features,old.table,old.capture_rows)
    proof=read(ROOT/'work/166可用指標の階層化/全出生/全出生の確認.json')
    refs=read(ROOT/'work/166可用指標の階層化/比較/全取得参照.json.gz')['rows']
    report=read(ROOT/'work/166可用指標の階層化/比較/主案と探索結果.json')
    tests=[]
    with (np.load(ROOT/'work/166可用指標の階層化/全出生/階層化の出生.npz',allow_pickle=False) as born,
        np.load(ROOT/'work/166可用指標の階層化/比較/階層化入口の統計配列.npz',allow_pickle=False) as metrics):
        for candidate,key in zip(setting['candidates'],('事前固定主案','前48場だけで選択'),strict=True):
            pi,li,mi,fi,hi,ti=report[key]['position'];birth=births(context.features,candidate)
            for name,expected in [('core',born['directions'][pi]),('branches',born['branches'][pi]),
                ('technical',born['technical'][li,ti]),('tier',born['technical_tier'][li,ti]),
                ('oldtechnical',born['oldtechnical'][ti]),('local',born['local_directions'][li]),
                ('local_eligible',born['local_eligible'][li])]:
                assert np.array_equal(birth[name],expected),name
            selected,origins,widths,tiers,audits=selection(context,birth,candidate)
            reference=next(r for r in refs if r['profile']==candidate['profile']['id'] and
                r['hierarchy']==candidate['hierarchy']['id'] and r['integration']==candidate['integration'])
            for name,actual in [('cases',selected.cases),('sides',selected.sides),('events',selected.events),
                ('origins',origins),('tiers',tiers)]:
                assert actual.tolist()==reference[name],name
            financial_checks=0
            for period in range(3):
                eligible=np.ones(len(context.scenes),dtype=bool)
                if period==1:eligible[48:]=False
                if period==2:eligible[:48]=False
                value=statistics(context,selected,widths,hi,eligible[context.case_scene[selected.cases]],eligible)
                expected=metrics['metrics'][pi,li,mi,fi,hi,ti,period]
                fields=read(ROOT/'work/166可用指標の階層化/比較/統計軸.json')['fields']
                for name in value:
                    if name not in fields:continue
                    got=value[name];want=expected[fields.index(name)]
                    if got is None:assert np.isnan(want),(name,want)
                    else:assert got==want,(name,got,want)
                    financial_checks+=1
            tests.append({'id':candidate['id'],'全方向列':7,'全q0':len(birth['core']),
                '取得':len(selected.cases),'三期間金融比較欄':financial_checks,'全同体':True})
    assert all(sha(here/p)==v for p,v in before.items())
    save(out,{'成功':True,'追加七場価格未読':True,'Source':before,'確認':tests})
    print(__import__('json').dumps({'成功':True,'確認':tests},ensure_ascii=False))


if __name__=='__main__':
    main()
