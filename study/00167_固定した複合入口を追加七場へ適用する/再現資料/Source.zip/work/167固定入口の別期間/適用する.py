"""固定した二入口を追加期間へ変更せず適用し、同じ取得で対照幅も比較する。"""
from pathlib import Path
import argparse
import json
import numpy as np
from 適用基盤167 import ROOT,load_features,births,GenericContext,selection,statistics,read,sha,module
from 共通163 import save

HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00167_固定した複合入口を追加七場へ適用する'
BOOK_SHA='73e16eabfc3364a9e038d9697472abe50bb91fbba49b488dd0c8ed8d5eaea9f4'


def locked() -> dict:
    """
    機能: 対象と固定候補・旧73同体・全親Sourceの指紋を検査する。
    引数: なし。
    返り値: dictは167の固定条件。
    """
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    setting=read(TRIAL/'条件.json')
    assert read(HERE/'旧73の同体.json')['成功']
    assert read(HERE/'旧73の同体.json')['Source']['適用基盤167.py']==sha(HERE/'適用基盤167.py')
    for ref in setting['source_references'].values():
        assert sha(ROOT/ref['path'])==ref['sha256']
    return setting


def generate(directory: Path) -> None:
    """
    機能: 追加期間の非金融特徴だけから固定二案の全q0方向を保存する。
    引数: directory(Path)は接続器の非金融母集団。
    返り値: None。出生NPZとF1を保存し、金融数値表は開かない。
    """
    setting=locked();out=HERE/'全出生';assert not out.exists()
    refs={p.relative_to(ROOT).as_posix():sha(p) for p in
        (Path(__file__),HERE/'適用基盤167.py',HERE/'旧73の同体.json',directory/'完了.json')}
    save(TRIAL/'検査/F1_追加出生前.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと入力':refs,'金融数値表未入力':True})
    features,captures,inputs=load_features(directory)
    assert [s['session'] for s in features.scenes]==setting['scenes']
    arrays={};diagnostics=[]
    for candidate in setting['candidates']:
        result=births(features,candidate)
        for key,value in result.items():arrays[candidate['id']+'__'+key]=value
        diagnostics.append({'id':candidate['id'],'主方向成立':int(np.count_nonzero(result['core'])),
            '技術成立':int(np.count_nonzero(result['technical'])),'局所成立':int(np.count_nonzero(result['local']))})
    assert all(sha(ROOT/p)==v for p,v in refs.items())
    out.mkdir();np.savez_compressed(out/'固定二案の出生.npz',**arrays)
    save(out/'完了.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと入力':refs,'非金融入力':inputs,
        '金融数値表未入力':True,'全q0':len(features.q0_meta),'場数':len(features.scenes),'診断':diagnostics,
        'files':{'固定二案の出生.npz':{'bytes':(out/'固定二案の出生.npz').stat().st_size,
            'sha256':sha(out/'固定二案の出生.npz')}}})
    print(json.dumps({'成功':True,'金融未入力の出生':diagnostics},ensure_ascii=False))


def evaluate(population: Path,numeric: Path,proof_path: Path) -> None:
    """
    機能: 封印済み方向を取得へ結び、主案・同取得の対照幅を評価する。
    引数: population/numeric/proof_path(Path)は非金融母集団・数値表・数値保存票。
    返り値: None。全七場・三時間帯・枝別・幅別・取得参照を保存する。
    """
    setting=locked();out=HERE/'比較';assert not out.exists()
    born_proof=read(HERE/'全出生/完了.json');assert born_proof['成功'] and born_proof['金融数値表未入力']
    born_path=HERE/'全出生/固定二案の出生.npz'
    assert sha(born_path)==born_proof['files'][born_path.name]['sha256']
    refs={p.relative_to(ROOT).as_posix():sha(p) for p in
        (Path(__file__),HERE/'適用基盤167.py',HERE/'全出生/完了.json',born_path,proof_path)}
    save(TRIAL/'検査/F2_追加金融比較前.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと出生と入力':refs})
    features,captures,inputs=load_features(population)
    adapter=module(ROOT/'work/166可変場の数値化/arrays166.py','arrays166_for167')
    numeric_proof=read(proof_path);assert numeric_proof['成功']
    table=adapter.load_table(numeric,numeric_proof['cache'])
    context=GenericContext(features,table,captures)
    assert context.sessions==setting['scenes']
    result=[];references=[];audits=[]
    with np.load(born_path,allow_pickle=False) as sealed:
        for candidate in setting['candidates']:
            prefix=candidate['id']+'__'
            birth={k[len(prefix):]:sealed[k].copy() for k in sealed.files if k.startswith(prefix)}
            selected,origins,widths,tiers,clock_audits=selection(context,birth,candidate)
            hi=table.horizons.index(candidate['horizon'])
            audits.append({'id':candidate['id'],'rows':clock_audits})
            references.append({'id':candidate['id'],'cases':selected.cases.tolist(),'sides':selected.sides.tolist(),
                'events':selected.events.tolist(),'phases':selected.phases.tolist(),
                'origins':origins.tolist(),'widths':widths.tolist(),'tiers':tiers.tolist()})
            scenes=context.case_scene[selected.cases]
            for control in [None,*setting['width_controls']]:
                wi=widths if control is None else np.full(len(widths),table.widths.index(control),dtype=np.int8)
                name='BRANCH' if control is None else f'W{control}'
                total=statistics(context,selected,wi,hi)
                rows=[]
                for scene in range(len(context.scenes)):
                    eligible=np.arange(len(context.scenes))==scene
                    rows.append({'session':context.sessions[scene],
                        'metrics':statistics(context,selected,wi,hi,scenes==scene,eligible)})
                bands={}
                for clock,phases in [('q0出生',selected.phases),('q1取得',context.case_phases[selected.cases])]:
                    bands[clock]=[]
                    for phase,label in enumerate(('デイ','ナイト米国前','ナイト米国後')):
                        eligible=context.hours[:,phase]>0
                        bands[clock].append({'band':label,'metrics':statistics(context,selected,wi,hi,
                            phases==phase,eligible,float(context.hours[:,phase].sum()))})
                branch=np.where(origins==2,np.where(tiers==1,2,3),birth['branches'][selected.events])
                branches=[{'branch':label,'metrics':statistics(context,selected,wi,hi,branch==i)}
                    for i,label in enumerate(('主順行','主回復失敗の反転','旧技術T','長期未知時の局所補完'))]
                sides=[{'side':label,'metrics':statistics(context,selected,wi,hi,selected.sides==i)}
                    for i,label in enumerate(('買い','売り'))]
                for field in ('count','F','A','N','C','profit','loss','net','known','unknown','wins','loss_trades'):
                    assert sum(r['metrics'][field] for r in rows)==total[field],field
                    assert sum(r['metrics'][field] for r in branches)==total[field],field
                    for band in bands.values():assert sum(r['metrics'][field] for r in band)==total[field],field
                result.append({'id':candidate['id']+'_'+name,'candidate':candidate,'width_control':control,
                    'metrics':total,'sessions':rows,'bands':bands,'branches':branches,'sides':sides})
    assert all(sha(ROOT/p)==v for p,v in refs.items())
    out.mkdir();save(out/'全比較と全場.json',{'成功':True,'trial':167,'results':result,
        '注意':'固定二案の別期間確認。幅対照から主案を交換せず、金額はmini1枚独立・既知分。未知を確定0円にしない。'})
    save(out/'全取得参照.json',{'成功':True,'rows':references})
    save(out/'因果監査.json',{'成功':True,'rows':audits})
    save(out/'完了.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと出生と入力':refs,
        'cache':numeric_proof['cache'],'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)}
        for p in out.iterdir() if p.is_file()}})
    print(json.dumps({'成功':True,'固定二案':[{'id':r['id'],'metrics':r['metrics']} for r in result
        if r['width_control'] is None]},ensure_ascii=False))


# ----------------------------------------
if __name__=='__main__':
    parser=argparse.ArgumentParser(description='固定複合入口の可変場適用')
    parser.add_argument('--mode',choices=('births','evaluate'),required=True)
    parser.add_argument('--population',type=Path,required=True)
    parser.add_argument('--numeric',type=Path)
    parser.add_argument('--numeric-proof',type=Path)
    args=parser.parse_args()
    if args.mode=='births':generate(args.population.resolve())
    else:
        assert args.numeric is not None and args.numeric_proof is not None
        evaluate(args.population.resolve(),args.numeric.resolve(),args.numeric_proof.resolve())
