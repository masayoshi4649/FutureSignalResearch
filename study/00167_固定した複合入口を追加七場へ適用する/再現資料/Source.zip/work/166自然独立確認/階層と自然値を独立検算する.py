"""166の局所指標・因果制御・全政策の自然損益を別実装で確認する。"""
from pathlib import Path
from itertools import product
import importlib.util
import json
import math
import sys
import time

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
PARENT=ROOT/'work/166可用指標の階層化'
COMPARE=PARENT/'比較'
TRIAL=ROOT/'study/00166_未公表の長期指標を捏造せず局所技術で参加を補う'
BOOK_SHA='5c3ad73b0003da91749c50e0242b973951c74993db6a9156dfa951d8020f5a49'
DATA=ROOT/'work/163任意幅の数値化/自然数値表'
HELPER=ROOT/'work/165自然独立確認/自然値を独立検算する.py'
spec=importlib.util.spec_from_file_location('independent165_helper',HELPER)
independent=importlib.util.module_from_spec(spec);spec.loader.exec_module(independent)
read=independent.read;save=independent.save;sha=independent.sha;match=independent.match
FIELDS=independent.FIELDS+('old_technical_count','local_technical_count')


def local_from_rows(buy: np.ndarray,sell: np.ndarray,columns: list,q0: list,scenes: list,hierarchies: list) -> tuple:
    """
    機能: 当時の長期公表履歴と実側特徴だけから局所方向を行単位で再構成する。
    引数: buy/sell(np.ndarray[N,100])、columns(list[str])、q0/scenes/hierarchies(list[dict])。
    返り値: tuple[np.ndarray,...]は全階層方向・資格・二実側得点・公表履歴。
            取得・未決・金融値は引数に受け取らない。
    """
    index={name:i for i,name in enumerate(columns)};n=len(q0)
    score_names=('m5_ema21_delta_to_side','m5_di_difference_to_side','m5_hist_delta_to_side',
                 'm5_rsi_delta_to_side','m5_body_ratio_to_side','m5_close_position_to_side','m1_volume_relative_prior3')
    gate_names=score_names+('m5_rsi_center_to_side','q0_entry_minus_ema8_atr5_to_side',
                          'm5_tr_atr_ratio','q0_spread_points','q0_last_minus_m1_close_atr5_to_side')
    sides=(buy,sell);scores=np.full((2,n),np.nan);local=np.zeros((len(hierarchies),n),dtype=np.int8)
    eligible=np.zeros((len(hierarchies),n),dtype=bool);seen=np.zeros(n,dtype=bool);known_scenes=set()
    finite_zero=0;publications=0
    for event,row in enumerate(q0):
        scene=row['session_index']
        available=[side[event,index['m15_hist_delta_to_side']] for side in sides]
        if any(math.isfinite(v) for v in available):
            known_scenes.add(scene);publications+=1
            if any(math.isfinite(v) and v==0 for v in available):finite_zero+=1
        seen[event]=scene in known_scenes
        gates=[];trends=[];momentums=[]
        for si,side in enumerate(sides):
            value={name:float(side[event,index[name]]) for name in gate_names}
            finite_score=all(math.isfinite(value[name]) for name in score_names)
            trend=int(value['m5_ema21_delta_to_side']>0)+int(value['m5_di_difference_to_side']>0)
            impulse=int(value['m5_hist_delta_to_side']>0)+int(value['m5_rsi_delta_to_side']>0)+\
                    int(value['m5_body_ratio_to_side']>0 and value['m5_close_position_to_side']>.5)
            volume=value['m1_volume_relative_prior3']>=.5
            if finite_score:scores[si,event]=trend+impulse+int(volume)
            gates.append(all(math.isfinite(v) for v in value.values()) and trend>=1 and impulse>=1 and
                         -5<=value['m5_rsi_center_to_side']<=25 and abs(value['m5_rsi_delta_to_side'])<=12 and
                         abs(value['q0_entry_minus_ema8_atr5_to_side'])<=1 and volume and
                         value['m5_tr_atr_ratio']<=2 and 0<value['q0_spread_points']<=20 and
                         abs(value['q0_last_minus_m1_close_atr5_to_side'])<=1)
            trends.append(trend);momentums.append(impulse)
        preferred=None
        if np.isfinite(scores[:,event]).all():
            if scores[0,event]-scores[1,event]>=1:preferred=0
            elif scores[1,event]-scores[0,event]>=1:preferred=1
        elapsed=row['q0_time']-scenes[scene]['start']
        for hi,hierarchy in enumerate(hierarchies):
            eligible[hi,event]=(not seen[event]) and elapsed>=hierarchy['after_minutes']*60
            if eligible[hi,event] and preferred is not None and gates[preferred] and scores[preferred,event]>=hierarchy['minimum_score']:
                local[hi,event]=1 if preferred==0 else -1
    return local,eligible,scores,seen,{'現在行で長期有限':publications,'長期有限0の行':finite_zero}


def add_tiers(rows: list,tiers: np.ndarray) -> list:
    """
    機能: 取得済みの補完行だけに当時tierを対応させる。
    引数: rows(list[tuple])はcase/side/event/origin、tiers(np.ndarray[N])は当時階層。
    返り値: list[int]は主0/旧T1/局所2。
    """
    result=[int(tiers[row[2]]) if row[3]==2 else 0 for row in rows]
    assert all(tier in (1,2) for row,tier in zip(rows,result,strict=True) if row[3]==2)
    return result


def summary(rows: list,tiers: list,widths: np.ndarray,hi: int,arrays: dict,hours: np.ndarray,
            mask: np.ndarray|None=None,eligible: np.ndarray|None=None) -> np.ndarray:
    """
    機能: 165の独立集計に二階層の取得数を追加する。
    引数: rows/tiers(list)、widths(np.ndarray)、hi(int)、arrays(dict)、hours(np.ndarray)、
          mask/eligible(np.ndarray又はNone)は集計範囲と対象場。
    返り値: np.ndarray[29]は全指標。
    """
    base=independent.summarize(rows,widths,hi,arrays,hours,mask,eligible)
    chosen=np.asarray(tiers,dtype=np.int8)
    if mask is not None:chosen=chosen[mask]
    return np.r_[base,int((chosen==1).sum()),int((chosen==2).sum())]


def clean(values: np.ndarray) -> dict:
    """
    機能: 指標をNaNではなく未定義null付き辞書へする。
    引数: values(np.ndarray[29])は全統計。
    返り値: dictは有限数値又はnull。
    """
    return {name:float(value) if math.isfinite(value) else None for name,value in zip(FIELDS,values,strict=True)}


# ----------------------------------------
def main() -> None:
    """
    機能: 全q0局所出生、全32取得集合、全3840政策と旧960対照を独立検算する。
    引数: なし。固定166・165・旧73場の入力だけを読む。
    返り値: None。全場/時間帯/枝明細、自然確認、停止票を保存する。
    """
    sys.stdout.reconfigure(encoding='utf-8');begin=time.monotonic();assert sha(TRIAL/'条件.json')==BOOK_SHA
    cache=ROOT/'work/151過去場判別の評価/入口選択/cache/feature_only'
    paths=[Path(__file__),HELPER,TRIAL/'条件.json',COMPARE/'完了.json',COMPARE/'統計軸.json',COMPARE/'主案と探索結果.json',
           COMPARE/'階層化入口の統計配列.npz',COMPARE/'全取得参照.json.gz',COMPARE/'初参加補完の因果監査.json.gz',
           PARENT/'全出生/全出生の確認.json',PARENT/'全出生/階層化の出生.npz',PARENT/'local166.py',
           PARENT/'出生を作る.py',PARENT/'比較する.py',cache/'features.npz',cache/'features_meta.json',
           ROOT/'inputs/00148_全1分入口母集団/取得対応.json.gz',DATA/'任意幅配列.npz',DATA/'任意幅識別.json.gz',
           ROOT/'work/165順行と回復失敗の複合/全出生/複合と技術補完.npz',
           ROOT/'work/165順行と回復失敗の複合/全出生/全出生の確認.json',
           ROOT/'work/165順行と回復失敗の複合/比較/複合入口の統計配列.npz']
    before={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    setting=read(paths[2]);axes=read(paths[4]);report=read(paths[5]);proof=read(paths[9])
    assert axes['fields']==list(FIELDS) and proof['金融未入力']
    meta=read(cache/'features_meta.json');q0=meta['q0_meta'];scenes=meta['scenes']
    with np.load(cache/'features.npz',allow_pickle=False) as source:
        buy=source['buy_X'].copy();sell=source['sell_X'].copy();columns=source['columns'].tolist()
    with np.load(paths[10],allow_pickle=False) as source:birth={name:source[name].copy() for name in source.files}
    local,eligible,scores,seen,availability=local_from_rows(buy,sell,columns,q0,scenes,axes['hierarchies'])
    assert np.array_equal(local,birth['local_directions']) and np.array_equal(eligible,birth['local_eligible'])
    assert np.array_equal(scores,birth['local_scores'],equal_nan=True)
    old_proof=read(paths[20]);lookup={row['id']:i for i,row in enumerate(old_proof['profiles'])}
    with np.load(paths[19],allow_pickle=False) as source:
        for pi,profile in enumerate(axes['profiles']):
            oi=lookup[profile['id']]
            assert np.array_equal(birth['directions'][pi],source['directions'][oi])
            assert np.array_equal(birth['branches'][pi],source['branches'][oi])
        assert np.array_equal(birth['oldtechnical'],source['technical'])
    technical=np.zeros_like(birth['technical']);tiers=np.zeros_like(birth['technical_tier'])
    for li,ti,event in product(range(4),range(2),range(len(q0))):
        old=int(birth['oldtechnical'][ti,event]);new=int(local[li,event])
        if old:technical[li,ti,event]=old;tiers[li,ti,event]=1
        elif new:technical[li,ti,event]=new;tiers[li,ti,event]=2
    assert np.array_equal(technical,birth['technical']) and np.array_equal(tiers,birth['technical_tier'])
    assert not np.any((tiers==2)&seen[None,None,:])
    # ----------------------------------------
    # 局所出生を確かめた後に初めて金融原始配列を読む。制御には金額を渡さない。
    raw_meta=read(paths[18]);mapping={name:i for i,name in enumerate(raw_meta['case_ids'])}
    captures_by_event={row['event_id']:row for row in read(paths[16])['rows']}
    captures=[captures_by_event[row['event_id']] for row in q0];scene_events=[[] for _ in scenes]
    for event,row in enumerate(q0):scene_events[row['session_index']].append(event)
    with np.load(paths[17],allow_pickle=False) as source:arrays={name:source[name].copy() for name in source.files}
    with np.load(paths[6],allow_pickle=False) as source:metrics=source['metrics'].copy();controls=source['controls'].copy()
    references={(r['profile'],r['hierarchy'],r['integration']):r for r in read(paths[7])['rows']}
    audit={(r['profile'],r['hierarchy'],r['integration']):r['rows'] for r in read(paths[8])['rows']}
    assert list(metrics.shape)==axes['shape']==[4,4,6,5,4,2,3,29]
    assert controls.shape==(4,6,5,4,2,3,27) and len(references)==len(audit)==32
    hours=np.zeros((73,3))
    for si,scene in enumerate(scenes):
        end=scene['end']-300
        if scene['session'].endswith('_Day'):hours[si,0]=(end-scene['start'])/3600
        else:
            boundary=independent.ny_open(scene['session']);hours[si,1]=(min(boundary,end)-scene['start'])/3600
            hours[si,2]=(end-max(boundary,scene['start']))/3600
    assert abs(float(hours.sum())-(720+55/60))<1e-10
    all_rows={};old_rows={};attempts=0
    for pi,profile in enumerate(axes['profiles']):
        core=independent.link(birth['directions'][pi],captures,mapping)
        for ti,tw in enumerate((150,200)):
            extra,_=independent.technical_controller(birth['directions'][pi],birth['oldtechnical'][ti],captures,scene_events,scenes,mapping)
            old_rows[pi,ti]=independent.merged(core,extra,technical=True)
            for li,hierarchy in enumerate(axes['hierarchies']):
                extra,observed=independent.technical_controller(birth['directions'][pi],technical[li,ti],captures,scene_events,scenes,mapping)
                where=(profile['id'],hierarchy['id'],axes['integrations'][ti])
                assert observed==audit[where],where
                attempts+=sum(len(row['attempts']) for row in observed)
                rows=independent.merged(core,extra,technical=True);chosen=add_tiers(rows,tiers[li,ti]);ref=references[where]
                for at,name in enumerate(('cases','sides','events','origins')):
                    assert [row[at] for row in rows]==ref[name],(where,name)
                assert chosen==ref['tiers'],(where,'tiers')
                all_rows[pi,li,ti]=(rows,chosen)
    # ----------------------------------------
    # 規模が小さいので全3840政策の全統計と旧960政策を個別に検算する。
    tested=0;control_tested=0
    for pi,li,mi,fi,hi,ti in product(range(4),range(4),range(6),range(5),range(4),range(2)):
        rows,chosen=all_rows[pi,li,ti];scene=np.asarray([arrays['session_index'][row[0]] for row in rows])
        widths=independent.widths_for(rows,birth['branches'][pi],axes['momentum_widths'][mi],axes['fade_widths'][fi],(150,200)[ti],raw_meta['widths'])
        for period in range(3):
            eligible_scene=np.arange(73)<48 if period==1 else np.arange(73)>=48 if period==2 else np.ones(73,dtype=bool)
            expected=summary(rows,chosen,widths,hi,arrays,hours,eligible_scene[scene],eligible_scene)
            match(metrics[pi,li,mi,fi,hi,ti,period],expected,('全166',pi,li,mi,fi,hi,ti,period))
        tested+=1
    for pi,mi,fi,hi,ti in product(range(4),range(6),range(5),range(4),range(2)):
        rows=old_rows[pi,ti];scene=np.asarray([arrays['session_index'][row[0]] for row in rows])
        widths=independent.widths_for(rows,birth['branches'][pi],axes['momentum_widths'][mi],axes['fade_widths'][fi],(150,200)[ti],raw_meta['widths'])
        for period in range(3):
            eligible_scene=np.arange(73)<48 if period==1 else np.arange(73)>=48 if period==2 else np.ones(73,dtype=bool)
            expected=independent.summarize(rows,widths,hi,arrays,hours,eligible_scene[scene],eligible_scene)
            match(controls[pi,mi,fi,hi,ti,period],expected,('旧T対照',pi,mi,fi,hi,ti,period))
        control_tested+=1
    with np.load(paths[21],allow_pickle=False) as source:
        for pi,profile in enumerate(axes['profiles']):
            oi=lookup[profile['id']]
            match(controls[pi],source['metrics'][oi,:,:,:,3:5],('旧165全同体',pi))
    f={name:i for i,name in enumerate(FIELDS)}
    for name in ('count','F','A','N','C','profit','loss','net','known','unknown','new_count','old_count','wins','loss_trades','technical_first_count','core_count','old_technical_count','local_technical_count'):
        value=metrics[...,f[name]];assert np.array_equal(value[...,0],value[...,1]+value[...,2]),name
    assert np.array_equal(metrics[...,f['technical_first_count']],metrics[...,-2]+metrics[...,-1])
    support=setting['discovery_support'];full=metrics[...,0,:];front=metrics[...,1,:];back=metrics[...,2,:]
    supported=(full[...,f['count']]>=support['minimum_count'])&(full[...,f['new_count']]>=support['minimum_new_count'])
    for value,resolved,rate in ((full,support['minimum_resolved'],support['minimum_rate']),
                               (front,support['minimum_resolved_each_period'],support['minimum_rate_each_period']),
                               (back,support['minimum_resolved_each_period'],support['minimum_rate_each_period'])):
        supported &= (value[...,f['F']]+value[...,f['A']]>=resolved)&(value[...,f['rate']]>=rate)
    supported &= (full[...,f['all_scenes']]==1)&(full[...,f['unknown']]<=support['maximum_financial_unknown_fraction']*full[...,f['count']])
    supported &= (front[...,f['net']]>0)&(back[...,f['net']]>0)
    assert int(supported.sum())==report['発見支持合格']
    training=(front[...,f['all_scenes']]==1)&(front[...,f['rate']]>=.7)&(front[...,f['F']]+front[...,f['A']]>=60)&\
             (front[...,f['new_count']]>=80)&(front[...,f['new_scenes']]>=10)&\
             (front[...,f['unknown']]<=.1*front[...,f['count']])&\
             ((front[...,f['pf']]>=1.2)|((front[...,f['loss']]==0)&(front[...,f['profit']]>0)))&(front[...,f['net']]>0)
    assert int(training.sum())==report['前48場で適格数']
    ordering=lambda p:(-front[tuple(p)][f['count']],-front[tuple(p)][f['rate']],tuple(p))
    selected=sorted(np.argwhere(training),key=ordering)
    assert (selected[0].tolist() if selected else None)==(report['前48場だけで選択']['position'] if report['前48場だけで選択'] else None)
    primary=report['事前固定主案'];pi,li,mi,fi,hi,ti=primary['position'];rows,chosen=all_rows[pi,li,ti]
    widths=independent.widths_for(rows,birth['branches'][pi],primary['momentum_width'],primary['fade_width'],(150,200)[ti],raw_meta['widths'])
    scene=np.asarray([arrays['session_index'][row[0]] for row in rows]);scene_report=[]
    for si,item in enumerate(scenes):
        eligible_scene=np.arange(73)==si
        scene_report.append({'session':item['session'],'metrics':clean(summary(rows,chosen,widths,hi,arrays,hours,scene==si,eligible_scene))})
    band_report={}
    for clock in ('q0出生','q1取得'):
        bands=np.asarray([independent.band(scenes[int(arrays['session_index'][row[0]])]['session'],
                          q0[row[2]]['q0_time'] if clock=='q0出生' else arrays['entry_time'][row[0]]) for row in rows])
        band_report[clock]=[{'band':name,'metrics':clean(summary(rows,chosen,widths,hi,arrays,hours[:,phase],bands==phase,hours[:,phase]>0))}
                            for phase,name in enumerate(('デイ','ナイト米国前','ナイト米国後'))]
    # originを先に判定し、補完行に偶然ある主枝列を枝帰属へ使わない。
    branch=np.asarray([int(birth['branches'][pi,row[2]]) if row[3]==0 else 2 if tier==1 else 3
                       for row,tier in zip(rows,chosen,strict=True)])
    branch_report=[{'branch':name,'metrics':clean(summary(rows,chosen,widths,hi,arrays,hours,branch==bi))}
                   for bi,name in enumerate(('主順行','主回復失敗の反転','旧技術T','長期未知時の局所補完'))]
    local_trades=[]
    for ri,(row,tier) in enumerate(zip(rows,chosen,strict=True)):
        if tier!=2:continue
        case,side,event,origin=row;known=bool(arrays['known'][case,side,widths[ri],hi])
        local_trades.append({'case_id':raw_meta['case_ids'][case],'session':scenes[int(arrays['session_index'][case])]['session'],
                             'side':1 if side==0 else -1,'q0':list(independent.key(captures[event]['q0'])),
                             'q1':list(independent.key(captures[event]['q1'])),'width':raw_meta['widths'][int(widths[ri])],
                             '先着':int(arrays['direction'][case,side,widths[ri],hi]) if known else None,
                             '損益既知':known,'費用後損益':int(arrays['net5'][case,side,widths[ri],hi]) if known else None})
    for period,name in enumerate(('全期','前48場','後25場')):
        reported=np.asarray([primary['periods'][name][field] if primary['periods'][name][field] is not None else np.nan for field in FIELDS])
        match(reported,metrics[pi,li,mi,fi,hi,ti,period],('主案JSON',name))
    full=primary['periods']['全期'];additive=('count','F','A','N','C','profit','loss','net','known','unknown','technical_first_count','core_count','old_technical_count','local_technical_count')
    for name in additive:
        assert sum(row['metrics'][name] for row in scene_report)==full[name]
        assert sum(row['metrics'][name] for row in branch_report)==full[name]
        for clock in band_report:assert sum(row['metrics'][name] for row in band_report[clock])==full[name]
    save(HERE/'主案の全73場と三時間帯と補完枝.json',{'成功':True,'position':primary['position'],'全期':full,
         '全73場':scene_report,'時間帯別':band_report,'枝別':branch_report,'局所補完の全取得':local_trades,
         '不足場':[row['session'] for row in scene_report if row['metrics']['count']==0],
         '留意':'mini1枚ごとの独立入口合算。数量上限付き口座収支ではない。観測不足を確定損益0として扱わない。'})
    neighbors=set()
    for next_m,next_f in product(range(max(mi-1,0),min(mi+2,6)),range(max(fi-1,0),min(fi+2,5))):
        neighbors.add((pi,li,next_m,next_f,hi,ti))
    for next_l,next_h,next_t in product(range(4),range(4),range(2)):
        neighbors.add((pi,next_l,mi,fi,next_h,next_t))
    nearby=[]
    for position in sorted(neighbors):
        p,l,m,w,h,t=position
        nearby.append({'position':list(position),'profile':axes['profiles'][p]['id'],
                       'hierarchy':axes['hierarchies'][l]['id'],'momentum_width':axes['momentum_widths'][m],
                       'fade_width':axes['fade_widths'][w],'horizon':axes['horizons'][h],
                       'integration':axes['integrations'][t],'発見支持合格':bool(supported[position]),
                       'periods':{name:clean(metrics[position+(period,)]) for period,name in enumerate(('全期','前48場','後25場'))}})
    save(HERE/'主案の近傍比較.json',{'成功':True,'全政策を独立検算済み':True,'rows':nearby,
         '留意':'既使用期での近傍比較であり、未知期の性能保証ではない。'})
    assert all(sha(ROOT/name)==digest for name,digest in before.items())
    save(HERE/'自然の独立確認.json',{'成功':True,'trial':166,'条件SHA256':BOOK_SHA,'入力とSource':before,
         '局所出生全q0':len(q0),'局所階層数':4,'局所方向資格と得点全同体':True,'旧T優先とtier全同体':True,
         '当時公表履歴':availability,'未知と有限0の扱い':'非有限を0票にせず、有限0は公表済み。後の公表時刻を使わない。',
         '全取得集合':32,'因果制御場数':32*73,'因果制御要求数':attempts,'因果制御の金融入力':False,
         '全政策独立再計算':tested,'全政策統計セル数':int(metrics.size),'旧対照独立再計算':control_tested,
         '旧対照統計セル数':int(controls.size),'旧165対照全同体':True,'発見支持合格':int(supported.sum()),
         '前48場適格数':int(training.sum()),'前48場選択同体':True,
         '主案全73場三帯補完枝SHA256':sha(HERE/'主案の全73場と三時間帯と補完枝.json'),
         '主案近傍比較SHA256':sha(HERE/'主案の近傍比較.json'),'近傍政策数':len(nearby),
         '未見7場の価格読取':False,'元入力変更':False,
         '限界':'原板全再走査は163/164の独立照合を参照。既使用73場での条件探索であり未見検証ではない。',
         '経過秒':time.monotonic()-begin})
    save(HERE/'独立確認の停止.json',{'成功':True,'SourceSHA256':sha(Path(__file__)),'検査票SHA256':sha(HERE/'自然の独立確認.json'),
         '主案明細SHA256':sha(HERE/'主案の全73場と三時間帯と補完枝.json'),'元入力不変':True})
    print(json.dumps({'成功':True,'全政策':tested,'旧対照':control_tested,'主案':full,'枝別':branch_report,
                      '検査票SHA256':sha(HERE/'自然の独立確認.json')},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
