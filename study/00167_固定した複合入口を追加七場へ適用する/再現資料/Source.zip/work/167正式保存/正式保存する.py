"""167の固定二案・同取得幅対照と単一恒久入力を正式保存する。"""
from pathlib import Path
import importlib.util
import importlib.metadata
import json
import platform
import re
import shutil
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00167_固定した複合入口を追加七場へ適用する'
INPUT=ROOT/'inputs/00167_追加七場の入口と共用価格索引'
BOOK_SHA='73e16eabfc3364a9e038d9697472abe50bb91fbba49b488dd0c8ed8d5eaea9f4'
spec=importlib.util.spec_from_file_location('保存共通167',ROOT/'work/163_164正式保存/正式保存する.py')
B=importlib.util.module_from_spec(spec);spec.loader.exec_module(B)


def rate(value: float|None) -> str:
    """
    機能: 未定義率と百分率を区別する。
    引数: value(float|None)。返り値: str。
    """
    return '未定義' if value is None else f'{value:.2%}'


def row_metrics(name: str,m: dict) -> list:
    """
    機能: 利益・損失・既知差引・未知と先着分母を併記する。
    引数: name(str)、m(dict)。返り値: listは表の一行。
    """
    return [name,m['count'],f"{m['F']}/{m['A']}/{m['N']}/{m['C']}",rate(m['rate']),
        f"{m['profit']:,}",f"{m['loss']:,}",f"{m['net']:+,}",f"{m['pf']:.3f}" if m['pf'] is not None else '未定義',m['unknown'],f"{m['per_hour']:.3f}"]


def settings() -> None:
    """
    機能: V8の全567セルを固定二案の参照設定へ写す。
    引数: なし。返り値: None。
    """
    parent=ROOT/'study/00166_未公表の長期指標を捏造せず局所技術で参加を補う/設定と結果.md'
    text=parent.read_text(encoding='utf-8').split('## 手法×時間スケール',1)[1].split('## 設定明細',1)[0]
    text=text.replace('S166-X/Q','S167-FIXED').replace('R166','R167')
    text=text.replace('新fadeは反対実側で確認/背景を別比較','今回は元EXの反対実側へ即時。追加背景filterなし')
    text=text.replace('fade背景は15/30分4票','今回はB0で追加背景票なし')
    text=text.replace('順行150～300、失速250～500、補完150/200ptを出生で固定。IFD_FIRSTと4期限',
        '順行200/250・元EX反対400・補完200/150pt、H60/H120。同取得で12固定幅も対照')
    rows=[line for line in text.splitlines() if re.match(r'^\| [A-Z]\d{2} \|',line)]
    assert len(rows)==63 and all(len(line.split('|')[1:-1])==11 for line in rows)
    header='# 167 設定と結果\n\n2026-11-15。汎用表V8全63手法×9尺度=567セルをコピーし、166から変更しない固定二案の設定を記した。指標単独の効果ではなく複合評価R167。元V8 SHA256 `'+B.sha(ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md')+'`。\n\n100Xへ供給されるだけの未使用列は使用としない。未使用・未検証と必要値未知を区別し、未知を0や中立へ置換しない。原板列はq0/実BBO/逐次評価、1分は観測量、5/15/30分は指標足であり新規の5分/15分定時時計ではない。E02の追尾は本試行で未使用。\n\n## 手法×時間スケール\n'
    details='''\n## 固定設定ID\n\n|設定ID|閾値・役割|複合評価|\n|---|---|---|\n|S167-MP|MP0057/58。0<spread<=10/20、absq0gap<=1ATR5、M5 Hist/ATR>=0.1、M15 Hist>0、M5 HistΔ>=0、RSI中心差0..25・Δ>0、ADX15>=25・Δ>=0、前3分比量>=0.75|主順行|\n|S167-EX|EX0076の元側でBB15σ<=−2、逆ヒゲ>=0.2、RSI中心差<=5・Δ>0、HistΔ5>0、実体比>=0、量>=0.5、spread<=20・absq0gap<=1。成立方向を反転して反対実BBOへ。B0/IMMEDIATEで後続失敗確認なし|元EX反対側|\n|S167-MERGE|MPとEX反対側が逆方向なら待機、同方向又は片方なら採用。両方同方向の幅はMP優先|主枝|\n|S167-T|166の旧T8票・17列knownと方向/動力/量/位置/RSI急変gateを同体再用。>=5票、側差>=1。全既知20列の詳細は166固定設定S166-T8/T_GATE|旧T|\n|S167-L|その場でM15 HistΔが当時まで一度も有限でない場合のみ、開始180/120分後に局所6票>=4・側差>=1。M5方向・動力・形状・量と位置/急変gate。旧T非0を絶対優先|局所階層|\n|S167-CTRL|開始45分後、主取得0・主pendingなし・同q0主方向0時だけ補完要求。取消後再試行、後発主取得を使って補完を事後取消ししない|取得制御|\n|S167-E|PRIMARYは順行±200/EX反対±400/補完±200・H60。FRONT48は±250/±400/±150・H120。q0で枝幅を固定。両案同じ取得で125〜1000の12幅を事前対照|単純IFD|\n\nR167は固定2案×主枝幅と同取得12幅=26政策。全7場参加・未知・先着・利益損失を[主結果](README.md)へ記録した。追加7場の成績から主案・閾値・幅を交換していない。局所階層は今回0取得であり、その部分の別期間有効性は確認していない。\n'''
    (TRIAL/'設定と結果.md').write_text(header+text+details,encoding='utf-8')


def documents(results: list) -> None:
    """
    機能: 固定主案・前48選択・同取得125/全幅の結果を分母付きで記す。
    引数: results(list[dict])。返り値: None。
    """
    by={r['id']:r for r in results};p=by['PRIMARY_BRANCH'];f=by['FRONT48_BRANCH']
    headers=['政策','取得','F/A/N/C','F/(F+A)','利益円','損失円','既知差引円','PF','金融未知','回/時']
    intro='''# 00167 固定した複合入口を追加七場へ適用する\n\n2026-11-15。固定主案は追加7場すべてで159取得、先着60順18逆、到達済み76.92%。費用後利益1,972,532円・損失1,013,390円、既知差引+959,142円、金融未知5件。条件は価格参照前に固定し、結果を見て交換していない。\n\n## 仮説・固定条件\n\n166の事前主案と前48場だけの選択案を、未使用だった11/10Night〜11/13Nightの7場へ同じ式で適用した。主案はMP0057+元EX0076の反対側、L180_S4、順行±200/元EX反対±400/補完±200・H60。前48場選択はMP0058+同反対側、L120_S4、±250/±400/±150・H120。旧C1参照は使わない。\n\n[条件](条件.json)SHA `73e16eabfc3364a9e038d9697472abe50bb91fbba49b488dd0c8ed8d5eaea9f4`、[全567設定セル](設定と結果.md)、[条件・心理と限界](条件心理と限界.md)、[再現手順](再現手順.md)。\n\n## 固定二案と同取得±125\n'''
    intro+=B.table(headers,[row_metrics(label,by[key]['metrics']) for label,key in [('固定主案・枝幅','PRIMARY_BRANCH'),('主案の同取得±125','PRIMARY_W125'),('前48選択・枝幅','FRONT48_BRANCH'),('前48選択の同取得±125','FRONT48_W125')]])
    intro+='''\nFは期限/観測打切り前の順側初到達、Aは逆側初到達、Nは同幅未到達で期限完了、Cは未確定。IFD_FIRSTでは未来の期限完了を待たず、打切り前の既知touchでF/Aを確定する。F/(F+A)はN/Cを除いた率で、全取得成功率ではない。主案は60/159=37.74%、費用後実現勝率は84/154=54.55%。FRONT48は66/104=63.46%、金融未知23件。両者を「勝率70%以上」と一括しない。\n\n1入口独立mini1枚、100円/pt、税込往復77円と追加往復滑り1,000円を控除。利益は費用後正の合計、損失は負の絶対値合計。未知を0円実績に加えず、Cが残る全件収支はnull。重なる建玉の既知合算であり、片側10枚口座の利益とは異なる。実BBOはラージを代用し、mini待ち行列・注文遅延・実IFD執行は保証していない。\n\n## 全7場\n'''
    rows=[]
    for a,b in zip(p['sessions'],f['sessions'],strict=True):
        x,y=a['metrics'],b['metrics'];rows.append([a['session'],x['count'],f"{x['F']}/{x['A']}/{x['N']}/{x['C']}",rate(x['rate']),f"{x['profit']:,}",f"{x['loss']:,}",f"{x['net']:+,}",y['count'],rate(y['rate']),f"{y['net']:+,}"])
    intro+=B.table(['場','主取得','主F/A/N/C','主先着率','主利益円','主損失円','主既知差引円','前48取得','前48先着率','前48既知差引円'],rows)
    intro+='\n頻度の分母は全対象ザラバ72時間25分。主案2.196回/時、前48選択2.348回/時で、各場の回数を均等にしていない。\n\n## 三帯・枝の診断\n'
    rows=[]
    for r in (p,f):
        for band in r['bands']['q0出生']:rows.append(row_metrics(r['candidate']['id']+' '+band['band'],band['metrics']))
    intro+=B.table(headers,rows)
    intro+='\n主案の到達済み順60件のうち53件は11/11Day・11/12Dayの2場に集中した。全期の率だけで夜間の優位性を主張しない。q1区分・枝別・売買別の全件は[26政策正本](成果物/全比較と全場.json)に保持した。今回の局所補完は0取得であり、166の欠測対策の追加期間での効果をこの結果から確認できない。\n\n## 全事前幅対照\n\n各列は同じ入口取得を維持した事前対照で、幅を広げるほどN/Cの構成も変わる。掲載後に最良幅を選んで主案を置き換えない。\n'
    for candidate in ('PRIMARY','FRONT48'):
        intro+=f'\n### {candidate}\n'
        intro+=B.table(headers,[row_metrics('枝幅' if r['width_control'] is None else f"±{r['width_control']}",r['metrics']) for r in results if r['candidate']['id']==candidate])
    intro+='''\n## 入力・検査・限界\n\n[恒久入力](../../inputs/00167_追加七場の入口と共用価格索引/正本の案内.md)に7場の索引・100X母集団・原本指紋・純観測・数値表・封印出生を一度だけ保存した。全q0台帳4,125、適格100X3,608、物理q1母集団3,250。価格参照前F0→非金融生成→Root出生封印→金融観測の順を守った。\n\n独立Source/人工監査と、追加7場を含む自然の独立確認は[検査](検査/自然独立確認/README.md)へ保存。167全26政策の全場・三帯・枝・売買13,520統計を元NPZから別算術で確認し、取得/幅/tier/因果制御も一致した。新Rawを第二parserで全再走査した確認ではない。旧73での同体確認は別票で保持する。\n\n追加期間は7場と短く、利益・先着が2つのDayへ集中し、負けのNightもある。既知黒字や高い到達済み率を継続的な未見利益・実口座利益の確定としない。固定FRONT48は70%へ届かず、未知も多い。旧73の探索、今回の一回適用、後続の数量枠検証を混ぜない。CSV/globalは全体研究側で整理し、PDF/xlsxは作らない。\n'''
    (TRIAL/'README.md').write_text(intro,encoding='utf-8')
    psychology='''# 167 条件・心理と限界\n\n2026-11-15。公開技法の一般的な役割と本研究の心理仮説を、確認した数値から区別する。新しい技法を追加せず166固定二案を適用した。\n\n## 主順行\n\nMP0057/58は5分MACD Hist/ATR>=0.1、15分Hist正、5分Hist増分非負、方向付きRSI中心差0..25と増分正、15分ADX>=25・増分非負、1分観測量/直前3分平均>=0.75を同時に要求する。q0スプレッド上限だけ10/20ptが異なる。価格の足終値乖離は1ATR以内。\n\n心理仮説は、短い反発1本を追うより、中期の動力・トレンド強度が残る側へ参加すること。RSIの水準と変化を分け、極端な過熱を抑える。量の0.75は活況の証明ではなく、直近平均から極端に細い局面を避ける条件である。\n\n## 元EX方向の反対側\n\nEX0076はBB15の反対端2σ以上、逆ヒゲ比>=0.2、RSIとHistの改善、非負の実体、相対量>=0.5等で元の回復方向を定義する。本試行はその方向を即座に反転して反対実側で取得する。B0/IMMEDIATEなので、その後の失敗足を見届けてから入る方式ではない。\n\n心理仮説は、端の小さい回復の兆しが売買を誘っても、継続圧力に吸収される状態を捉えること。元EX群の弱さと実反対側の再評価を旧73で発見した条件であり、「回復は常に失敗する」という一般則ではない。反対率を1−pで作らず、反対側Ask/Bidで別に計算している。MPと反対側EXが衝突したら待機し、同方向時はMP幅を優先する。\n\n## 技術による初参加補完\n\n旧TはEMA/DIの5/15/30分方向、MACD/RSI増分、実体と終値位置、観測量、BB余地、EMA距離/TRの8票と位置・量・急変gateを合わせる。必要17列の既知性を求める。開始45分以後に、主の取得もpendingも無く同q0主方向も0なら補完を要求する。\n\n旧Tが0のときだけ、15分HistΔが当時まで一度も公表されていない場に限り、開始180/120分後から5分方向・動力・形状・量の局所6票を使う。有限0を公表済みとして扱い、後のNaNで再開しない。旧T非0は局所で置き換えない。今回の追加7場では局所取得0で、その有効性の別期間確認にはなっていない。\n\n## この検証が答えていないこと\n\n同じ入口に幅125を置くと主案先着は59.06%、枝幅では76.92%になる。到達幅・期限・N/C構成が変わるため、幅を示さない「入口の確率」は使わない。159取得のうち同幅到達は78件であり、全取得の76.92%が利益になったわけではない。主案の費用後実現勝率は54.55%。\n\n本試行は単純IFDと期限返済の入口研究で、可変追尾や実注文は追加していない。片側10枚の建玉制約は後続168で分ける。技術同士の相関があるため、複合結果を各指標単独の効果と解釈しない。\n\n[設定](設定と結果.md)、[結果](README.md)、[固定条件](条件.json)を参照する。\n'''
    (TRIAL/'条件心理と限界.md').write_text(psychology,encoding='utf-8')


def main() -> None:
    """
    機能: Sourceと確認票を保存し、原本非改変の正式索引を作る。
    引数: なし。返り値: None。
    """
    assert B.sha(TRIAL/'条件.json')==BOOK_SHA
    results=B.read(TRIAL/'成果物/全比較と全場.json')['results'];assert len(results)==26
    settings();documents(results)
    # ----------------------------------------
    # 監査票は正本へbyte同体コピーする。自然監査とSource/人工監査を混ぜない。
    for name,source in [('Source独立監査','work/167適用Source独立監査'),('自然独立確認','work/167_168自然独立確認')]:
        destination=TRIAL/'検査'/name;destination.mkdir(exist_ok=True)
        for path in (ROOT/source).rglob('*'):
            if not path.is_file() or '__pycache__' in path.parts:continue
            target=destination/path.relative_to(ROOT/source);target.parent.mkdir(parents=True,exist_ok=True)
            if target.exists():assert target.read_bytes()==path.read_bytes()
            else:shutil.copyfile(path,target)
    for name in ('旧73の同体.json',):
        source=ROOT/'work/167固定入口の別期間'/name;target=TRIAL/'検査'/name
        if target.exists():assert target.read_bytes()==source.read_bytes()
        else:shutil.copyfile(source,target)
    # ----------------------------------------
    # 共通Pythonと停止済GoをSourceとして保持し、大きいRaw/CSV/共用数値は再複製しない。
    folders=['work/167固定入口の別期間','work/未見入口の同体接続','work/166可変場の観測','work/166可変場の数値化',
             'work/167適用Source独立監査','work/167_168自然独立確認','work/167正式保存']
    paths=[p for folder in folders for p in B.source_files(folder)]
    go_folders=['work/三時間軸の公開器','work/115三時間軸と方向性の公開','work/三時間軸の市場入力口',
                'work/118複数技法の入口条件','work/122公表生成','work/147中位位置からの実体回復',
                'work/148全1分候補の当時特徴','work/148全1分知得の入口母集団','work/未見入口の同体接続']
    paths += [p for folder in go_folders for p in (ROOT/folder).rglob('*') if p.is_file() and (p.suffix=='.go' or p.name=='go.mod')]
    names=['work/161三時間帯入口のデータ/data161.py','work/162入口探索/共通.py','work/162入口探索/評価基盤.py',
           'work/162複合入口候補/rules162.py','work/163入口と任意幅/共通163.py','work/163入口と任意幅/評価163.py',
           'work/164先着確定と反転比較/比較する.py','work/165順行と回復失敗の複合/評価基盤165.py',
           'work/165順行と回復失敗の複合/出生を作る.py','work/166可用指標の階層化/local166.py',
           'work/163任意幅の数値化/arrays163.py','work/165自然独立確認/自然値を独立検算する.py',
           'work/166自然独立確認/階層と自然値を独立検算する.py','work/168数量枠の独立確認/独立人工を確認する.py',
           'work/168数量枠の因果再生/engine168.py','work/163_164正式保存/正式保存する.py']
    paths += [ROOT/name for name in names]
    archive=TRIAL/'再現資料';archive.mkdir(exist_ok=True)
    members=B.archive(archive/'Source.zip',paths)
    data=[B.reference(p) for p in INPUT.rglob('*') if p.is_file() and p.name!='保存索引.json' and '__pycache__' not in p.parts]
    B.save(INPUT/'保存索引.json',{'成功':True,'試行':167,'物理正本は一組':True,'files':data,
        'workAlias':'work/167追加七場の入力 -> inputs/00167_追加七場の入口と共用価格索引',
        '出生Alias':'work/167固定入口の別期間/全出生 -> inputs/00167_追加七場の入口と共用価格索引/固定二案の出生',
        '原Raw_CSV':'新七場の原本指紋.jsonで外部共用原本を参照。複製なし。'})
    packages={name:importlib.metadata.version(name) for name in ('numpy','tzdata')}
    B.save(archive/'保存索引.json',{'成功':True,'条件':B.reference(TRIAL/'条件.json'),
        'Source':{'archive':B.reference(archive/'Source.zip'),'members':members},
        '恒久入力':B.reference(INPUT/'保存索引.json'),'結果':[B.reference(p) for p in (TRIAL/'成果物').iterdir() if p.is_file()],
        '環境':{'Python':sys.version,'platform':platform.platform(),'packages':packages,
             'Go':(ROOT/'work/未見入口の同体接続/Go版.txt').read_text(encoding='utf-8').strip()},
        '監査':[B.reference(TRIAL/'検査/Source独立監査/Source監査の停止.json'),B.reference(TRIAL/'検査/自然独立確認/自然確認の停止.json')],
        '再現時の依存':'Source.zipの相対work配置を復元。価格参照なしの比較は恒久167入力で完結。原板再生成には固定外部Raw/CSVと旧122前史の復元を別途要する。',
        '初回exe':'停止票で指紋・Go版を保持するが実行体は再複製しない。Sourceから再ビルドする。'})
    print(json.dumps({'成功':True,'Sourceメンバー':len(members),'恒久入力ファイル':len(data),'26政策正本':True},ensure_ascii=False))


if __name__=='__main__':main()
