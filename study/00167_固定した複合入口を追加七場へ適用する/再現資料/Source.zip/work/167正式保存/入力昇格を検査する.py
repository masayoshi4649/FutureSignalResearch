"""生成入力の同一volume移動をSource・全bytes・file ID・mtimeで確認する。"""
from pathlib import Path
import argparse
import hashlib
import json
import os

ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / 'study/00167_固定した複合入口を追加七場へ適用する'
SOURCE = ROOT / 'work/167追加七場の入力'
TARGET = ROOT / 'inputs/00167_追加七場の入口と共用価格索引'


def inventory(directory: Path) -> dict:
    """
    機能: 全生成ファイルの物理指紋と移動で保持すべきstatを列挙する。
    引数: directory(Path)。
    返り値: dictは相対pathからSHA/bytes/mtime/inode/deviceへの対応。
    """
    result = {}
    for path in sorted(directory.rglob('*')):
        if not path.is_file():
            continue
        stat = path.stat()
        with path.open('rb') as source:
            digest = hashlib.file_digest(source,'sha256').hexdigest()
        result[path.relative_to(directory).as_posix()] = {'bytes':stat.st_size,'sha256':digest,
            'mtime_ns':stat.st_mtime_ns,'inode':stat.st_ino,'device':stat.st_dev}
    return result


def save(path: Path, value: dict) -> None:
    """
    機能: 昇格前後の確認票を未作成先へ保存する。
    引数: path(Path)、value(dict)。
    返り値: None。
    """
    with path.open('x',encoding='utf-8') as output:
        json.dump(value,output,ensure_ascii=False,indent=2)
        output.write('\n')


def main(phase: str) -> None:
    """
    機能: 意図したsrc/dst・未存在・同volume及び全ファイル不変を検査する。
    引数: phase(str)はbefore又はafter。
    返り値: None。不一致なら停止する。
    """
    if phase == 'before':
        assert SOURCE.is_dir() and not SOURCE.is_symlink() and not TARGET.exists()
        workspace = ROOT.resolve()
        src = SOURCE.resolve()
        dst = TARGET.parent.resolve()/TARGET.name
        assert src.is_relative_to(workspace/'work') and dst.is_relative_to(workspace/'inputs')
        assert src == workspace/'work/167追加七場の入力' and dst == workspace/'inputs/00167_追加七場の入口と共用価格索引'
        assert src.stat().st_dev == TARGET.parent.stat().st_dev
        complete = json.loads((SOURCE/'生成の完了.json').read_text(encoding='utf-8'))
        assert complete['成功'] and complete['Source前後同体'] and complete['原本指紋前後同体']
        values=inventory(SOURCE)
        assert 'F0_全段生成前.json' in values and '生成の完了.json' in values
        save(STUDY/'検査/入力昇格前.json',{'成功':True,'workspace':str(workspace),'src':str(src),'dst':str(dst),
            'dst未存在':True,'同volume':True,'単一PowerShellでMoveする':True,'files':values,
            '全bytes':sum(v['bytes'] for v in values.values()),'全ファイル':len(values)})
    else:
        before=json.loads((STUDY/'検査/入力昇格前.json').read_text(encoding='utf-8'))
        assert TARGET.is_dir() and SOURCE.is_dir() and SOURCE.resolve()==TARGET.resolve()
        current=inventory(TARGET)
        assert current == before['files']
        assert inventory(SOURCE)==current
        save(STUDY/'検査/入力昇格後.json',{'成功':True,'恒久実体':str(TARGET.resolve()),'workはjunction':str(SOURCE),
            '全SHA_bytes_fileID_mtime_device同体':True,'全ファイル':len(current),'全bytes':before['全bytes'],
            '移動前票':'入力昇格前.json','原Raw_CSV複製':False,'生成入力の物理複製':False})
        print(json.dumps({'成功':True,'全ファイル':len(current),'全bytes':before['全bytes']},ensure_ascii=False))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--phase',choices=('before','after'),required=True)
    main(parser.parse_args().phase)
