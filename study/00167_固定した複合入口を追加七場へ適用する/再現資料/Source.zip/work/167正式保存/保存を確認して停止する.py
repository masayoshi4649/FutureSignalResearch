"""167の正式入力・Source・文書・監査の参照を照合して保存停止する。"""
from pathlib import Path
import hashlib
import json
import re
import zipfile

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00167_固定した複合入口を追加七場へ適用する'
INPUT=ROOT/'inputs/00167_追加七場の入口と共用価格索引'


def reference(path: Path) -> dict:
    """
    機能: 正式確認対象の物理指紋を返す。
    引数: path(Path)。返り値: dict。
    """
    with path.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':sha}


def read(path: Path) -> dict:
    """
    機能: 固定JSONの内容を読む。
    引数: path(Path)。返り値: dict。
    """
    return json.loads(path.read_bytes())


def main() -> None:
    """
    機能: 全参照/ZIP/567セル/主要金額と独立QAの範囲を確認する。
    引数: なし。返り値: None。自然政策を再実行しない。
    """
    assert reference(TRIAL/'条件.json')['sha256']=='73e16eabfc3364a9e038d9697472abe50bb91fbba49b488dd0c8ed8d5eaea9f4'
    index=read(TRIAL/'再現資料/保存索引.json')
    records=[index['条件'],index['恒久入力'],index['Source']['archive'],*index['結果'],*index['監査']]
    records+=read(INPUT/'保存索引.json')['files']
    for value in records:assert reference(ROOT/value['path'])==value,value['path']
    with zipfile.ZipFile(ROOT/index['Source']['archive']['path']) as source:
        assert source.testzip() is None
        for value in index['Source']['members']:
            body=source.read(value['path']);assert len(body)==value['bytes'] and hashlib.sha256(body).hexdigest()==value['sha256']
    documents=[TRIAL/name for name in ('README.md','設定と結果.md','条件心理と限界.md','再現手順.md')]+[INPUT/'正本の案内.md']
    links=0
    for path in documents:
        body=path.read_text(encoding='utf-8');assert '現在未実行' not in body
        for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)',body):
            if '://' in target or target.startswith('#'):continue
            assert (path.parent/target.split('#')[0]).resolve().exists(),(str(path),target)
            links+=1
    body=(TRIAL/'設定と結果.md').read_text(encoding='utf-8')
    rows=[line for line in body.splitlines() if re.match(r'^\| [A-Z]\d{2} \|',line)]
    assert len(rows)==63 and all(len(line.split('|')[1:-1])==11 for line in rows)
    results=read(TRIAL/'成果物/全比較と全場.json')['results'];assert len(results)==26
    for record in results:
        m=record['metrics'];assert m['profit']-m['loss']==m['net'] and m['count']==m['F']+m['A']+m['N']+m['C']
        assert m['all_net'] is None if m['unknown'] else m['all_net']==m['net']
        assert len(record['sessions'])==7 and sum(row['metrics']['count'] for row in record['sessions'])==m['count']
    natural=read(TRIAL/'検査/自然独立確認/自然の独立確認.json')
    assert natural['成功'] and natural['167全政策数']==26 and natural['167全分解統計検算セル']==13520
    assert read(TRIAL/'検査/Source独立監査/Sourceと人工の確認.json')['成功']
    for value in read(TRIAL/'条件.json')['source_references'].values():
        assert reference(ROOT/value['path'])['sha256']==value['sha256']
    proof={'成功':True,'確認日':'2026-11-15','試行':167,'文書':[reference(path) for path in documents],
        '保存索引':reference(TRIAL/'再現資料/保存索引.json'),'V8手法数':63,'V8尺度数':9,'V8セル数':567,
        '全政策数':26,'全場':7,'有効な文書リンク':links,'Source全ZIP_member数':len(index['Source']['members']),
        '独立Source人工と自然QA':True,'自然独立検算の範囲':'保存NPZと原始条件から167全26政策/13520分解指標。新Raw第二parser全走査ではない。',
        '入力は単一恒久実体':True,'原Raw_CSV複製':False,'元条件_Source_F0_結果非改変':True,
        '再現wrapper':'compile/help/全参照検査。後発wrapperで自然政策全体を再実行していない。',
        'CSV_global変更':False,'PDF_xlsx生成':False}
    (TRIAL/'検査/正式保存の停止.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'停止票':reference(TRIAL/'検査/正式保存の停止.json'),'リンク':links},ensure_ascii=False))


if __name__=='__main__':main()
