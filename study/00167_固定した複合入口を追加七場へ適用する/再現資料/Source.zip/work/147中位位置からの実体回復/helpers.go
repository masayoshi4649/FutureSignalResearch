package midrecover147

import (
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
)

// finite は時計・価格・派生値の有限性を確認します。
//
// 引数: values(...float64)。返り値: boolです。
func finite(values ...float64) bool {
	for _, v := range values {
		if math.IsNaN(v) || math.IsInf(v, 0) {
			return false
		}
	}
	return true
}

// normal は受信時計を仮定せず保存された最良BBOだけを確認します。
//
// 引数: q(Quote)。返り値: boolです。
func normal(q Quote) bool { return finite(q.Bid, q.Ask) && q.Bid > 0 && q.Ask > q.Bid }

// v は有限の既知値を作り非有限値を未知へします。
//
// 引数: x(float64)。返り値: rules.Valueです。
func v(x float64) rules.Value {
	if !finite(x) {
		return rules.Value{}
	}
	return rules.Value{Known: true, Value: x}
}

// diff は既知の両端の差だけを計算します。
//
// 引数: a/b(rules.Value)。返り値: rules.Valueです。
func diff(a, b rules.Value) rules.Value {
	if !a.Known || !b.Known {
		return rules.Value{}
	}
	return v(a.Value - b.Value)
}

// rq は背景Bankの要求型へ同一価格時計を写します。
//
// 引数: q(Quote)。返り値: rules.Quoteです。
func rq(q Quote) rules.Quote {
	return rules.Quote{Time: q.Time, Index: int(q.Index), Line: int(q.SourceLine), Last: q.Last}
}

// sign はゼロを方向なしとする符号です。
//
// 引数: x(float64)。返り値: intは−1/0/1です。
func sign(x float64) int {
	if x > 0 {
		return 1
	}
	if x < 0 {
		return -1
	}
	return 0
}

// merge は参照の全値を保ちID単位で重複を除きます。
//
// 引数: groups(...[]rules.Ref)。返り値: []rules.Refです。
func merge(groups ...[]rules.Ref) []rules.Ref {
	out := []rules.Ref{}
	seen := map[string]rules.Ref{}
	for _, g := range groups {
		for _, r := range g {
			if _, ok := seen[r.ID]; !ok {
				seen[r.ID] = r
				out = append(out, r)
			}
		}
	}
	return out
}
