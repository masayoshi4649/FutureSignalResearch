package midrecover147

import (
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"testing"
)

// quote147 は価格反転でも正常BBOを保つ人工原行です。
//
// 引数: at(float64)、index(int64)、last(float64)。返り値: Quoteです。
func quote147(at float64, index int64, last float64) Quote {
	return Quote{Clock: "人工", Time: at, Index: index, SourceLine: index + 1, Last: last, Bid: last - 1, Ask: last + 1, QuoteOK: true}
}

// context147 はHistの絶対符号を条件化しない人工背景です。
//
// 引数: q(Quote)、side(int)。返り値: Contextです。
func context147(q Quote, side int) Context {
	s := float64(side)
	c := Context{At: q, Direction30: side, Fields: map[string]rules.Value{}, Refs: []rules.Ref{}, BBWindowID: "人工BB", BB15: rules.Bands{Known: true, Mean: 1000 - 5*s, Sigma: 100, Upper: 1195, Lower: 795, Count: 20}}
	if side < 0 {
		c.BB15.Upper = 1205
		c.BB15.Lower = 805
	}
	for _, key := range []string{"price_known_300", "price_known_900", "price_known_1800"} {
		c.Fields[key] = v(1)
	}
	for key, value := range map[string]float64{"gap30": s * 2, "ema21_delta30": s, "atr5": 100, "previous_atr5": 100, "tr5": 30, "ema8_5": 1000, "ema21_5": 1000 - 5*s, "hist5": -3 * s, "hist_delta5": .2 * s, "di_difference15": 3 * s, "adx15": 20, "adx_delta15": 0} {
		c.Fields[key] = v(value)
	}
	return c
}

// bars147 はp逆実体から始値回復する隣接2足を鏡像生成します。
//
// 引数: side(int)。返り値: p/r(ShortBar)です。
func bars147(side int) (ShortBar, ShortBar) {
	p := ShortBar{ID: "p", Session: "人工_Day", Contract: "X", Width: 60, Start: 0, End: 60, AvailableAt: 120, Stamp: rules.Stamp{Time: 120, Index: 1, Line: 2}, PriceKnown: true, Closed: true, VolumeKnown: true, Volume: 100, OHLC: ohlc147(1000, 1005, 985, 990)}
	r := ShortBar{ID: "r", Session: p.Session, Contract: p.Contract, Width: 60, Start: 60, End: 120, AvailableAt: 180, Stamp: rules.Stamp{Time: 180, Index: 2, Line: 3}, PriceKnown: true, Closed: true, VolumeKnown: true, Volume: 100, OHLC: ohlc147(990, 1010, 990, 1005)}
	if side < 0 {
		p.OHLC = ohlc147(1000, 1015, 995, 1010)
		r.OHLC = ohlc147(1010, 1010, 990, 995)
	}
	return p, r
}

// detector147 は将来の対照取得を持たない人工状態です。
//
// 引数: なし。返り値: *Detectorです。
func detector147() *Detector {
	return NewDetector(Scene{Session: "人工_Day", Contract: "X", Start: 0, End: 10000, ForceClose: 8000})
}

// prepared147 はpとrを別の原行で配送します。
//
// 引数: t(*testing.T)、side(int)。返り値: *Detectorです。
func prepared147(t *testing.T, side int) *Detector {
	t.Helper()
	d := detector147()
	p, r := bars147(side)
	for _, b := range []ShortBar{p, r} {
		q := quote147(b.Stamp.Time, int64(b.Stamp.Index), b.OHLC.Close)
		if err := d.observe(context147(q, side), q, []ShortBar{b}); err != nil {
			t.Fatal(err)
		}
	}
	if len(d.Events) != 1 || d.pending == nil {
		t.Fatal("出生なし", d.Checks)
	}
	return d
}

// Test147鏡像と実P はHist絶対符号が逆でも実増分・実体回復で出生します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test147鏡像と実P(t *testing.T) {
	for _, side := range []int{1, -1} {
		d := prepared147(t, side)
		e := d.Events[0]
		if e.Structure.K != 1000 || e.Structure.Width != 25 || e.Structure.Cap != 70 {
			t.Fatal(e.Structure)
		}
		q := quote147(181, 3, 1000+5*float64(side))
		if err := d.observe(context147(q, side), q, nil); err != nil {
			t.Fatal(err)
		}
		if e.Status != "filled" || e.EntryPrice == nil || *e.EntryPrice != 1000+6*float64(side) {
			t.Fatal(e)
		}
	}
}

// Test147凍結pと同Raw拒否 は初知不足を後のrで補いません。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test147凍結pと同Raw拒否(t *testing.T) {
	d := detector147()
	p, r := bars147(1)
	q := quote147(120, 1, 990)
	c := context147(q, 1)
	c.BB15.Known = false
	if err := d.observe(c, q, []ShortBar{p}); err != nil {
		t.Fatal(err)
	}
	q = quote147(180, 2, 1005)
	if err := d.observe(context147(q, 1), q, []ShortBar{r}); err != nil {
		t.Fatal(err)
	}
	if len(d.Events) != 0 {
		t.Fatal("p初知を補完")
	}
	d = detector147()
	p.Stamp = r.Stamp
	q = quote147(180, 2, 1005)
	if err := d.observe(context147(q, 1), q, []ShortBar{p, r}); err != nil {
		t.Fatal(err)
	}
	if len(d.Checks) != 1 || len(d.Events) != 0 || d.Checks[0].Gates["p_r初配送strict"].Value != 0 {
		t.Fatal(d.Checks)
	}
}

// Test147最初正常と期限 は実PのBB余地不足と等号期限を拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test147最初正常と期限(t *testing.T) {
	for _, which := range []string{"実P域外", "期限", "不正常I"} {
		d := prepared147(t, 1)
		e := d.Events[0]
		q := quote147(181, 3, 1005)
		if which == "実P域外" {
			q.Last = 1070
			q.Bid = 1069
			q.Ask = 1071
		}
		if which == "期限" {
			q.Time = e.Expires
		}
		if which == "不正常I" {
			q.Last = e.Structure.I
			q.QuoteOK = false
			q.Bid = 0
			q.Ask = 0
		}
		if err := d.observe(context147(q, 1), q, nil); err != nil {
			t.Fatal(err)
		}
		want := map[string]string{"実P域外": "entry_position_rejected", "期限": "unfilled_expired", "不正常I": "invalidation_reached"}[which]
		if e.Status != want {
			t.Fatal(which, e.Status, e.Reasons)
		}
	}
}

// Test147pendingの背景と最新未知 は新足/背景未知から古い値へfallbackしません。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test147pendingの背景と最新未知(t *testing.T) {
	for _, which := range []string{"背景未知", "最新未知"} {
		d := prepared147(t, 1)
		q := quote147(181, 3, 1005)
		c := context147(q, 1)
		batch := []ShortBar{}
		if which == "背景未知" {
			c.Fields["hist_delta5"] = rules.Value{}
		} else {
			_, r := bars147(1)
			r.ID = "unknown"
			r.Start = 120
			r.End = 180
			r.AvailableAt = 240
			r.Stamp = rules.Stamp{Time: 240, Index: 3, Line: 4}
			r.PriceKnown = false
			q = quote147(240, 3, 1005)
			c = context147(q, 1)
			batch = []ShortBar{r}
			d.Events[0].Expires = 270
		}
		if err := d.observe(c, q, batch); err != nil {
			t.Fatal(err)
		}
		if d.Events[0].Status == "filled" || d.pending != nil {
			t.Fatal(d.Events)
		}
	}
}

// Test147BB余地境界 は端まで125pt等号・負cap・幅の役割を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test147BB余地境界(t *testing.T) {
	s := Structure{K: 1000, I: 975, Width: 25, Cap: 70, ArmATR: 100, BBMean: 995, BBForward: 1195}
	if !position(1, 1070, s) || position(1, 1071, s) || position(1, 994, s) {
		t.Fatal("位置境界")
	}
	d := detector147()
	p, r := bars147(1)
	q := quote147(120, 1, 990)
	c := context147(q, 1)
	c.BB15.Upper = 1124
	if err := d.observe(c, q, []ShortBar{p}); err != nil {
		t.Fatal(err)
	}
	q = quote147(180, 2, 1005)
	if err := d.observe(context147(q, 1), q, []ShortBar{r}); err != nil {
		t.Fatal(err)
	}
	if len(d.Events) != 0 || d.Checks[1].Status != "target_room_rejected" {
		t.Fatal(d.Checks)
	}
}
