package main

import (
	"encoding/json"
	"flag"
	"fmt"
	source "midrecover147"
	"os"
)

// main はF0後だけ固定参照の中位実体回復Sourceを未作成先へ生成します。
//
// 引数: CLIのinput/sha256/output/workers/execute-after-f0。返り値: ありません。不整合は終了1です。
func main() {
	input := flag.String("input", "", "147入力参照")
	sha := flag.String("sha256", "", "小参照SHA")
	output := flag.String("output", "", "未作成出力")
	workers := flag.Int("workers", 1, "互換指定。実効1")
	execute := flag.Bool("execute-after-f0", false, "F0後明示実行")
	flag.Parse()
	fail := func(err error) { fmt.Fprintln(os.Stderr, err); os.Exit(1) }
	if !*execute || *input == "" || *output == "" || flag.NArg() != 0 {
		fail(fmt.Errorf("F0後明示指定と全引数が必要"))
	}
	if _, err := os.Stat(*output); !os.IsNotExist(err) {
		fail(fmt.Errorf("未作成出力だけ許可"))
	}
	scenes, err := source.Load(*input, *sha)
	if err != nil {
		fail(err)
	}
	result, err := source.Generate(scenes, *workers, true)
	if err != nil {
		fail(err)
	}
	result.InputSHA = *sha
	if _, err = source.Load(*input, *sha); err != nil {
		fail(err)
	}
	body, err := json.MarshalIndent(result, "", "  ")
	if err != nil {
		fail(err)
	}
	f, err := os.OpenFile(*output, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		fail(err)
	}
	if _, err = f.Write(append(body, '\n')); err != nil {
		f.Close()
		fail(err)
	}
	if err = f.Close(); err != nil {
		fail(err)
	}
	fmt.Printf("147 Source成功 場=%d 候補=%d 物理取得=%d\n", len(result.Scenes), result.Summary["候補数"], result.Summary["物理取得数"])
}
