package midrecover147

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"testing"
)

// pubContext147 は自然価格を使わない背景票を作ります。
//
// 引数: width(int)、end(float64)、index(int)、close(float64)。返り値: rules.Publicationです。
func pubContext147(width int, end float64, index int, close float64) rules.Publication {
	p := rules.Publication{}
	p.Stamp = rules.Stamp{Time: end + 60, Index: index, Line: index + 1}
	f := &p.Frame.Frame
	f.ID = fmt.Sprintf("p%d/%.0f", width, end)
	f.SessionID = "人工_Day"
	f.Contract = "X"
	f.Width = width
	f.Start = end - float64(width)
	f.End = end
	f.AvailableAt = end + 60
	f.DeliveryAt = end + 60
	f.PriceKnown = true
	f.OHLC = ohlc147(close, close+1, close-1, close)
	f.VolumeKnown = true
	f.Volume = 100
	f.Technical = rules.Technical{EMA8: v(1010), EMA21: v(1000), EMA21Delta: v(1), Gap: v(10), ATR: v(100), TR: v(10), Histogram: v(-2), PreviousHistogram: v(-3)}
	p.Frame.DMI.PlusDI = v(20)
	p.Frame.DMI.MinusDI = v(10)
	p.Frame.DMI.ADX = v(20)
	p.Frame.DMI.PreviousADX = v(19)
	return p
}

// cacheContext147 はBB20と同場の実前5/15公表を用意します。
//
// 引数: t(*testing.T)、declaredUnknown/mismatch(bool)。返り値: *Publications/rules.Snapshot/Quoteです。
func cacheContext147(t *testing.T, declaredUnknown, mismatch bool) (*Publications, rules.Snapshot, Quote) {
	t.Helper()
	cache := NewPublications()
	bank := rules.NewBank()
	if err := cache.StartSession("人工_Day", "X"); err != nil {
		t.Fatal(err)
	}
	if err := bank.StartSession("人工_Day", "X"); err != nil {
		t.Fatal(err)
	}
	add := func(p rules.Publication) {
		if err := bank.Add(p); err != nil {
			t.Fatal(err)
		}
		if err := cache.Record(p); err != nil {
			t.Fatal(err)
		}
	}
	for i := 1; i <= 20; i++ {
		p := pubContext147(900, float64(i*900), i, 1000+float64(i))
		if i == 19 {
			p.Frame.DMI.ADX = v(19)
		}
		if i == 20 && declaredUnknown {
			p.Frame.DMI.PreviousADX = rules.Value{}
		}
		if i == 20 && mismatch {
			p.Frame.DMI.PreviousADX = v(18)
		}
		add(p)
	}
	prior := pubContext147(300, 17700, 21, 1000)
	prior.Frame.Frame.Technical.Histogram = v(-3)
	add(prior)
	current := pubContext147(300, 18000, 22, 1000)
	if declaredUnknown {
		current.Frame.Frame.Technical.PreviousHistogram = rules.Value{}
	}
	if mismatch {
		current.Frame.Frame.Technical.PreviousHistogram = v(-4)
	}
	add(current)
	add(pubContext147(1800, 18000, 23, 1000))
	q := quote147(18060, 24, 1000)
	snapshot, err := bank.Current(rq(q))
	if err != nil {
		t.Fatal(err)
	}
	return cache, snapshot, q
}

// Test147実前照合とBB正本 は現在値/実前/20元refを保存し、既知不一致を拒否します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test147実前照合とBB正本(t *testing.T) {
	cache, snapshot, q := cacheContext147(t, false, false)
	c, err := makeContext(snapshot, q, cache)
	if err != nil {
		t.Fatal(err)
	}
	if !c.Fields["hist_delta5"].Known || c.Fields["hist_delta5"].Value != 1 || c.Fields["adx_delta15"].Value != 1 || len(c.Refs) != 5 {
		t.Fatal(c)
	}
	w, ok := cache.Window(c.BBWindowID)
	if !ok || len(w.Refs) != 20 || w.Bands != snapshot.BB15 {
		t.Fatal(w)
	}
	cache, snapshot, q = cacheContext147(t, false, true)
	if _, err = makeContext(snapshot, q, cache); err == nil {
		t.Fatal("宣言Previous不一致を受理")
	}
}

// Test147宣言未知を実前で補完しない は同場に値があっても未知を保持します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test147宣言未知を実前で補完しない(t *testing.T) {
	cache, snapshot, q := cacheContext147(t, true, false)
	c, err := makeContext(snapshot, q, cache)
	if err != nil {
		t.Fatal(err)
	}
	if c.Fields["hist_delta5"].Known || c.Fields["adx_delta15"].Known {
		t.Fatal(c.Fields)
	}
	if !c.Fields["actual_previous_hist5"].Known || !c.Fields["actual_previous_adx15"].Known {
		t.Fatal("実前の原値も消えた")
	}
	if gatesPass(currentGates(c, 1)) {
		t.Fatal("未知gateを受理")
	}
}

// Test147後着抑止と欠足 は既pendingの終了Rawも新rを再発注しません。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test147後着抑止と欠足(t *testing.T) {
	d := prepared147(t, 1)
	p, r := bars147(1)
	_ = p
	q := quote147(181, 3, 1005)
	r.ID = "後着"
	r.Stamp = rules.Stamp{Time: 181, Index: 3, Line: 4}
	if err := d.observe(context147(q, 1), q, []ShortBar{r}); err != nil {
		t.Fatal(err)
	}
	if d.Events[0].Status != "filled" || d.pending != nil || !d.Checks[len(d.Checks)-1].Suppressed || !d.processed["後着"] {
		t.Fatal(d.Checks, d.Events)
	}
	d = detector147()
	p, r = bars147(1)
	q = quote147(120, 1, 990)
	if err := d.observe(context147(q, 1), q, []ShortBar{p}); err != nil {
		t.Fatal(err)
	}
	r.Start += 60
	r.End += 60
	r.AvailableAt += 60
	r.Stamp = rules.Stamp{Time: 240, Index: 2, Line: 3}
	q = quote147(240, 2, 1005)
	if err := d.observe(context147(q, 1), q, []ShortBar{r}); err != nil {
		t.Fatal(err)
	}
	if len(d.Events) != 0 || d.Checks[len(d.Checks)-1].Gates["当場隣接p_r"].Value != 0 {
		t.Fatal("欠分を連結")
	}
}
