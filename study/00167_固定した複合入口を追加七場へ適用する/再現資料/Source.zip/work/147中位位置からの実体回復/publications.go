package midrecover147

import (
	"fmt"
	"math"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

type evidenceSample147 struct {
	Ref   rules.Ref
	Close rules.Value
}

// Publications は、Bank.Add成功後の同順公表から実前値とBB窓の証拠だけを保持します。
// Bank自体や売買条件は変更せず、次場へ進む品質成功/場順は呼出側が保証します。
type Publications struct {
	session, contract string
	seen              map[string]rules.Publication
	last              map[int]rules.Publication
	previous          map[string]rules.Publication
	window15          []evidenceSample147
	canonical         map[string]BBWindow
	order             []string
}

// NewPublications は、空の公表証拠cacheを作ります。
//
// 引数: ありません。
// 返り値: *Publications は初回coldで外部共有のない状態です。
func NewPublications() *Publications {
	return &Publications{seen: map[string]rules.Publication{}, last: map[int]rules.Publication{},
		previous: map[string]rules.Publication{}, window15: []evidenceSample147{}, canonical: map[string]BBWindow{}, order: []string{}}
}

// StartSession は、同限月のBB数値窓だけを継承し当場の正本と実前対応を初期化します。
//
// 引数: session/contract(string)は当場IDと限月です。
// 返り値: error は空識別子又は同場再開始の拒否です。異限月はcoldになります。
func (c *Publications) StartSession(session, contract string) error {
	if session == "" || contract == "" || (c.session == session && c.contract == contract) {
		return fmt.Errorf("公表証拠の場/限月が空又は同場再開始")
	}
	next := *c
	if next.seen == nil || (c.contract != "" && c.contract != contract) {
		next = *NewPublications()
	}
	next.session, next.contract = session, contract
	next.previous = map[string]rules.Publication{}
	next.canonical = map[string]BBWindow{}
	next.order = []string{}
	*c = next
	return nil
}

// publicationFinite147 は、証拠時計と既知価格の有限性を調べます。
//
// 引数: value(float64)は一つの確認値です。
// 返り値: bool は有限なら真です。
func publicationFinite147(value float64) bool {
	return !math.IsNaN(value) && !math.IsInf(value, 0)
}

// publicationRef147 は、公表ID/足幅/End/実配送を値copyへ結びます。
//
// 引数: p(rules.Publication)はBank.Add済みの公表です。
// 返り値: rules.Ref は同じ公表の参照です。
func publicationRef147(p rules.Publication) rules.Ref {
	f := p.Frame.Frame
	return rules.Ref{ID: f.ID, Width: f.Width, End: f.End, Delivered: p.Stamp}
}

// evidenceBands147 は、118Bank.bandsと同じ演算順で20公表の母σ帯を求めます。
//
// 引数: window([]evidenceSample147)は未知closeも除外しない最大20公表です。
// 返り値: rules.Bands は不足/未知をknown=false、全20既知を母分散で計算した値です。
func evidenceBands147(window []evidenceSample147) rules.Bands {
	result := rules.Bands{Count: len(window)}
	if len(window) != 20 {
		return result
	}
	origin := window[0].Close.Value
	sum := 0.0
	for _, sample := range window {
		if !sample.Close.Known {
			return result
		}
		sum += sample.Close.Value - origin
	}
	mean := sum / 20
	variance := 0.0
	for _, sample := range window {
		delta := (sample.Close.Value - origin) - mean
		variance += delta * delta
	}
	result.Known = true
	result.Mean = origin + mean
	result.Sigma = math.Sqrt(variance / 20)
	result.Upper = result.Mean + 2*result.Sigma
	result.Lower = result.Mean - 2*result.Sigma
	return result
}

// Record は、Bank.Add成功直後の同順公表を一度だけ証拠へ反映します。
//
// 引数: p(rules.Publication)は当場/同限月の正常な公表です。
// 返り値: error は同ID改変・後退・不正時計等で、拒否時はcacheを変更しません。
func (c *Publications) Record(p rules.Publication) error {
	f := p.Frame.Frame
	if c.session == "" || f.SessionID != c.session || f.Contract != c.contract || f.ID == "" || (f.Width != 300 && f.Width != 900 && f.Width != 1800) {
		return fmt.Errorf("公表証拠の場/限月/ID/幅が不正")
	}
	if !publicationFinite147(f.Start) || !publicationFinite147(f.End) || !publicationFinite147(f.AvailableAt) || !publicationFinite147(f.DeliveryAt) || !publicationFinite147(p.Stamp.Time) || f.Start > f.End || f.End > f.AvailableAt || f.AvailableAt > f.DeliveryAt || f.DeliveryAt > p.Stamp.Time || p.Stamp.Index < 0 || p.Stamp.Line < 1 {
		return fmt.Errorf("公表証拠の因果時計が不正")
	}
	if f.PriceKnown && (!publicationFinite147(f.OHLC.Close) || f.OHLC.Close <= 0) {
		return fmt.Errorf("公表証拠の既知終値が不正")
	}
	if previous, exists := c.seen[f.ID]; exists {
		if previous != p {
			return fmt.Errorf("同公表IDの改変")
		}
		return nil
	}
	last, hasLast := c.last[f.Width]
	if hasLast {
		old := last.Frame.Frame
		if f.End <= old.End || p.Stamp.Time < last.Stamp.Time || (old.SessionID == f.SessionID && (p.Stamp.Index < last.Stamp.Index || p.Stamp.Line < last.Stamp.Line)) {
			return fmt.Errorf("公表証拠の時計/配送が後退")
		}
	}
	// ----------------------------------------
	// 実前の対応とBB候補を局所値へ作り、全検査成功後にだけ消費します。
	adjacent := hasLast && last.Frame.Frame.SessionID == f.SessionID && last.Frame.Frame.Contract == f.Contract && f.End-last.Frame.Frame.End == float64(f.Width)
	var nextWindow []evidenceSample147
	var canonical BBWindow
	if f.Width == 900 {
		nextWindow = append([]evidenceSample147{}, c.window15...)
		if hasLast && last.Frame.Frame.SessionID == f.SessionID && !adjacent {
			nextWindow = []evidenceSample147{}
		}
		nextWindow = append(nextWindow, evidenceSample147{Ref: publicationRef147(p), Close: rules.Value{Known: f.PriceKnown, Value: f.OHLC.Close}})
		if len(nextWindow) > 20 {
			nextWindow = append([]evidenceSample147{}, nextWindow[len(nextWindow)-20:]...)
		}
		canonical = BBWindow{ID: f.ID, Bands: evidenceBands147(nextWindow), Refs: []rules.Ref{}}
		if canonical.Bands.Known && (!publicationFinite147(canonical.Bands.Mean) || !publicationFinite147(canonical.Bands.Sigma) || !publicationFinite147(canonical.Bands.Upper) || !publicationFinite147(canonical.Bands.Lower)) {
			return fmt.Errorf("BB証拠の既知計算が非有限")
		}
		for _, sample := range nextWindow {
			canonical.Refs = append(canonical.Refs, sample.Ref)
		}
	}
	// ----------------------------------------
	// 当場canonicalはIDごと一票、同限月の数値窓は次場へだけ継承します。
	c.seen[f.ID] = p
	c.last[f.Width] = p
	if adjacent {
		c.previous[f.ID] = last
	}
	if f.Width == 900 {
		c.window15 = nextWindow
		c.canonical[f.ID] = canonical
		c.order = append(c.order, f.ID)
	}
	return nil
}

// Previous は、当場同限月の同幅・厳密隣接の実前公表を返します。
//
// 引数: p(rules.Publication)は既にRecordした現在公表です。
// 返り値: rules.Publication/bool は実前値copyと存在。未知の技法値を既知へ補完しません。
func (c *Publications) Previous(p rules.Publication) (rules.Publication, bool) {
	f := p.Frame.Frame
	stored, seen := c.seen[f.ID]
	previous, exists := c.previous[f.ID]
	if !seen || stored != p || !exists || f.SessionID != c.session || f.Contract != c.contract {
		return rules.Publication{}, false
	}
	return previous, true
}

// copyWindow147 は、参照sliceを外部から変更できないcopyへします。
//
// 引数: window(BBWindow)は保存された正本です。
// 返り値: BBWindow は同じ帯と独立した参照sliceです。
func copyWindow147(window BBWindow) BBWindow {
	window.Refs = append([]rules.Ref{}, window.Refs...)
	return window
}

// Window は、公表IDに対応した当場のBB正本を返します。
//
// 引数: id(string)は15分公表IDです。
// 返り値: BBWindow/bool は帯/全元refsのcopyと存在。known=falseの正本も保存します。
func (c *Publications) Window(id string) (BBWindow, bool) {
	window, exists := c.canonical[id]
	if !exists {
		return BBWindow{}, false
	}
	return copyWindow147(window), true
}

// Windows は、当場に記録した15分公表のcanonicalだけを配送順で返します。
//
// 引数: ありません。
// 返り値: []BBWindow は外部変更が内部へ伝わらないcopyです。
func (c *Publications) Windows() []BBWindow {
	result := []BBWindow{}
	for _, id := range c.order {
		result = append(result, copyWindow147(c.canonical[id]))
	}
	return result
}
