package midrecover147

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// makeContext は当時の3背景・実前両端・BB正本IDを初知時に凍結します。
//
// 引数: s(rules.Snapshot)、q(Quote)、cache(*Publications)。返り値: Context/errorです。
func makeContext(s rules.Snapshot, q Quote, cache *Publications) (Context, error) {
	c := Context{At: q, Fields: map[string]rules.Value{}, Refs: append([]rules.Ref(nil), s.Refs...)}
	for _, w := range []int{300, 900, 1800} {
		p, ok := s.Frames[w]
		c.Fields[fmt.Sprintf("price_known_%d", w)] = v(0)
		if ok && p.Frame.Frame.PriceKnown && q.Time < p.Frame.Frame.End+float64(w)+60 {
			c.Fields[fmt.Sprintf("price_known_%d", w)] = v(1)
		}
	}
	t30 := s.Frames[1800].Frame.Frame.Technical
	c.Fields["gap30"], c.Fields["ema21_delta30"] = t30.Gap, t30.EMA21Delta
	if t30.Gap.Known && t30.EMA21Delta.Known && sign(t30.Gap.Value) != 0 && sign(t30.Gap.Value) == sign(t30.EMA21Delta.Value) {
		c.Direction30 = sign(t30.Gap.Value)
	}
	// ----------------------------------------
	// 5分は同場の実前公表と宣言Previousを照合してから増分を作ります。
	p5, has5 := s.Frames[300]
	t5 := p5.Frame.Frame.Technical
	c.Fields["atr5"], c.Fields["tr5"], c.Fields["ema8_5"], c.Fields["ema21_5"] = t5.ATR, t5.TR, t5.EMA8, t5.EMA21
	c.Fields["hist5"], c.Fields["declared_previous_hist5"] = t5.Histogram, t5.PreviousHistogram
	c.Fields["previous_hist5"], c.Fields["hist_delta5"], c.Fields["previous_atr5"] = rules.Value{}, rules.Value{}, rules.Value{}
	if has5 {
		if prior, ok := cache.Previous(p5); ok {
			f := prior.Frame.Frame
			c.Refs = merge(c.Refs, []rules.Ref{{ID: f.ID, Width: 300, End: f.End, Delivered: prior.Stamp}})
			real := f.Technical.Histogram
			c.Fields["actual_previous_hist5"] = real
			if real.Known && t5.PreviousHistogram.Known {
				if real.Value != t5.PreviousHistogram.Value {
					return c, fmt.Errorf("宣言前Histと実前5分の値不一致")
				}
				c.Fields["previous_hist5"] = real
				c.Fields["hist_delta5"] = diff(t5.Histogram, real)
			}
			c.Fields["previous_atr5"] = f.Technical.ATR
		}
	}
	// ----------------------------------------
	// 15分の強さとBB窓はそれぞれ独立した参照へ束縛します。
	p15, has15 := s.Frames[900]
	d := p15.Frame.DMI
	c.Fields["di_difference15"] = diff(d.PlusDI, d.MinusDI)
	c.Fields["adx15"], c.Fields["declared_previous_adx15"] = d.ADX, d.PreviousADX
	c.Fields["previous_adx15"], c.Fields["adx_delta15"] = rules.Value{}, rules.Value{}
	if has15 {
		if prior, ok := cache.Previous(p15); ok {
			f := prior.Frame.Frame
			c.Refs = merge(c.Refs, []rules.Ref{{ID: f.ID, Width: 900, End: f.End, Delivered: prior.Stamp}})
			real := prior.Frame.DMI.ADX
			c.Fields["actual_previous_adx15"] = real
			if real.Known && d.PreviousADX.Known {
				if real.Value != d.PreviousADX.Value {
					return c, fmt.Errorf("宣言前ADXと実前15分の値不一致")
				}
				c.Fields["previous_adx15"] = real
				c.Fields["adx_delta15"] = diff(d.ADX, real)
			}
		}
		window, ok := cache.Window(p15.Frame.Frame.ID)
		if !ok || window.Bands != s.BB15 {
			return c, fmt.Errorf("BB正本窓と118Bank値不一致")
		}
		c.BBWindowID = window.ID
		c.BB15 = window.Bands
	}
	for _, r := range c.Refs {
		if r.Delivered.Time > q.Time || r.Delivered.Index > int(q.Index) || r.Delivered.Line > int(q.SourceLine) {
			return c, fmt.Errorf("Context実前参照が未来")
		}
	}
	return c, nil
}

// validCurrent はSnapshotの範囲と利用可能時計を現在Rawへ照合します。
//
// 引数: snapshot(rules.Snapshot)、q(Quote)、scene(Scene)。返り値: errorです。
func validCurrent(snapshot rules.Snapshot, q Quote, scene Scene) error {
	if snapshot.SessionID != scene.Session || snapshot.Contract != scene.Contract || snapshot.AsOf != rq(q) {
		return fmt.Errorf("現在Snapshotのscope/原行差")
	}
	for width, p := range snapshot.Frames {
		f := p.Frame.Frame
		if f.SessionID != scene.Session || f.Contract != scene.Contract || f.Width != width || (width != 300 && width != 900 && width != 1800) || f.End > q.Time || f.End > f.AvailableAt || f.AvailableAt > f.DeliveryAt || f.DeliveryAt > p.Stamp.Time || p.Stamp.Time > q.Time || p.Stamp.Index > int(q.Index) || p.Stamp.Line > int(q.SourceLine) {
			return fmt.Errorf("背景の未来参照又はscope差")
		}
	}
	return nil
}

// currentGates は出生後も必要な現在背景を同じ条件名で列挙します。
//
// 引数: c(Context)、side(int)。返り値: map[string]rules.Valueです。
func currentGates(c Context, side int) map[string]rules.Value {
	g := map[string]rules.Value{}
	for _, w := range []int{300, 900, 1800} {
		g[fmt.Sprintf("現在%d価格fresh", w)] = c.Fields[fmt.Sprintf("price_known_%d", w)]
	}
	x, y := c.Fields["gap30"], c.Fields["ema21_delta30"]
	g["現在30方向"] = test(x.Known && y.Known, side != 0 && c.Direction30 == side)
	x = c.Fields["di_difference15"]
	g["現在15DI方向"] = test(x.Known, float64(side)*x.Value > 0)
	x = c.Fields["adx_delta15"]
	g["現在15ADX非低下"] = test(x.Known, x.Value >= 0)
	x = c.Fields["hist_delta5"]
	g["現在5Hist実改善"] = test(x.Known, float64(side)*x.Value > 0)
	x, y = c.Fields["tr5"], c.Fields["previous_atr5"]
	g["現在5TR急変ガード"] = test(x.Known && y.Known, x.Value >= 0 && y.Value > 0 && x.Value <= 2*y.Value)
	return g
}

// test は未知と既知の偽を別の値にします。
//
// 引数: known/pass(bool)。返り値: rules.Valueです。
func test(known, pass bool) rules.Value {
	if !known {
		return rules.Value{}
	}
	if pass {
		return v(1)
	}
	return v(0)
}

// gatesPass はすべて既知の成立である場合だけ真にします。
//
// 引数: gates(map[string]rules.Value)。返り値: boolです。
func gatesPass(gates map[string]rules.Value) bool {
	for _, x := range gates {
		if !x.Known || x.Value != 1 {
			return false
		}
	}
	return true
}

// position は固定K/capとBB中心/順端までの余地を同じ実価格に要求します。
//
// 引数: side(int)、price(float64)、s(Structure)。返り値: boolです。
func position(side int, price float64, s Structure) bool {
	x := float64(side)
	d := x * (price - s.K)
	center, room := x*(price-s.BBMean), x*(s.BBForward-price)
	return finite(price, d, center, room) && d >= 0 && d <= s.Cap && center >= 0 && room >= 125
}
