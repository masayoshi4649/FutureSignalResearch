package midrecover147

import (
	"encoding/json"
	"fmt"
	"math"
	"testing"

	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
)

// evidencePublication147 は、自然データを使わない正常な公表を作ります。
//
// 引数: session/contract(string)、width(int)、end(float64)、index(int)、close(float64)は架空公表の指定です。
// 返り値: rules.Publication はEnd+60で配送する架空値です。
func evidencePublication147(session, contract string, width int, end float64, index int, close float64) rules.Publication {
	return rules.Publication{Stamp: rules.Stamp{Time: end + 60, Index: index, Line: index + 1}, Frame: rules.Frame{Frame: rules.ChartFrame{
		ID: fmt.Sprintf("%s/%d/%.0f", session, width, end), SessionID: session, Contract: contract, Width: width,
		Start: end - float64(width), End: end, AvailableAt: end + 60, DeliveryAt: end + 60, PriceKnown: true, VolumeKnown: true,
		OHLC: rules.OHLC{Open: close, High: close + 1, Low: close - 1, Close: close}, Volume: 10}}}
}

// mustRecordEvidence147 は、純cache人工の正常記録を実行します。
//
// 引数: t(*testing.T)、cache(*Publications)、p(rules.Publication)は検査と架空公表です。
// 返り値: ありません。拒否時は検査を失敗にします。
func mustRecordEvidence147(t *testing.T, cache *Publications, p rules.Publication) {
	t.Helper()
	if err := cache.Record(p); err != nil {
		t.Fatal(err)
	}
}

// TestEvidence147MatchesBank は、20本母分散と不足/σ0を旧Bankへ厳密照合します。
//
// 引数: t(*testing.T)は純人工です。
// 返り値: ありません。旧Bank自体は編集しません。
func TestEvidence147MatchesBank(t *testing.T) {
	for _, flat := range []bool{false, true} {
		cache, bank := NewPublications(), rules.NewBank()
		if err := cache.StartSession("S", "C"); err != nil {
			t.Fatal(err)
		}
		if err := bank.StartSession("S", "C"); err != nil {
			t.Fatal(err)
		}
		for i := 1; i <= 35; i++ {
			close := 10000.0
			if !flat {
				close += float64(i*i) + float64(i)/7
			}
			p := evidencePublication147("S", "C", 900, float64(i*900), i, close)
			if err := bank.Add(p); err != nil {
				t.Fatal(err)
			}
			mustRecordEvidence147(t, cache, p)
			snapshot, err := bank.Current(rules.Quote{Time: p.Stamp.Time, Index: i, Line: i + 1, Last: close})
			if err != nil {
				t.Fatal(err)
			}
			window, exists := cache.Window(p.Frame.Frame.ID)
			if !exists || window.Bands != snapshot.BB15 {
				t.Fatal("Bankとの厳密差", i, window, snapshot.BB15)
			}
			if window.Bands.Count != len(window.Refs) || window.Bands.Known != (i >= 20) {
				t.Fatal("助走/参照本数差")
			}
			if flat && i >= 20 && window.Bands.Sigma != 0 {
				t.Fatal("σ0を別の値へ変換")
			}
			for _, ref := range window.Refs {
				if ref.End > p.Frame.Frame.End || ref.Delivered.Time > p.Stamp.Time || ref.Delivered.Index > p.Stamp.Index {
					t.Fatal("未来の窓参照")
				}
			}
		}
	}
}

// TestEvidence147PreviousIsActual は、5/15実前参照・unknown・同Raw・欠分を分けます。
//
// 引数: t(*testing.T)は純人工です。
// 返り値: ありません。宣言Previousの未知をこの部品で補完しません。
func TestEvidence147PreviousIsActual(t *testing.T) {
	for _, width := range []int{300, 900} {
		cache := NewPublications()
		_ = cache.StartSession("S", "C")
		p := evidencePublication147("S", "C", width, float64(width), 1, 100)
		p.Stamp = rules.Stamp{Time: float64(2*width + 60), Index: 2, Line: 3}
		p.Frame.Frame.DeliveryAt = p.Stamp.Time
		p.Frame.Frame.Technical.Histogram = rules.Value{}
		mustRecordEvidence147(t, cache, p)
		q := evidencePublication147("S", "C", width, float64(2*width), 2, 110)
		q.Frame.Frame.Technical.PreviousHistogram = rules.Value{Known: true, Value: 999}
		mustRecordEvidence147(t, cache, q)
		previous, exists := cache.Previous(q)
		if !exists || previous != p || previous.Frame.Frame.Technical.Histogram.Known {
			t.Fatal("実前未知を宣言値へ置換")
		}
		changed := q
		changed.Frame.Frame.Technical.Histogram = rules.Value{Known: true, Value: 5}
		if _, exists = cache.Previous(changed); exists {
			t.Fatal("未記録の改変pubへ実前を付与")
		}
		gap := evidencePublication147("S", "C", width, float64(4*width), 3, 120)
		mustRecordEvidence147(t, cache, gap)
		if _, exists = cache.Previous(gap); exists {
			t.Fatal("欠分を飛ばして実前を代用")
		}
	}
}

// TestEvidence147CarryAndScope は、同限月BB窓と当場実前/正本の境界を検査します。
//
// 引数: t(*testing.T)は純人工です。
// 返り値: ありません。
func TestEvidence147CarryAndScope(t *testing.T) {
	cache := NewPublications()
	_ = cache.StartSession("A", "C")
	for i := 1; i <= 20; i++ {
		mustRecordEvidence147(t, cache, evidencePublication147("A", "C", 900, float64(i*900), i, 1000+float64(i)))
	}
	if err := cache.StartSession("B", "C"); err != nil {
		t.Fatal(err)
	}
	if len(cache.Windows()) != 0 {
		t.Fatal("前場canonicalを当場へ転記")
	}
	p := evidencePublication147("B", "C", 900, 40000, 1, 1100)
	mustRecordEvidence147(t, cache, p)
	window, exists := cache.Window(p.Frame.Frame.ID)
	if !exists || !window.Bands.Known || len(window.Refs) != 20 || window.Refs[0].ID != "A/900/1800" {
		t.Fatal("同限月20窓を継承しない", window)
	}
	if _, ok := cache.Previous(p); ok {
		t.Fatal("跨場を実前15分にした")
	}
	if _, ok := cache.Window("A/900/18000"); ok {
		t.Fatal("Windowが前場正本を返した")
	}
	_ = cache.StartSession("C", "NEXT")
	p = evidencePublication147("C", "NEXT", 900, 50000, 1, 1000)
	mustRecordEvidence147(t, cache, p)
	window, _ = cache.Window(p.Frame.Frame.ID)
	if window.Bands.Count != 1 || window.Bands.Known {
		t.Fatal("異限月の窓を継承")
	}
}

// TestEvidence147UnknownAndGap は、未知closeを除外せず20本後まで保持することを確認します。
//
// 引数: t(*testing.T)は純人工です。
// 返り値: ありません。
func TestEvidence147UnknownAndGap(t *testing.T) {
	cache := NewPublications()
	_ = cache.StartSession("S", "C")
	for i := 1; i <= 20; i++ {
		mustRecordEvidence147(t, cache, evidencePublication147("S", "C", 900, float64(i*900), i, 1000))
	}
	p := evidencePublication147("S", "C", 900, 19800, 21, 1000)
	mustRecordEvidence147(t, cache, p)
	window, _ := cache.Window(p.Frame.Frame.ID)
	if window.Bands.Count != 1 || window.Bands.Known {
		t.Fatal("当場欠分で窓を切らない")
	}
	p = evidencePublication147("S", "C", 900, 20700, 22, 1000)
	p.Frame.Frame.PriceKnown = false
	p.Frame.Frame.OHLC = rules.OHLC{}
	mustRecordEvidence147(t, cache, p)
	for i := 1; i <= 20; i++ {
		p = evidencePublication147("S", "C", 900, 20700+float64(i*900), 22+i, 1000+float64(i))
		mustRecordEvidence147(t, cache, p)
		window, _ = cache.Window(p.Frame.Frame.ID)
		if window.Bands.Known != (i == 20) {
			t.Fatal("未知足を除外又は前値で補完", i, window.Bands)
		}
	}
}

// TestEvidence147CanonicalCopy は、同IDの不増/改変拒否と公開正本の未来不変を確認します。
//
// 引数: t(*testing.T)は純人工です。
// 返り値: ありません。
func TestEvidence147CanonicalCopy(t *testing.T) {
	cache := NewPublications()
	_ = cache.StartSession("S", "C")
	var p rules.Publication
	for i := 1; i <= 20; i++ {
		p = evidencePublication147("S", "C", 900, float64(i*900), i, 1000+float64(i))
		mustRecordEvidence147(t, cache, p)
	}
	old, _ := cache.Window(p.Frame.Frame.ID)
	before, _ := json.Marshal(old)
	mustRecordEvidence147(t, cache, p)
	if len(cache.Windows()) != 20 {
		t.Fatal("同ID再配送で正本を増やした")
	}
	changed := p
	changed.Frame.Frame.OHLC.Close++
	if err := cache.Record(changed); err == nil {
		t.Fatal("同ID改変を許可")
	}
	poison := cache.Windows()
	poison[19].Refs[0].ID = "改変"
	poison[19].Bands.Mean = -1
	copyWindow, _ := cache.Window(p.Frame.Frame.ID)
	copyWindow.Refs[0].ID = "変更"
	current, _ := cache.Window(p.Frame.Frame.ID)
	got, _ := json.Marshal(current)
	if string(before) != string(got) {
		t.Fatal("公開copyから内部を書換えた")
	}
	mustRecordEvidence147(t, cache, evidencePublication147("S", "C", 900, 18900, 21, 2000))
	after, _ := json.Marshal(old)
	current, _ = cache.Window(p.Frame.Frame.ID)
	got, _ = json.Marshal(current)
	if string(before) != string(after) || string(before) != string(got) {
		t.Fatal("未来更新で過去窓を変更")
	}
}

// TestEvidence147RejectBeforeMutation は、不正scope/時計/既知価格を状態変更前に拒否します。
//
// 引数: t(*testing.T)は純人工です。
// 返り値: ありません。
func TestEvidence147RejectBeforeMutation(t *testing.T) {
	cache := NewPublications()
	_ = cache.StartSession("S", "C")
	good := evidencePublication147("S", "C", 900, 900, 1, 1000)
	bad := []rules.Publication{good, good, good, good}
	bad[0].Frame.Frame.Contract = "OTHER"
	bad[1].Stamp.Time = 959
	bad[2].Frame.Frame.OHLC.Close = math.NaN()
	bad[3].Frame.Frame.Width = 60
	for _, p := range bad {
		if err := cache.Record(p); err == nil || len(cache.Windows()) != 0 {
			t.Fatal("不正記録が非原子的")
		}
	}
	mustRecordEvidence147(t, cache, good)
	back := evidencePublication147("S", "C", 900, 800, 2, 1000)
	if err := cache.Record(back); err == nil || len(cache.Windows()) != 1 {
		t.Fatal("後退を拒否しない")
	}
	if err := cache.StartSession("S", "C"); err == nil {
		t.Fatal("同場再開始を許可")
	}
}

// TestEvidence147InstancesIsolated は、独立cache間に数値/参照を共有しないことを確認します。
//
// 引数: t(*testing.T)は純人工です。
// 返り値: ありません。
func TestEvidence147InstancesIsolated(t *testing.T) {
	a, b := NewPublications(), NewPublications()
	_ = a.StartSession("S", "C")
	_ = b.StartSession("S", "C")
	for i := 1; i <= 20; i++ {
		mustRecordEvidence147(t, a, evidencePublication147("S", "C", 900, float64(i*900), i, 1000))
	}
	p := evidencePublication147("S", "C", 900, 18000, 20, 1000)
	mustRecordEvidence147(t, b, p)
	window, _ := b.Window(p.Frame.Frame.ID)
	if window.Bands.Count != 1 || window.Bands.Known || len(b.Windows()) != 1 {
		t.Fatal("別cacheの過去が混ざった")
	}
}
