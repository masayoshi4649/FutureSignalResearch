package midrecover147

import (
	"bufio"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"io"
	"os"
	"reflect"
)

type SceneResult struct {
	Success          bool              `json:"success"`
	Session          string            `json:"session"`
	Contract         string            `json:"contract"`
	Start            float64           `json:"start"`
	End              float64           `json:"end"`
	ForceClose       float64           `json:"force_close"`
	EntryLimit       float64           `json:"entry_limit"`
	ExecutionEnd     float64           `json:"execution_end"`
	Raw              FileRef           `json:"raw"`
	ActualSHA        string            `json:"actual_sha256"`
	ExpectedAccepted int64             `json:"expected_accepted"`
	ExpectedQuality  *Counts           `json:"expected_quality"`
	Counts           Counts            `json:"counts"`
	Quality          Counts            `json:"quality"`
	StatBefore       map[string]int64  `json:"stat_before"`
	StatAfter        map[string]int64  `json:"stat_after"`
	RawPasses        int               `json:"raw_passes"`
	CSVStats         CSVStats          `json:"csv_stats"`
	ShortStats       map[string]int    `json:"short_stats"`
	Bars             []KnownBar        `json:"bars"`
	Events           []*Event          `json:"events"`
	Groups           []*Group          `json:"groups"`
	Checks           []PatternCheck    `json:"checks"`
	Stats            map[string]uint64 `json:"stats"`
	BBWindows        []BBWindow        `json:"bb_windows"`
}
type Result struct {
	Success             bool              `json:"success"`
	Trial               int               `json:"trial"`
	InputSHA            string            `json:"input_sha256"`
	BackgroundSHA       string            `json:"background_sha256"`
	CSVManifestSHA      string            `json:"csv_manifest_sha256"`
	FinancialLabelsUsed bool              `json:"financial_labels_used"`
	SourcePositionsUsed bool              `json:"source_positions_used"`
	EffectiveWorkers    int               `json:"effective_workers"`
	Scenes              []SceneResult     `json:"scenes"`
	Summary             map[string]uint64 `json:"summary"`
}

// scan は前場成功後の背景Bankを使いRawを一度だけ走査します。
//
// 引数: scene(Scene)、bank(*rules.Bank)、short(*ShortTracker)、cache(*Publications)、carry(bool)は互換指定で短期へ継承しない。返り値: SceneResult/errorです。
func scan(scene Scene, bank *rules.Bank, short *ShortTracker, cache *Publications, carry bool) (SceneResult, error) {
	out := SceneResult{Session: scene.Session, Contract: scene.Contract, Start: scene.Start, End: scene.End, ForceClose: scene.ForceClose, ExecutionEnd: scene.End - 300, EntryLimit: scene.End - 3900, Raw: scene.Raw, ExpectedAccepted: scene.ExpectedAccepted, ExpectedQuality: scene.ExpectedQuality, RawPasses: 1}
	if err := bank.StartSession(scene.Session, scene.Contract); err != nil {
		return out, err
	}
	if err := short.StartSession(scene.Session, scene.Contract, scene.Start, scene.End-300, carry); err != nil {
		return out, err
	}
	if err := cache.StartSession(scene.Session, scene.Contract); err != nil {
		return out, err
	}
	d := NewDetector(scene)
	out.EntryLimit = d.limit()
	minutes, cs, err := loadCSV(scene)
	if err != nil {
		return out, err
	}
	f, err := os.Open(scene.Raw.Path)
	if err != nil {
		return out, err
	}
	defer f.Close()
	before, err := f.Stat()
	if err != nil {
		return out, err
	}
	out.StatBefore = statValue(before)
	if scene.Raw.Bytes > 0 && scene.Raw.Bytes != before.Size() {
		return out, fmt.Errorf("Raw bytes差")
	}
	hash := sha256.New()
	buffer := bufio.NewReader(io.TeeReader(f, hash))
	magic, err := buffer.Peek(2)
	if err != nil {
		return out, err
	}
	var reader io.Reader = buffer
	if magic[0] == 0x1f && magic[1] == 0x8b {
		gz, e := gzip.NewReader(buffer)
		if e != nil {
			return out, e
		}
		defer gz.Close()
		reader = gz
	}
	scanner := bufio.NewScanner(reader)
	scanner.Buffer(make([]byte, 65536), 8<<20)
	previous, index, pi, cursor := scene.Start, int64(0), 0, 0
	contracts := map[string]bool{}
	for scanner.Scan() {
		out.Counts.Lines++
		q, reason, next, e := decodeRow(scanner.Bytes(), out.Counts.Lines, index, scene, previous, &out.Counts, contracts)
		if e != nil {
			return out, e
		}
		previous = next
		if q == nil {
			if reason == "clock_missing" || reason == "clock_invalid" || reason == "backward_clock" {
				d.Stats["Raw時計拒否/"+reason]++
			}
			continue
		}
		for pi < len(scene.Publications) && scene.Publications[pi].Stamp.Index <= int(q.Index) {
			p := scene.Publications[pi]
			if p.Stamp.Index != int(q.Index) || p.Stamp.Time != q.Time || p.Stamp.Line != int(q.SourceLine) {
				return out, fmt.Errorf("固定背景配送原行差")
			}
			if e = bank.Add(p); e != nil {
				return out, e
			}
			if e = cache.Record(p); e != nil {
				return out, e
			}
			pi++
		}
		snapshot, e := bank.Current(rq(*q))
		if e != nil {
			return out, e
		}
		batch := []ShortBar{}
		for _, m := range deliverMinutes(minutes, &cursor, *q) {
			bars, e := short.Add(m)
			if e != nil {
				return out, e
			}
			batch = append(batch, bars...)
		}
		if e = d.Observe(snapshot, *q, batch, cache); e != nil {
			return out, e
		}
		index++
	}
	if err = scanner.Err(); err != nil {
		return out, err
	}
	if _, err = io.Copy(io.Discard, buffer); err != nil {
		return out, err
	}
	out.ActualSHA = hex.EncodeToString(hash.Sum(nil))
	after, err := f.Stat()
	if err != nil {
		return out, err
	}
	pathAfter, err := os.Stat(scene.Raw.Path)
	if err != nil {
		return out, err
	}
	out.StatAfter = statValue(after)
	if out.ActualSHA != scene.Raw.SHA256 || !os.SameFile(before, pathAfter) || !reflect.DeepEqual(out.StatBefore, out.StatAfter) || before.Size() != pathAfter.Size() || !before.ModTime().Equal(pathAfter.ModTime()) || index != scene.ExpectedAccepted || !reflect.DeepEqual(out.Counts, *scene.ExpectedQuality) || len(contracts) != 1 || !contracts[scene.Contract] || pi != len(scene.Publications) {
		return out, fmt.Errorf("Raw SHA/stat/品質/限月/公表差:%s", scene.Session)
	}
	d.Finish()
	cs.Delivered = cursor
	cs.EOFUndelivered = len(minutes) - cursor
	out.CSVStats = cs
	out.ShortStats = short.Stats()
	out.Bars = d.Bars
	out.Events = d.Events
	out.Groups = d.Groups
	out.Checks = d.Checks
	out.Stats = d.Stats
	out.BBWindows = cache.Windows()
	out.Quality = out.Counts
	out.Success = true
	return out, nil
}

// Generate は前場全品質成功後だけ背景窓を継承し、短期を毎場coldで生成します。
//
// 引数: scenes([]Scene)、workers(int)は互換指定、all73(bool)。返り値: Result/errorです。実効並列は1です。
func Generate(scenes []Scene, workers int, all73 bool) (Result, error) {
	out := Result{Trial: 147, BackgroundSHA: BackgroundSHA, CSVManifestSHA: CSVManifestSHA, EffectiveWorkers: 1, Scenes: []SceneResult{}, Summary: map[string]uint64{}}
	if workers < 1 || workers > 16 {
		return out, fmt.Errorf("workersは1..16")
	}
	if err := Validate(scenes, all73); err != nil {
		return out, err
	}
	bank := rules.NewBank()
	short := NewShort()
	cache := NewPublications()
	for _, s := range scenes {
		scene, err := scan(s, bank, short, cache, false)
		if err != nil {
			return out, err
		}
		out.Scenes = append(out.Scenes, scene)
		out.Summary["場数"]++
		out.Summary["候補数"] += uint64(len(scene.Events))
		out.Summary["group数"] += uint64(len(scene.Groups))
		for _, e := range scene.Events {
			out.Summary["候補status/"+e.Status]++
			if e.Status == "filled" {
				out.Summary["filled候補数"]++
			}
		}
		for _, g := range scene.Groups {
			out.Summary["groupstatus/"+g.Status]++
			if g.Status == "filled" {
				out.Summary["物理取得数"]++
			}
		}
		for k, n := range scene.Stats {
			out.Summary["stage/"+k] += n
		}
		fmt.Fprintf(os.Stderr, "147進捗 session=%s 候補累計=%d 物理取得累計=%d\n", s.Session, out.Summary["候補数"], out.Summary["物理取得数"])
	}
	out.Success = true
	return out, nil
}
