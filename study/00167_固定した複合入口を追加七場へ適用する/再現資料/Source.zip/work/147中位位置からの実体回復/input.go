package midrecover147

import (
	"encoding/json"
	"fmt"
	"os"
)

const CSVManifestSHA = "07e136e2b77a0029ddacd955abad16a9240373fa849ec96b553c2875e1e85147"

type InputReference struct {
	Trial       int     `json:"trial"`
	Background  FileRef `json:"background"`
	CSVManifest FileRef `json:"csv_manifest"`
}

// Load は小参照と両固定入力のサイズ/SHAを確認して73場を結合します。
//
// 引数: path/expected(string)。返り値: []Scene/errorです。CSV本文はまだ開きません。
func Load(path, expected string) ([]Scene, error) {
	if len(expected) != 64 {
		return nil, fmt.Errorf("小参照SHA形式差")
	}
	for _, c := range expected {
		if !(c >= '0' && c <= '9' || c >= 'a' && c <= 'f') {
			return nil, fmt.Errorf("小参照SHA形式差")
		}
	}
	body, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	if digest(body) != expected {
		return nil, fmt.Errorf("小参照SHA差")
	}
	var input InputReference
	if err = json.Unmarshal(body, &input); err != nil {
		return nil, err
	}
	if input.Trial != 147 || input.Background.SHA256 != BackgroundSHA || input.CSVManifest.SHA256 != CSVManifestSHA {
		return nil, fmt.Errorf("147小参照の固定先差")
	}
	for _, r := range []FileRef{input.Background, input.CSVManifest} {
		s, e := os.Stat(r.Path)
		if e != nil {
			return nil, e
		}
		if r.Bytes <= 0 || r.Bytes != s.Size() {
			return nil, fmt.Errorf("小参照bytes差")
		}
	}
	return loadSources(input.Background.Path, input.Background.SHA256, input.CSVManifest.Path, input.CSVManifest.SHA256)
}
