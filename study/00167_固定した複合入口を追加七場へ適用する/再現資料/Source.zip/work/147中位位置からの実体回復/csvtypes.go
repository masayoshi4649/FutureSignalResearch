package midrecover147

import rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"

// FileRef は複写しない固定原本の参照です。
type FileRef struct {
	Path   string `json:"path"`
	SHA256 string `json:"sha256"`
	Bytes  int64  `json:"bytes"`
}

// Minute は当時実配送された確定1分です。Missingは未知の格子を表します。
type Minute struct {
	ID          string      `json:"id"`
	Session     string      `json:"session"`
	Contract    string      `json:"contract"`
	Start       float64     `json:"start"`
	End         float64     `json:"end"`
	AvailableAt float64     `json:"available_at"`
	OHLC        rules.OHLC  `json:"ohlc"`
	Volume      float64     `json:"volume"`
	PriceKnown  bool        `json:"price_known"`
	VolumeKnown bool        `json:"volume_known"`
	Closed      bool        `json:"closed"`
	Missing     bool        `json:"missing"`
	Stamp       rules.Stamp `json:"stamp"`
	CSV         FileRef     `json:"csv"`
	CSVLine     int         `json:"csv_line"`
}
