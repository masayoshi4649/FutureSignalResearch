package midrecover147

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
	"sort"
)

type Detector struct {
	Scene     Scene
	Bars      []KnownBar
	Events    []*Event
	Groups    []*Group
	Checks    []PatternCheck
	Stats     map[string]uint64
	windows   map[int][]KnownBar
	latest    map[int]KnownBar
	processed map[string]bool
	pending   *Group
	active    []*Event
	filled    map[string]bool
}

// NewDetector は旧対照や口座保有に依存しない単一T状態を作ります。
//
// 引数: scene(Scene)。返り値: *Detectorです。
func NewDetector(scene Scene) *Detector {
	return &Detector{Scene: scene, Bars: []KnownBar{}, Events: []*Event{}, Groups: []*Group{}, Checks: []PatternCheck{}, Stats: map[string]uint64{}, windows: map[int][]KnownBar{}, latest: map[int]KnownBar{}, processed: map[string]bool{}, filled: map[string]bool{}}
}

// limit は主H60の観測を残す共通新規限界です。
//
// 引数: なし。返り値: float64です。
func (d *Detector) limit() float64 { return math.Min(d.Scene.ForceClose, d.Scene.End-3900) }

// addGate は既知不成立と未知を別に記録します。
//
// 引数: c(*PatternCheck)、key(string)、known/pass(bool)。返り値: ありません。
func addGate(c *PatternCheck, key string, known, pass bool) {
	c.Gates[key] = test(known, pass)
	if !known {
		c.Reasons = append(c.Reasons, key+"未知")
	} else if !pass {
		c.Reasons = append(c.Reasons, key+"不成立")
	}
}

// preferred は固定代表順を返します。
//
// 引数: a/b(*Event)。返り値: boolはaが先です。
func preferred(a, b *Event) bool {
	if a.Width != b.Width {
		return a.Width > b.Width
	}
	if a.Family[0] != b.Family[0] {
		return a.Family[0] < b.Family[0]
	}
	return a.ID < b.ID
}

// terminate は候補自身だけを取り消し現在参照を保存します。
//
// 引数: e(*Event)、status/reason(string)、q(Quote)、c(Context)。返り値: ありません。
func terminate(e *Event, status, reason string, q Quote, c Context) {
	z := q
	e.Status = status
	e.TerminationQuote = &z
	e.Reasons = append(e.Reasons, reason)
	e.Refs = merge(e.Refs, c.Refs)
	e.Trace = append(e.Trace, Trace{Stage: status, Reason: reason, At: q, Context: c, Fields: map[string]rules.Value{}})
}

// processPending はgroup内の各候補を独立検査し同Quoteの実取得をまとめます。
//
// 引数: q(Quote)、c(Context)。返り値: errorは物理取得の重複です。
func (d *Detector) processPending(q Quote, c Context) error {
	if d.pending == nil {
		return nil
	}
	group := d.pending
	alive := []*Event{}
	for _, e := range d.active {
		if e.Status != "pending" {
			continue
		}
		b, ok := d.latest[e.Width]
		switch {
		case q.Time >= d.limit():
			terminate(e, "force_close", "共通限界", q, c)
		case q.Time >= e.Expires:
			terminate(e, "unfilled_expired", "pending期限等号又は超過", q, c)
		case !gatesPass(currentGates(c, e.Side)):
			terminate(e, "background_lost", "現在背景未知又は否定", q, c)
		case !ok || !b.Bar.PriceKnown || !b.Bar.Closed || q.Time >= b.Bar.End+float64(e.Width)+60:
			terminate(e, "short_unknown", "現在短期足未知又はfresh不足", q, c)
		case float64(e.Side)*(q.Last-e.Structure.I) <= 0:
			terminate(e, "invalidation_reached", "現在LastがI到達", q, c)
		case !position(e.Side, q.Last, e.Structure):
			terminate(e, "last_position_rejected", "現在Lastが固定K/cap/BB域外", q, c)
		default:
			alive = append(alive, e)
		}
	}
	if len(alive) == 0 {
		group.Status = "all_cancelled"
		z := q
		group.TerminationQuote = &z
		d.pending = nil
		d.active = nil
		return nil
	}
	if q.Index <= group.Birth.Index || q.SourceLine <= group.Birth.SourceLine || q.Time < group.Birth.Time+1 || !q.QuoteOK || !normal(q) {
		return nil
	}
	filled := []*Event{}
	for _, e := range alive {
		price := q.Ask
		if e.Side < 0 {
			price = q.Bid
		}
		risk := float64(e.Side) * (price - e.Structure.I)
		e.Refs = merge(e.Refs, c.Refs)
		e.Trace = append(e.Trace, Trace{Stage: "最初正常実P評価", At: q, Context: c, Fields: map[string]rules.Value{"entry_price": v(price), "risk": v(risk)}})
		if !position(e.Side, price, e.Structure) || risk <= 0 || risk > 125 {
			terminate(e, "entry_position_rejected", "最初正常実側の固定域又はrisk不適合", q, c)
			continue
		}
		z := q
		e.Status = "filled"
		e.EntryQuote = &z
		e.EntryPrice = &price
		e.TerminationQuote = &z
		filled = append(filled, e)
		d.Stats["候補取得/"+e.Family]++
	}
	z := q
	group.TerminationQuote = &z
	if len(filled) > 0 {
		key := fmt.Sprintf("%g/%d/%d", q.Time, q.Index, q.SourceLine)
		if d.filled[key] {
			return fmt.Errorf("同原行の複数group取得矛盾")
		}
		d.filled[key] = true
		sort.Slice(filled, func(i, j int) bool { return preferred(filled[i], filled[j]) })
		group.Status = "filled"
		group.EntryQuote = &z
		group.RepresentativeID = filled[0].ID
		for _, e := range filled {
			group.FilledIDs = append(group.FilledIDs, e.ID)
		}
		d.Stats["物理取得"]++
	} else {
		group.Status = "all_cancelled"
	}
	d.pending = nil
	d.active = nil
	return nil
}

// submit は同Raw出生可能候補を固定順でgroup化し逆向き競合を全取消します。
//
// 引数: candidates([]*Event)、q(Quote)、current(Context)。返り値: ありません。
func (d *Detector) submit(candidates []*Event, q Quote, current Context) {
	sort.Slice(candidates, func(i, j int) bool { return preferred(candidates[i], candidates[j]) })
	side := candidates[0].Side
	conflict := false
	for _, e := range candidates {
		conflict = conflict || e.Side != side
	}
	g := &Group{ID: fmt.Sprintf("%s/group/%d", d.Scene.Session, q.Index), Side: side, Birth: q, CandidateIDs: []string{}, Status: "pending", FilledIDs: []string{}}
	for _, e := range candidates {
		e.GroupID = g.ID
		g.CandidateIDs = append(g.CandidateIDs, e.ID)
	}
	d.Groups = append(d.Groups, g)
	if conflict {
		g.Side = 0
		g.Status = "conflict"
		z := q
		g.TerminationQuote = &z
		for _, e := range candidates {
			terminate(e, "conflict", "同Rawの逆向き出生競合", q, current)
		}
		d.Stats["競合group"]++
		return
	}
	d.pending = g
	d.active = candidates
	d.Stats["group出生"]++
}

// Finish はEOFで気配を作らず未取得候補とgroupを終えます。
//
// 引数: なし。返り値: ありません。
func (d *Detector) Finish() {
	if d.pending == nil {
		return
	}
	d.pending.Status = "eof_unfilled"
	for _, e := range d.active {
		if e.Status == "pending" {
			e.Status = "eof_unfilled"
			e.Reasons = append(e.Reasons, "EOF")
		}
	}
	d.pending = nil
	d.active = nil
}
