package midrecover147

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"os"
	"path/filepath"
	"testing"
	"time"
)

// ohlc147 は人工価格の型を短く記します。
//
// 引数: o/h/l/c(float64)。返り値: rules.OHLCです。
func ohlc147(o, h, l, c float64) rules.OHLC { return rules.OHLC{Open: o, High: h, Low: l, Close: c} }

// sceneIO147 は自然資料を使わずRaw/CSVの参照と期待品質を作ります。
//
// 引数: t(*testing.T)、compressed(bool)。返り値: Sceneです。
func sceneIO147(t *testing.T, compressed bool) Scene {
	t.Helper()
	var raw bytes.Buffer
	for i, at := range []int64{120, 121, 122} {
		row := map[string]any{"Symbol": "X", "CurrentPriceTime": time.Unix(at, 0).UTC().Format(time.RFC3339Nano), "CurrentPrice": 100.}
		for j := 1; j <= 10; j++ {
			row[fmt.Sprintf("Buy%d", j)] = map[string]float64{"Price": 90, "Qty": 1}
			row[fmt.Sprintf("Sell%d", j)] = map[string]float64{"Price": 110, "Qty": 1}
		}
		if i == 1 {
			row["Buy1"] = map[string]float64{"Price": 0, "Qty": 1}
		}
		b, e := json.Marshal(row)
		if e != nil {
			t.Fatal(e)
		}
		raw.Write(b)
		raw.WriteByte('\n')
	}
	body := raw.Bytes()
	if compressed {
		var z bytes.Buffer
		gz := gzip.NewWriter(&z)
		_, _ = gz.Write(body)
		_ = gz.Close()
		body = z.Bytes()
	}
	dir := t.TempDir()
	rawPath := filepath.Join(dir, "raw")
	if err := os.WriteFile(rawPath, body, 0600); err != nil {
		t.Fatal(err)
	}
	h := sha256.Sum256(body)
	csvBody := []byte("time,open,high,low,close,volume,volume_complete,closed\n1970-01-01T00:00:00Z,100,101,99,100,1,true,true\n1970-01-01T00:01:00Z,100,101,99,100,0,false,true\n")
	csvPath := filepath.Join(dir, "1分.csv")
	if err := os.WriteFile(csvPath, csvBody, 0600); err != nil {
		t.Fatal(err)
	}
	csvHash := sha256.Sum256(csvBody)
	return Scene{Session: "人工_Day", Contract: "X", Start: 0, End: 10200, ForceClose: 9000, Raw: FileRef{Path: rawPath, SHA256: hex.EncodeToString(h[:])}, CSV: FileRef{Path: csvPath, SHA256: hex.EncodeToString(csvHash[:]), Bytes: int64(len(csvBody))}, ExpectedAccepted: 3, ExpectedQuality: &Counts{Lines: 3, Accepted: 3, Delivered: 3, BadBBO: 1}}
}

// Test147CSVと原板一走査 は未知格子・EOF未配送・品質・0件配列を確認します。
//
// 引数: t(*testing.T)。返り値: ありません。
func Test147CSVと原板一走査(t *testing.T) {
	for _, compressed := range []bool{false, true} {
		scene := sceneIO147(t, compressed)
		minutes, stats, err := loadCSV(scene)
		if err != nil {
			t.Fatal(err)
		}
		if stats.Missing != 163 || len(minutes) != 165 || minutes[1].VolumeKnown || minutes[1].Volume != 0 {
			t.Fatal("未知と0又は格子")
		}
		result, err := Generate([]Scene{scene}, 4, false)
		if err != nil {
			t.Fatal(err)
		}
		s := result.Scenes[0]
		if !result.Success || result.Trial != 147 || result.EffectiveWorkers != 1 || s.Counts != *scene.ExpectedQuality || s.RawPasses != 1 || s.Events == nil || s.Groups == nil || s.Bars == nil || len(s.Bars) != 1 || s.CSVStats.EOFUndelivered != 164 {
			t.Fatal(s)
		}
		scene.ExpectedQuality.BadBBO = 0
		if _, err = Generate([]Scene{scene}, 1, false); err == nil {
			t.Fatal("期待品質差受理")
		}
	}
	if _, err := Load("存在しない", "不正"); err == nil {
		t.Fatal("I/O前入力拒否なし")
	}
}
