package midrecover147

import (
	"fmt"
	rules "github.com/masayoshi4649/SessionTradeExecuter/entryrules118"
	"math"
	"sort"
)

// shortRef は短期正本を変えず参照だけを返します。
//
// 引数: b(ShortBar)。返り値: rules.Refです。
func shortRef(b ShortBar) rules.Ref {
	return rules.Ref{ID: b.ID, Width: 60, End: b.End, Delivered: b.Stamp}
}

// candidate はp初知を保存した隣接2足を現在の上位動力と組み合わせます。
//
// 引数: current(Context)、q(Quote)。返り値: *Event又はnilとPatternCheckです。
func (d *Detector) candidate(current Context, q Quote) (*Event, PatternCheck) {
	r := d.latest[60]
	c := PatternCheck{Width: 60, Family: "T0", At: q, R: shortRef(r.Bar), UsedRefs: []rules.Ref{}, Gates: map[string]rules.Value{}, Fields: map[string]rules.Value{}, Reasons: []string{}, Status: "pattern_rejected"}
	w := d.windows[60]
	addGate(&c, "当場隣接p_r", true, len(w) >= 2)
	if len(w) < 2 {
		return nil, c
	}
	p := w[len(w)-2]
	r = w[len(w)-1]
	side := p.Context.Direction30
	s := float64(side)
	c.UsedRefs = []rules.Ref{shortRef(p.Bar), shortRef(r.Bar)}
	addGate(&c, "p_r初配送strict", true, p.Bar.Stamp.Time < r.Bar.Stamp.Time && p.Bar.Stamp.Index < r.Bar.Stamp.Index)
	for _, width := range []int{300, 900, 1800} {
		x := p.Context.Fields[fmt.Sprintf("price_known_%d", width)]
		addGate(&c, fmt.Sprintf("p初%d価格fresh", width), x.Known, x.Value == 1)
	}
	x, y := p.Context.Fields["gap30"], p.Context.Fields["ema21_delta30"]
	addGate(&c, "p初30方向", x.Known && y.Known, side != 0)
	atr, em8, em21 := p.Context.Fields["atr5"], p.Context.Fields["ema8_5"], p.Context.Fields["ema21_5"]
	addGate(&c, "p初ATR5正", atr.Known, atr.Value > 0)
	addGate(&c, "p初EMA5帯接触", em8.Known && em21.Known, p.Bar.OHLC.High >= math.Min(em8.Value, em21.Value) && p.Bar.OHLC.Low <= math.Max(em8.Value, em21.Value))
	addGate(&c, "p初BB15正sigma", p.Context.BB15.Known, p.Context.BB15.Sigma > 0)
	addGate(&c, "p逆実体", side != 0, s*(p.Bar.OHLC.Close-p.Bar.OHLC.Open) < 0)
	keys := []string{}
	gates := currentGates(current, side)
	for key := range gates {
		keys = append(keys, key)
	}
	sort.Strings(keys)
	for _, key := range keys {
		x := gates[key]
		addGate(&c, key, x.Known, x.Value == 1)
	}
	addGate(&c, "r現在fresh", true, r.Bar.PriceKnown && r.Bar.Closed && q.Time < r.Bar.End+120)
	addGate(&c, "r順実体", side != 0, s*(r.Bar.OHLC.Close-r.Bar.OHLC.Open) > 0)
	k := p.Bar.OHLC.Open
	addGate(&c, "r終値p始値回復", side != 0, s*(r.Bar.OHLC.Close-k) >= 0)
	addGate(&c, "p_r同足量", p.Bar.VolumeKnown && r.Bar.VolumeKnown, p.Bar.Volume > 0 && r.Bar.Volume > 0 && r.Bar.Volume >= p.Bar.Volume)
	tr := math.Max(r.Bar.OHLC.High-r.Bar.OHLC.Low, math.Max(math.Abs(r.Bar.OHLC.High-p.Bar.OHLC.Close), math.Abs(r.Bar.OHLC.Low-p.Bar.OHLC.Close)))
	addGate(&c, "短期TR上限", atr.Known, tr <= 2*atr.Value)
	c.Fields["p_context_atr5"], c.Fields["short_tr"], c.Fields["p_signed_body"], c.Fields["r_signed_body"] = atr, v(tr), v(s*(p.Bar.OHLC.Close-p.Bar.OHLC.Open)), v(s*(r.Bar.OHLC.Close-r.Bar.OHLC.Open))
	if len(c.Reasons) > 0 {
		return nil, c
	}
	// ----------------------------------------
	// 技術完成後に初めて固定I・幅・BB目標余地を計算します。
	c.Status = "technical_complete"
	d.Stats["技術完成/T0"]++
	i := math.Min(p.Bar.OHLC.Low, r.Bar.OHLC.Low) - 10
	forward := p.Context.BB15.Upper
	if side < 0 {
		i = math.Max(p.Bar.OHLC.High, r.Bar.OHLC.High) + 10
		forward = p.Context.BB15.Lower
	}
	widthPt := s * (k - i)
	room := s*(forward-k) - 125
	capPt := math.Min(atr.Value, math.Min(125-widthPt, room))
	st := Structure{K: k, I: i, Width: widthPt, Cap: capPt, ArmATR: atr.Value, CapATRWidth: 300, BBMean: p.Context.BB15.Mean, BBForward: forward, BBWindowID: p.Context.BBWindowID}
	c.Fields["k"], c.Fields["i"], c.Fields["structure_width"], c.Fields["cap"], c.Fields["bb_mean"], c.Fields["bb_forward"] = v(k), v(i), v(widthPt), v(capPt), v(st.BBMean), v(forward)
	if !finite(k, i, widthPt, capPt, forward, st.BBMean, room) || widthPt <= 0 || widthPt > 125 {
		c.Status = "structure_rejected"
		c.Reasons = append(c.Reasons, "構造幅又は有限性不適合")
		return nil, c
	}
	if capPt < 0 {
		c.Status = "target_room_rejected"
		c.Reasons = append(c.Reasons, "固定BB順端までの125pt余地不足")
		return nil, c
	}
	if !position(side, q.Last, st) {
		c.Status = "position_rejected"
		c.Reasons = append(c.Reasons, "完成時現在Lastの固定K_cap_BB位置不適合")
		return nil, c
	}
	e := &Event{ID: fmt.Sprintf("%s/T0/%s/%d", d.Scene.Session, r.Bar.ID, q.Index), Family: "T0", Width: 60, Side: side, Status: "pending", Birth: q, Expires: math.Min(q.Time+30, d.limit()), Structure: st, Arm: shortRef(p.Bar), Confirm: shortRef(r.Bar), Refs: merge(p.Context.Refs, current.Refs, c.UsedRefs), Fields: c.Fields, Reasons: []string{}, Trace: []Trace{}}
	c.Status = "birth_eligible"
	return e, c
}

// Observe は公表と全1分の配送後に最新rを一回消費します。
//
// 引数: snapshot(rules.Snapshot)、q(Quote)、batch([]ShortBar)、cache(*Publications)。返り値: errorです。
func (d *Detector) Observe(snapshot rules.Snapshot, q Quote, batch []ShortBar, cache *Publications) error {
	if err := validCurrent(snapshot, q, d.Scene); err != nil {
		return err
	}
	current, err := makeContext(snapshot, q, cache)
	if err != nil {
		return err
	}
	return d.observe(current, q, batch)
}

// observe は既pendingの終了Rawでも後着rを抑止する状態遷移を行います。
//
// 引数: current(Context)、q(Quote)、batch([]ShortBar)。返り値: errorです。
func (d *Detector) observe(current Context, q Quote, batch []ShortBar) error {
	d.Stats["採用Raw"]++
	hasNew := false
	for _, bar := range batch {
		if bar.Session != d.Scene.Session || bar.Contract != d.Scene.Contract || bar.Width != 60 || bar.Stamp.Time != q.Time || bar.Stamp.Index != int(q.Index) || bar.Stamp.Line != int(q.SourceLine) || bar.End > q.Time || bar.AvailableAt > q.Time {
			return fmt.Errorf("1分配送scope/時計差")
		}
		known := KnownBar{Bar: bar, Context: current}
		d.Bars = append(d.Bars, known)
		d.latest[60] = known
		hasNew = true
		if !bar.PriceKnown || !bar.Closed {
			d.windows[60] = nil
			continue
		}
		w := d.windows[60]
		if len(w) > 0 && w[len(w)-1].Bar.End != bar.Start {
			w = nil
		}
		w = append(w, known)
		if len(w) > 2 {
			w = append([]KnownBar(nil), w[len(w)-2:]...)
		}
		d.windows[60] = w
	}
	// ----------------------------------------
	// 開始時の占有を保存し、取得又は取消の同Rawを次出生へ使いません。
	hadPending := d.pending != nil
	if err := d.processPending(q, current); err != nil {
		return err
	}
	if !hasNew {
		return nil
	}
	r := d.latest[60]
	if d.processed[r.Bar.ID] {
		return fmt.Errorf("rID再配送矛盾")
	}
	d.processed[r.Bar.ID] = true
	d.Stats["新r/60"]++
	if q.Time >= d.limit() {
		d.Checks = append(d.Checks, PatternCheck{Width: 60, Family: "T0", At: q, R: shortRef(r.Bar), UsedRefs: []rules.Ref{}, Gates: map[string]rules.Value{}, Fields: map[string]rules.Value{}, Status: "late_excluded", Suppressed: hadPending, Reasons: []string{"共通新規限界"}})
		return nil
	}
	e, check := d.candidate(current, q)
	check.Suppressed = hadPending
	if e != nil && hadPending {
		check.Status = "suppressed"
	}
	d.Checks = append(d.Checks, check)
	if e == nil {
		return nil
	}
	d.Events = append(d.Events, e)
	d.Stats["出生可能候補/T0"]++
	if hadPending {
		terminate(e, "suppressed", "既pending又はその終了Rawの後着候補", q, current)
		return nil
	}
	d.submit([]*Event{e}, q, current)
	return nil
}
