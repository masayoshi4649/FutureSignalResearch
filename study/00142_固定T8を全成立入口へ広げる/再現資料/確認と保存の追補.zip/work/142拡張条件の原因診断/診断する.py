"""固定142方向票の拡張分岐を保存BBO正逆で診断する。金融モジュールはimportしない。"""
import collections
from fractions import Fraction
import hashlib
import json
import pathlib

ROOT = pathlib.Path(__file__).resolve().parents[2]
OWN = pathlib.Path(__file__).resolve().parent
FILES = {
    'choices': ('work/142固定T8の拡張評価/方向票/全752の方向.json', '7c76a270325aeeb45fff97d4f549568d86920d3452f1d1f9d6e92b9d1988deb8'),
    'observed': ('work/138全成立入口の評価/固定取得の正逆観測.json', 'd272fc6f6768342ff67e1a9ec58b0b7307a0a5b07cc215ba5ff7bcb50865b742'),
    'aggregate': ('work/142固定T8の拡張評価/金融評価/集計.json', 'e5b0d87e1fde42619470fa9e6f06d1bdf91e74e9ff96a2af3dee9b889cc3f3c5'),
}
LABELS = ('順行', '逆行', '未到達', 'H不足')


def sha(body):
    """機能: bytesのSHAを求める。引数: body(bytes)。返り値: str。"""
    return hashlib.sha256(body).hexdigest()


def outcome(stream):
    """機能: H60±125のラベルとQuote由来のC5清算を独立計算。引数: stream(dict)。返り値: dict。"""
    h = next(h for h in stream['outcomes'] if h['seconds'] == 3600)
    touch = next(t for t in h['touches'] if t['width'] == 125)
    direction = touch['direction']
    assert direction in (-1, 0, 1) and (touch['quote'] is None) == (direction == 0)
    complete = h['status'] == 'complete'
    label = 'H不足' if not complete else '順行' if direction == 1 else '逆行' if direction == -1 else '未到達'
    quote = touch['quote'] if direction else h['endpoint'] if complete else None
    side = stream['birth']['side']
    entry = stream['entry']
    assert stream['entry_price'] == (entry['ask'] if side == 1 else entry['bid'])
    known = quote is not None
    money = None
    if known:
        price = quote['bid'] if side == 1 else quote['ask']
        money = 100*side*(price-stream['entry_price'])-1077
    return {'main_label': label, 'H_complete': complete, 'touch_direction': direction,
            'ifd_known': known, 'net5': money,
            'exit_reason': '順行到達' if direction == 1 else '逆行到達' if direction == -1 else '期限清算' if complete else '観測不足'}


def path_class(row):
    """機能: 固定方向票の段階別反転で排他的経路を付ける。引数: row(dict)。返り値: str。"""
    if row['baseline']:
        assert all(o['result'] is None for o in row['origins'])
        return '旧81保護'
    paths = set()
    for o in row['origins']:
        r = o['result']
        paths.add(('B0のみ' if r['b0_flip'] else '両段なし') if not r['t8_patch_flip'] else ('両段で相殺' if r['b0_flip'] else '第2段のみ'))
    return next(iter(paths)) if len(paths) == 1 else '経路混在:'+','.join(sorted(paths))


def stats(rows, name):
    """機能: 全件分母とC5利益損失を保存する。引数: rows(list)、name(str)。返り値: dict。"""
    c = collections.Counter(r[name]['main_label'] for r in rows)
    resolved = c['順行']+c['逆行']
    known = [r[name]['net5'] for r in rows if r[name]['ifd_known']]
    profit = sum(v for v in known if v > 0)
    loss = -sum(v for v in known if v < 0)
    return {'count': len(rows), **{label: c[label] for label in LABELS},
            'resolved_fraction': str(Fraction(c['順行'], resolved)) if resolved else None,
            'resolved_rate': c['順行']/resolved if resolved else None,
            'ifd_known': len(known), 'ifd_unknown': len(rows)-len(known),
            'profit5': profit, 'loss5': loss, 'net5': sum(known)}


def compare(rows):
    """機能: 元→新の行列と両側既知C5差を示す。引数: rows(list)。返り値: dict。"""
    matrix = {a: {b: 0 for b in LABELS} for a in LABELS}
    transitions = collections.Counter()
    paired = []
    for row in rows:
        a, b = row['native'], row['selected']
        matrix[a['main_label']][b['main_label']] += 1
        transitions[(a['ifd_known'], b['ifd_known'])] += 1
        if a['ifd_known'] and b['ifd_known']:
            paired.append(b['net5']-a['net5'])
    return {'native': stats(rows, 'native'), 'selected': stats(rows, 'selected'), 'matrix': matrix,
            'both_IFD_known': len(paired), 'both_IFD_known_net5_difference': sum(paired),
            'paired_improved': sum(v > 0 for v in paired), 'paired_worsened': sum(v < 0 for v in paired),
            'paired_unchanged': sum(v == 0 for v in paired),
            'IFD_known_to_unknown': transitions[(True, False)],
            'IFD_unknown_to_known': transitions[(False, True)],
            'IFD_both_unknown': transitions[(False, False)]}


def grouped(rows, key):
    """機能: 排他的区分の比較を作る。引数: rows(list)、key(str)。返り値: list[dict]。"""
    groups = collections.defaultdict(list)
    for r in rows:
        groups[r[key]].append(r)
    return [{'group': group, **compare(items)} for group, items in sorted(groups.items())]


def run():
    """機能: 148反転の原因群を分け全体数値も照合。引数: なし。返り値: dict。閾値探索なし。"""
    docs = {}
    for key, (path, expected) in FILES.items():
        body = (ROOT/path).read_bytes()
        assert sha(body) == expected
        docs[key] = json.loads(body)
    choices, observed, aggregate = (docs[k] for k in ('choices', 'observed', 'aggregate'))
    assert choices['success'] and choices['trial'] == 142 and observed['success']
    cby = {r['id']: r for r in choices['rows']}
    assert len(cby) == 752 and sum(r['flip'] for r in cby.values()) == 148
    sessions = [s['session'] for s in observed['scenes']]
    assert sessions == choices['sessions'] and len(sessions) == 73
    train = set(sessions[:48])
    rows = []
    for s in observed['scenes']:
        for c in s['cases']:
            if not c['id'].startswith('P0/'):
                continue
            r = cby[c['id']]
            assert r['session'] == s['session'] and r['native_side'] == c['original_side']
            assert r['selected_side'] == (r['native_side'] if not r['flip'] else -r['native_side'])
            assert c['original']['entry'] == c['reverse']['entry']
            families = '+'.join(sorted({o['family'] for o in r['origins']}))
            native = outcome(c['original'])
            selected = outcome(c['reverse'] if r['flip'] else c['original'])
            rows.append({'id': c['id'], 'session': s['session'], 'flip': r['flip'], 'baseline': r['baseline'],
                         'path': path_class(r), 'known': '3入力全既知' if r['all_origins_known'] else '部分未知',
                         'family_set': families, 'part': '前48' if s['session'] in train else '後25',
                         'native': native, 'selected': selected,
                         'origins': [{'query_id': o['query_id'], 'family': o['family'], 'known_mask': o['known_mask'],
                                      'formula_applied': o['formula_applied'], 'result': o['result']} for o in r['origins']]})
    assert len(rows) == 752 and sum(r['baseline'] for r in rows) == 81
    assert len({r['session'] for r in rows}) == 73
    for label, policy in (('native', 'P0'), ('selected', 'T0')):
        calculated = stats(rows, label)
        expected = aggregate['集計']['all'][policy]['BBO']['3600']['125']
        assert [calculated[k] for k in LABELS] == [expected[k] for k in ('forward', 'adverse', 'neither', 'censored')]
        assert (calculated['ifd_known'], calculated['ifd_unknown'], calculated['profit5'], calculated['loss5'], calculated['net5']) == (expected['ifd_known'], expected['ifd_unknown'], expected['ifd_net5_profit'], expected['ifd_net5_loss'], expected['ifd_net5_sum'])
    flips = [r for r in rows if r['flip']]
    assert len(flips) == 148 and all(not r['baseline'] for r in flips)
    result = {'success': True, 'trial': 142, 'new_parameter_search': False, 'financial_module_import': False,
              'all752': compare(rows), 'flip148': compare(flips),
              'flip_path': grouped(flips, 'path'), 'flip_known': grouped(flips, 'known'),
              'flip_path_known': grouped([{**r, 'path_known': r['path']+'/'+r['known']} for r in flips], 'path_known'),
              'flip_family_sets_exclusive': grouped(flips, 'family_set'), 'flip_parts': grouped(flips, 'part'),
              'flip_family_path_exclusive': grouped([{**r, 'family_path': r['family_set']+'/'+r['path']} for r in flips], 'family_path'),
              'all752_paths_including_cancelled_double_flip': grouped(rows, 'path'),
              'all752_parts': grouped(rows, 'part'), 'flip_details': flips,
              'sources': {k: {'path': p, 'sha256': h} for k, (p, h) in FILES.items()}}
    for key, (path, expected) in FILES.items():
        assert sha((ROOT/path).read_bytes()) == expected
    p = OWN/'拡張分岐別の比較.json'
    p.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    return result


def artificial():
    """機能: H不足touch優先とC5費用を鏡像検査。引数: なし。返り値: intは成功数。"""
    checked = 0
    for side in (1, -1):
        entry = {'ask': 1010, 'bid': 1000}
        price = entry['ask'] if side == 1 else entry['bid']
        exit_price = price+side*125
        quote = {'bid': exit_price if side == 1 else exit_price-10, 'ask': exit_price+10 if side == 1 else exit_price}
        h = {'seconds': 3600, 'status': 'phase_censored', 'touches': [{'width': 125, 'direction': 1, 'quote': quote}], 'endpoint': None}
        stream = {'birth': {'side': side}, 'entry': entry, 'entry_price': price, 'outcomes': [h]}
        got = outcome(stream)
        assert got['main_label'] == 'H不足' and got['ifd_known'] and got['net5'] == 11423
        h['touches'][0] = {'width': 125, 'direction': 0, 'quote': None}
        assert outcome(stream)['net5'] is None and not outcome(stream)['ifd_known']
        h['status'], h['endpoint'] = 'complete', entry
        assert outcome(stream)['main_label'] == '未到達' and outcome(stream)['net5'] == -2077
        checked += 3
    return checked


if __name__ == '__main__':
    assert artificial() == 6
    result = run()
    print(json.dumps({k: result[k] for k in ('flip148', 'flip_path', 'flip_known', 'flip_parts')}, ensure_ascii=True))
