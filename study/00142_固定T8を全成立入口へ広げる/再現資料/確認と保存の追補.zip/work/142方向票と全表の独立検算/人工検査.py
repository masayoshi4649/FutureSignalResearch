"""142独立再構成の二段階式と有理数IFDを小型人工で確認する。"""
import copy
from 検算する import direction, calculate, feature_check, KEYS


def values(body, ma, hist) -> dict:
    """
    機能: 人工の3特徴を既知/null形式へする。
    引数: body/ma/hist(float又はNone)。
    返り値: dictは入力3列。
    """
    return {k: {'known': v is not None, 'value': v} for k, v in zip(KEYS, (body, ma, hist))}


# ----------------------------------------
def case(complete: bool, touch: int) -> dict:
    """
    機能: 完了/不足と正逆実価格を別にする保存観測人工を作る。
    引数: complete(bool)、touch(int)は原側のH状態と到達。
    返り値: dictは原側・実逆側・Last側。
    """
    quote = {'time': 100, 'index': 100, 'source_line': 101, 'last': 1130, 'bid': 1125, 'ask': 1135}
    c = {'id': 'P0/人工', 'original_side': 1}
    for key in ('original', 'reverse', 'chart_original', 'chart_reverse'):
        reverse = key.endswith('reverse'); chart = key.startswith('chart_')
        side = -1 if reverse else 1
        price = 1000 if chart or not reverse else 990
        t = -touch if reverse else touch
        c[key] = {'birth': {'side': side}, 'entry_price': price,
                  'outcomes': [{'seconds': 3600, 'status': 'complete' if complete else 'censored',
                                'touches': [{'width': 125, 'direction': t, 'quote': copy.deepcopy(quote) if t else None}],
                                'endpoint': copy.deepcopy(quote) if complete else None}]}
    return c


# ----------------------------------------
def main() -> None:
    """
    機能: 5主群で式の境界/未知・鏡像・touch優先/未知/Lastを検査する。
    引数: なし。
    返り値: None。自然入力を読まない。
    """
    for side in (1, -1):
        for body, ma, hist, want in ((.5,None,None,-1),(.75,None,None,1),(None,0,.1,-1),(.6,-1,-.2,1),(.6,1,.2,-1),(.5,0,-.1,1)):
            assert direction(side,values(body,ma,hist))['t8_side'] == side*want
    selected = {'P0/人工': 1}
    r = calculate([('人工場',case(False,1))],selected,'T0','BBO',3600,125)
    assert r['complete'] == 0 and r['censored'] == 1 and r['forward'] == 0 and r['ifd_known'] == 1 and r['ifd_net5_sum'] == 11423
    r = calculate([('人工場',case(False,0))],selected,'T0','BBO',3600,125)
    assert r['ifd_unknown'] == 1 and r['ifd_net0_sum'] is None and r['ifd_net5_sum'] is None
    r = calculate([('人工場',case(True,1))],{'P0/人工':-1},'T0','BBO',3600,125)
    assert r['adverse'] == 1 and r['flips'] == 1 and r['ifd_net5_sum'] == -15577
    r = calculate([('人工場',case(True,0))],selected,'T0','Last',3600,125)
    assert r['neither'] == 1 and r['ifd_known'] == 1 and r['ifd_points_mean'] == 130 and r['ifd_net5_sum'] is None
    print('独立人工5主群成功。自然値・Root/作者算術importなし。')


if __name__ == '__main__': main()
