"""142の全origin方向と180条件・3表を作者/Root関数importなしで独立再構成する。"""
from pathlib import Path
from collections import Counter, defaultdict
from fractions import Fraction
import argparse
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parents[2]
OWN = Path(__file__).resolve().parent
REFS = {
    'F0': ('work/142固定T8の拡張評価/F0方向前.json', '7ef0d3ddcc8c0618edd657a9d45b9e9971bb946f3c6803f2a5efe04466805509'),
    'F1': ('work/142固定T8の拡張評価/F1金融前.json', '2060e25bdf7dff165cedf1797500ca1644d1710f11e7cd84bf69d10362075a14'),
    '方向': ('work/142固定T8の拡張評価/方向票/全752の方向.json', '7c76a270325aeeb45fff97d4f549568d86920d3452f1d1f9d6e92b9d1988deb8'),
    '集計': ('work/142固定T8の拡張評価/金融評価/集計.json', 'e5b0d87e1fde42619470fa9e6f06d1bdf91e74e9ff96a2af3dee9b889cc3f3c5'),
    '表': ('work/142固定T8の拡張評価/金融評価/CSV用の表.json', 'aa478a32cf65bf8d62c4ecabe3a7245061395e1b0e259021f1328ab59713c189'),
    'model': ('work/142固定T8の全成立への方向票/固定条件.json', 'abf6f27834ec1eaf38104f094337adc9da635abcc8ef157ee5aef378c1af8708'),
    'manifest': ('work/全成立poolの非金融manifest/manifest.json', 'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35'),
    'queries': ('work/138全成立入口の評価/固定入力_版2/特徴照会.json', '81442c3ebaa3065213d0844417bb0462cfa3e5d0a05c4f44edfb3fb14191e75c'),
    'features': ('work/138全成立入口の評価/全出生の当時特徴.json', 'c2b9b8efeb65ba22b2dac3147fdefa3b513cb5cc61cd69249864065f2fcca6e4'),
    'fixed': ('work/138全成立入口の評価/固定入力_版2/固定取得入力.json', '0c83e525dec3079ce188d942069c0d137c94f39009339752ec8227ec9ecb4ce7'),
    'pairs': ('work/138全成立入口の評価/固定取得の正逆観測.json', 'd272fc6f6768342ff67e1a9ec58b0b7307a0a5b07cc215ba5ff7bcb50865b742'),
    'old_stats': ('work/138全成立入口と頻度の集計/集計.json', '6ef283db667603884b42260affce732ba5c9b31731d24b1bb18f9e96ee4b3486'),
    'old_tables': ('work/138全成立入口と頻度の集計/CSV用の表.json', 'c8a83240c0345662353af42d5eeafa306bd68a710f53985be01dc0676c5f2f5d'),
}
KEYS = ('m5_body_ratio_to_side', 'm30_ema21_delta_to_side', 'm5_hist_atr_to_side')


def sha(path: Path) -> str:
    """
    機能: 固定非金融/保存金融JSONの指紋を求める。
    引数: path(Path)は明示対象。
    返り値: strはSHA256。原板/CSV本文を開かない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def same(a: object, b: object) -> None:
    """
    機能: dict/listと型付き値を再帰照合し、比率だけ微小浮動差を許容する。
    引数: a/b(object)は独立値と保存値。
    返り値: None。不一致なら停止する。
    """
    if isinstance(a, dict):
        assert isinstance(b, dict) and set(a) == set(b)
        for k in a: same(a[k], b[k])
    elif isinstance(a, (list, tuple)):
        assert isinstance(b, (list, tuple)) and len(a) == len(b)
        for x, y in zip(a, b): same(x, y)
    elif a is None or type(a) is bool:
        assert type(a) is type(b) and a == b
    elif type(a) in (float, int):
        assert type(b) in (float, int) and math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-9), (a, b)
    else:
        assert a == b


# ----------------------------------------
def scalar(item: dict) -> float | None:
    """
    機能: 既知0と未知nullを区別する。
    引数: item(dict)はknown/value。
    返り値: float又はNone。
    """
    assert type(item['known']) is bool
    if not item['known']:
        assert item['value'] is None
        return None
    v = item['value']; assert type(v) in (float, int) and math.isfinite(v)
    return v


# ----------------------------------------
def direction(native: int, data: dict) -> dict:
    """
    機能: 正本の二段階式を倍率として別記し、未知処置を独立計算する。
    引数: native(int)、data(dict)は保存元向き3特徴。
    返り値: dictは元式の全段階情報。
    """
    assert native in (-1, 1) and type(native) is int
    body, ma, hist = [scalar(data[k]) for k in KEYS]
    first = -1 if body is not None and .5 <= body < .75 else 1
    ma_b = None if ma is None else ma * first
    hist_b = None if hist is None else hist * first
    ma_ok, hist_ok = ma_b is not None and ma_b >= 0, hist_b is not None and hist_b >= .1
    last = -first if ma_ok and hist_ok else first
    return {'native_side': native, 'b0_side': native * first, 't8_side': native * last,
            'known_mask': {k: data[k]['known'] for k in KEYS},
            'all_three_known': all(v is not None for v in (body, ma, hist)),
            'b0_flip': first == -1, 't8_patch_flip': bool(ma_ok and hist_ok),
            'ma30_nonnegative_to_B0': ma_ok, 'hist5_atr_ge_point1_to_B0': hist_ok,
            'values_to_B0': {'body5_ratio_to_native': body, 'ema21_delta30_to_B0': ma_b, 'hist5_atr_to_B0': hist_b}}


# ----------------------------------------
def at(q: dict) -> tuple:
    """
    機能: 時間・採用順・物理行を取り出す。
    引数: q(dict)はQuote又はStamp。
    返り値: tupleは3時計。
    """
    return tuple(q[k] for k in ('time', 'index', 'source_line'))


# ----------------------------------------
def feature_check(row: dict, query: dict) -> None:
    """
    機能: 3特徴のknownと出生以前の公表・freshを別に検査する。
    引数: row/query(dict)は特徴と元出生。
    返り値: None。
    """
    assert row['query'] == query
    now = at(query['birthQuote'])
    for key in KEYS:
        scalar(row['values'][key]); assert row['known_mask'][key] == row['values'][key]['known']
    for ref in row['refs']:
        assert ref['end'] <= now[0] and all(x <= y for x, y in zip(at(ref['delivered']), now))
    for scale in (5, 30):
        foot = row['feet']['m' + str(scale)]
        if foot is None: continue
        assert foot['end'] <= foot['available_at'] <= foot['delivery_at'] <= foot['delivered']['time'] <= now[0]
        assert now[0] < foot['end'] + scale * 60 + 60
        assert all(x <= y for x, y in zip(at(foot['delivered']), now))
        assert {'id': foot['id'], 'width_seconds': scale * 60, 'end': foot['end'], 'delivered': foot['delivered']} in row['refs']
    for key, scale in zip(KEYS, (5, 30, 5)):
        if row['values'][key]['known']: assert row['feet']['m' + str(scale)] is not None and row['feet']['m' + str(scale)]['price_known']


# ----------------------------------------
def directions(manifest: dict, queries: dict, features: dict, saved: dict) -> tuple[dict, dict]:
    """
    機能: 全833入口/850originから752方向を再計算し、全段階票と照合する。
    引数: manifest/queries/features/saved(dict)は固定入力と方向票。
    返り値: tuple[dict,dict]は選択方向と小型証跡。
    """
    qmap = {r['id']: r for r in queries['queries']}; fmap = {r['query']['id']: r for r in features['rows']}
    assert len(qmap) == len(queries['queries']) == len(fmap) == len(features['rows']) == 769 and set(qmap) == set(fmap)
    for qid, q in qmap.items(): feature_check(fmap[qid], q)
    relations = {(r['model'], r['manifest_index'], r['origin_index']): r for r in queries['relations']}
    assert len(relations) == len(queries['relations']) == 850
    actual = {r['id']: r for r in saved['rows']}; assert len(actual) == len(saved['rows']) == 752
    protected = {c['id']: c for c in manifest['C0']}; assert len(protected) == 81
    output, entries, used, touched = {}, [], set(), set()
    reasons, sens, actions = Counter(), Counter(), Counter()
    for model in ('C0', 'P0'):
        for index, c in enumerate(manifest[model]):
            native, baseline = c['side'], c['baseline']
            if baseline:
                assert all(c[k] == protected[c['id']][k] for k in ('session', 'contract', 'side', 'entryQuote'))
            else:
                assert model == 'P0'
            votes, query_ids = [], []
            for oi, origin in enumerate(c['origins']):
                born = origin['birthQuote']; stamp = at(born)
                key = json.dumps([origin['source_file_sha'], origin['source_locator'], origin['side'], stamp], ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
                qid = 'origin/' + hashlib.sha256(key).hexdigest()[:32]
                expected_query = {'id': qid, 'session': c['session'], 'contract': c['contract'], 'side': origin['side'],
                                  'birthQuote': {k: born[k] for k in ('time', 'index', 'source_line', 'last')}}
                assert qmap[qid] == expected_query
                rk = (model, index, oi)
                assert relations[rk] == {'entry_id': model + '/' + c['id'], 'query_id': qid, 'model': model,
                                         'manifest_index': index, 'origin_index': oi, 'family': origin['family'], 'side': origin['side'], 'selected_side': native}
                assert all(a <= b for a, b in zip(stamp, at(c['entryQuote'])))
                assert all(origin['entryQuote'][k] == c['entryQuote'][k] for k in ('time', 'index', 'source_line', 'last', 'bid', 'ask', 'quote_ok'))
                if not baseline: assert origin['side'] == native
                f = fmap[qid]; data = {k: f['values'][k] for k in KEYS}
                result = None if baseline else direction(native, data)
                votes.append({'origin_index': oi, 'query_id': qid, 'family': origin['family'], 'source_file_sha': origin['source_file_sha'],
                              'source_locator': origin['source_locator'], 'birthQuote': expected_query['birthQuote'], 'native_side': native,
                              'formula_applied': not baseline, 'values': data, 'known_mask': {k: data[k]['known'] for k in KEYS},
                              'refs': f['refs'], 'feet': {k: f['feet'][k] for k in ('m5', 'm30')}, 'result': result})
                used.add(qid); touched.add(rk); query_ids.append(qid)
            entries.append({'id': model + '/' + c['id'], 'session': c['session'], 'model': model, 'origin_query_ids': query_ids})
            if model == 'C0': continue
            sides = {native} if baseline else {v['result']['t8_side'] for v in votes}
            agree = len(sides) == 1
            selected = next(iter(sides)) if agree else native
            all_known = all(all(v['known_mask'].values()) for v in votes)
            if baseline: reason = '固定81native保護・T8再適用なし'
            elif not agree: reason = 'origin方向不一致・native維持'
            elif selected != native: reason = '元T8の全origin方向一致・反転'
            else: reason = '元T8の全origin方向一致・native維持'
            flip = selected != native; action = 'flip' if flip else 'keep'
            expected = {'id': 'P0/' + c['id'], 'session': c['session'], 'native_side': native, 'selected_side': selected, 'baseline': baseline,
                        'flip': flip, 'action': action, 'reason': reason, 'all_origins_known': all_known, 'all_origins_agree': agree,
                        'origin_query_ids': query_ids, 'origin_count': len(query_ids), 'unique_query_count': len(set(query_ids)), 'origins': votes}
            same(expected, actual[expected['id']]); output[expected['id']] = selected
            reasons[reason] += 1; actions[action] += 1
            if not baseline:
                sens['追加全3特徴既知'] += all_known; sens['追加に未知あり'] += not all_known
                sens['参考_全3既知を足した反転数'] += flip and all_known
                sens['主では反転_参考全3既知guardなら維持'] += flip and not all_known
    assert used == set(qmap) and touched == set(relations) and len(entries) == 833
    same(entries, saved['entry_origins']); same(dict(actions), saved['counts']); same(dict(reasons), saved['reasons']); same(dict(sens), saved['known_sensitivity_only'])
    assert actions == Counter(flip=148, keep=604)
    return output, {'全752方向': len(output), '固定81保護': 81, '全833入口': len(entries), '全850relations': len(touched), '全769query': len(used),
                    '方向件数': dict(actions), '段階別未知感度': dict(sens)}


# ----------------------------------------
def qfraction(value: float) -> Fraction:
    """
    機能: 保存価格の十進値を有理数として扱う。
    引数: value(float)は保存価格。
    返り値: Fractionは正確な十進価格。
    """
    return Fraction(str(value))


# ----------------------------------------
def exit_value(view: dict, horizon: int, width: int, axis: str) -> dict:
    """
    機能: 既知touchをH不足より優先し、なければ完了endpointだけで精算する。
    引数: view(dict)、horizon/width(int)、axis(str)。
    返り値: dictは先着状態と有理数損益。金額未知はNone。
    """
    o = next(x for x in view['outcomes'] if x['seconds'] == horizon)
    t = next(x for x in o['touches'] if x['width'] == width)
    endpoint = t['quote'] if t['direction'] else o['endpoint'] if o['status'] == 'complete' else None
    if endpoint is None:
        return {'status': o['status'], 'touch': t['direction'], 'known': False, 'reason': '観測不足', 'points': None, 'net0': None, 'net5': None}
    side = view['birth']['side']
    mark = endpoint['last'] if axis == 'Last' else endpoint['bid' if side > 0 else 'ask']
    points = side * (qfraction(mark) - qfraction(view['entry_price']))
    reason = {1: '順行到達', -1: '逆行到達', 0: '期限清算'}[t['direction']]
    return {'status': o['status'], 'touch': t['direction'], 'known': True, 'reason': reason, 'points': points,
            'net0': points * 100 - 77 if axis == 'BBO' else None, 'net5': points * 100 - 1077 if axis == 'BBO' else None}


# ----------------------------------------
def numeric(value: Fraction | None) -> float | int | None:
    """
    機能: 有理数をJSON比較用の値へ変換する。
    引数: value(Fraction又はNone)。
    返り値: int/float又はNone。
    """
    if value is None: return None
    return value.numerator if value.denominator == 1 else float(value)


# ----------------------------------------
def calculate(records: list, selected: dict, policy: str, axis: str, horizon: int, width: int) -> dict:
    """
    機能: 保存正逆streamを方向票で選び180条件の統計を別計算する。
    引数: records(list[(session,case)])、selected(dict)、policy/axis(str)、horizon/width(int)。
    返り値: dictは独立統計。
    """
    outcomes, flips = [], 0
    for sid, c in records:
        side = selected[c['id']] if policy == 'T0' else c['original_side']
        reverse = side != c['original_side']; flips += reverse
        key = ('chart_' if axis == 'Last' else '') + ('reverse' if reverse else 'original')
        outcomes.append(exit_value(c[key], horizon, width, axis))
    complete = [r for r in outcomes if r['status'] == 'complete']; count = Counter(r['touch'] for r in complete)
    known = [r for r in outcomes if r['known']]; reasons = Counter(r['reason'] for r in outcomes)
    points = [r['points'] for r in known]; money = [r['net5'] for r in known] if axis == 'BBO' else []
    f, a, z = count[1], count[-1], count[0]; resolved = f+a
    gains, losses = sum((x for x in money if x > 0), Fraction()), -sum((x for x in money if x < 0), Fraction())
    total = sum(money, Fraction()) if money else None
    return {'entries': len(records), 'sessions': len({sid for sid, _ in records}), 'complete': len(complete), 'censored': len(records)-len(complete),
            'forward': f, 'adverse': a, 'neither': z, 'resolved': resolved, 'resolved_rate': f/resolved if resolved else None,
            'complete_rate': f/len(complete) if complete else None, 'target70': Fraction(f, resolved) >= Fraction(7, 10) if resolved else None,
            'target70_all': Fraction(f, len(complete)) >= Fraction(7, 10) if complete else None,
            'ifd_known': len(known), 'ifd_unknown': len(outcomes)-len(known), 'ifd_exits': dict(reasons),
            'ifd_net0_sum': numeric(total+len(known)*1000) if total is not None else None,
            'ifd_net5_sum': numeric(total), 'ifd_net5_mean': numeric(total/len(money)) if money else None,
            'ifd_net5_profit': numeric(gains) if money else None, 'ifd_net5_loss': numeric(losses) if money else None,
            'ifd_net5_pf': numeric(gains/losses) if losses else None, 'ifd_net5_positive': sum(x > 0 for x in money) if axis == 'BBO' else None,
            'ifd_points_mean': numeric(sum(points, Fraction())/len(points)) if points else None, 'flips': flips}


# ----------------------------------------
def main() -> None:
    """
    機能: Root許可後の固定方向/保存金融を全origin・180条件・3表で独立照合する。
    引数: CLI --execute-after-root-notification(bool)。
    返り値: None。検査器は見出し/一部schema閲覧後に準備し、条件最適化を行わない。
    """
    parser = argparse.ArgumentParser(description='142の全originと全表を独立再構成')
    parser.add_argument('--execute-after-root-notification', action='store_true', required=True); parser.parse_args()
    target = OWN / '独立検算.json'; assert not target.exists()
    for name, (relative, expected) in REFS.items(): assert sha(ROOT/relative) == expected, name
    docs = {name: json.loads((ROOT/relative).read_bytes()) for name, (relative, _) in REFS.items()}
    f0, f1, saved, summary = [docs[k] for k in ('F0', 'F1', '方向', '集計')]
    assert f0['試行'] == f1['試行'] == saved['trial'] == summary['試行'] == 142
    assert f1['F0_SHA256'] == saved['F0_SHA256'] == REFS['F0'][1] and summary['F1_SHA256'] == REFS['F1'][1]
    assert summary['方向SHA256'] == REFS['方向'][1] and summary['モデルSHA256'] == saved['model_sha256'] == REFS['model'][1]
    assert saved['features_sha256'] == REFS['features'][1] and saved['queries_sha256'] == REFS['queries'][1] and saved['manifest_sha256'] == REFS['manifest'][1]
    assert docs['model']['inherited_T8_learned'] is True and docs['model']['learned'] is False and docs['model']['all_three_known_required'] is False
    for name in ('方向', 'model', 'manifest', 'queries', 'features', 'fixed', 'pairs', 'old_stats'):
        relative, expected = REFS[name]; assert f1['ファイル'][str(ROOT/relative)] == expected
    chosen, direction_proof = directions(docs['manifest'], docs['queries'], docs['features'], saved)
    sessions = [s['session'] for s in docs['fixed']['scenes']]
    assert len(sessions) == len(set(sessions)) == 73 and saved['sessions'] == sessions
    fixed = {e['id']: (s, e) for s in docs['fixed']['scenes'] for e in s['entries']}
    cases = {c['id']: (s['session'], c) for s in docs['pairs']['scenes'] for c in s['cases']}
    assert set(fixed) == set(cases) and len(cases) == 833
    assert {k for k in cases if k.startswith('P0/')} == set(chosen)
    phase_quotes = 0
    for identity, (sid, c) in cases.items():
        scene, original = fixed[identity]
        assert sid == scene['session'] and c['original_side'] == original['side']
        if identity.startswith('P0/'):
            assert saved['rows'][next(i for i, r in enumerate(saved['rows']) if r['id'] == identity)]['native_side'] == c['original_side']
        for key in ('original', 'reverse', 'chart_original', 'chart_reverse'):
            view = c[key]; assert view['entry'] == original['entry'] and view['entry']['time'] < min(scene['force_close'], scene['end']-3900)
            expected_side = c['original_side'] * (-1 if key.endswith('reverse') else 1)
            assert view['birth']['side'] == expected_side
            for out in view['outcomes']:
                for q in [out['endpoint']] + [t['quote'] for t in out['touches']]:
                    if q is not None: assert q['time'] < scene['end']-300; phase_quotes += q is not None
    values, n, cells, controls = {}, 0, 0, 0
    for part, ids in (('all', sessions), ('train', sessions[:48]), ('validation', sessions[48:])):
        values[part] = {}
        for policy in ('T0', 'P0', 'C0'):
            cohort = 'C0/' if policy == 'C0' else 'P0/'
            records = [(sid, c) for identity, (sid, c) in cases.items() if identity.startswith(cohort) and sid in ids]
            hours = sum((s['end']-300-s['start'])/3600 for s in docs['fixed']['scenes'] if s['session'] in ids)
            model = 'C0' if policy == 'C0' else 'P0'
            same(summary['頻度'][part][model]['全時間平均件数毎時'], len(records)/hours)
            assert summary['参加'][part][model]['取得数'] == len(records) and summary['参加'][part][model]['全場最低1取得'] == (len({sid for sid, _ in records}) == len(ids))
            values[part][policy] = {}
            for axis in ('BBO', 'Last'):
                values[part][policy][axis] = {}
                for h in (1800, 3600):
                    values[part][policy][axis][str(h)] = {}
                    for width in (25, 50, 100, 125, 200):
                        expected = calculate(records, chosen, policy, axis, h, width)
                        same(expected, summary['集計'][part][policy][axis][str(h)][str(width)])
                        values[part][policy][axis][str(h)][str(width)] = expected
                        n += 1; cells += len(expected)
                        if policy != 'T0': same(expected, docs['old_stats']['集計'][part][policy][axis][str(h)][str(width)]); controls += policy != 'T0'
    assert n == 180 and controls == 120
    new_tables, old_tables = docs['表']['tables'], docs['old_tables']['tables']
    assert [(len(t['rows']), len(t['headers'])) for t in new_tables] == [(180,34),(833,36),(73,49)]
    comparison = []
    for part in ('all', 'train', 'validation'):
        for policy in ('T0', 'P0', 'C0'):
            model = 'C0' if policy == 'C0' else 'P0'; p = summary['参加'][part][model]; freq = summary['頻度'][part][model]
            for axis in ('BBO', 'Last'):
                for h in (1800, 3600):
                    for width in (25,50,100,125,200):
                        s = values[part][policy][axis][str(h)][str(width)]; both = p['全場最低1取得'] and s['target70'] is True
                        comparison.append([142,part,policy,model,axis,h/60,width,p['対象場数'],s['sessions'],s['entries'],s['flips'],p['全場最低1取得'],s['complete'],s['censored'],s['forward'],s['adverse'],s['neither'],s['resolved_rate'],s['complete_rate'],s['forward']/s['entries'] if s['entries'] else None,s['target70'],bool(both),freq['全時間平均件数毎時'],freq['名目新規可時間平均件数毎時'],freq['全時間平均1件毎時以上'],bool(both and freq['全時間平均1件毎時以上']),s['ifd_known'],s['ifd_unknown'],s['ifd_net0_sum'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],s['ifd_net5_mean'],s['ifd_net5_pf']])
    same(comparison, new_tables[0]['rows']); assert new_tables[0]['headers'] == old_tables[0]['headers']
    for current, prior in zip(new_tables[1]['rows'], old_tables[1]['rows'], strict=True):
        prefix = list(prior[:18]); prefix[0] = 142
        identity = prefix[4]; sid, c = cases[identity]; expected = prefix
        for policy in ('T0', 'P0', 'C0'):
            if identity.startswith('C0/') != (policy == 'C0'): expected += [None]*6; continue
            side = chosen[identity] if policy == 'T0' else c['original_side']
            view = c['reverse' if side != c['original_side'] else 'original']
            out = exit_value(view,3600,125,'BBO')
            expected += [side,out['status'],out['touch'],out['known'],out['reason'],numeric(out['net5'])]
        same(expected, current)
    cumulative, unknown = Counter(), Counter()
    for i, (current, prior) in enumerate(zip(new_tables[2]['rows'], old_tables[2]['rows'], strict=True)):
        expected = list(prior[:13]); expected[0] = 142; sid = sessions[i]
        assert prior[1] == sid
        for policy in ('T0', 'P0', 'C0'):
            records = [(session, c) for identity, (session, c) in cases.items() if session == sid and identity.startswith('C0/' if policy == 'C0' else 'P0/')]
            s = calculate(records,chosen,policy,'BBO',3600,125)
            cumulative[policy] += s['ifd_net5_sum'] or 0; unknown[policy] += s['ifd_unknown']
            expected += [s['flips'],s['forward'],s['adverse'],s['neither'],s['censored'],s['ifd_known'],s['ifd_unknown'],s['ifd_net5_profit'],s['ifd_net5_loss'],s['ifd_net5_sum'],cumulative[policy],unknown[policy]]
        same(expected,current)
    for index, (prefix, block) in enumerate(((18,6),(13,12)),1):
        headers = old_tables[index]['headers'][:prefix]
        for p, source in (('T0','P0'),('P0','P0'),('C0','C0')):
            start = prefix + ('P0','C0','R0').index(source)*block
            headers += [p + h[len(source):] for h in old_tables[index]['headers'][start:start+block]]
        assert headers == new_tables[index]['headers']
    assert sum(len(t['rows'])*len(t['headers']) for t in new_tables) == 39685
    for name, (relative, expected) in REFS.items(): assert sha(ROOT/relative) == expected, name
    proof = {'成功':True,'確認日':'2026-11-12','試行':142,'段階':'方向と保存金融全表の独立再構成・停止',
             '全origin独立再計算':direction_proof,'全73場':True,'全833保存入口':833,'全180比較':n,'統計セル':cells,'旧native対照同体':controls,'全3表セル':39685,'phase既知quote照合数':phase_quotes,
             '主T0':values['all']['T0']['BBO']['3600']['125'],'Root_作者関数import':False,'金融算術':'Fractionによる保存実BBO/Lastのtouch優先IFD独立再計算','入力前後同体':True,
             'Raw_CSV本文_追加2場読取':False,'正式142_旧源変更':False,'準備時点':'Rootの主結果見出し、JSON構造と先頭表行のschema閲覧後に検査器準備。閾値/条件選定は行わない。',
             '入力':{name:{'path':relative,'sha256':expected} for name,(relative,expected) in REFS.items()},'独立コードSHA256':sha(Path(__file__))}
    with target.open('x',encoding='utf-8',newline='\n') as stream: json.dump(proof,stream,ensure_ascii=False,indent=2); stream.write('\n')
    print(json.dumps({'成功':True,'全方向':752,'origin結合':850,'金融条件':n,'全表セル':39685,'独立検算SHA256':sha(target)},ensure_ascii=False))


if __name__ == '__main__': main()
