"""142のF0/F1全原文を先退避し、新方向/モデルだけ一度gzip保存する。"""
from pathlib import Path
import gzip
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00142_*'))
RUN=ROOT/'work/142固定T8の拡張評価'


def sha(raw: bytes) -> str:
    """
    機能: 原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def save(source: Path,target: Path,packed: bool=False) -> dict:
    """
    機能: 未作成先へ同体又はgzipを保存する。
    引数: source/target(Path)、packed(bool)。
    返り値: dictは復元先と保存/解凍指紋。
    """
    raw=source.read_bytes();body=gzip.compress(raw,mtime=0) if packed else raw;target.parent.mkdir(parents=True,exist_ok=True)
    with target.open('xb') as f:f.write(body)
    return {'保存元':target.relative_to(ROOT).as_posix(),'復元先':source.relative_to(ROOT).as_posix(),'形式':'gzip' if packed else '同体',
        '保存bytes':len(body),'保存SHA256':sha(body),'解凍bytes':len(raw),'解凍SHA256':sha(raw)}


# ----------------------------------------
def main() -> None:
    """
    機能: 全30直接源を共有/新固定/小型入力へ解決し、条件と結果の原文を先に残す。
    引数: なし。
    返り値: None。新Raw/旧大入力複写/旧試行変更をしない。
    """
    freezes={};docs={}
    for name,h in [('F0方向前.json','7ef0d3ddcc8c0618edd657a9d45b9e9971bb946f3c6803f2a5efe04466805509'),
        ('F1金融前.json','2060e25bdf7dff165cedf1797500ca1644d1710f11e7cd84bf69d10362075a14')]:
        raw=(RUN/name).read_bytes();assert sha(raw)==h;freezes[name]=json.loads(raw);save(RUN/name,FORMAL/'検査'/name)
        for p,expected in freezes[name]['ファイル'].items():
            path=Path(p)
            if path.suffix=='.md':
                b=path.read_bytes();assert sha(b)==expected;rel=path.relative_to(ROOT).as_posix();docs[rel]={'path':rel,'sha256':expected,'bytes':len(b),'本文':b.decode('utf-8')}
    assert len(freezes['F0方向前.json']['ファイル'])==17 and len(freezes['F1金融前.json']['ファイル'])==30
    snap={'試行':142,'段階':'F0/F1全MDの結果編集前原文','文書数':len(docs),'正式文書数':sum(n.startswith('study/') for n in docs),'文書':list(docs.values()),'事前固定の後造り':False}
    assert snap['正式文書数']==3
    with (FORMAL/'検査/実行前文書.json.gz').open('xb') as f:f.write(gzip.compress((json.dumps(snap,ensure_ascii=False,indent=2)+'\n').encode('utf-8'),mtime=0))
    prior138=next((ROOT/'study').glob('00138_*'));m138=json.loads((prior138/'保管索引.json').read_bytes())
    data_registry={x['復元先']:x for x in m138['共有入力']+m138['新共用入力']+[m138['特徴診断入力'],m138['保存済み正逆観測'],m138['集計正本']]}
    inputs=[save(ROOT/'work/142固定T8の全成立への方向票/固定条件.json',ROOT/'inputs/00142_固定T8全成立/固定条件.json.gz',True),
        save(RUN/'方向票/全752の方向.json',ROOT/'inputs/00142_固定T8全成立/全752の方向.json.gz',True)]
    inputmap={x['復元先']:x for x in inputs}
    f0ref={'保存元':(FORMAL/'検査/F0方向前.json').relative_to(ROOT).as_posix(),'復元先':'work/142固定T8の拡張評価/F0方向前.json','形式':'同体',
        '保存bytes':(FORMAL/'検査/F0方向前.json').stat().st_size,'保存SHA256':sha((FORMAL/'検査/F0方向前.json').read_bytes()),
        '解凍bytes':(FORMAL/'検査/F0方向前.json').stat().st_size,'解凍SHA256':sha((FORMAL/'検査/F0方向前.json').read_bytes())}
    inputmap[f0ref['復元先']]=f0ref
    groups=[];registry={}
    for number,key in [(133,'固定コード'),(138,'追加固定資料'),(141,'F1増分固定資料')]:
        folder=next((ROOT/'study').glob(f'{number:05d}_*'));m=json.loads((folder/'保管索引.json').read_bytes());item=m[key];path=folder/'再現資料'/item['ZIP']
        assert sha(path.read_bytes())==item['ZIP_SHA256'];at=len(groups);groups.append({'保存元ZIP':path.relative_to(ROOT).as_posix(),'ZIP_SHA256':item['ZIP_SHA256'],'格納源':[]})
        for x in item['格納源']:registry.setdefault(x['sha256'],(at,x['path']))
    new=[];bodies={};shared=[]
    for name,h in freezes['F1金融前.json']['ファイル'].items():
        p=Path(name);rel=p.relative_to(ROOT).as_posix()
        if rel in inputmap:assert inputmap[rel]['解凍SHA256']==h;continue
        if rel in data_registry:assert data_registry[rel]['解凍SHA256']==h;shared.append(data_registry[rel]);continue
        raw=p.read_bytes();assert sha(raw)==h and len(raw)<1_000_000
        if h in registry:
            at,entry=registry[h];groups[at]['格納源'].append({'復元先':rel,'ZIP内path':entry,'sha256':h,'bytes':len(raw)})
        else:new.append({'path':rel,'sha256':h,'bytes':len(raw)});bodies[rel]=raw
    assert len(new)+len(shared)+len(inputmap)+sum(len(x['格納源']) for x in groups)==30
    archive=FORMAL/'再現資料/142方向金融前の固定資料.zip';archive.parent.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for x in new:z.writestr(x['path'],bodies[x['path']])
    for g in groups:g['格納源数']=len(g['格納源'])
    aggregate=save(RUN/'金融評価/集計.json',FORMAL/'成果物/集計.json')
    assert aggregate['解凍SHA256']=='e5b0d87e1fde42619470fa9e6f06d1bdf91e74e9ff96a2af3dee9b889cc3f3c5'
    for n in ('方向の完了.json','集計の完了.json','金融集計の独立確認.json','CSV全セルの独立再読.json'):
        save(RUN/n,FORMAL/'検査'/n)
    save(RUN/'金融評価/集計完了.json',FORMAL/'検査/集計器の完了.json')
    save(ROOT/'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/142_固定T8全成立適用/CSVの確認.json',FORMAL/'検査/CSV作成の確認.json')
    m={'試行':142,'段階':'F0/F1原文・全入力・金融/CSV正本の保存。結果追記前','F0_SHA256':sha((RUN/'F0方向前.json').read_bytes()),'F1_SHA256':sha((RUN/'F1金融前.json').read_bytes()),
        'F0直接源':17,'F1直接源':30,'追加固定資料':{'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(new),'格納源':new},
        '共有固定コード群':groups,'共有入力':shared,'新共用入力':inputs,'元F0の復元参照':f0ref,'集計正本':aggregate,
        'CSV正本':'outputs/01a1889f-f2af-7943-a047-543275ee9ed2/142_固定T8全成立適用','表JSON再現期待SHA256':'aa478a32cf65bf8d62c4ecabe3a7245061395e1b0e259021f1328ab59713c189',
        '新Raw/177MB/大観測22MB/features/manifestの複写':False,'旧141以前/追加2場変更':False}
    (FORMAL/'保管索引.json').write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'退避MD':len(docs),'正式MD':3,'F1全30源復元参照':True,'新入力gzip':2,'固定ZIP_SHA256':m['追加固定資料']['ZIP_SHA256']},ensure_ascii=False))


if __name__=='__main__':main()
