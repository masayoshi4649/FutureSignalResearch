"""142の停止済み変更群診断を恒久保存する。新しい群選択をしない。"""
from pathlib import Path
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00142_*'))
SOURCE=ROOT/'work/142拡張条件の原因診断'


def sha(raw: bytes) -> str:
    """
    機能: 原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 正本診断票を1gzip、区分/確認を同体保存して結果の解釈へ結ぶ。
    引数: なし。
    返り値: None。方向/条件/旧源を変更せず再計算もしない。
    """
    proofraw=(SOURCE/'診断の確認.json').read_bytes();proof=json.loads(proofraw);assert proof['成功'] and proof['編集停止']
    for x in proof['保存資料']:assert sha(Path(x['path']).read_bytes())==x['sha256']
    (FORMAL/'根拠').mkdir(exist_ok=True)
    raw=(SOURCE/'拡張分岐別の比較.json').read_bytes();packed=gzip.compress(raw,mtime=0);target=FORMAL/'根拠/拡張分岐別の比較.json.gz'
    with target.open('xb') as f:f.write(packed)
    (FORMAL/'検査/原因診断の確認.json').write_bytes(proofraw)
    (FORMAL/'根拠/診断の区分.md').write_bytes((SOURCE/'診断の区分.md').read_bytes())
    text=(SOURCE/'結果の要点.md').read_text('utf-8').replace('(拡張分岐別の比較.json)','(拡張分岐別の比較.json.gz)').replace('(診断する.py)','(../再現資料/確認と保存の追補.zip)')
    text=text.replace('[事前に置いた診断方針]','[診断用に定義した区分]')
    text += '\n本資料は142金融後の保存データによる事後診断である。区分は診断計算の前に定義したもので、142の金融前F1へ新たな選別規則を固定した意味ではない。原文・コードも追補ZIPに残す。\n'
    (FORMAL/'根拠/拡張条件の原因.md').write_text(text,encoding='utf-8')
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes());m['原因診断票']={'保存元':target.relative_to(ROOT).as_posix(),
        '復元先':(SOURCE/'拡張分岐別の比較.json').relative_to(ROOT).as_posix(),'形式':'gzip','保存bytes':len(packed),'保存SHA256':sha(packed),'解凍bytes':len(raw),'解凍SHA256':sha(raw)}
    m['原因診断確認SHA256']=sha(proofraw);mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    report='''## 変更群の事後診断

[全148反転の診断](根拠/拡張条件の原因.md)では元56順64逆18未10不足→49順73逆16未10不足。元の順行56件を全て失い、元逆行を順行へ変えたのは49件、両実側とも逆行した12件もあった。反転は単純な補数ではない。

B0だけの88件も第2段だけの60件も悪化し、両IFD既知ペア差はそれぞれ−157,000/−145,000円。全3特徴が既知の129件でも悪化し、部分未知19件ではペア差が+12,000円だったため、未知処置だけが主因とは言えない。結果後に全3known guardを追加する根拠にしない。

両側IFD既知143件のペア差−302,000円と、元未知→新既知3件の損失−42,231円を分けると、全既知合計差−344,231円に一致した。未知の減少自体を改善と呼ばない。大きい悪化はU165_03の30件（両既知ペア差−316,000円）に集中し、129 C1では改善したが、同じ条件の意味が出生familyで異なるという事後観測である。これをそのままfamily除外ルールへ変えない。

元の学習領域の例外条件を別の出生群へ移す前に、勢い継続と失速/構造否定を当時の価格・量で分けて検証する必要がある。現在の結果だけで市場心理の因果関係や新しい入口規則の有効性を実証したとはしない。

'''
    readme=(FORMAL/'README.md').read_text('utf-8');assert '## 保存・再現・閲覧' in readme
    (FORMAL/'README.md').write_text(readme.replace('## 保存・再現・閲覧',report+'## 保存・再現・閲覧',1),encoding='utf-8')
    print(json.dumps({'成功':True,'原因確認SHA256':sha(proofraw),'原因gzipSHA256':sha(packed)},ensure_ascii=False))


if __name__=='__main__':main()
