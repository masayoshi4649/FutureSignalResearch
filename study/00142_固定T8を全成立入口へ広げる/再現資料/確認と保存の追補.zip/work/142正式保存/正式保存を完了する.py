"""142の停止済み独立・原因・保存資料だけをまとめて正式保存を閉じる。"""
from pathlib import Path
import gzip
import hashlib
import json
import re
import zipfile

ROOT=Path(__file__).resolve().parents[2]
FORMAL=next((ROOT/'study').glob('00142_*'))


def sha(raw: bytes) -> str:
    """
    機能: 原文の指紋を求める。
    引数: raw(bytes)。
    返り値: strはSHA256。
    """
    return hashlib.sha256(raw).hexdigest()


# ----------------------------------------
def cells(body: str) -> list:
    """
    機能: 固定済み57手法9尺度の設定を抽出する。
    引数: body(str)。
    返り値: listはIDと513セル。
    """
    rows=[]
    for line in body.splitlines():
        if re.match(r'^\| [A-Z]+\d{2} \|',line):
            row=[v.strip() for v in line.strip('|').split('|')]
            if len(row)==11:rows.append([row[0],row[2:]])
    assert len(rows)==57 and sum(len(row[1]) for row in rows)==513
    return rows


# ----------------------------------------
def main() -> None:
    """
    機能: 結果状態と再現資料を最小保存し、原文・元条件・513セル・既存証跡を照合する。
    引数: なし。
    返り値: None。自然再生・価格読取・新金融/CSV生成・旧試行変更はしない。
    """
    mpath=FORMAL/'保管索引.json';m=json.loads(mpath.read_bytes())
    body=(FORMAL/'README.md').read_text('utf-8')
    body=body.replace('方向票再生成・金融・Root金融独立確認・CSV確認を完了。方向独立照合と正式保存を確定中。',
                      '方向票再生成・金融・全方向/全表の独立検算・CSV・再現・正式保存を完了。未達として固定し、編集停止。')
    note='''[全方向と金融全表の独立検算](検査/独立検算.json)では全752方向/850origin/769query/833基礎入口、全180条件・4,320統計セル、旧120対照、三表39,685セルを別算術で一致した。作者/Root関数をimportせずIFDをFractionで再算し、人工5群も成功。[停止票](検査/独立停止の確認.json)に記すとおり主見出し・一部schemaを閲覧後に検査器を準備し、自然照合は初回成功。金融前に未知の独立評価を行ったとはしない。

'''
    assert '全方向と金融全表の独立検算' not in body
    body=body.replace('## 保存・再現・閲覧\n\n','## 保存・再現・閲覧\n\n'+note,1)
    (FORMAL/'README.md').write_text(body,encoding='utf-8')
    for name in ('README.md','study/README.md','docs/README.md','docs/議論/README.md'):
        p=ROOT/name;body=p.read_text('utf-8')
        assert '[142：' in body
        body=body.replace('の金融/CSVを実行済み、方向独立照合と正式保存を確定中。','の方向/金融/独立検算/CSV/再現・正式保存を完了。',1)
        body=body.replace('金融独立180比較/CSV39,685セル・保存観測再現を保存。','全方向独立照合/金融180比較/三表39,685セル・原因診断・保存観測再現を保存。',1)
        p.write_text(body,encoding='utf-8')
    p=FORMAL/'再現手順.md';body=p.read_text('utf-8')
    body=body.replace('方向全752/全origin850の独立照合と、変更群の原因診断は別の停止資料として保存索引へ追加する。',
        '[独立検算](検査/独立検算.json)は全752方向/850origin/769query/833入口・全180条件/旧120・39,685表セルを一致し、[停止票](検査/独立停止の確認.json)へ検査範囲を残した。見出し/schema一部閲覧後の検査器であり、作者/Root算術importなし・人工5群・自然照合初回成功。\n\n[変更群の事後原因](根拠/拡張条件の原因.md)と[確認票](検査/原因診断の確認.json)も保存した。148反転の両IFD既知143件差−302,000円と、新既知3件−42,231円を分け、全合計差−344,231円を説明する。B0/第2段の両方と全3既知群も悪化し、未知処理だけを原因としない。独立/原因の原文コードと保存用コードは[追補ZIP](再現資料/確認と保存の追補.zip)、CSVwriter v2/readerは共有ZIP参照。区分は金融後の診断用であり、新しい選別規則を事前固定したものではない。')
    p.write_text(body,encoding='utf-8')
    p=FORMAL/'根拠/拡張条件の原因.md';body=p.read_text('utf-8').replace('主勝率の分母','主到達済み先着率の分母');p.write_text(body,encoding='utf-8')
    # ----------------------------------------
    independent=ROOT/'work/142方向票と全表の独立検算';stop=json.loads((independent/'停止の確認.json').read_bytes())
    files=list((ROOT/'work/142正式保存').glob('*.py'))+list((FORMAL/'再現資料').glob('*.py'))
    for name,h in stop['保存対象'].items():
        p=independent/name;assert sha(p.read_bytes())==h
        if name!='独立検算.json':files.append(p)
    cause=ROOT/'work/142拡張条件の原因診断';cp=json.loads((cause/'診断の確認.json').read_bytes())
    assert cp['成功'] and cp['編集停止']
    files += [cause/n for n in ('結果の要点.md','診断する.py')]
    new=[];bodies={}
    for p in sorted(set(files)):
        raw=p.read_bytes();assert len(raw)<1000000;rel=p.relative_to(ROOT).as_posix()
        new.append({'path':rel,'sha256':sha(raw),'bytes':len(raw),'区分':'F0/F1直接源外の独立・事後原因・保存/復元'})
        bodies[rel]=raw
    archive=FORMAL/'再現資料/確認と保存の追補.zip'
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for item in new:z.writestr(item['path'],bodies[item['path']])
    m['後発資料']={'ZIP':archive.name,'ZIP_SHA256':sha(archive.read_bytes()),'ZIP_bytes':archive.stat().st_size,'格納源数':len(new),'格納源':new}
    groups=[]
    for prefix,zipname,entry,h in [
        ('00141_','確認と保存の追補.zip','work/確定三表のCSV出力_版2/出力する.mjs','0994706575ed4fc634fe5d0577d48b5b79e95ff0db2330407daf02a74ca478d3'),
        ('00140_','確認と保管の追補.zip','work/確定三表のCSV出力/CSVを独立再読する.py','f161688d1e4f742c0e290e45bbbbbf6506ee07ac06eb01e505d3455c24c9b60b')]:
        prior=next((ROOT/'study').glob(prefix+'*'));pm=json.loads((prior/'保管索引.json').read_bytes());zp=prior/'再現資料'/zipname
        assert sha(zp.read_bytes())==pm['後発資料']['ZIP_SHA256']
        with zipfile.ZipFile(zp) as z:raw=z.read(entry);assert sha(raw)==h
        groups.append({'保存元ZIP':zp.relative_to(ROOT).as_posix(),'ZIP_SHA256':sha(zp.read_bytes()),'格納源数':1,
            '格納源':[{'復元先':entry,'ZIP内path':entry,'sha256':h,'bytes':len(raw)}]})
    m['後発共有コード']=groups
    m['段階']='方向/金融/独立全方向・全金融表/CSV/原因/保存観測再現/正式保存完了。主51.04%で未達、不採用・編集停止'
    m['保存観測再現SHA256']='09e42555ee81e7a41eb06befbf4ec39badadaff31a2e3e311443bb53c2c31688'
    mpath.write_text(json.dumps(m,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    # ----------------------------------------
    snapshot=json.loads(gzip.decompress((FORMAL/'検査/実行前文書.json.gz').read_bytes()))
    assert snapshot['正式文書数']==3 and snapshot['文書数']==4
    for item in snapshot['文書']:assert sha(item['本文'].encode('utf-8'))==item['sha256']
    original={Path(x['path']).name:x['本文'] for x in snapshot['文書'] if x['path'].startswith('study/')}
    assert cells(original['設定と結果.md'])==cells((FORMAL/'設定と結果.md').read_text('utf-8'))
    assert (FORMAL/'条件.md').read_bytes().startswith(original['条件.md'].encode('utf-8'))
    assert sha((FORMAL/'検査/F0方向前.json').read_bytes())==m['F0_SHA256']
    assert sha((FORMAL/'検査/F1金融前.json').read_bytes())==m['F1_SHA256']
    for item in [m['追加固定資料'],m['後発資料']]+m['共有固定コード群']+groups:
        zp=ROOT/item['保存元ZIP'] if '保存元ZIP' in item else FORMAL/'再現資料'/item['ZIP']
        assert sha(zp.read_bytes())==item['ZIP_SHA256']
        with zipfile.ZipFile(zp) as z:
            assert z.testzip() is None
            for entry in item['格納源']:assert sha(z.read(entry.get('ZIP内path',entry.get('path'))))==entry['sha256']
    for item in m['共有入力']+m['新共用入力']+[m['元F0の復元参照'],m['集計正本'],m['原因診断票']]:
        raw=(ROOT/item['保存元']).read_bytes();assert sha(raw)==item['保存SHA256']
        decoded=gzip.decompress(raw) if item['形式']=='gzip' else raw;assert sha(decoded)==item['解凍SHA256']
    for name,h in [
        ('独立検算.json',m['独立方向/金融/全表SHA256']),('独立停止の確認.json',m['独立停止SHA256']),
        ('金融集計の独立確認.json','87820885fd282e7302cba0e019a87b2ea6f8928e4ca7b865d03ce2aa85ceaf79'),
        ('原因診断の確認.json',m['原因診断確認SHA256']),('保存資料の再現確認.json',m['保存観測再現SHA256'])]:
        assert sha((FORMAL/'検査'/name).read_bytes())==h
    csv=json.loads((FORMAL/'検査/CSV全セルの独立再読.json').read_bytes());assert csv['全データセル比較数']==39685 and csv['数値比較数']==16949
    for item in csv['表別']:
        p=ROOT/m['CSV正本']/Path(item['CSV']['path']).name;assert sha(p.read_bytes())==item['CSV']['sha256']
    creator=json.loads((FORMAL/'検査/CSV作成の確認.json').read_bytes());assert creator['コードSHA256']==groups[0]['格納源'][0]['sha256']
    assert len(creator['プレビュー'])==3
    for name in creator['プレビュー']:assert (ROOT/m['CSV正本']/name).exists()
    aggregate=json.loads((FORMAL/'成果物/集計.json').read_bytes());primary=aggregate['集計']['all']['T0']['BBO']['3600']['125']
    assert [primary[k] for k in ('entries','forward','adverse','neither','censored','ifd_net5_profit','ifd_net5_loss','ifd_net5_sum')]==[752,319,306,74,53,4098280,4856875,-758595]
    assert primary['ifd_known']==735 and primary['ifd_unknown']==17
    assert cp['両既知ペア差円']==-302000 and cp['新規既知3件清算円']==-42231 and cp['全既知額差円']==-344231
    # ----------------------------------------
    indices=[ROOT/n for n in ('README.md','study/README.md','docs/README.md','docs/議論/README.md')];links=0
    for p in list(FORMAL.rglob('*.md'))+[ROOT/m['CSV正本']/'README.md']+indices:
        body=p.read_text('utf-8')
        if p in indices:
            assert '[142：' in body;body=next(x for x in body.split('\n\n') if '[142：' in x)
            assert '確定中' not in body
        for target in re.findall(r'\]\(([^)]+)\)',body):
            if target.startswith(('http:','https:','#')):continue
            assert (p.parent/target.strip('<>').split('#',1)[0]).resolve().exists(),(p,target);links+=1
    proof={'成功':True,'試行':142,'正式保存完了':True,'編集停止':True,'F0/F1原文/正式3含む4MD先退避':True,
        '元条件本文と57x9_513セル不変':True,'F0全17/F1全30源同体復元':True,'新モデル方向各一度gzip/旧大観測特徴共有':True,
        '独立全752方向/850origin/769query/833入口一致':True,'独立180条件4320統計セル/旧120/39685表セル一致':True,
        '独立IFDFraction/人工5/自然初回成功':True,'独立は見出しとschema一部受領後準備':True,'CSV39685セル16949数値再読/Root三画像視認通知':True,
        '保存観測から全180条件/三表JSONbytes同体再現':True,'変更148の両IFD既知差と新既知損失を分離':True,
        'B0/第2段とも悪化/全3既知でも悪化':True,'主未達で不採用/旧学習木の汎化成功でない':True,
        '新Raw/価格CSV/出生/金融観測/新CSV生成/旧141以前変更/追加2場読取':False,'4索引更新':True,'ローカルリンク':links,'重大不足':[],
        '主T0':primary,'F0_SHA256':m['F0_SHA256'],'F1_SHA256':m['F1_SHA256'],'独立SHA256':m['独立方向/金融/全表SHA256'],
        '原因SHA256':m['原因診断確認SHA256'],'再現SHA256':m['保存観測再現SHA256'],'保管索引SHA256':sha(mpath.read_bytes()),
        '追補ZIP_SHA256':m['後発資料']['ZIP_SHA256'],'コードSHA256':sha(Path(__file__).read_bytes())}
    p=FORMAL/'検査/正式保存の最終確認.json';assert not p.exists();p.write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'最終確認SHA256':sha(p.read_bytes()),'保管索引SHA256':sha(mpath.read_bytes()),'追補ZIP_SHA256':m['後発資料']['ZIP_SHA256'],'重大不足':[]},ensure_ascii=False))


if __name__=='__main__':main()
