"""固定T8の全成立適用を、非金融方向票と保存実正逆の評価へ分離する。"""
from pathlib import Path
from datetime import datetime, timezone
import argparse
import hashlib
import importlib.util
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
OWN = ROOT / 'work/142固定T8の拡張評価'
LOGIC = ROOT / 'work/142固定T8の全成立への方向票'
FORMAL = ROOT / 'study/00142_固定T8を全成立入口へ広げる'
MODEL = LOGIC / '固定条件.json'
CHOICES = OWN / '方向票/全752の方向.json'


def sha(path: Path) -> str:
    """
    機能: 保存ファイルの指紋を求める。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def module(path: Path, name: str) -> object:
    """
    機能: 主処理を呼ばず私有モジュールを読み込む。
    引数: path(Path)、name(str)はコードと内部名。
    返り値: objectはモジュール。
    """
    previous = list(sys.path)
    try:
        sys.path.insert(0, str(path.parent))
        spec = importlib.util.spec_from_file_location(name, path)
        value = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(value)
        return value
    finally:
        sys.path[:] = previous


# ----------------------------------------
def main() -> None:
    """
    機能: 固定式の再生成、金融前固定、保存実BBO正逆の集計を別段階で行う。
    引数: CLI --mode(str)は固定/方向/金融前/集計。
    返り値: None。対象752・旧81・主125/H60を結果後に変更しない。
    """
    parser = argparse.ArgumentParser(description='142の方向と金融を分離する')
    parser.add_argument('--mode', choices=('固定', '方向', '金融前', '集計'), required=True)
    args = parser.parse_args()
    helper = module(ROOT / 'work/133金融前を固定して実行する.py', '142の固定補助')
    io = module(LOGIC / 'io142.py', '142の非金融依存')
    f0, f1 = OWN / 'F0方向前.json', OWN / 'F1金融前.json'
    OWN.mkdir(parents=True, exist_ok=True)
    if args.mode == '固定':
        assert json.loads((LOGIC / '準備の確認.json').read_bytes())['成功']
        files = set(io.NONFINANCIAL) | set(io.local_sources()) | {Path(__file__).resolve(),
            ROOT / 'work/133金融前を固定して実行する.py', LOGIC / '準備の確認.json',
            ROOT / 'work/固定T8を全取得へ拡張できるかの非金融監査/確認の指紋.json'}
        for path, expected in io.NONFINANCIAL.items():
            assert sha(path) == expected, path
        for name in ('README.md', '条件.md', '設定と結果.md'):
            path = FORMAL / name
            assert path.is_file()
            files.add(path)
        helper.save(f0, {'成功': True, '試行': 142, '段階': '非金融方向再生成前F0',
            'UTC': datetime.now(timezone.utc).isoformat(),
            '主': 'T0・固定T8の段階別未知処置と全origin合意を追加671へ適用、旧81保護・全752保持',
            '非金融予備確認': '元式148flip/523keepを既に確認。新しい先着率・金額は未計算。',
            '追加2場未読': True, '本試行の再学習': False, '全期間既使用': True,
            'ファイル': {str(p): sha(p) for p in sorted(files)}})
        print(json.dumps({'F0_SHA256': sha(f0), '固定源数': len(files)}, ensure_ascii=False))
        return
    frozen = json.loads(f0.read_bytes()); helper.verify(frozen)
    if args.mode == '方向':
        command = [sys.executable, '-X', 'utf8', str(LOGIC / '方向票を作る.py'), '--f0', str(f0),
            '--f0-sha256', sha(f0), '--output-dir', str(CHOICES.parent), '--execute-after-f0']
    elif args.mode == '金融前':
        assert CHOICES.is_file()
        choices = json.loads(CHOICES.read_bytes())
        assert choices['success'] and choices['trial'] == 142 and len(choices['rows']) == 752
        assert choices['model_sha256'] == sha(MODEL) and choices['counts'] == {'flip':148, 'keep':604}
        declared = module(LOGIC / '集計する.py', '142の金融依存宣言')
        files = {Path(p) for p in frozen['ファイル']} | {f0, CHOICES, CHOICES.parent / '方向票の確認.json',
            ROOT / 'work/141金融集計を独立に確認する.py', ROOT / 'work/142金融集計を独立に確認する.py'}
        for path, expected in declared.SOURCES.items():
            assert sha(path) == expected, path
            files.add(path)
        inherited = module(declared.BASE, '142の共通算術依存')
        for path, expected in inherited.SOURCES.items():
            assert sha(path) == expected, path
            files.add(path)
        helper.save(f1, {'成功': True, '試行': 142, '段階': '保存正逆の金融再集計前F1',
            'UTC': datetime.now(timezone.utc).isoformat(), 'F0_SHA256': sha(f0),
            '方向SHA256': sha(CHOICES), '本試行の再学習': False, '新Raw走査': False,
            'ファイル': {str(p): sha(p) for p in sorted(files)}})
        print(json.dumps({'F1_SHA256': sha(f1), '固定源数': len(files)}, ensure_ascii=False))
        return
    else:
        finance = json.loads(f1.read_bytes()); helper.verify(finance)
        command = [sys.executable, '-X', 'utf8', str(LOGIC / '集計する.py'), '--f1', str(f1), '--f1-sha256', sha(f1),
            '--model', str(MODEL), '--model-sha256', sha(MODEL), '--choices', str(CHOICES), '--choices-sha256', sha(CHOICES),
            '--output-dir', str(OWN / '金融評価')]
    subprocess.run(command, cwd=ROOT, check=True)
    helper.verify(frozen)
    if args.mode == '集計': helper.verify(finance)
    helper.save(OWN / (args.mode + 'の完了.json'), {'成功': True, '試行': 142, '段階': args.mode,
        'F0_SHA256': sha(f0), '全固定源前後同体': True, '実行列': command})


if __name__ == '__main__':
    main()
