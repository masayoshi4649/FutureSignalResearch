"""142の固定式・全結合・方向選択を人工入力だけで確認する。"""
import copy
import importlib.util
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

from logic142 import (INPUT_SHA, QUERY_SHA, MANIFEST_SHA, KEYS, formula, choose, origin_query, stream, fixed_spec)
from io142 import sha, load, save, verify_freeze


def value(number):
    """
    機能: 未知nullを区別する人工特徴を作る。
    引数: number(float又はNone)。返り値: dict。
    """
    return {'known': number is not None, 'value': number}


def three(body, long, hist):
    """
    機能: native向き3特徴を作る。
    引数: body/long/hist(float又はNone)。返り値: dict。
    """
    return dict(zip(KEYS, map(value, (body, long, hist))))


def fixture(side=1):
    """
    機能: 752/81入口、769出生、850由来の人工入力を構築する。
    引数: side(int)は鏡像方向。返り値: tuple[dict,dict,dict]。
    """
    manifest = {'success': True, 'financial_labels_used': False, 'C0': [], 'P0': [],
                'frequency': {'P0': {'scenes': [{'session': f'人工/{i}'} for i in range(73)]}}}
    queries = {'success': True, 'trial': 138, 'manifest_sha256': MANIFEST_SHA, 'queries': [], 'relations': []}
    features = {'success': True, 'input_sha256': INPUT_SHA, 'queries_sha256': QUERY_SHA,
                'financial_labels_used': False, 'entry_prices_used': False,
                'source_scene_count': 73, 'query_count': 769, 'rows': []}
    count = 0
    patterns = ((.6, -1, -.2), (.6, 1, .2), (.75, 0, .1), (None, 0, .1), (.6, None, None), (.4, 0, .09999))
    for i in range(752):
        session = f'人工/{i%73}'
        entry = {'time': 20000+i*100, 'index': 10000+i*100, 'source_line': 10050+i*100,
                 'last': 1000, 'bid': 999, 'ask': 1001, 'quote_ok': True}
        candidate = {'id': '人工入口/'+str(i), 'session': session, 'contract': '人工限月',
                     'side': side, 'baseline': i < 81, 'entryQuote': entry, 'origins': []}
        for oi in range(2 if 81 <= i < 98 else 1):
            birth = {k: entry[k]-2-oi for k in ('time', 'index', 'source_line')}
            birth['last'] = entry['last']
            origin = {'source_file_sha': f'{count:064x}', 'source_locator': {'人工位置': count},
                      'side': side, 'family': '人工技術', 'birthQuote': birth, 'entryQuote': copy.deepcopy(entry)}
            candidate['origins'].append(origin)
            query = origin_query(origin, candidate)
            assert query['id'] not in {q['id'] for q in queries['queries']}
            queries['queries'].append(query)
            p = patterns[i % len(patterns)]
            vals = three(*p)
            foots, refs = {}, []
            for minute, age in ((5, 120), (30, 400)):
                at = {'time': birth['time']-1, 'index': birth['index']-1, 'source_line': birth['source_line']-1}
                end = birth['time']-age
                identity = f'人工公表/{count}/{minute}'
                foots['m'+str(minute)] = {'id': identity, 'end': end, 'available_at': end+60,
                                         'delivery_at': at['time'], 'delivered': at, 'price_known': True}
                refs.append({'id': identity, 'width_seconds': minute*60, 'end': end, 'delivered': at})
            features['rows'].append({'query': query, 'values': vals,
                                     'known_mask': {k: v['known'] for k, v in vals.items()}, 'feet': foots, 'refs': refs})
            count += 1
        manifest['P0'].append(candidate)
        if i < 81:
            manifest['C0'].append(copy.deepcopy(candidate))
    for model in ('C0', 'P0'):
        for index, candidate in enumerate(manifest[model]):
            for oi, origin in enumerate(candidate['origins']):
                query = origin_query(origin, candidate)
                queries['relations'].append({'entry_id': model+'/'+candidate['id'], 'query_id': query['id'],
                    'model': model, 'manifest_index': index, 'origin_index': oi, 'family': origin['family'],
                    'side': side, 'selected_side': side})
    assert count == 769 and len(queries['relations']) == 850
    return manifest, queries, features


class Cases(unittest.TestCase):
    """固定式の境界と全入口保持を検査します。"""

    def test_式の境界と段階別未知(self):
        """機能: 各境界・未知を検査。引数: self(Cases)。返り値: None。"""
        cases = ((.5, -1, -.2, 1), (.75, 0, .1, -1), (.49999, 0, .1, -1),
                 (.5, 1, .2, -1), (None, 0, .1, -1), (.5, None, None, -1),
                 (.5, 0, -.09999, -1), (None, None, None, 1), (.75, -.00001, .1, 1),
                 (.75, 0, .099999, 1))
        for side in (1, -1):
            for body, long, hist, relative in cases:
                values = three(body, long, hist)
                before = copy.deepcopy(values)
                result = formula(side, values)
                self.assertEqual(result['t8_side'], side*relative)
                self.assertEqual(values, before)
        self.assertEqual(formula(1, three(.6, -1, -.2))['b0_side'], -1)
        self.assertTrue(formula(1, three(.6, -1, -.2))['t8_patch_flip'])

    def test_全結合と固定81と非改変(self):
        """機能: 全体結合・保護・copyを検査。引数: self(Cases)。返り値: None。"""
        data = fixture(); before = copy.deepcopy(data)
        result = choose(*data)
        self.assertEqual([len(result[k]) for k in ('rows', 'entry_origins', 'sessions')], [752, 833, 73])
        self.assertEqual(result['join_proof']['relations'], 850)
        self.assertTrue(all(not r['flip'] for r in result['rows'] if r['baseline']))
        self.assertTrue(all(o['result'] is None and not o['formula_applied'] for r in result['rows'] if r['baseline'] for o in r['origins']))
        self.assertGreater(result['known_sensitivity_only']['主では反転_参考全3既知guardなら維持'], 0)
        result['rows'][100]['origins'][0]['values'][KEYS[0]]['value'] = 999
        self.assertEqual(data, before)

    def test_鏡像と全origin不一致保持(self):
        """機能: 鏡像とalias不一致での保持を検査。引数: self(Cases)。返り値: None。"""
        a = choose(*fixture(1)); b = choose(*fixture(-1))
        self.assertEqual([r['selected_side'] for r in a['rows']], [-r['selected_side'] for r in b['rows']])
        data = fixture()
        candidate = data[0]['P0'][81]
        qid = origin_query(candidate['origins'][1], candidate)['id']
        row = next(r for r in data[2]['rows'] if r['query']['id'] == qid)
        row['values'] = three(.4, 0, .09999)
        row['known_mask'] = {k: True for k in KEYS}
        result = choose(*data)['rows'][81]
        self.assertFalse(result['all_origins_agree'])
        self.assertEqual(result['selected_side'], result['native_side'])

    def test_因果と由来改変の拒否(self):
        """機能: 未来・unknown偽装・由来欠落を拒否。引数: self(Cases)。返り値: None。"""
        for kind in ('future', 'unknown_zero', 'missing_relation', 'wrong_native'):
            data = fixture()
            if kind == 'future': data[2]['rows'][0]['refs'][0]['delivered']['time'] += 100
            if kind == 'unknown_zero': data[2]['rows'][0]['values'][KEYS[0]] = {'known': False, 'value': 0}
            if kind == 'missing_relation': data[1]['relations'].pop()
            if kind == 'wrong_native': data[0]['P0'][100]['side'] *= -1
            with self.assertRaises(AssertionError): choose(*data)

    def test_実正逆の選択とLast分離(self):
        """機能: 方向票のstream選択だけを検査。引数: self(Cases)。返り値: None。"""
        case = {'id': 'P0/id', 'original_side': 1, 'original': {'value': 1}, 'reverse': {'value': 2},
                'chart_original': {'value': 3}, 'chart_reverse': {'value': 4}}
        record = {'model': 'P0', 'case': case}; choices = {'P0/id': {'selected_side': -1}}
        self.assertIs(stream(record, 'T0', 'BBO', choices), case['reverse'])
        self.assertIs(stream(record, 'T0', 'Last', choices), case['chart_reverse'])
        self.assertIs(stream(record, 'P0', 'BBO', choices), case['original'])
        record = {'model': 'C0', 'case': case}
        self.assertIs(stream(record, 'C0', 'Last', choices), case['chart_original'])

    def test_指紋とF0と上書拒否(self):
        """機能: 固定照合と未作成保存を検査。引数: self(Cases)。返り値: None。"""
        with tempfile.TemporaryDirectory() as folder:
            p = Path(folder)/'人工.json'; h = save(p, {'成功': True})
            self.assertEqual(load(p, h), {'成功': True})
            with self.assertRaises(FileExistsError): save(p, {})
            with self.assertRaises(AssertionError): load(p, '0'*64)
            f0 = Path(folder)/'F0.json'; fsha = save(f0, {'試行': 142, 'ファイル': {str(p.resolve()): h}})
            verify_freeze(f0, fsha, {p: h})
            p.write_text('{}', encoding='utf-8')
            with self.assertRaises(AssertionError): verify_freeze(f0, fsha, {p: h})

    def test_明示実行なしは入力前拒否(self):
        """機能: F0後の明示フラグなしでI/Oしないことを検査。引数: self(Cases)。返り値: None。"""
        spec = importlib.util.spec_from_file_location('人工142CLI', Path(__file__).with_name('方向票を作る.py'))
        cli = importlib.util.module_from_spec(spec); spec.loader.exec_module(cli)
        argv = ['方向票を作る.py', '--f0', '存在しない', '--f0-sha256', '0'*64, '--output-dir', '未作成']
        with patch.object(sys, 'argv', argv), patch.object(cli, 'verify_freeze', side_effect=RuntimeError('I/O禁止')):
            with self.assertRaises(AssertionError): cli.main()


if __name__ == '__main__':
    unittest.main(verbosity=2)
