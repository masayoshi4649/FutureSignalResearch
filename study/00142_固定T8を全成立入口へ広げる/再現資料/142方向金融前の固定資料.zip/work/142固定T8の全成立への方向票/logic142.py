"""142の固定B0→T8と全origin合意。I/O・金融・学習を含まない純部品。"""
import copy
import hashlib
import json
import math
from collections import Counter

INPUT_SHA = '6a6cd13dfd00c9669b522e3c3c8e06a4066766f6075786f64d8c0feeb45513ec'
QUERY_SHA = '81442c3ebaa3065213d0844417bb0462cfa3e5d0a05c4f44edfb3fb14191e75c'
MANIFEST_SHA = 'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35'
FEATURES_SHA = 'c2b9b8efeb65ba22b2dac3147fdefa3b513cb5cc61cd69249864065f2fcca6e4'
KEYS = ('m5_body_ratio_to_side', 'm30_ema21_delta_to_side', 'm5_hist_atr_to_side')


def fixed_spec() -> dict:
    """
    機能: 旧T8の式を新しい追加671領域へ適用する固定仕様を返す。
    引数: なし。返り値: dictは学習しないmodel相当の条件。
    """
    return {'success': True, 'trial': 142, 'learned': False, 'inherited_T8_learned': True,
            'learned_field_meaning': '142では再学習なし、元T8は125/126の既使用期で学習選定', 'main_policy': 'T0',
            'controls': ['P0', 'C0'], 'entries': 752, 'sessions': 73,
            'protected_baseline': 81, 'additional': 671, 'queries': 769, 'relations': 850,
            'features': list(KEYS), 'b0_flip': '既知0.5<=s*(C5-O5)/(H5-L5)<0.75ならB0=-s、他B0=s',
            't8_patch': 'B0側EMA21増分30分>=0かつB0側Hist5/ATR5>=0.1がともに既知ならT8=-B0、他T8=B0',
            'unknown_body': 'B0だけnative保持、他の既知条件によるT8反転は可',
            'unknown_patch': 'T8段階の追加反転なし、既にB0が反転済みでもB0を維持',
            'all_three_known_required': False,
            'all_origins': '全originを同じnative基準でB0からT8へ計算、最終方向一致なら採用、不一致ならnative保持',
            'baseline': '旧137A0の81取得とselected方向を再適用せず固定保護',
            'scope_change': '旧L0非E0の70件からFAR M0等を含む追加671件への新しい適用領域拡張',
            'entry_time_and_population': '138全752取得/73場と取得時計を保持、出生特徴だけを使用',
            'financial_selection': '同取得時計の保存実BBO原側/逆側。1-p推定なし',
            'new_order_geometry_rebuilt': False, 'all_period_previously_used': True,
            'input_sha256': INPUT_SHA, 'queries_sha256': QUERY_SHA,
            'manifest_sha256': MANIFEST_SHA, 'features_sha256': FEATURES_SHA}


def finite(value: object) -> bool:
    """
    機能: boolを数値へ混ぜず有限性を判定する。
    引数: value(object)。返り値: bool。
    """
    return type(value) in (int, float) and math.isfinite(value)


def number(item: dict) -> float | None:
    """
    機能: 未知nullと既知0を区別する。
    引数: item(dict)。返り値: float又はNone。
    """
    assert type(item['known']) is bool
    if not item['known']:
        assert item['value'] is None
        return None
    value = item['value']
    assert finite(value)
    return value


def stamp(quote: dict) -> tuple:
    """
    機能: 価格時計・採用順・原行を型付きで取り出す。
    引数: quote(dict)。返り値: tuple。
    """
    assert finite(quote['time']) and type(quote['index']) is int and quote['index'] >= 0
    assert type(quote['source_line']) is int and quote['source_line'] > 0
    return tuple(quote[k] for k in ('time', 'index', 'source_line'))


def formula(side: int, values: dict) -> dict:
    """
    機能: 元T8の段階別未知処置と境界を保って方向を計算する。
    引数: side(int)はnativeの±1、values(dict)は出生時3特徴。
    返り値: dictはB0/T8、knownmask、段階別判定とB0基準値。
    """
    assert type(side) is int and side in (-1, 1)
    body, long, hist = (number(values[k]) for k in KEYS)
    b0_flip = body is not None and .5 <= body < .75
    b0 = -side if b0_flip else side
    factor = b0 * side
    long_b0 = None if long is None else factor * long
    hist_b0 = None if hist is None else factor * hist
    ma_pass = long_b0 is not None and long_b0 >= 0
    hist_pass = hist_b0 is not None and hist_b0 >= .1
    t8_flip = ma_pass and hist_pass
    return {'native_side': side, 'b0_side': b0, 't8_side': -b0 if t8_flip else b0,
            'known_mask': {k: values[k]['known'] for k in KEYS},
            'all_three_known': all(v is not None for v in (body, long, hist)),
            'b0_flip': b0_flip, 't8_patch_flip': t8_flip,
            'ma30_nonnegative_to_B0': ma_pass, 'hist5_atr_ge_point1_to_B0': hist_pass,
            'values_to_B0': {'body5_ratio_to_native': body,
                             'ema21_delta30_to_B0': long_b0, 'hist5_atr_to_B0': hist_b0}}


def origin_query(origin: dict, candidate: dict) -> dict:
    """
    機能: 固定138のorigin由来hashから出生queryを再構築する。
    引数: origin/candidate(dict)。返り値: dictは同じ出生/方向の照会。
    """
    birth = origin['birthQuote']
    bs = stamp(birth)
    assert finite(birth['last']) and birth['last'] > 0
    assert type(origin['side']) is int and origin['side'] in (-1, 1)
    key = json.dumps([origin['source_file_sha'], origin['source_locator'], origin['side'], bs],
                     ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()
    return {'id': 'origin/'+hashlib.sha256(key).hexdigest()[:32], 'session': candidate['session'],
            'contract': candidate['contract'], 'side': origin['side'],
            'birthQuote': {k: birth[k] for k in ('time', 'index', 'source_line', 'last')}}


def validate_row(row: dict, query: dict) -> None:
    """
    機能: 保存特徴と元出生、known値、公表の因果順を検査する。
    引数: row/query(dict)。返り値: None。新たな指標・価格を算出しない。
    """
    assert row['query'] == query
    at = stamp(query['birthQuote'])
    for key in KEYS:
        number(row['values'][key])
        assert row['known_mask'][key] is row['values'][key]['known']
    for ref in row['refs']:
        assert ref['end'] <= at[0] and all(a <= b for a, b in zip(stamp(ref['delivered']), at))
    for minute in (5, 30):
        foot = row['feet']['m'+str(minute)]
        if foot is None:
            continue
        end = foot['end']
        assert end <= foot['available_at'] <= foot['delivery_at'] <= foot['delivered']['time'] <= at[0]
        assert all(a <= b for a, b in zip(stamp(foot['delivered']), at))
        assert at[0] < end+minute*60+60
        assert {'id': foot['id'], 'width_seconds': minute*60, 'end': end, 'delivered': foot['delivered']} in row['refs']
    for key, minute in ((KEYS[0], 5), (KEYS[1], 30), (KEYS[2], 5)):
        if row['values'][key]['known']:
            assert row['feet']['m'+str(minute)] is not None and row['feet']['m'+str(minute)]['price_known']


def choose(manifest: dict, queries: dict, features: dict) -> dict:
    """
    機能: 全833入口/850originを結合し、旧81保護・追加全origin合意を方向票へする。
    引数: manifest/queries/features(dict)は金融なしの固定3入力。
    返り値: dictは全752方向票と参照・known・結合証跡。代表出生を選ばない。
    """
    assert manifest['success'] and manifest['financial_labels_used'] is False
    assert queries['success'] and queries['trial'] == 138 and queries['manifest_sha256'] == MANIFEST_SHA
    assert features['success'] and features['input_sha256'] == INPUT_SHA and features['queries_sha256'] == QUERY_SHA
    assert features['financial_labels_used'] is False and features['entry_prices_used'] is False
    assert features['source_scene_count'] == 73 and features['query_count'] == 769
    qmap = {q['id']: q for q in queries['queries']}
    fmap = {r['query']['id']: r for r in features['rows']}
    assert len(qmap) == len(queries['queries']) == len(fmap) == len(features['rows']) == 769 and set(qmap) == set(fmap)
    for key, query in qmap.items():
        validate_row(fmap[key], query)
    rels = {(r['model'], r['manifest_index'], r['origin_index']): r for r in queries['relations']}
    assert len(rels) == len(queries['relations']) == 850
    assert [len(manifest[k]) for k in ('C0', 'P0')] == [81, 752]
    sessions = [r['session'] for r in manifest['frequency']['P0']['scenes']]
    assert len(sessions) == len(set(sessions)) == 73
    controls = {r['id']: r for r in manifest['C0']}
    assert len(controls) == 81 and sum(c['baseline'] is True for c in manifest['P0']) == 81
    used, seen_rel = set(), set()
    rows, entries = [], []
    reasons, sensitivity = Counter(), Counter()
    for model in ('C0', 'P0'):
        identities = set()
        for index, candidate in enumerate(manifest[model]):
            assert candidate['id'] not in identities and candidate['session'] in sessions
            identities.add(candidate['id'])
            side = candidate['side']
            assert type(side) is int and side in (-1, 1) and type(candidate['baseline']) is bool and candidate['origins']
            if model == 'C0' or candidate['baseline']:
                assert candidate['baseline'] is True and candidate['id'] in controls
                for key in ('session', 'contract', 'side', 'entryQuote'):
                    assert candidate[key] == controls[candidate['id']][key]
            votes, query_ids = [], []
            for oi, origin in enumerate(candidate['origins']):
                expected = origin_query(origin, candidate)
                qid = expected['id']
                assert qmap[qid] == expected
                rkey = (model, index, oi)
                assert rels[rkey] == {'entry_id': model+'/'+candidate['id'], 'query_id': qid, 'model': model,
                                     'manifest_index': index, 'origin_index': oi, 'family': origin['family'],
                                     'side': origin['side'], 'selected_side': side}
                assert all(a <= b for a, b in zip(stamp(origin['birthQuote']), stamp(candidate['entryQuote'])))
                assert all(origin['entryQuote'][k] == candidate['entryQuote'][k] for k in ('time', 'index', 'source_line', 'last', 'bid', 'ask', 'quote_ok'))
                if not candidate['baseline']:
                    assert origin['side'] == side
                f = fmap[qid]
                value = {k: copy.deepcopy(f['values'][k]) for k in KEYS}
                applied = not candidate['baseline']
                result = formula(side, value) if applied else None
                votes.append({'origin_index': oi, 'query_id': qid, 'family': origin['family'],
                              'source_file_sha': origin['source_file_sha'], 'source_locator': copy.deepcopy(origin['source_locator']),
                              'birthQuote': copy.deepcopy(qmap[qid]['birthQuote']), 'native_side': side,
                              'formula_applied': applied, 'values': value,
                              'known_mask': {k: value[k]['known'] for k in KEYS},
                              'refs': copy.deepcopy(f['refs']), 'feet': {k: copy.deepcopy(f['feet'][k]) for k in ('m5', 'm30')},
                              'result': result})
                used.add(qid); seen_rel.add(rkey); query_ids.append(qid)
            entries.append({'id': model+'/'+candidate['id'], 'session': candidate['session'], 'model': model, 'origin_query_ids': query_ids})
            if model == 'C0':
                continue
            all_known = all(all(v['known_mask'].values()) for v in votes)
            directions = {v['result']['t8_side'] for v in votes} if not candidate['baseline'] else {side}
            agreement = len(directions) == 1
            selected = next(iter(directions)) if agreement else side
            if candidate['baseline']:
                selected, reason = side, '固定81native保護・T8再適用なし'
            elif not agreement:
                reason = 'origin方向不一致・native維持'
            else:
                reason = '元T8の全origin方向一致・反転' if selected != side else '元T8の全origin方向一致・native維持'
            flip = selected != side
            action = 'flip' if flip else 'keep'
            reasons[reason] += 1
            if not candidate['baseline']:
                sensitivity['追加全3特徴既知'] += all_known
                sensitivity['追加に未知あり'] += not all_known
                sensitivity['参考_全3既知を足した反転数'] += flip and all_known
                sensitivity['主では反転_参考全3既知guardなら維持'] += flip and not all_known
            rows.append({'id': 'P0/'+candidate['id'], 'session': candidate['session'], 'native_side': side,
                         'selected_side': selected, 'baseline': candidate['baseline'], 'flip': flip,
                         'action': action, 'reason': reason, 'all_origins_known': all_known,
                         'all_origins_agree': agreement, 'origin_query_ids': query_ids,
                         'origin_count': len(query_ids), 'unique_query_count': len(set(query_ids)), 'origins': votes})
    assert used == set(qmap) and seen_rel == set(rels) and len(entries) == 833 and len(rows) == 752
    assert len({r['id'] for r in rows}) == 752 and set(r['session'] for r in rows) == set(sessions)
    assert all(r['selected_side'] == r['native_side'] for r in rows if r['baseline'])
    return {'success': True, 'trial': 142, 'sessions': sessions, 'rows': rows, 'entry_origins': entries,
            'counts': dict(Counter(r['action'] for r in rows)), 'reasons': dict(reasons), 'known_sensitivity_only': dict(sensitivity),
            'join_proof': {'entries': 833, 'P0': 752, 'C0': 81, 'relations': 850, 'unique_queries': 769,
                           'reused_query_relations': 81, 'all_relations_joined': True, 'all_queries_used': True},
            'all_752_kept': True, 'protected_81_kept': True, 'all_73_sessions': True, 'labels_read': False, 'learned': False,
            'inherited_T8_learned': True, 'learned_field_meaning': '142では再学習なし、元T8は125/126の既使用期で学習選定'}


def stream(record: dict, policy: str, axis: str, choices: dict) -> dict:
    """
    機能: 142方向票が指す同時点の実正逆streamを選ぶ。
    引数: record(dict)、policy/axis(str)、choices(dict)。返り値: dictは保存stream。
    """
    assert policy in ('T0', 'P0', 'C0') and axis in ('BBO', 'Last')
    assert record['model'] == ('C0' if policy == 'C0' else 'P0')
    native = record['case']['original_side']
    side = choices[record['case']['id']]['selected_side'] if policy == 'T0' else native
    return record['case'][('chart_' if axis == 'Last' else '')+('original' if side == native else 'reverse')]
