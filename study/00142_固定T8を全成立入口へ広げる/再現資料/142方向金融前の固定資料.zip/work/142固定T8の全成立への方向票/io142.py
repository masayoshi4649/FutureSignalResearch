"""142の明示入力とRoot固定証跡だけを読む。金融の暗黙読取はしない。"""
import hashlib
import importlib.util
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
MANIFEST = ROOT/'work/全成立poolの非金融manifest/manifest.json'
QUERIES = ROOT/'work/138全成立入口の評価/固定入力_版2/特徴照会.json'
FEATURES = ROOT/'work/138全成立入口の評価/全出生の当時特徴.json'
NONFINANCIAL = {MANIFEST: 'e7ba444fd66f9ca52e10e929eeb31d21076f97afa161de738dabca14a8ff8e35',
                QUERIES: '81442c3ebaa3065213d0844417bb0462cfa3e5d0a05c4f44edfb3fb14191e75c',
                FEATURES: 'c2b9b8efeb65ba22b2dac3147fdefa3b513cb5cc61cd69249864065f2fcca6e4'}


def sha(path: Path) -> str:
    """
    機能: ファイルのSHA256を求める。
    引数: path(Path)。返り値: str。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path: Path, expected: str) -> dict:
    """
    機能: 指定SHA確認後に明示JSONだけを読む。
    引数: path(Path)、expected(str)。返り値: dict。
    """
    assert len(expected) == 64 and all(c in '0123456789abcdef' for c in expected)
    body = path.read_bytes()
    assert hashlib.sha256(body).hexdigest() == expected
    return json.loads(body)


def save(path: Path, value: dict) -> str:
    """
    機能: 未作成先だけにUTF-8 JSONを保存する。
    引数: path(Path)、value(dict)。返り値: strは保存SHA。
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write('\n')
    return sha(path)


def module(path: Path, name: str) -> object:
    """
    機能: 指定コードを私有名でimportする。
    引数: path(Path)、name(str)。返り値: object。
    """
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def verify_freeze(path: Path, expected: str, required: dict) -> tuple[dict, dict]:
    """
    機能: Root142固定JSONに必要源が全て含まれ現在も同体か確認する。
    引数: path(Path)、expected(str)、required(dict[Path,str])。返り値: tupleは固定文書とpath表。
    """
    fixed = load(path, expected)
    assert fixed['試行'] == 142
    declared = {Path(p).resolve(): h for p, h in fixed['ファイル'].items()}
    for p, h in required.items():
        assert declared[p.resolve()] == h and sha(p) == h, p
    return fixed, declared


def local_sources() -> dict:
    """
    機能: 純部品/CLI/条件とRoot集計器をF0/F1の必要源へ列挙する。
    引数: なし。返り値: dict[Path,str]。準備proofは自己参照に含めない。
    """
    names = ('logic142.py', 'io142.py', '方向票を作る.py', '集計する.py', '人工検査.py', '条件.md', '固定条件.json')
    return {HERE/n: sha(HERE/n) for n in names}
