"""Root F0後だけ、既存出生特徴から固定T8を追加671へ適用する。"""
import argparse
import json
from pathlib import Path
from logic142 import choose, fixed_spec
from io142 import HERE, MANIFEST, QUERIES, FEATURES, NONFINANCIAL, sha, load, save, verify_freeze, local_sources


def main() -> None:
    """
    機能: F0にbindした既存769出生から全752方向票を生成する。
    引数: --f0/--f0-sha256/--output-dir/--execute-after-f0。
    返り値: None。学習・金融・原板・新しい出生を計算しない。
    """
    parser = argparse.ArgumentParser(description='142の固定T8方向票')
    parser.add_argument('--f0', type=Path, required=True)
    parser.add_argument('--f0-sha256', required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--execute-after-f0', action='store_true')
    args = parser.parse_args()
    assert args.execute_after_f0
    assert not any((args.output_dir/n).exists() for n in ('全752の方向.json', '方向票の確認.json'))
    checks = {**NONFINANCIAL, **local_sources()}
    verify_freeze(args.f0, args.f0_sha256, checks)
    model_path = HERE/'固定条件.json'
    model_sha = sha(model_path)
    assert load(model_path, model_sha) == fixed_spec()
    out = choose(load(MANIFEST, NONFINANCIAL[MANIFEST]), load(QUERIES, NONFINANCIAL[QUERIES]),
                 load(FEATURES, NONFINANCIAL[FEATURES]))
    out.update({'model_sha256': model_sha, 'features_sha256': NONFINANCIAL[FEATURES],
                'queries_sha256': NONFINANCIAL[QUERIES], 'manifest_sha256': NONFINANCIAL[MANIFEST],
                'F0_SHA256': args.f0_sha256,
                'sources': {str(p.resolve()): h for p, h in {**NONFINANCIAL, model_path: model_sha}.items()}})
    verify_freeze(args.f0, args.f0_sha256, checks)
    direction_sha = save(args.output_dir/'全752の方向.json', out)
    save(args.output_dir/'方向票の確認.json', {'成功': True, '試行': 142, '方向SHA256': direction_sha,
        'モデルSHA256': model_sha, '出生特徴SHA256': NONFINANCIAL[FEATURES], 'F0_SHA256': args.f0_sha256,
        '全件保持': True, '固定81保護': True, '全73場保持': True, '元T8段階別未知処置': True,
        '全3既知を主に追加': False, '結合': out['join_proof'], '方向件数': out['counts'],
        '理由件数': out['reasons'], '非金融既知感度': out['known_sensitivity_only'],
        '前後不変': True, '前後SHA256': {str(p.resolve()): h for p, h in checks.items()},
        '金融本文読取': False, '学習': False, '反転注文適格性再構築': False})
    print(json.dumps({'成功': True, '方向SHA256': direction_sha, '方向件数': out['counts'], '結合': out['join_proof']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
