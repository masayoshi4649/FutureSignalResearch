"""142方向票を保存実正逆へ割り当て、作者の集計関数を使わず180比較を確認する。"""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import json
import math

ROOT = Path(__file__).resolve().parent.parent


def sha(path: Path) -> str:
    """
    機能: 保存ファイルの指紋を計算する。
    引数: path(Path)は対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


# ----------------------------------------
def main() -> None:
    """
    機能: 新方向と旧原側/実逆側を独立結合し全比較の主要統計を再計算する。
    引数: CLI --folder(Path)は142実行先、--output(Path)は未作成の検算記録。
    返り値: None。金融の抽出関数・124/138/142作者算術はimportしない。
    """
    parser = argparse.ArgumentParser(description='142金融集計の独立確認')
    parser.add_argument('--folder', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args(); own = args.folder
    paths = {'f1': own/'F1金融前.json', 'choices': own/'方向票/全752の方向.json', 'summary': own/'金融評価/集計.json',
             'observed': ROOT/'work/138全成立入口の評価/固定取得の正逆観測.json',
             'fixed': ROOT/'work/138全成立入口の評価/固定入力_版2/固定取得入力.json',
             'arithmetic': ROOT/'work/141金融集計を独立に確認する.py'}
    fingerprints = {k: sha(p) for k,p in paths.items()}
    f1, choices, summary, observed, fixed = [json.loads(paths[k].read_bytes()) for k in ('f1','choices','summary','observed','fixed')]
    assert f1['試行'] == choices['trial'] == summary['試行'] == 142 and observed['trial'] == 133
    assert summary['F1_SHA256'] == fingerprints['f1'] and summary['方向SHA256'] == fingerprints['choices']
    assert all(f1['ファイル'][str(paths[k].resolve())] == fingerprints[k] for k in ('choices','observed','fixed','arithmetic'))
    selection = {r['id']: r for r in choices['rows']}; assert len(selection) == 752
    cases = [(s['session'], c) for s in observed['scenes'] for c in s['cases']]
    assert len(cases) == fixed['expected_entry_count'] == 833
    assert {c['id'] for _,c in cases if c['id'].startswith('P0/')} == set(selection)
    spec = importlib.util.spec_from_file_location('142独立の共通算術', paths['arithmetic'])
    arithmetic = importlib.util.module_from_spec(spec);spec.loader.exec_module(arithmetic)
    sessions = [s['session'] for s in observed['scenes']]; assert len(sessions) == 73 and sessions == choices['sessions']
    comparisons = 0; cells = 0
    for part, ids in (('all',sessions),('train',sessions[:48]),('validation',sessions[48:])):
        for policy in ('T0','P0','C0'):
            cohort = 'C0/' if policy == 'C0' else 'P0/'
            selected = []; flips = 0
            for sid, case in cases:
                if sid not in ids or not case['id'].startswith(cohort): continue
                reverse = policy == 'T0' and selection[case['id']]['selected_side'] != case['original_side']
                if policy == 'T0':
                    assert selection[case['id']]['native_side'] == case['original_side']
                    assert selection[case['id']]['selected_side'] in (-1,1)
                    assert not selection[case['id']]['baseline'] or not reverse
                flips += reverse
                view = {'original': case['reverse' if reverse else 'original'],
                        'chart_original': case['chart_reverse' if reverse else 'chart_original']}
                selected.append((sid, view))
            hours = sum((s['end']-300-s['start'])/3600 for s in fixed['scenes'] if s['session'] in ids)
            model = 'C0' if policy == 'C0' else 'P0'
            assert math.isclose(summary['頻度'][part][model]['全時間平均件数毎時'],len(selected)/hours,rel_tol=1e-12)
            assert summary['参加'][part][model]['取得数'] == len(selected)
            for axis in ('BBO','Last'):
                for horizon in (1800,3600):
                    for width in (25,50,100,125,200):
                        expected = arithmetic.calculate(selected,False,axis,horizon,width);expected['flips'] = flips
                        actual = summary['集計'][part][policy][axis][str(horizon)][str(width)]
                        assert set(expected) == set(actual)
                        for key,value in expected.items():
                            if isinstance(value,float): assert math.isclose(value,actual[key],rel_tol=1e-12,abs_tol=1e-9),(part,policy,axis,horizon,width,key)
                            else: assert value == actual[key],(part,policy,axis,horizon,width,key,value,actual[key])
                            cells += 1
                        comparisons += 1
    assert comparisons == 180 and all(sha(p) == fingerprints[k] for k,p in paths.items())
    out = {'成功': True,'試行':142,'比較数':comparisons,'統計セル数':cells,'新Raw走査':False,
           '作者算術import':False,'独立共通算術':'Rootの141金融独立確認calculateのみ',
           '入力':{str(p.resolve()): fingerprints[k] for k,p in paths.items()}}
    with args.output.open('x',encoding='utf-8',newline='\n') as f:json.dump(out,f,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps(out,ensure_ascii=False))


if __name__ == '__main__':
    main()
