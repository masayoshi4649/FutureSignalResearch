"""163の探索用NPZの全軸を、監査済みGo観測へ独立に対応付ける。"""
from pathlib import Path
from collections import Counter
import gzip
import hashlib
import json

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
ARRAYS=ROOT/'work/163任意幅の数値化/自然数値表'
RAW=ROOT/'work/163任意幅Raw索引'
NPZ_SHA='72f8a79bcfb56585ee9276632d82705e6467bd99db5f9c03648a2b343b7c0a9a'
META_SHA='5eb6ea0dbeed7918476952383bd1cbebdbb2c53fadfca83694cc5b5d7c9830c0'
MANIFEST_SHA='3e87f0c48dc03daa0dcb71475bfd84eaa461035b4986073e7d8bcbfae60e592d'


def sha(path: Path) -> str:
    """
    機能: 全物理bytesのSHA256を得る。
    引数: path(Path)は入力。
    返り値: strは指紋。
    """
    with path.open('rb') as source:return hashlib.file_digest(source,'sha256').hexdigest()


def read(path: Path) -> dict:
    """
    機能: 小型JSONを必要ならgzip全CRC読了して解析する。
    引数: path(Path)は入力。
    返り値: dictは解析値。
    """
    body=path.read_bytes()
    return json.loads(gzip.decompress(body) if body[:2]==b'\x1f\x8b' else body)


def main() -> None:
    """
    機能: case辞書順・実側・幅・時計の全配列値をGo原始値へ照合する。
    引数: なし。SHA固定の完成NPZ/metadata/Go観測だけを利用する。
    返り値: None。未知0とknown、SESSION成熟を含む照合票を保存する。
    """
    paths=[ARRAYS/'任意幅配列.npz',ARRAYS/'任意幅識別.json.gz',RAW/'自然観測/manifest.json']
    expected=(NPZ_SHA,META_SHA,MANIFEST_SHA)
    assert all(sha(p)==s for p,s in zip(paths,expected,strict=True))
    meta=read(paths[1]);manifest=read(paths[2])
    with np.load(paths[0],allow_pickle=False) as source:
        arrays={k:source[k].copy() for k in source.files}
    assert all(v.dtype.kind!='O' for v in arrays.values())
    assert arrays['label'].shape==(31642,2,12,4)
    assert np.array_equal(np.isfinite(arrays['points']),arrays['known'])
    assert np.array_equal(np.isfinite(arrays['known_at']),arrays['label']!=2)
    assert np.all(arrays['net0'][~arrays['known']]==0) and np.all(arrays['net5'][~arrays['known']]==0)
    assert np.array_equal(np.isfinite(arrays['exit_time']),arrays['known'])
    assert np.all(arrays['exit_index'][~arrays['known']]==-1) and np.all(arrays['exit_line'][~arrays['known']]==-1)
    assert meta['widths']==manifest['config']['widths']
    assert meta['horizon_ids']==[h['id'] for h in manifest['config']['horizons']]
    assert len(meta['case_ids'])==len(set(meta['case_ids']))==31642 and meta['case_ids']==sorted(meta['case_ids'])
    mapping={case:i for i,case in enumerate(meta['case_ids'])};counts=Counter();seen=set();proofs=[]
    index_manifest=read(RAW/'自然索引/manifest.json')
    dtype=np.dtype([('time','<f8'),('line','<i8'),('last','<f8'),('bid','<f8'),('ask','<f8'),('normal','<u8')])
    for scene_index,scene in enumerate(manifest['scenes']):
        path=RAW/'自然観測'/scene['file']['path'];assert sha(path)==scene['file']['sha256']
        observed=read(path);ix=index_manifest['scenes'][scene_index]
        index_path=RAW/'自然索引'/ix['index']['path'];assert sha(index_path)==ix['index']['sha256']
        body=gzip.decompress(index_path.read_bytes());records=np.frombuffer(body,dtype=dtype,offset=8)
        for case in observed['cases']:
            ci=mapping[case['id']];assert case['id'] not in seen;seen.add(case['id'])
            assert meta['sessions'][ci]==scene['session']==meta['session_order'][scene_index]
            assert arrays['session_index'][ci]==scene_index and arrays['original_side'][ci]==case['original_side']
            ei=case['entry_index'];assert arrays['entry_index'][ci]==ei
            assert arrays['entry_time'][ci]==records['time'][ei] and arrays['entry_line'][ci]==records['line'][ei]
            for si,side in enumerate(case['sides']):
                assert side['side']==(1,-1)[si] and arrays['entry_price'][ci,si]==side['entry_price']
                for hi,outcome in enumerate(side['outcomes']):
                    assert outcome['horizon_id']==meta['horizon_ids'][hi]
                    assert arrays['complete'][ci,si,hi]==outcome['complete']
                    assert meta['status_names'][int(arrays['status'][ci,si,hi])]==outcome['status']
                    assert arrays['deadline'][ci,si,hi]==outcome['deadline']
                    endpoint=outcome['endpoint_index']
                    if endpoint is None:
                        assert arrays['endpoint_index'][ci,si,hi]==-1 and np.isnan(arrays['endpoint_time'][ci,si,hi])
                    else:
                        assert arrays['endpoint_index'][ci,si,hi]==endpoint
                        assert arrays['endpoint_time'][ci,si,hi]==records['time'][endpoint]
                    for wi,touch in enumerate(outcome['touches']):
                        assert touch['width']==meta['widths'][wi]
                        at=(ci,si,wi,hi);known=touch['exit_index'] is not None
                        assert arrays['label'][at]==touch['label'] and arrays['direction'][at]==touch['direction']
                        assert arrays['known'][at]==known
                        if known:
                            exit_index=touch['exit_index']
                            assert arrays['points'][at]==touch['points']
                            assert arrays['net0'][at]==touch['net0'] and arrays['net5'][at]==touch['net5']
                            assert arrays['exit_index'][at]==exit_index
                            assert arrays['exit_time'][at]==records['time'][exit_index] and arrays['exit_line'][at]==records['line'][exit_index]
                        if outcome['known_at'] is None:
                            assert np.isnan(arrays['known_at'][at])
                        else:
                            assert arrays['known_at'][at]==outcome['known_at']
                        counts['case側幅時計セル']+=1
                    if outcome['kind']=='session':
                        counts['SESSION成熟検査']+=1
                        if outcome['complete']:
                            assert outcome['known_at']>=outcome['deadline']>arrays['endpoint_time'][ci,si,hi]
                        else:
                            assert outcome['known_at'] is None
            counts['case']+=1
        assert sha(path)==scene['file']['sha256'] and sha(index_path)==ix['index']['sha256']
        counts['scene']+=1;proofs.append({'session':scene['session'],'observations_sha256':scene['file']['sha256'],'index_sha256':ix['index']['sha256']})
    assert counts['case']==len(seen)==31642 and counts['scene']==73 and counts['case側幅時計セル']==31642*2*12*4
    complete=np.all(arrays['label']!=2,axis=1);known_at=np.max(arrays['known_at'],axis=1)
    assert np.array_equal(np.isfinite(known_at),complete)
    assert all(sha(p)==s for p,s in zip(paths,expected,strict=True))
    proof={'成功':True,'試行':163,'検査':dict(counts),'全NPZmemberのCRC読了':True,'pickle使用':False,
        '未知金融0はknownFalseと同時使用':True,'SESSIONのendpoint時計と成熟時計を区別':True,
        'SourceSHA256':sha(Path(__file__)),'inputs':{str(p.relative_to(ROOT)):s for p,s in zip(paths,expected,strict=True)},
        'scene_proofs':proofs}
    (HERE/'探索配列とGoの全セル同体.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'検査':dict(counts)},ensure_ascii=False))


if __name__=='__main__':
    main()
