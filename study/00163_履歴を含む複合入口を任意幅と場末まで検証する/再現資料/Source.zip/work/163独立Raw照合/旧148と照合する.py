"""163の数値Raw索引と観測を、元148の全case両実側へ別Pythonで照合する。"""
from pathlib import Path
from collections import Counter
import argparse
import gzip
import hashlib
import json
import math

import ijson
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
OLD=ROOT/'study/00148_全1分知得から入口品質の母集団を固定する/成果物/固定取得の正逆観測.json.gz'
OLD_SHA='bd809bdf24400628817afee702063504c65682e6748a60e0f32d7690b7363c61'
OLD_DECODED_SHA='d1b4cab8a258203f04b5c1d081f57d10ed2a0c58ce4cc160ef571d5fac0ceffc'
FIXED_SHA='99f10a996ca6e8b6c428061f1b48624bbc479ec84c500a9633818d47e4298e2a'
DTYPE=np.dtype([('time','<f8'),('line','<i8'),('last','<f8'),('bid','<f8'),('ask','<f8'),('normal','<u8')])


class DigestReader:
    """ijsonが読む解凍全bytesのSHAと件数を記録する。"""
    def __init__(self,source: object):
        """
        機能: 読み取り可能な解凍元と検査状態を結ぶ。
        引数: self(DigestReader)、source(object)はreadを持つバイナリ元。
        返り値: None。
        """
        self.source=source;self.digest=hashlib.sha256();self.size=0

    def read(self,size: int=-1) -> bytes:
        """
        機能: 全bytesを逐次計上して解析器へ渡す。
        引数: self(DigestReader)、size(int)は読取要求長。
        返り値: bytesは解凍内容。
        """
        data=self.source.read(size);self.digest.update(data);self.size+=len(data)
        return data


def sha(path: Path) -> str:
    """
    機能: ファイル全物理bytesのSHAを計算する。
    引数: path(Path)はファイル。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:
        return hashlib.file_digest(source,'sha256').hexdigest()


def stat(path: Path) -> tuple:
    """
    機能: ファイルの前後同体検査用の識別情報を得る。
    引数: path(Path)はファイル。
    返り値: tupleはdevice/inode/bytes/mtime_ns。
    """
    value=path.stat()
    return value.st_dev,value.st_ino,value.st_size,value.st_mtime_ns


def checked_json(path: Path,expected: str) -> tuple:
    """
    機能: 物理SHAとgzip全CRCを確認して小型JSONを読む。
    引数: path(Path)、expected(str)は入力と期待SHA。
    返り値: tupleは解析値と読取証拠。
    """
    before=stat(path);assert sha(path)==expected
    physical=path.read_bytes();body=gzip.decompress(physical) if physical[:2]==b'\x1f\x8b' else physical
    value=json.loads(body);assert stat(path)==before and sha(path)==expected
    return value,{'path':str(path),'sha256':expected,'bytes':len(physical),
        'decoded_sha256':hashlib.sha256(body).hexdigest(),'decoded_bytes':len(body),'gzip_full_crc':physical[:2]==b'\x1f\x8b'}


def checked_records(path: Path,expected: str,count: int) -> tuple:
    """
    機能: 索引magic・件数・数値・順序・BBO旗と全CRCを独立に検査する。
    引数: path(Path)、expected(str)、count(int)は索引参照。
    返り値: tupleは構造化配列と入力証拠。
    """
    before=stat(path);assert sha(path)==expected
    with gzip.open(path,'rb') as source:body=source.read()
    assert DTYPE.itemsize==48 and body[:8]==b'NQIDX163' and len(body)==8+count*48
    rows=np.frombuffer(body,dtype=DTYPE,offset=8)
    assert len(rows)==count and np.isfinite(rows['time']).all() and np.isfinite(rows['last']).all()
    assert np.isfinite(rows['bid']).all() and np.isfinite(rows['ask']).all() and (rows['last']>0).all()
    assert (rows['time'][1:]>=rows['time'][:-1]).all() and (rows['line'][1:]>rows['line'][:-1]).all()
    assert np.isin(rows['normal'],(0,1)).all()
    normal=(rows['bid']>0)&(rows['ask']>rows['bid'])
    assert np.array_equal(rows['normal']==1,normal)
    assert stat(path)==before and sha(path)==expected
    return rows,{'path':str(path),'sha256':expected,'rows':count,'decoded_bytes':len(body),'full_crc':True}


def quote_matches(quote: dict|None,index: int|None,rows: np.ndarray) -> int:
    """
    機能: 旧quoteの全価格と時計・原行を新索引へ照合する。
    引数: quote(dict又はNone)、index(int又はNone)、rows(np.ndarray)は索引。
    返り値: intは照合した実数値数。None同士は0。
    """
    if quote is None:
        assert index is None
        return 0
    assert index==quote['index'] and 0<=index<len(rows)
    row=rows[index]
    for old_key,new_key in (('time','time'),('source_line','line'),('last','last'),('bid','bid'),('ask','ask')):
        assert quote[old_key]==row[new_key],(old_key,index,quote[old_key],row[new_key])
    assert quote['quote_ok']==bool(row['normal'])
    return 6


def same_number(actual: float|None,wanted: float|None,description: tuple) -> None:
    """
    機能: 未知を0へ変換せず有限の金融値を比較する。
    引数: actual/wanted(float又はNone)、description(tuple)は不一致の所在。
    返り値: None。不一致はAssertionError。
    """
    if wanted is None:
        assert actual is None,description
    else:
        assert actual is not None and math.isfinite(actual) and math.isclose(actual,wanted,rel_tol=1e-13,abs_tol=1e-8),description


# ----------------------------------------
def main() -> None:
    """
    機能: 旧148全31642case両実側と163全新幅の金融原始値を照合する。
    引数: CLI index_dir/evaluation_dir(Path)、index_sha256/evaluation_sha256(str)、output(Path)。
    返り値: None。元観測を全CRC/SHA読了後に成功票を保存する。
    """
    parser=argparse.ArgumentParser()
    for name in ('index-dir','evaluation-dir','output'):parser.add_argument('--'+name,type=Path,required=True)
    for name in ('index-sha256','evaluation-sha256'):parser.add_argument('--'+name,required=True)
    args=parser.parse_args();assert not args.output.exists()
    index,index_proof=checked_json(args.index_dir/'manifest.json',args.index_sha256)
    evaluation,evaluation_proof=checked_json(args.evaluation_dir/'manifest.json',args.evaluation_sha256)
    assert index['success'] and index['version']==163 and index['source_entry_count']==31642
    assert evaluation['success'] and evaluation['trial']==163 and evaluation['source_entry_count']==31642
    assert index['input_sha256']==evaluation['input_sha256']==FIXED_SHA
    assert evaluation['index_manifest_sha256']==args.index_sha256 and evaluation['new_entry_selection'] is False
    assert len(index['scenes'])==len(evaluation['scenes'])==73
    config=evaluation['config'];assert config['point_yen']==100 and config['round_trip_fee']==77 and config['extra_round_trip_slippage']==1000
    assert {125,200}<={float(w) for w in config['widths']}
    counters=Counter();proofs=[];seen=set();before=stat(OLD);assert sha(OLD)==OLD_SHA
    with gzip.open(OLD,'rb') as stream:
        hashed=DigestReader(stream)
        for scene_index,old_scene in enumerate(ijson.items(hashed,'scenes.item',use_float=True)):
            assert scene_index<73
            ix=index['scenes'][scene_index];ev=evaluation['scenes'][scene_index]
            assert old_scene['success'] and old_scene['session']==ix['session']==ev['session']
            assert ix['success'] and ev['success'] and ix['all_entries_matched']
            assert old_scene['actual_sha256']==ix['actual_raw_sha256']==ix['raw']['sha256']
            assert old_scene['quality']==old_scene['expected_quality']==ix['quality']
            rows,index_row_proof=checked_records(args.index_dir/ix['index']['path'],ix['index']['sha256'],ix['rows'])
            new_scene,new_proof=checked_json(args.evaluation_dir/ev['file']['path'],ev['file']['sha256'])
            assert new_scene['success'] and new_scene['session']==old_scene['session']
            new_cases={c['id']:c for c in new_scene['cases']}
            assert len(new_cases)==len(new_scene['cases'])==len(old_scene['cases'])
            for old in old_scene['cases']:
                identifier=old['id'];assert identifier not in seen;seen.add(identifier)
                actual=new_cases[identifier];native=old['original_side']
                assert actual['original_side']==native
                entry=old['original']['entry'];entry_index=actual['entry_index']
                counters['旧quote全数値']+=quote_matches(entry,entry_index,rows)
                sides={s['side']:s for s in actual['sides']};assert set(sides)=={1,-1}
                for side in (1,-1):
                    new_side=sides[side];old_side=old['original' if side==native else 'reverse']
                    price=entry['ask' if side==1 else 'bid']
                    assert old_side['birth']['side']==side and old_side['entry']==entry
                    assert old_side['entry_price']==new_side['entry_price']==price
                    for new_outcome in new_side['outcomes']:
                        endpoint_index=new_outcome['endpoint_index']
                        if endpoint_index is not None:
                            assert rows['normal'][endpoint_index]==1 and endpoint_index>entry_index
                        # 新全幅も、保存した実BBOと費用から金融を独立再計算する。
                        for touch in new_outcome['touches']:
                            ti=touch['touch_index'];ei=touch['exit_index'];width=touch['width']
                            assert touch['label']==(touch['direction'] if new_outcome['complete'] else 2)
                            assert touch['direction'] in (-1,0,1) and (ti is None)==(touch['direction']==0)
                            if ti is not None:
                                assert entry_index<ti<len(rows) and rows['normal'][ti]==1
                                assert rows['time'][ti]<=new_outcome['deadline'] and rows['time'][ti]<old_scene['execution_end']
                                movement=side*(float(rows['bid' if side==1 else 'ask'][ti])-price)
                                assert movement>=width if touch['direction']==1 else movement<=-width
                            expected_exit=ti if ti is not None else endpoint_index if new_outcome['complete'] else None
                            assert ei==expected_exit
                            points=side*(float(rows['bid' if side==1 else 'ask'][ei])-price) if ei is not None else None
                            same_number(touch['points'],points,(identifier,side,'points'))
                            same_number(touch['net0'],points*100-77 if points is not None else None,(identifier,side,'net0'))
                            same_number(touch['net5'],points*100-1077 if points is not None else None,(identifier,side,'net5'))
                            counters['新全幅IFD原始値']+=1
                        if new_outcome['kind']!='strict' or new_outcome['seconds'] not in (1800,3600):continue
                        seconds=new_outcome['seconds']
                        old_outcome=next(o for o in old_side['outcomes'] if o['seconds']==seconds)
                        assert new_outcome['deadline']==old_outcome['deadline']==entry['time']+seconds
                        assert new_outcome['status']==old_outcome['status']
                        assert new_outcome['complete']==(old_outcome['status']=='complete')
                        counters['旧quote全数値']+=quote_matches(old_outcome['endpoint'],endpoint_index,rows)
                        assert new_outcome['known_at']==(old_outcome['endpoint']['time'] if old_outcome['endpoint'] is not None else None)
                        for width in (125,200):
                            old_touch=next(t for t in old_outcome['touches'] if t['width']==width)
                            new_touch=next(t for t in new_outcome['touches'] if t['width']==width)
                            assert new_touch['direction']==old_touch['direction']
                            counters['旧quote全数値']+=quote_matches(old_touch['quote'],new_touch['touch_index'],rows)
                            counters['旧幅先着IFD同体']+=1
                        counters['旧期限状態同体']+=1
            counters['場']+=1;counters['case']+=len(new_cases)
            proofs.append({'session':old_scene['session'],'index':index_row_proof,'evaluation':new_proof})
            print(json.dumps({'独立照合場':scene_index+1,'case累計':counters['case']},ensure_ascii=False),flush=True)
        assert hashed.read()==b''
        decoded=hashed.digest.hexdigest();decoded_bytes=hashed.size
    assert counters['場']==73 and counters['case']==len(seen)==31642
    assert counters['旧幅先着IFD同体']==31642*2*2*2 and counters['旧期限状態同体']==31642*2*2
    assert decoded==OLD_DECODED_SHA and stat(OLD)==before and sha(OLD)==OLD_SHA
    assert sha(args.index_dir/'manifest.json')==args.index_sha256 and sha(args.evaluation_dir/'manifest.json')==args.evaluation_sha256
    result={'成功':True,'試行':163,'独立Python':'ijson '+ijson.__version__,'新採否変更':False,
        'SourceSHA256':sha(Path(__file__)),'比較':dict(counters),'元148':{'sha256':OLD_SHA,'decoded_sha256':decoded,'decoded_bytes':decoded_bytes,'full_crc':True},
        'index_manifest':index_proof,'evaluation_manifest':evaluation_proof,'scene_proofs':proofs,
        '範囲':'旧125/200×H30/H60全case両実側の先着/原行/期限同体。全新幅は実BBOと費用の金融原始値検算。新幅の最初到達は独立人工線形参照で別確認。'}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'比較':dict(counters)},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
