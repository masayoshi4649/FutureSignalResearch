"""任意幅とSESSIONの最初到達を、別Pythonの逐次参照へ照合する。"""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
import random
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
WIDTHS=[25,125,150,175.5,200,250,300,400,500,750,1000,5000]
HORIZONS=[{'id':'H1','kind':'strict','seconds':60},{'id':'H30','kind':'strict','seconds':1800},
    {'id':'H60','kind':'strict','seconds':3600},{'id':'H120','kind':'strict','seconds':7200},
    {'id':'SESSION','kind':'session','seconds':0}]


def sha(path: Path) -> str:
    """
    機能: Source又は人工binaryの全物理SHAを得る。
    引数: path(Path)は入力。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def record(time: float, bid: float, spread: float=10, normal: bool=True, line: int=1) -> dict:
    """
    機能: 価格時計と実側価格を持つ人工原行を作る。
    引数: time/bid/spread(float)、normal(bool)、line(int)は時計・値・正常旗・物理行。
    返り値: dictは停止GoRecordへJSONで渡せる人工値。
    """
    return {'Time':time,'SourceLine':line,'Last':bid+spread/2,'Bid':bid,'Ask':bid+spread if normal else bid,'Flags':int(normal)}


def config() -> dict:
    """
    機能: 幅・期限と既存費用の人工条件を返す。
    引数: なし。
    返り値: dictは異なる幅を混ぜるテスト設定。
    """
    return {'widths':WIDTHS,'horizons':HORIZONS,'session_exit':'last_normal_pre_end_fresh30_require_boundary',
        'maximum_gap_seconds':300,'endpoint_grace_seconds':30,'point_yen':100,'round_trip_fee':77,'extra_round_trip_slippage':1000}


def reference(rows: list,entry: int,end: float,horizon: dict,side: int) -> dict:
    """
    機能: 木索引や作者関数を使わず原行を一行ずつ読み、先着と期限を確定する。
    引数: rows(list[dict])、entry(int)、end(float)、horizon(dict)、side(int±1)は人工契約。
    返り値: dictは全幅の逐次参照結果。境界原行の価格は清算に使わない。
    """
    start=rows[entry];price=start['Ask' if side==1 else 'Bid']
    session=horizon['kind']=='session';deadline=end if session else start['Time']+horizon['seconds']
    status='eof_censored';complete=False;endpoint=None;known_at=None
    touches=[None for _ in WIDTHS];previous=start['Time'];last_normal=start['Time'];last_normal_index=entry
    for at in range(entry+1,len(rows)):
        row=rows[at];now=row['Time']
        # ----------------------------------------
        # phaseが同原行のgapより優先。SESSIONは直前正常BBOの鮮度を別に確認する。
        if now>=end:
            status='phase_censored'
            if session and last_normal_index>entry and end-last_normal<=30:
                complete=True;status='complete';endpoint=last_normal_index;known_at=now
            break
        if now-previous>300 and previous<deadline:
            status='gap_censored';break
        if now-last_normal>300 and last_normal<deadline:
            status='bbo_gap_censored';break
        if not session and now>deadline+30:
            status='endpoint_missing';break
        if row['Flags']==1:
            if now<=deadline:
                points=side*(row['Bid' if side==1 else 'Ask']-price)
                for wi,width in enumerate(WIDTHS):
                    if touches[wi] is None and (points>=width or points<=-width):touches[wi]=at
            last_normal=now;last_normal_index=at
            if not session and now>=deadline:
                complete=True;status='complete';endpoint=at;known_at=now;break
        previous=now
    result={'deadline':deadline,'status':status,'complete':complete,'known_at':known_at,'endpoint_index':endpoint,'touches':[]}
    for width,ti in zip(WIDTHS,touches,strict=True):
        direction=0
        if ti is not None:
            movement=side*(rows[ti]['Bid' if side==1 else 'Ask']-price)
            direction=1 if movement>0 else -1
        exit_index=ti if ti is not None else endpoint if complete else None
        points=side*(rows[exit_index]['Bid' if side==1 else 'Ask']-price) if exit_index is not None else None
        result['touches'].append({'width':width,'direction':direction,'label':direction if complete else 2,
            'touch_index':ti,'exit_index':exit_index,'points':points,'net0':points*100-77 if points is not None else None,
            'net5':points*100-1077 if points is not None else None})
    return result


def check_value(actual: object,wanted: object,where: tuple) -> None:
    """
    機能: None・文字列・真偽・整数を保持し、有限実数だけ許容誤差で照合する。
    引数: actual/wanted(object)は比較値、where(tuple)は所在。
    返り値: None。不一致はAssertionError。
    """
    if isinstance(wanted,float):
        assert type(actual) in (int,float) and math.isclose(actual,wanted,rel_tol=1e-13,abs_tol=1e-8),where
    else:
        assert actual==wanted,where


# ----------------------------------------
def main() -> None:
    """
    機能: 停止GoSourceの隔離bridgeを人工だけで動かし、線形参照へ全値比較する。
    引数: なし。元の自然Sourceと原板は変更も再実行もしない。
    返り値: None。新幅・SESSION・境界・gap・同秒の独立人工票を保存する。
    """
    source_refs=json.loads((HERE/'bridge元Source指紋.json').read_text(encoding='utf-8'))
    for name,expected in source_refs.items():
        assert sha(ROOT/'work/163任意幅Raw索引'/name)==sha(HERE/'Go接続'/name)==expected
    # ----------------------------------------
    # 手製境界には同秒touch、厳密期限等号、phase等号、鮮度30/31、境界なしを含める。
    handmade=[
        ([record(0,10000),record(0,10210),record(60,10210),record(120,10300)],0,120),
        ([record(0,10000),record(60,10135),record(90,10150)],0,90),
        ([record(0,10000),record(60,10135),record(61,10140)],0,60),
        ([record(0,10000),record(280,10010),record(300,10100)],0,300),
        ([record(0,10000),record(270,10010),record(1000,9999)],0,300),
        ([record(0,10000),record(269,10010),record(300,9999)],0,300),
        ([record(0,10000),record(290,10010)],0,300),
        ([record(0,10000),record(60,10135),record(361,10200)],0,400),
        ([record(0,10000),record(100,10010,normal=False),record(250,10010,normal=False),record(301,10200)],0,400),
        ([record(0,10000),record(60,10010,normal=False),record(90,10135)],0,400),
        ([record(0,10000),record(60,10010,normal=False),record(91,10135)],0,400),
    ]
    cases=[]
    for rows,entry,end in handmade:
        for i,row in enumerate(rows):row['SourceLine']=i*3+1
        cases.append({'rows':rows,'entry':entry,'end':end,'config':config()})
    rng=random.Random(163041)
    for sample in range(120):
        rows=[];now=0;bid=10000
        for i in range(200):
            if i:
                now+=rng.choice([0,1,10,30,60,90])
                if sample%3==0 and rng.random()<.03:now+=301
            bid+=rng.randrange(-60,61)*5
            rows.append(record(now,bid,rng.choice([5,10,15]),rng.random()>.12,i*2+1))
        end=rows[rng.randrange(120,200)]['Time']
        for entry in (0,5,19):
            if rows[entry]['Flags']==1 and rows[entry]['Time']<end:
                cases.append({'rows':rows,'entry':entry,'end':end,'config':config()})
    process=subprocess.run([str(HERE/'Go接続/人工接続.exe')],input=json.dumps(cases).encode('utf-8'),capture_output=True,check=True)
    outputs=json.loads(process.stdout);assert len(outputs)==len(cases)
    count=0;statuses=Counter();labels=Counter();known=0
    for sample,(case,result) in enumerate(zip(cases,outputs,strict=True)):
        for side,actual in zip((1,-1),result['sides'],strict=True):
            assert actual['side']==side
            for hi,horizon in enumerate(HORIZONS):
                expected=reference(case['rows'],case['entry'],case['end'],horizon,side)
                got=actual['outcomes'][hi]
                for key in ('deadline','status','complete','known_at','endpoint_index'):
                    check_value(got[key],expected[key],(sample,side,horizon['id'],key))
                statuses[(horizon['kind'],got['status'])]+=1
                assert len(got['touches'])==len(WIDTHS)
                for wi,(g,w) in enumerate(zip(got['touches'],expected['touches'],strict=True)):
                    for key,value in w.items():check_value(g[key],value,(sample,side,horizon['id'],wi,key))
                    count+=1;labels[g['label']]+=1;known+=g['exit_index'] is not None
    for name,expected in source_refs.items():
        assert sha(ROOT/'work/163任意幅Raw索引'/name)==expected
    proof={'成功':True,'試行':163,'自然Raw再実行':False,'独立参照':'Pythonの原行逐次scan。木探索/旧kernelを参照実装へ流用しない。',
        '人工case':len(cases),'手製境界case':len(handmade),'全幅期限実側比較':count,'幅':WIDTHS,'期限':HORIZONS,
        '状態':{kind+'/'+status:value for (kind,status),value in statuses.items()},'label':dict(labels),'金融既知':known,
        '原Source':source_refs,'参照SourceSHA256':sha(Path(__file__)),'bridgeSourceSHA256':sha(HERE/'bridge_main.go.txt'),
        'bridgeBinarySHA256':sha(HERE/'Go接続/人工接続.exe'),'人工入力SHA256':hashlib.sha256(json.dumps(cases,separators=(',',':')).encode()).hexdigest()}
    (HERE/'線形人工の同体.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
