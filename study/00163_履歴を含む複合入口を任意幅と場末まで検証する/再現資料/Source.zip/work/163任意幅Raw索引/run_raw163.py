"""Root固定後に数値索引と12幅4時計の純観測を連続生成する。"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import hashlib
import json
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
FIXED=ROOT/'inputs/00148_全1分入口母集団/固定取得入力.json.gz'
FIXED_SHA='99f10a996ca6e8b6c428061f1b48624bbc479ec84c500a9633818d47e4298e2a'


def sha(path: Path) -> str:
    """
    機能: ファイル物理SHA256を固定長ずつ計算する。
    引数: path(Path)は対象。
    返り値: strは小文字16進SHA256。
    """
    with path.open('rb') as source:
        return hashlib.file_digest(source,'sha256').hexdigest()


def save(path: Path,value: object) -> None:
    """
    機能: UTF-8の新規JSONを上書きせず保存する。
    引数: path(Path)、value(object)は保存先と記録。
    返り値: None。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8',newline='\n') as target:
        json.dump(value,target,ensure_ascii=False,indent=2,allow_nan=False);target.write('\n')


def main() -> None:
    """
    機能: Go停止SourceとbookをF0へ束縛し全73場の索引と任意幅観測を生成する。
    引数: CLI book/config(Path)、book-sha256/config-sha256(str)、workers(int)は固定条件と並列数。
    返り値: None。新規選択・学習を行わず純観測manifestを確定する。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('--book',type=Path,required=True);parser.add_argument('--book-sha256',required=True)
    parser.add_argument('--config',type=Path,required=True);parser.add_argument('--config-sha256',required=True)
    parser.add_argument('--workers',type=int,default=4)
    args=parser.parse_args();assert sha(args.book)==args.book_sha256 and sha(args.config)==args.config_sha256
    book=json.loads(args.book.read_text(encoding='utf-8'));assert book.get('trial',book.get('試行'))==163
    stop_path=HERE/'Raw部品の停止.json';stop=json.loads(stop_path.read_text(encoding='utf-8'))
    assert stop['成功'] and stop['自然Raw未実行']
    assert all(sha(HERE/name)==digest for name,digest in stop['Source'].items())
    executable=HERE/stop['binary']['path'];assert sha(executable)==stop['binary']['sha256']
    assert sha(FIXED)==FIXED_SHA and args.config_sha256==stop['Source']['観測条件の雛形.json']
    f0={'成功':True,'試行':163,'時計':datetime.now(timezone.utc).isoformat(),'条件SHA256':args.book_sha256,
        '観測条件SHA256':args.config_sha256,'Go停止票SHA256':sha(stop_path),'Source':stop['Source'],
        'binary':stop['binary'],'runnerSHA256':sha(Path(__file__)),'固定入力SHA256':FIXED_SHA,
        '自然Raw前':True,'新規採否なし':True,'未見2場なし':True}
    save(args.book.parent/'検査/F0_任意幅観測前.json',f0)
    index=HERE/'自然索引';observations=HERE/'自然観測';assert not index.exists() and not observations.exists()
    commands=[['--mode','index','--input',str(FIXED),'--sha256',FIXED_SHA,'--output-dir',str(index),'--workers',str(args.workers)]]
    for command in commands:
        print(json.dumps({'開始':command},ensure_ascii=False),flush=True)
        subprocess.run([str(executable),*command],cwd=ROOT,check=True)
    index_sha=sha(index/'manifest.json')
    command=['--mode','evaluate','--input',str(FIXED),'--sha256',FIXED_SHA,'--index-dir',str(index),
        '--index-sha256',index_sha,'--config',str(args.config),'--config-sha256',args.config_sha256,
        '--output-dir',str(observations),'--workers',str(args.workers)]
    print(json.dumps({'開始':command},ensure_ascii=False),flush=True)
    subprocess.run([str(executable),*command],cwd=ROOT,check=True)
    assert sha(args.book)==args.book_sha256 and sha(args.config)==args.config_sha256
    assert all(sha(HERE/name)==digest for name,digest in stop['Source'].items()) and sha(executable)==stop['binary']['sha256']
    observation_sha=sha(observations/'manifest.json')
    save(HERE/'自然観測完了.json',{'成功':True,'試行':163,'条件SHA256':args.book_sha256,
        '観測条件SHA256':args.config_sha256,'索引manifestSHA256':index_sha,'観測manifestSHA256':observation_sha,
        '全Source前後同体':True,'F0_SHA256':sha(args.book.parent/'検査/F0_任意幅観測前.json'),
        '全73場':True,'全31642case':True,'新規採否なし':True})
    print(json.dumps({'自然観測完了':True,'索引manifestSHA256':index_sha,'観測manifestSHA256':observation_sha},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
