package main

import (
	"bufio"
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"math"
	"os"
	"path/filepath"
	"regexp"
	"sync"
)

const indexMagic = "NQIDX163"
const recordBytes = 48

type FixedEntry struct {
	ID    string `json:"id"`
	Side  int    `json:"side"`
	Entry Quote  `json:"entry"`
}

type FixedScene struct {
	Session          string       `json:"session"`
	Contract         string       `json:"contract"`
	Start            float64      `json:"start"`
	End              float64      `json:"end"`
	ForceClose       float64      `json:"force_close"`
	Raw              FileRef      `json:"raw"`
	ExpectedAccepted int64        `json:"expected_accepted"`
	ExpectedQuality  *Counts      `json:"expected_quality"`
	Entries          []FixedEntry `json:"entries"`
}

type FixedInput struct {
	Scenes             []FixedScene `json:"scenes"`
	ExpectedEntryCount int          `json:"expected_entry_count"`
}

type Record struct {
	Time       float64
	SourceLine int64
	Last       float64
	Bid        float64
	Ask        float64
	Flags      uint64
}

type IndexScene struct {
	Session           string   `json:"session"`
	Contract          string   `json:"contract"`
	Rows              int64    `json:"rows"`
	EntryCount        int      `json:"entry_count"`
	AllEntriesMatched bool     `json:"all_entries_matched"`
	Raw               FileRef  `json:"raw"`
	ActualRawSHA256   string   `json:"actual_raw_sha256"`
	Before            FileStat `json:"stat_before"`
	After             FileStat `json:"stat_after"`
	Quality           Counts   `json:"quality"`
	Index             FileRef  `json:"index"`
	IndexBytes        int64    `json:"index_bytes"`
	Success           bool     `json:"success"`
	Error             string   `json:"error,omitempty"`
}

type Manifest struct {
	Version            int          `json:"version"`
	Success            bool         `json:"success"`
	InputSHA256        string       `json:"input_sha256"`
	InputDecodedSHA256 string       `json:"input_decoded_sha256"`
	SourceEntryCount   int          `json:"source_entry_count"`
	Scenes             []IndexScene `json:"scenes"`
	RowFormat          string       `json:"row_format"`
	RawPassesPerScene  int          `json:"raw_passes_per_scene"`
}

// hashFile は圧縮又は通常ファイルの全物理bytesをSHA256へ流します。
//
// 機能: 入力同体と生成索引を指紋化します。
// 引数: path(string)はファイル名。
// 返り値: string/errorは小文字SHA256又は読取失敗です。
func hashFile(path string) (string, error) {
	f, e := os.Open(path)
	if e != nil {
		return "", e
	}
	defer f.Close()
	h := sha256.New()
	if _, e = io.Copy(h, f); e != nil {
		return "", e
	}
	return hex.EncodeToString(h.Sum(nil)), nil
}

// readFixed はSHA固定した取得入力をgzip判別して読みます。
//
// 機能: Raw本文を開く前に全73場と旧固定取得の範囲を確認します。
// 引数: path/expected(string)は入力と物理SHA。
// 返り値: FixedInput/string/errorは固定表・解凍SHA・失敗です。
func readFixed(path, expected string) (FixedInput, string, error) {
	var result FixedInput
	body, e := os.ReadFile(path)
	if e != nil {
		return result, "", e
	}
	digest := sha256.Sum256(body)
	if hex.EncodeToString(digest[:]) != expected {
		return result, "", fmt.Errorf("入力物理SHA差")
	}
	reader, _, e := rawStream133(bytes.NewReader(body))
	if e != nil {
		return result, "", e
	}
	defer reader.Close()
	decoded, e := io.ReadAll(reader)
	if e != nil {
		return result, "", e
	}
	if e = json.Unmarshal(decoded, &result); e != nil {
		return result, "", e
	}
	if len(result.Scenes) != 73 || result.ExpectedEntryCount != 31642 {
		return result, "", fmt.Errorf("全73場/31642case差")
	}
	pattern := regexp.MustCompile(`^2026-\d{2}-\d{2}_(Day|Night)$`)
	count := 0
	globalIDs := map[string]bool{}
	previous := 0.0
	seen := map[string]bool{}
	for _, s := range result.Scenes {
		if !pattern.MatchString(s.Session) || seen[s.Session] || s.Start <= previous || s.Contract == "" || s.ExpectedQuality == nil || s.ExpectedAccepted != s.ExpectedQuality.Delivered {
			return result, "", fmt.Errorf("場/限月/順序/品質差:%s", s.Session)
		}
		if !finite(s.Start, s.End, s.ForceClose) || s.End-3900 <= s.Start || s.ForceClose <= s.Start || s.Raw.Path == "" || len(s.Raw.SHA256) != 64 {
			return result, "", fmt.Errorf("場時計/Raw参照差")
		}
		seen[s.Session] = true
		previous = s.End
		count += len(s.Entries)
		ids := map[string]bool{}
		for _, entry := range s.Entries {
			q := entry.Entry
			if entry.ID == "" || ids[entry.ID] || globalIDs[entry.ID] || (entry.Side != 1 && entry.Side != -1) || !q.QuoteOK || !normal(q) || !finite(q.Time, q.Last) || q.Time < s.Start || q.Time >= math.Min(s.ForceClose, s.End-3900) || q.Index < 0 || q.Index >= s.ExpectedAccepted || q.SourceLine < q.Index+1 {
				return result, "", fmt.Errorf("固定取得の範囲/原行/BBO差:%s", entry.ID)
			}
			ids[entry.ID] = true
			globalIDs[entry.ID] = true
		}
	}
	if count != 31642 || result.Scenes[0].Session != "2026-09-21_Day" || result.Scenes[72].Session != "2026-11-10_Day" {
		return result, "", fmt.Errorf("固定取得数/使用場範囲差")
	}
	sha := sha256.Sum256(decoded)
	return result, hex.EncodeToString(sha[:]), nil
}

// appendRecord は固定little endian48bytesで採用quoteを書きます。
//
// 機能: JSONや同じ幅ごとの価格副本を避けて数値索引を作ります。
// 引数: target(io.Writer)、q(Quote)は保存先と採用原行。
// 返り値: errorは書込失敗です。
func appendRecord(target io.Writer, q Quote) error {
	var row [recordBytes]byte
	values := [6]uint64{math.Float64bits(q.Time), uint64(q.SourceLine), math.Float64bits(q.Last), math.Float64bits(q.Bid), math.Float64bits(q.Ask), 0}
	if q.QuoteOK {
		values[5] = 1
	}
	for i, v := range values {
		binary.LittleEndian.PutUint64(row[i*8:], v)
	}
	_, e := target.Write(row[:])
	return e
}

// indexScene は一場のRawを一回だけ読み固定取得を全値照合します。
//
// 機能: Source同体parserの全採用行をgzip数値索引へ保存し品質と原板指紋を検査します。
// 引数: scene(FixedScene)、directory(string)は固定場と未使用の保存ディレクトリ。
// 返り値: IndexScene/errorは索引の物理証跡又は失敗です。
func indexScene(scene FixedScene, directory string) (IndexScene, error) {
	result := IndexScene{Session: scene.Session, Contract: scene.Contract, Raw: scene.Raw, EntryCount: len(scene.Entries)}
	raw, e := os.Open(scene.Raw.Path)
	if e != nil {
		return result, e
	}
	defer raw.Close()
	before, e := raw.Stat()
	if e != nil {
		return result, e
	}
	result.Before = FileStat{Bytes: before.Size(), ModTimeNS: before.ModTime().UnixNano()}
	fileName := scene.Session + ".quotes.bin.gz"
	pending := filepath.Join(directory, fileName+".part")
	output, e := os.OpenFile(pending, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		return result, e
	}
	compressed := gzip.NewWriter(output)
	buffer := bufio.NewWriterSize(compressed, 1<<20)
	if _, e = buffer.WriteString(indexMagic); e != nil {
		return result, e
	}
	h := sha256.New()
	tee := io.TeeReader(raw, h)
	stream, _, e := rawStream133(tee)
	if e != nil {
		return result, e
	}
	defer stream.Close()
	scanner := bufio.NewScanner(stream)
	scanner.Buffer(make([]byte, 65536), 8*1024*1024)
	base := Scene{Session: scene.Session, Contract: scene.Contract, Start: scene.Start, End: scene.End, Raw: scene.Raw}
	wanted := map[int64][]FixedEntry{}
	for _, entry := range scene.Entries {
		wanted[entry.Entry.SourceLine] = append(wanted[entry.Entry.SourceLine], entry)
	}
	previous := scene.Start
	var index int64
	matched := 0
	contracts := map[string]bool{}
	for scanner.Scan() {
		result.Quality.Lines++
		q, reason, next, err := decodeRow(scanner.Bytes(), result.Quality.Lines, index, base, previous, &result.Quality, contracts)
		if err != nil {
			return result, err
		}
		previous = next
		for _, entry := range wanted[result.Quality.Lines] {
			if q == nil || entry.Entry != *q {
				return result, fmt.Errorf("固定取得全値差:%s 原行%d 理由%s", entry.ID, result.Quality.Lines, reason)
			}
			matched++
		}
		if q != nil {
			if q.Index != index {
				return result, fmt.Errorf("採用index非連続")
			}
			if e = appendRecord(buffer, *q); e != nil {
				return result, e
			}
			index++
		}
	}
	if e = scanner.Err(); e != nil {
		return result, e
	}
	if _, e = io.Copy(io.Discard, tee); e != nil {
		return result, e
	}
	after, e := raw.Stat()
	if e != nil {
		return result, e
	}
	result.After = FileStat{Bytes: after.Size(), ModTimeNS: after.ModTime().UnixNano()}
	result.ActualRawSHA256 = hex.EncodeToString(h.Sum(nil))
	if result.ActualRawSHA256 != scene.Raw.SHA256 || result.Before != result.After {
		return result, fmt.Errorf("Raw全bytes SHA/stat差")
	}
	if len(contracts) != 1 || !contracts[scene.Contract] || index != scene.ExpectedAccepted || result.Quality != *scene.ExpectedQuality || matched != len(scene.Entries) {
		return result, fmt.Errorf("限月/全行品質/全取得結合差")
	}
	if e = buffer.Flush(); e != nil {
		return result, e
	}
	if e = compressed.Close(); e != nil {
		return result, e
	}
	if e = output.Close(); e != nil {
		return result, e
	}
	final := filepath.Join(directory, fileName)
	if _, e = os.Stat(final); !os.IsNotExist(e) {
		return result, fmt.Errorf("索引出力の重複")
	}
	if e = os.Rename(pending, final); e != nil {
		return result, e
	}
	digest, e := hashFile(final)
	if e != nil {
		return result, e
	}
	stat, e := os.Stat(final)
	if e != nil {
		return result, e
	}
	result.Index = FileRef{Path: fileName, SHA256: digest}
	result.IndexBytes = stat.Size()
	result.Rows = index
	result.AllEntriesMatched = true
	result.Success = true
	return result, nil
}

// buildIndex は全73場を最大8並列で一度だけ数値索引化します。
//
// 機能: 正式manifestが完成した後の任意幅評価でRaw再走査を不要にします。
// 引数: input/expected/output(string)、workers(int)は固定表・SHA・未作成保存先・並列数。
// 返り値: errorは入力/原板/保存検査の失敗です。
func buildIndex(input, expected, output string, workers int) error {
	if workers < 1 || workers > 8 {
		return fmt.Errorf("並列数は1～8")
	}
	in, decoded, e := readFixed(input, expected)
	if e != nil {
		return e
	}
	if _, e = os.Stat(output); !os.IsNotExist(e) {
		return fmt.Errorf("未作成の索引保存先だけ")
	}
	if e = os.MkdirAll(output, 0700); e != nil {
		return e
	}
	results := make([]IndexScene, len(in.Scenes))
	jobs := make(chan int)
	var wg sync.WaitGroup
	for worker := 0; worker < workers; worker++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := range jobs {
				r, err := indexScene(in.Scenes[i], output)
				if err != nil {
					r.Error = err.Error()
				}
				results[i] = r
				fmt.Printf("索引 %s 成功=%t %s\n", r.Session, r.Success, r.Error)
			}
		}()
	}
	for i := range in.Scenes {
		jobs <- i
	}
	close(jobs)
	wg.Wait()
	for _, r := range results {
		if !r.Success {
			return fmt.Errorf("索引失敗 %s:%s", r.Session, r.Error)
		}
	}
	after, e := hashFile(input)
	if e != nil || after != expected {
		return fmt.Errorf("固定入力の前後変更")
	}
	manifest := Manifest{Version: 163, Success: true, InputSHA256: expected, InputDecodedSHA256: decoded, SourceEntryCount: in.ExpectedEntryCount, Scenes: results, RowFormat: "magic8=NQIDX163, little endian48bytes=(time f64,line i64,last f64,bid f64,ask f64,normal u64)。indexは0始まり行位置。", RawPassesPerScene: 1}
	return writeJSON(filepath.Join(output, "manifest.json"), manifest)
}

// writeJSON は上書きを拒否してUTF-8の検査票を作ります。
//
// 機能: 途中結果と正常完了の公開を分けます。
// 引数: path(string)、value(any)は保存先とJSON値。
// 返り値: errorは保存失敗です。
func writeJSON(path string, value any) error {
	body, e := json.MarshalIndent(value, "", "  ")
	if e != nil {
		return e
	}
	f, e := os.OpenFile(path, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if e != nil {
		return e
	}
	defer f.Close()
	_, e = f.Write(append(body, '\n'))
	return e
}

// loadRecords は索引の物理SHAとgzip全CRCを確認して採用行を復元します。
//
// 機能: JSON原板の再解析を避けて固定数値索引を読む。
// 引数: path/expected(string)、rows(int64)は索引と期待SHA・採用件数。
// 返り値: []Record/errorは原行順の数値又は不正入力です。
func loadRecords(path, expected string, rows int64) ([]Record, error) {
	digest, e := hashFile(path)
	if e != nil || digest != expected {
		return nil, fmt.Errorf("数値索引SHA差")
	}
	f, e := os.Open(path)
	if e != nil {
		return nil, e
	}
	defer f.Close()
	z, e := gzip.NewReader(f)
	if e != nil {
		return nil, e
	}
	defer z.Close()
	body, e := io.ReadAll(z)
	if e != nil {
		return nil, e
	}
	if int64(len(body)) != 8+recordBytes*rows || string(body[:8]) != indexMagic {
		return nil, fmt.Errorf("数値索引magic/件数差")
	}
	result := make([]Record, rows)
	for i := range result {
		b := body[8+i*recordBytes : 8+(i+1)*recordBytes]
		r := Record{Time: math.Float64frombits(binary.LittleEndian.Uint64(b)), SourceLine: int64(binary.LittleEndian.Uint64(b[8:])), Last: math.Float64frombits(binary.LittleEndian.Uint64(b[16:])), Bid: math.Float64frombits(binary.LittleEndian.Uint64(b[24:])), Ask: math.Float64frombits(binary.LittleEndian.Uint64(b[32:])), Flags: binary.LittleEndian.Uint64(b[40:])}
		if !finite(r.Time, r.Last, r.Bid, r.Ask) || r.Last <= 0 || r.Flags > 1 || r.SourceLine < 1 {
			return nil, fmt.Errorf("索引数値不正")
		}
		if i > 0 && (r.Time < result[i-1].Time || r.SourceLine <= result[i-1].SourceLine) {
			return nil, fmt.Errorf("索引の物理順序差")
		}
		if (r.Flags == 1) != (r.Bid > 0 && r.Ask > r.Bid) {
			return nil, fmt.Errorf("索引BBO旗差")
		}
		result[i] = r
	}
	return result, nil
}
