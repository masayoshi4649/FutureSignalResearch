# 任意幅IFDのRaw数値索引と最初到達検索

2026-11-14。Raw本文は全73場を一度だけ走査し、以後の値幅・期限比較は数値索引を使う。新規入口・特徴・学習をこの後段へ渡さない。対象は旧148固定31,642caseで、新しい取得範囲へ拡張しない。

## 実装と計算量

旧133の`finite/normal/decodeRow`関数本文を同体再用し、由来SHAを保存した。全物理RawのSHA、gzip全CRC、前後stat、限月、全行品質、採用件数と全固定取得原行の全値を確認する。各採用quoteは48byte little endianのgzip数値へ一度保存。採用indexは行位置、time/元line/Last/Bid/Ask/正常BBO旗を保持し、幅ごとの原板副本を作らない。

任意幅評価はBidとAskのmin/max segment treeを一場につき一度作り、取得q1より後の最初の上下到達を原行順に検索する。正常BBO以外は木の極値へ含めない。価格gapとBBOgapの最初イベントは別の二分探索。全quote×全case×全widthの更新を避け、概ねO(N＋case×width×horizon×logN)で評価する。原板のJSON再解析は繰り返さない。

人工では旧133逐次kernelへ48,832の実側×幅×時計を照合し、正常BBOのgap300秒、期限猶予30秒、同秒後続、期限完了後の同秒除外、phase等号優先が同体だった。新しいSESSIONも人工で別確認。人工10万行の索引上で1000取得×7幅×4期限×両側の木検索は約13msだったが、Raw読取や自然全体の性能をこの値から推定しない。

## 時計

H30/H60/H120は固定q1からのstrict期限。取得q1原行を先着に使わず、同秒の後続原行は使う。正常BBOで買Ask/売Bid取得、買Bid/売Ask清算。市場終端End−300の等号以後は先着/endpointに使わない。旧H60を残す取得母集団を保つため、H120が閉場前に完了しなければCへ残す。

SESSIONは別契約。市場境界を観測したこと、終端未満の最後の正常BBOが鮮度30秒以内であることを完了条件とする。清算用quoteは境界未満、label成熟は最初の境界観測時計。境界前のgapはC。旧strictHの時計へ混同しない。どの時計を採用するかはRootの新試行条件で固定する。

各幅ともstrict完了だけF/A/N、他C。Cでも打切り前touchがあればIFD金融既知、touchなしCは未知。mini1枚100円/pt、往復77円、C5追加滑り1000円。実IFDの遅延・mini板・待ち行列は再現しておらず、瞬時実BBO代用である。

## CLIと出力

```powershell
go test ./...
go vet ./...
go build -o 任意幅Raw索引.exe .
任意幅Raw索引.exe --mode index --input 固定取得入力.json.gz --sha256 固定SHA --output-dir 未作成索引先 --workers 4
任意幅Raw索引.exe --mode evaluate --input 固定取得入力.json.gz --sha256 固定SHA --index-dir 索引先 --index-sha256 manifestSHA --config 観測条件.json --config-sha256 条件SHA --output-dir 未作成観測先 --workers 4
```

indexは`manifest.json`と73本の`場名.quotes.bin.gz`、evaluateは`manifest.json`と73本の`場名.outcomes.json.gz`。最初到達・期限・清算は採用indexを参照し同じQuote本体を重複保存しない。case→sides(BUY/SELL)→outcomes(H30/H60/H120/SESSION)→touches(任意幅)の順。Go部品のSource停止票・人工・条件雛形とRoot F0を別に保存する。自然実行は`run_raw163.py`のF0検査後だけ。
