module quoteindex163

go 1.24.2
