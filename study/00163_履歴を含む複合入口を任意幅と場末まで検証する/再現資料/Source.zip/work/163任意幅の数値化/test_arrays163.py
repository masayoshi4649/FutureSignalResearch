"""任意幅数値化の実側・期限・場末成熟・未知・保存型を人工検査する。"""
from pathlib import Path
import copy
import gzip
import json
import math
import tempfile

import numpy as np
import arrays163 as M


def fixture() -> tuple:
    """
    機能: strict完了・場末完了・strict打切りを持つ人工両側観測を作る。
    引数: なし。
    返り値: tupleはconfig/records/entry/case。
    """
    times=[100,200,400,600,800,1000,1200,1400,1600,1800,1900,1999,2000]
    bids=[990,1300,900,1400,1500,1450,1300,1200,1350,1400,1500,1600,1900]
    records=np.zeros(len(times),dtype=M.RECORD)
    for i,(at,bid) in enumerate(zip(times,bids,strict=True)):
        records[i]=(at,i+1,bid+5,bid,bid+10,1)
    config={'widths':[125,200,400,750],'horizons':[{'id':'H30','kind':'strict','seconds':1800},
        {'id':'H120','kind':'strict','seconds':7200},{'id':'SESSION','kind':'session','seconds':0}]}
    e={'time':100,'index':0,'source_line':1,'last':995,'bid':990,'ask':1000,'quote_ok':True}
    entry={'id':'人工','side':1,'entry':e}
    case={'id':'人工','original_side':1,'entry_index':0,'sides':[]}
    for side in (1,-1):
        price=e['ask' if side==1 else 'bid'];outcomes=[]
        for h in config['horizons']:
            session=h['kind']=='session';deadline=2000 if session else e['time']+h['seconds']
            endpoint=11 if session else 10 if h['seconds']==1800 else None
            complete=endpoint is not None;known_at=2000 if session else records[endpoint]['time'].item() if complete else None
            touch_end=12 if session or not complete else endpoint+1
            touches=[]
            for width in config['widths']:
                hit=None;direction=0
                for i in range(1,touch_end):
                    if records[i]['time']>deadline:
                        break
                    movement=side*(records[i]['bid' if side==1 else 'ask']-price)
                    if abs(movement)>=width:
                        hit=i;direction=1 if movement>0 else -1;break
                exit_index=hit if hit is not None else endpoint if complete else None
                points=side*(records[exit_index]['bid' if side==1 else 'ask']-price).item() if exit_index is not None else None
                touches.append({'width':width,'direction':direction,'label':direction if complete else 2,
                    'touch_index':hit,'exit_index':exit_index,'points':points,'net0':points*100-77 if points is not None else None,
                    'net5':points*100-1077 if points is not None else None})
            outcomes.append({'horizon_id':h['id'],'kind':h['kind'],'seconds':h['seconds'],'deadline':deadline,
                'status':'complete' if complete else 'phase_censored','complete':complete,'known_at':known_at,
                'endpoint_index':endpoint,'touches':touches})
        case['sides'].append({'side':side,'entry_price':price,'outcomes':outcomes})
    return config,records,entry,case


def main() -> None:
    """
    機能: 金融と時計の意味、cache型と破損拒否を自然入力なしで確認する。
    引数: なし。
    返り値: None。成功票をJSON出力する。
    """
    config,records,entry,case=fixture();widths=tuple(config['widths']);ids=tuple(h['id'] for h in config['horizons'])
    a=M.allocate(1,widths,ids);status={};M.fill_case(a,0,case,entry,records,widths,ids,config,status,2000)
    a['session_index'][0]=0
    table=M.RawOutcomeTable(('人工',),('場',),('場',),widths,ids,ids,a,tuple(status),{'条件':config})
    root=table.root_arrays()
    assert root['label'].shape==(1,2,4,3) and root['net'].dtype==np.int64
    assert np.all(root['label'][:,:,:,1]==2) and np.isnan(root['known_at'][:,:,:,1]).all()
    assert root['known'][0,0,0,1] and root['net'][0,0,0,1]==30000-1077
    assert not root['known'][0,0,3,1] and root['net'][0,0,3,1]==0
    assert np.all(root['known_at'][:,:,:,2]==2000) and np.all(a['endpoint_time'][:,:,2]==1999)
    assert root['pair_complete'][0,0].tolist()==[True,False,True]
    assert np.array_equal(table.view(125,1800)['net'],table.view(125,'H30')['net'])
    tests=['買売実価格と任意4幅×3時計','C早期touch既知と未知net0+known旗','SESSION清算時計と成熟時計の分離','両実側pair完了と成熟','期限IDと秒lookup']
    bad=copy.deepcopy(case);bad['sides'][0]['outcomes'][0]['touches'][0]['net5']+=1000
    try:M.fill_case(M.allocate(1,widths,ids),0,bad,entry,records,widths,ids,config,{},2000)
    except AssertionError:pass
    else:raise AssertionError('費用改変を許した')
    tests.append('実IFD費用1077円の改変拒否')
    raw={'path':'人工','sha256':'0'*64,'bytes':100,'mod_time_ns':123}
    ref={'raw':{'path':'人工','sha256':'0'*64},'actual_raw_sha256':'0'*64,
        'stat_before':{'bytes':100,'mtime_ns':123},'stat_after':{'bytes':100,'mtime_ns':123}}
    M.checked_raw_ref(raw,ref);M.checked_raw_ref({k:raw[k] for k in ('path','sha256')},ref)
    bad=copy.deepcopy(ref);bad['stat_before']['bytes']=99;bad['stat_after']['bytes']=99
    try:M.checked_raw_ref(raw,bad)
    except AssertionError:pass
    else:raise AssertionError('固定Rawサイズ差を許した')
    tests.append('Raw参照の追加stat有無と固定サイズ改変拒否')
    with tempfile.TemporaryDirectory() as temporary:
        p=Path(temporary)/'table';refs=M.save_table(table,p);again=M.load_table(p,refs)
        assert again.case_ids==table.case_ids and again.horizons==ids
        for name,value in a.items():
            assert np.array_equal(value,again.arrays[name],equal_nan=True)
        record_path=Path(temporary)/'records.bin.gz'
        record_path.write_bytes(gzip.compress(b'NQIDX163'+records.tobytes(),mtime=0))
        decoded=M.load_records(record_path,M.sha(record_path),len(records));assert np.array_equal(decoded,records)
        encoded=bytearray(record_path.read_bytes());encoded[-1]^=1;record_path.write_bytes(encoded)
        try:M.load_records(record_path,M.sha(record_path),len(records))
        except (OSError,EOFError):pass
        else:raise AssertionError('数値索引CRC破損を許した')
    tests.append('数値NPZとgzip識別の全型保存復元・数値索引48byte・CRC拒否')
    print(json.dumps({'成功':True,'自然入力なし':True,'検査群':tests,'SourceSHA256':M.sha(Path(M.__file__))},ensure_ascii=False))


if __name__=='__main__':
    main()
