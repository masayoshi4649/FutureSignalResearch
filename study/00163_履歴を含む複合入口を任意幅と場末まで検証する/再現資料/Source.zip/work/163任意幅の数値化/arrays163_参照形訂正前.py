"""163の任意幅観測を探索器のcase/実側/幅/期限配列へ変換する。"""
from dataclasses import dataclass
from pathlib import Path
import gzip
import hashlib
import json
import math

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
FIXED=ROOT/'inputs/00148_全1分入口母集団/固定取得入力.json.gz'
FIXED_SHA='99f10a996ca6e8b6c428061f1b48624bbc479ec84c500a9633818d47e4298e2a'
FIXED_DECODED_SHA='12c43fe60e0ffd5ffa44bec7b5f7dd3d60bb92b291e0008db23587dcf19536d3'
RECORD=np.dtype({'names':['time','source_line','last','bid','ask','normal'],
    'formats':['<f8','<i8','<f8','<f8','<f8','<u8'],'offsets':[0,8,16,24,32,40],'itemsize':48})


def sha(path: Path) -> str:
    """
    機能: ファイル全物理bytesのSHA256を求める。
    引数: path(Path)は入力ファイル。
    返り値: strは小文字16進SHA256。
    """
    with path.open('rb') as source:
        return hashlib.file_digest(source,'sha256').hexdigest()


def checked_json(path: Path, expected: str, compressed: bool=False) -> dict:
    """
    機能: 物理SHAと任意gzip全CRCを確認してJSONを読む。
    引数: path(Path)、expected(str)、compressed(bool)は入力と指紋・gzip旗。
    返り値: dictは標準JSONの内容。
    """
    assert sha(path)==expected
    body=path.read_bytes()
    if compressed:
        body=gzip.decompress(body)
    value=json.loads(body,parse_constant=lambda s:(_ for _ in ()).throw(ValueError(s)))
    assert sha(path)==expected
    return value


def load_records(path: Path, expected: str, rows: int) -> np.ndarray:
    """
    機能: 48byteの数値索引を全CRC/物理SHA/行数/単調性確認後に復元する。
    引数: path(Path)、expected(str)、rows(int)は索引と期待指紋・採用件数。
    返り値: np.ndarrayは構造化した原行順数値。
    """
    assert sha(path)==expected
    body=gzip.decompress(path.read_bytes())
    assert body[:8]==b'NQIDX163' and len(body)==8+48*rows
    records=np.frombuffer(body,dtype=RECORD,offset=8)
    assert len(records)==rows and np.isfinite(records['time']).all()
    assert np.all(np.diff(records['time'])>=0) and np.all(np.diff(records['source_line'])>0)
    assert np.all(np.isin(records['normal'],[0,1]))
    assert np.array_equal(records['normal']==1,(records['bid']>0)&(records['bid']<records['ask']))
    assert sha(path)==expected
    return records


@dataclass
class RawOutcomeTable:
    case_ids: tuple[str,...]
    sessions: tuple[str,...]
    session_order: tuple[str,...]
    widths: tuple[float,...]
    horizons: tuple
    horizon_ids: tuple[str,...]
    arrays: dict[str,np.ndarray]
    status_names: tuple[str,...]
    evidence: dict

    def case_to_index(self) -> dict[str,int]:
        """
        機能: case識別子を数値表位置へ対応付ける。
        引数: self(RawOutcomeTable)は完成した純観測。
        返り値: dict[str,int]は辞書順caseの位置。
        """
        return {case:i for i,case in enumerate(self.case_ids)}

    def view(self,width: float,horizon: object,cost: str='C5') -> dict[str,np.ndarray]:
        """
        機能: 指定幅・期限のcase×実側参照を返す。
        引数: self(RawOutcomeTable)、width(float)、horizon(int秒又はstr ID)、cost(str C0/C5)。
        返り値: dict[str,np.ndarray]はlabel/net/known/exit/成熟時計。
        """
        assert cost in ('C0','C5')
        wi=self.widths.index(width)
        if horizon in self.horizon_ids:
            hi=self.horizon_ids.index(horizon)
        else:
            matches=[i for i,h in enumerate(self.evidence['条件']['horizons']) if h['kind']=='strict' and h['seconds']==horizon]
            assert len(matches)==1
            hi=matches[0]
        return {**{k:self.arrays[k][:,:,wi,hi] for k in ('label','known','direction','points','exit_time','exit_index','exit_line','known_at')},
            'net':self.arrays['net0' if cost=='C0' else 'net5'][:,:,wi,hi]}

    def root_arrays(self,cost: str='C5') -> dict[str,np.ndarray]:
        """
        機能: Root探索器向けの配列名と軸順で全幅・期限を公開する。
        引数: self(RawOutcomeTable)、cost(str)はC0又はC5。
        返り値: dict[str,np.ndarray]はlabel/net/known等。金融未知0はknown=Falseと同時に使用する。
        """
        assert cost in ('C0','C5')
        pair_complete=np.all(self.arrays['label']!=2,axis=1)
        pair_known_at=np.max(self.arrays['known_at'],axis=1)
        assert np.array_equal(np.isfinite(pair_known_at),pair_complete)
        return {**{k:self.arrays[k] for k in ('label','known','entry_time','entry_index','entry_line','entry_price',
            'exit_time','exit_index','exit_line','known_at','session_index')},'net':self.arrays['net0' if cost=='C0' else 'net5'],
            'pair_complete':pair_complete,'pair_known_at':pair_known_at}


def allocate(n: int,widths: tuple,horizons: tuple) -> dict[str,np.ndarray]:
    """
    機能: 未知旗と別に金額や時計を保持する数値配列を確保する。
    引数: n(int)、widths/horizons(tuple)はcase数と評価軸。
    返り値: dict[str,np.ndarray]はpickle不要の配列。
    """
    shape=(n,2,len(widths),len(horizons));short=(n,2,len(horizons))
    arrays={k:np.full(shape,math.nan) for k in ('points','exit_time','known_at')}
    arrays.update({k:np.full(shape,-1,dtype=np.int64) for k in ('exit_index','exit_line')})
    arrays.update(label=np.full(shape,2,dtype=np.int8),direction=np.zeros(shape,dtype=np.int8),known=np.zeros(shape,dtype=np.bool_))
    arrays.update(net0=np.zeros(shape,dtype=np.int64),net5=np.zeros(shape,dtype=np.int64))
    arrays.update(complete=np.zeros(short,dtype=np.bool_),status=np.full(short,-1,dtype=np.int16),
        endpoint_time=np.full(short,math.nan),deadline=np.full(short,math.nan),endpoint_index=np.full(short,-1,dtype=np.int64))
    arrays.update(entry_time=np.full(n,math.nan),entry_index=np.full(n,-1,dtype=np.int64),entry_line=np.full(n,-1,dtype=np.int64),
        entry_price=np.full((n,2),math.nan),session_index=np.full(n,-1,dtype=np.int16),original_side=np.zeros(n,dtype=np.int8))
    return arrays


def fill_case(arrays: dict,index: int,case: dict,entry: dict,records: np.ndarray,
              widths: tuple,horizon_ids: tuple,config: dict,status_codes: dict,execution_end: float) -> None:
    """
    機能: Go観測の実原行参照と金融算式を検算してcase配列へ記録する。
    引数: arrays(dict)、index(int)、case/entry(dict)、records(np.ndarray)、widths/horizon_ids(tuple)、config/status_codes(dict)、execution_end(float)。
    返り値: None。当該case行だけを更新する。
    """
    assert case['id']==entry['id'] and case['original_side']==entry['side']
    e=entry['entry'];ei=case['entry_index'];assert ei==e['index'] and 0<=ei<len(records)
    q=records[ei]
    assert all(q[k]==e[k] for k in ('time','source_line','last','bid','ask')) and q['normal']==1
    for key,name in (('time','entry_time'),('index','entry_index'),('source_line','entry_line')):
        arrays[name][index]=e[key]
    arrays['original_side'][index]=entry['side']
    assert [s['side'] for s in case['sides']]==[1,-1]
    for si,s in enumerate(case['sides']):
        side=s['side'];price=e['ask' if side==1 else 'bid'];assert s['entry_price']==price
        arrays['entry_price'][index,si]=price
        assert [o['horizon_id'] for o in s['outcomes']]==list(horizon_ids)
        for hi,o in enumerate(s['outcomes']):
            h=config['horizons'][hi];complete=o['complete'];endpoint=o['endpoint_index']
            assert type(complete) is bool and complete==(o['status']=='complete') and (endpoint is not None)==complete
            assert o['kind']==h['kind'] and o['seconds']==h['seconds']
            deadline=execution_end if h['kind']=='session' else e['time']+h['seconds'];assert o['deadline']==deadline
            key=(index,si,hi);arrays['complete'][key]=complete;arrays['deadline'][key]=deadline
            code=status_codes.setdefault(o['status'],len(status_codes));arrays['status'][key]=code
            if complete:
                assert endpoint>ei and endpoint<len(records) and records[endpoint]['normal']==1 and records[endpoint]['time']<execution_end
                endpoint_time=records[endpoint]['time'];known_at=o['known_at'];assert type(known_at) in (int,float) and math.isfinite(known_at)
                if h['kind']=='strict':
                    assert deadline<=endpoint_time<=deadline+30 and known_at==endpoint_time
                else:
                    assert 0<execution_end-endpoint_time<=30 and known_at>=execution_end
                arrays['endpoint_time'][key]=endpoint_time;arrays['endpoint_index'][key]=endpoint
            else:
                assert o['known_at'] is None
            assert [t['width'] for t in o['touches']]==list(widths)
            for wi,touch in enumerate(o['touches']):
                at=(index,si,wi,hi);direction=touch['direction'];hit=touch['touch_index'];exit_index=touch['exit_index']
                assert type(direction) is int and direction in (-1,0,1) and (hit is None)==(direction==0)
                assert touch['label']==(direction if complete else 2)
                if hit is not None:
                    assert hit>ei and hit<len(records) and records[hit]['normal']==1
                    assert records[hit]['time']>=e['time'] and records[hit]['time']<execution_end
                    assert records[hit]['time']<=deadline
                    movement=side*(records[hit]['bid' if side==1 else 'ask']-price)
                    assert movement>=widths[wi]-1e-9 if direction==1 else movement<=-widths[wi]+1e-9
                expected_exit=hit if hit is not None else endpoint if complete else None
                assert exit_index==expected_exit
                known=exit_index is not None;arrays['known'][at]=known;arrays['label'][at]=touch['label'];arrays['direction'][at]=direction
                if complete:
                    arrays['known_at'][at]=o['known_at']
                if known:
                    mark=records[exit_index]['bid' if side==1 else 'ask'];points=side*(mark-price);net0=points*100-77;net5=net0-1000
                    assert touch['points']==points and touch['net0']==net0 and touch['net5']==net5
                    assert net0==round(net0) and net5==round(net5)
                    arrays['points'][at]=points;arrays['net0'][at]=int(net0);arrays['net5'][at]=int(net5)
                    arrays['exit_time'][at]=records[exit_index]['time'];arrays['exit_index'][at]=exit_index;arrays['exit_line'][at]=records[exit_index]['source_line']
                else:
                    assert touch['points'] is None and touch['net0'] is None and touch['net5'] is None


# ----------------------------------------
def read_table(index_directory: Path,index_sha: str,observation_directory: Path,observation_sha: str,
               config_path: Path,config_sha: str) -> RawOutcomeTable:
    """
    機能: 全73場の任意幅観測と数値索引を完読し探索器向けの純数値表を作る。
    引数: index_directory/observation_directory/config_path(Path)、index_sha/observation_sha/config_sha(str)は固定入力指紋。
    返り値: RawOutcomeTableはcase辞書順×BUY/SELL×任意幅×時計の数値配列。
    """
    im=checked_json(index_directory/'manifest.json',index_sha)
    om=checked_json(observation_directory/'manifest.json',observation_sha)
    config=checked_json(config_path,config_sha)
    assert im['success'] and im['version']==163 and om['success'] and om['trial']==163 and om['new_entry_selection'] is False
    assert om['index_manifest_sha256']==index_sha and om['config_sha256']==config_sha and om['config']==config
    assert om['input_sha256']==im['input_sha256']==FIXED_SHA and im['input_decoded_sha256']==FIXED_DECODED_SHA
    assert im['source_entry_count']==om['source_entry_count']==31642
    fixed=checked_json(FIXED,FIXED_SHA,True);assert len(fixed['scenes'])==len(im['scenes'])==len(om['scenes'])==73
    all_entries=[e for s in fixed['scenes'] for e in s['entries']]
    ids=tuple(sorted(e['id'] for e in all_entries));assert len(ids)==len(set(ids))==31642
    mapping={case:i for i,case in enumerate(ids)};sessions=['']*len(ids);order=[]
    widths=tuple(config['widths']);horizon_ids=tuple(h['id'] for h in config['horizons'])
    horizons=horizon_ids
    arrays=allocate(len(ids),widths,horizons);status_codes={}
    for scene_index,(scene,index_ref,observed_ref) in enumerate(zip(fixed['scenes'],im['scenes'],om['scenes'],strict=True)):
        session=scene['session'];assert session==index_ref['session']==observed_ref['session']
        assert index_ref['success'] and observed_ref['success'] and index_ref['all_entries_matched']
        assert index_ref['quality']==scene['expected_quality'] and index_ref['rows']==scene['expected_accepted']
        assert index_ref['raw']==scene['raw'] and index_ref['actual_raw_sha256']==scene['raw']['sha256']
        assert index_ref['stat_before']==index_ref['stat_after']
        index_name=index_ref['index']['path'];observed_name=observed_ref['file']['path']
        assert index_name==session+'.quotes.bin.gz' and observed_name==session+'.outcomes.json.gz'
        records=load_records(index_directory/index_name,index_ref['index']['sha256'],index_ref['rows'])
        observed=checked_json(observation_directory/observed_name,observed_ref['file']['sha256'],True)
        assert observed['success'] and observed['session']==session
        entries={e['id']:e for e in scene['entries']};seen=set()
        for case in observed['cases']:
            case_id=case['id'];assert case_id in entries and case_id not in seen
            row=mapping[case_id]
            fill_case(arrays,row,case,entries[case_id],records,widths,horizon_ids,config,status_codes,scene['end']-300)
            arrays['session_index'][row]=scene_index;sessions[row]=session;seen.add(case_id)
        assert seen==set(entries)
        order.append(session)
    assert all(sessions) and order[0]=='2026-09-21_Day' and order[-1]=='2026-11-10_Day'
    evidence={'成功':True,'純観測のみ':True,'採否なし':True,'入力物理SHA256':FIXED_SHA,
        '索引manifestSHA256':index_sha,'観測manifestSHA256':observation_sha,'観測条件SHA256':config_sha,
        '全73場':order,'case数':len(ids),'全索引と観測gzipの物理SHAとCRC':True,'side_order':[1,-1],
        '条件':config,'未知net0は格納値':'必ずknownを伴って集計する。points/時計は未知NaN。',
        'SESSION成熟時計':'境界を最初に観測した原行の価格時計。清算用endpoint時計とは分ける。'}
    return RawOutcomeTable(ids,tuple(sessions),tuple(order),widths,horizons,horizon_ids,arrays,
        tuple(sorted(status_codes,key=status_codes.get)),evidence)


def save_table(table: RawOutcomeTable,directory: Path) -> dict:
    """
    機能: 任意幅の純数値をNPZとgzip識別情報へ一度保存する。
    引数: table(RawOutcomeTable)、directory(Path)は未作成保存先。
    返り値: dictは物理ファイル名からSHA/bytesへの写像。
    """
    assert not directory.exists();directory.mkdir(parents=True)
    npz=directory/'任意幅配列.npz';np.savez_compressed(npz,**table.arrays)
    meta={'case_ids':table.case_ids,'sessions':table.sessions,'session_order':table.session_order,'widths':table.widths,
        'horizons':table.horizons,'horizon_ids':table.horizon_ids,'status_names':table.status_names,'evidence':table.evidence,
        'arrays':{k:{'shape':list(v.shape),'dtype':str(v.dtype)} for k,v in table.arrays.items()}}
    body=json.dumps(meta,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode('utf-8')
    path=directory/'任意幅識別.json.gz'
    with path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw,filename='',mode='wb',mtime=0) as output:
            output.write(body)
    return {p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in (npz,path)}


def load_table(directory: Path,expected: dict) -> RawOutcomeTable:
    """
    機能: 保存指紋と全NPZ/gzip CRCを確認して任意幅表を復元する。
    引数: directory(Path)、expected(dict)は保存先と2ファイルの固定指紋。
    返り値: RawOutcomeTableはpickle不要の復元値。
    """
    for name,ref in expected.items():
        p=directory/name;assert p.stat().st_size==ref['bytes'] and sha(p)==ref['sha256']
    meta=checked_json(directory/'任意幅識別.json.gz',expected['任意幅識別.json.gz']['sha256'],True)
    with np.load(directory/'任意幅配列.npz',allow_pickle=False) as source:
        assert set(source.files)==set(meta['arrays'])
        arrays={k:source[k].copy() for k in source.files}
    assert all(a.dtype.kind!='O' and list(a.shape)==meta['arrays'][k]['shape'] and str(a.dtype)==meta['arrays'][k]['dtype'] for k,a in arrays.items())
    return RawOutcomeTable(tuple(meta['case_ids']),tuple(meta['sessions']),tuple(meta['session_order']),tuple(meta['widths']),
        tuple(meta['horizons']),tuple(meta['horizon_ids']),arrays,tuple(meta['status_names']),meta['evidence'])
