"""163の固定任意幅観測をSource固定後に数値cacheへ変換する。"""
from pathlib import Path
from datetime import datetime,timezone
import argparse
import json

import arrays163 as M

HERE=Path(__file__).resolve().parent
RAW=M.ROOT/'work/163任意幅Raw索引'


def save(path: Path,value: object) -> None:
    """
    機能: UTF-8の新規JSONへ証跡を保存する。
    引数: path(Path)、value(object)は保存先と内容。
    返り値: None。
    """
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('x',encoding='utf-8',newline='\n') as output:
        json.dump(value,output,ensure_ascii=False,indent=2,allow_nan=False);output.write('\n')


def main() -> None:
    """
    機能: book/Go完了/停止Sourceを数値化前へ固定して全任意幅配列を保存する。
    引数: CLI book/config/output-dir(Path)、book-sha256/config-sha256(str)は条件と未作成保存先。
    返り値: None。新規採否やモデルを受け取らず純配列を作る。
    """
    parser=argparse.ArgumentParser()
    parser.add_argument('--book',type=Path,required=True);parser.add_argument('--book-sha256',required=True)
    parser.add_argument('--config',type=Path,required=True);parser.add_argument('--config-sha256',required=True)
    parser.add_argument('--output-dir',type=Path,required=True)
    args=parser.parse_args();assert M.sha(args.book)==args.book_sha256 and M.sha(args.config)==args.config_sha256
    book=json.loads(args.book.read_text(encoding='utf-8'));assert book.get('trial',book.get('試行'))==163
    stop_path=HERE/'数値化の停止.json';stop=json.loads(stop_path.read_text(encoding='utf-8'))
    assert stop['成功'] and stop['自然数値化前']
    assert all(M.sha(HERE/name)==digest for name,digest in stop['Source'].items())
    finished=RAW/'自然観測完了.json';ready=json.loads(finished.read_text(encoding='utf-8'))
    assert ready['成功'] and ready['条件SHA256']==args.book_sha256 and ready['観測条件SHA256']==args.config_sha256
    save(args.book.parent/'検査/F1_任意幅数値化前.json',{'成功':True,'試行':163,'時計':datetime.now(timezone.utc).isoformat(),
        '条件SHA256':args.book_sha256,'観測条件SHA256':args.config_sha256,'Go観測完了票SHA256':M.sha(finished),
        '停止票SHA256':M.sha(stop_path),'Source':stop['Source'],'採否なし':True,'自然数値化前':True})
    table=M.read_table(RAW/'自然索引',ready['索引manifestSHA256'],RAW/'自然観測',ready['観測manifestSHA256'],args.config,args.config_sha256)
    refs=M.save_table(table,args.output_dir)
    assert M.sha(args.book)==args.book_sha256 and M.sha(args.config)==args.config_sha256
    assert all(M.sha(HERE/name)==digest for name,digest in stop['Source'].items())
    save(args.output_dir/'入力と数値化の確認.json',{'成功':True,'試行':163,'条件SHA256':args.book_sha256,
        'Source':stop['Source'],'入力':table.evidence,'cache':refs,'shape':list(table.arrays['label'].shape),
        '軸':'case辞書順/BUY+1 SELL−1/12幅/H30,H60,H120,SESSION','新規採否なし':True})
    save(args.output_dir/'完了.json',{'成功':True,'試行':163,'case数':len(table.case_ids),'全場数':len(table.session_order),
        '幅':table.widths,'時計':table.horizons,'cache':refs,'条件SHA256':args.book_sha256,
        '確認票SHA256':M.sha(args.output_dir/'入力と数値化の確認.json')})
    print(json.dumps({'数値化完了':True,'case数':len(table.case_ids),'shape':list(table.arrays['label'].shape),'cache':refs},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
