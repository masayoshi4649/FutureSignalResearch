# 163任意幅観測の数値化

2026-11-14。Raw数値索引とGo最初到達結果を探索器の共通配列へ射影する後段。自然採否・特徴・モデルを引数に取らない。

`arrays163.read_table(index_directory,index_sha,observation_directory,observation_sha,config_path,config_sha)`は全73場の索引・観測gzip全CRC/物理SHAと実原行を照合し、31,642caseを辞書順へ揃える。Rootの162case順と同体にできる。`save_table` / `load_table(directory,expected)`は数値NPZと小型gzip識別へ保存・再読する。

表の`.widths`はRoot固定12幅。`.horizons`と`.horizon_ids`は`('H30','H60','H120','SESSION')`。`.case_ids`はcase辞書順、`.sessions`はcaseごとの場、`.session_order`は73場の時系列。`root_arrays('C5')`は`label/net/known/exit_time/known_at`を[case,実側,幅,期限]で返す。実側はBUY+1・SELL−1、labelは−1逆/0未/1順/2不足。netはint64円、未知の格納0は必ずknown=Falseを伴う。`entry_time/index/line`と`session_index`はcase軸、`entry_price`はcase×実側。

`known_at`はlabelの成熟時計である。strict完了では最初正常endpoint、SESSIONでは市場境界を初めて観測した価格時計を使い、直前清算BBOの時計と区別する。C早期touchでは金融既知でもlabel成熟はNaNのまま。`pair_complete`と`pair_known_at`は両実側が完了した幅×期限の教師用集合を示す。

`view(width,horizon)`はcase×実側の参照で、horizonはID又はstrict秒でも指定できる。Raw indexはmagic8 `NQIDX163`と48byte little endian/time,line,last,bid,ask,normal、元採用indexは行位置。数値化時も全物理q1のtime/index/line/last/Bid/Askを照合し、決済は必ず実Bid/Askから計算する。`outcome.net5`の期限清算値をtouch清算へ転用しない。

人工は両実側・4幅×strict/SESSION・C早期touch/未知・場末成熟・対pair・費用改変拒否・型保存復元・48byte索引/gzip全CRCを含む。Goの独立検算は別担当で旧148125/200×H30/H60を比較する。
