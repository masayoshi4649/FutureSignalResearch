"""163のベクトル集計を別の一取引ずつの算術へ人工照合する。"""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import math
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'work/163入口と任意幅'))
import 評価163 as S
from 評価基盤 import Selection


def sha(path: Path) -> str:
    """
    機能: 検査したSourceをSHA256へ束縛する。
    引数: path(Path)は対象Source。
    返り値: strは小文字SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def independent(context: object,selected: Selection,widths: object) -> np.ndarray:
    """
    機能: numpyの一括集計を使わず一取得ごとのPython算術で25指標を計算する。
    引数: context(object)、selected(Selection)、widths(int又はnp.ndarray[int])は人工文脈と選択。
    返り値: np.ndarray[H,3,25]は別実装の期待統計。
    """
    result=np.full((len(context.table.horizons),3,len(S.FIELDS)),math.nan)
    for hi in range(len(context.table.horizons)):
        for pi in range(3):
            eligible=list(range(73)) if pi==0 else list(range(48)) if pi==1 else list(range(48,73))
            counts={s:0 for s in eligible};new_scenes=set();labels={'F':0,'A':0,'N':0,'C':0}
            count=old_count=known=wins=losing=profit=loss=0;holding=[]
            for row in range(len(selected.cases)):
                ci=int(selected.cases[row]);si=int(selected.sides[row]);scene=int(context.case_scene[ci])
                if scene not in eligible:
                    continue
                wi=int(widths) if np.isscalar(widths) else int(widths[row])
                label=int(context.arrays['label'][ci,si,wi,hi]);labels[{1:'F',-1:'A',0:'N',2:'C'}[label]]+=1
                count+=1;counts[scene]+=1;is_old=bool(selected.old[row]);old_count+=int(is_old)
                if not is_old:
                    new_scenes.add(scene)
                if not bool(context.arrays['known'][ci,si,wi,hi]):
                    continue
                known+=1;net=int(context.arrays['net'][ci,si,wi,hi])
                if net>0:profit+=net;wins+=1
                if net<0:loss-=net;losing+=1
                holding.append(float(context.arrays['exit_time'][ci,si,wi,hi])-float(context.arrays['entry_time'][ci]))
            def ratio(a: float,b: float) -> float:
                """
                機能: 分母0をNaNで保持する独立した除算。
                引数: a/b(float)は分子/分母。
                返り値: floatは比率又はNaN。
                """
                return a/b if b else math.nan
            hours=sum(float(context.hours[s,j]) for s in eligible for j in range(3))
            values={'count':count,**labels,'rate':ratio(labels['F'],labels['F']+labels['A']),
                'complete_rate':ratio(labels['F'],labels['F']+labels['A']+labels['N']),
                'all_rate':ratio(labels['F'],count),'profit':profit,'loss':loss,'net':profit-loss,'pf':ratio(profit,loss),
                'known':known,'unknown':count-known,'scenes':sum(v>0 for v in counts.values()),
                'all_scenes':int(all(v>0 for v in counts.values())),'per_hour':ratio(count,hours),
                'max_scene_share':ratio(max(counts.values()),count),'new_count':count-old_count,'old_count':old_count,
                'hold_mean_seconds':ratio(sum(holding),known),'wins':wins,'loss_trades':losing,
                'realized_win_rate':ratio(wins,known),'new_scenes':len(new_scenes)}
            for fi,name in enumerate(S.FIELDS):
                result[hi,pi,fi]=values[name]
    return result


def fixture() -> object:
    """
    機能: 73場と47/48境界、F/A/N/C、未知、0円を含む人工文脈を作る。
    引数: なし。
    返り値: objectは実配列と同shapeの人工Context。
    """
    rng=np.random.default_rng(163);n=219;shape=(n,2,3,4)
    labels=rng.choice(np.array([-1,0,1,2],dtype=np.int8),size=shape)
    known=(labels!=2)|(rng.random(shape)>.5)
    net=rng.integers(-50000,50001,size=shape,dtype=np.int64)
    net[labels==1]=rng.integers(12000,50001,size=int((labels==1).sum()))
    net[labels==-1]=-rng.integers(12000,50001,size=int((labels==-1).sum()))
    net[(labels==0)&(rng.random(shape)<.25)]=0;net[~known]=0
    entry=np.arange(n,dtype=np.float64)*10000+1000000000
    duration=rng.integers(0,30001,size=shape).astype(np.float64)+.125
    exits=entry[:,None,None,None]+duration;exits[~known]=np.nan
    hours=np.zeros((73,3))
    for scene in range(73):
        if scene%2==0:hours[scene,0]=6+55/60
        else:hours[scene,1]=5.5;hours[scene,2]=7+25/60
    assert math.isclose(float(hours.sum()),720+55/60,rel_tol=1e-14)
    return SimpleNamespace(arrays={'label':labels,'known':known,'net':net,'exit_time':exits,'entry_time':entry},
        table=SimpleNamespace(horizons=('H30','H60','H120','SESSION')),case_scene=np.tile(np.arange(73,dtype=np.int16),3),hours=hours)


def selection(cases: list,old: object=False) -> Selection:
    """
    機能: 物理重複のない人工選択を作る。
    引数: cases(list[int])、old(bool又はlist[bool])はcaseと旧参照旗。
    返り値: SelectionはRootと同じ型の人工取得。
    """
    c=np.asarray(cases,dtype=np.int32)
    flags=np.full(len(c),old,dtype=np.bool_) if type(old) is bool else np.asarray(old,dtype=np.bool_)
    return Selection(c,(c%2).astype(np.int8),np.arange(len(c),dtype=np.int32),np.zeros(len(c),dtype=np.int8),flags)


def main() -> None:
    """
    機能: 固定幅・取得別幅と各25指標を独立ループで全件検査する。
    引数: なし。自然金融・候補結果は読まない。
    返り値: None。人工票JSONを保存する。
    """
    before={str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'work/163入口と任意幅/評価163.py',ROOT/'work/163入口と任意幅/広く評価する.py',Path(__file__))}
    context=fixture();rng=np.random.default_rng(31163)
    selections={'空政策':selection([]),'前48最後':selection([47]),'後25最初':selection([48]),
        '一場集中':selection([0,73,146],[False,True,False]),'全73純新規':selection(list(range(73))),
        '全73旧参照':selection(list(range(73)),True),'前48だけ':selection(list(range(48))),
        '後25だけ':selection(list(range(48,73))),
        '全219混合':selection(list(range(219)),[i%3==0 for i in range(219)])}
    for i in range(12):
        c=rng.choice(219,size=int(rng.integers(1,219)),replace=False).tolist()
        selections['不均等無作為'+str(i)]=selection(c,rng.random(len(c))>.65)
    cells=0;groups=[];largest=0.0
    for name,selected in selections.items():
        settings=[0,1,2,rng.integers(0,3,size=len(selected.cases),dtype=np.int8)]
        for widths in settings:
            got=S.summary_cube(context,selected,widths);wanted=independent(context,selected,widths)
            assert np.allclose(got,wanted,equal_nan=True,rtol=1e-12,atol=1e-9),(name,widths,np.argwhere(~np.isclose(got,wanted,equal_nan=True)))
            finite=np.isfinite(got)&np.isfinite(wanted)
            largest=max(largest,float(np.max(np.abs(got[finite]-wanted[finite]),initial=0)))
            cells+=got.size
        for wi in range(3):
            assert np.array_equal(S.summary_cube(context,selected,wi),S.summary_cube(context,selected,np.full(len(selected.cases),wi,dtype=np.int8)),equal_nan=True)
        groups.append(name)
    # ----------------------------------------
    # 未知金額と時計を汚染しても、known旗による統計が変化しないことを検査する。
    chosen=selections['全219混合'];base=S.summary_cube(context,chosen,1)
    context.arrays['net'][~context.arrays['known']]=123456789
    context.arrays['exit_time'][~context.arrays['known']]=-123456789.0
    poisoned=S.summary_cube(context,chosen,1);assert np.array_equal(base,poisoned,equal_nan=True)
    assert np.allclose(poisoned,independent(context,chosen,1),equal_nan=True,rtol=1e-12,atol=1e-9)
    # ----------------------------------------
    # 0円既知を実現勝率の分母へ含める。
    zeros=np.flatnonzero((context.arrays['known'][:,0,0,0])&(context.arrays['net'][:,0,0,0]==0))
    if len(zeros):
        z=selection([int(zeros[0])]);z.sides[:]=0
        cube=S.summary_cube(context,z,0);fi={n:i for i,n in enumerate(S.FIELDS)}
        assert cube[0,0,fi['known']]==1 and cube[0,0,fi['wins']]==0 and cube[0,0,fi['loss_trades']]==0 and cube[0,0,fi['realized_win_rate']]==0
    assert all(sha(ROOT/p)==v for p,v in before.items())
    proof={'成功':True,'自然データなし':True,'独立実装':'1取得・1期限・1期間ずつのPython算術。Root集計関数は期待値に使用しない。',
        'Source':before,'人工選択群':groups,'固定幅3種と取得別幅':'全選択で25指標×4期限×3期間',
        '照合セル':cells,'最大絶対差':largest,'固定幅と同値percase幅':True,
        '未知金額と時計の汚染で不変':True,'0円既知の実現勝率分母':bool(len(zeros)),
        '全73新規と旧参照の場数':True,'47と48の期間境界':True}
    HERE.mkdir(exist_ok=True);(HERE/'summary人工確認.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
