# q0履歴を使う別版・163用の準備

2026-11-14。初版972規則のSourceを変更せず、`rules162_stateful.py`と`履歴候補辞書.json`に六群488規則を追加した。Root方針により、固定済み162は初版972を実行し、履歴488は次163で初版と合わせ1460規則として比較する。準備と自然検証を混同しない。

|群|規則数|役割|
|---|---:|---|
|SB|96|過去BBσの圧縮と現在の再拡大edge＋背景/実体/Hist/RSI/量|
|BR|72|当時BB位置の端から内へのクロス＋旧方向失速/実体/動力/量|
|IR|48|Impulse近似の短期反対→許可、長短衝突禁止＋別構造/量trigger|
|SP|144|RSIの実時間持続と過大増分除外＋長中期方向/Hist/量|
|SF|64|反対側のRSI急変後に現在は回復＋BB位置/Hist/実体/量|
|HP|64|Hist増分の実時間持続＋RSI急変除外/長中期方向/ADX/量|

## 時計と未知

同一セッション・限月のq0価格時刻、原行index/source_lineを順序として使う。180秒を超える間隔で履歴をresetする。US開始の帯境界では強制reset/再発火しない。場ごとの時間/原行後退は拒否する。

ローリングは実時間10/20/30/60分を使う。窓の80%以上に相当する時間の被覆と、`max(3, 分数//2)`個以上の異なる価格秒を必要とする。窓内の必要値はすべてknownとし、NaNや欠落を0/前値で代用しない。同価格秒の複数原行は時間支持の数を水増ししない。

BB圧縮/拡大の過去基準と反対RSI急変窓は現在行を除外する。RSI/Hist持続と過大増分除外は現在行を含む。クロス/releaseの前値は同じ有効区間の直前q0であり、場境界/長い間隔後の先頭では未知とする。

## API

```python
from rules162_stateful import StatefulEvaluator, candidate_catalog, manifest

evaluator = StatefulEvaluator(
    buy_X, sell_X, columns, target_points=250,
    q0_meta=features.q0_meta,
)
for result in evaluator.iter_decisions():
    pass
```

返り値は初版と同じcandidate_id/directions/conflicts/unknown_buy/unknown_sell/buy_pass/sell_pass/target_points。q0_metaはsession/contract/q0_time/q0_index/q0_lineを要する。教師、取得q1、先着、金融を引数に取らない。

## 原法と研究派生の違い

BB復帰は各q0当時のdynamicσ座標のクロスであり、固定した以前のバンド価格を再取得したことを意味しない。BB圧縮は過去σmin/max、拡大は現在σ/過去minの上抜けで、中心価格を分母とする厳密なbandwidthではない。

Impulseは既存EMA21の傾きとMACD Hist増分による近似で、原法EMA13の再現ではない。現在の短期・長期が反対色ならその側を禁止し、短期反対から中立/同方向へ変わり長期も許可するとき、別の構造と量のtriggerを重ねる。これはElderのフィルタとしての使い方を参考にした派生である。Root調査の原典：[Elder公式マニュアル](https://s3-us-west-2.amazonaws.com/elderdownload/wp/wp-content/uploads/20180906134024/Elder-disk-for-TradeStation-v4.1.pdf)、2026-11-14確認。

RSI持続はq0で公表されていたRSI値の時間持続で、確定5分足の異なる本数へ勝手に換算しない。BB端とオシレーターの組合せも価格回復を確認し、接触だけで反転を確定しない。Root調査の原典：[Bollinger本人のCMT講演](https://cmtassociation.org/wp-content/uploads/2024/01/Bollinger-Trading-Bands-1.pdf)、2026-11-14確認。候補の利益を原典が証明したわけではない。

## 人工検査と停止

全488規則×101人工q0の49,288行で買売鏡像、32,208行で未来への毒入れ後の過去不変を確認。21履歴派生、BB圧縮/再拡大、BB復帰、Impulse解除、RSI持続/spike、180秒超reset、場境界、80%被覆、窓内NaN、後退時計拒否を確認した。自然X・取得・金融は未読。

`履歴人工検査結果.json`がSource/辞書の停止SHA。別担当の静的レビューでも時計・実側対称性・原法との差の表記に不整合指摘なし。自然検証ではない。Sourceを変更する場合はRootへ先に連絡し、新版又は新試行とする。
