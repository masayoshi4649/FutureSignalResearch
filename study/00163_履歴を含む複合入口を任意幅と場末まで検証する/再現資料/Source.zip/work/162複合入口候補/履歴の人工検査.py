"""q0履歴だけの候補を人工時系列で検査する。"""
from pathlib import Path
from collections import Counter
import hashlib
import json

import numpy as np
from rules162_stateful import StatefulEvaluator,candidate_catalog,manifest

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent


def main() -> None:
    """
    機能: 過去窓、場境界、欠測、鏡像、未来毒入れを人工時系列だけで確認する。
    引数: なし。正式100列定義の列名だけを利用する。
    返り値: None。別版辞書と人工成功票を保存する。
    """
    columns=json.loads((ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json').read_text(encoding='utf-8'))
    names=[c['name'] for c in columns];index={n:i for i,n in enumerate(names)}
    n=101;buy=np.zeros((n,100));sell=np.zeros((n,100))
    for name in names:
        if name.endswith('_to_side'):buy[:,index[name]]=1;sell[:,index[name]]=-1
    for x in (buy,sell):
        x[:,index['q0_spread_points']]=5
        x[:,index['m1_volume_relative_prior3']]=2
        x[:,index['m15_adx']]=20
        x[:,index['bb15_width_atr_ratio']]=4
        x[:,index['q0_last_minus_m1_close_atr5_to_side']]=0
        x[:,index['bb15_sigma']]=np.repeat((10,5,6,8,9),(20,20,20,20,21))
    buy[:,index['m5_rsi_center_to_side']]=5;sell[:,index['m5_rsi_center_to_side']]=-5
    buy[:,index['bb15_position_sigma_to_side']]=-.5
    buy[49,index['bb15_position_sigma_to_side']]=-2.5
    buy[50,index['bb15_position_sigma_to_side']]=-1.5
    buy[39,index['m5_ema21_delta_to_side']]=-1
    buy[39,index['m5_hist_delta_to_side']]=-1
    buy[30,index['m5_rsi_delta_to_side']]=-12
    metadata=[{'event_id':f'人工/{i}','session':'人工_Day','contract':'人工限月',
        'session_index':0,'q0_time':1000+i*60,'q0_index':i+1,'q0_line':i+2} for i in range(n)]
    evaluator=StatefulEvaluator(buy,sell,columns,250,q0_meta=metadata)
    rules=candidate_catalog();assert len(rules)==488
    assert evaluator.factor(0,'h_bb_expand_edge_30_1.1')[0][40]==1
    assert evaluator.factor(0,'h_bb_prior_contract_30')[0][40]==.5
    assert evaluator.factor(0,'h_bb_reentry_2')[0][50]==1
    assert evaluator.factor(0,'h_impulse_release_15')[0][40]==1
    assert evaluator.factor(0,'h_rsi_min_10')[0][50]==5
    assert evaluator.factor(0,'h_rsi_absdelta_max_10')[0][35]==12
    assert evaluator.factor(0,'h_rsi_delta_min_10')[0][31]==-12
    # ----------------------------------------
    mirror=StatefulEvaluator(sell,buy,columns,250,q0_meta=metadata)
    poison_buy=buy.copy();poison_sell=sell.copy();cut=66
    poison_buy[cut:]=777;poison_sell[cut:]=-777
    poisoned=StatefulEvaluator(poison_buy,poison_sell,columns,250,q0_meta=metadata)
    all_factors=sorted({t['factor'] for rule in rules for t in rule['conditions'] if t['factor'].startswith('h_')})
    for factor in all_factors:
        for side in (0,1):
            a,ka=evaluator.factor(side,factor);b,kb=poisoned.factor(side,factor)
            assert np.array_equal(ka[:cut],kb[:cut])
            assert np.allclose(a[:cut],b[:cut],equal_nan=True)
    for rule in rules:
        a=evaluator.evaluate_one(rule);b=mirror.evaluate_one(rule);c=poisoned.evaluate_one(rule)
        assert np.array_equal(a['directions'],-b['directions'])
        assert np.array_equal(a['unknown_buy'],b['unknown_sell'])
        assert np.array_equal(a['directions'][:cut],c['directions'][:cut])
        assert np.array_equal(a['conflicts'][:cut],c['conflicts'][:cut])
    # ----------------------------------------
    gap=[dict(r) for r in metadata]
    for r in gap[70:]:r['q0_time']+=240
    reset=StatefulEvaluator(buy,sell,columns,250,q0_meta=gap)
    assert len(reset._segments)==2
    assert not reset.factor(0,'h_bb_reentry_2')[1][70]
    assert not reset.factor(0,'h_rsi_min_10')[1][77]
    assert reset.factor(0,'h_rsi_min_10')[1][78]
    boundary=[dict(r) for r in metadata]
    for r in boundary[70:]:r['session']='人工_Night';r['session_index']=1
    changed=StatefulEvaluator(buy,sell,columns,250,q0_meta=boundary)
    assert not changed.factor(0,'h_impulse_release_15')[1][70]
    missing=buy.copy();missing[45,index['m5_rsi_center_to_side']]=np.nan
    incomplete=StatefulEvaluator(missing,sell,columns,250,q0_meta=metadata)
    assert not incomplete.factor(0,'h_rsi_min_10')[1][50]
    assert incomplete.factor(0,'h_rsi_min_10')[1][56]
    bad=[dict(r) for r in metadata];bad[40]['q0_time']=bad[38]['q0_time']
    try:StatefulEvaluator(buy,sell,columns,250,q0_meta=bad)
    except AssertionError:pass
    else:raise AssertionError('後退時計を受理')
    # ----------------------------------------
    destination=HERE/'履歴候補辞書.json'
    destination.write_text(json.dumps(manifest(),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    proof={'成功':True,'自然X読取':False,'取得と金融読取':False,'候補数':len(rules),
        '群別数':dict(Counter(r['group'] for r in rules)),'鏡像比較行':len(rules)*n,
        '未来毒入れ比較行':len(rules)*cut,'履歴派生種類':len(all_factors),
        '確認':['BB圧縮後の拡大edge','BB端から内への当時位置クロス','Impulse反対から許可への解除',
            'RSI持続とspike区別','未来値の変更は過去不変','180秒超でreset','場境界reset',
            '80%時間被覆','窓内NaNを0化しない','後退時計拒否'],
        'SHA256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in
            (HERE/'rules162.py',HERE/'rules162_stateful.py',Path(__file__),destination)}}
    (HERE/'履歴人工検査結果.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(proof,ensure_ascii=False))


if __name__=='__main__':
    main()
