"""新規履歴条件と任意幅の比較を次試行として固定する。"""
from pathlib import Path
import hashlib
import json
import shutil

ROOT=Path(__file__).resolve().parents[2]
TRIAL=ROOT/'study/00163_履歴を含む複合入口を任意幅と場末まで検証する'


def file_ref(path: Path) -> dict:
    """
    機能: 共有Source又は固定辞書の由来を指紋化する。
    引数: path(Path)は参照。
    返り値: dictは相対path/bytes/SHA256。
    """
    return {'path':path.relative_to(ROOT).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


def main() -> None:
    """
    機能: 12幅・4時計・1460規則とATR幅の探索を自然Raw再観測前に固定する。
    引数: なし。
    返り値: None。正式163条件と未実行README、観測設定を保存する。
    """
    assert not TRIAL.exists()
    assert max(int(p.name[:5]) for p in (ROOT/'study').iterdir() if p.is_dir() and p.name[:5].isdigit())==162
    config_path=ROOT/'work/163任意幅Raw索引/観測条件の雛形.json'
    config=json.loads(config_path.read_text(encoding='utf-8'))
    sources={name:file_ref(ROOT/'work/162複合入口候補'/name) for name in
        ('rules162.py','rules162_stateful.py','候補辞書.json','履歴候補辞書.json')}
    book={'trial':163,'date':'2026-11-14','name':'履歴を含む複合入口を任意幅と場末まで検証する',
        'hypothesis':'固定値幅125/200に限らず、構造と勢いの複合入口・持続/再加速の履歴を、複数の対称値幅とセッション内期限で比較する。',
        'widths':config['widths'],'horizons':config['horizons'],'observation_config':file_ref(config_path),
        'candidate_count':1460,'static_count':972,'stateful_count':488,'candidate_sources':sources,
        'raw_source_stop':file_ref(ROOT/'work/163任意幅Raw索引/Raw部品の停止.json'),
        'fixed_inputs':{'path':'inputs/00148_全1分入口母集団/固定取得入力.json.gz','sha256':'99f10a996ca6e8b6c428061f1b48624bbc479ec84c500a9633818d47e4298e2a'},
        'population':'旧全73場31642case/実2側、全35339q0。既存取得母集団を変えず新Raw索引で再観測。',
        'new_width_contract':'H30/H60の125/200を旧148へ全件照合。H120は厳密期限・場末未到達C。SESSIONは境界観測あり・終端直前正常BBO鮮度30秒以内、touchはend-300未満。',
        'entry_modes':['ALL','EDGE'],'episode':'162と同じ0/反対→当該方向、場/180秒超reset。時間帯境界による強制再武装なし。',
        'integration':['N','U','F'],'legacy':'162と同じ旧全87U/初参加だけFの因果時計と旧優先。純新規の全場参加とは分ける。',
        'timeband':'判断q0はDAY/NY09:30前/以後DST変換。取得q1帯も別報告。各帯強制参加なし。',
        'adaptive_widths':{'multipliers_atr5':[2,3,4,6,8],
            'grid':[150,175,200,225,250,300,350,400,500,750,1000],
            'choice':'当時m5_atr*k以上の最小grid、1000を超えるなら1000。未知/非正ATRは新規待機。',
            'geometry':'選んだwのq0 BB余地等で候補を評価し、同case最初成立q0のwを決済まで固定。',
            'legacy_fallback_width':200},
        'prior_discovery_anchors':['MP0057','MP0058','MP0081','MP0082'],
        'anchors_status':'162の全期探索で発見した既使用由来の候補。主に勢い持続/ADX/RSI/相対量。未見選定ではない。',
        'selection_goal':'新条件が全73場最低1・同幅先着70%超・十分な頻度を持つか、利益/損失・前後/三帯/支持/集中とともに検証。',
        'screen':'全辞書の発見用探索。全期bestは採用済み/未見性能と呼ばない。近傍条件・複数幅・対照・必要な盲検で確認する。',
        'cost':{'point_yen':100,'fee_round_trip':77,'additional_round_trip_slippage_yen':1000},
        'account':'独立1mini入口品質。良候補は片側10枚上限等の実行可能性を別検査し、独立合算を口座収支と呼ばない。',
        'holdout':'11/10Night/11/11Dayは163探索へ使わない。旧156未実行。',
        'continuous_pdca':'本試行が未達でも原因を調べ別仮説へ進む。成果物整形だけで探索を打ち切らない。'}
    TRIAL.mkdir();(TRIAL/'検査').mkdir()
    target=TRIAL/'条件.json';target.write_text(json.dumps(book,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    shutil.copyfile(config_path,TRIAL/'観測条件.json')
    (TRIAL/'README.md').write_text('# 00163 履歴を含む複合入口を任意幅と場末まで検証する\n\n2026-11-14。自然再観測前に[条件](条件.json)・[観測条件](観測条件.json)を固定。1460条件、125対照＋150～1000pt、H30/H60/H120/SESSIONを比較する。現在未実行。旧試行を書き換えず、162の発見と過去選択の不調の両方を踏まえて進む。\n',encoding='utf-8')
    print(json.dumps({'条件SHA256':hashlib.sha256(target.read_bytes()).hexdigest(),'観測条件SHA256':hashlib.sha256((TRIAL/'観測条件.json').read_bytes()).hexdigest()},ensure_ascii=False))


if __name__=='__main__':
    main()
