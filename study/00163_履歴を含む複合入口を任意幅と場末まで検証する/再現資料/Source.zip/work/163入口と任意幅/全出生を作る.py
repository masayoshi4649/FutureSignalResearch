"""十二の対称幅について新規履歴条件を含む全q0判断を先に固定する。"""
from pathlib import Path
import json
import time
import numpy as np
from 共通163 import ROOT,HERE,TRIAL,BOOK_SHA,book,sha,read,save,module,data_module,libraries


def edge_directions(directions: np.ndarray, sessions: np.ndarray, times: np.ndarray) -> np.ndarray:
    """
    機能: 同じ技術条件への再遷移でだけ再武装し、180秒超/場で区切る。
    引数: directions(np.ndarray[int8])、sessions(np.ndarray[int])、times(np.ndarray[float])。
    返り値: np.ndarray[int8]は遷移出生だけの方向。
    """
    previous=np.r_[np.int8(0),directions[:-1]]
    reset=np.r_[True,(sessions[1:]!=sessions[:-1])|(times[1:]-times[:-1]>180)]
    return np.where((directions!=previous)|reset,directions,0).astype(np.int8)


def main() -> None:
    """
    機能: 金融を受けない1460複合規則の全幅×q0を圧縮保存する。
    引数: なし。固定163条件・当時100Xとq0履歴だけを使用する。
    返り値: None。幅に依存しない履歴cacheを同じX内だけで再用する。
    """
    setting=book();out=HERE/'全出生';assert not out.exists()
    sources=[Path(__file__),HERE/'共通163.py',ROOT/'work/162入口探索/共通.py',
        ROOT/'work/162複合入口候補/rules162.py',ROOT/'work/162複合入口候補/rules162_stateful.py']
    before={str(p.relative_to(ROOT)):sha(p) for p in sources}
    save(TRIAL/'検査/F1_全出生前.json',{'成功':True,'条件SHA256':BOOK_SHA,'Source':before,'金融未入力':True})
    _,history,registry=libraries();data=data_module();features=data.load_feature_dataset()
    columns,_=data.read_json_ref(data.FileRef(ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json',data.CATALOG_SHA256))
    sessions=np.array([q['session_index'] for q in features.q0_meta],dtype=np.int16)
    times=np.array([q['q0_time'] for q in features.q0_meta],dtype=np.float64)
    out.mkdir();counts=[];history_cache=None;begin=time.monotonic()
    for width in setting['widths']:
        evaluator=history.StatefulEvaluator(features.buy_X,features.sell_X,columns,target_points=width,q0_meta=features.q0_meta)
        if history_cache is not None:evaluator._history_cache=history_cache
        matrix=np.empty((len(registry),len(times)),dtype=np.int8);edges=np.empty_like(matrix)
        for i,decision in enumerate(evaluator.iter_decisions(registry)):
            assert decision['candidate_id']==registry[i]['id']
            matrix[i]=decision['directions'];edges[i]=edge_directions(matrix[i],sessions,times)
            counts.append({'rule':registry[i]['id'],'width':width,'ALL':int(np.count_nonzero(matrix[i])),
                'EDGE':int(np.count_nonzero(edges[i])),'conflict':int(decision['conflicts'].sum()),
                'unknown_buy':int(decision['unknown_buy'].sum()),'unknown_sell':int(decision['unknown_sell'].sum())})
        history_cache=evaluator._history_cache
        np.savez_compressed(out/f'出生{width}.npz',ALL=matrix,EDGE=edges)
        print(json.dumps({'出生確定幅':width,'規則数':len(registry),'経過秒':round(time.monotonic()-begin)},ensure_ascii=False),flush=True)
    assert all(sha(ROOT/p)==v for p,v in before.items())
    save(out/'全出生の確認.json',{'成功':True,'条件SHA256':BOOK_SHA,'金融未入力':True,'Source':before,
        '規則順':[r['id'] for r in registry],'counts':counts,'特徴入力':features.sources,
        '履歴cache':'同一X/q0のraw列の時間窓だけ共有。幅依存の比較cacheは幅ごと新規。',
        'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()}})


if __name__=='__main__':
    main()
