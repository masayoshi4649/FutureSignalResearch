"""1460複合入口を十二幅・四期限で高速に探索する。"""
from pathlib import Path
import json
import time
import numpy as np
from 共通163 import ROOT,HERE,TRIAL,BOOK_SHA,book,read,save,sha,data_module,libraries
from 評価163 import Context163,summary_cube,materialize,link_variable,FIELDS,PERIODS,INTEGRATIONS,ENTRY_MODES


def edge(directions: np.ndarray, scenes: np.ndarray, times: np.ndarray) -> np.ndarray:
    """
    機能: 適応幅で統合した条件の後にEDGEを計算し、幅変更だけで再発火させない。
    引数: directions(np.ndarray[int8])、scenes(np.ndarray[int])、times(np.ndarray[float])。
    返り値: np.ndarray[int8]は当時の再遷移だけの出生。
    """
    previous=np.r_[np.int8(0),directions[:-1]]
    reset=np.r_[True,(scenes[1:]!=scenes[:-1])|(times[1:]-times[:-1]>180)]
    return np.where((previous!=directions)|reset,directions,0).astype(np.int8)


def fixed_selection(context: Context163, proof: dict, width: int, rule_index: int, mode: str) -> object:
    """
    機能: 圧縮出生正本から一候補を再現し取得へ結ぶ。
    引数: context(Context163)、proof(dict)、width/rule_index(int)、mode(str)。
    返り値: Selectionは純新規の実取得。
    """
    path=HERE/'全出生'/f'出生{width}.npz';assert sha(path)==proof['files'][path.name]['sha256']
    with np.load(path,allow_pickle=False) as source:
        direction=source[mode][rule_index].copy()
    return context.link(direction)


# ----------------------------------------
def main() -> None:
    """
    機能: 全出生固定後、42万固定政策とATR適応幅を同一入力で比較する。
    引数: なし。163固定条件・数値金融・全出生を利用する。
    返り値: None。統計NPZと発見上位だけの小型JSONを保存する。
    """
    setting=book();out=HERE/'広い評価';assert not out.exists()
    proof=read(HERE/'全出生/全出生の確認.json');assert proof['成功'] and proof['金融未入力']
    paths=[Path(__file__),HERE/'評価163.py',HERE/'共通163.py',ROOT/'work/162入口探索/評価基盤.py',
        ROOT/'work/163任意幅の数値化/arrays163.py',HERE/'全出生/全出生の確認.json']
    before={p.relative_to(ROOT).as_posix():sha(p) for p in paths}
    save(TRIAL/'検査/F2_任意幅探索前.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと全出生':before,
        '全期探索は発見用':True,'適応幅対象':'162事前発見4anchorのみ。全1460へ追加探索しない。',
        '上位報告基準':'200取得/100到達/新100取得/全73場/到達済み70%/前後既知黒字。頻度と集中は別比較。'})
    registry_ids=proof['規則順'];assert len(registry_ids)==1460
    anchors=setting['prior_discovery_anchors'];anchor_indices=[registry_ids.index(r) for r in anchors]
    # ----------------------------------------
    # 適応幅の判断は当時ATRと固定済み出生だけで先に封印する。
    data=data_module();features=data.load_feature_dataset();column=features.columns.index('m5_atr')
    atr=features.buy_X[:,column];other=features.sell_X[:,column]
    assert np.array_equal(atr,other,equal_nan=True)
    grid=np.array(setting['adaptive_widths']['grid']);widths=np.array(setting['widths'])
    multipliers=setting['adaptive_widths']['multipliers_atr5']
    event_widths=[];adaptive=np.zeros((len(multipliers),len(anchors),len(atr)),dtype=np.int8)
    for multiplier in multipliers:
        target=atr*multiplier
        chosen=grid[np.minimum(np.searchsorted(grid,target,side='left'),len(grid)-1)]
        indices=np.searchsorted(widths,chosen).astype(np.int8)
        indices[~np.isfinite(atr)|(atr<=0)]=-1;event_widths.append(indices)
    for wi,width in enumerate(widths):
        path=HERE/'全出生'/f'出生{width}.npz';assert sha(path)==proof['files'][path.name]['sha256']
        with np.load(path,allow_pickle=False) as source:
            anchor_matrix=source['ALL'][anchor_indices].copy()
        for ki,width_index in enumerate(event_widths):
            mask=width_index==wi
            adaptive[ki][:,mask]=anchor_matrix[:,mask]
    scenes=np.array([q['session_index'] for q in features.q0_meta]);times=np.array([q['q0_time'] for q in features.q0_meta])
    adaptive_edges=np.empty_like(adaptive)
    for ki in range(len(multipliers)):
        for ai in range(len(anchors)):adaptive_edges[ki,ai]=edge(adaptive[ki,ai],scenes,times)
    out.mkdir();np.savez_compressed(out/'ATR適応幅の出生.npz',ALL=adaptive,EDGE=adaptive_edges,event_widths=np.stack(event_widths))
    save(out/'ATR適応出生の封印.json',{'成功':True,'幅選択と出生へ金融未入力':True,
        'anchors':anchors,'multipliers':multipliers,'files':{'ATR適応幅の出生.npz':sha(out/'ATR適応幅の出生.npz')}})
    del features,anchor_matrix
    # ----------------------------------------
    context=Context163();begin=time.monotonic()
    nr=len(registry_ids);nw=len(widths);nh=len(context.table.horizons)
    metrics=np.full((nr,2,nw,nh,3,3,len(FIELDS)),np.nan)
    old=context.old_controls();old_names=list(old)
    old_metrics=np.full((len(old),nw,nh,3,len(FIELDS)),np.nan)
    for wi,width in enumerate(widths):
        path=HERE/'全出生'/f'出生{width}.npz'
        assert sha(path)==proof['files'][path.name]['sha256']
        with np.load(path,allow_pickle=False) as source:
            matrices={mode:source[mode].copy() for mode in ENTRY_MODES}
        for mi,mode in enumerate(ENTRY_MODES):
            for ri,rule in enumerate(registry_ids):
                new=context.link(matrices[mode][ri])
                for ii,integration in enumerate(INTEGRATIONS):
                    selected=context.integrate(new,integration)
                    metrics[ri,mi,wi,:,ii]=summary_cube(context,selected,wi)
        for oi,selected in enumerate(old.values()):old_metrics[oi,wi]=summary_cube(context,selected,wi)
        print(json.dumps({'評価済幅':int(width),'全幅':nw,'候補数':nr,'経過秒':round(time.monotonic()-begin)},ensure_ascii=False),flush=True)
    adaptive_metrics=np.full((len(anchors),2,len(multipliers),nh,3,3,len(FIELDS)),np.nan)
    for ki,multiplier in enumerate(multipliers):
        for ai,rule in enumerate(anchors):
            for mi,mode in enumerate(ENTRY_MODES):
                direction=adaptive[ki,ai] if mode=='ALL' else adaptive_edges[ki,ai]
                for integration,(selected,per_case_width) in link_variable(context,direction,event_widths[ki]).items():
                    ii=INTEGRATIONS.index(integration)
                    adaptive_metrics[ai,mi,ki,:,ii]=summary_cube(context,selected,per_case_width)
    np.savez_compressed(out/'全探索の統計配列.npz',fixed=metrics,adaptive=adaptive_metrics,controls=old_metrics)
    save(out/'統計軸.json',{'成功':True,'trial':163,'規則順':registry_ids,'発火方式':ENTRY_MODES,'幅':widths.tolist(),
        '時計':context.table.horizons,'統合':INTEGRATIONS,'期間':PERIODS,'指標':FIELDS,'旧対照順':old_names,
        'fixed_shape':list(metrics.shape),'adaptive_shape':list(adaptive_metrics.shape),
        '適応anchor':anchors,'適応ATR倍率':multipliers,'未知':'率/平均未定義はNaN。金融未知はknown旗とunknown列を保持。',
        '数値表入力':context.array_sources})
    # ----------------------------------------
    # 発見候補だけを抽出する。全期上位を未見実績又は自動採用へ読み替えない。
    columns={name:i for i,name in enumerate(FIELDS)}
    def promising(array: np.ndarray) -> np.ndarray:
        """
        機能: 事前に固定した報告支持・全場・率・前後収支で発見候補を抽出する。
        引数: array(np.ndarray)は任意候補軸×三期間×全指標。
        返り値: np.ndarray[bool]は候補軸と同shapeのmask。
        """
        full=array[...,0,:]
        return (full[...,columns['count']]>=200)&(full[...,columns['F']]+full[...,columns['A']]>=100)&\
            (full[...,columns['new_count']]>=100)&(full[...,columns['all_scenes']]==1)&\
            (full[...,columns['rate']]>=.7)&(array[...,1,columns['net']]>0)&(array[...,2,columns['net']]>0)
    positions=np.argwhere(promising(metrics));adaptive_positions=np.argwhere(promising(adaptive_metrics))
    def ranking(position: np.ndarray,array: np.ndarray) -> tuple:
        """
        機能: 同幅の一位だけを選ばず頻度・率の順で表示順位を作る。
        引数: position(np.ndarray[int])、array(np.ndarray)は統計位置と表。
        返り値: tupleは頻度降順/率降順のキー。
        """
        row=array[tuple(position)][0]
        return -row[columns['count']],-row[columns['rate']]
    positions=sorted(positions,key=lambda p:ranking(p,metrics))
    adaptive_positions=sorted(adaptive_positions,key=lambda p:ranking(p,adaptive_metrics))
    found=[]
    for position in positions[:160]:
        ri,mi,wi,hi,ii=map(int,position)
        found.append({'kind':'固定幅','rule':registry_ids[ri],'entry_mode':ENTRY_MODES[mi],
            'width':int(widths[wi]),'horizon':context.table.horizons[hi],'integration':INTEGRATIONS[ii],
            'position':position.tolist(),'periods':materialize(metrics[ri,mi,wi,hi,ii])})
    adapted=[]
    for position in adaptive_positions[:80]:
        ai,mi,ki,hi,ii=map(int,position)
        adapted.append({'kind':'ATR適応幅','rule':anchors[ai],'entry_mode':ENTRY_MODES[mi],
            'multiplier':multipliers[ki],'horizon':context.table.horizons[hi],'integration':INTEGRATIONS[ii],
            'position':position.tolist(),'periods':materialize(adaptive_metrics[ai,mi,ki,hi,ii])})
    save(out/'有望な発見候補.json',{'成功':True,'全期探索で未採用':True,'固定政策数':nr*2*nw*nh*3,
        '適応政策数':len(anchors)*2*len(multipliers)*nh*3,'報告支持を満たす固定候補':len(positions),
        '報告支持を満たす適応候補':len(adaptive_positions),'fixed':found,'adaptive':adapted})
    assert all(sha(ROOT/p)==v for p,v in before.items())
    save(out/'完了.json',{'成功':True,'条件SHA256':BOOK_SHA,'Source':before,'経過秒':time.monotonic()-begin,
        'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()}})
    print(json.dumps({'成功':True,'有望固定':len(positions),'有望適応':len(adaptive_positions),'上位':found[:5],'適応上位':adapted[:3]},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
