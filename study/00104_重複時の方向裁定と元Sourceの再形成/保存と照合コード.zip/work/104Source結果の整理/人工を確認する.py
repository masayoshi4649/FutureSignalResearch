"""実Go型の手製codecだけで保存集計を確認する。市場結果は読まない。"""

import argparse
import copy
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path


def main():
    """
    機能: Go型人工の全6book/鏡像/半円と保存破損拒否を確認する。
    引数: --out(Path)は新規確認JSON。
    返り値: None。Source/金融engine/実Nativeを呼ばない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location("SourceA型人工", root / "SourceAを整理する.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    fixture = module.load(root / "Go型人工.json")
    count = 0
    for value in fixture["values"]:
        checked = module.inspect_scene(value, value["session"])
        count += len(checked)
        for key, row in checked.items():
            expected = 1769 if key.startswith("mini_") else 1340
            module.need(row["totals"]["gross"] == 5000 and row["totals"]["net"] == expected, "型人工の手計算額")
            side = "-1" if "U165_03" in key else "1"
            module.need(row["direction"][side]["close_notices"] == 2 and row["direction"][side]["new_fills"] == 1 and row["direction"][side]["close_fills"] == 2, "型人工の返済方向")
    good = fixture["values"][0]["books"]["mini_D164_15"]
    rejected = []
    for name in ("未完結", "予約残", "Hold残", "費用半円", "粗額", "商品点価", "返済側", "重複約定", "Target所有", "数量真偽値"):
        b = copy.deepcopy(good)
        if name == "未完結": b["complete"] = False
        elif name == "予約残": b["pending"] = [b["signals"][0]["signal"]]
        elif name == "Hold残": b["holds"][0]["quantity"] = 1
        elif name == "費用半円": b["fills"][0]["fee_yen"] += Decimal("0.5")
        elif name == "粗額": b["fills"][1]["gross_yen"] += 1000
        elif name == "商品点価": b["config"]["point_value"] = 10
        elif name == "返済側": b["fills"][1]["side"] *= -1
        elif name == "重複約定": b["fills"][1]["fill"]["ExecutionID"] = b["fills"][0]["fill"]["ExecutionID"]
        elif name == "Target所有": b["signals"][1]["signal"]["targets"][0]["id"] = "番号で推定しない他人玉"
        elif name == "数量真偽値": b["fills"][0]["fill"]["Quantity"] = True
        try:
            module.verify_book(b, "mini_D164_15", good["session"]["id"])
        except (ValueError, KeyError):
            rejected.append(name)
        else:
            raise AssertionError("破損を成功化:" + name)
    a, b = good["signals"], copy.deepcopy(good["signals"])
    b[0]["signal"]["id"] = "別番号"
    difference = module.first_difference(a, b)
    module.need(difference["path"].endswith("/signal/id"), "番号で同一玉とみなした")
    module.need(len(module.expected_ids("full54")) == 54 and module.expected_ids("first2") == ["2026-09-21_Day", "2026-09-21_Night"], "母集合")
    digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
    result = {"成功": True, "scope": fixture["scope"], "Go型book": count, "部分返済と半円": True, "売買方向の戻し": True, "破損拒否": rejected, "ID同一推定なし": difference, "実Native/Raw/CSV読取": 0, "Source/金融engine実行": 0, "codeSHA256": digest(root / "SourceAを整理する.py"), "Go型JSON_SHA256": digest(root / "Go型人工.json")}
    with args.out.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "Go型book": count, "拒否": len(rejected)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
