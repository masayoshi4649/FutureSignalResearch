package main

import (
	"encoding/json"
	"fmt"
	"os"

	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	replay "github.com/masayoshi4649/SessionTradeExecuter/minisourcereplay104"
)

// quote はSource未運転の型人工に使う気配を返します。
//
// 引数: i(int)、move(float64)、side(int)は原行番号/価格移動/鏡像です。
// 返り値: native.QuoteStampは有限の人工気配です。
func quote(i int, move float64, side int) native.QuoteStamp {
	bid, ask := 50000+move, 50010+move
	if side < 0 {
		bid, ask = 100000-ask, 100000-bid
	}
	return native.QuoteStamp{Time: 2000 + float64(i), Index: int64(i), SourceLine: int64(10 + i), Last: (bid + ask) / 2, Bid: bid, Ask: ask, QuoteOK: true}
}

// book は手製Signal/Fill/配賦を実Go型へ格納するだけです。
//
// 引数: session(native.Session)、method/product(string)、side(int)は場/手法/商品/鏡像です。
// 返り値: native.Ledgerは部分1+2又は10+20を閉じたcodec人工です。Source/金融engineは実行しません。
func book(session native.Session, method, product string, side int) native.Ledger {
	cfg := native.MiniConfig()
	scale := 1
	if product == "micro" {
		cfg = native.MicroControlConfig()
		scale = 10
	}
	qty := 3 * scale
	q := []native.QuoteStamp{quote(0, 0, side), quote(1, 0, side), quote(2, 10, side), quote(3, 20, side), quote(4, 20, side), quote(5, 30, side)}
	entry := q[1].Ask
	if side < 0 {
		entry = q[1].Bid
	}
	id := "Source番号1"
	hold := "所有1"
	newSignal := native.Signal{ID: id, Owner: "codec", Action: "new", Side: side, Quantity: qty, Time: q[0].Time, SourceIndex: q[0].Index, Reason: "型人工"}
	signals := []native.SignalRecord{{Signal: newSignal, Origin: "quote", At: q[0].Time, Quote: q[0]}}
	fee := float64(qty) * cfg.FeeYenPerSide
	slip := float64(qty) * 5 * cfg.PointValue
	fills := []native.FillRecord{{Fill: native.Fill{SignalID: id, ExecutionID: "取得1", Quantity: qty, Price: entry, Time: q[1].Time, HoldID: hold, Fee: 0}, Action: "new", Side: side, Quote: q[1], FeeYen: fee, SlippageYen: slip, NetContributionYen: -fee - slip, Allocations: []native.CloseAllocation{}}}
	gross := 0.0
	for j, n := range []int{scale, 2 * scale} {
		request, exit := q[2+j*2], q[3+j*2]
		price := exit.Bid
		if side < 0 {
			price = exit.Ask
		}
		sid := fmt.Sprintf("返済%d", j)
		target := strategy.LotTarget{ID: hold, Quantity: n}
		sig := native.Signal{ID: sid, Owner: "codec", Action: "close", Side: -side, Quantity: n, Time: request.Time, SourceIndex: request.Index, Reason: "型人工部分", Targets: []strategy.LotTarget{target}}
		signals = append(signals, native.SignalRecord{Signal: sig, Origin: "quote", At: request.Time, Quote: request})
		g := float64(side) * (price - entry) * float64(n) * cfg.PointValue
		gross += g
		f := float64(n) * cfg.FeeYenPerSide
		sl := float64(n) * 5 * cfg.PointValue
		fills = append(fills, native.FillRecord{Fill: native.Fill{SignalID: sid, ExecutionID: sid + "約定", Quantity: n, Price: price, Time: exit.Time, Closed: []strategy.LotTarget{target}, Fee: 0}, Action: "close", Side: -side, Quote: exit, GrossYen: g, FeeYen: f, SlippageYen: sl, NetContributionYen: g - f - sl, Allocations: []native.CloseAllocation{{HoldID: hold, Quantity: n, EntryPrice: entry, ExitPrice: price, EntryQuote: q[1], ExitQuote: exit, GrossYen: g, EntryFeeYen: f, ExitFeeYen: f, EntrySlippageYen: sl, ExitSlippageYen: sl, NetYen: g - 2*f - 2*sl}}})
	}
	return native.Ledger{Method: "NK225_" + method, Session: session, Config: cfg, Signals: signals, Fills: fills, Cancellations: []native.Cancellation{}, Holds: []native.HoldLedger{{HoldID: hold, InternalID: "独立所有", EntryID: id, Side: side, InitialQuantity: qty, Quantity: 0, ClosedQuantity: qty, EntryPrice: entry, EntryQuote: q[1], GrossYen: gross, ClosedNetYen: gross - 2*fee - 2*slip}}, Pending: []native.Signal{}, Finished: true, Complete: true, Totals: native.LedgerTotals{EntryQuantity: qty, CloseQuantity: qty, GrossYen: gross, FeeYen: 2 * fee, SlippageYen: 2 * slip, GrossMinusFeeYen: gross - 2*fee, NetYen: gross - 2*fee - 2*slip, ClosedNetYen: gross - 2*fee - 2*slip}}
}

// main は手製の実Go型Marshalを新規先へ保存します。
//
// 引数: CLI第1引数は新規JSONです。
// 返り値: ありません。Source/Features/金融/Rawを呼びません。
func main() {
	if len(os.Args) != 2 {
		panic("新規JSON指定が必要")
	}
	rows := []replay.ReplayResult{}
	for _, kind := range []string{"Day", "Night"} {
		s := native.Session{ID: "2026-09-21_" + kind, Kind: kind, Start: 1000, End: 5000, ForceClose: 4400}
		r := replay.ReplayResult{Session: s.ID, Quality: map[string]replay.RawQuality{}, SourceRows: map[string]int{}, Books: map[string]native.Ledger{}}
		methods := []string{"D164_15"}
		if kind == "Night" {
			methods = []string{"P164_06", "U165_03"}
		}
		for _, product := range []string{"micro", "mini"} {
			for i, method := range methods {
				side := 1
				if i%2 == 1 {
					side = -1
				}
				key := product + "_" + method
				r.Books[key] = book(s, method, product, side)
				r.SourceRows[key] = 6
			}
		}
		rows = append(rows, r)
	}
	f, e := os.OpenFile(os.Args[1], os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		panic(e)
	}
	e = json.NewEncoder(f).Encode(map[string]any{"scope": "手製codecの実Go型Marshal。Source/金融engine実行0", "values": rows})
	if close := f.Close(); e == nil {
		e = close
	}
	if e != nil {
		panic(e)
	}
}
