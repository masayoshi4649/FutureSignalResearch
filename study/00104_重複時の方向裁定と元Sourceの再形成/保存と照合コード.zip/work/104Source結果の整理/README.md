# SourceA完成保存の小整理器

[SourceAを整理する.py](SourceAを整理する.py) は固定104 Source条件/成功完了FileRefに結び、完成結果だけを読む。Source/Features/金融/原板を再実行しない。StageAは連続Sourceの商品会計であり、後段BのB5Q/LD10後ではない。micro/miniの数量・点価・費用は別に扱う。

Root指定のSource条件SHAは `05b8275a5c1abb60aab3402c617f62d5583852dacacce48e2b831430223ea266`。実保存の読取はRootからfirst2/full54の成功通知を受けた段階だけ行う。現在はfirst2だけ許可・実接続済み。full54は実行禁止のまま待つ。

```powershell
& work/venvs/technical-tree/Scripts/python.exe -B -X utf8 `
 'work/104Source結果の整理/SourceAを整理する.py' `
 --condition 'study/00104_重複時の方向裁定と元Sourceの再形成/Source条件.json' `
 --condition-sha '05b8275a5c1abb60aab3402c617f62d5583852dacacce48e2b831430223ea266' `
 --completion 'work/104Source市場再生/先頭2場/完了.json' `
 --completion-sha '2dde982dc4c81ef45642ce110018657e5f7731317d6c01d053a4a28a1ef3dd3f' `
 --out '<別の新規出力dir>'
```

full54はRoot成功後にcompletionのpath/SHAとoutだけを替える。同じ固定条件、54ID×3mode=162case/486Sourcebookを予定する。first2は2ID×3=6case/18book。既存先は拒否する。

## 確認するもの

- 完了成功/同条件/元code・停止・binary・台帳参照、入力前後不変、正確なcase集合。
- 各result/圧縮recordsの現物SHAと、legacy/defaultの旧93場別JSON全文構造を再照合。ID/unknown field/配列順を捨てない。
- 全Ledgerの商品規格、完結、残玉/pending/未配賦費用0。保存Fill/Targets/配賦から数量・半円・gross/fee/slip/netを照合する。実保有側上限を確認するが歴史的pending込みcapの独立再演ではない。
- Signal/Fill/取消/close Targets件数を完了countsへ結合する。Closes数は元close Signal.Targetsと一致する件数を使う。大きいrecordsは圧縮SHAのみで、全原行の再査定/Closes.Before/最初正常行の原板検算はしない。
- directionは元新規方向。closeは注文Sideの反対、取消は元new Signalへ戻す。miniの粗額、指定手数料、別仮定5pt滑り、費用のみ後/滑り込み純額を日夜/方向に区分する。
- sym対legacyは全Signal/Fill/取消JSON配列の差有無と最初の葉の差だけを少量保存。SourceID番号だけで同一玉/取引を対応付けない。

通知が同じなら『公開通知への影響未観測』。SourceRecordは全Observation SHAで、range_sideのL/H実評価件数は未計測である。重複域が発生しなかった、自然Source全体が完全対称だった、という結論にはしない。未使用期間の安定収益やBの採用も未検証。機会損失/退出後仮想利益を扱わない。

## 型人工とfirst2

`人工型を保存する.go` は実Go公開型へ手製Signal/Fill/部分返済/半円を格納してMarshalするだけ。Source/金融engineは呼ばない。`Go型人工.json` の6bookを検算し、売買方向の戻し/部分返済/10破損拒否を `人工確認_最終.json` へ記録した。初回人工証拠も不変で保持。

Root許可後にfirst2を読む実接続は [先頭2場_最終/結果.json](先頭2場_最終/結果.json) / [要約.md](先頭2場_最終/要約.md)。6case/18book、legacy/default旧93全文4case一致、入力前後不変。最初の先頭2場出力から方向別の観測済み0件項目を明示列へ揃えた（損益変更なし）。3modeのSignal/Fill/取消JSON差はこの2場で0。L/H重複実評価件数は未計測であり、不発生とは解釈しない。

miniは各mode共通でDay粗額4000/fee154/slip2000/net1846、Night粗額−45000/fee385/slip5000/net−50385。全量は買い元方向で、Nightの実参加はU、Pは0。この2場の記述だけで仮説の有効性/全54結果としない。

本整理器は条件固定後に作成した事後保存検算で、Source実行条件へ遡って含めない。formal/Core/停止元は変更しない。full54はRootの別成功通知後に接続する。
