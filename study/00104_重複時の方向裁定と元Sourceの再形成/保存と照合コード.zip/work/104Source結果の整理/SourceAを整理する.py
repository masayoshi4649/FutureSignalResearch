"""SourceAの完成保存だけを検算し、連続Source会計の差を小型に整理する。"""

import argparse
from collections import Counter, defaultdict
from datetime import date, timedelta
from decimal import Decimal
import hashlib
import json
from pathlib import Path


CONDITION_SHA = "05b8275a5c1abb60aab3402c617f62d5583852dacacce48e2b831430223ea266"
MODES = ("legacy", "default", "symmetric")
MONEY = ("gross", "fee", "slip", "fee_only", "net")
ZERO = Decimal(0)


def need(ok, reason):
    """
    機能: 欠測や不成立を成功へ補完しない。
    引数: ok(bool)、reason(str)は条件と失敗理由。
    返り値: None。不成立時ValueError。
    """
    if not ok:
        raise ValueError(reason)


def number(value):
    """
    機能: 保存金額を半円含む有限Decimalで扱う。
    引数: value(int|Decimal|float)は型人工又は保存値。
    返り値: Decimalは有限値。
    """
    need(type(value) in (int, float, Decimal), "非数値/真偽値の混入")
    result = value if isinstance(value, Decimal) else Decimal(str(value))
    need(result.is_finite(), "非有限値")
    return result


def integer(value):
    """
    機能: 枚数や個数を整数型のまま検査する。
    引数: value(int)は保存数量。
    返り値: intは整数値。
    """
    need(type(value) is int, "数量/件数が整数型でない")
    return value


def digest(path):
    """
    機能: 固定metadata又は成功後の保存成果物をhashする。
    引数: path(Path)はRaw/CSV以外の明示FileRef。
    返り値: strはSHA256。
    """
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def load(path):
    """
    機能: 保存JSONをDecimalで読む。
    引数: path(Path)はRoot成功通知後に許可される保存物又は型人工。
    返り値: dictは保存全構造。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"), parse_float=Decimal)


def valid_sha(value):
    """
    機能: 空/不正SHAを拒否する。
    引数: value(str)は期待指紋。
    返り値: boolは小文字64桁のとき真。
    """
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def file_ref(ref, base, before):
    """
    機能: 指定FileRefを現物指紋へ結ぶ。
    引数: ref(dict)、base(Path)、before(dict)は参照・基準・前指紋。
    返り値: Pathは照合済み現物。Raw/CSVのFileRefには使わない。
    """
    need(set(ref) == {"path", "sha256"} and bool(ref["path"]) and valid_sha(ref["sha256"]), "FileRef未固定")
    path = Path(ref["path"])
    path = (path if path.is_absolute() else base / path).resolve()
    actual = digest(path)
    need(actual == ref["sha256"], "FileRef SHA差:" + str(path))
    need(str(path) not in before or before[str(path)] == actual, "同path別SHA")
    before[str(path)] = actual
    return path


def expected_ids(stage):
    """
    機能: 既使用54又は先頭2だけを対象集合にする。
    引数: stage(str)はfirst2/full54。
    返り値: list[str]は許可順ID。
    """
    need(stage in ("first2", "full54"), "stage不正")
    result, day = [], date(2026, 9, 21)
    while day <= date(2026, 10, 27):
        if day.weekday() < 5:
            result.extend((f"{day}_Day", f"{day}_Night"))
        day += timedelta(days=1)
    return result[:2] if stage == "first2" else result


def expected_books(session):
    """
    機能: 商品×Source手法の保存keyを明示する。
    引数: session(str)は場ID。
    返り値: set[str]はDay2/Night4。
    """
    methods = ("D164_15",) if session.endswith("_Day") else ("P164_06", "U165_03")
    return {f"{product}_{method}" for product in ("micro", "mini") for method in methods}


def verify_book(book, key, session):
    """
    機能: 一Source口座の保存数量/費用/残0を検算し元新規方向へ集約する。
    引数: book(dict)、key/session(str)は公開Ledger・商品手法・場。
    返り値: dictは方向別件数/実現額。原板やSourceを再生しない。
    """
    product, method = key.split("_", 1)
    mini = product == "mini"
    cfg = {"product": "NK225mini" if mini else "NK225micro", "core_quantity": 5 if mini else 50, "extra_max_quantity": 5 if mini else 50, "cap": 10 if mini else 100, "point_value": 100 if mini else 10, "large_tick": 10, "fee_yen_per_side": Decimal("38.5") if mini else 11, "slippage_points": 5}
    need(book["config"] == cfg and book["method"] == "NK225_" + method, "商品/手法規格差")
    need(book["session"]["id"] == session and book["finished"] is True and book["complete"] is True and book["failure"] == "", "Source未完結")
    need(type(book["pending"]) is list and not book["pending"], "未約定/返済予約残")
    signals = book["signals"]
    need(type(signals) is list and type(book["fills"]) is list and type(book["holds"]) is list, "保存配列欠落")
    by_signal = {v["signal"]["id"]: v["signal"] for v in signals}
    holds = {v["hold_id"]: v for v in book["holds"]}
    need(len(by_signal) == len(signals) and len(holds) == len(book["holds"]), "Signal/Hold重複")
    direction = {1: Counter(), -1: Counter()}
    for item in signals:
        s = item["signal"]
        need(s["action"] in ("new", "close") and s["side"] in (-1, 1) and integer(s["quantity"]) > 0, "Signal型/量")
        side = s["side"] if s["action"] == "new" else -s["side"]
        target = direction[side]
        target["new_signals" if s["action"] == "new" else "close_signals"] += 1
        target["requested_new_qty" if s["action"] == "new" else "requested_close_qty"] += s["quantity"]
        if s["action"] == "close":
            targets = s["targets"]
            need(len({t["id"] for t in targets}) == len(targets) and sum(integer(t["quantity"]) for t in targets) == s["quantity"], "返済Targets総量")
            for t in targets:
                need(t["id"] in holds and holds[t["id"]]["side"] == side and t["quantity"] > 0, "返済所有方向")
            target["close_notices"] += len(targets)
    for cancellation in book["cancellations"]:
        s = by_signal[cancellation["signal_id"]]
        need(s["action"] == "new", "新規以外の取消")
        direction[s["side"]]["cancellations"] += 1
    open_qty, entry_qty, close_qty = Counter(), 0, 0
    gross = fee = slip = ZERO
    seen_exec = set()
    for record in book["fills"]:
        fill = record["fill"]
        need(fill["ExecutionID"] not in seen_exec, "重複ExecutionID")
        seen_exec.add(fill["ExecutionID"])
        s = by_signal[fill["SignalID"]]
        need(record["action"] == s["action"] and record["side"] == s["side"], "Fill/Signal型差")
        q = integer(fill["Quantity"])
        need(q > 0 and number(fill["Fee"]) == 0, "実Fill量/元判断Fee0")
        side = record["side"] if record["action"] == "new" else -record["side"]
        d = direction[side]
        if record["action"] == "new":
            entry_qty += q; open_qty[side] += q
            need(fill["HoldID"] in holds and holds[fill["HoldID"]]["side"] == side, "新規Hold所有")
            need(not record["allocations"], "新規に返済片")
        else:
            close_qty += q; open_qty[side] -= q
            need(sum(integer(a["quantity"]) for a in record["allocations"]) == q, "返済片数量")
            allocation_gross = ZERO
            for a in record["allocations"]:
                need(a["hold_id"] in holds and holds[a["hold_id"]]["side"] == side, "配賦Hold方向")
                value = side * (number(a["exit_price"]) - number(a["entry_price"])) * a["quantity"] * cfg["point_value"]
                need(value == number(a["gross_yen"]), "配賦粗額")
                unit_fee = number(cfg["fee_yen_per_side"]) * a["quantity"]
                unit_slip = Decimal(5 * cfg["point_value"] * a["quantity"])
                need(number(a["entry_fee_yen"]) == unit_fee == number(a["exit_fee_yen"]), "配賦半円費用")
                need(number(a["entry_slippage_yen"]) == unit_slip == number(a["exit_slippage_yen"]), "配賦滑り")
                need(number(a["net_yen"]) == value - 2 * unit_fee - 2 * unit_slip, "配賦純額")
                allocation_gross += value
            need(allocation_gross == number(record["gross_yen"]), "Fill粗額/配賦")
        need(0 <= open_qty[side] <= cfg["cap"], "実保有側上限/過剰返済")
        f = number(cfg["fee_yen_per_side"]) * q
        sl = Decimal(cfg["point_value"] * 5 * q)
        g = number(record["gross_yen"])
        need(number(record["fee_yen"]) == f and number(record["slippage_yen"]) == sl and number(record["net_contribution_yen"]) == g - f - sl, "Fill外費用/単片純額")
        d["new_fills" if record["action"] == "new" else "close_fills"] += 1
        d["entry_qty" if record["action"] == "new" else "close_qty"] += q
        d["gross"] += g; d["fee"] += f; d["slip"] += sl
        gross += g; fee += f; slip += sl
    need(open_qty[1] == open_qty[-1] == 0 and entry_qty == close_qty, "Fill清算残")
    for hold in holds.values():
        need(hold["quantity"] == 0 and hold["initial_quantity"] == hold["closed_quantity"], "Hold残")
    total = book["totals"]
    need(all(total[k] == 0 for k in ("open_buy_quantity", "open_sell_quantity", "pending_buy_quantity", "pending_sell_quantity", "open_entry_costs_yen")), "保存終残/予約/未配賦費用")
    need(total["entry_quantity"] == entry_qty and total["close_quantity"] == close_qty, "保存総数量")
    for name, expected in (("gross_yen", gross), ("fee_yen", fee), ("slippage_yen", slip), ("gross_minus_fee_yen", gross-fee), ("net_yen", gross-fee-slip), ("closed_net_yen", gross-fee-slip)):
        need(number(total[name]) == expected, "Source総額:" + name)
    for d in direction.values():
        for name in ("new_signals", "close_signals", "requested_new_qty", "requested_close_qty", "close_notices", "cancellations", "new_fills", "close_fills", "entry_qty", "close_qty", "gross", "fee", "slip"):
            d[name] = d[name]  # 完結した保存全列を観測した既知0。未知の補完ではない。
        d["fee_only"] = d["gross"] - d["fee"]
        d["net"] = d["gross"] - d["fee"] - d["slip"]
    return {"product": product, "method": method, "kind": book["session"]["kind"], "direction": {str(k): dict(v) for k, v in direction.items()}, "totals": {"gross": gross, "fee": fee, "slip": slip, "fee_only": gross-fee, "net": gross-fee-slip}}


def first_difference(a, b, path=""):
    """
    機能: 全JSON差を見て最初の葉だけを小型出力する。
    引数: a/b(any)、path(str)は保存値と現在path。
    返り値: dict|Noneは差。ID番号で同一玉を対応付けない。
    """
    if a == b:
        return None
    if isinstance(a, dict) and isinstance(b, dict):
        for key in sorted(set(a) | set(b)):
            if key not in a or key not in b:
                return {"path": path + "/" + key, "difference": "field有無"}
            found = first_difference(a[key], b[key], path + "/" + key)
            if found:
                return found
    if isinstance(a, list) and isinstance(b, list):
        for i, (x, y) in enumerate(zip(a, b)):
            found = first_difference(x, y, path + f"/{i}")
            if found:
                return found
        return {"path": path, "before_length": len(a), "after_length": len(b)}
    return {"path": path, "before": str(a)[:160], "after": str(b)[:160]}


def inspect_scene(value, session):
    """
    機能: 一場の商品/手法集合と全Source口座を確認する。
    引数: value(dict)、session(str)は保存結果と場ID。
    返り値: dictは各商品手法の検算済み小型値。
    """
    need(value["session"] == session and set(value["books"]) == expected_books(session), "Source場/商品手法集合")
    checked = {key: verify_book(book, key, session) for key, book in value["books"].items()}
    need(set(value["source_rows"]) == set(checked) and all(integer(n) > 0 for n in value["source_rows"].values()), "Source配送行欠落")
    return checked


def summarize(args):
    """
    機能: 成功完了と固定条件へ結合したSourceAだけを読む。
    引数: args(Namespace)は条件/完了FileRefと新規出力先。
    返り値: dictは小集計。Raw/CSV/Source/金融を再実行しない。
    """
    need(args.condition_sha == CONDITION_SHA, "固定SourceA条件SHA不一致")
    before = {}
    cp = file_ref({"path": str(args.condition.resolve()), "sha256": args.condition_sha}, Path.cwd(), before)
    condition = load(cp)
    need(condition["version"] == 1 and condition["trial"] == 104 and condition["fixed"] is True and condition["modes"] == list(MODES), "SourceA固定metadata")
    complete_path = file_ref({"path": str(args.completion.resolve()), "sha256": args.completion_sha}, Path.cwd(), before)
    complete = load(complete_path)
    ids = expected_ids(complete["stage"])
    need([s["session"] for s in condition["scenes"]] == expected_ids("full54"), "条件54場不一致")
    need(complete["success"] is True and complete["version"] == 1 and complete["trial"] == 104 and complete["condition_sha256"] == args.condition_sha and complete["sessions"] == len(ids) and complete["unchanged"] is True and complete["before"] == complete["after"] and complete["source_reformed"] is True and complete["financial103_executed"] is False and not complete.get("error"), "未成功/別条件/入力不変未成立")
    need(complete["before"].get(str(cp)) == args.condition_sha, "完了の条件参照不一致")
    repo = Path(__file__).resolve().parents[2]
    for name, expected in condition["code_sha256"].items():
        path = (repo / name).resolve()
        need(complete["before"].get(str(path)) == expected, "完了の固定code参照差:" + name)
    for field in ("generator_stop", "replay_stop", "binary", "manifest80"):
        ref = condition[field]
        path = file_ref(ref, cp.parent, before)
        need(complete["before"].get(str(path)) == ref["sha256"], "完了の固定metadata参照差:" + field)
    cases = {(c["session"], c["mode"]): c for c in complete["cases"]}
    need(len(cases) == len(complete["cases"]) and set(cases) == {(s, m) for s in ids for m in MODES}, "case欠落/重複/別場")
    aggregates = defaultdict(Counter); differences = []; total_books = 0
    for session in ids:
        scene_values = {}
        base_ref = next(s["baseline93"] for s in condition["scenes"] if s["session"] == session)
        old_path = file_ref(base_ref, cp.parent, before)
        need(complete["before"].get(str(old_path)) == base_ref["sha256"], "完了の旧93参照が不一致")
        old = load(old_path)
        for mode in MODES:
            case = cases[session, mode]
            need(not case.get("error") and case["old93_full_match"] is (mode != "symmetric"), "旧93一致flag誤用")
            result_path = file_ref(case["result"], complete_path.parent, before)
            file_ref(case["records"], complete_path.parent, before)
            value = load(result_path)
            if mode != "symmetric":
                need(value == old, "旧93全文構造が再照合不一致")
            checked = inspect_scene(value, session); total_books += len(checked)
            counts = case["counts"]
            need(set(counts) == {"calls", "steps", "forces", "signals", "fills", "closes", "cancellations"} and all(integer(v) >= 0 for v in counts.values()), "配送件数型/負値")
            actual = {"steps": sum(value["source_rows"].values()), "signals": sum(len(b["signals"]) for b in value["books"].values()), "fills": sum(len(b["fills"]) for b in value["books"].values()), "cancellations": sum(len(b["cancellations"]) for b in value["books"].values()), "closes": sum(sum(len(s["signal"].get("targets", [])) for s in b["signals"] if s["signal"]["action"] == "close") for b in value["books"].values())}
            need(all(integer(counts[k]) == v for k, v in actual.items()) and counts["calls"] == counts["steps"] + counts["forces"], "全配送receipt件数と保存列が不一致")
            for key, book in checked.items():
                for side, values in book["direction"].items():
                    aggregates[mode, book["product"], book["kind"], side].update(values)
            scene_values[mode] = value
        for key in scene_values["legacy"]["books"]:
            a, b = scene_values["legacy"]["books"][key], scene_values["symmetric"]["books"][key]
            flags = {name: a[name] == b[name] for name in ("signals", "fills", "cancellations")}
            differences.append({"session": session, "book": key, "full_json_equal": a == b, "arrays_equal": flags, "first_signal_difference": first_difference(a["signals"], b["signals"]), "first_fill_difference": first_difference(a["fills"], b["fills"])})
    need(total_books == (18 if len(ids) == 2 else 486), "Sourcebook予定数")
    rows = [{"mode": key[0], "product": key[1], "kind": key[2], "entry_side": int(key[3]), **dict(value)} for key, value in sorted(aggregates.items())]
    delta = []
    for product in ("mini", "micro"):
        for kind in ("Day", "Night"):
            for side in ("1", "-1"):
                a, b = aggregates["legacy", product, kind, side], aggregates["symmetric", product, kind, side]
                delta.append({"product": product, "kind": kind, "entry_side": int(side), **{name: b[name] - a[name] for name in MONEY}})
    after = {name: digest(Path(name)) for name in before}
    need(before == after, "読取前後SHA差")
    result = {"成功": True, "scope": "StageA連続Sourceの商品会計。B5Q/LD10後の実会計ではない", "stage": complete["stage"], "場数": len(ids), "case数": len(cases), "Sourcebook数": total_books, "条件SHA256": args.condition_sha, "完了SHA256": args.completion_sha, "旧93全文再照合case": 2 * len(ids), "集計": rows, "sym_minus_legacy": delta, "JSON差の件数": {name: sum(not d["arrays_equal"][name] for d in differences) for name in ("signals", "fills", "cancellations")}, "差の例_先頭最大6": [d for d in differences if not d["full_json_equal"]][:6], "入力SHA256前": before, "入力SHA256後": after, "入力不変": True, "限界": ["recordsは圧縮現物SHAとreceipt件数へ結合。全原行の再査定/Before/next正常行の原板検査はしない", "ID番号で同じ玉/取引を推定しない。JSON全構造差と最初の差だけ", "歴史的なpending込み上限/自然Source全体の鏡像は独立証明しない", "通知同値は公開通知への影響未観測であり、重複域不発生の証明でない。range_sideのL/H実評価件数は未計測", "B5Q/LD10/金融103/未使用期間の結果ではない", "機会損失/退出後仮想利益を扱わない"], "Raw/CSV/Source/金融実行": 0}
    need(not args.out.exists(), "新規出力先だけ")
    args.out.mkdir(parents=True, exist_ok=False)
    (args.out / "結果.json").write_text(json.dumps(result, ensure_ascii=False, indent=2, default=lambda d: int(d) if d == d.to_integral_value() else float(d)) + "\n", encoding="utf-8")
    md = "# SourceAの保存整理\n\nStageAは連続Source会計であり、B5Q/LD10後ではない。\n\n" + f"{len(ids)}場/{len(cases)}case/{total_books}Sourcebook、legacy/defaultの旧93全文再照合{2*len(ids)}case成功。入力前後不変。\n\n" + "|mode|商品|場種|元新規方向|粗額|手数料|5pt仮定滑り|費用のみ後|滑り込み純額|\n|---|---|---|---|---:|---:|---:|---:|---:|\n"
    for row in rows:
        md += f"|{row['mode']}|{row['product']}|{row['kind']}|{row['entry_side']}|" + "|".join(str(row.get(n, ZERO)) for n in MONEY) + "|\n"
    md += "\n方向は元新規方向。返済注文Sideをそのまま売り成績へ足さず、所有方向へ戻す。SourceID番号で玉対応を推定せず、全Signal/Fill配列の差と最初の差だけを記録した。micro/miniは枚数/点価/費用が異なり合算した優劣としない。圧縮recordsはSHA/件数確認で、原板全経路監査ではない。公開通知が同じ場合は公開通知への影響未観測とする。range_sideのL/H実評価件数は未計測で、重複域が発生しなかったとは言わない。Source全体の対称性・未使用期間の安定利益・後段Bの採否は未証明。\n"
    (args.out / "要約.md").write_text(md, encoding="utf-8")
    return {key: result[key] for key in ("成功", "stage", "場数", "case数", "Sourcebook数", "入力不変")}


def main():
    """
    機能: Rootの成功通知後だけ固定FileRefを指定して整理するCLI。
    引数: condition/condition-sha/completion/completion-sha/outは明示参照。
    返り値: None。未成功/不一致は例外で停止。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--condition", type=Path, required=True)
    parser.add_argument("--condition-sha", required=True)
    parser.add_argument("--completion", type=Path, required=True)
    parser.add_argument("--completion-sha", required=True)
    parser.add_argument("--out", type=Path, required=True)
    print(json.dumps(summarize(parser.parse_args()), ensure_ascii=False))


if __name__ == "__main__":
    main()
