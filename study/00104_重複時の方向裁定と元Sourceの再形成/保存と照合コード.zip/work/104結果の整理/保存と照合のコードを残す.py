"""104の事後保存・限定表示確認コードを小ZIPへ同体保存する。"""

import hashlib
import json
from pathlib import Path
import uuid
import zipfile


ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / "study/00104_重複時の方向裁定と元Sourceの再形成"
OLD_STUDY = ROOT / "study/00103_元の多玉と数量を保つ一定利益後の追尾"


def sha(path):
    """
    機能: 指定ファイルのbytesだけからSHA256を得る。
    引数: path(Path)はコード又は小さな証拠/既存コードZIP。
    返り値: strは内容指紋。金融/Sourceを実行しない。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    """
    機能: コード保存台帳又は人工確認metadataを読む。
    引数: path(Path)は明示した小JSON。
    返り値: dictは保存されたmetadata。実金融Nativeや結果を読まない。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def relative(path):
    """
    機能: repo内の元位置をZIPの安全な相対pathへ表す。
    引数: path(Path)はrepo内通常ファイル。
    返り値: strは同じ展開先。絶対path/親移動を含めない。
    """
    name = path.resolve().relative_to(ROOT).as_posix()
    assert name and not name.startswith("/") and ".." not in Path(name).parts
    return name


def main():
    """
    機能: 選択コード/人工証拠を同体保存し全entry読戻しを確認する。
    引数: なし。104正式先の新しい保存と照合コード.zip/.jsonだけを作る。
    返り値: None。再集計/市場読取/Viewer通信/コード実行は行わない。
    """
    target = STUDY / "保存と照合コード.zip"
    ledger = STUDY / "保存と照合コード.json"
    assert not target.exists() and not ledger.exists()
    saving = ROOT / "work/104LD10の保存"
    source = ROOT / "work/104Source結果の整理"
    save_stop, source_stop = saving / "停止.json", source / "停止.json"
    assert sha(save_stop) == "b4859a859f7b5dbfd3094824186984a4f7068fadf2a8819d88958728d3db2504"
    assert sha(source_stop) == "d0b0f06f695efe30323383772f15e4dcd990c136c8cad04f1e689286ab9d24b0"
    save_meta, source_meta = read(save_stop), read(source_stop)
    assert save_meta["成功"] and source_meta["成功"]
    assert sha(saving / "集計.py") == save_meta["保存コードSHA256"] == "0409ae3f0f084bedac0196ca5bd62a356c074f7c27e464854f1d5dd5645c7900"
    assert sha(source / "SourceAを整理する.py") == source_meta["codeSHA256"] == "1cebe87c7dc1a3ab099069c09ff835db799edca9458605f8e33723cc365a13cc"

    # ----------------------------------------
    # 選択は明示列だけ。globで実結果や人工の全帳簿を混入させない。
    paths = [saving / name for name in ("集計.py", "停止.json", "由来.json", "README.md", "人工を確認する.py",
        "公開型を確認する.py", "metadataを確認する.py", "停止を記録する.py", "公開型人工_最終.json", "metadata人工_最終.json")]
    paths += [source / name for name in ("SourceAを整理する.py", "停止.json", "README.md", "人工を確認する.py",
        "人工型を保存する.go", "go.mod", "go.sum", "人工確認_最終.json")]
    paths += [ROOT / "work/104実行条件の準備/主B保存を固定する.py",
              ROOT / "work/104結果の整理/Viewerの4資源を確認する.py",
              ROOT / "work/104結果の整理/報告と保存を確認する.py", Path(__file__).resolve()]
    assert len(paths) == len(set(paths)) == 22
    before = {relative(path): sha(path) for path in paths}
    for name, expected in save_meta["所有コードSHA256"].items():
        assert before[name] == expected
    for path in paths:
        name = relative(path)
        if name in source_meta["所有SHA256"]:
            assert before[name] == source_meta["所有SHA256"][name]
        assert path.suffix in (".py", ".go", ".md", ".json", ".mod", ".sum")
        assert path.name not in ("結果.json", "完了.json", "Go型人工.json")
    for n, proof in save_meta["人工証拠"].items():
        assert before[relative(ROOT / proof["path"])] == proof["SHA256"]

    # ----------------------------------------
    # 重複させない103/95/94の三保存器は旧103正式ZIP内の本文を検証する。
    old_ledger = OLD_STUDY / "保存と照合のコード.json"
    old = read(old_ledger)
    old_zip = OLD_STUDY / old["ZIP"]["path"]
    assert old["成功"] and sha(old_zip) == old["ZIP"]["sha256"] == "9cc31998ee0d819af7e8eaf180e2fbd8ab83b982269f4526b04dd621d068b537"
    reused = {}
    with zipfile.ZipFile(old_zip) as archive:
        for name in ("work/103多玉の保存集計/集計.py", "scripts/FAR5分判断と出生一回の監査/集計.py", "scripts/FAR連続出生と個別利益追尾/集計.py"):
            value = hashlib.sha256(archive.read(name)).hexdigest()
            assert value == old["相対path_SHA256"][name] == sha(ROOT / name)
            assert name not in before
            reused[name] = value
    external = []
    for path, role in ((old_zip, "103/95/94保存器の直接再用。先にrepoルートへ展開"),
                       (old_ledger, "上記既存ZIPの元path/SHA台帳"),
                       (STUDY / "主B追加コード.zip", "runtime停止59d7/型export生成testなど。人工依存のコード"),
                       (STUDY / "Source再現コード.zip", "人工型Go generatorが参照する旧93公開型等のコード。展開はSource再現手順に従う")):
        external.append({"path": relative(path), "SHA256": sha(path), "bytes": path.stat().st_size, "用途": role})
    preserved = {relative(path): sha(path) for path in STUDY.iterdir() if path.is_file()}
    preserved.update({relative(old_zip): sha(old_zip), relative(old_ledger): sha(old_ledger)})

    # ----------------------------------------
    # 全型出力は非同梱とし、指紋と再生成元だけを明示する。
    public = read(saving / "公開型人工_最終.json")
    omitted = []
    for name, expected in public["公開型入力前後SHA256"].items():
        path = Path(name)
        if "人工/型export/" in path.as_posix():
            omitted.append({"元path": relative(path), "SHA256": expected, "指紋根拠": "停止時の公開型人工_最終.json", "非同梱理由": "金融型の全出力はZIP対象外。主B追加コードのcodec_test.goで人工再生成する"})
    omitted.append({"元path": relative(source / "Go型人工.json"), "SHA256": source_meta["所有SHA256"][relative(source / "Go型人工.json")],
                    "指紋根拠": "SourceA停止d0b0", "非同梱理由": "型出力も同梱せず、人工型を保存する.goとgo.mod/sumを保存。Source/金融engineを呼ばず再生成可能"})
    legacy_artificial = ROOT / "work/103多玉の保護会計/人工/停止版"
    for path in sorted(legacy_artificial.glob("*.json")):
        omitted.append({"元path": relative(path), "SHA256": sha(path), "非同梱理由": "旧103全帳簿の型人工出力。大量重複を避ける。元金融停止e051と旧103再現コードに従い別途用意"})

    candidate = ROOT / "work/104保存照合コードの保存" / uuid.uuid4().hex
    candidate.mkdir(parents=True)
    prepared_zip = candidate / target.name
    with zipfile.ZipFile(prepared_zip, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name in sorted(before):
            payload = (ROOT / name).read_bytes()
            assert hashlib.sha256(payload).hexdigest() == before[name]
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, payload)
    with zipfile.ZipFile(prepared_zip) as archive:
        assert archive.testzip() is None and set(archive.namelist()) == set(before)
        assert len(archive.namelist()) == len(before)
        for name in archive.namelist():
            assert not name.startswith(("/", "\\")) and ":" not in name and ".." not in Path(name).parts
            assert hashlib.sha256(archive.read(name)).hexdigest() == before[name]
    after = {name: sha(ROOT / name) for name in before}
    assert after == before
    assert all(sha(ROOT / name) == expected for name, expected in preserved.items())
    value = {"成功": True, "scope": "104事後保存・限定照合コードと最終小人工証拠。市場実行前のSource/主B条件コードへ遡及追加しない",
             "ZIP": {"path": target.name, "SHA256": sha(prepared_zip), "bytes": prepared_zip.stat().st_size, "entry数": len(before)},
             "展開先": "FutureSignalResearchのrepoルート。entryの元相対pathへ同体展開。先に参照する旧103保存ZIPも元repoルートへ展開",
             "entries": [{"元path": name, "ZIP_entry": name, "展開先相対path": name, "SHA256": before[name], "bytes": (ROOT / name).stat().st_size} for name in sorted(before)],
             "再用ZIP参照": external, "直接再用Python_SHA256": reused, "不収録人工出力": omitted,
             "人工再現": ["SourceA: work/104Source結果の整理を作業dirとして go run 人工型を保存する.go Go型人工.json。次に人工を確認する.py --out <新規receipt>。これは手製型codecのみ",
                 "StageB: runtimeの型export5本と旧103停止版人工を既存再現コードの手順で別途生成/配置後、公開型を確認する.py/人工を確認する.pyを実行。全人工出力が本ZIPに同梱済みとはしない",
                 "metadata人工はmetadataを確認する.py --out <新規receipt>。実保存CLI/FileRef基準は同梱された凍結READMEを参照"],
             "停止時点の区別": "SourceA停止のfull54待機やStageB停止の実市場未読は停止当時の記録。後の成功結果/確認は別成果物。停止原文を訂正しない",
             "Viewerのscope": "同梱する4資源確認コードは保存用bytesのみ。今回HTTP/APIを再実行せず、全432表示の検証へ拡張しない",
             "ZIP全entry読戻し": {"SHA一致": len(before), "差分": 0, "CRC差": 0, "危険path": 0},
             "元コード前後SHA256": {"前": before, "後": after, "同一": True}, "既存正式/旧ZIP前後SHA256": preserved,
             "非同梱": ["原板", "CSV", "Source records", "金融Native", "実結果outputs", "xlsx", "人工全帳簿出力", "巨大中間", "実行exe/GoRoot/依存cache"],
             "旧停止/条件/README/設定/目次/完了記録変更": 0, "Source/金融/保存集計/Viewer再実行": 0}
    prepared_ledger = candidate / ledger.name
    prepared_ledger.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for src, dest in ((prepared_zip, target), (prepared_ledger, ledger)):
        with dest.open("xb") as stream:
            stream.write(src.read_bytes())
        assert sha(dest) == sha(src)
    print(json.dumps({"成功": True, "entry": len(before), "ZIP": relative(target), "ZIP_SHA256": sha(target), "台帳SHA256": sha(ledger)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
