"""104の完成保存・固定コード・報告リンクを照合する。"""

import hashlib
import json
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / "study/00104_重複時の方向裁定と元Sourceの再形成"


def sha(path: Path) -> str:
    """
    機能: ファイル内容のSHA256を求める。
    引数: path(Path)は読取対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict:
    """
    機能: UTF-8の完成JSONを読む。
    引数: path(Path)は保存先。
    返り値: dictは保存値。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main() -> None:
    """
    機能: 新しい金融再生をせず104の固定物と報告の対応を確認する。
    引数: なし。完成した主B保存とSource/金融/Viewer証拠を参照する。
    返り値: None。実行した範囲だけを新規の検査証拠へ記録する。
    """
    output = STUDY / "検査/報告と保存の確認.json"
    assert not output.exists()
    saved_dir = STUDY / "成果物_主B"
    saved = read(saved_dir / "保存会計の確認.json")
    result = read(saved_dir / "結果.json")
    assert saved["成功"] and saved["会計"] == saved["資源"] == 432
    assert saved["不一致数"] == 0 and saved["前後不変"]
    assert saved["conditionSHA256"] == sha(STUDY / "主B条件.json")
    assert saved["completionSHA256"] == "12ab59337bf42bb307cc70e86e6f0f54bbe845c5d32a60d00a1f7e0c16ee6299"
    counts = {}
    for name in ["Source条件.json", "先頭2結合条件.json", "主B条件.json"]:
        condition = read(STUDY / name)
        for key, expected in condition["code_sha256"].items():
            path = Path(key) if Path(key).is_absolute() else ROOT / key
            assert sha(path) == expected, key
        counts[name] = len(condition["code_sha256"])
    for key, expected in saved["出力SHA256"].items():
        assert sha(saved_dir / key) == expected, key
    assert len(result["集計"]) == 8
    for key, value in result["集計"].items():
        assert value["entry_quantity"] == value["close_quantity"]
        assert value["open_buy"] == value["open_sell"] == value["pending_buy"] == value["pending_sell"] == 0
        assert value["net_yen"] == value["gross_yen"] - value["fee_yen"] - value["slip_yen"]
        activity = value["活動主表"]
        assert activity["denom"] == 6048 and activity["active"] == activity["new"] + activity["hold"]
        assert activity["active"] + activity["wait"] + activity["unknown"] == 6048
        assert activity["欠測"] == activity["遅い取得の要求枠"] == 0
    same = read(STUDY / "検査/主B全54場/旧対称全Book同体.json")
    assert same["成功"] and same["Book対"] == 216 and same["field除外"] == same["差"] == 0
    viewer = read(STUDY / "検査/主B全54場/Viewer代表4資源.json")
    assert viewer["成功"] and viewer["一覧資源数"] == 432 and viewer["実GET資源"] == 4

    # ----------------------------------------
    # 現在のライブ報告だけを調べ、実行前の原文や固定数値は変更しない。
    docs = []
    missing = []
    for name in ["README.md", "設定と結果.md", "Source再現手順.md", "再現手順.md"]:
        path = STUDY / name
        for link in re.findall(r"\]\(([^)]+)\)", path.read_text(encoding="utf-8-sig")):
            if link.startswith(("https://", "http://", "#")):
                continue
            target = link.split("#", 1)[0].strip("<>")
            if target and not (path.parent / target).exists():
                missing.append({"文書": name, "参照": target})
        docs.append({"path": name, "sha256": sha(path)})
    assert not missing, missing
    value = {"成功": True, "scope": "固定コード/保存出力指紋・主8集計算術・既存限定証拠・ライブ4文書リンク。全原行別engine金融再生ではない",
             "固定code数": counts, "Source場": 54, "Sourcecase": 162, "主B会計": 432,
             "旧103全文対照Book": 216, "新旧同体Book対": 216, "Viewer一覧": 432, "Viewer実GET": 4,
             "文書": docs, "リンク欠損": missing, "確認コード": {"path": str(Path(__file__).relative_to(ROOT)), "sha256": sha(Path(__file__))},
             "研究目標達成": False, "実運用採用": False, "新金融再実行": 0, "Source再生成": 0}
    output.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "主B会計": 432, "固定code数": counts, "リンク欠損": 0}, ensure_ascii=False))


if __name__ == "__main__":
    main()
