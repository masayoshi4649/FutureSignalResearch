"""StageB完了metadataの型・集合・未固定拒否だけを人工で検査する。"""

import argparse
import copy
import importlib.util
import json
from pathlib import Path
import tempfile


def main():
    """
    機能: 手製成功metadataの正常1と狭い破損を検査する。
    引数: --out(Path)は新規receipt。
    返り値: None。完了実JSON/StageB Native本文は読まない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location("StageB保存metadata", here / "集計.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    configs = m.configurations()
    condition = {"version": 1, "trial": 104, "fixed": True, "configs": configs}
    done = {"version": 1, "trial": 104, "stage": "first2", "success": True, "condition_sha256": "a" * 64, "sessions": 2, "books_per_scene": 8, "books": 16, "legacy_control_books": 8, "default_books": 0, "configs": configs, "before": {"metadata-only": "b" * 64}, "after": {"metadata-only": "b" * 64}, "unchanged": True, "source_reexecuted": False, "charts_recomputed": False, "gate_executed": False, "raw_csv_read": 0, "results": [{"session": sid, "books": 8, "legacy_control_books": 4, "native": {"path": sid + ".json.gz", "sha256": "c" * 64}} for sid in m.expected_sessions("first2")]}
    assert len(m.validate_completion(condition, done, "first2", "a" * 64)) == 2
    rejected = []
    for name in ("未固定", "未成功", "別条件", "default経済化", "旧対照不足", "設定不足", "場重複", "Native空path", "前後差", "Source再形成"):
        c, d = copy.deepcopy(condition), copy.deepcopy(done)
        if name == "未固定": c["fixed"] = False
        elif name == "未成功": d["success"] = False
        elif name == "別条件": d["condition_sha256"] = "f" * 64
        elif name == "default経済化": d["default_books"] = 4
        elif name == "旧対照不足": d["legacy_control_books"] = 4
        elif name == "設定不足": d["configs"] = d["configs"][:4]
        elif name == "場重複": d["results"][1]["session"] = d["results"][0]["session"]
        elif name == "Native空path": d["results"][0]["native"]["path"] = ""
        elif name == "前後差": d["after"] = {}
        elif name == "Source再形成": d["source_reexecuted"] = True
        try:
            m.validate_completion(c, d, "first2", "a" * 64)
        except (ValueError, KeyError):
            rejected.append(name)
        else:
            raise AssertionError("破損を成功化:" + name)
    assert not m.valid_sha("") and not m.valid_sha("A" * 64)
    # ----------------------------------------
    # 本物のCLI準備関数も未固定Root段階で止まり、Native入力へ到達しない。
    with tempfile.TemporaryDirectory(prefix="StageB保存入口_") as directory:
        root = Path(directory)
        p = root / "未固定.json"
        p.write_text(json.dumps({"version": 1, "trial": 104, "phase": "StageB", "fixed": False}), encoding="utf-8")
        calls, original_load = [], m.OLD.load

        def track_load(path):
            """
            機能: 未固定拒否時の入力読取先を人工内だけで記録する。
            引数: path(Path)は保存準備が読むJSON。
            返り値: dictは元読取関数の値。金融/Source入力は作らない。
            """
            calls.append(Path(path))
            return original_load(path)

        m.OLD.load = track_load
        try:
            try:
                m.prepare(p, m.OLD.digest(p), root / "出力")
            except ValueError:
                pass
            else:
                raise AssertionError("未固定Rootを成功化")
        finally:
            m.OLD.load = original_load
        assert calls == [p] and not (root / "出力").exists()
    output = {"成功": True, "scope": "手製metadataのみ。StageB金融成功を生成/流用しない", "正常": 1, "拒否": rejected, "未固定RootでNative読取前拒否": True, "主6048/副5832": "値は旧103関数を実Native後に検算", "StageB実Native読取": 0, "Source/金融再生": 0, "codeSHA256": m.OLD.digest(here / "集計.py")}
    with args.out.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(output, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "正常": 1, "拒否": len(rejected)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
