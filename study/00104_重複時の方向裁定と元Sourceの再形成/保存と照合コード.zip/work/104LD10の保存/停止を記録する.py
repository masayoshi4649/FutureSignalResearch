"""StageB保存器の型人工と固定103再用を市場前の停止証拠へ結ぶ。"""

import argparse
import importlib.util
import json
from pathlib import Path


def main():
    """
    機能: 所有コード、公開型/metadata人工、元103/runtime指紋を停止へ保存する。
    引数: --out(Path)は存在しない停止JSON。
    返り値: None。市場本文、Source、金融、Raw、実Viewerへ接続しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location("StageB保存停止確認", here / "集計.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    root = m.ROOT
    need, equal = m.need, m.equal

    # ----------------------------------------
    # 元103/固定95/固定94とruntimeの停止済み公開型を指紋で結ぶ。
    fixed = {m.LEGACY_PATH: m.LEGACY_SHA, m.OLD.GRID_PATH: m.OLD.GRID_SHA,
             m.OLD.GRID.BASE_PATH: m.OLD.GRID.BASE_SHA,
             root / "work/103多玉の保護会計/停止.json": "e051a2401c8919835adfea52bf346d644707239fd030f0b13f101586b4c1d52b",
             root / "work/104LD10の全場比較/停止.json": "59d7cb6768ebe7825cf031d85012c83710ba3a2926ef8bd2d5d3f22c3c1a54d0"}
    runtime_stop = m.OLD.load(root / "work/104LD10の全場比較/停止.json")
    for group in (runtime_stop["所有コードSHA256"], runtime_stop["人工確認"]["型人工SHA256"]):
        fixed.update({(root / p).resolve(): h for p, h in group.items()})
    before = {str(p): m.OLD.digest(p) for p in fixed}
    equal(before, {str(p): h for p, h in fixed.items()}, "固定元/code/全公開型前指紋")

    # ----------------------------------------
    # 実行済み人工のscopeと、最終保存本体SHAを別のまま結ぶ。
    sha = m.OLD.digest(here / "集計.py")
    proofs = {}
    for name in ("公開型人工_最終.json", "metadata人工_最終.json"):
        path = here / name
        value = m.OLD.load(path)
        need(value["成功"] is True, "最終人工が未成功")
        equal(value.get("保存コードSHA256", value.get("codeSHA256")), sha, "人工の保存本体SHA")
        proofs[name] = {"path": str(path.relative_to(root)).replace("\\", "/"), "SHA256": m.OLD.digest(path)}
    public = m.OLD.load(here / "公開型人工_最終.json")
    metadata = m.OLD.load(here / "metadata人工_最終.json")
    equal(public["合法空BindのNative会計"], 8, "空Native8")
    equal(public["非0Go型会計"], 32, "非0ModeResult32")
    equal(public["非0全Fill対応"], 160, "全Fill保存対応")
    equal(public["二宣言modeの比較"], 16, "二mode比較16")
    equal(len(public["拒否"]), 6, "型破損6")
    equal(len(metadata["拒否"]), 10, "metadata拒否10")
    need(metadata["未固定RootでNative読取前拒否"] is True, "未固定Root拒否が未検査")
    for p, expected in public["公開型入力前後SHA256"].items():
        equal(m.OLD.digest(Path(p)), expected, "公開型/元指紋不変")
    names = ("集計.py", "人工を確認する.py", "公開型を確認する.py", "metadataを確認する.py",
             "停止を記録する.py", "README.md", "由来.json")
    owned = {str((here / n).relative_to(root)).replace("\\", "/"): m.OLD.digest(here / n) for n in names}
    after = {str(p): m.OLD.digest(p) for p in fixed}
    equal(after, before, "固定元/runtime/code/型入力の停止時不変")
    output = {"成功": True, "市場前": True, "フェーズ": "StageB保存準備", "保存コードSHA256": sha,
              "所有コードSHA256": owned, "元指紋前": before, "元指紋後": after, "前後不変": True,
              "人工証拠": proofs, "人工成功": {"合法空Native": 8, "非0ModeResult": 32, "全Fill対応": 160,
                  "同実入口比較": 16, "旧103LD10全文": {"空": 4, "非0": 16, "除外": []},
                  "型破損拒否": 6, "metadata正常": 1, "metadata拒否": 10, "未固定RootでNative読取前拒否": True,
                  "Viewer形式資源": 8, "実Viewer通信": 0},
              "主設定": list(m.KEYS), "default経済会計": 0, "保存後予定": {"first2": {"会計": 16, "旧103対照": 8, "資源": 16},
                  "full54": {"会計": 432, "旧103対照": 216, "資源": 432, "主参加分母": 6048, "副参加分母": 5832}},
              "直接再用": "固定103保存aa1fの所有/部分返済/LD起動/実現/参加/保存点DD/同実入口/Viewer算術。式変更なし",
              "旧103市場LD10全JSON": "本停止では未実施。Root成功後、実Nativeから全4Book/場・除外0を再読照合する入口のみ",
              "SourceAと分離": "元連続Source3mode会計は含めず、StageB旧/対称各LD10四のみ。defaultは通知QA専用",
              "未実施": ["StageB実Native本文読取", "非0対称Source形成と合法Bind市場位相", "全原行別engine独立金融再生", "実Viewer通信", "未使用期間検証"],
              "StageB実Native/実新Source本文読取": 0, "Source/金融/Raw/CSV/HTTPの再実行": 0, "新日読取": 0,
              "再現CLI": "python -B -X utf8 work/104LD10の保存/集計.py --fixed <Root保存用固定.json> --fixed-sha <SHA256> --out <新規保存先>"}
    with args.out.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(output, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "保存コードSHA256": sha, "停止SHA256": m.OLD.digest(args.out)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
