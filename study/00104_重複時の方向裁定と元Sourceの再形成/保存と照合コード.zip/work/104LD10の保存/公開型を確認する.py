"""StageB runtimeが実Go型で出力した空Nativeと非0会計を別scopeで検査する。"""

import argparse
import copy
import importlib.util
import json
from pathlib import Path


def main():
    """
    機能: runtime公開型の空Bindと手製非0配送を保存器へ接続する。
    引数: --fixtures/--out/--viewer-dir(Path)は実Go型人工根と新規証拠保存先。
    返り値: None。自然Source形成、StageB市場成功、原板再生を主張しない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fixtures", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--viewer-dir", type=Path, required=True)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    spec = importlib.util.spec_from_file_location("StageB保存公開型人工", here / "集計.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    paths = sorted(args.fixtures.glob("*.json"))
    assert len(paths) == 5
    stop_path = here.parents[1] / "work/104LD10の全場比較/停止.json"
    stop_sha = "59d7cb6768ebe7825cf031d85012c83710ba3a2926ef8bd2d5d3f22c3c1a54d0"
    assert m.OLD.digest(stop_path) == stop_sha
    runtime_stop = m.OLD.load(stop_path)
    wanted = runtime_stop["人工確認"]["型人工SHA256"]
    actual = {str(p.resolve().relative_to(m.ROOT)).replace("\\", "/"): m.OLD.digest(p) for p in paths}
    m.equal(actual, wanted, "停止runtimeの全5型人工")
    before = {str(p.resolve()): m.OLD.digest(p) for p in paths}
    before[str(stop_path)] = stop_sha
    before[str(m.LEGACY_PATH)] = m.LEGACY_SHA
    empty_path = args.fixtures / "合法空Bindの8冊.json"
    empty = m.OLD.load(empty_path)
    value = empty["output"]
    original = m.OLD.freeze(empty)
    m.validate_native(value, value["session"]["id"])
    checked = m.inspect_scene(value)
    m.compare_control(value, empty["baseline103_api"])
    assert len(checked) == 8 and all(not b["positions"] and not b["orders"] for b in checked.values())
    assert all(b["totals"]["net_yen"] == 0 for b in checked.values())
    assert len(value["bindings"]) == 3 and set(value["tape_canonical_sha256"]) == set(m.MODES)
    assert original == m.OLD.freeze(empty)

    # ----------------------------------------
    # 非0系列はModeResultの公開会計型であり、合法Bindの成功へ合成しない。
    nonzero_books = nonzero_fills = compare_count = 0
    selected = None
    for path in paths:
        if path == empty_path:
            continue
        fixture = m.OLD.load(path)
        frozen = m.OLD.freeze(fixture)
        modes = fixture["modes"]
        assert set(modes) == set(m.MODES)
        session = modes["legacy"]["session"]
        books = {}
        for mode in m.MODES:
            current = modes[mode]
            assert current["complete"] and current["input_unchanged"]
            assert not current["source_reexecuted"] and not current["charts_recomputed"] and not current["gate_executed"]
            assert current["source_mode"] == mode and current["session"] == session
            assert current["main_keys"] == list(m.INNER_KEYS) and current["diagnostic_keys"] == []
            assert set(current["books"]) == set(m.INNER_KEYS)
            for key in m.INNER_KEYS:
                books[m.outer_key(mode, key)] = current["books"][key]
        saved = {"session": session, "books": books, "source_mode_by_book": m.SOURCE_MODES,
                 "grid_times": modes["legacy"]["grid_times"]}
        c = m.inspect_scene(saved)
        for key in m.INNER_KEYS:
            m.equal(books[m.outer_key("legacy", key)], fixture["baseline103_api"]["books"][key], "runtime旧103LD10全field")
        rows = m.scene_rows(saved, c)
        combined, diagnostics = m.aggregate(rows)
        comparison = m.compare_modes(c)
        for key, row in comparison.items():
            assert row["全差額"] == 0 and row["取得変更玉"] == row["前のみ玉"] == row["後のみ玉"] == 0
            compare_count += 1
        for key in m.KEYS:
            assert c[key]["positions"]
            m.equal(combined[key]["net_yen"], c[key]["totals"]["net_yen"], "公開型保存実額")
            shown = m.OLD.BASE.viewer_trades(books[key])
            assert len(shown) == len(books[key]["fills"])
            for trade, fill in zip(shown, books[key]["fills"]):
                assert trade["source_line"] == fill["quote"]["source_line"]
                assert trade["fee_yen"] == fill["fee_yen"] + fill["slip_yen"]
            nonzero_fills += len(shown)
        nonzero_books += len(c)
        assert m.OLD.freeze(fixture) == frozen
        selected = saved

    # ----------------------------------------
    # 出力は人工Viewerの形式だけであり、HTTP通信を実施しない。
    assert not args.viewer_dir.exists()
    args.viewer_dir.mkdir(parents=True)
    resources = m.save_viewer(selected, args.viewer_dir)
    assert len(resources) == 8 and len({r["id"] for r in resources}) == 8
    m.OLD.BASE.write_json(args.viewer_dir / "一覧.resources.json", {"schema_version": 1, "path_base": "catalog", "resources": resources})
    rejected = []
    for name in ("所属偽装", "内key改名", "default経済追加", "外場偽装", "binding対照未成立", "旧103差"):
        bad = copy.deepcopy(value)
        baseline = copy.deepcopy(empty["baseline103_api"])
        key = m.KEYS[0]
        if name == "所属偽装": bad["source_mode_by_book"][key] = "symmetric"
        elif name == "内key改名": bad["books"][key]["key"] = key
        elif name == "default経済追加": bad["books"]["default_" + m.INNER_KEYS[0]] = copy.deepcopy(bad["books"][key])
        elif name == "外場偽装": bad["session"]["id"] = "別_Day"
        elif name == "binding対照未成立": bad["bindings"]["default"]["notifications_equal_old"] = False
        elif name == "旧103差": baseline["books"][m.INNER_KEYS[0]]["totals"]["net_yen"] += 1
        try:
            m.validate_native(bad, bad["session"]["id"])
            m.inspect_scene(bad)
            m.compare_control(bad, baseline)
        except (ValueError, KeyError):
            rejected.append(name)
        else:
            raise AssertionError("型破損を成功化:" + name)
    for path, sha in before.items():
        assert m.OLD.digest(Path(path)) == sha
    result = {"成功": True, "scope": "runtime実Go型の合法空Native8と非0ModeResult32を別scopeで保存検算。自然対称Source形成/非0合法Bind市場位相は未検証",
              "合法空BindのNative会計": 8, "非0Go型会計": nonzero_books, "非0全Fill対応": nonzero_fills,
              "二宣言modeの比較": compare_count, "旧103LD10全JSON": {"空": 4, "非0": 16, "除外": []},
              "Viewer形式資源": len(resources), "実Viewer通信": 0, "拒否": rejected,
              "公開型入力前後SHA256": before, "前後不変": True, "保存コードSHA256": m.OLD.digest(here / "集計.py"),
              "未実施": ["StageB実Native読取", "Source/金融再実行", "Raw/CSV読取", "非0新Source効果検証"]}
    with args.out.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "空": 8, "非0": nonzero_books, "Fill": nonzero_fills, "比較": compare_count, "拒否": len(rejected)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
