# StageB LD10八設定の保存（市場前停止候補）

固定103保存 `aa1f27f56a54db0288c6e48d83bd292f424af720a5573fa774349489b206bd57` を直接importする。旧103/金融本文/条件/正式成果物は変更しない。SourceAの元連続3mode/486Sourcebookと、StageB旧/対称×LD10四費用の主8設定を分ける。defaultはSource生成の旧対照だけで、経済Bookへ追加しない。

`集計.py` の純APIは `inspect_scene/compare_control/scene_rows/compare_modes/save_viewer/aggregate`。外keyは `legacy_` / `symmetric_` + `LD10_B5Q_P0_Cx_Dy`。`source_mode_by_book`で所属を検査する。内部ActualResult.Key/Config/注文/実玉/全fieldは旧LD10の原値のまま103 verify_bookへ渡し、金融本文を射影/改名しない。

旧103から直接使うのは所有/部分返済/Source比例返済/予約/費用/MTM保存点/LD起動のverify_book、主6048/副5832の参加、u正益とProtectionActiveの別分母、実現集計/保存点連結DD、日夜/日別、同実入口の指紋比較、Viewer実Fill変換である。全原行の別engine金融再生を実施した証明ではない。

同実入口はSourceIdentity全値＋要求時計/quote/取得quote/価格/量/方向等の旧指紋を再用する。Source番号だけで同じ玉へ対応付けず、番号等が変われば厳密対応の片参加等へ残す。未参加/退出後仮想利益/MFEは算出しない。

Viewerは主8用の `104B_{outerKey}_{session}` namespaceへ保存し、SourceAの資料を混ぜない。全54なら8×54=432資源、first2なら16。現段階は人工8形式生成だけで実Viewer通信0。金融Nativeはruntimeの参照/SHAで残し、本保存器で元Source全量や旧Nativeを重複転記しない。

## 現時点の人工scope

初版では停止済み103Go型4系列のLD10四だけを二つのSourceMode namespaceへ同値copyし、32会計/160実Fill対応/16比較・Viewer8資源を確認した。これはnamespace/旧会計保存の限定型人工で、新Sourceの効果や新runtimeの成功ではない。9破損を拒否し、原型/固定103不変を確認した。

次にruntime停止 `59d7cb6768ebe7825cf031d85012c83710ba3a2926ef8bd2d5d3f22c3c1a54d0` の実Go型export全5本へ接続した。合法空BindのNative8と、停止103の手製通知を二modeへ同じまま流した非0ModeResult32は別scopeである。160件の全Fill保存対応、旧103LD10の全文（空4・非0 16、除外なし）、同実入口比較16、Viewer形式8、6種の破損拒否を確認した。自然対称Source形成や非0合法Bind市場位相は未検証とする。人工中の一時FileRefは残存を仮定せず、実Go型に同梱されたbaseline103_apiだけを照合した。これを実市場のFileRef検査へ流用しない。

metadata人工は正常1、未固定・未成功・別条件・集合/旧対照不足・default経済化・前後差等10拒否。実際のprepare口も未固定Root JSONだけを読んで拒否し、Native読取と出力作成へ進まないことを確認する。

```powershell
python -B -X utf8 work/104LD10の保存/人工を確認する.py --out '<新規人工receipt.json>' --viewer-dir '<新規人工dir>'
python -B -X utf8 work/104LD10の保存/公開型を確認する.py --fixtures work/104LD10の全場比較/人工/型export --out '<新規公開型receipt.json>' --viewer-dir '<新規公開型Viewerdir>'
python -B -X utf8 work/104LD10の保存/metadataを確認する.py --out '<新規metadatareceipt.json>'
```

## Root成功後の保存入口

市場前に本保存コードを停止し、RootがStageB金融成功を確認してから保存用JSONを事後固定する。`--fixed-sha` はそのJSONの現物SHAとする。相対FileRefは保存用JSON又は当該参照を持つJSONのディレクトリ基準。runtimeのcode_sha256キーはrepo基準又は絶対pathを維持する。

```json
{
  "version": 1,
  "trial": 104,
  "phase": "StageB",
  "fixed": true,
  "stage": "first2",
  "condition": {"path": "<同じStageB条件.json>", "sha256": "<64桁>"},
  "completion": {"path": "<StageB金融の完了.json>", "sha256": "<64桁>"},
  "code": {"path": "<本集計.py>", "sha256": "<停止した本体の64桁>"}
}
```

```powershell
python -B -X utf8 work/104LD10の保存/集計.py --fixed '<Root保存用固定.json>' --fixed-sha '<64桁>' --out '<存在しない保存先>'
```

Conditionの8設定は `legacy/symmetric` の順にそれぞれ `P0/LD10 × C0/C5 × D0/D1`。Completionは先頭2なら16冊/旧103対照8冊、全54なら432冊/旧対照216冊、default冊数0を必須とする。結果参照は `results[].native.{path,sha256}` で、totalsを補完せず各Nativeの全8帳簿から計算する。全54の場IDは既使用9月21日〜10月27日の54場だけ。full54はruntimeが同条件first2成功を検査した完了である。

実Nativeではversion/trial/完結/入力不変、経済2modeと通知QA3modeの区別を検査する。実使用したcondition/code/binary/Source結果・記録/旧Tape/旧103保存の現物SHAと金融完了beforeを結ぶ。旧103の保存Nativeを再読し、legacy側LD10四を全field・除外0で再照合する。新Source記録は指紋を照合するだけで形成/再生しない。Source/Scalar結合そのものはruntime/binderの責務であり、本保存器の独立全原行監査成功とは呼ばない。

出力は `結果.json/.md`、`保存会計の確認.json`、`一覧.resources.json` と主8の実約定trades。成功の根拠は保存会計の確認も含めて確認する。集計はu正益後赤字額と保護起動後赤字額を別に残し、主6048/副5832、日夜/日別、売買、Source/保護返済を分ける。全て費用後実額であり、感度や両modeを独立市場標本にしない。

RootのStageB金融成功通知まで実金融/新Sourceの保存結果の実本文は読まない。本停止では実StageB本文読取、Source/金融/Raw/CSVの再実行、実Viewer通信はいずれも0。未使用・未検証・対象外を埋めず、SourceA元連続の損益をLD10後の実績と混同しない。
