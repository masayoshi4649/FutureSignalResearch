"""固定103のGo金融型を用い、StageBの外側namespaceだけを人工で確認する。"""

import argparse
import copy
from decimal import Decimal
import hashlib
import importlib.util
import json
from pathlib import Path


def main():
    """
    機能: 旧Go型LD10四を二namespaceへ写した限定人工と破損を検査する。
    引数: --out(Path)は新規receipt、--viewer-dir(Path)は新規人工Viewer保存先。
    返り値: None。新Source形成/StageB金融再生/市場本文読取はしない。
    """
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--viewer-dir", type=Path, required=True)
    args = parser.parse_args()
    here = Path(__file__).resolve().parent
    repo = here.parents[1]
    spec = importlib.util.spec_from_file_location("StageB保存型人工", here / "集計.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    origin = repo / "work/103多玉の保護会計/人工/停止版"
    stop = repo / "work/103多玉の保護会計/停止.json"
    assert m.OLD.digest(stop) == "e051a2401c8919835adfea52bf346d644707239fd030f0b13f101586b4c1d52b"
    paths = sorted(origin.glob("*.json"))
    assert len(paths) == 4
    before = {str(p): m.OLD.digest(p) for p in [stop, m.LEGACY_PATH] + paths}
    values = []
    count = fills = comparisons = 0
    for path in paths:
        old = m.OLD.load(path)
        value = {"books": {m.outer_key(mode, key): copy.deepcopy(old["actors"][key]) for mode in m.MODES for key in m.INNER_KEYS}, "source_mode_by_book": copy.deepcopy(m.SOURCE_MODES), "control103": {"all": True, "books": 4, "keys": list(m.INNER_KEYS), "excluded": [], "baseline_sha256": before[str(path)]}}
        baseline = {"books": {key: old["actors"][key] for key in m.INNER_KEYS}}
        frozen = m.OLD.freeze(value)
        checked = m.inspect_scene(value)
        m.compare_control(value, baseline)
        rows = m.scene_rows(value, checked)
        combined, _ = m.aggregate(rows)
        compared = m.compare_modes(checked)
        count += len(checked)
        for row in compared.values():
            assert row["全差額"] == 0 and row["取得変更玉"] == 0 and row["前のみ玉"] == row["後のみ玉"] == 0
            comparisons += 1
        for key in m.KEYS:
            assert combined[key]["net_yen"] == checked[key]["totals"]["net_yen"]
            book = value["books"][key]
            shown = m.OLD.BASE.viewer_trades(book)
            assert len(shown) == len(book["fills"])
            fills += len(shown)
            for trade, fill in zip(shown, book["fills"]):
                assert trade["source_line"] == fill["quote"]["source_line"]
                assert trade["fee_yen"] == fill["fee_yen"] + fill["slip_yen"]
        assert m.OLD.freeze(value) == frozen
        values.append((value, baseline))
    assert not args.viewer_dir.exists()
    args.viewer_dir.mkdir(parents=True, exist_ok=False)
    resources = m.save_viewer(values[0][0], args.viewer_dir)
    assert len(resources) == 8 and len({v["id"] for v in resources}) == 8
    assert all(v["id"].startswith("104B_") and v["method_id"] in m.KEYS for v in resources)
    m.OLD.BASE.write_json(args.viewer_dir / "一覧.resources.json", {"schema_version": 1, "path_base": "catalog", "resources": resources})
    rejected = []
    for name in ("mode偽装", "外key欠落", "内key改名", "Config改名", "費用半円", "LD起動前倒し", "Source別所有", "旧103差", "旧対照除外"):
        value, baseline = copy.deepcopy(values[0])
        key = m.KEYS[0]
        if name == "mode偽装": value["source_mode_by_book"][key] = "symmetric"
        elif name == "外key欠落": value["books"].pop(key)
        elif name == "内key改名": value["books"][key]["key"] = key
        elif name == "Config改名": value["books"][key]["config"]["activation_policy"] = "LD05"
        elif name == "費用半円": value["books"][key]["fills"][0]["fee_yen"] += Decimal("0.5")
        elif name == "LD起動前倒し":
            p = value["books"][key]["positions"][0]
            p["activation"] = copy.deepcopy(p["marks"]["first_unit_positive"])
        elif name == "Source別所有": value["books"][key]["positions"][0]["source_hold_id"] = "別所有を番号で埋めない"
        elif name == "旧103差": baseline["books"][m.INNER_KEYS[0]]["totals"]["net_yen"] += 1
        elif name == "旧対照除外": value["control103"]["excluded"] = ["key"]
        try:
            m.inspect_scene(value)
            m.compare_control(value, baseline)
        except (ValueError, KeyError):
            rejected.append(name)
        else:
            raise AssertionError("破損を成功化:" + name)
    for path, expected in before.items():
        assert m.OLD.digest(Path(path)) == expected
    result = {"成功": True, "scope": "固定103 Go型LD10四を二つの外namespaceへ同値copyした保存/表示人工。新Source効果/StageB runtime成功ではない。", "Go由来型会計": count, "実FillViewer対応": fills, "比較感度": comparisons, "実Viewer通信": 0, "人工Viewer資源": 8, "拒否": rejected, "元人工/固定103前後不変": True, "入力SHA256": before, "StageB実金融/新Source本文読取": 0, "Source/金融再実行": 0, "codeSHA256": m.OLD.digest(here / "集計.py")}
    with args.out.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"成功": True, "会計": count, "Fill": fills, "比較": comparisons, "拒否": len(rejected)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
