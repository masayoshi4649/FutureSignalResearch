"""主B金融成功後に限り、固定済み保存器の実行参照を新規保存する。"""

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
CODE = ROOT / "work/104LD10の保存/集計.py"
CODE_SHA = "0409ae3f0f084bedac0196ca5bd62a356c074f7c27e464854f1d5dd5645c7900"


def sha(path: Path) -> str:
    """
    機能: 固定済み内容のSHA256を求める。
    引数: path(Path)は実在ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 成功した主B条件/完了/保存コードの3参照を初回固定する。
    引数: --condition/--condition-sha/--completion/--completion-sha/--stage/--outは固定参照と新規保存先。
    返り値: None。metadataを検査して固定JSONだけを保存し、Native読取/金融/Viewerを実行しない。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--condition", type=Path, required=True)
    parser.add_argument("--condition-sha", required=True)
    parser.add_argument("--completion", type=Path, required=True)
    parser.add_argument("--completion-sha", required=True)
    parser.add_argument("--stage", choices=["first2", "full54"], required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    condition = args.condition.resolve()
    completion = args.completion.resolve()
    output = args.out.resolve()
    assert not output.exists()
    assert sha(condition) == args.condition_sha and sha(completion) == args.completion_sha
    assert sha(CODE) == CODE_SHA
    condition_value = json.loads(condition.read_text(encoding="utf-8-sig"))
    completion_value = json.loads(completion.read_text(encoding="utf-8-sig"))
    spec = importlib.util.spec_from_file_location("保存104の固定検査", CODE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    tasks = module.validate_completion(condition_value, completion_value, args.stage, args.condition_sha)
    assert len(tasks) == (2 if args.stage == "first2" else 54)
    assert completion_value["before"].get(str(condition)) == args.condition_sha

    # ----------------------------------------
    # FileRefの基準はこれから保存する固定JSONの親directoryとする。
    def ref(path: Path, expected: str) -> dict:
        """
        機能: 保存用固定JSONからの相対参照を作る。
        引数: path(Path)、expected(str)は実位置と固定指紋。
        返り値: dictはpath/sha256。
        """
        assert sha(path) == expected
        return {"path": os.path.relpath(path, output.parent).replace("\\", "/"), "sha256": expected}
    value = {"version": 1, "trial": 104, "phase": "StageB", "fixed": True, "stage": args.stage,
             "condition": ref(condition, args.condition_sha), "completion": ref(completion, args.completion_sha),
             "code": ref(CODE, CODE_SHA)}
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"成功": True, "固定": str(output), "固定SHA256": sha(output), "場": len(tasks),
                      "Native読取": 0, "金融再実行": 0, "Viewer実行": 0}, ensure_ascii=False))


if __name__ == "__main__":
    main()
