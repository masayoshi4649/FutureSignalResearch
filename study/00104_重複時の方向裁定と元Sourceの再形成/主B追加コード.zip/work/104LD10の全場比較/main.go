package main

import (
	"flag"
	"fmt"
	"os"
	"path/filepath"
)

// main はRoot固定後のfirst2/full54だけを新規directoryへ実行します。
//
// 引数: condition/condition-sha/stage/out/first2/first2-shaのCLIです。
// 返り値: なし。未固定/不完結/旧対照差は終了1です。
func main() {
	a := Arguments{}
	flag.StringVar(&a.Condition, "condition", "", "Root固定条件")
	flag.StringVar(&a.ConditionSHA, "condition-sha", "", "条件SHA")
	flag.StringVar(&a.Stage, "stage", "first2", "first2/full54")
	flag.StringVar(&a.Out, "out", "", "新規出力")
	flag.StringVar(&a.First2, "first2", "", "同条件先頭2完了")
	flag.StringVar(&a.First2SHA, "first2-sha", "", "先頭2SHA")
	flag.Parse()
	root, e := os.Getwd()
	if e == nil {
		for {
			d, de := os.Stat(filepath.Join(root, "study"))
			s, se := os.Stat(filepath.Join(root, "scripts"))
			if de == nil && se == nil && d.IsDir() && s.IsDir() {
				break
			}
			next := filepath.Dir(root)
			if next == root {
				e = fmt.Errorf("repo基準なし")
				break
			}
			root = next
		}
	}
	if e == nil {
		exe, x := os.Executable()
		e = x
		if e == nil {
			_, e = RunMarket(a, root, exe)
		}
	}
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
}
