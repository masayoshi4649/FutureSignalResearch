package main

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	origin "github.com/masayoshi4649/SessionTradeExecuter/delayedreplay103"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	finance "github.com/masayoshi4649/SessionTradeExecuter/minidelayed103"
	binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
)

// TestOriginalNonzeroAPI は停止103の4型人工を同じ四Actorへ配送します。
//
// 引数: t(*testing.T)は人工試験器です。
// 返り値: なし。手製Source/ATRのAPI器具で、Bind市場位相や対称Source形成の証明ではありません。
func TestOriginalNonzeroAPI(t *testing.T) {
	for _, name := range []string{"方向1_未知ATRfalse.json", "方向-1_未知ATRfalse.json", "方向1_未知ATRtrue.json", "方向-1_未知ATRtrue.json"} {
		t.Run(name, func(t *testing.T) {
			path := filepath.Join("..", "103多玉の一定利益保護", "人工", "停止版", name)
			var fixture struct {
				Tape   tape.Tape        `json:"tape"`
				Output origin.RunResult `json:"output"`
			}
			if e := decode(path, &fixture, false, false); e != nil {
				t.Fatal(e)
			}
			states := []map[string][]byte{}
			base, e := origin.RunObserved(fixture.Tape, func(_ tape.TapeEvent, books map[string]finance.ActualResult) error {
				state := map[string][]byte{}
				for _, c := range SelectedConfigs() {
					key := origin.ConfigKey(c)
					b, x := json.Marshal(books[key])
					if x != nil {
						return x
					}
					state[key] = b
				}
				states = append(states, state)
				return nil
			})
			if e != nil {
				t.Fatal(e)
			}
			modes := map[string]ModeResult{}
			for _, mode := range []string{"legacy", "symmetric"} {
				index := 0
				value, e := RunModeObserved(fixture.Tape, mode, func(_ tape.TapeEvent, books map[string]finance.ActualResult) error {
					if len(books) != 4 || index >= len(states) {
						t.Fatal("四冊時点集合")
					}
					for key, book := range books {
						b, e := json.Marshal(book)
						if e != nil {
							return e
						}
						if !bytes.Equal(b, states[index][key]) {
							t.Fatalf("event%d/%s 全JSON差", index, key)
						}
					}
					index++
					return nil
				})
				if e != nil || !value.Complete || !value.InputUnchanged || len(value.Books) != 4 || index != len(states) {
					t.Fatal("旧配送/四冊完結", e)
				}
				for key, book := range value.Books {
					b, _ := json.Marshal(book)
					old, _ := json.Marshal(base.Books[key])
					saved, _ := json.Marshal(fixture.Output.Books[key])
					if !bytes.Equal(b, old) || !bytes.Equal(b, saved) || book.Totals.EntryQuantity <= 0 {
						t.Fatal("旧103非0四冊全JSON差")
					}
				}
				modes[mode] = value
			}
			if root := os.Getenv("LD10_104_EXPORT_ROOT"); root != "" {
				e = writeNew(filepath.Join(root, name), map[string]any{"scope": "停止103の手製Source/ATR金融API型。同じ通知を二つの宣言modeへ配送。新対称Source形成/合法Bind市場位相は未検証", "tape": fixture.Tape, "baseline103_api": base, "modes": modes}, false)
				if e != nil {
					t.Fatal(e)
				}
			}
			if _, e = RunMode(fixture.Tape, "default"); e == nil {
				t.Fatal("defaultの経済会計を作成")
			}
		})
	}
}

// writeRows は上流と同じgzip JSONLへ型人工を新規保存します。
//
// 引数: path(string)、rows([]binder.SourceRecord)は新規先と手製codec値です。
// 返り値: errorは保存失敗です。自然Sourceを生成しません。
func writeRows(path string, rows []binder.SourceRecord) error {
	f, e := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return e
	}
	z := newGzip(f)
	for _, row := range rows {
		if e = z.encoder.Encode(row); e != nil {
			break
		}
	}
	if close := z.close(); e == nil {
		e = close
	}
	if close := f.Close(); e == nil {
		e = close
	}
	return e
}

// TestBoundEmptyNative は停止Bindの合法空通知を8冊保存型へ結びます。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: なし。旧103対照・outer8名・default経済0を型人工で確認します。
func TestBoundEmptyNative(t *testing.T) {
	var fixture struct {
		Old     tape.Tape             `json:"old_tape"`
		Records []binder.SourceRecord `json:"records"`
	}
	if e := decode(filepath.Join("..", "104新Sourceと判断時計の結合案", "人工", "停止版", "合法空通知.json"), &fixture, false, false); e != nil {
		t.Fatal(e)
	}
	dir := t.TempDir()
	oldPath := filepath.Join(dir, "old.json.gz")
	if e := writeNew(oldPath, fixture.Old, true); e != nil {
		t.Fatal(e)
	}
	oldSHA, _ := origin.FileSHA(oldPath)
	base, e := origin.RunTape(fixture.Old)
	if e != nil {
		t.Fatal(e)
	}
	baselinePath := filepath.Join(dir, "baseline.json.gz")
	if e = writeNew(baselinePath, base, true); e != nil {
		t.Fatal(e)
	}
	baselineSHA, _ := origin.FileSHA(baselinePath)
	rp := filepath.Join(dir, "records.jsonl.gz")
	if e = writeRows(rp, fixture.Records); e != nil {
		t.Fatal(e)
	}
	_, counts, e := readRecords(rp)
	if e != nil {
		t.Fatal(e)
	}
	rh, _ := origin.FileSHA(rp)
	source := []SourceCase{}
	for _, mode := range []string{"legacy", "default", "symmetric"} {
		source = append(source, SourceCase{Session: fixture.Old.Session.ID, Mode: mode, Records: FileRef{rp, rh}, Result: FileRef{baselinePath, baselineSHA}, Counts: counts})
	}
	value, e := RunScene(fixture.Old.Session.ID, FileRef{oldPath, oldSHA}, FileRef{baselinePath, baselineSHA}, source)
	if e != nil {
		t.Fatal(e)
	}
	if !value.Complete || len(value.Books) != 8 || len(value.Bindings) != 3 || value.Control.Books != 4 || !value.Control.All || len(value.Control.Excluded) != 0 || len(value.TapeSHA) != 2 {
		t.Fatal("8冊/三Bind/旧四集合")
	}
	for key, b := range value.Books {
		mode := value.SourceMode[key]
		if key != mode+"_"+b.Key || (mode != "legacy" && mode != "symmetric") || b.Config.ActivationPolicy != finance.ActivationLD10 {
			t.Fatal("outer/inner所属又は設定差")
		}
	}
	if root := os.Getenv("LD10_104_EXPORT_ROOT"); root != "" {
		path := filepath.Join(root, "合法空Bindの8冊.json")
		if e = writeNew(path, map[string]any{"scope": "合法空通知codecの8冊。自然Source形成/市場非0ではない", "old_tape": fixture.Old, "records": fixture.Records, "baseline103_api": base, "output": value}, false); e != nil {
			t.Fatal(e)
		}
	}
	bad := base
	bad.Books = map[string]finance.ActualResult{}
	for k, b := range base.Books {
		bad.Books[k] = b
	}
	for _, c := range SelectedConfigs() {
		k := origin.ConfigKey(c)
		b := bad.Books[k]
		b.Totals.NetYen++
		bad.Books[k] = b
		break
	}
	badPath := filepath.Join(dir, "bad.json.gz")
	if e = writeNew(badPath, bad, true); e != nil {
		t.Fatal(e)
	}
	legacy, e := RunMode(fixture.Old, "legacy")
	if e != nil {
		t.Fatal(e)
	}
	if _, e = CompareLegacy(legacy, badPath, "人工"); e == nil {
		t.Fatal("旧Book金額破損を受理")
	}
	source[0].Counts.Calls++
	if _, e = RunScene(fixture.Old.Session.ID, FileRef{oldPath, oldSHA}, FileRef{baselinePath, baselineSHA}, source); e == nil {
		t.Fatal("上流counter差を受理")
	}
}
