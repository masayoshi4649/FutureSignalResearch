"""停止first2 CLIの標準JSON/gzip読取と公開metadata型だけを機械抽出する。"""

from pathlib import Path


def main() -> None:
    """
    機能: 新しい全場CLIに必要な小型IOだけを由来付きで抽出する。
    引数: なし。
    返り値: None。Source/金融/市場入力を実行しない。
    """
    here = Path(__file__).resolve().parent
    src = here.parent / "104Source結合の実行"
    main = (src / "main.go").read_text(encoding="utf-8")
    bind = (src / "bind.go").read_text(encoding="utf-8")
    types = main[main.index("type Counts struct"):main.index("type Prepared struct")]
    helpers = main[main.index("// validSHA"):main.index("// validateSource")]
    reader = bind[bind.index("// readRecords"):bind.index("// compareFinal")]
    text = '''// 停止first2 CLI e795c615の公開metadata型と標準IO本文を無変更抽出。
package main
import (
    "compress/gzip"
    "encoding/hex"
    "encoding/json"
    "fmt"
    "io"
    "os"
    "path/filepath"
    "strings"
    run103 "github.com/masayoshi4649/SessionTradeExecuter/delayedreplay103"
    binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
)
type FileRef struct { Path string `json:"path"`; SHA string `json:"sha256"` }
'''+types+helpers+reader
    with (here / "io.go").open("x", encoding="utf-8", newline="\n") as out:
        out.write(text)


if __name__ == "__main__":
    main()
