package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"strings"

	origin "github.com/masayoshi4649/SessionTradeExecuter/delayedreplay103"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	finance "github.com/masayoshi4649/SessionTradeExecuter/minidelayed103"
	binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
)

const Old100IndexSHA = "4db6812dda91ae4235d15ce5619c19a7dffa305f24ec3f577332d8665b49610f"
const Old103IndexSHA = "f07280a74d90cb8df9a74d5074370b729e825c1fc19c6a7fe8104ad68c7b68fe"

type Config struct {
	SourceMode string                   `json:"source_mode"`
	Policy     string                   `json:"policy"`
	Activation finance.ActivationPolicy `json:"activation_policy"`
	Slip       float64                  `json:"slip_pts"`
	Delay      int                      `json:"delay_seconds"`
}
type Condition struct {
	Version   int               `json:"version"`
	Trial     int               `json:"trial"`
	Fixed     bool              `json:"fixed"`
	Source    FileRef           `json:"source_full"`
	Index     FileRef           `json:"old100_tape_index"`
	FirstBind FileRef           `json:"first2_bind"`
	Binder    FileRef           `json:"binder_stop"`
	Baseline  FileRef           `json:"baseline103_index"`
	Binary    FileRef           `json:"binary"`
	Code      map[string]string `json:"code_sha256"`
	Configs   []Config          `json:"configs"`
}
type Arguments struct{ Condition, ConditionSHA, Stage, Out, First2, First2SHA string }
type NativeIndex struct {
	Success  bool `json:"成功"`
	Sessions int  `json:"場数"`
	Books    int  `json:"会計"`
	Refs     []struct {
		Session string `json:"session"`
		Path    string `json:"path"`
		SHA     string `json:"sha256"`
	} `json:"参照"`
}
type BindCompletion struct {
	Version       int               `json:"version"`
	Trial         int               `json:"trial"`
	Stage         string            `json:"stage"`
	Success       bool              `json:"success"`
	Sessions      int               `json:"sessions"`
	ConditionSHA  string            `json:"condition_sha256"`
	Before        map[string]string `json:"before"`
	After         map[string]string `json:"after"`
	Unchanged     bool              `json:"unchanged"`
	SourceFormed  bool              `json:"source_reformed"`
	RawCSV        int               `json:"raw_csv_read"`
	EconomicBooks int               `json:"economic_adopted_books"`
	Scope         string            `json:"scope"`
	Error         string            `json:"error,omitempty"`
	Cases         []struct {
		Session       string       `json:"session"`
		Mode          string       `json:"mode"`
		SourceRecords FileRef      `json:"source_records"`
		SourceResult  FileRef      `json:"source_result"`
		OldTape       FileRef      `json:"old_tape"`
		NewTape       FileRef      `json:"new_tape"`
		Binding       binder.Proof `json:"binding"`
		Compatibility struct {
			Performed     bool     `json:"performed"`
			AllPoints     bool     `json:"all_points"`
			Books         int      `json:"books"`
			Excluded      []string `json:"book_field_excluded"`
			EnvelopeEqual bool     `json:"whole_envelope_equal"`
			FinalSHA      string   `json:"final_books_json_sha256,omitempty"`
			Scope         string   `json:"scope"`
		} `json:"compatibility_103"`
		Error string `json:"error,omitempty"`
	} `json:"cases"`
}
type Control struct {
	All         bool     `json:"all"`
	Books       int      `json:"books"`
	Keys        []string `json:"keys"`
	Excluded    []string `json:"excluded"`
	BaselineSHA string   `json:"baseline_sha256"`
}
type Native struct {
	Version          int                             `json:"version"`
	Trial            int                             `json:"trial"`
	Session          finance.Session                 `json:"session"`
	Books            map[string]finance.ActualResult `json:"books"`
	SourceMode       map[string]string               `json:"source_mode_by_book"`
	Bindings         map[string]binder.Proof         `json:"bindings"`
	Records          map[string]FileRef              `json:"input_source_records"`
	SourceResults    map[string]FileRef              `json:"source_results"`
	OldTape          FileRef                         `json:"old_tape"`
	Baseline103      FileRef                         `json:"baseline103"`
	TapeSHA          map[string]string               `json:"tape_canonical_sha256"`
	Control          Control                         `json:"control103"`
	Events           origin.EventCounts              `json:"events"`
	GridTimes        []float64                       `json:"grid_times"`
	Complete         bool                            `json:"complete"`
	InputUnchanged   bool                            `json:"input_unchanged"`
	SourceReexecuted bool                            `json:"source_reexecuted"`
	ChartsRecomputed bool                            `json:"charts_recomputed"`
	GateExecuted     bool                            `json:"gate_executed"`
	Scope            string                          `json:"scope"`
}
type SceneReceipt struct {
	Session       string  `json:"session"`
	Native        FileRef `json:"native"`
	Books         int     `json:"books"`
	LegacyControl int     `json:"legacy_control_books"`
	Error         string  `json:"error,omitempty"`
}
type Completion struct {
	Version          int               `json:"version"`
	Trial            int               `json:"trial"`
	Stage            string            `json:"stage"`
	Success          bool              `json:"success"`
	ConditionSHA     string            `json:"condition_sha256"`
	Sessions         int               `json:"sessions"`
	BooksPerScene    int               `json:"books_per_scene"`
	Books            int               `json:"books"`
	LegacyControl    int               `json:"legacy_control_books"`
	DefaultBooks     int               `json:"default_books"`
	Configs          []Config          `json:"configs"`
	Results          []SceneReceipt    `json:"results"`
	Before           map[string]string `json:"before"`
	After            map[string]string `json:"after"`
	Unchanged        bool              `json:"unchanged"`
	First2           *FileRef          `json:"first2,omitempty"`
	SourceReexecuted bool              `json:"source_reexecuted"`
	ChartsRecomputed bool              `json:"charts_recomputed"`
	GateExecuted     bool              `json:"gate_executed"`
	RawCSV           int               `json:"raw_csv_read"`
	Error            string            `json:"error,omitempty"`
}
type Prepared struct {
	Condition     Condition
	Source        SourceCompletion
	IDs           []string
	Old, Baseline map[string]FileRef
	Before        map[string]string
}

// Configurations は旧103のLD10四だけを旧/対称の固定順へ展開します。
//
// 引数: なし。返り値: []Configは全8設定です。defaultの経済口座はありません。
func Configurations() []Config {
	out := []Config{}
	for _, mode := range []string{"legacy", "symmetric"} {
		for _, c := range SelectedConfigs() {
			out = append(out, Config{mode, c.Policy, c.Activation, c.Slip, c.Delay})
		}
	}
	return out
}

// validateSource は全54場×3modeの上流成功と一意性を検査します。
//
// 引数: source(SourceCompletion)はSourceA全54完了metadataです。
// 返り値: errorは未完結/集合/参照不整合です。入力本文を開きません。
func validateSource(source SourceCompletion) error {
	ids := origin.AllowedSessions()
	if source.Version != 1 || source.Trial != 104 || source.Stage != "full54" || !source.Success || source.Error != "" || source.Sessions != 54 || len(source.Cases) != 162 || !source.Unchanged || len(source.Before) == 0 || !reflect.DeepEqual(source.Before, source.After) || !source.Formed || source.Finance || !validSHA(source.ConditionSHA) {
		return fmt.Errorf("SourceA全54成功が必須です")
	}
	wanted := map[string]bool{}
	for _, id := range ids {
		for _, mode := range []string{"legacy", "default", "symmetric"} {
			wanted[id+"/"+mode] = true
		}
	}
	seen := map[string]bool{}
	for _, r := range source.Cases {
		key := r.Session + "/" + r.Mode
		if !wanted[key] || seen[key] || r.Error != "" || r.Match != (r.Mode != "symmetric") {
			return fmt.Errorf("Source全162case不正:%s", key)
		}
		seen[key] = true
		for _, ref := range []FileRef{r.Result, r.Records} {
			if strings.TrimSpace(ref.Path) == "" || !validSHA(ref.SHA) {
				return fmt.Errorf("Source出力未固定")
			}
		}
		if r.Counts.Calls <= 0 || r.Counts.Calls != r.Counts.Steps+r.Counts.Forces || r.Counts.Steps <= 0 || r.Counts.Forces <= 0 {
			return fmt.Errorf("Source通知counter不正")
		}
	}
	return nil
}

// validateBindReceipt は実先頭2結合と全Sourceの同じ先頭6出力を結びます。
//
// 引数: b(BindCompletion)、source(SourceCompletion)、old(map)は固定済み互換proofと全Source/旧Tape参照です。
// 返り値: errorは成功/一意性/出典/全16互換の不足です。
func validateBindReceipt(b BindCompletion, source SourceCompletion, old map[string]FileRef) error {
	if b.Version != 1 || b.Trial != 104 || b.Stage != "first2" || !b.Success || b.Error != "" || b.Sessions != 2 || len(b.Cases) != 6 || !b.Unchanged || len(b.Before) == 0 || !reflect.DeepEqual(b.Before, b.After) || b.SourceFormed || b.RawCSV != 0 || b.EconomicBooks != 0 || !validSHA(b.ConditionSHA) {
		return fmt.Errorf("実first2結合成功が必須です")
	}
	refs := map[string]SourceCase{}
	for _, r := range source.Cases {
		refs[r.Session+"/"+r.Mode] = r
	}
	wanted := map[string]bool{}
	for _, id := range origin.AllowedSessions()[:2] {
		for _, mode := range []string{"legacy", "default", "symmetric"} {
			wanted[id+"/"+mode] = true
		}
	}
	for _, r := range b.Cases {
		key := r.Session + "/" + r.Mode
		if !wanted[key] || r.Error != "" {
			return fmt.Errorf("実結合case不正")
		}
		delete(wanted, key)
		src := refs[key]
		if src.Records.SHA != r.SourceRecords.SHA || src.Result.SHA != r.SourceResult.SHA || old[r.Session].SHA != r.OldTape.SHA || !validSHA(r.NewTape.SHA) || r.Binding.ModeDeclared != r.Mode || r.Binding.SourceFormedHere || r.Binding.FinancialExecutedHere {
			return fmt.Errorf("実結合の由来差:%s", key)
		}
		c := r.Compatibility
		if r.Mode != "symmetric" {
			if !r.Binding.NotificationsEqualOld || !c.Performed || c.Books != 16 || len(c.Excluded) != 0 || !validSHA(c.FinalSHA) {
				return fmt.Errorf("先頭2の旧全16互換不足")
			}
		} else if c.Performed || c.Books != 0 {
			return fmt.Errorf("対称QAへ金融流用")
		}
	}
	return nil
}

// Prepare は同条件の2→54と固定5参照/code/binaryを対象本文より先に検査します。
//
// 引数: a(Arguments)、root/exe(string)は実行設定とrepo/実行物です。
// 返り値: Prepared/errorは固定対象又は拒否です。Raw/CSVは開きません。
func Prepare(a Arguments, root, exe string) (Prepared, error) {
	p := Prepared{Old: map[string]FileRef{}, Baseline: map[string]FileRef{}, Before: map[string]string{}}
	if a.Stage != "first2" && a.Stage != "full54" {
		return p, fmt.Errorf("対象stage不正")
	}
	check := func(ref FileRef, base string) (string, error) {
		if !validSHA(ref.SHA) {
			return "", fmt.Errorf("未固定SHA")
		}
		path, e := absolute(base, ref.Path)
		if e != nil {
			return "", e
		}
		h, e := origin.FileSHA(path)
		if e != nil || h != ref.SHA {
			return "", fmt.Errorf("指紋差:%s", path)
		}
		p.Before[path] = h
		return path, nil
	}
	cp, e := check(FileRef{a.Condition, a.ConditionSHA}, root)
	if e != nil {
		return p, e
	}
	if e = decode(cp, &p.Condition, false, true); e != nil {
		return p, e
	}
	c := p.Condition
	base := filepath.Dir(cp)
	if c.Version != 1 || c.Trial != 104 || !c.Fixed || len(c.Code) == 0 || !reflect.DeepEqual(c.Configs, Configurations()) || c.Index.SHA != Old100IndexSHA || c.Baseline.SHA != Old103IndexSHA {
		return p, fmt.Errorf("全条件/設定未固定")
	}
	code := map[string]string{}
	for n, h := range c.Code {
		path, e := check(FileRef{n, h}, root)
		if e != nil {
			return p, e
		}
		k := strings.ToLower(filepath.Clean(path))
		if _, ok := code[k]; ok {
			return p, fmt.Errorf("code正規path重複")
		}
		code[k] = h
	}
	_, caller, _, ok := runtime.Caller(0)
	if !ok || !filepath.IsAbs(caller) {
		return p, fmt.Errorf("CLI source根拠なし")
	}
	for _, n := range []string{"main.go", "market.go", "replay.go", "io.go", "go.mod", "go.sum"} {
		if code[strings.ToLower(filepath.Join(filepath.Dir(caller), n))] == "" {
			return p, fmt.Errorf("当実code不足:%s", n)
		}
	}
	bp, e := check(c.Binary, base)
	if e != nil {
		return p, e
	}
	actual, e := filepath.Abs(exe)
	if e != nil || !strings.EqualFold(actual, bp) {
		return p, fmt.Errorf("実binary差")
	}
	sp, e := check(c.Binder, base)
	if e != nil {
		return p, e
	}
	var stopped BinderStop
	if e = decode(sp, &stopped, false, false); e != nil {
		return p, e
	}
	if !stopped.Success || len(stopped.Code) == 0 {
		return p, fmt.Errorf("Binder停止未成功")
	}
	for n, h := range stopped.Code {
		path, e := absolute(root, n)
		if e != nil || !validSHA(h) || code[strings.ToLower(filepath.Clean(path))] != h {
			return p, fmt.Errorf("Binder固定code不足")
		}
	}
	sourcePath, e := check(c.Source, base)
	if e != nil {
		return p, e
	}
	if e = decode(sourcePath, &p.Source, false, true); e != nil {
		return p, e
	}
	if e = validateSource(p.Source); e != nil {
		return p, e
	}
	indexPath, e := check(c.Index, base)
	if e != nil {
		return p, e
	}
	var index Index
	if e = decode(indexPath, &index, false, false); e != nil {
		return p, e
	}
	all := origin.AllowedSessions()
	if index.Version != 1 || index.Stage != "full54" || len(index.Entries) != 54 {
		return p, fmt.Errorf("旧100台帳不正")
	}
	for i, r := range index.Entries {
		if r.Session != all[i] || !validSHA(r.SHA) || r.Path == "" {
			return p, fmt.Errorf("旧100集合不正")
		}
		path, e := absolute(filepath.Dir(indexPath), r.Path)
		if e != nil {
			return p, e
		}
		p.Old[r.Session] = FileRef{path, r.SHA}
	}
	bindPath, e := check(c.FirstBind, base)
	if e != nil {
		return p, e
	}
	var bound BindCompletion
	if e = decode(bindPath, &bound, false, true); e != nil {
		return p, e
	}
	if e = validateBindReceipt(bound, p.Source, p.Old); e != nil {
		return p, e
	}
	nativePath, e := check(c.Baseline, base)
	if e != nil {
		return p, e
	}
	var native NativeIndex
	if e = decode(nativePath, &native, false, false); e != nil {
		return p, e
	}
	if !native.Success || native.Sessions != 54 || native.Books != 864 || len(native.Refs) != 54 {
		return p, fmt.Errorf("旧103Native台帳不正")
	}
	nativeRoot := filepath.Dir(filepath.Dir(nativePath))
	for i, r := range native.Refs {
		if r.Session != all[i] || r.Path == "" || !validSHA(r.SHA) {
			return p, fmt.Errorf("旧103Native集合不正")
		}
		path, e := absolute(nativeRoot, r.Path)
		if e != nil {
			return p, e
		}
		p.Baseline[r.Session] = FileRef{path, r.SHA}
	}
	p.IDs = all
	if a.Stage == "first2" {
		if a.First2 != "" || a.First2SHA != "" {
			return p, fmt.Errorf("first2へ旧receipt指定")
		}
		p.IDs = all[:2]
	} else {
		fp, e := check(FileRef{a.First2, a.First2SHA}, root)
		if e != nil {
			return p, e
		}
		var first Completion
		if e = decode(fp, &first, false, true); e != nil {
			return p, e
		}
		if e = validateFirst2(first, a.ConditionSHA, c.Configs); e != nil {
			return p, e
		}
		for path, h := range p.Before {
			if path != fp && first.Before[path] != h {
				return p, fmt.Errorf("first2との固定参照差")
			}
		}
		for _, r := range first.Results {
			if _, e = check(r.Native, filepath.Dir(fp)); e != nil {
				return p, e
			}
		}
	}
	selected := map[string]bool{}
	for _, id := range p.IDs {
		selected[id] = true
		for _, r := range []FileRef{p.Old[id], p.Baseline[id]} {
			if _, e = check(r, root); e != nil {
				return p, e
			}
		}
	}
	for i, r := range p.Source.Cases {
		if selected[r.Session] {
			for _, ref := range []*FileRef{&r.Result, &r.Records} {
				path, e := check(*ref, filepath.Dir(sourcePath))
				if e != nil {
					return p, e
				}
				ref.Path = path
			}
			p.Source.Cases[i] = r
		}
	}
	return p, nil
}

// validateFirst2 は同じ全条件の先頭2成功と16冊/旧対照8を検査します。
//
// 引数: first(Completion)、sha(string)、configs([]Config)は固定前段と同条件です。
// 返り値: errorは欠落/差/未完結です。
func validateFirst2(first Completion, sha string, configs []Config) error {
	if first.Version != 1 || first.Trial != 104 || first.Stage != "first2" || !first.Success || first.Error != "" || first.ConditionSHA != sha || first.Sessions != 2 || first.BooksPerScene != 8 || first.Books != 16 || first.LegacyControl != 8 || first.DefaultBooks != 0 || !reflect.DeepEqual(first.Configs, configs) || !first.Unchanged || len(first.Before) == 0 || !reflect.DeepEqual(first.Before, first.After) || first.SourceReexecuted || first.ChartsRecomputed || first.GateExecuted || first.RawCSV != 0 || len(first.Results) != 2 {
		return fmt.Errorf("同条件first2成功が必須")
	}
	for i, r := range first.Results {
		if r.Session != origin.AllowedSessions()[i] || r.Books != 8 || r.LegacyControl != 4 || r.Error != "" || r.Native.Path == "" || !validSHA(r.Native.SHA) {
			return fmt.Errorf("first2結果集合不正")
		}
	}
	return nil
}

// CompareLegacy は旧103全NativeのLD10四を未知fieldごと全JSONで比較します。
//
// 引数: result(ModeResult)、path(string)はlegacy四と旧正式gzipです。
// 返り値: Control/errorは全四冊一致又は差です。envelopeの同体とは別です。
func CompareLegacy(result ModeResult, path string, expectedSHA string) (Control, error) {
	proof := Control{Keys: []string{}, Excluded: []string{}, BaselineSHA: expectedSHA}
	var baseline struct {
		Session  finance.Session            `json:"session"`
		Books    map[string]json.RawMessage `json:"books"`
		Complete bool                       `json:"complete"`
	}
	if e := decode(path, &baseline, true, false); e != nil {
		return proof, e
	}
	if !baseline.Complete || !reflect.DeepEqual(baseline.Session, result.Session) || len(baseline.Books) != 16 || !result.Complete || result.SourceMode != "legacy" || len(result.Books) != 4 {
		return proof, fmt.Errorf("旧103/legacy集合又は完結差")
	}
	for _, c := range SelectedConfigs() {
		key := origin.ConfigKey(c)
		raw, ok := baseline.Books[key]
		current, found := result.Books[key]
		if !ok || !found {
			return proof, fmt.Errorf("旧LD10欠落")
		}
		b, e := json.Marshal(current)
		if e != nil {
			return proof, e
		}
		var left, right any
		d := json.NewDecoder(bytes.NewReader(raw))
		d.UseNumber()
		if e = d.Decode(&left); e != nil {
			return proof, e
		}
		d = json.NewDecoder(bytes.NewReader(b))
		d.UseNumber()
		if e = d.Decode(&right); e != nil {
			return proof, e
		}
		if !reflect.DeepEqual(left, right) {
			return proof, fmt.Errorf("旧103LD10全BookJSON差:%s", key)
		}
		proof.Keys = append(proof.Keys, key)
	}
	proof.All = true
	proof.Books = 4
	return proof, nil
}

// RunScene は3mode全Bindを検査し旧/対称各四冊だけを保存型へ集めます。
//
// 引数: id(string)、oldRef/baseline(FileRef)、source([]SourceCase)は固定一場の全入力です。
// 返り値: Native/errorは8冊又は失敗です。defaultは通知QAのみです。
func RunScene(id string, oldRef, baseline FileRef, source []SourceCase) (Native, error) {
	out := Native{Version: 1, Trial: 104, Books: map[string]finance.ActualResult{}, SourceMode: map[string]string{}, Bindings: map[string]binder.Proof{}, Records: map[string]FileRef{}, SourceResults: map[string]FileRef{}, TapeSHA: map[string]string{}, OldTape: oldRef, Baseline103: baseline, Scope: "SourceA記録を旧時計へ結合。legacy/symmetric各103LD10四、default通知QAのみ。Source/指標/Gate形成0"}
	var old tape.Tape
	if e := decode(oldRef.Path, &old, true, true); e != nil {
		return out, e
	}
	if old.Session.ID != id {
		return out, fmt.Errorf("旧Tape session差")
	}
	oldBefore, e := json.Marshal(old)
	if e != nil {
		return out, e
	}
	out.Session = old.Session
	for _, mode := range []string{"legacy", "default", "symmetric"} {
		var input SourceCase
		for _, r := range source {
			if r.Session == id && r.Mode == mode {
				input = r
				break
			}
		}
		records, count, e := readRecords(input.Records.Path)
		if e != nil {
			return out, e
		}
		if !reflect.DeepEqual(count, input.Counts) {
			return out, fmt.Errorf("上流通知count差")
		}
		joined, proof, e := binder.Bind(old, records, mode)
		if e != nil {
			return out, e
		}
		out.Bindings[mode] = proof
		out.Records[mode] = input.Records
		out.SourceResults[mode] = input.Result
		if mode == "default" {
			if !proof.NotificationsEqualOld {
				return out, fmt.Errorf("default通知差")
			}
			continue
		}
		value, e := RunMode(joined, mode)
		if e != nil {
			return out, e
		}
		out.TapeSHA[mode] = value.TapeCanonicalSHA
		if mode == "legacy" {
			out.Control, e = CompareLegacy(value, baseline.Path, baseline.SHA)
			if e != nil {
				return out, e
			}
			out.Events = value.Events
			out.GridTimes = value.GridTimes
		} else if value.Events != out.Events || !reflect.DeepEqual(value.GridTimes, out.GridTimes) {
			return out, fmt.Errorf("対称Sourceで時計差")
		}
		for k, b := range value.Books {
			outer := mode + "_" + k
			out.Books[outer] = b
			out.SourceMode[outer] = mode
		}
	}
	if len(out.Books) != 8 || len(out.SourceMode) != 8 || len(out.Bindings) != 3 || !out.Control.All {
		return out, fmt.Errorf("全8冊/defaultQA/旧対照不完結")
	}
	oldAfter, e := json.Marshal(old)
	if e != nil {
		return out, e
	}
	out.InputUnchanged = bytes.Equal(oldBefore, oldAfter)
	if !out.InputUnchanged {
		return out, fmt.Errorf("旧Tapeの共有入力を変更")
	}
	out.Complete = true
	return out, nil
}

// RunMarket は固定済み2→54を逐次実行し新Nativeだけを保存します。
//
// 引数: a(Arguments)、root/exe(string)は固定起動設定です。
// 返り値: Completion/errorは完了又は成功falseの失敗です。
func RunMarket(a Arguments, root, exe string) (Completion, error) {
	out := Completion{Version: 1, Trial: 104, Stage: a.Stage, ConditionSHA: a.ConditionSHA, BooksPerScene: 8, Configs: Configurations(), Results: []SceneReceipt{}}
	p, e := Prepare(a, root, exe)
	if e != nil {
		return out, e
	}
	out.Before = p.Before
	out.Sessions = len(p.IDs)
	if a.Stage == "full54" {
		fp, _ := absolute(root, a.First2)
		out.First2 = &FileRef{fp, a.First2SHA}
	}
	dir, e := absolute(root, a.Out)
	if e != nil {
		return out, e
	}
	if _, e = os.Stat(dir); !os.IsNotExist(e) {
		return out, fmt.Errorf("既存出力拒否")
	}
	if e = os.MkdirAll(filepath.Dir(dir), 0700); e != nil {
		return out, e
	}
	if e = os.Mkdir(dir, 0700); e != nil {
		return out, e
	}
	for _, id := range p.IDs {
		row := SceneReceipt{Session: id}
		value, e := RunScene(id, p.Old[id], p.Baseline[id], p.Source.Cases)
		if e == nil {
			row.Native.Path = filepath.Join(dir, id+".json.gz")
			e = writeNew(row.Native.Path, value, true)
			if e == nil {
				row.Native.SHA, e = origin.FileSHA(row.Native.Path)
			}
		}
		if e != nil {
			row.Error = e.Error()
			out.Error = id + ":" + e.Error()
		} else {
			row.Books = 8
			row.LegacyControl = 4
			out.Books += 8
			out.LegacyControl += 4
		}
		out.Results = append(out.Results, row)
		if e != nil {
			break
		}
	}
	out.After = map[string]string{}
	for path := range out.Before {
		h, e := origin.FileSHA(path)
		out.After[path] = h
		if e != nil && out.Error == "" {
			out.Error = e.Error()
		}
	}
	out.Unchanged = reflect.DeepEqual(out.Before, out.After)
	if !out.Unchanged && out.Error == "" {
		out.Error = "入力/code/binary前後差"
	}
	out.Success = out.Error == "" && len(out.Results) == len(p.IDs) && out.Books == 8*len(p.IDs) && out.LegacyControl == 4*len(p.IDs)
	if e = writeNew(filepath.Join(dir, "完了.json"), out, false); e != nil {
		return out, e
	}
	if !out.Success {
		return out, fmt.Errorf("%s", out.Error)
	}
	return out, nil
}
