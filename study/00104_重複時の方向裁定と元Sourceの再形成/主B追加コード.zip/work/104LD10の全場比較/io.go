// 停止first2 CLI e795c615の公開metadata型と標準IO本文を無変更抽出。
package main

import (
	"compress/gzip"
	"encoding/hex"
	"encoding/json"
	"fmt"
	binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
	"io"
	"os"
	"path/filepath"
	"strings"
)

type FileRef struct {
	Path string `json:"path"`
	SHA  string `json:"sha256"`
}
type Counts struct {
	Calls   int `json:"calls"`
	Steps   int `json:"steps"`
	Forces  int `json:"forces"`
	Signals int `json:"signals"`
	Fills   int `json:"fills"`
	Closes  int `json:"closes"`
	Cancels int `json:"cancellations"`
}
type SourceCase struct {
	Session string  `json:"session"`
	Mode    string  `json:"mode"`
	Result  FileRef `json:"result"`
	Records FileRef `json:"records"`
	Counts  Counts  `json:"counts"`
	Match   bool    `json:"old93_full_match"`
	Error   string  `json:"error,omitempty"`
}
type SourceCompletion struct {
	Version      int               `json:"version"`
	Trial        int               `json:"trial"`
	Stage        string            `json:"stage"`
	Success      bool              `json:"success"`
	ConditionSHA string            `json:"condition_sha256"`
	Sessions     int               `json:"sessions"`
	Cases        []SourceCase      `json:"cases"`
	Before       map[string]string `json:"before"`
	After        map[string]string `json:"after"`
	Unchanged    bool              `json:"unchanged"`
	Formed       bool              `json:"source_reformed"`
	Finance      bool              `json:"financial103_executed"`
	Error        string            `json:"error,omitempty"`
}
type Index struct {
	Version int    `json:"version"`
	Stage   string `json:"stage"`
	Entries []struct {
		Session string `json:"session"`
		Path    string `json:"path"`
		SHA     string `json:"sha256"`
	} `json:"entries"`
}
type BinderStop struct {
	Success bool              `json:"成功"`
	Code    map[string]string `json:"所有コードSHA256"`
}

// validSHA は未固定又は不正なSHAを拒否します。
//
// 引数: value(string)は期待SHAです。返り値: boolは小文字64桁なら真です。
func validSHA(value string) bool {
	b, e := hex.DecodeString(value)
	return e == nil && len(b) == 32 && strings.ToLower(value) == value
}

// absolute は明示された根を基準にpathを解決します。
//
// 引数: base/name(string)は基準とpathです。返り値: string/errorは絶対path又は空pathです。
func absolute(base, name string) (string, error) {
	if strings.TrimSpace(name) == "" {
		return "", fmt.Errorf("空path")
	}
	if !filepath.IsAbs(name) {
		name = filepath.Join(base, name)
	}
	return filepath.Abs(name)
}

// decode は公開JSON一値を型どおり読み、末尾値を拒否します。
//
// 引数: path(string)、value(any)、compressed/strict(bool)は入力と型・gzip/未知欄拒否です。
// 返り値: errorは読取又は型/末尾破損です。
func decode(path string, value any, compressed, strict bool) error {
	f, e := os.Open(path)
	if e != nil {
		return e
	}
	defer f.Close()
	var reader io.Reader = f
	if compressed {
		z, e := gzip.NewReader(f)
		if e != nil {
			return e
		}
		defer z.Close()
		reader = z
	}
	d := json.NewDecoder(reader)
	if strict {
		d.DisallowUnknownFields()
	}
	if e = d.Decode(value); e != nil {
		return e
	}
	var tail any
	if e = d.Decode(&tail); e != io.EOF {
		return fmt.Errorf("JSON末尾不正")
	}
	return nil
}

// writeNew はJSON又はgzipを既存ファイルへ上書きせず保存します。
//
// 引数: path(string)、value(any)、compressed(bool)は新規先と公開値です。
// 返り値: errorは保存又はclose失敗です。
func writeNew(path string, value any, compressed bool) error {
	f, e := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return e
	}
	var writer io.Writer = f
	var z *gzip.Writer
	if compressed {
		z = gzip.NewWriter(f)
		writer = z
	}
	enc := json.NewEncoder(writer)
	enc.SetEscapeHTML(false)
	e = enc.Encode(value)
	if z != nil {
		if close := z.Close(); e == nil {
			e = close
		}
	}
	if close := f.Close(); e == nil {
		e = close
	}
	return e
}

// readRecords は上流gzip全記録を未知欄を落とさず型検査して読みます。
//
// 引数: path(string)はRoot固定後のSource JSONLです。
// 返り値: []binder.SourceRecord/Counts/errorは全記録と実count又は読取失敗です。
func readRecords(path string) ([]binder.SourceRecord, Counts, error) {
	rows := []binder.SourceRecord{}
	count := Counts{}
	f, e := os.Open(path)
	if e != nil {
		return rows, count, e
	}
	defer f.Close()
	z, e := gzip.NewReader(f)
	if e != nil {
		return rows, count, e
	}
	defer z.Close()
	d := json.NewDecoder(z)
	d.DisallowUnknownFields()
	for {
		var row binder.SourceRecord
		e = d.Decode(&row)
		if e == io.EOF {
			break
		}
		if e != nil {
			return rows, count, e
		}
		rows = append(rows, row)
		count.Calls++
		switch row.Kind {
		case "quote":
			count.Steps++
		case "force":
			count.Forces++
		default:
			return rows, count, fmt.Errorf("未知SourceRecord種別")
		}
		count.Signals += len(row.Delta.Signals)
		count.Fills += len(row.Delta.Fills)
		count.Closes += len(row.Delta.Closes)
		count.Cancels += len(row.Delta.Cancellations)
	}
	return rows, count, nil
}
