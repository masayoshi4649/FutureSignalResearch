// 停止103 replay.go 03ef63f6…からの機械派生。Actor/算術/配送順は直接再用する。
package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"reflect"

	origin "github.com/masayoshi4649/SessionTradeExecuter/delayedreplay103"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	finance "github.com/masayoshi4649/SessionTradeExecuter/minidelayed103"
)

type ModeResult struct {
	Version          int                             `json:"version"`
	Trial            int                             `json:"trial"`
	SourceMode       string                          `json:"source_mode"`
	Session          finance.Session                 `json:"session"`
	Books            map[string]finance.ActualResult `json:"books"`
	MainKeys         []string                        `json:"main_keys"`
	DiagnosticKeys   []string                        `json:"diagnostic_keys"`
	GridTimes        []float64                       `json:"grid_times"`
	Events           origin.EventCounts              `json:"events"`
	TapeCanonicalSHA string                          `json:"tape_canonical_sha256"`
	InputUnchanged   bool                            `json:"input_unchanged"`
	SourceReexecuted bool                            `json:"source_reexecuted"`
	ChartsRecomputed bool                            `json:"charts_recomputed"`
	GateExecuted     bool                            `json:"gate_executed"`
	Complete         bool                            `json:"complete"`
	Scope            string                          `json:"scope"`
}

// SelectedConfigs は停止103の設定からP0/LD10四感度だけを選びます。
//
// 引数: なし。返り値: []origin.Configは旧数値を変更しない四設定です。
func SelectedConfigs() []origin.Config {
	out := []origin.Config{}
	for _, c := range origin.Configurations() {
		if c.Policy == "P0" && c.Activation == finance.ActivationLD10 {
			out = append(out, c)
		}
	}
	return out
}

// RunMode はSource一方式を既存103Actorの四設定へ配送します。
//
// 引数: input(tape.Tape)、mode(string)は結合入力とlegacy/symmetricです。
// 返り値: ModeResult/errorは全四冊完結又は失敗です。defaultは経済運転しません。
func RunMode(input tape.Tape, mode string) (ModeResult, error) {
	return RunModeObserved(input, mode, nil)
}

// RunModeObserved は旧103と同じ全配送を人工の四冊観測口付きで実行します。
//
// 引数: input(tape.Tape)、mode(string)、observer(origin.SnapshotObserver又はnil)は入力・方式・人工観測口です。
// 返り値: ModeResult/errorは全四冊又は不整合です。市場ではobserver=nilです。
func RunModeObserved(input tape.Tape, mode string, observer origin.SnapshotObserver) (ModeResult, error) {
	out := ModeResult{Version: 1, Trial: 104, SourceMode: mode, Session: input.Session, Books: map[string]finance.ActualResult{}, MainKeys: []string{}, DiagnosticKeys: []string{}, GridTimes: []float64{}, Scope: "元103ActorのLD10四だけ。同じ多玉/数量/B5Q/Source返済、Source/指標/Gate再形成なし"}
	if (mode != "legacy" && mode != "symmetric") || input.Version != 1 || input.Scope == "" || !reflect.DeepEqual(input.Capabilities, tape.Capabilities()) {
		return out, fmt.Errorf("Tape版/対応範囲不一致")
	}
	before, e := json.Marshal(input)
	if e != nil {
		return out, e
	}
	sum := sha256.Sum256(before)
	out.TapeCanonicalSHA = hex.EncodeToString(sum[:])
	configs := SelectedConfigs()
	actors := make([]*finance.ActualBook, 0, len(configs))
	for _, cfg := range configs {
		b, e := finance.NewActualBook(input.Session, finance.ActorConfig{Policy: cfg.Policy, ActivationPolicy: cfg.Activation, SlipPts: cfg.Slip, DelaySeconds: cfg.Delay, EntryTiming: "B5Q", USOpen: input.Session.USOpen})
		if e != nil {
			return out, e
		}
		key := b.Snapshot().Key
		if key != origin.ConfigKey(cfg) {
			return out, fmt.Errorf("金融key差: %s != %s", key, origin.ConfigKey(cfg))
		}
		actors = append(actors, b)
		if cfg.Policy == "S0" {
			out.DiagnosticKeys = append(out.DiagnosticKeys, key)
		} else {
			out.MainKeys = append(out.MainKeys, key)
		}
	}
	previous := 0.0
	last := map[string]int64{}
	lastGrid := input.Session.Start - 1
	for i, event := range input.Events {
		if event.Ordinal != i+1 || event.At < previous {
			return out, fmt.Errorf("Tape順序不正: %d", i+1)
		}
		previous = event.At
		switch event.Kind {
		case "quote", "force":
			if event.Context != nil {
				return out, fmt.Errorf("Source行へ技法contextが混入")
			}
			if event.Kind == "quote" && (event.Quote == nil || event.Quote.Time != event.At) {
				return out, fmt.Errorf("Scalar時計不一致")
			}
			if event.Kind == "force" && event.Quote != nil {
				return out, fmt.Errorf("Forceへ架空Quoteが混入")
			}
			batches, e := tape.RestoreBatches(event, last)
			if e != nil {
				return out, e
			}
			batchBefore, e := json.Marshal(batches)
			if e != nil {
				return out, e
			}
			for j, b := range actors {
				if event.Kind == "quote" {
					e = b.OnNativeStep(event.Quote.Observation(), event.Quote.SourceLine, origin.ConvertBatches(batches))
				} else {
					e = b.OnNativeForce(event.At, origin.ConvertBatches(batches))
				}
				if e != nil {
					return out, fmt.Errorf("%s %s ordinal%d: %w", input.Session.ID, origin.ConfigKey(configs[j]), event.Ordinal, e)
				}
			}
			batchAfter, e := json.Marshal(batches)
			if e != nil {
				return out, e
			}
			if !bytes.Equal(batchBefore, batchAfter) {
				return out, fmt.Errorf("共用Source通知を変更")
			}
			if event.Kind == "quote" {
				out.Events.Quotes++
			} else {
				out.Events.Forces++
			}
		case "grid":
			if event.Quote != nil || len(event.Methods)+len(event.NonEmpty) != 0 || event.Context != nil && event.Context.At != event.At || event.At <= lastGrid {
				return out, fmt.Errorf("保存gridの時計/Source混入/重複")
			}
			lastGrid = event.At
			for j, b := range actors {
				if e = b.OnEntryGrid(event.At); e != nil {
					return out, fmt.Errorf("%s %s grid%.0f: %w", input.Session.ID, origin.ConfigKey(configs[j]), event.At, e)
				}
			}
			out.GridTimes = append(out.GridTimes, event.At)
			out.Events.Grids++
		default:
			return out, fmt.Errorf("不明イベント: %s", event.Kind)
		}
		if observer != nil {
			snapshots := map[string]finance.ActualResult{}
			for j, b := range actors {
				snapshots[origin.ConfigKey(configs[j])] = b.Snapshot()
			}
			if e = observer(event, snapshots); e != nil {
				return out, e
			}
		}
	}
	for j, b := range actors {
		r, e := b.Finish()
		if e != nil {
			return out, fmt.Errorf("%s %s Finish: %w", input.Session.ID, origin.ConfigKey(configs[j]), e)
		}
		key := origin.ConfigKey(configs[j])
		if r.Key != key || !r.Finished || !r.Complete || r.Failure != "" || r.Totals.OpenBuy != 0 || r.Totals.OpenSell != 0 || r.Totals.PendingBuy != 0 || r.Totals.PendingSell != 0 {
			return out, fmt.Errorf("未完結口座: %s", key)
		}
		out.Books[key] = r
	}
	after, e := json.Marshal(input)
	if e != nil {
		return out, e
	}
	out.InputUnchanged = bytes.Equal(before, after)
	if !out.InputUnchanged || len(out.Books) != 4 || len(out.MainKeys) != 4 || len(out.DiagnosticKeys) != 0 {
		return out, fmt.Errorf("入力不変/LD10四集合不一致")
	}
	out.Complete = true
	return out, nil
}
