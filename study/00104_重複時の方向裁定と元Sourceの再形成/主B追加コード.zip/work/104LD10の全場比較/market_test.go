package main

import (
	"encoding/json"
	"strings"
	"testing"

	origin "github.com/masayoshi4649/SessionTradeExecuter/delayedreplay103"
	binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
)

// sourceFixture は全54×3modeの成功metadata型だけを構成します。
//
// 引数: なし。返り値: SourceCompletionは自然Sourceではない手製器具です。
func sourceFixture() SourceCompletion {
	h := strings.Repeat("a", 64)
	s := SourceCompletion{Version: 1, Trial: 104, Stage: "full54", Success: true, ConditionSHA: h, Sessions: 54, Before: map[string]string{"人工": h}, After: map[string]string{"人工": h}, Unchanged: true, Formed: true}
	for _, id := range origin.AllowedSessions() {
		for _, mode := range []string{"legacy", "default", "symmetric"} {
			s.Cases = append(s.Cases, SourceCase{Session: id, Mode: mode, Records: FileRef{"records", h}, Result: FileRef{"result", h}, Match: mode != "symmetric", Counts: Counts{Calls: 2, Steps: 1, Forces: 1}})
		}
	}
	return s
}

// firstFixture は同条件のStageB先頭2成功metadata型を返します。
//
// 引数: なし。返り値: Completionは16冊/旧対照8の手製schema器具です。
func firstFixture() Completion {
	h := strings.Repeat("a", 64)
	f := Completion{Version: 1, Trial: 104, Stage: "first2", Success: true, ConditionSHA: h, Sessions: 2, BooksPerScene: 8, Books: 16, LegacyControl: 8, Configs: Configurations(), Before: map[string]string{"人工": h}, After: map[string]string{"人工": h}, Unchanged: true}
	for _, id := range origin.AllowedSessions()[:2] {
		f.Results = append(f.Results, SceneReceipt{Session: id, Native: FileRef{"native", h}, Books: 8, LegacyControl: 4})
	}
	return f
}

// TestMetadataBoundary はSource全成功と同条件first2の必要境界を確認します。
//
// 引数: t(*testing.T)は人工試験器です。
// 返り値: なし。市場metadataや実Nativeを読みません。
func TestMetadataBoundary(t *testing.T) {
	if e := validateSource(sourceFixture()); e != nil {
		t.Fatal(e)
	}
	sourceTests := []struct {
		name   string
		change func(*SourceCompletion)
	}{
		{"Sourcefirst2流用", func(s *SourceCompletion) { s.Stage = "first2" }},
		{"Source未完結", func(s *SourceCompletion) { s.Success = false }},
		{"Source欠落", func(s *SourceCompletion) { s.Cases = s.Cases[:161] }},
		{"Source重複", func(s *SourceCompletion) { s.Cases[161] = s.Cases[0] }},
		{"Source別日", func(s *SourceCompletion) { s.Cases[0].Session = "2026-11-05_Day" }},
		{"Source対称へ旧一致", func(s *SourceCompletion) { s.Cases[2].Match = true }},
		{"Source出力未固定", func(s *SourceCompletion) { s.Cases[0].Records.SHA = "" }},
		{"Source前後差", func(s *SourceCompletion) { s.After["人工"] = "差" }},
	}
	for _, x := range sourceTests {
		t.Run(x.name, func(t *testing.T) {
			s := sourceFixture()
			x.change(&s)
			if e := validateSource(s); e == nil {
				t.Fatal("Source破損を受理")
			}
		})
	}
	if e := validateFirst2(firstFixture(), strings.Repeat("a", 64), Configurations()); e != nil {
		t.Fatal(e)
	}
	firstTests := []struct {
		name   string
		change func(*Completion)
	}{
		{"初段全54混同", func(f *Completion) { f.Stage = "full54" }},
		{"初段別条件", func(f *Completion) { f.ConditionSHA = strings.Repeat("b", 64) }},
		{"初段default経済", func(f *Completion) { f.DefaultBooks = 4 }},
		{"初段口座不足", func(f *Completion) { f.Books = 8 }},
		{"初段旧対照不足", func(f *Completion) { f.LegacyControl = 4 }},
		{"初段別ID", func(f *Completion) { f.Results[1].Session = f.Results[0].Session }},
		{"初段設定差", func(f *Completion) { f.Configs = f.Configs[:7] }},
		{"初段前後差", func(f *Completion) { f.After["人工"] = "差" }},
		{"初段空出力", func(f *Completion) { f.Results[0].Native.Path = "" }},
	}
	for _, x := range firstTests {
		t.Run(x.name, func(t *testing.T) {
			f := firstFixture()
			x.change(&f)
			if e := validateFirst2(f, strings.Repeat("a", 64), Configurations()); e == nil {
				t.Fatal("初段破損を受理")
			}
		})
	}
	if len(Configurations()) != 8 || len(SelectedConfigs()) != 4 {
		t.Fatal("固定設定集合")
	}
	if _, e := Prepare(Arguments{Condition: "未作成", Stage: "first2"}, t.TempDir(), "fake.exe"); e == nil {
		t.Fatal("条件未固定を受理")
	}
}

// TestFirstBindBoundary は前の実結合の出典と64冊互換scopeを検査します。
//
// 引数: t(*testing.T)は人工試験器です。
// 返り値: なし。先頭2の実receiptは読みません。
func TestFirstBindBoundary(t *testing.T) {
	h := strings.Repeat("a", 64)
	source := sourceFixture()
	old := map[string]FileRef{}
	b := BindCompletion{Version: 1, Trial: 104, Stage: "first2", Success: true, Sessions: 2, ConditionSHA: h, Before: map[string]string{"人工": h}, After: map[string]string{"人工": h}, Unchanged: true}
	cases := []map[string]any{}
	for _, id := range origin.AllowedSessions()[:2] {
		old[id] = FileRef{"old", h}
		for _, mode := range []string{"legacy", "default", "symmetric"} {
			cases = append(cases, map[string]any{"session": id, "mode": mode, "source_records": FileRef{"records", h}, "source_result": FileRef{"result", h}, "old_tape": FileRef{"old", h}, "new_tape": FileRef{"new", h}, "binding": binder.Proof{ModeDeclared: mode, NotificationsEqualOld: mode != "symmetric"}, "compatibility_103": map[string]any{"performed": mode != "symmetric", "books": 0, "book_field_excluded": []string{}, "final_books_json_sha256": h}})
			if mode != "symmetric" {
				cases[len(cases)-1]["compatibility_103"].(map[string]any)["books"] = 16
			}
		}
	}
	raw, e := json.Marshal(cases)
	if e != nil {
		t.Fatal(e)
	}
	if e = json.Unmarshal(raw, &b.Cases); e != nil {
		t.Fatal(e)
	}
	if e = validateBindReceipt(b, source, old); e != nil {
		t.Fatal(e)
	}
	b.Cases[0].SourceRecords.SHA = strings.Repeat("b", 64)
	if e = validateBindReceipt(b, source, old); e == nil {
		t.Fatal("Sourcefullと実結合の由来差を受理")
	}
	b.Cases[0].SourceRecords.SHA = h
	b.Cases[5] = b.Cases[0]
	if e = validateBindReceipt(b, source, old); e == nil {
		t.Fatal("結合case重複を受理")
	}
	if e = json.Unmarshal(raw, &b.Cases); e != nil {
		t.Fatal(e)
	}
	b.Cases[0].Compatibility.Books = 4
	if e = validateBindReceipt(b, source, old); e == nil {
		t.Fatal("前段全16比較を四冊と混同")
	}
	if e = json.Unmarshal(raw, &b.Cases); e != nil {
		t.Fatal(e)
	}
	b.Cases[2].Compatibility.Performed = true
	if e = validateBindReceipt(b, source, old); e == nil {
		t.Fatal("symmetricの金融scope流用")
	}
}
