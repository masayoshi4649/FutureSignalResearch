# LD10の旧Source・対称Source比較（市場前の別固定）

module `github.com/masayoshi4649/SessionTradeExecuter/ld10compare104`、package main。SourceA全54成功後に、同じ旧100Tape時計へ各modeをBindし、**legacy/symmetricの各LD10四感度だけ、全8×54=432冊**を運転する。defaultは全通知一致の検査だけで経済口座0。SourceAの元連続会計とこのB5Q金融の成績を混ぜない。

実市場・Raw/CSV・本物SourceFull/旧Native本文の読取は準備中0。既存のSourceAプロセス、103/104の固定済みコード・条件・停止は変更しない。Rootが新条件/code/binaryを固定して実行するまで待つ。

## 再用と保存型

[停止103](../103多玉の一定利益保護/README.md)の`ActualBook`を直接importし、`Configurations()`からPolicy=P0/ActivationLD10の四設定だけを選ぶ。新しい利益起動・数量・比例返済・B5Q・各側10枚・費用・D1・Force/Source優先の式は追加しない。`RunModeObserved`は旧103配送関数の機械派生で、[関数差分](配送関数の派生差分.patch)と派生scriptを残す。`ConvertBatches/ConfigKey`も旧public関数を使う。

同じ旧Tapeへlegacy/default/symmetricの全記録を順に渡し、純Binderがfresh Scalar11、全micro/miniのmethod順、全Delta、Force直前SourceLine、quote/force/grid位相、余剰/欠落を検査する。Sourceや技法を形成せず、Scalarを完全Observationの代用にしない。default/legacyは旧mini通知全文一致、symmetricは新通知を許す。既存Contextは旧時計の公表値であり、新Sourceの技法形成成功ではない。

一場のNative topは`version/trial/session/books/source_mode_by_book/bindings/input_source_records/source_results/old_tape/baseline103/tape_canonical_sha256/control103/events/grid_times/complete/input_unchanged/source_reexecuted/charts_recomputed/gate_executed/scope`。

- `books`外keyは`legacy_LD10_B5Q_P0_Cx_Dy`又は`symmetric_LD10_B5Q_P0_Cx_Dy`。`source_mode_by_book`も同8key。**内ActualResult.Key/Config/全金融fieldは旧四keyの原値のまま**で、金融内IDを改名しない。
- `bindings`は全3modeのProof。`input_source_records/source_results`は各modeの固定FileRef。`tape_canonical_sha256`は金融を運転した2mode。新Tape全件は重複保存せず、固定旧Tapeと入力SourceRecordsから同じBindで再構成できる。
- `control103`はlegacy四の旧103正式Nativeとの**全Book JSON比較、除外[]**。旧Nativeの16冊からLD10四をRawMessageで取り出し、未知field・null/空・数量・半円等を落とさず比較する。symmetricへ旧同値を流用しない。新Scope/TapeSHAの異なるenvelope全体を旧Native同体とは呼ばない。

default経済0、Source/チャート/Gate再形成false。最終未完結、旧対照差、入力共有値の変更は失敗にする。新規出力directoryとO_EXCL保存だけを許す。

## Root固定条件と2→54

`version:1,trial:104,fixed:true`、`configs`は旧/対称の順に各C0D0/C0D1/C5D0/C5D1。各設定は`source_mode/policy:P0/activation_policy:LD10/slip_pts/delay_seconds`。固定数値は103そのもの。

必須5FileRefs（条件directory基準）:

1. `source_full`：**SourceA full54成功/54場/162case/前後同一がfirst2段階から必須**。全54ID×3modeを一意検査し、Source未完の途中出力を運転しない。Source結果JSONはhashだけ、会計内容は展開しない。
2. `old100_tape_index`：旧100の正式54台帳。SHA `4db6812d…`を固定、全54順序を検査。entriesのpathは台帳directory基準。
3. `first2_bind`：既済み実先頭2結合の完了。全6case、legacy/defaultの最終16×4=64 Book互換scope、入力前後不変を検査し、先頭2の全Source出力SHAがSourceFullの同じ6caseと一致することも要求する。
4. `binder_stop`：純Binderの成功停止/所有code全体を固定する。
5. `baseline103_index`：103正式`成果物/Native参照台帳.json`、SHA `f07280a7…`。全54/864を検査。参照pathはこの台帳の規約どおり**study103 directory基準（台帳の親の親）**。歴史の元workNative pathは使用しない。

`binary`の実行path/SHAと`code_sha256`（repo相対又は絶対path）も必須。当CLIのmain/market/replay/io/mod/sumと停止Binder所有集合の正規path/SHAを検査し、残るGo依存閉包はRootが固定する。条件自体の最終SHAをコードへ埋め込まずCLIで渡す。

全固定metadataとcode/binary検査後、選択stageの旧Tape・旧103Native・Source result/recordsだけを前hashする。上流before辞書を理由にRawを再hashしない。終了後に同じ集合を再hashして同一を必須にする。並列workerは実装せず、一場・一modeずつ処理する。

```powershell
Set-Location '<repo>'
& 'work/104LD10の全場比較/検査/LD10比較.exe' `
  --condition '<Root固定条件.json>' --condition-sha '<そのSHA>' `
  --stage first2 --out '<存在しない先頭2先>'
& 'work/104LD10の全場比較/検査/LD10比較.exe' `
  --condition '<同条件>' --condition-sha '<同SHA>' --stage full54 `
  --first2 '<上の完了.json>' --first2-sha '<そのSHA>' --out '<別の新規全54先>'
```

CLIのcondition/out/first2の相対pathはrepo基準。full54は同条件/configs/code/binary/固定参照・成功2ID/16冊/旧対照8を継承し、前段Native実SHAも再確認する。完了は`results[{session,native:{path,sha256},books:8,legacy_control_books:4,error?}]`、`books_per_scene:8`、全54なら`books:432/legacy_control_books:216/default_books:0`、before/after/unchangedを残す。失敗を成功に補完しない。Preflight又は出力directory作成前の失敗はreceipt自体を作らない。

## 人工と未検証の境界

停止103の非0API型人工4本（買売×ATR既知/未知）を使い、各LD10四を二つの宣言modeへ配送した32冊の全時点/最終JSONを旧103四へ除外0で照合した。**この二つは同じ手製通知であり、対称Sourceを自然形成して利益差を検証したものではない。** 既存API器具には市場Bindの同秒位相外の呼出しもあるため、その非0波を厳格Bindの成功へ流用しない。

別に停止Binderの合法空通知を全3modeへBindして8冊Native・旧103四対照・default金融0を検査した。こちらは全取引0のcodec型人工。Source全162case、実結合由来、同条件first2→54の破損拒否も人工で確認。完全な型は[人工/型export](人工/型export)へ保存し、原金融/Sourceの停止本文は不変。

実SourceFull→全8冊、未見期間、自然Source全体の売買対称、mini実執行、5pt実測、未知期間安定利益は未確認。主評価は実現粗純額・正負/PF・u正益後とLD起動後の赤字・DD・日夜参加・回数枚数・同実入口差。Source番号変更を無理に同玉対応させず、取得変更/片側の実在額を区別する。機会損失・退出後価格・MFE回収は算出しない。
