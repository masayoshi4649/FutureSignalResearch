"""停止103の配送関数を機械派生し、設定選択だけLD10四へ限定する。"""

from pathlib import Path
import hashlib
import difflib


def main() -> None:
    """
    機能: 停止103の読取・変換・ctor/配送を追跡可能な新runtimeへ派生する。
    引数: なし。
    返り値: None。市場入力や金融を実行しない。
    """
    here = Path(__file__).resolve().parent
    old = here.parent / "103多玉の一定利益保護/replay.go"
    assert hashlib.sha256(old.read_bytes()).hexdigest() == "03ef63f6702e25e64b179dbd6ccce24d68d055c6cdd5c5de02dd50a3e36c66af"
    text = old.read_text(encoding="utf-8")
    start = text.index("func RunObserved(")
    end = text.index("// CompareP0", start)
    body = text[start:end]
    body = body.replace("func RunObserved(input tape.Tape, observer SnapshotObserver) (RunResult, error)", "func RunModeObserved(input tape.Tape, mode string, observer origin.SnapshotObserver) (ModeResult, error)")
    body = body.replace("out := RunResult{Version: 1, Trial: 103,", "out := ModeResult{Version: 1, Trial: 104, SourceMode: mode,")
    body = body.replace('Scope: "固定Sourceの多玉/可変量/B5Qと比例返済を維持。主12起動比較＋S0診断4（保護義務未充足・採用不可）。Source/チャート/Gate再実行なし"', 'Scope: "元103ActorのLD10四だけ。同じ多玉/数量/B5Q/Source返済、Source/指標/Gate再形成なし"')
    body = body.replace('if input.Version != 1', 'if (mode != "legacy" && mode != "symmetric") || input.Version != 1', 1)
    body = body.replace("configs := Configurations()", "configs := SelectedConfigs()")
    body = body.replace("ConfigKey(", "origin.ConfigKey(").replace("ConvertBatches(", "origin.ConvertBatches(")
    body = body.replace("len(out.Books) != 16 || len(out.MainKeys) != 12 || len(out.DiagnosticKeys) != 4", "len(out.Books) != 4 || len(out.MainKeys) != 4 || len(out.DiagnosticKeys) != 0")
    body = body.replace('入力不変/主12診断4集合不一致', '入力不変/LD10四集合不一致')
    head = '''// 停止103 replay.go 03ef63f6…からの機械派生。Actor/算術/配送順は直接再用する。
package main

import (
    "bytes"
    "crypto/sha256"
    "encoding/hex"
    "encoding/json"
    "fmt"
    "reflect"

    origin "github.com/masayoshi4649/SessionTradeExecuter/delayedreplay103"
    tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
    finance "github.com/masayoshi4649/SessionTradeExecuter/minidelayed103"
)

type ModeResult struct {
    Version int `json:"version"`
    Trial int `json:"trial"`
    SourceMode string `json:"source_mode"`
    Session finance.Session `json:"session"`
    Books map[string]finance.ActualResult `json:"books"`
    MainKeys []string `json:"main_keys"`
    DiagnosticKeys []string `json:"diagnostic_keys"`
    GridTimes []float64 `json:"grid_times"`
    Events origin.EventCounts `json:"events"`
    TapeCanonicalSHA string `json:"tape_canonical_sha256"`
    InputUnchanged bool `json:"input_unchanged"`
    SourceReexecuted bool `json:"source_reexecuted"`
    ChartsRecomputed bool `json:"charts_recomputed"`
    GateExecuted bool `json:"gate_executed"`
    Complete bool `json:"complete"`
    Scope string `json:"scope"`
}

// SelectedConfigs は停止103の設定からP0/LD10四感度だけを選びます。
//
// 引数: なし。返り値: []origin.Configは旧数値を変更しない四設定です。
func SelectedConfigs() []origin.Config {
    out := []origin.Config{}
    for _, c := range origin.Configurations() {
        if c.Policy == "P0" && c.Activation == finance.ActivationLD10 { out = append(out,c) }
    }
    return out
}

// RunMode はSource一方式を既存103Actorの四設定へ配送します。
//
// 引数: input(tape.Tape)、mode(string)は結合入力とlegacy/symmetricです。
// 返り値: ModeResult/errorは全四冊完結又は失敗です。defaultは経済運転しません。
func RunMode(input tape.Tape, mode string) (ModeResult,error) { return RunModeObserved(input,mode,nil) }

// RunModeObserved は旧103と同じ全配送を人工の四冊観測口付きで実行します。
//
// 引数: input(tape.Tape)、mode(string)、observer(origin.SnapshotObserver又はnil)は入力・方式・人工観測口です。
// 返り値: ModeResult/errorは全四冊又は不整合です。市場ではobserver=nilです。
'''
    with (here / "replay.go").open("x", encoding="utf-8", newline="\n") as out:
        out.write(head + body)
    original = text[start:end].splitlines(True)
    derived = body.splitlines(True)
    (here / "配送関数の派生差分.patch").write_text("".join(difflib.unified_diff(original, derived, fromfile="停止103/RunObserved", tofile="104/RunModeObserved")), encoding="utf-8")


if __name__ == "__main__":
    main()
