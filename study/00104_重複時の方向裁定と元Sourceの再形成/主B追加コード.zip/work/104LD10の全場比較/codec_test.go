package main

import (
	"compress/gzip"
	"encoding/json"
	"io"
)

type gzipFixture struct {
	writer  *gzip.Writer
	encoder *json.Encoder
}

// newGzip は型人工だけのJSONL writerを作ります。
//
// 引数: out(io.Writer)は新規人工先です。返り値: gzipFixtureは閉じる必要のある人工writerです。
func newGzip(out io.Writer) gzipFixture {
	z := gzip.NewWriter(out)
	return gzipFixture{z, json.NewEncoder(z)}
}

// close は型人工gzipの末尾を閉じます。
//
// 引数: なし。返り値: errorはclose失敗です。
func (g gzipFixture) close() error { return g.writer.Close() }
