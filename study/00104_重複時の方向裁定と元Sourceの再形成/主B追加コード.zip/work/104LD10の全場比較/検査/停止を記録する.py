"""停止済み依存・限定差分・Go型人工と実行物を市場前に固定する。"""

from __future__ import annotations

import difflib
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: コード又は小型metadata/人工の指紋を返す。
    引数: path(Path)は許可範囲のファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path: Path, value: dict) -> None:
    """
    機能: 新規metadataを上書きせず保存する。
    引数: path(Path)、value(dict)は新規先と値。
    返り値: None。
    """
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def main() -> None:
    """
    機能: SourceA未完でも市場本文を開かず停止を作成する。
    引数: なし。
    返り値: None。再build/金融/Raw/本物Source・Nativeの展開は行わない。
    """
    dependencies = {
        "work/103多玉の一定利益保護/停止.json": "9e899ea0cbdab53c299925b7061165e832309ee7cba3187de80066774bddd88f",
        "work/103多玉の保護会計/停止.json": "e051a2401c8919835adfea52bf346d644707239fd030f0b13f101586b4c1d52b",
        "work/104新Sourceと判断時計の結合案/停止.json": "e66adae009ff3edfa59b38dd22ffa07c48f83843f045080a4ede0045dab0fbf2",
        "work/104Source結合の実行/停止.json": "e795c61557f8af1a2f54f46dc2908ce145c62263e20b1b8e383752bf80e9ebbd",
    }
    original = {}
    for name, expected in dependencies.items():
        assert sha(ROOT / name) == expected, name
        stopped = json.loads((ROOT / name).read_text(encoding="utf-8-sig"))
        owned = stopped.get("所有コードSHA256", stopped.get("所有SHA256", {}))
        assert owned
        for p, h in owned.items():
            assert sha(ROOT / p) == h, p
            original[p] = h
    config = []
    for mode in ["legacy", "symmetric"]:
        for slip in [0, 5]:
            for delay in [0, 1]:
                config.append({"source_mode": mode, "policy": "P0", "activation_policy": "LD10", "slip_pts": slip, "delay_seconds": delay})
    refs = {"path": "", "sha256": ""}
    template = {"version": 1, "trial": 104, "fixed": False, "source_full": dict(refs), "old100_tape_index": {"path": "", "sha256": "4db6812dda91ae4235d15ce5619c19a7dffa305f24ec3f577332d8665b49610f"}, "first2_bind": {"path": "", "sha256": "af23ffae8b9ed96e9c31fbb6195495cfbb85f389421e635c32a0e68cd5c4a548"}, "binder_stop": {"path": "", "sha256": dependencies["work/104新Sourceと判断時計の結合案/停止.json"]}, "baseline103_index": {"path": "", "sha256": "f07280a74d90cb8df9a74d5074370b729e825c1fc19c6a7fe8104ad68c7b68fe"}, "binary": dict(refs), "code_sha256": {}, "configs": config}
    save(HERE / "実行条件の雛形.json", template)

    # ----------------------------------------
    # gofmt後の実関数同士の差分を保存する。
    source = (ROOT / "work/103多玉の一定利益保護/replay.go").read_text(encoding="utf-8")
    old_body = source[source.index("func RunObserved("):source.index("// CompareP0")]
    target = (HERE / "replay.go").read_text(encoding="utf-8")
    new_body = target[target.index("func RunModeObserved("):]
    (HERE / "配送関数の整形後差分.patch").write_text("".join(difflib.unified_diff(old_body.splitlines(True), new_body.splitlines(True), fromfile="停止103/RunObserved", tofile="104/RunModeObserved")), encoding="utf-8")
    logs = HERE / "検査/Go人工_型export.jsonl"
    records = [json.loads(line) for line in logs.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    assert records[-1]["Action"] == "pass"
    tests = [item["Test"] for item in records if item["Action"] == "pass" and "Test" in item]
    artifacts = {p.relative_to(ROOT).as_posix(): sha(p) for p in sorted((HERE / "人工/型export").glob("*.json"))}
    assert len(artifacts) == 5
    counters = {"非0ModeResult会計": 0, "全時点LD10比較": 0, "最終LD10比較": 0}
    for path in (HERE / "人工/型export").glob("方向*.json"):
        value = json.loads(path.read_text(encoding="utf-8"))
        assert set(value["modes"]) == {"legacy", "symmetric"}
        for mode in value["modes"].values():
            assert len(mode["books"]) == 4 and mode["complete"] and mode["input_unchanged"]
            counters["非0ModeResult会計"] += sum(book["totals"]["entry_quantity"] > 0 for book in mode["books"].values())
            counters["最終LD10比較"] += 4
            counters["全時点LD10比較"] += len(value["tape"]["events"]) * 4
    assert counters["非0ModeResult会計"] == 32
    proof = {"成功": True, "scope": "停止103の非0API通知を同じ四Actorへ配送する型人工と、合法空Bindの全8冊を区別。自然対称Source/市場ではない。", "Goトップ": [name for name in tests if "/" not in name], "全pass名数": len(tests), "型人工SHA256": artifacts, **counters, "合法空BindのNative": 8, "合法空旧103全文対照": 4, "default経済会計": 0, "metadata破損拒否": 21, "追加拒否": ["default金融呼出", "旧103Book金額差", "上流count差", "未固定条件"], "test/vet/build": {"test": 0, "vet": 0, "build": 0}, "金融Book除外": [], "Scope外": ["実SourceFull接続", "対称Source自然形成の非0影響", "新期間/未見", "Raw/CSV/本物Native"]}
    save(HERE / "検査/人工確認.json", proof)
    origin = {"成功": True, "依存停止SHA256": dependencies, "元所有指紋": original, "再用": "103 Actor/ConfigKey/ConvertBatches直import。配送関数は設定四への選択・mode/envelope以外を維持。first2 e795のmetadata型/標準IO本文は抽出再用。", "金融式/数値/Source形成/新規時計/数量の変更": 0, "source_full": "Root固定前。未成功/途中Sourceをfirst2にも使用しない。", "実型scope": proof["scope"]}
    save(HERE / "由来と差分.json", origin)

    # ----------------------------------------
    # 条件最終SHAをコードへ埋め込まず、実行前停止を署名する。
    names = ["main.go", "market.go", "replay.go", "io.go", "replay_test.go", "market_test.go", "codec_test.go", "go.mod", "go.sum", "README.md", "派生を準備する.py", "IOを準備する.py", "配送関数の派生差分.patch", "配送関数の整形後差分.patch", "由来と差分.json", "実行条件の雛形.json", "検査/停止を記録する.py"]
    owned = {(HERE / name).relative_to(ROOT).as_posix(): sha(HERE / name) for name in names}
    exe = HERE / "検査/LD10比較.exe"
    assert sha(exe) == "4c76932771db9987e5e561f6784aeab3498e116288c716cf0cd04de583af258e"
    assert all(sha(ROOT / p) == h for p, h in original.items())
    stopped = {"成功": True, "市場前": True, "module": "github.com/masayoshi4649/SessionTradeExecuter/ld10compare104", "所有コードSHA256": owned, "実行物": exe.relative_to(ROOT).as_posix(), "実行物SHA256": sha(exe), "依存停止SHA256": dependencies, "元停止/所有前後不変": True, "人工確認": {"path": (HERE / "検査/人工確認.json").relative_to(ROOT).as_posix(), "SHA256": sha(HERE / "検査/人工確認.json"), **proof}, "主会計": "legacy/symmetric各LD10四。全8×54=432、default経済0", "旧対照": "legacy四だけ旧103正式Native LD10 Book全文。envelope全同体やsymmetricの旧同値には流用しない。", "保存schema": "market.go exact。保存担当とouter8名/inner原値/SourceMode/Control/Completionを合意。", "static_peer": "exit_diagnostic83から配送/Scope/namespace/旧対照の止める差なしを受領。コード読取のみ。", "Root条件": "未固定、同条件first2→full54。SourceA全54成功をfirst2から要求。", "本物SourceFull/旧Native本文/Raw/CSV/実金融/新期間読取実行": 0, "既存103/104正式・停止・SourceAプロセス変更": 0}
    save(HERE / "停止.json", stopped)
    print(json.dumps({"停止SHA256": sha(HERE / "停止.json"), "exeSHA256": sha(exe), "全pass名数": len(tests), **counters}, ensure_ascii=False))


if __name__ == "__main__":
    main()
