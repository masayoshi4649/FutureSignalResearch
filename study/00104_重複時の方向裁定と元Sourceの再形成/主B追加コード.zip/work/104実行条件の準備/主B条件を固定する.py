"""Source全54成功後だけ、104主Bの8会計比較条件を初回固定する。"""

import argparse
import hashlib
import json
import os
from pathlib import Path
import uuid
import zipfile


ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / "study/00104_重複時の方向裁定と元Sourceの再形成"


def read(path: Path) -> dict:
    """
    機能: UTF-8 JSONを読み込む。
    引数: path(Path)は実在資料。
    返り値: dictは保存値。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def sha(path: Path) -> str:
    """
    機能: ファイルの内容指紋を求める。
    引数: path(Path)は参照元。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 成功した全Source、互換確認、全実依存を主B条件へ結ぶ。
    引数: --source-full(str)、--source-full-sha(str)は終端成功の完了path/指紋。
    返り値: None。Raw/CSV/Source本文/金融を再生せず条件と小ZIPを新規保存する。
    """
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-full", required=True)
    parser.add_argument("--source-full-sha", required=True)
    args = parser.parse_args()
    source = Path(args.source_full).resolve()
    assert sha(source) == args.source_full_sha
    completion = read(source)
    assert completion["success"] and completion["stage"] == "full54" and completion["sessions"] == 54
    assert len(completion["cases"]) == 162 and completion["unchanged"] and completion["before"] and completion["before"] == completion["after"]
    assert completion["condition_sha256"] == "05b8275a5c1abb60aab3402c617f62d5583852dacacce48e2b831430223ea266"
    source_plan = read(STUDY / "Source条件.json")
    expected_cases = {(x["session"], mode) for x in source_plan["scenes"] for mode in source_plan["modes"]}
    assert {(x["session"], x["mode"]) for x in completion["cases"]} == expected_cases
    assert completion["source_reformed"] and not completion["financial103_executed"]
    for item in completion["cases"]:
        assert not item.get("error")
        assert item["old93_full_match"] == (item["mode"] != "symmetric")
        for key in ["records", "result"]:
            assert item[key]["path"] and len(bytes.fromhex(item[key]["sha256"])) == 32
    target = STUDY / "主B条件.json"
    archive_path = STUDY / "主B追加コード.zip"
    fixed_path = STUDY / "主B実行前固定.json"
    assert not target.exists() and not archive_path.exists() and not fixed_path.exists()
    code = dict(read(STUDY / "先頭2結合条件.json")["code_sha256"])
    owned = {}
    stop = ROOT / "work/104LD10の全場比較/停止.json"
    assert sha(stop) == "59d7cb6768ebe7825cf031d85012c83710ba3a2926ef8bd2d5d3f22c3c1a54d0"
    assert read(stop)["成功"]
    def add(path: Path, expected: str | None = None, archive: bool = False) -> None:
        """
        機能: 実在する依存を指紋集合へ追加する。
        引数: path(Path)、expected(str|None)、archive(bool)は位置・既知指紋・小追加ZIPの対象。
        返り値: None。指紋差と同pathの衝突を拒否する。
        """
        path = path.resolve()
        try:
            name = os.path.relpath(path, ROOT).replace("\\", "/")
        except ValueError:
            name = path.as_posix()
        value = sha(path)
        assert expected is None or expected == value
        assert name not in code or code[name] == value
        code[name] = value
        if archive:
            owned[path] = value
    add(stop, archive=True)
    for name, expected in read(stop)["所有コードSHA256"].items():
        add(ROOT / name, expected, archive=True)
    add(Path(__file__), archive=True)
    metadata = ROOT / "work/104実行条件の準備/主BGo依存.json"
    add(metadata, archive=True)
    raw = metadata.read_text(encoding="utf-8-sig")
    decoder, offset, packages = json.JSONDecoder(), 0, 0
    fields = ["GoFiles", "CgoFiles", "CFiles", "CXXFiles", "MFiles", "HFiles", "FFiles", "SFiles", "SwigFiles", "SwigCXXFiles", "SysoFiles", "EmbedFiles"]
    while offset < len(raw):
        while offset < len(raw) and raw[offset].isspace():
            offset += 1
        if offset == len(raw):
            break
        package, offset = decoder.raw_decode(raw, offset)
        assert not package.get("Error")
        packages += 1
        for field in fields:
            for name in package.get(field, []):
                add(Path(package["Dir"]) / name)
        module = package.get("Module", {})
        for item in [module, module.get("Replace", {})]:
            if item.get("GoMod"):
                add(Path(item["GoMod"]))
    def ref(path: Path, expected: str | None = None) -> dict:
        """
        機能: 正式条件dir基準のFileRefを作る。
        引数: path(Path)、expected(str|None)は位置と既知指紋。
        返り値: dictは相対path/sha256。
        """
        value = sha(path)
        assert expected is None or expected == value
        return {"path": os.path.relpath(path, STUDY).replace("\\", "/"), "sha256": value}
    condition = read(ROOT / "work/104LD10の全場比較/実行条件の雛形.json")
    assert not condition["fixed"] and len(condition["configs"]) == 8
    condition.update({"fixed": True, "code_sha256": code,
        "source_full": ref(source, args.source_full_sha),
        "old100_tape_index": ref(ROOT / "study/00100_費用後利益化の前後で保護を分ける/正式54Tape台帳.json", "4db6812dda91ae4235d15ce5619c19a7dffa305f24ec3f577332d8665b49610f"),
        "first2_bind": ref(ROOT / "work/104Source結合市場/先頭2場/完了.json", "af23ffae8b9ed96e9c31fbb6195495cfbb85f389421e635c32a0e68cd5c4a548"),
        "binder_stop": ref(ROOT / "work/104新Sourceと判断時計の結合案/停止.json", "e66adae009ff3edfa59b38dd22ffa07c48f83843f045080a4ede0045dab0fbf2"),
        "baseline103_index": ref(ROOT / "study/00103_元の多玉と数量を保つ一定利益後の追尾/成果物/Native参照台帳.json", "f07280a74d90cb8df9a74d5074370b729e825c1fc19c6a7fe8104ad68c7b68fe"),
        "binary": ref(ROOT / "work/104LD10の全場比較/検査/LD10比較.exe", "4c76932771db9987e5e561f6784aeab3498e116288c716cf0cd04de583af258e")})
    for name, expected in code.items():
        path = Path(name) if Path(name).is_absolute() else ROOT / name
        assert sha(path) == expected
    # ----------------------------------------
    # 候補をworkへ全て完成させ、実行に使う条件を最後に排他保存する。
    candidate = ROOT / "work/104主B固定候補" / uuid.uuid4().hex
    candidate.mkdir(parents=True)
    candidate_condition = candidate / target.name
    candidate_archive = candidate / archive_path.name
    candidate_fixed = candidate / fixed_path.name
    candidate_condition.write_text(json.dumps(condition, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with zipfile.ZipFile(candidate_archive, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for path, expected in sorted(owned.items()):
            assert sha(path) == expected
            info = zipfile.ZipInfo(path.relative_to(ROOT).as_posix(), date_time=(2026, 11, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())
    with zipfile.ZipFile(candidate_archive) as archive:
        assert archive.testzip() is None
    for name, expected in code.items():
        path = Path(name) if Path(name).is_absolute() else ROOT / name
        assert sha(path) == expected
    proof = {"成功": True, "市場金融実行前": True, "条件SHA256": sha(candidate_condition), "code数": len(code), "実使用package数": packages,
             "追加ZIP": {"path": archive_path.name, "sha256": sha(candidate_archive), "コード資料数": len(owned)},
             "依存保存": "先頭2結合検査コード.zip/Source再現コード.zip/旧103再現コード.zipの固定参照。stdlib/toolchain本文を重複しない。",
             "Source再形成": False, "主金融実行": 0, "旧103改変": 0}
    candidate_fixed.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for prepared, destination in [(candidate_archive, archive_path), (candidate_fixed, fixed_path), (candidate_condition, target)]:
        with destination.open("xb") as stream:
            stream.write(prepared.read_bytes())
        assert sha(destination) == sha(prepared)
    print(json.dumps({"成功": True, "条件SHA256": sha(target), "code数": len(code)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
