package minisymmetric104

import (
	"bytes"
	"encoding/json"
	"fmt"
	"math"
	"os"
	"path/filepath"
	"testing"

	"github.com/masayoshi4649/SessionTradeExecuter/internal/rules"
	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	old "github.com/masayoshi4649/SessionTradeExecuter/mininative"
)

type binding104 struct {
	Method      string  `json:"method"`
	Path        string  `json:"path"`
	Profile     string  `json:"profile"`
	RuleHash    string  `json:"rule_hash"`
	Expression  string  `json:"expression"`
	OverlapSide float64 `json:"overlap_side"`
	Active145   bool    `json:"active145"`
}

// testSession104 はSourceを生成できる最小の人工時計を返します。
//
// 引数: method(string)は対象三手法です。
// 返り値: Sessionは手製Day/Nightで実入力ではありません。
func testSession104(method string) Session {
	kind := "Night"
	if method == "D164_15" {
		kind = "Day"
	}
	return Session{ID: "生成口人工_" + kind, Kind: kind, Start: 1000, End: 20600, ForceClose: 20000, USOpen: 6000, ExtraAt: 6900, NightCoreStart: 1000}
}

// equal104 は旧保存型を全fieldのJSONで比較します。
//
// 引数: t(*testing.T)、a/b(any)は試験器と比較値です。
// 返り値: ありません。nil/空と全配列順を除外しません。
func equal104(t *testing.T, a, b any) {
	t.Helper()
	x, e := json.Marshal(a)
	if e != nil {
		t.Fatal(e)
	}
	y, e := json.Marshal(b)
	if e != nil {
		t.Fatal(e)
	}
	if !bytes.Equal(x, y) {
		t.Fatalf("全JSON差\n%s\n%s", x, y)
	}
}

// Test104EmptyOverride は自然Portfolioへ空人工特徴を渡し旧adapterと全時点比較します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。fake book/手製Signalへ差し替えず、自然新規発生の証明にはしません。
func Test104EmptyOverride(t *testing.T) {
	for _, method := range []string{"D164_15", "P164_06", "U165_03"} {
		for _, product := range []ProductConfig{MiniConfig(), MicroControlConfig()} {
			for _, mode := range []string{"nil", "空map", "既定全式", "互換NewAdapter"} {
				t.Run(method+"/"+product.Product+"/"+mode, func(t *testing.T) {
					s := testSession104(method)
					var expressions map[string]string
					if mode == "空map" {
						expressions = map[string]string{}
					}
					if mode == "既定全式" {
						var e error
						expressions, e = DefaultRuleExpressions(method, s)
						if e != nil {
							t.Fatal(e)
						}
					}
					b, e := NewAdapterWithRules(method, s, product, expressions)
					if mode == "互換NewAdapter" {
						b, e = NewAdapter(method, s, product)
					}
					if e != nil {
						t.Fatal(e)
					}
					legacy, e := old.NewAdapter(method, s, product)
					if e != nil {
						t.Fatal(e)
					}
					if _, ok := b.book.(*portfolioBook); !ok {
						t.Fatal("自然Portfolio以外")
					}
					equal104(t, b.Snapshot(), legacy.Snapshot())
					for i, at := range []float64{1100, 1100, 1101, 3000, 6000, 6900, 19000} {
						o := Observation{Reference: "NK225", Time: at, Received: at, Index: int64(i), Last: 1005, Bid: 1000, Ask: 1010, QuoteOK: true}
						o.Selected.NightAvailable, o.Selected.NightTime, o.Selected.NightIndex = true, at, o.Index
						if i == 2 {
							o.QuoteOK = false
							o.Bid = 0
							o.Ask = 0
						}
						x, e := b.Step(o, int64(i)+20)
						y, e0 := legacy.Step(o, int64(i)+20)
						if e != nil || e0 != nil {
							t.Fatal(e, e0)
						}
						equal104(t, x, y)
						equal104(t, b.Snapshot(), legacy.Snapshot())
					}
					x, e := b.Force(20000)
					y, e0 := legacy.Force(20000)
					if e != nil || e0 != nil {
						t.Fatal(e, e0)
					}
					equal104(t, x, y)
					equal104(t, b.Snapshot(), legacy.Snapshot())
					z, e := b.Finish()
					z0, e0 := legacy.Finish()
					if e != nil || e0 != nil {
						t.Fatal(e, e0)
					}
					equal104(t, z, z0)
					if !z.Complete || len(z.Fills) != 0 || len(z.Signals) != 0 {
						t.Fatal("空特徴scopeが不正")
					}
				})
			}
		}
	}
}

// collect104 は生成済み公開PortfolioのRulesと実addon評価器を辿ります。
//
// 引数: t(*testing.T)、method/path(string)、p(*strategy.Portfolio)は試験器と現在の所有木です。
// 返り値: []binding104は実際に接続された式/overlap評価です。coreの別profileは強制変更しません。
func collect104(t *testing.T, method, path string, p *strategy.Portfolio) []binding104 {
	t.Helper()
	if p == nil {
		return nil
	}
	out := []binding104{}
	check := func(path string, rt *rules.Runtime, active bool) {
		if rt == nil || rt.Set == nil {
			t.Fatal("評価器欠落", path)
		}
		if code, ok := rt.Set.Expressions()[RangeSideRuleID]; ok {
			if code != SymmetricRangeSideExpression {
				t.Fatal("内側で旧式へ戻った", path)
			}
			env := map[string]any{"efficiency": 0.2, "mid": 105.0, "low": 100.0, "high": 110.0, "risk": 100.0}
			v := rt.Number(RangeSideRuleID, env)
			if rt.Err() != nil || v != 0 {
				t.Fatal("実評価器の重複待機", path, v, rt.Err())
			}
			out = append(out, binding104{method, path, rt.Set.Profile(), rt.Set.Hash(), code, v, active})
		}
	}
	check(path+".Rules", p.Rules, false)
	if p.Selected != nil {
		out = append(out, collect104(t, method, path+".Selected.Shadow", p.Selected.Shadow)...)
	}
	if p.S01 != nil {
		out = append(out, collect104(t, method, path+".S01.Shadow", p.S01.Shadow)...)
	}
	if p.P05 != nil {
		out = append(out, collect104(t, method, path+".P05.Shadow", p.P05.Shadow)...)
	}
	if p.Research != nil {
		for _, s := range p.Research.Sleeves {
			check(path+".Research."+s.Name+".Rules", s.Source.Rules, false)
			if s.Source.Active145 != nil {
				check(path+".Research."+s.Name+".Active145.Rules", s.Source.Active145.Rules, true)
			}
			for _, inner := range []*strategy.Portfolio{s.Source.Legacy, s.Source.Supplement} {
				if inner != nil && inner.Rules != nil {
					if _, exists := inner.Rules.Set.Expressions()[RangeSideRuleID]; exists {
						t.Fatal("別profileのcoreへD07式を混入")
					}
				}
			}
		}
	}
	return out
}

// inheritance104 は三手法へ全式overrideを渡し、継承と入力map不変を検査します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: []binding104は三手法内の実評価器の結合証拠です。
func inheritance104(t *testing.T) []binding104 {
	t.Helper()
	out := []binding104{}
	for _, method := range []string{"D164_15", "P164_06", "U165_03"} {
		s := testSession104(method)
		base, e := DefaultRuleExpressions(method, s)
		if e != nil {
			t.Fatal(e)
		}
		full, e := SymmetricRuleExpressions(method, s)
		if e != nil {
			t.Fatal(e)
		}
		if len(base) != len(full) {
			t.Fatal("全式件数")
		}
		changed := 0
		for id, expr := range base {
			if full[id] != expr {
				if id != RangeSideRuleID {
					t.Fatal("別の式変更", id)
				}
				changed++
			}
		}
		if changed != 1 {
			t.Fatal("1式限定")
		}
		before, _ := json.Marshal(full)
		b, e := NewAdapterWithRules(method, s, MiniConfig(), full)
		if e != nil {
			t.Fatal(e)
		}
		after, _ := json.Marshal(full)
		if !bytes.Equal(before, after) {
			t.Fatal("入力map副作用")
		}
		p := b.book.(*portfolioBook).Portfolio
		if p.Config.RuleExpressions[RangeSideRuleID] != SymmetricRangeSideExpression {
			t.Fatal("Config.RuleExpressions欠落")
		}
		full[RangeSideRuleID] = "999.0"
		fresh, _ := DefaultRuleExpressions(method, s)
		if fresh[RangeSideRuleID] != base[RangeSideRuleID] || p.Config.RuleExpressions[RangeSideRuleID] != SymmetricRangeSideExpression {
			t.Fatal("map所有分離")
		}
		rows := collect104(t, method, "Portfolio", p)
		n := 0
		for _, v := range rows {
			if v.Active145 {
				n++
			}
		}
		if n == 0 {
			t.Fatal("実addon評価器へ届かない", method)
		}
		out = append(out, rows...)
	}
	return out
}

// Test104RuleInheritance はD/P/Uの内側とActive145までの継承を確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。人工の式実行であり、自然Source発動数/経済影響は未測定です。
func Test104RuleInheritance(t *testing.T) { inheritance104(t) }

// Test104RangeExpression は旧優先と新しい重複待機を境界/鏡像で比較します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。価格反射の厳密対称はこの1式の入力空間だけです。
func Test104RangeExpression(t *testing.T) {
	s := testSession104("D164_15")
	full, e := SymmetricRuleExpressions("D164_15", s)
	if e != nil {
		t.Fatal(e)
	}
	profile, _ := rules.SelectProfile("NK225", "Day", "D164_15")
	rt, e := rules.NewRuntimeFor(profile, full)
	if e != nil {
		t.Fatal(e)
	}
	standard, e := rules.NewRuntimeFor(profile, nil)
	if e != nil {
		t.Fatal(e)
	}
	for _, c := range []struct {
		name                              string
		eff, mid, lo, hi, risk, want, old float64
	}{
		{"低側のみ", .3, 101, 100, 200, 10, 1, 1}, {"高側のみ", .3, 199, 100, 200, 10, -1, -1}, {"両方なし", .3, 150, 100, 200, 10, 0, 0}, {"両方真", .3, 105, 100, 110, 100, 0, 1}, {"両境界同値", .3, 105, 100, 110, 50, 0, 1}, {"低側等号", .3, 101, 100, 200, 10, 1, 1}, {"高側等号", .3, 199, 100, 200, 10, -1, -1}, {"ER超過", math.Nextafter(.3, 1), 101, 100, 200, 10, 0, 0},
	} {
		t.Run(c.name, func(t *testing.T) {
			env := map[string]any{"efficiency": c.eff, "mid": c.mid, "low": c.lo, "high": c.hi, "risk": c.risk}
			copyBefore, _ := json.Marshal(env)
			v := rt.Number(RangeSideRuleID, env)
			v0 := standard.Number(RangeSideRuleID, env)
			if rt.Err() != nil || standard.Err() != nil || v != c.want || v0 != c.old {
				t.Fatal(v, v0, rt.Err(), standard.Err())
			}
			mirror := map[string]any{"efficiency": c.eff, "mid": 300 - c.mid, "low": 300 - c.hi, "high": 300 - c.lo, "risk": c.risk}
			m := rt.Number(RangeSideRuleID, mirror)
			if rt.Err() != nil || m != -v {
				t.Fatal("式鏡像", v, m)
			}
			copyAfter, _ := json.Marshal(env)
			if !bytes.Equal(copyBefore, copyAfter) {
				t.Fatal("式入力map変更")
			}
		})
	}
}

// Test104RejectPartial は部分map/未知キー/型破損を補完せず拒否します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。旧constructorの手法/場/商品制限も維持します。
func Test104RejectPartial(t *testing.T) {
	s := testSession104("D164_15")
	for _, mode := range []string{"1キー", "欠落", "未知置換", "型", "変数"} {
		m, e := DefaultRuleExpressions("D164_15", s)
		if e != nil {
			t.Fatal(e)
		}
		switch mode {
		case "1キー":
			m = map[string]string{RangeSideRuleID: SymmetricRangeSideExpression}
		case "欠落":
			delete(m, RangeSideRuleID)
		case "未知置換":
			v := m[RangeSideRuleID]
			delete(m, RangeSideRuleID)
			m["誤記"] = v
		case "型":
			m[RangeSideRuleID] = "true"
		case "変数":
			m[RangeSideRuleID] = "future_unknown"
		}
		if _, e := NewAdapterWithRules("D164_15", s, MiniConfig(), m); e == nil {
			t.Fatal("破損map成功", mode)
		}
	}
	if _, e := NewAdapterWithRules("D07", s, MiniConfig(), nil); e == nil {
		t.Fatal("別手法")
	}
	if _, e := DefaultRuleExpressions("D07", s); e == nil {
		t.Fatal("既定口別手法")
	}
	if _, e := NewAdapterWithRules("P164_06", s, MiniConfig(), nil); e == nil {
		t.Fatal("異場手法")
	}
	product := MiniConfig()
	product.Cap = 11
	if _, e := NewAdapterWithRules("D164_15", s, product, nil); e == nil {
		t.Fatal("商品条件の変更")
	}
}

// Test104Export は明示した新規先へ小型の生成口継承証拠だけを保存します。
//
// 引数: t(*testing.T)、環境SYMMETRIC104_EXPORT(string)は試験器と新規JSONです。
// 返り値: ありません。市場/Source通知の成果物は作りません。
func Test104Export(t *testing.T) {
	name := os.Getenv("SYMMETRIC104_EXPORT")
	if name == "" {
		t.Skip("明示exportなし")
	}
	if _, e := os.Stat(name); !os.IsNotExist(e) {
		t.Fatal("新規出力だけ")
	}
	if e := os.MkdirAll(filepath.Dir(name), 0755); e != nil {
		t.Fatal(e)
	}
	rows := inheritance104(t)
	expressions := map[string]map[string]string{}
	for _, method := range []string{"D164_15", "P164_06", "U165_03"} {
		m, e := SymmetricRuleExpressions(method, testSession104(method))
		if e != nil {
			t.Fatal(e)
		}
		expressions[method] = m
	}
	data, e := json.MarshalIndent(map[string]any{"expressions": expressions, "成功": true, "scope": "手製envによる生成時式継承。市場Source自然発動/経済影響は未測定。", "bindings": rows, "changed_rule": RangeSideRuleID, "expression": SymmetricRangeSideExpression, "市場実行": 0}, "", "  ")
	if e != nil {
		t.Fatal(e)
	}
	if e = os.WriteFile(name, append(data, '\n'), 0644); e != nil {
		t.Fatal(e)
	}
	fmt.Println("式継承証跡", len(rows))
}
