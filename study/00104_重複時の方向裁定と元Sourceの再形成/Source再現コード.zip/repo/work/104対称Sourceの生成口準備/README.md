# 対称Sourceの生成口準備（未採番104候補）

module `github.com/masayoshi4649/SessionTradeExecuter/minisymmetric104`、package `minisymmetric104`。SessionTradeExecuterのinternal APIを利用できるmodule名を維持し、依存は固定した兄弟repoをreplaceする。正式試行は最大103のまま、本dir名は将来候補である。原仕様は[仕様.md](仕様.md)、出典指紋は[元指紋.json](元指紋.json)。固定Source43と旧93は変更しない。

公開口:

- `NewAdapter(method, Session, ProductConfig)` は旧既定のまま。
- `NewAdapterWithRules(method, Session, ProductConfig, map[string]string)` は指定profileの**完全式map**で生成。nil/長さ0は旧nilへ、非空は元rules.CompileForで型・全キーを検査する。1キーの部分mapは補完せず拒否する。
- `DefaultRuleExpressions(method, Session)` はD/P/U対象profileの既定全式の独立copy。
- `SymmetricRuleExpressions(method, Session)` は既定copyの `addon.entry.range_side` だけを新しい候補式へ替える。全式件数はD60/P60/U54。

```go
expressions, err := minisymmetric104.SymmetricRuleExpressions(method, session)
if err != nil { return err }
adapter, err := minisymmetric104.NewAdapterWithRules(method, session, minisymmetric104.MiniConfig(), expressions)
```

候補の唯一の差分は、既存 `efficiency<=0.3` 内で `mid<=low+0.1*risk` と `mid>=high-0.1*risk` が両方真なら0、唯一成立なら+1/-1とすること。両方偽も0。ER/0.1R/等号/数量/価格構造の入力は変えない。閾値を再調整した候補ではなく、旧買い優先重複を待機へ変える1式候補。

adapter.goを旧93から小派生し、生成時にConfig.RuleExpressionsを渡す。通知/予約/SelectedCancellationIDs/Fill/OnOrderDone/SourcePortfolio/Force/外費用の判断を作り直さない。公開Ledger/Signal/Fill/StepResult等は旧mininative aliasなので、元の保存型/JSONを維持する。新Ledgerへルール欄は足していない。将来のreplay envelopeで使用全map/指紋を別に固定する必要がある。

aliasは他packageの型になるため、旧adapterの5つの無名フィールドliteralを同じ値のkey付きliteralへ機械変更した。初回vetがここを指摘した証拠を残し、変更後test/vet/buildを確認した。算術・値・更新順序の変更ではない。[本文差分.patch](本文差分.patch)にconstructorとこの5点だけを示す。

## 人工の範囲

```powershell
Set-Location 'work/104対称Sourceの生成口準備'
go test -json -count=1 ./...
go vet ./...
go build ./...
# 未使用の新規JSONへ、小型全式map/実評価器の結合だけを出す。
$env:SYMMETRIC104_EXPORT = '<新規JSON絶対path>'
go test -count=1 -run '^Test104Export$' ./...
Remove-Item Env:SYMMETRIC104_EXPORT
```

空override(nil/空map)、既定全map、互換NewAdapterの4種×D/P/U×mini/micro=24経路で、手製Observation→元strategy.Portfolio→Step/Force/Finishを実行し、旧93と全時点/最終JSONを除外0比較した。空の人工特徴なので自然新規/実fillは0であり、新しいSource生成の非0成功と呼ばない。book差替え/fakeNativeBatch/手製Signalは使用していない。

D→Selected.Shadow(S01)→D07、P→Selected.Shadow(P05)→D07、U→Selected.Shadow(D07)を、生成済みの公開Portfolio/Rulesから辿った。24の接続式評価器（うちActive145が4）で新しい式を保持し、重複envの実Runtime.Numberが0になった。coreの別profile T06/U06の旧標準式へD07全式を流用しない既存境界も確認した。これは内側への継承と式評価の確認であり、自然時系列でrange_sideが発動したという証拠ではない。

旧式の重複+1/新式0、唯一成立±1、両方なし0、ER等号/超過、価格境界等号、1式だけの算術価格反射を8条件で検査。部分map/欠落/未知キー/型/変数/商品/異場/別手法を拒否し、入力mapの独立copyを確認した。

制約:

- 自然Source全体の完全売買鏡像は未確認。bpの相対変化などは別の問題で、この1式を変えて解決したとは言わない。
- 固定旧source_asymの自然発動・経済影響・実市場/Raw/CSV/Native/新損益は未測定/未読。
- 実データSource再運転、条件/採番、既存Replayの変更はRootの別固定後。今回の候補全mapは人工証跡に固定しただけ。
- 旧replay factoryが具体*mininative.Adapterを保持する場合、新*minisymmetric104.Adapterとは別型である。将来はStep/Force/Snapshot/Finishの共通interfaceをfactory戻り口に置く最小adapterか別replay版が必要。旧Replay本文は今回変更していない。
