# 104 Source再生の接続準備（未採番・市場未実行）

module/package `github.com/masayoshi4649/SessionTradeExecuter/minisourcereplay104` / `minisourcereplay104`。停止e519の[生成口](../104対称Sourceの生成口準備/README.md)を、旧93の完全Observation経路へ接続する準備である。旧93/固定Source43/生成口停止は変更しない。

## APIと差分

- `Replay(root,input)` / `ReplayWithFactory(root,input,factory)`：旧93同体のinput.goで指紋、限月、時計を検査し、二市場板と60/300足を読み、同じFeaturesを作る。**今段階はこの実IO口を呼んでいない。**
- `SourceAdapter`：旧93と新生成口のStep/Force/Snapshot/Finish公開型の共通interface。保存Ledgerは旧93 aliasでfieldを落とさない。
- `AdapterFactory`：元のmethod/session/productを受ける生成時だけの差替口。nilは旧93 NewAdapterそのもの。
- `RuleFactory(RuleEmpty/RuleDefault/RuleSymmetric)`：停止e519のNewAdapterWithRulesへ、空override/既定完全map/対称1式完全mapを渡す。空は旧nil、非空は全式必須、D60/P60/U54。新式はrange_sideだけ。
- `ReplayPrepared(session,boards,candles,factory)`：IOをせず、手製又は将来事前固定した**完全**Board/Candleを旧Featuresへ通す人工/将来hook口。ScalarやCurrentから不足する特徴を埋める口ではない。

input.goは元SHA付きコメントとpackage以外の本文同体。replay.goの入力検査/特徴設定/読込/sort部分はLedger型alias名以外同体。生成以降は共通replayLoadedへ切り出し、adapterの具体型→interfaceとconstructor→factory呼出以外に旧loopの本文差なしを機械照合した。Source会計の再実装はない。[本文差分.patch](本文差分.patch)と[由来と差分.json](由来と差分.json)を参照。

旧順はglobal board時計で `timer処理→公開可能candles→Last>0のFeatures.OnBoard→NKだけ全active adapter.Step`。同時計のTOPIX/NKは読込TOPIX先のstable sortを維持する。Forceは原行前、Pの米国前Force後にForced&&Completeを確認してからUS+900でUを生成する。Pも返済・完結のため以後の原行へ継続配送する。末尾は未実在の気配でfillせずForceのみ、Finish未完結/窓欠落/SourceRows0はfail。

miniは5+5/上限10/点価100/片道38.5、microは50+50/上限100/点価10/片道11の固定対照。元Sourceの内部基準mini状態は旧93のまま。両者の数量/粗額を同じ尺度と呼ばない。元判断へ外費用を返さない。

## 人工

```powershell
Set-Location 'work/104Source再生の接続準備'
go test -json -count=1 ./...
go vet ./...
go build ./...
# 新規小型JSONだけ。実IO/CLI実行ではない。
$env:SOURCE104_PREPARED_EXPORT = '<新規JSON絶対path>'
go test -count=1 -run '^Test104PreparedExport$' ./...
Remove-Item Env:SOURCE104_PREPARED_EXPORT
```

手製Day/Nightの二市場板・正の板数量・公開3本の確定5分足から実Featuresを通し、非0のOwn5支持とnative ATR40/公開時計を持つ完全Observationを実adapterへ渡した。fakeNativeBatch/手製Signal/book差替えはない。空/defaultは旧生成口と全配送（Observation/StepResult/Snapshot）・最終JSONが除外0一致。Symも同じ口を通してD/P/U窓を完結する。P Force→U切替、同時計Force先行、mini/micro尺度、U未観測/末尾全欠測failも確認した。

型人工は[完全入力の接続.json](人工確認/完全入力の接続.json)。8case=Day/Night×legacy/empty/default/symmetric、完全配送はSHA、少数Observation全値と保存結果を残す。人工波で自然Sourceの新規/Fillは0であり、**実Featuresの非0Observationを通した確認と、非0自然Source発動は別**。自然Sourceの保有残を作ったEOF不足例は今回未検査、旧adapter.Finishの残玉/予約fail本文を維持しているだけ。旧93の実データ一致・新対称式の自然発動/経済影響・全面鏡像はいずれも未確認。

## 読込メモリと次の選択

Direct93は二市場のBoardRowを全件sliceへ読み、結合してstable sortする。Candleも全件保持し、Ledgerも通知/Fill履歴が増える。並列場数を増やせばこの常駐分が重なる。今回実データを読んでいないため実RSS/場サイズは未測定。最初はRoot固定の先頭2場・小workerで旧nil/新defaultの実出力全文を別々に確認してから、Symの新Source再形成へ進む必要がある。コード類似/この人工を旧93の市場一致へ代用しない。

代案は別版continuous builderで `Features.OnBoard` が返した**完全Observation**を、Scalarへの射影前にSource consumerへ同期hookする方法。価格時計によるForce/P-U切替は全boardの前に進め、candles/Last0/同時計相手行/FeaturesIndexと物理行の規則を旧93へ合わせる必要がある。保存済Scalar11/Current/Chartだけから完全Source特徴を復元してはならない。既存builderはSource形成なしの別scopeなので、hookで新Sourceを動かすなら新producer版/metadata/同値証拠が必要であり旧停止を書き換えない。

既存WriteStreamは出力Rows/Traceの蓄積を抑えるが、Request.Rowsとbuild.prepareの入力配列は保持するため、hookだけで原板読込メモリが消えるとは言えない。真の二市場逐次mergeは別IO変更・順序照合を伴う。今回は共通interface/factoryまでの最小接続を選び、stream化/旧Replayの書換え/市場CLI/条件作成は行っていない。
