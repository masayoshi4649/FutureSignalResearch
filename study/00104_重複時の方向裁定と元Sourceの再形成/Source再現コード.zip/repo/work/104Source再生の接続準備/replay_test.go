package minisourcereplay104

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"path/filepath"
	"testing"

	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
)

type delivery104 struct {
	Kind        string            `json:"kind"`
	Method      string            `json:"method"`
	Product     string            `json:"product"`
	At          float64           `json:"at"`
	Line        int64             `json:"line"`
	Observation json.RawMessage   `json:"observation,omitempty"`
	Delta       native.StepResult `json:"delta"`
	State       native.Ledger     `json:"state"`
}
type tracing104 struct {
	inner           SourceAdapter
	method, product string
	log             *[]delivery104
}

// Step は実adapterへ完全Observationを値のまま渡して配送証跡を残します。
//
// 引数: o(Observation)、line(int64)はFeaturesが生成した全値と人工物理行です。
// 返り値: native.StepResult/errorは実adapterの値です。Signalやbatchを手製しません。
func (x *tracing104) Step(o Observation, line int64) (native.StepResult, error) {
	raw, e := json.Marshal(o)
	if e != nil {
		return native.StepResult{}, e
	}
	v, e := x.inner.Step(o, line)
	after, e0 := json.Marshal(o)
	if e0 != nil || !bytes.Equal(raw, after) {
		return v, fmt.Errorf("完全Observationの入力副作用")
	}
	*x.log = append(*x.log, delivery104{"step", x.method, x.product, o.Time, line, raw, v, x.inner.Snapshot()})
	return v, e
}

// Force は元timerを実adapterへ渡し、原行や約定を生成しません。
//
// 引数: at(float64)は旧timerです。
// 返り値: native.StepResult/errorは元の取消/返済通知です。
func (x *tracing104) Force(at float64) (native.StepResult, error) {
	v, e := x.inner.Force(at)
	*x.log = append(*x.log, delivery104{Kind: "force", Method: x.method, Product: x.product, At: at, Delta: v, State: x.inner.Snapshot()})
	return v, e
}

// Snapshot は同じ実adapterの保存値を返します。
//
// 引数: ありません。
// 返り値: native.Ledgerは元の深いcopyです。
func (x *tracing104) Snapshot() native.Ledger { return x.inner.Snapshot() }

// Finish は実adapterの完結結果を返します。
//
// 引数: ありません。
// 返り値: native.Ledger/errorは元の完結又は失敗です。
func (x *tracing104) Finish() (native.Ledger, error) { return x.inner.Finish() }

// traceFactory104 は生成時だけの型変換を観測し、元Sourceを差し替えません。
//
// 引数: f(AdapterFactory)、log(*[]delivery104)は実生成口と人工証跡です。
// 返り値: AdapterFactoryは実adapterを包む読取口です。
func traceFactory104(f AdapterFactory, log *[]delivery104) AdapterFactory {
	return func(method string, s Session, c native.ProductConfig) (SourceAdapter, error) {
		b, e := createAdapter(f, method, s, c)
		if e != nil {
			return nil, e
		}
		*log = append(*log, delivery104{Kind: "create", Method: method, Product: c.Product, At: s.Start, State: b.Snapshot()})
		return &tracing104{b, method, c.Product, log}, nil
	}
}

// prepared104 は実ファイルを使わない二市場板と確定足を作ります。
//
// 引数: night(bool)は場種です。
// 返り値: Session/[]BoardRow/[]CandleEventは正の価格/数量を持つ人工完全入力です。
func prepared104(night bool) (Session, []BoardRow, []CandleEvent) {
	s := Session{ID: "完全入力人工_Day", Kind: "Day", Start: 1000, End: 5000, ForceClose: 4400}
	if night {
		s = Session{ID: "完全入力人工_Night", Kind: "Night", Start: 1000, End: 12000, ForceClose: 11400, USOpen: 6000, ExtraAt: 7800}
	}
	rows := []BoardRow{}
	candles := []CandleEvent{}
	// 実loaderと同じく全TOPIXを先、次に全NKの順で安定sortへ渡す。
	for _, ref := range []string{"TOPIX", "NK225"} {
		base, tick := 1000.0, .5
		if ref == "NK225" {
			base, tick = 50000, 10
		}
		for i := 0; i < 3; i++ {
			at := s.Start + float64(i*300)
			candles = append(candles, CandleEvent{Reference: ref, Interval: 300, At: at + 360, Candle: strategy.Candle{Closed: true, Time: at, Open: base, High: base + 2*tick, Low: base - 2*tick, Close: base + tick}})
		}
		for i := 0; i <= 64; i++ {
			at := s.Start + 1000 + float64(i*5)
			mid := base + float64(i)*tick
			rows = append(rows, BoardRow{Board: strategy.Board{Reference: ref, Time: at, Received: at, Last: mid, Bid: mid - tick/2, Ask: mid + tick/2, BidQuantity: 100 + float64(i), AskQuantity: 80}, Line: int64(20 + i)})
		}
		if night {
			for i, at := range []float64{s.USOpen - 901, s.USOpen - 900, s.USOpen - 899, s.USOpen + 900, s.USOpen + 901} {
				rows = append(rows, BoardRow{Board: strategy.Board{Reference: ref, Time: at, Received: at, Last: base, Bid: base - tick/2, Ask: base + tick/2, BidQuantity: 100, AskQuantity: 80}, Line: int64(90 + i)})
			}
		}
		rows = append(rows, BoardRow{Board: strategy.Board{Reference: ref, Time: s.ForceClose + 1, Received: s.ForceClose + 1, Last: base, Bid: base - tick/2, Ask: base + tick/2, BidQuantity: 100, AskQuantity: 80}, Line: 100})
	}
	return s, rows, candles
}

// equalPrepared104 は全保存fieldを除外なしで比較します。
//
// 引数: t(*testing.T)、a/b(any)は試験器と実値です。
// 返り値: ありません。旧93の実原板一致とは別の人工配送比較です。
func equalPrepared104(t *testing.T, a, b any) {
	t.Helper()
	x, e := json.Marshal(a)
	if e != nil {
		t.Fatal(e)
	}
	y, e := json.Marshal(b)
	if e != nil {
		t.Fatal(e)
	}
	if !bytes.Equal(x, y) {
		t.Fatal("完全入力の配送/結果JSON差")
	}
}

// Test104FullObservationFactory は旧生成口と新nil/defaultの全配送/最終を比較します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。実Featuresを通し、Scalar/Currentで代用しません。
func Test104FullObservationFactory(t *testing.T) {
	for _, night := range []bool{false, true} {
		t.Run(fmt.Sprint("Night", night), func(t *testing.T) {
			s, rows, candles := prepared104(night)
			before, _ := json.Marshal([]any{rows, candles})
			oldTrace := []delivery104{}
			baseline, e := ReplayPrepared(s, rows, candles, traceFactory104(nil, &oldTrace))
			if e != nil {
				t.Fatal(e)
			}
			for _, mode := range []RuleMode{RuleEmpty, RuleDefault} {
				f, e := RuleFactory(mode)
				if e != nil {
					t.Fatal(e)
				}
				trace := []delivery104{}
				r, e := ReplayPrepared(s, rows, candles, traceFactory104(f, &trace))
				if e != nil {
					t.Fatal(e)
				}
				equalPrepared104(t, r, baseline)
				equalPrepared104(t, trace, oldTrace)
			}
			after, _ := json.Marshal([]any{rows, candles})
			if !bytes.Equal(before, after) {
				t.Fatal("準備済み入力の副作用")
			}
			seenNonzero := false
			seenATR := false
			for _, call := range oldTrace {
				if call.Kind != "step" {
					continue
				}
				var o Observation
				if e := json.Unmarshal(call.Observation, &o); e != nil {
					t.Fatal(e)
				}
				if o.Selected.DayBuy.Own5 != 0 {
					seenNonzero = true
				}
				if o.ATR > 0 {
					seenATR = true
				}
				if o.Time == s.Start+1000 && (o.ATR != 40 || o.E01.ATRAvailable != s.Start+960) {
					t.Fatal("公開済み3本の確定足がOnBoardより後へ回った")
				}
				if len(call.Observation) < 500 {
					t.Fatal("完全Observationがscalar化")
				}
			}
			if !seenNonzero || !seenATR {
				t.Fatal("実Featuresの非0支持/ATR未通過", seenNonzero, seenATR)
			}
			for key, b := range baseline.Books {
				if !b.Complete || b.Config.Product == "NK225mini" && b.Config.Cap != 10 || b.Config.Product == "NK225micro" && b.Config.Cap != 100 {
					t.Fatal("商品尺度", key)
				}
			}
		})
	}
}

// Test104SymmetricFactory は新全式生成口を同じ完全入力へ結びます。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。自然発動/経済効果を旧93一致から推定しません。
func Test104SymmetricFactory(t *testing.T) {
	f, e := RuleFactory(RuleSymmetric)
	if e != nil {
		t.Fatal(e)
	}
	for _, night := range []bool{false, true} {
		s, rows, cs := prepared104(night)
		r, e := ReplayPrepared(s, rows, cs, f)
		if e != nil {
			t.Fatal(e)
		}
		expected := 2
		if night {
			expected = 4
		}
		if len(r.Books) != expected {
			t.Fatal("Sym生成窓欠落")
		}
	}
	if _, e := RuleFactory("unknown"); e == nil {
		t.Fatal("未知mode")
	}
}

// Test104TimerAndEnd はP完結後U生成/Force先行/末尾不足を保存順で確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。未実在の末尾気配/特徴を生成しません。
func Test104TimerAndEnd(t *testing.T) {
	s, rows, cs := prepared104(true)
	trace := []delivery104{}
	r, e := ReplayPrepared(s, rows, cs, traceFactory104(nil, &trace))
	if e != nil {
		t.Fatal(e)
	}
	for _, product := range []string{"NK225mini", "NK225micro"} {
		forced := false
		createdU := false
		for _, call := range trace {
			if call.Product != product {
				continue
			}
			if call.Kind == "force" && call.Method == "P164_06" && call.At == s.USOpen-900 {
				forced = true
			}
			if call.Kind == "create" && call.Method == "U165_03" {
				if !forced {
					t.Fatal("P終了前にU生成")
				}
				createdU = true
			}
			if call.Kind == "step" && call.Method == "P164_06" && call.At == s.USOpen-900 && !call.State.Forced {
				t.Fatal("同時計原行前にForceがない")
			}
		}
		if !createdU {
			t.Fatal("U未生成")
		}
	}
	if !r.Books["mini_P164_06"].Forced || !r.Books["mini_P164_06"].Complete {
		t.Fatal("P完結")
	}
	short := []BoardRow{}
	for _, row := range rows {
		if row.Board.Time < s.USOpen+900 {
			short = append(short, row)
		}
	}
	if _, e := ReplayPrepared(s, short, cs, nil); e == nil {
		t.Fatal("U窓未観測を成功化")
	}
	if _, e := ReplayPrepared(s, nil, nil, nil); e == nil {
		t.Fatal("末尾/全原行欠測を成功化")
	}
}

// Test104PreparedExport は手製完全入力の配送指紋と少数Observationを実Go型で保存します。
//
// 引数: t(*testing.T)、環境SOURCE104_PREPARED_EXPORT(string)は試験器と新規JSONです。
// 返り値: ありません。実市場や自然Source発動の成功は保存しません。
func Test104PreparedExport(t *testing.T) {
	path := os.Getenv("SOURCE104_PREPARED_EXPORT")
	if path == "" {
		t.Skip("明示exportなし")
	}
	if _, e := os.Stat(path); !os.IsNotExist(e) {
		t.Fatal("新規出力だけ")
	}
	if e := os.MkdirAll(filepath.Dir(path), 0755); e != nil {
		t.Fatal(e)
	}
	rows := []map[string]any{}
	for _, night := range []bool{false, true} {
		s, boards, cs := prepared104(night)
		var baseline ReplayResult
		var baselineTrace []delivery104
		for _, mode := range []string{"legacy", "empty", "default", "symmetric"} {
			var factory AdapterFactory
			var e error
			if mode != "legacy" {
				m := RuleMode(mode)
				if mode == "empty" {
					m = RuleEmpty
				}
				factory, e = RuleFactory(m)
				if e != nil {
					t.Fatal(e)
				}
			}
			trace := []delivery104{}
			r, e := ReplayPrepared(s, boards, cs, traceFactory104(factory, &trace))
			if e != nil {
				t.Fatal(e)
			}
			if mode == "legacy" {
				baseline = r
				baselineTrace = trace
			}
			if mode == "empty" || mode == "default" {
				equalPrepared104(t, r, baseline)
				equalPrepared104(t, trace, baselineTrace)
			}
			data, e := json.Marshal(trace)
			if e != nil {
				t.Fatal(e)
			}
			h := sha256.Sum256(data)
			samples := []json.RawMessage{}
			for _, call := range trace {
				if call.Kind != "step" {
					continue
				}
				var o Observation
				if e = json.Unmarshal(call.Observation, &o); e != nil {
					t.Fatal(e)
				}
				if len(samples) == 0 || o.Selected.DayBuy.Own5 != 0 && len(samples) == 1 {
					samples = append(samples, call.Observation)
				}
			}
			fills, signals := 0, 0
			for _, b := range r.Books {
				fills += len(b.Fills)
				signals += len(b.Signals)
			}
			rows = append(rows, map[string]any{"session": s, "mode": mode, "result": r, "delivery_sha256": hex.EncodeToString(h[:]), "calls": len(trace), "observation_samples": samples, "source_signals": signals, "source_fills": fills})
		}
	}
	data, e := json.MarshalIndent(map[string]any{"成功": true, "scope": "手製二市場Board/Candle→実Features→完全Observation→実Source adapter。全式生成口の人工接続。実入力IO/旧93実データ一致/自然Source経済影響は未検査。", "cases": rows, "市場/Raw/CSV/Native読取": 0}, "", "  ")
	if e != nil {
		t.Fatal(e)
	}
	if e = os.WriteFile(path, append(data, '\n'), 0644); e != nil {
		t.Fatal(e)
	}
}
