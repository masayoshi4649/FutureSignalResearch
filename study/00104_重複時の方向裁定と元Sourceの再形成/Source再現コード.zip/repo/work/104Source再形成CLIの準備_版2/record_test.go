package main

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	replay "github.com/masayoshi4649/SessionTradeExecuter/minisourcereplay104"
)

// artificialInputs はRootの原板を使わない二市場完全入力を返します。
//
// 引数: night(bool)は場種です。
// 返り値: Session/BoardRow/CandleEvent配列は手製の正価格/数量と確定足です。
func artificialInputs(night bool) (replay.Session, []replay.BoardRow, []replay.CandleEvent) {
	s := replay.Session{ID: "記録人工_Day", Kind: "Day", Start: 1000, End: 5000, ForceClose: 4400}
	if night {
		s = replay.Session{ID: "記録人工_Night", Kind: "Night", Start: 1000, End: 12000, ForceClose: 11400, USOpen: 6000, ExtraAt: 7800}
	}
	boards := []replay.BoardRow{}
	cs := []replay.CandleEvent{}
	for _, ref := range []string{"TOPIX", "NK225"} {
		base, tick := 1000.0, .5
		if ref == "NK225" {
			base, tick = 50000, 10
		}
		for i := 0; i < 3; i++ {
			at := s.Start + float64(i*300)
			cs = append(cs, replay.CandleEvent{Reference: ref, Interval: 300, At: at + 360, Candle: strategy.Candle{Time: at, Closed: true, Open: base, High: base + 2*tick, Low: base - 2*tick, Close: base + tick}})
		}
		clocks := []float64{2000, 2005, 2010}
		if night {
			clocks = append(clocks, 5099, 5100, 5101, 6900, 6901)
		}
		clocks = append(clocks, s.ForceClose+1)
		for i, at := range clocks {
			mid := base + float64(i)*tick
			boards = append(boards, replay.BoardRow{Board: strategy.Board{Reference: ref, Time: at, Received: at, Last: mid, Bid: mid - tick/2, Ask: mid + tick/2, BidQuantity: 100, AskQuantity: 80}, Line: int64(20 + i)})
		}
	}
	return s, boards, cs
}

// Test104RecordedSource は実adapter全Step/Forceが同じ保存型で逐次記録されることを確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。Source新規/約定0の人工接続であり経済効果ではありません。
func Test104RecordedSource(t *testing.T) {
	for _, night := range []bool{false, true} {
		s, boards, cs := artificialInputs(night)
		baseline, e := replay.ReplayPrepared(s, boards, cs, nil)
		if e != nil {
			t.Fatal(e)
		}
		expected, e := json.Marshal(baseline)
		if e != nil {
			t.Fatal(e)
		}
		for _, mode := range []string{"legacy", "empty", "default", "symmetric"} {
			var stream bytes.Buffer
			enc := json.NewEncoder(&stream)
			saved := []SourceRecord{}
			rec := &Recorder{Sink: func(v SourceRecord) error { saved = append(saved, v); return enc.Encode(v) }}
			factory, e := rec.Factory(mode)
			if e != nil {
				t.Fatal(e)
			}
			actual, e := replay.ReplayPrepared(s, boards, cs, factory)
			if e != nil {
				t.Fatal(e)
			}
			if mode != "symmetric" {
				if e = Compare93(actual, expected); e != nil {
					t.Fatal(e)
				}
			}
			if rec.Counts.Calls != len(saved) || rec.Counts.Steps == 0 || rec.Counts.Forces == 0 {
				t.Fatal("全通知の欠落")
			}
			last := map[string]int64{}
			d := json.NewDecoder(&stream)
			for i, v := range saved {
				var read SourceRecord
				if e = d.Decode(&read); e != nil {
					t.Fatal(e)
				}
				x, _ := json.Marshal(v)
				y, _ := json.Marshal(read)
				if !bytes.Equal(x, y) {
					t.Fatal("保存再読の全field差")
				}
				if v.Ordinal != i+1 {
					t.Fatal("配送順")
				}
				key := v.Product + "/" + v.Method
				if v.Kind == "quote" {
					q := v.Scalar
					if q == nil || q.Time != v.Delta.At || q.SourceLine != v.Delta.SourceLine || !validSHA(v.ObservationSHA) {
						t.Fatal("完全Observation由来Scalar/Delta")
					}
					if q.ATR != 40 {
						t.Fatal("ATR源未配送")
					}
					last[key] = q.SourceLine
				} else {
					if v.Scalar != nil || v.Delta.SourceLine != last[key] || v.Delta.Origin != "timer" {
						t.Fatal("Forceへ気配retime又は別物理行")
					}
				}
			}
			for _, b := range actual.Books {
				if !b.Complete || len(b.Signals) != 0 || len(b.Fills) != 0 {
					t.Fatal("人工scope")
				}
			}
		}
	}
}

// Test104RecordCodec は全通知型のTargets/Closes/取消/配賦を捨てない保存境界だけを確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。手製codec値をSource形成成功へ加算しません。
func Test104RecordCodec(t *testing.T) {
	v := SourceRecord{Kind: "quote", Delta: native.StepResult{Signals: []native.SignalRecord{{Signal: native.Signal{ID: "close", Targets: []strategy.LotTarget{{ID: "hold", Quantity: 1}}}}}, Closes: []native.CloseNotice{{ID: "notice", ReferenceID: "hold", Before: 3, Quantity: 1}}, Cancellations: []native.Cancellation{{SignalID: "cancel"}}, Fills: []native.FillRecord{{Allocations: []native.CloseAllocation{{HoldID: "hold", Quantity: 1, EntryFeeYen: 38.5, ExitFeeYen: 38.5}}}}}}
	raw, e := json.Marshal(v)
	if e != nil {
		t.Fatal(e)
	}
	var read SourceRecord
	if e = json.Unmarshal(raw, &read); e != nil {
		t.Fatal(e)
	}
	again, _ := json.Marshal(read)
	if !bytes.Equal(raw, again) {
		t.Fatal("元全通知型の欠落")
	}
}

// Test104RootGuard はRoot未固定の入力を原板読込前に拒否します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。市場CLI又は実Sourceは実行しません。
func Test104RootGuard(t *testing.T) {
	root := t.TempDir()
	a := Arguments{Condition: filepath.Join(root, "未作成.json"), Stage: "first2", Out: filepath.Join(root, "出力")}
	if _, _, _, _, e := Preflight(a, root, "fake.exe"); e == nil || !strings.Contains(e.Error(), "Root条件SHA") {
		t.Fatal("未固定SHAが入力を読んだ", e)
	}
	c := Condition{Version: 1, Trial: 104, Fixed: false, Scenes: make([]SceneRef, 54), Modes: []string{"legacy", "default", "symmetric"}, Code: map[string]string{"main.go": strings.Repeat("0", 64)}, GeneratorStop: FileRef{"存在しない生成口停止", GeneratorStopSHA}, ReplayStop: FileRef{"存在しない接続停止", ReplayStopSHA}, Manifest: FileRef{"原板へ進ませない台帳", strings.Repeat("0", 64)}}
	for _, mode := range []string{"未固定", "別trial", "別停止", "主mode不足"} {
		x := c
		switch mode {
		case "別trial":
			x.Trial = 103
			x.Fixed = true
		case "別停止":
			x.Fixed = true
			x.GeneratorStop.SHA = strings.Repeat("0", 64)
		case "主mode不足":
			x.Fixed = true
			x.Modes = x.Modes[:2]
		}
		a.Condition = filepath.Join(root, mode+".json")
		if e := writeNew(a.Condition, x); e != nil {
			t.Fatal(e)
		}
		a.ConditionSHA, _ = digest(a.Condition)
		if _, _, _, _, e := Preflight(a, root, "fake.exe"); e == nil || !strings.Contains(e.Error(), "Rootの全条件") {
			t.Fatal("未固定metadata通過", mode, e)
		}
	}
	if _, e := os.Stat(a.Out); !os.IsNotExist(e) {
		t.Fatal("拒否後に出力が生じた")
	}
}

// Test104BaselineReject は同体比較で旧field/数量/半円/余剰fieldを無視しないことを確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。市場の旧Native本文は使いません。
func Test104BaselineReject(t *testing.T) {
	s, b, c := artificialInputs(false)
	r, e := replay.ReplayPrepared(s, b, c, nil)
	if e != nil {
		t.Fatal(e)
	}
	raw, _ := json.Marshal(r)
	for _, mode := range []string{"同体", "旧余剰field", "費用", "欠落book"} {
		var value map[string]any
		if e = json.Unmarshal(raw, &value); e != nil {
			t.Fatal(e)
		}
		books := value["books"].(map[string]any)
		switch mode {
		case "旧余剰field":
			value["追加"] = "未知でも捨てない"
		case "費用":
			for _, v := range books {
				v.(map[string]any)["totals"].(map[string]any)["fee_yen"] = .5
				break
			}
		case "欠落book":
			for k := range books {
				delete(books, k)
				break
			}
		}
		bad, _ := json.Marshal(value)
		e := Compare93(r, bad)
		if mode == "同体" && e != nil || mode != "同体" && e == nil {
			t.Fatal(mode, e)
		}
	}
}
