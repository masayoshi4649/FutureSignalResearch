package main

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"

	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
	replay "github.com/masayoshi4649/SessionTradeExecuter/minisourcereplay104"
)

// SourceRecord は完全Observation経路からの全StepResultを一配送ずつ保存します。
type SourceRecord struct {
	Ordinal        int               `json:"ordinal"`
	Session        string            `json:"session"`
	Kind           string            `json:"kind"`
	Method         string            `json:"method"`
	Product        string            `json:"product"`
	Scalar         *tape.ScalarQuote `json:"scalar,omitempty"`
	ObservationSHA string            `json:"observation_sha256,omitempty"`
	Delta          native.StepResult `json:"delta"`
	Error          string            `json:"error,omitempty"`
}
type RecordCounts struct {
	Calls   int `json:"calls"`
	Steps   int `json:"steps"`
	Forces  int `json:"forces"`
	Signals int `json:"signals"`
	Fills   int `json:"fills"`
	Closes  int `json:"closes"`
	Cancels int `json:"cancellations"`
}
type SourceSink func(SourceRecord) error
type Recorder struct {
	Sink   SourceSink
	Counts RecordCounts
}
type recordedSource struct {
	inner                    replay.SourceAdapter
	owner                    *Recorder
	session, method, product string
}

// Factory は生成時だけ元口へ差し込み、実adapterの通知を変更しません。
//
// 引数: mode(string)はlegacy/empty/default/symmetricです。
// 返り値: replay.AdapterFactory/errorは停止生成口又は未知modeです。
func (r *Recorder) Factory(mode string) (replay.AdapterFactory, error) {
	if r == nil || r.Sink == nil {
		return nil, fmt.Errorf("全通知の保存先が必要です")
	}
	var base replay.AdapterFactory
	var e error
	if mode != "legacy" {
		m := replay.RuleMode(mode)
		if mode == "empty" {
			m = replay.RuleEmpty
		}
		base, e = replay.RuleFactory(m)
		if e != nil {
			return nil, e
		}
	}
	return func(method string, s replay.Session, c native.ProductConfig) (replay.SourceAdapter, error) {
		var b replay.SourceAdapter
		var e error
		if base == nil {
			b, e = native.NewAdapter(method, s, c)
		} else {
			b, e = base(method, s, c)
		}
		if e != nil {
			return nil, e
		}
		return &recordedSource{b, r, s.ID, method, c.Product}, nil
	}, nil
}

// emit は空通知も含め一配送を連番付きで保存します。
//
// 引数: v(SourceRecord)は元公開型の全値です。
// 返り値: errorは保存失敗です。会計更新後の失敗を成功へ補いません。
func (r *Recorder) emit(v SourceRecord) error {
	r.Counts.Calls++
	v.Ordinal = r.Counts.Calls
	if v.Kind == "quote" {
		r.Counts.Steps++
	} else {
		r.Counts.Forces++
	}
	r.Counts.Signals += len(v.Delta.Signals)
	r.Counts.Fills += len(v.Delta.Fills)
	r.Counts.Closes += len(v.Delta.Closes)
	r.Counts.Cancels += len(v.Delta.Cancellations)
	return r.Sink(v)
}

// Step は完全Observationを実Sourceへ渡し、新Scalar11と元Deltaを保存します。
//
// 引数: o(replay.Observation)、line(int64)は旧Featuresからの全値と物理行です。
// 返り値: native.StepResult/errorは元Sourceの全通知又は保存失敗です。
func (x *recordedSource) Step(o replay.Observation, line int64) (native.StepResult, error) {
	data, e := json.Marshal(o)
	if e != nil {
		return native.StepResult{}, e
	}
	h := sha256.Sum256(data)
	scalar, e := tape.ProjectQuote(o, line)
	if e != nil {
		return native.StepResult{}, e
	}
	d, e := x.inner.Step(o, line)
	v := SourceRecord{Session: x.session, Kind: "quote", Method: x.method, Product: x.product, Scalar: &scalar, ObservationSHA: hex.EncodeToString(h[:]), Delta: d}
	if e != nil {
		v.Error = e.Error()
	}
	if save := x.owner.emit(v); save != nil {
		return d, save
	}
	return d, e
}

// Force は元の時計/直前SourceLineを保存し、価格を作り直しません。
//
// 引数: at(float64)は旧全board駆動timerです。
// 返り値: native.StepResult/errorは元Sourceの全通知又は保存失敗です。
func (x *recordedSource) Force(at float64) (native.StepResult, error) {
	d, e := x.inner.Force(at)
	v := SourceRecord{Session: x.session, Kind: "force", Method: x.method, Product: x.product, Delta: d}
	if e != nil {
		v.Error = e.Error()
	}
	if save := x.owner.emit(v); save != nil {
		return d, save
	}
	return d, e
}

// Snapshot は元Sourceの公開保存値をそのまま返します。
//
// 引数: ありません。
// 返り値: native.Ledgerは元の深いcopyです。
func (x *recordedSource) Snapshot() native.Ledger { return x.inner.Snapshot() }

// Finish は元Sourceの完結検査をそのまま返します。
//
// 引数: ありません。
// 返り値: native.Ledger/errorは元の最終結果又は残玉/予約失敗です。
func (x *recordedSource) Finish() (native.Ledger, error) { return x.inner.Finish() }

// Compare93 は旧場別結果を未知fieldを捨てず全JSON構造で比較します。
//
// 引数: actual(replay.ReplayResult)、expected([]byte)は新制御結果とRoot固定旧93本文です。
// 返り値: errorはLedgerを含む全保存構造の差です。Symの成功へ代用しません。
func Compare93(actual replay.ReplayResult, expected []byte) error {
	data, e := json.Marshal(actual)
	if e != nil {
		return e
	}
	if !json.Valid(expected) {
		return fmt.Errorf("旧93 JSON破損")
	}
	decode := func(b []byte) (any, error) {
		d := json.NewDecoder(bytes.NewReader(b))
		d.UseNumber()
		var v any
		e := d.Decode(&v)
		return v, e
	}
	a, e := decode(data)
	if e != nil {
		return e
	}
	b, e := decode(expected)
	if e != nil {
		return e
	}
	ax, _ := json.Marshal(a)
	bx, _ := json.Marshal(b)
	if !bytes.Equal(ax, bx) {
		return fmt.Errorf("旧93の全JSON構造が不一致です")
	}
	return nil
}
