"""市場入力を開かず、版2の差分と実施済み人工・vet・buildの停止指紋を保存する。"""

from __future__ import annotations

import difflib
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[1]
OLD = ROOT / "work/104Source再形成CLIの準備"
PEER = ROOT / "work/104Sourceのpeer確認/確認.json"


def sha(path: Path) -> str:
    """
    機能: 許可済みコード又は小metadata一件の指紋を返す。
    引数: path(Path)はコード・停止・新人工の対象。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_new(path: Path, value: dict) -> None:
    """
    機能: 新規metadataを上書きせず保存する。
    引数: path(Path)は新規先、value(dict)は公開する値。
    返り値: None。
    """
    with path.open("x", encoding="utf-8", newline="\n") as out:
        json.dump(value, out, ensure_ascii=False, indent=2)
        out.write("\n")


def main() -> None:
    """
    機能: 版1不変・限定差分と実施済み検査を新停止へ結ぶ。
    引数: なし。
    返り値: None。市場・原板・旧Native・追加Goは実行しない。
    """
    peer = json.loads(PEER.read_text(encoding="utf-8"))
    original = peer["読み取ったファイルSHA256"]
    assert all(sha(ROOT / p) == h for p, h in original.items())
    unchanged = ["record.go", "record_test.go", "go.mod", "go.sum"]
    assert all((OLD / n).read_bytes() == (HERE / n).read_bytes() for n in unchanged)
    old_stop = OLD / "停止.json"
    assert sha(old_stop) == "a424baabcf21159bc83e09bf705f1d4e365b4bee7e16a0ca60de7b0523633532"

    # ----------------------------------------
    # 差分と由来だけを新workへ固定し、旧停止は変更しない。
    patch = ""
    for name in ["main.go", "README.md", "guard_test.go"]:
        before = (OLD / name).read_text(encoding="utf-8").splitlines(True) if (OLD / name).exists() else []
        after = (HERE / name).read_text(encoding="utf-8").splitlines(True)
        patch += "".join(difflib.unified_diff(before, after, fromfile="版1/" + name, tofile="版2/" + name))
    patch_path = HERE / "版1との差分.patch"
    with patch_path.open("x", encoding="utf-8", newline="\n") as out:
        out.write(patch)
    old_fingerprint = {
        "元停止": {"path": old_stop.relative_to(ROOT).as_posix(), "SHA256": sha(old_stop)},
        "peer": {"path": PEER.relative_to(ROOT).as_posix(), "SHA256": sha(PEER)},
        "版1所有SHA256": json.loads(old_stop.read_text(encoding="utf-8"))["所有SHA256"],
        "元指紋の由来": "元の元指紋.jsonは版1停止の所有集合に保存されたまま。版2はこの新由来記録へ更新。",
    }
    (HERE / "元指紋.json").write_text(json.dumps(old_fingerprint, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    difference = {
        "成功": True,
        "元停止SHA256": sha(old_stop),
        "peerSHA256": sha(PEER),
        "変更": ["main.goの固定metadata guardと出力hash error伝播", "guard_test.go追加", "READMEと由来metadata更新"],
        "本文同体": unchanged,
        "停止依存本文同体": True,
        "Source/金融/配送/旧93全比較の変更": 0,
        "差分SHA256": sha(patch_path),
        "市場/Raw/CSV/旧Native読取": 0,
    }
    write_new(HERE / "由来と差分.json", difference)
    artificial = {
        "成功": True,
        "test/vet/build": {"test": 0, "vet": 0, "build": 0},
        "検査観測": "実コマンドのツール終了値とGo test -json出力を観測。生stdout全件の別ファイル保存はしていない。",
        "top成功": 7,
        "全pass名数": 29,
        "追加正常": ["当CLI4実path＋2停止所有集合", "正確2ID×3mode6件", "出力hash正常"],
        "追加拒否": {"code/停止所有": 10, "first2集合/成果参照/旧一致": 12, "出力hash取得失敗": 1},
        "旧人工再用": ["実Features/Source全配送・自然新規Fill0", "手製非0配賦等のcodec", "未固定Root拒否", "旧93全構造の破損拒否"],
        "実市場first2/full54": 0,
        "限界": ["自然非0Source未検証", "旧93実データ一致未検証", "新Tape/金融103未接続", "全Go依存探索はRoot固定の責務"],
    }
    write_new(HERE / "検査/人工確認.json", artificial)

    # ----------------------------------------
    # 同一実行物と所有集合を新停止へ結ぶ。
    owned_names = ["main.go", "record.go", "record_test.go", "guard_test.go", "go.mod", "go.sum", "README.md", "元指紋.json", "由来と差分.json", "版1との差分.patch", "検査/停止を記録する.py"]
    owned = {(HERE / n).relative_to(ROOT).as_posix(): sha(HERE / n) for n in owned_names}
    executable = HERE / "検査/Source準備.exe"
    assert sha(executable) == "6b5f897e62f91a94fbe2e6b6a82e7d1855fe741f8a452753245c62672e1e5033"
    assert all(sha(ROOT / p) == h for p, h in original.items())
    stop = {
        "成功": True,
        "未固定104候補": True,
        "module": "github.com/masayoshi4649/SessionTradeExecuter/minisourcecli104",
        "所有SHA256": owned,
        "元停止": old_fingerprint["元停止"],
        "参照停止": {
            "生成口": {"path": "work/104対称Sourceの生成口準備/停止.json", "SHA256": "e5192a02340de79e41c8a38643e883375682bb8f4f9fe46f5c0b91ab64d3f1cc"},
            "再生接続": {"path": "work/104Source再生の接続準備/停止.json", "SHA256": "2104b6609e160cf86133239554d7338d6c5ccc3446e434ad7a10751f5b39ec39"},
        },
        "exe": {"path": executable.relative_to(ROOT).as_posix(), "SHA256": sha(executable)},
        "人工確認": {"path": (HERE / "検査/人工確認.json").relative_to(ROOT).as_posix(), "SHA256": sha(HERE / "検査/人工確認.json"), **artificial},
        "peerSHA256": sha(PEER),
        "元停止/所有/読取対象前後不変": True,
        "Source/金融/配送/既存全構造比較変更": 0,
        "Root条件": "未作成・未固定のまま市場拒否",
        "市場/Raw/CSV/旧Native本文/103正式編集": 0,
    }
    write_new(HERE / "停止.json", stop)
    print(json.dumps({"停止SHA256": sha(HERE / "停止.json"), "exeSHA256": sha(executable)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
