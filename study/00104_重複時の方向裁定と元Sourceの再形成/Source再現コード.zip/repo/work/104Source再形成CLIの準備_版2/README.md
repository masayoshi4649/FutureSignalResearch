# 104 Source再形成CLIの準備・版2（未固定・市場実行禁止）

module `github.com/masayoshi4649/SessionTradeExecuter/minisourcecli104`。停止e519生成口と2104再生接続を直接importし、旧93のprivate IOやSource会計をこのCLIへ再複写していない。正式104は未採番、Rootが103結果から計画・許可入力・コード・条件・実行物を固定するまで実原板/CSV/旧Native本文/Source市場再形成を実行しない。ここに市場の条件JSONは作っていない。

版1停止a424baabは不変で保存し、[非市場peer](../104Sourceのpeer確認/所見.md)の3点だけを訂正した別版である。[版1との差分](版1との差分.patch)と[由来と差分](由来と差分.json)を参照。Source、金融、Observation/StepResult/Force配送、旧93全構造比較、商品規格は変更していない。

## 最小構成

`Recorder.Factory(mode)` が公開factoryを包み、元SourceAdapter.Step/Forceを実行した直後の全 `native.StepResult` を逐次保存する。Signal/Fill/Cancellation/Closes/Targets/Before/配賦は元の公開型をそのまま保持し、空通知も捨てない。Snapshot/Finishは元へ直通。Sourceや偽NativeBatchを自作しない。

各modeは別の新規adapterで、`legacy`=旧93constructor、`default`=停止生成口へ既定完全式map、`symmetric`=全式mapのrange_sideだけ重複待機へ変更。API人工用 `empty` も生成できるが市場条件のmode集合はlegacy/default/symmetricに固定する。元タイマー/公開足/全Observation/同時計順/mini-microの規格は2104のrunnerが維持する。

quote recordは**今の完全Observation**から新たにProjectQuoteしたScalar11と全ObservationのSHA、Force recordは元Deltaの時刻/直前SourceLineを持つ。旧Scalarを完全ObservationとしてSourceへ渡す処理はない。全Observationの巨大な全件dumpは保存せず、元Sourceへ渡した証拠をSHAで残す。

## 出力

1場×modeごとに次を新規保存する。

- `{session}_{mode}.deltas.jsonl.gz`：`SourceRecord{ordinal,session,kind,method,product,scalar?,observation_sha256?,delta,error?}`。micro/miniとD/P/Uの元callback順で全配送を残す。単一ファイル内ordinalは1開始。
- `{session}_{mode}.result.json`：旧93 `ReplayResult` のsession/quality/source_rows/books全値。全Ledgerを保つ。
- `完了.json`：条件SHA/stage/前後指紋/各2成果SHA/全通知counts/旧対照成否。失敗時もsuccess=falseを残し、Source未完結や旧対照差を成功へ補完しない。

legacy/defaultはRootが明示固定した旧93場別JSONを**全JSON構造（全Ledgerを含む）**で比較する。未知field/配列nil空/数量/半円等を落とさない。symはdistinct結果で、旧一致trueを代用しない。mini/microの量・点価・外費用を混同しない。ここで得る旧93のNative出力は元判断/元商品会計であり、金融103を適用した成績ではない。

## Rootが将来固定する条件schema

`Condition` のexact JSONはmain.goを正本とする。

- `version:1, trial:104, fixed:true`。未固定はmetadataの段階で拒否。
- `manifest80:{path,sha256}`：固定80入力台帳。既使用9/21〜10/27の54IDを抽出し全54と一致。元の6入力とSource43検査を再生接続へ維持。
- `generator_stop:{path,sha256}` はe5192a02340de79e41c8a38643e883375682bb8f4f9fe46f5c0b91ab64d3f1cc、`replay_stop` は2104b6609e160cf86133239554d7338d6c5ccc3446e434ad7a10751f5b39ec39。
- `binary:{path,sha256}` は実行中exeのpath/SHA。`code_sha256` はrepo相対又は絶対path→SHAの固定依存集合（このCLI/停止依存module/旧93/Source43/Go mod等をRootがclosureとして固定）。`runtime.Caller`で当CLIのmain.go実pathを確認し、同じdirectoryのmain.go/record.go/go.mod/go.sumの正規pathを必須にする。別moduleの同名ファイルでは代用できない。生成口/再生接続の停止JSONが宣言する**所有SHA256集合全体（README/由来等も含む）**を同じpath/SHAでcodeへ包含する。停止JSON自体は上記FileRefの固定SHAで検査する。これは停止所有集合の検査であり、CLIが独自にgo list依存閉包を探索するものではない。RootがSource43等の残る閉包を固定する責務は維持する。
- `modes:["legacy","default","symmetric"]`。
- `scenes:[{session,baseline93:{path,sha256}}×54]`：上記54IDのDay/Night順、旧93各場の固定対照本文。先頭2も同じ条件を使う。

FileRefは条件dir基準、code keysだけrepo基準。台帳内source_root/純戦略repoが相対なら台帳dir基準へ解決し、原板の各InputFile.Pathはsource_root基準。Root条件全体・code・binary・停止参照を先に検査し、その後だけ対象stageの原板/CSV/旧93対照を前hashする。固定台帳の6入力Size/SHAは旧Replayが実読込時にも検査する。終了後も全前指紋を再hashする。

full54の前提first2は2026-09-21のDay/Night×legacy/default/symmetricを各1件、計6件とする。欠落・余分・重複・別ID/mode・空成果path・不正SHA・Error残留・旧一致flag誤用を拒否する。legacy/defaultだけOld93FullMatch=true、symmetricはfalseを要求する。成果2種類の実ファイルSHAと同条件/code/binary/停止の前後参照も従来どおり検査する。records出力hashが読めなければ成功完了へ補完しない。Preflight又は新規directory作成前に拒否した場合はreceiptを生成しない。

```powershell
Set-Location '<repo>'
& 'work/104Source再形成CLIの準備_版2/検査/Source準備.exe' `
  --condition '<Rootが市場前固定した104条件>' --condition-sha '<そのSHA>' `
  --stage first2 --out '<存在しない新規先>'
# 同じ条件/code/binary/台帳・成功した全6case/前後不変が必要。
& 'work/104Source再形成CLIの準備_版2/検査/Source準備.exe' `
  --condition '<同条件>' --condition-sha '<同SHA>' --stage full54 `
  --first2 '<先頭2/完了.json>' --first2-sha '<そのSHA>' --out '<別の新規先>'
```

逐次1場×3modeを優先し、worker/大量キャッシュ/巨大fullObservation dumpは実装していない。Direct93は板配列とLedgerを保持するためメモリ測定はRoot固定後の先頭2で必要。first2/full54の実実行はまだ0。

## 既存97Tape/金融103への境界

mini記録を選び、同じ**quoteのFeaturesIndex/physicalLine/Scalar11全値**又はForce時計のgroupへ、元active method順にNativeBatch{Method,Delta}を戻せる。P/Uが同時activeの時は両方の空通知も残す。Closes.Before/TargetsをLedgerから再推測しなくても記録全型に存在し、Force.SourceLineは各手法の直前受理行である。既存RestoreBatchesはこの時計/位相/lineを厳格に照合する。

ただし旧93のSource runner自体には**B5Q gridがない**。新Source記録だけから97Tapeの全gridや全board駆動順を推測しない。旧固定の全board grid/Force/quote配列と、今回fresh Scalar全値/物理行/同時計優先を別途照合し、Sourceを新Deltaへ差し替えた**新Tape**を作る工程が不足している。Atだけでまとめると同秒異行やForce→grid→quoteを崩す恐れがある。既存Tapeをそのまま新Source成功と呼ばない。

金融103はGateなしP0/LD05/LD10/S0でScalar11と元公開Deltaを読むため、上の新Tape結合後には同じ保護式を適用できる。今回その工程/金融103/旧103正式結果には触れていない。将来技法gateを足す場合は対応Contextを別形成・版固定する必要があり、Scalarから補完できない。Source形成と金融運転は別の固定/検査段階。

## 非市場人工と限界

```powershell
Push-Location 'work/104Source再形成CLIの準備_版2'
go test -json -count=1 ./...
go vet ./...
go build -o 検査/Source準備.exe .
Pop-Location
```

手製Board/Candle→実Features→実SourceでDay/Night×legacy/empty/default/symの全Step/Forceを保存再読し、Scalar/元Delta時計/Force直前line、全件連番、旧結果の全構造を確認。Source新規/Fillは0の人工波であり、自然非0発動の検証ではない。Targets/Closes/配賦/取消のnonzero値はcodec単体の手製型だけで検査し、Source形成成功へ加算していない。Root未固定/別trial/別停止/不完全modeを原板前に拒否する境界を確認した。版2では正規code/停止所有集合の正常例と10拒否、正確な6case集合の正常例と12拒否、出力hash成功/失敗の小人工を追加した。実CLIの全54前提連結や旧93実データ一致は未検査。実原板/CSV/市場Native読取・新損益・104正式採番は0。
