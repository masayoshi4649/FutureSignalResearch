package main

import (
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"
)

// coverageFixture は実入力なしの正規path/停止所有集合を返します。
//
// 引数: root(string)は人工repoの根です。
// 返り値: map/string/[]StoppedCodeは固定code・CLI根・二つの停止所有集合です。
func coverageFixture(root string) (map[string]string, string, []StoppedCode) {
	cli := filepath.Join(root, "work", "actual-cli")
	h := strings.Repeat("a", 64)
	code := map[string]string{}
	for _, name := range []string{"main.go", "record.go", "go.mod", "go.sum"} {
		code[filepath.Join(cli, name)] = h
	}
	stops := []StoppedCode{
		{Success: true, Owned: map[string]string{"work/generator/adapter.go": h, "work/generator/README.md": h}},
		{Success: true, Owned: map[string]string{"work/replay/replay.go": h, "work/replay/input.go": h}},
	}
	for _, stop := range stops {
		for name, sha := range stop.Owned {
			code[name] = sha
		}
	}
	return code, cli, stops
}

// Test104CodeCoverage は別basename・停止所有欠落・別SHAを拒否します。
//
// 引数: t(*testing.T)は人工試験器です。
// 返り値: ありません。ファイル読込やSource再形成は行いません。
func Test104CodeCoverage(t *testing.T) {
	root := t.TempDir()
	code, cli, stops := coverageFixture(root)
	if e := validateCodeCoverage(code, root, cli, stops); e != nil {
		t.Fatal(e)
	}
	before := len(code)
	if e := validateCodeCoverage(code, root, cli, stops); e != nil || len(code) != before {
		t.Fatal("包含検査が入力を変更")
	}
	tests := []struct {
		name   string
		change func(map[string]string, string, []StoppedCode)
	}{
		{"別mainのbasename", func(c map[string]string, d string, _ []StoppedCode) {
			delete(c, filepath.Join(d, "main.go"))
			c["work/other/main.go"] = strings.Repeat("a", 64)
		}},
		{"別go.modのbasename", func(c map[string]string, d string, _ []StoppedCode) {
			delete(c, filepath.Join(d, "go.mod"))
			c["work/other/go.mod"] = strings.Repeat("a", 64)
		}},
		{"生成口所有の欠落", func(c map[string]string, _ string, _ []StoppedCode) { delete(c, "work/generator/adapter.go") }},
		{"再生口所有の欠落", func(c map[string]string, _ string, _ []StoppedCode) { delete(c, "work/replay/input.go") }},
		{"停止資料も必須", func(c map[string]string, _ string, _ []StoppedCode) { delete(c, "work/generator/README.md") }},
		{"停止と別SHA", func(c map[string]string, _ string, _ []StoppedCode) {
			c["work/replay/replay.go"] = strings.Repeat("b", 64)
		}},
		{"失敗停止", func(_ map[string]string, _ string, s []StoppedCode) { s[0].Success = false }},
		{"空所有停止", func(_ map[string]string, _ string, s []StoppedCode) { s[0].Owned = map[string]string{} }},
		{"所有SHA破損", func(_ map[string]string, _ string, s []StoppedCode) { s[0].Owned["work/generator/adapter.go"] = "bad" }},
		{"正規path重複", func(c map[string]string, _ string, _ []StoppedCode) {
			c[filepath.Join(root, "work/replay/replay.go")] = strings.Repeat("a", 64)
		}},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			c, d, s := coverageFixture(root)
			test.change(c, d, s)
			if e := validateCodeCoverage(c, root, d, s); e == nil {
				t.Fatal("固定集合の破損を受理")
			}
		})
	}
	dir, e := cliDirectory()
	if e != nil {
		t.Fatal(e)
	}
	wd, e := os.Getwd()
	if e != nil || !strings.EqualFold(filepath.Clean(dir), filepath.Clean(wd)) {
		t.Fatal("runtime.Callerの実CLI根拠が現在moduleと不一致")
	}
}

// first2Fixture は2ID×3modeの正規metadataだけを返します。
//
// 引数: ありません。
// 返り値: []CaseReceiptは非市場の完全6ケースです。実成果の代用ではありません。
func first2Fixture() []CaseReceipt {
	rows := []CaseReceipt{}
	for _, id := range expectedIDs()[:2] {
		for _, mode := range []string{"legacy", "default", "symmetric"} {
			prefix := id + "_" + mode
			rows = append(rows, CaseReceipt{Session: id, Mode: mode, Result: FileRef{prefix + ".result.json", strings.Repeat("a", 64)}, Records: FileRef{prefix + ".deltas.jsonl.gz", strings.Repeat("b", 64)}, Old93FullMatch: mode != "symmetric"})
		}
	}
	return rows
}

// Test104First2Coverage は正確な6ケースと不正参照/旧一致の拒否を確認します。
//
// 引数: t(*testing.T)は人工試験器です。
// 返り値: ありません。実first2/full54を実行しません。
func Test104First2Coverage(t *testing.T) {
	rows := first2Fixture()
	if e := validateFirst2Cases(rows); e != nil || !reflect.DeepEqual(rows, first2Fixture()) {
		t.Fatal("正常集合又は入力不変", e)
	}
	tests := []struct {
		name   string
		change func([]CaseReceipt) []CaseReceipt
	}{
		{"欠落", func(v []CaseReceipt) []CaseReceipt { return v[:5] }},
		{"余分", func(v []CaseReceipt) []CaseReceipt { return append(v, v[0]) }},
		{"同一case重複6件", func(v []CaseReceipt) []CaseReceipt {
			for i := range v {
				v[i] = v[0]
			}
			return v
		}},
		{"別ID", func(v []CaseReceipt) []CaseReceipt { v[0].Session = "2026-09-22_Day"; return v }},
		{"別mode", func(v []CaseReceipt) []CaseReceipt { v[0].Mode = "empty"; return v }},
		{"空result参照", func(v []CaseReceipt) []CaseReceipt { v[0].Result.Path = ""; return v }},
		{"空records参照", func(v []CaseReceipt) []CaseReceipt { v[0].Records.Path = " "; return v }},
		{"空SHA", func(v []CaseReceipt) []CaseReceipt { v[0].Records.SHA = ""; return v }},
		{"不正SHA", func(v []CaseReceipt) []CaseReceipt { v[0].Result.SHA = strings.Repeat("x", 64); return v }},
		{"旧不一致", func(v []CaseReceipt) []CaseReceipt { v[0].Old93FullMatch = false; return v }},
		{"対称へ旧一致流用", func(v []CaseReceipt) []CaseReceipt { v[2].Old93FullMatch = true; return v }},
		{"成功へerror残留", func(v []CaseReceipt) []CaseReceipt { v[0].Error = "失敗"; return v }},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			if e := validateFirst2Cases(test.change(first2Fixture())); e == nil {
				t.Fatal("first2の破損を受理")
			}
		})
	}
}

// Test104OutputFingerprint は出力hash取得失敗をerrorとして保持します。
//
// 引数: t(*testing.T)は人工試験器です。
// 返り値: ありません。存在しない人工pathだけを使い、実成果を変更しません。
func Test104OutputFingerprint(t *testing.T) {
	p := filepath.Join(t.TempDir(), "missing.jsonl.gz")
	ref, e := fingerprintOutput(p)
	if e == nil || ref.Path != p || ref.SHA != "" {
		t.Fatal("出力hash失敗を成功へ補完")
	}
	p = filepath.Join(t.TempDir(), "output.jsonl.gz")
	if e := os.WriteFile(p, []byte("人工"), 0600); e != nil {
		t.Fatal(e)
	}
	ref, e = fingerprintOutput(p)
	if e != nil || ref.Path != p || !validSHA(ref.SHA) {
		t.Fatal("正常出力hash", e)
	}
}
