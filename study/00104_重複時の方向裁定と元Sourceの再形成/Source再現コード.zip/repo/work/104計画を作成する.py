"""103を変更せず、104の事前計画と全手法表を新規作成する。"""

from pathlib import Path
import re


def main() -> None:
    """
    機能: 重複方向の待機裁定を単一変更として104を採番する。
    引数: なし。既存最大番号103と版5の継承を確認する。
    返り値: None。新104の計画・設定表・実行前コピーだけを作る。
    """
    root = Path(__file__).resolve().parent.parent
    study_root = root / "study"
    numbers = [int(p.name[:5]) for p in study_root.iterdir() if p.is_dir() and re.match(r"^\d{5}_", p.name)]
    assert max(numbers) in (103, 104)
    target = study_root / "00104_重複時の方向裁定と元Sourceの再形成"
    if target.exists():
        assert max(numbers) == 104 and {p.name for p in target.iterdir()} == {"README.md"}
    else:
        assert max(numbers) == 103
        target.mkdir()
    plan = """# 00104：重複時の方向裁定と元Sourceの再形成

2026-11-09採番。市場実行前の仮説。新しいSource・損益・参加率は未検証。[103](../00103_元の多玉と数量を保つ一定利益後の追尾/README.md)の黒字を新条件の成績として転記しない。

## 仮説と単一変更

元三手法D164_15/P164_06/U165_03には、EMA・ATR・価格帯・短秒進行・二市場と板数量の支持・初回/追加/親の履歴がある。これを維持し、共有D07の範囲逆張り方向式で買い・売り両方が成立したときだけ待機にする。狭い帯の両端条件が同時成立しても、買いを先に評価したという理由で方向を選ばない。

`efficiency <= 0.3` の領域で、買い候補Lは `mid <= low + 0.1*risk`、売り候補Hは `mid >= high - 0.1*risk`。従来はLなら買い、そうでなければHなら売り。新式はLとHが等しければ0（両方真/両方偽）、Lだけ真なら+1、Hだけ真なら−1。方向効率・境界係数・risk尺度・準備/解除/返済等の他式は変えない。

両側に同じ価格条件が成立する領域は、方向を選ぶ情報が不足しているという解釈を置く。これは設計上の仮説であり、実参加者の心理を観測した証明ではない。上位トレンドや勢いで重複時に方向を選ぶ案は別仮説とし、今回へ追加しない。任意の価格反射でbp率等まで完全鏡像になるという主張とも区別する。

## 段階A：自然Sourceを再形成する

既使用2026-09-21〜10-27の54セッション、固定80の二市場原板と確定1/5分足6入力を共用参照する。旧Scalarから欠けた特徴を補わず、元93の入力検査→実Features→完全Observation→実Sourceを通す。原板を正式試行へ複製しない。

1. legacy：元93生成口をそのまま使用。
2. default：新しい全式override生成口へ既定の完全mapを渡す。旧93との生成口の同値確認。
3. symmetric：完全mapの `addon.entry.range_side` 一式だけを上記へ変更。

legacy/defaultは固定旧93の場別JSONを全構造で比較する。全Ledger/数量/費用/予約/配列nil空/品質/SourceRowsを落とさず、除外0を条件とする。先頭2場で自然な新規・Fillの非0を確認し、同じ条件・コード・実行物で全54場へ進む。差が出たら新成績を採用へ進めず、差の発生点を確認する。元資料は書き換えない。

miniとmicroの両方を元の商品条件のまま動かすが、microは元規格の照合対照であり、ユーザーの新しい運用候補はmini。Aのminiは元MiniConfigの片道5pt仮定費用を含む連続Source会計である。Aの粗額/純額を、Bの5分判断・LD10適用後の成績と混ぜない。

各Step/Forceの公開Deltaを空通知も含め逐次保存し、Targets/Closes.Before/所有ID/配賦を失わない。完全Observationそのものを全件複製せず、fresh Scalar11と全ObservationのSHAを記録する。同時計TOPIX/NK、公開足、Force、P終了後U開始の元の順を維持する。価格時計と受信時計は区別する。

## 段階B：同じ一定利益後保護へ接続する

Aの結果を見て閾値を選び直さず、legacyとsymmetric各々へ103と同じB5Q＋LD10を適用する。defaultは生成口同値の照合用で、同値成立後の金融結果を重複採用しない。Source変更の全体効果には新規・数量・返済の自然な変化も含む。同実入口の退出差と片側だけに成立した実取引は別記する。

新しいTapeは、Aで再生成したminiの全Deltaを、元TapeのQuote Scalar11全値・FeaturesIndex・物理行・active method順へ厳密に結ぶ。Forceは元の時計と各method直前SourceLine、gridは既存の全board由来の列を維持する。時刻Atだけで結合しない。元Sourceを形成しない旧Scalarを完全Observationと偽らない。legacy/defaultは変換後Tapeと旧Tapeの通知・順序、103金融の全時点/最終会計の同値を確認してから新Sourceの経済効果を判定する。

結合器・B金融実行物は別途コード/入力を実行前に固定する。現在は未完成・未実行であり、A成功をB成功としない。結合不能・通知欠落・別位相なら補完せず停止し、保存データで原因を調べる。

## Bの時計・保護・費用は103と同じ

- 日経mini、買い/売りそれぞれ上限10枚。元の可変数量・多建玉・比例返済を保つ。
- 新規は初回通知をstrict次5分の一枠だけ取得するB5Q。開始30分は見送り。末尾30分を新たに除外しない。元Forceはデイ15:35、ナイト翌05:50。
- 主判断はデイ09:15〜15:30、ナイト17:30〜翌05:45、54場6,048枠。元の米国開始前後15分ずつの静観162枠、個別手法締切も分母へ残す。開始/末尾30分を除く5,832枠は観測副表であり別運転ではない。
- 参加は当枠受理して同じ[t,t+300)に実取得した枠と、grid時点で実保有する枠の和集合。全体25%以上を最低、50%以上を目標とし、日夜別も明示。受理だけ/後枠Fill/欠測/判定不能は別記する。
- 現在残枚数1枚当たりの費用後含み益u円が `100*max(10,ATRLock.Value)` 以上なら必ず追加全玉追尾を起動。取得時または初回既知の元5分ATR12の未丸めValueを固定する。未知ATRは保留し、元Source損失管理とForceは維持。
- 起動後は最低名目建値を保護し、固定幅 `5*ceil(2*Value/5)` で追尾し不利に緩めない。保護は定時外も連続。今回は新しい収束可変幅を加えず、Source裁定の変更と分ける。
- 点価100円/pt、税込手数料38.5円/枚片道。追加滑りC0/仮定C5pt片道、strict次正常気配/D1追加1価格秒を各Sourceで比較する。spreadはBBO粗額に含み二重控除しない。実測遅延やmini固有板の実約定とは呼ばない。

## 事前に固定する比較と評価

Aは3mode×54場。Dayはmini/micro各D、Nightはmini/micro各P/Uの旧規格で計486Source会計。Bは旧/対称Source×4費用遅延で8設定・54場432会計を予定し、金融実行前の別固定で正確なKeyと入出力を定める。

費用後実現純額、全正額/負額、PF、保存点連結時価DD、取引/枚数、u正益後と保護起動後の最終赤字を別分母で比較。日夜・開始日・売買方向・参加率・最終残予約0・品質を記録する。未参加/退出後の仮想利益、機会損失、MFE回収率、元手未指定ROIは算出しない。

先読み・約定・所有・費用・時計の検査を維持する。従来70%・125/250の合格判定は最新指示に従い一旦適用しない。黒字だけで達成とはせず、未知期間・費用・参加・保護・売買条件の残る例外を確認する。この54場は探索で既使用であり、未見期間と呼ばない。

## 保存と再現

[設定と結果](設定と結果.md)に版5の55手法×9尺度を継承し、Sourceの設定とBの固定保護を区別する。A条件は `Source条件.json`、B条件は後段の別ファイルとする。条件/停止/実行物/入力指紋を市場実行前に固定し、先頭2→同じ全54を実行する。未固定下書きは実行条件に使わない。

全原板や巨大な完全Observationを正式複製せず、必要な新通知Tape/金融Nativeを圧縮保存し、Viewerの一覧resourcesと約定tradesを作る。コード・依存・Go版を保存する。ライブ報告の市場前原文は実行前仕様へコピーし、旧103とA/Bの固定資料は改変しない。

[元Sourceの重複条件](../../docs/議論/元Sourceの売買対称性と重複条件.md) / [103の起動と建玉構造の知見](../../docs/議論/利益追尾の起動時機と元の建玉構造を分ける.md)。今回の変更の根拠は静的に確認した方向裁定とユーザーの売買同条件指定であり、新式の収益効果は未検証。
"""
    if (target / "README.md").exists():
        assert (target / "README.md").read_text(encoding="utf-8") == plan
    else:
        (target / "README.md").write_text(plan, encoding="utf-8")

    # ----------------------------------------
    # 旧試行の数値を持ち込まず、55×9の表とSource閾値だけを継承する。
    source = (study_root / "00103_元の多玉と数量を保つ一定利益後の追尾/設定と結果.md").read_text(encoding="utf-8")
    catalog = source[source.index("# 手法と時間スケールの汎用表・版5"):source.index("## 設定明細（市場前固定）")]
    catalog = catalog.replace("（全16）", "（A全mode・B全設定予定）")
    catalog = catalog.replace("S02/K02:元ATR12・Value/幅を区別", "S02/K04:元ATR12・Value/幅を区別")
    catalog = catalog.replace("S08/09元管理、K01〜03追加追尾（主12）", "S08/09元管理（A/B）、K04/06追加追尾（B全設定予定）")
    catalog = catalog.replace("K06:正常BBO/strict後行", "K07:正常BBO/strict後行")
    catalog = catalog.replace("S08/09元管理、K01〜03追加全玉（主12）", "S08/09元管理（A/B）、K04/06追加全玉（B全設定予定）")
    details = source[source.index("| S01 | 元方向"):source.index("| K01 | P0起動")]
    details = details.replace("R01〜16", "R01〜03・R04〜11予定").replace("本試行実行済・単独寄与は未検証", "A/B未検証・単独寄与は未検証")
    settings = """# 00104：設定と結果

市場実行前。Sourceの方向裁定一式だけを変更し、技法・時計・数量・一定利益後保護を重ねて選び直さない。使用表は版5、55手法×9尺度。Aの連続Source診断とBの5分LD10売買は別であり、103の数値を結果へ転記しない。

""" + catalog + """## 設定明細（実行前）

| 設定ID | 役割 | 閾値/内容 | 適用評価 | 状態 |
| --- | --- | --- | --- | --- |
""" + details + """| K01 | 元生成口 | 元93 constructor・全式既定 | R01、R04〜07予定 | A/B未検証 |
| K02 | 既定全式生成口 | 全式mapで既定と同じ式、D60/P60/U54 | R02 | A未検証・旧93全文対照専用 |
| K03 | 重複時待機 | ER<=0.3、L=mid<=low+0.1R/H=mid>=high−0.1R、L==Hなら0・Lのみ+1/Hのみ−1。他式不変 | R03、R08〜11予定 | A/B未検証 |
| K04 | LD10起動 | ATRLock.Value既知、u円>=100*max(10,Value)、元5分ATR12/初回既知で固定 | R04〜11予定 | B未実装/未固定/未検証 |
| K05 | B5Qと判断時計 | strict次5分一枠、開始30分見送り、元米国前後15分静観/個別締切/Force、主6048/副5832 | R04〜11予定 | B接続準備・Aへ定時制限を付けたとはしない |
| K06 | 起動後追尾 | 5*ceil(2*Value/5)固定、最低名目建値、非緩和、元Source損失管理 | R04〜11予定 | B未検証・新可変幅未使用 |
| K07 | 商品/執行/費用 | Bはmini各側10、100円/pt・税込38.5片道、C0/C5・strict次気配/D1価格秒。Aは元mini/micro規格の照合 | R01〜03、R04〜11予定 | 新しいmini実板約定は未観測 |
| K08 | 参加分子 | 同枠実取得または当時実保有の和集合、受理のみ/遅いFill/欠測を分離 | R04〜11予定 | Aの全場取引を参加100%としない |

## 複合条件と結果

### 段階A：Sourceの実再形成

| 評価ID | mode | 変更 | 旧93全文比較 | 自然Signal/Fill | 結果 |
| --- | --- | --- | --- | --- | --- |
| R01 | legacy | K01・元生成口 | 除外0で実施予定 | 未検証 | 未実行・採用売買の成績ではない |
| R02 | default | K02・既定完全式map | 除外0で実施予定 | 未検証 | 未実行・生成口同値対照 |
| R03 | symmetric | K03・重複待機一式 | 旧同値は要求せず差を記録 | 未検証 | 未実行・新Source |

Aは各modeでDay mini/micro各D、Night mini/micro各P/U、54場計486Source会計。原板・確定足・完全Observationの元経路で自然生成する。Aの旧商品規格の費用後額とBを混同しない。

### 段階B：予定する固定保護の比較

| 評価ID | Source | 保護 | 追加滑りpt/片道 | 追加価格秒 | 純額 | 参加率 | 状態 |
| --- | --- | --- | ---: | ---: | --- | --- | --- |
"""
    index = 4
    for mode in ["legacy", "symmetric"]:
        for slip in [0, 5]:
            for delay in [0, 1]:
                settings += f"| R{index:02d} | {mode} | B5Q/LD10 | {slip} | {delay} | 未検証 | 未検証 | 接続/金融は別固定前 |\n"
                index += 1
    settings += """
適用はS01〜10とK01またはK03、K04〜08の複合。金融の具体KeyはB実行前の別固定で明記し、R04〜11との対応を保持する。閾値はAの損益を見て選び直さない。defaultは同値確認後のB結果を重複計上しない。

## 記録範囲

新規/保有/待機/判定不能と分母、全正負額・PF・保存点DD、日夜/開始日/売買別、u正益後と保護起動後赤字を分離する。旧95/103との一致は実際に照合した範囲だけに限定。未参加/退出後の仮想利益は扱わない。

価格波形からの複数指標は独立証拠とは限らず、元支持値を校正済み勝率としない。Aの範囲裁定の符号対称性と、自然Source全体や任意の価格反射での全面鏡像は区別する。

[計画と再現方針](README.md) / [版5の正本](../../docs/議論/手法と時間スケールの汎用表_版5.md)。確認日2026-11-09。入力/コード/実行物固定と市場実行の証拠は作成後に追加する。
"""
    rows = [line for line in catalog.splitlines() if re.match(r"\| (I|V|P|C|B|X|M|Q|E)\d{2} \|", line)]
    assert len(rows) == 55 and all(len(row.split("|")) == 13 for row in rows)
    (target / "設定と結果.md").write_text(settings, encoding="utf-8")
    snapshots = target / "実行前仕様"
    snapshots.mkdir()
    for name in ["README.md", "設定と結果.md"]:
        (snapshots / name).write_bytes((target / name).read_bytes())
    print("104採番・計画・全55×9表を新規保存。市場実行0。")


if __name__ == "__main__":
    main()
