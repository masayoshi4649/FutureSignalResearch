"""104段階Aの条件と小さいコード保存を、市場再生前に固定する。"""

import hashlib
import json
import os
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / "study/00104_重複時の方向裁定と元Sourceの再形成"
DRAFT = ROOT / "work/104条件固定の準備_版2/候補/条件_未固定.json"


def sha(path: Path) -> str:
    """
    機能: 保存内容の指紋を求める。
    引数: path(Path)は実在ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict:
    """
    機能: UTF-8の固定資料を読み込む。
    引数: path(Path)はJSONファイル。
    返り値: dictは保存値。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def resolve_code(name: str) -> Path:
    """
    機能: CLIのcodeキーを実在位置へ解決する。
    引数: name(str)はrepo相対又は絶対path。
    返り値: Pathは正規化済み絶対path。
    """
    path = Path(name)
    return path.resolve() if path.is_absolute() else (ROOT / path).resolve()


def archive_name(path: Path) -> str:
    """
    機能: ZIPへ親参照のない名前を付ける。
    引数: path(Path)はコードの実位置。
    返り値: strは元位置を台帳で対応可能な保存名。
    """
    try:
        return "repo/" + path.relative_to(ROOT).as_posix()
    except ValueError:
        return "外部/" + path.as_posix().replace(":", "")


def main() -> None:
    """
    機能: 未固定下書きの参照を正式dir基準へ直し、fixed条件を初回保存する。
    引数: なし。Source版2停止とRootの実行前仕様を必須とする。
    返り値: None。新条件/コードZIP/固定証拠のみを作り、原板・CSV・Sourceを実行しない。
    """
    condition_path = STUDY / "Source条件.json"
    code_zip = STUDY / "Source再現コード.zip"
    fixed_path = STUDY / "Source実行前固定.json"
    assert not condition_path.exists() and not code_zip.exists() and not fixed_path.exists()
    creation = read(DRAFT.parent / "作成確認.json")
    assert creation["成功"] and not creation["fixed"] and not creation["Root snapshot pending"]
    assert sha(DRAFT) == creation["条件SHA256"]
    condition = read(DRAFT)
    assert condition["trial"] == 104 and condition["version"] == 1 and not condition["fixed"]
    assert condition["modes"] == ["legacy", "default", "symmetric"] and len(condition["scenes"]) == 54
    assert creation["CLI版2停止SHA256"] == "ea208380d5b1e71f4370e9ed9a081d9858b4951c8d5eeb3221ca8e08e3b30e1a"
    partition = read(DRAFT.parent / "コード保存の区分.json")
    excluded = partition["本文をZIPへ複製しないSHA256"]
    code = condition["code_sha256"]
    code[str(Path(__file__).relative_to(ROOT)).replace("\\", "/")] = sha(Path(__file__))
    for name, expected in code.items():
        assert sha(resolve_code(name)) == expected, name
    for name, expected in excluded.items():
        assert code[name] == expected

    # ----------------------------------------
    # FileRefだけを正式条件dir基準へ再配置し、値や対象を変えない。
    refs = [condition[k] for k in ["manifest80", "generator_stop", "replay_stop", "binary"]]
    refs += [scene["baseline93"] for scene in condition["scenes"]]
    for ref in refs:
        source = Path(ref["path"])
        if not source.is_absolute():
            source = DRAFT.parent / source
        source = source.resolve()
        assert sha(source) == ref["sha256"]
        ref["path"] = os.path.relpath(source, STUDY).replace("\\", "/")
    assert condition["binary"]["sha256"] == "6b5f897e62f91a94fbe2e6b6a82e7d1855fe741f8a452753245c62672e1e5033"
    condition["fixed"] = True
    condition_path.write_text(json.dumps(condition, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    # ----------------------------------------
    # 外部toolchainは指紋参照にし、原板と旧Native本文をZIPへ含めない。
    mapping = {}
    with zipfile.ZipFile(code_zip, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, expected in code.items():
            if name in excluded:
                continue
            path = resolve_code(name)
            destination = archive_name(path)
            assert destination not in mapping
            info = zipfile.ZipInfo(destination, date_time=(2026, 11, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            raw = path.read_bytes()
            assert hashlib.sha256(raw).hexdigest() == expected
            archive.writestr(info, raw)
            mapping[destination] = {"元codeキー": name, "sha256": expected}
        info = zipfile.ZipInfo("展開対応とtoolchain参照.json", date_time=(2026, 11, 9, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        value = {"展開対応": mapping, "別途必要なtoolchain": excluded, "Go版": partition["Go版"], "GOROOT": partition["GOROOT"]}
        archive.writestr(info, json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    with zipfile.ZipFile(code_zip) as archive:
        assert archive.testzip() is None
        for name, item in mapping.items():
            assert hashlib.sha256(archive.read(name)).hexdigest() == item["sha256"]
    for name, expected in code.items():
        assert sha(resolve_code(name)) == expected
    proof = {"成功": True, "段階": "A/Source再形成", "条件": {"path": condition_path.name, "sha256": sha(condition_path)},
             "市場実行前": True, "実行物": condition["binary"], "固定code資料数": len(code),
             "ZIP": {"path": code_zip.name, "sha256": sha(code_zip), "bytes": code_zip.stat().st_size,
                     "本文保存code資料数": len(mapping), "toolchain指紋参照数": len(excluded)},
             "下書き": {"path": str(DRAFT.relative_to(ROOT)), "sha256": sha(DRAFT)},
             "Go版": partition["Go版"], "Source条件変更": "共有range_sideの両側成立だけ待機、他式と元商品規格は固定",
             "場": 54, "先頭2": [s["session"] for s in condition["scenes"][:2]], "mode": condition["modes"],
             "Raw_CSV本文読取": 0, "Source実行": 0, "B金融実行": 0, "旧103変更": 0,
             "限界": "固定はWindows/amd64の実Go版と参照配置。toolchain本文/原板/旧NativeはZIP複製しない。段階Bは別固定。"}
    fixed_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "条件SHA256": sha(condition_path), "code": len(code), "ZIPbytes": code_zip.stat().st_size}, ensure_ascii=False))


if __name__ == "__main__":
    main()
