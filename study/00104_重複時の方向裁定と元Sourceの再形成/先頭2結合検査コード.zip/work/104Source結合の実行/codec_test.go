package main

import (
	"compress/gzip"
	"os"
)

// writeGzipFixture はcodec人工の文字列だけを新規保存します。
//
// 引数: path/body(string)は新規先と手製JSONLです。
// 返り値: errorは保存又はclose失敗です。
func writeGzipFixture(path, body string) error {
	f, e := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return e
	}
	z := gzip.NewWriter(f)
	_, e = z.Write([]byte(body))
	if close := z.Close(); e == nil {
		e = close
	}
	if close := f.Close(); e == nil {
		e = close
	}
	return e
}
