package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"testing"

	run103 "github.com/masayoshi4649/SessionTradeExecuter/delayedreplay103"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
)

// sourceFixture は実Sourceを装わない成功metadata型を作ります。
//
// 引数: なし。返り値: SourceCompletionは6case集合の手製schema器具です。
func sourceFixture() SourceCompletion {
	h := strings.Repeat("a", 64)
	s := SourceCompletion{Version: 1, Trial: 104, Stage: "first2", Success: true, Sessions: 2, ConditionSHA: h, Before: map[string]string{"人工": h}, After: map[string]string{"人工": h}, Unchanged: true, Formed: true}
	for _, id := range run103.AllowedSessions()[:2] {
		for _, mode := range []string{"legacy", "default", "symmetric"} {
			s.Cases = append(s.Cases, SourceCase{Session: id, Mode: mode, Result: FileRef{"result.json", h}, Records: FileRef{"records.jsonl.gz", h}, Match: mode != "symmetric", Counts: Counts{Calls: 2, Steps: 1, Forces: 1}})
		}
	}
	return s
}

// TestSourceMetadata は上流6case/前後指紋/旧対照の誤用を拒否します。
//
// 引数: t(*testing.T)は人工試験器です。返り値: なし。実市場完了を読みません。
func TestSourceMetadata(t *testing.T) {
	if e := validateSource(sourceFixture()); e != nil {
		t.Fatal(e)
	}
	tests := []struct {
		name string
		bad  func(*SourceCompletion)
	}{
		{"未成功", func(s *SourceCompletion) { s.Success = false }},
		{"full54流用", func(s *SourceCompletion) { s.Stage = "full54" }},
		{"余分", func(s *SourceCompletion) { s.Cases = append(s.Cases, s.Cases[0]) }},
		{"欠落", func(s *SourceCompletion) { s.Cases = s.Cases[:5] }},
		{"重複6件", func(s *SourceCompletion) { s.Cases[5] = s.Cases[0] }},
		{"別日", func(s *SourceCompletion) { s.Cases[0].Session = "2026-09-22_Day" }},
		{"別mode", func(s *SourceCompletion) { s.Cases[0].Mode = "empty" }},
		{"対称へ旧一致", func(s *SourceCompletion) { s.Cases[2].Match = true }},
		{"空参照", func(s *SourceCompletion) { s.Cases[0].Records.Path = "" }},
		{"偽SHA", func(s *SourceCompletion) { s.Cases[0].Result.SHA = "bad" }},
		{"前後差", func(s *SourceCompletion) { s.After["人工"] = strings.Repeat("b", 64) }},
		{"Source未形成", func(s *SourceCompletion) { s.Formed = false }},
		{"金融混同", func(s *SourceCompletion) { s.Finance = true }},
		{"counter差", func(s *SourceCompletion) { s.Cases[0].Counts.Calls++ }},
	}
	for _, test := range tests {
		t.Run(test.name, func(t *testing.T) {
			value := sourceFixture()
			test.bad(&value)
			if e := validateSource(value); e == nil {
				t.Fatal("不正metadata受理")
			}
		})
	}
}

// TestLegalCodecBinding は停止済み合法空通知だけをconsumerへ接続します。
//
// 引数: t(*testing.T)は人工試験器です。
// 返り値: なし。新規/Fill0の型器具であり自然Source成功ではありません。
func TestLegalCodecBinding(t *testing.T) {
	path := filepath.Join("..", "104新Sourceと判断時計の結合案", "人工", "停止版", "合法空通知.json")
	h, e := run103.FileSHA(path)
	if e != nil || h != "453b8390eba1c7a3f9406ddbac8bebe82c21e7f21d43a461557cfdc9151c039b" {
		t.Fatal("停止人工指紋", e)
	}
	var fixture struct {
		Old     tape.Tape             `json:"old_tape"`
		Records []binder.SourceRecord `json:"records"`
	}
	if e = decode(path, &fixture, false, false); e != nil {
		t.Fatal(e)
	}
	dir := t.TempDir()
	oldPath := filepath.Join(dir, "old.json.gz")
	if e = writeNew(oldPath, fixture.Old, true); e != nil {
		t.Fatal(e)
	}
	recordPath := filepath.Join(dir, "records.jsonl.gz")
	if e = writeRecordFixture(recordPath, fixture.Records); e != nil {
		t.Fatal(e)
	}
	read, count, e := readRecords(recordPath)
	if e != nil || !reflect.DeepEqual(read, fixture.Records) {
		t.Fatal("SourceRecord全型再読", e)
	}
	source := []SourceCase{}
	for _, mode := range []string{"legacy", "default", "symmetric"} {
		source = append(source, SourceCase{Session: fixture.Old.Session.ID, Mode: mode, Records: FileRef{Path: recordPath}, Counts: count})
	}
	rows, e := bindScene(fixture.Old.Session.ID, FileRef{Path: oldPath}, source, dir)
	if e != nil || len(rows) != 3 {
		t.Fatal("型人工結合", e)
	}
	for _, row := range rows {
		if !validSHA(row.NewTape.SHA) || row.Compatibility.AllPoints || row.Compatibility.EnvelopeEqual || row.Error != "" {
			t.Fatal("scope又は出力指紋")
		}
		if row.Mode != "symmetric" && (!row.Binding.NotificationsEqualOld || !row.Compatibility.Performed || row.Compatibility.Books != 16 || len(row.Compatibility.Excluded) != 0) {
			t.Fatal("旧通知/最終16全文の欠落")
		}
		if row.Mode == "symmetric" && row.Compatibility.Performed {
			t.Fatal("symmetric金融を実行")
		}
	}
	if e = writeNew(oldPath, fixture.Old, true); e == nil {
		t.Fatal("既存成果を上書き")
	}
	if _, e = bindScene(fixture.Old.Session.ID, FileRef{Path: oldPath}, source, dir); e == nil {
		t.Fatal("既存結合出力を上書き")
	}
}

// writeRecordFixture は型人工だけを上流と同じgzip JSONLへ保存します。
//
// 引数: path(string)、rows([]binder.SourceRecord)は新規先と手製型です。
// 返り値: errorは保存失敗です。市場通知は生成しません。
func writeRecordFixture(path string, rows []binder.SourceRecord) error {
	var body strings.Builder
	for _, row := range rows {
		b, e := json.Marshal(row)
		if e != nil {
			return e
		}
		body.Write(b)
		body.WriteByte('\n')
	}
	return writeGzipFixture(path, body.String())
}

// TestRejectBeforeInputs は未固定条件を対象データより前に拒否します。
//
// 引数: t(*testing.T)は試験器です。返り値: なし。市場pathは渡しません。
func TestRejectBeforeInputs(t *testing.T) {
	if _, e := prepare("存在しない条件.json", "", t.TempDir(), "none.exe"); e == nil {
		t.Fatal("未固定を受理")
	}
	c := Condition{Version: 1, Trial: 104, Fixed: false, Stage: "first2", Compatibility: "final", Index: FileRef{SHA: Old100IndexSHA}}
	dir := t.TempDir()
	p := filepath.Join(dir, "condition.json")
	if e := writeNew(p, c, false); e != nil {
		t.Fatal(e)
	}
	h, _ := run103.FileSHA(p)
	if _, e := prepare(p, h, dir, "none.exe"); e == nil || !strings.Contains(e.Error(), "未固定") {
		t.Fatal("未固定Root条件の読取前拒否", e)
	}
	bad := filepath.Join(dir, "bad.jsonl.gz")
	if e := writeGzipFixture(bad, "{\"未知field\":1}\n"); e != nil {
		t.Fatal(e)
	}
	if _, _, e := readRecords(bad); e == nil {
		t.Fatal("未知fieldを捨てた")
	}
	if e := os.WriteFile(filepath.Join(dir, "壊れたgzip"), []byte("破損"), 0600); e != nil {
		t.Fatal(e)
	}
	if _, _, e := readRecords(filepath.Join(dir, "壊れたgzip")); e == nil {
		t.Fatal("壊れたgzipを受理")
	}
}
