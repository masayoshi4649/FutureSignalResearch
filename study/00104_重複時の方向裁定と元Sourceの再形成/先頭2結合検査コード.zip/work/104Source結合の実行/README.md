# Source先頭2場と旧判断時計の結合CLI（実接続前）

module `github.com/masayoshi4649/SessionTradeExecuter/sourcebindcli104`。停止済み[純Binder](../104新Sourceと判断時計の結合案/README.md)の`Bind`と、停止済み103の`RunTape`を直接importする。Source、特徴、金融式、旧Tape配送、JSON parserの独自代用品は作っていない。JSONL読込とmetadata guard/新規保存だけがこのCLIの役割。

市場のSourceRecord/Tape本文・Raw/CSV・新しい期間は、この準備では読んでいない。Rootが実行前条件・code閉包・binaryを固定してから実first2だけを実行する。SourceA全54のプロセスは操作しない。

## 固定する条件

[雛形](実行条件の雛形.json)の`fixed:false`/空SHAはそのまま拒否される。Rootが新規条件を作る。

- `version:1,trial:104,fixed:true,stage:first2,compatibility_103:final`。
- `source_first2:{path,sha256}`：SourceA先頭2の完了。成功/前後不変/形成true/103金融false、9月21日のDay/Night×legacy/default/symmetricの正確6caseを必須とする。legacy/defaultだけ旧93一致true、symmetricはfalse。各Source result/recordsの実SHAを検査し、result本文は展開しない。Rawを含み得る上流before辞書はmetadataの前後一致だけを確認し、その全pathを本CLIで再読しない。
- `old100_tape_index:{path,sha256}`：旧100正式54Tape台帳（固定SHA `4db6812dda91ae4235d15ce5619c19a7dffa305f24ec3f577332d8665b49610f`）。全54ID/順序/参照型を確認し、Tape本文の対象は先頭2だけ。
- `binder_stop:{path,sha256}`：純Bind停止（現在 `e66adae009ff3edfa59b38dd22ffa07c48f83843f045080a4ede0045dab0fbf2`）。成功と`所有コードSHA256`全体の正規path/SHAを下記code集合へ包含する。
- `binary:{path,sha256}`：実行中exeと一致。`code_sha256`はrepo相対又は絶対path→SHA。`runtime.Caller`が示す当CLIのmain.go/bind.go/go.mod/go.sumを必須とし、Rootが103金融等の推移依存も固定する。全Go閉包を本CLIで独自探索しない。

FileRefは条件directory基準、codeはrepo基準、旧台帳entriesは台帳directory基準。Source出力FileRefはSource完了directory基準。全metadata/code/binaryを先検査した後、選択した旧Tape2とSource出力6組の指紋を確認する。条件自身もbefore/afterへ含め、実行後に同じ入力集合を再hashする。条件SHAを後からコードへ埋め込む処理はない。

```powershell
Set-Location '<repo>'
& 'work/104Source結合の実行/検査/Source結合.exe' `
  --condition '<Rootが新規固定した結合条件.json>' `
  --condition-sha '<条件のSHA256>' `
  --out '<存在しない先頭2結合出力先>'
```

本CLIにfull54モードや金融の経済成績集計はない。未固定/別stageを既存first2成功へ補完しない。既存directoryは拒否し、個別ファイルもO_EXCLで保存する。通常の結合/比較/保存/後指紋エラーはsuccess=falseの完了へ残す。Preflight・新規directory作成前の失敗では完了ファイル自体を作らない。

## 接続と成功範囲

1場×1modeで上流gzip JSONLを`SourceRecord`全型へ読み、UnknownFieldsと末尾破損を拒否。全通知countsを上流完了へ合わせ、全micro/mini・active method順を純Binderへそのまま渡す。SourceRecord配列と旧Tape1場を保持する方式であり、逐次Boundメモリの実測は未実施。

Bindがfresh Scalar11全値、特徴Index/物理行、全Delta、quote/force位相、直前SourceLine、空通知、余剰/欠落を確認する。gridと既存Contextは旧Tapeから保持するが、新Sourceから技法を形成した成功とは呼ばない。新Scope/Provenanceは純Binderが区別して保存する。

legacy/defaultは旧mini公開通知全文一致を必須にする。その後、旧Tapeと結合Tapeを同じ103 `RunTape`へ流し、**最終16 Bookの全JSONをfield除外0で比較**する。完結/全16・主12診断4・grid時計・event件数も確認する。envelopeのTapeSHA/Scopeは異なるためRunResult全体の同体とは呼ばない。全原行の深いSnapshot比較（all_points）は本CLIでは実装・実行していない。symmetricはBindだけで金融を運転しない。

この互換QAはP0/LD05/LD10/S0×C/Dの16冊であり、主Bで将来比較するLD10四感度×旧/対称の8設定へ経済採用数を足さない。完了には`economic_adopted_books:0`を記す。Sourceを再形成せず、旧/新のSourceの優劣・対称性・未知期間利益を判定しない。

出力は6個の`{session}_{mode}.tape.json.gz`と`完了.json`。完了casesはSource result/records・旧/新TapeのFileRef、BinderのProof、最終金融互換のBook JSON SHA、all_points=false、envelope同体falseを持つ。金銭の全件転記やRaw複製はしない。

## 今回の人工

```powershell
Push-Location 'work/104Source結合の実行'
go test -json -count=1 ./...
go vet ./...
go build -o 検査/Source結合.exe .
Pop-Location
```

停止純Bindの`人工/停止版/合法空通知.json`をSHA照合して直接再用し、JSONL→Bind→legacy/default最終16×2=32 Book全文比較、symmetric金融未実行、新Tape保存型、上書き拒否を確認した。これは**全て取引0の手製codec型人工**。非0Source形成や実first2成功ではない。既存の非0API人工は同秒quote後Forceという市場位相外の器具なので本CLIへ無理に適合させていない。

上流metadataの正常6caseと14破損、未固定Root条件の入力前拒否、未知SourceRecord欄と壊れたgzipも拒否した。実first2の自然非0接続、メモリ/所要時間、旧100Tapeとの実Scalar一致はRoot実行で初めて確認する。機会損失・退出後価格・新仮説の損益は計算しない。
