package main

import (
	"bytes"
	"compress/gzip"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"

	run103 "github.com/masayoshi4649/SessionTradeExecuter/delayedreplay103"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	binder "github.com/masayoshi4649/SessionTradeExecuter/sourceclock104"
)

type Compatibility struct {
	Performed     bool     `json:"performed"`
	AllPoints     bool     `json:"all_points"`
	Books         int      `json:"books"`
	Excluded      []string `json:"book_field_excluded"`
	EnvelopeEqual bool     `json:"whole_envelope_equal"`
	FinalSHA      string   `json:"final_books_json_sha256,omitempty"`
	Scope         string   `json:"scope"`
}
type CaseResult struct {
	Session       string        `json:"session"`
	Mode          string        `json:"mode"`
	SourceRecords FileRef       `json:"source_records"`
	SourceResult  FileRef       `json:"source_result"`
	OldTape       FileRef       `json:"old_tape"`
	NewTape       FileRef       `json:"new_tape"`
	Binding       binder.Proof  `json:"binding"`
	Compatibility Compatibility `json:"compatibility_103"`
	Error         string        `json:"error,omitempty"`
}

// readRecords は上流gzip全記録を未知欄を落とさず型検査して読みます。
//
// 引数: path(string)はRoot固定後のSource JSONLです。
// 返り値: []binder.SourceRecord/Counts/errorは全記録と実count又は読取失敗です。
func readRecords(path string) ([]binder.SourceRecord, Counts, error) {
	rows := []binder.SourceRecord{}
	count := Counts{}
	f, e := os.Open(path)
	if e != nil {
		return rows, count, e
	}
	defer f.Close()
	z, e := gzip.NewReader(f)
	if e != nil {
		return rows, count, e
	}
	defer z.Close()
	d := json.NewDecoder(z)
	d.DisallowUnknownFields()
	for {
		var row binder.SourceRecord
		e = d.Decode(&row)
		if e == io.EOF {
			break
		}
		if e != nil {
			return rows, count, e
		}
		rows = append(rows, row)
		count.Calls++
		switch row.Kind {
		case "quote":
			count.Steps++
		case "force":
			count.Forces++
		default:
			return rows, count, fmt.Errorf("未知SourceRecord種別")
		}
		count.Signals += len(row.Delta.Signals)
		count.Fills += len(row.Delta.Fills)
		count.Closes += len(row.Delta.Closes)
		count.Cancels += len(row.Delta.Cancellations)
	}
	return rows, count, nil
}

// compareFinal は全16金融Bookをfield除外なしで比較します。
//
// 引数: old/new(run103.RunResult)は同じ時計の旧/結合結果です。
// 返り値: Compatibility/errorは最終全文一致又は差です。envelopeのTapeSHA等は別です。
func compareFinal(old, new run103.RunResult) (Compatibility, error) {
	proof := Compatibility{Excluded: []string{}, Scope: "103 RunTape最終全16Book JSON。全時点未実施。主B8設定の経済比較ではない"}
	if !old.Complete || !new.Complete || !old.InputUnchanged || !new.InputUnchanged || len(old.Books) != 16 || len(new.Books) != 16 || !reflect.DeepEqual(old.MainKeys, new.MainKeys) || !reflect.DeepEqual(old.DiagnosticKeys, new.DiagnosticKeys) || !reflect.DeepEqual(old.GridTimes, new.GridTimes) || old.Events != new.Events {
		return proof, fmt.Errorf("103完結/集合/時計差")
	}
	a, e := json.Marshal(old.Books)
	if e != nil {
		return proof, e
	}
	b, e := json.Marshal(new.Books)
	if e != nil {
		return proof, e
	}
	if !bytes.Equal(a, b) {
		return proof, fmt.Errorf("103最終16Book全JSON差")
	}
	h := sha256.Sum256(b)
	proof.FinalSHA = hex.EncodeToString(h[:])
	proof.Performed = true
	proof.Books = 16
	return proof, nil
}

// bindScene は一場の3modeを逐次結合し制御2modeだけ最終金融を照合します。
//
// 引数: id(string)、oldRef(FileRef)、source([]SourceCase)、dir(string)は先頭場・旧Tape・全6上流case・新規先です。
// 返り値: []CaseResult/errorは3mode結果又は失敗までです。Sourceを作りません。
func bindScene(id string, oldRef FileRef, source []SourceCase, dir string) ([]CaseResult, error) {
	rows := []CaseResult{}
	var old tape.Tape
	if e := decode(oldRef.Path, &old, true, true); e != nil {
		return rows, e
	}
	if old.Session.ID != id {
		return rows, fmt.Errorf("旧Tape session差")
	}
	baseline, e := run103.RunTape(old)
	if e != nil {
		return rows, e
	}
	for _, mode := range []string{"legacy", "default", "symmetric"} {
		var input SourceCase
		for _, row := range source {
			if row.Session == id && row.Mode == mode {
				input = row
				break
			}
		}
		row := CaseResult{Session: id, Mode: mode, SourceRecords: input.Records, SourceResult: input.Result, OldTape: oldRef, Compatibility: Compatibility{Excluded: []string{}, Scope: "symmetricは金融未実行。全時点未実施"}}
		records, counts, e := readRecords(input.Records.Path)
		if e == nil && !reflect.DeepEqual(counts, input.Counts) {
			e = fmt.Errorf("上流全通知count差")
		}
		var joined tape.Tape
		if e == nil {
			joined, row.Binding, e = binder.Bind(old, records, mode)
		}
		if e == nil && mode != "symmetric" {
			var result run103.RunResult
			result, e = run103.RunTape(joined)
			if e == nil {
				row.Compatibility, e = compareFinal(baseline, result)
			}
		}
		if e == nil {
			row.NewTape.Path = filepath.Join(dir, id+"_"+mode+".tape.json.gz")
			e = writeNew(row.NewTape.Path, joined, true)
			if e == nil {
				row.NewTape.SHA, e = run103.FileSHA(row.NewTape.Path)
			}
		}
		if e != nil {
			row.Error = e.Error()
		}
		rows = append(rows, row)
		if e != nil {
			return rows, e
		}
	}
	return rows, nil
}
