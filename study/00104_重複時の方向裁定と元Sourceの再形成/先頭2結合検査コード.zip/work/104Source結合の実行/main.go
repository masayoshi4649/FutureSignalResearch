package main

import (
	"compress/gzip"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"reflect"
	"runtime"
	"strings"

	run103 "github.com/masayoshi4649/SessionTradeExecuter/delayedreplay103"
)

const Old100IndexSHA = "4db6812dda91ae4235d15ce5619c19a7dffa305f24ec3f577332d8665b49610f"

type FileRef struct {
	Path string `json:"path"`
	SHA  string `json:"sha256"`
}
type Condition struct {
	Version       int               `json:"version"`
	Trial         int               `json:"trial"`
	Fixed         bool              `json:"fixed"`
	Stage         string            `json:"stage"`
	Source        FileRef           `json:"source_first2"`
	Index         FileRef           `json:"old100_tape_index"`
	Binder        FileRef           `json:"binder_stop"`
	Binary        FileRef           `json:"binary"`
	Code          map[string]string `json:"code_sha256"`
	Compatibility string            `json:"compatibility_103"`
}
type Counts struct {
	Calls   int `json:"calls"`
	Steps   int `json:"steps"`
	Forces  int `json:"forces"`
	Signals int `json:"signals"`
	Fills   int `json:"fills"`
	Closes  int `json:"closes"`
	Cancels int `json:"cancellations"`
}
type SourceCase struct {
	Session string  `json:"session"`
	Mode    string  `json:"mode"`
	Result  FileRef `json:"result"`
	Records FileRef `json:"records"`
	Counts  Counts  `json:"counts"`
	Match   bool    `json:"old93_full_match"`
	Error   string  `json:"error,omitempty"`
}
type SourceCompletion struct {
	Version      int               `json:"version"`
	Trial        int               `json:"trial"`
	Stage        string            `json:"stage"`
	Success      bool              `json:"success"`
	ConditionSHA string            `json:"condition_sha256"`
	Sessions     int               `json:"sessions"`
	Cases        []SourceCase      `json:"cases"`
	Before       map[string]string `json:"before"`
	After        map[string]string `json:"after"`
	Unchanged    bool              `json:"unchanged"`
	Formed       bool              `json:"source_reformed"`
	Finance      bool              `json:"financial103_executed"`
	Error        string            `json:"error,omitempty"`
}
type Index struct {
	Version int    `json:"version"`
	Stage   string `json:"stage"`
	Entries []struct {
		Session string `json:"session"`
		Path    string `json:"path"`
		SHA     string `json:"sha256"`
	} `json:"entries"`
}
type BinderStop struct {
	Success bool              `json:"成功"`
	Code    map[string]string `json:"所有コードSHA256"`
}
type Prepared struct {
	Condition Condition
	Source    SourceCompletion
	Old       map[string]FileRef
	Before    map[string]string
}
type Completion struct {
	Version       int               `json:"version"`
	Trial         int               `json:"trial"`
	Stage         string            `json:"stage"`
	Success       bool              `json:"success"`
	ConditionSHA  string            `json:"condition_sha256"`
	Sessions      int               `json:"sessions"`
	Cases         []CaseResult      `json:"cases"`
	Before        map[string]string `json:"before"`
	After         map[string]string `json:"after"`
	Unchanged     bool              `json:"unchanged"`
	SourceFormed  bool              `json:"source_reformed"`
	RawCSV        int               `json:"raw_csv_read"`
	EconomicBooks int               `json:"economic_adopted_books"`
	Scope         string            `json:"scope"`
	Error         string            `json:"error,omitempty"`
}

// validSHA は未固定又は不正なSHAを拒否します。
//
// 引数: value(string)は期待SHAです。返り値: boolは小文字64桁なら真です。
func validSHA(value string) bool {
	b, e := hex.DecodeString(value)
	return e == nil && len(b) == 32 && strings.ToLower(value) == value
}

// absolute は明示された根を基準にpathを解決します。
//
// 引数: base/name(string)は基準とpathです。返り値: string/errorは絶対path又は空pathです。
func absolute(base, name string) (string, error) {
	if strings.TrimSpace(name) == "" {
		return "", fmt.Errorf("空path")
	}
	if !filepath.IsAbs(name) {
		name = filepath.Join(base, name)
	}
	return filepath.Abs(name)
}

// decode は公開JSON一値を型どおり読み、末尾値を拒否します。
//
// 引数: path(string)、value(any)、compressed/strict(bool)は入力と型・gzip/未知欄拒否です。
// 返り値: errorは読取又は型/末尾破損です。
func decode(path string, value any, compressed, strict bool) error {
	f, e := os.Open(path)
	if e != nil {
		return e
	}
	defer f.Close()
	var reader io.Reader = f
	if compressed {
		z, e := gzip.NewReader(f)
		if e != nil {
			return e
		}
		defer z.Close()
		reader = z
	}
	d := json.NewDecoder(reader)
	if strict {
		d.DisallowUnknownFields()
	}
	if e = d.Decode(value); e != nil {
		return e
	}
	var tail any
	if e = d.Decode(&tail); e != io.EOF {
		return fmt.Errorf("JSON末尾不正")
	}
	return nil
}

// writeNew はJSON又はgzipを既存ファイルへ上書きせず保存します。
//
// 引数: path(string)、value(any)、compressed(bool)は新規先と公開値です。
// 返り値: errorは保存又はclose失敗です。
func writeNew(path string, value any, compressed bool) error {
	f, e := os.OpenFile(path, os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
	if e != nil {
		return e
	}
	var writer io.Writer = f
	var z *gzip.Writer
	if compressed {
		z = gzip.NewWriter(f)
		writer = z
	}
	enc := json.NewEncoder(writer)
	enc.SetEscapeHTML(false)
	e = enc.Encode(value)
	if z != nil {
		if close := z.Close(); e == nil {
			e = close
		}
	}
	if close := f.Close(); e == nil {
		e = close
	}
	return e
}

// validateSource は先頭2場と3modeの上流成功を実結果本文なしで検査します。
//
// 引数: source(SourceCompletion)は固定Source完了metadataです。
// 返り値: errorは不足/重複/不正flag/未固定参照です。
func validateSource(source SourceCompletion) error {
	if source.Version != 1 || source.Trial != 104 || source.Stage != "first2" || !source.Success || source.Error != "" || source.Sessions != 2 || len(source.Cases) != 6 || !source.Unchanged || len(source.Before) == 0 || !reflect.DeepEqual(source.Before, source.After) || !source.Formed || source.Finance || !validSHA(source.ConditionSHA) {
		return fmt.Errorf("Source先頭2成功が必要です")
	}
	wanted := map[string]bool{}
	for _, id := range run103.AllowedSessions()[:2] {
		for _, mode := range []string{"legacy", "default", "symmetric"} {
			wanted[id+"/"+mode] = true
		}
	}
	seen := map[string]bool{}
	for _, row := range source.Cases {
		key := row.Session + "/" + row.Mode
		if !wanted[key] || seen[key] || row.Error != "" || row.Match != (row.Mode != "symmetric") {
			return fmt.Errorf("Sourceの正確な6case集合が不正:%s", key)
		}
		seen[key] = true
		for _, ref := range []FileRef{row.Result, row.Records} {
			if strings.TrimSpace(ref.Path) == "" || !validSHA(ref.SHA) {
				return fmt.Errorf("Source出力未固定:%s", key)
			}
		}
		if row.Counts.Calls <= 0 || row.Counts.Calls != row.Counts.Steps+row.Counts.Forces || row.Counts.Steps <= 0 || row.Counts.Forces <= 0 {
			return fmt.Errorf("Source全通知count不正:%s", key)
		}
	}
	return nil
}

// prepare はRoot条件と3参照/実行codeを先に固定し対象入力SHAだけを集めます。
//
// 引数: conditionPath/conditionSHA/root/exe(string)はRoot固定入力と実行物です。
// 返り値: Prepared/errorは検査済み先頭2場又は読取前拒否です。Rawは開きません。
func prepare(conditionPath, conditionSHA, root, exe string) (Prepared, error) {
	p := Prepared{Old: map[string]FileRef{}, Before: map[string]string{}}
	check := func(ref FileRef, base string) (string, error) {
		if !validSHA(ref.SHA) {
			return "", fmt.Errorf("SHA未固定")
		}
		name, e := absolute(base, ref.Path)
		if e != nil {
			return "", e
		}
		h, e := run103.FileSHA(name)
		if e != nil || h != ref.SHA {
			return "", fmt.Errorf("指紋差:%s", name)
		}
		p.Before[name] = h
		return name, nil
	}
	cp, e := check(FileRef{conditionPath, conditionSHA}, root)
	if e != nil {
		return p, e
	}
	base := filepath.Dir(cp)
	if e = decode(cp, &p.Condition, false, true); e != nil {
		return p, e
	}
	c := p.Condition
	if c.Version != 1 || c.Trial != 104 || !c.Fixed || c.Stage != "first2" || c.Compatibility != "final" || len(c.Code) == 0 || c.Index.SHA != Old100IndexSHA {
		return p, fmt.Errorf("first2結合条件が未固定又は対象外")
	}
	code := map[string]string{}
	for name, h := range c.Code {
		path, e := check(FileRef{name, h}, root)
		if e != nil {
			return p, e
		}
		key := strings.ToLower(filepath.Clean(path))
		if _, ok := code[key]; ok {
			return p, fmt.Errorf("code正規path重複")
		}
		code[key] = h
	}
	_, caller, _, ok := runtime.Caller(0)
	if !ok || !filepath.IsAbs(caller) {
		return p, fmt.Errorf("CLI実path根拠なし")
	}
	for _, name := range []string{"main.go", "bind.go", "go.mod", "go.sum"} {
		if code[strings.ToLower(filepath.Join(filepath.Dir(caller), name))] == "" {
			return p, fmt.Errorf("当CLI code未固定:%s", name)
		}
	}
	bp, e := check(c.Binary, base)
	if e != nil {
		return p, e
	}
	actual, e := filepath.Abs(exe)
	if e != nil || !strings.EqualFold(actual, bp) {
		return p, fmt.Errorf("実binary path差")
	}
	sp, e := check(c.Binder, base)
	if e != nil {
		return p, e
	}
	var stop BinderStop
	if e = decode(sp, &stop, false, false); e != nil {
		return p, e
	}
	if !stop.Success || len(stop.Code) == 0 {
		return p, fmt.Errorf("Binder停止が未成功")
	}
	for name, h := range stop.Code {
		path, e := absolute(root, name)
		if e != nil || !validSHA(h) || code[strings.ToLower(filepath.Clean(path))] != h {
			return p, fmt.Errorf("Binder停止所有code不足:%s", name)
		}
	}
	sourcePath, e := check(c.Source, base)
	if e != nil {
		return p, e
	}
	if e = decode(sourcePath, &p.Source, false, true); e != nil {
		return p, e
	}
	if e = validateSource(p.Source); e != nil {
		return p, e
	}
	ip, e := check(c.Index, base)
	if e != nil {
		return p, e
	}
	var index Index
	if e = decode(ip, &index, false, false); e != nil {
		return p, e
	}
	ids := run103.AllowedSessions()
	if index.Version != 1 || index.Stage != "full54" || len(index.Entries) != len(ids) {
		return p, fmt.Errorf("旧100全54台帳不正")
	}
	for i, row := range index.Entries {
		if row.Session != ids[i] || !validSHA(row.SHA) || row.Path == "" {
			return p, fmt.Errorf("旧100台帳集合/順序/参照不正")
		}
		if i < 2 {
			path, e := check(FileRef{row.Path, row.SHA}, filepath.Dir(ip))
			if e != nil {
				return p, e
			}
			p.Old[row.Session] = FileRef{path, row.SHA}
		}
	}
	for i, row := range p.Source.Cases {
		for _, ref := range []*FileRef{&row.Result, &row.Records} {
			path, e := check(*ref, filepath.Dir(sourcePath))
			if e != nil {
				return p, e
			}
			ref.Path = path
		}
		p.Source.Cases[i] = row
	}
	return p, nil
}

// run は停止Binderを逐次呼び新Tapeと互換QAだけを新規保存します。
//
// 引数: condition/SHA/root/exe/out(string)は固定入力と新規先です。
// 返り値: Completion/errorは結合完了又は明示失敗です。対称金融は実行しません。
func run(condition, SHA, root, exe, out string) (Completion, error) {
	result := Completion{Version: 1, Trial: 104, Stage: "first2", ConditionSHA: SHA, Cases: []CaseResult{}, Scope: "新Sourceを旧100判断時計へ結合。legacy/defaultのみ103最終16Book互換QA、経済採用0・全時点未実施"}
	p, e := prepare(condition, SHA, root, exe)
	if e != nil {
		return result, e
	}
	result.Before = p.Before
	result.Sessions = 2
	dir, e := absolute(root, out)
	if e != nil {
		return result, e
	}
	if _, e = os.Stat(dir); !os.IsNotExist(e) {
		return result, fmt.Errorf("既存出力先を拒否")
	}
	if e = os.MkdirAll(filepath.Dir(dir), 0700); e != nil {
		return result, e
	}
	if e = os.Mkdir(dir, 0700); e != nil {
		return result, e
	}
	for _, id := range run103.AllowedSessions()[:2] {
		cases, e := bindScene(id, p.Old[id], p.Source.Cases, dir)
		result.Cases = append(result.Cases, cases...)
		if e != nil {
			result.Error = id + ":" + e.Error()
			break
		}
	}
	result.After = map[string]string{}
	for path := range result.Before {
		h, e := run103.FileSHA(path)
		result.After[path] = h
		if e != nil && result.Error == "" {
			result.Error = e.Error()
		}
	}
	result.Unchanged = reflect.DeepEqual(result.Before, result.After)
	if !result.Unchanged && result.Error == "" {
		result.Error = "入力/code/binary前後差"
	}
	result.Success = result.Error == "" && len(result.Cases) == 6
	if e = writeNew(filepath.Join(dir, "完了.json"), result, false); e != nil {
		return result, e
	}
	if !result.Success {
		return result, fmt.Errorf("%s", result.Error)
	}
	return result, nil
}

// main はRoot固定条件なしでは対象データを開きません。
//
// 引数: CLIのcondition/condition-sha/outです。返り値: なし、失敗は終了1です。
func main() {
	var condition, SHA, out string
	flag.StringVar(&condition, "condition", "", "Root固定条件")
	flag.StringVar(&SHA, "condition-sha", "", "条件SHA")
	flag.StringVar(&out, "out", "", "存在しない新規先")
	flag.Parse()
	root, e := os.Getwd()
	if e == nil {
		for {
			a, ae := os.Stat(filepath.Join(root, "study"))
			b, be := os.Stat(filepath.Join(root, "scripts"))
			if ae == nil && be == nil && a.IsDir() && b.IsDir() {
				break
			}
			next := filepath.Dir(root)
			if next == root {
				e = fmt.Errorf("repo基準なし")
				break
			}
			root = next
		}
	}
	if e == nil {
		exe, x := os.Executable()
		e = x
		if e == nil {
			_, e = run(condition, SHA, root, exe, out)
		}
	}
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(1)
	}
}
