"""Source結合CLIの非市場人工と依存停止を新規記録する。"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parents[1]
ROOT = HERE.parents[1]


def sha(path: Path) -> str:
    """
    機能: コード又は小metadataの指紋を返す。
    引数: path(Path)は許可済みファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path: Path, value: dict) -> None:
    """
    機能: 新規JSONを上書きせず保存する。
    引数: path(Path)、value(dict)は出力と公開値。
    返り値: None。
    """
    with path.open("x", encoding="utf-8", newline="\n") as out:
        json.dump(value, out, ensure_ascii=False, indent=2)
        out.write("\n")


def main() -> None:
    """
    機能: 実施済み人工の生ログ・停止所有集合・新exeを結合する。
    引数: なし。
    返り値: None。市場SourceRecord/TapeやRaw/Nativeは読み込まない。
    """
    dependencies = {
        "work/104新Sourceと判断時計の結合案/停止.json": "e66adae009ff3edfa59b38dd22ffa07c48f83843f045080a4ede0045dab0fbf2",
        "work/104Source再形成CLIの準備_版2/停止.json": "ea208380d5b1e71f4370e9ed9a081d9858b4951c8d5eeb3221ca8e08e3b30e1a",
        "work/103多玉の一定利益保護/停止.json": "9e899ea0cbdab53c299925b7061165e832309ee7cba3187de80066774bddd88f",
        "work/103多玉の保護会計/停止.json": "e051a2401c8919835adfea52bf346d644707239fd030f0b13f101586b4c1d52b",
    }
    source_fingerprints: dict[str, str] = {}
    for name, expected in dependencies.items():
        assert sha(ROOT / name) == expected, name
        stopped = json.loads((ROOT / name).read_text(encoding="utf-8-sig"))
        owned = stopped.get("所有コードSHA256", stopped.get("所有SHA256", {}))
        assert owned, name
        for path, h in owned.items():
            assert sha(ROOT / path) == h, path
            source_fingerprints[path] = h
    artifact = "work/104新Sourceと判断時計の結合案/人工/停止版/合法空通知.json"
    assert sha(ROOT / artifact) == "453b8390eba1c7a3f9406ddbac8bebe82c21e7f21d43a461557cfdc9151c039b"
    log = HERE / "検査/Go人工.jsonl"
    events = [json.loads(line) for line in log.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    assert events[-1]["Action"] == "pass"
    tests = [e["Test"] for e in events if e["Action"] == "pass" and "Test" in e]
    assert len([name for name in tests if "/" not in name]) == 3
    proof = {
        "成功": True,
        "scope": "停止済み合法空通知codec人工。新規/Fill0。自然Source形成/市場/実first2は未実施。",
        "型人工": {"path": artifact, "SHA256": sha(ROOT / artifact)},
        "Goトップ": [name for name in tests if "/" not in name],
        "全pass名数": len(tests),
        "metadata拒否": 14,
        "legacy/default最終Book比較": 32,
        "金融Book除外": [],
        "全時点比較": False,
        "symmetric金融実行": 0,
        "その他": ["SourceRecord全型JSONL再読", "新Tape3mode保存", "既存出力拒否", "未知field/gzip破損拒否", "未固定条件の入力前拒否"],
        "Go人工ログ": {"path": log.relative_to(ROOT).as_posix(), "SHA256": sha(log)},
        "test/vet/build": {"test": 0, "vet": 0, "build": 0},
    }
    save(HERE / "検査/人工確認.json", proof)
    owned_names = ["main.go", "bind.go", "main_test.go", "codec_test.go", "go.mod", "go.sum", "README.md", "実行条件の雛形.json", "検査/停止を記録する.py"]
    owned = {(HERE / name).relative_to(ROOT).as_posix(): sha(HERE / name) for name in owned_names}
    exe = HERE / "検査/Source結合.exe"
    assert all(sha(ROOT / name) == value for name, value in source_fingerprints.items())
    stop = {
        "成功": True,
        "市場実行前": True,
        "module": "github.com/masayoshi4649/SessionTradeExecuter/sourcebindcli104",
        "所有コードSHA256": owned,
        "依存停止SHA256": dependencies,
        "停止元の所有指紋一致": source_fingerprints,
        "元停止/所有本文不変": True,
        "exe": {"path": exe.relative_to(ROOT).as_posix(), "SHA256": sha(exe)},
        "人工確認": {"path": (HERE / "検査/人工確認.json").relative_to(ROOT).as_posix(), "SHA256": sha(HERE / "検査/人工確認.json"), **proof},
        "Root条件": "未固定。固定条件/3FileRefs/全code/実行物検査後だけfirst2対象を開く。",
        "予定実Sourcefirst2": {"SHA256": "2dde982dc4c81ef45642ce110018657e5f7731317d6c01d053a4a28a1ef3dd3f", "由来": "Root通知。今回の停止作成では実完了の本文/出力データを展開していない。"},
        "実SourceRecord/Tape/Raw/CSV/旧Native本文読取": 0,
        "市場/金融経済採用/全54CLI": 0,
        "全時点市場比較": False,
        "既存金融/Source/配送/103正式編集": 0,
    }
    save(HERE / "停止.json", stop)
    print(json.dumps({"停止SHA256": sha(HERE / "停止.json"), "exeSHA256": sha(exe)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
