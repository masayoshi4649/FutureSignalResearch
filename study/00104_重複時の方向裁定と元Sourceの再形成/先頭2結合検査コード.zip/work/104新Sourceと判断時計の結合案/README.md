# 104 新Sourceと旧判断時計の純結合

市場実行・Raw/CSV/市場Native本文読取は0。Source再形成も本moduleでは行わない。`Bind(oldTape, allSourceRecords, mode)`で、停止104 CLIの公開全記録を旧97Tapeのquote/forceへ順に結び、gridと公表Contextはそのまま保持する。ScalarからSourceを生成しない。

SourceRecordはCLIのmain packageをimportできないため、record.goと同じJSON公開型をconsumer側に明示定義した。record.goは版2でも同体。Rootの上流成功receipt・mode・記録file SHAを市場wrapperで固定する工程は別で、本純関数のProofをSource再形成成功へ代用しない。

現在のrunnerの全callback順はactive methodごとmicro→mini。Night後半もPを残し、microP/miniP/microU/miniUの順。全ordinal/session/product/method/kindを確認し、両productのfresh Scalar11全値・FeaturesIndex・物理行を旧quoteへ一致させる。Forceはproduct×method別の直前quote.SourceLineへ結ぶ。Atだけのjoinをしない。

金融へ渡すのはmini Deltaだけ。Signal/Targets/Fill/配賦/Closes.Before/取消を元公開型のまま深く複写し、Closes-onlyも圧縮落ちさせない。旧RestoreBatchesとの全JSON往復が不一致なら拒否。legacy/defaultは旧mini全通知との全文差も拒否。symmetricは新通知を許すが、Sourceの正規性・全Ledger完結は上流と金融側の規範が別に必要。

旧Capabilitiesは公開型の互換性のため保持するが、今回の使用範囲は103のGate無し金融だけ。既存grid Contextを新Source由来の技法形成成功と呼ばない。旧TapeのProvenanceは新Tapeへ転載せず、旧TapeのJSON指紋と上流記録のJSON指紋を新しい出典として分離する。圧縮file自体のSHAは呼出側で別固定する。

今回のAPIは小型の全記録配列を受ける純関数。実市場の逐次JSONL読込・メモリ上限・条件／入力前後指紋・新規保存CLIは未実装で、ここから市場実行しない。小型人工の結果と停止範囲は停止.jsonへ記録する。

## 人工の完了範囲

5トップのGo人工・vet・buildが終了0。合法な空通知5イベントに対し、legacy/defaultそれぞれ103の全16口座・全時点JSON（計160口座時点）と最終32口座が除外0で一致した。mini実新規/Fillは0であり、非0経済効果の証拠ではない。micro通知はこのcodec人工では空の手製値で、micro会計の再現を証明しない。

ordinal/session/product/method/Scalar Index/物理行/ATR/Observation SHA/上流error/記録不足/Force直前行の11破損、同秒別行、P/Uの空P保持と直前行・順序不一致、Closes-only/Targets/Beforeの保持と独立copyを確認した。元Go型の非0人工はquote→同時計API Forceという市場timer外の呼出順を含むため、原本を直さず拒否した。非0Source→新Tape→103の全時点/最終同値は今回準備不足として残す。

`人工/停止版/合法空通知.json`は公開型codecの小さな入力。`old_tape`、`records`、`modes`を持つ。全Observationも手製で、SourceをScalarから生成したものではない。上流のSource形成成功は別に必要。

```powershell
Push-Location work/104新Sourceと判断時計の結合案
go test ./...
go vet ./...
go build ./...
Pop-Location
```

市場first2の別wrapperでは、上流の成功receipt・旧Tape台帳・本停止と全code/入力SHAを先に固定し、legacy/defaultの全mini通知同値と103の最終16口座全文を対照する。`runtime103.RunTape`はobserver無しで全原行の巨大Snapshotを避ける。`RunObserved`の全時点比較は小人工で確認済みだが、市場での実施を本証拠へ含めない。
