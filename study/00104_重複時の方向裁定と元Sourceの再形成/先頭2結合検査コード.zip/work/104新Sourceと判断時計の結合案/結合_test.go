package sourceclock104

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"testing"

	runtime103 "github.com/masayoshi4649/SessionTradeExecuter/delayedreplay103"
	"github.com/masayoshi4649/SessionTradeExecuter/internal/strategy"
	tape "github.com/masayoshi4649/SessionTradeExecuter/lighttape97"
	actual "github.com/masayoshi4649/SessionTradeExecuter/minichart"
	finance "github.com/masayoshi4649/SessionTradeExecuter/minidelayed103"
	native "github.com/masayoshi4649/SessionTradeExecuter/mininative"
)

// emptyDelta はcodec人工だけの空通知を型どおり作ります。
//
// 引数: at(float64)、origin(string)、line(int64)は人工出典です。
// 返り値: native.StepResultは空配列を保持する手製値。Source生成ではありません。
func emptyDelta(at float64, origin string, line int64) native.StepResult {
	return native.StepResult{At: at, Origin: origin, SourceLine: line, Signals: []native.SignalRecord{}, Fills: []native.FillRecord{}, Cancellations: []native.Cancellation{}, Closes: []native.CloseNotice{}}
}

// recordsFor は既存人工のmini通知と全Observationを公開記録型へ配線します。
//
// 引数: t(*testing.T)、input(Tape)、full(map)は人工原本と全Observationです。
// 返り値: []SourceRecordは手製codec値。micro通知は空の型器具で同値未測定です。
func recordsFor(t *testing.T, input tape.Tape, full map[int64]native.Observation) []SourceRecord {
	t.Helper()
	records := []SourceRecord{}
	last := map[string]int64{}
	for _, e := range input.Events {
		if e.Kind == "grid" {
			continue
		}
		batches, err := tape.RestoreBatches(e, last)
		if err != nil {
			t.Fatal(err)
		}
		for _, b := range batches {
			for _, product := range []string{"NK225micro", "NK225mini"} {
				r := SourceRecord{Ordinal: len(records) + 1, Session: input.Session.ID, Kind: e.Kind, Method: b.Method, Product: product, Delta: b.Delta}
				if product == "NK225micro" {
					r.Delta = emptyDelta(b.Delta.At, b.Delta.Origin, b.Delta.SourceLine)
				}
				if e.Kind == "quote" {
					o, ok := full[e.Quote.SourceLine]
					if !ok {
						t.Fatal("全Observationの人工出典不足")
					}
					q, err := tape.ProjectQuote(o, e.Quote.SourceLine)
					if err != nil {
						t.Fatal(err)
					}
					r.Scalar = &q
					data, _ := json.Marshal(o)
					h := sha256.Sum256(data)
					r.ObservationSHA = hex.EncodeToString(h[:])
				}
				records = append(records, r)
			}
		}
	}
	return records
}

// loadArtificial は停止済み小型人工だけを読みます。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: Tape/mapは金融人工の公開入力。Raw/市場Nativeは開きません。
func loadArtificial(t *testing.T) (tape.Tape, map[int64]native.Observation) {
	t.Helper()
	name := "方向1_未知ATRfalse.json"
	var value struct {
		Tape tape.Tape `json:"tape"`
	}
	body, e := os.ReadFile(filepath.Join("..", "103多玉の一定利益保護", "人工", "停止版", name))
	if e != nil {
		t.Fatal(e)
	}
	if e = json.Unmarshal(body, &value); e != nil {
		t.Fatal(e)
	}
	var source struct {
		Steps []struct {
			Observation native.Observation `json:"observation"`
			Line        int64              `json:"source_line"`
		} `json:"steps"`
	}
	body, e = os.ReadFile(filepath.Join("..", "103多玉の保護会計", "人工", "停止版", name))
	if e != nil {
		t.Fatal(e)
	}
	if e = json.Unmarshal(body, &source); e != nil {
		t.Fatal(e)
	}
	full := map[int64]native.Observation{}
	for _, s := range source.Steps {
		full[s.Line] = s.Observation
	}
	return value.Tape, full
}

// legalEmpty はForce→grid→同秒別原行の合法空通知だけを作ります。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: Tape/mapは公開型の手製codec入力。自然Source形成ではありません。
func legalEmpty(t *testing.T) (tape.Tape, map[int64]native.Observation) {
	t.Helper()
	old := tape.Tape{Version: 1, Scope: "合法位相の空通知codec人工", Session: actual.Session{ID: "人工_Day", Kind: "Day", Start: 900, End: 1800, ForceClose: 1200}, Capabilities: tape.Capabilities()}
	full := map[int64]native.Observation{}
	for i, at := range []float64{1199, 1200, 1200} {
		o := native.Observation{Reference: "NK225", Time: at, Received: at, Index: int64(i), Last: 100, Bid: 95, Ask: 105, QuoteOK: true}
		full[int64(10+i)] = o
		q, _ := tape.ProjectQuote(o, int64(10+i))
		if i == 1 {
			old.Events = append(old.Events, tape.TapeEvent{Kind: "force", At: 1200, Methods: []string{"D164_15"}}, tape.TapeEvent{Kind: "grid", At: 1200})
		}
		old.Events = append(old.Events, tape.TapeEvent{Kind: "quote", At: at, Quote: &q, Methods: []string{"D164_15"}})
	}
	for i := range old.Events {
		old.Events[i].Ordinal = i + 1
	}
	return old, full
}

// TestControlAllPoints はminiのlegacy/default結合を103全16口座へ同じ順で配送します。
//
// 引数: t(*testing.T)は小型公開型の試験器です。
// 返り値: ありません。全時点/最終JSONは除外0。自然Source再形成は範囲外です。
func TestControlAllPoints(t *testing.T) {
	old, full := legalEmpty(t)
	records := recordsFor(t, old, full)
	before, _ := json.Marshal(old)
	rb, _ := json.Marshal(records)
	states := [][]byte{}
	baseline, e := runtime103.RunObserved(old, func(_ tape.TapeEvent, b map[string]finance.ActualResult) error {
		x, _ := json.Marshal(b)
		states = append(states, x)
		return nil
	})
	if e != nil {
		t.Fatal(e)
	}
	for _, mode := range []string{"legacy", "default"} {
		joined, p, e := Bind(old, records, mode)
		if e != nil {
			t.Fatal(e)
		}
		if !p.NotificationsEqualOld || p.SourceFormedHere || p.FinancialExecutedHere || p.MiniCalls == 0 || p.Grids == 0 {
			t.Fatal("結合scope")
		}
		n := 0
		result, e := runtime103.RunObserved(joined, func(_ tape.TapeEvent, b map[string]finance.ActualResult) error {
			x, _ := json.Marshal(b)
			if n >= len(states) || !bytes.Equal(x, states[n]) {
				t.Fatalf("%s event%d 全16時点JSON差", mode, n+1)
			}
			n++
			return nil
		})
		if e != nil {
			t.Fatal(e)
		}
		a, _ := json.Marshal(result.Books)
		b, _ := json.Marshal(baseline.Books)
		if n != len(states) || !bytes.Equal(a, b) || len(result.Books) != 16 {
			t.Fatal("最終16全文差")
		}
		// ----------------------------------------
		// 旧gridとSource側のslice/Targetsを新Tapeから書き換えられない。
		for i := range joined.Events {
			if joined.Events[i].Quote != nil {
				joined.Events[i].Quote.Last++
			}
			for j := range joined.Events[i].NonEmpty {
				d := &joined.Events[i].NonEmpty[j].Delta
				for k := range d.Signals {
					if len(d.Signals[k].Signal.Targets) > 0 {
						d.Signals[k].Signal.Targets[0].Quantity++
					}
				}
			}
		}
		x, _ := json.Marshal(old)
		y, _ := json.Marshal(records)
		if !bytes.Equal(x, before) || !bytes.Equal(y, rb) {
			t.Fatal("浅copy共有")
		}
	}
	if dir := os.Getenv("JOIN104_EXPORT_DIR"); dir != "" {
		if e := os.MkdirAll(dir, 0700); e != nil {
			t.Fatal(e)
		}
		value := struct {
			Scope   string         `json:"scope"`
			Old     tape.Tape      `json:"old_tape"`
			Records []SourceRecord `json:"records"`
			Modes   []string       `json:"modes"`
			Points  int            `json:"events"`
		}{
			"手製合法空通知。microは空codec型。全Observationも手製、自然Source/非0金融は未測定", old, records, []string{"legacy", "default"}, len(states)}
		body, e := json.MarshalIndent(value, "", "  ")
		if e != nil {
			t.Fatal(e)
		}
		f, e := os.OpenFile(filepath.Join(dir, "合法空通知.json"), os.O_CREATE|os.O_EXCL|os.O_WRONLY, 0600)
		if e != nil {
			t.Fatal(e)
		}
		if _, e = f.Write(body); e != nil {
			t.Fatal(e)
		}
		if e = f.Close(); e != nil {
			t.Fatal(e)
		}
	}
}

// TestMismatchReject はAtだけでは識別できない出典と通知順を拒否します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。元人工を編集せず各一破損を独立copyへ注入します。
func TestMismatchReject(t *testing.T) {
	old, full := legalEmpty(t)
	source := recordsFor(t, old, full)
	changes := []func(*[]SourceRecord){
		func(r *[]SourceRecord) { (*r)[0].Ordinal++ }, func(r *[]SourceRecord) { (*r)[0].Session = "他場" },
		func(r *[]SourceRecord) { (*r)[0].Product = "NK225mini" }, func(r *[]SourceRecord) { (*r)[0].Method = "U165_03" },
		func(r *[]SourceRecord) { (*r)[0].Scalar.Index++ }, func(r *[]SourceRecord) { (*r)[0].Scalar.SourceLine++ },
		func(r *[]SourceRecord) { (*r)[0].Scalar.ATR++ }, func(r *[]SourceRecord) { (*r)[0].ObservationSHA = "不足" },
		func(r *[]SourceRecord) { (*r)[0].Error = "上流失敗" }, func(r *[]SourceRecord) { *r = (*r)[:len(*r)-1] },
		func(r *[]SourceRecord) {
			for i := range *r {
				if (*r)[i].Kind == "force" {
					(*r)[i].Delta.SourceLine++
					return
				}
			}
		},
	}
	for i, change := range changes {
		x, e := clone(reflect.ValueOf(source))
		if e != nil {
			t.Fatal(e)
		}
		r := x.Interface().([]SourceRecord)
		change(&r)
		if _, _, e = Bind(old, r, "legacy"); e == nil {
			t.Fatalf("破損%dを受理", i)
		}
	}
}

// TestAPICallOrderOutsideMarket は元API人工を市場timer順へ偽って直しません。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。既存非0人工のquote→同時計API Forceは市場位相外として拒否します。
func TestAPICallOrderOutsideMarket(t *testing.T) {
	old, full := loadArtificial(t)
	if _, _, e := Bind(old, recordsFor(t, old, full), "legacy"); e == nil {
		t.Fatal("市場位相外のAPI人工を成功扱い")
	}
}

// TestSameClockAndCloses は同秒別物理行/位相とCloses-onlyの保存を確認します。
//
// 引数: t(*testing.T)は小型codec試験器です。
// 返り値: ありません。手製通知の保存だけでSource正規性/金融成功を主張しません。
func TestSameClockAndCloses(t *testing.T) {
	old := tape.Tape{Version: 1, Scope: "同秒codec人工", Session: actual.Session{ID: "人工_Day", Kind: "Day", Start: 900, End: 6000, ForceClose: 5400}, Capabilities: tape.Capabilities()}
	full := map[int64]native.Observation{}
	for i, at := range []float64{1199, 1200, 1200} {
		o := native.Observation{Reference: "NK225", Time: at, Received: at, Index: int64(i), Last: 100, Bid: 95, Ask: 105, QuoteOK: true, ATR: 20}
		o.E01.ATR = 20
		full[int64(10+i)] = o
		q, _ := tape.ProjectQuote(o, int64(10+i))
		if i == 1 {
			old.Events = append(old.Events, tape.TapeEvent{Kind: "force", At: 1200, Methods: []string{"D164_15"}}, tape.TapeEvent{Kind: "grid", At: 1200})
		}
		old.Events = append(old.Events, tape.TapeEvent{Kind: "quote", At: at, Quote: &q, Methods: []string{"D164_15"}})
	}
	for i := range old.Events {
		old.Events[i].Ordinal = i + 1
	}
	records := recordsFor(t, old, full)
	if _, _, e := Bind(old, records, "legacy"); e != nil {
		t.Fatal(e)
	}
	last := len(records) - 1
	records[last].Scalar.SourceLine = 11
	if _, _, e := Bind(old, records, "legacy"); e == nil {
		t.Fatal("同秒別行を混同")
	}
	records = recordsFor(t, old, full)
	records[last].Delta.Closes = []native.CloseNotice{{ID: "手製notice", ReferenceID: "手製hold", Before: 3, Quantity: 1, Reason: "codecのみ"}}
	only, _, err := Bind(old, records, "symmetric")
	if err != nil || len(only.Events[len(only.Events)-1].NonEmpty) != 1 {
		t.Fatal("Closes-only圧縮落ち", err)
	}
	records[last].Delta.Signals = []native.SignalRecord{{Signal: native.Signal{ID: "手製close", Action: "close", Side: -1, Quantity: 1, Targets: []strategy.LotTarget{{ID: "手製hold", Quantity: 1}}}}}
	joined, p, e := Bind(old, records, "symmetric")
	if e != nil {
		t.Fatal(e)
	}
	if p.NotificationsEqualOld || len(joined.Events[len(joined.Events)-1].NonEmpty) != 1 {
		t.Fatal("Closes-only圧縮落ち")
	}
	batches, e := tape.RestoreBatches(joined.Events[len(joined.Events)-1], map[string]int64{})
	if e != nil || batches[0].Delta.Closes[0].Before != 3 {
		t.Fatal("Before欠落", e)
	}
	if _, _, e = Bind(old, records, "default"); e == nil {
		t.Fatal("対照通知差を許容")
	}
	joined.Events[len(joined.Events)-1].NonEmpty[0].Delta.Signals[0].Signal.Targets[0].Quantity++
	if records[last].Delta.Signals[0].Signal.Targets[0].Quantity != 1 {
		t.Fatal("Targetsの浅copy共有")
	}
}

// TestActivePU はPを残す順序・空通知と各methodのForce直前行を確認します。
//
// 引数: t(*testing.T)は試験器です。
// 返り値: ありません。P/Uの公開型配線だけで自然Sourceの経済効果は未測定です。
func TestActivePU(t *testing.T) {
	old := tape.Tape{Version: 1, Scope: "P/U空通知の位相人工", Session: actual.Session{ID: "人工_Night", Kind: "Night", Start: 900, End: 6000, ForceClose: 5400, USOpen: 3000}, Capabilities: tape.Capabilities()}
	full := map[int64]native.Observation{}
	for i, at := range []float64{2099, 3900} {
		o := native.Observation{Reference: "NK225", Time: at, Received: at, Index: int64(i), Last: 100, Bid: 95, Ask: 105, QuoteOK: true}
		line := int64(10 + i)
		full[line] = o
		q, _ := tape.ProjectQuote(o, line)
		methods := []string{"P164_06"}
		if i == 1 {
			methods = append(methods, "U165_03")
		}
		old.Events = append(old.Events, tape.TapeEvent{Kind: "quote", At: at, Quote: &q, Methods: methods})
		if i == 0 {
			old.Events = append(old.Events, tape.TapeEvent{Kind: "force", At: 2100, Methods: []string{"P164_06"}}, tape.TapeEvent{Kind: "grid", At: 2100})
		}
	}
	old.Events = append(old.Events, tape.TapeEvent{Kind: "force", At: 5400, Methods: []string{"P164_06", "U165_03"}})
	for i := range old.Events {
		old.Events[i].Ordinal = i + 1
	}
	records := recordsFor(t, old, full)
	joined, _, e := Bind(old, records, "legacy")
	if e != nil {
		t.Fatal(e)
	}
	if !reflect.DeepEqual(joined.Events[3].Methods, []string{"P164_06", "U165_03"}) {
		t.Fatal("空Pを脱落")
	}
	records[len(records)-1].Delta.SourceLine = 10
	if _, _, e = Bind(old, records, "legacy"); e == nil {
		t.Fatal("Uの直前物理行差を許容")
	}
	records = recordsFor(t, old, full)
	records[5].Method = "U165_03"
	if _, _, e = Bind(old, records, "legacy"); e == nil {
		t.Fatal("P/U同時計順の差を許容")
	}
}
