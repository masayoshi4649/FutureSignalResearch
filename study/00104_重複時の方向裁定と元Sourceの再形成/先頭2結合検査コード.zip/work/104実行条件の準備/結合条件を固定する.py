"""104の先頭2場接続と旧103最終会計対照の条件を固定する。"""

import hashlib
import json
import os
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parents[2]
STUDY = ROOT / "study/00104_重複時の方向裁定と元Sourceの再形成"


def sha(path: Path) -> str:
    """
    機能: コードまたは固定入力の内容指紋を求める。
    引数: path(Path)は実在ファイル。
    返り値: strはSHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path: Path) -> dict:
    """
    機能: UTF-8 JSONを読む。
    引数: path(Path)は参照元。
    返り値: dictは保存値。
    """
    return json.loads(path.read_text(encoding="utf-8-sig"))


def main() -> None:
    """
    機能: Source先頭2成功、旧Tape台帳、純結合停止と全実依存を固定する。
    引数: なし。最終会計の互換QAだけを固定し、対称Sourceの経済評価はしない。
    返り値: None。新条件と小コードZIP/固定証拠を保存する。市場本文はまだ読まない。
    """
    target = STUDY / "先頭2結合条件.json"
    archive_path = STUDY / "先頭2結合検査コード.zip"
    assert not target.exists() and not archive_path.exists()
    code = {}
    def add(path: Path, expected: str | None = None) -> None:
        """
        機能: 正規化した実pathを重複なくコード集合へ追加する。
        引数: path(Path)、expected(str|None)は実位置と既存固定指紋。
        返り値: None。既存指紋差があれば拒否する。
        """
        path = path.resolve()
        value = sha(path)
        if expected is not None:
            assert value == expected, str(path)
        try:
            name = os.path.relpath(path, ROOT).replace("\\", "/")
        except ValueError:
            name = path.as_posix()
        assert name not in code or code[name] == value
        code[name] = value
    for path in [STUDY / "Source条件.json", ROOT / "study/00103_元の多玉と数量を保つ一定利益後の追尾/条件.json"]:
        for name, expected in read(path)["code_sha256"].items():
            add(Path(name) if Path(name).is_absolute() else ROOT / name, expected)
    stop_paths = [ROOT / "work/104新Sourceと判断時計の結合案/停止.json", ROOT / "work/104Source結合の実行/停止.json"]
    new_files = {Path(__file__).resolve()}
    for path in stop_paths:
        add(path)
        new_files.add(path)
        stop = read(path)
        assert stop["成功"]
        for name, expected in stop["所有コードSHA256"].items():
            actual = ROOT / name
            add(actual, expected)
            new_files.add(actual.resolve())
    assert sha(stop_paths[0]) == "e66adae009ff3edfa59b38dd22ffa07c48f83843f045080a4ede0045dab0fbf2"
    assert sha(stop_paths[1]) == "e795c61557f8af1a2f54f46dc2908ce145c62263e20b1b8e383752bf80e9ebbd"

    # ----------------------------------------
    # 新CLIのgo listで実使用ファイルを独立列挙し、旧二条件の和だけに頼らない。
    metadata = ROOT / "work/104実行条件の準備/結合Go依存.json"
    raw = metadata.read_text(encoding="utf-8-sig")
    decoder = json.JSONDecoder()
    offset = 0
    packages = 0
    fields = ["GoFiles", "CgoFiles", "CFiles", "CXXFiles", "MFiles", "HFiles", "FFiles", "SFiles", "SwigFiles", "SwigCXXFiles", "SysoFiles", "EmbedFiles"]
    while offset < len(raw):
        while offset < len(raw) and raw[offset].isspace():
            offset += 1
        if offset == len(raw):
            break
        package, offset = decoder.raw_decode(raw, offset)
        assert not package.get("Error")
        packages += 1
        for field in fields:
            for name in package.get(field, []):
                add(Path(package["Dir"]) / name)
        module = package.get("Module", {})
        for item in [module, module.get("Replace", {})]:
            if item.get("GoMod"):
                add(Path(item["GoMod"]))
    add(metadata)
    add(Path(__file__))

    def ref(path: Path, expected: str | None = None) -> dict:
        """
        機能: 正式条件dirからのFileRefを作る。
        引数: path(Path)、expected(str|None)は実位置と既知指紋。
        返り値: dictは相対pathとSHA256。
        """
        value = sha(path)
        assert expected is None or expected == value
        return {"path": os.path.relpath(path, STUDY).replace("\\", "/"), "sha256": value}
    condition = {"version": 1, "trial": 104, "fixed": True, "stage": "first2",
                 "source_first2": ref(ROOT / "work/104Source市場再生/先頭2場/完了.json", "2dde982dc4c81ef45642ce110018657e5f7731317d6c01d053a4a28a1ef3dd3f"),
                 "old100_tape_index": ref(ROOT / "study/00100_費用後利益化の前後で保護を分ける/正式54Tape台帳.json", "4db6812dda91ae4235d15ce5619c19a7dffa305f24ec3f577332d8665b49610f"),
                 "binder_stop": ref(stop_paths[0]),
                 "binary": ref(ROOT / "work/104Source結合の実行/検査/Source結合.exe", "50a0888e29d2f75cc4676fa16832bb896a796acbcc9a173eb1cb183246cab780"),
                 "code_sha256": code, "compatibility_103": "final"}
    target.write_text(json.dumps(condition, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with zipfile.ZipFile(archive_path, "x", compression=zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(new_files):
            info = zipfile.ZipInfo(path.relative_to(ROOT).as_posix(), date_time=(2026, 11, 9, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())
    for name, expected in code.items():
        path = Path(name) if Path(name).is_absolute() else ROOT / name
        assert sha(path) == expected
    proof = {"成功": True, "市場実行前": True, "scope": "先頭2の新Source→旧時計結合とlegacy/default旧103最終16互換QA。全時点Snapshotと対称Sourceの金融は実行しない",
             "条件SHA256": sha(target), "code数": len(code), "新CLI実使用package数": packages,
             "小追加ZIP": {"path": archive_path.name, "sha256": sha(archive_path), "収録数": len(new_files)},
             "依存本文": "Source再現コード.zipと旧103再現コード.zipを参照。stdlib/toolchainは指紋参照。",
             "Source再形成": False, "金融の経済採用": 0, "互換全時点Snapshot": False}
    (STUDY / "先頭2結合実行前固定.json").write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"成功": True, "条件SHA256": sha(target), "code数": len(code)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
