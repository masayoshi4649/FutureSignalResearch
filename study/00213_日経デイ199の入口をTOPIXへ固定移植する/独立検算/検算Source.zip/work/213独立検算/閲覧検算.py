"""生成済み全12CSVを型付き入力と独立に比較する。"""
from pathlib import Path
from decimal import Decimal
import json
import csv
import hashlib


def main() -> None:
    """
    機能：全候補のCSVを再読し、候補別行数・空欄・値・日次の収支加減算を照合する。
    引数：なし。
    返り値：None。閲覧確認票を作る。
    """
    here=Path(__file__).resolve().parent
    root=here.parents[1]
    study=next((root/'study').glob('00213*'))
    base=next((root/'outputs').glob('00213*'))
    done={}
    for path in [root/'work/213集計/CSV入力.json',study/'日経取得通知の対照/型付き入力.json']:
        typed=json.loads(path.read_bytes())
        for source,table in typed['tables'].items():
            for cid in sorted(set(r[0] for r in table['rows'])):
                f=base/cid.replace(':','_',1)/(typed['tableNames'][source]+'.csv')
                expected=[r for r in table['rows'] if r[0]==cid]
                with f.open(encoding='utf-8-sig',newline='') as stream: read=list(csv.reader(stream))
                assert read[0]==table['headers'] and len(read)==len(expected)+1
                for r,v in zip(read[1:],expected,strict=True):
                    assert len(r)==len(v)
                    for found,exp in zip(r,v,strict=True):
                        if exp is None:assert found==''
                        elif isinstance(exp,str):assert found==exp
                        else:assert abs(Decimal(found)-Decimal(str(exp)))<=Decimal('0.00000001')
                    h=table['headers']
                    assert Decimal(r[h.index('既知利益円')])-Decimal(r[h.index('既知損失円')])==Decimal(r[h.index('既知収支円')])
                done[f.relative_to(base).as_posix()]={'データ行':len(expected),'セル':len(read)*len(read[0]),
                                                     '指紋':hashlib.sha256(f.read_bytes()).hexdigest()}
    assert len(done)==12
    record={'CSV数':len(done),'全セル':sum(v['セル'] for v in done.values()),'ファイル':done,'全件照合':True}
    (here/'CSV照合.json').write_text(json.dumps(record,ensure_ascii=False,indent=1)+'\n',encoding='utf8')
    print(record['CSV数'],record['全セル'])


if __name__=='__main__':
    main()
