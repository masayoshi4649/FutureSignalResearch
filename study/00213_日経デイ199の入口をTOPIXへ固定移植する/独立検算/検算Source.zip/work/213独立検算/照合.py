"""試行213の金融表・同時刻の両指数・日経建玉群を、生産モジュールから独立に照合する。"""
from collections import Counter, defaultdict
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path
from statistics import median, mean
import csv
import gzip
import hashlib
import json
import math
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
STUDY=next((ROOT/'study').glob('00213*'))
JST=timezone(timedelta(hours=9))
DT=np.dtype([('t','<f8'),('line','<i8'),('last','<f8'),('bid','<f8'),('ask','<f8'),('ok','<u8')])

# ----------------------------------------
def read(p:Path) -> object:
    """
    機能：生データまたは圧縮結果を展開して読む。
    引数：p（Path）はJSONの位置。
    返り値：objectは展開値。
    """
    return json.loads(gzip.decompress(p.read_bytes()) if p.suffix=='.gz' else p.read_bytes())


# ----------------------------------------
def check_leg(book:np.ndarray, t:dict, cut:float, multiplier:int) -> None:
    """
    機能：取得価格・利確/損切の初回到達と期限/強制の優先原行を原板配列から照合する。
    引数：book（np.ndarray）、t（dict）、cut（float）、multiplier（int）はポイント倍率。
    返り値：None。
    """
    entry=t['entry_index']
    side=t['side']
    prices=book['bid' if side==0 else 'ask']; times=book['t']
    assert t['entry_price']==book['ask' if side==0 else 'bid'][entry] and book['ok'][entry]
    assert t['entry_time']==times[entry] and t['entry_line']==book['line'][entry]
    horizon= t['entry_time']+60*int(t['horizon'][1:]) if t['horizon']!='SESSION' else math.inf
    valid=np.flatnonzero(book['ok'])
    def first(at:float, latest:float) -> int:
        """
        機能：時計・期限・参加行に適合する最初の正常板を取る。
        引数：at/latest（float）は検索時刻と期限。
        返り値：intは原行添字または番兵。
        """
        idx=valid[(valid>entry)&(times[valid]>=at)&(times[valid]<=latest)]
        return int(idx[0]) if len(idx) else len(book)
    normal=first(horizon,min(cut,horizon+30))
    forced=first(cut-59,cut)
    close=min(normal,forced); ce=times[close] if close<len(times) else cut
    if ce>horizon+30:
        close=len(book)
    observe_deadline=min(horizon,times[close] if close<len(times) else cut)
    # ----------------------------------------
    # 観測できた区間を前方に辿り、日経179で同規則の異常板・価格時計切断を識別する。
    prev=entry
    last=entry
    gap=len(book)
    for i in range(entry+1,min(len(book),int(np.searchsorted(times,cut,'right'))+1)):
        if times[last]<observe_deadline and times[i]-times[last]>300 or times[prev]<observe_deadline and times[i]-times[prev]>300:
            gap=i
            break
        if book['ok'][i]:
            prev=i
        last=i
        if times[last]>=observe_deadline and times[prev]>=observe_deadline:
            break
    mark_end=min(int(np.searchsorted(times,min(horizon,cut),'right')),close+1,gap)
    change=(1 if side==0 else -1)*(prices[entry+1:mark_end]-t['entry_price'])
    touch=np.flatnonzero(book['ok'][entry+1:mark_end] & (abs(change)>=t['width']))
    expected=int(touch[0]+entry+1) if len(touch) else close
    if expected>=min(gap,len(book)):
        assert t['net'] is None and t['exit_index']==-1
        return
    assert t['exit_index']==expected and t['exit_time']==times[expected]<=cut
    pnl=(1 if side==0 else -1)*(float(prices[expected])-t['entry_price'])
    assert t['exit_line']==book['line'][expected] and t['exit_price']==prices[expected]
    assert t['gross']==pnl*multiplier
    assert abs(t['net']-(pnl*multiplier-(1077 if multiplier==100 else 583.6)))<1e-7
    assert t['label']==((1 if pnl>0 else -1) if len(touch) else 0)


# ----------------------------------------
def main() -> None:
    """
    機能：固定出力に対するセッション・群・比較の独立検算と指紋を保存する。
    引数：なし。
    返り値：None。
    """
    files=sorted((STUDY/'金融正本').glob('*.gz'))
    stats=read(STUDY/'成績.json')
    sync=read(STUDY/'同期照合の明細.json.gz')
    ref=read(STUDY/'同期照合の集計.json')
    typed=read(ROOT/'work/213集計/CSV入力.json')
    old=next((ROOT/'study').glob('00199_*'))
    nk=[]
    for p in [*old.glob('保存金融/*02__C0_IFD.json.gz'),*old.glob('追加二場/保存金融/*02__C0_IFD.json.gz')]:
        l=read(p)['ledger']
        nk.extend([{k:v[i] for k,v in l.items()} for i,s in enumerate(l['scene']) if s.endswith('Day')])
    result={'旧42日':{},'取得群':{},'同期':{},'原行':{},'入力指紋':{}}
    by=defaultdict(list)
    for name in files:
        pk=read(name); accounts=pk['取得'];dates=sorted(pk['監査']); cid=name.name.removesuffix('.json.gz').replace('_',':',1)
        assert len(dates)==43
        tab=[dict(zip(typed['tables']['デイ']['headers'],r)) for r in typed['tables']['デイ']['rows'] if r[0]==cid]
        assert len(tab)==len(dates) and len({r['セッション'] for r in tab})==43
        for date,row in zip(dates,tab):
            trades=[a for a in accounts if a['scene']==date]
            known=[r['net'] for r in trades if r['net'] is not None]
            assert row['建玉回数']==len(trades) and row['未知件数']==len(trades)-len(known)
            assert abs(sum(known)-row['既知収支円'])<1e-7
            assert abs(sum(v for v in known if v>0)-row['既知利益円'])<1e-7
            assert abs(sum(-v for v in known if v<0)-row['既知損失円'])<1e-7
            for a,b in zip(trades,trades[1:]):
                assert a['exit_time'] is not None and a['exit_time']<b['request_time']<=b['entry_time']
        for span,ds in [('旧42日',dates[:-1]),('全43日',dates),('追加11月18日',dates[-1:])]:
            tr=[a for a in accounts if a['scene'] in ds];k=[a['net'] for a in tr if a['net'] is not None]; ss=stats[cid][span]
            day={d:[a['net'] for a in tr if a['scene']==d] for d in ds}
            sums=[sum(x) for x in day.values() if None not in x]
            unknown=len(tr)-len(k);u_days=len(ds)-len(sums)
            assert len(tr)==ss['取得'] and unknown==ss['未知'] and len([1 for v in day.values() if v])==ss['参加場']
            for lo,sign in [('lower',-math.inf),('upper',math.inf)]:
                for key,items,u in [('建玉中央値',k,unknown),('場中央値',sums,u_days)]:
                    m=median(items+[sign]*u)
                    assert abs(ss[key][lo]-m)<1e-7
            holds=sum(t['confirmed_until']-t['entry_time'] for t in tr)
            assert abs(holds/(24300*len(ds))-ss['保有率下限'])<1e-12
            assert abs(sum(k)-ss['収支'])<1e-7
            assert abs(sum(v for v in k if v>0)-ss['利益'])<1e-7 and abs(sum(-v for v in k if v<0)-ss['損失'])<1e-7
            assert abs(sum(a['gross'] for a in tr if a['gross'] is not None)-ss['費用前'])<1e-7
            assert Counter(a['label'] for a in tr)==Counter({i:ss[n] for i,n in [(1,'順'),(-1,'逆'),(0,'未到達'),(2,'不足')]})
            if span=='旧42日':
                result[span][cid]={k:ss[k] for k in ('取得','未知','収支','利益','損失','参加場','費用前')}
        for t in accounts: by[(t['scene'],'TOPIX')].append(t)
        if cid.startswith('213:03'):
            tp=[t for t in accounts if t['scene'] in dates[:-1]]
    for origin,tr in [('NK225',nk),('TOPIX',tp)]:
        pre=[t for t in tr if datetime.fromtimestamp(t['entry_time'],JST).hour==8]
        long=[t for t in tr if t['added'] and t['origin']!=2]
        result['取得群'][origin]={'寄付前件数':len(pre),'寄付前収支':round(sum(r['net'] for r in pre),1),
                                 'LC件数':len(long),'LC収支':round(sum(r['net'] for r in long),1),
                                 '重複件数':sum(r in long for r in pre)}
        signature=lambda row:(row['scene'],row['entry_time'],row['side'],row['width']*(20 if origin=='TOPIX' else 1),row['horizon'])
        assert Counter(signature(t) for t in tr)==Counter((t['場'],t['通知'],t['側'],t['日経表記幅'],t['期限']) for t in sync[origin])
        complete=[p for p in sync[origin] if all(p[x] and p[x]['net'] is not None for x in ('NK225','TOPIX'))]
        assert len(complete)==ref[origin]['両側確定']
        for sym,mult in [('NK225',100),('TOPIX',1000)]:
            for field,label in [('net','平均費用後幅比'),('gross','平均費用前幅比')]:
                ratio=mean(p[sym][field]/mult/p[sym]['width'] for p in complete)
                assert abs(ratio-ref[origin][sym][label])<1e-12
            for p in sync[origin]:
                by[p['場'],sym].append((p,sym))
        result['同期'][origin]={'通知':len(tr),'両側既知':len(complete),'TOPIX費用後幅比':ref[origin]['TOPIX']['平均費用後幅比']}
    manifests={'NK225':[next((ROOT/'inputs').glob(s)) for s in ('00163*/価格索引/manifest.json','00167*/原板数値索引/manifest.json','00180*/原板数値索引/manifest.json','00194*/NK225/原板数値索引/manifest.json')],
               'TOPIX':[ROOT/'work/今回移植/原行索引/manifest.json']}
    for symbol,ms in manifests.items():
        inspected,legs,missing=0,0,0
        for mp in ms:
            for row in read(mp)['scenes']:
                s=row['session']
                if not by[s,symbol]:continue
                fn=mp.parent/row['index']['path'];raw=fn.read_bytes()
                assert hashlib.sha256(raw).hexdigest()==row['index']['sha256']
                buf=gzip.decompress(raw)
                assert buf[:8]==b'NQIDX163' and len(buf)==8+48*row['rows']
                book=np.frombuffer(buf,DT,offset=8)
                cut=datetime.fromisoformat(s[:10]).replace(hour=15,minute=30,tzinfo=JST).timestamp()
                valid=np.flatnonzero(book['ok'])
                seen=set()
                for item in by[s,symbol]:
                    if isinstance(item,tuple):
                        p,_=item;cell=p[symbol]
                        ex=valid[(book['t'][valid]>=p['通知']+1)&(book['t'][valid]<min(p['通知']+30,cut-60))]
                        if cell is None:
                            assert not len(ex)
                            missing+=1;continue
                        assert len(ex) and ex[0]==cell['entry_index']
                    else:cell=item
                    key=(cell['entry_index'],cell['side'],cell['width'],cell['horizon'])
                    legs+=1
                    if key not in seen:
                        check_leg(book,cell,cut,100 if symbol=='NK225' else 1000)
                        seen.add(key);inspected+=1
        result['原行'][symbol]={'全建玉照合':legs,'異なる決済セル照合':inspected,'同期取得不可':missing}
    result['入力指紋']={p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in
                    files+[STUDY/'同期照合の明細.json.gz',STUDY/'同期照合の集計.json',STUDY/'成績.json',ROOT/'work/213集計/CSV入力.json']}
    result['検算']='成立。源コード・固定入力・既存正本は変更していない。CSVの生成元は4候補×各43日を照合。'
    (HERE/'照合結果.json').write_text(json.dumps(result,ensure_ascii=False,indent=1)+'\n',encoding='utf-8')
    print({k:v for k,v in result.items() if k!='入力指紋'})


if __name__=='__main__':
    main()
