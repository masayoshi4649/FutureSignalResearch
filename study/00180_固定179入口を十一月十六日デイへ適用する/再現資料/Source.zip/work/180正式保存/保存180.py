"""180の固定適用Sourceと本日結果だけを、既存正式資料へ接続して保存する。"""
from pathlib import Path
from datetime import datetime, timezone
import gzip
import json
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'work/178正式保存'))
import 保存178 as OLD
P = OLD.P
WORK = ROOT / 'work/180本日デイ適用'
AUDIT = ROOT / 'work/20261116_DAYの独立監査'
TRIAL = ROOT / 'study/00180_固定179入口を十一月十六日デイへ適用する'
DEST = TRIAL / '再現資料'
PARENT = ROOT / 'study/00179_保有時間参加率と終了前決済で入口を広げる/再現資料'
INPUT = ROOT / 'inputs/00180_20261116デイの固定適用入力'
CSV = ROOT / 'outputs/00180_十一月十六日デイの固定適用'


def inherit() -> tuple:
    """
    機能: 179のSource連鎖と、174/179固定選択だけを正式ZIPの元byteへ照合する。
    引数: なし。
    返り値: tuple[dict,list,dict]はSource参照、小入力参照、必要小入力byte。
    """
    parent = P.read(PARENT / '保存索引.json')
    reference = {'archive': parent['Source']['archive'],
        'index': P.fingerprint(PARENT / '保存索引.json'),
        'members': parent['Source']['members'], '親Source継承元': parent['Source継承元']}
    OLD.verify_source(reference)
    folders = [(PARENT, ['work/179保有参加の探索/旧73の固定選択.json',
        'study/00179_保有時間参加率と終了前決済で入口を広げる/条件.json']),
        (ROOT / 'study/00174_共同条件を残して単一建玉の入口を広げる/再現資料',
        ['work/174参加と両中央値の再探索/旧73jointの固定選択.json'])]
    contents = {}; records = []
    for folder, names in folders:
        index = P.read(folder / '保存索引.json')
        canonical = folder / '出生と比較正本.zip'
        assert P.fingerprint(canonical) == index['正本']['archive']
        expected = {r['path']: r for r in index['正本']['members']}
        with zipfile.ZipFile(canonical) as archive:
            assert archive.testzip() is None
            for name in names:
                body = archive.read(name)
                assert P.member_reference(name, body) == expected[name]
                assert (ROOT / name).read_bytes() == body
                contents[name] = body
        records.append({'archive': P.fingerprint(canonical),
            'index': P.fingerprint(folder / '保存索引.json'),
            'members': [expected[name] for name in names], '元byte継承': True})
    return reference, records, contents


def verify() -> dict:
    """
    機能: 本日の固定再現、同体確認、独立監査と恒久入力を保存直前に確認する。
    引数: なし。
    返り値: dictは成功票と恒久入力・CSV・Go正式Sourceの指紋参照。
    """
    proofs = [WORK / '再現確認.json', WORK / '純方向の同体確認180.json',
        WORK / '金融前の接続.json', WORK / '終了前金融の接続.json',
        WORK / 'CSV作成検査/作成確認.json', AUDIT / '原板監査.json',
        AUDIT / '全七取引とCSVの独立結果.json']
    assert all(P.read(path)['成功'] is True for path in proofs)
    assert P.read(WORK / '再現確認.json')['固定2政策の全行一致']
    original = json.loads(gzip.decompress((WORK / '本日の固定結果.json.gz').read_bytes()))
    replay = json.loads(gzip.decompress((ROOT / 'work/180本日再現確認/本日の固定結果.json.gz').read_bytes()))
    assert original == replay and len(original['rows']) == 2
    for row in original['rows']:
        assert len(row['ledger']['net']) == 7 and sum(row['ledger']['net']) == -93539
        assert sum(row['ledger']['added']) == 0
    source = P.fingerprint(WORK / '入力180.py')
    assert source['sha256'] == P.read(INPUT / '保存索引.json')['Source']['sha256']
    input_files = [P.fingerprint(path) for path in sorted(INPUT.rglob('*')) if path.is_file()]
    csv_files = [P.fingerprint(path) for path in sorted(CSV.rglob('*.csv'))]
    assert len(csv_files) == 4
    csv_audit = P.read(WORK / 'CSV作成検査/作成確認.json')
    for item in csv_audit['files']:
        current = P.fingerprint(CSV / item['相対path'])
        assert current['sha256'] == item['sha256'] and current['bytes'] == item['bytes']
    go = ROOT / 'study/00167_固定した複合入口を追加七場へ適用する/再現資料/Source.zip'
    assert P.fingerprint(go)['sha256'] == '8e24d3adbba2d3c997e7cf61842b08db6645cc98d0d3ef107f08cb1b79ee7b54'
    return {'成功': True, '既存固定条件変更なし': True, '探索なし': True,
        '必須確認票': [P.fingerprint(path) for path in proofs],
        '恒久入力': input_files, 'CSV': csv_files, 'Go入力生成Source': P.fingerprint(go),
        '再現方式': '恒久入力から別の新規workへSource4本をコピーして2政策全結果を再計算。同一キャッシュ禁止監査は行っていない。'}


def main() -> None:
    """
    機能: 本日Sourceと小正本だけを新規ZIPへ一度保存し、全memberを再照合する。
    引数: なし。
    返り値: None。正式ZIP二つと保存索引JSONを作成する。
    """
    parent, small_refs, inherited = inherit()
    gate = verify()
    sources = sorted(WORK.glob('*.py')) + sorted(AUDIT.glob('*.py')) + [Path(__file__)]
    names = ['本日の固定結果.json.gz', '本日の純出生.npz', '本日の終了前金融.npz',
        '金融前の接続.json', '終了前金融の接続.json', '純方向の同体確認180.json',
        '再現確認.json', 'CSV型付き入力.json', '入力Source参照180.json', 'CSV作成検査/作成確認.json']
    results = [WORK / name for name in names] + sorted(AUDIT.glob('*.json'))
    results += sorted(path for path in TRIAL.iterdir() if path.is_file() and path.suffix in ('.json', '.md'))
    results += [CSV / 'README.md']
    source_bytes = {path.relative_to(ROOT).as_posix(): path.read_bytes() for path in sources}
    result_bytes = {path.relative_to(ROOT).as_posix(): path.read_bytes() for path in results}
    assert not (set(result_bytes) & set(inherited))
    result_bytes.update(inherited)
    DEST.mkdir(parents=True, exist_ok=True)
    source_ref = P.write_archive(DEST / 'Source.zip', source_bytes)
    result_ref = P.write_archive(DEST / '本日結果と証拠.zip', result_bytes)
    assert verify() == gate
    body = {'成功': True, '正式保存': True, '保存UTC': datetime.now(timezone.utc).isoformat(),
        'Source': source_ref, '正本': result_ref, 'Source継承元': parent,
        '旧小入力の選択継承': small_refs, '完了gate': gate,
        '保存器': P.fingerprint(Path(__file__)),
        '保存方針': '当日Sourceと固定結果のみ。原板・前史7場・既存ZIP・恒久入力・閲覧CSVの重複保存を避ける。',
        '除外': ['初回失敗CSV', 'ISO初回入力', 'node_modules', '__pycache__', '前史七場と本日の母集団', '既存7場の複製'],
        '依存関係': {'Python': '3.14.3', 'NumPy': '2.5.4', 'tzdata': '2026.6', 'Go': '1.24.2', 'Node': 'v24.22.1'},
        '注意': '179までの正式Sourceを連鎖順に復元し、本ZIPで上書きする。本日入力の再生成方法は恒久入力README。今日の赤字を用いた再選択はしない。'}
    destination = DEST / '保存索引.json'
    assert not destination.exists()
    destination.write_text(json.dumps(body, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, 'Source': source_ref['archive'], 'Source数': len(source_ref['members']),
        '正本': result_ref['archive'], '正本数': len(result_ref['members']), '索引': P.fingerprint(destination)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
