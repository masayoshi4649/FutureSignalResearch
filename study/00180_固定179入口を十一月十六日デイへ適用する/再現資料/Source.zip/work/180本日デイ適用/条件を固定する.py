"""11月16日デイへの固定政策適用条件と原入力を保存する。"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
TRIAL = ROOT / 'study/00180_固定179入口を十一月十六日デイへ適用する'


def ref(path: Path) -> dict:
    """
    機能: 参照ファイルのサイズと内容指紋を取得する。
    引数: path(Path)は入力ファイル。
    返り値: dictは絶対パス・バイト数・SHA256。
    """
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.resolve().as_posix(), 'bytes': path.stat().st_size, 'sha256': digest}


def main() -> None:
    """
    機能: 既存主案と同じ時計の旧対照を本日金融計算前に固定する。
    引数: なし。
    返り値: None。再実行時は入力の不変を照合する。
    """
    selection = ROOT / 'work/179保有参加の探索/旧73の固定選択.json'
    fixed = json.loads(selection.read_text(encoding='utf-8'))
    policy = fixed['選択']['全期']['candidates'][0]
    assert policy['id'] == '全期_J035'
    raw = ROOT.parent / 'JP_OSE_Data/future/NK225/2026-11-16_Day/book.jsonl'
    paths = [selection, ROOT / 'study/00179_保有時間参加率と終了前決済で入口を広げる/条件.json',
             ROOT / 'work/179終了前決済/early179.py', ROOT / 'work/179保有参加の探索/基盤179.py',
             ROOT / 'work/179量と構造の純入口/rules179.py', raw]
    body = {'試行': 180, '対象': '2026-11-16_Day', '主政策': policy,
            '対照': '旧178全期のDAY入口、179と同じ終了時計', '再探索': False,
            '単位': 'NK225ラージBBO、mini1枚、買売合計保有予約1件',
            '時計': '開始一律待機なし、15:29全決済要求と新規停止・予約取消、15:30締切',
            '費用': '1pt100円、片道38.5円と追加滑り5pt、売買側BBOを使用',
            '入力と固定Source': [ref(path) for path in paths]}
    destination = TRIAL / '条件.json'
    if destination.exists():
        assert json.loads(destination.read_text(encoding='utf-8')) == body
    else:
        destination.write_text(json.dumps(body, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '政策': policy['id'], '原入力': ref(raw), '条件': ref(destination)}, ensure_ascii=False))


if __name__ == '__main__':
    main()
