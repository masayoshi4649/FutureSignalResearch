"""180純方向を旧73・追加7の凍結済み純出生だけと照合する。"""
from pathlib import Path
from types import SimpleNamespace
import importlib.util
import json
import numpy as np

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('adapter180_verified', HERE / '純方向180.py')
R = importlib.util.module_from_spec(spec)
spec.loader.exec_module(R)
ROOT = R.ROOT


def compare(features: object, period: str) -> dict:
    """
    機能: 全期J035と旧178のデイ方向・幅・期限・追加旗を固定純sealへ照合する。
    引数: features(FeatureDataset)、period(str)は旧73又は追加7。
    返り値: dictは場数、q0数、照合項目数、不一致数と参照SHA。金融は読まない。
    """
    output = R.build(features)
    mask = np.asarray(features.q0_timeband) == 0
    old_path = ROOT / 'work/178追加七場適用' / f'{period}の純出生178.npz'
    new_path = ROOT / 'work/179保有参加の探索' / f'{period}の純出生179.npz'
    order_path = new_path.with_suffix('.json')
    identity = '全期_J002_J000_K012'
    with np.load(old_path, allow_pickle=False) as source:
        assert np.array_equal(source['phases'], features.q0_timeband)
        seal = {k: source[identity + '__' + k].copy()
                for k in ('core', 'branches', 'technical', 'tier', 'mw', 'fw', 'hi')}
    order = json.loads(order_path.read_text(encoding='utf-8'))['候補順']
    with np.load(new_path, allow_pickle=False) as source:
        assert np.array_equal(source['phases'], features.q0_timeband)
        direction = source['directions'][order.index('VLC0003_EDGE')].copy()
    inherited, selected = R.policies()
    parent = R.module(ROOT / 'work/179保有参加の探索/探索179.py', 'compose179_pure180')
    previous = (parent.CTX, parent.SEALS, parent.DIRS)
    try:
        parent.CTX = SimpleNamespace(event_phases=np.asarray(features.q0_timeband),
                                    table=SimpleNamespace(horizons=R.HORIZONS))
        parent.SEALS = {selected['base']: seal}
        parent.DIRS = {'VLC0003_EDGE/NORMAL': direction}
        birth, mw, fw, hi, added = parent.compose(selected)
    finally:
        parent.CTX, parent.SEALS, parent.DIRS = previous
    expected = {'全期_J035': {'birth': birth, 'mw': mw, 'fw': fw, 'hi': hi, 'added': added},
        '旧178_新時計': {'birth': {k: seal[k] for k in ('core', 'branches', 'technical', 'tier')},
            **{k: seal[k] for k in ('mw', 'fw', 'hi')}, 'added': np.zeros(len(mask), bool)}}
    checks = []
    for name in expected:
        for key in ('core', 'branches', 'technical', 'tier', 'mw', 'fw', 'hi', 'added'):
            actual = output[name]['birth'][key] if key in output[name]['birth'] else output[name][key]
            prior = expected[name]['birth'][key] if key in expected[name]['birth'] else expected[name][key]
            mismatch = int(np.count_nonzero(actual[mask] != prior[mask]))
            checks.append({'候補': name, '配列': key, '項目': int(mask.sum()), '不一致': mismatch})
    assert not sum(r['不一致'] for r in checks), checks
    return {'期間': period, '全q0': len(mask), 'デイq0': int(mask.sum()),
        'デイ場': sum(s['session'].endswith('_Day') for s in features.scenes),
        '項目': sum(r['項目'] for r in checks), '不一致': 0, '照合': checks,
        '純seal参照': [R.ref(p) for p in (old_path, new_path, order_path)],
        '主成立q0': int(np.count_nonzero(output['全期_J035']['birth']['core'][mask])),
        '旧幹成立q0': int(np.count_nonzero(output['旧178_新時計']['birth']['core'][mask])),
        '新枝成立q0': int(np.count_nonzero(output['全期_J035']['added'][mask]))}


def main() -> None:
    """
    機能: 過去の純特徴と封印出生だけで180adapterの同体証拠を保存する。
    引数: なし。
    返り値: None。旧固定Sourceと入力は変更しない。
    """
    old = R.module(ROOT / 'work/174追加七場適用/固定政策を適用する.py', 'old174_pure180')
    source_before = R.references()
    past = old.B.P.R168.BASE.data_module().load_feature_dataset()
    added_dir = ROOT / 'inputs/00167_追加七場の入口と共用価格索引/入口母集団'
    added, _, _ = old.B.P.R168.BASE.load_features(added_dir)
    checks = [compare(past, '旧73'), compare(added, '追加7')]
    assert R.references() == source_before
    result = {'成功': True, '固定条件の変更': False, '当日金融未入力': True,
        '比較': '旧178純sealと179の封印LC方向を、元179固定composeへ渡した正本。デイのみ照合。',
        '参照': source_before, '検査Source': R.ref(Path(__file__)), '期間': checks,
        '項目': sum(c['項目'] for c in checks), '不一致': 0}
    target = HERE / '純方向の同体確認180.json'
    target.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '項目': result['項目'], '不一致': 0,
                      '証拠': R.ref(target)}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
