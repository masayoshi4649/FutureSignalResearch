"""固定した本日分の損益を候補別CSV用の型付き値へまとめる。"""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import gzip
import json

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).parent


def local_time(value: float | None) -> str | None:
    """
    機能: 価格時計の秒をJST日時へ変換する。
    引数: value(float|None)はUnix秒。未知はNone。
    返り値: str|NoneはJSTの年月日と時分秒、又は未知。
    """
    return None if value is None else datetime.fromtimestamp(value, ZoneInfo('Asia/Tokyo')).strftime('%Y-%m-%d %H:%M:%S')


def main() -> None:
    """
    機能: 二つの固定政策を分離し、集計と全取引明細を準備する。
    引数: なし。
    返り値: None。金融結果や条件は変更しない。
    """
    result = json.loads(gzip.decompress((HERE / '本日の固定結果.json.gz').read_bytes()))
    summary_headers = ['候補', '対象日', '利益円', '損失円', '収支円_既知', '収支円_全件確定',
        '取引回数', '黒字決済回数', '赤字決済回数', '金融未知件数', '保有率下限', '保有率上限',
        '保有分下限', '対象分', 'F', 'A', 'N', 'C', '強制決済回数', '終了前全決済確認', '新枝取得回数']
    trade_headers = ['候補', '取引番号', '方向', '取得時刻JST', '決済時刻JST', '取得BBO価格',
        '決済BBO価格', '売買差pt', '往復手数料円', '往復追加滑り円', '費用後損益円', '累計収支円_既知',
        '累計収支円_全件確定', '決済理由', '入口区分', 'IFD対称幅pt', '期限', 'case_id', '取得原行', '決済原行']
    tables = {'候補比較': {'headers': summary_headers, 'rows': []}, '取引明細': {'headers': trade_headers, 'rows': []}}
    names = {'全期_J035': '180:179主J035', '旧178_新時計': '180:旧178対照'}
    reasons = {1: '利確幅先着', 2: '損切幅先着', 3: '通常期限決済', 4: '終了前の予定決済',
        10: '価格欠測で不明', 11: 'BBO欠測で不明', 12: '通常期限の板不足',
        13: '終了前決済窓の板不足', 14: '観測終了で不明', 15: '新規停止後'}
    for row in result['rows']:
        candidate = names[row['id']]
        evidence = row['evidence']; ledger = row['ledger']
        group = evidence['financial']['session_groups_required']['DAY']
        trade = group['trades']; first = trade['IFD_FIRSTFANC']
        hold = evidence['holding']['groups']['DAY']
        flat = evidence['holding']['closure']['rows'][0]['flat_guaranteed']
        tables['候補比較']['rows'].append([candidate, '2026-11-16', trade['known_profit'], trade['known_loss'],
            trade['known_net'], trade['known_net'] if not trade['unknown_count'] else None, trade['all_count'],
            sum(v is not None and v > 0 for v in ledger['net']), sum(v is not None and v < 0 for v in ledger['net']),
            trade['unknown_count'], hold['held_lower_ratio'], hold['held_upper_ratio'], hold['held_lower_seconds'] / 60,
            hold['eligible_seconds'] / 60, *[first[key] for key in ('F', 'A', 'N', 'C')], sum(ledger['forced']),
            '確認済' if flat is True else '未知' if flat is None else '違反', sum(ledger['added'])])
        cumulative = 0.; unknown = 0
        for i, net in enumerate(ledger['net']):
            cumulative += 0 if net is None else net
            unknown += net is None
            sign = 1 if ledger['side'][i] == 0 else -1
            point = None if net is None else sign * (ledger['exit_price'][i] - ledger['entry_price'][i])
            kind = '新LC' if ledger['added'][i] else '初参加T' if ledger['origin'][i] == 2 else '旧主'
            tables['取引明細']['rows'].append([candidate, i + 1, '買い' if sign == 1 else '売り',
                local_time(ledger['entry_time'][i]), local_time(ledger['exit_time'][i]), ledger['entry_price'][i],
                ledger['exit_price'][i], point, 77 if net is not None else None, 1000 if net is not None else None,
                net, cumulative, cumulative if not unknown else None, reasons[ledger['status'][i]], kind,
                ledger['width'][i], ledger['horizon'][i], ledger['case_id'][i], ledger['entry_line'][i], ledger['exit_line'][i]])
        assert cumulative == trade['known_net']
    body = {'trial': 180, 'tableNames': {'候補比較': '集計', '取引明細': '取引明細'}, 'tables': tables,
        '定義': 'NK225ラージBBOをmini1枚換算。開始待機なし。15:29決済要求/新規停止、15:30締切。費用後。各候補は別CSV。'}
    destination = HERE / 'CSV型付き入力.json'
    assert not destination.exists()
    destination.write_text(json.dumps(body, ensure_ascii=False, indent=2, allow_nan=False) + '\n', encoding='utf-8')
    print(json.dumps({'成功': True, '予定CSV数': 4, '行数': {key: len(value['rows']) for key, value in tables.items()}}, ensure_ascii=False))


if __name__ == '__main__':
    main()
