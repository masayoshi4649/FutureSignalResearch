"""本日固定適用の全取引を、原板実側価格・逐次時計・費用から独立照合する。"""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import gzip
import hashlib
import json
import math
import sys
import numpy as np

from 原板を確認する import RAW, stamp, finite

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
WORK=ROOT/'work/180本日デイ適用'
INPUT=ROOT/'inputs/00180_20261116デイの固定適用入力'
sys.path.insert(0,str(ROOT/'work/179固定結果の独立検査'))
import scan179 as S
import independent179 as I
V=I.V
JST=timezone(timedelta(hours=9))
DETAIL=['候補','取引番号','方向','取得時刻JST','決済時刻JST','取得BBO価格','決済BBO価格','売買差pt',
    '往復手数料円','往復追加滑り円','費用後損益円','累計収支円_既知','累計収支円_全件確定','決済理由','入口区分',
    'IFD対称幅pt','期限','case_id','取得原行','決済原行']
SUMMARY=['候補','対象日','利益円','損失円','収支円_既知','収支円_全件確定','取引回数','黒字決済回数','赤字決済回数',
    '金融未知件数','保有率下限','保有率上限','保有分下限','対象分','F','A','N','C','強制決済回数','終了前全決済確認','新枝取得回数']


def fingerprint(path: Path) -> dict:
    """
    機能: 原板・固定結果・CSVの全物理指紋を取得する。
    引数: path(Path)。
    返り値: dictはpath/bytes/sha256。
    """
    with path.open('rb') as stream:digest=hashlib.file_digest(stream,'sha256').hexdigest()
    return {'path':str(path.resolve()),'bytes':path.stat().st_size,'sha256':digest}


def raw_records() -> np.ndarray:
    """
    機能: 原JSONLから価格時計・Last・Buy1/Sell1を直接取り出し、原行順を保持する。
    引数: なし。
    返り値: np.ndarrayは独立復元した48byte列。adapter生成索引を読んで作らない。
    """
    values=[]
    with RAW.open('rb') as stream:
        for line,body in enumerate(stream,1):
            source=json.loads(body);text=source.get('CurrentPriceTime')
            if text is None:continue
            at=stamp(text);last=source.get('CurrentPrice');bid=(source.get('Buy1') or {}).get('Price');ask=(source.get('Sell1') or {}).get('Price')
            assert finite(last) and finite(bid) and finite(ask)
            values.append((at,line,last,bid,ask,int(bid<ask)))
    result=np.asarray(values,dtype=S.RECORD)
    assert np.all(np.diff(result['time'])>=0) and np.all(np.diff(result['source_line'])>0)
    return result


def jst(value: float|None) -> str|None:
    """
    機能: 確定したUnix秒をCSVと同じ日本時間表示へ変換する。
    引数: value(float|None)。
    返り値: str|Noneは秒精度の日本時間。未知はNone。
    """
    return None if value is None else datetime.fromtimestamp(value,JST).strftime('%Y-%m-%d %H:%M:%S')


def extrema(records: np.ndarray, entry: int, exit_line: int, price: float, side: int) -> dict:
    """
    機能: 実保有中の正常実側BBOからMFE/MAEとその原行を一覧法で求める。
    引数: records(np.ndarray)、entry/exit_line(int)、price(float)、side(int)。
    返り値: dictは保有中の評価値。約定成立や将来の仮想利益を保証しない。
    """
    last=int(np.searchsorted(records['source_line'],exit_line,side='right'));selected=records[entry:last]
    selected=selected[selected['normal']==1];marks=selected['bid' if side==0 else 'ask']
    points=(1 if side==0 else -1)*(marks-price);high=int(np.argmax(points));low=int(np.argmin(points))
    return {'MFE_pt':float(points[high]),'MFE_費用後円':float(points[high]*100-1077),
        'MFE_JST':jst(float(selected['time'][high])),'MFE_原行':int(selected['source_line'][high]),
        'MAE_pt':float(points[low]),'MAE_費用後円':float(points[low]*100-1077),
        'MAE_JST':jst(float(selected['time'][low])),'MAE_原行':int(selected['source_line'][low])}


def main() -> None:
    """
    機能: 固定主/旧178対照の全7件とCSV4本を独立な原行走査・手計算へ照合する。
    引数: なし。入口・出口・閾値の探索や変更を行わない。
    返り値: None。担当workに検査JSONを保存し、原板・固定Sourceは変更しない。
    """
    result_path=WORK/'本日の固定結果.json.gz';index_path=INPUT/'原板数値索引/2026-11-16_Day.quotes.bin.gz'
    output=ROOT/'outputs/00180_十一月十六日デイの固定適用'
    files=[RAW,result_path,index_path,WORK/'CSV型付き入力.json',Path(__file__),*sorted(output.rglob('*.csv'))]
    before=[fingerprint(path) for path in files]
    assert before[0]['sha256']=='a8cb764a0667285461109b2d8c128e0e7d2e13af5e5bc642e634bb6c12b4d27d'
    data=json.loads(gzip.decompress(result_path.read_bytes()));assert data['成功'] and data['再探索'] is False
    records=raw_records();body=gzip.decompress(index_path.read_bytes())
    assert body[:8]==b'NQIDX163' and len(body)==8+48*len(records)
    adapter_records=np.frombuffer(body,dtype=S.RECORD,offset=8)
    assert np.array_equal(records,adapter_records)
    line_to_index={int(line):i for i,line in enumerate(records['source_line'])}
    horizons={name:{'id':name,'kind':'strict','seconds':seconds} for name,seconds in [('H30',1800),('H60',3600),('H120',7200)]}
    horizons['SESSION']={'id':'SESSION','kind':'session'}
    aliases={'全期_J035':'179主J035','旧178_新時計':'旧178対照'}
    assert {r['id'] for r in data['rows']}==set(aliases)
    C=I.module(ROOT/'work/177増分の独立検査/CSVを点検する.py','csv177_for180')
    counter={'scalar':0,'files':0,'rows':0,'cells':0,'audited_trade_rows':0,'header_cells':0};audit={};cache={};last_audits={}
    for row in data['rows']:
        ledger=row['ledger'];n=len(ledger['net']);assert n==7
        held=I.holding(row['sessions'],row['positions']);V.compare(held,{key:row['evidence']['holding'][key] for key in held},row['id']+'/保有',counter)
        groups=I.financial_groups(row);finance=groups['DAY'];V.compare(finance,row['evidence']['financial']['session_groups_required']['DAY'],row['id']+'/金融',counter)
        checked=[];detail=[];cumulative=0.0
        for i in range(n):
            side=ledger['side'][i];entry_line=ledger['entry_line'][i];entry=line_to_index[entry_line];width=ledger['width'][i];horizon=ledger['horizon'][i]
            assert entry==ledger['entry_index'][i]
            key=(entry_line,side,width,horizon)
            if key not in cache:cache[key]=S.scan_one(records,entry,row['sessions'][0]['original_end'],width,horizons[horizon],side)
            expected=cache[key]
            assert expected['audit']['entry_price']==ledger['entry_price'][i] and expected['audit']['entry_time']==ledger['entry_time'][i]
            for field in ('known','label','status','forced','exit_time','exit_price','exit_line','exit_index','net'):
                V.compare(expected[field],ledger[field][i],row['id']+'/'+str(i+1)+'/'+field,counter)
            assert expected['known'] and expected['exit_line'] in line_to_index
            exit_row=records[line_to_index[expected['exit_line']]]
            mark=float(exit_row['bid' if side==0 else 'ask']);points=(1 if side==0 else -1)*(mark-ledger['entry_price'][i])
            manual=points*100-77-1000;assert manual==expected['net']
            interval=extrema(records,entry,expected['exit_line'],ledger['entry_price'][i],side)
            record={'番号':i+1,'case_id':ledger['case_id'][i],'方向':'買い' if side==0 else '売り',
                '取得JST':jst(ledger['entry_time'][i]),'取得原行':entry_line,'取得価格':ledger['entry_price'][i],
                '決済JST':jst(expected['exit_time']),'決済原行':expected['exit_line'],'決済価格':mark,
                '幅':width,'期限':horizon,'label':expected['label'],'status':expected['status'],'強制':expected['forced'],
                '売買差pt':points,'手数料':77,'追加滑り':1000,'手計算純損益':manual,'元結果一致':True,'保有中':interval}
            checked.append(record);cumulative+=manual;alias=aliases[row['id']]
            reason={1:'利確幅先着',2:'損切幅先着',3:'通常期限決済',4:'終了前の予定決済'}[expected['status']]
            origin='新枝' if ledger['added'][i] else '初参加T' if ledger['origin'][i]==2 else '旧主'
            detail.append(['180:'+alias,i+1,record['方向'],record['取得JST'],record['決済JST'],record['取得価格'],mark,points,
                77,1000,manual,cumulative,cumulative,reason,origin,width,horizon,ledger['case_id'][i],entry_line,expected['exit_line']])
            counter['audited_trade_rows']+=1
        profits=sum(max(0,r['手計算純損益']) for r in checked);losses=-sum(min(0,r['手計算純損益']) for r in checked)
        assert profits==14923 and losses==108462 and cumulative==-93539
        h=held['groups']['DAY'];fa=finance['trades']['IFD_FIRSTFANC'];flat=held['closure']['all_scenes_flat_guaranteed']
        summary=[['180:'+aliases[row['id']],'2026-11-16',profits,losses,cumulative,cumulative,n,
            sum(r['手計算純損益']>0 for r in checked),sum(r['手計算純損益']<0 for r in checked),0,
            h['held_lower_ratio'],h['held_upper_ratio'],h['held_lower_seconds']/60,h['eligible_seconds']/60,
            *[fa[k] for k in ('F','A','N','C')],sum(r['強制'] for r in checked),'確認済' if flat is True else '未知' if flat is None else '違反',sum(ledger['added'])]]
        for filename,columns,wanted in [('集計',SUMMARY,summary),('取引明細',DETAIL,detail)]:
            C.compare_csv(output/('180_'+aliases[row['id']])/(filename+'.csv'),columns,wanted,counter);counter['header_cells']+=len(columns)
        audit[row['id']]={'利益':profits,'損失':losses,'収支':cumulative,'回数':n,'保有下限':h['held_lower_ratio'],
            '保有分':h['held_lower_seconds']/60,'取引':checked,'締切内全決済確認':flat}
        last_audits[row['id']]=checked[-1]
    assert data['rows'][0]['ledger']==data['rows'][1]['ledger']
    assert before==[fingerprint(path) for path in files]
    proof={'成功':True,'再探索':False,'入力不変':True,'入力':before,'原JSONLから独立復元した索引全同体':len(records),
        '固有取引数':len(cache),'検査':counter,'ヘッダー込CSVセル':counter['cells']+counter['header_cells'],
        '両政策台帳同体':True,'政策':audit,'最終取引':last_audits,
        '注意':['主と対照は同じ7件であり独立した14取引ではない。金融未知0、手計算はmini1枚。',
            '保有中MFE/MAEは正常BBOでの評価値。約定成立や売買終了後の仮想利益ではない。',
            '時刻は価格時計。実受信時刻や注文順位を復元したものではない。']}
    (HERE/'全七取引とCSVの独立結果.json').write_text(json.dumps(proof,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'固有取引':len(cache),'原板索引行':len(records),'検査':counter,'ヘッダー込CSVセル':proof['ヘッダー込CSVセル'],
        '主の最終取引':last_audits['全期_J035']},ensure_ascii=False))


if __name__=='__main__':main()
