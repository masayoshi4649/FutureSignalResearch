"""2026-11-16 Day原板の独立読取監査。手法や入力ファイルは変更しない。"""
from pathlib import Path
from collections import Counter, deque
from datetime import datetime, timezone
import csv
import hashlib
import json
import math

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
DIRECTORY=ROOT.parent/'JP_OSE_Data/future/NK225/2026-11-16_Day'
RAW=DIRECTORY/'book.jsonl'


def stamp(text: str) -> float:
    """
    機能: タイムゾーンを持つ原板のISO時計をUnix秒へ変換する。
    引数: text(str)はISO日時。
    返り値: floatはUnix秒。不正値はValueError。
    """
    value=datetime.fromisoformat(text)
    if value.tzinfo is None:raise ValueError('タイムゾーンなし。')
    return value.timestamp()


def finite(value: object) -> bool:
    """
    機能: 正の有限価格かを判定する。
    引数: value(object)は価格。
    返り値: boolは正の有限実数。
    """
    return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) and value>0


def summary(row: dict, line: int) -> dict:
    """
    機能: 手計算に必要な原行・価格時計・限月・実BBOを抽出する。
    引数: row(dict)は原板、line(int)は1起算物理行。
    返り値: dictは小型監査行。英語BidPrice/AskPriceの逆転名を実側へ流用しない。
    """
    return {'line':line,'time':row.get('CurrentPriceTime'),'last':row.get('CurrentPrice'),
        'bid':(row.get('Buy1') or {}).get('Price'),'ask':(row.get('Sell1') or {}).get('Price'),
        'symbol':row.get('Symbol'),'name':row.get('SymbolName'),'volume':row.get('TradingVolume'),
        'volume_time':row.get('TradingVolumeTime')}


def scan() -> dict:
    """
    機能: 全原行を順に読み、時計とBBOの欠測・gap・締切窓・末尾を集計する。
    引数: なし。
    返り値: dictは物理指紋と品質/窓の観測事実。時計gapを通信断とは断定しない。
    """
    before=RAW.stat();digest=hashlib.sha256();counts=Counter();symbols=Counter();names=Counter();dates=Counter()
    start=stamp('2026-11-16T08:45:00+09:00');submit=stamp('2026-11-16T15:29:00+09:00')
    force_min=submit+1;cut=stamp('2026-11-16T15:30:00+09:00');execution_end=stamp('2026-11-16T15:40:00+09:00')
    end=stamp('2026-11-16T15:45:00+09:00')
    first_clock=last_clock=maximum_clock=first_usable=last_usable=None;physical_tail=deque(maxlen=5)
    last_time=last_usable_time=None;price_gaps=[];bbo_gaps=[];regressions=[];force_rows=[];last_before_submit=None;last_before_cut=None
    phase_counts=Counter();invalid_examples=[]
    with RAW.open('rb') as stream:
        for line,body in enumerate(stream,1):
            digest.update(body);counts['physical_lines']+=1
            try:row=json.loads(body)
            except (ValueError,UnicodeError):
                counts['invalid_json']+=1
                if len(invalid_examples)<5:invalid_examples.append(line)
                continue
            symbols[str(row.get('Symbol'))]+=1;names[str(row.get('SymbolName'))]+=1
            record=summary(row,line);physical_tail.append(record)
            raw_time=row.get('CurrentPriceTime')
            if raw_time is None:counts['null_price_clock']+=1;continue
            try:at=stamp(raw_time)
            except (ValueError,TypeError):counts['invalid_price_clock']+=1;continue
            counts['clock_rows']+=1;dates[raw_time[:10]]+=1
            first_clock=record if first_clock is None else first_clock;last_clock=record
            if maximum_clock is None or at>stamp(maximum_clock['time']):maximum_clock=record
            if last_time is not None:
                if at<last_time:
                    counts['clock_regressions']+=1
                    if len(regressions)<10:regressions.append({'line':line,'time':raw_time,'previous_unix':last_time})
                elif at==last_time:counts['same_price_clock_rows']+=1
                elif at-last_time>300:price_gaps.append({'line':line,'before_unix':last_time,'after':raw_time,'seconds':at-last_time})
            last_time=at
            bid=record['bid'];ask=record['ask'];last=record['last']
            normal=finite(bid) and finite(ask) and bid<ask
            if not finite(last):counts['invalid_last_with_clock']+=1
            if normal:counts['normal_bbo_clock_rows']+=1
            elif finite(bid) and finite(ask) and bid==ask:counts['locked_bbo_clock_rows']+=1
            elif finite(bid) and finite(ask) and bid>ask:counts['crossed_bbo_clock_rows']+=1
            else:counts['missing_bbo_clock_rows']+=1
            phase='before_start' if at<start else 'before_submit' if at<submit else 'force_window' if at<=cut else 'after_cut_zaraba' if at<execution_end else 'preclosing_or_close' if at<=end else 'after_end'
            phase_counts[phase]+=1
            if not normal or not finite(last) or at<start or at>end:continue
            counts['usable_clock_last_bbo_rows']+=1
            if last_usable_time is not None and at>last_usable_time and at-last_usable_time>300:
                bbo_gaps.append({'line':line,'before_unix':last_usable_time,'after':raw_time,'seconds':at-last_usable_time})
            last_usable_time=at;first_usable=record if first_usable is None else first_usable;last_usable=record
            if at<submit:last_before_submit=record
            if at<=cut:last_before_cut=record
            if force_min<=at<=cut:
                counts['usable_force_window_rows']+=1
                if len(force_rows)<5:force_rows.append(record)
    after=RAW.stat();assert before.st_size==after.st_size and before.st_mtime_ns==after.st_mtime_ns
    return {'成功':True,'原板':{'path':str(RAW.resolve()),'bytes':after.st_size,'sha256':digest.hexdigest(),
        'mtime_ns':after.st_mtime_ns,'mtime_utc':datetime.fromtimestamp(after.st_mtime,timezone.utc).isoformat()},
        '入力stat不変':True,'counts':dict(counts),'symbols':dict(symbols),'names':dict(names),'価格時計の日付':dict(dates),
        '価格時計phase行数':dict(phase_counts),'first_clock':first_clock,'last_clock':last_clock,'maximum_clock':maximum_clock,
        'first_usable':first_usable,'last_usable':last_usable,'last_usable_before_submit':last_before_submit,
        'last_usable_before_cut':last_before_cut,'first_usable_force_window':force_rows,'physical_tail':list(physical_tail),
        'price_clock_gaps_over300':price_gaps,'usable_bbo_clock_gaps_over300':bbo_gaps,'clock_regression_examples':regressions,
        'invalid_json_examples':invalid_examples,'時計':'CurrentPriceTimeのみ。受信時刻や取引所連番ではない。価格時計gapを通信断と断定しない。',
        'BBO':'Buy1.PriceをBid、Sell1.PriceをAskとする。normalは有限・正・Bid<Ask。usableはLastも正有限。'}


def candles() -> dict:
    """
    機能: 分足を読取専用で確認し、先頭・末尾・closed旗を記録する。
    引数: なし。
    返り値: dictは1分/5分の物理指紋と簡潔な形式監査。
    """
    output={}
    for filename in ('candle_1min.csv','candle_5min.csv'):
        path=DIRECTORY/filename;body=path.read_bytes()
        with path.open(encoding='utf-8-sig',newline='') as stream:reader=csv.DictReader(stream);rows=list(reader);columns=reader.fieldnames
        output[filename]={'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'columns':columns,'rows':len(rows),
            'head':rows[:2],'tail':rows[-3:],'closed_counts':dict(Counter(r.get('closed') for r in rows)),
            'volume_complete_counts':dict(Counter(r.get('volume_complete') for r in rows))}
    return output


def main() -> None:
    """
    機能: 原板と分足の独立監査を保存する。
    引数: なし。
    返り値: None。担当workだけへ結果JSONを書き、原板や179 Sourceを変更しない。
    """
    result=scan();result['candles']=candles()
    (HERE/'原板監査.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False)+'\n',encoding='utf-8')
    print(json.dumps({'成功':True,'原板':result['原板'],'counts':result['counts'],'symbols':result['symbols'],
        'maximum_clock':result['maximum_clock'],'last_usable_before_cut':result['last_usable_before_cut'],
        'first_force':result['first_usable_force_window'][:1],
        'price_gaps300':len(result['price_clock_gaps_over300']),'normal_gaps300':len(result['usable_bbo_clock_gaps_over300']),
        'csv_rows':{name:r['rows'] for name,r in result['candles'].items()}},ensure_ascii=False))


if __name__=='__main__':main()
