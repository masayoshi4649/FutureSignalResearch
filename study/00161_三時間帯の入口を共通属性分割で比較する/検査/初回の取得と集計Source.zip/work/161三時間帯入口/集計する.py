"""161の取得集合を旧厳密H60の同一先着・IFD条件で比較する。"""
from pathlib import Path
from collections import Counter
import gzip
import json
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from 学習する import ROOT, TRIAL, BOOK_SHA, module, sha, save

BAND_NAMES=('デイ','米国前','米国後')
PERIODS=('全期','前48場','後25場')


def ratio(a: float, b: float) -> float|None:
    """
    機能: 分母0を未知として割合を計算する。
    引数: a/b(float)は分子/分母。
    返り値: float又はNone。
    """
    return a/b if b else None


def stats(rows: list, eligible: list, hours: float) -> dict:
    """
    機能: 不明を損益0で埋めず先着率・参加・金融を独立して集計する。
    引数: rows(list[dict])は入口金融、eligible(list[str])は対象場、hours(float)は全場ザラバ時間。
    返り値: dictは件数、分母別率、既知利益/損失、PF、参加率。
    """
    counts=Counter(r['label'] for r in rows)
    known=[r['net'] for r in rows if r['known']]
    profit=sum(max(n,0) for n in known);loss=-sum(min(n,0) for n in known)
    scenes=Counter(r['session'] for r in rows)
    complete=counts['F']+counts['A']+counts['N']
    return {'取得':len(rows),'順':counts['F'],'逆':counts['A'],'未到達':counts['N'],'観測不足':counts['C'],
        '到達済み先着率':ratio(counts['F'],counts['F']+counts['A']),
        '完了分母順行率':ratio(counts['F'],complete),'全取得分母順行率':ratio(counts['F'],len(rows)),
        '対象場':len(eligible),'取得場':len(scenes),'未取得場':len(eligible)-len(scenes),
        '全場最低1':bool(eligible) and all(scenes[s]>=1 for s in eligible),
        '対象時間':hours,'取得毎時':ratio(len(rows),hours),
        '利益総額':profit,'損失総額':loss,'既知差引':profit-loss,'PF':ratio(profit,loss),
        '金融既知':len(known),'金融未知':len(rows)-len(known),
        '新枝取得':sum(r['source_kind']!='旧C1固定参照' for r in rows),
        '旧C1取得':sum(r['source_kind']=='旧C1固定参照' for r in rows),
        '最大場集中率':ratio(max(scenes.values(),default=0),len(rows))}


def table(headers: list, records: list) -> dict:
    """
    機能: 順序を固定して型付き表へ変換する。
    引数: headers(list[str])、records(list[dict])は列と記録。
    返り値: dictはheadersとrows。
    """
    return {'headers':headers,'rows':[[r[h] for h in headers] for r in records]}


# ----------------------------------------
def main() -> None:
    """
    機能: 選択完了後にだけ金融を結合し、全41政策の四表と追跡可能な小型正本を作る。
    引数: なし。固定161選択、固定148由来の全case金融射影を利用する。
    返り値: None。JSON正本を保存しCSV出力器へ渡す。
    """
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    book=json.loads((TRIAL/'条件.json').read_text(encoding='utf-8'))
    selection_path=HERE/'選択/選択対応.json.gz'
    finance_path=ROOT/'work/161三時間帯入口の金融/自然射影/全caseの厳密先着とIFD.json.gz'
    audit_path=HERE/'自然学習/場別モデルと教師.json.gz'
    data=module(ROOT/'work/161三時間帯入口のデータ/data161.py','data161_report')
    source_paths=[Path(__file__),selection_path,finance_path,audit_path]
    before={str(p.relative_to(ROOT)):sha(p) for p in source_paths}
    save(TRIAL/'検査/F2_金融集計前.json',{'成功':True,'条件SHA256':BOOK_SHA,'入力とSource':before})
    selected=json.loads(gzip.decompress(selection_path.read_bytes()))
    finance=json.loads(gzip.decompress(finance_path.read_bytes()))
    audits=json.loads(gzip.decompress(audit_path.read_bytes()))['rows']
    sessions=selected['全73場'];assert len(sessions)==73
    indices={s:i for i,s in enumerate(sessions)}
    features=data.load_feature_dataset()
    scenes={s['session']:s for s in features.scenes}
    # Sourceのforce_closeは15:35/05:50。頻度分母は全ザラバ15:40/05:55。
    all_hours=sum(s['end']-300-s['start'] for s in scenes.values())/3600
    assert abs(all_hours-(720+55/60))<1e-10
    records=[];quality=[];by_scene=[];by_model=[];physical={}
    for policy in book['policies']:
        rows=[]
        for source in selected['政策'][policy]:
            case=finance[source['case_id']];result=case[source['stream']]
            assert source['side']==result['side'] and source['session']==case['session']
            q1=case['entry_quote']
            assert (q1['time'],q1['index'],q1['source_line'])==tuple(source['q1'][k] for k in ('time','index','source_line'))
            band=data.timeband(source['session'],q1['time'])
            kind=source['source_kind']
            row={'policy':policy,'case_id':source['case_id'],'session':source['session'],'side':source['side'],
                'stream':source['stream'],'event_id':source['event_id'],'source_kind':kind,
                'q0_timeband':source.get('q0_timeband'),'q1_timeband':band,'q1_time':q1['time'],
                'label':result['label'],'known':result['known'],'net':result['net'],
                'entry_price':result['entry_price'],'mark':result['mark'],'points':result['points'],
                'exit_quote':result['exit_quote'],'reason':result['reason']}
            rows.append(row)
            physical[(source['case_id'],source['stream'])]={'case_id':source['case_id'],
                'session':source['session'],'entry_quote':q1,'result':result}
        records.extend(rows)
        for period in PERIODS:
            eligible=[s for s in sessions if period=='全期' or (indices[s]<48 if period=='前48場' else indices[s]>=48)]
            subset=[r for r in rows if r['session'] in eligible]
            hours=sum(scenes[s]['end']-300-scenes[s]['start'] for s in eligible)/3600
            item={'政策':policy,'期間':period,'取得帯':'全体',**stats(subset,eligible,hours)}
            quality.append(item)
            for band,name in enumerate(BAND_NAMES):
                band_scenes=[s for s in eligible if (s.endswith('_Day'))==(band==0)]
                band_hours=0
                for session in band_scenes:
                    scene=scenes[session]
                    if band==0:
                        band_hours+=scene['end']-300-scene['start']
                    else:
                        boundary=data.us_open_time(session)
                        continuous_end=scene['end']-300
                        begin,end=(scene['start'],min(continuous_end,boundary)) if band==1 else (max(scene['start'],boundary),continuous_end)
                        band_hours+=max(0,end-begin)
                quality.append({'政策':policy,'期間':period,'取得帯':name,
                    **stats([r for r in subset if r['q1_timeband']==band],band_scenes,band_hours/3600)})
        cumulative=0
        for session in sessions:
            subset=[r for r in rows if r['session']==session]
            hour=(scenes[session]['end']-300-scenes[session]['start'])/3600
            item=stats(subset,[session],hour);cumulative+=item['既知差引']
            by_scene.append({'政策':policy,'セッション':session,**item,'既知累計収支':cumulative})
    for audit in audits:
        entries=[('COMMON','全帯',audit['models']['COMMON']),('CONTEXT','全帯',audit['models']['CONTEXT'])]
        entries += [('SPLIT',BAND_NAMES[int(b)],a) for b,a in audit['models']['SPLIT'].items()]
        for mode,band,item in entries:
            by_model.append({'セッション':audit['session'],'方式':mode,'判断帯':band,'学習可':item['ready'],
                '不足理由':'/'.join(item['ready_reasons']),'物理pair':item['physical_pair_count'],
                '寄与場':len(item['contributing_sessions']),'時区画':item['active_block_count'],
                '最終成熟時計':item['max_label_known_at'],
                '学習配列SHA256':item['model']['training_array_sha256'] if item['model'] else None,
                '構造SHA256':item['model']['structure_sha256'] if item['model'] else None})
    out=TRIAL/'成果物';out.mkdir(exist_ok=True)
    save(out/'入口とIFDの小型正本.json.gz',{'試行':161,'成功':True,'条件SHA256':BOOK_SHA,'全73場':sessions,
        '政策':records,'物理実側':[physical[k] for k in sorted(physical)]})
    headers=['政策','期間','取得帯',*stats([],[],0).keys()]
    overall=[r for r in quality if r['取得帯']=='全体']
    bands=[r for r in quality if r['取得帯']!='全体']
    tables={'比較一覧':table(headers,overall),'時間帯別':table(headers,bands),
        '全セッション':table(['政策','セッション',*stats([],[],0).keys(),'既知累計収支'],by_scene),
        'モデル支持':table(list(by_model[0]),by_model)}
    refs={'conditions':{'path':str((TRIAL/'条件.json').relative_to(ROOT)),'sha256':BOOK_SHA},
        'selected_finance':{'path':str((out/'入口とIFDの小型正本.json.gz').relative_to(ROOT)),
            'sha256':sha(out/'入口とIFDの小型正本.json.gz')}}
    save(out/'型付き四表.json',{'trial':161,'inputs':refs,'tables':tables})
    assert all(sha(ROOT/p)==v for p,v in before.items())
    save(out/'集計確認.json',{'成功':True,'条件SHA256':BOOK_SHA,'入力とSource':before,
        '会員行数':len(records),'物理実側数':len(physical),'全時間':all_hours,'全表行数':{k:len(t['rows']) for k,t in tables.items()},
        '利益と損失は各入口独立1mini':'実口座収支ではない','金融は旧strictH60の即時代用':'157の場末短縮/D1と区別',
        '出力':{p.name:sha(p) for p in out.iterdir() if p.is_file()}})
    print(json.dumps({'成功':True,'主政策':[r for r in overall if r['政策'] in book['main_policies']]},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
