"""161の全q0判断を先に確定し、後段で実取得と固定旧信号だけを結合する。"""
from pathlib import Path
from collections import Counter
import copy
import gzip
import json
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from 学習する import ROOT, TRIAL, BOOK_SHA, module, sha, save


def quote_key(quote: dict) -> tuple:
    """
    機能: 文字列IDを混ぜず物理気配の時計を比較可能にする。
    引数: quote(dict)はtime/index/source_lineを持つ気配。
    返り値: tupleは秒・原行index・source_line。
    """
    return quote['time'],quote['index'],quote['source_line']


def connect(decisions: list, captures: list, descriptors: list, legacy: list, book: dict) -> dict:
    """
    機能: ラベルなしの完成済み要求を取得へ結び、純新規・旧全保持・初参加補完を比較する。
    引数: decisions/captures/descriptors/legacy(list[dict])は判断・取得・参照・旧出生、book(dict)は固定条件。
    返り値: dictは41政策の取得参照と因果時計監査。損益・先着を引数へ受けない。
    """
    captures_by_event={c['event_id']:c for c in captures}
    cases={c['case_id']:c for c in descriptors}
    assert len(captures_by_event)==len(captures)==len(decisions)
    assert set(captures_by_event)=={d['event_id'] for d in decisions}
    old={};first={};quotes={};counts={s:Counter() for s in book['signal_policies']}
    for capture in captures:
        if capture['status']=='filled':
            case=capture['case_id']
            if case in quotes:
                assert quote_key(quotes[case])==quote_key(capture['q1'])
            quotes[case]=capture['q1']
    for row in legacy:
        case=row['case_id'];assert cases[case]['c1_reused']
        assert row['side']==cases[case]['original_side']
        old[case]={'case_id':case,'session':row['session'],'side':row['side'],'stream':'original',
            'event_id':None,'feature_ref':None,'origin':'C1','source_kind':'旧C1固定参照',
            'signal_quote':row['signal_quote'],'q1':row['entry_quote'],'legacy_model':row['model']}
        quotes[case]=row['entry_quote']
        previous=first.get(row['session'])
        if previous is None or (*quote_key(row['signal_quote']),case)<(*quote_key(previous['signal_quote']),previous['case_id']):
            first[row['session']]=row
    assert len(old)==87 and len(first)==73
    chosen={s:{} for s in book['signal_policies']}
    for d in sorted(decisions,key=lambda r:(r['session_index'],r['q0_index'],r['q0_line'],r['event_id'])):
        c=captures_by_event[d['event_id']]
        assert (d['q0_time'],d['q0_index'],d['q0_line'])==quote_key(c['q0'])
        assert c['session']==d['session'] and c['contract']==d['contract']
        for signal in book['signal_policies']:
            side=d['decision']['directions'][signal]
            if not side:
                continue
            counts[signal]['born']+=1;counts[signal][c['status']]+=1
            if c['status']!='filled':
                continue
            case=c['case_id'];desc=cases[case]
            if case in chosen[signal]:
                counts[signal]['duplicate_q1']+=1
                continue
            stream=c['buy_stream' if side==1 else 'sell_stream']
            assert stream==desc['buy_stream' if side==1 else 'sell_stream']
            assert desc['session']==d['session']
            if case in quotes:
                assert quote_key(quotes[case])==quote_key(c['q1'])
            quotes[case]=c['q1']
            chosen[signal][case]={'case_id':case,'session':d['session'],'side':side,'stream':stream,
                'event_id':d['event_id'],'feature_ref':d['event_id'],'origin':signal,'source_kind':'新q0',
                'q0_time':d['q0_time'],'q0_index':d['q0_index'],'q0_line':d['q0_line'],
                'q0_timeband':d['q0_timeband'],'q1':c['q1'],
                'evidence':[e for e in d['decision']['evidence'] if e['rule']==signal]}
    policies={};audits=[];overlaps=[]
    for signal,new in chosen.items():
        policies[signal+'_N']=list(new.values())
        union=dict(old)
        for case,row in new.items():
            if case in union:
                overlaps.append({'signal':signal,'case_id':case,'old_side':union[case]['side'],'new_side':row['side']})
            else:
                union[case]=row
        policies[signal+'_U']=list(union.values())
        supplement={}
        for session,signal_row in first.items():
            signal_key=quote_key(signal_row['signal_quote'])
            filled=[r for r in new.values() if r['session']==session and quote_key(r['q1'])<=signal_key]
            reserved=not filled
            if reserved:
                supplement[signal_row['case_id']]=old[signal_row['case_id']]
            audits.append({'signal_policy':signal,'session':session,'first_C1_case':signal_row['case_id'],
                'first_C1_birth':signal_row['signal_quote'],'first_C1_q1':signal_row['entry_quote'],
                'new_filled_before_or_at_birth':[r['case_id'] for r in filled],
                'reserve_C1':reserved,'pending_new_does_not_count':True,'later_fill_does_not_cancel':True})
        fallback=dict(new)
        fallback.update(supplement)
        policies[signal+'_F']=list(fallback.values())
        assert all(any(r['session']==s for r in fallback.values()) for s in first)
    policies['C1']=list(old.values())
    return {'政策':policies,'候補と取得':{s:dict(c) for s,c in counts.items()},
        'F因果監査':audits,'旧優先衝突':overlaps,'quotes':quotes}


# ----------------------------------------
def correct(decisions: list, features: object, columns: list, logic: object) -> list:
    """
    機能: 全原判断の後に、旧152A0の複合回復条件をP65だけへ適用する。
    引数: decisions(list[dict])、features(object)は実側100X、columns(list)、logic(object)は旧固定純関数。
    返り値: list[dict]は取得/教師を含まない追加補正判断。元確率は反転先へ付けない。
    """
    out=[]
    for index,raw in enumerate(decisions):
        assert raw['event_id']==features.q0_meta[index]['event_id']
        d={k:raw[k] for k in ('event_id','session','contract','session_index','q0_time','q0_index','q0_line','q0_timeband')}
        d['decision']=copy.deepcopy(raw['decision']);d['correction']={}
        buy=features.buy_X[index].tolist();sell=features.sell_X[index].tolist()
        for mode in ('COMMON','CONTEXT','SPLIT'):
            source=mode+'_P65';name=source+'_A';s=d['decision']['directions'][source]
            choice=logic.choose(s,buy,sell,columns);t=choice['A0']['side']
            d['correction'][mode]=choice
            d['decision']['directions'][name]=t
            d['decision']['conflicts'][name]=choice['A0']['reason']=='recovery_conflict'
            if t:
                roles=set(raw['predictions'][mode]['prediction']['known_roles'])|{'方向','強度'}
                if choice['G'] is not None and choice['G']['value'] is True:
                    roles={'方向','強度','勢い','構造','量'}
                d['decision']['evidence'].append({'rule':name,'signal_side':s,'order_side':t,
                    'roles':sorted(roles),'G':choice['G'],'operation':choice['A0'],
                    'reverse_probability_transferred':False})
        out.append(d)
    return out


# ----------------------------------------
def main() -> None:
    """
    機能: 全q0を補正して先に保存し、次に取得を結合して旧対照を載せる。
    引数: なし。固定条件・自然学習正本・正式148/152/153を利用する。
    返り値: None。ラベル未読の選択対応と入力指紋を保存する。
    """
    out=HERE/'選択';assert not out.exists()
    assert sha(TRIAL/'条件.json')==BOOK_SHA
    book=json.loads((TRIAL/'条件.json').read_text(encoding='utf-8'))
    data=module(ROOT/'work/161三時間帯入口のデータ/data161.py','data161_link')
    logic_path=ROOT/'work/152複合回復の入口/logic152.py'
    logic=module(logic_path,'logic152_frozen161')
    paths=[Path(__file__),logic_path,HERE/'自然学習/q0の判断.json.gz']
    before={str(p.relative_to(ROOT)):sha(p) for p in paths}
    save(TRIAL/'検査/F1_取得結合前.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと判断':before,'金融ラベル未読':True})
    raw=json.loads(gzip.decompress(paths[-1].read_bytes()))['rows']
    features=data.load_feature_dataset()
    columns,_=data.read_json_ref(data.FileRef(ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json',book['catalog_definition_sha256']))
    decisions=correct(raw,features,columns,logic)
    save(out/'補正q0の判断.json.gz',{'成功':True,'試行':161,'取得結合前全件':True,'金融ラベル未読':True,'rows':decisions})
    capture_ref=data.FORMAL_REFS['captures']
    captures,capture_proof=data.read_json_ref(capture_ref)
    metadata,metadata_proof=data.read_json_ref(data.LEGACY_META)
    legacy=data.legacy_signals_from_metadata(metadata)
    result=connect(decisions,captures['rows'],metadata['population148']['cases'],legacy,book)
    old_refs={}
    for trial,folder,aliases in [(152,'00152_複合回復の方向切替',{'OLD152_B0_N':'B0','OLD152_U1':'U1'}),
        (153,'00153_先行高安の独立出生',{'OLD153_N15':'N15','OLD153_U15':'U15'})]:
        path=ROOT/'inputs'/folder/'選択対応.json.gz'
        body=gzip.decompress(path.read_bytes());old=json.loads(body)
        assert old['成功'] and old['試行']==trial
        old_refs[str(trial)]={'path':str(path.relative_to(ROOT)),'sha256':sha(path),'decoded_sha256':__import__('hashlib').sha256(body).hexdigest()}
        for name,alias in aliases.items():
            result['政策'][name]=copy.deepcopy(old['政策'][alias])
            for row in result['政策'][name]:
                row['q1']=result['quotes'][row['case_id']]
                row['source_kind']='旧C1固定参照' if row['case_id'] in {r['case_id'] for r in result['政策']['C1']} else '過去新枝固定参照'
    assert set(result['政策'])==set(book['policies'])
    assert all(sha(ROOT/p)==v for p,v in before.items())
    result.pop('quotes')
    save(out/'選択対応.json.gz',{'成功':True,'試行':161,'金融ラベル未読':True,'全73場':captures['sessions'],**result})
    save(out/'選択完了.json',{'成功':True,'条件SHA256':BOOK_SHA,'Sourceと判断':before,
        '入力':{'capture':capture_proof,'metadata':metadata_proof,'old':old_refs},
        '政策別取得数':{p:len(rows) for p,rows in result['政策'].items()},
        '出力':{p.name:sha(p) for p in out.iterdir() if p.is_file()}})
    print(json.dumps({'成功':True,'政策数':len(result['政策']),'取得数':{p:len(rows) for p,rows in result['政策'].items()}},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
