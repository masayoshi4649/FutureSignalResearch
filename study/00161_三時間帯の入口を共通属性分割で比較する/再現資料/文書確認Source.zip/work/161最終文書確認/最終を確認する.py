"""161の最終文書・保存指紋・ローカルリンクを変更せず確認する。"""
from pathlib import Path
from zipfile import ZipFile
import ast
import csv
import hashlib
import io
import json
import re
from urllib.parse import unquote

import 準備を確認する as prepare

ROOT=prepare.ROOT
HERE=prepare.HERE
STUDY=prepare.STUDY
DOCS=[ROOT/'AGENTS.md',ROOT/'README.md',ROOT/'docs/README.md',ROOT/'docs/議論/README.md',ROOT/'study/README.md',
    ROOT/'docs/議論/入口をデイと米国前後で分けて検証する.md',
    ROOT/'docs/議論/三時間帯だけでなく背景の混在状態を入口で分ける.md']


def check_links(paths: list[Path]) -> dict:
    """
    機能: Markdownのローカルリンクを文書位置から解決し、存在とwork非依存を確認する。
    引数: paths (list[Path]) 最終文書。返り値: dict 型のリンク結果。
    """
    missing=[];work=[];count=0;external=0
    for path in paths:
        text=path.read_text(encoding='utf-8-sig')
        for match in re.finditer(r'(?<!!)\[[^\]\n]*\]\(([^\)\n]+)\)',text):
            target=match[1].strip()
            if target.startswith('<') and '>' in target:
                target=target[1:target.index('>')]
            else:
                target=target.split(' "',1)[0]
            if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',target) or target.startswith('#'):
                external+=1;continue
            target=unquote(target.split('#',1)[0].split('?',1)[0])
            if not target:
                continue
            resolved=(path.parent/target).resolve();count+=1
            if not resolved.exists():
                missing.append({'文書':str(path.relative_to(ROOT)),'先':target})
            if resolved.is_relative_to(ROOT/'work'):
                work.append({'文書':str(path.relative_to(ROOT)),'先':target})
    return {'成功':not missing and not work,'ローカル数':count,'外部又は同頁参照':external,
        '不存在':missing,'正式文書からworkへの閲覧依存':work}


# ----------------------------------------
def check_archives(index: dict) -> tuple:
    """
    機能: 最終2ZIPを全CRC完読し、保存指紋と元Source/学習正本への同体を確認する。
    引数: index (dict) 保存索引。返り値: tuple のZIP監査・member指紋・Python規約。
    """
    result=[];members={};python_issues=[];functions=0
    for name,expected in index['archives'].items():
        path=STUDY/'再現資料'/name
        assert path.stat().st_size==expected['bytes'] and prepare.sha(path)==expected['sha256']
        same=[];different=[]
        with ZipFile(path) as archive:
            infos=archive.infolist();assert len(infos)==len({i.filename for i in infos})==expected['members']
            for info in infos:
                assert not info.is_dir()
                body=archive.read(info.filename);digest=hashlib.sha256(body).hexdigest()
                members[info.filename.replace('\\','/')]=digest
                local=ROOT/info.filename
                if local.exists():
                    (same if prepare.sha(local)==digest else different).append(info.filename)
                if name=='Source.zip' and info.filename.endswith('.py'):
                    text=body.decode('utf-8-sig');tree=ast.parse(text,filename=info.filename)
                    for node in ast.walk(tree):
                        if not isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                            continue
                        functions+=1;doc=ast.get_docstring(node,clean=False);reasons=[]
                        if doc is None:
                            reasons.append('docstringなし')
                        else:
                            if len([s for s in doc.splitlines() if s.strip()])<2:reasons.append('複数行でない')
                            for word in ('機能','引数','返り値'):
                                if word not in doc:reasons.append(word+'なし')
                            if '戻り値' in doc:reasons.append('禁止語あり')
                            if not re.search(r'[ぁ-んァ-ン一-龥]',doc):reasons.append('日本語でない')
                        if reasons:python_issues.append({'path':info.filename,'line':node.lineno,'function':node.name,'理由':reasons})
        result.append({'zip':name,'全CRC完読':True,'sha256':prepare.sha(path),'members':len(infos),
            '存在元と同体':len(same),'元と相違':different})
    return result,members,{'成功':not python_issues,'関数数':functions,'要確認':python_issues}


# ----------------------------------------
def check_checkpoints(members: dict) -> dict:
    """
    機能: 最終F0/F1/F2で固定したSourceと判断の指紋が保存ZIPへ結べるか検査する。
    引数: members (dict[str,str]) ZIP内のpath別SHA。返り値: dict 型の照合結果。
    """
    rows=[]
    for name,key in (('F0_自然実行前.json','Source'),('F1_取得結合前.json','Sourceと判断')):
        value=json.loads((STUDY/'検査'/name).read_text(encoding='utf-8-sig'))
        for path,digest in value[key].items():
            normalized=path.replace('\\','/')
            rows.append({'票':name,'path':normalized,'一致':members.get(normalized)==digest})
    return {'成功':all(r['一致'] for r in rows),'件数':len(rows),'比較':rows}


# ----------------------------------------
def old160() -> dict:
    """
    機能: 旧160の準備時点全指紋と、160自身の停止票に固定した正式資料を照合する。
    引数: なし。返り値: dict 型の不変確認。旧文書を更新しない。
    """
    before=json.loads((HERE/'160の準備時点指紋.json').read_text(encoding='utf-8'))
    after=prepare.inventory(prepare.OLD160)
    mismatches=[p for p in set(before)|set(after) if before.get(p)!=after.get(p)]
    ticket=json.loads((prepare.OLD160/'検査/文書と最終保存の確認.json').read_text(encoding='utf-8'))
    anchored=[]
    for path,digest in ticket['文書'].items():
        if path.replace('\\','/').startswith('study/00160_'):
            anchored.append({'path':path,'一致':prepare.sha(ROOT/path)==digest})
    for name,ref in ticket['再現ZIP'].items():
        paths=list(prepare.OLD160.rglob(name));assert len(paths)==1
        anchored.append({'path':str(paths[0].relative_to(ROOT)),
            '一致':prepare.sha(paths[0])==ref['sha256'] and paths[0].stat().st_size==ref['bytes']})
    return {'成功':not mismatches and all(r['一致'] for r in anchored),'準備時点全ファイル数':len(before),
        '準備時点から相違':mismatches,'160停止票から照合':anchored}


# ----------------------------------------
def main() -> None:
    """
    機能: 最終文書QAを新規票へ保存し、必要な指摘だけを出す。
    引数: なし。返り値: None。文書・正式保存・Sourceを変更しない。
    """
    index_path=STUDY/'再現資料/保存索引.json'
    index=json.loads(index_path.read_text(encoding='utf-8-sig'))
    formal=[]
    for name,ref in index['formal_files'].items():
        path=STUDY/name
        formal.append({'path':name,'一致':path.exists() and path.stat().st_size==ref['bytes'] and prepare.sha(path)==ref['sha256']})
    archives,members,python=check_archives(index)
    paths=sorted({*DOCS,*STUDY.rglob('*.md')});utf8=[]
    for p in [*paths,*STUDY.rglob('*.json')]:
        try:p.read_text(encoding='utf-8-sig')
        except UnicodeError:utf8.append(str(p.relative_to(ROOT)))
    readme=(STUDY/'README.md').read_text(encoding='utf-8-sig')
    reproduce=(STUDY/'再現手順.md').read_text(encoding='utf-8-sig')
    mandatory={'仮説':bool(re.search('仮説|案|比較',readme)),'入力':bool(re.search('q0|特徴|入力',readme)),
        '費用':'77円' in readme and '1000円' in readme,'結果':'主結果' in readme,'限界':'限界' in readme,
        '再現手順':'再現手順.md' in readme,'旧156未実行':'未実行の旧156' in readme,
        '未見2場明記':'11/10ナイト' in readme and '11/11デイ' in readme,
        '既使用と未見の区別':'前48/後25とも既使用' in readme,
        'cache無しCLI未重複実行':'追加CLI自体は今回全学習を重複実行していない' in reproduce,
        '心理仮説と事実の区別':'市場心理を証明した事実とはしない' in (STUDY/'原因と次の仮説.md').read_text(encoding='utf-8-sig')}
    csvs=[]
    for match in re.finditer(r'\]\(([^)]+\.csv)\)',(STUDY/'閲覧資料.md').read_text(encoding='utf-8-sig')):
        path=(STUDY/match[1]).resolve();body=path.read_bytes();rows=list(csv.reader(io.StringIO(body.decode('utf-8-sig'))))
        csvs.append({'path':str(path.relative_to(ROOT)),'utf8_bom':body.startswith(b'\xef\xbb\xbf'),
            '行数':len(rows),'セル数':sum(map(len,rows)),'sha256':prepare.sha(path)})
    report={'成功':False,'段階':'正式保存完了後の最終QA','SourceSHA256':prepare.sha(Path(__file__)),
        '文書数':len(paths),'UTF8失敗':utf8,'リンク':check_links(paths),'汎用表':prepare.check_table(),
        '条件SHA固定':prepare.sha(STUDY/'条件.json')==index['条件SHA256']==prepare.EXPECTED_BOOK,
        '正式保存ファイル':formal,'ZIP全CRC':archives,'保存Sourceの関数コメント':python,
        'F0F1保存Source照合':check_checkpoints(members),'必須項目':mandatory,'旧160不変':old160(),
        'CSV':csvs,'CSV全セル':sum(r['セル数'] for r in csvs),
        '正式PNG':list(map(str,STUDY.rglob('*.png'))),'正式xlsx':list(map(str,STUDY.rglob('*.xlsx'))),
        '保存索引SHA256':prepare.sha(index_path),'確認文書SHA256':{str(p.relative_to(ROOT)):prepare.sha(p) for p in paths}}
    report['成功']=not utf8 and report['リンク']['成功'] and report['汎用表']['成功'] and report['条件SHA固定']\
        and all(r['一致'] for r in formal) and all(not r['元と相違'] for r in archives) and python['成功']\
        and report['F0F1保存Source照合']['成功'] and all(mandatory.values()) and report['旧160不変']['成功']\
        and len(csvs)==4 and all(r['utf8_bom'] for r in csvs) and report['CSV全セル']==93504\
        and not report['正式PNG'] and not report['正式xlsx']
    path=HERE/'最終文書と保存物の確認.json'
    assert not path.exists()
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':report['成功'],'文書数':len(paths),'リンク':report['リンク'],
        '保存指紋相違':[r for r in formal if not r['一致']],
        'Source相違':[r for r in archives if r['元と相違']],
        'コメント':python,'F0F1保存Source照合':report['F0F1保存Source照合'],
        '必須項目不備':[k for k,v in mandatory.items() if not v],
        '旧160不変':report['旧160不変']['成功'],'CSV全セル':report['CSV全セル']},ensure_ascii=False))


if __name__=='__main__':
    main()
