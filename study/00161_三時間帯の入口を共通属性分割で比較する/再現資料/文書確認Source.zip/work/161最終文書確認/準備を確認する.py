"""161の文書・コード規約の準備確認。対象文書を編集せず検査票だけ保存する。"""
from pathlib import Path
import ast
import hashlib
import json
import re
from urllib.parse import unquote

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
STUDY=ROOT/'study/00161_三時間帯の入口を共通属性分割で比較する'
OLD160=ROOT/'study/00160_入口を三時間帯で診断する'
V8=ROOT/'docs/議論/手法と時間スケールの汎用表_版8.md'
EXPECTED_BOOK='f22d735cefd0146aa4ec691a5adeeaf82c6961e746e88d7cdfd52fbcc25b46b8'


def sha(path: Path) -> str:
    """
    機能: 検査対象の物理SHA256を求める。
    引数: path (Path) 対象。返り値: str 型のSHA256。
    """
    with path.open('rb') as source:
        return hashlib.file_digest(source,'sha256').hexdigest()


# ----------------------------------------
def inventory(folder: Path) -> dict:
    """
    機能: 既存試行の全実体を相対pathと指紋だけで記録する。
    引数: folder (Path) 旧試行。返り値: dict[str,str] 型の指紋一覧。
    """
    return {str(p.relative_to(ROOT)):sha(p) for p in sorted(folder.rglob('*')) if p.is_file()}


# ----------------------------------------
def grid(path: Path) -> list:
    """
    機能: Markdownの手法ID行から見出しと9尺度を読み取る。
    引数: path (Path) 汎用表又は設定表。返り値: list[dict] 型の行。
    """
    result=[]
    section=path.read_text(encoding='utf-8-sig').split('## 手法×時間スケール',1)[1].split('\n## ',1)[0]
    for line in section.splitlines():
        if re.match(r'^\|\s*[A-Z]\d{2}\s*\|',line):
            cells=[c.strip() for c in line.split('|')[1:-1]]
            assert len(cells)==11,(str(path),cells[0],len(cells))
            match=re.fullmatch(r'\[([^]]+)\]\(([^)]+)\)',cells[1]);assert match
            target=(path.parent/unquote(match[2])).resolve()
            result.append({'id':cells[0],'name':match[1],'target':str(target),'cells':cells[2:]})
    return result


# ----------------------------------------
def check_table() -> dict:
    """
    機能: V8と161の63手法・9尺度・ラベル・リンク先・空欄を検査する。
    引数: なし。返り値: dict 型の表検査票。
    """
    source=grid(V8);target=grid(STUDY/'設定と結果.md')
    shape=len(source)==len(target)==63 and len({r['id'] for r in target})==63
    labels=[{k:r[k] for k in ('id','name','target')} for r in source]==[{k:r[k] for k in ('id','name','target')} for r in target]
    blanks=[(r['id'],i) for r in target for i,c in enumerate(r['cells']) if not c]
    missing=[r['target'] for r in target if not Path(r['target']).exists()]
    quoted=sha(V8) in (STUDY/'設定と結果.md').read_text(encoding='utf-8-sig')
    return {'成功':shape and labels and not blanks and not missing and quoted,
        '行数':len(target),'尺度':9,'セル数':len(target)*9,'ID名称リンク同体':labels,
        '空欄':blanks,'不存在リンク':missing,'V8引用SHA一致':quoted,'V8_SHA256':sha(V8)}


# ----------------------------------------
def python_files() -> list[Path]:
    """
    機能: 161に関係する新work Python Sourceを列挙する。
    引数: なし。返り値: list[Path] 型のSource一覧。
    """
    result=[]
    for p in (ROOT/'work').rglob('*.py'):
        rel=p.relative_to(ROOT/'work')
        if rel.parts[0].startswith('161') and not any(part in ('__pycache__','node_modules','site-packages') for part in rel.parts):
            result.append(p)
    return sorted(result)


# ----------------------------------------
def check_python(paths: list[Path]) -> dict:
    """
    機能: 関数の複数行日本語コメントと機能・引数・型・返り値の記載を静的確認する。
    引数: paths (list[Path]) Source一覧。返り値: dict 型の規約検査票。
    """
    issues=[];functions=0
    for path in paths:
        body=path.read_text(encoding='utf-8-sig');tree=ast.parse(body,filename=str(path))
        for node in ast.walk(tree):
            if not isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                continue
            functions+=1;doc=ast.get_docstring(node,clean=False);reasons=[]
            if doc is None:
                reasons.append('関数docstringなし')
            else:
                if len([s for s in doc.splitlines() if s.strip()])<2:reasons.append('複数行でない')
                for word in ('機能','引数','返り値'):
                    if word not in doc:reasons.append(word+'の記載なし')
                if '戻り値' in doc:reasons.append('禁止語の戻り値')
                if not re.search(r'[ぁ-んァ-ン一-龥]',doc):reasons.append('日本語でない')
                if '返り値' in doc and not re.search(r'返り値[^\n]*(?:None|bool|str|int|float|dict|list|tuple|set|object|Path|ndarray|numpy|np\.|型|FeatureDataset|FeatureMetadata|TeacherDataset|FileRef)',doc):
                    reasons.append('返り値の型表記を要目視確認')
                args=[a for a in (*node.args.posonlyargs,*node.args.args,*node.args.kwonlyargs) if a.arg not in ('self','cls')]
                if args and not re.search(r'引数[^。]*[\(（][^\n]*[\)）]',doc):
                    reasons.append('引数の型表記を要目視確認')
            if reasons:issues.append({'path':str(path.relative_to(ROOT)),'line':node.lineno,'function':node.name,'理由':reasons})
    return {'成功':not issues,'Source数':len(paths),'関数数':functions,'要確認':issues}


# ----------------------------------------
def main() -> None:
    """
    機能: 160の初期指紋と161準備検査票を新規保存する。
    引数: なし。返り値: None。対象文書は変更しない。
    """
    HERE.mkdir(exist_ok=True)
    baseline=HERE/'160の準備時点指紋.json'
    if not baseline.exists():
        baseline.write_text(json.dumps(inventory(OLD160),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    source_paths=python_files();utf8=[]
    text_paths=sorted({*source_paths,*[p for p in STUDY.rglob('*') if p.suffix in ('.md','.json','.py')]})
    for p in text_paths:
        try:p.read_text(encoding='utf-8-sig')
        except UnicodeError: utf8.append(str(p.relative_to(ROOT)))
    f0=json.loads((STUDY/'検査/F0_自然実行前.json').read_text(encoding='utf-8-sig'))
    condition=sha(STUDY/'条件.json')
    report={'段階':'正式保存前の準備確認','汎用表':check_table(),'Python規約':check_python(source_paths),
        'UTF8読取数':len(text_paths),'UTF8失敗':utf8,'条件SHA256':condition,
        '条件F0固定一致':condition==f0['条件SHA256']==EXPECTED_BOOK,
        'Source指紋':{str(p.relative_to(ROOT)):sha(p) for p in source_paths},
        '160初期指紋':str(baseline.relative_to(ROOT)),'160ファイル数':len(json.loads(baseline.read_text(encoding='utf-8')))}
    path=HERE/'準備確認.json'
    path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:report[k] for k in ('汎用表','Python規約','UTF8失敗','条件F0固定一致','160ファイル数')},ensure_ascii=False))


if __name__=='__main__':
    main()
