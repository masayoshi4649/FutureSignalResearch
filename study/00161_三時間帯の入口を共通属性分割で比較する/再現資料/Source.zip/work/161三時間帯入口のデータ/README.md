# 161の三時間帯入力部品

2026-11-14。旧151の全35,339適格q0・実BUY/SELL各100列・全体正準31,632物理pairを再用する。旧射影の完了pairは28,059、不完全pairは3,573、未取得q0は3,707である。これらは既存cacheの記録であり、161の新しい帯別・採否・金融結果ではない。旧Source、旧選択、旧成果物を変更しない。

## APIと時計

- `load_feature_dataset()` は固定4cacheのうち特徴NPZ/metadataだけを読む。`FeatureDataset` の100列・実側2配列・`q0_meta`・`scenes` は151と互換で、別配列 `q0_timeband` を追加する。Xにq1・取得成否・未来ラベル・C1フラグを加えない。
- `feature_meta()` はXを含めず、識別・場時計・帯の独立コピーを返す。
- `load_teacher_dataset(feature_meta)` は教師専用NPZ/metadataを読み、元の `rows`・`labels`・`pair_complete`・`known_at`・`event_to_teacher_index`・`canonical_feature_index` を保持する。`teacher_timeband` は全体正準の `canonical_feature_index` に対応する。ラベルはBUY/SELL順の-1/0/+1。不完全pairは両側NaNとknown_at NaNのまま。
- 定数は `DAY=0/PRE_US=1/POST_US=2`。ナイト開始日のAmerica/New_York09:30を境界に、判断q0の厳密前/等号以後を区分する。夏冬はIANA時計で自動変換する。デイは常に0。前後15分静観や境界返済を加えない。
- 物理q1の最早 `(q0_index,q0_line,event_id)` を旧151で全体正準化した後、その正準q0の帯へ所属させる。帯ごとの再正準化はしない。
- 現在/未来場の除外、過去20場窓、`max(BUY.endpoint.time,SELL.endpoint.time) < current_scene.start` のstrict成熟、支持下限・学習・採否は呼出側の責務である。同じ場の米国前を米国後の教師へ追加しない。
- 時間帯onehotの103列化はモデル側の責務であり、第2のテクニカル役割として数えない。

## 入力の指紋と復元

旧射影Source `work/151過去場判別/data151.py` のSHA256は `3b92ff77a28bf82e6cf8e5dc504cc5586f4101c1e28d0bc12b29bc7cd0efdd8c`。各cacheは `work/151過去場判別の評価/入口選択/cache/` の成功実行版であり、初回時計型停止のcacheは使用しない。

|相対path|bytes|物理SHA256|
|---|---:|---|
|feature_only/features.npz|11,077,409|5b309e0821403fcf1b122956fc6c9fe20ec5dfbe4327d7d674193b8e58f99b44|
|feature_only/features_meta.json|8,761,551|71df54db57a3093eb4de2f5ce26c654c758f9181e07f61660cb1a192f6fa4602|
|teacher_only/teachers.npz|185,781|ec613a27461c32d1aa09aed4ecf3b013c2d7dc827d86ba642385698547f22689|
|teacher_only/teachers_meta.json|20,818,639|3b723ca78d5ddc8ab4f301d5f9ba18ee08bea4e0159a085558296f824d736106|

NPZはpickle禁止・全メンバー読了CRC、JSONは標準外非有限値禁止。読取前後のstatと物理SHAを確認する。gzipを読むAPIでは解凍SHAと全CRCも確認する。

cacheは旧151の後発参照で、当時のF1事前固定ではない。[151の再現手順](../../study/00151_広い複合テクニカルを過去場だけで判別する/再現手順.md)を継承する。正式148の共有5入力は `FORMAL_REFS` に物理/解凍SHAを固定する。cacheが無い環境では、正式151資料からSHA同体の `data151.py` を隔離復元し、`load_feature_from_formal(source_path)` と `load_teacher_from_formal(feature_meta,source_path)` を明示実行する。再生成NPZのbytes同体は要求せず、返るX・全体正準・教師と既存参照の値同体を確認する。Rawを再走査せず、大観測の解凍副本も保存しない。

## C1の判断時計

152/153保存選択のC1全87は `event_id/feature_ref=null` であり、これだけではq0へ結べない。正式148 `入口参照.json.gz` の `entries[].origins[0].birthQuote` に当時出生があり、`entry_quote` に取得がある。`legacy_signals_from_metadata(metadata)` と `load_legacy_signals()` は `signal_quote` と `entry_quote` を別フィールドへ返す。これは148の全1分research q0とは別集合である。133観測側のbirth=entryは判断時計に使用しない。

81 C0の由来は `work/全成立poolの入力型を準備する/射影する.py:baseline` が137metadataの `birth.quote` と `entryQuote` を転送したもの。137の `verify_legacy` は出生までの方向refs、出生後1秒以上の取得を検査する。E1も当時 `event.at=birth` と公表refsを確認する。追加A0=2/B0=4は145の `validate_event` が当時出生・取得・30秒TTLを検査し、birthQuoteへ転送する。読み取り時のSource追跡による確認であり、Rawからの再実証ではない。

元137の固定方向では、反転側注文適格性は未再構築という制約を継承する。C1初参加補完を使う場合は、純粋な新入口政策と区別した固定対照由来の補完である。旧信号時点より前に取得済みかどうかの判定は、呼出側が当時時計で行う。本部品は採否を計算しない。

## 検査と停止

`test_data161.py` の人工6群で夏冬境界・NaN/0・全体正準の境界跨ぎalias・不完全pair・改変拒否・C1時計を確認する。`prepare_data161.py` は構文/関数コメント・UTF-8・Source前後一致と人工成功を記録する。自然共有データの帯射影・学習・採否・金融はRootの161 F0後通知まで実行しない。既使用73場だけを扱い、未見11/10ナイト・11/11デイと156を使用しない。
