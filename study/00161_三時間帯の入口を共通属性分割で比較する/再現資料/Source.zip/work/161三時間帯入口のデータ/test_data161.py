"""161入力部品を自然ファイル未読の人工時計・人工配列だけで確認する。"""
from datetime import datetime, timedelta
from pathlib import Path
from tempfile import TemporaryDirectory
from zoneinfo import ZoneInfo
import copy
import hashlib
import json
import unittest

import numpy as np

import data161 as D


# ----------------------------------------
def fixture() -> tuple:
    """
    機能: 夏冬境界と同q1の境界跨ぎaliasを含む小さな人工入力を作る。
    引数: なし。
    返り値: tupleはFeatureDataset・教師配列・教師metadata。
    """
    scenes, q0 = [], []
    for date, kind in (("2026-10-30", "Day"), ("2026-10-30", "Night"), ("2026-11-02", "Night")):
        base = datetime.fromisoformat(date).replace(tzinfo=ZoneInfo("Asia/Tokyo"))
        start = base + (timedelta(hours=8, minutes=45) if kind == "Day" else timedelta(hours=17))
        end = base + (timedelta(hours=15, minutes=45) if kind == "Day" else timedelta(days=1, hours=6))
        sid = date + "_" + kind
        scenes.append({"session": sid, "contract": "人工", "start": start.timestamp(), "end": end.timestamp(), "force_close": end.timestamp()-600})
    for scene_index, offsets in ((0, [3600]), (1, [-1, 0, 1]), (2, [0])):
        scene = scenes[scene_index]
        boundary = D.us_open_time(scene["session"]) or scene["start"]
        for offset in offsets:
            i = len(q0)
            q0.append({"event_id": "人工"+str(i), "session": scene["session"], "contract": "人工", "session_index": scene_index, "q0_time": boundary+offset, "q0_index": i+1, "q0_line": i+2})
    buy = np.arange(500, dtype=np.float64).reshape(5, 100)
    sell = -buy.copy()
    buy[0, 0] = np.nan
    sell[0, 1] = np.nan
    features = D.feature_dataset_from_objects(["人工%03d" % i for i in range(100)], buy, sell, q0, scenes)
    rows = []
    for fi, aliases, complete in ((0, [0], False), (1, [1, 2], True), (4, [4], False)):
        row = {**q0[fi], "case_id": "case"+str(fi), "feature_index": fi, "aliases": [q0[i]["event_id"] for i in aliases], "alias_feature_indices": aliases, "case_aliases": ["case"+str(fi)], "pair_complete": complete, "label_buy": 1 if complete else None, "label_sell": -1 if complete else None, "known_at": q0[fi]["q0_time"]+3601 if complete else None}
        rows.append(row)
    arrays = {"labels": np.array([[np.nan, np.nan], [1., -1.], [np.nan, np.nan]]), "pair_complete": np.array([False, True, False]), "known_at": np.array([np.nan, rows[1]["known_at"], np.nan]), "event_to_teacher_index": np.array([0, 1, 1, -1, 2], dtype=np.int64), "canonical_feature_index": np.array([0, 1, 4], dtype=np.int64), "side_order": np.array([1, -1])}
    meta = {"success": True, "trial": 151, "rows": rows, "counts": {}, "sources": {}, "side_order": [1, -1]}
    return features, arrays, meta


def artificial_legacy() -> dict:
    """
    機能: 観測birthではなく正式入口参照のorigins.birthQuoteを模した人工票を作る。
    引数: なし。
    返り値: dictは1件のC0出生と取得を分離した148形式。
    """
    birth = {"time": 100, "index": 2, "source_line": 3, "bid": 1000, "ask": 1010, "quote_ok": True}
    entry = {**birth, "time": 102, "index": 4, "source_line": 5}
    origin = {"birthQuote": birth, "entryQuote": entry, "birth_quote_source": "metadata.birth.quote", "source_locator": {"file": "人工", "entry_index": 0}, "source_file_sha": "0"*64, "original_execution": "人工の固定方向"}
    return {"success": True, "trial": 148, "financial_labels_used": False, "entries": [{"id": "人工C1", "session": "2026-10-30_Day", "contract": "人工", "model": "C0", "native_side": -1, "entry_quote": entry, "origins": [origin]}]}


# ----------------------------------------
class DataTests(unittest.TestCase):
    def test_clock(self) -> None:
        """
        機能: NY夏冬変換と境界等号以後を人工時計で確認する。
        引数: self(DataTests)。
        返り値: None。
        """
        summer = D.us_open_time("2026-10-30_Night")
        winter = D.us_open_time("2026-11-02_Night")
        self.assertEqual(datetime.fromtimestamp(summer, ZoneInfo("Asia/Tokyo")).strftime("%H:%M"), "22:30")
        self.assertEqual(datetime.fromtimestamp(winter, ZoneInfo("Asia/Tokyo")).strftime("%H:%M"), "23:30")
        self.assertEqual([D.timeband("2026-10-30_Night", summer+d) for d in (-1, 0, 1)], [1, 2, 2])
        self.assertEqual(D.timeband("2026-10-30_Day", summer), 0)
        with self.assertRaises(AssertionError):
            D.timeband("2026-10-30_Night", float("nan"))

    def test_features(self) -> None:
        """
        機能: 実買/実売のNaNと0を保持し特徴/教師の型とコピーを分離する。
        引数: self(DataTests)。
        返り値: None。
        """
        data, _, _ = fixture()
        self.assertEqual(data.q0_timeband.tolist(), [0, 1, 2, 2, 2])
        self.assertTrue(np.isnan(data.buy_X[0, 0]))
        self.assertTrue(np.isnan(data.sell_X[0, 1]))
        self.assertEqual(data.sell_X[0, 0], 0)
        meta = data.feature_meta()
        self.assertFalse(hasattr(meta, "buy_X"))
        meta.q0_meta[0]["event_id"] = "変更"
        meta.q0_timeband[0] = 2
        self.assertEqual(data.q0_meta[0]["event_id"], "人工0")
        self.assertEqual(data.q0_timeband[0], 0)
        corrupted = data.buy_X.copy()
        corrupted[0, 0] = np.inf
        with self.assertRaises(AssertionError):
            D.feature_dataset_from_objects(data.columns, corrupted, data.sell_X, data.q0_meta, data.scenes)

    def test_global_canonical(self) -> None:
        """
        機能: 境界を跨いだaliasでも全体最早q0の物理教師を一度だけ保持する。
        引数: self(DataTests)。
        返り値: None。
        """
        features, arrays, meta = fixture()
        teachers = D.teacher_dataset_from_objects(features.feature_meta(), arrays, meta)
        self.assertEqual(teachers.teacher_timeband.tolist(), [0, 1, 2])
        self.assertEqual(teachers.event_to_teacher_index.tolist(), [0, 1, 1, -1, 2])
        self.assertTrue(np.isnan(teachers.labels[0]).all())
        self.assertEqual(teachers.known_at[1], meta["rows"][1]["known_at"])
        changed = copy.deepcopy(meta)
        changed["rows"][1]["alias_feature_indices"] = [2, 1]
        with self.assertRaises(AssertionError):
            D.teacher_dataset_from_objects(features.feature_meta(), arrays, changed)
        changed_arrays = {**arrays, "pair_complete": np.array([0, 2, 0])}
        with self.assertRaises(AssertionError):
            D.teacher_dataset_from_objects(features.feature_meta(), changed_arrays, meta)

    def test_label_integrity(self) -> None:
        """
        機能: 不完全pairの片側ラベル・成熟時計・event対応の改変を拒否する。
        引数: self(DataTests)。
        返り値: None。
        """
        features, arrays, meta = fixture()
        for key, index, value in (("labels", (0, 0), 1), ("known_at", 0, 100), ("event_to_teacher_index", 3, 0), ("canonical_feature_index", 1, 2)):
            altered = {k: v.copy() for k, v in arrays.items()}
            altered[key][index] = value
            with self.assertRaises(AssertionError):
                D.teacher_dataset_from_objects(features.feature_meta(), altered, meta)

    def test_file_fingerprints(self) -> None:
        """
        機能: 人工ファイルの指紋不一致・JSON非有限値・NPZのobject配列を拒否する。
        引数: self(DataTests)。
        返り値: None。
        """
        with TemporaryDirectory() as directory:
            path = Path(directory) / "人工.json"
            path.write_text("{\"人工\": 1}", encoding="utf-8")
            ref = D.FileRef(path, D.sha(path))
            value, evidence = D.read_json_ref(ref)
            self.assertEqual(value, {"人工": 1})
            self.assertEqual(evidence["stat_before"], evidence["stat_after"])
            path.write_text("{\"人工\": 2}", encoding="utf-8")
            with self.assertRaises(AssertionError):
                D.read_json_ref(ref)
            path.write_text("{\"人工\": NaN}", encoding="utf-8")
            with self.assertRaises(ValueError):
                D.read_json_ref(D.FileRef(path, D.sha(path)))
            npz = Path(directory) / "人工.npz"
            np.savez(npz, a=np.array([1.0, np.nan]))
            values, _ = D.read_npz_ref(D.FileRef(npz, D.sha(npz)), {"a"})
            self.assertTrue(np.isnan(values["a"][1]))
            np.savez(npz, a=np.array([{}], dtype=object))
            with self.assertRaises(ValueError):
                D.read_npz_ref(D.FileRef(npz, D.sha(npz)), {"a"})

    def test_legacy_clock(self) -> None:
        """
        機能: C1の判断/取得を区別し観測birth=entry・同原行重複を拒否する。
        引数: self(DataTests)。
        返り値: None。
        """
        metadata = artificial_legacy()
        rows = D.legacy_signals_from_metadata(metadata, 1)
        self.assertEqual(rows[0]["signal_quote"]["time"], 100)
        self.assertEqual(rows[0]["entry_quote"]["time"], 102)
        self.assertEqual(rows[0]["side"], -1)
        rows[0]["signal_quote"]["time"] = 0
        self.assertEqual(metadata["entries"][0]["origins"][0]["birthQuote"]["time"], 100)
        metadata["entries"][0]["origins"][0]["birthQuote"] = copy.deepcopy(metadata["entries"][0]["entry_quote"])
        with self.assertRaises(AssertionError):
            D.legacy_signals_from_metadata(metadata, 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
