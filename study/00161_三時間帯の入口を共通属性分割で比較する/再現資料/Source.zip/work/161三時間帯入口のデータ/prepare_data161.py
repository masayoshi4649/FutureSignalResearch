"""161のデータ部品を人工入力だけで確認しSource停止票を作る。"""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys

import numpy as np

HERE = Path(__file__).resolve().parent


# ----------------------------------------
def sha(path: Path) -> str:
    """
    機能: 小型Sourceの物理bytesを指紋化する。
    引数: path(Path)は確認対象。
    返り値: strは小文字SHA256。
    """
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    """
    機能: 自然入力未読の人工検査とSource前後一致を記録し部品を停止する。
    引数: なし。
    返り値: None。未作成の準備票と停止票をUTF-8で作る。
    """
    paths = [HERE/name for name in ("data161.py", "test_data161.py", "README.md", "prepare_data161.py")]
    before = {p.name: sha(p) for p in paths}
    for path in paths:
        if path.suffix == ".py":
            tree = ast.parse(path.read_text(encoding="utf-8"))
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    text = ast.get_docstring(node)
                    assert text and "\n" in text and all(word in text for word in ("機能", "引数", "返り値")), (path.name, node.name)
    command = [sys.executable, "-B", "-X", "utf8", str(HERE/"test_data161.py")]
    process = subprocess.run(command, capture_output=True, cwd=HERE, env={**os.environ, "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8", "PYTHONDONTWRITEBYTECODE": "1"})
    stdout, stderr = process.stdout.decode("utf-8", "strict"), process.stderr.decode("utf-8", "strict")
    assert process.returncode == 0 and "\ufffd" not in stdout+stderr
    assert before == {p.name: sha(p) for p in paths}
    proof = {"成功": True, "試行": 161, "対象": "データ部品のみ", "人工主検査数": 6, "構文と関数コメント": True, "UTF8_strict": True, "自然共有特徴の新帯射影": False, "自然教師の新帯射影": False, "自然学習": False, "自然採否": False, "金融": False, "旧Source変更": False, "追加2場": False, "読み取り調査": "旧cacheの既存件数/物理指紋とC1保存時計の由来のみ確認済み。新帯別集計なし。", "python": sys.version, "numpy": np.__version__, "実行": {"引数": command, "終了値": process.returncode, "標準出力": stdout, "標準エラー": stderr}, "源": [{"name": p.name, "bytes": p.stat().st_size, "sha256": before[p.name]} for p in paths], "全源前後一致": True, "自然実行": "Rootの161 F0後通知待ち"}
    target = HERE/"データ準備の確認.json"
    with target.open("x", encoding="utf-8", newline="\n") as output:
        json.dump(proof, output, ensure_ascii=False, indent=2, allow_nan=False)
        output.write("\n")
    stop = {"成功": True, "編集停止": True, "準備票SHA256": sha(target), "源": before}
    with (HERE/"データ部品の停止.json").open("x", encoding="utf-8", newline="\n") as output:
        json.dump(stop, output, ensure_ascii=False, indent=2)
        output.write("\n")
    print(json.dumps({"成功": True, "data161_SHA256": before["data161.py"], "準備票SHA256": sha(target), "停止票SHA256": sha(HERE/"データ部品の停止.json")}, ensure_ascii=False))


if __name__ == "__main__":
    main()
