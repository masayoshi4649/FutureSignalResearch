"""161の共通モデル・旧政策を151/152/153正式正本へ照合する。探索と損益計算はしない。"""
from pathlib import Path
from zipfile import ZipFile
import argparse
import gzip
import hashlib
import json

ROOT=Path(__file__).resolve().parents[2]
OLD151=ROOT/'inputs/00151_過去場だけの複合判別/学習と選択の正本.zip'
OLD151_SHA='61e4826a61e06440b7914b3e9eff0539ab5f8632d389a83515108f9a46f423cb'
OLD152=ROOT/'inputs/00152_複合回復の方向切替/選択対応.json.gz'
OLD152_SHA='8f7815505f3a0bc158d738a128df1b7d9a140455aa5178ba7f1b8b1eb447032b'
OLD152_DECODED='d77fcb20976b6207039e31912058894fdf1cc31c7aaae604739df82d2d74110c'
OLD153=ROOT/'inputs/00153_先行高安の独立出生/選択対応.json.gz'
OLD153_SHA='3ffdab0cfd846e250473206b2e55c9cd45a8b18e1c9a73285537319aa1e99334'
OLD153_DECODED='bf5a29225a69e4e8837df9d8b34f263adb59f43ee70908e7668cc35a1a97a758'
Q0_KEYS=('event_id','session','contract','session_index','q0_time','q0_index','q0_line')
POLICIES=(('COMMON_P65_N',151,'P65'),('COMMON_P65_U',151,'U65'),
    ('COMMON_P65_A_N',152,'A0'),('COMMON_P65_A_U',152,'U0'),
    ('OLD152_B0_N',152,'B0'),('OLD152_U1',152,'U1'),
    ('OLD153_N15',153,'N15'),('OLD153_U15',153,'U15'))
IDENTITY_KEYS=('case_id','session','side','stream','event_id','feature_ref')
OPTIONAL_CLOCK_KEYS=('q0_time','q0_index','q0_line')


def sha(path: Path) -> str:
    """
    機能: ファイル全体の物理SHA256を計算する。
    引数: path (Path) 対象ファイル。返り値: str 型の小文字SHA256。
    """
    with path.open('rb') as source:
        return hashlib.file_digest(source,'sha256').hexdigest()


# ----------------------------------------
def state(path: Path) -> tuple:
    """
    機能: 読取前後の同一ファイル確認に使うstatを取得する。
    引数: path (Path)。返り値: tuple 型のdevice/inode/サイズ/更新nanosecond。
    """
    value=path.stat()
    return tuple(getattr(value,k) for k in ('st_dev','st_ino','st_size','st_mtime_ns'))


# ----------------------------------------
def reject_constant(token: str) -> None:
    """
    機能: 非標準JSONの非有限数を拒否する。
    引数: token (str) 解析器が受けた値。返り値: None。常に例外を送出する。
    """
    raise ValueError('非標準JSON: '+token)


# ----------------------------------------
def canonical_sha(value: object) -> str:
    """
    機能: JSON意味値をキー順固定で指紋化する。
    引数: value (object) JSONに変換可能な値。返り値: str 型のSHA256。
    """
    body=json.dumps(value,ensure_ascii=False,allow_nan=False,sort_keys=True,separators=(',',':')).encode('utf-8')
    return hashlib.sha256(body).hexdigest()


# ----------------------------------------
def structure_sha(value: dict) -> str:
    """
    機能: CatBoostの日時等メタデータを除いた構造指紋を旧151と同じ算式で計算する。
    引数: value (dict) 公開JSONモデル。返り値: str 型の構造SHA256。
    """
    stable={k:value[k] for k in ('features_info','oblivious_trees','scale_and_bias')}
    return hashlib.sha256(json.dumps(stable,sort_keys=True,separators=(',',':')).encode()).hexdigest()


# ----------------------------------------
def read_json(path: Path,expected_sha: str|None=None,expected_decoded: str|None=None) -> tuple:
    """
    機能: 全CRC・前後stat・物理/任意解凍SHAを確認してJSONを読む。
    引数: path (Path)、expected_sha/expected_decoded (str|None) 固定指紋。
    返り値: tuple の意味値と読取証跡。入力を複製又は変更しない。
    """
    before=state(path);physical=sha(path)
    assert expected_sha is None or physical==expected_sha
    with (gzip.open(path,'rb') if path.suffix=='.gz' else path.open('rb')) as source:
        body=source.read()
    decoded=hashlib.sha256(body).hexdigest()
    assert expected_decoded is None or decoded==expected_decoded
    value=json.loads(body,parse_constant=reject_constant)
    assert state(path)==before and sha(path)==physical
    return value,{'path':str(path.relative_to(ROOT)) if path.is_relative_to(ROOT) else str(path),
        'sha256':physical,'decoded_sha256':decoded,'physical_bytes':before[2],
        'decoded_bytes':len(body),'stat_before':list(before),'stat_after':list(state(path)),
        'full_crc_checked':path.suffix=='.gz'}


# ----------------------------------------
def read_old151() -> tuple:
    """
    機能: 固定151 ZIPを全member完読し、q0・教師監査・政策・65モデルを直接取り出す。
    引数: なし。返り値: tuple の正本辞書とCRC/指紋証跡。ディスク展開しない。
    """
    before=state(OLD151)
    assert sha(OLD151)==OLD151_SHA
    result={};models={};members=[]
    with ZipFile(OLD151) as archive:
        infos=archive.infolist();assert len(infos)==len({i.filename for i in infos})==69
        for info in infos:
            assert not info.is_dir()
            body=archive.read(info.filename)
            value=json.loads(body,parse_constant=reject_constant)
            members.append({'name':info.filename,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'crc32':info.CRC})
            leaf=Path(info.filename).name
            if '/models/' in info.filename:
                index=int(Path(leaf).stem);assert index not in models
                models[index]=value
            else:
                assert leaf in ('q0の判断.json','場別モデルと教師.json','選択対応.json','選択の確認.json')
                assert leaf not in result;result[leaf]=value
    assert len(models)==65 and sorted(models)==list(range(8,73))
    assert state(OLD151)==before and sha(OLD151)==OLD151_SHA
    result['models']=models
    return result,{'path':str(OLD151.relative_to(ROOT)),'sha256':OLD151_SHA,
        'physical_bytes':before[2],'stat_before':list(before),'stat_after':list(state(OLD151)),
        'all_members_crc_checked':True,'members':members}


# ----------------------------------------
def preview(value: object) -> str:
    """
    機能: 不一致の内容を巨大転記せず短く示す。
    引数: value (object) 不一致値。返り値: str 型の先頭200文字。
    """
    return json.dumps(value,ensure_ascii=False,allow_nan=False,sort_keys=True)[:200]


# ----------------------------------------
def compare_part(name: str,old: object,new: object) -> dict:
    """
    機能: 固定射影値の完全同体と両指紋を記録する。
    引数: name (str)、old/new (object) 比較値。
    返り値: dict 型の結果。許容誤差を置かずJSON意味値を照合する。
    """
    old_sha=canonical_sha(old);new_sha=canonical_sha(new)
    result={'比較':name,'一致':old_sha==new_sha,'旧SHA256':old_sha,'新SHA256':new_sha}
    if old_sha!=new_sha:
        result.update(旧の先頭=preview(old),新の先頭=preview(new))
    return result


# ----------------------------------------
def common_decision(row: dict) -> dict:
    """
    機能: 161の共通原判断を旧151の決定schemaへ名称だけ正規化する。
    引数: row (dict) 新しい一つのq0判断。
    返り値: dict 型の旧151同形決定。追加メタデータは比較対象外と明記する。
    """
    raw=row['decision'];prediction=row['predictions']['COMMON']
    directions={name:raw['directions']['COMMON_'+name] for name in ('P70','P65','P60')}
    conflicts={name:raw['conflicts']['COMMON_'+name] for name in ('P70','P65','P60')}
    directions['N70']=directions['P70'];conflicts['N70']=conflicts['P70']
    model_id=row['session_index'] if prediction['model_id'] is not None else None
    assert prediction['model_id']==(f"{row['session_index']:03d}_COMMON" if model_id is not None else None)
    assert prediction['requested_mode']=='COMMON' and prediction['fallback'] is False
    assert prediction['effective_mode']==('COMMON' if model_id is not None else 'WAIT')
    evidence=[]
    for source in raw['evidence']:
        if source['rule'].startswith('COMMON_'):
            assert source['model_id']==prediction['model_id']
            evidence.append({'rule':source['rule'].removeprefix('COMMON_'),'signal_side':source['signal_side'],
                'order_side':source['order_side'],'roles':source['roles'],'model_id':model_id})
    return {'directions':directions,'conflicts':conflicts,'evidence':evidence}


# ----------------------------------------
def compare_learning(old_q0: dict,old_audits: dict,old_models: dict,new_q0: dict,
                     new_audits: dict,new_models: dict) -> dict:
    """
    機能: 共通の全q0確率/決定と場ごとの学習配列/実モデル構造を正本へ照合する。
    引数: old_q0/old_audits/old_models/new_q0/new_audits/new_models (dict) 意味値。
    返り値: dict 型の比較票。損益、選別、未見性能を評価しない。
    """
    old_rows=old_q0['rows'];new_rows=new_q0['rows']
    comparisons=[compare_part('q0の順序と識別時計',
        [{k:r[k] for k in Q0_KEYS} for r in old_rows],[{k:r[k] for k in Q0_KEYS} for r in new_rows]),
        compare_part('全q0のCOMMON確率・score・理由・技術役割・閾値方向',
            [r['prediction'] for r in old_rows],[r['predictions']['COMMON']['prediction'] for r in new_rows]),
        compare_part('全q0のdecision（COMMON接頭辞とN70別名を正規化）',
            [r['decision'] for r in old_rows],[common_decision(r) for r in new_rows]),
        compare_part('全q0のモデル所属',
            [r['model_id'] for r in old_rows],
            [r['session_index'] if r['predictions']['COMMON']['model_id'] is not None else None for r in new_rows])]
    old_scenes=old_audits['scenes'];new_scenes=new_audits['rows']
    assert len(old_scenes)==len(new_scenes)
    compared=[];ready=0
    scalar_keys=('ready','ready_reasons','window','physical_pair_count','contributing_sessions','classes',
        'active_block_count','blocks','max_label_known_at','side_weight_mean')
    for old,new in zip(old_scenes,new_scenes,strict=True):
        index=old['session_index'];common=new['models']['COMMON']
        parts=[compare_part('場時計',
            {k:old[k] for k in ('session_index','session','current_start','all_current_feature_rows')},
            {k:new[k] for k in ('session_index','session','current_start','all_current_feature_rows')}),
            compare_part('共通教師の窓・成熟・支持・区画重み',
                {k:old[k] for k in scalar_keys},{k:common[k] for k in scalar_keys}),
            compare_part('判断理由件数',old['prediction_reasons'],new['prediction_reasons']['COMMON'])]
        fi=old['training_feature_indices']
        fi_sha=hashlib.sha256(json.dumps(fi,separators=(',',':')).encode()).hexdigest()
        parts.append(compare_part('学習feature_indicesSHA256',fi_sha,common['training_feature_indices_sha256']))
        if old['ready']:
            ready+=1;old_ref=old['model'];new_ref=common['model']
            for key in ('training_array_sha256','structure_sha256','used_indices','used_columns','classes','parameters','catboost'):
                parts.append(compare_part(key,old_ref[key],new_ref[key]))
            parts.append(compare_part('旧実モデルの構造と旧記録',old_ref['structure_sha256'],structure_sha(old_models[index])))
            parts.append(compare_part('新実モデルの構造と新記録',new_ref['structure_sha256'],structure_sha(new_models[index])))
            parts.append(compare_part('旧新の実モデル構造',structure_sha(old_models[index]),structure_sha(new_models[index])))
        else:
            parts.append(compare_part('未準備時モデルなし',old['model'],common['model']))
        compared.append({'session_index':index,'session':old['session'],'一致':all(p['一致'] for p in parts),'比較':parts})
    assert sorted(new_models)==sorted(old_models)
    return {'成功':all(p['一致'] for p in comparisons) and all(p['一致'] for p in compared),
        '範囲':'旧151の固定100特徴・過去20場分類器・P70/P65/P60原判断を161 COMMONが再現するか。',
        '全q0数':len(old_rows),'場数':len(compared),'学習モデル数':ready,
        '確率比較':'許容誤差なし。保存JSONの全買売確率と判断を完全同体照合。',
        '名称の正規化':'COMMON_接頭辞を除去。N70=P70の旧別名を復元。model_idの003_COMMON形式を整数へ写す。',
        '比較しない新メタデータ':'q0帯、要求/実効方式、fallback、証拠の方式属性。モデル物理bytesは学習時刻メタデータを含むため旧新同体を要求しない。',
        '全q0比較':comparisons,'場別比較':compared}


# ----------------------------------------
def policy_projection(rows: list[dict]) -> list[dict]:
    """
    機能: 政名・追加証跡を除き、取得物理IDと方向・出生時計を比較用に射影する。
    引数: rows (list[dict]) 一政策の取得集合。
    返り値: list[dict] 型のcase_id順射影。重複caseを拒否する。
    """
    assert len(rows)==len({r['case_id'] for r in rows})
    return sorted([{**{k:r[k] for k in IDENTITY_KEYS},
        **{k:r[k] for k in OPTIONAL_CLOCK_KEYS if k in r}} for r in rows],key=lambda r:r['case_id'])


# ----------------------------------------
def compare_selections(new: dict,old: dict[int,dict],policies: tuple=POLICIES) -> dict:
    """
    機能: 161の再現対照を151/152/153の固定取得集合へ照合する。
    引数: new (dict) 161選択、old (dict[int,dict]) 旧3試行選択、policies (tuple) 対応。
    返り値: dict 型の全8対照票。成立証跡の名称変更や新signal_quoteは比較しない。
    """
    comparisons=[]
    for new_name,trial,old_name in policies:
        old_rows=old[trial]['政策'][old_name];new_rows=new['政策'][new_name]
        item=compare_part(f'{new_name}=旧{trial}/{old_name}',policy_projection(old_rows),policy_projection(new_rows))
        item.update(旧試行=trial,旧政策=old_name,新政策=new_name,旧件数=len(old_rows),新件数=len(new_rows))
        comparisons.append(item)
    return {'成功':all(p['一致'] for p in comparisons),'政策比較数':len(comparisons),'比較':comparisons,
        '必須比較列':list(IDENTITY_KEYS),'時計比較列':list(OPTIONAL_CLOCK_KEYS),
        '集合比較':'case_id順へ正規化し、政策内の取得順序は成績の根拠としない。重複caseは禁止。',
        '比較しない列':'origin/成立ID/evidenceの新政策名と追加メタデータ、C1に追加されたsignal_quote。',
        '範囲':'主要151/152/153の指定政策の再現であり、過去全探索の有効性・将来優位・未見性能の証明ではない。'}


# ----------------------------------------
def main() -> None:
    """
    機能: 完了済み161と固定旧正本を照合し、新規JSON票だけ保存する。
    引数: CLI --learning-dir (Path)、--selection (Path|None)、--selection-only (bool)、--output (Path)。
    返り値: None。不一致時は失敗票を保存して終了code1とする。学習・損益計算はしない。
    """
    parser=argparse.ArgumentParser(description='161の主要旧探索再現を正式正本と照合する')
    parser.add_argument('--learning-dir',type=Path,default=ROOT/'work/161三時間帯入口/自然学習')
    parser.add_argument('--selection',type=Path)
    parser.add_argument('--selection-only',action='store_true')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    assert not args.output.exists()
    assert not args.selection_only or args.selection is not None
    old151,proof151=read_old151();report={'成功':True,'試行':161,'旧151正式ZIP':proof151,
        '照合SourceSHA256':sha(Path(__file__)),'自然学習・金融・探索を実施':False}
    if not args.selection_only:
        completed,completed_proof=read_json(args.learning_dir/'学習完了.json')
        assert completed['成功'] and completed['判断数']==35339 and completed['場数']==73
        nq,pq=read_json(args.learning_dir/'q0の判断.json.gz',completed['出力SHA256']['q0の判断.json.gz'])
        na,pa=read_json(args.learning_dir/'場別モデルと教師.json.gz',completed['出力SHA256']['場別モデルと教師.json.gz'])
        models={};model_proofs=[]
        for scene in na['rows']:
            ref=scene['models']['COMMON']['model']
            if ref is not None:
                index=scene['session_index'];value,proof=read_json(args.learning_dir/'models'/ref['model_file'],ref['physical_sha256'])
                models[index]=value;model_proofs.append(proof)
        result=compare_learning(old151['q0の判断.json'],old151['場別モデルと教師.json'],old151['models'],nq,na,models)
        assert result['全q0数']==35339 and result['場数']==73 and result['学習モデル数']==65
        report.update(学習比較=result,新学習入力証跡={'完了':completed_proof,'q0':pq,'監査':pa,'共通実モデル':model_proofs})
    if args.selection is not None:
        new,pn=read_json(args.selection)
        old152,p152=read_json(OLD152,OLD152_SHA,OLD152_DECODED)
        old153,p153=read_json(OLD153,OLD153_SHA,OLD153_DECODED)
        result=compare_selections(new,{151:old151['選択対応.json'],152:old152,153:old153})
        report.update(取得比較=result,選択入力証跡={'旧152':p152,'旧153':p153,'新161':pn})
    report['成功']=all(report[k]['成功'] for k in ('学習比較','取得比較') if k in report)
    report['限界']='固定151/152/153の指定範囲の再現。旧研究の先読み・約定・費用・未見性能・全探索の妥当性を新たに証明する票ではない。'
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,ensure_ascii=False,allow_nan=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'成功':report['成功'],'保存先':str(args.output),
        '学習比較':'学習比較' in report,'取得比較':'取得比較' in report},ensure_ascii=False),flush=True)
    if not report['成功']:
        raise SystemExit(1)


if __name__=='__main__':
    main()
