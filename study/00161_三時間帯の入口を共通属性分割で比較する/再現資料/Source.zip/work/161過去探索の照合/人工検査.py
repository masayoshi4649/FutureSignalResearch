"""照合器が完全一致を受理し、確率・構造・取得の違いを拒否することを人工確認する。"""
from pathlib import Path
import copy
import hashlib
import json

import 照合する as check


def fixture() -> tuple:
    """
    機能: 学習や自然入力を要しない一場二q0の比較資料を作る。
    引数: なし。返り値: tuple 型の旧新q0・監査・モデル6資料。
    """
    actual={'features_info':{'float_features':[]},'oblivious_trees':[{'splits':None,'leaf_values':[0,1,2]}],
            'scale_and_bias':[1,[0,0,0]]}
    ref={'training_array_sha256':'a'*64,'structure_sha256':check.structure_sha(actual),
         'used_indices':[4,5],'used_columns':['構造','勢い'],'classes':[0,1,2],
         'parameters':{'人工':True},'catboost':'1.2.10'}
    old_rows=[];new_rows=[]
    for i in range(2):
        q0={'event_id':f'人工{i}','session':'人工場','contract':'人工限月','session_index':0,
            'q0_time':100+i,'q0_index':i,'q0_line':i+1}
        vote={'directions':{'P70':1,'P65':1,'P60':1},'probabilities':{'buy':[.1,.2,.7],'sell':[.6,.3,.1]},
            'selected_side':1,'reason':'selected','known_roles':['勢い','構造']}
        directions={**vote['directions'],'N70':1};evidence=[];new_evidence=[]
        for name in vote['directions']:
            entry={'rule':name,'signal_side':1,'order_side':1,'roles':['勢い','構造'],'model_id':0}
            evidence.append(entry)
            new_evidence.append({**entry,'rule':'COMMON_'+name,'model_id':'000_COMMON','effective_mode':'COMMON'})
        old_rows.append({**q0,'model_id':0,'prediction':copy.deepcopy(vote),
            'decision':{'directions':directions,'conflicts':{k:False for k in directions},'evidence':evidence}})
        new_rows.append({**q0,'predictions':{'COMMON':{'prediction':copy.deepcopy(vote),
            'model_id':'000_COMMON','requested_mode':'COMMON','effective_mode':'COMMON','fallback':False}},
            'decision':{'directions':{'COMMON_'+k:v for k,v in vote['directions'].items()},
                'conflicts':{'COMMON_'+k:False for k in vote['directions']},'evidence':new_evidence}})
    audit={'session_index':0,'session':'人工場','current_start':90,'all_current_feature_rows':2,
        'ready':True,'ready_reasons':[],'window':{'limit':20},'physical_pair_count':1000,
        'contributing_sessions':list(range(8)),'classes':[-1,0,1],'active_block_count':8,'blocks':[],
        'max_label_known_at':89,'side_weight_mean':1,'training_feature_indices':[0,1],
        'model':copy.deepcopy(ref),'prediction_reasons':{'selected':2}}
    common={k:copy.deepcopy(v) for k,v in audit.items() if k not in
        ('session_index','session','current_start','all_current_feature_rows','training_feature_indices','prediction_reasons')}
    common['training_feature_indices_sha256']=hashlib.sha256(b'[0,1]').hexdigest()
    new_audit={k:audit[k] for k in ('session_index','session','current_start','all_current_feature_rows')}
    new_audit.update(models={'COMMON':common},prediction_reasons={'COMMON':audit['prediction_reasons']})
    return {'rows':old_rows},{'scenes':[audit]},{0:actual},{'rows':new_rows},{'rows':[new_audit]},{0:copy.deepcopy(actual)}


# ----------------------------------------
def selection_fixture() -> tuple:
    """
    機能: 政名と補足証跡だけが異なる人工8対照を作る。
    引数: なし。返り値: tuple 型の新政策・旧試行別政策。
    """
    old={t:{'政策':{}} for t in (151,152,153)};new={'政策':{}}
    for name,trial,policy in check.POLICIES:
        row={'case_id':f'人工{trial}/{policy}','session':'人工場','side':1,'stream':'original',
            'event_id':'人工出生','feature_ref':'人工出生','q0_time':100,'q0_index':1,'q0_line':2}
        old[trial]['政策'][policy]=[row]
        new['政策'][name]=[{**row,'origin':name,'signal_quote':{'time':100}}]
    return new,old


# ----------------------------------------
def main() -> None:
    """
    機能: 同体受理と10種類の不一致拒否を人工値だけで実行する。
    引数: なし。返り値: None。小さい人工結果票を保存する。
    """
    source=fixture();assert check.compare_learning(*source)['成功']
    for target,path,value in ((3,('rows',0,'predictions','COMMON','prediction','probabilities','buy',0),.11),
        (3,('rows',0,'decision','directions','COMMON_P65'),-1),
        (3,('rows',0,'q0_time'),101),
        (4,('rows',0,'models','COMMON','model','training_array_sha256'),'b'*64),
        (4,('rows',0,'models','COMMON','model','structure_sha256'),'b'*64),
        (5,(0,'oblivious_trees',0,'leaf_values',0),9)):
        values=copy.deepcopy(source);cursor=values[target]
        for key in path[:-1]:cursor=cursor[key]
        cursor[path[-1]]=value
        assert not check.compare_learning(*values)['成功']
    new,old=selection_fixture();assert check.compare_selections(new,old)['成功']
    for key,value in (('side',-1),('stream','reverse'),('event_id','別出生'),('q0_line',3)):
        changed=copy.deepcopy(new);changed['政策']['COMMON_P65_N'][0][key]=value
        assert not check.compare_selections(changed,old)['成功']
    duplicated=copy.deepcopy(new)
    duplicated['政策']['COMMON_P65_N']*=2
    try:
        check.compare_selections(duplicated,old)
    except AssertionError:
        pass
    else:
        raise AssertionError('重複caseを受理した')
    result={'成功':True,'同体受理':2,'学習不一致拒否':6,'取得不一致拒否':4,'重複case拒否':1,
        '自然入力読取':False,'SourceSHA256':check.sha(Path(check.__file__))}
    path=Path(__file__).resolve().parent/'人工検査結果.json'
    path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False))


if __name__=='__main__':
    main()
