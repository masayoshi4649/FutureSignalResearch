"""161の固定条件を検査し、三方式を全73場へ過去順に適用する。"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import sys
import gzip

ROOT=Path(__file__).resolve().parents[2]
HERE=Path(__file__).resolve().parent
TRIAL=ROOT/'study/00161_三時間帯の入口を共通属性分割で比較する'
OUT=HERE/'自然学習'
BOOK_SHA='f22d735cefd0146aa4ec691a5adeeaf82c6961e746e88d7cdfd52fbcc25b46b8'


def module(path: Path, name: str) -> object:
    """
    機能: 固定したPython部品をmain未実行で読み込む。
    引数: path(Path)はSource、name(str)は登録名。
    返り値: objectは読込module。
    """
    spec=importlib.util.spec_from_file_location(name,path)
    value=importlib.util.module_from_spec(spec)
    sys.modules[name]=value
    spec.loader.exec_module(value)
    return value


def sha(path: Path) -> str:
    """
    機能: ファイルの物理SHA256を計算する。
    引数: path(Path)はファイル。
    返り値: strはSHA256。
    """
    with path.open('rb') as source:
        return hashlib.file_digest(source,'sha256').hexdigest()


def save(path: Path, value: object) -> None:
    """
    機能: UTF-8標準JSONをgzip又は通常ファイルへ保存する。
    引数: path(Path)、value(object)は保存対象。
    返り値: None。
    """
    body=(json.dumps(value,ensure_ascii=False,allow_nan=False,separators=(',',':'))+'\n').encode('utf-8')
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.suffix=='.gz':
        with path.open('wb') as raw:
            with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as target:
                target.write(body)
    else:
        path.write_bytes(body)


# ----------------------------------------
def main() -> None:
    """
    機能: F0を先に保存し、cacheの固定射影から自然学習・全q0判断を一度実行する。
    引数: なし。固定161条件と固定Sourceを利用する。
    返り値: None。判断・場監査・入力確認を保存する。取得結合・金融は行わない。
    """
    assert not OUT.exists()
    book_path=TRIAL/'条件.json'
    assert sha(book_path)==BOOK_SHA
    sources=[Path(__file__),ROOT/'work/161三時間帯入口のデータ/data161.py',
        *[ROOT/'work/161三時間帯入口のモデル'/name for name in ('model161.py','training161.py','simulate161.py')],
        ROOT/'work/過去場だけの教師選択と時間区画重み/教師選択.py']
    fingerprints={str(p.relative_to(ROOT)):sha(p) for p in sources}
    book=json.loads(book_path.read_text(encoding='utf-8'))
    f0={'成功':True,'試行':161,'時計':datetime.now(timezone.utc).isoformat(),'条件SHA256':BOOK_SHA,
        'Source':fingerprints,'自然実行前':True,'条件探索数':book['evaluation']['comparisons'],
        'キャッシュは旧151の後発生成物':'原148正式入力とSHA固定旧151Sourceから再射影可能。byte再生成同体は要求しない。'}
    save(TRIAL/'検査/F0_自然実行前.json',f0)
    OUT.mkdir()
    data=module(sources[1],'data161')
    model=module(sources[2],'model161')
    training=module(sources[3],'training161')
    simulate=module(sources[4],'simulate161')
    selector=module(sources[5],'teacher161')
    simulate.validate_book(book,model,training)
    import numpy as np
    import catboost
    assert book['runtime']=={'python':'.'.join(map(str,sys.version_info[:3])),'numpy':np.__version__,'catboost':catboost.__version__}
    features=data.load_feature_dataset()
    teachers=data.load_teacher_dataset(features.feature_meta())
    columns,catalog_proof=data.read_json_ref(data.FileRef(ROOT/'inputs/00148_全1分入口母集団/100特徴の列定義.json',book['catalog_definition_sha256']))
    if isinstance(columns,dict):
        columns=columns['columns']
    save(OUT/'入力確認.json',{'features':features.sources,'teachers':teachers.sources,'catalog':catalog_proof,
        'q0帯件数':{str(i):int(np.sum(features.q0_timeband==i)) for i in range(3)},
        '教師帯件数':{str(i):int(np.sum(teachers.teacher_timeband==i)) for i in range(3)}})
    decisions,audits=simulate.simulate(features,teachers,columns,features.q0_timeband,
        teachers.teacher_timeband,book,OUT,model,training,selector.select_past_teachers)
    save(OUT/'q0の判断.json.gz',{'成功':True,'試行':161,'q1結合前全件':True,'rows':decisions})
    save(OUT/'場別モデルと教師.json.gz',{'成功':True,'試行':161,'rows':audits})
    assert sha(book_path)==BOOK_SHA and all(sha(ROOT/p)==v for p,v in fingerprints.items())
    save(OUT/'学習完了.json',{'成功':True,'自然学習':True,'判断数':len(decisions),'場数':len(audits),
        'モデル数':len(list((OUT/'models').glob('*.json'))),'条件SHA256':BOOK_SHA,
        '出力SHA256':{p.name:sha(p) for p in OUT.iterdir() if p.is_file()}})
    print(json.dumps({'学習完了':True,'判断数':len(decisions),'場数':len(audits)},ensure_ascii=False),flush=True)


if __name__=='__main__':
    main()
